// @vitest-environment jsdom
// ⚠️ 本文件用 jsdom：scene 分支要 `document.createElement('canvas')`（控制器只创建 fg 一个 canvas），
// node 环境下 select 壁纸会直接抛 `document is not defined`。
import { describe, expect, it, vi } from 'vitest';
import { createWallpaperController } from '../src/client/wallpaper-controller.js';

function fakeLayer() {
  const calls: string[] = [];
  const fg: string[] = [];
  const outline: string[] = [];
  // showImage 的**实参**（正文字符串串不带 kenBurns，回退断言需要它）。
  const imageArgs: Array<[string, boolean]> = [];
  return {
    calls,
    fg,
    outline,
    imageArgs,
    showImage: (u: string, kenBurns: boolean) => { imageArgs.push([u, kenBurns]); calls.push('image:' + u); },
    showVideo: async (u: string) => { calls.push('video:' + u); return 'ok' as const; },
    showSceneCanvas: () => calls.push('scene'),
    showNone: () => calls.push('none'),
    setOverlayOpacity: () => {},
    setBlur: () => {},
    // 文字颜色跟随壁纸亮度：单独记录 setChatFg，不污染主 calls（不影响 switch 展示断言）。
    setChatFg: (c: string) => fg.push('fg:' + c),
    setChatOutline: (c: string, lv: number) => outline.push(`outline:${c}:${lv}`),
  } as any;
}

const list = [
  { id: '1', type: 'video', file: 'a.mp4', hasScene: false, hasPreviewGif: false, previewUrl: '/p1', title: 'v' },
  { id: '2', type: 'scene', hasScene: true, hasPreviewGif: false, previewUrl: '/p2', title: 's' },
  { id: '3', type: 'unknown', hasScene: false, hasPreviewGif: true, previewUrl: '/p3', title: 'g' },
];

describe('createWallpaperController', () => {
  it('loads the wallpaper list once', async () => {
    const layer = fakeLayer();
    const c = createWallpaperController(layer, { fetchList: async () => list as any });
    const got = await c.load();
    expect(got).toHaveLength(3);
  });
  it('select video -> video plan', async () => {
    const layer = fakeLayer();
    const c = createWallpaperController(layer, { fetchList: async () => list as any });
    await c.load();
    await c.select('1');
    expect(layer.calls.at(-1)).toBe('video:/wallpapers/media/1/file');
  });
  it('select scene -> falls back to image when scene renderer absent', async () => {
    const layer = fakeLayer();
    const c = createWallpaperController(layer, { fetchList: async () => list as any });
    await c.load();
    await c.select('2');
    // 阶段 2 前 scene 无渲染器 → 回退 preview 图
    expect(layer.calls.at(-1)).toBe('image:/p2');
  });
  it('select gif wallpaper -> image without kenburns', async () => {
    const layer = fakeLayer();
    const c = createWallpaperController(layer, { fetchList: async () => list as any });
    await c.load();
    await c.select('3');
    expect(layer.calls.at(-1)).toBe('image:/p3');
  });
  it('select empty id -> 取消壁纸（showNone 恢复默认背景）', async () => {
    const layer = fakeLayer();
    const c = createWallpaperController(layer, { fetchList: async () => list as any });
    await c.load();
    await c.select('');
    expect(layer.calls.at(-1)).toBe('none');
  });
  it('select empty id 在列表未加载时也能取消（不依赖 fetchList）', async () => {
    const layer = fakeLayer();
    let fetched = false;
    const c = createWallpaperController(layer, { fetchList: async () => { fetched = true; return list as any; } });
    await c.select('');
    expect(layer.calls.at(-1)).toBe('none');
    expect(fetched).toBe(false);
  });
  it('REPRO(I1): 缓存列表不含新添加壁纸时，select 该 id 应重新拉取列表后再选中', async () => {
    // 新添加壁纸在设置面板可见（组件独立 fetch），但 controller 内部缓存的 list 是旧列表。
    // 旧行为：list.find(id) 找不到 → 直接 return → 背景无任何变化（bug）。
    // 期望：select 找不到时重新 load 一次，列表刷新后能选中新壁纸。
    const layer = fakeLayer();
    let fetched = 0;
    const c = createWallpaperController(layer, {
      fetchList: async () => {
        fetched++;
        // 第一次（controller 初次缓存）：旧列表，不含新壁纸 '4'
        if (fetched === 1) {
          return ([{ id: '1', type: 'video', file: 'a.mp4', hasScene: false, hasPreviewGif: false, previewUrl: '/p1', title: 'v' }] as any);
        }
        // 之后：含新添加壁纸 '4'（新壁纸选择后按 preview 回退显示）
        return ([
          { id: '1', type: 'video', file: 'a.mp4', hasScene: false, hasPreviewGif: false, previewUrl: '/p1', title: 'v' },
          { id: '4', type: 'unknown', hasScene: false, hasPreviewGif: true, previewUrl: '/p4', title: 'new' },
        ] as any);
      },
    });
    await c.load();      // 缓存旧列表（不含 '4'）
    await c.select('4'); // 选择新添加的壁纸
    expect(layer.calls.at(-1)).toBe('image:/p4'); // 修复后命中 preview 回退
  });
});

// 视频编码兜底（v0.8）：showVideo 三态；失败时回退 preview、上报面板，且旧结果不得覆盖新选择。
describe('createWallpaperController 视频编码兜底', () => {
  const videoWall = (id: string, previewUrl: string | null, gif = false) =>
    ({ id, type: 'video', file: 'a.mp4', hasScene: false, hasPreviewGif: gif, previewUrl, title: 'v' }) as any;

  it('视频不支持 → 回退 preview 并上报 onMediaFailure', async () => {
    const layer = fakeLayer();
    layer.showVideo = vi.fn(async () => 'unsupported');
    const onMediaFailure = vi.fn();
    const c = createWallpaperController(layer, { fetchList: async () => list as any, onMediaFailure });
    await c.load();
    await c.select('1');
    expect(layer.imageArgs.at(-1)).toEqual(['/p1', true]);
    expect(onMediaFailure).toHaveBeenCalledWith('1', 'unsupported', 'preview');
  });

  it('视频超时 → 回退 preview（gif 不启用 Ken Burns）并上报 timeout', async () => {
    const layer = fakeLayer();
    layer.showVideo = vi.fn(async () => 'timeout');
    const onMediaFailure = vi.fn();
    const c = createWallpaperController(layer, { fetchList: async () => [videoWall('9', '/p9', true)] as any, onMediaFailure });
    await c.load();
    await c.select('9');
    expect(layer.imageArgs.at(-1)).toEqual(['/p9', false]);
    expect(onMediaFailure).toHaveBeenCalledWith('9', 'timeout', 'preview');
  });

  it('视频失败且无 preview → showNone（不留一块黑背景）', async () => {
    const layer = fakeLayer();
    layer.showVideo = vi.fn(async () => 'unsupported');
    const onMediaFailure = vi.fn();
    const c = createWallpaperController(layer, { fetchList: async () => [videoWall('9', null)] as any, onMediaFailure });
    await c.load();
    await c.select('9');
    expect(layer.calls.at(-1)).toBe('none');
    expect(onMediaFailure).toHaveBeenCalledWith('9', 'unsupported', 'none');
  });

  it('视频正常 → 不回退、不上报', async () => {
    const layer = fakeLayer();
    const onMediaFailure = vi.fn();
    const c = createWallpaperController(layer, { fetchList: async () => list as any, onMediaFailure });
    await c.load();
    await c.select('1');
    expect(layer.calls.at(-1)).toBe('video:/wallpapers/media/1/file');
    expect(layer.imageArgs).toHaveLength(0);
    expect(onMediaFailure).not.toHaveBeenCalled();
  });

  it('等待解码期间切换壁纸 → 旧失败结果不覆盖新壁纸、不上报', async () => {
    const layer = fakeLayer();
    let release!: (r: 'unsupported') => void;
    layer.showVideo = vi.fn(() => new Promise<'unsupported'>((res) => { release = res; }));
    const onMediaFailure = vi.fn();
    const c = createWallpaperController(layer, { fetchList: async () => list as any, onMediaFailure });
    await c.load();
    const pending = c.select('1'); // 视频结果挂起
    await c.select('3');           // 期间切到另一张壁纸
    release('unsupported');
    await pending;
    expect(layer.calls.at(-1)).toBe('image:/p3');
    expect(layer.imageArgs.at(-1)).toEqual(['/p3', false]);
    expect(onMediaFailure).not.toHaveBeenCalled();
  });
});

// WebGL 上下文丢失回退（Task 8，护栏项）：渲染器只带回调，**只有控制器**知道当前壁纸的 preview
// 地址 ⇒ 控制器在工厂体里注册回调，并在**调用时**读 currentInfo（闭包，不是注册时快照）。
// 覆盖三条：切到 preview 图（gif 不带 Ken Burns）、无 preview 走 showNone、换壁纸后回退新壁纸。
describe('createWallpaperController WebGL 上下文丢失回退 preview（Task 8）', () => {
  const sceneWall = (id: string, previewUrl: string | null, gif = false) =>
    ({ id, type: 'scene', hasScene: true, hasPreviewGif: gif, previewUrl, title: 's' }) as any;

  /** 假渲染器：捕获控制器注册的回调（= setOnContextLost 的下游），供用例模拟上下文丢失。 */
  function sceneRendererStub() {
    let onLost: ((id: string) => void) | null = null;
    return {
      lost: (id: string) => onLost?.(id),
      registered: () => onLost !== null,
      render: async () => true,
      setOnContextLost: (cb: ((id: string) => void) | null) => { onLost = cb; },
    };
  }

  function controller(sceneRenderer: unknown, walls: unknown[]) {
    const layer = fakeLayer();
    const c = createWallpaperController(layer, {
      fetchList: async () => walls as any,
      // 测光恒有结果：避免异步测光失败路径干扰回退断言。
      measurePreviewLuma: async () => 120,
      sceneRenderer: sceneRenderer as any,
    });
    return { layer, c };
  }

  it('上下文丢失 ⇒ 回退当前壁纸 preview 图（gif 不启用 Ken Burns）', async () => {
    const r = sceneRendererStub();
    const { layer, c } = controller(r, [sceneWall('2', '/p2', true)]);
    expect(r.registered()).toBe(true); // 工厂期就注册（不是等 scene 渲染时才注册）
    await c.load();
    await c.select('2');
    expect(layer.calls.at(-1)).toBe('scene');

    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    r.lost('2');
    expect(layer.imageArgs.at(-1)).toEqual(['/p2', false]);
    expect(warn.mock.calls.some((x) => String(x[0]).includes('上下文丢失'))).toBe(true);
    warn.mockRestore();
  });

  it('上下文丢失但该壁纸无 preview ⇒ showNone（不留一块空白 canvas）', async () => {
    const r = sceneRendererStub();
    const { layer, c } = controller(r, [sceneWall('2', null)]);
    await c.load();
    await c.select('2');
    expect(layer.calls.at(-1)).toBe('scene');

    // 回退路径自身 warn（壁纸 id）：spy 收口，保持测试输出干净。
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    r.lost('2');
    expect(layer.calls.at(-1)).toBe('none');
    warn.mockRestore();
  });

  it('换壁纸后再丢失 ⇒ 用**当时**的 currentInfo（读到新壁纸的 preview，非注册时快照）', async () => {
    const r = sceneRendererStub();
    const walls = [sceneWall('2', '/p2'), sceneWall('5', '/p5')];
    const { layer, c } = controller(r, walls);
    await c.load();
    await c.select('2');
    await c.select('5');
    expect(layer.calls.at(-1)).toBe('scene');

    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    r.lost('5');
    // 注册发生在构造期（此时还没有 currentInfo）；若实现快照了注册时的值，这里会拿到 /p2 或什么都不做。
    expect(layer.imageArgs.at(-1)).toEqual(['/p5', true]);
    warn.mockRestore();
  });

  it('select 进行中丢上下文 ⇒ 按回调参数（id）选对壁纸，不闪出上一张', async () => {
    const r = sceneRendererStub();
    const { layer, c } = controller(r, [sceneWall('2', '/p2'), sceneWall('9', '/p9')]);
    await c.load();
    await c.select('2');
    expect(layer.calls.at(-1)).toBe('scene');
    // 让 #9 的渲染挂起：此时 select('9') 还没走到 currentInfo = #9，currentInfo 仍是 #2
    let release!: (ok: boolean) => void;
    const gate = new Promise<boolean>((res) => { release = res; });
    r.render = () => gate;
    const pending = c.select('9');
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    // 渲染器回报的 id 是**正在渲染的那张**；旧实现只读 currentInfo ⇒ 拿到 #2 的 /p2
    r.lost('9');
    expect(layer.imageArgs.at(-1)).toEqual(['/p9', true]);
    warn.mockRestore();
    release(true);
    await pending;
  });
});

// 贴壁纸文字颜色（2026-10-01，用户报告「某些壁纸文字看不清」）：设置面板可手动指定文字色，
// 手动档**跳过** preview 亮度测量直接下发固定色（否则异步测量会把手选颜色覆盖掉）；
// auto 档保持既有行为（测不出来 → 清变量回主题默认）。描边档位随颜色一起下发。
describe('createWallpaperController 文字颜色（手动档优先于自动测量）', () => {
  const style = (patch: Partial<{ mode: string; custom: string; outline: number }> = {}) =>
    ({ mode: 'auto', custom: '#ff8800', outline: 0, ...patch });
  const luma = (id: string) => ({ id, type: 'unknown', hasScene: false, hasPreviewGif: false, previewUrl: '/p' + id, title: 't' });
  const setup = (opts: any = {}) => {
    const layer = fakeLayer();
    const c = createWallpaperController(layer, { fetchList: async () => [luma('1')] as any, ...opts });
    return { layer, c };
  };

  it('手动白/黑/自定义：select 后直接下发固定色（不依赖 preview 测量）', async () => {
    for (const [mode, want] of [['white', '#ffffff'], ['black', '#000000'], ['custom', '#ff8800']] as const) {
      const { layer, c } = setup({ textStyle: () => style({ mode }) });
      await c.load();
      await c.select('1');
      expect(layer.fg.at(-1)).toBe('fg:' + want);
    }
  });

  it('自定义色非法时回退白色（不把任意串写进 CSS 变量）', async () => {
    const { layer, c } = setup({ textStyle: () => style({ mode: 'custom', custom: 'red;x' }) });
    await c.load();
    await c.select('1');
    expect(layer.fg.at(-1)).toBe('fg:#ffffff');
  });

  it('描边档位随文字色一起下发（对立色由 layer 计算）', async () => {
    const { layer, c } = setup({ textStyle: () => style({ mode: 'black', outline: 2 }) });
    await c.load();
    await c.select('1');
    expect(layer.outline.at(-1)).toBe('outline:#000000:2');
  });

  it('auto 档：测量不出亮度 → 清空颜色与描边（回主题默认，与既有行为一致）', async () => {
    const { layer, c } = setup({ measurePreviewLuma: async () => null, textStyle: () => style({ outline: 3 }) });
    await c.load();
    await c.select('1');
    expect(layer.fg.at(-1)).toBe('fg:');
    expect(layer.outline.at(-1)).toBe('outline::0');
  });

  it('auto 档：测出暗壁纸 → 白字 + 描边档位生效', async () => {
    const { layer, c } = setup({ measurePreviewLuma: async () => 32, textStyle: () => style({ outline: 1 }) });
    await c.load();
    await c.select('1');
    expect(layer.fg.at(-1)).toBe('fg:#f9fafb');
    expect(layer.outline.at(-1)).toBe('outline:#f9fafb:1');
  });

  it('auto 档：测出亮壁纸 → 黑字', async () => {
    const { layer, c } = setup({ measurePreviewLuma: async () => 220, textStyle: () => style() });
    await c.load();
    await c.select('1');
    expect(layer.fg.at(-1)).toBe('fg:#0f1115');
  });

  it('测量回调期间用户改成手动档 → 迟到的测量结果不得覆盖手选颜色', async () => {
    let release: (v: number | null) => void = () => {};
    const pending = new Promise<number | null>((r) => { release = r; });
    let mode = 'auto';
    const { layer, c } = setup({ measurePreviewLuma: () => pending, textStyle: () => style({ mode }) });
    await c.load();
    await c.select('1');          // auto：启动测量（挂起）
    mode = 'white';
    c.applyTextStyle();           // 用户改设置 → 立即按手动档下发
    expect(layer.fg.at(-1)).toBe('fg:#ffffff');
    release(32);                  // 迟到的测量结果回来
    await new Promise((r) => setTimeout(r, 0));
    expect(layer.fg.at(-1)).toBe('fg:#ffffff'); // 仍是手选色
  });

  it('applyTextStyle()：设置变更后无需重选壁纸即可生效', async () => {
    let s = style({ mode: 'auto' });
    const { layer, c } = setup({ measurePreviewLuma: async () => 220, textStyle: () => s });
    await c.load();
    await c.select('1');
    expect(layer.fg.at(-1)).toBe('fg:#0f1115');
    s = style({ mode: 'custom', custom: '#00ff00', outline: 2 });
    c.applyTextStyle();
    expect(layer.fg.at(-1)).toBe('fg:#00ff00');
    expect(layer.outline.at(-1)).toBe('outline:#00ff00:2');
  });

  it('取消壁纸（select 空 id）清空颜色与描边变量', async () => {
    const { layer, c } = setup({ textStyle: () => style({ mode: 'white', outline: 1 }) });
    await c.load();
    await c.select('1');
    await c.select('');
    expect(layer.fg.at(-1)).toBe('fg:');
    expect(layer.outline.at(-1)).toBe('outline::0');
  });

  // auto 档改描边（2026-10-01，用户报告「选自动时描边像不生效」）：首次测光结果要**缓存**，
  // 之后改档位/描边同步下发（拖动即时可见），且不再为每次拖动重新测图。
  const tick = () => new Promise((r) => setTimeout(r, 0));

  it('auto 档：测光完成后改描边同步生效（拖动即时可见），且不再重新测图', async () => {
    let outline = 0;
    const measure = vi.fn(async () => 220);
    const layer = fakeLayer();
    const c = createWallpaperController(layer, {
      fetchList: async () => [luma('1')] as any,
      measurePreviewLuma: measure,
      textStyle: () => style({ outline }),
    });
    await c.load();
    await c.select('1'); // 首次：启动测光
    await tick();
    expect(layer.fg.at(-1)).toBe('fg:#0f1115');
    expect(measure).toHaveBeenCalledTimes(1);

    outline = 2;
    c.applyTextStyle(); // 用户拖描边 → 同步下发（无需 await）
    expect(layer.outline.at(-1)).toBe('outline:#0f1115:2');
    await tick();
    expect(measure).toHaveBeenCalledTimes(1); // 没有为拖滑杆重新测图
  });

  it('auto 档：切换壁纸不复用上一张的测光结果（各自重新测光）', async () => {
    const two = [luma('1'), luma('2')];
    const measure = vi.fn(async (url: string) => (url.includes('p2') ? 220 : 32));
    const layer = fakeLayer();
    const c = createWallpaperController(layer, {
      fetchList: async () => two as any,
      measurePreviewLuma: measure,
      textStyle: () => style(),
    });
    await c.load();
    await c.select('1');
    await tick();
    expect(layer.fg.at(-1)).toBe('fg:#f9fafb'); // 暗壁纸 → 白字
    await c.select('2');
    await tick();
    expect(layer.fg.at(-1)).toBe('fg:#0f1115'); // 新壁纸重新测光，而非沿用白字
    expect(measure).toHaveBeenCalledTimes(2);
  });

  it('auto 档：测光瞬时失败但有上次结果 → 保留旧色与描边（不闪回主题默认）', async () => {
    const measure = vi.fn(async () => 32);
    const layer = fakeLayer();
    const c = createWallpaperController(layer, {
      fetchList: async () => [luma('1')] as any,
      measurePreviewLuma: measure,
      textStyle: () => style({ outline: 1 }),
    });
    await c.load();
    await c.select('1');
    await tick();
    expect(layer.fg.at(-1)).toBe('fg:#f9fafb');
    measure.mockImplementation(async () => null); // 第二次测光失败（网络抖动 / 跨源）
    await c.select('1');
    await tick();
    expect(layer.fg.at(-1)).toBe('fg:#f9fafb');                  // 保留旧色
    expect(layer.outline.at(-1)).toBe('outline:#f9fafb:1');      // 描边同样保留
  });
});

// scene 降级链（v0.8 Task 6）：渲染成功 → onSceneLive（后台抓帧入口）；
// 失败/异常 → 可注入 sceneFallback（内嵌视频 → 抓帧 → preview）；降级自身抛错必须落回既有 preview。
describe('createWallpaperController scene 降级链（Task 6）', () => {
  const sceneWall = (id: string, previewUrl: string | null = '/p' + id, gif = false, sceneEntry?: string) =>
    ({ id, type: 'scene', hasScene: true, sceneEntry, hasPreviewGif: gif, previewUrl, title: 's' }) as any;

  function make(opts: {
    render?: () => Promise<boolean>;
    walls?: unknown[];
    onSceneLive?: (info: any) => void;
    sceneFallback?: (info: any) => Promise<void>;
  } = {}) {
    const layer = fakeLayer();
    const renderer = {
      render: vi.fn(opts.render ?? (async () => true)),
      setOnContextLost: vi.fn(),
    };
    const c = createWallpaperController(layer, {
      fetchList: async () => (opts.walls ?? [sceneWall('2')]) as any,
      sceneRenderer: renderer,
      onSceneLive: opts.onSceneLive,
      sceneFallback: opts.sceneFallback,
      // 测光恒有结果：避免异步测光失败路径干扰回退断言。
      measurePreviewLuma: async () => 120,
    });
    return { layer, c, renderer };
  }

  // WE 模板（GIF）：scene 入口不是 scene.json，渲染器需要拿到 list 下发的入口名。
  it('scene 渲染把入口名传给 renderer（自定义 pkg 的 gifscene.json）', async () => {
    const { c, renderer } = make({ walls: [sceneWall('2', '/p2', false, 'gifscene.json')] });
    await c.load();
    await c.select('2');
    expect(renderer.render).toHaveBeenCalled();
    expect((renderer.render.mock.calls[0] as unknown[])[3]).toBe('gifscene.json');
  });

  it('渲染成功 → showSceneCanvas 后调用 onSceneLive（带 info），不触发 sceneFallback', async () => {    const onSceneLive = vi.fn();
    const sceneFallback = vi.fn(async () => {});
    const { layer, c } = make({ onSceneLive, sceneFallback });
    await c.load();
    await c.select('2');
    expect(layer.calls.at(-1)).toBe('scene');
    expect(onSceneLive).toHaveBeenCalledTimes(1);
    expect(onSceneLive.mock.calls[0][0]).toMatchObject({ id: '2' });
    expect(sceneFallback).not.toHaveBeenCalled();
  });

  it('首次 render false、重建 canvas 重试成功 → 仍调用 onSceneLive（只一次）', async () => {
    let n = 0;
    const onSceneLive = vi.fn();
    const { layer, c } = make({ render: async () => ++n > 1, onSceneLive });
    await c.load();
    await c.select('2');
    expect(layer.calls.at(-1)).toBe('scene');
    expect(onSceneLive).toHaveBeenCalledTimes(1);
  });

  it('渲染失败（两次 false）→ 调用 sceneFallback，由其决定显示内容；控制器不再叠加 preview', async () => {
    const sceneFallback = vi.fn(async (_info: any) => {});
    const onSceneLive = vi.fn();
    const { layer, c } = make({ render: async () => false, sceneFallback, onSceneLive });
    await c.load();
    await c.select('2');
    expect(sceneFallback).toHaveBeenCalledTimes(1);
    expect(sceneFallback.mock.calls[0][0]).toMatchObject({ id: '2' });
    expect(onSceneLive).not.toHaveBeenCalled();
    expect(layer.imageArgs).toHaveLength(0); // 降级链负责显示，控制器不重复回 preview
  });

  it('render 抛异常 → 同样调用 sceneFallback（不向调用方抛）', async () => {
    const sceneFallback = vi.fn(async () => {});
    const { c } = make({ render: async () => { throw new Error('gl lost'); }, sceneFallback });
    await c.load();
    await expect(c.select('2')).resolves.toBeUndefined();
    expect(sceneFallback).toHaveBeenCalledTimes(1);
  });

  it('无 sceneRenderer（渲染不可用）但注入了 sceneFallback → 仍走降级链', async () => {
    const layer = fakeLayer();
    const sceneFallback = vi.fn(async () => {});
    const c = createWallpaperController(layer, {
      fetchList: async () => [sceneWall('2')] as any,
      sceneFallback,
      measurePreviewLuma: async () => 120,
    });
    await c.load();
    await c.select('2');
    expect(sceneFallback).toHaveBeenCalledWith(expect.objectContaining({ id: '2' }));
    expect(layer.imageArgs).toHaveLength(0);
  });

  it('sceneFallback 抛错 → 落回既有 preview（绝不白屏）', async () => {
    const sceneFallback = vi.fn(async () => { throw new Error('fallback boom'); });
    const { layer, c } = make({ render: async () => false, sceneFallback });
    await c.load();
    await expect(c.select('2')).resolves.toBeUndefined();
    expect(layer.imageArgs.at(-1)).toEqual(['/p2', true]);
  });

  it('sceneFallback 抛错且无 preview → showNone（不留黑块）', async () => {
    const layer = fakeLayer();
    const c = createWallpaperController(layer, {
      fetchList: async () => [sceneWall('6', null)] as any,
      sceneRenderer: { render: vi.fn(async () => false), setOnContextLost: vi.fn() } as any,
      sceneFallback: async () => { throw new Error('fallback boom'); },
      measurePreviewLuma: async () => 120,
    });
    await c.load();
    await c.select('6');
    expect(layer.calls.at(-1)).toBe('none');
  });

  it('未经注入了 sceneFallback 时行为不变（scene 失败 → preview）', async () => {
    const { layer, c } = make({ render: async () => false });
    await c.load();
    await c.select('2');
    expect(layer.imageArgs.at(-1)).toEqual(['/p2', true]);
  });
});
