import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { parseSceneJson, sceneJsonWithResolvedModulation } from '../src/client/scene-json.js';
import { resolveSceneUserBindings } from '../src/client/user-bindings.js';

const raw = readFileSync(new URL('./fixtures/eva/scene.json', import.meta.url), 'utf8');

describe('parseSceneJson', () => {
  it('parses camera and orthogonal projection', () => {
    const desc = parseSceneJson(raw);
    expect(desc.camera.center).toEqual([35.931, -6.317, 0]);
    expect(desc.orthogonal).toEqual({ width: 2400, height: 1555 });
  });
  // 粒子透视相机（2026-09-26）：spec 带 flags perspective 位的粒子对象在 WE 里改用
  // `global_perspective` 相机渲染，其参数来自 general.fov / general.perspectiveoverridefov
  // （OWE SceneObjectParsers.cpp:59-85）。缺省 fov=50、perspectiveoverridefov=0（= 未覆盖）。
  it('parses general.fov / general.perspectiveoverridefov（粒子透视相机参数）', () => {
    const desc = parseSceneJson(JSON.stringify({
      general: { fov: 50, perspectiveoverridefov: 90, orthogonalprojection: { width: 3840, height: 2160 } },
      objects: [],
    }));
    expect(desc.fov).toBe(50);
    expect(desc.perspectiveOverrideFov).toBe(90);
  });
  it('general.fov / perspectiveoverridefov 缺失 → WE 缺省 50 / 0', () => {
    const desc = parseSceneJson(JSON.stringify({
      general: { orthogonalprojection: { width: 1920, height: 1080 } },
      objects: [],
    }));
    expect(desc.fov).toBe(50);
    expect(desc.perspectiveOverrideFov).toBe(0);
  });
  // F15：general.clearcolor 真实库为 0-1（如 2980088441），也有 0-255 写法；解析统一归一化到 0-255。
  it('normalizes general.clearcolor from 0-1 or 0-255 to 0-255', () => {
    const parse = (cc: string) => parseSceneJson(JSON.stringify({
      general: { orthogonalprojection: { width: 1920, height: 1080 }, clearcolor: cc },
      objects: [],
    }));
    expect(parse('0.06667 0.07843 0.09412').clearColor)
      .toEqual([0.06667 * 255, 0.07843 * 255, 0.09412 * 255]);
    expect(parse('17 20 24').clearColor).toEqual([17, 20, 24]);
  });
  // A4：NaN / 非有限分量不产出 clearColor（走缺省黑），与 optColor 的 isFinite 口径一致。
  it('clearcolor 含 NaN/非有限值 → 不产出 clearColor', () => {
    const parse = (cc: string) => parseSceneJson(JSON.stringify({
      general: { orthogonalprojection: { width: 1920, height: 1080 }, clearcolor: cc },
      objects: [],
    }));
    expect(parse('nan 20 24').clearColor).toBeUndefined();
    expect(parse('17 Infinity 24').clearColor).toBeUndefined();
    expect(parse('17 20').clearColor).toEqual([17, 20, 0]); // 分量不足补 0（非 NaN，旧语义不变）
  });
  // F8：壁纸级 bloom（general.bloom*）——仅 bloom===true 才产出；缺省 strength=2 / threshold=0.65。
  it('解析壁纸级 bloom（strength/threshold，缺省 2/0.65）', () => {
    const parse = (general: Record<string, unknown>) =>
      parseSceneJson(JSON.stringify({ camera: {}, general, objects: [] }));
    expect(parse({ bloom: true }).bloom).toEqual({ strength: 2, threshold: 0.65 });
    expect(parse({ bloom: true, bloomstrength: 0.98, bloomthreshold: 0.65 }).bloom)
      .toEqual({ strength: 0.98, threshold: 0.65 });
    expect(parse({ bloom: false }).bloom).toBeUndefined();
    expect(parse({}).bloom).toBeUndefined();
  });
  it('parses objects into image and particle kinds', () => {
    const desc = parseSceneJson(raw);
    const imageObj = desc.objects.find((o) => o.kind === 'image') as any;
    expect(imageObj.image).toBe('models/neon-genesis-evangelion-wallpaper-3.json');
    const particleObjs = desc.objects.filter((o) => o.kind === 'particle');
    expect(particleObjs.length).toBeGreaterThanOrEqual(4);
  });
  it('parses image object size field (WE pixels)', () => {
    const desc = parseSceneJson(raw);
    const imageObj = desc.objects.find((o) => o.kind === 'image') as any;
    expect(imageObj.size).toEqual([2400, 1555]);
    // 粒子对象无 size 字段
    const particleObj = desc.objects.find((o) => o.kind === 'particle') as any;
    expect(particleObj.size).toBeUndefined();
  });
  it('leaves size undefined when absent or invalid', () => {
    const desc = parseSceneJson('{"objects":[{"id":1,"image":"a.json","origin":"0 0 0","scale":"1 1 1"}]}');
    expect((desc.objects[0] as any).size).toBeUndefined();
    const bad = parseSceneJson('{"objects":[{"id":1,"image":"a.json","size":"abc","origin":"0 0 0","scale":"1 1 1"}]}');
    expect((bad.objects[0] as any).size).toBeUndefined();
  });
  it('falls back to a default camera when absent', () => {
    const desc = parseSceneJson('{"objects":[]}');
    expect(desc.camera.center).toEqual([0, 0, 0]);
  });
  it('defaults missing/invalid scale to [1,1,1] (WE: no scale = original size)', () => {
    // 缺 scale 字段的 image 对象（实测 3303428996/3743126786/3760200530）：scale 缺省须为
    // [1,1,1] 而非 [0,0,0]——否则 wasm image_half_ndc quad 尺寸 0 → 主图不渲染。
    // 与 Rust 侧 scene.rs unwrap_or([1.0,1.0,1.0]) 语义对齐。
    const missing = parseSceneJson('{"objects":[{"id":1,"image":"a.json","origin":"0 0 0"}]}');
    expect((missing.objects[0] as any).scale).toEqual([1, 1, 1]);
    // 非法 scale（非字符串）同样回退 [1,1,1]
    const bad = parseSceneJson('{"objects":[{"id":1,"image":"a.json","scale":123}]}');
    expect((bad.objects[0] as any).scale).toEqual([1, 1, 1]);
    // 合法 scale 保持原值；origin 缺省仍为 [0,0,0]（不回归 camera/origin 语义）
    const ok = parseSceneJson('{"objects":[{"id":1,"image":"a.json","origin":"0 0 0","scale":"2 2 1"}]}');
    expect((ok.objects[0] as any).scale).toEqual([2, 2, 1]);
    expect((ok.objects[0] as any).origin).toEqual([0, 0, 0]);
  });
  it('变换字段的 {script,value} / {animation,value} 形态消费静态 value', () => {
    // 库内实测 42 处非字符串写法（全部带 value），其中 10 处落在会被渲染的对象上；
    // 此前一律被丢成默认值（origin → [0,0,0] 即场景原点）。见 AGENT.md §7.16。
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        // 3798688689 obj701：text 的 origin/angles 是 {script, value}（真实作者坐标）
        { id: 701, text: 'x', origin: { script: 's', value: '1983.24158 750.83368 0.00000' },
          angles: { script: 's', value: '0.00000 0.00000 0.50615' }, scale: '1 1 1' },
        // 2597392171 obj251：particle 的 origin 是 {animation, value}
        { id: 251, particle: 'particles/p.json',
          origin: { animation: { c0: [] }, value: '1505.36206 5257.40479 0.00000' }, scale: '1 1 1' },
        // scale / size 的同类形态
        { id: 3, image: 'models/a.json', origin: '0 0 0',
          scale: { script: 's', value: '2 2 1' }, size: { animation: {}, value: '100 200' } },
      ],
    }));
    const [t, p, img] = desc.objects as any[];
    expect(t.origin).toEqual([1983.24158, 750.83368, 0]);
    expect(t.angles[2]).toBeCloseTo(0.50615, 6);
    expect(p.origin).toEqual([1505.36206, 5257.40479, 0]);
    expect(img.scale).toEqual([2, 2, 1]);
    expect(img.size).toEqual([100, 200]);
  });
  it('变换字段的对象形态**不含 value** 时仍回退默认（不引入未经验证的形态）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 1, image: 'models/a.json', origin: { animation: { c0: [] } }, scale: { script: 's' } },
      ],
    }));
    const o = desc.objects[0] as any;
    expect(o.origin).toEqual([0, 0, 0]); // 无静态值可用 ⇒ 维持原缺省
    expect(o.scale).toEqual([1, 1, 1]);
  });
  it('parent 字段解析（含容器对象）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 1, name: 'root', origin: '0 0 0', scale: '1 1 1' },
        { id: 2, parent: 1, image: 'models/a.json', origin: '0 0 0', scale: '1 1 1' },
      ],
    }));
    expect((desc.objects[0] as any).parent).toBeUndefined();
    expect((desc.objects[1] as any).parent).toBe(1);
  });
  it('classifies built-in util layers (models/util/*) as util kind', () => {
    // WE 内置合成层/全屏层/项目层：pkg 内无 models/util/*.json 文件，
    // 对象语义是效果链容器/控制节点（非纹理），必须与普通 image 区分开
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 1, name: 'Compose', image: 'models/util/composelayer.json', origin: '0 0 0', scale: '1 1 1' },
        { id: 2, name: 'Global', image: 'models/util/fullscreenlayer.json', origin: '0 0 0', scale: '1 1 1' },
        { id: 3, name: 'Pic', image: 'models/girl_01.json', origin: '0 0 0', scale: '1 1 1' },
      ],
    }));
    const utilObjs = desc.objects.filter((o) => o.kind === 'util');
    expect(utilObjs.length).toBe(2);
    expect(utilObjs[0].image).toBe('models/util/composelayer.json');
    const pic = desc.objects.find((o) => o.kind === 'image') as any;
    expect(pic.image).toBe('models/girl_01.json');
  });
  it('preserves effects chain on util objects for future effect rendering', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 1, name: 'girl_animation', image: 'models/util/composelayer.json',
        origin: '0 0 0', scale: '1 1 1',
        effects: [{ file: 'effects/waterwaves/effect.json', id: 244 }],
      }],
    }));
    const utilObj = desc.objects.find((o) => o.kind === 'util') as any;
    expect(utilObj.effects).toHaveLength(1);
    expect(utilObj.effects[0].file).toBe('effects/waterwaves/effect.json');
  });
  it('throws on non-object input', () => {
    expect(() => parseSceneJson('[]')).toThrow();
  });
});

// T3.1 text 对象归类（Ruling P3-1：particle > image > text(对象) > 空粒子兜底）。
// 真实样本：2937346640 的 VHS Time and Date（id=182）——text 字段为
// { script, scriptproperties, value } 对象，此前落入空粒子兜底不渲染。
describe('parseSceneJson text 对象归类（T3.1）', () => {
  const textObj = {
    id: 182, name: 'Time', origin: '1024 20 0', scale: '1 1 1',
    size: '400 100', color: '255 255 255 255', pointsize: '80',
    font: 'fonts/Atami-Regular.otf', alignment: 'center',
    text: { script: 'var d = new Date();', scriptproperties: '{}', value: '12:00' },
  };

  it('含 text 对象字段（无 image/particle）→ 归为 kind:text，text 取 text.value', () => {
    const desc = parseSceneJson(JSON.stringify({ objects: [textObj] }));
    const o = desc.objects[0] as any;
    expect(o.kind).toBe('text');
    expect(o.text).toBe('12:00');
  });

  it('text 对象的 effects 被解析保留', () => {
    const desc = parseSceneJson(JSON.stringify({
      camera: {}, general: {}, objects: [
        { id: 3, name: 't', text: '12:00', effects: [{ file: 'effects/waterwaves/effect.json' }] },
      ],
    }));
    const text = desc.objects.find((o) => o.kind === 'text') as any;
    expect(text.effects).toHaveLength(1);
  });

  // 2980088441（CodeTime）实测：11 个对象里有 4 个的 text 是**字符串**（"const"/"clock"/"={"/"}"），
  // 此前只认对象形态 → 它们被归为「无引用对象」不渲染，画面上整行 `const clock = {` 与收尾 `}` 缺失。
  it('text 为字符串 → 归为 kind:text，text 取该字符串（CodeTime 的 const/clock/={/} 形态）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 51, name: 'Text Layer', origin: '110.88 135.24 0', scale: '0.05 0.05 0.05',
        size: '365 156', text: 'const', font: 'systemfont_consolas', pointsize: '32',
        color: '0.19608 0.62353 0.62353', horizontalalign: 'center', verticalalign: 'center',
      }],
    }));
    const o = desc.objects[0] as any;
    expect(o.kind).toBe('text');
    expect(o.text).toBe('const');
    expect(o.pointsize).toBe(32);
    expect(o.color).toEqual([0.19608 * 255, 0.62353 * 255, 0.62353 * 255]);
  });

  // 图层尺寸/定位靠 horizontalalign/verticalalign/padding（SceneTextObjectParser 第 434-449 行）；
  // 缺失时图层取 alignment 推导（9 种锚点），因此三种形态的对象形态都要解析。
  it('对象形态 text：解析 horizontalalign/verticalalign/padding', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{ ...textObj, horizontalalign: 'left', verticalalign: 'bottom', padding: '32' }],
    }));
    const o = desc.objects[0] as any;
    expect(o.horizontalAlign).toBe('left');
    expect(o.verticalAlign).toBe('bottom');
    expect(o.padding).toBe(32);
  });

  it('字符串形态 text：同样解析 horizontalalign/verticalalign/padding；缺失 → undefined', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 59, name: 'vars', origin: '107.35 108.11 0', scale: '0.05 0.05 0.05',
        size: '511 936', text: 'hour:\nminute:', font: 'systemfont_consolas', pointsize: '32',
        padding: '32', horizontalalign: 'left', verticalalign: 'center',
      }],
    }));
    const o = desc.objects[0] as any;
    expect(o.kind).toBe('text');
    expect(o.horizontalAlign).toBe('left');
    expect(o.verticalAlign).toBe('center');
    expect(o.padding).toBe(32);

    const plain = parseSceneJson(JSON.stringify({ objects: [{ id: 1, text: 'x' }] }));
    const p = plain.objects[0] as any;
    expect(p.horizontalAlign).toBeUndefined();
    expect(p.verticalAlign).toBeUndefined();
    expect(p.padding).toBeUndefined();
  });

  it('保留 font/pointsize/color/size/alignment 字段', () => {
    const desc = parseSceneJson(JSON.stringify({ objects: [textObj] }));
    const o = desc.objects[0] as any;
    expect(o.font).toBe('fonts/Atami-Regular.otf');
    expect(o.pointsize).toBe(80);          // 字符串 "80" → 数值
    expect(o.color).toEqual([255, 255, 255]); // "r g b a" 取前 3 通道
    expect(o.size).toEqual([400, 100]);
    expect(o.alignment).toBe('center');
    expect(o.origin).toEqual([1024, 20, 0]);
    expect(o.scale).toEqual([1, 1, 1]);
  });

  it('text.value 缺失/非字符串 → text 为空字符串（静态渲染不崩）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{ id: 1, text: { script: 'var d = new Date();' }, origin: '0 0 0', scale: '1 1 1' }],
    }));
    expect((desc.objects[0] as any).kind).toBe('text');
    expect((desc.objects[0] as any).text).toBe('');
  });

  it('Ruling P3-1 优先级：particle > image > text > 空粒子兜底', () => {
    // particle 字符串优先于 text
    const p = parseSceneJson(JSON.stringify({ objects: [{ id: 1, particle: 'particles/p.json', text: { value: 'x' } }] }));
    expect((p.objects[0] as any).kind).toBe('particle');
    // image 字符串优先于 text
    const img = parseSceneJson(JSON.stringify({ objects: [{ id: 2, image: 'models/a.json', text: { value: 'x' } }] }));
    expect((img.objects[0] as any).kind).toBe('image');
    // 仅 text → text
    const t = parseSceneJson(JSON.stringify({ objects: [{ id: 3, text: { value: 'x' } }] }));
    expect((t.objects[0] as any).kind).toBe('text');
    // 无引用无 text → 空粒子兜底（原行为不回归）
    const empty = parseSceneJson(JSON.stringify({ objects: [{ id: 4 }] }));
    expect((empty.objects[0] as any).kind).toBe('particle');
  });

  // 2026-09-21 订正（原断言「text 字符串不归为 text」）：text 为字符串 = 静态文本
  // （CodeTime 的 "const" / "clock" / "={" / "}"）。全库实测该形态仅 4 个对象、全在 2980088441、
  // 值均为代码片段，无「把路径写进 text」的误用。
  it('text 为字符串 → 归为 text（静态文本）；数组 / 空串仍不归', () => {
    const s = parseSceneJson(JSON.stringify({ objects: [{ id: 1, text: 'const' }] }));
    expect((s.objects[0] as any).kind).toBe('text');
    expect((s.objects[0] as any).text).toBe('const');
    const arr = parseSceneJson(JSON.stringify({ objects: [{ id: 2, text: [] }] }));
    expect((arr.objects[0] as any).kind).not.toBe('text');
    const empty = parseSceneJson(JSON.stringify({ objects: [{ id: 3, text: '' }] }));
    expect((empty.objects[0] as any).kind).not.toBe('text');
  });

  it('pointsize 非数字 / color 非法 → 对应字段 undefined', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{ id: 1, text: { value: 'x' }, pointsize: 'abc', color: 'zzz' }],
    }));
    expect((desc.objects[0] as any).pointsize).toBeUndefined();
    expect((desc.objects[0] as any).color).toBeUndefined();
  });
});

// T3.3 脚本字段解析：image 对象从 visible.{script,scriptproperties}、text 对象从
// text.{script,scriptproperties} 提取（scriptproperties 的 {user,value} 包装解包）。
describe('parseSceneJson script/scriptproperties 解析（T3.3）', () => {
  it('image 对象 visible.script → script；visible.scriptproperties 的 user 绑定被保留', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 61, name: 'Simple Visualizer', image: 'models/workshop/2652493753/bar.json',
        origin: '113.74350 83.14454 0.00000', scale: '2.36344 2.36344 0.75850',
        alignment: 'bottomright',
        visible: {
          script: 'let audioData = engine.registerAudioBuffers(64);',
          scriptproperties: { barWidth: 0.83, originX: { user: '_x', value: 12.67 } },
          value: true,
        },
      }],
    }));
    const o = desc.objects[0] as any;
    expect(o.kind).toBe('image');
    expect(o.script).toBe('let audioData = engine.registerAudioBuffers(64);');
    // T4.4：带 user 的 scriptproperty 保留 {value,user}（装配前 resolve 成标量）；普通值仍解包。
    expect(o.scriptProperties).toEqual({ barWidth: 0.83, originX: { value: 12.67, user: { name: '_x' } } });
  });

  it('image 对象 alignment 字段 → SceneImageObject.alignment（2937346640 Simple Visualizer id=61 实测：bottomright）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 61, name: 'Simple Visualizer', image: 'models/workshop/2652493753/bar.json',
        origin: '113.74350 83.14454 0.00000', scale: '2.36344 2.36344 0.75850',
        alignment: 'bottomright',
      }],
    }));
    const o = desc.objects[0] as any;
    expect(o.kind).toBe('image');
    expect(o.alignment).toBe('bottomright');
  });

  it('particle 对象 alignment 字段 → SceneParticleObject.alignment；缺省/非法 → undefined', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 1, name: 'p1', particle: 'particles/a.json', origin: '0 0 0', scale: '1 1 1', alignment: 'top' },
        { id: 2, name: 'p2', particle: 'particles/b.json', origin: '0 0 0', scale: '1 1 1' },
        { id: 3, name: 'p3', particle: 'particles/c.json', origin: '0 0 0', scale: '1 1 1', alignment: 42 },
      ],
    }));
    expect((desc.objects[0] as any).alignment).toBe('top');
    expect((desc.objects[1] as any).alignment).toBeUndefined(); // 缺省 → undefined
    expect((desc.objects[2] as any).alignment).toBeUndefined(); // 非字符串 → undefined
  });

  it('text 对象 text.script → script；text.scriptproperties 的 user 绑定被保留（use24hFormat）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 182, name: 'VHS Time and Date', origin: '1859.88074 811.84882 0.00000', scale: '1 1 1',
        text: {
          script: 'let time = new Date(); let hours = time.getHours();',
          scriptproperties: { delimiter: ':', use24hFormat: { user: '_24hourformat', value: false } },
          value: '<Time and Date>',
        },
      }],
    }));
    const o = desc.objects[0] as any;
    expect(o.kind).toBe('text');
    expect(o.script).toBe('let time = new Date(); let hours = time.getHours();');
    expect(o.scriptProperties).toEqual({
      delimiter: ':',
      use24hFormat: { value: false, user: { name: '_24hourformat' } },
    });
  });

  it('无 script/scriptproperties → 字段 undefined（不误报）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{ id: 1, image: 'models/a.json', origin: '0 0 0', scale: '1 1 1' }],
    }));
    expect((desc.objects[0] as any).script).toBeUndefined();
    expect((desc.objects[0] as any).scriptProperties).toBeUndefined();
  });

  it('visible 为 {user,value} 开关包装（非脚本对象，如效果可见性）→ script 为 undefined', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{ id: 1, image: 'models/a.json', visible: { user: 'newproperty', value: true }, origin: '0 0 0', scale: '1 1 1' }],
    }));
    expect((desc.objects[0] as any).script).toBeUndefined();
  });

  it('scriptproperties 非对象（畸形数据）→ scriptProperties 为 undefined（不抛错）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{ id: 1, image: 'models/a.json', visible: { script: 'x', scriptproperties: 'nope' }, origin: '0 0 0', scale: '1 1 1' }],
    }));
    expect((desc.objects[0] as any).script).toBe('x');
    expect((desc.objects[0] as any).scriptProperties).toEqual({}); // 解析失败 → 空对象
  });
});

// I3 修复：WE 文本 color 为 0-1 归一化值（fixture 对象 182 实测 "1.00000 1.00000 1.00000"
// 白色），optColor 原按 0-255 直用 → rgb(1,1,1) 近黑、深色壁纸上时钟文本不可见。
// 归一化启发：max 分量 ≤ 1 → 视为 0-1 语义 ×255（"1 1 1" → 255）；否则保持 0-255 语义。
describe('text 对象 color 归一化（I3：0-1 与 0-255 双语义）', () => {
  const parseColor = (color: string) => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{ id: 1, text: { value: 'x' }, color, origin: '0 0 0', scale: '1 1 1' }],
    }));
    return (desc.objects[0] as any).color;
  };

  it('"1 1 1"（0-1 语义白色，VHS fixture 实测形态）→ 255（归一化 ×255，不再近黑）', () => {
    expect(parseColor('1.00000 1.00000 1.00000')).toEqual([255, 255, 255]);
  });
  it('"255 255 255"（0-255 语义）→ 不变', () => {
    expect(parseColor('255 255 255 255')).toEqual([255, 255, 255]);
  });
  it('"0 0 0" → 0 不变（两种语义下黑色一致）', () => {
    expect(parseColor('0 0 0')).toEqual([0, 0, 0]);
  });
  it('中间值 "0.5 0.5 0.5" → ×255 得 127.5（0-1 语义线性放大）', () => {
    expect(parseColor('0.5 0.5 0.5')).toEqual([127.5, 127.5, 127.5]);
  });
  it('既有 0-255 语义不回归：T3.1 的 "255 255 255 255" 仍解析为白色', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 182, name: 'Time', origin: '1024 20 0', scale: '1 1 1',
        size: '400 100', color: '255 255 255 255', pointsize: '80',
        font: 'fonts/Atami-Regular.otf', alignment: 'center',
        text: { script: 'var d = new Date();', scriptproperties: '{}', value: '12:00' },
      }],
    }));
    expect((desc.objects[0] as any).color).toEqual([255, 255, 255]);
  });

  // CodeTime id=54 的 color 是**对象**（音频响应脚本驱动，value = 红色）→ 不执行脚本时取 value。
  it('color 为对象（脚本驱动）→ 取 value 解析（否则退化为白色）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 54, text: 'clock', origin: '0 0 0', scale: '1 1 1',
        color: { script: 'x', scriptproperties: {}, value: '0.76078 0.15294 0.15294' },
      }],
    }));
    expect((desc.objects[0] as any).color).toEqual([0.76078 * 255, 0.15294 * 255, 0.15294 * 255]);
  });
});

// T3.4/v0.8.1 sound 字段解析：WE 音频对象（无 image/particle/text 的纯音频节点）携带
// sound 数组。实测（PkgReader 全库 26 个 scene.pkg）：10 个含 sound 的壁纸全部为
// 对象级 sound 数组（如 2937346640 id=35：["sounds/yutaka hirasaka - acro.flac"]），
// 无根级 sound 字段 → 按 objects 顺序收集。v0.8.1 起每个对象产出结构化 SceneSoundObject
// （多文件 + volume + playbackmode，语义对齐 OWE SoundParser）。
// 音频对象本身无可见内容，解析后仍落入空粒子兜底（不渲染，行为与现状一致）。
describe('parseSceneJson sound 对象解析（T3.4/v0.8.1）', () => {
  it('对象级 sound 数组 → SceneDescription.sounds（2937346640 id=35 实测形态）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 1, image: 'models/a.json', origin: '0 0 0', scale: '1 1 1' },
        {
          id: 35, name: 'yutaka hirasaka - acro.flac',
          origin: '-194.97546 0 0', scale: '0.90018 0.90018 0.90018',
          sound: ['sounds/yutaka hirasaka - acro.flac'], playbackmode: 'loop', volume: 1,
        },
      ],
    }));
    expect(desc.sounds).toEqual([{
      files: ['sounds/yutaka hirasaka - acro.flac'], volume: 1, playbackmode: 'loop',
    }]);
  });

  it('sound 对象被解析为结构化 SceneSoundObject（volume/playbackmode/多文件）', () => {
    const raw = JSON.stringify({
      camera: {}, general: {}, objects: [
        { id: 1, name: 'bgm', sound: ['sounds/a.mp3', 'sounds/b.mp3'], volume: 0.31, playbackmode: 'random' },
      ],
    });
    const desc = parseSceneJson(raw);
    expect(desc.sounds).toEqual([{ files: ['sounds/a.mp3', 'sounds/b.mp3'], volume: 0.31, playbackmode: 'random' }]);
  });

  it('多对象 sound 按 objects 顺序收集（2597392171 实测：单对象 14 轨）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 1, sound: ['sounds/a.mp3', 'sounds/b.mp3'] },
        { id: 2, sound: ['sounds/c.mp3'] },
      ],
    }));
    expect(desc.sounds).toEqual([
      { files: ['sounds/a.mp3', 'sounds/b.mp3'], volume: 1, playbackmode: 'loop' },
      { files: ['sounds/c.mp3'], volume: 1, playbackmode: 'loop' },
    ]);
  });

  it('无 sound 对象 → sounds 为 undefined（不误报空数组）', () => {
    const desc = parseSceneJson('{"objects":[{"id":1,"image":"a.json"}]}');
    expect(desc.sounds).toBeUndefined();
  });

  it('sound 非数组 / 含非字符串条目 → 过滤（畸形数据防御，不抛错）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 1, sound: 'sounds/a.mp3' },              // 非数组 → 忽略
        { id: 2, sound: ['sounds/b.mp3', 42, null, ''] }, // 过滤非字符串/空串
        { id: 3, sound: [42, ''] },                    // 过滤后无文件 → 整个对象忽略
      ],
    }));
    expect(desc.sounds).toEqual([{ files: ['sounds/b.mp3'], volume: 1, playbackmode: 'loop' }]);
  });

  it('volume 越界/非数字与未知 playbackmode → 归一到 OWE 口径（clamp 0-1、回退 loop）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 1, sound: ['sounds/a.mp3'], volume: 2, playbackmode: 'shuffle' },
        { id: 2, sound: ['sounds/b.mp3'], volume: -1 },
        { id: 3, sound: ['sounds/c.mp3'], volume: 'loud', playbackmode: 'single' },
      ],
    }));
    expect(desc.sounds).toEqual([
      { files: ['sounds/a.mp3'], volume: 1, playbackmode: 'loop' },
      { files: ['sounds/b.mp3'], volume: 0, playbackmode: 'loop' },
      { files: ['sounds/c.mp3'], volume: 1, playbackmode: 'single' },
    ]);
  });
});

// T4.3 image 对象 color/alpha/brightness 调制字段解析：color 复用 optColor 归一化启发
// （0-1 → ×255），alpha 按 WE NormalizeLayerAlpha（>1 → /100，再 clamp 0-1），
// brightness 为乘法系数（缺省 1）。text 对象 color 路径不变（T3.1/I3 不回归）。
describe('parseSceneJson image 对象调制字段（T4.3）', () => {
  const parseImage = (fields: Record<string, unknown>) => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{ id: 1, image: 'models/a.json', origin: '0 0 0', scale: '1 1 1', ...fields }],
    }));
    return desc.objects[0] as any;
  };

  it('color 0-1 语义（"1 1 1"）→ ×255 归一化（复用 optColor 启发）', () => {
    expect(parseImage({ color: '1 1 1' }).color).toEqual([255, 255, 255]);
    expect(parseImage({ color: '0.5 0.5 0.5' }).color).toEqual([127.5, 127.5, 127.5]);
  });
  it('color 0-255 语义（"255 255 255"）→ 不变', () => {
    expect(parseImage({ color: '255 255 255 255' }).color).toEqual([255, 255, 255]);
  });
  it('color 缺省/非法 → undefined', () => {
    expect(parseImage({}).color).toBeUndefined();
    expect(parseImage({ color: 'zzz' }).color).toBeUndefined();
  });
  it('alpha 0-100 百分比（"50"）→ 0.5（NormalizeLayerAlpha：>1 → /100）', () => {
    expect(parseImage({ alpha: '50' }).alpha).toBe(0.5);
    expect(parseImage({ alpha: 80 }).alpha).toBe(0.8);
  });
  it('alpha 0-1 语义（"1"/"0.5"）→ 不变', () => {
    expect(parseImage({ alpha: '1' }).alpha).toBe(1);
    expect(parseImage({ alpha: '0.5' }).alpha).toBe(0.5);
  });
  it('alpha >100 → /100 后 clamp 1（"200" → 2 → 1）', () => {
    expect(parseImage({ alpha: '200' }).alpha).toBe(1);
  });
  it('alpha 缺省/非法 → undefined', () => {
    expect(parseImage({}).alpha).toBeUndefined();
    expect(parseImage({ alpha: 'abc' }).alpha).toBeUndefined();
  });
  it('brightness 缺省 → 1（乘法系数默认）', () => {
    expect(parseImage({}).brightness).toBe(1);
  });
  it('brightness 数值/数字字符串 → 原值', () => {
    expect(parseImage({ brightness: 2 }).brightness).toBe(2);
    expect(parseImage({ brightness: '0.5' }).brightness).toBe(0.5);
  });
  it('text 对象 color 不回归（T3.1/I3：仍解析为 0-255 量级）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{ id: 2, text: { value: 'x' }, color: '255 255 255 255', origin: '0 0 0', scale: '1 1 1' }],
    }));
    expect((desc.objects[0] as any).color).toEqual([255, 255, 255]);
  });
});

// T4.2 visible 归一化：scene.json 的 visible 字段（布尔 / {user,value} / {script,value}）
// 解析为 SceneObject.visible（VisibleBinding）。所有 kind（image/particle/text/util）
// 统一在 base 上解析；image 对象的 script/scriptProperties 由归一化 visible 派生
// （T3.3 行为不回归：kind==='script' 时字段照常产生）。
describe('parseSceneJson visible 归一化（T4.2）', () => {
  it('布尔 visible → visible.kind plain（image/particle/text 均支持）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 1, image: 'models/a.json', visible: false, origin: '0 0 0', scale: '1 1 1' },
        { id: 2, particle: 'particles/p.json', visible: true, origin: '0 0 0', scale: '1 1 1' },
        { id: 3, text: { value: 'x' }, visible: true, origin: '0 0 0', scale: '1 1 1' },
      ],
    }));
    expect((desc.objects[0] as any).visible).toEqual({ kind: 'plain', value: false });
    expect((desc.objects[1] as any).visible).toEqual({ kind: 'plain', value: true });
    expect((desc.objects[2] as any).visible).toEqual({ kind: 'plain', value: true });
  });

  it('{user,value} → visible.kind user（key/value 保留；不产生 script 字段）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{ id: 1, image: 'models/a.json', visible: { user: 'timeand', value: true }, origin: '0 0 0', scale: '1 1 1' }],
    }));
    const o = desc.objects[0] as any;
    expect(o.visible).toEqual({ kind: 'user', key: 'timeand', value: true });
    expect(o.script).toBeUndefined(); // 用户开关不是脚本对象（T3.3 语义保持）
  });

  it('{script,value} → visible.kind script，且 script/scriptProperties 照常解析（T3.3 不回归）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 61, name: 'Simple Visualizer', image: 'models/workshop/2652493753/bar.json',
        origin: '113.74350 83.14454 0.00000', scale: '2.36344 2.36344 0.75850',
        visible: {
          script: 'let audioData = engine.registerAudioBuffers(64);',
          scriptproperties: { barWidth: 0.83, originX: { user: '_x', value: 12.67 } },
          value: true,
        },
      }],
    }));
    const o = desc.objects[0] as any;
    expect(o.visible).toEqual({
      kind: 'script',
      script: 'let audioData = engine.registerAudioBuffers(64);',
      scriptProperties: { barWidth: 0.83, originX: { value: 12.67, user: { name: '_x' } } },
      value: true,
    });
    expect(o.script).toBe('let audioData = engine.registerAudioBuffers(64);'); // T3.3 字段保留
    expect(o.scriptProperties).toEqual({ barWidth: 0.83, originX: { value: 12.67, user: { name: '_x' } } });
  });

  it('无 visible 字段 → visible undefined（不误报绑定）', () => {
    const desc = parseSceneJson('{"objects":[{"id":1,"image":"models/a.json"}]}');
    expect((desc.objects[0] as any).visible).toBeUndefined();
  });

  it('visible 畸形（数组/数字/字符串/null）→ visible undefined（防御，不抛错）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 1, image: 'models/a.json', visible: [], origin: '0 0 0', scale: '1 1 1' },
        { id: 2, image: 'models/b.json', visible: 42, origin: '0 0 0', scale: '1 1 1' },
        { id: 3, image: 'models/c.json', visible: 'true', origin: '0 0 0', scale: '1 1 1' },
        { id: 4, image: 'models/d.json', visible: null, origin: '0 0 0', scale: '1 1 1' },
      ],
    }));
    for (const o of desc.objects) expect((o as any).visible).toBeUndefined();
  });

  // ---------------------------------------------------------------------------
  // 对象级 `instanceoverride`（粒子实例覆盖）：JS 侧**只透传原始 JSON 文本**，语义解析在
  // wasm CPU 模拟器（Rust `parse_particle_override`），避免两份语义漂移。
  // 回归背景：GTR 3743126786 的烟柱 `{alpha: 0.03, size: 2.09}` 此前完全没被消费，
  // 粒子按材质 alpha（实测均值 0.797）渲染 → 贯穿全屏的竖直白烟串。
  // ---------------------------------------------------------------------------
  it('particle 对象的 instanceoverride → instanceOverrideJson（原始 JSON 文本透传）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 22, name: 'Струя дыма', particle: 'particles/presets/smoke2.json',
        origin: '5101.16553 1089.44336 0.00000', scale: '2.89780 2.89780 2.89780',
        instanceoverride: { alpha: 0.029999999, id: 23, size: 2.0899999 },
      }],
    }));
    const p = desc.objects[0] as any;
    expect(p.kind).toBe('particle');
    expect(JSON.parse(p.instanceOverrideJson)).toEqual({ alpha: 0.029999999, id: 23, size: 2.0899999 });
  });

  it('instanceoverride 缺失/空对象/非对象 → instanceOverrideJson undefined（= 无覆盖）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 1, particle: 'particles/a.json' },
        { id: 2, particle: 'particles/b.json', instanceoverride: {} },
        { id: 3, particle: 'particles/c.json', instanceoverride: [] },
        { id: 4, particle: 'particles/d.json', instanceoverride: null },
        { id: 5, particle: 'particles/e.json', instanceoverride: 7 },
      ],
    }));
    for (const o of desc.objects) expect((o as any).instanceOverrideJson).toBeUndefined();
  });

  it('image 对象不产出 instanceOverrideJson（WE 里该字段属于 particle 对象）', () => {
    const desc = parseSceneJson('{"objects":[{"id":1,"image":"models/a.json","instanceoverride":{"alpha":0.5}}]}');
    expect((desc.objects[0] as any).instanceOverrideJson).toBeUndefined();
  });

  // F21：真实素材 2859263090 的对象 2233「Perspective (runscript)」把 colorn 写成
  // `{ user: null, value: "1.000 1.000 1.000" }`；wasm 只认标量 ⇒ 原样透传会 vec3(对象)
  // 得 [0,0,0]，additive 雪层变黑不可见。解 WE 的 `{user|script, value}` 包装后才还原白色。
  it('instanceoverride 的 {user,value} 包装被解包为标量字符串', () => {
    const raw = JSON.stringify({
      camera: {}, general: {}, objects: [
        {
          id: 9, name: 'snow', particle: 'particles/snow.json',
          instanceoverride: { rate: 1, colorn: { user: null, value: '1.000 1.000 1.000' } },
        },
      ],
    });
    const desc = parseSceneJson(raw);
    const p = desc.objects.find((o) => o.kind === 'particle') as any;
    expect(JSON.parse(p.instanceOverrideJson).colorn).toBe('1.000 1.000 1.000');
  });

  it('instanceoverride 的 {script,value} 包装及嵌套/数组内包装递归解包（有效 user 保留待 resolve）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 10, particle: 'particles/snow.json',
        instanceoverride: {
          colorn: { script: 'return vec3(1,1,1);', scriptproperties: {}, value: '2.000 3.000 4.000' },
          nested: { inner: { user: { name: 'u' }, value: 7 } },
          list: [{ user: null, value: 1 }, 2],
        },
      }],
    }));
    const parsed = JSON.parse((desc.objects[0] as any).instanceOverrideJson);
    expect(parsed.colorn).toBe('2.000 3.000 4.000');
    // T4.4：带有效 user 的包装不再预解包，交由 resolveSceneUserBindings 注入用户值。
    expect(parsed.nested).toEqual({ inner: { user: { name: 'u' }, value: 7 } });
    expect(parsed.list).toEqual([1, 2]);
  });

  // ---------------------------------------------------------------------------
  // 对象 `angles`（WE 对象欧拉角，**弧度**；缺省 (0,0,0)）。
  // 全库 79 个对象带非零 angles（粒子 75 / image 2 / text 1 / other 1），此前**完全未解析**
  // → 粒子运动方向/发射点、背景朝向都没经过对象旋转。
  // 回归背景（GTR 3743126786）：烟柱 `angles.z = -1.20063`（≈ -68.8°），局部 +Y（向上）
  // 经该旋转后指向世界 (0.932, 0.362) = **向右偏上** —— 正是桌面端「烟从排气管向右侧飘」，
  // 而网页端因为丢掉这个旋转，烟直着往上走。
  // ---------------------------------------------------------------------------
  it('解析对象 angles（弧度 → [x,y,z]；缺省 [0,0,0]）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 22, particle: 'particles/p.json', angles: '-0.00000 -0.00000 -1.20063' },
        { id: 23, particle: 'particles/q.json' },
        { id: 13, image: 'models/a.json', angles: '0.5 0 0' },
      ],
    }));
    const a0 = (desc.objects[0] as any).angles;
    expect(a0[0]).toBeCloseTo(0, 6);
    expect(a0[1]).toBeCloseTo(0, 6);
    expect(a0[2]).toBeCloseTo(-1.20063, 6);
    expect((desc.objects[1] as any).angles).toEqual([0, 0, 0]); // 缺省无旋转
    expect((desc.objects[2] as any).angles[0]).toBeCloseTo(0.5, 6);
  });

  // ---------------------------------------------------------------------------
  // image 对象的 `colorBlendMode`（WE 图像颜色混合模式 → shader combo BLENDMODE）。
  // 语义见 WE `shaders/common_blending.h::ApplyBlending`；非零时 WE 会追加一遍
  // 「读帧缓冲做混合」的 pass（lwe `CImage.cpp:751-767`）。
  // 回归背景（GTR 3743126786）：Clouds Back 的纹理是 78% 黑底 + 白云，`colorBlendMode: 7`
  // （Screen）本应让黑色不改变背景 —— 未实现时黑底被普通 alpha 混合直接盖上 = 左上角一块黑。
  // ---------------------------------------------------------------------------
  it('解析 image 对象的 colorBlendMode（数值；缺省/非法 → 0）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 246, image: 'models/clouds.json', colorBlendMode: 7 },
        { id: 17, image: 'models/bg.json' },
        { id: 18, image: 'models/x.json', colorBlendMode: 0 },
        { id: 19, image: 'models/y.json', colorBlendMode: 'abc' },
      ],
    }));
    expect((desc.objects[0] as any).colorBlendMode).toBe(7);
    expect((desc.objects[1] as any).colorBlendMode).toBe(0);
    expect((desc.objects[2] as any).colorBlendMode).toBe(0);
    expect((desc.objects[3] as any).colorBlendMode).toBe(0);
  });
});

// T4.4 scene 解析保留 {user} 引用：对象字段 / general / scriptproperties / instanceoverride
// 在解析阶段只记录 ref（userRefs / bloomUser / parallaxUser / {value,user}），装配前由
// resolveSceneUserBindings 统一替换；静态 value 仍作为兜底保留（旧渲染路径不受影响）。
describe('parseSceneJson 保留 {user} 引用（T4.4）', () => {
  it('对象字段的 {user} 绑定被保留为 userRefs（静态兜底仍解析）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        {
          id: 1, image: 'a', origin: '0 0 0', scale: '1 1 1',
          color: { user: 'clockcolor', value: '1 1 1' }, alpha: { user: 'vis', value: 0.5 },
          brightness: { user: 'bright', value: 2 },
        },
        {
          id: 2, image: 'b', origin: { user: 'move', value: '1 2 3' },
          scale: { user: 'zoom', value: '2 2 2' }, angles: { user: 'rot', value: '0 0 1' },
        },
      ],
    }));
    const [o1, o2] = desc.objects as any[];
    expect(o1.userRefs.color).toEqual({ name: 'clockcolor' });
    expect(o1.userRefs.alpha).toEqual({ name: 'vis' });
    expect(o1.userRefs.brightness).toEqual({ name: 'bright' });
    expect(o1.color).toEqual([255, 255, 255]); // 静态兜底仍保留
    expect(o1.alpha).toBe(0.5);
    expect(o1.brightness).toBe(2);
    expect(o2.userRefs.origin).toEqual({ name: 'move' });
    expect(o2.userRefs.scale).toEqual({ name: 'zoom' });
    expect(o2.userRefs.angles).toEqual({ name: 'rot' });
    expect(o2.origin).toEqual([1, 2, 3]);
    expect(o2.scale).toEqual([2, 2, 2]);
  });

  it('对象形态 user 的 condition 被保留；无绑定 → userRefs undefined', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [
        { id: 1, image: 'a', origin: '0 0 0', scale: '1 1 1', color: { user: { name: 'clock', condition: '1' }, value: '1 1 1' } },
        { id: 2, image: 'b', origin: '0 0 0', scale: '1 1 1', color: '1 1 1' },
      ],
    }));
    expect((desc.objects[0] as any).userRefs.color).toEqual({ name: 'clock', condition: '1' });
    expect((desc.objects[1] as any).userRefs).toBeUndefined();
  });

  it('general.bloom / cameraparallax 的 binding → bloomUser / parallaxUser', () => {
    const on = parseSceneJson(JSON.stringify({
      general: {
        bloom: { user: 'bloom', value: true },
        cameraparallax: { user: 'par', value: true },
        cameraparallaxamount: 0.5,
        orthogonalprojection: { width: 100, height: 100 },
      },
      objects: [],
    }));
    expect(on.bloomUser).toEqual({ name: 'bloom' });
    expect(on.parallaxUser).toEqual({ name: 'par' });
    expect(on.bloom).toEqual({ strength: 2, threshold: 0.65 }); // 静态 value=true 仍产出配置
    expect(on.parallax).toEqual({ enabled: true, amount: 0.5, delay: 0, mouseInfluence: 0 });

    const off = parseSceneJson(JSON.stringify({
      general: { bloom: { user: 'bloom', value: false }, orthogonalprojection: { width: 100, height: 100 } },
      objects: [],
    }));
    expect(off.bloomUser).toEqual({ name: 'bloom' });
    expect(off.bloom).toBeUndefined(); // 静态 false 不产出（等 resolve 决定）
  });

  it('scriptproperties 保留 {value, user}（普通值仍为标量）', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 182,
        text: {
          script: 'x', value: 'x',
          scriptproperties: { delimiter: ':', use24hFormat: { user: '_24h', value: false } },
        },
      }],
    }));
    const props = (desc.objects[0] as any).scriptProperties;
    expect(props.delimiter).toBe(':');
    expect(props.use24hFormat).toEqual({ value: false, user: { name: '_24h' } });
  });

  it('instanceoverride 中带有效 user 的包装被保留（供 resolve），无 user 的仍解包', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 10, particle: 'particles/p.json',
        instanceoverride: {
          rate: { user: 'leavedspeed', value: 1 },
          colorn: { user: null, value: '1.000 1.000 1.000' },
          nested: { inner: { user: { name: 'u' }, value: 7 } },
        },
      }],
    }));
    const parsed = JSON.parse((desc.objects[0] as any).instanceOverrideJson);
    expect(parsed.rate).toEqual({ user: 'leavedspeed', value: 1 });
    expect(parsed.colorn).toBe('1.000 1.000 1.000');
    expect(parsed.nested).toEqual({ inner: { user: { name: 'u' }, value: 7 } });
  });
});

// R1 写回回环：resolved color 是 0-255 三元组，写回原始 JSON 必须是 0-1 字符串，
// 否则 optColor 的 max≤1 启发会二次 ×255（#010101 近黑 → 白）。
describe('sceneJsonWithResolvedModulation（resolved 颜色按 0-1 写回）', () => {
  const writeBack = (authored: string, user: string): { color: number[]; json: any } => {
    const raw = JSON.stringify({
      camera: { center: '0 0 0', eye: '0 0 1', up: '0 1 0' },
      general: { orthogonalprojection: { width: 100, height: 100 } },
      objects: [{
        id: 1, image: 'a', origin: '0 0 0', scale: '1 1 1',
        color: { user: 'tint', value: authored },
      }],
    });
    const resolved = resolveSceneUserBindings(parseSceneJson(raw), { tint: user });
    const text = sceneJsonWithResolvedModulation(raw, resolved);
    return { color: (parseSceneJson(text).objects[0] as any).color, json: JSON.parse(text) };
  };

  it('#010101 近黑边界：resolved [1,1,1] 写回 0-1 串后重解析仍为 [1,1,1]（不再变白）', () => {
    const user = '0.00392156862745098 0.00392156862745098 0.00392156862745098'; // 1/255
    const out = writeBack('255 255 255', user);
    expect(out.color).toEqual([1, 1, 1]);
    expect(out.color).not.toEqual([255, 255, 255]);
  });

  it('纯白 / 纯黑边界往返', () => {
    expect(writeBack('255 255 255', '1 1 1').color).toEqual([255, 255, 255]);
    const black = writeBack('255 255 255', '0 0 0');
    expect(black.color).toEqual([0, 0, 0]);
    expect(black.json.objects[0].color).toBe('0 0 0');
  });

  it('写回颜色为 0-1 字符串；alpha/brightness 保持标量', () => {
    const raw = JSON.stringify({
      general: { orthogonalprojection: { width: 100, height: 100 } },
      objects: [{
        id: 1, image: 'a', origin: '0 0 0', scale: '1 1 1',
        color: { user: 'tint', value: '1 1 1' },
        alpha: { user: 'vis', value: 1 }, brightness: { user: 'bright', value: 1 },
      }],
    });
    const resolved = resolveSceneUserBindings(parseSceneJson(raw), { tint: '0.5 0.5 0.5', vis: 0.25, bright: 2 });
    const obj = JSON.parse(sceneJsonWithResolvedModulation(raw, resolved)).objects[0];
    expect(obj.color).toBe('0.5 0.5 0.5');
    expect(obj.alpha).toBe(0.25);
    expect(obj.brightness).toBe(2);
  });

  it('无 userRefs 的对象原样保留（仅写回绑定字段）', () => {
    const raw = JSON.stringify({
      general: { orthogonalprojection: { width: 100, height: 100 } },
      objects: [
        { id: 1, image: 'a', color: '10 20 30' },
        { id: 2, image: 'b', color: { user: 'tint', value: '1 1 1' } },
      ],
    });
    const resolved = resolveSceneUserBindings(parseSceneJson(raw), { tint: '1 1 1' });
    const out = JSON.parse(sceneJsonWithResolvedModulation(raw, resolved));
    expect(out.objects[0].color).toBe('10 20 30');
    expect(out.objects[1].color).toBe('1 1 1');
  });

  it('写回字段清单固定为 color/alpha/brightness：origin 走 worldTransforms、visible 走 effectiveVisible、未知字段不动', () => {
    const raw = JSON.stringify({
      general: { orthogonalprojection: { width: 100, height: 100 } },
      objects: [{
        id: 1, image: 'a',
        color: { user: 'tint', value: '1 1 1' },
        alpha: { user: 'vis', value: 1 },
        brightness: { user: 'bright', value: 1 },
        origin: { user: 'pos', value: '0 0 0' },
        visible: { user: 'show', value: true },
        custom: { user: 'tint', value: '9 9 9' },
      }],
    });
    const resolved = resolveSceneUserBindings(parseSceneJson(raw), {
      tint: '0.5 0.5 0.5', vis: 0.25, bright: 2, pos: '1 2 3', show: false,
    });
    const out = JSON.parse(sceneJsonWithResolvedModulation(raw, resolved)).objects[0];
    expect(out.color).toBe('0.5 0.5 0.5');
    expect(out.alpha).toBe(0.25);
    expect(out.brightness).toBe(2);
    // 变换与可见性不写回文本：前者由 SceneAssets.worldTransforms、后者由 effectiveVisible 下发
    expect(out.origin).toEqual({ user: 'pos', value: '0 0 0' });
    expect(out.visible).toEqual({ user: 'show', value: true });
    expect(out.custom).toEqual({ user: 'tint', value: '9 9 9' });
  });
});

// SceneScript 运行时（2026-09-22）：util 对象不渲染，但承载场景总控脚本——3798688689 的
// 4 个总控全部挂在 models/util/* 上，若 util 分支不派生 script，这些脚本永远不会被执行。
describe('parseSceneJson - util 对象的 visible.script', () => {
  it('util 对象保留 script 与解包后的 scriptProperties', () => {
    const raw = JSON.stringify({
      objects: [{
        id: 94000, name: '场景控制器',
        image: 'models/util/solidlayer.json',
        visible: {
          script: "'use strict';\nexport function update(v){return v;}",
          value: true,
          scriptproperties: { fx_float: { user: 'fx_float', value: true } },
        },
      }],
    });
    const desc = parseSceneJson(raw);
    const o = desc.objects[0] as any;
    expect(o.kind).toBe('util');
    expect(o.script).toContain('export function update');
    expect(o.scriptProperties).toEqual({ fx_float: { value: true, user: { name: 'fx_float' } } });
  });

  it('无 script 的 util 对象不产生 script 字段', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{ id: 1, image: 'models/util/solidlayer.json', visible: false }],
    }));
    expect((desc.objects[0] as any).script).toBeUndefined();
  });

  // ⚠️ 真实数据实测（3798688689）：3 个总控（92000 粒子 / 93000 拖尾 / 94000 场景控制器，
  // 后者 348 KB）**没有** image/particle/text 字段，会落到 parseSceneJson 末尾的空粒子兜底分支。
  // 只在 image/util 分支派生 script 的话，原始 15 个 visible.script 对象解析后只剩 12 个。
  it('无 image/particle/text 的纯控制器对象（兜底分支）也派生 script', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 94000, name: '场景控制器 · 双向切换与分类开关',
        visible: { script: "'use strict';\nexport function update(v){return v;}", value: true },
      }],
    }));
    const o = desc.objects[0] as any;
    expect(o.kind).toBe('particle');
    expect(o.particle).toBe('');
    expect(o.script).toContain('export function update');
  });

  it('particle 非空的对象也保留 script', () => {
    const desc = parseSceneJson(JSON.stringify({
      objects: [{
        id: 7, name: 'p', particle: 'particles/a.json',
        visible: { script: 'export function update(){}', value: true },
      }],
    }));
    const o = desc.objects[0] as any;
    expect(o.kind).toBe('particle');
    expect(o.particle).toBe('particles/a.json');
    expect(o.script).toContain('export function update');
  });
});
