import { describe, expect, it } from 'vitest';
import { WALLPAPER_CSS } from '../src/client/styles.js';

// 浅色模式适配（2026-08-19）：styles.ts 须导出 CSS 常量（供测试断言），
// 且包含竞品式主题分支——浅色（有壁纸、非深色主题）与深色（有壁纸 + 深色主题）。
// 插件自身 UI（picker/FAB/thumb/badge）颜色改用 CSS 变量，不再硬编码深色。

describe('styles 主题适配', () => {
  it('导出 CSS 含浅色分支（有壁纸、非深色主题）', () => {
    expect(WALLPAPER_CSS).toContain('body[data-we-wallpaper]:not([data-ds-dark-theme])');
  });
  it('导出 CSS 含深色分支（有壁纸 + 深色主题）', () => {
    expect(WALLPAPER_CSS).toContain('body[data-ds-dark-theme][data-we-wallpaper]');
  });
  it('浅色分支覆盖 DSH 灰阶文字 token 提升对比度', () => {
    // 浅色主题下文字按近白底调校，壁纸透出后失去对比 → 压暗整条灰阶（竞品 1396-1403 同款）
    expect(WALLPAPER_CSS).toMatch(/body\[data-we-wallpaper\]:not\(\[data-ds-dark-theme\]\)\s*{[^}]*--dsw-alias-label-primary/);
  });
  it('壁纸网格固定 3 列，窄面板降 2 列、超宽升 4 列（真实 DSH 设置区约 560px，不能只排 2 列）', () => {
    expect(WALLPAPER_CSS).toMatch(/\.wss-grid\s*\{[^}]*grid-template-columns:repeat\(3,\s*minmax\(0,\s*1fr\)\)/);
    expect(WALLPAPER_CSS).toMatch(/@container \(max-width:440px\)\s*\{\.wss-grid\{[^}]*grid-template-columns:repeat\(2,\s*minmax\(0,\s*1fr\)\)/);
    expect(WALLPAPER_CSS).toMatch(/@container \(min-width:900px\)\s*\{\.wss-grid\{[^}]*grid-template-columns:repeat\(4,\s*minmax\(0,\s*1fr\)\)/);
  });
  it('Hero 在真实设置宽度保持左图右信息，仅 ≤440px 才堆叠（设计稿不能只在宽预览壳成立）', () => {
    expect(WALLPAPER_CSS).toContain('@container (max-width:620px){.wss-hero-media{flex:0 0 160px;width:160px}}');
    expect(WALLPAPER_CSS).toContain('@container (max-width:440px){.wss-hero{flex-direction:column');
    expect(WALLPAPER_CSS).not.toContain('@container (max-width:620px){.wss-hero{');
    expect(WALLPAPER_CSS).toContain('@container (max-width:600px){.wss-pair{grid-template-columns:minmax(0,1fr)}}');
  });
  it('设置面板 UI 用 CSS 变量而非硬编码深色（wss-root）', () => {
    expect(WALLPAPER_CSS).toMatch(/\.wss-root\s*{[^}]*var\(--dsw-alias-label-primary/);
  });
  it('设置面板按钮用 CSS 变量而非硬编码深色（wss-cancel 分组）', () => {
    expect(WALLPAPER_CSS).toMatch(/\.wss-cancel[^{]*\{[^}]*var\(--dsw-alias-border-l2/);
  });
  it('缩略图文字颜色用 CSS 变量', () => {
    expect(WALLPAPER_CSS).toMatch(/\.wp-thumb\s*{[^}]*var\(--wp-text/);
  });
  it('不再包含已移除的 FAB / picker 面板样式', () => {
    expect(WALLPAPER_CSS).not.toMatch(/\.wp-fab/);
    expect(WALLPAPER_CSS).not.toMatch(/\.wp-picker-panel/);
  });
  it('背景透明化收敛到有壁纸时（body[data-we-wallpaper] 作用域）', () => {
    // 原实现无条件 body{background:transparent!important}，浅色主题无壁纸时也被破坏 →
    // 改为仅在有壁纸激活时透明化
    expect(WALLPAPER_CSS).toMatch(/body\[data-we-wallpaper\]\s+#root/);
  });
  it('遮罩颜色可读：浅色分支 overlay 不硬编码纯黑高不透明度', () => {
    // 遮罩仍为深色但透明度收敛（不再 .35 压暗浅色主题）
    expect(WALLPAPER_CSS).not.toMatch(/\.wp-bg-overlay\s*{[^}]*opacity:\.35/);
  });
  it('输入框/提问弹窗用半透明玻璃底且**不含 backdrop-filter**（桌面端滚动条抖动，2026-10-08）', () => {
    expect(WALLPAPER_CSS).not.toMatch(/\[data-we-wallpaper\]\s*\[class\*="flowItem"\]\s*\{[^}]*backdrop-filter/);
    expect(WALLPAPER_CSS).not.toMatch(/\[class\*="flowItem"\]\s*\{[^}]*border-radius:16px/);
    // 输入框：圆角 + 半透明玻璃底；`backdrop-filter` 会在桌面端「有壁纸 + 输出中」时
    // 触发横向滚动条闪现与页面跳动（去掉即消失），故断言其**不存在**（防回归）。
    expect(WALLPAPER_CSS).toMatch(/\[data-composer-card\]\s*\{[^}]*border-radius:20px/);
    const lightComposer = /body\[data-we-wallpaper\]\s*\[data-composer-card\]\s*\{([^}]*)\}/.exec(WALLPAPER_CSS)?.[1] ?? '';
    expect(lightComposer).toMatch(/background-color:rgba\(255,\s*255,\s*255,\s*\.6\d*\)/);
    expect(lightComposer).not.toMatch(/backdrop-filter/);
    const darkComposer = /body\[data-ds-dark-theme\]\[data-we-wallpaper\]\s*\[data-composer-card\]\s*\{([^}]*)\}/.exec(WALLPAPER_CSS)?.[1] ?? '';
    expect(darkComposer).toMatch(/background-color:rgba\(2[0-9],\s*2[0-9],\s*3[0-9],\s*\.7\d*\)/);
  });
  it('用户提问弹窗与主输入框一致：半透明玻璃，同样不含 backdrop-filter', () => {
    expect(WALLPAPER_CSS).toMatch(/\[data-question-key\]\s*section\s*\{[^}]*border-radius:20px/);
    const light = /body\[data-we-wallpaper\]\s*\[data-question-key\]\s*section\s*\{([^}]*)\}/.exec(WALLPAPER_CSS)?.[1] ?? '';
    expect(light).not.toMatch(/backdrop-filter/);
    const dark = /body\[data-ds-dark-theme\]\[data-we-wallpaper\]\s*\[data-question-key\]\s*section\s*\{([^}]*)\}/.exec(WALLPAPER_CSS)?.[1] ?? '';
    expect(dark).toMatch(/background-color:rgba\(2[0-9],\s*2[0-9],\s*3[0-9],\s*\.7\d*\)/);
  });
  it('整区 scrollBody 不 blur（壁纸在气泡间清晰可见，不遮挡背景）', () => {
    expect(WALLPAPER_CSS).not.toMatch(/\[class\*="scrollBody"\]\s*\{[^}]*backdrop-filter/);
  });
  it('侧边栏无 blur（对话框 portal 在下面会塌陷）；填充用 --dsw-specific-sidebar-fill 半透明（壁纸透出）', () => {
    expect(WALLPAPER_CSS).not.toMatch(/\[class\*="sidebarCol"\]\s*\{[^}]*backdrop-filter/);
    // 侧边栏根（hHd-Xa_root）与列都用 --dsw-specific-sidebar-fill，半透明让壁纸透出
    expect(WALLPAPER_CSS).toMatch(/body\[data-we-wallpaper\]:not\(\[data-ds-dark-theme\]\)\s*\{[^}]*--dsw-specific-sidebar-fill:rgba\(255,\s*255,\s*255,\s*\.5\d*\)!important/);
    expect(WALLPAPER_CSS).toMatch(/body\[data-ds-dark-theme\]\[data-we-wallpaper\]\s*\{[^}]*--dsw-specific-sidebar-fill:rgba\(24,\s*26,\s*30,\s*\.4\d*\)!important/);
  });
  it('壁纸层不透明化：消息区/输入框 token 透明（壁纸透出），整区 scrollBody 无 blur，消息区无 text-shadow', () => {
    // 侧边栏 fill 不再全局设 transparent，而由浅/深分支半透明控制（覆盖 DSH dark 分支的不透明值）
    expect(WALLPAPER_CSS).not.toMatch(/body\[data-we-wallpaper\]\s*\{[^}]*--dsw-specific-sidebar-fill:transparent/);
    const light = /body\[data-we-wallpaper\]:not\(\[data-ds-dark-theme\]\)\s*\{([^}]*)\}/.exec(WALLPAPER_CSS)?.[1] ?? '';
    expect(light).toMatch(/--dsw-specific-input-major:transparent/);
    expect(light).toMatch(/--dsw-specific-bubble:transparent/);
    const dark = /body\[data-ds-dark-theme\]\[data-we-wallpaper\]\s*\{([^}]*)\}/.exec(WALLPAPER_CSS)?.[1] ?? '';
    expect(dark).toMatch(/--dsw-specific-input-major:transparent/);
    expect(dark).toMatch(/--dsw-specific-bubble:transparent/);
    expect(WALLPAPER_CSS).not.toMatch(/\[class\*="scrollBody"\]\s*\{[^}]*backdrop-filter/);
    // 2026-09-18：断言收窄到消息区（原为全局 not.toMatch(/text-shadow:/)）。
    // 原意未变——消息区的对比靠 scrim + 文字颜色，不用 text-shadow；插件管理页
    // 页头/分组标题的阴影是另一页面的处理，见文件末尾用例。
    // 2026-10-01 收窄：消息区的文字描边改为「用户可选」（--wp-chat-outline，0 档 = none，
    // 默认仍是既有观感）。故不再禁止出现 text-shadow，但**不得硬编码**阴影值——
    // 消息区只允许「消费该变量」或「显式复位 none」（实底区域挡继承）。
    expect(WALLPAPER_CSS).not.toMatch(/\[class\*="flowItem"\][^{]*\{[^}]*text-shadow:(?!var\(--wp-chat-outline|none)/);
    expect(WALLPAPER_CSS).not.toMatch(/\[data-composer-card\][^{]*\{[^}]*text-shadow/);
    expect(WALLPAPER_CSS).not.toMatch(/\[data-question-key\][^{]*\{[^}]*text-shadow/);
  });
  it('scrim 遮罩：壁纸清晰可见但被适度压暗（.wp-bg-overlay rgba(0,0,0,.3)）', () => {
    expect(WALLPAPER_CSS).toMatch(/\.wp-bg-overlay\s*\{[^}]*background:rgba\(0,\s*0,\s*0,\s*\.3\d*\)/);
    expect(WALLPAPER_CSS).not.toMatch(/\.wp-bg-overlay\s*\{[^}]*opacity:\.35/);
  });
  it('边框强调：--dsw-alias-border-l1/l2 中性灰（深浅主题可见）', () => {
    expect(WALLPAPER_CSS).toMatch(/--dsw-alias-border-l1:rgba\(180,\s*180,\s*180/);
    expect(WALLPAPER_CSS).toMatch(/--dsw-alias-border-l2:rgba\(180,\s*180,\s*180/);
  });
  it('文字颜色跟随壁纸亮度：消息列文本消费 --wp-chat-fg（fallback 到主题文字色）', () => {
    // 2026-09-03：只改消息列文字颜色（不遮背景）。flowItem 主要文本 color 读 --wp-chat-fg，
    // 未测量时 fallback 到 DSH 主题文字色（--dsw-alias-label-primary）。
    expect(WALLPAPER_CSS).toMatch(/body\[data-we-wallpaper\]\s*\[class\*="flowItem"\]\s*p[\s\S]*color:var\(--wp-chat-fg,var\(--dsw-alias-label-primary,inherit\)\)/);
  });
  it('行内代码/代码块不随壁纸亮度反色：显式用主题文字色（避免暗壁纸下 code 白字白底）', () => {
    // 2026-09-03 修复：code 有独立不透明背景（浅色近白），其 color 会被父级 --wp-chat-fg 继承成白字
    // → 白底白字。须显式给 code/pre code 用 --dsw-alias-label-primary（随主题：浅=黑/深=白）。
    expect(WALLPAPER_CSS).toMatch(/body\[data-we-wallpaper\]\s*\[class\*="flowItem"\]\s*code[\s\S]*color:var\(--dsw-alias-label-primary,inherit\)/);
    expect(WALLPAPER_CSS).toMatch(/body\[data-we-wallpaper\]\s*\[class\*="flowItem"\]\s*pre code[\s\S]*color:var\(--dsw-alias-label-primary,inherit\)/);
  });
  it('actions 内操作 SVG 图标跟随壁纸亮度（fill=currentColor 继承容器 color）', () => {
    // 2026-09-03 修复：actions 的 SVG 图标 fill="currentColor"，背景透明贴壁纸，
    // 应跟随 --wp-chat-fg（暗壁纸→白图标、亮壁纸→黑图标），避免浅灰图标在壁纸上看不清。
    expect(WALLPAPER_CSS).toMatch(/\[class\*="flowItem"\]\s*\[class\*="actions"\]\s*svg\s*\{/);
    expect(WALLPAPER_CSS).toMatch(/\[class\*="flowItem"\]\s*\[class\*="actions"\]\s*svg\s*\{[^}]*color:var\(--wp-chat-fg,var\(--dsw-alias-label-primary,inherit\)\)/);
  });
  it('文件链接跟随壁纸亮度（[class*=fileLink]/a，避免深灰链接在暗壁纸上看不清）', () => {
    // 文件链接选择器是逗号分组（a, fileLink, _file），最后 `_file]{` 直接跟规则体。
    expect(WALLPAPER_CSS).toMatch(/\[class\*="flowItem"\]\s*\[class\*="fileLink"\]/);
    expect(WALLPAPER_CSS).toMatch(/\[class\*="flowItem"\]\s*\[class\*="_file"\]\s*\{[^}]*color:var\(--wp-chat-fg,var\(--dsw-alias-label-primary,inherit\)\)/);
  });
  it('li 列表点（::marker）跟随壁纸亮度（避免深灰点在暗壁纸上看不清）', () => {
    expect(WALLPAPER_CSS).toMatch(/\[class\*="flowItem"\]\s*li::marker\s*\{[^}]*color:var\(--wp-chat-fg,var\(--dsw-alias-label-primary,inherit\)\)/);
  });
  it('消息气泡（有独立背景）内部文字用主题色（避免暗壁纸下白字贴淡蓝底看不清）', () => {
    // 2026-09-03 修复：气泡有 --dsw-specific-bubble 背景（浅色淡蓝），内部文字不能用 --wp-chat-fg 反色，
    // 须显式用 --dsw-alias-label-primary（浅=黑/深=白）保证与气泡背景对比。
    // 选择器是逗号分组（bubble, bubble p, ... bubble code{），code 是最后一条直接跟 {。
    expect(WALLPAPER_CSS).toMatch(/\[class\*="flowItem"\]\s*\[class\*="bubble"\]\s*code\s*\{[^}]*color:var\(--dsw-alias-label-primary,inherit\)/);
  });
  it('自带实底的卡片（present 文件卡 / 改动文件卡）内部文字不跟随壁纸反色', () => {
    // 2026-09-18：这两类卡片有 --deliverable-fill / --changes-fill 实底，卡内文字靠继承取
    // --dsw-alias-label-primary；被 --wp-chat-fg 反色后，浅色主题下白字贴浅底 → 看不见。
    expect(WALLPAPER_CSS).toMatch(/\[data-presented-file\][\s\S]*color:var\(--dsw-alias-label-primary/);
    expect(WALLPAPER_CSS).toMatch(/\[data-changed-files\][\s\S]*color:var\(--dsw-alias-label-primary/);
    // 改动文件卡片 DSH 只给 header 上色，卡片本体要补 --changes-fill，否则文件行列表透壁纸
    expect(WALLPAPER_CSS).toMatch(/\[data-changed-files\]\s*\{[^}]*background:var\(--changes-fill/);
  });
  it('聊天顶部 header（文字+图标）跟随壁纸亮度', () => {
    // 2026-09-03：聊天 header（ChatHeader wSkVaW_header / headerActions / headerUtilities）
    // 背景透明贴壁纸，文字/图标用固定深灰 → 暗壁纸下看不清，跟随 --wp-chat-fg 反色。
    expect(WALLPAPER_CSS).toMatch(/body\[data-we-wallpaper\]\s*\[class\*="wSkVaW_header"\]/);
    // 规则体：header（含 header * 通配）都设 --wp-chat-fg
    expect(WALLPAPER_CSS).toMatch(/\[class\*="wSkVaW_header"\]\s*\*\s*\{[^}]*color:var\(--wp-chat-fg,/);
  });
  it('插件管理页（DSH 0.1.6 新增）卡片补底：两类稳定锚点都覆盖，且不碰共用中间列', () => {
    // 2026-09-18：该页容器与卡片原本全透明（--dsw-alias-bg-base 被插件置 transparent），
    // 文字直接压在壁纸上读不清。卡片有两类锚点：data-plugin-package（已安装的包）
    // 与 data-plugin-item（内置项），必须都覆盖，否则内置项那几张仍是无底的。
    expect(WALLPAPER_CSS).toMatch(/li:is\(\[data-plugin-package\],\[data-plugin-item\]\)\s*\{\s*background:var\(--wp-card-bg\)/);
    // 深浅两套底由 --wp-card-bg 按主题分支给出（深色主题白字配深底、浅色主题黑字配白底）
    expect(WALLPAPER_CSS).toMatch(/body\[data-we-wallpaper\]\s*\[data-plugin-panel\]\s*\{[^}]*--wp-card-bg:rgba\(255,\s*255,\s*255/);
    expect(WALLPAPER_CSS).toMatch(/body\[data-ds-dark-theme\]\[data-we-wallpaper\]\s*\[data-plugin-panel\]\s*\{[^}]*--wp-card-bg:rgba\(16,\s*18,\s*24/);
    // 挂在插件页专属容器上；挂共用中间列会波及对话页（先剥注释，只查真实选择器）
    expect(WALLPAPER_CSS.replace(/\/\*[\s\S]*?\*\//g, '')).not.toMatch(/centerCol/);
    // 详情页（同一 [data-plugin-panel] 的下一层）：头部块与「包含的组件」行补同一套底
    expect(WALLPAPER_CSS).toMatch(/\[data-plugin-detail\]\s*\[class\*="detailMain"\]\s*\{[^}]*background:var\(--wp-card-bg\)/);
    expect(WALLPAPER_CSS).toMatch(/li\[data-plugin-row\]\s*\{[^}]*background:var\(--wp-card-bg\)/);
    // 面包屑（← 插件列表）跟随壁纸亮度反色，避免 DSH 固定浅灰贴壁纸发虚
    expect(WALLPAPER_CSS).toMatch(/\[class\*="crumb"\]\s*\{[^}]*color:var\(--wp-chat-fg,/);
    // 页头标题/副标题同样走 chip 底（浅色主题下黑字压亮壁纸段仍糊）
    expect(WALLPAPER_CSS).toMatch(/\[class\*="pageIntro"\]\s*\{[^}]*background:var\(--wp-chip-bg\)/);
    // 页头不再加 text-shadow：会连 DSH 原生「＋ 添加插件」按钮的文字一起弄脏
    expect(WALLPAPER_CSS).not.toMatch(/pageHead[^{]*\{[^}]*text-shadow/);
  });
  it('右侧栏半透明底只作用于展开态；全屏仍用不透明底', () => {
    // 2026-09-18：面板内容容器原本全透明，内容直接压壁纸（浅色下大片发虚）。
    // 必须挂 [data-sidebar-right-panel]：点全屏后 DSH 把面板改成 position:fixed 铺满视口，
    // 挂外层 [data-rightbar-col]（仍 576px 宽）会整片漏底。
    // 2026-09-23 订正：0.1.7 起「收起」改成隐藏 dock 子内容，面板容器本身常驻且可见
    // （position:absolute/right:0，宽 = 侧栏宽度）⇒ 底必须限定 [data-sidebar-right-open]，
    // 否则收起时整条右栏被画成常驻遮罩（真机现象）。该属性三版都渲染。
    // 还必须用 :not(fullscreen) 排除全屏：属性限定把半透明底提到 (0,3,1)，会盖过全屏那条
    // (0,2,1) 的不透明底 ⇒ 全屏面板漏出壁纸（真机回归）。
    expect(WALLPAPER_CSS).toMatch(/body\[data-we-wallpaper\]\s*\[data-sidebar-right-panel\]\[data-sidebar-right-open\]:not\(\[data-sidebar-right-panel="fullscreen"\]\)\s*\{[^}]*background:rgba\(255,\s*255,\s*255,\s*\.7/);
    expect(WALLPAPER_CSS).toMatch(/body\[data-ds-dark-theme\]\[data-we-wallpaper\]\s*\[data-sidebar-right-panel\]\[data-sidebar-right-open\]:not\(\[data-sidebar-right-panel="fullscreen"\]\)\s*\{[^}]*background:rgba\(24,\s*26,\s*30,\s*\.6/);
    // 底不再挂外层列（全屏会漏）
    expect(WALLPAPER_CSS.replace(/\/\*[\s\S]*?\*\//g, '')).not.toMatch(/\[data-rightbar-col\]\s*\{/);
    // 不允许「未限定展开态就给面板上半透明底」的规则（全屏分支是不透明底，不在此列）
    const unguarded = [...WALLPAPER_CSS.matchAll(/([^{}]*\[data-sidebar-right-panel\][^{}]*)\{([^}]*)\}/g)]
      .filter(([sel, body]) => !sel.includes('data-sidebar-right-open')
        && /background[^;]*rgba\([^)]*,\s*\.?\d*\.\d+\s*\)/.test(body));
    expect(unguarded.map((m) => m[1].trim())).toEqual([]);
    // 全屏模式铺满视口，要用不透明底，否则左侧栏/聊天内容透上来（半透明实测仍有残影）；
    // 但必须同时限定 [data-sidebar-right-open]：收起按钮只 toggleExpanded、不改 mode ⇒
    // 「全屏 + 未展开」是可达状态（面板仍 width:100vw、dock 内容 visibility:hidden），
    // 未限定时整块不透明底会盖住整个应用 ⇒ 页面全空（真机现象）。
    expect(WALLPAPER_CSS).toMatch(/\[data-sidebar-right-panel="fullscreen"\]\[data-sidebar-right-open\]\s*\{[^}]*background:#fff/);
    expect(WALLPAPER_CSS).toMatch(/\[data-ds-dark-theme\]\[data-we-wallpaper\]\s*\[data-sidebar-right-panel="fullscreen"\]\[data-sidebar-right-open\]\s*\{[^}]*background:rgb\(24,\s*26,\s*30\)/);
  });
  it('全屏面板必须自带 z-index：盖住聊天（最高 z=10）、低于 DSH 遮罩（z=20），且不越权覆盖旧版 DSH 的 40', () => {
    // 2026-09-23（用户报告全屏时聊天框仍显示）：0.1.7 的 .P3OORG_panel 去掉了 z-index ⇒ 容器
    // z-index:auto，而聊天输入框所在的 composerStack 是 z-index:1、面板 dock 内容是 z-index:40
    // 但全透明 ⇒ 输入框浮在面板上。实测聊天内容层最高 z-index:10（dsh-client-ui-conversation），
    // DSH 自己的 overlayLayer 是 20，故取 15。
    // 但旧版（≤0.1.6）DSH 自己给了 `.P3OORG_panel[data-sidebar-right-panel=fullscreen]{z-index:40}`
    // ⇒ 该规则必须用 :where() 保持低具体度，否则会把旧版的 40 压成 15（真机 Chromium 层叠实测）。
    const css = WALLPAPER_CSS.replace(/\/\*[\s\S]*?\*\//g, '');
    const specificity = (sel: string) => {
      const s = sel.replace(/:where\([^)]*\)/g, ''); // :where() 不贡献具体度
      const ids = (s.match(/#[\w-]+/g) ?? []).length;
      const classes = (s.match(/\.[\w-]+|\[[^\]]+\]|:(?!:)[\w-]+/g) ?? []).length;
      const types = (s.match(/(?:^|[\s>+~])[a-zA-Z][\w-]*/g) ?? []).length;
      return ids * 10000 + classes * 100 + types;
    };
    const zRules = [...css.matchAll(/([^{}]+)\{([^}]*)\}/g)]
      .filter(([, sel, body]) => sel.includes('[data-sidebar-right-panel="fullscreen"]') && /z-index:\s*\d+/.test(body));
    expect(zRules.length).toBe(1); // z-index 与主题无关，一条即可
    const [sel, body] = [zRules[0][1].trim(), zRules[0][2]];
    expect(sel).toContain('[data-sidebar-right-open]'); // 收起态不得生效（否则空白盒子盖住整个应用）
    const z = Number(/z-index:\s*(\d+)/.exec(body)?.[1] ?? NaN);
    expect(z).toBeGreaterThan(10);
    expect(z).toBeLessThan(20);
    for (const one of sel.split(',')) {
      expect(specificity(one.trim()), one.trim())
        .toBeLessThan(specificity('.P3OORG_panel[data-sidebar-right-panel=fullscreen]')); // 旧版 DSH 的 40 那条
    }
  });
  it('弹层菜单底 --dsw-specific-menu 在有壁纸时必须提高不透明度（0.1.7 把它从 bg-layer-3 换成半透明玻璃）', () => {
    // 2026-09-23（用户报告「输入框面板透明度太高，看不清文字」）：0.1.7 把该 token 从
    // var(--dsw-alias-bg-layer-3)（不透明）改成字面量 #f8f9fa94 / #30313680（α≈.58/.50）
    // 并加 backdrop-filter:blur(40px) ⇒ 壁纸透上来、指令菜单/模型选择等 8 个包的弹层文字发虚。
    // 插件在有壁纸时把它压回接近不透明（浅 .92 / 深 .94），保持文字可读。
    const light = /body\[data-we-wallpaper\]:not\(\[data-ds-dark-theme\]\)\s*\{[^}]*--dsw-specific-menu:rgba\(255,\s*255,\s*255,\s*\.9\d*\)!important/;
    const dark = /body\[data-ds-dark-theme\]\[data-we-wallpaper\]\s*\{[^}]*--dsw-specific-menu:rgba\(2\d,\s*2\d,\s*3\d,\s*\.9\d*\)!important/;
    expect(WALLPAPER_CSS).toMatch(light);
    expect(WALLPAPER_CSS).toMatch(dark);
  });

  it('命令面板（MenuSurface）读的 --dsw-menu-surface-fill 必须同样提高不透明度（0.1.7-rc.2 起公共菜单底改由它提供）', () => {
    // 2026-09-28（用户报告「rc.2 下 / 调出的命令面板看不清」）：rc.2 把公共菜单迁到 MenuSurface
    // 组件，背景由 primitives 的 MenuSurface.module.css 读 **--dsw-menu-surface-fill** 提供；
    // 同时旧 token 退化为它的别名（非 macOS 上不再接近不透明）⇒ 只覆盖旧 token 对该菜单无效。
    // 实测（真实 GUI，有壁纸）：material background = rgba(248,249,250,.58)，token 值 #f8f9fa94。
    const light = /body\[data-we-wallpaper\]:not\(\[data-ds-dark-theme\]\)\s*\{[^}]*--dsw-menu-surface-fill:rgba\(255,\s*255,\s*255,\s*\.9\d*\)!important/;
    const dark = /body\[data-ds-dark-theme\]\[data-we-wallpaper\]\s*\{[^}]*--dsw-menu-surface-fill:rgba\(2\d,\s*2\d,\s*3\d,\s*\.9\d*\)!important/;
    expect(WALLPAPER_CSS).toMatch(light);
    expect(WALLPAPER_CSS).toMatch(dark);
  });

  // 文字可读性（2026-10-01，用户报告「某些壁纸文字看不清」）：设置面板可手动指定文字色并开描边。
  // 描边值由 JS 按文字色亮度算好后写进 --wp-chat-outline；CSS 侧只负责消费它，
  // fallback 到 none ⇒ 未开启（或 0 档）时观感与加此功能前一致。
  it('贴壁纸文字消费 --wp-chat-outline（fallback none；默认无描边）', () => {
    expect(WALLPAPER_CSS).toMatch(/text-shadow:var\(--wp-chat-outline,\s*none\)/);
    // 消息列主要文本必须消费（否则用户开了描边在正文上不生效）
    expect(WALLPAPER_CSS).toMatch(
      /body\[data-we-wallpaper\]\s*\[class\*="flowItem"\]\s*p[\s\S]{0,1200}?text-shadow:var\(--wp-chat-outline/,
    );
    // 链接同样消费（深灰链接贴壁纸是最易看不清的一类）
    expect(WALLPAPER_CSS).toMatch(/\[class\*="_file"\]\s*\{[^}]*text-shadow:var\(--wp-chat-outline/);
  });
  it('描边只作用于贴壁纸文字：实底区域（气泡/卡片/code）必须显式复位 text-shadow', () => {
    const css = WALLPAPER_CSS.replace(/\/\*[\s\S]*?\*\//g, '');
    // text-shadow 是**可继承**属性，且消息列的 `[class*="flowItem"] p/span/...` 规则同样命中
    // 气泡与卡片内的同名元素 ⇒ 实底区域必须显式 `text-shadow:none` 把描边挡回去，
    // 否则用户的描边会渗进实底文字（浅底黑边/深底白边都发脏）。
    const bodies = (needle: string) =>
      [...css.matchAll(/([^{}]+)\{([^}]*)\}/g)].filter(([, sel]) => sel.includes(needle)).map(([, , body]) => body);
    for (const anchor of ['[class*="bubble"]', '[data-presented-file]', '[data-changed-files]', '[class*="flowItem"] code']) {
      const hit = bodies(anchor);
      expect(hit.length, anchor + ' 必须命中规则（防正则/选择器写错导致假通过）').toBeGreaterThan(0);
      expect(hit.some((b) => /text-shadow:none/.test(b)), anchor + ' 需显式复位 text-shadow').toBe(true);
    }
    // 有自带底的其他区域同样不得消费描边变量
    for (const anchor of ['[data-composer-card]', '[data-question-key]', '[data-plugin-panel]']) {
      for (const body of bodies(anchor)) expect(body, anchor).not.toMatch(/--wp-chat-outline/);
    }
  });
  it('面板文字可读性控件复用既有 wss-row / wss-slider，并给 color 输入最小样式', () => {
    expect(WALLPAPER_CSS).toMatch(/\.wss-row input\[type=color\]\s*\{[^}]*width:\d+px/);
  });

  // Task 4：实时渲染卡片（状态行 + 重试/清除按钮）的类名必须在样式里落地，
  // 且按钮要进既有的按钮基样式与 reduced-motion 列表（否则动效与其它按钮不一致）。
  it('实时渲染卡片：状态行与两个按钮都有样式，按钮进基样式与 reduced-motion 列表', () => {
    for (const cls of ['.wss-live-status', '.wss-live-retry', '.wss-live-forget']) {
      expect(WALLPAPER_CSS).toContain(cls);
    }
    expect(WALLPAPER_CSS).toMatch(/\.wss-live-status\[data-state="failed"\][^{]*\{[^}]*color:var\(/);
    expect(WALLPAPER_CSS).toMatch(/\.wss-cancel[^{]*\.wss-live-retry[^{]*\.wss-live-forget[^{]*\{[^}]*var\(--dsw-alias-border-l2/);
    expect(WALLPAPER_CSS).toMatch(/prefers-reduced-motion[^{]*\{[^}]*\.wss-live-retry[^}]*\.wss-live-forget[^}]*transition:none/);
  });

  // 通知卡片（turn-trigger，「收到任务消息」）与代码块同底（2026-10-08，用户报告两块配色不一致）：
  // DSH 深色主题下卡片底读 --dsw-alias-turn-trigger-bg = --dsw-alias-interactive-bg-hover
  // （#ffffff14 半透明），代码块读 --dsw-alias-markdown-code-block（#1b1b1c 实色）；
  // 插件把 --dsw-alias-bg-base 透明化后卡片直接透壁纸 ⇒ 同屏两块观感不一致。
  // 有壁纸时把卡片底（含 hover）统一到代码块同色。
  it('通知卡片（turn-trigger）底与 hover 都统一到代码块底色（浅/深两侧都覆盖）', () => {
    // 必须写进浅/深分支（特异性 (0,2,1)）：DSH 自己的定义是 body[data-ds-dark-theme]（(0,1,1)），
    // 若写成单条 body[data-we-wallpaper]（同为 (0,1,1)）就只能靠样式表插入顺序取胜。
    const light = /body\[data-we-wallpaper\]:not\(\[data-ds-dark-theme\]\)\s*\{([^}]*)\}/.exec(WALLPAPER_CSS)?.[1] ?? '';
    const dark = /body\[data-ds-dark-theme\]\[data-we-wallpaper\]\s*\{([^}]*)\}/.exec(WALLPAPER_CSS)?.[1] ?? '';
    for (const [name, body] of [['浅色', light], ['深色', dark]] as const) {
      expect(body, name).toMatch(/--dsw-alias-turn-trigger-bg:var\(--dsw-alias-markdown-code-block\)/);
      expect(body, name).toMatch(/--dsw-alias-turn-trigger-bg-hover:var\(--dsw-alias-markdown-code-block\)/);
    }
  });
  it('通知卡片是实底：卡内文字用主题色（不被 --wp-chat-fg 反色）且描边复位', () => {
    // --wp-chat-fg 按壁纸亮度反色，压在实底上会白底白字 / 深底黑字，故与气泡/present 卡片同口径复位。
    // ⚠ 光写 [data-turn-trigger] * 不够：消息列的 `[class*="flowItem"] p` 具体度 (0,2,2) 高于
    // 通配后代 (0,2,1)（`*` 不贡献具体度、`p` 贡献 1），属性会输给它 ⇒ 实测卡内仍是黑字。
    const css = WALLPAPER_CSS.replace(/\/\*[\s\S]*?\*\//g, '');
    const specificity = (sel: string) => {
      const s = sel.replace(/:where\([^)]*\)/g, '');
      const ids = (s.match(/#[\w-]+/g) ?? []).length;
      const classes = (s.match(/\.[\w-]+|\[[^\]]+\]|:(?!:)[\w-]+/g) ?? []).length;
      const types = (s.match(/(?:^|[\s>+~])[a-zA-Z][\w-]*/g) ?? []).length;
      return ids * 10000 + classes * 100 + types;
    };
    const hit = [...css.matchAll(/([^{}]+)\{([^}]*)\}/g)]
      .map((m) => [m[1], m[2]] as const)
      .filter(([sel]) => sel.includes('[data-turn-trigger]'));
    expect(hit.length, '必须命中 [data-turn-trigger] 规则（防选择器写错导致假通过）').toBeGreaterThan(0);
    const colorRules = hit.filter(([, body]) => /color:var\(--dsw-alias-label-primary/.test(body));
    expect(colorRules.length, '卡内文字须复位为 --dsw-alias-label-primary').toBeGreaterThan(0);
    const shadowRules = hit.filter(([, body]) => /text-shadow:none/.test(body));
    expect(shadowRules.length, '卡内容器须显式复位 text-shadow').toBeGreaterThan(0);
    // 复位规则必须**每一条选择器**都压过消息列反色规则，否则卡内仍被反色
    const floor = specificity('body[data-we-wallpaper] [class*="flowItem"] p');
    const stronger = colorRules.some(([sel]) => sel.split(',').every((one) => specificity(one.trim()) > floor));
    expect(stronger, '复位规则具体度必须高于 [class*="flowItem"] p 反色规则').toBe(true);
  });
  it('通知卡片 header 与说明文字保留 DSH 层级色', () => {
    expect(WALLPAPER_CSS).toMatch(/\[data-turn-trigger\]\s*>\s*button[^{]*\{[^}]*color:var\(--dsw-alias-label-tertiary/);
    expect(WALLPAPER_CSS).toMatch(/\[data-turn-trigger\]\s*\[class\*="explanation"\]\s*\{[^}]*color:var\(--dsw-alias-label-secondary/);
  });
});
