# AGENT.md

本文件供 AI 编程助手快速了解 `dsh-use-wallpaper` 仓库。**改动代码前请通读本文件**，并查阅 `docs/superpowers/specs/` 下对应的设计文档。

**本文只写现状、硬约束与真遗留**（结论直给，§5 每条 ≤3 行）。历史根因、实验数据、一次性扫描结果、已修记录的完整版在 `docs/fixes/`（索引见 §8）—— **新内容不要往本文件里堆数据**；测试项数、全库计数这类会漂的数字一律不在此钉死，以 `npm test` / e2e 的实测输出为准。文中出现的「**全库 N 条 / N 张 / N 个对象**」都是**本机壁纸库的快照**（会随素材增减而漂移），只作量级与影响面参考，**不要据此推断代码行为**。§5.x / §7.x 的**编号多处被代码注释引用，不得重排**（§5.35 是历史空号）。

三句话版本：单包 DSH 插件；scene 壁纸由 **three.js 播放器**在浏览器实时渲染（粒子模拟复用 wasm CPU 模拟器），失败回退 preview 图；渲染语义以 **Wallpaper Engine（WE）** 为准，参考实现是 `research/open-wallpaper-engine`（C++）与 `research/.lwe`（linux-wallpaperengine），**WE 安装目录下的 shader 与材质是明文的**（`<WE>/assets/shaders`、`<WE>/assets/materials`）—— 遇语义疑问先读它们。

## 1. 项目概述

- **形态**：单包仓库，仓库根即插件 `@dsh-use/wallpaper-engine`（`package.json` 声明了 `dsh.bundle`，可直接 `dsh plugin add github:...`）。
- **能力**：扫描 Steam workshop 壁纸目录（默认 `D:/Steam/steamapps/workshop/content/431960`，可自动探测 —— 注册表 + `libraryfolders.vdf` + 常见路径，见 `src/host/steam-paths.ts` —— 或手动配置，settings 热更新），在 DSH Web GUI 里渲染 scene 壁纸 / 播放视频 / 加载 web 页，其余回退 preview 图 + Ken Burns。
- **入口**：DSH 设置对话框侧边栏「壁纸」菜单（client 经 `settings.section` slot 注册，见 `src/client/settings-section.tsx`）。
- **技术栈**：TypeScript strict、ESM-only；浏览器侧 three.js（WebGL2）+ Rust（wasm，**仅 CPU 粒子模拟**，已无 wgpu/WebGPU）；宿主侧 Cordis 插件体系。Node 版本无 `engines` 声明，CI 用 Node 22。
- **自带解包**：host 侧自行解析 **PKGV 容器**（magic `PKGV` 在 offset 4，`src/host/pkg-reader.ts` 只校验这 4 字节，版本字段未使用）与 **TEXV0005 纹理**（`src/client/tex-loader.ts`）；不依赖 WE 运行时。

## 2. 架构

### 2.1 scene 渲染路径

- **接线**：`index.ts` → `createThreeSceneRenderer()`（`three-renderer.ts`：拉 scene.json + 背景纹理 + 粒子条件 + 纹理材质）→ `loadSceneToThree()`（`threejs-player.ts`：正交 cover 相机 + 背景 mesh + 粒子 billboard）→ `setAnimationLoop` 每帧 `sim.update(dt)` 后刷新粒子缓冲。
- **段渲染与帧内快照**（2026-10-13，§5.45）：无消费者时整条路径与本文之前**逐字节一致**；有消费者（当前**只有**粒子 `REFRACT`）时 `render()` 改走 `renderSegmented()` —— 按 `renderOrder` 升序逐段渲进 `frameCapture.target`，消费者段**绘制之前**拍一张帧内快照。⚠️ **成本 = O(段数 × 场景)**：每段一次**全场景** `render`（靠 `visible` 排除其它段），不是「每对象只光栅化一次」（实测数字见 §5.45 与设计文档附录 A.4 ⑦）。效果链引用 `_rt_FullFrameBuffer` 的消费者**本轮门控关闭**（`object-effects.ts` 的 `ENABLE_CHAIN_FRAME_SNAPSHOT_CONSUMER = false`，§5.46）。`frame-capture.ts`（帧内快照：惰性建画布尺寸 RT + `FramebufferTexture` + `copyFramebufferToTexture`，语义 = WE 的 `_rt_FullFrameBuffer` / 场景 FBO）与 `composite-quad.ts`（末段把段渲染结果全屏恒等贴回默认 fb；开了 Glow 则改由 `glow-stage.apply(..., target)` 复用同一张 RT）是这条路径上新增的两个模块。
- **对象级效果链**：同一入口下多走两步 —— 解析每个对象的 `effects`（`shader/effect-chain.ts` 的 `resolveEffectChain`）→ `ObjectEffectStage`（`object-effects.ts`）编排：隔离对象进 `localScene` + 主场景放合成 quad，每帧 `renderIsolatedContents()`（内容 → 对象 RT）→ `stage.bindOutputs()` → 渲染主场景 → `stage.advance(time)`。无带效果对象时 stage 为 null，帧序退化为 `fn → update → render`。段渲染开启时帧序多两处：消费者段边界 `stage.onSegmentBoundary(id, 快照, 快照代号)`（同步选取，runner 仍由帧末 `advance` 推进）、`resize()` 时 `stage.notifyViewportResize()`（作废在途快照）。
- **粒子模拟不重写**：复用 wasm 的 `CpuParticleSim`（纯 CPU，无需 WebGPU）；renderer 只把 `sim.vertices()` 的**每粒子 16 浮点**（`[pos3,size,uv2,color3,alpha,rot3,vel3]`，见 `threejs-player.ts` 的 `PARTICLE_FLOATS_PER_INSTANCE`）画成 billboard。
- **相机视差**（2026-10-13）：装配时 `three-renderer.ts` 把 `scene.json` 的 `general.cameraparallax*` **原样**下发 `player.setParallax(desc.parallax)`（关闭态用 `enabled:false` 的配置表达、**从不传 null**），并把 `pointer-input.createPointerTracker()` 的归一化指针经 `assets.onFrame` **逐帧**交给 `player.setParallaxPointer`；窗口监听随实例装/卸（`teardown` 里 `pointer.dispose()`，§5.43）。插值语义与两个坑见 §5.47、机制局限见 §7.39。
- **web 壁纸的鼠标跟随**（2026-10-15，§5.48）：背景层 `pointer-events:none` ⇒ 壁纸 iframe 收不到 `mousemove`，故由 host 在 `/wallpapers/web` 的 `.html` 响应里内联注入 `pointer-shim.ts` 的 shim，client 侧 `background-layer.ts` 用 `pointer-post.ts` 把宿主的 `pointermove` 经 `postMessage` 直传给**可见**帧；iframe 内 shim 直接调用壁纸自己注册的 mouse handler。**与 scene 视差是两条互不相干的通路**（后者读 `cameraparallax*`/`parallaxDepth`，只作用于 three 场景）。
- **失败重试**：`wallpaper-controller.ts` 在 `render()` 返回 false 后用**新 canvas** 重试一次（防 WebGL 上下文污染），仍失败才落 preview。
- **puppet 骨骼模型与动画层**（2026-10-13）：`image` → `models/*.json` 的 `puppet` 字段 → `.mdl`（MDLV/MDLS/MDLA）→ `THREE.SkinnedMesh` + `Skeleton`（`puppet.ts`）；蒙皮矩阵交给 three 的 `bind()`（= `World(动画)·World(绑定)⁻¹`），MDLA 关键帧逐帧采样写回骨骼。逐帧推进在 `threejs-player.tickPuppets`：已播时长 `+= dt × rate`，帧号 = `(已播时长 × fps) % frameCount`（循环播）；动画选择走 scene.json 的 `animationlayers`（`scene-json.ts` 解析 → `addPuppet` 入参），**只应用第一条可见层**（`visible !== false`；`blend` 不参与混合），多条可见层告警一次；**字段缺失**退回「播动画表首个」= 改动前的行为（本机实测 34 张真实 `scene.json` 无一带该字段，按空层处理会静默关掉既有动画；**除 `frameCount <= 0`**：旧实现会采样帧 0，现直接不采样）。单个 puppet 采样失败**只丢该图层**：`try { dispose() } finally { delete }` 保证先释放再摘表（`dispose()` 只遍历表内图层 ⇒ 不摘表就再无释放点），dispose 抛错也不穿出帧循环（否则本帧 `render` 被跳过），不升级成整帧渲染失败。⚠️ **本机唯一 `.mdl` 是静态族**（无 MDLS/MDLA ⇒ `bones=0`/`anims=0`）⇒ **蒙皮与动画只有合成夹具覆盖**，真机只能验「静态网格出图」；段布局与动画层缺省口径见 §7.40。
- **渲染看护**（2026-10-13）：`render()` 的失败细化为结构化原因（`scene-json` / `no-visible-objects` / `context-lost` / `exception` = **硬失败**，`load-error` = **软失败**），经 `render-health.ts` 分级记忆：硬失败按壁纸落 `localStorage`（`we:renderfail:<id>`）、软失败仅会话内并在冷却后自动重试一次；面板「实时渲染」卡片显示状态并提供重试/清除；排查入口 `__wallpaperEngine.health()`。对渲染像素路径**零改动**（`e2e:compare` 零回归）。**本轮实测**（2026-10-14，最终修复轮复跑）：基准 = 分支起点 `7e30a9f`（= master 的 v0.7.0），壁纸 `2683211654`，dpr **1 与 2 都产出了可比截图**，`e2e:compare` 两档全部 `maxAbs=0`、「差≥2」像素 0（前后 PNG 的 SHA256 逐字节相同）。对拍归档在 `.superpowers/sdd/2026-10-13-scene-live-watchdog/t5-shots/{before,after}-dpr{1,2}.png` —— **本地归档、未入 git**（`.superpowers/` 与 `e2e/.out/` 都在 `.gitignore`）；重跑口径见 `TESTING.md` §2.9。⚠️ `e2e/.out/` 会被后续 e2e 运行覆盖（其中 `before-dpr1-out.png` / `before-dpr1-rt.png` 仍是 2026-09-30 另一轮的残留）⇒ 回查基准对拍请用上面的 `t5-shots/` 归档，不要依赖 `e2e/.out/`。
- **生命周期**：DSH 会在客户端 bundle 重建时**重新执行 bundle 并重挂载插件** —— 挂载必须幂等、必须有收尾（§5.43）。
- **唯一路径**：three.js 播放器是 scene 的**唯一**渲染路径。`wasm-renderer.ts` / `scene-renderer.ts` / `alignment.ts` / `scene-script.ts` / `shader/glsl-to-naga.ts` 与 Rust 侧 `wasm/src/render/**`、`wasm/shaders/` 已于 2026-09-22 整体删除（连带 `isThreeUse()` / `THREE_USE`）。

### 2.2 host / client / shared 分层

- `src/host/`：Node 侧（Cordis 插件）。`scanner.ts` 扫描目录 → `WallpaperInfo`；`steam-paths.ts` 目录探测（`/wallpapers/probe`）；`pkg-reader.ts` 解包 PKGV；`routes.ts` HTTP 路由（每次请求读实时目录，settings 热更新；对 web 壁纸的 HTML 注入指针 shim，见 §5.48）；`settings.ts` 插件设置（双路径，见 §5.34）；`data-dir.ts` / `scene-frame-store.ts`（数据目录与抓帧 PNG，见 §5.49）、`scene-media-probe.ts`（内嵌 MP4 探测）、`user-props.ts`（四类型用户属性聚合，见 §7.41）。
- `src/client/`：浏览器侧（esbuild → `dist/client.js`，external react 等 DSH 共享模块）。主路径：`index.ts`（bootstrap + `window.__wallpaperEngine` + 注册设置菜单）、`wallpaper-controller.ts`（选择/竞态/回退链）、`three-renderer.ts` + `threejs-player.ts`（渲染）、`object-effects.ts` + `object-range.ts` + `effect-runner.ts` + `effect-graph.ts`（对象级效果链）、`rt-render.ts`（「渲染进 RT」的唯一入口，透明清屏不变量落在这里）、`tex-loader.ts`（TEXV0005 解码）、`scene-json.ts` / `scene-graph.ts` / `visibility.ts`、`text-object.ts` + `text-script.ts` + `scene-script-vm.ts` + `scene-script-host.ts` + `scene-anim.ts` + `layer-state.ts` + `dynamic-mesh.ts`（text / 脚本 / 动态网格）、`glow-stage.ts`（应用级 Glow）、`bloom-stage.ts`（壁纸级 bloom，薄封装 GlowStage）、`audio-input.ts`（音效音量 / 播放模式）、`scene-fallback.ts` / `frame-export.ts`（降级链与首帧导出）、`rotation.ts` / `library-view.ts` / `local-store.ts`（轮播 / 壁纸库 / 本地存储）、`wallpaper-properties.ts` / `media-health.ts`（用户属性面板读写 / 视频解码失败提示）、`background-layer.ts` / `settings.ts` / `styles.ts` / `settings-section.tsx`。
- `src/shared/`：跨 host/client 的类型与**两端共用的常量/纯函数**（`types.ts` 的 `WallpaperInfo` / `SceneDescription` / `SceneObject` 等；`pointer-shim.ts` 的 shim 源码与 HTML 注入 —— host 侧要把它内联进响应、client 侧与测试要按同一契约断言，故不能放在任一侧）。
- `src/client/shader/`：WE shader 方言转译层（`effect-chain.ts` 解析、`shader-preprocessor.ts` 预处理、`uniform-binder.ts`、`we-headers.ts`）。

### 2.3 坐标与对象变换约定（**勿再翻转 / 勿漏乘**）

- **WE 场景系 = 左下原点、y 向上**；three 正交相机 = 中心原点、y 向上。映射：`three = we − viewport/2`，**y 不翻转**。历史事故：曾用 `vh/2 − oy`，导致非居中对象上下镜像。新代码不得引入 y 翻转或 `scale.y` 取负。
- **对象 model matrix = T·R·S**；其中 `angles` 是**弧度**（OWE `SceneNode.cpp:15`），旋转顺序 **R = Rz·Ry·Rx**（OWE `ParticleRuntime.cpp:25-28`）。
- 粒子世界坐标：`worldPos = objCenter + R(angles) · (scale ⊙ (emitterOrigin + local))`（`threejs-player.ts` 的 `PARTICLE_VERTEX_SHADER`）。
- 背景 mesh：`position / rotation / scale` 直接对应 T / R / S（three 的 `Object3D` 变换顺序本就是 T·R·S）。
- **视差**（`cameraparallax`）也是**对象 model 矩阵的平移**（相机不动）：`shift = depth ⊙ ((node − cam) + mouse) × amount`，`mouse = ((0.5−px)·W, (py−0.5)·H) × mouseInfluence`（`W/H` = 场景正交尺寸）。`depth` 全 0 或关视差的对象**不写** `position` —— 每帧无条件写会盖掉脚本对同一对象 `origin` 的写入（§7.39）。

## 3. 构建、测试与集成

### 3.1 常用命令

```bash
npm test                 # vitest run（node + jsdom 双环境；全量约 7s，基线为空）
npm run build            # tsc -p tsconfig.json → lib/（strict）
npm run build:wasm       # cd wasm && wasm-pack build --no-opt --target web --release --features cpu-sim → wasm/pkg/
npm run build:client     # esbuild → dist/client.js，并把 wasm/pkg/ 复制到 dist/static/
npm run e2e:colorblend   # 渲染 e2e：colorBlendMode 逐像素判据（零本机素材依赖，可上 CI）
npm run e2e:card         # 计算样式 e2e：通知卡片与代码块同底（需本机 DSH 的 app.asar，不可上 CI）
npm run e2e:hidpi        # 渲染 e2e：dpr=1/2 的挂载期 RT 尺寸断言（需本机 WE 壁纸库）
npm run e2e:textclock    # 渲染 e2e：text 时钟层（魔兽之门 1922570576）是否真的画在画面上（需本机素材）
npm run e2e:verify-v081  # 渲染 e2e：v0.8.1 三项像素判据（bloom / clearcolor / spritesheet；需本机素材）
npm run e2e:web-pointer  # 渲染 e2e：web 壁纸跟随鼠标（1184182304）真机像素级 A/B（需本机素材）
npm run e2e:compare      # A/B 截图逐像素对拍（零回归验收）
npx vitest run tests/xxx.test.ts --reporter=basic   # 跑单个文件
```

**铁律：改了 Rust 必须先 `build:wasm` 再 `build:client`** —— `build:client` 只把 `wasm/pkg/` 的现成产物复制到 `dist/static/`，顺序反了会复制旧 wasm；产物缺失时 `build:client` 直接报错。

### 3.2 集成到 DSH profile

- profile 用 **`link:` 符号链接**引用本包（在仓库根执行）：
  ```powershell
  dsh plugin --profile web add link:E:/code/dsh-use-wallpaper
  ```
  `dsh plugin` 会把本包追加进 `dsh.profile.bundles`（本包声明了 `dsh.bundle`），**不要**再手改 profile 的 `package.json` 或往 profile `cordis.patch.yml` 插条目（重复 insert 报 `duplicate loader entry id`）。`link:` 是符号链接而非快照复制，构建产物直接生效；若 `LinkType` 为空说明落成了实体副本，需手动复制产物。
- **client 侧改动（`dist/`）→ 自动热重载**：web 组合始终挂载 `@deepseek-ai/dsh-client-hmr`，host 半侧每 500ms stat 轮询各 client bundle（mtime/ctime/size），变化即 `clientModules.rebuilt(id)` 并经 SSE `/plugins/events` 推给浏览器，浏览器半侧**重新执行 bundle 并以全新状态重挂载插件**（旧 fiber 被 drain）⇒ 插件必须幂等挂载 + 正确收尾（§5.43）。
- **host 侧改动（`lib/`）→ 需重启 `dsh web`**：host 模块热重载在 dsh-base 里默认 disabled。
- **兜底**：HMR 未生效（SSE 断开 / 页面未打开 / 落成实体副本）时，把 `lib/`、`dist/` 复制进 profile 并重启 + 强刷。
- **设置位置**：DSH 0.1.7-alpha.1 起是 profile `cordis.patch.yml` 里条目 `dsh-wallpaper-engine` 的 `config`；≤0.1.6 是 `$DSH_HOME/settings.yaml`。**手工预置请写前者**（两版都读，见 §5.34）。
- `lib/` 与 `dist/` **纳入版本控制**（`.gitignore` 不含它们）；发布包 `files` = `lib` + `dist` + `cordis.patch.yml` ⇒ **提交与发布前两个产物都要是新的**。

### 3.3 验证手段

- **单测**：`tests/**/*.test.ts` 默认 node，`tests/dom/**` 走 jsdom（`vitest.config.ts`）；`scripts/known-failures.json` 是空的**新增失败**基线（CI 只对新增失败判红，见 §7.11）。
- **测试侧类型检查**：`npm run typecheck:tests`（= `scripts/check-known-type-errors.mjs`，跑 `tsconfig.tests.json`）把 `tests/**` 纳入 `tsc --noEmit` —— vitest 走 esbuild 不做类型检查，测试用字面量构造的接口改坏了本不会红。基线 `scripts/known-type-errors.json` 是 `(文件, TS 错误码)` 计数的**棘轮**（只增不放过），更新用 `--update`。⚠️ 两处已知盲区（别把它当全覆盖）：① `vi.fn()` / `Mock<any>` 造的桩**不受接口约束**（`mockReturnValue` 的实参不参与检查）⇒ 这类测试桩改坏接口不会红；② 同文件同码「计数守恒的位置互换」会漏判（指纹不含行号，也不含消息）。
- **全库解析回归**：`tests/verify-real-library.test.ts`（全库 scene.pkg 的 scene.json / image 纹理 / particle 规格 / 效果链解析零失败）。**依赖本机壁纸库**，无库时 `skipIf` 跳过并告警 —— CI 上等于不跑。
- **端到端渲染（推荐）**：`e2e/`（自起 http server + headless Edge（自己 `spawn` + 手写裸 CDP，**不依赖 playwright**）+ esbuild 打包 harness，**用生产 `lib/`** 渲染真实素材并逐像素判定，**不依赖 DSH token**）。机器相关项一律走 `e2e/config.mjs`；判据失败**置非零退出码**（是 CI 门禁，不是日志）。
- **零回归对拍**：`npm run e2e:hidpi -- --tag=before` → 改动 → `--tag=after` → `npm run e2e:compare`。判据：最大差 ≤ 1 且「差≥2」像素为 0。
- **CI**：`.github/workflows/ci.yml`（tsc + `lib/`/`dist/client.js` 产物新鲜度守卫 / tests 侧类型检查棘轮 / vitest 新增失败 / Windows 渲染 e2e）。已知失败基线在 `scripts/known-failures.json`，类型错误基线在 `scripts/known-type-errors.json`。CI 的三个历史坑（动作运行时 Node24、runner 的 Edge、`pnpm-workspace.yaml` 需 `packages` 字段）与排查过程见 `docs/fixes/verification-ci-history.md`。
- **测试环境**：vitest / esbuild / headless Edge 都依赖 service 子进程，**受限沙箱下会失败**（见 §5.13）。

## 4. 目录

```
<repo root>                  # 仓库根即插件包（不是 monorepo）
  src/{host,client,shared}/  源码（client/shader/ 为 WE shader 方言层）
  wasm/                      Rust 引擎（wasm-bindgen；**只剩 CPU 粒子模拟**）
    src/{lib.rs,coords.rs,particle/}
    pkg/                     构建产物（gitignore；由 build:client 复制进 dist/static/）
    tests/                   Rust native 测试（cargo test，无需 wasm 目标）
  lib/                       tsc 产物（**入库**）
  dist/                      esbuild 产物 + dist/static/（wasm；**入库**）
  tests/                     单测；tests/dom/ 走 jsdom；tests/fixtures/ 真实素材 fixture
  e2e/                       端到端渲染验证（入库）：config.mjs 统一参数
    lib/ harness/ verify/    像素工具 / esbuild harness 入口 / 验收脚本
    fixtures/                零素材依赖的 fixture（clouds-dxt1.png）
    .out/                    运行产物（gitignore）
  scripts/                   build-client.mjs / check-known-failures.mjs / known-failures.json / check-known-type-errors.mjs / known-type-errors.json
  tsconfig.tests.json        tests 侧类型检查（noEmit + rootDir "."；门禁 1d 用）
  .github/workflows/ci.yml   CI：tsc + 产物新鲜度 / tests 类型棘轮 / vitest 新增失败 / Windows 渲染 e2e
docs/superpowers/
  specs/                     设计文档（改动前必读）
  plans/                     实施计划与修复记录
docs/fixes/                  历史归档（§5/§7 的明细与已修记录，见 §8）
research/                    gitignore：截图 / 一次性探针 / 临时 profile（权威 e2e 已移入 e2e/）
  open-wallpaper-engine/     C++ 参考实现（语义对齐来源）
  .lwe/                      linux-wallpaperengine 源码（另一参考）
```

## 5. 硬约束（踩过的坑）

> 编号沿用历史（代码注释按 §5.x 引用，勿重排；§5.35 为空号）。每条只给结论与判据，**实测数据、推导与历史事故全文见 `docs/fixes/conventions-details.md` 的对应小节**。

1. **wasm 产物必须 `--target web`**：曾用 `--target module`（无默认导出 `__wbg_init`）导致 wasm 静默失败、一路回退。
2. **`research/`、`wasm/pkg/`、`dist/static/ptex-*.tex` 是 gitignore**；`lib/`、`dist/` 其余部分**必须提交**（见 §3.2）。
3. **对象 `angles`（弧度）必须应用**，否则局部朝向被当世界朝向。三个应用点：粒子顶点 shader、背景 `mesh.rotation`、util/text（字段解析保留，暂不做几何变换）。
4. **`turbulentvelocityrandom` = `forward` 绕 `normal` 旋转**（不是「沿 normal 偏移」）：方向恒在垂直 normal 的平面内。旧实现写成 `forward*cosθ + normal*sinθ*scale` ⇒ 速度进屏幕上不可见的 z 轴、粒子排成竖线（影响 9 张壁纸）。
5. **对象级 `instanceoverride`**（scene.json → 粒子）：`alpha/size/lifetime/speed` 是**乘数**，`color/colorn` 是**覆盖**（`UiColorToLinear` = v²，legacy `color` 先 /255），emitter rate **× `count`**；缺省恒等。JS 只解 `{user|script,value}` 编辑器包装，数值语义仍在 Rust。
6. **图像 `colorBlendMode`（→ shader combo `BLENDMODE`）不是 alpha 混合**，而是**额外追加一遍「读当前帧缓冲」的混合 pass**（WE 材质 `materials/util/effectpassthrough.json` / shader `genericimage3`；模式表在 WE 明文 `assets/shaders/common_blending.h`）。three 侧用**预乘片元** + `CustomBlending` 复刻；**未实现的模式回退普通 alpha 混合**（不静默画错）。全库非零的只有 3 个对象：`3743126786`=7、`2832263418`=6、`2460786246`=31。合成侧的三个约束见 §5.25/§5.26。
7. **粒子 alpha 属性链**：透明度 = 生命周期衰减 × alpha（`alpharandom` 等经属性链传入），JS ShaderMaterial 与 wasm 粒子层**双路径同语义**；改 alpha 相关逻辑要双路径验证。
8. **场景资源禁止浏览器缓存**：`/wallpapers/scene/<id>/asset` 返回 `Cache-Control: no-store`，改资源无需清缓存。
9. （**已作废**）wasm 效果链的 GLSL→SPIR-V→WGSL 卡点：整条链路与依赖**已随未接入的 WebGPU 渲染器删除**，主路径效果链走 three 的 GLSL 路径，与本条无关。
10. （**已作废**）对象级效果链管线的 **wasm 备用路径**（`wasm/src/render/**`）已随 §2.1 的删除一并移除；`OBJECT_RT_MAX = 4096` 这条事实已并入 §5.15/§5.21。现存唯一路径见 §2.1。
11. **效果链的一切编译/建管线必须在加载时一次性完成**（`resolveEffectChain` / `EffectRunner` 创建 / 探针编译）；`render_frame` / `render_object_effects` / `step` / `bindOutputs` / `advance` **不得**在帧内做编译或建管线（每帧只写 uniform + 建 bind group + 提交 pass）。
12. **音频管线**：`createAudioAnalyzer` 频谱 → EffectRunner 音频 uniform + visualizer 条高；壁纸 `sound` 数组经 `playWallpaperSound` 接入（autoplay 被拦时 context suspended、可视化全零，用户手势后恢复）；无 Web Audio → 全零静音；切壁纸必须 `context.close()`。
13. **测试沙箱**：vitest / esbuild 依赖 service 子进程（命名管道），受限沙箱下报 `spawn EPERM`；同一条限制也让 **headless Edge 起不来**（mojo 平台通道 `拒绝访问`）⇒ **单测与端到端验收都必须完整权限**（别误判成 flag 或 Edge 装坏了）。
14. **WE 内置纹理走 host 路由，不随包分发**：粒子/效果材质引用的 `particle/*`、`util/*` 等是 WE 的第三方素材，client 请求 `/wallpapers/particle-texture?name=<相对 assets/materials 的路径>`（可带 `id`），host **先在壁纸 `scene.pkg` 的 `materials/<name>.tex` 找、再回退 `<weAssetsDir>/assets/materials`**（顺序对齐 WE 挂载顺序）。`name` 是原始相对路径，**不能无条件加 `particle/` 前缀**；`util/*` 效果纹理也走同一路由（**不得**把 `util/noise` 与 `util/clouds_256` 映射成同一张程序化噪声）。普通 scene 素材（`fonts/*.ttf` 等）同样「pkg → 引擎 assets」两级查找。
15. **对象级 RT 的三条不变量**：① **局部正交相机的 left/right/top/bottom 是「世界坐标范围」**，必须覆盖**完整对象世界尺寸**（拿 RT 像素当范围 ⇒ HiDPI 下对象缩小 + 边缘 clamp 拉伸；按 4096 钳制范围 ⇒ 边缘拉伸带，超限对象的正确代价是「分辨率低」而非几何裁剪）；② **RT 像素尺寸 ≥ 屏占位**（**屏占位 = |未钳制世界尺寸| × 屏幕密度**，是**尺寸对**；目标长边 = `max(屏占位长边, min(源纹理长边, 4096))`，**软预算 `budgetScale` 可把它压到两者之间**，见 §7.36①；单一等比收口 4096、**只升不降**；源纹理长边比屏占位长边小的对象保持屏占位，粒子 / 源尺寸未知的对象走 `object-range.objectRtSize` 的屏占位口径，见 `object-range.isolatedRtSize`）—— 密度 = 画布缓冲宽 / cover 视锥宽（`object-range.screenScalePx`），**mount 与 resize 必须同源**，基准必须是**未钳制**的世界尺寸；③ **`isolate` 的键是 `scene.json` 的对象 id**（不是图层计数器），`isolatedObjects()` / `setObjectOutput()` / `resizeObjectRT()` 同一把键。
16. **效果纹理槽编号 + sampler `combo` 派生**：**`textures[i] → g_Texture(i)`**（不是 `i+1`）；sampler 声明带 `"combo":"X"` 时，该槽被绑定即置 `X = 1`（`scene.json` 的 `pass.combos` 显式值优先，必须在 `preprocessWeShader` **之前**）。两者写错会让**所有效果的纹理槽整体错位**或 mask 分支永不启用（效果全图生效）。
17. **`g_TextureNResolution` 四分量一律同值 = 各分支实际上传尺寸**（视频 `videoWidth/Height`（0 时回退 mip0 记录）、编码图像解码尺寸、raw 裁剪尺寸、DXT `ceil4` 尺寸；由 `tex-loader.ts` 的 `withSprite` 唯一写入 `tex.userData.fxRes`）；效果 shader 用 `.z/.x` 缩放遮罩 UV ⇒ 该比值**恒为 1**。插件**不按 `.tex` 头做 padding 分配**，故**填头里的分配尺寸**会让 NPOT 纹理的遮罩按 分配/内容 挤向画面左上（真机：湖水波动跑到树上）。⚠️ **真实残留**：`fxRes` **无法表达「内容域偏移」**（WE 的 `(内容宽,内容高,打包宽,打包高)` 语义，见 `mesh-shaders.ts:26-32`）——本实现每分支只报一个 `(w,h)` 对，故 `cropToMap` 对 `flags & 4`（sprite）刻意不裁（`tex-loader.ts:285`）也满足该不变量。细节与实测见 `docs/fixes/conventions-details.md` §5.17。
18. **R8 / RG88 有两套通道语义，不能混用**（`convertUnormToRgba(data, format, alphaPriority)`）：缺省 `true` = **粒子纹理**语义（形状/覆盖在 R 或 G 通道）；`false` = **效果纹理槽**语义（shader 直接读 `.r`/`.rg` 当遮罩数值）。**待办**：权威来源应是 `.tex` 头的 `TextureFlags_AlphaChannelPriority`（bit19），现由调用方路径推断。
19. **`.tex` 的 flags 必须被消费**：`ClampUVs = 2`（bit1）→ WE 默认 **REPEAT**、仅带此位才 CLAMP（曾一律 clamp ⇒ `clouds` 整屏偏白且越来越白）；**待办**：`NoInterpolation = 1`（bit0）应 `NearestFilter`、`ClampUVsBorder = 8`（bit3）语义未验证。⚠️ **RT 纹理必须保持 CLAMP**（别在别处一律改成 repeat）。
20. **纹理 v 轴约定**：WE 是 `v=0` = 图像顶部；显示路径翻行序后画面正确但**效果 shader 里的 v 语义与 WE 相反**（带符号方向量整体反向）。修法是**窄修**：只在效果链一侧按 WE 约定加载（`rowOrder` + 注入 topDown 加载器），并用「隔离局部相机 y 镜像 + 合成 quad `flipGeometryUvY`」抵消 —— **不要做全量迁移**（要改 4~8 个显示采样点，漏一处就是整图上下颠倒）。
21. **对象 RT 的尺寸口径 = 屏占位**（详见 §5.15 ②）：旧口径把「预算」当基准，与屏占位差 0.8% ⇒ 合成那一步的双线性 + 亚纹素漂移让**整层锐度 −52%**（实测 Laplacian 713 → 342）。密度必须与主相机 cover 同源、mount 与 resize 同源。
22. **渲染进 RenderTarget 缺省必须「透明清屏」（clearAlpha = 0）**：three 的清屏 alpha 由 `WebGLRenderer({alpha})` 决定，主路径 `alpha` 缺省 false ⇒ **每个 RT 都被清成不透明黑**，效果降 alpha 处（opacity/mask）贴回主场景就是整片黑块（`2911105183` 实测黑像素 31.1% → 0.7%）。落点是 `src/client/rt-render.ts` 的唯一入口。**刻意不改 renderer 的 `alpha` 参数**（那是另一种可见行为变更）。**例外（v0.8.1）**：Glow / bloom 的 **baseRT 自渲**（含 `glowFailed` 回退写下游 `outTarget`）必须传 `preserveClearAlpha`、保留 renderer 当前 clear alpha —— 它清的是整屏背景色，强制 0 会被 `premultipliedAlpha` 把 RGB 乘成 0（默认 Glow 下 `general.clearcolor` 丢失）；**对象隔离 RT 仍走缺省透明清屏**（不变量不变）。
23. **WE 视频纹理（`flags` bit5 = Video）**：`.tex` 的 mip0 载荷是完整 mp4，交浏览器原生解码（`tex-loader.videoTextureFromMp4`，必须排在编码图像与原始像素两条分支**之前**）；判定要 `flags & 32` **且** mip0 前 8 字节是 mp4 的第一个 box。约束：**静音自动播放**、**不进 mip 链**（`generateMipmaps=false`）、**生命周期不归 GPU 管**（清理挂在纹理 `dispose` 事件上：pause + 清 `src` + `revokeObjectURL`）。不可播时返回 **1×1 透明纹理** + 可辨识 `console.warn`（不是 null）。
24. **uniform 注解里的嵌套对象必须完整解析**：非贪婪 `\{[\s\S]*?\}` 遇到内层 `}`（WE 注解普遍带 `"require":{...}`）会截断 ⇒ 注解整体丢失 ⇒ uniform 全零（`3303428996` 整屏黑）。要抓到行尾再用 `takeBalancedJson` 配对花括号。
25. **效果 pass 的 `blending: "normal"` = 覆盖（`ONE/ZERO`）**，不是 alpha 混合（lwe `CPass.cpp::setupRenderFramebuffer`）：`Normal`/未知 → `NoBlending`，`Additive` → Additive，`Translucent` → Normal。写成 three 的 `NormalBlending` 会让 rgb 每过一个 pass 再乘一次自身 alpha ⇒ 半透明图层逐级趋零（GTR 云消失）。
26. **`colorBlendMode ∈ {6,7,31}` 的合成 quad 必须把图层 alpha 预乘进 rgb**：`colorBlendMode` 语义是 `mix(A, Blend(A,B), opacity)`，而 Screen(7)/31/6 的颜色因子**都不看 alpha** ⇒ 不预乘就是全强度盖住画面（GTR「云挡住人物」）。内容侧已改普通 alpha 写入（混合语义整体移到合成 quad）。
27. **GTR 云亮度 vs 桌面 WE 的差异来自「应用级后处理」**（WE `config.json` 的 `general.user.postprocessing`，作用于整帧、不属于任何壁纸字段）—— 插件**已实现**（`glow-stage.ts`，缺省 `0.65/0.35`）且只覆盖 **scene** 壁纸。⚠️ 壁纸级 `general.bloom`（全库 3 张）**v0.8.1 起已实现**（边界见 §7.42 ③）。
28. **具名 RT 图链的执行语义（P2）**：加载期由 `buildEffectPlan`（`effect-graph.ts`）编译成静态计划，`EffectRunner.setPlan` 建**具名 RT 池**；帧内只查表绑槽 + 提交 pass。要点：`bind.index` = `g_Texture<index>` 且 `bind` 优先于 `textures`；**`previous` = 进入 target 序列前的输入**（不是上一 pass 输出）；具名 RT = 对象 RT ÷ `fbos.scale`，**池作用域 = 单条链**；**写具名 RT 的 pass 编译失败 ⇒ 整条计划放弃**（回退对象 RT 原图）；引用链内不存在的 `_rt_*` 保持默认不绑白纹 + 去重告警；effect 级 `visible === false` 整条不挂链（作者正常内容，不打降级告警）。
29. **combo 宏必须跨 stage 合并**（`effect-chain.ts` 在两次 `preprocessWeShader` **之前**合并 vert/frag 两侧的 `[COMBO]` 默认值）：一侧从默认值取到 `NOISE 1`、另一侧被 `#if` 裸标识符兜底成 `0` ⇒ frag 引用 vert 未声明的 varying ⇒ **program 链接失败**（链接错误不在 shader info log 里）。**不要只特判某个宏**。
30. **web 壁纸 iframe 必须「与自身资源同源 + 与宿主跨源」**：`sandbox="allow-scripts"`（无 `allow-same-origin`）是 opaque origin，壁纸**自己的** img/video 也算跨源 ⇒ WebGL `texImage2D` 抛 SecurityError、画面空白。承载 origin 优先级（`planWebFrameOrigin`）：**桌面壳公布的宿主 HTTP origin**（`globalThis.__DSH_TRANSPORT__.streamBaseUrl`，不探活）→ **回环页换另一回环主机名 + 探活** → 其余退回 opaque origin 兜底。
31. **`project.json` 的 `type` 大小写不定**（实测 `"Web"`/`"Scene"`）：`kindFromProjectJson` 必须 `trim().toLowerCase()` 再比较，否则掉进 `unknown`、只剩 preview 图兜底（`3778198228` 被放大 10 倍的根因）。**v0.9 起识别 WE 预设壁纸**（无 `type`/`file`、只有 `dependency` + `preset` + `preview`）：`kindFromProjectJson` 返回 `'preset'`、`WallpaperInfo.presetOf` 记依赖 id、`hasScene` 取依赖目录；`routes` 的 scene 资源、properties 与音频标记统一经 `sceneResourceDir` 解析到依赖目录，属性默认值再按 preset 同名键覆盖（`applyPresetDefaults`）；`resolveBackground` 将 preset 按 scene 渲染（**渲染键仍是 preset 自身 id**，preview 仍取自身，属性 localStorage 也按 preset id 隔离）。
32. **应用级 Glow 的颜色空间在本仓库是「字节域恒等」⇒ 链内不做任何转换**：`threejs-player` 强制 `outputColorSpace = LinearSRGBColorSpace`，且全库纹理未标 `colorSpace` ⇒ 全链路字节域恒等；按 spec 原设计插 `toSrgb()` 就是**二次编码**（阈值语义整体偏移，表现为「几乎不发光」而不报错）。**先确认 `outputColorSpace` 与纹理 `colorSpace` 的实际取值，再决定要不要手工对齐。**
33. **纹理槽必须在探针渲染前预建进 `material.uniforms`**：`uniformsList` 只在换 program 时重算，而 1×1 编译探针会先把 program 定下来 ⇒ 探针之后补的条目**永不上传**（`godrays_combine` 整屏近黑的根因）。槽数 = `max(textures.length, g_TextureN 最大下标 + 1)`，声明来源 = `samplerNames ∪ samplerModes`。
34. **DSH 设置系统双路径**（兼容 ≤0.1.6 与 ≥0.1.7-alpha.1）：新版命名空间 = **profile 条目 id**（`dsh-wallpaper-engine`）、`Config` 必须挂在默认导出 `apply` 上、volatile 值要用 `config.get()` 解引用且**不得在 `apply` 里快照**；**不得静态 import `dsh-settings`**（`settingsNamespace` 已不在导出里 ⇒ 链接期 SyntaxError）；`.volatile()` 需 `schemastery ≥3.18.4`。client 侧按候选 ns 探测并记住命中项。
36. **右侧栏「常驻遮罩」是 0.1.7 改了收起方式**：半透明底规则必须加 `[data-sidebar-right-open]` 限定**并** `:not([data-sidebar-right-panel="fullscreen"])`，fullscreen 的底与 `z-index:15` 也要带 open 限定，且 **z-index 必须写 `:where()` 低具体度**（否则压掉旧版 DSH 自己的 40）。**底与 z-index 拆成两条规则、两种具体度。** jsdom 的 `:where()` 具体度不可信，要真机验证。
37. **浮层菜单的底要覆盖两个 token**：0.1.7 的 `--dsw-specific-menu` 与 rc.2 起 `MenuSurface` 实际读的 `--dsw-menu-surface-fill`（旧 token 在新版只是别名）—— **两个都要覆盖**（浅 `.92` / 深 `.94`，保留 DSH 的 backdrop-filter）。通用教训：DSH 把某类浮层的底从 token A 迁到 token B 时，可读性覆盖必须同时覆盖两个。
38. **可见性只有一张装配期 effective 表**：`computeEffectiveVisibility` 一次算出「自身绑定（含 condition）&& 父链」，text/image/particle/util 的过滤点共用同一张 `effectiveVisible`（随 `SceneAssets` 下发）；`script` 绑定在装载期恒不隐藏，交给 `visible.script` 的运行时通道。`isStaticallyHidden` 是表内的单绑定判定，`resolveVisibility` 现仅单测使用。混用旧接口会让脚本控制的图层在装载期被永久剔掉。
39. **设置面板的 DOM 钩子与样式断言被测试锁定**（`tests/dom/settings-section.dom.test.tsx` + `tests/styles.test.ts`）：重排结构时必须保留 `.wss-thumb` / `.wss-thumb-title`（textContent 精确等于壁纸名）/ `.wss-cancel` / `.wss-refresh` / `.wss-probe` / `.wss-save-dirs` / `.wss-adopt[data-path]` / `.wss-candidate[data-kind]` / `.wss-dir-*` / `.wss-glow-*` / `.wss-quality` / `.wss-sound`（**不能**并进 `.wss-power`，后者恰好 2 个复选框）/ 首个 `.wss-glow-row` 文本为「光晕（立即生效）」，以及样式侧 `var(--dsw-alias-label-primary` / `var(--dsw-alias-border-l2` 的存在。
40. **web 壁纸 iframe 必须「先挂载 + 强制布局，再赋 `src`」**：跨源子帧是 OOPIF，未挂载时冷启动读到的视口是 **0**；而部分壁纸把 `innerWidth/Height` **快照**成画布尺寸 ⇒ 画面永远 0×0，只有 resize 重建 iframe 才显示。`appendWebFrame` 的顺序（appendChild → `getBoundingClientRect()` → `src`）**即修复本身，勿调换**。
41. **贴壁纸文字颜色可手动配置 + 可选描边**（`auto/white/black/custom` + 0–3 档）：手动档**跳过 preview 测光**直接下发；auto 档按**壁纸 id 缓存**最近一次测光结果（设置变更同步复用、`select` 强制重测）。⚠️ `text-shadow` **可继承**，实底区域（气泡 / 卡片 / 行内 code）必须显式 `text-shadow:none` 复位。
42. **通知卡片与代码块在深色主题下不同底**：DSH 的卡片底 token 在深色取 8% 白半透明 ⇒ 透出壁纸后与代码块不一致。修法：浅/深分支各把 `--dsw-alias-turn-trigger-bg(-hover)` 覆盖为 `var(--dsw-alias-markdown-code-block)`，卡内文字按实底口径复位；⚠️ token 覆盖必须写进**浅/深分支**（具体度），卡内文字复位必须带 `[class*="flowItem"]` 前缀（否则压不过消息列反色规则）。
43. **插件被重挂载（client-hmr 的 `rebuilt`）后必须只剩一份背景层**：旧 fiber 被 drain 后旧 DOM 不会被自动移除 ⇒ 每次重载叠一份 `.wp-background-layer`，两层 `z-index` 同为 0、DOM 序在后的**最老实例压在最上面**且再也不会收到 select（真机层数 9 ⇒ 「切壁纸怎么点都不换」）。约束：**凡是「插入 DOM / 起循环 / 开上下文」的挂载点都要同时具备幂等与收尾**（`ctx.effect` 收尾 + `mount()` 单例清理 + `window.__wpEngineTeardown` 跨模块实例交接）。

44. **满屏隔离对象关 MSAA（结构性无效）+ RT 纹理的采样参数必须 `dispose()` 才下发**：① 满屏背景隔离对象的 RT 内只有一张盖满的 quad、没有轮廓边 ⇒ `samples=0` 与 `4` **逐像素相同（MAD=0.0000）**，关掉它把省下的显存换成分辨率；非满屏对象（贴片 / 粒子 billboard）保留 `4`（有真实几何边，一个都不能被关）；② **RT 纹理的采样参数只在 `setupRenderTarget`（首次使用或 `dispose()` 之后）下发**，`texture.needsUpdate` 对 RT 纹理**无效** ⇒ 采样判定翻转（mipmap 开 / 关）时必须 `rt.dispose()`，否则新的 `minFilter` 到不了 GL，且 `generateMipmaps=true` 会**每帧白生成 mip**。A/B 实测表与 three 源码行号见 `docs/fixes/conventions-details.md` §5.44。

45. **段渲染与帧内快照的四条不变量（+ 成本量级与门控）**（2026-10-13，`frame-capture.ts` / `composite-quad.ts`；明细与偏差见 `docs/fixes/conventions-details.md` §5.46 与设计文档的执行附录）：
    - **无消费者 ⇒ 帧序与本文档之前逐字节一致**：`render()` 只在 `frameCapture.active` 时改走 `renderSegmented()`，否则不建段目标、不切段、不合成（结构性零回归，靠既有渲染断言网 + 单测钉住）。
    - **每段一次全场景 `render`**：段渲染是「按 `renderOrder` 切段、每段调一次 `renderer.render(scene, camera)`，靠 `visible` 排除其它段」，不是「每对象只光栅化一次」⇒ **成本 O(段数 × 场景)**。实测 `2897292240`（2 个粒子消费者）每帧 **3 次全场景 render + 2 次 `copyFramebufferToTexture` blit + 1 次 composite 合成**（改动前 1 次 render）；实测数字与「半分辨率 `frameRT`」优化项见设计文档附录 A.4 ⑦。
    - **`autoClear` 只在段内 `try/finally` 临时关闭并在 `finally` 恢复**（连带 `clearColor` / `clearAlpha` / `renderTarget`）—— `rt-render.ts` 的调用点依赖它清屏；只有首段之前对整个段目标清屏一次，其余段累积。
    - **每段只让本段对象可见，`finally` 里按原值恢复**（透明混合是累积的，留可见会被再画一遍 ⇒ 重复叠加）；`visible` 原本为 false 的对象不得被段逻辑改成 true。
    - **快照拍在消费者被绘制之前且逐帧覆盖**：快照语义 = 「到这一刻为止已渲染进段目标的内容」（= WE 场景 FBO / `_rt_FullFrameBuffer`）；每个消费者边界恰好 `capture()` 一次（无幂等性），消费者**不得跨帧持有**该纹理引用。resize 会 `dispose` + 重建快照 ⇒ 排队的异步消费方在**执行当刻**读 `ObjectEffectHost.frameSnapshotVersion()` 的实时值、与**捕获当刻**记录的代号比较，不一致即按「无快照」走；`player.resize()` 另通知 `notifyViewportResize()` 作废尚未被 `advance` 消费的那份。判据只认「真的换代」⇒ 只是排到下一帧执行的 runner 不被误伤；`runner.update` 内 `await resolveTextureSlot(...)` 期间仍有极低频窗口（设计文档附录 A.4 ⑥）。

46. **`_rt_FullFrameBuffer` 的语义与当前消费点**：`_rt_FullFrameBuffer` = 「到该对象被绘制那一刻为止，本帧已绘制的内容」= WE 的场景 FBO（lwe `CScene.cpp:351-361` 按 `m_objectsByRenderOrder` 逐个 render、`CParticle.cpp:2069-2079` 在画粒子层**之前** blit）。本轮实现：段边界 `copyFramebufferToTexture` 快照，**当前唯一启用的消费点 = 粒子 `REFRACT`**（顶点切线基 + 片元 `genericparticle.frag:103-116` 位移采样）。⚠️ **效果链消费点本轮门控关闭**（`object-effects.ts` 的 `ENABLE_CHAIN_FRAME_SNAPSHOT_CONSUMER = false`，按 R6 降级）：对象链的贴屏 quad UV 覆盖**对象窗口**、快照却是**整画布**（v 约定还反向一次）⇒ 该路径从未真机验收、直采会错位，启用前须先解决映射（设计文档附录 A.4 ⑧）；关闭时引用该槽的效果链行为 = 改动前（该槽**留空** + 每槽去重告警）。能力（`resolveBuiltinTexture(path, frameTexture?)` / `planSamplesFrameSnapshot` / `slotBoundByBind` / `onSegmentBoundary` 宿主契约）与单测**保留**。本轮只做这一个名字：其它 `_rt_*`（含 `_rt_imageLayerComposite_*`）分两条路径 —— **直接调 `resolveBuiltinTexture`** 的仍回退 1×1 白纹（只有 `_rt_FullFrameBuffer` 那一条会打一次模块级告警）；**效果链 runner 路径**对一切未声明的 `_rt_*` 一律**槽留空 + 每槽去重告警**（`resolveSlotFallback` 返回 null），不绑白纹（§7.31 / §7.38）。

47. **视差的 `delay` 必须按「每帧重置滞后时钟」实现**（`parallax.ts` 的 `advancePointer`）：OWE 每帧先 `SetPointerInput`（滞后时钟减去已流逝时间）再 `Advance`（加回同一个 `frame.delta`），两者同帧抵消 ⇒ 字面累积只会让 `elapsed` 停在**历史最大帧长**；本播放器 dt 被 clamp 到 **0.1s**，而本机唯一开视差壁纸的 `cameraparallaxdelay` 恰好 **0.1** ⇒ 一次长帧（切走标签页再切回）就把它永久打成「完全跟手」。故取 `min(dt, delay)`：稳态比例与 OWE 相同、无历史残留。**判据** = `tests/parallax.test.ts` 的「滞后时钟封顶到 delay」「delay>0：每帧按 min(dt,delay)/delay 靠近」两条（变异实测会红）。

48. **web 壁纸的「跟随鼠标」靠宿主直传指针，不改 `pointer-events`**（2026-10-15）：背景层的 `pointer-events:none`（`styles.ts:3`，背景不得吃 GUI 的点击）意味着壁纸 iframe **永远收不到** `mousemove`，而 web 壁纸普遍把视差绑在**自己 window 的 `mousemove`** 上（实测样本 `1184182304` 的 `jquery.parallax`）⇒ 这类壁纸在插件里恒为静态。链路：宿主 `pointermove`（capture/passive，仅 web 帧存活期间挂）→ 按 iframe 盒子算 `nx/ny` + 真实 `clientX/Y` → `postMessage({__wpPointer:1,…})` → iframe 内 shim（`/wallpapers/web` 对 `.html` **内联注入**，`src/shared/pointer-shim.ts`）**直接调用**它记录的 mouse handler（不经 DOM 派发 —— `pointer-events:none` 下正是不存在可派发目标）。
    - shim 只保留**最后一个** mouse 类监听（单个 handler 无法重复注册）；真实用法（一个 `window.mousemove`）落在此契约内，单测逐条钉住。
    - 注入必须插在壁纸自带脚本**之前**（`<head>` 后；无 `<head>` 退 `<html>` 后、无锚点即返回 null 原样返回）；⚠️ 内联脚本在 `document.write` 期间会**静默不执行**，故 `__WE_*` 初始化存在时不得走内联路径（本仓无此路径）。
    - 坐标优先用宿主按 iframe 盒子换算的 `px/py`（避开屏幕坐标/`object-fit`/缩放折算链），越界或缺失时回退 `nx/ny × iframe 自身视口`（桌面壳的宿主视口可大于 iframe 视口，此时只有归一化值正确）。
    - 只合成 mouse 事件，不合成 wheel/click/键盘；iframe 重建（resize）后指针监听必须跟着**可见帧**重挂并作废旧 token。
    - 判据：`tests/pointer-shim.test.ts`（真实 `jquery.parallax` 夹具：raw 零位移 / shim 位移跟随 / `removeEventListener` 语义不被 patch 破坏）+ `tests/web-route-shim.test.ts`（真实路由注入、非 HTML 逐字节不变）+ `npm run e2e:web-pointer`（真机像素级 A/B，raw 零位移对 shim 位移 > 20px）。

49. **v0.8 数据目录契约（抓帧缓存，2026-10-19）**：数据根 = `DSH_USE_WALLPAPER_DATA_DIR`（`trim` 后非空）否则 `~/.dsh-use-wallpaper`；抓帧目录 = `<数据根>/frames`（`data-dir.ts` 唯一入口，`routes.ts` 注入）。
    - 帧文件 `<id>.png` **原子写**（同目录 tmp + `rename`），GET 不会读到半截 PNG；id 走 `/^[A-Za-z0-9._-]+$/` 且禁 `..`，防路径穿越。
    - 限额：单张 ≤ **12MB**（超限 413，非 PNG 头 400），目录 ≤ **200 张**，超出按 mtime 淘汰最旧；淘汰/清理失败不影响本次写入。
    - **2xx** 的帧响应与探测响应带 **`Cache-Control: no-store`**（GET/HEAD 命中帧、`video-probe` 200、`embedded-video` 命中 200）；4xx/5xx 走 `json()`，不带该头。帧缓存是派生数据，删掉只会让下次 scene 成功渲染时重抓（`frameCacheEnabled` 控制）。
    - 写入只发生在 scene **首帧成功**后（`onSceneLive` → `ensureSceneFrame`），失败只 `warn`，不影响渲染与降级链。
    - 决策理由与放弃的备选见 [v0.8 降级链、轮播池、属性范围与抓帧落盘](.agents/notes/implemented/architecture/2026-10-19-v08-degradation-rotation-and-properties.md)。

## 6. 工作约定

- 回复、注释、文档、**提交信息一律简体中文**；代码、命令、文件名、技术术语保留原文。
- 提交信息**从简**：标题一行 `type(scope): 中文标题`；正文可选，**最多 3 行**（改了什么 / 关键根因一句话 / 怎么验证）。**不贴实验数据、不复述推理、不列文件清单** —— 细节写进本文件与 `docs/`。
- **注释从简**：默认只写一行「是什么 / 为什么」，最多 2 行。**禁止**复述代码、罗列实验数据、贴多段推理。根因与实测数字写进本文件或 `docs/`；代码里只留**一句结论 + `AGENT.md §x.y` 指针**。例外：涉及「不改就会踩回去」的硬约束（坐标 / 行序 / 混合因子）可留 2-3 行，但仍要指向 §5。
- **壁纸目录只读（用户明令）**：Steam 工坊目录里是**用户自己的作品**，**不得修改其中任何文件**（含 CSS/JS/HTML）。发现壁纸侧缺陷（资源 404、脚本报错、文档溢出等）**只记录 + 报告**，由用户在创作源里改；修复只能落在**插件侧**。
- 实施前读 `docs/superpowers/specs/` 对应设计文档；重大变更走技能流程（brainstorming → 设计文档 → writing-plans → TDD）。
- 渲染 / 坐标 / 粒子 / 材质语义的改动：先写失败测试，改完跑相关 vitest + 必要时用 §3.3 的端到端渲染验证，最后把结论与遗留如实写进本文件。
- **如实标注**：能力未达成就在 §7 写明，不要宣称「全库支持」。**不要在本文件里钉会漂的数字**（测试项数、全库计数）；需要时给「怎么测」而不是「测出来是多少」。
- **决策留笔记**：改了行为 / 架构 / 跨文件契约 / 流程与工具链 / 测试策略 / 落盘与网络格式时，在 `.agents/notes/{lifecycle}/{class}/` 下新建或就地更新**决策笔记**——契约与现状写在本文件与 `docs/`，笔记只写**为什么**与**放弃了什么**，两者互链；规则见 `.agents/skills/intent-notes/SKILL.md` 与 `.agents/notes/README.md`。会话开始先 `git status --short` 并跑 `node .agents/skills/intent-notes/scripts/verify-note-anchors.ts .`。

## 7. 当前遗留（如实状态，勿虚标）

> 编号沿用历史（代码注释按 §7.x 引用，勿重排）。**已修记录的完整版在 `docs/fixes/`**，这里只留「今天仍未达成 / 有明确边界」的条目。

> **编号沿用历史**（多处代码注释与 `docs/superpowers/` 按 §7.x 引用，勿重排）：**空号 = 该条已结案、记录已移入 `docs/fixes/`**（如 §7.2 起的各「已修」条目）。§7.30+ 是本次精简新增的续号。

1. **对象级效果链：执行器能力已覆盖；util 自 v0.8.2 起可挂链，无 effects 的 util 层仍不渲染**：`util` 对象有 effects 时进隔离渲染（§7.42 ⑧）；全库 util 8 对象 / 10 条 effects 均可执行，本机 `none` 0（数字口径勘误见 `docs/2026-10-20-library-feature-gap-audit.md` 第七节 #11）。**无 effects 的 util 层整层不渲染**（记边界，§7.42 ⑧）。`text` 对象的 effects 自 v0.8.1 起已挂链（隔离边界见 §7.42 ①）；**粒子对象挂载 effects 全库为 0** ⇒ 粒子隔离分支只有单测覆盖、无真实样本。端到端只逐像素验过少数样本，其余是分类学推断（详见 `docs/fixes/threejs-path-fixes.md`）。
3. **粒子自旋的轴序偏差**：本项目用 `Rz·Ry·Rx`，WE 的 `ComputeParticleTangents` 是 `Rz·Rx·Ry` ⇒ **仅多轴自旋**（全库 6 个对象）结果可能与桌面不同，**未与桌面逐像素对照**；z-only 时两种顺序逐像素等价。
10. **headless Edge 的 WebGPU 是 SwiftShader**（软件光栅化），非真实 GPU。**订正**：该结论**只对 WebGPU 成立** —— WebGL 加 `--use-angle=d3d11 --ignore-gpu-blocklist` 就能拿真 GPU（真机验收的代价只是一个 flag）。
11. **测试基线口径**：`scripts/known-failures.json` 的基线**为空**（CI 只对**新增**失败判红；套件级错误不豁免）。`scripts/known-type-errors.json` 是另一半：tests 侧 `tsc` 类型错误按 `(文件, TS 错误码)` 计数的**棘轮**，基线内不红、**新键或计数变大即红**（计数变小只提示；行号不进指纹）；确认要放宽才 `node scripts/check-known-type-errors.mjs --update`。全库计数是**本机壁纸库的快照**、随素材漂移 ⇒ 测试只断言非空，**不要在文档里钉数字**（2026-09 快照：线性 42 种/168 次、具名 RT 11 种/38 次；该数字随素材漂移，以 `npx vitest run tests/object-effects.test.ts` 的 `[全库分类]` 行为准，见 `tests/object-effects.test.ts:106`）。
12. **e2e harness 与真 GPU 的边界**：`verify-hidpi-object-rt.mjs` 已加「挂载期 RT 尺寸」断言（含独立 oracle 与变异验证），`verify-isolated-rt-sharpness.mjs` 再加结构性判据 + 锐度双判据（口径见 §5.44 与 `TESTING.md`），但**不覆盖「RT 尺寸对而贴屏映射错」**这一类缺陷；而实测到的「背景糊」根因是**分辨率不足**（RT 只有屏占位 1×），不是贴屏映射错。软件光栅化的性能数字**不能**替代真机 FPS（真机观感已按 `TESTING.md` §2.15 V10 人眼验收通过，2026-10-23）。
16. **`{animation}` 的关键帧轨道播放未实现**：`{script,value}` / `{animation,value}` 形态已按 `value` 静态兜底，但 track/keyframe/mode/fps **全部未解析** ⇒ 轨道驱动的位移/缩放/旋转仍不生效；「新位置与桌面一致」未证实。
30. **应用级 Glow 的范围边界**：只覆盖 **scene** 壁纸（且只测过 GTR 一张），而 WE 的 postprocessing 对 video 也生效 ⇒ **video / image / web 的亮部仍与桌面有差**；开启时 base RT **无 MSAA**（整帧从 canvas 的 `antialias:true` 掉到无 MSAA）；性能门槛（1080p FPS ≥ 30）**未做量化计时**（缺 GPU 耗时或有头浏览器帧率），但 **2026-10-23 人眼验收无可见卡顿**（`TESTING.md` §2.15 V10）；壁纸级 `general.bloom` **v0.8.1 起已实现**（全库 3 张：`2454403969`、`2937346640`、`3790775478`），新边界见 §7.42 ③。
31. **`copybackground` 语义未实现**（读背景副本做倒影/涟漪的场景会缺内容）；`colorBlendMode` 只实现 6/7/31，其余模式回退普通 alpha 混合。**订正**：`_rt_FullFrameBuffer` 不再是「不绑白纹 + 只打降级告警」—— 粒子 `REFRACT` 的帧内快照消费已实现（§5.46）；**效果链**消费点本轮门控关闭（`ENABLE_CHAIN_FRAME_SNAPSHOT_CONSUMER = false`，按 R6 降级），该槽在效果链里仍**留空 + 每槽去重告警**，待对象窗口 UV ↔ 整画布快照的映射验证后再开。
32. **web 壁纸的 resize 与失败回退**：跨源 iframe 拿不到子帧错误 ⇒ **无失败回退**（渲染失败停在空白而非 preview 图）；resize 靠**重建 iframe** ⇒ 跨屏拖动导致的 **dpr 变化不触发重建**，且重建会让壁纸动画从头开始（跨源探测不到壁纸是否快照了视口，故统一重建）。
33. **非回环且非桌面壳的访问仍退回 opaque origin 沙箱**：局域网 IP / 隧道访问 GUI 时既无回环名也无 `__DSH_TRANSPORT__` ⇒ 依赖 WebGL 贴图的 web 壁纸空白（纯 DOM/CSS 的不受影响）。未做「另起端口」方案。
34. **DSH 旧版（≤0.1.6）适配层待删**：0.1.7 起设置系统与右侧栏行为都变了，插件因此并存两套代码与样式。**判据**：README 声明的最低 DSH 版本 ≥ `0.1.7-alpha.1`（目前 README 只声明兼容三版），且本机与 CI 都不再跑旧版验收；清理清单见 `docs/superpowers/plans/2026-09-23-dsh-settings-compat-migration.md` §9。
35. **壁纸侧的已知缺陷（不修，仅记录）**：`3789244610` 自身的 `city.jpg` 404、空 `<nav>` 让脚本抛 TypeError、文档溢出（见 §5.40 与 `docs/fixes/web-wallpaper-history.md`）；`3778198228` 给 video 写死 `object-fit:cover`（宽于 16:9 时裁掉约 15%）。

36. **隔离对象 RT 分辨率的已知边界**：① 显存预算是**软保证** —— 预算小到装不下全部屏占位时无法再降，只能保住「只升不降」；② 预算只覆盖 **image** 隔离对象：挂载期输入只含 image，resize 期同一函数按 `entries` 计入了粒子的屏占位 ⇒ 两期输入集合不同（粒子 RT 恒为屏占位）；③ 视频纹理**未就绪时回退屏占位**，不做「就绪后重设 RT」；④ 精灵表按**源尺寸未知**处理（回退屏占位）；⑤ e2e 锐度判据的样本里粒子 / 精灵表对象**各 0 个**（判据无真实样本）；⑥ 锐度判据余量偏薄（逐块中位数最低约 **1.11**，阈值 1.05）。详见 `docs/superpowers/specs/2026-10-12-isolated-object-rt-resolution-design.md` §5 与「实测（实现后）」，脚本用法见 `TESTING.md`。

37. **`g_TextureNResolution` = 各分支实际上传尺寸（A1 已实现）**：`fxRes` 由 `withSprite` 按分支写「即将上传的宽高」（视频 `videoWidth/Height`、编码图像解码尺寸、raw `cropToMap`/`cropRowsToMap` 尺寸、DXT `ceil4` 尺寸），**四分量同值 ⇒ `.z/.x === 1` 恒成立**。**本项目前数值影响为 0**：把 `.x/.y` / `.z/.w` 当尺寸用的 B/C/D 类用法**逐条都在 `g_Texture0`**，而 slot 0 每帧被绑成 pass 输入 RT、走无 `fxRes` 的回退（RT 自身尺寸 = 其上传尺寸）；唯一 slot≥1 的尺寸用法（`3780477933` 的 `min(.w,.z)`）落在 POT 纹理上、比值本就为 1。⚠️ **唯一代码层第三类**是 DXT 的块对齐（`ceil4`）⇒ `fxRes` 可比重内容宽高多出至多 3 像素（**本机库 0 实例**，只在单测 fixture 出现）。细节与实测见 `docs/fixes/conventions-details.md` §5.17 与 `docs/superpowers/specs/2026-10-12-fxres-actual-upload-size-design.md`。

38. **看护的已知边界**：① 失败记忆落在 **localStorage**（同 origin 多窗口共享，但从另一个 origin 访问 GUI 时不共享，且不同步到其它机器）；② 软失败只记会话内，**重开即忘**；③ 首帧耗时是「宿主 `onFrame` 第一次被调用」，不等于「首帧已上屏」（浏览器合成时机不可观测）；④ 无装配**超时中断**（慢盘上仍会一直等），本计划只观测不打断；⑤ 失败记忆落 localStorage ⇒ **从另一个 origin 打开 GUI 时不共享**（本机同一 GUI 的另一个端口看不到既有失败记忆）。**以下几条本轮已修，记录在此以免回退**：⑥ `show({kind:'image'|'video'|'web'|'none'})` 经公开 API 直切时拿不到壁纸 id ⇒ 上一张 scene 的迟到打点曾**持续**上屏、且「重试实时渲染」会把它选回来 —— **本轮已修**（这四个分支同步解绑选中项并补推一次面板，见 `index.ts` 的 `show()`）；⑦ `snapshot.ok` = 本次会话最近一次装配结果、`snapshot.failure` = 失败记忆，**两者可并存**（硬/软失败都不覆盖装配结论：曾硬失败而现已正常 ⇒ `ok:true` + `failure.hard:true`）⇒ 消费方必须**两件都看**，只看 `ok` 会漏掉失败记忆；⑧ 首帧慢时面板曾把 `assembleMs` 抬高（把「首帧时刻 − 起始」当成装配耗时写回）—— **本轮已修**（装配出口记一次、首帧只回填 `firstFrameMs`）；⑨ 面板在首帧未出（`firstFrameMs < 0`，暂停态下会长期如此）时曾显示「首帧 **-1** ms」—— **本轮已修**（`formatHealthLine` 不渲染该字段，装配耗时照常）。

39. **视差的机制局限：开视差时，脚本对同一对象 `origin` 的写入每帧被丢弃** —— 基准位取自**创建期**的 `entry.origin`，`tickParallax` 每帧写 `position = 基准位 + shift`；而 OWE 是 shift 与脚本 model 平移**叠加**。**影响面 = 落点在 `position` 上的那几路**：**背景**（非隔离写对象 mesh、隔离写合成 quad）与**隔离粒子**的合成 quad；**非隔离粒子走顶点 shader 的 `u_Parallax`、不写 `position`** ⇒ 其脚本 `origin` 写入**不受影响**。故影响面不是「34 张里的 1 张」那么小，但也**不是**「该壁纸里所有带 `parallaxDepth` 的对象」。**当前本机无实害**（本机唯一开视差的 `3793620838` 那 pkg 内无 `.js` 脚本）；真遇到「脚本位移 + 视差」同对象的壁纸，须先按叠加语义改 `tickParallax`。验收观察项见 `TESTING.md` §2.10（**2026-10-23 已人眼验收通过，无可见异常**）。
    - **未实现的视差语义**：① **传播组**（父链锚点 + `disablepropagation`）**未实现** —— 按「每对象自算 `parallaxDepth`」近似，子对象**不继承**父层深度（`research/audit-parallax-mechanism.md` §7.4：扁平层级观感一致，容器/组继承待做）；② **`parallaxDepth` 缺省不参与视差** —— WE 对 composite 容器有 `{1,1}` 缺省，本仓**未实现**该缺省（字段缺失即不写 `position`，见 §2.3）。

40. **`.mdl` puppet 只有静态族有真实样本，蒙皮/动画半段在本机无素材可验**（T6，2026-10-13，分支 `feat/scene-parallax-puppet`）：全机（本机壁纸库 + 磁盘上全部解包副本）**只有一个 `.mdl`** —— `3303428996` 的 `models/20240220213723_1_puppet.mdl`（magic `MDLV0021`）。它与 T6 brief 的段布局**三处不一致**，故 `parseMdl` 得按「文档化口径 + 实测静态口径」双候选实现（`src/client/mdl-parser.ts`）：
    - **没有 `MDLS`/`MDLA`/`MDLE`/`MDAT` 段**（`indexOf` 全 `-1`）⇒ `bones=0`、`animations=0`、`blendWeights=null`；`MdlPuppet.segments` 实测 = `{mdls:'absent',mdla:'absent'}`（本机唯一可硬断言的段级事实，测试已钉）。本机 puppet 只能按**静态网格**渲染 ⇒ **T7 的蒙皮与 T8 的动画路径在本机无真实样本**，只有 brief 夹具的单测覆盖；测试硬判据相应只到「几何 + 段 absent」为止，骨骼/动画只 log（`tests/mdl-real-library.test.ts`）。
    - **容器头不是 `magic(9) + 材质 cstr@9`**：实测材质串 @21、NUL @52（@9 处按 cstr 读只有 1 B `09`）。头 12 B（9..20）**实测字节为** `09 00 00 00 01 00 00 00 01 00 00 00`，**其 u32 读法为 9/1/1，字段语义未确证** —— 「二进制头 + 2 B 对齐」只是同一串字节的另一种等价读法，不是确证结论。字段区 `fields@53+4k` 实测 = `0,0,0,0,0,0,0,15,88800`（28 B 零 + `u32 15`@81 + `u32 vertexBytes`@85）；顶点数据 @89。**未确认**：`u32 15` 的语义、文件尾 3 B `00 00 00`（@110889..110891）的语义（不猜、不赋义）。
    - **顶点 stride = 48 不是 80**（88800 B = 12 float/顶点）：判据是**紧覆盖** —— 索引 10998 个、`maxIndex=1849`，只有 `vertexCount = 1850`（stride 48）满足 `vertexCount ≈ maxIndex+1`；24/32/40 虽然同样零越界，但浪费率 50%/33%/17% 远超 5%。**旁证**：`f32@+12..+20` 在**全部 1850 条**记录上都是单位向量（记录边界与 `pos@+0/+4` 正确）；`uv@+40/+44` 绝大多数落在 `[0,1]`（实测 1850 条里 38 条 = 2.05% 轻微出界：u ∈ [−0.00195, 1.00156]、v ∈ [−0.00278, 1.00347]，three 的 ClampToEdge 采样可覆盖）。**未确认**：`f32@+8` 恒 0（z 还是占位无法证明），12 float 记录里另 8 个 float 语义未知，均不映射。**订正**：`+8..+36` 那 8 个 float **并非全部恒定** —— 实测 `+8/+12/+16/+32` 恒 `0`、`+20/+24/+36` 恒 `1`，而 **`+28` 在全部 1850 条记录上互不相同**（量级 ~1e-7）⇒ 夹具里的 `STATIC_CONSTANTS` 只描述夹具，不能当实测口径引用。
    - 静态族的 stride **不再硬编码**：候选集 `[24,28,32,36,40,44,48,52,56,64,72,80]` → 整除 → 索引零越界 → 取浪费率最小者；**并列或最小浪费率 > 5% 即返回结构化错误**（`stride-waste:` / `stride-ambiguous:`），选中但无字段布局也拒收（`stride-layout-unknown:`）。判定痕迹随 `mesh.strideInfo`（候选列表 + 各自浪费率 + 命中原因）返回，Task 7 排查用。
    - **实现语义（T7/T8 必读）**：① 定位到块上的 stride **硬失败只留痕、继续扫描**（锚点与扫描都可能先撞假块），**整份文件都找不出网格时才上报**该错误与 `strideInfo`；② 材质串按「宽窄两种口径」（@9 / @21）取候选并**优先取以 `.json` 结尾者**，避免扫描命中时把真串截成后缀（如 `m.json`）；③ `segments` 区分「段不存在 / 段在但没解完」⇒ `bones=[]`、`animations=[]` 不再等于「没有该段」；④ 骨骼文件 id 非 `0..n-1` 时按 id 升序**重排**并同步父索引与轨 `boneId`（`MdlPuppet.boneIdMapping='remapped'`），不静默错绑；⑤ `strideInfo.reason` 是闭集：`packed-80`/`tight-coverage`/`waste-too-high`/`ambiguous`/`no-candidate`/`layout-unknown`。
    - brief 的参照实现另有两处**读法分歧**（骨骼头 13 B 还是 9 B；`MDLA0006` 头里 `fps/frameCount` 与轨数之间那个 `u32` 是否计入）—— **两处结论都来自 brief 自己的字段表 / 夹具口径，未在真实素材上确证**（本机样本没有骨骼段与动画段）。解析器对两处都做**双候选 + 自洽校验择一**（轨表要让每轨字节数整除 36 且不越界；骨骼头要让绑定矩阵末行 = `(0,0,0,1)` 且 matSize = 64），择不出来就不解该段。段头十六进制：网格头首 89 B = `4d444c5630303231000900000001000000010000006d6174657269616c732f32303234303232303231333732335f312e6a736f6e00` + 28 B 零 + `0f000000` + `e05a0100`。
    - **动画层口径（T8）**：`scene.json` 的 `animationlayers` 由 `scene-json.ts` 解析（`id`/`animation` 必需，缺任一**整条跳过**，不产出半截层；`rate`/`blend` 缺省 1、`visible` 缺省 false），逐帧**只应用第一条可见层**（`threejs-player.tickPuppets`：帧号 = `(已播秒数 × rate × fps) % frameCount`，`fps` 非法兜回 30），`blend` / `additive` **未参与混合**。⚠️ **缺省 `visible=false`** 的出处是 **lwe** `research/.lwe/src/WallpaperEngine/Data/Parsers/ObjectParser.cpp:284`（`it.user("visible", properties, false)`，但该字段在 lwe 中**从未被消费**）；本仓**照 brief 取 false**，与 WE 渲染侧实测相反 —— `WPPuppetLayer::AnimationLayer` 两棵源码树都是 `bool visible { true }`（`.superpowers/we-layerd-src/third_party/wallpaper-engine-renderer/src/backend/scene/internal/animation/WPPuppet.hpp:114-118`、`research/open-wallpaper-engine/src/Scene/Pkg/Parse/Puppet/Puppet.cppm:251`，`WPImageObject.cpp:220` 的 `GET_JSON_NAME_VALUE_NOWARN` 不改初值）⇒ 真实素材里**省略 `visible` 的层在本仓不会被应用**。本机实测：34 个真实 `scene.json` **0 个**含 `animationlayers`、唯一含 `.mdl` 的样本是静态族 ⇒ 该差异**无真实素材可证伪**，待有素材再对齐；**控制方已裁定保留 `false`**（与计划书夹具 `visible:false` 一致，**勿改回 `true`**）。**字段缺失**时退回「播动画表首个」（= T7 行为，`tests/threejs-player.test.ts` 有断言；**除 `frameCount <= 0`**：旧实现会采样帧 0，现直接不采样）；显式空数组 / 无可见层 / 动画 id 不存在 / `frameCount ≤ 0` ⇒ 不做动画（OWE `PuppetLayer::prepared()` 同义）。
    - **未复刻与其它的边界（T8）**：puppet 材质走 three **内建材质**（`createPuppetMaterial` = 普通 alpha 混合），WE 的 `colorBlendMode ≠ 0` 与自定义 shader 分支**未复刻**（复刻要预乘 `ShaderMaterial`，会失去「内建材质才自动注入蒙皮 shader」这条前提）；**无 puppet 的 e2e 自动化判据** —— 只有真机人工验收（`TESTING.md` §2.11，**2026-10-23 人眼验收通过**）+ 非 puppet 壁纸的零回归对拍。

41. **v0.8 产品化边界（2026-10-19）**（理由与取舍见[决策笔记](.agents/notes/implemented/architecture/2026-10-19-v08-degradation-rotation-and-properties.md)）：**已修（记录在此以免回退）** —— ① 视频壁纸 HEVC/H.265 缺解码时不再停在黑背景：`showVideo` 在 `error` 或 1.5s 首帧超时返回 `unsupported` / `timeout`，controller 回退 preview（无 preview 则空态），面板按 `media-health` 分档提示（失败记忆只在**内存**，重开可重试；**不做** host ffmpeg 转码）；② `overlayOpacity` / `blurEnabled` / `blurRadius` / `kenBurns` / `fitMode` 已在「显示效果」面板有控件，点击即生效。**新边界**：
    - ① **用户属性面板（v0.9 已全类型，记录在此以免回退）**：暴露 `project.json general.properties` 中 `type ∈ {bool,slider,color,combo}`、`editable !== false`、且**被当前 scene 真正引用**（`usedBy` 非空）的属性——`group` / `text` / 未被引用的 `schemecolor` 不返回；默认值取 **project.json 的 `value`**（不是 scene 的 value，两者可能不一致）；写 `we:userprop:<wallpaperId>:<key>`（localStorage，**按壁纸隔离**；读侧缺 per-id 键时回退旧全局键 `we:userprop:<key>`，不再写入）后**重装配**才生效。
        - **绑定语义**：`user:"k"` 与对象形态 `user:{name,condition}` 同等解析；绑定侧 condition **匹配即可见、不匹配即隐藏**（bool 的 `"0"`=开、`"1"`=关，we-layerd 语义；与作者 value 无关），无 condition 时保持历史口径（用户布尔覆盖，键缺失/非布尔回退作者 value）；对象可见性 = 自身 && **父链继承**（`computeEffectiveVisibility`）。
        - **装配前统一 resolve**：`resolveSceneUserBindings` 一次性把 `color/alpha/brightness/origin/scale/angles`、`general.bloom` / `cameraparallax`、effect visible、`instanceoverride`、`scriptproperties` 的 `{user}` 引用换成用户值，下游只消费静态值；属性级 condition（如 `audiobar.value==true`）不满足 ⇒ 面板禁用标灰、渲染侧回退作者值。面板提交：bool/combo 立即，slider/color 防抖 300ms 或 `pointerup`/`blur` 后提交一次。
        - **边界**：`text` 类型本机 0 样本、面板不渲染；`group` 折叠不做（Leon 的 `character`/`weather` 不显示）；color 的 0-1 值首版按 sRGB 直映射（`clockcolor` 色彩空间已按 `TESTING.md` §2.16 P2 人眼验收通过，2026-10-23；未做逐像素色差量化）；`bloomhdr*` 仍不支持（另一条缺口）。设计与全库影响面见[设计文档](docs/superpowers/specs/2026-10-23-user-properties-full-types-design.md)，为什么这样取舍见[决策笔记](.agents/notes/implemented/feature/2026-10-23-user-properties-full-types.md)。
    - ② **轮播失败跳过仅本会话**：`failed` 是内存 Set（不落盘，手动选择清空）；池 = 收藏 ≥2 张时只用收藏，否则全部非隐藏且 `type !== 'unknown'` 的壁纸；池 <2 张不切、面板显示原因并明示。
    - ③ **抓帧依赖 `readPixels`**：无 GPU / 上下文丢失 / 部分浏览器可能失败或读回全零；当前只对 context-lost 跳过，**无亮度门禁**（Task 6 评审已知），失败只 `warn`、不写缓存、不影响渲染 —— **已按 `TESTING.md` §2.13 人眼验收通过（2026-10-23）**。
    - ④ 抓帧数据目录契约见 §5.49；`frameCacheEnabled` 只影响是否抓帧，不影响降级链的读取。
    - ⑤ **降级成功不清 live 失败记忆**：`sceneFallback` 显示 video / frame 后不 `healthStore.clear`。软失败仍按 3s 冷却自动重试一次（每会话每壁纸一次）；硬失败不自动重试（重试同一张渲染不出来的壁纸只会重复失败）。面板可能同时显示「降级画面 + 上次失败」，属真实状态，用户可手动重试 / 清除。

42. **v0.8.1 缺口修复的新边界（2026-10-20）**（设计见 `docs/superpowers/specs/2026-10-20-v0.8.1-gap-fixes-design.md`）：
    - ① **text effects 已挂链，但隔离尺寸装配期冻结**：`groupEffectsByObject` 不再跳过 text，隔离 RT / 合成 quad 取装配期实测布局 × |scale|；时钟文本跨分钟变宽时仍按装配期尺寸采样（轻微裁边/拉伸），不自动重建 RT。**源分辨率下限 = 布局 canvas 像素（热修 2026-10-20）**：此前 RT 只按屏占位 ⇒ 小字号 text（如 `3660373677` 的 Date/Clock：布局 917×214 / 489×214，屏占位仅 97×22 / 46×20）在效果链里先被降采样，`blurprecise` 1.3px 相对笔画过强、文字糊成一片；现与 image 同口径（`isolatedRtSize(world, density, source=布局尺寸)`），text 仍不进显存预算。`threejs-player.update_background` 的 origin 位移落在合成 quad（`parallaxNode`）而非 RT 内容 mesh。静态解析隐藏、但可见性脚本会点亮的 text 只收链、无图层，落入「效果挂在未参与渲染对象上」的汇总告警（仅文案不精确）。
    - ② **精灵表帧 UV 与对象级脚本**：材质 `passes[0].combos.spritesheet` + TEXS 帧网格 ⇒ 行优先当前帧 UV（`resizeBackground` 后重写）。**对象级脚本已执行**（`visible.script` 优先，其次 `angles > origin > scale > color`）；`thisLayer.getTextureAnimation` 已接（`pause/play/stop/setFrame/getFrame`）；无脚本的 spritesheet 仍自动 1 fps。**属性脚本 `update(value)` 已按 WE 契约写回**（传入当前值 Vec3、返回 Vec3-like 写回；`angles/origin/scale` 经 `applyLayerState` 生效，其中 angles 的脚本单位是**度**、落 three 时转弧度，`color` **仅记录不应用**）。**生产 GUI 点击不可达**（canvas 在 `pointer-events:none` 的背景层里），按 2026-10-20 产品决策**不做 window 级点击转发** ⇒ 点击循环（如 `3765967112` 的 automatic→day→night）为**已知边界**，canvas 上的 click 监听只服务 e2e/harness；`frametime` 与 image 材质的 `sequencemultiplier` 未解析；材质标记为精灵表但缺 TEXS 时回退整表（失败开放）。
    - ③ **bloom 两级后处理**：`general.bloom === true` ⇒ `bloom-stage.ts` 薄封装 GlowStage（缺省 strength=2 / threshold=0.65），player 按「壁纸 bloom → 应用级 Glow → composite」串联（段渲染同序）；`bloomRT` 为 8-bit RGBA 且带 depthBuffer（`WebGLRenderTarget` 缺省建法，未按需关闭）。**资源代价**：每条 bloom 管线 = 一整套 GlowStage（7 张 HalfFloat RT：base 画布缓冲 + 三级 ping-pong ≈0.66×base 面积）＋ 每帧 10 个全屏 pass（另加主场景自渲 1 次）；bloom + Glow 同开时下游 Glow 读 `bloomRT`、不再自渲，合计约 20 个 pass/帧。**边界**：`general.hdr` 未实现；bloom + Glow 同时开启已有 e2e 像素判据（默认 Glow 下 bloom on/off A/B，`2454403969`）；另两张 bloom 壁纸（`3790775478` / `2937346640`）**已按 `TESTING.md` §2.14 V1 人眼验收通过（2026-10-23）**（e2e 只判 `2454403969`）。
    - ④ **sound 每对象只播一首**：OWE 语义下 `loop` 从首曲起、`random` 装配时随机、`single` 随机选一首播一次；**多文件 loop 轮播 / random 播完重随机未实现**；单文件失败不尝试同对象其余文件；`volume` 的 `{user,value}` 包装未支持（非 number → 1）。**所有音频统一走 `<audio>` 原生流式**（浏览器流式解码，大小无上限；不依赖 `content-length`——桌面版 GUI 的 `/app/...` 前缀链路下该头不可靠，曾导致回退 132MB 整块解码而无声）；`<audio>` 不可用且文件较小才回退 `decodeAudioData`（>32MB 拒绝解码）；`PkgReader` 仍整包常驻内存（147MB 级 pkg，v0.9 改按需读取）。
    - ⑤ **starttime 预推进上限 900 步**：按 effect 秒（步长 `1/60/rate`）前滚，900 步 = 15 effect-s，超限**静默截断**（未 warn）。**起播构造成本实测**：`2897292240`（maxcount=10000、starttime=10，两个同 spec 对象）单对象构造耗时中位数约 **155ms**、两个对象合计约 **0.3s**（最终评审实测）。**cargo 既有失败** `particle_override_test::override_rate_keeps_duty_cycle` 在本轮之前即存在（干净 HEAD 可复现），cargo 不在 CI 门禁，待另开任务订正测试期望。
    - ⑥ **clearcolor 语义**：真实 `general.clearcolor` 是 **0-1** 归一化值，`parseSceneJson` 按 max≤1 ⇒ ×255 归一化，player 接口仍收 0-255；**`general.clearenabled` 未消费**（未解析）。OWE 源码未找到 clearcolor / clearenabled 解析，语义依据是 WE 编辑器行为与 `2980088441` 实测；透明区露出的底色**已按 `TESTING.md` §2.14/§2.15 人眼验收通过（2026-10-23）**；`clearColor` 对 NaN/非有限分量不产出（走缺省黑），但未做范围 clamp。
    - ⑦ **e2e 零回归口径**：`e2e:hidpi` 的挂载期 RT 尺寸断言在 v0.8.0 基线即 FAIL（**已知基线**，非本版引入；不作为回归判据，2026-10-23 人眼验收确认画面无问题）；`e2e:compare` 因 F7 预推进改变 `2683211654` 的雾相位属**预期变化**（记录为基线更新，不作为回归判据）。本版新增 `e2e:verify-v081` 三项像素判据（bloom 含默认 Glow A/B / clearcolor 默认 Glow 四角 / spritesheet）已 PASS；观感**已按 `TESTING.md` §2.14 人眼验收通过（2026-10-23）**。
    - ⑧ **util 层渲染（v0.8.2）**：四类 `layerKind` = `project`/`fullscreen`/`compose`/`solid`（按 `image` 文件名判，未知 util → fullscreen 降级，`src/client/scene-json.ts:152`）；project/fullscreen **强制居中**（origin=场景中心、scale=1、size=场景，`src/client/threejs-player.ts:1723-1731`），RT = world × 屏幕密度（**屏占位、与 world 等比，不是画布缓冲**——cover 裁切/竖构图会拉伸效果 mask；2597392171 竖构图 RT=1920×3000 > 画布 1080）；compose/solid 的 world = `size×|scale|`、RT = 屏占位（`src/client/object-range.ts:82`）；均**不参与** `fitIsolatedBudget`（挂载期与 resize 期一致：resize 只用 `budgeted=image` 条目，`src/client/object-effects.ts:263-279`）。有 effects 才进 isolate（**无链 util 仍不渲染**，记边界）；`passthrough` 内容为**白色占位**（opacity 0）、对象 alpha 落合成 quad（`src/client/threejs-player.ts:1787-1796`），**color/brightness 仅 solid 消费**（本机 util 全白/1，无可见差）；solid 的 0<alpha<1 存在 alpha²（T3 遗留）；renderOrder = objects 下标穿插。
    - ⑨ **util 快照内容输入（v0.8.2）**：真实 util 链读 `bind: previous`，快照作为**内容输入**（`setUtilContentTexture`，`src/client/threejs-player.ts:1515-1535`）：cover 反解到场景世界、UV 写内容几何、**不动**共享快照纹理；`_rt_FullFrameBuffer` 槽门控保留，但仅「util 内容层 + 链显式引用」绑定（对象链仍关闭，`src/client/object-effects.ts:380-389`）；同帧多消费者取**最后段**边界快照（仅单消费者语义明确），solid 不登记消费者（拿不到快照，本机 0 实例）。段渲染成本 O(段数×全场景 render) + frameRT 无 MSAA（2911105183 5 消费者 ⇒ 6 段/帧）；headless 1080p 实测（强制 SwiftShader，**非真机**）：291/213/259 = 404/222/2578 ms/帧 ≈ 2.5/4.5/0.4 fps，默认 headless 本机落 D3D11 RTX 3060 时 60fps 封顶、render 2.0/1.0/1.2 ms ⇒ 真机 ≥30fps **已按 `TESTING.md` §2.15 V10 人眼验收通过（2026-10-23，量化 FPS 未记录）**。
    - ⑩ **text 字段边界（v0.8.2）**：alpha 落**内容材质** opacity（合成 quad 中性、避免 a²；效果链重写 alpha 会丢对象 alpha；e2e A/B：291 changed 1107px / 246 34366px，内容 opacity 0.93/0/0.82、合成 quad 恒 1）；brightness 为 canvas LDR 近似（<1 压暗、>1 用 `lighter` 叠加，clamp ≤4；非 WE 精确 HDR 语义，`src/client/text-object.ts:312-320`）；anchor 只决定 quad 原点（9 值，`none` 回退 alignment 族；语义**已按 `TESTING.md` §2.15 V7 人眼验收通过（2026-10-23，未发现偏移问题）**：1922570576 / 2937346640）；limitwidth/maxwidth 按字体像素（单位按 §2.15 人眼验收通过、未量化；超长单词不切，`src/client/text-object.ts:130-139`）。
    - ⑪ **image color/alignment（v0.8.2）**：color 乘内容材质（直渲/隔离一致；合成 quad 中性，`src/client/threejs-player.ts:1744-1746`）；alignment 决定直渲 mesh 与隔离合成 quad 的位置（方向按 WE 参考实现 we-layerd，**已按 `TESTING.md` §2.15 V6 人眼验收通过（2026-10-23）**，`src/client/alignment.ts:3`、`threejs-player.ts:1744-1772`）；脚本写 origin 会覆盖静态 alignment（2937346640 收益有限，`src/client/layer-state.ts` 无 alignment 写入）；puppet 未接 color/alignment（全库无样本）；`update_background` 的 scale 仅在 alignment 偏移变化时按差值平移（`threejs-player.ts:2127-2135`）。
    - ⑫ **F18 全局 uniform（v0.8.2）**：`g_PointerPosition` 归一化 [0,1]、y 向下（按 3780477933 shader 实测，`src/client/effect-runner.ts:674-689`）；3780477933 原样素材**无可见差**（作者常量把效果关成 no-op），像素链路由服务端 defaults 变体（Default Circle Size=0.3 + opacitymask=util/white）证明。`g_ParallaxPosition` 公式（0.5 中性 / y 向上 / ×mouseinfluence，`src/client/parallax.ts:86-103`）为**有据假设**：唯一消费者 3118949804 在现解析器下 `cameraparallax={user,value}` 未解析 ⇒ `enabled=false`，公式无法量化校准（2026-10-23 人眼验收未发现异常，`TESTING.md` §2.15 V11）；该壁纸行为变化（binder 旧默认 [0,0] → 新 [0.5,0.5]，旧值被 shader 当 -1 偏移）记录在案。`applyGlobalUniforms` 仅当 uniform 已是 2/4 长度数组时写（vec4 = [x,y,0,0]；number/非数组/其它长度跳过）；`onFrame` 读上一帧视差（1 帧滞后）；未声明 uniform 的壁纸零回归。
    - ⑬ **e2e 门禁（v0.8.2）**：新增 `npm run e2e:verify-v082`（`e2e/verify/verify-v082.mjs`）四组判据及基准值：2911105183 util `meanAbs 11.410 / 62.10%`（全屏 bbox）、2132420420 pulse `0.826 / 3.23%`、3765967112 text `910px / maxΔ20`、3780477933 pointer asis `0.00%` / defaults `3.88%` / 双簇 `4.3 / 5.8px`；shader 编译失败（warn 文案或 `__fxShaderErrors`）对门禁**判红**（fail-loud，换驱动出现良性 info log 时可能 brittle）；③ 的文字区 `[728,305,841,368]@1600×900` 为硬编码常量需重标定；② 阈值余量最小（meanAbs 1.65× / changed 1.62×），换机需按实测重标定。
    - ⑭ **静态隐藏对象不装配（v0.8.2 修复）**：`loadSceneToThree` 按装配期 `effectiveVisible`（`computeEffectiveVisibility`：自身绑定含 condition + 父链继承）跳过隐藏对象——`visible:false` 的对象（全库仅 2832263418 的 `all_fg_still`）此前仍会建无纹理 quad，渲染成白色全屏层盖住背景（v0.8.1 起存在）。user 绑定 / condition 按装配期用户属性判定：运行中切换用户属性需重载壁纸；script 绑定不在装载期跳过（保持可点亮）。
    - ⑮ **音频频谱竖条（v0.8.2 修复）**：`Simple_Audio_Bars` 等效果以 `linked` 参数默认值 `"0.0, 1.0"`（逗号分隔）提供 `u_BarBounds`，`resolveUniformBindings` 的 parseValue 改为按 `[\s,]+` 分隔（此前返回 `[0,0]` ⇒ bars 高度恒 0、竖条不可见）；音频数据来自 sound 对象播放的 analyser（浏览器自动播放被拦截时需用户手势，注册手势重试）；EVA 卡农（2832263418）竖条已验证渲染（白色 `u_BarColor`，颜色/`copybackground` 语义与桌面 WE 的差异待 v0.8.3 对齐；chromatic_aberration pass 仍编译失败跳过，不影响 bars）。

## 8. 历史归档

| 位置 | 内容 |
|---|---|
| `docs/fixes/conventions-details.md` | **§5 全部条目的原文**（含实测数据、推导、历史事故）—— 本文件 §5.x 的指针目标 |
| `docs/fixes/threejs-path-fixes.md` | §7 组一的完整记录（three.js 主路径的修复过程、效果链验收表、Glow 标定、显存与性能实测） |
| `docs/fixes/web-wallpaper-history.md` | web 壁纸的定位过程与已修记录 |
| `docs/fixes/verification-ci-history.md` | 验证手段、CI 三个坑、测试基线的历史记录 + 精简前的 §3.3 长段 |
| `docs/superpowers/specs/`、`docs/superpowers/plans/` | 各轮设计文档与实施计划（**改动前必读**） |
| `.agents/notes/{lifecycle}/{class}/` | **决策笔记**：只记「为什么」与「放弃了什么」；契约与现状仍以本文件 §5/§7 为准，两者互链 |
| git 历史（`AGENT.md` 的上一个版本） | 精简前含 §1–§4 / §6 旧措辞的完整文档 |

归档文件只作查阅：**新的结论、边界与遗留写回本文件的 §5 / §7**，不要往归档文件里追加。
    - ⑯ **多彩音频条对齐（v0.8.2 修复）**：2832263418 的 `Simple_Audio_Bars` 在桌面 WE 显示内容色（Rainboww 彩虹），实测由两点共同决定：① `colorBlendMode ≠ 0` 的对象**不做 color tint**（追加混合 pass 的 B = 内容原色，`threejs-player.ts` addBackground）；② 该效果 `BLENDMODE=0`（Normal，官方 fallback 输出 BarColor=白）按桌面实测映射为 `min(A,B)`（内容色，`shader/effect-chain.ts`）。影响面：全库仅 4 个 `colorBlendMode≠0` 对象（其中 2 个 color 缺省白）与 1 个 Simple_Audio_Bars 效果；2911105183 的 music bar 同效果。桌面截图证据：bars 左紫→右红 = Rainboww 内容色。
    - ⑰ **SceneScript 音频可视化（visualizer，v0.8.2 修复）**：脚本含 `engine.registerAudioBuffers` + `createLayer`（`detectScriptPattern === 'visualizer'`，本机样本 2937346640 的 `Simple Visualizer`）时，three 路径不再依赖脚本 VM：`three-renderer` 收集对象参数后由 `player.setVisualizerBars` 代建 64 条 bar（宽 = barWidth × 图宽、底部对齐 origin.y），`onFrame` 用 analytics 频谱（64 bins）逐帧更新高度（无音频 → 高度 0 不可见）；bar 贴图 = 对象自身 image 的白色 4×4 纹理。其余 visualizer 参数（对齐/角度）按 Simple Visualizer 语义实现，其它 visualizer 脚本若结构不同需单独适配。**v0.9 起**新增 `pixel-bars` 家族（props 含 `visualizerResolution` / `visualizerBarPath` / `minBarHeight`，本机样本 `3118949804` 的 `3007895627` 脚本）：`computePixelBarLayout` 按脚本公式算条数 / 世界条宽 / 最小高度，`player.setPixelVisualizerBars` 按对象 `scale` / `angles` 旋转布局；静音高度 = `minBarHeight`（桌面同款静态条），系统音频驱动仍缺（`supportsaudioprocessing`）。取舍见[决策笔记](.agents/notes/implemented/bug-fix/2026-10-26-pixel-bars-visualizer.md)。**系统音频（v0.9 P1）**：`project.json general.supportsaudioprocessing === true` 的壁纸在面板显示「系统音频」入口——浏览器模式经 `getDisplayMedia({audio:true})` 捕获（独立 AudioContext → analyser → 静音 gain，不重复出声），频谱优先于包内 sound 驱动 visualizer 与效果 uniform；桌面 App 主进程禁用 display media/设备权限 ⇒ 返回失败码并提示用浏览器打开 GUI；不落盘、不上传，停止共享即清理。取舍见[决策笔记](.agents/notes/implemented/feature/2026-10-26-system-audio-capture.md)。
