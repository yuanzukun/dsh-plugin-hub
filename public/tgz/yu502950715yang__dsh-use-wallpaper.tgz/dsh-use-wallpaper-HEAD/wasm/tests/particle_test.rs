//! Task 3: 粒子规格解析（emitter/initializer/operator）——TDD 测试
//! 断言来自 brief；字段名以真实 fixture 为准（operator[].name、emitter.rate）。

use we_scene_wasm::particle::{parse_particle_spec, OperatorKind};

const ASHES_JSON: &str = include_str!("fixtures/eva/particles_Ashes.json");
const LIGHTSHAFTS_JSON: &str = include_str!("fixtures/eva/particles_presets_lightshafts.json");

#[test]
fn ashes_emitter_defaults() {
    // Ashes emitter 无 rate 字段 → 缺省 10
    let spec = parse_particle_spec(ASHES_JSON);
    assert_eq!(spec.emitter.rate, 10.0);
    assert_eq!(spec.emitter.distance_max, [256.0, 256.0, 0.0]);
}

#[test]
fn lightshafts_low_rate() {
    let spec = parse_particle_spec(LIGHTSHAFTS_JSON);
    assert!(spec.emitter.rate < 1.0, "lightshafts rate 应很低: {}", spec.emitter.rate);
}

#[test]
fn vector_fields_do_not_nan() {
    // 仅验证真实 fixture 解析结果均为有限值：
    // Ashes emitter 无 distancemax 字段 → 走缺省分支 256.0（不经过 token 解析）；
    // velocityrandom.max = "50 0 0" 三个 token 均可解析（vec3 正常路径）。
    // 防 NaN 的 token 解析路径由 scalar_string_parses_first_token /
    // unparsable_token_falls_back_to_zero 两个内联测试专门覆盖。
    let spec = parse_particle_spec(ASHES_JSON);
    assert!(spec.emitter.distance_max.iter().all(|v| v.is_finite()));
    assert!(spec.init.velocity_max.iter().all(|v| v.is_finite()));
}

#[test]
fn scalar_string_parses_first_token() {
    // 标量字段为多 token 字符串 → 取第一 token（防把 "50 256 0" 整串解析成 NaN）
    let spec = parse_particle_spec(r#"{"emitter":[{"rate":"50 256 0"}]}"#);
    assert_eq!(spec.emitter.rate, 50.0);
}

#[test]
fn unparsable_token_falls_back_to_zero() {
    // token 无法解析为数字 → 回退 0.0，不得 panic / NaN
    let spec = parse_particle_spec(r#"{"initializer":[{"name":"velocityrandom","max":"abc def"}]}"#);
    assert_eq!(spec.init.velocity_max, [0.0, 0.0, 0.0]);
}

#[test]
fn detects_movement_operator() {
    let spec = parse_particle_spec(ASHES_JSON);
    assert!(spec.operators.iter().any(|op| op.kind == OperatorKind::Movement));
}

#[test]
fn colorrandom_normalized_to_0_1() {
    // WE colorrandom 0-255 量级 → /255 归一化（对齐 JS particles.ts；2026-08-21 修复：
    // 原实现透传 255 → shader v_color 超范围 → additive 过曝黄色爆炸）
    let spec = parse_particle_spec(
        r#"{"emitter":[{"rate":1}],"initializer":[{"name":"colorrandom","min":"255 255 255"}]}"#,
    );
    let cm = spec.init.color_min.expect("color_min 应解析");
    assert!((cm[0] - 1.0).abs() < 1e-5, "255/255 应为 1.0，实际 {}", cm[0]);
    assert!((cm[1] - 1.0).abs() < 1e-5);
    assert!((cm[2] - 1.0).abs() < 1e-5);

    let spec2 = parse_particle_spec(
        r#"{"emitter":[{"rate":1}],"initializer":[{"name":"colorrandom","min":"0 128 255"}]}"#,
    );
    let cm2 = spec2.init.color_min.expect("color_min 应解析");
    assert!((cm2[0] - 0.0).abs() < 1e-5);
    assert!((cm2[1] - 128.0 / 255.0).abs() < 1e-5);
    assert!((cm2[2] - 1.0).abs() < 1e-5);
}

#[test]
fn maxcount_parsed_when_present() {
    // 2026-08-25：parse 读取 spec 的 maxcount（WE 权威粒子上限）。
    // Fireflies 场景（Crimson Horizon）maxcount=20；无 maxcount → 0（estimate 回退 rate 估算）。
    let spec = parse_particle_spec(r#"{"maxcount":20,"emitter":[{"rate":20}]}"#);
    assert_eq!(spec.maxcount, 20);

    let spec2 = parse_particle_spec(r#"{"emitter":[{"rate":20}]}"#);
    assert_eq!(spec2.maxcount, 0, "缺省 maxcount 应为 0（estimate 回退 rate×寿命+64）");
}
