# Agent Note: {{标题}}

Status: implemented

## Problem

{{动机。不依赖方案即可独立成立。}}

## Decision

{{现在时描述已交付事实。路径、符号、默认值变了就地改这里，不要追加变更流水账。}}

## Affected repositories

- `{{仓库名}}` 分支 `{{分支名}}` commits `{{短哈希}}`
- `{{不涉及的仓库名}}` 不涉及

## Alternatives considered

**{{备选方案名}}。** {{它最强的理由}}。{{为什么最终不选它}}。

## Consequences

**收益：** {{...}}

**代价：** {{...}}
