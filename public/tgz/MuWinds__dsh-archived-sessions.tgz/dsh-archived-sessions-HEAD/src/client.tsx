/**
 * Browser half of the archived-sessions page (@muwinds/dsh-archived-sessions).
 *
 * Runs inside the harness web profile's __ModuleLoader__ bundle: this module is
 * compiled to CommonJS by `tsc -p tsconfig.client.json` and then wrapped into
 * `window.__ModuleLoader__.load({ id, factory: (require) => {...} })` by
 * scripts/build-client.mjs. The compiled body may use `require` and `exports`
 * freely because both are in scope inside the factory.
 */
import * as React from "react";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Browser-side plugin context (the subset this plugin needs). */
export interface ClientCtx {
  effect(fn: () => () => void, name?: string): void;
  slots: {
    inject(slot: string, fn: () => unknown): void;
    register(desc: Record<string, unknown>, render: () => unknown): unknown;
  };
}

export interface ArchivedItem {
  id: string;
  title: string | null;
  createdAt?: number | null;
  cwd?: string | null;
  parentSession?: string | null;
  sizeBytes: number;
  missing: boolean;
  live: boolean;
  running: boolean;
  path: string | null;
}

export interface ListResult {
  items: ArchivedItem[];
  totalBytes: number;
}

export interface DetailMessage {
  seq?: number;
  time?: number;
  role: "user" | "assistant" | "tool";
  text: string;
}

export interface DetailData {
  id: string;
  createdAt?: number | null;
  cwd?: string | null;
  parentSession?: string | null;
  totalEvents: number;
  messageCount: number;
  truncated: boolean;
  messages: DetailMessage[];
}

export interface DetailState {
  id: string;
  loading: boolean;
  data: DetailData | null;
  error: string | null;
}

interface ApiEnvelope {
  error?: string;
}

// ---------------------------------------------------------------------------
// Styles
// ---------------------------------------------------------------------------

const STYLE_ID = "dsw-arch-style";
const CSS = [
  ".dsw-arch-page{font-size:13px;padding:2px 2px 24px;}",
  ".dsw-arch-toolbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px;}",
  ".dsw-arch-page-title{font-weight:600;color:var(--dsw-alias-label-primary);}",
  ".dsw-arch-meta{color:var(--dsw-alias-label-secondary);font-size:12px;}",
  ".dsw-arch-btn{background:transparent;border:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-primary);border-radius:6px;padding:3px 7px;font-size:12px;cursor:pointer;margin-right:4px;white-space:nowrap;}",
  ".dsw-arch-btn:hover:not(:disabled){border-color:var(--dsw-alias-brand-primary);color:var(--dsw-alias-brand-primary);}",
  ".dsw-arch-btn-danger{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary);}",
  ".dsw-arch-btn:disabled{opacity:0.45;cursor:default;}",
  ".dsw-arch-table{width:100%;border-collapse:collapse;table-layout:fixed;}",
  ".dsw-arch-table th{text-align:left;font-weight:600;color:var(--dsw-alias-label-secondary);font-size:12px;padding:6px 8px;border-bottom:1px solid var(--dsw-alias-border-l1);}",
  ".dsw-arch-table td{padding:8px 8px;border-bottom:1px solid var(--dsw-alias-border-l1);vertical-align:top;}",
  ".dsw-arch-table tr:last-child td{border-bottom:none;}",
  ".dsw-arch-table th:nth-child(1),.dsw-arch-table td:nth-child(1){width:32px;text-align:center;padding-left:2px;padding-right:2px;}",
  ".dsw-arch-table th:nth-child(2),.dsw-arch-table td:nth-child(2){width:auto;}",
  ".dsw-arch-table th:nth-child(3),.dsw-arch-table td:nth-child(3){width:104px;}",
  ".dsw-arch-table th:nth-child(4),.dsw-arch-table td:nth-child(4){width:92px;padding-left:2px;padding-right:2px;}",
  ".dsw-arch-size{white-space:nowrap;}",
  ".dsw-arch-actions{white-space:nowrap;}",
  ".dsw-arch-title-click{cursor:pointer;color:var(--dsw-alias-label-primary);}",
  ".dsw-arch-title-click:hover{text-decoration:underline;}",
  ".dsw-arch-id,.dsw-arch-path{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:11px;color:var(--dsw-alias-label-secondary);word-break:break-all;margin-top:2px;}",
  ".dsw-arch-selectbar{display:flex;align-items:center;gap:8px;padding:6px 10px;margin-bottom:10px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:8px;font-size:12px;flex-wrap:wrap;}",
  ".dsw-arch-selectbar .dsw-arch-meta{flex:1;}",
  ".dsw-arch-detail{background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:10px 12px;font-size:12px;text-align:left;}",
  ".dsw-arch-detail-head{margin-bottom:8px;}",
  ".dsw-arch-detail-body{max-height:360px;overflow:auto;}",
  ".dsw-arch-msg{margin-bottom:8px;white-space:pre-wrap;word-break:break-word;}",
  ".dsw-arch-msg-role{display:inline-block;font-weight:600;margin-right:6px;}",
  ".dsw-arch-msg-user .dsw-arch-msg-role{color:var(--dsw-alias-label-primary);}",
  ".dsw-arch-msg-assistant .dsw-arch-msg-role{color:var(--dsw-alias-brand-primary);}",
  ".dsw-arch-msg-tool .dsw-arch-msg-role{color:var(--dsw-alias-state-warn-primary);}",
  ".dsw-arch-msg-time{color:var(--dsw-alias-label-secondary);font-size:11px;margin-left:6px;}",
  ".dsw-arch-detail-note{color:var(--dsw-alias-label-secondary);font-size:11px;margin-bottom:8px;}",
  ".dsw-arch-error{color:var(--dsw-alias-state-error-primary);font-size:12px;margin-bottom:8px;}",
  ".dsw-arch-empty{color:var(--dsw-alias-label-secondary);padding:28px 0;text-align:center;}",
  ".dsw-arch-badge{display:inline-block;border:1px solid var(--dsw-alias-state-warn-primary);color:var(--dsw-alias-state-warn-primary);border-radius:4px;padding:1px 6px;font-size:11px;}"
].join("");

function ensureStyle(): void {
  try {
    if (document.getElementById(STYLE_ID)) return;
    const el = document.createElement("style");
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  } catch (e) {
    // ignore
  }
}

// ---------------------------------------------------------------------------
// API
// ---------------------------------------------------------------------------

function api<T>(action: string, args?: Record<string, unknown>): Promise<T> {
  return fetch("/dsh-archived/" + action, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(args || {})
  })
    .then((res) => res.json().catch(() => null))
    .then((payload: T | ApiEnvelope | null) => {
      if (payload === null || typeof payload !== "object") {
        throw new Error("请求失败：服务返回了无效响应");
      }
      if ("error" in payload && typeof payload.error === "string") {
        throw new Error(payload.error);
      }
      return payload as T;
    });
}

// ---------------------------------------------------------------------------
// Formatting
// ---------------------------------------------------------------------------

function fmtSize(bytes: number): string {
  const n = Number(bytes) || 0;
  if (n <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v = v / 1024;
    i = i + 1;
  }
  return (i === 0 ? String(Math.round(v)) : v.toFixed(1)) + " " + units[i];
}

function fmtTime(ms?: number | null): string {
  if (!ms) return "—";
  try {
    return new Date(ms).toLocaleString();
  } catch (e) {
    return String(ms);
  }
}

// ---------------------------------------------------------------------------
// Page component
// ---------------------------------------------------------------------------

function ArchivedSessionsPage() {
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [items, setItems] = React.useState<ArchivedItem[]>([]);
  const [total, setTotal] = React.useState(0);
  const [busy, setBusy] = React.useState<string | null>(null);
  const [confirmId, setConfirmId] = React.useState<string | null>(null);
  const [selected, setSelected] = React.useState<string[]>([]);
  const [batchBusy, setBatchBusy] = React.useState<string | null>(null);
  const [batchConfirm, setBatchConfirm] = React.useState<"clear" | "delete" | null>(null);
  const [expandedId, setExpandedId] = React.useState<string | null>(null);
  const [detail, setDetail] = React.useState<DetailState | null>(null);

  function describe(err: unknown): string {
    if (err === null || err === undefined) return String(err);
    if (typeof err === "object" && typeof (err as { message?: unknown }).message === "string") {
      return (err as { message: string }).message;
    }
    return String(err);
  }

  function applyList(res: ListResult): void {
    const next = res && Array.isArray(res.items) ? res.items : [];
    setItems(next);
    setTotal(res && typeof res.totalBytes === "number" ? res.totalBytes : 0);
    const ids: Record<string, boolean> = {};
    for (let i = 0; i < next.length; i++) ids[next[i].id] = true;
    setSelected((sel) => sel.filter((id) => ids[id]));
    if (expandedId && !ids[expandedId]) {
      setExpandedId(null);
      setDetail(null);
    }
  }

  function load(): void {
    setLoading(true);
    setError(null);
    api<ListResult>("list", {})
      .then((res) => {
        applyList(res);
        setLoading(false);
      })
      .catch((err) => {
        setError(describe(err));
        setLoading(false);
      });
  }

  React.useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
 * Refresh the sidebar/workbench views.
 *
 * Nothing to do: the Workspace registry's `setState` lands in the storage
 * domain, which emits `domain/changed`; the host-side workspace feed turns that
 * into an `archived` frame on the browser's follow stream, so the sidebar
 * projection updates itself. (The client `workspaces` service is a subscribe +
 * snapshot model with no `refresh()` to call.)
 */
function refreshViews(): void {}

  function reloadAfterAction(): Promise<void> {
    refreshViews();
    return api<ListResult>("list", {}).then(applyList);
  }

  // ---- row operations ----
  function unarchive(id: string): void {
    setBusy("unarchive:" + id);
    setError(null);
    api<unknown>("unarchive", { sessionId: id })
      .then(() => reloadAfterAction())
      .catch((err) => setError(describe(err)))
      .finally(() => setBusy(null));
  }

  // Single-button two-step delete: 删除 -> 确认 (auto-reverts after 5s).
  //
  // The browser timer globals are available to a plugin bundle (only dynamic
  // packages are guarded), and the host-side timer plugin is not on the browser
  // context, so a native timeout is the right tool here.
  function armDelete(id: string): void {
    setConfirmId(id);
    try {
      window.setTimeout(() => {
        setConfirmId((cur) => (cur === id ? null : cur));
      }, 5000);
    } catch (e) {
      // timer unavailable; stay armed until the user acts
    }
  }

  function doDelete(id: string): void {
    setBusy("delete:" + id);
    setError(null);
    api<unknown>("delete", { sessionId: id })
      .then(() => reloadAfterAction())
      .catch((err) => setError(describe(err)))
      .finally(() => {
        setBusy(null);
        setConfirmId(null);
      });
  }

  // ---- selection ----
  function toggleSelect(id: string): void {
    setSelected((sel) => (sel.includes(id) ? sel.filter((x) => x !== id) : sel.concat([id])));
  }

  function toggleSelectAll(): void {
    setSelected((sel) => (sel.length === items.length ? [] : items.map((item) => item.id)));
  }

  // ---- batch operations ----
  async function runBatch(ids: string[], kind: "delete" | "unarchive"): Promise<void> {
    setBatchBusy(kind);
    setError(null);
    const results: Array<{ id: string; ok: boolean }> = [];
    const method = kind === "delete" ? "delete" : "unarchive";
    for (const id of ids) {
      try {
        await api<unknown>(method, { sessionId: id });
        results.push({ id, ok: true });
      } catch (err) {
        results.push({ id, ok: false });
      }
    }
    const failed = results.filter((r) => !r.ok);
    if (failed.length > 0) {
      setError(
        (kind === "delete" ? "删除" : "释放") +
          "失败 " + failed.length + " 个会话：" + failed.map((f) => f.id).join(", ")
      );
    }
    refreshViews();
    try {
      applyList(await api<ListResult>("list", {}));
    } catch (err) {
      setError(describe(err));
    } finally {
      setBatchBusy(null);
      setBatchConfirm(null);
      setSelected([]);
      setConfirmId(null);
    }
  }

  function releaseAll(): void {
    runBatch(items.map((item) => item.id), "unarchive");
  }
  function clearAll(): void {
    runBatch(items.map((item) => item.id), "delete");
  }
  function releaseSelected(): void {
    runBatch(selected, "unarchive");
  }
  function deleteSelected(): void {
    runBatch(selected, "delete");
  }

  // ---- detail ----
  function toggleDetail(id: string): void {
    if (expandedId === id) {
      setExpandedId(null);
      setDetail(null);
      return;
    }
    setExpandedId(id);
    setDetail({ id, loading: true, data: null, error: null });
    api<DetailData>("detail", { sessionId: id })
      .then((data) => {
        setDetail({ id, loading: false, data, error: null });
      })
      .catch((err) => {
        setDetail({ id, loading: false, data: null, error: describe(err) });
      });
  }

  function detailCell(): React.ReactNode {
    if (!detail) return null;
    if (detail.loading) {
      return <div className="dsw-arch-detail">加载会话内容中…</div>;
    }
    if (detail.error) {
      return <div className="dsw-arch-detail">{detail.error}</div>;
    }
    const d = detail.data;
    if (!d || !Array.isArray(d.messages)) {
      return <div className="dsw-arch-detail">没有可显示的内容</div>;
    }
    const headParts: string[] = [];
    if (d.createdAt) headParts.push("创建于 " + fmtTime(d.createdAt));
    if (d.cwd) headParts.push(d.cwd);
    const msgs = d.messages.map((m, i) => {
      const roleLabel = m.role === "user" ? "用户" : m.role === "assistant" ? "助手" : "工具";
      return (
        <div key={i} className={"dsw-arch-msg dsw-arch-msg-" + m.role}>
          <span className="dsw-arch-msg-role">{roleLabel}</span>
          <span className="dsw-arch-msg-time">{fmtTime(m.time)}</span>
          <div>{m.text}</div>
        </div>
      );
    });
    return (
      <div className="dsw-arch-detail">
        <div className="dsw-arch-detail-head">
          <span className="dsw-arch-page-title">会话内容</span>
          <span className="dsw-arch-meta"> · {headParts.join(" · ")}</span>
        </div>
        <div className="dsw-arch-detail-note">
          共 {d.totalEvents} 条事件，提取 {d.messageCount} 条消息
          {d.truncated ? "（仅显示前 100 条）" : ""}
        </div>
        <div className="dsw-arch-detail-body">{msgs}</div>
      </div>
    );
  }

  // ---- render ----
  const anyBusy = busy !== null || batchBusy !== null;

  const header = (
    <div className="dsw-arch-toolbar">
      <span className="dsw-arch-page-title">归档会话</span>
      <span className="dsw-arch-meta">
        {items.length} 个会话 · 共 {fmtSize(total)}
        {loading ? " · 加载中…" : ""}
        {batchBusy ? " · 批量操作中…" : ""}
      </span>
      <button className="dsw-arch-btn" disabled={anyBusy} onClick={() => load()}>刷新</button>
      <button className="dsw-arch-btn" disabled={anyBusy || items.length === 0} onClick={() => releaseAll()}>一键释放</button>
      <button
        className="dsw-arch-btn dsw-arch-btn-danger"
        disabled={anyBusy || items.length === 0}
        onClick={() => setBatchConfirm("clear")}
      >一键清空</button>
    </div>
  );

  let confirmBar: React.ReactNode = null;
  if (batchConfirm === "clear") {
    confirmBar = (
      <div className="dsw-arch-selectbar">
        <span className="dsw-arch-meta" style={{ color: "var(--dsw-alias-state-warn-primary)" }}>
          确认清空全部 {items.length} 个归档会话？此操作会从硬盘删除且不可恢复。
        </span>
        <button className="dsw-arch-btn dsw-arch-btn-danger" disabled={anyBusy} onClick={() => clearAll()}>确认清空</button>
        <button className="dsw-arch-btn" disabled={anyBusy} onClick={() => setBatchConfirm(null)}>取消</button>
      </div>
    );
  } else if (batchConfirm === "delete") {
    confirmBar = (
      <div className="dsw-arch-selectbar">
        <span className="dsw-arch-meta" style={{ color: "var(--dsw-alias-state-warn-primary)" }}>
          确认删除选中的 {selected.length} 个会话？此操作不可恢复。
        </span>
        <button className="dsw-arch-btn dsw-arch-btn-danger" disabled={anyBusy} onClick={() => deleteSelected()}>确认删除</button>
        <button className="dsw-arch-btn" disabled={anyBusy} onClick={() => setBatchConfirm(null)}>取消</button>
      </div>
    );
  } else if (selected.length > 0) {
    confirmBar = (
      <div className="dsw-arch-selectbar">
        <span className="dsw-arch-meta">已选择 {selected.length} 个会话</span>
        <button className="dsw-arch-btn" disabled={anyBusy} onClick={() => releaseSelected()}>释放选中</button>
        <button className="dsw-arch-btn dsw-arch-btn-danger" disabled={anyBusy} onClick={() => setBatchConfirm("delete")}>删除选中</button>
        <button className="dsw-arch-btn" disabled={anyBusy} onClick={() => setSelected([])}>取消选择</button>
      </div>
    );
  }

  let body: React.ReactNode;
  if (loading && items.length === 0) {
    body = <div className="dsw-arch-empty">加载中…</div>;
  } else if (items.length === 0) {
    body = <div className="dsw-arch-empty">没有已归档的会话</div>;
  } else {
    const allSelected = selected.length === items.length;
    const rows = items.map((item) => {
      const confirming = confirmId === item.id;
      const metaParts: string[] = [];
      if (item.createdAt) metaParts.push("创建于 " + fmtTime(item.createdAt));
      if (item.cwd) metaParts.push(item.cwd);
      const chevron = expandedId === item.id ? "▾ " : "▸ ";
      return (
        <React.Fragment key={item.id}>
          <tr>
            <td>
              <input
                type="checkbox"
                checked={selected.includes(item.id)}
                disabled={anyBusy}
                onChange={() => toggleSelect(item.id)}
              />
            </td>
            <td>
              <div
                className="dsw-arch-title-click"
                title="点击查看会话内容"
                onClick={() => toggleDetail(item.id)}
              >
                {chevron}{item.title || "(无标题)"}
              </div>
              <div className="dsw-arch-id">{item.id}</div>
              <div className="dsw-arch-meta">{metaParts.join(" · ")}</div>
              {item.path ? <div className="dsw-arch-path">{item.path}</div> : null}
            </td>
            <td>
              {item.missing ? (
                <span className="dsw-arch-badge">文件缺失</span>
              ) : (
                <span className="dsw-arch-size">{fmtSize(item.sizeBytes)}</span>
              )}
            </td>
            <td className="dsw-arch-actions">
              <button
                className="dsw-arch-btn"
                disabled={anyBusy || item.missing}
                onClick={() => unarchive(item.id)}
              >释放</button>
              <button
                className="dsw-arch-btn dsw-arch-btn-danger"
                disabled={anyBusy}
                title={confirming ? "再次点击确认删除（5 秒后自动取消）" : "删除（需再次点击确认）"}
                onClick={() => (confirming ? doDelete(item.id) : armDelete(item.id))}
              >{confirming ? "确认" : "删除"}</button>
            </td>
          </tr>
          {expandedId === item.id ? (
            <tr key={item.id + "-detail"}>
              <td colSpan={4} style={{ padding: "4px 10px 10px" }}>{detailCell()}</td>
            </tr>
          ) : null}
        </React.Fragment>
      );
    });
    body = (
      <table className="dsw-arch-table">
        <thead>
          <tr>
            <th>
              <input
                type="checkbox"
                checked={allSelected}
                disabled={anyBusy}
                onChange={() => toggleSelectAll()}
              />
            </th>
            <th>会话</th>
            <th>磁盘占用</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>{rows}</tbody>
      </table>
    );
  }

  const errorEl = error ? <div className="dsw-arch-error">{error}</div> : null;

  return (
    <div className="dsw-arch-page">
      {errorEl}
      {header}
      {confirmBar}
      {body}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Plugin body
// ---------------------------------------------------------------------------

/**
 * Client-side service dependencies.
 *
 * `slots` (ui-renderer) is the registration seat. `workspaces`
 * (api-workspace-controller) is the live Workspace/archive projection the page
 * is about — it is injectable on 0.1.5-rc.1 and worth waiting for.
 *
 * Dropped from the original list: `sessions` (provided via
 * `ctx.reflect.provide`, not a Cordis service, so it is not injectable) and
 * `timer` (the page now uses a native `setTimeout`; the host-side timer plugin
 * is not on the browser context).
 */
export const inject = ["slots", "workspaces"];

export function apply(ctx: ClientCtx): void {
  ensureStyle();
  ctx.effect(() => {
    return () => {
      try {
        const el = document.getElementById(STYLE_ID);
        if (el) el.remove();
      } catch (e) {
        // ignore
      }
    };
  }, "ui-archived-sessions: style cleanup");

  ctx.slots.inject("settings.section", () =>
    ctx.slots.register(
      { name: "settings.section", id: "archived-sessions", order: 30, label: () => "归档会话" },
      () => React.createElement(ArchivedSessionsPage)
    )
  );
}
