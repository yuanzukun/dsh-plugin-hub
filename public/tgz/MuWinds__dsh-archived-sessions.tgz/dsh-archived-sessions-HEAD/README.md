# dsh-archived-sessions

归档会话管理（Archived sessions manager）—— DeepSeek Harness Web 界面的设置页扩展，以单 bundle 包分发，一条命令即可安装。

在 Harness 的「设置 → 归档会话」页面中提供：

- 查看所有已归档会话（标题、创建时间、所属目录、磁盘上的实际文件路径）
- 每个会话占用的磁盘空间与总占用
- 释放（取消归档，回到原工作区）—— 单个、批量、一键全部
- 从硬盘删除会话文件 —— 单个、批量、一键清空（两步确认）
- 点击会话标题展开查看会话内容（用户 / 助手 / 工具消息预览）

> ⚠️ **安全提示**：本插件包含「从硬盘删除会话文件」能力，删除不可恢复。安装即代表信任本仓库代码会在你的机器上以你的权限运行，请自行审阅源码。

## 安装（推荐：bundle 一键安装）

本包是一个声明了 `dsh.bundle` 的插件组合包，`lib/` 里已是构建好的纯 JavaScript，可直接从 GitHub 安装：

```sh
dsh plugin --profile web add github:MuWinds/dsh-archived-sessions
```

然后**重启 Harness**（`npx @deepseek-ai/dsh web`）。设置面板底部会出现「归档会话」页面。

> `lib/` 中的分发产物是纯 JS、没有 `prepare` 构建脚本，因此**不需要** pnpm `allowBuilds` 授权。若你习惯锁定版本，可钉住 commit：`github:MuWinds/dsh-archived-sessions#<sha>`。

### 从本地目录安装（开发调试）

```sh
dsh plugin --profile web add ./dsh-archived-sessions
```

> ⚠️ 路径含空格时不要直接写 `link:<路径>`：`dsh plugin` 会按空格切分参数，把路径拆成两个包（例如 `C:\...\Coding Project\pkg` 会被装成 `Coding` 和 `Project\pkg`）。先把目录 junction 到无空格路径，或改用绝对路径的 junction 再 link：

```powershell
New-Item -ItemType Junction -Path 'C:\dsh-archived-sessions' -Target 'C:\path with space\dsh-archived-sessions'
dsh plugin --profile web add 'link:C:\dsh-archived-sessions'
```

`dsh plugin --profile web remove @muwinds/dsh-archived-sessions` 可卸载（同时移除依赖与对应的 bundle 层）。

## 仓库结构

```
dsh-archived-sessions/
├── package.json          # dsh.bundle + dsh.client 声明（单包双端）+ 构建脚本
├── cordis.patch.yml      # 插入一行 archived-sessions（宿主端 + 浏览器端）
├── src/                  # TypeScript 源码（npm run build 编译到 lib/）
│   ├── index.ts          # 宿主端插件：webServer 路由 /dsh-archived/* + 全部业务逻辑
│   └── client.tsx        # 浏览器端插件：设置页 UI（JSX，编译后包装为 __ModuleLoader__ bundle）
├── lib/                  # 构建产物（package.json 的 main / exports 指向这里）
│   ├── index.js          # 由 src/index.ts 编译生成（ESM）
│   └── client.js         # 由 src/client.tsx 编译 + scripts/build-client.mjs 包装生成
├── scripts/
│   └── build-client.mjs  # 把编译后的 client 模块包装进 window.__ModuleLoader__.load({...})
├── tsconfig.json         # 宿主端编译配置（NodeNext / ESM → lib/index.js）
├── tsconfig.client.json  # 浏览器端编译配置（CommonJS + JSX → lib/.client/）
├── README.md
└── LICENSE               # MIT
```

## 开发与构建

源码是 TypeScript，`lib/` 里的 JS 由 `npm run build` 生成（`package.json` 的 `main` / `exports` 仍指向 `lib/`，安装与分发方式不变）：

```sh
npm install          # 安装 typescript 等开发依赖
npm run typecheck    # 仅做类型检查，不产出文件
npm run build        # tsc 编译宿主端 + 浏览器端，并生成 __ModuleLoader__ 包装
```

> 说明：`lib/` 是 `src/` 的编译产物，已按 `0.1.5-rc.1` 的契约重新构建。仓库没有 `prepare` 脚本，改动 `src/` 后需手动跑一次 `npm run build` 再提交；这也正是从 GitHub 直装无需 pnpm `allowBuilds` 授权的原因。

宿主端 API（`POST /dsh-archived/*`，无鉴权、同源）：

| 路由 | 请求体 | 返回 |
| --- | --- | --- |
| `/dsh-archived/list` | `{}` | `{ items, totalBytes }` |
| `/dsh-archived/unarchive` | `{ sessionId }` | `{ ok, changed, archivedSessionIds }` |
| `/dsh-archived/delete` | `{ sessionId }` | `{ ok, deleted, sessionId, path?, sizeBytes?, reason? }` |
| `/dsh-archived/detail` | `{ sessionId }` | `{ id, createdAt, cwd, totalEvents, messageCount, truncated, messages }` |

## 兼容性

- 目标 Harness 版本：`0.1.5-rc.1`（web profile 组合结构）。
- 宿主端插件无第三方运行时依赖（纯 ESM，不 import 任何 `@deepseek-ai/*`，需要的能力全部从 `ctx` 获取）；浏览器端仅依赖 `react`（由 Harness 前端运行时提供，属于 platform seed）。
- 浏览器端 `inject` 只需要 `slots` 与 `workspaces` 两个服务（`package.json` 的 `dsh.client.inject` 声明的是提供它们的包：`dsh-client-ui-renderer` / `dsh-api-workspace-controller`——前者是 seed 包，声明它只是为了让注册表里的依赖关系可读）。早期版本里声明的 `sessions` / `timer` 已移除：`sessions` 走的是 `ctx.reflect.provide`，不是 Cordis 服务、无法注入；`timer` 是宿主端插件，浏览器上下文里没有。
- 归档集合的写回依赖 `workspaceRegistry.setState()`；该调用会经由 storage domain 触发 `domain/changed`，宿主端 workspace feed 将其转成 `archived` 帧推给浏览器，侧边栏因此自动刷新，无需客户端主动 refresh。

### 0.1.0-rc.6 → 0.1.5-rc.1 的适配点

这一版 Harness 改了两个宿主端契约，旧代码会**静默出错**（不报错，但数据全错 / 删除无效）：

| 契约 | 旧假设 | 0.1.5-rc.1 实际 |
| --- | --- | --- |
| `sessionPersistence.list()` | 返回裸 header 数组 | 返回 `{ header, revision, sizeBytes }` 快照数组 |
| `fs.resolve()` | 返回路径字符串，配 `fs.processPath()` | 返回 `{ displayPath, targetKey }` 句柄，`processPath` 已不存在 |

已按新契约修正（`headerOf()` 同时兼容两种形状；`dirSizeOfTarget()` 全程传递句柄，支持会话目录下的嵌套子目录）。

## License

MIT
