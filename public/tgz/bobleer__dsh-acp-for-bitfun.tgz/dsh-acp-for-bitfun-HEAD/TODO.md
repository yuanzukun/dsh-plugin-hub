# TODO

- [x] 补充 dsh-plugin 接入说明（README.md）
- [x] 添加使用示例（README.md「安装」与「配置」章节）
- [ ] 发布到 npm registry（`npm publish`，之后 `dsh plugin add dsh-acp-for-bitfun` 直接可用）
- [ ] 添加自动化冒烟测试（协议层：bitfun acp 与 ACP SDK 的 initialize/prompt 往返）
- [ ] 跟随 deepseek-harness 的 rc 版本节奏升级依赖（当前 0.1.0-rc.6）
- [ ] 评估连接复用：BitFun ACP server 支持多 session，可考虑常驻进程替代每任务冷启动
