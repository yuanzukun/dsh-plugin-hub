/**
 * Idea-layer schemas: IdeaCard with gap, nearest prior works, counter-search,
 * falsifiability, MVE and Pareto scores (design §4.5, §6.3).
 * @module @dsh-scholar/research-schemas
 */

import { z } from 'zod'

/** Nearest prior work comparison entry. */
export const NearestPriorWork = z.object({
  paper_id: z.string().min(1),
  same: z.array(z.string()).default([]),
  different: z.array(z.string()).default([]),
})
export type NearestPriorWork = z.infer<typeof NearestPriorWork>

/** Minimum viable experiment definition. */
export const MveDefinition = z.object({
  dataset: z.string().min(1),
  baseline: z.string().min(1),
  primary_metric: z.string().min(1),
  estimated_gpu_hours: z.number().nonnegative().default(1),
  expected_runtime: z.string().default(''),
})
export type MveDefinition = z.infer<typeof MveDefinition>

/** Novelty counter-search record: queries + outcome + unresolved risk. */
export const NoveltyAudit = z.object({
  queries: z.array(z.string()).default([]),
  result: z.enum(['no_direct_match_found', 'overlap_found', 'inconclusive']),
  overlap_papers: z.array(z.string()).default([]),
  unresolved_risk: z.enum(['low', 'medium', 'high']).default('medium'),
  audited_at: z.string(),
})
export type NoveltyAudit = z.infer<typeof NoveltyAudit>

/**
 * Model-produced IdeaCard body before Kernel identity/provenance fields are
 * attached. Keeping this schema separate makes the model boundary explicit:
 * the model may propose scientific content, but it cannot choose project,
 * corpus, status, version, ids or timestamps.
 */
export const IdeaDraft = z.object({
  title: z.string().min(1).max(300),
  hypothesis: z.string().min(1).max(4_000),
  scientific_gap: z.object({
    claims: z.array(z.string().min(1).max(1_000)).min(1).max(12),
    statement: z.string().min(1).max(4_000),
  }).strict(),
  nearest_prior_works: z.array(NearestPriorWork).min(1).max(12),
  exact_delta: z.string().min(1).max(4_000),
  falsification: z.object({
    observation: z.string().min(1).max(4_000),
  }).strict(),
  minimum_viable_experiment: MveDefinition,
  scores: z.object({
    feasibility: z.number().int().min(1).max(5),
    information_gain: z.number().int().min(1).max(5),
    reproducibility: z.number().int().min(1).max(5),
    cost: z.number().int().min(1).max(5),
  }).strict(),
  risk_notes: z.string().max(4_000).default(''),
}).strict()
export type IdeaDraft = z.infer<typeof IdeaDraft>

/** A structured, auditable candidate idea. */
export const IdeaCard = z.object({
  idea_id: z.string().regex(/^idea_[a-z0-9_]+$/),
  project_id: z.string().min(1),
  version: z.number().int().positive().default(1),
  // v2 shape (domain-model.md §6): every idea bound to a frozen Corpus
  // snapshot BEFORE its Idea Gate decision. NULLABLE for pre-v2 cards —
  // old cards keep working and simply skip the gate binding check; new
  // cards are expected to carry it (kernel validates at Gate decision).
  corpus_snapshot_id: z.string().nullable().default(null),
  title: z.string().min(1),
  hypothesis: z.string().min(1),
  scientific_gap: z.object({
    claims: z.array(z.string()).default([]),
    statement: z.string().default(''),
  }).default({ claims: [] }),
  nearest_prior_works: z.array(NearestPriorWork).default([]),
  exact_delta: z.string().min(1),
  falsification: z.object({
    observation: z.string().min(1),
  }),
  minimum_viable_experiment: MveDefinition,
  novelty_audit: NoveltyAudit.optional(),
  scores: z.object({
    feasibility: z.number().int().min(1).max(5),
    information_gain: z.number().int().min(1).max(5),
    reproducibility: z.number().int().min(1).max(5),
    cost: z.number().int().min(1).max(5),
  }),
  risk_notes: z.string().default(''),
  status: z.enum(['proposed', 'approved', 'rejected', 'archived']).default('proposed'),
  created_at: z.string(),
  updated_at: z.string(),
})
export type IdeaCard = z.infer<typeof IdeaCard>
