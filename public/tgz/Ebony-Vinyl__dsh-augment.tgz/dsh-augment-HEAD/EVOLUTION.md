# dsh augment — 自我进化机制

0.0.1 预览版的边界很明确：**模型权重不变，进化的是模型外部的 harness**。这与 Harness²、GEPA、Continual Harness、PenguinHarness 的共识一致——在桌面插件里，可安全、可审计、可回滚的自我改进对象是提示词、记忆、技能、工具指导、子代理、脚本和模型路由，而不是模型参数。

## 1. 8 个可进化组件

| 组件 | 作用 |
|---|---|
| `systemPrompt` | 角色、目标、输出约束与任务策略 |
| `guardrails` | 安全、隐私、不可逆操作与审批边界 |
| `memory` | 跨任务事实、token、偏好与已验证经验 |
| `toolGuidance` | 何时读、何时搜、何时验证与重试 |
| `subagents` | 可复用的委派角色与工具白名单 |
| `skills` | `SKILL.md` 形式的工作流与检查清单 |
| `scripts` | 沙箱中可验证的辅助脚本 |
| `plugins` | 已启用插件的能力说明与路由偏好 |

`lib/evolution/harness.js` 负责树校验、差异、指纹和多样性。组件有 24,000 字符上限，整棵树 96,000 字符；拒绝控制字符、双向覆盖字符和未知组件。采纳的 harness 通过 `agent.ctx.systemPrompt.section({ name: 'dsh-augment:evolved', order: 710 })` 注入，并在会话段内冻结以保护 KV cache。

## 2. 双层递归

### 任务级：Propose–Probe–Compose

```
Observe → Reflect → Propose (通用 + 领域候选) → Probe (dev minibatch)
        → Compose (合并互补编辑) → Select (盲评) → Validate (held-out) → Adopt
```

- **Observe**：从 `session.snapshotEvents()` 归一化轨迹，提取工具调用、错误、重复调用、用户纠正和测试失败信号。
- **Reflect**：让模型读轨迹，输出失败模式、逐字证据和最小编辑；没有证据的反思直接拒绝。
- **Propose**：按算子生成候选；每个候选必须带摘要、证据、预期影响、风险和 token 预算。
- **Probe**：在 dev 任务上执行候选，记录分数、token、调用数和轨迹。
- **Compose**：合并互补编辑；live 模式让 improver 组合，simulated 模式用确定性合并。
- **Select**：候选匿名化为 A/B/C，路径和标签盲化；选择器只看开发集表现和 harness，不看身份。
- **Validate**：在 held-out 任务上跑四臂评测，配对 bootstrap；只有正向 CI 下界且无回归才采纳。

### 改进级：元进化

`lib/evolution/meta.js` 用 UCB1 bandit 记录每个算子的尝试/成功率与平均奖励，动态调整后续候选的算子选择；UI 的“组件 → 算子”区域展示权重迁移。这个第二层递归让“改进机制本身”也成为被改进的对象。

## 3. 候选算子

| 算子 | 来源 | 机制 |
|---|---|---|
| `reflective-edit` | GEPA | 读轨迹 + 逐任务反馈，做一处有针对性的编辑 |
| `ppc-general` | Harness² | 通用候选，Probe 后 Compose |
| `ppc-domain` | Harness² | 领域候选，Probe 后 Compose |
| `ace-lesson` | ACE / PenguinHarness | 从成功/失败轨迹抽取可复用 lesson |
| `opro` | OPRO | 从历史分数生成指令候选 |
| `ape` | APE | 从示例归纳指令 |
| `awm` | AWM | 从成功运行归纳工作流 |
| `skill-opt` | SkillOpt / SkillAdam | 有界编辑 `SKILL.md` |
| `trace-skill` | TRACE | 对比轨迹，进化技能库 |
| `routing` | Airbnb AHO | 按任务特征学习模型/推理强度路由 |

## 4. 评测协议

### Capability Gym

12 个任务模板，每个模板 2 个 held-out 变体：

- 上下文检索（read-before-answer）
- 代码修复 + 测试（verify-before-answer）
- 精确输出契约（format-checklist）
- 记忆召回（memory-recall）
- 瞬时错误重试（retry-on-error）
- 多步规划（plan-steps）
- 仓库入口定位（use-repo-map）
- 逐字引用（cite-evidence）
- 大日志检索（token-efficiency）
- 工具选择（tool-choice）
- 失败诊断（error-diagnosis）
- 有预算摘要（summarize）

每个任务有 fixture、公开 prompt、隐藏 grader、最大步数和超时。grader 在本地运行：答案精确/包含/JSON/摘要检查，代码在 sandbox 中跑测试，产物检查文件内容。

### 四臂

- `baseline`：基线 harness。
- `equal-compute`：同等调用预算下的基线（多次 trial，取平均/最优）。
- `full-rsi`：候选 harness。
- `reuse-only`：基线 harness + 经验库注入，不重新进化。

### 统计与采纳门

- 按任务配对，任务级 percentile bootstrap（默认 10,000 次，seed 42）。
- 两个主比较（`baseline`、`equal-compute`）用 Bonferroni 校正到 97.5%。
- `verified`：两个主比较的 CI 下界 > 0，且没有任务回归超过 5%。
- `no-gain`：至少一个主比较非正，或有任务回退；不采纳。
- `incomplete`：有臂没有完成全部任务。
- `exploratory`：CI 包含 0，证据不足。

`verified` 是评测级结论，不保证未来任务一定提升；报告里始终显示 CI、样本量和成本。

**预算边界**：`maxCalls` / `maxTokens` / `maxMinutes` 是**进化运行**的硬上限（含反思、提议、选择、验证）。独立评测（benchmark）按 `4 臂 × 任务数` 估算调用量，不受运行预算截断，报告里显示实际消耗；UI 在启动前显示预计调用数。

## 5. 经验库与持续学习

经验类型：`lesson`、`skill`、`memory`、`subagent`、`routing`。

作用域：`workspace + provider + model + simulated`。全局/会话本地；本地覆盖全局。Windows 路径会做大小写归一化。

抽取门：只从“已完成 + 已交付 + 采纳版本确实被使用”的轨迹抽取；证据必须是本会话逐字出现的 8–1200 字符片段。反思证据不足时返回空 lesson，不写入。

检索：词法 + CJK bigram + 新鲜度 + 置信度 + 复用次数；按 token 预算排序注入。`renderContext` 会先用一个比内容中最长反引号串更长的围栏包住经验，防止经验文本闭合围栏。

生命周期：`candidate → adopted → verified → archived/frozen`；CAS 版本、谱系、回滚。只有 `adopted`/`verified` 会进入提示词。

## 6. 模型路由

默认 executor/improver/selector/judge 都是 `agnes / agnes-3.0-flash`。评测后可以按任务域学习路由规则（成功率/成本/置信度），在“记忆 → 模型路由”查看；没有足够证据时保持默认路由。

## 7. 任务内自修复

监听 `tools/post-execute`：工具失败时，如果本 turn 修复提示 < 2 次、距上次提示 ≥ 3 次调用，就注入一条 `[dsh augment: self-repair]` 提示。优先使用经验库中相关 lesson；没有则用通用提示：“检查错误、改变一个假设、重试一次，不要重复相同调用”。不注入停止/完成类指令。

## 8. 安全、审计与回滚

- 生成代码只在 `worker_threads + vm` 沙箱运行：无 `require`、无 `process`、无 fs/网络、1s 超时、输出 ≤1MB；默认关闭自动执行。
- 所有反思/经验文本过 secret 检测、控制字符/双向覆盖检测、prompt injection 检测。
- 评测集/隐藏 grader 不进入反思上下文。
- 破坏性命令在 probe 中默认阻断。
- 采纳/回滚/冻结写 `audit.jsonl`；版本可一键回滚。
- 数据保留：默认 30 天，按条数/大小 LRU。

## 9. 运行方式

### UI

设置 → dsh augment → 自我进化：

- 总览：能力趋势、Pareto、组件雷达、活动流。
- 工作台：模拟/实时、k、dev/held-out 任务数、自动采纳；阶段时间线、候选 diff、采纳/回滚。
- 评测中心：四臂、热力图、CI、Pareto、协议指纹、导出。
- 经验库/组件/记忆/设置。

### 脚本

```bash
npm test
node scripts/evolution-smoke.mjs        # 模拟进化 + held-out 验证
node scripts/build-client.mjs           # 构建客户端
node scripts/save-simulated-harness.mjs # 把 6-feature 模拟 harness 保存为候选
```

### HTTP

```bash
# 启动一次实时进化（在 DSH 渲染器内 fetch，或通过宿主 webServer）
POST /plugins/dsh-augment/evolution/actions
{ "action": "run/start", "mode": "live", "k": 3, "devTasks": 6, "heldoutTasks": 12 }

# 启动一次评测
POST /plugins/dsh-augment/evolution/benchmark
{ "mode": "live", "tasks": 8, "reps": 1, "versionId": "hv-..." }
```

SSE：`GET /plugins/dsh-augment/evolution/events?token=<uiToken>`。

## 10. 数据布局

```
~/.dsh/dsh-augment/evolution/
  config.json
  runs/<id>.json
  runs/stages/<runId>/<stageId>.json
  versions/<id>.json
  active.json
  experiences.json
  evaluations/<id>.json
  reports/<id>.json|md
  gym/<id>/...
  audit.jsonl
  meta.json
```

## 11. 已知限制

- **指令稀释**：实测在 `agnes-3.0-flash` 上，把 6 条能力规则（约 1,185 字符）叠加进提示词后，held-out 平均分从 62.5% **降到** 37.5%（3 个原本答对的任务答错）。提示词堆叠不是免费收益；系统会用 `no-gain` 拒绝这类候选，概览页在 harness 超过 1,200 字符时显示风险提示。
- 实时进化的效果取决于模型能力与任务分布；`agnes-3.0-flash` 在简单任务上可能已经满分，提升空间小。没有正向 CI 时系统会显示 `no-gain`，不会伪造提升。
- 评测是本地确定性任务，不代表所有真实工作负载。
- 实时评测按任务串行，单任务约 3–5 分钟；8 任务 × 4 臂约 40–60 分钟、约 100 次调用。
- 生成代码的 sandbox 是 bounded evaluation sandbox，不是对抗性安全边界；执行生成技能仍需审批。
- 宿主 API 在 0.2.x 内可能漂移；插件对可选服务做 `ctx.get` 探测和 try/catch 降级。
- 实时运行受预算/时间上限约束；超出会失败并保留已完成的阶段。
