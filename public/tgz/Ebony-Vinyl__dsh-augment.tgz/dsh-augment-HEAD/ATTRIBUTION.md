# 思想来源与归属

`dsh augment` 0.0.1 预览版的自我进化层是独立实现；下列项目提供了机制、协议和工程约束上的思想来源。没有复制其源代码；所有宿主接入、数据模型、UI 和评测实现均为本项目重新编写。若后续引入任何直接移植的代码，会在文件头和本文件中单独标注许可证。

## 核心参考

| 项目 | 吸收的思想 |
|---|---|
| **Harness²**（Google Research，`google-research/harness2`） | 8 个可进化组件；Propose–Probe–Compose；任务级 + 改进级双层递归；parallel/sequential 模式；held-out 评测与采纳。 |
| **GEPA**（`gepa-ai/gepa`，arXiv:2507.19457） | 对执行轨迹做自然语言反思；Pareto 保留多样候选；minibatch rollout；Actionable Side Information（ASI）作为“文本梯度”；比 RL 更省样本。 |
| **Continual Harness**（`sethkarten/continual-harness`） | 任务进行中按窗口做 prompt / subagent / skill / memory 的 CRUD；失败模式检测（循环、失败工具、停滞、漏探索）；不 reset 的在线改进。 |
| **PenguinHarness**（`Prism-Shadow/penguin-harness`） | 算子库（default/OPRO/APE/ACE/AWM/SkillAdam/SkillOpt/TRACE）；候选版本快照；Evaluation Center；成本对比；技能库与可回放轨迹。 |
| **dsh-continual-harness**（`jasen215/dsh-continual-harness`） | 跨会话持久状态；prompt/memory/skill/subagent 四类经验；全局/会话作用域；排序注入；A/B benchmark；refinement 历史与 rollback。 |
| **Airbnb AHO** — *Beyond Prompts: Measuring and Optimizing LLM Tool-Agent Harnesses*（EMNLP 2026） | harness 优化是资源受限搜索；可靠性/脆性比单次分数更重要；生产级验证门与可运维性。 |
| **Awesome RSI**（`lobehub/awesome-rsi`） | RSI 分类法；held-out 验证、模块隔离、编辑预算、provenance、rollback、独立评测与安全边界。 |
| **dsh-evolution**（DSH 生态插件） | DSH 宿主接入配方（`ctx.llm.prepareCall`、`ctx.agents.create`、作用域工具/提示）；任务级配对 bootstrap；树校验/差异/多样性；盲评；工作区安全快照；学习存储的 CAS/预算/证据约束。本项目未修改该仓库，也未复制其 TypeScript 源码；上述内容以纯 JS 重新实现。 |

## 其他工程参考

- **DeepSeek Harness / Cordis**：`ctx.inject`、`ctx.effect`、`agent/pre-step`、`tools/post-execute`、`llm/stream`、`agent/status`、`settings.section`、`webServer.register`。
- **Node.js**：`worker_threads`、`vm`、`node:test`、`AbortSignal`。
- **esbuild**：客户端打包（仅开发时使用；发布包包含构建产物）。

## 许可证

本项目 MIT。上述项目的许可证以其仓库为准；本文件仅做思想归属，不构成对其代码的再分发。
