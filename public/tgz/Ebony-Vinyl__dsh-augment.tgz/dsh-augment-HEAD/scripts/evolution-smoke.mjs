import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { EvolutionStore } from '../lib/evolution/store.js'
import { EvolutionEngine } from '../lib/evolution/engine.js'
import { baseHarness, featureTags, renderHarness } from '../lib/evolution/harness.js'
import { createSimulatedAdapter } from '../lib/evolution/gym/simulated.js'
import { buildSuite } from '../lib/evolution/gym/tasks.js'
import { sanitizeEvolutionConfig } from '../lib/evolution/config.js'
import { reportMarkdown } from '../lib/evolution/evaluate.js'

const root = path.resolve(import.meta.dirname, '..')
const runId = `sim-${Date.now().toString(36)}`
const store = new EvolutionStore(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-augment-sim-')), 'evolution'))
const config = sanitizeEvolutionConfig({
  k: 3,
  autoAdopt: true,
  maxCalls: 10000,
  maxTokens: 100000000,
  maxMinutes: 60,
  gym: { seed: 42, reps: 1, devTasks: 12, heldoutTasks: 24 },
})
const suite = buildSuite()
const adapter = createSimulatedAdapter({ seed: 42 })
const engine = new EvolutionEngine({ store, adapter, config })
const started = Date.now()
const run = await engine.run({
  runId,
  devTasks: suite.dev,
  heldoutTasks: suite.heldout,
  baseTree: baseHarness(),
  experiences: [],
  config,
})
const evaluation = run.evaluationId ? store.loadEvaluation(run.evaluationId) : null
const active = store.activeVersion()
const report = {
  generatedAt: new Date().toISOString(),
  mode: 'simulated',
  runId: run.id,
  status: run.status,
  validationStatus: run.metrics.validationStatus,
  baselineScore: run.metrics.baselineScore,
  evolvedScore: run.metrics.evolvedScore,
  delta: run.metrics.delta,
  ci: run.metrics.ci,
  features: active ? featureTags(active.tree) : [],
  activeVersion: active?.id || null,
  usage: run.usage,
  elapsedMs: Date.now() - started,
  armSummaries: evaluation?.armSummaries || {},
  comparisons: evaluation?.comparisons?.map((item) => ({
    candidate: item.candidate, comparator: item.comparator, delta: item.delta, ci: item.ci, n: item.n, confidence: item.confidence,
  })) || [],
  regressions: evaluation?.regressions || [],
  stages: run.stages.map((stage) => ({ label: stage.label, kind: stage.kind, status: stage.status, score: stage.score ?? null })),
  harnessPreview: active ? renderHarness(active.tree) : '',
}
const jsonFile = path.join(root, 'docs/evolution-simulated.json')
const mdFile = path.join(root, 'docs/evolution-simulated.md')
fs.writeFileSync(jsonFile, `${JSON.stringify(report, null, 2)}\n`, 'utf8')
const lines = [
  '# dsh augment — 模拟进化验证',
  '',
  `- 运行：\`${report.runId}\``,
  `- 模式：simulated（确定性 Capability Gym，不调用外部模型）`,
  `- 状态：**${report.validationStatus}**`,
  `- 基线：${(report.baselineScore * 100).toFixed(1)}%`,
  `- 进化后：${(report.evolvedScore * 100).toFixed(1)}%`,
  `- Δ：+${(report.delta * 100).toFixed(1)} 个百分点`,
  `- 95% CI：[${report.ci.map((value) => (value * 100).toFixed(1)).join('%, ')}%]`,
  `- 采纳版本：\`${report.activeVersion}\``,
  `- 能力标签：${report.features.join(', ')}`,
  `- 用时：${(report.elapsedMs / 1000).toFixed(1)}s`,
  '',
  '## 阶段',
  '',
  '| 阶段 | 类型 | 状态 | 开发集评分 |',
  '|---|---|---|---:|',
  ...report.stages.map((stage) => `| ${stage.label} | ${stage.kind} | ${stage.status} | ${stage.score === null ? '—' : (stage.score * 100).toFixed(1) + '%'} |`),
  '',
  evaluation ? reportMarkdown(evaluation) : '',
  '',
  '> 该报告证明进化算法、评测协议和采纳门在确定性环境中端到端工作。它不代表真实模型上的必然提升；实时结果见 EVOLUTION-REPORT.md。',
]
fs.writeFileSync(mdFile, lines.join('\n'), 'utf8')
console.log(`simulated run ${run.id}`)
console.log(`status=${run.metrics.validationStatus} baseline=${(run.metrics.baselineScore * 100).toFixed(1)}% evolved=${(run.metrics.evolvedScore * 100).toFixed(1)}% delta=+${(run.metrics.delta * 100).toFixed(1)}pp ci=[${run.metrics.ci.map((value) => (value * 100).toFixed(1)).join(', ')}]`)
console.log(`features: ${report.features.join(', ')}`)
console.log(`wrote ${path.relative(root, jsonFile)} and ${path.relative(root, mdFile)}`)
if (run.metrics.validationStatus !== 'verified' || run.metrics.delta < 0.2) {
  console.error('simulated smoke did not meet the acceptance threshold (verified and delta >= 0.2)')
  process.exit(1)
}
