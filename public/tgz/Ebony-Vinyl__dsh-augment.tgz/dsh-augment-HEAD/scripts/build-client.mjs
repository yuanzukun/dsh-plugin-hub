import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import { pathToFileURL } from 'node:url'
import { atomicWriteFile } from '../lib/util.js'

const root = path.resolve(import.meta.dirname, '..')
const entry = path.join(root, 'lib/client/index.js')
const outfile = path.join(root, 'lib/client.js')

async function loadEsbuild() {
  try {
    const mod = await import('esbuild')
    return mod.default ?? mod
  } catch {}
  if (process.env.ESBUILD_PATH) {
    try {
      const mod = await import(pathToFileURL(process.env.ESBUILD_PATH).href)
      return mod.default ?? mod
    } catch {}
  }
  throw new Error('esbuild is not available. Run `npm install` first, or set ESBUILD_PATH to esbuild/lib/main.js.')
}

const esbuild = await loadEsbuild()
const result = await esbuild.build({
  entryPoints: [entry],
  bundle: true,
  write: false,
  format: 'cjs',
  platform: 'browser',
  target: 'es2022',
  minify: true,
  sourcemap: false,
  legalComments: 'none',
  external: [
    'react',
    'react-dom',
    'react/jsx-runtime',
    '@deepseek-ai/cordis',
    '@deepseek-ai/dsh-client-ui-slots',
  ],
  logLevel: 'silent',
})
const code = result.outputFiles?.[0]?.text || ''
if (!code) throw new Error('esbuild produced no output')
const wrapped = `window.__ModuleLoader__.load({\n  id: 'dsh-augment',\n  factory: (require) => {\n    var module = { exports: {} };\n    var exports = module.exports;\n${code}\n    return module.exports;\n  },\n})\n`
atomicWriteFile(outfile, wrapped)
const bytes = Buffer.byteLength(wrapped)
const gzip = zlib.gzipSync(wrapped).length
console.log(`built ${path.relative(root, outfile)}: ${(bytes / 1024).toFixed(1)} KiB (${(gzip / 1024).toFixed(1)} KiB gzip)`)
if (gzip > 500 * 1024) console.warn('warning: client bundle exceeds 500 KiB gzip')
