#!/usr/bin/env node
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { performance } from 'node:perf_hooks'
import { DEFAULT_CONFIG } from '../lib/config.js'
import { compressText } from '../lib/pipeline.js'
import { estimateTokens } from '../lib/tokens.js'
import { RepoMap } from '../lib/repo-map.js'
import { CcrStore } from '../lib/ccr.js'

function logText(kb) {
  const lines = []
  let size = 0
  let i = 0
  while (size < kb * 1024) {
    const line = `2026-10-30T12:00:${String(i % 60).padStart(2, '0')}Z INFO step=${i} component=worker payload=${'x'.repeat(80)}`
    lines.push(line)
    size += line.length + 1
    i++
  }
  return lines.join('\n')
}

function diffText(kb) {
  const lines = ['diff --git a/src/a.ts b/src/a.ts', 'index abc..def 100644', '--- a/src/a.ts', '+++ b/src/a.ts', '@@ -1,9999 +1,9999 @@']
  let size = 0
  let i = 0
  while (size < kb * 1024) {
    const line = i % 10 === 0 ? `-const old${i} = ${i}` : ` context line ${i} ${'y'.repeat(80)}`
    lines.push(line)
    size += line.length + 1
    i++
    if (i % 10 === 0) {
      const add = `+const next${i} = ${i}`
      lines.push(add)
      size += add.length + 1
    }
  }
  return lines.join('\n')
}

function htmlText(kb) {
  const parts = ['<html><head><style>.x{color:red}</style></head><body>']
  let size = 0
  let i = 0
  while (size < kb * 1024) {
    const part = `<p>Paragraph ${i} ${'x'.repeat(100)}</p>`
    parts.push(part)
    size += part.length
    i++
  }
  parts.push('<script>alert(1)</script></body></html>')
  return parts.join('')
}

function jsonText(kb) {
  const items = []
  let i = 0
  while (JSON.stringify(items).length < kb * 1024) {
    items.push({ id: i, name: `item-${i}`, value: 'x'.repeat(80), tags: ['a', 'b', 'c'] })
    i++
  }
  return JSON.stringify({ items }, null, 2)
}

function bench(name, text, iterations) {
  let result
  const start = performance.now()
  for (let i = 0; i < iterations; i++) {
    result = compressText(text, { tool: 'bash', config: DEFAULT_CONFIG, allowStore: false })
  }
  const ms = (performance.now() - start) / iterations
  console.log([
    name.padEnd(12),
    `${(text.length / 1024).toFixed(0).padStart(6)} KB`,
    `${iterations.toString().padStart(3)}x`,
    `${ms.toFixed(2).padStart(8)} ms`,
    `${(result.before ?? 0).toString().padStart(7)} -> ${(result.after ?? 0).toString().padStart(7)}`,
    `saved ${String(result.saved ?? 0).padStart(7)}`,
    result.tech ?? 'none',
  ].join('  '))
}

console.log('compression pipeline (allowStore=false, pure CPU)')
console.log('name            size      iter      avg       tokens before -> after      saved  tech')
for (const kb of [10, 100, 1000, 2000]) {
  bench(`log-${kb}kb`, logText(kb), kb >= 1000 ? 5 : 20)
}
bench('diff-100kb', diffText(100), 10)
bench('html-100kb', htmlText(100), 10)
bench('json-100kb', jsonText(100), 10)

const big = logText(2000)
let tokens = 0
const t0 = performance.now()
for (let i = 0; i < 10; i++) tokens = estimateTokens(big)
const tokenMs = (performance.now() - t0) / 10
console.log(`\nestimateTokens: ${(big.length / 1024 / 1024).toFixed(1)} MB -> ${tokens} tokens, ${tokenMs.toFixed(2)} ms/pass`)

const repoRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-augment-bench-repo-'))
for (let d = 0; d < 10; d++) {
  const dir = path.join(repoRoot, `src${d}`)
  fs.mkdirSync(dir, { recursive: true })
  for (let f = 0; f < 50; f++) {
    fs.writeFileSync(path.join(dir, `file${f}.js`), `import x from './file${(f + 1) % 50}.js'\nexport const value${f} = ${f}\n`)
  }
}
const repoMap = new RepoMap(fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-augment-bench-map-')), { maxFiles: 8000, maxDepth: 6, maxTokens: 700 }, console)
const t1 = performance.now()
const map = await repoMap.build(repoRoot)
const mapMs = performance.now() - t1
console.log(`repo map: 500 files -> ${map.fileCount} files, ${map.text.length} chars, ${mapMs.toFixed(0)} ms (budgeted, background)`)
fs.rmSync(repoRoot, { recursive: true, force: true })

const ccrDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-augment-bench-ccr-'))
const ccr = new CcrStore(ccrDir, { enabled: true, ttlDays: 7, maxStoreMB: 200, pageBytes: 8192 }, { warn: () => {} })
const ccrText = logText(2000)
const ccrPutStart = performance.now()
const ccrId = await ccr.put(ccrText, { sessionId: 'bench', tool: 'bash' })
const ccrPutMs = performance.now() - ccrPutStart
const ccrPageStart = performance.now()
const ccrPage = await ccr.page(ccrId, 0, 8192)
const ccrPageMs = performance.now() - ccrPageStart
console.log(`CCR async: put 2MB ${ccrPutMs.toFixed(0)} ms, page ${ccrPageMs.toFixed(1)} ms (${ccrPage?.text.length ?? 0} bytes)`)
ccr.dispose()
fs.rmSync(ccrDir, { recursive: true, force: true })
