#!/usr/bin/env node
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const pluginDir = path.resolve(fileURLToPath(new URL('..', import.meta.url)))
const dshHome = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const profileDir = path.join(dshHome, 'profiles', 'desktop')
const pkgFile = path.join(profileDir, 'package.json')
const patchFile = path.join(profileDir, 'cordis.patch.yml')
const lockFile = path.join(profileDir, 'pnpm-lock.yaml')
const args = new Set(process.argv.slice(2))
const dryRun = args.has('--dry-run')
const force = args.has('--force')

function fail(message) {
  console.error(`\n[install] ${message}`)
  process.exit(1)
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'))
}

function writeJson(file, value) {
  fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`)
}

function isAppRunning() {
  if (process.platform !== 'win32') return false
  try {
    const out = execFileSync('tasklist', ['/FI', 'IMAGENAME eq DeepSeek Harness.exe'], { encoding: 'utf8', windowsHide: true })
    return out.includes('DeepSeek Harness.exe')
  } catch {
    return false
  }
}

function findPnpm() {
  if (process.env.DSH_PNPM) return { command: process.execPath, args: [process.env.DSH_PNPM] }
  if (process.env.DSH_APP_ROOT) {
    const candidate = path.join(process.env.DSH_APP_ROOT, 'resources', 'runtime', 'primary-runtime', 'dependencies', 'pnpm', 'bin', 'pnpm.mjs')
    if (fs.existsSync(candidate)) return { command: process.execPath, args: [candidate] }
  }
  return { command: process.platform === 'win32' ? 'pnpm.cmd' : 'pnpm', args: [] }
}

if (!fs.existsSync(pkgFile)) fail(`profile package.json not found: ${pkgFile}`)
if (!fs.existsSync(patchFile)) fail(`profile cordis.patch.yml not found: ${patchFile}`)
if (isAppRunning() && !force) {
  fail('DeepSeek Harness is running. Close it first, or re-run with --force (not recommended).')
}

const backupDir = path.join(dshHome, 'dsh-augment', 'backup', new Date().toISOString().replace(/[:.]/g, '-'))
fs.mkdirSync(backupDir, { recursive: true })
for (const file of [pkgFile, patchFile, lockFile]) {
  if (fs.existsSync(file)) fs.copyFileSync(file, path.join(backupDir, path.basename(file)))
}
console.log(`[install] backup: ${backupDir}`)

const pkg = readJson(pkgFile)
pkg.dependencies = pkg.dependencies && typeof pkg.dependencies === 'object' ? pkg.dependencies : {}
pkg.dependencies['dsh-augment'] = `link:${pluginDir.replace(/\\/g, '/')}`
pkg.dsh = pkg.dsh && typeof pkg.dsh === 'object' ? pkg.dsh : {}
pkg.dsh.profile = pkg.dsh.profile && typeof pkg.dsh.profile === 'object' ? pkg.dsh.profile : {}
pkg.dsh.profile.bundles = Array.isArray(pkg.dsh.profile.bundles) ? pkg.dsh.profile.bundles : []
if (!pkg.dsh.profile.bundles.includes('dsh-augment')) {
  const compactIndex = pkg.dsh.profile.bundles.indexOf('dsh-compact')
  if (compactIndex >= 0) pkg.dsh.profile.bundles.splice(compactIndex + 1, 0, 'dsh-augment')
  else pkg.dsh.profile.bundles.push('dsh-augment')
}

if (dryRun) {
  console.log('[install] dry run: would add dependency dsh-augment =', pkg.dependencies['dsh-augment'])
  console.log('[install] dry run: bundles =', pkg.dsh.profile.bundles.join(', '))
  process.exit(0)
}

writeJson(pkgFile, pkg)
console.log(`[install] registered dsh-augment in ${pkgFile}`)

const pnpm = findPnpm()
console.log(`[install] running: ${pnpm.command} ${[...pnpm.args, 'install', '--dir', profileDir].join(' ')}`)
try {
  execFileSync(pnpm.command, [...pnpm.args, 'install', '--dir', profileDir, '--no-frozen-lockfile', '--reporter=append-only', '--config.confirmModulesPurge=false'], {
    cwd: profileDir,
    stdio: 'inherit',
    windowsHide: true,
    env: { ...process.env, CI: '1' },
  })
} catch (error) {
  fail(`pnpm install failed: ${error instanceof Error ? error.message : String(error)}\nBackup: ${backupDir}`)
}

const linkPath = path.join(profileDir, 'node_modules', 'dsh-augment')
if (!fs.existsSync(linkPath)) {
  fail(`install finished but ${linkPath} is missing.\nBackup: ${backupDir}`)
}
let real = linkPath
try { real = fs.realpathSync(linkPath) } catch {}
console.log(`[install] dsh-augment -> ${real}`)
console.log('[install] done. Restart DeepSeek Harness, then open Settings -> dsh augment.')
