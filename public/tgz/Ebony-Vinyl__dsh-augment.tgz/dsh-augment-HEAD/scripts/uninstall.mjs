#!/usr/bin/env node
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execFileSync } from 'node:child_process'

const dshHome = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const profileDir = path.join(dshHome, 'profiles', 'desktop')
const pkgFile = path.join(profileDir, 'package.json')
const patchFile = path.join(profileDir, 'cordis.patch.yml')
const lockFile = path.join(profileDir, 'pnpm-lock.yaml')
const args = new Set(process.argv.slice(2))
const dryRun = args.has('--dry-run')
const restore = args.has('--restore')

function fail(message) {
  console.error(`\n[uninstall] ${message}`)
  process.exit(1)
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'))
}

function writeJson(file, value) {
  fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`)
}

function findPnpm() {
  if (process.env.DSH_PNPM) return { command: process.execPath, args: [process.env.DSH_PNPM] }
  if (process.env.DSH_APP_ROOT) {
    const candidate = path.join(process.env.DSH_APP_ROOT, 'resources', 'runtime', 'primary-runtime', 'dependencies', 'pnpm', 'bin', 'pnpm.mjs')
    if (fs.existsSync(candidate)) return { command: process.execPath, args: [candidate] }
  }
  return { command: process.platform === 'win32' ? 'pnpm.cmd' : 'pnpm', args: [] }
}

if (!fs.existsSync(pkgFile)) fail(`profile package.json not found: ${pkgFile}`)

const backupRoot = path.join(dshHome, 'dsh-augment', 'backup')
const backupDir = path.join(dshHome, 'dsh-augment', 'backup', new Date().toISOString().replace(/[:.]/g, '-'))
fs.mkdirSync(backupDir, { recursive: true })
for (const file of [pkgFile, patchFile, lockFile]) {
  if (fs.existsSync(file)) fs.copyFileSync(file, path.join(backupDir, path.basename(file)))
}
console.log(`[uninstall] backup: ${backupDir}`)

let pkg
if (restore) {
  const dirs = fs.existsSync(backupRoot)
    ? fs.readdirSync(backupRoot).filter((name) => fs.existsSync(path.join(backupRoot, name, 'package.json'))).sort()
    : []
  if (dirs.length === 0) fail('no backup available to restore')
  const latest = path.join(backupRoot, dirs[dirs.length - 1])
  pkg = readJson(path.join(latest, 'package.json'))
  for (const file of ['cordis.patch.yml', 'pnpm-lock.yaml']) {
    const source = path.join(latest, file)
    if (fs.existsSync(source)) fs.copyFileSync(source, path.join(profileDir, file))
  }
  console.log(`[uninstall] restoring ${latest}`)
} else {
  pkg = readJson(pkgFile)
  if (pkg.dependencies && typeof pkg.dependencies === 'object') delete pkg.dependencies['dsh-augment']
  if (pkg.dsh?.profile?.bundles) {
    pkg.dsh.profile.bundles = pkg.dsh.profile.bundles.filter((name) => name !== 'dsh-augment')
  }
}

if (dryRun) {
  console.log('[uninstall] dry run: would remove dsh-augment from dependencies and bundles')
  process.exit(0)
}

writeJson(pkgFile, pkg)
console.log('[uninstall] removed dsh-augment from the desktop profile')

const pnpm = findPnpm()
try {
  execFileSync(pnpm.command, [...pnpm.args, 'install', '--dir', profileDir, '--no-frozen-lockfile', '--reporter=append-only', '--config.confirmModulesPurge=false'], {
    cwd: profileDir,
    stdio: 'inherit',
    windowsHide: true,
    env: { ...process.env, CI: '1' },
  })
} catch (error) {
  console.warn(`[uninstall] pnpm install failed (the plugin entry is already removed): ${error instanceof Error ? error.message : String(error)}`)
}

const linkPath = path.join(profileDir, 'node_modules', 'dsh-augment')
if (fs.existsSync(linkPath) || fs.lstatSync(linkPath, { throwIfNoEntry: false })) {
  try {
    fs.unlinkSync(linkPath)
  } catch {
    try { fs.rmdirSync(linkPath) } catch {}
  }
}
console.log('[uninstall] done. Restart DeepSeek Harness.')
