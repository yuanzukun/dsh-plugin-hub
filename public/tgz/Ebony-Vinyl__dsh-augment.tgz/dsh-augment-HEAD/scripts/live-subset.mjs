import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { baseHarness, applyEdits, featureTags } from '../lib/evolution/harness.js'

const root = path.resolve(import.meta.dirname, '..')

function buildRefinedHarness() {
  const tree = baseHarness()
  const edits = [
    {
      component: 'systemPrompt',
      op: 'append',
      text: 'Respect the task\'s exact output contract. If the task says "answer with X only", output only X. Do not add markdown or extra keys unless asked.\n<!-- dsh-evolve:feature=format-checklist -->',
    },
    {
      component: 'memory',
      op: 'append',
      text: 'When the user asks you to remember a token or fact, store it and recall it at the end of the task.\n<!-- dsh-evolve:feature=memory-recall -->',
    },
    {
      component: 'toolGuidance',
      op: 'append',
      text: 'After editing code, run the tests and verify the result before answering.\n<!-- dsh-evolve:feature=verify-before-answer -->\nA transient tool error is not a final failure. Retry once with the same intent before giving up.\n<!-- dsh-evolve:feature=retry-on-error -->\nFor multi-step tasks, write a short plan and execute each step in order, then verify the artifact.\n<!-- dsh-evolve:feature=plan-steps -->',
    },
  ]
  return applyEdits(tree, edits)
}

function cdp(expression) {
  const output = execFileSync(process.execPath, [path.join(root, 'scripts/cdp.mjs'), 'eval', expression], {
    cwd: root,
    encoding: 'utf8',
    windowsHide: true,
  })
  return JSON.parse(output)
}

function action(body) {
  const expression = `fetch('/plugins/dsh-augment/evolution/actions',{method:'POST',headers:{'x-dsh-augment':'1','content-type':'application/json'},body:${JSON.stringify(JSON.stringify(body))}}).then(r=>r.json())`
  return cdp(expression)
}

const tree = buildRefinedHarness()
fs.writeFileSync(path.join(root, 'docs/refined-harness.json'), `${JSON.stringify(tree, null, 2)}\n`, 'utf8')
console.log(`refined features: ${featureTags(tree).join(', ')}`)
const saved = action({ action: 'version/save', tree, notes: 'Refined live harness: exact output contract + verify + memory + retry + plan' })
const versionId = saved?.version?.id
if (!versionId) {
  console.error(JSON.stringify(saved, null, 2))
  process.exit(1)
}
console.log(`saved refined harness: ${versionId}`)
const taskIds = [
  'heldout-verify-before-answer-1',
  'heldout-verify-before-answer-2',
  'heldout-format-checklist-1',
  'heldout-format-checklist-2',
  'heldout-memory-recall-1',
  'heldout-memory-recall-2',
]
const started = cdp(`fetch('/plugins/dsh-augment/evolution/benchmark',{method:'POST',headers:{'x-dsh-augment':'1','content-type':'application/json'},body:${JSON.stringify(JSON.stringify({ mode: 'live', reps: 1, versionId, taskIds }))}}).then(r=>r.json())`)
console.log(JSON.stringify(started, null, 2))
