import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { baseHarness, applyEdits, featureTags } from '../lib/evolution/harness.js'
import { FEATURE_EDITS } from '../lib/evolution/gym/simulated.js'

const root = path.resolve(import.meta.dirname, '..')
const features = [
  'read-before-answer',
  'verify-before-answer',
  'format-checklist',
  'memory-recall',
  'retry-on-error',
  'plan-steps',
]
const tree = applyEdits(baseHarness(), features.map((feature) => ({
  component: FEATURE_EDITS[feature].component,
  op: 'append',
  text: FEATURE_EDITS[feature].text,
})))
fs.writeFileSync(path.join(root, 'docs/simulated-harness.json'), `${JSON.stringify(tree, null, 2)}\n`, 'utf8')
console.log(`features: ${featureTags(tree).join(', ')}`)
const body = JSON.stringify({
  action: 'version/save',
  tree,
  notes: 'Simulated 6-feature harness for live validation',
})
const expression = `fetch('/plugins/dsh-augment/evolution/actions',{method:'POST',headers:{'x-dsh-augment':'1','content-type':'application/json'},body:${JSON.stringify(body)}}).then(r=>r.json())`
const output = execFileSync(process.execPath, [path.join(root, 'scripts/cdp.mjs'), 'eval', expression], {
  cwd: root,
  encoding: 'utf8',
  windowsHide: true,
})
console.log(output.trim())
const parsed = JSON.parse(output)
const versionId = parsed?.version?.id
if (!versionId) {
  console.error('version/save did not return a version id')
  process.exit(1)
}
console.log(`saved version: ${versionId}`)
console.log(`next: start a live benchmark with {"versionId":"${versionId}"}`)
