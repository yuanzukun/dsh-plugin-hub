import fs from 'node:fs'
import path from 'node:path'
import { EvolutionStore } from '../lib/evolution/store.js'
import { EvolutionEngine } from '../lib/evolution/engine.js'
import { baseHarness, featureTags } from '../lib/evolution/harness.js'
import { createSimulatedAdapter } from '../lib/evolution/gym/simulated.js'
import { buildSuite } from '../lib/evolution/gym/tasks.js'
import { sanitizeEvolutionConfig } from '../lib/evolution/config.js'
import { resolveDshHome } from '../lib/util.js'

const root = path.resolve(import.meta.dirname, '..')
const dataDir = path.join(resolveDshHome(), 'dsh-augment', 'evolution')
const store = new EvolutionStore(dataDir)
const config = sanitizeEvolutionConfig({
  k: 3,
  autoAdopt: false,
  maxCalls: 10000,
  maxTokens: 100000000,
  maxMinutes: 60,
  gym: { seed: 42, reps: 1, devTasks: 12, heldoutTasks: 24 },
})
const suite = buildSuite()
const adapter = createSimulatedAdapter({ seed: 42 })
const engine = new EvolutionEngine({ store, adapter, config })
const run = await engine.run({
  runId: `run-demo-${Date.now().toString(36)}`,
  devTasks: suite.dev,
  heldoutTasks: suite.heldout,
  baseTree: baseHarness(),
  experiences: [],
  config,
})
const evaluation = run.evaluationId ? store.loadEvaluation(run.evaluationId) : null
console.log(JSON.stringify({
  runId: run.id,
  status: run.status,
  validationStatus: run.metrics.validationStatus,
  baseline: run.metrics.baselineScore,
  evolved: run.metrics.evolvedScore,
  delta: run.metrics.delta,
  ci: run.metrics.ci,
  features: run.selectedVersionId ? featureTags(store.loadVersion(run.selectedVersionId)?.tree || {}) : [],
  evaluationId: run.evaluationId,
  evaluationStatus: evaluation?.status,
  activeVersion: store.activeVersionId(),
  dataDir,
}, null, 2))
fs.writeFileSync(path.join(root, 'docs/evolution-demo-run.json'), `${JSON.stringify(run, null, 2)}\n`, 'utf8')
