#!/usr/bin/env node
import fs from 'node:fs'
import path from 'node:path'
import { ConfigStore } from '../lib/config.js'
import { Ledger } from '../lib/ledger.js'
import { RepoMap } from '../lib/repo-map.js'
import { compressText } from '../lib/pipeline.js'
import { dataDir, readJsonSafe, readTextSafe } from '../lib/util.js'

const args = process.argv.slice(2)
const command = args[0] ?? 'help'
const dir = dataDir()

function fmt(n) {
  const value = Number(n)
  if (!Number.isFinite(value)) return '0'
  if (Math.abs(value) >= 1e6) return `${(value / 1e6).toFixed(2)}M`
  if (Math.abs(value) >= 1e4) return `${(value / 1e3).toFixed(1)}K`
  return new Intl.NumberFormat('en-US').format(Math.round(value))
}

function pct(n) {
  return `${((Number(n) || 0) * 100).toFixed(1)}%`
}

function loadConfig() {
  return new ConfigStore(dir).get()
}

function printStats() {
  const stats = readJsonSafe(path.join(dir, 'stats.json'), null)
  if (!stats) {
    console.log('no stats yet; run a conversation in DeepSeek Harness first')
    return
  }
  const totals = stats.totals ?? {}
  const byTech = stats.byTech ?? {}
  const byTool = stats.byTool ?? {}
  const schemaCosts = stats.schemaCosts ?? {}
  console.log(`dsh augment stats  (${dir})`)
  console.log(`requests          ${fmt(totals.requests)}`)
  console.log(`prompt baseline   ${fmt(totals.promptBaseline)}`)
  console.log(`prompt actual     ${fmt(totals.promptActual)}`)
  console.log(`net saved         ${fmt(totals.netSaved)}  (${pct(totals.promptBaseline ? totals.netSaved / totals.promptBaseline : 0)})`)
  console.log(`output tokens     ${fmt(totals.outputTokens)}`)
  console.log(`cache read        ${fmt(totals.cacheReadTokens)}`)
  console.log(`injection         ${fmt(totals.injectionTokens)}`)
  console.log(`read dedup        ${fmt(totals.readDedupSaved)} (${fmt(totals.readDedupHits)} hits)`)
  console.log(`compressions      ${fmt(totals.compressions)} (${fmt(totals.compressionSaved)} saved)`)
  console.log(`schema / request  ${fmt(totals.schemaTokens)}`)
  console.log('by tech:')
  for (const [name, value] of Object.entries(byTech).sort((a, b) => (b[1].saved ?? 0) - (a[1].saved ?? 0))) {
    console.log(`  ${name.padEnd(14)} ${fmt(value.saved)}`)
  }
  if (Object.keys(byTool).length > 0) {
    console.log('by tool:')
    for (const [name, value] of Object.entries(byTool).sort((a, b) => (b[1].saved ?? 0) - (a[1].saved ?? 0))) {
      console.log(`  ${name.padEnd(14)} ${fmt(value.saved)}`)
    }
  }
  if (Object.keys(schemaCosts).length > 0) {
    console.log('top schema costs:')
    for (const [name, value] of Object.entries(schemaCosts).sort((a, b) => (b[1].tokens ?? 0) - (a[1].tokens ?? 0)).slice(0, 8)) {
      console.log(`  ${name.padEnd(22)} ${fmt(value.tokens)} tokens`)
    }
  }
}

async function main() {
  if (command === 'stats') {
    printStats()
    return
  }
  if (command === 'config') {
    console.log(JSON.stringify(loadConfig(), null, 2))
    return
  }
  if (command === 'compress') {
    const file = args[1]
    if (!file) throw new Error('usage: dsh-augment compress <file> [--out <file>]')
    const text = fs.readFileSync(file, 'utf8')
    const result = compressText(text, { tool: 'cli', config: loadConfig() })
    const outIndex = args.indexOf('--out')
    const outFile = outIndex >= 0 ? args[outIndex + 1] : undefined
    console.error(`before=${result.before ?? '?'} after=${result.after ?? '?'} saved=${result.saved ?? 0} tech=${result.tech ?? 'none'}`)
    if (outFile) {
      fs.writeFileSync(outFile, result.text)
      console.error(`wrote ${outFile}`)
    } else {
      process.stdout.write(result.text)
      if (!result.text.endsWith('\n')) process.stdout.write('\n')
    }
    return
  }
  if (command === 'map') {
    const root = args[1] ?? process.cwd()
    const config = loadConfig()
    const repoMap = new RepoMap(dir, config.repoMap, console)
    const map = await repoMap.build(root)
    console.log(map.text)
    return
  }
  if (command === 'reset') {
    if (!args.includes('--yes')) throw new Error('refusing to reset without --yes')
    const ledger = new Ledger(dir)
    ledger.reset()
    ledger.dispose()
    console.log('stats reset')
    return
  }
  if (command === 'export') {
    const outFile = args[1] ?? path.join(dir, `export-${Date.now()}.json`)
    const payload = {
      exportedAt: new Date().toISOString(),
      config: loadConfig(),
      stats: readJsonSafe(path.join(dir, 'stats.json'), null),
    }
    fs.writeFileSync(outFile, `${JSON.stringify(payload, null, 2)}\n`)
    console.log(outFile)
    return
  }
  console.log(`dsh augment CLI

usage:
  node scripts/augment.mjs stats
  node scripts/augment.mjs config
  node scripts/augment.mjs compress <file> [--out <file>]
  node scripts/augment.mjs map [root]
  node scripts/augment.mjs reset --yes
  node scripts/augment.mjs export [file]

data directory: ${dir}`)
}

main().catch((error) => {
  console.error(`error: ${error instanceof Error ? error.message : String(error)}`)
  process.exit(1)
})
