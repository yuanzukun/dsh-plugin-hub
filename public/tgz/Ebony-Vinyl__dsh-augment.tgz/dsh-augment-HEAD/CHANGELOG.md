# Changelog

## 0.0.1 preview — 2026-10-31

First public preview of dsh augment.

### Token efficiency

- Live token ledger: baseline vs actual input per request, plus cache-aware effective savings.
- Always-on output compression: ANSI/progress/dedup/grep-group/JSON/git-diff/HTML/base64/shape cap, guarded by `never_worse`.
- CCR: elided originals are kept locally for 7 days and retrievable through `augment_retrieve`.
- `read` replacement with scoped shadowing, `fs/observed`, and repeated-read references.
- Repo map, learned environment facts, loop guard, and a compression directive.
- Tool schema cost panel with per-tool usage counts and unused-tool flags.
- Compression lab for previewing before/after on pasted text.

### Self-evolution

- Eight evolvable components and a two-level Propose–Probe–Compose / bandit loop.
- Capability Gym: 12 deterministic task templates with held-out variants.
- Evidence gates: four-arm comparison, paired bootstrap, regression gate, audit trail and one-click rollback.
- Seven-tab evolution workspace with SSE updates.

### Operations

- CLI: `stats`, `config`, `compress`, `map`, `reset`, `export`.
- Install/uninstall scripts and a `DISABLED` emergency switch.
- Zero native runtime dependencies; no telemetry; local data only.

### Verification

- 59/59 offline tests.
- Tested on DeepSeek Harness 0.2.1-rc.5 desktop (Electron 44.7.0, Node 24).
