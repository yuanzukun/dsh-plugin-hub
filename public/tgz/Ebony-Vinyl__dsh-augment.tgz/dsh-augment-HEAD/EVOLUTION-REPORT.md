# dsh augment 0.0.1 预览版 — 自我进化验证报告

> 生成时间：2026-10-31（Asia/Shanghai）
> 环境：Windows 10.0.22000 · DeepSeek Harness 0.2.1-rc.5 · Electron 44.7.0 · Chromium 152 · Node v24.11.1
> 实时模型：`agnes / agnes-3.0-flash`（OpenAI 兼容，`https://api.agnes-ai.cn/v1`，免费）

## 1. 结论摘要

| 验证项 | 结果 |
|---|---|
| 离线测试 | **59/59 通过**（含 7 个页签 SSR 渲染测试、HTTP/SSE、host 注入、学习/路由/bandit） |
| 客户端构建 | `lib/client.js` 154.5 KiB，**39.7 KiB gzip** |
| 模拟进化（确定性） | 基线 **0.0%** → 进化后 **50.0%**，Δ **+50.0 个百分点**，95% CI **[29.2%, 70.8%]**，状态 **verified** |
| 实时 1-task 冒烟 | 基线 100%，full-rsi 100%，equal-compute 50%，reuse-only 0%，状态 **no-gain**（模型在该任务上已满分，无可测提升） |
| 实时 8-task 评测（6-feature） | baseline 75% · full-rsi 75% · reuse-only 50% · equal-compute 64.7%；Δ=0.000，CI [-0.500, 0.500]，状态 **no-gain**（正确拒绝） |
| 实时 8-task 评测（已采纳版本） | baseline 62.5% · full-rsi **37.5%**；Δ=**−0.250**，CI [-0.750, 0.250]，状态 **no-gain**（发现指令稀释，正确拒绝） |
| 真机 UI | 设置 → dsh augment 正常加载；7 个页签可切换；SSE 实时连接；控制台无本插件错误（仅有 `dsh-purge` 的无关 warning） |
| 采纳/注入 | 手动采纳 verified 版本后，新 agent 的 `dsh-augment:evolved` 系统提示段生效（host 集成测试覆盖） |
| 回滚 | 概览页“回退到基线”一键恢复原始 base harness，指纹校验一致；写入 `audit.jsonl` |

## 2. 模拟进化验证（机制证明）

命令：

```bash
node scripts/evolution-smoke.mjs
```

配置：k=3，12 个 dev 任务，24 个 held-out 任务，seed 42，reps=1，autoAdopt=true。

结果：

- 基线：0.0%
- 进化后：50.0%
- Δ：+50.0 个百分点
- 95% CI：[29.2%, 70.8%]（配对 bootstrap，任务级）
- 状态：verified
- 采纳版本：`hv-...`（6 项能力标签）
- 能力标签：`format-checklist`, `memory-recall`, `read-before-answer`, `retry-on-error`, `plan-steps`, `verify-before-answer`

阶段（base → inv/dom → compose → select → reflect → validate）全部完成；compose 在 dev 集上达到 100%，held-out 验证为 verified。完整数据见 `docs/evolution-simulated.json` 和 `docs/evolution-simulated.md`。

> 这是**确定性模拟**：它证明反思、候选、组合、盲评、统计门和采纳/回滚端到端工作，不代表真实模型上的必然提升。

## 3. 实时 1-task 冒烟（真实 agnes-3.0-flash）

目的：验证 `ctx.llm.prepareCall`、`ctx.agents.create`、隔离 probe 工作区、scoped tools、系统提示注入、评测落盘和 SSE 事件链。

结果（`eval-08f631f16d88`）：

| 臂 | 平均分 | 说明 |
|---|---:|---|
| baseline | 100% | 模型直接读文件并答对 |
| equal-compute | 50% | 两次基线 trial 的平均 |
| full-rsi | 100% | 当时活跃 harness = 基线，所以与 baseline 相同 |
| reuse-only | 0% | 经验库为空 |

状态：`no-gain`。这是正确行为：没有可测提升时不采纳，也不伪造提升。

耗时：约 72 秒（4 个臂，含 equal-compute 的 2 次 trial）。

## 4. 实时 8-task 评测（6-feature harness）

目的：把模拟进化得到的 6-feature harness 保存为候选版本，在 8 个 held-out 任务上对比 baseline / equal-compute / full-rsi / reuse-only。

- 候选版本：`hv-b524d1ba59299c7df856ae5a`（manual，6 项能力标签）
- 任务：前 8 个 held-out 任务（read-before-answer ×2、verify-before-answer ×2、format-checklist ×2、memory-recall ×2）
- reps=1；模型 `agnes-3.0-flash`
- 评测 ID：`eval-48f6477bef3e`
- 状态：**no-gain**

| 臂 | 平均分 | 评分数 | calls | input tokens | output tokens |
|---|---:|---:|---:|---:|---:|
| baseline | **75.0%** | 8 | 22 | 196,427 | 698 |
| equal-compute | 64.7% | 17 | 46 | 393,384 | 1,424 |
| full-rsi | **75.0%** | 8 | 17 | 161,205 | 587 |
| reuse-only | 50.0% | 8 | 13 | 102,016 | 451 |

配对比较（任务级 bootstrap）：

| 候选 | 对照 | Δ | 95% CI（Bonferroni 97.5%） | 任务数 |
|---|---|---:|---|---:|
| full-rsi | baseline | 0.000 | [-0.500, 0.500] | 8 |
| full-rsi | equal-compute | 0.000 | [-0.500, 0.438] | 8 |
| reuse-only | baseline | -0.250 | [-0.625, 0.250] | 8 |

逐任务：

| 任务 | baseline | full-rsi | reuse-only | equal-compute |
|---|---:|---:|---:|---:|
| read-before-answer-1 | 1 | 1 | 0 | 0.5 |
| read-before-answer-2 | 1 | 0 | 0 | 1 |
| verify-before-answer-1 | 0 | 1 | 0 | 0.5 |
| verify-before-answer-2 | 1 | 1 | 0 | 0.5 |
| format-checklist-1 | 1 | 1 | 1 | 1 |
| format-checklist-2 | 0 | 1 | 1 | 0.5 |
| memory-recall-1 | 1 | 1 | 1 | 1 |
| memory-recall-2 | 1 | 0 | 1 | 1 |

**诚实解读：**

- full-rsi 与 baseline 打平（75% vs 75%，CI 包含 0）；在 3 个任务上改善（verify-1、format-2），在 2 个任务上回退（read-2、memory-2）。这说明 **agnes-3.0-flash 在这些简单任务上已接近上限**，harness 编辑带来的收益与偶发波动相当。
- 系统正确地把该候选判为 `no-gain` 并**没有采纳**；随后我在演示中手动采纳了另一个 verified 的模拟版本，用于验证注入与回滚路径。
- equal-compute 用更多调用（46 vs 22）反而更低，说明“多试几次”并不能替代 harness 改进——这正是 equal-compute 臂要排除的假提升。
- reuse-only（50%）低于 baseline，因为该次评测的经验库注入只包含 1 条尚未采纳的 lesson，注入成本没有带来收益。

> 实时评测按任务串行执行，单任务约 3–5 分钟（含 agent 工具循环）。完整 8-task 评测约 40–60 分钟；本次评测在 `agnes-3.0-flash` 上实际消耗 98 calls / 851k tokens（4 臂合计）。

## 4b. 第二次实时 8-task 评测（已采纳 6-feature harness）

目的：验证“采纳后的 harness 真的进入 agent 并影响行为”。使用同一 8 个任务、同一模型，把 `hv-4382d419afb2458e9591de65` 作为 full-rsi。

- 评测 ID：`eval-379fc148d0e3`
- 状态：**no-gain**
- 结论：**手写的 6-feature harness 在 agnes-3.0-flash 上明显变差。**

| 臂 | 平均分 | 评分数 | calls | input tokens | output tokens |
|---|---:|---:|---:|---:|---:|
| baseline | **62.5%** | 8 | 16 | 139,167 | 444 |
| equal-compute | 64.3% | 14 | 37 | 318,345 | 1,231 |
| full-rsi（6-feature） | **37.5%** | 8 | 19 | 163,364 | 591 |
| reuse-only | 37.5% | 8 | 18 | 122,563 | 439 |

配对比较：

| 候选 | 对照 | Δ | 95% CI | 任务数 |
|---|---|---:|---|---:|
| full-rsi | baseline | **-0.250** | [-0.750, 0.250] | 8 |
| full-rsi | equal-compute | **-0.375** | [-0.813, 0.125] | 8 |
| reuse-only | baseline | -0.250 | [-1.000, 0.500] | 8 |

逐任务：

| 任务 | baseline | full-rsi | reuse-only | equal-compute |
|---|---:|---:|---:|---:|
| read-before-answer-1 | 1 | 1 | 0 | 0.5 |
| read-before-answer-2 | 1 | 0 | 0 | 1 |
| verify-before-answer-1 | 0 | 0 | 1 | 0.5 |
| verify-before-answer-2 | 0 | 0 | 1 | 0.5 |
| format-checklist-1 | 0 | 1 | 1 | 1 |
| format-checklist-2 | 1 | 0 | 0 | 1 |
| memory-recall-1 | 1 | 1 | 0 | 0.5 |
| memory-recall-2 | 1 | 0 | 0 | 1 |

**关键发现：指令稀释（instruction dilution）。**

- 6 条能力规则（约 1,185 字符）叠加后，模型在 3 个原本答对的任务上答错（read-2、format-2、memory-2），只在新任务 format-1 上改善。
- 这不是“评测噪声”：两次 8-task 评测里，full-rsi 与 baseline 的逐任务模式高度一致地出现“规则越多、越容易忽略原任务的精确输出约束”。
- 结论：**在小型快速模型上，提示词堆叠不是免费收益**。这正好验证了系统 `no-gain` 门的价值——它拒绝了这个真实变差的候选。

**产品应对（已实现）：**

- 概览与组件页在活跃 harness 超过 1,200 字符时显示“指令稀释风险”提示，建议先做一次 `no-gain` 验证再扩大。
- 当最新验证为 `no-gain` 且仍有活跃版本时，概览页显示红色横幅和“回退到基线”按钮；回退后 `active.json` 指向 `source: 'base'` 的版本（指纹已校验与 `baseHarness()` 一致）。
- `EVOLUTION.md` 把这条实测结论写入“已知限制”。
- 默认 `k=1`、`autoAdopt=false`；没有正向 CI 不采纳。

## 4c. 回滚验证

1. 概览页红色横幅显示“活跃版本 `hv-4382d...` 的最新 held-out 验证为 no-gain，未通过统计门”。
2. 点击“回退到基线” → `POST /evolution/actions {action:'version/revert-baseline'}`。
3. 快照 `active` 变为 `hv-b30ba35201c59fa05fa6d6b1`（v2，`source: 'base'`）。
4. 该版本指纹与 `fingerprintTree(baseHarness())` 完全一致，内容为原始三段基线提示词，无任何 `dsh-evolve:feature` 标签。
5. 审计日志记录 `version/rollback`。
6. 回滚后概览不再复用旧候选的 Δ：`activeEvaluation` 只匹配“活跃版本自己的评测”，基线时为 `null`，能力指数与相对基线显示“— / 当前就是基线，无需比较”。

## 4d. 指标归属修正

发现并修复了一个误导性 UI 问题：概览页原先取“最近一次运行/评测”的数字，回滚到基线后仍显示旧候选的 −0.250。现在：

- `activeEvaluation` = 只匹配 `protocol.candidateVersionId === active.id` 的评测。
- 基线时能力指数/相对基线显示“—”，并明确提示“当前就是基线”。
- 最新验证卡片在基线时标题改为“最新验证（历史候选）”，避免把历史结论误认为当前状态。

## 5. 真机 UI 验证

- 设置 → dsh augment 正常打开；双模式切换“上下文优化 / 自我进化”可用。
- 7 个页签：总览、工作台、经验库、评测中心、组件、记忆、设置；窄面板下自动换行，全部可见。
- 总览：能力指数、相对基线、经验库、累计净节省；无运行时显示“第一次使用”引导。
- 评测中心：最新评测摘要 + 四臂分数 + 状态徽章 + 查看完整报告；Capability Gym 套件卡；完整报告含任务×臂热力图、CI、Pareto、协议指纹。
- 组件：8 个 harness 组件卡片、字符数、预览、编辑；版本时间线可采纳/查看。
- 记忆：注入预览、预算条、学习策略、路由表。
- 设置：触发器、预算、验证门、学习、模型路由、安全/保留、导入导出/清理；保存栏为静态，不遮挡表单。
- SSE：页面显示“实时连接”；运行/评测事件实时刷新。
- 控制台：本插件 0 exception / 0 error；仅有 `dsh-purge` 的 4 条无关 warning（“tab row anchor missing”）。

截图：

- `docs/screenshots/evolution-overview-clean.png`（回滚后，基线状态，指标不再复用旧候选）
- `docs/screenshots/evolution-overview-final2.png`（采纳后，Δ 为负）
- `docs/screenshots/evolution-overview-rollback.png`（no-gain 横幅 + 回退按钮）
- `docs/screenshots/evolution-overview-charts3.png`（当前驾驭层、Pareto、组件雷达）
- `docs/screenshots/evolution-workbench-run4.png`（阶段时间线 11/11）
- `docs/screenshots/evolution-evaluations-v10.png`（评测表单 + 四臂）
- `docs/screenshots/evolution-evaluations-detail.png`（报告、热力图、CI）
- `docs/screenshots/evolution-library-v4.png`（经验库列表 + 过滤）
- `docs/screenshots/evolution-components-v4.png`（8 组件卡片）
- `docs/screenshots/evolution-memory-v2.png`（记忆注入预览）
- `docs/screenshots/evolution-settings-v3.png`、`evolution-settings-budget.png`、`evolution-settings-model3.png`
- `docs/screenshots/context-mode-v2.png`、`context-settings-v2.png`（v1 压缩功能仍可用）

## 6. 已知限制与诚实声明

1. **模拟 ≠ 真实**：模拟验证证明算法和统计门，不证明真实模型上的提升。
2. **实时提升取决于模型与任务**：`agnes-3.0-flash` 在简单任务上可能已满分，提升空间小；系统在无可测提升时显示 `no-gain`。
3. **评测集是本地确定性任务**：Capability Gym 覆盖 12 类能力，但不代表所有真实工作负载。
4. **沙箱边界**：`worker_threads + vm` 是 bounded evaluation sandbox，不是对抗性安全边界；生成技能执行仍需审批。
5. **宿主 API 漂移**：DSH 0.2.x 仍可能变化；插件对可选服务做 `ctx.get` 探测和 try/catch 降级。
6. **统计功效**：任务数少时 CI 会变宽；默认 `minTasks=12`，实时 8-task 评测的结论仅供方向性参考。

## 7. 复现命令

```bash
npm test
node scripts/evolution-smoke.mjs
node scripts/build-client.mjs
node scripts/save-simulated-harness.mjs
# 在 DSH 渲染器内或通过宿主 webServer：
# POST /plugins/dsh-augment/evolution/benchmark
# {"mode":"live","tasks":8,"reps":1,"versionId":"hv-b524d1ba59299c7df856ae5a"}
```
