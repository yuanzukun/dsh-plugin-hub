import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

import { estimateTokens, detectDensity, estimateMessagesTokens } from '../lib/tokens.js'
import {
  stripAnsi,
  collapseProgress,
  dedupLines,
  groupGrep,
  compactJson,
  compactDiff,
  htmlToText,
  elideBase64,
  capLines,
  applyFilters,
} from '../lib/filters.js'
import { compressText, shouldProtectTool } from '../lib/pipeline.js'
import { DEFAULT_CONFIG, sanitizeConfig } from '../lib/config.js'
import { Ledger } from '../lib/ledger.js'
import { CcrStore } from '../lib/ccr.js'
import { DedupTracker } from '../lib/dedup.js'

function tmpDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), `dsh-augment-${name}-`))
}

test('token estimator counts CJK near one token per character', () => {
  const cjk = estimateTokens('这是一个中文测试句子，用来验证估算。')
  const ascii = estimateTokens('This is an English test sentence for estimation.')
  assert.ok(cjk >= 15)
  assert.ok(ascii > 0)
  assert.ok(cjk > ascii)
  assert.equal(estimateTokens(''), 0)
})

test('density detection distinguishes json, code, log and prose', () => {
  assert.equal(detectDensity('{"a":1,"b":[1,2,3]}'), 'json')
  assert.equal(detectDensity('import x from "y"\nexport const a = 1;\n  if (a) {\n    return a;\n  }'), 'code')
  assert.equal(detectDensity('2026-01-01T00:00:00Z INFO start\n2026-01-01T00:00:01Z INFO ready\n2026-01-01T00:00:02Z ERROR bad\n2026-01-01T00:00:03Z INFO done'), 'log')
  assert.equal(detectDensity('A short paragraph about the repository and its conventions.'), 'prose')
})

test('estimateMessagesTokens includes block overhead', () => {
  const messages = [
    { role: 'user', content: [{ type: 'text', text: 'hello world' }] },
    { role: 'assistant', content: [{ type: 'tool-call', name: 'bash', arguments: '{"command":"ls"}' }] },
  ]
  assert.ok(estimateMessagesTokens(messages) > 10)
})

test('stripAnsi and progress collapse', () => {
  const ansi = '\u001B[31mred\u001B[0m and \u001B]0;title\u0007text'
  assert.equal(stripAnsi(ansi).text, 'red and text')
  const progress = 'step 1\rstep 2\rstep 3\ndone'
  assert.equal(collapseProgress(progress).text, 'step 3\ndone')
})

test('dedupLines collapses repeated runs and blank runs', () => {
  const input = ['a', 'same', 'same', 'same', 'b', '', '', '', 'c'].join('\n')
  const result = dedupLines(input)
  assert.match(result.text, /same \[x3\]/)
  assert.equal(result.text.split('\n').filter((line) => line === '').length, 1)
})

test('groupGrep groups repeated files and bails out on unparseable lines', () => {
  const input = [
    'src/a.ts:12:const x = 1',
    'src/a.ts:44:const y = 2',
    'src/b.ts:7:export const z = 3',
  ].join('\n')
  const result = groupGrep(input)
  assert.equal(result.grouped, true)
  assert.match(result.text, /src\/a\.ts \(2\):/)
  assert.match(result.text, /  12: const x = 1/)
  assert.match(result.text, /src\/b\.ts:7:export const z = 3/)

  const withContext = 'src/a.ts-10-context line\nsrc/a.ts:12:match'
  const bail = groupGrep(withContext)
  assert.equal(bail.changed, false)
  assert.equal(bail.text, withContext)
})

test('compactJson minifies and skeletonizes large payloads', () => {
  const small = '{\n  "a": 1,\n  "b": [1, 2, 3]\n}'
  const minified = compactJson(small)
  assert.equal(minified.text, '{"a":1,"b":[1,2,3]}')

  const big = { items: Array.from({ length: 200 }, (_, i) => ({ id: i, name: `item-${i}`.repeat(10) })) }
  const result = compactJson(JSON.stringify(big), { skeletonThreshold: 1000 })
  assert.equal(result.lossy, true)
  assert.ok(result.text.length < JSON.stringify(big).length)
})

test('elideBase64 replaces long runs', () => {
  const payload = `data:image/png;base64,${'A'.repeat(2048)}`
  const result = elideBase64(payload)
  assert.match(result.text, /\[base64 2048 chars elided\]/)
  assert.match(result.text, /^data:image\/png;base64,/)
})

test('compactDiff drops index lines and collapses long context runs', () => {
  const lines = [
    'diff --git a/src/a.ts b/src/a.ts',
    'index abc1234..def5678 100644',
    '--- a/src/a.ts',
    '+++ b/src/a.ts',
    '@@ -1,20 +1,20 @@',
    ...Array.from({ length: 8 }, (_, i) => ` context ${i}`),
    '-const old = 1',
    '+const next = 2',
    ...Array.from({ length: 4 }, (_, i) => ` tail context ${i}`),
  ]
  const result = compactDiff(lines.join('\n'))
  assert.equal(result.changed, true)
  assert.doesNotMatch(result.text, /^index /m)
  assert.match(result.text, /context lines elided/)
  assert.match(result.text, /\+const next = 2/)
})

test('htmlToText strips scripts, styles and tags', () => {
  const html = '<html><head><style>.x{color:red}</style></head><body><h1>Title</h1><script>alert(1)</script><p>Hello &amp; welcome</p></body></html>'
  const result = htmlToText(html)
  assert.match(result.text, /Title/)
  assert.match(result.text, /Hello & welcome/)
  assert.doesNotMatch(result.text, /alert/)
  assert.doesNotMatch(result.text, /<h1>/)
})

test('pipeline compresses html and git diff with a retrievable footer', () => {
  const html = `<html><body>${Array.from({ length: 80 }, (_, i) => `<p>Paragraph ${i} ${'x'.repeat(100)}</p>`).join('')}</body></html>`
  const htmlResult = compressText(html, { tool: 'web_fetch', config: DEFAULT_CONFIG })
  assert.equal(htmlResult.changed, true)
  assert.ok(htmlResult.techniques.includes('html'))
  assert.match(htmlResult.text, /\[dsh augment:/)

  const diff = [
    'diff --git a/src/a.ts b/src/a.ts',
    'index abc1234..def5678 100644',
    '--- a/src/a.ts',
    '+++ b/src/a.ts',
    '@@ -1,60 +1,60 @@',
    ...Array.from({ length: 60 }, (_, i) => ` context line ${i} ${'y'.repeat(80)}`),
    '-const old = 1',
    '+const next = 2',
  ].join('\n')
  const diffResult = compressText(diff, { tool: 'bash', config: DEFAULT_CONFIG })
  assert.equal(diffResult.changed, true)
  assert.ok(diffResult.techniques.includes('diff'))
  assert.match(diffResult.text, /\[dsh augment:/)
})

test('capLines keeps the tail of log output', () => {
  const lines = Array.from({ length: 1000 }, (_, i) => `line ${i}`)
  const result = capLines(lines.join('\n'), 'log', { maxLineChars: 2000 })
  assert.equal(result.changed, true)
  assert.match(result.text, /\[\.\.\. 780 lines elided \.\.\.\]/)
  assert.match(result.text, /line 999/)
  assert.match(result.text, /line 0/)
})

test('applyFilters returns techniques and lossy flag', () => {
  const lines = Array.from({ length: 1000 }, (_, i) => `same line ${i % 2 === 0 ? 'even' : 'odd'}`)
  const result = applyFilters(lines.join('\n'), DEFAULT_CONFIG.compression)
  assert.ok(result.techniques.includes('cap'))
  assert.equal(result.lossy, true)
})

test('pipeline compresses a large bash output and is idempotent', () => {
  const text = Array.from({ length: 5000 }, (_, i) => `line ${i} ${'x'.repeat(60)}`).join('\n')
  const result = compressText(text, { tool: 'bash', config: DEFAULT_CONFIG })
  assert.equal(result.changed, true)
  assert.ok(result.saved > 0)
  assert.match(result.text, /\[dsh augment: tech=cap/)
  assert.match(result.text, /saved \d+/)
  assert.match(result.text, /id="c-[0-9a-f]{12}"/)
  const second = compressText(result.text, { tool: 'bash', config: DEFAULT_CONFIG })
  assert.equal(second.changed, false)
})

test('pipeline protects read tools and leaves short text alone', () => {
  assert.equal(shouldProtectTool('read', DEFAULT_CONFIG), true)
  assert.equal(shouldProtectTool('read_pdf', DEFAULT_CONFIG), true)
  assert.equal(shouldProtectTool('bash', DEFAULT_CONFIG), false)
  const text = 'short output'
  const result = compressText(text, { tool: 'bash', config: DEFAULT_CONFIG })
  assert.equal(result.changed, false)
})

test('pipeline only strips ansi from errors', () => {
  const text = `\u001B[31m${'error line\n'.repeat(500)}\u001B[0m`
  const result = compressText(text, { tool: 'bash', config: DEFAULT_CONFIG, isError: true })
  assert.equal(result.changed, true)
  assert.equal(result.text.includes('\u001B'), false)
  assert.equal(result.text.includes('[dsh augment:'), false)
})

test('config sanitize clamps and preserves defaults', () => {
  const config = sanitizeConfig({
    compression: { minChars: -5, maxLineChars: 999999, cap: { logTail: 99999 } },
    ccr: { ttlDays: 9999 },
    repoMap: { maxTokens: 1 },
  })
  assert.equal(config.compression.minChars, 0)
  assert.equal(config.compression.maxLineChars, 10000)
  assert.equal(config.compression.cap.logTail, 5000)
  assert.equal(config.ccr.ttlDays, 365)
  assert.equal(config.repoMap.maxTokens, 100)
  assert.equal(config.enabled, true)
})

test('ledger records compression and request rows', () => {
  const dir = tmpDir('ledger')
  const ledger = new Ledger(dir)
  ledger.recordCompression({ sessionId: 's1', tool: 'bash', tech: 'cap', before: 1000, after: 200, saved: 800, id: 'c-abc' })
  ledger.recordRead({ sessionId: 's1', dedup: true, saved: 300, tokens: 400 })
  ledger.recordToolUse('bash')
  ledger.recordRequest({
    ts: Date.now(),
    sessionId: 's1',
    promptActual: 2000,
    promptBaseline: 5000,
    netSaved: 3000,
    outputTokens: 100,
    inputTokens: 1500,
    cacheReadTokens: 500,
    cacheWriteTokens: 0,
    injectionTokens: 200,
    contextSaved: 3200,
    estimated: false,
    byTech: { cap: 3000 },
  })
  const snap = ledger.snapshot()
  assert.equal(snap.totals.requests, 1)
  assert.equal(snap.totals.netSaved, 3000)
  assert.equal(snap.totals.compressionSaved, 800)
  assert.equal(snap.totals.readDedupHits, 1)
  assert.ok(snap.totals.savingsRate > 0.5)
  assert.ok(snap.byTech.cap.saved >= 3000)
  assert.equal(snap.toolUsage.bash, 1)
  ledger.dispose()
})

test('ccr stores, pages and refuses sensitive content', async () => {
  const dir = tmpDir('ccr')
  const ccr = new CcrStore(dir, { enabled: true, ttlDays: 7, maxStoreMB: 200, pageBytes: 100 }, console)
  const text = 'A'.repeat(5000)
  const id = await ccr.put(text, { sessionId: 's1', tool: 'bash' })
  assert.match(id, /^c-[0-9a-f]{12}$/)
  assert.equal(await ccr.get(id), text)
  const page = await ccr.page(id, 0, 1000)
  assert.equal(page.text.length, 1000)
  assert.equal(page.total, 5000)
  assert.equal(page.nextOffset, 1000)
  assert.equal(await ccr.put('-----BEGIN RSA PRIVATE KEY-----\nsecret\n-----END RSA PRIVATE KEY-----', {}), null)
  ccr.dispose()
})

test('dedup tracker collapses a repeated read inside the window', () => {
  const tracker = new DedupTracker(sanitizeConfig({}))
  const base = { sessionId: 's1', path: 'src/a.ts', offset: 1, limit: 100, version: 'v1', callId: 'call-1', endLine: 100, totalLines: 500 }
  tracker.rememberRead({ ...base, tokens: 1200 })
  const hit = tracker.checkRead({ ...base, callId: 'call-2', tokens: 1200 })
  assert.equal(hit.hit, true)
  assert.ok(hit.saved > 0)
  assert.match(hit.text, /read-dedup/)
  const changedVersion = tracker.checkRead({ ...base, version: 'v2', callId: 'call-3', tokens: 1200 })
  assert.equal(changedVersion.hit, false)
})
