import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

import { RepoMap } from '../lib/repo-map.js'
import { EnvFacts } from '../lib/env-facts.js'
import { LoopGuard } from '../lib/loop-guard.js'
import { buildContext } from '../lib/prompt.js'
import { capLines } from '../lib/filters.js'
import { compressText } from '../lib/pipeline.js'
import { sanitizeConfig } from '../lib/config.js'

function tmpDir(name) {
  return fs.mkdtempSync(path.join(os.tmpdir(), `dsh-augment-${name}-`))
}

test('capLines clamps a single very long line', () => {
  const text = 'x'.repeat(10_000)
  const result = capLines(text, 'prose', { maxLineChars: 2000 })
  assert.equal(result.changed, true)
  assert.ok(result.text.length <= 2001)
  assert.match(result.text, /…$/)
})

test('pipeline compresses a single huge line', () => {
  const text = 'x'.repeat(10_000)
  const result = compressText(text, { tool: 'bash', config: sanitizeConfig({}) })
  assert.equal(result.changed, true)
  assert.ok(result.saved > 0)
  assert.match(result.text, /\[dsh augment:/)
})

test('repo map scans a fixture repository', async () => {
  const root = tmpDir('repomap')
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({
    name: 'fixture-repo',
    main: 'src/index.js',
    scripts: { test: 'node --test', build: 'node build.js' },
    dependencies: { react: '18.0.0', express: '4.0.0' },
  }))
  fs.mkdirSync(path.join(root, 'src'), { recursive: true })
  fs.writeFileSync(path.join(root, 'src', 'index.js'), "import { x } from './util.js'\nimport express from 'express'\nexport const app = x\n")
  fs.writeFileSync(path.join(root, 'src', 'util.js'), 'export const x = 1\n')
  fs.writeFileSync(path.join(root, '.env.example'), 'API_URL=http://localhost\nDEBUG=1\n')
  const repoMap = new RepoMap(tmpDir('repomap-data'), { maxFiles: 100, maxDepth: 4, maxTokens: 700 }, console)
  const map = await repoMap.build(root)
  assert.equal(map.name, 'fixture-repo')
  assert.ok(map.fileCount >= 3)
  assert.ok(map.languages.some((item) => item.name === 'JavaScript'))
  assert.ok(map.frameworks.includes('React'))
  assert.ok(map.frameworks.includes('Express'))
  assert.ok(map.entryPoints.includes('src/index.js'))
  assert.ok(map.testCommands.includes('npm test'))
  assert.ok(map.envVars.includes('API_URL'))
  assert.ok(map.hotFiles.some((item) => item.path === 'src/util.js'))
  assert.match(map.text, /# Repo map: fixture-repo/)
  assert.match(repoMap.section(root, 'tests'), /npm test/)
  assert.match(repoMap.section(root, 'summary'), /Hot files/)
})

test('env facts learn verified commands and repairs', () => {
  const root = tmpDir('facts-repo')
  const facts = new EnvFacts(tmpDir('facts-data'), { enabled: true, maxFacts: 4, maxTokens: 150, minConfirmations: 2 }, console)
  facts.observe({ root, tool: 'bash', command: 'npm test', isError: false, output: 'ok' })
  facts.observe({ root, tool: 'bash', command: 'npm test', isError: false, output: 'ok' })
  facts.observe({ root, tool: 'bash', command: 'pytest', isError: true, output: 'pytest: command not found' })
  facts.observe({ root, tool: 'bash', command: 'python -m pytest', isError: false, output: 'ok' })
  facts.observe({ root, tool: 'bash', command: 'python -m pytest', isError: false, output: 'ok' })
  const rendered = facts.render(root)
  assert.match(rendered, /npm test/)
  assert.match(rendered, /python -m pytest/)
  assert.match(rendered, /not `pytest`/)
  facts.dispose()
})

test('loop guard nudges after repeated identical failures and respects cooldown', () => {
  const guard = new LoopGuard({ enabled: true, threshold: 3, windowCalls: 10, cooldownCalls: 10 })
  const base = { sessionId: 's1', tool: 'bash', args: { command: 'node missing.js' }, isError: true, output: 'Error: Cannot find module missing.js' }
  assert.equal(guard.observe(base).nudge, null)
  assert.equal(guard.observe(base).nudge, null)
  const third = guard.observe(base)
  assert.ok(third.nudge)
  assert.match(third.nudge, /loop-guard/)
  assert.equal(guard.observe(base).nudge, null)
})

test('prompt context contains directive, map and facts inside markers', () => {
  const text = buildContext({
    config: sanitizeConfig({}),
    repoMapText: '# Repo map: demo',
    factsText: '### Verified commands\n- `npm test` works (verified 2×).',
    readReplacementActive: true,
  })
  assert.match(text, /^<!-- dsh-augment:context:start -->/)
  assert.match(text, /dsh augment/)
  assert.match(text, /augment_retrieve/)
  assert.match(text, /read.*reference/)
  assert.match(text, /# Repo map: demo/)
  assert.match(text, /Verified commands/)
  assert.match(text, /<!-- dsh-augment:context:end -->$/)
})

test('repo map and env facts normalize slash variants of the same root', async () => {
  const root = tmpDir('norm-repo')
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ name: 'norm-repo', scripts: { test: 'node --test' } }))
  fs.writeFileSync(path.join(root, 'index.js'), 'export const x = 1\n')
  const forward = root.replace(/\\/g, '/')
  const repoMap = new RepoMap(tmpDir('norm-map-data'), { maxFiles: 50, maxDepth: 3, maxTokens: 400 }, console)
  await repoMap.build(root)
  assert.ok(repoMap.get(forward))
  assert.equal(repoMap.get(forward).root, path.resolve(root))
  assert.match(repoMap.section(forward, 'summary'), /# Repo map: norm-repo/)

  const facts = new EnvFacts(tmpDir('norm-facts-data'), { enabled: true, maxFacts: 4, maxTokens: 150, minConfirmations: 2 }, console)
  facts.observe({ root, tool: 'bash', command: 'npm test', isError: false, output: 'ok' })
  facts.observe({ root: forward, tool: 'bash', command: 'npm test', isError: false, output: 'ok' })
  assert.match(facts.render(forward), /npm test/)
  facts.dispose()
})
