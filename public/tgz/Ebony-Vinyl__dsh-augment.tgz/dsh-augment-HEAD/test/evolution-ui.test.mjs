import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { createRequire } from 'node:module'
import { pathToFileURL } from 'node:url'

async function loadEsbuild() {
  try {
    const mod = await import('esbuild')
    return mod.default ?? mod
  } catch {}
  if (process.env.ESBUILD_PATH) {
    try {
      const mod = await import(pathToFileURL(process.env.ESBUILD_PATH).href)
      return mod.default ?? mod
    } catch {}
  }
  return null
}

const esbuild = await loadEsbuild()

if (!esbuild) {
  test('all seven evolution tabs render with a realistic snapshot', { skip: 'esbuild is not installed; run npm install' }, () => {})
} else {
  const entry = path.resolve('test/ui-entry.js')
  const result = await esbuild.build({
    entryPoints: [entry],
    bundle: true,
    write: false,
    format: 'cjs',
    platform: 'node',
    target: 'node20',
    logLevel: 'silent',
  })
  const out = path.join(os.tmpdir(), `dsh-augment-ui-${Date.now()}.cjs`)
  fs.writeFileSync(out, result.outputFiles[0].text)
  const require = createRequire(pathToFileURL(out))
  const { renderAll } = require(out)

  test('all seven evolution tabs render with a realistic snapshot', () => {
    const html = renderAll()
    assert.equal(Object.keys(html).length, 7)
    for (const [name, value] of Object.entries(html)) {
      assert.ok(value.length > 200, `${name} rendered only ${value.length} chars`)
      assert.ok(!value.includes('data-factory-error'), `${name} hit a render error`)
    }
    assert.match(html.overview, /能力指数/)
    assert.match(html.workbench, /运行配置/)
    assert.match(html.library, /经验库/)
    assert.match(html.evaluations, /Capability Gym/)
    assert.match(html.components, /Harness 组件/)
    assert.match(html.memory, /记忆注入预览/)
    assert.match(html.settings, /总开关与触发/)
  })
}
