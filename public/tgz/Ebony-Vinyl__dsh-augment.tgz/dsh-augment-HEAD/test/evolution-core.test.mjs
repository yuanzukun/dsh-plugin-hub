import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

import { DEFAULT_EVOLUTION_CONFIG, sanitizeEvolutionConfig } from '../lib/evolution/config.js'
import {
  COMPONENTS,
  applyEdits,
  baseHarness,
  cloneTree,
  featureTags,
  fingerprintTree,
  hasFeature,
  markFeature,
  renderHarness,
  treeDiff,
  validateTree,
} from '../lib/evolution/harness.js'
import { bonferroni, pairedBootstrap, quantile, mulberry32 } from '../lib/evolution/statistics.js'
import { EvolutionStore } from '../lib/evolution/store.js'
import { runInSandbox } from '../lib/evolution/sandbox.js'

function tempRoot() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-augment-evo-'))
}

test('evolution config merges defaults and clamps invalid values', () => {
  const config = sanitizeEvolutionConfig({
    k: 99,
    concurrency: 0,
    maxCalls: -5,
    mode: 'nope',
    executor: { provider: '  agnes ', model: 'agnes-3.0-flash' },
    learning: { maxContextTokens: 999999 },
  })
  assert.equal(config.k, 8)
  assert.equal(config.concurrency, 1)
  assert.equal(config.maxCalls, 1)
  assert.equal(config.mode, 'parallel')
  assert.equal(config.executor.provider, 'agnes')
  assert.equal(config.executor.model, 'agnes-3.0-flash')
  assert.equal(config.learning.maxContextTokens, 8000)
  assert.equal(config.version, 1)
})

test('evolution config preserves the free agnes default route', () => {
  const config = sanitizeEvolutionConfig({})
  assert.equal(config.executor.provider, DEFAULT_EVOLUTION_CONFIG.executor.provider)
  assert.equal(config.executor.model, 'agnes-3.0-flash')
  assert.equal(config.improver.model, 'agnes-3.0-flash')
  assert.equal(config.selector.model, 'agnes-3.0-flash')
  assert.equal(config.judge.model, 'agnes-3.0-flash')
})

test('harness validates, clones, diffs and fingerprints deterministically', () => {
  const base = baseHarness()
  assert.equal(validateTree(base).components.systemPrompt, base.components.systemPrompt)
  const next = applyEdits(base, [
    { component: 'toolGuidance', op: 'append', text: markFeature('Read the relevant file before answering.', 'read-before-answer') },
    { component: 'memory', op: 'replace', text: 'Tests run with node --test.' },
  ])
  assert.ok(hasFeature(next, 'read-before-answer'))
  assert.deepEqual(featureTags(next), ['read-before-answer'])
  const diff = treeDiff(base, next)
  assert.ok(diff.modified.some((item) => item.component === 'toolGuidance'))
  assert.ok(diff.added.includes('memory'))
  assert.equal(fingerprintTree(next), fingerprintTree(cloneTree(next)))
  assert.notEqual(fingerprintTree(base), fingerprintTree(next))
  assert.match(renderHarness(next), /dsh-augment:evolved:start/)
  assert.match(renderHarness(next), /Read the relevant file/)
})

test('harness rejects unknown components, control characters and oversize text', () => {
  assert.throws(() => validateTree({ components: { nope: 'x' } }), /unknown harness component/)
  assert.throws(() => applyEdits(baseHarness(), [{ component: 'systemPrompt', op: 'replace', text: 'x\u0000y' }]), /control characters/)
  assert.throws(() => applyEdits(baseHarness(), [{ component: 'systemPrompt', op: 'replace', text: 'x'.repeat(25000) }]), /too large|exceeds/)
  assert.throws(() => applyEdits(baseHarness(), [{ component: 'systemPrompt', op: 'nope', text: 'x' }]), /unknown edit op/)
})

test('all eight components are present and emptyTree is complete', () => {
  const tree = baseHarness()
  assert.equal(COMPONENTS.length, 8)
  for (const name of COMPONENTS) assert.equal(typeof tree.components[name], 'string')
})

test('statistics computes a paired bootstrap with a deterministic seed', () => {
  const pairs = []
  for (let i = 0; i < 20; i++) {
    pairs.push({ taskId: `t${i}`, baseline: 0.3, candidate: 0.8 })
  }
  const result = pairedBootstrap(pairs, { iterations: 2000, seed: 7 })
  assert.equal(result.n, 20)
  assert.ok(result.delta > 0.49 && result.delta < 0.51)
  assert.ok(result.ci[0] > 0)
  assert.ok(result.ci[0] <= result.ci[1])
  const again = pairedBootstrap(pairs, { iterations: 2000, seed: 7 })
  assert.deepEqual(result.ci, again.ci)
})

test('statistics averages repetitions within a task', () => {
  const pairs = [
    { taskId: 'a', baseline: 0, candidate: 1 },
    { taskId: 'a', baseline: 0, candidate: 0 },
    { taskId: 'b', baseline: 0, candidate: 1 },
    { taskId: 'b', baseline: 0, candidate: 1 },
  ]
  const result = pairedBootstrap(pairs, { iterations: 500, seed: 1 })
  assert.equal(result.n, 2)
  assert.equal(result.delta, 0.75)
})

test('statistics helpers are stable', () => {
  assert.equal(quantile([0, 1, 2, 3, 4], 0.5), 2)
  assert.equal(bonferroni(0.95, 2), 0.975)
  const random = mulberry32(42)
  const a = random()
  const b = mulberry32(42)()
  assert.equal(a, b)
})

test('store persists runs, versions, active pointer, experiences, evaluations and audit', () => {
  const root = path.join(tempRoot(), 'evolution')
  const store = new EvolutionStore(root)
  const run = { id: 'run-1', createdAt: new Date().toISOString(), status: 'completed', stages: [] }
  store.saveRun(run)
  assert.equal(store.loadRun('run-1').status, 'completed')
  assert.equal(store.listRuns().length, 1)
  store.saveStage('run-1', { id: 'stage-1', label: 'base', status: 'completed' })
  assert.equal(store.loadStage('run-1', 'stage-1').label, 'base')

  store.saveVersion({ id: 'hv-1', version: 1, tree: baseHarness(), fingerprint: 'x' })
  store.setActiveVersion('hv-1')
  assert.equal(store.activeVersionId(), 'hv-1')
  assert.equal(store.activeVersion().id, 'hv-1')

  store.upsertExperience({ id: 'exp-1', kind: 'lesson', content: 'use tests' })
  assert.equal(store.listExperiences().length, 1)
  store.upsertExperience({ id: 'exp-1', kind: 'lesson', content: 'use tests twice' })
  assert.equal(store.listExperiences()[0].content, 'use tests twice')
  assert.equal(store.removeExperience('exp-1'), true)

  store.saveEvaluation({ id: 'eval-1', createdAt: new Date().toISOString(), status: 'verified' })
  assert.equal(store.listEvaluations().length, 1)
  store.saveReport('eval-1', { ok: true }, '# report')
  assert.ok(fs.existsSync(path.join(store.reportsDir, 'eval-1.md')))
  assert.ok(store.readAudit().some((entry) => entry.type === 'version/activate'))
})

test('store rejects path traversal ids and prototype pollution', () => {
  const store = new EvolutionStore(path.join(tempRoot(), 'evolution'))
  assert.throws(() => store.saveRun({ id: '../evil' }), /invalid/)
  const polluted = JSON.parse('{"id":"ok","__proto__":{"bad":true}}')
  assert.throws(() => store.saveRun(polluted), /unsafe|invalid/)
})

test('sandbox runs functions without node globals and enforces timeout', async () => {
  const ok = await runInSandbox({ source: 'function solve(input){ return { value: input.x + 1, hasProcess: typeof process, hasRequire: typeof require } }', input: { x: 41 } })
  assert.equal(ok.ok, true)
  const parsed = JSON.parse(ok.result)
  assert.equal(parsed.value, 42)
  assert.equal(parsed.hasProcess, 'undefined')
  assert.equal(parsed.hasRequire, 'undefined')

  const expr = await runInSandbox({ source: 'input.a * 2', mode: 'expression', input: { a: 21 } })
  assert.equal(JSON.parse(expr.result), 42)

  const timeout = await runInSandbox({ source: 'function solve(){ while (true) {} }', timeoutMs: 100 })
  assert.equal(timeout.ok, false)
  assert.match(timeout.error, /timed out|timeout/i)
})
