import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

process.env.DSH_HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-augment-home-'))

const { apply } = await import('../lib/index.js')

function makeMockContext() {
  const handlers = new Map()
  const tools = new Map()
  const sections = new Map()
  const routes = new Map()
  const disposers = []
  const logger = {
    info: () => {},
    warn: () => {},
    error: () => {},
  }
  const makeChild = (serviceName, service) => ({
    [serviceName]: service,
    effect(fn) {
      const disposer = fn()
      if (typeof disposer === 'function') disposers.push(disposer)
      return disposer
    },
    inject(_names, cb) { cb(this) },
    on() {},
    logger,
  })
  const ctx = {
    logger,
    on(event, handler) {
      if (!handlers.has(event)) handlers.set(event, [])
      handlers.get(event).push(handler)
    },
    inject(names, cb) {
      const child = {}
      if (names.includes('tools')) {
        child.tools = {
          register(definition) {
            tools.set(definition.name, definition)
            return () => tools.delete(definition.name)
          },
        }
      }
      if (names.includes('webServer')) {
        child.webServer = {
          register(route) {
            routes.set(route.path, route.handler)
            return () => routes.delete(route.path)
          },
        }
      }
      child.effect = (fn) => {
        const disposer = fn()
        if (typeof disposer === 'function') disposers.push(disposer)
        return disposer
      }
      child.inject = (_names, nested) => nested(child)
      child.logger = logger
      cb(child)
    },
    effect(fn) {
      const disposer = fn()
      if (typeof disposer === 'function') disposers.push(disposer)
      return disposer
    },
    get(name) { return this[name] },
    emit() {},
  }
  return { ctx, handlers, tools, sections, routes, disposers, makeChild, logger }
}

function makeAgent(sessionId, cwd, mockCtx) {
  const tools = new Map()
  const sections = new Map()
  const agent = {
    session: { id: sessionId, header: { cwd } },
    ctx: {
      tools: {
        register(definition) {
          tools.set(definition.name, definition)
          return () => tools.delete(definition.name)
        },
      },
      systemPrompt: {
        section(definition) {
          sections.set(definition.name, definition)
          return () => sections.delete(definition.name)
        },
      },
    },
  }
  return { agent, tools, sections }
}

function makeRes() {
  const res = {
    status: 0,
    headers: {},
    body: '',
    writeHead(status, headers) { this.status = status; this.headers = headers ?? {} },
    end(body) { this.body = body ?? '' },
  }
  return res
}

async function callRoute(routes, routePath, method = 'GET', body, headers = {}) {
  const handler = routes.get(routePath)
  assert.ok(handler, `route ${routePath} is registered`)
  const req = {
    method,
    url: routePath,
    socket: { remoteAddress: '127.0.0.1' },
    headers: { host: '127.0.0.1:1234', 'x-dsh-augment': '1', ...headers },
    async *[Symbol.asyncIterator]() {
      if (body !== undefined) yield Buffer.from(JSON.stringify(body))
    },
  }
  const res = makeRes()
  await handler(req, res)
  return { status: res.status, headers: res.headers, body: res.body ? JSON.parse(res.body) : undefined }
}

test('mock host: compression, ledger, read dedup, retrieve, map and stats', async () => {
  const mock = makeMockContext()
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-augment-repo-'))
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({
    name: 'fixture-repo',
    scripts: { test: 'node --test' },
    dependencies: { react: '18.0.0' },
  }))
  fs.mkdirSync(path.join(root, 'src'), { recursive: true })
  fs.writeFileSync(path.join(root, 'src', 'index.js'), "import x from './util.js'\nexport const a = 1\n")
  fs.writeFileSync(path.join(root, 'src', 'util.js'), 'export const x = 1\n')
  fs.writeFileSync(path.join(root, 'README.md'), '# fixture\n')

  const fileText = Array.from({ length: 300 }, (_, i) => `line ${i + 1} ${'y'.repeat(40)}`).join('\n')
  const mockFs = {
    async resolve(filePath) { return { targetKey: filePath, displayPath: filePath } },
    async stat(target) {
      if (target.targetKey === 'missing.txt') return undefined
      return { version: 'v1', type: 'file', size: fileText.length }
    },
    async readText() { return fileText },
    async streamText() { return (async function* () { yield fileText })() },
  }
  mock.ctx.fs = mockFs

  apply(mock.ctx, {})
  assert.ok(mock.tools.has('augment_retrieve'))
  assert.ok(mock.tools.has('augment_map'))

  const { agent, tools: agentTools, sections } = makeAgent('s1', root, mock)
  const createdHandlers = mock.handlers.get('agent/created') ?? []
  for (const handler of createdHandlers) await handler({ agent, source: 'startup' })
  assert.ok(agentTools.has('read'))

  // Read replacement: first read returns lines, second unchanged read returns a reference.
  const readTool = agentTools.get('read')
  const readExec = { name: 'read', callId: 'call-read-1', arguments: { file_path: 'fixture.txt' }, agent, signal: new AbortController().signal }
  const firstRead = await readTool.execute({ file_path: 'fixture.txt', offset: 1, limit: 200 }, readExec)
  assert.equal(firstRead.lines.length, 200)
  assert.match(readTool.output.render(null, firstRead)[0].text, /1\|line 1/)
  const secondRead = await readTool.execute({ file_path: 'fixture.txt', offset: 1, limit: 200 }, { ...readExec, callId: 'call-read-2' })
  assert.ok(secondRead.reference)
  assert.match(secondRead.reference, /read-dedup/)
  assert.deepEqual(readTool.output.presentationMeta(null, secondRead), {})
  assert.equal(readTool.output.presentationMeta(null, firstRead).path, 'fixture.txt')

  // A large bash result is compressed and stored for retrieval.
  const big = Array.from({ length: 5000 }, (_, i) => `output line ${i} ${'x'.repeat(50)}`).join('\n')
  const postHandlers = mock.handlers.get('tools/post-execute') ?? []
  assert.ok(postHandlers.length >= 1)
  const exec = { name: 'bash', callId: 'call-bash-1', arguments: { command: 'npm test' }, agent, signal: new AbortController().signal }
  const result = { isError: false, content: [{ type: 'text', text: big }] }
  const decision = await postHandlers[0](exec, result, async () => ({ kind: 'accept', content: result.content }))
  assert.equal(decision.kind, 'accept')
  const compressedText = decision.content[0].text
  assert.match(compressedText, /\[dsh augment: tech=cap/)
  const idMatch = /id="(c-[0-9a-f]{12})"/.exec(compressedText)
  assert.ok(idMatch)

  // Retrieve the stored original.
  const retrieveTool = mock.tools.get('augment_retrieve')
  const retrieved = await retrieveTool.execute({ id: idMatch[1], offset: 0, limit: 4096 }, { agent })
  assert.match(retrieved, /retrieved c-/)
  assert.ok(retrieved.includes('output line 0'))

  // System prompt section contains the directive and, after the map is ready, the repo map.
  const sectionDef = sections.get('dsh-augment:context')
  assert.ok(sectionDef)
  const mapTool = mock.tools.get('augment_map')
  const mapText = await mapTool.execute({ section: 'summary' }, { agent })
  assert.match(mapText, /# Repo map: fixture-repo/)
  const sectionText = sectionDef.text()
  assert.match(sectionText, /<!-- dsh-augment:context:start -->/)
  assert.match(sectionText, /# Repo map: fixture-repo/)

  // A model request sees the compressed marker and reports provider usage.
  const llmHandlers = mock.handlers.get('llm/stream') ?? []
  assert.equal(llmHandlers.length, 1)
  const options = {
    provider: 'mock',
    model: 'mock-1',
    sessionId: 's1',
    messages: [
      { role: 'system', content: [{ type: 'text', text: sectionText }] },
      { role: 'tool', content: [{ type: 'text', text: compressedText }] },
    ],
    tools: [...mock.tools.values()].map((tool) => ({ name: tool.name, description: tool.description, parameters: tool.parameters })),
  }
  const chunks = []
  const stream = llmHandlers[0](options, () => (async function* () {
    yield { type: 'usage', usage: { inputTokens: 1000, outputTokens: 50, cacheReadTokens: 200, cacheWriteTokens: 0 } }
    yield { type: 'finish', reason: { kind: 'stop' } }
  })())
  for await (const chunk of stream) chunks.push(chunk)
  assert.equal(chunks.length, 2)

  // Stats endpoint reflects the request and compression.
  const stats = await callRoute(mock.routes, '/plugins/dsh-augment/stats')
  assert.equal(stats.status, 200)
  assert.ok(stats.body.totals.requests >= 1)
  assert.ok(stats.body.totals.compressionSaved > 0)
  assert.ok(stats.body.totals.promptActual >= 1200)
  assert.ok(stats.body.totals.netSaved > 0)
  assert.equal(stats.body.health.readTool, 'active')
  assert.match(stats.body.health.repoRoot, /dsh-augment-repo-/)
  assert.ok(stats.body.totals.schemaTokens > 0)
  assert.ok(Object.keys(stats.body.schemaCosts).length > 0)
  assert.ok(stats.body.toolUsage.bash >= 1)

  // Config endpoint round-trips.
  const cfg = await callRoute(mock.routes, '/plugins/dsh-augment/config')
  assert.equal(cfg.status, 200)
  assert.equal(cfg.body.config.enabled, true)
  const updated = await callRoute(mock.routes, '/plugins/dsh-augment/config', 'POST', { config: { ...cfg.body.config, compression: { ...cfg.body.config.compression, minChars: 1024 } } })
  assert.equal(updated.status, 200)
  assert.equal(updated.body.config.compression.minChars, 1024)

  // Compression lab endpoint.
  const lab = await callRoute(mock.routes, '/plugins/dsh-augment/test', 'POST', { text: big })
  assert.equal(lab.status, 200)
  assert.equal(lab.body.changed, true)
  assert.ok(lab.body.saved > 0)

  for (const disposer of mock.disposers.reverse()) {
    try { disposer() } catch {}
  }
})
