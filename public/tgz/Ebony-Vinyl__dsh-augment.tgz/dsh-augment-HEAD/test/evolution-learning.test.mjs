import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

import { EvolutionStore } from '../lib/evolution/store.js'
import { LearningStore, canonicalScope, scopeKey, validateExperience } from '../lib/evolution/learning.js'
import { chooseRoute, learnRoutingRules, mergeRoutingRules } from '../lib/evolution/policy.js'
import { OperatorBandit } from '../lib/evolution/meta.js'

function tempStore() {
  return new EvolutionStore(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-augment-learning-')), 'evolution'))
}

function experience(overrides = {}) {
  return validateExperience({
    id: `exp-${Math.random().toString(16).slice(2, 14)}`,
    kind: 'lesson',
    scope: { workspace: 'D:\\demo', provider: 'agnes', model: 'agnes-3.0-flash', simulated: true },
    cue: 'When reading a config',
    content: 'Read the file before answering.',
    evidence: [{ quote: 'Read config/app.json: port 7412', source: 'trajectory' }],
    confidence: 0.8,
    state: 'adopted',
    createdAt: new Date().toISOString(),
    ...overrides,
  })
}

test('scope canonicalization is stable across Windows path aliases', () => {
  const a = canonicalScope({ workspace: 'D:\\Demo\\', provider: 'AGNES', model: 'agnes-3.0-flash', simulated: true })
  const b = canonicalScope({ workspace: 'd:/demo', provider: 'agnes', model: 'agnes-3.0-flash', simulated: true })
  assert.equal(scopeKey(a), scopeKey(b))
})

test('experience validation rejects secrets, control characters and missing evidence', () => {
  assert.throws(() => experience({ content: 'api_key = "sk-abcdefghijklmnopqrstuvwxyz"' }), /secret/)
  assert.throws(() => experience({ content: 'bad\u0000text' }), /control/)
  assert.throws(() => experience({ evidence: [] }), /evidence/)
})

test('learning store ranks by relevance, scope and state', () => {
  const store = new LearningStore(tempStore())
  const adopted = store.upsert(experience({ content: 'Read the config file before answering the port question.' }))
  store.upsert(experience({ id: 'exp-candidate', content: 'Candidate lesson about ports.', state: 'candidate' }))
  store.upsert(experience({ id: 'exp-other-scope', content: 'Read the config file.', scope: { workspace: 'D:\\other', provider: 'agnes', model: 'agnes-3.0-flash', simulated: true } }))
  const ranked = store.rank({ text: 'config port', scope: { workspace: 'd:/demo', provider: 'agnes', model: 'agnes-3.0-flash', simulated: true } })
  assert.equal(ranked[0].id, adopted.id)
  assert.ok(!ranked.some((item) => item.id === 'exp-candidate'))
  assert.ok(!ranked.some((item) => item.id === 'exp-other-scope'))
})

test('learning store renders a bounded, fenced context', () => {
  const store = new LearningStore(tempStore(), { maxContextTokens: 200 })
  store.upsert(experience({ content: 'Use the exact evidence quote from the file. '.repeat(20) }))
  const rendered = store.renderContext({ text: 'evidence', scope: { workspace: 'D:\\demo', provider: 'agnes', model: 'agnes-3.0-flash', simulated: true } }, { maxTokens: 200 })
  assert.match(rendered.text, /dsh-augment:learned:start/)
  assert.match(rendered.text, /dsh-augment:learned:end/)
  assert.ok(rendered.tokens <= 220)
})

test('learning lifecycle supports adopt, verify, archive, freeze and restore', () => {
  const store = new LearningStore(tempStore())
  const exp = store.upsert(experience({ state: 'candidate' }))
  assert.equal(store.transition(exp.id, 'adopt').state, 'adopted')
  assert.equal(store.transition(exp.id, 'verify').state, 'verified')
  assert.equal(store.transition(exp.id, 'freeze').state, 'frozen')
  assert.throws(() => store.transition(exp.id, 'archive'), /frozen/)
  assert.equal(store.transition(exp.id, 'restore').state, 'adopted')
  assert.equal(store.transition(exp.id, 'archive').state, 'archived')
  assert.equal(store.rank({}).length, 0)
})

test('routing rules learn per-domain routes and merge deterministically', () => {
  const tasks = [
    { id: 't1', domain: 'code' },
    { id: 't2', domain: 'code' },
    { id: 't3', domain: 'memory' },
  ]
  const observations = [
    { taskId: 't1', arm: 'baseline', score: 0.2 },
    { taskId: 't1', arm: 'full-rsi', score: 0.9 },
    { taskId: 't2', arm: 'baseline', score: 0.3 },
    { taskId: 't2', arm: 'full-rsi', score: 0.8 },
    { taskId: 't3', arm: 'baseline', score: 0.7 },
    { taskId: 't3', arm: 'full-rsi', score: 0.7 },
  ]
  const rules = learnRoutingRules({ observations, tasks, routes: { executor: { provider: 'agnes', model: 'agnes-3.0-flash' } } })
  assert.equal(rules.length, 1)
  assert.equal(rules[0].domain, 'code')
  const merged = mergeRoutingRules([], rules)
  assert.equal(merged.length, 1)
  const choice = chooseRoute({ domain: 'code', rules: merged, defaultRoute: { provider: 'agnes', model: 'agnes-3.0-flash' } })
  assert.equal(choice.route.model, 'agnes-3.0-flash')
  assert.match(choice.reason, /full-rsi/)
})

test('operator bandit explores then exploits and persists', () => {
  const store = tempStore()
  const bandit = new OperatorBandit({ store })
  const first = bandit.choose(['reflective-edit', 'ace-lesson'])
  assert.ok(['reflective-edit', 'ace-lesson'].includes(first))
  bandit.update(first, 0.5)
  const second = bandit.choose(['reflective-edit', 'ace-lesson'])
  assert.notEqual(second, first)
  bandit.update(second, -0.1)
  const snapshot = bandit.snapshot()
  assert.ok(snapshot.find((row) => row.operator === first).trials >= 1)
  const reloaded = new OperatorBandit({ store })
  assert.ok(reloaded.snapshot().some((row) => row.trials >= 1))
})
