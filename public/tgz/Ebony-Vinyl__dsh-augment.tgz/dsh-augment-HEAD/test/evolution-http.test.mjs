import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

process.env.DSH_HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-augment-evo-http-'))
const { apply } = await import('../lib/index.js')

function makeMockContext() {
  const handlers = new Map()
  const routes = new Map()
  const tools = new Map()
  const logger = { info() {}, warn() {}, error() {} }
  const ctx = {
    logger,
    on(event, handler) {
      if (!handlers.has(event)) handlers.set(event, [])
      handlers.get(event).push(handler)
    },
    inject(names, cb) {
      const child = {}
      if (names.includes('tools')) {
        child.tools = { register(definition) { tools.set(definition.name, definition); return () => tools.delete(definition.name) } }
      }
      if (names.includes('webServer')) {
        child.webServer = { register(route) { routes.set(route.path, route.handler); return () => routes.delete(route.path) } }
      }
      if (names.includes('commands')) {
        child.commands = { register() { return () => {} } }
      }
      child.effect = (fn) => { const disposer = fn(); return disposer }
      child.inject = (_names, nested) => nested(child)
      child.logger = logger
      cb(child)
    },
    effect(fn) { const disposer = fn(); return disposer },
    get(name) { return this[name] },
    emit() {},
  }
  return { ctx, handlers, routes, tools }
}

function makeRes() {
  return {
    status: 0,
    headers: {},
    body: '',
    writeHead(status, headers) { this.status = status; this.headers = headers || {} },
    write(chunk) { this.body += String(chunk); return true },
    end(chunk) { if (chunk !== undefined) this.body += String(chunk) },
    on() {},
  }
}

async function callExact(routes, routePath, method = 'GET', body, headers = {}) {
  const handler = routes.get(routePath)
  assert.ok(handler, `route ${routePath} is registered`)
  const req = {
    method,
    url: routePath,
    socket: { remoteAddress: '127.0.0.1' },
    headers: { host: '127.0.0.1:1234', 'x-dsh-augment': '1', ...headers },
    async *[Symbol.asyncIterator]() { if (body !== undefined) yield Buffer.from(JSON.stringify(body)) },
  }
  const res = makeRes()
  await handler(req, res)
  return { status: res.status, headers: res.headers, body: res.body ? JSON.parse(res.body) : undefined, raw: res.body }
}

async function callPrefix(routes, prefix, fullPath, method = 'GET', headers = {}) {
  const handler = routes.get(prefix)
  assert.ok(handler, `prefix route ${prefix} is registered`)
  const req = {
    method,
    url: fullPath,
    socket: { remoteAddress: '127.0.0.1' },
    headers: { host: '127.0.0.1:1234', 'x-dsh-augment': '1', ...headers },
    async *[Symbol.asyncIterator]() {},
  }
  const res = makeRes()
  await handler(req, res)
  return { status: res.status, headers: res.headers, body: res.body ? JSON.parse(res.body) : undefined, raw: res.body }
}

async function waitFor(check, timeoutMs = 30000) {
  const started = Date.now()
  while (Date.now() - started < timeoutMs) {
    const value = await check()
    if (value) return value
    await new Promise((resolve) => setTimeout(resolve, 150))
  }
  throw new Error('timed out waiting for condition')
}

test('evolution HTTP routes start a simulated run, persist it and expose a snapshot', async () => {
  const mock = makeMockContext()
  apply(mock.ctx, {})
  const prefix = '/plugins/dsh-augment/evolution'
  const snapshot = await callExact(mock.routes, `${prefix}/snapshot`)
  assert.equal(snapshot.status, 200)
  assert.equal(snapshot.body.config.executor.model, 'agnes-3.0-flash')
  assert.ok(snapshot.body.uiToken)

  const started = await callExact(mock.routes, `${prefix}/actions`, 'POST', {
    action: 'run/start',
    mode: 'simulated',
    k: 3,
    devTasks: 6,
    heldoutTasks: 16,
    autoAdopt: true,
  })
  assert.equal(started.status, 200)
  assert.ok(started.body.runId)

  const detail = await waitFor(async () => {
    const response = await callPrefix(mock.routes, `${prefix}/runs`, `${prefix}/runs/${started.body.runId}`)
    return response.body?.run?.status === 'completed' ? response.body : null
  })
  assert.equal(detail.run.status, 'completed')
  assert.ok(detail.run.metrics?.validationStatus)
  assert.ok(detail.stages.length >= 5)
  assert.ok(detail.candidates.length >= 1)

  const after = await callExact(mock.routes, `${prefix}/snapshot`)
  assert.ok(after.body.runs.some((run) => run.id === started.body.runId))
  assert.ok(after.body.active)
  assert.equal(after.body.active.status, 'adopted')

  const library = await callExact(mock.routes, `${prefix}/library`)
  assert.equal(library.status, 200)
  assert.ok(Array.isArray(library.body.experiences))

  const exported = await callExact(mock.routes, `${prefix}/export`)
  assert.equal(exported.status, 200)
  assert.ok(exported.raw.includes('exportedAt'))
})

test('evolution HTTP rejects unauthenticated POSTs and streams SSE snapshots', async () => {
  const mock = makeMockContext()
  apply(mock.ctx, {})
  const prefix = '/plugins/dsh-augment/evolution'
  const denied = await callExact(mock.routes, `${prefix}/actions`, 'POST', { action: 'prune' }, { 'x-dsh-augment': '' })
  assert.equal(denied.status, 403)

  const snapshot = await callExact(mock.routes, `${prefix}/snapshot`)
  const handler = mock.routes.get(`${prefix}/events`)
  assert.ok(handler)
  const res = makeRes()
  const req = {
    method: 'GET',
    url: `${prefix}/events?token=${encodeURIComponent(snapshot.body.uiToken)}`,
    socket: { remoteAddress: '127.0.0.1' },
    headers: { host: '127.0.0.1:1234' },
  }
  await handler(req, res)
  assert.equal(res.status, 200)
  assert.match(res.headers['content-type'], /text\/event-stream/)
  await new Promise((resolve) => setTimeout(resolve, 100))
  assert.match(res.body, /retry: 3000/)
  assert.match(res.body, /event: snapshot/)
})
