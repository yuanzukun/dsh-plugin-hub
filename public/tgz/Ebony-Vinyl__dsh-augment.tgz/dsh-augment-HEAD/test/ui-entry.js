import React from 'react'
import { renderToString } from 'react-dom/server'
import { Overview } from '../lib/client/evolution/overview.js'
import { Workbench } from '../lib/client/evolution/workbench.js'
import { Library } from '../lib/client/evolution/library.js'
import { Evaluations } from '../lib/client/evolution/evaluations.js'
import { Components } from '../lib/client/evolution/components.js'
import { Memory } from '../lib/client/evolution/memory.js'
import { Settings } from '../lib/client/evolution/settings.js'

const now = new Date().toISOString()
const components = {
  systemPrompt: 'You are a capable agent. Read the source before answering.',
  guardrails: 'Do not run destructive commands.',
  memory: 'Read config files before answering questions about ports.',
  toolGuidance: 'Use search for large logs. Run tests after edits.',
  subagents: '',
  skills: 'Use a plan for multi-step tasks.',
  scripts: '',
  plugins: 'agnes-3.0-flash is the default model.',
}
const sizes = { total: 420, components: Object.fromEntries(Object.entries(components).map(([key, value]) => [key, value.length])) }
const tree = { version: 1, components }

export function mockSnapshot() {
  return {
    version: '0.0.1',
    config: {
      enabled: true,
      trigger: 'manual',
      mode: 'parallel',
      k: 2,
      concurrency: 2,
      maxCalls: 60,
      maxTokens: 300000,
      maxMinutes: 30,
      liveModelCalls: true,
      autoAdopt: false,
      minTasks: 12,
      minConfidence: 0.95,
      maxRegression: 0.05,
      executor: { provider: 'agnes', model: 'agnes-3.0-flash' },
      improver: { provider: 'agnes', model: 'agnes-3.0-flash' },
      selector: { provider: 'agnes', model: 'agnes-3.0-flash' },
      judge: { provider: 'agnes', model: 'agnes-3.0-flash' },
      learning: { enabled: true, capture: true, recall: true, writeMode: 'review', maxContextTokens: 1200, maxExperiences: 2000 },
      routing: { enabled: true, rules: [] },
      safety: { redactSecrets: true, blockDestructive: true, sandboxSkills: true, retentionDays: 30, maxStoreMB: 512 },
      ui: { animations: true, pollMs: 2000 },
      gym: { suite: 'capability-gym', devTasks: 8, heldoutTasks: 16, reps: 2, seed: 42 },
    },
    stats: { runs: 1, versions: 2, experiences: 1, evaluations: 1, activeVersionId: 'hv-1' },
    savings: { netSaved: 12345, savingsRate: 0.3 },
    baseSizes: sizes,
    basePreview: 'base',
    baseTree: tree,
    active: {
      id: 'hv-1', version: 2, fingerprint: 'abcdef', score: 0.82, source: 'compose', status: 'adopted', createdAt: now,
      features: ['read-before-answer', 'verify-before-answer'], sizes, preview: 'evolved', diff: { added: ['memory'], removed: [], modified: [], unchanged: [] },
      tree,
    },
    versions: [{ id: 'hv-1', version: 2, source: 'compose', status: 'adopted', score: 0.82, createdAt: now, parentId: null, notes: 'compose', fingerprint: 'abcdef', features: ['read-before-answer'], sizes }],
    runs: [{
      id: 'run-1', taskId: 'dev', domain: 'context', status: 'completed', mode: 'simulated', k: 2, createdAt: now, endedAt: now,
      metrics: { baselineScore: 0.3, evolvedScore: 0.82, selectedDevScore: 0.8, delta: 0.52, ci: [0.2, 0.8], validationStatus: 'verified' },
      usage: { calls: 20, inputTokens: 1000, outputTokens: 200, latencyMs: 0 },
      selectedVersionId: 'hv-1', adoptedVersionId: 'hv-1', evaluationId: 'eval-1', selectionReason: 'best', errors: [],
      candidates: [{ id: 'c1', label: 'A', score: 0.82, operator: 'reflective-edit', versionId: 'hv-1', summary: 'Add read-before-answer', usage: { inputTokens: 500, outputTokens: 100 } }],
      stages: [{ id: 's1', label: 'base', kind: 'base', status: 'completed', score: 0.3 }, { id: 's2', label: 'compose', kind: 'compose', status: 'completed', score: 0.82 }],
    }],
    evaluations: [{
      id: 'eval-1', status: 'verified', createdAt: now, tasks: 12, reps: 1, note: 'verified',
      armSummaries: {
        baseline: { meanScore: 0.3, scored: 12, expected: 12, inputTokens: 100, outputTokens: 10 },
        'equal-compute': { meanScore: 0.31, scored: 12, expected: 12, inputTokens: 200, outputTokens: 20 },
        'full-rsi': { meanScore: 0.82, scored: 12, expected: 12, inputTokens: 300, outputTokens: 30 },
        'reuse-only': { meanScore: 0.5, scored: 12, expected: 12, inputTokens: 100, outputTokens: 10 },
      },
      comparisons: [{ candidate: 'full-rsi', comparator: 'baseline', delta: 0.52, ci: [0.2, 0.8], n: 12, confidence: 0.975 }],
      regressions: [],
    }],
    experiences: [{
      id: 'exp-1', kind: 'lesson', scope: { workspace: 'D:/demo', provider: 'agnes', model: 'agnes-3.0-flash', simulated: false },
      cue: 'When reading config', content: 'Read the file before answering.', evidence: [{ quote: 'Read config/app.json: port 7412', source: 'trajectory' }],
      confidence: 0.8, generation: 1, parentId: null, state: 'adopted', frozen: false, reuseCount: 2, createdAt: now, lastUsedAt: null, runId: 'run-1', domain: 'context', versionId: 'hv-1',
    }],
    experienceCount: 1,
    meta: [{ operator: 'reflective-edit', trials: 1, successes: 1, successRate: 1, meanReward: 0.5, weight: 1 }],
    routing: [{ domain: 'context', provider: 'agnes', model: 'agnes-3.0-flash', confidence: 0.8, evidence: 'full-rsi 0.8 vs baseline 0.3', createdAt: now }],
    models: { providers: [{ id: 'agnes', name: 'agnes' }], models: [{ provider: 'agnes', id: 'agnes-3.0-flash', name: 'agnes-3.0-flash' }] },
    gym: [],
    learned: { tokens: 100, preview: '<!-- dsh-augment:learned:start -->\nlesson', count: 1 },
    events: [],
    uiToken: 'ui-123',
    health: { engine: 'idle', activeRuns: [], sseClients: 1, dataDir: 'D:/data', version: '2.0.0' },
  }
}

export function renderAll() {
  const snapshot = mockSnapshot()
  const action = { busy: '', error: '', run: async () => ({}) }
  const common = { snapshot, action, events: [], onOpenRun() {}, onGoTab() {}, selectedRunId: '', setSelectedRunId() {} }
  const tabs = [
    ['overview', Overview],
    ['workbench', Workbench],
    ['library', Library],
    ['evaluations', Evaluations],
    ['components', Components],
    ['memory', Memory],
    ['settings', Settings],
  ]
  return Object.fromEntries(tabs.map(([name, Component]) => [name, renderToString(React.createElement(Component, common))]))
}
