import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

import { EvolutionEngine, EvolutionControl, RunBudget, BudgetExceededError, planStages } from '../lib/evolution/engine.js'
import { EvolutionStore } from '../lib/evolution/store.js'
import { baseHarness, featureTags } from '../lib/evolution/harness.js'
import { createSimulatedAdapter } from '../lib/evolution/gym/simulated.js'
import { buildSuite } from '../lib/evolution/gym/tasks.js'
import { sanitizeEvolutionConfig } from '../lib/evolution/config.js'
import { anonymousCandidates, paretoFront } from '../lib/evolution/selection.js'

function tempStore() {
  return new EvolutionStore(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-augment-engine-')), 'evolution'))
}

function testConfig(overrides = {}) {
  return sanitizeEvolutionConfig({
    k: 3,
    concurrency: 2,
    maxCalls: 4000,
    maxTokens: 40000000,
    maxMinutes: 60,
    autoAdopt: true,
    minTasks: 12,
    minConfidence: 0.95,
    gym: { seed: 42, reps: 1 },
    ...overrides,
  })
}

test('planStages produces base, inv, dom, compose, select, reflect and validate', () => {
  const stages = planStages({ k: 2 })
  assert.deepEqual(stages.map((stage) => stage.label), ['base', 'inv1', 'inv2', 'dom1', 'dom2', 'compose', 'select', 'reflect', 'validate'])
})

test('run budget enforces call, token and time caps', () => {
  const budget = new RunBudget({ maxCalls: 1, maxTokens: 1000, maxMinutes: 1 })
  budget.check()
  budget.record({ calls: 1, inputTokens: 1000 })
  assert.throws(() => budget.check(), (error) => error instanceof BudgetExceededError)
})

test('simulated suite has 12 dev and 24 held-out tasks covering all features', () => {
  const suite = buildSuite()
  assert.equal(suite.dev.length, 12)
  assert.equal(suite.heldout.length, 24)
  const features = new Set(suite.dev.map((task) => task.feature))
  assert.equal(features.size, 12)
  assert.ok(suite.heldout.every((task) => task.heldout))
})

test('engine evolves a harness, validates it on held-out tasks and adopts it', async () => {
  const store = tempStore()
  const adapter = createSimulatedAdapter({ seed: 42 })
  const config = testConfig()
  const suite = buildSuite()
  const events = []
  const engine = new EvolutionEngine({ store, adapter, config, onEvent: (type, payload) => events.push({ type, payload }) })
  const run = await engine.run({
    devTasks: suite.dev,
    heldoutTasks: suite.heldout,
    baseTree: baseHarness(),
    experiences: [],
    config,
  })
  assert.equal(run.status, 'completed')
  assert.ok(run.stages.length >= 7)
  assert.equal(run.metrics.validationStatus, 'verified')
  assert.ok(run.metrics.delta > 0.2, `delta was ${run.metrics.delta}`)
  assert.ok(run.metrics.ci[0] > 0, `ci was ${run.metrics.ci}`)
  assert.ok(run.adoptedVersionId)
  assert.ok(store.activeVersionId())
  assert.ok(store.listExperiences().length >= 1)
  assert.ok(events.some((event) => event.type === 'run/complete'))
  assert.ok(events.some((event) => event.type === 'evaluation/complete'))
  const active = store.activeVersion()
  assert.ok(featureTags(active.tree).length >= 2, `active features: ${featureTags(active.tree)}`)
})

test('engine can run a standalone benchmark report', async () => {
  const store = tempStore()
  const adapter = createSimulatedAdapter()
  const config = testConfig({ autoAdopt: false })
  const suite = buildSuite()
  const engine = new EvolutionEngine({ store, adapter, config })
  const baseline = baseHarness()
  const candidate = baseHarness()
  candidate.components.toolGuidance += '\n<!-- dsh-evolve:feature=read-before-answer -->\n<!-- dsh-evolve:feature=verify-before-answer -->\n<!-- dsh-evolve:feature=retry-on-error -->\n<!-- dsh-evolve:feature=plan-steps -->\n<!-- dsh-evolve:feature=memory-recall -->'
  candidate.components.systemPrompt += '\n<!-- dsh-evolve:feature=format-checklist -->\n<!-- dsh-evolve:feature=cite-evidence -->\n<!-- dsh-evolve:feature=summarize -->'
  const report = await engine.benchmark({
    tasks: suite.heldout.slice(0, 12),
    baselineHarness: baseline,
    candidateHarness: candidate,
    experiences: [],
    config,
    reps: 1,
  })
  assert.equal(report.status, 'verified')
  assert.ok(report.armSummaries['full-rsi'].meanScore > report.armSummaries.baseline.meanScore)
  assert.ok(store.listEvaluations().length === 1)
  assert.ok(fs.existsSync(path.join(store.reportsDir, `${report.id}.md`)))
})

test('selection anonymizes candidates and keeps a Pareto front', () => {
  const treeA = baseHarness()
  const treeB = baseHarness()
  treeB.components.memory = 'remember'
  const candidates = [
    { id: 'a', tree: treeA, score: 0.4, tokens: 100 },
    { id: 'b', tree: treeB, score: 0.8, tokens: 200 },
    { id: 'c', tree: treeA, score: 0.6, tokens: 150 },
    { id: 'd', tree: treeA, score: 0.5, tokens: 160 },
  ]
  const { candidates: anonymous, map } = anonymousCandidates(candidates)
  assert.equal(anonymous.length, 4)
  assert.deepEqual(anonymous.map((item) => item.label).sort(), ['A', 'B', 'C', 'D'])
  assert.equal(Object.keys(map).length, 4)
  assert.ok(anonymous.every((item) => item.trajectory === ''))
  const front = paretoFront(candidates)
  assert.ok(front.some((item) => item.id === 'b'))
  assert.ok(front.some((item) => item.id === 'c'))
  assert.ok(!front.some((item) => item.id === 'd'))
})

test('control pause and cancel are observable', async () => {
  const control = new EvolutionControl()
  control.pause()
  let resumed = false
  const promise = control.checkpoint().then(() => { resumed = true })
  await new Promise((resolve) => setTimeout(resolve, 20))
  assert.equal(resumed, false)
  control.resume()
  await promise
  assert.equal(resumed, true)
  control.cancel()
  await assert.rejects(() => control.checkpoint(), /cancelled/)
})
