import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

process.env.DSH_HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-augment-host-'))
const { apply } = await import('../lib/index.js')

function makeMockContext() {
  const handlers = new Map()
  const tools = new Map()
  const commands = new Map()
  const routes = new Map()
  const logger = { info() {}, warn() {}, error() {} }
  const ctx = {
    logger,
    on(event, handler) {
      if (!handlers.has(event)) handlers.set(event, [])
      handlers.get(event).push(handler)
    },
    inject(names, cb) {
      const child = {}
      if (names.includes('tools')) child.tools = { register(def) { tools.set(def.name, def); return () => tools.delete(def.name) } }
      if (names.includes('commands')) child.commands = { register(def) { commands.set(def.name, def); return () => commands.delete(def.name) } }
      if (names.includes('webServer')) child.webServer = { register(route) { routes.set(route.path, route.handler); return () => routes.delete(route.path) } }
      child.effect = (fn) => fn()
      child.inject = (_names, nested) => nested(child)
      child.logger = logger
      cb(child)
    },
    effect(fn) { return fn() },
    get(name) { return this[name] },
    emit() {},
  }
  return { ctx, handlers, tools, commands, routes }
}

function makeAgent(sessionId, cwd) {
  const tools = new Map()
  const sections = new Map()
  const agent = {
    session: { id: sessionId, header: { cwd }, snapshotEvents: () => [] },
    options: { provider: 'agnes', model: 'agnes-3.0-flash' },
    ctx: {
      tools: { register(def) { tools.set(def.name, def); return () => tools.delete(def.name) } },
      systemPrompt: { section(def) { sections.set(def.name, def); return () => sections.delete(def.name) } },
    },
  }
  return { agent, tools, sections }
}

async function emit(mock, event, ...args) {
  let result
  for (const handler of mock.handlers.get(event) || []) {
    result = await handler(...args, async () => ({ kind: 'accept' }))
  }
  return result
}

test('adopted harness and learned experience are injected into a live agent', async () => {
  const mock = makeMockContext()
  apply(mock.ctx, {})
  assert.ok(mock.tools.has('augment_evolve'))
  assert.ok(mock.tools.has('augment_recall'))
  assert.ok(mock.tools.has('augment_skill'))
  assert.ok(mock.commands.has('evolve'))
  assert.ok(mock.commands.has('recall'))
  assert.ok(mock.commands.has('benchmark'))

  const snapshot = await mock.routes.get('/plugins/dsh-augment/evolution/snapshot')({
    method: 'GET',
    url: '/plugins/dsh-augment/evolution/snapshot',
    socket: { remoteAddress: '127.0.0.1' },
    headers: { host: '127.0.0.1:1234' },
  }, {
    status: 0,
    headers: {},
    body: '',
    writeHead(s, h) { this.status = s; this.headers = h || {} },
    end(b) { this.body = b || '' },
  })
  const res = {
    status: 0,
    headers: {},
    body: '',
    writeHead(s, h) { this.status = s; this.headers = h || {} },
    end(b) { this.body = b || '' },
  }
  await mock.routes.get('/plugins/dsh-augment/evolution/snapshot')({
    method: 'GET',
    url: '/plugins/dsh-augment/evolution/snapshot',
    socket: { remoteAddress: '127.0.0.1' },
    headers: { host: '127.0.0.1:1234' },
  }, res)
  assert.equal(res.status, 200)
  assert.ok(JSON.parse(res.body).uiToken)

  const { agent, sections, tools } = makeAgent('live-session-1', 'D:\\demo')
  await emit(mock, 'agent/created', { agent })
  assert.ok(sections.has('dsh-augment:evolved'))
  assert.ok(sections.has('dsh-augment:learned'))
  assert.equal(typeof sections.get('dsh-augment:evolved').text, 'function')

  // A failed tool result produces one bounded self-repair hint once the cooldown is satisfied.
  const exec = { agent, name: 'bash', arguments: { command: 'npm test' }, callId: 'c1' }
  const result = { isError: true, content: [{ type: 'text', text: 'Error: test failed' }] }
  const handlers = mock.handlers.get('tools/post-execute') || []
  // Waterfall: the last registered handler settles first; earlier handlers see its decision.
  const waterfall = (index) => async () => {
    if (index >= handlers.length) return { kind: 'accept', content: result.content }
    return handlers[index](exec, result, waterfall(index + 1))
  }
  let decision
  const decisions = []
  for (let i = 0; i < 5; i++) {
    decision = await waterfall(0)()
    decisions.push(decision)
  }
  const repaired = decisions.find((item) => Array.isArray(item?.additionalContexts) && item.additionalContexts.length > 0)
  assert.ok(repaired, `no self-repair hint across ${decisions.length} failed calls`)
  assert.match(repaired.additionalContexts[0].content[0].text, /self-repair/)
})

test('augment_evolve status tool reports the active harness', async () => {
  const mock = makeMockContext()
  apply(mock.ctx, {})
  const tool = mock.tools.get('augment_evolve')
  const text = await tool.execute({ action: 'status' }, {})
  assert.match(text, /dsh augment evolution/)
  assert.match(text, /agnes-3\.0-flash|runs=/)
})

test('evolve command reports status and rejects unknown verbs gracefully', async () => {
  const mock = makeMockContext()
  apply(mock.ctx, {})
  const command = mock.commands.get('evolve')
  const status = await command.handler({ agent: {}, rawInput: '' })
  assert.equal(status.kind, 'success')
  assert.match(status.text, /dsh augment evolution/)
  const bad = await command.handler({ agent: {}, rawInput: 'adopt' })
  assert.ok(bad.kind === 'success' || bad.kind === 'error')
})
