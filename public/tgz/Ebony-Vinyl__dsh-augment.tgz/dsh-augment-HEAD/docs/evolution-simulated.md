# dsh augment — 模拟进化验证

- 运行：`sim-mvveh4w2`
- 模式：simulated（确定性 Capability Gym，不调用外部模型）
- 状态：**verified**
- 基线：0.0%
- 进化后：50.0%
- Δ：+50.0 个百分点
- 95% CI：[29.2%, 70.8%]
- 采纳版本：`hv-4382d419afb2458e9591de65`
- 能力标签：format-checklist, memory-recall, read-before-answer, retry-on-error, plan-steps, verify-before-answer
- 用时：1.1s

## 阶段

| 阶段 | 类型 | 状态 | 开发集评分 |
|---|---|---|---:|
| base | base | completed | 0.0% |
| inv1 | invariant | completed | 8.3% |
| inv2 | invariant | completed | 8.3% |
| inv3 | invariant | completed | 8.3% |
| dom1 | domain | completed | 8.3% |
| dom2 | domain | completed | 8.3% |
| dom3 | domain | completed | 8.3% |
| compose | compose | completed | 50.0% |
| select | select | completed | 50.0% |
| reflect | reflect | completed | — |
| validate | validate | completed | 50.0% |

# Evolution evaluation eval-c76f63bce401

Status: **verified**
Tasks: 24 · Reps: 1 · Seed: 42
Created: 2026-10-30T20:03:49.172Z

## Arms
| Arm | Scored | Mean score | Calls | Input tokens | Output tokens | Errors |
|---|---:|---:|---:|---:|---:|---:|
| baseline | 24/24 | 0.000 | 24 | 3491 | 209 | 0 |
| equal-compute | 24/24 | 0.000 | 24 | 3491 | 209 | 0 |
| full-rsi | 24/24 | 0.500 | 24 | 8257 | 227 | 0 |
| reuse-only | 24/24 | 0.000 | 24 | 3491 | 209 | 0 |

## Paired comparisons
| Candidate | Comparator | Delta | 95% CI | Tasks | Confidence |
|---|---|---:|---|---:|---:|
| full-rsi | baseline | 0.500 | [0.292, 0.708] | 24 | 97.5% |
| full-rsi | equal-compute | 0.500 | [0.292, 0.708] | 24 | 97.5% |
| reuse-only | baseline | 0.000 | [0.000, 0.000] | 24 | 95.0% |

## Note
The two co-primary comparisons have positive lower confidence bounds and no task regressed beyond tolerance.

> `verified` is an evaluation-level statement, not a guarantee of future gains. Held-out tasks are deterministic and local.

> 该报告证明进化算法、评测协议和采纳门在确定性环境中端到端工作。它不代表真实模型上的必然提升；实时结果见 EVOLUTION-REPORT.md。