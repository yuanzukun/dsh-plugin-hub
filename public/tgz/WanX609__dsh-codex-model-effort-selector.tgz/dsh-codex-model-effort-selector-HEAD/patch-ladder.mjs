import fs from 'node:fs';
const target = 'D:/dsh_newli/plugins/dsh-codex-model-effort-selector/client.js';
let src = fs.readFileSync(target, 'utf8');
if (src.includes('OFFICIAL_STOPS')) { console.log('已打过统一档位补丁'); process.exit(0); }

const pairs = [];
const add = (from, to) => pairs.push([from, to]);

add(
`      return effort.name || effort.id;
    }`,
`      return effort.name || effort.id;
    }

    /* LOCAL PATCH: 所有 provider 统一成 DeepSeek 官方那四档（Off / Low / High / Max）。
     * 每一档记住该模型真正认得的 effort id（dispatch），提交时发真实 id，
     * 界面统一、请求依旧合法。 */
    const OFFICIAL_STOPS = [
      { id: 'off', name: 'Off' },
      { id: 'low', name: 'Low' },
      { id: 'high', name: 'High' },
      { id: 'max', name: 'Max' }
    ];
    function officialLadder(list) {
      const real = sortEfforts(list);
      if (real.length === 0) return [];
      if (real.length === 1) return [{ id: real[0].id, name: real[0].name || real[0].id, dispatch: real[0].id }];
      return OFFICIAL_STOPS.map((stop, k) => {
        const rank = Math.round((k / (OFFICIAL_STOPS.length - 1)) * (real.length - 1));
        return { id: stop.id, name: stop.name, dispatch: real[rank].id };
      });
    }
    /** 官方档位 id -> 该 provider 认得的 id */
    function dispatchOf(list, id) {
      const hit = list.find(e => e.id === id);
      return hit ? hit.dispatch : id;
    }`);

add(
`      const efforts = sortEfforts(model?.reasoning?.efforts);`,
`      const efforts = officialLadder(model?.reasoning?.efforts);`);

add(
`      const savedEffort = selection?.reasoningEffort ?? model?.reasoning?.defaultEffort;`,
`      const realEffort = selection?.reasoningEffort ?? model?.reasoning?.defaultEffort;
      const savedEffort = efforts.length
        ? (efforts.find(e => e.dispatch === realEffort)?.id ?? efforts[Math.floor(efforts.length / 2)].id)
        : realEffort;`);

add(
`        if (id !== savedEffort) void commit({ ...selection, reasoningEffort: id });`,
`        if (id !== savedEffort) void commit({ ...selection, reasoningEffort: dispatchOf(efforts, id) });`);

add(
`        const declared = model?.reasoning?.defaultEffort;
        if (declared !== undefined && efforts.some(e => e.id === declared)) return declared;
        return efforts[Math.floor(efforts.length / 2)].id;`,
`        const declared = model?.reasoning?.defaultEffort;
        if (declared !== undefined) {
          const stop = efforts.find(e => e.dispatch === declared);
          if (stop) return stop.id;
        }
        return efforts[Math.floor(efforts.length / 2)].id;`);

add(
`        const levels = sortEfforts(nextModel.reasoning?.efforts);`,
`        const levels = officialLadder(nextModel.reasoning?.efforts);`);

add(
`          ...(id === undefined ? {} : { reasoningEffort: id })`,
`          ...(id === undefined ? {} : { reasoningEffort: dispatchOf(levels, id) })`);

add(
`      const levelCount = sortEfforts(m.reasoning?.efforts).length;`,
`      const levelCount = officialLadder(m.reasoning?.efforts).length;`);

for (const [from, to] of pairs) {
  const count = src.split(from).length - 1;
  if (count !== 1) {
    console.error('补丁点出现 ' + count + ' 次（应为 1）：' + JSON.stringify(from.slice(0, 70)));
    process.exit(2);
  }
  src = src.replace(from, () => to);
}
fs.writeFileSync(target, src);
console.log('统一档位补丁已应用：' + target);
