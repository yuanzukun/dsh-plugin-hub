# 本地改动记录（相对上游 dsh-codex-model-effort-selector 1.1.2）

本目录是从 GitHub `ABING1111/dsh-codex-model-effort-selector`（MIT）复制出来的**本地副本**，
profile 以 `link:` 方式引用它，**不再跟随上游更新**。上游原文件保留为 `client.js.orig`（未打补丁的 1.1.2）。

## 改了五处（全部在 client.js）

1. **档位名改英文**（`:50-52`）
   `Off / Minimal / Low / Medium / High / Extra High / Ultra`，中英词典一致。

2. **所有 provider 统一成 DeepSeek 官方那四档**（`:259-281`、`:769-773`、`:958`、`:1007`、`:1020`、`:1408`）
   新增 `OFFICIAL_STOPS` = Off / Low / High / Max 与 `officialLadder()`：
   把任意模型的档位列表按名次投影到这四档上，每一档带一个 `dispatch`（该 provider 真正认识的 effort id），
   提交时用 `dispatchOf()` 换回真实 id —— 界面对齐官方，请求仍然合法。
   单档模型不强行凑四档；无档位模型照旧隐藏滑杆。

3. **最高档特效跟「最高档」走**（`:753` 附近）
   `peak = isPeakId(displayed) || isLastStop`，折叠态胶囊同理。任何 provider 拖到最右端都是紫色渐变 + 粒子。

4. **删掉 ⚡ Fast 开关**（`:681`、`:1448`、`:1544`）
   按钮、触发器闪电都移除，状态恒为 `false`（上游那个开关本来也只是视觉效果，README 自述「仅视觉效果」）。

5. **删掉「更快消耗使用额度」提示**（`:882`、`:1455`）
   文案移除，`enterPeak()` 改为空函数，进入最高档不再无提示地变暗 1.8 秒。

## 维护

- 想重新对齐上游：用 `client.js.orig` 覆盖 `client.js`，再跑一次 `patch-ladder.mjs` 和上面 1/3/4/5 的等价改动。
- 本目录被 profile `link:` 引用，改完 `client.js` **刷新页面**即可（boot 清单没变时不必重启）。

## 追加：第 6 处（2026-11-05，DSH 0.2.2 缩放导致弹层飞出右边）

**现象**：DSH 桌面端（0.2.2-rc.1，Windows 150% 缩放）里点开模型弹层，面板不贴着模型按钮，
而是跑到窗口最右边并被窗口边缘裁掉一半，模型名显示成 `deepseek-v4.1-flas…`。

**根因**：DSH 桌面端在祖先节点上给了 CSS `zoom`（跟显示 DPI / 界面缩放走）。
在缩放子树里，`style.left` 的 px 是**布局像素**，而 `getBoundingClientRect()` 回的是**渲染像素**。
上游 `align()` 直接拿渲染坐标算完又写回 `left`，等于把偏移乘了一次缩放系数
（实测 1.25 倍时面板右移 ~300px 并越界）。Web 端 / 无缩放环境下量不出来，所以之前一直没暴露。

**改法**（`align()`，约 `:1060-1093`）：

- 用 `root.offsetWidth` 与 `root.getBoundingClientRect().width` 的比值测出真实缩放系数
  （必须用 root，弹层自己带 `closed` 态的 `scale(.98)`，拿它测会得到 0.98 的假系数）；
- `left / bottom / 宽度` 全部先在渲染坐标里算好、再除以系数写回 CSS 变量；
- 写入后**再量一次真实矩形**，左右越界就按残差修正（不信任算术）；
- 弹层宽度改由 `--cmes-w` 驱动（CSS 里 `width: var(--cmes-w, 272px)`），窄窗口下随缩放收窄；
- 算「触发点上方还剩多少空间」时也把窗口高度换算到布局像素（`:1352-1362` 附近）。

**回归验证**（无头 Chrome，同一份 DSH 0.2.2 客户端）：

| 场景 | 改前 | 改后 |
|---|---|---|
| 无缩放 1600×1000 | 居中、不越界 | 居中（偏差 -2px）、不越界 |
| html zoom 1.25 | 左 1314 / 右 1654，越界 54px（复现你的截图） | 左 1015 / 右 1355，居中、不越界 |
| html zoom 1.5 | 越界更严重 | 居中、不越界 |
| body zoom 1.25，宽 1700 | 越界 | 居中、不越界 |
| zoom 1.25 + 矮窗口 620（模型长列表） | — | 顶部 31px、底部 388px，不出屏 |

改前版本备份：`client.js.bak-20261105-093651`；上游原版仍是 `client.js.orig`。
