# DSH CLIProxyAPI Provider

[![CI](https://github.com/ChadCSong/dsh-cliproxyapi-provider/actions/workflows/ci.yml/badge.svg)](https://github.com/ChadCSong/dsh-cliproxyapi-provider/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

面向 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)（DSH）的
[CLIProxyAPI](https://github.com/router-for-me/CLIProxyAPI) 自动发现与模型同步插件。

它能自动发现本地 CPA 服务，并把实时模型目录同步到 DSH 原生模型选择器。

> [English](README.md)

## 主要功能

- **本地地址零配置**：依次探测 `127.0.0.1:8317`、`localhost:8317` 和 `[::1]:8317`。
- **动态模型发现**：读取 `/v1/models?client_version=pi`，同时兼容标准 `data[].id` 格式。
- **原生模型切换**：所有模型进入 DSH 的模型选择器，显示在 `CLIProxyAPI (auto)` 分组下。
- **新版本在上**：同一模型家族内按版本倒序排列。
- **同步原生能力**：同步上下文上限、输出上限、reasoning 和图片输入能力。
- **自动刷新**：CPA 增删账号或模型后，无需重装插件。
- **安全保存 Key**：API Key 通过 DSH credential service 保存，不写入 `settings.yaml`。
- **标准 DSH 插件**：同一份包支持 DSH Web、headless profile 和 DSH Desktop，不是 Desktop 私有插件。

## 环境要求

- DeepSeek Harness `0.2.1-rc.2`（官方桌面版或同版本 Web/headless 主机）
- Node.js `22.19+` 或 `24+`
- 已启动的 CLIProxyAPI 服务

插件 `0.3.0` 以 DSH `0.2.1-rc.2` 的公开接口为基准，保守声明兼容范围
`>=0.2.1-rc.2 <0.2.2-0`；后续 DSH 版本线需重新验证。DSH `0.1.5` 用户请保留插件
`0.1.9`，本次新版不再兼容旧设置 API。

## 安装

安装到你使用的 DSH profile：

```sh
dsh plugin --profile web add github:ChadCSong/dsh-cliproxyapi-provider
```

官方桌面版请在 App 内通过 **插件 → 添加插件**，输入上述 GitHub 地址规范或 GitHub Release
的 `.tgz` 安装包地址。不要用不相关的全局 CLI 修改 App 管理的 `desktop` profile。
安装到 `web` 不会同时更新桌面版。

安装或更新本插件后请重启一次 App/主机，让后台同步任务在 DSH 热重载事务之外启动。
之后修改插件设置无需重启，会自动生效。
插件已经通过 `package.json` 和 `cordis.patch.yml` 声明标准
DSH bundle，不需要手动修改 profile。

### 从本地源码安装

```sh
git clone https://github.com/ChadCSong/dsh-cliproxyapi-provider.git
cd dsh-cliproxyapi-provider
pnpm install
pnpm build
dsh plugin --profile web add "$PWD"
```

请把 `web` 换成你实际使用的 profile。

## 使用方法

1. 启动 CLIProxyAPI。使用默认 `8317` 端口时，CPA 地址可以留空。
2. 打开 DSH 的 **插件 → dsh-cliproxyapi-provider**，设置就在插件详情页。
3. CPA 开启 bearer 鉴权时，填写一次 API Key。
4. 回到会话，在 DSH 原生模型选择器的 **CLIProxyAPI (auto)** 分组中选择模型。

还可以使用：

```text
/cpa-status
/cpa-refresh
```

`/cpa-status` 查看当前连接地址和已同步模型数量；`/cpa-refresh` 立即重新探测并刷新模型目录。

## 可选生图功能（0.3.0）

在插件详情页先保存现有 CPA 地址和 Key，点击「图片生成」区域的「刷新模型列表」。
这里独立读取完整 `/v1/models`，不使用 Pi/聊天过滤目录。生图模型直接从下拉框选择，
不需要输入 ID。选定协议并开启开关即可；默认关闭。

- 常见 GPT Image / Grok Imagine Image 名称使用 `/v1/images/generations`；
  Gemini 生图名称使用 `/v1beta/models/{model}:generateContent`。
- 生图下拉框只显示 ID 或名称包含 `image` 的模型（不区分大小写），不影响聊天模型列表。
  未知生图别名需选择 OpenAI Images 或 Gemini 协议，可用性以 CPA 实际返回为准。
- 开启且选定模型与可识别协议后，注册内置 `/cpa-image` 技能及 `cpa_generate_image`
  工具，由 DSH 正常技能/工具目录告诉模型可用能力，不写入全局技能目录。
- 直接说「帮我生成一张……」或使用 `/cpa-image`。每次调用生成一张图片，复用当前
  CPA 地址和凭据；此版本仅支持文生图，不支持参考图编辑、批量生成。
- DSH 附件服务验证并持久保存图片，结果包含本地图片链接；只有主模型支持读图时才
  同时返回图片内容块，不修改主对话模型或它的原生能力声明。
- 生图可能消耗额度，不自动重试；超时后先确认上游用量。取消本地请求不保证上游退款。
- 关闭开关即移除技能和工具并取消在途请求。只接收内联 PNG/JPEG/WebP，拒绝自动下载
  上游返回的 URL。模型列表接口仅供经过 DSH 认证的所有者读取，不接收客户端地址或 Key。

## 配置

DSH 0.2 使用 profile 条目 ID `llm-cliproxyapi-auto` 作为配置表单命名空间。
推荐通过界面设置，等效 profile patch 如下：

```yaml
- id: llm-cliproxyapi-auto
  config:
    enabled: true
    # 留空即自动探测，也支持显式填写远程 CPA 地址
    baseURL: ''
    apiKeyEnv: CLIPROXYAPI_API_KEY
    protocol: openai-completions
    refreshIntervalSeconds: 300
    probeTimeoutMs: 2000
```

### 地址解析顺序

插件去重后按以下顺序探测：

1. 设置中明确填写的 `baseURL`
2. DSH 启动环境中的 `CLIPROXYAPI_BASE_URL`
3. 本机 `8317` 端口的 loopback 候选地址

只有你明确配置时，插件才会访问非本机地址。

### API Key

`apiKeyEnv` 是凭据引用名，不是明文密钥。设置界面通过 DSH credential service 写入 API Key，
默认引用名为 `CLIPROXYAPI_API_KEY`。
读取遵循 DSH 主机的已保存凭据/环境变量策略。普通配置一次性提交成功后，才单独保存 Key；
失败时保留尚未保存的输入。若遇到其他编辑器造成的版本冲突，请放弃草稿后重新编辑。

### 刷新与原生配置

插件管理模型列表和顺序，以及插件设置中的地址、协议和凭据引用；保留原生界面设置的超时、
协议兼容参数和模型字段修改。图片输入能力始终以 CPA 为准，避免保留旧版读图桥生成的虚假
能力标记。重启后的第一次刷新会保守保留已有模型调参；同一运行期间，
未被用户修改的生成字段继续跟随 CPA 元数据更新。显式模型列表不能与原生 `modelOverrides`
同时使用。不会恢复独立读图模型或图片预处理。

旧插件升级不会自动迁移任意旧 `settings.yaml` 段，请在新详情页核对设置；已有凭据仍由 DSH
保管。能看到旧模型列表不代表插件已运行，应同时确认组件状态及 `/cpa-status`。

### 推理协议

默认 `openai-completions`，使用 CPA 的 `/v1/chat/completions`。只有 CPA 部署要求通过 Responses API
调用目标模型时，才需要切换为 `openai-responses`。

### 图片输入

插件只同步 CPA 返回的原生输入能力。声明支持图片的模型由 DSH 官方 adapter 直接接收图片，
纯文本模型仍保持纯文本能力。插件不再提供独立读图模型、图片转文字预处理或能力覆盖；会话中
存在图片时，由 DSH 本体执行原生兼容性检查。

## 兼容原理

插件通过公开的 settings contract 管理 DSH 官方 `@deepseek-ai/dsh-llm-pi-ai` adapter 中的一条
route；不修改 Harness，也不自行复制模型传输层。因此流式响应、工具调用、附件、reasoning、
图片处理和错误处理仍由官方 adapter 负责。

Host 代码不导入 Electron 或 `dsh-plugin-desktop` API，设置卡片也只使用公开 DSH client service/slot，
所以它可以同时用于 CLI/Web 和 Desktop profile。

## 开发

```sh
pnpm install
pnpm test
pnpm typecheck
pnpm build
```

针对本地 Harness 源码开发时：

```sh
DSH_CHECKOUT=/absolute/path/to/deepseek-harness pnpm test
DSH_CHECKOUT=/absolute/path/to/deepseek-harness pnpm build
```

也可以让 `DSH_PACKAGES_ROOT` 指向 DSH 的 `node_modules`。构建生成的本地路径文件已被 Git 忽略，
不会进入发布包。

## 安全与贡献

自动探测只访问 loopback 地址。插件不会把明文 API Key 写入设置、模型缓存或日志。安全问题请参考
[SECURITY.md](SECURITY.md) 私下报告。

欢迎提交 Issue 和 Pull Request。修改行为时请补充或更新测试，并确保 `pnpm test`、
`pnpm typecheck` 和 `pnpm build` 通过。

## License

[MIT](LICENSE)
