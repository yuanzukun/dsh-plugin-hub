# DSH CLIProxyAPI Provider

[![CI](https://github.com/ChadCSong/dsh-cliproxyapi-provider/actions/workflows/ci.yml/badge.svg)](https://github.com/ChadCSong/dsh-cliproxyapi-provider/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

An auto-discovery [CLIProxyAPI](https://github.com/router-for-me/CLIProxyAPI) provider for
[DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) (DSH).

It discovers a local CPA service and synchronizes the live model catalog into DSH's native model picker.

> [简体中文说明](README.zh-CN.md)

## Why this plugin?

Generic OpenAI-compatible routes usually require a manually maintained base URL and model list. This
plugin treats CLIProxyAPI as a first-class, dynamic DSH provider:

- **Zero-address local setup** — probes `127.0.0.1:8317`, `localhost:8317`, and `[::1]:8317`.
- **Live model discovery** — reads `/v1/models?client_version=pi`, with standard `data[].id` fallback.
- **Native model switching** — models appear under `CLIProxyAPI (auto)` in DSH's model picker.
- **Newest versions first** — versions are sorted newest-first inside each model family.
- **Native capability sync** — imports context/output limits, reasoning support, and image input
  when CPA reports them.
- **Automatic refresh** — CPA account or model changes are picked up without reinstalling the plugin.
- **Credential-safe** — the API key is stored through DSH's credential service, not in `settings.yaml`.
- **Standard DSH bundle** — works with DSH Web, headless profiles, and DSH Desktop; it is not a
  Desktop-only extension.

## Requirements

- DeepSeek Harness `0.2.1-rc.2` (official Desktop or a matching Web/headless host)
- Node.js `22.19+` or `24+`
- A running CLIProxyAPI instance

Plugin `0.3.0` targets the public DSH `0.2.1-rc.2` contracts. Its conservative
`engines.dsh` range is `>=0.2.1-rc.2 <0.2.2-0`; later DSH lines require another compatibility check.
For DSH `0.1.5`, stay on plugin `0.1.9`. This release is not backward-compatible with the old settings API.

## Install

Install directly from GitHub into the profile you use:

```sh
dsh plugin --profile web add github:ChadCSong/dsh-cliproxyapi-provider
```

For the official Desktop app, use **Plugins → Add plugin** inside the app and enter the GitHub
spec above (or the `.tgz` asset from a GitHub Release). Do not use an unrelated global CLI to manage
the app-owned `desktop` profile. Installing into `web` does not update Desktop.

Restart the host once after installing/updating this plugin. DSH's HMR transaction context must not
be inherited by the background route writer. Subsequent setting edits apply live without a restart.
No manual profile patching is needed;
the standard DSH bundle declaration lives in `package.json` and `cordis.patch.yml`.

### Install from a local checkout

```sh
git clone https://github.com/ChadCSong/dsh-cliproxyapi-provider.git
cd dsh-cliproxyapi-provider
pnpm install
pnpm build
dsh plugin --profile web add "$PWD"
```

Replace `web` with the profile you actually use.

## Setup and usage

1. Start CLIProxyAPI. Leave the URL empty when it listens on the default port, `8317`.
2. Open **Plugins → dsh-cliproxyapi-provider** in DSH; settings are on the bundle's detail page.
3. If CPA bearer authentication is enabled, enter the API key once.
4. Return to a conversation and select any model under **CLIProxyAPI (auto)** in DSH's native picker.

Useful commands:

```text
/cpa-status
/cpa-refresh
```

`/cpa-status` reports the current endpoint and synchronized model count. `/cpa-refresh` immediately
probes CPA and refreshes the DSH model catalog.

## Optional image generation (0.3.0)

In the CPA plugin details, save the existing URL/key, then use **Refresh models**
under **Optional: image generation**. This reads the full `/v1/models` catalog,
not the Pi/chat-filtered catalog. Select a model from the dropdown (no typed IDs),
select its image protocol, and enable the feature. The default is **off**.

- Common GPT Image / Grok Imagine Image names use OpenAI `/v1/images/generations`;
  Gemini image names use `/v1beta/models/{model}:generateContent`.
- The image dropdown only shows IDs or names containing `image` (case-insensitive),
  without changing the chat model list. Unknown image-named aliases need an explicit
  OpenAI Images or Gemini protocol. Availability depends on the actual CPA response.
- The bundled `/cpa-image` skill and `cpa_generate_image` tool are registered only
  while enabled with a selected model and a resolvable protocol. DSH's normal
  catalogs advertise them to the agent; no global skill files are written.
- Say “generate an illustration of …”, or invoke `/cpa-image`. Each call makes
  **one text-to-image request** using the saved CPA endpoint and credentials.
  Reference-image editing and batch generation are not implemented.
- Images are validated and saved by DSH's durable attachment service. Results
  include a local image link; an image content block is included only when the
  conversation model declares image input. The conversation model is not changed.
- Requests may consume quota. There are **no automatic retries**; after a timeout,
  check upstream usage before trying again. Local cancellation does not guarantee
  cancellation or refund by the upstream provider.
- Disabling removes both skill and tool and cancels active requests. Returned
  image URLs are never fetched; inline PNG/JPEG/WebP is required.

Desktop and Web use DSH's authenticated carrier for catalog reads. Only the
owner may read this endpoint; it accepts no client-supplied URL or secret.

## Configuration

DSH 0.2 uses the bundle's profile entry ID, `llm-cliproxyapi-auto`, as the form namespace.
Prefer the UI; the equivalent profile patch is:

```yaml
- id: llm-cliproxyapi-auto
  config:
    enabled: true
    # Empty means local auto-discovery. Remote CPA is also supported.
    baseURL: ''
    apiKeyEnv: CLIPROXYAPI_API_KEY
    protocol: openai-completions
    refreshIntervalSeconds: 300
    probeTimeoutMs: 2000
```

### Endpoint resolution

Candidates are deduplicated and tried in this order:

1. Explicit `baseURL` setting
2. `CLIPROXYAPI_BASE_URL` from the DSH launch environment
3. Local loopback candidates on port `8317`

A non-loopback service is contacted only when you explicitly configure it.

### API key storage

`apiKeyEnv` is a credential reference, not the secret itself. The settings UI writes the key through
DSH's credential service. The default reference is `CLIPROXYAPI_API_KEY`.
Resolution follows the host's saved-credential/environment policy. Settings fields save atomically;
the credential is saved separately, only after the settings are accepted. A rejected save retains
the remaining drafts. If another editor changed the same settings, discard and re-edit before retrying.

### Refresh and native edits

Discovery owns model membership/order and the plugin's endpoint/protocol/credential reference.
Native route options (such as timeouts and compatibility flags) and edited model fields are preserved.
Image-input capability always follows CPA, removing any synthetic flag left by the old vision bridge.
On the first refresh after a restart, existing model fields win conservatively; during the same run,
unchanged generated fields track CPA metadata updates. Explicit model lists cannot coexist with
native `modelOverrides`. No separate vision model or image preprocessing is installed.

Upgrading from an old plugin does not migrate arbitrary legacy `settings.yaml` sections. Verify the
settings in the new detail page. Credentials remain in DSH's store; a visible old model list alone
does not prove the plugin is running—check the component state and `/cpa-status`.

### Inference protocol

The default, `openai-completions`, uses CPA's `/v1/chat/completions` route. Select
`openai-responses` only when your CPA deployment exposes the target models through the Responses API.

### Image input

The plugin forwards the input capabilities reported by CPA. Models that declare image input receive images
through DSH's official adapter; text-only models remain text-only. There is no separate vision model, image-to-text
preprocessing, or capability override. DSH applies its native compatibility rules when a session contains images.

## How it works

The plugin manages one route in DSH's official `@deepseek-ai/dsh-llm-pi-ai` adapter through the public
settings contract. It does not patch Harness or reimplement model transport. Streaming, tool calls,
attachments, reasoning, image handling, and errors continue through the official adapter.

The host bundle imports no Electron or `dsh-plugin-desktop` APIs. Its settings card uses public DSH
client services and slots, allowing the same package to run in CLI/Web and Desktop profiles.

## Development

```sh
pnpm install
pnpm test
pnpm typecheck
pnpm build
```

When developing against a local Harness checkout:

```sh
DSH_CHECKOUT=/absolute/path/to/deepseek-harness pnpm test
DSH_CHECKOUT=/absolute/path/to/deepseek-harness pnpm build
```

Alternatively, point `DSH_PACKAGES_ROOT` at a DSH `node_modules` directory. Generated local path files
are ignored by Git and never included in published packages.

## Security

Automatic discovery only contacts loopback addresses. The plugin never writes a literal API key to its
settings, model cache, or logs. See [SECURITY.md](SECURITY.md) to report a vulnerability privately.

## Contributing

Issues and pull requests are welcome. For behavior changes, please include or update Vitest coverage and
verify `pnpm test`, `pnpm typecheck`, and `pnpm build` before submitting.

## License

[MIT](LICENSE)
