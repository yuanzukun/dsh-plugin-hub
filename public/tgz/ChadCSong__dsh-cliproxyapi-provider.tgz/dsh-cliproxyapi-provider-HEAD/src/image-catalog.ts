import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-connection'
import type { ResolvedConfig } from './config.js'
import { discoverCpa } from './discovery.js'
import { imageChoices } from './image-models.js'

/** Read-only, owner-only RPC over DSH's authenticated carrier, including Desktop.
 * No arbitrary URL/key supplied by the browser; only saved configuration is used.
 * The response contains model IDs/names, never credentials or raw provider data.
 */
export function registerImageCatalog(ctx: Context, options: {
  config: () => ResolvedConfig
  resolveApiKey: (ref: string) => Promise<string | undefined>
  environmentBaseURL: () => string | undefined
}): void {
  ctx.inject(['connection'], inner => {
    const lifetime = new AbortController()
    inner.effect(() => () => lifetime.abort(), 'CPA catalog lifetime')
    // The single shared RPC interceptor belongs to DSH's Gateway. An exact
    // route coexists with it and inherits the carrier's owner-only admission.
    inner.connection.fetch.register({ path: '/api/cpaImages/catalog', methods: ['POST'], requestBody: 'buffered', fetch: async request => {
      const body: unknown = await request.json().catch(() => null)
      if (body === null || typeof body !== 'object') return new Response('Invalid request', { status: 400 })
      const message = body as Record<string, unknown>
      if (message.type !== 'client-request' || typeof message.rpcId !== 'string' || message.rpcId.length > 128
        || message.method !== 'cpaImages/catalog' || message.payload !== null) return new Response('Invalid request', { status: 400 })
      const reply = (result: unknown): Response => Response.json({ type: 'server-response', rpcId: message.rpcId, result })
      try {
        const config = options.config()
        const apiKey = await options.resolveApiKey(config.apiKeyEnv)
        const environmentBaseURL = options.environmentBaseURL()
        const catalog = await discoverCpa({ catalogMode: 'standard', baseURL: config.baseURL,
          ...(apiKey === undefined ? {} : { apiKey }), ...(environmentBaseURL === undefined ? {} : { environmentBaseURL }),
          timeoutMs: config.probeTimeoutMs, signal: AbortSignal.any([request.signal, lifetime.signal]) })
        if (JSON.stringify(config) !== JSON.stringify(options.config())) throw new Error('stale configuration')
        return reply({ ok: true, value: imageChoices(catalog.models) })
      } catch { return reply({ ok: false, error: { code: 'cpa/catalog', message: 'Could not load CPA models. Save URL/key and retry.', details: {} } }) }
    } })
  })
}
