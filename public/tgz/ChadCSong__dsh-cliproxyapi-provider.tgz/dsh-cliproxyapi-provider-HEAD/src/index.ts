import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/cordis-plugin-loader'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import { launchEnvironmentOf } from '@deepseek-ai/dsh-launch-environment'
import type {} from '@deepseek-ai/dsh-settings'
import { readConfig, resolveConfig, type LiveConfig, type ResolvedConfig } from './config.js'
import { registerCommands } from './commands.js'
import { CpaRuntime } from './runtime.js'
import { registerImageFeature } from './image-feature.js'
import { registerImageCatalog } from './image-catalog.js'

export { Config } from './config.js'
export type { Config as CpaConfig, ResolvedConfig } from './config.js'
export { discoverCpa, discoveryCandidates, normalizeCpaRoot, parseCatalog } from './discovery.js'
export type { CpaCatalogModel, CpaDiscoveryResult } from './discovery.js'
export { buildPiAiRoute } from './profile.js'
export { CpaRuntime } from './runtime.js'

export const name = 'dsh-cliproxyapi'
export const inject = ['settings', 'credentials']

export function apply(ctx: Context, config: LiveConfig): void {
  let resolved: ResolvedConfig = resolveConfig(readConfig(config))
  let nextRefreshAt = 0

  const resolveApiKey = async (ref: string): Promise<string | undefined> => {
    const credential = credentialRef(ref)
    const credentials = ctx.get('credentials')
    const stored = credentials === undefined ? undefined : await credentials.resolve(credential)
    const raw = stored?.value ?? launchEnvironmentOf(ctx).get(credential)?.value
    const value = raw?.trim()
    return value === undefined || value === '' ? undefined : value
  }

  const runtime = new CpaRuntime({
    settings: ctx.settings,
    config: () => resolved,
    resolveApiKey,
    environmentBaseURL: () => launchEnvironmentOf(ctx).get('CLIPROXYAPI_BASE_URL')?.value,
    logger: ctx.logger,
  })

  const reschedule = (): void => {
    resolved = resolveConfig(readConfig(config))
    nextRefreshAt = 0
  }

  // Loader notifications occur inside HMR's transaction. Never start another
  // settings transaction there (even a deferred promise inherits its async
  // context). A fixed startup timer consumes only a dirty flag. Restart the
  // host after package installation so this timer starts outside HMR.
  const timer = setInterval(() => {
    if (Date.now() < nextRefreshAt) return
    nextRefreshAt = Date.now() + resolved.refreshIntervalSeconds * 1_000
    void runtime.refresh()
  }, 1_000)

  // The namespace is the profile entry ID, not the package or locale name.
  // A custom browser form replaces the automatically generated schema form.
  ctx.effect(() => ctx.settings.configure({ auto: false }, ctx.fiber), 'CPA configuration form')
  ctx.on('loader/volatile-update', reschedule)
  registerImageFeature(ctx, {
    config: () => resolved, resolveApiKey,
    environmentBaseURL: () => launchEnvironmentOf(ctx).get('CLIPROXYAPI_BASE_URL')?.value,
  })
  registerImageCatalog(ctx, {
    config: () => resolved, resolveApiKey,
    environmentBaseURL: () => launchEnvironmentOf(ctx).get('CLIPROXYAPI_BASE_URL')?.value,
  })

  registerCommands(ctx, runtime)
  ctx.on('credentials/reference-updated', ref => {
    if (ref === resolved.apiKeyEnv) nextRefreshAt = 0
  })
  ctx.effect(() => () => {
    clearInterval(timer)
    runtime.dispose()
  }, 'dsh-cliproxyapi refresh loop')
  reschedule()
}
