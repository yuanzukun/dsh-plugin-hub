import type { SettingsForms } from '@deepseek-ai/dsh-settings'
import type { ResolvedConfig } from './config.js'
import { discoverCpa } from './discovery.js'
import { buildPiAiRoute, type PiAiRouteProfile } from './profile.js'

const PI_AI_NS = 'llm-pi-ai'

export interface CpaStatus {
  state: 'idle' | 'probing' | 'connected' | 'error' | 'disabled'
  endpoint?: string
  modelCount: number
  refreshedAt?: string
  error?: string
}

export interface RuntimeLogger {
  info(message: string): void
  warn(message: string): void
  error(error: unknown): void
}

export interface CpaRuntimeOptions {
  settings: Pick<SettingsForms, 'mutate' | 'describe'>
  config: () => ResolvedConfig
  resolveApiKey: (ref: string) => Promise<string | undefined>
  environmentBaseURL: () => string | undefined
  logger: RuntimeLogger
  fetch?: typeof fetch
}

function sameJson(left: unknown, right: unknown): boolean {
  return JSON.stringify(left) === JSON.stringify(right)
}

function record(value: unknown): Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown> : {}
}

/** Merge catalog-owned fields without destroying native model/transport tuning.
 * On the first refresh there is no trustworthy generated baseline, so existing
 * model fields win. Later refreshes update unchanged generated fields, keeping
 * deliberate native edits. Added/removed IDs and ordering always follow CPA.
 */
export function mergeRoute(current: unknown, next: PiAiRouteProfile, previous?: PiAiRouteProfile): Record<string, unknown> {
  const existing = record(current)
  const models = new Map((Array.isArray(existing.models) ? existing.models : [])
    .map(value => { const model = record(value); return [model.id, model] as const }))
  const baseline = new Map(previous?.models.map(model => [model.id, model]))
  const merged: Record<string, unknown> = {
    ...existing, ...next,
    models: next.models.map(model => {
      const old = models.get(model.id)
      if (old === undefined) return model
      const prior = baseline.get(model.id)
      const result: Record<string, unknown> = { ...old }
      // Only the generated model fields participate in three-way merging.
      for (const key of ['name', 'contextWindow', 'maxTokens', 'reasoningEfforts'] as const) {
        if (!Object.hasOwn(old, key) || (prior !== undefined && sameJson(old[key], prior[key]))) {
          if (model[key] === undefined) delete result[key]
          else result[key] = model[key]
        }
      }
      // Input capability is not a tuning knob: pre-0.1.9 routes may carry the
      // removed vision bridge's image flag. CPA is authoritative on every sync.
      return { ...result, id: model.id, input: model.input }
    }),
  }
  // Explicit models and modelOverrides are mutually exclusive in native pi-ai.
  delete merged.modelOverrides
  // Preserve custom headers, but never leave our unauthenticated placeholder
  // overriding a newly configured real credential.
  const headers = { ...record(existing.headers) }
  for (const key of Object.keys(headers)) {
    if (key.toLowerCase() === 'authorization' && headers[key] === 'Bearer cpa-local') delete headers[key]
  }
  if (next.apiKeyEnv === undefined) {
    delete merged.apiKeyEnv
    if (!Object.keys(headers).some(key => key.toLowerCase() === 'authorization')) Object.assign(headers, next.headers)
  }
  if (Object.keys(headers).length) merged.headers = headers
  else delete merged.headers
  return merged
}

export class CpaRuntime {
  private activeProvider: string | undefined
  private activeProfile: PiAiRouteProfile | undefined
  private running: Promise<void> | undefined
  private rerun = false
  private controller = new AbortController()
  private currentStatus: CpaStatus = { state: 'idle', modelCount: 0 }

  constructor(private readonly options: CpaRuntimeOptions) {}

  status(): CpaStatus {
    return { ...this.currentStatus }
  }

  refresh(): Promise<void> {
    if (this.controller.signal.aborted) return Promise.resolve()
    if (this.running !== undefined) {
      this.rerun = true
      return this.running
    }
    this.running = this.runLoop().finally(() => { this.running = undefined })
    return this.running
  }

  dispose(): void {
    this.rerun = false
    this.controller.abort(new Error('dsh-cliproxyapi disposed'))
    // Do not await an already-submitted settings write: it can be queued behind
    // the HMR transaction currently disposing us, causing a deadlock. Requests
    // are aborted; submitted writes retain their native revision fence.
  }

  private async runLoop(): Promise<void> {
    do {
      this.rerun = false
      try {
        await this.syncOnce()
      } catch (error) {
        if (this.controller.signal.aborted) return
        const message = error instanceof Error ? error.message : String(error)
        this.currentStatus = { ...this.currentStatus, state: 'error', error: message }
        this.options.logger.warn(message)
      }
    } while (this.rerun && !this.controller.signal.aborted)
  }

  private async syncOnce(): Promise<void> {
    const config = this.options.config()
    if (!config.enabled) {
      const provider = this.activeProvider ?? config.provider
      const section = this.options.settings.describe().find(section => section.ns === PI_AI_NS)
      if (this.activeProvider !== undefined || record(record(section?.value).providers)[provider] !== undefined) {
        await this.options.settings.mutate(PI_AI_NS, [{ op: 'unset', path: ['providers', provider] }], section?.revision)
      }
      this.activeProvider = undefined
      this.activeProfile = undefined
      this.currentStatus = { state: 'disabled', modelCount: 0 }
      return
    }

    const { error: _previousError, ...previousStatus } = this.currentStatus
    this.currentStatus = { ...previousStatus, state: 'probing' }
    const apiKey = await this.options.resolveApiKey(config.apiKeyEnv)
    if (this.controller.signal.aborted) return
    const environmentBaseURL = this.options.environmentBaseURL()
    const result = await discoverCpa({
      baseURL: config.baseURL,
      ...environmentBaseURL === undefined ? {} : { environmentBaseURL },
      ...apiKey === undefined ? {} : { apiKey },
      timeoutMs: config.probeTimeoutMs,
      signal: this.controller.signal,
      ...this.options.fetch === undefined ? {} : { fetch: this.options.fetch },
    })
    const built = buildPiAiRoute(config, result, apiKey !== undefined)
    // A pending probe may finish after a config edit. Do not install stale
    // endpoints/credentials; the refresh queued by the edit runs next.
    if (this.controller.signal.aborted || !sameJson(config, this.options.config())) return

    if (this.activeProvider !== config.provider || !sameJson(this.activeProfile, built.profile)) {
      const section = this.options.settings.describe().find(section => section.ns === PI_AI_NS)
      if (section === undefined) throw new Error('dsh-cliproxyapi: native llm-pi-ai configuration is unavailable')
      const current = record(record(section.value).providers)[config.provider]
      const profile = mergeRoute(current, built.profile, this.activeProvider === config.provider ? this.activeProfile : undefined)
      await this.options.settings.mutate(PI_AI_NS, [
        { op: 'set', path: ['providers', config.provider], value: profile },
        ...(this.activeProvider !== undefined && this.activeProvider !== config.provider
          ? [{ op: 'unset' as const, path: ['providers', this.activeProvider] }]
          : []),
      ], section.revision)
      if (this.controller.signal.aborted) return
      this.activeProvider = config.provider
      this.activeProfile = built.profile
    }

    this.currentStatus = {
      state: 'connected',
      endpoint: result.rootURL,
      modelCount: result.models.length,
      refreshedAt: new Date().toISOString(),
    }
    this.options.logger.info(
      `dsh-cliproxyapi: connected to ${result.rootURL}; synchronized ${result.models.length} model(s)`,
    )
  }
}
