import Schema from '@deepseek-ai/schemastery'

export const DEFAULT_PROVIDER = 'cliproxyapi'
export const DEFAULT_DISPLAY_NAME = 'CLIProxyAPI (auto)'
export const DEFAULT_API_KEY_ENV = 'CLIPROXYAPI_API_KEY'
export const DEFAULT_REFRESH_INTERVAL_SECONDS = 300
export const DEFAULT_PROBE_TIMEOUT_MS = 2_000

export type CpaProtocol = 'openai-completions' | 'openai-responses'

export interface Config {
  enabled?: boolean
  provider?: string
  displayName?: string
  /** Optional explicit CPA root. Empty means local auto-discovery. */
  baseURL?: string
  /** Credential/environment reference, never the literal secret. */
  apiKeyEnv?: string
  protocol?: CpaProtocol
  refreshIntervalSeconds?: number
  probeTimeoutMs?: number
  /** Explicit opt-in: generation may consume upstream quota. */
  imageGenerationEnabled?: boolean
  imageModel?: string
  imageProtocol?: 'auto' | 'openai' | 'gemini'
}

// DSH 0.2 exposes only volatile fields to configForms. The host supplies live
// references, while discovery and tests consume plain values via readConfig.
export const Config = Schema.object({
  enabled: Schema.boolean().default(true).volatile(),
  provider: Schema.string().pattern(/\S/).default(DEFAULT_PROVIDER).volatile(),
  displayName: Schema.string().default(DEFAULT_DISPLAY_NAME).volatile(),
  baseURL: Schema.string().default('').volatile(),
  apiKeyEnv: Schema.string().pattern(/\S/).role('credential-ref').default(DEFAULT_API_KEY_ENV).volatile(),
  protocol: Schema.union(['openai-completions', 'openai-responses']).default('openai-completions').volatile(),
  refreshIntervalSeconds: Schema.number().step(1).min(15).max(86_400).default(DEFAULT_REFRESH_INTERVAL_SECONDS).volatile(),
  probeTimeoutMs: Schema.number().step(1).min(250).max(30_000).default(DEFAULT_PROBE_TIMEOUT_MS).volatile(),
  imageGenerationEnabled: Schema.boolean().default(false).volatile(),
  imageModel: Schema.string().default('').volatile(),
  imageProtocol: Schema.union(['auto', 'openai', 'gemini']).default('auto').volatile(),
})

export type LiveConfig = ReturnType<typeof Config>

export function readConfig(config: LiveConfig): Config {
  // Ignore retired keys (e.g. the pre-0.1.9 vision bridge) in older profiles.
  return {
    enabled: config.enabled.get(), provider: config.provider.get(),
    displayName: config.displayName.get(), baseURL: config.baseURL.get(),
    apiKeyEnv: config.apiKeyEnv.get(), protocol: config.protocol.get(),
    refreshIntervalSeconds: config.refreshIntervalSeconds.get(),
    probeTimeoutMs: config.probeTimeoutMs.get(),
    imageGenerationEnabled: config.imageGenerationEnabled.get(),
    imageModel: config.imageModel.get(),
    imageProtocol: config.imageProtocol.get(),
  }
}

export interface ResolvedConfig {
  enabled: boolean
  provider: string
  displayName: string
  baseURL: string
  apiKeyEnv: string
  protocol: CpaProtocol
  refreshIntervalSeconds: number
  probeTimeoutMs: number
  imageGenerationEnabled: boolean
  imageModel: string
  imageProtocol: 'auto' | 'openai' | 'gemini'
}

export function resolveConfig(config: Config): ResolvedConfig {
  const provider = (config.provider ?? DEFAULT_PROVIDER).trim()
  if (provider.length === 0) throw new Error('dsh-cliproxyapi: provider must be non-empty')
  const displayName = (config.displayName ?? DEFAULT_DISPLAY_NAME).trim() || DEFAULT_DISPLAY_NAME
  const apiKeyEnv = (config.apiKeyEnv ?? DEFAULT_API_KEY_ENV).trim()
  if (apiKeyEnv.length === 0) throw new Error('dsh-cliproxyapi: apiKeyEnv must be non-empty')
  return {
    enabled: config.enabled ?? true,
    provider,
    displayName,
    baseURL: (config.baseURL ?? '').trim(),
    apiKeyEnv,
    protocol: config.protocol ?? 'openai-completions',
    refreshIntervalSeconds: config.refreshIntervalSeconds ?? DEFAULT_REFRESH_INTERVAL_SECONDS,
    probeTimeoutMs: config.probeTimeoutMs ?? DEFAULT_PROBE_TIMEOUT_MS,
    imageGenerationEnabled: config.imageGenerationEnabled ?? false,
    imageModel: (config.imageModel ?? '').trim(),
    imageProtocol: config.imageProtocol ?? 'auto',
  }
}
