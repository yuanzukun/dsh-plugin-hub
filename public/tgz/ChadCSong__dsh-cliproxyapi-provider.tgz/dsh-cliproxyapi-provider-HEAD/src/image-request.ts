import { imageTransport } from './image-models.js'

const MAX_RESPONSE_BYTES = 24 * 1024 * 1024
const MAX_IMAGE_BYTES = 16 * 1024 * 1024
export interface GeneratedImage { bytes: Uint8Array; mediaType: 'image/png' | 'image/jpeg' | 'image/webp' }

/** Bounded streaming read: never buffer an unbounded upstream response. */
async function readJson(response: Response): Promise<unknown> {
  if (!response.body) throw new Error('CPA returned an empty response')
  const reader = response.body.getReader()
  const chunks: Uint8Array[] = []
  let length = 0
  try {
    for (;;) {
      const next = await reader.read()
      if (next.done) break
      length += next.value.length
      if (length > MAX_RESPONSE_BYTES) throw new Error('CPA image response exceeds 24 MiB')
      chunks.push(next.value)
    }
  } finally { await reader.cancel().catch(() => {}); reader.releaseLock() }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')) }
  catch { throw new Error('CPA returned invalid image JSON') }
}

function object(value: unknown): Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {}
}

function decodeImage(encoded: unknown): GeneratedImage {
  if (typeof encoded !== 'string' || encoded.length > Math.ceil(MAX_IMAGE_BYTES / 3) * 4
    || !/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)) throw new Error('CPA returned invalid or oversized image data')
  const bytes = Buffer.from(encoded, 'base64')
  if (bytes.toString('base64') !== encoded) throw new Error('CPA returned non-canonical image data')
  // Actual bytes, not the upstream MIME label, decide the decoder. The DSH
  // attachment service performs the full pixel/dimension validation later.
  const mediaType = bytes.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10])) ? 'image/png'
    : bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255 ? 'image/jpeg'
    : bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP' ? 'image/webp' : undefined
  if (!mediaType) throw new Error('CPA returned an unsupported image format')
  return { bytes, mediaType }
}

/** Never fetch returned URLs: they could target private services or leak a key.
 * Request inline bytes and refuse URL-only outputs. No automatic retry of paid
 * requests; a timeout can mean the provider already generated/billed an image.
 */
export async function requestImage(options: {
  rootURL: string; apiKey?: string; model: string; prompt: string
  protocol?: 'auto' | 'openai' | 'gemini'
  signal: AbortSignal; fetch?: typeof fetch
}): Promise<GeneratedImage> {
  const transport = options.protocol && options.protocol !== 'auto' ? options.protocol : imageTransport(options.model)
  if (!transport) throw new Error('Model alias has no known transport; select OpenAI Images or Gemini explicitly in plugin settings')
  const prompt = options.prompt.trim()
  if (!prompt || prompt.length > 16000) throw new Error('Image prompt must contain 1–16000 characters')
  const path = transport === 'gemini' ? `/v1beta/models/${encodeURIComponent(options.model)}:generateContent` : '/v1/images/generations'
  const body = transport === 'gemini'
    ? { contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { responseModalities: ['TEXT', 'IMAGE'], candidateCount: 1 } }
    : { model: options.model, prompt, n: 1, response_format: 'b64_json' }
  let response: Response
  try {
    response = await (options.fetch ?? fetch)(options.rootURL + path, {
      method: 'POST', redirect: 'error', signal: options.signal,
      headers: { 'Content-Type': 'application/json', ...(options.apiKey ? { Authorization: `Bearer ${options.apiKey}` } : {}) },
      body: JSON.stringify(body),
    })
  } catch { throw new Error('CPA image request interrupted or failed; check provider usage before retrying') }
  if (!response.ok) {
    await response.body?.cancel()
    // Never echo an upstream body: it can contain credentials or user prompts.
    throw new Error(`CPA image request failed (HTTP ${response.status}); no automatic retry`)
  }
  const value = object(await readJson(response))
  if (transport === 'openai') {
    const images = Array.isArray(value.data) ? value.data : []
    return decodeImage(object(images[0]).b64_json)
  }
  const candidates = Array.isArray(value.candidates) ? value.candidates : []
  const parts = object(object(candidates[0]).content).parts
  for (const part of Array.isArray(parts) ? parts : []) {
    const record = object(part)
    if (record.thought === true) continue
    const inline = object(record.inlineData ?? record.inline_data)
    if (inline.data !== undefined) return decodeImage(inline.data)
  }
  throw new Error('CPA returned no image; the model/account may not support generation or the request was refused')
}
