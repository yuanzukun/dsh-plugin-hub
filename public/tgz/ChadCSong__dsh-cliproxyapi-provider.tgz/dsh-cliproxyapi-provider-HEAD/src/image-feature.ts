import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-skill'
import type {} from '@deepseek-ai/dsh-attachment'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ResolvedConfig } from './config.js'
import { discoverCpa } from './discovery.js'
import { imageTransport } from './image-models.js'
import { requestImage } from './image-request.js'

/** Bundled instructions stay in the compiled plugin, avoiding writes into a
 * user's global skill directories and disappearing with the feature itself. */
export const IMAGE_SKILL = `Use cpa_generate_image when the user requests an AI-generated picture, illustration, poster or concept image.
The tool uses the user's selected image model and existing CPA credentials. Do not ask for an API key, invent a model ID, or switch the conversation model.
Write a clear prompt preserving the user's subject, composition, style and requested text. Generate only when asked; each call can consume quota. The tool produces one image per call.
Call cpa_generate_image with prompt. Display the returned saved image using Markdown with its absolute path, and provide its file link. Never claim success without a successful tool result.
Do not automatically retry failures or timeouts: the provider may already have billed the request. Explain the failure and ask before another attempt.
This version supports text-to-image only. It cannot edit an existing image or accept reference images; explain this limitation instead of pretending to use an attachment.
If the tool is unavailable, ask the user to enable image generation and select a model in the CPA plugin settings. Do not work around the disabled feature using shell commands or direct network calls.`

export function registerImageFeature(ctx: Context, options: {
  config: () => ResolvedConfig
  resolveApiKey: (ref: string) => Promise<string | undefined>
  environmentBaseURL: () => string | undefined
}): void {
  ctx.inject(['tools', 'skills', 'attachments'], inner => {
    let cleanup: (() => void) | undefined
    let lastConfig = ''
    const update = (): void => {
      const config = options.config()
      const fingerprint = JSON.stringify(config)
      if (fingerprint === lastConfig) return
      lastConfig = fingerprint
      cleanup?.(); cleanup = undefined
      if (!config.enabled || !config.imageGenerationEnabled || !config.imageModel
        || (config.imageProtocol === 'auto' && !imageTransport(config.imageModel))) return
      const lifetime = new AbortController()
      let busy = false
      const removeTool = inner.tools.register(defineTool({
        name: 'cpa_generate_image',
        description: 'Generate one image from a text prompt using the configured CPA image model. Costs provider quota. Text-to-image only; no reference images or editing. Never automatically retry.',
        parameters: { prompt: { type: 'string', required: true, description: 'Complete description of the image to generate (1–16000 characters).' } },
        output: {
          schema: { type: 'json' },
          render: (_args, value) => {
            const result = value as unknown as { path: string; image: ImageAttachmentRef; includeImage: boolean }
            return [
              { type: 'text', text: `Generated image saved at: ${result.path}\n![Generated image](${result.path})` },
              ...(result.includeImage ? [{ type: 'image' as const, attachment: result.image }] : []),
            ]
          },
        },
        async execute(args, exec) {
          if (busy) throw new Error('A CPA image request is already in progress; do not duplicate it')
          if (JSON.stringify(options.config()) !== fingerprint || lifetime.signal.aborted) throw new Error('CPA image configuration changed; request cancelled')
          if (!args.prompt.trim() || args.prompt.length > 16000) throw new Error('Image prompt must contain 1–16000 characters')
          busy = true
          const signal = AbortSignal.any([exec.signal, lifetime.signal, AbortSignal.timeout(180000)])
          try {
            // Keep text-only conversation routes usable: the file link renders
            // for the user without injecting unsupported image input next turn.
            let includeImage = false
            const route = exec.agent?.session.requestHeader()?.config ?? exec.agent?.options
            const llm = inner.get('llm')
            if (llm && route?.provider && route.model) {
              const info = await llm.resolveModelInfo(route.provider, route.model, signal)
              includeImage = info.inputModalities?.includes('image') ?? false
            }
            const apiKey = await options.resolveApiKey(config.apiKeyEnv)
            const environmentBaseURL = options.environmentBaseURL()
            // Re-discover before billing; do not trust a persisted model list or
            // silently send a prompt to another local fallback after POST.
            const catalog = await discoverCpa({ catalogMode: 'standard', baseURL: config.baseURL,
              ...(environmentBaseURL === undefined ? {} : { environmentBaseURL }),
              ...(apiKey === undefined ? {} : { apiKey }), timeoutMs: config.probeTimeoutMs, signal })
            if (!catalog.models.some(model => model.id === config.imageModel)) throw new Error('Selected image model is no longer in the CPA catalog; select another model')
            signal.throwIfAborted()
            const image = await requestImage({ rootURL: catalog.rootURL, model: config.imageModel, protocol: config.imageProtocol, prompt: args.prompt,
              ...(apiKey === undefined ? {} : { apiKey }), signal })
            signal.throwIfAborted()
            const [ref] = await inner.attachments.saveImages([{ data: image.bytes, mediaType: image.mediaType, name: 'cpa-generated-image' }])
            if (!ref) throw new Error('DSH did not save the generated image')
            const path = inner.attachments.imageHostPath(ref)
            if (!path) throw new Error('DSH saved the image but did not expose a local file path')
            return { path, image: { ...ref }, includeImage }
          } finally { busy = false }
        },
      }))
      const removeSkill = inner.skills.register({ name: 'cpa-image', source: 'bundled',
        description: 'Generate an image, illustration or poster through CPA. Use when the user asks to draw or generate a picture. 文生图、画图、生成海报或插画。',
        content: IMAGE_SKILL, invocation: { modelInvocable: true, userInvocable: true } })
      cleanup = () => { lifetime.abort(); removeSkill(); removeTool() }
    }
    // Loader filters volatile notifications to the entry's exact fiber. The
    // injected service context has a different fiber and cannot hear them.
    // Listen on the owner (after its config reader), but release that listener
    // with this injected context so service reloads never retain stale tools.
    inner.effect(() => ctx.on('loader/volatile-update', update), 'CPA image config updates')
    inner.effect(() => () => cleanup?.(), 'CPA image feature lifetime')
    update()
  })
}
