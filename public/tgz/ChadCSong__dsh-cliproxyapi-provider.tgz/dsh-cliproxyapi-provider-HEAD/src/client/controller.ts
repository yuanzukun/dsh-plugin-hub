import type { SnapshotStore } from '@deepseek-ai/dsh-client-store'
import type { ConfigForm, ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client'
import type { CardActions, CardFieldState, CardShell } from './form.js'
import { booleanField, CardForm, choiceField, numberField, textField, type CardApi } from './form.js'

export const SETTINGS_NS = 'llm-cliproxyapi-auto'
const DEFAULT_KEY_REF = 'CLIPROXYAPI_API_KEY'
const API_KEY_FIELD = 'apiKey'

interface Section {
  enabled?: boolean
  provider?: string
  baseURL?: string
  apiKeyEnv?: string
  protocol?: string
  refreshIntervalSeconds?: number
  probeTimeoutMs?: number
  imageGenerationEnabled?: boolean
  imageModel?: string
  imageProtocol?: string
}

interface CredentialState { ref: string; configured: boolean; writable: boolean }

export interface CpaCardState extends CardShell {
  enabled: CardFieldState
  baseURL: CardFieldState
  apiKeyEnv: CardFieldState
  protocol: CardFieldState
  refreshIntervalSeconds: CardFieldState
  probeTimeoutMs: CardFieldState
  apiKey: CardFieldState
  apiKeyConfigured: boolean
  apiKeyWritable: boolean
  imageGenerationEnabled: CardFieldState
  imageModel: CardFieldState
  imageProtocol: CardFieldState
  imageModels: Array<{ value: string; label: string }>
  catalogLoading: boolean
  catalogFailed: boolean
}

export interface CpaCardFace extends CardActions {
  refreshImageModels(): void
  hooks: { cpaCard: SnapshotStore<CpaCardState> }
}

function refOf(snapshot: ConfigFormSnapshot<Section>): string {
  const ref = snapshot.value?.apiKeyEnv
  return typeof ref === 'string' && ref.length > 0 ? ref : DEFAULT_KEY_REF
}

export class CpaCardController {
  private readonly form: CardForm<Section>
  private readonly store: SnapshotStore<CpaCardState>
  private credential: CredentialState = { ref: '', configured: false, writable: false }
  private readonly unsubscribe: () => void
  private disposed = false
  private credentialRead = 0
  private catalogAbort: AbortController | undefined
  private imageModels: Array<{ value: string; label: string }> = []
  private catalogLoading = false
  private catalogFailed = false
  private catalogConfig = ''

  constructor(private readonly scope: ConfigForm<Section>, private readonly api: CardApi,
    private readonly loadCatalog?: (signal: AbortSignal) => Promise<Array<{ value: string; label: string }>>) {
    this.form = new CardForm(scope, [
      booleanField('enabled'),
      textField('baseURL'),
      textField('apiKeyEnv'),
      choiceField('protocol', ['openai-completions', 'openai-responses']),
      numberField('refreshIntervalSeconds', 15, 86_400),
      numberField('probeTimeoutMs', 250, 30_000),
      booleanField('imageGenerationEnabled'),
      { ...textField('imageModel'), parse: text => text === '' ? { kind: 'clear' } : this.imageModels.some(model => model.value === text) ? { kind: 'set', value: text } : undefined },
      choiceField('imageProtocol', ['auto', 'openai', 'gemini']),
    ], [{ field: API_KEY_FIELD, write: value => this.writeKey(value) }])
    this.store = this.form.bind(() => this.project())
    this.unsubscribe = scope.subscribe(() => { void this.readCredential(); this.catalogChanged() })
    void this.readCredential()
    this.catalogChanged()
  }

  inject(): CpaCardFace {
    return { hooks: { cpaCard: this.store }, ...this.form.actions(), refreshImageModels: () => { void this.refreshModels() } }
  }

  refreshCredential(ref: string): void {
    if (ref === this.credential.ref) { void this.readCredential(); void this.refreshModels() }
  }

  private project(): CpaCardState {
    return {
      ...this.form.shell(),
      enabled: this.form.field('enabled'),
      baseURL: this.form.field('baseURL'),
      apiKeyEnv: this.form.field('apiKeyEnv'),
      protocol: this.form.field('protocol'),
      refreshIntervalSeconds: this.form.field('refreshIntervalSeconds'),
      probeTimeoutMs: this.form.field('probeTimeoutMs'),
      apiKey: this.form.field(API_KEY_FIELD),
      apiKeyConfigured: this.credential.configured,
      apiKeyWritable: this.credential.writable,
      imageGenerationEnabled: this.form.field('imageGenerationEnabled'),
      imageModel: this.form.field('imageModel'),
      imageProtocol: this.form.field('imageProtocol'),
      imageModels: this.imageModels, catalogLoading: this.catalogLoading, catalogFailed: this.catalogFailed,
    }
  }

  private catalogChanged(): void {
    const snapshot = this.scope.getSnapshot()
    if (snapshot.status !== 'ready') return
    const key = JSON.stringify([snapshot.value?.baseURL, snapshot.value?.apiKeyEnv])
    if (this.catalogConfig === key) return
    this.catalogConfig = key
    this.imageModels = []
    void this.refreshModels()
  }

  private async refreshModels(): Promise<void> {
    if (this.disposed || !this.loadCatalog || this.scope.getSnapshot().status !== 'ready') return
    this.catalogAbort?.abort()
    const request = new AbortController()
    this.catalogAbort = request
    this.catalogLoading = true; this.catalogFailed = false
    this.store.set(this.project())
    try {
      const models = await this.loadCatalog(request.signal)
      if (this.disposed || request.signal.aborted) return
      this.imageModels = models
    } catch {
      if (this.disposed || request.signal.aborted) return
      this.imageModels = []; this.catalogFailed = true
    } finally {
      if (!this.disposed && !request.signal.aborted) { this.catalogLoading = false; this.store.set(this.project()) }
    }
  }

  private async readCredential(): Promise<void> {
    if (this.disposed || this.scope.getSnapshot().status !== 'ready') return
    const request = ++this.credentialRead
    const ref = refOf(this.scope.getSnapshot())
    try {
      const response = await this.api.credentials.describe([ref])
      if (this.disposed || request !== this.credentialRead || !response.ok || ref !== refOf(this.scope.getSnapshot())) return
      const view = response.value[ref]
      this.credential = { ref, configured: view?.configured ?? false, writable: view?.writable ?? false }
      this.store.set(this.project())
    } catch {}
  }

  private async writeKey(value: string): Promise<boolean> {
    if (this.disposed) return false
    try {
      const response = await this.api.credentials.set(refOf(this.scope.getSnapshot()), value)
      if (!response.ok) return false
    } catch { return false }
    await this.readCredential()
    // describe is only badge enrichment: a racing refresh must not turn a
    // Host-accepted credential write into a false save failure.
    return true
  }

  /** Hot reload must release both accepted-value subscriptions. */
  dispose(): void {
    this.disposed = true
    this.catalogAbort?.abort()
    this.unsubscribe()
    this.form.dispose()
  }
}
