import type { SnapshotStore } from '@deepseek-ai/dsh-client-store'
import type { SettingsScope, SettingsScopeSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client'
import type { CardActions, CardFieldState, CardShell } from './form.js'
import { booleanField, CardForm, choiceField, numberField, textField, type CardApi } from './form.js'

export const SETTINGS_NS = 'dsh-cliproxyapi'
const DEFAULT_KEY_REF = 'CLIPROXYAPI_API_KEY'
const API_KEY_FIELD = 'apiKey'

interface Section {
  enabled?: boolean
  provider?: string
  baseURL?: string
  apiKeyEnv?: string
  protocol?: string
  refreshIntervalSeconds?: number
  probeTimeoutMs?: number
}

interface CredentialState { ref: string; configured: boolean; writable: boolean }

export interface CpaCardState extends CardShell {
  enabled: CardFieldState
  baseURL: CardFieldState
  apiKeyEnv: CardFieldState
  protocol: CardFieldState
  refreshIntervalSeconds: CardFieldState
  probeTimeoutMs: CardFieldState
  apiKey: CardFieldState
  apiKeyConfigured: boolean
  apiKeyWritable: boolean
}

export interface CpaCardFace extends CardActions {
  hooks: { cpaCard: SnapshotStore<CpaCardState> }
}

function refOf(snapshot: SettingsScopeSnapshot<Section>): string {
  const ref = snapshot.value?.apiKeyEnv
  return typeof ref === 'string' && ref.length > 0 ? ref : DEFAULT_KEY_REF
}

export class CpaCardController {
  private readonly form: CardForm<Section>
  private readonly store: SnapshotStore<CpaCardState>
  private credential: CredentialState = { ref: '', configured: false, writable: true }

  constructor(private readonly scope: SettingsScope<Section>, private readonly api: CardApi) {
    this.form = new CardForm(scope, api, SETTINGS_NS, [
      booleanField('enabled'),
      textField('baseURL'),
      textField('apiKeyEnv'),
      choiceField('protocol', ['openai-completions', 'openai-responses']),
      numberField('refreshIntervalSeconds'),
      numberField('probeTimeoutMs'),
    ], [{ field: API_KEY_FIELD, write: value => this.writeKey(value) }])
    this.store = this.form.bind(() => this.project())
    scope.subscribe(() => { void this.readCredential() })
    void this.readCredential()
  }

  inject(): CpaCardFace {
    return { hooks: { cpaCard: this.store }, ...this.form.actions() }
  }

  refreshCredential(ref: string): void {
    if (ref === this.credential.ref) void this.readCredential()
  }

  private project(): CpaCardState {
    return {
      ...this.form.shell(),
      enabled: this.form.field('enabled'),
      baseURL: this.form.field('baseURL'),
      apiKeyEnv: this.form.field('apiKeyEnv'),
      protocol: this.form.field('protocol'),
      refreshIntervalSeconds: this.form.field('refreshIntervalSeconds'),
      probeTimeoutMs: this.form.field('probeTimeoutMs'),
      apiKey: this.form.field(API_KEY_FIELD),
      apiKeyConfigured: this.credential.configured,
      apiKeyWritable: this.credential.writable,
    }
  }

  private async readCredential(): Promise<void> {
    const ref = refOf(this.scope.getSnapshot())
    try {
      const response = await this.api.credentials.describe([ref])
      if (!response.ok || ref !== refOf(this.scope.getSnapshot())) return
      const view = response.value[ref]
      this.credential = { ref, configured: view?.configured ?? false, writable: view?.writable ?? true }
      this.store.set(this.project())
    } catch {}
  }

  private async writeKey(value: string): Promise<boolean> {
    try {
      const response = await this.api.credentials.set(refOf(this.scope.getSnapshot()), value)
      if (!response.ok) return false
    } catch { return false }
    await this.readCredential()
    return this.credential.configured
  }

}
