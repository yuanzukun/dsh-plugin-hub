import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-connection/client'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import type {} from '@deepseek-ai/dsh-api-remotes/types'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-ui-plugin-manager/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import { CpaCard } from './card.js'
import { CpaCardController, SETTINGS_NS } from './controller.js'
import { en, LOCALE_NS, zh } from './locales.js'

export const inject = ['slots', 'locale', 'remote', 'remote.credentials', 'configForms', 'connection']

const CSS = `
.dcpa-card{padding:12px 16px 16px;border:1px solid var(--dsh-border,rgba(128,128,128,.35));border-radius:8px}.dcpa-card h3{margin:0 0 4px;font-size:15px}.dcpa-description{margin:0 0 10px;font-size:12px;opacity:.75}.dcpa-field{margin:10px 0}.dcpa-field-head{display:flex;gap:8px;align-items:center;margin-bottom:4px;font-size:12px;font-weight:500}.dcpa-badge{font-size:10px;padding:1px 6px;border-radius:999px;background:rgba(64,128,255,.18)}.dcpa-reset{margin-left:auto;border:0;background:transparent;color:inherit;cursor:pointer;opacity:.7}.dcpa-input{width:100%;box-sizing:border-box;padding:6px 8px;font:inherit;font-size:13px;border-radius:6px;border:1px solid var(--dsh-border,rgba(128,128,128,.35));background:transparent;color:inherit}.dcpa-hint{margin-top:3px;font-size:11px;opacity:.65}.dcpa-actions{display:flex;gap:8px;align-items:center;margin-top:14px}.dcpa-button{padding:5px 12px;font:inherit;font-size:12px;border-radius:6px;border:1px solid var(--dsh-border,rgba(128,128,128,.35));background:transparent;color:inherit;cursor:pointer}.dcpa-button:disabled{opacity:.4;cursor:default}.dcpa-primary{background:var(--dsh-accent,rgba(64,128,255,.85));border-color:transparent;color:#fff}.dcpa-failed{font-size:11px;color:#e5484d}
`

export function apply(ctx: ClientContext): void {
  const api = ctx.remote
  ctx.effect(() => ctx.locale.register(LOCALE_NS, { zh, en }), 'dsh-cliproxyapi locales')
  if (typeof document !== 'undefined') {
    const style = document.createElement('style'); style.dataset.plugin = 'dsh-cliproxyapi'; style.textContent = CSS; document.head.appendChild(style)
    ctx.effect(() => () => { style.remove() }, 'dsh-cliproxyapi styles')
  }
  const controller = new CpaCardController(ctx.configForms.get(SETTINGS_NS), api, async signal => {
    // Host and Client Context augmentations share the same key in this build;
    // this entry runs only on the Client carrier.
    const connection = ctx.connection as unknown as ConnectionHandle
    const response = await connection.rpc.call('/api', 'cpaImages/catalog', null, signal)
    if (!response.ok || !Array.isArray(response.value)) throw new Error('CPA catalog unavailable')
    return response.value.filter((item): item is { value: string; label: string } => item !== null
      && typeof item === 'object' && typeof item.value === 'string' && typeof item.label === 'string')
  })
  ctx.effect(() => () => controller.dispose(), 'dsh-cliproxyapi form subscriptions')
  ctx.effect(() => ctx.remote.$on('credentials/reference-updated', (ref: string) => { controller.refreshCredential(ref) }), 'dsh-cliproxyapi credential updates')
  // Third-party bundles configure their own detail page, not the official
  // plugins.item list. Register only while the host exposes our entry form.
  ctx.effect(() => ctx.configForms.whileServed([SETTINGS_NS], () =>
    ctx.slots.inject('plugins.bundle.config', () => ctx.slots.register({
      name: 'plugins.bundle.config', key: 'dsh-cliproxyapi-provider',
      locale: LOCALE_NS, inject: () => controller.inject(),
    }, CpaCard))), 'dsh-cliproxyapi configuration page')
}
