import { createSnapshotStore, type SnapshotStore } from '@deepseek-ai/dsh-client-store'
import type { ClientRemote } from '@deepseek-ai/dsh-api-remotes/client'
import type { ConfigForm, ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client'
import type { SettingsPathOpView } from '@deepseek-ai/dsh-api-remotes/client'

// These are our view-model contracts, not imports from another plugin's UI.
export interface CardActions {
  edit(field: string, text: string): void
  resetField(field: string): void
  save(): void
  discard(): void
}
export interface CardFieldState { text: string; overridden: boolean; invalid: boolean }
export interface CardShell {
  available: boolean; writable: boolean; dirty: boolean
  invalid: boolean; saving: boolean; failed: boolean
}
interface CardSecretSpec { field: string; write(value: string): Promise<boolean> }
export type CardApi = Pick<ClientRemote, 'credentials'>

type FieldWrite = { kind: 'set'; value: string | number | boolean } | { kind: 'clear' }

export interface CardFieldSpec {
  field: string
  path: readonly string[]
  format: (value: unknown) => string
  parse: (text: string) => FieldWrite | undefined
}

interface StagedEdit { text: string; clear: boolean }
interface PlannedWrite { field: string; run?: () => Promise<boolean>; op?: SettingsPathOpView }

function atPath(value: unknown, path: readonly string[]): unknown {
  let node = value
  for (const segment of path) {
    if (typeof node !== 'object' || node === null) return undefined
    node = (node as Record<string, unknown>)[segment]
  }
  return node
}

export function textField(field: string): CardFieldSpec {
  return {
    field,
    path: [field],
    format: value => typeof value === 'string' ? value : '',
    parse: text => text.trim() === '' ? { kind: 'clear' } : { kind: 'set', value: text.trim() },
  }
}

export function numberField(field: string, min = -Infinity, max = Infinity): CardFieldSpec {
  return {
    field,
    path: [field],
    format: value => typeof value === 'number' ? String(value) : '',
    parse: (text) => {
      if (text.trim() === '') return { kind: 'clear' }
      const value = Number(text)
      return Number.isInteger(value) && value >= min && value <= max ? { kind: 'set', value } : undefined
    },
  }
}

export function choiceField(field: string, choices: readonly string[]): CardFieldSpec {
  return {
    field,
    path: [field],
    format: value => typeof value === 'string' ? value : '',
    parse: text => text === '' ? { kind: 'clear' } : choices.includes(text) ? { kind: 'set', value: text } : undefined,
  }
}

export function booleanField(field: string): CardFieldSpec {
  return {
    field,
    path: [field],
    format: value => value === true ? 'true' : value === false ? 'false' : '',
    parse: text => text === '' ? { kind: 'clear' } : text === 'true' ? { kind: 'set', value: true } : text === 'false' ? { kind: 'set', value: false } : undefined,
  }
}

export class CardForm<T> {
  private readonly specs = new Map<string, CardFieldSpec>()
  private readonly secrets = new Map<string, CardSecretSpec>()
  private readonly staged = new Map<string, StagedEdit>()
  private readonly listeners = new Set<() => void>()
  private saving = false
  private failed = false
  private disposed = false
  private baseline: ConfigFormSnapshot<T> | undefined
  private readonly unsubscribe: () => void

  constructor(
    private readonly scope: ConfigForm<T>,
    specs: CardFieldSpec[],
    secrets: CardSecretSpec[] = [],
  ) {
    for (const spec of specs) this.specs.set(spec.field, spec)
    for (const secret of secrets) this.secrets.set(secret.field, secret)
    this.unsubscribe = scope.subscribe(() => { this.publish() })
  }

  bind<S>(project: () => S): SnapshotStore<S> {
    const store = createSnapshotStore(project())
    this.listeners.add(() => { store.set(project()) })
    return store
  }

  shell(): CardShell {
    const plan = this.plan()
    const snapshot = this.scope.getSnapshot()
    return {
      available: snapshot.status === 'ready',
      writable: snapshot.writable,
      dirty: plan.length > 0,
      invalid: plan.some(item => item.run === undefined && item.op === undefined),
      saving: this.saving,
      failed: this.failed,
    }
  }

  field(field: string): CardFieldState {
    const staged = this.staged.get(field)
    if (this.secrets.has(field)) return { text: staged?.text ?? '', overridden: false, invalid: false }
    const spec = this.spec(field)
    if (staged === undefined) {
      return { text: spec.format(this.value(field)), overridden: this.stored(field), invalid: false }
    }
    const parsed = staged.clear ? { kind: 'clear' as const } : spec.parse(staged.text)
    return { text: staged.text, overridden: parsed?.kind === 'set', invalid: parsed === undefined }
  }

  actions(): CardActions {
    return {
      edit: (field, text) => {
        if (this.saving || this.disposed) return
        this.baseline ??= this.snapshot()
        this.staged.set(field, { text, clear: false }); this.failed = false; this.publish()
      },
      resetField: (field) => {
        if (this.saving || this.disposed) return
        this.baseline ??= this.snapshot()
        const spec = this.spec(field)
        this.staged.set(field, { text: spec.format(atPath(this.snapshot().base, spec.path)), clear: true })
        this.failed = false
        this.publish()
      },
      save: () => { void this.save() },
      discard: () => {
        if (this.saving || this.disposed) return
        this.staged.clear(); this.baseline = undefined; this.failed = false; this.publish()
      },
    }
  }

  /** Commit ordinary fields atomically before writing a key to the accepted reference.
   * A conflict retains drafts; discard/re-edit explicitly rebases them. Secrets
   * cannot share the settings transaction and are never sent after a refusal.
   */
  async save(): Promise<void> {
    const plan = this.plan()
    if (plan.length === 0 || this.saving || this.disposed || !this.snapshot().writable
      || this.snapshot().status !== 'ready' || plan.some(item => item.run === undefined && item.op === undefined)) return
    this.saving = true
    this.failed = false
    this.publish()
    try {
      const ops = plan.flatMap(item => item.op === undefined ? [] : [item.op])
      if (ops.length && !await this.scope.mutate(ops, this.baseline?.revision)) {
        this.failed = true
        return
      }
      // Accepted settings must not be replayed if a later credential write fails.
      for (const item of plan) if (item.op !== undefined) this.staged.delete(item.field)
      this.baseline = this.snapshot()
      for (const item of plan) {
        if (this.disposed) return
        if (item.run !== undefined) {
          if (!await item.run()) { this.failed = true; return }
          this.staged.delete(item.field)
        }
      }
      this.staged.clear()
      this.baseline = undefined
    } catch {
      this.failed = true
    } finally {
      this.saving = false
      this.publish()
    }
  }

  dispose(): void {
    this.disposed = true
    this.unsubscribe()
    this.staged.clear()
    this.listeners.clear()
  }

  private plan(): PlannedWrite[] {
    const plan: PlannedWrite[] = []
    for (const [field, staged] of this.staged) {
      const secret = this.secrets.get(field)
      if (secret !== undefined) {
        if (staged.text.trim() !== '') plan.push({ field, run: () => secret.write(staged.text.trim()) })
        continue
      }
      const spec = this.spec(field)
      if (staged.clear) {
        if (this.stored(field)) plan.push({ field, op: { op: 'unset', path: [...spec.path] } })
        continue
      }
      if (staged.text === spec.format(this.value(field))) continue
      const parsed = spec.parse(staged.text)
      if (parsed === undefined) plan.push({ field })
      else if (parsed.kind === 'clear') plan.push({ field, op: { op: 'unset', path: [...spec.path] } })
      else plan.push({ field, op: { op: 'set', path: [...spec.path], value: parsed.value } })
    }
    return plan
  }

  private spec(field: string): CardFieldSpec {
    const value = this.specs.get(field)
    if (value === undefined) throw new Error(`unknown field ${field}`)
    return value
  }

  private snapshot(): ConfigFormSnapshot<T> { return this.scope.getSnapshot() }
  private value(field: string): unknown { return atPath(this.snapshot().value, this.spec(field).path) }
  private stored(field: string): boolean { return atPath(this.snapshot().user, this.spec(field).path) !== undefined }
  private publish(): void { for (const listener of this.listeners) listener() }
}
