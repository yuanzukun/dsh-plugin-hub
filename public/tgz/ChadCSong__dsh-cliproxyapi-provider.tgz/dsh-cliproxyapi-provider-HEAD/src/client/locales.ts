import type {} from '@deepseek-ai/dsh-client-ui-slots'

export const LOCALE_NS = 'dsh-cliproxyapi'

export type LocaleKey =
  | 'title' | 'description' | 'enabled' | 'enabledHint' | 'apiKey' | 'apiKeyHint' | 'apiKeySet' | 'apiKeyUnset'
  | 'apiKeyEnv' | 'apiKeyEnvHint' | 'baseURL' | 'baseURLHint'
  | 'protocol' | 'protocolHint' | 'refreshIntervalSeconds' | 'refreshIntervalSecondsHint'
  | 'probeTimeoutMs' | 'probeTimeoutMsHint' | 'overridden' | 'reset' | 'invalid' | 'save' | 'discard' | 'saving' | 'saveFailed'
  | 'yes' | 'no'
  | 'imageTitle' | 'imageEnabled' | 'imageEnabledHint' | 'imageModel' | 'imageModelHint'
  | 'imageProtocol' | 'imageProtocolHint' | 'auto'
  | 'modelMissing' | 'refreshModels' | 'catalogLoading' | 'catalogFailed'
  | 'imageSetupNeeded'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap { 'dsh-cliproxyapi': LocaleKey }
}

export const zh: Record<LocaleKey, string> = {
  imageSetupNeeded: '技能和工具尚未启用：请选择模型；自定义别名需明确选择生图协议，然后保存。',
  imageTitle: '可选：图片生成', imageEnabled: '启用生图技能与工具',
  imageEnabledHint: '默认关闭。开启并选定模型后提供 /cpa-image 和生图工具；调用可能消耗额度。仅支持文生图，不支持参考图或编辑。',
  imageModel: '生图模型', imageModelHint: '仅显示 ID 或名称包含 image 的模型。先保存地址和 Key，再刷新。可用性以 CPA 实际返回为准。',
  imageProtocol: '生图协议', imageProtocolHint: '自动识别常见 GPT/Grok/Gemini 生图名称。自定义别名请直接选择对应协议，无需输入 ID。',
  auto: '自动识别',
  modelMissing: '不在当前目录', refreshModels: '刷新模型列表', catalogLoading: '读取模型中…', catalogFailed: '模型读取失败，请确认已保存 CPA 地址和 Key 后重试。',
  title: 'CLIProxyAPI（自动探测）',
  description: '自动发现本机 CPA，并把模型及其原生能力同步到 DSH 模型选择器。',
  enabled: '启用', enabledHint: '关闭后移除本插件管理的 CPA provider。',
  apiKey: 'CPA API Key', apiKeyHint: '写入 DSH 凭据存储，不会写入 settings.yaml。', apiKeySet: '已配置', apiKeyUnset: '未配置',
  apiKeyEnv: '密钥引用名', apiKeyEnvHint: '默认 CLIPROXYAPI_API_KEY。',
  baseURL: 'CPA 地址（可选）', baseURLHint: '留空自动扫描 127.0.0.1 / localhost / ::1 的 8317 端口。',
  protocol: '推理协议', protocolHint: '默认 Chat Completions；CPA 部署要求 Responses 时可切换。',
  refreshIntervalSeconds: '自动刷新间隔（秒）', refreshIntervalSecondsHint: '默认 300，最小 15。',
  probeTimeoutMs: '单地址探测超时（毫秒）', probeTimeoutMsHint: '默认 2000。',
  overridden: '已覆盖', reset: '重置', invalid: '无效值', save: '保存', discard: '放弃修改', saving: '保存中…', saveFailed: '保存未全部生效',
  yes: '是', no: '否',
}

export const en: Record<LocaleKey, string> = {
  imageSetupNeeded: 'Skill/tool not enabled yet: select a model; choose an explicit protocol for aliases, then save.',
  imageTitle: 'Optional: image generation', imageEnabled: 'Enable image skill and tool',
  imageEnabledHint: 'Off by default. Enable and select a model to expose /cpa-image and the tool. Calls may consume quota. Text-to-image only; no references or edits.',
  imageModel: 'Image model', imageModelHint: 'Only models with image in their ID or name are shown. Save URL and key, then refresh. Availability depends on the actual CPA response.',
  imageProtocol: 'Image protocol', imageProtocolHint: 'Auto recognizes common GPT/Grok/Gemini image names. Choose a protocol for custom aliases; no manual model IDs.',
  auto: 'Auto detect',
  modelMissing: 'Not in current catalog', refreshModels: 'Refresh models', catalogLoading: 'Loading models…', catalogFailed: 'Could not load models. Save CPA URL/key and retry.',
  title: 'CLIProxyAPI (auto discovery)',
  description: 'Discovers local CPA and synchronizes models with their native capabilities into DSH.',
  enabled: 'Enabled', enabledHint: 'Disabling removes the CPA provider managed by this plugin.',
  apiKey: 'CPA API key', apiKeyHint: 'Stored in DSH credentials, never in settings.yaml.', apiKeySet: 'configured', apiKeyUnset: 'not configured',
  apiKeyEnv: 'Credential reference', apiKeyEnvHint: 'Defaults to CLIPROXYAPI_API_KEY.',
  baseURL: 'CPA URL (optional)', baseURLHint: 'Leave empty to scan port 8317 on 127.0.0.1, localhost, and ::1.',
  protocol: 'Inference protocol', protocolHint: 'Chat Completions by default; switch when the CPA deployment requires Responses.',
  refreshIntervalSeconds: 'Refresh interval (seconds)', refreshIntervalSecondsHint: 'Default 300; minimum 15.',
  probeTimeoutMs: 'Probe timeout per URL (ms)', probeTimeoutMsHint: 'Default 2000.',
  overridden: 'overridden', reset: 'reset', invalid: 'invalid value', save: 'Save', discard: 'Discard', saving: 'Saving…', saveFailed: 'Save did not fully land',
  yes: 'Yes', no: 'No',
}
