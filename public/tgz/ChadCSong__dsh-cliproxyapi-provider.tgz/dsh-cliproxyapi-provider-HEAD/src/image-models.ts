/** Transport hints, not a claim of account availability. Image INPUT metadata
 * is never interpreted as image OUTPUT support. Image-named aliases use an
 * explicitly selected protocol instead of a hidden guess.
 */
export function imageTransport(id: string): 'gemini' | 'openai' | undefined {
  if (/^gemini-[a-z0-9.-]*image(?:-[a-z0-9.-]+)?$/i.test(id)) return 'gemini'
  if (/^(?:gpt-image-[a-z0-9.-]+|grok-imagine-image(?:-[a-z0-9.-]+)?)$/i.test(id)) return 'openai'
  return undefined
}

export function imageChoices(models: readonly { id: string; name?: string }[]): Array<{ value: string; label: string }> {
  // Keep this filter local to the image picker; chat discovery stays unchanged.
  return models.filter(model => /image/i.test(model.id) || /image/i.test(model.name ?? ''))
    .sort((a, b) => Number(imageTransport(b.id) !== undefined) - Number(imageTransport(a.id) !== undefined)
    || b.id.localeCompare(a.id, undefined, { numeric: true }))
    .map(model => ({ value: model.id, label: model.name ?? model.id }))
}
