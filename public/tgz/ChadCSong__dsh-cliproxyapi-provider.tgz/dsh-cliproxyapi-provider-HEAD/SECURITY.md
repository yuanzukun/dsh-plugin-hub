# Security Policy

Please report vulnerabilities through GitHub's private vulnerability reporting for this repository. Do not open
a public issue for an unpatched vulnerability. If private reporting is unavailable, open a non-sensitive issue
asking the maintainer to establish a private contact channel without including vulnerability details.

The plugin treats the CPA API key as a DSH credential reference. A valid report includes any path that logs,
persists, renders, or transmits that secret somewhere other than the configured CPA endpoint.

Image generation is opt-in and may consume upstream quota. The catalog RPC is owner-only, accepts no
parameters, and returns only model IDs and labels. Generation rechecks model membership, never follows
HTTP redirects or provider-returned URLs, limits response sizes, and stores raster output through DSH's
validated attachment service. Provider errors are reduced to HTTP status without echoing their bodies.
There are no automatic generation retries. Cancellation cannot guarantee an upstream refund.
