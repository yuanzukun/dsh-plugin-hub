import { describe, expect, it, vi } from 'vitest'
import { resolveConfig } from '../src/config.js'
import { CpaRuntime, mergeRoute } from '../src/runtime.js'
import type { PiAiRouteProfile } from '../src/profile.js'

function fixture() {
  let config = resolveConfig({ baseURL: 'http://127.0.0.1:8317' })
  let value: unknown = {}
  const mutate = vi.fn(async () => {})
  const fetcher = vi.fn<typeof fetch>(async () => Response.json({ data: [{ id: 'model' }] }))
  const warn = vi.fn()
  const runtime = new CpaRuntime({
    settings: { mutate, describe: () => [{ ns: 'llm-pi-ai', revision: 3, value }] } as never,
    config: () => config, resolveApiKey: async () => 'test-key', environmentBaseURL: () => undefined,
    fetch: fetcher, logger: { info: vi.fn(), warn, error: vi.fn() },
  })
  return { runtime, mutate, fetcher, warn, setConfig: (patch: Partial<typeof config>) => { config = { ...config, ...patch } }, setValue: (next: unknown) => { value = next } }
}

describe('runtime cancellation and native route ownership', () => {
  it('deduplicates unchanged catalogs and fences native writes by revision', async () => {
    const { runtime, mutate } = fixture()
    await runtime.refresh()
    await runtime.refresh()
    expect(mutate).toHaveBeenCalledTimes(1)
    expect(mutate.mock.calls[0]?.[2]).toBe(3)
    await runtime.dispose()
  })

  it('does not publish late responses or restart after disposal', async () => {
    const { runtime, fetcher, mutate, warn } = fixture()
    let finish!: (response: Response) => void
    fetcher.mockImplementation(() => new Promise(resolve => { finish = resolve }))
    const refresh = runtime.refresh()
    await vi.waitFor(() => expect(fetcher).toHaveBeenCalledTimes(1))
    const disposed = runtime.dispose()
    finish(Response.json({ data: [{ id: 'late' }] }))
    await Promise.all([refresh, disposed])
    await runtime.refresh()
    expect(mutate).not.toHaveBeenCalled()
    expect(warn).not.toHaveBeenCalled()
    expect(fetcher).toHaveBeenCalledTimes(1)
  })

  it('drops a stale probe after configuration changes and runs the queued refresh', async () => {
    const { runtime, fetcher, mutate, setConfig } = fixture()
    let finish!: (response: Response) => void
    fetcher.mockImplementationOnce(() => new Promise(resolve => { finish = resolve }))
    const refresh = runtime.refresh()
    await vi.waitFor(() => expect(fetcher).toHaveBeenCalledTimes(1))
    setConfig({ displayName: 'New name' })
    void runtime.refresh()
    finish(Response.json({ data: [{ id: 'stale' }] }))
    await refresh
    expect(mutate).toHaveBeenCalledTimes(1)
    expect(mutate.mock.calls[0]?.[1][0].value).toMatchObject({ displayName: 'New name', models: [{ id: 'model' }] })
  })

  it('removes a persisted route when starting disabled', async () => {
    const { runtime, setConfig, setValue, mutate, fetcher } = fixture()
    setConfig({ enabled: false })
    setValue({ providers: { cliproxyapi: { models: [] } } })
    await runtime.refresh()
    expect(mutate).toHaveBeenCalledWith('llm-pi-ai', [{ op: 'unset', path: ['providers', 'cliproxyapi'] }], 3)
    expect(fetcher).not.toHaveBeenCalled()
  })

  it('does not destroy the route when a revision conflict occurs', async () => {
    const { runtime, mutate } = fixture()
    mutate.mockRejectedValueOnce(new Error('revision conflict'))
    await runtime.refresh()
    expect(runtime.status().state).toBe('error')
    await runtime.refresh()
    expect(runtime.status().state).toBe('connected')
    expect(mutate).toHaveBeenCalledTimes(2)
  })

  it('does not deadlock unloading behind a queued native settings transaction', async () => {
    const { runtime, mutate } = fixture()
    let finish!: () => void
    mutate.mockImplementationOnce(() => new Promise<void>(resolve => { finish = resolve }))
    const refresh = runtime.refresh()
    await vi.waitFor(() => expect(mutate).toHaveBeenCalledTimes(1))
    expect(runtime.dispose()).toBeUndefined()
    finish()
    await refresh
    expect(runtime.status().state).not.toBe('connected')
  })
})

const route = (models: PiAiRouteProfile['models']): PiAiRouteProfile => ({
  displayName: 'CPA', api: 'openai-completions', baseURL: 'http://localhost:8317/v1',
  apiKeyEnv: 'KEY', models,
})

describe('preserving native model tuning', () => {
  it('retains edits, updates untouched metadata, and follows new catalog IDs/order', () => {
    const previous = route([{ id: 'a', input: ['text'], maxTokens: 100, contextWindow: 1000 }])
    const current = { ...previous, timeoutMs: 12000, models: [{ ...previous.models[0], maxTokens: 200 }], headers: { 'X-Custom': 'yes', Authorization: 'Bearer cpa-local' } }
    const next = route([{ id: 'b', input: ['text', 'image'] }, { id: 'a', input: ['text'], maxTokens: 300, contextWindow: 2000 }])
    const merged = mergeRoute(current, next, previous)
    expect(merged).toMatchObject({ timeoutMs: 12000, headers: { 'X-Custom': 'yes' }, models: [
      { id: 'b' }, { id: 'a', maxTokens: 200, contextWindow: 2000 },
    ] })
    expect(merged.headers).not.toHaveProperty('Authorization')
  })

  it('preserves tuning after restart but removes legacy synthetic image capability', () => {
    const existing = route([{ id: 'a', input: ['text', 'image'], reasoningEfforts: { high: 'high' } }])
    const next = route([{ id: 'a', input: ['text'] }])
    expect(mergeRoute(existing, next)).toMatchObject({ models: [{
      id: 'a', input: ['text'], reasoningEfforts: { high: 'high' },
    }] })
  })
})
