import { describe, expect, it, vi } from 'vitest'
vi.mock('@deepseek-ai/dsh-tools', () => ({ defineTool: (definition: unknown) => definition }))
vi.mock('../src/discovery.js', () => ({ discoverCpa: vi.fn() }))
vi.mock('../src/image-request.js', () => ({ requestImage: vi.fn() }))
import { registerImageFeature, IMAGE_SKILL } from '../src/image-feature.js'
import { registerImageCatalog } from '../src/image-catalog.js'
import { discoverCpa } from '../src/discovery.js'
import { requestImage } from '../src/image-request.js'
import { resolveConfig } from '../src/config.js'
import { Context } from '@deepseek-ai/cordis'

function fixture(enabled = true) {
  let config = resolveConfig({ imageGenerationEnabled: enabled, imageModel: 'gpt-image-2' })
  const events = new Map<string, () => void>()
  const dispose: Array<() => void> = []
  const removeTool = vi.fn(), removeSkill = vi.fn()
  const tools = { register: vi.fn(() => removeTool) }
  const skills = { register: vi.fn(() => removeSkill) }
  const attachments = { saveImages: vi.fn(async () => [{ attachmentId: 'test-image', mediaType: 'image/png', bytes: 1, width: 1, height: 1 }]), imageHostPath: () => '/saved/image.png' }
  const inner = { tools, skills, attachments, get: () => undefined,
    on: (name: string, fn: () => void) => events.set(name, fn), effect: (fn: () => () => void) => dispose.push(fn()) }
  const ctx = { inject: (_services: unknown, callback: (ctx: unknown) => void) => callback(inner),
    on: (name: string, fn: () => void) => { events.set(name, fn); return () => { events.delete(name) } } }
  const resolveApiKey = vi.fn(async () => 'secret-test-key')
  registerImageFeature(ctx as never, { config: () => config, resolveApiKey, environmentBaseURL: () => undefined })
  const tool = () => tools.register.mock.calls.at(-1)?.[0] as unknown as {
    execute: (args: { prompt: string }, exec: { signal: AbortSignal }) => Promise<unknown>
    output: { render: (args: unknown, value: unknown) => unknown[] }
  }
  return { tools, skills, tool, attachments, resolveApiKey, removeTool, removeSkill,
    change: (patch: Parameters<typeof resolveConfig>[0]) => { config = { ...config, ...patch }; events.get('loader/volatile-update')?.() },
    dispose: () => dispose.forEach(fn => fn()) }
}

describe('optional image capability lifecycle', () => {
  it('refreshes tools on real Loader owner-filtered events, including disable and teardown', async () => {
    const root = new Context()
    let owner!: Context
    let saved = resolveConfig({ imageGenerationEnabled: true, imageModel: 'gpt-image-2' })
    const activeTools = new Map<string, any>()
    const activeSkills = new Map<string, unknown>()
    let registrations = 0
    root.provide('tools', { register: (tool: any) => {
      registrations++
      activeTools.set(tool.name, tool)
      return () => { if (activeTools.get(tool.name) === tool) activeTools.delete(tool.name) }
    } } as never)
    root.provide('skills', { register: (skill: any) => {
      activeSkills.set(skill.name, skill)
      return () => { if (activeSkills.get(skill.name) === skill) activeSkills.delete(skill.name) }
    } } as never)
    const attachments = { saveImages: async () => [{ attachmentId: 'test' }], imageHostPath: () => '/saved/test.png' }
    const removeAttachments = root.provide('attachments', attachments as never)
    const fiber = root.plugin(ctx => {
      owner = ctx
      let resolved = saved
      ctx.on('loader/volatile-update', () => { resolved = saved })
      registerImageFeature(ctx, { config: () => resolved, resolveApiKey: async () => 'test', environmentBaseURL: () => undefined })
    })
    const emitChange = (patch: Partial<typeof saved>) => {
      saved = { ...saved, ...patch }
      // Mirror Loader.tryUpdateVolatile: descendants have distinct fibers and
      // do not receive this event merely because their parent owns the entry.
      const sender = Object.create(owner)
      sender[Context.filter] = (listener: Context) => listener.fiber === owner.fiber
      owner.emit(sender, 'loader/volatile-update', [['imageModel']])
    }
    try {
      await fiber
      await vi.waitFor(() => expect(activeTools.has('cpa_generate_image')).toBe(true))
      const original = activeTools.get('cpa_generate_image')
      emitChange({ imageModel: 'gemini-3.1-flash-image' })
      const current = activeTools.get('cpa_generate_image')
      expect(current).not.toBe(original)
      vi.mocked(discoverCpa).mockResolvedValue({ rootURL: 'http://localhost:8317', models: [{ id: saved.imageModel }] } as never)
      vi.mocked(requestImage).mockResolvedValue({ bytes: new Uint8Array([1]), mediaType: 'image/png' })
      await expect(current.execute({ prompt: 'bird' }, { signal: new AbortController().signal })).resolves.toMatchObject({ path: '/saved/test.png' })
      expect(requestImage).toHaveBeenLastCalledWith(expect.objectContaining({ model: 'gemini-3.1-flash-image', protocol: 'auto' }))
      await expect(original.execute({ prompt: 'bird' }, { signal: new AbortController().signal })).rejects.toThrow('configuration changed')
      emitChange({ imageProtocol: 'gemini' })
      expect(activeTools.get('cpa_generate_image')).not.toBe(current)
      emitChange({ imageGenerationEnabled: false })
      expect(activeTools.size).toBe(0)
      expect(activeSkills.size).toBe(0)
      emitChange({ imageGenerationEnabled: true })
      expect(activeTools.size).toBe(1)
      expect(activeSkills.size).toBe(1)
      // A service withdrawal disposes the injected context, not the owner.
      // Its owner-bound listener must disappear until the service is restored.
      await removeAttachments()
      await vi.waitFor(() => expect(activeTools.size).toBe(0))
      const beforeReload = registrations
      emitChange({ imageProtocol: 'auto' })
      expect(registrations).toBe(beforeReload)
      root.provide('attachments', attachments as never)
      await vi.waitFor(() => expect(activeTools.size).toBe(1))
      expect(registrations).toBe(beforeReload + 1)
      emitChange({ imageProtocol: 'gemini' })
      expect(registrations).toBe(beforeReload + 2)
    } finally { await fiber.dispose() }
    expect(activeTools.size).toBe(0)
    expect(activeSkills.size).toBe(0)
  })
  it('exposes neither tool nor skill until opted in, and cleans up on disable', () => {
    const f = fixture(false)
    expect(f.tools.register).not.toHaveBeenCalled()
    f.change({ imageGenerationEnabled: true })
    expect(f.tools.register).toHaveBeenCalledTimes(1)
    expect(f.skills.register).toHaveBeenCalledWith(expect.objectContaining({ name: 'cpa-image', source: 'bundled', content: IMAGE_SKILL }))
    f.change({ imageGenerationEnabled: false })
    expect(f.removeTool).toHaveBeenCalledOnce(); expect(f.removeSkill).toHaveBeenCalledOnce()
    f.dispose()
  })
  it('requires explicit alias protocol and a selected model', () => {
    const f = fixture(false)
    f.change({ imageGenerationEnabled: true, imageModel: 'alias' })
    expect(f.tools.register).not.toHaveBeenCalled()
    f.change({ imageProtocol: 'openai' })
    expect(f.tools.register).toHaveBeenCalledOnce()
    f.change({ imageModel: '' })
    expect(f.removeTool).toHaveBeenCalledOnce()
    f.dispose()
  })
  it('reuses credentials, verifies the full catalog, saves durable output, avoids images on text-only routes', async () => {
    vi.mocked(discoverCpa).mockResolvedValue({ rootURL: 'http://localhost:8317', modelsURL: '', models: [{ id: 'gpt-image-2' }] } as never)
    vi.mocked(requestImage).mockResolvedValue({ bytes: new Uint8Array([1]), mediaType: 'image/png' })
    const f = fixture()
    const result = await f.tool().execute({ prompt: 'bird' }, { signal: new AbortController().signal })
    expect(f.resolveApiKey).toHaveBeenCalledWith('CLIPROXYAPI_API_KEY')
    expect(discoverCpa).toHaveBeenLastCalledWith(expect.objectContaining({ catalogMode: 'standard', apiKey: 'secret-test-key' }))
    expect(requestImage).toHaveBeenLastCalledWith(expect.objectContaining({ rootURL: 'http://localhost:8317', apiKey: 'secret-test-key' }))
    expect(result).toMatchObject({ path: '/saved/image.png', includeImage: false })
    expect(JSON.stringify(result)).not.toContain('secret')
    expect(f.tool().output.render({}, result)).toHaveLength(1)
    f.dispose()
  })
  it('refuses removed catalog models without a billed request', async () => {
    vi.mocked(discoverCpa).mockResolvedValue({ rootURL: 'http://localhost:8317', modelsURL: '', models: [] })
    vi.mocked(requestImage).mockClear()
    const f = fixture()
    await expect(f.tool().execute({ prompt: 'bird' }, { signal: new AbortController().signal })).rejects.toThrow('no longer')
    expect(requestImage).not.toHaveBeenCalled()
    f.dispose()
  })
  it('cancels in-flight generation when disabled and refuses duplicate calls', async () => {
    vi.mocked(discoverCpa).mockResolvedValue({ rootURL: 'http://localhost:8317', modelsURL: '', models: [{ id: 'gpt-image-2' }] } as never)
    vi.mocked(requestImage).mockImplementation(async options => new Promise((_resolve, reject) => {
      options.signal.addEventListener('abort', () => reject(new Error('cancelled')), { once: true })
    }))
    const f = fixture(), tool = f.tool()
    const pending = tool.execute({ prompt: 'bird' }, { signal: new AbortController().signal })
    await vi.waitFor(() => expect(requestImage).toHaveBeenCalled())
    await expect(tool.execute({ prompt: 'bird' }, { signal: new AbortController().signal })).rejects.toThrow('already')
    const rejection = expect(pending).rejects.toThrow('cancelled')
    f.change({ imageGenerationEnabled: false })
    await rejection
    expect(f.attachments.saveImages).not.toHaveBeenCalled()
    f.dispose()
  })
})

describe('catalog RPC access', () => {
  it('uses an owner-admitted exact route without replacing the Gateway interceptor', async () => {
    let handler: (request: Request) => Promise<Response>
    const inner = { connection: { fetch: { register: vi.fn(route => {
      expect(route.path).toBe('/api/cpaImages/catalog')
      expect(route.methods).toEqual(['POST'])
      expect(route.requestBody).toBe('buffered')
      handler = route.fetch
    }) }, rpc: { intercept: () => { throw new Error('Gateway already owns the interceptor') } } }, effect: (fn: () => unknown) => fn() }
    const ctx = { inject: (_: unknown, callback: (inner: unknown) => void) => callback(inner) }
    const resolveApiKey = vi.fn(async () => 'secret')
    registerImageCatalog(ctx as never, { config: () => resolveConfig({}), resolveApiKey, environmentBaseURL: () => undefined })
    const request = (payload: unknown, method = 'cpaImages/catalog') => new Request('http://localhost/api/cpaImages/catalog', {
      method: 'POST', body: JSON.stringify({ type: 'client-request', rpcId: 'test-id', method, payload }),
    })
    expect((await handler!(request({ apiKey: 'evil' }))).status).toBe(400)
    expect((await handler!(request(null, 'other'))).status).toBe(400)
    expect(resolveApiKey).not.toHaveBeenCalled()
    vi.mocked(discoverCpa).mockResolvedValue({ models: [{ id: 'gpt-image-2' }, { id: 'alias' }] } as never)
    const envelope = await (await handler!(request(null))).json()
    expect(envelope.type).toBe('server-response')
    expect(envelope.rpcId).toBe('test-id')
    const result = envelope.result
    expect(result.ok).toBe(true)
    expect(result.value).toEqual([{ value: 'gpt-image-2', label: 'gpt-image-2' }])
    expect(JSON.stringify(result)).not.toContain('secret')
  })
})
