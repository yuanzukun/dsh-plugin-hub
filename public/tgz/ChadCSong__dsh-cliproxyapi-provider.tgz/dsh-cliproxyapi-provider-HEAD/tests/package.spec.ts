import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import buildConfig from '../tsdown.config.js'

describe('published DSH bundle', () => {
  it('declares the tested host API line and the modern settings namespace/slot', () => {
    const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
    expect(manifest.engines.dsh).toBe('>=0.2.1-rc.2 <0.2.2-0')
    expect(manifest.devDependencies['@deepseek-ai/dsh-settings']).toBe('0.2.1-rc.2')
    const client = readFileSync(new URL('../src/client/index.ts', import.meta.url), 'utf8')
    expect(client).toContain('plugins.bundle.config')
    expect(client).toContain("'remote.credentials'")
    expect(client).not.toContain('settingsScope')
    const host = readFileSync(new URL('../src/index.ts', import.meta.url), 'utf8')
    expect(host).not.toContain('installSection')
    expect(host).toContain('loader/volatile-update')
  })
  it('loads the package by its published name', () => {
    const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')) as { name: string }
    const patch = readFileSync(new URL('../cordis.patch.yml', import.meta.url), 'utf8')

    expect(patch).toContain(`name: ${manifest.name}`)
  })

  it('registers the browser module by its published name', () => {
    const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')) as { name: string }
    const configs = buildConfig as unknown as Array<{
      outputOptions?: { banner?: string }
    }>
    const client = configs.find(config => config.outputOptions?.banner !== undefined)

    expect(client?.outputOptions?.banner).toContain(`id: ${JSON.stringify(manifest.name)}`)
  })
})
