import { afterEach, describe, expect, it, vi } from 'vitest'
import { Config } from '../src/config.js'

const runtime = vi.hoisted(() => ({ refresh: vi.fn(async () => {}), dispose: vi.fn() }))
vi.mock('../src/runtime.js', () => ({ CpaRuntime: class { refresh = runtime.refresh; dispose = runtime.dispose } }))
vi.mock('@deepseek-ai/dsh-tools', () => ({ defineTool: (definition: unknown) => definition }))
import { apply } from '../src/index.js'

afterEach(() => { vi.useRealTimers(); vi.clearAllMocks() })

describe('host scheduling outside Loader transactions', () => {
  it('defers volatile and credential notifications to the fixed startup timer', async () => {
    vi.useFakeTimers()
    const events = new Map<string, (...args: unknown[]) => void>()
    const cleanups: Array<() => void> = []
    const ctx = {
      settings: { configure: vi.fn(() => () => {}) }, fiber: {}, logger: {},
      on: (event: string, handler: (...args: unknown[]) => void) => { events.set(event, handler) },
      inject: vi.fn(),
      effect: (setup: () => () => void) => { cleanups.push(setup()) },
    }
    apply(ctx as never, Config({}))
    expect(ctx.settings.configure).toHaveBeenCalledWith({ auto: false }, ctx.fiber)
    expect(runtime.refresh).not.toHaveBeenCalled()
    await vi.advanceTimersByTimeAsync(1000)
    expect(runtime.refresh).toHaveBeenCalledTimes(1)
    events.get('loader/volatile-update')!()
    expect(runtime.refresh).toHaveBeenCalledTimes(1)
    await vi.advanceTimersByTimeAsync(1000)
    expect(runtime.refresh).toHaveBeenCalledTimes(2)
    events.get('credentials/reference-updated')!('UNRELATED')
    await vi.advanceTimersByTimeAsync(1000)
    expect(runtime.refresh).toHaveBeenCalledTimes(2)
    events.get('credentials/reference-updated')!('CLIPROXYAPI_API_KEY')
    expect(runtime.refresh).toHaveBeenCalledTimes(2)
    await vi.advanceTimersByTimeAsync(1000)
    expect(runtime.refresh).toHaveBeenCalledTimes(3)
    for (const cleanup of cleanups) cleanup()
    await vi.advanceTimersByTimeAsync(400000)
    expect(runtime.refresh).toHaveBeenCalledTimes(3)
    expect(runtime.dispose).toHaveBeenCalledTimes(1)
  })
})
