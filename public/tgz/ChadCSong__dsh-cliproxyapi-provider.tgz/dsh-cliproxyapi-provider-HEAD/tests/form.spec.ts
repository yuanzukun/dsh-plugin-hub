import { describe, expect, it, vi } from 'vitest'
import type { ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client'
import { CardForm, numberField, textField } from '../src/client/form.js'
import { CpaCardController, SETTINGS_NS } from '../src/client/controller.js'

function fixture() {
  let snapshot: ConfigFormSnapshot<Record<string, unknown>> = {
    status: 'ready', writable: true, revision: 2,
    value: { baseURL: '', apiKeyEnv: 'OLD', refreshIntervalSeconds: 300 }, base: {}, user: {},
  }
  const listeners = new Set<() => void>()
  const scope = {
    getSnapshot: () => snapshot,
    subscribe: (listener: () => void) => { listeners.add(listener); return () => { listeners.delete(listener) } },
    mutate: vi.fn(async (ops, _revision?: number) => {
      const value = { ...snapshot.value }
      for (const op of ops) {
        if (op.op === 'set') value[op.path[0]] = op.value
        else delete value[op.path[0]]
      }
      snapshot = { ...snapshot, value, revision: (snapshot.revision ?? 0) + 1 }
      for (const listener of listeners) listener()
      return true
    }),
    set: vi.fn(), unset: vi.fn(),
  }
  const form = new CardForm(scope, [textField('baseURL'), textField('apiKeyEnv'), numberField('refreshIntervalSeconds', 15, 86400)])
  return { scope, form, listeners, update: (patch: Partial<typeof snapshot>) => { snapshot = { ...snapshot, ...patch } } }
}

describe('native configuration form integration', () => {
  it('loads full image choices, validates selection and rejects late catalog responses', async () => {
    const { scope } = fixture()
    let finishFirst: (value: Array<{ value: string; label: string }>) => void = () => {}
    const load = vi.fn().mockImplementationOnce(() => new Promise(resolve => { finishFirst = resolve }))
      .mockResolvedValueOnce([{ value: 'gpt-image-2', label: 'GPT Image 2' }, { value: 'custom-alias', label: 'Alias' }])
    const api = { credentials: { describe: vi.fn(async () => ({ ok: true, value: {} })), set: vi.fn() } }
    const controller = new CpaCardController(scope, api as never, load)
    const face = controller.inject()
    face.refreshImageModels()
    await vi.waitFor(() => expect(face.hooks.cpaCard.getSnapshot().imageModels).toHaveLength(2))
    finishFirst([{ value: 'stale', label: 'Stale' }])
    await Promise.resolve()
    expect(face.hooks.cpaCard.getSnapshot().imageModels[0]?.value).toBe('gpt-image-2')
    face.edit('imageModel', 'invented')
    expect(face.hooks.cpaCard.getSnapshot().invalid).toBe(true)
    face.edit('imageModel', 'custom-alias')
    face.edit('imageProtocol', 'openai')
    face.edit('imageGenerationEnabled', 'true')
    face.save()
    await vi.waitFor(() => expect(scope.getSnapshot().value?.imageModel).toBe('custom-alias'))
    expect(scope.getSnapshot().value?.imageGenerationEnabled).toBe(true)
    controller.dispose()
  })
  it('batches settings with the revision at the start of editing', async () => {
    const { scope, form, update } = fixture()
    form.actions().edit('baseURL', 'http://localhost:8317')
    form.actions().edit('refreshIntervalSeconds', '60')
    update({ revision: 3 })
    await form.save()
    expect(scope.mutate).toHaveBeenCalledTimes(1)
    expect(scope.mutate).toHaveBeenCalledWith([
      { op: 'set', path: ['baseURL'], value: 'http://localhost:8317' },
      { op: 'set', path: ['refreshIntervalSeconds'], value: 60 },
    ], 2)
    expect(form.shell()).toMatchObject({ dirty: false, failed: false })
  })

  it('keeps drafts after conflict and writes no credential', async () => {
    const { scope } = fixture()
    scope.mutate.mockResolvedValue(false)
    const write = vi.fn(async () => true)
    const form = new CardForm(scope, [textField('apiKeyEnv')], [{ field: 'key', write }])
    form.actions().edit('apiKeyEnv', 'NEW')
    form.actions().edit('key', 'secret')
    await form.save()
    expect(form.shell()).toMatchObject({ dirty: true, failed: true, saving: false })
    expect(write).not.toHaveBeenCalled()
  })

  it('accepts new reference before writing the key and retries only failed secret', async () => {
    const { scope } = fixture()
    const write = vi.fn(async () => false)
    const form = new CardForm(scope, [textField('apiKeyEnv')], [{ field: 'key', write: async value => {
      expect(scope.getSnapshot().value?.apiKeyEnv).toBe('NEW')
      return write(value)
    } }])
    form.actions().edit('key', 'secret')
    form.actions().edit('apiKeyEnv', 'NEW')
    await form.save()
    write.mockResolvedValue(true)
    await form.save()
    expect(scope.mutate).toHaveBeenCalledTimes(1)
    expect(write).toHaveBeenCalledTimes(2)
    expect(form.field('key').text).toBe('')
  })

  it('blocks invalid, read-only and disposed writes', async () => {
    const { scope, form, update, listeners } = fixture()
    form.actions().edit('refreshIntervalSeconds', '1.5')
    expect(form.shell().invalid).toBe(true)
    await form.save()
    form.actions().edit('refreshIntervalSeconds', '60')
    update({ writable: false })
    await form.save()
    update({ writable: true })
    form.dispose()
    await form.save()
    expect(listeners.size).toBe(0)
    expect(scope.mutate).not.toHaveBeenCalled()
  })

  it('releases controller subscriptions and ignores credential reads after disposal', async () => {
    const { scope, listeners, form } = fixture()
    form.dispose()
    let finish!: (value: unknown) => void
    const credentials = { describe: vi.fn(() => new Promise(resolve => { finish = resolve })), set: vi.fn() }
    const controller = new CpaCardController(scope, { credentials } as never)
    expect(SETTINGS_NS).toBe('llm-cliproxyapi-auto')
    expect(listeners.size).toBe(2)
    const store = controller.inject().hooks.cpaCard
    controller.dispose()
    finish({ ok: true, value: { OLD: { configured: true } } })
    await Promise.resolve()
    expect(listeners.size).toBe(0)
    expect(store.getSnapshot().apiKeyConfigured).toBe(false)
  })
})
