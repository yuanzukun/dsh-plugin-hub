import { describe, expect, it, vi } from 'vitest'
import { imageChoices, imageTransport } from '../src/image-models.js'
import { requestImage } from '../src/image-request.js'
import { discoverCpa } from '../src/discovery.js'

// 1×1 PNG; production uses DSH's decoder after the bounded wire parser.
const png = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jA1kAAAAASUVORK5CYII='
const defaults = { rootURL: 'http://127.0.0.1:8317', model: 'gpt-image-2', prompt: 'A blue bird', signal: new AbortController().signal }

describe('image catalog and transport', () => {
  it('filters image IDs/names case-insensitively and preserves image model ordering', () => {
    const models = [{ id: 'my-IMAGE-alias' }, { id: 'gpt-6-sol' }, { id: 'gpt-image-2' }, { id: 'gemini-3.1-flash-image' }, { id: 'custom', name: 'Image Studio' }, { id: 'gpt-image-2.5' }]
    const choices = imageChoices(models)
    expect(choices).toHaveLength(5)
    expect(choices.map(choice => choice.value)).not.toContain('gpt-6-sol')
    expect(choices).toContainEqual({ value: 'my-IMAGE-alias', label: 'my-IMAGE-alias' })
    expect(choices).toContainEqual({ value: 'custom', label: 'Image Studio' })
    expect(choices.findIndex(choice => choice.value === 'gpt-image-2.5')).toBeLessThan(choices.findIndex(choice => choice.value === 'gpt-image-2'))
    expect(models).toHaveLength(6)
    expect(choices.slice(0, 2).every(choice => imageTransport(choice.value))).toBe(true)
    expect(imageTransport('gpt-6-sol')).toBeUndefined()
    expect(imageTransport('gemini-3.1-pro')).toBeUndefined()
  })
  it('returns no choices when the catalog has no image-named models', () => {
    expect(imageChoices([{ id: 'gpt-6-sol' }, { id: 'alias', name: 'Chat model' }])).toEqual([])
  })
  it('reads full catalog without the Pi filter', async () => {
    const fetch = vi.fn(async () => Response.json({ data: [{ id: 'gpt-image-2' }, { id: 'my-alias' }] }))
    const result = await discoverCpa({ catalogMode: 'standard', timeoutMs: 1000, fetch })
    expect(fetch.mock.calls[0]?.[0]).toBe('http://127.0.0.1:8317/v1/models')
    expect(result.models.map(model => model.id)).toEqual(['gpt-image-2', 'my-alias'])
  })
  it('uses OpenAI Images with one image and server-side bearer credentials', async () => {
    const fetch = vi.fn(async () => Response.json({ data: [{ b64_json: png }] }))
    const result = await requestImage({ ...defaults, apiKey: 'private-test-key', fetch })
    expect(result.mediaType).toBe('image/png')
    expect(fetch).toHaveBeenCalledWith(defaults.rootURL + '/v1/images/generations', expect.objectContaining({
      method: 'POST', redirect: 'error', headers: expect.objectContaining({ Authorization: 'Bearer private-test-key' }),
      body: JSON.stringify({ model: 'gpt-image-2', prompt: 'A blue bird', n: 1, response_format: 'b64_json' }),
    }))
  })
  it('routes Gemini generation and ignores thought images', async () => {
    const fetch = vi.fn(async () => Response.json({ candidates: [{ content: { parts: [
      { thought: true, inlineData: { data: 'invalid' } }, { inlineData: { mimeType: 'wrong/type', data: png } },
    ] } }] }))
    const result = await requestImage({ ...defaults, model: 'gemini-3.1-flash-image', fetch })
    expect(result.mediaType).toBe('image/png')
    expect(fetch.mock.calls[0]?.[0]).toContain('/v1beta/models/gemini-3.1-flash-image:generateContent')
    expect(JSON.parse((fetch.mock.calls[0] as unknown as [string, RequestInit])[1].body as string).generationConfig.responseModalities).toEqual(['TEXT', 'IMAGE'])
  })
  it('requires a protocol choice for an unknown alias', async () => {
    const fetch = vi.fn(async () => Response.json({ data: [{ b64_json: png }] }))
    await expect(requestImage({ ...defaults, model: 'custom-alias', fetch })).rejects.toThrow('select OpenAI')
    expect(fetch).not.toHaveBeenCalled()
    await requestImage({ ...defaults, model: 'custom-alias', protocol: 'openai', fetch })
    expect(fetch).toHaveBeenCalledTimes(1)
  })
  it.each(['', ' '.repeat(3), 'x'.repeat(16001)])('refuses invalid prompt before network I/O', async prompt => {
    const fetch = vi.fn()
    await expect(requestImage({ ...defaults, prompt, fetch })).rejects.toThrow('prompt')
    expect(fetch).not.toHaveBeenCalled()
  })
  it('does not download URL-only responses', async () => {
    const fetch = vi.fn(async () => Response.json({ data: [{ url: 'http://169.254.169.254/private' }] }))
    await expect(requestImage({ ...defaults, fetch })).rejects.toThrow('image data')
    expect(fetch).toHaveBeenCalledTimes(1)
  })
  it('redacts upstream errors and never retries a failed generation', async () => {
    const fetch = vi.fn(async () => new Response('secret-key and prompt', { status: 401 }))
    await expect(requestImage({ ...defaults, fetch })).rejects.toThrow('HTTP 401')
    expect(fetch).toHaveBeenCalledTimes(1)
  })
  it('sanitizes network errors and forwards cancellation', async () => {
    const abort = new AbortController()
    abort.abort()
    const fetch = vi.fn(async (_url: unknown, init?: RequestInit) => { init?.signal?.throwIfAborted(); throw new Error('secret') })
    await expect(requestImage({ ...defaults, signal: abort.signal, fetch })).rejects.toThrow('interrupted')
    expect(fetch).toHaveBeenCalledTimes(1)
  })
  it('refuses malformed and non-raster inline bytes', async () => {
    for (const b64_json of ['bad!', Buffer.from('<svg/>').toString('base64')]) {
      await expect(requestImage({ ...defaults, fetch: async () => Response.json({ data: [{ b64_json }] }) })).rejects.toThrow()
    }
  })
  it('bounds response bytes before decoding', async () => {
    const stream = new ReadableStream({ start(controller) { controller.enqueue(new Uint8Array(24 * 1024 * 1024 + 1)); controller.close() } })
    await expect(requestImage({ ...defaults, fetch: async () => new Response(stream) })).rejects.toThrow('24 MiB')
  })
  it('reports a text-only Gemini answer as failure', async () => {
    await expect(requestImage({ ...defaults, model: 'gemini-3.1-flash-image', fetch: async () => Response.json({ candidates: [{ content: { parts: [{ text: 'No image' }] } }] }) })).rejects.toThrow('no image')
  })
})
