import { describe, expect, it } from 'vitest'
import { Config, readConfig, resolveConfig } from '../src/config.js'

describe('DSH 0.2 volatile configuration', () => {
  it('exposes live references with the same plain defaults', () => {
    const live = Config({})
    expect(live.enabled.get()).toBe(true)
    expect(resolveConfig(readConfig(live))).toEqual(resolveConfig({}))
    expect(Object.values(Config.dict!).every(field => field.meta?.volatile)).toBe(true)
  })
  it('rejects empty credential references and invalid polling intervals', () => {
    expect(() => Config({ apiKeyEnv: ' ' })).toThrow()
    expect(() => Config({ refreshIntervalSeconds: 1 })).toThrow()
  })
})
