# Changelog

## 0.3.0 — 2026-10-19

- Fix image tool configuration refresh after changing models/protocols by listening on the Loader entry's owning fiber; cover real Cordis filtered events and teardown in regression tests.
- Add opt-in bundled `cpa-image` skill and `cpa_generate_image` tool using the existing CPA endpoint and credential reference.
- Read the complete CPA model catalog through an owner-only DSH carrier endpoint; the image dropdown shows only IDs/names containing `image` (case-insensitive), with plain model labels and a shared availability hint.
- Support OpenAI Images and Gemini generateContent with explicit protocol selection for aliases; leave chat model discovery unchanged.
- Bound response/image bytes, reject redirects and URL-only images, sanitize upstream errors, cancel on disposal/config changes, prevent concurrent duplicate calls, and never automatically retry paid requests.
- Persist generated images through DSH attachments and avoid injecting image blocks into text-only conversation models.
- Keep generation disabled by default; no DSH source modifications and no global skill-directory writes.

## 0.2.0

- Target public DSH `0.2.1-rc.2` APIs and declare a conservative `engines.dsh` range; DSH 0.1.5 users should stay on 0.1.9.
- Replace removed settings registration with volatile schema fields and Loader configuration updates.
- Bind the browser form to `configForms` using the profile entry ID and mount it in `plugins.bundle.config` on the plugin detail page.
- Save ordinary settings atomically with revision fencing, then write credentials to the accepted reference; retain failed drafts and avoid replaying accepted settings.
- Dispose browser subscriptions and abort discovery on unload; ignore stale probe responses after configuration changes without deadlocking HMR on queued settings writes.
- Defer live configuration refreshes to the startup polling loop, outside Loader transactions; require one host restart after package installation/update.
- Preserve native transport options and model tuning while updating model membership and newest-first ordering.
- Keep native image handling only, without patching DSH or adding a separate vision model.
- Always refresh image capabilities from CPA, clearing synthetic image flags left by the retired vision bridge.
- Add configuration, form, conflict, cancellation, and model-merge regression tests; update bilingual installation and upgrade documentation.

## 0.1.9

- Remove the separate vision-model selector and image-to-text preprocessing bridge.
- Preserve only the native image-input capabilities reported by CLIProxyAPI.
- Let DSH enforce its native compatibility rules when a conversation contains images.

## 0.1.8

- Migrate settings registration to DSH 0.1.5's `ctx.settings.installSection` API.
- Follow the renamed `credentials/reference-updated` event on both Host and Client.
- Replace the removed `dsh-client-runtime` dependency with the new client store, settings, Remote, and renderer contracts.
- Build and type-check against the public DSH `0.1.5-rc.2` packages.

## 0.1.7

- Keep DSH's built-in DeepSeek provider untouched and subject to its native image-session model-switch restriction.
- Remove the experimental DeepSeek bridge alias so the picker does not show confusing duplicate model names.
- Retain independent vision preprocessing only for models managed by the plugin's CPA route.

## 0.1.6

- Decouple the selected vision model from the conversation's main model using DSH's public `llm/stream` extension point.
- Preprocess image attachments into factual text before calling text-only CPA models, allowing model switches in image-containing sessions.
- Cache successful descriptions by provider, vision model, and immutable attachment ID.
- Continue sending images directly when the selected main model is natively image-capable.
- Add a `DeepSeek (CPA vision)` adapter alias that delegates to DSH's official DeepSeek provider after preprocessing, without patching DSH or duplicating its credentials.

## 0.1.5

- Register the browser bundle with the published `dsh-cliproxyapi-provider` name required by DSH rc.8's strict client-module loader.
- Derive the browser module ID from `package.json` and test it alongside the host bundle name to prevent future drift.

## 0.1.4

- Build and type-check against the public DSH `0.1.0-rc.8` contracts.
- Load the rc.8 remote-event type assembly explicitly so model-catalog refresh subscriptions remain type-safe.
- Point the DSH bundle loader at the published `dsh-cliproxyapi-provider` package name.
- Keep runtime compatibility with the rc.7-based DSH Desktop release.

## 0.1.3

- Declare the DSH credential service as a startup dependency so a persisted CPA key is available on the first probe after restart.

## 0.1.2

- Keep CPA model families in catalog order while sorting versions newest-first within each family.

## 0.1.1

- Vision model is now a catalog-backed dropdown; model IDs cannot be typed manually.
- The dropdown probes after the CPA URL and API key are entered, with loopback discovery when the URL is empty.
- Credential updates immediately refresh the CPA route instead of waiting for the periodic timer.

## 0.1.0

- Initial open-source DSH bundle.
- Local IPv4/hostname/IPv6 CPA discovery.
- Dynamic `/v1/models` synchronization through the official pi-ai adapter.
- Native model switching, configurable vision model, settings card, credentials, and refresh/status commands.
