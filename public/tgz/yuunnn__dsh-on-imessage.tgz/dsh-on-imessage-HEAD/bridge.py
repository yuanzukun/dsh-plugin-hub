# bridge.py - iMessage -> dsh bridge
# Run: python3 bridge.py
#
# Commands:
#   direct message           continue current dsh session
#   dsh                      list workspaces
#   dsh use <id|path|name>   switch workspace
#   dsh use <id|path|name> <session#>   switch workspace + session
#   dsh sessions [<workspace>]          list sessions
#   dsh new <message>        start a new session

import os
import sys
import time
import json
import sqlite3
import hashlib
import uuid
import urllib.request
import argparse
import subprocess
import shutil
import glob
from datetime import datetime

NODE_BIN = os.environ.get("NODE_BIN", "node")


def find_dsh_bin():
    """Locate the dsh CLI entrypoint.

    Order:
      1. DSH_BIN env var (explicit)
      2. `dsh` on PATH
      3. npx cache (~/.npm/_npx/*/node_modules/@deepseek-ai/dsh/lib/bin.js)
      4. common dev clone (~/deepseek-harness/apps/cli/lib/bin.js)
    """
    env = os.environ.get("DSH_BIN")
    if env:
        return os.path.expanduser(env)
    path = shutil.which("dsh")
    if path:
        return os.path.realpath(path)
    hits = sorted(glob.glob(
        os.path.expanduser("~/.npm/_npx/*/node_modules/@deepseek-ai/dsh/lib/bin.js")
    ))
    if hits:
        return hits[-1]
    dev = os.path.expanduser("~/deepseek-harness/apps/cli/lib/bin.js")
    if os.path.isfile(dev):
        return dev
    return ""


DSH_BIN = os.environ.get("DSH_BIN", "") or find_dsh_bin()
CHAT_DB = os.path.expanduser("~/Library/Messages/chat.db")

# --- Configuration -----------------------------------------------------------
# Set these in bridge.py or via environment variables:
#   DSH_BUDDY              your iPhone iMessage handle (e.g. "+8613800138000")
#   DSH_AUTHORIZED_FROM    comma-separated sender whitelist (e.g. "+8613800138000")
#   DSH_BRIDGE_ACCOUNT     the iMessage account the bridge listens on (e.g. "E:dsh@icloud.com")
BUDDY = os.environ.get("DSH_BUDDY", "")
AUTHORIZED_FROM = set(filter(None, os.environ.get("DSH_AUTHORIZED_FROM", "").split(",")))
BRIDGE_ACCOUNT = os.environ.get("DSH_BRIDGE_ACCOUNT", "")

POLL_INTERVAL = 3
STATE_FILE = os.path.expanduser("~/.dsh-imessage-state.json")
DSH_TIMEOUT = 900


def detect_system_language():
    """Return 'zh' or 'en' based on macOS system language (dsh follows it)."""
    try:
        out = subprocess.run(
            ["defaults", "read", "-g", "AppleLanguages"],
            capture_output=True, text=True, encoding='utf-8', timeout=5,
        )
        if out.returncode == 0 and 'zh' in out.stdout:
            return 'zh'
    except Exception:
        pass
    return 'en'


UI_LANG = os.environ.get("DSH_BRIDGE_LANG") or detect_system_language()

# ---------- CJK UI strings (escaped) ----------
S_STARTED = "\U0001f50c dsh-iMessage \u6865\u5df2\u542f\u52a8\u3002\u53d1 'dsh' \u770b\u5de5\u4f5c\u533a\uff1b\u53d1 'dsh use <id|\u8def\u5f84|\u540d\u5b57>' \u5207\u6362\uff1b\u76f4\u63a5\u53d1\u6d88\u606f\u7ee7\u7eed\u5f53\u524d\u4f1a\u8bdd\u3002"
S_WS_TITLE = "\U0001f4c2 dsh \u5de5\u4f5c\u533a\uff1a"
S_WS_ITEM = "  {i}. {name}  ({n} sessions)"
S_CURRENT = "\u5f53\u524d\uff1a{ws}\n\u4f1a\u8bdd\uff1a{sess}"
S_SWITCHED = "\u5df2\u5207\u6362\u5230\uff1a{ws}\n\u4f1a\u8bdd\uff1a{sess}"
S_NO_MATCH = "\u6ca1\u6709\u627e\u5230\u5339\u914d '{kw}' \u7684\u5de5\u4f5c\u533a\u3002\u53d1 'dsh' \u770b\u5217\u8868\uff0c\u6216\u7528\u5b8c\u6574\u8def\u5f84\u3002"
S_MULTI_MATCH = "\u5173\u952e\u8bcd\u4e0d\u591f\u7cbe\u786e\uff0c\u5339\u914d\u5230\u591a\u4e2a\u5de5\u4f5c\u533a\uff1a\n{lst}\n\u8bf7\u7528\u5b8c\u6574\u540d\u5b57\u6216\u7f16\u53f7\u3002"
S_HELP = "dsh \u2192 \u5217\u51fa\u5de5\u4f5c\u533a\n  dsh use <id|\u8def\u5f84|\u540d\u5b57> [<session#>] \u2192 \u5207\u6362\u5de5\u4f5c\u533a/\u4f1a\u8bdd\n  dsh sessions [<id|\u8def\u5f84|\u540d\u5b57>] \u2192 \u67e5\u770b\u4f1a\u8bdd\n  dsh new <\u6d88\u606f> \u2192 \u5f00\u65b0\u4f1a\u8bdd\n  \u76f4\u63a5\u53d1\u6d88\u606f \u2192 \u7ee7\u7eed\u5f53\u524d\u4f1a\u8bdd"
S_NEW_DONE = "\u5df2\u5f00\u65b0\u4f1a\u8bdd\u3002\u540e\u7eed\u6d88\u606f\u4f1a\u7ee7\u7eed\u8fd9\u4e2a\u65b0\u4f1a\u8bdd\u3002"
S_NO_SESSIONS = "\u6ca1\u6709\u627e\u5230 dsh session\u3002"
S_WS_EMPTY = "{name} \u4e0b\u6ca1\u6709 session\u3002"
S_SESS_NOT_FOUND = "session \u7f16\u53f7 {n} \u4e0d\u5b58\u5728\u3002\u53d1 'dsh sessions {ws}' \u67e5\u770b\u5217\u8868\u3002"
S_ERROR = "[\u9519\u8bef] {err}"
S_TIMEOUT = "[timeout] dsh \u8d85\u65f6 >{n}s"

# ---------- English UI strings ----------
E_STARTED = "\U0001f50c dsh-iMessage bridge started. Send 'dsh' for workspaces; send 'dsh use <id|path|name>' to switch; just type a message to continue the current session."
E_WS_TITLE = "\U0001f4c2 dsh workspaces:"
E_WS_ITEM = "  {i}. {name}  ({n} sessions)"
E_CURRENT = "Current: {ws}\nSession: {sess}"
E_SWITCHED = "Switched to: {ws}\nSession: {sess}"
E_NO_MATCH = "No workspace matching '{kw}'. Send 'dsh' to list, or use the full path."
E_MULTI_MATCH = "Ambiguous keyword, matched multiple workspaces:\n{lst}\nUse a full name or index."
E_HELP = "dsh \u2192 list workspaces\n  dsh use <id|path|name> [<session#>] \u2192 switch workspace/session\n  dsh sessions [<id|path|name>] \u2192 list sessions\n  dsh new <message> \u2192 start a new session\n  direct message \u2192 continue current session"
E_NEW_DONE = "Started a new session. Follow-up messages will continue this new session."
E_NO_SESSIONS = "No dsh sessions found."
E_WS_EMPTY = "{name} has no sessions."
E_SESS_NOT_FOUND = "Session #{n} not found. Send 'dsh sessions {ws}' to list."
E_ERROR = "[error] {err}"
E_TIMEOUT = "[timeout] dsh took >{n}s"

# Apply language selection
if UI_LANG == 'en':
    S_STARTED = E_STARTED
    S_WS_TITLE = E_WS_TITLE
    S_WS_ITEM = E_WS_ITEM
    S_CURRENT = E_CURRENT
    S_SWITCHED = E_SWITCHED
    S_NO_MATCH = E_NO_MATCH
    S_MULTI_MATCH = E_MULTI_MATCH
    S_HELP = E_HELP
    S_NEW_DONE = E_NEW_DONE
    S_NO_SESSIONS = E_NO_SESSIONS
    S_WS_EMPTY = E_WS_EMPTY
    S_SESS_NOT_FOUND = E_SESS_NOT_FOUND
    S_ERROR = E_ERROR
    S_TIMEOUT = E_TIMEOUT

# ============================================================
# iMessage receive
# ============================================================
def extract_text_from_attr(attr):
    """Extract plain text from attributedBody (fallback when text is NULL)."""
    if not attr:
        return None
    marker = b'NSString\x01\x95\x84\x01+'
    idx = attr.find(marker)
    if idx < 0:
        return None
    pos = idx + len(marker)
    if pos >= len(attr):
        return None
    length = attr[pos]
    pos += 1
    chunk = attr[pos:pos + length]
    try:
        return chunk.decode('utf-8')
    except UnicodeDecodeError:
        return None


def query_new_messages(last_rowid):
    """Return messages with ROWID > last_rowid, ordered by ROWID."""
    conn = sqlite3.connect(CHAT_DB)
    conn.text_factory = bytes
    try:
        cur = conn.cursor()
        cur.execute(
            """
            SELECT m.ROWID, m.text, m.attributedBody, m.is_from_me, h.id, m.account
            FROM message m
            LEFT JOIN handle h ON h.ROWID = m.handle_id
            WHERE m.ROWID > ?
            ORDER BY m.ROWID ASC
            """,
            (last_rowid,),
        )
        results = []
        for row in cur:
            rowid, raw_text, raw_attr, is_from_me, raw_handle, raw_account = row
            text = None
            if raw_text:
                try:
                    text = raw_text.decode('utf-8')
                except UnicodeDecodeError:
                    text = raw_text.decode('utf-8', errors='replace')
            else:
                text = extract_text_from_attr(raw_attr)
            handle = None
            if raw_handle:
                handle = raw_handle.decode('utf-8', errors='replace')
            account = None
            if raw_account:
                account = raw_account.decode('utf-8', errors='replace')
            results.append({
                'rowid': rowid,
                'text': text,
                'is_from_me': is_from_me,
                'handle': handle,
                'account': account,
            })
        return results
    finally:
        conn.close()


def get_latest_rowid():
    conn = sqlite3.connect(CHAT_DB)
    try:
        cur = conn.cursor()
        cur.execute("SELECT MAX(ROWID) FROM message")
        result = cur.fetchone()
        return result[0] if result and result[0] else 0
    finally:
        conn.close()


# ============================================================
# iMessage send
# ============================================================
def send_imessage(text):
    """Send one iMessage via osascript to BUDDY (email handle)."""
    safe = text.replace('\\', '\\\\').replace('"', '\\"')
    script = (
        'tell application "Messages"\n'
        'set targetService to 1st service whose service type = iMessage\n'
        f'set targetBuddy to buddy "{BUDDY}" of targetService\n'
        f'send "{safe}" to targetBuddy\n'
        'end tell'
    )
    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True, text=True, encoding='utf-8', timeout=30,
        )
    except subprocess.TimeoutExpired:
        sys.stderr.write("[send timeout] osascript hung\n")
        return False
    except Exception as e:
        sys.stderr.write("[send exception] " + str(e) + "\n")
        return False
    if result.returncode != 0:
        sys.stderr.write("[send error] " + result.stderr + "\n")
        return False
    return True


def send_multipart(text, max_len=1800):
    """Send text, splitting long messages into parts."""
    if len(text) <= max_len:
        return send_imessage(text)
    parts = []
    chunk = ""
    for line in text.split("\n"):
        if len(chunk) + len(line) + 1 > max_len:
            if chunk:
                parts.append(chunk)
            chunk = line
        else:
            chunk = chunk + "\n" + line if chunk else line
    if chunk:
        parts.append(chunk)
    for i, part in enumerate(parts):
        prefix = "[%d/%d] " % (i + 1, len(parts)) if len(parts) > 1 else ""
        send_imessage(prefix + part)
        time.sleep(0.5)
    return True


# ============================================================
# dsh session management
# ============================================================
def decode_ws_name(dir_name):
    """Decode a dsh sessions dir name back to a filesystem path."""
    s = dir_name
    if s.endswith("--"):
        s = s[:-2]
    if s.startswith("--"):
        s = "/" + s[2:]
    positions = [i for i, ch in enumerate(s) if ch == '-']
    candidates = []
    for mask in range(1 << len(positions)):
        t = list(s)
        for j, pos in enumerate(positions):
            t[pos] = '/' if (mask >> j) & 1 else '-'
        candidates.append(''.join(t))
    candidates.sort(key=lambda p: (not os.path.isdir(p), p.count('/'), p))
    for c in candidates:
        if os.path.isdir(c):
            return c
    return candidates[0] if candidates else s


def list_workspaces():
    sessions_dir = os.path.expanduser("~/.dsh/sessions")
    if not os.path.isdir(sessions_dir):
        return []
    result = []
    for name in sorted(os.listdir(sessions_dir)):
        path = os.path.join(sessions_dir, name)
        if not os.path.isdir(path):
            continue
        ws_name = decode_ws_name(name)
        sess_count = 0
        latest_mtime = 0
        for sess in os.listdir(path):
            if sess.startswith("session-"):
                sess_count += 1
                mtime = os.path.getmtime(os.path.join(path, sess))
                if mtime > latest_mtime:
                    latest_mtime = mtime
        if sess_count > 0:
            result.append({
                'dir_name': name,
                'ws_name': ws_name,
                'sessions': sess_count,
                'latest_mtime': latest_mtime,
            })
    return result


def ws_display(ws):
    """Short display name: the basename of the workspace path."""
    name = ws['ws_name'].rstrip('/')
    return name.rsplit('/', 1)[-1] if '/' in name else name


def list_sessions(ws_dir_name):
    ws_path = os.path.expanduser("~/.dsh/sessions/" + ws_dir_name)
    if not os.path.isdir(ws_path):
        return []
    result = []
    for sess in os.listdir(ws_path):
        if not sess.startswith("session-"):
            continue
        sess_dir = os.path.join(ws_path, sess)
        # Prefer the session file mtime; resume updates the file, not the dir.
        mtime = os.path.getmtime(sess_dir)
        session_file = os.path.join(sess_dir, "session.jsonl.zstd")
        if os.path.isfile(session_file):
            file_mtime = os.path.getmtime(session_file)
            if file_mtime > mtime:
                mtime = file_mtime
        result.append({'session_id': sess, 'mtime': mtime})
    result.sort(key=lambda x: x['mtime'], reverse=True)
    return result


def latest_session_for_ws(ws_dir_name):
    sessions = list_sessions(ws_dir_name)
    return sessions[0]['session_id'] if sessions else None


def latest_session_overall():
    best = None
    for ws in list_workspaces():
        sessions = list_sessions(ws['dir_name'])
        if not sessions:
            continue
        mtime = sessions[0]['mtime']
        if best is None or mtime > best[0]:
            best = (mtime, sessions[0]['session_id'], ws)
    return best


# ============================================================
# dsh web API (primary path; keeps the web UI live)
# ============================================================
DSH_WEB_URL = "http://127.0.0.1:3080"


def rpc_call(method, payload, timeout=15):
    """Call dsh web RPC endpoint. Returns (value, error)."""
    body = json.dumps({
        "type": "client-request",
        "rpcId": str(uuid.uuid4()),
        "method": method,
        "payload": payload,
    }).encode("utf-8")
    req = urllib.request.Request(
        DSH_WEB_URL + "/api/" + method,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        return None, str(e)
    result = data.get("result", {})
    if not result.get("ok"):
        return None, (result.get("error") or {}).get("message", "rpc error")
    return result.get("value"), None


def extract_assistant_texts(events):
    """Extract finalized assistant text blocks from history events."""
    texts = []
    for entry in events or []:
        ev = entry.get("event", {})
        if ev.get("type") != "assistant/message":
            continue
        content = ev.get("data", {}).get("message", {}).get("content", [])
        if isinstance(content, list):
            text = "".join(
                b.get("text", "")
                for b in content
                if isinstance(b, dict) and b.get("type") == "text"
            )
            if text:
                texts.append(text)
    return texts


def call_dsh_web(prompt, session_id):
    """Send a prompt through dsh web and wait for the reply."""
    # Establish baseline seq
    history_val, err = rpc_call("session.history", {"sessionId": session_id, "maxMessages": 1})
    if err:
        return None, err
    events = history_val.get("events", [])
    baseline = max(
        (e.get("event", {}).get("seq", 0) for e in events),
        default=0,
    )

    # Send the prompt
    val, err = rpc_call("session.prompt", {
        "sessionId": session_id,
        "mode": "queue",
        "content": [{"type": "text", "text": prompt}],
    })
    if err:
        return None, err
    if not (val or {}).get("accepted"):
        return None, "prompt not accepted"

    # Poll history for the new assistant message
    deadline = time.time() + DSH_TIMEOUT
    last_text = None
    while time.time() < deadline:
        time.sleep(5)
        history_val, err = rpc_call("session.history", {
            "sessionId": session_id,
            "maxMessages": 30,
        })
        if err:
            continue
        new_texts = []
        for entry in history_val.get("events", []) or []:
            ev = entry.get("event", {})
            if ev.get("seq", 0) > baseline and ev.get("type") == "assistant/message":
                content = ev.get("data", {}).get("message", {}).get("content", [])
                if isinstance(content, list):
                    text = "".join(
                        b.get("text", "")
                        for b in content
                        if isinstance(b, dict) and b.get("type") == "text"
                    )
                    if text:
                        new_texts.append(text)
        if new_texts:
            last_text = new_texts[-1]
            # If a turn/end exists after baseline, the reply is final.
            has_end = any(
                e.get("event", {}).get("seq", 0) > baseline
                and e.get("event", {}).get("type") == "turn/end"
                for e in history_val.get("events", []) or []
            )
            if has_end:
                return last_text, None
    if last_text:
        return last_text, None
    return None, "timeout waiting for dsh web reply"


# ============================================================
# dsh CLI (fallback when web UI is not running)
# ============================================================
def run_dsh(prompt, session_id=None, workspace=None):
    """Send a prompt to dsh (web API first, headless fallback)."""
    if session_id:
        reply, err = call_dsh_web(prompt, session_id)
        if err is None:
            return reply or "(no output)"
        # Web API unavailable/error -> fall back to headless
        sys.stderr.write("[web api unavailable] " + err + "\n")

    if not DSH_BIN:
        return "[error] dsh CLI not found. Set DSH_BIN or install dsh on PATH."
    args = [NODE_BIN, DSH_BIN, "--profile", "headless"]
    if session_id:
        args += ["--resume", session_id]
    args += [prompt]
    cwd = workspace if workspace and os.path.isdir(workspace) else None
    try:
        result = subprocess.run(
            args, capture_output=True, text=True, encoding='utf-8',
            timeout=DSH_TIMEOUT, cwd=cwd,
        )
        out = (result.stdout or '').strip()
        err = (result.stderr or '').strip()
        if result.returncode != 0:
            return "[dsh error] " + (err or out or ("rc=" + str(result.returncode)))
        return out or "(no output)"
    except subprocess.TimeoutExpired:
        return S_TIMEOUT.format(n=DSH_TIMEOUT)
    except Exception as e:
        return S_ERROR.format(err=str(e))


# ============================================================
# State
# ============================================================
def load_state():
    if os.path.isfile(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {}


def save_state(state):
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2)


# ============================================================
# Command handling (natural language)
# ============================================================
def parse_input(text):
    """Parse a user message into (action, arg)."""
    t = text.strip()
    low = t.lower()
    if low in ('dsh', 'list', 'sessions', 'ls', 'help', '?',
               'dsh list', 'dsh sessions', 'dsh ls', 'dsh help'):
        return ('list', None)

    # dsh use <target> [<session#>] / use / switch / qie huan
    for prefix in ('dsh use ', 'use ', 'switch ', '\u5207\u6362 ', '\u5207\u5230 '):
        if low.startswith(prefix):
            rest = t[len(prefix):].strip()
            if not rest:
                return ('list', None)
            parts = rest.split(None, 1)
            target = parts[0]
            sess_idx = None
            if len(parts) > 1 and parts[1].isdigit():
                sess_idx = int(parts[1])
            return ('switch', (target, sess_idx))
    if low in ('dsh use', 'use', 'switch', '\u5207\u6362', '\u5207\u5230'):
        return ('list', None)

    # dsh new <msg> / new <msg> / xin jian <msg>
    for prefix in ('dsh new ', 'new ', '\u65b0\u5efa ', '\u65b0\u4f1a\u8bdd '):
        if low.startswith(prefix):
            msg = t[len(prefix):].strip()
            return ('new', msg) if msg else ('list', None)

    # dsh sessions [<workspace>] [<session#>]
    for prefix in ('dsh sessions ', 'sessions '):
        if low.startswith(prefix):
            rest = t[len(prefix):].strip()
            if not rest:
                return ('sessions', (None, None))
            parts = rest.split(None, 1)
            target = parts[0]
            sess_idx = None
            if len(parts) > 1 and parts[1].isdigit():
                sess_idx = int(parts[1])
            return ('sessions', (target, sess_idx))

    # bare dsh <msg> is a direct chat (legacy habit)
    if low.startswith('dsh '):
        return ('chat', t[4:].strip())

    return ('chat', t)


def resolve_workspace(kw):
    """Resolve a workspace by index, full path, or basename."""
    wss = list_workspaces()
    if not wss:
        return None, [], 'no_sessions'

    kw = kw.strip()

    # 1. integer index
    if kw.isdigit():
        idx = int(kw)
        if 0 <= idx < len(wss):
            return wss[idx], [], None
        return None, wss, 'index_out_of_range'

    # 2. exact full path
    for ws in wss:
        if ws['ws_name'] == kw:
            return ws, [], None
    low = kw.lower()
    for ws in wss:
        if ws['ws_name'].lower() == low:
            return ws, [], None

    # basename helpers
    def basename(path):
        return path.rstrip('/').rsplit('/', 1)[-1]

    # 3. exact basename
    for ws in wss:
        if basename(ws['ws_name']) == kw:
            return ws, [], None
    for ws in wss:
        if basename(ws['ws_name']).lower() == low:
            return ws, [], None

    # 4. basename prefix
    prefix_matches = []
    for ws in wss:
        if basename(ws['ws_name']).lower().startswith(low):
            prefix_matches.append(ws)
    if len(prefix_matches) == 1:
        return prefix_matches[0], [], None
    if len(prefix_matches) > 1:
        return None, prefix_matches, 'ambiguous'

    # 5. basename substring (unique only)
    substr_matches = []
    for ws in wss:
        if low in basename(ws['ws_name']).lower():
            substr_matches.append(ws)
    if len(substr_matches) == 1:
        return substr_matches[0], [], None
    if len(substr_matches) > 1:
        return None, substr_matches, 'ambiguous'

    # 6. full path substring (unique only)
    path_matches = []
    for ws in wss:
        if low in ws['ws_name'].lower():
            path_matches.append(ws)
    if len(path_matches) == 1:
        return path_matches[0], [], None
    if len(path_matches) > 1:
        return None, path_matches, 'ambiguous'

    return None, [], 'no_match'


def cmd_list(state):
    wss = list_workspaces()
    if not wss:
        return S_NO_SESSIONS
    lines = [S_WS_TITLE]
    cur_dir = state.get('current_ws_dir')
    for i, ws in enumerate(wss):
        mark = ' *' if ws['dir_name'] == cur_dir else ''
        lines.append(S_WS_ITEM.format(i=i, name=ws_display(ws), n=ws['sessions']) + mark)
    lines.append('')
    cur_sess = state.get('current_session', '')
    cur_ws = ''
    for ws in wss:
        if ws['dir_name'] == cur_dir:
            cur_ws = ws_display(ws)
            break
    if cur_ws:
        lines.append(S_CURRENT.format(ws=cur_ws, sess=cur_sess[:20]))
    lines.append('')
    lines.append(S_HELP)
    return '\n'.join(lines)


def cmd_sessions(state, target, sess_idx=None):
    if not target:
        return cmd_list(state)
    ws, candidates, err = resolve_workspace(target)
    if err == 'no_sessions':
        return S_NO_SESSIONS
    if err == 'no_match':
        return S_NO_MATCH.format(kw=target)
    if err == 'ambiguous':
        lst = '\n'.join('  %d. %s' % (list_workspaces().index(c), ws_display(c)) for c in candidates)
        return S_MULTI_MATCH.format(lst=lst)
    if err == 'index_out_of_range':
        return S_NO_MATCH.format(kw=target)
    if ws is None:
        return S_NO_MATCH.format(kw=target)
    sessions = list_sessions(ws['dir_name'])
    if not sessions:
        return S_WS_EMPTY.format(name=ws_display(ws))
    if sess_idx is not None:
        if sess_idx < 0 or sess_idx >= len(sessions):
            return S_SESS_NOT_FOUND.format(n=sess_idx, ws=ws_display(ws))
        sess = sessions[sess_idx]['session_id']
        state['current_ws_dir'] = ws['dir_name']
        state['current_ws_name'] = ws['ws_name']
        state['current_session'] = sess
        return S_SWITCHED.format(ws=ws_display(ws), sess=sess[:20])
    current = state.get('current_session')
    lines = ['\U0001f4ac %s sessions:' % ws_display(ws)]
    for i, s in enumerate(sessions):
        mark = ' *' if s['session_id'] == current else ''
        ts = datetime.fromtimestamp(s['mtime']).strftime('%m-%d %H:%M')
        lines.append('  %d. %s  (%s)%s' % (i, s['session_id'][:20], ts, mark))
    return '\n'.join(lines)


def cmd_switch(state, target, sess_idx=None):
    ws, candidates, err = resolve_workspace(target)
    if err == 'no_sessions':
        return S_NO_SESSIONS
    if err == 'no_match':
        return S_NO_MATCH.format(kw=target)
    if err == 'index_out_of_range':
        return S_NO_MATCH.format(kw=target)
    if err == 'ambiguous':
        lst = '\n'.join('  %d. %s' % (list_workspaces().index(c), ws_display(c)) for c in candidates)
        return S_MULTI_MATCH.format(lst=lst)
    if ws is None:
        return S_NO_MATCH.format(kw=target)
    sessions = list_sessions(ws['dir_name'])
    if not sessions:
        return S_WS_EMPTY.format(name=ws_display(ws))
    if sess_idx is not None:
        if sess_idx < 0 or sess_idx >= len(sessions):
            return S_SESS_NOT_FOUND.format(n=sess_idx, ws=ws_display(ws))
        sess = sessions[sess_idx]['session_id']
    else:
        sess = sessions[0]['session_id']
    state['current_ws_dir'] = ws['dir_name']
    state['current_ws_name'] = ws['ws_name']
    state['current_session'] = sess
    return S_SWITCHED.format(ws=ws_display(ws), sess=sess[:20])


def cmd_new(state, prompt):
    ws_dir = state.get('current_ws_dir')
    ws_name = state.get('current_ws_name', '')
    if not ws_dir:
        # pick latest workspace
        best = latest_session_overall()
        if not best:
            return S_NO_SESSIONS
        ws_dir = best[2]['dir_name']
        ws_name = best[2]['ws_name']
    resp = run_dsh(prompt, session_id=None, workspace=ws_name)
    # record the new session that dsh just flushed
    new_sess = latest_session_for_ws(ws_dir)
    if new_sess:
        state['current_ws_dir'] = ws_dir
        state['current_ws_name'] = ws_name
        state['current_session'] = new_sess
    return resp + '\n\n' + S_NEW_DONE


def cmd_chat(state, prompt):
    if not prompt:
        return None
    ws_dir = state.get('current_ws_dir')
    ws_name = state.get('current_ws_name')
    session_id = state.get('current_session')
    if not ws_dir or not ws_name or not session_id:
        best = latest_session_overall()
        if not best:
            return S_NO_SESSIONS
        ws_dir = best[2]['dir_name']
        ws_name = best[2]['ws_name']
        session_id = best[1]
        state['current_ws_dir'] = ws_dir
        state['current_ws_name'] = ws_name
        state['current_session'] = session_id
    return run_dsh(prompt, session_id=session_id, workspace=ws_name)


def handle_message(text, state):
    action, arg = parse_input(text)
    try:
        if action == 'list':
            return cmd_list(state)
        if action == 'sessions':
            if isinstance(arg, tuple):
                return cmd_sessions(state, arg[0], arg[1])
            return cmd_sessions(state, arg)
        if action == 'switch':
            if isinstance(arg, tuple):
                return cmd_switch(state, arg[0], arg[1])
            return cmd_switch(state, arg)
        if action == 'new':
            return cmd_new(state, arg)
        if action == 'chat':
            return cmd_chat(state, arg)
    except Exception as e:
        return S_ERROR.format(err=str(e))
    return None


# ============================================================
# Main loop
# ============================================================
def is_inbound_from_user(msg):
    """Accept messages only from the dsh email channel.

    The dsh bridge owns the iMessage conversation addressed to the iCloud
    email (account starts with 'E:').  Messages sent to the phone number
    (account starts with 'P:') are left alone, so the phone conversation can
    still be used as a personal memo / notes thread.
    """
    account = msg.get('account') or ''
    if not BRIDGE_ACCOUNT or not account.startswith(BRIDGE_ACCOUNT):
        return False
    if msg['is_from_me'] == 0 and msg['handle'] in AUTHORIZED_FROM:
        return True
    if msg['is_from_me'] == 1 and msg['handle'] == BUDDY:
        return True  # user sent from email identity
    return False


def fingerprint(text):
    """Stable short fingerprint for sent-message loop prevention."""
    return hashlib.sha256((text or '')[:200].encode('utf-8')).hexdigest()[:16]


def collect_sent_rowids(before_rowid):
    conn = sqlite3.connect(CHAT_DB)
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT ROWID FROM message WHERE ROWID > ? AND is_from_me = 1",
            (before_rowid,),
        )
        return [r[0] for r in cur.fetchall()]
    finally:
        conn.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--once', action='store_true', help='run one poll cycle then exit')
    ap.add_argument('--test-parse', metavar='MSG', help='run a command locally, print reply')
    ap.add_argument('--test-send', metavar='MSG', help='send a test iMessage and exit')
    args = ap.parse_args()

    if not args.test_parse:
        if not BUDDY or not AUTHORIZED_FROM or not BRIDGE_ACCOUNT:
            print("Configuration missing. Set DSH_BUDDY, DSH_AUTHORIZED_FROM, DSH_BRIDGE_ACCOUNT in bridge.py or as env vars.")
            sys.exit(1)

    if args.test_send:
        ok = send_multipart(args.test_send)
        print("sent" if ok else "failed")
        return

    if args.test_parse:
        state = load_state()
        reply = handle_message(args.test_parse, state)
        print(reply if reply is not None else "(no reply)")
        return

    state = load_state()
    sent = set(state.get('sent_rowids', []))
    sent_fp = set(state.get('sent_fp', []))
    last_rowid = state.get('last_rowid', 0)
    if last_rowid == 0:
        last_rowid = get_latest_rowid()
        state['last_rowid'] = last_rowid
        save_state(state)
        print("[init] starting from ROWID=%d" % last_rowid)

    def send_reply(text):
        """Send one bridge reply and track it so it is never re-read."""
        fp = fingerprint(text)
        sent_fp.add(fp)
        state['sent_fp'] = sorted(sent_fp)[-200:]
        before = get_latest_rowid()
        send_multipart(text)
        new_rows = collect_sent_rowids(before)
        for rowid in new_rows:
            sent.add(rowid)
        state['sent_rowids'] = sorted(sent)[-200:]
        save_state(state)
        return new_rows

    def process_once():
        nonlocal last_rowid
        messages = query_new_messages(last_rowid)
        for msg in messages:
            last_rowid = msg['rowid']
            state['last_rowid'] = last_rowid
            save_state(state)
            if msg['rowid'] in sent:
                continue
            if msg['is_from_me'] == 1 and fingerprint(msg['text'] or '') in sent_fp:
                continue
            if not is_inbound_from_user(msg):
                continue
            text = (msg['text'] or '').strip()
            if not text:
                continue
            reply = handle_message(text, state)
            if reply is None:
                continue
            ts = datetime.now().strftime('%H:%M:%S')
            print("[%s] in=%s -> out %d chars" % (ts, repr(text[:40]), len(reply)))
            new_rows = send_reply(reply)
            if new_rows:
                last_rowid = max(last_rowid, max(new_rows))
                state['last_rowid'] = last_rowid
                save_state(state)

    if args.once:
        process_once()
        return

    print("[daemon] polling every %ds, buddy=%s" % (POLL_INTERVAL, BUDDY))
    new_rows = send_reply(S_STARTED)
    if new_rows:
        last_rowid = max(last_rowid, max(new_rows))
        state['last_rowid'] = last_rowid
        save_state(state)
    while True:
        try:
            process_once()
        except KeyboardInterrupt:
            print("\n[exit]")
            break
        except Exception as e:
            sys.stderr.write("[loop error] " + str(e) + "\n")
        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    main()
