# dsh-on-iMessage

> 在 iPhone 的「信息」里直接和本机 DeepSeek Harness（dsh）代理聊天 —— 不用额外 App、不用服务器、不用云。

[![GitHub stars](https://img.shields.io/github/stars/yuunnn/dsh-on-imessage?style=for-the-badge)](https://github.com/yuunnn/dsh-on-imessage)
[![GitHub release](https://img.shields.io/github/v/release/yuunnn/dsh-on-imessage?style=for-the-badge&label=release)](https://github.com/yuunnn/dsh-on-imessage/releases)
[![License](https://img.shields.io/badge/license-Apache--2.0-2f6f73?style=for-the-badge)](LICENSE)
[![Awesome DSH Plugin](https://awesome-dsh-plugin.com/badge.svg)](https://awesome-dsh-plugin.com)

[![macOS](https://img.shields.io/badge/platform-macOS-111827?style=for-the-badge)](#)
[![iMessage](https://img.shields.io/badge/interface-iMessage-0d9488?style=for-the-badge)](#)
[![DeepSeek Harness](https://img.shields.io/badge/agent-DeepSeek%20Harness-7c3aed?style=for-the-badge)](#)
[![PRs welcome](https://img.shields.io/badge/PRs-welcome-brightgreen?style=for-the-badge)](#)

**English version: [README.md](README.md).**

把 Mac 变成一台 24/7 的 dsh 助手，住在你的 iMessage 会话里。给桥接账户发一条消息，本机 dsh 就会切换工作区/会话、调用工具、把回复发回给你 —— 全程不用开终端。

## 为什么做这个

- 你本来就用 iMessage；dsh 在 Mac 上。
- 手机 SSH 不够顺手；Web UI 要端口/组网；Telegram/微信要第三方平台。
- iMessage 在每台 iPhone 上都有、端到端加密、离线也能聊。

这个桥接给你**真正的聊天体验**：dsh 白色气泡，你蓝色气泡，一来一回。

## 特性

- **用 iMessage 和 dsh 聊天** —— 发任意消息，得到代理回复。
- **切换工作区** —— `dsh`、`dsh use stockKing`、`dsh use 2`。
- **切换会话** —— `dsh sessions stockKing`、`dsh use stockKing 0`。
- **开新会话** —— `dsh new <消息>`。
- **Web UI 实时同步** —— 如果 dsh web 在运行，消息走它的本地 API，浏览器端同步可见。
- **默认安全** —— 严格发送者白名单，别人触发不了你的代理。
- **中英文回复** —— 跟随 Mac 系统语言（或 `DSH_BRIDGE_LANG=en|zh`）。
- **零第三方服务** —— 全部在你 Mac 和苹果 iMessage 内。

## 环境要求

- macOS + 信息（Messages）+ 一个**独立的 Apple ID**（推荐，避免 self-chat 重复气泡）。
- 已安装 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)（也就是 `dsh`）。
- Python 3.9+（桥接只用标准库）。

## 安装

### 方式 A：作为 dsh 插件安装（推荐）

本仓库已经是标准 [DeepSeek Harness 插件 bundle](https://github.com/deepseek-ai/deepseek-harness/blob/main/docs/user/develop/basic/publish.md)，可以一条命令安装：

```bash
dsh plugin --profile web add github:yuunnn/dsh-on-imessage
```

然后在启动 `dsh web` 的 shell 里设置环境变量：

```bash
export DSH_BUDDY="+861234567890"             # 你的 iPhone 号码
export DSH_AUTHORIZED_FROM="+861234567890"   # 发送者白名单
export DSH_BRIDGE_ACCOUNT="E:dsh@icloud.com" # 登录在“信息”里的第二个 Apple ID
```

重启 `dsh web` 即可。插件会在 dsh profile 启动时自动拉起 `bridge.py`。

> 如果 pnpm 提示需要允许构建脚本，把 `dsh-on-imessage: true` 加到 profile 的 `pnpm-workspace.yaml` 即可；本包没有构建步骤，一般不需要。

### 方式 B：独立守护进程

在 Mac 终端粘贴这一行：

```bash
curl -fsSL https://raw.githubusercontent.com/yuunnn/dsh-on-imessage/main/install.sh | bash
```

完事。安装器会把仓库克隆到 `~/.dsh/bridges/imessage`、启动守护进程、**打印下一步操作，包括在信息里登录第二个 Apple ID**。

> 安装器只需要 `git` 和 `python3`，其它都在你的 Mac 上。


**DSH_BIN** (optional): if your dsh CLI is not on PATH and not in the npx cache, set the environment variable to its entry point, e.g. `export DSH_BIN="$HOME/deepseek-harness/apps/cli/lib/bin.js"`.

## 配置

1. **创建第二个 Apple ID**（例如 `dsh@example.com`），在 [appleid.apple.com](https://appleid.apple.com) 注册。这就是「dsh 人格」。
2. **在 Mac 的信息里登录该账户**（信息 > 设置 > iMessage）。
3. **设置桥接配置**。桥接从环境变量读取：
   - `DSH_BUDDY` = 你的 iPhone 号码，如 `+861234567890`
   - `DSH_AUTHORIZED_FROM` = 你的 iPhone 号码（或你回复用的邮箱）
   - `DSH_BRIDGE_ACCOUNT` = 桥接监听的 iMessage 账户，如 `E:dsh@icloud.com`
4. **重启守护进程**：
   ```bash
   pkill -f bridge.py; DSH_BUDDY="+861234567890" DSH_AUTHORIZED_FROM="+861234567890" DSH_BRIDGE_ACCOUNT="E:dsh@icloud.com" ~/.dsh/bridges/imessage/install.sh
   ```
5. **从 iPhone 给桥接账户发消息**，它会回复 `dsh` 帮助。

## 用法

| 命令 | 含义 |
|---|---|
| `dsh` | 列出工作区 |
| `dsh use <id\|路径\|名字>` | 切换工作区（最新会话） |
| `dsh use <id\|路径\|名字> <会话#>` | 切换工作区 + 指定会话 |
| `dsh sessions [<工作区>]` | 查看会话 |
| `dsh new <消息>` | 开新会话 |
| 其它任何消息 | 继续当前会话 |

工作区支持按编号、完整路径、目录名匹配 —— 精确匹配优先，模糊匹配有多个时列出候选。

## 架构

```
iPhone iMessage
   │  （发给 dsh@icloud.com）
   ▼
Mac 信息（chat.db + osascript）
   │
   ▼
bridge.py（轮询新消息）
   │
   ├── dsh web API (127.0.0.1:3080)  ──► dsh web UI 实时同步
   └── dsh --profile headless --resume（兜底）
   │
   ▼
通过信息把回复发回 iPhone
```

## 安全

- **发送者白名单**：只处理 `AUTHORIZED_FROM` 里的号码。
- **账户隔离**：只处理发到桥接账户的消息。
- **纯本地**：没有公网服务器、没有遥测、没有云。
- 你仍然可以用 iMessage 当备忘录；那些发到别的会话，桥接会忽略。

## 常见问题

**为什么要第二个 Apple ID？** iMessage 会把同一个 Apple ID 内地址互发当作 self-chat，导致气泡重复。独立的 Apple ID 才能得到干净的一对一对话。

**需要开着 dsh web UI 吗？** 不需要。web 进程不在时，桥接会自动退回 headless CLI。

**别人能触发我的代理吗？** 不能。只有白名单里的号码可以。

## License

Apache-2.0，见 [LICENSE](LICENSE)。
