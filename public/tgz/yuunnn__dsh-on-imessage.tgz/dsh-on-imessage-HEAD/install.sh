#!/usr/bin/env bash
set -euo pipefail

# dsh-iMessage bridge installer
# Installs to ~/.dsh/bridges/imessage and starts the daemon.

REPO_URL="${1:-https://github.com/yuunnn/dsh-on-imessage.git}"
TARGET="${DSH_BRIDGE_HOME:-$HOME/.dsh/bridges/imessage}"
LANG_MODE="${DSH_BRIDGE_LANG:-auto}"

echo "==> Installing dsh-iMessage bridge to $TARGET"

# 1. Clone or update the repo
if [ -d "$TARGET/.git" ]; then
  echo "==> Updating existing installation"
  git -C "$TARGET" pull --ff-only
else
  mkdir -p "$(dirname "$TARGET")"
  git clone "$REPO_URL" "$TARGET"
fi

cd "$TARGET"

# 2. Python dependencies (only stdlib used by bridge.py, but keep this for future deps)
if [ -f requirements.txt ]; then
  python3 -m pip install --user -r requirements.txt
fi

# 3. Kill any existing daemon
if [ -f "$TARGET/bridge.pid" ]; then
  OLD_PID=$(cat "$TARGET/bridge.pid")
  if kill -0 "$OLD_PID" 2>/dev/null; then
    echo "==> Stopping old daemon ($OLD_PID)"
    kill "$OLD_PID" || true
  fi
fi

# 4. Start daemon
if [ "$LANG_MODE" != "auto" ]; then
  export DSH_BRIDGE_LANG="$LANG_MODE"
fi
nohup python3 -u "$TARGET/bridge.py" > "$TARGET/bridge.log" 2>&1 &
echo $! > "$TARGET/bridge.pid"

echo "==> Done. dsh-iMessage bridge is running (pid $(cat "$TARGET/bridge.pid"))."
echo "    If DSH_BUDDY / DSH_AUTHORIZED_FROM / DSH_BRIDGE_ACCOUNT are not set,"
echo "    the bridge will exit with a configuration error."

echo ""
echo "Next steps:"
echo "  1. Sign in to a SECOND Apple ID in Messages (Settings > iMessage)."
echo "     This keeps the dsh conversation clean (one-to-one, no duplicate bubbles)."
echo "  2. Set the environment before starting dsh or this installer:"
echo "       export DSH_BUDDY=\"+861234567890\"             # your iPhone number"
echo "       export DSH_AUTHORIZED_FROM=\"+861234567890\"   # sender whitelist"
echo "       export DSH_BRIDGE_ACCOUNT=\"E:dsh@icloud.com\" # iMessage account for the bridge"
echo "  3. Restart the bridge:"
echo "       pkill -f bridge.py; $0"
echo "  4. From your iPhone, text the bridge account and send 'dsh'."

