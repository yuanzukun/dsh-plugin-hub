# awesome-dsh-plugin submission

Once this repo is older than 1 day and has 10+ commits, submit one file to
[awesome-dsh-plugin/awesome-dsh-plugin](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin).

File name: `data/plugins/yuunnn__dsh-on-imessage.yml`

```yaml
url: https://github.com/yuunnn/dsh-on-imessage
name: yuunnn/dsh-on-imessage
category: notify
description:
  en: 'iMessage bridge for DeepSeek Harness: chat with a local dsh agent from iPhone Messages, switch workspaces/sessions, and keep the web UI in sync — no servers or third-party platforms.'
  zh: 'DeepSeek Harness 的 iMessage 桥接：直接在 iPhone 信息里和本机 dsh 代理聊天，支持切换工作区/会话，并同步 Web UI——不需要服务器或第三方平台。'
```

Also add the `dsh-plugin` topic (already done on GitHub) and keep the repo actively maintained.
