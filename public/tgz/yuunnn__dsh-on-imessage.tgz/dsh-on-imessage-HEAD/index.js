import { spawn } from 'node:child_process'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'dsh-on-imessage'

export function apply(ctx) {
  const dir = path.dirname(fileURLToPath(import.meta.url))
  const python = process.env.DSH_IMESSAGE_PYTHON || 'python3'
  const script = path.join(dir, 'bridge.py')

  const child = spawn(python, [script], {
    cwd: dir,
    env: {
      ...process.env,
      DSH_BUDDY: process.env.DSH_BUDDY || '',
      DSH_AUTHORIZED_FROM: process.env.DSH_AUTHORIZED_FROM || '',
      DSH_BRIDGE_ACCOUNT: process.env.DSH_BRIDGE_ACCOUNT || '',
      DSH_BRIDGE_LANG: process.env.DSH_BRIDGE_LANG || '',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  })

  const log = (level, message) => {
    const line = message.trim()
    if (!line) return
    if (ctx.logger && typeof ctx.logger[level] === 'function') {
      ctx.logger[level](`[dsh-on-imessage] ${line}`)
    } else {
      console[level === 'warn' ? 'warn' : 'log'](`[dsh-on-imessage] ${line}`)
    }
  }

  child.stdout.on('data', (chunk) => log('info', chunk.toString()))
  child.stderr.on('data', (chunk) => log('warn', chunk.toString()))
  child.on('exit', (code, signal) => {
    log('warn', `bridge.py exited (code=${code}, signal=${signal})`)
  })

  ctx.effect(() => {
    return () => {
      if (!child.killed) {
        child.kill('SIGTERM')
      }
    }
  })
}
