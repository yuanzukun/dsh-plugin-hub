import { readFile, access } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(dirname(fileURLToPath(import.meta.url)))

const requiredFiles = [
  'package.json',
  'index.js',
  'bridge.py',
  'cordis.patch.yml',
  'README.md',
  'README.zh.md',
  'LICENSE',
]

for (const file of requiredFiles) {
  if (!existsSync(join(root, file))) {
    throw new Error(`missing required file: ${file}`)
  }
}

const pkg = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'))

if (!pkg.dsh?.bundle?.patch) {
  throw new Error('package.json must declare dsh.bundle.patch')
}

if (!existsSync(join(root, pkg.dsh.bundle.patch))) {
  throw new Error(`dsh.bundle.patch points to missing file: ${pkg.dsh.bundle.patch}`)
}

const patch = await readFile(join(root, pkg.dsh.bundle.patch), 'utf8')
if (!patch.includes('dsh-on-imessage')) {
  throw new Error('cordis.patch.yml does not reference the plugin package')
}

console.log('plugin smoke check passed')
