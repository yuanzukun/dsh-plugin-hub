import assert from "node:assert/strict";
import { test } from "node:test";
import { diff, parse, serialize } from "../src/portable.js";

// Shaped like a real exported profile, including a patch block with the `!!js`
// expression that made a YAML round-trip unacceptable.
const PROFILE = {
  name: "web",
  bundles: ["@deepseek-ai/dsh-base", "@deepseek-ai/dsh-web-app", "dsh-cloudflare-browser-run"],
  plugins: { "dsh-cloudflare-browser-run": "^0.1.1", "@huanlin/dsh-plugin-sleep": "^0.1.0" },
  patch: `- id: session-title
  config:
    fallbackMaxWords: 12
- id: session-persistence
  config:
    root: !!js dshHomePath('sessions')
`,
};

test("serialize then parse round-trips a profile exactly", () => {
  const back = parse(serialize(PROFILE));
  assert.equal(back.name, PROFILE.name);
  assert.deepEqual(back.bundles, PROFILE.bundles);
  assert.deepEqual(back.plugins, PROFILE.plugins);
  assert.equal(back.patch, PROFILE.patch);
});

test("bundle order survives the round trip", () => {
  // Load order decides which layer patches which; reordering changes the tree.
  const back = parse(serialize(PROFILE));
  assert.deepEqual(back.bundles, [
    "@deepseek-ai/dsh-base",
    "@deepseek-ai/dsh-web-app",
    "dsh-cloudflare-browser-run",
  ]);
});

test("a !!js expression in the patch is preserved verbatim", () => {
  const back = parse(serialize(PROFILE));
  assert.match(back.patch, /root: !!js dshHomePath\('sessions'\)/);
});

test("a profile with no plugins and no patch round-trips", () => {
  const bare = { name: "headless", bundles: ["@deepseek-ai/dsh-base"], plugins: {}, patch: "" };
  const back = parse(serialize(bare));
  assert.deepEqual(back, { name: "headless", bundles: ["@deepseek-ai/dsh-base"], plugins: {}, patch: "" });
});

test("an unsupported format version is rejected", () => {
  assert.throws(() => parse("dshp: 2\nname: x\nbundles:\n  - a\n"), /unsupported dshp format/);
});

test("a file without bundles is rejected rather than silently imported", () => {
  assert.throws(() => parse("dshp: 1\nname: x\n"), /lists no bundles/);
});

test("diff reports added, removed and changed entries", () => {
  const a = { name: "a", bundles: ["base", "web"], plugins: { p: "^1.0.0", q: "^1.0.0" }, patch: "x" };
  const b = { name: "b", bundles: ["base", "headless"], plugins: { p: "^2.0.0", r: "^1.0.0" }, patch: "y" };
  const d = diff(a, b);
  assert.deepEqual(d.bundles, ["- web", "+ headless"]);
  assert.deepEqual(d.plugins, ["~ p: ^1.0.0 -> ^2.0.0", "- q@^1.0.0", "+ r@^1.0.0"]);
  assert.equal(d.patch, true);
});

test("a pure reordering of bundles is still a difference", () => {
  const a = { name: "a", bundles: ["base", "web"], plugins: {}, patch: "" };
  const b = { name: "b", bundles: ["web", "base"], plugins: {}, patch: "" };
  assert.deepEqual(diff(a, b).bundles, ["~ same bundles, different order"]);
});

test("identical profiles diff to nothing", () => {
  const d = diff(PROFILE, { ...PROFILE, name: "other" });
  assert.deepEqual(d.bundles, []);
  assert.deepEqual(d.plugins, []);
  assert.equal(d.patch, false);
});
