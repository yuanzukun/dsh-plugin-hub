import assert from "node:assert/strict";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";

/** Each test gets its own $DSH_HOME; the module reads it per call, not at import. */
function sandbox(t) {
  const home = mkdtempSync(join(tmpdir(), "dshp-"));
  const prev = process.env.DSH_HOME;
  process.env.DSH_HOME = home;
  t.after(() => {
    if (prev === undefined) delete process.env.DSH_HOME;
    else process.env.DSH_HOME = prev;
    rmSync(home, { recursive: true, force: true });
  });
  return home;
}

const mod = () => import("../src/profile.js");

test("listing ignores pnpm's node_modules and incomplete directories", async (t) => {
  const home = sandbox(t);
  const { listProfiles, writeProfile } = await mod();
  writeProfile({ name: "web", plugins: {}, bundles: ["@deepseek-ai/dsh-base"], patch: "" });
  writeProfile({ name: "alpha", plugins: {}, bundles: ["@deepseek-ai/dsh-base"], patch: "" });
  // pnpm's hoisted store sits beside the profiles, and a half-made directory
  // without package.json is not bootable — neither should be listed.
  mkdirSync(join(home, "profiles", "node_modules"), { recursive: true });
  mkdirSync(join(home, "profiles", "half-made"), { recursive: true });

  assert.deepEqual(listProfiles(), ["alpha", "web"]);
});

test("a written profile has every file dsh needs to compose", async (t) => {
  const home = sandbox(t);
  const { writeProfile } = await mod();
  const dir = writeProfile({
    name: "demo",
    plugins: { "some-plugin": "^1.0.0" },
    bundles: ["@deepseek-ai/dsh-base", "some-plugin"],
    patch: "- id: x\n  config:\n    a: 1\n",
  });
  for (const f of ["package.json", "cordis.yml", "pnpm-workspace.yaml", "cordis.patch.yml"]) {
    assert.ok(existsSync(join(dir, f)), `${f} missing`);
  }
  const pkg = JSON.parse(readFileSync(join(dir, "package.json"), "utf8"));
  assert.equal(pkg.name, "dsh-profile-demo");
  assert.equal(pkg.private, true);
  assert.deepEqual(pkg.dsh.profile.bundles, ["@deepseek-ai/dsh-base", "some-plugin"]);
  assert.deepEqual(pkg.dependencies, { "some-plugin": "^1.0.0" });
  // cordis.yml must stay an empty list: the tree is composed from patch layers.
  assert.match(readFileSync(join(dir, "cordis.yml"), "utf8"), /^\[\]$/m);
  assert.ok(home);
});

test("a profile with no patch does not get an empty patch file", async (t) => {
  sandbox(t);
  const { writeProfile } = await mod();
  const dir = writeProfile({ name: "bare", plugins: {}, bundles: ["@deepseek-ai/dsh-base"], patch: "" });
  // dsh throws on a patch file that parses to nothing, so absent beats empty.
  assert.equal(existsSync(join(dir, "cordis.patch.yml")), false);
});

test("reading returns exactly what was written", async (t) => {
  sandbox(t);
  const { readProfile, writeProfile } = await mod();
  const original = {
    name: "rt",
    plugins: { a: "^1.0.0" },
    bundles: ["@deepseek-ai/dsh-base", "a"],
    patch: "- id: x\n",
  };
  writeProfile(original);
  assert.deepEqual(readProfile("rt"), original);
});

test("clone copies content and renames the package", async (t) => {
  sandbox(t);
  const { cloneProfile, readProfile, writeProfile } = await mod();
  writeProfile({ name: "src", plugins: { a: "^1.0.0" }, bundles: ["b"], patch: "- id: x\n" });
  const dir = cloneProfile("src", "dst");
  assert.equal(JSON.parse(readFileSync(join(dir, "package.json"), "utf8")).name, "dsh-profile-dst");
  const copy = readProfile("dst");
  assert.deepEqual(copy.plugins, { a: "^1.0.0" });
  assert.equal(copy.patch, "- id: x\n");
});

test("clone refuses to overwrite an existing profile", async (t) => {
  sandbox(t);
  const { cloneProfile, writeProfile } = await mod();
  writeProfile({ name: "a", plugins: {}, bundles: ["x"], patch: "" });
  writeProfile({ name: "b", plugins: {}, bundles: ["y"], patch: "" });
  assert.throws(() => cloneProfile("a", "b"), /already exists/);
});

test("reading a missing profile names the directory searched", async (t) => {
  sandbox(t);
  const { readProfile } = await mod();
  assert.throws(() => readProfile("nope"), /not found under .*profiles/);
});

test("removing a profile deletes it", async (t) => {
  sandbox(t);
  const { exists, removeProfile, writeProfile } = await mod();
  writeProfile({ name: "temp", plugins: {}, bundles: ["x"], patch: "" });
  assert.equal(exists("temp"), true);
  removeProfile("temp");
  assert.equal(exists("temp"), false);
});
