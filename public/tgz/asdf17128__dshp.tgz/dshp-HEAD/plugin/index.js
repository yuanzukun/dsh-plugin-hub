/**
 * dshp as a DeepSeek Harness plugin.
 *
 * Registers two tools around the thing a chat turn actually asks for:
 * "what setups do I have?" and "export this one so I can send it to someone".
 * The second is the interesting one — the agent can hand back the portable text
 * directly, which is the whole point of the format being short enough to paste.
 *
 * Read-only by design. Creating, cloning and deleting profiles stay CLI-only:
 * those write to the Harness home, and an agent doing that mid-conversation is
 * how you lose a setup you cannot get back.
 */

import { exists, listProfiles, profileSize, readProfile } from "../src/profile.js";
import { serialize } from "../src/portable.js";

export const name = "dshp";
export const inject = ["tools"];

/** @param {import('@deepseek-ai/cordis').Context} ctx */
export function apply(ctx) {
  ctx.tools.register({
    name: "list_profiles",
    description:
      "List the DeepSeek Harness profiles on this machine with their bundle count, " +
      "installed plugins and whether they carry a user patch. Read-only.",
    parameters: {},
    output: {
      schema: {
        type: "object",
        properties: { profiles: { type: "array" } },
        required: ["profiles"],
      },
      render: (_args, value) => [{ type: "text", text: renderList(value.profiles) }],
    },
    async execute() {
      return {
        profiles: listProfiles().map((name) => {
          const p = readProfile(name);
          return {
            name,
            bundles: p.bundles.length,
            plugins: Object.keys(p.plugins),
            patched: Boolean(p.patch.trim()),
            bytes: profileSize(name),
          };
        }),
      };
    },
  });

  ctx.tools.register({
    name: "export_profile",
    description:
      "Export a profile as one portable file — bundle order, plugin versions and " +
      "the user patch — that someone else reproduces with `dshp import`. Use this " +
      "when the user wants to share or back up their setup. Read-only.",
    parameters: {
      profile: { type: "string", required: true, description: "Profile name to export." },
    },
    output: {
      schema: {
        type: "object",
        properties: { profile: { type: "string" }, content: { type: "string" } },
        required: ["profile", "content"],
      },
      render: (_args, value) => [
        {
          type: "text",
          text:
            `Portable file for "${value.profile}" — save it and run \`dshp import <file>\`:\n\n` +
            `\`\`\`yaml\n${value.content}\`\`\``,
        },
      ],
    },
    async execute(args) {
      const profile = String(args?.profile ?? "").trim();
      if (!profile) throw new Error("profile is required");
      if (!exists(profile)) {
        throw new Error(`profile "${profile}" not found; call list_profiles first`);
      }
      return { profile, content: serialize(readProfile(profile)) };
    },
  });
}

function renderList(profiles) {
  if (profiles.length === 0) return "No profiles found under the Harness home.";
  const lines = [`${profiles.length} profile(s):`];
  for (const p of profiles) {
    const bits = [`${p.bundles} bundles`];
    if (p.plugins.length) bits.push(`${p.plugins.length} plugins: ${p.plugins.join(", ")}`);
    if (p.patched) bits.push("has a user patch");
    lines.push(`  ${p.name} — ${bits.join("; ")}`);
  }
  return lines.join("\n");
}
