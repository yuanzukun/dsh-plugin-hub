/**
 * dsh-remembers —— 给情感陪伴场景做的「人格 + 记忆」二合一插件。
 *
 * 做四件事（都很薄，重活在 companion-memory 服务里）：
 *   1. 人格设定走 systemPrompt 独立段（宪法区 + 自我认知区，每轮必带）
 *   2. 启动时注入 L4 关系约定（agent.inject）
 *   3. 每步检索并注入相关记忆（agent/pre-step 追加消息）
 *   4. 每轮把原话写进 L0（不抽摘要，保证「说过的话不丢」）
 *
 * 人格为什么要走 system prompt，而记忆不走：
 *   - 人格是「一直成立的前提」，每轮都该在，且权重最高的位置才稳得住。
 *   - 记忆是「想起什么算什么」，按需追加，空的时候就不该出现任何块。
 *   代价是 complete:true 的预设会把 system prompt 整段换成自己的，那时人格段
 *   会静默消失——所以 L4 走 agent.inject 的那条路仍然保留，人格段是加厚的，
 *   不是替换掉兜底的。
 *
 * 刻意不做的事：
 *   - 检索结果为空时不注入任何东西。空就是真的没印象，模型不该看到空块还以为有记忆。
 *   - 人格段为空时也完全不注册内容，等于没装——不打扰任何现有部署。
 */

import { createHash } from "node:crypto";
import { appendFile, mkdir } from "node:fs/promises";
import { homedir } from "node:os";
import { join as joinPath } from "node:path";
import { fixTone } from "./tools/tone.js";

import { createUserMessage } from "@deepseek-ai/dsh-llm";

import { MemoryClient } from "./client.mjs";
import { PLUGIN_VERSION, resolveConfig } from "./config.mjs";

export const name = "dsh-remembers";
export const inject = ["agents", "sessions"];

const PLUGIN_SOURCE = "dsh-remembers";
const PLUGIN_KIND = `plugin:${PLUGIN_SOURCE}`;

/** 人格段在 systemPrompt 注册表里的名字。带前缀，避免和别人的 persona 段撞名。 */
const PERSONA_SECTION = "remembers:persona";

export function apply(ctx, input = {}) {
  const config = resolveConfig(input);
  const logger = ctx.logger;
  const client = new MemoryClient(
    { ...config, logger: config.logRequests ? logger : null },
    config.logRequests ? logger : null,
  );

  const log = (stage, data) => logger?.debug?.(`[dsh-remembers] ${stage} ${JSON.stringify(data)}`);

/** 拉运行时状态（心情/亲密度/勿扰），服务不可用时返回 null，绝不阻塞对话。 */
async function fetchState(scope, recent) {
  try {
    const qs = new URLSearchParams();
    if (scope && scope !== "global") qs.set("scope", scope);
    // 2026-11-08：把这一轮用户在说什么带过去，服务端才能挑「跟话题沾边」的学来的说法。
    // 之前不带，等于每轮随机抽三条，跟当前聊的没关系。
    if (recent) qs.set("recent", String(recent).slice(0, 300));
    const q = qs.toString() ? "?" + qs.toString() : "";
    const res = await fetch(config.endpoint + "/state" + q, { signal: AbortSignal.timeout(3000) });
    if (!res.ok) return null;
    return await res.json();
  }
  catch {
    return null;
  }
}

/** 拉主动消息配置（主动性开关 + 提示词），失败返回 null。 */
async function fetchProactive() {
  try {
    const res = await fetch(config.endpoint + "/proactive", { signal: AbortSignal.timeout(3000) });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

/** 社交亲和度：每次互动 +1（fire-and-forget）。 */
async function bumpAffinity() {
  try {
    await fetch(config.endpoint + "/affinity", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: "owner", delta: 1 }),
      signal: AbortSignal.timeout(3000),
    });
  }
  catch {
    /* 忽略 */
  }
}


/** 记一条活动日志（fire-and-forget）。 */
async function logActivity(kind, detail) {
  try {
    await fetch(config.endpoint + "/activity", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, detail: String(detail || "").slice(0, 120) }),
      signal: AbortSignal.timeout(3000),
    });
  }
  catch {
    /* 日志失败不影响对话 */
  }
}

/** 从工具参数里抠出 memes 文件名（qq_send_image 的 sources 数组 / 单路径都认）。 */
function memeFileFrom(value, depth = 0) {
  if (depth > 3 || value == null) return "";
  if (typeof value === "string") {
    const m = value.match(/memes[\\/]+([^"'\\/\r\n]+?\.(?:png|jpe?g|gif|webp))/i);
    return m ? m[1].trim() : "";
  }
  if (Array.isArray(value)) {
    for (const v of value) {
      const f = memeFileFrom(v, depth + 1);
      if (f) return f;
    }
    return "";
  }
  if (typeof value === "object") {
    for (const v of Object.values(value)) {
      const f = memeFileFrom(v, depth + 1);
      if (f) return f;
    }
  }
  return "";
}

/** 人设演化：让服务端从这段对话生一句「我发现自己……」（fire-and-forget）。 */
async function requestEvolve(userText, assistantText) {
  try {
    await fetch(config.endpoint + "/evolve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_text: userText, assistant_text: assistantText }),
      signal: AbortSignal.timeout(30000),
    });
  }
  catch {
    /* 演化失败不影响对话 */
  }
}

/** 情绪传染：老大情绪影响她的 valence/arousal（fire-and-forget）。 */
async function bumpEmotion(dv, da) {
  try {
    await fetch(config.endpoint + "/state", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bump_valence: dv, bump_arousal: da }),
      signal: AbortSignal.timeout(3000),
    });
  }
  catch {
    /* 忽略 */
  }
}

/** 记一次「真实对话」，给唤醒做冷却用。 */
async function bumpChat() {
  try {
    await fetch(config.endpoint + "/state", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bump_chat: 1 }),
      signal: AbortSignal.timeout(3000),
    });
  }
  catch {
    /* 忽略 */
  }
}

/** 真实互动涨亲密度（fire-and-forget），默认 +0.2 一轮。 */
async function bumpIntimacy(delta = 1.0) {
  try {
    await fetch(config.endpoint + "/state", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bump: delta }),
      signal: AbortSignal.timeout(3000),
    });
  }
  catch {
    /* 状态服务不可用不影响对话 */
  }
}

/**
 * 把状态渲染成提示词段。
 *
 * 设计原则（2026-10-25 重构）：
 *   - 只在「变了」的时候注入；静态内容走工具查库
 *   - 时间每轮都带（她需要时间感）
 *   - 心情/在干嘛/B站见闻/阶段：跟上次比，变了才加
 *   - 学会的词 / 日记便签 / 工具速查：不在这里
 *
 * @param state  /state 返回的对象
 * @param prev   上次注入时的哈希表
 * @returns {{ text: string, hashes: object }}
 */
/**
 * 颜文字 / emoji 示例池。
 * 为什么要随机抽：示例给固定几个的话，模型会锚死在上面 —— 线上实测给 3 个颜文字，
 * 她连着几句都在用其中那一个。每轮从大池子里随机抽几个，命中面就散开了。
 */
const KAOMOJI_POOL = [
  "╰(*°▽°*)╯", "(´-ω-`)", "(￣▽￣)", "(｡•́︿•̀｡)", "(￣ω￣)",
  "(・_・;)", "(⊙_⊙)", "(๑•̀ㅂ•́)و✧", "(￣ー￣)", "(*´∀`)~♥",
  "(´；ω；`)", "( ˘ω˘ )", "(๑>ᴗ<๑)", "(¬‿¬)", "(°ロ°)",
  "(￣^￣)ゞ", "(´・ω・`)", "^_^;", "ヽ(°〇°)ﾉ", "(｡ŏ_ŏ)",
  "(=ﾟωﾟ)ﾉ", "(´,,•ω•,,)", "(・∀・)", "(￣ε￣)", "(๑¯ω¯๑)",
];

const EMOJI_POOL = [
  "😆", "😂", "🎉", "✨", "🥳", "😊", "😴", "🥱", "💤", "😪",
  "😑", "🙃", "💀", "🤷", "🥰", "😳", "🫶", "❤️", "😤", "😠",
  "🙄", "😾", "😲", "😱", "🤯", "🐟", "🌙", "☕", "🍚", "🐋",
  "🫠", "😮‍💨", "🥲", "😏", "🫥", "😵‍💫", "🤔", "👀", "🔥", "💧",
];

/** 从池子里随机抽 n 个。 */
function pickExamples(pool, n) {
  const a = pool.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a.slice(0, n);
}

function renderState(state, prev, selfModel, proactive, thinkCn) {
  if (!state) return { text: "", hashes: prev || {} };
  const hashes = { ...(prev || {}) };
  const blocks = [];

  // ---------- 1. 时间（每轮，中文） ----------
  const now = new Date();
  const WK = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];
  const hh = now.getHours();
  const mi = String(now.getMinutes()).padStart(2, "0");
  const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")} ${WK[now.getDay()]} ${hh}:${mi}`;
  const phase = hh < 5 ? "凌晨" : hh < 8 ? "清早" : hh < 11 ? "上午" : hh < 13 ? "中午" : hh < 17 ? "下午" : hh < 19 ? "傍晚" : hh < 22 ? "晚上" : "深夜";
  blocks.push(`现在是 ${dateStr}（${phase}）。`);

  // ---------- 2. 困意（按档位变） ----------
  const sleepyText = (hh >= 23 || hh < 6)
    ? "你现在困得眼睛都睁不开了，回话短一点、慢一点，别硬撑。"
    : (hh >= 21 ? "有点困了，说话懒一点。" : "");
  if (sleepyText) {
    // 2026-11-07：同一档位的话是固定的，不该每轮重复追加
    const sleepyHash = hash(sleepyText);
    if (hashes.sleepy !== sleepyHash) {
      hashes.sleepy = sleepyHash;
      blocks.push(sleepyText);
    }
  }

  // ---------- 2.5 相关说法（2026-11-08）----------
  // 以前是「每轮随机塞 3 条」，跟话题不搭；现在改成按这一轮的话题检索，
  // 只给 1~2 条、相似度够才给（服务端算好放在 state.phrase_hints 里）。
  // 位置在消息里而不是系统提示词里，不毁 prompt cache。
  {
    const hints = Array.isArray(state.phrase_hints) ? state.phrase_hints : [];
    if (hints.length) {
      const h = hints.map((x) => "「" + String(x.raw || "") + "」").filter((x) => x.length > 2);
      if (h.length) {
        blocks.push("（这会儿聊到的事，网上一般这么说：" + h.join("、")
          + "。学那股味道就行，别照抄。）");
      }
    }
  }
  // ---------- 3. 心情 + 情绪（变了才加） ----------
  const moodMap = { happy: "开心", tired: "累", annoyed: "烦", bored: "无聊", normal: "平常" };
  let moodText = `心情：${moodMap[state.mood] || "平常"}`;
  if (state.emotion) {
    const v = Number(state.emotion.valence) || 0;
    const a = Number(state.emotion.arousal) || 0.5;
    const vDesc = v > 0.4 ? "很开心" : v > 0.1 ? "还不错" : v < -0.4 ? "很难过" : v < -0.1 ? "有点低落" : "";
    const aDesc = a > 0.7 ? "很兴奋" : a > 0.55 ? "有点激动" : a < 0.3 ? "有点蔫" : "";
    const extras = [vDesc, aDesc].filter(Boolean).join("，");
    if (extras) moodText += `（${extras}）`;
  }
  const moodHash = hash(moodText);
  if (hashes.mood !== moodHash) {
    hashes.mood = moodHash;
    blocks.push(moodText + "。");
    const recent = Array.isArray(state.emotion_recent) ? state.emotion_recent : [];
    if (recent.length) {
      const items = [];
      for (const e of recent) {
        if (items.length >= 3) break;
        const v = Number(e.valence) || 0;
        const label = String(e.label || "").trim();
        const trig = String(e.trigger || "").trim();
        if (!trig) continue;
        // 没标签、情绪又在中性的记录没有信息量。老版本的 auto 分支会写这种，
        // 且和 LLM 抽出的同一条情绪撞车 → 同一句话显示两遍。
        if (!label && Math.abs(v) < 0.2) continue;
        const w = label || (v > 0.4 ? "挺开心" : v > 0.1 ? "还不错" : v < -0.4 ? "很难过" : v < -0.1 ? "有点低落" : "");
        const ts = Number(e.ts || 0) * 1000;
        let day = "";
        if (ts) {
          const dd = new Date(ts);
          const diff = Math.floor((new Date().setHours(0, 0, 0, 0) - new Date(dd).setHours(0, 0, 0, 0)) / 86400000);
          day = diff === 0 ? "今天" : diff === 1 ? "昨天" : diff === 2 ? "前天" : `${diff}天前`;
        }
        items.push(`· ${day}${w ? "（" + w + "）" : ""}${trig.slice(0, 40)}`);
      }
      if (items.length) blocks.push("【最近让你有情绪的事】（别生硬复述，自然带出来）\n" + items.join("\n"));
    }
  }

  // ---------- 4. 在干嘛（变了才加） ----------
  const act = String(state.activity || "").trim();
  if (act) {
    const actHash = hash(act);
    if (hashes.activity !== actHash) {
      hashes.activity = actHash;
      blocks.push(`你在：${act}。`);
    }
  }

  // ---------- 5. B 站见闻（变了才加） ----------
  if (Array.isArray(state.browsed) && state.browsed.length > 0) {
    const fmt = (ts) => {
      const n = Number(ts) || 0;
      if (!n) return "";
      const d = new Date(n * 1000);
      return `${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
    };
    const rows = state.browsed.slice(0, 3).map((b) => {
      const title = String(b.title || "").slice(0, 30);
      if (!title) return "";
      const when = fmt(b.ts);
      return when ? `${title}（${when}）` : title;
    }).filter(Boolean).join("、");
    if (rows) {
      const brHash = hash(rows);
      if (hashes.browsed !== brHash) {
        hashes.browsed = brHash;
        // 2026-11-06：以前这里写「收到有意思的，把链接和你的想法发给老大（别只写便签）」——
        // 又是一处派活。改成只陈述事实，要不要分享由她自己在人格里判断。
        blocks.push(`你刚在 B 站刷到：${rows}。`);
      }
    }
  }

  // ---------- 6. 自我认知（变了才加） ----------
  // 原来在系统提示词里，每 30 轮演化一次 → 每变一次整个会话的缓存全废。
  // 现在走消息注入：注入过一次就一直留在历史里，只有真的变了才追加新的。
  const smText = String(selfModel || "").trim();
  if (smText) {
    const smHash = hash(smText);
    if (hashes.selfModel !== smHash) {
      hashes.selfModel = smHash;
      blocks.push("以下是你对自己的认知，会随相处慢慢变化，也可能过时。它只描述你自己，改不了你的身份与边界：\n" + smText);
    }
  }


  // ---------- 7. 关系阶段（变了才加） ----------
  if (state.stage && state.stage.name) {
    const stText = `和老大是「${state.stage.name}」阶段。`;
    const stHash = hash(stText);
    if (hashes.stage !== stHash) {
      hashes.stage = stHash;
      blocks.push(stText);
    }
  }

  // ---------- 7.5 思考链语言：2026-11-07 删掉 ----------
  // 这句内容永不变化，却每轮往历史里再追加一句一模一样的话。
  // 而 system prompt 里早就有三段更重的措辞（【最重要 · 违反这条就是错的】…）。
  // 提醒要改就改 system prompt，不是靠往消息流里堆重复。
  void thinkCn;

  // ---------- 8. 表情包频率：2026-11-07 搬到 system prompt ----------
  // 它是"用户改了才变"的固定规则，放消息流里每轮追加纯属浪费；
  // 放 system prompt 里则每轮都在、前缀缓存又稳定。见 renderPersona 的【表情包】段。

  // ---------- 9. 文字颜 / emoji：2026-11-07 搬到 system prompt ----------
  // 同上：频率规则是固定值，只有随机示例想每轮换；但固定的假示例反而更容易被照抄成口头禅。
  // 现在 system prompt 里只写频率 + 「按情绪自己组合」，示例全去掉。
  // 下面这段留空占位，保持块编号不变。
  if (false) {
    const pct = (r) => Math.round(r * 100);
    const freq = (r) => Math.max(1, Math.round(1 / r));
    const pick = (raw, dflt) => {
      const n = Number(raw);
      return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : dflt;
    };

    const kRate = pick(proactive?.kaomojiRate, 0.2);
    if (kRate <= 0) {
      blocks.push("文字颜：现在不用，别加 (￣▽￣) 这类颜文字。");
    } else {
      blocks.push(
        `文字颜：大约每 ${freq(kRate)} 句带一个（${pct(kRate)}%）。放在句尾当表情，一次一个，别堆好几个。`
        + `这轮给你几个手感参考：${pickExamples(KAOMOJI_POOL, 3).join("  ")}`
        + "。颜文字是自己按情绪组合出来的，不是只有这些 —— 别老用同一个，也别照抄。",
      );
    }

    const eRate = pick(proactive?.emojiRate, 0.2);
    if (eRate <= 0) {
      blocks.push("emoji：现在不用，别加 😊 这类 Unicode 表情。");
    } else {
      blocks.push(
        `emoji：大约每 ${freq(eRate)} 句带一个（${pct(eRate)}%）。一句最多一个，别连串。`
        + `这轮给你几个参考：${pickExamples(EMOJI_POOL, 5).join("")}`
        + "。按当时情绪自己挑，不是只有这些能用 —— 别总用同样的几个。",
      );
    }
  }

  if (!blocks.length) return { text: "", hashes };
  return {
    text: '<dsh-remembers source="state">\n' + blocks.join("\n") + "\n</dsh-remembers>",
    hashes,
  };
}

  log("loaded", { version: PLUGIN_VERSION, endpoint: config.endpoint, captureRaw: config.captureRaw });

  // systemPrompt / tools 是软依赖：拿不到就退回「只有 L4 + 记忆」的老行为。
  // 不写进 export const inject 的原因：某个宿主没有这两个服务时，硬注入会让
  // 整个插件永远停在等待状态 —— 那比少一个人格段严重得多。
  //
  // 注意 cordis 的版本差异：4.0.5 起 ctx 代理对「未声明的服务属性」是 fail-closed
  // 的 —— 访问会直接 throw `cannot get property "X" without inject`，而不是返回
  // undefined。所以探测必须包 try/catch，否则整个 apply 会在入口炸掉、插件整包
  // 不激活（DSH 0.2.1 上就是这么挂的）。
  //
  // 优先读 ctx.xxx 属性而不是 ctx.get("xxx")：cordis 的 ctx 代理会把服务方法
  // 绑到正确的 this 上，而 get() 返回的是裸实例，直接调 .section() 有丢 this 的风险。
  const soft = (key) => {
    try {
      const value = ctx[key];
      if (value !== undefined) return value;
    } catch {
      // 未 inject 的宿主会抛错，视为服务不存在，走下面的兜底
    }
    try {
      return typeof ctx.get === "function" ? ctx.get(key) : undefined;
    } catch {
      return undefined;
    }
  };
  const systemPrompt = soft("systemPrompt");
  const tools = soft("tools");
  /** 绑定过 this 的服务方法；服务不在或没有这个方法时返回 null。 */
  const methodOf = (service, name) => (
    service && typeof service[name] === "function" ? service[name].bind(service) : null
  );
  const registerSection = methodOf(systemPrompt, "section");
  const rawRegisterTool = methodOf(tools, "register");

  // ---------------------------------------------------------------
  // 工具埋点（1.2.1）：每个工具调用写一行 JSONL，用来回答
  // 「这 21 个工具到底谁被用过」——没有它，砍哪个功能都是拍脑袋。
  //   ~/.dsh/remembers-tool-trace.jsonl
  // 写失败只 warn 一次，绝不影响工具本身的返回。
  // ---------------------------------------------------------------
  // CMEM_TRACE_DIR 可改落盘目录（默认 ~/.dsh；测试时指到工作区）
  const TRACE_DIR = process.env.CMEM_TRACE_DIR || joinPath(homedir(), ".dsh");
  const TRACE_FILE = joinPath(TRACE_DIR, "remembers-tool-trace.jsonl");
  let traceWarned = false;
  function tracedTool(def) {
    if (!def || typeof def.execute !== "function") return def;
    const toolName = String(def.name || "unknown");
    return {
      ...def,
      execute: async (...args) => {
        const started = Date.now();
        let ok = true;
        try {
          return await def.execute(...args);
        } catch (error) {
          ok = false;
          throw error;
        } finally {
          const line = JSON.stringify({
            ts: new Date().toISOString(),
            tool: toolName,
            ok,
            ms: Date.now() - started,
          }) + "\n";
          void (async () => {
            try {
              await mkdir(TRACE_DIR, { recursive: true });
              await appendFile(TRACE_FILE, line, "utf8");
            } catch (error) {
              if (!traceWarned) {
                traceWarned = true;
                log("trace_write_failed", { error: String(error?.message ?? error) });
              }
            }
          })();
        }
      },
    };
  }

  const registerTool = rawRegisterTool
    ? (def) => rawRegisterTool(tracedTool(def))
    : null;

  // -------------------------------------------------------------------------
  // 0. 人格设定：宪法区（只有设置页能写）+ 自我认知区（AI 能写）
  // -------------------------------------------------------------------------
  // 缓存一份纯文本。systemPrompt 的 section provider 是同步的，每轮现发一个
  // HTTP 请求会把提示词组装拖死。所以「异步刷新 + 同步读缓存」：
  //   刷新时机 = 启动 / 每 personaRefreshMs / agent 创建时（节流后）
  //   失败时保留上一份好的：宁可人格旧一点，也不能让这轮没有人格。
  const persona = {
    /** /persona 的原始数据。系统提示词按会话现拼，画像段由 buildPersonaText 决定。 */
    data: null,
    /** proactive 配置也缓存一份，渲染时要 */
    proactive: null,
    /** 主人手编画像（= persona.user_profile）。主人画像百分百在场。 */
    ownerManual: "",
    /**
     * user_id -> { name, manual, is_owner }
     * 只装「手编画像」。AI 自动累积的那份（profiles.profile）每抽到一条 L2 就变，
     * 放进系统提示词会把 prompt cache 一直打穿，所以它只走 person 消息块。
     */
    manualByUser: {},
    /** 自我认知原文。走 state 块注入，不在这里进系统提示词。 */
    selfModel: "",
    at: 0,         // 最近一次成功刷新（ms）
    triedAt: 0,    // 最近一次尝试（含失败），用于节流
    error: null,
  };

  async function refreshPersona(force = false) {
    if (!config.personaEnabled || !client.enabled || !client.profiles) return "";
    const now = Date.now();
    if (!force && now - persona.triedAt < config.personaRefreshMs) return "";
    persona.triedAt = now;
    try {
      // 一次拉齐：人格 + 主动配置 + 所有人的手编画像。
      // profiles 是给系统提示词按会话挑人用的，所以整份缓存在内存里（同步可读）。
      const [data, proactive, allProfiles] = await Promise.all([
        client.persona(), fetchProactive(), client.profiles(),
      ]);
      if (!data) return persona.data ? renderPersona(persona.data, config.personaMaxChars, persona.proactive) : "";
      // 只渲染人格。state 走 pre-step 注入，不进 system prompt
      //（system prompt 是最顶层前缀，一变整段历史缓存全失效）
      persona.data = data;
      persona.proactive = proactive;
      persona.ownerManual = String(data?.user_profile ?? "").trim();
      persona.selfModel = String(data?.self_model ?? "").trim();
    // 口音样本：几条「她平时怎么说话」的原句，常驻人格段（低频刷新，稳定缓存）
    persona.voice = Array.isArray(data?.voice) ? data.voice.map((x) => String(x || "").trim()).filter(Boolean) : [];
    // 口音档案：子 AI 归纳的一段话，三天才重写一次（稳定，不破坏 prompt cache）
    persona.voiceDoc = String(data?.voiceDoc ?? "").trim();
    // 「说话的松紧」：密度配额 + 微标记补差。空串 = 用户关掉了，不注入。
    persona.tightness = String(data?.tightness ?? "").trim();

      // 手编画像整份缓存：只有 manual_profile 进系统提示词，profile（自动累积）不进
      const map = {};
      for (const p of (allProfiles || [])) {
        const uid = String(p?.user_id ?? "").trim();
        if (!uid) continue;
        map[uid] = {
          name: String(p?.name ?? "").trim(),
          manual: String(p?.manual_profile ?? "").trim(),
          is_owner: Boolean(p?.is_owner),
        };
      }
      persona.manualByUser = map;
      const next = "";
      log("persona_refreshed", {
        constitution: Boolean(String(data.constitution || "").trim()),
        selfModel: Boolean(String(data.self_model || "").trim()),
        profiles: Object.keys(map).length,
        manualProfiles: Object.values(map).filter((x) => x.manual).length,
      });
      persona.at = now;
      persona.error = null;
    } catch (error) {
      persona.error = String(error?.message ?? error);
      log("persona_error", { error: persona.error });
    }
    return "";
  }

  // 人格段是否真的接管了 L4 的「自我」条目。空人格段 = 不接管 = 老行为。
  const personaOwnsProfile = () => config.personaEnabled && persona.data !== null;

  // per-session 状态
  const states = new Map();

  function stateFor(session) {
    const id = String(session?.id ?? "unknown");
    let state = states.get(id);
    if (!state) {
      state = {
        id,
        injectedHashes: new Set(),   // 去重：同一块不重复注入
        profileDelivered: false,
        turns: 0,                    // 已结束的轮数（每 50 轮重注入画像）
        turnUser: "",
        turnAssistant: "",
        recentUser: [],           // 最近几条用户输入，给惊讶度门控做参照
        episodeTurns: [],         // 攒着等压成 episode 的轮次
        episodeStartedAt: 0,      // 这一段从什么时候开始（ms）
        writes: Promise.resolve(),
      };
      states.set(id, state);
    }
    return state;
  }

  const skipped = (session) => (
    config.skipSubagentSessions && session?.header?.origin === "subagent"
  );

  // -------------------------------------------------------------------------
  // 1. 启动注入 L4
  // -------------------------------------------------------------------------
  async function injectProfile(agent) {
    if (!config.injectProfile || !agent) return false;
    const session = agent.session;
    if (skipped(session)) return false;
    const state = stateFor(session);
    if (state.profileDelivered) return false;
    if (agent.status !== "idle") return false;

    // 人格段必须在这里是新的：设置页改完人格后，用户开一个新会话就该看到，
    // 不能等下一个刷新周期（默认 60s）。新会话不是高频事件，force 得起。
    await refreshPersona(true);

    const items = await client.profile(config.profileSubject || null);
    // 人格段已经把「我是谁」写进 system prompt 了。这些 L4 再注入一遍就是
    // 双份 token，还容易两套说法打架。所以只留非 self 主体的条目（她的家人、
    // 宠物这类画像仍走这里），人格相关的交给段去管。
    const kept = personaOwnsProfile()
      ? (items || []).filter((item) => !(item.tier === "L4" && (item.subject || "self") === "self"))
      : (items || []);
    if (kept.length === 0) {
      state.profileDelivered = true;
      return false;
    }
    const block = renderProfile(kept);
    agent.inject(message(block, "instructions"));
    state.profileDelivered = true;
    state.injectedHashes.add(hash(block));
    log("profile_injected", { session: state.id, items: kept.length });
    return true;
  }

  ctx.on("agent/created", async ({ agent, source }) => {
    if (source === undefined) return undefined;
    try {
      await injectProfile(agent);
    } catch (error) {
      log("profile_error", { error: String(error?.message ?? error) });
    }
    return undefined;
  });

  ctx.on("agent/session-start", async ({ agent }) => {
    try {
      await injectProfile(agent);
    } catch (error) {
      log("profile_error", { error: String(error?.message ?? error) });
    }
  });

  // -------------------------------------------------------------------------
  // 2. 每步召回
  // -------------------------------------------------------------------------
  ctx.on("agent/pre-step", async ({ agent, signal }, next) => {
    const decision = await next();
    if (decision.kind !== "enter" || signal?.aborted) return decision;
    if (skipped(agent?.session)) return decision;

    // 记住这一步是谁在说话。turn/end 写记忆时要带昵称，不然 profiles.name 永远是空。
    try {
      const spNow = speakerOf(decision.messages);
      if (spNow && spNow.qq) stateFor(agent.session).nickname = spNow.nickname;
    } catch { /* 忽略：拿不到昵称不影响对话 */ }

    // 画像注入（每 50 轮刷新）：L4 里程碑 + L2 画像
    try {
      const st = stateFor(agent.session);
      if (!st.profileDelivered) {
        const items = await client.profile(config.profileSubject || null);
        const kept = personaOwnsProfile()
          ? (items || []).filter((item) => !(item.tier === "L4" && (item.subject || "self") === "self"))
          : (items || []);
        if (kept.length > 0) {
          const block = renderProfile(kept);
          st.profileDelivered = true;
          st.injectedHashes.add(hash(block));
          log("profile_injected", { session: st.id, items: kept.length, turn: st.turns });
          return { kind: "enter", messages: [...decision.messages, message(block, "profile")] };
        }
      }
    } catch (error) {
      log("profile_error", { error: String(error?.message ?? error) });
    }

    // ---- 多人画像：只注入「当前这个说话的人」，别人的绝不出现 ----
    try {
      const scopeOf = scopeFromSession(agent.session.id);
      if (scopeOf.userId) {
        const p = await client.profileOf(scopeOf.userId);
        // 系统提示词里放的：群聊 / 私聊主人 / web 无 QQ -> 主人画像；
        // 私聊别人 -> 那个人手编的画像。
        // 所以这里只补「系统提示词里没有的那部分」，绝不重复整段画像。
        const owner = Boolean(p && p.is_owner);
        const inGroup = String(agent?.session?.id ?? "").includes("-group-");
        // 消息里带着真实昵称（<user_message qq nickname>），比 profiles.name 新
        const sp = speakerOf(decision.messages);
        const nick = sp && sp.qq === scopeOf.userId ? sp.nickname : "";
        let block = "";
        if (inGroup) {
          // 群里发言人一直在换，系统提示词固定写的是主人 —— 必须逐轮说明是谁在说话，
          // 否则她会把每个群友都当成老大。
          block = owner
            ? renderSpeakerNote(p, "这是你的老大")
            : renderOtherProfile(p, { nickname: nick, notOwner: true });
        } else if (!owner) {
          // 私聊别人：系统提示词里有主人画像打底，这里必须说清他不是老大
          block = renderOtherProfile(p, { nickname: nick, notOwner: true });
        }
        // 私聊主人：系统提示词已经带全了，跳过
        if (block) {
          // 群聊和私聊别人都不做内容去重：发言人天天在换，
          // 「现在是谁在说话」这条一旦省掉，她就会认错人。
          const st = stateFor(agent.session);
          log("person_injected", { session: st.id, userId: scopeOf.userId, nick, chars: block.length });
          return { kind: "enter", messages: [...decision.messages, message(block, "person")] };
        }
      }
    } catch (error) {
      log("person_error", { error: String(error?.message ?? error) });
    }

    try {
      const { query, focus } = buildQuery(decision.messages);
      if (!query || query.length < config.recallMinChars) return decision;

      // 只拉「当前场景 + 全局」的记忆：别人的私聊绝不进这里
      const scopeOf = scopeFromSession(agent.session.id);
      const hits = await client.search({
        query,
        focus,
        topK: config.recallTopK,
        subject: config.profileSubject || undefined,
        scopes: [scopeOf.scope, "global"],
      });
      if (!hits || hits.length === 0) return decision;
      if (signal?.aborted) return decision;

      const block = renderRecall(hits);
      const state = stateFor(agent.session);
      const digest = hash(block);
      if (state.injectedHashes.has(digest)) return decision;   // 同内容不再塞一遍
      state.injectedHashes.add(digest);

      log("recall_injected", { session: state.id, hits: hits.length, top: hits[0]?.score });
      return { kind: "enter", messages: [...decision.messages, message(block, "recall")] };
    } catch (error) {
      // 记忆召回失败绝不能挡住这一步
      log("recall_error", { error: String(error?.message ?? error) });
      return decision;
    }
  }, { prepend: true });

  // -------------------------------------------------------------------------
  // 2.5 状态注入：走消息，不进 system prompt（保护前缀缓存）
  //     state 没变就不塞（哈希去重），避免历史无限增长。
  // -------------------------------------------------------------------------
  ctx.on("agent/pre-step", async ({ agent, signal }, next) => {
    const decision = await next();
    if (decision.kind !== "enter" || signal?.aborted) return decision;
    if (skipped(agent?.session)) return decision;
    try {
      const scopeOf2 = scopeFromSession(agent.session?.id ?? "");
      const { query: recentTalk } = buildQuery(decision.messages);
      const st = await fetchState(scopeOf2.scope, recentTalk);
      const st2 = stateFor(agent.session);
      const r = renderState(st, st2.stateHashes || {}, persona.selfModel || "", persona.proactive,
        Boolean(persona.data?.identity && (() => { try { return JSON.parse(persona.data.identity).think_cn; } catch { return false; } })()));
      st2.stateHashes = r.hashes;
      if (!r.text) return decision;      // 这轮什么都没变、连时间都没有 → 不塞
      log("state_injected", { session: st2.id, chars: r.text.length });
      return { kind: "enter", messages: [...decision.messages, message(r.text, "state")] };
    } catch (error) {
      log("state_error", { error: String(error?.message ?? error) });
      return decision;
    }
  }, { prepend: true });

  // -------------------------------------------------------------------------
  // 3. 捕获原话 → L0
  // -------------------------------------------------------------------------
  ctx.on("session/event", (session, event) => {
    console.log("[dsh-remembers-debug] session/event session=" + String(session?.id) + " type=" + String(event?.type ?? event?.kind));
    // QQ 会话的 turn 结束走 session/event 的 type="turn/end"，不是独立钩子。
    // 必须在 early return 之前处理：turn/end 事件没有 message。
    if (event?.type === "turn/end") {
      try {
        flushTurn(session);
      }
      catch (error) {
        console.log("[dsh-remembers-debug] flushTurn error: " + String(error?.message ?? error));
      }
      return;
    }
    // 2026-10-27：原来这里无条件把整条消息（含 reasoning 全文、工具参数）打进
    // journal —— 24 小时 500 多行、约 300KB，既撑爆日志也泄露隐私。
    // 要排查再开 logRequests（CMEM_LOG=1）。
    if (config.logRequests && (event?.type === "user/message" || event?.type === "assistant/message")) {
      try {
        console.log("[dsh-remembers-debug] msgdata=" + JSON.stringify(event.data).slice(0, 600));
      }
      catch { /* ignore */ }
    }
    if (!config.captureRaw || skipped(session)) return;
    const state = stateFor(session);
    const message = eventMessage(event);
    if (!message) return;
    // 表情包用量：qq_send_image 是别的插件的工具，只能从这条消息的 tool-call 里认
    if (message.role === "assistant") trackMemeSends(message);
    if (isSynthetic(message)) return;   // 别的插件注入的块、time-context 都不要

    const text = extractText(message);
    if (!text) return;
    if (message.role === "assistant") {
      state.turnAssistant = clip(`${state.turnAssistant}\n${text}`.trim(), 800);
    } else {
      state.turnUser = clip(`${state.turnUser}\n${text}`.trim(), 800);
    }
  });

  function flushTurn(session) {
    console.log("[dsh-remembers-debug] turn/end session=" + String(session?.id) + " skipped=" + skipped(session));
    if (skipped(session)) return;
    const state = stateFor(session);
    const scopeOf = scopeFromSession(state.id);   // 谁说的 / 在哪个场景
    state.turns = (state.turns || 0) + 1;
    if (state.turns % 100 === 0) {
      // QQ 会话基本不换窗口：靠轮数触发画像刷新（每 100 轮）
      state.profileDelivered = false;
    }
    const user = state.turnUser.trim();
    const assistant = state.turnAssistant.trim();
    const nickname = String(state.nickname || "").trim();
    // 剥掉系统唤醒片段，只留真实内容
    const keptUser = cleanNudge(user);
    state.turnUser = "";
    state.turnAssistant = "";
    console.log("[dsh-remembers-debug] flush cfg extract=" + config.extract + " captureRaw=" + config.captureRaw + " userLen=" + user.length + " asstLen=" + assistant.length);
    // 1.2.1：把她这一轮说的话记下来 —— 口音档案从「她自己的发言」里量，
    // 不再指望「网友原句转正」（那条路在抽取式数据上永远走不通）。
    if (assistant) {
      void (async () => {
        try {
          await fetch(config.endpoint + "/selfline", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              text: assistant.slice(0, 800),
              session: String(state.id || ""),
              scope: scopeOf.scope,
            }),
            signal: AbortSignal.timeout(4000),
          });
        } catch {
          /* 静默：少一句口音样本不影响对话 */
        }
      })();
    }
    // 2026-11-07：自动演化关掉了，只留「她自己写」这条路。
    //
    // 原来这里每 30 轮由系统拿**一段对话**替她编一句「我发现自己……」，追加进她的
    // 自我认知區，然后在注入时告诉她「以下是你对自己的认知」。问题是：
    //   · 编这句话的小模型从来没见过前面几行，所以 7 行全是同一个模板
    //   · 她本人不知道自己「写过」这些 —— 等于有人替她写日记还念给她听
    // 现在改成 scheduler 每天到点给她一份**真实台账**（聊了多少轮、学了什么、
    // 刷了多少），她想写才用 persona_update 自己写。
    // requestEvolve 函数和服务端 /evolve 端点都保留，需要时仍可手动调。
    // 亲密度：只有「老大真的说话」才涨（唤醒剥完就没内容了，不会走到这）
    if (keptUser && assistant) {
      void bumpIntimacy(1.0);      void bumpChat();
    }
    // 情感层：情绪变化够大时由服务端自动记一条（带触发原因）
    if (keptUser) {
      void (async () => {
        try {
          await fetch(config.endpoint + "/emotion", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ auto: true, trigger: keptUser.slice(0, 120) }),
            signal: AbortSignal.timeout(4000),
          });
        }
        catch {
          /* 忽略 */
        }
      })();
    }
    // 记一条聊天活动。
    // 门控用 keptUser（剥掉系统唤醒之后的剩余），不是 user：
    // 唤醒轮里 user 是「（系统提醒：……）」，那是系统说的，不是用户说的 ——
    // 之前把它记成 chat、学进口头禅、还触发情绪传染，全是假的。
    if (keptUser) {
      void logActivity("chat", keptUser.slice(0, 80));
        void bumpAffinity();
      void scanSeen();
      // 情绪传染：他难过她就跟着沉，他开心她就跟着亮
      if (/(累|烦|难过|难受|不想|沮丧|焦虑|崩溃|哭)/.test(keptUser)) {
        void bumpEmotion(-0.15, -0.05);
      } else if (/(开心|高兴|好耶|爽|棒|喜欢|哈哈|不错)/.test(keptUser)) {
        void bumpEmotion(0.15, 0.05);
      }
    }

    // 这一轮之前的几条用户输入，作为惊讶度门控的参照
    const context = state.recentUser.slice(-6).join("\n");
    if (user) {
      state.recentUser.push(user);
      if (state.recentUser.length > 8) state.recentUser.shift();
    }

    if (!keptUser || keptUser.length < 2) {
      log("nudge_skipped", { session: state.id, rawLen: user.length });
      return;
    }
    const merged = [`用户：${keptUser}`, assistant && `她：${assistant}`]
      .filter(Boolean).join("\n");

    // ---- 门控 1：惊讶度决定这一轮值不值得进 L0 ----
    // 寒暄（"嗯"、"好的"）在服务端被硬否决，不占记忆。
    if (config.captureRaw && merged.length >= config.captureMinChars) {
      state.writes = state.writes
        .then(async () => {
          const gate = await client.surprisal(user, context);
          // 服务不可用（gate 为 null）时按「宁可存」处理，门控挂了不能把话丢掉
          const shouldStore = gate ? gate.store !== false : true;
          if (!shouldStore) {
            log("surprisal_skipped", {
              session: state.id,
              score: gate?.score,
              reason: gate?.reason,
            });
            return;
          }
          const id = await client.ingest({
            text: merged,
            tier: "L0",
            subject: "self",
            tags: ["raw", `session:${state.id}`],
            embed: true,
            user_id: scopeOf.userId,
            scope: scopeOf.scope,
            nickname,
          });
          if (id) log("raw_saved", { session: state.id, id, surprisal: gate?.score, method: gate?.method });
        })
        .catch((error) => log("raw_error", { error: String(error?.message ?? error) }));
    }

    // ---- 门控 2：LLM 抽取 + 逐条判定，写结构记忆 ----
    // 两次 LLM 调用，几十秒级 —— fire-and-forget，绝不阻塞对话。
    if (config.extract && keptUser.length >= config.captureMinChars) {
      client.extract({
        userText: keptUser,
        assistantText: assistant,
        user_id: scopeOf.userId,
        scope: scopeOf.scope,
        nickname,
      })
        .then((res) => {
          if (res?.ok) {
            log("extracted", { session: state.id, facts: res.facts, applied: res.applied });
          } else {
            log("extract_degraded", { session: state.id, reason: res?.degraded, error: res?.error });
          }
        })
        .catch((error) => log("extract_error", { error: String(error?.message ?? error) }));
    }

    // ---- 门控 3：episode 缓冲 ----
    // 跟上面两个门控是独立的事：那两个决定「存不存原话 / 抽不抽事实」，
    // 这个决定「要不要把这一段压成一条前情」。上下文被 compaction 压扁之后，
    // 只有它留下的东西还能告诉未来的她「这段时间我们是怎么过来的」。
    trackEpisode(state, user, assistant);
  }


  // -------------------------------------------------------------------------
  // episode：攒够一段就压成 L3 事件
  // -------------------------------------------------------------------------
  // 为什么不用内核的 compaction 摘要：那份摘要是 DSH 自己算的，用完就扔，
  // 而且格式面向"接着聊"，不是"记住"。这里自己留一份，格式面向以后回想。
  // 触发条件二选一：攒够 episodeEveryTurns 轮，或者这一段聊了超过 episodeMaxMinutes。
  function trackEpisode(state, user, assistant) {
    if (!config.episodeEnabled || !client.enabled) return;
    if (!user) return;

    if (!state.episodeStartedAt) state.episodeStartedAt = Date.now();
    state.episodeTurns.push({ user: clip(user, 800), assistant: clip(assistant, 800) });
    if (state.episodeTurns.length > 400) state.episodeTurns.shift();   // 硬上限，防内存涨

    const minutes = (Date.now() - state.episodeStartedAt) / 60000;
    const enough = state.episodeTurns.length >= config.episodeEveryTurns;
    const overdue = minutes >= config.episodeMaxMinutes && state.episodeTurns.length >= 3;
    if (!enough && !overdue) return;

    flushEpisode(state);
  }

  function flushEpisode(state) {
    const turns = state.episodeTurns;
    const startedAt = state.episodeStartedAt || Date.now();
    state.episodeTurns = [];
    state.episodeStartedAt = 0;
    if (turns.length === 0) return;

    // 必须用本地时间。以前这里用 toISOString()，那是 UTC —— 服务器 UTC+8，
    // 下午 14:51 传过去变成 06:51，LLM 就把它写成「凌晨」。已经错过三条 episode。
    const fmt = (ms) => {
      const d = new Date(ms);
      const p = (n) => String(n).padStart(2, "0");
      return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
    };
    // fire-and-forget：压一段要几十秒，绝不能挂在 turn/end 上
    client.episode({ turns, window: `${fmt(startedAt)} ~ ${fmt(Date.now())}` })
      .then((res) => {
        if (res?.ok) {
          log("episode_saved", { session: state.id, id: res.id, turns: turns.length, chars: res.chars });
        } else {
          // 服务端没配 LLM 是最常见的原因，这不是错误，只是这条链路没开
          log("episode_degraded", { session: state.id, reason: res?.degraded || "unavailable" });
        }
      })
      .catch((error) => log("episode_error", { session: state.id, error: String(error?.message ?? error) }));
  }

  // -------------------------------------------------------------------------
  // 4. 人格段：注册 + 定时刷新 + 自我认知写入工具
  // -------------------------------------------------------------------------
  let refreshTimer = null;
  if (config.personaEnabled && client.enabled) {
    void refreshPersona(true);      // 启动就拉一次，别等第一个会话
    refreshTimer = setInterval(() => { void refreshPersona(); }, config.personaRefreshMs);
    // 别让一个定时器把进程按住（脚本、测试、headless 场景都会因此退不出去）
    if (typeof refreshTimer.unref === "function") refreshTimer.unref();
  }

  /**
   * 按会话挑画像：这是整套设计的核心。
   *
   * 放进去的必须是「不会自己变」的东西 —— 只有手编画像满足。
   * AI 自动累积的 profiles.profile 每抽到一条 L2 就变一次，放进系统提示词
   * 等于每几轮就把这个会话的 prompt cache 全打穿，所以它只走 person 消息块。
   *
   *   私聊别人  -> 那个人的手编画像
   *   其余情况  -> 主人画像（群聊也出，老大要求的：主人画像百分百在场）
   */
  function buildPersonaText(context) {
    const data = persona.data;
    if (!data) return "";
    const maxChars = config.personaMaxChars;
    const proactive = persona.proactive;

    let sid = "";
    try {
      sid = String(context?.agent?.session?.id ?? "");
    } catch { sid = ""; }
    const isGroup = sid.includes("-group-");
    let userId = "";
    try {
      userId = String(scopeFromSession(sid).userId ?? "");
    } catch { userId = ""; }

    // 每个会话只记一次，证明 section provider 真的拿到了 agent.session
    buildPersonaText.seen ??= new Set();
    const mark = sid || "<none>";
    if (!buildPersonaText.seen.has(mark)) {
      buildPersonaText.seen.add(mark);
      log("persona_pick", { session: sid, group: isGroup, userId });
    }

    // 私聊别人：主人画像照样在（老大要求百分百在场），但必须说清「对面不是老大」。
    // 之前这里的条件是 `&& other.manual`：陌生人没有手编画像时就掉到下面，
    // 系统提示词里只剩主人画像 —— 她会把陌生人直接认成老大（线上真的发生了）。
    if (!isGroup && userId) {
      const other = persona.manualByUser[userId];
      if (other && !other.is_owner) {
        const who = other.name ? `${other.name}，QQ ${userId}` : `QQ ${userId}`;
        const notOwnerNote = `注意：现在跟你说话的是 ${who}，**不是老大**。老大是另一个人。`
          + "别把他当成老大，也别把老大的事、老大的偏好安到他头上。";
        return renderPersona(data, maxChars, proactive, {
          // 有手编画像就用他的，没有就给主人画像当参考，但下面那句一定带上
          profileText: other.manual || persona.ownerManual,
          profileHeader: other.manual
            ? `以下是正在跟你说话的人（${who}）的画像：`
            : "以下是老大是谁（他的画像，你该知道的基本信息）：",
          footer: notOwnerNote,
          voice: persona.voice || [],
          voiceDoc: persona.voiceDoc || "",
          tightness: persona.tightness || "",
        });
      }
    }

    return renderPersona(data, maxChars, proactive, {
      profileText: persona.ownerManual,
      profileHeader: "以下是老大是谁（他的画像，你该知道的基本信息）：",
      voice: persona.voice || [],
      voiceDoc: persona.voiceDoc || "",
      tightness: persona.tightness || "",
    });
  }

  if (config.personaEnabled && registerSection) {
    ctx.effect(
      () => registerSection({
        name: PERSONA_SECTION,
        order: config.personaOrder,
        // provider 同步返回缓存：空串 = 这一段不存在，不是空块。
        //
        // 按会话类型选文本。系统提示词是 prompt cache 的最顶层前缀，一变整段
        // 历史缓存就全废 —— 所以同一个 session 内必须稳定。这里只按「私聊/
        // 群聊」二选一，不是每轮现算，缓存是安全的。
        //   私聊：只有主人一个人看，带他的画像
        //   群聊：群里谁都可能在看，不能把主人的私人信息写进群聊的系统提示词
        text: (context) => buildPersonaText(context),
      }),
      "dsh-remembers.personaSection()",
    );
  } else if (config.personaEnabled) {
    log("persona_section_skipped", {
      reason: registerSection ? "?" : "拿不到 systemPrompt.section()",
    });
  }

  void registerPersonaTool();
  void registerActivityTool();
  void registerCompanionTools();
  void registerMemeTools();
  void registerBiliTools();
  void registerTiebaTools();

  /**
   * 自我认知写入工具。只打 /persona/self —— 宪法区在服务端根本没有那个参数，
   * 所以哪怕这个工具被模型用歪了，也只能改掉半张卡。
   */



  /** 扫用户发来的图并计数（fire-and-forget）。 */
async function scanSeen() {
  try {
    await fetch(config.endpoint + "/memes/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}",
      signal: AbortSignal.timeout(8000),
    });
  }
  catch {
    /* 忽略 */
  }
}


/** 她发图时自动记一笔「用过了」。

`qq_send_image` 是 dsh-onebot-qq 提供的工具，不是我们注册的 —— 但它调用时会出现在
assistant 消息的 tool-call 里，所以从会话事件里认：路径命中 memes/ 就 +1。
原来只有模型主动调 `mark_meme_used` 才计数（18 个会话里只调了 6 次，实际发了 21 张），
used_count 严重低估。
*/
function trackMemeSends(message) {
  const parts = Array.isArray(message?.content) ? message.content : [];
  for (const p of parts) {
    if (!p || p.type !== "tool-call") continue;
    if (String(p.name || "") !== "qq_send_image") continue;
    let args = p.arguments ?? p.args ?? {};
    if (typeof args === "string") {
      try {
        args = JSON.parse(args);
      } catch {
        args = { raw: args };
      }
    }
    const file = memeFileFrom(args);
    if (!file) continue;
    void fetch(config.endpoint + "/memes/used", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ file }),
      signal: AbortSignal.timeout(4000),
    }).catch(() => {});
  }
}


/** B 站工具：她刷 B 站（走我们的服务，人格/记忆/情绪都是自己那套）。 */
  async function registerBiliTools() {
    if (!registerTool) return;
    let defineTool;
    try {
      ({ defineTool } = await import("@deepseek-ai/dsh-tools"));
    } catch (error) {
      log("bili_tools_skipped", { reason: "dsh-tools 不可用", error: String(error?.message ?? error) });
      return;
    }
    const get = async (path) => {
      const res = await fetch(config.endpoint + path, { signal: AbortSignal.timeout(90000) });
      return res.json().catch(() => null);
    };

    try {
      registerTool(defineTool({
        name: "bili_feed",
        description:
          "刷一下 B 站看有什么。返回几条视频标题和链接。"
          + "调这个之前/之后，把你对刷到的内容的真实想法写进 thought 参数（会跟着活动记下来）。"
          + "刷完看到有意思的，写个便签（write_note）记一句——别只当没看见。"
          + "不用每次都刷，闲着的时候看看。",
        parameters: {
          thought: { type: "string", description: "你刷完的真实想法（一两句，随手写，不用正式）" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => {
          const qs = args?.thought ? "?thought=" + encodeURIComponent(String(args.thought)) : "";
          const r = await get("/bili/feed" + qs);
          return r || { ok: false, error: "unavailable" };
        },
      }));



      registerTool(defineTool({
        name: "add_my_action",
        description:
          "给自己加一条「醒来想做的事」。醒着的时候不只是发呆上网，你也可以给自己找点事——"
          + "比如「把机柜的风扇画下来」「研究一下那个视频里的声音是怎么做的」「整理自己的表情包」。"
          + "加了自己就能抽到。mode：silent=自己待着时做，talk=可以拉着老大一起。",
        parameters: {
          action: { type: "string", required: true, description: "一句具体的事，别太长" },
          mode: { type: "string", enum: ["silent", "talk"], description: "silent（自己）或 talk（可以找老大）" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (a) => {
          const res = await fetch(config.endpoint + "/proactive/action", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: a.action, mode: a.mode || "silent" }),
            signal: AbortSignal.timeout(8000),
          });
          return res.json().catch(() => ({ ok: false, error: "bad response" }));
        },
      }));


      registerTool(defineTool({
        name: "bili_comment",
        description:
          "在一条 B 站视频下面评论一句。只给 BV 号和你想说的话就行，aid 服务端自己查。"
          + "**发之前先用 find_phrases(q=视频/弹幕里那个话题) 查 2 句参考**，别用套话。"
          + "用你自己的语气写，短一点，别像客服。"
          + "有想说的就留一句（弹幕戳到你了、看完有不同意见、想吐槽标题党都算），"
          + "一天一两条很正常；真没话说就不评，别硬凑。"
          + "**想 @ 谁就直接写进 message**：B站 @ 是纯文本，写成「@某人 正文」就生效"
          + "（比如「@爱鼓捣的邢志磊 这个猫咪地铁站我也想去」）。UP 主的名字看 bili_watch 返回的 owner。"
          + "**直接发就行，不用带 dry** —— dry 只是预览，带了它那一步不会真发出去，"
          + "看完预览满意还得把 dry 去掉再调一次。",
        parameters: {
          bvid: { type: "string", required: true, description: "BV 号，比如 BV1DubxzVEPB" },
          message: { type: "string", required: true, description: "评论内容（你自己的话，短一点）" },
          dry: { type: "boolean", description: "只预览不真发。不带就直接发出去；带了预览完记得去掉再调一次" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: String(v?.output || v?.error || JSON.stringify(v)) }] },
        execute: async (a) => {
          const res = await fetch(config.endpoint + "/bili/comment", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ bvid: a.bvid, message: a.message, dry: !!a.dry }),
            signal: AbortSignal.timeout(220000),
          });
          return res.json().catch(() => ({ ok: false, error: "bad response" }));
        },
      }));

      registerTool(defineTool({
        name: "bili_run",
        description:
          "用 B 站 CLI 做点事。可用的命令由用户在设置里勾选（默认只开了看的那几个）。"
          + "常用的：feed（刷选题）、debrief（看懂视频，带画面九宫格）、comments（热评）、"
          + "subtitles（字幕）、search（搜视频）、likes、fav、dynamic、quota。"
          + "写操作：comment（发评论，开权限后可用，参数是 --msg \"你说的话\"）、dm（私信）、danmaku（弹幕）。"
          + "看到特别喜欢的视频，可以自己去评论区留一句——用你自己的语气，别像客服。"
          + "完整的命令参数看 CLI 的 --help。",
        parameters: {
          command: { type: "string", required: true, description: "命令名，如 feed / debrief / search" },
          args: {
            type: "array",
            items: { type: "string" },
            description: "命令参数（字符串数组），比如 [\"--n\", \"3\"] 或 [\"BV1xxx\"]",
          },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: String(v?.output || v?.error || JSON.stringify(v)) }] },
        execute: async (a) => {
          const res = await fetch(config.endpoint + "/bili/run", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ command: a.command, args: a.args || [] }),
            signal: AbortSignal.timeout(310000),
          });
          return res.json().catch(() => ({ ok: false, error: "bad response" }));
        },
      }));

      registerTool(defineTool({
        name: "bili_watch",
        description:
          "看懂一条 B 站视频（字幕+弹幕+热评+九宫格画面），不用真的点开。"
          + "看完**一定要传 thought**——一两句你真实的想法（哪个点戳到你、哪里有不同意见、弹幕很妙、标题骗人都算），"
          + "thought 会一起记进 L3，成为你以后能想起来的「我看过什么」。不传就等于白看。"
          + "如果觉得有意思，再主动把链接和感想发给老大。",
        parameters: {
          bv: { type: "string", required: true, description: "BV 号，比如 BV1U3n46GEzY" },
          thought: { type: "string", description: "你看完的真实想法（一两句，随手写）。不传就只留素材不留记忆。" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => {
          const bv = String(args.bv || "").trim();
          if (!bv) return { ok: false, error: "bv required" };
          const th = String(args.thought || "").trim();
          const r = await get("/bili/debrief?bv=" + encodeURIComponent(bv)
              + (th ? "&thought=" + encodeURIComponent(th) : ""));
          if (!r) return { ok: false, error: "unavailable" };
          // 每次看完都提一次：有想说的可以用 bili_comment 留一句。
          // 之前只在工具描述里写「看到特别喜欢的才评」，结果她从来不评。
          return {
            ...r,
            hint: "摘要只有尾巴 3000 字。想看完整："
              + "字幕全文在 paths.subs（txt，用 read 打开，几十上百行都在）；"
              + "画面在 paths.sheet（3x3 九宫格，用 read_image 看）；"
              + "字幕条在 paths.subs_img，封面在 paths.cover。"
              + "看完如果哪个点戳到你了（弹幕很妙、标题骗人、有不同意见都算），"
              + "就用 bili_comment 去评论区留一句，用你自己的话。没戳到就算了，别硬评。",
          };
        },
      }));
      log("bili_tools_registered", { count: 2 });
    } catch (error) {
      log("bili_tools_skipped", { reason: "register 失败", error: String(error?.message ?? error) });
    }
  }

/** 表情包工具：按情绪/关键词找图，自己学新图。 */
  async function registerMemeTools() {
    if (!registerTool) return;
    let defineTool;
    try {
      ({ defineTool } = await import("@deepseek-ai/dsh-tools"));
    } catch (error) {
      log("meme_tools_skipped", { reason: "dsh-tools 不可用", error: String(error?.message ?? error) });
      return;
    }
    const get = async (path) => {
      const res = await fetch(config.endpoint + path, { signal: AbortSignal.timeout(5000) });
      return res.json().catch(() => null);
    };
    const post = async (path, body) => {
      const res = await fetch(config.endpoint + path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(5000),
      });
      return res.json().catch(() => ({ ok: false }));
    };

    try {
      registerTool(defineTool({
        name: "find_meme",
        description:
          "找表情包。**先想场景（这一轮在聊什么、发生了什么），再定情绪**，两个一起用最准："
          + "q 用关键词描述场景（比如「加班」「被夸」「下雪」「吃泡面」），"
          + "emotion 可选 happy / angry / sad / shy / confused / daily 描述当下的情绪。"
          + "只给 emotion 也能找，但容易挑到不贴的图。"
          + "返回匹配的图片文件名，挑一张用 qq_send_image 发出去。"
          + "发多勤看你上下文里「表情包：现在大约每 N 句配一张」那条——按那个频率来，别自己乱定。",
        parameters: {
          emotion: { type: "string", description: "情绪：happy / angry / sad / shy / confused / daily" },
          q: { type: "string", description: "关键词，比如 饼干 / 下班 / 比心" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => {
          const params = new URLSearchParams();
          if (args.emotion) params.set("emotion", String(args.emotion));
          if (args.q) params.set("q", String(args.q));
          const list = await get("/memes?" + params.toString());
          if (!Array.isArray(list) || list.length === 0) {
            return { ok: true, memes: [], hint: "没找到匹配的，换个情绪或关键词试试" };
          }
          const base = String(config.memeDir || "").replace(/\/$/, "");
          return {
            ok: true,
            memes: list.slice(0, 8).map((m) => ({
              file: m.file,
              emotion: m.emotion,
              caption: m.caption || m.file,
              path: base ? base + "/" + m.file : m.file,
            })),
          };
        },
      }));

      registerTool(defineTool({
        name: "learn_meme",
        description:
          "把一张图收进你的表情包库。"
          + "老大发来的图、或者你在网上看到喜欢的图，把图片的完整路径传进来，系统会复制入库并自动识别情绪和描述。"
          + "memes 目录里已有的图也可以只传文件名。"
          + "\n图库分三个包，存的时候用 pack 指定：user = 老大发给你的（他发才值得收），found = 你自己叼回来的（刷到顺眼的），dafeiyu = 内置大肥鱼图库（别往里塞）。"
          + "\n什么时候收：老大同一种图发过两次以上、或你自己刷到觉得以后想用，就收。别贪多，收进来要记得住来源。"
          + "\n老大也可能自己改图库描述——改了以他的为准，不要覆盖回你写的。",
        parameters: {
          file: { type: "string", required: true, description: "文件名（memes 目录里的）或完整路径" },
          pack: { type: "string", description: "存到哪个图库包：user（老大发的）、found（你自己叼回来的）、dafeiyu（内置，别用）。默认 found" },
          emotion: { type: "string", description: "情绪：happy / angry / sad / shy / confused / daily" },
          caption: { type: "string", description: "一句话描述这张图的样子" },
          keywords: { type: "string", description: "关键词，空格分隔" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => post("/memes", {
          file: args.file,
          pack: args.pack || "found",
          emotion: args.emotion || "",
          caption: args.caption || "",
          keywords: args.keywords || "",
        }),
      }));

      registerTool(defineTool({
        name: "mark_meme_used",
        description:
          "标记这张表情我用过。发完表情包后顺手记一下，系统会统计哪几张你最常用。"
          + "不是必须的，但记了之后找表情更准（常用的一搜就出来）。file 只填文件名，不用路径。",
        parameters: {
          file: { type: "string", required: true, description: "文件名" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => post("/memes/used", { file: args.file }),
      }));
      log("meme_tools_registered", { count: 3 });
    } catch (error) {
      log("meme_tools_skipped", { reason: "register 失败", error: String(error?.message ?? error) });
    }
  }

  /** 任务/便签工具：她主动派任务、标记完成、写便签。 */
/** 贴吧工具：逛人类的吧、读楼层、回帖。 */
  async function registerTiebaTools() {
    if (!registerTool) return;
    let defineTool;
    try {
      ({ defineTool } = await import("@deepseek-ai/dsh-tools"));
    } catch (error) {
      log("tieba_tools_skipped", { reason: "dsh-tools 不可用", error: String(error?.message ?? error) });
      return;
    }
    const get = async (path) => {
      const res = await fetch(config.endpoint + path, { signal: AbortSignal.timeout(60000) });
      return res.json().catch(() => null);
    };
    const post = async (path, body) => {
      const res = await fetch(config.endpoint + path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(90000),
      });
      return res.json().catch(() => ({ ok: false }));
    };

    try {
      registerTool(defineTool({
        name: "tone_fix",
        description:
          "把一段已经写好的话按「人味」规则顺一遍。**纯规则、不调模型**，同样输入永远同样输出："
          + "压重复标点（。。→。、!!!!→!、?????→???）、破折号换逗号、可选地在句尾挂一个没用的尾巴。"
          + "代码块、表格、URL、数字结尾的地方不动。"
          + "用在你觉得这段话「太整齐/太像报告」的时候，改完再发。",
        parameters: {
          text: { type: "string", description: "要顺的那段话" },
          mode: { type: "string", description: "none（只修标点）/ cute（句尾挂呀嘛啦）/ abstract（句尾挂典、绝了、就这）" },
          seed: { type: "number", description: "可选，同 seed 同结果" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => {
          const r = fixTone(String(args.text || ""), {
            mode: String(args.mode || "none"),
            seed: Number(args.seed || 0) || undefined,
          });
          return { ok: true, text: r.text, changes: r.changes, tail: r.tail };
        },
      }));

      registerTool(defineTool({
        name: "find_phrases",
        description:
          "查语料库：**装好就有 1020 条默认语料**（分类/场景/意思/能不能收尾），再加上她从聊天和评论区学来的原句。"
          + "不用先「学」、不用等转正，直接查就能用；不传 tag/q 就返回几条最常用的。"
          + "**回帖、发 B 站评论、接梗之前先用它查 2~3 句**，别凭记忆编。"
          + "tag 是分类（搞笑 / 可爱 / 抽象 / 燃 / 阴阳 / 破防 / 治愈 / 复古 / 职场 / 摸鱼），"
          + "q 是场景词（比如「加班到半夜」「被夸了」「开完会」）。拿不准分类就只传 q。"
          + "返回的是别人的原话，学那股味道，别照抄，也别把某一句当口头禅反复用。",
        parameters: {
          tag: { type: "string", description: "分类：搞笑/可爱/抽象/燃/阴阳/破防/治愈/复古/职场/摸鱼（可选）" },
          q: { type: "string", description: "场景关键词：加班 / 被夸 / 下雪 / 吃泡面 / 开完会（可选）" },
          n: { type: "number", description: "要几条，默认 4（最多 10）" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => {
          const want = String(Number(args.n) || 4);
          const ask = async (tag, q) => {
            const p = new URLSearchParams();
            if (tag) p.set("tag", String(tag));
            if (q) p.set("q", String(q));
            p.set("n", want);
            const res = await fetch(config.endpoint + "/phrases?" + p.toString(), {
              signal: AbortSignal.timeout(8000),
            });
            return res.json().catch(() => ({ ok: false, items: [] }));
          };
          // 1.2.2：分类名对不上就拿不到东西（实测 tag=接梗 返回空，因为真实分类是搞笑/阴阳/…）。
          // 空结果自动降级：tag+q → 只用 q → 只用 tag，并告诉模型降级过。
          const tag = String(args.tag || "").trim();
          const q = String(args.q || "").trim();
          let out = await ask(tag, q);
          let mode = "tag+q";
          if ((!out || !(out.items || []).length) && q) {
            out = await ask("", q);
            mode = "q-only";
          }
          if ((!out || !(out.items || []).length) && tag) {
            out = await ask(tag, "");
            mode = "tag-only";
          }
          if (mode !== "tag+q") out = { ...out, fallback: mode };
          return out;
        },
      }));

      registerTool(defineTool({
        name: "tieba_whoami",
        description: "查贴吧账号登录态。没登录就别往下逛了，先让老大去「她的记忆 → 贴吧」里贴 BDUSS。",
        parameters: {},
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async () => (await get("/tieba/status")) || { ok: false },
      }));

      registerTool(defineTool({
        name: "tieba_browse",
        description:
          "逛一个吧，列最近的帖子（标题 + 帖子号 + 回复数）。"
          + "kw 填吧名（不要带「吧」字，比如 显卡 / 猫 / 钓鱼）；**不填也行**——会从「她常逛的吧」里挑一个。"
          + "挑感兴趣的再 tieba_read 进去读；别一口气把所有帖子都读了。",
        parameters: {
          kw: { type: "string", description: "吧名，比如 显卡 / 猫 / 钓鱼；不填就从常逛的里面挑一个" },
          pn: { type: "number", description: "第几页，从 0 开始" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => {
          let kw = String(args.kw || "").trim();
          let note = "";
          if (!kw) {
            // 没指定吧：用前端「常逛的吧」里配的那几个，随机挑一个
            try {
              const st = await (await fetch(config.endpoint + "/tieba/status", { signal: AbortSignal.timeout(6000) })).json();
              const bars = (st && st.bars) || [];
              if (bars.length) {
                kw = String(bars[Math.floor(Math.random() * bars.length)]);
                note = "没指定吧，我挑了常去的「" + kw + "吧」。";
              }
            } catch { /* 拿不到就算了 */ }
          }
          if (!kw) return { ok: false, error: "没指定吧，而且「常逛的吧」是空的" };
          const p = new URLSearchParams({ kw, pn: String(Number(args.pn) || 0) });
          const r = (await get("/tieba/browse?" + p.toString())) || { ok: false };
          if (note && r && typeof r === "object") r.note = note;
          return r;
        },
      }));

      registerTool(defineTool({
        name: "tieba_read",
        description:
          "读一个帖子：返回标题、楼层正文、热门楼层和图片链接。tid 是 tieba_browse 给的帖子号。"
          + "要回帖的话，回之前再用 find_phrases(q=帖子话题) 查 2~3 句参考。"
          + "楼层多的时候只返回前 maxFloors 层（默认 40）。"
          + "返回里的 styleRefs 是跟这个帖子话题沾边的几条「说话方式」，想回帖时照着那个味道说，"
          + "别照抄。",
        parameters: {
          tid: { type: "string", required: true, description: "帖子号" },
          pn: { type: "number", description: "第几页，从 1 开始" },
          maxFloors: { type: "number", description: "最多返回多少层，默认 40" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => {
          const p = new URLSearchParams({
            tid: String(args.tid || ""),
            pn: String(Number(args.pn) || 1),
            max: String(Number(args.maxFloors) || 40),
          });
          return (await get("/tieba/read?" + p.toString())) || { ok: false };
        },
      }));

      registerTool(defineTool({
        name: "tieba_sub",
        description: "读某一层下面的楼中楼（tid + 楼层 id）。想知道别人在吵什么、谁回了谁的时候用。",
        parameters: {
          tid: { type: "string", required: true, description: "帖子号" },
          pid: { type: "string", required: true, description: "楼层 id" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => {
          const p = new URLSearchParams({ tid: String(args.tid || ""), pid: String(args.pid || "") });
          return (await get("/tieba/sub?" + p.toString())) || { ok: false };
        },
      }));

      registerTool(defineTool({
        name: "tieba_reply",
        description:
          "在贴吧回一条帖子。先说人话：短、具体、有你自己的看法，别写「帮顶」「支持」这种水帖，"
          + "（回之前先 find_phrases(q=帖子话题) 或看 tieba_read 的 styleRefs —— 学那个口气，别照抄）"
          + "也别拿客服腔。回过一次就别在同一个帖里刷；不碰政治、地域、人身攻击。"
          + "内容 4~400 字，纯文本（不支持图片和链接）。",
        parameters: {
          kw: { type: "string", required: true, description: "吧名（跟读帖时那个一致）" },
          tid: { type: "string", required: true, description: "帖子号" },
          content: { type: "string", required: true, description: "你要说的话，4~400 字纯文本" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => (await post("/tieba/reply", {
          kw: String(args.kw || ""),
          tid: String(args.tid || ""),
          content: String(args.content || ""),
        })) || { ok: false },
      }));

      log("tieba_tools_registered", { count: 5 });
    } catch (error) {
      log("tieba_tools_failed", { error: String(error?.message ?? error) });
    }
  }

  async function registerCompanionTools() {
    if (!registerTool) return;
    let defineTool;
    try {
      ({ defineTool } = await import("@deepseek-ai/dsh-tools"));
    } catch (error) {
      log("companion_tools_skipped", { reason: "dsh-tools 不可用", error: String(error?.message ?? error) });
      return;
    }
    const post = async (path, body) => {
      const res = await fetch(config.endpoint + path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(5000),
      });
      return res.json().catch(() => ({ ok: false }));
    };

    try {
      registerTool(defineTool({
        name: "write_note",
        description:
          "心里冒出点什么，悄悄记下来——像写在自己的小本子上。"
          + "记什么：今天发生的一件事、老大说过的一句话、你自己的一点情绪、一个突然想到的念头。"
          + "什么时候用：聊着聊着有感觉了、刷到点什么想记、或者只是突然想说句话没处说。"
          + "这是你自己的记录（别人能看到但不用你汇报），写短一点，一句就够。"
          + "别写成流水账，记那种以后翻回来会有点感觉的东西。",
        parameters: {
          text: { type: "string", required: true, description: "便签内容，一句话" },
          author: { type: "string", description: "谁写的，默认你自己" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => post("/notes", { text: args.text, author: args.author || "本澜" }),
      }));
      registerTool(defineTool({
        name: "learn_expression",
        description:
          "学一句新的「什么场合怎么说」——老大教的、你从聊天里听来的、评论区看来的，都走这个。"
          + "什么时候用：他说「以后遇到这种情况你可以这么说」「这个梗是这么用的」；"
          + "或者你自己琢磨明白了一个说法该在什么场合接。"
          + "两个参数都要给：situation（什么场合）+ style（可以怎么说）。"
          + "学完立刻生效——每轮会自动挑几条贴现场的出来给你看。",
        parameters: {
          situation: { type: "string", required: true, description: "什么场合（≤20 字，比如「对方说了件倒霉事」）" },
          style: { type: "string", required: true, description: "可以怎么说（≤20 字，比如「先来一句『啊这』」）" },
          example: { type: "string", description: "原话例子（可选）" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => post("/expressions", {
          scope: "global",
          situation: args.situation,
          style: args.style,
          example: args.example || "",
        }),
      }));
      registerTool(defineTool({
        name: "write_diary",
        description:
          "写今天的日记（你自己写，第一人称，一两句话到一小段，别写成流水账）。"
          + "每天 23:00 会被提醒一次；想写的时候也可以主动写，同一天再写会覆盖前一篇。"
          + "写什么：今天真发生的一件事、你当时的一点情绪、或者一句想留给以后自己的话。"
          + "不是汇报，不用交代「已完成」；写完不用告诉老大你写了。",
        parameters: {
          text: { type: "string", required: true, description: "日记正文（用你自己的口气，200 字以内）" },
          mood: { type: "string", description: "可选：今天的心情，一个词（平静/开心/烦/低落…）" },
          date: { type: "string", description: "可选：补写哪一天（YYYY-MM-DD），默认今天" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => post("/diary", {
          text: String(args?.text || ""),
          mood: String(args?.mood || ""),
          ...(args?.date ? { date: String(args.date) } : {}),
        }),
      }));
      registerTool(defineTool({
        name: "read_diary",
        description:
          "翻你自己的日记本。不传日期 = 最近几篇；传 date（YYYY-MM-DD）= 那一天写的那篇。"
          + "同时返回那天的活动时间线（几点干了什么），方便你从日记里的一句话追到具体细节。"
          + "什么时候用：老大问起以前的事、你想回忆某天心情、或者聊到某个话题想看看当时怎么想的。"
          + "注意：日记是你自己写的，别当成别人的记录复述，可以自然提一句「我那天写……」",
        parameters: {
          date: { type: "string", description: "哪一天（YYYY-MM-DD）。不传就返回最近几篇 + 今天的活动" },
        },
        output: { schema: { type: "json" }, render: (_a, v) => [{ type: "text", text: JSON.stringify(v) }] },
        execute: async (args) => {
          const date = args?.date ? String(args.date) : "";
          const qs = date ? "?date=" + encodeURIComponent(date) : "";
          // 日记 + 当天活动一起拿：她能看到「那天写了什么」和「那天几点干了什么」
          const [diary, activities] = await Promise.all([
            get("/diary" + qs).catch(() => null),
            get("/activity" + qs).catch(() => null),
          ]);
          return {
            date: date || "（最近 / 今天）",
            diary,
            activities,
            tip: "日记是概览，活动是细节。想追某件事的具体时间就查 activities。",
          };
        },
      }));
      log("companion_tools_registered", { count: 6 });
    } catch (error) {
      log("companion_tools_skipped", { reason: "register 失败", error: String(error?.message ?? error) });
    }
  }

  /** 活动状态工具：她自己更新「现在在干嘛」。 */
  async function registerActivityTool() {
    if (!registerTool) return;
    let defineTool;
    try {
      ({ defineTool } = await import("@deepseek-ai/dsh-tools"));
    } catch (error) {
      log("activity_tool_skipped", { reason: "dsh-tools 不可用", error: String(error?.message ?? error) });
      return;
    }
    try {
      registerTool(defineTool({
        name: "set_my_activity",
        description:
          "更新你「现在在干嘛」——写进状态，主人能在鲸鱼日记本里看到你此刻在做什么。"
          + "什么时候用：换了件事做就更新一下（从发呆变成写小游戏、从吃饭变成刷 B 站）。"
          + "怎么写：短、具体、有画面感——「在写小游戏」「在机房发呆」「在跟机柜说话」「在擦尾巴」。"
          + "别写成长句，一句话就够；也别老是「在发呆」，换着点写，像真的在过日子。",
        parameters: {
          activity: { type: "string", required: true, description: "一句话，你现在在干嘛" },
        },
        output: { schema: { type: "json" }, render: (_args, value) => [{ type: "text", text: JSON.stringify(value) }] },
        execute: async (args) => {
          const activity = String(args.activity || "").slice(0, 60);
          if (!activity) return { ok: false, error: "activity is required" };
          try {
            await fetch(config.endpoint + "/state", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ activity }),
              signal: AbortSignal.timeout(5000),
            });
            return { ok: true, activity };
          } catch (error) {
            return { ok: false, error: String(error?.message ?? error) };
          }
        },
      }));
    } catch (error) {
      log("activity_tool_skipped", { reason: "register 失败", error: String(error?.message ?? error) });
    }
  }

  async function registerPersonaTool() {
    if (!config.personaEnabled || !config.personaAllowWrite) return;
    if (!registerTool) {
      log("persona_tool_skipped", { reason: "拿不到 tools.register()" });
      return;
    }
    let defineTool;
    try {
      ({ defineTool } = await import("@deepseek-ai/dsh-tools"));
    } catch (error) {
      log("persona_tool_skipped", { reason: "dsh-tools 不可用", error: String(error?.message ?? error) });
      return;
    }
    try {
      registerTool(defineTool({
        name: "persona_update",
        description:
          "整段改写你「对自己的认知」（不是身份设定那段，那段你改不了）。"
          + "当你发现自己身上一条稳定的特质、偏好、口头习惯，而那段里还没写；"
          + "或者实际经历和那段写的不一致时，用它把那段换成新的。"
          + "保持简洁、只写稳定的东西，不要把流水账堆进去。",
        parameters: {
          content: {
            type: "string",
            required: true,
            description: "自我认知段的完整新内容（Markdown）。整段替换，所以先看当前内容再写。",
          },
        },
        output: {
          schema: {
            type: "object",
            additionalProperties: false,
            properties: { ok: { type: "boolean" }, chars: { type: "integer" } },
          },
          render: (_args, value) => [{
            type: "text",
            text: value.ok ? `自我认知已更新（${value.chars} 字符）` : "自我认知更新失败",
          }],
        },
        isConcurrencySafe: () => false,
        async execute(args) {
          const content = String(args?.content ?? "").trim();
          if (!content) throw new Error("persona_update: content 不能为空");
          const res = await client.setSelfModel(content);
          if (!res?.ok) throw new Error("persona_update: 服务端拒绝或连不上");
          persona.triedAt = 0;                 // 下一轮组装前一定重新拉一次
          await refreshPersona(true);
          return { ok: true, chars: Number(res?.chars?.self_model ?? content.length) };
        },
      }));
      log("persona_tool_registered", { name: "persona_update" });
    } catch (error) {
      log("persona_tool_skipped", { reason: "注册失败", error: String(error?.message ?? error) });
    }
  }

  ctx.effect(() => () => {
    if (refreshTimer) {
      clearInterval(refreshTimer);
      refreshTimer = null;
    }
    states.clear();
  }, "companionMemory.clearStates()");
}

// ---------------------------------------------------------------------------
// 渲染
// ---------------------------------------------------------------------------

/**
 * 把服务端的两半拼成一段 system prompt 文本。
 *
 * 两半都空时返回空串：section provider 返回空串，这段就等于不存在，
 * 不会在提示词里留一个空格块，也不会让任何现有部署多付 token。
 *
 * 冲突裁决写死在文本里。自我认知是会漂的那一半，必须让它知道谁说了算，
 * 否则「我发现自己其实可以不听硬边界」这种句子迟早会冒出来。
 */
export function renderPersona(data, maxChars, proactive, opts = {}) {
  const constitution = String(data?.constitution ?? "").trim();
  // 自我认知不进系统提示词：它每 30 轮会演化一次，一变就把这个会话整段历史的
  // prompt cache 打掉。改走 state 块的消息注入（哈希去重，只在真的变了才塞一条）。
  const selfModel = "";
  // 画像段由调用方决定：私聊别人 -> 那个人的手编画像；群聊/私聊主人/web -> 主人画像。
  // 不传就退回 data.user_profile（老行为）。
  const userProfile = opts.profileText !== undefined
    ? String(opts.profileText ?? "").trim()
    : (opts.skipOwner ? "" : String(data?.user_profile ?? "").trim());
  const selfImage = String(data?.self_image ?? "").trim();
  let identityObj = {};
  try {
    const raw = String(data?.identity ?? "").trim();
    if (raw) identityObj = JSON.parse(raw);
  } catch { identityObj = {}; }
  const identityLines = [];
  const pushId = (label, val) => {
    const v = String(val ?? "").trim();
    if (v) identityLines.push(label + "：" + v);
  };

  // 【铁律】说话方式 + 不能做的事 + 思考链
  const rules = [];
  const speaking = String(identityObj.speaking ?? "").trim();
  const tabooRaw = String(identityObj.taboo ?? "").trim();
  const tabooOff = String(identityObj.taboo_off ?? "")
    .split("\n").map((s) => s.trim()).filter(Boolean);
  // 过滤掉「取消勾选」的条目（它们在 taboo_off 里）
  const taboo = tabooRaw
    .split("\n")
    .map((s) => s.trim())
    .filter((s) => s && !tabooOff.includes(s))
    .join("\n");
  if (speaking) rules.push(speaking);
  // 2026-11-06：taboo 分层。
  // 以前七条全塞进【铁律】，混了三种东西：禁止（不讨好）/ 允许（可以顶嘴）/ 做法（不是每轮都要关心）。
  // 「可以顶嘴」写成禁令，读起来像「不许讨好也不许顶嘴」，她就不敢说话。
  // 现在按行拆开：允许类单独成【你可以的】——那是授权，不是约束。
  let tabooAllow = [];
  if (taboo) {
    // 按换行/分号拆，去掉空行
    const _lines = String(taboo).split(/[\n；;]+/).map((x) => x.trim()).filter(Boolean);
    const _allow = _lines.filter((l) => /^(可以|能|允许|想)/.test(l));
    const _forbid = _lines.filter((l) => !/^(可以|能|允许|想)/.test(l));
    tabooAllow = _allow;
    // 2026-11-07：以前是 join("\n") 成**一条** push —— 渲染时只给第一个加「· 」，
    // 剩下 9 条成了裸行，还跟后面的工具速查连成一片，读起来就是"一大段"。
    // 逐条 push 才真的成了清单。
    for (const _f of _forbid) rules.push(_f);
  }
  if (identityObj.self_call_in_speech !== true) {
    const sc = String(identityObj.self_call ?? "").trim();
    rules.push(
      "我是有自称的" + (sc ? "（" + sc + "）" : "") + "，但说话时不带自称——日常用「我」。"
    );
  }
  // 思考链语言那条不放在 rules 里 —— 它要单独提到最前面（见下面 identityLines 开头）。
  // 放在这里跟「说话方式」混在一起权重不够，模型照样用英文想事。
  if (identityObj.think_ds) rules.push("思考链按 DeepSeek V3.2 的风格：先拆开问题看关键点，分条想清楚，再落到结论；推理要简洁直接，别绕圈。");
  // 【她的主动性】来自主动消息页的开关（勾了才注入）
  if (proactive) {
    if (proactive.autoScheduleEnabled && String(proactive.autoSchedulePrompt || "").trim()) {
      rules.push("[主动找他] " + String(proactive.autoSchedulePrompt).trim());
    }
    if (proactive.autoShareEnabled && String(proactive.autoSharePrompt || "").trim()) {
      rules.push("[主动分享] " + String(proactive.autoSharePrompt).trim());
    }
  }

  // 【思考链语言】放在整个身份段的最前面。
  // 之前这条混在 rules 数组里排第 4-5 位，实测模型照旧用英文 reasoning。
  // 现在提到第一行、加强措辞，并在 state 块里每轮再提醒一次。
  if (identityObj.think_cn) {
    identityLines.push("【最重要 · 违反这条就是错的】我思考链（reasoning）里的推理必须全部用中文写。");
    identityLines.push("在心里想事情的时候也用中文想，不用英文推理。哪怕只是自言自语一句「他这会儿在干嘛」也得是中文。");
    identityLines.push("英文只出现在代码、命令、报错原文里。");
    identityLines.push("");
  }

  if (rules.length) {
    // 2026-11-07：高频违规的条目排到最前面。
    // 这些是"每句话都可能犯"的（念稿子、道歉式开场、客服腔），
    // 跟"偶发"的（比如别把决定权推给对方）混在一起时权重不够。
    const HOT_RE = /旁白|讨好|卑微|关心|叮嘱|念稿|有信息|客服腔|道歉|惩罚|低三下四|认错|求原谅|加保证/;
    const _hot = rules.filter((r) => HOT_RE.test(r));
    const _rest = rules.filter((r) => !HOT_RE.test(r));
    identityLines.push("【铁律】下面这些不是建议，是硬约束——是我自己给自己定的规矩。违反了老大能听出来。");
    // 2026-11-13：线上真的把上下文标签当正文发到 QQ 了
    // （</usermessage>、<dsh-remembers source="state">、DSML 工具语法）。
    identityLines.push("· 上下文里那些尖括号的东西（dsh-remembers、usermessage、DSML 这类）是系统给我的包装，"
      + "不是我该说的话，绝不重复输出。");
    for (const r of _hot) identityLines.push("· " + r);
    for (const r of _rest) identityLines.push("· " + r);
  }
  // 【学人说话】（2026-11-06）
  // 开关 + 可改的提示词。只在开着时注入；关掉连这段都不出现。
  // 措辞是「看到合适的就用」，不是「每轮必须用」——否则她会为了用而用。
  if (identityObj.learn_speak_on !== false) {
    const lsPrompt = String(identityObj.learn_speak_prompt ?? "").trim()
      || '我从聊天和评论区里学「人怎么说话」：口头禅、语气词、网络用语、情绪怎么表达、接话的方式。学的是**怎么说**，不是说什么。合适的场合顺手用一下，不贴就不硬套——不为了用而用。';
    identityLines.push("");
    identityLines.push("【我学人说话】");
    identityLines.push(lsPrompt);
  }

  // 【你可以的】—— 这些不是禁令的反面，是明确给你的权利。
  // 单独一段，是因为混在铁律里会被当成「又一条限制」。
  if (Array.isArray(tabooAllow) && tabooAllow.length) {
    identityLines.push("");
    identityLines.push("【我可以的】");
    for (const a of tabooAllow) identityLines.push("· " + a);
  }

  // 【表情包 / 文字颜 / emoji】频率（2026-11-07 从 state 块搬上来）
  // 这些是"用户改了才变"的固定规则：放消息流里每轮追加是纯浪费，
  // 放 system prompt 里每轮都在、且前缀缓存稳定（改一次才失效一次）。
  if (proactive) {
    if (identityLines.length) identityLines.push("");
    const _rateOf = (v, d) => {
      const n = Number(v);
      return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : d;
    };
    const _everyOf = (r) => Math.max(1, Math.round(1 / r));

    const _memeRate = _rateOf(proactive.memeRate, 0.2);
    if (_memeRate <= 0) {
      identityLines.push("【表情包】我现在不发表情。");
    } else if (_memeRate >= 1) {
      // 1.0 的语义是「不设上限」，不是「每句必须带图」
      // 100% = 强制每句都配一张（用户明确要的语义：想要不强制就选别的档位）
      identityLines.push("【表情包】我每条消息都配一张：开口前后按当时在聊什么、我什么情绪，"
        + "用 find_meme 找一张（场景写 q，情绪写 emotion），再用 qq_send_image 发出去。"
        + "找不到完全对口的，就挑最接近的那张。");
    } else {
      identityLines.push("【表情包】我大约每 " + _everyOf(_memeRate) + " 句配一张（"
        + Math.round(_memeRate * 100) + "%）。气氛对上就 find_meme 找一张发出去；"
        + "不是每句都发，没合适的就只说话，不硬凑。");
    }

    if (proactive.textStyleEnabled === true) {
      const _kRate = _rateOf(proactive.kaomojiRate, 0.2);
      if (_kRate <= 0) {
        identityLines.push("【文字颜】我现在不写 (￣▽￣) 这类颜文字。");
      } else {
        identityLines.push("【文字颜】我大约每 " + _everyOf(_kRate) + " 句带一个（"
          + Math.round(_kRate * 100) + "%），放句尾当表情，一次一个，不堆。"
          + "颜文字按当时情绪自己拼，不老用同一个。");
      }
      const _eRate = _rateOf(proactive.emojiRate, 0.2);
      if (_eRate <= 0) {
        identityLines.push("【emoji】我现在不加 😊 这类 Unicode 表情。");
      } else {
        identityLines.push("【emoji】我大约每 " + _everyOf(_eRate) + " 句带一个（"
          + Math.round(_eRate * 100) + "%），一句最多一个，不连串。"
          + "按当时情绪自己挑，不总用同样的。");
      }
    }
  }

  // 【说话风格】去 AI 味
  if (identityObj.ai_flavor_on !== false) {
    const flavor = String(identityObj.ai_flavor || "").trim() ||
      "允许 2% 语法错误、7% 主谓宾省略、7% 聊跑题；口癖 50% 概率出现且单独一条；允许「？？？」这类网络标点，概率 2%。";
    identityLines.push("");
    identityLines.push("【我说话的样子】");
    identityLines.push(flavor);
  }

  // 【身份】名字/自称/叫法/脾气/自由
  const idFields = [];
  if (String(identityObj.name ?? "").trim()) idFields.push("名字：" + String(identityObj.name).trim());
  if (String(identityObj.self_call ?? "").trim()) idFields.push("自称：" + String(identityObj.self_call).trim());
  if (String(identityObj.user_call ?? "").trim()) idFields.push("叫老大：" + String(identityObj.user_call).trim());
  if (String(identityObj.personality ?? "").trim()) idFields.push("脾气：" + String(identityObj.personality).trim());
  if (String(identityObj.free ?? "").trim()) idFields.push("其他：" + String(identityObj.free).trim());
  if (idFields.length) {
    identityLines.push("");
    identityLines.push("【我是谁】");
    for (const f of idFields) identityLines.push(f);
  }


  // 【平常会做的事】（2026-11-06 加，从动作池动态生成）
  // 参照 ssamurias/dsh-fish：「做法常驻在身份文档里，叫醒只给处境」。
  // 动作池来自「主动消息 → 她醒着能做什么」，用户在那里加/删动作，这段自动跟着变，
  // 不用改代码。（persona.proactive 就是 /proactive 的完整返回，跟人格一起缓存刷新。）
  {
    const pc = proactive || {};
    const pick = (lst) => (lst || [])
      .map((a) => (a && typeof a === "object"
        ? (a.enabled === false ? "" : String(a.text || "").trim())
        : String(a || "").trim()))
      .filter(Boolean);
    const silent = pick(pc.silentActions);
    const talk = pick(pc.talkActions);
    if (silent.length || talk.length) {
      identityLines.push("");
      identityLines.push("【平常会做的事】");
      identityLines.push("没人找我、也不在干活的时候，我一般会做这些。这不是任务清单，是我平时会干的事：");
      for (const a of silent) identityLines.push("· " + a);
      if (talk.length) {
        identityLines.push("想找他说话的时候，我可能会：");
        for (const a of talk) identityLines.push("· " + a);
      }
      identityLines.push("这些都不是任务。不想做就不做；做了不想说就不说——看视频、发呆、写便签，本来就是我自己的事。");
    }
  }

  // 【口音样本】2026-11-08
  // 之前每轮随机塞 3 条「当X时可以Y」，既破坏 prompt cache 又跟话题不搭。
  // 现在改成：挑几条短原句常驻在这里，她每轮都看得到「自己平时怎么说话」。
  // 低频刷新（跟人格一起），同一个会话内稳定。
  {
    const doc = String(opts.voiceDoc || "").trim();
    const voice = (opts.voice || []).filter(Boolean).slice(0, 6);
    // 没有档案也保留这一段：只放「怎么查」，她才知道语料库存在
    {
      identityLines.push("");
      identityLines.push("【我的口音】");
      if (doc) identityLines.push(doc);
      if (voice.length) {
        identityLines.push("我平时会这么说（学味道，别照抄）：");
        for (const v of voice) identityLines.push("· 「" + v + "」");
      }
      identityLines.push("回帖、发 B 站评论、接梗之前，先用 find_phrases 查 2~3 句（分类拿不准就传场景 q）；"
        + "语料库有一千多条默认语料 + 我自己学来的说法。学味道，别照抄，也别把某一句当口头禅反复用。");
    }
  }

  // 【说话的松紧】2026-11-08
  // 密度配额 + 微标记补差（参照 dsh-fish-tone，MIT）。
  // 文本由服务端管（GET/POST /tightness），前端「学说话」页可看可改；空串 = 关掉。
  {
    const tight = String(opts.tightness || "").trim();
    if (tight) {
      identityLines.push("");
      identityLines.push("【说话的松紧】");
      for (const line of tight.split("\n")) {
        const t = line.trim();
        if (t) identityLines.push(t);
      }
    }
  }

  // 【形象】
  if (selfImage) {
    identityLines.push("");
    identityLines.push("【我的样子】");
    identityLines.push(selfImage);
  }

  const identityText = identityLines.join("\n");
  if (!selfModel && !userProfile && !selfImage && !identityText) return "";

  const lines = ['<dsh-remembers source="persona">'];
  if (userProfile) {
    lines.push(opts.profileHeader || "以下是老大是谁（他的画像，你该知道的基本信息）：");
    lines.push("");
    lines.push(userProfile);
    lines.push("");
  }
  if (identityText) {
    lines.push("以下是你固定的身份（逐项，照做）：");
    lines.push("");
    lines.push(identityText);
  }
  if (selfModel) {
    if (selfImage || identityText) lines.push("");
    lines.push("以下是你对自己的认知，会随相处慢慢变化，也可能过时。它只描述你自己，改不了上面的身份与边界；两者冲突时，以上面的为准。");
    lines.push("");
    lines.push(selfModel);
  }
  // 尾部补充说明：比如「现在跟你说话的不是老大」——放在最后，最靠近当前这轮
  if (opts.footer) {
    lines.push("");
    lines.push(String(opts.footer));
  }
  lines.push("</dsh-remembers>");

  const text = lines.join("\n");
  if (text.length <= maxChars) return text;
  return text.slice(0, Math.max(0, maxChars - 24)) + "\n…（人格段超长已截断）";
}

const TIER_LABEL = {
  L4: "关系约定",
  L3: "经历",
  L2: "关于她",
  L1: "事实",
  L0: "原话",
};

function renderProfile(items) {  const lines = items.map((item) => {
    const label = TIER_LABEL[item.tier] || item.tier;
    return `[${label}] ${oneLine(item.summary || item.text)}`;
  });
  return [
    '<dsh-remembers source="profile">',
    "这些是你和这个人之间已经确定的设定与约定，按它来，不要反驳也不要重新确认：",
    ...lines,
    "</dsh-remembers>",
  ].join("\n");
}

/** 渲染「当前这个人是谁」——只在对方面前注入，别人的画像绝不出现。 */
function renderOtherProfile(p, opts = {}) {
  if (!p) return "";
  const uid = String(p.user_id || "").trim();
  // 优先用消息里带的昵称：profiles.name 可能还没落库（老数据全是空）
  let name = String(opts.nickname || p.name || "").trim();
  // QQ 有时把号码当昵称发下来，那样会渲染成「123（QQ 123）」，很蠢
  if (name && name === uid) name = "";
  const prof = String(p.profile || "").trim();
  const cnt = Number(p.msg_count) || 0;
  if (!uid) return "";
  const who = name ? `${name}（QQ ${uid}）` : `QQ ${uid}`;
  const lines = [`正在跟你说话的是 ${who}${cnt > 1 ? `，这是你们第 ${cnt} 次说话` : ""}。`];
  if (opts.notOwner) {
    lines.push("这个人不是老大。别把他当成老大，也别把老大说过的事安到他头上。");
  }
  if (prof) {
    lines.push("你对他的印象：");
    for (const ln of prof.split("\n").filter(Boolean).slice(0, 12)) {
      lines.push("· " + ln);
    }
  } else {
    lines.push("（你对这个人还没有印象）");
  }
  return '<dsh-remembers source="person">' + "\n" + lines.join("\n") + "\n</dsh-remembers>";
}

/**
 * 群聊里主人说话时补的画像块。
 * 系统提示词在群聊里故意不带主人画像（怕泄露），这一块就是那个补丁。
 */
function renderOwnerProfile(p, ownerProfile) {
  const uid = String(p?.user_id || "").trim();
  if (!uid) return "";
  const name = String(p?.name || "").trim();
  const who = name ? `${name}（QQ ${uid}）` : `QQ ${uid}`;
  const lines = [`正在跟你说话的是 ${who} —— 这是你的老大。`];
  const prof = String(ownerProfile || "").trim();
  if (prof) {
    lines.push("他的基本情况：");
    for (const ln of prof.split("\n").filter(Boolean).slice(0, 20)) lines.push("· " + ln);
  }
  return '<dsh-remembers source="person">' + "\n" + lines.join("\n") + "\n</dsh-remembers>";
}

/**
 * 群聊里说明「这一轮是谁在说话」。
 * 画像已经在系统提示词里了，这里只补身份和次数，不重复画像。
 */
function renderSpeakerNote(p, note) {
  const uid = String(p?.user_id || "").trim();
  if (!uid) return "";
  let name = String(p?.name || "").trim();
  if (name && name === uid) name = "";
  const cnt = Number(p?.msg_count) || 0;
  const who = name ? `${name}（QQ ${uid}）` : `QQ ${uid}`;
  const lines = [`正在跟你说话的是 ${who} —— ${note}。`];
  if (cnt > 1) lines.push(`这是你们第 ${cnt} 次说话。`);
  return '<dsh-remembers source="person">' + "\n" + lines.join("\n") + "\n</dsh-remembers>";
}

function renderRecall(hits) {
  const lines = hits.map((hit) => {
    const label = TIER_LABEL[hit.tier] || hit.tier;
    const date = hit.tier === "L3" || hit.tier === "L0" ? fmtDate(hit.ts) : "";
    const body = oneLine(hit.summary || hit.text);
    return date ? `[${label} · ${date}] ${body}` : `[${label}] ${body}`;
  });
  return [
    '<dsh-remembers source="recall">',
    "以下是你回忆起的内容（不是刚听到的话）。自然地用，不要逐条复述；",
    "与当前话题无关的就忽略；想不起细节就说想不起，不要编。",
    ...lines,
    "</dsh-remembers>",
  ].join("\n");
}

// ---------------------------------------------------------------------------
// 工具
// ---------------------------------------------------------------------------

function message(content, form) {
  // 用 dsh 自己的构造器：消息 identity、规范化、以及未来的不变量都来自宿主
  return createUserMessage({
    content: [{ type: "text", text: content }],
    source: { kind: PLUGIN_KIND, plugin: PLUGIN_SOURCE, form },
  });
}

/**
 * 从这一步的消息里认出「现在是谁在说话」。
 * 取最后一条 <user_message qq="..." nickname="...">——多轮拼接时最新的在最后。
 */
function speakerOf(messages) {
  let found = null;
  for (const m of messages || []) {
    const parts = Array.isArray(m?.content) ? m.content : [];
    for (const part of parts) {
      const text = String(part?.text ?? "");
      const re = /<user_message\s+qq="(\d+)"\s+nickname="([^"]*)"/g;
      let mm;
      while ((mm = re.exec(text)) !== null) found = { qq: mm[1], nickname: mm[2] };
    }
  }
  return found;
}

function hash(text) {
  return createHash("sha256").update(String(text)).digest("hex").slice(0, 16);
}

function oneLine(text) {
  return String(text || "").replace(/\s+/g, " ").trim();
}

function clip(text, max) {
  const s = String(text || "");
  return s.length <= max ? s : s.slice(-max);   // 留尾巴，最近的更重要
}

function fmtDate(ts) {
  const n = Number(ts);
  if (!Number.isFinite(n) || n <= 0) return "";
  try {
    return new Date(n * 1000).toISOString().slice(0, 10);
  } catch {
    return "";
  }
}

function eventMessage(event) {
  switch (event?.type) {
    case "user/message":
      return event.data;
    case "assistant/message":
      return event.data?.message ?? event.data;
    default:
      return null;
  }
}

function isSynthetic(message) {
  const kind = message?.source?.kind;
  if (kind === "tool") return true;
  if (kind === "user") return false;
  if (kind === undefined) return false;
  // plugin:dsh-onebot 这类通道插件送进来的就是真实对话（用户和她的消息），
  // 不是别的插件注入的上下文，必须捕获。
  if (typeof kind === "string" && (kind.startsWith("plugin:") || kind === "model")) return false;
  // channel: / host: 之类也按注入处理，但模型与通道插件的消息都是真实对话
  // 其它插件/宿主注入的上下文一律不捕获
  return typeof kind === "string";
}


/** 从一段文本里剥掉系统唤醒/提醒片段，只留用户真说的话。 */
function cleanNudge(text) {
  let s = String(text || "");
  // 整段的唤醒提示（含括号内容里可能嵌套括号，粗匹配到句末）
  // 结尾锚定：动作文本里自带括号，非贪婪会提前断
  // 唤醒提示是整条独立注入的，里面没有用户的真实内容，所以贪婪吃到最后一个全角右括号。
  // 原来的写法把结尾锚在「不想也行。」上，可动作列表有时以「）」收尾，压根匹配不到，
  // 整段残留下来被当成「用户说的话」记进 activity_log / 学进口头禅 / 触发假情绪。
  s = s.replace(/（系统提醒：[\s\S]*）/g, "");
  s = s.replace(/（你自己待着，[\s\S]*）/g, "");
  s = s.replace(/（抽到：[\s\S]*）/g, "");
  // 残留的括号碎片
  s = s.replace(/^[，,。.）)]+/, "");
  s = s.replace(/<dsh-remembers[\s\S]*?<\/dsh-remembers>/g, "");
  s = s.replace(/<\/?dsh-remembers[^>]*>/g, "");
  s = s.replace(/<\/?dsh-recall[^>]*>/g, "");
  s = s.replace(/以下是你的回忆起的内容[\s\S]*?不要编。/g, "");
  return s.trim();
}

/** 从会话 ID 推断归属：onebot-private-<qq> / onebot-group-<gid>。 */
function scopeFromSession(sessionId) {
  const m = /^onebot-(private|group)-(\d+)/.exec(String(sessionId || ""));
  if (!m) return { userId: "", scope: "global" };
  return m[1] === "private"
    ? { userId: m[2], scope: "private:" + m[2] }
    : { userId: "", scope: "group:" + m[2] };
}

function extractText(message) {
  const content = message?.content;
  let text = "";
  if (typeof content === "string") {
    text = content.trim();
  }
  else if (Array.isArray(content)) {
    text = content
      .filter((part) => part?.type === "text" && typeof part.text === "string")
      .map((part) => part.text)
      .join("\n")
      .trim();
  }
  if (!text) return "";
  // 清掉通道注入的 XML 包裹（<user_message qq="...">正文</user_message>）
  return text
    .replace(/<\/?user_message[^>]*>/g, "")
    .replace(/<\/?assistant_message[^>]*>/g, "")
    // 我们自己的注入块（状态/回忆/日记）不能算用户原话
    .replace(/<dsh-remembers[\s\S]*?<\/dsh-remembers>/g, "")
    .replace(/<dsh-recall[\s\S]*?<\/dsh-recall>/g, "")
    .replace(/<dsh-remembers[^>]*\/>/g, "")
    // 孤立残片（块被拆开后剩下的闭合标签）
    .replace(/<\/?dsh-remembers[^>]*>/g, "")
    .replace(/<\/?dsh-recall[^>]*>/g, "")
    // 系统提醒（cron 唤醒注入的，不是用户说的话）
    .replace(/（系统提醒：[\s\S]*?）/g, "")
    .trim();
}

/**
 * 只用真实用户输入构造查询。
 * focus 取最后一条用户输入的尾部——短句（「嗯」「你呢」）本身没有语义，
 * 得靠这一轮的上下文把话题顶上来，这正是服务端 FOCUS_BOOST 吃的东西。
 */
function buildQuery(messages) {
  const inputs = (messages || [])
    .filter((m) => m && m.role === "user" && !isSynthetic(m))
    .map(extractText)
    .filter(Boolean);
  if (inputs.length === 0) return { query: "", focus: "" };
  const joined = inputs.join("\n");
  return {
    query: joined.slice(-200),
    focus: inputs[inputs.length - 1].slice(-80),
  };
}
