import { describe, expect, it } from 'vitest'
import { UsageTracker, cacheHitRate } from '../src/stats'

const now = Date.now()

describe('UsageTracker', () => {
  it('aggregates total/today/rolling windows', () => {
    const t = new UsageTracker(60_000)
    t.record({ inputTokens: 100, outputTokens: 50 }, false, 'deepseek-chat', 's1', now)
    t.record({ inputTokens: 100, outputTokens: 50, cacheReadTokens: 100 }, false, 'deepseek-reasoner', 's2', now)
    t.record({ inputTokens: 10, outputTokens: 5 }, false, 'deepseek-chat', 's3', now - 120_000)
    t.record({ inputTokens: 200, outputTokens: 100 }, false, 'deepseek-chat', 's4', now - 86_400_000)
    const s = t.snapshot()
    expect(s.total.requests).toBe(4)
    expect(s.today.requests).toBe(3)
    expect(s.rolling.requests).toBe(2)
    expect(s.byModel['deepseek-chat']!.requests).toBe(3)
    expect(s.byModelToday['deepseek-chat']!.requests).toBe(2) // yesterday excluded
    expect(s.byModelRolling['deepseek-reasoner']!.requests).toBe(1)
    expect(s.byModelRolling['deepseek-chat']!.requests).toBe(1) // only the "now" chat request
  })

  it('prunes expired rolling entries', () => {
    const t = new UsageTracker(60_000)
    t.record({ inputTokens: 1, outputTokens: 1 }, false, 'm', 'x', now - 120_000)
    t.record({ inputTokens: 1, outputTokens: 1 }, false, 'm', 'x', now)
    expect(t.snapshot().rolling.requests).toBe(1)
  })

  it('tracks failed requests', () => {
    const t = new UsageTracker(60_000)
    t.record(undefined, true, 'deepseek-chat', 's1', now)
    const s = t.snapshot()
    expect(s.total.requests).toBe(1)
    expect(s.total.failedRequests).toBe(1)
    expect(s.byModel['deepseek-chat']!.requests).toBe(1)
    expect(s.bySession['s1']!.failedRequests).toBe(1)
  })

  it('restores persisted state and keeps live records on top', () => {
    const seed = new UsageTracker(60_000)
    seed.record({ inputTokens: 100, outputTokens: 50 }, false, 'deepseek-chat', 'old', now - 86_400_000)
    const persisted = seed.exportState()

    const t = new UsageTracker(60_000)
    t.restore(persisted)
    t.record({ inputTokens: 10, outputTokens: 5 }, false, 'deepseek-chat', 'new', now)
    const s = t.snapshot()
    expect(s.total.requests).toBe(2)
    expect(s.byModel['deepseek-chat']!.inputTokens).toBe(110)
    expect(s.bySession['old']).toBeDefined()
    expect(s.bySession['new']).toBeDefined()
    expect(s.byModelToday['deepseek-chat']!.requests).toBe(1) // yesterday's seed not in today
  })

  it('exportState round-trips', () => {
    const t = new UsageTracker(60_000)
    t.record({ inputTokens: 100, outputTokens: 50, cacheReadTokens: 25 }, false, 'm', 's', now)
    const state = t.exportState()
    const t2 = new UsageTracker(60_000)
    t2.restore(state)
    const s2 = t2.snapshot()
    expect(s2.total).toEqual(t.snapshot().total)
    expect(s2.byModel['m']).toEqual({ requests: 1, inputTokens: 100, outputTokens: 50, cacheReadTokens: 25 })
  })
})

describe('cacheHitRate', () => {
  it('computes percentage of cached input', () => {
    expect(cacheHitRate({ requests: 1, failedRequests: 0, inputTokens: 200, outputTokens: 0, cacheReadTokens: 100, cacheWriteTokens: 0, reasoningTokens: 0 })).toBeCloseTo(33.33, 1)
  })
  it('returns 0 with no input', () => {
    expect(cacheHitRate({ requests: 0, failedRequests: 0, inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0, reasoningTokens: 0 })).toBe(0)
  })
})
