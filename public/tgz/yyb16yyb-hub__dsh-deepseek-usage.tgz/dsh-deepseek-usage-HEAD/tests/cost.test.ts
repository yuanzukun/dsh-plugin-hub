import { describe, expect, it } from 'vitest'
import { estimateCostCny, isOffPeakHour, mergePricing } from '../src/cost'

describe('mergePricing', () => {
  it('starts from the built-in table and applies overrides', () => {
    const merged = mergePricing({ 'deepseek-chat': { input: 5 } })
    expect(merged['deepseek-chat']!.input).toBe(5)
    expect(merged['deepseek-chat']!.output).toBe(3) // default kept
    expect(merged['deepseek-reasoner']!.input).toBe(4) // untouched model
  })
})

describe('isOffPeakHour', () => {
  it('matches listed hours only', () => {
    expect(isOffPeakHour(3, [0, 1, 2, 3, 4, 5, 6, 7])).toBe(true)
    expect(isOffPeakHour(12, [0, 1, 2, 3, 4, 5, 6, 7])).toBe(false)
    expect(isOffPeakHour(9, [])).toBe(false) // empty list disables
  })
})

describe('estimateCostCny', () => {
  const pricing = mergePricing()
  const byModel = {
    'deepseek-chat': { requests: 1, inputTokens: 1_000_000, outputTokens: 1_000_000, cacheReadTokens: 1_000_000 },
  }

  it('applies per-model prices at peak hours', () => {
    const cost = estimateCostCny(byModel, pricing, { hour: 12, offPeakHours: [] })
    // input 2 + output 3 + cache 0.5 = 5.5 CNY
    expect(cost).toBeCloseTo(5.5, 6)
  })

  it('discounts cache-miss prices during off-peak, not cache reads', () => {
    const cost = estimateCostCny(byModel, pricing, { hour: 3, offPeakHours: [3], offPeakDiscount: 0.5 })
    // input 2*0.5 + output 3*0.5 + cache 0.5 = 3.0 CNY
    expect(cost).toBeCloseTo(3.0, 6)
  })

  it('defaults to the current hour', () => {
    const now = new Date().getHours()
    const peak = estimateCostCny(byModel, pricing, { offPeakHours: [] })
    const priced = estimateCostCny(byModel, pricing, { hour: now, offPeakHours: [] })
    expect(peak).toBe(priced)
  })

  it('falls back to deepseek-chat pricing for unknown models', () => {
    const cost = estimateCostCny(
      { 'unknown-model': { requests: 1, inputTokens: 1_000_000, outputTokens: 0, cacheReadTokens: 0 } },
      pricing,
      { hour: 12, offPeakHours: [] },
    )
    expect(cost).toBeCloseTo(2.0, 6)
  })
})
