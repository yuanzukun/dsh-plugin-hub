/**
 * Build script for dsh-deepseek-usage.
 *
 * Emits two artifacts (mirroring the harness tsdown clientBundle preset):
 *  - lib/index.js   — host (Node) half, ESM, @deepseek-ai/* left external so
 *                     they resolve from the profile's node_modules (single
 *                     cordis runtime identity).
 *  - lib/client.js  — browser half, CJS wrapped in the __ModuleLoader__.load
 *                     factory handoff, externals answered by the frozen
 *                     module table (platform modules + the runtime client
 *                     exemption); everything else is inlined.
 */
import { build } from 'esbuild'
import { mkdir } from 'node:fs/promises'

const ID = 'dsh-deepseek-usage'

// Shared browser platform modules seeded by the web shell (see
// packages/client/web/src/platform.ts) plus the documented runtime store
// exemption — the only specifiers the loader module table can answer.
const CLIENT_EXTERNALS = [
  'react', 'react/jsx-runtime', 'react-dom', 'react-dom/client', '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-attachment',
  '@deepseek-ai/dsh-client-schema-form',
  '@deepseek-ai/dsh-client-runtime/client',
]

const NODE_ENV = process.env.NODE_ENV ?? 'production'

await mkdir('lib', { recursive: true })

// ---- Host half ------------------------------------------------------------
await build({
  entryPoints: ['src/index.ts'],
  outfile: 'lib/index.js',
  bundle: true,
  format: 'esm',
  platform: 'node',
  target: 'es2022',
  external: ['@deepseek-ai/*', 'node:*'],
  define: { 'process.env.NODE_ENV': JSON.stringify(NODE_ENV) },
  sourcemap: false,
  logLevel: 'info',
})

// ---- Browser half ---------------------------------------------------------
await build({
  entryPoints: ['src/client/index.ts'],
  outfile: 'lib/client.js',
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: 'es2022',
  jsx: 'automatic',
  external: CLIENT_EXTERNALS,
  define: {
    'process.env.NODE_ENV': JSON.stringify(NODE_ENV),
    'import.meta.env.MODE': JSON.stringify(NODE_ENV),
    'import.meta.env': JSON.stringify({ MODE: NODE_ENV }),
  },
  banner: {
    js: `window.__ModuleLoader__.load({ id: ${JSON.stringify(ID)}, factory: (require) => {\nvar module = { exports: {} }; var exports = module.exports;`,
  },
  footer: {
    js: 'return module.exports; } });',
  },
  sourcemap: true,
  logLevel: 'info',
})

console.log('build ok: lib/index.js + lib/client.js')
