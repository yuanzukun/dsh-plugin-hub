/**
 * Pure pricing/cost logic, kept dependency-free so it is unit-testable:
 * merging the user pricing table over the built-in defaults, peak/off-peak
 * hour handling, and per-window cost estimation. No ctx, no imports from
 * harness packages.
 */
import { DEFAULT_PRICING, type Config as ConfigType } from './config.ts'
import type { ModelUsage } from './stats.ts'

export interface PriceRow {
  input: number
  output: number
  cacheRead: number
}

export type PricingTable = Record<string, PriceRow>

/** Merge the user pricing overrides over the built-in table. */
export function mergePricing(userPricing: ConfigType['pricing'] = {}): PricingTable {
  const merged: PricingTable = {}
  for (const [model, price] of Object.entries(DEFAULT_PRICING)) merged[model] = { ...price }
  for (const [model, userPrice] of Object.entries(userPricing ?? {})) {
    const base = merged[model] ?? { input: 2, output: 3, cacheRead: 0.5 }
    merged[model] = {
      input: userPrice.input ?? base.input,
      output: userPrice.output ?? base.output,
      cacheRead: userPrice.cacheRead ?? base.cacheRead,
    }
  }
  return merged
}

/** Whether the given local hour (0–23) falls in the off-peak window. */
export function isOffPeakHour(hour: number, offPeakHours: readonly number[]): boolean {
  return offPeakHours.includes(hour)
}

export interface CostOptions {
  /** Local hours (0–23) treated as off-peak; empty list disables off-peak pricing. */
  offPeakHours?: readonly number[]
  /** Multiplier applied to cache-miss input/output prices during off-peak hours (e.g. 0.5). */
  offPeakDiscount?: number
  /** Local hour (0–23) to price against; defaults to the current hour. */
  hour?: number
}

/**
 * Estimated spend in CNY across a window's per-model usage. During off-peak
 * hours the cache-miss input/output prices are discounted; cache-read tokens
 * keep the full price (matching DeepSeek's off-peak policy). The estimate is
 * priced at the current hour, so a window spanning the peak boundary is
 * approximate by design.
 */
export function estimateCostCny(
  byModel: Record<string, ModelUsage>,
  pricing: PricingTable,
  options: CostOptions = {},
): number {
  const hour = options.hour ?? new Date().getHours()
  const offPeak = isOffPeakHour(hour, options.offPeakHours ?? [])
  const discount = offPeak ? (options.offPeakDiscount ?? 1) : 1
  let total = 0
  for (const [model, usage] of Object.entries(byModel)) {
    const price = pricing[model] ?? pricing['deepseek-chat']
    if (price === undefined) continue
    total += (usage.inputTokens * price.input * discount) / 1_000_000
    total += (usage.outputTokens * price.output * discount) / 1_000_000
    total += (usage.cacheReadTokens * price.cacheRead) / 1_000_000
  }
  return Number(total.toFixed(6))
}
