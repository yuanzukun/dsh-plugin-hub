/**
 * Real-time usage tracking for the `llm/stream` waterfall: request counts,
 * token usage (input/output/cache/reasoning) and failures, aggregated over
 * three windows — all time (since plugin load), today (local day), and the
 * last N seconds (rolling). Per-model token maps are kept per window for
 * correct cost estimates.
 */
import type { TokenUsage } from '@deepseek-ai/dsh-llm'

export interface UsageWindow {
  requests: number
  failedRequests: number
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
  cacheWriteTokens: number
  reasoningTokens: number
}

export interface ModelUsage {
  requests: number
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
}

/** One session's aggregated usage (keyed by session id). */
export interface SessionUsage {
  requests: number
  failedRequests: number
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
  lastAt: number
}

export interface UsageSnapshot {
  total: UsageWindow
  today: UsageWindow
  rolling: UsageWindow
  /** First recorded request time (ms epoch); undefined before any request. */
  firstRequestAt?: number
  /** Last recorded request time (ms epoch); undefined before any request. */
  lastRequestAt?: number
  /** Per-model usage, all time (settings pricing table). */
  byModel: Record<string, ModelUsage>
  /** Per-model usage, today. */
  byModelToday: Record<string, ModelUsage>
  /** Per-model usage, rolling window. */
  byModelRolling: Record<string, ModelUsage>
  /** Per-session usage (bounded, most recent activity kept). */
  bySession: Record<string, SessionUsage>
}

function emptyWindow(): UsageWindow {
  return {
    requests: 0, failedRequests: 0,
    inputTokens: 0, outputTokens: 0,
    cacheReadTokens: 0, cacheWriteTokens: 0, reasoningTokens: 0,
  }
}

function emptyModel(): ModelUsage {
  return { requests: 0, inputTokens: 0, outputTokens: 0, cacheReadTokens: 0 }
}

function localDayKey(now: number): string {
  const d = new Date(now)
  const month = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${d.getFullYear()}-${month}-${day}`
}

/**
 * Cache-hit rate of one window as a percentage (0–100): cached input tokens
 * divided by all input tokens (cache reads + cache misses). 0 when no input.
 */
export function cacheHitRate(window: UsageWindow): number {
  const denominator = window.inputTokens + window.cacheReadTokens
  if (denominator <= 0) return 0
  return (window.cacheReadTokens / denominator) * 100
}

/** One rolling-window entry, carrying the model for per-model aggregation. */
interface RollingEntry {
  at: number
  usage: TokenUsage
  model?: string
}

export class UsageTracker {
  private readonly total = emptyWindow()
  private readonly byDay = new Map<string, UsageWindow>()
  private readonly byModel = new Map<string, ModelUsage>()
  /** Per-model usage keyed by local day (today's entry feeds byModelToday). */
  private readonly byModelByDay = new Map<string, Map<string, ModelUsage>>()
  /** Rolling window entries; consumed from a cursor so pruning is O(1)-amortized. */
  private readonly rollingEntries: RollingEntry[] = []
  private rollingStart = 0
  private readonly bySession = new Map<string, SessionUsage>()
  private firstRequestAt: number | undefined
  private lastRequestAt: number | undefined

  constructor(
    private readonly rollingWindowMs: number,
    private readonly maxSessions = 200,
    private readonly sessionRetentionMs = 30 * 86_400_000,
  ) {}

  /** Record one completed (or failed) request. */
  record(usage: TokenUsage | undefined, failed = false, model?: string, sessionId?: string, at = Date.now()): void {
    if (this.firstRequestAt === undefined) this.firstRequestAt = at
    this.lastRequestAt = at

    this.total.requests += 1
    if (failed) this.total.failedRequests += 1

    const dayKey = localDayKey(at)
    const day = this.byDay.get(dayKey) ?? emptyWindow()
    day.requests += 1
    if (failed) day.failedRequests += 1
    this.byDay.set(dayKey, day)
    this.pruneDays()

    if (usage !== undefined) {
      this.total.inputTokens += usage.inputTokens
      this.total.outputTokens += usage.outputTokens
      this.total.cacheReadTokens += usage.cacheReadTokens ?? 0
      this.total.cacheWriteTokens += usage.cacheWriteTokens ?? 0
      this.total.reasoningTokens += usage.reasoningTokens ?? 0
      day.inputTokens += usage.inputTokens
      day.outputTokens += usage.outputTokens
      day.cacheReadTokens += usage.cacheReadTokens ?? 0
      day.cacheWriteTokens += usage.cacheWriteTokens ?? 0
      day.reasoningTokens += usage.reasoningTokens ?? 0

      if (model !== undefined) {
        touchModel(this.byModel, model, usage)
        this.touchDayModel(dayKey, model, usage)
        this.pruneModelDays()
      }

      this.rollingEntries.push({ at, usage, model })
      this.trimRolling(at)
    } else if (failed && model !== undefined) {
      // A failed request with no usage chunk still counts as a request.
      touchModel(this.byModel, model, undefined)
      this.touchDayModel(dayKey, model, undefined)
    }

    if (sessionId !== undefined && sessionId !== '') {
      const s = this.bySession.get(sessionId)
        ?? { requests: 0, failedRequests: 0, inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, lastAt: 0 }
      s.requests += 1
      if (failed) s.failedRequests += 1
      if (usage !== undefined) {
        s.inputTokens += usage.inputTokens
        s.outputTokens += usage.outputTokens
        s.cacheReadTokens += usage.cacheReadTokens ?? 0
      }
      s.lastAt = at
      this.bySession.set(sessionId, s)
      this.pruneSessions(at)
    }
  }

  /** Add one request's usage into the per-model map of one local day. */
  private touchDayModel(dayKey: string, model: string, usage: TokenUsage | undefined): void {
    let dayModels = this.byModelByDay.get(dayKey)
    if (dayModels === undefined) {
      dayModels = new Map()
      this.byModelByDay.set(dayKey, dayModels)
    }
    touchModel(dayModels, model, usage)
  }

  /** Keep only the recent local days' per-model maps (trend history). */
  private pruneModelDays(): void {
    const cutoff = localDayKey(Date.now() - 60 * 86_400_000)
    for (const key of this.byModelByDay.keys()) {
      if (key < cutoff) this.byModelByDay.delete(key)
    }
  }

  /** Keep only the recent local days' windows (trend history). */
  private pruneDays(): void {
    const cutoff = localDayKey(Date.now() - 60 * 86_400_000)
    for (const key of this.byDay.keys()) {
      if (key < cutoff) this.byDay.delete(key)
    }
  }

  /** Drop stale sessions, then keep only the most recently active ones. */
  private pruneSessions(now: number): void {
    const cutoff = now - this.sessionRetentionMs
    for (const [id, s] of this.bySession) {
      if (s.lastAt < cutoff) this.bySession.delete(id)
    }
    if (this.bySession.size > this.maxSessions) {
      const stale = [...this.bySession.entries()]
        .sort((a, b) => a[1].lastAt - b[1].lastAt)
        .slice(0, this.bySession.size - this.maxSessions)
      for (const [id] of stale) this.bySession.delete(id)
    }
  }

  /** Advance the rolling cursor past expired entries; compact occasionally. */
  private trimRolling(now: number): void {
    const cutoff = now - this.rollingWindowMs
    let start = this.rollingStart
    while (start < this.rollingEntries.length && this.rollingEntries[start]!.at < cutoff) start++
    this.rollingStart = start
    if (this.rollingStart > 1024 && this.rollingStart > this.rollingEntries.length / 2) {
      this.rollingEntries.splice(0, this.rollingStart)
      this.rollingStart = 0
    }
  }

  snapshot(): UsageSnapshot {
    const rolling = emptyWindow()
    const byModelRolling = new Map<string, ModelUsage>()
    const cutoff = Date.now() - this.rollingWindowMs
    for (let i = this.rollingStart; i < this.rollingEntries.length; i++) {
      const entry = this.rollingEntries[i]!
      // Cursor pruning assumes chronological pushes; the filter keeps the
      // window correct even if an out-of-order timestamp slips in.
      if (entry.at < cutoff) continue
      rolling.requests += 1
      rolling.inputTokens += entry.usage.inputTokens
      rolling.outputTokens += entry.usage.outputTokens
      rolling.cacheReadTokens += entry.usage.cacheReadTokens ?? 0
      rolling.cacheWriteTokens += entry.usage.cacheWriteTokens ?? 0
      rolling.reasoningTokens += entry.usage.reasoningTokens ?? 0
      if (entry.model !== undefined) {
        touchModel(byModelRolling, entry.model, entry.usage)
      }
    }
    const todayKey = localDayKey(Date.now())
    return {
      total: { ...this.total },
      today: { ...(this.byDay.get(todayKey) ?? emptyWindow()) },
      rolling,
      firstRequestAt: this.firstRequestAt,
      lastRequestAt: this.lastRequestAt,
      byModel: snapshotMap(this.byModel),
      byModelToday: snapshotMap(this.byModelByDay.get(todayKey) ?? new Map()),
      byModelRolling: snapshotMap(byModelRolling),
      bySession: Object.fromEntries(
        [...this.bySession.entries()].map(([id, usage]) => [id, { ...usage }]),
      ),
    }
  }

  /**
   * Seed history from persisted state (called before any live records).
   * Rolling-window data is not persisted — it starts empty after a restart.
   */
  restore(state: {
    total: UsageWindow
    byDay: Record<string, UsageWindow>
    byModel: Record<string, ModelUsage>
    byModelByDay: Record<string, Record<string, ModelUsage>>
    bySession: Record<string, SessionUsage>
    firstRequestAt?: number
    lastRequestAt?: number
  }): void {
    Object.assign(this.total, state.total)
    for (const [day, window] of Object.entries(state.byDay)) this.byDay.set(day, { ...window })
    for (const [model, usage] of Object.entries(state.byModel)) this.byModel.set(model, { ...usage })
    for (const [day, models] of Object.entries(state.byModelByDay)) {
      const map = new Map<string, ModelUsage>()
      for (const [model, usage] of Object.entries(models)) map.set(model, { ...usage })
      this.byModelByDay.set(day, map)
    }
    for (const [id, usage] of Object.entries(state.bySession)) this.bySession.set(id, { ...usage })
    this.firstRequestAt = state.firstRequestAt
    this.lastRequestAt = state.lastRequestAt
    this.pruneDays()
    this.pruneModelDays()
    this.pruneSessions(Date.now())
  }

  /** Serialize the persisted subset (rolling window excluded). */
  exportState(): {
    total: UsageWindow
    byDay: Record<string, UsageWindow>
    byModel: Record<string, ModelUsage>
    byModelByDay: Record<string, Record<string, ModelUsage>>
    bySession: Record<string, SessionUsage>
    firstRequestAt?: number
    lastRequestAt?: number
  } {
    const byModelByDay: Record<string, Record<string, ModelUsage>> = {}
    for (const [day, models] of this.byModelByDay) byModelByDay[day] = snapshotMap(models)
    return {
      total: { ...this.total },
      byDay: Object.fromEntries([...this.byDay.entries()].map(([day, w]) => [day, { ...w }])),
      byModel: snapshotMap(this.byModel),
      byModelByDay,
      bySession: Object.fromEntries([...this.bySession.entries()].map(([id, u]) => [id, { ...u }])),
      firstRequestAt: this.firstRequestAt,
      lastRequestAt: this.lastRequestAt,
    }
  }
}

/** Add one request's usage (or a failed request) into a per-model map. */
function touchModel(map: Map<string, ModelUsage>, model: string, usage: TokenUsage | undefined): void {
  const m = map.get(model) ?? emptyModel()
  m.requests += 1
  if (usage !== undefined) {
    m.inputTokens += usage.inputTokens
    m.outputTokens += usage.outputTokens
    m.cacheReadTokens += usage.cacheReadTokens ?? 0
  }
  map.set(model, m)
}

function snapshotMap(map: Map<string, ModelUsage>): Record<string, ModelUsage> {
  return Object.fromEntries([...map.entries()].map(([model, usage]) => [model, { ...usage }]))
}
