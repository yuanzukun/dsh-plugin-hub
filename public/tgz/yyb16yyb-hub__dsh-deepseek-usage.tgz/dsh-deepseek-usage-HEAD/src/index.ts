/**
 * dsh-deepseek-usage — host half.
 *
 * Real-time DeepSeek API usage for the DeepSeek Harness:
 *  - polls the DeepSeek `/user/balance` endpoint on a timer (keys resolved
 *    from plugin config → env → credentials seam → stored settings; multiple
 *    keys are aggregated),
 *  - tracks request/token usage by wrapping the `llm/stream` waterfall,
 *  - persists daily history so statistics survive restarts,
 *  - can block LLM requests while the balance is below a threshold (opt-in),
 *  - exposes a `deepseek_usage` model tool,
 *  - serves `GET /dsh-deepseek-usage` (+ `POST /dsh-deepseek-usage/config`
 *    for the settings-panel editor), same-origin JSON.
 *
 * Everything registered through `ctx` is auto-disposed on unload; the
 * balance timer and the persistence write are the only manual resources.
 */
import { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ContentBlock, GenerateOptions, StreamChunk, TokenUsage } from '@deepseek-ai/dsh-llm'
import type { CredentialRef } from '@deepseek-ai/dsh-credentials'
import { dshHomePath } from '@deepseek-ai/dsh-home-paths'
import {
  Config,
  DEFAULT_ALERT_THRESHOLD,
  DEFAULT_API_KEY_ENV,
  DEFAULT_BASE_URL,
  DEFAULT_POLL_INTERVAL_MS,
  type Config as ConfigType,
} from './config.ts'
import { BalancePoller } from './balance.ts'
import {
  UsageTracker,
  cacheHitRate,
  type ModelUsage,
  type SessionUsage,
} from './stats.ts'
import { estimateCostCny, mergePricing } from './cost.ts'
import { Persistence, PERSIST_VERSION } from './persist.ts'

export const name = 'deepseek-usage'
export const inject = ['tools', 'llm']

/** Rolling usage window for the "last N seconds" readout. */
const ROLLING_WINDOW_MS = 60_000
/** Days of daily history served to the trend chart. */
const HISTORY_DAYS = 30

/** Wrap one model stream: count the request and harvest the usage chunk. */
function trackStream(
  tracker: UsageTracker,
  ctx: Context,
  stream: AsyncIterable<StreamChunk>,
  model: string | undefined,
  sessionId: string | undefined,
  afterRecord?: () => void,
): AsyncIterable<StreamChunk> {
  return (async function* () {
    let usage: TokenUsage | undefined
    let failed = false
    try {
      for await (const chunk of stream) {
        if (chunk.type === 'usage') usage = chunk.usage
        yield chunk
      }
    } catch (error) {
      failed = true
      throw error
    } finally {
      // Statistics live on the hot path of every model call — a tracking
      // failure must never break the stream, so record is fire-and-forget.
      try {
        tracker.record(usage, failed, model, sessionId)
        afterRecord?.()
      } catch (error) {
        ctx.logger.warn('[deepseek-usage] usage tracking failed: %s',
          error instanceof Error ? error.message : String(error))
      }
    }
  })()
}

/** A stream that immediately fails with a clear reason (low-balance block). */
function blockedStream(reason: string): AsyncIterable<StreamChunk> {
  return (async function* () {
    throw new Error(reason)
  })()
}

/** The canonical tool value for one scope window. */
type UsageScope = 'total' | 'today' | 'rolling'

interface ToolValue {
  scope: UsageScope
  fetchedAt: number
  balance: {
    available: boolean
    total: number
    granted: number
    toppedUp: number
    error: string | null
  }
  usage: {
    requests: number
    failedRequests: number
    inputTokens: number
    outputTokens: number
    cacheReadTokens: number
    cacheWriteTokens: number
    reasoningTokens: number
    /** Cache-hit rate of this window as a percentage (0–100). */
    cacheHitRate: number
  }
  estimatedCostCny: number
}

/**
 * Allowlist + coerce an unknown object into an editable config patch. Unknown
 * keys and malformed values are dropped; nothing secret is ever accepted.
 */
function sanitizeEditableConfig(input: unknown): Partial<ConfigType> {
  if (typeof input !== 'object' || input === null) return {}
  const rec = input as Record<string, unknown>
  const out: Partial<ConfigType> = {}
  if (typeof rec.pollIntervalMs === 'number' && rec.pollIntervalMs >= 5_000 && rec.pollIntervalMs <= 3_600_000) {
    out.pollIntervalMs = Math.round(rec.pollIntervalMs)
  }
  if (typeof rec.alertThreshold === 'number' && rec.alertThreshold >= 0) out.alertThreshold = rec.alertThreshold
  for (const key of ['showBalance', 'showTokens', 'showCost', 'blockOnLowBalance'] as const) {
    if (typeof rec[key] === 'boolean') out[key] = rec[key]
  }
  if (Array.isArray(rec.offPeakHours)
    && rec.offPeakHours.every((h) => typeof h === 'number' && h >= 0 && h <= 23)) {
    out.offPeakHours = [...rec.offPeakHours] as number[]
  }
  if (typeof rec.offPeakDiscount === 'number' && rec.offPeakDiscount >= 0 && rec.offPeakDiscount <= 1) {
    out.offPeakDiscount = rec.offPeakDiscount
  }
  if (typeof rec.pricing === 'object' && rec.pricing !== null) {
    const pricing: NonNullable<ConfigType['pricing']> = {}
    for (const [model, raw] of Object.entries(rec.pricing)) {
      if (typeof raw !== 'object' || raw === null) continue
      const row = raw as Record<string, unknown>
      const input = typeof row.input === 'number' && row.input >= 0 ? row.input : undefined
      const output = typeof row.output === 'number' && row.output >= 0 ? row.output : undefined
      const cacheRead = typeof row.cacheRead === 'number' && row.cacheRead >= 0 ? row.cacheRead : undefined
      if (input !== undefined || output !== undefined || cacheRead !== undefined) {
        pricing[model] = { input, output, cacheRead }
      }
    }
    if (Object.keys(pricing).length > 0) out.pricing = pricing
  }
  return out
}

/** The live editable subset, for the editor UI and persistence. */
function editableConfigView(config: ConfigType): Record<string, unknown> {
  return {
    pollIntervalMs: config.pollIntervalMs ?? DEFAULT_POLL_INTERVAL_MS,
    showBalance: config.showBalance ?? true,
    showTokens: config.showTokens ?? true,
    showCost: config.showCost ?? true,
    alertThreshold: config.alertThreshold ?? DEFAULT_ALERT_THRESHOLD,
    blockOnLowBalance: config.blockOnLowBalance ?? false,
    offPeakHours: config.offPeakHours ?? [],
    offPeakDiscount: config.offPeakDiscount ?? 0.5,
    pricing: config.pricing ?? {},
  }
}

/** Drain a request body (small JSON payloads). */
function readBody(req: { on: (event: string, listener: (chunk: Buffer) => void) => unknown }): Promise<string> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    req.on('data', (chunk) => chunks.push(chunk))
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
    req.on('error', reject)
  })
}

export async function apply(ctx: Context, rowConfig: ConfigType): Promise<void> {
  // ---- Persistence: restore history, seed the live config with editor overrides.
  const persistence = new Persistence(dshHomePath('deepseek-usage', 'usage.json'))
  const persisted = await persistence.load()
  const live: ConfigType = { ...rowConfig, ...sanitizeEditableConfig(persisted?.config) }

  const baseURL = (live.baseURL ?? DEFAULT_BASE_URL).replace(/\/+$/u, '')
  const apiKeyEnv = live.apiKeyEnv ?? DEFAULT_API_KEY_ENV

  const tracker = new UsageTracker(ROLLING_WINDOW_MS, live.maxSessions ?? 200)
  if (persisted !== undefined) tracker.restore(persisted)

  let pricing = mergePricing(live.pricing)
  const costOptions = (): { offPeakHours: readonly number[]; offPeakDiscount: number } => ({
    offPeakHours: live.offPeakHours ?? [],
    offPeakDiscount: live.offPeakDiscount ?? 0.5,
  })

  // ---- Debounced persistence writes.
  let saveTimer: NodeJS.Timeout | undefined
  const saveNow = async (): Promise<void> => {
    await persistence.save({
      version: PERSIST_VERSION,
      ...tracker.exportState(),
      config: editableConfigView(live),
    })
  }
  const scheduleSave = (): void => {
    if (saveTimer !== undefined) clearTimeout(saveTimer)
    saveTimer = setTimeout(() => {
      saveTimer = undefined
      void saveNow()
    }, 5_000)
  }

  /**
   * Resolve the primary API key: explicit config → dsh credentials seam
   * (process env, ~/.dsh/.credentials.yaml, project/user env layers) →
   * stored settings. Re-resolved on every poll, so a changed credential
   * reaches the next balance fetch without a restart.
   */
  const resolveApiKey = async (): Promise<string | undefined> => {
    if (live.apiKey !== undefined && live.apiKey !== '') return live.apiKey
    const fromEnv = process.env[apiKeyEnv]
    if (fromEnv !== undefined && fromEnv !== '') return fromEnv
    try {
      const credentials = ctx.get('credentials') as
        | { resolve?: (ref: CredentialRef) => Promise<{ value?: string } | undefined> }
        | undefined
      const resolved = await credentials?.resolve?.(apiKeyEnv as CredentialRef)
      if (resolved?.value !== undefined && resolved.value !== '') return resolved.value
    } catch {
      // credentials service absent — fall through
    }
    try {
      const settings = ctx.get('settings') as
        | { describe?: () => Array<{ ns: string; value: unknown }> }
        | undefined
      for (const desc of settings?.describe?.() ?? []) {
        if (desc.ns !== 'llm-deepseek') continue
        const section = desc.value as { apiKey?: string } | null
        if (section?.apiKey !== undefined && section.apiKey !== '') return section.apiKey
      }
    } catch {
      // settings service absent or section unreadable — fall through
    }
    return undefined
  }

  /** All keys: the primary plus configured extras (multi-account aggregate). */
  const resolveKeys = async (): Promise<string[]> => {
    const keys: string[] = []
    const primary = await resolveApiKey()
    if (primary !== undefined) keys.push(primary)
    for (const key of live.apiKeys ?? []) {
      if (key !== undefined && key !== '') keys.push(key)
    }
    return keys
  }

  const poller = new BalancePoller(
    resolveKeys,
    () => baseURL,
    live.pollIntervalMs ?? DEFAULT_POLL_INTERVAL_MS,
    undefined,
    live.balanceTimeoutMs ?? 10_000,
  )
  ctx.effect(() => () => {
    poller.dispose()
    if (saveTimer !== undefined) clearTimeout(saveTimer)
    void saveNow()
  }, 'deepseek-usage: poller + persistence')

  /** Reason to block requests, or undefined when requests may proceed. */
  const blockedReason = (): string | undefined => {
    if (live.blockOnLowBalance !== true) return undefined
    const snapshot = poller.snapshot
    if (!snapshot.ok) return undefined // cannot judge while balance is unknown
    const total = Number(snapshot.infos[0]?.totalBalance ?? 0)
    const threshold = live.alertThreshold ?? DEFAULT_ALERT_THRESHOLD
    if (threshold > 0 && total < threshold) {
      return `DeepSeek balance ${total} is below alertThreshold ${threshold} — requests blocked by blockOnLowBalance. Top up, raise alertThreshold, or disable the option.`
    }
    return undefined
  }

  // ---- Real-time usage tracking: wrap every model stream.
  ctx.on('llm/stream', (options: GenerateOptions, next: () => AsyncIterable<StreamChunk>) => {
    const reason = blockedReason()
    if (reason !== undefined) return blockedStream(reason)
    return trackStream(tracker, ctx, next(), options.model, options.sessionId, scheduleSave)
  })

  // ---- Model tool: the agent can query usage on demand.
  const outputSchema = {
    type: 'object',
    additionalProperties: false,
    properties: {
      scope: { type: 'string', enum: ['total', 'today', 'rolling'] as const, required: true },
      fetchedAt: { type: 'number', required: true },
      balance: {
        type: 'object',
        additionalProperties: false,
        properties: {
          available: { type: 'boolean', required: true },
          total: { type: 'number', required: true },
          granted: { type: 'number', required: true },
          toppedUp: { type: 'number', required: true },
          error: { oneOf: [{ type: 'string' }, { type: 'null' }] as const, required: true },
        },
        required: true,
      },
      usage: {
        type: 'object',
        additionalProperties: false,
        properties: {
          requests: { type: 'number', required: true },
          failedRequests: { type: 'number', required: true },
          inputTokens: { type: 'number', required: true },
          outputTokens: { type: 'number', required: true },
          cacheReadTokens: { type: 'number', required: true },
          cacheWriteTokens: { type: 'number', required: true },
          reasoningTokens: { type: 'number', required: true },
          cacheHitRate: { type: 'number', required: true },
        },
        required: true,
      },
      estimatedCostCny: { type: 'number', required: true },
    },
  } as const

  function toolValueOf(scope: UsageScope): ToolValue {
    const snapshot = poller.snapshot
    const usage = tracker.snapshot()
    const window = usage[scope]
    const byModelForScope = scope === 'total' ? usage.byModel
      : scope === 'today' ? usage.byModelToday : usage.byModelRolling
    const balance = snapshot.infos[0]
    return {
      scope,
      fetchedAt: Date.now(),
      balance: {
        available: snapshot.ok && snapshot.isAvailable,
        total: balance !== undefined ? Number(balance.totalBalance) : 0,
        granted: balance !== undefined ? Number(balance.grantedBalance) : 0,
        toppedUp: balance !== undefined ? Number(balance.toppedUpBalance) : 0,
        error: snapshot.ok ? null : (snapshot.error ?? 'unknown'),
      },
      usage: {
        requests: window.requests,
        failedRequests: window.failedRequests,
        inputTokens: window.inputTokens,
        outputTokens: window.outputTokens,
        cacheReadTokens: window.cacheReadTokens,
        cacheWriteTokens: window.cacheWriteTokens,
        reasoningTokens: window.reasoningTokens,
        cacheHitRate: cacheHitRate(window),
      },
      estimatedCostCny: estimateCostCny(byModelForScope, pricing, costOptions()),
    }
  }

  function renderToolValue(value: ToolValue): string {
    const lines = [
      `DeepSeek usage (${value.scope})`,
      `- balance: ${value.balance.available ? `${value.balance.total} ${'CNY'}` : `unavailable${value.balance.error ? ` (${value.balance.error})` : ''}`}`,
      `- requests: ${value.usage.requests}${value.usage.failedRequests > 0 ? ` (${value.usage.failedRequests} failed)` : ''}`,
      `- tokens: ${value.usage.inputTokens} in / ${value.usage.outputTokens} out (cache read ${value.usage.cacheReadTokens}, write ${value.usage.cacheWriteTokens}, reasoning ${value.usage.reasoningTokens})`,
      `- cache hit rate: ${value.usage.cacheHitRate.toFixed(1)}%`,
      `- estimated cost: ¥${value.estimatedCostCny}`,
    ]
    return lines.join('\n')
  }

  ctx.tools.register(defineTool({
    name: 'deepseek_usage',
    description: 'Query real-time DeepSeek API usage: account balance, request count, token usage (input/output/cache/reasoning), cache-hit rate and estimated cost. Use it to check available credit or how many tokens have been consumed.',
    parameters: {
      scope: {
        type: 'string',
        enum: ['total', 'today', 'rolling'],
        description: 'Which window to summarize: total (all time), today (local day) or rolling (last 60 seconds). Defaults to total.',
      },
    },
    output: {
      schema: outputSchema,
      render: (_args: unknown, value: unknown): ContentBlock[] => {
        return [{ type: 'text', text: renderToolValue(value as ToolValue) }]
      },
    },
    async execute(args: { scope?: UsageScope }): Promise<ToolValue> {
      return toolValueOf(args.scope ?? 'total')
    },
  }))

  // ---- Same-origin JSON endpoints for the Web dock + settings editor.
  const installRoute = (): void => {
    if (routeDispose !== undefined) return
    const webServer = ctx.get('webServer') as
      | {
          register: (route: {
            kind: 'exact'
            path: string
            handler: (req: {
              method?: string
              url?: string | undefined
              on: (event: string, listener: (chunk: Buffer) => void) => unknown
            }, res: {
              writeHead: (status: number, headers?: Record<string, string>) => unknown
              end: (body?: string) => unknown
            }) => void | Promise<void>
          }) => () => void
        }
      | undefined
    if (webServer === undefined) return
    try {
      routeDispose = webServer.register({
        kind: 'exact',
        path: '/dsh-deepseek-usage',
        handler: async (req, res) => {
          try {
            const url = new URL(req.url ?? '/', 'http://localhost')
            if (url.searchParams.get('refresh') === '1') await poller.refresh()
            const usage = tracker.snapshot()
            const bySession: Array<SessionUsage & { sessionId: string }> =
              Object.entries(usage.bySession)
                .map(([sessionId, s]) => ({ sessionId, ...s }))
                .sort((a, b) => b.lastAt - a.lastAt)
            const costOf = (byModel: Record<string, ModelUsage>): number =>
              estimateCostCny(byModel, pricing, costOptions())
            const payload = {
              balance: poller.snapshot,
              usage,
              estimatedCost: {
                total: costOf(usage.byModel),
                today: costOf(usage.byModelToday),
                rolling: costOf(usage.byModelRolling),
              },
              cacheHitRate: {
                total: cacheHitRate(usage.total),
                today: cacheHitRate(usage.today),
                rolling: cacheHitRate(usage.rolling),
              },
              history: historyOf(),
              config: editableConfigView(live),
              display: {
                showBalance: live.showBalance ?? true,
                showTokens: live.showTokens ?? true,
                showCost: live.showCost ?? true,
              },
              alertThreshold: live.alertThreshold ?? DEFAULT_ALERT_THRESHOLD,
              rollingWindowMs: ROLLING_WINDOW_MS,
              pollIntervalMs: live.pollIntervalMs ?? DEFAULT_POLL_INTERVAL_MS,
              bySession,
              pricing,
              serverTime: Date.now(),
            }
            res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
            res.end(JSON.stringify(payload))
          } catch (error) {
            res.writeHead(500, { 'content-type': 'application/json; charset=utf-8' })
            res.end(JSON.stringify({ error: error instanceof Error ? error.message : String(error) }))
          }
        },
      })
      routeDispose = webServer.register({
        kind: 'exact',
        path: '/dsh-deepseek-usage/config',
        handler: async (req, res) => {
          const respond = (status: number, body: unknown): void => {
            res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
            res.end(JSON.stringify(body))
          }
          if ((req.method ?? 'GET') !== 'POST') {
            respond(405, { error: 'method not allowed' })
            return
          }
          try {
            const raw = await readBody(req)
            const patch = sanitizeEditableConfig(JSON.parse(raw) as unknown)
            if (Object.keys(patch).length === 0) {
              respond(400, { error: 'no valid editable fields' })
              return
            }
            Object.assign(live, patch)
            if (patch.pollIntervalMs !== undefined) poller.setInterval(patch.pollIntervalMs)
            pricing = mergePricing(live.pricing)
            void saveNow()
            respond(200, { ok: true, config: editableConfigView(live) })
          } catch (error) {
            respond(400, { error: error instanceof Error ? error.message : String(error) })
          }
        },
      })
    } catch (error) {
      ctx.logger.warn('[deepseek-usage] web route registration failed: %s',
        error instanceof Error ? error.message : String(error))
    }
  }

  /** Last N days of daily usage + cost (trend chart + CSV export). */
  const historyOf = (): Array<{
    day: string
    requests: number
    inputTokens: number
    outputTokens: number
    cacheReadTokens: number
    costCny: number
  }> => {
    const state = tracker.exportState()
    const days = Object.keys(state.byDay).sort().slice(-HISTORY_DAYS)
    return days.map((day) => {
      const w = state.byDay[day]!
      return {
        day,
        requests: w.requests,
        inputTokens: w.inputTokens,
        outputTokens: w.outputTokens,
        cacheReadTokens: w.cacheReadTokens,
        costCny: estimateCostCny(state.byModelByDay[day] ?? {}, pricing, costOptions()),
      }
    })
  }

  let routeDispose: (() => void) | undefined
  installRoute()
  ctx.on('internal/service', (name: string) => {
    if (name === 'webServer') installRoute()
    // The credentials seam may bind after our first poll; re-poll the moment
    // it does so the dock shows a real balance without waiting a cycle.
    if (name === 'credentials') void poller.refresh().catch(() => {})
  })
  ctx.effect(() => () => { routeDispose?.() }, 'deepseek-usage: web route')
}

export { Config }
export type { Config as UsageConfig } from './config.ts'
