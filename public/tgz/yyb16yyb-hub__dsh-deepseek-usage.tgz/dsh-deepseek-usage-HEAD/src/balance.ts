/**
 * DeepSeek `/user/balance` client: one fetch plus a poller that keeps the
 * latest snapshot and refreshes it on a timer. Supports multiple API keys:
 * each key's balance is fetched and aggregated by currency; the per-key
 * detail is exposed as `accounts`. Keys are re-resolved on every poll, so a
 * later settings/env change picks up on the next tick.
 */

export interface BalanceInfo {
  currency: string
  totalBalance: string
  grantedBalance: string
  toppedUpBalance: string
}

/** One API key's balance result (the settings panel's per-account table). */
export interface AccountBalance {
  label: string
  ok: boolean
  isAvailable: boolean
  currency: string
  totalBalance: string
  grantedBalance: string
  toppedUpBalance: string
  error?: string
}

export interface BalanceSnapshot {
  ok: boolean
  isAvailable: boolean
  /** Aggregated by currency across all keys. */
  infos: BalanceInfo[]
  /** Per-key detail, in key order. */
  accounts?: AccountBalance[]
  /** Human-readable failure (never the key itself). */
  error?: string
  fetchedAt: number
}

function sumBalances(list: readonly AccountBalance[]): BalanceInfo[] {
  const byCurrency = new Map<string, { total: number; granted: number; toppedUp: number }>()
  for (const account of list) {
    if (!account.ok) continue
    const cur = byCurrency.get(account.currency) ?? { total: 0, granted: 0, toppedUp: 0 }
    cur.total += Number(account.totalBalance) || 0
    cur.granted += Number(account.grantedBalance) || 0
    cur.toppedUp += Number(account.toppedUpBalance) || 0
    byCurrency.set(account.currency, cur)
  }
  return [...byCurrency.entries()].map(([currency, value]) => ({
    currency,
    totalBalance: value.total.toFixed(2),
    grantedBalance: value.granted.toFixed(2),
    toppedUpBalance: value.toppedUp.toFixed(2),
  }))
}

/** One `/user/balance` fetch. Throws only on transport-level failures. */
export async function fetchBalance(
  baseURL: string,
  apiKey: string,
  signal?: AbortSignal,
  timeoutMs = 10_000,
): Promise<BalanceSnapshot> {
  const url = `${baseURL.replace(/\/+$/u, '')}/user/balance`
  // Never let a hung upstream stall the poller: combine the caller's signal
  // (if any) with a hard timeout.
  const timeout = AbortSignal.timeout(timeoutMs)
  const effective = signal !== undefined ? AbortSignal.any([signal, timeout]) : timeout
  const response = await fetch(url, {
    headers: {
      authorization: `Bearer ${apiKey}`,
      accept: 'application/json',
    },
    signal: effective,
  })
  if (!response.ok) {
    return {
      ok: false,
      isAvailable: false,
      infos: [],
      error: `HTTP ${response.status} ${response.statusText}`,
      fetchedAt: Date.now(),
    }
  }
  const body = (await response.json()) as {
    is_available?: boolean
    balance_infos?: Array<{
      currency?: string
      total_balance?: string
      granted_balance?: string
      topped_up_balance?: string
    }>
  }
  return {
    ok: true,
    isAvailable: body.is_available === true,
    infos: (body.balance_infos ?? []).map((info) => ({
      currency: info.currency ?? 'CNY',
      totalBalance: info.total_balance ?? '0',
      grantedBalance: info.granted_balance ?? '0',
      toppedUpBalance: info.topped_up_balance ?? '0',
    })),
    fetchedAt: Date.now(),
  }
}

/** Reduce per-key fetches into one aggregated snapshot. */
function aggregate(
  keys: readonly string[],
  results: readonly BalanceSnapshot[],
  fetchedAt: number,
): BalanceSnapshot {
  const accounts: AccountBalance[] = keys.map((key, index) => {
    const result = results[index]!
    const info = result.infos[0]
    return {
      label: index === 0 ? 'default' : `key-${index}`,
      ok: result.ok,
      isAvailable: result.isAvailable,
      currency: info?.currency ?? 'CNY',
      totalBalance: info?.totalBalance ?? '0',
      grantedBalance: info?.grantedBalance ?? '0',
      toppedUpBalance: info?.toppedUpBalance ?? '0',
      ...(result.ok ? {} : { error: result.error ?? 'fetch failed' }),
    }
  })
  const anyOk = accounts.some((account) => account.ok)
  return {
    ok: anyOk && accounts.every((account) => account.ok),
    isAvailable: anyOk && accounts.every((account) => account.ok && account.isAvailable),
    infos: sumBalances(accounts),
    accounts,
    ...(!anyOk ? { error: accounts.find((a) => a.error)?.error ?? 'all keys failed' } : {}),
    fetchedAt,
  }
}

/**
 * Polling holder: owns the timer and the latest snapshot. Starts polling on
 * construction; `dispose()` clears the timer. `refresh()` is idempotent and
 * never throws (failures land in the snapshot).
 */
export class BalancePoller {
  private latest: BalanceSnapshot = {
    ok: false,
    isAvailable: false,
    infos: [],
    error: 'not polled yet',
    fetchedAt: 0,
  }
  private timer: NodeJS.Timeout | undefined
  private readonly poll: () => Promise<void>

  constructor(
    private readonly resolveKeys: () => Promise<string[]>,
    private readonly resolveBaseURL: () => string,
    private intervalMs: number,
    private readonly onSnapshot?: (snapshot: BalanceSnapshot) => void,
    private readonly timeoutMs = 10_000,
  ) {
    this.poll = async () => {
      try {
        const keys = (await this.resolveKeys()).filter((key) => key !== undefined && key !== '')
        if (keys.length === 0) {
          this.latest = {
            ok: false, isAvailable: false, infos: [],
            error: 'no API key: set DEEPSEEK_API_KEY (or plugin config apiKey / apiKeys)',
            fetchedAt: Date.now(),
          }
          this.onSnapshot?.(this.latest)
          return
        }
        const baseURL = this.resolveBaseURL()
        const results = await Promise.all(keys.map(async (key) => {
          try {
            return await fetchBalance(baseURL, key, undefined, this.timeoutMs)
          } catch (error) {
            return {
              ok: false, isAvailable: false, infos: [],
              error: error instanceof Error ? error.message : String(error),
              fetchedAt: Date.now(),
            }
          }
        }))
        this.latest = aggregate(keys, results, Date.now())
      } catch (error) {
        this.latest = {
          ok: false, isAvailable: false, infos: [],
          error: error instanceof Error ? error.message : String(error),
          fetchedAt: Date.now(),
        }
      }
      this.onSnapshot?.(this.latest)
    }
    void this.poll()
    this.timer = setInterval(() => { void this.poll() }, intervalMs)
  }

  get snapshot(): BalanceSnapshot {
    return this.latest
  }

  async refresh(): Promise<BalanceSnapshot> {
    await this.poll()
    return this.latest
  }

  /** Live-reschedule the poll timer (settings-panel edits apply immediately). */
  setInterval(ms: number): void {
    if (ms < 5_000 || ms === this.intervalMs) return
    this.intervalMs = ms
    if (this.timer !== undefined) clearInterval(this.timer)
    this.timer = setInterval(() => { void this.poll() }, ms)
  }

  dispose(): void {
    if (this.timer !== undefined) clearInterval(this.timer)
    this.timer = undefined
  }
}
