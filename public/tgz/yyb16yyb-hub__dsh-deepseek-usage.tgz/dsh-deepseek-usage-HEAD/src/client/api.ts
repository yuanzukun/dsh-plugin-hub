/**
 * Shared client-side API surface for the usage readouts: the wire payload
 * types mirroring the host endpoint, one fetch helper, and number/date
 * formatters used by both the composer dock and the settings section.
 */

export interface BalanceInfo {
  currency: string
  totalBalance: string
  grantedBalance: string
  toppedUpBalance: string
}

/** One API key's balance result (settings panel per-account table). */
export interface AccountBalance {
  label: string
  ok: boolean
  isAvailable: boolean
  currency: string
  totalBalance: string
  grantedBalance: string
  toppedUpBalance: string
  error?: string
}

export interface BalanceSnapshot {
  ok: boolean
  isAvailable: boolean
  infos: BalanceInfo[]
  accounts?: AccountBalance[]
  error?: string
  fetchedAt: number
}

export interface UsageWindow {
  requests: number
  failedRequests: number
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
  cacheWriteTokens: number
  reasoningTokens: number
}

export interface ModelUsage {
  requests: number
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
}

export interface SessionUsageRow {
  sessionId: string
  requests: number
  failedRequests: number
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
  lastAt: number
}

export interface PricingRow {
  input: number
  output: number
  cacheRead: number
}

/** One day of persisted usage history (trend chart + CSV export). */
export interface HistoryDay {
  day: string
  requests: number
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
  costCny: number
}

/** The non-secret config subset the settings panel editor can write. */
export interface EditableConfig {
  pollIntervalMs: number
  showBalance: boolean
  showTokens: boolean
  showCost: boolean
  alertThreshold: number
  blockOnLowBalance: boolean
  offPeakHours: number[]
  offPeakDiscount: number
  pricing: Record<string, PricingRow>
}

export interface UsagePayload {
  balance: BalanceSnapshot
  usage: {
    total: UsageWindow
    today: UsageWindow
    rolling: UsageWindow
    firstRequestAt?: number
    lastRequestAt?: number
    byModel: Record<string, ModelUsage>
  }
  /** Estimated spend in CNY per window (per-model pricing). */
  estimatedCost: { total: number; today: number; rolling: number }
  /** Cache-hit rate as a percentage (0–100) per window. */
  cacheHitRate: { total: number; today: number; rolling: number }
  /** Persisted daily history (ascending by day). */
  history: HistoryDay[]
  /** Current editable config (for the settings panel editor). */
  config: EditableConfig
  display: { showBalance: boolean; showTokens: boolean; showCost: boolean }
  alertThreshold: number
  rollingWindowMs: number
  pollIntervalMs: number
  bySession: SessionUsageRow[]
  pricing?: Record<string, PricingRow>
  serverTime: number
}

/** Fetch the host snapshot; `refresh` forces a balance re-poll upstream. */
export async function fetchUsage(refresh: boolean): Promise<UsagePayload> {
  const response = await fetch(`/dsh-deepseek-usage${refresh ? '?refresh=1' : ''}`, {
    cache: 'no-store',
  })
  if (!response.ok) throw new Error(`HTTP ${response.status}`)
  return (await response.json()) as UsagePayload
}

/** Persist a partial config patch via the host; returns the updated config. */
export async function saveConfig(patch: Partial<EditableConfig>): Promise<EditableConfig> {
  const response = await fetch('/dsh-deepseek-usage/config', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(patch),
  })
  if (!response.ok) {
    let message = `HTTP ${response.status}`
    try {
      const body = (await response.json()) as { error?: string }
      if (body.error) message = body.error
    } catch { /* keep the status fallback */ }
    throw new Error(message)
  }
  const body = (await response.json()) as { config: EditableConfig }
  return body.config
}

/** Trigger a client-side CSV download. */
export function downloadCsv(filename: string, header: string[], rows: (string | number)[][]): void {
  const escape = (value: string | number): string => {
    const text = String(value)
    return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text
  }
  const lines = [header.map(escape).join(','), ...rows.map((row) => row.map(escape).join(','))]
  const blob = new Blob([`\uFEFF${lines.join('\n')}`], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  link.click()
  URL.revokeObjectURL(url)
}

/** 1.2K / 3.4M style token formatting. */
export function formatCount(value: number): string {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`
  if (value >= 1_000) return `${(value / 1_000).toFixed(1)}K`
  return String(value)
}

export function formatCny(value: number): string {
  if (value > 0 && value < 0.01) return '¥<0.01'
  return `¥${value.toFixed(2)}`
}

export function formatTime(epoch: number): string {
  const d = new Date(epoch)
  const pad = (n: number): string => String(n).padStart(2, '0')
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
}

export function formatDateTime(epoch: number): string {
  const d = new Date(epoch)
  const pad = (n: number): string => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

/** Numeric balance value (NaN when unavailable). */
export function balanceValue(payload: UsagePayload | null): number {
  const info = payload?.balance.infos[0]
  if (payload?.balance.ok !== true || info === undefined) return Number.NaN
  return Number(info.totalBalance)
}

export type AlertLevel = 'ok' | 'low' | 'critical' | 'off'

/** Derive the low-balance alert level from the payload. */
export function alertLevelOf(payload: UsagePayload | null): AlertLevel {
  if (payload === null) return 'off'
  const threshold = payload.alertThreshold
  if (threshold <= 0) return 'off'
  const value = balanceValue(payload)
  if (Number.isNaN(value)) return 'off'
  if (value < threshold / 5) return 'critical'
  if (value < threshold) return 'low'
  return 'ok'
}
