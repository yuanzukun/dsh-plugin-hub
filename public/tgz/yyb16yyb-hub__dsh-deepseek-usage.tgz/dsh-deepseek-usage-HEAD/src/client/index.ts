/**
 * dsh-deepseek-usage — browser half.
 *
 * Registers the `usage` locale dictionaries and one `conversation.composer.dock`
 * entry rendering the live usage readout. The dock only fetches the same-origin
 * `/dsh-deepseek-usage` JSON endpoint — no credentials ever cross the wire to
 * the browser.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { LocaleNamespaceMap } from '@deepseek-ai/dsh-client-ui-slots'
// Type-only: pulls the locale plugin's Context merge (ctx.locale), the
// ui-conversation SlotMap merge (the dock seat) and the settings SlotMap
// merge (the section seat) into this program.
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import { UsageDock } from './UsageDock.tsx'
import { UsageSettingsSection } from './UsageSettingsSection.tsx'
import { en, zh, type UsageKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The usage dock's copy (this plugin's dictionaries). */
    usage: UsageKey
  }
}

export const name = 'deepseek-usage-client'
export const inject = ['slots', 'locale']

export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register('usage', { zh, en }), 'deepseek-usage: dictionaries')

  ctx.inject(['slots'], (scope: ClientContext) => {
    const t = scope.locale.bind('usage')
    scope.slots.inject('conversation.composer.dock', () => scope.slots.register({
      name: 'conversation.composer.dock',
      id: 'deepseek-usage-dock',
      locale: 'usage',
      order: 20,
      label: 'DeepSeek usage dock',
    }, UsageDock))
    scope.slots.inject('settings.section', () => scope.slots.register({
      name: 'settings.section',
      id: 'deepseek-usage',
      order: 20,
      label: () => t('settings.nav'),
      locale: 'usage',
    }, UsageSettingsSection))
  })
}
