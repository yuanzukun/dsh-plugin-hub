/**
 * The Web dock component: a compact stats line rendered under the composer
 * card (`conversation.composer.dock`). It polls the same-origin
 * `/dsh-deepseek-usage` endpoint served by the host half, refreshes on a
 * timer plus a manual refresh affordance, and flags low balances against the
 * host-provided alert threshold (amber below it, red below threshold/5, one
 * browser notification per crossing when permission is already granted).
 * Pure presentation: all data comes from the host snapshot; the component
 * never touches credentials.
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import type { CSSProperties, ReactElement } from 'react'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
// Type-only: pulls the ui-conversation SlotMap merge (the dock seat) into
// this program.
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import {
  alertLevelOf,
  balanceValue,
  fetchUsage,
  formatCount,
  formatCny,
  formatTime,
  type UsagePayload,
} from './api.ts'

/** Full props of the dock entry: owner share (InputZone) + standard kit + locale seat. */
export type UsageDockProps = PropsRuntime<'conversation.composer.dock'> & PropsLocale<'usage'>

const POLL_INTERVAL_MS = 30_000

const row: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 12,
  fontSize: 12,
  lineHeight: 1.4,
  opacity: 0.85,
  padding: '2px 4px',
  whiteSpace: 'nowrap',
  overflow: 'hidden',
}

const segment: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 4,
}

const label: CSSProperties = { opacity: 0.6 }

const button: CSSProperties = {
  border: 'none',
  background: 'transparent',
  padding: '0 4px',
  cursor: 'pointer',
  fontSize: 12,
  opacity: 0.7,
  textDecoration: 'underline',
}

const ALERT_COLOR = {
  low: '#b8860b',       // dark goldenrod — amber
  critical: '#b3261e',  // red
} as const

export function UsageDock(props: UsageDockProps): ReactElement | null {
  const { t } = props
  const [payload, setPayload] = useState<UsagePayload | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [refreshing, setRefreshing] = useState(false)
  const mounted = useRef(true)
  const intervalMs = useRef(POLL_INTERVAL_MS)
  const alertedRef = useRef(false)

  const load = useCallback(async (force: boolean): Promise<void> => {
    try {
      setError(null)
      const data = await fetchUsage(force)
      if (!mounted.current) return
      setPayload(data)
      // Follow the host-side poll cadence once known.
      if (data.pollIntervalMs > 0) intervalMs.current = data.pollIntervalMs
    } catch (cause) {
      if (!mounted.current) return
      setError(cause instanceof Error ? cause.message : String(cause))
    }
  }, [])

  useEffect(() => {
    mounted.current = true
    void load(false)
    const timer = setInterval(() => { void load(false) }, intervalMs.current)
    return () => {
      mounted.current = false
      clearInterval(timer)
    }
  }, [load])

  const onRefresh = useCallback(() => {
    setRefreshing(true)
    void load(true).finally(() => {
      if (mounted.current) setRefreshing(false)
    })
  }, [load])

  // Low-balance alert: visual state + one browser notification per crossing.
  const alert = alertLevelOf(payload)
  const alertActive = alert === 'low' || alert === 'critical'
  useEffect(() => {
    if (payload === null) return
    if (alertActive && !alertedRef.current) {
      alertedRef.current = true
      const value = balanceValue(payload)
      if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
        try {
          new Notification(t('alert.title'), {
            body: t('alert.body', { balance: `${value.toFixed(2)} ${payload.balance.infos[0]?.currency ?? ''}`.trim() }),
          })
        } catch {
          // Notification construction can throw on some platforms — non-fatal.
        }
      }
    } else if (!alertActive) {
      alertedRef.current = false
    }
  }, [alertActive, payload, t])

  const segments: ReactElement[] = []
  const showBalance = payload?.display.showBalance ?? true
  const showTokens = payload?.display.showTokens ?? true
  const showCost = payload?.display.showCost ?? true

  if (payload !== null) {
    const balance = payload.balance.infos[0]
    if (showBalance) {
      const text = payload.balance.ok && balance !== undefined
        ? `${balance.totalBalance} ${balance.currency}`
        : (payload.balance.error ?? t('dock.balanceUnavailable'))
      segments.push(
        <span
          key="balance"
          style={{ ...segment, color: alertActive ? ALERT_COLOR[alert] : undefined }}
          title={
            alertActive
              ? t('alert.tooltip', { threshold: String(payload.alertThreshold), balance: text })
              : t('dock.balance')
          }
        >
          <span style={label}>{t('dock.balance')}</span>
          <span>{alertActive ? `⚠ ${text}` : text}</span>
        </span>,
      )
    }
    segments.push(
      <span key="requests" style={segment} title={t('dock.requests')}>
        <span style={label}>{t('dock.requests')}</span>
        <span>
          {t('dock.todayRequests', { count: String(payload.usage.today.requests) })}
          {payload.usage.rolling.requests > 0
            ? ` · ${t('dock.rollingRequests', { count: String(payload.usage.rolling.requests) })}`
            : ''}
        </span>
      </span>,
    )
    if (showTokens) {
      const today = payload.usage.today
      const cacheRate = payload.cacheHitRate.today
      segments.push(
        <span key="tokens" style={segment} title={t('dock.tokens')}>
          <span style={label}>{t('dock.tokens')}</span>
          <span>
            {formatCount(today.inputTokens)}↑ / {formatCount(today.outputTokens)}↓
            {today.cacheReadTokens > 0
              ? ` / ${formatCount(today.cacheReadTokens)}⚡${cacheRate > 0 ? ` ${cacheRate.toFixed(0)}%` : ''}`
              : ''}
          </span>
        </span>,
      )
    }
    if (showCost) {
      segments.push(
        <span key="cost" style={segment} title={t('dock.cost')}>
          <span style={label}>{t('dock.cost')}</span>
          <span>{formatCny(payload.estimatedCost.today)}</span>
        </span>,
      )
    }
    segments.push(
      <span
        key="updated"
        style={{ ...segment, opacity: 0.6 }}
        title={t('dock.updated', { time: formatTime(payload.serverTime) })}
      >
        {t('dock.updated', { time: formatTime(payload.serverTime) })}
      </span>,
    )
  } else if (error !== null) {
    segments.push(
      <span key="error" style={segment}>
        {t('dock.error', { message: error })}
      </span>,
    )
  } else {
    segments.push(<span key="loading" style={segment}>{t('dock.balance')}…</span>)
  }

  return (
    <div style={row}>
      {segments}
      <button type="button" style={button} onClick={() => { void onRefresh() }} disabled={refreshing}>
        {refreshing ? '…' : t('dock.refresh')}
      </button>
    </div>
  )
}
