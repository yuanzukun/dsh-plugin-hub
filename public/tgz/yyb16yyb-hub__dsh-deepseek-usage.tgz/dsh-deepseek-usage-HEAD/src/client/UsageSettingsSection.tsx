/**
 * The settings-section component (`settings.section`, id `deepseek-usage`):
 * a full usage page inside the settings panel — balance card (with per-key
 * accounts), three-window usage stats, an in-panel config editor that writes
 * back through the host, history/trend heatmap + bars, per-model pricing,
 * per-session drill-down, and CSV exports. Same data path as the dock:
 * same-origin `/dsh-deepseek-usage` polling.
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import type { CSSProperties, ReactElement } from 'react'
import type { PropsLocale, PropsRuntime, TranslateNS } from '@deepseek-ai/dsh-client-ui-slots'
// Type-only: pulls the settings SlotMap merge (the section seat) and the
// runtime's global standard kit (useSessions) into this program.
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-runtime/client'
import {
  alertLevelOf,
  downloadCsv,
  fetchUsage,
  formatCount,
  formatCny,
  formatDateTime,
  saveConfig,
  type EditableConfig,
  type HistoryDay,
  type SessionUsageRow,
  type UsagePayload,
} from './api.ts'
import type { UsageKey } from './locales.ts'

export type UsageSettingsProps = PropsRuntime<'settings.section'> & PropsLocale<'usage'>

const POLL_INTERVAL_MS = 30_000

const card: CSSProperties = {
  border: '1px solid rgba(128,128,128,0.35)',
  borderRadius: 8,
  padding: '10px 12px',
  marginBottom: 12,
}

const title: CSSProperties = {
  fontSize: 13,
  fontWeight: 600,
  margin: '0 0 8px',
}

const grid: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
  gap: 8,
}

const stat: CSSProperties = { display: 'flex', flexDirection: 'column', gap: 2 }

const statLabel: CSSProperties = { fontSize: 11, opacity: 0.6 }

const statValue: CSSProperties = { fontSize: 14, fontWeight: 600 }

const table: CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: 12,
}

const th: CSSProperties = {
  textAlign: 'left',
  padding: '4px 6px',
  borderBottom: '1px solid rgba(128,128,128,0.4)',
  opacity: 0.7,
  fontWeight: 600,
  whiteSpace: 'nowrap',
}

const td: CSSProperties = {
  padding: '4px 6px',
  borderBottom: '1px solid rgba(128,128,128,0.2)',
  whiteSpace: 'nowrap',
}

const button: CSSProperties = {
  border: '1px solid rgba(128,128,128,0.5)',
  background: 'transparent',
  borderRadius: 4,
  padding: '2px 10px',
  cursor: 'pointer',
  fontSize: 12,
}

const hint: CSSProperties = { fontSize: 11, opacity: 0.6, marginTop: 6 }

const input: CSSProperties = {
  border: '1px solid rgba(128,128,128,0.5)',
  borderRadius: 4,
  background: 'transparent',
  padding: '2px 6px',
  fontSize: 12,
  width: '100%',
  boxSizing: 'border-box',
}

const fieldRow: CSSProperties = { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }

const fieldLabel: CSSProperties = { fontSize: 12, minWidth: 150, opacity: 0.8 }

const checkLabel: CSSProperties = { fontSize: 12, display: 'flex', alignItems: 'center', gap: 6 }

const ALERT_COLOR = { low: '#b8860b', critical: '#b3261e' } as const

function localDayKeyOf(date: Date): string {
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${date.getFullYear()}-${month}-${day}`
}

/** GitHub-style daily-request heatmap over the last `weeks` weeks. */
function Heatmap({ history, weeks = 15, t }: { history: HistoryDay[]; weeks?: number; t: TranslateNS<'usage'> }): ReactElement {
  const byDay = new Map(history.map((h) => [h.day, h.requests]))
  const today = new Date()
  const dow = (today.getDay() + 6) % 7 // 0 = Monday
  const currentMonday = new Date(today)
  currentMonday.setDate(today.getDate() - dow)
  const start = new Date(currentMonday)
  start.setDate(currentMonday.getDate() - (weeks - 1) * 7)
  const max = Math.max(1, ...history.map((h) => h.requests))
  const cell: CSSProperties = {
    width: 10,
    height: 10,
    borderRadius: 2,
    margin: 1,
  }
  const columns: ReactElement[] = []
  for (let w = 0; w < weeks; w++) {
    const cells: ReactElement[] = []
    for (let d = 0; d < 7; d++) {
      const date = new Date(start)
      date.setDate(start.getDate() + w * 7 + d)
      const key = localDayKeyOf(date)
      const requests = byDay.get(key) ?? 0
      cells.push(
        <div
          key={key}
          style={{
            ...cell,
            background: requests === 0
              ? 'rgba(128,128,128,0.15)'
              : `rgba(46,160,67,${0.25 + 0.75 * (requests / max)})`,
          }}
          title={`${key}: ${requests}`}
        />,
      )
    }
    columns.push(
      <div key={w} style={{ display: 'flex', flexDirection: 'column' }}>
        {cells}
      </div>,
    )
  }
  return (
    <div>
      <div style={{ display: 'flex', flexDirection: 'row', gap: 1, flexWrap: 'wrap' }}>{columns}</div>
      <p style={hint}>{t('settings.heatmapTip', { weeks: String(weeks) })}</p>
    </div>
  )
}

/** Last-30-days bars: day, request count bar, tokens, cost. */
function HistoryBars({ history, t }: { history: HistoryDay[]; t: TranslateNS<'usage'> }): ReactElement {
  const last30 = history.slice(-30)
  const max = Math.max(1, ...last30.map((h) => h.requests))
  const barTrack: CSSProperties = {
    flex: 1,
    background: 'rgba(128,128,128,0.15)',
    borderRadius: 2,
    height: 10,
    overflow: 'hidden',
  }
  return (
    <div>
      {last30.map((h) => (
        <div key={h.day} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3, fontSize: 11 }}>
          <span style={{ minWidth: 72, opacity: 0.7 }}>{h.day.slice(5)}</span>
          <div style={barTrack}>
            <div
              style={{
                height: '100%',
                width: `${Math.max(2, (h.requests / max) * 100)}%`,
                background: 'rgba(46,160,67,0.7)',
                borderRadius: 2,
              }}
            />
          </div>
          <span style={{ minWidth: 40, textAlign: 'right' }}>{h.requests}</span>
          <span style={{ minWidth: 70, textAlign: 'right', opacity: 0.7 }}>
            {formatCount(h.inputTokens)}↑/{formatCount(h.outputTokens)}↓
          </span>
          <span style={{ minWidth: 52, textAlign: 'right', opacity: 0.7 }}>{formatCny(h.costCny)}</span>
        </div>
      ))}
    </div>
  )
}

function SessionTable({ rows, byTitle, t }: {
  rows: SessionUsageRow[]
  byTitle: (id: string) => string
  t: (key: UsageKey, params?: Record<string, unknown>) => string
}): ReactElement {
  if (rows.length === 0) {
    return <p style={hint}>{t('session.empty')}</p>
  }
  return (
    <table style={table}>
      <thead>
        <tr>
          <th style={th}>{t('session.id')}</th>
          <th style={th}>{t('session.requests')}</th>
          <th style={th}>{t('session.input')}</th>
          <th style={th}>{t('session.output')}</th>
          <th style={th}>{t('session.cache')}</th>
          <th style={th}>{t('session.last')}</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((row) => (
          <tr key={row.sessionId}>
            <td style={td} title={row.sessionId}>{byTitle(row.sessionId)}</td>
            <td style={td}>{row.requests}{row.failedRequests > 0 ? ` (${row.failedRequests}✗)` : ''}</td>
            <td style={td}>{formatCount(row.inputTokens)}</td>
            <td style={td}>{formatCount(row.outputTokens)}</td>
            <td style={td}>{formatCount(row.cacheReadTokens)}</td>
            <td style={td}>{formatDateTime(row.lastAt)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

function ConfigEditor({ initial, t, onSaved }: {
  initial: EditableConfig
  t: (key: UsageKey, params?: Record<string, unknown>) => string
  onSaved: () => void
}): ReactElement {
  const [draft, setDraft] = useState<EditableConfig>(initial)
  const [state, setState] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle')
  const [error, setError] = useState<string | null>(null)
  const set = <K extends keyof EditableConfig>(key: K, value: EditableConfig[K]): void => {
    setDraft((d) => ({ ...d, [key]: value }))
    setState('idle')
  }
  const setPricing = (model: string, key: 'input' | 'output' | 'cacheRead', value: number): void => {
    setDraft((d) => ({
      ...d,
      pricing: {
        ...d.pricing,
        [model]: { ...(d.pricing[model] ?? { input: 0, output: 0, cacheRead: 0 }), [key]: value },
      },
    }))
    setState('idle')
  }
  const onOffPeakHours = (text: string): void => {
    const hours = text.split(',')
      .map((part) => Number.parseInt(part.trim(), 10))
      .filter((n) => !Number.isNaN(n) && n >= 0 && n <= 23)
    set('offPeakHours', hours)
  }

  const save = useCallback(async () => {
    setState('saving')
    setError(null)
    try {
      const updated = await saveConfig({ ...draft })
      setDraft(updated)
      setState('saved')
      onSaved()
      setTimeout(() => setState('idle'), 2000)
    } catch (cause) {
      setState('error')
      setError(cause instanceof Error ? cause.message : String(cause))
    }
  }, [draft, onSaved])

  return (
    <div>
      <div style={fieldRow}>
        <span style={fieldLabel}>{t('settings.pollInterval')}</span>
        <input
          style={{ ...input, width: 110 }}
          type="number"
          min={5000}
          step={5000}
          value={draft.pollIntervalMs}
          onChange={(e) => set('pollIntervalMs', Math.max(5000, Number(e.target.value) || 5000))}
        />
      </div>
      <div style={fieldRow}>
        <span style={fieldLabel}>{t('settings.alertThresholdLabel')}</span>
        <input
          style={{ ...input, width: 110 }}
          type="number"
          min={0}
          step={1}
          value={draft.alertThreshold}
          onChange={(e) => set('alertThreshold', Math.max(0, Number(e.target.value) || 0))}
        />
      </div>
      <div style={fieldRow}>
        <span style={fieldLabel}>{t('settings.offPeakHours')}</span>
        <input
          style={{ ...input, width: 220 }}
          value={draft.offPeakHours.join(',')}
          onChange={(e) => onOffPeakHours(e.target.value)}
        />
      </div>
      <div style={fieldRow}>
        <span style={fieldLabel}>{t('settings.offPeakDiscount')}</span>
        <input
          style={{ ...input, width: 110 }}
          type="number"
          min={0}
          max={1}
          step={0.05}
          value={draft.offPeakDiscount}
          onChange={(e) => set('offPeakDiscount', Math.min(1, Math.max(0, Number(e.target.value) || 0)))}
        />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 4, marginBottom: 8 }}>
        {(['showBalance', 'showTokens', 'showCost', 'blockOnLowBalance'] as const).map((key) => (
          <label key={key} style={checkLabel}>
            <input
              type="checkbox"
              checked={draft[key]}
              onChange={(e) => set(key, e.target.checked)}
            />
            {t(`settings.${key === 'blockOnLowBalance' ? 'blockLowBalance' : key}`)}
          </label>
        ))}
      </div>
      <div style={{ marginBottom: 8 }}>
        <p style={{ ...statLabel, margin: '0 0 4px' }}>{t('settings.pricingEditTitle')}</p>
        {Object.entries(draft.pricing).length === 0
          ? <p style={hint}>{t('settings.pricingNote')}</p>
          : (
            <table style={table}>
              <thead>
                <tr>
                  <th style={th}>{t('settings.model')}</th>
                  <th style={th}>in</th>
                  <th style={th}>out</th>
                  <th style={th}>cache</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(draft.pricing).map(([model, price]) => (
                  <tr key={model}>
                    <td style={td}>{model}</td>
                    {(['input', 'output', 'cacheRead'] as const).map((key) => (
                      <td key={key} style={td}>
                        <input
                          style={{ ...input, width: 64 }}
                          type="number"
                          min={0}
                          step={0.1}
                          value={price[key]}
                          onChange={(e) => setPricing(model, key, Math.max(0, Number(e.target.value) || 0))}
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          )}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <button type="button" style={button} onClick={() => { void save() }} disabled={state === 'saving'}>
          {state === 'saving' ? t('settings.saving') : t('settings.save')}
        </button>
        {state === 'saved' ? <span style={{ ...hint, marginTop: 0, color: '#2e9e44' }}>{t('settings.saved')}</span> : null}
        {state === 'error' && error !== null
          ? <span style={{ ...hint, marginTop: 0, color: ALERT_COLOR.critical }}>{t('settings.saveError', { message: error })}</span>
          : null}
      </div>
      <p style={hint}>{t('settings.configHint')}</p>
    </div>
  )
}

export function UsageSettingsSection(props: UsageSettingsProps): ReactElement {
  const { t } = props
  const [payload, setPayload] = useState<UsagePayload | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [refreshing, setRefreshing] = useState(false)
  const mounted = useRef(true)
  const intervalMs = useRef(POLL_INTERVAL_MS)
  // Global standard kit: session list for title resolution.
  const byId = props.useSessions((state) => state.byId)

  const load = useCallback(async (force: boolean): Promise<void> => {
    try {
      setError(null)
      const data = await fetchUsage(force)
      if (!mounted.current) return
      setPayload(data)
      if (data.pollIntervalMs > 0) intervalMs.current = data.pollIntervalMs
    } catch (cause) {
      if (!mounted.current) return
      setError(cause instanceof Error ? cause.message : String(cause))
    }
  }, [])

  useEffect(() => {
    mounted.current = true
    void load(false)
    const timer = setInterval(() => { void load(false) }, intervalMs.current)
    return () => {
      mounted.current = false
      clearInterval(timer)
    }
  }, [load])

  const onRefresh = useCallback(() => {
    setRefreshing(true)
    void load(true).finally(() => {
      if (mounted.current) setRefreshing(false)
    })
  }, [load])

  const byTitle = useCallback((id: string): string => {
    return byId[id as SessionId]?.displayTitle ?? id.slice(0, 12)
  }, [byId])

  const alert = alertLevelOf(payload)
  const balance = payload?.balance.infos[0]
  const balanceText = payload?.balance.ok === true && balance !== undefined
    ? `${balance.totalBalance} ${balance.currency}`
    : (payload?.balance.error ?? t('dock.balanceUnavailable'))

  const exportHistory = useCallback(() => {
    if (payload === null) return
    downloadCsv(
      'deepseek-usage-history.csv',
      ['day', 'requests', 'inputTokens', 'outputTokens', 'cacheReadTokens', 'costCny'],
      payload.history.map((h) => [h.day, h.requests, h.inputTokens, h.outputTokens, h.cacheReadTokens, h.costCny]),
    )
  }, [payload])

  const exportSessions = useCallback(() => {
    if (payload === null) return
    downloadCsv(
      'deepseek-usage-sessions.csv',
      ['sessionId', 'requests', 'failedRequests', 'inputTokens', 'outputTokens', 'cacheReadTokens', 'lastAt'],
      payload.bySession.map((s) => [s.sessionId, s.requests, s.failedRequests, s.inputTokens, s.outputTokens, s.cacheReadTokens, s.lastAt]),
    )
  }, [payload])

  return (
    <div>
      {/* Balance card */}
      <div style={card}>
        <h3 style={title}>
          {t('settings.balanceTitle')}
          {alert === 'low' || alert === 'critical'
            ? <span style={{ color: ALERT_COLOR[alert] }}> ⚠ {t('alert.short')}</span>
            : null}
        </h3>
        <div style={grid}>
          <div style={stat}>
            <span style={statLabel}>{t('settings.totalBalance')}</span>
            <span style={{ ...statValue, color: alert === 'critical' ? ALERT_COLOR.critical : undefined }}>
              {balanceText}
            </span>
          </div>
          <div style={stat}>
            <span style={statLabel}>{t('settings.granted')}</span>
            <span style={statValue}>{balance !== undefined ? `${balance.grantedBalance} ${balance.currency}` : '—'}</span>
          </div>
          <div style={stat}>
            <span style={statLabel}>{t('settings.toppedUp')}</span>
            <span style={statValue}>{balance !== undefined ? `${balance.toppedUpBalance} ${balance.currency}` : '—'}</span>
          </div>
          <div style={stat}>
            <span style={statLabel}>{t('settings.status')}</span>
            <span style={statValue}>
              {payload?.balance.ok === true
                ? (payload.balance.isAvailable ? t('settings.available') : t('settings.unavailable'))
                : t('settings.unknown')}
            </span>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8 }}>
          <button type="button" style={button} onClick={() => { void onRefresh() }} disabled={refreshing}>
            {refreshing ? '…' : t('dock.refresh')}
          </button>
          {payload !== null
            ? <span style={hint}>{t('dock.updated', { time: formatDateTime(payload.serverTime) })}</span>
            : null}
        </div>
        {payload?.balance.accounts !== undefined && payload.balance.accounts.length > 1
          ? (
            <div style={{ marginTop: 8 }}>
              <p style={{ ...statLabel, margin: '0 0 4px' }}>{t('settings.accountsTitle')}</p>
              <table style={table}>
                <thead>
                  <tr>
                    <th style={th}>{t('settings.account')}</th>
                    <th style={th}>{t('settings.accountTotal')}</th>
                    <th style={th}>{t('settings.granted')}</th>
                    <th style={th}>{t('settings.toppedUp')}</th>
                    <th style={th}>{t('settings.status')}</th>
                  </tr>
                </thead>
                <tbody>
                  {payload.balance.accounts.map((account) => (
                    <tr key={account.label}>
                      <td style={td}>{account.label}</td>
                      <td style={td}>{account.totalBalance} {account.currency}</td>
                      <td style={td}>{account.grantedBalance}</td>
                      <td style={td}>{account.toppedUpBalance}</td>
                      <td style={td}>
                        {account.ok
                          ? (account.isAvailable ? t('settings.available') : t('settings.unavailable'))
                          : (account.error ?? t('settings.unknown'))}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
          : null}
      </div>

      {/* Usage windows */}
      <div style={card}>
        <h3 style={title}>{t('settings.usageTitle')}</h3>
        <div style={grid}>
          {(['total', 'today', 'rolling'] as const).map((key) => {
            const w = payload?.usage[key]
            const cacheRate = payload?.cacheHitRate[key]
            return (
              <div key={key} style={stat}>
                <span style={statLabel}>{t(`settings.window.${key}`)}</span>
                <span style={statValue}>{w?.requests ?? 0} {t('settings.requestsUnit')}</span>
                <span style={hint}>
                  {w !== undefined
                    ? `${formatCount(w.inputTokens)}↑ / ${formatCount(w.outputTokens)}↓ / ${formatCount(w.cacheReadTokens)}⚡${cacheRate !== undefined && cacheRate > 0 ? ` ${cacheRate.toFixed(1)}%` : ''}`
                    : '—'}
                </span>
              </div>
            )
          })}
        </div>
        {payload !== null && payload.display.showCost
          ? (
            <p style={hint}>
              {t('settings.estimatedCost', { cost: formatCny(payload.estimatedCost.today) })}
            </p>
          )
          : null}
      </div>

      {/* History & trends */}
      <div style={card}>
        <h3 style={{ ...title, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          {t('settings.historyTitle')}
          <button type="button" style={button} onClick={exportHistory} disabled={payload?.history.length === 0}>
            {t('settings.exportCsv')}
          </button>
        </h3>
        {payload === null || payload.history.length === 0
          ? <p style={hint}>{t('settings.historyEmpty')}</p>
          : (
            <>
              <Heatmap history={payload.history} t={t} />
              <div style={{ marginTop: 10 }}>
                <HistoryBars history={payload.history} t={t} />
              </div>
            </>
          )}
      </div>

      {/* Settings editor */}
      {payload !== null
        ? (
          <div style={card}>
            <h3 style={title}>{t('settings.configTitle')}</h3>
            <ConfigEditor initial={payload.config} t={t} onSaved={() => { void load(false) }} />
          </div>
        )
        : null}

      {/* Per-model cost breakdown */}
      {payload?.pricing !== undefined && Object.keys(payload.pricing).length > 0
        ? (
          <div style={card}>
            <h3 style={title}>{t('settings.pricingTitle')}</h3>
            <table style={table}>
              <thead>
                <tr>
                  <th style={th}>{t('settings.model')}</th>
                  <th style={th}>{t('settings.requestsUnit')}</th>
                  <th style={th}>¥/M in</th>
                  <th style={th}>¥/M out</th>
                  <th style={th}>¥/M cache</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(payload.pricing).map(([model, price]) => {
                  const usage = payload.usage.byModel[model]
                  return (
                    <tr key={model}>
                      <td style={td}>{model}</td>
                      <td style={td}>{usage?.requests ?? 0}</td>
                      <td style={td}>{price.input}</td>
                      <td style={td}>{price.output}</td>
                      <td style={td}>{price.cacheRead}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
            <p style={hint}>{t('settings.pricingNote')}</p>
          </div>
        )
        : null}

      {/* Per-session drill-down */}
      <div style={card}>
        <h3 style={{ ...title, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          {t('settings.sessionsTitle')}
          <button type="button" style={button} onClick={exportSessions} disabled={payload?.bySession.length === 0}>
            {t('settings.exportCsv')}
          </button>
        </h3>
        <SessionTable rows={payload?.bySession ?? []} byTitle={byTitle} t={t} />
      </div>

      {error !== null ? <p style={{ color: ALERT_COLOR.critical }}>{t('dock.error', { message: error })}</p> : null}
    </div>
  )
}
