/**
 * Persistence for usage history: daily windows, all-time totals, per-model
 * maps and per-session usage, plus user config overrides from the settings
 * panel editor. Stored as one JSON file under the dsh home
 * (`$DSH_HOME/deepseek-usage/usage.json`, default `~/.dsh/...`). Writes are
 * atomic (tmp file + rename) and debounced by the caller.
 */
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import type { ModelUsage, SessionUsage, UsageWindow } from './stats.ts'

export interface PersistedState {
  version: 1
  total: UsageWindow
  byDay: Record<string, UsageWindow>
  byModel: Record<string, ModelUsage>
  byModelByDay: Record<string, Record<string, ModelUsage>>
  bySession: Record<string, SessionUsage>
  firstRequestAt?: number
  lastRequestAt?: number
  /** User config overrides written through the settings panel editor. */
  config?: Record<string, unknown>
}

export const PERSIST_VERSION = 1 as const

export class Persistence {
  constructor(private readonly file: string) {}

  /** Read and validate the persisted state; undefined when absent or corrupt. */
  async load(): Promise<PersistedState | undefined> {
    try {
      const raw = await readFile(this.file, 'utf8')
      const parsed = JSON.parse(raw) as PersistedState
      if (parsed?.version !== PERSIST_VERSION) return undefined
      if (typeof parsed.total?.requests !== 'number') return undefined
      return parsed
    } catch {
      return undefined
    }
  }

  /** Atomically persist the state; failures are swallowed (never fatal). */
  async save(state: PersistedState): Promise<void> {
    try {
      await mkdir(dirname(this.file), { recursive: true })
      const tmp = `${this.file}.tmp`
      await writeFile(tmp, JSON.stringify(state), 'utf8')
      await rename(tmp, this.file)
    } catch (error) {
      // Persistence must never take the plugin down.
      console.warn('[deepseek-usage] persist failed:', error instanceof Error ? error.message : String(error))
    }
  }
}
