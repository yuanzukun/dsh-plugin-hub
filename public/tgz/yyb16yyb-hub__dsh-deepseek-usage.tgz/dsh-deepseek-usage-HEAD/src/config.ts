/**
 * Plugin configuration. Doubles as the `deepseek-usage` user-settings
 * section shape (schemastery). Every field is optional in yml.
 */
import z from '@deepseek-ai/schemastery'

export interface Config {
  /** Explicit API key; highest priority. Never logged. */
  apiKey?: string
  /** Env var name holding the key; defaults to DEEPSEEK_API_KEY. */
  apiKeyEnv?: string
  /** DeepSeek API base; defaults to https://api.deepseek.com. */
  baseURL?: string
  /** Balance poll interval in ms; defaults to 30s (min 5s). */
  pollIntervalMs?: number
  /** Balance fetch timeout in ms; defaults to 10s. */
  balanceTimeoutMs?: number
  /** Show the balance segment in the Web dock. */
  showBalance?: boolean
  /** Show the token segment in the Web dock. */
  showTokens?: boolean
  /** Show the estimated-cost segment in the Web dock. */
  showCost?: boolean
  /**
   * Low-balance alert threshold in the account's currency; the dock turns
   * amber below it and red below threshold/5, and may send one browser
   * notification per crossing. 0 disables alerts. Defaults to 20.
   */
  alertThreshold?: number
  /** Max sessions kept in the per-session drill-down; defaults to 200. */
  maxSessions?: number
  /**
   * Additional API keys whose balances are fetched and aggregated with the
   * primary key (multi-account overview). Keys are never logged.
   */
  apiKeys?: string[]
  /**
   * When enabled, LLM requests are blocked while the aggregated balance is
   * below `alertThreshold` (opt-in — the error surfaces to the agent).
   * Defaults to false.
   */
  blockOnLowBalance?: boolean
  /**
   * Local hours (0–23) treated as off-peak for the cost estimate; cache-miss
   * input/output prices are multiplied by `offPeakDiscount` in those hours.
   * Defaults to 00:00–07:59 (approximation of DeepSeek's off-peak window).
   */
  offPeakHours?: number[]
  /** Off-peak multiplier applied to cache-miss prices; defaults to 0.5. */
  offPeakDiscount?: number
  /**
   * Model id -> {input, output, cacheRead} prices in ¥ per 1M tokens, used
   * for the estimated cost readout. Missing models fall back to the
   * built-in table.
   */
  pricing?: Record<string, { input?: number; output?: number; cacheRead?: number }>
}

export const Config = z.object({
  apiKey: z.string(),
  apiKeyEnv: z.string(),
  baseURL: z.string().default('https://api.deepseek.com'),
  pollIntervalMs: z.natural().min(5000).default(30000),
  balanceTimeoutMs: z.natural().default(10000),
  showBalance: z.boolean().default(true),
  showTokens: z.boolean().default(true),
  showCost: z.boolean().default(true),
  alertThreshold: z.number().default(20),
  maxSessions: z.natural().default(200),
  apiKeys: z.array(z.string()),
  blockOnLowBalance: z.boolean().default(false),
  offPeakHours: z.array(z.natural().max(23)).default([0, 1, 2, 3, 4, 5, 6, 7]),
  offPeakDiscount: z.number().min(0).max(1).default(0.5),
  pricing: z.dict(z.object({
    input: z.number().default(2),
    output: z.number().default(3),
    cacheRead: z.number().default(0.5),
  })),
})

export const DEFAULT_POLL_INTERVAL_MS = 30_000
export const DEFAULT_BASE_URL = 'https://api.deepseek.com'
export const DEFAULT_API_KEY_ENV = 'DEEPSEEK_API_KEY'
export const DEFAULT_ALERT_THRESHOLD = 20

/**
 * Built-in pricing table (¥ per 1M tokens), merged under user `pricing`.
 * Used only for the explicitly-labelled "estimated" cost readout — figures
 * are approximate and the table is editable via plugin config.
 */
export const DEFAULT_PRICING: Readonly<Record<string, { input: number; output: number; cacheRead: number }>> = {
  'deepseek-chat': { input: 2, output: 3, cacheRead: 0.5 },
  'deepseek-reasoner': { input: 4, output: 16, cacheRead: 1 },
}
