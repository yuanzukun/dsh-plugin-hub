﻿/**
 * Connection manager tests: define/open/close lifecycle, reuse, duplicates,
 * lazy credential resolution, and redacted status output.
 */

import { strict as assert } from 'node:assert';
import { join } from 'node:path';
import { test } from 'node:test';
import { DbConnectorError, ErrorCode } from '../dist/errors.js';
import type { DriverApi } from '../dist/drivers/driver.js';
import { makeHarness } from './helpers.ts';

function deferred<T>(): { promise: Promise<T>; resolve(value: T): void } {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((done) => {
    resolve = done;
  });
  return { promise, resolve };
}

function nextTurn(): Promise<void> {
  return new Promise((resolve) => setImmediate(resolve));
}

function makeFakeDriver(
  onConnect: () => Promise<void> = async () => {},
  onClose: () => Promise<void> = async () => {},
): DriverApi {
  return {
    kind: 'sqlite',
    connect: onConnect,
    async read() {
      return { columns: [], rows: [], rowCount: 0 };
    },
    async write() {
      return { affectedRows: 0, isDdl: false };
    },
    async introspect() {
      return { tables: [], views: [], columns: [], indexes: [], foreignKeys: [] };
    },
    close: onClose,
  };
}

function installDriver(h: ReturnType<typeof makeHarness>, driver: DriverApi): void {
  (h.connectors as unknown as {
    buildDriver(spec: unknown): DriverApi;
  }).buildDriver = () => driver;
}

function getOpenWaiters(h: ReturnType<typeof makeHarness>, name: string): Set<() => void> {
  return (h.connectors as unknown as {
    map: Map<string, { openWaiters: Set<() => void> }>;
  }).map.get(name)!.openWaiters;
}

test('list is empty initially; define+open shows connected', async () => {
  const h = makeHarness();
  assert.deepEqual(h.connectors.list(), []);
  h.connectors.define({ name: 'a', driver: 'sqlite', database: join(h.dir, 'a.sqlite') });
  assert.equal(h.connectors.list()[0]!.status, 'defined');
  await h.connectors.open('a');
  const status = h.connectors.list()[0]!;
  assert.equal(status.status, 'connected');
  assert.ok(status.openedAt);
});

test('lazy open resolves environment-backed settings after definition', async () => {
  const h = makeHarness();
  const env: NodeJS.ProcessEnv = {};
  const database = join(h.dir, 'late.sqlite');
  let builtSpec: { database?: string } | undefined;
  (h.connectors as unknown as {
    buildDriver(spec: { database?: string }): DriverApi;
  }).buildDriver = (spec) => {
    builtSpec = spec;
    return makeFakeDriver();
  };

  h.connectors.define(
    { name: 'lazy-env', driver: 'sqlite', database: '${LAZY_DATABASE}' },
    env,
  );
  env.LAZY_DATABASE = database;

  await h.connectors.open('lazy-env');
  assert.equal(builtSpec?.database, database);
});

test('duplicate definition is refused', () => {
  const h = makeHarness();
  h.connectors.define({ name: 'a', driver: 'sqlite' });
  assert.throws(
    () => h.connectors.define({ name: 'a', driver: 'sqlite' }),
    (e: DbConnectorError) => e.code === 'CONNECTION_EXISTS',
  );
});

test('open on unknown name raises CONNECTION_NOT_FOUND', async () => {
  const h = makeHarness();
  await assert.rejects(
    h.connectors.open('nope'),
    (e: DbConnectorError) => e.code === 'CONNECTION_NOT_FOUND',
  );
});

test('open is idempotent and shared by concurrent callers', async () => {
  const h = makeHarness();
  h.connectors.define({ name: 'a', driver: 'sqlite', database: join(h.dir, 'a.sqlite') });
  const [d1, d2] = await Promise.all([h.connectors.open('a'), h.connectors.open('a')]);
  assert.equal(d1, d2);
});

test('cancelling one shared open waiter does not cancel the underlying open', async () => {
  const h = makeHarness();
  const connectStarted = deferred<void>();
  const releaseConnect = deferred<void>();
  let connectCalls = 0;
  let receivedSignal: AbortSignal | undefined;
  const driver: DriverApi = {
    kind: 'sqlite',
    connect: async (signal) => {
      connectCalls += 1;
      receivedSignal = signal;
      connectStarted.resolve();
      await releaseConnect.promise;
      if (signal?.aborted) throw new Error('shared open was cancelled');
    },
    async read() {
      return { columns: [], rows: [], rowCount: 0 };
    },
    async write() {
      return { affectedRows: 0, isDdl: false };
    },
    async introspect() {
      return { tables: [], views: [], columns: [], indexes: [], foreignKeys: [] };
    },
    async close() {},
  };
  installDriver(h, driver);
  h.connectors.define({ name: 'shared-open', driver: 'sqlite' });

  const firstController = new AbortController();
  const first = h.connectors.open('shared-open', undefined, firstController.signal);
  await connectStarted.promise;
  const second = h.connectors.open('shared-open', undefined, new AbortController().signal);

  firstController.abort();
  await assert.rejects(
    first,
    (error: unknown) => error instanceof DbConnectorError && error.code === ErrorCode.Cancelled,
  );
  assert.ok(receivedSignal);
  assert.equal(receivedSignal.aborted, false);

  releaseConnect.resolve();
  const opened = await second;
  assert.equal(opened, driver);
  assert.equal(connectCalls, 1);
  await h.connectors.close('shared-open');
});

test('an aborted reconnect discards the closed driver before the next open', async () => {
  const h = makeHarness();
  const reconnectStarted = deferred<void>();
  const releaseReconnect = deferred<void>();
  let builds = 0;
  let firstDriverClosed = false;
  const firstDriver: DriverApi = {
    kind: 'mysql',
    connect: async (signal) => {
      reconnectStarted.resolve();
      await releaseReconnect.promise;
      if (signal?.aborted) throw new Error('reconnect was cancelled');
    },
    async read() {
      return { columns: [], rows: [], rowCount: 0 };
    },
    async write() {
      return { affectedRows: 0, isDdl: false };
    },
    async introspect() {
      return { tables: [], views: [], columns: [], indexes: [], foreignKeys: [] };
    },
    async close() {
      firstDriverClosed = true;
    },
  };
  const freshDriver = { ...firstDriver, connect: async () => {} };
  (h.connectors as unknown as {
    buildDriver(spec: unknown): DriverApi;
  }).buildDriver = () => {
    builds += 1;
    return freshDriver;
  };
  h.connectors.define({ name: 'reconnect', driver: 'mysql', database: 'test' });
  const record = (h.connectors as unknown as {
    map: Map<string, { driver: DriverApi | null; status: string }>;
  }).map.get('reconnect');
  assert.ok(record);
  record.driver = firstDriver;
  record.status = 'connected';

  const controller = new AbortController();
  const reconnect = h.connectors.open('reconnect', undefined, controller.signal);
  await reconnectStarted.promise;
  controller.abort();
  releaseReconnect.resolve();
  await assert.rejects(
    reconnect,
    (error: unknown) => error instanceof DbConnectorError && error.code === ErrorCode.Cancelled,
  );
  assert.equal(firstDriverClosed, true);

  const opened = await h.connectors.open('reconnect');
  assert.equal(opened, freshDriver);
  assert.equal(builds, 1);
});

test('close removes the connection; closeAll clears everything', async () => {
  const h = makeHarness();
  h.connectors.define({ name: 'a', driver: 'sqlite', database: join(h.dir, 'a.sqlite') });
  h.connectors.define({ name: 'b', driver: 'sqlite', database: join(h.dir, 'b.sqlite') });
  await h.connectors.open('a');
  await h.connectors.close('a');
  assert.equal(h.connectors.has('a'), false);
  await h.connectors.open('b');
  await h.connectors.closeAll();
  assert.deepEqual(h.connectors.list(), []);
  assert.equal(h.connectors.has('b'), false);
});

test('closeAll blocks new definitions until teardown finishes', async () => {
  const h = makeHarness();
  const closeStarted = deferred<void>();
  const releaseClose = deferred<void>();
  installDriver(h, makeFakeDriver(async () => {}, async () => {
    closeStarted.resolve();
    await releaseClose.promise;
  }));
  h.connectors.define({ name: 'a', driver: 'sqlite' });
  await h.connectors.open('a');

  const closing = h.connectors.closeAll();
  await closeStarted.promise;
  assert.throws(
    () => h.connectors.define({ name: 'b', driver: 'sqlite' }),
    (e: DbConnectorError) => e.code === ErrorCode.ConnectionNotFound,
  );

  releaseClose.resolve();
  await closing;
  h.connectors.define({ name: 'b', driver: 'sqlite' });
  assert.equal(h.connectors.has('b'), true);
  await h.connectors.close('b');
});

test('close cancels a pending open waiter and closes its driver', async () => {
  const h = makeHarness();
  const openingStarted = deferred<void>();
  const releaseOpening = deferred<void>();
  let closeCalls = 0;
  installDriver(h, makeFakeDriver(async () => {
    openingStarted.resolve();
    await releaseOpening.promise;
  }, async () => {
    closeCalls += 1;
  }));
  h.connectors.define({ name: 'a', driver: 'sqlite' });
  const opening = h.connectors.open('a');
  await openingStarted.promise;

  let closeFinished = false;
  const closing = h.connectors.close('a').then(() => {
    closeFinished = true;
  });
  const openingRejected = assert.rejects(
    opening,
    (e: DbConnectorError) => e.code === 'CONNECTION_NOT_FOUND',
  );
  await openingRejected;
  assert.equal(closeFinished, false);
  releaseOpening.resolve();
  await closing;
  assert.equal(closeCalls, 1);
  assert.equal(h.connectors.has('a'), false);
});

test('closeAll cancels a pending open waiter and closes its driver', async () => {
  const h = makeHarness();
  const openingStarted = deferred<void>();
  const releaseOpening = deferred<void>();
  let closeCalls = 0;
  installDriver(h, makeFakeDriver(async () => {
    openingStarted.resolve();
    await releaseOpening.promise;
  }, async () => {
    closeCalls += 1;
  }));
  h.connectors.define({ name: 'a', driver: 'sqlite' });
  const opening = h.connectors.open('a');
  await openingStarted.promise;

  let closeAllFinished = false;
  const closing = h.connectors.closeAll().then(() => {
    closeAllFinished = true;
  });
  const openingRejected = assert.rejects(
    opening,
    (e: DbConnectorError) => e.code === 'CONNECTION_NOT_FOUND',
  );
  await openingRejected;
  assert.equal(closeAllFinished, false);
  releaseOpening.resolve();
  await closing;
  assert.equal(closeCalls, 1);
  assert.deepEqual(h.connectors.list(), []);
});

test('open cannot return a driver while close is in progress', async () => {
  const h = makeHarness();
  const closeStarted = deferred<void>();
  const releaseClose = deferred<void>();
  installDriver(h, makeFakeDriver(async () => {}, async () => {
    closeStarted.resolve();
    await releaseClose.promise;
  }));
  h.connectors.define({ name: 'a', driver: 'sqlite' });
  await h.connectors.open('a');

  const pendingOpen = h.connectors.open('a');
  const concurrentOpen = assert.rejects(
    pendingOpen,
    (e: DbConnectorError) => e.code === 'CONNECTION_NOT_FOUND',
  );
  const closing = h.connectors.close('a');
  await closeStarted.promise;

  releaseClose.resolve();
  await Promise.all([closing, concurrentOpen]);
});

test('open cannot return a driver while closeAll is in progress', async () => {
  const h = makeHarness();
  const closeStarted = deferred<void>();
  const releaseClose = deferred<void>();
  let closeCalls = 0;
  installDriver(h, makeFakeDriver(async () => {}, async () => {
    closeCalls += 1;
    closeStarted.resolve();
    await releaseClose.promise;
  }));
  h.connectors.define({ name: 'a', driver: 'sqlite' });
  await h.connectors.open('a');

  const pendingOpen = h.connectors.open('a');
  const concurrentOpen = assert.rejects(
    pendingOpen,
    (e: DbConnectorError) => e.code === 'CONNECTION_NOT_FOUND',
  );
  const closing = h.connectors.closeAll();
  await closeStarted.promise;

  releaseClose.resolve();
  await Promise.all([closing, concurrentOpen]);
  assert.equal(closeCalls, 1);
});

test('open rejects when close starts after its waiter resolves', async () => {
  const h = makeHarness();
  const closeStarted = deferred<void>();
  const releaseClose = deferred<void>();
  const closeInvoked = deferred<void>();
  let closePromise: Promise<void> | null = null;
  installDriver(h, makeFakeDriver(async () => {}, async () => {
    closeStarted.resolve();
    await releaseClose.promise;
  }));

  const connectors = h.connectors as unknown as {
    waitForOpen(
      rec: unknown,
      opening: Promise<DriverApi>,
    ): Promise<DriverApi>;
  };
  const originalWaitForOpen = connectors.waitForOpen;
  connectors.waitForOpen = (rec, opening) => {
    const waited = originalWaitForOpen.call(h.connectors, rec, opening);
    waited.then(() => {
      closePromise = h.connectors.close('a');
      closeInvoked.resolve();
    });
    return waited;
  };

  h.connectors.define({ name: 'a', driver: 'sqlite' });
  const opening = h.connectors.open('a');
  await assert.rejects(
    opening,
    (e: DbConnectorError) => e.code === 'CONNECTION_NOT_FOUND',
  );
  await closeInvoked.promise;
  await closeStarted.promise;
  releaseClose.resolve();
  const teardown = closePromise;
  assert.ok(teardown);
  await teardown;
  assert.equal(h.connectors.has('a'), false);
});

test('settled opens do not retain teardown waiters', async () => {
  const h = makeHarness();
  installDriver(h, makeFakeDriver());
  h.connectors.define({ name: 'a', driver: 'sqlite' });
  await h.connectors.open('a');

  const waiters = getOpenWaiters(h, 'a');
  assert.equal(waiters.size, 0);
  for (let i = 0; i < 100; i += 1) await h.connectors.open('a');
  assert.equal(waiters.size, 0);
});

test('close reserves the name and shares in-progress teardown', async () => {
  const h = makeHarness();
  const closeStarted = deferred<void>();
  const releaseClose = deferred<void>();
  let closeCalls = 0;
  installDriver(h, makeFakeDriver(async () => {}, async () => {
    closeCalls += 1;
    closeStarted.resolve();
    await releaseClose.promise;
  }));
  h.connectors.define({ name: 'a', driver: 'sqlite' });
  await h.connectors.open('a');

  const firstClose = h.connectors.close('a');
  await closeStarted.promise;
  assert.throws(
    () => h.connectors.define({ name: 'a', driver: 'sqlite' }),
    (e: DbConnectorError) => e.code === 'CONNECTION_EXISTS',
  );

  let secondFinished = false;
  const secondClose = h.connectors.close('a').then(() => {
    secondFinished = true;
  });
  await nextTurn();
  assert.equal(secondFinished, false);

  releaseClose.resolve();
  await Promise.all([firstClose, secondClose]);
  assert.equal(closeCalls, 1);
  assert.equal(h.connectors.has('a'), false);
});

test('closeAll reserves names and shares in-progress teardown', async () => {
  const h = makeHarness();
  const closeStarted = deferred<void>();
  const releaseClose = deferred<void>();
  let closeCalls = 0;
  installDriver(h, makeFakeDriver(async () => {}, async () => {
    closeCalls += 1;
    closeStarted.resolve();
    await releaseClose.promise;
  }));
  h.connectors.define({ name: 'a', driver: 'sqlite' });
  await h.connectors.open('a');

  const firstCloseAll = h.connectors.closeAll();
  await closeStarted.promise;
  assert.throws(
    () => h.connectors.define({ name: 'a', driver: 'sqlite' }),
    (e: DbConnectorError) => e.code === 'CONNECTION_EXISTS',
  );

  let secondFinished = false;
  const secondCloseAll = h.connectors.closeAll().then(() => {
    secondFinished = true;
  });
  await nextTurn();
  assert.equal(secondFinished, false);

  releaseClose.resolve();
  await Promise.all([firstCloseAll, secondCloseAll]);
  assert.equal(closeCalls, 1);
  assert.deepEqual(h.connectors.list(), []);
});

test('touch increments the execution counter and updates last-used', async () => {
  const h = makeHarness();
  h.connectors.define({ name: 'a', driver: 'sqlite', database: join(h.dir, 'a.sqlite') });
  await h.connectors.open('a');
  h.connectors.touch('a');
  h.connectors.touch('a');
  assert.equal(h.connectors.list()[0]!.executions, 2);
  assert.ok(h.connectors.list()[0]!.lastUsedAt);
});

test('failed open (unsupported driver) is surfaced cleanly', async () => {
  const h = makeHarness();
  h.connectors.define({ name: 'x', driver: 'sqlite' });
  // sqlite :memory: always opens; simulate failure with a bogus path is
  // flaky across platforms, so instead assert define-time validation.
  assert.throws(
    () => h.connectors.define({ name: 'bad', driver: 'cassandra' as never }),
    (e: DbConnectorError) => e.code === 'UNSUPPORTED_DRIVER',
  );
});

test('sqlite connections persist state across engines lifecycle', async () => {
  const h = makeHarness();
  const db = join(h.dir, 's.sqlite');
  await h.engine.connect({ name: 's', driver: 'sqlite', database: db });
  await h.engine.exec(
    { connection: 's', sql: 'CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT)', allowWrite: true, way: 'cli' },
    new AbortController().signal,
  );
  await h.engine.exec(
    { connection: 's', sql: "INSERT INTO t(v) VALUES (?)", params: ['kept'], allowWrite: true, way: 'cli' },
    new AbortController().signal,
  );
  // simulate a dropped connection (timeout path) by reopening the file
  await h.engine.close('s');
  await h.engine.connect({ name: 's', driver: 'sqlite', database: db });
  const { rows } = await h.engine.query(
    { connection: 's', sql: 'SELECT v FROM t', way: 'cli' },
    new AbortController().signal,
  );
  assert.deepEqual(rows, [['kept']]);
});

test('open reconnects an existing driver after a dropped connection', async () => {
  const h = makeHarness();
  h.connectors.define({ name: 'mysql', driver: 'mysql', database: 'test' });

  let connected = false;
  let connectCalls = 0;
  const driver: DriverApi = {
    kind: 'mysql',
    connect: async () => {
      connectCalls += 1;
      connected = true;
    },
    read: async () => {
      if (!connected) {
        throw new DbConnectorError(ErrorCode.ConnectionNotFound, 'connection dropped');
      }
      return { columns: [], rows: [], rowCount: 0 };
    },
    write: async (_sql, _params, isDdl) => ({ affectedRows: 0, isDdl }),
    introspect: async () => ({
      tables: [],
      views: [],
      columns: [],
      indexes: [],
      foreignKeys: [],
    }),
    close: async () => {
      connected = false;
    },
  };
  const record = (h.connectors as unknown as {
    map: Map<string, { driver: DriverApi | null; status: string }>;
  }).map.get('mysql');
  assert.ok(record);
  record.driver = driver;
  record.status = 'connected';

  const reopened = await h.connectors.open('mysql');
  assert.equal(reopened, driver);
  assert.equal(connectCalls, 1);
  await reopened.read('SELECT 1', [], new AbortController().signal);
});

test('failed reconnect reports the connection as defined', async () => {
  const h = makeHarness();
  h.connectors.define({ name: 'mysql', driver: 'mysql', database: 'test' });

  let connectCalls = 0;
  const driver: DriverApi = {
    kind: 'mysql',
    connect: async () => {
      connectCalls += 1;
      if (connectCalls === 1) throw new Error('reconnect failed');
    },
    read: async () => ({ columns: [], rows: [], rowCount: 0 }),
    write: async (_sql, _params, isDdl) => ({ affectedRows: 0, isDdl }),
    introspect: async () => ({
      tables: [],
      views: [],
      columns: [],
      indexes: [],
      foreignKeys: [],
    }),
    close: async () => {},
  };
  const record = (h.connectors as unknown as {
    map: Map<string, { driver: DriverApi | null; status: string }>;
  }).map.get('mysql');
  assert.ok(record);
  record.driver = driver;
  record.status = 'connected';

  await assert.rejects(h.connectors.open('mysql'), /reconnect failed/);
  assert.equal(h.connectors.describe('mysql')?.status, 'defined');
  assert.equal(h.connectors.has('mysql'), true);

  await h.connectors.open('mysql');
  assert.equal(h.connectors.describe('mysql')?.status, 'connected');
  assert.equal(connectCalls, 2);
});
