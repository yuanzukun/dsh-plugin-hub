// DshDockLauncher.cs — the single dsh-dock desktop launcher executable.
//
// One native exe replaces the old four-layer chain (.lnk -> wscript ->
// launch-dsh.vbs -> dsh-card.exe/HTA). Everything lives in this one file:
//
//   quick path  : server alive -> read the freshest token line, verify it
//                 really serves HTTP 200 (health gate with a cookie jar —
//                 DSH answers the token URL with 303 + Set-Cookie), then
//                 silently open the fullscreen Edge app window. No card UI.
//   exit race   : a fresh .stopping marker means the server is mid-shutdown;
//                 wait for the port to go down, then treat as cold start.
//   cold start  : show the breathing whale card, settle-probe, take the
//                 single-spawner lock, spawn start-server.cmd, poll, then
//                 open the window the moment the token URL serves 200.
//   stale server: port occupied by a non-responding / stale-token process
//                 (card did not spawn it) -> explicit failure with guidance
//                 instead of a 180 s silent wait.
//
// All paths (log, batch, profile, markers, whale png) come from
// %USERPROFILE%\.dsh\launcher\launcher.ini baked at install time, so the
// binary itself is build-independent — no csc at install, no VBS/HTA fallback.
//
// Compile (scripts/build-launcher.ps1):
//   csc /target:winexe /optimize+ /win32icon:assets/dsh-dock.ico
//       /r:System.Windows.Forms.dll /r:System.Drawing.dll src/DshDockLauncher.cs
//
// Language level: C# 5 (the Windows-bundled .NET Framework 4 csc).

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: System.Reflection.AssemblyTitle("dsh-dock-launcher")]
[assembly: System.Reflection.AssemblyProduct("dsh-dock")]

static class DshDockProgram
{
  public const int PortProbeMs = 700;    // TCP connect timeout for Probe()
  public const int QuickRetries = 10;    // quick path re-scrape attempts
  public const int QuickRetryMs = 500;
  public const int RaceWaitMs = 15000;   // exit/start race absorption window
  public const int MarkerFreshSec = 15;  // .stopping freshness (matches VBS)
  public const int SpawnLockTakeoverSec = 60; // crashed-spawner lock takeover
  public const int HttpTimeoutMs = 1500;
  public const int GateThrottleMs = 600; // health-gate probe throttle
  public const int GateFailLimit = 40;   // ~24s of non-200 -> explicit failure
  public const int ProbeThrottleMs = 400; // card TCP probe throttle — a dead
  // port blocks Probe() up to 700ms, so probing every 60ms tick would stall
  // the message pump and freeze the breathing lamp for the whole cold boot.

  /**
   * Diagnostics: set DSH_DOCK_DIAG=1 to append decision/crash traces to
   * %TEMP%\dsh-dock-diag.log. Zero cost when unset — keep for field support.
   */
  static readonly bool DiagOn = Environment.GetEnvironmentVariable("DSH_DOCK_DIAG") == "1";
  internal static void Diag(string m)
  {
    if (!DiagOn) return;
    try
    {
      File.AppendAllText(Path.Combine(Path.GetTempPath(), "dsh-dock-diag.log"),
        DateTime.Now.ToString("HH:mm:ss.fff") + " " + m + Environment.NewLine);
    }
    catch { }
  }

  /** JSON string literal via the serializer (escaping handled). */
  internal static string JsonStr(string value)
  {
    try
    {
      return new System.Web.Script.Serialization.JavaScriptSerializer()
        .Serialize(value ?? "");
    }
    catch { return "\"\""; }
  }

  /** Tail of a log file (tokens redacted), for the early-exit failure card. */
  internal static string ReadLogTail(string path, int maxChars)
  {
    try
    {
      if (string.IsNullOrEmpty(path) || !File.Exists(path)) return "";
      using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read,
        FileShare.ReadWrite | FileShare.Delete))
      {
        long start = Math.Max(0, fs.Length - maxChars);
        fs.Seek(start, SeekOrigin.Begin);
        int want = (int)(fs.Length - start);
        byte[] buf = new byte[want];
        int n = fs.Read(buf, 0, want);
        string s = System.Text.Encoding.UTF8.GetString(buf, 0, n);
        s = RedactTokens(s);
        if (s.Length > 260) s = s.Substring(s.Length - 260);
        return s.Trim();
      }
    }
    catch { return ""; }
  }

  /** Replace token values so crash dumps can never leak a session URL. */
  internal static string RedactTokens(string s)
  {
    try { return Regex.Replace(s, "token=[A-Za-z0-9_\\-]+", "token=…"); }
    catch { return s; }
  }

  [STAThread]
  static void Main()
  {
    Application.EnableVisualStyles();
    Application.SetCompatibleTextRenderingDefault(false);
    Diag("main start");
    Application.ThreadException += (s, e) => Diag("ThreadException: " + e.Exception);
    AppDomain.CurrentDomain.UnhandledException += (s, e) =>
      Diag("UnhandledException: " + e.ExceptionObject);

    LauncherConfig cfg;
    try
    {
      Diag("config read in");
      cfg = LauncherConfig.Read();
      Diag("config read ok url=" + cfg.Url);
    }
    catch (Exception e)
    {
      Diag("config read FAIL: " + e.Message);
      MessageBox.Show(e.Message, "DSH Harness",
        MessageBoxButtons.OK, MessageBoxIcon.Error);
      return;
    }

    bool alive = ServerAlive(cfg.Url);
    Diag("server alive: " + alive + " (url=" + cfg.Url + ")");

    // --boot: HKCU Run autostart entry. Resident tray + silent server start,
    // NO window (the preheated fast-open path). Never opens UI on its own.
    bool boot = Array.IndexOf(Environment.GetCommandLineArgs(), "--boot") >= 0;
    bool trayAlive = DshTray.IsRunning(cfg);
    if (boot)
    {
      if (trayAlive) { Diag("boot: tray already running -> exit"); return; }
      Diag("boot mode -> tray");
      DshTray.Run(cfg, true);
      return;
    }

    if (alive)
    {
      // Exit/start race: a double-click right after 完全退出 must not open
      // the dying server. Wait the port down, then cold-start normally.
      if (MarkerActive(cfg.Stopping) && WaitForPortDown(cfg, RaceWaitMs))
      {
        Diag("exit race: port down -> cold card");
        RunColdCard(cfg);
        return;
      }
      // Quick path: open silently — no card UI — the moment the token URL
      // really serves the page. If the log only holds a stale token (server
      // still booting), retry a few times for a fresh line.
      for (int i = 0; i < QuickRetries; i++)
      {
        string url = ReadTokenUrl(cfg.Log);
        if (url != null && HttpReady(url))
        {
          Diag("quick open: " + url);
          LaunchEdge(url, cfg.Profile);
          // v0.4.0: a non-boot launcher that just opened the window hands
          // over to the resident tray (when enabled and none is running)
          // instead of exiting — the whale stays as the status entry point.
          MaybeEnterTray(cfg, trayAlive);
          return;
        }
        Thread.Sleep(QuickRetryMs);
      }
      // Server answers but never serves a valid token URL: show the card in
      // wait mode, which surfaces an explicit failure instead of waiting
      // silently for 180 s.
      Diag("quick path exhausted -> wait card");
      Application.Run(new DshCard(cfg, false, CandidateSet.Single(cfg), false));
      return;
    }

    Diag("server dead -> cold card");
    RunColdCard(cfg);
  }

  /**
   * Cold start entry: run the T2 refresh first so a dsh installed since the
   * last server boot is already selectable, then let the card pick or start.
   * When the card closes on a LIVE server (window opened / boot finished),
   * the process may hand over to the resident tray instead of exiting.
   */
  static void RunColdCard(LauncherConfig cfg)
  {
    // Hygiene: the sidebar stop route's marker cleanup may be lost when the
    // dying server's spawn chain collapses mid-script (observed in E2E). A
    // stale marker is behaviorally inert (freshness gate) but untidy — clear
    // it here, on a path that provably runs.
    if (File.Exists(cfg.Stopping) && !MarkerActive(cfg.Stopping))
    {
      try { File.Delete(cfg.Stopping); } catch { }
    }
    bool refreshed = DshDockProgram.RunCandidateRefresh(cfg);
    CandidateSet cands = CandidateSet.Load(cfg, refreshed);
    bool stale = cands.HasRealList && !refreshed;
    Application.Run(new DshCard(cfg, true, cands, stale));
    if (ServerAlive(cfg.Url) && !MarkerActive(cfg.Stopping))
    {
      MaybeEnterTray(cfg, DshTray.IsRunning(cfg));
    }
  }

  /** Enter tray residency when enabled and no tray is already running. */
  static void MaybeEnterTray(LauncherConfig cfg, bool trayAlive)
  {
    if (trayAlive || !DshTray.ReadTrayStay(cfg)) return;
    Diag("enter tray residency");
    DshTray.Run(cfg, false);
  }

  // ── quick-path helpers ───────────────────────────────────────────────────

  /** Any HTTP answer (200, 401, ...) means the server process is alive. */
  internal static bool ServerAlive(string url)
  {
    Diag("ServerAlive in: " + url);
    try
    {
      var req = (HttpWebRequest)WebRequest.Create(url);
      req.Method = "GET";
      req.Timeout = 1200;
      req.ReadWriteTimeout = 1200;
      req.Proxy = null;
      req.AllowAutoRedirect = false;
      using (var resp = (HttpWebResponse)req.GetResponse())
      {
        Diag("ServerAlive out: status=" + (int)resp.StatusCode);
        return true;
      }
    }
    catch (WebException we)
    {
      Diag("ServerAlive out: WebException response=" + (we.Response != null));
      return we.Response != null;
    }
    catch (Exception e)
    {
      Diag("ServerAlive out: " + e.GetType().Name + " " + e.Message);
      return false;
    }
  }

  /** True while the stop route is shutting the server down (marker fresh). */
  internal static bool MarkerActive(string path)
  {
    try
    {
      long epochSec = long.Parse(File.ReadAllText(path).Trim());
      long nowSec = (long)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds;
      return nowSec - epochSec < MarkerFreshSec;
    }
    catch { return false; }
  }

  /** Wait up to ms for the server port to actually go down. */
  internal static bool WaitForPortDown(LauncherConfig cfg, int ms)
  {
    DateTime deadline = DateTime.UtcNow.AddMilliseconds(ms);
    while (DateTime.UtcNow < deadline)
    {
      if (!ServerAlive(cfg.Url)) return true;
      Thread.Sleep(250);
    }
    return !ServerAlive(cfg.Url);
  }

  /** Freshest `dsh web: http://…?token=…` line from the server log, or null. */
  internal static string ReadTokenUrl(string logPath)
  {
    try
    {
      using (var fs = new FileStream(logPath, FileMode.Open, FileAccess.Read,
        FileShare.ReadWrite | FileShare.Delete))
      using (var rd = new StreamReader(fs))
      {
        MatchCollection ms = Regex.Matches(rd.ReadToEnd(),
          "dsh web: (http://[^ \\t\\r\\n]+)");
        if (ms.Count > 0) return ms[ms.Count - 1].Groups[1].Value;
      }
    }
    catch { }
    return null;
  }

  /**
   * Health gate: only a token URL that really serves the page may open the
   * window. DSH answers a VALID token URL with 303 + Set-Cookie -> "/"; the
   * cookie jar lets the auto-redirect land on 200 exactly like a browser.
   * A STALE token answers a plain 401 (no redirect) -> WebException -> false,
   * so the launcher keeps waiting for a fresh line instead of opening a fake
   * 401 window at a half-dead server.
   */
  internal static bool HttpReady(string url)
  {
    try
    {
      var req = (HttpWebRequest)WebRequest.Create(url);
      req.Method = "GET";
      req.Timeout = HttpTimeoutMs;
      req.ReadWriteTimeout = HttpTimeoutMs;
      req.Proxy = null;
      req.CookieContainer = new CookieContainer();
      using (var resp = (HttpWebResponse)req.GetResponse())
      {
        Diag("HttpReady " + url + " -> " + (int)resp.StatusCode);
        return resp.StatusCode == HttpStatusCode.OK;
      }
    }
    catch (Exception e)
    {
      var we = e as WebException;
      string detail = we != null && we.Response != null
        ? "status=" + (int)((HttpWebResponse)we.Response).StatusCode
        : e.GetType().Name + ": " + e.Message;
      Diag("HttpReady " + url + " -> FAIL (" + detail + ")");
      return false;
    }
  }

  /**
   * Open the GUI as a fullscreen Edge app window (default browser fallback).
   * Returns the spawned process (null via shell-open) so the tray can close
   * the windows it opened on 完全退出.
   */
  internal static Process LaunchEdge(string url, string profile)
  {
    string edge = null;
    string[] cands = {
      Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
        "Microsoft\\Edge\\Application\\msedge.exe"),
      Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
        "Microsoft\\Edge\\Application\\msedge.exe"),
      Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "Microsoft\\Edge\\Application\\msedge.exe"),
    };
    foreach (string c in cands) if (File.Exists(c)) { edge = c; break; }
    if (edge != null)
    {
      string args = "--app=\"" + url + "\" --start-fullscreen --user-data-dir=\"" + profile
        + "\" --no-first-run --no-default-browser-check";
      return Process.Start(edge, args);
    }
    Process.Start(url);
    return null;
  }

  /**
   * T2 candidate refresh: re-scan every installed dsh right before a cold
   * start by running the deployed node script (it writes candidates.json and
   * creates per-candidate batches — content-gated, never a rewrite of the
   * selection itself). Returns false when refresh cannot run (old ini, node
   * missing, timeout) so the caller can fall back to the stale list.
   */
  internal static bool RunCandidateRefresh(LauncherConfig cfg)
  {
    CandidateSet.EnsureDerivedPaths(cfg);
    if (string.IsNullOrEmpty(cfg.Node) || string.IsNullOrEmpty(cfg.Refresh)
      || !File.Exists(cfg.Node) || !File.Exists(cfg.Refresh))
    {
      Diag("refresh skipped: node/script missing");
      return false;
    }
    try
    {
      var psi = new ProcessStartInfo(cfg.Node, "\"" + cfg.Refresh + "\"")
      {
        UseShellExecute = false,
        CreateNoWindow = true,
      };
      Diag("refresh start");
      Process p = Process.Start(psi);
      if (p == null) return false;
      if (!p.WaitForExit(8000))
      {
        try { p.Kill(); } catch { }
        Diag("refresh timeout");
        return false;
      }
      Diag("refresh exit=" + p.ExitCode);
      return p.ExitCode == 0;
    }
    catch (Exception e)
    {
      Diag("refresh FAIL: " + e.Message);
      return false;
    }
  }
}

/** Bake-time configuration, read from %USERPROFILE%\.dsh\launcher\launcher.ini. */
sealed class LauncherConfig
{
  public string Url;
  public string Log;
  public string Batch;
  public string Profile;
  public string Stopping;
  public string Lock;
  public string Whale;
  // v0.3.3 multi-DSH selection support.
  public string Node;
  public string Candidates;
  public string State;
  public string Refresh;
  // v0.4.0 tray-resident support.
  public string Settings;
  public string Manifest;

  public int Port
  {
    get
    {
      try { return new Uri(Url).Port; }
      catch { return 3080; }
    }
  }

  public static LauncherConfig Read()
  {
    string dir = Path.Combine(
      Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
      ".dsh", "launcher");
    string ini = Path.Combine(dir, "launcher.ini");
    if (!File.Exists(ini))
    {
      throw new InvalidOperationException(
        "缺少启动器配置 launcher.ini。请先安装 dsh-dock 插件并重启 dsh web。");
    }
    var cfg = new LauncherConfig();
    foreach (string raw in File.ReadAllLines(ini, System.Text.Encoding.UTF8))
    {
      // Defensive: strip a stray UTF-8 BOM before the first key.
      string line = raw.Trim().TrimStart('\uFEFF').Trim();
      if (line.Length == 0 || line.StartsWith("#")) continue;
      int sep = line.IndexOf('=');
      if (sep < 1) continue;
      string key = line.Substring(0, sep).Trim();
      string value = Decode(line.Substring(sep + 1).Trim(), key);
      if (key == "URL") cfg.Url = value;
      else if (key == "LOG") cfg.Log = value;
      else if (key == "BATCH") cfg.Batch = value;
      else if (key == "PROFILE") cfg.Profile = value;
      else if (key == "STOPPING") cfg.Stopping = value;
      else if (key == "LOCK") cfg.Lock = value;
      else if (key == "WHALE") cfg.Whale = value;
      else if (key == "NODE") cfg.Node = value;
      else if (key == "CANDIDATES") cfg.Candidates = value;
      else if (key == "STATE") cfg.State = value;
      else if (key == "REFRESH") cfg.Refresh = value;
      else if (key == "SETTINGS") cfg.Settings = value;
      else if (key == "MANIFEST") cfg.Manifest = value;
    }
    if (string.IsNullOrEmpty(cfg.Url) || string.IsNullOrEmpty(cfg.Log)
      || string.IsNullOrEmpty(cfg.Batch) || string.IsNullOrEmpty(cfg.Profile))
    {
      throw new InvalidOperationException("launcher.ini 缺少必要配置项 (URL/LOG/BATCH/PROFILE)。");
    }
    return cfg;
  }

  static string Decode(string value, string key)
  {
    try
    {
      return System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(value));
    }
    catch
    {
      throw new InvalidOperationException("launcher.ini 的 " + key + " 值不是合法 Base64。");
    }
  }
}

/** One selectable dsh installation (one baked batch file each). */
sealed class CandidateRow
{
  public string Id;
  public string Version;
  public string Kind;
  public string Path;
  public string Label;
  public string Batch;

  public string BatchPath(LauncherConfig cfg)
  {
    // cfg.Batch points at the default start-server.cmd (row 0). Alternates
    // live next to it under their own names.
    string dir = System.IO.Path.GetDirectoryName(cfg.Batch);
    if (string.IsNullOrEmpty(Batch)) return cfg.Batch;
    // Defense in depth: only a bare filename may combine into the launcher
    // dir. A tampered candidates.json could name an absolute path or a path
    // with separators here (Path.Combine would run it verbatim); refuse and
    // fall back to the canonical default batch instead.
    if (System.IO.Path.IsPathRooted(Batch)
      || Batch.IndexOfAny(new char[] { '\\', '/' }) >= 0)
      return cfg.Batch;
    if (dir == null) return Batch;
    return System.IO.Path.Combine(dir, Batch);
  }
}

/**
 * v0.3.3 candidate set — parsed from candidates.json (written by the host at
 * activation and refreshed by the T2 script before each cold start). Rows are
 * pre-sorted by the writer (version desc, then kind, then path). A missing or
 * unreadable file degrades to a single pseudo-candidate pointing at the baked
 * default batch, so pre-v0.3.3 suites behave exactly as before.
 */
sealed class CandidateSet
{
  public List<CandidateRow> Rows = new List<CandidateRow>();
  public bool NpxFallback = false;
  /** True when rows came from a real candidates.json (not the pseudo default). */
  public bool HasRealList = false;

  /**
   * An OLDER plugin release rewrites launcher.ini without the v0.3.3 keys
   * (NODE/CANDIDATES/STATE/REFRESH) on every server boot, but it does not
   * delete candidates.json or the deployed refresh script. Derive those
   * paths from the default batch's directory so the picker still works
   * under a stale ini instead of silently degrading to a single candidate.
   */
  internal static void EnsureDerivedPaths(LauncherConfig cfg)
  {
    string dir = string.IsNullOrEmpty(cfg.Batch) ? null : System.IO.Path.GetDirectoryName(cfg.Batch);
    if (dir == null) return;
    if (string.IsNullOrEmpty(cfg.Candidates)) cfg.Candidates = System.IO.Path.Combine(dir, "candidates.json");
    if (string.IsNullOrEmpty(cfg.State)) cfg.State = System.IO.Path.Combine(dir, "launcher-state.json");
    if (string.IsNullOrEmpty(cfg.Refresh)) cfg.Refresh = System.IO.Path.Combine(dir, "dsh-dock-refresh.mjs");
  }

  /** Degraded single-candidate set (old ini / missing list / wait-mode card). */
  public static CandidateSet Single(LauncherConfig cfg)
  {
    var s = new CandidateSet();
    s.Rows.Add(new CandidateRow { Id = "default", Version = "", Kind = "default",
      Label = "默认", Batch = "" });
    return s;
  }

  /** Load candidates.json. refreshOk = the T2 refresh just ran successfully. */
  public static CandidateSet Load(LauncherConfig cfg, bool refreshOk)
  {
    var s = new CandidateSet();
    EnsureDerivedPaths(cfg);
    if (string.IsNullOrEmpty(cfg.Candidates) || !File.Exists(cfg.Candidates))
      return Single(cfg);
    try
    {
      string text = File.ReadAllText(cfg.Candidates, System.Text.Encoding.UTF8);
      var ser = new System.Web.Script.Serialization.JavaScriptSerializer();
      ser.MaxJsonLength = 1 << 20;
      var root = ser.DeserializeObject(text) as System.Collections.Generic.Dictionary<string, object>;
      if (root == null) return Single(cfg);
      if (root.ContainsKey("candidates"))
      {
        var list = root["candidates"] as object[];
        if (list != null)
        {
          foreach (object item in list)
          {
            var row = item as System.Collections.Generic.Dictionary<string, object>;
            if (row == null) continue;
            var r = new CandidateRow();
            if (row.ContainsKey("id")) r.Id = Convert.ToString(row["id"]);
            if (row.ContainsKey("version")) r.Version = Convert.ToString(row["version"]);
            if (row.ContainsKey("kind")) r.Kind = Convert.ToString(row["kind"]);
            if (row.ContainsKey("path")) r.Path = Convert.ToString(row["path"]);
            if (row.ContainsKey("label")) r.Label = Convert.ToString(row["label"]);
            if (row.ContainsKey("batch")) r.Batch = Convert.ToString(row["batch"]);
            r.Label = string.IsNullOrEmpty(r.Label) ? "默认" : r.Label;
            s.Rows.Add(r);
          }
        }
      }
      if (root.ContainsKey("npxFallback"))
      {
        var fb = root["npxFallback"];
        if (fb != null) s.NpxFallback = true;
      }
      if (s.Rows.Count == 0 && !s.NpxFallback)
      {
        // candidates.json exists but lists nothing and there is no npx
        // fallback — degrade to the baked default rather than a dead end.
        return Single(cfg);
      }
      s.HasRealList = true;
      return s;
    }
    catch (Exception e)
    {
      DshDockProgram.Diag("candidates parse FAIL: " + e.Message);
      return Single(cfg);
    }
  }

  /** Version of the last successful run (state file), or null. */
  public static string ReadLastVersion(LauncherConfig cfg)
  {
    EnsureDerivedPaths(cfg);
    if (string.IsNullOrEmpty(cfg.State) || !File.Exists(cfg.State)) return null;
    try
    {
      string text = File.ReadAllText(cfg.State, System.Text.Encoding.UTF8);
      var ser = new System.Web.Script.Serialization.JavaScriptSerializer();
      var root = ser.DeserializeObject(text) as System.Collections.Generic.Dictionary<string, object>;
      if (root != null && root.ContainsKey("lastVersion")) return Convert.ToString(root["lastVersion"]);
    }
    catch { }
    return null;
  }

  /** Persist the last successful (version, path) — called on a real open. */
  public static void RecordRun(LauncherConfig cfg, CandidateRow row)
  {
    if (row == null) return;
    EnsureDerivedPaths(cfg);
    if (string.IsNullOrEmpty(cfg.State)) return;
    try
    {
      string json = "{\"lastVersion\":" + DshDockProgram.JsonStr(row.Version)
        + ",\"lastPath\":" + DshDockProgram.JsonStr(row.Path)
        + ",\"updatedAt\":" + DateTime.UtcNow.Ticks + "}";
      string dir = System.IO.Path.GetDirectoryName(cfg.State);
      if (!string.IsNullOrEmpty(dir)) System.IO.Directory.CreateDirectory(dir);
      System.IO.File.WriteAllText(cfg.State, json, new System.Text.UTF8Encoding(false));
    }
    catch { }
  }
}

/** Breathing-whale cold-start card (also the wait/failure surface). */
sealed class DshCard : Form
{
  readonly LauncherConfig cfg;
  readonly bool coldStart;
  readonly System.Windows.Forms.Timer anim = new System.Windows.Forms.Timer();
  Thread poller = null;
  volatile bool pollerStop = false;
  readonly Label logline = new Label();
  readonly Button closeBtn = new Button();
  readonly Font uiFont = new Font("Segoe UI Light", 11f);
  readonly Font monoFont = new Font("Consolas", 8.5f);
  readonly Font titleFont = new Font("Segoe UI", 12f, FontStyle.Bold);
  readonly Font tagFont = new Font("Segoe UI", 8.5f);
  readonly Color bgTop = Color.FromArgb(28, 33, 42);
  readonly Color bgBot = Color.FromArgb(20, 24, 31);
  readonly Color ink = Color.FromArgb(200, 206, 216);
  readonly Color dim = Color.FromArgb(128, 136, 148);
  readonly Color danger = Color.FromArgb(240, 110, 100);
  Bitmap whaleBmp = null;
  System.Drawing.Imaging.ImageAttributes whaleAttrs = null;
  System.Drawing.Imaging.ColorMatrix whaleMatrix = null;
  Brush textInk = null;
  Brush textDanger = null;
  Pen borderPen = null;
  string statusText = "正在启动";
  float breatheT = 0f;
  float fadeTarget = 0.90f;
  int warmTicks = 0;
  DateTime deadline;
  DateTime lastHttpCheck = DateTime.MinValue;
  DateTime lastProbe = DateTime.MinValue;
  bool opened = false;
  bool failing = false;
  bool fadeOut = false;
  bool spawned = false;
  /** True while THIS process holds `.starting.lock` (only then may it clear it). */
  bool holdsSpawnLock = false;
  /** Height of the painted status box; the failure face grows it to fit (M3). */
  int statusBoxH = 30;
  int deadStreak = 0;
  int gateFailStreak = 0;
  Process spawnProc = null;
  DateTime spawnAt = DateTime.MinValue;
  const int W = 340;
  const int HNormal = 184;
  const int HFail = 284;
  const int HZero = 204;
  const int WhaleW = 84;
  // v0.3.5 multi-DSH selection: a painted candidate list (no native ComboBox).
  const int WMulti = 400;
  const int HMulti = 288;
  const int ListX = 24;
  const int ListRowH = 46;
  const int ListGap = 7;
  const int ListTop = 88;
  const int ListViewBottom = 244;   // bottom of the scrollable list viewport
  readonly CandidateSet cands;
  readonly bool stale;
  readonly List<CandidateRow> rows = new List<CandidateRow>();
  readonly Button npxBtn = new Button();
  readonly Button cancelBtn = new Button();
  int choiceMode = 0;        // 0 = none/single, 1 = picker, 2 = zero-candidate prompt
  int chosenIndex = -1;
  int keyIndex = 0;          // highlighted candidate; Enter/auto-start target
  int hoverIndex = -1;
  int scrollY = 0;           // scroll offset in px when the list overflows
  string serverBatch = null;
  bool chooseDone = false;
  bool listVisible = false;
  DateTime chooseDeadline = DateTime.MaxValue;
  int lastHintSec = -1;
  const int ChooseSeconds = 10;

  public DshCard(LauncherConfig config, bool coldStart, CandidateSet cands, bool stale)
  {
    this.cfg = config;
    this.coldStart = coldStart;
    this.cands = cands ?? CandidateSet.Single(config);
    this.stale = stale;
    rows.AddRange(this.cands.Rows);
    DshDockProgram.Diag("card ctor coldStart=" + coldStart + " port=" + config.Port
      + " log=" + config.Log + " cands=" + rows.Count + " stale=" + stale);

    // Resolve the start target up front. The picker (mode 1) pauses spawn
    // until the user picks or the countdown fires; the zero-prompt (mode 2)
    // waits for an explicit npx/cancel click. Mode 0 (single candidate) is
    // resolved in SetupChoiceControls.
    if (coldStart)
    {
      if (rows.Count > 1) choiceMode = 1;
      else if (rows.Count == 0) choiceMode = 2;
    }

    FormBorderStyle = FormBorderStyle.None;
    StartPosition = FormStartPosition.CenterScreen;
    ShowInTaskbar = false;
    TopMost = true;
    BackColor = bgBot;
    DoubleBuffered = true;
    SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint
      | ControlStyles.UserPaint, true);
    Size = new Size(W, HNormal);
    Opacity = 0;

    textInk = new SolidBrush(ink);
    textDanger = new SolidBrush(danger);
    borderPen = new Pen(Color.FromArgb(36, 255, 255, 255), 1f);

    whaleMatrix = new System.Drawing.Imaging.ColorMatrix();
    whaleAttrs = new System.Drawing.Imaging.ImageAttributes();
    whaleAttrs.SetColorMatrix(whaleMatrix);
    PreRenderWhale();

    logline.Location = new Point(48, 148);
    logline.Size = new Size(244, 40);
    logline.Font = monoFont;
    logline.ForeColor = dim;
    logline.Visible = false;
    Controls.Add(logline);

    closeBtn.Location = new Point(120, 198);
    closeBtn.Size = new Size(100, 28);
    closeBtn.FlatStyle = FlatStyle.Flat;
    closeBtn.FlatAppearance.BorderColor = Color.FromArgb(70, 76, 88);
    closeBtn.FlatAppearance.MouseOverBackColor = Color.FromArgb(40, 46, 58);
    closeBtn.BackColor = Color.FromArgb(32, 37, 48);
    closeBtn.ForeColor = ink;
    closeBtn.Font = new Font("Segoe UI", 9f);
    closeBtn.Text = "关闭";
    closeBtn.Visible = false;
    closeBtn.Click += delegate { fadeOut = true; fadeTarget = 0f; };
    Controls.Add(closeBtn);

    SetupChoiceControls();

    anim.Interval = 16;
    anim.Tick += delegate
    {
      if (warmTicks < 10) { warmTicks++; Invalidate(); return; }
      breatheT += 0.011f;
      if (breatheT > 1f) breatheT -= 1f;
      float d = fadeTarget - (float)Opacity;
      if (Math.Abs(d) > 0.003f) Opacity = Math.Max(0, Math.Min(1, Opacity + d * 0.10f));
      else Opacity = fadeTarget;
      if (fadeOut && Opacity <= 0.015) Close();
      TickChoice();
      Invalidate();
    };
    anim.Start();

    Shown += delegate
    {
      Region = RoundedRegion(Width, Height, 20);
      deadline = DateTime.UtcNow.AddSeconds(180);
      // Provisional first status; the poller's first probe (within ~60ms)
      // refines it — probing here would block this (UI) thread.
      if (choiceMode == 1)
      {
        Size = new Size(WMulti, HMulti);
        Region = RoundedRegion(WMulti, HMulti, 20);
        SetStatus("正在选择要启动的 DSH");
        listVisible = true;
        chooseDeadline = DateTime.UtcNow.AddSeconds(ChooseSeconds);
        lastHintSec = -1;
      }
      else if (choiceMode == 2)
      {
        Size = new Size(W, HZero);
        Region = RoundedRegion(W, HZero, 20);
        SetStatus("未找到任何已安装的 DSH");
        npxBtn.Visible = true;
        cancelBtn.Visible = true;
        // Fetching via npx is a deliberate, networked action — no countdown.
      }
      else
      {
        SetStatus(coldStart ? "正在启动" : "正在连接");
      }
      poller = new Thread(PollerLoop);
      poller.IsBackground = true;
      poller.Name = "dsh-dock-poller";
      poller.Start();
    };
  }

  void PreRenderWhale()
  {
    try
    {
      string whalePath = cfg.Whale;
      if (string.IsNullOrEmpty(whalePath) || !File.Exists(whalePath)) return;
      Image src;
      using (var fs = new FileStream(whalePath, FileMode.Open,
        FileAccess.Read, FileShare.ReadWrite))
      {
        src = new Bitmap(fs);
      }
      int h = (int)(WhaleW * 17.04 / 23.16);
      whaleBmp = new Bitmap(WhaleW, h);
      using (var g = Graphics.FromImage(whaleBmp))
      {
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        var attrs = new System.Drawing.Imaging.ImageAttributes();
        var map = new System.Drawing.Imaging.ColorMap[1];
        map[0] = new System.Drawing.Imaging.ColorMap();
        map[0].OldColor = Color.Black;
        map[0].NewColor = Color.FromArgb(225, 230, 240);
        attrs.SetRemapTable(map);
        g.DrawImage(src, new Rectangle(0, 0, WhaleW, h), 0, 0, src.Width, src.Height,
          GraphicsUnit.Pixel, attrs);
      }
      src.Dispose();
    }
    catch { whaleBmp = null; }
  }

  /** Build the choice-phase controls: npx prompt (mode 2) and the painted
   *  candidate-list geometry (mode 1); the list itself is drawn in OnPaint. */
  void SetupChoiceControls()
  {
    keyIndex = 0;
    scrollY = 0;
    if (choiceMode == 1 && rows.Count > 0)
    {
      // Preselect the last successfully-run version when the list is real.
      string lastV = cands.HasRealList ? CandidateSet.ReadLastVersion(cfg) : null;
      if (lastV != null)
      {
        for (int i = 0; i < rows.Count; i++)
        {
          if (rows[i].Version == lastV) { keyIndex = i; break; }
        }
      }
    }
    else if (rows.Count > 0)
    {
      chosenIndex = 0;
      serverBatch = rows[0].BatchPath(cfg);
      chooseDone = true;
    }

    npxBtn.Location = new Point(26, 158);
    npxBtn.Size = new Size(192, 30);
    npxBtn.FlatStyle = FlatStyle.Flat;
    npxBtn.FlatAppearance.BorderColor = Color.FromArgb(70, 76, 88);
    npxBtn.FlatAppearance.MouseOverBackColor = Color.FromArgb(40, 46, 58);
    npxBtn.BackColor = Color.FromArgb(32, 37, 48);
    npxBtn.ForeColor = ink;
    npxBtn.Font = new Font("Segoe UI", 9f);
    npxBtn.Text = "用 npx 拉取并启动(需联网)";
    npxBtn.Visible = false;
    npxBtn.Click += delegate
    {
      // cfg.Batch is the canonical npx-fallback batch when no candidate exists.
      serverBatch = cfg.Batch;
      chooseDone = true;
      npxBtn.Visible = false;
      cancelBtn.Visible = false;
      SetStatus("正在通过 npx 获取最新版…");
    };
    Controls.Add(npxBtn);

    cancelBtn.Location = new Point(226, 158);
    cancelBtn.Size = new Size(88, 30);
    cancelBtn.FlatStyle = FlatStyle.Flat;
    cancelBtn.FlatAppearance.BorderColor = Color.FromArgb(70, 76, 88);
    cancelBtn.FlatAppearance.MouseOverBackColor = Color.FromArgb(40, 46, 58);
    cancelBtn.BackColor = Color.FromArgb(32, 37, 48);
    cancelBtn.ForeColor = ink;
    cancelBtn.Font = new Font("Segoe UI", 9f);
    cancelBtn.Text = "取消";
    cancelBtn.Visible = false;
    cancelBtn.Click += delegate { fadeOut = true; fadeTarget = 0f; };
    Controls.Add(cancelBtn);

    KeyPreview = true;   // let the card see Up/Down/Enter before the buttons
  }

  /** 10s auto-start countdown for the picker (mode 1); no-op otherwise. */
  void TickChoice()
  {
    if (choiceMode != 1 || chooseDone) return;
    double left = (chooseDeadline - DateTime.UtcNow).TotalSeconds;
    if (left <= 0)
    {
      DoChoose(keyIndex >= 0 && keyIndex < rows.Count ? keyIndex : 0);
      return;
    }
    int secs = (int)Math.Ceiling(left);
    if (secs != lastHintSec)
    {
      lastHintSec = secs;
      Invalidate();   // the countdown is painted in OnPaint
    }
  }

  /** Lock in the picker selection and allow the spawn path to proceed. */
  void DoChoose(int index)
  {
    if (chooseDone || choiceMode != 1) return;
    if (index < 0 || index >= rows.Count) index = 0;
    chosenIndex = index;
    serverBatch = rows[index].BatchPath(cfg);
    chooseDone = true;
    listVisible = false;
    hoverIndex = -1;
    DshDockProgram.Diag("chosen: " + rows[index].Label + " batch=" + serverBatch);
    SetStatus("正在启动 " + rows[index].Label);
    // Settle the card back to the single-candidate startup size.
    Size = new Size(W, HNormal);
    Region = RoundedRegion(W, HNormal, 20);
    Invalidate();
  }

  /** Marshal a UI update onto the message loop (safe once the form is shown). */
  void Ui(MethodInvoker a)
  {
    try { if (!IsDisposed) BeginInvoke(a); }
    catch (ObjectDisposedException) { }
    catch (InvalidOperationException) { }
  }

  void SetStatus(string t)
  {
    Ui(delegate { statusText = t; failing = false; Invalidate(); });
  }

  /** Re-read the log, health-gate the token URL, and open on success. */
  bool TryOpenFromLog()
  {
    string url = DshDockProgram.ReadTokenUrl(cfg.Log);
    if (url == null) return false;
    if (!DshDockProgram.HttpReady(url)) return false;
    Open(url);
    return true;
  }

  void Open(string url)
  {
    DshDockProgram.Diag("card open: " + url);
    opened = true;
    pollerStop = true;
    // Remember the version that really served the page — the next cold start
    // preselects it. Only recorded on success, never on a failed pick.
    if (cands.HasRealList && chosenIndex >= 0 && chosenIndex < rows.Count)
    {
      CandidateSet.RecordRun(cfg, rows[chosenIndex]);
    }
    TryClearSpawnLock();
    holdsSpawnLock = false;
    DshDockProgram.LaunchEdge(url, cfg.Profile);
    Ui(delegate
    {
      statusText = "已就绪";
      fadeOut = true;
      fadeTarget = 0f;
      Invalidate();
    });
  }

  /**
   * All blocking I/O — the TCP probe (a dead port blocks up to 700ms), the
   * log scrape, and the health-gate HTTP call (up to 1.5s) — runs on this
   * background thread; the UI thread only paints. These used to run inside
   * a WinForms timer tick, freezing the message pump and stuttering the
   * breathing lamp on every poll — machine-independent, because a kernel
   * connect timeout is not CPU work.
   */
  void PollerLoop()
  {
    while (!pollerStop)
    {
      try { PollOnce(); }
      catch (Exception ex) { DshDockProgram.Diag("poller tick FAIL: " + ex.Message); }
      if (pollerStop) break;
      Thread.Sleep(60);
    }
    DshDockProgram.Diag("poller exit");
  }

  void PollOnce()
  {
    if (failing || opened) { pollerStop = true; return; }
    if (coldStart)
    {
      // Probe at most every ProbeThrottleMs: a dead port blocks the TCP
      // connect up to 700ms, and doing that on every 60ms tick would freeze
      // the breathing animation for the whole server boot.
      bool probed = (DateTime.UtcNow - lastProbe).TotalMilliseconds
        >= DshDockProgram.ProbeThrottleMs;
      bool up = false;
      if (probed)
      {
        lastProbe = DateTime.UtcNow;
        up = Probe();
      }
      if (up)
      {
        deadStreak = 0;
        if ((DateTime.UtcNow - lastHttpCheck).TotalMilliseconds
          >= DshDockProgram.GateThrottleMs)
        {
          lastHttpCheck = DateTime.UtcNow;
          if (TryOpenFromLog()) return;
          statusText = "正在连接";
        }
        return;
      }
      // Multi-DSH / zero-prompt: the user picks (or the countdown fires)
      // before we may spawn — probes above still detect an external start.
      if (!chooseDone) return;
      if (probed && !spawned)
      {
        // Settle guard (port must stay down) PLUS a single-spawner lock: the
        // cold boot keeps the port dead ~10s+, so settle checks alone cannot
        // stop a second double-click from spawning a duplicate server.
        deadStreak++;
        // Only a lock we actually TOOK may latch `spawned`. Latching a failed
        // attempt killed every later retry in this process (the guard above is
        // dead once spawned is true), so the natural retry after a fast failure
        // waited out the full 180s against a still-fresh lock file.
        if (deadStreak >= 3 && TryTakeSpawnLock())
        {
          holdsSpawnLock = true;
          spawned = true;
          statusText = "首次启动可能稍久";
          try { StartServer(); } catch (Exception ex) { Fail(ex.Message); }
        }
        return;
      }
      // Early-exit detection: the chosen batch died without ever listening —
      // fail with the log tail instead of making the user wait out 180 s.
      if (spawned && !opened && spawnProc != null && spawnAt != DateTime.MinValue
        && (DateTime.UtcNow - spawnAt).TotalSeconds > 4)
      {
        try
        {
          if (spawnProc.HasExited && !Probe())
          {
            string tail = DshDockProgram.ReadLogTail(cfg.Log + ".err", 300);
            DshDockProgram.Diag("spawn exited early; err tail len=" + tail.Length);
            Fail("所选 DSH 启动后立即退出,未能监听端口 " + cfg.Port
              + "(依赖缺失或需其它启动方式)。",
              "日志尾部:" + (tail.Length == 0 ? "无" : tail) + "\n日志:" + cfg.Log);
            return;
          }
        }
        catch { }
      }
      if (DateTime.UtcNow > deadline)
      {
        Fail("服务器在 180 秒内未就绪(端口 " + cfg.Port
          + ")。若服务器由手动命令启动,请直接用浏览器打开 " + cfg.Url
          + "。日志:" + cfg.Log);
      }
    }
    else
    {
      // Wait mode: the server answers HTTP but never serves a valid token
      // URL. Keep polling with the health gate, but surface an explicit
      // failure (~24 s) instead of a silent 180 s wait — and tailor the
      // guidance to the port's actual state (occupied vs. already gone).
      if (!opened && (DateTime.UtcNow - lastHttpCheck).TotalMilliseconds
        >= DshDockProgram.GateThrottleMs)
      {
        lastHttpCheck = DateTime.UtcNow;
        if (TryOpenFromLog()) return;
        gateFailStreak++;
        if (gateFailStreak >= DshDockProgram.GateFailLimit)
        {
          if (Probe())
          {
            Fail("端口 " + cfg.Port + " 已被占用,但 DSH 页面未就绪(上一次会话可能未完全退出,"
              + "或服务器由手动命令启动)。请结束占用 " + cfg.Port + " 端口的进程,"
              + "或直接用浏览器打开 " + cfg.Url + "。日志:" + cfg.Log);
          }
          else
          {
            Fail("服务器已停止响应。请再次双击以重新启动。日志:" + cfg.Log);
          }
        }
      }
    }
  }

  void Fail(string msg)
  {
    Fail(msg, null);
  }

  /**
   * Failure face. `detail` (the .err tail + the log path) is assigned INSIDE the
   * queued delegate: setting it from the poller thread raced with this delegate
   * and always lost, so the richest diagnostic never reached the user.
   */
  void Fail(string msg, string detail)
  {
    failing = true;
    pollerStop = true;
    ReleaseSpawnLockIfHeld();
    Ui(delegate
    {
      statusText = "启动失败:" + msg;
      LayoutFailureFace(statusText);
      logline.Text = string.IsNullOrEmpty(detail) ? ("日志:" + cfg.Log) : detail;
      logline.Visible = true;
      closeBtn.Visible = true;
      Invalidate();
    });
  }

  /** Give the failure face the height its remedy text needs (see M3). */
  void LayoutFailureFace(string text)
  {
    Size measured = TextRenderer.MeasureText(text, uiFont, new Size(W - 44, int.MaxValue),
      TextFormatFlags.WordBreak);
    statusBoxH = Math.Max(30, measured.Height + 8);
    int extra = statusBoxH - 30;
    int height = HFail + extra;
    Size = new Size(W, height);
    Region = RoundedRegion(W, height, 20);
    logline.Location = new Point(48, 148 + extra);
    closeBtn.Location = new Point(120, 198 + extra);
  }

  /**
   * Drop the spawn lock only when THIS process took it. Deleting another
   * launcher's fresh lock would let a third double-click spawn a duplicate
   * server while the peer is still booting.
   */
  void ReleaseSpawnLockIfHeld()
  {
    if (!holdsSpawnLock) return;
    holdsSpawnLock = false;
    TryClearSpawnLock();
  }

  protected override void OnFormClosed(FormClosedEventArgs e)
  {
    pollerStop = true;
    // A card closed (or crashed) mid-spawn must not leave a fresh lock behind:
    // the user's next double-click would fail to take it and, before the fix
    // above, never retried.
    ReleaseSpawnLockIfHeld();
    base.OnFormClosed(e);
  }

  /** Release the GDI+ resources this card owns. */
  protected override void Dispose(bool disposing)
  {
    if (disposing)
    {
      if (whaleBmp != null) whaleBmp.Dispose();
      if (textInk != null) textInk.Dispose();
      if (textDanger != null) textDanger.Dispose();
      if (borderPen != null) borderPen.Dispose();
      if (whaleAttrs != null) whaleAttrs.Dispose();
      if (uiFont != null) uiFont.Dispose();
      if (monoFont != null) monoFont.Dispose();
      if (titleFont != null) titleFont.Dispose();
      if (tagFont != null) tagFont.Dispose();
      anim.Stop();
      anim.Dispose();
    }
    base.Dispose(disposing);
  }

  protected override void OnPaint(PaintEventArgs e)
  {
    var g = e.Graphics;
    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
    g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

    using (var bgGrad = new System.Drawing.Drawing2D.LinearGradientBrush(
      new Rectangle(0, 0, Width, Height), bgTop, bgBot, 90f))
    {
      var oldClip = g.Clip;
      g.SetClip(RoundedPath(0, 0, Width, Height, 20));
      g.FillRectangle(bgGrad, 0, 0, Width, Height);
      g.Clip = oldClip;
    }

    g.DrawPath(borderPen, RoundedPath(0.5f, 0.5f, Width - 1f, Height - 1f, 19f));

    if (choiceMode == 1 && listVisible && !chooseDone) PaintCandidateList(g);
    else PaintWhaleAndStatus(g);
  }

  /** The single-candidate / zero / fail / post-choice face. */
  void PaintWhaleAndStatus(Graphics g)
  {
    if (whaleBmp != null)
    {
      int whaleH = whaleBmp.Height;
      int wx = (Width - WhaleW) / 2;
      int wy = 32;
      if (failing) g.DrawImage(whaleBmp, wx, wy);
      else
      {
        float lamp = (float)(0.35 + 0.65 * (0.5 - 0.5 * Math.Cos(breatheT * 2 * Math.PI)));
        whaleMatrix.Matrix33 = lamp;
        whaleAttrs.SetColorMatrix(whaleMatrix);
        g.DrawImage(whaleBmp, new Rectangle(wx, wy, WhaleW, whaleH),
          0, 0, WhaleW, whaleH, GraphicsUnit.Pixel, whaleAttrs);
      }
    }
    var sf = new StringFormat();
    sf.Alignment = StringAlignment.Center;
    sf.LineAlignment = StringAlignment.Center;
    int statusY = (choiceMode == 2) ? 112 : 138;
    using (var brush = new SolidBrush(failing ? danger : dim))
    {
      g.DrawString(statusText, uiFont, brush,
        new RectangleF(0, statusY, Width, failing ? statusBoxH : 30), sf);
    }
  }

  /** Multi-DSH face: a painted, scrollable candidate list matching the chrome. */
  void PaintCandidateList(Graphics g)
  {
    // Brand whale, centered at the top (a bit bigger than a thumbnail).
    if (whaleBmp != null)
    {
      int smallW = 64, smallH = (int)(smallW * (float)whaleBmp.Height / whaleBmp.Width);
      int wx = (Width - smallW) / 2, wy = 12;
      float lamp = (float)(0.35 + 0.65 * (0.5 - 0.5 * Math.Cos(breatheT * 2 * Math.PI)));
      whaleMatrix.Matrix33 = lamp;
      whaleAttrs.SetColorMatrix(whaleMatrix);
      g.DrawImage(whaleBmp, new Rectangle(wx, wy, smallW, smallH),
        0, 0, whaleBmp.Width, whaleBmp.Height, GraphicsUnit.Pixel, whaleAttrs);
    }

    using (var titleBrush = new SolidBrush(Color.FromArgb(220, 226, 234)))
    {
      var sf = new StringFormat();
      sf.Alignment = StringAlignment.Center;
      g.DrawString("选择要启动的 DSH", titleFont, titleBrush, new RectangleF(0, 60, Width, 24), sf);
    }

    int viewH = ListViewBottom - ListTop;
    int maxScroll = ComputeMaxScroll();
    int rowW = WMulti - 2 * ListX;
    using (var rowFill = new SolidBrush(Color.FromArgb(30, 36, 46)))
    using (var hoverFill = new SolidBrush(Color.FromArgb(44, 52, 66)))
    using (var selBorder = new Pen(Color.FromArgb(160, 195, 235), 1.6f))
    using (var mainBrush = new SolidBrush(ink))
    using (var dimBrush = new SolidBrush(dim))
    using (var checkPen = new Pen(Color.FromArgb(130, 210, 160), 2f))
    {
      for (int i = 0; i < rows.Count; i++)
      {
        int y = ListTop + i * (ListRowH + ListGap) - scrollY;
        if (y + ListRowH < ListTop || y > ListTop + viewH) continue;  // off-viewport
        var r = new Rectangle(ListX, y, rowW, ListRowH);
        bool sel = i == keyIndex;
        bool hov = i == hoverIndex;
        using (var path = RoundedPath(r.X, r.Y, r.Width, r.Height, 9))
        {
          g.FillPath(hov ? hoverFill : rowFill, path);
          if (sel) g.DrawPath(selBorder, path);
        }
        var mr = new Rectangle(r.X + 14, r.Y + 8, r.Width - 14 - 32, 20);
        DrawEllipsis(g, rows[i].Label, uiFont, mainBrush, mr);
        var pr = new Rectangle(r.X + 14, r.Y + 26, r.Width - 14 - 32, 16);
        DrawEllipsis(g, PathTail(rows[i].Path), monoFont, dimBrush, pr);
        if (sel)
        {
          float cx = r.Right - 20, cy = r.Top + r.Height / 2f;
          g.DrawLines(checkPen, new PointF[] {
            new PointF(cx - 5, cy), new PointF(cx - 1, cy + 4), new PointF(cx + 6, cy - 4) });
        }
      }
      // thin scrollbar thumb when the list overflows
      if (maxScroll > 0)
      {
        int trackW = 4, tx = WMulti - 14;
        float thumbH = Math.Max(24f, viewH * (float)viewH / (viewH + maxScroll));
        float ty = ListTop + (float)scrollY / maxScroll * Math.Max(0, viewH - thumbH);
        using (var thumb = new SolidBrush(Color.FromArgb(110, 120, 134)))
        using (var tp = RoundedPath(tx, (int)ty, trackW, (int)thumbH, 2))
          g.FillPath(thumb, tp);
      }
    }

    // footer: countdown (right) + overflow/stale note (center)
    var sfC = new StringFormat();
    sfC.Alignment = StringAlignment.Far;
    if (!chooseDone)
    {
      double left = Math.Max(0, (chooseDeadline - DateTime.UtcNow).TotalSeconds);
      int secs = (int)Math.Ceiling(left);
      using (var hint = new SolidBrush(dim))
        g.DrawString(secs + " 秒后自动启动", monoFont, hint,
          new RectangleF(12, HMulti - 34, Width - 24, 18), sfC);
    }
    string note = null;
    if (maxScroll > 0) note = "共 " + rows.Count + " 个候选 · 滚轮 / ↑↓ 选择";
    else if (stale && cands.HasRealList) note = "候选列表可能已过期";
    if (note != null)
    {
      using (var nb = new SolidBrush(Color.FromArgb(150, 158, 170)))
      {
        var sn = new StringFormat();
        sn.Alignment = StringAlignment.Center;
        g.DrawString(note, tagFont, nb, new RectangleF(0, HMulti - 20, Width, 16), sn);
      }
    }
  }

  /** Right-anchored path tail so the install dir is recognizable in a row. */
  string PathTail(string p)
  {
    if (string.IsNullOrEmpty(p)) return p;
    var segs = p.Split(new[] { '\\', '/' }, StringSplitOptions.RemoveEmptyEntries);
    if (segs.Length <= 3) return p;
    return "…\\" + segs[segs.Length - 2] + "\\" + segs[segs.Length - 1];
  }

  /** How far the list can scroll (0 = fits). */
  int ComputeMaxScroll()
  {
    int viewH = ListViewBottom - ListTop;
    int contentH = rows.Count * ListRowH + (rows.Count > 0 ? (rows.Count - 1) * ListGap : 0);
    return Math.Max(0, contentH - viewH);
  }

  int RowRectAt(Point p)
  {
    int rowW = WMulti - 2 * ListX;
    for (int i = 0; i < rows.Count; i++)
    {
      int y = ListTop + i * (ListRowH + ListGap) - scrollY;
      if (p.X >= ListX && p.X <= ListX + rowW && p.Y >= y && p.Y < y + ListRowH) return i;
    }
    return -1;
  }

  /** Keep the highlighted row inside the scroll viewport. */
  void EnsureKeyVisible()
  {
    int max = ComputeMaxScroll();
    if (max <= 0) { scrollY = 0; return; }
    int top = ListTop + keyIndex * (ListRowH + ListGap) - scrollY;
    int bot = top + ListRowH;
    int viewH = ListViewBottom - ListTop;
    if (top < ListTop) scrollY -= (ListTop - top);
    else if (bot > ListTop + viewH) scrollY += (bot - (ListTop + viewH));
    if (scrollY < 0) scrollY = 0;
    if (scrollY > max) scrollY = max;
  }

  protected override void OnMouseWheel(MouseEventArgs e)
  {
    base.OnMouseWheel(e);
    if (choiceMode != 1 || !listVisible || chooseDone) return;
    int max = ComputeMaxScroll();
    if (max <= 0) return;
    scrollY -= (e.Delta > 0 ? 40 : -40);
    if (scrollY < 0) scrollY = 0;
    if (scrollY > max) scrollY = max;
    var handled = e as HandledMouseEventArgs;
    if (handled != null) handled.Handled = true;
    Invalidate();
  }

  void DrawEllipsis(Graphics g, string text, Font font, Brush brush, Rectangle rect)
  {
    if (string.IsNullOrEmpty(text)) return;
    TextRenderer.DrawText(g, text, font, rect, ((SolidBrush)brush).Color,
      TextFormatFlags.SingleLine | TextFormatFlags.Left
      | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis
      | TextFormatFlags.NoPrefix);
  }

  protected override void OnMouseMove(MouseEventArgs e)
  {
    base.OnMouseMove(e);
    if (choiceMode != 1 || !listVisible || chooseDone) return;
    int h = RowRectAt(e.Location);
    if (h != hoverIndex)
    {
      hoverIndex = h;
      Cursor = h >= 0 ? Cursors.Hand : Cursors.Default;
      Invalidate();
    }
  }

  protected override void OnMouseLeave(EventArgs e)
  {
    base.OnMouseLeave(e);
    if (hoverIndex != -1) { hoverIndex = -1; Cursor = Cursors.Default; Invalidate(); }
  }

  protected override void OnMouseClick(MouseEventArgs e)
  {
    base.OnMouseClick(e);
    if (choiceMode != 1 || !listVisible || chooseDone) return;
    if (e.Button != MouseButtons.Left) return;
    int i = RowRectAt(e.Location);
    if (i >= 0) DoChoose(i);
  }

  protected override void OnKeyDown(KeyEventArgs e)
  {
    base.OnKeyDown(e);
    if (choiceMode != 1 || !listVisible || chooseDone) return;
    if (e.KeyCode == Keys.Up) { keyIndex = Math.Max(0, keyIndex - 1); EnsureKeyVisible(); Invalidate(); e.Handled = true; }
    else if (e.KeyCode == Keys.Down) { keyIndex = Math.Min(rows.Count - 1, keyIndex + 1); EnsureKeyVisible(); Invalidate(); e.Handled = true; }
    else if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space) { DoChoose(keyIndex); e.Handled = true; }
    else if (e.KeyCode == Keys.Escape) { fadeOut = true; fadeTarget = 0f; e.Handled = true; }
  }

  static System.Drawing.Drawing2D.GraphicsPath RoundedPath(float x, float y, float w, float h, float r)
  {
    var p = new System.Drawing.Drawing2D.GraphicsPath();
    p.AddArc(x, y, r, r, 180, 90);
    p.AddArc(x + w - r, y, r, r, 270, 90);
    p.AddArc(x + w - r, y + h - r, r, r, 0, 90);
    p.AddArc(x, y + h - r, r, r, 90, 90);
    p.CloseFigure();
    return p;
  }

  bool Probe()
  {
    string host = "127.0.0.1";
    try { host = new Uri(cfg.Url).Host; } catch { }
    try
    {
      using (var c = new System.Net.Sockets.TcpClient())
      {
        var ok = c.BeginConnect(host, cfg.Port, null, null);
        bool done = ok.AsyncWaitHandle.WaitOne(DshDockProgram.PortProbeMs);
        if (done && c.Connected) { c.Close(); return true; }
      }
    }
    catch { }
    return false;
  }

  void StartServer()
  {
    string target = serverBatch ?? cfg.Batch;
    DshDockProgram.Diag("spawn batch: " + target);
    var pi = new ProcessStartInfo("cmd.exe", "/c \"" + target + "\"")
    {
      UseShellExecute = false,
      CreateNoWindow = true,
    };
    try
    {
      spawnProc = Process.Start(pi);
      spawnAt = DateTime.UtcNow;
    }
    catch (Exception ex)
    {
      spawnProc = null;
      throw ex;
    }
  }

  /** Single-spawner lock: of N racing launchers exactly one starts the server;
   *  a crashed spawner's lock is taken over after 60 s. */
  bool TryTakeSpawnLock()
  {
    string lp = cfg.Lock;
    try
    {
      using (var fs = new FileStream(lp, FileMode.CreateNew, FileAccess.Write))
      {
        byte[] b = System.Text.Encoding.UTF8.GetBytes(DateTime.UtcNow.Ticks.ToString());
        fs.Write(b, 0, b.Length);
      }
      return true;
    }
    catch { }
    try
    {
      var fi = new FileInfo(lp);
      if (fi.Exists && DateTime.UtcNow - fi.LastWriteTimeUtc
        > TimeSpan.FromSeconds(DshDockProgram.SpawnLockTakeoverSec))
      {
        try { File.Delete(lp); } catch { }
        try
        {
          using (var fs = new FileStream(lp, FileMode.CreateNew, FileAccess.Write))
          {
            byte[] b = System.Text.Encoding.UTF8.GetBytes(DateTime.UtcNow.Ticks.ToString());
            fs.Write(b, 0, b.Length);
          }
          return true;
        }
        catch { }
      }
    }
    catch { }
    return false;
  }

  void TryClearSpawnLock()
  {
    try { if (File.Exists(cfg.Lock)) File.Delete(cfg.Lock); } catch { }
  }

  static Region RoundedRegion(int w, int h, int r)
  {
    var path = new System.Drawing.Drawing2D.GraphicsPath();
    path.AddArc(0, 0, r, r, 180, 90);
    path.AddArc(w - r, 0, r, r, 270, 90);
    path.AddArc(w - r, h - r, r, r, 0, 90);
    path.AddArc(0, h - r, r, r, 90, 90);
    path.CloseFigure();
    return new Region(path);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// v0.4.0 tray residency: the whale lives in the notification area as the
// permanent status entry point. Tooltip reflects server state (probe on a
// background thread — a dead port blocks up to 700ms); the menu offers
// 打开 DSH / 重启服务器 / ☑开机自启 / ⏻完全退出 (single click, per user
// preference). The tray stamps its PID into launcher.json so the host stop
// route can clean it up, and its 完全退出 mirrors the host sequence:
// marker -> kill listener -> close every dock Edge window (by profile
// identity, not spawn bookkeeping) -> clear marker -> vanish.
//
// v0.8 adaptive pacing: the poll loop keeps its fast 1.5s cadence only while a
// human is waiting on a transition (boot/restart/open-when-ready); a steady
// running server relaxes to 15s, and the sidebar restart request is delivered
// by a file watcher instead of being noticed on the next tick.
// ─────────────────────────────────────────────────────────────────────────────

sealed class DshTray
{
  const string RunKeySub = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";
  const string RunValueName = "dsh-dock";
  // Adaptive poll cadence (v0.8). The tray is a separate process with no IPC,
  // so it discovers the world by polling — but only the TRANSITIONS need a fast
  // cadence. A steady running server needs none of it: the sidebar restart
  // request now arrives through a file watcher (instant), so the probe relaxes
  // to 15s. Before this, every resident tray sent ~57,600 HTTP requests a day
  // for a state that changes a few times a day.
  const int PollActiveMs = 1500;  // starting / restarting / waiting to open
  const int PollIdleMs = 5000;    // dead or failed: the server may come up from anywhere
  const int PollSteadyMs = 15000; // running, nothing pending

  readonly LauncherConfig cfg;
  readonly bool boot;
  readonly NotifyIcon icon = new NotifyIcon();
  readonly List<Process> edgeWindows = new List<Process>();
  Mutex gate = null; // single-instance mutex held for the tray's lifetime
  Thread poller = null;
  /** Wakes the poll loop out of its adaptive wait the moment the sidebar writes
   *  .restart.request, so a long steady-state interval costs no restart latency. */
  readonly ManualResetEventSlim wake = new ManualResetEventSlim(false);
  FileSystemWatcher restartWatch = null;
  volatile bool watchOk = false;       // false => stay on the fast cadence
  volatile bool stopping = false;
  volatile bool pendingOpen = false;   // open the window the moment ready
  volatile bool spawnWanted = false;   // spawn the batch when port is dead
  bool spawned = false;
  Process spawnProc = null;
  DateTime spawnAt = DateTime.MinValue;
  string state = "starting";           // starting | running | dead | failed | restarting
  MenuItem exitItem = null;
  DateTime lastHttpCheck = DateTime.MinValue;
  /** Body of the restart request already acted on (see ConsumeRestartRequest). */
  string lastHandledRequest = null;

  DshTray(LauncherConfig config, bool boot)
  {
    this.cfg = config;
    this.boot = boot;
  }

  // ── lifecycle ────────────────────────────────────────────────────────────

  /** Single-instance gate: ONE tray icon, ever, across BOTH binary copies
   * (suite dsh-dock-launcher.exe and the desktop "DSH Harness.exe" differ
   * in process NAME, so a name-based liveness check misfired and let a
   * second icon in — a mutex is name-agnostic, race-free, and self-releases
   * when the holder dies). */
  static string MutexName(LauncherConfig cfg)
  {
    return "Local\\dsh-dock-tray-" + cfg.Port;
  }

  /** True when a tray holder exists (mutex object alive == process alive). */
  internal static bool IsRunning(LauncherConfig cfg)
  {
    try
    {
      Mutex existing = Mutex.OpenExisting(MutexName(cfg));
      existing.Dispose();
      return true;
    }
    catch { return false; }
  }

  /** Create the tray and run its message loop until 完全退出. Losing the
   * single-instance race (another tray already holds the mutex) exits
   * silently — the winner keeps the one and only icon. */
  internal static void Run(LauncherConfig cfg, bool boot)
  {
    Mutex gate = new Mutex(false, MutexName(cfg));
    if (!gate.WaitOne(0))
    {
      DshDockProgram.Diag("tray: mutex held by another instance -> exit");
      return;
    }
    var tray = new DshTray(cfg, boot);
    tray.gate = gate;
    tray.Start();
    Application.Run();
    DshDockProgram.Diag("tray loop exited");
  }

  void Start()
  {
    try
    {
      icon.Icon = System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath);
    }
    catch { icon.Icon = SystemIcons.Application; }
    icon.Visible = true;
    icon.Text = "DSH 启动中…";
    BuildMenu();
    icon.MouseClick += delegate(object s, MouseEventArgs e)
    {
      if (e.Button == MouseButtons.Left) OpenDsh();
    };
    WriteTrayPid(cfg, System.Diagnostics.Process.GetCurrentProcess().Id);
    Application.ApplicationExit += delegate { Cleanup(); };
    // Initial facts: alive -> running; dead -> spawn only in boot mode
    // (a user-visible cold start belongs to the card, not the tray).
    bool alive = DshDockProgram.ServerAlive(cfg.Url);
    state = alive ? "running" : (boot ? "starting" : "dead");
    if (boot && !alive)
    {
      spawnWanted = true;
      pendingOpen = false;
    }
    // Arm the restart-request watcher BEFORE the poller so the very first
    // steady wait is already interruptible.
    StartRestartWatch();
    poller = new Thread(PollerLoop);
    poller.IsBackground = true;
    poller.Name = "dsh-dock-tray-poller";
    poller.Start();
  }

  void Cleanup()
  {
    stopping = true;
    Wake(); // release the poller from a 15s steady wait instead of waiting it out
    try { if (restartWatch != null) restartWatch.Dispose(); } catch { }
    WriteTrayPid(cfg, 0);
    try { icon.Visible = false; icon.Dispose(); } catch { }
    try { if (gate != null) gate.ReleaseMutex(); } catch { }
    try { if (gate != null) gate.Dispose(); } catch { }
  }

  // ── adaptive pacing (v0.8) ───────────────────────────────────────────────

  /**
   * Cadence for the NEXT poll. Fast only where a human is waiting on a
   * transition; a steady running server just needs the tooltip refreshed and
   * the restart request noticed — and the latter is watcher-woken now.
   */
  int PollIntervalMs()
  {
    if (state == "starting" || state == "restarting") return PollActiveMs;
    if (pendingOpen || spawnWanted) return PollActiveMs;
    if (state == "running") return watchOk ? PollSteadyMs : PollActiveMs;
    return PollIdleMs;
  }

  /**
   * Watch the launcher directory for the sidebar's restart request so the
   * steady-state interval can be long without delaying 洄游. Filtered to that
   * one file on purpose: the directory also carries a server log that is
   * written continuously, and watching everything would wake the poller as
   * often as the old 1.5s heartbeat.
   */
  void StartRestartWatch()
  {
    try
    {
      string path = RestartPath(cfg);
      string dir = string.IsNullOrEmpty(path) ? null : Path.GetDirectoryName(path);
      if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir)) return;
      restartWatch = new FileSystemWatcher(dir);
      restartWatch.Filter = Path.GetFileName(path);
      restartWatch.NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite;
      restartWatch.Created += delegate { Wake(); };
      restartWatch.Changed += delegate { Wake(); };
      restartWatch.Renamed += delegate { Wake(); };
      restartWatch.EnableRaisingEvents = true;
      watchOk = true;
      DshDockProgram.Diag("tray: restart watcher armed on " + dir);
    }
    catch (Exception e)
    {
      // No watcher => PollIntervalMs() keeps the fast cadence, so 洄游 can
      // never sit unanswered for a whole steady interval.
      watchOk = false;
      DshDockProgram.Diag("tray: restart watcher FAIL: " + e.Message);
    }
  }

  /** Nudge the poll loop out of its wait (watcher thread or shutdown). */
  void Wake()
  {
    try { wake.Set(); } catch { }
  }

  /**
   * Consume the sidebar restart request EXACTLY ONCE.
   *
   * The request file is written by the host and deleted here before the restart
   * runs, but that delete can lose a race with the writer (the host still holds
   * the handle for a few ms) and it used to be swallowed by an empty catch: the
   * file survived, the restarting/starting guard only debounced it, and the very
   * same request restarted the server a second time ~6s later — killing the
   * instance it had just started. Detection used to be up to 1.5s late, which
   * hid the race; the watcher now wakes the loop ~50ms after the write, so it
   * bites. Hence: retry the delete, and remember the body — a request whose
   * content was already handled is deleted and ignored, never restarted again.
   * @returns true when this is a request the tray has not acted on yet.
   */
  bool ConsumeRestartRequest()
  {
    string path = RestartPath(cfg);
    if (path == null) return false;
    string body;
    try
    {
      if (!File.Exists(path)) return false;
      body = File.ReadAllText(path).Trim(); // throws while the host is mid-write
    }
    catch { return false; }                 // -> retried on the next tick
    for (int attempt = 0; attempt < 5; attempt++)
    {
      try { File.Delete(path); break; }
      catch { Thread.Sleep(120); }
    }
    if (body.Length > 0 && body == lastHandledRequest) return false;
    lastHandledRequest = body;
    return true;
  }

  // ── menu ─────────────────────────────────────────────────────────────────

  void BuildMenu()
  {
    var open = new MenuItem("打开 DSH", delegate { OpenDsh(); });
    var restart = new MenuItem("重启服务器", delegate { RestartServer(); });
    var auto = new MenuItem("开机自启", delegate { ToggleAutostart(); });
    auto.Checked = ReadAutostart();
    exitItem = new MenuItem("完全退出", delegate { ExitClicked(); });
    var sep = new MenuItem("-");
    var menu = new ContextMenu(new MenuItem[] { open, restart, auto, sep, exitItem });
    // Refresh the autostart checkmark on EVERY popup: the state can also be
    // written by the web settings page (settings/set -> registry), and a
    // once-baked checkmark would show a stale state from tray start-up.
    menu.Popup += delegate { auto.Checked = ReadAutostart(); };
    icon.ContextMenu = menu;
  }

  /** 打开 DSH (also tray left-click): open now, or spawn + open when ready. */
  void OpenDsh()
  {
    if (stopping) return;
    DshDockProgram.Diag("tray: open");
    if (DshDockProgram.ServerAlive(cfg.Url))
    {
      if (TryOpenFromLog()) return;
      state = "starting"; // alive but not ready yet — open when it is
      pendingOpen = true;
      return;
    }
    // Server dead: cold-start it from the tray (card-less), open when ready.
    pendingOpen = true;
    spawnWanted = true;
    state = "starting";
  }

  /**
   * 重启服务器: close every dock window -> marker -> kill the listener ->
   * wait the port down -> clear the marker -> spawn the batch again -> open
   * ONE fresh window when ready (user preference: no stale pre-restart pages;
   * their tokens died with the old server anyway). This is the first-class
   * restart the plugin never had (previously: full exit + double-click,
   * ~15s of manual steps).
   */
  void RestartServer()
  {
    if (stopping || state == "restarting") return;
    DshDockProgram.Diag("tray: restart server");
    state = "restarting";
    pendingOpen = true;
    // User preference: kill old dock windows first — they hold dead tokens
    // once the listener dies; only the freshly auto-opened window remains.
    CloseDockWindows();
    WriteStoppingMarker();
    foreach (int pid in ListenerPids())
    {
      try { System.Diagnostics.Process.GetProcessById(pid).Kill(); }
      catch { }
    }
    // The poller's spawn path takes over once the port is really down.
    spawnWanted = true;
    spawned = false;
  }

  /** ☑开机自启: toggle the HKCU Run entry pointing at the suite exe --boot. */
  void ToggleAutostart()
  {
    try
    {
      bool on = !ReadAutostart();
      WriteAutostart(on, cfg);
      icon.ContextMenu.MenuItems[2].Checked = on;
      DshDockProgram.Diag("tray: autostart " + (on ? "on" : "off"));
    }
    catch (Exception e)
    {
      DshDockProgram.Diag("tray: autostart FAIL: " + e.Message);
      Balloon("开机自启设置失败: " + e.Message, ToolTipIcon.Error);
    }
  }

  /** 完全退出 — single click (user preference: no two-step guard on the
   * tray menu; the sidebar menu keeps its in-page two-step arm). */
  void ExitClicked()
  {
    if (stopping) return;
    if (exitItem != null) exitItem.Text = "完全退出";
    DshDockProgram.Diag("tray: full exit");
    stopping = true;
    WriteStoppingMarker();
    foreach (int pid in ListenerPids())
    {
      try { System.Diagnostics.Process.GetProcessById(pid).Kill(); }
      catch { }
    }
    DshDockProgram.WaitForPortDown(cfg, 15000);
    CloseDockWindows();
    TryDeleteMarker();
    Application.Exit();
  }

  /**
   * Close every DSH-dock Edge window — by IDENTITY (command line carries the
   * dedicated --user-data-dir profile), not by spawn bookkeeping. Windows
   * opened by a previous/double-click launcher outlive their spawner, and a
   * tray that restarted mid-session would otherwise orphan them. Graceful
   * close first, force-kill the survivors after a short grace.
   */
  void CloseDockWindows()
  {
    string profile = cfg.Profile ?? "";
    var targets = new List<int>();
    try
    {
      var searcher = new System.Management.ManagementObjectSearcher(
        "SELECT ProcessId, CommandLine FROM Win32_Process WHERE Name = 'msedge.exe'");
      foreach (var o in searcher.Get())
      {
        string cmd = Convert.ToString(o["CommandLine"]);
        if (string.IsNullOrEmpty(cmd) || profile.Length == 0) continue;
        if (cmd.IndexOf(profile, StringComparison.OrdinalIgnoreCase) < 0) continue;
        targets.Add(Convert.ToInt32(o["ProcessId"]));
      }
      searcher.Dispose();
    }
    catch (Exception e) { DshDockProgram.Diag("CloseDockWindows enum FAIL: " + e.Message); }
    // Fallback: tracked windows when WMI enumeration failed.
    if (targets.Count == 0)
    {
      foreach (Process p in edgeWindows)
      {
        try { if (!p.HasExited) targets.Add(p.Id); } catch { }
      }
    }
    foreach (int pid in targets)
    {
      try { System.Diagnostics.Process.GetProcessById(pid).CloseMainWindow(); }
      catch { }
    }
    System.Threading.Thread.Sleep(900);
    foreach (int pid in targets)
    {
      try
      {
        var p = System.Diagnostics.Process.GetProcessById(pid);
        if (!p.HasExited) p.Kill();
      }
      catch { }
    }
    edgeWindows.Clear();
  }

  // ── poller (background thread — probes block) ────────────────────────────

  void PollerLoop()
  {
    while (!stopping)
    {
      // Reset BEFORE the pass: a request landing while PollOnce runs leaves the
      // signal set, so the wait below returns at once instead of sleeping out
      // the (now much longer) steady interval.
      wake.Reset();
      try { PollOnce(); }
      catch (Exception ex) { DshDockProgram.Diag("tray poll FAIL: " + ex.Message); }
      if (stopping) break;
      UpdateTooltip();
      int waitMs = PollIntervalMs();
      try { wake.Wait(waitMs); }
      catch (ObjectDisposedException) { break; }
    }
    DshDockProgram.Diag("tray poller exit");
  }

  void PollOnce()
  {
    if (stopping) return;
    // Sidebar 重启服务器 request (host wrote .restart.request; the tray owns
    // the restart sequence because the host cannot restart its own death).
    if (state != "restarting" && state != "starting" && ConsumeRestartRequest())
    {
      DshDockProgram.Diag("tray: restart requested from sidebar");
      RestartServer();
    }
    bool alive = DshDockProgram.ServerAlive(cfg.Url);
    if (alive)
    {
      state = "running";
      spawned = false;
      if (pendingOpen && (DateTime.UtcNow - lastHttpCheck).TotalMilliseconds
        >= DshDockProgram.GateThrottleMs)
      {
        lastHttpCheck = DateTime.UtcNow;
        if (TryOpenFromLog()) pendingOpen = false;
      }
      return;
    }
    // Port dead.
    if (pendingOpen) spawnWanted = true;
    if (spawnWanted && !spawned)
    {
      // Restart flow: the old listener must be fully down before a new one
      // may take the port (start-server.cmd waits internally too, but the
      // marker must not read "fresh" or the next double-click would stall).
      if (state == "restarting")
      {
        if (!DshDockProgram.WaitForPortDown(cfg, 15000)) return; // still dying
        TryDeleteMarker();
      }
      spawned = true;
      spawnAt = DateTime.UtcNow;
      try
      {
        DshDockProgram.Diag("tray spawn batch: " + cfg.Batch);
        var pi = new ProcessStartInfo("cmd.exe", "/c \"" + cfg.Batch + "\"")
        {
          UseShellExecute = false,
          CreateNoWindow = true,
        };
        spawnProc = System.Diagnostics.Process.Start(pi);
        state = "starting";
      }
      catch (Exception ex)
      {
        DshDockProgram.Diag("tray spawn FAIL: " + ex.Message);
        state = "failed";
        spawnWanted = false;
        Balloon("服务器启动失败: " + ex.Message + "\n日志:" + cfg.Log, ToolTipIcon.Error);
      }
      return;
    }
    // Early death detection: the spawned batch exited without listening.
    if (spawned && spawnProc != null && (DateTime.UtcNow - spawnAt).TotalSeconds > 4)
    {
      try
      {
        if (spawnProc.HasExited)
        {
          state = "failed";
          spawned = false;
          spawnWanted = false;
          pendingOpen = false;
          Balloon("服务器启动后立即退出(端口 " + cfg.Port
            + ")。日志:" + cfg.Log, ToolTipIcon.Error);
        }
      }
      catch { }
      return;
    }
    if (state == "running") state = "dead"; // died without an exit request
  }

  void UpdateTooltip()
  {
    string text;
    if (state == "running") text = "DSH 运行中 · 端口 " + cfg.Port;
    else if (state == "starting" || state == "restarting") text = "DSH 启动中… · 端口 " + cfg.Port;
    else if (state == "failed") text = "DSH 启动失败 · 日志:" + cfg.Log;
    else text = "服务器未运行 · 点左键打开";
    try { icon.Text = text.Length > 63 ? text.Substring(0, 63) : text; }
    catch { }
  }

  void Balloon(string msg, ToolTipIcon kind)
  {
    try
    {
      icon.ShowBalloonTip(6000, "DSH Dock", msg, kind);
    }
    catch { }
  }

  /** Re-read the log, health-gate the token URL, open + adopt the window. */
  bool TryOpenFromLog()
  {
    string url = DshDockProgram.ReadTokenUrl(cfg.Log);
    if (url == null) return false;
    if (!DshDockProgram.HttpReady(url)) return false;
    DshDockProgram.Diag("tray open: " + url);
    Process p = DshDockProgram.LaunchEdge(url, cfg.Profile);
    if (p != null) edgeWindows.Add(p);
    return true;
  }

  // ── shared state files / registry ────────────────────────────────────────

  /** Derive the manifest path (old inis lack the v0.4.0 keys). */
  static string ManifestPath(LauncherConfig cfg)
  {
    if (!string.IsNullOrEmpty(cfg.Manifest)) return cfg.Manifest;
    string dir = string.IsNullOrEmpty(cfg.Log) ? null : Path.GetDirectoryName(cfg.Log);
    return dir == null ? null : Path.Combine(dir, "launcher.json");
  }

  static string SettingsPath(LauncherConfig cfg)
  {
    if (!string.IsNullOrEmpty(cfg.Settings)) return cfg.Settings;
    string dir = string.IsNullOrEmpty(cfg.Log) ? null : Path.GetDirectoryName(cfg.Log);
    return dir == null ? null : Path.Combine(dir, "settings.json");
  }

  /** Sidebar restart-request file (next to the other suite files). */
  static string RestartPath(LauncherConfig cfg)
  {
    string dir = string.IsNullOrEmpty(cfg.Log) ? null : Path.GetDirectoryName(cfg.Log);
    return dir == null ? null : Path.Combine(dir, ".restart.request");
  }

  /** trayStay setting (default on when the file is missing/unreadable). */
  internal static bool ReadTrayStay(LauncherConfig cfg)
  {
    try
    {
      string path = SettingsPath(cfg);
      if (string.IsNullOrEmpty(path) || !File.Exists(path)) return true;
      var ser = new System.Web.Script.Serialization.JavaScriptSerializer();
      var root = ser.DeserializeObject(File.ReadAllText(path, System.Text.Encoding.UTF8))
        as Dictionary<string, object>;
      if (root != null && root.ContainsKey("trayStay")) return Convert.ToBoolean(root["trayStay"]);
    }
    catch { }
    return true;
  }

  /** Stamp (or clear, pid<=0) trayPid inside launcher.json, merging keys. */
  internal static void WriteTrayPid(LauncherConfig cfg, int pid)
  {
    try
    {
      string path = ManifestPath(cfg);
      if (string.IsNullOrEmpty(path)) return;
      var ser = new System.Web.Script.Serialization.JavaScriptSerializer();
      Dictionary<string, object> root = null;
      try
      {
        root = ser.DeserializeObject(File.ReadAllText(path, System.Text.Encoding.UTF8))
          as Dictionary<string, object>;
      }
      catch { }
      if (root == null) root = new Dictionary<string, object>();
      if (pid > 0) root["trayPid"] = pid;
      else root.Remove("trayPid");
      File.WriteAllText(path, ser.Serialize(root), new System.Text.UTF8Encoding(false));
    }
    catch (Exception e) { DshDockProgram.Diag("WriteTrayPid FAIL: " + e.Message); }
  }

  /** Suite exe the Run entry launches (stable path; falls back to self). */
  static string AutostartExe(LauncherConfig cfg)
  {
    string dir = string.IsNullOrEmpty(cfg.Log) ? null : Path.GetDirectoryName(cfg.Log);
    string exe = dir == null ? null : Path.Combine(dir, "dsh-dock-launcher.exe");
    if (!string.IsNullOrEmpty(exe) && File.Exists(exe)) return exe;
    return Application.ExecutablePath;
  }

  internal static bool ReadAutostart()
  {
    try
    {
      using (RegistryKey k = Registry.CurrentUser.OpenSubKey(RunKeySub))
      {
        return k != null && k.GetValue(RunValueName) != null;
      }
    }
    catch { return false; }
  }

  internal static void WriteAutostart(bool on, LauncherConfig cfg)
  {
    using (RegistryKey k = Registry.CurrentUser.CreateSubKey(RunKeySub))
    {
      if (on) k.SetValue(RunValueName, "\"" + AutostartExe(cfg) + "\" --boot");
      else k.DeleteValue(RunValueName, false);
    }
  }

  // ── stop helpers (mirror the host route's semantics) ─────────────────────

  /** PIDs LISTENING on our port (netstat, ~100ms; never Get-NetTCPConnection). */
  List<int> ListenerPids()
  {
    var ids = new List<int>();
    try
    {
      var pi = new ProcessStartInfo("netstat", "-ano")
      {
        UseShellExecute = false,
        CreateNoWindow = true,
        RedirectStandardOutput = true,
      };
      using (Process p = Process.Start(pi))
      {
        string outText = p.StandardOutput.ReadToEnd();
        p.WaitForExit(3000);
        string portToken = ":" + cfg.Port + " ";
        foreach (string raw in outText.Split('\n'))
        {
          string line = raw.Trim();
          if (!line.StartsWith("TCP") || !line.Contains("LISTENING")) continue;
          if (!line.Contains(portToken)) continue;
          string[] parts = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
          int pid;
          if (int.TryParse(parts[parts.Length - 1], out pid) && pid > 0) ids.Add(pid);
        }
      }
    }
    catch (Exception e) { DshDockProgram.Diag("ListenerPids FAIL: " + e.Message); }
    // Never kill ourselves, whatever netstat says.
    int self = Process.GetCurrentProcess().Id;
    return ids.FindAll(delegate(int id) { return id != self; });
  }

  void WriteStoppingMarker()
  {
    try
    {
      long epoch = (long)(DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds;
      File.WriteAllText(cfg.Stopping, epoch.ToString());
    }
    catch { }
  }

  void TryDeleteMarker()
  {
    try { if (File.Exists(cfg.Stopping)) File.Delete(cfg.Stopping); }
    catch { }
  }
}
