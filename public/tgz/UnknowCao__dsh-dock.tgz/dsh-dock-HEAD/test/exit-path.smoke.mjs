/**
 * exit-path.smoke.mjs — offline tests for the /launcher/api/stop exit
 * orchestration (armGracefulExit in index.js).
 *
 * Run:   node --test test/exit-path.smoke.mjs
 *
 * Why this exists: a real host assigns `process.exitCode` exactly once, after
 * the Cordis tree finished disposing (and clears its own 5s force-exit timer at
 * that same moment); the process is then expected to fall out of the event loop
 * by itself. In practice a leaked handle keeps it alive, so exits used to end on
 * a flat 7s watchdog. These tests pin the replacement contract:
 *
 *   1. a signalled dispose exits at "dispose time + flush", never the backstop;
 *   2. the stop log names the elapsed time and the still-live resource types;
 *   3. a host that never signals falls back to the backstop;
 *   4. a throwing appExit exits immediately with code 1;
 *   5. a pre-existing process.exitCode is NOT mistaken for the signal.
 *
 * Safety: `force` is injected, so the test runner is never exited, and
 * `process.exitCode` is restored in a finally block.
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { armGracefulExit } from '../index.js'

/** Collect the exit call plus the stop-log lines an orchestrator produced. */
function recorder() {
  const calls = []
  const logs = []
  let resolve
  const done = new Promise((r) => { resolve = r })
  return {
    logs,
    calls,
    done,
    force: (code) => {
      calls.push({ code, at: Date.now() })
      resolve(calls[0])
    },
    log: (event, detail) => logs.push(`${event} ${detail}`),
  }
}

test('a signalled dispose exits at dispose time + flush, never at the backstop', async () => {
  const leak = setInterval(() => {}, 1000) // stands in for the handle that really leaks
  const rec = recorder()
  const started = Date.now()
  try {
    const dispose = armGracefulExit({
      exit: () => { setTimeout(() => { process.exitCode = 0 }, 120) },
      force: rec.force,
      log: rec.log,
      graceMs: 10, pollMs: 5, flushMs: 40, backstopMs: 3000,
    })
    const call = await rec.done
    const elapsed = call.at - started
    assert.equal(call.code, 0)
    assert.ok(elapsed >= 120, `cannot exit before disposal finished (${elapsed}ms)`)
    assert.ok(elapsed < 1000, `must not wait for the 3s backstop (${elapsed}ms)`)
    assert.ok(rec.logs.some((l) => /dispose finished in \d+ms \(exitCode=0\)/.test(l)),
      `missing the dispose-duration line: ${JSON.stringify(rec.logs)}`)
    assert.equal(rec.calls.length, 1, 'must exit exactly once')
    dispose()
  } finally {
    clearInterval(leak)
    process.exitCode = undefined
  }
})

test('the stop log names the resource types still holding the loop', async () => {
  const leak = setInterval(() => {}, 1000)
  const rec = recorder()
  try {
    const dispose = armGracefulExit({
      exit: () => { setTimeout(() => { process.exitCode = 0 }, 60) },
      force: rec.force,
      log: rec.log,
      graceMs: 5, pollMs: 5, flushMs: 20, backstopMs: 3000,
    })
    await rec.done
    // both snapshots are logged, and a handle that predates the stop request
    // must still be visible in the final one (a delta would have hidden it)
    assert.ok(rec.logs.some((l) => /resources at request: .*Timeout×[1-9]/.test(l)),
      `missing the request-time snapshot: ${JSON.stringify(rec.logs)}`)
    const evidence = rec.logs.find((l) => l.includes('resources at exit:'))
    assert.ok(evidence, `missing the exit-time snapshot: ${JSON.stringify(rec.logs)}`)
    assert.match(evidence, /resources at exit: .*Timeout×[1-9]/, evidence)
    dispose()
  } finally {
    clearInterval(leak)
    process.exitCode = undefined
  }
})

test('a host that never signals disposal falls back to the backstop', async () => {
  const rec = recorder()
  const started = Date.now()
  const dispose = armGracefulExit({
    exit: () => {}, // signals nothing
    force: rec.force,
    log: rec.log,
    graceMs: 5, pollMs: 5, flushMs: 5, backstopMs: 150,
  })
  const call = await rec.done
  const elapsed = call.at - started
  assert.equal(call.code, 0)
  assert.ok(elapsed >= 150 && elapsed < 1200, `backstop timing off (${elapsed}ms)`)
  assert.ok(rec.logs.some((l) => l.includes('backstop: host never signalled disposal')),
    JSON.stringify(rec.logs))
  assert.ok(!rec.logs.some((l) => l.includes('dispose finished')), 'no completion was signalled')
  dispose()
})

test('a throwing appExit exits immediately with code 1', async () => {
  const rec = recorder()
  const dispose = armGracefulExit({
    exit: () => { throw new Error('boom') },
    force: rec.force,
    log: rec.log,
    graceMs: 5, pollMs: 5, flushMs: 5, backstopMs: 3000,
  })
  const call = await rec.done
  assert.equal(call.code, 1)
  assert.ok(rec.logs.some((l) => l.includes('appExit threw (boom)')), JSON.stringify(rec.logs))
  dispose()
})

test('a pre-existing process.exitCode is not mistaken for the completion signal', async () => {
  const rec = recorder()
  process.exitCode = 7 // set before arming, e.g. by an unrelated plugin
  try {
    const dispose = armGracefulExit({
      exit: () => {}, // never changes it
      force: rec.force,
      log: rec.log,
      graceMs: 5, pollMs: 5, flushMs: 5, backstopMs: 120,
    })
    const call = await rec.done
    assert.ok(rec.logs.some((l) => l.includes('backstop: host never signalled disposal')),
      JSON.stringify(rec.logs))
    assert.ok(!rec.logs.some((l) => l.includes('dispose finished')),
      'an unchanged exitCode must not read as disposal')
    assert.equal(call.code, 0)
    dispose()
  } finally {
    process.exitCode = undefined
  }
})

test('the returned disposer cancels every armed timer', async () => {
  const rec = recorder()
  const dispose = armGracefulExit({
    exit: () => { setTimeout(() => { process.exitCode = 0 }, 30) },
    force: rec.force,
    log: rec.log,
    graceMs: 5, pollMs: 5, flushMs: 5, backstopMs: 60,
  })
  dispose()
  await new Promise((r) => setTimeout(r, 200))
  assert.equal(rec.calls.length, 0, 'a disposed orchestrator must not exit anything')
  process.exitCode = undefined
})
