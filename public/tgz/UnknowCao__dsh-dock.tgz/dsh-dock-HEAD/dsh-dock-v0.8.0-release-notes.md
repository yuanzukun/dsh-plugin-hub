# dsh-dock v0.8.0 — 托盘节奏自适应 + 退出确定性 + 重启恰好一次（含发布把关修复）

> 基于 **v0.7.0**（含其全部能力：自适应候选发现 M1/B1–B3、自定义额外路径 M2、鲸湾菜单、托盘、
> 重启、自启、设置页）。本版首次让**常驻托盘的轮询随状态变化**、让**退出在宿主给出完成信号时立即收尾**，
> 并修掉发布把关评审里发现的 8 个会在真实使用中咬人的缺陷。
> 改动集中在 `candidates.mjs` / `index.js` / `client.js` / `src/DshDockLauncher.cs` 与重编的启动器 exe。

## 为什么改

三件事原本都不对：

1. **托盘的 1.5s 心跳是恒定值。** 托盘是独立进程、没有任何 IPC，只能轮询感知世界——但只有
   **转换期**（冷启动、重启、等待开窗）需要快节奏；稳态下它每天发 ~57,600 次本机 HTTP，只为刷新
   一个几乎不变的状态。侧栏「洄游」也是靠「下一个 tick 撞见」来发现，所以间隔不敢放松。
2. **「归湾」每次都要等满 7s 看门狗。** 宿主的 `createProcessShutdown` 在整树 dispose 完成后会
   **清掉自己那个 5s 强制退出定时器**、只设 `process.exitCode`，然后指望事件循环自然排空——而实际有
   handle 没释放，所以唯一能结束进程的只剩 dsh-dock 的固定 7s 看门狗（`stop.log` 里 7/7 次都是它）。
3. **一次重启请求可能被执行两次。** 宿主写入的句柄还在时，托盘的 `File.Delete` 会静默失败、文件留在
   原地；状态守卫只在 `restarting/starting` 期间去重，等状态回到 `running` 就会把**同一份请求再重启
   一次**——把刚起来的服务器又杀掉。

## 新增 / 改动

| 能力 | 行为 | 入口 |
|---|---|---|
| 轮询间隔按状态自适应（v0.8） | `starting`/`restarting`/待开窗 1.5s；稳定运行 15s；服务器未运行 5s | 自动 |
| 重启请求文件监视（v0.8） | 只监视 `.restart.request` 一个文件；写入即唤醒轮询线程（实测 ~50ms），因此稳态间隔可以拉长而不增加洄游延迟；watcher 装载失败自动退回 1.5s | 自动 |
| 退出以宿主信号为准（v0.8） | 调 `ctx.appExit` 后轮询 `process.exitCode` 的**变化**作为「dispose 已完成」；完成后 flush 0.25s 自行 `process.exit`；宿主始终不发信号则 6s 兜底 | 侧栏「归湾」 |
| 退出诊断 | `stop.log` 每次记录 `resources at request` / `resources at exit` 与 `dispose finished in Xms` | `~/.dsh/launcher/stop.log` |
| 重启请求恰好一次（v0.8） | 读内容 → 重试删除 → 按 body 记忆已处理的请求：同一份只执行一次，不同 body 照常执行 | 自动 |
| 冷启动失败后可立即重试（修复） | 只有**抢到锁**才闩 `spawned`，失败/关窗时释放自己持有的锁——此前失败一次会 60s 锁死并让每次重试白等 3 分钟 | 双击桌面程序 |
| 端口真正传给 dsh（修复） | 批次生成时把 `--port <port>` 插到 `web` 之后——此前端口只写进了等待循环与 `launcher.ini` 的 URL，dsh 仍绑默认 3080，自定义端口场景必失败 | 自动 |
| 候选校验入口文件（修复） | 除了 `package.json`，还要求 `lib/bin.js` 存在——半装的「最新版」不再排第一、拿默认批次、被倒计时默认选中 | 自动 |
| 批次 `%` 转义（修复） | `%` → `%%`：cmd.exe **在双引号内也展开** `%VAR%`，因此 `C:\tools\50%off` 这类合法路径此前会让批次启动错误目标 | 自动 |
| npx 缓存容错（修复） | `readdirSync` 包上 try/catch——此前一个不可读/异常形状的 `_npx` 会让整次扫描（含首次安装）抛出，且只留一行 `console.warn` | 自动 |
| 失败卡片自适应高度（修复） | 按实测文本高度撑开卡片，补救建议不再被 30px 的状态框裁掉；`.err` 尾部改为在 UI 委托里赋值，不再被覆盖 | 双击桌面程序 |
| 「完全退出」先验响应（修复） | 只有宿主确认接受停止请求才关窗；被拒（403/503/网络错误）时留在页面并提示，而不是关掉窗口让用户以为已退出 | 侧栏「归湾」 |
| 额外路径编辑器以读取完成为门（修复） | 初始读取返回/失败前禁用添加与删除——此前会用「看起来是空」的列表整体覆盖 `extra-roots.json`，抹掉已保存的路径 | 设置 → DSH Dock → 额外路径 |

## 实现落点

- `candidates.mjs`：新增导出 `withPortFlag(args, port)` 并在 `materializeSuite` 里对**每一行候选**注入
  端口（含零候选的 npx 回退批次）；`buildServerBatch` 的 `q()` 增加 `%` → `%%`；global/extra/npx 三类
  候选统一断言 `lib/bin.js`；`npxCacheDirs` 的目录读取加保护。
- `index.js`：删除两处**已经失效**的 `--port` 注入（它们注入的 `serverArgs` 从未传进批次生成器，
  且 `slice(0, webAt + 2)` 在缺少 `web` 令牌时会把命令行截断）；退出编排见上表。
- `client.js`：`fullExit` 改为 `then` 校验响应后才进入 `exiting`（失败弹 `menu.exitFailed` 并留在原地）；
  `ExtraRootsEditor` 的 `loaded` 真正成为门（新增 `setting.extraRootsLoading`），失败时渲染读错误态而
  不是空态；托盘常驻说明改写为与当前行为一致。
- `src/DshDockLauncher.cs`：`holdsSpawnLock` + `ReleaseSpawnLockIfHeld()`（`Fail()`/`OnFormClosed` 释放、
  `Open()` 成功后复位）；抢锁与闩 `spawned` 的顺序调整；`Fail(msg, detail)` 重载 +
  `LayoutFailureFace()` 自适应高度；`OnPaint` 使用 `statusBoxH`。
- `regen-launcher.mjs`：`--port` 注入改用 `withPortFlag`（同样是 `slice` 截断隐患）。
- `package.json` 0.8.0（新增 `scripts.test`）；新增 `.gitignore`（运行期产物不入库）；
  `README.md` / `README.en.md` 的安装命令 pin、退出叙事、托盘常驻说明、激活成本说明与文件树同步更新。

## 验证

- **真机退出实测（2026-09-14，本机两次「归湾」）**：请求 → 进程真正退出分别为 **4.76s / 3.55s**
  （其中 dispose 3.87s / 2.68s，加 0.6s 响应窗与 0.25s flush）；此前 `stop.log` 里 **29 次历史退出全部**是
  `watchdog forcing process.exit(0)` 的固定 7.0s。同一份 `stop.log` 还给出了泄漏线索：请求时刻是
  `FSEventWrap×235 PipeWrap×2 TCPServerWrap×1 TCPSocketWrap×5 Timeout×1`，dispose 后仍撑着事件循环的
  只剩 `TTYWrap×1 TCPSocketWrap×1 Timeout×1`——FSEvent（HMR 监视器）全被正确释放，剩下三类留待 0.8.1 追。
- `node --test`：**18 个用例全绿**（新增 5 条）——`buildServerBatch` 的 `%` 双写、`withPortFlag` 的插入/
  幂等/无 `web` 三态、`materializeSuite` 把 `--port 3099` 写进批次、缺少 `lib/bin.js` 的候选不入列、
  不可读 npx 缓存不抛出。
- **B1 前后对照（隔离配置，真跑 exe）**：让卡片去拉起一个必然失败的批次——
  旧二进制：批次跑 1 次、锁文件留在原地、紧接着第二次双击**无法重试**（累计仍 1 次）；
  新二进制：批次跑 1 次、锁已释放、第二次双击**成功重试**（累计 2 次）。
- 托盘节奏与「恰好一次」的隔离实验见 v0.7.0 之后的评审记录（稳态 15.02s/15.01s、watcher 唤醒 54ms；
  同一请求体持续 14s：旧 3 次重启 / 新 1 次，两次不同请求仍为 2 次）。
- 提交的 exe 与源码一致：以同名输出从仓库源码重编，与 `assets/dsh-dock-launcher.exe` 仅差 18 字节
  （PE 时间戳 + 程序集 MVID）。

## 发布检查单

1. ✅ `git push origin main` —— 提交 `d45d8b8`。
2. ✅ `git tag v0.8.0 && git push origin v0.8.0` —— 附注 tag 已推送（对象 `f9f836c` → `d45d8b8`）；
   README 里 `#v0.8.0` 的安装命令已用真实安装验证（版本 0.8.0、exe 与仓库一致、源码按行尾归一化后逐字节相同）。
   （历史遗留：`v0.6.0` 从未打 tag，`v0.7.0` 指向合并前的分支提交——内容与 main 相同。）
3. ✅ 真机确认：`~/.dsh/launcher/stop.log` 已出现 `dispose finished in 3873ms / 2678ms`，两次「归湾」
   合计 4.76s / 3.55s（见上文「验证」）。

## 未纳入本版（0.8.1 计划）

- 侧栏「归湾」与卡片 spawn 之间的竞态、托盘 `state`/`spawned` 的跨线程同步、「打开 DSH」在日志无 token
  行时永久静默无效、按端口杀进程不做身份校验、`--boot` 不尊重「托盘常驻」。
- 选择不持久（`lastPath` 写了但没人读）、UNC / `\\?\` 根被归一化破坏、junction 别名产生重复行、
  T2 的 8s 预算、`candidates.json` 非原子写。
- 用 `!important` 重排共享槽位（`[data-slot="sidebar.footer.action"]`）——有意为之的共存权衡，但
  上游一旦改掉该属性，鲸湾入口会静默消失。
