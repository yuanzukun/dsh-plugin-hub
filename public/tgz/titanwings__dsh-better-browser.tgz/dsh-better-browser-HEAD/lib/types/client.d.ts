/**
 * Kimi WebBridge daemon client: one POST /command call per browser action.
 *
 * The daemon lives at `http://127.0.0.1:10086` (installed by
 * `curl -fsSL https://cdn.kimi.com/webbridge/install.sh | bash`). Every
 * request carries a top-level `session` naming the current task; tabs opened
 * under one session form one browser tab group. The daemon answers
 * `{ok:true, data}` on success and `{ok:false, error:{code,message}}` on
 * failure (extension not connected, unknown action, page errors, ...).
 *
 * This module is transport-only: it knows nothing about tools or the model.
 * Every failure path throws a typed DSH {@link WebBridgeError} so the tool
 * registry can retain the daemon's own error code verbatim.
 *
 * @module @dsh-external/dsh-better-browser
 */
import { HarnessError } from '@deepseek-ai/dsh-llm';
/** Daemon base URL when the plugin config does not override it. */
export declare const WEBBRIDGE_DEFAULT_URL = "http://127.0.0.1:10086";
/** Default per-call timeout budget (ms) for one daemon round-trip. */
export declare const WEBBRIDGE_DEFAULT_TIMEOUT_MS = 30000;
/** One browser-control command understood by the daemon. */
export type WebBridgeAction = 'navigate' | 'find_tab' | 'snapshot' | 'click' | 'fill' | 'evaluate' | 'screenshot' | 'network' | 'upload' | 'save_as_pdf' | 'list_tabs' | 'close_tab' | 'close_session';
/** Client options. Both fields are validated by the plugin config. */
export interface WebBridgeClientOptions {
    /** Daemon base URL. Defaults to {@link WEBBRIDGE_DEFAULT_URL}. */
    readonly baseUrl?: string;
    /** Per-call timeout budget (ms). Defaults to {@link WEBBRIDGE_DEFAULT_TIMEOUT_MS}. */
    readonly timeoutMs?: number;
}
/** A rejected daemon call (transport, HTTP, or daemon-level rejection). */
export declare class WebBridgeError extends HarnessError {
    readonly action: WebBridgeAction;
    /** Original human-readable daemon/transport detail without the code prefix. */
    readonly detail: string;
    constructor(message: string, code: string, action: WebBridgeAction);
}
/** Successful daemon payload (`data` is action-specific). */
export interface WebBridgeOk {
    ok: true;
    data: Record<string, unknown>;
}
/** Validate the resolved client options; throws a loud configuration error. */
export declare function validateClientOptions(options: WebBridgeClientOptions): Required<WebBridgeClientOptions>;
/**
 * Call the daemon once. Every failure — daemon unreachable, non-2xx HTTP
 * status, unparseable body, or the daemon's own `{ok:false}` rejection —
 * throws {@link WebBridgeError} with the daemon's error code when one exists.
 * @param action - one browser-control command.
 * @param args - action-specific arguments.
 * @param session - task/session label grouping this call's tabs.
 * @param options - resolved client options (see {@link validateClientOptions}).
 * @param callerSignal - caller/turn cancellation fused with the local timeout.
 * @returns The daemon's `data` payload on success.
 */
export declare function webbridgeCommand(action: WebBridgeAction, args: Record<string, unknown>, session: string, options?: WebBridgeClientOptions, callerSignal?: AbortSignal): Promise<WebBridgeOk['data']>;
