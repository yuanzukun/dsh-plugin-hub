/**
 * Kimi WebBridge model tools: browser control through the local daemon.
 *
 * Every tool talks to `127.0.0.1:10086` (the kimi-webbridge daemon), which
 * drives the user's REAL browser (their login sessions included) through the
 * WebBridge extension. Tools cover navigation, page reading (accessibility
 * tree snapshot), interaction (click/fill/upload), JS evaluation,
 * screenshots/PDF export, network inspection, and tab management. A single `webbridge_session` parameter names the current
 * task on every call — tabs opened under one session form one tab group.
 *
 * Tools are pure functions of their arguments and the resolved client
 * options: no DSH service is required to build or execute them, which keeps
 * this module unit-testable without a running harness.
 *
 * @module @dsh-external/dsh-better-browser
 */
import type { JsonValue } from '@deepseek-ai/dsh-session';
import type { WebBridgeClientOptions } from './client.ts';
/** One tool result as a lossless-JSON value (what the model receives). */
export interface WebBridgeToolResult {
    ok: boolean;
    summary: string;
    detail: JsonValue;
}
/** Registry-ready tool set. `options` overrides the daemon address and budget (tests). */
export declare function webbridgeTools(options?: WebBridgeClientOptions): {
    navigate: import("@deepseek-ai/dsh-tools").ToolDefinition;
    findTab: import("@deepseek-ai/dsh-tools").ToolDefinition;
    snapshot: import("@deepseek-ai/dsh-tools").ToolDefinition;
    click: import("@deepseek-ai/dsh-tools").ToolDefinition;
    fill: import("@deepseek-ai/dsh-tools").ToolDefinition;
    evaluate: import("@deepseek-ai/dsh-tools").ToolDefinition;
    screenshot: import("@deepseek-ai/dsh-tools").ToolDefinition;
    listTabs: import("@deepseek-ai/dsh-tools").ToolDefinition;
    network: import("@deepseek-ai/dsh-tools").ToolDefinition;
    upload: import("@deepseek-ai/dsh-tools").ToolDefinition;
    saveAsPdf: import("@deepseek-ai/dsh-tools").ToolDefinition;
    closeTab: import("@deepseek-ai/dsh-tools").ToolDefinition;
    closeSession: import("@deepseek-ai/dsh-tools").ToolDefinition;
};
/** Names of every tool the plugin registers, in registry order. */
export declare const WEBBRIDGE_TOOL_NAMES: readonly ["webbridge_navigate", "webbridge_find_tab", "webbridge_snapshot", "webbridge_click", "webbridge_fill", "webbridge_evaluate", "webbridge_screenshot", "webbridge_list_tabs", "webbridge_network", "webbridge_upload", "webbridge_save_as_pdf", "webbridge_close_tab", "webbridge_close_session"];
/** Defaults re-exported so composition bundles can surface them in docs. */
export { WEBBRIDGE_DEFAULT_TIMEOUT_MS, WEBBRIDGE_DEFAULT_URL } from './client.ts';
