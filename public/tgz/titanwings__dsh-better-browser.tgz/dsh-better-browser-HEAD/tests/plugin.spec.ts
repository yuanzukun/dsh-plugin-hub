/**
 * Plugin-level tests: mounting `dsh-better-browser` on a real Cordis context with
 * the real dsh-tools registry — registration, HMR-safe disposal, config
 * wiring, and loud misconfiguration. The daemon itself stays mocked.
 */

import { createServer } from 'node:http'
import { readFileSync } from 'node:fs'
import type { AddressInfo } from 'node:net'
import { Context } from '@deepseek-ai/cordis'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import { SystemPrompt } from '@deepseek-ai/dsh-system-prompt'
import { afterEach, describe, expect, it } from 'vitest'
import { apply, Config, name } from '../src/index.ts'
import { WEBBRIDGE_TOOL_NAMES } from '../src/tools.ts'

/** One fake daemon server; records the last request body. */
let server: ReturnType<typeof createServer>
let baseUrl = ''
let lastBody: { action: string; args: Record<string, unknown>; session: string } | null = null

async function startFakeDaemon(): Promise<void> {
  server = createServer((req, res) => {
    const chunks: Buffer[] = []
    req.on('data', (c: Buffer) => chunks.push(c))
    req.on('end', () => {
      lastBody = JSON.parse(Buffer.concat(chunks).toString('utf8'))
      res.writeHead(200, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ ok: true, data: { success: true, url: lastBody?.args.url ?? null } }))
    })
  })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`
}

/** A daemon socket that accepts a request but never writes a response. */
async function startHangingDaemon(): Promise<void> {
  server = createServer(() => { /* never respond */ })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`
}

afterEach(async () => {
  lastBody = null
  if (server !== undefined) {
    await new Promise<void>(resolve => server.close(() => { resolve() }))
    server = undefined as unknown as ReturnType<typeof createServer>
  }
})

/** The full plugin object a Loader would mount (name + inject + apply). */
const plugin = { name, inject: ['tools'], apply }

/** A harness with the real tool registry and the webbridge plugin mounted. */
async function makeHarness(config: Record<string, unknown> = {}) {
  const ctx = new Context()
  await ctx.plugin(SystemPrompt, {})
  await ctx.plugin(ToolRuntime, { mode: 'native' })
  const fiber = await ctx.plugin(plugin, config)
  return { ctx, fiber }
}

describe('dsh-better-browser plugin', () => {
  it('marks Harness-provided platform peers optional for profile installs', () => {
    const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')) as {
      peerDependencies: Record<string, string>
      peerDependenciesMeta?: Record<string, { optional?: boolean }>
    }
    for (const dependency of Object.keys(manifest.peerDependencies)) {
      expect(manifest.peerDependenciesMeta?.[dependency]?.optional).toBe(true)
    }
  })

  it('declares the canonical plugin identity and inject list', () => {
    expect(name).toBe('dsh-better-browser')
    expect(apply).toBeTypeOf('function')
  })

  it('registers every webbridge_* tool on the tools service', async () => {
    const { ctx } = await makeHarness()
    const registered = ctx.tools.schemas().map(schema => schema.name).filter(n => n.startsWith('webbridge_'))
    expect(registered.sort()).toEqual([...WEBBRIDGE_TOOL_NAMES].sort())
    const navigate = ctx.tools.schemas().find(schema => schema.name === 'webbridge_navigate')
    expect(navigate?.description).toContain('real browser')
    expect(navigate?.parameters).toMatchObject({ type: 'object' })
  })

  it('disposing the plugin unregisters every tool (HMR safety)', async () => {
    const { ctx, fiber } = await makeHarness()
    expect(ctx.tools.schemas().some(schema => schema.name === 'webbridge_navigate')).toBe(true)
    await fiber.dispose()
    expect(ctx.tools.schemas().some(schema => schema.name === 'webbridge_navigate')).toBe(false)
    // Re-mounting after disposal works (plugin reload cycle).
    const second = await ctx.plugin(plugin, {})
    expect(ctx.tools.schemas().some(schema => schema.name === 'webbridge_navigate')).toBe(true)
    await second.dispose()
  })

  it('wires the configured baseUrl into executed tools', async () => {
    await startFakeDaemon()
    const { ctx } = await makeHarness({ baseUrl })
    await ctx.tools.execute({
      callId: 'c1' as never,
      name: 'webbridge_navigate',
      arguments: { url: 'https://wired.dev', session: 's' },
      signal: new AbortController().signal,
    })
    expect(lastBody).toEqual({
      action: 'navigate',
      args: { url: 'https://wired.dev' },
      session: 's',
    })
  })

  it('returns action-critical evidence in the real registry model-facing content', async () => {
    await startFakeDaemon()
    server.removeAllListeners('request')
    const noise = 'x'.repeat(40_000)
    const dataByAction: Record<string, Record<string, unknown>> = {
      snapshot: { noise, tree: [{ ref: '@e42', role: 'button', name: 'Continue' }] },
      list_tabs: { noise, tabs: [{ tabId: 7, url: 'https://tabs.dev' }] },
      network: { noise, requestId: 'network-request-7', responseBody: '{"ok":true}' },
      evaluate: { noise, type: 'string', value: 'evaluated-through-registry' },
      screenshot: { noise, path: '/tmp/kimi-webbridge-screenshots/registry.png' },
      save_as_pdf: { noise, path: '/tmp/kimi-webbridge-pdfs/registry.pdf' },
    }
    server.on('request', (req, res) => {
      const chunks: Buffer[] = []
      req.on('data', (chunk: Buffer) => chunks.push(chunk))
      req.on('end', () => {
        const body = JSON.parse(Buffer.concat(chunks).toString('utf8')) as { action: string }
        res.writeHead(200, { 'content-type': 'application/json' })
        res.end(JSON.stringify({ ok: true, data: dataByAction[body.action] }))
      })
    })
    const { ctx } = await makeHarness({ baseUrl })
    const cases = [
      ['webbridge_snapshot', { session: 'evidence' }, '@e42'],
      ['webbridge_list_tabs', { session: 'evidence' }, 'https://tabs.dev'],
      ['webbridge_network', { session: 'evidence', cmd: 'detail', requestId: 'network-request-7' }, 'network-request-7'],
      ['webbridge_evaluate', { session: 'evidence', code: 'document.title' }, 'evaluated-through-registry'],
      ['webbridge_screenshot', { session: 'evidence' }, 'registry.png'],
      ['webbridge_save_as_pdf', { session: 'evidence' }, 'registry.pdf'],
    ] as const
    for (const [toolName, arguments_, expected] of cases) {
      const result = await ctx.tools.execute({
        callId: `${toolName}-model-content` as never,
        name: toolName,
        arguments: arguments_,
        signal: new AbortController().signal,
      })
      expect(result.isError).toBe(false)
      expect(result.content).toHaveLength(1)
      expect(result.content[0]).toMatchObject({ type: 'text' })
      const text = (result.content[0] as { text: string }).text
      expect(text).toContain(expected)
      expect(text).toContain('truncated')
    }
  })

  it('cancels an in-flight fetch through the real DSH tool registry signal', async () => {
    await startHangingDaemon()
    const { ctx } = await makeHarness({ baseUrl, timeoutMs: 1_000 })
    const caller = new AbortController()
    const started = Date.now()
    const pending = ctx.tools.execute({
      callId: 'cancel-through-registry' as never,
      name: 'webbridge_snapshot',
      arguments: { session: 'cancelled-task' },
      signal: caller.signal,
    })
    setTimeout(() => caller.abort(new Error('turn cancelled')), 20)
    const result = await pending
    expect(Date.now() - started).toBeLessThan(500)
    expect(result).toMatchObject({
      isError: true,
      error: { info: { name: 'WebBridgeError', code: 'request_aborted' } },
    })
  })

  it('preserves a daemon 502 error code through the real DSH tool registry', async () => {
    await startFakeDaemon()
    server.removeAllListeners('request')
    server.on('request', (_req, res) => {
      res.writeHead(502, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ ok: false, error: { code: 'tool_error', message: 'no extension connected' } }))
    })
    const { ctx } = await makeHarness({ baseUrl })
    const result = await ctx.tools.execute({
      callId: 'extension-missing-through-registry' as never,
      name: 'webbridge_navigate',
      arguments: { url: 'https://example.com', session: 'diagnostic' },
      signal: new AbortController().signal,
    })
    expect(result).toMatchObject({
      isError: true,
      error: {
        message: 'tool_error: no extension connected',
        info: { name: 'WebBridgeError', code: 'tool_error' },
      },
    })
    expect(result.content).toHaveLength(1)
    expect(result.content[0]).toMatchObject({ type: 'text' })
    expect((result.content[0] as { text: string }).text).toContain('tool_error')
  })

  it('accepts a custom timeoutMs through the config and wires it onto every tool', async () => {
    const { ctx } = await makeHarness({ baseUrl, timeoutMs: 1234 })
    for (const name of WEBBRIDGE_TOOL_NAMES) {
      expect(ctx.tools.get(name)?.timeoutMs).toBe(1234)
    }
  })

  it('fails loud on a malformed baseUrl at mount time', async () => {
    const ctx = new Context()
    await ctx.plugin(SystemPrompt, {})
    await ctx.plugin(ToolRuntime, { mode: 'native' })
    await expect(ctx.plugin(plugin, { baseUrl: 'ftp://nope' })).rejects.toThrow(/baseUrl/)
  })

  it('fails loud on a non-positive timeout at mount time', async () => {
    const ctx = new Context()
    await ctx.plugin(SystemPrompt, {})
    await ctx.plugin(ToolRuntime, { mode: 'native' })
    await expect(ctx.plugin(plugin, { timeoutMs: 0 })).rejects.toThrow(/timeoutMs/)
  })

  it('the DSH Schemastery Config applies defaults', () => {
    const resolved = Config({})
    expect(resolved.baseUrl).toBe('http://127.0.0.1:10086')
    expect(resolved.timeoutMs).toBe(30_000)
  })
})
