/**
 * Model-tool tests: every `webbridge_*` tool forwards the right daemon
 * payload, validates its arguments, and folds the daemon reply into the
 * shared `{ok, summary, detail}` output shape. The daemon is mocked with a
 * local HTTP server; no real browser or daemon is involved.
 */

import { createServer } from 'node:http'
import { mkdtemp, mkdir, rm, symlink, writeFile } from 'node:fs/promises'
import type { AddressInfo } from 'node:net'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { CallId } from '@deepseek-ai/dsh-llm'
import type { ToolExecutionToken, ToolRunContext } from '@deepseek-ai/dsh-tools'
import { afterEach, describe, expect, it } from 'vitest'
import type { WebBridgeToolResult } from '../src/tools.ts'
import { webbridgeTools, WEBBRIDGE_TOOL_NAMES } from '../src/tools.ts'

/** One fake daemon server; records the last request body. */
let server: ReturnType<typeof createServer>
let baseUrl = ''
let lastBody: { action: string; args: Record<string, unknown>; session: string } | null = null
let respondWith: { ok: boolean; data?: Record<string, unknown>; error?: { code: string; message: string } } = { ok: true, data: {} }
const temporaryRoots: string[] = []

async function startFakeDaemon(): Promise<void> {
  server = createServer((req, res) => {
    const chunks: Buffer[] = []
    req.on('data', (c: Buffer) => chunks.push(c))
    req.on('end', () => {
      lastBody = JSON.parse(Buffer.concat(chunks).toString('utf8'))
      res.writeHead(200, { 'content-type': 'application/json' })
      res.end(JSON.stringify(respondWith))
    })
  })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`
}

afterEach(async () => {
  lastBody = null
  respondWith = { ok: true, data: {} }
  if (server !== undefined) {
    await new Promise<void>(resolve => server.close(() => { resolve() }))
    server = undefined as unknown as ReturnType<typeof createServer>
  }
  await Promise.all(temporaryRoots.splice(0).map(root => rm(root, { recursive: true, force: true })))
})

let callSeq = 0

/** A minimal typed execution context for direct tool-body calls. */
function execStub(
  name: string,
  args: Record<string, unknown> = {},
  signal = new AbortController().signal,
  workspace?: string,
): ToolRunContext {
  callSeq += 1
  const callId = CallId(`c${callSeq}`)
  return {
    callId,
    rootCallId: callId,
    name,
    arguments: args,
    signal,
    token: Symbol() as ToolExecutionToken,
    ...(workspace === undefined ? {} : {
      agent: { session: { header: { cwd: workspace } } } as never,
    }),
    deferContext: () => {},
    concludeTurn: () => {},
  }
}

/** All thirteen tools with the fake daemon wired in. */
function tools() {
  return webbridgeTools({ baseUrl })
}

describe('webbridge tools', () => {
  it('registers the canonical thirteen tools in a stable order', () => {
    const registered = Object.values(tools()).map(tool => tool.name)
    expect(registered).toEqual([...WEBBRIDGE_TOOL_NAMES])
  })

  it('every tool declares parameters, an output schema, and an execute body', () => {
    for (const tool of Object.values(tools())) {
      expect(tool.parameters).toBeDefined()
      expect(tool.output.schema).toBeDefined()
      expect(typeof tool.execute).toBe('function')
    }
  })

  it('every tool wires the cooperative timeout budget and schedules exclusively', () => {
    const defaulted = webbridgeTools({ baseUrl })
    for (const tool of Object.values(defaulted)) {
      expect(tool.timeoutMs).toBe(30_000)
      expect(tool.isConcurrencySafe?.({})).toBe(false)
    }
    const custom = webbridgeTools({ baseUrl, timeoutMs: 7_500 })
    for (const tool of Object.values(custom)) {
      expect(tool.timeoutMs).toBe(7_500)
    }
  })

  it('every tool requires the session parameter', async () => {
    const names = WEBBRIDGE_TOOL_NAMES
    const all = Object.values(tools())
    // navigate/find_tab/click/fill/evaluate/network need more than session;
    // probe with session missing for the no-arg tools and with only session
    // for the rest.
    for (let index = 0; index < all.length; index++) {
      const tool = all[index]!
      const args = names[index]!.startsWith('webbridge_network')
        ? { cmd: 'list' }
        : names[index] === 'webbridge_navigate' || names[index] === 'webbridge_find_tab'
          ? { url: 'https://a.dev' }
          : names[index] === 'webbridge_click'
            ? { selector: '@e1' }
            : names[index] === 'webbridge_fill'
              ? { selector: '@e1', value: 'x' }
              : names[index] === 'webbridge_evaluate'
                ? { code: '1' }
                : names[index] === 'webbridge_upload'
                  ? { selector: '@e1', files: ['/tmp/a.txt'] }
                  : names[index] === 'webbridge_screenshot' || names[index] === 'webbridge_save_as_pdf'
                    ? {}
                    : {}
      await expect(tool.execute(args, execStub(tool.name, args))).rejects.toMatchObject({
        name: 'ToolArgsError',
      })
    }
  })

  it('maps all thirteen tools to the exact daemon action, args, and session', async () => {
    await startFakeDaemon()
    const root = await mkdtemp(join(tmpdir(), 'dsh-better-browser-tools-'))
    temporaryRoots.push(root)
    const uploadPath = join(root, 'upload.txt')
    await writeFile(uploadPath, 'fixture')
    const cases = [
      ['navigate', { url: 'https://a.dev', newTab: true, group_title: 'A', session: 's1' }, 'navigate', { url: 'https://a.dev', newTab: true, group_title: 'A' }],
      ['findTab', { url: 'https://a.dev', active: true, session: 's2' }, 'find_tab', { url: 'https://a.dev', active: true }],
      ['snapshot', { session: 's3' }, 'snapshot', {}],
      ['click', { selector: '@e1', session: 's4' }, 'click', { selector: '@e1' }],
      ['fill', { selector: '@e2', value: 'hello', session: 's5' }, 'fill', { selector: '@e2', value: 'hello' }],
      ['evaluate', { code: 'document.title', session: 's6' }, 'evaluate', { code: 'document.title' }],
      ['screenshot', { format: 'jpeg', quality: 75, selector: '@e3', session: 's7' }, 'screenshot', { format: 'jpeg', quality: 75, selector: '@e3' }],
      ['listTabs', { session: 's8' }, 'list_tabs', {}],
      ['network', { cmd: 'detail', filter: 'api', requestId: 'r1', session: 's9' }, 'network', { cmd: 'detail', filter: 'api', requestId: 'r1' }],
      ['upload', { selector: 'input[type=file]', files: [uploadPath], session: 's10' }, 'upload', { selector: 'input[type=file]', files: [uploadPath] }],
      ['saveAsPdf', { paper_format: 'a4', landscape: true, scale: 0.8, print_background: false, file_name: 'report', session: 's11' }, 'save_as_pdf', { paper_format: 'a4', landscape: true, scale: 0.8, print_background: false, file_name: 'report' }],
      ['closeTab', { session: 's12' }, 'close_tab', {}],
      ['closeSession', { session: 's13' }, 'close_session', {}],
    ] as const
    for (const [key, args, action, expectedArgs] of cases) {
      const tool = tools()[key]
      await tool.execute(args, execStub(
        tool.name,
        args,
        new AbortController().signal,
        key === 'upload' ? root : undefined,
      ))
      expect(lastBody).toEqual({ action, args: expectedArgs, session: args.session })
    }
  })

  it('keeps different task sessions distinct and rejects a blank session', async () => {
    await startFakeDaemon()
    await tools().snapshot.execute({ session: 'task-a' }, execStub('webbridge_snapshot'))
    expect(lastBody?.session).toBe('task-a')
    await tools().snapshot.execute({ session: 'task-b' }, execStub('webbridge_snapshot'))
    expect(lastBody?.session).toBe('task-b')
    await expect(tools().snapshot.execute({ session: '   ' }, execStub('webbridge_snapshot'))).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'invalid_argument',
    })
  })

  it('forwards ToolRunContext cancellation to the in-flight daemon request', async () => {
    server = createServer(() => { /* never respond */ })
    await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
    baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`
    const caller = new AbortController()
    const started = Date.now()
    const pending = tools().snapshot.execute(
      { session: 'cancelled-task' },
      execStub('webbridge_snapshot', {}, caller.signal),
    )
    setTimeout(() => caller.abort(new Error('turn cancelled')), 20)
    await expect(pending).rejects.toMatchObject({ name: 'WebBridgeError', code: 'request_aborted' })
    expect(Date.now() - started).toBeLessThan(500)
  })

  it('rejects browser-local and script URL schemes before contacting the daemon', async () => {
    await startFakeDaemon()
    for (const url of ['file:///etc/passwd', 'javascript:alert(1)']) {
      await expect(tools().navigate.execute({ url, session: 's' }, execStub('webbridge_navigate'))).rejects.toMatchObject({
        name: 'WebBridgeError',
        code: 'invalid_argument',
      })
    }
    expect(lastBody).toBeNull()
  })

  it('navigate forwards url/newTab/group_title and session', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, url: 'https://a.dev', tabId: 3 } }
    const value = (await tools().navigate.execute(
      { url: 'https://a.dev', newTab: true, group_title: '研究', session: 'research' },
      execStub('webbridge_navigate'),
    )) as WebBridgeToolResult
    expect(value.ok).toBe(true)
    expect(value.summary).toContain('tabId=3')
    expect(lastBody?.args).toEqual({ url: 'https://a.dev', newTab: true, group_title: '研究' })
    expect(lastBody?.session).toBe('research')
  })

  it('navigate omits optional args when absent', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, url: 'https://a.dev' } }
    await tools().navigate.execute({ url: 'https://a.dev', session: 's' }, execStub('webbridge_navigate'))
    expect(lastBody?.args).toEqual({ url: 'https://a.dev' })
  })

  it('find_tab forwards url and active', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, tabId: 9 } }
    const value = (await tools().findTab.execute(
      { url: 'https://b.dev/path', active: true, session: 's' },
      execStub('webbridge_find_tab'),
    )) as WebBridgeToolResult
    expect(value.ok).toBe(true)
    expect(lastBody?.args).toEqual({ url: 'https://b.dev/path', active: true })
  })

  it('snapshot folds the accessibility tree into detail', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { url: 'https://a.dev', title: 'A', tree: [{ role: 'heading', name: 'Hi' }] } }
    const value = (await tools().snapshot.execute({ session: 's' }, execStub('webbridge_snapshot'))) as WebBridgeToolResult
    expect(value.detail).toMatchObject({ title: 'A' })
    expect(value.summary).toContain('url=https://a.dev')
  })

  it('click forwards the selector', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, tag: 'button', text: 'Go' } }
    const value = (await tools().click.execute({ selector: '@e12', session: 's' }, execStub('webbridge_click'))) as WebBridgeToolResult
    expect(value.ok).toBe(true)
    expect(lastBody?.args).toEqual({ selector: '@e12' })
  })

  it('fill forwards selector + value', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, mode: 'contenteditable' } }
    const value = (await tools().fill.execute({ selector: '@e5', value: '你好', session: 's' }, execStub('webbridge_fill'))) as WebBridgeToolResult
    expect(value.ok).toBe(true)
    expect(lastBody?.args).toEqual({ selector: '@e5', value: '你好' })
  })

  it('evaluate forwards code', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { type: 'string', value: 'hi' } }
    const value = (await tools().evaluate.execute({ code: 'document.title', session: 's' }, execStub('webbridge_evaluate'))) as WebBridgeToolResult
    expect(value.detail).toEqual({ type: 'string', value: 'hi' })
    expect(lastBody?.args).toEqual({ code: 'document.title' })
  })

  it('screenshot forwards format/quality/selector and omits absent ones', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, path: '/tmp/kimi-webbridge-screenshots/shot.png', format: 'png' } }
    const value = (await tools().screenshot.execute(
      { format: 'jpeg', quality: 60, selector: '@e3', session: 's' },
      execStub('webbridge_screenshot'),
    )) as WebBridgeToolResult
    expect(value.ok).toBe(true)
    expect(lastBody?.args).toEqual({ format: 'jpeg', quality: 60, selector: '@e3' })
    respondWith = { ok: true, data: { success: true, path: '/tmp/kimi-webbridge-screenshots/shot.png' } }
    await tools().screenshot.execute({ session: 's' }, execStub('webbridge_screenshot'))
    expect(lastBody?.args).toEqual({})
  })

  it('rejects unsupported screenshot formats and out-of-range JPEG quality', async () => {
    await startFakeDaemon()
    await expect(tools().screenshot.execute(
      { format: 'gif', session: 's' },
      execStub('webbridge_screenshot'),
    )).rejects.toMatchObject({ name: 'ToolArgsError' })
    for (const quality of [-1, 101]) {
      await expect(tools().screenshot.execute(
        { format: 'jpeg', quality, session: 's' },
        execStub('webbridge_screenshot'),
      )).rejects.toMatchObject({ name: 'WebBridgeError', code: 'invalid_argument' })
    }
    expect(lastBody).toBeNull()
  })

  it('list_tabs forwards only the session', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { tabs: [{ tabId: 1, url: 'https://a.dev' }] } }
    const value = (await tools().listTabs.execute({ session: 's' }, execStub('webbridge_list_tabs'))) as WebBridgeToolResult
    expect(value.detail).toMatchObject({ tabs: [{ tabId: 1, url: 'https://a.dev' }] })
    expect(lastBody?.args).toEqual({})
    expect(lastBody?.session).toBe('s')
  })

  it('network forwards cmd/filter/requestId and validates the cmd enum', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { capturing: true } }
    const value = (await tools().network.execute(
      { cmd: 'start', filter: 'api.', session: 's' },
      execStub('webbridge_network'),
    )) as WebBridgeToolResult
    expect(value.ok).toBe(true)
    expect(lastBody?.args).toEqual({ cmd: 'start', filter: 'api.' })
    await expect(
      tools().network.execute({ cmd: 'rewind', session: 's' }, execStub('webbridge_network')),
    ).rejects.toMatchObject({ name: 'ToolArgsError' })
  })

  it('close_tab and close_session forward only the session', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, closed: 1 } }
    await tools().closeTab.execute({ session: 's' }, execStub('webbridge_close_tab'))
    expect(lastBody).toEqual({ action: 'close_tab', args: {}, session: 's' })
    await tools().closeSession.execute({ session: 's' }, execStub('webbridge_close_session'))
    expect(lastBody).toEqual({ action: 'close_session', args: {}, session: 's' })
  })

  it('upload forwards the selector and file paths', async () => {
    await startFakeDaemon()
    const root = await mkdtemp(join(tmpdir(), 'dsh-better-browser-upload-'))
    temporaryRoots.push(root)
    const first = join(root, 'a.pdf')
    const second = join(root, 'b.png')
    await Promise.all([writeFile(first, 'a'), writeFile(second, 'b')])
    respondWith = { ok: true, data: { success: true, fileCount: 2 } }
    const value = (await tools().upload.execute(
      { selector: 'input[type=file]', files: [first, second], session: 's' },
      execStub('webbridge_upload', {}, new AbortController().signal, root),
    )) as WebBridgeToolResult
    expect(value.ok).toBe(true)
    expect(lastBody?.args).toEqual({ selector: 'input[type=file]', files: [first, second] })
  })

  it('upload rejects a missing files array', async () => {
    await expect(
      tools().upload.execute({ selector: 'input[type=file]', session: 's' }, execStub('webbridge_upload')),
    ).rejects.toMatchObject({ name: 'ToolArgsError' })
  })

  it('upload rejects empty, relative, missing, and directory paths before contacting the daemon', async () => {
    await startFakeDaemon()
    const root = await mkdtemp(join(tmpdir(), 'dsh-better-browser-upload-invalid-'))
    const outsideRoot = await mkdtemp(join(tmpdir(), 'dsh-better-browser-upload-outside-'))
    temporaryRoots.push(root)
    temporaryRoots.push(outsideRoot)
    const directory = join(root, 'directory')
    const inside = join(root, 'inside.txt')
    const outside = join(outsideRoot, 'outside.txt')
    const escapedLink = join(root, 'escaped-link.txt')
    await mkdir(directory)
    await writeFile(inside, 'inside')
    await writeFile(outside, 'outside')
    await symlink(outside, escapedLink)
    const cases = [[], ['relative.txt'], [join(root, 'missing.txt')], [directory], [outside], [escapedLink]]
    for (const files of cases) {
      await expect(tools().upload.execute(
        { selector: 'input[type=file]', files, session: 's' },
        execStub('webbridge_upload', {}, new AbortController().signal, root),
      )).rejects.toMatchObject({ name: 'WebBridgeError', code: 'invalid_argument' })
    }
    await expect(tools().upload.execute(
      { selector: 'input[type=file]', files: [inside], session: 's' },
      execStub('webbridge_upload'),
    )).rejects.toMatchObject({ name: 'WebBridgeError', code: 'invalid_argument' })
    expect(lastBody).toBeNull()
  })

  it('save_as_pdf forwards optional print options and omits absent ones', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, path: '/tmp/kimi-webbridge-pdfs/report.pdf', sizeBytes: 1234 } }
    const value = (await tools().saveAsPdf.execute(
      { paper_format: 'a4', landscape: true, file_name: 'report', session: 's' },
      execStub('webbridge_save_as_pdf'),
    )) as WebBridgeToolResult
    expect(value.ok).toBe(true)
    expect(lastBody?.args).toEqual({ paper_format: 'a4', landscape: true, file_name: 'report' })
    respondWith = { ok: true, data: { success: true, path: '/tmp/kimi-webbridge-pdfs/page.pdf' } }
    await tools().saveAsPdf.execute({ session: 's' }, execStub('webbridge_save_as_pdf'))
    expect(lastBody?.args).toEqual({})
  })

  it('rejects unsafe PDF file names before contacting the daemon', async () => {
    await startFakeDaemon()
    for (const file_name of ['../report', 'nested/report', 'nested\\report', '..', 'report\nname']) {
      await expect(tools().saveAsPdf.execute(
        { file_name, session: 's' },
        execStub('webbridge_save_as_pdf'),
      )).rejects.toMatchObject({ name: 'WebBridgeError', code: 'invalid_argument' })
    }
    await expect(tools().saveAsPdf.execute(
      { scale: 0, session: 's' },
      execStub('webbridge_save_as_pdf'),
    )).rejects.toMatchObject({ name: 'WebBridgeError', code: 'invalid_argument' })
    expect(lastBody).toBeNull()
  })

  it('rejects screenshot and PDF output paths outside dedicated daemon temp roots', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, path: '../shot.png' } }
    await expect(tools().screenshot.execute({ session: 's' }, execStub('webbridge_screenshot'))).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'bad_response',
    })
    respondWith = { ok: true, data: { success: true, path: 'report.pdf' } }
    await expect(tools().saveAsPdf.execute({ session: 's' }, execStub('webbridge_save_as_pdf'))).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'bad_response',
    })
    respondWith = { ok: true, data: { success: true, path: '/etc/passwd' } }
    await expect(tools().screenshot.execute({ session: 's' }, execStub('webbridge_screenshot'))).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'bad_response',
    })
  })

  it('daemon rejections surface as WebBridgeError with the daemon code', async () => {
    await startFakeDaemon()
    respondWith = { ok: false, error: { code: 'tool_error', message: 'no extension connected' } }
    await expect(tools().navigate.execute({ url: 'https://a.dev', session: 's' }, execStub('webbridge_navigate'))).rejects
      .toMatchObject({ name: 'WebBridgeError', code: 'tool_error' })
  })

  it('summaries are compact one-liners and long payloads truncate', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { url: 'https://a.dev', success: true } }
    const value = (await tools().snapshot.execute({ session: 's' }, execStub('webbridge_snapshot'))) as WebBridgeToolResult
    expect(value.summary).toBe('url=https://a.dev success=true')
    respondWith = { ok: true, data: { blob: 'x'.repeat(500) } }
    const long = (await tools().snapshot.execute({ session: 's' }, execStub('webbridge_snapshot'))) as WebBridgeToolResult
    expect(long.summary.length).toBeLessThanOrEqual(203)
    expect(long.summary.endsWith('…')).toBe(true)
  })

  it('presentCall yields a generic card and render exposes canonical detail to the model', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true } }
    const tool = tools().navigate
    const view = tool.presentCall?.({ url: 'https://a.dev', session: 's' })
    expect(view).toMatchObject({ card: 'generic', title: 'Open in browser' })
    const value = (await tool.execute({ url: 'https://a.dev', session: 's' }, execStub('webbridge_navigate'))) as WebBridgeToolResult
    // The render value parameter is inferred from the output schema; the
    // structurally identical domain type satisfies it at runtime.
    const blocks = tool.output.render({ url: 'https://a.dev', session: 's' }, value as never)
    expect(blocks).toHaveLength(1)
    expect(blocks[0]).toMatchObject({ type: 'text' })
    expect((blocks[0] as { text: string }).text).toContain(value.summary)
    expect((blocks[0] as { text: string }).text).toContain('"success": true')
  })

  it('keeps critical browser evidence model-visible and bounds oversized payloads', () => {
    const cases = [
      [tools().snapshot, { tree: [{ ref: '@e7', role: 'button', name: 'Continue' }] }, '@e7'],
      [tools().listTabs, { tabs: [{ tabId: 9, url: 'https://a.dev' }] }, 'https://a.dev'],
      [tools().network, { requestId: 'req-7', responseBody: '{"ok":true}' }, 'req-7'],
      [tools().evaluate, { type: 'string', value: 'evaluated-value' }, 'evaluated-value'],
      [tools().screenshot, { path: '/tmp/kimi-webbridge-screenshots/shot.png' }, 'shot.png'],
      [tools().saveAsPdf, { path: '/tmp/kimi-webbridge-pdfs/report.pdf' }, 'report.pdf'],
    ] as const
    for (const [tool, detail, expected] of cases) {
      const blocks = tool.output.render({}, { ok: true, summary: 'done', detail } as never)
      expect((blocks[0] as { text: string }).text).toContain(expected)
    }

    const oversized = tools().snapshot.output.render({}, {
      ok: true,
      summary: 'large snapshot',
      detail: { tree: 'x'.repeat(100_000) },
    } as never)
    const text = (oversized[0] as { text: string }).text
    expect(text.length).toBeLessThan(33_000)
    expect(text).toContain('truncated')
  })

  it('keeps action-critical evidence ahead of oversized auxiliary fields', () => {
    const noise = 'x'.repeat(40_000)
    const cases = [
      [tools().snapshot, { noise, tree: [{ ref: '@e-critical' }] }, '@e-critical'],
      [tools().listTabs, { noise, tabs: [{ url: 'https://critical.dev' }] }, 'https://critical.dev'],
      [tools().network, { noise, requestId: 'critical-request' }, 'critical-request'],
      [tools().evaluate, { noise, value: 'critical-evaluation' }, 'critical-evaluation'],
      [tools().screenshot, { noise, path: '/tmp/kimi-webbridge-screenshots/critical.png' }, 'critical.png'],
      [tools().saveAsPdf, { noise, path: '/tmp/kimi-webbridge-pdfs/critical.pdf' }, 'critical.pdf'],
    ] as const
    for (const [tool, detail, expected] of cases) {
      const blocks = tool.output.render({}, { ok: true, summary: 'done', detail } as never)
      const text = (blocks[0] as { text: string }).text
      expect(text.length).toBeLessThanOrEqual(32_000)
      expect(text).toContain(expected)
      expect(text).toContain('truncated')
    }
  })

  it('uses the configured baseUrl for every call', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, url: 'https://c.dev' } }
    const custom = webbridgeTools({ baseUrl })
    await custom.navigate.execute({ url: 'https://c.dev', session: 's' }, execStub('webbridge_navigate'))
    expect(lastBody?.session).toBe('s')
  })
})
