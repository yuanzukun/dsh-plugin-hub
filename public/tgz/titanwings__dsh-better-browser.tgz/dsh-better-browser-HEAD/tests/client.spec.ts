/**
 * WebBridge daemon client tests. The daemon is mocked with a local HTTP
 * server so the suite runs anywhere; a separate integration test (skipped
 * unless KIMI_WEBBRIDGE_IT=1) exercises the real local daemon.
 */

import { createServer } from 'node:http'
import type { AddressInfo } from 'node:net'
import { afterEach, describe, expect, it } from 'vitest'
import {
  validateClientOptions,
  webbridgeCommand,
  WEBBRIDGE_DEFAULT_TIMEOUT_MS,
  WEBBRIDGE_DEFAULT_URL,
} from '../src/client.ts'

/** One fake daemon server; records the last request body. */
let server: ReturnType<typeof createServer>
let baseUrl = ''
let lastBody: { action: string; args: Record<string, unknown>; session: string } | null = null
let respondWith: { ok: boolean; data?: Record<string, unknown>; error?: { code: string; message: string } } = { ok: true, data: {} }

async function startFakeDaemon(): Promise<void> {
  server = createServer((req, res) => {
    const chunks: Buffer[] = []
    req.on('data', (c: Buffer) => chunks.push(c))
    req.on('end', () => {
      lastBody = JSON.parse(Buffer.concat(chunks).toString('utf8'))
      res.writeHead(200, { 'content-type': 'application/json' })
      res.end(JSON.stringify(respondWith))
    })
  })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`
}

afterEach(async () => {
  lastBody = null
  respondWith = { ok: true, data: {} }
  if (server !== undefined) {
    await new Promise<void>(resolve => server.close(() => { resolve() }))
    server = undefined as unknown as ReturnType<typeof createServer>
  }
})

describe('webbridgeCommand', () => {
  it('posts action/args/session and returns the data payload', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: { success: true, url: 'https://x.dev', tabId: 7 } }
    const data = await webbridgeCommand('navigate', { url: 'https://x.dev' }, 'task-a', { baseUrl })
    expect(data).toEqual({ success: true, url: 'https://x.dev', tabId: 7 })
    expect(lastBody).toEqual({ action: 'navigate', args: { url: 'https://x.dev' }, session: 'task-a' })
  })

  it('defaults to the standard daemon URL and timeout', () => {
    expect(validateClientOptions({})).toEqual({
      baseUrl: WEBBRIDGE_DEFAULT_URL,
      timeoutMs: WEBBRIDGE_DEFAULT_TIMEOUT_MS,
    })
  })

  it('throws WebBridgeError with the daemon code on rejection', async () => {
    await startFakeDaemon()
    respondWith = { ok: false, error: { code: 'tool_error', message: 'no extension connected' } }
    await expect(webbridgeCommand('snapshot', {}, 't', { baseUrl })).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'tool_error',
      action: 'snapshot',
    })
  })

  it('preserves a structured daemon rejection carried by a non-2xx response', async () => {
    await startFakeDaemon()
    server.removeAllListeners('request')
    server.on('request', (_req, res) => {
      res.writeHead(502, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ ok: false, error: { code: 'tool_error', message: 'no extension connected' } }))
    })
    await expect(webbridgeCommand('navigate', { url: 'https://example.com' }, 't', { baseUrl })).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'tool_error',
      action: 'navigate',
      message: 'tool_error: no extension connected',
      detail: 'no extension connected',
    })
  })

  it('throws WebBridgeError when the daemon is unreachable', async () => {
    await expect(webbridgeCommand('snapshot', {}, 't', { baseUrl: 'http://127.0.0.1:1' })).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'daemon_unreachable',
    })
  })

  it('throws WebBridgeError on non-200 responses', async () => {
    await startFakeDaemon()
    server.removeAllListeners('request')
    server.on('request', (_req, res) => { res.writeHead(500); res.end('boom') })
    await expect(webbridgeCommand('click', { selector: '@e1' }, 't', { baseUrl })).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'http_error',
    })
  })

  it('uses http_error for a JSON non-2xx response without a daemon error envelope', async () => {
    await startFakeDaemon()
    server.removeAllListeners('request')
    server.on('request', (_req, res) => {
      res.writeHead(502, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ message: 'upstream failed' }))
    })
    await expect(webbridgeCommand('snapshot', {}, 't', { baseUrl })).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'http_error',
    })
  })

  it('throws WebBridgeError on a non-JSON body', async () => {
    await startFakeDaemon()
    server.removeAllListeners('request')
    server.on('request', (_req, res) => { res.writeHead(200, { 'content-type': 'text/plain' }); res.end('not json') })
    await expect(webbridgeCommand('snapshot', {}, 't', { baseUrl })).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'bad_response',
    })
  })

  it('throws WebBridgeError when the data payload is missing', async () => {
    await startFakeDaemon()
    respondWith = { ok: true } as never
    await expect(webbridgeCommand('snapshot', {}, 't', { baseUrl })).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'bad_response',
    })
  })

  it('rejects a malformed success flag as a protocol error', async () => {
    await startFakeDaemon()
    respondWith = { ok: 'yes', data: {} } as never
    await expect(webbridgeCommand('snapshot', {}, 't', { baseUrl })).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'daemon_error',
    })
  })

  it('rejects an array success payload instead of exposing it as a record', async () => {
    await startFakeDaemon()
    respondWith = { ok: true, data: [] } as never
    await expect(webbridgeCommand('snapshot', {}, 't', { baseUrl })).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'bad_response',
    })
  })

  it('times out with a typed error when the daemon never answers', async () => {
    server = createServer(() => { /* never respond */ })
    await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
    const slowUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`
    await expect(webbridgeCommand('snapshot', {}, 't', { baseUrl: slowUrl, timeoutMs: 50 })).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'daemon_timeout',
    })
  })

  it('applies the timeout while reading a response body after headers arrive', async () => {
    server = createServer((_req, res) => {
      res.writeHead(200, { 'content-type': 'application/json' })
      res.write('{"ok":true')
      // Deliberately never finish the JSON body.
    })
    await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
    const slowUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`
    await expect(webbridgeCommand('snapshot', {}, 't', { baseUrl: slowUrl, timeoutMs: 50 })).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'daemon_timeout',
    })
  })

  it('aborts immediately with the caller signal instead of waiting for the daemon timeout', async () => {
    server = createServer(() => { /* never respond */ })
    await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
    const slowUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`
    const caller = new AbortController()
    const started = Date.now()
    const pending = webbridgeCommand('snapshot', {}, 't', { baseUrl: slowUrl, timeoutMs: 1_000 }, caller.signal)
    setTimeout(() => caller.abort(new Error('turn cancelled')), 20)
    await expect(pending).rejects.toMatchObject({
      name: 'WebBridgeError',
      code: 'request_aborted',
      action: 'snapshot',
    })
    expect(Date.now() - started).toBeLessThan(500)
  })

  it('rejects a non-http base URL loudly', () => {
    expect(() => validateClientOptions({ baseUrl: 'ftp://localhost:10086' })).toThrow(/baseUrl/)
    expect(() => validateClientOptions({ baseUrl: 'http://' })).toThrow(/baseUrl/)
  })

  it('rejects a non-positive or non-integer timeout loudly', () => {
    expect(() => validateClientOptions({ timeoutMs: 0 })).toThrow(/timeoutMs/)
    expect(() => validateClientOptions({ timeoutMs: -5 })).toThrow(/timeoutMs/)
    expect(() => validateClientOptions({ timeoutMs: 1.5 })).toThrow(/timeoutMs/)
  })
})

describe.skipIf(process.env.KIMI_WEBBRIDGE_IT !== '1')('real daemon integration', () => {
  it('diagnoses an extension-missing daemon or completes a navigate round-trip', async () => {
    const status = await fetch(`${WEBBRIDGE_DEFAULT_URL}/status`).then(response => response.json()) as { extension_connected?: boolean }
    const call = webbridgeCommand('navigate', { url: 'https://example.com', newTab: true }, `it-${Date.now()}`)
    if (status.extension_connected === false) {
      await expect(call).rejects.toMatchObject({
        name: 'WebBridgeError',
        code: 'tool_error',
        message: 'tool_error: no extension connected',
        detail: 'no extension connected',
      })
      return
    }
    await expect(call).resolves.toHaveProperty('success')
  }, 60_000)
})
