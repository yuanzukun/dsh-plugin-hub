/**
 * Real-composition smoke: the BUILT plugin bundle boots through the actual
 * Cordis Loader from a test-only cordis.yml, alongside the real built
 * dsh-tools / dsh-system-prompt / timer services, and executes a browser
 * action against a mocked daemon through the real registry pipeline.
 *
 * This is the "real entry path" guard from the DSH testing policy: the
 * shipped artifact (`lib/index.js`) must mount and serve tools, not just the
 * source. It skips (with a message) when `pnpm build` has not produced
 * `lib/index.js` yet.
 */

import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { createServer } from 'node:http'
import type { AddressInfo } from 'node:net'
import { tmpdir } from 'node:os'
import { existsSync, readlinkSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { Context } from '@deepseek-ai/cordis'
import Include from '@deepseek-ai/cordis-plugin-include'
import Loader from '@deepseek-ai/cordis-plugin-loader'
import { afterEach, describe, expect, it } from 'vitest'
import { WEBBRIDGE_TOOL_NAMES } from '../src/tools.ts'

/** Absolute path of this repo root (works under vitest's transformed ESM). */
const REPO_ROOT = new URL('..', import.meta.url).pathname
const BUILT_PLUGIN = join(REPO_ROOT, 'lib/index.js')

/** DSH source checkout resolved by scripts/dev-env.mjs (`.dsh/source/current`). */
const DSH_LINK = join(REPO_ROOT, '.dsh/source/current')
const DSH_CHECKOUT = process.env.DSH_CHECKOUT ?? (existsSync(DSH_LINK) ? readlinkSync(DSH_LINK) : '')

let root: string | undefined
let ctx: Context | undefined

afterEach(async () => {
  await ctx?.fiber.dispose()
  ctx = undefined
  if (root !== undefined) {
    await rm(root, { recursive: true, force: true })
    root = undefined
  }
})

describe.skipIf(!existsSync(BUILT_PLUGIN) || !existsSync(DSH_CHECKOUT))(
  'dsh-better-browser built bundle through the real Loader',
  () => {
    it('boots from cordis.yml, registers every tool, and serves a browser action', async () => {
      // Mock daemon the composed plugin talks to.
      let lastBody: { action: string; args: Record<string, unknown>; session: string } | null = null
      const server = createServer((req, res) => {
        const chunks: Buffer[] = []
        req.on('data', (c: Buffer) => chunks.push(c))
        req.on('end', () => {
          lastBody = JSON.parse(Buffer.concat(chunks).toString('utf8'))
          res.writeHead(200, { 'content-type': 'application/json' })
          res.end(JSON.stringify({ ok: true, data: { success: true, url: lastBody?.args.url ?? null } }))
        })
      })
      await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
      const daemonUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`

      try {
        root = await mkdtemp(join(tmpdir(), 'dsh-better-browser-loader-'))
        await writeFile(join(root, 'cordis.yml'), [
          '- id: timer',
          "  name: '@deepseek-ai/cordis-plugin-timer'",
          '- id: system-prompt',
          "  name: '@deepseek-ai/dsh-system-prompt'",
          '- id: tools',
          "  name: '@deepseek-ai/dsh-tools'",
          '- id: webbridge',
          "  name: '@dsh-external/dsh-better-browser'",
          '  config:',
          `    baseUrl: ${daemonUrl}`,
          '',
        ].join('\n'))

        const built = new Map<string, string>([
          ['@dsh-external/dsh-better-browser', BUILT_PLUGIN],
          ['@deepseek-ai/dsh-tools', join(DSH_CHECKOUT, 'packages/core/tools/lib/index.js')],
          ['@deepseek-ai/dsh-system-prompt', join(DSH_CHECKOUT, 'packages/core/system-prompt/lib/index.js')],
          ['@deepseek-ai/cordis-plugin-timer', join(DSH_CHECKOUT, 'vendor/timer/lib/index.js')],
        ])

        const harness = new Context()
        ctx = harness
        harness.baseUrl = pathToFileURL(root).href + '/'
        await harness.plugin(Loader)
        harness.loader.builtins.include = Include
        harness.loader.internal = {
          version: 'v2',
          async import(specifier: string) {
            const entry = built.get(specifier)
            if (entry === undefined) throw new Error(`unexpected Loader import: ${specifier}`)
            return import(pathToFileURL(entry).href)
          },
        } as unknown as NonNullable<typeof harness.loader.internal>
        await harness.loader.create({
          name: 'cordis:include',
          config: { path: pathToFileURL(join(root, 'cordis.yml')).href },
        })
        await harness.loader.await()

        // Every tool of the BUILT bundle is registered on the real registry.
        const registered = harness.tools.schemas().map(schema => schema.name).filter(n => n.startsWith('webbridge_'))
        expect(registered.sort()).toEqual([...WEBBRIDGE_TOOL_NAMES].sort())

        // The composed plugin executed a browser action through the real
        // registry pipeline against the configured daemon URL.
        await harness.tools.execute({
          callId: 'loader-smoke' as never,
          name: 'webbridge_navigate',
          arguments: { url: 'https://smoke.dev', session: 'loader-smoke' },
          signal: new AbortController().signal,
        })
        expect(lastBody).toEqual({
          action: 'navigate',
          args: { url: 'https://smoke.dev' },
          session: 'loader-smoke',
        })
      } finally {
        await new Promise<void>(resolve => server.close(() => { resolve() }))
      }
    })
  },
)
