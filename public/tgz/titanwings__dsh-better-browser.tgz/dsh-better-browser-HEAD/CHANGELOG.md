# Changelog

All notable changes to `@dsh-external/dsh-better-browser` are documented here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.3.6] - 2026-08-14

### Fixed

- Prioritized action-critical evidence before bounded model-output truncation,
  so accessibility trees, tab/network/evaluation results, and screenshot/PDF
  paths remain visible even when an auxiliary daemon field is unusually large.
- Added real DSH registry assertions for all six evidence-bearing action
  families while retaining the 32,000-character output ceiling.

## [0.3.5] - 2026-08-14

### Fixed

- Included the stable WebBridge error code in model-visible failure text while
  retaining the same code as structured `HarnessError` metadata.

## [0.3.4] - 2026-08-14

### Fixed

- Marked the Harness-provided Cordis, Schemastery, and DSH runtime packages as
  optional peers so Git profile installation stays warning-free while keeping
  the runtime compatibility contract explicit.

## [0.3.3] - 2026-08-13

### Fixed

- Forwarded DSH turn cancellation through all thirteen tools and the daemon
  response body read, while preserving structured WebBridge error codes such
  as `tool_error: no extension connected`.
- Restored the model-visible accessibility tree, tab/network evidence,
  evaluation values, and screenshot/PDF paths with an explicit 32,000-character
  output bound.
- Restricted navigation to HTTP(S), uploads to canonical files inside the
  calling Agent workspace, and daemon output paths to its dedicated temporary
  directories.

## [0.3.2] - 2026-08-13

### Fixed

- Migrated the Cordis and Schemastery runtime peers to the official
  `@deepseek-ai/*` package names used by the latest DeepSeek Harness profile.
  The bundle now mounts as an active Loader entry instead of failing module
  resolution during Host startup.
- Updated the real Loader composition test and build fallback probes to use
  the same scoped runtime contract as the installed plugin.

## [0.3.1] - 2026-08-13

### Changed

- Published the source repository under `titanwings/dsh-better-browser` while
  keeping the `@dsh-external/dsh-better-browser` package and Cordis bundle
  identity stable.
- Marked compiled runtime bundles as generated for accurate GitHub language
  statistics.

## [0.3.0] - 2026-08-13

### Changed

- Renamed the product, repository, package, and plugin identity from
  `dsh-kimi-browser` to `dsh-better-browser`.
- Kept the `webbridge` composition row, all `webbridge_*` tool names, daemon
  protocol, and configuration fields stable for existing profile overlays and
  callers.
- Corrected the composition documentation: Loader row ids are unique and a
  bundle `insert` does not override another `webbridge` row.
- Documented the one-time profile migration from
  `@dsh-external/dsh-kimi-browser` to `@dsh-external/dsh-better-browser`.

## [0.2.1] - 2026-08-11

### Changed

- Renamed the distribution to `@dsh-external/dsh-kimi-browser` (repository
  `dsh-external/dsh-kimi-browser`). The composition row keeps the `webbridge`
  id and the `webbridge_*` tool names — they are the Kimi WebBridge protocol
  contract and the drop-in override semantics for the official built-in row.

## [0.2.0] - 2026-08-11


### Added

- Two new model tools completing the daemon protocol surface: `webbridge_upload`
  (file input upload) and `webbridge_save_as_pdf` (page → PDF under
  `/tmp/kimi-webbridge-pdfs/`) — thirteen tools total.
- Cooperative timeout wiring: every tool now carries `ToolDefinition.timeoutMs`
  (configurable via plugin `timeoutMs`, default 30000) so
  `@deepseek-ai/dsh-timeout-policy` enforces the budget when present in the
  composition.
- Explicit exclusive scheduling on every tool (`isConcurrencySafe: false`):
  browser sessions are shared mutable state, so even reads never interleave
  with in-flight actions.

### Changed

- `pnpm check` order is now typecheck → build → test → lint, so the real
  Loader smoke always runs against a freshly built bundle.

## [0.1.0] - 2026-08-11


### Added

- Plugin `Config` (schemastery-validated): `baseUrl` and `timeoutMs`, both
  failing loud at mount time on invalid values.
- Typed daemon error taxonomy: `daemon_unreachable`, `daemon_timeout`,
  `http_error`, `bad_response`, plus the daemon's own `error.code` verbatim.
- `validateClientOptions()` shared by the client and the plugin entry.
- Tool suite: `network.cmd` restricted to the daemon's `start|stop|list|detail`
  enum; `WEBBRIDGE_TOOL_NAMES` as the canonical registration contract.
- Test matrix (37 tests): daemon client (timeout, non-JSON, missing payload,
  config validation), all eleven tools (arg forwarding, required-field
  validation, output folding, presentation), plugin mounting on a real Cordis
  context (registration, HMR-safe disposal, config wiring), and a **real
  entry-path Loader smoke** booting the built bundle from cordis.yml.
- Dev environment: `pnpm link:dsh`, `scripts/dev-env.mjs` (toolchain linking
  + generated path/alias maps), `vitest.config.ts`, `tsconfig.test.json`,
  `pnpm typecheck` / `pnpm test` / `pnpm check`.

### Changed

- `webbridgeCommand` now returns the daemon `data` payload directly and
  throws `WebBridgeError` on every failure path (the unreachable
  `{ok:false}` fold branch in the tool layer is gone).
- The daemon client accepts `WebBridgeClientOptions` (`baseUrl`, `timeoutMs`)
  instead of a bare `baseUrl`; the 30s budget is now configurable.
- Removed the unused `invariant` module and its package export.

### Fixed

- Build: `schemastery` is now a declared peer dependency so the bundle keeps
  it external (previously the type declaration file was inlined and the
  bundle crashed with `Schema is not defined`).
- Build: `scripts/build.mjs` also resolves the DSH checkout through
  `.dsh/source/current` (no `DSH_CHECKOUT` env needed after `link:dsh`).

## [0.0.1] - 2026-08-09

- Initial open-source release: eleven `webbridge_*` model tools bridging the
  Kimi WebBridge daemon into DeepSeek Harness.
