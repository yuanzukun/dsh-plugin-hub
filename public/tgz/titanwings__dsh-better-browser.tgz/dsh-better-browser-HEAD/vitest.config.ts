/**
 * Vitest configuration for @dsh-external/dsh-better-browser.
 *
 * The DSH official packages are not on the public npm registry; tests resolve
 * every `@deepseek-ai/*` import to a DSH source checkout through
 * `.dsh/alias.json` (generated from the checkout by `scripts/dev-env.mjs`,
 * which `pnpm test` runs first).
 */

import { readFileSync } from 'node:fs'
import { defineConfig } from 'vitest/config'

const aliases = JSON.parse(readFileSync(new URL('./.dsh/alias.json', import.meta.url), 'utf8'))

export default defineConfig({
  resolve: {
    alias: aliases,
  },
  test: {
    include: ['tests/**/*.spec.ts'],
    environment: 'node',
    // Mock-daemon HTTP servers and the abort/timeout paths need headroom.
    testTimeout: 20_000,
    hookTimeout: 20_000,
  },
})
