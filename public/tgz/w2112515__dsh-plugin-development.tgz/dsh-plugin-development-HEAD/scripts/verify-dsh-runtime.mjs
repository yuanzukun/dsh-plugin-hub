#!/usr/bin/env node

import assert from 'node:assert/strict'
import { cp, mkdir, mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import process from 'node:process'
import { fileURLToPath, pathToFileURL } from 'node:url'

const checkout = process.argv[2]
if (checkout === undefined) {
  console.error('Usage: node scripts/verify-dsh-runtime.mjs <deepseek-harness-checkout> [plugin-entry]')
  process.exit(2)
}

const cordisUrl = pathToFileURL(path.join(path.resolve(checkout), 'vendor', 'cordis', 'lib', 'index.js')).href
const skillUrl = pathToFileURL(path.join(path.resolve(checkout), 'packages', 'skill', 'skill', 'lib', 'index.js')).href
const skillFilesystemUrl = pathToFileURL(path.join(path.resolve(checkout), 'packages', 'skill', 'skill-filesystem', 'lib', 'index.js')).href
const pluginUrl = process.argv[3] === undefined
  ? new URL('../index.js', import.meta.url).href
  : pathToFileURL(path.resolve(process.argv[3])).href
const pluginRoot = path.dirname(fileURLToPath(pluginUrl))
const portableSkill = path.join(pluginRoot, 'skills', 'dsh-plugin-development')

const [{ Context }, { default: SkillRegistry }, skillFilesystem, plugin] = await Promise.all([
  import(cordisUrl),
  import(skillUrl),
  import(skillFilesystemUrl),
  import(pluginUrl),
])

const projectRoot = await mkdtemp(path.join(tmpdir(), 'dsh-plugin-development-'))
const installedSkill = path.join(projectRoot, '.agents', 'skills', 'dsh-plugin-development')
const localCtx = new Context()
try {
  await mkdir(path.join(projectRoot, '.git'))
  await mkdir(path.dirname(installedSkill), { recursive: true })
  await cp(portableSkill, installedSkill, { recursive: true })
  await localCtx.plugin(SkillRegistry)
  const localFiber = await localCtx.plugin(skillFilesystem, {
    dshHome: path.join(projectRoot, '.isolated-dsh-home'),
    agentsHome: path.join(projectRoot, '.isolated-agents-home'),
    watch: false,
  })

  const lookup = { cwd: projectRoot }
  const localSummary = (await localCtx.skills.list(lookup)).find(candidate => candidate.name === 'dsh-plugin-development')
  assert(localSummary, 'portable Skill was not discovered from project .agents/skills')
  assert.equal(localSummary.source, 'project-agents')
  const localDefinition = await localCtx.skills.get('dsh-plugin-development', lookup)
  assert(localDefinition, 'portable Skill could not be loaded from project .agents/skills')
  assert.match(localDefinition.content, /^# Develop and Audit DeepSeek Harness Plugins/m)
  assert.equal(localDefinition.resourceBase?.kind, 'directory')
  assert.equal(localDefinition.resourceBase?.path, installedSkill)
  await localFiber.dispose()
  assert.equal(await localCtx.skills.get('dsh-plugin-development', lookup), undefined, 'portable Skill remained after provider disposal')
} finally {
  await localCtx.fiber.dispose()
  await rm(projectRoot, { recursive: true, force: true })
}

const runtimeCtx = new Context()
await runtimeCtx.plugin(SkillRegistry)
const runtimeFiber = await runtimeCtx.plugin(plugin)

const summary = (await runtimeCtx.skills.list()).find(candidate => candidate.name === 'dsh-plugin-development')
assert(summary, 'installed plugin did not register dsh-plugin-development')
assert.equal(summary.source, 'bundled')
assert.equal(summary.provider, 'dsh-plugin-development')

const definition = await runtimeCtx.skills.get('dsh-plugin-development')
assert(definition, 'registered Skill could not be loaded')
assert.match(definition.content, /^# Develop and Audit DeepSeek Harness Plugins/m)
assert.equal(definition.resourceBase?.kind, 'directory')

await runtimeFiber.dispose()
assert.equal(await runtimeCtx.skills.get('dsh-plugin-development'), undefined, 'Skill remained registered after plugin disposal')
await runtimeCtx.fiber.dispose()

console.log('PASS: portable DSH discovery plus bundle registration and disposal')
