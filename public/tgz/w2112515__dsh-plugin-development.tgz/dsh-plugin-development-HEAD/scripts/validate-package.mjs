#!/usr/bin/env node

import fs from 'node:fs'
import path from 'node:path'
import process from 'node:process'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const errors = []

function check(condition, message) {
  if (!condition) errors.push(message)
}

function readText(relativePath) {
  try {
    return fs.readFileSync(path.join(root, relativePath), 'utf8').replace(/^\uFEFF/, '')
  } catch (error) {
    errors.push(`cannot read ${relativePath}: ${error.message}`)
    return ''
  }
}

function readJson(relativePath) {
  try {
    return JSON.parse(readText(relativePath))
  } catch (error) {
    errors.push(`cannot parse ${relativePath}: ${error.message}`)
    return {}
  }
}

function walk(directory) {
  const files = []
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (entry.name === '.git' || entry.name === 'node_modules' || entry.name === '.tmp') continue
    const target = path.join(directory, entry.name)
    if (entry.isDirectory()) files.push(...walk(target))
    else files.push(target)
  }
  return files
}

const manifest = readJson('package.json')
const patch = readText('cordis.patch.yml')
const entry = readText('index.js')
const readme = readText('README.md')
const skillDirectory = path.join(root, 'skills', 'dsh-plugin-development')
const skill = readText('skills/dsh-plugin-development/SKILL.md')
const openaiMetadata = readText('skills/dsh-plugin-development/agents/openai.yaml')
const frontmatterMatch = /^---\r?\n([\s\S]*?)\r?\n---\r?\n/.exec(skill)
const frontmatter = frontmatterMatch?.[1] ?? ''
const frontmatterKeys = frontmatter
  .split(/\r?\n/)
  .filter(line => line.trim() !== '')
  .map(line => line.slice(0, line.indexOf(':')).trim())
const skillName = /^name:\s*([^\r\n]+)$/m.exec(frontmatter)?.[1]?.trim() ?? ''
const descriptionSource = /^description:\s*([^\r\n]+)$/m.exec(frontmatter)?.[1]?.trim() ?? ''
const skillDescription = descriptionSource.startsWith("'") && descriptionSource.endsWith("'")
  ? descriptionSource.slice(1, -1).replaceAll("''", "'")
  : descriptionSource.startsWith('"') && descriptionSource.endsWith('"')
    ? JSON.parse(descriptionSource)
    : descriptionSource

check(manifest.name === 'dsh-plugin-development', 'package name must be dsh-plugin-development')
check(/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(manifest.version ?? ''), 'package version must be strict semver')
check(manifest.type === 'module', 'package must use ESM')
check(manifest.main === './index.js', 'package main must be ./index.js')
check(manifest.dsh?.bundle?.patch === './cordis.patch.yml', 'dsh.bundle.patch must name ./cordis.patch.yml')
check(!('prepare' in (manifest.scripts ?? {})), 'package must not execute a Git prepare build')
check(!('install' in (manifest.scripts ?? {})) && !('postinstall' in (manifest.scripts ?? {})), 'package must not execute install lifecycle scripts')
for (const required of ['index.js', 'cordis.patch.yml', 'skills/dsh-plugin-development/**/*']) {
  check(manifest.files?.includes(required), `package files must include ${required}`)
}

check(patch.includes('id: dsh-plugin-development-skill'), 'bundle patch must use the stable skill row ID')
check(patch.includes('name: dsh-plugin-development'), 'bundle patch must load the installed package name')
check(!patch.includes('../') && !/\b(?:src|lib)\//.test(patch), 'bundle patch must not reference checkout or build directories')
check(entry.includes("export const inject = ['skills']"), 'runtime plugin must inject the skill registry')
check(entry.includes('ctx.skills.register({'), 'runtime plugin must register the packaged Skill')
check(entry.includes("./skills/dsh-plugin-development/SKILL.md"), 'runtime plugin must read the canonical portable Skill')
check(!/^\s*export\s+default\b/m.test(entry), 'function plugin must not export default')
check(frontmatterMatch !== null, 'portable Skill must have a frontmatter block')
check(frontmatterKeys.join(',') === 'name,description', 'portable Skill frontmatter must use only name and description')
check(skillName === 'dsh-plugin-development', 'portable Skill frontmatter name is missing')
check(path.basename(skillDirectory) === skillName, 'portable Skill directory must match its frontmatter name')
check(/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(skillName) && skillName.length <= 64, 'portable Skill name must follow the Agent Skills naming rules')
check(skillDescription.length > 0 && skillDescription.length <= 1024, 'portable Skill description must be 1-1024 characters')
check(skillDescription.includes('DeepSeek Harness plugin'), 'portable Skill description must identify the DSH plugin use case')
check(/^# Develop and Audit DeepSeek Harness Plugins$/m.test(skill), 'portable Skill body must identify its workflow')
check(!/\$\{CLAUDE_|^\s*!`|^\s*(?:context|agent|argument-hint|allowed-tools):/m.test(skill), 'portable Skill must not depend on host-specific syntax')

check(openaiMetadata.includes('display_name: "DSH Plugin Development"'), 'Codex UI metadata must identify the Skill')
check(openaiMetadata.includes('short_description: "Develop and audit DeepSeek Harness plugins"'), 'Codex UI metadata description is missing')
check(openaiMetadata.includes('default_prompt: "Use $dsh-plugin-development'), 'Codex default prompt must invoke the portable Skill')

check(readme.includes('portable Agent Skill'), 'README must lead with the portable Skill identity')
check(readme.includes('## Codex') && readme.includes('## Claude Code') && readme.includes('## DeepSeek Harness'), 'README must document all three host surfaces')
check(readme.includes('optional DSH bundle adapter'), 'README must describe the DSH bundle as optional')

check(!fs.existsSync(path.join(root, '.codex-plugin')), 'DSH bundle must not contain a Codex plugin manifest')
check(!fs.existsSync(path.join(root, '.claude-plugin')), 'portable Skill must not require a Claude Code plugin manifest')
check(!fs.existsSync(path.join(root, 'skill')), 'retired skill/ directory must not remain as a second source')

for (const file of walk(root)) {
  if (!/\.(?:js|json|md|mjs|ya?ml)$/.test(file)) continue
  const source = fs.readFileSync(file, 'utf8')
  const relative = path.relative(root, file)
  check(!source.includes(`[${'TODO'}:`), `${relative} contains a scaffold placeholder`)
  check(!/[A-Z]:\\Users\\[^\\]+\\/.test(source), `${relative} contains a user-specific absolute path`)
  if (!file.endsWith('.md')) continue
  for (const match of source.matchAll(/\[[^\]]*\]\(([^)]+)\)/g)) {
    const rawTarget = match[1].trim().replace(/^<|>$/g, '')
    if (/^(?:https?:|mailto:|#)/.test(rawTarget)) continue
    const localTarget = decodeURIComponent(rawTarget.split('#', 1)[0])
    if (localTarget === '') continue
    check(fs.existsSync(path.resolve(path.dirname(file), localTarget)), `${relative} has a broken local link: ${rawTarget}`)
  }
}

if (errors.length > 0) {
  for (const error of errors) console.error(`ERROR: ${error}`)
  console.error(`FAIL: portable Skill and DSH adapter validation (${errors.length} error(s))`)
  process.exit(1)
}

console.log('PASS: portable Skill and DSH adapter validation')
