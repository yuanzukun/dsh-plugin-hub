# Changelog

## Unreleased

- Route marketplace solution packs (整合包, `dsh.pack.json`) to `dsh-marketplace-publish` instead of treating them as bundles.

## 0.2.0-beta.1 — 2026-08-14

- Reposition the project around one portable Agent Skill for Codex, Claude Code, and DSH.
- Move the canonical Skill into the name-matched `skills/dsh-plugin-development` directory.
- Keep the DSH bundle as an optional thin adapter that reads metadata and instructions from the canonical Skill.
- Add Codex UI metadata and cross-host validation without adding host-specific workflow forks.

## 0.1.0-beta.1 — 2026-08-14

- Publish the DSH bundle and runtime Skill registration.
- Route dynamic Cordis, workspace package, and installable bundle work through separate workflows.
- Add current-checkout authority, component ownership, lifecycle, authorization, and verification guidance.
- Include a read-only workspace-function and bundle artifact checker.
