# Security Policy

Only the latest beta is maintained while DeepSeek Harness remains in developer preview.

Use GitHub private vulnerability reporting for security-sensitive findings. Do not publish credentials, private source, session logs, filesystem paths, or executable exploit details in an issue.

The portable Skill and optional DSH adapter have no install-time build or lifecycle script, external service, credential, or network integration. The adapter registers packaged instructions inside DSH. Generated plugins may still access files, processes, networks, sessions, or install-time code; review their source and follow the active host's permission and sandbox policies.
