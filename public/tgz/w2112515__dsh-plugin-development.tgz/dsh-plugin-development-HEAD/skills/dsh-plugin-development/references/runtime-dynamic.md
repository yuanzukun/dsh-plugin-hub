# Dynamic Runtime Cordis Plugins

Use this mode only for a plugin defined and activated inside a live DSH process. It is process-local and versioned through the dynamic plugin tools; it is not a workspace package or an installable profile bundle.

## Load the live workflow

Prefer the current `cordis-plugin-development` skill when it is available in the skill catalog. Otherwise, locate the DSH root and read `apps/cli/config/agent-presets/cordis/skills/cordis-plugin-development/SKILL.md` completely before defining code. That file owns the live tool protocol, Host and Client APIs, approval states, version semantics, repair flow, and UI Slot rules.

Do not copy its provider names or schemas into a new plugin from memory. Query the running process because mounted capabilities and Client state can differ by composition and version.

## Follow the dynamic sequence

1. Call `cordis_inspect_list` to discover the registered Host and Client providers.
2. Query only the Services, Events, Builtins, Slots, theme tokens, or Tools the plugin will use.
3. For an existing `@pluginId`, read its exact package source and diagnostics with `cordis_inspect_self`; preserve the plugin identity and any unchanged Host or Client half.
4. Choose Host for filesystem, commands, processes, networking, agents, and durable Session data; choose Client for page state, Slots, theme, and browser UI; use both only when the data owner requires it.
5. Define an immutable package with `cordis_define`, then activate the returned package with `cordis_run` using the mode required by current version state.
6. Treat `awaiting-approval` and `starting` as pending, not success. End the tool flow and wait for system steering instead of polling in the same turn.
7. Inspect exact diagnostics after failure, define a new package under the same plugin, and either update to the repair or explicitly run the last successful package to roll back.

## Preserve runtime constraints

- Write plain JavaScript function bodies. Do not use imports, `require`, TypeScript syntax, JSX, decorators, or unconfirmed globals.
- Use `React.createElement` for Client React code and register UI through a queried Slot.
- Read optional Services with `ctx.get(name)` and handle absence. Declare `inject` only for hard dependencies and use `ctx.<name>` only after declaring that injection.
- Register listeners through `ctx.on`; own subscriptions and external resources through `ctx.effect` or the disposer returned by the queried API.
- Query Event mode and payload order. Delegate a Waterfall listener with `next()` unless intentional short-circuiting is the feature.
- Read only required leaf values from internal live objects. Do not clone, stringify, enumerate, retain, or send whole Service, Session, Snapshot, Event, Slot, or Context objects across Host and Client.
- Keep package-private Host-to-Client data lossless JSON. Do not create a public remote Service for package-private communication.

Use `cordis_stop` for reversible deactivation. Treat `cordis_undefine` as destructive removal and require authorization unless the user explicitly requested deletion.

## Work without live tools

If the dynamic inspect/define/run tools are unavailable, inspect source documentation and produce a design or diagnosis only. State which live schemas and activation results remain unverified. Do not invent provider methods, package IDs, approval results, or Client completion.
