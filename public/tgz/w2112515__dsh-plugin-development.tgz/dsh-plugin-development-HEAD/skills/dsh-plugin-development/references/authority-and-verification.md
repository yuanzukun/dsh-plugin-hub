# Authority and Verification

Use this reference for every DSH plugin task. Load exactly one mode-specific reference unless the request deliberately crosses modes.

## Locate the current authority

1. Resolve the target's repository root with `git rev-parse --show-toplevel` when possible. Confirm a DSH checkout from its root manifest and repository content; do not depend on a fixed drive path.
2. If the target is outside DSH, inspect its package manifest and use a user-provided or current local DSH checkout for compatibility facts. Ask for a checkout only when exact current rules cannot otherwise be established.
3. In a DSH checkout, inspect `git status --short --branch` and preserve pre-existing changes.
4. Before changing `packages/`, read the root `AGENTS.md`, `docs/architecture.md`, `packages/AGENTS.md`, and every nearer instruction file. Read `docs/defensive-patterns.md` for lifecycle, concurrency, subprocess, or teardown work.

Use this precedence for technical facts:

1. System and user instructions, then the nearest applicable `AGENTS.md`.
2. Executable validators, current types, Loader behavior, package manifests, and current implementation.
3. Generated catalogs, owning package READMEs, architecture and subsystem references.
4. Active Agent Notes for rationale and rejected alternatives.
5. Tutorials and examples for orientation.

An instruction that conflicts with an executable constraint is a repository defect, not permission to ignore either one. Surface the conflict before making a dependent change. Never edit or treat `.agents/notes/archived/` as current authority.

## Discover instead of guessing

- Find current package groups, names, scripts, compiler faces, and export maps from manifests and neighboring packages.
- Trace the actual Loader or profile composition used by the requested entry point.
- Inspect current Service, Event, Tool, Slot, and config definitions before using them.
- Prefer the closest maintained prior art that exercises the same role and runtime path.
- Verify a path's resolution base. A patch overlay does not necessarily change the directory from which module paths resolve.
- When a missing technical fact would change the design, run the smallest non-destructive spike or consumer harness that can distinguish the live options, and state what result confirms or rejects each one. Ask the user only when the unresolved choice is product intent or requires new authority.

## Select evidence by mode

| Change | Minimum relevant evidence |
| --- | --- |
| Dynamic runtime plugin | Live inspect results; successful `cordis_define`; final `cordis_run` state; Client completion or diagnostics when Client code exists |
| Workspace behavior | Focused owning tests with affected-source coverage; lifecycle disposal checks; typecheck or build evidence for changed compiler/export paths |
| Model- or product-visible workspace behavior | A real Loader composition plus the owning keyless snapshot or end-to-end scenario |
| Workspace documentation or Agent Note | The repository documentation gates and link checks required by current instructions |
| Installable bundle | Package-content inspection; isolated profile install or link; `--dump-config`; boot smoke through the packaged entry path |
| Git or registry distribution | Packed-artifact inspection and a clean install from the same artifact users receive |

Use the repository's current pre-push skill or instructions to choose exact commands. Do not reflexively run the full suite when focused evidence covers the change. Do not weaken coverage, skip a real composition, or substitute a hand-mounted plugin when the regression lives in Loader exports or configuration.

Plugin mode determines loading and packaging mechanics; the consumer surface determines the behavior that evidence must prove:

| Consumer surface | Required focus |
| --- | --- |
| Model Tool or agent workflow | Real model-visible schema and result, logged state when required, unavailable or failure behavior, and the owning keyless scenario |
| Client UI | Real Slot and page entry, representative interaction, visible failure or recovery, and required visual evidence |
| CLI or runnable app | Real source or installed entry, stdout and stderr, exit status, state changes, interruption, and disposal |
| API or wire protocol | Real consumer request, authorization, state change, stable response or error, and relevant cancellation, retry, or idempotency behavior |
| In-process Service | Current consumer harness, observable result or side effect, ownership, cancellation where applicable, and disposal |

## Handle incomplete verification

- Record the exact command or live operation, result, and failure.
- Distinguish a product failure from missing credentials, unavailable Client state, an absent runtime tool, or an environment limitation using evidence.
- Stop before publishing, pushing, or claiming readiness when required evidence is unresolved.
- For audit-only work, provide findings with location, impact, evidence, and a concrete correction; make no edits.

## Completion report

Lead with the outcome. Include:

- selected plugin mode and why;
- changed artifacts, or inspected scope for read-only work;
- behavior and compatibility decisions;
- checks actually run and their results;
- unresolved risks or unavailable evidence;
- the next concrete action, only when work remains.
