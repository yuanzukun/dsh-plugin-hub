# Component Routing and Scenario Cards

Use this reference after selecting the plugin mode. It helps separate product behavior into the smallest owned components. Treat the cards as routing examples, not manifests or APIs to copy. Confirm every named Service, Event, Slot, package, and command from the current checkout or live runtime.

## Build a component plan

For a change spanning more than one role, record this compact plan before implementation:

| Component or role | Current consumer and owner | Configuration and lifecycle owner | Observable success | Required evidence |
| --- | --- | --- | --- | --- |
| One row per required component | Name the existing caller and package or live provider | Name where validation, startup, cancellation, and disposal live | State what a user, model, or caller observes | Name the real entry path and failure case |

Omit speculative rows. A component is justified only when a current consumer needs its independently owned behavior.

## Route by component

| Need | Prefer | Keep out |
| --- | --- | --- |
| Register lifecycle behavior or consume another Service | Function plugin | Unrelated reusable API and provider-specific state |
| Expose a replaceable in-process capability | Service Definition plus at least one Provider and one Consumer | Concrete provider policy in the definition; presentation in the provider |
| Add model-facing behavior | Tool or agent-workflow Consumer using the owning Service | Provider SDK calls in the Tool; unlogged model-visible inputs |
| Add Client UI | Queried Slot or existing Client extension point | Filesystem, process, credentials, and durable authority owned by Host |
| Add CLI behavior | Existing command-line parser and app-owned startup path | A new launcher kind or hidden process exit path |
| Add API or protocol behavior | Existing transport and authorization owner | Package-private communication promoted to a public protocol without a consumer |
| Compose installable behavior | Bundle patch with stable rows and installed package references | Checkout-relative runtime paths and hand-edited profile state |

Treat a surface and its capability as separate dimensions. A Client button may consume a Host operation; a Tool may consume a Service; a bundle may compose several existing plugins without owning their behavior.

## Scenario cards

### Dynamic Client contribution

- Route to dynamic runtime mode.
- Inspect the live Client providers and query the exact Slot before designing props or selectors.
- Use Client code only for UI state and interaction. Add a Host half only when the action needs Host-owned data or authority.
- Define success as the contribution rendering at the real Slot, the representative interaction completing, and final Client diagnostics being clean.
- If live inspect, define, run, or Client completion is unavailable, stop at a source-backed design and list the unverified live facts.

### Workspace capability seam

- Route to workspace mode.
- Identify the product operation and current Consumer before defining public request or result types.
- Split Service Definition, Provider, and Consumer only when they evolve or configure independently.
- Keep provider selection, cancellation, availability, and disposal in the owning seam; keep schema and presentation in the Consumer.
- Define success through focused role tests, a real Loader composition, and the owning keyless scenario when behavior is model- or product-visible.

### Workspace CLI surface

- Route to workspace mode and identify the existing app startup and command parser.
- Decide output semantics, selectors, overwrite behavior, cancellation, partial-write cleanup, stdout, stderr, and exit status before coding.
- Use the existing persistence or capability Service instead of reading its backend files unless raw artifacts are the explicit product result.
- Verify the source or installed CLI entry, output state, interruption, and disposal. A hand-mounted plugin test does not prove the command path.

### Installable external bundle

- Route to installable-bundle mode even when the runtime modules resemble workspace plugins.
- Separate the bundle package manifest, bundle patch, and profile manifest.
- Decide whether users install prebuilt npm or tarball artifacts or authorize a pinned Git build.
- Define success from the packed files, isolated profile composition, dumped configuration, packaged boot path, and removal behavior when relevant.

### Loader export diagnosis

- Route to workspace mode when the failing module is source-backed under DSH; route to bundle mode when the failing module comes from an installed external package.
- Trace the real Loader unwrapping and mounting path before changing exports.
- For a workspace function plugin, use named protocol exports and reject a default export that would replace the namespace. For a Service class, confirm the current same-role export form instead of applying the function-plugin rule.
- Prove the correction through the real Loader path. Importing and invoking `apply` directly is insufficient evidence.

### Audit-only request

- Classify mode and component, inspect authority, and produce findings only.
- For each finding, include location, observable impact, evidence, and the smallest correction.
- Do not edit files, define or run a plugin, install a bundle, or publish an artifact unless the user separately authorizes that action.

### Compatibility spike

- Use a spike only when a technical fact cannot be established from current types, implementation, or documentation and the answer changes the design.
- Exercise the narrowest real consumer boundary with deterministic local inputs.
- State the competing outcomes and what observation confirms each one before running the spike.
- Keep the result as compatibility evidence; do not turn a spike into a public abstraction without a current consumer.

## Diagnose by failed boundary

| Symptom | Inspect first | Do not infer |
| --- | --- | --- |
| Plugin exports exist in source but injection is absent | Loader namespace unwrapping, built export map, real entry composition | Direct import success proves Loader success |
| Client contribution does not render | Live Slot name, owner props, selector result, Client diagnostics | A catalog example matches the mounted version |
| Dynamic update appears inactive | Package version state, approval or starting state, `inspect_self` diagnostics | `cordis_define` means activation completed |
| Bundle installs but behavior is absent | Packed file list, bundle declaration, profile bundle order, dumped rows, installed resolution base | Checkout build success proves installed activation |
| Tool or workflow output cannot replay | Session events and model request assembly | In-memory prompt or state is durable because the current run worked |
| Disposal leaks behavior | Registration disposer, Fiber teardown, cancellation owner, external resource shutdown | Process exit hides lifecycle defects |

Escalate a product decision only when source evidence cannot choose it. Ask one focused question that names the alternatives and the artifact or behavior each alternative changes.
