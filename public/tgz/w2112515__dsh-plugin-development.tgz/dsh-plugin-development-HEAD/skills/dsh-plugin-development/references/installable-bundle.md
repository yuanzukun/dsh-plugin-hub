# Installable DSH Bundles

Use this mode for an out-of-tree package installed into a DSH profile. A bundle contributes a configuration layer and may ship runtime Cordis modules mounted by that layer. It is not the profile itself and does not inherit every workspace-only package rule. A repository tagged `dsh-plugin-pack` is a marketplace solution pack, not a bundle — use `dsh-marketplace-publish`.

## Confirm the current package format

Locate a current DSH checkout and read `docs/user/develop/basic/publish.md`, the profile contract owned by app boot, and the CLI manifest types or implementation before authoring. Use installed-version documentation when targeting an older DSH release.

Keep the two manifests distinct:

- The bundle package declares `dsh.bundle` and names its patch file.
- The profile manifest declares `dsh.profile` and an ordered bundle list. Let `dsh plugin` create and maintain the profile instead of editing it by hand.

Use this minimal relationship, adapting fields to the current manifest type:

```json
{
  "type": "module",
  "dsh": { "bundle": { "patch": "./cordis.patch.yml" } }
}
```

Include the patch and every built runtime entry in the distributed package. Reference installed runtime modules from `cordis.patch.yml` by package name or exported subpath, not by a source-checkout-relative path.

## Design the layer deliberately

1. Give each inserted row a stable, specific ID and module name.
2. Declare required row injections and validated config at the owning plugin.
3. Inspect the current profile layer order before overriding another bundle's row.
4. Restate a row's complete `config` when the patch format replaces the whole value instead of deep-merging keys.
5. Leave deployment choices overridable by later profile, home, and command-line patch layers.
6. Use an app-owned startup Service for a surface bundle's command-line arguments; do not add a launcher-specific plugin kind without an existing contract.

Apply ordinary Cordis cleanup, injection, configuration, and failure rules to runtime modules. Do not impose DSH workspace-only requirements such as compiler aggregates or package invariants on an external bundle unless its own repository adopts them.

## Choose a distribution path

- Prefer npm or a tarball with built artifacts when users should install without executing a build.
- For a Git dependency that ships TypeScript sources, provide a self-contained `prepare` build that does not depend on a sibling monorepo or missing development state.
- Treat pnpm `allowBuilds` as permission to execute dependency code on the user's machine. Inspect the source, require explicit authorization, and pin a commit before enabling an untrusted Git build.
- Treat registry publication, pushing tags, and uploading artifacts as external writes requiring explicit authorization unless the user already requested that exact action.

Never claim that a package works from Git merely because its source checkout builds; Git installation must reproduce the packaged build path.

Run the Skill's read-only static preflight before packing:

```sh
node scripts/check-artifact.mjs bundle <package-root-or-package.json>
```

It checks the stable relationship between `package.json`, `dsh.bundle.patch`, and the patch file. It cannot prove npm file selection, runtime module resolution, patch semantics, profile precedence, or boot behavior.

## Verify the installed artifact

1. Build the package and inspect the pack or dry-run file list for the patch, runtime entries, declarations where applicable, and absence of secrets or local-only files.
2. Install or link the exact artifact into an isolated disposable profile when authorized.
3. Run `dsh --profile <name> --dump-config` and verify the bundle layer, row IDs, module names, config, and precedence.
4. Boot the profile through the packaged entry and exercise the smallest observable behavior that proves activation and cleanup.
5. Test removal when the task changes lifecycle or uninstall behavior.

Use a temporary profile or test-specific DSH home for verification. Do not overwrite a user's active profile merely to obtain evidence. Report any build permission, credential, network, or registry step that was not exercised.
