# DSH Workspace Plugins

Use this mode for code shipped from the DeepSeek Harness repository, especially under `packages/`. Read the current repository instructions and architecture before applying these routing rules.

## Choose the owned role

- Use a function plugin for lifecycle registration or consumption. Named-export `name`, required `inject`, `Config`, and `apply`; do not add a default export.
- Use a Service class when the package provides a reusable Cordis Service. Follow the current service-package export form, including its required default export.
- Build a capability as Service Definition, Service Provider, and Consumer roles when it creates a replaceable capability. Design the definition for all current consumers; keep provider-, tool-, UI-, Loader-, and transport-specific behavior in the owning role.
- Pass a private closure to one internal consumer instead of widening a generic public Service with a single-caller method.
- Keep new behavior on existing extension points. Do not change `agent-loop` merely to avoid writing a plugin.

Trace actual consumers before creating packages or public APIs. Require a current owner and need for every option, abstraction, state machine, compatibility path, and defensive copy.

For planning requests, do not invent a public request/result schema, provider target, data source, default, or operation set merely to make the plan look complete. When a missing product choice would materially change package roles or behavior, present the source-backed alternatives and ask one focused question before finalizing the plan.

## Construct a package from current prior art

1. Discover the current package group and closest same-role package. Do not reuse a group list from a tutorial.
2. Derive the package name, visibility, `exports`, dependency classes, publish settings, and files from current manifests and executable workspace constraints. Use `@deepseek-ai/dsh-<name>` for Harness packages and keep Cordis in the dependency class required by current repository rules.
3. Keep ESM throughout. Use package names across packages and `.ts` extensions for local relative imports.
4. Extend the correct host or Client tsconfig, add workspace references, and register the package in exactly one current compiler aggregate.
5. Export public modules deliberately. Exercise the real Loader or plain-Node built entry when export selection is part of the behavior.

Do not follow a stale example when its package visibility, group name, export form, or compiler registration disagrees with current instructions or validators.

For a function-plugin entry, run the read-only advisory check from the Skill directory before the real Loader test:

```sh
node scripts/check-artifact.mjs workspace-function <path-to-source-entry>
```

It catches a default export that can hide sibling protocol exports and reports missing expected named exports. Treat warnings as prompts to inspect the current contract; the script is not a TypeScript parser or a Loader substitute.

## Implement plugin contracts

- Put deployment-varying values in a validated `Config` field. Place defaults in the owning schema or explicit resolution step, not in `run()` or a test-only constant.
- Fail self-contained misconfiguration at load and service-dependent misconfiguration at the earliest point where the referent can be resolved.
- Declare hard Service dependencies and use `ctx.get(name)` for genuinely optional Services.
- Register every contribution through `ctx.effect`, `ctx.on`, or an API whose registration returns a disposer. Prove removal after Fiber disposal.
- Keep asynchronous setup, publication, cancellation, rollback, and teardown under one explicit lifecycle owner. Read `docs/defensive-patterns.md` before implementing these paths.
- Switch on closed discriminants with `assertNever`; document the default for merge-extensible unions.
- Brand opaque cross-package identifiers instead of exporting bare strings.
- Define typed Events through declaration merging. Document mode, payload, and unsupported scope scans as required by current gates.
- Give every package its required `./invariant` companion. Assert an owned runtime relationship or provide the exact package-specific empty reason allowed by current policy.

## Preserve model and product behavior

- Make every model-visible input reconstructable from the Session log; add a Session event when a new input reaches a model request.
- Design model-facing prompts, schemas, results, and diagnostics from the model's task, without UI or implementation vocabulary.
- Decide a Tool's UI render intent and locations before implementation. Keep presentation pure over arguments and the canonical result.
- Enforce permissions, limits, and denials in the operation that executes them, not only in prompts, schemas, or facades.
- Publish state and notifications only after the authoritative operation succeeds. Apply bounds where the complete retained or emitted value is known.

## Complete the repository change

- Update public JSDoc and the owning package README with configuration, behavior, failures, limitations, extension points, and model experience.
- Add or update an active Agent Note for every non-trivial behavior, architecture, process, or testing decision. Follow the repository's note and bilingual-pair rules; never edit an archived note.
- Add focused unit coverage for affected source, including disposal and invalid cases.
- Add a real Loader composition for product-visible behavior. Add or update the owning keyless snapshot for model-, CLI-, editor-, terminal-, or GUI-visible output.
- Run build, hygiene, or built-entry smoke checks when manifests, exports, compiler faces, workers, bins, or published paths change.

Use the current repository pre-push workflow to select commands. Do not claim a hand-mounted test proves a Loader export, profile composition, subprocess, worker, or built-artifact path.
