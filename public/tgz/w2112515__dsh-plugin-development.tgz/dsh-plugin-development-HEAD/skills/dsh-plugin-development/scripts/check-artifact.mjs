#!/usr/bin/env node
/**
 * Run narrow, read-only static checks for DSH plugin artifacts.
 *
 * This helper catches two stable mistakes early. It does not replace live
 * Cordis inspection, the real Loader, repository gates, npm packing, or boot.
 */

import fs from "node:fs";
import path from "node:path";
import process from "node:process";

class Report {
  errors = [];
  warnings = [];

  error(message) {
    this.errors.push(message);
  }

  warn(message) {
    this.warnings.push(message);
  }

  render(label) {
    for (const message of this.errors) console.log(`ERROR: ${message}`);
    for (const message of this.warnings) console.log(`WARN: ${message}`);
    if (this.errors.length > 0) {
      console.log(`FAIL: ${label} (${this.errors.length} error(s))`);
      return 1;
    }
    console.log(`PASS: ${label} (${this.warnings.length} warning(s))`);
    return 0;
  }
}

function loadJson(file, report) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8").replace(/^\uFEFF/, ""));
  } catch (error) {
    if (error?.code === "ENOENT") {
      report.error(`missing file: ${file}`);
    } else {
      report.error(`cannot parse ${file}: ${error.message}`);
    }
    return null;
  }
}

function isWithin(candidate, root) {
  const relative = path.relative(root, candidate);
  return relative === "" || (!relative.startsWith(`..${path.sep}`) && relative !== ".." && !path.isAbsolute(relative));
}

function escapeRegExp(value) {
  return value.replace(/[|\\{}()[\]^$+?.]/g, "\\$&");
}

function globToRegExp(pattern) {
  const doubleStar = "\u0000";
  const escaped = escapeRegExp(pattern)
    .replaceAll("**", doubleStar)
    .replaceAll("*", "[^/]*")
    .replaceAll(doubleStar, ".*");
  return new RegExp(`^${escaped}$`);
}

function filesMayInclude(entries, relativePath) {
  const candidate = relativePath.replace(/^\.\//, "").replaceAll("\\", "/");
  return entries.some((entry) => {
    if (typeof entry !== "string") return false;
    const pattern = entry.replace(/^\.\//, "").replaceAll("\\", "/").replace(/\/$/, "");
    return candidate === pattern || candidate.startsWith(`${pattern}/`) || globToRegExp(pattern).test(candidate);
  });
}

function checkBundle(target) {
  const packageJson = path.basename(target) === "package.json" ? target : path.join(target, "package.json");
  const root = path.resolve(path.dirname(packageJson));
  const report = new Report();
  const manifest = loadJson(packageJson, report);
  if (manifest === null || Array.isArray(manifest) || typeof manifest !== "object") {
    if (manifest !== null) report.error(`expected a JSON object in ${packageJson}`);
    return report.render(`bundle ${root}`);
  }

  if (manifest.type !== "module") report.error('package.json must declare "type": "module"');
  if (manifest.dsh === null || Array.isArray(manifest.dsh) || typeof manifest.dsh !== "object") {
    report.error("package.json must contain a dsh object");
    return report.render(`bundle ${root}`);
  }
  if (manifest.dsh.bundle === null || Array.isArray(manifest.dsh.bundle) || typeof manifest.dsh.bundle !== "object") {
    report.error("package.json must contain dsh.bundle");
    return report.render(`bundle ${root}`);
  }

  const patchValue = manifest.dsh.bundle.patch;
  if (typeof patchValue !== "string" || patchValue.trim() === "") {
    report.error("dsh.bundle.patch must be a non-empty relative path");
    return report.render(`bundle ${root}`);
  }
  if (!patchValue.startsWith("./")) report.error("dsh.bundle.patch must start with ./");

  const patchPath = path.resolve(root, patchValue);
  if (!isWithin(patchPath, root)) {
    report.error("dsh.bundle.patch resolves outside the package root");
  } else if (!fs.existsSync(patchPath) || !fs.statSync(patchPath).isFile()) {
    report.error(`bundle patch does not exist: ${patchPath}`);
  }

  if (Array.isArray(manifest.files) && !filesMayInclude(manifest.files, patchValue)) {
    report.warn("package.json files may exclude the bundle patch; confirm with the packed file list");
  }
  if (Object.hasOwn(manifest.dsh, "profile")) {
    report.warn("package declares both dsh.bundle and dsh.profile; confirm the two responsibilities are intentional");
  }
  return report.render(`bundle ${root}`);
}

function hasNamedExport(source, name) {
  const declaration = new RegExp(
    String.raw`^[ \t]*export[ \t]+(?:declare[ \t]+)?(?:async[ \t]+)?(?:function|const|let|var|class|interface|type|enum)[ \t]+${escapeRegExp(name)}\b`,
    "m",
  );
  if (declaration.test(source)) return true;
  for (const block of source.matchAll(/\bexport\s*\{([\s\S]*?)\}/g)) {
    for (const item of block[1].split(",")) {
      const exported = item.replace(/\s+/g, " ").trim();
      if (exported === name || exported.endsWith(` as ${name}`)) return true;
    }
  }
  return false;
}

function checkWorkspaceFunction(entry) {
  const report = new Report();
  let source;
  try {
    source = fs.readFileSync(entry, "utf8").replace(/^\uFEFF/, "");
  } catch (error) {
    report.error(error?.code === "ENOENT" ? `missing file: ${entry}` : `cannot read ${entry}: ${error.message}`);
    return report.render(`workspace function ${entry}`);
  }

  if (/^[ \t]*export[ \t]+default\b/m.test(source)) {
    report.error("function plugin entry must not have a default export; the Loader may discard sibling protocol exports");
  }
  if (!hasNamedExport(source, "apply")) report.error("function plugin entry must export named apply");
  for (const expected of ["name", "inject", "Config"]) {
    if (!hasNamedExport(source, expected)) {
      report.warn(`named ${expected} export was not detected; confirm the current function-plugin contract`);
    }
  }
  return report.render(`workspace function ${path.resolve(entry)}`);
}

function usage() {
  console.error("Usage:");
  console.error("  node check-artifact.mjs bundle <package-root-or-package.json>");
  console.error("  node check-artifact.mjs workspace-function <source-entry>");
  return 2;
}

const [mode, target, ...extra] = process.argv.slice(2);
if (!mode || !target || extra.length > 0) process.exit(usage());
if (mode === "bundle") process.exit(checkBundle(target));
if (mode === "workspace-function") process.exit(checkWorkspaceFunction(target));
process.exit(usage());
