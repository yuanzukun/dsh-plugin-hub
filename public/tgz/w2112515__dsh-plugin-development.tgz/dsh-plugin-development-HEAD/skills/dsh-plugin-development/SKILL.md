---
name: dsh-plugin-development
description: 'Use when designing, creating, modifying, packaging, installing, reviewing, auditing, or diagnosing a DeepSeek Harness plugin: a live dynamic Cordis plugin driven by cordis_define, a source-backed workspace plugin under packages, or an out-of-tree installable bundle using dsh.bundle and cordis.patch.yml. Also use for plugin Loader exports, Service/Provider/Consumer roles, Client Slots, CLI surfaces, lifecycle, configuration, profile composition, and plugin verification. Not for marketplace solution packs, 整合包, dsh.pack.json, or dsh-plugin-pack — those belong to dsh-marketplace-publish.'
---

# Develop and Audit DeepSeek Harness Plugins

Classify the plugin before designing it. Dynamic runtime packages, repository workspace packages, and installable bundles use different source formats, loaders, persistence models, and evidence. Do not transfer a rule from one mode without confirming that it applies.

## Establish authority and intent

1. Identify the requested outcome, target files or runtime, and whether the user asked to inspect or to change it.
2. Locate the current DeepSeek Harness checkout and read [authority and verification](references/authority-and-verification.md). Use current repository evidence instead of memorized package lists or copied tutorial manifests.
3. Determine the plugin mode from the target and available tools. If the request is a marketplace solution pack (整合包, `dsh.pack.json`, `dsh-plugin-pack`, or a curated catalog list), stop. Use `dsh-marketplace-publish`. Do not select a plugin mode or author `dsh.bundle` / `cordis.patch.yml` for that artifact.

| Mode | Strong indicators | Read next |
| --- | --- | --- |
| Dynamic runtime | `cordis_define`, `cordis_run`, a live Host or Client, Slots, `@pluginId`, or a process-local customization | [runtime dynamic plugins](references/runtime-dynamic.md) |
| Workspace package | A target under `packages/`, a repository capability or Consumer, or a change shipped as part of DSH | [workspace plugins](references/workspace-plugin.md) |
| Installable bundle | `dsh.bundle`, `cordis.patch.yml`, `dsh plugin`, profile composition, npm, a tarball, or an out-of-tree package | [installable bundles](references/installable-bundle.md) |

When a request intentionally crosses modes, split it into explicit phases and load each applicable reference. When the evidence remains ambiguous and the modes would produce different artifacts, ask one focused question: whether the result should be process-local, shipped in the DSH repository, installable into a profile, or a marketplace solution pack (then switch to `dsh-marketplace-publish`).

After selecting the mode, classify the owned component and consumer surface. Read [component routing and scenarios](references/component-routing.md) for a new design, a cross-role change, unclear ownership, or diagnosis spanning more than one component. Skip it for a narrow same-role task whose owner and entry path are already established.

Use the read-only [artifact checker](scripts/check-artifact.mjs) only for the workspace function-plugin or bundle preflight requested by the applicable mode reference. Treat it as an early static guard, never as completion evidence.

## Apply authorization once

- For answer, explanation, review, audit, diagnosis, or planning requests, inspect the relevant material and report the result. Do not implement changes unless the request also asks for them.
- For create, change, build, or fix requests, make the requested in-scope local changes and run relevant non-destructive validation without asking first.
- Require confirmation for publishing, external writes, destructive removal, executing an untrusted dependency's install-time code, purchases, credential use beyond an already authorized check, or a material expansion of scope.

Reading files, inspecting the runtime, editing requested local files, and running non-destructive tests are safe in-scope actions. Preserve unrelated changes and obey the nearest repository instructions.

## Execute the selected workflow

1. Discover: inspect the target, current configuration, neighboring implementations, repository status, and real loading path.
2. Plan components: identify the consumer, current owner, required plugin roles, configuration owner, lifecycle owner, observable result, and evidence. Use a compact component table when more than one role is involved.
3. Resolve decisions: establish entry and preconditions, action and input, result or state, failure and recovery, cleanup, model-visible effects, and authorization before coding.
4. Implement: change only the required components and update owning documentation or decision records required by the selected mode.
5. Validate: run the narrowest evidence that exercises the real dynamic, Loader, packaged, or consumer entry path. An advisory static check never substitutes for that evidence.
6. Report: lead with the outcome, selected mode, changed artifacts or audit findings, checks actually run, unresolved risks, and the next concrete action.

## Stop on invalid assumptions

- Do not silently reconcile a conflict between repository instructions and executable constraints. Cite both, explain why they cannot both be satisfied, and request resolution if the task depends on the conflict.
- Do not treat an archived Agent Note, generated artifact, tutorial example, or remembered API as current authority.
- Do not claim a dynamic plugin ran when the live Cordis tools or responding Client were unavailable.
- Do not mutate `vendor/` unless the user explicitly requests vendoring work and the repository procedure authorizes it.
