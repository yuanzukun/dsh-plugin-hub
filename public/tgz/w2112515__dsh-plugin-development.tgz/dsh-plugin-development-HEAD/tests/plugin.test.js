import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import test from 'node:test'
import { fileURLToPath } from 'node:url'
import { apply, inject, name } from '../index.js'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const portableSkill = path.join(root, 'skills', 'dsh-plugin-development')

test('exports the named Cordis function-plugin protocol', () => {
  assert.equal(name, 'dsh-plugin-development')
  assert.deepEqual(inject, ['skills'])
})

test('registers the packaged Skill and its resource directory', () => {
  let registered
  const ctx = {
    skills: {
      register(skill) {
        registered = skill
        return () => {}
      },
    },
  }

  apply(ctx)

  assert(registered)
  assert.equal(registered.name, 'dsh-plugin-development')
  assert.equal(registered.source, 'bundled')
  assert.equal(registered.provider, 'dsh-plugin-development')
  assert.equal(registered.resourceBase.kind, 'directory')
  assert.equal(registered.resourceBase.path, portableSkill)
  assert.equal(fs.existsSync(registered.path), true)
  assert.equal(fs.existsSync(`${registered.resourceBase.path}/references/installable-bundle.md`), true)
  assert.equal(fs.existsSync(`${registered.resourceBase.path}/agents/openai.yaml`), true)
  assert.match(registered.description, /DeepSeek Harness plugin/)
  assert.match(registered.content, /^# Develop and Audit DeepSeek Harness Plugins/m)
  assert.doesNotMatch(registered.content, /^---/)
})

test('keeps the portable Agent Skill in a name-matched directory', () => {
  const source = fs.readFileSync(path.join(portableSkill, 'SKILL.md'), 'utf8')
  assert.equal(path.basename(portableSkill), 'dsh-plugin-development')
  assert.match(source, /^---\r?\nname: dsh-plugin-development\r?\n/m)
  assert.doesNotMatch(source, /^\s*(?:context|agent|allowed-tools|argument-hint):/m)
})
