# Contributing

Treat `skills/dsh-plugin-development` as the only workflow source. Keep its `SKILL.md`, references, and scripts portable across Codex, Claude Code, and DSH; host adapters may add discovery or presentation metadata but must not fork the instructions.

Use a current DeepSeek Harness checkout as the technical authority. Identify the plugin mode, consumer, owner, Loader or runtime entry, and observable result before changing guidance. Keep `SKILL.md` compact and route mode-specific detail into its references. Do not copy large DSH documentation sections, freeze a local checkout path, invent public APIs, or promote tutorials and archived notes over executable constraints.

Run:

```sh
npm test
npm pack --dry-run
```

Also run Codex's `quick_validate.py` or the Agent Skills reference validator against `skills/dsh-plugin-development` when available. For runtime or packaging changes, exercise direct DSH filesystem discovery, then install the packed tarball into an isolated DSH home and verify the composed row, installed entry, Skill registration, and disposal. Pull requests should name the host versions and DSH commit used as evidence and list checks actually run.
