import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react'

import type { Config } from '../config.js'
import type { EndpointStatus } from '../status.js'
import type { SettingsPathOp, SettingsScopeSnapshot } from './contract.js'
import { GROUPS, formatList, parseList, pathKey, readPath, type FieldSpec, type GroupSpec } from './fields.js'
import { clientSnippet, maskSecret, sourceLabel, TOKEN_PLACEHOLDER } from './snippet.js'

/** The bound settings namespace, as the section consumes it. */
export interface SectionStore {
  subscribe(listener: () => void): () => void
  getSnapshot(): SettingsScopeSnapshot<Config>
  mutate(ops: readonly SettingsPathOp[], revision?: number): Promise<void>
  /**
   * Whether a token is pinned, per the settings describe mirror. The settings
   * form never carries the literal; the live value the Copy button needs comes
   * from {@link SectionStore.readStatus}.
   */
  secretIsSet(): boolean
  /** Live endpoint state, or `undefined` when the host route is not reachable. */
  readStatus(): Promise<EndpointStatus | undefined>
}

/** Props the slot hands this component. */
export interface SectionProps {
  t(key: string): string
  store: SectionStore
  /** Where the generated token lives, for the copyable client configuration. */
  tokenFile: string
}

/**
 * Commit on blur, not on every keystroke.
 *
 * A settings write is a round trip through the host document, so writing per
 * character would queue a request per character. Holding a local draft also
 * means a value arriving from another surface cannot overwrite what the user is
 * currently typing.
 */
function DraftInput({
  value,
  disabled,
  placeholder,
  type,
  min,
  max,
  onCommit,
}: {
  value: string
  disabled: boolean
  placeholder?: string
  type: 'text' | 'number' | 'password'
  min?: number
  max?: number
  onCommit(next: string): void
}) {
  const [draft, setDraft] = useState(value)
  const editing = useRef(false)

  useEffect(() => {
    if (!editing.current) setDraft(value)
  }, [value])

  return (
    <input
      className="dshmcp_input"
      type={type}
      value={draft}
      disabled={disabled}
      {...(placeholder === undefined ? {} : { placeholder })}
      {...(min === undefined ? {} : { min })}
      {...(max === undefined ? {} : { max })}
      onFocus={() => {
        editing.current = true
      }}
      onChange={(event) => {
        setDraft(event.target.value)
      }}
      onBlur={() => {
        editing.current = false
        if (draft !== value) onCommit(draft)
      }}
      onKeyDown={(event) => {
        if (event.key === 'Enter') (event.target as HTMLInputElement).blur()
        if (event.key === 'Escape' && editing.current) {
          editing.current = false
          setDraft(value)
          ;(event.target as HTMLInputElement).blur()
        }
      }}
    />
  )
}

/** One labelled control. */
function FieldRow({
  t,
  field,
  value,
  disabled,
  onWrite,
}: {
  t(key: string): string
  field: FieldSpec
  value: unknown
  disabled: boolean
  onWrite(next: unknown): void
}) {
  const stacked = field.kind === 'text' || field.kind === 'number' || field.kind === 'list'
  return (
    <label className={`dshmcp_row${stacked ? ' dshmcp_rowStack' : ''}`} data-field={pathKey(field.path)}>
      <span className="dshmcp_rowMain">
        <span className="dshmcp_label">{t(field.label)}</span>
        {field.hint !== undefined && <span className="dshmcp_hint">{t(field.hint)}</span>}
      </span>
      <span className="dshmcp_control">
        {field.kind === 'toggle' && (
          <input
            className="dshmcp_check"
            type="checkbox"
            checked={value === true}
            disabled={disabled}
            onChange={(event) => {
              onWrite(event.target.checked)
            }}
          />
        )}
        {field.kind === 'list' && (
          // Comma-separated, editing a real `string[]` on the host. The joined
          // form is what `DraftInput` compares against, so an untouched field
          // writes nothing.
          <DraftInput
            type="text"
            value={formatList(value)}
            disabled={disabled}
            {...(field.placeholder === undefined ? {} : { placeholder: field.placeholder })}
            onCommit={(next) => {
              onWrite(parseList(next))
            }}
          />
        )}
        {(field.kind === 'text' || field.kind === 'number') && (
          <DraftInput
            type={field.kind === 'number' ? 'number' : 'text'}
            value={value === undefined || value === null ? '' : String(value)}
            disabled={disabled}
            {...(field.placeholder === undefined ? {} : { placeholder: field.placeholder })}
            {...(field.min === undefined ? {} : { min: field.min })}
            {...(field.max === undefined ? {} : { max: field.max })}
            onCommit={(next) => {
              if (field.kind === 'text') {
                onWrite(next)
                return
              }
              // A number input can hold an empty or half-typed value; neither is
              // a number the host would accept, so a draft like "1" on the way to
              // "1000" must not become a write.
              const parsed = Number(next)
              if (next.trim() === '' || !Number.isFinite(parsed)) return
              if (field.min !== undefined && parsed < field.min) return
              if (field.max !== undefined && parsed > field.max) return
              onWrite(parsed)
            }}
          />
        )}
        {field.kind === 'select' && (
          <select
            className="dshmcp_input"
            value={value === undefined || value === null ? '' : String(value)}
            disabled={disabled}
            onChange={(event) => {
              onWrite(event.target.value)
            }}
          >
            {(field.options ?? []).map((option) => (
              <option key={option.value} value={option.value}>
                {t(option.label)}
              </option>
            ))}
          </select>
        )}
      </span>
    </label>
  )
}

/** One titled group. */
function Group({
  t,
  group,
  value,
  disabled,
  onWrite,
}: {
  t(key: string): string
  group: GroupSpec
  value: unknown
  disabled: boolean
  onWrite(field: FieldSpec, next: unknown): void
}) {
  return (
    <section className="dshmcp_group">
      <h3 className="dshmcp_groupTitle">{t(group.title)}</h3>
      <p className="dshmcp_groupDesc">{t(group.description)}</p>
      <div className="dshmcp_rows">
        {group.fields.map((field) => (
          <FieldRow
            key={pathKey(field.path)}
            t={t}
            field={field}
            value={readPath(value, field.path)}
            disabled={disabled}
            onWrite={(next) => {
              onWrite(field, next)
            }}
          />
        ))}
      </div>
    </section>
  )
}

/** The write-only token control. */
function TokenRow({
  t,
  isSet,
  disabled,
  onWrite,
  onClear,
}: {
  t(key: string): string
  isSet: boolean
  disabled: boolean
  onWrite(value: string): void
  onClear(): void
}) {
  const [draft, setDraft] = useState('')
  return (
    <label className="dshmcp_row dshmcp_rowStack" data-field="auth.token">
      <span className="dshmcp_rowMain">
        <span className="dshmcp_label">
          {t('field.auth.token')}{' '}
          <span className={`dshmcp_badge${isSet ? ' dshmcp_badgeOk' : ''}`}>
            {isSet ? t('field.auth.token.set') : t('field.auth.token.unset')}
          </span>
        </span>
        <span className="dshmcp_hint">{t('field.auth.token.hint')}</span>
      </span>
      <span className="dshmcp_control">
        <input
          className="dshmcp_input"
          type="password"
          value={draft}
          disabled={disabled}
          placeholder={t('field.auth.token.placeholder')}
          autoComplete="off"
          onChange={(event) => {
            setDraft(event.target.value)
          }}
          onBlur={() => {
            // An empty box means "I did not type anything", never "clear it" —
            // clearing is its own button, because it cannot be undone from here.
            if (draft !== '') {
              onWrite(draft)
              setDraft('')
            }
          }}
          onKeyDown={(event) => {
            if (event.key === 'Enter') (event.target as HTMLInputElement).blur()
          }}
        />
        {isSet && (
          <button
            className="dshmcp_btn"
            type="button"
            disabled={disabled}
            onClick={onClear}
          >
            {t('field.auth.token.clear')}
          </button>
        )}
      </span>
    </label>
  )
}

/** The read-only pane: where to point a client, and whether the endpoint is up. */
function ClientConfig({
  t,
  url,
  mounted,
  token,
  tokenSource,
  tokenFile,
  status,
  statusRead,
}: {
  t(key: string): string
  url: string
  mounted: boolean
  /** The live bearer token, or `undefined` while the host has not reported one. */
  token: string | undefined
  tokenSource: string | undefined
  tokenFile: string
  status: EndpointStatus | undefined
  statusRead: boolean
}) {
  const [copied, setCopied] = useState<'idle' | 'ok' | 'failed'>('idle')
  const [revealed, setRevealed] = useState(false)

  // Two renderings of one snippet. What is shown masks the token so a shared
  // screen does not leak it; what the button copies carries the real value, so
  // the pasted configuration works without a trip to the token file. Until the
  // host answers — or on a profile that mounts no status route — both fall back
  // to the placeholder rather than inventing a value.
  const known = token !== undefined && token !== ''
  const copyText = clientSnippet(url, known ? token : TOKEN_PLACEHOLDER)
  const shownText = clientSnippet(url, known ? (revealed ? token : maskSecret(token)) : TOKEN_PLACEHOLDER)
  const source = sourceLabel(t, tokenSource)

  return (
    <section className="dshmcp_group">
      <h3 className="dshmcp_groupTitle">{t('client.title')}</h3>
      <p className="dshmcp_groupDesc">{t('client.description')}</p>
      <pre className="dshmcp_code">{shownText}</pre>
      <div className="dshmcp_control">
        <button
          className="dshmcp_btn"
          type="button"
          onClick={() => {
            void navigator.clipboard
              .writeText(copyText)
              .then(() => {
                setCopied('ok')
              })
              .catch(() => {
                setCopied('failed')
              })
          }}
        >
          {copied === 'ok' ? t('client.copied') : copied === 'failed' ? t('client.copyFailed') : t('client.copy')}
        </button>
        {known && (
          <button
            className="dshmcp_btn"
            type="button"
            onClick={() => {
              setRevealed((on) => !on)
            }}
          >
            {revealed ? t('client.hide') : t('client.reveal')}
          </button>
        )}
        {statusRead && (
          <span className={`dshmcp_badge${status?.listening === true ? ' dshmcp_badgeOk' : ''}`}>
            {status?.listening === true ? t('client.listening') : t('client.notListening')}
          </span>
        )}
        {mounted && <span className="dshmcp_badge">{t('client.mounted')}</span>}
      </div>
      <p className="dshmcp_note">
        {t('client.tokenSourceLabel')}
        {source ?? t('client.tokenUnknown')}
      </p>
      {!known && (
        <p className="dshmcp_note">
          {t('client.tokenUnknownHint')} <code>{tokenFile}</code>
        </p>
      )}
      {status !== undefined && status.enabledToolGroups.length > 0 && (
        <p className="dshmcp_note">
          {t('client.toolsLabel')}
          {status.enabledToolGroups.join(', ')}
        </p>
      )}
      {status?.error != null && (
        <p className="dshmcp_error">
          {t('client.errorLabel')}
          {status.error}
        </p>
      )}
    </section>
  )
}

/**
 * The MCP section.
 *
 * Every control writes one path, and the snapshot it renders comes from the same
 * namespace the host registers — so what this panel shows is what the endpoint
 * will read on its next request, with no second copy to fall out of step.
 */
export function McpSection({ t, store, tokenFile }: SectionProps) {
  const snapshot = useSyncExternalStore(store.subscribe, store.getSnapshot)
  const [writeError, setWriteError] = useState(false)
  const [status, setStatus] = useState<EndpointStatus>()
  const [statusRead, setStatusRead] = useState(false)
  const live = useRef(true)

  const value = snapshot.value
  const writable = snapshot.writable && snapshot.status === 'ready' && value !== undefined

  // The status route is polled rather than subscribed: it reports state that
  // changes outside the settings document (a port taken by someone else, a bind
  // that failed), and a slow poll is enough to answer "is it up right now?".
  // A write also refreshes it directly, so the snippet and the token badge
  // reflect a value the user just typed instead of the previous poll's answer.
  const refreshStatus = useCallback(
    () =>
      store.readStatus().then((next) => {
        if (!live.current) return
        setStatusRead(true)
        setStatus(next)
      }),
    [store],
  )

  useEffect(() => {
    live.current = true
    void refreshStatus()
    const timer = setInterval(() => {
      void refreshStatus()
    }, 5_000)
    return () => {
      live.current = false
      clearInterval(timer)
    }
  }, [refreshStatus])

  const write = useCallback(
    (path: readonly string[], next: unknown) => {
      setWriteError(false)
      return store.mutate([{ op: 'set', path: [...path], value: next }], snapshot.revision).catch(() => {
        setWriteError(true)
      })
    },
    [store, snapshot.revision],
  )

  const clear = useCallback(
    (path: readonly string[]) => {
      setWriteError(false)
      return store.mutate([{ op: 'unset', path: [...path] }], snapshot.revision).catch(() => {
        setWriteError(true)
      })
    },
    [store, snapshot.revision],
  )

  // Whether a token is pinned, as the host itself sees it. The settings mirror
  // can only answer "is the field defined?", which is a proxy that a schema
  // default or an explicitly stored empty string distorts; the status route
  // reports whether the effective credential is a pinned one or the file/generated
  // fallback, which is the actual question. The mirror remains the fallback for a
  // profile whose status route is absent.
  const pinnedFromStatus = status === undefined
    ? undefined
    : status.tokenSource === 'settings' || status.tokenSource === 'config'
  const tokenIsSet = pinnedFromStatus ?? store.secretIsSet()

  const host = readPath(value, ['http', 'host'])
  const port = readPath(value, ['http', 'port'])
  const path = readPath(value, ['http', 'path'])
  const hostText = typeof host === 'string' && host !== '' ? host : '127.0.0.1'
  const url = `http://${hostText === '0.0.0.0' ? '127.0.0.1' : hostText}:${String(port ?? '')}${String(path ?? '')}`

  return (
    <div className="dshmcp">
      <p className="dshmcp_intro">{t('intro')}</p>

      {snapshot.status === 'loading' && <p className="dshmcp_note">{t('state.loading')}</p>}
      {snapshot.status === 'unavailable' && <p className="dshmcp_error">{t('state.unavailable')}</p>}
      {snapshot.status === 'ready' && !snapshot.writable && <p className="dshmcp_note">{t('state.readonly')}</p>}
      {writeError && <p className="dshmcp_error">{t('state.writeFailed')}</p>}

      {GROUPS.map((group) => (
        <Group
          key={group.id}
          t={t}
          group={group}
          value={value}
          disabled={!writable}
          onWrite={(field, next) => {
            void write(field.path, next)
          }}
        />
      ))}

      <section className="dshmcp_group">
        <h3 className="dshmcp_groupTitle">{t('group.auth.title')}</h3>
        <p className="dshmcp_groupDesc">{t('group.auth.description')}</p>
        <div className="dshmcp_rows">
          <TokenRow
            t={t}
            isSet={tokenIsSet}
            disabled={!writable}
            onWrite={(next) => {
              void write(['auth', 'token'], next).then(() => refreshStatus())
            }}
            onClear={() => {
              void clear(['auth', 'token']).then(() => refreshStatus())
            }}
          />
        </div>
      </section>

      <ClientConfig
        t={t}
        url={url}
        mounted={readPath(value, ['http', 'mountOnWebServer']) === true}
        token={status?.token}
        tokenSource={status?.tokenSource}
        tokenFile={status?.tokenFile ?? tokenFile}
        status={status}
        statusRead={statusRead}
      />
    </div>
  )
}
