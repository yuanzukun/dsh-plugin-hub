import type { CallToolResult, McpServer } from '@modelcontextprotocol/server'
import { z } from 'zod'

import type { Config } from '../config.js'
import type { DshDriver } from '../dsh/driver.js'
import type { DshLogger } from '../dsh/types.js'
import type { EndpointStatus } from '../status.js'

/** Where external agents should connect, reported by `dsh_info`. */
export interface ConnectionInfo {
  /** The endpoint an MCP client should POST to. */
  readonly url: string
  /** The bearer token the endpoint requires. */
  readonly token: string
  /** How that token was obtained. */
  readonly tokenSource: string
  /** Whether the endpoint is also reachable through DSH's own web server. */
  readonly mountedOnWebServer: boolean
}

/**
 * What {@link registerTools} needs beyond the server itself.
 *
 * Configuration is a getter rather than a value: the MCP handler builds a fresh
 * server per request, so reading the toggles here at that moment is what makes a
 * settings-panel change show up in the very next `tools/list` instead of at the
 * next restart.
 */
export interface ToolDeps {
  readonly driver: McpDriver
  readonly getConfig: () => Config
  readonly connection: () => ConnectionInfo
  /** Live endpoint state, so a caller can tell "not listening" from "no such tool". */
  readonly status: () => EndpointStatus
  readonly log: DshLogger
}

/**
 * The driver surface the tools use.
 *
 * Expressed as a `Pick` of the real driver so there is one source of truth for
 * the signatures, while tests can supply a stub without constructing a Cordis
 * context.
 */
export type McpDriver = Pick<
  DshDriver,
  | 'describeCapabilities'
  | 'ownsSession'
  | 'createWorkspace'
  | 'listWorkspaces'
  | 'createSession'
  | 'listSessions'
  | 'promptSession'
  | 'cancelSession'
  | 'readTranscript'
  | 'readFile'
  | 'writeFile'
  | 'listDirectory'
  | 'runShell'
  | 'listAgentTools'
  | 'callAgentTool'
>

/** Pretty-printed JSON as ordinary text content — the one shape every MCP client renders. */
function ok(value: unknown): CallToolResult {
  return { content: [{ type: 'text', text: JSON.stringify(value, null, 2) }] }
}

/**
 * A harness tool that ran and failed, as a protocol-level tool error.
 *
 * The payload still carries the whole outcome, so a caller that reads it loses
 * nothing; `isError` is set because the protocol is where a model looks to learn
 * that a call did not succeed. Leaving it unset would bury `ok: false` inside a
 * JSON body the model may treat as a success.
 */
function toolOutcome(value: { ok: boolean }): CallToolResult {
  const result = ok(value)
  return value.ok ? result : { ...result, isError: true }
}

/**
 * Wrap a tool body so a harness failure becomes a readable tool error rather
 * than a transport error.
 *
 * The caller is handed the message alone: a stack trace would leak this host's
 * paths into another agent's context and spend its attention on frames it
 * cannot act on. The full error, stack included, goes to the DSH log instead.
 */
function guard<A>(name: string, log: DshLogger, body: (args: A) => Promise<CallToolResult>) {
  return async (args: A): Promise<CallToolResult> => {
    try {
      return await body(args)
    } catch (error) {
      log.warn(`[dsh-as-mcp] %s failed:`, name, error)
      return {
        content: [{
          type: 'text',
          text: `${name} failed: ${error instanceof Error ? error.message : String(error)}`,
        }],
        isError: true,
      }
    }
  }
}

/**
 * Register every enabled tool on one MCP server instance.
 *
 * `createMcpHandler` builds a fresh server from a factory per request, so this
 * runs on every call; keep the bodies thin and push work into {@link DshDriver}.
 */
export function registerTools(server: McpServer, deps: ToolDeps): void {
  const { driver, getConfig, connection, status, log } = deps
  const enabled = getConfig().tools

  server.registerTool(
    'dsh_info',
    {
      title: 'Describe this DSH MCP endpoint',
      description:
        'Report which DeepSeek Harness services this endpoint can drive, which tool groups are enabled, '
        + 'and the endpoint URL plus where its bearer token comes from. Call this first when you are unsure '
        + 'whether a capability (sessions, files, shell) is available in this DSH profile.',
      inputSchema: z.object({}),
      annotations: { readOnlyHint: true, openWorldHint: false },
    },
    guard('dsh_info', log, async () => {
      const info = connection()
      const live = status()
      return ok({
        endpoint: info.url,
        // The token itself is deliberately absent. Its value is not needed by a
        // caller that just authenticated with it, and echoing a live credential
        // puts it into every calling agent's transcript and logs. `tokenSource`
        // and `tokenFile` say where it comes from, which is what a client that
        // legitimately needs to hand it on actually requires.
        tokenSource: info.tokenSource,
        tokenFile: live.tokenFile,
        mountedOnDshWebServer: info.mountedOnWebServer,
        listening: live.listening,
        listenError: live.error,
        settingsRegistered: live.settingsRegistered,
        enabledToolGroups: enabled,
        harnessServices: driver.describeCapabilities(),
        notes: [
          'workspace_* and session_* drive this DSH instance directly; work appears live in the DSH UI.',
          'session_prompt waits for the turn to settle by default and returns the agent reply plus its tool calls.',
        ],
      })
    }),
  )

  if (enabled.workspace) {
    server.registerTool(
      'workspace_create',
      {
        title: 'Create a DSH workspace',
        description:
          'Register a directory as a workspace in DeepSeek Harness, so sessions created in it appear under '
          + 'that project in the DSH UI. Returns the existing registration when the path is already a workspace. '
          + 'The directory is created first unless createDirectory is false.',
        inputSchema: z.object({
          path: z.string().describe('Absolute path of the project directory.'),
          title: z.string().optional().describe('Display title; defaults to the final path segment.'),
          createDirectory: z
            .boolean()
            .optional()
            .describe('Create the directory when it does not exist. Defaults to true.'),
        }),
        annotations: { openWorldHint: false },
      },
      guard('workspace_create', log, async (args) => ok(await driver.createWorkspace({
        path: args.path,
        ...(args.title === undefined ? {} : { title: args.title }),
        ...(args.createDirectory === undefined ? {} : { createDirectory: args.createDirectory }),
      }))),
    )

    server.registerTool(
      'workspace_list',
      {
        title: 'List DSH workspaces',
        description: 'List every workspace registered in this DeepSeek Harness, with its id, path, title, session count, and whether the directory still exists.',
        inputSchema: z.object({}),
        annotations: { readOnlyHint: true, openWorldHint: false },
      },
      guard('workspace_list', log, async () => ok({ workspaces: await driver.listWorkspaces() })),
    )
  }

  if (enabled.session) {
    server.registerTool(
      'session_create',
      {
        title: 'Start a DSH agent session',
        description:
          'Create a new DeepSeek Harness agent session bound to a workspace (or a bare directory) and return '
          + 'its session id. Pass that id to session_prompt to make the DSH agent do work. Sessions are visible '
          + 'live in the DSH UI. Model selection falls back to this DSH instance\'s default route.',
        inputSchema: z.object({
          workspaceId: z.string().optional().describe('Workspace id from workspace_list or workspace_create.'),
          cwd: z.string().optional().describe('Bare directory to bind the session to; use instead of workspaceId.'),
          agentPreset: z.string().optional().describe('Agent preset id; defaults to the harness default.'),
          provider: z.string().optional().describe('Model provider route. Must be paired with model.'),
          model: z.string().optional().describe('Model id. Must be paired with provider.'),
        }),
        annotations: { openWorldHint: false },
      },
      guard('session_create', log, async (args) => ok(await driver.createSession({
        ...(args.workspaceId === undefined ? {} : { workspaceId: args.workspaceId }),
        ...(args.cwd === undefined ? {} : { cwd: args.cwd }),
        ...(args.agentPreset === undefined ? {} : { agentPreset: args.agentPreset }),
        ...(args.provider === undefined ? {} : { provider: args.provider }),
        ...(args.model === undefined ? {} : { model: args.model }),
      }))),
    )

    server.registerTool(
      'session_list',
      {
        title: 'List DSH sessions',
        description: 'List sessions known to this DeepSeek Harness, most recently updated first.',
        inputSchema: z.object({
          limit: z.number().int().positive().max(200).optional().describe('Maximum sessions to return. Defaults to 20.'),
        }),
        annotations: { readOnlyHint: true, openWorldHint: false },
      },
      guard('session_list', log, async (args) => ok({ sessions: await driver.listSessions(args.limit ?? 20) })),
    )

    server.registerTool(
      'session_prompt',
      {
        title: 'Ask a DSH session to do work',
        description:
          'Send one user message to a DSH agent session. This is how to write code through DSH: describe the '
          + 'task and the DSH agent runs its own tools (file edits, shell, subagents) in the session workspace, '
          + 'subject to this DSH instance\'s permission policy. By default the call waits for the turn to settle '
          + 'and returns the agent\'s final reply plus every tool call it made. Set wait=false to queue the '
          + 'message and return immediately.',
        inputSchema: z.object({
          sessionId: z.string().describe('Session id from session_create or session_list.'),
          // `.trim()` before `.min(1)`: the harness rejects whitespace-only
          // content, so letting it through here would only move the failure
          // deeper, after a session has been touched.
          prompt: z.string().trim().min(1).describe('The task or question for the DSH agent.'),
          mode: z
            .enum(['queue', 'steer'])
            .optional()
            .describe('queue (default) runs a new turn; steer delivers into the running turn.'),
          wait: z.boolean().optional().describe('Wait for the turn to settle. Defaults to true.'),
          timeoutMs: z
            .number()
            .int()
            .positive()
            // Capped because each waiting call holds a poll loop that re-reads and
            // replays the whole session log every 200 ms, and the queue only
            // serialises per session — so an uncapped timeout lets a caller keep N
            // loops alive indefinitely. Ten minutes is far beyond any real turn the
            // wait is meant to cover; a caller that genuinely needs longer should
            // poll `session_messages` instead of holding one call open.
            .max(600_000)
            .optional()
            .describe('Upper bound for the wait. Defaults to the endpoint configuration.'),
        }),
        annotations: { openWorldHint: true },
      },
      guard('session_prompt', log, async (args) => ok(await driver.promptSession({
        sessionId: args.sessionId,
        prompt: args.prompt,
        mode: args.mode ?? 'queue',
        wait: args.wait ?? true,
        ...(args.timeoutMs === undefined ? {} : { timeoutMs: args.timeoutMs }),
      }))),
    )

    server.registerTool(
      'session_messages',
      {
        title: 'Read a DSH session transcript',
        description: 'Return the most recent user and assistant messages of one session, oldest first.',
        inputSchema: z.object({
          sessionId: z.string(),
          limit: z.number().int().positive().max(500).optional().describe('Maximum messages to return. Defaults to 50.'),
        }),
        annotations: { readOnlyHint: true, openWorldHint: false },
      },
      guard('session_messages', log, async (args) => ok({
        messages: await driver.readTranscript(args.sessionId, args.limit ?? 50),
      })),
    )

    server.registerTool(
      'session_cancel',
      {
        title: 'Cancel a DSH turn',
        description: 'Ask the agent in this session to stop its current turn. Queued work is preserved.',
        inputSchema: z.object({ sessionId: z.string() }),
        annotations: { openWorldHint: false },
      },
      guard('session_cancel', log, async (args) => ok(driver.cancelSession(args.sessionId))),
    )
  }

  if (enabled.files) {
    server.registerTool(
      'file_read',
      {
        title: 'Read a file through DSH',
        description:
          'Read a UTF-8 text file through this DSH instance\'s filesystem service, so the same path rules and '
          + 'sandboxing the DSH agent uses apply to you. Output is truncated at the configured byte limit.',
        inputSchema: z.object({
          path: z.string().describe('File path; relative paths resolve against cwd.'),
          cwd: z.string().optional().describe('Base directory for a relative path; defaults to the DSH process cwd.'),
        }),
        annotations: { readOnlyHint: true, openWorldHint: false },
      },
      guard('file_read', log, async (args) => ok(await driver.readFile({
        path: args.path,
        ...(args.cwd === undefined ? {} : { cwd: args.cwd }),
        maxBytes: getConfig().limits.maxReadBytes,
      }))),
    )

    server.registerTool(
      'file_write',
      {
        title: 'Write a file through DSH',
        description:
          'Create or replace a UTF-8 text file through this DSH instance\'s filesystem service. The write is '
          + 'atomic. Use this for direct edits; use session_prompt when you want the DSH agent to do the work.',
        inputSchema: z.object({
          path: z.string().describe('File path; relative paths resolve against cwd.'),
          content: z.string().describe('Complete new file content.'),
          cwd: z.string().optional(),
          createDirectories: z
            .boolean()
            .optional()
            .describe(
              'When false, the call fails if the parent directory does not exist instead of '
              + 'creating it. Defaults to true (create it).',
            ),
        }),
        annotations: { openWorldHint: false },
      },
      guard('file_write', log, async (args) => ok(await driver.writeFile({
        path: args.path,
        content: args.content,
        ...(args.cwd === undefined ? {} : { cwd: args.cwd }),
        createDirectories: args.createDirectories ?? true,
      }))),
    )

    server.registerTool(
      'file_list',
      {
        title: 'List a directory through DSH',
        description: 'List one directory level through this DSH instance\'s filesystem service.',
        inputSchema: z.object({
          path: z.string().describe('Directory path; relative paths resolve against cwd.'),
          cwd: z.string().optional(),
        }),
        annotations: { readOnlyHint: true, openWorldHint: false },
      },
      guard('file_list', log, async (args) => ok(await driver.listDirectory({
        path: args.path,
        ...(args.cwd === undefined ? {} : { cwd: args.cwd }),
      }))),
    )
  }

  if (enabled.shell) {
    server.registerTool(
      'shell_run',
      {
        title: 'Run a command through DSH',
        description:
          'Run one shell command through this DSH instance\'s shell service, so the DSH sandbox and permission '
          + 'policy decide what is allowed. Prefer session_prompt when you want the agent to interpret results; '
          + 'use this for deterministic commands.',
        inputSchema: z.object({
          command: z.string().min(1).describe('Command line to run.'),
          cwd: z.string().optional().describe('Working directory; defaults to the shell executor\'s configured directory.'),
          timeoutMs: z.number().int().positive().optional().describe('Timeout in milliseconds.'),
        }),
        annotations: { openWorldHint: true },
      },
      guard('shell_run', log, async (args) => ok(await driver.runShell({
        command: args.command,
        ...(args.cwd === undefined ? {} : { cwd: args.cwd }),
        timeoutMs: args.timeoutMs ?? getConfig().limits.shellTimeoutMs,
      }))),
    )
  }

  if (enabled.agentTools) {
    server.registerTool(
      'dsh_tool_list',
      {
        title: "List this DSH instance's own agent tools",
        description:
          'List the tools one DSH session can run, with the same schema its own agent sees. Only the permitted '
          + 'names are shown; the rest are neither listed nor callable. A sessionId is required because DSH '
          + 'registers tools inside an agent scope — there is no deployment-wide toolbox.',
        inputSchema: z.object({
          sessionId: z.string().min(1)
            .describe('The session whose agent and policy scope the listing. Required.'),
        }),
        annotations: { readOnlyHint: true, openWorldHint: false },
      },
      guard('dsh_tool_list', log, async (args) => ok(await driver.listAgentTools({
        sessionId: args.sessionId,
      }))),
    )

    server.registerTool(
      'dsh_tool_call',
      {
        title: "Run one of this DSH instance's agent tools",
        description:
          'Run a tool from dsh_tool_list directly, through the same pipeline the DSH agent uses — pre-policy, '
          + 'guards, sandbox and approval all still apply — without spending a model turn to decide to call it. '
          + 'Use dsh_tool_list first: a name that is not listed is refused. The call runs as the given '
          + 'session agent, which is what supplies the policy. Prefer session_prompt when the task needs '
          + 'judgement; use this for deterministic calls.',
        inputSchema: z.object({
          name: z.string().trim().min(1).describe('Tool name, exactly as dsh_tool_list reports it.'),
          args: z.record(z.string(), z.unknown()).optional()
            .describe('Arguments object matching the schema that tool reports.'),
          sessionId: z.string().min(1)
            .describe('The session whose agent runs the call, under its policy and working directory. Required.'),
          timeoutMs: z.number().int().positive().max(600_000).optional()
            .describe(
              'Abort the call after this many milliseconds. Defaults to the configured agent '
              + 'tool timeout (limits.agentToolTimeoutMs).',
            ),
        }),
        annotations: { openWorldHint: true },
      },
      guard('dsh_tool_call', log, async (args) => toolOutcome(await driver.callAgentTool({
        name: args.name,
        ...(args.args === undefined ? {} : { args: args.args }),
        sessionId: args.sessionId,
        timeoutMs: args.timeoutMs ?? getConfig().limits.agentToolTimeoutMs,
      }))),
    )
  }
}
