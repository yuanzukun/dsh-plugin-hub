/**
 * v3 contract tests for lib/facts.js — the honesty pass.
 * Each case encodes an attack finding; v2 fails these (red).
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { classifyElement, findOverlaps, renderElementFacts, renderVisualSummary } from '../lib/facts.js';

const VP = { width: 375, height: 812 };

// -- sentinel honesty (reality P1) -------------------------------------------

test('maybeRead sentinels are read-failed, never zero-size or offscreen', () => {
  const el = {
    uid: 'view_0',
    tagName: 'view',
    size: { unavailable: true, code: 'ELEMENT_PROPERTY_TIMEOUT', message: 'timed out' },
    offset: { unavailable: true, code: 'ELEMENT_PROPERTY_TIMEOUT' },
    text: { unavailable: true, code: 'ELEMENT_PROPERTY_TIMEOUT' },
  };
  const c = classifyElement(el, VP);
  assert.equal(c.hasGeometry, false);
  assert.ok(c.flags.includes('read-failed'), `flags must name the read failure, got ${c.flags}`);
  assert.ok(!c.flags.includes('zero-size'), 'a timed-out read is NOT a zero-size fact');
  assert.ok(!c.flags.includes('offscreen'));
  const table = renderElementFacts([el], { viewport: VP });
  assert.ok(!table.includes('[object Object]'), 'sentinel text must not render as [object Object]');
});

// -- viewport honesty (coherence/gaming/reality P2) --------------------------

test('unknown viewport never yields visible; it yields viewport-unknown', () => {
  const el = { uid: 'v9', tagName: 'view', size: { width: 100, height: 40 }, offset: { left: -9999, top: -9999 } };
  for (const vp of [undefined, { windowWidth: 0, windowHeight: 0 }, {}]) {
    const c = classifyElement(el, vp);
    assert.ok(!c.flags.includes('visible') && !c.flags.includes('fully-visible'), `vp=${JSON.stringify(vp)} must not certify visibility`);
    assert.ok(c.flags.includes('viewport-unknown'));
  }
});

test('sysinfo-shaped viewport {windowWidth,windowHeight} is accepted (coherence P2)', () => {
  const el = { uid: 'v1', tagName: 'view', size: { width: 100, height: 40 }, offset: { left: 9999, top: 9999 } };
  const c = classifyElement(el, { windowWidth: 375, windowHeight: 812 });
  assert.ok(c.flags.includes('offscreen'), 'the off-viewport element must be classified with the sysinfo field names');
});

// -- fully-visible vs partial (v4pro P3) -------------------------------------

test('a half-offscreen element is partial, not fully-visible', () => {
  const el = { uid: 'b1', tagName: 'button', size: { width: 200, height: 44 }, offset: { left: 300, top: 100 } }; // right edge 500 > 375
  const c = classifyElement(el, VP);
  assert.ok(c.flags.includes('partial'));
  assert.ok(!c.flags.includes('fully-visible'));
});

// -- containment is the defect, not noise (gaming/reality P1) ----------------

test('a full-screen mask over a button is REPORTED as contained-by, not skipped', () => {
  const mask = classifyElement({ uid: 'mask', tagName: 'view', size: { width: 375, height: 812 }, offset: { left: 0, top: 0 } }, VP);
  const btn = classifyElement({ uid: 'btn', tagName: 'button', size: { width: 200, height: 44 }, offset: { left: 80, top: 700 } }, VP);
  const { pairs } = findOverlaps([mask, btn], { viewport: VP });
  assert.equal(pairs.length, 1, 'the containment pair must be reported');
  assert.equal(pairs[0].kind, 'contained-by');
});

test('overlap section reports dropped pairs instead of silence (gaming P2)', () => {
  // 30 stacked rows produce 29 adjacent intersect pairs; the intersect budget
  // keeps only a handful, so dropped>0 MUST be disclosed. The old assertion
  // here was a vacuous disjunction (its own fix-audit caught it).
  const els = Array.from({ length: 30 }, (_, i) => ({ uid: `r${i}`, tagName: 'view', size: { width: 355, height: 88 }, offset: { left: 10, top: i * 40 } }));
  const out = renderElementFacts(els, { viewport: VP, limit: 30 });
  assert.match(out, /more pair\(s\) dropped by the reporting cap/, 'the dropped-pairs disclosure line must be present when the cap bites');
  // and when nothing is dropped, the disclosure must be absent
  const two = [
    { uid: 'a', tagName: 'view', size: { width: 100, height: 100 }, offset: { left: 0, top: 0 } },
    { uid: 'b', tagName: 'view', size: { width: 100, height: 100 }, offset: { left: 50, top: 50 } },
  ];
  const outTwo = renderElementFacts(two, { viewport: VP });
  assert.ok(!/dropped by the reporting cap/.test(outTwo), 'no false disclosure when nothing was dropped');
});

// -- budgets in code (coherence/gaming/v4pro P2) -----------------------------

test('renderElementFacts enforces a byte clamp with an explicit truncation note', () => {
  const els = Array.from({ length: 60 }, (_, i) => ({
    uid: `view_${i}`, tagName: 'view',
    text: '连续扫码器立刻开始简单扫码常用模板编辑分组上次使用快速标注入库标识文本标注'.repeat(2),
    size: { width: 120 + i, height: 44 }, offset: { left: 10, top: 20 * i },
  }));
  const out = renderElementFacts(els, { viewport: VP, limit: 60 });
  assert.ok(Buffer.byteLength(out, 'utf8') <= 4096, `output must clamp ≤4096 bytes, got ${Buffer.byteLength(out, 'utf8')}`);
  assert.ok(/truncated|截断/i.test(out), 'the clamp must be disclosed in the output');
});

test('default row limit is 15 and elementCount is rendered (v4pro P3)', () => {
  const els = Array.from({ length: 40 }, (_, i) => ({ uid: `v${i}`, tagName: 'view', text: 'x', size: { width: 10, height: 10 }, offset: { left: 0, top: i * 12 } }));
  const out = renderElementFacts(els, { viewport: VP });
  assert.ok(out.includes('elementCount=40') || /elementCount[:=] ?40/.test(out), 'elementCount must be present');
  const rows = out.split('\n').filter((l) => l.startsWith('v')).length;
  assert.ok(rows <= 15, `default must render ≤15 rows, got ${rows}`);
});

// -- screenshot disclosure (coherence P3) ------------------------------------

test('renderVisualSummary discloses the not-in-context PNG whenever imageVisible is not true', () => {
  for (const iv of [false, undefined]) {
    const out = renderVisualSummary({ route: '/p', viewport: VP, elements: [], screenshotPath: '/tmp/a.png', imageVisible: iv });
    assert.ok(/不在你的上下文|NOT in context|not in context/i.test(out), `imageVisible=${iv} must disclose`);
  }
  const withImage = renderVisualSummary({ route: '/p', viewport: VP, elements: [], screenshotPath: '/tmp/a.png', imageVisible: true });
  assert.ok(!/不在你的上下文|NOT in context/i.test(withImage));
});

// -- fix-audit R2 regressions ------------------------------------------------

test('R2-P1: a mask BEYOND the rendered rows is still reported (analysis covers all elements)', () => {
  // 39 content rows, button at index 5, full-screen mask LAST (where WXML puts overlays)
  const els = [
    ...Array.from({ length: 39 }, (_, i) => ({ uid: `row${i}`, tagName: 'view', size: { width: 355, height: 20 }, offset: { left: 10, top: i * 20 } })),
  ];
  els.splice(5, 0, { uid: 'btn_submit', tagName: 'button', size: { width: 200, height: 44 }, offset: { left: 80, top: 700 } });
  els.push({ uid: 'loading_mask', tagName: 'view', size: { width: 375, height: 812 }, offset: { left: 0, top: 0 } });
  const out = renderElementFacts(els, { viewport: VP }); // default limit 15 — mask is far beyond it
  assert.ok(out.includes('contained-by loading_mask'), `the mask pair must be reported even though the mask is not a rendered row:\n${out.slice(0, 400)}`);
  assert.ok(/btn_submit contained-by loading_mask/.test(out), 'the covered BUTTON must be among the reported inner elements');
});

test('R2-P1: offscreen boxes cannot starve the overlap budget', () => {
  const els = [
    { uid: 'mask', tagName: 'view', size: { width: 375, height: 812 }, offset: { left: 0, top: 0 } },
    { uid: 'btn', tagName: 'button', size: { width: 200, height: 44 }, offset: { left: 80, top: 700 } },
    // 12 large mutually-overlapping OFFSCREEN views
    ...Array.from({ length: 12 }, (_, i) => ({ uid: `off${i}`, tagName: 'view', size: { width: 900, height: 900 }, offset: { left: 2000, top: 2000 + i * 10 } })),
  ];
  const classified = els.map((e) => classifyElement(e, VP));
  const { pairs } = findOverlaps(classified);
  assert.ok(pairs.some((p) => p.kind === 'contained-by' && p.inner === 'btn' && p.outer === 'mask'), 'mask/btn must survive; offscreen noise must not consume the slots');
});

test('R2-P3: null geometry is no-geometry, not a fabricated 0x0 box', () => {
  const c = classifyElement({ uid: 'x', size: { width: null, height: null }, offset: { left: null, top: null } }, VP);
  assert.equal(c.hasGeometry, false);
  assert.ok(c.flags.includes('no-geometry'));
  assert.ok(!c.flags.includes('zero-size'));
});
