/**
 * The in-repo harness for lib/index.js — the 0.1.0 audits' top residual gap
 * (every P1 of the fix-audit round lived in this then-untested file).
 *
 * Runs against the REAL host packages (linked by scripts/link-host.mjs from
 * the installed dsh); on a machine without dsh it self-skips loudly rather
 * than faking a pass.
 *
 * The fake exec replays RESPONSE SHAPES captured from vince-mp-cli 0.2.0
 * live probes (docs/ATTACK-LEDGER.md) — not convenient inventions; that
 * lesson cost a P1 (the suite that couldn't see the real execFile shape).
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

let mod;
try {
  mod = await import('../lib/index.js');
} catch (error) {
  // Self-skip ONLY for the absent-host case; anything else (a syntax error,
  // a broken non-host import) must fail the suite loudly — a broad catch here
  // would be the exact S2 silent-skip pattern this project's audits ban.
  const hostMissing = error?.code === 'ERR_MODULE_NOT_FOUND' && /@deepseek-ai\//.test(String(error?.message ?? ''));
  if (!hostMissing) throw error;
  test('index.js harness SKIPPED — @deepseek-ai host packages unavailable on this machine', { skip: 'install dsh or run scripts/link-host.mjs against a dsh home' }, () => {});
}

const ok = (doc) => JSON.stringify({ ok: true, ...doc });
const CAPABILITIES = ok({ command: 'capabilities', package: { name: 'vince-mp-cli', version: '0.2.0', backend: 'miniprogram-automator' }, commands: [], shorthands: [], workflowSteps: ['tap'], importantErrors: [] });
const SYSINFO = ok({ command: 'sysinfo', via: 'session', result: { value: { platform: 'devtools', model: 'iPhone', windowWidth: 375, windowHeight: 812, pixelRatio: 3, SDKVersion: '3.16.1' } } });
const PAGE = ok({ command: 'page', via: 'session', result: { path: 'pages/home/index', query: {} } });

/** Build a fake ctx capturing registered tool definitions. */
function fakeCtx(services = {}) {
  const defs = [];
  return {
    defs,
    tools: { register: (d) => defs.push(d) },
    logger: { info: () => {}, warn: () => {} },
    get: (name) => services[name],
  };
}

/** Route a fake CLI: map argv[0] (or argv[0]+marker) to a response supplier. */
function fakeExec(routes) {
  const calls = [];
  const fn = async (bin, argv, opts) => {
    calls.push(argv);
    const key = argv[0] === 'step' ? `step:${JSON.parse(argv[1]).type}` : argv[0];
    const supplier = routes[key];
    if (!supplier) throw Object.assign(new Error(`no fake route for ${key}`), { code: 1, stdout: '', stderr: JSON.stringify({ ok: false, command: argv[0], code: 'UNSUPPORTED_COMMAND', message: `fake: ${key}` }) });
    const out = typeof supplier === 'function' ? supplier(argv, calls) : supplier;
    return { stdout: out, stderr: '' };
  };
  fn.calls = calls;
  return fn;
}

/** apply() into a fake ctx with an injected exec; returns {defs, tool(name)}. */
function mount(routes, services = {}, config = {}) {
  const ctx = fakeCtx(services);
  mod.apply(ctx, { _exec: fakeExec(routes), ...config });
  return { ctx, tool: (n) => ctx.defs.find((d) => d.name === n) };
}

const AGENT = (cwd) => ({ agent: { session: { header: { cwd }, requestHeader: () => undefined }, options: {} }, signal: undefined });

if (mod) {
  const CWD = mkdtempSync(join(tmpdir(), 'mp-harness-'));

  test('apply registers exactly the 8 documented tools', () => {
    const { ctx } = mount({});
    assert.deepEqual(
      ctx.defs.map((d) => d.name).sort(),
      ['mp_act', 'mp_console', 'mp_doctor', 'mp_eval', 'mp_inspect', 'mp_query', 'mp_screenshot', 'mp_session'].sort(),
    );
  });

  test('every tool declares exclusivity EXPLICITLY (not by host default)', () => {
    const { ctx } = mount({});
    for (const d of ctx.defs) {
      assert.equal(typeof d.isConcurrencySafe, 'function', `${d.name} must declare isConcurrencySafe`);
      assert.equal(d.isConcurrencySafe(), false, `${d.name} must be explicitly exclusive`);
    }
  });

  test('no-cwd refusal renders its remedy (guarded covers the cwd gate)', async () => {
    const { tool } = mount({});
    await assert.rejects(
      tool('mp_inspect').execute({ mode: 'page' }, { agent: undefined, signal: undefined }),
      (e) => /project\.config\.json/.test(e.message),
      'the remedy must reach the model, not just the complaint',
    );
  });

  test('G1: stale doctor blocks mp_act with the rebuild remedy', async () => {
    const routes = {
      capabilities: CAPABILITIES,
      doctor: ok({ command: 'doctor', checks: { project: { ok: true }, typecheck: { ran: false, ok: null }, jsFreshness: { checked: 4, staleCount: 2, stale: ['a.js'] } } }),
    };
    const { tool } = mount(routes);
    await assert.rejects(
      tool('mp_act').execute({ action: 'tap', selector: '.x' }, AGENT(CWD)),
      (e) => /refusing to act/.test(e.message) && /rebuild/.test(e.message),
    );
  });

  test('G1: no-signal proceeds WITH the warning prefix', async () => {
    const routes = {
      capabilities: CAPABILITIES,
      doctor: ok({ command: 'doctor', checks: { project: { ok: true }, typecheck: { ran: false, ok: null }, jsFreshness: { checked: 0, staleCount: 0, stale: [] } } }),
      query: ok({ command: 'query', via: 'session', result: { selector: '.x', count: 1, elements: [{ uid: 'view_0', tagName: 'view' }] } }),
      tap: ok({ command: 'tap', via: 'session', result: {} }),
      page: PAGE,
    };
    const { tool } = mount(routes);
    const value = await tool('mp_act').execute({ action: 'tap', selector: '.x' }, AGENT(CWD));
    assert.match(value.summary, /freshness UNKNOWN/, 'the mandatory warning line must lead the result');
    assert.match(value.summary, /tap on \.x\[0\]/);
  });

  test('mp_act selector-miss refuses with the anti-guess remedy', async () => {
    const routes = {
      capabilities: CAPABILITIES,
      doctor: ok({ command: 'doctor', checks: { project: { ok: true }, jsFreshness: { checked: 3, staleCount: 0, stale: [] }, typecheck: { ran: false, ok: null } } }),
      query: ok({ command: 'query', via: 'session', result: { selector: '.gone', count: 0, elements: [] } }),
    };
    const { tool } = mount(routes);
    await assert.rejects(
      tool('mp_act').execute({ action: 'tap', selector: '.gone' }, AGENT(CWD)),
      (e) => /matched nothing/.test(e.message) && /do not guess/.test(e.message),
    );
  });

  test('mp_console walks EVERY page to the tail (no ≤2000 assumption)', async () => {
    // total=2500 across three pages: errors only on the LAST page — the 0.1.0
    // implementation stopped after pageIdx 1 and would miss them.
    const mkEntries = (start, n, type = 'log') => Array.from({ length: n }, (_, i) => ({ type, text: `e${start + i}` }));
    const routes = {
      capabilities: CAPABILITIES,
      console: ok({ command: 'console', via: 'session', result: { installed: true, total: 2500, pageIdx: 0, pageSize: 1000, entries: mkEntries(0, 1000) } }),
      'step:listConsole': (argv) => {
        const req = JSON.parse(argv[1]);
        return req.pageIdx === 1
          ? ok({ command: 'step', via: 'session', result: { total: 2500, pageIdx: 1, entries: mkEntries(1000, 1000) } })
          : ok({ command: 'step', via: 'session', result: { total: 2500, pageIdx: 2, entries: [...mkEntries(2000, 480), ...mkEntries(2480, 20, 'error')] } });
      },
    };
    const { tool } = mount(routes);
    const value = await tool('mp_console').execute({}, AGENT(CWD));
    assert.match(value.summary, /total=2500/);
    assert.match(value.summary, /errors=20/, 'errors on the final page must be counted');
    assert.match(value.summary, /e2499/, 'the true tail must be shown');
  });

  test('scroll-aware visibility: a below-fold element is fully-visible AFTER scrolling to it', async () => {
    const routes = {
      capabilities: CAPABILITIES,
      query: ok({ command: 'query', via: 'session', result: { selector: '.deep', count: 1, elements: [{ uid: 'view_9', tagName: 'view', text: 'deep', size: { width: 200, height: 44 }, offset: { left: 10, top: 900 } }] } }),
      sysinfo: SYSINFO,
      'step:scrollTop': ok({ command: 'step', via: 'session', result: { value: 800, truncated: false } }),
    };
    const { tool } = mount(routes);
    const value = await tool('mp_query').execute({ selector: '.deep' }, AGENT(CWD));
    assert.match(value.summary, /fully-visible/, 'top:900 with scrollTop:800/height:812 is inside the scroll window');
    assert.match(value.summary, /scroll(ed)?[=: ]?800|scrollTop.?800/i, 'the scroll position must be disclosed');
  });

  test('mp_session status reads the running field honestly', async () => {
    const routes = {
      capabilities: CAPABILITIES,
      session: ok({ command: 'session', action: 'status', running: false }),
    };
    const { tool } = mount(routes);
    const value = await tool('mp_session').execute({ action: 'status' }, AGENT(CWD));
    assert.match(value.summary, /NOT running/);
  });

  test('mp_screenshot attaches the image only when the route declares image input', async () => {
    const png = join(CWD, 'captures', 'probe.png');
    const routes = {
      capabilities: CAPABILITIES,
      doctor: ok({ command: 'doctor', checks: { project: { ok: true }, jsFreshness: { checked: 3, staleCount: 0, stale: [] }, typecheck: { ran: false, ok: null } } }),
      shot: (argv) => { writeFileSync(png, Buffer.from([137, 80, 78, 71])); return ok({ command: 'shot', via: 'session', result: { output: png, sideEffects: ['write-file'] } }); },
      page: PAGE,
      sysinfo: SYSINFO,
      snapshot: ok({ command: 'snapshot', via: 'session', result: { path: 'pages/home/index', elementCount: 0, returnedCount: 0, elements: [] } }),
      'step:scrollTop': ok({ command: 'step', via: 'session', result: { value: 0 } }),
    };
    const services = {
      attachments: {
        imageLimits: { mediaTypes: ['image/png'], maxImageBytes: 10_000_000, maxMessageImageBytes: 10_000_000 },
        saveImage: async ({ data, mediaType, name }) => ({ attachmentId: 'att-fake-1', mediaType, bytes: data.length, width: 1, height: 1, name }),
      },
      llm: { resolveModelInfo: async () => ({ inputModalities: ['text', 'image'] }) },
    };
    const agentWithRoute = { agent: { session: { header: { cwd: CWD }, requestHeader: () => ({ config: { provider: 'p', model: 'm' } }) }, options: {} }, signal: undefined };
    const { tool } = mount(routes, services);
    const value = await tool('mp_screenshot').execute({ name: 'probe' }, agentWithRoute);
    assert.match(value.summary, /<imageStatus>attached \(1\/3 image budget\)<\/imageStatus>/);
    assert.equal(value.image?.attachmentId, 'att-fake-1');

    // and the text-only route degrades with the honest note
    const servicesText = { ...services, llm: { resolveModelInfo: async () => ({ inputModalities: ['text'] }) } };
    const m2 = mount(routes, servicesText);
    const v2 = await m2.tool('mp_screenshot').execute({ name: 'probe' }, agentWithRoute);
    assert.match(v2.summary, /declares \[text\] — no image input/);
    assert.match(v2.summary, /NOT in context/);
    assert.equal(v2.image, undefined);
  });

  test('image economy: identical screenshots are not re-attached and do not burn budget', async () => {
    const png = join(CWD, 'captures', 'econ.png');
    let variant = 1;
    const routes = {
      capabilities: CAPABILITIES,
      doctor: ok({ command: 'doctor', checks: { project: { ok: true }, jsFreshness: { checked: 3, staleCount: 0, stale: [] }, typecheck: { ran: false, ok: null } } }),
      shot: () => { writeFileSync(png, Buffer.from([137, 80, 78, 71, variant])); return ok({ command: 'shot', via: 'session', result: { output: png } }); },
      page: PAGE,
      sysinfo: SYSINFO,
      snapshot: ok({ command: 'snapshot', via: 'session', result: { path: 'p', elementCount: 0, returnedCount: 0, elements: [] } }),
      'step:scrollTop': ok({ command: 'step', via: 'session', result: { value: 0 } }),
    };
    const services = {
      attachments: { imageLimits: { mediaTypes: ['image/png'], maxImageBytes: 1e7, maxMessageImageBytes: 1e7 }, saveImage: async ({ data }) => ({ attachmentId: 'a1', mediaType: 'image/png', bytes: data.length, width: 1, height: 1 }) },
      llm: { resolveModelInfo: async () => ({ inputModalities: ['text', 'image'] }) },
    };
    const agent = { agent: { session: { header: { cwd: CWD }, requestHeader: () => ({ config: { provider: 'p', model: 'm' } }) }, options: {} }, signal: undefined };
    const { tool } = mount(routes, services);
    const first = await tool('mp_screenshot').execute({ name: 'econ' }, agent);
    assert.match(first.summary, /attached \(1\/3/);
    const second = await tool('mp_screenshot').execute({ name: 'econ' }, agent);
    assert.equal(second.image, undefined, 'an identical screen must not re-attach');
    assert.match(second.summary, /NOT re-attached/);
    assert.match(second.summary, /deliberately not attached/, 'economy skip must not read as a failure');
    const third = await tool('mp_screenshot').execute({ name: 'econ' }, agent);
    assert.match(third.summary, /NOT re-attached/);
    // The non-vacuous half (fix-audit: the old test passed even when dupes DID
    // burn budget): after two dedupe skips a CHANGED screen must land at 2/3 —
    // if dedupes consumed budget this would read 4/3 or exhausted.
    variant = 2;
    const fourth = await tool('mp_screenshot').execute({ name: 'econ' }, agent);
    assert.match(fourth.summary, /attached \(2\/3/, 'dupes must not have consumed budget');
  });

  test('image economy: state is per-SESSION — a fresh session in the same cwd is never told an image it lacks is in its context', async () => {
    const png = join(CWD, 'captures', 'xsess.png');
    const routes = {
      capabilities: CAPABILITIES,
      doctor: ok({ command: 'doctor', checks: { project: { ok: true }, jsFreshness: { checked: 3, staleCount: 0, stale: [] }, typecheck: { ran: false, ok: null } } }),
      shot: () => { writeFileSync(png, Buffer.from([137, 80, 78, 71, 9])); return ok({ command: 'shot', via: 'session', result: { output: png } }); },
      page: PAGE,
      sysinfo: SYSINFO,
      snapshot: ok({ command: 'snapshot', via: 'session', result: { path: 'p', elementCount: 0, returnedCount: 0, elements: [] } }),
      'step:scrollTop': ok({ command: 'step', via: 'session', result: { value: 0 } }),
    };
    const services = {
      attachments: { imageLimits: { mediaTypes: ['image/png'], maxImageBytes: 1e7, maxMessageImageBytes: 1e7 }, saveImage: async ({ data }) => ({ attachmentId: 'a1', mediaType: 'image/png', bytes: data.length, width: 1, height: 1 }) },
      llm: { resolveModelInfo: async () => ({ inputModalities: ['text', 'image'] }) },
    };
    const sessionA = { agent: { session: { header: { cwd: CWD }, requestHeader: () => ({ config: { provider: 'p', model: 'm' } }) }, options: {} }, signal: undefined };
    const sessionB = { agent: { session: { header: { cwd: CWD }, requestHeader: () => ({ config: { provider: 'p', model: 'm' } }) }, options: {} }, signal: undefined };
    const { tool } = mount(routes, services); // ONE plugin instance, two sessions — the dsh host mainline
    const a = await tool('mp_screenshot').execute({ name: 'xsess' }, sessionA);
    assert.match(a.summary, /attached \(1\/3/);
    const b = await tool('mp_screenshot').execute({ name: 'xsess' }, sessionB);
    assert.ok(b.image, 'session B took the identical screen but its context has NO image — it must get a real attach');
    assert.match(b.summary, /attached \(1\/3/, 'session B budget starts fresh');
    assert.ok(!/NOT re-attached/.test(b.summary), 'the cross-session dedupe lie is the P1 this test pins');
  });

  test('image economy: imageBudget edges — 0 disables with a deliberate message, junk falls back to the default', async () => {
    const png = join(CWD, 'captures', 'edge.png');
    const routes = {
      capabilities: CAPABILITIES,
      doctor: ok({ command: 'doctor', checks: { project: { ok: true }, jsFreshness: { checked: 3, staleCount: 0, stale: [] }, typecheck: { ran: false, ok: null } } }),
      shot: () => { writeFileSync(png, Buffer.from([137, 80, 78, 71, 7])); return ok({ command: 'shot', via: 'session', result: { output: png } }); },
      page: PAGE,
      sysinfo: SYSINFO,
      snapshot: ok({ command: 'snapshot', via: 'session', result: { path: 'p', elementCount: 0, returnedCount: 0, elements: [] } }),
      'step:scrollTop': ok({ command: 'step', via: 'session', result: { value: 0 } }),
    };
    const services = {
      attachments: { imageLimits: { mediaTypes: ['image/png'], maxImageBytes: 1e7, maxMessageImageBytes: 1e7 }, saveImage: async ({ data }) => ({ attachmentId: 'a1', mediaType: 'image/png', bytes: data.length, width: 1, height: 1 }) },
      llm: { resolveModelInfo: async () => ({ inputModalities: ['text', 'image'] }) },
    };
    const agent = () => ({ agent: { session: { header: { cwd: CWD }, requestHeader: () => ({ config: { provider: 'p', model: 'm' } }) }, options: {} }, signal: undefined });
    const zero = await mount(routes, services, { imageBudget: 0 }).tool('mp_screenshot').execute({ name: 'edge' }, agent());
    assert.equal(zero.image, undefined);
    assert.match(zero.summary, /image attaching disabled by configuration/);
    assert.match(zero.summary, /deliberately not attached/, 'budget 0 is economy, not failure');
    const nan = await mount(routes, services, { imageBudget: Number.NaN }).tool('mp_screenshot').execute({ name: 'edge' }, agent());
    assert.match(nan.summary, /attached \(1\/3/, 'NaN must fall back to the default, never unbounded');
    const neg = await mount(routes, services, { imageBudget: -2 }).tool('mp_screenshot').execute({ name: 'edge' }, agent());
    assert.equal(neg.image, undefined, 'negative clamps to 0 = disabled');
    assert.match(neg.summary, /image attaching disabled by configuration/);
  });

  test('image economy: the budget exhausts and degrades with the honest token warning', async () => {
    const png = join(CWD, 'captures', 'budget.png');
    let n = 0;
    const routes = {
      capabilities: CAPABILITIES,
      doctor: ok({ command: 'doctor', checks: { project: { ok: true }, jsFreshness: { checked: 3, staleCount: 0, stale: [] }, typecheck: { ran: false, ok: null } } }),
      shot: () => { n += 1; writeFileSync(png, Buffer.from([137, 80, 78, 71, n])); return ok({ command: 'shot', via: 'session', result: { output: png } }); },
      page: PAGE,
      sysinfo: SYSINFO,
      snapshot: ok({ command: 'snapshot', via: 'session', result: { path: 'p', elementCount: 0, returnedCount: 0, elements: [] } }),
      'step:scrollTop': ok({ command: 'step', via: 'session', result: { value: 0 } }),
    };
    const services = {
      attachments: { imageLimits: { mediaTypes: ['image/png'], maxImageBytes: 1e7, maxMessageImageBytes: 1e7 }, saveImage: async ({ data }) => ({ attachmentId: `a${n}`, mediaType: 'image/png', bytes: data.length, width: 1, height: 1 }) },
      llm: { resolveModelInfo: async () => ({ inputModalities: ['text', 'image'] }) },
    };
    const agent = { agent: { session: { header: { cwd: CWD }, requestHeader: () => ({ config: { provider: 'p', model: 'm' } }) }, options: {} }, signal: undefined };
    const { tool } = mount(routes, services, { imageBudget: 2 });
    const r1 = await tool('mp_screenshot').execute({ name: 'budget' }, agent);
    assert.match(r1.summary, /attached \(1\/2/);
    const r2 = await tool('mp_screenshot').execute({ name: 'budget' }, agent);
    assert.match(r2.summary, /attached \(2\/2/);
    const r3 = await tool('mp_screenshot').execute({ name: 'budget' }, agent);
    assert.equal(r3.image, undefined);
    assert.match(r3.summary, /image budget exhausted \(2\/2/);
    assert.match(r3.summary, /billing on all later requests/, 'the WHY must be in the message');
  });

  test('G1 has no cache window: a doctor that turns stale between two acts blocks the second', async () => {
    let staleCount = 0;
    const routes = {
      capabilities: CAPABILITIES,
      doctor: () => ok({ command: 'doctor', checks: { project: { ok: true }, typecheck: { ran: false, ok: null }, jsFreshness: { checked: 4, staleCount, stale: staleCount ? ['x.js'] : [] } } }),
      query: ok({ command: 'query', via: 'session', result: { selector: '.x', count: 1, elements: [{ uid: 'v0', tagName: 'view' }] } }),
      tap: ok({ command: 'tap', via: 'session', result: {} }),
      page: PAGE,
    };
    const { tool } = mount(routes);
    await tool('mp_act').execute({ action: 'tap', selector: '.x' }, AGENT(CWD)); // fresh → passes
    staleCount = 2; // the build goes stale IMMEDIATELY after
    await assert.rejects(
      tool('mp_act').execute({ action: 'tap', selector: '.x' }, AGENT(CWD)),
      (e) => /refusing to act/.test(e.message),
      'the very next act must see the stale build — no TTL window',
    );
  });
}
