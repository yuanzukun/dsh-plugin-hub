/**
 * v3 contract tests for lib/gates.js — the four-state freshness gate.
 * Each case encodes an attack finding; v2 fails these (red).
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { evaluateFreshness, routeKeyOf } from '../lib/gates.js';

// -- evaluateFreshness: fail-closed + four states ----------------------------

test('missing/empty/failed doctor docs are doctor-failed, never "fresh" (coherence+gaming+reality P1)', () => {
  for (const doc of [undefined, null, {}, { checks: undefined }, { ok: false, code: 'INVALID_PROJECT' }]) {
    const v = evaluateFreshness(doc, { mode: 'block' });
    assert.equal(v.state, 'doctor-failed', `${JSON.stringify(doc)} → doctor-failed`);
    assert.equal(v.ok, false, 'block mode must refuse');
    assert.ok(!/build is fresh/i.test(v.reason), 'must not claim freshness it never saw');
    assert.ok(v.remedy, 'must carry a remedy');
  }
});

test('shorthand-wrapped {result:{checks}} shape is unwrapped, not misread as fresh (reality P1)', () => {
  const v = evaluateFreshness({ ok: true, result: { checks: { jsFreshness: { checked: 4, staleCount: 2, stale: ['a.js'] } } } }, { mode: 'block' });
  assert.equal(v.state, 'stale');
  assert.equal(v.ok, false);
});

test('JS-only / no-tsconfig projects are no-signal with a warning — not fake fresh (reality P1: no gradient)', () => {
  // real doctor shape for a JS-only project: typecheck never ran, zero ts/js pairs checked
  const doc = { ok: true, checks: { project: { ok: true }, typecheck: { ran: false, ok: null }, jsFreshness: { checked: 0, staleCount: 0, stale: [] } } };
  const v = evaluateFreshness(doc, { mode: 'block' });
  assert.equal(v.state, 'no-signal');
  assert.equal(v.ok, true, 'no-signal proceeds');
  assert.ok(v.warning, 'must carry the mandatory warning line');
  assert.ok(!/build is fresh/i.test(v.reason), '"fresh" wording is banned without evidence');
});

test('fresh requires checked>0 and staleCount===0', () => {
  const doc = { ok: true, checks: { project: { ok: true }, typecheck: { ran: true, ok: true, exitCode: 0 }, jsFreshness: { checked: 12, staleCount: 0, stale: [] } } };
  const v = evaluateFreshness(doc, { mode: 'block' });
  assert.equal(v.state, 'fresh');
  assert.equal(v.ok, true);
  assert.equal(v.warning, undefined);
});

test('stale blocks in block mode with a rebuild remedy that survives other problems (reality P3: remedy overwrite)', () => {
  const doc = { ok: true, checks: { project: { ok: true }, typecheck: { ran: true, ok: false, exitCode: 2 }, jsFreshness: { checked: 9, staleCount: 3, stale: ['a.js', 'b.js', 'c.js'] } } };
  const v = evaluateFreshness(doc, { mode: 'block' });
  assert.equal(v.state, 'stale');
  assert.equal(v.ok, false);
  assert.ok(/rebuild|重建|重新编译/i.test(v.remedy), `remedy must mention rebuilding, got: ${v.remedy}`);
});

test('tsc timeout (exitCode null) is reported as a timeout, not as type errors (reality P3)', () => {
  const doc = { ok: true, checks: { project: { ok: true }, typecheck: { ran: true, ok: false, exitCode: null }, jsFreshness: { checked: 5, staleCount: 0, stale: [] } } };
  const v = evaluateFreshness(doc, { mode: 'block' });
  assert.equal(v.state, 'stale');
  assert.ok(/timeout|超时/i.test(v.reason), `reason must name the timeout, got: ${v.reason}`);
  assert.ok(!/fix the type errors/i.test(v.remedy ?? ''), 'must not send the reader to a nonexistent error list');
});

test('warn mode proceeds but keeps the warning visible; off mode says disabled, not fresh', () => {
  const stale = { ok: true, checks: { jsFreshness: { checked: 3, staleCount: 1, stale: ['x.js'] } } };
  const warn = evaluateFreshness(stale, { mode: 'warn' });
  assert.equal(warn.ok, true);
  assert.ok(warn.warning, 'warn mode must surface the problem in the result');
  const off = evaluateFreshness(stale, { mode: 'off' });
  assert.equal(off.ok, true);
  assert.ok(/disabled|关闭/i.test(off.reason));
  assert.ok(!/fresh/i.test(off.reason));
});

// -- routeKeyOf --------------------------------------------------------------

test('routeKeyOf is key-order insensitive (reality P3)', () => {
  const a = routeKeyOf({ path: 'pages/a/a', query: { id: '1', from: 'home' } });
  const b = routeKeyOf({ path: 'pages/a/a', query: { from: 'home', id: '1' } });
  assert.equal(a, b);
});

test('routeKeyOf: unknown route is undefined (callers must treat as un-provable, not stable)', () => {
  assert.equal(routeKeyOf({}), undefined);
  assert.equal(routeKeyOf(undefined), undefined);
});
