/**
 * v3 contract tests for lib/cli.js.
 *
 * Every case here encodes an attack-round finding; the v2 module fails them
 * (red), the v3 rewrite must pass. Finding tags reference .attack/r1-ledger.md
 * in the development repo.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildArgs, parseResponse, createCli, probeCapabilities, MP_CODES, MpCliError } from '../lib/cli.js';

// -- buildArgs ---------------------------------------------------------------

test('buildArgs: dash-leading positionals travel after `--` (reality P2: parseArgs strict)', () => {
  const argv = buildArgs('eval', ['-1 + this.data.total']);
  const sep = argv.indexOf('--');
  assert.ok(sep !== -1, 'a `--` separator must be present');
  assert.ok(argv.indexOf('-1 + this.data.total') > sep, 'the expression must sit after `--`');
  assert.ok(argv.includes('--json'), '--json must still be a real flag');
  assert.ok(argv.indexOf('--json') < sep, '--json must sit in the flag region, before `--`');
});

test('buildArgs: a positional that literally equals --json does not suppress the flag (coherence P3)', () => {
  const argv = buildArgs('eval', ['--json']);
  const sep = argv.indexOf('--');
  const flagJson = argv.findIndex((a, i) => a === '--json' && i < sep);
  assert.ok(flagJson !== -1, 'the real --json flag must exist before `--`');
  assert.ok(argv.lastIndexOf('--json') > sep, 'the positional --json must sit after `--`');
});

test('buildArgs: plain positionals stay in command position', () => {
  const argv = buildArgs('query', ['.submit-btn'], { position: true });
  assert.deepEqual(argv[0], 'query');
  assert.ok(argv.includes('.submit-btn'));
  assert.ok(argv.includes('--position'));
});

// -- parseResponse (fail-closed) --------------------------------------------

test('parseResponse: only strict ok === true is success (gaming P2 fail-open)', () => {
  for (const bad of ['{"ok":"false","code":"BOOM"}', '{"checks":{}}', 'null', '42', '"ok"', '[]']) {
    assert.throws(
      () => parseResponse(bad, '', 'doctor'),
      (e) => e instanceof MpCliError && e.code === MP_CODES.BAD_OUTPUT,
      `input ${bad} must be refused as MP_BAD_OUTPUT`,
    );
  }
  const doc = parseResponse('{"ok":true,"command":"page","result":{}}', '', 'page');
  assert.equal(doc.ok, true);
});

test('parseResponse: structured ok:false carries the CLI code and suggestions through', () => {
  try {
    parseResponse(JSON.stringify({ ok: false, command: 'tap', code: 'STALE_OR_UNKNOWN_UID', message: 'stale', suggestions: ['re-query'] }), '', 'tap');
    assert.fail('should throw');
  } catch (e) {
    assert.equal(e.code, 'STALE_OR_UNKNOWN_UID');
    assert.deepEqual(e.suggestions, ['re-query']);
  }
});

test('parseResponse: falls back to STDERR JSON — the CLI writes thrown errors there (reality P1)', () => {
  const stderrDoc = JSON.stringify({ ok: false, command: 'tap', code: 'AUTOMATION_PORT_TIMEOUT', message: 'port never came up', suggestions: ['enable DevTools automation'] });
  try {
    parseResponse('', stderrDoc, 'tap');
    assert.fail('should throw the structured error');
  } catch (e) {
    assert.equal(e.code, 'AUTOMATION_PORT_TIMEOUT', 'code must come from the stderr document');
    assert.deepEqual(e.suggestions, ['enable DevTools automation']);
  }
});

// -- invoke ------------------------------------------------------------------

test('invoke: timeouts are never swallowed into success (gaming P2)', async () => {
  const cli = createCli({
    cwd: '/tmp',
    exec: async () => {
      const e = new Error('Command timed out after 120000 ms');
      e.killed = true;
      e.stdout = '{"ok":true,"command":"tap","result":{"tapped":"view_0"}}';
      e.stderr = '';
      throw e;
    },
  });
  await assert.rejects(
    cli.invoke('tap', ['view_0']),
    (e) => e instanceof MpCliError && e.code === MP_CODES.TIMEOUT,
    'a killed/timed-out process must surface MP_TIMEOUT even when stdout holds JSON',
  );
});

test('invoke: missing binary is MP_CLI_NOT_INSTALLED, never the CLI\'s own WECHAT_CLI_NOT_FOUND (coherence P2)', async () => {
  for (const err of [
    Object.assign(new Error('spawn vince-mp ENOENT'), { code: 'ENOENT' }),
    new Error('subprocess-local: command "vince-mp" was not found on PATH'), // seam shape: no .code (reality P1)
  ]) {
    const cli = createCli({ cwd: '/tmp', exec: async () => { throw err; } });
    await assert.rejects(
      cli.invoke('doctor'),
      (e) => e.code === MP_CODES.NOT_INSTALLED && /npm i -g vince-mp-cli/.test(e.toModelText()),
    );
  }
});

test('invoke: a thrown exec error with a structured stderr doc surfaces that doc', async () => {
  const cli = createCli({
    cwd: '/tmp',
    exec: async () => {
      const e = new Error('exit 1');
      e.stdout = '';
      e.stderr = JSON.stringify({ ok: false, command: 'session', code: 'APP_NOT_RUNNING', message: 'no current page', suggestions: ['check the build'] });
      throw e;
    },
  });
  await assert.rejects(cli.invoke('session', ['status']), (e) => e.code === 'APP_NOT_RUNNING');
});

// -- probeCapabilities (G4) --------------------------------------------------

const capDoc = (pkg) => JSON.stringify({ ok: true, command: 'capabilities', package: pkg, commands: ['doctor'], shorthands: ['page'], workflowSteps: ['tap', 'longpress'], importantErrors: ['APP_NOT_RUNNING'] });

test('probeCapabilities: enforces name and semver window (coherence P2: v2 checked nothing)', async () => {
  const cases = [
    [{ name: 'some-other-cli', version: '9.9.9' }, false],
    [{ name: 'vince-mp-cli', version: '0.1.9' }, false],
    [{ name: 'vince-mp-cli', version: '0.3.0' }, false],
    [{ name: 'vince-mp-cli', version: '0.2.0' }, true],
    [{ name: 'vince-mp-cli', version: '0.2.7' }, true],
    [undefined, false], // package block missing entirely (gaming flag)
  ];
  for (const [pkg, ok] of cases) {
    const cli = createCli({ cwd: '/tmp', exec: async () => ({ stdout: capDoc(pkg), stderr: '' }) });
    const probe = await probeCapabilities(cli);
    assert.equal(probe.ok, ok, `${JSON.stringify(pkg)} → ok must be ${ok}`);
    if (!ok) assert.ok(probe.reason, 'a refusal must carry a reason');
  }
});

test('probeCapabilities: reads the REAL keys — workflowSteps, importantErrors (gaming/evidence P2)', async () => {
  const cli = createCli({ cwd: '/tmp', exec: async () => ({ stdout: capDoc({ name: 'vince-mp-cli', version: '0.2.0' }), stderr: '' }) });
  const probe = await probeCapabilities(cli);
  assert.deepEqual(probe.workflowSteps, ['tap', 'longpress']);
  assert.deepEqual(probe.importantErrors, ['APP_NOT_RUNNING']);
  assert.ok(!('steps' in probe), 'the imaginary `steps` field must be gone');
});

// -- fix-audit R2 regressions ------------------------------------------------

test('R2-P1: structured stderr wins over message-text classification (real execFile shape)', async () => {
  // node's execFile embeds the child's ENTIRE stderr inside error.message —
  // a message-regex classifier sees "timed out" and fabricates MP_TIMEOUT.
  const stderrDoc = JSON.stringify({ ok: false, command: 'snapshot', code: 'SNAPSHOT_ELEMENT_ENUMERATION_TIMEOUT', message: 'timed out while enumerating page elements', suggestions: ['narrow the selector'] });
  const cli = createCli({
    cwd: '/tmp',
    exec: async () => {
      const e = new Error(`Command failed: vince-mp snapshot view --json\n${stderrDoc}`);
      e.code = 1; e.killed = false;
      e.stdout = ''; e.stderr = stderrDoc;
      throw e;
    },
  });
  await assert.rejects(cli.invoke('snapshot', ['view']), (e) => {
    assert.equal(e.code, 'SNAPSHOT_ELEMENT_ENUMERATION_TIMEOUT', `CLI code must survive, got ${e.code}`);
    assert.deepEqual(e.suggestions, ['narrow the selector']);
    return true;
  });
});

test("R2-P1: a CLI-side WECHAT_CLI_NOT_FOUND with ENOENT text is NOT relabeled as vince-mp-missing", async () => {
  const stderrDoc = JSON.stringify({ ok: false, command: 'session', code: 'WECHAT_CLI_NOT_FOUND', message: 'spawn /Applications/wechatwebdevtools.app/Contents/MacOS/cli ENOENT', suggestions: ['install WeChat DevTools'] });
  const cli = createCli({
    cwd: '/tmp',
    exec: async () => {
      const e = new Error(`Command failed: vince-mp session start --json\n${stderrDoc}`);
      e.code = 1; e.stdout = ''; e.stderr = stderrDoc;
      throw e;
    },
  });
  await assert.rejects(cli.invoke('session', ['start']), (e) => e.code === 'WECHAT_CLI_NOT_FOUND');
});

test('R2-P3: abort surfaces as MP_CANCELLED, never as CLI-blame', async () => {
  const cli = createCli({
    cwd: '/tmp',
    exec: async () => { const e = new Error('The operation was aborted'); e.code = 'ABORT_ERR'; throw e; },
  });
  await assert.rejects(cli.invoke('page'), (e) => e.code === MP_CODES.CANCELLED);
});

test('R2-P3: ok:false without a code is MP_CLI_REFUSED with the CLI message intact', () => {
  try {
    parseResponse(JSON.stringify({ ok: false, command: 'session', message: 'no running session to reconnect' }), '', 'session');
    assert.fail('should throw');
  } catch (e) {
    assert.equal(e.code, MP_CODES.CLI_REFUSED);
    assert.ok(/no running session/.test(e.message));
  }
});
