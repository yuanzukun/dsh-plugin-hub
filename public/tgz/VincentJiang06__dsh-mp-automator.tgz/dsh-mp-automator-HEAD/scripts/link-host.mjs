/**
 * Pre-test: make the @deepseek-ai host packages resolvable.
 *
 * The index.js harness needs the REAL host packages (defineTool, schemastery,
 * scrubbedParentEnv, AttachmentId). Publishing-grade fidelity comes from
 * linking the installed dsh host itself — the exact versions production
 * resolves — rather than npm-pinning a parallel copy of its deep peer graph.
 * On a machine without dsh, the harness self-skips (see test/index.test.js).
 */
import { existsSync, symlinkSync, mkdirSync, lstatSync, unlinkSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';

const target = join(process.cwd(), 'node_modules', '@deepseek-ai');
try {
  // A dangling symlink (host moved) fails existsSync but still blocks
  // symlinkSync with EEXIST — detect via lstat and replace it.
  const st = lstatSync(target);
  if (st.isSymbolicLink() && !existsSync(target)) unlinkSync(target);
  else if (existsSync(target)) process.exit(0);
} catch { /* no target at all — fall through and link */ }
const host = join(homedir(), '.dsh', 'profiles', 'node_modules', '@deepseek-ai');
if (!existsSync(host)) {
  console.log('[link-host] no dsh host found — index.js harness will self-skip');
  process.exit(0);
}
mkdirSync(join(process.cwd(), 'node_modules'), { recursive: true });
try {
  symlinkSync(host, target, 'dir');
  console.log(`[link-host] linked ${host}`);
} catch (error) {
  console.log(`[link-host] link failed (${error.code}) — harness will self-skip`);
}
