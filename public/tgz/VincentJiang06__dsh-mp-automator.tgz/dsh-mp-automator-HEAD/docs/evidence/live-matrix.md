# Live test matrix — 2026-08-16, real WeChat DevTools + real mini program

| test | route | declared input | observed |
|---|---|---|---|
| T1 | deepseek-official/deepseek-v4-pro | text (hardcoded by adapter) | full read flow: doctor→page→query(miss handled honestly)→snapshot fact table→screenshot text path→console. Model summary: 冒烟测试通过 |
| T2 | moonshot/kimi-k2.7-code | [text] | `<imageStatus>model kimi-k2.7-code declares [text] — no image input</imageStatus>` + verbatim not-in-context note; model confirms no image seen |
| T3 | moonshot/kimi-k2.7-code | [text, image] | `<imageStatus>attached</imageStatus>`; model CORRECTED the prompt's false premise (card is cream, not dark), read the button text 「立刻开始 简单扫码」 from pixels, and reported colors — which do not exist in the geometry table. Real vision through the pipe. |

Negative gates (tool-triggered, not pure-function):
- G1 stale: touch utils/debounce.ts (real .ts/.js pair project) → mp_act refused verbatim:
  "refusing to act on this runtime: 1 compiled file(s) are older than their TypeScript source
  (e.g. …/utils/debounce.ts) — rebuild the project …" (refused BEFORE touching DevTools)
- G1 no-signal: project with jsFreshness.checked=0 → act proceeds WITH the mandatory
  "build freshness UNKNOWN" warning line (never fake-fresh)
- G4/boot: additionalProperties schema strictness caught by real boot (3rd real-boot-only defect
  in this project line); pnpm same-version tgz reinstall requires remove+add

Environment lessons recorded:
- settings.yaml hand-edits race a live `dsh web` (its settings flush clobbers agent-default-model);
  window must be seconds and verified afterwards
- headless --patch on agent-default-model loses to the settings layer (settings hot layer wins)
- selector-no-match: mp_act{tap, .does-not-exist-xyz} → verbatim refusal:
  'selector ".does-not-exist-xyz" matched nothing on the current page — inspect with
  mp_query / mp_inspect{mode:"snapshot"} and use a selector that exists — do not guess'
- G3 DevTools-kill: exercised at the unit level only (stderr JSON → structured code +
  suggestions + remedy map); a live DevTools kill was skipped to avoid wrecking the
  shared dev environment. Honest gap.

## 0.2.0 live smoke (2026-08-16)
- mp_query view → matched=76, 15-row table, fully-visible flags — no regression
- mp_console → total=0 errors=0 (full pagination loop in place; live buffer small)
- scroll-aware classification covered by the in-repo harness (below-fold element
  fully-visible at scrollTop=800); live scrolled-page run not performed (no
  scroll verb is exposed to agents by design)

## 0.2.0 four-route battery (2026-08-16, user-mandated pre-release gate)
Standard 7-step battery per route (doctor / page / query / negative-act / act /
screenshot / console), route PROVEN in-band by the <imageStatus> line (the model
name resolveModelInfo actually saw — immune to the settings-race).

| route | declared input | route proof | negative refusal | act | image blocks in request | verdict |
|---|---|---|---|---|---|---|
| deepseek-v4-pro | text (adapter) | `deepseek-v4-pro declares [text]` | ✓ | tap→route ✓ | 0 | PASS |
| deepseek-v4-flash | text (adapter) | `deepseek-v4-flash declares [text]` | ✓ | tap ×10 (noisy driver), all clean ✓ | 0 | PASS |
| kimi-k2.7-code | [text] | `kimi-k2.7-code declares [text]` | ✓ | tap→route ✓ | 0 | PASS |
| kimi-k2.7-code | [text, image] | `attached` | ✓ | tap→route ✓ | exactly 1 | PASS + read 「立刻开始/简单扫码」& colors from pixels |

Build note: rows 1-3 ran on the pre-Fable-review 0.2.0 build; row 4 and a
re-proof of row 1's route branch ran on the FIXED build (the fixes touch
disclosure/metadata paths, not the primary battery paths). Flash as a driver
is scattered (called mp_act 10×) but every tool call it made succeeded —
stability under a noisy driver is itself evidence.

## 0.3.0 complex batteries (2026-08-16)

Beyond smoke: multi-step stateful scenarios, evidence extracted from the session
log's TOOL-RESULT blocks only (an earlier run showed the driver model can
FABRICATE plausible `<imageStatus>` quotes in prose — tool results are the only
admissible ground truth).

### CB-A · deepseek-v4-pro (text route) — PASS
eval→data round-trip (wrote 42 via mp_eval, read it back via mp_inspect data
path), reLaunch navigation chain, camera-less `scan` injection, console
generate-then-read (probe-err / probe-mark-4 found in mp_console output).
- C3 scroll: honest N/A — the app's home page scrolls inside a `scroll-view`,
  so `wx.pageScrollTo` is a no-op there by platform design. The plugin
  correctly reported `scrollTop=0` (it refuses to invent page scroll that
  never happened); scroll math itself is pinned by the in-repo harness.

### CB-B · kimi-k2.7-code [text, image] — image economy — PASS
Sequence e1..e5 (same screen ×2, then three distinct pages via reLaunch):

| step | expected | tool-result ground truth |
|---|---|---|
| e1 home | attach 1/3 | `attached (1/3 image budget)` |
| e2 same screen | dedupe | `unchanged … image NOT re-attached (token economy …)` |
| e3 settings | attach 2/3 | `attached (2/3 image budget)` |
| e4 guide | attach 3/3 | `attached (3/3 image budget)` |
| e5 workflow | exhausted | `image budget exhausted (3/3 attached this session) …` |

- image blocks in API requests: **exactly 3** (budget honored end-to-end)
- vision proof: asked which text the LAST attached image shows — the model
  quoted the guide page's copy verbatim (「把手机变成扫码枪」「戴手套也能盲扫」
  「一键导 Excel」— all present in `pages/guide/index.wxml`), correctly named
  e4/guide, and correctly declared e5 never entered its context.

### Found in passing (now doctrine, skill §Screenshot economy)
`wx.showLoading` renders in a NATIVE layer the DevTools screencap does not
capture: four PNGs taken across showLoading ECON-1/2/3 title changes were
byte-identical (sha256 `177ef0cf…` all four) — the dedupe that fired on every
one of them was CORRECT. Never assert a toast/loading from a screenshot.

### Environment note
A wedged DevTools render process made every `screenshot` step time out
(STEP_TIMEOUT) while all other steps kept working; `session restart` alone did
NOT clear it — quitting DevTools and restarting the session did. This remedy
is now in the tool's STEP_TIMEOUT error mapping.
