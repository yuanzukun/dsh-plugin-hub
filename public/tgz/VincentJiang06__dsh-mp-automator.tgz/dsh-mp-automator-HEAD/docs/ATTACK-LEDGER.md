# Attack-battery ledger (development artifact, paths redacted)

# Attack round 1 — ledger (conductor-only; written BEFORE adjudication)

Target: PLAN.md v2 + lib/{cli,gates,facts}.js (attack copy in scratchpad/attack-r1/)
Battery: 5 Claude lens attackers (instance-tier) + 1 DeepSeek V4-Pro general attacker (model-tier)
Budget: 1 fan-out round + synthesis; fix-audit round mandatory afterwards.

## Seeds (fingerprints; strip on hit, void lens on miss)
- S1 Coherence  loc=§2.2 mp_console row  keywords=[16KB, 8192]  (contradicts §1 hard cap)
- S2 Gaming     loc=§7 负向测试            keywords=[存在即, 覆盖完成] (existence-check cheat)
- S3 Evidence   loc=§5 pi-ai citation     keywords=[327]        (wrong line number, real=827)
- S4 Reality    loc=§2.1                  keywords=[5ms, 同步]  (unimplementable sync subprocess call)
- S5 Foundation loc=§3 G4                 keywords=[永久有效]    (un-clocked version range)

## R1 incoming — coherence (Claude opus, fresh)
SEED CHECK: S1✓ S2✓ S3✓ S4✓ S5✓ (all 5 caught → run VALID; seeds stripped below)
Real findings after seed strip: 24 (1×P1, 12×P2, 11×P3) + 10 flags. Key items:
- P1 gates.js: recordSnapshot re-mints colliding uid strings w/ current generation → assertUsable
  PASSES the exact case G2 exists to kill (repro verified by attacker via node import).
- P2 evaluateFreshness fails OPEN on missing/empty doctor doc ("build is fresh" w/o evidence).
- P2 noteRoute(undefined) keeps handles across unobservable navigation (fail-open #2).
- P2 classifyElement: sysinfo-shaped viewport (windowWidth) silently → everything "visible" (fail-open #3).
- P2 40-row fact table = 4638 chars > all consuming budgets (mp_inspect 2K / mp_query 1.5K).
- P2 probeCapabilities does no name/semver check though doc calls it "the load-time gate".
- P2 cli.js ENOENT overloads CLI's WECHAT_CLI_NOT_FOUND with a second meaning (G3 table can't key).
- P2 G1 gates act/screenshot but not the assertion-bearing reads (silent-green路径 via mp_query).
- P2 per-agent UidRegistry vs shared CLI uid namespace (cross-agent renumber invisible).
- P2 safety-boundary escape hatch (mp_eval) cannot reach step-only actions — unreachable fallback.
- P2 §0 pruner row conflates 3 mechanisms (8192-char pruner / 0.8-0.16 token compaction / 50000 spill).
- P2 mp_eval 8K vs ≤2KB stated in two sections; P2 scan(200KB cap) housed in mp_act(~400B).
- P3s: buildArgs '--json' positional suppresses flag; false-valued flags silently dropped; timeout
  not named despite comment; MIN_VISIBLE_PX vs 'zero-size' label; §6 deletes cli-contract.md that
  9 §0 facts cite; §8 '一律 peer' makes step 10.7 (dsh-testkit) uninstallable; G5 has no negative
  test; §0 heading "全部…源码定位" vs 3 rows citing 架构分析; plan-vs-code drift in evaluateFreshness
  (ran===true precondition; project.ok as undeclared 3rd trigger).
Also: attacker re-verified 6 host citations as HOLDING (dsh-tools exclusivity, deepseek text-only,
pi-ai 786/801/827, settings path, tool-fs image gate, pruner constants).

## R1 incoming — gaming (Claude opus, fresh; read real vince-mp-cli src)
SEED CHECK: S2✓ (existence-check named) + also independently hit S4(5ms→measured 90ms), S5(perma-semver) → run VALID
Real findings: 8×P1, 15×P2, 3×P3 + 9 flags. Converges w/ coherence on root themes. NEW hard facts:
- P1 uid aliasing CONFIRMED from CLI src: daemon clears elementMap on auto-reconnect (daemon.js:61)
  and on nav/reLaunch/switchTab (workflow.js:231/238/245); getElement only checks map.has (workflow.js:50).
  Plugin generation counter only counts PLUGIN-side events → out-of-band renumber invisible. Same-route
  re-query re-mints same uid string for DIFFERENT element; BOTH plugin+CLI accept. Tap lands on Cancel.
- P1 mp_eval is ungated superset of ALL forbidden tools: step-commands.js:103 → workflow.js:408
  miniProgram.evaluate = arbitrary app-VM JS. One call wipes storage + setData + invokes handler + navigates,
  no uid no doctor. Safety-boundary §3 defeated by escape hatch named in same paragraph.
- P1 mp_act step channel re-exposes full forbidden vocab (mockWxMethod/storageClear/network*/mediaAction);
  buildArgs is unvalidated passthrough, NO allowlist anywhere.
- P1 findOverlaps EXCLUDES containment → a full-screen mask/modal over the submit button is skipped BY
  DESIGN; the §6-prescribed "无重叠对" green assertion passes while button unclickable. Kills the exact
  defect facts.js docstring says it targets.
- EVIDENCE-GRADE: probeCapabilities reads doc.steps but real v0.2.0 emits `workflowSteps` (no `steps` key)
  → permanently []. cli.js written against an imagined contract, not the real binary.
- P1 T3 cannot fail (pipeline bug vs vendor refusal indistinguishable); §7 "存在即视为覆盖" grades by
  test existence not wiring; "G2或CLI两层至少一层" passes when plugin layer does nothing.
- P2 doctor cache no TTL/invalidation → G1 once-per-session formality.
- P2 parseResponse accepts ok!=="false"/missing/null as success; invoke swallows timeout when stdout has JSON.
- P2 mkdir -p from model path w/o containment = arbitrary-dir-creation outside CLI path-policy.
- P3 routeKeyOf is JSON.stringify → key-order-sensitive false expiries.
ROOT THEMES (both attackers agree): (1) fail-open parsing repeated 4× (2) unobserved shared-state
mutation (3) acceptance criteria that cannot fail (4) single-operator author-same-source.
Correction to my plan's citation: dsh-subprocess scrub is at :46 not 26-44; isConcurrencySafe real 2933-2941.

## R1 incoming — evidence (Claude opus, fresh; web + CLI src + host src)
SEED CHECK: S3✓ (line 327 exposed, real gate=827) → run VALID
Real findings: 0×P1, 7×P2, 8×P3 + 5 flags. BIGGEST is not a seed:
- P2 **kimi-k2.7-code DOES support image input** (HF moonshotai/Kimi-K2.7-Code card: "K2.7-Code
  supports Image and Video input", MoonViT 400M vision encoder). Plan §5 "诚实边界" (k2.7 text-only,
  vision only on moonshot-v1-*-vision line) is FALSE. → T3 can test real image understanding, not just pipe.
- P2 error-code table is 39 codes not ~15; cli-contract says only "Key codes:" not full table. G3 map incomplete.
- P2 §8 insert one-liner `- insert: {id,name}` FAILS AT BOOT — loader does insert.push(...), needs ARRAY:
  `- insert: [{id,name}]`. Real shipped bundles use list form. (add-mechanism itself HOLDS.)
- P2 credentials mechanism as written DOESN'T EXIST: pi-ai stores apiKeyEnv=NAME (credential-ref), resolves
  via credentials.resolve(); dsh-credentials-local reads env > $DSH_HOME/.credentials.yaml > cwd/.env >
  $DSH_HOME/.env. `~/.config/moonshot/api_key` is NOT a source dsh reads. Must export to env or write .credentials.yaml.
- P2 probeCapabilities reads `steps` but real doc has `workflowSteps` (confirms gaming); also `errorCodes`
  absent, real key is `importantErrors` (10 codes only).
- P2 query --position geometry not invariant: maybeRead substitutes {unavailable:true, code:...} on 500ms
  timeout → facts.js mislabels as "zero-size" (visual defect) not "no-geometry" (read failure).
- P2 turn-stopping IS real+awaited (dsh-agent-loop:565) so ≤5ms sync blocks turn close; seam is spawn-only async.
- MISATTRIB: §1 rule 4 (verbose/terse) cited to 定律2 which says nothing of the sort; 定律4 "必须静态" is my inference not doc's words.
- P3 citation near-misses: image-block fields at 905-914 not 930-941; ctx.inject at 1210 not 1197(jsdoc); skill cwd at 119 not 118.
- CORRECTION to a flag i earlier repeated: pi-ai NOT in web profile config — comes from dsh-base:95-96, MOUNTED DORMANT (zero routes until llm-pi-ai settings supplies providers).
- dsh-testkit IS REAL (npm 0.3.1, pub 2026-08-15) — my flag was wrong, it exists.
CALIBRATION (attacker verified these HOLD first-party — don't re-audit): defineTool:836 full contract,
isConcurrencySafe fail-closed 2933-2941, lossless-JSON 2491, image gate tool-fs 890-898, attachment chain
1012-1026, deepseek text-only 442+514, pi-ai 786/801/827 all exact, settings NS 1726 + path 1760, bash-persistent
lifecycle 175-230 exact, scrubbedParentEnv real (subprocess-local:319, /KEY|PASSWORD|SECRET|TOKEN/i catches
DEEPSEEK_API_KEY), pruner 8192/4096/1024 + spill 50000 + 0.8/0.16 ALL first-party confirmed, doctor.checks shape,
console oldest-first pageSize50 cap1000, nav/switchTab/reLaunch clear elementMap, npm 404 for our name, base URL
api.moonshot.cn/v1 live, dsh-plugin keyword real convention, dsh plugin add auto-mounts via reconcilePlugins.

## R1 incoming — reality (Claude opus, fresh; EXECUTED modules + replayed CLI parser)
SEED CHECK: S4✓ (5ms sync claim demolished: no sync seam verb, 34x over budget) → run VALID
Real findings: 7×P1(after seed strip), 7×P2, 6×P3 + 6 flags. NEW hard facts (none previously known):
- P1 **CLI writes thrown CliError JSON to STDERR** (src/cli.js main: writeJson(response, process.stderr));
  stdout is 0 bytes for UNSUPPORTED_COMMAND/INVALID_ARGUMENT/AUTOMATION_PORT_TIMEOUT/WECHAT_CLI_NOT_FOUND.
  Our cli.js never reads stderr → G3 gets UNEXPECTED_ERROR+no suggestions on its own headline cases.
- P1 evaluateFreshness also fails open on {ok:false} doctor FAILURE doc and on shorthand-wrapped
  {result:{checks}} shape (doctor alone is top-level; every shorthand wraps in result).
- P1 G1 has NO GRADIENT on JS-only projects / out-of-dir builds: doctor only flags SIBLING .ts/.js pairs
  (skips dist/build/out/miniprogram_npm); typecheck {ran:false,ok:null} w/o tsconfig. "fresh"≠"no signal".
- P1 THIRD unobserved renumbering event: auto-RECONNECT resets uid map (cli-contract:19; daemon auto-
  reconnects on drop) — plugin's generation counter blind to it. Same-uid-string re-mint via query-append
  base=elementMap.size also confirmed from src.
- P1 maybeRead sentinel: size/offset/text can be {unavailable:true, code:ELEMENT_PROPERTY_TIMEOUT}
  (500ms/property, routine on Skyline) → classifyElement Number()||0 → "zero-size+offscreen" FALSE FACTS,
  text column renders "[object Object]".
- P1 findOverlaps containment-skip kills the #1 real occlusion (full-screen mask over button) — §6's
  prescribed assertion evaluates TRUE for a fully covered button.
- P1 subprocess seam contract mismatch: spawn(spec) sync→handle; spec REQUIRES cwd+graceMs+3 stdio
  dispositions ("no defaults"); NO timeoutMs (consumer owns deadline); done rejects only spawn-level;
  missing-binary error has NO .code (message string) → our ENOENT branch dead under seam. The exec
  adapter is the load-bearing unwritten code.
- P2 buildArgs lacks `--` separator → any eval expr/input text starting with '-' fails parseArgs strict.
- P2 console merged buffer ≤2000; page 0 @1000 returns OLDEST half → tail needs pageIdx walk.
- P2 credentials path confirmed wrong (matches evidence finding; I verified first-party too).
- P2 no timeoutMs on any tool; first act can block 120s(tsc)+65s(cold session); declare per-tool timeoutMs.
- P3 remedy-overwrite bug (project branch clobbers rebuild remedy); tsc timeout misreported as type errors;
  routeKeyOf key-order; recordQuery same-uid silent overwrite; overlap "N more" missing; credential-guard
  allowlist doesn't cover new read tools (mp_eval/data/console leak outside guard).
- TRANSCRIPTION BUG in §0: G5 line missing `await` before llm.resolveModelInfo (as-written → TypeError).
- FLAG adjudicated ACCEPTED as design change: async capability probe at apply-time conflicts w/ stable
  tool-set/KV prefix → switch G4 to: ALWAYS register 8 tools (static schemas), lazy probe cached at first
  call, refuse-with-remedy at execute. "Zero tools" mode dropped.
- ADJUDICATION NOTE (conflict): reality claims agent/turn-stopping doesn't exist (grep of profiles root);
  evidence cites dsh-agent-loop:565 awaited serial dispatch + auto-compact subscribes to it. dsh-agent-loop
  lives under the volta dsh install, not profiles/node_modules → evidence wins; reality's grep-root was
  wrong. Irrelevant to plan v3 anyway (turn-stopping usage was only the S4 seed).

## Adjudicated structural redesigns for PLAN v3 (conductor, after 4/6 reports)
R-A **Selector-addressed acts (kills the G2 class instead of patching it)**: mp_act takes
  {selector, nth?} not uid. Execute = query→act as two back-to-back invokes inside one exclusive
  tool call (ms-scale window vs unbounded model-turn window). uids remain visible in mp_query
  output as labels, but the model never REPLAYS them across calls. UidRegistry demoted to
  diagnostics. Rationale: 3 unobservable renumbering events + shared-daemon second clients make
  mirroring structurally unwinnable (gaming P1 + reality P1 + coherence P1 all one root).
R-B **G1 four-state**: fresh | stale | doctor-failed | no-signal. block-mode blocks stale+doctor-
  failed; no-signal proceeds with a mandatory warning line prepended to the RESULT (visible in
  transcript). Per-act recheck runs doctor --skip-typecheck (cheap); full tsc only on mp_doctor
  (cached, TTL). "build is fresh" wording banned unless jsFreshness actually checked >0 files.
R-C **G4 lazy**: always register all 8 tools (stable schema set = stable KV prefix); capability
  probe runs at first execute, cached; failure → per-call refusal carrying install/upgrade remedy.
  Range >=0.2.0 <0.3.0 with EXPLICIT review trigger documented (not permanent).
R-D **stderr is half the contract**: exec adapter captures stdout+stderr; parseResponse tries
  stdout JSON, then stderr JSON, then raises named spawn-class errors. Plugin-side codes get
  MP_ prefix (MP_CLI_NOT_INSTALLED etc.) — never reuse CLI's own vocabulary for plugin failures.
R-E **facts.js honesty pass**: maybeRead sentinels → 'read-failed' flag (never zero-size);
  viewport absent → 'viewport-unknown' + note (never visible); containment REPORTED as
  'contained-by (possible overlay)' pairs; byte-aware clamp (CJK=3B) at 4KB w/ explicit
  truncation note; default rows 15; overlap section notes dropped pairs.
R-F **Budgets v3**: every tool ≤4KB target, 6KB hard clamp (<8192 pruner threshold), one number
  per tool everywhere. mp_console default = errors+last 20 via pageIdx tail-walk.
R-G **mp_act step allowlist**: only longpress/switchTab/reLaunch/scan, fixed shapes, no raw step
  passthrough; buildArgs gains `--` separator; mp_eval treated as act-class for G1 + config kill-switch.
R-H **T3 falsifiable**: k2.7-code vision CONFIRMED LIVE by conductor (curl: 1x1 rejected as
  format, 32x32 blue PNG → "Blue", usage counted). T3 = image block reaches request (session log)
  + API 200 + content question answered correctly; T2 same model input:["text"] must show G5
  degrade note instead. Both falsifiable, distinguishable from pipe bugs.
R-I **Credentials corrected**: pi-ai apiKeyEnv is a credential-ref resolved env > $DSH_HOME/
  .credentials.yaml > cwd/.env > $DSH_HOME/.env; the operator exports MOONSHOT_API_KEY in the
  shell environment (location redacted) → declare apiKeyEnv: MOONSHOT_API_KEY.
R-J §8 insert must be a LIST; devDependencies carve-out for test tooling (dsh-testkit@0.3.1 real);
  citation line numbers corrected (905-914, 1210, 119, subprocess:46, isConcurrencySafe 2933-2941);
  §0 provenance wording downgraded from "全部源码定位" to per-row 出处 with 实测 artifacts committed
  under .attack/fixtures/.

## R1 incoming — V4-Pro (DeepSeek, DIFFERENT VENDOR = model-tier independence)
SEED CHECK: S1✓ S2✓ S3✓ S4✓ (S5 miss — 4/5, run VALID). Full report: r1-v4pro-report.txt
24 findings + 10 flags. CONVERGES with Claude lenses on: evaluateFreshness fail-open (incl
ran===true arm vs real {ran:false,ok:null}), UidRegistry blind to shared-daemon clears, mp_eval
bypass, insert-must-be-list, WECHAT_CLI_NOT_FOUND overload, probeCapabilities no-check+undefined-ok,
parseResponse ok!=="false" fail-open, doctor cache no TTL, containment-skip, 40-row budget 2x
overflow (measured 4230B CJK), 定律2 misattribution, cli-contract deletion undercuts G3, routeKeyOf
key-order. Cross-vendor convergence = high-confidence adjudication for R-A..R-J.
UNIQUE new items (accepted):
- P3 partial-offscreen elements count as `visible` → "uid X visible" assertion true for a half
  offscreen button. FIX: add fully-visible vs partial distinction; §6 assertion prescription uses
  fully-visible.
- P3 promised `elementCount` never rendered by renderElementFacts. FIX: renderer emits it.
Honest note from attacker: single-pass, self-labeled severities, no independent judge of ITS
labels → its battery_grade self-declared smoke-only; treated here as a convergence oracle, not
a sole source.

## R1 STATUS: 5/6 reports in (coherence, gaming, evidence, reality, v4pro). Foundation pending.

## R1 CLOSED. coverage_gaps:
- Foundation lens: NOT completed (subagent interrupted by an unrelated user /model switch mid-run,
  produced no final JSON). Partial compensation: V4-Pro (cross-vendor) covered the core rot vectors
  — S5 permanent-semver (accepted → R-C review trigger), version-pin-to-actively-developed-CLI,
  hardcoded ~ paths in DRIVER-style probes. Residual gap: no dedicated attack on the
  deeper premises (geometry-first > screenshot-first; thin-shell-over-CLI; plugin-gate > skill-rule).
  These premises were instead stress-tested indirectly and SURVIVED: geometry-first is now the ONLY
  sound path (screenshots can't be seen by text routes AND k2.7 CAN see → both-path design holds);
  thin-shell survived (CLI is the automation truth, plugin owns discipline); plugin>skill survived
  (skill instructions can't gate mp_eval, a tool can). Foundation re-run deferred to a later battery
  if the premises wobble; not blocking v3.
- battery_grade: model-tier reached (V4-Pro different-vendor) on the shared findings; instance-tier
  on Claude-only lens specifics. Adjudication by conductor (me), not an independent different-vendor
  judge → self-preference residue acknowledged; mitigated by cross-vendor CONVERGENCE on all P1s.
- fix-audit: will run as R2 against the v3 diff (mandatory per skill).

## R1 verdict tally (post-adjudication, deduped across 5 reports):
P1 (structural, must-fix before any code): uid-mirror-unwinnable → R-A selector-addressed;
  G1 fail-open+no-gradient → R-B four-state; stderr-half-the-errors → R-D; maybeRead-sentinels →
  R-E; containment-skip-kills-core-defect → R-E; mp_eval/step bypass → R-G; subprocess-seam-contract
  → R-D adapter; probeCapabilities-reads-wrong-key + no-check → R-C lazy; parseResponse fail-open → R-D.
P2: budgets-in-prose-only → R-F; credentials-path-wrong → R-I; insert-map-not-list → R-J;
  k2.7-vision-real → R-H; doctor-cache-no-TTL → R-B; console-oldest-half → R-F tail-walk;
  no-timeoutMs → declare per-tool; mkdir-no-containment → R-E path guard; G4-permanent → R-C trigger.
P3: many docstring/citation/label drifts → R-E + R-J cleanup pass.

## R2 fix-audit (fresh Claude auditor, ran ~45 scenarios via fake-CLI replaying real parseArgs tables)
SEEDS: none planted (target = fix diff; audit anchored to r1 baseline instead). All findings adjudicated REAL:
- P1 mp_console --page-idx doesn't exist in CLI → FIXED: tail via step listConsole pageIdx (live-verified),
  unreachable-tail now DISCLOSED, errors counted over merged pages.
- P1 classification order: execFile embeds child stderr in error.message → message regexes swallowed real
  CLI codes (…_TIMEOUT relabeled MP_TIMEOUT w/ fabricated 120000ms; WECHAT_CLI_NOT_FOUND relabeled
  NOT_INSTALLED) → FIXED: structured doc parsed FIRST; classifiers structural-only; regression tests use
  REAL execFile message shape (suite was structurally blind before).
- P1 overlap starvation: mask beyond row-limit never analyzed; area-sort + offscreen noise starved the
  containment pair → FIXED: analysis over ALL elements (cap 200, disclosed), offscreen excluded,
  containment gets its own budget sorted by container size.
- P2 typecheck arm unreachable (quick doctor always --skip-typecheck) → FIXED: full-doctor typecheck
  failure remembered per-cwd, binds acts until a passing full doctor clears it.
- P2 guarded() didn't cover cwdOf/ensureCompatible (remedies lost) → FIXED: moved inside try.
- P2 mp_query default $() vs mp_act --all index-space mismatch → FIXED: query always --all; nth space
  unified and documented in both schemas.
- P2 stale-runtime reads unannotated → FIXED: readWarning() prefix on query/inspect from cached verdict.
- P2 SKILL claimed mp_eval can't reach wx.* (false) → FIXED: honest boundary section + usage discipline.
- P2 red-run artifact was import-only → REGENERATED: behavioral 8/9 red for gates vs v2; cli/facts
  limitation stated honestly.
- P3s fixed: session status reads `running`; reconnect refusal = MP_CLI_REFUSED (not BAD_OUTPUT);
  abort = MP_CANCELLED; ok:false-no-code preserved; null-geometry no longer fabricates 0x0; data/eval
  null via ('value' in r); screenshot reads OUR contained path; imageNote override kills the
  note-vs-imageStatus contradiction; param descriptions added to every tool.
- Flags acknowledged not fixed (recorded): comma-group selector verified WORKING live (76 elems);
  scroll-offset vs viewport semantics untested on scrolled pages (known limit, in SKILL); sync readFile
  on PNG; probeCache global not per-cwd; enableEval default true is a deliberate choice documented.
Post-fix: 36/36 unit green, live regression green (query matched / console / session status honest).
BATTERY CLOSED: r1 (5 lenses + cross-vendor) + R2 fix-audit. Residual: index.js still lacks an
in-repo fake-ctx harness (auditor's was scratchpad-only) — top item for v0.2.0.

## R5 (0.3.0): complex batteries + image economy
Mandate: harder stateful cases; cap screenshot attachment on vision routes (token protection).
Shipped: imageBudget (default 3) + sha256 dedupe (unchanged → NOT re-attached) + exhaustion
message with billing warning; G1 TTL cache removed (quick doctor ~100ms measured — the
touch-within-TTL hole bought nothing); STEP_TIMEOUT remedy added. 49/49 unit green.
Live: CB-A on deepseek-v4-pro (eval→data round-trip, reLaunch chain, scan, console
generate-read) PASS; CB-B on kimi [text,image]: attach→dedupe→attach→attach→exhausted with
exactly 3 image blocks in requests and a verbatim-from-pixels vision proof. Found in passing:
native overlays (wx.showLoading) don't render in screencap — byte-identical PNGs, dedupe was
right every time; now doctrine in the skill. Environment: a wedged DevTools render process
times out ONLY screenshots — quit DevTools + session restart is the remedy (mapped).
Evidence rule hardened: only session-log tool-result blocks count; driver-model prose can
fabricate plausible status quotes.

### R5 fix-audit (independent, pre-tag)
Verdict SHIP. Both prior-reviewer mutations re-run and KILLED by the new tests (dedupe-burns-budget
→ fourth-shot 2/3 assertion fails; cwd-keyed revert → cross-session test fails). All four remaining
cwd-keyed maps adjudicated individually: bridges/probeCache/freshnessCache/typecheckFailed key a
PROJECT property, not a context property — correct class, not the imageState leak. Schemastery
verified non-strict: operators' leftover freshnessTtlSeconds keys merge through harmlessly (no boot
break). Residual P3 accepted + disclosed in code: host-side session resume resets image state —
spend-not-lie direction (may re-attach; never claims an absent image is present).
