> **HISTORICAL DOCUMENT 历史文档** — this is the pre-implementation plan (v3), kept as a
> design record. The shipped code and README are the current truth; several details below
> changed during implementation (mp_query has no `all`/`nth` parameters, budgets are a
> uniform in-code byte clamp, the attack ledger lives at `docs/ATTACK-LEDGER.md`).
> 本文是实现前的计划存档；以代码与 README 为准。

# dsh-mp-automator — 构建计划 v3（攻击后重铸版）

WeChat 小程序自动化测试组件：**plugin（能力 + 门）+ skill（打法）**。
v3 是一次电池攻击（5 透镜 Claude + 跨厂商 V4-Pro，seeds 全命中，台账见 `docs/ATTACK-LEDGER.md`）之后的结构性重写。
v2 的三个纯模块被证明有 9 个 P1，全部源于四个根因；v3 从设计上消灭根因，而非打补丁。

状态：v3 待批准 → 随后 fix-audit 第二轮 → loop 构建。

---

## 攻击暴露的四个根因（v3 的全部动机）

1. **镜像共享状态必输**。uid 表是 CLI daemon 的单例；它在断线重连、导航、snapshot、以及**任何第二个客户端**操作时重编号，其中三类事件插件不可见。任何"插件侧 generation 计数"都会在盲区放行——三个 P1 同一根因。→ **不再镜像；改变寻址模型（R-A）**。
2. **到处 fail-open**。`evaluateFreshness` 对缺失/失败/异形 doctor 文档答 "build is fresh"；`parseResponse` 只认字面 `ok===false`；`invoke` 吞掉带 stdout 的超时；`probeCapabilities` 对任何 JSON 报 ok。计划在声明处 fail-closed，在没声明处全部 fail-open。→ **每个解析/判定默认 fail-closed（R-B/R-C/R-D）**。
3. **半个错误契约**。CLI 把**抛出的**结构化错误写 **stderr**；cli.js 只读 stdout。G3 的错误映射在它自己的头号案例（`AUTOMATION_PORT_TIMEOUT`）上收到的是空 stdout。→ **exec adapter 读 stdout+stderr（R-D）**。
4. **散文当契约**。8192 字符预算、40 行默认、门与工具的接线、门覆盖标准，全部只活在散文里、零执行、零字节记账。→ **预算进代码、带 clamp、带测试（R-F）；覆盖标准按接线不按存在（R-F 测试纪律）**。

---

## R-A 选择器寻址：从设计上消灭 G2 类

**mp_act 接受 `{selector, nth?}`，不接受 uid。** 一次 `mp_act` 调用内部 = `query <selector>` → 立刻 `tap/input <刚铸的 uid>`，两步在**同一个 exclusive 工具调用**里背靠背完成。危险窗口从"模型跨多轮持有 uid"（不可控、秒到分钟级）压缩到"插件内部两次 CLI 往返之间"（毫秒级，且期间无其他工具能插入，因 exclusive）。

- uid 仍出现在 `mp_query` 的输出里，但**作为人看的标签**，模型永不跨调用重放它。
- `UidRegistry` 从"门"降级为**诊断辅助**：仅在 mp_act 内部这一步用于"query 刚返回 0 个元素 → 报 selector 未命中"。它不再承担跨调用溯源，因为那是它赢不了的仗。
- 代价：无法对"先看后点同一元素"省一次 query。这个代价换来的是 G2 类三个 P1 的整体消失——**不是修好，是不存在**。
- selector 稳定性交给使用者（skill 里教：优先 data 属性/文本锚点，避开位置选择器），这是打法不是能力。

## R-B 构建新鲜度门：四态，不再二元

`evaluateFreshness` 返回 `{state, severity, reason, remedy}`，state ∈ **fresh | stale | doctor-failed | no-signal**：

| state | 触发 | block 模式行为 |
|---|---|---|
| `fresh` | `jsFreshness.staleCount===0` 且（typecheck 未跑 或 ok）| 放行 |
| `stale` | `jsFreshness.staleCount>0` 或 `typecheck.ran && !ok` | **拒 mp_act/mp_eval/mp_screenshot**，remedy=重建 |
| `doctor-failed` | doctor 文档 `ok:false` 或无法解析 | **拒**，remedy=先跑 mp_doctor 看错误 |
| `no-signal` | 文档缺失/空/异形/无 jsFreshness 字段（含 JS-only 项目、独立产物目录、无 tsconfig）| **放行但在结果头部注入一行警告**："构建新鲜度未知（此项目无 .ts/.js 对或无 tsconfig）——本次结果基于未经新鲜度验证的运行时" |

- 关键纪律：**"build is fresh" 这个措辞只有在真的检查了 >0 个文件且全新鲜时才允许出现**。no-signal 绝不说 fresh。
- 消灭"无梯度"P1：JS-only / 独立构建目录项目落 `no-signal`（诚实），不再伪装成 fresh。
- 消灭 fail-open P1：缺失/失败文档落 `doctor-failed`（block），不再放行。
- doctor 结果解析要兼容两种外壳：`doctor` 把 `checks` 放顶层，而所有 shorthand 包在 `{result:{...}}`——解析器两种都认，认不出落 `doctor-failed`。

## R-C 能力门：懒探测，工具集恒定

- **加载时恒注册全部 8 个工具**（schema 静态 → KV cache 前缀稳定，符合定律 4；不因探测快慢在 turn 1/2 之间改变工具集）。
- 能力探测在**首次 execute** 时跑一次并缓存；`vince-mp capabilities` 读 `package.{name,version}` 校验 `name==='vince-mp-cli'` 且 semver ∈ `>=0.2.0 <0.3.0`。
- 探测失败/版本不符 → 该工具调用**返回带 remedy 的拒绝**（装/升级指引），而非"零工具注册"。
- capabilities 真实键是 `workflowSteps`（45 项）不是 `steps`，`importantErrors` 不是 `errorCodes`——按真实键读。
- 版本区间**带显式复审触发器**注释（"CLI 升 0.3.0 时此处必须复审"），不写"永久有效"。

## R-D 错误契约：stderr 是另一半

exec adapter（`ctx.subprocess` seam 或回落 execFile）**同时捕获 stdout 与 stderr**：
- `parseResponse` 依次尝试：stdout JSON → stderr JSON → 命名的 spawn 类错误。CLI 抛错走 stderr，这条路必须通。
- **fail-closed 解析**：只有 `ok === true`（严格布尔）且有预期字段才算成功；`ok:"false"`、缺 ok、`null`、`42`、空——全部视为失败。
- **超时不吞**：带 stdout 的超时/SIGTERM 仍是失败，命名为 `MP_TIMEOUT`。
- **插件自有错误码加 `MP_` 前缀**（`MP_CLI_NOT_INSTALLED`/`MP_TIMEOUT`/`MP_BAD_OUTPUT`），**绝不复用 CLI 自己的词汇**（`WECHAT_CLI_NOT_FOUND` 是 CLI 表示 DevTools cli 缺失的码，不是"vince-mp 没装"）。
- subprocess seam 真实契约（reality 实测）：`spawn(spec)` 同步返回 handle；spec **必须**给 `cwd`（string）、`graceMs`、三个 stdio disposition，seam **无默认**；**无 timeoutMs**（deadline 归消费者，adapter 自己用 AbortController 计时）；`done` 只在 spawn 级失败 reject；missing-binary 错误**无 `.code`**（靠 message 串识别）。adapter 按此写，不假设 execFile 语义。
- cwd 缺失时不能让 CLI 从宿主进程 cwd 猜项目——adapter 必给 cwd，取 `exec.agent?.session.header.cwd`，无则拒绝并提示"在小程序项目目录内运行"。

## R-E facts.js 诚实化

| 缺陷 | v3 行为 |
|---|---|
| maybeRead 返回 `{unavailable:true, code}` 被当几何 | 检测 sentinel → flag `read-failed`（带 code），**绝不**报 zero-size；text 同理不渲染 `[object Object]` |
| viewport 缺失 → 全体 visible | viewport 未知 → flag `viewport-unknown` + 结果注明"未做可见性判定"，绝不报 visible |
| 全屏遮罩（containment）被跳过 | containment **报告**为 `contained-by（可能是遮罩/mask）` 候选对，正是核心缺陷 |
| partial-offscreen 算 visible | 区分 `fully-visible` vs `partial`；skill 的断言处方用 `fully-visible` |
| 无字节记账，40 行超预算 2–3× | **字节感知 clamp**（CJK=3 字节）在 4KB 处截断并注明；默认 **15 行**不是 40 |
| overlap 只在前 N 行、丢弃无提示 | overlap 段注明"另有 N 对未显示"；无重叠段与"未检查"用词区分 |
| 承诺 elementCount 不渲染 | 渲染 `elementCount` |
| mkdir 无包含校验 | 截图路径先做 workspace 包含校验再 mkdir，越界拒绝（不制造 CLI 之外的任意建目录原语）|

## R-F 输出预算：进代码，带 clamp，一个数

- 每工具 **≤4KB 目标，6KB 硬 clamp**（< 8192 pruner 阈值，留余量），字节记账，超出截断并注明。
- **一个工具一个数**，散文与表一致；删除所有"8K vs 2KB"式双数字。
- `mp_console` 默认 = **错误/异常 + 最近 20 条**，内部用 `pageIdx` 尾部走页（CLI 合并缓冲 ≤2000，page 0 是最旧半段，必须走到尾页），不是 page 0。
- **门覆盖测试按接线判定**：负向测试必须调用 `mp_act` 并断言它被拒，而非只断言纯函数——"两个纯函数断言存在即覆盖"被禁止；G1..G5 每个都要有"经工具触发的"负向测试。

## R-G act 通道白名单

- `mp_act` 的 step 通道**只允许** `longpress/switchTab/reLaunch/scan`，固定 shape，**无裸 step JSON 透传**。
- `buildArgs` 加 `--` 分隔符：任何以 `-` 开头的 selector/input/eval 参数放 `--` 之后（否则 CLI 的 parseArgs strict 报 Unknown option）。
- `mp_eval` 归为 **act 类**（受 G1 约束），且有 config 级 kill-switch（默认开，可关）。它仍是逃生舱，但不再是绕过全部门的暗道——受 G1、受 config、结果受 R-F 预算。
- 安全边界诚实重述：`storageClear`/`mockWxMethod`/`network*`/`media*` **既不做成工具、也不承诺 mp_eval 可达**（mp_eval 是页内 JS，够不到 automator 级 step 动作）。唯一途径是使用者亲自开 CLI。这是诚实的"不支持"，不是假装有后门。

## R-H T3 可证伪（k2.7 视觉已实证为真）

**conductor 已用真实 API 证实 k2.7-code 有视觉**（curl：1×1 被拒为格式错误，32×32 蓝 PNG → 模型答 "Blue"，usage 计入 image token）。所以 v2 的"k2.7 纯文本"诚实边界是错的，T3 反而变强：

| 测试 | 路由 input 声明 | 判据（可证伪、能区分管道 bug 与厂商拒收）|
|---|---|---|
| T1 | `deepseek-v4-pro`（硬编码 text）| 文本几何路径全流程 |
| T2 | `moonshot/kimi-k2.7-code` `input:["text"]` | G5 **降级分支**：结果必含"截图在磁盘不在上下文"注记，无 image block |
| T3 | 同模型 `input:["text","image"]` | G5 **放行分支**：① 会话日志显示 image block 进了请求 ② API 返回 200 ③ 就一张已知内容截图提问，模型答对。三条全绿才算过；API 4xx 或答错都是**失败**，如实归因（管道 vs 理解）|

k2.7 额外约束（实测）：`temperature` 只接受 1。

## R-I 凭据：改对机制

- pi-ai 的 `apiKeyEnv` 是**凭据引用名**（credential-ref），dsh 解析顺序：**环境变量 > `$DSH_HOME/.credentials.yaml` > `<cwd>/.env` > `$DSH_HOME/.env`**——**不读** `~/.config/moonshot/api_key`。
- 在启动 dsh 的环境里 `export MOONSHOT_API_KEY`（值放在一个 0600 权限的文件里由 shell 配置读入）即可命中"环境变量"层；provider 声明 `apiKeyEnv: MOONSHOT_API_KEY`。注意 dsh 不读任意文件路径，只认凭据层。
- provider 完整块（settings ns `llm-pi-ai`，路径 `providers.moonshot`）必须给全：`displayName`、`api`（协议）、`baseURL: https://api.moonshot.cn/v1`、每个 model 的 `{id,name,contextWindow,maxTokens,input,reasoningEfforts,compat}`——不能只给 baseURL+input。这个块是 §7 依赖的可运行产物，随插件附一份模板。

## R-J 打包与引用卫生

- `cordis.patch.yml` 的 insert 是**列表**：`- insert:\n    - id: mp-automator\n      name: dsh-mp-automator`（map 形式启动即崩）。
- 依赖：`@deepseek-ai/*` 一律 optional peerDependencies，`dependencies: {}`；**但 devDependencies 允许**测试工具（`dsh-testkit@0.3.1` 真实存在）。
- 引用行号更正：image-block 字段 905-914（非 930-941）、`ctx.inject(['attachments'])` 1210（1197 是 jsdoc）、skill cwd 119（非 118）、subprocess scrub :46、isConcurrencySafe 2933-2941。
- **G5 门必须 `await llm.resolveModelInfo(...)`** 再读 `.inputModalities`（§0 曾漏 await → 对 Promise 取属性必 TypeError）。
- §0 表头从"全部源码定位"降级为逐行 出处；`实测` 类事实的复现命令与输出存档于 `docs/evidence/`。

---

## 工具集 v3（8 个，全 exclusive，预算见 R-F）

| 工具 | 参数 | 作用 | 预算 |
|---|---|---|---|
| `mp_session` | action | start/status/stop/restart/reconnect | 512B |
| `mp_doctor` | skipTypecheck? | 健康 + 四态新鲜度（G1 数据源，缓存带 TTL）| 2KB |
| `mp_inspect` | mode, path? | page/stack/data/sysinfo/snapshot（默认 15 行事实表 + elementCount）| 4KB |
| `mp_query` | selector, all?, nth? | 找元素 + 几何事实表（uid 作标签）| 3KB |
| `mp_act` | selector, action, nth?, text? | query→act 原子对；step 通道白名单（R-G）| 1KB |
| `mp_screenshot` | name | 双路径（R-H），路径先包含校验后 mkdir | 3KB + 可选 image block |
| `mp_console` | clear? | 错误优先 + 尾部 20（R-F 尾页走页）| 4KB |
| `mp_eval` | expr | 逃生舱，act 类受 G1 + config kill-switch | 4KB |

门：G1 四态新鲜度（R-B）、G2 selector 寻址消解（R-A，无独立门）、G3 stderr 感知的 code→remedy（R-D）、G4 懒能力探测（R-C）、G5 await 的图像模态（R-J）。

## 测试矩阵 v3

正向：T1/T2/T3（R-H）。**负向（经工具触发，比正向重要）**：
- 改旧一个 `.js` → `mp_act` 被 G1 拒（stale 态），结果含 rebuild remedy
- JS-only 项目 → `mp_act` 放行但结果头部有 no-signal 警告行（不是伪 fresh）
- doctor 文档 `ok:false` → `mp_act` 被 G1 拒（doctor-failed 态）
- 杀 DevTools → `mp_act` 得到 G3 映射错误（从 **stderr** 取到真实 code + suggestions），非裸 stack、非空
- selector 未命中（query 返 0）→ `mp_act` 报 selector 未命中，不瞎点
- `mp_eval` 在 stale 构建 → 被 G1 拒（证明逃生舱受门约束）
- 以 `-` 开头的 input 文本 → 经 `--` 正常送达（不报 Unknown option）
- vince-mp 从 PATH 摘除 → 工具调用返回 `MP_CLI_NOT_INSTALLED` + 装指引（非 CLI 的 WECHAT_CLI_NOT_FOUND）

纯逻辑层 `node --test`：cli（argv+`--`分隔、stdout/stderr 双解析、fail-closed）、gates（四态、无镜像残留）、facts（sentinel/viewport/containment/字节 clamp/elementCount）。**先红后绿，红的证据留档**。

## 交付顺序

1. package.json（R-J 依赖纪律）+ cordis.patch.yml（R-J 列表 insert）
2. 纯模块**测试先行**（红）→ 重写 cli/gates/facts 到绿（消灭四根因）
3. `lib/index.js` 接线：R-D exec adapter → R-C 懒探测 → per-agent 连接生命周期 → 8 工具 → 门
4. tgz 装 web profile，T1 跑通（真实项目，DevTools 会话已可用）
5. pi-ai 手工路由 moonshot（R-I 完整块），T2 → T3（R-H 三判据）
6. 全部负向门测试经工具触发、全绿
7. skill 瘦身（打法：selector 稳定性、几何断言、证据纪律）+ 双语 README
8. 推 GitHub（conventional commits + vX.Y.Z tag，对齐生态）；npm 待 `npm login` 后发

## 诚实边界（v3）

1. selector 寻址把窗口从分钟压到毫秒，不是零——同一 exclusive 调用内 CLI 两次往返之间理论上仍可被第二个客户端 renumber，但需要另一个进程正好在这毫秒级窗口操作同一 daemon，概率与影响都远低于跨轮 uid 重放。
2. 矩形 containment/overlap 只报候选，拿不到 paint order。
3. T3 证实 k2.7 有视觉的是**管道 + 单张已知图**，不是全面视觉质量基准。
4. facts.js 的几何来自 CLI 的 automator 读数，Skyline 上 500ms/属性超时会落 read-failed（诚实标注，不猜）。
5. 插件与 CLI 是两进程，daemon idle-timeout/重启是又一次不可见 renumber——这正是 R-A 放弃镜像的原因，selector 寻址对此免疫（每次 act 自带新鲜 query）。
