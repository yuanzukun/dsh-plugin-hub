/**
 * Shared wire contract between the host plugin and its settings section:
 * the generic Connection RPC channel name, the endpoint names, and the
 * status/update payload shapes. Imported by both halves (type-only on the
 * client side — erased at build).
 */

/** Generic Connection RPC channel mounted by the host plugin. */
export const RPC_CHANNEL = '/dsh-proxy'
/** Endpoint: read the current proxy status. */
export const RPC_STATUS_ENDPOINT = 'status'
/** Endpoint: apply a settings patch and restart the forwarding service. */
export const RPC_UPDATE_ENDPOINT = 'update'
/** Endpoint: start the forwarding service (idempotent). */
export const RPC_START_ENDPOINT = 'start'
/** Endpoint: stop the forwarding service (the response is answered before the listener closes). */
export const RPC_STOP_ENDPOINT = 'stop'

/** Read-only status the settings section shows. */
export interface LanProxyStatus {
  /** Interface the proxy binds (0.0.0.0 = LAN reachable). */
  listenHost: string
  /** Port the proxy listens on (the OS-assigned value when 0 was configured). */
  listenPort: number
  /** Whether the proxy is actually bound (false = bind failed, e.g. port busy). */
  proxyListening: boolean
  /** Upstream DSH host. */
  upstreamHost: string
  /** Upstream DSH port the proxy forwards to. */
  upstreamPort: number
  /** Whether the target upstream service answers a probe. */
  upstreamReachable: boolean
  /** Login username currently enforced. */
  username: string
  /**
   * The CURRENT password, so the settings form can pre-fill (write back) the
   * credential fields and empty means "set empty". The status channel sits
   * behind Connection's Host/Origin trust fence and browser authentication
   * (DSH 0.1.7 dropped the per-channel `authority: 'loopback'` option in favour
   * of that uniform fence), and through the proxy the Host is rewritten to
   * loopback, so a caller reaching it already holds the same credentials (or is
   * on the host, where the persisted $DSH_HOME file is equally readable).
   */
  password: string
  /** Whether the auth gate is on (both credentials non-empty). */
  authEnabled: boolean
  /** Whether a persisted runtime override exists on top of the cordis config. */
  persisted: boolean
}

/** Settings-section patch: only fields present are changed; omitted fields keep their values. */
export interface LanProxyUpdatePayload {
  /** New proxy listen port (1–65535, must differ from the default service port). */
  listenPort?: number
  /**
   * Deprecated: new forward target port, kept so legacy persisted configs
   * and scripts still apply. The settings page no longer edits it — the
   * editable port is the proxy's own listen port.
   */
  upstreamPort?: number
  /** New login username. */
  username?: string
  /** New login password; an empty string clears it (auth needs a non-empty pair to stay on). */
  password?: string
}

/** Successful update response. */
export interface LanProxyUpdateResult {
  /** The status after the forwarding service restarted (or stayed stopped). */
  status: LanProxyStatus
  /**
   * Machine-readable outcome the settings page localizes into the UI language:
   * `saved`/`credentials-partial-saved` mean the service was stopped and was
   * merely saved (no restart); the `*-restarted` variants mean it was running
   * and got restarted; `saved-restart-failed` means a running service failed to
   * rebind and the reason rides in `message`.
   */
  notice:
    | 'saved'
    | 'saved-restarted'
    | 'saved-restart-failed'
    | 'credentials-partial-saved'
    | 'credentials-partial-restarted'
  /**
   * Deprecated human-readable confirmation (Chinese); kept for scripts. When
   * `notice` is `saved-restart-failed`, this carries the rebind error reason.
   */
  message: string
}
