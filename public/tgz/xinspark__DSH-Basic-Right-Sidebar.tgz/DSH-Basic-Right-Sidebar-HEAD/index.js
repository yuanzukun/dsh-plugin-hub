// dsh-basic-right-sidebar host half
// 提供会话数据接口与设置持久化：
//   GET  /basrs/session-log-stats  会话日志统计（时间跨度/事件计数/大小/创建时间）
//   GET  /basrs/todos-last         最后写入的任务快照
//   GET/POST /bsrs-settings        设置读写（$DSH_HOME/plugins/dsh-basic-right-sidebar/settings.json）
// 后台任务列表无接口：客户端直接读会话快照（jobsBySession），与原生顶栏同源同形。
//
// 设置持久化说明：DSH 官方设置线对命名空间有硬编码白名单（api-proxy 的
// WEB_SETTINGS_NAMESPACES），第三方插件命名空间不在其中——浏览器端 describe 看不到、
// mutate 会被拒绝（settings-not-exposed）。因此本插件自带持久化端点，客户端 fetch 读写。
// 另注册 dsh-basic-right-sidebar 命名空间（无害；DSH 未来若改为 register 即暴露时可立即生效）。
import z from '@deepseek-ai/schemastery'
import { readFile, writeFile, mkdir } from 'node:fs/promises'
import { join, dirname } from 'node:path'
import { homedir } from 'node:os'

const BSR_SETTINGS_NAMESPACE = 'dsh-basic-right-sidebar'
// 字段名必须与客户端 bsrSettingsState 完全一致：
// defaultOpen / hideHeaderExtras（总开关）/ hideLog·hideMode·hideSubagents·hideJobs·hideTabs（可选隐藏项）/ showBreadcrumb
const bsrSettingsSchema = z.object({
  defaultOpen: z.boolean().default(true),
  hideHeaderExtras: z.boolean().default(true),
  hideLog: z.boolean().default(true),
  hideMode: z.boolean().default(true),
  hideSubagents: z.boolean().default(true),
  hideJobs: z.boolean().default(true),
  hideTabs: z.boolean().default(true),
  showBreadcrumb: z.boolean().default(true),
})
const BSR_SETTINGS_FILE = join(
  process.env.DSH_HOME ?? join(homedir(), '.dsh'),
  'plugins', 'dsh-basic-right-sidebar', 'settings.json',
)
const BSR_SETTINGS_KEYS = [
  'defaultOpen', 'hideHeaderExtras',
  'hideLog', 'hideMode', 'hideSubagents', 'hideJobs', 'hideTabs',
  'showBreadcrumb',
]

// 读设置文件（不存在/损坏 → {}）
async function readSettings() {
  try {
    const text = await readFile(BSR_SETTINGS_FILE, 'utf8')
    const j = JSON.parse(text)
    return j && typeof j === 'object' && !Array.isArray(j) ? j : {}
  } catch {
    return {}
  }
}

// 写设置文件（只保留已知布尔字段，原子替换）
async function writeSettings(value) {
  await mkdir(dirname(BSR_SETTINGS_FILE), { recursive: true })
  const cleaned = {}
  for (const key of BSR_SETTINGS_KEYS) {
    if (typeof value[key] === 'boolean') cleaned[key] = value[key]
  }
  await writeFile(BSR_SETTINGS_FILE, JSON.stringify(cleaned, null, 2) + '\n', 'utf8')
  return cleaned
}

export const name = 'dsh-basic-right-sidebar'

export const inject = ['webServer']

function toJson(req, res, value) {
  res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(value))
}

// 后台任务列表：客户端已改走会话快照（jobsBySession）直读，不再需要本接口，故已移除。
// 如需恢复调试接口，可参照下方 sessionLogStats 的模式实现（jobs.list(caller) 取任务）。

// 会话日志统计：读持久化日志工件（session.jsonl），逐行统计事件类型/时间跨度/大小。
// 与原生下载（GET /api/session.export）同一份日志来源；live 会话先过 flush 屏障。
async function sessionLogStats(ctx, sessionId) {
  if (typeof sessionId !== 'string' || sessionId === '') return null
  const persistence = ctx.get('sessionPersistence')
  if (persistence === undefined) return null
  try {
    const sessions = ctx.get('sessions')
    if (sessions !== undefined) {
      const live = sessions.get(sessionId)
      if (live !== undefined) await sessions.flush(live)
    }
    const raw = await persistence.readRaw(sessionId)
    if (raw === undefined) return null
    const content = raw.content
    const counts = {}
    let headerLines = 0, eventLines = 0
    let firstTime = null, lastTime = null
    let createdAt = null
    for (const line of content.split('\n')) {
      if (line === '') continue
      let obj
      try { obj = JSON.parse(line) } catch { continue }
      const type = obj && typeof obj.type === 'string' ? obj.type : null
      // header 行（{"type":"session",...}）与无 type 行均归 header；事件行必有 seq/time
      if (type === null || type === 'session') {
        headerLines += 1
        // 首行 header 携带创建时间（HeaderLine.createdAt），供前端「创建时间」展示
        if (type === 'session' && createdAt === null && typeof obj.createdAt === 'number') createdAt = obj.createdAt
        continue
      }
      eventLines += 1
      counts[type] = (counts[type] || 0) + 1
      const time = obj.time
      if (typeof time === 'number') {
        if (firstTime === null || time < firstTime) firstTime = time
        if (lastTime === null || time > lastTime) lastTime = time
      }
    }
    return {
      headerLines,
      eventLines,
      totalLines: headerLines + eventLines,
      counts,
      firstTime,
      lastTime,
      createdAt,
      bytes: new TextEncoder().encode(content).byteLength,
    }
  } catch (err) {
    throw new Error(err && err.message ? err.message : 'session log stats failed')
  }
}

// 最后写入的 todo 快照：解析日志中最后一条 todo/write 事件（跨轮持久，
// 因为 todos 投影为 per-turn 语义：turn/start 时清空）。同源 session.jsonl。
async function todosLast(ctx, sessionId) {
  if (typeof sessionId !== 'string' || sessionId === '') return null
  const persistence = ctx.get('sessionPersistence')
  if (persistence === undefined) return null
  try {
    const sessions = ctx.get('sessions')
    if (sessions !== undefined) {
      const live = sessions.get(sessionId)
      if (live !== undefined) await sessions.flush(live)
    }
    const raw = await persistence.readRaw(sessionId)
    if (raw === undefined) return null
    let last = null
    for (const line of raw.content.split('\n')) {
      if (line === '') continue
      let obj
      try { obj = JSON.parse(line) } catch { continue }
      if (obj && obj.type === 'todo/write' && obj.data && Array.isArray(obj.data.todos)) {
        last = {
          todos: obj.data.todos.map((t) => ({
            content: t && typeof t.content === 'string' ? t.content : String(t && t.content !== undefined ? t.content : ''),
            status: t && typeof t.status === 'string' ? t.status : 'pending',
          })),
          time: typeof obj.time === 'number' ? obj.time : null,
        }
      }
    }
    return last
  } catch (err) {
    throw new Error(err && err.message ? err.message : 'todos last failed')
  }
}

export function apply(ctx) {
  // 注册设置命名空间：settings 服务就绪后执行（不阻塞 apply），随插件纤维卸载自动注销；
  // 宿主无 settings 服务时静默跳过，插件其余功能不受影响。
  ctx.inject(['settings'], (sctx) => {
    try {
      sctx.settings.register(BSR_SETTINGS_NAMESPACE, bsrSettingsSchema)
    } catch (err) {
      if (ctx.logger) ctx.logger.warn('dsh-basic-right-sidebar: settings register failed: %s', err && err.message ? err.message : String(err))
    }
  })
  ctx.effect(() => ctx.webServer.register({
    kind: 'prefix',
    path: '/basrs',
    handler: async (req, res) => {
      const pathname = new URL(req.url ?? '/', 'http://x').pathname
      const sessionId = new URL(req.url ?? '/', 'http://x').searchParams.get('sessionId')
      let value
      try {
        if (pathname === '/basrs/session-log-stats') {
          value = await sessionLogStats(ctx, sessionId)
        } else if (pathname === '/basrs/todos-last') {
          value = await todosLast(ctx, sessionId)
        } else {
          res.writeHead(404)
          res.end('basrs: not found')
          return
        }
      } catch (err) {
        res.writeHead(500, { 'content-type': 'application/json; charset=utf-8' })
        res.end(JSON.stringify({ error: err && err.message ? err.message : 'basrs: failed' }))
        return
      }
      toJson(req, res, value)
    },
  }), 'basrs: http routes')
  // 设置持久化端点：GET/POST /bsrs-settings，读写 settings.json（$DSH_HOME 下）。
  ctx.effect(() => ctx.webServer.register({
    kind: 'prefix',
    path: '/bsrs-settings',
    handler: async (req, res) => {
      const pathname = new URL(req.url ?? '/', 'http://x').pathname
      if (pathname === '/bsrs-settings' && req.method === 'GET') {
        toJson(req, res, await readSettings())
        return
      }
      if (pathname === '/bsrs-settings' && req.method === 'POST') {
        let raw = ''
        for await (const chunk of req) raw += typeof chunk === 'string' ? chunk : Buffer.from(chunk).toString('utf8')
        let next
        try {
          next = JSON.parse(raw || '{}')
        } catch {
          res.writeHead(400)
          res.end('bsrs-settings: bad json')
          return
        }
        if (typeof next !== 'object' || next === null || Array.isArray(next)) {
          res.writeHead(400)
          res.end('bsrs-settings: bad shape')
          return
        }
        try {
          const cleaned = await writeSettings(next)
          toJson(req, res, cleaned)
        } catch (err) {
          res.writeHead(500, { 'content-type': 'text/plain; charset=utf-8' })
          res.end('bsrs-settings: write failed: ' + (err && err.message ? err.message : String(err)))
        }
        return
      }
      res.writeHead(404)
      res.end('bsrs-settings: not found')
    },
  }), 'basrs: settings route')
}
