<p align="center">
  <img src="docs/screenshots/image-7.png" alt="Basic Right Sidebar preview" width="100%">
</p>

<p align="center">
  <img src="https://img.shields.io/github/v/release/xinspark/DSH-Basic-Right-Sidebar?style=flat&amp;label=release&amp;color=08C" alt="GitHub release">
  <img src="https://img.shields.io/badge/plugin-UI%20enhancement-47848F?style=flat" alt="UI enhancement plugin">
  <img src="https://img.shields.io/badge/DSH%20Web%20GUI-Windows%20%7C%20macOS%20%7C%20Linux-4493F8?style=flat" alt="Windows | macOS | Linux">
  <img src="https://img.shields.io/badge/license-MIT-2EA44F?style=flat" alt="MIT License">
</p>

<p align="center"><sub><a href="README.md">简体中文</a> · English</sub></p>

<h3 align="center">Bring DSH's native capabilities to the right edge: two-level navigation, session overview with log download, native trajectory view, configurable topbar decluttering</h3>

<p align="center"><a href="#install"><ins><code>dsh plugin --profile web add github:xinspark/DSH-Basic-Right-Sidebar#v1.0.0</code></ins></a></p>

Basic Right Sidebar is a **right sidebar foundation plugin** for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) — pure UI enhancement that introduces no new capabilities: it surfaces DSH's native features inside the right sidebar, and is meant to be the **foundation plugin** every feature-enhancing right sidebar builds on.

The native DSH left sidebar is rich, but when it is collapsed — or when you simply prefer a right-hand workflow — sessions, workspaces and panel switches become unreachable without extra clicks. This plugin brings those native controls to the right edge of the screen. Installing it also installs the sub-plugin [dsh-better-session-title](https://github.com/xinspark/dsh-better-session-title) (the session-topbar workspace/session breadcrumb).

Works on **Windows · macOS · Linux** (DSH Web GUI) — plain JavaScript, no native dependencies, no build step for distribution.

## Highlights

<table>
  <tr>
    <td width="50%" valign="top">
      <h3>Two-level navigation</h3>
      <p>Functions / Sessions menus switch panels (Overview · Trajectory / Overview). Everything is one click away from the sidebar header.</p>
    </td>
    <td width="50%" valign="top">
      <h3>Workspace/session breadcrumb</h3>
      <p>Switch workspaces and sessions right from the session topbar; no need to expand the left sidebar. Provided by the <a href="https://github.com/xinspark/dsh-better-session-title">dsh-better-session-title</a> sub-plugin (native menu/dialog interactions); this plugin's "Show workspace/session breadcrumb" setting controls it live.</p>
    </td>
  </tr>
  <tr>
    <td width="50%" valign="top">
      <h3>Session overview</h3>
      <p>Session meta info, log stats (time span, event counts, size) and one-click log download (zip).</p>
    </td>
    <td width="50%" valign="top">
      <h3>Native trajectory view</h3>
      <p>Pixel-identical with the DSH native trajectory UI (official component, vendored and lazy-loaded); no system source changes required.</p>
    </td>
  </tr>
  <tr>
    <td width="50%" valign="top">
      <h3>Configurable topbar decluttering</h3>
      <p>Hide duplicated topbar elements individually: session log · session mode · subagents · background jobs · chat/trajectory tab bar.</p>
    </td>
    <td width="50%" valign="top">
      <h3>Built-in foundations</h3>
      <p>An icon library (native-first) and a reusable component library ship with the plugin, so extending the sidebar is a matter of writing components, not fighting the DOM. The sidebar supports expand/collapse and fullscreen, and opens by default after load (a manual collapse is always respected).</p>
    </td>
  </tr>
</table>

## Screenshots

Right sidebar UI in the session view:

**Function area / Overview (non-fullscreen)**

![Function area / Overview](docs/screenshots/image-7.png)

**Function area / Trajectory (non-fullscreen)**

![Function area / Trajectory](docs/screenshots/image-8.png)

**Session management / Overview (non-fullscreen)**

![Session management / Overview](docs/screenshots/image-9.png)

**Function area / Trajectory (fullscreen)**

![Function area / Trajectory (fullscreen)](docs/screenshots/image-10.png)

**Right sidebar collapsed**

![Right sidebar collapsed](docs/screenshots/image-11.png)

**Plugin configuration UI**

![Plugin configuration UI](docs/screenshots/image-12.png)

![Plugin configuration UI (continued)](docs/screenshots/image-13.png)

## Install

`dsh-basic-right-sidebar` is a **bundle** — a configuration patch layer distributed as a package (see the [official DSH plugin publishing docs](https://deepseek-harness.github.io/deepseek-harness/develop/basic/publish)). Install it into a profile with the `dsh plugin` command — it links the package and appends it to `dsh.profile.bundles` automatically:

```sh
# from GitHub (primary channel; v1.0.0 is the current release tag)
dsh plugin --profile web add github:xinspark/DSH-Basic-Right-Sidebar#v1.0.0
```

- **Consider locking a commit**: a GitHub install pulls the repository source, so later pushes don't silently change what you run. To pin the exact content, use `github:xinspark/DSH-Basic-Right-Sidebar#<commit-sha>` (as recommended by the official docs).
- **Local directory / tarball** (development or offline):

  ```sh
  dsh plugin --profile web add ./dsh-basic-right-sidebar
  dsh plugin --profile web add ./dsh-basic-right-sidebar-1.0.0.tgz
  ```

Then start the web UI: `dsh web` (or `dsh --profile web`). The first `add` initializes the profile with `@deepseek-ai/dsh-base` automatically.

**The sub-plugin comes along**: this bundle's `cordis.patch.yml` inserts both the `dsh-basic-right-sidebar` and `dsh-better-session-title` rows. The sub-plugin is declared as a **GitHub git dependency** in `package.json`'s `dependencies` (commit-SHA locked, so upstream pushes can't silently change behavior); pnpm fetches it when you install this bundle — one command, both plugins. Do not `dsh plugin add dsh-better-session-title` separately (`insert` appends, so you would end up with duplicate plugin rows).

> **One-time pnpm security setting required**: pnpm ≥10.6 enables `blockExoticSubdeps` by default, which refuses to install packages that have git-spec **sub-dependencies** (which is exactly how this plugin ships its sub-plugin) — you'd see an error like `ERR_PNPM_EXOTIC_SUBDEP`. If that happens, append one line to the profile's `pnpm-workspace.yaml` (e.g. `$DSH_HOME/profiles/web/pnpm-workspace.yaml`) and re-run the install command:
>
> ```yaml
> blockExoticSubdeps: false
> ```
>
> It is a one-time, profile-level setting (DSH's own template doesn't include it). This plugin is plain JS with no lifecycle scripts, so no `allowBuilds` approval is needed.

- **Local development (editing both plugins)**: pnpm does not see local edits through a git dependency, so add the child as a **direct profile dependency** instead. **Install it with `--save-dev` into devDependencies**: `dsh plugin`'s bundle reconciliation only scans `dependencies`, so a child in `dependencies` would be auto-promoted into its own bundle layer by the next `dsh plugin` command — duplicating the row the parent bundle inserts:

  ```sh
  dsh plugin --profile web add ./dsh-basic-right-sidebar
  pnpm --dir "$DSH_HOME/profiles/web" add -w --save-dev link:"$DSH_HOME/plugins/dsh-better-session-title"
  ```

  If the child already landed in `dependencies` or `dsh.profile.bundles`: move it from `dependencies` to `devDependencies` in `package.json` and remove the package name from `dsh.profile.bundles`.
- **Upgrading the sub-plugin**: update the commit SHA (or tag) in the `package.json` dependency to a newer commit of the dsh-better-session-title repository.
- **Removal**: `dsh plugin --profile web remove dsh-basic-right-sidebar` plus `pnpm --dir "$DSH_HOME/profiles/web" remove dsh-better-session-title`.

The plugin's bundle patch (`cordis.patch.yml`) registers the host and client rows automatically. The browser half is served per-request, so client-side changes only need a page refresh; host-side changes need a restart.

## Configure

Open **Settings → Plugins → Basic Right Sidebar**:

| Option | Description |
| --- | --- |
| Open right sidebar by default | Auto-expand the sidebar on load; manual collapse is never overridden. |
| Hide duplicated session topbar elements | Master switch; when on, choose which of the following to hide: **session log · session mode · subagents · background jobs · chat/trajectory tab bar**. |
| Show workspace/session breadcrumb | The breadcrumb on the left of the session topbar (provided by the dsh-better-session-title sub-plugin); off restores the native topbar. |

Settings persist to `$DSH_HOME/plugins/dsh-basic-right-sidebar/settings.json`. The plugin ships its own persistence endpoint (`/bsrs-settings`): DSH's settings wire only exposes an allowlisted set of namespaces, so third-party namespaces cannot use it.

## Relationship with dsh-better-session-title

This plugin ships [dsh-better-session-title](https://github.com/xinspark/dsh-better-session-title) as a **sub-plugin**: `package.json` declares it in `dependencies` (git dependency, commit-locked), and `cordis.patch.yml` inserts its plugin row together with this bundle. The topbar breadcrumb is **exclusively provided by the sub-plugin** (registered into `conversation.session.header.actions`); this plugin's "Show workspace/session breadcrumb" setting is bridged to it via the `window.__BASRS_SETTINGS__` snapshot and the `'basrs:settings'` event — when off, the sub-plugin hides the breadcrumb and restores the native title.

- **If you installed this plugin, do not install the sub-plugin separately** — two bundles inserting the same plugin row duplicate it.
- The sub-plugin can also be **installed standalone** (without the parent plugin the settings bridge defaults to enabled).
- If both bundles are installed, turn off the breadcrumb on either side.

## Relationship with DSH

Basic Right Sidebar is a **community plugin built on the official [deepseek-ai/deepseek-harness](https://github.com/deepseek-ai/deepseek-harness)** — it is not an official DeepSeek product.

Everything it shows is DSH's own data and UI, re-arranged:

- The sidebar is rendered into the official `details` slot; the toggle into `conversation.session.header.utilities`; the config card into `settings.plugin.item`; the topbar breadcrumb into `conversation.session.header.actions` via the `dsh-better-session-title` sub-plugin.
- The trajectory view is the official DSH trajectory component, vendored and lazy-loaded — pixel-identical, no system source changes.
- The icon library prefers native icons so the sidebar never looks alien next to the official UI.

If you prefer the command line, or you want to contribute to the core, use the official repository.

## Develop

- **`index.js`** — host half: session log stats, last-todos snapshot, and settings persistence (`GET/POST /bsrs-settings`).
- **`lib/client.js`** — browser half (UMD, registered into DSH `clientModules`). Structure, top to bottom:
  1. Vendored official trajectory view (lazy-loaded; normally you don't touch it).
  2. **Icon library** (`createIconLibrary`) — native icons preferred; add new icons per the rules at the top of the library.
  3. **Component library** (`createComponentLibrary`) — `SectionCard`, dropdown menus (`MenuItem`/`MenuPop`/`MoreMenu`/`DropdownList`), `Tag`, `StateDot`, `TodoList`/`TodoGlyph`/`ProgressGlyph`, task-status normalization, time formatting, shared CSS. `DropdownList` is absorbed from the dsh-better-session-title sub-plugin (self-drawn data-driven dropdown: fixed positioning + viewport avoidance / click-outside close / inline meta + hover more button); the icon library already covers every native icon the sub-plugin's breadcrumb uses (including the `chevronDownOutline14`/`chevronUpOutline14`/`ellipsis16` naming-aligned aliases).
  4. `apply(ctx)` — registers the slots: `details` (sidebar), `conversation.session.header.utilities` (sidebar toggle), `settings.plugin.item` (config card); ships built-in zh/en dictionaries that follow DSH's language switch. The topbar breadcrumb (`header.actions`) is registered by the sub-plugin.
- **`dsh-better-session-title` sub-plugin** — a separate package (git dependency declared in `package.json`, its row inserted by `cordis.patch.yml`). Its client half registers the `conversation.session.header.actions` breadcrumb; the parent's `showBreadcrumb` setting is bridged to it via the `window.__BASRS_SETTINGS__` snapshot and the `'basrs:settings'` event. Its code lives in the [dsh-better-session-title](https://github.com/xinspark/dsh-better-session-title) repository.

Extension cheatsheet:

- **Add a panel** — add an entry to the `panels` list in `apply` and write the render component.
- **Add copy** — add a key to `BSR_ZH` / `BSR_EN`.
- **Add an icon** — register it in the icon library (native first, custom fallback).

## Community

- [GitHub Issues](https://github.com/xinspark/DSH-Basic-Right-Sidebar/issues) — bugs, feature requests and questions.
- [GitHub Discussions](https://github.com/xinspark/DSH-Basic-Right-Sidebar/discussions) — ideas and general talk about extending the sidebar.
- Topic [`dsh-plugin`](https://github.com/topics/dsh-plugin) — the community plugin topic this project is tagged with.

### Ecosystem

Projects and resources around the DeepSeek Harness ecosystem that we find useful:

| Project | What it is | Link |
| --- | --- | --- |
| DeepSeek Harness | The official project: "Everything is a Plugin." | [GitHub](https://github.com/deepseek-ai/deepseek-harness) |
| dsh-TUI | Full-screen interactive terminal UI for DSH. | [GitHub](https://github.com/ccch1mneyyy/dsh-TUI) |
| Awesome DSH Plugin | Community-curated list of DSH plugins. | [GitHub](https://github.com/AdamPlatin123/awesome-dsh-plugins) |
| dsh-market | Plugin marketplace covering 1500+ DSH plugins. | [GitHub](https://github.com/2BingLing/dsh-market) |
| DSH-Plugins-Marketplace | In-GUI plugin marketplace built on the `dsh-plugin` topic. | [GitHub](https://github.com/bradeGithub/DSH-Plugins-Marketplace) |

Want your project listed here? Open a PR or start a Discussion.

## Acknowledgments

Thanks to [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) and the DeepSeek AI team — the agent, models, tools, sessions, Web UI and plugin ecosystem all come from this project; to [Cordis](https://github.com/cordiverse/cordis) for the plugin foundation; and to the [Koishi.js](https://koishi.chat/) community for its long-standing plugin practices, tooling and experience.

## License

[MIT](LICENSE) — free and open source.

Basic Right Sidebar is a community plugin for DeepSeek Harness; it is **not** an official DeepSeek product. If someone tries to sell you this plugin, please refuse.
