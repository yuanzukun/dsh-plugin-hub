"""
把已生成的 25 个输出文件夹改成中文可读名 + 保留原有时间戳。

名字逐个按 manifest.json 里的 `material` 人工定（英文材质描述 -> 简短中文），
而不是机翻，避免出现"淡蓝奶油釉面陶瓷"这种虽然对但很长的名字。

写 _RENAME_MAP.csv 记录映射，便于回查。
"""

from __future__ import annotations

import csv
import json
import os

ROOT = r"D:\DSH材质\000材质"

# old-folder-name  ->  中文名（不含时间戳）
ZH = {
    '0ef7dedd86ca-20261027-112111': '深色枪灰抛光镀铬油润',
    '10a719212ca1-20261027-120010': '空文件夹_无manifest',
    '22de8fc2597f-20261016-184017': '白色漆面金属薄涂',
    '22de8fc2597f-20261016-184143': '米白漆面钢板',
    '22de8fc2597f-20261016-184503': '米白缎面漆金属',
    '22de8fc2597f-20261016-184855': '米白粉末喷涂钢板',
    '22de8fc2597f-20261016-185011': '米白漆面金属板',
    '22de8fc2597f-20261016-185123': '米白漆面金属板B',
    '28d228253046-20261016-161602': '浅灰米色漆面金属',
    '28d228253046-20261016-162158': '浅奶油灰漆面厚涂',
    '3b60344ce4ea-20261027-122248': '橙红漆面带条纹',
    '42364bfb6d91-20261016-162648': '深炭灰漆面金属',
    'ab13d4e225d6-20261104-164332': '彩虹氧化铋晶体膜',
    'b848b59250a4-20261016-190034': '风化石灰色浇筑混凝土',
    'b848b59250a4-20261016-190239': '斑驳灰色铸造混凝土A',
    'b848b59250a4-20261016-190528': '斑驳灰色铸造混凝土B',
    'ba33c3b35b02-20261016-164902': '中灰色石板铺装',
    'ba33c3b35b02-20261016-165020': '中灰风化石板路',
    'c70fad9bf487-20261016-180425': '淡蓝奶油釉面陶瓷',
    'c70fad9bf487-20261016-180601': '淡蓝绿泛白釉面',
    'e5e25ff62fa0-20261016-185452': '哑光深灰钢表面',
    'e5e25ff62fa0-20261016-185623': '深灰缎面漆铸件A',
    'e5e25ff62fa0-20261016-185812': '深灰缎面漆铸件B',
    'e954a97c907c-20261016-165214': '风化浅奶油黄漆面',
    'f1f552ab492a-20261016-163127': '深炭灰近黑漆面',
}


def main(apply: bool) -> int:
    if not os.path.isdir(ROOT):
        print(f'目录不存在: {ROOT}')
        return 1

    present = {d for d in os.listdir(ROOT) if os.path.isdir(os.path.join(ROOT, d))}
    rows, missing = [], []
    for old, zh in ZH.items():
        if old not in present:
            missing.append(old)
            continue
        stamp = old.rsplit('-', 2)[-2] + '-' + old.rsplit('-', 1)[-1]
        target = f'{zh}-{stamp}'
        rows.append((old, target, ''))

    # 目录里还有 manifest 之外的东西也报出来，不做处理
    leftover = sorted(present - set(ZH))

    print(f'{"旧名":<34} -> 新名')
    print('-' * 80)
    for old, new, _ in rows:
        print(f'{old:<34} -> {new}')

    if missing:
        print(f'\n! 以下旧名在磁盘上找不到（可能已改过）: {missing}')
    if leftover:
        print(f'\n! 未在映射里的目录（保持不动）: {leftover}')

    if not apply:
        print(f'\n共 {len(rows)} 个待改名。(试运行，加 --apply 执行)')
        return 0

    log = os.path.join(ROOT, '_RENAME_MAP.csv')
    with open(log, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['old', 'new'])
        w.writerows([(o, n) for o, n, _ in rows])

    done, failed = 0, []
    for old, new, _ in rows:
        try:
            os.rename(os.path.join(ROOT, old), os.path.join(ROOT, new))
            done += 1
        except Exception as exc:  # noqa: BLE001
            failed.append((old, str(exc)))
    print(f'\n已改名 {done} 个，失败 {len(failed)} 个')
    for old, err in failed:
        print(f'  FAIL {old}: {err}')
    print(f'映射记录: {log}')
    return 0


if __name__ == '__main__':
    import sys
    raise SystemExit(main('--apply' in sys.argv))
