"""
把已经生成的 PBR 输出文件夹从 `<会话id>-<日期>-<时间>` 改成可读的名字。

命名规则与新代码一致：<材质描述的前几个关键词>-<日期>-<时间>
例：Iridescent bismuth oxide film in deep blue, gold, magenta and teal...
    -> iridescent-bismuth-oxide-film-deep-20261104-164332

读 manifest.json 的 `material` 字段（英文、纯 ASCII，安全）。没有 manifest 或没有
material 的，退化为 unknown-material-<stamp>，不会丢东西。

同时写 _RENAME_MAP.csv 记录 旧名 -> 新名，便于回查。
"""

from __future__ import annotations

import csv
import json
import os
import re
import sys

ROOT = r"D:\DSH材质\000材质"

STOP = {
    'a', 'an', 'the', 'of', 'in', 'on', 'at', 'to', 'for', 'from', 'by', 'with',
    'and', 'or', 'over', 'into', 'plus', 'is', 'are', 'its', 'that', 'this',
    'it', 'as', 'some', 'very', 'heavily', 'slightly', 'light', 'overall',
}


def material_slug(material: str, max_words: int = 5) -> str:
    tokens = re.sub(r'[^\w\u4e00-\u9fff]+', ' ', str(material or '')).strip().lower().split()
    tokens = [t for t in tokens if t and t not in STOP]
    return '-'.join(tokens[:max_words])[:48]


def stamp_from(name: str) -> str:
    m = re.search(r'(\d{8})-(\d{6})$', name)
    return f'{m.group(1)}-{m.group(2)}' if m else 'nostamp'


def main(apply: bool) -> int:
    if not os.path.isdir(ROOT):
        print(f'目录不存在: {ROOT}')
        return 1

    rows = []
    used = set()
    for name in sorted(os.listdir(ROOT)):
        full = os.path.join(ROOT, name)
        if not os.path.isdir(full):
            continue
        stamp = stamp_from(name)
        material = ''
        mf = os.path.join(full, 'manifest.json')
        if os.path.exists(mf):
            try:
                with open(mf, encoding='utf-8', errors='replace') as fh:
                    material = (json.load(fh) or {}).get('material') or ''
            except Exception as exc:  # noqa: BLE001
                print(f'  ! manifest 读不出: {name} ({exc})')
        slug = material_slug(material) or 'unknown-material'
        target = f'{slug}-{stamp}'
        base, n = target, 2
        while target in used or (os.path.exists(os.path.join(ROOT, target)) and target != name):
            target = f'{base}-{n}'
            n += 1
        used.add(target)
        rows.append((name, target, material[:70]))

    width = max((len(r[1]) for r in rows), default=10)
    print(f'{"旧名":<34} -> {"新名"}')
    print('-' * (34 + 4 + width))
    for old, new, _ in rows:
        mark = '' if old == new else '  *'
        print(f'{old:<34} -> {new}{mark}')
    print(f'\n共 {len(rows)} 个，{sum(1 for r in rows if r[0] != r[1])} 个需要改名')

    if not apply:
        print('\n(试运行，未改动。加 --apply 执行)')
        return 0

    log_path = os.path.join(ROOT, '_RENAME_MAP.csv')
    with open(log_path, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['old', 'new', 'material'])
        w.writerows(rows)

    done = 0
    for old, new, _ in rows:
        if old == new:
            continue
        try:
            os.rename(os.path.join(ROOT, old), os.path.join(ROOT, new))
            done += 1
        except Exception as exc:  # noqa: BLE001
            print(f'  改名失败 {old}: {exc}')
    print(f'\n已改名 {done} 个。映射写入 {log_path}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main('--apply' in sys.argv))
