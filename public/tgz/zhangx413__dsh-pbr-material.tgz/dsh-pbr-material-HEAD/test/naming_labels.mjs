/**
 * Folder naming: the label must be readable without the user having to invent one.
 *
 * This is a pure-function test on purpose - the previous round of this bug was a
 * naming rule that could only be checked by running a 30 s generation job, which
 * is exactly how `ab13d4e225d6-20261104-164332` survived 25 runs.
 */
import assert from 'node:assert/strict'
import test from 'node:test'

import { resolveJobLabel } from '../lib/pipeline.js'
import { cleanTitle, titleFromMaterial } from '../lib/draft.js'

test('an explicit name wins over everything', () => {
  assert.equal(
    resolveJobLabel({ name: '龟裂水泥地', title: '忽略我', material: 'grey concrete', imagePath: 'x.png' }),
    '龟裂水泥地',
  )
})

test('a short title from the drafting model beats the material slug', () => {
  assert.equal(
    resolveJobLabel({ title: '做旧橙红漆面', material: 'heavily worn orange-red paint on metal' }),
    '做旧橙红漆面',
  )
})

test('without a title the material description is used, not the upload id', () => {
  const label = resolveJobLabel({
    material: 'Iridescent bismuth oxide film in deep blue, gold, magenta and teal',
    imagePath: 'D:/tmp/ab13d4e225d6.png',
  })
  assert.equal(label, 'iridescent-bismuth-oxide-film-deep')
  assert.ok(!label.includes('ab13d4e225d6'), 'the upload id must never leak into a label')
})

test('glue words are dropped from the material slug', () => {
  // "surface" is not a glue word, so it stays - the point is that a/an/and/very go.
  assert.equal(
    resolveJobLabel({ material: 'a worn and very dark grey steel surface' }),
    'worn-dark-grey-steel-surface',
  )
})

test('falling all the way back to the image stem still avoids the id when the stem is readable', () => {
  assert.equal(resolveJobLabel({ imagePath: 'D:/tmp/old-concrete.png' }), 'old-concrete')
})

test('an empty everything still yields a usable label', () => {
  assert.equal(resolveJobLabel({}), 'material')
})

test('cleanTitle strips the ways a small model dresses up the answer', () => {
  assert.equal(cleanTitle('"做旧橙红漆面"'), '做旧橙红漆面')
  assert.equal(cleanTitle('```\n做旧橙红漆面\n```'), '做旧橙红漆面')
  assert.equal(cleanTitle('名字：做旧橙红漆面。'), '名字：做旧橙红漆面')
  assert.equal(cleanTitle('灰色龟裂水泥\n'), '灰色龟裂水泥')
})

test('cleanTitle makes the result filesystem-safe and short', () => {
  const t = cleanTitle('灰/色\\龟裂:水泥*表面?纹理')
  assert.equal(t, '灰色龟裂水泥表面纹理')
  assert.equal([...cleanTitle('一二三四五六七八九十一二三四五六七八九十')].length, 16)
})

test('cleanTitle refuses an empty answer', () => {
  assert.equal(cleanTitle(''), '')
  assert.equal(cleanTitle('   \n\n  '), '')
})

test('titleFromMaterial degrades to null instead of throwing', async () => {
  assert.equal(await titleFromMaterial(null, { material: 'grey concrete' }), null)
  assert.equal(await titleFromMaterial({}, { material: 'grey concrete' }), null)
  assert.equal(await titleFromMaterial({ get: () => undefined }, { material: 'grey concrete' }), null)
  // no material yet -> nothing to name
  assert.equal(await titleFromMaterial({ get: () => ({}) }, { material: '   ' }), null)
})
