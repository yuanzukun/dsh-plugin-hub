import assert from 'node:assert/strict'
import test from 'node:test'
import { messageHash } from '../lib/context.js'
import {
  diffAgainstSnapshot,
  normalizeSnapshotMarker,
  parseSnapshotBlocks,
  snapshotOf,
  splitAutoBlocks,
  stripMarkersInMessages,
  stripSnapshotMarkers,
} from '../lib/snapshot-diff.js'

const MARKER = '9F3C7A1E5B2D'
const B = `<<<STB-${MARKER}:B>>>`
const E = `<<<STB-${MARKER}:E>>>`
const wrap = (...blocks) => blocks.map(text => `${B}\n${text}\n${E}`).join('\n')
const msg = (role, text) => ({ role, text, hash: messageHash(role, text) })

test('marker normalization only accepts 8-32 uppercase hex', () => {
  assert.equal(normalizeSnapshotMarker('stb-9f3c7a1e5b2d'), '9F3C7A1E5B2D')
  assert.equal(normalizeSnapshotMarker('9f3c7a1e5b2d'), '9F3C7A1E5B2D')
  assert.equal(normalizeSnapshotMarker(''), '')
  assert.equal(normalizeSnapshotMarker('xyz'), '')
  assert.equal(normalizeSnapshotMarker(123), '')
})

test('parse requires paired markers and no text outside', () => {
  const parsed = parseSnapshotBlocks(wrap('A', 'B'), MARKER)
  assert.equal(parsed.kind, 'blocks')
  assert.deepEqual(parsed.blocks, ['A', 'B'])
  assert.equal(stripSnapshotMarkers(wrap('A'), MARKER), 'A')

  assert.equal(parseSnapshotBlocks(`${B}A${E} tail`, MARKER).kind, 'ambiguous')
  assert.equal(parseSnapshotBlocks(`${B}A`, MARKER).kind, 'ambiguous')
  assert.equal(parseSnapshotBlocks(`A${E}`, MARKER).kind, 'ambiguous')
  assert.equal(parseSnapshotBlocks(`${B}A${B}B${E}${E}`, MARKER).kind, 'ambiguous')
  assert.equal(parseSnapshotBlocks('plain text', MARKER).kind, 'unmarked')
})

test('diff trims leading/trailing identical blocks and keeps the middle', () => {
  const previous = [msg('system', wrap('FIXED_A', 'OLD_MIDDLE', 'FIXED_B'))]
  const snapshot = { marker: MARKER, turn: 1, messages: snapshotOf(previous, MARKER) }
  const current = [msg('system', wrap('FIXED_A', 'NEW_MIDDLE', 'FIXED_B'))]
  const result = diffAgainstSnapshot(current, snapshot, MARKER)
  assert.ok(result.diagnostic)
  assert.equal(result.diagnostic.trimmed_blocks, 2)
  assert.equal(result.messages[0].text, 'NEW_MIDDLE')
  assert.equal(JSON.stringify(result.diagnostic).includes('FIXED_A'), false)
})

test('diff trims identical leading messages but never empties the turn', () => {
  const previous = [msg('system', 'S1'), msg('user', 'TARGET')]
  const snapshot = { marker: MARKER, turn: 1, messages: snapshotOf(previous, MARKER) }
  const next = [msg('system', 'S1'), msg('user', 'TARGET2')]
  const result = diffAgainstSnapshot(next, snapshot, MARKER)
  assert.equal(result.messages.length, 1)
  assert.equal(result.messages[0].text, 'TARGET2')
  assert.equal(result.diagnostic.trimmed_messages, 1)

  const identical = diffAgainstSnapshot(previous, snapshot, MARKER)
  assert.equal(identical.diagnostic, undefined)
  assert.equal(identical.messages.length, 2)
})

test('no marker, marker change or ambiguous blocks fall back to full', () => {
  const current = [msg('user', 'plain')]
  assert.equal(diffAgainstSnapshot(current, { marker: MARKER, messages: [] }, '').diagnostic, undefined)
  assert.equal(diffAgainstSnapshot(current, { marker: 'STB-AAAAAAAAAAAA', messages: [] }, MARKER).diagnostic, undefined)
  const broken = [msg('system', `${B}only-open`)]
  const snapshot = { marker: MARKER, turn: 1, messages: snapshotOf([msg('system', wrap('X'))], MARKER) }
  const result = diffAgainstSnapshot(broken, snapshot, MARKER)
  assert.equal(result.messages[0].text, `${B}only-open`)
})

test('never trims away every user message', () => {
  const previous = [msg('system', 'S'), msg('user', 'TARGET'), msg('system', 'OLD_TAIL')]
  const snapshot = { marker: MARKER, turn: 1, messages: snapshotOf(previous, MARKER) }
  const current = [msg('system', 'S'), msg('user', 'TARGET'), msg('system', 'NEW_TAIL')]
  const result = diffAgainstSnapshot(current, snapshot, MARKER)
  assert.equal(result.diagnostic.status, 'no-user-after-trim')
  assert.equal(result.messages.length, 3)
  assert.equal(result.messages[1].text, 'TARGET')
})

test('marker tokens are stripped even when blocks are unbalanced', () => {
  const mixed = msg('system', `prefix\n${B}\nA\n${E}\nsuffix`)
  const broken = msg('user', `head ${B} body`)
  const other = msg('system', '<<<STB-AAAAAAAAAAAA:B>>>keep<<<STB-AAAAAAAAAAAA:E>>>')
  const out = stripMarkersInMessages([mixed, broken, other], MARKER)
  assert.equal(out[0].text, 'prefix\n\nA\n\nsuffix')
  assert.equal(out[1].text, 'head  body')
  assert.equal(out[2].text, other.text)
})

test('auto mode splits paragraphs and trims stable head/tail blocks', () => {
  const previous = [msg('system', 'FIXED_A\n\nOLD_MIDDLE\n\nFIXED_B'), msg('user', 'TARGET')]
  const snapshot = { mode: 'auto', marker: '', turn: 1, messages: snapshotOf(previous, { mode: 'auto', maxBlockChars: 2000 }) }
  const current = [msg('system', 'FIXED_A\n\nNEW_MIDDLE\n\nFIXED_B'), msg('user', 'TARGET2')]
  const result = diffAgainstSnapshot(current, snapshot, { mode: 'auto', maxBlockChars: 2000 })
  assert.ok(result.diagnostic)
  assert.equal(result.diagnostic.mode, 'auto')
  assert.equal(result.diagnostic.trimmed_blocks, 2)
  assert.equal(result.messages[0].text, 'NEW_MIDDLE')
})

test('keep token pins blocks against leading/trailing trim', () => {
  const K = '<<<STB-KEEP>>>'
  const previous = [msg('system', 'FIXED_A\n\nOLD_MIDDLE\n\nFIXED_B')]
  const snapshot = { mode: 'auto', marker: '', turn: 1, messages: snapshotOf(previous, { mode: 'auto' }) }

  const middle = [msg('system', `FIXED_A\n\n${K}\nOLD_MIDDLE\n\nNEW_TAIL`)]
  const middleResult = diffAgainstSnapshot(middle, snapshot, { mode: 'auto' })
  assert.equal(middleResult.messages[0].text, 'OLD_MIDDLE\n\nNEW_TAIL')
  assert.equal(middleResult.diagnostic.trimmed_blocks, 1)

  const first = [msg('system', `${K}\nFIXED_A\n\nNEW_MIDDLE\n\nFIXED_B`)]
  const firstResult = diffAgainstSnapshot(first, snapshot, { mode: 'auto' })
  assert.equal(firstResult.messages[0].text, 'FIXED_A\n\nNEW_MIDDLE')
  assert.equal(firstResult.diagnostic.trimmed_blocks, 1)

  const last = [msg('system', `FIXED_A\n\nNEW_MIDDLE\n\n${K}\nFIXED_B`)]
  const lastResult = diffAgainstSnapshot(last, snapshot, { mode: 'auto' })
  assert.equal(lastResult.messages[0].text, 'NEW_MIDDLE\n\nFIXED_B')
  assert.equal(lastResult.diagnostic.trimmed_blocks, 1)
})

test('KEEP prevents whole-message prefix and suffix trimming across changed turns', () => {
  const world = '<<<STB-KEEP>>>\nWORLD_ENTRY_A\n\nWORLD_ENTRY_B\n<<<STB-/KEEP>>>'
  for (const options of [{mode:'auto',marker:MARKER}, {mode:'marker',marker:MARKER}]) {
    for (const marked of [false,true]) {
      const protect = marked ? wrap(world) : world
      for (const position of ['head','tail','both']) {
        const sequence = target => position === 'head' ? [msg('system',protect),msg('user',target)]
          : position === 'tail' ? [msg('user',target),msg('system',protect)]
          : [msg('system','UNPROTECTED_HEADER'),msg('system',protect),msg('user',target),msg('system',protect)]
        const previous = sequence('PREVIOUS_TARGET')
        const result = diffAgainstSnapshot(sequence('NEW_TARGET'), {mode:options.mode,marker:options.marker,turn:1,messages:snapshotOf(previous,options)},options)
        const outgoing = stripMarkersInMessages(result.messages,options.marker)
        const worlds = outgoing.filter(message=>message.text.includes('WORLD_ENTRY_A'))
        assert.equal(worlds.length,position==='both'?2:1)
        assert.ok(worlds.every(message=>message.text.includes('WORLD_ENTRY_B')))
        assert.ok(outgoing.some(message=>message.text==='NEW_TARGET'))
        assert.ok(outgoing.every(message=>!message.text.includes('<<<STB-')))
      }
    }
  }
})

test('worldbook KEEP protects a changed middle and stable surrounding blocks', () => {
  const protect = middle => `<<<STB-KEEP>>>\nWORLD_HEADER\n\n${middle}\n\nWORLD_TAIL\n<<<STB-/KEEP>>>`
  const previous=[msg('system',protect('OLD_ENTRY')),msg('user','OLD_TARGET')]
  const current=[msg('system',protect('NEW_ENTRY')),msg('user','NEW_TARGET')]
  const result=diffAgainstSnapshot(current,{mode:'auto',messages:snapshotOf(previous,{mode:'auto'})},{mode:'auto'})
  const text=stripMarkersInMessages(result.messages,'')[0].text
  assert.equal(text,'WORLD_HEADER\n\nNEW_ENTRY\n\nWORLD_TAIL')
})

test('ordinary repeated messages remain trimmable and an orphan close token grants no KEEP range', () => {
  for (const world of ['WORLD_ENTRY', 'WORLD_ENTRY\n<<<STB-/KEEP>>>']) {
    const previous=[msg('system',world),msg('user','PREVIOUS_TARGET')]
    const result=diffAgainstSnapshot([msg('system',world),msg('user','NEW_TARGET')],{mode:'auto',messages:snapshotOf(previous,{mode:'auto'})},{mode:'auto'})
    assert.deepEqual(result.messages.map(message=>message.role),['user'])
  }
})

test('paired keep tokens pin every block in the range', () => {
  const K = '<<<STB-KEEP>>>'
  const C = '<<<STB-/KEEP>>>'
  const previous = [msg('system', 'FIXED_A\n\nOLD_ONE\n\nOLD_TWO\n\nFIXED_B')]
  const snapshot = { mode: 'auto', marker: '', turn: 1, messages: snapshotOf(previous, { mode: 'auto' }) }
  const current = [msg('system', `FIXED_A\n\n${K}\nNEW_ONE\n\nNEW_TWO\n\n${C}\nFIXED_B`)]
  const result = diffAgainstSnapshot(current, snapshot, { mode: 'auto' })
  assert.equal(result.messages[0].text, 'NEW_ONE\n\nNEW_TWO\n\nFIXED_B')
  assert.equal(result.diagnostic.trimmed_blocks, 1)

  const markerPrevious = [msg('system', wrap('FIXED_A', 'OLD_ONE', 'OLD_TWO', 'FIXED_B'))]
  const markerSnapshot = { marker: MARKER, turn: 1, messages: snapshotOf(markerPrevious, MARKER) }
  const markerCurrent = [msg('system', wrap('FIXED_A', `${K}\nNEW_ONE`, 'NEW_TWO', `${C}\nFIXED_B`))]
  const markerResult = diffAgainstSnapshot(markerCurrent, markerSnapshot, MARKER)
  assert.equal(markerResult.messages[0].text, 'NEW_ONE\n\nNEW_TWO\n\nFIXED_B')
  assert.equal(markerResult.diagnostic.trimmed_blocks, 1)
})

test('keep range tokens are stripped even without a snapshot marker', () => {
  assert.equal(stripSnapshotMarkers('<<<STB-KEEP>>>\nfixed\n<<<STB-/KEEP>>>', ''), 'fixed')
  assert.equal(
    stripSnapshotMarkers('A\n<<<STB-KEEP>>>\nfixed\n<<<STB-/KEEP>>>\nB', ''),
    'A\nfixed\nB',
  )
})

test('keep token works inside explicit marker blocks', () => {
  const K = '<<<STB-KEEP>>>'
  const previous = [msg('system', wrap('FIXED_A', 'OLD_MIDDLE', 'FIXED_B'))]
  const snapshot = { marker: MARKER, turn: 1, messages: snapshotOf(previous, MARKER) }
  const current = [msg('system', wrap('FIXED_A', `${K}\nOLD_MIDDLE`, 'NEW_TAIL'))]
  const result = diffAgainstSnapshot(current, snapshot, MARKER)
  assert.equal(result.messages[0].text, 'OLD_MIDDLE\n\nNEW_TAIL')
  assert.equal(result.diagnostic.trimmed_blocks, 1)
})

test('keep token is transport-only and works without a snapshot marker', () => {
  const K = '<<<STB-KEEP>>>'
  const input = [msg('system', `${K}\nkeep this\n\nplain`)]
  const out = stripMarkersInMessages(input, '')
  assert.equal(out[0].text, 'keep this\n\nplain')
  assert.equal(stripSnapshotMarkers(`${K}\nA`, ''), 'A')
})

test('auto mode splits an oversized paragraph into line groups', () => {
  const long = Array.from({ length: 40 }, (_, index) => `line-${index} ${'x'.repeat(120)}`).join('\n')
  const blocks = splitAutoBlocks(long, { maxBlockChars: 500 })
  assert.ok(blocks.length > 1)
  assert.ok(blocks.every(block => block.text.length <= 700))
  assert.equal(blocks[0].start, 0)
  assert.equal(blocks[blocks.length - 1].end, long.length)
})

test('mode change between snapshots falls back to full', () => {
  const previous = [msg('user', 'A\n\nB')]
  const snapshot = { mode: 'marker', marker: MARKER, turn: 1, messages: snapshotOf(previous, MARKER) }
  const current = [msg('user', 'A\n\nC')]
  assert.equal(diffAgainstSnapshot(current, snapshot, { mode: 'auto' }).diagnostic, undefined)
})

test('long paragraphs become one block per line', () => {
  const text = `${'a'.repeat(300)}\n${'b'.repeat(300)}\n${'c'.repeat(300)}`
  const blocks = splitAutoBlocks(text, { maxBlockChars: 500 })
  assert.equal(blocks.length, 3)
  assert.equal(blocks[0].text.length, 300)
  assert.equal(blocks[1].text.length, 300)
  assert.equal(blocks[2].text.length, 300)
})

test('an oversized single line is split by sentence boundary', () => {
  const sentence = `${'字'.repeat(90)}。`
  const text = sentence.repeat(20)
  const blocks = splitAutoBlocks(text, { maxBlockChars: 300 })
  assert.ok(blocks.length > 1)
  assert.ok(blocks.every(block => block.text.length <= 300))
  assert.equal(blocks[0].start, 0)
  assert.equal(blocks[blocks.length - 1].end, text.length)
})
