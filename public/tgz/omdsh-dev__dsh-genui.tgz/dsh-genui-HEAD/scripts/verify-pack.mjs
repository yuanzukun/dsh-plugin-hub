#!/usr/bin/env node
/**
 * Pack verification gate: packs a REAL tarball and asserts the published
 * surface — required entries present, forbidden entries absent, all runtime
 * export targets resolvable inside the tarball, sizes under the targets.
 * Fails non-zero with the concrete offenders; thresholds are overridable
 * via env (tuning), never silently widened.
 */
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { appendFileSync, mkdtempSync, readFileSync, rmSync, statSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import { parseArgs } from 'node:util'

const { values: options } = parseArgs({
  options: { keep: { type: 'boolean', default: false } },
  strict: true,
})

// 2026-10-19: 字形目录（749 个 apps-sdk-ui glyph，MIT）把包体推过原上限：
// +0.29 MB tarball / +1.80 MB unpacked，其中 lib/assets/icons.js 是运行时
// 懒加载资源、src/client/icons/icon-data-full.ts 是它的可复现构建输入（issue #15）。
// 两者都不可裁掉，因此把上限显式抬一档；若上游决定缩减字形集，同步回落这两个值。
const MAX_TARBALL = Number(process.env.GENUI_PACK_MAX_TARBALL ?? 4 * 1024 * 1024)
// 2026-10-23: 内置懒加载 MapLibre 的 CSP 主包、CSS 和独立 worker（issue #358 / PR #362）
// 使解包体积达到约 12.33 MiB。维护者同意保留完整引擎、许可和可复现源码，
// 将解包预算从 12 MiB 调整为 13 MiB；压缩包预算仍为上面的 4 MiB。
const MAX_UNPACKED = Number(process.env.GENUI_PACK_MAX_UNPACKED ?? 13 * 1024 * 1024)

const pkgJson = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))

// All runtime export targets (strings under each export entry) must exist.
const exportTargets = []
for (const entry of Object.values(pkgJson.exports)) {
  if (typeof entry === 'string') exportTargets.push(entry)
  else if (entry !== null && typeof entry === 'object') {
    for (const v of Object.values(entry)) {
      if (typeof v === 'string') exportTargets.push(v)
    }
  }
}

// Everything the loader / installer / TS consumers resolve — plus the lazy
// engine assets the node-half route serves to the browser on demand.
const required = [
  'package.json', 'LICENSE', 'SKILL.md', 'README.md', 'CHANGELOG.md', 'demo-prompts.md', 'cordis.patch.yml',
  'lib/assets/mermaid.js', 'lib/assets/three.js', 'lib/assets/icons.js',
  // 字形资产与它的两份说明文件：漏掉任何一个都意味着 npm 用户拿到坏包，
  // 而主渲染路径在本地开发时照样是绿的。
  'ICON-NAMES.md', 'THIRD_PARTY_NOTICES.md',
  // ECharts ships as two bundles: core (common presets) + full (the rest).
  'lib/assets/echarts-core.js', 'lib/assets/echarts-full.js',
  // plugin_check 发布规范（issue #15）：tarball 必须携带可复现构建所需的
  // 源码入口与构建配置，prepack 已在打包前重建 lib。
  'src/index.ts', 'tsconfig.json', 'tsdown.config.ts',
  ...exportTargets,
]

const dir = mkdtempSync(join(tmpdir(), 'dsh-genui-pack-'))
let keepTarball = false
try {
  const out = execFileSync('npm', ['pack', '--pack-destination', dir, '--json'], {
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  })
  const [packed] = JSON.parse(out)
  const paths = new Set(packed.files.map(f => f.path))
  // npm pack reports paths without the leading './' that exports use.
  const missing = required.filter(p => !paths.has(p.startsWith('./') ? p.slice(2) : p))
  if (missing.length > 0) {
    console.error(`verify-pack: FAIL — missing required entries: ${missing.join(', ')}`)
    throw new Error('pack verification failed')
  }

  const forbidden = [...paths].filter(p =>
    p.endsWith('.map')
    || p.includes('.tsbuildinfo')
    || /^lib\/types\/.*\.js$/.test(p),
  )
  if (forbidden.length > 0) {
    console.error(`verify-pack: FAIL — forbidden entries in pack:\n  ${forbidden.join('\n  ')}`)
    throw new Error('pack verification failed')
  }

  const tarballPath = resolve(dir, packed.filename)
  const tarballBytes = statSync(tarballPath).size
  const problems = []
  if (tarballBytes > MAX_TARBALL) problems.push(`tarball ${tarballBytes} > ${MAX_TARBALL}`)
  if (packed.unpackedSize > MAX_UNPACKED) problems.push(`unpacked ${packed.unpackedSize} > ${MAX_UNPACKED}`)
  if (problems.length > 0) {
    console.error(`verify-pack: FAIL — ${problems.join('; ')}`)
    throw new Error('pack verification failed')
  }

  console.log(`verify-pack: OK — ${packed.filename}`)
  console.log(`  tarball ${(tarballBytes / 1048576).toFixed(2)} MB (max ${(MAX_TARBALL / 1048576).toFixed(0)} MB), unpacked ${(packed.unpackedSize / 1048576).toFixed(2)} MB (max ${(MAX_UNPACKED / 1048576).toFixed(0)} MB), ${packed.entryCount} files`)
  if (options.keep) {
    const sha256 = createHash('sha256').update(readFileSync(tarballPath)).digest('hex')
    if (process.env.GITHUB_OUTPUT) appendFileSync(process.env.GITHUB_OUTPUT, `tarball=${tarballPath}\nsha256=${sha256}\n`)
    console.log(`  tarball path ${tarballPath}`)
    console.log(`  sha256 ${sha256}`)
    keepTarball = true
  }
} finally {
  if (!keepTarball) rmSync(dir, { recursive: true, force: true })
}
