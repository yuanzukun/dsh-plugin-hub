// @vitest-environment jsdom
// GenUI gallery: the full-vocabulary spec renders through the real fence
// path (parse → repair → GenuiBlock) and every component family appears.
// Regression net: if a future vocabulary addition breaks rendering of any
// existing type, this file catches it.
import { cleanup, render, screen } from '@testing-library/react'
import { afterEach, describe, expect, it } from 'vitest'
import { MarkdownText } from './genui-markdown.tsx'
import { gallerySpec } from '../src/client/gallery.ts'
import { repairGenuiSpec } from '../src/client/guard.ts'
import { GENUI_LIMITS } from '../src/client/genui-runtime/index.ts'

afterEach(cleanup)

function fenced(spec: unknown): string {
  return `\`\`\`dsh-ui\n${JSON.stringify(spec)}\n\`\`\``
}

describe('gallery spec', () => {
  it('survives the guard unchanged', () => {
    const repaired = repairGenuiSpec(gallerySpec)
    expect(repaired).toEqual(gallerySpec)
  })

  it('renders every component family through the fence path', () => {
    render(<MarkdownText text={fenced(gallerySpec)} />)
    const body = document.body.textContent ?? ''
    // Layout + text hierarchy
    expect(body).toContain('排版层级')
    expect(body).toContain('正文')
    // Display
    expect(body).toContain('成功')
    expect(body).toContain('CPU')
    expect(body).toContain('训练进度')
    // 音频控件现行契约为 preload="metadata"(basic.tsx);不再断言 "none"。
    expect(document.querySelector('audio[controls][preload="metadata"]')).not.toBeNull()
    expect(body).toContain('性能指标')
    expect(body).toContain('版本')
    expect(body).toContain('标题项')
    // Labeled divider (B2): the chapter separator renders its label
    // (the anthology chapters double as the divider.label demo).
    expect(document.querySelector('[class*="dividerLabeled"]')).not.toBeNull()
    expect(body).toContain('图表册')
    // Avatars render their initial: the two avatars sit adjacent in a row.
    expect(body).toContain('AB')
    expect(screenCount('tab', 'label')).toBeLessThanOrEqual(GENUI_LIMITS.maxTabs)
    // Charts
    expect(document.querySelector('svg')).not.toBeNull()
    // Interactive controls
    expect(document.querySelector('input[type="checkbox"]')).not.toBeNull()
    expect(document.querySelector('textarea')).not.toBeNull()
    expect(document.querySelector('select')).not.toBeNull()
    expect(screenAllByRole('switch').length).toBeGreaterThan(0)
    expect(document.querySelector('input[type="radio"]')).not.toBeNull()
    expect(body).toContain('复制令牌')
    expect(document.querySelector('img[src="/demo-image.png"]')).not.toBeNull()
    expect(screen.getByRole('group', { name: '横向浏览 · 本地切换，不发送消息' })).toBeDefined()
    expect(document.querySelector('button[aria-haspopup="dialog"]')).not.toBeNull()
    expect(document.querySelector('audio[controls][preload="metadata"]')).not.toBeNull()
    expect(document.querySelector('video[controls][preload="metadata"]')).not.toBeNull()
    // Advanced
    expect(document.querySelector('[data-genui-callout]')).not.toBeNull()
    expect(document.querySelector('[data-genui-quiz]')).not.toBeNull()
    expect(document.querySelector('[data-genui-scene3d]')).not.toBeNull()
    expect(document.querySelector('nav[aria-label="breadcrumb"]')).not.toBeNull()
    // Containers
    expect(document.querySelector('table')).not.toBeNull()
    expect(document.querySelector('ol')).not.toBeNull()
    expect(document.querySelector('dl')).not.toBeNull()
    expect(document.querySelector('pre')).not.toBeNull() // code / mermaid fallback
  })
})

/** Query helpers that survive the hashed css-module class names. */
function screenCount(role: string, label: string): number {
  return Array.from(document.querySelectorAll(`[role="${role}"]`)).filter(el => el.textContent?.includes(label)).length
}

function screenAllByRole(role: string, label?: string): Element[] {
  const els = Array.from(document.querySelectorAll(`[role="${role}"]`))
  return label === undefined ? els : els.filter(el => el.textContent?.includes(label))
}
