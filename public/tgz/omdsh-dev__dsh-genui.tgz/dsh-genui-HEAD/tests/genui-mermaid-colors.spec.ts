import { afterEach, describe, expect, it, vi } from 'vitest'
import { readMermaidThemeColor } from '../src/client/mermaid-colors.ts'

const TOKEN = '--genui-test-color'
const FALLBACK = '#123456'

afterEach(() => {
  document.body.style.removeProperty(TOKEN)
  document.body.style.removeProperty('color')
  vi.restoreAllMocks()
})

describe('Mermaid theme colors', () => {
  it.each([
    ['#2255aa', 'rgb(34, 85, 170)'],
    ['red', 'rgb(255, 0, 0)'],
    ['rgba(20, 40, 60, .4)', 'rgba(20, 40, 60, 0.4)'],
    ['rgb(20 40 60 / 40%)', 'rgba(20, 40, 60, 0.4)'],
    ['transparent', 'rgba(0, 0, 0, 0)'],
  ])('normalizes %s without changing its color or opacity', (value, expected) => {
    document.body.style.setProperty(TOKEN, value)
    expect(readMermaidThemeColor(TOKEN, FALLBACK)).toBe(expected)
  })

  it('reads the local diagram token and resolves currentColor in that context', () => {
    document.body.style.setProperty(TOKEN, '#112233')
    const card = document.createElement('section')
    card.style.setProperty(TOKEN, 'rgba(44, 44, 46, .4)')
    document.body.append(card)
    try {
      expect(readMermaidThemeColor(TOKEN, FALLBACK, card)).toBe('rgba(44, 44, 46, 0.4)')
      card.style.color = 'rgb(40, 80, 120)'
      card.style.setProperty(TOKEN, 'currentColor')
      expect(readMermaidThemeColor(TOKEN, FALLBACK, card)).toBe('rgb(40, 80, 120)')
      expect(readMermaidThemeColor(TOKEN, FALLBACK)).toBe('rgb(17, 34, 51)')
    } finally { card.remove() }
  })

  it('resolves calc() in a skin token instead of passing the raw custom property to Mermaid', () => {
    const value = 'rgba(235, 242, 250, calc(.4 + .75 * .4))'
    document.body.style.setProperty(TOKEN, value)
    expect(getComputedStyle(document.body).getPropertyValue(TOKEN)).toContain('calc(')
    expect(readMermaidThemeColor(TOKEN, FALLBACK)).toBe('rgba(235, 242, 250, 0.7)')
  })

  it('resolves currentColor from the host body', () => {
    document.body.style.color = 'rgb(12, 34, 56)'
    document.body.style.setProperty(TOKEN, 'currentColor')
    expect(readMermaidThemeColor(TOKEN, FALLBACK)).toBe('rgb(12, 34, 56)')
  })

  it.each(['', 'not-a-color'])('keeps the fallback for a missing or invalid token (%s)', value => {
    document.body.style.setProperty(TOKEN, value)
    expect(readMermaidThemeColor(TOKEN, FALLBACK)).toBe(FALLBACK)
  })

  it('removes its temporary element after resolving a color', () => {
    document.body.style.setProperty(TOKEN, '#2255aa')
    const before = [...document.body.children]
    readMermaidThemeColor(TOKEN, FALLBACK)
    expect([...document.body.children]).toEqual(before)
  })

  it('removes its temporary element when computed style fails', () => {
    document.body.style.setProperty(TOKEN, '#2255aa')
    const before = [...document.body.children]
    const getStyle = getComputedStyle
    vi.spyOn(globalThis, 'getComputedStyle').mockImplementation(element => {
      if (element !== document.body) throw new Error('style resolution failed')
      return getStyle(element)
    })
    expect(() => readMermaidThemeColor(TOKEN, FALLBACK)).toThrow('style resolution failed')
    expect([...document.body.children]).toEqual(before)
  })

  it('converts modern colors through sRGB pixels while retaining alpha', () => {
    // jsdom can parse oklch(), but has no Canvas renderer. Supply just that
    // browser primitive; the token and computed-style path remain real.
    document.body.style.setProperty(TOKEN, 'oklch(40% .1 210 / .4)')
    const context = {
      fillStyle: '',
      fillRect: vi.fn(),
      getImageData: () => ({ data: new Uint8ClampedArray([12, 34, 56, 102]) }),
    }
    vi.spyOn(HTMLCanvasElement.prototype, 'getContext').mockReturnValue(context as unknown as CanvasRenderingContext2D)
    expect(readMermaidThemeColor(TOKEN, FALLBACK)).toBe('rgba(12, 34, 56, 0.4)')
    expect(context.fillStyle).toMatch(/^oklch\(/)
  })

  it('keeps the fallback if a modern color needs an unavailable Canvas context', () => {
    document.body.style.setProperty(TOKEN, 'oklch(40% .1 210)')
    vi.spyOn(HTMLCanvasElement.prototype, 'getContext').mockReturnValue(null)
    expect(readMermaidThemeColor(TOKEN, FALLBACK)).toBe(FALLBACK)
  })

  it('keeps the fallback if Canvas rejects a valid modern color assignment', () => {
    document.body.style.setProperty(TOKEN, 'oklch(40% .1 210)')
    let fillStyle = ''
    const context = {
      get fillStyle() {
        return fillStyle
      },
      set fillStyle(value: string) {
        if (value === '#010203') fillStyle = value
      },
      fillRect: vi.fn(),
      getImageData: vi.fn(),
    }
    vi.spyOn(HTMLCanvasElement.prototype, 'getContext').mockReturnValue(context as unknown as CanvasRenderingContext2D)
    expect(readMermaidThemeColor(TOKEN, FALLBACK)).toBe(FALLBACK)
    expect(context.fillRect).not.toHaveBeenCalled()
    expect(context.getImageData).not.toHaveBeenCalled()
  })

  it('keeps the fallback if Canvas pixel reading fails', () => {
    document.body.style.setProperty(TOKEN, 'oklch(40% .1 210)')
    const context = {
      fillStyle: '',
      fillRect: vi.fn(),
      getImageData: vi.fn(() => {
        throw new Error('pixel read failed')
      }),
    }
    vi.spyOn(HTMLCanvasElement.prototype, 'getContext').mockReturnValue(context as unknown as CanvasRenderingContext2D)
    expect(readMermaidThemeColor(TOKEN, FALLBACK)).toBe(FALLBACK)
  })
})
