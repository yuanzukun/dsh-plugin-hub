window.__ModuleLoader__.load({id:'dsh-dpia-workbench',factory:function(require){
 const exports={},React=require('react');
 'use strict';
 const h=React.createElement;
 // COMMUNITY-CORE-BEGIN
 function createCommunityController(options={}){
  const endpoint='https://xingchendata.com/community/dpia.json';
  const fetcher=options.fetch||globalThis.fetch,now=options.now||Date.now;
  const later=options.setTimeout||setTimeout,cancel=options.clearTimeout||clearTimeout;
  const onChange=options.onChange||(()=>{});
  let running=false,visible=options.visible!==false,serial=0,request=null,refreshTimer=null,expiryTimer=null;
  let current={status:'loading'};
  function publish(value){current=value;onChange(value);}
  function clearTimers(){cancel(refreshTimer);cancel(expiryTimer);refreshTimer=expiryTimer=null;}
  function abortRequest(){if(request){request.abort.abort();request.finish();cancel(request.timer);request=null;}}
  function parse(data){
   if(data?.schemaVersion!==1||typeof data.revision!=='string'||!data.revision||data.revision.length>100||!Array.isArray(data.groups)||data.groups.length>12)throw Error('INVALID_CONFIG');
   const ids=new Set();
   const groups=data.groups.map(group=>{
    if(!group||typeof group.id!=='string'||!/^[a-z0-9][a-z0-9-]{0,63}$/.test(group.id)||ids.has(group.id)||typeof group.name!=='string'||!group.name.trim()||group.name.length>100||!['open','full','paused'].includes(group.state))throw Error('INVALID_GROUP');
    ids.add(group.id);
    if(typeof group.expiresAt!=='string'||!/T.*(?:Z|[+-]\d{2}:\d{2})$/.test(group.expiresAt)||!Number.isFinite(Date.parse(group.expiresAt)))throw Error('INVALID_EXPIRY');
    const image=new URL(group.image);
    if(image.origin!=='https://xingchendata.com'||image.username||image.password||image.hash||!/^\/community\/images\/[a-zA-Z0-9_-]+\.(png|jpe?g|webp)$/.test(image.pathname))throw Error('INVALID_IMAGE');
    return {id:group.id,name:group.name,state:group.state,image:image.href,expiresAt:group.expiresAt,expires:Date.parse(group.expiresAt)};
   });
   const group=groups.find(item=>item.state==='open'&&item.expires>now());
   return group?{status:'ready',revision:data.revision,group}:{status:'unavailable',revision:data.revision};
  }
  async function boundedJson(response){
   if(!response.ok||response.redirected||!(response.headers.get('content-type')||'').toLowerCase().includes('application/json'))throw Error('CONFIG_HTTP_ERROR');
   if(Number(response.headers.get('content-length'))>65536)throw Error('CONFIG_TOO_LARGE');
   const reader=response.body?.getReader();if(!reader)throw Error('EMPTY_CONFIG');
   const decoder=new TextDecoder();let count=0,text='';
   try{for(;;){const part=await reader.read();if(part.done)break;count+=part.value.byteLength;if(count>65536){await reader.cancel();throw Error('CONFIG_TOO_LARGE');}text+=decoder.decode(part.value,{stream:true});}text+=decoder.decode();}
   finally{reader.releaseLock();}
   return JSON.parse(text);
  }
  function schedule(){cancel(refreshTimer);if(running&&visible)refreshTimer=later(()=>{void refresh();},300000);}
  async function refresh(){
   if(!running||!visible)return;
   const ticket=++serial;clearTimers();abortRequest();publish({status:'loading'});
   const abort=new AbortController();let rejectRequest;
   const interrupted=new Promise((_,reject)=>{rejectRequest=reject;});
   const active={abort,finish:()=>rejectRequest(Error('CONFIG_CANCELLED')),timer:null};
   active.timer=later(()=>{abort.abort();rejectRequest(Error('CONFIG_TIMEOUT'));},8000);request=active;
   try{
    const response=await Promise.race([Promise.resolve().then(()=>fetcher(endpoint+'?t='+now()+'-'+ticket,{cache:'no-store',credentials:'omit',mode:'cors',redirect:'error',referrerPolicy:'no-referrer',headers:{Accept:'application/json'},signal:abort.signal})),interrupted]);
    const data=await Promise.race([boundedJson(response),interrupted]);
    if(!running||!visible||ticket!==serial)return;
    const next=parse(data);publish(next);
    if(next.status==='ready')expiryTimer=later(()=>{if(running&&visible&&ticket===serial){publish({status:'loading'});void refresh();}},Math.min(next.group.expires-now(),2147483647));
   }catch(error){if(running&&visible&&ticket===serial)publish({status:'error'});}
   finally{cancel(active.timer);if(request===active)request=null;if(ticket===serial)schedule();}
  }
  return {
   start(){if(running)return;running=true;return refresh();},
   refresh,
   setVisible(value){const next=Boolean(value);if(visible===next)return;visible=next;if(!running)return;if(!next){serial++;clearTimers();abortRequest();publish({status:'loading'});}else return refresh();},
   imageFailed(image){if(running&&current.status==='ready'&&current.group.image===image){cancel(expiryTimer);publish({status:'error'});}},
   stop(){running=false;serial++;clearTimers();abortRequest();},
   state:()=>current
  };
 }
 // COMMUNITY-CORE-END
 function CommunityContact(){
  const [value,setValue]=React.useState({status:'loading'}),controller=React.useRef(null),container=React.useRef(null);
  React.useEffect(()=>{
   const doc=typeof document!=='undefined'?document:null,win=typeof window!=='undefined'?window:null;
   let intersecting=true;
   const ctrl=createCommunityController({onChange:setValue,visible:!doc?.hidden});controller.current=ctrl;
   const visibility=()=>ctrl.setVisible(intersecting&&!doc?.hidden),focus=()=>{if(intersecting&&!doc?.hidden)void ctrl.refresh();};
   const observer=typeof IntersectionObserver!=='undefined'?new IntersectionObserver(entries=>{intersecting=entries.some(entry=>entry.isIntersecting);visibility();}):null;
   if(observer&&container.current)observer.observe(container.current);
   doc?.addEventListener('visibilitychange',visibility);win?.addEventListener?.('focus',focus);void ctrl.start();
   return()=>{observer?.disconnect();doc?.removeEventListener('visibilitychange',visibility);win?.removeEventListener?.('focus',focus);ctrl.stop();controller.current=null;};
  },[]);
  const ready=value.status==='ready';
  return h('section',{className:'card community-card',ref:container,'data-testid':'community-contact'},h('div',{className:'community-layout'},h('div',null,h('h2',null,ready?value.group.name:'开源 DPIA 工作台技术交流群'),h('p',{role:'status','aria-live':'polite'},ready?'安装答疑、功能交流与问题反馈。':value.status==='loading'?'正在加载群二维码…':value.status==='unavailable'?'新的入群入口正在准备，可稍后再查看。':'群二维码暂时无法加载，可重试或访问个人网站。'),value.status==='error'&&h('button',{type:'button',onClick:()=>controller.current?.refresh()},'重试'),h('p',null,h('a',{href:'https://xingchendata.com/',target:'_blank',rel:'noopener noreferrer'},'访问个人网站 ↗'))),ready&&h('figure',null,h('img',{key:value.group.image,src:value.group.image,alt:value.group.name+'二维码',width:220,height:220,referrerPolicy:'no-referrer',onError:()=>controller.current?.imageFailed(value.group.image)}),h('figcaption',null,'微信群 · 产品交流与反馈'))));
 }
 function CommunityHelp({onClose}){
  const dialog=React.useRef(null);
  React.useEffect(()=>{const previous=document.activeElement;dialog.current?.showModal();return()=>{if(dialog.current?.open)dialog.current.close();previous?.focus?.();};},[]);
  return h('dialog',{ref:dialog,className:'community-dialog','aria-labelledby':'dpia-community-title',onCancel:event=>{event.preventDefault();onClose();},onClick:event=>{if(event.target===event.currentTarget){const r=event.currentTarget.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)onClose();}}},h('header',null,h('h2',{id:'dpia-community-title'},'帮助与交流'),h('button',{type:'button',onClick:onClose,'aria-label':'关闭帮助与交流'},'关闭 ×')),h(CommunityContact));
 }

 function factText(value){
  if(value===null||value===undefined)return '未提供';
  if(Array.isArray(value))return value.length?value.map(factText).join('；'):'空列表';
  if(typeof value==='object')return Object.keys(value).length?Object.entries(value).map(([k,v])=>k+'：'+factText(v)).join('；'):'空对象';
  return String(value);
 }
 function factValue(value){
  if(Array.isArray(value))return value.length?h('ul',null,...value.map((v,i)=>h('li',{key:i},factValue(v)))):h('span',null,'空列表');
  if(value!==null&&typeof value==='object')return Object.keys(value).length?h('dl',null,...Object.entries(value).map(([k,v])=>h('div',{key:k},h('dt',null,k),h('dd',null,factValue(v))))):h('span',null,'空对象');
  return h('span',{style:{whiteSpace:'pre-wrap'}},factText(value));
 }
 class RenderBoundary extends React.Component{
  constructor(props){super(props);this.state={failed:false};}
  static getDerivedStateFromError(){return {failed:true};}
  render(){return this.state.failed?h('section',{role:'alert',className:'notice error'},h('p',null,'这部分内容暂时无法显示。已保存的材料和分析结果未被修改。'),h('button',{type:'button',onClick:()=>this.setState({failed:false})},'重试显示'),h('button',{type:'button',onClick:this.props.onHome},'返回总览')):this.props.children;}
 }
 function PageContent({render}){return render();}
 const css=`.dpia{box-sizing:border-box;height:100%;overflow:auto;background:#f6f8fc;color:#182438;font:14px/1.6 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;padding:32px}.dpia *{box-sizing:border-box}.dpia h1{font-size:27px;margin:0}.dpia h2{font-size:18px;margin:0 0 14px}.dpia h3{font-size:15px;margin:0}.dpia p{margin:6px 0 16px}.dpia .muted{color:#617086}.dpia .top{display:flex;justify-content:space-between;align-items:start;gap:16px;margin-bottom:24px}.dpia .pill{background:#e9efff;color:#3055a1;padding:4px 10px;border-radius:20px;white-space:nowrap}.dpia .grid{display:grid;grid-template-columns:minmax(230px,1fr) minmax(360px,2.5fr);gap:20px}.dpia .card{background:#fff;border:1px solid #dde4ef;border-radius:14px;padding:20px;margin-bottom:16px}.dpia label{display:block;font-weight:600;margin:12px 0 4px}.dpia input,.dpia textarea,.dpia select{display:block;width:100%;font:inherit;padding:9px 11px;border:1px solid #bdcadd;border-radius:7px;background:white;color:#182438}.dpia textarea{min-height:82px;resize:vertical}.dpia button{font:inherit;cursor:pointer;border:1px solid #c7d3e5;background:white;color:#28425f;padding:8px 13px;border-radius:7px;margin:8px 8px 0 0}.dpia button.primary{background:#2d5fd2;color:white;border-color:#2d5fd2}.dpia button:disabled{opacity:.5;cursor:wait}.dpia button:focus-visible,.dpia input:focus,.dpia textarea:focus,.dpia select:focus{outline:2px solid #618cf0;outline-offset:2px}.dpia .case{width:100%;text-align:left;margin:0 0 8px;padding:12px}.dpia .case.active{border-color:#2d5fd2;background:#eff4ff}.dpia .case small{display:block;color:#617086}.dpia .notice{padding:12px 16px;background:#edf3ff;border-radius:8px;margin-bottom:16px}.dpia .error{background:#fff0ee;color:#923427;white-space:pre-wrap}.dpia .row{border-top:1px solid #e6ebf3;padding:12px 0;overflow-wrap:anywhere}.dpia code,.dpia pre{font-size:12px;white-space:pre-wrap;overflow-wrap:anywhere}.dpia details{margin:10px 0}.dpia summary{cursor:pointer;font-weight:600}.dpia .stats{display:flex;gap:12px;flex-wrap:wrap}.dpia .stats span{background:#f2f5fa;border-radius:8px;padding:8px 14px}.dpia .actions{display:flex;flex-wrap:wrap}.dpia .report-table{border-collapse:collapse;width:100%;margin:12px 0}.dpia .report-table td,.dpia .report-table th{border:1px solid #d9d9d9;padding:8px;text-align:left;overflow-wrap:anywhere}.dpia .report-table th{background:#f2f5fa}.dpia .hint{font-size:12px;color:#617086}@media(max-width:850px){.dpia{padding:18px}.dpia .grid{grid-template-columns:1fr}.dpia .top{display:block}}`;
 const communityCss='.dpia .community-top{display:flex;gap:12px;align-items:center;flex-wrap:wrap}.dpia .community-top button{margin:0}.dpia .community-layout{display:grid;grid-template-columns:minmax(0,1fr) 220px;align-items:center;gap:24px}.dpia .community-card a{color:#285db8}.dpia .community-card figure{margin:0;text-align:center}.dpia .community-card img{display:block;width:220px;max-width:100%;height:auto;aspect-ratio:1;background:white;border:1px solid #e1e6ee;border-radius:8px}.dpia .community-card figcaption{font-size:12px;color:#617086;margin-top:8px}.dpia .community-dialog{color:inherit;background:#f6f8fc;width:min(720px,94vw);max-height:90vh;border:1px solid #c7d3e5;border-radius:14px;padding:22px;overflow:auto}.dpia .community-dialog::backdrop{background:#14243c88}.dpia .community-dialog>header{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:16px}.dpia .community-dialog>header h2{margin:0}.dpia .community-dialog>header button{margin:0}.dpia .community-dialog .community-card{margin:0}@media(max-width:600px){.dpia .community-layout{grid-template-columns:1fr}.dpia .community-card figure{justify-self:center}.dpia .community-top{margin-top:12px}.dpia .community-dialog{padding:16px}}';
 const messages={INTERNAL_WORD_UNAVAILABLE:'Word生成环境不可用。原报告已保留，请核对文档Python依赖后重试。',INTERNAL_REPORT_BASIS_MISMATCH:'报告依据已变化，请关闭预览并重新打开当前版本。',REPORT_CONTENT_REVIEW_FAILED:'报告内容检查尚未通过。请查看本轮字段与页面检查记录，修复报告后再完成交付；原文件已保留。',REPORT_PAGE_REVIEW_FAILED:'存在未通过或已失效的页面检查，请逐页核对当前版本。',REPORT_PAGE_REVIEW_MISSING:'尚未检查全部页面，请完成逐页检查后再交付。',EXECUTION_BUSY:'该评估正在运行或提交，请稍后查看会话。',STALE_EXECUTION:'运行状态已经更新，请刷新后再操作。',HOST_STATUS_UNAVAILABLE:'暂时无法核对 DSH 状态，请恢复连接后重试。',CORRUPT_EXECUTION:'运行记录无法读取，原文件已保留。',STALE_VERSION:'这条评估已有更新。请点击“刷新”，核对后重新保存。',PYTHON_NOT_AVAILABLE:'未找到 Python 3。请配置 DSH_DPIA_PYTHON 后重启本插件。',CORRUPT_STATE:'保存记录无法读取。原文件已保留，请勿覆盖；请根据数据目录检查并恢复。',SOURCE_NOT_FOUND:'请选择已保存的证据来源。',INVALID_TEXT:'请填写必填字段，证据正文最多 100,000 字符。',CASE_LIMIT:'此评估达到本实验容量限制，请导出并拆分材料。',ARCHIVE_SELECTION_EMPTY:'请至少选择一个分析版本、报告或材料。',ARCHIVE_SOURCE_CHANGED:'所选文件摘要已变化，归档已阻止；请核对原件。',ARCHIVE_TOO_LARGE:'所选内容超过 150 MB，请拆分归档范围。',INTERNAL_REPORT_DIGEST_MISMATCH:'已生成内部报告的摘要不一致，原文件已保留，请核对。'};
 function errText(e){return messages[e.message]||`操作失败：${e.message}。请检查连接或数据目录后重试。`;}
 function Field({name,label,area=false,...props}){return h('label',null,label,h(area?'textarea':'input',{name,required:true,...props}));}
 function Form({onSave,children,label,busy}){return h('form',{onSubmit:async e=>{e.preventDefault();const form=e.currentTarget;const data=new FormData(form),values=Object.fromEntries(data);for(const select of form.querySelectorAll('select[multiple]'))values[select.name]=data.getAll(select.name);const ok=await onSave(values);if(ok)form.reset();}},children,h('button',{className:'primary',disabled:busy,type:'submit'},label));}
 function Workbench({rpc,openSession}){
  const [index,setIndex]=React.useState({cases:[],testFixtures:[],errors:[]}),[current,setCurrent]=React.useState(null),[execution,setExecution]=React.useState(null),[tab,setTab]=React.useState(0),[search,setSearch]=React.useState(''),[filter,setFilter]=React.useState('active'),[busy,setBusy]=React.useState(false),[error,setError]=React.useState(''),[note,setNote]=React.useState(''),[modal,setModal]=React.useState(null),[selectedAnswers,setSelectedAnswers]=React.useState([]),[reports,setReports]=React.useState([]);
  const [helpOpen,setHelpOpen]=React.useState(false);
 const refreshSerial=React.useRef(0),executionRef=React.useRef(null);
  executionRef.current=execution;
  const alive=React.useRef(true),ticket=React.useRef(0),currentRef=React.useRef(null),inFlight=React.useRef(false);
  currentRef.current=current;
  const labels={documented:'材料描述',confirmed:'用户确认',observed:'已观察',inferred:'推断',unknown:'未知',conflict:'冲突',planned:'计划',implemented:'已实施',verified:'已验证',partial:'部分',open:'待答',answered:'已吸收',resolved:'已解决',high:'高',medium:'中',low:'低',undetermined:'待定',required:'需要开展 DPIA',not_required:'无需 DPIA',no_trigger_identified_within_assessed_scope:'本次范围内未识别 DPIA 触发',outside_scope:'不在适用范围',applicability_unresolved:'适用性尚未确定',conflict_requires_review:'触发与例外冲突待复核',exception_claim_requires_review:'例外主张待复核',recommended_high_risk_review:'建议开展高风险审查',not_met:'未满足',met:'满足',reported_implemented:'实施自报',evidence_submitted:'已提交证据',draft:'草稿',pending:'待核验',complete:'已完成',not_started:'尚未开始',not_assessed:'尚未评估',compliant:'符合',non_compliant:'不符合'};
  const label=x=>labels[x]||x||'未说明',pretty=x=>typeof x==='string'?x:JSON.stringify(x,null,2);
  const button=(title,fn,primary=false)=>h('button',{type:'button',disabled:busy,onClick:fn,className:primary?'primary':''},title);
  const card=(title,...children)=>h('section',{className:'card'},h('h2',null,title),...children);
  const p=(text,cls)=>h('p',{className:cls},text);
  const details=(title,...children)=>h('details',null,h('summary',null,title),...children);
  const code=x=>h('pre',null,pretty(x));
  async function refreshList(){const data=await rpc({action:'list'});if(alive.current)setIndex(data);}
  React.useEffect(()=>{alive.current=true;refreshList().catch(e=>setError(errText(e)));return()=>{alive.current=false;ticket.current++;};},[]);
  const selectableAnswers=c=>(c.answerDrafts||[]).filter(d=>c.result?.assessment.questions.some(q=>q.id===d.questionId&&q.status==='open')&&!c.answerStateError&&['draft','cancelled'].includes(c.answerStates?.find(r=>r.answerId===d.id)?.status||'draft')).map(d=>d.id);
  async function open(id){const n=++ticket.current;setBusy(true);setError('');setNote('');setModal(null);setSelectedAnswers([]);try{const execution=await rpc({action:'execution',id});const c=await rpc({action:'get',id});if(alive.current&&ticket.current===n){setCurrent(c);setSelectedAnswers(selectableAnswers(c));setExecution(execution);setReports([]);}}catch(e){if(alive.current&&ticket.current===n)setError(errText(e));}finally{if(alive.current&&ticket.current===n)setBusy(false);}}
  async function command(action,values={},setCase=true){if(inFlight.current)return false;inFlight.current=true;refreshSerial.current++;setBusy(true);setError('');try{const c=currentRef.current;const data=await rpc({action,id:c?.id,version:c?.version,...values});if(!alive.current)return false;if(setCase){setCurrent(data);if(action==='create'){setExecution({revision:0,phase:'not_started'});setTab(1);}await refreshList();}if(setCase&&data.answerDrafts)setSelectedAnswers(v=>{const allowed=selectableAnswers(data);return [...new Set([...v.filter(id=>allowed.includes(id)),...(action==='answerDraft'?allowed.filter(id=>!c?.answerDrafts?.some(d=>d.id===id)):[])])];});setNote(data.importNotice||'已保存，原记录保留。');return data;}catch(e){if(alive.current)setError(errText(e));return false;}finally{inFlight.current=false;if(alive.current)setBusy(false);}}
  async function read(action,values={}){try{return await rpc({action,id:currentRef.current.id,...values});}catch(e){setError(errText(e));return null;}}
  async function refreshCurrent(isLive=()=>true){
   const id=currentRef.current?.id,epoch=ticket.current,requestId=executionRef.current?.requestId,serial=++refreshSerial.current;
   if(!id)return null;
   const valid=()=>isLive()&&alive.current&&ticket.current===epoch&&currentRef.current?.id===id&&refreshSerial.current===serial&&executionRef.current?.requestId===requestId;
   try{
    const status=await rpc({action:'execution',id});if(!valid())return null;
    // The execution read can adopt a result; fetch it afterwards, before publishing terminal state.
    const c=await rpc({action:'get',id});if(!valid())return null;
    const list=status.kind==='report'?await rpc({action:'reportList',id}):null;if(!valid())return null;
    const changed=c.result?.record.revisionId!==currentRef.current?.result?.record.revisionId;
    setCurrent(c);setSelectedAnswers(v=>v.filter(answerId=>selectableAnswers(c).includes(answerId)));
    if(list)setReports(list);
    setExecution(status);setError('');
    if(changed)setNote('本轮成果已校验并同步。');
    refreshList().catch(()=>{});return status;
   }catch(e){if(valid())setError('刷新未完成，当前显示仍是上次读取的版本。'+errText(e));return null;}
  }
  React.useEffect(()=>{
   if(!current?.id||!execution?.requestId||execution.stoppedAt||['ready','cancelled','not_started'].includes(execution.phase))return;
   let live=true,checking=false,count=0,idle=0,unknown=0;
   const timer=setInterval(async()=>{if(checking||inFlight.current)return;checking=true;try{
    const r=await refreshCurrent(()=>live);if(!live||!alive.current)return;
    count++;if(!r){unknown++;}else{idle=r.statusKnown&&!r.running?idle+1:0;unknown=r.statusKnown?0:unknown+1;}
    if(r?.stoppedAt||r?.phase==='cancelled'||(r&&idle>=3&&!['submitting','uncertain','cancel_requested'].includes(r.phase))||unknown>=10||count>=720){clearInterval(timer);if(unknown>=10||count>=720)setNote('自动状态查询已达到本轮上限。可刷新运行状态或打开执行会话继续核对。');}
   }finally{checking=false;}},5000);
   return()=>{live=false;clearInterval(timer);};
  },[current?.id,execution?.requestId,execution?.phase,execution?.stoppedAt]);
  async function execute(){const values={executionRevision:execution?.revision??0,intent:modal?.intent||'分析当前材料',answerIds:selectedAnswers};const r=await command('start',values,false);if(r){setExecution(r);const updated=await read('get');if(updated){setCurrent(updated);setSelectedAnswers(v=>v.filter(id=>selectableAnswers(updated).includes(id)));}setModal(null);setNote(r.phase==='uncertain'?'接收回执未确认，请打开会话核对；重试将复用同一请求。':'任务已提交；完成后工作台自动接收结果。');}}
  const result=current?.result,a=result?.assessment;
  const sources=id=>read('source',{sourceId:id}).then(x=>{if(x)setModal({title:x.title,body:code(x.text)});});
  const reportBlocks=blocks=>(blocks||[]).map((b,i)=>b.type==='heading'?h('h'+Math.min(6,b.level+1),{key:i},b.text):b.type==='table'?h('div',{key:i,style:{overflowX:'auto'}},h('table',{className:'report-table'},h('thead',null,h('tr',null,...b.rows[0].map((c,j)=>h('th',{key:j},c)))),h('tbody',null,...b.rows.slice(1).map((r,j)=>h('tr',{key:j},...r.map((c,k)=>h('td',{key:k},c))))))):b.type==='list'?h(b.ordered?'ol':'ul',{key:i},...b.items.map((v,j)=>h('li',{key:j},v))):b.type==='code'?h('pre',{key:i},b.text):h('p',{key:i,style:{whiteSpace:'pre-wrap'}},b.text));
  const report=()=>read('report').then(x=>{if(x)setModal({title:'内部评估报告',body:h(React.Fragment,null,p('依据第 '+x.inputVersion+' 版材料形成的分析，供内部审阅，不代表正式报告或批准上线。'),button('下载 Word',async()=>{const out=await command('downloadInternalWord',{revisionId:x.revisionId},false);if(out)download(Uint8Array.from(atob(out.base64),c=>c.charCodeAt(0)),out.filename,out.mime);}),...reportBlocks(x.blocks||[{type:'paragraph',text:x.content}]),details('其他格式',button('下载 Markdown',()=>download(x.content,current.title+'-内部评估.md','text/markdown'))))});});
  const readable=value=>factText(value??'').replace(/\bF-?\d+\b/g,id=>{const fact=a?.facts.find(f=>f.id===id);return fact?factText(fact.value):('事实记录 '+id+'（可在材料与事实中查看）');});
  const references=refs=>(refs||[]).map((ref,i)=>{const source=a.sources?.find(x=>x.id===ref.source_id)||current.presentation?.sources?.find(x=>x.id===ref.source_id);const url=source?.url||source?.uri;return h('p',{key:i},source?.title||ref.source_id,ref.locator?' · '+ref.locator:'',/^https?:\/\//i.test(url||'')?h('a',{href:url,target:'_blank',rel:'noopener noreferrer'},' 查看原文'):null);});
  function download(content,name,type){const url=URL.createObjectURL(new Blob([content],{type}));const link=document.createElement('a');link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  const start=intent=>setModal({title:'本轮分析范围',intent,run:true,body:h(React.Fragment,null,p(intent),p('材料修订 '+current.version+'；当前分析 '+(result?.record.revisionId.slice(0,8)||'尚无')+'；选中 '+selectedAnswers.length+' 项补答。'),p('模型：'+(execution?.nextModel?.model||'宿主尚未返回具体模型；沿用 DSH 当前配置')+'。本次调用产生模型用量，未选补答不纳入。'),p('当前有效材料和上一版分析将形成固定快照，运行中的后续修改留到下一轮。'))});
  const unavailable=()=>p(current?.resultError?'成果读取失败：'+current.resultError+'。已保存文件保持原样。':'尚未同步评估结果；手工登记和模型分析分别保存。','muted');
  const factCards=()=>a.facts.map(f=>{const link=result.intake.fact_links.find(x=>x.fact_id===f.id),passages=result.sourceIndex.passages.filter(x=>link?.passage_ids.includes(x.id));return h('article',{className:'row',key:f.id},h('div',{className:'fact-value'},factValue(f.value)),p(label(f.status)+' · '+label(f.implementation)+' · '+f.id,'muted'),link&&p(link.support_note),details('查看原文与来源',...passages.map(x=>h('div',{key:x.id},p(x.locator),code(x.text),button('查看完整来源',()=>sources(x.source_id))))),button('确认这一事实',()=>setModal({title:'确认选定事实',body:h(React.Fragment,null,factValue(f.value),p('仅确认这一事实及其当前来源版本，不确认法律结论或其他事实。'),h(Form,{busy,label:'保存确认记录',onSave:async v=>{const ok=await command('confirmFact',{...v,factId:f.id});if(ok)setModal(null);return ok;}},h(Field,{name:'person',label:'确认人 / 身份'}),h(Field,{name:'text',label:'确认依据与范围',area:true})))})),button('纠正 / 补充',()=>setModal({title:'纠正事实并保留原陈述',body:h(React.Fragment,null,factValue(f.value),h(Form,{busy,label:'保存纠正，等待复评',onSave:async v=>{const ok=await command('correctFact',{...v,factId:f.id});if(ok)setModal(null);return ok;}},h(Field,{name:'person',label:'来源人 / 身份'}),h(Field,{name:'text',label:'纠正内容及依据',area:true})))})));});
  const questions=(historical=false)=>a.questions.filter(q=>historical?['answered','resolved','closed'].includes(q.status):!['answered','resolved','closed'].includes(q.status)).map(q=>{
   const check=result.intake.checks.find(c=>c.question_id===q.id),draft=current.answerDrafts?.find(d=>d.questionId===q.id),review=current.answerStates?.find(r=>r.answerId===draft?.id);
   const attachments=current.evidence.filter(e=>(!e.attachmentToQuestion||e.attachmentToQuestion===q.id)&&!current.withdrawnSourceIds?.includes(e.id));
   return h('article',{key:q.id,className:'row'},h('h3',null,q.question),p(label(q.status)+' · '+(q.compliance_impact||q.impact),'muted'),
    !historical&&check&&h(React.Fragment,null,details('材料已有信息',p(readable(check.finding))),p('仍需补充：'+readable(review?.remaining||check.gap)),details('影响与可继续事项',p(check.pause?.reason),p('可继续：'+(check.pause?.continue_with||[]).join('；')),p('恢复条件：'+check.pause?.resume_when))),
    draft&&h('div',{className:'notice'},p((current.answerStateError?'答复处理记录暂不可读':({draft:'已保存草稿',submitted:'已提交，等待复评',submitting:'正在提交',submission_uncertain:'提交回执待核',cancel_requested:'已请求中止',cancelled:'本轮已中止，答复保留',absorbed:'已纳入评估，无需重复回答',partial:'部分解决',conflict:'来源冲突，待澄清',still_missing:'仍缺信息'})[review?.status||'draft'])+' · '+draft.answerer+' · '+draft.date),p(draft.text),
     review?.reason&&p('处理说明：'+readable(review.reason)),!historical&&review?.remaining&&p('仍需补充：'+readable(review.remaining)),review?.historical&&p('以上处理来自历史分析版本。'),
     p('所附材料：'+((draft.attachmentSourceIds||[]).map(id=>current.evidence.find(e=>e.id===id)?.title||id).join('、')||'无')),
     !historical&&selectableAnswers(current).includes(draft.id)&&h('label',null,h('input',{type:'checkbox',style:{display:'inline',width:'auto'},checked:selectedAnswers.includes(draft.id),onChange:e=>setSelectedAnswers(v=>e.target.checked?[...v,draft.id]:v.filter(x=>x!==draft.id))}),' 纳入本轮复评')),
    !historical&&h('details',{key:'answer-editor-'+q.id+'-'+(draft?.id||'new')},h('summary',null,draft?'修改已保存答复':'填写补充答复'),h('label',null,'上传本问题附件（保存答复时选择纳入）',h('input',{type:'file',accept:'.docx,.pdf,.txt,.md',disabled:busy,onChange:e=>{const f=e.target.files?.[0];e.target.value='';importFile(f,{questionId:q.id});}})),
     h(Form,{key:q.id+'-'+current.version,busy,label:'保存答复（不调用模型）',onSave:v=>command('answerDraft',{...v,questionId:q.id})},
      h('label',null,'答复性质',h('select',{name:'mode',defaultValue:draft?.mode||'answer'},h('option',{value:'answer'},'已知答复'),h('option',{value:'partial'},'仅回答部分'),h('option',{value:'unknown'},'暂时无法提供'),h('option',{value:'not_designed'},'尚未设计'))),
      h(Field,{name:'answerer',label:'答复者 / 来源',defaultValue:draft?.answerer||''}),h(Field,{name:'date',label:'答复日期',type:'date',defaultValue:draft?.date||new Intl.DateTimeFormat('sv-SE').format(new Date())}),
      h(Field,{name:'text',label:'答复原文与依据；未知请具体说明',area:true,defaultValue:draft?.text||'',maxLength:100000}),
      h('label',null,'随答复提交的材料（可多选）',h('select',{name:'attachmentSourceIds',multiple:true,defaultValue:draft?.attachmentSourceIds||[]},...attachments.map(e=>h('option',{key:e.id,value:e.id},e.title)))))));
  });
  async function legacy(){const c=await read('legacyCandidates');if(!c)return;setModal({title:'承接既有评估成果（不调用模型）',body:h(React.Fragment,null,p('已按评估身份、来源摘要和报告关联整理以下候选。选择一套后校验并采用；不会覆盖原件或重新调用模型。'),!c.bundles.length&&p('没有找到完整匹配的成果组合。请打开原会话核对底稿、来源索引及报告是否齐全。'),...c.bundles.map(b=>h('article',{key:b.key,className:'row'},h('h3',null,b.project),p(b.counts.facts+' 条事实 · '+b.counts.questions+' 个问题 · '+b.counts.risks+' 项风险 · '+b.counts.actions+' 项整改'),p('修订 '+b.revisionId.slice(0,8)+' · '+(b.files.report?'含内部评估报告':'事实 / 筛查成果')),details('来源文件',code(b.files)),button('采用这套成果',async()=>{const ok=await command('adoptLegacy',{bundleKey:b.key});if(ok)setModal(null);},true))))});}
  async function history(){const rows=await read('resultHistory');if(!rows)return;setModal({title:'不可变结果历史',body:rows.length?h('div',null,...rows.map(r=>h('div',{className:'row',key:r.sequence},p('分析版本 '+r.sequence+' · 材料 '+r.inputVersion+' · '+r.adoptedAt),button('查看此版本',async()=>{const old=await read('resultVersion',{sequence:r.sequence});if(old)setModal({title:'历史分析 '+r.sequence,body:h(React.Fragment,null,p('修订：'+old.record.revisionId),p(old.assessment.facts.length+' 条事实 / '+old.assessment.questions.length+' 个问题 / '+old.assessment.risks.length+' 项风险 / '+old.assessment.actions.length+' 项整改'),old.report?code(old.report):code(old.intake))});}),button('比较当前版本',async()=>{const old=await read('resultVersion',{sequence:r.sequence});if(!old)return;const changes=['facts','questions','risks','actions'].map(k=>{const before=new Map(old.assessment[k].map(x=>[x.id,x])),after=new Map(a[k].map(x=>[x.id,x]));return {type:({facts:'事实',questions:'问题',risks:'风险',actions:'整改'})[k],added:a[k].filter(x=>!before.has(x.id)),removed:old.assessment[k].filter(x=>!after.has(x.id)),changed:a[k].filter(x=>before.has(x.id)&&JSON.stringify(before.get(x.id))!==JSON.stringify(x)).map(x=>({before:before.get(x.id),after:x}))};});setModal({title:'历史版本 → 当前版本',body:code(changes)});})))):p('尚无已接收结果版本。')});}
  async function importFile(file,extra={}){if(!file)return;if(file.size>20_000_000){setError('单文件最多 20 MB，请拆分本轮材料。');return;}try{const base64=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(Error('FILE_READ_FAILED'));reader.readAsDataURL(file);});await command('importAsset',{filename:file.name,base64,...extra});}catch(e){setError(errText(e));}}
  async function previewAsset(asset){const item=await read('assetPreview',{assetId:asset.id});if(!item)return;setModal({title:asset.filename,body:h(React.Fragment,null,p('提取状态：'+asset.status+'；'+asset.parts+' 个文本定位片段'),...asset.warnings.map(w=>p(w,'notice')),code(item.text||'未提取到可读文字'),button('下载原件',async()=>{const out=await read('downloadAsset',{assetId:asset.id});if(out)download(Uint8Array.from(atob(out.base64),c=>c.charCodeAt(0)),out.filename,out.mime);}),asset.status==='needs_review'&&h(Form,{busy,label:'记录提取限制并纳入分析',onSave:async v=>{const ok=await command('reviewAsset',{assetId:asset.id,...v});if(ok)setModal(null);return ok;}},h(Field,{name:'reviewNote',label:'已核对哪些内容、仍有哪些提取限制（不等于确认业务事实）',area:true})))});}
  const fileCard=()=>card('导入文件',p('支持 DOCX、含文字的 PDF、TXT、Markdown；单文件 20 MB，评估原件合计 100 MB。扫描件与复杂内容会明确提示限制。','hint'),h('label',null,'选择本轮材料',h('input',{type:'file',accept:'.docx,.pdf,.txt,.md',disabled:busy,onChange:e=>{const f=e.target.files?.[0];e.target.value='';importFile(f);}})),...(current.assets||[]).map(asset=>h('article',{className:'row',key:asset.id},h('strong',null,asset.filename),p(({ready:'可分析',needs_review:'需核对提取质量',blocked:'无法提取，原件已保留',accepted_with_limits:'已记录提取限制'})[asset.status]||asset.status),...asset.warnings.map(w=>p(w,'hint')),button('查看提取内容 / 原件',()=>previewAsset(asset)),asset.extracted&&current.evidence.some(e=>e.id===asset.extracted.id)&&!current.withdrawnSourceIds?.includes(asset.extracted.id)&&h('label',null,'上传修订文件（保留原件，核对后替换本轮来源）',h('input',{type:'file',accept:'.docx,.pdf,.txt,.md',disabled:busy,onChange:e=>{const f=e.target.files?.[0];e.target.value='';importFile(f,{replacesSourceId:asset.extracted.id,purpose:asset.purpose,questionId:asset.questionId});}})))));
  function withdraw(source){const sid=result?.sourceIndex.sources.find(s=>s.path===source.path)?.id;const affected=(a?.facts||[]).filter(f=>f.source_ids.includes(sid));setModal({title:'撤回本轮材料',body:h(React.Fragment,null,p(source.title+' 将在下一轮排除；原件和既有报告保持可追溯。'),p('当前直接引用该材料的事实：'+(affected.map(f=>f.id).join('、')||'未匹配到，需在复评中核对关联')),button('确认撤回，保留历史',async()=>{const ok=await command('withdrawSource',{sourceId:source.id});if(ok)setModal(null);}))});}
  React.useEffect(()=>{if(current?.id&&tab===5)read('reportList').then(x=>{if(x)setReports(x);});},[current?.id,tab]);
  async function archivePackage(){
   const options=await read('archiveOptions');if(!options)return;
   const choice=(name,label,items,value,title)=>h('label',null,label,h('select',{name,multiple:true,size:Math.min(5,Math.max(2,items.length)),defaultValue:[]},...items.map(x=>h('option',{key:value(x),value:value(x)},title(x)))));
   setModal({title:'选择归档范围',body:h(React.Fragment,null,p(options.notice),h(Form,{busy,label:'生成并下载归档包（不调用模型）',onSave:async v=>{
    const out=await command('downloadArchive',{version:options.version,sequences:(v.sequences||[]).map(Number),reportIds:v.reportIds||[],sourceIds:v.sourceIds||[],assetIds:v.assetIds||[]},false);
    if(out){download(Uint8Array.from(atob(out.base64),c=>c.charCodeAt(0)),out.filename,out.mime);setNote('归档包已生成，共 '+out.files+' 个文件。');setModal(null);}return false;
   }},choice('sequences','分析版本（包括内部报告、底稿及索引）',options.revisions,x=>String(x.sequence),x=>'第 '+x.sequence+' 版 · 材料 '+x.inputVersion+' · '+x.revisionId.slice(0,8)),choice('reportIds','已检查报告（自动包含对应分析版本）',options.reports,x=>x.requestId,x=>(x.reportType==='formal'?'正式报告':'草稿')+' · '+x.template+' · '+x.language),choice('sourceIds','文本来源（仅所选内容）',options.sources,x=>x.id,x=>x.title+(x.withdrawn?' · 已撤回':'')),choice('assetIds','原始文件（仅所选内容）',options.assets,x=>x.id,x=>x.filename+' · '+Math.ceil(x.bytes/1024)+' KB')),p('可多选；未选择的原件、其他案件和会话不会打包。','hint'))});
  }
  async function reportWizard(initialType='draft'){
   const data=await read('reportOptions');if(!data)return;setReports(data.reports);const hasEU=(a?.jurisdictions||[]).some(j=>(typeof j==='string'?j:j.code||j.id)==='EU');const preferred=(hasEU?data.templates.find(t=>t.official):null)||data.templates[0];const ordered=[preferred,...data.templates.filter(t=>t!==preferred)].filter(Boolean);
   setModal({title:'准备报告交付',body:h(React.Fragment,null,
    p(preferred?.official?'已优先选择内置官方模板及原语言，无需另行上传。下一步核对依据和缺口。':'当前地区未匹配内置官方模板，可用自编格式或上传适用模板。下一步核对依据和缺口。'),
    h(Form,{busy,label:'审阅本次报告依据',onSave:async values=>{await reviewReport(values);return false;}},
     h('label',null,'报告类型',h('select',{name:'reportType',defaultValue:initialType==='formal'?'formal':'draft'},h('option',{value:'draft'},'待完善草稿（未知留空并批注）'),h('option',{value:'formal'},'正式报告（需满足内容条件）'))),
     h('label',null,'模板',h('select',{name:'templateId',defaultValue:preferred?.id,onChange:e=>{const chosen=data.templates.find(t=>t.id===e.target.value);if(chosen?.official&&e.target.form?.elements.language)e.target.form.elements.language.value=chosen.language;}},...ordered.map(t=>h('option',{key:t.id,value:t.id},t.title+(t.official?' · 官方原件':' · '+(t.status==='self_authored'?'自编格式':'出处待核验')))))),
     h('label',null,'语言',h('select',{name:'language',defaultValue:preferred?.official?preferred.language:'zh-CN'},h('option',{value:'zh-CN'},'中文审阅'),h('option',{value:'en'},'英文 / 官方原语言')))),
    ...data.templates.map(t=>p(t.title+'：'+t.description,'hint')))});
  }
  async function reviewReport(values){
   const preview=await read('reportPreview',{...values,version:currentRef.current.version});if(!preview)return;
   const allowed=preview.generationReady&&(values.reportType==='draft'||preview.check.eligible);
   setModal({title:'确认报告依据及生成',body:h(React.Fragment,null,
    p('评估修订：'+preview.basis.revisionId+'；依据材料：'+preview.basis.inputVersion),
    p('模板：'+preview.template.title+'；语言：'+preview.basis.language+'；类型：'+(values.reportType==='formal'?'正式交付版':'待完善草稿')),
    p(preview.template.status==='public_consultation_version_not_verified_final'?'此原件为公开征求意见版本，不能标为已定稿统一模板；生成时再次核验。':preview.template.description,'notice'),
    preview.summary&&p('本版 '+preview.summary.facts+' 条事实（已确认 '+preview.summary.confirmedFacts.length+' 条）、'+preview.summary.openQuestions+' 个待答、'+preview.summary.risks+' 项风险、'+preview.summary.actions+' 项整改；确认范围：'+(preview.summary.confirmedFacts.join('、')||'尚无已确认事实')),
    p(preview.basis.limits),preview.check.blockers.length>0&&details('内容缺口与适用限制',...preview.check.blockers.map(x=>p(x))),
    p(preview.notice,'hint'),p('本操作调用 DSH 当前模型并渲染文档。有缺口时不会自动改成正式版。','hint'),
    allowed?button('确认本版依据并生成'+(values.reportType==='formal'?'正式报告':'待完善草稿'),async()=>{
     const r=await command('startReport',{...values,basisDigest:preview.basisDigest,executionRevision:execution?.revision??0},false);
     if(r){setExecution(r);setModal(null);setNote(r.phase==='uncertain'?'报告任务回执待核；重试复用原任务。':'报告任务已提交，完成后在本页查看状态并下载。');}
    },true):!preview.generationReady?h(React.Fragment,null,...preview.generationBlockers.map(x=>p(x,'error')),button('重新检查文档环境',()=>reviewReport(values))):h(React.Fragment,null,p('当前条件不足以生成正式报告。可补充后复评，或生成待完善草稿。','error'),button('改为待完善草稿',()=>reviewReport({...values,reportType:'draft'}))))});
  }
  async function previewReportPage(report,page=1){
   const item=await read('reportPage',{requestId:report.requestId,page});if(!item)return;
   setModal({title:(report.reportType==='formal'?'正式报告':'待完善草稿')+' · 第 '+page+' / '+item.pageCount+' 页',body:h(React.Fragment,null,
    p('依据修订：'+item.revisionId+(report.historicalBasis?'；这是历史版本。':'')),
    item.pendingReview&&h(Form,{busy,label:'保存本页视觉检查',onSave:async v=>{const out=await command('reviewReportPage',{requestId:report.requestId,page,sha256:item.sha256,...v},false);if(out){setReports(await read('reportList')||[]);await previewReportPage(report,Math.min(page+1,item.pageCount));}return out;}},p('查看本页的文字、表格、分页、页眉页脚与溢出后填写。脚本检测不能替代看图。'),h('select',{name:'verdict'},h('option',{value:'fail'},'需要修复'),h('option',{value:'pass'},'本页检查通过')),h(Field,{name:'notes',label:'本页实际检查结果',area:true,maxLength:4000})),
    page>1&&button('上一页',()=>previewReportPage(report,page-1)),page<item.pageCount&&button('下一页',()=>previewReportPage(report,page+1)),
    h('img',{src:'data:image/png;base64,'+item.base64,alt:'报告第 '+page+' 页',style:{display:'block',maxWidth:'100%',height:'auto'}}))});
  }
  async function downloadReportFile(report,format){const out=await read('downloadReport',{requestId:report.requestId,format});if(out)download(Uint8Array.from(atob(out.base64),c=>c.charCodeAt(0)),out.filename,out.mime);}
  const recordKinds={screening_scope:'筛查事实范围确认',legal_review:'法律复核记录',dpo_opinion:'DPO 意见',stakeholder_opinion:'相关方意见',risk_acceptance:'风险接受记录',launch_decision:'业务审批记录',verification:'措施验证记录'};
  function professionalForm(category){
   const subjects=category==='screening_scope'?a.facts.map(f=>[f.id,factText(f.value)]):category==='verification'?a.controls.map(c=>[c.id,c.description]):['risk_acceptance','launch_decision'].includes(category)?a.jurisdictions.map(j=>[j.code,j.code]):a.rule_assessments.map(r=>[r.rule_id,r.analysis]);
   setModal({title:'登记'+recordKinds[category],body:h(React.Fragment,null,p('请录入实际意见或确认原文、人员身份和适用范围。保存记录后进入复评，不自动变成批准或验证通过。'),
    h(Form,{busy,label:'保存适用范围与原始记录',onSave:async v=>{const saved=await command('professionalRecord',{...v,category});if(saved)setModal(null);return saved;}},
     h(Field,{name:'person',label:'确认人 / 意见来源'}),h(Field,{name:'role',label:'身份或职责'}),h(Field,{name:'date',label:'原记录日期',type:'date'}),
     h('label',null,'本记录覆盖的对象（可多选）',h('select',{name:'subjectIds',multiple:true,required:true},...subjects.map(([id,title])=>h('option',{key:id,value:id},id+' · '+title)))),
     h(Field,{name:'text',label:'意见、依据及限制的原文',area:true,maxLength:100000})))});
  }
  const recordsCard=()=>card('意见、确认与审批记录',p('事实范围、专业意见和业务审批分别留存。报告生成确认不会替代这些记录。'),result&&h(React.Fragment,null,...Object.entries(recordKinds).map(([key,title])=>button(title,()=>professionalForm(key)))),...(current.events||[]).filter(e=>e.kind==='professional_record').map(e=>p(recordKinds[e.category]+' · '+e.person+'（'+e.role+'） · '+e.date+' · '+e.subjectIds.join('、'))));
  const telemetryCard=()=>details('运行用量与提醒',p('模型：'+(execution?.model?.model||execution?.nextModel?.model||'宿主未返回')+'；本轮经过：'+(execution?.elapsedSeconds==null?'未开始':execution.elapsedSeconds+' 秒')),
   p(execution?.usage?'本轮宿主已报告 tokens：输入 '+execution.usage.uncachedInputTokens+'，输出 '+execution.usage.outputTokens+'，缓存读取 '+execution.usage.cacheReadTokens+'，缓存写入 '+execution.usage.cacheWriteTokens:execution?.usageTotals?'只取得会话累计用量，本轮差值尚不可用。':'宿主尚未返回可核对的用量，不以 0 代替。'),
   ...(execution?.reminders||[]).map(r=>p(r,'notice')),p('提醒是软提示，可能晚于实际用量；不自动取消，不推算金额。','hint'),
   h(Form,{busy,label:'保存提醒设置',onSave:v=>command('reminders',v)},h(Field,{name:'minutes',label:'耗时提醒（分钟，0 关闭）',type:'number',min:0,max:1440,defaultValue:current.reminders?.minutes||0}),h(Field,{name:'tokens',label:'本轮 tokens 提醒（含缓存，0 关闭）',type:'number',min:0,max:100000000,defaultValue:current.reminders?.tokens||0})));
  const reportCard=()=>card('报告生成与交付',button('审阅并生成报告',()=>reportWizard(),true),p('内置官方模板可直接选用，无需上传；其他地区或企业格式可使用扩展模板。'),details('使用其他模板（可选）',h('label',null,'上传报告模板 DOCX / PDF（保留原格式）',h('input',{type:'file',accept:'.docx,.pdf',disabled:busy,onChange:e=>{const f=e.target.files?.[0];e.target.value='';importFile(f,{purpose:'template'});}}))),
   p('报告绑定评估修订、模板及语言。生成、校验或页面检查失败时保留旧版，不提供未通过文件的正式下载。','hint'),
   ...reports.map(r=>h('article',{className:'row',key:r.requestId},
    h('h3',null,(r.reportType==='formal'?'正式报告':'待完善草稿')+' · '+r.language),p(r.template+' · '+(r.revisionId||'').slice(0,8)),p('文件版本 '+r.requestId.slice(-8)+' · 生成任务 '+(r.createdAt||'未记录'),'hint'),
    p('状态：'+({queued:'等待生成',composed:'Word 已生成，等待检查与渲染',rendering:'正在渲染',awaiting_page_review:'等待全部页面检查',ready:'检查通过，可下载',failed:'生成失败',render_failed:'渲染失败',unreadable:'记录无法读取'})[r.phase]),
    r.summary&&details('本版依据与决策摘要',p('任务创建插件版本：'+(r.summary.jobPluginVersion||'历史未记录')+'；当前插件版本：'+r.summary.runtimePluginVersion),p(r.summary.notice),...(r.summary.decisions.length?r.summary.decisions.map(d=>h('div',{className:'row'},p((d.jurisdiction||'未标明范围')+' · '+(d.recommendation||'未记录结论')),p(d.rationale||'未记录理由'))):[p('冻结底稿未记录决策。')])),
    r.reason&&p(r.reason,'error'),r.historicalBasis&&p('此报告依据历史材料或分析版本；当前输入已有变化。','notice'),(['failed','render_failed'].includes(r.phase)||(execution?.unfinished&&execution.requestId===r.requestId))&&button('同版重试生成（调用模型）',async()=>{const next=await command('retryReport',{reportRequestId:r.requestId,executionRevision:execution?.revision??0},false);if(next){setExecution(next);setNote('已复用原确认范围重试；旧产物保留。');}}),r.phase==='awaiting_page_review'&&h(React.Fragment,null,button('逐页检查',()=>previewReportPage(r)),button('全部检查后完成交付（不调用模型）',async()=>{const out=await command('completeReport',{requestId:r.requestId},false);if(out){const id=current.id;const [status,list]=await Promise.all([read('execution',{id}),read('reportList',{id})]);if(currentRef.current?.id===id){if(status)setExecution(status);if(list)setReports(list);}}})),r.phase==='ready'&&h(React.Fragment,null,button('逐页预览',()=>previewReportPage(r)),button(r.templateFormat==='pdf'?'下载 Word 转换工作副本':'下载这一版 Word',()=>downloadReportFile(r,'docx')),button('下载这一版 PDF',()=>downloadReportFile(r,'pdf'))),r.quality&&p(r.quality,'hint'))));
  const pages=[
   ()=>h(React.Fragment,null,card('本轮结果',result?.record.delivery?.kind==='screening_exit'&&p('本轮已交付筛查结论与复评条件；不强行创建风险报告。','notice'),!result?unavailable():h(React.Fragment,null,h('div',{className:'stats'},...['facts','questions','risks','actions'].map(k=>h('span',{key:k},(k==='questions'?a.questions.filter(q=>q.status==='open').length:a[k].length)+' '+({facts:'条事实',questions:'个待答',risks:'项风险记录',actions:'项整改'})[k]))),h('h3',null,label(result.screening?.result||'unknown')),p(result.conditionalBasis||'结论范围见来源审查与底稿。'),p('下一步：'+(a.questions.some(q=>q.status==='open')?'补充影响相关判断的具体事实；其余分析可继续。':'核对本轮结论、整改及相应报告条件。')),button('查看本轮报告',report),button('审阅并生成正式报告',()=>reportWizard('formal'),true),button('查看问题',()=>setTab(2)),button('查看风险与依据',()=>setTab(3)))),card('本轮限制',result?details('查看校验提示（不等于法律结论）',...result.warnings.map((x,i)=>p(x))):unavailable()),card('既有成果',p('早期插件产生的成果可在核验后采用，无需重新运行模型。'),button('选择既有成果',legacy))),
   ()=>h(React.Fragment,null,fileCard(),card('来源与证据',p(current.evidence.length?'已保存 '+current.evidence.length+' 份材料，可在下方查看原文。':'尚未保存材料，可上传文件或展开下方入口粘贴文字。','hint'),...current.evidence.map(e=>h('div',{key:e.id,className:'row'},h('strong',null,e.title),p(e.locator,'muted'),button('查看原文',()=>sources(e.id)),current.withdrawnSourceIds?.includes(e.id)?p('已撤回，下一轮排除','muted'):button('撤回本轮材料',()=>withdraw(e)))),details('添加文本证据（可选）',h(Form,{label:'保存文本证据',busy,onSave:v=>command('evidence',v)},h(Field,{name:'title',label:'材料名称',maxLength:200}),h(Field,{name:'locator',label:'来源位置 / 日期',maxLength:300}),h(Field,{name:'text',label:'原文',area:true,maxLength:100000})))),card('事实与来源',result?factCards():unavailable()),current.events?.length>0&&card('人工记录',...current.events.filter(e=>['fact_confirmation','fact_correction'].includes(e.kind)).map(e=>p((e.kind==='fact_confirmation'?'已记录确认':'已记录纠正')+' · '+e.factIds.join('、')+' · '+e.at+'；后续分析需吸收对应来源。')))),
   ()=>card('具体问题与补答',p('保存的待提交答复默认纳入本轮，你可以取消勾选。提交后等待复评；已解决问题归入历史，未解决的只需补充剩余信息。'),button('提交 '+selectedAnswers.length+' 项选定补答并复评',()=>{if(!selectedAnswers.length){setError('请先选择需要提交的答复。');return;}start('复评选定补答');},true),result?h(React.Fragment,null,a.questions.some(q=>!['answered','resolved','closed'].includes(q.status))?questions():p('本轮没有待补充的问题。'),a.questions.some(q=>['answered','resolved','closed'].includes(q.status))&&details('已解决问题与答复历史',...questions(true))):unavailable()),
   ()=>h(React.Fragment,null,card('筛查与维度',result?h(React.Fragment,null,h('h3',null,label(result.screening?.result||'unknown')),p(result.conditionalBasis),...result.dimensions.map(d=>h('div',{className:'row',key:d.rule_id},h('h3',null,(current.presentation?.rules?.[d.rule_id]||'评估事项')+' · '+label(d.review?.progress)),p('发现：'+label(d.review?.finding)+'；限制：'+(d.review?.limitations||'见依据')),p(readable(d.analysis)),details('法律依据',...references(d.source_refs)),details('技术追溯记录',code({ruleId:d.rule_id,sourceRefs:d.source_refs}))))):unavailable()),card('风险及判断依据',result?a.risks.map(r=>h('article',{key:r.id,className:'row'},h('h3',null,r.scenario),p('等级：'+label(r.gdpr_rating?.level)),p('受影响的人：'+r.affected_people),p('损害：'+r.harm),p(readable(r.legal_analysis)),details('事实、措施与评级依据',...a.facts.filter(f=>r.fact_ids.includes(f.id)).map(f=>factValue(f.value)),p('发生可能性：'+(r.gdpr_rating?.likelihood_reason||'尚未确定')),p('损害严重性：'+(r.gdpr_rating?.severity_reason||'尚未确定')),p('综合判断：'+(r.gdpr_rating?.rationale||'尚未确定')),p('保护措施的作用：'+(r.gdpr_rating?.measures_reason||'尚未确定')),...(Array.isArray(r.target_assumptions)?r.target_assumptions:[r.target_assumptions]).filter(Boolean).map(v=>p('判断前提：'+v)),...references(r.legal_refs),details('技术追溯记录',code({riskId:r.id,factIds:r.fact_ids,rating:r.gdpr_rating,legalRefs:r.legal_refs}))),button('查看关联整改',()=>setTab(4)),button('记录异议',()=>setModal({title:'记录判断异议',body:h(Form,{busy,label:'保存异议，待复评',onSave:async v=>{const ok=await command('dispute',{...v,riskId:r.id});if(ok)setModal(null);return ok;}},h(Field,{name:'person',label:'提出人 / 来源'}),h(Field,{name:'text',label:'异议及依据',area:true}))})))):unavailable())),
   ()=>card('整改与效果复评',p('措施实施自报、验证证据和剩余风险分别记录。保存进展不会自动关闭风险。'),button('复评措施及相关风险',()=>start('复评新增措施证据及受影响风险'),true),result?a.actions.map(x=>{const progress=current.actionProgress?.find(p=>p.actionId===x.id);return h('article',{key:x.id,className:'row'},h('h3',null,x.description),p('关联风险：'+x.risk_ids.join('、')),p('验收：'+x.acceptance),p('底稿状态：'+label(x.status)+'；责任：'+(x.owner||'未确定')+'；期限：'+(x.due||'未确定')),progress&&p('最新登记：'+label(progress.status)+' · '+progress.owner+' · '+progress.due),details('登记计划 / 实施证据',h(Form,{busy,label:'保存进展（待复评）',onSave:v=>command('actionProgress',{...v,actionId:x.id})},h(Field,{name:'owner',label:'责任人',required:false}),h(Field,{name:'due',label:'期限',type:'date',required:false}),h('label',null,'进展',h('select',{name:'status'},h('option',{value:'planned'},'计划'),h('option',{value:'reported_implemented'},'实施自报'),h('option',{value:'evidence_submitted'},'提交验证证据'))),h(Field,{name:'text',label:'进展与证据原文',area:true,maxLength:100000}))));}):unavailable()),
   ()=>h(React.Fragment,null,card('报告与版本',result?h(React.Fragment,null,p('依据修订：'+result.record.revisionId),button('预览 / 下载内部报告',report,true),button('本地重生成内部报告',async()=>{const out=await command('generateInternalReport',{},false);if(out){setNote('已按本版底稿本地生成，未调用模型。');report();}}),button('选择范围并下载归档包',archivePackage),button('查看结果历史与差异',history)):unavailable()),reportCard(),recordsCard(),card('案件归档与恢复',p('归档保留全部材料和历史，不等于评估批准。'),button(current.archived?'恢复案件':'归档案件',()=>command('archive',{archived:!current.archived})),details('恢复历史输入为新修订',h(Form,{busy,label:'恢复选定输入版本',onSave:v=>command('restoreInput',{fromVersion:Number(v.fromVersion)})},h(Field,{name:'fromVersion',label:'历史材料修订号',type:'number',min:1,max:current.version-1})))) )
  ];
  const executionLabel=!execution?.sessionId?'尚未启动':execution.statusKnown===false?'宿主状态暂不可读':execution.running?'运行中':execution.phase==='uncertain'?'回执待核':execution.phase==='cancel_requested'?'中止请求待完成':execution.phase==='cancelled'?'已中止':execution.recoverable?'会话丢失，可恢复':'已停止';
  const syncLabel=current?.resultError?'读取失败':execution?.sync?.state==='failed'?'同步失败（旧版保留）':result?'已同步':execution?.sync?.state==='waiting'?'等待完整成果':'尚无结果';
  const cases=index.cases.filter(c=>c.title.toLowerCase().includes(search.toLowerCase())&&(filter==='archived'?c.archived:filter==='pending'?!c.archived&&(c.openGaps===null||c.openGaps>0):!c.archived));
  return h('div',{className:'dpia','data-testid':'dpia-workbench'},h('style',null,css+communityCss),h('header',{className:'top'},h('div',null,h('h1',null,'DPIA 工作台'),p('材料、分析、补答、整改与报告，关联到同一评估版本。','muted')),h('div',{className:'community-top'},h('button',{type:'button',onClick:()=>setHelpOpen(true)},'帮助与交流'),h('span',{className:'pill'},'完整版开发中 · Skill 0.7.8'))),
   error&&h('div',{role:'alert',className:'notice error'},error),note&&h('div',{role:'status',className:'notice'},note),
   h('div',{className:'grid'},h('aside',null,card('评估案件',h('input',{'aria-label':'搜索案件',placeholder:'搜索项目',value:search,onChange:e=>setSearch(e.target.value)}),h('select',{'aria-label':'案件筛选',value:filter,onChange:e=>setFilter(e.target.value)},h('option',{value:'active'},'当前案件'),h('option',{value:'pending'},'待处理'),h('option',{value:'archived'},'已归档')),cases.length===0&&p('没有匹配的案件。','muted'),...cases.map(c=>h('button',{className:'case'+(c.id===current?.id?' active':''),key:c.id,disabled:busy,onClick:()=>open(c.id)},h('strong',null,c.title),h('small',null,c.resultStatus==='synced'?c.openGaps+' 个待答 · '+c.riskCount+' 项风险记录':c.resultStatus==='failed'?'结果无法读取':'结果尚未同步'))),index.testFixtures.length>0&&details('测试样例（非正式评估）',...index.testFixtures.map(c=>button(c.title,()=>open(c.id)))),...index.errors.map(e=>p(e.id+'：'+e.error)),button('刷新',()=>current?open(current.id):refreshList())),card('新建评估',h(Form,{label:'创建评估',busy,onSave:v=>command('create',v)},h(Field,{name:'title',label:'项目名称',maxLength:200})),p('新评估为空，不预设日志问题或合规结论。','hint'))),h('main',null,!current?h(React.Fragment,null,card('从材料开始',p('创建或选择一个评估。只有明确发起分析时才调用模型。')),!helpOpen&&h(CommunityContact)):h(React.Fragment,null,current.isTestFixture&&p('测试样例 · 非正式业务评估','notice'),card(current.title,p('执行：'+executionLabel+' ｜ 同步：'+syncLabel+' ｜ 评估：'+(result?.conditionalBasis?'条件分析':result?'以本轮记录为准':'尚未分析')),p('当前材料修订 '+current.version+' · 分析依据材料 '+(result?.record.inputVersion??'尚无')+(result&&result.record.materialDigest!==current.materialDigest?' · 有未纳入本轮的变化':''),'muted'),button(['uncertain','submitting'].includes(execution?.phase)?'重试同一请求':result?'基于当前材料继续分析':'开始分析',()=>start('分析当前有效材料'),true),execution?.sessionId&&button('打开执行会话',()=>openSession(execution.sessionId)),execution?.recoverable&&button('恢复评估会话（不调用模型）',async()=>{const r=await command('recoverSession',{executionRevision:execution.revision},false);if(r){setExecution(r);setNote('会话已重新绑定，原任务和成果保留。核对本轮材料后可继续分析。');}}),execution?.unfinished&&h(React.Fragment,null,p('宿主已停止，本轮尚未完成交付。已有成果保留。','notice'),execution.kind!=='report'&&button('修复本轮输出（调用模型）',async()=>{const r=await command('repairOutput',{executionRevision:execution.revision},false);if(r){setExecution(r);setNote('已提交产物修复；沿用原任务材料，不混入本轮之后的新输入。');}})),execution?.unarchivedInput&&h(React.Fragment,null,p('会话在本轮提交后有新增输入，可能尚未归档到工作台。请核对后整理。','notice'),button('整理会话新增输入',()=>start('整理本会话新增用户答复为带出处的来源记录，逐项关联问题后复评；没有确认事件的内容不能当作已确认事实'))),execution?.running&&button('中止当前任务',async()=>{const r=await command('cancel',{executionRevision:execution.revision},false);if(r){setExecution(r);setNote(r.cancelAcknowledged?'已请求中止当前任务；宿主队列保留。':'中止回执未确认，请打开会话核对。');}}),telemetryCard(),button('刷新运行状态',()=>refreshCurrent()),button('重试同步（不调用模型）',async()=>{const r=await command('sync',{},false);if(r){setNote(r.state==='synced'?'结果已同步':r.state==='waiting'?'任务尚未提交完整成果；可打开会话核对。':'同步失败：'+(r.details||r.code));if(r.state==='synced')await open(current.id);}}),execution?.sync?.state==='failed'&&p((execution.sync.details||[execution.sync.code]).join('\n'),'error')),h('nav',{className:'actions','aria-label':'评估页签'},...['总览','材料与事实','问题与补答','评估与风险','整改与复评','报告与版本'].map((name,i)=>h('button',{key:name,type:'button',className:tab===i?'primary':'',onClick:()=>setTab(i)},name))),h(RenderBoundary,{key:current.id+':'+tab+':'+(result?.record.revisionId||''),onHome:()=>{setModal(null);setTab(0);}},h(PageContent,{render:pages[tab]}))))),
   helpOpen&&h(CommunityHelp,{onClose:()=>setHelpOpen(false)}),
   modal&&h('div',{role:'dialog','aria-modal':true,'aria-label':modal.title,style:{position:'fixed',inset:0,background:'#14243c88',zIndex:9999,display:'flex',alignItems:'center',justifyContent:'center'}},h('section',{className:'card',style:{maxWidth:900,width:'90%',maxHeight:'88vh',display:'flex',flexDirection:'column',overflow:'hidden'}},h('header',{style:{display:'flex',alignItems:'center',justifyContent:'space-between',gap:16,flexShrink:0}},h('h2',null,modal.title),h('button',{type:'button','aria-label':'关闭窗口',onClick:()=>setModal(null),style:{margin:0,whiteSpace:'nowrap'}},'关闭 ×')),h('div',{className:'modal-body',style:{overflowY:'auto',minHeight:0}},h(RenderBoundary,{key:modal.title,onHome:()=>{setModal(null);setTab(0);}},modal.body),modal.run&&button('确认输入并开始运行',execute,true))))
  );
 }
 exports.inject=['slots','connection','uiWorkspace'];
 exports.apply=function(ctx){
  const rpc=async payload=>{const result=await ctx.connection.rpc.call('/api','dpia.workbench',payload);if(!result.ok)throw new Error(result.error.message);return result.value;};
  ctx.slots.inject('main',()=>ctx.slots.register({name:'main',key:'dpia-workbench',inject:()=>({rpc,openSession:id=>ctx.uiWorkspace.openSession(id)})},Workbench));
  ctx.slots.inject('sidebar.panellist',()=>ctx.slots.register({name:'sidebar.panellist',id:'dpia-workbench',label:'DPIA 工作台',order:30},()=>h('span',{'aria-hidden':true},'◈')));
 };
 return exports;
}});
