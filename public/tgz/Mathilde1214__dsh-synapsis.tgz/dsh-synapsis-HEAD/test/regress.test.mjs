import test from 'node:test'
import assert from 'node:assert/strict'
import os from 'node:os'
import path from 'node:path'
import { promises as fs } from 'node:fs'

import { safeName } from '../lib/paths.mjs'
import { assertDoc, normalizeDoc } from '../lib/validate.mjs'
import { createStore } from '../lib/store.mjs'
import { registerTools } from '../lib/tools.mjs'

const source = await fs.readFile(new URL('../core/synapsis-core.js', import.meta.url), 'utf8')
const createMindMap = new Function(source + '\nreturn createMindMap;')()
/* 工厂返回 { MindMap, buildLayout, fitFor, createMathRenderer, sortReviewPool }：
   这里只测不依赖渲染器的几个纯函数，所以 React 给个空壳就够。 */
const mind = createMindMap({
  createElement: () => null,
  Fragment: 'fragment',
  useState: (v) => [v, () => {}],
  useMemo: (f) => f(),
  useRef: (v) => ({ current: v }),
  useCallback: (f) => f,
  useEffect: () => {},
})

const blank = (title) => ({
  version: 1,
  title,
  subtitle: '',
  updated: new Date().toISOString(),
  nodes: [{ id: 'root', title, parent: null, mastery: 0 }],
  edges: [],
})

async function tempStore() {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'syn-regress-'))
  return { store: createStore(dir), dir }
}

test('Windows 设备名带扩展名也要拒绝', () => {
  assert.equal(safeName('CON.foo.mindmap.json'), null)
  assert.equal(safeName('lpt9.x.mindmap.json'), null)
  assert.equal(safeName('console.mindmap.json'), 'console.mindmap.json')
})

test('保存到不存在的文件返回 gone，新建只能走 create', async () => {
  const { store, dir } = await tempStore()
  await assert.rejects(
    () => store.save('不存在.mindmap.json', blank('x'), 'whatever'),
    (err) => err.code === 'gone',
  )
  await fs.rm(dir, { recursive: true, force: true })
})

test('版本令牌精确：内容变一次，旧令牌就失效', async () => {
  const { store, dir } = await tempStore()
  const made = await store.create('两个版本')
  const v1 = structuredClone(made.data)
  v1.nodes[0].title = 'A'
  const s1 = await store.save(made.name, v1, made.token)
  const v2 = structuredClone(v1)
  v2.nodes[0].title = 'B'
  const s2 = await store.save(made.name, v2, s1.token)
  assert.notEqual(s1.token, s2.token)
  await assert.rejects(
    () => store.save(made.name, v1, s1.token),
    (err) => err.code === 'conflict' && err.token === s2.token,
  )
  await fs.rm(dir, { recursive: true, force: true })
})

test('多根 / 自环 / 类型错误都会被拒；未知字段不会丢', () => {
  const multi = { ...blank('多根'), nodes: [{ id: 'a', title: 'a', parent: null }, { id: 'b', title: 'b', parent: null }] }
  assert.throws(() => assertDoc(multi), (err) => err.code === 'bad_doc' && err.issues.includes('multi-root'))

  const loop = { ...blank('环'), nodes: [{ id: 'root', title: 'r', parent: null }, { id: 'a', title: 'a', parent: 'b' }, { id: 'b', title: 'b', parent: 'a' }] }
  assert.throws(() => assertDoc(loop), (err) => err.code === 'bad_doc' && err.issues.includes('cycle'))

  const typed = { ...blank('类型'), nodes: [{ id: 'root', title: 'r', parent: null, mastery: 7 }] }
  assert.throws(() => assertDoc(typed), (err) => err.code === 'bad_doc')

  const rich = { ...blank('保留'), tags: ['a', 'b'], extra: { keep: true }, nodes: [{ id: 'root', title: 'r', parent: null, tags: ['x'], position: { x: 1 } }] }
  const { doc } = normalizeDoc(rich)
  assert.deepEqual(doc.tags, ['a', 'b'])
  assert.deepEqual(doc.extra, { keep: true })
  assert.deepEqual(doc.nodes[0].tags, ['x'])
  assert.deepEqual(doc.nodes[0].position, { x: 1 })
})

test('大图校验是线性的（5000 节点不卡）', () => {
  /* 深度限制是 32，所以这里做一棵「宽而浅」的树来测规模，而成环检测本身就是线性的 */
  const nodes = [{ id: 'root', title: 'r', parent: null }]
  for (let i = 0; i < 4999; i += 1) nodes.push({ id: `n${i}`, title: `n${i}`, parent: 'root' })
  const started = Date.now()
  assert.doesNotThrow(() => assertDoc({ ...blank('大图'), nodes }))
  assert.ok(Date.now() - started < 3000, '5000 节点应在 3 秒内完成')
})

test('本地没学过的概念和复习过的没印象不是一回事：排序仍分档', () => {
  const nodes = [
    { id: 'root', title: 'root', parent: null },
    { id: 'a', title: '甲', parent: 'root', mastery: 2, definition: 'x' },
    { id: 'b', title: '乙', parent: 'root', mastery: 0, definition: 'x' },
    { id: 'c', title: '丙', parent: 'root', mastery: 1, definition: 'x' },
  ]
  const pool = mind.sortReviewPool(nodes, 'root')
  assert.deepEqual(pool.map((n) => n.id), ['c', 'b', 'a'])
})

test('id 叫 constructor 的节点不会被顺手删掉', () => {
  const map = mind
  assert.equal(typeof map.buildLayout, 'function')
  const nodes = [
    { id: 'root', title: 'root', parent: null },
    { id: 'constructor', title: '构造器', parent: 'root' },
    { id: 'toString', title: '字符串', parent: 'root' },
  ]
  const layout = map.buildLayout(nodes, 'root')
  assert.ok(layout.byId.has('constructor'))
  assert.ok(layout.byId.has('toString'))
  assert.equal(layout.order.length, 3)
})

test('更新工具：局部改一个字段，不碰关系与掌握度；带旧令牌会被拒', async () => {
  const { store, dir } = await tempStore()
  const made = await store.create('局部更新')
  const v2 = structuredClone(made.data)
  v2.nodes[0].title = '局部更新'
  v2.nodes.push({ id: 'kid', title: '子', parent: 'root', mastery: 2, note: '我的笔记', definition: '原来的定义' })
  v2.edges = [{ from: 'root', to: 'kid', type: 'related' }]
  const saved = await store.save(made.name, v2, made.token)

  const { ctx, tools } = fakeCtx()
  registerTools(ctx, store)
  const update = tools.find((t) => t.name === 'synapsis_update_map')
  const loaded = await store.read(made.name)

  await update.execute({
    name: made.name,
    versionToken: loaded.token,
    nodes: [{ id: 'kid', definition: '改过的定义' }],
  })
  const after = await store.read(made.name)
  const kid = after.data.nodes.find((n) => n.id === 'kid')
  assert.equal(kid.definition, '改过的定义')
  assert.equal(kid.mastery, 2, '没传的掌握度要保留')
  assert.equal(kid.note, '我的笔记', '没传的笔记要保留')
  assert.equal(after.data.edges.length, 1, '不传 edges 时关系要保留')

  await assert.rejects(
    () => update.execute({ name: made.name, versionToken: saved.token, nodes: [{ id: 'kid', note: 'x' }] }),
    (err) => err.code === 'conflict',
  )
  await fs.rm(dir, { recursive: true, force: true })
})

function fakeCtx() {
  const tools = []
  return {
    tools,
    ctx: {
      tools: { register: (def) => { tools.push(def); return () => {} } },
    },
  }
}

test('版本号必须是整数：true / null / "1" 都算畸形', () => {
  const base = { ...blank('版本'), nodes: [{ id: 'root', title: 'r', parent: null }] }
  for (const bad of [true, null, '1', 1.5]) {
    assert.throws(
      () => assertDoc({ ...base, version: bad }),
      (err) => err.code === 'bad_doc' && err.issues.includes('version-invalid'),
      `version=${String(bad)} 应该被拒`,
    )
  }
  const { doc, warnings } = normalizeDoc({ ...base, version: true })
  assert.equal(doc.version, 1, '畸形版本号按 1 存')
  assert.ok(warnings.includes('version-invalid'), '并给出提醒')
})

test('历史里时间戳相同时，latest.json 排第一', async () => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'syn-hist-'))
  const store = createStore(dir)
  const made = await store.createFrom({ ...blank('历史'), nodes: [{ id: 'root', title: 'r', parent: null }] }, '历史.mindmap.json')
  const token1 = made.token
  const doc = (await store.read(made.name)).data
  const saved = await store.save(made.name, { ...doc, title: '历史 v2' }, token1)
  /* 再写一次，产生多个检查点/快照文件 */
  await store.save(made.name, { ...doc, title: '历史 v3' }, saved.token)

  const historyDir = path.join(dir, '.history', '历史')
  const files = (await fs.readdir(historyDir)).filter((f) => f.endsWith('.json'))
  const same = new Date('2026-01-01T00:00:00Z')
  for (const f of files) await fs.utimes(path.join(historyDir, f), same, same)

  const list = await store.history(made.name)
  assert.ok(list.length >= 2, '至少两个历史版本')
  assert.equal(list[0].latest, true, '同一毫秒时 latest.json 必须排第一')
  await fs.rm(dir, { recursive: true, force: true })
})

test('409 里带回的令牌可以直接用来覆盖', async () => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'syn-cover-'))
  const store = createStore(dir)
  const made = await store.createFrom({ ...blank('覆盖'), nodes: [{ id: 'root', title: 'r', parent: null }] }, '覆盖.mindmap.json')
  const firstToken = made.token
  const doc = (await store.read(made.name)).data

  /* 别处先改一次 */
  await store.save(made.name, { ...doc, title: '别处改的' }, firstToken)

  /* 本地拿着旧令牌去写：应当 409，并带回磁盘上那一版的令牌 */
  let conflicted = null
  try {
    await store.save(made.name, { ...doc, title: '我的版本' }, firstToken)
  } catch (err) {
    conflicted = err
  }
  assert.equal(conflicted.code, 'conflict')
  assert.equal(typeof conflicted.token, 'string')

  /* 用 409 里的令牌再写：这一次必须成功 */
  const ok = await store.save(made.name, { ...doc, title: '我的版本' }, conflicted.token)
  assert.equal(typeof ok.token, 'string')
  const after = await store.read(made.name)
  assert.equal(after.data.title, '我的版本')
  await fs.rm(dir, { recursive: true, force: true })
})

test('createFrom 用同一份内容另存不会覆盖已有文件', async () => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'syn-copy-'))
  const store = createStore(dir)
  const doc = { ...blank('副本'), nodes: [{ id: 'root', title: 'r', parent: null }] }
  const a = await store.createFrom(doc, '副本.mindmap.json')
  /* 指定了文件名就不覆盖：直接报 exists，让调用方自己决定改名 */
  await assert.rejects(() => store.createFrom(doc, '副本.mindmap.json'), (err) => err.code === 'exists')
  /* 不给文件名时自动让位 */
  const b = await store.createFrom({ ...doc, title: '副本' })
  const c = await store.createFrom({ ...doc, title: '副本' })
  assert.notEqual(b.name, c.name, '重名时自动换名字，不覆盖')
  assert.equal(a.name, '副本.mindmap.json')
  await fs.rm(dir, { recursive: true, force: true })
})

test('回收站能列出并放回指定那一份', async () => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'syn-trash-'))
  const store = createStore(dir)
  const doc = { ...blank('回收'), nodes: [{ id: 'root', title: '回收', parent: null }] }
  const made = await store.createFrom(doc, '回收.mindmap.json')
  await store.trash(made.name)

  const list = await store.trashList()
  assert.equal(list.length, 1)
  assert.equal(list[0].name, '回收.mindmap.json')
  assert.ok(list[0].at, '带删除时间')

  /* 名字先被别人占了：放回来时自动让位，不覆盖 */
  await store.createFrom(doc, '回收.mindmap.json')
  const back = await store.restoreFile(list[0].file)
  assert.equal(back.name, '回收-2.mindmap.json')
  assert.equal((await store.trashList()).length, 0)

  /* 指定的那份不存在时报 not_found；带斜杠的名字直接拒 */
  await assert.rejects(() => store.restoreFile('nope.mindmap.json.2026-01-01T00-00-00-000Z'), (err) => err.code === 'not_found')
  await assert.rejects(() => store.restoreFile('../x.mindmap.json'), (err) => err.code === 'bad_name')
  await fs.rm(dir, { recursive: true, force: true })
})
