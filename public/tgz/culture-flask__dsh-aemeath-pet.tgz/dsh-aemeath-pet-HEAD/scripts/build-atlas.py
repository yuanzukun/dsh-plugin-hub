#!/usr/bin/env python3
"""Rebuild the Aemeath pet spritesheet from the original GIF sources.

The published Codex Pet V2 atlas is 192x208 cells built by downscaling 200x200
GIF art and re-encoding it lossily, which softens the sprites. This script
rebuilds the atlas directly from the native 200x200 frames at 2x (400x400
cells) with a high-quality resample, so the client can sample 1:1 on HiDPI
screens (devicePixelRatio >= 2) and downsample cleanly otherwise.

Row/frame mapping is taken from the original aemeath-codex-pet
docs/source-mapping.json. Source GIFs keep their own transparency; nothing is
keyed from a background.

Usage:
    python3 scripts/build-atlas.py --sources ~/aemeath-gif --out assets/spritesheet-2x.webp
"""
import argparse
import glob
import os
import sys

from PIL import Image, ImageFilter

# Row -> (source gif prefix, frame indices). Mirrors aemeath-codex-pet source-mapping.json.
ROWS = [
    ('idle',        'd86375e8', [0, 3, 6, 9, 12, 15, 0]),
    ('run-right',   '455f181e', [0, 1, 2, 3, 4, 5, 6, 7]),
    ('run-left',    '455f181e', [0, 1, 2, 3, 4, 5, 6, 7]),   # mirrored below
    ('waving',      '24a4bbf1', [0, 2, 4, 6]),
    ('jumping',     '53a58a26', [0, 2, 4, 6, 7]),
    ('failed',      '216d4f2d', [0, 3, 6, 9, 12, 15, 19, 24]),
    ('waiting',     '216d4f2d', [0, 5, 10, 15, 20, 24]),
    ('work',        '1a05d5b6', [0, 1, 2, 3, 4, 6]),
    ('review',      '216d4f2d', [0, 5, 10, 15, 20, 24]),
    ('look-front',  'd86375e8', [0] * 8),
    ('look-back',   'd86375e8', [0] * 8),
]
COLUMNS = 8


def load_sources(folder):
    """Index the GIF sources by filename prefix."""
    sources = {}
    for path in sorted(glob.glob(os.path.join(folder, '*.gif'))):
        sources[os.path.basename(path)[:8]] = path
    return sources


def frame_of(path, index):
    """Return one frame of a GIF as RGBA."""
    img = Image.open(path)
    n = getattr(img, 'n_frames', 1)
    img.seek(min(index, n - 1))
    return img.convert('RGBA')


def build(sources, scale, sharpen):
    """Compose the atlas grid and return (image, cell size)."""
    base = None
    for _name, prefix, _idx in ROWS:
        base = frame_of(sources[prefix], 0).size
        break
    cell = (base[0] * scale, base[1] * scale)
    sheet = Image.new('RGBA', (cell[0] * COLUMNS, cell[1] * len(ROWS)), (0, 0, 0, 0))

    for r, (name, prefix, indices) in enumerate(ROWS):
        path = sources[prefix]
        mirror = name == 'run-left'
        for c, idx in enumerate(indices):
            fr = frame_of(path, idx)
            if fr.size != base:
                fr = fr.resize(base, Image.LANCZOS)
            if mirror:
                fr = fr.transpose(Image.FLIP_LEFT_RIGHT)
            if scale != 1:
                fr = fr.resize(cell, Image.LANCZOS)
            sheet.alpha_composite(fr, (c * cell[0], r * cell[1]))
    if sharpen > 0:
        # Mild unsharp mask on RGB only; alpha stays binary.
        rgb = sheet.convert('RGB').filter(
            ImageFilter.UnsharpMask(radius=1.0, percent=int(sharpen * 100), threshold=2))
        rgb = Image.merge('RGBA', (*rgb.split(), sheet.getchannel('A')))
        sheet = rgb
    return sheet, cell


def report(sheet, cell):
    """Print validation facts so a bad rebuild fails loudly."""
    w, h = sheet.size
    print(f'sheet: {w}x{h}, cell: {cell[0]}x{cell[1]}, grid: {COLUMNS}x{len(ROWS)}')
    px = sheet.load()
    semis = 0
    for y in range(0, h, 2):
        for x in range(0, w, 2):
            a = px[x, y][3]
            if 0 < a < 255:
                semis += 1
    print(f'semi-transparent sample pixels: {semis}')
    used = []
    for r in range(len(ROWS)):
        cols = len(ROWS[r][2])
        used.append(cols)
    print('frames per row:', used)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--sources', required=True, help='folder with the original .gif files')
    ap.add_argument('--out', required=True, help='output .webp path')
    ap.add_argument('--scale', type=int, default=2, help='atlas scale vs native art (default 2)')
    ap.add_argument('--sharpen', type=float, default=0.35, help='unsharp mask percent (0 disables)')
    ap.add_argument('--quality', type=int, default=95, help='webp quality')
    args = ap.parse_args()

    sources = load_sources(args.sources)
    missing = sorted({p for _n, p, _i in ROWS if p not in sources})
    if missing:
        sys.exit(f'missing source gifs: {missing}')

    sheet, cell = build(sources, args.scale, args.sharpen)
    report(sheet, cell)
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    sheet.save(args.out, 'WEBP', quality=args.quality, method=6)
    size = os.path.getsize(args.out)
    print(f'wrote {args.out} ({size/1024/1024:.2f} MB, q={args.quality})')


if __name__ == '__main__':
    main()
