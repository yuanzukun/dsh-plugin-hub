# dsh-aemeath-pet

爱弥斯 · DeepSeek Harness 桌宠 — DeepSeek Harness Web GUI 的像素风宠物插件。

爱弥斯会停在页面角落，陪 agent 一起工作：
<img width="1220" height="672" alt="屏幕截图 2026-08-14 221709" src="https://github.com/user-attachments/assets/cd101920-3442-4c73-80c6-6080074a7725" />
<img width="1118" height="676" alt="屏幕截图 2026-08-14 221702" src="https://github.com/user-attachments/assets/000e50d7-9c47-452e-bef3-47ff064649f5" />

| 场景          | 动作                         |
| ----------- | -------------------------- |
| Agent 空闲    | 随机奔跑 / 原地工作 / 跳跃（不受会话状态限制） |
| Agent 正在运行  | 工作动画 + 「思考中…」              |
| Agent 等待你输入 | 等待动画 + 「等你哦～」              |
| Agent 步骤出错  | 失败动画 + 「唔…出错了」             |
| 新任务开始       | 跳跃 + 「交给我吧！」               |
| 一轮任务完成      | 跳跃庆祝 + 「搞定啦 ✨」             |
| 点击 / 触碰     | 挥手回应                       |

## 功能

- 🎬 全部 11 种动画（待机 / 左右移动 / 挥手 / 跳跃 / 失败 / 等待 / 工作 / 检查 / 两向注视），8×11 网格布局，**2× 重建图集**（3200×4400，每格 400×400）
- 🐾 右击菜单：停靠角落 / 自由摆放、大小（小·中·大）、隐藏、重置位置；拖拽可随意移动
- 💬 跟随 DSH 语言的中/英气泡文案（locale 命名空间 `dsh-aemeath-pet`）
- 🏃 随时随机表演：向左/右斜向奔跑（running-left / running-right，含垂直分量）、原地工作（running）、跳跃（jumping）— 停靠和自由摆放模式下都会出现
- 💾 偏好（启用 / 缩放 / 位置）持久化在 localStorage
- 🔌 纯客户端渲染（canvas + DOM，无 React 依赖）；Host 半只负责服务精灵图素材

## 0.2.0 更新

提升了贴图精度：

![0.1.0 与 0.2.0 贴图对比（125% 缩放下的实际渲染）](docs/0.2.0-before-after.png)

- **2× 重建图集**：从原始 200×200 GIF 素材按 2× 重建（每格 400×400）。
- **DPR 自适应渲染**：canvas 位图尺寸改为 `逻辑尺寸 × devicePixelRatio`，CSS 尺寸保持逻辑值。125% / 150% Windows 缩放和 Retina 屏幕上不再由浏览器放大逻辑分辨率位图 —— 这是之前「发糊」的主因
- **高质量重采样**：素材是柔和插画风而非硬像素画，因此用高质量缩放（2× 屏 1:1 直出、125% 屏干净缩小）替代块状放大
- **跨屏自适应**：窗口拖到不同缩放的显示器时，画布按新 DPR 自动重建
- **兼容新版 Harness 客户端 API**：改为按「运行状态翻转 + 最近错误」推导动作，不再依赖已被移除的回合计数与待处理交互字段（顺带修复：在新版 Harness 上旧版会一直待机不响应）
- **可复现**：图集由 `scripts/build-atlas.py` 生成，原始 GIF 存放在 `assets/sources/`，执行 `pnpm run build:atlas` 即可重建

动画帧数、动作映射与交互行为与 0.1.0 一致，**升级无需改配置**。

## 安装

```sh
dsh plugin --profile web add https://github.com/culture-flask/dsh-aemeath-pet/archive/refs/tags/v0.2.0.tar.gz
```

从 0.1.0 升级：把命令里的 tag 改成 `v0.2.0` 重新安装，然后重启 `dsh web` 并硬刷新浏览器（Cmd/Ctrl+Shift+R）即可看到爱弥斯。

## 目录结构

```text
dsh-aemeath-pet/
├─ src/
│  ├─ index.ts          # host 半：webServer 素材路由（/aemeath-pet/spritesheet.webp）
│  └─ client/           # 浏览器半（无 React，canvas + DOM）
│     ├─ index.ts       # 会话接线：snapshot → 情绪/动作 + 气泡
│     ├─ pet.ts         # 宠物引擎：动画循环、随机动作、拖拽/菜单/偏好
│     ├─ state.ts       # 纯函数状态派生（单测覆盖）
│     ├─ atlas.ts       # Codex Pet V2 图集布局（每动画的行/帧/帧率）
│     ├─ locales.ts     # 中英文案
│     └─ styles.ts      # 注入样式
├─ assets/
│  ├─ spritesheet-2x.webp  # 2× 重建图集（3200×4400，每格 400×400）
│  └─ sources/             # 六个原始 GIF（图集重建的输入）
├─ scripts/
│  └─ build-atlas.py    # 从 GIF 重建 2× 图集（pnpm run build:atlas）
├─ lib/                 # 构建产物（提交）
├─ tests/               # state 纯逻辑 + pet jsdom 引擎测试
├─ CHANGELOG.md         # 版本变更记录
├─ cordis.patch.yml     # bundle 补丁（挂载行）
└─ dsh.plugin.json      # 插件元数据
```

## 素材与版权

素材来源：

- **精灵图与图集布局**：行/帧编排源自 [aemeath-codex-pet](https://github.com/ChuyuZhong/aemeath-codex-pet)（Apache-2.0，R2）。0.2.0 起图集由本仓库 `scripts/build-atlas.py` 直接从那六个原始 GIF 以 2× 分辨率重建（`assets/spritesheet-2x.webp`），不再使用该仓库降采样后的 192×208 图集
- **角色形象**：爱弥斯出自游戏 **《鸣潮》（Wuthering Waves）**，角色及美术素材权利归 Kuro Games / 相应权利方所有
- **原始表情包素材**：出自 B 站 up 主 **「Neuro音乐」** 的动态：[哔哩哔哩 · 爱弥斯表情包](https://www.bilibili.com/opus/1167003396733927448)

本项目是非官方、非商业的同人桌宠适配项目；本仓库不对这些素材授予额外的商业使用许可。角色形象与原始美术素材权利归原作者与相应权利方所有，仅供个人使用；二次分发或商业使用请先取得授权。

## License

Apache-2.0，见 [LICENSE](./LICENSE)。
