# Changelog

All notable changes to this plugin are documented here. Versions follow
[Semantic Versioning](https://semver.org/); the plugin targets the DeepSeek
Harness web GUI.

## 0.2.0

Sharper sprites, and compatibility with the restructured Harness client API.

### Changed

- **Rebuilt sprite atlas at 2× resolution.** The 0.1.0 atlas was 192×208 cells
  produced by downscaling the original 200×200 GIF art and re-encoding it
  lossily. The atlas is now rebuilt directly from those native GIFs at 400×400
  cells (3200×4400 sheet), so the texture carries the art's full detail.
  Regenerate it with `pnpm run build:atlas`; the six source GIFs are vendored
  under `assets/sources/`.
- **Device-pixel-ratio aware rendering.** The canvas bitmap is now
  `logical × devicePixelRatio` with an explicit CSS box, so the browser no
  longer upscales a logical-resolution bitmap on 125%/150% display scaling or
  Retina screens (the main cause of the old softness). Moving the window to a
  display with a different scale rebuilds the canvas.
- **High-quality resampling** replaces `image-rendering: pixelated`. The art is
  a soft illustration rather than hard pixel art, so a high-quality resample
  (1:1 at 2×, clean downscale at 125%) reads sharper than block scaling.
- The pet's logical size now derives from the native 200×200 art, so it keeps
  the same on-screen proportions as before.

### Fixed

- **Harness 0.2.x client compatibility.** The client wiring depended on
  `SessionListState.current`, turn counters and pending-interaction lists,
  which the restructured Harness client API removed. The pet now derives its
  state from the stable parts only — list summaries with a running flag and the
  bound session snapshot's `running` / `lastAgentError` — and types the
  sessions service structurally, so future renames do not break loading.
- Burst reactions follow the running flag: work starts → jumping + 「交给我吧！」,
  work finishes → jumping + 「搞定啦 ✨」, a new error → failed + 「唔…出错了」.

### Notes

- Upgrading needs no configuration change: run the install command with the
  `v0.2.0` tag and restart `dsh web` (the host half serves the new atlas).
- The `assets/sources/` GIFs and the rebuilt atlas derive from the same fan-made
  assets credited in the README; the art's rights stay with the original
  creators.
