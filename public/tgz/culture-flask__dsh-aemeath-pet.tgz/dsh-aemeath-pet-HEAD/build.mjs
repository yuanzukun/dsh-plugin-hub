/**
 * dsh-aemeath-pet build: single-file client bundle + ESM host build.
 *
 * The web server serves exactly one file per plugin (/plugins/dsh-aemeath-pet/client.js),
 * so the client half is one CJS bundle wrapped in the ModuleLoader factory
 * handshake. The client imports only types from @deepseek-ai/dsh-* (erased at
 * build time) and touches the DOM/canvas directly, so the bundle has no
 * external runtime dependencies. The host half is plain ESM for Node,
 * externalizing @deepseek-ai/dsh-* plus cordis.
 */
import { build } from 'esbuild'
import { mkdirSync } from 'node:fs'

mkdirSync('lib', { recursive: true })

const dshExternal = ['@deepseek-ai/cordis', '@deepseek-ai/dsh-*']

await build({
  entryPoints: ['src/index.ts'],
  outfile: 'lib/index.js',
  bundle: true,
  format: 'esm',
  platform: 'node',
  target: ['node22'],
  sourcemap: true,
  external: dshExternal,
  logLevel: 'info',
})

await build({
  entryPoints: ['src/client/index.ts'],
  outfile: 'lib/client.js',
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: ['es2022'],
  sourcemap: true,
  external: dshExternal,
  banner: {
    js: "window.__ModuleLoader__.load({ id: 'dsh-aemeath-pet', factory: (require) => { var module = { exports: {} }; var exports = module.exports;",
  },
  footer: {
    js: 'return module.exports; } });',
  },
  logLevel: 'info',
})
