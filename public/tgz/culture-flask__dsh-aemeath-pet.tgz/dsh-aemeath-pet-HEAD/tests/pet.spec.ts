// @vitest-environment jsdom
/**
 * Browser-engine tests for the pet: mount, loop-driven stunt scheduling,
 * the walking state machine, and interaction guards — with a manually
 * controlled rAF loop and deterministic nextStuntAt.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { AemeathPet, type Translate } from '../src/client/pet.ts'

const t: Translate = (key) => key

/** Minimal fake 2d context (drawImage/clearRect only). */
function fakeCtx(): CanvasRenderingContext2D {
  return {
    clearRect: vi.fn(),
    drawImage: vi.fn(),
    imageSmoothingEnabled: false,
  } as unknown as CanvasRenderingContext2D
}

let rafCb: FrameRequestCallback | null = null
let clock = 0

beforeEach(() => {
  rafCb = null
  clock = performance.now()
  window.requestAnimationFrame = ((cb: FrameRequestCallback) => {
    rafCb = cb
    return 1
  }) as unknown as typeof window.requestAnimationFrame
  window.cancelAnimationFrame = (() => {
    rafCb = null
  }) as unknown as typeof window.cancelAnimationFrame
  HTMLCanvasElement.prototype.getContext = vi.fn(() => fakeCtx()) as never
  class FakeImage {
    onload: (() => void) | null = null
    onerror: (() => void) | null = null
    src = ''
  }
  ;(globalThis as { Image: new () => { onload: (() => void) | null; onerror: (() => void) | null; src: string } }).Image = FakeImage
  localStorage.clear()
})

afterEach(() => {
  rafCb = null
  document.body.innerHTML = ''
  vi.restoreAllMocks()
})

/** Run one animation frame at +ms. */
function tick(ms: number): void {
  clock += ms
  const cb = rafCb
  rafCb = null
  cb?.(clock)
}

/** Cast helper for private members under test. */
function priv(pet: AemeathPet): Record<string, any> {
  return pet as unknown as Record<string, any>
}

describe('AemeathPet idle activity', () => {
  it('docks at the bottom-right corner by default', () => {
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    try {
      const root = document.querySelector('.ap-pet-root') as HTMLElement
      expect(root.style.right).toBe('16px')
      expect(root.style.bottom).toBe('16px')
      expect(root.style.left).toBe('')
      expect(root.style.top).toBe('')
    } finally {
      dispose()
    }
  })

  it('falls back to the dock corner for legacy free-position data without coordinates', () => {
    localStorage.setItem('dsh-aemeath-pet.prefs', JSON.stringify({ enabled: true, scale: 1, docked: false }))
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    try {
      const p = priv(pet)
      expect(p.prefs.docked).toBe(true)
      const root = document.querySelector('.ap-pet-root') as HTMLElement
      expect(root.style.right).toBe('16px')
      expect(root.style.bottom).toBe('16px')
    } finally {
      dispose()
    }
  })

  it('restores a persisted free position instead of the origin', () => {
    localStorage.setItem('dsh-aemeath-pet.prefs', JSON.stringify({ enabled: true, scale: 1, docked: false, x: 300, y: 200 }))
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    try {
      const p = priv(pet)
      expect(p.px).toBe(300)
      expect(p.py).toBe(200)
      const root = document.querySelector('.ap-pet-root') as HTMLElement
      expect(root.style.left).toBe('300px')
      expect(root.style.top).toBe('200px')
    } finally {
      dispose()
    }
  })

  it('mounts the overlay into the document', () => {
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    expect(document.querySelector('.ap-pet-root')).not.toBeNull()
    expect(document.querySelector('.ap-pet-canvas')).not.toBeNull()
    dispose()
    expect(document.querySelector('.ap-pet-root')).toBeNull()
  })

  it('starts a random stunt from the loop without any timer (dock mode)', () => {
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    try {
      const p = priv(pet)
      p.nextStuntAt = 0 // eligible immediately
      vi.spyOn(Math, 'random').mockReturnValue(0.5) // beginActing('work')
      for (let i = 0; i < 3; i++) tick(16)
      expect(p.activityMode).toBe('acting')
      expect(p.anim).toBe('work')
    } finally {
      dispose()
    }
  })

  it('stunts even while the agent is working (base is work, not idle)', () => {
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    try {
      const p = priv(pet)
      pet.setBase('work')
      p.nextStuntAt = 0
      vi.spyOn(Math, 'random').mockReturnValue(0.9) // beginActing('jumping')
      for (let i = 0; i < 3; i++) tick(16)
      expect(p.activityMode).toBe('acting')
      expect(p.anim).toBe('jumping')
      // The stunt retires back into the work base animation.
      for (let i = 0; i < 60; i++) tick(16) // ~1s > jumping duration
      expect(p.activityMode).toBe('none')
      expect(p.anim).toBe('work')
    } finally {
      dispose()
    }
  })

  it('runs diagonally (both x and y move), rests, and arms the next stunt', () => {
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    try {
      const p = priv(pet)
      p.px = 300 // mid-screen: room to the right and below
      p.py = 300
      p.nextStuntAt = 0
      vi.spyOn(Math, 'random')
        .mockReturnValueOnce(0.1) // startActivity → beginRun(1)
        .mockReturnValueOnce(0.5) // spanX = 120 + 0.5*260 = 250
        .mockReturnValueOnce(0.5) // spanY gate: 0.5 < 0.65 → vertical run
        .mockReturnValueOnce(0.5) // spanY = 30 + 0.5*140 = 100
        .mockReturnValueOnce(0.5) // dirY: 0.5 < 0.5 is false → +1 (down)
        .mockReturnValue(0.9)     // afterPause: 0.9 >= 0.3 → settle
      for (let i = 0; i < 5; i++) tick(16)
      expect(p.activityMode).toBe('walking')
      expect(p.anim).toBe('walk-right')
      expect(p.activityTargetX).toBe(550) // 300 + 250
      expect(p.activityTargetY).toBe(400) // 300 + 100
      const startX = p.px
      const startY = p.py
      for (let i = 0; i < 40; i++) tick(16) // ~0.64s, still mid-run
      expect(p.px).toBeGreaterThan(startX)
      expect(p.py).toBeGreaterThan(startY) // the diagonal vertical component
      expect(p.py).not.toBe(startY)
      // Reached the target: rests, then settles into the base.
      for (let i = 0; i < 160; i++) tick(16)
      expect(p.activityMode).toBe('none')
      expect(p.nextStuntAt).toBeGreaterThan(clock)
    } finally {
      dispose()
    }
  })

  it('flips direction when the run is blocked at the edge', () => {
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    try {
      const p = priv(pet)
      p.px = window.innerWidth - 24 - p.petW // at the right edge
      p.nextStuntAt = 0
      vi.spyOn(Math, 'random').mockReturnValue(0.1) // beginRun(1) → blocked → left
      for (let i = 0; i < 5; i++) tick(16)
      expect(p.activityMode).toBe('walking')
      expect(p.anim).toBe('walk-left')
    } finally {
      dispose()
    }
  })

  it('stunts even when free-positioned (dragged once)', () => {
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    try {
      const p = priv(pet)
      p.prefs.docked = false
      p.nextStuntAt = 0
      vi.spyOn(Math, 'random').mockReturnValue(0.9) // beginActing('jumping')
      for (let i = 0; i < 3; i++) tick(16)
      expect(p.activityMode).toBe('acting')
      expect(p.anim).toBe('jumping')
    } finally {
      dispose()
    }
  })

  it('does not stunt while dragging', () => {
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    try {
      const p = priv(pet)
      p.nextStuntAt = 0
      p.dragging = true
      for (let i = 0; i < 100; i++) tick(16)
      expect(p.activityMode).toBe('none')
    } finally {
      dispose()
    }
  })

  it('speaks the waiting bubble while idle (agent waiting for input)', () => {
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    try {
      const p = priv(pet)
      p.idleBubbleAt = 0 // eligible immediately
      for (let i = 0; i < 3; i++) tick(16)
      const bubble = document.querySelector('.ap-pet-bubble') as HTMLElement
      expect(bubble.textContent).toBe('bubble.waiting')
      expect(bubble.classList.contains('visible')).toBe(true)
      // Re-arms for the next occurrence instead of spamming every frame.
      expect(p.idleBubbleAt).toBeGreaterThan(clock)
    } finally {
      dispose()
    }
  })

  it('does not override a visible bubble with the idle waiting line', () => {
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    try {
      const p = priv(pet)
      pet.speak('hello') // a bubble is already showing
      p.idleBubbleAt = 0
      for (let i = 0; i < 3; i++) tick(16)
      const bubble = document.querySelector('.ap-pet-bubble') as HTMLElement
      expect(bubble.textContent).toBe('hello') // untouched
      expect(p.idleBubbleAt).toBeGreaterThan(clock) // deferred ~5s instead of overriding
    } finally {
      dispose()
    }
  })

  it('cuts an in-place stunt short when the base mood changes', () => {
    const pet = new AemeathPet(t)
    const dispose = pet.mount()
    try {
      const p = priv(pet)
      p.nextStuntAt = 0
      vi.spyOn(Math, 'random').mockReturnValue(0.7) // beginActing('work')
      for (let i = 0; i < 3; i++) tick(16)
      expect(p.activityMode).toBe('acting')
      pet.setBase('work')
      expect(p.activityMode).toBe('none')
      expect(p.anim).toBe('work')
    } finally {
      dispose()
    }
  })
})
