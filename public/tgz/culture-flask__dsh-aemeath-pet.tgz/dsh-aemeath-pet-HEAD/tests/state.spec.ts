import { describe, expect, it } from 'vitest'
import { baseMoodOf, burstOf, deriveState, type PetFacts } from '../src/client/state.ts'

const facts = (over: Partial<PetFacts> = {}): PetFacts => ({
  running: false,
  pendingCount: 0,
  error: null,
  turnCount: 0,
  turnEndCount: 0,
  ...over,
})

describe('baseMoodOf', () => {
  it('is idle for an idle agent', () => {
    expect(baseMoodOf(facts())).toBe('idle')
  })

  it('is work while the agent runs', () => {
    expect(baseMoodOf(facts({ running: true }))).toBe('work')
  })

  it('is waiting while the session is blocked on the user', () => {
    expect(baseMoodOf(facts({ pendingCount: 2 }))).toBe('waiting')
  })

  it('prefers work over waiting', () => {
    expect(baseMoodOf(facts({ running: true, pendingCount: 1 }))).toBe('work')
  })
})

describe('burstOf', () => {
  it('emits nothing at bootstrap', () => {
    expect(burstOf(undefined, facts())).toBe('none')
  })

  it('emits failed exactly when an error appears', () => {
    const before = facts({ error: null })
    const after = facts({ error: 'boom' })
    expect(burstOf(before, after)).toBe('failed')
  })

  it('does not re-emit failed while the error persists', () => {
    const still = facts({ error: 'boom' })
    expect(burstOf(still, still)).toBe('none')
  })

  it('emits jumping when a new turn starts', () => {
    const before = facts({ turnCount: 3 })
    expect(burstOf(before, facts({ turnCount: 4 }))).toBe('jumping')
  })

  it('ignores a shrinking turn window (pagination)', () => {
    const before = facts({ turnCount: 10 })
    expect(burstOf(before, facts({ turnCount: 5 }))).toBe('none')
  })

  it('emits jumping when a new turn starts and done when one ends', () => {
    const before = facts({ turnCount: 3, turnEndCount: 2 })
    expect(burstOf(before, facts({ turnCount: 4, turnEndCount: 2 }))).toBe('jumping')
    expect(burstOf(before, facts({ turnCount: 3, turnEndCount: 3 }))).toBe('done')
  })

  it('does not re-emit done while the turn count is stable', () => {
    const stable = facts({ turnEndCount: 2 })
    expect(burstOf(stable, stable)).toBe('none')
  })

  it('prefers failed over jumping/done on the same transition', () => {
    const before = facts({ error: null, turnCount: 3, turnEndCount: 2 })
    const after = facts({ error: 'boom', turnCount: 4, turnEndCount: 3 })
    expect(burstOf(before, after)).toBe('failed')
  })
})

describe('deriveState', () => {
  it('combines base and burst', () => {
    const before = facts({ running: true, turnCount: 1 })
    const after = facts({ running: true, turnCount: 2 })
    expect(deriveState(before, after)).toEqual({ base: 'work', burst: 'jumping' })
  })

  it('stays quiet on a stable idle snapshot', () => {
    expect(deriveState(facts(), facts())).toEqual({ base: 'idle', burst: 'none' })
  })
})
