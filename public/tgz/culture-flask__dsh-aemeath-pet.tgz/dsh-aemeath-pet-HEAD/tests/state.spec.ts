import { describe, expect, it } from 'vitest'
import { IDLE_FACTS, baseMoodOf, burstOf, deriveState, type PetFacts } from '../src/client/state.ts'

const facts = (over: Partial<PetFacts> = {}): PetFacts => ({ ...IDLE_FACTS, ...over })

describe('baseMoodOf', () => {
  it('is idle for an idle agent', () => {
    expect(baseMoodOf(facts())).toBe('idle')
  })

  it('is work while the agent runs', () => {
    expect(baseMoodOf(facts({ running: true }))).toBe('work')
  })

  it('is waiting while the session is blocked on the user', () => {
    expect(baseMoodOf(facts({ pendingCount: 2 }))).toBe('waiting')
  })

  it('prefers work over waiting', () => {
    expect(baseMoodOf(facts({ running: true, pendingCount: 1 }))).toBe('work')
  })
})

describe('burstOf', () => {
  it('emits nothing at bootstrap', () => {
    expect(burstOf(undefined, facts())).toBe('none')
    expect(burstOf(undefined, facts({ running: true }))).toBe('none')
  })

  it('emits jumping when the agent starts working', () => {
    expect(burstOf(facts(), facts({ running: true }))).toBe('jumping')
  })

  it('emits done when the turn finishes', () => {
    expect(burstOf(facts({ running: true }), facts())).toBe('done')
  })

  it('emits failed once when a new error text appears', () => {
    expect(burstOf(facts(), facts({ error: 'boom' }))).toBe('failed')
    expect(burstOf(facts({ error: 'boom' }), facts({ error: 'boom' }))).toBe('none')
    expect(burstOf(facts({ error: 'boom' }), facts({ error: 'bang' }))).toBe('failed')
  })

  it('prefers failed over the running flip on the same transition', () => {
    expect(burstOf(facts({ running: true }), facts({ running: false, error: 'boom' }))).toBe('failed')
  })

  it('stays quiet on a stable snapshot', () => {
    expect(burstOf(facts(), facts())).toBe('none')
    expect(burstOf(facts({ running: true }), facts({ running: true }))).toBe('none')
  })
})

describe('deriveState', () => {
  it('combines base and burst', () => {
    expect(deriveState(facts(), facts({ running: true }))).toEqual({ base: 'work', burst: 'jumping' })
  })

  it('settles into idle after work', () => {
    expect(deriveState(facts({ running: true }), facts())).toEqual({ base: 'idle', burst: 'done' })
  })
})
