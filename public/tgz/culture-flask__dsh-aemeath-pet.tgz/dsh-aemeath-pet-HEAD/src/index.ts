/**
 * dsh-aemeath-pet host plugin: serves the pet spritesheet for the browser
 * half. The client ships in the same package (`./client`); the web server
 * serves it under /plugins/dsh-aemeath-pet/client.js. Everything else —
 * rendering, agent-state reactions, preferences — lives in the browser half.
 */
import { createHash } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
// Type-only: brings the `ctx.webServer` Context merge into this program.
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'

/** Cordis plugin name (the Loader entry and client bundle id). */
export const name = 'dsh-aemeath-pet'

/** Services required before load: the web server that serves the asset route. */
export const inject = ['webServer']

/** Exact route that serves the spritesheet to the browser half. */
export const SPRITESHEET_ROUTE = '/aemeath-pet/spritesheet.webp'

/** The packaged spritesheet, resolved relative to this module. */
const SPRITESHEET_FILE = new URL('../assets/spritesheet-2x.webp', import.meta.url)

/** Short etag from a buffer (asset cache revalidation). */
function etagOf(body: Buffer): string {
  const digest = createHash('sha1').update(body).digest('hex').slice(0, 12)
  return `"${body.length.toString(16)}-${digest}"`
}

/** One handler: GET/HEAD serve the spritesheet; anything else is a 405. */
async function serveSpritesheet(req: IncomingMessage, res: ServerResponse): Promise<void> {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405)
    res.end()
    return
  }
  let body: Buffer
  try {
    body = await readFile(SPRITESHEET_FILE)
  } catch {
    res.writeHead(404)
    res.end('not found')
    return
  }
  const etag = etagOf(body)
  if (req.headers['if-none-match'] === etag) {
    res.writeHead(304, { 'cache-control': 'no-cache', etag })
    res.end()
    return
  }
  res.writeHead(200, {
    'content-type': 'image/webp',
    'cache-control': 'no-cache',
    etag,
  })
  res.end(req.method === 'HEAD' ? undefined : body)
}

/**
 * Mount the spritesheet route.
 * @param ctx - host cordis context carrying webServer.
 */
export function apply(ctx: Context): void {
  const webServer = ctx.get('webServer') as { register(route: WebRoute): () => void }
  ctx.effect(() => webServer.register({
    kind: 'exact',
    path: SPRITESHEET_ROUTE,
    handler: serveSpritesheet,
  }), 'dsh-aemeath-pet: spritesheet route')
}
