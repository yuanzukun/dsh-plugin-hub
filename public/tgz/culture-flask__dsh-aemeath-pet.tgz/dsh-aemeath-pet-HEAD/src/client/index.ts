/**
 * dsh-aemeath-pet client plugin: the browser half. Mounts the Aemeath pet
 * overlay, follows the sessions store, derives the pet mood (idle / work) and
 * one-shot bursts (jumping when work starts, done when it finishes, failed on
 * a new agent error), and speaks locale-aware bubbles. The Host half only
 * serves the spritesheet.
 *
 * The sessions service is described structurally on purpose: the harness
 * client packages are renamed and reshaped between releases (turn counters and
 * pending-interaction lists already came and went), so the pet depends only on
 * the parts that have stayed stable — `list` summaries with a running flag,
 * and `binding(id)` exposing a session snapshot with `running` and
 * `lastAgentError`.
 */
// Type-only: the ctx.locale Context merge (register/bind).
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type { Context } from '@deepseek-ai/cordis'
import { NS, en, zh } from './locales.ts'
import { AemeathPet, type Translate } from './pet.ts'
import { IDLE_FACTS, deriveState, type BaseMood, type PetFacts } from './state.ts'
import { adoptStyles } from './styles.ts'

/** Required services: the session store (agent state) and the locale service. */
export const inject = ['sessions', 'locale']

/** Minimal snapshot-store face (`getSnapshot` + `subscribe`) every harness version exposes. */
interface ObservableLike<T> {
  getSnapshot(): T
  subscribe(listener: () => void): () => void
}

/** The session-summary fields the pet reads. */
interface SessionSummaryLike {
  id?: string
  running?: boolean
}

/** The list-store fields the pet reads. */
interface SessionListStateLike {
  ids?: readonly string[]
  byId?: Readonly<Record<string, SessionSummaryLike>>
}

/** The session-snapshot fields the pet reads. */
interface SessionSnapshotLike {
  running?: boolean
  lastAgentError?: string | null
}

/** The binding face: an observable session snapshot. */
interface SessionBindingLike {
  session: ObservableLike<SessionSnapshotLike>
}

/** The sessions-service face the pet needs. */
interface SessionsLike {
  list: ObservableLike<SessionListStateLike>
  binding(id: string): SessionBindingLike | undefined
}

/**
 * Compose the pet surface.
 * @param ctx - client root context.
 */
export function apply(ctx: Context): void {
  adoptStyles()
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-aemeath-pet: dictionaries')
  const t = ctx.locale.bind(NS) as unknown as Translate
  const sessions = ctx.get('sessions') as unknown as SessionsLike
  const pet = new AemeathPet(t)

  ctx.effect(() => pet.mount(), 'dsh-aemeath-pet: overlay')

  let lastFacts: PetFacts | undefined
  let lastBase: BaseMood | undefined
  /** Session whose events the pet currently follows (the last one seen running). */
  let watchedId: string | undefined
  let unwatch: () => void = () => {}

  /** Pick the session to follow: a running one if any, else the last running one. */
  const runningIdOf = (list: SessionListStateLike): string | undefined => {
    const ids = list.ids ?? []
    for (const id of ids) {
      if (list.byId?.[id]?.running === true) return id as string
    }
    return undefined
  }

  /** Read the current facts from the list summaries plus the watched session snapshot. */
  const readFacts = (): PetFacts => {
    const list = sessions.list.getSnapshot()
    const runningId = runningIdOf(list)
    if (runningId !== undefined) watchedId = runningId
    const snapshot = watchedId === undefined
      ? undefined
      : sessions.binding(watchedId)?.session.getSnapshot()
    return {
      running: runningId !== undefined,
      pendingCount: 0,
      error: snapshot?.lastAgentError ?? null,
    }
  }

  /** Follow the watched session's snapshot so raises/errors land without polling. */
  const rewatch = (): void => {
    if (watchedId === undefined) return
    const binding = sessions.binding(watchedId)
    if (binding === undefined) return
    unwatch()
    unwatch = binding.session.subscribe(() => sync())
  }

  /** Re-derive the pet state from the live snapshots. */
  const sync = (): void => {
    const facts = readFacts()
    if (watchedId !== undefined) rewatch()
    const state = deriveState(lastFacts, facts)
    lastFacts = facts
    if (state.burst === 'failed') pet.playBurst('failed', t('bubble.error'))
    else if (state.burst === 'jumping') pet.playBurst('jumping', t('bubble.onTask'))
    else if (state.burst === 'done') pet.playBurst('jumping', t('bubble.done'))
    if (state.base !== lastBase) {
      lastBase = state.base
      pet.setBase(state.base)
      console.debug('[dsh-aemeath-pet] base:', state.base, 'facts:', facts)
      if (state.base === 'work') pet.speak(t('bubble.work'))
      else if (state.base === 'waiting') pet.speak(t('bubble.waiting'))
    }
  }

  ctx.effect(() => {
    const offList = sessions.list.subscribe(sync)
    sync()
    return () => {
      offList()
      unwatch()
    }
  }, 'dsh-aemeath-pet: session wiring')
}
