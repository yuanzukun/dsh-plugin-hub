/**
 * dsh-aemeath-pet client plugin: the browser half. Mounts the Aemeath pet
 * overlay, subscribes to the current session's snapshot, derives the pet
 * mood (idle / work / waiting) and one-shot bursts (failed, jumping), and
 * speaks locale-aware bubbles. The Host half only serves the spritesheet.
 */
// Type-only: the ctx.locale Context merge (register/bind).
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type { ClientContext, ConversationSnapshot, ISessions } from '@deepseek-ai/dsh-client-runtime/client'
import { NS, en, zh } from './locales.ts'
import { AemeathPet } from './pet.ts'
import { deriveState, type PetFacts } from './state.ts'
import { adoptStyles } from './styles.ts'

/** Required services: the session store (agent state) and the locale service. */
export const inject = ['sessions', 'locale']

/** Default facts when no session is open. */
const NO_SESSION: PetFacts = { running: false, pendingCount: 0, error: null, turnCount: 0, turnEndCount: 0 }

/**
 * Compose the pet surface.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  adoptStyles()
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-aemeath-pet: dictionaries')
  const t = ctx.locale.bind(NS)
  const sessions = ctx.get('sessions') as unknown as ISessions
  const pet = new AemeathPet(t)

  ctx.effect(() => pet.mount(), 'dsh-aemeath-pet: overlay')

  let lastFacts: PetFacts | undefined
  let lastBase: string | undefined
  let boundId: string | undefined
  let unsubBinding: () => void = () => {}

  /** Read the facts for the current session (binding snapshot, then list summary). */
  const readFacts = (): PetFacts => {
    const list = sessions.list.getSnapshot()
    const current = list.current
    if (current === undefined) return NO_SESSION
    const binding = sessions.binding(current)
    if (binding !== undefined) {
      const snap: ConversationSnapshot = binding.session.getSnapshot()
      return {
        running: snap.running,
        pendingCount: snap.pending.length,
        error: snap.lastAgentError,
        turnCount: snap.turnTimings.size,
        turnEndCount: snap.turnEnds.size,
      }
    }
    const summary = list.byId[current]
    if (summary !== undefined) {
      return {
        running: summary.running,
        pendingCount: summary.pendingInteraction === undefined ? 0 : 1,
        error: null,
        turnCount: 0,
        turnEndCount: 0,
      }
    }
    return NO_SESSION
  }

  /** Re-derive the pet state from the live snapshots. */
  const sync = (): void => {
    const current = sessions.list.getSnapshot().current
    if (current !== boundId) {
      unsubBinding()
      unsubBinding = () => {}
      boundId = current
      if (current !== undefined) {
        const binding = sessions.binding(current)
        if (binding !== undefined) unsubBinding = binding.session.subscribe(sync)
      }
    }
    const facts = readFacts()
    const state = deriveState(lastFacts, facts)
    lastFacts = facts
    if (state.burst === 'failed') pet.playBurst('failed', t('bubble.error'))
    else if (state.burst === 'jumping') pet.playBurst('jumping', t('bubble.onTask'))
    else if (state.burst === 'done') pet.playBurst('jumping', t('bubble.done'))
    if (state.base !== lastBase) {
      lastBase = state.base
      pet.setBase(state.base)
      console.debug('[dsh-aemeath-pet] base:', state.base, 'facts:', facts)
      if (state.base === 'work') pet.speak(t('bubble.work'))
      else if (state.base === 'waiting') pet.speak(t('bubble.waiting'))
    }
  }

  ctx.effect(() => {
    const offList = sessions.list.subscribe(sync)
    sync()
    return () => {
      offList()
      unsubBinding()
    }
  }, 'dsh-aemeath-pet: session wiring')
}
