/**
 * Injected styles for the pet overlay. The root is pointer-transparent so the
 * pet never blocks the app; only the pet canvas, bubble, and menu re-enable
 * pointer events. All selectors are prefixed with `ap-`.
 */

/** CSS text injected into the page (one `<style data-plugin>` tag). */
export const STYLES = `
.ap-pet-root {
  position: fixed;
  z-index: 2147483000;
  pointer-events: none;
  user-select: none;
  -webkit-user-select: none;
}
.ap-pet-canvas {
  display: block;
  pointer-events: auto;
  cursor: grab;
  touch-action: none;
  image-rendering: pixelated;
}
.ap-pet-canvas.dragging {
  cursor: grabbing;
}
.ap-pet-bubble {
  position: absolute;
  bottom: calc(100% + 8px);
  left: 50%;
  transform: translateX(-50%);
  max-width: 220px;
  padding: 6px 10px;
  border-radius: 10px;
  background: rgba(20, 22, 32, 0.88);
  color: #f2f3f7;
  font-size: 12px;
  line-height: 1.45;
  white-space: pre-line;
  text-align: center;
  pointer-events: none;
  opacity: 0;
  transition: opacity 180ms ease;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.25);
}
.ap-pet-bubble.visible {
  opacity: 1;
}
.ap-pet-bubble::after {
  content: '';
  position: absolute;
  top: 100%;
  left: 50%;
  transform: translateX(-50%);
  border: 6px solid transparent;
  border-top-color: rgba(20, 22, 32, 0.88);
}
.ap-pet-menu {
  position: fixed;
  z-index: 2147483001;
  min-width: 150px;
  padding: 6px;
  border-radius: 10px;
  background: rgba(24, 26, 38, 0.96);
  color: #f2f3f7;
  font-size: 13px;
  pointer-events: auto;
  box-shadow: 0 4px 18px rgba(0, 0, 0, 0.35);
  display: none;
}
.ap-pet-menu.open {
  display: block;
}
.ap-pet-menu-row {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 5px 8px;
  border-radius: 6px;
  cursor: pointer;
  white-space: nowrap;
}
.ap-pet-menu-row:hover {
  background: rgba(255, 255, 255, 0.1);
}
.ap-pet-menu-row.sep {
  margin-top: 4px;
  padding-top: 8px;
  border-top: 1px solid rgba(255, 255, 255, 0.12);
}
.ap-pet-menu-label {
  flex: 1;
}
.ap-pet-menu-btn {
  border: none;
  border-radius: 5px;
  padding: 2px 8px;
  background: rgba(255, 255, 255, 0.14);
  color: inherit;
  font-size: 12px;
  cursor: pointer;
}
.ap-pet-menu-btn:hover {
  background: rgba(255, 255, 255, 0.26);
}
.ap-pet-menu-btn.active {
  background: #4d6bfe;
}
.ap-pet-paw {
  position: fixed;
  z-index: 2147483000;
  width: 34px;
  height: 34px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(20, 22, 32, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.25);
  color: #fff;
  font-size: 16px;
  cursor: pointer;
  pointer-events: auto;
  opacity: 0.65;
}
.ap-pet-paw:hover {
  opacity: 1;
}
`

/** Adopt the styles into the page (idempotent per page load). */
export function adoptStyles(): void {
  const id = 'dsh-aemeath-pet-styles'
  if (document.getElementById(id) !== null) return
  const style = document.createElement('style')
  style.id = id
  style.textContent = STYLES
  document.head.append(style)
}
