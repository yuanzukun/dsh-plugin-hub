/**
 * AemeathPet — the browser pet engine. Mounts the floating overlay, plays
 * spritesheet animations on a canvas, performs random stunts (run / jump /
 * work) whenever docked, reacts to agent facts, speaks transient bubbles, and
 * supports drag positioning plus a right-click menu. Preferences persist to
 * localStorage.
 */

import { ANIMATIONS, CELL_H, CELL_W, SHEET_URL, animationForBase, type PetAnimation } from './atlas.ts'
import type { PetKey } from './locales.ts'
import type { BaseMood } from './state.ts'

/** Translate function shape (what ctx.locale.bind returns, narrowed to this plugin's keys). */
export type Translate = (key: PetKey) => string

/** Docked margin from the viewport edge. */
const DOCK_MARGIN = 16
/** Walking speed in logical px/s (scaled). */
const WALK_SPEED = 110
/** One-shot burst names. */
type Burst = 'failed' | 'jumping' | 'waving'
/** Available scales (menu buttons). */
const SCALES = [0.75, 1, 1.25]

/** Persisted preferences. */
interface Prefs {
  enabled: boolean
  scale: number
  docked: boolean
  x: number | undefined
  y: number | undefined
}

const PREFS_KEY = 'dsh-aemeath-pet.prefs'
const DEFAULT_PREFS: Prefs = { enabled: true, scale: 1, docked: true, x: undefined, y: undefined }

function loadPrefs(): Prefs {
  try {
    const parsed = JSON.parse(localStorage.getItem(PREFS_KEY) ?? '{}') as Partial<Prefs>
    const prefs: Prefs = {
      ...DEFAULT_PREFS,
      ...parsed,
      scale: SCALES.includes(parsed.scale ?? 1) ? parsed.scale ?? 1 : 1,
    }
    // A free position without coordinates (legacy drag data before x/y were
    // persisted) is invalid — fall back to the dock corner instead of (0,0).
    if (!prefs.docked && (prefs.x === undefined || prefs.y === undefined)) prefs.docked = true
    return prefs
  } catch {
    return { ...DEFAULT_PREFS }
  }
}

function savePrefs(prefs: Prefs): void {
  try {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs))
  } catch {
    /* storage unavailable — prefs stay session-local */
  }
}

/**
 * The pet overlay: DOM + canvas + animation loop + idle stunts + drag + menu.
 * Constructed once per plugin activation; mount() attaches and returns the
 * disposer the fiber effect calls on unload.
 */
export class AemeathPet {
  private readonly root: HTMLDivElement
  private readonly canvas: HTMLCanvasElement
  private readonly paint: CanvasRenderingContext2D
  private readonly bubble: HTMLDivElement
  private readonly menu: HTMLDivElement
  private readonly paw: HTMLButtonElement

  private prefs: Prefs = loadPrefs()
  private img: HTMLImageElement | null = null
  private imageFailed = false
  private base: BaseMood = 'idle'
  private anim: PetAnimation = 'idle'
  private transient: boolean = false
  private animStart: number = 0
  private lastNow: number = 0
  private raf: number = 0
  private disposed = false

  /** Current top-left position (logical px). */
  private px: number = 0
  private py: number = 0

  /** Activity state: walking (running along the bottom edge), pausing (short rest), acting (in-place stunt). */
  private activityMode: 'none' | 'walking' | 'pausing' | 'acting' = 'none'
  private activityDir: 1 | -1 = 1
  private activityTargetX: number = 0
  private activityTargetY: number = 0
  private activityUntil: number = 0
  /** Earliest performance.now() at which the next random stunt may start. */
  private nextStuntAt: number = 0
  /** Earliest performance.now() at which the next idle "waiting for you" bubble may appear. */
  private idleBubbleAt: number = 0

  private dragging: boolean = false
  private dragMoved: boolean = false
  private dragLastX: number = 0
  private dragLastY: number = 0

  private bubbleTimer: ReturnType<typeof setTimeout> | undefined
  private readonly onResize = (): void => this.handleResize()
  private readonly onDocPointerDown = (event: PointerEvent): void => {
    if (!this.menu.classList.contains('open')) return
    if (this.menu.contains(event.target as Node) || this.canvas.contains(event.target as Node)) return
    this.closeMenu()
  }

  /**
   * @param t - locale translate bound to the plugin namespace.
   */
  constructor(private readonly t: Translate) {
    this.root = document.createElement('div')
    this.root.className = 'ap-pet-root'
    this.canvas = document.createElement('canvas')
    this.canvas.className = 'ap-pet-canvas'
    this.canvas.setAttribute('role', 'img')
    this.canvas.setAttribute('aria-label', t('aria.pet'))
    const paint = this.canvas.getContext('2d')
    if (paint === null) throw new Error('dsh-aemeath-pet: 2d canvas context unavailable')
    this.paint = paint
    this.bubble = document.createElement('div')
    this.bubble.className = 'ap-pet-bubble'
    this.menu = document.createElement('div')
    this.menu.className = 'ap-pet-menu'
    this.menu.setAttribute('role', 'menu')
    this.menu.setAttribute('aria-label', t('aria.menu'))
    this.paw = document.createElement('button')
    this.paw.className = 'ap-pet-paw'
    this.paw.textContent = '🐾'
    this.paw.setAttribute('aria-label', t('aria.pet'))
    this.root.append(this.canvas, this.bubble)
    // Seed the current position from persisted free coordinates (dock mode
    // re-anchors through syncDockPos on the first applyPosition).
    this.px = this.prefs.x ?? 0
    this.py = this.prefs.y ?? 0
  }

  /** Current logical pet width. */
  private get petW(): number {
    return Math.round(CELL_W * this.prefs.scale)
  }

  /** Current logical pet height. */
  private get petH(): number {
    return Math.round(CELL_H * this.prefs.scale)
  }

  /** Current base mood (read by the wiring layer for transition bubbles). */
  baseMood(): BaseMood {
    return this.base
  }

  /**
   * Attach the overlay, start the loop, and return the disposer.
   * @returns function that tears the pet down (fiber dispose).
   */
  mount(): () => void {
    document.body.append(this.root, this.menu, this.paw)
    this.applySize()
    this.applyVisibility()
    this.wireEvents()
    window.addEventListener('resize', this.onResize)
    document.addEventListener('pointerdown', this.onDocPointerDown, true)
    const img = new Image()
    img.decoding = 'async'
    img.onload = () => {
      this.img = img
      this.imageFailed = false
    }
    img.onerror = () => {
      this.imageFailed = true
      this.speak(this.t('bubble.noAsset'))
    }
    img.src = SHEET_URL
    this.lastNow = performance.now()
    // First stunt lands quickly (4–8s); later ones space out (6–15s).
    this.nextStuntAt = this.lastNow + 4000 + Math.random() * 4000
    // First idle "waiting for you" bubble lands after ~15s, then every 25–45s.
    this.idleBubbleAt = this.lastNow + 15000 + Math.random() * 5000
    this.raf = requestAnimationFrame(this.loop)
    console.debug('[dsh-aemeath-pet] mounted, docked =', this.prefs.docked)
    return () => this.dispose()
  }

  /** Switch the looping base mood (idle/work/waiting). */
  setBase(mood: BaseMood): void {
    if (mood === this.base) return
    this.base = mood
    if (this.activityMode === 'walking') return // finish the current run first
    if (this.activityMode === 'acting') this.activityMode = 'none' // cut the in-place stunt short
    if (this.transient) return // let the one-shot finish, then the new base applies
    this.setAnim(animationForBase(mood))
  }

  /** Play one one-shot burst (with an optional bubble). */
  playBurst(burst: Burst, bubble?: string): void {
    if (burst !== 'failed' && this.transient) return
    this.setAnim(burst)
    if (bubble !== undefined) this.speak(bubble)
  }

  /** Show a speech bubble for a few seconds. */
  speak(text: string): void {
    this.bubble.textContent = text
    this.bubble.classList.add('visible')
    if (this.bubbleTimer !== undefined) clearTimeout(this.bubbleTimer)
    this.bubbleTimer = setTimeout(() => {
      this.bubble.classList.remove('visible')
    }, 3500)
  }

  /** Switch the active animation (restarting its timeline). */
  private setAnim(anim: PetAnimation): void {
    this.anim = anim
    this.transient = !ANIMATIONS[anim].loop
    this.animStart = performance.now()
  }

  /** Apply scale to the canvas and (re)position. */
  private applySize(): void {
    const w = this.petW
    const h = this.petH
    this.canvas.width = w
    this.canvas.height = h
    this.paint.imageSmoothingEnabled = false
    this.applyPosition()
  }

  /** Apply current position mode (dock vs free) to the root style. */
  private applyPosition(): void {
    if (this.prefs.docked) {
      this.root.style.left = ''
      this.root.style.top = ''
      this.root.style.right = `${DOCK_MARGIN}px`
      this.root.style.bottom = `${DOCK_MARGIN}px`
      this.syncDockPos()
    } else {
      this.root.style.right = ''
      this.root.style.bottom = ''
      this.root.style.left = `${this.px}px`
      this.root.style.top = `${this.py}px`
    }
    this.paw.style.right = ''
    this.paw.style.bottom = ''
    this.paw.style.left = `${this.prefs.docked ? window.innerWidth - DOCK_MARGIN - 34 : this.px}px`
    this.paw.style.top = `${this.prefs.docked ? window.innerHeight - DOCK_MARGIN - 34 : this.py}px`
  }

  /** Recompute the dock anchor position. */
  private syncDockPos(): void {
    this.px = Math.max(0, window.innerWidth - DOCK_MARGIN - this.petW)
    this.py = Math.max(0, window.innerHeight - DOCK_MARGIN - this.petH)
  }

  /** Hide the pet (paw button appears) or show it. */
  private applyVisibility(): void {
    const enabled = this.prefs.enabled
    this.root.style.display = enabled ? '' : 'none'
    this.paw.style.display = enabled ? 'none' : 'flex'
    if (enabled) {
      this.applySize()
      this.nextStuntAt = 0 // eligible again as soon as the loop runs
    }
  }

  /** Wire pointer interactions on the canvas and menu. */
  private wireEvents(): void {
    this.canvas.addEventListener('pointerdown', (event) => {
      if (event.button !== 0) return
      this.dragging = true
      this.dragMoved = false
      this.dragLastX = event.clientX
      this.dragLastY = event.clientY
      this.canvas.setPointerCapture(event.pointerId)
      this.canvas.classList.add('dragging')
    })
    this.canvas.addEventListener('pointermove', (event) => {
      if (!this.dragging) return
      const dx = event.clientX - this.dragLastX
      const dy = event.clientY - this.dragLastY
      if (!this.dragMoved && Math.hypot(dx, dy) < 5) return
      this.dragMoved = true
      this.dragLastX = event.clientX
      this.dragLastY = event.clientY
      if (this.prefs.docked) {
        this.prefs.docked = false
        this.syncDockPos()
      }
      this.px = Math.max(0, Math.min(window.innerWidth - this.petW, this.px + dx))
      this.py = Math.max(0, Math.min(window.innerHeight - this.petH, this.py + dy))
      this.applyPosition()
    })
    const finishDrag = (event: PointerEvent): void => {
      if (!this.dragging) return
      this.dragging = false
      this.canvas.classList.remove('dragging')
      if (event.pointerId !== undefined) {
        try { this.canvas.releasePointerCapture(event.pointerId) } catch { /* already released */ }
      }
      if (!this.dragMoved) {
        // A click: wave back and greet.
        this.playBurst('waving', Math.random() < 0.5 ? this.t('bubble.hi') : this.t('bubble.greeting'))
      } else {
        this.prefs.x = this.px
        this.prefs.y = this.py
        savePrefs(this.prefs)
        this.nextStuntAt = performance.now() + 4000 + Math.random() * 4000
      }
    }
    this.canvas.addEventListener('pointerup', finishDrag)
    this.canvas.addEventListener('pointercancel', finishDrag)
    this.canvas.addEventListener('contextmenu', (event) => {
      event.preventDefault()
      this.openMenu(event.clientX, event.clientY)
    })
    this.paw.addEventListener('click', (event) => {
      this.openMenu(event.clientX, event.clientY)
    })
    this.paw.addEventListener('contextmenu', (event) => {
      event.preventDefault()
      this.openMenu(event.clientX, event.clientY)
    })
  }

  /** Whether a new random stunt may start right now. */
  private canStunt(now: number): boolean {
    return !this.dragging
      && !document.hidden
      && this.activityMode === 'none'
      && now >= this.nextStuntAt
  }

  /** Pick one random stunt: run right, run left, work in place, or jump. */
  private startActivity(now: number): void {
    const pick = Math.random()
    if (pick < 0.25) this.beginRun(1)
    else if (pick < 0.5) this.beginRun(-1)
    else if (pick < 0.75) this.beginActing('work')
    else this.beginActing('jumping')
    console.debug('[dsh-aemeath-pet] stunt:', this.anim, 'at', Math.round(now / 1000), 's')
  }

  /** Begin running diagonally across the viewport in one horizontal direction. */
  private beginRun(dir: 1 | -1): void {
    const lowX = 24
    const lowY = 24
    const highX = Math.max(lowX + 40, window.innerWidth - this.petW - 24)
    const highY = Math.max(lowY + 40, window.innerHeight - this.petH - 24)
    if (highX <= lowX || highY <= lowY) {
      this.retireStunt()
      return
    }
    const spanX = 120 + Math.random() * 260
    // Mostly diagonal: a vertical component on 65% of runs.
    const spanY = Math.random() < 0.65 ? 30 + Math.random() * 140 : 0
    const dirY = Math.random() < 0.5 ? -1 : 1
    const targetX = dir === 1 ? Math.min(highX, this.px + spanX) : Math.max(lowX, this.px - spanX)
    const targetY = Math.max(lowY, Math.min(highY, this.py + dirY * spanY))
    const blocked = dir === 1 ? targetX <= this.px + 10 : targetX >= this.px - 10
    if (blocked) {
      // No room in the chosen direction: try the other way, then give up.
      if (dir === 1 && this.px > lowX + 10) this.beginRun(-1)
      else if (dir === -1 && this.px < highX - 10) this.beginRun(1)
      else this.retireStunt()
      return
    }
    this.activityMode = 'walking'
    this.activityDir = dir
    this.activityTargetX = targetX
    this.activityTargetY = targetY
    this.setAnim(dir === 1 ? 'walk-right' : 'walk-left')
  }

  /** Begin an in-place stunt: the work animation for a while, or one jump. */
  private beginActing(kind: 'work' | 'jumping'): void {
    this.activityMode = 'acting'
    const spec = ANIMATIONS[kind]
    this.activityUntil = performance.now()
      + (kind === 'work' ? 1500 + Math.random() * 1500 : (spec.frames / spec.fps) * 1000)
    this.setAnim(kind)
  }

  /** After a pause, either chain another stunt or settle back. */
  private afterPause(): void {
    if (Math.random() < 0.3) {
      this.startActivity(performance.now())
    } else {
      this.retireStunt()
    }
  }

  /** Settle back into the base animation and arm the next stunt. */
  private retireStunt(): void {
    this.activityMode = 'none'
    this.setAnim(animationForBase(this.base))
    this.nextStuntAt = performance.now() + 6000 + Math.random() * 9000
  }

  /** An in-place stunt finished: settle back and arm the next one. */
  private finishActing(): void {
    this.retireStunt()
  }

  /** Advance a run by one frame (diagonal toward the target point). */
  private stepWalk(dt: number): void {
    const step = WALK_SPEED * this.prefs.scale * dt
    const dx = this.activityTargetX - this.px
    const dy = this.activityTargetY - this.py
    const dist = Math.hypot(dx, dy)
    if (dist <= step) {
      this.px = this.activityTargetX
      this.py = this.activityTargetY
      this.arriveAtTarget()
    } else {
      this.px += (dx / dist) * step
      this.py += (dy / dist) * step
    }
    this.root.style.right = ''
    this.root.style.bottom = ''
    this.root.style.left = `${this.px}px`
    this.root.style.top = `${this.py}px`
  }

  /** The run reached its target: rest briefly, then decide. */
  private arriveAtTarget(): void {
    this.activityMode = 'pausing'
    this.activityUntil = performance.now() + 800 + Math.random() * 600
    this.setAnim(animationForBase(this.base))
  }

  /** Viewport resize: keep the dock anchor or clamp free/walk positions. */
  private handleResize(): void {
    if (this.prefs.docked) {
      this.applyPosition()
    } else {
      this.px = Math.max(0, Math.min(window.innerWidth - this.petW, this.px))
      this.py = Math.max(0, Math.min(window.innerHeight - this.petH, this.py))
      this.applyPosition()
    }
    if (this.activityMode === 'walking') {
      const lowX = 24
      const lowY = 24
      const highX = Math.max(lowX + 40, window.innerWidth - this.petW - 24)
      const highY = Math.max(lowY + 40, window.innerHeight - this.petH - 24)
      this.activityTargetX = Math.max(lowX, Math.min(highX, this.activityTargetX))
      this.activityTargetY = Math.max(lowY, Math.min(highY, this.activityTargetY))
    }
  }

  /** Draw the current animation frame. */
  private draw(now: number): void {
    const img = this.img
    this.paint.clearRect(0, 0, this.petW, this.petH)
    if (img === null || this.imageFailed) return
    const spec = ANIMATIONS[this.anim]
    const elapsed = (now - this.animStart) / 1000
    const frame = spec.loop
      ? Math.floor(elapsed * spec.fps) % spec.frames
      : Math.min(Math.floor(elapsed * spec.fps), spec.frames - 1)
    this.paint.imageSmoothingEnabled = false
    this.paint.drawImage(img, frame * CELL_W, spec.row * CELL_H, CELL_W, CELL_H, 0, 0, this.petW, this.petH)
  }

  /** The animation frame loop. */
  private readonly loop = (now: number): void => {
    if (this.disposed) return
    this.raf = requestAnimationFrame(this.loop)
    const dt = Math.min((now - this.lastNow) / 1000, 0.05)
    this.lastNow = now
    if (this.activityMode === 'walking') this.stepWalk(dt)
    else if (this.activityMode === 'pausing' && now >= this.activityUntil) this.afterPause()
    else if (this.activityMode === 'acting' && now >= this.activityUntil) this.finishActing()
    else if (this.canStunt(now)) this.startActivity(now)
    // The agent is idle — waiting for the user's next input: occasionally say so.
    if (this.base === 'idle' && !this.dragging && now >= this.idleBubbleAt) {
      if (this.bubble.classList.contains('visible')) {
        // Another bubble is showing: defer, don't stack on it.
        this.idleBubbleAt = now + 5000
      } else {
        this.speak(this.t('bubble.waiting'))
        this.idleBubbleAt = now + 25000 + Math.random() * 20000
      }
    }
    if (this.transient && !ANIMATIONS[this.anim].loop && now - this.animStart >= (ANIMATIONS[this.anim].frames / ANIMATIONS[this.anim].fps) * 1000) {
      // One-shot finished: resume the base (or the run) animation.
      this.setAnim(this.activityMode === 'walking' ? (this.activityDir === 1 ? 'walk-right' : 'walk-left') : animationForBase(this.base))
    }
    this.draw(now)
  }

  /** Open the right-click menu at a viewport point. */
  private openMenu(x: number, y: number): void {
    this.menu.textContent = ''
    const dockLabel = this.t(this.prefs.docked ? 'menu.free' : 'menu.dock')
    this.menu.append(this.menuRow(dockLabel, () => {
      this.prefs.docked = !this.prefs.docked
      savePrefs(this.prefs)
      this.closeMenu()
      this.applyPosition()
      if (this.prefs.docked) this.nextStuntAt = 0
    }))
    // size row: label + three buttons
    const sizeLabel = document.createElement('span')
    sizeLabel.className = 'ap-pet-menu-label'
    sizeLabel.textContent = this.t('menu.size')
    const sizeWrap = document.createElement('div')
    sizeWrap.className = 'ap-pet-menu-row'
    sizeWrap.append(sizeLabel)
    for (const s of SCALES) {
      const btn = document.createElement('button')
      btn.className = 'ap-pet-menu-btn'
      btn.textContent = s === 0.75 ? this.t('menu.size.small') : s === 1 ? this.t('menu.size.medium') : this.t('menu.size.large')
      if (s === this.prefs.scale) btn.classList.add('active')
      btn.addEventListener('click', (event) => {
        event.stopPropagation()
        this.prefs.scale = s
        savePrefs(this.prefs)
        this.closeMenu()
        this.applySize()
      })
      sizeWrap.append(btn)
    }
    this.menu.append(sizeWrap)
    const hideRow = this.menuRow(this.t(this.prefs.enabled ? 'menu.hide' : 'menu.show'), () => {
      this.prefs.enabled = !this.prefs.enabled
      savePrefs(this.prefs)
      this.closeMenu()
      this.applyVisibility()
    })
    hideRow.classList.add('sep')
    this.menu.append(hideRow)
    this.menu.append(this.menuRow(this.t('menu.reset'), () => {
      this.prefs.docked = true
      this.prefs.x = undefined
      this.prefs.y = undefined
      savePrefs(this.prefs)
      this.closeMenu()
      this.applyPosition()
      this.nextStuntAt = 0
    }))
    this.menu.append(this.menuRow(this.t('menu.about'), () => {
      this.closeMenu()
      this.speak(this.t('about.text'))
    }))
    const menuW = 190
    const menuH = 190
    this.menu.style.left = `${Math.max(4, Math.min(window.innerWidth - menuW, x))}px`
    this.menu.style.top = `${Math.max(4, Math.min(window.innerHeight - menuH, y))}px`
    this.menu.classList.add('open')
  }

  /** One menu row. */
  private menuRow(label: string, onClick?: () => void): HTMLDivElement {
    const row = document.createElement('div')
    row.className = 'ap-pet-menu-row'
    const span = document.createElement('span')
    span.className = 'ap-pet-menu-label'
    span.textContent = label
    row.append(span)
    if (onClick !== undefined) row.addEventListener('click', onClick)
    return row
  }

  /** Close the menu. */
  private closeMenu(): void {
    this.menu.classList.remove('open')
  }

  /** Full teardown (fiber dispose / HMR). */
  private dispose(): void {
    this.disposed = true
    cancelAnimationFrame(this.raf)
    if (this.bubbleTimer !== undefined) clearTimeout(this.bubbleTimer)
    window.removeEventListener('resize', this.onResize)
    document.removeEventListener('pointerdown', this.onDocPointerDown, true)
    this.root.remove()
    this.menu.remove()
    this.paw.remove()
  }
}
