/**
 * Pure pet-state derivation: maps a session facts snapshot to the pet's base
 * mood and one-shot bursts. Kept framework-free so the behavior is unit
 * tested without a browser.
 */

/** Agent facts the pet reacts to (subset of the client ConversationSnapshot). */
export interface PetFacts {
  /** Whether the agent is running a turn. */
  running: boolean
  /** Count of pending interactions (approvals / follow-ups) blocking the session. */
  pendingCount: number
  /** Last agent error text, or null when the last step did not fail. */
  error: string | null
  /** Number of turns started in the current conversation window. */
  turnCount: number
  /** Number of completed turns in the current conversation window. */
  turnEndCount: number
}

/** Long-lived pet moods, each mapped to a looping animation. */
export type BaseMood = 'idle' | 'work' | 'waiting'

/** One-shot reactions that interrupt the base animation. */
export type Burst = 'none' | 'failed' | 'jumping' | 'done'

/** Derived pet state for one facts snapshot. */
export interface PetState {
  /** The looping base mood. */
  base: BaseMood
  /** One-shot burst to play (after the previous snapshot). */
  burst: Burst
}

/**
 * Derive the base mood: working beats waiting beats idle.
 * @param facts - current agent facts.
 * @returns the base mood.
 */
export function baseMoodOf(facts: PetFacts): BaseMood {
  if (facts.running) return 'work'
  if (facts.pendingCount > 0) return 'waiting'
  return 'idle'
}

/**
 * Detect one-shot bursts from a snapshot transition. A burst is only emitted
 * on the exact transition (error appears; a new turn starts; a turn ends),
 * never while the condition persists.
 * @param prev - previous facts snapshot, or undefined at bootstrap.
 * @param next - current facts snapshot.
 * @returns the burst to play, or 'none'.
 */
export function burstOf(prev: PetFacts | undefined, next: PetFacts): Burst {
  if (prev !== undefined) {
    if (prev.error === null && next.error !== null) return 'failed'
    if (next.turnCount > prev.turnCount) return 'jumping' // a new turn: the agent takes the task
    if (next.turnEndCount > prev.turnEndCount) return 'done' // a turn finished: celebrate
  }
  return 'none'
}

/**
 * Derive the complete pet state from a snapshot transition.
 * @param prev - previous facts snapshot, or undefined at bootstrap.
 * @param next - current facts snapshot.
 * @returns the derived state.
 */
export function deriveState(prev: PetFacts | undefined, next: PetFacts): PetState {
  return { base: baseMoodOf(next), burst: burstOf(prev, next) }
}
