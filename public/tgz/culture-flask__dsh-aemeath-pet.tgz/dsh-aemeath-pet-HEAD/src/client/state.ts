/**
 * Pure pet-state derivation: maps session facts to the pet's base mood and
 * one-shot bursts. Kept framework-free so the behavior is unit tested without
 * a browser.
 *
 * Facts are deliberately minimal — a running flag plus the last agent error —
 * because the harness client API changes between versions: turn counters and
 * pending-interaction lists came and went, while "is the agent running" and
 * "what was the last error" stay meaningful across them.
 */

/** Session facts the pet reacts to. */
export interface PetFacts {
  /** Whether any visible session is running a turn. */
  running: boolean
  /** Count of pending interactions (kept for the waiting mood; 0 when unknown). */
  pendingCount: number
  /** Last agent error text, or null when the last step did not fail. */
  error: string | null
}

/** Long-lived pet moods, each mapped to a looping animation. */
export type BaseMood = 'idle' | 'work' | 'waiting'

/** One-shot reactions that interrupt the base animation. */
export type Burst = 'none' | 'failed' | 'jumping' | 'done'

/** Derived pet state for one facts snapshot. */
export interface PetState {
  /** The looping base mood. */
  base: BaseMood
  /** One-shot burst to play (after the previous snapshot). */
  burst: Burst
}

/** Facts for "no session at all". */
export const IDLE_FACTS: PetFacts = { running: false, pendingCount: 0, error: null }

/**
 * Derive the base mood: working beats waiting beats idle.
 * @param facts - current session facts.
 * @returns the base mood.
 */
export function baseMoodOf(facts: PetFacts): BaseMood {
  if (facts.running) return 'work'
  if (facts.pendingCount > 0) return 'waiting'
  return 'idle'
}

/**
 * Detect one-shot bursts from a facts transition. A burst is emitted only on
 * the exact flip (work starts, work finishes, a new error text appears) and
 * never while a condition merely persists.
 * @param prev - previous facts snapshot, or undefined at bootstrap.
 * @param next - current facts snapshot.
 * @returns the burst to play, or 'none'.
 */
export function burstOf(prev: PetFacts | undefined, next: PetFacts): Burst {
  if (prev === undefined) return 'none'
  if (next.error !== null && next.error !== prev.error) return 'failed'
  if (!prev.running && next.running) return 'jumping' // the agent took the task
  if (prev.running && !next.running) return 'done' // the turn finished
  return 'none'
}

/**
 * Derive the complete pet state from a facts transition.
 * @param prev - previous facts snapshot, or undefined at bootstrap.
 * @param next - current facts snapshot.
 * @returns the derived state.
 */
export function deriveState(prev: PetFacts | undefined, next: PetFacts): PetState {
  return { base: baseMoodOf(next), burst: burstOf(prev, next) }
}
