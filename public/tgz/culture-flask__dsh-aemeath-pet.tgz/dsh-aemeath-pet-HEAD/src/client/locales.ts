/**
 * `dsh-aemeath-pet` locale namespace: speech-bubble phrases, menu labels, and
 * aria text. Chinese is the product copy; English mirrors it.
 */

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh = {
  'bubble.work': '思考中…',
  'bubble.onTask': '交给我吧！',
  'bubble.done': '搞定啦 ✨',
  'bubble.error': '唔…出错了',
  'bubble.waiting': '等你哦～',
  'bubble.hi': '嗨～',
  'bubble.greeting': '我在哦～',
  'bubble.noAsset': '素材加载失败啦…',
  'menu.size': '大小',
  'menu.dock': '停靠角落',
  'menu.free': '自由摆放',
  'menu.size.small': '小',
  'menu.size.medium': '中',
  'menu.size.large': '大',
  'menu.hide': '隐藏爱弥斯',
  'menu.show': '显示爱弥斯',
  'menu.reset': '重置位置',
  'menu.about': '关于',
  'about.text': '爱弥斯 · DSH 桌宠 v0.1.0',
  'aria.pet': '爱弥斯桌宠',
  'aria.menu': '爱弥斯菜单',
} satisfies Record<string, string>

/** The `dsh-aemeath-pet` namespace key union. */
export type PetKey = keyof typeof zh

/** English dictionary, checked complete against the zh key set. */
export const en = {
  'bubble.work': 'Thinking…',
  'bubble.onTask': 'On it!',
  'bubble.done': 'All done ✨',
  'bubble.error': 'Oops, that failed…',
  'bubble.waiting': 'Waiting for you~',
  'bubble.hi': 'Hi~',
  'bubble.greeting': 'I am here~',
  'bubble.noAsset': 'Spritesheet failed to load…',
  'menu.size': 'Size',
  'menu.dock': 'Dock to corner',
  'menu.free': 'Free position',
  'menu.size.small': 'Small',
  'menu.size.medium': 'Medium',
  'menu.size.large': 'Large',
  'menu.hide': 'Hide Aemeath',
  'menu.show': 'Show Aemeath',
  'menu.reset': 'Reset position',
  'menu.about': 'About',
  'about.text': 'Aemeath · DSH pet v0.1.0',
  'aria.pet': 'Aemeath pet',
  'aria.menu': 'Aemeath menu',
} satisfies Record<PetKey, string>

/** Locale namespace id registered under ctx.locale. */
export const NS = 'dsh-aemeath-pet'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The pet bubble and menu copy. */
    [NS]: PetKey
  }
}
