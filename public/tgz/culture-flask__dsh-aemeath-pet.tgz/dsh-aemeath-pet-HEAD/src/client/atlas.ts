/**
 * Spritesheet layout for the Aemeath pet. The row/frame plan follows the
 * Codex Pet V2 grid (8 columns × 11 animation rows), but this plugin ships a
 * REBUILT atlas: cells are 400×400, i.e. 2× the native 200×200 GIF art, so a
 * HiDPI display can sample the texture 1:1 instead of watching the browser
 * upscale a 192×208 image. Regenerate it with `pnpm run build:atlas`
 * (scripts/build-atlas.py) from the vendored sources in assets/sources/.
 *
 * Native art is 200×200 per frame; the logical (CSS) pet size is derived from
 * NATIVE_W/NATIVE_H, while CELL_W/CELL_H address the texture.
 *
 *   row 0  idle          (7 frames)    row 6  waiting (6 frames)
 *   row 1  running-right (8 frames)    row 7  running (6 frames, work)
 *   row 2  running-left  (8 frames)    row 8  review  (6 frames)
 *   row 3  waving        (4 frames)    row 9  look-front (8 static)
 *   row 4  jumping       (5 frames)    row 10 look-back  (8 static)
 *   row 5  failed        (8 frames)
 */

/** One spritesheet cell size (texture pixels; 2× the native art). */
export const CELL_W = 400
/** One spritesheet cell height (texture pixels; 2× the native art). */
export const CELL_H = 400

/** Native art width in device-independent pixels (the logical pet width at scale 1). */
export const NATIVE_W = 200
/** Native art height in device-independent pixels (the logical pet height at scale 1). */
export const NATIVE_H = 200

/** Animation names the pet can play. */
export type PetAnimation =
  | 'idle'
  | 'walk-right'
  | 'walk-left'
  | 'waving'
  | 'jumping'
  | 'failed'
  | 'waiting'
  | 'work'
  | 'review'
  | 'look-front'
  | 'look-back'

/** One animation: which atlas row, how many frames (columns 0..frames-1), and its timing. */
export interface AnimationSpec {
  /** Atlas row index. */
  row: number
  /** Frame count (columns 0..frames-1). */
  frames: number
  /** Loop rate in frames per second. */
  fps: number
  /** Whether the animation loops; one-shots return to the base mood when done. */
  loop: boolean
}

/** Per-animation atlas metadata. */
export const ANIMATIONS: Record<PetAnimation, AnimationSpec> = {
  idle: { row: 0, frames: 7, fps: 8, loop: true },
  'walk-right': { row: 1, frames: 8, fps: 12, loop: true },
  'walk-left': { row: 2, frames: 8, fps: 12, loop: true },
  waving: { row: 3, frames: 4, fps: 8, loop: false },
  jumping: { row: 4, frames: 5, fps: 10, loop: false },
  failed: { row: 5, frames: 8, fps: 10, loop: false },
  waiting: { row: 6, frames: 6, fps: 8, loop: true },
  work: { row: 7, frames: 6, fps: 12, loop: true },
  review: { row: 8, frames: 6, fps: 8, loop: true },
  'look-front': { row: 9, frames: 8, fps: 3, loop: true },
  'look-back': { row: 10, frames: 8, fps: 3, loop: true },
}

/** Browser URL of the spritesheet (served by the host half). */
export const SHEET_URL = '/aemeath-pet/spritesheet.webp'

/** Map a base mood to the animation that loops for it. */
export function animationForBase(base: 'idle' | 'work' | 'waiting'): PetAnimation {
  if (base === 'work') return 'work'
  if (base === 'waiting') return 'waiting'
  return 'idle'
}
