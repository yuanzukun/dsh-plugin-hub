# dsh-custom-enter-key

[English](README.md) | 中文

`@dsh-external/dsh-custom-enter-key` 是 DeepSeek Harness Web GUI 的独立插件．它可以分别配置 Enter、Ctrl/Cmd+Enter、Shift+Enter 三个提交按键的行为（换行 / 排队发送 / 插话发送），取代内置的「繁忙时 Enter 键行为」．

## 功能

内置的 `ui-conversation.busyEnter` 偏好只提供二元选择：智能体繁忙时普通 Enter 排队或插话，Ctrl/Cmd+Enter 永远绑定为另一行为．本插件把每个按键独立出来：Enter、Ctrl/Cmd+Enter、Shift+Enter 都可分别选择换行、排队发送、插话发送中的任意一项．

默认值与内置行为一致（Enter 排队、Ctrl/Cmd+Enter 插话、Shift+Enter 换行）．启用后不修改任何按键即等效．之后在「设置 → 通用设置 → 提交按键」中逐个修改．配置保存在浏览器 `localStorage`（键 `dsh.customEnterKey`）．插件不引入新的模型可见输入，只把按键手势映射到输入栏既有的 queue/steer 提交流程．

## 如何取代内置偏好

插件挂载后，在文档捕获阶段拦截三个 Enter 按键（先于 React 委托处理器），并驱动与内置输入栏同一个公开输入 facade（`ctx.conversation.input`）．因此内置 busyEnter 偏好对这三个按键失效．它的设置行保留，但不再起作用．独立插件无法移除其他插件的行．

- **换行**：只停止事件传播而不阻止默认行为，浏览器原生插入换行、光标不动，输入状态机经正常变更路径收下．Shift+Enter 配置为换行时不拦截（输入栏本就原生换行）．
- **排队发送 / 插话发送**：阻止默认行为并停止事件传播后调用 `input.submit('queue' | 'steer')`：与输入栏相同的机器路径，包含斜杠命令仲裁、引用 chip 与草稿清空．
- **插话降级**：会话空闲或已寻址 subagent（其传输不支持 steering）时，steer 自动降级为 queue，与内置行为一致．
- **空草稿插话**：配置为插话的按键在草稿为空时，经公开的 `conversation.updateQueue(itemId, { kind: 'steer' })` 按 FIFO 把仍在排队的消息全部插话进运行中的轮次．
- **放行场景**：IME 组合输入、斜杠菜单（`[role="listbox"]`）打开、无会话的 inert 输入框（工作区选择器）都保持原生行为．

## 安装

插件是独立的 dsh bundle 插件，用 `dsh plugin` 命令安装到 profile 中．安装前先构建：

1. 构建插件：

```sh
# 安装构建工具
pnpm install

# 生成类型检查路径表，DSH_REPO 指向 dsh 仓库
DSH_REPO=/path/to/deepseek-harness node scripts/gen-paths.mjs > tsconfig.paths.json

# 构建 lib/index.js 与 lib/client.js
pnpm build
```

2. 安装到你的 dsh profile：

```sh
dsh plugin --profile web add /path/to/dsh-custom-enter-key
```

3. 重启 `dsh web`．

插件会出现在「设置 → 插件」面板中，可在此停用或启用．

## 开发

插件自带独立的 Biome 工具链，不依赖顶层仓库的 lint 规则．

```sh
# 安装构建工具
pnpm install

# harness 构建后重新生成类型检查路径表
DSH_REPO=/path/to/deepseek-harness node scripts/gen-paths.mjs > tsconfig.paths.json

# 类型检查（对照 harness 的 lib/types 产物）
pnpm typecheck

# 代码检查与格式
pnpm lint
pnpm format

# 纯逻辑冒烟（配置往返、按键映射、插话降级）
pnpm smoke

# 重新构建
pnpm build
```

## 结构

- `src/index.ts`：节点侧，内容为空．所有状态与行为都在浏览器侧．
- `src/client/config.ts`：配置类型、默认值、localStorage 读写，无运行时依赖，可直接测试．
- `src/client/store.ts`：设置行与拦截器共享的响应式配置 store．
- `src/client/keys.ts`：文档级按键拦截与投递决策，纯决策函数已导出．
- `src/client/SubmitKeysRow.tsx`：通用设置里的「提交按键」行组．
- `src/client/apply.ts`：浏览器插件入口，注册设置行、拦截器与词典．
- `cordis.patch.yml`：挂载插件行的 bundle patch．
- `pnpm-workspace.yaml`：关闭自动安装 peer 依赖．

## 已知限制

- **内置行仍显示**：独立插件不能移除其他插件注册的设置行．「繁忙时 Enter 键行为」行保留，但不再影响被拦截的三个按键．
- **默认差异**：若在启用本插件前把内置 busyEnter 设为「插话发送」，启用后普通 Enter 回到本插件默认（排队）．插件配置始终优先．

## 许可证

依据 Apache License 2.0 授权，完整文本见 LICENSE 文件．版权声明：Copyright 2026 Aberter0x3F．
