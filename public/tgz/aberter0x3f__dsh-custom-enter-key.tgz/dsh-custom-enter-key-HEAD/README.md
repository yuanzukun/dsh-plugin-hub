# dsh-custom-enter-key

English | [中文](README.zh.md)

`@dsh-external/dsh-custom-enter-key` is a standalone plugin for the DeepSeek Harness web GUI.
It configures Enter, Ctrl/Cmd+Enter, and Shift+Enter independently.
Each key can use any of three behaviors: newline, queue send, or interject send.
It replaces the built-in "busy-Enter behavior" preference.

## What it does

The built-in `ui-conversation.busyEnter` preference has one binary choice.
While the addressed agent is busy, plain Enter queues or interjects.
Ctrl/Cmd+Enter always performs the other behavior.
This plugin makes every key independent.
Enter, Ctrl/Cmd+Enter, and Shift+Enter can each use any of the same three behaviors.
The behaviors are newline, queue send, and interject send.

The defaults preserve the built-in composer behavior.
Enter queues, Ctrl/Cmd+Enter steers, and Shift+Enter breaks the line.
With these defaults, the plugin changes nothing until you set a key.
You set keys in Settings → General → Submit keys.
The plugin stores its configuration in browser `localStorage`, under the `dsh.customEnterKey` key.
The plugin adds no new model-visible input.
It uses only the existing queue and steer submission verbs.

## How it replaces the built-in preference

While mounted, the plugin intercepts the three Enter-family keys.
It intercepts them on the document capture phase, before React's delegated handlers.
It drives the same public input facade that the composer uses (`ctx.conversation.input`).
The built-in busy-Enter preference stops affecting the three keys.
Its Settings row stays visible, but it is inert.
A standalone plugin cannot remove another plugin's row.

- **Newline**: The plugin stops propagation. It does not prevent the default action.
  The browser inserts the newline natively.
  The input machine accepts it through the normal change path.
  The caret stays in place.
  Shift+Enter with newline behavior is not intercepted.
  The composer bar already breaks the line natively.

- **Queue send and Interject send**: The plugin prevents the default action and stops propagation.
  Then it calls `input.submit('queue' | 'steer')`.
  The call uses the same machine path as the composer bar.
  It includes slash-command arbitration, reference chips, and draft clearing.

- **Steer degradation**: Steer degrades to queue when the session is idle.
  It also degrades when the session is an addressed subagent.
  A subagent transport exposes no steering face.
  This matches the built-in behavior.

- **Empty-draft steer**: A steer-configured key with an empty draft flushes the pending queue.
  It sends the queued messages in FIFO order, into the running turn.
  It uses the public `conversation.updateQueue(itemId, { kind: 'steer' })`.

- **Pass-through**: IME composition keeps its native behavior.
  An open slash menu (`[role="listbox"]`) keeps its native behavior.
  The inert no-session textarea (workspace picker) keeps its native behavior.

## Installation

The plugin is a standalone dsh bundle plugin.
It installs into a profile with the `dsh plugin` command.
Build it before installation.

1. Build the plugin:

```sh
# Install the build tools
pnpm install

# Generate the type-check path table. Point DSH_REPO at the dsh repository.
DSH_REPO=/path/to/deepseek-harness node scripts/gen-paths.mjs > tsconfig.paths.json

# Build lib/index.js and lib/client.js
pnpm build
```

2. Install the plugin into your dsh profile:

```sh
dsh plugin --profile web add /path/to/dsh-custom-enter-key
```

3. Restart `dsh web`.

The plugin appears in Settings → Plugins.
You can enable or disable it there.

## Development

The plugin has its own Biome setup.
This setup is independent of the repository lint rules.

```sh
# Install the build tools
pnpm install

# Generate the type-check path table after a harness build
DSH_REPO=/path/to/deepseek-harness node scripts/gen-paths.mjs > tsconfig.paths.json

# Type-check against the harness lib/types outputs
pnpm typecheck

# Lint and format with Biome
pnpm lint
pnpm format

# Pure-logic smoke (config round-trip, gesture mapping, steer degradation)
pnpm smoke

# Rebuild the bundles
pnpm build
```

## Layout

- `src/index.ts`: node half. It is empty. All state and behavior live in the browser.
- `src/client/config.ts`: configuration types, defaults, and localStorage read/write. It has no runtime dependency, so it is directly testable.
- `src/client/store.ts`: reactive configuration store. The Settings row and the interceptor share it.
- `src/client/keys.ts`: document-level key interception and delivery decisions. The pure decision helpers are exported.
- `src/client/SubmitKeysRow.tsx`: the "Submit keys" row group in General Settings.
- `src/client/apply.ts`: browser plugin entry. It registers the Settings row, the interceptor, and the dictionaries.
- `cordis.patch.yml`: the bundle patch that mounts the plugin row.
- `pnpm-workspace.yaml`: disables automatic peer installation.

## Known limitations

- **The built-in row remains**. A standalone plugin cannot remove another plugin's Settings row. The "busy-Enter behavior" row stays visible, but it no longer affects the three intercepted keys.
- **Default divergence**. If you set the built-in busy-Enter preference to Steer before you enable this plugin, plain Enter returns to the plugin default (Queue). The plugin configuration always wins.

## License

Licensed under the Apache License, Version 2.0.
See the LICENSE file for the full text.
Copyright 2026 Aberter0x3F.
