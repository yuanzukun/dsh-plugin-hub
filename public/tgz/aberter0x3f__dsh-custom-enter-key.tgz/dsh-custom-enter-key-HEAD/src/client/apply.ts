/**
 * Copyright 2026 Aberter0x3F
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Browser custom-enter-key plugin: registers the per-key Settings row and the
 * document-level key interceptor that gives Enter, Ctrl/Cmd+Enter, and
 * Shift+Enter their configured behaviors.
 */
import type { Context } from "@deepseek-ai/cordis";
// Type-only: pulls the locale plugin's Context merge (ctx.locale).
import type {} from "@deepseek-ai/dsh-client-locale/client";
// Type-only: pulls the settings domain's slot map (settings.general.item) and
// scope merge into this program.
import type {} from "@deepseek-ai/dsh-client-ui-settings/client";
import { attachSubmitKeyInterceptor } from "./keys.ts";
import { en, NS, type SubmitKeysKey, zh } from "./locales.ts";
import type { SubmitKeysInjected } from "./SubmitKeysRow.tsx";
import { SubmitKeysRow } from "./SubmitKeysRow.tsx";
import { createConfigStore, setBehavior } from "./store.ts";

declare module "@deepseek-ai/dsh-client-ui-slots" {
  interface LocaleNamespaceMap {
    "custom-enter-key": SubmitKeysKey;
  }
}

/**
 * Services required by the custom-enter-key plugin. The conversation service is
 * resolved lazily so the plugin degrades where the composer is absent.
 */
export const inject = ["slots", "sessions", "locale"];

/**
 * Mount the browser half.
 * @param ctx - Client root context.
 */
export function apply(ctx: Context): void {
  const config = createConfigStore();
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), "custom-enter-key: dictionaries");
  ctx.effect(
    () => attachSubmitKeyInterceptor(ctx, config),
    "custom-enter-key: composer key interceptor",
  );
  ctx.slots.inject("settings.general.item", () =>
    ctx.slots.register(
      {
        name: "settings.general.item",
        id: "custom-enter-key",
        order: 21,
        locale: NS,
        inject: (): SubmitKeysInjected => ({
          hooks: { keys: config },
          setBehavior: (key, behavior) => {
            setBehavior(config, key, behavior);
          },
        }),
      },
      SubmitKeysRow,
    ),
  );
}
