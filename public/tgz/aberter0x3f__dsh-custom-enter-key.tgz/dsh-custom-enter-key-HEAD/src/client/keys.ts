/**
 * Copyright 2026 Aberter0x3F
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Document-level key interception that gives Enter, Ctrl/Cmd+Enter, and
 * Shift+Enter the behavior configured in the plugin's Settings row. The
 * built-in composer bar hard-codes its busy-Enter handling, so this listener
 * takes precedence on the capture phase: it stops propagation before React's
 * delegated handlers (and therefore the composer bar's keydown) see the
 * event, and drives the same public input facade the composer uses.
 */
import type { ClientContext, SnapshotStore } from "@deepseek-ai/dsh-client-runtime/client";
import type { IConversation } from "@deepseek-ai/dsh-client-ui-conversation/client";
import type { KeyBehavior, SubmitKeyConfig } from "./config.ts";

/** Delivery modes the input facade accepts. */
export type SubmitMode = "queue" | "steer";

/** The gesture's submit key, independent of the built-in busy state. */
export function submitKeyOf(
  event: Pick<KeyboardEvent, "shiftKey" | "ctrlKey" | "metaKey">,
): "enter" | "ctrlEnter" | "shiftEnter" {
  if (event.shiftKey) return "shiftEnter";
  if (event.ctrlKey || event.metaKey) return "ctrlEnter";
  return "enter";
}

/**
 * Resolve the delivery mode for one submit behavior: steer degrades to queue
 * while the addressed session is idle or an addressed subagent (their
 * continuation transport exposes no steering face).
 * @param behavior - the configured Queue or Steer intent.
 * @param running - whether the addressed agent currently reports busy.
 * @param addressedSubagent - whether the current session is an addressed subagent.
 */
export function deliveryModeOf(
  behavior: Exclude<KeyBehavior, "newline">,
  running: boolean,
  addressedSubagent: boolean,
): SubmitMode {
  if (behavior === "steer" && (!running || addressedSubagent)) return "queue";
  return behavior;
}

/** True when the active element is the live composer textarea. The inert no-session textarea stays native. */
function composerFocused(): boolean {
  const el = document.activeElement;
  return (
    el instanceof HTMLTextAreaElement &&
    el.hasAttribute("data-phase") &&
    el.getAttribute("data-phase") !== "inert"
  );
}

/** The slash popup owns Enter while open (aria-activedescendant listbox). */
function slashMenuOpen(): boolean {
  return document.querySelector('[role="listbox"]') !== null;
}

/**
 * Attach the submit-key interceptor.
 * @param ctx - client root context. Services are read live at event time.
 * @param config - the shared per-key behavior store.
 * @returns disposer removing the listener.
 */
export function attachSubmitKeyInterceptor(
  ctx: ClientContext,
  config: SnapshotStore<SubmitKeyConfig>,
): () => void {
  const onKeyDown = (event: KeyboardEvent): void => {
    if (event.key !== "Enter") return;
    if (!composerFocused() || event.isComposing || slashMenuOpen()) return;
    // oxlint-disable-next-line typescript/no-deprecated
    if (event.keyCode === 229) return; // legacy IME-composition signal
    const key = submitKeyOf(event);
    const behaviors = config.getSnapshot();
    const behavior =
      key === "enter"
        ? behaviors.enter
        : key === "ctrlEnter"
          ? behaviors.ctrlEnter
          : behaviors.shiftEnter;
    if (behavior === "newline") {
      // Native line break with the composer bar submit suppressed. Stop
      // propagation without preventDefault. The browser inserts the newline
      // natively. The machine accepts it through its normal change path with
      // the caret preserved. Shift+Enter needs no interception. The composer
      // bar already breaks the line natively.
      if (key === "shiftEnter") return;
      event.stopPropagation();
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    if (event.repeat) return; // a held key must not send again
    void handleSubmit(ctx, behavior);
  };
  document.addEventListener("keydown", onKeyDown, true);
  return () => document.removeEventListener("keydown", onKeyDown, true);
}

/**
 * Submit the current draft (or flush the queue on an empty-draft steer)
 * through the public input facade. Steer degrades to queue when the
 * addressed session cannot steer.
 * @param ctx - client root context.
 * @param behavior - Queue or Steer delivery intent.
 */
async function handleSubmit(
  ctx: ClientContext,
  behavior: Exclude<KeyBehavior, "newline">,
): Promise<void> {
  const sessions = ctx.sessions;
  const list = sessions.list.getSnapshot();
  const id = list.current;
  if (id === undefined) return;
  const summary = list.byId[id];
  const mode = deliveryModeOf(
    behavior,
    summary?.running ?? false,
    list.currentAddress !== undefined,
  );
  const binding = sessions.binding(id);
  const conversation = ctx.get("conversation") as IConversation | undefined;
  if (binding === undefined || conversation === undefined) return;
  const input = conversation.input.for(binding.ctx);
  // Empty-draft steer flushes the still-pending queue (the composer's
  // whole-queue gesture) instead of the machine's empty-draft no-op.
  if (mode === "steer" && input.state.getSnapshot().draft.trim() === "") {
    const queued = input.state.getSnapshot().queue.filter((row) => row.placement === "queued");
    if (queued.length > 0) {
      const scoped = sessions.scope(id)?.get("conversation") as IConversation | undefined;
      if (scoped !== undefined) {
        for (const row of queued) await scoped.updateQueue(row.id, { kind: "steer" });
      }
      return;
    }
  }
  input.submit(mode);
}
