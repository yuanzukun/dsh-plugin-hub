/**
 * Copyright 2026 Aberter0x3F
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Reactive configuration store shared by the Settings row and the key
 * interceptor, backed by the localStorage document in config.ts.
 */
import { createSnapshotStore, type SnapshotStore } from "@deepseek-ai/dsh-client-runtime/client";
import {
  type KeyBehavior,
  loadConfig,
  persistConfig,
  type SubmitKey,
  type SubmitKeyConfig,
} from "./config.ts";

/** The reactive config source shared by the Settings row and the key interceptor. */
export function createConfigStore(): SnapshotStore<SubmitKeyConfig> {
  return createSnapshotStore(loadConfig());
}

/**
 * Change one submit key's behavior: publish locally first, then persist.
 * @param store - the shared config store.
 * @param key - the submit key being reconfigured.
 * @param behavior - Newline, Queue, or Steer.
 */
export function setBehavior(
  store: SnapshotStore<SubmitKeyConfig>,
  key: SubmitKey,
  behavior: KeyBehavior,
): void {
  const current = store.getSnapshot();
  if (current[key] === behavior) return;
  const next = { ...current, [key]: behavior };
  store.set(next);
  persistConfig(next);
}
