/**
 * Copyright 2026 Aberter0x3F
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * General Settings row group for the Composer submit keys: Enter,
 * Ctrl/Cmd+Enter, and Shift+Enter, each with an independent Newline,
 * Queue, or Interject behavior. While this plugin is mounted, the built-in
 * busy-Enter preference is inert. The key interceptor decides every Enter.
 */

import type { SnapshotStore } from "@deepseek-ai/dsh-client-runtime/client";
import { IconChevronDownOutline14, Menu } from "@deepseek-ai/dsh-client-ui-primitives";
import type { InjectFace, PropsLocale, PropsRuntime } from "@deepseek-ai/dsh-client-ui-slots";
import { useState } from "react";
import { type KeyBehavior, SUBMIT_KEYS, type SubmitKey, type SubmitKeyConfig } from "./config.ts";
import type { SubmitKeysKey } from "./locales.ts";

/** Registration-side inject face. */
export interface SubmitKeysInjected {
  hooks: {
    /** Live per-key behaviors bound as useKeys. */
    keys: SnapshotStore<SubmitKeyConfig>;
  };
  /** Change one submit key's behavior. */
  setBehavior: (key: SubmitKey, behavior: KeyBehavior) => void;
}

/** Full Settings-row props. */
export type SubmitKeysRowProps = PropsRuntime<"settings.general.item"> &
  PropsLocale<"custom-enter-key"> &
  InjectFace<SubmitKeysInjected>;

const BEHAVIOR_OPTIONS: readonly { id: KeyBehavior; label: SubmitKeysKey }[] = [
  { id: "newline", label: "behavior.newline" },
  { id: "queue", label: "behavior.queue" },
  { id: "steer", label: "behavior.steer" },
];

const KEY_LABELS: Record<SubmitKey, SubmitKeysKey> = {
  enter: "key.enter",
  ctrlEnter: "key.ctrlEnter",
  shiftEnter: "key.shiftEnter",
};

/** Resolve one behavior's localized label key. */
function behaviorLabelKey(behavior: KeyBehavior): SubmitKeysKey {
  switch (behavior) {
    case "newline":
      return "behavior.newline";
    case "queue":
      return "behavior.queue";
    case "steer":
      return "behavior.steer";
  }
}

/** One submit key's labeled selector pill. */
function KeySelector({
  label,
  behavior,
  onSelect,
  t,
}: {
  label: string;
  behavior: KeyBehavior;
  onSelect: (behavior: KeyBehavior) => void;
  t: (key: SubmitKeysKey) => string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <fieldset
      aria-label={label}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        minHeight: 36,
        border: "none",
        margin: 0,
        padding: 0,
      }}
    >
      <div
        style={{
          flex: 1,
          minWidth: 0,
          fontSize: 14,
          lineHeight: "22px",
          color: "var(--dsw-alias-label-primary)",
        }}
      >
        {label}
      </div>
      <Menu
        open={open}
        onClose={() => {
          setOpen(false);
        }}
        items={BEHAVIOR_OPTIONS.map((option) => ({ id: option.id, label: t(option.label) }))}
        selectedId={behavior}
        onSelect={(id) => {
          setOpen(false);
          onSelect(id as KeyBehavior);
        }}
        align="end"
        portal
        anchor={
          <button
            type="button"
            aria-haspopup="menu"
            aria-expanded={open}
            onClick={() => {
              setOpen((value) => !value);
            }}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 12,
              height: 36,
              padding: "0 14px",
              border: "none",
              borderRadius: 18,
              background: "var(--dsw-alias-bg-module-platform)",
              font: "inherit",
              fontSize: 14,
              lineHeight: "22px",
              color: "var(--dsw-alias-label-primary)",
              cursor: "pointer",
            }}
          >
            {t(behaviorLabelKey(behavior))}
            <IconChevronDownOutline14 />
          </button>
        }
      />
    </fieldset>
  );
}

/**
 * Render the Composer submit-key behavior selector group.
 * @param props - composed Settings slot props.
 * @returns the group of per-key rows.
 */
export function SubmitKeysRow({ useKeys, setBehavior, t }: SubmitKeysRowProps) {
  const keys = useKeys((snapshot) => snapshot);
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 12,
        padding: "16px 0",
        borderBottom: "1px solid var(--dsw-alias-border-l2)",
      }}
    >
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        <div
          style={{
            fontSize: 14,
            fontWeight: 400,
            lineHeight: "22px",
            color: "var(--dsw-alias-label-primary)",
          }}
        >
          {t("title")}
        </div>
        <div
          style={{
            fontSize: 12,
            fontWeight: 400,
            lineHeight: "18px",
            color: "var(--dsw-alias-label-tertiary)",
          }}
        >
          {t("description")}
        </div>
      </div>
      {SUBMIT_KEYS.map((key) => (
        <KeySelector
          key={key}
          label={t(KEY_LABELS[key])}
          behavior={keys[key]}
          onSelect={(behavior) => setBehavior(key, behavior)}
          t={t}
        />
      ))}
    </div>
  );
}
