/**
 * Copyright 2026 Aberter0x3F
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** `custom-enter-key` namespace dictionaries. */

/** Dictionary namespace owned by this plugin. */
export const NS = "custom-enter-key";

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh = {
  title: "提交按键",
  description: "分别设置 Enter、Ctrl/Cmd+Enter、Shift+Enter 的行为．插话发送仅在智能体运行时生效．",
  "key.enter": "Enter",
  "key.ctrlEnter": "Ctrl/Cmd+Enter",
  "key.shiftEnter": "Shift+Enter",
  "behavior.newline": "换行",
  "behavior.queue": "排队发送",
  "behavior.steer": "插话发送",
} satisfies Record<string, string>;

/** The custom-enter-key namespace key union. */
export type SubmitKeysKey = keyof typeof zh;

/** English dictionary, checked complete against the zh key set. */
export const en = {
  title: "Submit keys",
  description:
    "Set the behavior of Enter, Ctrl/Cmd+Enter, and Shift+Enter independently. Interject send works only while the agent is running.",
  "key.enter": "Enter",
  "key.ctrlEnter": "Ctrl/Cmd+Enter",
  "key.shiftEnter": "Shift+Enter",
  "behavior.newline": "Newline",
  "behavior.queue": "Queue",
  "behavior.steer": "Interject",
} satisfies Record<SubmitKeysKey, string>;
