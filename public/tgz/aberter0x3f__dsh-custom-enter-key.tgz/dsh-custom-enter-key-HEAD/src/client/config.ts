/**
 * Copyright 2026 Aberter0x3F
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Per-key composer submit configuration: one behavior for Enter,
 * Ctrl/Cmd+Enter, and Shift+Enter, persisted in localStorage. The built-in
 * Host-settings preference (ui-conversation.busyEnter) cannot be reused by a
 * standalone plugin because the web settings API serves an explicit namespace
 * allowlist, so the plugin keeps its own browser-scoped document. This module
 * is runtime-free so the pure logic stays directly testable.
 */
/** The three composer submit keys. */
export const SUBMIT_KEYS = ["enter", "ctrlEnter", "shiftEnter"] as const;

/** One configurable composer submit key. */
export type SubmitKey = (typeof SUBMIT_KEYS)[number];

/** Behaviors every submit key can take. */
export const KEY_BEHAVIORS = ["newline", "queue", "steer"] as const;

/** Configurable meaning of one composer submit key. */
export type KeyBehavior = (typeof KEY_BEHAVIORS)[number];

/** Defaults preserve the built-in composer: Enter queues, Ctrl/Cmd+Enter steers, Shift+Enter breaks the line. */
export const DEFAULT_BEHAVIORS: Record<SubmitKey, KeyBehavior> = {
  enter: "queue",
  ctrlEnter: "steer",
  shiftEnter: "newline",
};

/** Durable configuration section. */
export interface SubmitKeyConfig {
  /** Behavior of the plain Enter key. */
  enter: KeyBehavior;
  /** Behavior of Ctrl/Cmd+Enter (Cmd on macOS). */
  ctrlEnter: KeyBehavior;
  /** Behavior of Shift+Enter. */
  shiftEnter: KeyBehavior;
}

/** Browser storage key for the configuration document. */
export const STORAGE_KEY = "dsh.customEnterKey";

function isValidBehavior(value: unknown): value is KeyBehavior {
  return typeof value === "string" && (KEY_BEHAVIORS as readonly string[]).includes(value);
}

/** Read the persisted section, falling back to defaults on absence or corruption. */
export function loadConfig(): SubmitKeyConfig {
  if (typeof localStorage === "undefined") return { ...DEFAULT_BEHAVIORS };
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) return { ...DEFAULT_BEHAVIORS };
    const parsed = JSON.parse(raw) as Partial<SubmitKeyConfig>;
    return {
      enter: isValidBehavior(parsed.enter) ? parsed.enter : DEFAULT_BEHAVIORS.enter,
      ctrlEnter: isValidBehavior(parsed.ctrlEnter) ? parsed.ctrlEnter : DEFAULT_BEHAVIORS.ctrlEnter,
      shiftEnter: isValidBehavior(parsed.shiftEnter)
        ? parsed.shiftEnter
        : DEFAULT_BEHAVIORS.shiftEnter,
    };
  } catch {
    // A corrupt document does not fail the plugin.
    return { ...DEFAULT_BEHAVIORS };
  }
}

/** Persist the section. Storage failures keep the live in-memory value. */
export function persistConfig(config: SubmitKeyConfig): void {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch {
    // Quota or private-mode rejection: the live value still applies.
  }
}
