/**
 * Copyright 2026 Aberter0x3F
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Host half of the custom-enter-key plugin. All state lives in the browser
 * (localStorage-backed configuration) and the client half owns both the
 * Settings row and the key interception, so the host half is empty by
 * design. The row still needs a valid plugin entry to load.
 */
import type { Context } from "@deepseek-ai/cordis";

/**
 * Mount the host half.
 * @param ctx - Host context (unused: the host half owns no state).
 */
export function apply(_ctx: Context): void {
  // No host-side work: configuration and behavior are browser-only.
}
