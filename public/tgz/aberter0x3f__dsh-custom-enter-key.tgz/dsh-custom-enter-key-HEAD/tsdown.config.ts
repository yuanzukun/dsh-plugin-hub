/**
 * Copyright 2026 Aberter0x3F
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Two-half build: the node half (ESM) plus the official client bundle
// (CJS, the __ModuleLoader__ contract). The harness packages stay external;
// the profile closure supplies them at runtime.
export default [
  {
    entry: ["src/index.ts"],
    format: "esm",
    platform: "node",
    target: "es2024",
    outDir: "lib",
    clean: true,
    external: [/@deepseek-ai\//],
  },
  {
    name: "@dsh-external/dsh-custom-enter-key/client",
    entry: { client: "src/client/index.ts" },
    outDir: "lib",
    format: "cjs",
    platform: "browser",
    dts: false,
    clean: false,
    external: [/@deepseek-ai\/dsh-client-/, "react", "react-dom"],
    outputOptions: {
      entryFileNames: "client.js",
      banner:
        'window.__ModuleLoader__.load({ id: "@dsh-external/dsh-custom-enter-key", factory: (require) => {',
      footer: "return module.exports; } });",
      intro: "var module = { exports: {} }; var exports = module.exports;",
    },
  },
];
