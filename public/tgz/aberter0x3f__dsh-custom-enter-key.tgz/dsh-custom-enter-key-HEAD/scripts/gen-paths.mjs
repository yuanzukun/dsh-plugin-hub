#!/usr/bin/env node

/**
 * Copyright 2026 Aberter0x3F
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Generate the plugin's TypeScript path table from the dsh repository's
 * BUILT declarations (lib/types). The standalone plugin type-checks against
 * the harness's shipped artifacts instead of compiling its source graph.
 * Run from the plugin directory after a harness build:
 *   DSH_REPO=/path/to/deepseek-harness node scripts/gen-paths.mjs > tsconfig.paths.json
 */
import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";

if (!process.env.DSH_REPO) throw new Error("DSH_REPO must point at the dsh repository");
const repoRoot = process.env.DSH_REPO;

/** @type {string[]} */
const packageDirs = [];
for (const group of ["vendor"]) {
  const groupDir = join(repoRoot, group);
  if (!existsSync(groupDir)) continue;
  for (const entry of readdirSync(groupDir)) {
    const pkgDir = join(groupDir, entry);
    if (!existsSync(join(pkgDir, "package.json")) || !existsSync(join(pkgDir, "lib", "types")))
      continue;
    packageDirs.push(pkgDir);
  }
}
for (const group of ["packages"]) {
  const groupDir = join(repoRoot, group);
  if (!existsSync(groupDir)) continue;
  for (const area of readdirSync(groupDir)) {
    const areaDir = join(groupDir, area);
    if (!existsSync(areaDir) || !statSync(areaDir).isDirectory()) continue;
    for (const entry of readdirSync(areaDir)) {
      const pkgDir = join(areaDir, entry);
      if (!existsSync(join(pkgDir, "package.json")) || !existsSync(join(pkgDir, "lib", "types")))
        continue;
      packageDirs.push(pkgDir);
    }
  }
}

/** @type {Record<string, string[]>} */
const paths = {};
for (const pkgDir of packageDirs) {
  const manifest = JSON.parse(readFileSync(join(pkgDir, "package.json"), "utf8"));
  if (typeof manifest.name !== "string" || !manifest.name.startsWith("@deepseek-ai/")) continue;
  const exports = manifest.exports;
  if (exports === undefined || typeof exports !== "object") continue;
  for (const [subpath, target] of Object.entries(exports)) {
    if (subpath === "./package.json" || subpath.endsWith("*")) continue;
    const typesTarget =
      typeof target === "string"
        ? target
        : target !== null && typeof target === "object" && typeof target.types === "string"
          ? target.types
          : undefined;
    if (
      typesTarget === undefined ||
      !typesTarget.startsWith("./lib/types/") ||
      !typesTarget.endsWith(".d.ts")
    )
      continue;
    const absolute = join(pkgDir, typesTarget).split("\\").join("/");
    paths[manifest.name + (subpath === "." ? "" : subpath.slice(1))] = [absolute];
  }
}

// Framework types resolve through a workspace package's own install.
paths.react = [`${repoRoot}/packages/client/ui-conversation/node_modules/@types/react`];
paths["react/jsx-runtime"] = [
  `${repoRoot}/packages/client/ui-conversation/node_modules/@types/react/jsx-runtime.d.ts`,
];
paths["react-dom"] = [`${repoRoot}/packages/client/ui-conversation/node_modules/@types/react-dom`];
paths["react-dom/client"] = [
  `${repoRoot}/packages/client/ui-conversation/node_modules/@types/react-dom/client.d.ts`,
];

process.stdout.write(`${JSON.stringify({ compilerOptions: { paths } }, null, 2)}\n`);
