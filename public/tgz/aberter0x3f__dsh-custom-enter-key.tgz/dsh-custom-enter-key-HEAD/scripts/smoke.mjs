#!/usr/bin/env node

/**
 * Copyright 2026 Aberter0x3F
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Smoke check for the plugin's pure logic (configuration round-trip and the
 * gesture/delivery decision). Run from the plugin directory:
 *   node --import tsx/esm scripts/smoke.mjs
 * (tsx resolves @deepseek-ai/* through this package's tsconfig path table.)
 */
import assert from "node:assert/strict";
import {
  DEFAULT_BEHAVIORS,
  KEY_BEHAVIORS,
  loadConfig,
  persistConfig,
  SUBMIT_KEYS,
} from "../src/client/config.ts";
import { deliveryModeOf, submitKeyOf } from "../src/client/keys.ts";

/** @type {Map<string, string>} */
const storage = new Map();
globalThis.localStorage = {
  getItem: (key) => (storage.has(key) ? storage.get(key) : null),
  setItem: (key, value) => {
    storage.set(key, value);
  },
  removeItem: (key) => {
    storage.delete(key);
  },
};

// Defaults preserve the built-in composer semantics.
assert.deepEqual(loadConfig(), { enter: "queue", ctrlEnter: "steer", shiftEnter: "newline" });

// A corrupt document falls back to defaults instead of failing the plugin.
storage.set("dsh.customEnterKey", "{not json");
assert.deepEqual(loadConfig(), { ...DEFAULT_BEHAVIORS });

// Invalid field values are replaced per key; valid ones survive.
storage.set(
  "dsh.customEnterKey",
  JSON.stringify({ enter: "steer", ctrlEnter: "bogus", shiftEnter: "queue" }),
);
assert.deepEqual(loadConfig(), { enter: "steer", ctrlEnter: "steer", shiftEnter: "queue" });

// Persistence round-trip.
persistConfig({ enter: "newline", ctrlEnter: "queue", shiftEnter: "steer" });
assert.equal(
  storage.get("dsh.customEnterKey"),
  JSON.stringify({ enter: "newline", ctrlEnter: "queue", shiftEnter: "steer" }),
);
assert.deepEqual(loadConfig(), { enter: "newline", ctrlEnter: "queue", shiftEnter: "steer" });

// Gesture mapping: Shift wins, then the accelerated chord, then plain Enter.
assert.equal(submitKeyOf({ shiftKey: true, ctrlKey: false, metaKey: false }), "shiftEnter");
assert.equal(submitKeyOf({ shiftKey: false, ctrlKey: true, metaKey: false }), "ctrlEnter");
assert.equal(submitKeyOf({ shiftKey: false, ctrlKey: false, metaKey: true }), "ctrlEnter");
assert.equal(submitKeyOf({ shiftKey: false, ctrlKey: false, metaKey: false }), "enter");

// Delivery downgrade: steer stays steer only while running and not addressed.
assert.equal(deliveryModeOf("queue", true, false), "queue");
assert.equal(deliveryModeOf("steer", true, false), "steer");
assert.equal(deliveryModeOf("steer", false, false), "queue");
assert.equal(deliveryModeOf("steer", true, true), "queue");

// The behavior set is exactly what the UI offers.
assert.deepEqual([...SUBMIT_KEYS], ["enter", "ctrlEnter", "shiftEnter"]);
assert.deepEqual([...KEY_BEHAVIORS], ["newline", "queue", "steer"]);

console.log("smoke: all assertions passed");
