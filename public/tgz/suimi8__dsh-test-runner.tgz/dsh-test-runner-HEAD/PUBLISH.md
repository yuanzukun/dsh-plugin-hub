# 发布与收录清单

## 1. GitHub 仓库创建

```sh
# 在 dsh-test-runner 目录里（已 git init）
gh repo create dsh-test-runner --public \
  --description "DSH plugin: structured test runner tool (test_run) — auto-detect vitest/jest/pytest/node:test, run tests, parse failure summaries for the model." \
  --source . --push
```

仓库创建后，在仓库 Settings 里添加 topics（或用 CLI）：

```sh
gh repo edit --add-topic dsh-plugin --add-topic deepseek-harness --add-topic testing --add-topic test-runner --add-topic cordis
```

> `dsh-plugin` topic 是关键——GitHub `dsh-plugin` topic 页和社区雷达靠它自动发现。

## 2. awesome-dsh-plugins 收录

向 [AdamPlatin123/awesome-dsh-plugins](https://github.com/AdamPlatin123/awesome-dsh-plugins) 提 PR，在 `PLUGINS.md` 的「🔌 单插件」分类表格里追加一行：

```markdown
| [dsh-test-runner](https://github.com/<your-github>/dsh-test-runner) | 结构化测试运行工具 test_run：自动探测 vitest/jest/pytest/node:test，执行并解析失败摘要，避免模型阅读整段原始测试输出 |
```

**PR 标题**：`plugin: add dsh-test-runner`

**PR 描述模板**：

````markdown
## dsh-test-runner

结构化测试运行工具 `test_run`：自动探测测试框架（vitest/jest/pytest/node:test/npm script），执行测试，解析出通过/失败统计与失败用例摘要，避免模型阅读整段原始测试输出。

### 分类
🔌 单插件（工具类）

### 仓库
- URL: https://github.com/<your-github>/dsh-test-runner
- dsh-plugin topic: ✅
- License: MIT

### 兼容性证据
- mainline: `7b9644f`（2026-08）
- 验证环境: Windows + PowerShell 执行器 + node:test 实测通过
- 依赖 seam: `shell` / `fs` / `sandboxPolicy` / `ctx.tools`（均为稳定 seam）
- 退化安全: 解析失败时退化为 exitCode + 输出尾部，不崩溃
- `node --check index.js`: 通过

### 规范合规
对照 `docs/cookbook/adding-a-tool.md` 与 `docs/user/develop/` 全部 ✅（详见仓库 README「规范合规」一节）：
- execute 契约（canonical value / infra throw / exec.signal）
- UI 卡片硬规则（presentCall/presentResult 纯函数 / terminal title 是命令）
- 生命周期（effect-based 注册 / inject / isConcurrencySafe）
- 打包（dsh.bundle.patch / cordis.patch.yml 按包名引用）
````

## 3. awesome-deepseek-harness 收录

向 [0xsline/awesome-deepseek-harness](https://github.com/0xsline/awesome-deepseek-harness) 提 PR，在「🔌 单插件」分类追加同一行（URL 与描述同上）。

## 4. 发布到 npm（可选，免 allowBuilds 权限门槛）

从 git 安装的包需要 `prepare` 脚本 + 用户 `allowBuilds` 放行；发 npm 包则免此门槛：

```sh
# 确认 package.json 的 name/version/files 正确后
npm publish --access public
```

用户侧安装改为：

```sh
dsh plugin --profile web add dsh-test-runner
```

## 5. 发布前自检清单

- [x] `node --check index.js` 语法通过
- [x] `package.json` 声明 `dsh.bundle.patch`
- [x] `cordis.patch.yml` 按包名引用（`name: dsh-test-runner`）
- [x] README 含安装/使用/兼容性/规范合规/已知边界
- [x] LICENSE（MIT）
- [x] .gitignore（排除 node_modules）
- [ ] GitHub repo 创建 + `dsh-plugin` topic
- [ ] 首次 `git commit` + push
- [ ] awesome-dsh-plugins PR
- [ ] awesome-deepseek-harness PR
- [ ]（可选）npm publish
