import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'dsh-test-runner'
export const inject = ['tools']

const FRAMEWORKS = ['vitest', 'jest', 'pytest', 'node', 'npm-test']

function stripAnsi(s) {
  return String(s == null ? '' : s).replace(/\u001b\[[0-9;]*m/g, '')
}

function isAbsolutePath(p) {
  if (typeof p !== 'string' || p === '') return false
  return /^[A-Za-z]:[\\/]/.test(p) || p.charAt(0) === '/' || p.charAt(0) === '~'
}

function resolveWorkdir(modelWorkdir, exec) {
  const headerCwd = exec && exec.agent && exec.agent.session && exec.agent.session.header ? exec.agent.session.header.cwd : undefined
  if (modelWorkdir === undefined || modelWorkdir === '') return headerCwd
  if (headerCwd !== undefined && !isAbsolutePath(modelWorkdir)) {
    return headerCwd.replace(/[\\/]+$/, '') + '/' + modelWorkdir
  }
  return modelWorkdir
}

function buildCommand(framework, target, lastFailed, custom) {
  if (custom && custom.trim()) return custom.trim()
  const t = target ? target.trim() : ''
  switch (framework) {
    case 'vitest':
      if (lastFailed) return 'npx vitest run --lastFailed'
      return t ? 'npx vitest run ' + t : 'npx vitest run'
    case 'jest':
      if (lastFailed) return 'npx jest --onlyFailures --ci'
      return (t ? 'npx jest ' + t : 'npx jest') + ' --ci'
    case 'pytest':
      if (lastFailed) return 'python -m pytest -q --lf'
      return 'python -m pytest -q' + (t ? ' ' + t : '')
    case 'node':
      return t ? 'node --test ' + t : 'node --test'
    case 'npm-test':
      return 'npm test'
    default:
      return null
  }
}

function parseOutput(framework, text) {
  const t = stripAnsi(text)
  const summary = { total: 0, passed: 0, failed: 0, skipped: 0 }
  const failures = []
  if (framework === 'vitest') {
    const line = (t.match(/Tests\s+[^\n]*/) || [''])[0]
    if (line) {
      const fm = line.match(/(\d+)\s+failed/)
      const pm = line.match(/(\d+)\s+passed/)
      const tm = line.match(/\((\d+)\)/)
      if (fm) summary.failed = Number(fm[1])
      if (pm) summary.passed = Number(pm[1])
      summary.total = tm ? Number(tm[1]) : summary.failed + summary.passed
    }
    let cur = null
    for (const raw of t.split('\n')) {
      const line2 = raw.trim()
      const x = line2.match(/^[×✕✗]\s+(.+)$/)
      if (x) { cur = { name: x[1].trim(), message: '', detail: '' }; failures.push(cur); continue }
      const a = line2.match(/^→\s+(.+)$/)
      if (a && cur && !cur.message) cur.message = a[1].trim().slice(0, 300)
    }
  } else if (framework === 'jest') {
    const m = t.match(/Tests:\s+(\d+)\s+failed,\s+(\d+)\s+passed,\s+(\d+)\s+total/)
    if (m) { summary.failed = Number(m[1]); summary.passed = Number(m[2]); summary.total = Number(m[3]) }
    else {
      const m2 = t.match(/Tests:\s+(\d+)\s+passed,\s+(\d+)\s+total/)
      if (m2) { summary.passed = Number(m2[1]); summary.total = Number(m2[2]) }
    }
    let cur = null
    for (const raw of t.split('\n')) {
      const line2 = raw.trim()
      const b = line2.match(/^●\s+(.+)$/)
      if (b) { cur = { name: b[1].trim(), message: '', detail: '' }; failures.push(cur); continue }
      if (cur && !cur.message && line2 && !/^at\s/.test(line2) && !/^FAIL\s/.test(line2)) cur.message = line2.slice(0, 300)
    }
  } else if (framework === 'pytest') {
    const fm = t.match(/(\d+)\s+failed/)
    const pm = t.match(/(\d+)\s+passed/)
    const sm = t.match(/(\d+)\s+skipped/)
    const em = t.match(/(\d+)\s+error/)
    if (fm) summary.failed = Number(fm[1])
    if (pm) summary.passed = Number(pm[1])
    if (sm) summary.skipped = Number(sm[1])
    if (em) summary.failed += Number(em[1])
    summary.total = summary.passed + summary.failed + summary.skipped
    for (const raw of t.split('\n')) {
      const line2 = raw.trim()
      const m = line2.match(/^FAILED\s+(.+)$/)
      if (m) failures.push({ name: m[1].trim(), message: '', detail: '' })
    }
  } else if (framework === 'node') {
    const tM = t.match(/#\s*tests\s+(\d+)/)
    const pM = t.match(/#\s*pass\s+(\d+)/)
    const fM = t.match(/#\s*fail\s+(\d+)/)
    const sM = t.match(/#\s*skipped\s+(\d+)/)
    if (tM) summary.total = Number(tM[1])
    if (pM) summary.passed = Number(pM[1])
    if (fM) summary.failed = Number(fM[1])
    if (sM) summary.skipped = Number(sM[1])
    const lines = t.split('\n')
    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].trim().match(/^not ok\s+\d+\s+-\s+(.+)$/)
      if (m) {
        let message = ''
        for (let j = i + 1; j < Math.min(i + 20, lines.length); j++) {
          const mm = lines[j].trim().match(/^message:\s*(.+)$/)
          if (mm) { message = mm[1].trim(); break }
          if (/^error:\s*\|?-?/.test(lines[j].trim())) {
            const errLines = []
            for (let k = j + 1; k < Math.min(j + 15, lines.length); k++) {
              const l = lines[k]
              if (l.indexOf('  ') !== 0) break
              const trimmed = l.trim()
              if (!trimmed) continue
              errLines.push(trimmed)
              if (errLines.length >= 4) break
            }
            message = errLines.join(' | ').slice(0, 300)
            break
          }
        }
        failures.push({ name: m[1].trim(), message, detail: '' })
      }
    }
  }
  return { summary, failures }
}

function resolveSandboxPolicy(exec, sandboxPolicyService) {
  if (sandboxPolicyService === undefined) return undefined
  try {
    const session = exec && exec.agent && exec.agent.session ? exec.agent.session : undefined
    return sandboxPolicyService.resolve(session ? { session } : {})
  } catch (err) {
    return undefined
  }
}

function renderText(args, v) {
  const lines = []
  const head = ['framework=' + v.framework, 'exit=' + String(v.exitCode)]
  if (v.timedOut) head.push('TIMED_OUT')
  if (typeof v.durationMs === 'number') head.push((v.durationMs / 1000).toFixed(1) + 's')
  lines.push('test_run ' + head.join(' '))
  if (v.command) lines.push('command: ' + v.command)
  if (v.error) lines.push('ERROR: ' + v.error)
  if (v.summary) lines.push('SUMMARY: ' + v.summary.total + ' tests -> ' + v.summary.passed + ' passed, ' + v.summary.failed + ' failed, ' + v.summary.skipped + ' skipped')
  if (v.note) lines.push('note: ' + v.note)
  const failures = v.failures || []
  for (let i = 0; i < Math.min(failures.length, 8); i++) {
    lines.push((i + 1) + ') ' + failures[i].name)
    if (failures[i].message) lines.push('   ' + String(failures[i].message).split('\n')[0].slice(0, 200))
  }
  if (failures.length > 8) lines.push('... 及另外 ' + (failures.length - 8) + ' 个失败')
  if (v.outputTail) lines.push('--- output tail ---\n' + String(v.outputTail).slice(-1500))
  return lines.join('\n')
}

export function apply(ctx) {
  const shell = ctx.get('shell')
  if (shell === undefined) return
  const fsService = ctx.get('fs')
  const sandboxPolicyService = ctx.get('sandboxPolicy')

  async function tryReadFile(name, workdir) {
    if (fsService === undefined) return undefined
    const attempts = []
    if (workdir) attempts.push({ name, cwd: workdir })
    attempts.push({ name })
    for (const a of attempts) {
      try {
        const target = await fsService.resolve(a.name, a.cwd ? { cwd: a.cwd } : undefined)
        const text = await fsService.readText(target)
        if (typeof text === 'string') return text
      } catch (err) { /* try next */ }
    }
    return undefined
  }

  async function detectNodeTests(workdir) {
    if (fsService === undefined) return false
    try {
      const target = await fsService.resolve('.', workdir ? { cwd: workdir } : undefined)
      const entries = await fsService.listDir(target)
      for (const e of entries) {
        if (e.type === 'directory' && (e.name === 'test' || e.name === 'tests' || e.name === '__tests__')) return true
        if (e.type === 'file' && /\.(test|spec)\.(js|ts|mjs|cjs|jsx|tsx)$/.test(e.name)) return true
      }
    } catch (err) { /* ignore */ }
    return false
  }

  async function detectFramework(workdir) {
    const pkgText = await tryReadFile('package.json', workdir)
    if (pkgText !== undefined) {
      try {
        const pkg = JSON.parse(pkgText)
        const deps = Object.assign({}, pkg.dependencies, pkg.devDependencies)
        if (deps && (deps.vitest || deps['@vitest/runner'] || deps['@vitest/ui'])) return 'vitest'
        if (deps && (deps.jest || deps['@jest/core'])) return 'jest'
        if (pkg.scripts && typeof pkg.scripts.test === 'string' && pkg.scripts.test.trim()) return 'npm-test'
      } catch (err) { /* unparsable package.json */ }
    }
    for (const marker of ['pyproject.toml', 'pytest.ini', 'conftest.py']) {
      const text = await tryReadFile(marker, workdir)
      if (text !== undefined) return 'pytest'
    }
    if (await detectNodeTests(workdir)) return 'node'
    return null
  }

  ctx.tools.register(defineTool({
    name: 'test_run',
    description: '在项目中运行测试并返回结构化结果：自动探测测试框架（vitest/jest/pytest/node:test/npm test 脚本），执行测试命令，解析出通过/失败统计与失败用例摘要（名称+错误信息），并附带输出尾部。用于“改代码→跑测试→修”的快速闭环，避免阅读整段原始测试输出。可指定目标文件/用例、超时、只重跑上次失败（last_failed）。',
    parameters: {
      target: { type: 'string', description: '要运行的测试目标：文件、目录或用例过滤模式，例如 "src/utils.test.ts"、"tests/test_api.py::test_login"。多个目标用空格分隔；留空运行全部。' },
      framework: { type: 'string', enum: ['auto', 'vitest', 'jest', 'pytest', 'node', 'npm-test'], description: '测试框架；auto（默认）自动探测：package.json 的 vitest/jest 依赖、npm test 脚本、pyproject.toml/pytest.ini/conftest.py、test 目录或 *.test.* 文件。' },
      workdir: { type: 'string', description: '运行测试的目录；默认当前工作区。相对路径相对于当前会话工作区解析。' },
      last_failed: { type: 'boolean', description: '只重跑上次失败的用例：vitest --lastFailed / jest --onlyFailures / pytest --lf；node 与 npm-test 不支持（忽略）。' },
      timeout_ms: { type: 'number', description: '超时毫秒数，默认 120000（2 分钟）。' },
      command: { type: 'string', description: '完全自定义的运行命令，覆盖框架探测与默认命令构造，例如 "pnpm vitest run"、"python -m pytest -x -q"。' },
    },
    output: {
      schema: { type: 'json' },
      render: (args, value) => [{ type: 'text', text: renderText(args, value) }],
      presentationMeta: (args, value) => ({
        exitCode: value.exitCode,
        timedOut: !!value.timedOut,
        outputText: renderText(args, value),
      }),
    },
    isConcurrencySafe: () => false,
    presentCall(args) {
      // 纯函数：已知 framework（非 auto）或自定义 command 时重建真实命令做 terminal 卡片 title；
      // auto 时无法在纯函数里探测，退回 generic 卡片显示意图（不伪造命令）。
      const fw = args.framework || 'auto'
      const custom = typeof args.command === 'string' ? args.command : undefined
      const knownCommand = (fw !== 'auto' || custom) ? buildCommand(fw === 'auto' ? 'node' : fw, args.target, !!args.last_failed, custom) : null
      if (knownCommand) {
        const card = { card: 'terminal', title: knownCommand }
        if (args.workdir) card.description = args.workdir
        return card
      }
      const target = args.target && String(args.target).trim() ? String(args.target).trim() : '(all tests)'
      return { card: 'generic', title: 'test_run · ' + fw + ' · ' + target, kind: 'execute', rawInput: args.target || '' }
    },
    presentResult(args, result) {
      if (result.isError || !result.meta) return undefined
      const meta = result.meta
      const card = { card: 'terminal', output: meta.outputText || '' }
      if (typeof meta.exitCode === 'number') card.exitCode = meta.exitCode
      if (meta.timedOut) card.timedOut = true
      return card
    },
    async execute(args, exec) {
      if (args.timeout_ms !== undefined && (!Number.isFinite(args.timeout_ms) || args.timeout_ms <= 0)) {
        throw new Error('invalid timeout_ms: expected a positive number, got ' + JSON.stringify(args.timeout_ms))
      }
      const workdir = resolveWorkdir(args.workdir, exec)
      const timeoutMs = typeof args.timeout_ms === 'number' && args.timeout_ms > 0 ? args.timeout_ms : 120000
      const lastFailed = !!args.last_failed
      const startedAt = Date.now()

      const fail = (payload) => Object.assign({ ok: false, exitCode: null, timedOut: false, aborted: false, durationMs: Date.now() - startedAt, summary: { total: 0, passed: 0, failed: 0, skipped: 0 }, failures: [], outputTail: '' }, payload)

      let framework = typeof args.framework === 'string' ? args.framework : 'auto'
      if (framework === 'auto') {
        framework = (await detectFramework(workdir)) || ''
        if (!framework) {
          return fail({ framework: 'unknown', error: '无法自动探测测试框架：未找到 vitest/jest 依赖、npm test 脚本、pytest 标记文件或 test 目录。请通过 framework 参数指定，或提供 command 参数自定义命令。' })
        }
      } else if (FRAMEWORKS.indexOf(framework) === -1) {
        return fail({ framework, error: '未知框架: ' + framework + '，可选: ' + FRAMEWORKS.join(' / ') })
      }

      const custom = typeof args.command === 'string' ? args.command : undefined
      const command = buildCommand(framework, args.target, lastFailed, custom)
      if (!command) {
        return fail({ framework, error: '无法为框架 ' + framework + ' 构造命令' })
      }

      let result
      try {
        const request = { command, workdir, timeoutMs, stdoutMaxBytes: 262144, signal: exec.signal }
        const policy = resolveSandboxPolicy(exec, sandboxPolicyService)
        if (policy !== undefined) request.sandboxPolicy = policy
        const spec = shell.resolve(request)
        result = await shell.run(spec)
      } catch (err) {
        throw new Error('test_run 执行失败: ' + (err && err.message ? err.message : String(err)))
      }

      const stdout = result.stdout ? result.stdout.text || '' : ''
      const stderr = result.stderr ? result.stderr.text || '' : ''
      const raw = stdout + (stderr ? '\n[stderr]\n' + stderr : '')
      const parsed = parseOutput(framework, raw)

      let note
      if (lastFailed && (framework === 'node' || framework === 'npm-test')) {
        note = 'last_failed 不被 ' + framework + ' 支持，已忽略并运行全部测试'
      }

      const value = {
        ok: result.exitCode === 0 && !result.timedOut && !result.aborted,
        framework,
        command,
        exitCode: result.exitCode,
        timedOut: !!result.timedOut,
        aborted: !!result.aborted,
        durationMs: Date.now() - startedAt,
        summary: parsed.summary,
        failures: parsed.failures,
        outputTail: raw.slice(-3000),
      }
      if (note) value.note = note
      return value
    },
  }))
}
