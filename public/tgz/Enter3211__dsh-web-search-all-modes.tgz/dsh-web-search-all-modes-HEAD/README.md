# dsh-web-search-all-modes

**简体中文** · [English](./README.en.md)

一个 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) **插件（bundle）**，为所有未内置 `web_search` 工具的 agent 预设恢复该工具——尤其是**极简模式**，该模式默认只带 `bash` 与 `str_replace_editor` 两个工具。

## 为什么需要它

`dsh-base` 会为每个 profile 挂载 Web 服务、DeepSeek 搜索 provider 以及模型侧的 `web_search` 工具。而 `dsh-web-app` 界面会禁用这条宿主工具，改为让每个会话从 **agent 预设**中自行组合工具：

| 预设 | web_search |
|---|---|
| 标准（standard） | ✅ 预设自带 |
| 代码（code / PTC） | ✅ 预设自带 |
| 创造（cordis） | ✅ 预设自带 |
| 极简（minimal） | ❌ 无 |

本插件把宿主的 `tool-web` 行重新打开。自带 `web_search` 的预设不受影响（作用域内的注册会遮蔽全局注册，不会重复）；没有该工具的预设——极简模式，或任何本地编写时省略了 `tool-web` 的预设——会立即获得该工具。

## 安装

本地源码安装：

```sh
dsh plugin --profile web add ./dsh-web-search-all-modes
```

从 GitHub 安装（无构建脚本，无需 pnpm build 授权提示）：

```sh
dsh plugin --profile web add github:Enter3211/dsh-web-search-all-modes
```

安装后重启 Web 进程。之后在极简模式（或任意模式）新建会话，即可在工具目录中看到 `web_search`。

## 环境要求

- profile 基于 `@deepseek-ai/dsh-base` 组合而成（所有官方 profile 均满足）。
- 与标准模式相同的搜索凭据——`DEEPSEEK_API_KEY`，由宿主的 `web-search-deepseek` provider 解析。
- Web 搜索会发起一次独立的模型请求；基础行给每次搜索分配 60 秒预算，并默认 `fetch: false`（`web_fetch` 保持关闭），与标准模式预设级配置一致。

## 注意事项

- 极简预设把 persona 固定为完整系统提示词，因此工具引导提示段在该模式下保持隐藏；但 `web_search` 的工具 schema 仍会出现在目录中并正常工作。
- 补丁按 id 定位 `tool-web` 行。若组合中不存在该行（非 base 部署），加载器会记录一条跳过警告，插件整体不生效（no-op）。

## 许可证

MIT
