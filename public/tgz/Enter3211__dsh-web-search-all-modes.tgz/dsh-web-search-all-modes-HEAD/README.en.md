# dsh-web-search-all-modes

[简体中文](./README.md) · **English**

A [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) **bundle** that restores the model-facing `web_search` tool for every agent preset that lacks its own — most notably the **minimal mode**, which ships with only persistent `bash` and `str_replace_editor`.

## Why this exists

dsh-base mounts the web service, the DeepSeek search provider, and the `web_search` tool for every profile. The web-app surface disables that host tool row and lets each session compose its own tools from an **agent preset**:

| preset | web_search |
|---|---|
| standard | ✅ preset row |
| code / PTC | ✅ preset row |
| cordis | ✅ preset row |
| minimal | ❌ none |

This bundle flips the host `tool-web` row back on. Presets that register their own `web_search` keep it unchanged (scoped registrations shadow the global one, so nothing is duplicated); presets without one — minimal, or any locally authored preset that omits `tool-web` — gain the tool immediately.

## Install

From a local checkout:

```sh
dsh plugin --profile web add ./dsh-web-search-all-modes
```

From GitHub (no build script, so no pnpm build-permission prompt is needed):

```sh
dsh plugin --profile web add github:Enter3211/dsh-web-search-all-modes
```

Then restart the web process. New sessions in minimal mode (or any mode) will see `web_search` in the tool catalog.

## Requirements

- A profile composed from `@deepseek-ai/dsh-base` (every official profile is).
- The same credential standard mode already uses for search — `DEEPSEEK_API_KEY`, resolved by the host `web-search-deepseek` provider.
- Web search performs a separate model request; the base row budgets 60s per search and ships with `fetch: false` (web_fetch stays disabled), matching the preset-level configuration standard mode uses.

## Notes

- The minimal preset fixes its persona as the complete system prompt, so tool-guidance prompt sections stay suppressed there; the `web_search` tool schema still appears in the catalog and works normally.
- The patch targets the `tool-web` row by id. On a composition without that row (a non-base deployment), the loader logs a skip warning and the bundle is a no-op.

## License

MIT
