# dsh-model-auto-enricher — 项目记忆

> 唯一入口。改动记录见 `changelog.md`（覆盖式更新）。

## 它是什么

DSH 插件：一键为 profile 的 `cordis.patch.yml` 里所有模型渠道补齐
百万长上下文 / 多模态发图 / 深度思考档位。写前自动时间戳备份，严格幂等。

## 关键机制（决定怎么改代码）

- **本地 link 安装**：`~/.dsh/profiles/desktop/package.json` 里
  `"dsh-model-auto-enricher": "link:C:\Users\Administrator\Desktop\Ai\20_插件开发\dsh-model-auto-enricher"`，
  node_modules 是 symlink。**改 lib 即改线上**，DSH 重启后生效；无"复制到安装目录"这一步。
- **版本号来源**：运行时 `status` 接口的 `engineVersion` 读的是进程启动时缓存的
  package.json——改版本后不重启 DSH 就会显示旧值，属正常现象。
- **架构分层**：
  `lib/core.js`（setSelfDisabled / runEnrich / inspectConfig，纯逻辑+备份）
  → `lib/index.js`（HTTP 路由，先 sendJson 再延迟触发配置重载）
  → `lib/client.js`（面板 UI，中英 key 内置双语，不走 locale 文件）。
- **patch 层铁律**：`cordis.patch.yml` 的 disabled 行必须保留
  `dsh.profile.bundles` 声明。市场面板"移除 bundle + 写 disabled"会产生
  悬空 override → `no loader entry matched` → 重载中断。本插件的停用必须走
  `POST /api/model-enricher/self-disable`（只写 patch 行）。

## 环境事实

- DSH GUI: `http://127.0.0.1:51000`（2026-10-21 时 PID 17992，20:04:49 启动）
- 状态接口: `GET /api/model-enricher/status`（只读体检）
- 用户 remote: `https://github.com/66rapper/dsh-model-auto-enricher.git`

## 铁律（事故换来的）

1. 重启 DSH 禁用 `taskkill //T` / `//IM`（2026-10-20 曾误杀 DSH 自身）。
   只用 `//PID <GUI端口监听进程>` 或让用户自己重启。
2. 写 cordis.patch.yml 前必有 `.bak-*` 时间戳备份（core.js 已内置，勿拆）。
3. push 到 GitHub 前必须用户点头。

## 展示名硬约束（v2.3.0，糠神明确要求）

- **本插件永不主动写 `models[*].name`（展示名）**，也不写 `id`。
  展示名归用户，由 DSH 设置页「获取可用模型」或手工决定。
- 双保险：`WRITABLE_FIELDS` 白名单（写回时校验）+ `auditImmutableIdentity`
  （写盘前重解析比对）。任何一处被绕过都会抛错中止，不会静默写入。
- 边界：用户点 DSH「获取可用模型」写回的 name，**插件不会删**。要自动清掉
  那是 strip 策略，属另一条需求，糠神明确说不要。

## 当前状态（2026-10-29）

- **v2.3.0**：引擎缺陷修复（非对话模型污染 / self-disable 删不净 / 备份轮转）
  \+ 展示名硬护栏。详见 `changelog.md`。
- 待办：重启 DSH 让新 `core.js` 生效。
