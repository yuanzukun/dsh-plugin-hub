# dsh-model-auto-enricher changelog

## 2026-10-29 v2.3.0 — 展示名硬护栏 + 引擎缺陷修复

**任务链**：糠神先问"展示名不是我想要的"→ 手工删掉 87 个 `name` →
再要求"改插件源码，插件要迭代了"→ 明确"我就是单纯的不要主动写展示名字"。

### v2.2.0 · 引擎真缺陷（全部有实测复现）

1. **P0 非对话模型被污染**：`UNIVERSAL_RULES.thinking` 收裸 `pro`/`max`/`preview`，
   导致 `some-pro-model`、`my-max-tokenizer`、`preview-endpoint` 全被塞思考档位；
   `text-embedding-3-large` 被补 1M 上下文。修法：正则收紧为强特征词白名单，
   `-high$`/`-max$` 用结尾锚定（`` 在 `my-max-tokenizer` 里会误成立）；
   `planModel` 引入 `isNonChat` 全链路短路。
2. **P0 `setSelfDisabled(false)` 删不净**：`for-of` 遍历 filter 快照却 splice 原数组，
   3 条重复 marker 只删掉 2 条 —— 正是本函数当初想规避的 `no loader entry matched`
   隐患。改为先收集后一次性 filter 重建。
3. **P1 规则矩阵两处分叉**：改 `core.js` 后一致性测试当场抓出 CLI 与插件对
   `cn:text-embedding-3-large` 行为不一致。三处规则 + `non-chat` 短路 + 版本号已对齐。
4. **P1 备份无上限**：新增 `pruneBackups`，只轮转 `.bak-auto-enrich-*` 保留 20 个，
   `bak-self-toggle-*` / `bak-removename-*` 等人工留痕一律不动。

### v2.3.0 · 展示名硬护栏（本次核心需求）

需求原话："我就是单纯的不要主动写展示名字" —— **不加 strip/sync 策略开关**，
只把"永不主动写 name"做成代码级硬约束。

- **保险一 · 写回白名单**：`WRITABLE_FIELDS = {contextWindow, maxTokens, input,
  reasoningEfforts}`。写回循环校验，越界抛错整批不写。`name`/`id` 不在名单内。
- **保险二 · 写盘前审计**：`auditImmutableIdentity()` 把即将写出的 YAML 重新解析，
  与写入前逐模型比对 `id`/`name`，有变动即抛错中止（备份已生成、尚未动盘）。
  两种不同机制（内存写回 vs 序列化后重解析），同时被绕过概率极低。

### 验证结果（全绿）

```
白名单          ✅ 不含 name、不含 id、恰好 4 项
7 个模型写回    ✅ 全部不产生 name 字段
已有自定义名    ✅ 原样保留，不删不改
审计 A/B/C/D    ✅ name 删/改都被拦，正常补齐不误伤
真实配置副本    清空 4 项规格 → 补回 → diff = 0，零误报
全量回归        6 组全绿，87 模型全最优，0 改动
```

### 曾怀疑但已证伪的三个假问题

| 怀疑 | 实测结果 |
|---|---|
| 删 `name` 后系列识别失效 | 正则无 `^` 锚定，`cn:` 前缀不影响，`kimi`/`glm`/`hunyuan` 全命中 |
| `yaml.dump` 破坏手写格式 | 注入缺口→补齐→与原文件 diff **0 行**，逐字节一致 |
| 二次写入产生漂移 | `--dry-run` 报"0 处改动、字节未变、未生成备份" |

### 行为边界（明确记录）

| 场景 | 插件行为 |
|---|---|
| 模型无 name，补齐四项 | 补齐后仍无 name |
| 模型已有 name | 原样保留 |
| 用户点 DSH「获取可用模型」写回 name | 插件**不删**（DSH 行为，不归插件管） |
| 未来给 changes 加 name | 白名单抛错，整批不写 |
| 未来绕过白名单动 model.name | 写盘审计抛错，原文件不受影响 |

> 「插件不删 DSH 写回的 name」是当前唯一需用户手动处理的场景。要做自动清掉那是
> strip 策略，属另一条需求，本次明确不做。

### 改动文件

- `lib/core.js`：+186/−16（`WRITABLE_FIELDS`、`auditImmutableIdentity`、`pruneBackups`、
  `isNonChat` 短路、`setSelfDisabled` 重建、`ENGINE_VERSION` → 2.3.0）
- `package.json`：2.1.0 → 2.3.0
- `~/.dsh/tools/model-enricher/model-enricher.mjs`：三处规则同步 + `non-chat` 短路 +
  白名单 + 写盘审计 + 版本号对齐

### 生效

插件为软链安装（`node_modules/dsh-model-auto-enricher` → 源码目录），改源码即改插件。
**需重启 DSH** 让 Host 端 `core.js` 重新加载。


## 2026-10-21 v2.1.0 — 安全停用通道正式入库

**任务**：用户指令"更新我的DSH插件，注意安全"。上次会话（10-20）写的
安全停用功能一直未提交，本次完成审查 → 提交 → 发版。

**做了什么**：

1. 全量配置备份 `dsh-config-20261021-203935-dba258.zip`（3.1MB，无明文凭据）。
2. 审查未提交改动（273 行，三个文件 + 两个 README）：
   - `lib/core.js`：新增 `setSelfDisabled(disabled, {file})` —— 只写
     `cordis.patch.yml` patch 行（`{id, disabled}`），绝不动
     `dsh.profile.bundles`。含 `pureMarker` 清理分支（恢复启用时把纯标记行
     整行删掉）与 `.bak-self-toggle-*` 时间戳备份。
   - `lib/index.js`：新路由 `POST /api/model-enricher/self-disable`，
     先 `sendJson` 再 `setTimeout` 触发配置重载（停用时本插件会被卸载，
     必须让响应先出去）。
   - `lib/client.js`：两段式确认 UI —— 第一击只"武装"（disableButton→
     disableConfirm），第二击才执行；中英提示内置双语，不走 locale。
3. `node --check` 三文件全过；提交 `0cbf882`。
4. `package.json` 2.0.0 → **2.1.0**（`e85f692`）。
5. 新增 `MEMORY.md`（项目记忆）+ 本 changelog。

**生效判定**：DSH 现进程 17992 于 20:04:49 启动，晚于 lib 最后修改
（10-20 15:59）→ v2.1.0 代码**已在线运行**，无需重启。
`status` 接口显示 `engineVersion: 2.0.0` 是启动时缓存的旧版本号，属正常。

**为什么"安全停用"必须存在**：市场面板停用插件 = 移除 bundle 声明 +
写 patch disabled 行。bundle 移除后 patch 行失去匹配目标 →
`no loader entry matched` → 重载中断。本插件只写 patch 行，永远可恢复。

**未做 / 等用户**：push GitHub（领先 origin 2 提交）；重启 DSH 刷新
版本号显示（非必需）。

**安全措施记录**：全程只读验证 + git 提交，未触碰 profile 配置文件，
未重启任何进程。

## 2026-10-20 v2.0.0 — 功能版（上次会话）

- runEnrich 引擎 + self-disable 前后端 + README 重写（61e5b2f…4c18dc2 三个提交）。
- 真机实测留痕：profiles 下 `.bak-self-toggle-20261020-155918/160003/160029`。
