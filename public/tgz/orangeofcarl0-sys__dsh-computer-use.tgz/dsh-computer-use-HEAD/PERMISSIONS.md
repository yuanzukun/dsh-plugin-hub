# PERMISSIONS — dsh-computer-use

本文件声明 `dsh-computer-use` 插件在运行时实际使用的权限面（DSH STORE 审查依据）。

## 总览（运行时行为）

- 通过**宿主 `child_process.spawn` 以非 shell 固定 argv** 调用 `cua-driver` 原生驱动（跨平台：macOS / Windows / Linux），驱动本地桌面：
- Windows 附加 spawn（0.5.3）：`powershell.exe` 固定 argv 执行随包脚本 `tools/uia-password-scan.ps1`——UIA 结构性密码扫描（IsPassword ∨ ES_PASSWORD 样式位），幂等只读、无网络、无文件写；`passwordScan: 'off'` 可关闭：
  - 屏幕观测：`screen_observe` / `screen_zoom`（读取被观测应用的 Accessibility/AX 树与窗口快照）
  - 虚拟鼠标键盘模拟：`computer_click` / `computer_double_click` / `computer_right_click` / `computer_type` / `computer_key` / `computer_scroll` / `computer_drag` / `computer_wait`
  - 应用枚举与启动：`app_list` / `app_launch`
- `cua-driver` 可执行文件来源：环境变量 `CUA_DRIVER_BIN` 显式指定，或 `PATH` 查找；缺失时返回结构化错误（含自救指引），不静默。
- 内置安全姿态（**无感自治**，0.4.0）：动作**零审批、零打断**（危险词审批网关已删除），归因靠全量投递注记 + harness 会话日志；**凭据硬保护**（密码框拒绝自动输入）是唯一硬拒绝；**极危注记**（`extremePatterns` 配置命中 → 结果附警告，不阻断，默认空）；**兜底护栏**：快照 TTL 过期拒绝、无快照拒绝、`allowedApps` 作用域白名单（默认空 = 关闭）。
- 观测/投递能力默认全开（自动提权）：窗口级观测失败自动降级桌面级采集（视觉仅读、坐标系=桌面像素，不产生窗口级可执行坐标）；AX 树为空标注 `visualOnly`；结果附驱动权限面探测（`check_permissions`，只读）；投递链后台不可用时自动升级并恢复原前台。
- 本插件不改变真实 OS 权限边界：Windows 管理员窗口边界、macOS TCC 授权仍由操作系统决定。

## 承诺验证矩阵（承诺 × 平台 × 载体）

> 安全承诺必须按平台实测，"代码看起来对"不算数。✅ = 已验证；▒ = 离线覆盖、无运行时实测；unverified = 无环境。变更任何承诺必须同步更新本表并固化验证载体（smoke 或探针）。

| 承诺 | Windows | macOS | Linux | 验证载体 |
|---|---|---|---|---|
| 凭据硬保护（密码框拒自动输入） | ✅ 结构位（0.5.3 起：UIA sidecar IsPassword ∨ ES_PASSWORD 实测标记；启发式为降级路径；结构性上游投影待 [#3576](https://github.com/trycua/cua/issues/3576)） | ✅ AX 结构化角色 | unverified | posture.smoke G/H 系列 + A6 探针 |
| 极危注记（不阻断） | ✅ | ✅ | ✅ | posture.smoke |
| allowedApps 作用域白名单 | ✅ | ✅ | ✅ | posture.smoke |
| 快照 TTL / 无快照拒绝 | ✅ | ✅ | ✅ | posture.smoke / delivery-chain |
| 三级投递链 + 恢复原前台 | ✅ 实测 | ▒ | ▒ | delivery-chain.smoke |
| 强杀锁存（stop/resume） | ✅ 离线 | ▒ | ▒ | tools.smoke |
| 验证 unknown ≠ 成功 | ✅ | ▒ | ▒ | tools.smoke |

## 明确不做

- ❌ 不读取任何用户文件 / 项目文件（无 `fs` 读写）
- ❌ 不发起任何网络请求（无 fetch / http / WebSocket）
- ❌ 不访问用户 / 项目文件；不读取任何密钥**文件**（0.5.1 起移除家目录密钥文件扫描）
- ⚠️ 环境变量读取：`ZHIPU_API_KEY` / `GLM_API_KEY`（仅 GLM 视觉兜底这一可选特性；未配置则该路径停用）+ `CUA_DRIVER_BIN`（定位可执行文件）
- ❌ 不在宿主写入任何文件
- ❌ 无 npm 生命周期脚本（install / postinstall 等一律没有；安装包内的 `install.sh` / `uninstall.sh` 是给用户手动执行的安装辅助脚本，非 npm lifecycle）
- ❌ 不触碰真实鼠标键盘焦点（独立虚拟光标，隔离运行，不抢占用户输入）

## 依赖（仅两个，均为官方/DSH 生态）

| 依赖 | 用途 |
|---|---|
| `@deepseek-ai/dsh-tools` | 注册 dsh 原生工具（`ctx.tools.register(defineTool(...))`） |
| `@deepseek-ai/schemastery` | 工具参数 schema 定义 |

## 权限信号对照（STORE 五信号）

| 信号 | 状态 | 说明 |
|---|---|---|
| 文件权限 | ⚠️ 命中 | `spawn` 子进程（cua-driver）是核心能力，属真实插件必备，提交人工审查 |
| 命令权限 | ⚠️ 命中 | `spawn` 仅限固定 argv：`cua-driver` 与随包 `tools/uia-password-scan.ps1`（Windows 结构性密码扫描，只读），非 shell（`shell: false`），无 `exec` / `eval` |
| 网络权限 | ✅ 未命中 | 无任何网络调用 |
| 凭据权限 | ⚠️ 轻微命中（可选） | GLM 视觉兜底读取 `ZHIPU_API_KEY` / `GLM_API_KEY` 环境变量（未配置即停用）；不读取任何密钥文件；`CUA_DRIVER_BIN` 仅用于定位可执行文件 |
| 生命周期脚本 | ✅ 无 | npm 元数据中无 install/postinstall/prepare |

完整安装/启动/卸载证据见 `docs/store-evidence.md`。