#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""论文引用工具：从 PDF 里「划词」或「截图」，产出可直接粘进 Markdown 笔记的片段。

设计目标（DSH 增强器的地基，两条路共用）：
    1. 笔记是**纯 Markdown**，任何编辑器都能读；
    2. 引用片段带**回链**，点击能跳回 PDF 的对应页；
    3. 机器可读的精确位置（页码 + 矩形）放在 HTML 注释里，
       人看不见、Markdown 渲染不受影响，未来的 DSH 面板可以从注释里读出矩形做精确高亮。

回链格式（已定型，改动需同步 Memory）：
    [↗ p.3](zotero://open-pdf/library/items/<附件KEY>?page=3)
    <!-- dsh-paper item=<条目KEY> att=<附件KEY> page=3 rect="x0,y0,x1,y1" kind=clip|quote -->
    · 用 `zotero://` 是因为用户保留 Zotero：**今天就能点开跳到原文**；
      将来 DSH 面板接管时，读同一条注释即可精确跳转，不必改笔记。

用法：
    # 1) 划词：把某句话截成引用（自动在页面上定位）
    pixi run clip -- --item KGT7BATD --page 3 --quote "当思考充足时" --note notes/demo.md

    # 2) 截图：按 PDF 坐标裁一块（原点左上，单位 point）
    pixi run clip -- --item KGT7BATD --page 3 --rect 72,120,523,300 --note notes/demo.md

    # 3) 整页截图 / 导出该文已有标注
    pixi run clip -- --item KGT7BATD --page 1 --page-image --print
    pixi run clip -- --item KGT7BATD --annotations --note notes/demo.md

    # 4) 直接给 PDF 路径（不走索引）
    pixi run clip -- --pdf "zotero/storage/KYRYSVZE/xxx.pdf" --page 1 --page-image --print
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
from pathlib import Path

# Windows 控制台默认是 GBK，直接 print 中文/特殊符号会 UnicodeEncodeError 崩溃。
# 这里强制 stdout/stderr 用 UTF-8 并容错，脚本在任何终端都不会因为打印而失败。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
    except (AttributeError, ValueError):
        pass

WORKSPACE = Path(__file__).resolve().parent.parent
INDEX_JSON = WORKSPACE / "zotero_index.json"
NOTES_DIR = WORKSPACE / "notes"
ASSETS_DIR = NOTES_DIR / "assets"

ZOTERO_PDF_URI = "zotero://open-pdf/library/items/{att}?page={page}"
REF_COMMENT = '<!-- dsh-paper item={item} att={att} page={page} rect="{rect}" kind={kind} -->'

# 荧光笔颜色（RGB 0–1）。名字被宿主路由与客户端共用，改这里要同步 dsh-plugins/paper/lib/index.js
HIGHLIGHT_COLORS: dict[str, tuple[float, float, float]] = {
    "yellow": (1.00, 0.85, 0.15),
    "green": (0.45, 0.90, 0.40),
    "blue": (0.40, 0.70, 1.00),
    "pink": (1.00, 0.50, 0.72),
    "orange": (1.00, 0.68, 0.30),
    "purple": (0.68, 0.52, 1.00),
}


def add_pdf_highlight(pdf_path: Path, page_index: int, rects: list[tuple[float, float, float, float]],
                      color: str) -> str:
    """把高亮**写进 PDF 文件本身**（增量保存）。

    关键：接收的是**逐行矩形列表**（多行选区会有多个），用 quads 一次性画成一条高亮标注。
    早期版本只传「整个选区的外接矩形」，多行段落会把无关行也框进去 —— 高亮因此很不准。

    安全措施：首次修改某个 PDF 前，先备份一份 `<名字>.dsh-orig.pdf`；增量保存只追加，不改写已有内容。
    """
    import fitz

    backup = pdf_path.with_name(pdf_path.stem + ".dsh-orig.pdf")
    if not backup.exists():
        shutil.copy2(pdf_path, backup)

    doc = fitz.open(str(pdf_path))
    try:
        page = doc[page_index - 1]
        quads = [fitz.Rect(r) for r in rects]
        annot = page.add_highlight_annot(quads=quads)
        rgb = HIGHLIGHT_COLORS.get(color, HIGHLIGHT_COLORS["yellow"])
        annot.set_colors(stroke=rgb)
        annot.set_info(title="DSH Paper", content=color)
        annot.update()
        doc.save(str(pdf_path), incremental=True, encryption=fitz.PDF_ENCRYPT_KEEP)
    finally:
        doc.close()
    return str(backup) if backup.exists() else ""


def load_index(path: Path) -> dict:
    if not path.is_file():
        raise SystemExit(
            f"找不到索引 {path}；先运行：pixi run zindex"
        )
    return json.loads(path.read_text(encoding="utf-8"))


def find_item(index: dict, key: str) -> dict:
    for rec in index["records"]:
        if rec["key"].lower() == key.lower():
            return rec
    raise SystemExit(f"索引里找不到条目 key={key}")


def pick_pdf(rec: dict) -> tuple[str, str]:
    """返回 (附件KEY, PDF 绝对路径)。优先挑磁盘上存在的 PDF。"""
    pdfs = [a for a in rec["attachments"] if a["contentType"] == "application/pdf"]
    for a in pdfs:
        if a.get("exists"):
            return a["key"], a["absPath"]
    if pdfs:
        raise SystemExit(
            f"条目 {rec['key']} 的 PDF 附件在磁盘上不存在：{pdfs[0]['absPath']}"
        )
    raise SystemExit(f"条目 {rec['key']} 没有 PDF 附件")


def slugify(text: str, limit: int = 40) -> str:
    text = re.sub(r"\s+", "-", text.strip())
    text = re.sub(r"[^\w\-\u4e00-\u9fff]", "", text)
    return (text[:limit] or "clip").strip("-")


def locate_quote(page, quote: str, nth: int) -> "object":
    """在页面上定位一句话，返回 Rect。先精确搜索，失败则按行块模糊匹配。"""
    hits = page.search_for(quote)
    if hits:
        return hits[min(nth, len(hits) - 1)]

    # 模糊兜底：把引文切成片段，取命中最多的那个文本块
    probe = re.sub(r"\s+", "", quote)[:20]
    best, best_score = None, 0
    for block in page.get_text("blocks"):
        x0, y0, x1, y1, text = block[0], block[1], block[2], block[3], block[4]
        flat = re.sub(r"\s+", "", text)
        score = sum(1 for i in range(0, max(0, len(probe) - 3), 3) if probe[i:i + 4] in flat)
        if score > best_score:
            best, best_score = (x0, y0, x1, y1), score
    if best is None:
        raise SystemExit(f"在页面上找不到引文：{quote[:40]}…")
    return best


def render_clip(page, rect, out_path: Path, dpi: int, pad: float = 6.0) -> None:
    import fitz  # PyMuPDF

    x0, y0, x1, y1 = rect
    clip = fitz.Rect(
        max(0, x0 - pad), max(0, y0 - pad),
        min(page.rect.x1, x1 + pad), min(page.rect.y1, y1 + pad),
    )
    pix = page.get_pixmap(clip=clip, dpi=dpi)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    pix.save(str(out_path))
    return clip


def parse_rect(text: str) -> tuple[float, float, float, float]:
    parts = [p for p in re.split(r"[,\s]+", text.strip()) if p]
    if len(parts) != 4:
        raise SystemExit("--rect 需要 4 个数字：x0,y0,x1,y1")
    return tuple(float(p) for p in parts)  # type: ignore[return-value]


def note_header(rec: dict) -> str:
    authors = ", ".join(rec["creators"][:6]) or "未知作者"
    lines = [
        "---",
        f"zotero-key: {rec['key']}",
        f"title: {rec['title']}",
        f"year: {rec['year']}",
        f"doi: {rec.get('doi', '')}",
        "---",
        "",
        f"# {rec['title']}",
        "",
        f"- 作者：{authors}",
        f"- 年份：{rec['year']}　类型：{rec['type']}",
    ]
    if rec.get("publication"):
        lines.append(f"- 来源：{rec['publication']}")
    if rec.get("collections"):
        lines.append(f"- 集合：{' / '.join(rec['collections'][:3])}")
    lines += ["", "## 精读笔记", ""]
    return "\n".join(lines) + "\n"


def append_to_note(note_path: Path, snippet: str, rec: dict | None) -> None:
    if note_path.is_file():
        existing = note_path.read_text(encoding="utf-8")
        note_path.write_text(existing.rstrip() + "\n\n" + snippet + "\n", encoding="utf-8")
    else:
        note_path.parent.mkdir(parents=True, exist_ok=True)
        head = note_header(rec) if rec else ""
        note_path.write_text(head + "\n" + snippet + "\n", encoding="utf-8")


def build_link(pdf_path: Path | None, page_no: int, att: str, mode: str = "auto") -> str:
    """按 PDF 的位置决定回链形式。

    · Zotero 库内（`.../storage/<附件KEY>/xxx.pdf`）→ `zotero://` 协议链接，点击直接跳到 Zotero 原文；
    · 其他位置（如 `paper_orin/`）→ DSH 认得的**文件链接** `<路径#L页码>`：
      `primitives.parseFileLink` 只接受 `#L<数字>` 这一种 fragment，所以页码写在 `#L` 后面。
    """
    resolved = mode
    if mode == "auto":
        resolved = "zotero" if (att and pdf_path and "storage" in pdf_path.parts) else "file"
    if resolved == "zotero" and att:
        return ZOTERO_PDF_URI.format(att=att, page=page_no)
    if pdf_path:
        return f"<{pdf_path}#L{page_no}>"
    return ""


def quote_snippet(quote: str, page_no: int, link: str, att: str, item: str, rect_s: str,
                  image_rel: str | None, label: str = "") -> str:
    head = f"> [!quote] p.{page_no}" + (f" · [↗ 跳回原文]({link})" if link else "")
    lines = [
        head,
        "> " + quote.strip().replace("\n", " "),
        "",
        REF_COMMENT.format(item=item, att=att, page=page_no, rect=rect_s, kind="quote"),
    ]
    if image_rel:
        lines += ["", f"![{label or f'原文位置（p.{page_no}）'}]({image_rel})"]
    return "\n".join(lines)


def clip_snippet(label: str, page_no: int, link: str, att: str, item: str, rect_s: str, image_rel: str) -> str:
    tail = f"> 截图来源：p.{page_no}" + (f" · [↗ 跳回原文]({link})" if link else "")
    return "\n".join([
        f"![{label}]({image_rel})",
        "",
        tail,
        REF_COMMENT.format(item=item, att=att, page=page_no, rect=rect_s, kind="clip"),
    ])


def annotations_snippet(rec: dict) -> str:
    """把该条目已有的 Zotero 标注导出成 Markdown。"""
    anns = rec.get("annotations") or []
    if not anns:
        return f"（条目 {rec['key']} 没有标注）"
    pdfs = [a for a in rec["attachments"] if a["contentType"] == "application/pdf"]
    att = pdfs[0]["key"] if pdfs else ""
    lines = [f"## 已有标注（{len(anns)} 条，来自 Zotero）", ""]
    for i, an in enumerate(sorted(anns, key=lambda a: (a.get("page") or "", a.get("type") or "")), 1):
        page_no = int(re.sub(r"\D", "", str(an.get("page") or "1")) or 1)
        link = ZOTERO_PDF_URI.format(att=att, page=page_no)
        lines.append(f"**{i}. [{an['type']}] p.{an.get('page') or '?'}** · [↗]({link})")
        if an.get("text"):
            lines.append(f"> {an['text']}")
        if an.get("comment"):
            lines.append(f"> 批注：{an['comment']}")
        lines.append("")
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description="PDF 划词/截图 → Markdown 引用片段")
    src = ap.add_argument_group("来源")
    src.add_argument("--item", help="Zotero 条目 key（从 zotero_index.json 解析 PDF）")
    src.add_argument("--pdf", help="直接指定 PDF 路径（跳过索引）")
    src.add_argument("--index", default=str(INDEX_JSON), help="索引 JSON 路径")

    what = ap.add_argument_group("截取方式（多选一）")
    what.add_argument("--quote", help="划词：引文（自动在页面上定位）")
    what.add_argument("--quote-text", help="划词：直接给出文字（客户端已选中，不要求能定位到）")
    what.add_argument("--rect", help="截图：PDF 坐标 x0,y0,x1,y1（原点左上，单位 point）")
    what.add_argument("--rect-norm", help="截图：归一化坐标 fx0,fy0,fx1,fy1（0–1，抗缩放，供客户端框选用）")
    what.add_argument("--rects-norm", help="划词高亮：**逐行**归一化矩形，多行用分号分隔，如 a,b,c,d;e,f,g,h（这样多行选区不会框进无关行）")
    what.add_argument("--page-image", action="store_true", help="整页截图")
    what.add_argument("--highlight", choices=sorted(HIGHLIGHT_COLORS),
                      help="把该区域作为荧光高亮**写进 PDF 文件本身**（增量保存；首次修改会先备份 .dsh-orig.pdf）")
    what.add_argument("--annotations", action="store_true", help="导出该条目已有 Zotero 标注")

    opt = ap.add_argument_group("选项")
    opt.add_argument("--page", type=int, default=1, help="页码，从 1 开始")
    opt.add_argument("--nth", type=int, default=0, help="--quote 命中多处时取第几个（0 起）")
    opt.add_argument("--dpi", type=int, default=200, help="截图分辨率")
    opt.add_argument("--label", default="", help="图片 alt 文本")
    opt.add_argument("--note", help="写入的笔记文件（不存在则按模板创建）")
    opt.add_argument("--assets-dir", default=str(ASSETS_DIR), help="图片输出根目录")
    opt.add_argument("--no-image", action="store_true", help="只写文字，不生成截图")
    opt.add_argument("--external-image", help="使用已存在的图片（客户端从已渲染画布裁好的 PNG），不再自行渲染")
    opt.add_argument("--link-mode", choices=["auto", "zotero", "file"], default="auto",
                     help="回链形式：auto=Zotero 库内用 zotero://，否则用文件链接")
    opt.add_argument("--print", action="store_true", help="把片段打印到 stdout")
    args = ap.parse_args()

    rec = None
    att = ""
    if args.pdf:
        pdf_path = Path(args.pdf)
        if not pdf_path.is_absolute():
            pdf_path = WORKSPACE / pdf_path
        if not pdf_path.is_file():
            raise SystemExit(f"找不到 PDF：{pdf_path}")
        item_key = args.item or pdf_path.parent.name
        att = args.item or pdf_path.parent.name
    else:
        if not args.item and not args.pdf:
            raise SystemExit("需要 --item 或 --pdf")
        index = load_index(Path(args.index))
        rec = find_item(index, args.item)
        att, pdf_abs = pick_pdf(rec)
        pdf_path = Path(pdf_abs)
        item_key = rec["key"]

    # 标注导出不需要打开 PDF
    if args.annotations:
        if rec is None:
            raise SystemExit("--annotations 需要 --item")
        snippet = annotations_snippet(rec)
        if args.note:
            append_to_note(Path(args.note), snippet, rec)
        if args.print or not args.note:
            print(snippet)
        return 0

    import fitz

    doc = fitz.open(str(pdf_path))
    if not (1 <= args.page <= doc.page_count):
        raise SystemExit(f"页码 {args.page} 超出范围（该 PDF 共 {doc.page_count} 页）")
    page = doc[args.page - 1]

    quote_text = args.quote_text or args.quote
    rects: list[tuple[float, float, float, float]] = []

    def to_points(group: str) -> tuple[float, float, float, float]:
        f = parse_rect(group)
        return (f[0] * page.rect.x1, f[1] * page.rect.y1, f[2] * page.rect.x1, f[3] * page.rect.y1)

    if args.rects_norm:
        rects = [to_points(g) for g in args.rects_norm.split(";") if g.strip()]
    elif args.rect:
        rects = [parse_rect(args.rect)]
    elif args.rect_norm:
        rects = [to_points(args.rect_norm)]
    elif args.page_image:
        rects = [(0.0, 0.0, page.rect.x1, page.rect.y1)]
    elif quote_text:
        try:
            rects = [locate_quote(page, quote_text, args.nth)]
        except SystemExit:
            # 客户端给的文字可能因断行/连字符/软换行定位不到 —— 不该阻塞写笔记
            rects = []
    elif args.external_image:
        rects = []  # 图已由客户端裁好，不需要坐标

    rect_s = ";".join(",".join(f"{v:.1f}" for v in r) for r in rects)
    # 图片用所有行的并集
    rect = (
        (min(r[0] for r in rects), min(r[1] for r in rects),
         max(r[2] for r in rects), max(r[3] for r in rects))
        if rects else None
    )

    # 只要"有内容可写"就继续：引文定位不到也应写进笔记（客户端给的文字可能带断行/连字符）
    if not rects and not args.page_image and not args.annotations and not args.external_image and not quote_text:
        raise SystemExit("需要 --quote / --quote-text / --rect / --rect-norm / --rects-norm / --page-image / --external-image / --annotations 之一")

    link = build_link(pdf_path, args.page, att, args.link_mode)

    # 可选：把高亮写进 PDF 文件本身（增量保存）
    highlight_backup = ""
    if args.highlight:
        if not rects:
            raise SystemExit("--highlight 需要能确定位置：配合 --rects-norm / --rect-norm / --page-image 使用")
        highlight_backup = add_pdf_highlight(pdf_path, args.page, rects, args.highlight)
        print(f"[clip] highlight {args.highlight} -> {pdf_path}（{len(rects)} 段）")
        if highlight_backup:
            print(f"[clip] 原始 PDF 备份 -> {highlight_backup}")

    # 图片必须用「相对笔记文件」的路径，否则笔记一移动/一换机器图片就断链
    note_path = Path(args.note).resolve() if args.note else None
    note_dir = note_path.parent if note_path else WORKSPACE

    image_rel = None
    out_png_abs = None
    if args.external_image:
        # 客户端已从渲染画布裁好图并落盘，这里只负责把它写进笔记
        out_png_abs = Path(args.external_image).resolve()
        if not out_png_abs.is_file():
            raise SystemExit(f"找不到外部图片：{out_png_abs}")
        image_rel = (out_png_abs.relative_to(note_dir).as_posix()
                     if out_png_abs.is_relative_to(note_dir) else out_png_abs.as_posix())
    elif rect is not None and not args.no_image:
        stem = f"p{args.page}-{slugify(quote_text or args.label or 'clip', 36)}"
        out_png = Path(args.assets_dir) / item_key / f"{stem}.png"
        render_clip(page, rect, out_png, args.dpi)
        out_png_abs = Path(out_png).resolve()
        image_rel = (out_png_abs.relative_to(note_dir).as_posix()
                     if out_png_abs.is_relative_to(note_dir) else out_png_abs.as_posix())

    if quote_text:
        snippet = quote_snippet(quote_text, args.page, link, att, item_key, rect_s, image_rel,
                                label=args.label or f"原文位置（p.{args.page}）")
    elif image_rel:
        snippet = clip_snippet(args.label or f"p.{args.page} 截图", args.page, link, att, item_key, rect_s, image_rel)
    else:
        raise SystemExit("既没有文字也没有图片可写")

    if note_path:
        append_to_note(note_path, snippet, rec)
        if out_png_abs:
            print(f"[clip] image -> {out_png_abs}")
        print(f"[clip] note  -> {note_path}")
    if args.print or not note_path:
        print(snippet)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
