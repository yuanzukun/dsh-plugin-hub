import { test } from "node:test";
import assert from "node:assert/strict";
import { merge3 } from "../lib/merge.js";

const NOTE = "# T\n\n## 精读笔记\n\n## 摘录与截图\n\n> a\n\n*p.1*\n";

test("unchanged sides return the other side verbatim", () => {
  assert.deepEqual(merge3(NOTE, NOTE, NOTE), { text: NOTE, conflict: false });
  const mine = NOTE.replace("## 精读笔记\n", "## 精读笔记\n\n我的想法\n");
  assert.deepEqual(merge3(NOTE, mine, NOTE), { text: mine, conflict: false });
  assert.deepEqual(merge3(NOTE, NOTE, mine), { text: mine, conflict: false });
});

test("user edits one section while the plugin appends to another", () => {
  const mine = NOTE.replace("## 精读笔记\n", "## 精读笔记\n\n**Transformer** 只用注意力\n");
  const theirs = `${NOTE}\n> b\n\n*p.2 · 绿色高亮*\n`;
  const { text, conflict } = merge3(NOTE, mine, theirs);
  assert.equal(conflict, false);
  assert.equal(text, `${mine}\n> b\n\n*p.2 · 绿色高亮*\n`);
});

test("both sides inserting at the same place keeps both (mine first)", () => {
  const mine = `${NOTE}\nmine\n`;
  const theirs = `${NOTE}\ntheirs\n`;
  const { text, conflict } = merge3(NOTE, mine, theirs);
  assert.equal(conflict, false);
  assert.equal(text, `${NOTE}\nmine\n\ntheirs\n`);
});

test("identical edits on both sides are not a conflict", () => {
  const edited = NOTE.replace("> a\n", "> a!\n");
  assert.deepEqual(merge3(NOTE, edited, edited), { text: edited, conflict: false });
});

test("different edits to the same line conflict and keep the file untouched", () => {
  const mine = NOTE.replace("> a\n", "> mine\n");
  const theirs = NOTE.replace("> a\n", "> theirs\n");
  assert.equal(merge3(NOTE, mine, theirs).conflict, true);
});

test("deletion on one side merges with an edit elsewhere", () => {
  const mine = NOTE.replace("> a\n\n*p.1*\n", "");
  const theirs = NOTE.replace("# T\n", "# Title\n");
  const { text, conflict } = merge3(NOTE, mine, theirs);
  assert.equal(conflict, false);
  assert.equal(text, mine.replace("# T\n", "# Title\n"));
});

test("CRLF line endings and a missing final newline survive byte for byte", () => {
  const base = "a\r\nb\r\nc";
  const mine = "a\r\nB\r\nc";
  const theirs = "a\r\nb\r\nc\r\nd";
  const { text, conflict } = merge3(base, mine, theirs);
  assert.equal(conflict, false);
  assert.equal(text, "a\r\nB\r\nc\r\nd");
});

test("empty base and large unrelated middles fall back without crashing", () => {
  assert.deepEqual(merge3("", "x\n", ""), { text: "x\n", conflict: false });
  const big = (tag) => Array.from({ length: 3000 }, (_, i) => `${tag}${i}\n`).join("");
  const base = `head\n${big("b")}tail\n`;
  const result = merge3(base, `head\n${big("m")}tail\n`, `head\n${big("t")}tail\n`);
  assert.equal(result.conflict, true);
});
