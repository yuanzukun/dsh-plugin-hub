import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, mkdirSync, writeFileSync, symlinkSync, utimesSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, basename } from "node:path";
import { scanLibrary } from "../lib/library.js";

function fixture() {
  const root = mkdtempSync(join(tmpdir(), "pf-lib-"));
  const touch = (rel, mtimeSec) => {
    const file = join(root, rel);
    mkdirSync(join(file, ".."), { recursive: true });
    writeFileSync(file, "%PDF-1.4\n");
    if (mtimeSec) utimesSync(file, mtimeSec, mtimeSec);
    return file;
  };
  touch("a/Older Paper.pdf", 1000);
  touch("Newer.PDF", 2000);
  touch("node_modules/pkg/x.pdf");
  touch(".hidden/y.pdf");
  touch("notes/Older-Paper/z.pdf");
  touch("d1/d2/d3/d4/d5/too-deep.pdf");
  touch("a/readme.txt");
  mkdirSync(join(root, "outside"), { recursive: true });
  symlinkSync(join(root, "a"), join(root, "linked"));
  // 笔记：Older Paper 有笔记与 2 条高亮
  const noteDir = join(root, "notes", "Older-Paper");
  writeFileSync(join(noteDir, "Older-Paper.md"), "# x\n");
  writeFileSync(join(noteDir, "highlights.json"), JSON.stringify([{ page: 1 }, { page: 2 }]));
  return root;
}

const notePathsFor = (root) => (pdf) => {
  const slug = basename(pdf).replace(/\.pdf$/i, "").replace(/\s+/g, "-");
  const dir = join(root, "notes", slug);
  return { note: join(dir, `${slug}.md`), highlights: join(dir, "highlights.json") };
};

test("scanLibrary lists PDFs newest first, skipping tool dirs, dot dirs, notes, symlinks and deep files", () => {
  const root = fixture();
  const papers = scanLibrary(root, { notesDir: "notes", notePathsFor: notePathsFor(root) });
  assert.deepEqual(papers.map((p) => p.rel), ["Newer.PDF", "a/Older Paper.pdf"]);
  const older = papers[1];
  assert.equal(older.title, "Older Paper");
  assert.equal(older.dir, "a");
  assert.equal(older.path, join(root, "a", "Older Paper.pdf"));
  assert.equal(older.hasNote, true);
  assert.equal(older.highlights, 2);
  assert.equal(papers[0].hasNote, false);
  assert.equal(papers[0].highlights, 0);
  assert.equal(papers[0].dir, "");
  assert.ok(papers[0].mtime > older.mtime);
});

test("scanLibrary honours maxDepth and limit", () => {
  const root = fixture();
  const deep = scanLibrary(root, { notesDir: "notes", notePathsFor: notePathsFor(root), maxDepth: 6 });
  assert.ok(deep.some((p) => p.rel === "d1/d2/d3/d4/d5/too-deep.pdf"));
  const one = scanLibrary(root, { notesDir: "notes", notePathsFor: notePathsFor(root), limit: 1 });
  assert.equal(one.length, 1);
});

test("scanLibrary tolerates a broken highlights.json", () => {
  const root = fixture();
  writeFileSync(join(root, "notes", "Older-Paper", "highlights.json"), "{oops");
  const papers = scanLibrary(root, { notesDir: "notes", notePathsFor: notePathsFor(root) });
  assert.equal(papers.find((p) => p.title === "Older Paper").highlights, 0);
});
