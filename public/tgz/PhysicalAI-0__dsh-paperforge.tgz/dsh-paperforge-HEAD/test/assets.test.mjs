import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, mkdirSync, mkdtempSync, symlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { sweepAssets } from "../lib/assets.js";

function fixture() {
  const root = mkdtempSync(join(tmpdir(), "pf-assets-"));
  const paper = join(root, "Paper");
  mkdirSync(join(paper, "assets"), { recursive: true });
  mkdirSync(join(root, "汇总"), { recursive: true });
  for (const name of ["used.png", "used by guide.png", "summary.png", "orphan.png", "bak-only.png"]) writeFileSync(join(paper, "assets", name), "x");
  writeFileSync(join(paper, "assets", "notes.txt"), "not an image");
  writeFileSync(join(paper, "Paper.md"), "# P\n\n![p.1 截图](assets/used.png)\n");
  writeFileSync(join(paper, "图解.md"), '<img src="assets/used%20by%20guide.png">\n');
  writeFileSync(join(root, "汇总", "s.md"), "![fig](<../Paper/assets/summary.png>)\n");
  writeFileSync(join(paper, "Paper.md.bak"), "![old](assets/bak-only.png)\n");
  return { root, assets: join(paper, "assets"), state: new Map() };
}

test("only images no markdown references are deleted, and only after the grace period", () => {
  const { root, assets, state } = fixture();
  const first = sweepAssets(root, { now: 0, graceMs: 1000, state });
  assert.deepEqual(first.deleted, []);
  assert.deepEqual(first.pending.map((p) => p.split(/[\\/]/).pop()).sort(), ["bak-only.png", "orphan.png"]);
  const second = sweepAssets(root, { now: 1500, graceMs: 1000, state });
  assert.deepEqual(second.deleted.map((p) => p.split(/[\\/]/).pop()).sort(), ["bak-only.png", "orphan.png"]);
  for (const kept of ["used.png", "used by guide.png", "summary.png", "notes.txt"]) assert.ok(existsSync(join(assets, kept)), kept);
});

test("an image referenced again within the grace period survives (cut and paste)", () => {
  const { root, assets, state } = fixture();
  writeFileSync(join(root, "Paper", "Paper.md"), "# P\n");
  sweepAssets(root, { now: 0, graceMs: 1000, state });
  writeFileSync(join(root, "Paper", "Paper.md"), "# P\n\n![p.1 截图](assets/used.png)\n");
  sweepAssets(root, { now: 500, graceMs: 1000, state });
  sweepAssets(root, { now: 5000, graceMs: 1000, state });
  assert.ok(existsSync(join(assets, "used.png")));
});

test("symlinks and a missing notes root are left alone", () => {
  const { root, assets, state } = fixture();
  symlinkSync(join(assets, "orphan.png"), join(assets, "link.png"));
  sweepAssets(root, { now: 0, graceMs: 0, state });
  const result = sweepAssets(root, { now: 1, graceMs: 0, state });
  assert.ok(!result.deleted.some((p) => p.endsWith("link.png")));
  assert.deepEqual(sweepAssets(join(root, "nope"), { now: 0, state }), { deleted: [], pending: [] });
});
