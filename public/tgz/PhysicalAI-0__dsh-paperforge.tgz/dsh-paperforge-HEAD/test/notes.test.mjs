import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  noteTemplate, formatHighlight, formatFigure, formatQuote, insertEntry, migrateLegacy, ensureNoteFile, appendEntry,
} from "../lib/notes.js";

test("template links the PDF with an angle-bracket destination and has the two sections", () => {
  const md = noteTemplate({ title: "A Paper", pdfRelFromNote: "../../My Paper.pdf" });
  assert.equal(md, "# A Paper\n\n原文：[My Paper.pdf](<../../My Paper.pdf>)\n\n## 精读笔记\n\n## 摘录与截图\n");
});

test("highlight: whitespace collapsed, line-break hyphens joined, page/colour caption", () => {
  assert.equal(
    formatHighlight({ text: "a sim-\n ple  baseline", page: 3, color: "green" }),
    "> a simple baseline\n\n*p.3 · 绿色高亮*",
  );
  assert.equal(formatHighlight({ text: "x", page: 1, color: "unknown" }), "> x\n\n*p.1 · 高亮*");
});

test("quote: blockquote with a page caption", () => {
  assert.equal(formatQuote({ text: "a\n b", page: 7 }), "> a b\n\n*p.7*");
});

test("figure: relative image plus caption", () => {
  assert.equal(formatFigure({ imageRel: "assets/p4-fig-1.png", page: 4 }), "![p.4 截图](assets/p4-fig-1.png)\n\n*p.4 · 截图*");
});

test("insertEntry appends inside 摘录与截图, before the next heading", () => {
  const md = "# T\n\n## 摘录与截图\n\n> old\n\n## 我的总结\n\nmine\n";
  assert.equal(insertEntry(md, "> new"), "# T\n\n## 摘录与截图\n\n> old\n\n> new\n\n## 我的总结\n\nmine\n");
});

test("insertEntry into an empty trailing section and into a note without the section", () => {
  assert.equal(insertEntry("# T\n\n## 摘录与截图\n", "> x"), "# T\n\n## 摘录与截图\n\n> x\n");
  assert.equal(insertEntry("# T\n", "> x"), "# T\n\n## 摘录与截图\n\n> x\n");
});

const LEGACY = [
  "# Sample Paper",
  "",
  '<!-- dsh-paper-source pdf="Sample Paper.pdf" -->',
  "",
  "- 本地 PDF：[Sample Paper.pdf](../../Sample Paper.pdf)",
  "- 图片放在本文件夹的 `assets/` 下",
  "",
  "## 精读笔记",
  "",
  "## 引用与截图",
  "",
  "## 与 AI 的问答",
  "",
  "> [!quote] p.1 · [↗ 跳回原文](</home/u/Sample Paper.pdf#L1>)",
  "> first quoted line",
  "",
  '<!-- dsh-paper item=ws att=ws page=1 rect="58.5,451.0" kind=quote -->',
  "",
  "![p.1 截图](assets/p1-fig-1.png)",
  "",
  "> 截图来源：p.1 · [↗ 跳回原文](</home/u/Sample Paper.pdf#L1>)",
  '<!-- dsh-paper item=ws att=ws page=1 rect="" kind=clip -->',
  "",
].join("\n");

test("migrateLegacy produces the new clean format", () => {
  const { markdown, changed } = migrateLegacy(LEGACY);
  assert.equal(changed, true);
  assert.equal(markdown, [
    "# Sample Paper",
    "",
    "原文：[Sample Paper.pdf](<../../Sample Paper.pdf>)",
    "",
    "## 精读笔记",
    "",
    "## 摘录与截图",
    "",
    "> first quoted line",
    "",
    "*p.1*",
    "",
    "![p.1 截图](assets/p1-fig-1.png)",
    "",
    "*p.1 · 截图*",
    "",
  ].join("\n"));
});

test("migrateLegacy joins line-break hyphens inside migrated quotes only", () => {
  const legacy = "## 引用与截图\n\n> [!quote] p.2 · [↗ 跳回原文](</a.pdf#L2>)\n> a sim- ple exam- ple\n\nstate-of-the-art stays\n";
  const { markdown } = migrateLegacy(legacy);
  assert.match(markdown, /^> a simple example$/m);
  assert.match(markdown, /^state-of-the-art stays$/m);
});

test("migrateLegacy leaves clean notes untouched", () => {
  const clean = noteTemplate({ title: "T", pdfRelFromNote: "../../t.pdf" });
  assert.deepEqual(migrateLegacy(clean), { markdown: clean, changed: false });
});

test("ensureNoteFile creates once, migrates legacy with a single backup, appendEntry inserts", () => {
  const root = mkdtempSync(join(tmpdir(), "pf-notes-"));
  const dir = join(root, "notes", "paper");
  const paths = { dir, note: join(dir, "paper.md"), assets: join(dir, "assets") };
  const pdfPath = join(root, "paper.pdf");
  assert.deepEqual(ensureNoteFile(paths, { title: "paper", pdfPath }), { created: true, migrated: false });
  assert.ok(existsSync(paths.assets));
  assert.match(readFileSync(paths.note, "utf8"), /原文：\[paper\.pdf\]\(<\.\.\/\.\.\/paper\.pdf>\)/);
  assert.deepEqual(ensureNoteFile(paths, { title: "paper", pdfPath }), { created: false, migrated: false });

  writeFileSync(paths.note, LEGACY, "utf8");
  assert.deepEqual(ensureNoteFile(paths, { title: "paper", pdfPath }), { created: false, migrated: true });
  assert.equal(readFileSync(paths.note + ".bak", "utf8"), LEGACY);
  writeFileSync(paths.note, LEGACY.replace("first quoted line", "second legacy"), "utf8");
  ensureNoteFile(paths, { title: "paper", pdfPath });
  assert.equal(readFileSync(paths.note + ".bak", "utf8"), LEGACY, "backup is written only once");

  appendEntry(paths, formatHighlight({ text: "new quote", page: 2, color: "blue" }));
  const final = readFileSync(paths.note, "utf8");
  assert.match(final, /\*p\.1 · 截图\*\n\n> new quote\n\n\*p\.2 · 蓝色高亮\*\n$/);
  assert.doesNotMatch(final, /<!--|\[!quote\]/);
});
