import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, mkdirSync, readFileSync, symlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createMarkdown, guardMarkdownPath, saveMarkdown, MAX_MARKDOWN_BYTES } from "../lib/markdown-file.js";

function fixture() {
  const root = mkdtempSync(join(tmpdir(), "pf-md-"));
  const ws = join(root, "ws");
  const outside = join(root, "outside");
  mkdirSync(ws);
  mkdirSync(outside);
  const note = join(ws, "note.md");
  writeFileSync(note, "# T\n\n## 精读笔记\n\n## 摘录与截图\n");
  return { root, ws, outside, note };
}

test("guard accepts markdown inside a root and rejects everything else", () => {
  const { ws, outside, note } = fixture();
  assert.equal(guardMarkdownPath(note, [ws]).ok, true);
  writeFileSync(join(ws, "a.txt"), "x");
  writeFileSync(join(outside, "o.md"), "x");
  writeFileSync(join(ws, "big.md"), "x".repeat(MAX_MARKDOWN_BYTES + 1));
  symlinkSync(join(outside, "o.md"), join(ws, "escape.md"));
  const cases = {
    "relative path": "note.md",
    "not markdown": join(ws, "a.txt"),
    "outside every root": join(outside, "o.md"),
    "missing file": join(ws, "missing.md"),
    "symlink escaping the root": join(ws, "escape.md"),
    "too large": join(ws, "big.md"),
    "a directory": ws,
  };
  for (const [label, path] of Object.entries(cases)) {
    assert.equal(guardMarkdownPath(path, [ws]).ok, false, label);
  }
  assert.equal(guardMarkdownPath(note, []).ok, false, "no roots means nothing is writable");
});

test("save writes directly when the disk still matches base", () => {
  const { ws, note } = fixture();
  const base = readFileSync(note, "utf8");
  const text = base.replace("## 精读笔记\n", "## 精读笔记\n\n我的想法\n");
  const result = saveMarkdown({ path: note, base, text }, [ws]);
  assert.equal(result.status, 200);
  assert.deepEqual({ ok: result.body.ok, merged: result.body.merged, text: result.body.text }, { ok: true, merged: false, text });
  assert.equal(readFileSync(note, "utf8"), text);
});

test("save merges with a concurrent append instead of overwriting it", () => {
  const { ws, note } = fixture();
  const base = readFileSync(note, "utf8");
  writeFileSync(note, `${base}\n> 插件追加的高亮\n`);
  const mine = base.replace("## 精读笔记\n", "## 精读笔记\n\n我的想法\n");
  const result = saveMarkdown({ path: note, base, text: mine }, [ws]);
  assert.equal(result.status, 200);
  assert.equal(result.body.merged, true);
  const disk = readFileSync(note, "utf8");
  assert.equal(disk, `${mine}\n> 插件追加的高亮\n`);
  assert.equal(result.body.text, disk);
});

test("a real conflict leaves the file untouched; force overwrites", () => {
  const { ws, note } = fixture();
  const base = readFileSync(note, "utf8");
  const theirs = base.replace("# T\n", "# Theirs\n");
  writeFileSync(note, theirs);
  const mine = base.replace("# T\n", "# Mine\n");
  const conflict = saveMarkdown({ path: note, base, text: mine }, [ws]);
  assert.equal(conflict.status, 409);
  assert.deepEqual({ conflict: conflict.body.conflict, text: conflict.body.text }, { conflict: true, text: theirs });
  assert.equal(readFileSync(note, "utf8"), theirs);
  const forced = saveMarkdown({ path: note, base, text: mine, force: true }, [ws]);
  assert.equal(forced.status, 200);
  assert.equal(readFileSync(note, "utf8"), mine);
});

test("save rejects bad input without touching the file", () => {
  const { ws, note } = fixture();
  const before = readFileSync(note, "utf8");
  assert.equal(saveMarkdown({ path: note, base: before }, [ws]).status, 400);
  assert.equal(saveMarkdown({ path: note, base: before, text: "x".repeat(MAX_MARKDOWN_BYTES + 1) }, [ws]).status, 413);
  assert.equal(saveMarkdown({ path: "note.md", base: before, text: "x" }, [ws]).status, 400);
  assert.equal(readFileSync(note, "utf8"), before);
});

test("create makes the folder, never overwrites, and stays inside the roots", () => {
  const { ws, outside } = fixture();
  const first = createMarkdown({ workspace: ws, folder: "notes/汇总", name: "2026-09-29-2个会话", content: "# A\n" }, [ws]);
  assert.equal(first.status, 200);
  assert.equal(first.body.rel, "notes/汇总/2026-09-29-2个会话.md");
  assert.equal(readFileSync(first.body.path, "utf8"), "# A\n");
  const second = createMarkdown({ workspace: ws, folder: "notes/汇总", name: "2026-09-29-2个会话", content: "# B\n" }, [ws]);
  assert.equal(second.body.rel, "notes/汇总/2026-09-29-2个会话-2.md");
  assert.equal(readFileSync(first.body.path, "utf8"), "# A\n", "the first file is untouched");
  assert.equal(createMarkdown({ workspace: outside, folder: "notes", name: "x", content: "" }, [ws]).status, 403);
  const sneaky = createMarkdown({ workspace: ws, folder: "../outside", name: "../../x/y", content: "" }, [ws]);
  assert.equal(sneaky.status, 200);
  assert.ok(sneaky.body.path.startsWith(ws), "dot segments are dropped, not followed");
  assert.equal(createMarkdown({ workspace: "ws", folder: "notes", name: "x", content: "" }, [ws]).status, 400);
});
