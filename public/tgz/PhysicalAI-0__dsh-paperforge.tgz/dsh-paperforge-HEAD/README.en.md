<div align="center">

<img src="docs/images/logo.png" width="480" alt="PaperForge: watercolor paper pages, chat bubbles and a fountain pen">

<h3>Read papers in DSH: read, ask and take notes in one place</h3>

<p>
<a href="#quick-start">Quick start</a> ·
<a href="#highlights">Highlights</a> ·
<a href="#todo">TODO</a> ·
<a href="./AGENTS.md">Developer handbook</a> ·
<a href="./README.md">简体中文</a>
</p>

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE) [![DSH Plugin](https://img.shields.io/badge/DSH-plugin-4f46e5)](https://github.com/topics/dsh-plugin) [![DSH](https://img.shields.io/badge/DSH-0.1.7%2B-6366f1)](https://github.com/deepseek-ai/deepseek-harness) [![Repo](https://img.shields.io/badge/github-PhysicalAI--0%2Fdsh--paperforge-181717?logo=github)](https://github.com/PhysicalAI-0/dsh-paperforge)

</div>

**Understand the paper. Keep your own thinking.** Open a PDF from the paper library to bring the paper, its dedicated AI session and your Markdown notes side by side. Select a difficult passage to ask AI with the context included; highlight key text or capture a figure, and your highlights and screenshots go straight into local notes. Come back to the paper and pick up where your thinking left off.

<a id="news"></a>

## <img src="docs/images/icons/news.png" width="48" height="32" alt=""> News

- **2026-09-29**
  - Native multi-column reading layout: session list on the left, the paper's AI session in the middle, PDF｜notes on the right.
  - Added session Summary and Copy path; notes now live in `paperforge_notes`, and images no longer referenced by any note are cleaned up.
  - Block-level Markdown editing: every `.md` is editable in place, with autosave.
  - Reading flow rebuilt: paper library, live notes preview, one dedicated AI session per paper.
- **2026-09-28** — First release; installs through DSH's native `dsh plugin` command.

<a id="highlights"></a>

## <img src="docs/images/icons/highlights.png" width="48" height="32" alt=""> Highlights

![Reading layout: session list on the left, the paper's AI session in the middle, PDF and notes on the right](docs/images/en/reading.png)

<table>
  <tr>
    <td width="33%" valign="top"><b>Paper library</b><br><b>Papers</b> in the left sidebar lists the PDFs in your workspace; pick one to open the reading layout</td>
    <td width="33%" valign="top"><b>Annotate</b><br>Highlights (six colours) and region screenshots are saved to your notes automatically; selections can also be copied as plain text or Markdown quotes</td>
    <td width="33%" valign="top"><b>Ask AI</b><br><b>Ask AI</b> on a selection or <b>AI</b> in the PDF header opens the paper's session; questions about a selection include <code>@paper</code>, the page number and the passage</td>
  </tr>
  <tr>
    <td valign="top"><b>Markdown editing</b><br>Every <code>.md</code> is editable in place: click a block to edit its source, leave to render it; autosaves and merges with changes from the plugin or the AI</td>
    <td valign="top"><b>Summary</b><br>Tick sessions on the library's <b>Sessions</b> tab to produce one Summary in Markdown: referenced three at a time, then combined</td>
    <td valign="top"><b>Copy path</b><br>The copy icon in any document header copies the file's path in one click</td>
  </tr>
</table>

<table>
  <tr>
    <td width="34%" align="center" valign="top"><img src="docs/images/en/editor.png" alt="Click a block to edit its source; the rest stays rendered"><br><sub>Notes: click any block to edit its source</sub></td>
    <td width="66%" align="center" valign="top"><img src="docs/images/en/summary.png" alt="Summary: the AI writes a summary of several sessions into Markdown"><br><sub>Summary: the AI combines the ticked sessions into one Markdown file</sub></td>
  </tr>
</table>

<sub>Paper pages in the screenshots are from Vaswani et al., <i>Attention Is All You Need</i> (arXiv:1706.03762), reproduced with attribution for scholarly use as Google permits. The logo and section icons were generated with an AI image model.</sub>

<a id="quick-start"></a>

## <img src="docs/images/icons/quick-start.png" width="48" height="32" alt=""> Quick start

Requirements: DSH `0.1.7+` and `pnpm` on your PATH.

```bash
dsh plugin --profile web add github:PhysicalAI-0/dsh-paperforge
# or install from a local clone (code changes take effect after restarting dsh web):
git clone https://github.com/PhysicalAI-0/dsh-paperforge.git && cd dsh-paperforge
dsh plugin --profile web add .
```

Start `dsh web` in the folder that holds your papers (that folder must also be a DSH workspace). A **Papers** entry in the left sidebar means it's installed. Uninstall: `dsh plugin --profile web remove dsh-paperforge`.

<a id="notes"></a>

## <img src="docs/images/icons/notes.png" width="48" height="32" alt=""> Where notes go

```text
<papers folder>/paperforge_notes/
├─ <paper>/<paper>.md                       notes (standard Markdown, editable in place)
├─ <paper>/assets/                          captures; images not referenced by any note are removed after about 2 minutes
├─ <paper>/highlights.json, session.json    highlight positions, link to the paper's session
└─ Summary/                                 session summaries
```

<a id="config"></a>

## <img src="docs/images/icons/config.png" width="48" height="32" alt=""> Configuration (optional)

Override by id in `~/.dsh/profiles/web/cordis.patch.yml`:

```yaml
- id: paperforge
  config:
    workspaceRoot: <absolute path to your papers folder>  # defaults to the folder dsh web starts in
    notesDir: paperforge_notes          # notes root folder (older versions used notes)
    model:                              # model for paper sessions; omit to keep your current model
      provider: deepseek-official
      name: deepseek-flash
      reasoningEffort: high
```

Don't use `- insert:` (the plugin would load twice). When `model` is set, DSH also saves it as the default model for new sessions.

<a id="todo"></a>

## <img src="docs/images/icons/todo.png" width="48" height="32" alt=""> TODO

- [ ] Instant-rendering Markdown (Vditor-style): click an image to zoom, drag blocks to reorder
- [ ] Rich rendering: mermaid flowcharts / sequence diagrams / Gantt charts, echarts, mind maps
- [ ] Several sessions for the same paper (the **AI** header button)
- [ ] Tools and a skill for reading papers by page and by figure, cutting the token cost of reading figures
- [ ] Write key Q&A points back into the notes automatically
- [ ] Pure JavaScript: replace the Python sidecar with `mupdf`; make the library scan asynchronous

<a id="limitations"></a>

## <img src="docs/images/icons/limitations.png" width="48" height="32" alt=""> Known limitations

- The right sidebar has at most two panes (a DSH limit); float extra windows out.
- Before its first question, a paper session shows as "New session" in the left list, and DSH's "New session" may reuse it.
- Markdown is edited block by block: undo covers only the current block; reference-style links and footnotes defined in another block may not resolve; a `.md` outside the workspaces or over 2 MB is preview-only.
- Summary: DSH references at most three sessions per message, so the plugin sends batches; the AI writes the result with its file-writing tool.
- PDFs with the same file name in different folders share one notes folder; section headings in the notes are always Chinese.

<a id="development"></a>

## <img src="docs/images/icons/development.png" width="48" height="32" alt=""> Development

```bash
pixi run test     # unit tests
pixi run verify   # contract and smoke tests
```

The plugin has two halves: the browser half `lib/client.js` and the host half `lib/index.js` and friends (registering the `/api/paper.*` routes), plus an optional Python sidecar `py/` used only to write highlights into the PDF file itself. Read [`AGENTS.md`](./AGENTS.md) (in Chinese) before developing: it covers the hard constraints on DSH plugins, the key APIs, the pitfalls hit so far and the roadmap.

<a id="thanks"></a>

## <img src="docs/images/icons/thanks.png" width="48" height="32" alt=""> Background and acknowledgement

The author is a heavy user of [alphaXiv](https://www.alphaxiv.org/), which inspired this plugin's "ask about a selection, take notes in place" interaction. Its Q&A allowance is limited and its model can't be swapped, so this brings the "select → ask → note" loop into DSH, an environment you fully control: no new reader, just DSH's native preview, sessions and model configuration.

<sub>PaperForge is not affiliated with, sponsored by or endorsed by alphaXiv or its team, and contains none of its code or assets.</sub>

<a id="license"></a>

## <img src="docs/images/icons/license.png" width="48" height="32" alt=""> License

[MIT](./LICENSE) © dsh-paperforge contributors
