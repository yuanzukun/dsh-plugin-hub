/**
 * DSH Paper 插件 · 真实执行测试（不是语法检查）
 *
 * 目的：在没有浏览器的情况下，把两个半真的跑起来，验证：
 *   宿主半  → apply(ctx) 是否注册了 3 条路由、路径/方法是否正确、是否抛错
 *   客户端半 → factory 能否执行、apply(ctx) 是否注册插槽、浮层安装是否抛错
 *
 * 用法：node dsh-plugins/paper/verify.mjs（或 `pixi run verify`）
 */

/* 路径全部从本文件位置推导 —— 不写死任何用户名 / 盘符 / 安装位置，便于分发。 */
import { fileURLToPath, pathToFileURL } from "node:url";
import { dirname, join, resolve } from "node:path";
import { tmpdir } from "node:os";

const PLUGIN_DIR = dirname(fileURLToPath(import.meta.url));
/* 测试用工作区：**默认落在系统临时目录**，所以本套件：
 *   ① 不依赖宿主的 monorepo 结构（clone 到任何地方都能跑）；
 *   ② 不在仓库里留下 paperforge_notes/ 等测试产物。
 * 需要针对真实工作区跑时，设 DSH_PAPER_WORKSPACE 即可。 */
const WORKSPACE =
  process.env.DSH_PAPER_WORKSPACE || join(tmpdir(), "dsh-paperforge-verify");
const HOST_ENTRY = join(PLUGIN_DIR, "lib", "index.js");
const CLIENT_ENTRY = join(PLUGIN_DIR, "lib", "client.js");

const results = [];
const ok = (name, extra = "") => results.push(["OK  ", name, extra]);
const bad = (name, extra = "") => results.push(["FAIL", name, extra]);

/* ------------------------------------------------------------------ *
 * 1. 宿主半
 * ------------------------------------------------------------------ */
async function testHost() {
  let mod;
  try {
    mod = await import(pathToFileURL(HOST_ENTRY).href);
  } catch (error) {
    bad("宿主半 import", String(error));
    return;
  }
  ok("宿主半 import", `exports=[${Object.keys(mod).join(",")}]`);

  if (typeof mod.apply !== "function") {
    bad("宿主半 apply 是函数");
    return;
  }
  ok("宿主半 apply 是函数");
  ok("宿主半 inject", JSON.stringify(mod.inject));

  const routes = [];
  const errors = [];
  const ctx = {
    effect(fn, label) {
      try {
        const disposer = fn();
        if (typeof disposer !== "function") errors.push(`effect(${label}) 未返回 disposer`);
      } catch (error) {
        errors.push(`effect(${label}) 抛错：${String(error)}`);
      }
    },
    connection: {
      fetch: {
        register(route) {
          routes.push(route);
          return async () => {};
        },
      },
    },
  };

  try {
    mod.apply(ctx, { workspaceRoot: WORKSPACE });
  } catch (error) {
    bad("宿主半 apply() 执行", String(error));
    return;
  }
  ok("宿主半 apply() 执行");

  const expected = [
    "/api/paper.note", "/api/paper.clip", "/api/paper.highlights", "/api/paper.library",
    "/api/paper.session", "/api/paper.log", "/api/paper.diag", "/api/paper.health", "/api/paper.md.save",
    "/api/paper.summary.create",
  ];
  for (const path of expected) {
    const hit = routes.find((r) => r.path === path);
    if (!hit) bad(`路由 ${path}`);
    else if (hit.methods[0] !== "POST") bad(`路由 ${path} 方法`, JSON.stringify(hit.methods));
    else if (typeof hit.fetch !== "function") bad(`路由 ${path} fetch`);
    else ok(`路由 ${path}`, `POST, body=${hit.requestBody}`);
  }
  if (errors.length) bad("宿主半 effect 错误", errors.join(" | "));

  // 干净机器上测试工作区还不存在：先建好 notes/（handleLog 与下面的夹具都写在里面）
  (await import("node:fs")).mkdirSync(join(WORKSPACE, "paperforge_notes"), { recursive: true });

  // 真的发一个请求给 /api/paper.log，验证 handler 能跑通（写文件）
  const logRoute = routes.find((r) => r.path === "/api/paper.log");
  if (logRoute) {
    try {
      const response = await logRoute.fetch(
        new Request("http://127.0.0.1/api/paper.log", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ event: "verify", detail: "宿主半 handler 自测" }),
        }),
      );
      const payload = await response.json();
      ok("handleLog 实跑", `status=${response.status} ok=${payload.ok}`);
    } catch (error) {
      bad("handleLog 实跑", String(error));
    }
  }

  // 校验路径守卫：工作区外的 pdf 必须被拒
  const clipRoute = routes.find((r) => r.path === "/api/paper.clip");
  if (clipRoute) {
    try {
      const response = await clipRoute.fetch(
        new Request("http://127.0.0.1/api/paper.clip", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ mode: "quote", pdf: "C:\\Windows\\notepad.exe", text: "x" }),
        }),
      );
      const payload = await response.json();
      if (response.status === 400 && !payload.ok) ok("路径越界被拒", payload.error);
      else bad("路径越界应被拒", `status=${response.status}`);
    } catch (error) {
      bad("路径守卫测试", String(error));
    }
  }

  // 每个 handler 都真跑一遍：能抓到"用了没导入的标识符"这类**运行时**错误。
  // 本插件历史上就因为 `appendFileSync` / `readdirSync` 未导入而整半崩溃（node --check 抓不到）。
  // 先保证夹具存在（`notes/_diag.pdf` 是插件诊断通道的载体，属于插件产物）。
  const fixture = join(WORKSPACE, "paperforge_notes", "_diag.pdf");
  try {
    const fs = await import("node:fs");
    if (!fs.existsSync(fixture)) {
      fs.writeFileSync(
        fixture,
        "%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n" +
          "2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n" +
          "3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 200 200]>>endobj\n" +
          "trailer<</Root 1 0 R>>\n%%EOF\n",
        "utf8",
      );
    }
  } catch (error) {
    bad("创建测试夹具", String(error));
  }
  const smoke = [
    ["/api/paper.health", {}],
    ["/api/paper.session", { pdf: fixture, action: "get" }],
    ["/api/paper.highlights", { pdf: fixture }],
    ["/api/paper.diag", { stage: "verify", detail: "验证套件冒烟测试" }],
  ];
  smoke.push(["/api/paper.library", {}]);
  for (const [path, body] of smoke) {
    const route = routes.find((r) => r.path === path);
    if (!route) {
      bad(`smoke ${path}`);
      continue;
    }
    try {
      const response = await route.fetch(
        new Request(`http://127.0.0.1${path}`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(body),
        }),
      );
      const payload = await response.json();
      if (response.status === 200 && payload.ok) ok(`smoke ${path}`, `status=${response.status}`);
      else bad(`smoke ${path}`, `status=${response.status} ${JSON.stringify(payload).slice(0, 160)}`);
    } catch (error) {
      bad(`smoke ${path}`, String(error));
    }
  }
}

/* 高亮真实写入：笔记必须是干净的 Markdown（无 HTML 注释 / callout），并按章节插入 */
async function testClipWritesCleanNote() {
  const fs = await import("node:fs");
  const mod = await import(pathToFileURL(HOST_ENTRY).href);
  const routes = {};
  mod.apply({ effect: (fn) => fn(), connection: { fetch: { register: (r) => { routes[r.path] = r.fetch; return () => {}; } } } }, { workspaceRoot: WORKSPACE });
  const pdf = join(WORKSPACE, "paperforge_notes", "_diag.pdf");
  const post = async (path, body) => {
    const res = await routes[path](new Request(`http://127.0.0.1${path}`, { method: "POST", body: JSON.stringify(body) }));
    return { status: res.status, ...(await res.json()) };
  };
  const hl = await post("/api/paper.clip", { mode: "highlight", pdf, page: 1, text: "verify  quote", rects: ["0.1,0.1,0.2,0.2"], color: "green" });
  if (hl.status !== 200 || !hl.ok) return bad("高亮写入笔记", JSON.stringify(hl).slice(0, 160));
  const note = fs.readFileSync(hl.note, "utf8");
  if (/<!--|\[!quote\]/.test(note)) bad("笔记为干净 Markdown", "含 HTML 注释或 callout");
  else if (!/## 摘录与截图\n[\s\S]*> verify quote\n\n\*p\.1 · 绿色高亮\*/.test(note)) bad("高亮按章节写入笔记", note.slice(-120));
  else ok("高亮写入干净笔记（按章节）", hl.noteRel);
  const img = await post("/api/paper.clip", { mode: "image", pdf, page: 1, data: Buffer.from("not a png at all, just text......").toString("base64") });
  if (img.status === 400) ok("非 PNG 图片被拒", img.error);
  else bad("非 PNG 图片应被拒", `status=${img.status}`);
}

/* Markdown 编辑器保存：直写、与并发追加合并、真冲突不写盘、工作区外拒绝 */
async function testMarkdownSave() {
  const fs = await import("node:fs");
  const mod = await import(pathToFileURL(HOST_ENTRY).href);
  const routes = {};
  mod.apply({ effect: (fn) => fn(), connection: { fetch: { register: (r) => { routes[r.path] = r.fetch; return () => {}; } } } }, { workspaceRoot: WORKSPACE });
  const post = async (body) => {
    const res = await routes["/api/paper.md.save"](new Request("http://127.0.0.1/api/paper.md.save", { method: "POST", body: JSON.stringify(body) }));
    return { status: res.status, ...(await res.json()) };
  };
  const file = join(WORKSPACE, "paperforge_notes", "_editor.md");
  const base = "# T\n\n## 精读笔记\n\n## 摘录与截图\n";
  fs.writeFileSync(file, base);
  const mine = base.replace("## 精读笔记\n", "## 精读笔记\n\n**我的想法**\n");
  const direct = await post({ path: file, base, text: mine });
  if (direct.status === 200 && fs.readFileSync(file, "utf8") === mine) ok("编辑器保存：直写");
  else bad("编辑器保存：直写", JSON.stringify(direct).slice(0, 160));
  fs.writeFileSync(file, `${mine}\n> 插件追加\n`);
  const next = mine.replace("# T\n", "# Title\n");
  const merged = await post({ path: file, base: mine, text: next });
  if (merged.status === 200 && merged.merged && fs.readFileSync(file, "utf8") === `${next}\n> 插件追加\n`) ok("编辑器保存：与并发追加合并");
  else bad("编辑器保存：与并发追加合并", JSON.stringify(merged).slice(0, 160));
  const disk = fs.readFileSync(file, "utf8");
  const conflict = await post({ path: file, base: mine, text: mine.replace("# T\n", "# Other\n") });
  if (conflict.status === 409 && conflict.conflict && fs.readFileSync(file, "utf8") === disk) ok("编辑器保存：真冲突不写盘");
  else bad("编辑器保存：真冲突不写盘", JSON.stringify(conflict).slice(0, 160));
  const outside = await post({ path: join(PLUGIN_DIR, "README.md"), base: "", text: "x" });
  if (outside.status === 403 && outside.code === "outside") ok("编辑器保存：工作区外拒绝", outside.error);
  else bad("编辑器保存：工作区外拒绝", `status=${outside.status}`);
  fs.rmSync(file, { force: true });

  const summaryRes = await routes["/api/paper.summary.create"](
    new Request("http://127.0.0.1/api/paper.summary.create", { method: "POST", body: JSON.stringify({ workspace: WORKSPACE, name: "verify-2个会话", title: "Summary · 2 个会话" }) }),
  );
  const summary = await summaryRes.json();
  if (summaryRes.status === 200 && summary.rel === "paperforge_notes/Summary/verify-2个会话.md" && fs.readFileSync(summary.path, "utf8").startsWith("# Summary · 2 个会话")) ok("会话 Summary：新建占位 md", summary.rel);
  else bad("会话 Summary：新建占位 md", JSON.stringify(summary).slice(0, 160));
  if (summary.path) fs.rmSync(summary.path, { force: true });
}

/* ------------------------------------------------------------------ *
 * 2. 客户端半
 * ------------------------------------------------------------------ */
function makeElement(tag = "div") {
  const el = {
    tagName: tag,
    style: {},
    attributes: {},
    children: [],
    textContent: "",
    value: "",
    __listeners: [],
    setAttribute(k, v) {
      this.attributes[k] = v;
    },
    getAttribute(k) {
      return this.attributes[k] ?? null;
    },
    appendChild(child) {
      this.children.push(child);
      child.parentElement = this;
      return child;
    },
    removeChild(child) {
      this.children = this.children.filter((c) => c !== child);
      return child;
    },
    remove() {
      if (this.parentElement) this.parentElement.removeChild(this);
    },
    addEventListener(type, fn) {
      this.__listeners.push([type, fn]);
    },
    removeEventListener() {},
    contains() {
      return false;
    },
    querySelector() {
      return null;
    },
    querySelectorAll() {
      return [];
    },
    getBoundingClientRect() {
      return { left: 0, top: 0, right: 100, bottom: 100, width: 100, height: 100 };
    },
    focus() {},
    select() {},
    closest() {
      return null;
    },
  };
  return el;
}

async function testClient() {
  const fs = await import("node:fs");
  const source = fs.readFileSync(CLIENT_ENTRY, "utf8");

  // 客户端 bundle 必须是可拼接的普通脚本：不能有顶层 import/export
  if (/^\s*(import|export)\s/m.test(source)) bad("客户端 bundle 无顶层 import/export");
  else ok("客户端 bundle 无顶层 import/export");

  const documentListeners = [];
  const head = makeElement("head");
  const body = makeElement("body");
  const doc = {
    head,
    body,
    createElement: makeElement,
    querySelector: () => null,
    querySelectorAll: () => [],
    addEventListener(type, fn) {
      documentListeners.push([type, fn]);
    },
    removeEventListener() {},
    execCommand: () => true,
    baseURI: "http://127.0.0.1:4090/",
  };

  const win = {
    innerWidth: 1400,
    addEventListener() {},
    setTimeout,
    clearTimeout,
    setInterval,
    clearInterval,
    crypto: { randomUUID: () => "uuid-test" },
    getComputedStyle: () => ({ position: "relative" }),
  };

  let registration = null;
  win.__ModuleLoader__ = {
    load(reg) {
      registration = reg;
    },
  };

  const consoleErrors = [];
  const fakeConsole = {
    info() {},
    warn() {},
    error(...args) {
      consoleErrors.push(args.map(String).join(" "));
    },
  };

  // 浏览器全局的最小替身：MutationObserver 只需能 observe/disconnect
  globalThis.MutationObserver ??= class { observe() {} disconnect() {} };
  try {
    // eslint-disable-next-line no-new-func
    new Function("window", "document", "navigator", "fetch", "getComputedStyle", "console", source)(
      win,
      doc,
      { clipboard: { writeText: async () => {} } },
      async () => ({ json: async () => ({ ok: true }) }),
      () => ({ position: "relative" }),
      fakeConsole,
    );
  } catch (error) {
    bad("客户端 bundle 执行", String(error));
    return;
  }
  ok("客户端 bundle 执行（factory 注册）");

  if (!registration) {
    bad("__ModuleLoader__.load 被调用");
    return;
  }
  if (registration.id !== "dsh-paperforge") bad("bundle id 与包名一致", registration.id);
  else ok("bundle id 与包名一致");
  if (typeof registration.factory !== "function") {
    bad("factory 是函数");
    return;
  }
  ok("factory 是函数");

  const React = {
    useState: (initial) => [initial, () => {}],
    createElement: (type, props, ...children) => ({ type, props, children }),
    memo: (component) => component,
  };
  const jsxRuntime = { jsx: (type, props) => ({ type, props }), jsxs: (type, props) => ({ type, props }), Fragment: "Fragment" };
  const primitives = new Proxy({}, { get: (_target, key) => (typeof key === "string" ? function Primitive() { return null; } : undefined) });
  const reactDomClient = { createRoot: () => ({ render() {}, unmount() {} }) };
  const requireShim = (name) => {
    if (name === "react") return React;
    if (name === "react/jsx-runtime") return jsxRuntime;
    if (name === "react-dom/client") return reactDomClient;
    if (name === "@deepseek-ai/dsh-client-ui-primitives") return primitives;
    if (name === "@deepseek-ai/dsh-client-ui-dockkit") return { dockPaneIds: () => [], findContentTab: () => undefined, findTabPane: () => undefined };
    throw new Error(`未预期的 require：${name}（必须命中 9 个基线键之一）`);
  };

  let mod;
  try {
    mod = registration.factory(requireShim);
  } catch (error) {
    bad("factory 执行", String(error));
    return;
  }
  ok("factory 执行", `exports=[${Object.keys(mod).join(",")}]`);
  ok("客户端 inject", JSON.stringify(mod.inject));

  const baseline = new Set([
    "react",
    "react/jsx-runtime",
    "react-dom",
    "react-dom/client",
    "@deepseek-ai/cordis",
    "@deepseek-ai/dsh-client-store",
    "@deepseek-ai/dsh-client-ui-slots",
    "@deepseek-ai/dsh-client-ui-primitives",
    "@deepseek-ai/dsh-client-ui-dockkit",
  ]);
  const REQUIRES = [...source.matchAll(/require\(\s*"([^"]+)"\s*\)/g)].map((m) => m[1]);
  const outside = [...new Set(REQUIRES)].filter((name) => !baseline.has(name));
  if (outside.length) bad("require 只使用基线模块", outside.join(","));
  else ok("require 只使用基线模块", [...new Set(REQUIRES)].join(","));

  const slots = [];
  const effects = [];
  const tabTypes = [];
  const resourceProviders = [];
  const previews = [];
  const ctx = {
    effect(fn, label) {
      const disposer = fn();
      effects.push({ label, disposer });
      return disposer;
    },
    resources: { register: (provider) => { resourceProviders.push(provider); return () => {}; } },
    sidebarRightTabs: { register: (def) => { tabTypes.push(def); return () => {}; } },
    workspaces: { list: { getSnapshot: () => ({ items: [] }) } },
    uiWorkspace: { openWorkspace: async () => {} },
    layout: { panelInfo: { getSnapshot: () => ({}) }, selectPanel() {} },
    locale: { register: () => () => {}, bind: () => (key) => key },
    conversation: { input: { for: () => null } },
    slots: {
      inject(key, cb) {
        const out = cb();
        if (out && typeof out[Symbol.iterator] === "function" && typeof out !== "function") {
          for (const _ of out) break;
        }
        return () => {};
      },
      register(spec, component) {
        slots.push({ spec, component });
        return () => {};
      },
    },
    sidebarRight: { active: () => null, openResource: () => {}, registerCloseHandler: () => () => {}, mounted: { getSnapshot: () => undefined } },
    sessions: {
      list: { getSnapshot: () => ({ byId: {} }) },
      scope: () => undefined,
      retain: () => ({ release() {} }),
      create: async () => ({ sessionId: "verify-session" }),
      rename: async () => ({}),
      prompt: async () => ({}),
    },
    remote: {
      session: { create: async () => ({}), rename: async () => ({}), prompt: async () => ({}) },
      workspaceFiles: { read: async () => ({ ok: true, value: { text: "", eof: true, lines: 0, offset: 1, version: "v", absolutePath: "/x.md" } }) },
    },
    documentPreviews: { register: (def) => { previews.push(def); return () => {}; } },
  };

  try {
    mod.apply(ctx);
  } catch (error) {
    bad("客户端 apply() 执行", String(error));
  }
  if (consoleErrors.length === 0) ok("客户端 apply() 无内部错误");
  else bad("客户端 apply() 内部错误", consoleErrors.join(" | "));

  const chatType = tabTypes.find((t) => t.kind === "paperchat");
  if (!chatType) bad("注册论文对话标签类型 paperchat");
  else if (!chatType.canOpen("dsh-resource://paperchat/session/session-1") || chatType.canOpen("dsh-resource://file/session/x/y"))
    bad("paperchat 地址识别", "canOpen 结果不对");
  else ok("注册论文对话标签类型 paperchat");
  if (resourceProviders.some((p) => p.protocol === "paperchat")) ok("注册 paperchat 资源提供者");
  else bad("注册 paperchat 资源提供者");
  for (const name of ["sidebarRightTabs", "resources", "conversation", "workspaces", "uiWorkspace", "layout", "locale", "remote.session", "remote.workspaceFiles", "documentPreviews"]) {
    if (!mod.inject.includes(name)) bad(`客户端 inject 含 ${name}`);
  }

  // 「可编辑」Markdown 渲染器：extension 级、renderer 模式，并有同 key 的 document 槽位
  const editor = previews.find((p) => p.id === "paperforge.md-editor");
  const editorBody = slots.find((s) => s.spec && s.spec.name === "sidebar.right.tab.document" && s.spec.key === "paperforge.md-editor");
  if (!editor || !editor.extensions.includes("md") || editor.priority !== "extension" || editor.loading !== "renderer") bad("注册 Markdown 编辑渲染器", JSON.stringify(editor));
  else if (!editorBody) bad("注册 Markdown 编辑器 document 槽位");
  else ok("注册 Markdown 编辑渲染器", `${editor.id}（${editor.title()}）`);

  // 块切分：围栏 / 公式 / 列表续行 / front matter / CRLF；每个非空白字符都落在某一块里
  const { splitBlocks, parseFileAddress, sessionMention } = mod.__test || {};
  const mention = typeof sessionMention === "function" ? sessionMention("session-中文-1", "AI · a]b") : "";
  const wantMention = `@[AI · a\\]b](dsh-session:${Buffer.from(JSON.stringify("session-中文-1"), "utf8").toString("base64url")})`;
  if (mention === wantMention) ok("@会话 引用编码与 DSH 一致", mention);
  else bad("@会话 引用编码", `${mention} ≠ ${wantMention}`);
  const blockCases = [
    ["# T\n\n## A\n\npara 1\npara 2\n\n> quote\n\n*p.1*\n", ["# T", "## A", "para 1\npara 2", "> quote", "*p.1*"]],
    ["a\n\n```js\nx\n\ny\n```\n\nb", ["a", "```js\nx\n\ny\n```", "b"]],
    ["$$\na\n\nb\n$$\n\nc $$x$$", ["$$\na\n\nb\n$$", "c $$x$$"]],
    ["- item\n\n  continued\n\nnext", ["- item\n\n  continued", "next"]],
    ["---\ntitle: x\n---\n\n# H", ["---\ntitle: x\n---", "# H"]],
    ["a\r\n\r\nb\r\n", ["a", "b"]],
  ];
  let blockFailures = 0;
  for (const [text, want] of blockCases) {
    const blocks = typeof splitBlocks === "function" ? splitBlocks(text) : [];
    const got = blocks.map((b) => text.slice(b.start, b.end));
    const covered = new Set(blocks.flatMap((b) => Array.from({ length: b.end - b.start }, (_, i) => b.start + i)));
    const uncovered = [...text].some((ch, i) => /\S/.test(ch) && !covered.has(i));
    if (JSON.stringify(got) !== JSON.stringify(want) || uncovered) {
      blockFailures += 1;
      bad("块切分", `${JSON.stringify(text)} → ${JSON.stringify(got)}`);
    }
  }
  if (blockFailures === 0) ok("块切分（围栏/公式/列表续行/front matter/CRLF）", `${blockCases.length} 例`);
  const address = typeof parseFileAddress === "function" ? parseFileAddress("dsh-resource://file/session/s-1//home/u/a%20b.md") : null;
  if (address && address.sessionId === "s-1" && address.path === "/home/u/a b.md") ok("文件地址解析");
  else bad("文件地址解析", JSON.stringify(address));

  const target = slots.find((s) => s.spec && s.spec.name === "sidebar.right.tab.document.actions");
  if (!target) bad("注册到 sidebar.right.tab.document.actions");
  else if (target.spec.id !== "paper") bad("list 槽位条目带 id", JSON.stringify(target.spec));
  else ok("注册到 sidebar.right.tab.document.actions", `id=${target.spec.id}`);

  const expectedSlots = [
    "sidebar.right.tab.document.actions", "sidebar.right.pane.tab", "sidebar.right.pane.tab.title",
    "paperforge.chat.conversation", "shell.overlay", "sidebar.panellist", "main", "sidebar.right.tab.document",
  ];
  const names = slots.map((s) => s.spec && s.spec.name);
  const missing = expectedSlots.filter((n) => !names.includes(n));
  if (missing.length) bad("插槽注册齐全", `缺少 ${missing.join(",")}`);
  else ok("插槽注册齐全", names.join(","));

  // 文档事件监听是否装上（划词/框选依赖）
  const types = new Set(documentListeners.map(([t]) => t));
  const library = slots.find((s) => s.spec && s.spec.name === "sidebar.panellist");
  if (!library || library.spec.id !== "paperforge.library") bad("左侧栏「论文」入口带 id", JSON.stringify(library && library.spec));
  else ok("左侧栏「论文」入口", library.spec.id);
  for (const type of ["mouseup", "mousedown", "mousemove", "scroll", "keydown"]) {
    if (types.has(type)) ok(`监听 ${type}`);
    else bad(`监听 ${type}`);
  }

  // 文档级 style 是否注入（选中高亮修正）
  const style = head.children.find((c) => c.attributes && "data-paperforge-style" in c.attributes);
  if (style && /--dsw-alias-/.test(style.textContent)) ok("注入主题化样式", "使用 DSH 主题变量");
  else bad("注入主题化样式");
}

/* ------------------------------------------------------------------ *
 * 3. 脱敏自检：插件必须能原样分发，不得含用户名 / 机器专属路径
 * ------------------------------------------------------------------ */
async function testSanitize() {
  const fs = await import("node:fs");
  const workspaceName = WORKSPACE.split(/[\\/]/).filter(Boolean).pop() || "";
  const escaped = workspaceName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const PATTERNS = [
    // 真实用户名目录（`C:\Users` 后必须还有一段，故纯提示性的 "C:\Users" 不算）
    { label: "Windows 用户名目录", re: /[A-Za-z]:\\+Users\\+[^\\/\s"'<>|)]+/g },
    // 本机工作区被写死（动态推导，换机器也有效）
    { label: "工作区绝对路径", re: new RegExp(`[A-Za-z]:\\\\+${escaped}`, "gi") },
  ];
  const files = [];
  const walk = (dir) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (entry.name === "node_modules" || entry.name.startsWith(".")) continue;
      const full = join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (/\.(js|mjs|md|json|ya?ml)$/.test(entry.name)) files.push(full);
    }
  };
  walk(PLUGIN_DIR);

  let hits = 0;
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    for (const { label, re } of PATTERNS) {
      for (const match of text.match(re) || []) {
        hits += 1;
        bad(`脱敏：${label}`, `${file.replace(PLUGIN_DIR, "")} → ${match.slice(0, 60)}`);
      }
    }
  }
  if (hits === 0) ok("脱敏自检", `${files.length} 个文件，0 处用户名/机器路径`);
}

/* ------------------------------------------------------------------ *
 * 运行
 * ------------------------------------------------------------------ */
await testHost();
await testClipWritesCleanNote();
await testMarkdownSave();
await testClient();
await testSanitize();

const pad = (s, n) => String(s).padEnd(n);
console.log("\n================ 插件验证结果 ================");
for (const [status, name, extra] of results) {
  console.log(`${status} | ${pad(name, 34)} | ${extra || ""}`);
}
const failed = results.filter(([s]) => s === "FAIL");
console.log("==============================================");
console.log(failed.length === 0 ? `全部通过（${results.length} 项）` : `失败 ${failed.length} / ${results.length} 项`);
// 插件会装 setInterval（高亮持久化轮询），Node 因此不会自行退出；浏览器里这是正常的。
process.exit(failed.length === 0 ? 0 : 1);
