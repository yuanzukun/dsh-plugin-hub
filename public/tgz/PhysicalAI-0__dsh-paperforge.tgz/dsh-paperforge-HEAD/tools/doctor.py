"""PaperForge 环境自检（只读，不改任何文件）。

检查三件事：
  1. 插件会用哪个 Python，它能否 import PyMuPDF（写笔记 / 截图 / 高亮都靠它）；
  2. 随包分发的 Python 边车 `py/paper_clip.py` 是否存在；
  3. 插件是否已通过 `dsh plugin --profile <name> add …` 装入并启用。

用法：
    pixi run doctor
    python tools/doctor.py --profile web
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

REPO = Path(__file__).resolve().parent.parent  # <repo>/tools/doctor.py
PLUGIN_NAME = json.loads((REPO / "package.json").read_text(encoding="utf-8"))["name"]


def plugin_python() -> str:
    """复刻宿主 lib/index.js 的 resolvePython：取**第一个存在**的候选，不管它有没有 PyMuPDF。

    config.python 与 <工作区>/.pixi 只有宿主知道（取决于 profile 配置和启动目录），这里无法检查。
    """
    candidates = [
        os.environ.get("DSH_PAPER_PYTHON"),
        str(REPO / ".pixi" / "envs" / "default" / "python.exe"),
        str(REPO / ".pixi" / "envs" / "default" / "bin" / "python"),
    ]
    return next((c for c in candidates if c and Path(c).exists()), "python3")


def check_python() -> bool:
    interp = plugin_python()
    print(f"Python     : {interp}")
    try:
        out = subprocess.run(
            [interp, "-c", "import fitz;print(getattr(fitz, 'VersionBind', '?'))"],
            capture_output=True, text=True, timeout=60,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        print(f"  PyMuPDF  : 无法执行该解释器（{error}）")
        out = None
    if out is not None and out.returncode == 0:
        print(f"  PyMuPDF  : OK {out.stdout.strip()}")
        return True
    if out is not None:
        print("  PyMuPDF  : 缺失")
    print("  → 在本仓库跑 `pixi install`，或给上面这个解释器装 pymupdf，或设 DSH_PAPER_PYTHON 指向装了它的 Python")
    return False


def check_profile(profile: str) -> None:
    home = Path(os.environ.get("DSH_HOME") or (Path.home() / ".dsh"))
    manifest = home / "profiles" / profile / "package.json"
    bundles = []
    if manifest.is_file():
        bundles = json.loads(manifest.read_text(encoding="utf-8")).get("dsh", {}).get("profile", {}).get("bundles", [])
    if PLUGIN_NAME in bundles:
        print(f"DSH profile: {profile}  已启用 {PLUGIN_NAME}（改完代码重启 dsh web 生效）")
    else:
        print(f"DSH profile: {profile}  尚未启用 {PLUGIN_NAME}")
        print(f"  → dsh plugin --profile {profile} add github:PhysicalAI-0/{PLUGIN_NAME}   # 或 add <本仓库路径>")


def main() -> int:
    parser = argparse.ArgumentParser(description=f"{PLUGIN_NAME} 环境自检")
    parser.add_argument("--profile", default="web", help="要检查的 DSH profile（默认 web）")
    args = parser.parse_args()
    print(f"仓库根目录 : {REPO}")
    ok = check_python()
    clip = REPO / "py" / "paper_clip.py"
    print(f"边车脚本   : {clip}  {'存在' if clip.is_file() else '缺失!'}")
    ok = ok and clip.is_file()
    check_profile(args.profile)
    print("结论       : " + ("环境就绪" if ok else "环境不完整（见上）"))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
