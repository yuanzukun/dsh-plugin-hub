# Changelog / 更新日志

本文件记录 dsh-im 各正式版本的重要变化。格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，版本号遵循 [Semantic Versioning](https://semver.org/lang/zh-CN/)。

This file records the notable changes in each dsh-im release. Its format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and its versions follow [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Added / 新增

- 拟人化新增**过程进度提示开关（progressStatus，默认开启）**：处理任务时显示中间状态气泡（如"正在处理…""正在使用工具…""正在整理结果…"）。关闭后不再发送占位气泡与中间进度文案，回复直达，流式文本仍正常逐字显示。**与 message_break 同时开启时**，关闭此项会连带跳过占位流（分段直接逐条发送，消除占位气泡与分段消息的内容重复）；纯流式时以"懒建流"模式延迟到首条真实文本才创建消息，不发占位。支持所有聊天渠道（QQ/微信本就无中间进度，AI Office 任务进度不受影响）。支持每机器人覆盖，改设置下一条消息即生效，无需重启。
  Humanization adds a **progress hints toggle (progressStatus, on by default)**: interim status bubbles shown while processing (e.g. "Processing…", "Using tool…", "Gathering results…") can now be turned off so no placeholder or progress text is sent — replies arrive directly while streaming text still appears word by word. **When message_break is also on**, turning this off additionally skips the placeholder stream entirely (segments are sent directly, removing the duplicate top bubble); in pure streaming mode a "lazy stream" defers message creation until the first real text, so no placeholder is ever sent. Applies to all chat channels (QQ/WeChat already have no interim progress; AI Office job progress is unaffected). Supports per-bot overrides and takes effect on the next message without a restart.
- 拟人化设置支持**逐 bot 逐项覆盖全部设置**：每个渠道机器人卡片的「拟人化」折叠面板现可覆盖全部 8 项设置（流式回复、分步消息、状态表情回应、回复引用、新消息行为、输入状态指示、断续节奏、发送延迟），不再仅限发送延迟。每项独立选择「跟随全局」或自定义值，保存只写被覆盖的项，未覆盖项继续跟随全局默认变化。后端数据模型此前已支持逐键替换，本次开放 UI。
  Humanization settings now support **per-bot per-key override for ALL settings**: each channel bot card's "Humanization" panel can override all 8 settings (streaming, message break, status reaction, reply quote, on-new-message behavior, typing indicator, burst rhythm, send delay), not just send delay. Each setting independently chooses "follow global" or a custom value; only overridden settings are saved, while the rest continue to track the global default. The backend data model already supported per-key replacement; this release opens the UI.
- 全局面板与逐 bot 编辑器改为渲染**同一套共享字段模块**（`humanize-fields.js`：字段布局、提示文案、探索预设、上限与校验错误单一来源），两个界面的详略度与格式完全一致，不会再各自漂移；全局面板的发送延迟/断续节奏同步获得探索预设与保存时校验（字段错误就地显示），行为与逐 bot 编辑器对齐。全局面板从 590 行降到 273 行，逐 bot 编辑器从 810 行降到 419 行。
  The global panel and the per-bot editor now render from **one shared field module** (`humanize-fields.js`: a single source for field layout, hints, exploration presets, limits, and validation errors), so the two surfaces are identical in detail and format and can no longer drift apart; the global panel's send-delay/burst fields gain the exploration presets and on-save validation (inline field errors), matching the per-bot editor's behavior. The global panel shrank from 590 to 273 lines; the per-bot editor from 810 to 419.
- 拟人化新增两个全局开关，对应原始诉求「关掉 Telegram 的 reaction（点赞、眼睛）和回复引用」：**状态表情回应（statusReaction，默认开启）**关闭后六渠道（Telegram/Slack/Discord/WhatsApp/飞书/钉钉）不再发送处理中/成功/失败表情，回复照常送达；**回复引用（replyQuote，默认开启）**关闭后机器人回复不再以「回复/引用」形式指向用户消息，仅影响 Telegram/Discord/WhatsApp 的引用样式，话题路由与线程/话题归组不变。WhatsApp 的已读回执不受影响（门控在发送层，保留 `quoted.key` 用于已读标记）。两项均支持每机器人覆盖，改设置下一条消息即生效，无需重启。**升级兼容**：新客户端写旧宿主会被 `SETTABLE_KEYS` 整体拒绝（保存报错，非部分成功）——客户端与宿主需同版本；旧宿主读新 humanize.json 安全。
  Humanization adds two global toggles, answering the original request "turn off Telegram reactions (👍/👀) and reply quotes": **Status emoji reactions (statusReaction, on by default)** — when off, none of the six channels (Telegram/Slack/Discord/WhatsApp/Feishu/DingTalk) send processing/success/failure emoji and replies still deliver; **Reply quotes (replyQuote, on by default)** — when off, the bot's replies no longer quote the user's message, affecting only the quote style on Telegram/Discord/WhatsApp; topic routing and thread/topic grouping are unchanged. WhatsApp read receipts are unaffected (gated at the send layer; `quoted.key` is still used for read markers). Both support per-bot overrides (data model, no per-bot UI control) and take effect on the next message without a restart. **Upgrade note**: a new client writing to an older host is rejected wholesale by `SETTABLE_KEYS` (the save fails rather than partially succeeding) — client and host must be the same version; an older host reading a new humanize.json is safe.
- 拟人化两阶段发送：新增**发送延迟**（默认关闭）与**输入状态指示**。阅读延迟在回合开始前静默 `readDelay`（min/max 随机 + 可选按用户消息长度的阅读项，`maxTotalMs` 封顶；无输入状态接口的渠道封顶 5 秒），**活跃响应**（activityBoost）让刚聊完天的回合"秒回"：上一回合结束后秒回窗口（默认 1 分钟）内直接用快速回复（默认约 1 秒），恢复下限窗口（默认 2 分钟）前线性回升，超过完全恢复窗口（默认 5 分钟）回到完整随机区间；首条消息不加速。分段间隔为分步消息/流式分段之间"正在打下一条"的停顿。延迟期间的新消息（interrupt）或 `/stop` 会**静默取代**旧回合：不生成、不发送、无失败提示、无双回复；排队模式延迟累积。发送延迟支持**按机器人覆盖**（渠道卡片内跟随全局/自定义），配置文件暴露全部参数（charsPerSecond、activityBoost、typingBurst 等）。
  Two-phase humanized sending: adds a **send delay** (off by default) and a **typing indicator**. A read delay stays silent before the turn starts (`readDelay` min/max random + optional per-message-length reading term, capped by `maxTotalMs`; channels without a typing API are capped at 5 seconds), and the **activity boost** (activityBoost) makes a turn right after a quick exchange "reply in seconds": within the fast-reply window (default 1 min) after the previous turn ends use the fast reply (default ~1 s) directly, ramp linearly back to the floor by the floor-recovery window (default 2 min), and past the full-recovery window (default 5 min) return to the full random range; the first message is never accelerated. Segment gaps pause between message-break or streamed segments like someone typing the next message. A new message (interrupt) or `/stop` during the delay **silently supersedes** the old turn — no generation, no send, no failure notice, no double reply; queued messages accumulate delays. The send delay supports **per-bot overrides** (follow global / custom override on each channel card), and the config file exposes every parameter (charsPerSecond, activityBoost, typingBurst, …).
- 设置面板提供发送延迟**全参数面与探索预设**（轻拟人/慢性子/沉浸角色扮演/即刻应答）；按机器人覆盖草稿预填当前全局值，未显式修改的高级子字段保存时继承全局值，未保存草稿在轮询刷新下保留。钉钉分段间隔强制 ≥3 秒（webhook 频控）。
  The settings panel exposes the full send-delay parameter face plus exploration presets (lightly human / slow-paced / immersive role-play / instant reply); per-bot override drafts prefill the current global values, untouched advanced subfields inherit the global values on save, and unsaved drafts survive polling refreshes. DingTalk segment gaps are floored at 3 seconds (webhook rate limit).
- **breaking（配置）**：`readDelay.idleBoost`（闲置加成：闲置越久延迟 ×N）被语义反转并替换为 `readDelay.activityBoost`（活跃响应：刚聊完天"秒回"）。已存的 `idleBoost` 键在读取时被忽略并回落新默认值——如果你之前调过闲置加成，请在设置面板重配活跃响应。
  **Breaking (config)**: `readDelay.idleBoost` (idle boost — the longer the idle, the slower the reply) is semantically inverted and replaced by `readDelay.activityBoost` (active response — fast replies right after a quick exchange). A stored `idleBoost` key is ignored on load and falls back to the new defaults; if you had tuned the idle boost, re-configure the activity boost in the settings panel.
- 输入状态指示三档（off/continuous/burst，默认断续）：Telegram/Discord/WhatsApp 全档支持，微信票据型保活，QQ 仅私聊；交互等待期间暂停、回答后恢复、回合结束必熄灭；QQ 改用桥内自管理输入状态会话（55 秒显示 / 50 秒续期）替代失效的 SDK 中间件。
  Typing indicator in three modes (off/continuous/burst, bursty by default): full support on Telegram/Discord/WhatsApp, ticket-based keepalive on WeChat, direct chats only on QQ; paused while interactions are pending and always dark when the turn ends; QQ now uses a bridge-managed typing session (55 s display / 50 s renewal) instead of the dead SDK middleware.

### Fixed / 修复

- 修复 QQ 桥接 `messageBreakHandler` 作用域缺陷：此前任何成功回合只要启用 message_break 就会触发 ReferenceError 并误报"任务未完成"（4 个基线测试失败的真实根因）。
  Fixes a QQ bridge `messageBreakHandler` scoping bug: any successful turn with message_break enabled previously threw a ReferenceError and misreported a task failure (the true root cause behind 4 baseline test failures).
- 修复延迟窗口内被取代回合的双回复问题；被取代的批量输入保留待 `/send` 重试（turn-stopped 仍完成批次）。
  Fixes double replies for turns superseded during the delay window; superseded batch inputs are retained for `/send` retry (turn-stopped still completes its batch).

> 本仓库（humanize fork）在 [Unreleased] 段维护拟人化（humanize）功能层的变更条目；其下为上游 [xmanrui/dsh-im](https://github.com/xmanrui/dsh-im) 的版本历史。

## [4.21.2] - 2026-09-17

## [4.38.0] - 2026-10-09

### Added / 新增

- 飞书机器人「更多设置 → 通用」新增独立的「展开思考过程」和「展开工具摘要」开关。设置按机器人持久化，更新时无需重连，普通回复与双向同步的实时过程卡使用同一偏好；默认思考过程收起、工具摘要展开。（[#326](https://github.com/xmanrui/dsh-im/issues/326)）
  Feishu bots add independent “Expand thinking process” and “Expand tool summaries” switches under More settings → General. Preferences persist per bot and update without reconnecting, applying to live process cards for both ordinary replies and bidirectional Session sync. Thinking stays collapsed and tools expanded by default. ([#326](https://github.com/xmanrui/dsh-im/issues/326))

### Fixed / 修复

- 待处理审批默认在一小时后自动拒绝，不再无限占用队列或留下 Web 端审批。拒绝提交失败时保留审批状态并退避重试、明确提示尚未确认；已在提交的人工决定优先，过期后不再接受新的批准。感谢 [@luochen211](https://github.com/luochen211) 的贡献（[#319](https://github.com/xmanrui/dsh-im/pull/319)）。
  Pending approvals now default to automatic rejection after one hour instead of indefinitely occupying the queue or leaving shared Web approvals pending. Failed rejection submissions retain state, retry with backoff, and clearly report the unconfirmed outcome. An already-submitting human decision takes precedence, and expired approvals accept no new allow decision. Thanks to [@luochen211](https://github.com/luochen211) ([#319](https://github.com/xmanrui/dsh-im/pull/319)).
- Matrix 加密引擎停止时先等待房间密钥请求及其持久化任务完成，再释放加密会话；后台密钥请求失败被捕获并记录，避免关闭阶段的异步任务竞争。（[#337](https://github.com/xmanrui/dsh-im/pull/337)）
  Matrix crypto shutdown drains room-key requests and their persistence tasks before freeing crypto sessions. Background key-request failures are caught and logged, preventing shutdown races. ([#337](https://github.com/xmanrui/dsh-im/pull/337))

### Changed / 变更

- 简化机器人通用设置，消息处理模式和飞书面板开关改为修改后自动保存；保存期间避免重复提交，失败时恢复已保存值并显示错误。飞书两个过程卡开关以统一布局展示。
  Bot General settings are streamlined: message mode and Feishu panel switches save automatically on change, block duplicate submissions while saving, and restore the saved value with an error on failure. Both Feishu process-card controls share a consistent layout.
- 插件图标调整为更粗的蓝绿圆环，并更新文档截图。
  The plugin icon now uses thicker blue and green rings, with refreshed documentation screenshots.

### Notes / 使用说明

- 面板展开偏好仅影响飞书实时过程卡；已完成、已停止和分片封存的卡片仍自动收起过程详情，不会改变原生 CoT 或分步消息的展示模式。
  Panel expansion preferences apply only to Feishu live process cards. Completed, stopped, and sealed overflow cards still collapse process details; native CoT and discrete step-post modes remain unchanged.
- 依赖声明与 DSH `0.2.0-rc.2` 兼容声明保持不变；升级后重启 Host 并刷新管理页面，以加载同版 Host 和客户端设置。
  Dependency declarations and declared DSH `0.2.0-rc.2` compatibility remain unchanged. Restart the Host and refresh the management page after upgrading so Host and client settings use the same version.

## [4.37.0] - 2026-10-07

### Added / 新增

- 全部 13 个聊天渠道新增每个机器人独立的「排队／插话」设置，入口为「更多设置 → 通用」，默认排队。插话模式复用现有 `/steer` 权限、任务归属与补充指令机制；普通纯文字可在当前任务的下一步读取，并提供排队或提交回执。（[#314](https://github.com/xmanrui/dsh-im/issues/314)、[#115](https://github.com/xmanrui/dsh-im/issues/115)）
  All 13 chat channels add a per-bot Queue/Steer setting under More settings → General, defaulting to Queue. Automatic steering reuses `/steer` permissions, task ownership, and instruction submission for ordinary plain text, with queue or submission receipts. ([#314](https://github.com/xmanrui/dsh-im/issues/314), [#115](https://github.com/xmanrui/dsh-im/issues/115))

- 新增跨渠道 `/clear` 命令，清空当前会话的模型上下文，同时保留 Session 绑定和历史记录；同步更新帮助、菜单与中英文提示。感谢 [@luochen211](https://github.com/luochen211) 的贡献（[#320](https://github.com/xmanrui/dsh-im/pull/320)，解决 [#318](https://github.com/xmanrui/dsh-im/issues/318)）。
  The cross-channel `/clear` command clears model context while retaining the current Session binding and history, with updated help, menus, and bilingual messages. Thanks to [@luochen211](https://github.com/luochen211) ([#320](https://github.com/xmanrui/dsh-im/pull/320), addressing [#318](https://github.com/xmanrui/dsh-im/issues/318)).

### Fixed / 修复

- 修复飞书数字菜单的新会话操作在消息队列中被自身队列误判为忙碌的问题；等待前序消息处理完成后正常切换，仍保留未完成交互保护。
  Feishu numeric new-Session menu actions no longer mistake their own queue entry for a busy task. They run after earlier messages while preserving pending-interaction protection.

### Security / 安全

- 可选图片处理依赖 `sharp` 从 `0.35.4` 升级至 `0.35.5`，更新预编译原生依赖，修复上游 librsvg 内存安全漏洞 [GHSA-wq5f-xc86-pv6w](https://github.com/advisories/GHSA-wq5f-xc86-pv6w)。其他直接依赖声明保持不变。
  Optional image processing dependency `sharp` is upgraded from `0.35.4` to `0.35.5`, updating prebuilt native dependencies to fix the upstream librsvg memory-safety vulnerability [GHSA-wq5f-xc86-pv6w](https://github.com/advisories/GHSA-wq5f-xc86-pv6w). Other direct dependency declarations remain unchanged.

### Notes / 使用说明

- 设置保存后对新消息生效，已排队消息保持原顺序；没有运行任务时正常开始新任务，附件、语音、引用、命令、审批和菜单保持原有处理方式。手动 `/steer` 在两种模式下均可用；AI Office 的任务协议不适用此设置。
  Settings apply to new messages without reinterpreting queued inputs. Idle messages start normally; attachments, voice, quotes, commands, approvals, and menus retain their existing handling. Manual `/steer` works in either mode. AI Office's task protocol is outside this setting's scope.
- `/clear` 不接受参数、图片或文件，运行任务或等待交互时须先处理完毕；Host 不支持时明确提示，不会回退到 `/new` 或解除会话绑定。
  `/clear` accepts no arguments, images, or files and requires active tasks or pending interactions to finish first. Unsupported Hosts receive an explicit notice without falling back to `/new` or clearing the Session binding.
- DSH `0.2.0-rc.2` 兼容声明保持不变；升级后重启 Host 并刷新管理页面，以加载同版 Host 和客户端设置。
  Declared DSH `0.2.0-rc.2` compatibility remains unchanged. Restart the Host and refresh the management page after upgrading so Host and client settings use the same version.

## [4.36.1] - 2026-10-06

### Fixed / 修复

- Harness RPC 失败时保留实际调用方法、进程内 Host API 或 HTTP 调用方式、请求耗时及超时阈值；诊断信息经过健康检查包装、消息错误分类和公开错误转换后仍可用于定位问题。
  Failed Harness RPCs retain the actual method, in-process Host API or HTTP transport, elapsed request time, and timeout threshold. This evidence survives health-check wrapping, message-failure classification, and public error projection for troubleshooting.
- 管理页面的连接错误与消息错误详情补齐 RPC 方法和调用方式，中英文标签、复制诊断内容及日志同步保留这些信息；方法与调用方式使用白名单校验，不透出请求正文、认证信息或未经允许的底层字段。
  Management-page connection and message error details now show RPC method and transport, with Chinese and English labels and matching copied diagnostics and logs. Method and transport values are allowlisted without exposing request payloads, credentials, or unapproved underlying fields.
- 保持现有错误码及调用方取消行为；调用方主动取消时不改写原始错误，也不会因新增诊断而重试请求或切换传输方式。
  Existing error codes and caller cancellation behavior are preserved. Explicit cancellation leaves the original error untouched, and the added diagnostics do not retry requests or switch transports.

### Notes / 使用说明

- 依赖声明与 DSH `0.2.0-rc.2` 兼容声明保持不变；升级后重启 Host 并刷新管理页面，以加载同版 Host 和客户端诊断逻辑。
  Dependency declarations and declared DSH `0.2.0-rc.2` compatibility remain unchanged. Restart the Host and refresh the management page after upgrading so Host and client diagnostics use the same version.

## [4.36.0] - 2026-10-05

### Added / 新增

- Web 与 11 类 IM 渠道共享同一次审批，最先提交的「批准一次」或「拒绝」生效，另一端随即失效；机器人发起的审批沿用原聊天，Web/Host 发起的审批可投递到该 Session 唯一绑定且开启双向同步的私聊。发送和提交时重新校验绑定与访问权限，同一私聊的目标别名合并计算；多个私聊仅发送 Web 处理提醒，不提供永久批准。
  Web and 11 IM channel types can handle the same approval: the first allow-once or reject decision wins and retires the other presentation. IM-originated approvals stay in their original chat; Web/Host approvals may reach the Session's single bound private chat with bidirectional sync enabled. Binding and access checks run before presentation and submission, aliases for the same private chat are deduplicated, multiple private chats receive only a Web reminder, and permanent approval is not offered.
- 同 Host 的 `dshIm` Service 新增 `inboundVersion: 1`、`consumeInbound`、`replyChecked` 和 `historyChecked`。已注册的飞书/Lark 独占消费者可按已认证原消息读取群、附近或原生话题中的有限文本历史；每次重新核验作者、会话及话题路由，显式分页，单次最多检查 20 条平台记录，不支持的记录计入 `omitted`。
  The same-Host `dshIm` Service adds `inboundVersion: 1`, `consumeInbound`, `replyChecked`, and `historyChecked`. Registered exclusive Feishu/Lark consumers can read bounded group, nearby, or native-thread text history anchored to an authenticated source. Every call revalidates author, conversation, and topic routing, explicitly paginates at most 20 provider records, and counts unsupported records as `omitted`.
- 经过校验的 Lark 附近上下文先遍历原消息前后各五分钟内可见、受支持的用户文本，再按可配置的前后消息保底条数补齐稀疏侧（默认前 10／后 5）。新消息不会查询未来区间；每次调用仍有界并重新校验原消息身份。
  Checked Lark nearby context traverses all supported visible human text within five minutes before and after the source, then fills sparse sides to configurable message minima (default 10 before / 5 after). Fresh sources terminate without querying a future range; every call remains bounded and rechecks the authenticated anchor.

- 飞书/Lark 可由同 Host 应用独占接收文本消息，等待应用确认持久化后返回，并按校验过的原消息/话题回复；外部消费模式在释放或重启后不回退到独立 Session。
  Same-Host applications can opt into exclusive Feishu/Lark text intake, acknowledge after durable acceptance, and reply through a checked original-message/topic route. Releasing or restarting an external consumer never falls back to a standalone Session.

### Fixed / 修复

- 群与话题历史读取现在同时识别 SDK 成功响应和 HTTP 拒绝中的权限错误；取消优先于错误映射，不向应用暴露带认证信息的底层 HTTP 错误。
  Checked history reads recognize permission errors in both resolved responses and rejected SDK HTTP responses; cancellation takes precedence and raw authenticated HTTP errors never escape to application callers.

- 独占收件接管与凭据重绑共用配置事务队列；展示设置更新不再被误判为账号变更。应用回调不占用机器人操作队列，断开可取消待处理回调，回调也可读取或回复原消息。
  Exclusive takeover shares configuration serialization with credential rebinding; presentation changes no longer look like account changes. Application callbacks release the bot operation queue so disconnect can cancel them and callbacks can await checked reads or replies.

### Changed / 变更

- DSH 支持基线调整为 `0.2.0-rc.2`，同 Host 连接统一使用现代 Typert Gateway、Session 与 Workspace Controller，不再依赖旧 `apiProxy` 注入入口。
  The declared DSH baseline is now `0.2.0-rc.2`. Same-Host connections use the modern Typert Gateway, Session Controller, and Workspace Controller instead of the legacy injected `apiProxy` entry point.

### Notes / 使用说明

- 共享审批支持微信、飞书、钉钉、企业微信机器人／应用、QQ、Telegram、Slack、Discord、WhatsApp、Matrix；iMessage、邮箱与 AI Office 暂不参与。Slack 接收 Web 审批需 `im:read` 权限，缺少权限时保留 Web 入口；本次发布不会自动修改应用权限。
  Shared approvals support WeChat, Feishu, DingTalk, WeCom bot/app, QQ, Telegram, Slack, Discord, WhatsApp, and Matrix; iMessage, email, and AI Office do not participate. Slack needs `im:read` for Web-originated approvals and retains Web fallback when unavailable; this release does not automatically change application permissions.
- 独占收件由应用显式启用，应用负责授权、去重及持久化；释放或重启不会自动恢复独立 Session。历史读取仅覆盖平台可见的用户文本，群历史可能不包含话题回复，应单独使用 `thread`；读历史不会自动收件、唤醒 Agent 或回复。回复结果未知时应核对外部会话，不要盲目重试。
  Exclusive intake is application opt-in, with authorization, deduplication, and persistence owned by the application; release or restart never silently restores standalone Sessions. History covers provider-visible human text only; chat history may omit topic replies, so use `thread` separately. Reads do not automatically ingest messages, wake an agent, or reply. Reconcile unknown reply outcomes externally rather than blindly retrying.
- 依赖声明保持不变。旧版 DSH 请使用对应历史插件版本；升级后重启 Host 并刷新管理页面。感谢 [@DoodleBears](https://github.com/DoodleBears) 的飞书/Lark 接口贡献（[#313](https://github.com/xmanrui/dsh-im/pull/313)、[#315](https://github.com/xmanrui/dsh-im/pull/315)、[#317](https://github.com/xmanrui/dsh-im/pull/317)）。
  Dependency declarations remain unchanged. Use a corresponding historical plugin release with older DSH versions; restart the Host and refresh the management page after upgrading. Thanks to [@DoodleBears](https://github.com/DoodleBears) for the Feishu/Lark contracts ([#313](https://github.com/xmanrui/dsh-im/pull/313), [#315](https://github.com/xmanrui/dsh-im/pull/315), [#317](https://github.com/xmanrui/dsh-im/pull/317)).

## [4.35.1] - 2026-10-05

### Fixed / 修复

- QQ 正常回复和超时补发只包含最后一次工具调用后的答复正文，避免把“正在查询”等过程文字混入最终答案；保留正文分段、工具错误提示及停止后的部分回复。（[#310](https://github.com/xmanrui/dsh-im/issues/310)）
  QQ replies and deferred deliveries now retain answer text after the last tool call, excluding intermediate progress text while preserving answer paragraphs, tool error notices, and partial replies after stopping. ([#310](https://github.com/xmanrui/dsh-im/issues/310))

- 各渠道统一识别已归档会话，发送前明确提示到 DSH 取消归档或使用 `/new`，不再因归档日志不可读取而误判会话不存在、静默切换绑定。发送期间发生归档、相关内部错误或被阻止的轮次时重新核实归档状态；已被接受的消息会提示可能仍在队列中，避免重复提交。（[#316](https://github.com/xmanrui/dsh-im/issues/316)）
  All channels now recognize archived Sessions and explain how to unarchive in DSH or use `/new` before submitting. Unreadable archived logs no longer cause missing-Session misclassification or silent rebinding. Archive races, related internal errors, and blocked turns trigger a fresh archive check; already-accepted messages warn that they may still be queued to prevent duplicate submissions. ([#316](https://github.com/xmanrui/dsh-im/issues/316))
- 普通被阻止的轮次改为中性状态提示，不再直接断言为当前渠道无法处理的操作；归档诊断保留原请求归属、取消行为和其他网络、模型及附件错误，中英文错误提示同步更新。
  Ordinary blocked turns now use a neutral status notice instead of assuming an action unsupported by the channel. Archive diagnostics preserve request ownership, cancellation, and unrelated network, model, and attachment errors, with updated Chinese and English notices.

### Notes / 使用说明

- QQ 最终正文筛选仅用于正常完成及超时后的补发，不改变工具错误提示、停止后的部分回复或其他渠道的正文行为；本次不会自动取消归档或自动重发已接受的消息。
  QQ final-answer filtering applies to normal completion and deferred delivery, without changing tool-error notices, partial replies after stopping, or other channels' answer behavior. This release does not automatically unarchive Sessions or resubmit accepted messages.
- 依赖声明和 DSH `0.1.7-alpha.1` 兼容性声明保持不变；升级后重启 Host 并刷新管理页面。
  Dependency declarations and declared DSH `0.1.7-alpha.1` compatibility remain unchanged. Restart the Host and refresh the management page after upgrading.

## [4.35.0] - 2026-10-04

### Added / 新增

- 同 Host 的公开 `dshIm` Service 新增可选的飞书 / Lark 群消息投递回执：通过 `receiptVersion: 1` 和 `proactive-receipt-checked` 能力声明识别，调用 `sendChecked(..., { receipt: true })` 可获得经过目标校验的最小消息 ID 和会话 ID。未启用回执时继续返回 `{ sent: true }`，沿用账号指纹、目标摘要及发送前注册状态校验。感谢 [@DoodleBears](https://github.com/DoodleBears) 的贡献（[#308](https://github.com/xmanrui/dsh-im/pull/308)）。
  The same-Host public `dshIm` Service adds opt-in Feishu/Lark group delivery receipts, advertised through `receiptVersion: 1` and `proactive-receipt-checked`. Calling `sendChecked(..., { receipt: true })` returns minimal message and conversation IDs validated against the target. Existing sends retain `{ sent: true }` and account-fingerprint, target-digest, and pre-send registration checks. Thanks to [@DoodleBears](https://github.com/DoodleBears) ([#308](https://github.com/xmanrui/dsh-im/pull/308)).

### Fixed / 修复

- QQ 开启平台「接收所有群消息」后，识别 `GROUP_MESSAGE_CREATE` 中指向当前机器人的 @，不再仅依赖专用 @ 事件。识别信息在 SDK 清理文字前保留，并用于消息、命令、交互回复和输入状态；未 @ 当前机器人的消息不会触发回复，访问策略保持不变。（[#311](https://github.com/xmanrui/dsh-im/issues/311)）
  QQ now recognizes self mentions in `GROUP_MESSAGE_CREATE` when the platform delivers all group messages, rather than relying solely on dedicated mention events. The decision survives SDK text sanitization and applies to messages, commands, interaction replies, and typing status. Messages not addressing this bot do not trigger replies, and access policies remain unchanged. ([#311](https://github.com/xmanrui/dsh-im/issues/311))
- 飞书菜单和工作区选择卡片优先显示 Host 工作区名称，缺少名称时回退目录名；同名工作区增加路径片段区分，长名称缩略，仍冲突时补充序号。路径、回调值和数字选择的快照顺序不变，并兼容旧 Host 的路径列表接口。（[#300](https://github.com/xmanrui/dsh-im/issues/300)）
  Feishu menus and workspace cards prefer Host workspace titles, falling back to directory names. Duplicate labels gain path context, long labels are shortened, and remaining collisions receive numbers. Paths, callback values, and numeric-selection snapshot order remain unchanged, with compatibility for older path-only Host APIs. ([#300](https://github.com/xmanrui/dsh-im/issues/300))
- 插件元数据补齐中英文显示名称「IM 机器人」和「IM bots」。
  Plugin metadata now supplies the localized display names “IM 机器人” and “IM bots”.

### Changed / 变更

- README 更新 Token 赞助说明，并明确项目由社区开发者独立开发与维护。
  README sponsorship information is updated and clarifies independent community development and maintenance.

### Notes / 使用说明

- 回执仅证明平台接受请求，不代表消息已送达或被阅读。发送后的回执缺失或与目标不符时返回 `send-result-unknown`，调用方应保留结果未知状态，不要自动重试；本次未新增入站消费、调度或重试机制。详见[回执接口说明](https://github.com/xmanrui/dsh-im/blob/v4.35.0/docs/checked-proactive-receipts.md)。
  Receipts prove platform acceptance, not delivery or human read status. Missing or mismatched receipts after dispatch raise `send-result-unknown`; callers must retain an unknown outcome and must not automatically retry. This release adds no inbound consumer, scheduler, or retry mechanism. See the [receipt contract](https://github.com/xmanrui/dsh-im/blob/v4.35.0/docs/checked-proactive-receipts.md).
- 依赖声明和 DSH `0.1.7-alpha.1` 兼容性声明保持不变；升级后重启 Host 并刷新管理页面。
  Dependency declarations and declared DSH `0.1.7-alpha.1` compatibility remain unchanged. Restart the Host and refresh the management page after upgrading.

## [4.34.2] - 2026-10-03

### Fixed / 修复

- 飞书会话同步复用现有请求期限，为卡片创建、更新、封存和主动文字投递设置有限等待；SDK 请求持续挂起时进入原有失败与文字兜底路径，后续轮次可以继续，停止运行时也会释放当前等待。（[#294](https://github.com/xmanrui/dsh-im/issues/294)）
  Feishu session sync now reuses the existing request deadline to bound card creation, updates, sealing, and proactive text delivery. Hanging SDK requests enter the existing failure and text fallback paths so later turns can continue, and stopping the runtime releases pending waits. ([#294](https://github.com/xmanrui/dsh-im/issues/294))
- 机器人「更多设置」页签在空间不足时显示左右滚动按钮，切换页签及调整容器宽度时自动保持选中项可见，并支持方向键与 Home / End 导航。（[#303](https://github.com/xmanrui/dsh-im/issues/303)）
  Bot settings tabs now show scroll buttons when space is limited, keep the selected tab visible when switching tabs or resizing the container, and support arrow-key and Home / End navigation. ([#303](https://github.com/xmanrui/dsh-im/issues/303))

- 消息失败诊断区分请求超时与网络连接错误，跨 Host RPC 保留经过筛选的连接诊断信息；已知业务错误、主动取消和投递结果未知仍保留各自语义。错误提示提醒先检查会话记录，避免在结果不确定时立即重复发送。
  Message failure diagnostics distinguish request timeouts from network errors and preserve allowlisted connection evidence across Host RPC. Known business errors, deliberate cancellation, and uncertain delivery retain their own semantics. Hints recommend checking conversation history before resubmitting when the outcome is uncertain.

### Changed / 变更

- 新建飞书和 QQ 机器人默认允许所有用户在私聊和群聊中对话及执行内置命令；可在访问设置中改为白名单或关闭普通用户命令权限。已有机器人的已保存策略和旧配置迁移逻辑保持不变。
  New Feishu and QQ bots default to allowing all users to chat and run built-in commands in direct and group conversations. Access settings can restrict them to allowlists or disable ordinary-user commands. Existing saved policies and legacy configuration migration remain unchanged.

### Notes / 使用说明

- 新建机器人默认权限更开放，请按实际使用范围检查访问设置。飞书 SDK 请求超时只保证本地等待结束，不保证平台侧操作已取消；遇到超时或网络错误，请先核对聊天记录再决定是否重试。
  New bots have more permissive defaults; review access settings for the intended audience. A Feishu SDK timeout bounds local waiting but does not guarantee cancellation on the provider side. Check chat history before retrying after a timeout or network error.
- 依赖声明和 DSH `0.1.7-alpha.1` 兼容性声明保持不变；升级后重启 Host 并刷新管理页面。
  Dependency declarations and declared DSH `0.1.7-alpha.1` compatibility remain unchanged. Restart the Host and refresh the management page after upgrading.

## [4.34.1] - 2026-10-02

### Fixed / 修复

- Discord 通过已认证的应用信息确认个人应用所有者或团队所有者，并接入现有所有者访问豁免：已确认的所有者可在私聊和群聊中访问机器人、执行命令，不受普通用户白名单和命令开关限制。身份仅在正常启动、重连或凭据绑定时查询，成功保存后才用于运行时策略；查询失败保留已保存身份，不阻止机器人启动，也不会把团队其他成员或机器人自身视为所有者。（[#296](https://github.com/xmanrui/dsh-im/issues/296)）
  Discord now resolves the personal application owner or team owner from authenticated application metadata and applies the existing owner exemption. Confirmed owners can access the bot and run commands in direct and group chats regardless of ordinary-user allowlists or command switches. Identity is queried only during normal startup, reconnect, or credential binding and applied only after persistence succeeds. Lookup failures retain the saved identity without blocking startup; other team members and the bot itself are not treated as owners. ([#296](https://github.com/xmanrui/dsh-im/issues/296))
- 飞书保存访问策略时校验当前启用的私聊和群聊白名单，拒绝填入当前机器人自身的 Open ID，并返回中英文错误提示；校验失败不会写入或替换已有策略。开放模式下未启用的历史白名单保留，方便恢复访问。
  Feishu rejects its own bot Open ID in active direct-message or group allowlists, with localized save errors. Validation failures leave the existing policy untouched. Inactive historical allowlists remain available when switching back to open mode to recover access.
- 飞书被访问策略拒绝的消息、语音识别结果和卡片操作记录统一的拒绝原因日志，仅包含机器人标识、会话类型和原因，不记录用户身份或消息正文。
  Feishu consistently logs access-policy refusals for messages, transcribed voice input, and card actions using only the bot identifier, conversation type, and reason, without user identities or message content.

### Changed / 变更

- 访问设置补充已确认所有者的权限说明、飞书用户 Open ID 填写提示及 QQ 私聊／群聊身份边界说明，并同步英文文案；新增跨渠道所有者与普通用户隔离回归，修复 Matrix 测试清理临时目录前未等待历史写入的问题。
  Access settings clarify confirmed-owner privileges, Feishu user Open IDs, and QQ direct/group identity boundaries in Chinese and English. Added cross-channel owner/isolation regressions and fixed Matrix test cleanup to wait for pending room-history writes.

### Notes / 使用说明

- 所有者豁免仅适用于接入流程或平台认证确认的身份；飞书仅配置通配符时不会推断所有者，QQ 群聊必须匹配已确认身份，其他用户继续遵守原访问策略。Discord 升级后重启或重连即可尝试补齐身份，无需修改已有白名单；可选身份查询最长等待 5 秒，失败时不会自动放开访问。
  Owner exemptions require identities confirmed during connection setup or by the platform. Wildcard-only Feishu configurations do not identify an owner, QQ groups require a matching confirmed identity, and other users remain subject to their existing access policy. Restart or reconnect Discord after upgrading to attempt owner discovery without changing allowlists. The optional lookup has a five-second timeout and does not open access on failure.
- 依赖声明和 DSH `0.1.7-alpha.1` 兼容性声明保持不变；升级后重启 Host 并刷新管理页面。
  Dependency declarations and declared DSH `0.1.7-alpha.1` compatibility remain unchanged. Restart the Host and refresh the management page after upgrading.

## [4.34.0] - 2026-10-01

### Added / 新增

- 飞书和 QQ 新增 `/permission`、`/permissionlist`，可查看并通过序号或完整 ID 一步切换当前会话权限。序号绑定最近一次列表及会话，沿用 15 分钟快照；沙箱与审批联动由 Host 处理，运行中的任务也能响应。（[#280](https://github.com/xmanrui/dsh-im/issues/280)）
  Feishu and QQ add `/permission` and `/permissionlist` to view and switch current-session permissions by number or full ID in one step. Numbers retain the displayed list and session for 15 minutes; the Host applies sandbox and approval changes, including during a running turn. ([#280](https://github.com/xmanrui/dsh-im/issues/280))

### Fixed / 修复

- Telegram 关闭思考过程留痕时，私聊复用群聊的占位消息编辑流程，避免 Rich Draft 在 Android 上占用发送入口；`/stop`、`/steer` 和普通追加消息沿用原有处理。最终答案保留在占位消息位置，富文本、长答案拆分和附件保持现有投递机制；最终编辑返回明确的“内容未变化”时视为已送达，避免重复发送或降级格式。（[#276](https://github.com/xmanrui/dsh-im/issues/276)）
  With thinking traces off, Telegram private chats now reuse the group's editable placeholder flow, avoiding Rich Drafts that block the Android composer. `/stop`, `/steer`, and ordinary follow-ups retain their existing handling. Final answers stay at the placeholder's position, with existing Rich formatting, long-answer splitting, and attachment delivery. Explicit unchanged-content responses during final edits count as delivered, preventing duplicate messages or unnecessary format fallback. ([#276](https://github.com/xmanrui/dsh-im/issues/276))

### Notes / 使用说明

- 权限命令仅支持纯文字且要求当前聊天已绑定会话，不会为查询自动创建会话，沿用现有命令访问控制。切换直接调用 Host 的权限命令；包括完全访问在内的档位可能改变审批要求，请仅在可信聊天中按需选择。列表序号过期或会话改变后需重新执行 `/permissionlist`，纯数字档位 ID 使用 `/permission id:<ID>`。Host 缺少相关接口或命令时会明确提示不支持。
  Permission commands accept text only, require an already-bound Session, and retain existing command access controls; queries do not create Sessions. Switching invokes the Host's permission command directly. Presets, including full access, may change approval requirements, so select them deliberately in trusted chats. Refresh `/permissionlist` after its number mapping expires or the Session changes; use `/permission id:<ID>` for numeric IDs. Missing Host APIs or commands produce an explicit unsupported message.
- Telegram 本次只调整关闭思考过程留痕时的展示方式，不改变 `/stop`、`/steer`、普通追加消息或附件的既有处理规则。依赖声明和 DSH `0.1.7-alpha.1` 兼容性声明保持不变；升级后重启 Host 并刷新管理页面。
  The Telegram change affects presentation with thinking traces disabled, without changing existing handling of `/stop`, `/steer`, ordinary follow-ups, or attachments. Dependency declarations and declared DSH `0.1.7-alpha.1` compatibility remain unchanged. Restart the Host and refresh the management page after upgrading.

## [4.33.0] - 2026-10-01

### Added / 新增

- 同 Host 的公开 `dshIm` Service 新增版本化账号描述和条件纯文本发送：Feishu/Lark 账号由平台认证身份确定，目标以固定内容摘要校验，旧 `send` 行为保持兼容；未支持的渠道返回明确错误。感谢 [@DoodleBears](https://github.com/DoodleBears) 的代码、文档和测试贡献（[#293](https://github.com/xmanrui/dsh-im/pull/293)）。
  The same-Host public `dshIm` Service adds versioned account descriptions and checked plain-text sends. Feishu/Lark account identity is authenticated against the platform, destinations are checked against a frozen content digest, legacy `send` remains compatible, and unsupported channels return an explicit error. Thanks to [@DoodleBears](https://github.com/DoodleBears) for code, documentation and tests ([#293](https://github.com/xmanrui/dsh-im/pull/293)).

### Fixed / 修复

- IM 文件回传现在要求当前回合存在实际接收文件的活跃 IM 消费者；提示词只在对应回合提供回传指引，Web、Desktop、CLI 等非 IM 回合误用工具时明确拒绝入队。回合结束、消费者释放或文件快照期间失去归属时清理文件，避免显示已排队却无人接收。感谢 [@luochen211](https://github.com/luochen211)（[#290](https://github.com/xmanrui/dsh-im/pull/290)，修复 [#286](https://github.com/xmanrui/dsh-im/issues/286)）。
  IM file returns now require an active consumer that can receive files for the current turn. Prompt guidance is scoped to that turn, and tool calls from non-IM turns such as Web, Desktop, or CLI are explicitly refused rather than queued without a receiver. Files are cleaned up when ownership is lost, including during snapshot creation or turn completion. Thanks to [@luochen211](https://github.com/luochen211) ([#290](https://github.com/xmanrui/dsh-im/pull/290), fixes [#286](https://github.com/xmanrui/dsh-im/issues/286)).
- 飞书菜单的「新会话」按钮显示处理中、已执行和失败状态，并阻止重复或过期回调再次清空后续会话；失败可重试，成功后按钮禁用，卡片更新失败时提示重新打开菜单。感谢 [@luochen211](https://github.com/luochen211)（[#291](https://github.com/xmanrui/dsh-im/pull/291)）。
  Feishu's New session menu action shows processing, completed, and failed states, and prevents duplicate or stale callbacks from clearing a later session. Failures can be retried; successful actions disable the button, and failed card updates prompt the user to reopen the menu. Thanks to [@luochen211](https://github.com/luochen211) ([#291](https://github.com/xmanrui/dsh-im/pull/291)).
- 已启用会话同步的 IM 私聊可接收绑定 Session 中 Host 定时任务成功完成后的最终助手文字，不再漏发结果；内部提醒提示不会作为用户消息回显。
  IM direct chats with Session sync enabled now receive the final assistant text from successful Host-delivered scheduled turns in their bound Session. Internal reminder prompts are not echoed as user messages.

- 飞书图片或文件资源整文件下载返回 `234037` 时，自动改用每次最多 8 MiB 的顺序 Range 请求，并校验响应范围、总大小和实际字节数。普通附件直接流式落盘；图片继续遵守现有大小限制，取消或失败时清理未完成的附件。（[#266](https://github.com/xmanrui/dsh-im/issues/266)） 感谢 [@luochen211](https://github.com/luochen211)（[#289](https://github.com/xmanrui/dsh-im/pull/289)）。
  Feishu image and file downloads now fall back to sequential Range requests of at most 8 MiB when the full download returns `234037`, validating ranges, total size, and actual byte counts. Ordinary attachments stream directly to disk; images retain their existing size limits, and cancelled or failed downloads clean up incomplete attachments. ([#266](https://github.com/xmanrui/dsh-im/issues/266)) Thanks to [@luochen211](https://github.com/luochen211) ([#289](https://github.com/xmanrui/dsh-im/pull/289)).

- 条件投递在最后一次异步账号核验后、SDK 请求开始前再次检查渠道注册、控制器关闭状态和取消信号；凭据读取与平台认证失败返回 `account-unverified`，避免将尚未发送的请求误判为结果未知。
  Checked delivery revalidates the channel Registration, controller lifecycle and cancellation after its final asynchronous account verification, before the SDK request starts. Credential lookup and platform authentication failures return `account-unverified` instead of reporting an uncertain message outcome before any send.

- 修复 Host 语言设置在未注入的 Context 中读取时报错，以及新版 DSH 切换界面语言后 IM 回复和命令菜单未同步的问题。兼容新旧 settings API，渠道启动前等待语言初始化，settings 服务撤销时清理监听并回退到镜像语言。感谢 [@resetsix](https://github.com/resetsix)（[#288](https://github.com/xmanrui/dsh-im/pull/288)，修复 [#287](https://github.com/xmanrui/dsh-im/issues/287)）。
  Fixed Host language settings being read from a Context without injection, and IM replies and command menus not following interface-language changes in newer DSH versions. Supports both settings APIs, waits for language initialization before channels start, and cleans up observers and falls back to the mirrored language when the settings service is withdrawn. Thanks to [@resetsix](https://github.com/resetsix) ([#288](https://github.com/xmanrui/dsh-im/pull/288), fixes [#287](https://github.com/xmanrui/dsh-im/issues/287)).

### Changed / 变更

- npm 包元数据仅保留 `author`，贡献者致谢继续保留在 README 和更新日志中。
  npm package metadata retains only `author`; contributor acknowledgements remain in the READMEs and changelog.

### Notes / 使用说明

- 新条件投递接口为可选的同 Host 插件能力，首版支持飞书/Lark，不改变已有 `send`、HTTP 或管理 RPC。调用方仍需持有用户授权；平台接受不代表送达，结果不确定时不要盲目重试。
  Checked delivery is an optional same-Host plugin capability, initially supported by Feishu/Lark, without changes to existing `send`, HTTP, or management RPC. Callers still need user authorization; platform acceptance does not prove delivery, and uncertain outcomes must not be blindly retried.
- 非 IM 会话应使用 Host 的展示能力返回文件（若提供）；定时任务文字同步需事先启用对应私聊的会话同步。升级后请重新打开飞书菜单，旧卡片的「新会话」回调不再执行。DSH 兼容性声明仍为 `0.1.7-alpha.1`。
  Non-IM conversations should use the Host's presentation capability for file returns, when available. Scheduled text synchronization requires Session sync to be enabled for the direct chat. Reopen the Feishu menu after upgrading; New session callbacks from old cards no longer run. Declared DSH compatibility remains `0.1.7-alpha.1`.

## [4.32.0] - 2026-09-29

### Added / 新增

- 支持插件详情操作按钮的 DSH 中，dsh-im 插件详情页新增「打开 IM机器人」按钮，可在主区域打开已有 IM 管理面板，并通过「返回插件详情」返回当前插件。按钮及返回入口支持中英文。
  On DSH versions that support plugin detail actions, the dsh-im details page adds **Open IM bots** to open the existing IM management panel in the main area, with **Back to plugin details** returning to this plugin. Both actions support Chinese and English.
- 新增中英文插件描述资源，并随 npm 包发布、导出 `locale/*.json`，供 Host 根据界面语言显示插件说明。
  Added Chinese and English plugin-description resources, published and exported as `locale/*.json` so the Host can display the description in the interface language.

### Notes / 使用说明

- 新入口按需接入可选的 `layout`、`pluginNavigation` 服务和 `plugins.detail.actions` 槽位；缺少相关能力的旧版 DSH 仍可通过「设置 → IM机器人」访问，无需迁移配置。入口注册不会提前加载管理面板，相关服务或槽位撤销时会清理注册。
  The new entry uses the optional `layout` and `pluginNavigation` services and the `plugins.detail.actions` slot. Older DSH versions without these capabilities retain **Settings → IM bots**, with no configuration migration. Registration does not mount the panel early, and registrations are cleaned up when the relevant services or slots are withdrawn.
- 本次不改变渠道配置及消息处理行为；DSH 兼容性声明仍为 `0.1.7-alpha.1`，插件详情入口仅在 Host 提供上述能力时可用。
  This release does not change channel configuration or message processing. The declared DSH compatibility remains `0.1.7-alpha.1`; the plugin-details entry is available only when the Host provides the capabilities above.

## [4.31.0] - 2026-09-29

### Added / 新增

- 上下文增强新增可选来源字段「发送时间」`sentAt`，目前由微信渠道提供：优先使用平台发送时间，平台未提供时从消息 ID 解析，按 Host 本机时区输出 `YYYY-MM-DD HH:mm:ss`。无法取得有效时间时省略该字段，不用当前时间代替。感谢 [@Pegasus02](https://github.com/Pegasus02)（[#279](https://github.com/xmanrui/dsh-im/pull/279)）。
  Context enhancement adds an optional Sent at source field, `sentAt`, currently supplied by WeChat. It uses the platform send time, or decodes the message ID when that time is absent, and renders `YYYY-MM-DD HH:mm:ss` in the Host's local time zone. An unavailable or invalid time is omitted rather than replaced with the current time. Thanks to [@Pegasus02](https://github.com/Pegasus02) ([#279](https://github.com/xmanrui/dsh-im/pull/279)).

### Fixed / 修复

- 飞书等待用户回答时，提问发起人发送图片或图文消息会结束本轮追问，并在原会话按顺序处理图片，避免图片被丢弃且流程持续等待文字；原提问卡同步移除按钮。连续发图、图片消息去重和普通文字回答沿用既有机制。（[#208](https://github.com/xmanrui/dsh-im/issues/208)）
  When a Feishu question is pending, images and image posts from its initiating user end the question turn and are processed in order in the same Session. Images are no longer discarded while the flow waits for text, and the question card removes its buttons. Existing queueing, deduplication, and text-answer behavior are preserved. ([#208](https://github.com/xmanrui/dsh-im/issues/208))
- 发送时间仅在已启用的上下文增强实际选中并输出该字段时读取；关闭增强、未选择字段或执行本地命令时不读取，时间读取失败不阻断消息处理。
  Send time is read only when an enabled context-enhancement block actually selects and renders the field. Disabled enhancement, unselected fields, and local commands do not read it; an unreadable time does not block message processing.

### Security / 安全

- 将生产依赖 `undici` 从 7.29.0 更新到官方安全修复版 7.29.1，修复本次安装审计报告的 [GHSA-3wwx-pv8p-q78v](https://github.com/advisories/GHSA-3wwx-pv8p-q78v)。这只更新插件依赖，不替代 Node.js 自带网络组件的安全升级。
  Updated the production dependency `undici` from 7.29.0 to the upstream security release 7.29.1, addressing [GHSA-3wwx-pv8p-q78v](https://github.com/advisories/GHSA-3wwx-pv8p-q78v) reported by the release install audit. This updates the plugin dependency, not Node.js's bundled networking components.

### Notes / 使用说明

- 不自动开启上下文增强，也不自动给已有配置添加 `sentAt`。启用并勾选后，发送时间会作为消息上下文提供给模型；时间文本不带时区偏移，可在增强提示词中注明 Host 时区。其他渠道暂不提供该字段。
  Context enhancement is not enabled automatically, and existing field selections do not gain `sentAt` automatically. When enabled and selected, send time is supplied to the model as message context. The text contains no time-zone offset; name the Host time zone in the guidance if needed. Other channels do not currently supply this field.
- 飞书图片接续只由当前提问的发起人触发；若停止提问失败，图片保留在队列中并提示先回答问题或发送 `/stop`，不会伪造文字答案。DSH 0.1.7-alpha.1 兼容性声明保持不变；升级后重启 Host 并刷新设置页。
  Only the initiating user's image interrupts a pending Feishu question. If stopping fails, the image remains queued and the bot asks the user to answer or send `/stop`; no text answer is fabricated. The DSH 0.1.7-alpha.1 compatibility declaration remains unchanged. Restart the Host and refresh settings after upgrading.

## [4.30.0] - 2026-09-28

### Upgrade notes / 升级注意事项

- 飞书「被 @ 时以话题方式回复」现在默认开启，群聊和私聊都会在主时间线中被 @ 提问的消息下创建独立话题；这也会改变已有机器人的默认行为。需要保留平铺回复时，请在机器人卡片「更多设置 → 群聊」中关闭该开关（`mentionTopicReply: false`）。
  Feishu's Reply as a topic when mentioned setting is now on by default in both groups and direct chats, including existing bots. A question mentioning the bot in the main timeline starts a dedicated topic. To retain flat replies, disable the setting under the bot card's More Settings → Group (`mentionTopicReply: false`).
- 旧字段 `groupTopicReply` 不会迁移为新开关的取值，下次保存时会被忽略。相关设置端点由 `bot.group-topic-reply.set` 更名为 `bot.mention-topic-reply.set`；自行接入该端点的客户端需同步调整。升级后请重启 Host 并刷新设置页。
  The old `groupTopicReply` value is not migrated to the new setting and is ignored on the next save. The setting endpoint changes from `bot.group-topic-reply.set` to `bot.mention-topic-reply.set`; custom clients using it must update accordingly. Restart the Host and refresh settings after upgrading.

### Added / 新增

- 飞书由机器人开启的话题对应独立的 DSH 会话，话题内后续消息继续使用同一会话；仅发送 @机器人 不创建话题，没有 @ 的普通消息沿用原有会话及回复规则。感谢 [@yangzhe1991](https://github.com/yangzhe1991)（[#275](https://github.com/xmanrui/dsh-im/pull/275)）。
  Bot-created Feishu topics map to independent DSH Sessions, with follow-up messages staying in the same Session. A bare bot mention does not create a topic, and ordinary messages without a mention retain existing conversation and reply rules. Thanks to [@yangzhe1991](https://github.com/yangzhe1991) ([#275](https://github.com/xmanrui/dsh-im/pull/275)).
- 飞书机器人「更多设置 → 指令面板」可选择跟随插件默认清单，或自定义输入框“/”面板中的内置指令及顺序；支持增删、上下移动，以及确认后将当前配置保存并复制到同渠道其他机器人。离线机器人在下次启动时同步。感谢 [@yangzhe1991](https://github.com/yangzhe1991)（[#274](https://github.com/xmanrui/dsh-im/pull/274)）。
  Feishu More Settings → Command Panel now supports following the shipped defaults or selecting and ordering built-in commands in the input box's slash panel. Commands can be added, removed, and moved up or down; after confirmation, the current configuration can be saved and copied to other bots on the channel. Offline bots synchronize on their next start. Thanks to [@yangzhe1991](https://github.com/yangzhe1991) ([#274](https://github.com/xmanrui/dsh-im/pull/274)).

### Fixed / 修复

- 飞书回复未返回 `thread_id` 时回读根消息并登记话题，包含逐步消息模式，避免话题内追问错误回到主会话。
  Feishu topic registration reads back the root message when a reply omits `thread_id`, including step-by-step message mode, preventing topic follow-ups from falling back to the main conversation.
- 同一机器人的指令面板同步串行执行，新配置使旧同步在后续检查点停止，避免新旧计划交错写入；保存后设置页和后续复制操作使用已保存的新列表，不再回显旧配置。
  Command-panel synchronization runs serially per bot. New settings stop superseded work at subsequent checkpoints to prevent interleaved writes. The settings page and later copy actions retain the newly saved list instead of reverting to stale configuration.

### Notes / 使用说明

- 隐藏面板指令不等于禁用该命令，手动输入仍遵循现有处理及权限规则。默认模式仅补齐缺少项，不删除、不重排已有项；自定义模式按需重建插件清单内的指令，不删除清单外的指令。后台同步可能需要数十秒，保存配置成功不代表飞书面板已经更新完成。
  Hiding a panel entry does not disable the command; typed commands retain existing handling and permission rules. Default mode only adds missing entries without deleting or reordering existing ones. Custom mode rebuilds commands from the plugin manifest when needed and leaves commands outside that manifest untouched. Background synchronization may take tens of seconds; saving settings does not mean the Feishu panel has finished updating.
- 宿主兼容性声明保持 DSH 0.1.7-alpha.1，依赖声明未变。
  Host compatibility remains declared for DSH 0.1.7-alpha.1, and dependency declarations are unchanged.

## [4.29.1] - 2026-09-28

### Changed / 变更

- 新增渐变消息连接图标，并通过 `package.json` 的 `icon` 字段声明；图标资源随 npm 包发布，供支持该元数据的插件界面展示。
  Added a gradient message-link icon declared through the `icon` field in `package.json`. The asset is included in the npm package for plugin interfaces that support this metadata.

### Compatibility / 兼容性

- 本次仅更新插件图标与包元数据，不改变渠道行为、配置、依赖声明或宿主兼容性范围；DSH 兼容性声明保持 0.1.7-alpha.1。
  This release only updates the plugin icon and package metadata. Channel behavior, configuration, dependency declarations, and the Host compatibility range are unchanged; DSH compatibility remains declared for 0.1.7-alpha.1.

## [4.29.0] - 2026-09-28

### Added / 新增

- 飞书新增默认关闭、按机器人启用的语音交互：语音提问经 ASR 转写后进入现有文字处理流程，同回合答案在保留文字回复的同时可合成为语音，包含分步流式卡片完成后的语音回复。转写后继续执行命令权限检查，语音回合按会话隔离，避免同群不同话题之间串音。感谢 [@rosalynthompson32-a11y](https://github.com/rosalynthompson32-a11y)（[#271](https://github.com/xmanrui/dsh-im/pull/271)）。
  Added optional, per-bot Feishu voice interaction, disabled by default. ASR transcripts enter the existing text pipeline, and the same turn's answer can be spoken alongside its text reply, including after step-streaming cards finish. Transcribed commands retain permission checks, while voice turns are isolated per Session to prevent cross-topic replies. Thanks to [@rosalynthompson32-a11y](https://github.com/rosalynthompson32-a11y) ([#271](https://github.com/xmanrui/dsh-im/pull/271)).
- 飞书机器人「更多设置」新增「语音交互」页，可配置凭据引用、ASR/TTS 模型和音色；刷新后恢复已保存配置，关闭开关立即保存。密钥由宿主凭据库解析，配置只保存引用名称。
  Added a Voice Interaction tab in Feishu bot More Settings for the credential reference, ASR/TTS models, and voice. Saved settings survive refresh, disabling is persisted immediately, and configuration stores only a reference to the credential resolved by the Host.

### Fixed / 修复

- 飞书审批在批准、拒绝或已处理后更新原卡片，用结果文字替换操作按钮并保留工具、参数和原因；按钮与文字审批均生效，继续保留原有文字回执。卡片更新失败不会重新提交审批，也不阻断后续审批（[#273](https://github.com/xmanrui/dsh-im/issues/273)）。
  Feishu approvals now update the original card after approval, rejection, or resolution, replacing action buttons with the outcome while retaining tool details, arguments, and reason. Both button and text decisions retain the existing text receipt. Card-update failures neither resubmit the decision nor block later approvals ([#273](https://github.com/xmanrui/dsh-im/issues/273)).
- 邮件审批等待场景的回归测试改为等待实际轮询条件，减少繁忙环境下固定延时造成的偶发失败（[#272](https://github.com/xmanrui/dsh-im/pull/272)）。
  The email pending-approval regression now waits for the actual polling condition, reducing timing-related failures caused by a fixed delay under load ([#272](https://github.com/xmanrui/dsh-im/pull/272)).

### Notes / 使用说明

- 语音交互需要自行准备可用的 ffmpeg 和 DashScope 凭据；默认使用 `qwen3-asr-flash`、`qwen3-tts-flash` 与 `Momo` 音色。启用后，音频会发往所配置的 ASR 服务，回复文本会发往 DashScope TTS；TTS 仅取空白归一化后的前 600 个字符。转写失败时保留不支持类型提示，语音合成失败不影响已发送的文字回复；缺失 ffmpeg 不会导致宿主进程崩溃。npm 安装不会自动安装 ffmpeg。
  Voice interaction requires an available ffmpeg installation and DashScope credential. Defaults are `qwen3-asr-flash`, `qwen3-tts-flash`, and the `Momo` voice. When enabled, audio is sent to the configured ASR service and reply text to DashScope TTS; speech uses only the first 600 characters after whitespace normalization. Transcription failures retain the unsupported-type notice, speech failures leave delivered text intact, and missing ffmpeg does not crash the Host. npm installation does not install ffmpeg.
- 审批卡修复不批量更新旧版本或进程重启前已发出的历史卡片。宿主兼容性声明仍为 DSH 0.1.7-alpha.1；升级后请重启 Host 并刷新设置页。
  The approval fix does not retroactively update cards from older versions or before a process restart. Host compatibility remains declared for DSH 0.1.7-alpha.1; restart the Host and refresh settings after upgrading.

## [4.28.1] - 2026-09-25

### Fixed / 修复

- 默认 IM 工作区改为按实际选择创建：仅加载渠道或使用自定义工作区时，不再生成未使用的 `$DSH_HOME/im` 空目录；机器人或会话选用默认目录、切回默认目录，以及恢复相关 Session 时按需准备目录。已有工作区选择与未分组 Session 行为不变，不自动删除历史目录，也不自动创建任意自定义路径（[#259](https://github.com/xmanrui/dsh-im/issues/259)、[#260](https://github.com/xmanrui/dsh-im/pull/260)）。
  The default IM workspace is now created when selected, rather than generating an unused `$DSH_HOME/im` directory while loading channels or using a custom workspace. Bot/conversation selection, switching back, and relevant Session recovery prepare the directory as needed. Existing workspace choices and ungrouped Session behavior are preserved; old directories are not deleted and arbitrary custom paths are not created automatically ([#259](https://github.com/xmanrui/dsh-im/issues/259), [#260](https://github.com/xmanrui/dsh-im/pull/260)).
- 飞书「实时直播」在需要话题内回复的回合自动使用实时过程卡，让过程和最终答案留在同一话题，避免原生思考过程出现在群聊主时间线。私聊和非话题群聊继续使用原生思考过程，不修改机器人的已保存展示模式。感谢 [@TonyWu2333](https://github.com/TonyWu2333)（[#244](https://github.com/xmanrui/dsh-im/issues/244)、[#265](https://github.com/xmanrui/dsh-im/pull/265)）。
  Feishu Live process mode now uses a streaming process card for turns that must reply inside a topic, keeping progress and the final answer in that topic instead of posting native thinking progress to the main group timeline. Private and non-topic chats retain native thinking messages, and saved bot presentation settings are unchanged. Thanks to [@TonyWu2333](https://github.com/TonyWu2333) ([#244](https://github.com/xmanrui/dsh-im/issues/244), [#265](https://github.com/xmanrui/dsh-im/pull/265)).
- 微信图片与文件的 CDN 上传使用延迟创建、独立管理的网络分发器，避免宿主全局分发器导致成功响应缺少 `x-encrypted-param` 而上传失败；继续遵循环境代理配置，控制器关闭时释放资源，保留现有 JSON 请求和上传重试行为（[#270](https://github.com/xmanrui/dsh-im/issues/270)）。
  Weixin image/file CDN uploads now use a lazy, privately managed dispatcher, avoiding failures when the Host's global dispatcher loses `x-encrypted-param` from otherwise successful responses. Environment proxy settings remain honored, resources are released on controller close, and existing JSON requests and upload retry behavior are preserved ([#270](https://github.com/xmanrui/dsh-im/issues/270)).

### Changed / 变更

- CI 增加 Windows 工作区回归检查，覆盖默认目录创建、工作区切换、绑定恢复及相关并发场景；同步中英文 README 的官方 Token 赞助说明。
  Added Windows CI regression coverage for workspace creation, switching, binding recovery, and related concurrency cases, and clarified official token sponsorship wording in both READMEs.

### Compatibility / 兼容性

- 插件宿主兼容性元数据保持 DSH 0.1.7-alpha.1，不扩大为未经验证的版本范围。升级插件后请重启 Host 并刷新设置页。
  Host compatibility metadata remains declared for DSH 0.1.7-alpha.1 without expanding to unverified versions. Restart the Host and refresh settings after upgrading.

## [4.28.0] - 2026-09-24

### Fixed / 修复

- 飞书分步流式卡片按实际表格数量拆分正文与折叠面板，保留完整表格；重新分片时同步已有卡片，并隔离审批前后的卡片，避免超限、内容缺失或覆盖历史过程。感谢 [@C3H3-AI](https://github.com/C3H3-AI)（[#255](https://github.com/xmanrui/dsh-im/pull/255)）。
  Feishu step-streaming cards split answers and folded panels by their actual table count while preserving complete tables. Existing chunks are synchronized after redistribution, and cards before an interaction remain isolated from later updates. Thanks to [@C3H3-AI](https://github.com/C3H3-AI) ([#255](https://github.com/xmanrui/dsh-im/pull/255)).
- 飞书支持读取转发卡片中的可见文字，私聊仅提及机器人时可打开菜单，并沿用命令权限检查；语音、视频、表情和无可读文字的卡片保留不支持类型提示。感谢 [@C3H3-AI](https://github.com/C3H3-AI)（[#254](https://github.com/xmanrui/dsh-im/pull/254)）。
  Feishu now reads visible text from forwarded cards and opens the menu for a bare private mention with command permissions enforced. Unsupported audio, video, stickers, and unreadable cards retain their existing notice. Thanks to [@C3H3-AI](https://github.com/C3H3-AI) ([#254](https://github.com/xmanrui/dsh-im/pull/254)).
- 修复私聊引用消息后仅提及机器人时，被误判为菜单命令的问题；允许聊天但禁止命令的用户仍可正常提交引用内容。
  Fixed quoted private mentions being classified as menu commands, so users who may chat but cannot run commands can still submit quoted content.

### Notes / 使用说明

- 多表格修复覆盖分步流式卡片及复用该流程的会话镜像。表格数量拆分保持表头、分隔行和数据完整；原有过程摘要和字节预算仍生效，不新增单个超大表格的分页能力，也不将该路径的表格上限推广到所有飞书接口。
  The multi-table fixes cover step-streaming cards and Session mirrors using the same rendering path. Table-count splitting preserves headers, separators, and rows; existing process summaries and byte budgets still apply. This does not add pagination for a single oversized table or generalize this path's table limit to every Feishu API.
- 宿主兼容性声明保持 DSH 0.1.7-alpha.1，未扩展未经验证的版本范围。升级后请重启 Host 并刷新设置页；旧版 DSH 请继续使用对应的历史插件版本。
  Host compatibility remains declared for DSH 0.1.7-alpha.1 without expanding to unverified versions. Restart the Host and refresh settings after upgrading; older DSH installations should use the corresponding historical plugin version.

## [4.27.0] - 2026-09-23

### Added / 新增

- Matrix 新增按机器人、房间隔离的本机群聊记录。在需要提及的群聊中，未点名机器人的发言不会单独触发回复，但后续提及或引用提问可附带当天尚未注入的背景；背景带时间、发言者和明确边界，机器人自己的发言不作为其他成员的背景。感谢 [@Dong09](https://github.com/Dong09)（[#256](https://github.com/xmanrui/dsh-im/pull/256)）。
  Added local Matrix room records isolated by bot and room. In mention-gated groups, unaddressed chatter does not trigger replies by itself, but a later mention or quoted question can include pending same-day background with timestamps, speakers, and explicit delimiters. The bot's own messages are excluded from other-member background. Thanks to [@Dong09](https://github.com/Dong09) ([#256](https://github.com/xmanrui/dsh-im/pull/256)).
- 记录按事件 ID 去重并保存已注入标记，重启后可继续使用；默认每房间保留最近 2000 条，每次背景选择默认最多 50 条、目标字符预算 8000，优先保留较新的发言。新增 `roomContextEnabled`、`roomContextLimit`、`roomContextMaxChars` 和 `roomContextTzOffsetMinutes` 配置字段，并提供记录层的文本、发言者及时间范围查询能力。
  Room records deduplicate event IDs and persist consumed markers across restarts. Defaults retain the latest 2000 entries per room and select up to 50 background entries with a target 8000-character budget, preferring newer messages. Added `roomContextEnabled`, `roomContextLimit`, `roomContextMaxChars`, and `roomContextTzOffsetMinutes` configuration fields, plus record-layer queries by text, speaker, and time range.

### Fixed / 修复

- 修复飞书状态文件一次写入失败后，后续消息持续失败的问题；本次写入仍正常报错，文件恢复可写后，后续消息无需重启机器人即可继续处理（[#250](https://github.com/xmanrui/dsh-im/issues/250)）。
  Fixed a Feishu state-file write failure permanently blocking subsequent messages. The failed write still reports its error, while later messages recover once the file becomes writable, without restarting the bot ([#250](https://github.com/xmanrui/dsh-im/issues/250)).
- Matrix 不再仅凭房间只有两名成员就将其视为私聊，避免普通小群绕过提及要求；启动时清理缺少账号直接会话信息或路由依据的旧分类，邀请处理区分直接会话标记。
  Matrix no longer treats a two-member room as a direct chat solely by member count, preserving mention requirements for ordinary small groups. Startup discards stale classifications without account direct-chat data or routing evidence, and invitation handling distinguishes direct-chat flags.

### Compatibility / 兼容性

- 更新面板补充 4.27.0 的宿主版本提示：最低基线为 DSH 0.1.7-alpha.1；当前实际验证并在插件元数据中声明的版本仍为 0.1.7-alpha.1，更新宿主版本需另行验证。旧版 DSH 请继续使用 dsh-im 4.25.0；升级后重启 Host 并刷新设置页。
  Added the 4.27.0 Host-version notice to the update panel. The minimum baseline is DSH 0.1.7-alpha.1; this remains the version actually verified and declared in plugin metadata, while newer Host releases require separate validation. Older DSH users should stay on dsh-im 4.25.0. Restart the Host and refresh settings after upgrading.

### Notes / 使用说明

- Matrix 群聊背景记录默认开启，会在机器人目录的 `matrix-history.json` 中保存本机明文记录，并可能随后发送给模型；请按群成员的隐私预期使用。可通过 `roomContextEnabled: false` 停止新增记录与背景注入，但不会自动删除已有记录。背景按房间共享，不按发言者或 Session 单独分隔，也不是群聊全量历史归档。
  Matrix room context is enabled by default. Plaintext records are stored locally in the bot's `matrix-history.json` and may later be sent to the model; use according to participants' privacy expectations. `roomContextEnabled: false` stops new recording and background injection without deleting existing records. Background is shared per room rather than isolated by speaker or Session, and is not a complete room-history archive.
- Matrix 仍为实验性渠道，本次未进行真实 homeserver／Element 互通测试；4.25.0 所述设备验证、密钥备份、SSSS 和附件加密限制仍然适用。
  Matrix remains experimental, with no live homeserver/Element interoperability test in this release. The device-verification, key-backup, SSSS, and attachment-encryption limitations documented for 4.25.0 still apply.

## [4.26.0] - 2026-09-23

### Compatibility / 兼容性与升级提示

- 本版仅面向 **DSH 0.1.7-alpha.1** 的 Session V4 契约，并更新插件兼容性声明。请先升级 DSH，再升级 dsh-im，随后重启 Host 并刷新设置页；使用旧版 DSH 的用户请保留 dsh-im 4.25.0。本版不新增旧宿主兼容分支，也不承诺未经验证的后续版本。
  This release targets the Session V4 contract in **DSH 0.1.7-alpha.1** and updates the compatibility manifest. Upgrade DSH first, then dsh-im, restart the Host, and refresh settings. Users on older DSH versions should stay on dsh-im 4.25.0. No new legacy-Host compatibility branches or unverified future-version guarantees are added.

### Added / 新增

- 主动投递服务、`message.send` RPC 及 HTTP 接口新增可选 `format: "markdown"`。飞书私聊和群聊可发送 Markdown 卡片，保留原始文本与换行；默认仍为纯文本，其他渠道沿用原有行为，不保证 Markdown 渲染。感谢 [@alpacachen](https://github.com/alpacachen)（[#246](https://github.com/xmanrui/dsh-im/pull/246)）。
  Added optional `format: "markdown"` to proactive delivery, the `message.send` RPC, and HTTP endpoint. Feishu DMs and groups can receive Markdown cards with original text and line breaks preserved. Plain text remains the default; other channels retain their existing behavior without a Markdown-rendering guarantee. Thanks to [@alpacachen](https://github.com/alpacachen) ([#246](https://github.com/xmanrui/dsh-im/pull/246)).
- 新增基于真实 DSH JSONL 持久化的上下文验证脚本，覆盖普通消息、来源、指导语、引用和结构化内容，以及关闭重开后的后续回合；脚本随 npm 包发布。
  Added a real-DSH JSONL persistence verification script covering plain, source, guidance, quoted, and structured messages, including reopening and subsequent turns. The script is included in the npm package.

### Fixed / 修复

- 注入的来源信息、会话指导语及引用上下文改用 `source.kind: "plugin:dsh-im"`，适配 DSH 0.1.7-alpha.1 对消息来源的要求，修复 `SessionFormatError: format v4 message requires a producer-owned source kind`。保留用户正文、消息顺序及指导语去重行为；历史 Session 迁移仍由宿主负责。
  Injected source, guidance, and quoted context now use `source.kind: "plugin:dsh-im"`, fixing `SessionFormatError: format v4 message requires a producer-owned source kind` on DSH 0.1.7-alpha.1. User content, message ordering, and guidance deduplication are preserved; historical Session migration remains the Host's responsibility.

### Changed / 变更

- 优化图片输入设置的字段对齐、保存与重试区域，将说明收纳至带无障碍描述的帮助提示；原有限制值和默认行为不变。
  Aligned image-input settings and save/retry controls, moving explanatory text into an accessible help tooltip without changing limits or defaults.
- 完善中英文主动投递文档与回归测试：Markdown 卡片不静默截断或自动拆分；发送失败或结果不确定时不自动改发纯文本，避免重复投递。
  Expanded bilingual proactive-delivery documentation and regression coverage. Markdown cards are not silently truncated or automatically split, and failures or uncertain outcomes do not trigger automatic plain-text retries that could duplicate delivery.

## [4.25.0] - 2026-09-22

### Added / 新增

- 新增 Matrix 实验性渠道，可使用 homeserver 与访问令牌，或用户 ID 与密码接入；支持私聊、群聊提及、线程回复、HTML 白名单富文本、编辑式流式输出、输入状态及图片和结果文件回传。纳入现有机器人设置、工作区与会话绑定、访问策略和主动投递体系。感谢 [@Dong09](https://github.com/Dong09)（[#245](https://github.com/xmanrui/dsh-im/pull/245)）。
  Added an experimental Matrix channel using a homeserver with an access token or a user ID/password. It supports DMs, room mentions, thread replies, allowlisted HTML, edit-based streaming, typing indicators, and image/result-file delivery, integrated with bot settings, workspaces, Session bindings, access policies, and proactive delivery. Thanks to [@Dong09](https://github.com/Dong09) ([#245](https://github.com/xmanrui/dsh-im/pull/245)).
- Matrix 加入本机加密状态存储、设备密钥注册、Megolm 房间消息加解密及设备间密钥共享的实验性实现，依赖固定版本 `@matrix-org/olm@3.2.15`。配置支持 `off`、默认 `optional` 和 `required`；引擎启动失败时，optional 模式跳过收到的加密消息，required 模式拒绝启动连接。
  Added experimental Matrix local crypto state, device-key registration, Megolm room-message encryption/decryption, and to-device key sharing using pinned `@matrix-org/olm@3.2.15`. Configuration supports `off`, default `optional`, and `required`: failed crypto startup skips incoming encrypted traffic in optional mode and prevents connection startup in required mode.

### Changed / 变更

- 「检查更新」改为图标按钮，通过悬停提示与无障碍标签展示检查中、可更新版本、安装中或待手动重启状态，保留原有更新对话框和确认流程。
  Replaced the update-check text button with an icon whose tooltip and accessible label reflect checking, the available version, installation, or a required manual restart, preserving the update dialog and confirmation flow.
- Matrix 导航明确标注「实验功能」，补充渠道标识、中英文文案、集成说明及自动化测试，并纠正 README 中「始终跳过加密房间」的旧描述。
  Marked Matrix as experimental in navigation, added channel branding, Chinese/English copy, integration notes, and automated tests, and corrected the outdated README statement that encrypted rooms are always skipped.

### Known limitations / 已知限制

- Matrix 加密仍为实验性能力，本次发布验证不包含真实 homeserver／Element 互通测试；未实现交互式设备验证、密钥备份及 SSSS，媒体附件内容也未做附件级加密。请仅在非敏感测试场景试用，不要将其视为完整的端到端保密保障。
  Matrix encryption remains experimental; release validation does not include live homeserver/Element interoperability testing. Interactive device verification, key backup, SSSS, and attachment-content encryption are not implemented. Use only for non-sensitive testing, not as a complete end-to-end confidentiality guarantee.

## [4.24.1] - 2026-09-22

### Fixed / 修复

- 飞书话题首文在同一 AI 会话成功使用后不再重复注入；命令、拒绝消息及读取或请求失败不提前消耗首文，`/new`、会话切换或失效重建后重新附带。普通群聊和私聊的主动引用保持原有行为。感谢 [@yangzhe1991](https://github.com/yangzhe1991) 提出并实现首文去重（[#222](https://github.com/xmanrui/dsh-im/pull/222)）。
  Feishu topic roots are no longer injected repeatedly after a successful turn in the same AI session. Commands, rejected messages, and failed lookups or requests do not consume the root; new, switched, or rebuilt sessions receive it again. Explicit quotes in ordinary groups and direct chats retain their existing behavior. Thanks to [@yangzhe1991](https://github.com/yangzhe1991) for proposing and implementing topic-root deduplication ([#222](https://github.com/xmanrui/dsh-im/pull/222)).

- 修复通过终端或插件市场升级、回退后，历史更新记录持续阻止后续安装的问题。重启 Host 后，在无安装锁、当前安装校验通过且运行版本与已安装版本一致时重新判定可恢复状态；不删除历史记录，也不绕过安装锁、版本兼容性、确认有效期或手动重启要求。
  Fixed historical update jobs blocking later installs after an external upgrade or rollback. After restarting the Host, recovery is derived from a valid current installation with no install lock and matching running/installed versions. History remains intact, and install locks, compatibility checks, confirmation expiry, and manual-restart requirements remain enforced.
- 更新面板优先展示本次检查结果，区分「最新版本」「上次更新目标」与正在安装的「目标版本」，避免旧任务遮盖新版本或错误状态；打开符合条件的面板时重新检查更新，手动命令不再沿用可恢复历史任务的旧目标。已被旧版更新器阻塞的用户，需先通过手动命令或插件市场安装含修复的版本，再手动重启 Host。
  The update panel now prioritizes fresh checks and distinguishes Latest version, Previous update target, and an active Target version, so old jobs cannot hide available updates or errors. Eligible panel openings check again, and manual commands ignore recoverable historical targets. Users already blocked by the old updater must first install a fixed version through the manual command or plugin market, then restart the Host manually.

### Changed / 变更

- 统一机器人卡片设置入口：卡片顶部使用齿轮与箭头展开或收起常用配置，「更多设置」移入展开区域；调整图标间距，保留键盘操作、展开状态提示及收起后隐藏控件的无障碍行为。
  Unified bot-card settings entry points: a gear-and-chevron control expands or collapses common settings, with More settings inside the expanded area. Balanced icon spacing while preserving keyboard interaction, expanded-state announcements, and accessibility hiding for collapsed controls.
- 补充飞书话题首文去重贡献者信息，并完善飞书实时直播功能对 [@ShawnKung](https://github.com/ShawnKung) 的文档致谢（[#243](https://github.com/xmanrui/dsh-im/pull/243)）。
  Added contributor credits for Feishu topic-root deduplication and completed the documentation attribution to [@ShawnKung](https://github.com/ShawnKung) for Feishu Live process mode ([#243](https://github.com/xmanrui/dsh-im/pull/243)).

## [4.24.0] - 2026-09-21

### Added / 新增

- 飞书任务过程展示新增「实时直播」，使用原生思考过程消息展示当前任务的推理片段、工具调用、参数及结果，最终答案仍以普通富文本消息单独发送。推理通过实时连接补充，工具进度和最终结果沿用历史轮询；过程写入采用非阻塞批处理，原生过程不可用时不影响最终答案。已有机器人不自动切换展示模式。感谢 [@ShawnKung](https://github.com/ShawnKung)（[#224](https://github.com/xmanrui/dsh-im/pull/224)）。
  Added Feishu Live process mode, using native thinking-process messages for the current task's reasoning snippets, tool calls, arguments, and results while delivering the final answer separately as rich text. Live connections supplement reasoning; history polling remains authoritative for tool progress and final results. Process writes use non-blocking batches, and process failures do not suppress the answer. Existing bots keep their selected presentation mode. Thanks to [@ShawnKung](https://github.com/ShawnKung) ([#224](https://github.com/xmanrui/dsh-im/pull/224)).
- Telegram 新增每机器人独立的「会话行为 → 思考过程留痕」开关，将推理摘要和工具调用摘要作为独立的 💭／🔧 消息保留，最终答案另发。默认开启（含未设置该字段的已有机器人），显式关闭后恢复原有回复方式；中间留痕发送失败不阻止最终答案，长任务继续显示输入状态。留痕可能包含工具参数摘要，请按聊天受众选择是否开启。感谢 [@gin-melodic](https://github.com/gin-melodic)（[#203](https://github.com/xmanrui/dsh-im/pull/203)、[#235](https://github.com/xmanrui/dsh-im/pull/235)）。
  Added a per-bot Telegram Thinking traces toggle under Conversation behavior. Reasoning and tool-call summaries remain as separate 💭/🔧 messages, followed by the final answer. It defaults on, including existing bots without the field; explicitly disabling it restores the previous reply presentation. Trace-send failures do not prevent the final answer, and long-running tasks keep the typing indicator. Traces can include tool-argument summaries, so choose the setting for the chat's audience. Thanks to [@gin-melodic](https://github.com/gin-melodic) ([#203](https://github.com/xmanrui/dsh-im/pull/203), [#235](https://github.com/xmanrui/dsh-im/pull/235)).

### Fixed / 修复

- 飞书直播以历史记录恢复最终答案和任务结束，避免断线重连后的较新实时事件跳过尚未补回的回复。提前到达的推理采用有界暂存，确认请求与回合归属后才展示；同时处理排序、去重及结束后的迟到片段，避免排队请求混入上一轮推理。最终答复使用最后一步定稿内容，长工具参数和结果按协议限制截断。
  Feishu live replies recover final answers and completion from history so newer events after a reconnect cannot skip missing replies. Early reasoning is buffered within fixed limits and displayed only after request/turn correlation, with ordering, deduplication, and late-frame handling that keep queued requests separate. Final replies use the last step's canonical text, and long tool arguments/results are bounded for the protocol.
- Telegram 留痕模式的最终答案保留 Markdown、代码块及原有空行，不再按空段落预先拆分；纯文本重试保留原文，只重发明确失败的未发送部分，投递结果不确定时不自动重发。
  Telegram thinking-mode final answers preserve Markdown, fenced code, and original blank lines without pre-splitting on empty paragraphs. Plain-text retries preserve content and resend only the definitively failed unsent tail; uncertain delivery is not automatically retried.
- 修复邮件模型输入丢失主题等邮件头、腾讯 Agent 邮箱附件下载返回加载函数而非内容的问题；初始化收信游标只读取邮件列表摘要，不提前下载可能不在白名单内的正文。保留纯正文命令解析和现有延迟图片处理。感谢 [@C3H3-AI](https://github.com/C3H3-AI)（[#233](https://github.com/xmanrui/dsh-im/pull/233)）。
  Fixed email model input losing subject/header context and Agent Mail attachment loaders returning functions instead of bytes. Initial receive cursors now use list summaries without fetching potentially disallowed message bodies. Plain-body command parsing and deferred image handling are preserved. Thanks to [@C3H3-AI](https://github.com/C3H3-AI) ([#233](https://github.com/xmanrui/dsh-im/pull/233)).
- 补齐飞书原生斜杠命令面板中的工作区、会话绑定、模型、推理等级、预设、停止、补充指令、批量输入、版本及修复等现有命令入口，同步命令文档与测试。
  Completed Feishu's native slash-command panel entries for existing workspace, Session binding, model, reasoning effort, preset, stop, steer, batch-input, version, and repair commands, with updated documentation and tests.

### Changed / 变更

- 设置页 GitHub 入口改用 Logo，保留链接及无障碍标签；补充飞书直播、Telegram 留痕及邮件回归测试和验证记录。移除带固定本机路径和聊天目标的 Telegram 实测脚本，并将 npm 包内的脚本收紧为明确的验证脚本清单。
  Replaced the settings-page GitHub text button with a logo while preserving its link and accessible label, and expanded Feishu live-process, Telegram trace, and email regression coverage and verification records. Removed the machine-specific Telegram live-test script and restricted packaged scripts to an explicit verification-script allowlist.

## [4.23.0] - 2026-09-20

### Added / 新增

- 新增邮件渠道，支持标准 IMAP/SMTP 邮箱及通过官方 `@tencent-qqmail/agently-cli` 接入腾讯 Agent 邮箱；可在设置页管理多邮箱、发件人白名单、工作区、模型和 Session 绑定，并收发邮件正文及附件（[#223](https://github.com/xmanrui/dsh-im/pull/223)，感谢 [@C3H3-AI](https://github.com/C3H3-AI)）。邮件线程与绑定持久化，补齐分页收信、失败重试、限流退避和自动回复防循环。渠道默认可用，但需自行绑定邮箱；可用 `EMAIL_CHANNEL_ENABLED=0` 或 `emailChannelEnabled: false` 关闭，保留已有配置。空白名单不接收任何发件人的请求；邮件发件人地址可被伪造，白名单不能替代身份认证，应仅接入可信来源。
  Added an email channel for standard IMAP/SMTP mailboxes and Tencent Agent Mail through the official `@tencent-qqmail/agently-cli`, with multiple mailboxes, sender allowlists, workspace/model selection, Session bindings, and text/attachment delivery ([#223](https://github.com/xmanrui/dsh-im/pull/223), thanks to [@C3H3-AI](https://github.com/C3H3-AI)). Threads and bindings persist across restarts, with paginated polling, bounded retries, rate-limit backoff, and automatic-reply loop prevention. The channel is available by default but requires mailbox setup; `EMAIL_CHANNEL_ENABLED=0` or `emailChannelEnabled: false` disables it without deleting configuration. Empty allowlists admit nobody. Sender addresses can be spoofed, so allowlists are not identity authentication; connect only trusted sources.
- 新增「通用设置 → 附件 → 图片输入」四项限制：原图单张大小、单条消息图片数、模型单张图片预算和模型总图片预算。默认分别为 30 MB、20 张、5 MB 和 20 MB，设置对后续消息生效，仍受平台及 Host 限制。
  Added four Image input limits under General settings → Attachments: original image size, images per message, per-image model budget, and total model budget. Defaults are 30 MB, 20 images, 5 MB, and 20 MB respectively. Changes apply to subsequent messages and remain subject to platform and Host limits.

### Changed / 变更

- 图片原文件先保存到 Session 工作区并遵循附件保留设置；使用可选 `sharp` 为模型生成预算内的缩放或压缩副本。无法压缩、超出预算、缺少可选编解码器或 Host 拒绝图片输入时，按适用条件回退为工作区文件，并明确提示未直接提供给模型的图片，不丢弃已保存的原图。
  Original images are saved to the Session workspace under attachment-retention rules before optional `sharp` resizing/compression produces model copies within budget. Images fall back to workspace files where applicable when compression is unavailable or fails, budgets are exceeded, or the Host rejects image input, with explicit notices identifying images not directly provided to the model; saved originals are retained.
- 将连接诊断扩展到全部渠道，保留失败阶段、可识别的底层原因、HTTP 状态、时间和回滚结果，设置页可展开并复制诊断信息。诊断引用可关联 Host 日志；对外仅输出允许的诊断字段，并保留删除成功但清理失败的警告。
  Extended connection diagnostics across all channels, preserving failure stages, recognized underlying causes, HTTP status, timing, and rollback results, with expandable/copyable details in settings. References correlate with Host logs; public diagnostics use admitted fields and retain warnings when removal succeeds but cleanup fails.

### Fixed / 修复

- 修复 WhatsApp 群聊中其他成员通过 LID 提及或引用回复机器人时没有响应的问题（[#221](https://github.com/xmanrui/dsh-im/issues/221)）。恢复 3.0.3 的账号别名识别，使用当前连接提供的手机号 ID 和 LID 识别提及、回复及自聊；继续遵守现有群聊访问权限。
  Fixed WhatsApp group mentions and quoted replies from other members being ignored when they address the bot by LID ([#221](https://github.com/xmanrui/dsh-im/issues/221)). Restored the account-alias matching from 3.0.3, using the current connection's phone-number ID and LID for mentions, replies, and self-chat while preserving existing group access policies.
- 工具已完成处理但没有文本或文件回复时，返回明确的完成提示，不再误报模型空回复；文件交付失败仍报告原错误，并为回合失败补充关联信息。
  Completed tool-only turns without text or file replies now return an explicit completion notice instead of being misreported as empty model responses. Artifact handoff failures retain their original errors, and turn failures include correlation details.
- 邮件渠道可用性查询补齐请求载荷，修复设置页查询失败；同步生成的客户端与 Host 产物，并补充邮件、图片输入、连接诊断和 WhatsApp 的回归测试。
  Added the request payload to email availability queries to fix settings-page checks, synchronized generated client/Host artifacts, and expanded email, image-input, connection-diagnostic, and WhatsApp regression coverage.

## [4.22.0] - 2026-09-19

### Added / 新增

- 新增可选客户端服务 `dshImClient` v1，宿主可通过 `render({ preferredSectionId })` 嵌入完整 IM 管理面板，并用 `setSettingsVisible(boolean)` 隐藏或恢复本客户端的设置入口；`settingsVisible()` 返回入口是否已注册（[#231](https://github.com/xmanrui/dsh-im/issues/231)）。默认仍保留「设置 → IM机器人」，不需要迁移数据或新增配置，Host 侧主动投递服务 `dshIm` 不变。
  Added the optional `dshImClient` v1 client service so shells can embed the complete IM management panel with `render({ preferredSectionId })`, hide or restore this client's settings entry with `setSettingsVisible(boolean)`, and check its registration with `settingsVisible()` ([#231](https://github.com/xmanrui/dsh-im/issues/231)). Settings → IM bots remains the default without migration or new configuration; the Host-side `dshIm` delivery service is unchanged.
- 嵌入面板复用现有 RPC、权限、目录选择和语言服务，保持组件身份稳定，避免重复渲染重置未保存表单；支持首次栏目选择、语言刷新及局部错误重试。入口开关只作用于当前客户端内存，不影响其他浏览器或机器人运行；不支持新服务的旧宿主继续使用原设置页。接口 v1 面向单个活跃管理面板，不提供多面板状态同步。
  Embedded panels reuse existing RPC, permissions, directory selection, and locale services, with stable component identity to preserve unsaved forms across re-renders. Initial-section selection, locale updates, and local error recovery are supported. Visibility is in-memory and client-local, without affecting other browsers or running bots; older Hosts retain the original settings page. V1 targets one active management panel and does not synchronize multiple panels.

### Changed / 变更

- 新机器人默认工作目录由 Host 当前目录改为 `$DSH_HOME/im`，未设置时使用 `~/.dsh/im`，默认目录自动创建；显式 `workspace` 优先，`dshHome` 可覆盖环境变量。默认目录中的新 Session 保持「未分组」，切换到其他目录时继续使用原工作区分组机制，切回默认目录后新 Session 恢复未分组。已有机器人的目录和历史 Session 不自动迁移；各机器人仍独立保存聊天与 Session 的绑定。
  New bots default to `$DSH_HOME/im` instead of the Host's current directory, falling back to `~/.dsh/im`; the default directory is created automatically. Explicit `workspace` takes precedence, and `dshHome` overrides the environment variable. New Sessions in the default directory remain ungrouped, while other directories retain workspace grouping. Existing bot directories and historical Sessions are not migrated, and each bot retains independent chat-to-Session bindings.

### Fixed / 修复

- 默认 IM 目录的 `/sessionlist`／`/sessions` 识别工作目录匹配的未分组 Session，排除已归属其他工作区分组的会话；普通未分组 Session 可按 ID 或当前列表序号绑定，重启后也能重新识别已有绑定。路径比较兼容符号链接，默认目录创建失败时直接报告错误，不退回 Host 当前目录。
  `/sessionlist` and `/sessions` include ungrouped Sessions whose working directory matches the default IM directory, without including Sessions assigned to other workspace groups. Ordinary ungrouped Sessions can be bound by ID or current-list index, and existing bindings remain recognizable after restart. Path matching supports symbolic links; default-directory creation errors are reported instead of falling back to the Host's current directory.

### Documentation / 文档

- 新增中英文客户端接入文档并随 npm 包发布，记录服务契约、生命周期、权限及兼容边界；同步默认目录与会话命令说明。仓库提供独立的 `integrations/desktop-panel` 可选桌面接入示例，它不随 dsh-im npm 包发布，也不代表桌面端已内置入口。
  Added a bilingual client integration guide to the npm package covering the service contract, lifecycle, permissions, and compatibility, and updated default-directory and Session-command guidance. The repository includes an optional standalone `integrations/desktop-panel` integration; it is excluded from the dsh-im npm package and does not imply a built-in desktop entry.

## [4.21.2] - 2026-09-17

### Fixed / 修复

- 修复 Lark（飞书国际版）应用无法通过手动凭据入口接入的问题（[#212](https://github.com/xmanrui/dsh-im/issues/212)）。飞书设置页的「手动接入」可选择飞书或 Lark，绑定请求将所选平台传给 Host，并沿用该平台进行凭据验证、配置保存及 HTTP／WebSocket 连接；未指定平台的旧请求仍默认使用飞书。感谢 [@alpacachen](https://github.com/alpacachen) 的代码与测试贡献（[#219](https://github.com/xmanrui/dsh-im/pull/219)）。
  Fixed Lark (international Feishu) applications being unable to connect through manual credential binding ([#212](https://github.com/xmanrui/dsh-im/issues/212)). The Feishu settings page now offers a Feishu/Lark platform selector for manual setup. The selected platform is passed to the Host and used for credential verification, persisted configuration, and HTTP/WebSocket connections; existing requests without a platform still default to Feishu. Thanks to [@alpacachen](https://github.com/alpacachen) for code and tests in [#219](https://github.com/xmanrui/dsh-im/pull/219).
- 切换应用平台时清空已填写的 App ID、App Secret 和旧错误，避免跨平台复用凭据；提交期间锁定表单及平台选择，防止重复提交。补齐 Lark 绑定表单和成功提示的中英文文案，Host 仅接受 `feishu`、`lark` 或省略的平台值。
  Changing platforms clears the entered App ID, App Secret, and previous error to avoid reusing credentials across platforms. The form and platform selector are locked during submission to prevent duplicate requests. Added bilingual Lark form and success messages; the Host accepts only `feishu`, `lark`, or an omitted platform value.

### Documentation / 文档

- 补充自定义域名访问 IM 管理接口时的 HTTP 403 排查说明：通过 DSH 的 `--trusted-host` 配置域名及可选端口，反向代理需保留匹配的 Host／Origin，浏览器认证仍然必需；该文档更新不放宽访问控制。
  Documented HTTP 403 troubleshooting for IM management through custom domains: configure the domain and optional port with DSH's `--trusted-host`, preserve matching Host/Origin values through reverse proxies, and retain browser authentication. This documentation update does not relax access controls.
- 扩展局域网管理验证脚本，覆盖回环地址、局域网地址、自定义域名、未认证访问及 Host／Origin 不匹配，并等待渠道初始化完成后检查业务状态；新增 Lark 界面、RPC、配置持久化和运行时域名选择的回归测试。
  Expanded the LAN management verification script to cover loopback, LAN addresses, custom domains, unauthenticated access, and Host/Origin mismatches, waiting for channel initialization before checking business status. Added Lark regression tests for the UI, RPC validation, persisted configuration, and runtime domain selection.

## [4.21.1] - 2026-09-16

### Fixed / 修复

- 修复钉钉群聊和私聊中引用图片、文件、富文本图片及音视频附件时，模型只收到引用说明而无法读取实际内容的问题（[#211](https://github.com/xmanrui/dsh-im/issues/211)）。仅解析直接引用的一层附件，保留当前消息附件并按下载引用去重；命令、权限校验与交互路由完成后才下载。缺少下载信息或下载失败时明确提示，不再把仅有元数据的请求送入模型。
  Fixed quoted images, files, rich-text images, and audio/video attachments in DingTalk group and direct chats reaching the model as descriptions without their actual content ([#211](https://github.com/xmanrui/dsh-im/issues/211)). Only the immediate quote is resolved, current attachments are preserved, and matching download references are deduplicated. Downloads happen after command, access, and interaction routing; missing references or failed downloads report an error instead of submitting metadata alone.
- 微信文件上传改为分块流式加密，由网络背压控制读取，减少整份密文复制。将固定 60 秒上传截止时间改为 60 秒无进展超时，持续传输的大文件不再因总耗时超过一分钟被中断；重试重新创建加密流，用户取消立即停止，失败不发送文件消息，并提供明确的上传超时提示。
  Weixin file uploads now encrypt in chunks with network backpressure, reducing whole-file ciphertext copies. A 60-second idle timeout replaces the fixed upload deadline, allowing transfers that continue making progress to exceed one minute. Retries recreate the encrypted stream, caller cancellation stops immediately, and failed uploads never send a file message and report an explicit timeout when stalled.
- IM 来源块与引用块按实际消息身份配对，在支持的 Host 中拆成独立、可折叠的 `dsh-im` 上下文行；用户消息保留自己的正文，引用材料排在提问之前，并发或在途消息不会串用来源。只选择 `botId`、`chatId` 或 `threadId` 时仍正确拆分，无法生成摘要时使用「来源」标题；不支持拆分或连接外部 Harness 时保留内联回退。
  IM source and quoted-reply blocks are paired by message identity and split into separate, collapsible `dsh-im` context rows on supported Hosts. User messages retain their own text, quotations precede the question, and concurrent or in-flight prompts cannot exchange sources. ID-only field selections still split correctly and use a Source label when no readable summary exists; unsupported Hosts and external Harness connections retain the inline fallback.
- `/补充指令`（`/steer`）按执行时的增强配置记录实际下达指令者的来源，卡片使用操作者身份，菜单和消息使用发送者身份，不再借用开启该回合的消息来源。感谢 [@Librazy](https://github.com/Librazy) 的实现、测试与文档贡献（[#204](https://github.com/xmanrui/dsh-im/pull/204)）。
  `/steer` captures enhancement settings when the correction is issued and records its actual author: the card operator or the menu/message sender, rather than the author of the turn's opening message. Thanks to [@Librazy](https://github.com/Librazy) for implementation, tests, and documentation in [#204](https://github.com/xmanrui/dsh-im/pull/204).

### Changed / 变更

- 上下文增强提示词登记为会话级动态提示词上下文，不再逐条消息重复，配置变化时重新渲染。提示词中的 `{{变量}}` 按部署注册的变量解析，未知或格式错误的变量会使当前步骤失败；是否保留动态上下文由 Host 部署策略决定。
  Context-enhancement guidance is registered as Session-level dynamic prompt context instead of repeating in each message, and re-rendered when its configuration changes. `{{variable}}` references use the deployment's registered template variables; unknown or malformed references fail the current step. Host deployment policy controls whether dynamic context is retained.

### Security / 安全

- 会话增强提示词仅来自渠道捕获的配置，不从用户消息中的仿造标签回读；关闭增强时清除登记。来源块采用受限字段识别，避免将形状不符的用户 JSON 误当成插件上下文。
  Session guidance comes only from configuration captured by the channel, never from lookalike tags in user text, and is cleared when enhancement is disabled. Source blocks use restricted-field recognition so unrelated user JSON is not mistaken for plugin context.

### Documentation / 文档

- 更新上下文增强说明和钉钉引用附件修复记录，补充消息配对、纠偏来源、实际附件内容、微信流式上传、超时重试及取消的回归测试。
  Updated context-enhancement guidance and DingTalk quoted-attachment repair notes, with regression tests for message pairing, correction provenance, actual attachment content, Weixin streaming uploads, timeout retries, and cancellation.

## [4.21.0] - 2026-09-16

### Added / 新增

- Telegram 单选型 Harness 提问支持 Inline Keyboard，点击按钮即可提交，编号文字回复仍然有效。多选、超过八个选项、按钮标签不可用或平台拒绝键盘时回退到文本流程；回调数据使用短编码并校验 Telegram 的 64 字节限制（[#199](https://github.com/xmanrui/dsh-im/issues/199)）。感谢 [@wings1848](https://github.com/wings1848) 的代码、文档与测试贡献（[#206](https://github.com/xmanrui/dsh-im/pull/206)）。
  Telegram single-choice Harness questions now support inline keyboards: press a button to answer, or keep replying with numbered text. Multi-select questions, more than eight options, unusable button labels, or keyboard rejection fall back to text. Compact callback data is validated against Telegram's 64-byte limit ([#199](https://github.com/xmanrui/dsh-im/issues/199)). Thanks to [@wings1848](https://github.com/wings1848) for code, documentation, and tests in [#206](https://github.com/xmanrui/dsh-im/pull/206).

### Fixed / 修复

- Harness 提问允许 IM 与 Web／CLI 同时呈现，先作答者生效；另一端及时收回待答项和卡片。取消范围限定到当前问题，避免 IM 正常作答误取消外层 `run_code`／PTC 执行，真正的上游取消仍会传递。
  Harness questions can be presented on IM and Web/CLI together, with the first answer winning and the other side's pending question and card retired. Cancellation is scoped to the current question, so an IM answer does not cancel an enclosing `run_code`/PTC execution, while genuine upstream cancellation still propagates.
- Telegram 卡片提交前等待展示完成，拒绝提交期间的重复点击；文字回答也会回收旧键盘，旧卡片不能回答后续问题。数字标签按钮直接提交所选选项，不再把标签误解析为位置序号；手动输入数字仍按位置选择。宿主应答链仅对 `NO_PROVIDER` 静默降级，其他错误保留日志。
  Telegram card answers wait for presentation to finish, reject duplicate presses during submission, and retire keyboards after text answers so stale cards cannot answer later questions. Numeric button labels submit the exact selected option instead of being reinterpreted as positions; typed numbers still select by position. Only `NO_PROVIDER` is silently handled in the host answerer chain; other failures are logged.
- 批量输入收集期间，带引用的 `/send`、`/cancel` 和重复 `/batch` 正常提交、取消或报告进度；空闲时的 `/send`、`/cancel` 返回准确状态。命令携带的引用或附件不混入批量内容，会话标题取第一条已收录内容，而非插件框架句。首次开启批次仍需要纯文字 `/batch`。感谢 [@Librazy](https://github.com/Librazy) 的代码、文档与测试贡献（[#205](https://github.com/xmanrui/dsh-im/pull/205)）。
  During batch collection, quoted `/send`, `/cancel`, and repeated `/batch` commands submit, cancel, or report progress normally; idle `/send` and `/cancel` return accurate state messages. Command-carried quotes and attachments stay out of submissions, and Session titles use the first collected message rather than plugin framing. Starting a batch still requires plain-text `/batch`. Thanks to [@Librazy](https://github.com/Librazy) for code, documentation, and tests in [#205](https://github.com/xmanrui/dsh-im/pull/205).
- QQ 本地状态 JSON 损坏时，先以独占文件保存原始字节备份，再重建状态，避免机器人因解析失败无法启动（[#215](https://github.com/xmanrui/dsh-im/issues/215)）。恢复会重置该机器人的会话映射、消息去重和延迟投递记录，并在 Host 日志中提示；备份失败时保留原文件，读取、备份和写入失败分别通过管理接口报告。
  Corrupt QQ state JSON is backed up byte-for-byte to an exclusive file before state is rebuilt, allowing startup to recover from parse errors ([#215](https://github.com/xmanrui/dsh-im/issues/215)). Recovery resets that bot's Session mappings, message deduplication, and deferred-delivery records and reports this in Host logs. A failed backup preserves the original file; read, backup, and write failures retain distinct management-interface errors.
- 微信启动配置错误标明配置文件、从零开始的字段位置和校验原因，区分 JSON 语法、账号标识、重复账号、工作区及模型配置等问题；页面、复制诊断和参考号对应日志保持一致，不包含账号、配置值、凭据或本机绝对路径，并明确修复配置后需要重启 DSH。
  Weixin startup configuration errors identify the file, zero-based field position, and validation issue, distinguishing JSON syntax, account identity, duplicates, workspace, and model settings. The page, copied diagnostics, and correlated logs retain matching details without account identities, configuration values, credentials, or absolute local paths, and explain that DSH must restart after configuration repair.
- `dsh_im_return_file` 优先采用 Session 事件流观察到的活动回合，修复实际宿主不公开事件快照时误报 `artifact-context-required`、文件无法进入投递流程的问题；回合已结束或缺少活动证据时仍拒绝暂存。感谢 [@Dong09](https://github.com/Dong09) 的贡献（[#210](https://github.com/xmanrui/dsh-im/pull/210)）。
  `dsh_im_return_file` now prefers the active turn observed on the Session event stream, fixing `artifact-context-required` errors that blocked delivery when the host exposed no event snapshot. Staging still rejects closed turns or Sessions without activity evidence. Thanks to [@Dong09](https://github.com/Dong09) for [#210](https://github.com/xmanrui/dsh-im/pull/210).
- Telegram 移除机器人提及时使用原文偏移，避免 Unicode 大小写转换改变长度后残留提及或误删其他用户名，同时覆盖文字与媒体说明。
  Telegram mention removal uses original text offsets, avoiding retained mentions or damaged usernames when Unicode case conversion changes string length, for both text and media captions.

### Changed / 变更

- 将正常的模型思考强度说明移入帮助提示，失效配置仍在设置区显式提醒；统一 Slack、iMessage 的渠道图标与应用图标。
  Moved normal reasoning-effort guidance into the help tooltip while keeping unavailable-setting warnings visible, and aligned Slack and iMessage channel icons with their app icons.

### Security / 安全

- 减少动态正则与动态日志格式字符串，强化标识校验和配置目录错误处理；更新锁文件中的 `qs`、`sharp`／libvips 间接依赖，并将 CI Actions 固定到提交 SHA。感谢 [@johnslee1207-commits](https://github.com/johnslee1207-commits) 的代码、测试与基础设施贡献（[#214](https://github.com/xmanrui/dsh-im/pull/214)）。
  Reduced dynamic regular expressions and log format strings, strengthened identity validation and configuration-directory error handling, updated locked `qs` and `sharp`/libvips transitive dependencies, and pinned CI Actions to commit SHAs. Thanks to [@johnslee1207-commits](https://github.com/johnslee1207-commits) for code, tests, and infrastructure in [#214](https://github.com/xmanrui/dsh-im/pull/214).

### Documentation / 文档

- 同步中英文交互与批量命令说明、贡献者名单、渠道徽章和截图，并完善跨平台测试及 Windows 包校验兼容性。
  Updated bilingual interaction and batch-command guidance, contributor lists, channel badges, and screenshots, and improved cross-platform tests and Windows package verification.

## [4.20.2] - 2026-09-13

### Fixed / 修复

- 修复 Telegram 私聊在 `ask_user_question` 等待回答时，流式草稿心跳持续占用输入框、导致答案无法正常发送的问题（[#199](https://github.com/xmanrui/dsh-im/issues/199)）。需要提问或审批时，先停止本轮草稿预览与心跳，等待已在发送的草稿结束，再发送普通交互消息，避免迟到草稿覆盖问题并再次阻塞作答。
  Fixed Telegram private-chat live-draft heartbeats keeping the composer busy while `ask_user_question` waits for an answer, preventing replies from being sent normally ([#199](https://github.com/xmanrui/dsh-im/issues/199)). Questions and approvals now stop the current turn's draft preview and heartbeat and drain in-flight draft writes before sending the regular interaction message, so a late draft cannot replace the question and block replies again.
- 交互开始后，本轮后续进度不再重新激活草稿，最终回复仍正常发送；下一轮恢复正常流式预览，群聊的普通占位消息不受影响。提问仍通过编号或文字回答，本次未增加按钮协议、配置项或外部依赖。
  Later progress cannot restart the draft once interaction begins, while the final reply is still delivered normally. The next turn starts a fresh stream, and regular group-chat placeholders are unchanged. Questions still accept numbered or text replies; no button protocol, configuration option, or external dependency was added.

### Documentation / 文档

- 补充 #199 的复现、根因与修复验证记录；新增回归用例覆盖在途草稿、迟到进度、后续心跳、答案提交和最终消息投递。
  Recorded the reproduction, root cause, and validation for #199, and added regression coverage for in-flight drafts, late progress, subsequent heartbeats, answer submission, and final-message delivery.


## [4.20.1] - 2026-09-12

### Fixed / 修复

- 企业微信不再因进入单聊而自动发送菜单，重复进入、断线重连和运行时重启也保持静默；交互菜单通过 `/m` 或 `/menu` 手动打开，普通消息及其他文字命令不会额外触发菜单卡片。
  Enterprise WeChat no longer sends menus automatically on direct-chat entry, including repeated entries, reconnects, and runtime restarts. Open the interactive menu explicitly with `/m` or `/menu`; ordinary messages and other text commands do not trigger extra menu cards.
- 企业微信菜单按钮执行后仅确认操作并反馈结果，不再自动补发整组菜单；覆盖新会话、停止、压缩、状态、帮助、工作区切换及会话／模型／预设设置。保留卡片上的「重新打开菜单」入口；工作区已变化的旧卡片会提示发送 `/m` 重新选择，避免误操作。
  Enterprise WeChat menu actions now acknowledge the operation and return its result without automatically appending another set of menus. This covers new Session, stop, compact, status, help, workspace switching, and Session/model/preset settings. The card's Reopen menu action remains available; stale workspace cards prompt users to send `/m` and select again to avoid unintended actions.

### Documentation / 文档

- 同步中英文 README 与机器人命令指南，说明企业微信菜单的手动打开及操作后反馈行为。
  Updated the bilingual READMEs and bot-command guide to describe explicit Enterprise WeChat menu opening and post-action feedback.

## [4.20.0] - 2026-09-12

### Added / 新增

- 新增会话级工作区覆盖：每个会话（群线程 / 私聊）可绑定专属 DSH 工作区，未设置时回落到 bot 默认工作区。新增 `/conv` 命令（别名 `/conversation`、`/thread`）用于查看、设置、清除当前会话专属工作区，无参数时会显示当前是「显式绑定」还是「跟随 bot 默认」，并顺带列出现有工作区及序号，可直接用 `/conv <序号>` 切换；`/workspace` 保持 bot 默认级不变。主命令取 `/conv` 而非 `/thread`，是因为 Discord 客户端注册了同名原生斜杠命令，会抢占输入框。覆盖以可选增量字段 `conversationWorkspaces` 持久化到 `workspaces.json`，读取时逐条做破坏隔离，损坏时安全降级为 bot 默认。
  Added per-conversation workspace overrides: each conversation (group thread / DM) can pin its own DSH workspace, falling back to the bot default when unset. A new `/conv` command (aliases `/conversation`, `/thread`) shows, sets, or clears the current conversation's workspace; with no argument it reports whether the conversation is explicitly bound or following the bot default, and also lists the existing workspaces with their indexes so `/conv <index>` can switch directly. `/workspace` remains bot-default. The primary name is `/conv` rather than `/thread` because Discord registers a native slash command of that name and would capture the input box. Overrides persist as the optional additive `conversationWorkspaces` field in `workspaces.json`, with per-entry damage isolation and safe fallback to the bot default.

  感谢 [@baijian](https://github.com/baijian) 的实现、测试与文档，以及 [@lyzhu86](https://github.com/lyzhu86) 的方案与文档贡献（[#195](https://github.com/xmanrui/dsh-im/pull/195)）。Thanks to [@baijian](https://github.com/baijian) for implementation, tests, and documentation, and [@lyzhu86](https://github.com/lyzhu86) for ideas and documentation in [#195](https://github.com/xmanrui/dsh-im/pull/195).

### Fixed / 修复

- 微信连接与绑定失败保留具体分类和可执行的中英文恢复提示，覆盖启动、扫码、凭据读取、重连及账号移除；区分网络、超时、HTTP 状态、失效登录与文件访问问题，不再只显示笼统的离线或失败提示（[#198](https://github.com/xmanrui/dsh-im/issues/198)）。设置页支持展开和复制经过筛选的诊断详情，通过 `WX-CONN-XXXXXXXX` 参考编号关联 Host 日志，避免直接展示原始 Token、二维码链接、本地路径或消息内容。
  Weixin connection and provisioning failures retain classified, actionable bilingual recovery guidance across startup, QR login, credential reads, reconnects, and account removal. Network, timeout, HTTP, stale-login, and file-access failures are distinguished instead of collapsing into generic offline or failure messages ([#198](https://github.com/xmanrui/dsh-im/issues/198)). The settings UI can expand and copy filtered diagnostic details and correlate them with Host logs through a `WX-CONN-XXXXXXXX` reference ID, without directly exposing raw tokens, QR URLs, local paths, or message content.
- 微信账号移除后的清理失败明确报告为警告，不再恢复已删除的账号；回滚结果与主要失败分别保留，状态读取不确定时也不再误报为删除失败。自动重试的重复诊断日志会在短时间窗口内合并。
  Cleanup failures after Weixin account removal are reported as warnings without resurrecting deleted accounts. Rollback outcomes remain distinct from the primary failure, and uncertain status reads are no longer misreported as failed deletion. Repeated automatic-retry diagnostics are deduplicated within a short window.

- `/session ID` 绑定时在同一事务内清除与目标 Session 工作区冲突的对话覆盖，保留匹配的显式覆盖和原有 bot 默认工作区语义；重复 `/conv` 会核验遗留 Session 的目录归属，避免提示切换成功却在其他项目执行。补齐持久化失败、并发切换和符号链接路径的回归测试。
  `/session ID` now clears a conflicting conversation override in the binding transaction, preserving matching explicit pins and existing bot-default behavior. Repeated `/conv` verifies legacy Session ownership instead of reporting success while retaining a Session from another project. Regression tests cover persistence failures, concurrent switches, and symbolic-link paths.
- 飞书 `/sessionlist` 卡片及主菜单、钉钉会话选择器和 QQ 会话列表改用当前对话的有效工作区；工作区设置菜单仍管理 bot 默认工作区。切换后旧会话选择菜单失效，避免旧选项把新工作区切回，并新增实际渠道入口回归测试。
  Feishu `/sessionlist` cards and main-menu sessions, the DingTalk session selector, and QQ session lists now use the conversation's effective workspace. Workspace settings remain bot-default. Stale session-selection menus are rejected after a conversation workspace change, with regression tests covering channel entry points.
- 补齐会话工作区切换的提交校验：显式绑定统一记录会话代际，读取已有 Session 前捕获代际，`/model` 的既有会话与新会话路径都保留对话上下文，防止异步选模或绑定把旧工作区 Session 写回。`/session N` 与 `/sessionlist` 共用对话有效工作区，`/conv` 正确区分显式绑定与跟随默认；共享 Session 的其他对话不受单个对话切换影响。
  Completed conversation-workspace commit fencing: explicit bindings retain structured generation records, adoption captures the conversation generation before asynchronous lookups, and both `/model` paths preserve the conversation context. Delayed model selection or binding cannot restore a Session from the old workspace. `/session N` and `/sessionlist` resolve the same effective workspace, `/conv` reports explicit overrides correctly, and switching one conversation preserves other conversations sharing the Session.
- 修复对话工作区切换与消息处理并发时可能把后续消息发进旧工作区的问题：`/conv` 在开始提交时就发布代际栅栏，已在途的会话绑定会被拒绝并重新解析，消息也不会再经由切换前的会话发送；`/session` 显式绑定同样受该栅栏保护。
  Fixed messages sometimes running in the previous workspace when a conversation workspace switch overlapped message processing. `/conv` now publishes its generation fence as soon as it starts committing, so an in-flight Session binding is rejected and re-resolved and the prompt is never sent through the Session of the workspace being left behind. Explicit `/session` bindings are fenced the same way.
- 修复把对话绑定到当前 bot 默认工作区时未落盘的问题：`/conv <当前默认路径>` 现在会写入显式覆盖，之后修改 bot 默认工作区不再连带改变该对话；`/conv clear` 才回到跟随默认。
  Fixed binding a conversation to the bot's current default workspace not being persisted: `/conv <current default path>` now records an explicit override, so a later bot-default change no longer moves that conversation; only `/conv clear` goes back to following the default.
- `/sessionlist` 不带工作区参数时改为列出当前对话的有效工作区（显式传入工作区序号或绝对路径时仍以参数为准），避免在对话专属工作区里选到 bot 默认工作区的会话。
  `/sessionlist` without a workspace argument now lists the workspace the conversation effectively uses (an explicit index or absolute path still wins), so sessions from the bot default are no longer offered inside a conversation-specific workspace.
- 补齐 `/conv` 与相关提示的英文翻译，并让 Telegram 命令菜单、`/help` 与对应测试跟随命令目录自动更新。
  Added the missing English translations for `/conv` and its messages, and let the Telegram command menu, `/help`, and their tests follow the command catalog automatically.

### Documentation / 文档

- 中英文 README 补充会话专属工作区命令与微信诊断说明，统一贡献者致谢及贡献类型图例，并同步 npm 包的贡献者元数据。
  Updated bilingual READMEs with conversation-workspace commands and Weixin diagnostics, standardized contributor acknowledgements and contribution legends, and synchronized npm contributor metadata.

### Known limitations / 已知限制

- 本次微信更新改善错误诊断，不代表已复现或修复 #198 最初报告的掉线根因；再次发生时仍需结合页面诊断及对应参考编号的 Host 日志排查。
  The Weixin update improves diagnostics; it does not establish that the original disconnection reported in #198 has been reproduced or resolved. Further occurrences still require the page diagnostics and matching Host-log reference ID for investigation.

## [4.19.2] - 2026-09-11

### Fixed / 修复

- 机器人消息语言改为跟随 DeepSeek Harness 的界面语言，不再需要在 Host 配置中手动设置 `language`（[#185](https://github.com/xmanrui/dsh-im/issues/185)）。语言按「插件 `language` 配置 → DSH 语言设置项 → 设置页实际生效的界面语言」顺序解析，并把最后一项持久化到 `~/.dsh/integrations/dsh-im/interface-language.json`，因此界面语言来自浏览器语言列表、以及 Host 重启后尚无浏览器连接时，机器人仍以该语言回复。切换语言即时生效：无需重启 Host，Telegram 命令菜单也会重新下发，无需重连机器人。中文仍是兜底语言，已显式配置 `language` 的用户行为不变。
  Bot message language now follows the DeepSeek Harness interface language instead of requiring a manual `language` entry in the Host config ([#185](https://github.com/xmanrui/dsh-im/issues/185)). It resolves from the plugin's `language` option, then DSH's Language setting, then the interface language the settings page is actually rendered in, and it persists that last layer to `~/.dsh/integrations/dsh-im/interface-language.json` — so a browser-derived interface language, and a Host restart before any browser connects, both keep answering in the reader's language. Switching applies live: no Host restart, and the Telegram command menu is re-sent without reconnecting the bot. Chinese remains the fallback, and an explicitly configured `language` behaves exactly as before.

  感谢 [@grloper](https://github.com/grloper) 的贡献（[#189](https://github.com/xmanrui/dsh-im/pull/189)）。Thanks to [@grloper](https://github.com/grloper) for [#189](https://github.com/xmanrui/dsh-im/pull/189).

- 界面语言回传在连接尚未就绪或 Host 持久化失败时自动重试，渠道启动前先完成语言解析；Telegram 连接期间发生的语言切换会在就绪后补发命令菜单。补齐 Telegram 思考占位、降级投递状态和 Discord 新线程提示的英文翻译。
  Interface-language reporting retries when the Connection is not ready or Host persistence fails, and language resolution completes before channels start. Telegram catches up on command-menu changes made while connecting. Added English translations for Telegram thinking placeholders and fallback-delivery status, plus Discord's new-thread notice.

### Known limitations / 已知限制

- Telegram 客户端可能缓存旧的 `/` 命令菜单；重新打开客户端可刷新。输入框旁的 Menu 按钮由 Telegram 客户端自身语言决定，不随 DSH 语言设置改变。
  Telegram clients may cache the previous `/` command menu; reopen the client to refresh it. The Menu button beside the input follows Telegram's own client language, not the DSH language setting.

### Documentation / 文档

- 新增 `scripts/verify-interface-language.mjs`：使用原版 DSH CLI 与独立临时 home，通过真实 `/api` 通道端到端验证界面语言解析顺序、即时切换、重启后行为与运维固定值；提供机器人 Token 时还会断言 Telegram 侧实际存储的命令菜单，并在结束后恢复原菜单。
  Added `scripts/verify-interface-language.mjs`, an end-to-end check running the unmodified DSH CLI with an isolated temporary home. It asserts each interface-language resolution layer over the real `/api` carrier, live switching, restart behavior, and the operator pin. Given a bot token it also asserts the command menu Telegram itself stores, and restores the original menu afterwards.
- 验证脚本在 HTTP 启动后有界等待语言接口就绪，避免插件异步加载期间的临时 `404` 导致重启检查误报失败。
  The verification script waits for language-route readiness with a bounded timeout after HTTP startup, avoiding false restart failures from temporary `404` responses during asynchronous plugin activation.

## [4.19.1] - 2026-09-11

### Fixed / 修复

- 飞书 Web／CLI 会话同步按真实 Session 和回合区分过程卡，修复连续提问共用卡片或答案被覆盖的问题；长时间思考或工具执行不再因静默 90 秒被误判完成，改为通过真实结束事件或历史记录确认收尾。
  Feishu Web/CLI Session sync now separates process cards by Session and turn, preserving answers across consecutive prompts. Long reasoning or tool calls are no longer treated as completed after 90 seconds of silence; completion requires a real terminal event or a matching history record.
- 同步协调器等待完整答案实际写入卡片后才跳过该目标的最终文字；卡片创建或最后更新失败时保留文字兜底，并按渠道、机器人和目标隔离，避免同名目标相互影响。普通 IM 回合在事件入队前记录归属，避免额外生成同步卡片。
  The sync coordinator suppresses final text for a target only after its complete answer is successfully delivered to the card. Card creation or final-update failures retain text fallback, with channel, bot, and target isolation preventing same-named targets from interfering. IM-origin ownership is captured before event queuing to avoid unwanted mirror cards.
- 飞书同步卡片每次成功更新后保存最新快照与内容块，插件重载后沿用原卡片，并从历史读取最终答案，保留已封存的长答案分片；恢复投递失败保留记录重试，成功后才清理。缺少回合信息的旧记录保留原样，不以空卡片覆盖已有内容。
  Feishu sync cards persist their latest successful snapshot and content blocks. After plugin reload, recovery reuses the original card and reads the final answer from history while retaining sealed continuation chunks. Failed recovery keeps records for retry; cleanup follows successful delivery. Legacy records without turn information are left untouched instead of overwriting existing content with empty cards.

### Changed / 变更

- 优化机器人卡片的名称区域：截断的长名称支持悬停或键盘聚焦查看完整提示，提示避开视口边缘并可用 Escape 关闭；收紧横向间距，窄屏下名称与状态保持同一行。别名编辑图标默认更淡，悬停或聚焦时突出显示。
  Improved bot-card name presentation: truncated names expose a full tooltip on hover or keyboard focus, kept within the viewport and dismissible with Escape. Tighter horizontal spacing keeps names and status on one row on narrow screens. Alias-edit icons are subtler at rest and highlighted on hover or focus.

## [4.19.0] - 2026-09-10

### Added / 新增

- 十一个 IM 渠道的机器人卡片均支持自定义别名，点击名称旁的铅笔即可编辑；保存后立即显示，无需重启或重连，也不会清除会话绑定。原平台名称始终保留，清空别名或点击恢复即可还原；别名仅影响本机设置页，不会修改平台上的机器人名称（[#188](https://github.com/xmanrui/dsh-im/issues/188)）。
  Bot cards across all eleven IM channels support custom aliases through the pencil beside the name. Changes appear immediately without restarting, reconnecting, or clearing Session bindings. The original platform name is retained and can be restored by clearing or resetting the alias; aliases affect only the local settings UI, not the bot's platform identity ([#188](https://github.com/xmanrui/dsh-im/issues/188)).
- 已开启「会话双向同步」的飞书私聊可用实时过程卡展示当前 Session 中的 Web／CLI 回合，包含用户提问引用、思考与工具过程、长答案续卡和最终收尾；按投递目标避免重复发送最终文字，其他同步目标保留原有投递。感谢 [@C3H3-AI](https://github.com/C3H3-AI) 的贡献（[#186](https://github.com/xmanrui/dsh-im/pull/186)）。
  Feishu DMs with two-way Session sync enabled can mirror Web/CLI turns in the current Session as live process cards, including the quoted question, reasoning and tool progress, continuation cards for long answers, and final sealing. Final-text deduplication is scoped to the mirrored delivery target, preserving delivery to other synced targets. Thanks to [@C3H3-AI](https://github.com/C3H3-AI) for [#186](https://github.com/xmanrui/dsh-im/pull/186).

### Fixed / 修复

- 修复机器人保存的模型已失效且聊天尚未绑定 Session 时，连 `/model` 也无法切换的问题：显式选模创建 Session 时不再继承旧模型与思考强度，仍在核验所选模型后绑定会话；普通消息和已有 Session 的行为保持不变（[#192](https://github.com/xmanrui/dsh-im/issues/192)）。
  Fixed `/model` being blocked by an unavailable saved bot model when the chat has no bound Session. Explicit model selection creates the Session without inheriting the old model or reasoning level, then verifies the selection before binding. Normal messages and existing-Session behavior remain unchanged ([#192](https://github.com/xmanrui/dsh-im/issues/192)).
- 同时识别旧版 `model-unavailable` 和新版 `session/model-unavailable` 错误，并补全中英文恢复指引：先用 `/models` 查询，再用 `/model <序号>` 修复当前聊天。此操作不会改写机器人的默认模型；若要修复之后新建的 Session，仍需在机器人卡片中更新默认模型。
  Recognized both legacy `model-unavailable` and current `session/model-unavailable` errors with bilingual recovery guidance: list available models using `/models`, then recover the current chat with `/model <index>`. This does not rewrite the bot's default model; update the bot card to fix future Sessions as well.

## [4.18.1] - 2026-09-10

### Changed / 变更

- IM 管理接口的默认 `rpcAuthority` 从 `loopback` 改为 `trusted-host`，沿用 Harness 的浏览器认证与 Host／Origin 信任检查，修复已认证的受信任局域网访问仍被插件拒绝的问题（[#187](https://github.com/xmanrui/dsh-im/issues/187)）。显式配置的 `loopback` 继续生效；插件更新和入站 TTL 管理仍始终仅限本机。需要保持原默认限制的用户可设置 `rpcAuthority: loopback`。
  Changed the default IM management `rpcAuthority` from `loopback` to `trusted-host`, relying on Harness browser authentication and Host/Origin trust checks so authenticated, trusted LAN access is no longer rejected by the plugin ([#187](https://github.com/xmanrui/dsh-im/issues/187)). Explicit `loopback` settings remain effective, and plugin updates and inbound-TTL management stay local-only. Set `rpcAuthority: loopback` to retain the previous default restriction.

### Fixed / 修复

- Telegram 私聊 Rich Draft 在长时间思考或工具执行期间定时刷新，避免临时预览过期；慢网络下跳过尚未完成的心跳，发送最终答案或错误提示前停止调度，避免重复刷新积压拖延收尾。感谢 [@geekyfoxlab](https://github.com/geekyfoxlab) 的贡献（[#175](https://github.com/xmanrui/dsh-im/pull/175)）。
  Telegram private-chat Rich Drafts stay refreshed during long reasoning or tool calls. Pending heartbeats skip redundant ticks on slow networks, and scheduling stops before final or error delivery so repeated refreshes cannot delay completion. Thanks to [@geekyfoxlab](https://github.com/geekyfoxlab) for [#175](https://github.com/xmanrui/dsh-im/pull/175).

### Documentation / 文档

- 更新中英文管理访问说明，并新增使用原版 DSH、独立临时 profile 和空机器人配置的 HTTP 集成验证脚本，覆盖登录、Host／Origin 检查、默认访问和显式回环限制。该测试经回环 TCP 模拟局域网 Host／Origin，不替代跨设备浏览器验收。
  Updated bilingual management-access guidance and added an HTTP integration check using unmodified DSH, an isolated temporary profile, and no bot credentials. It covers login, Host/Origin checks, default access, and explicit loopback restrictions. LAN Host/Origin values are exercised over loopback TCP; this does not replace a browser check from another device.

## [4.18.0] - 2026-09-09

### Added / 新增

- 新增 macOS 原生 iMessage 渠道，通过本机 Messages.app 收发文本私聊，无需 BlueBubbles 或第三方网关；支持权限检查、连接管理、独立联系人会话和主动文字投递。每个 macOS 用户仅提供一个本机身份，需手动授予完全磁盘访问和 Messages 自动化权限；首版不支持群聊、图片或附件。接入说明见 [iMessage 指南](docs/imessage.md)。感谢 [@cherryFloris](https://github.com/cherryFloris) 的贡献（[#183](https://github.com/xmanrui/dsh-im/pull/183)）。
  Added a native macOS iMessage channel for text DMs through the local Messages.app, without BlueBubbles or a third-party gateway. It includes permission checks, connection management, separate contact Sessions, and proactive text delivery. Each macOS user has one local identity and must manually grant Full Disk Access and Messages automation permissions; the MVP does not support groups, images, or attachments. See the [iMessage guide](docs/imessage.md). Thanks to [@cherryFloris](https://github.com/cherryFloris) for [#183](https://github.com/xmanrui/dsh-im/pull/183).

### Fixed / 修复

- iMessage 支持同一 Apple ID 自聊指令，只处理已投递回本机的接收副本；回复统一携带持久化的 `🤖 DSH` 标记并跳过机器人回声，避免重复处理和重启后的回复循环。首次启用从最新消息游标开始，避免回放旧消息。
  iMessage supports self-chat commands under the same Apple ID by processing only incoming copies delivered to the Mac. Replies carry a persistent `🤖 DSH` marker, and bot echoes are ignored to prevent duplicate processing and reply loops after restarts. First-time activation starts at the latest message cursor instead of replaying old messages.
- 正确识别斜杠分隔的 Agent Preset 错误码，保留安全诊断原因，并在现代 Harness 适配层透传直接返回的 DSH RemoteError；中英文提示明确说明通过 `/presetlist`、`/preset` 和 `/new` 重选并新建会话，或恢复原 Preset 后继续旧会话。
  Recognized slash-separated Agent Preset error codes, retained safe diagnostic reasons, and preserved direct DSH RemoteErrors through the modern Harness adapter. Bilingual guidance explains how to select an available preset with `/presetlist` and `/preset`, then start a new Session with `/new`, or restore the original preset to continue an existing Session.

### Known limitations / 已知限制

- 原版 DSH `0.1.5-alpha.1` 恢复旧会话时仍可能将 Preset 错误包装为 `gateway/internal`，导致插件无法按结构化错误码分类；企业微信相关日志的附加诊断仍有缺口。本版不宣称完整解决 [#184](https://github.com/xmanrui/dsh-im/issues/184)。
  Unmodified DSH `0.1.5-alpha.1` can still wrap preset failures during existing-Session recovery as `gateway/internal`, preventing classification from structured error codes. Related WeCom logs still lack some diagnostic details. This release does not fully resolve [#184](https://github.com/xmanrui/dsh-im/issues/184).

## [4.17.1] - 2026-09-09

### Fixed / 修复

- 修复原版 DSH `0.1.5-alpha.1` 的 IM 管理接口兼容性，统一通过 Connection 的公开 `/api` Fetch 接口承载十个 IM 渠道、Office、更新、入站 TTL 和主动投递管理，无需修改或重新编译 DSH；继续兼容已支持的四个原版 DSH 版本。
  Fixed IM management compatibility with unmodified DSH `0.1.5-alpha.1`. Ten IM channels, Office, updates, inbound TTL, and proactive-delivery management now share Connection's public `/api` Fetch interface without modifying or rebuilding DSH, while retaining compatibility with the four previously supported DSH releases.
- 保留原生请求关联、取消信号和业务错误，并补全旧处理器缺少的错误详情。管理接口继续执行默认回环访问限制；`trusted-host` 复用 DSH 的浏览器认证与 Host／Origin 检查，更新和入站 TTL 管理始终仅允许回环访问。
  Preserved native request correlation, cancellation, and business errors, filling in error details omitted by older handlers. Management access remains loopback-only by default; `trusted-host` relies on DSH browser authentication and Host/Origin checks, while update and inbound-TTL management always remain loopback-only.

### Documentation / 文档

- 更新中英文兼容说明和元数据，记录五个原版 DSH Web profile 的兼容矩阵，以及飞书、钉钉、企业微信和 Telegram 的真实收发验证。升级插件后需重启 Host 并刷新设置页，使两端加载同一版插件。
  Updated bilingual compatibility guidance and metadata, documenting the five-version compatibility matrix for unmodified DSH Web profiles and real-message checks for Feishu, DingTalk, WeCom, and Telegram. Restart the Host and refresh settings after upgrading so both sides load the same plugin version.

## [4.17.0] - 2026-09-09

### Added / 新增

- 飞书新增实时过程卡，将任务步骤和最终答案在卡片内更新，工具摘要与过程说明可折叠；支持长答案续卡、交互前换卡和停止状态。任务过程展示可选不显示过程、实时过程卡或逐步直播；新接入机器人默认实时过程卡。
  Feishu gains process cards with in-place progress and answers, collapsible tool summaries and notes, long-answer continuation cards, interaction rotation, and stopped status. Users can choose no process, a live process card, or per-step messages; new bots default to the process card.

### Fixed / 修复

- 修复已有过程卡收尾时末块覆盖首块，长答案按顺序完整投递；卡片封存或续卡发送失败时沿用完整 post 答案兜底。
  Preserve every answer chunk in order when completing an existing process card. Failed sealing or continuation creation falls back to the complete post answer.

- 旧机器人缺少呈现模式时保留逐条消息行为，明确保存的模式及关闭状态不变；扫码和手动凭据新接入采用一致默认值。
  Existing bots without a stored mode retain per-step posts, preserving explicit modes and disabled settings. QR and manual-credential onboarding use the same new-bot defaults.

## [4.16.1] - 2026-09-09

### Fixed / 修复

- 钉钉 AI Card 改为在创建并投放时同时写入可见的思考提示，避免先出现空白卡片；首次流式更新失败时保留已显示的卡片，后续仍可原位完成。
  DingTalk AI Cards now include visible thinking text in the combined create-and-deliver request, avoiding an initially blank card. A failed initial streaming update keeps the visible card available for later in-place completion.

- 修复钉钉 AI Card 完成后正文消失或继续显示处理中：先结束流式组件，再将完整回答和完成状态持久化到模板实际使用的 `msgContent` 字段，保持正文可见。
  Fix DingTalk AI Cards losing their answer or remaining in the processing state after completion. The stream is finalized first, then the full answer and completed state are persisted in the template's visible `msgContent` field.

- 钉钉卡片创建、流式更新或最终状态写入失败时，恢复完整文字回答和安全错误提示的兜底投递，避免卡片失败被误记为已成功送达而丢失结果。
  Restore full-text answers and safe error-message fallback when DingTalk card creation, streaming updates, or final-state persistence fail, preventing failed cards from being treated as successful delivery and losing the result.

## [4.16.0] - 2026-09-09

### Added / 新增

- 新增实验性企业微信自建应用渠道（`wecom-app`），成为第十个 IM 渠道：通过加密 HTTP 回调接收消息，支持多应用独立配置、私聊流式回复、图片输入、结果文件回传与主动投递目标。成员关注企业的微信插件后可在微信中对话，微信端自动降级为分段文字；接入需要公网回调与企业可信 IP 配置。回调监听按需启动，移除最后一个应用后关闭。接入步骤见[中文指南](docs/企业微信自建应用接入.md)和[英文指南](docs/企业微信自建应用接入.en.md)。
  Adds the experimental WeCom self-built app channel (`wecom-app`) as the tenth IM channel, with encrypted HTTP callbacks, independent multi-app configuration, private-chat streaming, image input, result files, and proactive delivery targets. Members can chat from WeChat through the enterprise's WeChat plugin, with segmented-text fallback there. Setup requires a public callback route and trusted IP configuration. The callback listener starts on demand and stops when the last app is removed. See the linked Chinese and English setup guides.

- 机器人设置新增显式的「思考强度」选择，档位、说明和默认值来自 DSH 当前模型；每个机器人独立保存，切换模型时恢复新模型默认强度，仅影响之后新建的会话，不改变已有会话或进行中的回答。
  Bot settings now expose reasoning-effort choices using the current model's levels, descriptions, and defaults from DSH. Each bot saves its own override; changing models restores the new model's default effort. Changes apply only to future Sessions, leaving existing Sessions and in-progress replies unchanged.

- 飞书分步直推在静默 20 秒后显示「正在思考中」及运行时长，并原位定时更新。出现实际进度、问题或审批，以及回合结束时会尝试撤回；撤回失败最多重试三次，迟到的状态消息也会清理，避免重复状态和残留提示。
  Feishu Step Push shows a thinking-status message with elapsed time after 20 seconds of silence and periodically updates it in place. Real progress, questions, approvals, and turn completion trigger cleanup. Failed recalls allow up to three attempts, and late-arriving status messages are also cleaned up to prevent duplicates and stale notices.

- 飞书提问卡片新增自定义答案入口，提交后将原卡片更新为已回答状态并展示选择结果；重复或过期点击会提示已回答，避免重复提交。
  Feishu question cards add a custom-answer entry and update the original card with its answered state and selected result after submission. Repeated or stale clicks report that the question was already answered instead of submitting again.

### Changed / 变更

- Telegram 原生命令菜单与文字帮助改为共用命令目录，启动和重连时生成本地化完整菜单，自动纳入历史、推理等级等命令及别名；删除的命令不再残留，空目录会清空旧菜单。菜单同步失败不会阻止机器人连接。
  Telegram's native command menu and text help now share one command catalog. Startup and reconnection generate the complete localized menu, including history, reasoning commands, and aliases. Removed commands no longer linger, an empty catalog clears the previous menu, and synchronization failures do not block connection.

### Fixed / 修复

- 修复飞书提问或审批前后的流式消息顺序：卡片写入串行化，交互卡片展示后才继续后续回复，并按已展示正文去重；临时工具状态不再混入固定正文，最终卡片使用最新正文快照，避免旧过程重播、重复回答和正文丢失。
  Feishu serializes streaming-card writes and resumes subsequent replies only after a question or approval is presented, deduplicating already displayed text. Transient tool statuses stay out of the frozen answer prefix, and final cards use the latest text snapshot, preventing replayed progress, duplicate answers, and lost text.

- 各渠道与 AI Office 在初始化期间或启动失败后仍保留管理 RPC，返回可读、脱敏的初始化或失败信息，并清理部分启动的资源，避免设置页因处理器未注册而只显示 404。
  All channels and AI Office retain their management RPC during initialization and after startup failure, returning readable, sanitized status or error information and cleaning up partially initialized resources instead of leaving settings requests with an unregistered-handler 404.

- 企业微信菜单发送错误现在区分权限、限流、断连与结果不确定等情况；仅在明确且可降级的卡片拒绝后回退文字，结果不确定时保留卡片操作状态并避免重复发送。菜单恢复成功后清除对应旧错误，不覆盖模型错误或并发请求的新错误。
  WeCom menu delivery now distinguishes permission, rate-limit, disconnection, and uncertain-outcome errors. Only definite, eligible card rejections fall back to text; uncertain delivery retains card interaction state without duplicate sends. Successful menu recovery clears its own previous error without overwriting model failures or newer concurrent errors.

- 设置页恢复显示完整渠道导航列表，并将飞书分步直推说明移入帮助提示，减少设置项拥挤。
  Settings show the complete channel navigation list again, and Feishu Step Push guidance moves into its help tooltip to reduce clutter.

## [4.15.0] - 2026-09-08

### Added / 新增

- 本机 Host 的九个 IM 渠道与 AI Office 会话自动追加渠道前缀（如「微信 · 标题」），保留自动标题的来源与后续生成能力；不会调用手动重命名接口锁定标题，重复生成和重启不会叠加前缀。已有会话在加载时补齐；显式连接远程 `harnessBaseUrl` 时需在目标 Host 上安装插件。
  Sessions from all nine IM channels and AI Office on the local Host automatically receive channel prefixes such as “WeChat · Title”, preserving automatic title provenance and later generation. Prefixes do not use manual rename or pin titles, and do not stack across regeneration or restarts. Existing Sessions are decorated when loaded; explicit remote `harnessBaseUrl` connections require the plugin on the destination Host.

- Web 会话列表和搜索结果将渠道文字前缀显示为现有渠道 Logo，无需修改 DSH。浏览器适配保留原始文字节点、读屏信息和行操作；不兼容的页面结构或图标加载失败时保留文字前缀，插件卸载后恢复原始显示。
  Web Session lists and search results show existing channel logos in place of textual prefixes, without modifying DSH. The browser adapter preserves original text nodes, accessible names, and row actions, keeps text on incompatible page structures or image-load failures, and restores the original display on unload.

- 飞书群聊默认接收其他机器人明确 @ 当前机器人的消息，无需新增开关；仍遵守群聊白名单、命令权限与消息去重规则，未 @、自发和机器人私聊消息继续忽略。扫码新建应用与“补全权限”/`/repair` 流程同时申请接收机器人 @ 消息所需的飞书权限。
  Feishu group chats accept explicit mentions from other bots by default, while preserving group allowlists, command permissions, and deduplication. Unaddressed messages, self-sent messages, and bot DMs remain ignored. New-app QR onboarding and Complete permissions / `/repair` request the required Feishu bot-mention scope.

### Fixed / 修复

- 修正渠道标题监听器的 Host 启动回调返回值，避免 DSH 将其判为无效 effect 并卸载监听器，导致真实飞书等会话不显示渠道标识；回归验证覆盖完整插件启动流程及先命名、后接收 IM 消息的会话。
  Correct the channel-title observer's Host startup return value so DSH does not reject it as an invalid effect and unload the observer. Regression checks cover full plugin activation and Sessions titled before their first IM message.

## [4.14.0] - 2026-09-08

### Added / 新增

- 飞书机器人新增默认关闭的「分步直推」设置，支持按机器人独立开启并即时应用，无需重连。开启后，以独立富文本消息逐步推送工具调用及参数摘要、过程说明和已完成的助手消息，最终回答以支持 Markdown 的富文本投递；包含发送节流与单轮过程消息上限，达到上限仍会投递最终回答，关闭时保留原有流式卡片体验。
  Feishu bots gain an opt-in Step Push setting that applies per bot without reconnecting. It delivers tool calls with argument excerpts, progress notes, and completed assistant messages as separate rich-text posts, followed by a Markdown-capable final answer. Throttling and a per-turn progress-message cap limit traffic without suppressing the final answer; disabling the setting preserves the existing streaming-card experience.

### Fixed / 修复

- 飞书分步直推的长回答按富文本 JSON 编码后的字节数分段，兼顾中文、转义字符与 emoji 边界；中途投递失败时仅从失败分段恢复，避免重复已成功发送的内容。补齐限流重试、富文本到文字的降级和失败状态记录，防止最终回答未送达却被标记为成功。
  Feishu Step Push splits long answers by encoded rich-text JSON bytes, accounting for CJK text, escaped characters, and emoji boundaries. Delivery resumes at a failed chunk without repeating the successful prefix. Rate-limit retries, rich-text-to-text fallbacks, and failure reporting prevent undelivered final answers from being marked successful.

- 飞书已有话题内的回复现在按实际会话结构留在原话题，不再受「群聊以话题方式回复」开关影响；该开关仅控制是否为普通群聊消息自动创建话题。
  Replies in existing Feishu topics now stay in their original thread based on the conversation structure, regardless of the group-topic reply switch. That switch only controls automatic topic creation for ordinary group messages.

- `dsh_im_return_file` 在新版 DSH Session 使用 `snapshotEvents()` 时，现在可以再次识别当前 Turn 并回传文件；同时保留旧 `session.events` 路径。
  `dsh_im_return_file` once again recognizes the current turn and returns files when running against modern DSH Sessions that expose `snapshotEvents()`, while retaining the legacy `session.events` path.

- 兼容旧版持久化投递目标中重复保存的 `targetId`，修复微信等渠道旧配置的加载；仅在该字段与目标映射键一致时归一化，标识不一致的损坏记录仍会被拒绝。
  Legacy delivery targets with a redundantly stored `targetId` now load correctly for WeChat and other channels. Normalization is limited to IDs matching the target map key; inconsistent or corrupted records remain rejected.

## [4.13.0] - 2026-09-06

### Added / 新增

- 九个 IM 渠道新增统一的超时任务结果补发：前台等待超时后继续跟踪原 Harness 回合，完成后向原聊天或线程补发最终文字或终态通知，支持 Host 重启和连接恢复后继续检查。`/stop` 可精确停止当前聊天的待完成回合，换绑会话后不再补发旧结果；明确发送失败最多尝试三次，结果不确定时停止自动重试。此机制不重放文件产物、问题或审批，仍受平台发送权限与配额限制。
  All nine IM channels now share deferred task delivery: after the foreground reply wait times out, the original Harness turn remains tracked and its final text or terminal notification is delivered to the original chat or thread, including after Host restarts or reconnection. `/stop` can precisely cancel the chat's pending turn, and rebinding the Session prevents delivery of old results. Definite send failures allow up to three attempts; uncertain outcomes stop automatic retries. Files, questions, and approvals are not replayed, and platform permissions and quotas still apply.

- 钉钉新增 `/m`、`/menu` 原生下拉菜单，支持会话、工作区、Agent 预设和模型选择，以及新会话、历史、停止、压缩、状态与帮助按钮；选择后立即生效并更新原卡片。使用插件内置共享模板，无需为每个机器人配置模板；菜单 30 分钟或 Host 重启后失效。
  DingTalk adds native `/m` and `/menu` dropdown menus for Sessions, workspaces, Agent Presets, and models, with New, History, Stop, Compact, Status, and Help buttons. Selections apply immediately and update the original card. The bundled shared template requires no per-bot template configuration; menus expire after 30 minutes or a Host restart.

- QQ 新增 `/m`、`/menu` 按钮与数字菜单，覆盖会话、工作区、模式／预设、模型、新会话、停止、压缩、补充指令、归档显示切换、状态与帮助。长列表按快照分页，菜单按聊天和操作者隔离并沿用命令权限；按钮被平台明确拒绝时回退数字选择。旧菜单、重复点击和已变化的会话／工作区不会执行操作，审批、提问和批量输入保留原有优先级。
  QQ adds `/m` and `/menu` button and numbered menus for sessions, workspaces, modes/presets, models, new sessions, stop, compact, steering, archived-session visibility, status and help. Lists paginate over stable snapshots; menus are scoped to the chat and actor and use existing command permissions. Definite platform rejections fall back to numbered text. Stale menus, repeated clicks and changed session/workspace contexts cannot execute actions; questions, approvals and batch input retain priority.

### Fixed / 修复

- 兼容新版 Harness 命令接口的 `submittedAttachments` 参数，修复 QQ 菜单实测中发现的压缩失败；保留旧版无附件参数及 `images` 接口，仅在明确的调用前参数校验失败时适配重试。
  Support the newer Harness command descriptor's `submittedAttachments` argument, fixing compaction discovered during QQ menu testing. Older argument-free and `images` descriptors remain supported; adaptation retries only exact argument validation failures before command dispatch.

- 微信主动投递、连接测试和延迟任务结果现在复用对应用户最近的 `context_token`，并在 Host 重启后恢复；上下文按机器人登录与用户隔离，更换登录凭据后清理，补齐原先遗漏的会话上下文。主动发送失败会在账号状态中保留脱敏诊断与恢复建议，健康轮询不会覆盖发送错误。升级后需收到一次用户消息建立缓存，此修复不能解除 iLink 的发送额度和会话时效限制。
  WeChat proactive delivery, connection tests, and deferred task results now reuse the recipient's latest `context_token` and restore it after Host restarts. Context is isolated by bot login and recipient and cleared when login credentials change, supplying conversation context that was previously omitted. Proactive failures retain sanitized diagnostics and recovery guidance in account status, even while polling remains healthy. An inbound user message is needed to populate the cache after upgrading; this does not remove iLink sending quotas or conversation lifetime limits.

- 企业微信流式回复在完成、停止或失败后会清除临时思考与工具进度文字，保留最终回答或结果提示。
  Enterprise WeChat clears transient thinking and tool-progress text when a streamed reply completes, stops, or fails, preserving the final answer or outcome message.

- 机器人账号卡片收起时，标题栏的帮助提示不再被卡片边缘裁切。
  Help tooltips in collapsed bot-card headers are no longer clipped by the card edges.

## [4.12.0] - 2026-09-06

### Added / 新增

- 企业微信新增 `/menu`、`/m` 原生交互菜单，可通过下拉框选择会话、模型、Agent 预设和工作区，并使用新会话、停止、压缩、状态与帮助按钮；长列表支持分页，收到平台每日进入单聊事件时也会展示菜单。菜单操作沿用文字命令权限，30 分钟或插件重启后过期，卡片无法投递时提供文字命令降级。
  Enterprise WeChat adds native `/menu` and `/m` menus with dropdowns for Sessions, models, Agent Presets, and workspaces, plus New, Stop, Compact, Status, and Help buttons. Long lists support pagination, and the platform's daily direct-chat entry event also opens the menu. Actions use existing text-command permissions; menus expire after 30 minutes or a plugin restart, with text-command fallback when cards cannot be delivered.

- 九个 IM 渠道的账号卡片现在默认收起详细设置，点击账号标题或使用 Enter／空格即可展开与收起，便于管理多个机器人；折叠区域的控件不会继续占用键盘焦点，并尊重系统的减少动画设置。
  Account cards across all nine IM channels now collapse their detailed settings by default. Click the account header or press Enter/Space to toggle them for easier multi-bot management. Collapsed controls are excluded from keyboard focus, and animations respect reduced-motion preferences.

### Changed / 变更

- WhatsApp 回复改为每秒编辑同一条消息，逐步显示工具进度和生成中的回答；最终回复原位定稿，长回复自动分段。创建或完成流式消息失败时回退为完整文字回复，断开机器人时会取消待发送的预览。
  WhatsApp now edits the same message at one-second intervals to show tool progress and generated text, finalizes the answer in place, and splits long replies. Failed stream creation or finalization falls back to a complete text reply, and disconnecting the bot cancels queued previews.

### Fixed / 修复

- 删除首个账号后，其余账号的折叠样式与展开／收起操作现在会正常保留。
  Removing the first account no longer removes the shared collapse styles or disrupts toggling for the remaining accounts.

## [4.11.0] - 2026-09-05

### Added / 新增

- 已保存的私聊投递目标新增默认关闭的「会话双向同步」开关。开启后，DSH Web／CLI 在该私聊当前 Session 中提交的用户文字和完成后的助手文字会通过原机器人同步回私聊；IM 自身输入不会重复投递。九个 IM 渠道共用同一实现，自动跟随 `/session`、`/new` 和工作区切换后的当前会话；首版仅支持当前 Host 的私聊文字，不支持显式远程 `harnessBaseUrl`、群聊、Topic 或 Thread。
  Saved direct-message delivery targets now have an opt-in **Two-way Session sync** switch. When enabled, user text submitted from DSH Web/CLI and the completed assistant text in that DM's current Session are mirrored through the original bot, while IM-originated input is never duplicated. One shared implementation covers all nine IM channels and follows the current Session across `/session`, `/new`, and workspace changes. The first version supports text DMs on the current Host only, excluding explicit remote `harnessBaseUrl` connections, groups, Topics, and Threads.

- 九个 IM 渠道的每个机器人新增独立模型设置，可从 Host 当前可用模型中选择或跟随默认；设置只影响之后新建的 Session，已有 Session 与正在生成的回复不变。
  Every bot across all nine IM channels now has an independent model setting, selectable from the Host's current model catalog or left to follow the default. The setting applies only to newly created Sessions and does not alter existing Sessions or in-progress replies.

### Changed / 变更

- npm 包元数据新增已验证兼容 DSH `0.1.3-alpha.1`；兼容测试使用官方发布提交 `d347e70`，并完成九渠道各一台机器人的真实主动投递与双向同步冒烟。
  npm package metadata now declares verified compatibility with DSH `0.1.3-alpha.1`. Compatibility testing used official release commit `d347e70` and completed real proactive-delivery and two-way-sync smoke tests with one bot on each of the nine channels.

- 飞书的「群聊响应方式」与「群聊以话题方式回复」已从机器人卡片主页移入该机器人的设置页，使卡片布局与其他渠道保持一致。
  Feishu's “Group response mode” and “Reply to group chats as topics” controls have moved from the bot-card overview into that bot's settings page, aligning the card layout with the other channels.

### Fixed / 修复

- 九个 IM 渠道现在会按 step 顺序保留同一 Turn 的全部助手正文，并用定稿消息替换同 step 的流式草稿；多 step 回答不再在最终投递或进入新 step 时只剩最后一段。
  All nine IM channels now retain every assistant text step in turn order and replace each step's streamed draft with its canonical message, preventing multi-step replies from collapsing to the final fragment during streaming or final delivery.

## [4.10.0] - 2026-09-05

### Added / 新增

- 入站附件改为按时间戳目录持久落盘，并新增全局保留时长（TTL）设置：`-1` 永久保留、`0` 每轮对话结束后立即删除、`1-8760` 整数小时后自动清理，默认 `168` 小时（7 天）；清理在进程启动、每 30 分钟及设置页手动触发时执行，进行中对话的目录会被跳过。通用设置通过顶部 GitHub 按钮右侧的齿轮进入，附件保留功能位于首个「附件」Tab；取值说明收纳在标题右侧的问号中，修改后通过「保存」按钮明确提交。清扫会拒绝位于工作区外的符号链接附件目录。历史 `turn-` 目录及无法解析的目录不参与清理，需要手动删除。清扫仅覆盖各渠道当前配置的工作区；Bot 通过 `/workspace` 切换工作区后，旧工作区中已持久化的附件目录不再参与自动清理，需手动删除。
  Inbound attachments now persist under timestamped directories with a global retention (TTL) setting: `-1` keeps them forever, `0` deletes each directory right after its turn ends, and whole hours `1-8760` clean them automatically, defaulting to `168` hours (7 days). Sweeps run at process startup, every 30 minutes, and on demand from the settings page, always skipping directories owned by in-flight turns. General settings open from the gear beside the top GitHub button, with attachment retention under the first “Attachments” tab. Sweeps refuse symlinked attachment roots outside the workspace. Legacy `turn-` directories and unparseable names are never touched and must be removed manually. Sweeping only covers each channel's currently configured workspaces; after a bot switches its workspace via `/workspace`, persisted attachment directories left in the previous workspace are no longer swept and must be removed manually.

- 飞书机器人设置新增「群聊以话题方式回复」开关：开启后，群聊中向机器人提问会自动开启一条独立的飞书话题，回答落在话题内；每个话题是 dsh 会话列表里的一条独立会话，上下文互不串。私聊不受影响。可分别对每个机器人开启或关闭。
  Feishu bots gain a “Reply to group chats as Feishu topics” switch. When enabled, a question addressed to the bot in a group auto-opens a dedicated Feishu topic and replies stay inside it; each topic is an independent conversation in dsh with its own context. Private chats are unaffected. The switch is configured per bot.

- 同 Host 插件的 `ctx.dshIm` 服务新增 `listBots()`，可发现已配置机器人的公开 `botId` 与渠道类型，再配合现有 `listTargets()` 和 `send()` 完成主动投递；返回值不包含凭据、平台路由或目标内容。
  The same-Host `ctx.dshIm` service now exposes `listBots()`, allowing plugins to discover each configured bot's public `botId` and channel before using the existing `listTargets()` and `send()` APIs for proactive delivery. Results contain no credentials, provider routes, or target content.

### Changed / 变更

- npm 包元数据现在声明已验证兼容 DSH `0.1.2-alpha.4`、`0.1.2-alpha.5` 与 `0.1.2-rc.1` 的 Web profile。
  npm package metadata now declares verified Web-profile compatibility with DSH `0.1.2-alpha.4`, `0.1.2-alpha.5`, and `0.1.2-rc.1`.

### Fixed / 修复

- 新版 DSH Session 使用 `snapshotEvents()` 时，IM 的 `/stop` 现在可以再次识别并停止当前所属 Turn。
  IM `/stop` once again recognizes and cancels the currently owned turn when running against modern DSH Sessions that expose `snapshotEvents()`.

- 飞书在 DSH v2 生成回复期间会重新接收并转发实时 assistant chunk，流式卡片不再等到最终消息落盘后才显示整段回答。
  Feishu now receives and forwards live assistant chunks while DSH v2 is generating, so streaming cards no longer wait for the final durable message before displaying the full reply.

## [4.9.1] - 2026-09-04

### Fixed / 修复

- 九个 IM 渠道的 Harness 结构化问题与审批现在兼容新 DSH Session 的 `snapshotEvents()` 接口，同时保留旧 `session.events` 与旧 Host `apiProxy` 路径；交互不再只停留在 DSH Web，IM 用户回答或审批后原 Turn 可继续完成。
  Harness structured questions and approvals across all nine IM channels now support the new DSH Session `snapshotEvents()` API while retaining the legacy `session.events` and Host `apiProxy` paths. Interactions no longer remain visible only in DSH Web, and the originating turn can continue after the IM user answers or decides.

- 钉钉机器人连接失败时现在会按 Harness、凭据、超时、DNS、TLS、代理、SDK 与依赖兼容性等原因提供脱敏且可操作的诊断，并用参考号关联设置页提示与 Host 日志；已保存但尚未连通的机器人也会保留在设置页供排查。
  DingTalk connection failures now provide redacted, actionable diagnostics for Harness, credential, timeout, DNS, TLS, proxy, SDK, and dependency-compatibility causes, with a reference ID linking settings feedback to Host logs. Saved bots that are not yet connected also remain available in settings for troubleshooting.

## [4.9.0] - 2026-09-03

### Added / 新增

- 飞书的 Harness 审批与单选问题默认使用带按钮的交互卡片；审批人和答题人会绑定到发起者，多题场景会拒绝过期卡片，并在卡片不可用时保留纯文本降级流程。可通过 `DSH_IM_INTERACTION_CARDS=0` 或 `interactionCards=false` 继续使用纯文本交互。
  Harness approvals and single-choice questions in Feishu now use interactive cards with buttons by default. Decisions are bound to the initiating actor, stale cards are rejected in multi-question flows, and plain-text fallback remains available when cards cannot be used. Set `DSH_IM_INTERACTION_CARDS=0` or `interactionCards=false` to keep the plain-text interaction flow.

- 九个渠道的工作区命令新增快捷别名：`/ws` 等价于 `/workspace`，`/workspaces` 与 `/wsl` 等价于 `/workspacelist`。
  Workspace commands across all nine channels now have shortcuts: `/ws` aliases `/workspace`, while `/workspaces` and `/wsl` alias `/workspacelist`.

### Fixed / 修复

- Harness 回复等待改为按活动续期：持续产生事件或 Harness 明确报告 Session 仍在运行的长任务不再被固定 10 分钟上限误报超时；已开始但停止推进且不再运行的任务仍会按停滞窗口超时。
  Harness reply waits now renew from activity: long-running turns that keep producing events or are still reported as running no longer hit a fixed ten-minute timeout, while started turns that stop progressing and are no longer running still time out after the stall window.

- 引用消息注入 Harness 时不再携带内部消息 ID、作者 ID、空附件数组及默认 `truncated: false`，减少与回答无关的元数据，同时保留作者名称、正文、有效附件及不可用原因。
  Quoted-message context sent to Harness no longer includes internal message IDs, author IDs, empty attachment arrays, or the default `truncated: false`, reducing irrelevant metadata while preserving the author name, content, useful attachments, and unavailable reason.

- 飞书交互卡片现在保持引用回复语义，避免问题或审批卡片脱离触发它的消息上下文。
  Feishu interaction cards now preserve reply semantics so question and approval cards stay attached to the message context that triggered them.

- 上下文增强设置中的字段帮助提示会按左右栏定位，不再被设置面板边缘裁切。
  Field-help tooltips in Context enhancement settings now align to their column instead of being clipped by the settings-panel edge.

### Documentation / 文档

- 中英文 README 的详细安装、命令、访问模式与上下文增强说明已拆分到独立指南，并补充主动投递 Webhook 方案等文档。
  Detailed installation, command, access-mode, and Context enhancement material has moved from the Chinese and English READMEs into focused guides, with additional documentation for proactive-delivery webhooks and related workflows.

## [4.8.0] - 2026-09-02

### Added / 新增

- 上下文增强新增两个来源字段：`chatId`（会话标识，用于区分群组或私聊）与 `threadId`（话题标识，飞书话题群会带上 `thread_id`，用于区分同一群组内的不同话题）。九个渠道均可勾选；飞书群聊直接提供群 ID，Slack/Telegram 话题、Discord 频道等渠道也按各自事件补齐。仍只发送当前消息中已有的值，不查询平台 API。
  Context enhancement adds two source fields: `chatId` (the chat ID that distinguishes groups or direct chats) and `threadId` (the topic ID; Feishu topic chats carry `thread_id`, telling different topics inside the same group apart). All nine channels can select them; Feishu group chats provide the group ID directly, and Slack/Telegram topics, Discord channels, and other channels are wired per their own events. Only values already present in the current message are sent; no platform APIs are queried.

### Fixed / 修复

- 机器人工作区目录选择器现在同时识别新版 DSH 的 `directory-picker/*` 错误码与旧版连字符错误码；native 后端会正确回退到系统目录选择器，已失效的保存路径也会回退到 Host 主目录。
  The bot workspace directory picker now recognizes both current DSH `directory-picker/*` error codes and legacy hyphenated codes, restoring the native system-picker fallback and the Host-home fallback for stale saved paths.

## [4.7.0] - 2026-09-02

### Added / 新增

- `/sessionlist --limit N` 与等价命令 `/sessions --limit N` 现在可按现有顺序仅返回当前工作区的前 N 个会话；`N` 必须是正整数，该参数仅影响本次响应，不改变机器人或全局配置。飞书的分页会话卡片会在后续翻页与选择操作中保持同一限制。
  `/sessionlist --limit N` and its `/sessions --limit N` alias now return only the first N sessions in the current workspace's existing order. `N` must be a positive integer, and the option affects only that response without changing bot or global settings. Feishu's paginated session card preserves the same limit across subsequent page and selection actions.

## [4.6.0] - 2026-09-02

### Added / 新增

- 非视觉模型收到图片时不再直接报错丢图：宿主以 `MODEL_DOES_NOT_SUPPORT_IMAGES` 拒绝带图片的 prompt 后，自动把同一批图片字节按入站文件管线落盘到 Session 工作区，并以"原文本 + 工具分析指引 + `<dsh_im_files>` 清单"的纯文本 prompt 复用同一 rpcId 重试一次，使非视觉模型仍可通过 run_code/pwsh 等工具识图；视觉模型与文件消息行为不变，其余图片错误仍按原样提示。
  Sending an image to a non-vision model no longer fails outright: when the Host rejects an image-bearing prompt with `MODEL_DOES_NOT_SUPPORT_IMAGES`, the same image bytes are automatically staged into the Session workspace through the inbound-file pipeline and retried once as a text-only prompt (original text plus tool-analysis guidance and the `<dsh_im_files>` manifest) under the same rpcId, so non-vision models can still inspect images via tools such as run_code/pwsh. Vision models and file messages are unchanged, and other image errors keep their existing messages.

- 九个 IM 渠道统一支持引用或回复消息上下文：Harness 会在当前问题之前收到安全序列化的 `<dsh_im_reply_to>`，包含平台可提供的原消息文字、作者及附件类型/名称；缺少正文快照的渠道仅在访问控制和本地交互完成后进行同会话、有界的延迟查询或 Session 历史恢复，失败时不阻断当前问题，也不会把引用内容误当作命令、审批或问题回答。
  All nine IM channels now preserve quoted or replied-to message context. Harness receives a safely serialized `<dsh_im_reply_to>` before the current question with the original text, author, and attachment type/name when available. Channels without a content snapshot perform only bounded, same-conversation lazy lookup or Session-history recovery after access control and local interactions; lookup failure does not block the current question, and quoted content cannot be interpreted as a command, approval, or question answer.

### Fixed / 修复

- 非视觉模型图片回退在文件落盘阶段收到取消信号时，现在会保留调用方的取消原因并停止处理，不再误报模型不支持图片。
  When image fallback for a non-vision model is cancelled while staging files, it now preserves the caller's cancellation reason and stops instead of reporting that the model does not support images.

## [4.5.0] - 2026-09-01

### Added / 新增

- `/workspace` 现在支持使用 `/workspacelist` 中的工作区序号切换，并在执行命令时按最新列表解析；原有绝对路径用法保持不变。
  `/workspace` now accepts a workspace number from `/workspacelist`, resolved against the latest list when the command runs; the existing absolute-path form remains supported.

- 上下文增强新增可选的 `conversationTitle` 来源字段；渠道入站事件提供会话标题时可将其写入 `<dsh_im_source>`，无需额外的平台 API 请求。
  Context enhancement now offers an optional `conversationTitle` source field. When an inbound channel event provides a conversation title, it can be included in `<dsh_im_source>` without an additional platform API request.

### Fixed / 修复

- 新建 Harness Session 的标题现在始终基于未经上下文增强的首条用户消息：启用增强时会移除注入块后安全设置标题，未启用增强时继续保留 Harness 的原生自动标题；标题会清理控制字符并按 UTF-8 字节安全截断。
  New Harness Session titles now consistently reflect the unenhanced first user message. With enhancement enabled, dsh-im safely sets a title without injected context blocks; without enhancement, the Harness-native automatic title is preserved. Titles are sanitized and truncated safely by UTF-8 byte length.

- 飞书流式回复在同一轮出现 Harness 问题或审批交互时，会先结束当前卡片并在交互完成后创建新卡片，使最终回答显示在交互卡片之后；卡片轮换失败时保持可用的降级投递。
  When a Feishu streaming turn presents an in-turn Harness question or approval, dsh-im now finalizes the current card and starts a new one after the interaction so the final answer appears below the interaction card, with usable fallback delivery if card rotation fails.

## [4.4.0] - 2026-09-01

### Added / 新增

- 九个 IM 渠道新增统一的机器人级“访问设置”：私聊与群聊可分别选择允许所有用户或仅白名单用户，并独立配置默认命令权限、命令权限例外及白名单用户权限。策略按 `botId` 原子保存，保存后对新入站消息立即生效；原 owner、扫码接入者等既有特权身份继续保留访问与完整命令权限，Telegram 与 WhatsApp 旧访问配置会自动迁移。
  All nine IM channels now provide unified per-bot Access settings. Direct and group chats can independently allow everyone or only allowlisted users, with separate default command permissions, command-permission overrides, and per-user allowlist permissions. Policies are atomically stored by `botId` and apply to new inbound messages immediately; existing privileged identities such as owners and QR provisioners retain full access and command permissions, while legacy Telegram and WhatsApp access settings migrate automatically.

### Changed / 变更

- 机器人卡片的设置页改为可扩展的横向 Tab 布局，现有 Bot ID、投递目标管理与专属使用文档统一归入“投递设置”页签。
  Bot-card settings now use an extensible horizontal tab layout, with the existing Bot ID, delivery-target management, and dedicated guide grouped under the Delivery settings tab.

### Fixed / 修复

- 飞书长连接现在会先按常见 `NO_PROXY` / `no_proxy` 语义排除 `open.feishu.cn` 与 `open.larksuite.com`，仅在未命中排除规则时使用代理环境变量，避免本地代理导致长连接持续失败重试。
  Feishu long connections now honor standard `NO_PROXY` / `no_proxy` matching for `open.feishu.cn` and `open.larksuite.com` before using proxy environment variables, preventing local proxies from forcing the connection into a retry loop.

- 飞书话题群中的卡片操作确认、watch 完成通知、命令及子流程失败提示现在都会回复到对应卡片或触发消息所在话题；没有可用话题锚点的历史数据继续沿用原有投递方式。
  Feishu card-action confirmations, watch completion notices, and command or sub-flow failures in topic groups now reply inside the topic containing the relevant card or triggering message; legacy entries without an anchor keep their previous delivery behavior.

## [4.3.0] - 2026-09-01

### Added / 新增

- 飞书话题群现在按 `thread_id` 为每个话题隔离 Harness Session、上下文、批量输入与待处理交互；普通群聊和私聊的会话键保持不变。回答流、命令结果、菜单卡片、Harness 问题及审批提示也会回复到触发消息所在话题，引用消息失效时安全回退为普通消息。
  Feishu topic groups now isolate Harness Sessions, context, batch input, and pending interactions by `thread_id`, while regular group and direct-chat keys remain unchanged. Answer streams, command results, menu cards, Harness questions, and approval prompts reply inside the triggering topic, with a safe plain-message fallback when the referenced message is unavailable.

- QQ 入站消息现在启用 SDK 表情标签解析，把不透明的 `<faceType=...>` 片段转换为 `【表情: 名称】` 等可读文本后再交给 Harness。
  QQ inbound messages now enable the SDK face-tag parser, converting opaque `<faceType=...>` fragments into readable text such as `【表情: name】` before delivery to Harness.

### Changed / 变更

- 上下文增强现在为群聊和私聊分别保存启用开关、来源字段与增强提示词，接收消息时只使用当前会话类型对应的配置。旧版共用字段与提示词会在升级后自动映射到两个场景，并在下一次成功写入机器人设置时无损保存为新结构，无需手工迁移。
  Context enhancement now stores independent enable switches, source fields, and guidance for group and direct chats, and inbound messages use only the matching conversation configuration. Existing shared fields and guidance are automatically mapped to both scopes after upgrade and are losslessly persisted in the new structure on the next successful bot-settings write, with no manual migration required.

## [4.2.1] - 2026-08-31

### Fixed / 修复

- Telegram 机器人现在为长轮询和发送请求使用同一 Runtime 私有、代理感知的有限连接池，避免全局 HTTP 连接受限时 `getUpdates` 阻塞消息发送；停止或启动失败时会显式释放连接池。
  Telegram bots now use a private, proxy-aware bounded connection pool per Runtime for both long polling and sends, preventing `getUpdates` from blocking delivery when global HTTP connections are constrained; the pool is explicitly released on stop and failed startup.

## [4.2.0] - 2026-08-31

### Added / 新增

- 飞书机器人启动时调用 `app_slash_commands` OpenAPI，把常用命令注册为原生 Slash Command，使飞书单聊输入框输入 `/` 弹出命令面板；命令清单由 dsh-im 持有并推送注册，不依赖 dsh/Harness 后端。扫码新建的应用默认申请所需权限，已有应用可通过“补全权限”或 `/repair` 增量补全；注册失败不影响消息收发。
  On startup the Feishu bot registers its common commands as native Slash Commands via the `app_slash_commands` OpenAPI, so the `/` panel appears in Feishu direct-message input. The command list is owned and pushed by dsh-im and does not depend on the dsh/Harness backend. New QR-provisioned apps request the required scopes by default, while existing apps can add them through Complete permissions or `/repair`; registration failure does not affect messaging.

## [4.1.1] - 2026-08-31

### Fixed / 修复

- QQ 扫码绑定的机器人现在会响应群内任意成员对机器人的 @ 消息，同时继续只接受扫码者的私聊；群聊仍不会响应未 @ 机器人的普通消息。
  QQ bots connected by QR code now respond when any group member mentions the bot, while private chats remain restricted to the scanner. Ordinary group messages without a mention remain ignored.

### Documentation / 文档

- 中英文 README 新增上下文增强界面截图和企业微信群入口，方便查看设置效果并加入用户社区。
  Added context-enhancement screenshots and the WeCom community-group entry to the Chinese and English READMEs, making the settings easier to preview and the user community easier to join.

## [4.1.0] - 2026-08-30

### Added / 新增

- 九个 IM 渠道统一支持基于稳定 `botId + targetId` 的主动投递：普通外部程序可调用 `POST /api/dsh-im/delivery/messages`，同 Host Cordis 插件可调用 `ctx.dshIm`，已有 Connection 客户端可调用 `/dsh-im-delivery` RPC；三个入口共用同一投递核心。机器人卡片新增设置页，可复制 Bot ID、管理多个目标并逐个真实测试。新建目标时优先从九渠道已持久化的 conversation keys 选择已聊会话并自动预填稳定路由及随机 `targetId`，手动填写保留为高级兜底并同样预填随机 `targetId`。候选不包含 Harness Session ID、聊天正文、会话名称或活跃时间，也不代表平台全量聊天。
  Added stable `botId + targetId` proactive delivery across all nine IM channels. Ordinary external programs can call `POST /api/dsh-im/delivery/messages`, same-Host Cordis plugins can call `ctx.dshIm`, and existing Connection clients can call `/dsh-im-delivery` RPC; all three entry points share one delivery core. Bot cards now open a settings page for copying Bot IDs, managing multiple targets, and testing each target with a real send. Creating a target now starts with conversations derived from persisted conversation keys across all nine channels and pre-fills both the stable native route and a random `targetId`; advanced manual entry also starts with a random `targetId`. Suggestions contain no Harness Session ID, message text, conversation name, or activity timestamp and are not a complete platform chat directory.

- 新增中英文主动投递使用指南，覆盖设置流程、九渠道字段、HTTP POST、同 Host 插件与 Connection RPC 示例、错误处理和排错；机器人投递设置页可按当前界面语言直接打开对应指南。
  Added Chinese and English proactive-delivery guides covering setup, native fields for all nine channels, HTTP POST, same-Host plugin and Connection RPC examples, errors, and troubleshooting. Bot delivery settings link directly to the guide matching the current UI language.

- 九个 IM 渠道新增 `/presets` 与 `/sessions` 快捷命令，分别作为 `/presetlist` 与 `/sessionlist` 的等价别名，不改变原有会话、工作区或 Agent Preset 行为。
  Added `/presets` and `/sessions` shortcuts across all nine IM channels as equivalent aliases for `/presetlist` and `/sessionlist`, without changing existing Session, workspace, or Agent Preset behavior.

## [4.0.1] - 2026-08-30

### Fixed / 修复

- 新版 DSH 中，机器人卡片的工作区目录选择器现在使用 `uiWorkspace` 目录服务，不再调用已从 Workspace Controller 移除的 `workspaces.listDirectory` / `pickDirectory`；旧版 Host 仍保留原接口回退。
  On current DSH releases, the bot-card workspace picker now uses the `uiWorkspace` directory service instead of the removed Workspace Controller `workspaces.listDirectory` / `pickDirectory` methods, while retaining the legacy Host fallback.

## [4.0.0] - 2026-08-29

### Fixed / 修复

- 本机 `dsh web` 与 DSH Desktop 现在同时兼容旧版和当前版 Host：旧版继续复用内部 `apiProxy`，当前版自动适配 Typert Gateway、Session Controller 与 Workspace Controller；两者都无需回环 HTTP 地址，并继续隔离不同 Host 的会话、审批与问题交互。显式 `harnessBaseUrl` 仅保留给旧版远程 HTTP/WebSocket Harness。
  Local `dsh web` and DSH Desktop now support both legacy and current Hosts. Legacy releases continue to reuse the internal `apiProxy`, while current releases automatically adapt the Typert Gateway plus Session and Workspace controllers. Neither requires a loopback HTTP address, and Sessions, approvals, and questions remain isolated between Hosts. Explicit `harnessBaseUrl` is retained only for legacy remote HTTP/WebSocket Harness endpoints.

## [3.2.0] - 2026-08-29

### Added / 新增

- 九个 IM 渠道的机器人设置新增可选“上下文增强”，可分别控制群聊与私聊，把勾选的渠道、会话类型、发送者和机器人来源字段连同自定义引导附加到普通用户消息；默认关闭、不额外查询平台资料，微信当前仅支持私聊。
  Added optional context enhancement to bot settings across all nine IM channels. It can independently target group and direct chats and attach selected channel, conversation, sender, and bot source fields plus custom guidance to ordinary user messages. It is off by default, performs no extra profile queries, and currently supports direct chats only on Weixin.

- 更新窗口新增手工更新命令及一键复制，页面更新失败时可在相同 Harness / Desktop 环境中通过 npm 更新；复制受限时可选中文本手动复制，安装完成后仍需手动重启。
  Added a manual npm update command and copy button to the update dialog for use in the same Harness / Desktop environment when the in-page update fails. The command remains selectable if clipboard access fails, and installation still requires a manual restart.

### Fixed / 修复

- 钉钉群聊的流式回复现在会在进度、完成和清理阶段保留对发送者的原生提及，无需额外发送提醒消息；私聊与批量回复失败处理保持原有行为。
  DingTalk streamed group replies now preserve the native mention of the sender across progress, completion, and cleanup without sending a separate reminder; direct chats and batch-reply failure handling retain their existing behavior.

## [3.1.1] - 2026-08-28

### Fixed / 修复

- 飞书流式回复超过单卡长度限制时保留预览，生成结束后分段发送完整回答，不再因超限抛错而撤回卡片；分段保留 Unicode 字符、空白和所有消息 ID，解决 Issue #78。
  Feishu streaming replies now keep a bounded preview and deliver the complete final answer across multiple cards instead of throwing and recalling the card when its length limit is exceeded. Splitting preserves Unicode characters, whitespace, and every message ID, resolving Issue #78.

## [3.1.0] - 2026-08-28

### Added / 新增

- 「设置 → IM机器人」新增 npm 更新检查和确认安装按钮，复用当前 Desktop / Harness 的包管理机制；保护源码链接、校验精确版本与目标 profile，不拉取 GitHub，安装后提示手动重启。手动重启后可「刷新状态」核验生效，无需重载原页面。更新功能不会主动重启或刷新；宿主自带的界面刷新不代表后台版本已生效。
  Added npm update checking and confirmed installation to Settings → IM Bot using the current Desktop / Harness package-management mechanism. It protects source links, verifies the exact version and target profile, uses no GitHub downloads, and requires a manual restart. Refresh status verifies the restarted Host without reloading the existing page. The updater does not request a restart or refresh; the host's own interface refresh does not mean the new backend version is running.

- 九个聊天渠道统一新增私聊命令 `/history [数量]`，只读预览当前绑定会话的最近对话：默认 3 条、最多 5 条，超出上限自动按 5 条处理；过滤工具、推理和未完成回复，长正文截断，并复用各渠道现有文字回复机制。命令不创建会话或调用模型，绑定成功提示和中英文帮助同步提供入口。
  Added `/history [count]` to direct chats on all nine channels to preview the bound Session's recent conversation without creating a Session or prompting the model. It defaults to 3 messages and caps larger counts at 5, omits tools, reasoning, and unfinished replies, truncates long text, and reuses each channel's existing text-reply mechanism. Binding confirmations and bilingual help now point to the command.

### Fixed / 修复

- 调整设置页渠道栏顶部间距，使渠道页签与扫码操作对齐。
  Adjusted the channel rail's top spacing to align channel tabs with the scan action in settings.

## [3.0.8] - 2026-08-28

### Fixed / 修复

- 本机 `dsh web` 与 DSH Desktop 的 IM 渠道和 AI Office 现在默认直接使用当前 Host 的内部 `apiProxy`，不再依赖回环 HTTP 端口或 Desktop 的浏览器/局域网访问开关；显式配置 `harnessBaseUrl` 时仍使用 HTTP/WebSocket，内部调用失败不会静默切换 Host。
  IM channels and AI Office in local `dsh web` and DSH Desktop now use the current Host's internal `apiProxy` by default, removing the dependency on loopback HTTP ports or Desktop's browser/LAN access settings. Explicit `harnessBaseUrl` configurations still use HTTP/WebSocket, and failed internal calls never silently switch Hosts.

## [3.0.7] - 2026-08-27

### Fixed / 修复

- `/compact` 同时兼容要求 `images` 字段的新 Harness 与不接受该字段的旧 Harness；仅在网关明确拒绝多余字段、命令尚未执行时回退，避免重复压缩。
  `/compact` now supports both newer Harness endpoints that require `images` and older endpoints that reject it, falling back only after an explicit pre-execution field rejection to avoid duplicate compaction.

### Documentation / 文档

- 中英文 README 的联系方式新增 WhatsApp 二维码。
  Added a WhatsApp contact QR code to the Chinese and English READMEs.

## [3.0.6] - 2026-08-26

### Fixed / 修复

- 工作区目录选择器现在可以直接输入 Windows 盘符、UNC 共享或 POSIX 绝对路径并跳转；输入的目录无法读取时不会误选先前浏览的目录，解决 Issue #69。
  The workspace directory picker now accepts direct Windows drive, UNC share, and POSIX absolute paths; an unreadable typed path can no longer accidentally select the previously browsed directory, resolving Issue #69.
- 微信回复发送失败时会记录并展示脱敏的接口、域名、分段大小、上下文状态、HTTP 状态和平台错误码诊断，便于定位长回复部分投递等问题，同时不会泄露令牌或平台原始错误详情。
  Failed WeChat reply delivery now records and presents sanitized endpoint, host, chunk-size, context, HTTP-status, and provider-code diagnostics for troubleshooting issues such as partially delivered long replies, without exposing tokens or raw provider error details.

## [3.0.5] - 2026-08-26

### Fixed / 修复

- 微信扫码绑定和消息接口现在同时信任腾讯的 `wechat.com` 国际域名及其子域名，国际环境下的二维码验证、登录重定向和消息连接不再被错误拒绝，同时继续拦截伪装后缀域名。
  WeChat QR provisioning and messaging APIs now also trust Tencent's international `wechat.com` domain and its subdomains, preventing valid QR verification, login redirects, and message connections from being rejected in international environments while still blocking lookalike suffix domains.

## [3.0.4] - 2026-08-26

### Changed / 变更

- 回退 3.0.3 中未计划进入 `main` 的 WhatsApp 群聊提及、回复识别与群成员调用白名单改动；WhatsApp 行为恢复到 3.0.2。
  Reverted the WhatsApp group mention/reply detection and group-caller allowlist changes from 3.0.3 that were not intended for `main`; WhatsApp behavior returns to 3.0.2.

## [3.0.3] - 2026-08-26

### Fixed / 修复

- WhatsApp 开放响应模式现在会正确识别群聊中的提及和回复，并使用与私聊联系人分开保存的群成员号码列表控制调用者；群成员列表为空时允许所有群成员。
  WhatsApp Open responses now correctly recognize group mentions and replies and use a separately stored group-member number list to control callers; an empty group list allows every group member.
- 机器人卡片在窄屏布局下仍会把连接状态保持在卡片右上角，不再移动到机器人信息下方。
  Bot cards now keep connection status in the top-right corner on narrow layouts instead of moving it below the bot identity.
- 企业微信流式回复现在会把思考过程与最终答案分开呈现，工具进度只更新思考区域，避免覆盖或混入答案正文。
  WeCom streaming replies now present thinking separately from the final answer, with tool progress updating only the thinking area instead of overwriting or mixing into the answer body.

## [3.0.2] - 2026-08-26

### Fixed / 修复

- 设置页现在会在 `DSH-IM` 品牌标题旁常驻显示当前插件版本，不再需要悬停或键盘聚焦才能查看。
  The settings page now displays the current plugin version persistently beside the `DSH-IM` brand heading instead of requiring hover or keyboard focus.

## [3.0.1] - 2026-08-26

### Fixed / 修复

- QQ 私聊最终回答现在使用标准 Markdown 消息投递，避免部分客户端确认流式最终帧却不显示内容；长回答会安全拆分代码块和 GFM 表格，遵守被动回复配额，并仅在平台明确拒绝 Markdown 时逐段回退纯文本，避免不确定结果造成重复回复。
  QQ direct-message final answers now use standard Markdown delivery to avoid clients that acknowledge but do not render final streaming frames. Long answers safely split fenced code and GFM tables, respect passive-reply quotas, and fall back to plain text per chunk only after a definite Markdown rejection, preventing duplicate replies after uncertain outcomes.
- 优化英文设置界面的文案与间距，限制 Telegram 机器人卡片在窄面板内自适应显示，并把版本提示移到品牌标题下方，避免内容溢出或提示被裁切。
  Polished English settings copy and spacing, constrained Telegram bot cards within narrow panels, and moved the version tooltip below the brand heading to prevent overflow or clipping.

### Documentation / 文档

- 英文 README 新增设置界面预览图。
  Added a settings interface preview to the English README.

## [3.0.0] - 2026-08-25

### Changed / 变更

- 「IM机器人」设置页已从插件页签迁移到一级设置菜单，并以 `order: 21` 尽量排在「Agent 预设」之后；新版不再注册旧二级入口。升级后重启 `dsh web` 并刷新浏览器即可使用，已有机器人配置和页面内的渠道专属 Logo 保持不变。
  The **IM Bot** settings page has moved from a Plugins tab to the top-level settings menu and uses `order: 21` to follow **Agent Presets**. The new release no longer registers the legacy nested entry. Restart `dsh web` and refresh the browser after upgrading; existing bot configuration and channel-specific logos inside the page are preserved.

### Fixed / 修复

- 飞书中不含附件且仅有一个文本段落的富文本消息，如果内容是插件命令，现在会按普通文本命令处理，不再转发给 Harness。
  In Feishu, attachment-free rich-text messages containing a single text paragraph are now handled as ordinary plugin commands instead of being forwarded to Harness.

## [2.6.0] - 2026-08-25

### Added / 新增

- 飞书、钉钉、Slack、Telegram、Discord 和 WhatsApp 现在会通过消息 Reaction 显示任务正在处理、成功或失败；Reaction 调用采用限时的尽力而为机制，不会阻塞正常回复。Slack App Manifest 同步加入 `reactions:write`，已有 App 需要重新授权或安装后再连接机器人。
  Feishu, DingTalk, Slack, Telegram, Discord, and WhatsApp now use message reactions to show processing, success, or failure. Reaction calls are time-bounded and best-effort, so they never block normal replies. The Slack App Manifest now includes `reactions:write`; existing Apps must be re-authorized or reinstalled before reconnecting the bot.

### Fixed / 修复

- 当交互答案提交或后续交互问题发送失败时，消息会保留失败 Reaction，不再被外层处理流程覆盖为成功状态。
  When submitting an interaction answer or presenting a follow-up interaction question fails, the message now retains its failure reaction instead of being overwritten as successful by the outer processing flow.

## [2.5.0] - 2026-08-25

### Added / 新增

- 插件设置页的 DSH-IM 品牌标题现在支持悬停或键盘聚焦显示当前插件版本。
  The DSH-IM brand heading in plugin settings now displays the current plugin version on hover or keyboard focus.
- 九种内置聊天渠道新增结构化消息失败报告：会针对 Harness 连接、模型、会话、输入和渠道投递等故障给出可执行的中英文提示，并附带错误码与参考号；机器人设置卡片也会显示最近一次消息处理失败。
  Added structured message failure reporting across all nine built-in chat channels, with actionable bilingual guidance for Harness connectivity, model, Session, input, and channel-delivery failures, plus an error code and reference ID; bot cards also show the latest message-processing failure.
- 微信机器人现在会在 Harness 处理消息期间显示“正在输入”，并在最终回复、交互问题、错误或任务停止前自动取消；输入状态接口不可用时仍会正常发送最终回答。
  WeChat bots now show a typing indicator while Harness processes a message and automatically cancel it before final replies, interaction questions, errors, or stopped turns; final answers still work when the typing API is unavailable.

## [2.4.0] - 2026-08-25

### Added / 新增

- 九种内置聊天渠道新增 `/version` 命令，可直接查看当前运行的 dsh-im 插件版本；该命令不会连接 Harness、创建 Session 或调用模型。
  Added a `/version` command across all nine built-in chat channels for displaying the running dsh-im plugin version without contacting Harness, creating a Session, or invoking the model.

### Changed / 变更

- 飞书原“修复卡片按钮”操作已更名为“补全权限”，并会同时增量申请读取用户消息内图片或文件所需的 `im:message:readonly`、上传机器人图片或文件所需的 `im:resource`，以及卡片回调；缺权提示会引导用户私聊执行 `/repair`，或在插件页面点击“补全权限”。界面会说明各自用途，并明确确认页只展示应用当前缺少的配置。
  The former Feishu **Repair card buttons** action is now **Complete permissions**. It incrementally requests `im:message:readonly` for reading images or files in user messages, `im:resource` for uploading bot-sent images or files, and the card callback. The UI explains each purpose and that the confirmation page shows only the app's currently missing items.
- 飞书 `/repair` 不再额外区分管理员和普通用户；所有通过当前机器人渠道访问策略的私聊用户都能发起修复，包括使用 `*` 开放访问的手动绑定机器人。
  Feishu `/repair` no longer defines a separate administrator role. Any direct-message user admitted by the current bot's channel access policy can start repair, including manually bound bots configured with `*` access.
- 飞书私聊重复发送普通 `/repair` 时会作废仍在等待授权的旧一次性链接并生成新链接，避免错误账号打开链接后继续复用已消耗的授权码；查询、二维码、验证和取消命令不会意外重启流程，已提交的平台更新也不会并发执行。
  Repeating bare `/repair` in a Feishu direct chat now invalidates a still-pending one-time authorization link and generates a fresh one, avoiding reuse after the link was opened under the wrong account. Status, QR, verify, and cancel commands do not restart the flow, and a platform update that has already been submitted is never duplicated concurrently.

## [2.3.0] - 2026-08-25

### Added / 新增

- 九种内置聊天渠道新增私聊批量输入命令：使用 `/batch` 暂存最多 10 条纯文字消息，使用 `/send` 按原顺序合并为一次 Harness 输入，或使用 `/cancel` 放弃当前批次；提交失败时会保留内容以便重试。
  Added private-chat batch input commands to all nine built-in chat channels: `/batch` collects up to 10 text-only messages, `/send` submits them in order as one Harness input, and `/cancel` discards the batch; failed submissions retain their content for retry.

## [2.2.1] - 2026-08-25

### Fixed / 修复

- WhatsApp 开放响应模式现在会处理已绑定账号自己在群聊中发出的消息，包括只有自己的群；出站文本消息会在发送前预留消息 ID，避免机器人回复的本地回显再次触发 Harness。
  WhatsApp Open responses now handles group messages sent by the linked account, including owner-only groups; outbound text message IDs are reserved before sending so local reply echoes cannot trigger Harness again.

## [2.2.0] - 2026-08-25

### Added / 新增

- 所有聊天渠道新增 `/reasoninglist`、`/reasonings` 和 `/reasoning` 命令，可查看当前模型支持的推理等级、切换指定等级或恢复模型默认值；`/model` 也支持在切换模型时同时指定推理等级。
  Added `/reasoninglist`, `/reasonings`, and `/reasoning` commands across all chat channels for listing the current model's reasoning efforts, selecting an effort, or restoring the model default; `/model` can also select a reasoning effort while switching models.

### Fixed / 修复

- 当浏览器使用不兼容的回环地址访问 Web 设置页并触发 RPC 403 时，插件现在会提供保留当前端口的 `localhost` 恢复入口，避免各 IM 渠道配置页面持续请求失败。
  When an incompatible loopback address causes RPC 403 responses in the Web settings UI, the plugin now offers a `localhost` recovery link that preserves the current port, preventing persistent request failures across IM channel settings.
- 微信长回复现在在桥接层和运行时统一按腾讯 iLink 的 1,800 字符限制分段发送，避免超长回复被平台拒绝或截断。
  Long WeChat replies are now split consistently at Tencent iLink's 1,800-character limit across the bridge and runtime, preventing oversized replies from being rejected or truncated.
- Telegram Bot API 无法连接时会给出明确的代理诊断提示，并补充 Node 环境代理、`HTTPS_PROXY` 和 `NO_PROXY` 的中英文配置说明。
  Telegram Bot API connection failures now provide actionable proxy diagnostics, with bilingual setup guidance for Node environment proxy support, `HTTPS_PROXY`, and `NO_PROXY`.

## [2.1.0] - 2026-08-24

### Added / 新增

- 飞书 `/m` 菜单升级为交互式助手中心，集中提供会话、工作区、Agent Preset 和模型下拉切换，以及新会话、任务停止、上下文压缩、补充指令、关注管理和归档显示控制。
  The Feishu `/m` menu is now an interactive assistant center with dropdowns for sessions, workspaces, Agent Presets, and models, plus controls for new sessions, task stopping, context compaction, steering, watch management, and archived-session visibility.

### Changed / 变更

- 飞书菜单按设置、会话和任务控制重新组织；`/m` 会发送一张新菜单卡片，卡片内的导航和配置操作会尽量原位刷新，减少聊天中的重复卡片。
  The Feishu menu is reorganized around settings, sessions, and task controls; `/m` sends a new menu card, while navigation and configuration actions refresh it in place whenever possible to reduce duplicate cards in chat.

### Fixed / 修复

- 加固飞书卡片回调的字段兼容、串行执行、重试去重、并发上限和超时降级，避免快速或重复点击造成重复操作、状态错乱或 Host 请求堆积。
  Hardened Feishu card callbacks with payload compatibility, serialized execution, retry deduplication, concurrency limits, and timeout fallbacks, preventing rapid or repeated clicks from duplicating actions, corrupting state, or exhausting Host requests.
- 改进飞书 Session 关注完成事件的基线、重连补偿和并发处理，避免错过完成通知、重复推送或阻塞无关 Session。
  Improved baselining, reconnect compensation, and concurrent handling for Feishu Session-watch completion events, preventing missed notifications, duplicate deliveries, and blocking between unrelated Sessions.
- 修复飞书 WebSocket 在握手阶段关闭时的清理竞态，并阻止任务或交互尚未结束时误建新 Session。
  Fixed the Feishu WebSocket cleanup race when closing during the handshake, and prevented new Sessions from being created while a task or interaction is still pending.

## [2.0.1] - 2026-08-24

### Fixed / 修复

- 机器人卡片的操作区域现在会在空间不足时自动换行，避免英文或其他较长本地化文案把操作按钮挤出可视区域。
  Bot-card actions now wrap when space is limited, preventing English or other longer localized labels from pushing actions out of view.
- 一个 IM 渠道激活失败时，Host 现在会记录错误并继续依次激活其他渠道，避免单个渠道的本地配置或初始化故障阻断其余渠道。
  When one IM channel fails to activate, the Host now logs the error and continues activating the remaining channels in order, so a channel-local configuration or initialization failure cannot block the others.

## [2.0.0] - 2026-08-24

### Added / 新增

- Discord 服务器文字和公告频道首次 @ 机器人后会创建原生 Thread；后续消息、流式回答和结果文件都留在该 Thread，并在重启、事件重放和并发创建时保持同一会话。
  The first bot mention in a Discord server text or announcement channel now creates a native Thread; follow-up messages, streamed replies, and result files stay in that Thread, with stable routing across restarts, event replays, and concurrent creation attempts.
- Telegram 新增原生 Rich Message：私聊使用可更新 Draft 并持久化唯一最终消息，群聊和 Topic 原位完成占位消息，同时保留 Markdown 结构、长内容拆分和确定性纯文本降级。
  Added native Telegram Rich Messages: private chats update a Draft and persist one final message, while groups and Topics finalize their placeholder in place, preserving Markdown structure, long-content splitting, and deterministic plain-text fallback.
- 新增机器人聊天消息的英文支持：Host 配置 `language: en`（或环境变量 `DSH_IM_LANGUAGE=en`）后，各渠道发送给用户的提示、命令帮助和交互消息会切换为英文；未设置或未收录的文案仍以中文原样输出，不影响现有中文用户。
  Added English support for bot chat messages: with `language: en` in the Host config (or the `DSH_IM_LANGUAGE=en` environment variable), prompts, command help, and interaction messages sent by every channel switch to English; unset or untranslated text is still sent verbatim in Chinese, so existing Chinese users are unaffected.

### Changed / 变更

- **重大变更：** Discord 服务器父频道中的任务现在默认迁移到机器人创建的 Public Thread。部署方需要启用 **Message Content Intent**，并授予 **Create Public Threads**、**Send Messages in Threads**、**Send Messages** 和 **Read Message History**；文件交付还需要 **Attach Files**。
  **Breaking:** Discord tasks started in server parent channels now move into bot-created Public Threads by default. Deployments must enable **Message Content Intent** and grant **Create Public Threads**, **Send Messages in Threads**, **Send Messages**, and **Read Message History**; file delivery also requires **Attach Files**.
- Harness 助手增量和最终回答现在保留 Markdown 呈现意图，Telegram 交付回执会记录 Rich、纯文本降级、失败或不确定终态，并避免重复最终消息。
  Harness assistant updates and final replies now preserve Markdown presentation intent; Telegram delivery receipts record Rich delivery, plain-text fallback, failure, or uncertain terminal outcomes without duplicating final messages.
- 统一各渠道共用的英文文案到共享词典，消除同名键在不同渠道词典中的重复定义。
  Consolidated English copy shared across channels into the shared dictionaries, removing duplicate keys that were defined in multiple channel dictionaries.

### Fixed / 修复

- 最终文本交付明确失败时会向渠道上层报告安全错误，同时仍然完成已登记结果文件的交付，不会重复运行 Prompt。
  Definite final-text delivery failures now surface a safe channel-level error while registered result files still settle, without rerunning the Prompt.
- 收紧 Host 语言值识别并修复 Discord、Slack、Telegram 等渠道的英文消息边界，未知语言继续可靠回退为中文。
  Hardened Host language-value recognition and English-message handling in Discord, Slack, Telegram, and other channels, while unknown languages continue to fall back reliably to Chinese.

## [1.5.0] - 2026-08-24

### Added / 新增

- Harness 返回的图片现在会在九个内置 IM 渠道中优先使用原生图片消息呈现；渠道不支持或明确拒绝图片发送时自动回退为文件附件。
  Images returned by Harness now prefer native image messages across all nine built-in IM channels, with automatic file-attachment fallback when a channel does not support or definitively rejects image delivery.

### Changed / 变更

- 统一结果文件与图片的发送、交付回执、失败提示和资源释放，并在发送结果不确定时避免补发文件造成重复消息。
  Unified result-file and image sending, delivery receipts, failure notices, and resource cleanup, while avoiding duplicate file fallback when an image delivery result is uncertain.

## [1.4.0] - 2026-08-24

### Added / 新增

- QQ 最终回答现在支持 Markdown；长回答会尽量按代码块和 GFM 表格边界切分，平台拒绝 Markdown 时自动回退为纯文本。
  QQ final answers now support Markdown; long answers are split around code blocks and GFM tables where possible, with automatic plain-text fallback when QQ rejects Markdown.

### Changed / 变更

- QQ 私聊把进度和最终答案收束在一个回复气泡中，群聊只发送最终答案；工具失败会附在最终回答中，避免成功工具和状态消息刷屏。
  QQ private chats keep progress and the final answer in one reply bubble, while group chats send only the final answer; tool failures are appended to the final response without spamming successful tool or status messages.
- 长 QQ 回答使用唯一消息序号并避开被动回复额度，降低重复去重和超额发送失败。
  Long QQ answers use unique message sequence numbers and avoid passive-reply quotas, reducing duplicate suppression and over-quota delivery failures.

## [1.3.0] - 2026-08-23

### Added / 新增

- 九个内置 IM 渠道现在都能接收普通文件，并把文件随同用户消息安全地交给当前 Harness Session。
  All nine built-in IM channels can now receive ordinary files and safely pass them with the user message to the active Harness Session.

### Changed / 变更

- 统一入站文件的提前下载、工作区暂存、路径保护、失败提示和 Turn 结束清理，并继续由各消息平台决定文件类型、数量和大小限制。
  Unified inbound-file prefetching, workspace staging, path protection, failure messages, and end-of-Turn cleanup, while leaving file type, count, and size limits to each messaging platform.

## [1.2.0] - 2026-08-23

### Added / 新增

- WhatsApp 新增仅自己、指定联系人和开放响应三种访问模式；旧机器人和新接入机器人均默认仅响应账号自聊。
  Added Only me, Selected contacts, and Open responses access modes for WhatsApp; existing and newly linked bots now default to self-chat only.

## [1.1.0] - 2026-08-23

### Added / 新增

- 新增 Harness 结果文件的原生交付能力，支持通过钉钉、Discord、飞书、QQ、Slack、Telegram、企业微信、微信和 WhatsApp 返回文件。
  Added native delivery of Harness result files through DingTalk, Discord, Feishu, QQ, Slack, Telegram, WeCom, Weixin, and WhatsApp.
- 新增统一的结果文件快照、交付回执、失败分类与消息 ID 追踪。
  Added unified result-file snapshots, delivery receipts, failure classifications, and message ID tracking.

### Changed / 变更

- 压缩机器人连接元数据布局，并统一各频道卡片的反馈样式。
  Compacted bot connection metadata and unified feedback styling across channel cards.
- 将 Agent Preset 使用说明移入可访问的帮助提示。
  Moved Agent Preset guidance into an accessible help tooltip.

### Fixed / 修复

- 改进微信对 Harness 访问失败、回环地址拒绝和健康检查错误的提示。
  Improved Weixin messages for Harness access failures, loopback denials, and health-check errors.

## [1.0.2] - 2026-08-22

### Fixed / 修复

- 飞书 REST 请求和 WebSocket 连接现在都会遵循系统代理设置。
  Feishu REST requests and WebSocket connections now honor system proxy settings.

## [1.0.1] - 2026-08-22

### Fixed / 修复

- 改进微信对 Harness 健康检查失败的分类和安全提示。
  Improved the classification and safe messaging of Harness health-check failures in Weixin.

## [1.0.0] - 2026-08-22

### Added / 新增

- 新增 `/presetlist` 与 `/preset` 聊天命令，可查看和切换 Agent Preset，并支持恢复跟随 Host 默认值。
  Added `/presetlist` and `/preset` chat commands for viewing and switching Agent Presets, including returning to the Host default.

## [0.19.0] - 2026-08-22

### Added / 新增

- Telegram 启动时注册命令菜单和菜单按钮。
  Telegram now registers its command menu and menu button when the bot starts.
- 飞书新增群聊响应模式配置和群消息权限授权流程。
  Added configurable group response modes and group-message permission authorization for Feishu.

## [0.18.0] - 2026-08-22

### Added / 新增

- 支持为每个机器人独立选择 Agent Preset，并完成创建、持久化和会话启动生命周期。
  Added per-bot Agent Preset selection across bot creation, persistence, and session startup.

## [0.17.1] - 2026-08-21

### Fixed / 修复

- 当模型不支持图片输入时，各频道会返回更明确的提示。
  Channels now provide clearer feedback when a model does not support image input.

## [0.17.0] - 2026-08-21

### Added / 新增

- 飞书新增持久化 Session 关注、完成推送和菜单入口。
  Added persistent Session watches, completion notifications, and a watch menu entry for Feishu.
- 飞书 Session 列表支持关注按钮、归档标记和 `/archived on|off` 切换。
  Feishu Session lists now include watch buttons, archived badges, and the `/archived on|off` toggle.

### Fixed / 修复

- 改进飞书关注完成消息的可靠交付和重连补偿。
  Improved reliable delivery and reconnect compensation for Feishu watch completions.

## [0.16.0] - 2026-08-21

### Added / 新增

- 飞书新增交互式菜单卡片、Session/工作区列表卡片和一键回调修复。
  Added interactive menu cards, Session and workspace list cards, and one-click callback repair for Feishu.

### Fixed / 修复

- 改进飞书交互卡片回调的可靠性。
  Improved the reliability of Feishu interactive-card callbacks.

## [0.15.0] - 2026-08-21

### Changed / 变更

- 将 AI Office 连接器标记为实验性功能。
  Marked the AI Office connector as experimental.

### Fixed / 修复

- 改进微信机器人激活失败的分类和提示。
  Improved classification and messaging for Weixin bot activation failures.

## [0.14.0] - 2026-08-21

### Added / 新增

- 新增 AI Office 连接器，并支持在 Harness 中执行 Office 任务。
  Added the AI Office connector and support for executing Office jobs in Harness.
- 加强 Telegram 私聊访问控制。
  Strengthened access control for Telegram private chats.

### Changed / 变更

- 更新插件品牌、README 视觉和 AI Office 配置示例。
  Updated plugin branding, README visuals, and the AI Office configuration example.

## [0.13.0] - 2026-08-20

### Added / 新增

- 支持通过编号选择模型。
  Added model selection by list number.

### Changed / 变更

- 完善机器人交互、多机器人能力和频道配置文档。
  Expanded documentation for bot interactions, multi-bot support, and channel setup.
- 加强发布包检查，避免捆绑 DSH 运行时包。
  Strengthened package verification to prevent bundling DSH runtime packages.

## [0.12.0] - 2026-08-20

### Added / 新增

- 新增模型查看、模型切换、停止和引导当前 Turn 的聊天命令。
  Added chat commands for listing and switching models, stopping work, and steering the active Turn.

### Changed / 变更

- 改进 npm 安装文档、包元数据和项目徽章。
  Improved npm installation documentation, package metadata, and project badges.

## [0.11.0] - 2026-08-19

### Added / 新增

- 建立统一 IM 插件的首个保留标签版本，集中管理飞书、微信、钉钉、企业微信、QQ、Slack、Telegram、Discord 和 WhatsApp。
  Established the first retained tag of the unified IM plugin, covering Feishu, Weixin, DingTalk, WeCom, QQ, Slack, Telegram, Discord, and WhatsApp.
- 支持多机器人、工作区切换、Session 列表与绑定、Harness 交互和审批、图片输入及连接测试。
  Added multi-bot support, workspace switching, Session listing and binding, Harness interactions and approvals, image input, and connection tests.
- 支持按 Harness 默认 Agent Preset 创建 IM Session。
  Added IM Session creation using the Harness default Agent Preset.

### Changed / 变更

- 完成双语 README、插件品牌、深色主题和紧凑机器人卡片。
  Added a bilingual README, plugin branding, dark-theme support, and compact bot cards.
- 改进 npm 发布包结构，保留 CLI 入口并避免安装脚本拦截。
  Improved npm package contents to preserve the CLI entry point and avoid install-script blocking.

[Unreleased]: https://github.com/xmanrui/dsh-im/compare/v4.38.0...HEAD
[4.38.0]: https://github.com/xmanrui/dsh-im/compare/v4.37.0...v4.38.0
[4.37.0]: https://github.com/xmanrui/dsh-im/compare/v4.36.1...v4.37.0
[4.36.1]: https://github.com/xmanrui/dsh-im/compare/v4.36.0...v4.36.1
[4.36.0]: https://github.com/xmanrui/dsh-im/compare/v4.35.1...v4.36.0
[4.35.1]: https://github.com/xmanrui/dsh-im/compare/v4.35.0...v4.35.1
[4.35.0]: https://github.com/xmanrui/dsh-im/compare/v4.34.2...v4.35.0
[4.34.2]: https://github.com/xmanrui/dsh-im/compare/v4.34.1...v4.34.2
[4.34.1]: https://github.com/xmanrui/dsh-im/compare/v4.34.0...v4.34.1
[4.34.0]: https://github.com/xmanrui/dsh-im/compare/v4.33.0...v4.34.0
[4.33.0]: https://github.com/xmanrui/dsh-im/compare/v4.32.0...v4.33.0
[4.32.0]: https://github.com/xmanrui/dsh-im/compare/v4.31.0...v4.32.0
[4.31.0]: https://github.com/xmanrui/dsh-im/compare/v4.30.0...v4.31.0
[4.30.0]: https://github.com/xmanrui/dsh-im/compare/v4.29.1...v4.30.0
[4.29.1]: https://github.com/xmanrui/dsh-im/compare/v4.29.0...v4.29.1
[4.29.0]: https://github.com/xmanrui/dsh-im/compare/v4.28.1...v4.29.0
[4.28.1]: https://github.com/xmanrui/dsh-im/compare/v4.28.0...v4.28.1
[4.28.0]: https://github.com/xmanrui/dsh-im/compare/v4.27.0...v4.28.0
[4.27.0]: https://github.com/xmanrui/dsh-im/compare/v4.26.0...v4.27.0
[4.26.0]: https://github.com/xmanrui/dsh-im/compare/v4.25.0...v4.26.0
[4.25.0]: https://github.com/xmanrui/dsh-im/compare/v4.24.1...v4.25.0
[4.24.1]: https://github.com/xmanrui/dsh-im/compare/v4.24.0...v4.24.1
[4.24.0]: https://github.com/xmanrui/dsh-im/compare/v4.23.0...v4.24.0
[4.23.0]: https://github.com/xmanrui/dsh-im/compare/v4.22.0...v4.23.0
[4.22.0]: https://github.com/xmanrui/dsh-im/compare/v4.21.2...v4.22.0
[4.21.2]: https://github.com/xmanrui/dsh-im/compare/v4.21.1...v4.21.2
[4.21.1]: https://github.com/xmanrui/dsh-im/compare/v4.21.0...v4.21.1
[4.21.0]: https://github.com/xmanrui/dsh-im/compare/v4.20.2...v4.21.0
[4.20.2]: https://github.com/xmanrui/dsh-im/compare/v4.20.1...v4.20.2
[4.20.1]: https://github.com/xmanrui/dsh-im/compare/v4.20.0...v4.20.1
[4.20.0]: https://github.com/xmanrui/dsh-im/compare/v4.19.2...v4.20.0
[4.19.2]: https://github.com/xmanrui/dsh-im/compare/v4.19.1...v4.19.2
[4.19.1]: https://github.com/xmanrui/dsh-im/compare/v4.19.0...v4.19.1
[4.19.0]: https://github.com/xmanrui/dsh-im/compare/v4.18.1...v4.19.0
[4.18.1]: https://github.com/xmanrui/dsh-im/compare/v4.18.0...v4.18.1
[4.18.0]: https://github.com/xmanrui/dsh-im/compare/v4.17.1...v4.18.0
[4.17.1]: https://github.com/xmanrui/dsh-im/compare/v4.17.0...v4.17.1
[4.17.0]: https://github.com/xmanrui/dsh-im/compare/v4.16.1...v4.17.0
[4.16.1]: https://github.com/xmanrui/dsh-im/compare/v4.16.0...v4.16.1
[4.16.0]: https://github.com/xmanrui/dsh-im/compare/v4.15.0...v4.16.0
[4.15.0]: https://github.com/xmanrui/dsh-im/compare/v4.14.0...v4.15.0
[4.14.0]: https://github.com/xmanrui/dsh-im/compare/v4.13.0...v4.14.0
[4.13.0]: https://github.com/xmanrui/dsh-im/compare/v4.12.0...v4.13.0
[4.12.0]: https://github.com/xmanrui/dsh-im/compare/v4.11.0...v4.12.0
[4.11.0]: https://github.com/xmanrui/dsh-im/compare/v4.10.0...v4.11.0
[4.10.0]: https://github.com/xmanrui/dsh-im/compare/v4.9.1...v4.10.0
[4.9.1]: https://github.com/xmanrui/dsh-im/compare/v4.9.0...v4.9.1
[4.9.0]: https://github.com/xmanrui/dsh-im/compare/v4.8.0...v4.9.0
[4.8.0]: https://github.com/xmanrui/dsh-im/compare/v4.7.0...v4.8.0
[4.7.0]: https://github.com/xmanrui/dsh-im/compare/v4.6.0...v4.7.0
[4.6.0]: https://github.com/xmanrui/dsh-im/compare/v4.5.0...v4.6.0
[4.5.0]: https://github.com/xmanrui/dsh-im/compare/v4.4.0...v4.5.0
[4.4.0]: https://github.com/xmanrui/dsh-im/compare/v4.3.0...v4.4.0
[4.3.0]: https://github.com/xmanrui/dsh-im/compare/v4.2.1...v4.3.0
[4.2.1]: https://github.com/xmanrui/dsh-im/compare/v4.2.0...v4.2.1
[4.2.0]: https://github.com/xmanrui/dsh-im/compare/v4.1.1...v4.2.0
[4.1.1]: https://github.com/xmanrui/dsh-im/compare/v4.1.0...v4.1.1
[4.1.0]: https://github.com/xmanrui/dsh-im/compare/v4.0.1...v4.1.0
[4.0.1]: https://github.com/xmanrui/dsh-im/compare/v4.0.0...v4.0.1
[4.0.0]: https://github.com/xmanrui/dsh-im/compare/v3.2.0...v4.0.0
[3.2.0]: https://github.com/xmanrui/dsh-im/compare/v3.1.1...v3.2.0
[3.1.1]: https://github.com/xmanrui/dsh-im/compare/v3.1.0...v3.1.1
[3.1.0]: https://github.com/xmanrui/dsh-im/compare/v3.0.8...v3.1.0
[3.0.8]: https://github.com/xmanrui/dsh-im/compare/v3.0.7...v3.0.8
[3.0.7]: https://github.com/xmanrui/dsh-im/compare/v3.0.6...v3.0.7
[3.0.6]: https://github.com/xmanrui/dsh-im/compare/v3.0.5...v3.0.6
[3.0.5]: https://github.com/xmanrui/dsh-im/compare/v3.0.4...v3.0.5
[3.0.4]: https://github.com/xmanrui/dsh-im/compare/v3.0.3...v3.0.4
[3.0.3]: https://github.com/xmanrui/dsh-im/compare/v3.0.2...v3.0.3
[3.0.2]: https://github.com/xmanrui/dsh-im/compare/v3.0.1...v3.0.2
[3.0.1]: https://github.com/xmanrui/dsh-im/compare/v3.0.0...v3.0.1
[3.0.0]: https://github.com/xmanrui/dsh-im/compare/v2.6.0...v3.0.0
[2.6.0]: https://github.com/xmanrui/dsh-im/compare/v2.5.0...v2.6.0
[2.5.0]: https://github.com/xmanrui/dsh-im/compare/v2.4.0...v2.5.0
[2.4.0]: https://github.com/xmanrui/dsh-im/compare/v2.3.0...v2.4.0
[2.3.0]: https://github.com/xmanrui/dsh-im/compare/v2.2.1...v2.3.0
[2.2.1]: https://github.com/xmanrui/dsh-im/compare/v2.2.0...v2.2.1
[2.2.0]: https://github.com/xmanrui/dsh-im/compare/v2.1.0...v2.2.0
[2.1.0]: https://github.com/xmanrui/dsh-im/compare/v2.0.1...v2.1.0
[2.0.1]: https://github.com/xmanrui/dsh-im/compare/v2.0.0...v2.0.1
[2.0.0]: https://github.com/xmanrui/dsh-im/compare/v1.5.0...v2.0.0
[1.5.0]: https://github.com/xmanrui/dsh-im/compare/v1.4.0...v1.5.0
[1.4.0]: https://github.com/xmanrui/dsh-im/compare/v1.3.0...v1.4.0
[1.3.0]: https://github.com/xmanrui/dsh-im/compare/v1.2.0...v1.3.0
[1.2.0]: https://github.com/xmanrui/dsh-im/compare/v1.1.0...v1.2.0
[1.1.0]: https://github.com/xmanrui/dsh-im/compare/v1.0.2...v1.1.0
[1.0.2]: https://github.com/xmanrui/dsh-im/compare/v1.0.1...v1.0.2
[1.0.1]: https://github.com/xmanrui/dsh-im/compare/v1.0.0...v1.0.1
[1.0.0]: https://github.com/xmanrui/dsh-im/compare/v0.19.0...v1.0.0
[0.19.0]: https://github.com/xmanrui/dsh-im/compare/v0.18.0...v0.19.0
[0.18.0]: https://github.com/xmanrui/dsh-im/compare/v0.17.1...v0.18.0
[0.17.1]: https://github.com/xmanrui/dsh-im/compare/v0.17.0...v0.17.1
[0.17.0]: https://github.com/xmanrui/dsh-im/compare/v0.16.0...v0.17.0
[0.16.0]: https://github.com/xmanrui/dsh-im/compare/v0.15.0...v0.16.0
[0.15.0]: https://github.com/xmanrui/dsh-im/compare/v0.14.0...v0.15.0
[0.14.0]: https://github.com/xmanrui/dsh-im/compare/v0.13.0...v0.14.0
[0.13.0]: https://github.com/xmanrui/dsh-im/compare/v0.12.0...v0.13.0
[0.12.0]: https://github.com/xmanrui/dsh-im/compare/v0.11.0...v0.12.0
[0.11.0]: https://github.com/xmanrui/dsh-im/releases/tag/v0.11.0
