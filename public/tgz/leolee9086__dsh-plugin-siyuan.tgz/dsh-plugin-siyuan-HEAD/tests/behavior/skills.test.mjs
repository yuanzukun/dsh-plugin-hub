import test from 'node:test';
import assert from 'node:assert/strict';
import { SiYuanSkills, frontmatter, stripFrontmatter, PROVIDER } from '../../lib/skills.js';

/** 假数据构造：只提供端口要求的形状，不模拟 DSH 上下文。 */
function skills(documents, body) {
  const source = {
    kernel: () => 'local',
    documents: async () => documents,
    body: async () => body,
  };
  return new SiYuanSkills(source);
}

const document = (id, text) => ({ id, title: 'SKILL', frontmatter: text });
const body = (markdown, forward = [], backward = [], hpath = '/n/skills/demo/SKILL') => ({ markdown, hpath, forward, backward });

test('frontmatter 解析单行键值与引号', () => {
  const parsed = frontmatter('name: demo-skill\ndescription: "带冒号: 的描述"\nwhenToUse: 当用户写插件时');
  assert.equal(parsed.name, 'demo-skill');
  assert.equal(parsed.description, '带冒号: 的描述');
  assert.equal(parsed.whenToUse, '当用户写插件时');
});

test('frontmatter 支持缩进续行，遇到块标量和无主行直接报错', () => {
  assert.equal(frontmatter('description: 第一段\n  第二段').description, '第一段 第二段');
  assert.throws(() => frontmatter('description: |'), /块标量/);
  assert.throws(() => frontmatter('没有键的一行'), /无法解析/);
});

test('stripFrontmatter 只在首个代码块确实是 frontmatter 时剪掉', () => {
  assert.equal(stripFrontmatter('```yaml\nname: demo\ndescription: d\n```\n\n正文'), '正文');
  assert.equal(stripFrontmatter('```js\nconsole.log(1)\n```\n正文'), '```js\nconsole.log(1)\n```\n正文');
  assert.equal(stripFrontmatter('正文'), '正文');
});

test('list 只收名字合法且描述非空的文档', async () => {
  const provider = skills([
    document('20261030143115-aaaaaaa', 'name: good-skill\ndescription: 可用'),
    document('20261030143115-bbbbbbb', 'name: Bad Name\ndescription: 名字不合法'),
    document('20261030143115-ccccccc', 'name: no-description'),
    document('20261030143115-ddddddd', '这不是 frontmatter'),
  ], body(''));
  const candidates = await provider.list({});
  assert.equal(candidates.length, 1);
  assert.equal(candidates[0].name, 'good-skill');
  assert.equal(candidates[0].provider, PROVIDER);
  assert.equal(candidates[0].rank, 0);
  assert.deepEqual(candidates[0].locator, { kernelId: 'local', docId: '20261030143115-aaaaaaa' });
});

test('get 剪掉 frontmatter 并补上块级链接清单', async () => {
  const provider = skills([], body('```yaml\nname: good-skill\ndescription: 可用\n```\n\n# 正文\n看 规程/自查.spec.md',
    [{ id: '20261030143115-eeeeeee', title: '被引用的段落', hpath: '/n/另一篇' }],
    [{ id: '20261030143115-fffffff', title: '引用本文的文档', hpath: '/n/引用方' }]));
  const candidate = { name: 'good-skill', description: '可用', invocation: { modelInvocable: true, userInvocable: true },
    source: 'custom', provider: PROVIDER, rank: 0, locator: { kernelId: 'local', docId: '20261030143115-aaaaaaa' } };
  const loaded = await provider.get(candidate, {});
  assert.ok(loaded.content.startsWith('# 正文'));
  assert.ok(!loaded.content.includes('name: good-skill'));
  // 两个方向都要在，且保留块 ID 与所在文档——不归并到文档级。
  assert.ok(loaded.content.includes('正向链接'));
  assert.ok(loaded.content.includes('被引用的段落'));
  assert.ok(loaded.content.includes('/n/另一篇'));
  assert.ok(loaded.content.includes('20261030143115-eeeeeee'));
  assert.ok(loaded.content.includes('反向链接'));
  assert.ok(loaded.content.includes('引用本文的文档'));
  assert.ok(loaded.content.includes('20261030143115-fffffff'));
  assert.equal(loaded.resourceBase.kind, 'opaque');
  // 读到技能就该知道改哪：主文档 ID + 不要改文件系统，且不点名具体工具。
  assert.ok(loaded.resourceBase.description.includes('20261030143115-aaaaaaa'));
  assert.ok(loaded.resourceBase.description.includes('不要去文件系统'));
  assert.ok(!/siyuan_\w+/.test(loaded.resourceBase.description));
});

test('observe 只在技能集可能变化时返回 true', async () => {
  const provider = skills([document('20261030143115-aaaaaaa', 'name: good-skill\ndescription: 可用')], body(''));
  await provider.list({});
  // 没有可靠范围的事务按全量处理
  assert.equal(provider.observe({ kernelId: 'local', kind: 'change', operations: [] }), true);
  // 命中已知技能文档
  assert.equal(provider.observe({ kernelId: 'local', kind: 'change', roots: ['20261030143115-aaaaaaa'], operations: [] }), true);
  // 不认识的文档里出现标签文本：刚被打上技能标签
  assert.equal(provider.observe({ kernelId: 'local', kind: 'change', roots: ['20261030143115-fffffff'],
    operations: [{ action: 'updateAttrs', data: { new: { tags: 'agent-skill' } } }] }), true);
  // 无关编辑
  assert.equal(provider.observe({ kernelId: 'local', kind: 'change', roots: ['20261030143115-fffffff'],
    operations: [{ action: 'update', data: '普通文本' }] }), false);
  // 非变更事件
  assert.equal(provider.observe({ kernelId: 'local', kind: 'ready' }), false);
});
