/** 这一组业务工具共享完整思源连接；数据原文在参数整理时保持不变。 */
import type { Context } from "@deepseek-ai/cordis";
import type {} from "@deepseek-ai/dsh-tools";
import type {} from "@deepseek-ai/dsh-storage-domain";
import type {} from "@deepseek-ai/dsh-credentials";
import type {} from "@deepseek-ai/dsh-user-approval";
import type {} from "@deepseek-ai/dsh-sandbox-policy";
import type {} from "@deepseek-ai/dsh-host-webserver";
import type {} from "@deepseek-ai/dsh-client-connection";
import type {} from "@deepseek-ai/dsh-session";
import type {} from "@deepseek-ai/dsh-session-persistence";
import type { ReminderService } from "dsh-context-care/reminders";
import { callKernel } from "./api.js";
import { rebec } from "./rebec.js";
import { readSessionParts } from "./session-log.js";
import type { SessionParts } from "./session-import.js";
import { SiYuanConnection } from "./connection.js";
import { rpcTool } from "./rpc-tool.js";
import { KernelManager, managedTools, DOMAIN_SPEC } from "./manager.js";
import { createRoute, ROUTE } from "./route.js";
import { EndpointPolicy } from "./policy.js";
import { ReminderSources } from "./rules.js";
import { SiYuanSkills } from "./skills.js";
import { toolDef, requiredText as text, requiredId as id, optionalText, contentType, type ToolArgs } from "./tool.js";
import { docImportTool } from "./doc-import.js";

export const name = "dsh-plugin-siyuan";
export const inject = ["tools", "storageDomain", "credentials", "sessions", "sessionPersistence"];
export const SERVICE = "siyuan";

// Only plugin-owned services augment Cordis; platform services come from their real packages.
declare module "@deepseek-ai/cordis" {
  interface Context {
    siyuan: Pick<KernelManager, "invoke">;
    reminderRules: ReminderService;
    toolGateway: Pick<Parameters<KernelManager["attachGateway"]>[0], "registerGroup">;
  }
}

const string = { type: "string" };
const blockId = { type: "string", pattern: "^\\d{14}-[0-9a-z]{7}$" };
const dataType = { type: "string", enum: ["markdown", "dom"] };
function parameters(properties: Record<string, unknown>, required = ["action"]) {
  return { type: "object", properties, required, additionalProperties: false };
}
function blockIds(data: unknown): string[] {
  if (!Array.isArray(data)) throw new Error("内核事务响应应为数组");
  return data.flatMap(tx => {
    if (!Array.isArray(tx.doOperations)) throw new Error("内核事务缺少 doOperations");
    return tx.doOperations.flatMap((op: { id?: string }) => op.id ? [op.id] : []);
  });
}

/** 内核一次 insert 操作可能包含多个块，操作 ID 的数量不等于写入块数。 */
function blockResult(data: unknown) {
  return { blockIds: blockIds(data), blockIdScope: "transaction-operations",
    note: "blockIds 是内核返回的事务操作 ID。一次操作可写入多个块，返回 ID 不代表全部生成块清单。" };
}

export function createTools(connection: SiYuanConnection) {
  const kernel = (path: string, payload: ToolArgs, signal?: AbortSignal) => callKernel(connection, path, payload, signal);
  return [
    toolDef("siyuan_query", "读取思源：notebooks 列笔记本；docs 按 notebook 列文档（默认最多64条，可用 limit/offset 分页）；search 全文搜索；sql 查询 SQL；read 读块 Kramdown；children 列子块。索引更新可能晚于写入成功。", parameters({
      action: { type: "string", enum: ["notebooks", "docs", "search", "sql", "read", "children"] },
      notebook: blockId, query: string, stmt: string, id: blockId,
      page: { type: "integer", minimum: 1 }, pageSize: { type: "integer", minimum: 1, maximum: 100 },
      limit: { type: "integer", minimum: 1, maximum: 1000 }, offset: { type: "integer", minimum: 0 },
    }), async (args, signal) => {
      switch (args.action) {
        case "notebooks": return kernel("/api/notebook/lsNotebooks", {}, signal);
        case "docs": {
          const notebook = id(args, "notebook");
          const stmt = `SELECT id, content, hpath, created, updated FROM blocks WHERE type = 'd' AND box = '${notebook}' ORDER BY updated DESC LIMIT ${args.limit ?? 64} OFFSET ${args.offset ?? 0}`;
          return kernel("/api/query/sql", { stmt }, signal);
        }
        case "sql": return kernel("/api/query/sql", { stmt: text(args, "stmt") }, signal);
        case "read": return kernel("/api/block/getBlockKramdown", { id: id(args, "id") }, signal);
        case "children": return kernel("/api/block/getChildBlocks", { id: id(args, "id") }, signal);
        case "search": {
          const payload: ToolArgs = { query: text(args, "query") };
          for (const key of ["page", "pageSize", "notebook"]) if (args[key] !== undefined) payload[key] = args[key];
          return kernel("/api/search/fullTextSearchBlock", payload, signal);
        }
        default: throw new Error("未知查询 action");
      }
    }),
    toolDef("siyuan_create", "创建思源内容：doc 按 notebook/path 用 Markdown 建文档，重复路径不覆盖；block 在 nextID/previousID/parentID 锚点插块；append 往 parentID 追加子块。路径的 / 表示文档层级。返回文档 ID 或内核事务操作 ID；一次操作可写入多块，返回的 blockIds 不是全部生成块清单。", parameters({
      action: { type: "string", enum: ["doc", "block", "append"] },
      notebook: blockId, path: string, markdown: string, data: string, dataType,
      parentID: blockId, previousID: blockId, nextID: blockId,
    }), async (args, signal) => {
      if (args.action === "doc") {
        const path = text(args, "path");
        if (!path.startsWith("/")) throw new Error("path 必须以 / 开头");
        return { docId: await kernel("/api/filetree/createDocWithMd", {
          notebook: id(args, "notebook"), path, markdown: optionalText(args, "markdown") ?? "",
        }, signal) };
      }
      const payload: ToolArgs = { dataType: contentType(args), data: text(args, "data", true) };
      if (args.action === "append") {
        payload.parentID = id(args, "parentID");
        return blockResult(await kernel("/api/block/appendBlock", payload, signal));
      }
      for (const key of ["nextID", "previousID", "parentID"]) if (args[key] !== undefined) payload[key] = id(args, key);
      if (!["nextID", "previousID", "parentID"].some(key => key in payload)) throw new Error("block 需要至少一个锚点 ID");
      return blockResult(await kernel("/api/block/insertBlock", payload, signal));
    }),
    toolDef("siyuan_update", "修改思源：block 整块替换内容，先读出需要保留的内容；rename_doc 修改文档标题。支持 markdown/dom 和更新时的 lockType。", parameters({
      action: { type: "string", enum: ["block", "rename_doc"] }, id: blockId, data: string, dataType,
      lockType: { type: "boolean" }, title: string,
    }, ["action", "id"]), async (args, signal) => {
      const target = id(args, "id");
      if (args.action === "rename_doc") {
        const title = text(args, "title");
        await kernel("/api/filetree/renameDocByID", { id: target, title }, signal);
        return { id: target, title };
      }
      const payload: ToolArgs = { id: target, dataType: contentType(args), data: text(args, "data", true) };
      if (args.lockType !== undefined) payload.lockType = args.lockType;
      return blockResult(await kernel("/api/block/updateBlock", payload, signal));
    }),
    toolDef("siyuan_delete", "删除思源：block 删除指定块；doc 按 ID 删除文档及子块。操作影响真实存储，调用前核对 ID。", parameters({
      action: { type: "string", enum: ["block", "doc"] }, id: blockId,
    }, ["action", "id"]), async (args, signal) => {
      const target = id(args, "id");
      if (args.action === "doc") {
        await kernel("/api/filetree/removeDocByID", { id: target }, signal);
        return { deletedDoc: target };
      }
      return { deleted: blockIds(await kernel("/api/block/deleteBlock", { id: target }, signal)) };
    }),
    docImportTool(kernel),
    rpcTool(connection),
  ];
}

export async function apply(ctx: Context, rawConfig: unknown) {
  if (ctx.get(SERVICE) !== undefined) throw new Error("siyuan 服务已存在");
  const reminderOptions = ReminderSources.options(rawConfig);
  const domain = await ctx.storageDomain.open(DOMAIN_SPEC);
  const manager = new KernelManager(domain, ctx.credentials, async (connection, toolName, args, exec) => {
    const tool = createTools(connection).find(item => item.name === toolName);
    if (!tool) throw new Error("未知思源工具");
    return tool.execute(args, exec);
  }, async (exec, reason, decision) => {
    if (exec.signal?.aborted) return "cancelled";
    if (!exec.agent) return "unavailable";
    const mode = ctx.get("sandboxPolicy")?.resolve({ session: exec.agent.session }).mode;
    const route = EndpointPolicy.approvalRoute(decision, mode);
    if (route !== "request") return route;
    const approval = ctx.get("approval");
    if (!approval) return "unavailable";
    const policy = approval.overrideOf(exec.agent.session) ?? approval.config.policy ?? "ask";
    const outcome = await approval.request({ agent: exec.agent, toolName: exec.name ?? "siyuan_rpc", callId: exec.callId,
      reason, displayReason: { en: reason, "zh-CN": reason }, signal: exec.signal });
    // 决定仍由宿主作出；补充 never 的原因，避免把无弹窗的策略拒绝称为人工拒绝。
    return outcome === "rejected" && policy === "never" ? "policy-never" : outcome;
  });
  try { await manager.initialize(rawConfig); }
  catch (error) {
    const cause = manager.error(error);
    try { await domain.close(); } catch { /* 初始化原因优先于清理失败。 */ }
    throw new Error("思源配置或凭据初始化失败，请检查本机设置", { cause });
  }
  // 注册公共服务时只投影受控操作，不发布 config、HTTP、SDK client 或裸 socket。
  ctx.provide(SERVICE, Object.freeze({ invoke: manager.invoke.bind(manager) }));
  ctx.effect(() => () => manager.close(), `${name}: manager`);
  const template = new SiYuanConnection({});
  try {
    for (const tool of managedTools(manager, createTools(template))) {
      ctx.effect(() => ctx.tools.register(tool), `${name}: ${tool.name}`);
    }
  } finally { await template.dispose(); }
  ctx.inject(["reminderRules"], scope => {
    scope.effect(() => {
      const sources = ReminderSources.attach(scope.reminderRules, reminderOptions,
        manager.readReminderBlocks.bind(manager), message => ctx.logger.warn(message),
        () => manager.reminderKernels(), (kernelId, sessionId) => manager.acceptsReminder(kernelId, sessionId),
        manager.watchKernels);
      return () => sources.dispose();
    }, `${name}: reminder sources`);
  });
  // 技能来源：带 agent-skill 标签的思源文档并进技能注册表，模型用现有的 skill 工具加载。
  // 推送只在技能集可能变化时让注册表重新发现，不做定时查询。
  ctx.inject(["skills"], scope => {
    scope.effect(() => {
      const skills = new SiYuanSkills({
        kernel: () => manager.skillKernel(),
        documents: (kernelId, signal) => manager.listSkills(kernelId, signal),
        body: (kernelId, docId, signal) => manager.readSkill(kernelId, docId, signal),
      });
      return scope.skills.registerProvider(control => {
        const stop = manager.watchKernels(event => { if (skills.observe(event)) control.invalidate(); });
        control.signal.addEventListener("abort", () => { void stop(); }, { once: true });
        return skills;
      });
    }, `${name}: skills`);
  });
  // 子作用域等待可选网关；网关卸载时同时撤回扩展工具，重新挂载时按保存的选择恢复。
  ctx.inject(["toolGateway"], scope => {
    scope.effect(() => manager.attachGateway({
      registerGroup: spec => scope.toolGateway.registerGroup(spec),
      registerTool: tool => scope.tools.register(tool),
    }), `${name}: gateway publication`);
  });
  // 导入前先 flush 活会话，再按持久化读句柄取头和事件；日志格式与渲染都交给 dsh-session-sy。
  const sessionImport = {
    readSession: (sessionId: string, signal?: AbortSignal) =>
      readSessionParts({ sessions: ctx.sessions, persistence: ctx.sessionPersistence }, sessionId, signal),
    render: (parts: SessionParts, spin: boolean, assets: string | undefined) => rebec().render(parts, spin, assets),
  };
  // 与 gateway 同样延迟挂载界面路由，headless 模式不依赖 webServer。
  ctx.inject(["webServer", "connection"], scope => {
    scope.effect(() => scope.webServer.register({ kind: "exact", path: ROUTE,
      handler: createRoute(request => {
        const connection = scope.get("connection");
        if (!connection || typeof connection.requestRejection !== "function") return 503;
        return connection.requestRejection(request);
      }, manager, sessionImport) }), `${name}: management`);
  });
}
