/**
 * 网关持久状态：聊天→DSH 会话映射、iLink 轮询游标、消息去重表、发件箱。
 *
 * 目标是重启后无损续跑：未发完的回复从 outbox 断点继续，聊天会话 resume，
 * 已处理过的消息 id 不再重复消费。
 */

import { join } from 'node:path'
import { readPrivateJson, writePrivateJson, pathExists, dataDir } from './store.js'
import type { ILinkState } from './ilink.js'

const STATE_VERSION = 1

/** 单聊/群聊的待发送内容（分块文本 + 待发文件），带断点游标。 */
export interface OutboxItem {
  chunks: string[]
  files: string[]
  next: number
  nextFile: number
}

/** 单条投递记录（有界审计日志，每键最多 20 条，新的在前）。 */
export interface DeliveryLogEntry {
  at: string
  outcome: 'delivered' | 'deferred' | 'skipped' | 'failed'
  /** 失败/跳过原因（截断到 ~200 字符）。 */
  detail?: string
  /** 本轮涉及的文本块数。 */
  chunks: number
}

/** 每键保留的最大条数。 */
export const DELIVERY_LOG_LIMIT = 20

/** 不可变追加：返回新记录，原记录不动；超过上限从尾部淘汰。 */
export function pushDeliveryEntry(log: Record<string, DeliveryLogEntry[]>, key: string, entry: DeliveryLogEntry): Record<string, DeliveryLogEntry[]> {
  const updated = [entry, ...(log[key] ?? [])].slice(0, DELIVERY_LOG_LIMIT)
  return { ...log, [key]: updated }
}

export interface GatewayState {
  version: 1
  /** chatId → DSH 会话 id。 */
  chats: Record<string, string>
  /** 最近处理过的 iLink 消息 id（有界）。 */
  seenMessageIds: string[]
  protocol: ILinkState
  outbox: Record<string, OutboxItem>
  /** 投递审计日志：chatId（skipped 用 session id）→ 最近 20 条，新的在前。 */
  deliveryLog: Record<string, DeliveryLogEntry[]>
  /** 运行时覆盖的工作目录（空串或缺失时回退到 config.workspace）。 */
  workspace?: string
  /** 最近一次收到微信消息的时间（ISO）：凭据 24 小时有效期从最近收信重新计起。 */
  credentialActivityAt?: string
  /** 到期预警开关的运行时覆盖（侧边栏开关；undefined 表示默认开启）。 */
  expiryWarnEnabled?: boolean
  /** 凭据到期预警记录：已对哪个锚点时间发过预警（换凭据/续期后自动重置）。 */
  credentialWarn?: { anchorAt: string; warnedAt: string }
}

export function defaultStatePath(): string {
  return join(dataDir(), 'state.json')
}

function emptyState(): GatewayState {
  return {
    version: STATE_VERSION,
    chats: {},
    seenMessageIds: [],
    protocol: { updatesBuffer: '', contextTokens: {} },
    outbox: {},
    deliveryLog: {},
    workspace: undefined,
    credentialActivityAt: undefined,
    expiryWarnEnabled: undefined,
    credentialWarn: undefined,
  }
}

function asRecord(value: unknown, field: string): Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error(`状态文件 ${field} 必须是对象`)
  return value as Record<string, unknown>
}

function stringRecord(value: unknown, field: string): Record<string, string> {
  const output: Record<string, string> = {}
  for (const [key, item] of Object.entries(asRecord(value, field))) {
    if (typeof item !== 'string') throw new Error(`状态文件 ${field}.${key} 必须是字符串`)
    output[key] = item
  }
  return output
}

const DELIVERY_OUTCOMES = new Set(['delivered', 'deferred', 'skipped', 'failed'])

function deliveryLogFrom(value: unknown): Record<string, DeliveryLogEntry[]> {
  if (value === undefined) return {}
  const source = asRecord(value, 'deliveryLog')
  const log: Record<string, DeliveryLogEntry[]> = {}
  for (const [key, entries] of Object.entries(source)) {
    if (!Array.isArray(entries)) throw new Error(`状态文件 deliveryLog.${key} 必须是数组`)
    log[key] = entries.map((raw, index) => {
      if (raw === null || typeof raw !== 'object' || Array.isArray(raw)) throw new Error(`状态文件 deliveryLog.${key}[${index}] 必须是对象`)
      const entry = raw as Record<string, unknown>
      if (typeof entry.at !== 'string') throw new Error(`状态文件 deliveryLog.${key}[${index}].at 必须是字符串`)
      if (typeof entry.outcome !== 'string' || !DELIVERY_OUTCOMES.has(entry.outcome)) throw new Error(`状态文件 deliveryLog.${key}[${index}].outcome 无效`)
      if (typeof entry.chunks !== 'number' || !Number.isInteger(entry.chunks) || entry.chunks < 0) throw new Error(`状态文件 deliveryLog.${key}[${index}].chunks 无效`)
      if (entry.detail !== undefined && typeof entry.detail !== 'string') throw new Error(`状态文件 deliveryLog.${key}[${index}].detail 必须是字符串`)
      return { at: entry.at, outcome: entry.outcome as DeliveryLogEntry['outcome'], chunks: entry.chunks, ...(entry.detail === undefined ? {} : { detail: entry.detail }) }
    }).slice(0, DELIVERY_LOG_LIMIT)
  }
  return log
}

/** 加载并严格校验状态文件；不存在时返回空状态。 */
export async function loadGatewayState(path: string): Promise<GatewayState> {
  if (!await pathExists(path)) return emptyState()
  const value = await readPrivateJson<Record<string, unknown>>(path)
  if (value.version !== STATE_VERSION) throw new Error(`不支持的状态文件版本: ${String(value.version)}`)
  if (!Array.isArray(value.seenMessageIds) || value.seenMessageIds.some(item => typeof item !== 'string')) {
    throw new Error('状态文件 seenMessageIds 必须是字符串数组')
  }
  const protocolSource = asRecord(value.protocol, 'protocol')
  if (typeof protocolSource.updatesBuffer !== 'string') throw new Error('状态文件 protocol.updatesBuffer 必须是字符串')
  const contextTokens = protocolSource.contextTokens === undefined ? {} : stringRecord(protocolSource.contextTokens, 'protocol.contextTokens')
  const outboxSource = value.outbox === undefined ? {} : asRecord(value.outbox, 'outbox')
  const outbox: Record<string, OutboxItem> = {}
  for (const [chatId, item] of Object.entries(outboxSource)) {
    const record = asRecord(item, `outbox.${chatId}`)
    const chunks = record.chunks
    if (!Array.isArray(chunks) || chunks.some(chunk => typeof chunk !== 'string')) throw new Error(`状态文件 outbox.${chatId}.chunks 必须是字符串数组`)
    const files = record.files === undefined ? [] : record.files
    if (!Array.isArray(files) || files.some(file => typeof file !== 'string')) throw new Error(`状态文件 outbox.${chatId}.files 必须是字符串数组`)
    const next = typeof record.next === 'number' ? record.next : 0
    const nextFile = typeof record.nextFile === 'number' ? record.nextFile : 0
    if (!Number.isInteger(next) || next < 0 || next > chunks.length) throw new Error(`状态文件 outbox.${chatId}.next 无效`)
    if (!Number.isInteger(nextFile) || nextFile < 0 || nextFile > files.length) throw new Error(`状态文件 outbox.${chatId}.nextFile 无效`)
    outbox[chatId] = { chunks: [...chunks], files: [...files], next, nextFile }
  }
  let credentialWarn: GatewayState['credentialWarn']
  if (value.credentialWarn !== undefined) {
    const record = asRecord(value.credentialWarn, 'credentialWarn')
    if (typeof record.anchorAt !== 'string' || typeof record.warnedAt !== 'string') throw new Error('状态文件 credentialWarn.anchorAt/warnedAt 必须是字符串')
    credentialWarn = { anchorAt: record.anchorAt, warnedAt: record.warnedAt }
  }
  return {
    version: STATE_VERSION,
    chats: stringRecord(value.chats, 'chats'),
    seenMessageIds: [...value.seenMessageIds],
    protocol: { updatesBuffer: protocolSource.updatesBuffer, contextTokens },
    outbox,
    deliveryLog: deliveryLogFrom(value.deliveryLog),
    workspace: typeof value.workspace === 'string' ? value.workspace : undefined,
    credentialActivityAt: typeof value.credentialActivityAt === 'string' ? value.credentialActivityAt : undefined,
    expiryWarnEnabled: typeof value.expiryWarnEnabled === 'boolean' ? value.expiryWarnEnabled : undefined,
    credentialWarn,
  }
}

/** 串行化写盘：后一次 save 覆盖前一次的快照，避免交错写坏文件。 */
export class GatewayStateStore {
  readonly path: string
  readonly state: GatewayState
  #pending: Promise<void> = Promise.resolve()

  constructor(path: string, state: GatewayState) {
    this.path = path
    this.state = state
  }

  save(): Promise<void> {
    // 先吞掉前一次的失败再排队写盘：写盘错误只属于当次调用，不毒化后续 save。
    this.#pending = this.#pending.catch(() => undefined).then(async () => {
      await writePrivateJson(this.path, structuredClone(this.state))
    })
    return this.#pending
  }
}
