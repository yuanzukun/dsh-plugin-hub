/**
 * Wire helpers for the /restty JSON API: bounded body reading, response
 * writing, and the shared error envelope. Every API method returns
 * `{ok: true, value}` on success and `{ok: false, error: {code, message}}`
 * (HTTP 4xx/5xx matching the code) on failure.
 */
import type { ResttyHttpRequest, ResttyHttpResponse } from './context-types.ts'

/** Machine-readable error codes of the restty API. */
export type ResttyErrorCode =
  | 'bad-request'
  | 'not-found'
  | 'forbidden'
  | 'method-error'
  | 'pty-error'
  | 'pty-deps-missing'
  | 'search-deps-missing'
  | 'sqlite-deps-missing'
  | 'calendar-no-profile'
  | 'internal'

/** One API failure with its wire code and HTTP status. */
export class ResttyError extends Error {
  constructor(
    readonly code: ResttyErrorCode,
    message: string,
    readonly status = 400,
  ) {
    super(message)
  }
}

/** Body size bound of one JSON request (defense against unbounded reads). */
export const MAX_BODY_BYTES = 1 << 20

/** Success envelope of one API method. */
export interface ResttyOk<T> { ok: true; value: T }

/** Failure envelope of one API method. */
export interface ResttyErr { ok: false; error: { code: ResttyErrorCode; message: string } }

/**
 * Read and parse the JSON request body (bounded; malformed → bad-request).
 *
 * @param maxBytes - per-request bound. Defaults to {@link MAX_BODY_BYTES};
 * the extension-upload method raises it, since a base64 archive legitimately
 * exceeds the limit every other method needs. Passing the bound per call
 * keeps the default tight instead of widening it for the whole route.
 */
export async function readJsonBody(req: ResttyHttpRequest, maxBytes: number = MAX_BODY_BYTES): Promise<unknown> {
  const chunks: Buffer[] = []
  let total = 0
  for await (const chunk of req) {
    // The structural request yields string | Uint8Array; Buffer.from accepts
    // both (and the real runtime chunks are node Buffers anyway).
    const buffer = Buffer.from(chunk)
    total += buffer.length
    if (total > maxBytes) {
      throw new ResttyError('bad-request', 'request body too large')
    }
    chunks.push(buffer)
  }
  const text = Buffer.concat(chunks).toString('utf8')
  if (text.trim() === '') return {}
  try {
    return JSON.parse(text) as unknown
  } catch {
    throw new ResttyError('bad-request', 'request body is not valid JSON')
  }
}

/** Write a JSON response with the given status. */
export function writeJson(res: ResttyHttpResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
  res.end(payload)
}

/** Write the success envelope. */
export function writeOk(res: ResttyHttpResponse, value: unknown): void {
  writeJson(res, 200, { ok: true, value })
}

/** Write the failure envelope for any thrown value (unknown → internal 500). */
export function writeError(res: ResttyHttpResponse, error: unknown): void {
  if (error instanceof ResttyError) {
    writeJson(res, error.status, { ok: false, error: { code: error.code, message: error.message } })
    return
  }
  const message = error instanceof Error ? error.message : String(error)
  writeJson(res, 500, { ok: false, error: { code: 'internal', message } })
}

/** Narrow an unknown payload value to a string, else throw bad-request. */
export function requireString(payload: unknown, key: string): string {
  const record = payload as Record<string, unknown> | null
  const value = record?.[key]
  if (typeof value !== 'string' || value === '') {
    throw new ResttyError('bad-request', `missing or invalid "${key}"`)
  }
  return value
}
