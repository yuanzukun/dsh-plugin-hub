/**
 * Pure URL policy for the built-in browser tab: normalize user input into
 * an http(s) URL, and refuse destinations that would be dangerous to embed
 * in the sidebar iframe. Kept dependency-free so it is unit-testable.
 *
 * The iframe sandbox (opaque origin, no allow-same-origin / top-navigation)
 * is the primary security boundary; this module is the address-bar gate on
 * top of it: only http/https may be navigated, and loopback addresses are
 * refused so a browsed page cannot probe local services by user action.
 * The GUI's OWN origin is explicitly ALLOWED — the user may open the GUI
 * itself in the sidebar (debugging, mirroring); the sandbox still renders
 * it in an opaque origin with no same-origin privileges, exactly like any
 * other site.
 *
 * Adapted from dsh-better-sidebar (BSD-3-Clause).
 */
/** Why a navigation attempt was refused. */
export type BrowserBlockReason = 'scheme' | 'loopback';
/** Result of normalizing one address-bar input. */
export type BrowserNavigateResult = {
    kind: 'ok';
    url: string;
} | {
    kind: 'blocked';
    reason: BrowserBlockReason;
} | {
    kind: 'invalid';
};
/** One browser.probe wire result (host fetch of the target's headers). */
export interface BrowserProbeResult {
    reachable: boolean;
    /** The final (post-redirect) URL; present when reachable. */
    url?: string;
    status?: number;
    xFrameOptions?: string;
    /** The CSP frame-ancestors source list; present when the directive exists. */
    frameAncestors?: string[];
}
/** Embeddability verdict of one probe. */
export type Embeddability = 'embeddable' | 'blocked' | 'unknown';
/**
 * Decide whether a site can render inside the sidebar iframe. The signals
 * are exactly the ones the BROWSER enforces when it refuses an iframe load:
 * X-Frame-Options DENY/SAMEORIGIN, or a frame-ancestors directive that does
 * not allow `*` ('self' here means the SITE's own origin — never ours, so
 * it also blocks the sidebar). A site we could not reach yields 'unknown'
 * and the plain iframe stays.
 */
export declare function embeddabilityOf(probe: BrowserProbeResult): Embeddability;
/** A loopback hostname (localhost, IPv6 ::1, 127.0.0.0/8, 0.0.0.0). */
export declare function isLoopbackHostname(hostname: string): boolean;
/**
 * Normalize one address-bar input against the navigation policy.
 * @param input - raw user text.
 * @param selfOrigin - the GUI's own origin (window.location.origin). The GUI
 * itself may be browsed in the sidebar (the sandbox keeps it opaque), so it
 * is let through BEFORE the loopback check — its host is normally loopback.
 */
export declare function normalizeBrowserUrl(input: string, selfOrigin: string): BrowserNavigateResult;
