# 3-minute whiteboard — dsh-outcome-loop

Goal: leave ADR binders closed.

## 0:00-0:40 Problem
Agents say "done." That is not evidence. I want a user-owned local ledger that records what we meant to do, what mechanical checks say, and what the user decided — without extra model spend by default.

## 0:40-1:40 Data / control
- In: session events -> append-only sidecar facts.
- Contract: /outcome new + criteria (command / test / file / ...).
- Verify: default passive replay. Active only if deploy+contract policy unlocks allowlisted argv checks (never shell-string; timeout; output cap).
- Out: mechanical axis x user disposition; export = preview digest then approve then JSONL.

## 1:40-2:20 Non-negotiables
- unknown never becomes pass.
- User accept does not erase mechanical fail.
- Repo files never grant enterprise policy (deploy config only).
- Extra model calls: zero by default.

## 2:20-3:00 Proof I'm not cosplaying Datadog
- Version is beta; host DSH is preview.
- CI: typecheck/lint/tests/coverage/pack on Node 22.19/24 with pinned actions.
- Real-host smoke on rc.8 documented (install -> /outcome -> restart read -> remove).
- Limits disclosed: no multi-process writer claim; OS network jail is the host's job.

If asked for five axes: defer — two axes get 80% of the product story.
