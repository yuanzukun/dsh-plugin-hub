import assert from 'node:assert/strict'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'
import { Context } from '@deepseek-ai/cordis'
import { TaskboardAutomationCoordinator } from '../src/automation/index.js'
import { hostAutomationDefaults, TaskboardService } from '../src/service/index.js'

const config = {
  databasePath: ':memory:',
  attachmentRoot: '.dsh/test-attachments',
}

test('service exposes one authoritative snapshot and loopback human intents', () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  try {
    const projectResult = service.dispatchHumanRpc('project.create', {
      request: { key: 'DSH', name: 'Harness' },
    }, { kind: 'human', actorId: 'test-human' })
    assert.equal(projectResult.ok, true)
    if (!projectResult.ok) return
    const project = projectResult.value as { id: string }

    const taskResult = service.dispatchHumanRpc('task.create', {
      request: { projectId: project.id, title: 'Native page', creator: 'test-human' },
    }, { kind: 'human', actorId: 'test-human' })
    assert.equal(taskResult.ok, true)

    const snapshot = service.snapshot(project.id as never)
    assert.equal(snapshot.schemaVersion, 1)
    assert.equal(snapshot.projects.length, 1)
    assert.equal(snapshot.tasks[0]?.identifier, 'DSH-1')
    assert.equal(snapshot.globalRevision, 2)
    assert.deepEqual(snapshot.automationRuns, [])
    assert.deepEqual(snapshot.automationDefaults, {
      agentPreset: 'standard',
      minIntervalMs: 30_000,
    })
  } finally {
    service.provider.close()
  }
})

test('snapshot prefills automation defaults from the Host model selection', () => {
  const hostModel = {
    currentSelection: () => ({
      provider: 'deepseek-official',
      model: 'deepseek-v4-flash',
      reasoningEffort: 'low',
    }),
  }
  const hostCtx = new Context()
  hostCtx.provide('agentDefaultModel', hostModel as never)
  const hostService = new TaskboardService(hostCtx, config)
  const overrideCtx = new Context()
  overrideCtx.provide('agentDefaultModel', hostModel as never)
  const overrideService = new TaskboardService(overrideCtx, {
    ...config,
    defaultModelRoute: 'acme-gateway:acme-large',
  })
  try {
    assert.deepEqual(hostAutomationDefaults(hostCtx), {
      modelRoute: 'deepseek-official:deepseek-v4-flash',
      reasoning: 'low',
    })
    assert.deepEqual(hostService.snapshot().automationDefaults, {
      agentPreset: 'standard',
      modelRoute: 'deepseek-official:deepseek-v4-flash',
      reasoning: 'low',
      minIntervalMs: 30_000,
    })
    assert.deepEqual(overrideService.snapshot().automationDefaults, {
      agentPreset: 'standard',
      modelRoute: 'acme-gateway:acme-large',
      reasoning: 'low',
      minIntervalMs: 30_000,
    })
  } finally {
    hostService.provider.close()
    overrideService.provider.close()
  }
})

test('service long-poll wakes only for committed revisions and times out boundedly', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  try {
    const initial = service.provider.globalRevision()
    const waiting = service.watchChanges(initial, 1_000)
    const secondClient = service.watchChanges(initial, 1_000)
    service.provider.createProject({ key: 'DSH', name: 'Harness' }, { kind: 'human', actorId: 'human' })
    assert.deepEqual(await waiting, { globalRevision: initial + 1, changed: true })
    assert.deepEqual(await secondClient, { globalRevision: initial + 1, changed: true })
    assert.deepEqual(await service.watchChanges(initial + 1, 5), {
      globalRevision: initial + 1,
      changed: false,
    })
    const project = service.provider.listProjects()[0]!
    const task = service.provider.createTask({ projectId: project.id, title: 'No rollback event', creator: 'human' }, { kind: 'human', actorId: 'human' })
    const afterTask = service.provider.globalRevision()
    const rollbackWait = service.watchChanges(afterTask, 5)
    assert.throws(
      () => service.provider.updateTask(task.id, task.version + 1, { title: 'Stale' }, { kind: 'human', actorId: 'human' }),
      /version is stale/,
    )
    assert.deepEqual(await rollbackWait, { globalRevision: afterTask, changed: false })

    const carried = await service.remoteMutate({
      endpoint: 'changes.watch',
      payloadJson: JSON.stringify({ afterRevision: initial, timeoutMs: 1_000 }),
    })
    assert.equal(carried.ok, true)
    assert.deepEqual(JSON.parse(carried.valueJson ?? 'null'), {
      globalRevision: afterTask,
      changed: true,
    })
  } finally {
    service.provider.close()
  }
})

test('service unload settles pending change watches before closing SQLite', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, { ...config, maxChangeWaiters: 1 })
  const revision = service.provider.globalRevision()
  const waiting = service.watchChanges(revision, 30_000)
  assert.throws(
    () => service.watchChanges(revision, 30_000),
    /too many concurrent Taskboard change watches/,
  )
  await ctx.fiber.dispose()
  assert.deepEqual(await waiting, { globalRevision: revision, changed: false })
})

test('human RPC updates and deletes comments through optimistic versions', () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  const human = { kind: 'human', actorId: 'human' } as const
  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness' }, human)
    let task = service.provider.createTask({ projectId: project.id, title: 'Notes', creator: 'human' }, human)
    const created = service.dispatchHumanRpc('task.comment', {
      taskId: task.id, expectedVersion: task.version, body: 'Draft',
    }, human)
    assert.equal(created.ok, true)
    if (!created.ok) return
    const comment = created.value as { id: string }
    task = service.provider.getTask(task.id)
    const updated = service.dispatchHumanRpc('comment.update', {
      taskId: task.id, expectedVersion: task.version, commentId: comment.id, body: 'Revised',
    }, human)
    assert.equal(updated.ok, true)
    task = service.provider.getTask(task.id)
    assert.equal(service.provider.getTaskDetail(task.id).comments[0]?.body, 'Revised')
    const deleted = service.dispatchHumanRpc('comment.delete', {
      taskId: task.id, expectedVersion: task.version, commentId: comment.id,
    }, human)
    assert.equal(deleted.ok, true)
    assert.equal(service.provider.getTaskDetail(task.id).comments.length, 0)
  } finally {
    service.provider.close()
  }
})

test('human lifecycle RPC can establish a fresh direct rework claim', () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  const human = { kind: 'human', actorId: 'human' } as const
  const agent = { kind: 'agent', actorId: 'agent-1', sessionId: 'session-1', agentId: 'agent-1' } as const
  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness' }, human)
    let task = service.provider.createTask({ projectId: project.id, title: 'Rework', creator: 'human', status: 'todo' }, human)
    task = service.provider.claim(task.id, {
      expectedVersion: task.version, sessionId: agent.sessionId, agentId: agent.agentId,
    }, agent).task
    task = service.provider.submitReview(task.id, task.version, 'verified', 'first pass', agent)
    const result = service.dispatchHumanRpc('task.return', {
      taskId: task.id,
      expectedVersion: task.version,
      target: 'in_progress',
      comment: 'Continue in the selected Session',
      freshClaim: { sessionId: 'session-2', agentId: 'agent-2' },
    }, human)
    assert.equal(result.ok, true)
    assert.equal(service.provider.getTask(task.id).status, 'in_progress')
    assert.equal(service.provider.getTaskDetail(task.id).activeClaim?.sessionId, 'session-2')
  } finally {
    service.provider.close()
  }
})

test('RPC returns stable domain codes without throwing transport failures', () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  try {
    const result = service.dispatchHumanRpc('task.accept', {
      taskId: 'missing', expectedVersion: 1,
    }, { kind: 'human', actorId: 'test-human' })
    assert.deepEqual(result, {
      ok: false,
      error: {
        code: 'internal',
        message: 'TASK_NOT_FOUND: task missing was not found',
        details: {},
      },
    })
  } finally {
    service.provider.close()
  }
})

test('task detail projects live Agent status and durable todo progress without changing SQLite authority', () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness' }, { kind: 'human', actorId: 'human' })
    let task = service.provider.createTask({ projectId: project.id, title: 'Live status', creator: 'human', status: 'todo' }, { kind: 'human', actorId: 'human' })
    task = service.provider.claim(task.id, { expectedVersion: task.version, sessionId: 'session-live', agentId: 'session-live' }, {
      kind: 'agent', actorId: 'session-live', sessionId: 'session-live', agentId: 'session-live',
    }).task
    ctx.provide('agents', {
      get: () => ({
        status: 'running',
        session: { events: [{ type: 'todo/write', data: { todos: [{ content: 'Run verification', status: 'in_progress' }] } }] },
      }),
    } as never)
    assert.deepEqual(service.taskDetail(task.id).sessionRuntime, [{
      sessionId: 'session-live', status: 'running', current: true,
      todos: [{ content: 'Run verification', status: 'in_progress' }],
    }])
  } finally {
    service.provider.close()
  }
})

test('0.2.1 task detail reads todo projections without touching removed Session.events', () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  try {
    const project = service.provider.createProject({ key: 'REV', name: 'Review' }, { kind: 'human', actorId: 'human' })
    let task = service.provider.createTask({ projectId: project.id, title: 'Projection', creator: 'human', status: 'todo' }, { kind: 'human', actorId: 'human' })
    task = service.provider.claim(task.id, { expectedVersion: task.version, sessionId: 'session-new', agentId: 'session-new' }, {
      kind: 'agent', actorId: 'session-new', sessionId: 'session-new', agentId: 'session-new',
    }).task
    const session = { get events(): never { throw new Error('Session.events is not supported') } }
    let live = true
    let reads = 0
    let todos: readonly { content: string; status: 'in_progress' }[] | null = [{ content: 'Keep real progress', status: 'in_progress' }]
    ctx.provide('agents', { get: () => live ? { status: 'running', session } : undefined } as never)
    ctx.provide('sessionProjections' as never, { snapshot: (value: unknown, keys: readonly string[]) => {
      assert.equal(value, session)
      assert.deepEqual(keys, ['todos'])
      reads++
      return { values: { todos } }
    } } as never)
    assert.deepEqual(service.taskDetail(task.id).sessionRuntime, [{ sessionId: 'session-new', status: 'running', current: true, todos }])
    todos = []
    assert.deepEqual(service.taskDetail(task.id).sessionRuntime?.[0]?.todos, [])
    todos = null
    assert.deepEqual(service.taskDetail(task.id).sessionRuntime?.[0]?.todos, [])
    live = false
    assert.deepEqual(service.taskDetail(task.id).sessionRuntime, [{ sessionId: 'session-new', status: 'offline', current: true, todos: [] }])
    assert.equal(reads, 3)
  } finally {
    service.provider.close()
  }
})

test('a live Session without an events array or todo projection does not poison task detail', () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  try {
    const project = service.provider.createProject({ key: 'REV', name: 'Review' }, { kind: 'human', actorId: 'human' })
    let task = service.provider.createTask({ projectId: project.id, title: 'No todo plugin', creator: 'human', status: 'todo' }, { kind: 'human', actorId: 'human' })
    task = service.provider.claim(task.id, { expectedVersion: task.version, sessionId: 'session-empty', agentId: 'session-empty' }, {
      kind: 'agent', actorId: 'session-empty', sessionId: 'session-empty', agentId: 'session-empty',
    }).task
    ctx.provide('agents', { get: () => ({ status: 'idle', session: {} }) } as never)
    assert.deepEqual(service.taskDetail(task.id).sessionRuntime, [{ sessionId: 'session-empty', status: 'idle', current: true, todos: [] }])
  } finally {
    service.provider.close()
  }
})

test('snapshot discovers installed Skill and MCP capabilities without claiming they are executable', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  try {
    ctx.provide('skills' as never, {
      snapshot: () => Promise.resolve({
        complete: true,
        skills: [{ name: 'manage-taskboard', description: 'Manage native tasks' }],
      }),
    } as never)
    ctx.provide('tools', {
      schemas: () => [
        { name: 'mcp__github__get_issue', description: 'Get issue' },
        { name: 'taskboard_get', description: 'Get task' },
      ],
    } as never)
    await Promise.resolve()
    await Promise.resolve()
    const snapshot = service.snapshot()
    assert.deepEqual(snapshot.workflowCapabilities, {
      skills: [{ name: 'manage-taskboard', description: 'Manage native tasks' }],
      mcpTools: [{ name: 'mcp__github__get_issue', description: 'Get issue' }],
      skillDiscoveryComplete: true,
    })
    assert.equal(snapshot.workflowCatalog.find(entry => entry.kind === 'skill')?.execution, 'design-only')
  } finally {
    service.provider.close()
  }
})

test('human RPC can move a task status from the board without a claim', () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  const human = { kind: 'human', actorId: 'human' } as const
  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness' }, human)
    const task = service.provider.createTask({ projectId: project.id, title: 'Board move', creator: 'human', status: 'todo' }, human)
    const result = service.dispatchHumanRpc('task.move', {
      taskId: task.id, expectedVersion: task.version, status: 'in_progress',
    }, human)
    assert.equal(result.ok, true)
    assert.equal(service.provider.getTask(task.id).status, 'in_progress')
  } finally {
    service.provider.close()
  }
})

test('loopback automation intent runs immediately while the generic Remote refuses it', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  const actor = { kind: 'human', actorId: 'human' } as const
  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness' }, actor)
    const task = service.provider.createTask({ projectId: project.id, title: 'Now', creator: 'human', status: 'todo' }, actor)
    let rule = service.provider.createAutomation(project.id, {
      intervalMs: 30_000, agentPreset: 'coding', concurrencyLimit: 1, quotaPolicy: 'ignore', autoPauseOnEmpty: false,
    }, actor)
    rule = service.provider.updateAutomation(rule.id, rule.version, { state: 'enabled' }, actor)
    const scheduledAt = Date.now() + 60_000
    rule = service.provider.recordAutomationDecision(rule.id, rule.version, {
      kind: 'empty', message: 'parked for later', at: Date.now(),
    }, scheduledAt)
    const started: string[] = []
    const coordinator = new TaskboardAutomationCoordinator(service, {
      start(activeRule, candidate) {
        const sessionId = `automation-${candidate.id}`
        service.provider.claim(candidate.id, {
          expectedVersion: candidate.version, sessionId, agentId: sessionId,
        }, { kind: 'automation', actorId: sessionId, automationId: activeRule.id, sessionId, agentId: sessionId })
        started.push(candidate.id)
        return Promise.resolve()
      },
    })
    service.bindAutomation(coordinator)
    const refusedRemote = await service.remoteMutate({
      endpoint: 'automation.run-now',
      payloadJson: JSON.stringify({ automationId: rule.id }),
    })
    assert.equal(refusedRemote.ok, false)
    assert.equal(refusedRemote.errorCode, 'loopback-required')
    await service.runAutomationNow(rule.id)
    const after = service.provider.getAutomation(rule.id)
    assert.deepEqual(started, [task.id])
    assert.equal(after.nextEligibleAt, scheduledAt)
    assert.equal(after.state, 'enabled')
    const unbound = new TaskboardService(new Context(), config)
    try {
      const other = unbound.provider.createProject({ key: 'OTH', name: 'Other' }, actor)
      const otherRule = unbound.provider.createAutomation(other.id, {
        intervalMs: 30_000, agentPreset: 'coding', concurrencyLimit: 1, quotaPolicy: 'pause-on-uncertain', autoPauseOnEmpty: false,
      }, actor)
      await assert.rejects(() => unbound.runAutomationNow(otherRule.id), /coordinator is not running/)
    } finally {
      unbound.provider.close()
    }
    await coordinator.stop()
  } finally {
    service.provider.close()
  }
})

test('snapshot reports a truncated task page instead of hiding tasks silently', () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, { ...config, snapshotTaskLimit: 3 })
  const actor = { kind: 'human', actorId: 'test-human' } as const
  try {
    const created = service.dispatchHumanRpc('project.create', { request: { key: 'DSH', name: 'Harness' } }, actor)
    assert.equal(created.ok, true)
    if (!created.ok) return
    const project = created.value as { id: string }
    for (let index = 0; index < 5; index += 1) {
      assert.equal(service.dispatchHumanRpc('task.create', {
        request: { projectId: project.id, title: `Task ${index}`, creator: 'test-human' },
      }, actor).ok, true)
    }

    const snapshot = service.snapshot(project.id as never)
    assert.equal(snapshot.tasks.length, 3)
    assert.equal(snapshot.taskTotal, 5)
    assert.equal(snapshot.tasksTruncated, true)
  } finally {
    service.provider.close()
  }
})

test('snapshot falls back to the first project when the requested one no longer exists', () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  const actor = { kind: 'human', actorId: 'test-human' } as const
  try {
    const created = service.dispatchHumanRpc('project.create', { request: { key: 'DSH', name: 'Harness' } }, actor)
    assert.equal(created.ok, true)
    if (!created.ok) return
    const project = created.value as { id: string }

    // A stale deep link or a project deleted elsewhere must not fail the whole page.
    const snapshot = service.snapshot('project-does-not-exist' as never)
    assert.equal(snapshot.projects.length, 1)
    assert.equal(snapshot.projects[0]?.id, project.id)
    assert.deepEqual(snapshot.tasks, [])
    assert.equal(snapshot.taskTotal, 0)
    assert.equal(snapshot.tasksTruncated, false)
  } finally {
    service.provider.close()
  }
})

test('the integrity scan is explicit and never rides along on a snapshot', () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  const actor = { kind: 'human', actorId: 'test-human' } as const
  try {
    const opened = service.snapshot().storageHealth
    assert.equal(opened.integrity, 'ok')
    assert.ok(opened.integrityCheckedAt > 0)
    assert.equal(service.snapshot().storageHealth.integrityCheckedAt, opened.integrityCheckedAt)

    const rechecked = service.dispatchHumanRpc('storage.check-integrity', {}, actor)
    assert.equal(rechecked.ok, true)
    if (!rechecked.ok) return
    assert.equal((rechecked.value as { integrity: string }).integrity, 'ok')
    assert.ok((rechecked.value as { integrityCheckedAt: number }).integrityCheckedAt >= opened.integrityCheckedAt)
  } finally {
    service.provider.close()
  }
})

test('archived work is budgeted apart from the live board and stays searchable past the limit', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, { ...config, snapshotTaskLimit: 3 })
  const actor = { kind: 'human', actorId: 'test-human' } as const
  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness' }, actor)
    for (let index = 0; index < 4; index += 1) {
      const task = service.provider.createTask({ projectId: project.id, title: `Archived ${index}`, creator: 'test-human' }, actor)
      service.provider.archive(task.id, task.version, actor)
    }
    const live = [0, 1, 2].map(index => service.provider.createTask({
      projectId: project.id, title: `Live ${index}`, creator: 'test-human',
    }, actor))
    const needle = service.provider.createTask({ projectId: project.id, title: 'Findable needle', creator: 'test-human' }, actor)

    // One shared budget let a large archive push every live card out of the snapshot and leave
    // nothing but a truncation notice on the board.
    const snapshot = service.snapshot(project.id)
    assert.equal(snapshot.tasks.filter(task => task.archivedAt === undefined).length, 3)
    assert.equal(snapshot.tasks.filter(task => task.archivedAt !== undefined).length, 4)
    assert.equal(snapshot.taskTotal, 8)
    assert.equal(snapshot.tasksTruncated, true)
    assert.ok(live.every(task => snapshot.tasks.some(row => row.id === task.id)))

    // The board filters in memory, so anything past the limit is only reachable through SQLite.
    assert.equal(snapshot.tasks.some(task => task.id === needle.id), false)
    const found = service.dispatchHumanRpc('task.search', { projectId: project.id, search: 'needle' }, actor)
    assert.equal(found.ok, true)
    if (!found.ok) return
    assert.deepEqual((found.value as Array<{ id: string }>).map(task => task.id), [needle.id])
  } finally {
    service.provider.close()
  }
})

test('the Typert mutation carrier refuses human writes outside the loopback RPC channel', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, config)
  try {
    const result = await service.remoteMutate({
      endpoint: 'task.accept',
      payloadJson: JSON.stringify({ taskId: 'missing', expectedVersion: 1 }),
    })
    assert.equal(result.ok, false)
    if (result.ok) return
    assert.equal(result.errorCode, 'loopback-required')
    assert.match(result.errorMessage ?? '', /requires a loopback connection/)
  } finally {
    service.provider.close()
  }
})

test('a replacement change watch releases the waiter its page abandoned', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, { ...config, maxChangeWaiters: 2 })
  try {
    const revision = service.provider.globalRevision()
    // An abort is local to the browser and never reaches the Host, so without the watcher id the
    // abandoned poll held its slot for the whole timeout and a refresh loop filled the pool.
    const abandoned = service.watchChanges(revision, 30_000, 'page-1')
    const replacement = service.watchChanges(revision, 30_000, 'page-1')
    assert.deepEqual(await abandoned, { globalRevision: revision, changed: false })

    const other = service.watchChanges(revision, 30_000, 'page-2')
    assert.throws(() => service.watchChanges(revision, 30_000, 'page-3'))

    service.provider.createProject({ key: 'DSH', name: 'Harness' }, { kind: 'human', actorId: 'test-human' })
    assert.equal((await replacement).changed, true)
    assert.equal((await other).changed, true)
  } finally {
    service.provider.close()
  }
})

test('service reports the store it opened through the Host logger', t => {
  const directory = mkdtempSync(join(tmpdir(), 'dsh-taskboard-service-storage-'))
  t.after(() => { rmSync(directory, { recursive: true, force: true }) })
  const databasePath = join(directory, 'taskboard.sqlite')
  const attachmentRoot = join(directory, 'attachments')
  const ctx = new Context()
  const lines: string[] = []
  ctx.logger.exporter({ export: message => { lines.push(message.args.map(String).join(' ')) } })

  const service = new TaskboardService(ctx, { databasePath, attachmentRoot })
  try {
    assert.deepEqual(lines, [
      `taskboard database path: ${databasePath}`,
      `taskboard attachments path: ${attachmentRoot}`,
      `taskboard database created at ${databasePath}`,
    ])
  } finally {
    service.provider.close()
  }
})
