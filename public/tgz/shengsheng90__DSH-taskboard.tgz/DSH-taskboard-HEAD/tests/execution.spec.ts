import assert from 'node:assert/strict'
import test from 'node:test'
import { Context } from '@deepseek-ai/cordis'
import type { Message } from '@deepseek-ai/dsh-llm'
import { TaskboardError } from '../src/domain/index.js'
import type { HumanActor } from '../src/domain/index.js'
import { completionResultComment, HarnessTaskboardWorker } from '../src/execution/index.js'
import { TaskboardService } from '../src/service/index.js'

const human: HumanActor = { kind: 'human', actorId: 'user-1' }
const hostDefaultModel = { provider: 'deepseek-official', model: 'deepseek-v4-flash' }

function provideDefaultModel(ctx: Context): void {
  ctx.provide('agentDefaultModel', { currentSelection: () => hostDefaultModel } as never)
}

test('native worker binds workspace, persists task input, follows human changes, and maps Goal completion to review', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, { databasePath: ':memory:', attachmentRoot: '.dsh/test' })
  const messages: Message[] = []
  const steered: Message[] = []
  const createdGoals: unknown[] = []
  const attachedSessions: string[] = []
  const createOptions: Array<Record<string, unknown>> = []
  const disposed: string[] = []
  let activeAgent: {
    id: string
    followup(message: Message): void
    steer(message: Message): void
    whenIdle(): Promise<void>
  } | undefined

  ctx.provide('agentPresets', { mount: async () => undefined } as never)
  provideDefaultModel(ctx)
  ctx.provide('workspaceRegistry', {
    get: () => ({ path: '/workspace/project', attachSession: async (id: string) => { attachedSessions.push(id) } }),
  } as never)
  ctx.provide('goals', {
    get: () => undefined,
    create: (_agent: unknown, request: unknown) => { createdGoals.push(request); return { id: 'goal-1' } },
  } as never)
  ctx.provide('agents', {
    list: () => activeAgent === undefined ? [] : [{ id: activeAgent.id }],
    create: async (options: Record<string, unknown> & { sessionId: string; setup(context: Context): Promise<void> }) => {
      createOptions.push(options)
      await options.setup(new Context())
      activeAgent = {
        id: options.sessionId,
        followup: message => { messages.push(message) },
        steer: message => { steered.push(message) },
        whenIdle: () => Promise.resolve(),
      }
      return { agent: activeAgent, dispose: () => { disposed.push(options.sessionId); return Promise.resolve() } }
    },
    resume: async () => { throw new Error('unexpected resume') },
  } as never)

  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness', workspaceId: 'workspace-1' }, human)
    const workflow = service.provider.createWorkflow(project.id, 'Implementation path', {
      tabs: [{
        id: 'tab-1', name: 'Delivery',
        trigger: { id: 'trigger-1', kind: 'issue-trigger', execution: 'design-only', config: { repository: 'acme/app' } },
        steps: [{ id: 'step-1', kind: 'planning', execution: 'design-only', config: { owner: 'agent' } }],
      }],
    }, human)
    let task = service.provider.createTask({
      projectId: project.id,
      title: 'Native worker',
      description: 'Implement and verify the execution path.',
      creator: human.actorId,
      workflowId: workflow.id,
      developmentContext: { kind: 'worktree', path: '/workspace/project/.worktrees/task', branch: 'task/native-worker' },
    }, human)
    task = service.provider.approve(task.id, task.version, human)
    const rule = service.provider.createAutomation(project.id, {
      intervalMs: 30_000,
      agentPreset: 'coding',
      concurrencyLimit: 1,
      quotaPolicy: 'pause-on-uncertain',
      autoPauseOnEmpty: false,
    }, human)

    const worker = new HarnessTaskboardWorker(ctx, service)
    await worker.start(rule, task)

    assert.equal(service.provider.getTask(task.id).status, 'in_progress')
    assert.equal(createOptions.length, 1)
    assert.deepEqual((createOptions[0]?.['meta'] as { cwd?: string; agentPreset?: string }), {
      cwd: '/workspace/project/.worktrees/task',
      agentPreset: 'coding',
    })
    assert.deepEqual(createOptions[0]?.['agentOptions'], hostDefaultModel)
    assert.equal(attachedSessions.length, 1)
    assert.deepEqual(createdGoals, [{ objective: 'Complete and verify DSH-1: Native worker' }])
    assert.equal(messages.length, 1)
    const activeClaim = service.provider.getTaskDetail(task.id).activeClaim
    assert.ok(activeClaim)
    assert.deepEqual(messages[0]?.source, {
      kind: 'taskboard', taskId: task.id, claimId: activeClaim.id,
      claimedRevision: service.provider.getTask(task.id).version,
    })
    assert.match(messages[0]?.content[0]?.type === 'text' ? messages[0].content[0].text : '', /Never modify the task description/)
    assert.match(messages[0]?.content[0]?.type === 'text' ? messages[0].content[0].text : '', /Only a human may accept it as done/)
    assert.match(messages[0]?.content[0]?.type === 'text' ? messages[0].content[0].text : '', /Implementation path \(guidance-only; nodes are not run automatically\)/)
    assert.match(messages[0]?.content[0]?.type === 'text' ? messages[0].content[0].text : '', /planning \[design-only\]; config=\{"owner":"agent"\}/)

    const inProgress = service.provider.getTask(task.id)
    service.provider.updateTask(inProgress.id, inProgress.version, { description: 'New durable requirement.' }, human)
    assert.equal(messages.length, 1)
    assert.equal(steered.length, 1)
    assert.deepEqual(steered[0]?.source, {
      kind: 'taskboard', taskId: task.id, claimId: activeClaim.id,
      claimedRevision: service.provider.getTask(task.id).version,
    })
    assert.match(steered[0]?.content[0]?.type === 'text' ? steered[0].content[0].text : '', /changed after your claim/)
    assert.match(steered[0]?.content[0]?.type === 'text' ? steered[0].content[0].text : '', /New durable requirement/)

    assert.ok(activeAgent)
    ;(worker as unknown as { onGoalChanged(agent: unknown, goal: unknown): void }).onGoalChanged(activeAgent, {
      id: 'goal-1', phase: 'complete', objective: 'complete task', createdAt: 1, updatedAt: 2,
    })
    const reviewed = service.provider.getTask(task.id)
    assert.equal(reviewed.status, 'in_review')
    assert.match(service.provider.getTaskDetail(task.id).comments.at(-1)?.body ?? '', /Work completed/)
    assert.equal(service.provider.getTask(task.id).description, 'New durable requirement.')

    // The handle is held while the claim is active, so human edits still reach an idle Agent,
    // and released once review submission retires the claim -- otherwise a long-lived Host keeps
    // one Agent handle per completed task forever.
    assert.deepEqual(disposed, [activeClaim.sessionId])
    assert.equal((worker as unknown as { handles: Map<string, unknown> }).handles.size, 0)

    await worker.stop()
  } finally {
    service.provider.close()
  }
})

test('startup reconciliation resumes the original orphaned Session and maps a blocked Goal without task theft', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, { databasePath: ':memory:', attachmentRoot: '.dsh/test' })
  const resumed: string[] = []
  const messages: Message[] = []
  let resumedAgent: { id: string; followup(message: Message): void; whenIdle(): Promise<void> } | undefined
  ctx.provide('agentPresets', { mount: async () => undefined } as never)
  provideDefaultModel(ctx)
  ctx.provide('workspaceRegistry', { get: () => undefined } as never)
  ctx.provide('goals', {
    get: () => undefined,
    create: () => ({ id: 'goal-resumed' }),
  } as never)
  const resumeOptions: Array<Record<string, unknown>> = []
  ctx.provide('agents', {
    list: () => [],
    create: async () => { throw new Error('reconciliation must not create a replacement Session') },
    resume: async (options: { resumeSessionId: string; setup(context: Context): Promise<void> }) => {
      resumeOptions.push(options)
      resumed.push(options.resumeSessionId)
      await options.setup(new Context())
      resumedAgent = {
        id: options.resumeSessionId,
        followup: message => { messages.push(message) },
        whenIdle: () => Promise.resolve(),
      }
      return { agent: resumedAgent, dispose: () => Promise.resolve() }
    },
  } as never)
  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness' }, human)
    let task = service.provider.createTask({ projectId: project.id, title: 'Resume me', creator: human.actorId, status: 'todo' }, human)
    let rule = service.provider.createAutomation(project.id, {
      intervalMs: 30_000, agentPreset: 'coding', concurrencyLimit: 1,
      quotaPolicy: 'pause-on-uncertain', autoPauseOnEmpty: false,
    }, human)
    rule = service.provider.updateAutomation(rule.id, rule.version, { state: 'enabled' }, human)
    const sessionId = 'taskboard-existing-session'
    task = service.provider.claim(task.id, { expectedVersion: task.version, sessionId, agentId: sessionId }, {
      kind: 'automation', actorId: `automation:${rule.id}`, automationId: rule.id, sessionId, agentId: sessionId,
    }).task

    const worker = new HarnessTaskboardWorker(ctx, service)
    await worker.reconcile()
    assert.deepEqual(resumed, [sessionId])
    assert.deepEqual(resumeOptions[0]?.['agentOptions'], hostDefaultModel)
    assert.equal(service.provider.getTaskDetail(task.id).activeClaim?.sessionId, sessionId)
    assert.equal(service.provider.getTaskDetail(task.id).activeClaim?.state, 'active')
    assert.equal(messages[0]?.source.kind, 'taskboard')

    assert.ok(resumedAgent)
    ;(worker as unknown as { onGoalChanged(agent: unknown, goal: unknown): void }).onGoalChanged(resumedAgent, {
      id: 'goal-resumed', phase: 'blocked', objective: 'resume task', createdAt: 1, updatedAt: 2,
      blockedReason: { message: 'Repository permission requires human approval.' },
    })
    assert.equal(service.provider.getTask(task.id).status, 'blocked')
    assert.deepEqual(service.provider.getTaskDetail(task.id).activities.at(-1)?.after, {
      status: 'blocked', reason: 'Repository permission requires human approval.',
    })
    await worker.stop()
  } finally {
    service.provider.close()
  }
})

test('native worker prefers an explicit automation modelRoute over the Host default', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, { databasePath: ':memory:', attachmentRoot: '.dsh/test' })
  const createOptions: Array<Record<string, unknown>> = []
  provideDefaultModel(ctx)
  ctx.provide('agentPresets', { mount: async () => undefined } as never)
  ctx.provide('workspaceRegistry', { get: () => undefined } as never)
  ctx.provide('goals', { get: () => undefined, create: () => ({ id: 'goal-1' }) } as never)
  ctx.provide('agents', {
    list: () => [],
    create: async (options: Record<string, unknown> & { sessionId: string; setup(context: Context): Promise<void> }) => {
      createOptions.push(options)
      await options.setup(new Context())
      return {
        agent: { id: options.sessionId, followup: () => undefined, whenIdle: () => Promise.resolve() },
        dispose: () => Promise.resolve(),
      }
    },
    resume: async () => { throw new Error('unexpected resume') },
  } as never)
  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness' }, human)
    let task = service.provider.createTask({ projectId: project.id, title: 'Routed model', creator: human.actorId }, human)
    task = service.provider.approve(task.id, task.version, human)
    const rule = service.provider.createAutomation(project.id, {
      intervalMs: 30_000, agentPreset: 'coding', concurrencyLimit: 1,
      quotaPolicy: 'pause-on-uncertain', autoPauseOnEmpty: false,
      modelRoute: 'acme-gateway:acme-large', reasoning: 'high',
    }, human)
    const worker = new HarnessTaskboardWorker(ctx, service)
    await worker.start(rule, task)
    assert.deepEqual(createOptions[0]?.['agentOptions'], { provider: 'acme-gateway', model: 'acme-large' })
    await worker.stop()
  } finally {
    service.provider.close()
  }
})

test('native worker fails loudly when Host default model is missing and modelRoute is empty', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, { databasePath: ':memory:', attachmentRoot: '.dsh/test' })
  ctx.provide('agentPresets', { mount: async () => undefined } as never)
  ctx.provide('workspaceRegistry', { get: () => undefined } as never)
  ctx.provide('goals', { get: () => undefined, create: () => ({ id: 'goal-1' }) } as never)
  ctx.provide('agents', {
    list: () => [],
    create: async () => { throw new Error('must not create an Agent without a model') },
    resume: async () => { throw new Error('unexpected resume') },
  } as never)
  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness' }, human)
    let task = service.provider.createTask({ projectId: project.id, title: 'No model', creator: human.actorId }, human)
    task = service.provider.approve(task.id, task.version, human)
    const rule = service.provider.createAutomation(project.id, {
      intervalMs: 30_000, agentPreset: 'coding', concurrencyLimit: 1,
      quotaPolicy: 'pause-on-uncertain', autoPauseOnEmpty: false,
    }, human)
    const worker = new HarnessTaskboardWorker(ctx, service)
    await assert.rejects(() => worker.start(rule, task), /Host default model is unavailable/)
    assert.equal(service.provider.getTask(task.id).status, 'todo')
    await worker.stop()
  } finally {
    service.provider.close()
  }
})

test('goal completion writes a result comment and does not copy existing comments', () => {
  assert.equal(completionResultComment([]), 'Work completed.')
  assert.equal(completionResultComment([{ body: 'Implemented the endpoint.' }]), 'Ready for review.')
})

test('a human-started native Session binds its claim and maps a blocked Goal to the task', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, { databasePath: ':memory:', attachmentRoot: '.dsh/test' })
  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness', workspaceId: 'workspace-1' }, human)
    let task = service.provider.createTask({ projectId: project.id, title: 'Needs a decision', creator: human.actorId }, human)
    task = service.provider.approve(task.id, task.version, human)
    const sessionId = 'session-human-started'
    const bound = service.provider.bindHumanSession(task.id, task.version, { sessionId, agentId: sessionId }, human)
    assert.equal(bound.task.status, 'in_progress')
    assert.equal(bound.claim.sessionId, sessionId)

    const worker = new HarnessTaskboardWorker(ctx, service)
    ;(worker as unknown as { onGoalChanged(agent: unknown, goal: unknown): void }).onGoalChanged({ id: sessionId }, {
      id: 'goal-human-started', phase: 'blocked', objective: 'Need a human choice',
      blockedReason: { message: 'Choose a deployment target.' }, createdAt: 1, updatedAt: 2,
    })

    assert.equal(service.provider.getTask(task.id).status, 'blocked')
    assert.match(service.provider.getTaskDetail(task.id).comments.at(-1)?.body ?? '', /Choose a deployment target/)
    await worker.stop()
  } finally {
    service.provider.close()
  }
})

test('human comments on a claimed task reach the owning Session, and a blank Goal blocker is survivable', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, { databasePath: ':memory:', attachmentRoot: '.dsh/test' })
  const messages: Message[] = []
  const steered: Message[] = []
  let activeAgent: { id: string; followup(message: Message): void; steer(message: Message): void; whenIdle(): Promise<void> } | undefined
  ctx.provide('agentPresets', { mount: async () => undefined } as never)
  provideDefaultModel(ctx)
  ctx.provide('workspaceRegistry', { get: () => ({ path: '/workspace/project', attachSession: async () => undefined }) } as never)
  ctx.provide('goals', { get: () => undefined, create: () => ({ id: 'goal-1' }) } as never)
  ctx.provide('agents', {
    list: () => activeAgent === undefined ? [] : [{ id: activeAgent.id }],
    create: async (options: { sessionId: string; setup(context: Context): Promise<void> }) => {
      await options.setup(new Context())
      activeAgent = {
        id: options.sessionId,
        followup: message => { messages.push(message) },
        steer: message => { steered.push(message) },
        whenIdle: () => Promise.resolve(),
      }
      return { agent: activeAgent, dispose: () => Promise.resolve() }
    },
    resume: async () => { throw new Error('unexpected resume') },
  } as never)

  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness', workspaceId: 'workspace-1' }, human)
    let task = service.provider.createTask({ projectId: project.id, title: 'Commented', creator: human.actorId }, human)
    task = service.provider.approve(task.id, task.version, human)
    const rule = service.provider.createAutomation(project.id, {
      intervalMs: 30_000, agentPreset: 'coding', concurrencyLimit: 1,
      quotaPolicy: 'pause-on-uncertain', autoPauseOnEmpty: false,
    }, human)
    const worker = new HarnessTaskboardWorker(ctx, service)
    await worker.start(rule, task)
    // One message so far: the initial instruction.
    assert.equal(messages.length, 1)

    // The provider writes `comment.created` / `comment.updated`; the listener used to test for a
    // `task.commented` kind that nothing emits, so human comments never reached the Session.
    const claimed = service.provider.getTask(task.id)
    service.provider.comment(claimed.id, claimed.version, 'Also cover the blank-input case.', human)
    assert.equal(messages.length, 1)
    assert.equal(steered.length, 1)
    assert.match(steered[0]?.content[0]?.type === 'text' ? steered[0].content[0].text : '', /changed after your claim/)
    assert.match(steered[0]?.content[0]?.type === 'text' ? steered[0].content[0].text : '', /Also cover the blank-input case/)

    const commentId = service.provider.getTaskDetail(task.id).comments.at(-1)?.id ?? ''
    const beforeEdit = service.provider.getTask(task.id)
    service.provider.updateComment(beforeEdit.id, beforeEdit.version, commentId, 'Cover the whitespace case instead.', human)
    assert.equal(steered.length, 2)
    assert.match(steered[1]?.content[0]?.type === 'text' ? steered[1].content[0].text : '', /whitespace case/)

    // A Goal can report a blank reason. `requiredText` used to throw that straight out of the Host
    // event dispatch, leaving the task in progress and the Session handle held.
    assert.ok(activeAgent)
    ;(worker as unknown as { onGoalChanged(agent: unknown, goal: unknown): void }).onGoalChanged(activeAgent, {
      id: 'goal-1', phase: 'blocked', objective: 'blocked task', blockedReason: { message: '   ' }, createdAt: 1, updatedAt: 2,
    })
    assert.equal(service.provider.getTask(task.id).status, 'blocked')
    assert.match(service.provider.getTaskDetail(task.id).comments.at(-1)?.body ?? '', /Blocked: Harness Goal blocked/)
    await worker.stop()
  } finally {
    service.provider.close()
  }
})

test('a Goal that outlives its claim records the failure instead of throwing at the Host', async () => {
  const ctx = new Context()
  const service = new TaskboardService(ctx, { databasePath: ':memory:', attachmentRoot: '.dsh/test' })
  let activeAgent: { id: string; followup(): void; whenIdle(): Promise<void> } | undefined
  ctx.provide('agentPresets', { mount: async () => undefined } as never)
  provideDefaultModel(ctx)
  ctx.provide('workspaceRegistry', { get: () => ({ path: '/workspace/project', attachSession: async () => undefined }) } as never)
  ctx.provide('goals', { get: () => undefined, create: () => ({ id: 'goal-1' }) } as never)
  ctx.provide('agents', {
    list: () => activeAgent === undefined ? [] : [{ id: activeAgent.id }],
    create: async (options: { sessionId: string; setup(context: Context): Promise<void> }) => {
      await options.setup(new Context())
      activeAgent = { id: options.sessionId, followup: () => undefined, whenIdle: () => Promise.resolve() }
      return { agent: activeAgent, dispose: () => Promise.resolve() }
    },
    resume: async () => { throw new Error('unexpected resume') },
  } as never)

  try {
    const project = service.provider.createProject({ key: 'DSH', name: 'Harness', workspaceId: 'workspace-1' }, human)
    let task = service.provider.createTask({ projectId: project.id, title: 'Raced', creator: human.actorId }, human)
    task = service.provider.approve(task.id, task.version, human)
    const rule = service.provider.createAutomation(project.id, {
      intervalMs: 30_000, agentPreset: 'coding', concurrencyLimit: 1,
      quotaPolicy: 'pause-on-uncertain', autoPauseOnEmpty: false,
    }, human)
    const worker = new HarnessTaskboardWorker(ctx, service)
    await worker.start(rule, task)
    assert.ok(activeAgent)
    // Force the mutation to fail the way a cross-process write would: the version the listener
    // reads no longer matches by the time it writes.
    const patched = service.provider as unknown as { submitReview(...args: unknown[]): unknown }
    const original = patched.submitReview.bind(service.provider)
    patched.submitReview = () => { throw new TaskboardError('task version changed during transition', 'TASK_STALE_VERSION') }
    try {
      ;(worker as unknown as { onGoalChanged(agent: unknown, goal: unknown): void }).onGoalChanged(activeAgent, {
        id: 'goal-1', phase: 'complete', objective: 'done task', createdAt: 1, updatedAt: 2,
      })
    } finally {
      patched.submitReview = original
    }
    const runs = service.provider.listAutomationRuns(project.id)
    assert.ok(runs.some(run => run.decision.kind === 'error' && /Goal handoff failed/.test(run.decision.message)))
    // The authoritative task is untouched and the claim survives, so the Session handle is still
    // legitimately held; what must not happen is the domain error escaping the listener.
    assert.equal(service.provider.getTask(task.id).status, 'in_progress')
    assert.equal(service.provider.getTaskDetail(task.id).activeClaim?.state, 'active')
    await worker.stop()
  } finally {
    service.provider.close()
  }
})
