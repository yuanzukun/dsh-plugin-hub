/**
 * Where the enterprise deployment lives: the API host the PAT is exchanged and
 * the models are called on (`host`), and the console host that serves
 * GetUserInfo and a ToB seat's quota (`consoleHost`).
 *
 * Trae enterprise is not only the public SaaS. A privately deployed client
 * writes its own addresses into
 * `<Trae client>/User/globalStorage/storage.json` (`iCubeHostInfo.apiHost` /
 * `iCubeHostInfo.consoleHost`, measured: the two are the same origin), and on
 * such a deployment the built-in host refuses every PAT with `30021 网络异常`.
 *
 * Both are ordinary — not volatile — config fields. The settings card writes
 * them through dsh's configEditor, which persists them in the active
 * profile's patch and reloads the plugin: a new host has to rebuild the JWT,
 * the catalog and everything cached on top of them anyway.
 */

import { TRAE_HOST } from './auth.ts'
import { TOB_CONSOLE_HOST } from './tob.ts'

/** The config fields the card's deployment section edits. */
export const DEPLOYMENT_FIELDS = ['host', 'consoleHost'] as const
export type DeploymentField = typeof DEPLOYMENT_FIELDS[number]
export type DeploymentChanges = Partial<Record<DeploymentField, string>>

/**
 * A typed address as the origin the plugin appends its paths to: trimmed,
 * `https://` when no scheme is given, no trailing slash; a path prefix is kept
 * (a deployment may sit under one). `''` stays `''` — the default. Undefined
 * when it is not a plain http(s) address.
 */
export function normalizeOrigin(text: string): string | undefined {
  const trimmed = text.trim()
  if (!trimmed) return ''
  const withScheme = /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`
  let url: URL
  try { url = new URL(withScheme) } catch { return undefined }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') return undefined
  if (!url.hostname || url.search || url.hash || url.username || url.password) return undefined
  return `${url.origin}${url.pathname}`.replace(/\/+$/, '')
}

/**
 * The console origin actually used: the configured one; else, on a private
 * deployment (any API host but the built-in one), the API host itself; else
 * the public console.
 */
export function consoleHostFor(host: string, consoleHost: string): string {
  const own = consoleHost.trim().replace(/\/+$/, '')
  if (own) return own
  const api = host.trim().replace(/\/+$/, '')
  return api && api !== TRAE_HOST ? api : TOB_CONSOLE_HOST
}

/**
 * The next raw config with the given deployment fields changed. `''` removes
 * the field, and so does the built-in API host typed out in full, so going
 * back to the default leaves no override behind (the editor then drops the
 * profile row's config altogether if nothing else is in it).
 */
export function withDeployment(current: Record<string, unknown>, changes: DeploymentChanges): Record<string, unknown> {
  const next = { ...current }
  for (const field of DEPLOYMENT_FIELDS) {
    const value = changes[field]
    if (value === undefined) continue
    if (value === '' || (field === 'host' && value === TRAE_HOST)) delete next[field]
    else next[field] = value
  }
  return next
}

/**
 * The editor's refusals in terms of this card. The one worth translating is
 * a higher layer pinning the row: the profile patch is the editor's own
 * target, but a home patch or a command-line overlay wins over it, so a save
 * there would never take effect and is refused outright.
 */
export function deploymentSaveError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error)
  if (/overridden by a home patch or command-line overlay/i.test(message)) {
    return `部署地址被更高一层的配置钉住了：home patch 或命令行覆盖里写了 trae2api 的 config，界面改不动。去那里改，或者删掉那几行再回来保存。（${message}）`
  }
  return message
}
