/**
 * dsh-trae2api — browser half.
 *
 * Renders one settings card in two places:
 *   - the Models settings page, inside the "Trae" provider row
 *     (slot `settings.models.provider-card`, keyed by our settings namespace);
 *   - the plugin's own page in the Plugins sidebar
 *     (slot `plugins.bundle.config`, keyed by the package name).
 *
 * The card edits the host plugin's volatile config fields through the settings
 * service, writes the Trae PAT to the credential store (never into config),
 * sets a private deployment's addresses through the host's own route (they
 * reload the plugin, which the settings service does not do), and shows
 * whether Trae accepts it and which models it serves — the same
 * models the composer's model picker offers — plus the remaining quota.
 *
 * The remaining quota also shows as a small chip next to the composer's model
 * picker (slot `conversation.input.right`) while a Trae model is selected.
 *
 * One "Trae" View tab (slot `conversation.view`), beside the host's 对话 /
 * 轨迹 / 上下文, holds everything Trae-specific about the session: its ids —
 * its own, the upstream conversation its last Trae turn ran in, and Trae's own
 * support line, each with a copy button — and, on the same page, Trae share
 * links (read one, mint one). The tab is on the row only while a session on
 * screen has a Trae model selected.
 *
 * After each Trae answer, cards above the composer (slot
 * `conversation.input.dock`) offer the next steps the answer left open, each
 * with the model's own answers as buttons; a button picks its card's answer,
 * and the picks go out together with an optional note — as subagent tasks
 * while `suggestSubagent` is on, which the line under the cards says and can
 * switch back to this session.
 */
window.__ModuleLoader__.load({
  id: 'dsh-trae2api',
  factory: (require) => {
    const React = require('react')
    const P = require('@deepseek-ai/dsh-client-ui-primitives')
    // Optional: the collapsed status line goes up into the row's own header
    // when portals are available, and stays in the card body when they are not.
    let createPortal
    try { createPortal = require('react-dom').createPortal } catch { createPortal = undefined }
    const h = React.createElement

    /** Settings namespace = the row id the bundle patch inserts. */
    const SETTINGS_NS = 'trae2api'
    /** Package name, the key of the plugin page's bundle-config slot. */
    const PACKAGE = 'dsh-trae2api'
    /** Locale namespace owned by this plugin. */
    const NS = 'dshTrae2api'
    /** Provider route the host registers. */
    const PROVIDER = 'trae'
    const DEFAULT_TOKEN_REF = 'TRAE_PAT'
    const TOKEN_FIELD = 'pat'
    /** Enterprise console login, only shown for a ToB seat (see src/trae/tob.ts). */
    const DEFAULT_CONSOLE_PASSWORD_REF = 'TRAE_CONSOLE_PASSWORD'
    const CONSOLE_PASSWORD_FIELD = 'consolePassword'
    const EMAIL_FIELD = 'consoleEmail'
    const DEFAULT_CONSOLE_EMAIL_REF = 'TRAE_CONSOLE_EMAIL'
    /** Whether next-step cards are offered at all (host config `suggestions`). */
    const SUGGEST_FIELD = 'suggestions'
    /**
     * The boolean as the two choices the card offers. An absent value is the
     * schema default, on — the same as a host too old to serve the field.
     */
    const SUGGEST_SPEC = {
      field: SUGGEST_FIELD,
      format: value => (value === false ? 'off' : 'on'),
      parse: text => ({ kind: 'set', value: text !== 'off' }),
    }
    /** Who does what a next-step card sends, by default (host config `suggestSubagent`). */
    const SUBAGENT_FIELD = 'suggestSubagent'
    /**
     * The boolean as the two choices the card offers. An absent value is the
     * schema default, on — the same as a host too old to serve the field.
     */
    const SUBAGENT_SPEC = {
      field: SUBAGENT_FIELD,
      format: value => (value === false ? 'inline' : 'subagent'),
      parse: text => ({ kind: 'set', value: text !== 'inline' }),
    }
    /** Host route serving the remaining quota (see QUOTA_ROUTE in src/index.ts). */
    const QUOTA_ROUTE = '/api/dsh-trae2api/quota'
    /** How often a visible chip re-reads the quota. */
    const QUOTA_POLL_MS = 5 * 60_000
    /** How long the "new upstream conversation next turn" notice stays up. */
    const SWITCH_NOTICE_MS = 8_000
    /** Host route serving the session's own id and its upstream one (SESSION_ROUTE). */
    const SESSION_ROUTE = '/api/dsh-trae2api/session'
    /**
     * Host route for share links (SHARE_ROUTE in src/index.ts): `?id=` reads one
     * anonymously, `?sessions=1` lists the account's real chat sessions, and a
     * POST with `action: 'create'` mints a link.
     */
    const SHARE_ROUTE = '/api/dsh-trae2api/share'
    /**
     * Host route for the deployment's addresses (DEPLOYMENT_ROUTE in
     * src/index.ts): GET reads them, POST `{host?, consoleHost?}` saves them
     * through the profile and reloads the host plugin.
     */
    const DEPLOYMENT_ROUTE = '/api/dsh-trae2api/deployment'
    /** The deployment fields the card edits, in the order it shows them. */
    const DEPLOYMENT_FIELDS = ['host', 'consoleHost']
    /** How often, and how far apart, a save reads the reloaded plugin back. */
    const DEPLOYMENT_READBACK = { attempts: 8, intervalMs: 500 }
    /**
     * A typed address the way the host half stores it (`normalizeOrigin` in
     * src/trae/deployment.ts): `https://` when no scheme is given, no trailing
     * slash, `''` for empty; undefined when it is no http(s) address.
     */
    function normalizeOrigin(text) {
      const trimmed = String(text ?? '').trim()
      if (!trimmed) return ''
      const withScheme = /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`
      let url
      try { url = new URL(withScheme) } catch { return undefined }
      if (url.protocol !== 'https:' && url.protocol !== 'http:') return undefined
      if (!url.hostname || url.search || url.hash || url.username || url.password) return undefined
      return `${url.origin}${url.pathname}`.replace(/\/+$/, '')
    }
    /** This plugin's own entry in the session's View tab row (ids + share links). */
    const TAB_ID = 'trae-session'
    /** How long the chip says "copied" after a click. */
    const COPIED_MS = 1_600
    /** Host route serving next-step cards (see SUGGESTION_ROUTE in src/index.ts). */
    const SUGGESTION_ROUTE = '/api/dsh-trae2api/suggestion'
    /** How long a just-ended turn waits for its cards. */
    const SUGGESTION_WAIT_MS = 20_000
    /** Host route the composer reports shown cards / a pressed button to (SUGGESTION_EVENT_ROUTE). */
    const SUGGESTION_EVENT_ROUTE = '/api/dsh-trae2api/suggestion/event'
    /**
     * Fire-and-forget: the host dedupes, times and decides whether anything is
     * reported (Cue reporting is off unless configured).
     */
    function reportSuggestion(session, id, action, pick) {
      fetch(SUGGESTION_EVENT_ROUTE.slice(1), {
        method: 'POST',
        headers: { 'content-type': 'application/json', accept: 'application/json' },
        body: JSON.stringify({ session, id, action, ...pick }),
      }).catch(() => {})
    }

    const zh = {
      title: 'Trae',
      description: '直接使用 Trae 企业版的模型，只需填写个人访问令牌',
      token: 'Trae 个人访问令牌（PAT）',
      tokenHint: '在 Trae 企业版控制台生成。只保存在 dsh 的凭据库里，不会写进任何配置文件。保存后立即生效。',
      tokenSet: '已保存',
      tokenUnset: '未填写',
      unavailable: 'Trae 插件当前未加载，暂时无法配置。',
      readOnly: '当前部署的设置是只读的。',
      save: '保存',
      saving: '保存中…',
      saveFailed: '保存失败，修改已保留，请检查后重试。',
      status: '连接状态',
      checking: '正在连接 Trae…',
      ready: '已连接，{n} 个模型可用。在输入框的模型菜单里选「Trae」分组，思考档位在同一菜单。',
      failed: '连接失败',
      empty: 'Trae 没有返回任何模型。',
      refresh: '重新检测',
      models: '可用模型（{n}）',
      quota: '剩余额度',
      quotaRefresh: '刷新',
      quotaLoading: '正在查询额度…',
      quotaRemaining: '剩余 {remaining} / {limit}（{percent}）',
      quotaPackUsed: '已用 {used} / {limit}',
      quotaUsed: '已用 {used}',
      quotaUnlimited: '不限量',
      quotaEnds: '{date} 到期',
      quotaNone: '当前账号没有额度包。',
      quotaEnterprise: '你是企业版账号，填一下控制台账号就能看到额度。',
      quotaEnterpriseHint: '企业版的额度记在公司账户下（租户 {tenant}），Trae 给 IDE 的那个接口查不到，只有企业控制台知道。在下面填一次登录控制台用的邮箱和密码就好。',
      console: '企业控制台账号',
      consoleHint: '就是你登录企业控制台（公网企业版是 console.enterprise.trae.cn）用的那个账号。密码只存在 dsh 的凭据库里，不会写进配置文件。用 SSO 登录的公司暂时用不了这个。',
      consoleEmail: '邮箱',
      consolePassword: '密码',
      consoleSet: '已保存',
      consoleUnset: '未填写',
      consoleSaveFailed: '没保存上：',
      consoleSettled: '已连上控制台，额度正常读取中。要换账号就点右边的「修改」。',
      consoleEdit: '修改',
      credentialsEdit: '编辑',
      cancel: '取消',
      collapsedReady: '已连接 · {n} 个模型',
      collapsedQuota: '剩余 {percent}',
      consoleCollapse: '收起',
      deployment: '部署地址',
      deploymentSaas: '公网企业版',
      deploymentPrivate: '私有化部署',
      deploymentHost: '接口地址',
      deploymentHostHint: '公网企业版留空即可。私有化部署填你们自己的地址，就是 Trae 客户端 storage.json 里的 iCubeHostInfo.apiHost。保存后插件会重载，用新地址重新兑换令牌、拉模型列表。',
      deploymentConsole: '控制台地址',
      deploymentConsoleHint: '额度和账号信息从这里读。留空：私有化部署跟随上面的接口地址，公网企业版用 console.enterprise.trae.cn。和接口地址不同时才需要填（iCubeHostInfo.consoleHost）。',
      deploymentInvalid: '不是一个 http(s) 地址',
      deploymentSaveFailed: '部署地址没保存上：',
      deploymentReadOnly: '这个 dsh 不能从界面改部署地址，只能手改 profile 的 cordis.patch.yml（- id: trae2api / config: { host: … }）。',
      quotaModels: '按模型用量（{n}）',
      quotaNoneHint: '查了 {source}，这个账号名下没有任何额度包。如果你在 Trae 官网能看到额度，说明接口对不上，欢迎把这行反馈回来。',
      quotaUnknown: 'Trae 返回了无法识别的额度格式。原始响应如下，可用于反馈：',
      quotaFailed: '额度查询失败：',
      quotaChip: 'Trae 剩余 {percent}',
      quotaChipPack: '{name}：{detail}',
      quotaChipTotal: '合计：{detail}',
      quotaChipHint: '点击刷新',
      sessionTabTitle: 'Trae',
      sessionIdsTitle: '会话 ID',
      shareTitle: '分享这条会话',
      shareLead: '每轮对话单独显示，回答里带思考和工具调用。不调用模型。',
      shareStatTurns: '{n} 轮',
      shareStatSteps: '{n} 步工具调用',
      shareNoTurnYet: '插件启动后用 Trae 模型跑完一轮，这里就能分享。',
      shareAction: '生成分享链接',
      shareActionAgain: '再生成一条',
      shareBusy: '生成中…',
      shareReplay: '改为逐轮重放（{n} 次模型调用）',
      shareReplayHint: '逐轮重放会把每个提问重新发给 Trae，页面上的回答由 Trae 重新生成，不是这里的原文。',
      shareReplayConfirm: '确认重放',
      shareReplayCancel: '取消',
      sharePublicNote: '拿到链接的人不用登录就能看完整对话，有效期 1 年。',
      shareDropped: '只带上了最近 {turns} 轮：单条分享最多 50 轮，更早的 {dropped} 轮没带上。',
      shareCallsNote: '{n} 次模型调用',
      shareOpen: '打开',
      shareCopy: '复制链接',
      shareCopied: '已复制',
      shareCopyFailed: '复制失败',
      shareExpires: '有效至 {date}',
      shareCreated: '{date} 创建',
      shareFilesTitle: '分享生成的文件',
      shareFilesLead: '把这条会话写出的 Markdown / HTML 发成网页链接。同一目录里被引用的图片、样式会一起打包，Markdown 会排版成网页。同一个文件再分享一次，链接不变、内容更新。',
      shareFilesEmpty: '这条会话还没写出 .md / .html 文件。也可以在下面填文件的绝对路径。',
      shareFileAction: '分享',
      shareFileUpdate: '更新',
      shareFileBusy: '上传中…',
      shareFileOther: '其他文件',
      shareFilePlaceholder: '/绝对路径/report.html 或 notes.md',
      shareFileCount: '{n} 个文件',
      shareFileCardAction: '分享',
      shareFileCardTitle: '发成网页链接（拿到链接的人不用登录就能打开）',
      shareFileCardBusy: '分享中…',
      shareFileCardRetry: '重试分享',
      shareFileInline: '分享为网页',
      shareMineTitle: '我的分享',
      shareMineRefresh: '刷新',
      shareMineLoading: '读取中…',
      shareMineEmpty: '还没有分享。生成第一条后会出现在这里。',
      shareUntitled: '（无标题）',
      shareStateActive: '公开中',
      shareStateDisabled: '已关闭',
      shareStateAuditing: '审核中',
      shareClose: '关闭链接（对方打开会提示已关闭）',
      shareReopen: '重新公开',
      shareDelete: '删除（不能恢复）',
      shareDeleteConfirm: '确认删除',
      sessionTabNotTrae: '这条会话现在选的不是 Trae 模型，下面两项说的是它上一轮跑 Trae 时的情况。',
      sessionIdRow: '会话 ID',
      sessionIdRowHint: 'dsh 这边的会话 ID，插件按它分会话。',
      sessionUpstreamRow: '上游会话',
      sessionUpstreamRowHint: '上游按「会话 × 模型 × 思考档位」分别开会话，这条 ID 猜不出来。',
      sessionUpstreamRowOn: '上一轮跑在：{model}',
      sessionDebugRow: '排查串',
      sessionDebugRowHint: 'Trae 客户端给客服用的那套格式；裸接口没有的字段保留 no_* 占位符。',
      sessionNoTurn: '这条会话还没发过一轮，发一轮就有了',
      sessionCopy: '复制',
      sessionCopied: '已复制',
      sessionCopyFailedShort: '复制失败',
      switchNotice: '换了模型／档位 · 下一轮重开会话',
      switchNoticeHint: '上游是按会话绑定模型的：换了模型或思考档位，下一轮就在一条新的上游会话里跑。上一个模型的服务端状态和 prompt 缓存都不沿用，这一轮按完整 prompt 计费；换回原来的模型和档位，还是回到它自己那条会话。',
      switchCardHint: '换模型或思考档位会在下一轮开一条新的上游会话（prompt 缓存从头建立）——上游不认同一条会话里换模型。',
      choicesDismiss: '收起',
      choicesEyebrow: '下一步',
      choicesOther: '其他建议',
      choicesOtherPlaceholder: '说说你想怎么做，回车发送',
      choicesSend: '发送',
      choicesSubagentOn: '子会话处理',
      choicesSubagentOff: '当前会话处理',
      choicesSubagentHint: '点按钮选中，选好后一起发送；交给子会话去做，不占当前会话的上下文，做完回来汇报。',
      choicesInlineHint: '点按钮选中，选好后一起发送，在当前会话里做。',
      choicesSubagentToggle: '切换由谁来做：子会话 / 当前会话',
      choicesPicked: '关于「{question}」：{reply}',
      choicesSubagentTask: '请开一个子会话来做下面这件事：用 subagent 工具把它派出去，你自己不要在当前会话里直接动手；子会话结束后把结果要点和改动过的文件告诉我。\n\n{context}任务：{task}',
      choicesSubagentTasks: '请为下面每件事各开一个子会话来做：每件事用 subagent 工具单独派出去，互不依赖的可以同时派；你自己不要在当前会话里直接动手。子会话都结束后，把每件事的结果要点和改动过的文件告诉我。\n\n{tasks}',
      choicesSubagentItem: '任务：{task}',
      choicesSubagentContext: '背景：上一轮结束时待定的问题是「{question}」。',
      choicesPickedCount: '已选 {n}/{total}',
      choicesExtraPlaceholder: '补充几句（可选），回车发送',
      choicesExtra: '补充：{text}',
      choicesSubagentExtra: '补充（派活时一并交代给子会话）：{text}',
      choicesEnabled: '下一步卡片',
      choicesEnabledOn: '开',
      choicesEnabledOff: '关',
      choicesEnabledHint: '每轮回答结束后，在输入框上方给出下一步卡片。关掉就一张也不出，也不会多花那次生成卡片的请求。保存后下一轮生效。',
      choicesDefault: '下一步卡片默认由谁来做',
      choicesDefaultHint: '从下一步卡片发出去的任务默认交给谁。卡片下面那行还能临时切换，只对当前这一轮有效。保存后下一轮卡片就按新的来。',
      choicesFold: '折叠',
      choicesFoldHint: '把下一步卡片折叠成一行，之后几轮也保持折叠',
      choicesUnfold: '展开',
      choicesFoldedCount: '{n} 条',
    }
    const en = {
      title: 'Trae',
      description: 'Use Trae enterprise models with just a Personal Access Token',
      token: 'Trae Personal Access Token (PAT)',
      tokenHint: 'Create it in the Trae enterprise console. Stored only in the dsh credential store, never in config. Takes effect on save.',
      tokenSet: 'Saved',
      tokenUnset: 'Not set',
      unavailable: 'The Trae plugin is not loaded right now.',
      readOnly: 'Settings are read-only in this deployment.',
      save: 'Save',
      saving: 'Saving…',
      saveFailed: 'Save failed; your edits were kept.',
      status: 'Connection',
      checking: 'Connecting to Trae…',
      ready: 'Connected, {n} models available. Pick one under "Trae" in the composer model menu; thinking level is in the same menu.',
      failed: 'Connection failed',
      empty: 'Trae returned no models.',
      refresh: 'Check again',
      models: 'Models ({n})',
      quota: 'Remaining quota',
      quotaRefresh: 'Refresh',
      quotaLoading: 'Checking quota…',
      quotaRemaining: '{remaining} of {limit} left ({percent})',
      quotaPackUsed: '{used} of {limit} used',
      quotaUsed: '{used} used',
      quotaUnlimited: 'Unlimited',
      quotaEnds: 'ends {date}',
      quotaNone: 'This account has no quota packs.',
      quotaEnterprise: 'This is an enterprise account — add the console login below to see your quota.',
      quotaEnterpriseHint: 'Your quota is metered on the company account (tenant {tenant}), which the IDE-facing API cannot see; only the enterprise console knows it. Just add the e-mail and password you sign in to the console with.',
      console: 'Enterprise console account',
      consoleHint: 'The account you sign in to the enterprise console with (console.enterprise.trae.cn on the public edition). The password is kept in dsh\'s credential store, never in a config file. SSO-only companies cannot use this yet.',
      consoleEmail: 'E-mail',
      consolePassword: 'Password',
      consoleSet: 'Saved',
      consoleUnset: 'Not set',
      consoleSaveFailed: 'Not saved: ',
      consoleSettled: 'Connected to the console; quota is reading fine. Use Change on the right to switch accounts.',
      consoleEdit: 'Change',
      credentialsEdit: 'Edit',
      cancel: 'Cancel',
      collapsedReady: 'Connected · {n} models',
      collapsedQuota: '{percent} left',
      consoleCollapse: 'Collapse',
      deployment: 'Deployment',
      deploymentSaas: 'Public enterprise',
      deploymentPrivate: 'Private deployment',
      deploymentHost: 'API host',
      deploymentHostHint: 'Leave empty for the public enterprise edition. A private deployment fills in its own address: iCubeHostInfo.apiHost in the Trae client\'s storage.json. Saving reloads the plugin, which exchanges the token and fetches the models again on the new host.',
      deploymentConsole: 'Console host',
      deploymentConsoleHint: 'Quota and account details are read here. Empty: a private deployment follows the API host above, the public edition uses console.enterprise.trae.cn. Only needed when it differs from the API host (iCubeHostInfo.consoleHost).',
      deploymentInvalid: 'Not an http(s) address',
      deploymentSaveFailed: 'Deployment not saved: ',
      deploymentReadOnly: 'This dsh cannot change the deployment from here; edit the profile\'s cordis.patch.yml instead (- id: trae2api / config: { host: … }).',
      quotaModels: 'Usage by model ({n})',
      quotaNoneHint: 'Asked {source}: this account has no quota packs at all. If the Trae site does show quota for you, the plugin is asking the wrong place — worth reporting.',
      quotaUnknown: 'Trae answered in a quota format this plugin does not recognise. The raw answer, for a bug report:',
      quotaFailed: 'Quota check failed: ',
      quotaChip: 'Trae {percent} left',
      quotaChipPack: '{name}: {detail}',
      quotaChipTotal: 'Total: {detail}',
      quotaChipHint: 'Click to refresh',
      sessionTabTitle: 'Trae',
      sessionIdsTitle: 'Session ids',
      shareTitle: 'Share this session',
      shareLead: 'Each turn shows on its own, with the thinking and tool calls behind every answer. No model runs.',
      shareStatTurns: '{n} turn(s)',
      shareStatSteps: '{n} tool step(s)',
      shareNoTurnYet: 'Finish one Trae turn after the plugin starts, then share it here.',
      shareAction: 'Create share link',
      shareActionAgain: 'Create another',
      shareBusy: 'Creating…',
      shareReplay: 'Replay each turn instead ({n} model calls)',
      shareReplayHint: 'Replaying sends every question to Trae again; the answers on the page are Trae\'s new ones, not this session\'s.',
      shareReplayConfirm: 'Replay',
      shareReplayCancel: 'Cancel',
      sharePublicNote: 'Anyone with the link can read the whole conversation without signing in, for a year.',
      shareDropped: 'Only the latest {turns} turn(s) went out: a share holds at most 50, so {dropped} older one(s) were left off.',
      shareCallsNote: '{n} model call(s)',
      shareOpen: 'Open',
      shareCopy: 'Copy link',
      shareCopied: 'Copied',
      shareCopyFailed: 'Copy failed',
      shareExpires: 'Valid until {date}',
      shareCreated: 'Created {date}',
      shareFilesTitle: 'Share a file it produced',
      shareFilesLead: 'Publish a Markdown or HTML file this session wrote as a web page. Images and styles it references in its own folder go along; Markdown is laid out as a page. Sharing the same file again keeps the link and updates the page.',
      shareFilesEmpty: 'This session has not written a .md / .html file yet. You can also enter a file\'s absolute path below.',
      shareFileAction: 'Share',
      shareFileUpdate: 'Update',
      shareFileBusy: 'Uploading…',
      shareFileOther: 'Another file',
      shareFilePlaceholder: '/absolute/path/report.html or notes.md',
      shareFileCount: '{n} file(s)',
      shareFileCardAction: 'Share',
      shareFileCardTitle: 'Publish as a web page link (anyone with the link can open it)',
      shareFileCardBusy: 'Sharing…',
      shareFileCardRetry: 'Retry share',
      shareFileInline: 'Share as a page',
      shareMineTitle: 'My shares',
      shareMineRefresh: 'Refresh',
      shareMineLoading: 'Loading…',
      shareMineEmpty: 'No shares yet. The first one you create shows up here.',
      shareUntitled: '(untitled)',
      shareStateActive: 'Public',
      shareStateDisabled: 'Closed',
      shareStateAuditing: 'In review',
      shareClose: 'Close link (opening it says it is closed)',
      shareReopen: 'Make public again',
      shareDelete: 'Delete (cannot be undone)',
      shareDeleteConfirm: 'Delete',
      sessionTabNotTrae: 'This session is not on a Trae model right now; the rows below are from its last Trae turn.',
      sessionIdRow: 'Session id',
      sessionIdRowHint: 'The dsh-side id; this plugin keys everything by it.',
      sessionUpstreamRow: 'Upstream chat',
      sessionUpstreamRowHint: 'Upstream opens one chat per session, model and thinking level — this id cannot be guessed.',
      sessionUpstreamRowOn: 'Last turn ran on: {model}',
      sessionDebugRow: 'Support line',
      sessionDebugRowHint: 'The format Trae\'s own client hands to support; fields the raw endpoint lacks keep their no_* placeholder.',
      sessionNoTurn: 'This session has not run a turn yet',
      sessionCopy: 'Copy',
      sessionCopied: 'Copied',
      sessionCopyFailedShort: 'Copy failed',
      switchNotice: 'Model/level changed · new chat next turn',
      switchNoticeHint: 'Upstream binds a chat to the model it started on: after a model or thinking-level switch, the next turn runs in a new upstream chat. None of the previous model\'s server-side state or prompt cache carries over, so that turn pays full prompt price; switching back to the earlier model and level returns to its own chat.',
      switchCardHint: 'Switching model or thinking level starts a new upstream chat on the next turn (prompt cache starts over) — upstream does not honour a model switch inside one chat.',
      choicesDismiss: 'Dismiss',
      choicesEyebrow: 'Next step',
      choicesOther: 'Something else',
      choicesOtherPlaceholder: 'Say what you want instead — Enter to send',
      choicesSend: 'Send',
      choicesSubagentOn: 'In a subagent',
      choicesSubagentOff: 'In this session',
      choicesSubagentHint: 'Pick answers, then send them together: each task goes to a subagent, stays out of this session\'s context and reports back when done.',
      choicesInlineHint: 'Pick answers, then send them together; they are done in this session, right here.',
      choicesSubagentToggle: 'Switch who does it: a subagent or this session',
      choicesPicked: 'On "{question}": {reply}',
      choicesSubagentTask: 'Hand the task below to a subagent: delegate it with the subagent tool instead of doing it in this session, and tell me what it found and which files it changed once the child is done.\n\n{context}Task: {task}',
      choicesSubagentTasks: 'Hand each task below to its own subagent: delegate each with the subagent tool (independent ones may run at the same time) instead of doing them in this session, and tell me what each found and which files it changed once they are done.\n\n{tasks}',
      choicesSubagentItem: 'Task: {task}',
      choicesSubagentContext: 'Context: the question left open by your last answer was "{question}".',
      choicesPickedCount: '{n}/{total} picked',
      choicesExtraPlaceholder: 'Add a note (optional) — Enter to send',
      choicesExtra: 'Also: {text}',
      choicesSubagentExtra: 'Also (pass this on when delegating): {text}',
      choicesEnabled: 'Next-step cards',
      choicesEnabledOn: 'On',
      choicesEnabledOff: 'Off',
      choicesEnabledHint: 'Cards above the composer once an answer ends. Off offers none and skips the side request that writes them. Saved, it applies from the next turn.',
      choicesDefault: 'Who does a next-step card by default',
      choicesDefaultHint: 'Where the tasks sent from next-step cards go by default. The line under the cards can still switch a single round. Saved, it applies from the next round of cards.',
      choicesFold: 'Collapse',
      choicesFoldHint: 'Fold the next-step cards into one line; later rounds stay folded too',
      choicesUnfold: 'Expand',
      choicesFoldedCount: '{n} cards',
    }

    /** Minimal uSES-compatible snapshot store — the shape slot `hooks` bind to. */
    function createStore(initial) {
      let snapshot = initial
      const listeners = new Set()
      return {
        getSnapshot: () => snapshot,
        subscribe: (listener) => { listeners.add(listener); return () => { listeners.delete(listener) } },
        set: (next) => { snapshot = next; for (const listener of [...listeners]) listener() },
      }
    }

    /**
     * A translate for text read outside a slot component — the tab's own title,
     * which the tab system asks for rather than rendering through a component.
     * The host binds the namespace to the active locale; where it cannot, the
     * shipped dictionary answers so the tab still has a name.
     */
    function bindLocale(ctx) {
      try {
        const bound = ctx.locale?.bind?.(NS)
        if (typeof bound === 'function') return bound
      } catch { /* fall through to the shipped dictionary */ }
      return key => zh[key] ?? en[key] ?? key
    }

    /** Remaining quota, shared by the settings card and the composer chip. */
    class QuotaController {
      constructor() {
        this.store = createStore({ phase: 'idle', value: null, error: '', at: 0 })
        this.generation = 0
      }

      /**
       * Read the quota from the host. Without `force` a read younger than a
       * minute (or one in flight) is reused; `force` also skips the host's cache.
       */
      async load(force) {
        const current = this.store.getSnapshot()
        if (!force && (current.phase === 'loading' || Date.now() - current.at < 60_000)) return
        const generation = ++this.generation
        this.store.set({ ...current, phase: 'loading' })
        let next
        try {
          // Page-relative, like the official clients' `api/...` routes, so a
          // prefixed mount and the Desktop page both resolve it.
          const response = await fetch(`${QUOTA_ROUTE.slice(1)}${force ? '?refresh=1' : ''}`, { headers: { accept: 'application/json' } })
          if (!response.ok) throw new Error(`HTTP ${response.status}`)
          const body = await response.json()
          next = body && body.ok === true
            ? { phase: 'ready', value: body.value, error: '', at: Date.now() }
            : { phase: 'error', value: current.value, error: String(body?.error ?? 'unknown error'), at: Date.now() }
        } catch (error) {
          next = { phase: 'error', value: current.value, error: error instanceof Error ? error.message : String(error), at: Date.now() }
        }
        if (generation === this.generation) this.store.set(next)
      }
    }

    /** A session without cards: before its first answer, while a turn runs, after a pick. */
    const NO_CHOICES = Object.freeze({ id: '', cards: [], dismissed: [], subagent: false })

    /** Where the cards' folded / open state outlives the page. */
    const FOLDED_KEY = `${PACKAGE}:choices-folded`

    function readFolded() {
      try { return window.localStorage?.getItem(FOLDED_KEY) === '1' } catch { return false }
    }

    /**
     * Next-step cards per session, the browser end of src/trae/suggest.ts.
     * A session's snapshot is `{ id, cards, dismissed, subagent }`: the
     * suggestion's id, its cards (`{ question, choices: [{ label, reply }] }`),
     * the indexes of cards closed without an answer, and whether the host asks
     * for a pressed button to go to a subagent (config `suggestSubagent`).
     * Kept for the page's lifetime, so switching back to a session shows what
     * it had.
     *
     * Whether the cards are folded to one line is not a property of one round
     * but the user's choice: one store for every session, kept across reloads.
     */
    class SuggestionController {
      constructor() {
        this.stores = new Map()
        this.folded = createStore(readFolded())
      }

      /** Fold every session's cards to one line, or open them again. */
      fold(folded) {
        this.folded.set(folded)
        try { window.localStorage?.setItem(FOLDED_KEY, folded ? '1' : '0') } catch {}
      }

      storeFor(sessionId) {
        let store = this.stores.get(sessionId)
        if (!store) {
          store = createStore(NO_CHOICES)
          this.stores.set(sessionId, store)
        }
        return store
      }

      /** A turn is running: whatever was offered is stale. */
      clear(sessionId) {
        this.storeFor(sessionId).set(NO_CHOICES)
      }

      /** Read the session's cards, waiting up to `waitMs` for ones still being generated. Returns a canceller. */
      load(sessionId, waitMs) {
        const abort = new AbortController()
        fetch(`${SUGGESTION_ROUTE.slice(1)}?session=${encodeURIComponent(sessionId)}&wait=${waitMs}`, {
          headers: { accept: 'application/json' }, signal: abort.signal,
        })
          .then(response => response.ok ? response.json() : null)
          .then((body) => {
            if (abort.signal.aborted) return
            const value = body?.ok ? body.value : null
            const store = this.storeFor(sessionId)
            if (!value || !Array.isArray(value.cards) || value.cards.length === 0) store.set(NO_CHOICES)
            // Read again, the same suggestion keeps the cards already closed or answered.
            else if (store.getSnapshot().id !== value.id) {
              store.set({ id: value.id, cards: value.cards, dismissed: [], subagent: value.subagent === true })
            }
          })
          .catch(() => {})
        return () => { abort.abort() }
      }

      /** Card `card` closed without an answer. */
      dismiss(sessionId, card) {
        const store = this.storeFor(sessionId)
        const current = store.getSnapshot()
        if (!current.dismissed.includes(card)) store.set({ ...current, dismissed: [...current.dismissed, card] })
      }

      /** The user answered: every card is done, and the same suggestion read again stays done. */
      close(sessionId) {
        const store = this.storeFor(sessionId)
        store.set({ ...store.getSnapshot(), cards: [], dismissed: [] })
      }
    }

    function formatAmount(n, dollars) {
      const text = new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(n)
      return dollars ? `$${text}` : text
    }

    /** Remaining share of the limit in percent, or null when there is no finite limit. */
    function remainingPercent(value) {
      if (!value || value.limit === null || value.remaining === null || !(value.limit > 0)) return null
      return Math.max(0, Math.min(100, (value.remaining / value.limit) * 100))
    }

    /** 17114388 -> "17.1M", so a model row stays one line. */
    function formatTokens(n) {
      if (n >= 1e9) return `${(n / 1e9).toFixed(1)}B`
      if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M`
      if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`
      return String(n)
    }

    function formatPercent(p) {
      return `${p >= 10 ? Math.round(p) : Math.round(p * 10) / 10}%`
    }

    function formatDate(ms) {
      return new Date(ms).toLocaleDateString()
    }

    /** "1,234 / 2,000 left (62%)" for a quota with a finite limit. */
    function remainingLine(t, value) {
      return t('quotaRemaining')
        .replace('{remaining}', formatAmount(value.remaining, value.dollars))
        .replace('{limit}', formatAmount(value.limit, value.dollars))
        .replace('{percent}', formatPercent(remainingPercent(value) ?? 0))
    }

    /**
     * What is left of one allowance, however that allowance is shaped: a
     * finite limit reads as the usual remaining line, an unlimited pack says
     * so, and a pack with no limit of this kind (limit 0) can only report
     * what it has spent.
     */
    function packDetail(t, pack, dollars) {
      if (pack.limit === null) return t('quotaUnlimited')
      if (remainingPercent(pack) === null) return t('quotaUsed').replace('{used}', formatAmount(pack.used, dollars))
      return remainingLine(t, { ...pack, dollars })
    }

    /** Settings form + credential + connection status for one card. */
    class TraeCardController {
      constructor(scope, ctx, quota) {
        this.scope = scope
        this.ctx = ctx
        this.quota = quota
        this.credential = { ref: '', configured: false, writable: true }
        this.consoleCredential = { ref: '', configured: false, writable: true }
        this.consoleEmailCredential = { ref: '', configured: false, writable: true }
        /** Last credential-write failure, shown under the fields. */
        this.credentialError = ''
        /**
         * The deployment's addresses as the host serves them (`phase: 'ready'`
         * once read). Not settings-form fields: the form only writes volatile
         * ones, and these reload the plugin, so they go through the host's own
         * route and are staged here instead.
         */
        this.deployment = { phase: 'idle' }
        /** Typed, unsaved deployment text, by field. */
        this.deploymentDrafts = new Map()
        this.deploymentSaving = false
        /** Why the last deployment save did not land (e.g. a higher layer pins the row). */
        this.deploymentError = ''
        this.status = { phase: 'idle', models: [], message: '' }
        this.statusGeneration = 0
        this.form = new P.SettingsFormModel(
          scope,
          [SUGGEST_SPEC, SUBAGENT_SPEC],
          [
            { field: TOKEN_FIELD, write: text => this.writeToken(text) },
            { field: EMAIL_FIELD, write: text => this.writeSecret('consoleEmailCredential', this.consoleEmailRef(), text) },
            { field: CONSOLE_PASSWORD_FIELD, write: text => this.writeSecret('consoleCredential', this.consoleRef(), text) },
          ],
        )
        this.store = this.form.bind(() => this.projection())
        this.unsubscribe = scope.subscribe(() => { void this.readCredential() })
        void this.readCredential()
        void this.readDeployment()
      }

      projection() {
        const shell = this.form.shell()
        const deployment = this.deploymentView()
        return {
          ...shell,
          // One Save covers both: the form's fields and the deployment drafts.
          dirty: Boolean(shell.dirty) || deployment.dirty,
          invalid: Boolean(shell.invalid) || deployment.invalid,
          saving: Boolean(shell.saving) || this.deploymentSaving,
          deployment,
          token: this.form.field(TOKEN_FIELD),
          tokenConfigured: this.credential.configured,
          tokenWritable: this.credential.writable,
          email: this.form.field(EMAIL_FIELD),
          emailConfigured: this.consoleEmailCredential.configured,
          emailWritable: this.consoleEmailCredential.writable,
          consolePassword: this.form.field(CONSOLE_PASSWORD_FIELD),
          consoleConfigured: this.consoleCredential.configured,
          consoleWritable: this.consoleCredential.writable,
          suggest: this.form.field(SUGGEST_FIELD),
          delegate: this.form.field(SUBAGENT_FIELD),
          credentialError: this.credentialError,
          status: this.status,
        }
      }

      tokenRef() {
        const declared = this.scope.getSnapshot().value?.patEnv
        return typeof declared === 'string' && declared.length > 0 ? declared : DEFAULT_TOKEN_REF
      }

      consoleRef() {
        const declared = this.scope.getSnapshot().value?.consolePasswordEnv
        return typeof declared === 'string' && declared.length > 0 ? declared : DEFAULT_CONSOLE_PASSWORD_REF
      }

      consoleEmailRef() {
        const declared = this.scope.getSnapshot().value?.consoleEmailEnv
        return typeof declared === 'string' && declared.length > 0 ? declared : DEFAULT_CONSOLE_EMAIL_REF
      }

      /** The three credential slots this card owns: [state key, reference]. */
      slots() {
        return [
          ['credential', this.tokenRef()],
          ['consoleEmailCredential', this.consoleEmailRef()],
          ['consoleCredential', this.consoleRef()],
        ]
      }

      async readCredential() {
        const slots = this.slots()
        let changed = false
        for (const [key, ref] of slots) {
          if (ref === this[key].ref) continue
          this[key] = { ref, configured: false, writable: true }
          changed = true
        }
        if (changed) this.store.set(this.projection())
        let response
        try { response = await this.ctx.remote.credentials.describe(slots.map(([, ref]) => ref)) } catch { return }
        const current = this.slots()
        if (!response.ok || current.some(([key, ref], i) => key !== slots[i][0] || ref !== slots[i][1])) return
        changed = false
        for (const [key, ref] of slots) {
          const view = response.value[ref]
          const next = { ref, configured: view?.configured ?? false, writable: view?.writable ?? true }
          if (next.configured === this[key].configured && next.writable === this[key].writable) continue
          this[key] = next
          changed = true
        }
        if (changed) this.store.set(this.projection())
      }

      refreshCredential(ref) {
        if (this.slots().some(([, name]) => name === ref)) void this.readCredential()
      }

      async writeToken(value) {
        const ok = await this.writeSecret('credential', this.tokenRef(), value)
        // The host drops its cached JWT when the PAT changes; check right away.
        if (ok) setTimeout(() => { void this.checkStatus() }, 300)
        return ok
      }

      /**
       * Write one credential and report whether it landed. The form only knows
       * "saved" or "failed", so the reason is kept here and shown by the card —
       * otherwise a rejected write reads as an unexplained failure.
       */
      async writeSecret(key, ref, value) {
        try {
          const response = await this.ctx.remote.credentials.set(ref, value)
          if (response && response.ok === false) {
            this.credentialError = `${ref}: ${response.error?.message ?? String(response.error)}`
            this.store.set(this.projection())
            return false
          }
        } catch (error) {
          this.credentialError = `${ref}: ${error instanceof Error ? error.message : String(error)}`
          this.store.set(this.projection())
          return false
        }
        this.credentialError = ''
        await this.readCredential()
        setTimeout(() => { void this.quota.load(true) }, 300)
        return this[key].configured
      }

      /**
       * A deployment field's saved text: the host's value, blank where that
       * is the default — the API host's built-in one, or a console host left
       * to follow.
       */
      savedDeploymentText(field) {
        const d = this.deployment
        if (d.phase !== 'ready') return ''
        if (field === 'host') return d.host && d.host !== d.defaults?.host ? d.host : ''
        return d.consoleHost ?? ''
      }

      /** The deployment section's state: staged text over what the host serves. */
      deploymentView() {
        const d = this.deployment
        const ready = d.phase === 'ready'
        const field = (name) => {
          const saved = this.savedDeploymentText(name)
          const text = this.deploymentDrafts.has(name) ? this.deploymentDrafts.get(name) : saved
          const value = normalizeOrigin(text)
          return { text, invalid: value === undefined, dirty: this.deploymentDrafts.has(name) && value !== normalizeOrigin(saved) }
        }
        const host = field('host')
        const consoleHost = field('consoleHost')
        const defaults = d.defaults ?? { host: '', consoleHost: '' }
        // What an empty console field resolves to, given the API host as typed.
        const typedHost = normalizeOrigin(host.text)
        return {
          ready,
          writable: ready && d.writable !== false,
          custom: ready && d.host !== defaults.host,
          effective: ready ? d.host : '',
          host,
          consoleHost,
          hostPlaceholder: defaults.host,
          consolePlaceholder: typedHost && typedHost !== defaults.host ? typedHost : defaults.consoleHost,
          dirty: host.dirty || consoleHost.dirty,
          invalid: host.invalid || consoleHost.invalid,
          error: this.deploymentError,
        }
      }

      /**
       * Read the addresses from the host. After a save the host plugin is
       * reloading, so the read is retried until the new instance answers.
       */
      async readDeployment(attempts = 1) {
        for (let i = 0; i < attempts; i++) {
          if (i > 0) await new Promise(resolve => setTimeout(resolve, DEPLOYMENT_READBACK.intervalMs))
          let body
          try {
            // Page-relative, like the other host routes.
            const response = await fetch(DEPLOYMENT_ROUTE.slice(1), { headers: { accept: 'application/json' } })
            body = response.ok ? await response.json() : undefined
          } catch { body = undefined }
          if (body?.ok === true && body.value) {
            this.deployment = { phase: 'ready', ...body.value }
            this.store.set(this.projection())
            return true
          }
        }
        return false
      }

      editDeployment(field, text) {
        if (!DEPLOYMENT_FIELDS.includes(field)) return
        this.deploymentDrafts.set(field, text)
        this.deploymentError = ''
        this.store.set(this.projection())
      }

      discardDeployment() {
        if (this.deploymentDrafts.size === 0 && !this.deploymentError) return
        this.deploymentDrafts.clear()
        this.deploymentError = ''
        this.store.set(this.projection())
      }

      /**
       * Write the staged addresses through the host route and report whether
       * they landed. A refusal — a home patch or command-line overlay pinning
       * the row, a dsh without a config editor — is kept and shown in the
       * section, with the drafts, instead of failing silently.
       */
      async saveDeployment() {
        const changes = {}
        for (const [field, text] of this.deploymentDrafts) {
          const value = normalizeOrigin(text)
          if (value === undefined) return false
          if (value !== normalizeOrigin(this.savedDeploymentText(field))) changes[field] = value
        }
        if (Object.keys(changes).length === 0) {
          this.discardDeployment()
          return true
        }
        this.deploymentSaving = true
        this.deploymentError = ''
        this.store.set(this.projection())
        let landed = false
        try {
          const response = await fetch(DEPLOYMENT_ROUTE.slice(1), {
            method: 'POST',
            headers: { 'content-type': 'application/json', accept: 'application/json' },
            body: JSON.stringify(changes),
          })
          let body
          try { body = await response.json() } catch { body = undefined }
          if (body?.ok === true) landed = true
          else this.deploymentError = String(body?.error ?? `HTTP ${response.status}`)
        } catch (error) {
          this.deploymentError = error instanceof Error ? error.message : String(error)
        }
        if (landed) {
          // The host plugin reloaded on the new address: read it back from
          // the new instance. Should it not answer in time, show what was
          // written rather than the old addresses.
          if (!(await this.readDeployment(DEPLOYMENT_READBACK.attempts)) && this.deployment.phase === 'ready') {
            const next = { ...this.deployment }
            if ('host' in changes) next.host = changes.host || next.defaults?.host || ''
            if ('consoleHost' in changes) next.consoleHost = changes.consoleHost
            this.deployment = next
          }
          this.deploymentDrafts.clear()
        }
        this.deploymentSaving = false
        this.store.set(this.projection())
        if (landed) {
          // A new host is a new JWT, catalog and quota: ask again right away.
          void this.checkStatus()
          void this.quota.load(true)
        }
        return landed
      }

      /** One Save: the form's own fields first (no reload), then the deployment (reloads the host plugin). */
      async save(actions) {
        if (typeof this.form.save === 'function') await this.form.save()
        else actions.save?.()
        await this.saveDeployment()
        setTimeout(() => { void this.checkStatus() }, 800)
      }

      /** Ask the host's model catalog — the same source as the composer picker. */
      async checkStatus() {
        const generation = ++this.statusGeneration
        this.status = { phase: 'checking', models: this.status.models, message: '' }
        this.store.set(this.projection())
        let next
        try {
          const response = await this.ctx.remote.session.modelCatalog()
          if (!response.ok) {
            next = { phase: 'error', models: [], message: response.error?.message ?? String(response.error) }
          } else {
            const catalog = response.value
            const group = catalog.groups.find(g => g.id === PROVIDER)
            const failure = (catalog.failures ?? []).find(f => f.id === PROVIDER)
            if (group) next = { phase: 'ready', models: group.models.map(m => m.name || m.id), message: '' }
            else if (failure) next = { phase: 'error', models: [], message: failure.message }
            else next = { phase: 'empty', models: [], message: '' }
          }
        } catch (error) {
          next = { phase: 'error', models: [], message: error instanceof Error ? error.message : String(error) }
        }
        if (generation !== this.statusGeneration) return
        this.status = next
        this.store.set(this.projection())
      }

      inject() {
        const actions = this.form.actions()
        return {
          hooks: { traeCard: this.store, traeQuota: this.quota.store },
          ...actions,
          save: () => { void this.save(actions) },
          discard: () => { actions.discard?.(); this.discardDeployment() },
          editDeployment: (field, text) => { this.editDeployment(field, text) },
          checkStatus: () => { void this.checkStatus() },
          refreshQuota: (force) => { void this.quota.load(force) },
        }
      }

      dispose() { this.unsubscribe(); this.form.dispose() }
    }

    function StatusBlock(props) {
      const { t, status } = props
      const React_ = React
      React_.useEffect(() => { if (status.phase === 'idle') props.checkStatus() }, [])
      const state = status.phase === 'ready' ? 'done'
        : status.phase === 'checking' || status.phase === 'idle' ? 'ongoing'
          : status.phase === 'empty' ? 'warning' : 'error'
      const line = status.phase === 'ready' ? t('ready').replace('{n}', String(status.models.length))
        : status.phase === 'checking' || status.phase === 'idle' ? t('checking')
          : status.phase === 'empty' ? t('empty') : `${t('failed')}：`
      const muted = { color: 'var(--dsw-alias-label-secondary)', fontSize: 'var(--dsw-font-xs-13, 13px)' }
      return h('div', { style: { display: 'flex', flexDirection: 'column', gap: 8, marginTop: 16 } },
        h('div', { style: { display: 'flex', alignItems: 'center', gap: 8, fontWeight: 600 } },
          t('status'),
          h('span', { style: { flex: 1 } }),
          h(P.Button, { variant: 'ghost', size: 'sm', type: 'button', disabled: status.phase === 'checking', onClick: () => props.checkStatus() }, t('refresh')),
        ),
        h('div', { style: { display: 'flex', alignItems: 'flex-start', gap: 8 } },
          h('span', { style: { paddingTop: 5 } }, h(P.StateDot, { state })),
          h('span', { style: { color: 'var(--dsw-alias-label-primary)' } }, line),
        ),
        status.phase === 'error' && status.message
          ? h('pre', {
            style: {
              ...muted, margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', maxHeight: 180, overflow: 'auto',
              padding: 8, borderRadius: 'var(--dsw-radius-sm, 6px)', background: 'var(--dsw-alias-bg-layer-1)',
            },
          }, status.message)
          : null,
        // Switching the picker mid-conversation is not free: say so where the
        // picker is first mentioned, so the composer notice later is a reminder
        // rather than a surprise.
        status.phase === 'ready' ? h('span', { style: muted }, t('switchCardHint')) : null,
        // 24 names is a wall of text in a settings card: keep it one line,
        // openable when someone actually wants to read it.
        status.phase === 'ready' && status.models.length > 0
          ? h('details', { style: muted },
            h('summary', { style: { cursor: 'pointer' } }, t('models').replace('{n}', String(status.models.length))),
            h('div', { style: { marginTop: 4 } }, status.models.join('、')),
          )
          : null,
      )
    }

    /**
     * How much of an allowance is spent, as a colour: comfortable, getting
     * tight, nearly gone. The bands are on the spent share, so a bar that
     * grows to the right also warms up as it goes.
     */
    const TONE_COLOR = {
      ok: 'var(--dsw-alias-state-success-primary)',
      warn: 'var(--dsw-alias-state-warn-primary)',
      low: 'var(--dsw-alias-state-error-primary)',
    }

    /** Composer room is scarce: the chip's bar reads at a glance and no wider. */
    const QUOTA_BAR_WIDTH = 34

    function meterTone(spent) {
      if (spent >= 85) return 'low'
      if (spent >= 60) return 'warn'
      return 'ok'
    }

    /**
     * One allowance: its name, what is left of it, and a bar that fills from
     * the left with what has been spent.
     */
    function QuotaMeter(props) {
      const { t, pack, dollars } = props
      const muted = { color: 'var(--dsw-alias-label-secondary)', fontSize: 'var(--dsw-font-xs-13, 13px)' }
      const unlimited = pack.limit === null
      const spent = unlimited || !(pack.limit > 0) ? 0 : Math.max(0, Math.min(100, (pack.used / pack.limit) * 100))
      const tone = meterTone(spent)
      return h('div', { style: { display: 'flex', flexDirection: 'column', gap: 4 } },
        h('div', { style: { display: 'flex', alignItems: 'baseline', gap: 8, fontSize: 'var(--dsw-font-xs-13, 13px)' } },
          h('span', { style: { color: 'var(--dsw-alias-label-primary)', flex: 1, minWidth: 0 } }, pack.name),
          h('span', {
            style: {
              ...muted, fontVariantNumeric: 'tabular-nums',
              // The figure picks up the bar's colour once it starts to matter.
              ...tone === 'ok' || unlimited ? {} : { color: TONE_COLOR[tone] },
            },
          }, unlimited ? t('quotaUnlimited')
            : t('quotaPackUsed')
              .replace('{used}', formatAmount(pack.used, dollars))
              .replace('{limit}', formatAmount(pack.limit, dollars))),
        ),
        unlimited ? null : h('div', {
          style: {
            height: 6, borderRadius: 999, overflow: 'hidden',
            background: 'var(--dsw-alias-bg-layer-2)',
          },
        }, h('div', {
          style: {
            width: `${spent}%`, height: '100%', borderRadius: 999,
            transition: 'width 240ms ease, background-color 240ms ease',
            background: TONE_COLOR[tone],
          },
        })),
        pack.endsAt === undefined ? null
          : h('div', { style: muted }, t('quotaEnds').replace('{date}', formatDate(pack.endsAt))),
      )
    }

    function QuotaBlock(props) {
      const { t, quota } = props
      React.useEffect(() => { props.refresh(false) }, [])
      const value = quota.value
      const muted = { color: 'var(--dsw-alias-label-secondary)', fontSize: 'var(--dsw-font-xs-13, 13px)' }
      const pre = text => h('pre', {
        style: {
          ...muted, margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', maxHeight: 180, overflow: 'auto',
          padding: 8, borderRadius: 'var(--dsw-radius-sm, 6px)', background: 'var(--dsw-alias-bg-layer-1)',
        },
      }, text)
      // Prose, not a code block: the mono `pre` is for raw upstream answers.
      const note = text => h('p', { style: { ...muted, margin: 0, lineHeight: 1.5 } }, text)
      const percent = remainingPercent(value)

      let state, line, extra = []
      if (quota.phase === 'error') {
        state = 'error'; line = t('quotaFailed'); extra = [pre(quota.error)]
      } else if (!value) {
        state = 'ongoing'; line = t('quotaLoading')
      } else if (value.raw !== undefined) {
        state = 'warning'; line = t('quotaUnknown'); extra = [pre(value.raw)]
      } else if (value.packs.length === 0 && value.seat === 'enterprise') {
        // A ToB seat's quota sits on the enterprise tenant, which this personal
        // entitlement API never carries: saying "no quota packs" would be wrong.
        state = 'warning'; line = t('quotaEnterprise')
        extra = [note(t('quotaEnterpriseHint').replace('{tenant}', value.tenant || '—'))]
      } else if (value.packs.length === 0) {
        // Name the endpoint: an account that really has nothing reads the same
        // as one whose quota lives somewhere this plugin does not ask.
        state = 'warning'; line = t('quotaNone')
        if (value.source) extra = [note(t('quotaNoneHint').replace('{source}', value.source))]
      } else {
        state = percent !== null && percent < 10 ? 'warning' : 'done'
        line = value.limit === null ? t('quotaUnlimited') : remainingLine(t, value)
        if (value.endsAt !== undefined) {
          extra.push(h('div', { key: 'ends', style: muted }, t('quotaEnds').replace('{date}', formatDate(value.endsAt))))
        }
        // One meter per pack, each filling left to right with what is spent —
        // a seat allowance and a pay-as-you-go allowance run down separately,
        // and a single combined bar hides which one is nearly gone.
        extra.push(h('div', {
          key: 'meters',
          style: { display: 'flex', flexDirection: 'column', gap: 10, marginTop: 2 },
        }, value.packs.map(pack => h(QuotaMeter, { key: pack.name, t, pack, dollars: value.dollars }))))
        // Only the enterprise console reports per-model figures; fold them away.
        if (value.models && value.models.length > 0) {
          extra.push(h('details', { key: 'models', style: { ...muted, marginTop: 2 } },
            h('summary', { style: { cursor: 'pointer' } }, t('quotaModels').replace('{n}', String(value.models.length))),
            h('div', { style: { marginTop: 6, display: 'flex', flexDirection: 'column', gap: 4 } },
              value.models.map(model => h('div', {
                key: model.name,
                style: { display: 'flex', alignItems: 'baseline', gap: 8 },
              },
              h('span', { style: { flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, model.name),
              h('span', { style: { fontVariantNumeric: 'tabular-nums' } }, `${formatTokens(model.tokens)} tokens`),
              h('span', { style: { fontVariantNumeric: 'tabular-nums', minWidth: 64, textAlign: 'right' } }, formatAmount(model.cost, value.dollars)),
              )),
            ),
          ))
        }
      }

      return h('div', { style: { display: 'flex', flexDirection: 'column', gap: 10, marginTop: 16 } },
        h('div', { style: { display: 'flex', alignItems: 'center', gap: 8, fontWeight: 600 } },
          t('quota'),
          h('span', { style: { flex: 1 } }),
          h(P.Button, { variant: 'ghost', size: 'sm', type: 'button', disabled: quota.phase === 'loading', onClick: () => props.refresh(true) }, t('quotaRefresh')),
        ),
        h('div', { style: { display: 'flex', alignItems: 'flex-start', gap: 8 } },
          h('span', { style: { paddingTop: 5 } }, h(P.StateDot, { state })),
          h('span', {
            style: { color: 'var(--dsw-alias-label-primary)', fontVariantNumeric: 'tabular-nums' },
          }, line),
        ),
        ...extra,
      )
    }

    /**
     * The chip's bar: one segment per allowance with a finite limit, each as
     * wide as that allowance's share of the whole and filled with what is
     * left of it. Two numbers side by side read as a fraction ("0% / 88%"),
     * a bar does not — the drained pack is simply an empty segment.
     */
    function QuotaBar(props) {
      const { packs } = props
      const total = packs.reduce((sum, pack) => sum + pack.limit, 0)
      return h('span', {
        'aria-hidden': 'true',
        style: { display: 'inline-flex', alignItems: 'center', gap: 2, width: QUOTA_BAR_WIDTH, flex: 'none' },
      }, packs.map(pack => {
        const left = remainingPercent(pack) ?? 0
        return h('span', {
          key: pack.name,
          style: {
            // Weighted by the allowance itself: a 600 plan beside a 200 top-up
            // reads as 3:1, so a nearly empty big pack cannot look like a nick.
            flex: `${total > 0 ? pack.limit / total : 1} 1 0`,
            minWidth: 4, height: 6, borderRadius: 999, overflow: 'hidden',
            background: 'var(--dsw-alias-bg-layer-2)',
          },
        }, h('span', {
          style: {
            display: 'block', width: `${left}%`, height: '100%', borderRadius: 999,
            transition: 'width 240ms ease, background-color 240ms ease',
            background: TONE_COLOR[meterTone(100 - left)],
          },
        }))
      }))
    }

    /**
     * Composer chip beside the model picker: a bar of the session's Trae
     * allowances followed by one figure — what is left in total — while the
     * session's model is a Trae one and the quota has a finite limit; nothing
     * otherwise (no error noise in the composer — the card shows those).
     * Clicking re-reads the quota past every cache.
     */
    function QuotaChip(props) {
      const { t } = props
      const provider = props.useTraeModel(snapshot => snapshot?.current?.provider)
      const quota = props.useTraeQuota(snapshot => snapshot)
      const active = provider === PROVIDER
      React.useEffect(() => {
        if (!active) return undefined
        props.refresh(false)
        const timer = setInterval(() => { props.refresh(false) }, QUOTA_POLL_MS)
        return () => { clearInterval(timer) }
      }, [active])
      const value = quota.value
      const percent = remainingPercent(value)
      if (!active || quota.phase === 'error' || !value || value.raw !== undefined || percent === null) return null
      // Several allowances are several numbers: adding a top-up pack to the
      // plan's own quota hides which one is about to run out, so each pack
      // gets its line and the total follows only to explain the chip's figure.
      const details = value.packs.length > 1
        ? [
            ...value.packs.map(pack => t('quotaChipPack')
              .replace('{name}', pack.name)
              .replace('{detail}', packDetail(t, pack, value.dollars))),
            t('quotaChipTotal').replace('{detail}', remainingLine(t, value)),
          ]
        : [remainingLine(t, value), t('quotaUsed').replace('{used}', formatAmount(value.used, value.dollars))]
      if (value.endsAt !== undefined) details.push(t('quotaEnds').replace('{date}', formatDate(value.endsAt)))
      details.push(t('quotaChipHint'))
      // The bar splits in pack order. A pack carrying no quota of this kind
      // (limit 0) has no share to fill and is left out, so one real allowance
      // beside a free empty pack still draws as a single segment.
      const bars = value.packs.filter(pack => remainingPercent(pack) !== null)
      // Same bands as the card's meters, read off what is left rather than
      // spent; a comfortable chip stays quiet grey instead of shouting green.
      // The figure is the total, so its colour follows the total: which pack
      // is nearly gone is the bar's job, and the tooltip spells it out.
      const tone = meterTone(100 - percent)
      const color = tone === 'ok' ? 'var(--dsw-alias-label-secondary)' : TONE_COLOR[tone]
      // The same sentence the chip used to be, split around its figure: the
      // bar takes the figure's place, and the figure follows it.
      const [before, after] = t('quotaChip').split('{percent}')
      const label = t('quotaChip').replace('{percent}', formatPercent(percent))
      // Portaled: the composer row re-measures itself on every mutation in its
      // subtree, and other plugins watch that subtree too, so a bubble mounted
      // in place is re-laid-out (and its fade-in replayed) under the pointer.
      // Under the body it is nobody's child. The bubble is `pre-line` itself,
      // so the lines go in as one plain string.
      return h(P.Tooltip, { label: details.join('\n'), side: 'top', portal: true },
        h('button', {
          type: 'button',
          onClick: () => { props.refresh(true) },
          'aria-label': label,
          style: {
            display: 'inline-flex', alignItems: 'center', gap: 6,
            border: 'none', background: 'transparent', cursor: 'pointer', padding: '2px 6px', borderRadius: 6,
            color, fontSize: 12, lineHeight: '20px', whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums',
            opacity: quota.phase === 'loading' ? 0.6 : 1,
          },
        },
        before.trim() === '' ? null : h('span', { key: 'before' }, before.trim()),
        h(QuotaBar, { key: 'bar', packs: bars.length > 0 ? bars : [{ name: 'total', limit: 1, remaining: percent / 100 }] }),
        h('span', { key: 'figure' }, `${formatPercent(percent)}${after}`),
        ),
      )
    }

    /**
     * Signature of a session's model selection — what a switch changes. The
     * directory's snapshot shape belongs to the host's model picker, so the
     * model and level fields are picked by name and the whole selection is the
     * fallback: an unexpected shape makes the notice quiet, never wrong about
     * which field moved.
     */
    function selectionKey(current) {
      if (!current || typeof current !== 'object') return null
      const named = Object.keys(current).filter(key => /model|effort|reasoning/i.test(key)).sort()
      const fields = named.length > 0 ? named : Object.keys(current).sort()
      try {
        return JSON.stringify(fields.map(key => [key, current[key]]))
      } catch { return null }
    }

    /**
     * Composer notice beside the model picker: the picked model or thinking
     * level just changed, so the next turn runs in a new upstream conversation
     * (the host half derives the id from the variant — see `conversationUuid`
     * in src/trae/wire.ts). Shown for a few seconds, then gone; it says what
     * the switch costs rather than asking for anything.
     */
    function SwitchNotice(props) {
      const { t } = props
      const current = props.useTraeModel(snapshot => snapshot?.current ?? null)
      const key = selectionKey(current)
      const active = current?.provider === PROVIDER
      const [shownAt, setShownAt] = React.useState(0)
      const last = React.useRef(key)
      React.useEffect(() => {
        const previous = last.current
        last.current = key
        // Binding the session to its first model is not a switch, and neither
        // is a selection this plugin cannot read.
        if (!active || !key || !previous || previous === key) return undefined
        setShownAt(Date.now())
        const timer = setTimeout(() => { setShownAt(0) }, SWITCH_NOTICE_MS)
        return () => { clearTimeout(timer) }
      }, [key, active])
      if (!active || !shownAt) return null
      // Portaled for the same reason as the quota chip's bubble.
      return h(P.Tooltip, { label: t('switchNoticeHint'), side: 'top', portal: true },
        h('span', {
          style: {
            padding: '2px 6px', borderRadius: 6, color: 'var(--dsw-alias-label-secondary)',
            fontSize: 12, lineHeight: '20px', whiteSpace: 'nowrap',
          },
        }, t('switchNotice')),
      )
    }

    /**
     * Put `text` on the clipboard, and say whether it landed. The async
     * clipboard is the normal path; a page it is not granted on (an insecure
     * origin, a stricter WebView) falls back to the old selection copy, which
     * needs a real element on the page.
     */
    async function copyText(text) {
      try {
        if (navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(text)
          return true
        }
      } catch { /* denied or unavailable: try the old way */ }
      try {
        const area = document.createElement('textarea')
        area.value = text
        area.setAttribute('readonly', '')
        area.style.cssText = 'position:fixed;top:-1000px;opacity:0'
        document.body.appendChild(area)
        area.select()
        const ok = document.execCommand('copy')
        area.remove()
        return ok === true
      } catch { return false }
    }

    /**
     * Whether the View tab row carries this plugin's tab at all.
     *
     * The row is global — the host builds it from every `conversation.view`
     * registration, with no per-session filter — so the tab is registered only
     * while a session on screen is running a Trae model, and dropped again
     * when the last one goes. The host subscribes to the slot, so the row
     * updates itself; `restoreView` then falls back to Chat if the tab the
     * user was on has just left.
     *
     * Several sessions can be mounted at once (a split view): the tab stays
     * while any of them is on Trae, which is the only answer a global row
     * allows.
     */
    class TabPresence {
      constructor(register) {
        this.register = register
        this.sessions = new Map()
        this.registered = undefined
      }

      set(sessionId, isTrae) {
        if (this.sessions.get(sessionId) === isTrae) return
        this.sessions.set(sessionId, isTrae)
        this.sync()
      }

      drop(sessionId) {
        if (!this.sessions.delete(sessionId)) return
        this.sync()
      }

      sync() {
        const wanted = [...this.sessions.values()].some(Boolean)
        if (wanted === (this.registered !== undefined)) return
        if (wanted) this.registered = this.register()
        else {
          const dispose = this.registered
          this.registered = undefined
          if (typeof dispose === 'function') dispose()
        }
      }

      dispose() {
        this.sessions.clear()
        this.sync()
      }
    }

    /**
     * Renders nothing; it is there to say which sessions are on screen and
     * whether they are on a Trae model, which is what decides whether the View
     * tab is registered at all. It sits beside the composer because that is
     * where this plugin already has a per-session seat that mounts for every
     * session, Trae or not.
     */
    // ---- sharing a file from the conversation itself ------------------------
    //
    // The host closes a turn with its own file cards (dsh-client-ui-deliverables):
    // "edited TEST.md" for a file the turn wrote, and a card per file `present`
    // delivered. A Markdown / HTML file on one of those cards gets a "Share"
    // button that publishes it as a page (src/trae/artifact.ts), right where the
    // file is shown. All entry points share one state per (session, file), so
    // the button, the Trae tab and a second card naming the same file agree.

    /** `${sessionId}\u0000${path}` -> { phase: 'busy' | 'done' | 'error', url?, error? } */
    const fileShares = createStore({})
    /** `${sessionId}:${seq}:${index}` of a delivered file -> its absolute path. */
    const deliveredPaths = createStore({})
    const SHAREABLE = /\.(?:md|markdown|html?)$/i

    function shareKey(sessionId, path) { return `${sessionId}\u0000${path}` }

    function shareFileNow(sessionId, path) {
      const key = shareKey(sessionId, path)
      if (fileShares.getSnapshot()[key]?.phase === 'busy') return
      fileShares.set({ ...fileShares.getSnapshot(), [key]: { phase: 'busy' } })
      fetch(SHARE_ROUTE.slice(1), {
        method: 'POST',
        headers: { 'content-type': 'application/json', accept: 'application/json' },
        body: JSON.stringify({ action: 'artifact', path, ...sessionId ? { session: sessionId } : {} }),
      })
        .then(async (response) => {
          const body = await response.json().catch(() => null)
          if (!body?.ok) throw new Error(body?.error ?? `HTTP ${response.status}`)
          fileShares.set({ ...fileShares.getSnapshot(), [key]: { phase: 'done', url: body.value.url } })
        })
        .catch((cause) => {
          fileShares.set({ ...fileShares.getSnapshot(), [key]: { phase: 'error', error: String(cause?.message ?? cause) } })
        })
    }

    /** A path as the host shows it, made absolute against the session's folder. */
    function absolutePath(cwd, path) {
      if (typeof path !== 'string' || !path) return ''
      if (path.startsWith('/') || /^[A-Za-z]:[\\/]/.test(path)) return path
      if (!cwd) return ''
      return `${cwd.replace(/[/\\]+$/, '')}/${path.replace(/^(?:\.?[/\\])+/, '')}`
    }

    /** The share control for one file: Share → Sharing… → Open · Copy link (or Retry). */
    function FileShareButton(props) {
      const { t, sessionId, path } = props
      const state = props.useFileShares(all => all[shareKey(sessionId, path)])
      const [copied, setCopied] = React.useState('')
      React.useEffect(() => {
        if (!copied) return undefined
        const timer = setTimeout(() => { setCopied('') }, COPIED_MS)
        return () => { clearTimeout(timer) }
      }, [copied])
      const stop = event => { event.stopPropagation() }
      if (state?.phase === 'done') {
        return h('span', { className: 'trae-fs', onClick: stop, onMouseDown: stop },
          h('a', {
            className: 'trae-fs-btn', href: state.url, target: '_blank', rel: 'noreferrer noopener',
            title: state.url, 'aria-label': `${t('shareOpen')} ${state.url}`,
          }, icon(ICON_OPEN, 12), h('span', null, t('shareOpen'))),
          h('button', {
            type: 'button', className: 'trae-fs-btn', 'data-strong': 'true', title: state.url,
            onClick: () => { void copyText(state.url).then((ok) => { setCopied(ok ? 'ok' : 'failed') }) },
          }, icon(copied === 'ok' ? ICON_CHECK : ICON_COPY, 12),
          h('span', null, copied === 'ok' ? t('shareCopied') : copied === 'failed' ? t('shareCopyFailed') : t('shareCopy'))),
        )
      }
      return h('span', { className: 'trae-fs', onClick: stop, onMouseDown: stop },
        h('button', {
          type: 'button', className: 'trae-fs-btn', 'data-error': state?.phase === 'error' ? 'true' : undefined,
          disabled: state?.phase === 'busy',
          title: state?.phase === 'error' ? state.error : t('shareFileCardTitle'),
          'aria-label': `${t('shareFileCardTitle')}: ${path}`,
          onClick: () => { shareFileNow(sessionId, path) },
        }, icon(ICON_SHARE, 12), h('span', null,
          state?.phase === 'busy' ? t('shareFileCardBusy') : state?.phase === 'error' ? t('shareFileCardRetry') : t('shareFileCardAction'))),
      )
    }

    /**
     * One closing turn's Markdown / HTML files, from the host's own per-turn
     * fold (`turn.data.get('deliverables')`: files written successfully, files
     * delivered). Delivered files get their button through the cards' action
     * slot (DeliveredShareAction); a single "edited <file>" card gets one
     * placed on the card itself; whatever has no card to sit on is listed in a
     * line of its own under the cards.
     */
    function TurnFileShare(props) {
      const { t, sessionId } = props
      const anchor = React.useRef(null)
      const cwd = typeof props.useSessions === 'function' ? props.useSessions(state => state?.byId?.[sessionId]?.cwd) : undefined
      const data = props.turn?.data?.get?.('deliverables')
      const delivered = []
      for (const file of data?.presented ?? []) {
        const path = absolutePath(cwd, file.path)
        if (path && SHAREABLE.test(path)) delivered.push({ ...file, path })
      }
      const written = []
      for (const file of data?.produced ?? []) {
        const path = absolutePath(cwd, file.path)
        if (path && SHAREABLE.test(path) && !written.includes(path) && !delivered.some(d => d.path === path)) written.push(path)
      }
      // Tell the delivered cards' action slot which file each one is.
      React.useEffect(() => {
        if (delivered.length === 0) return
        const next = { ...deliveredPaths.getSnapshot() }
        let changed = false
        for (const file of delivered) {
          const key = `${sessionId}:${file.seq}:${file.index}`
          if (next[key] !== file.path) { next[key] = file.path; changed = true }
        }
        if (changed) deliveredPaths.set(next)
      })
      // The single-file "edited" card, once the host has rendered it.
      const [host, setHost] = React.useState(null)
      React.useLayoutEffect(() => {
        if (written.length === 0 || !createPortal) return undefined
        const tail = anchor.current?.closest('[data-turn-tail]')
        if (!tail) return undefined
        let placed = null
        const attach = () => {
          const card = tail.querySelector('[data-changed-files][data-single]')
          const described = card?.querySelector('button[aria-describedby]')
          const pathId = described?.getAttribute('aria-describedby')
          const cardPath = pathId ? document.getElementById(pathId)?.textContent?.trim() : undefined
          if (!card || !cardPath || !written.includes(cardPath)) return
          if (placed?.isConnected && placed.parentElement === card) return
          if (getComputedStyle(card).position === 'static') card.style.position = 'relative'
          const span = document.createElement('span')
          span.className = 'trae-fs-slot'
          span.dataset.path = cardPath
          card.appendChild(span)
          placed = span
          setHost({ element: span, path: cardPath })
        }
        attach()
        const observer = new MutationObserver(attach)
        observer.observe(tail, { childList: true, subtree: true })
        return () => { observer.disconnect(); placed?.remove(); setHost(null) }
      }, [written.join('\n')])

      if (written.length === 0) return delivered.length > 0 ? h('span', { ref: anchor, hidden: true }) : null
      const loose = written.filter(path => path !== host?.path)
      return h(React.Fragment, null,
        host && createPortal(h(FileShareButton, { t, sessionId, path: host.path, useFileShares: props.useFileShares }), host.element),
        loose.length > 0
          ? h('div', { ref: anchor, className: 'trae-fs-row' },
            h('span', { className: 'trae-fs-label' }, icon(ICON_SHARE, 12), t('shareFileInline')),
            ...loose.map(path => h('span', { key: path, className: 'trae-fs-item' },
              h('span', { className: 'trae-fs-name', title: path }, path.split('/').pop()),
              h(FileShareButton, { t, sessionId, path, useFileShares: props.useFileShares }),
            )),
          )
          : h('span', { ref: anchor, hidden: true }),
      )
    }

    /** The share button on a delivered (`present`) file card, through the card's own action slot. */
    function DeliveredShareAction(props) {
      const { t, actionUrl } = props
      let key = ''
      let sessionId = ''
      try {
        const query = new URLSearchParams(String(actionUrl ?? '').split('?')[1] ?? '')
        sessionId = query.get('sessionId') ?? ''
        key = `${sessionId}:${query.get('seq')}:${query.get('index')}`
      } catch { /* not ours to read */ }
      const path = props.useDeliveredPaths(all => all[key])
      if (!path || !SHAREABLE.test(path)) return null
      return h(FileShareButton, { t, sessionId, path, useFileShares: props.useFileShares })
    }

    function SessionWatch(props) {
      const provider = props.useTraeModel(snapshot => snapshot?.current?.provider)
      // Two effects on purpose: the first follows the picked model, and the
      // second runs only on unmount. One effect with a cleanup would drop and
      // re-add the session on every switch, and a tab that leaves and comes
      // back loses the user's place in it.
      React.useEffect(() => { props.watch(provider === PROVIDER) }, [provider])
      React.useEffect(() => () => { props.unwatch() }, [])
      return null
    }

    /**
     * This session's ids, read from the host route: the harness session id, the
     * upstream conversation its last Trae turn ran in, and Trae's own support
     * line. Shared by the tab and the header button that opens it.
     *
     * The upstream conversation follows the picked model and thinking level
     * (wire.ts `conversationUuid`), so a switch is a re-read as much as a
     * finished turn is; `useSession` is used where the host passes it, and
     * where it does not the read still happens on mount, on a switch and on
     * demand.
     */
    function useSessionIds(props, sessionId, selection) {
      const [info, setInfo] = React.useState(null)
      const running = typeof props.useSession === 'function' ? props.useSession(s => s?.running) : undefined
      const key = selectionKey(selection)
      const read = () => {
        if (!sessionId) return undefined
        const abort = new AbortController()
        fetch(`${SESSION_ROUTE.slice(1)}?session=${encodeURIComponent(sessionId)}`, {
          headers: { accept: 'application/json' }, signal: abort.signal,
        })
          .then(response => response.ok ? response.json() : null)
          .then((body) => { if (!abort.signal.aborted) setInfo(body?.ok ? body.value : null) })
          .catch(() => {})
        return () => { abort.abort() }
      }
      React.useEffect(() => read(), [sessionId, key, running])
      return [info, read]
    }

    /**
     * One id in the tab: what it is, the whole value, and a button that copies
     * it. A value the session does not have yet (no turn, so no upstream
     * conversation and no support line) says so instead of offering an empty
     * copy.
     */
    function IdRow(props) {
      const { t, label, hint, value, empty } = props
      const [copied, setCopied] = React.useState('')
      React.useEffect(() => {
        if (!copied) return undefined
        const timer = setTimeout(() => { setCopied('') }, COPIED_MS)
        return () => { clearTimeout(timer) }
      }, [copied])
      const copy = () => {
        // Read again while the write runs: the upstream id and the support line
        // move with every turn.
        props.refresh()
        void copyText(value).then((ok) => { setCopied(ok ? 'ok' : 'failed') })
      }
      return h('div', { className: 'trae-id-row' },
        h('div', { className: 'trae-id-head' },
          h('span', { className: 'trae-id-label' }, label),
          value
            ? h('button', {
              type: 'button', className: 'trae-id-copy',
              onClick: copy,
              'aria-label': `${t('sessionCopy')} ${label}`,
            }, icon(ICON_COPY, 12), h('span', null, copied === 'ok' ? t('sessionCopied') : copied === 'failed' ? t('sessionCopyFailedShort') : t('sessionCopy')))
            : null,
        ),
        value
          ? h('p', { className: 'trae-id-value' }, value)
          : h('p', { className: 'trae-id-empty' }, empty),
        hint ? h('p', { className: 'trae-id-hint' }, hint) : null,
      )
    }

    /**
     * One of the session's own View tabs, beside 对话 / 轨迹 / 上下文: the three
     * ids a Trae bug report or a log search needs, each on its own row with a
     * copy button.
     *
     * A tab rather than a composer chip, because this is read once in a while
     * and read in full — the ids are long, and the support line is a whole
     * line. The tab is only on the row while a session on screen is on a Trae
     * model (TabPresence); in a split view with one Trae session and one on
     * another provider, the other session reads a line saying the last two
     * rows are not about it.
     */
    function SessionTab(props) {
      const { t, sessionId } = props
      const selection = props.useTraeModel(snapshot => snapshot?.current ?? null)
      const [info, refresh] = useSessionIds(props, sessionId, selection)
      const upstream = info?.conversation ?? ''
      // The whole line Trae's own client copies for support, built host-side
      // from what this turn really has (src/trae/debug.ts).
      const support = info?.debug ?? ''
      const variant = info?.effort ? `${info.model} · ${info.effort}` : info?.model ?? ''
      // An outer scroller the full width of the view, and a column inside it
      // as wide as the chat column. The host keeps its column-width drag
      // handle (absolute, z-index 0) just outside that column; content that
      // ran the full width sat under it, and the handle's hover gradient drew
      // across the page.
      return h('div', { className: 'trae-view' }, h('div', { className: 'trae-ids' },
        // The tab row is global, so this session may well be on another
        // provider: say so first, rather than leaving empty rows to explain
        // themselves.
        selection && selection.provider !== PROVIDER
          ? h('p', { className: 'trae-id-note' }, t('sessionTabNotTrae'))
          : null,
        // Handing the conversation out is what this tab is opened for; the
        // ids are for a support ticket and sit underneath.
        h(ShareSection, { t, sessionId, conversation: upstream }),
        h('section', { className: 'trae-card', 'aria-label': t('sessionIdsTitle') },
          h('header', { className: 'trae-card-head' }, h('h3', { className: 'trae-card-title' }, t('sessionIdsTitle'))),
          h(IdRow, {
            t, refresh, key: 'session',
            label: t('sessionIdRow'), hint: t('sessionIdRowHint'), value: sessionId ?? '',
          }),
          h(IdRow, {
            t, refresh, key: 'upstream',
            label: t('sessionUpstreamRow'),
            hint: upstream ? t('sessionUpstreamRowOn').replace('{model}', variant) : t('sessionUpstreamRowHint'),
            value: upstream,
            empty: t('sessionNoTurn'),
          }),
          h(IdRow, {
            t, refresh, key: 'support',
            label: t('sessionDebugRow'), hint: t('sessionDebugRowHint'), value: support,
            empty: t('sessionNoTurn'),
          }),
        ),
      ))
    }

    /**
     * Card and id-row styles, injected once. Colours, radii and the elevation
     * come from the host's design tokens — the same ones its own question
     * dialog uses — so both follow the theme, light or dark. The card column
     * is sized like the host's dock panels (todo, queue) so everything lines
     * up.
     */
    const CHOICES_CSS = `
.trae-view{box-sizing:border-box;flex:1 1 auto;min-height:0;width:100%;height:100%;overflow-x:hidden;overflow-y:auto}
.trae-ids{--trae-tint:color-mix(in srgb,var(--dsw-alias-label-primary) 4%,var(--dsw-alias-bg-base));box-sizing:border-box;display:flex;flex-direction:column;gap:12px;width:100%;max-width:calc(var(--dsh-chat-content-width,720px) + 32px);margin:0 auto;padding:20px 16px 40px;color:var(--dsw-alias-label-primary);font-size:13px;line-height:20px}
.trae-ids *{box-sizing:border-box}
.trae-share{display:flex;flex-direction:column;gap:12px}
.trae-card{display:flex;flex-direction:column;gap:10px;padding:16px 16px 14px;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-lg,12px);background:var(--dsw-alias-bg-base)}
.trae-card[data-primary]{gap:12px;padding:18px 18px 16px;border-color:var(--dsw-alias-border-l2)}
.trae-card-head{display:flex;align-items:center;gap:8px;min-height:24px}
.trae-card-title{margin:0;font-size:14px;font-weight:600;line-height:22px;letter-spacing:.01em}
.trae-card[data-primary] .trae-card-title{font-size:15px}
.trae-card-count{flex:1;color:var(--dsw-alias-label-tertiary);font-size:12px;font-variant-numeric:tabular-nums}
.trae-card-head .trae-card-title:last-child{flex:1}
.trae-card-head .trae-icon-btn{margin-left:auto}
.trae-card-lead{margin:0;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}
.trae-card-note{margin:0;color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px}
.trae-stats{display:flex;flex-wrap:wrap;gap:6px}
.trae-stat{display:inline-flex;align-items:center;height:22px;padding:0 9px;border-radius:999px;background:var(--trae-tint);color:var(--dsw-alias-label-secondary);font-size:11px;font-variant-numeric:tabular-nums}
.trae-actions{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px}
.trae-btn{height:34px;padding:0 16px 0 13px;border:none;border-radius:var(--dsw-radius-md,8px);background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground);font:inherit;font-size:13px;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:7px;transition:background-color .12s}
.trae-btn:hover:not(:disabled){background:var(--dsw-alias-button-primary-hover)}
.trae-btn:disabled{opacity:.4;cursor:default}
.trae-link{padding:0;border:none;background:none;color:var(--dsw-alias-label-tertiary);font:inherit;font-size:12px;line-height:18px;cursor:pointer;text-decoration:underline;text-decoration-color:var(--dsw-alias-border-l3);text-underline-offset:3px}
.trae-link:hover:not(:disabled){color:var(--dsw-alias-label-primary);text-decoration-color:currentColor}
.trae-link:disabled{opacity:.5;cursor:default}
.trae-chip{flex:none;height:26px;padding:0 10px 0 8px;border:.5px solid var(--dsw-alias-border-l3);border-radius:999px;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:12px;line-height:16px;text-decoration:none;cursor:pointer;display:inline-flex;align-items:center;gap:5px}
.trae-chip:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.trae-chip[data-strong]{border-color:transparent;background:var(--dsw-alias-label-primary);color:var(--dsw-alias-bg-base)}
.trae-chip[data-strong]:hover:not(:disabled){background:var(--dsw-alias-label-primary);color:var(--dsw-alias-bg-base);opacity:.88}
.trae-icon-btn{flex:none;width:28px;height:28px;padding:0;border:none;border-radius:var(--dsw-radius-sm,6px);background:transparent;color:var(--dsw-alias-label-tertiary);cursor:pointer;display:grid;place-items:center;text-decoration:none}
.trae-icon-btn:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.trae-icon-btn[data-danger]:hover:not(:disabled){color:var(--dsw-alias-state-error-primary)}
.trae-icon-btn:disabled{opacity:.4;cursor:default}
.trae-callout{display:flex;flex-direction:column;gap:8px;padding:10px 12px;border-radius:var(--dsw-radius-md,8px);background:var(--trae-tint)}
.trae-callout p{margin:0;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}
.trae-error{margin:0;padding:8px 10px;border-radius:var(--dsw-radius-sm,6px);background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 9%,transparent);color:var(--dsw-alias-state-error-primary);font-size:12px;line-height:18px;overflow-wrap:anywhere}
.trae-ticket{position:relative;display:flex;flex-direction:column;border:.5px solid var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-md,10px);background:var(--trae-tint);animation:trae-choice-in .18s ease-out}
.trae-ticket-url{margin:0;padding:14px 16px 13px;font-family:var(--dsw-font-mono,ui-monospace,SFMono-Regular,Menlo,monospace);font-size:12.5px;line-height:20px;overflow-wrap:anywhere;user-select:text}
.trae-ticket-url span{color:var(--dsw-alias-label-tertiary)}
.trae-ticket-url b{font-weight:650;font-size:14px;letter-spacing:.04em;color:var(--dsw-alias-label-primary)}
.trae-ticket-foot{position:relative;display:flex;flex-wrap:wrap;align-items:center;gap:6px 8px;padding:9px 10px 9px 16px;border-top:1px dashed var(--dsw-alias-border-l3)}
.trae-ticket-foot::before,.trae-ticket-foot::after{content:"";position:absolute;top:-8px;width:15px;height:15px;border-radius:50%;background:var(--dsw-alias-bg-base);border:.5px solid var(--dsw-alias-border-l2)}
.trae-ticket-foot::before{left:-8px;clip-path:inset(0 0 0 50%)}
.trae-ticket-foot::after{right:-8px;clip-path:inset(0 50% 0 0)}
.trae-ticket-meta{flex:1 1 150px;min-width:0;color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px;font-variant-numeric:tabular-nums}
.trae-list{display:flex;flex-direction:column;margin:0 -4px;padding:0;list-style:none}
.trae-file{display:flex;flex-direction:column;gap:8px;padding:10px 4px;border-top:.5px solid var(--dsw-alias-border-l4)}
.trae-file:first-child{border-top:none;padding-top:2px}
.trae-file-main{display:flex;align-items:center;gap:10px;min-width:0}
.trae-kind{flex:none;min-width:38px;height:20px;padding:0 6px;border-radius:5px;background:var(--trae-tint);color:var(--dsw-alias-label-secondary);font-family:var(--dsw-font-mono,ui-monospace,SFMono-Regular,Menlo,monospace);font-size:10px;font-weight:600;line-height:20px;text-align:center;letter-spacing:.04em}
.trae-kind[data-kind=html]{color:var(--dsw-alias-state-business-primary)}
.trae-file-text{flex:1;min-width:0;display:flex;flex-direction:column}
.trae-file-name{font-size:13px;font-weight:500;line-height:20px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.trae-file-meta{color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.trae-other{display:flex;flex-direction:column;gap:6px;padding-top:10px;border-top:.5px solid var(--dsw-alias-border-l4)}
.trae-list + .trae-other{margin-top:-2px}
.trae-card-lead + .trae-other{border-top:none;padding-top:0}
.trae-other-label{color:var(--dsw-alias-label-secondary);font-size:12px;font-weight:500}
.trae-other-row{display:flex;align-items:center;gap:8px}
.trae-input{flex:1;min-width:0;height:30px;padding:0 10px;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-md,8px);background:transparent;color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-mono,ui-monospace,SFMono-Regular,Menlo,monospace);font-size:12px;outline:none}
.trae-input:focus{border-color:var(--dsw-alias-state-business-primary)}
.trae-input::placeholder{color:var(--dsw-alias-label-caption,var(--dsw-alias-label-tertiary))}
.trae-chip:disabled{opacity:.4;cursor:default}
.trae-fs{display:inline-flex;align-items:center;gap:6px;font-size:12px;line-height:16px}
.trae-fs-btn{flex:none;height:26px;padding:0 10px 0 8px;border:.5px solid var(--dsw-alias-border-l3);border-radius:999px;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-secondary);font:inherit;font-size:12px;text-decoration:none;cursor:pointer;display:inline-flex;align-items:center;gap:5px;white-space:nowrap}
.trae-fs-btn:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.trae-fs-btn:disabled{opacity:.55;cursor:default}
.trae-fs-btn[data-strong]{border-color:transparent;background:var(--dsw-alias-label-primary);color:var(--dsw-alias-bg-base)}
.trae-fs-btn[data-strong]:hover:not(:disabled){background:var(--dsw-alias-label-primary);color:var(--dsw-alias-bg-base);opacity:.88}
.trae-fs-btn[data-error]{border-color:color-mix(in srgb,var(--dsw-alias-state-error-primary) 45%,transparent);color:var(--dsw-alias-state-error-primary)}
.trae-fs-btn:focus-visible{outline:2px solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:2px}
.trae-fs-slot{position:absolute;top:50%;right:16px;transform:translateY(-50%);z-index:1;display:inline-flex}
.trae-fs-row{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;margin-top:8px;padding:8px 12px;border:.5px solid var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-lg,12px);color:var(--dsw-alias-label-secondary);font-size:12px}
.trae-fs-label{display:inline-flex;align-items:center;gap:5px;color:var(--dsw-alias-label-tertiary)}
.trae-fs-item{display:inline-flex;align-items:center;gap:8px;min-width:0}
.trae-fs-name{max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-primary);font-weight:500}
.trae-item{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:2px 12px;padding:10px 4px;border-top:.5px solid var(--dsw-alias-border-l4)}
.trae-item:first-child{border-top:none;padding-top:2px}
.trae-item-title{display:flex;align-items:center;gap:8px;min-width:0;font-size:13px;font-weight:500;line-height:20px}
.trae-item-name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.trae-dot{flex:none;width:7px;height:7px;border-radius:50%;background:var(--dsw-alias-state-success-primary)}
.trae-item[data-state=disabled] .trae-dot{background:var(--dsw-alias-label-caption,var(--dsw-alias-label-tertiary))}
.trae-item[data-state=auditing] .trae-dot{background:var(--dsw-alias-state-business-primary)}
.trae-item[data-state=disabled] .trae-item-name{color:var(--dsw-alias-label-tertiary)}
.trae-pill{flex:none;padding:0 7px;border-radius:999px;background:var(--dsw-alias-state-success-tertiary,var(--dsw-alias-bg-layer-1));color:var(--dsw-alias-state-success-primary);font-size:10px;font-weight:500;line-height:17px}
.trae-item[data-state=disabled] .trae-pill{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-tertiary)}
.trae-item[data-state=auditing] .trae-pill{background:var(--dsw-alias-state-business-tertiary,var(--dsw-alias-bg-layer-1));color:var(--dsw-alias-state-business-primary)}
.trae-item-meta{grid-column:1;display:flex;flex-wrap:wrap;gap:2px 10px;padding-left:15px;color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px;font-variant-numeric:tabular-nums}
.trae-item-meta code{font-family:var(--dsw-font-mono,ui-monospace,SFMono-Regular,Menlo,monospace);font-size:11px;color:var(--dsw-alias-label-secondary);user-select:all}
.trae-item-actions{grid-column:2;grid-row:1 / span 2;display:flex;align-items:center;gap:2px}
.trae-confirm{height:26px;padding:0 12px;border:none;border-radius:999px;background:var(--dsw-alias-state-error-primary);color:#fff;font:inherit;font-size:12px;font-weight:600;cursor:pointer;margin-right:8px}
.trae-id-row{display:flex;flex-direction:column;gap:3px;padding:8px 0;border-top:.5px solid var(--dsw-alias-border-l4)}
.trae-card-head + .trae-id-row{border-top:none;padding-top:0}
.trae-id-head{display:flex;align-items:center;gap:8px;min-height:22px}
.trae-id-label{flex:1;min-width:0;color:var(--dsw-alias-label-secondary);font-size:12px;font-weight:500;line-height:18px}
.trae-id-copy{flex:none;height:22px;padding:0 8px 0 6px;border:.5px solid var(--dsw-alias-border-l4);border-radius:999px;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:11px;line-height:16px;cursor:pointer;display:inline-flex;align-items:center;gap:4px}
.trae-id-copy:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.trae-id-value{margin:0;font-family:var(--dsw-font-mono,ui-monospace,SFMono-Regular,Menlo,monospace);font-size:12px;line-height:18px;color:var(--dsw-alias-label-primary);overflow-wrap:anywhere;user-select:text}
.trae-id-empty{margin:0;color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}
.trae-id-hint{margin:0;color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px}
.trae-id-note{margin:0;padding:9px 12px;border-radius:var(--dsw-radius-md,8px);background:var(--trae-tint);color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}
.trae-btn:focus-visible,.trae-link:focus-visible,.trae-chip:focus-visible,.trae-icon-btn:focus-visible,.trae-confirm:focus-visible,.trae-id-copy:focus-visible{outline:2px solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:2px}
@media (max-width:520px){.trae-item{grid-template-columns:minmax(0,1fr)}.trae-item-actions{grid-column:1;grid-row:auto;padding-left:11px}}
@media (prefers-reduced-motion:reduce){.trae-ticket{animation:none}.trae-btn{transition:none}}
.trae-choices{box-sizing:border-box;width:calc(100% - 2 * var(--dsh-composer-side-clearance, 0px) - 4 * var(--dsh-composer-dock-inset, 0px));max-width:calc(var(--dsh-composer-card-max-width, 100%) - 4 * var(--dsh-composer-dock-inset, 0px));margin:0 auto;flex:none;display:flex;flex-direction:column;gap:8px}
.trae-choice{--dsw-elevation-stroke-color:var(--dsw-alias-border-l2-darkmode-thin);border-radius:var(--dsw-radius-xl,16px);background:var(--dsw-specific-input-major,var(--dsw-specific-menu));box-shadow:var(--dsw-elevation-panel);color:var(--dsw-alias-label-primary);padding:12px 12px 14px 16px;display:flex;flex-direction:column;gap:10px;animation:trae-choice-in .18s ease-out}
.trae-choice *{box-sizing:border-box}
.trae-choice-head{display:flex;align-items:flex-start;gap:12px}
.trae-choice-heading{flex:1;min-width:0}
.trae-choice-eyebrow{display:flex;align-items:center;gap:4px;margin-bottom:2px;color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px}
.trae-choice-question{margin:0;font-size:14px;font-weight:500;line-height:22px;overflow-wrap:anywhere}
.trae-choice-tag{margin-left:2px;padding:0 6px;border-radius:999px;background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary);font-size:10px;line-height:15px}
.trae-choice-foot{display:flex;align-items:center;flex-wrap:wrap;gap:4px 8px;padding:0 4px;color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px}
.trae-choice-who,.trae-choice-tuck{flex:none;height:20px;padding:0 8px 0 6px;border:.5px solid var(--dsw-alias-border-l4);border-radius:999px;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:11px;line-height:16px;cursor:pointer;display:inline-flex;align-items:center;gap:4px}
.trae-choice-who:hover,.trae-choice-tuck:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.trae-choice-who[aria-pressed="true"]{border-color:transparent;background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.trae-choice-who:focus-visible,.trae-choice-tuck:focus-visible{outline:2px solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:2px}
.trae-choice-note{min-width:0;flex:1}
.trae-choice-fold{width:100%;border:none;font:inherit;text-align:left;cursor:pointer;flex-direction:row;align-items:center;gap:10px;padding:8px 12px 8px 16px}
.trae-choice-fold:focus-visible{outline:2px solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:2px}
.trae-choice-fold .trae-choice-eyebrow{flex:none;margin:0}
.trae-choice-peek{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-secondary);font-size:13px;line-height:20px}
.trae-choice-unfold{flex:none;display:inline-flex;align-items:center;gap:4px;color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px}
.trae-choice-fold:hover .trae-choice-unfold,.trae-choice-fold:hover .trae-choice-peek{color:var(--dsw-alias-label-primary)}
.trae-choice-close{flex:none;width:24px;height:24px;margin:-2px -2px 0 0;padding:0;border:none;border-radius:999px;background:transparent;color:var(--dsw-alias-label-tertiary);cursor:pointer;display:grid;place-items:center}
.trae-choice-close:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.trae-choice-actions{display:flex;flex-wrap:wrap;gap:8px}
.trae-choice-btn{height:30px;max-width:100%;padding:0 12px;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-md,8px);background:transparent;color:var(--dsw-alias-label-primary);font:inherit;font-size:13px;line-height:20px;cursor:pointer;display:inline-flex;align-items:center;gap:6px;transition:background-color .12s,border-color .12s,color .12s}
.trae-choice-btn:hover{background:var(--dsw-alias-interactive-bg-hover)}
.trae-choice-btn[data-primary]{border-color:var(--dsw-alias-border-l2);font-weight:600}
.trae-choice-btn[aria-pressed="true"]{border-color:transparent;background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground)}
.trae-choice-btn[aria-pressed="true"]:hover{background:var(--dsw-alias-button-primary-hover)}
.trae-choice-btn[data-other]{border:1px dashed var(--dsw-alias-border-l4);color:var(--dsw-alias-label-secondary)}
.trae-choice-btn[data-other][aria-expanded="true"]{border-style:solid;border-color:var(--dsw-alias-border-l2);background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.trae-choice-label{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.trae-choice-btn:focus-visible,.trae-choice-close:focus-visible,.trae-choice-send:focus-visible{outline:2px solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:2px}
.trae-choice-other{display:flex;align-items:flex-end;gap:8px;padding:5px 5px 5px 12px;border:.5px solid var(--dsw-alias-border-l4);border-radius:var(--dsw-radius-lg,12px);background:var(--dsw-alias-bg-module-platform);transition:border-color .12s}
.trae-choice-other:focus-within{border-color:var(--dsw-alias-state-business-primary)}
.trae-choice-input{flex:1;min-width:0;max-height:120px;padding:3px 0;resize:none;border:none;outline:none;background:transparent;color:var(--dsw-alias-label-primary);caret-color:var(--dsw-alias-state-business-primary);font:inherit;font-size:14px;line-height:22px}
.trae-choice-input::placeholder{color:var(--dsw-alias-label-caption,var(--dsw-alias-label-tertiary))}
.trae-choice-send{flex:none;width:28px;height:28px;padding:0;border:none;border-radius:999px;background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground);cursor:pointer;display:grid;place-items:center}
.trae-choice-send:hover:not(:disabled){background:var(--dsw-alias-button-primary-hover)}
.trae-choice-send:disabled{opacity:.35;cursor:default}
.trae-choice-compose{gap:8px;padding:10px 12px 12px 16px}
.trae-choice-compose .trae-choice-eyebrow{margin:0}
@keyframes trae-choice-in{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion:reduce){.trae-choice{animation:none}.trae-choice-btn,.trae-choice-other{transition:none}}
`

    /** A 16×16 line icon (or a filled one) in the current text colour. */
    function icon(d, size = 14, filled = false) {
      return h('svg', {
        width: size, height: size, viewBox: '0 0 16 16', 'aria-hidden': true,
        fill: filled ? 'currentColor' : 'none', stroke: filled ? 'none' : 'currentColor',
        strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round',
      }, h('path', { d }))
    }
    const ICON_SPARK = 'M8 1.5 9.4 6.6 14.5 8 9.4 9.4 8 14.5 6.6 9.4 1.5 8 6.6 6.6Z'
    const ICON_CLOSE = 'M4.5 4.5l7 7M11.5 4.5l-7 7'
    const ICON_PEN = 'M10.5 3l2.5 2.5L6 12.5H3.5V10z'
    const ICON_SEND = 'M8 12.5v-9M4 7.5l4-4 4 4'
    const ICON_SHARE = 'M5.5 8.5 10 11M10 5 5.5 7.5M12 3.5a1.75 1.75 0 1 0 0 3.5 1.75 1.75 0 0 0 0-3.5ZM4 6.25a1.75 1.75 0 1 0 0 3.5 1.75 1.75 0 0 0 0-3.5ZM12 9.25a1.75 1.75 0 1 0 0 3.5 1.75 1.75 0 0 0 0-3.5Z'

    const ICON_OPEN = 'M9.5 3.5h3v3M12.5 3.5 7.5 8.5M11 9.5v3h-7.5V5h3'
    const ICON_EYE = 'M1.75 8S4 3.75 8 3.75 14.25 8 14.25 8 12 12.25 8 12.25 1.75 8 1.75 8ZM8 6.25a1.75 1.75 0 1 0 0 3.5 1.75 1.75 0 0 0 0-3.5Z'
    const ICON_EYE_OFF = 'M1.75 8S4 3.75 8 3.75 14.25 8 14.25 8 12 12.25 8 12.25 1.75 8 1.75 8ZM2.5 13.5l11-11'
    const ICON_TRASH = 'M3 4.5h10M6.25 4.5V3h3.5v1.5M4.5 4.5l.6 8.5h5.8l.6-8.5'
    const ICON_REFRESH = 'M12.5 6.5A4.75 4.75 0 1 0 12.8 9.5M12.5 3v3.5H9'

    /** POST to the share route; resolves to its `value`, or throws its error text. */
    async function shareRoute(body) {
      const response = await fetch(SHARE_ROUTE.slice(1), {
        method: 'POST',
        headers: { 'content-type': 'application/json', accept: 'application/json' },
        body: JSON.stringify(body),
      })
      const answer = await response.json().catch(() => null)
      if (!answer?.ok) throw new Error(answer?.error ?? `HTTP ${response.status}`)
      return answer.value
    }

    /** `2026-11-06T14:00:15+08:00` -> `2026-11-06 14:00` in local time; `withTime: false` drops the time. */
    function shortDate(value, withTime = true) {
      if (!value) return ''
      const date = new Date(/^\d+$/.test(String(value)) ? Number(value) : value)
      if (Number.isNaN(date.getTime())) return String(value)
      const pad = n => String(n).padStart(2, '0')
      const day = `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
      return withTime ? `${day} ${pad(date.getHours())}:${pad(date.getMinutes())}` : day
    }

    /** Bytes as people read them. */
    function sizeLabel(bytes) {
      if (!Number.isFinite(bytes)) return ''
      if (bytes < 1024) return `${bytes} B`
      if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
      return `${(bytes / 1024 / 1024).toFixed(1)} MB`
    }

    /** A link split for the ticket: the part everyone's links share, and the id that is this one's. */
    function splitLink(url) {
      try {
        const parsed = new URL(url)
        const id = parsed.pathname.split('/').filter(Boolean).pop() ?? ''
        return { prefix: `${parsed.host}${parsed.pathname.slice(0, parsed.pathname.length - id.length)}`, id }
      } catch {
        return { prefix: '', id: String(url ?? '') }
      }
    }

    /** A share's status, as the dot and the pill say it. */
    function shareState(status) {
      if (status === 'disabled') return 'disabled'
      if (status === 'auditing') return 'auditing'
      return 'active'
    }

    /**
     * Sharing, the top half of the Trae tab: hand this session out as a link,
     * and look after the links already handed out.
     *
     * The session goes out as a Trae "local conversation" (src/trae/local-share.ts):
     * every turn its own pair of bubbles, every answer with its steps, no model
     * call. Replaying the questions through Trae instead is offered as a quiet
     * second choice, behind a confirmation, because it spends a model call per
     * question and its answers are not this session's.
     *
     * The new link is shown as a ticket — the shared prefix dimmed, the id that
     * makes it this link set apart — and the account's links are listed below
     * it, each with its state and the actions the share API allows: open,
     * copy, close / reopen, delete (delete asks twice: it cannot be undone).
     */
    function ShareSection(props) {
      const { t, sessionId, conversation } = props
      const [kept, setKept] = React.useState(null)
      const [busy, setBusy] = React.useState('')
      const [result, setResult] = React.useState(null)
      const [error, setError] = React.useState('')
      const [replayArmed, setReplayArmed] = React.useState(false)
      const [mine, setMine] = React.useState(null)
      const [mineError, setMineError] = React.useState('')
      const [confirmDelete, setConfirmDelete] = React.useState('')
      const [copied, setCopied] = React.useState('')
      // Files the session produced, and per file the link / error of its last share.
      const [files, setFiles] = React.useState(null)
      const [fileResults, setFileResults] = React.useState({})
      const [otherPath, setOtherPath] = React.useState('')

      React.useEffect(() => {
        if (!copied) return undefined
        const timer = setTimeout(() => { setCopied('') }, COPIED_MS)
        return () => { clearTimeout(timer) }
      }, [copied])

      // What the plugin kept of this session (counts only), re-read whenever
      // a turn may have added to it.
      React.useEffect(() => {
        if (!sessionId || busy) return undefined
        const abort = new AbortController()
        fetch(`${SHARE_ROUTE.slice(1)}?transcript=${encodeURIComponent(sessionId)}`, {
          headers: { accept: 'application/json' }, signal: abort.signal,
        })
          .then(response => response.ok ? response.json() : null)
          .then((body) => { if (!abort.signal.aborted) setKept(body?.ok ? body.value : null) })
          .catch(() => {})
        return () => { abort.abort() }
      }, [sessionId, conversation, busy])

      const loadMine = () => {
        setBusy(current => current || 'mine'); setMineError(''); setConfirmDelete('')
        fetch(`${SHARE_ROUTE.slice(1)}?mine=1`, { headers: { accept: 'application/json' } })
          .then(async (response) => {
            const body = await response.json().catch(() => null)
            if (body?.ok) {
              // Newest first: the one just made is the one wanted next.
              const time = item => Date.parse(item.createdAt ?? '') || 0
              setMine([...body.value].sort((a, b) => time(b) - time(a)))
            } else setMineError(body?.error ?? `HTTP ${response.status}`)
          })
          .catch((cause) => { setMineError(String(cause?.message ?? cause)) })
          .finally(() => { setBusy(current => current === 'mine' ? '' : current) })
      }
      React.useEffect(() => { loadMine() }, [])

      React.useEffect(() => {
        if (!sessionId || busy) return undefined
        const abort = new AbortController()
        fetch(`${SHARE_ROUTE.slice(1)}?files=${encodeURIComponent(sessionId)}`, {
          headers: { accept: 'application/json' }, signal: abort.signal,
        })
          .then(response => response.ok ? response.json() : null)
          .then((body) => { if (!abort.signal.aborted) setFiles(body?.ok ? body.value : []) })
          .catch(() => {})
        return () => { abort.abort() }
      }, [sessionId, conversation, busy])

      const shareFile = (path) => {
        const target = String(path ?? '').trim()
        if (!target) return
        setBusy(`file:${target}`)
        setFileResults(current => ({ ...current, [target]: undefined }))
        shareRoute({ action: 'artifact', path: target, ...sessionId ? { session: sessionId } : {} })
          .then((value) => {
            setFileResults(current => ({ ...current, [target]: { value } }))
            if (value?.source && value.source !== target) setFileResults(current => ({ ...current, [value.source]: { value } }))
            loadMine()
          })
          .catch((cause) => { setFileResults(current => ({ ...current, [target]: { error: String(cause?.message ?? cause) } })) })
          .finally(() => { setBusy('') })
      }

      const create = (mode) => {
        if (!sessionId || !kept) return
        setBusy(mode); setError(''); setResult(null); setReplayArmed(false)
        shareRoute({
          action: 'mirror', session: sessionId, mode,
          ...mode === 'replay' ? { maxTurns: kept.questions } : {},
        })
          .then((value) => { setResult(value); loadMine() })
          .catch((cause) => { setError(String(cause?.message ?? cause)) })
          .finally(() => { setBusy('') })
      }

      const act = (item, action) => {
        const id = item.shareSessionId
        setBusy(`act:${id}`); setMineError(''); setConfirmDelete('')
        shareRoute({ action, id, ...item.host ? { host: item.host } : {} })
          .then((value) => {
            setMine(list => (list ?? []).flatMap(entry => entry.shareSessionId !== id
              ? [entry]
              : action === 'delete' ? [] : [{ ...entry, status: value?.status ?? (action === 'enable' ? 'active' : 'disabled') }]))
          })
          .catch((cause) => { setMineError(String(cause?.message ?? cause)) })
          .finally(() => { setBusy('') })
      }

      const copy = (key, value) => {
        void copyText(value).then((ok) => { setCopied(`${key}:${ok ? 'ok' : 'failed'}`) })
      }
      const copyLabel = key => copied === `${key}:ok` ? t('shareCopied') : copied === `${key}:failed` ? t('shareCopyFailed') : t('shareCopy')

      const iconButton = (label, d, onClick, extra = {}) => h('button', {
        type: 'button', className: 'trae-icon-btn', title: label, 'aria-label': label,
        disabled: busy !== '' && busy !== 'mine', onClick, ...extra,
      }, icon(d, 14))
      const openButton = (url, className = 'trae-icon-btn') => h('a', {
        className, href: url, target: '_blank', rel: 'noreferrer noopener',
        title: t('shareOpen'), 'aria-label': t('shareOpen'),
      }, icon(ICON_OPEN, 14), className === 'trae-icon-btn' ? null : h('span', null, t('shareOpen')))

      // ---- the ticket ------------------------------------------------------
      const ticket = (value) => {
        const { prefix, id } = splitLink(value.url)
        const expires = value.link?.expiresAt ?? value.expiresAt
        return h('div', { className: 'trae-ticket' },
          h('p', { className: 'trae-ticket-url' }, h('span', null, prefix), h('b', null, id)),
          h('div', { className: 'trae-ticket-foot' },
            h('span', { className: 'trae-ticket-meta' }, [
              value.turns ? t('shareStatTurns').replace('{n}', String(value.turns)) : '',
              value.files ? t('shareFileCount').replace('{n}', String(value.files)) : '',
              value.modelCalls ? t('shareCallsNote').replace('{n}', String(value.modelCalls)) : '',
              expires ? t('shareExpires').replace('{date}', shortDate(expires, false)) : '',
            ].filter(Boolean).join(' · ')),
            openButton(value.url, 'trae-chip'),
            h('button', {
              type: 'button', className: 'trae-chip', 'data-strong': 'true',
              onClick: () => { copy(`new:${value.url}`, value.url) },
            }, icon(ICON_COPY, 12), h('span', null, copyLabel(`new:${value.url}`))),
          ),
        )
      }

      // ---- one of my shares -------------------------------------------------
      const row = (item) => {
        const id = item.shareSessionId
        const state = shareState(item.status)
        const stateLabel = state === 'disabled' ? t('shareStateDisabled') : state === 'auditing' ? t('shareStateAuditing') : t('shareStateActive')
        return h('li', { key: id, className: 'trae-item', 'data-state': state },
          h('div', { className: 'trae-item-title' },
            h('span', { className: 'trae-dot', 'aria-hidden': true }),
            h('span', { className: 'trae-item-name', title: item.title || '' }, item.title || t('shareUntitled')),
            h('span', { className: 'trae-pill' }, stateLabel),
          ),
          h('div', { className: 'trae-item-meta' },
            h('code', null, id),
            item.createdAt ? h('span', null, t('shareCreated').replace('{date}', shortDate(item.createdAt))) : null,
            item.expiresAt ? h('span', null, t('shareExpires').replace('{date}', shortDate(item.expiresAt, false))) : null,
          ),
          h('div', { className: 'trae-item-actions' },
            confirmDelete === id
              ? [
                h('button', { key: 'yes', type: 'button', className: 'trae-confirm', onClick: () => { act(item, 'delete') } }, t('shareDeleteConfirm')),
                h('button', { key: 'no', type: 'button', className: 'trae-link', onClick: () => { setConfirmDelete('') } }, t('shareReplayCancel')),
              ]
              : [
                h(React.Fragment, { key: 'open' }, openButton(item.url)),
                h(React.Fragment, { key: 'copy' }, iconButton(copyLabel(`mine:${id}`), copied === `mine:${id}:ok` ? ICON_CHECK : ICON_COPY, () => { copy(`mine:${id}`, item.url) })),
                h(React.Fragment, { key: 'state' }, state === 'disabled'
                  ? iconButton(t('shareReopen'), ICON_EYE, () => { act(item, 'enable') })
                  : iconButton(t('shareClose'), ICON_EYE_OFF, () => { act(item, 'disable') })),
                h(React.Fragment, { key: 'delete' }, iconButton(t('shareDelete'), ICON_TRASH, () => { setConfirmDelete(id) }, { 'data-danger': 'true' })),
              ],
          ),
        )
      }

      const fileRow = (file) => {
        const name = file.path.split('/').pop()
        const folder = file.path.slice(0, file.path.length - name.length)
        const result = fileResults[file.path]
        const shared = result?.value ?? file.shared
        const working = busy === `file:${file.path}`
        return h('li', { key: file.path, className: 'trae-file' },
          h('div', { className: 'trae-file-main' },
            h('span', { className: 'trae-kind', 'data-kind': file.kind }, file.kind === 'markdown' ? 'MD' : 'HTML'),
            h('div', { className: 'trae-file-text' },
              h('span', { className: 'trae-file-name', title: file.path }, name),
              h('span', { className: 'trae-file-meta' }, [shortDate(file.modifiedAt), sizeLabel(file.size), folder].filter(Boolean).join(' · ')),
            ),
            h('button', {
              type: 'button', className: 'trae-chip', 'data-strong': shared ? undefined : 'true',
              disabled: busy !== '' && busy !== 'mine',
              onClick: () => { shareFile(file.path) },
            }, working ? t('shareFileBusy') : shared ? t('shareFileUpdate') : t('shareFileAction')),
          ),
          result?.error ? h('p', { className: 'trae-error', role: 'alert' }, result.error) : null,
          result?.value ? ticket(result.value) : null,
        )
      }

      const turns = kept?.turns ?? 0
      return h('div', { className: 'trae-share' },
        // ---- share this session ---------------------------------------------
        h('section', { className: 'trae-card', 'data-primary': 'true', 'aria-label': t('shareTitle') },
          h('header', { className: 'trae-card-head' }, h('h3', { className: 'trae-card-title' }, t('shareTitle'))),
          h('p', { className: 'trae-card-lead' }, turns ? t('shareLead') : t('shareNoTurnYet')),
          turns
            ? h('div', { className: 'trae-stats' },
              h('span', { className: 'trae-stat' }, t('shareStatTurns').replace('{n}', String(turns))),
              kept.steps ? h('span', { className: 'trae-stat' }, t('shareStatSteps').replace('{n}', String(kept.steps))) : null,
            )
            : null,
          h('div', { className: 'trae-actions' },
            h('button', {
              type: 'button', className: 'trae-btn',
              disabled: busy !== '' && busy !== 'mine' || !turns,
              onClick: () => { create('local') },
            }, icon(ICON_SHARE, 14), h('span', null, busy === 'local' ? t('shareBusy') : result ? t('shareActionAgain') : t('shareAction'))),
            turns && kept.questions && !replayArmed
              ? h('button', {
                type: 'button', className: 'trae-link',
                disabled: busy !== '' && busy !== 'mine',
                onClick: () => { setReplayArmed(true) },
              }, t('shareReplay').replace('{n}', String(kept.questions)))
              : null,
          ),
          replayArmed
            ? h('div', { className: 'trae-callout' },
              h('p', null, t('shareReplayHint')),
              h('div', { className: 'trae-actions' },
                h('button', { type: 'button', className: 'trae-chip', 'data-strong': 'true', onClick: () => { create('replay') } },
                  busy === 'replay' ? t('shareBusy') : `${t('shareReplayConfirm')} · ${t('shareCallsNote').replace('{n}', String(kept.questions))}`),
                h('button', { type: 'button', className: 'trae-link', onClick: () => { setReplayArmed(false) } }, t('shareReplayCancel')),
              ),
            )
            : null,
          error ? h('p', { className: 'trae-error', role: 'alert' }, error) : null,
          result ? ticket(result) : null,
          result?.dropped
            ? h('p', { className: 'trae-card-note' }, t('shareDropped').replace('{turns}', String(result.turns)).replace('{dropped}', String(result.dropped)))
            : null,
          result ? h('p', { className: 'trae-card-note' }, t('sharePublicNote')) : null,
        ),

        // ---- files the session produced ------------------------------------------
        h('section', { className: 'trae-card', 'aria-label': t('shareFilesTitle') },
          h('header', { className: 'trae-card-head' }, h('h3', { className: 'trae-card-title' }, t('shareFilesTitle'))),
          h('p', { className: 'trae-card-lead' }, files && files.length === 0 ? t('shareFilesEmpty') : t('shareFilesLead')),
          files && files.length > 0 ? h('ul', { className: 'trae-list' }, files.map(fileRow)) : null,
          h('div', { className: 'trae-other' },
            h('label', { className: 'trae-other-label', htmlFor: 'trae-other-path' }, t('shareFileOther')),
            h('div', { className: 'trae-other-row' },
              h('input', {
                id: 'trae-other-path', className: 'trae-input', value: otherPath, spellCheck: false,
                placeholder: t('shareFilePlaceholder'),
                onChange: (event) => { setOtherPath(event.target.value) },
                onKeyDown: (event) => { if (event.key === 'Enter') shareFile(otherPath) },
              }),
              h('button', {
                type: 'button', className: 'trae-chip', 'data-strong': 'true',
                disabled: !otherPath.trim() || busy !== '' && busy !== 'mine',
                onClick: () => { shareFile(otherPath) },
              }, busy === `file:${otherPath.trim()}` ? t('shareFileBusy') : t('shareFileAction')),
            ),
            fileResults[otherPath.trim()]?.error ? h('p', { className: 'trae-error', role: 'alert' }, fileResults[otherPath.trim()].error) : null,
            fileResults[otherPath.trim()]?.value && !files?.some(file => file.path === otherPath.trim())
              ? ticket(fileResults[otherPath.trim()].value)
              : null,
          ),
        ),

        // ---- my shares ---------------------------------------------------------
        h('section', { className: 'trae-card', 'aria-label': t('shareMineTitle') },
          h('header', { className: 'trae-card-head' },
            h('h3', { className: 'trae-card-title' }, t('shareMineTitle')),
            mine?.length ? h('span', { className: 'trae-card-count' }, String(mine.length)) : null,
            h('button', {
              type: 'button', className: 'trae-icon-btn', title: t('shareMineRefresh'), 'aria-label': t('shareMineRefresh'),
              disabled: busy !== '', onClick: loadMine,
            }, icon(ICON_REFRESH, 14)),
          ),
          mineError ? h('p', { className: 'trae-error', role: 'alert' }, mineError) : null,
          mine === null && !mineError ? h('p', { className: 'trae-card-lead' }, t('shareMineLoading')) : null,
          mine && mine.length === 0 ? h('p', { className: 'trae-card-lead' }, t('shareMineEmpty')) : null,
          mine && mine.length > 0 ? h('ul', { className: 'trae-list' }, mine.map(row)) : null,
        ),
      )
    }
    const ICON_CHECK = 'M3.5 8.5l3 3 6-7'
    const ICON_FOLD = 'M4 6l4 4 4-4'
    const ICON_UNFOLD = 'M4 10l4-4 4 4'
    /** A line branching off: the task going to a child session. */
    const ICON_BRANCH = 'M5 2.5v6a3 3 0 0 0 3 3h3M11 9l2 2.5-2 2.5'
    /** Two sheets: copy. */
    const ICON_COPY = 'M5.5 5.5h7v8h-7zM3.5 10.5v-8h7'

    /** Grow a textarea with its text, up to the stylesheet's max-height. */
    function fitHeight(element) {
      element.style.height = 'auto'
      element.style.height = `${element.scrollHeight}px`
    }

    /**
     * Next-step cards above the composer, beside the host's todo and queue
     * docks: one card per decision the last Trae answer left open, each with
     * the model's own answers as buttons (its recommendation first, in bold).
     * A button picks that answer for its card — one per card, a second click
     * takes it back — and "something else" picks the user's own words, typed
     * in a box on the card. Once anything is picked, a box under the cards
     * counts the picks, takes an optional note and sends every answer as one
     * message. × closes a card without answering it. The cards step aside
     * while the user types in the composer, and go once a turn runs.
     *
     * With the host's `suggestSubagent` on, what goes out is those answers
     * wrapped in "delegate this to a subagent" (one subagent per task): the
     * one line under the cards says so, and switches the round back to this
     * session when the user would rather watch it happen here.
     *
     * The same line folds the whole round into one row — its count and first
     * question — that opens again on a click. Folding is the user's choice
     * rather than the round's, so later rounds arrive folded until opened.
     */
    function SuggestionCards(props) {
      const { t, sessionId, inputActions } = props
      const running = props.useSession(s => s.running) ?? false
      const draft = props.useInput(s => s.draft ?? '')
      const phase = props.useInput(s => s.phase)
      const choices = props.useTraeChoices(s => s)
      const folded = props.useTraeChoicesFolded(s => s) === true
      // Each card's answer so far, by card index: `{ choice }` for a button,
      // `{ text }` for the user's own words (its box is open while it is).
      const [picks, setPicks] = React.useState({})
      // The note sent along with the answers.
      const [extra, setExtra] = React.useState('')
      // Who does the task: the host's answer for this round until it is switched.
      const [delegate, setDelegate] = React.useState(null)

      // Ask once a turn ends (waiting while the host still works it out), and
      // once on mount so switching back to a session shows what it had.
      const wasRunning = React.useRef(running)
      React.useEffect(() => {
        const ended = wasRunning.current && !running
        wasRunning.current = running
        if (running) { props.clear(); return undefined }
        return props.load(ended ? SUGGESTION_WAIT_MS : 0)
      }, [running, sessionId])

      // A new round of cards starts with nothing picked and the host's own
      // answer for who does the work.
      React.useEffect(() => { setPicks({}); setExtra(''); setDelegate(null) }, [choices.id])

      const open = choices.cards
        .map((card, index) => ({ card, index }))
        .filter(({ index }) => !choices.dismissed.includes(index))
      const visible = open.length > 0 && !running && draft === '' && (phase === undefined || phase === 'plain')

      // Tell the host they were actually on screen; it counts each suggestion
      // once. Folded, the buttons are not on screen, so that waits for a click.
      React.useEffect(() => {
        if (visible && !folded) reportSuggestion(sessionId, choices.id, 'shown')
      }, [visible, folded, choices.id])

      if (!visible) return null
      if (folded) {
        const first = open[0].card
        const count = open.length > 1 ? ` · ${t('choicesFoldedCount').replace('{n}', String(open.length))}` : ''
        return h('div', { className: 'trae-choices', 'data-trae-choices': '', 'data-folded': '' },
          h('button', {
            type: 'button', className: 'trae-choice trae-choice-fold',
            'aria-expanded': false, title: t('choicesUnfold'),
            onClick: () => { props.fold(false) },
          },
          h('span', { className: 'trae-choice-eyebrow' }, icon(ICON_SPARK, 12, true), `${t('choicesEyebrow')}${count}`),
          h('span', { className: 'trae-choice-peek' }, first.question || first.choices[0]?.label || ''),
          h('span', { className: 'trae-choice-unfold' }, t('choicesUnfold'), icon(ICON_UNFOLD, 12)),
          ))
      }
      const toSubagent = delegate ?? choices.subagent === true
      // One pass with a replacement function: a `$&` or a `{task}` inside the
      // model's own words stays itself.
      const fill = (key, values) => t(key)
        .replace(/\{(\w+)\}/g, (whole, slot) => (slot in values ? values[slot] : whole))
      // What would go out now, card by card; an empty box answers nothing.
      const answers = open.flatMap(({ card, index }) => {
        const pick = picks[index]
        if (!pick) return []
        const reply = pick.choice !== undefined ? card.choices[pick.choice]?.reply : pick.text.trim()
        return reply ? [{ card: index, choice: pick.choice, question: (card.question ?? '').trim(), reply }] : []
      })
      const setPick = (card, pick) => {
        setPicks((current) => {
          const next = { ...current }
          if (pick) next[card] = pick
          else delete next[card]
          return next
        })
      }
      // Every answer goes out with its question: the questions were asked by
      // the side completion, so the chat itself never saw them, and "改吧" on
      // its own leaves both this session and a subagent guessing which of the
      // things the answer raised is meant. Delegated tasks travel as the
      // message asking for them — the host has no way to start a child of its
      // own for an idle session. The editor applies a draft as one discrete
      // update, so submit already reads it.
      const compose = (note) => {
        const context = asked => (asked ? fill('choicesSubagentContext', { question: asked }) : '')
        let text
        if (!toSubagent) {
          text = answers
            .map(({ question, reply }) => (question ? fill('choicesPicked', { question, reply }) : reply))
            .join('\n')
        } else if (answers.length === 1) {
          const [{ question, reply }] = answers
          text = fill('choicesSubagentTask', { context: question ? `${context(question)}\n` : '', task: reply })
        } else {
          const tasks = answers.map(({ question, reply }, at) => {
            const item = fill('choicesSubagentItem', { task: reply })
            return `${at + 1}. ${question ? `${context(question)}\n   ${item}` : item}`
          })
          text = fill('choicesSubagentTasks', { tasks: tasks.join('\n\n') })
        }
        return note ? `${text}\n\n${fill(toSubagent ? 'choicesSubagentExtra' : 'choicesExtra', { text: note })}` : text
      }
      // Cue hears of one accepted button per round, the first one picked in
      // card order; the user's own words are no suggestion of Trae's.
      const send = () => {
        if (answers.length === 0) return
        const accepted = answers.find(answer => answer.choice !== undefined)
        if (accepted) reportSuggestion(sessionId, choices.id, 'accept', { card: accepted.card, choice: accepted.choice })
        const text = compose(extra.trim())
        props.close()
        setPicks({})
        setExtra('')
        inputActions.setDraft(text)
        inputActions.submit()
      }
      const onKey = (onEscape) => (event) => {
        if (event.nativeEvent?.isComposing || event.keyCode === 229) return
        if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); send() }
        else if (event.key === 'Escape' && onEscape) { event.preventDefault(); onEscape() }
      }

      return h('div', { className: 'trae-choices', 'data-trae-choices': '' },
        open.map(({ card, index }, position) => {
          const pick = picks[index]
          const editing = pick?.text !== undefined
          return h('div', { key: `${choices.id}:${index}`, className: 'trae-choice' },
            h('div', { className: 'trae-choice-head' },
              h('div', { className: 'trae-choice-heading' },
                h('div', { className: 'trae-choice-eyebrow' },
                  icon(ICON_SPARK, 12, true),
                  open.length > 1 ? `${t('choicesEyebrow')} · ${position + 1}/${open.length}` : t('choicesEyebrow'),
                  toSubagent ? h('span', { className: 'trae-choice-tag' }, t('choicesSubagentOn')) : null,
                ),
                card.question ? h('p', { className: 'trae-choice-question' }, card.question) : null,
              ),
              h('button', {
                type: 'button', className: 'trae-choice-close',
                'aria-label': t('choicesDismiss'), title: t('choicesDismiss'),
                onClick: () => { setPick(index, null); props.dismiss(index) },
              }, icon(ICON_CLOSE)),
            ),
            h('div', { className: 'trae-choice-actions' },
              ...card.choices.map((choice, at) => {
                const picked = pick?.choice === at
                return h('button', {
                  key: at, type: 'button', className: 'trae-choice-btn',
                  'data-primary': at === 0 ? '' : undefined,
                  'aria-pressed': picked,
                  title: choice.reply,
                  onClick: () => { setPick(index, picked ? null : { choice: at }) },
                }, picked ? icon(ICON_CHECK, 13) : null, h('span', { className: 'trae-choice-label' }, choice.label))
              }),
              h('button', {
                key: 'other', type: 'button', className: 'trae-choice-btn',
                'data-other': '', 'aria-expanded': editing,
                onClick: () => { setPick(index, editing ? null : { text: '' }) },
              }, icon(ICON_PEN, 13), h('span', { className: 'trae-choice-label' }, t('choicesOther'))),
            ),
            editing
              ? h('div', { className: 'trae-choice-other' },
                h('textarea', {
                  className: 'trae-choice-input', rows: 1, autoFocus: true,
                  placeholder: t('choicesOtherPlaceholder'), 'aria-label': t('choicesOther'),
                  value: pick.text,
                  onChange: (event) => {
                    fitHeight(event.target)
                    setPick(index, { text: event.target.value })
                  },
                  onKeyDown: onKey(() => { setPick(index, null) }),
                }),
              )
              : null,
          )
        }),
        // Everything picked goes out together, with the user's note if any.
        answers.length > 0
          ? h('div', { className: 'trae-choice trae-choice-compose' },
            h('div', { className: 'trae-choice-eyebrow' },
              icon(ICON_CHECK, 12),
              fill('choicesPickedCount', { n: String(answers.length), total: String(open.length) }),
            ),
            h('div', { className: 'trae-choice-other' },
              h('textarea', {
                className: 'trae-choice-input', rows: 1,
                placeholder: t('choicesExtraPlaceholder'), 'aria-label': t('choicesExtraPlaceholder'),
                value: extra,
                onChange: (event) => {
                  fitHeight(event.target)
                  setExtra(event.target.value)
                },
                onKeyDown: onKey(null),
              }),
              h('button', {
                type: 'button', className: 'trae-choice-send',
                'aria-label': t('choicesSend'), title: t('choicesSend'),
                onClick: send,
              }, icon(ICON_SEND)),
            ),
          )
          : null,
        // One line for the whole round: who does what is sent, the switch to
        // the other one, and folding the round away.
        h('div', { className: 'trae-choice-foot', 'data-subagent': toSubagent ? '' : undefined },
          h('button', {
            type: 'button', className: 'trae-choice-who',
            'aria-pressed': toSubagent, title: t('choicesSubagentToggle'),
            onClick: () => { setDelegate(!toSubagent) },
          }, icon(ICON_BRANCH, 12), h('span', null, t(toSubagent ? 'choicesSubagentOn' : 'choicesSubagentOff'))),
          h('span', { className: 'trae-choice-note' }, t(toSubagent ? 'choicesSubagentHint' : 'choicesInlineHint')),
          h('button', {
            type: 'button', className: 'trae-choice-tuck',
            'aria-expanded': true, title: t('choicesFoldHint'),
            onClick: () => { props.fold(true) },
          }, icon(ICON_FOLD, 12), h('span', null, t('choicesFold'))),
        ),
      )
    }

    /**
     * The enterprise console login. Once it is saved and the quota is actually
     * coming back, this is settled business: it folds away to one line, and
     * opens again on demand (or on its own when something is missing or a
     * write failed).
     */
    function ConsoleAccount(props) {
      const { t, state } = props
      const settled = props.working && state.emailConfigured && state.consoleConfigured && !state.credentialError
      const [open, setOpen] = React.useState(!settled)
      // Collapse the moment it starts working; reopen if it stops.
      React.useEffect(() => { setOpen(!settled) }, [settled])
      const muted = { color: 'var(--dsw-alias-label-secondary)', fontSize: 'var(--dsw-font-xs-13, 13px)' }
      return h('div', { style: { display: 'flex', flexDirection: 'column', gap: open ? 12 : 4, marginTop: 4 } },
        h('div', { style: { display: 'flex', alignItems: 'center', gap: 8 } },
          h('span', { style: { fontWeight: 600 } }, t('console')),
          settled ? h(P.Tag, { tone: 'neutral' }, t('consoleSet')) : null,
          h('span', { style: { flex: 1 } }),
          settled
            ? h(P.Button, {
              variant: 'ghost', size: 'sm', type: 'button',
              onClick: () => { setOpen(!open) },
            }, open ? t('consoleCollapse') : t('consoleEdit'))
            : null,
        ),
        !open
          ? h('p', { style: { ...muted, margin: 0 } }, t('consoleSettled'))
          : h('div', { style: { display: 'flex', flexDirection: 'column', gap: 12 } },
            h(P.SettingsValueField, {
              id: 'dsh-trae2api-console-email',
              label: t('consoleEmail'),
              hint: t('consoleHint'),
              // Write-only like the password, so it reads back blank: say so in
              // the placeholder instead of looking like it was not saved.
              placeholder: state.emailConfigured ? t('consoleSet') : 'you@example.com',
              disabled: !state.emailWritable,
              text: state.email.text,
              onEdit: (text) => { props.edit(EMAIL_FIELD, text) },
            }),
            h(P.SettingsSecretField, {
              id: 'dsh-trae2api-console-password',
              label: t('consolePassword'),
              disabled: !state.consoleWritable,
              text: state.consolePassword.text,
              configured: state.consoleConfigured,
              stateLabel: state.consoleConfigured ? t('consoleSet') : t('consoleUnset'),
              onEdit: (text) => { props.edit(CONSOLE_PASSWORD_FIELD, text) },
            }),
            state.credentialError
              ? h('p', {
                style: {
                  margin: 0, fontSize: 'var(--dsw-font-xs-13, 13px)', whiteSpace: 'pre-wrap',
                  wordBreak: 'break-word', color: 'var(--dsw-alias-state-error-primary)',
                },
              }, `${t('consoleSaveFailed')}${state.credentialError}`)
              : null,
          ),
      )
    }

    /**
     * Where the enterprise deployment lives: the API host and the console
     * host. Folded to one line — the address in use and whether it is the
     * public edition — since most seats never touch it, and open whenever there
     * is something to do here: an unsaved edit, a refused save, or a
     * connection that fails (whose message names the host it asked).
     */
    function DeploymentSection(props) {
      const { t, state } = props
      const d = state.deployment
      const wanted = d.dirty || Boolean(d.error) || props.failing
      const [open, setOpen] = React.useState(wanted)
      React.useEffect(() => { if (wanted) setOpen(true) }, [wanted])
      if (!d.ready) return null
      const muted = { color: 'var(--dsw-alias-label-secondary)', fontSize: 'var(--dsw-font-xs-13, 13px)' }
      const disabled = !d.writable || state.saving
      return h('div', { style: { display: 'flex', flexDirection: 'column', gap: open ? 12 : 4, marginTop: 4 } },
        h('div', { style: { display: 'flex', alignItems: 'center', gap: 8 } },
          h('span', { style: { fontWeight: 600 } }, t('deployment')),
          h(P.Tag, { tone: 'neutral' }, d.custom ? t('deploymentPrivate') : t('deploymentSaas')),
          h('span', { style: { flex: 1 } }),
          h(P.Button, {
            variant: 'ghost', size: 'sm', type: 'button',
            onClick: () => { setOpen(!open) },
          }, open ? t('consoleCollapse') : t('consoleEdit')),
        ),
        !open
          ? h('p', { style: { ...muted, margin: 0, wordBreak: 'break-all' } }, d.effective)
          : h('div', { style: { display: 'flex', flexDirection: 'column', gap: 12 } },
            !d.writable ? h('p', { style: { ...muted, margin: 0 } }, t('deploymentReadOnly')) : null,
            h(P.SettingsValueField, {
              id: 'dsh-trae2api-host',
              label: t('deploymentHost'),
              hint: t('deploymentHostHint'),
              placeholder: d.hostPlaceholder,
              disabled,
              text: d.host.text,
              invalid: d.host.invalid,
              invalidLabel: t('deploymentInvalid'),
              onEdit: (text) => { props.editDeployment('host', text) },
            }),
            h(P.SettingsValueField, {
              id: 'dsh-trae2api-console-host',
              label: t('deploymentConsole'),
              hint: t('deploymentConsoleHint'),
              placeholder: d.consolePlaceholder,
              disabled,
              text: d.consoleHost.text,
              invalid: d.consoleHost.invalid,
              invalidLabel: t('deploymentInvalid'),
              onEdit: (text) => { props.editDeployment('consoleHost', text) },
            }),
            d.error
              ? h('p', {
                style: {
                  margin: 0, fontSize: 'var(--dsw-font-xs-13, 13px)', whiteSpace: 'pre-wrap',
                  wordBreak: 'break-word', color: 'var(--dsw-alias-state-error-primary)',
                },
              }, `${t('deploymentSaveFailed')}${d.error}`)
              : null,
          ),
      )
    }

    function TraeCard(props) {
      const { t } = props
      const state = props.useTraeCard(snapshot => snapshot)
      const quota = props.useTraeQuota(snapshot => snapshot)
      // Credentials are set-and-forget: once they are in, the card folds down to
      // one status line. The row's own "edit" button opens it (props.editorOpen);
      // the line's own button overrides that either way, for the case where the
      // page's structure moved and that signal never arrives.
      const [override, setOverride] = React.useState(undefined)
      const lastEditorOpen = React.useRef(props.editorOpen)
      React.useEffect(() => {
        if (lastEditorOpen.current === props.editorOpen) return
        lastEditorOpen.current = props.editorOpen
        setOverride(undefined)
      }, [props.editorOpen])
      // An enterprise seat is not set up until its console account is in, so it
      // stays open until then — folding away the fields it still needs would
      // hide the only thing left to do.
      const needsConsole = quota.value?.seat === 'enterprise'
        && !(state.emailConfigured && state.consoleConfigured)
      const settled = state.tokenConfigured && !state.credentialError && !state.deployment?.error && !needsConsole
      const open = !settled || (override ?? props.editorOpen === true)
      // Folded, neither the status block nor the quota block is mounted to ask
      // for its own data, and the one line shows both: ask here.
      React.useEffect(() => {
        if (state.status.phase === 'idle') props.checkStatus()
        props.refreshQuota(false)
      }, [])
      const headerSlot = useRowHeaderSlot(props.hostRef, !open && props.view !== 'summary')
      if (props.view === 'summary') return t('description')
      // Folded away, the whole card is one line: is it working, and how much is
      // left. The line itself opens the editor, the way the row's own "edit"
      // button does — one affordance, not two.
      if (!open) {
        const percent = remainingPercent(quota.value)
        const parts = []
        if (state.status.phase === 'ready') parts.push(t('collapsedReady').replace('{n}', String(state.status.models.length)))
        else if (state.status.phase === 'error' || state.status.phase === 'empty') parts.push(t('failed'))
        else parts.push(t('checking'))
        if (percent !== null) parts.push(t('collapsedQuota').replace('{percent}', formatPercent(percent)))
        else if (quota.value?.limit === null && (quota.value?.packs.length ?? 0) > 0) parts.push(t('quotaUnlimited'))
        const dotState = state.status.phase === 'ready' ? (percent !== null && percent < 15 ? 'warning' : 'done')
          : state.status.phase === 'checking' || state.status.phase === 'idle' ? 'ongoing' : 'error'
        const line = h('div', {
          role: 'button',
          tabIndex: 0,
          'aria-expanded': false,
          title: t('credentialsEdit'),
          onClick: () => { setOverride(true) },
          onKeyDown: (event) => {
            if (event.key !== 'Enter' && event.key !== ' ') return
            event.preventDefault()
            setOverride(true)
          },
          style: {
            display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer',
            fontSize: 'var(--dsw-font-xs-13, 13px)', color: 'var(--dsw-alias-label-secondary)',
            ...headerSlot ? {} : { marginTop: 4 },
          },
        },
        h(P.StateDot, { state: dotState }),
        h('span', { style: { fontVariantNumeric: 'tabular-nums' } }, parts.join(' · ')),
        )
        // On the row's own header line when the page lets us, in the card body
        // otherwise.
        return headerSlot ? createPortal(line, headerSlot) : line
      }
      // Open: one inset panel in the shape of the page's own provider editor —
      // title, fields, then cancel/save at the bottom right. SettingsForm is not
      // used here because its footer sits on the left, out of step with the rest
      // of the page; the save it would run is this card's own `props.save`.
      const blocked = !state.dirty || state.invalid || state.saving
      return h('div', {
        style: {
          display: 'flex', flexDirection: 'column', gap: 16, marginTop: 8,
          padding: 16, borderRadius: 'var(--dsw-radius-md, 10px)',
          background: 'var(--dsw-alias-bg-layer-1)',
        },
      },
      h('div', { style: { display: 'flex', alignItems: 'baseline', gap: 8 } },
        h('span', { style: { fontWeight: 600 } }, t('title')),
        h('span', {
          style: { color: 'var(--dsw-alias-label-secondary)', fontSize: 'var(--dsw-font-xs-13, 13px)' },
        }, PROVIDER),
      ),
      !state.available
        ? h('p', { style: { margin: 0, color: 'var(--dsw-alias-label-secondary)' } }, t('unavailable'))
        : h('div', { style: { display: 'flex', flexDirection: 'column', gap: 16 } },
          !state.writable
            ? h('p', {
              style: { margin: 0, color: 'var(--dsw-alias-label-secondary)', fontSize: 'var(--dsw-font-xs-13, 13px)' },
            }, t('readOnly'))
            : null,
          h(P.SettingsSecretField, {
            id: 'dsh-trae2api-token',
            label: t('token'),
            hint: t('tokenHint'),
            disabled: !state.tokenWritable,
            text: state.token.text,
            configured: state.tokenConfigured,
            stateLabel: state.tokenConfigured ? t('tokenSet') : t('tokenUnset'),
            onEdit: (text) => { props.edit(TOKEN_FIELD, text) },
          }),
          // Right under the PAT: on a private deployment the host is the other
          // half of "fill in the token", and the first thing to get right.
          h(DeploymentSection, {
            t, state, editDeployment: props.editDeployment, failing: state.status.phase === 'error',
          }),
          // Only a ToB seat needs these: a consumer account's quota comes off
          // the IDE API, and the console login would be meaningless for it.
          quota.value?.seat === 'enterprise'
            ? h(ConsoleAccount, { t, state, edit: props.edit, working: (quota.value?.packs.length ?? 0) > 0 })
            : null,
          h(StatusBlock, { t, status: state.status, checkStatus: props.checkStatus }),
          h(QuotaBlock, { t, quota, refresh: props.refreshQuota }),
          h(ChoicesSwitch, { t, field: state.suggest, disabled: !state.writable, edit: props.edit }),
          // Nothing to delegate while the cards are off, so the field below
          // follows the switch above it rather than standing there live.
          h(DelegateChoice, {
            t, field: state.delegate, edit: props.edit,
            disabled: !state.writable || state.suggest.text === 'off',
          }),
          h('div', { style: { display: 'flex', alignItems: 'center', gap: 8, justifyContent: 'flex-end' } },
            state.failed
              ? h('p', {
                style: { margin: 0, flex: 1, color: 'var(--dsw-alias-state-error-primary)', fontSize: 'var(--dsw-font-xs-13, 13px)' },
              }, t('saveFailed'))
              : null,
            h(P.Button, {
              variant: 'outline',
              size: 'md',
              type: 'button',
              onClick: () => { props.discard(); if (settled) setOverride(false) },
            }, t('cancel')),
            h(P.Button, {
              variant: 'primary',
              size: 'md',
              type: 'button',
              disabled: blocked,
              onClick: () => { props.save() },
            }, state.saving ? t('saving') : t('save')),
          ),
        ),
      )
    }

    /**
     * Whether the composer offers next-step cards at all: staged like the
     * card's other fields, written by its Save, and picked up by the host
     * without a restart (the field is volatile). Off stops the side completion
     * that writes the cards too, so a turn costs nothing extra.
     */
    function ChoicesSwitch(props) {
      const { t, field } = props
      return h('div', { style: { display: 'flex', flexDirection: 'column', gap: 8, marginTop: 4 } },
        h('span', { style: { fontWeight: 600 } }, t('choicesEnabled')),
        h('div', null,
          h(P.SegmentedControl, {
            id: 'dsh-trae2api-choices',
            label: t('choicesEnabled'),
            value: field.text,
            disabled: props.disabled,
            options: [
              { value: 'on', label: t('choicesEnabledOn') },
              { value: 'off', label: t('choicesEnabledOff') },
            ],
            onChange: (value) => { props.edit(SUGGEST_FIELD, value) },
          }),
        ),
        h('p', {
          style: { margin: 0, color: 'var(--dsw-alias-label-secondary)', fontSize: 'var(--dsw-font-xs-13, 13px)' },
        }, t('choicesEnabledHint')),
      )
    }

    /**
     * Who does what a next-step card sends, unless the line under the cards
     * switches that round: staged like the card's other fields, written by its
     * Save, and picked up by the host without a restart (the field is volatile).
     */
    function DelegateChoice(props) {
      const { t, field } = props
      return h('div', { style: { display: 'flex', flexDirection: 'column', gap: 8, marginTop: 4 } },
        h('span', { style: { fontWeight: 600 } }, t('choicesDefault')),
        h('div', null,
          h(P.SegmentedControl, {
            id: 'dsh-trae2api-delegate',
            label: t('choicesDefault'),
            value: field.text,
            disabled: props.disabled,
            options: [
              { value: 'subagent', label: t('choicesSubagentOn') },
              { value: 'inline', label: t('choicesSubagentOff') },
            ],
            onChange: (value) => { props.edit(SUBAGENT_FIELD, value) },
          }),
        ),
        h('p', {
          style: { margin: 0, color: 'var(--dsw-alias-label-secondary)', fontSize: 'var(--dsw-font-xs-13, 13px)' },
        }, t('choicesDefaultHint')),
      )
    }

    /**
     * The Models page renders its generic editor beside this slot while the
     * row's own "edit" button is on; for a namespace it does not know, that
     * editor is nothing but a title, a "edit cordis.patch.yml" hint and a
     * disabled Save — a broken-looking second form next to this card's real
     * one. Hide the whole thing, and report whether it was there at all: that
     * is the only signal this slot gets for "the row is being edited", since
     * the page passes it no such prop.
     *
     * Guarded: if the page's structure ever differs, nothing is touched and the
     * card falls back to its own disclosure.
     */
    function useGenericEditorChrome(ref) {
      const [open, setOpen] = React.useState(false)
      React.useLayoutEffect(() => {
        const hidden = []
        let node = ref.current
        for (let depth = 0; node && hidden.length === 0 && depth < 6; depth++, node = node.parentElement) {
          // The editor sits before this slot on the setup card and after it on
          // a normal row, so look both ways.
          for (const editor of [node.previousElementSibling, node.nextElementSibling]) {
            if (!editor || editor.contains(ref.current)) continue
            const ours = Array.from(editor.querySelectorAll('p'))
              .some(p => (p.textContent || '').trim().endsWith(`(${SETTINGS_NS})`))
            if (!ours) continue
            hidden.push([editor, editor.style.display])
            editor.style.display = 'none'
          }
        }
        // Same value is a no-op in React, so this cannot loop.
        setOpen(hidden.length > 0)
        return () => { for (const [el, display] of hidden) el.style.display = display }
      })
      return open
    }

    /**
     * The row's own header — the strip with the provider name and its buttons —
     * so the collapsed status line can sit on that line instead of starting a
     * second one. Recognised structurally (the row's first child, which holds
     * buttons and does not contain this card), so a page that looks different
     * simply yields nothing.
     */
    function findRowHeader(el) {
      for (let node = el, depth = 0; node && depth < 6; depth++, node = node.parentElement) {
        const head = node.parentElement?.firstElementChild
        if (!head || head === node || head.contains(el)) continue
        if (!head.querySelector('button')) continue
        return head
      }
      return undefined
    }

    /**
     * A span parked in the row header to portal into, while `enabled`.
     *
     * Checked on every render rather than once: on the first mount this effect
     * runs before the owner's ref is attached (a child's layout effect is
     * processed before its parent's ref), so the header is not reachable yet,
     * and the page may also re-render the row out from under the span.
     */
    function useRowHeaderSlot(ref, enabled) {
      const [slot, setSlot] = React.useState(null)
      const parked = React.useRef(null)
      const detach = () => {
        if (!parked.current) return
        parked.current.remove()
        parked.current = null
        setSlot(null)
      }
      React.useLayoutEffect(() => {
        if (!enabled || !createPortal) { detach(); return }
        if (parked.current?.isConnected) return
        const header = ref?.current ? findRowHeader(ref.current) : undefined
        if (!header) return
        const host = document.createElement('span')
        host.style.cssText = 'display:flex;align-items:center;gap:8px;margin-right:auto'
        // After the name, before the row's buttons.
        header.insertBefore(host, header.firstElementChild?.nextElementSibling ?? null)
        parked.current = host
        setSlot(host)
      })
      React.useEffect(() => () => { detach() }, [])
      return slot
    }

    /** The Models page passes provider-card owner props instead of a view; always render the full card. */
    function ProviderCardExtras(props) {
      const ref = React.useRef(null)
      const editorOpen = useGenericEditorChrome(ref)
      // `display: contents` so this wrapper generates no box of its own: folded
      // away, the card renders nothing in place (its one line lives in the row
      // header), and an empty flex item would still take the row's gap and
      // leave this row taller than the others.
      return h('div', { ref, style: { display: 'contents' } },
        h(TraeCard, { ...props, view: 'page', editorOpen, hostRef: ref }))
    }

    return {
      inject: ['slots', 'locale', 'remote', 'remote.credentials', 'remote.session', 'configForms'],
      apply(ctx) {
        ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-trae2api: dictionaries')
        const quota = new QuotaController()
        const card = new TraeCardController(ctx.configForms.get(SETTINGS_NS), ctx, quota)
        ctx.effect(() => () => { card.dispose() }, 'dsh-trae2api: form')
        // The chip needs each session's model selection; without the model
        // picker's service there is nothing to sit beside, so no chip.
        const noModel = createStore({ current: null })
        ctx.inject(['slots', 'modelDirectories'], (scope) => {
          /** The session's model selection, or an empty one until it is bound. */
          const directoryFor = (sessionId) => {
            try { return scope.modelDirectories.directoryFor(sessionId).store } catch { return noModel }
          }
          scope.slots.inject('conversation.input.right', () => scope.slots.register({
            name: 'conversation.input.right',
            // A list slot: every entry needs its own id, or the registry throws.
            id: 'trae-quota',
            locale: NS,
            inject: sessionId => ({
              hooks: { traeModel: directoryFor(sessionId), traeQuota: quota.store },
              refresh: (force) => { void quota.load(force) },
            }),
          }, QuotaChip))
          // The ids and the share links are one "Trae" view of the session, so
          // they are one of the session's own tabs (对话 / 轨迹 / 上下文 / …),
          // after the shipped ones.
          //
          // That row is a global registry — the host builds it from
          // `slots.entries('conversation.view')` and filters nothing per
          // session — so the tab is registered and dropped as Trae sessions
          // come and go on screen instead (see TabPresence). The host
          // subscribes to the slot, so the row follows along.
          const t = bindLocale(ctx)
          const presence = new TabPresence(() => scope.slots.inject('conversation.view', () => scope.slots.register({
            name: 'conversation.view',
            id: TAB_ID,
            // After the shipped views, which sit at their own low orders.
            order: 100,
            label: () => t('sessionTabTitle'),
            locale: NS,
            inject: sessionId => ({ sessionId, hooks: { traeModel: directoryFor(sessionId) } }),
          }, SessionTab)))
          scope.effect(() => () => { presence.dispose() }, 'dsh-trae2api: session tab presence')
          // What tells it which sessions are on screen and what they picked:
          // one entry beside the composer that renders nothing at all.
          scope.slots.inject('conversation.input.right', () => scope.slots.register({
            name: 'conversation.input.right',
            id: 'trae-session-watch',
            locale: NS,
            inject: sessionId => ({
              hooks: { traeModel: directoryFor(sessionId) },
              watch: (isTrae) => { presence.set(sessionId, isTrae) },
              unwatch: () => { presence.drop(sessionId) },
            }),
          }, SessionWatch))
          // Its own entry rather than part of the chip: the chip is absent on an
          // unlimited or unreadable quota, and the switch still needs saying.
          scope.slots.inject('conversation.input.right', () => scope.slots.register({
            name: 'conversation.input.right',
            id: 'trae-switch',
            // Before the quota chip, where the picker it talks about sits.
            order: -10,
            locale: NS,
            inject: sessionId => ({ hooks: { traeModel: directoryFor(sessionId) } }),
          }, SwitchNotice))
        })
        // Next-step cards above the composer, one per decision the answer left open.
        ctx.effect(() => {
          const style = document.createElement('style')
          style.dataset.plugin = PACKAGE
          style.textContent = CHOICES_CSS
          document.head.appendChild(style)
          return () => { style.remove() }
        }, 'dsh-trae2api: next-step card styles')
        const choices = new SuggestionController()
        // Share buttons on the host's own file cards at the end of a turn.
        ctx.slots.inject('conversation.chat.turnTail', () => ctx.slots.register({
          name: 'conversation.chat.turnTail',
          id: 'trae-file-share',
          // After the host's file cards, which this sits on or under.
          order: 50,
          locale: NS,
          inject: () => ({ hooks: { fileShares } }),
        }, TurnFileShare))
        ctx.slots.inject('deliverables.file.actions', () => ctx.slots.register({
          name: 'deliverables.file.actions',
          id: 'trae-file-share',
          locale: NS,
          inject: () => ({ hooks: { fileShares, deliveredPaths } }),
        }, DeliveredShareAction))
        ctx.slots.inject('conversation.input.dock', () => ctx.slots.register({
          name: 'conversation.input.dock',
          // After the host's todo (0) and queue (20) docks, right above the input.
          id: 'trae-choices',
          order: 30,
          locale: NS,
          inject: sessionId => ({
            hooks: { traeChoices: choices.storeFor(sessionId), traeChoicesFolded: choices.folded },
            load: waitMs => choices.load(sessionId, waitMs),
            clear: () => { choices.clear(sessionId) },
            dismiss: (card) => { choices.dismiss(sessionId, card) },
            close: () => { choices.close(sessionId) },
            fold: (folded) => { choices.fold(folded) },
          }),
        }, SuggestionCards))
        ctx.effect(
          () => ctx.remote.$on('credentials/reference-updated', (ref) => { card.refreshCredential(ref) }),
          'dsh-trae2api: credential updates',
        )
        ctx.effect(
          () => ctx.remote.$on('llm/adapters-updated', () => {
            void card.checkStatus()
            if (quota.store.getSnapshot().phase !== 'idle') void quota.load(true)
          }),
          'dsh-trae2api: provider updates',
        )
        ctx.effect(() => ctx.configForms.whileServed([SETTINGS_NS], () => {
          const disposers = [
            ctx.slots.inject('plugins.bundle.config', () => ctx.slots.register({
              name: 'plugins.bundle.config', key: PACKAGE, locale: NS, inject: () => card.inject(),
            }, TraeCard)),
            ctx.slots.inject('settings.models.provider-card', () => ctx.slots.register({
              name: 'settings.models.provider-card', key: SETTINGS_NS, locale: NS, inject: () => card.inject(),
            }, ProviderCardExtras)),
          ]
          return () => { for (const dispose of disposers) if (typeof dispose === 'function') dispose() }
        }), 'dsh-trae2api: settings card')
      },
    }
  },
})
