/**
 * 门禁 · 跑全部自测（不需要 dsh、不需要 GUI）
 *
 *   node test/run-all.mjs [报告目录]
 *
 * stdio 用 inherit（不走管道），受限壳里也能跑。全部通过才 exit 0。
 */

import { spawnSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import { join, resolve } from 'node:path';

const reportDir = resolve(process.argv[2] ?? join(import.meta.dirname, 'out'));
mkdirSync(reportDir, { recursive: true });

const suites = [
  ['数据层（状态 / 名单 / 差异）', join(import.meta.dirname, 'run-data-layer.mjs')],
  ['受管辖通道（含默认禁与 fail-closed 负向证据）', join(import.meta.dirname, 'run-guard.mjs')],
  ['策略档（profile / 会话绑定 / 联网软禁）', join(import.meta.dirname, 'run-profiles.mjs')],
  ['策略档运行时（文件读取 / 目录绑定 / fail-closed）', join(import.meta.dirname, 'run-profiles-runtime.mjs')],
  ['宿主路由', join(import.meta.dirname, 'run-routes.mjs')],
  ['客户端（槽位 / 渲染 / 交互）', join(import.meta.dirname, 'run-client.mjs')],
  ['Claude Code 适配器（PreToolUse 拦截 / 放行 / fail-closed）', join(import.meta.dirname, 'run-hook-claude.mjs')],
  ['opencode 适配器（tool.execute.before 拦截 / 放行）', join(import.meta.dirname, 'run-opencode-plugin.mjs')],
  ['Gemini CLI 适配器（BeforeTool 拦截 / fail-closed）', join(import.meta.dirname, 'run-hook-gemini.mjs')],
  ['通用前置钩子（字段容错 / 三种拦截输出）', join(import.meta.dirname, 'run-hook-generic.mjs')],
  ['MCP 服务器（JSON-RPC 握手 / 工具调用）', join(import.meta.dirname, 'run-mcp.mjs')],
  ['一键接线器（dry-run / 合并 / 幂等 / 多 harness）', join(import.meta.dirname, 'run-setup.mjs')],
  ['pi 扩展（tool_call 拦截 / 放行 / 字段容错）', join(import.meta.dirname, 'run-plugin-pi.mjs')],
  ['本机设置页（gate ui：只读接口 / token / 改级别 / 加减对象）', join(import.meta.dirname, 'run-ui.mjs')],
  ['接线体检（doctor / --fix 全量接线）', join(import.meta.dirname, 'run-doctor.mjs')],
  ['CLI 契约（--version / -v）', join(import.meta.dirname, 'run-cli.mjs')],
];

const results = [];
for (const [label, script] of suites) {
  console.log(`\n########## ${label}：${script} ##########`);
  const result = spawnSync(process.execPath, [script, reportDir], { stdio: 'inherit' });
  results.push({ label, script, code: result.status });
}

console.log('\n########## 汇总 ##########');
for (const row of results) {
  console.log(`${row.code === 0 ? 'PASS' : 'FAIL'}  ${row.label}  (exit ${row.code})`);
}
const failed = results.filter((row) => row.code !== 0);
console.log(`\n${results.length - failed.length}/${results.length} 个套件通过 · 报告目录 ${reportDir}`);
process.exit(failed.length === 0 ? 0 : 1);
