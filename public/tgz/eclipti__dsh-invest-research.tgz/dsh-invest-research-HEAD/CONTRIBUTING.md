# Contributing

Thanks for considering a contribution to `dsh-invest-research`!

## Development

```sh
npm test          # unit tests (pure functions, no network)
node tests/smoke.mjs 600519   # live API smoke test
node cli.mjs 600519           # run the full research chain
```

## Adding a data source / layer

1. Add a module under `lib/` that exports an async `getXxx(code)` function.
2. Keep the deterministic scoring logic in a pure function (testable without
   network), following `lib/value.js` (`analyzeValue`) as the pattern.
3. Wrap network calls with the shared `fetchJson` client from
   `lib/eastmoney.js` (timeouts, UA, referer included).
4. Wire the layer into `runResearch` in `index.js` (use `guarded()` so a
   single source failure never sinks the chain), and add a section in
   `formatText` / `buildReport`.
5. Add unit tests in `tests/run.js` and run `npm test`.

## Guidelines

- Public data sources only, no API keys required.
- Output is research data + heuristic scores — never buy/sell advice.
- Per-layer fault tolerance: one failing source must not break the chain.
- Run `node --check` on every changed module before committing.
