/**
 * CLI entry: run the research chain, compare stocks, dump K-line or
 * generate a report file from the command line.
 *
 * Usage:
 *   node cli.mjs 600519                 # full 5-layer research (JSON)
 *   node cli.mjs 600519 --report        # write reports/600519-<date>.md
 *   node cli.mjs --compare 600519 000858  # side-by-side comparison table
 *   node cli.mjs --kline 600519 30      # K-line + technical summary
 *   node cli.mjs --sectors 10           # hot sector rankings
 */
import { writeFileSync, mkdirSync } from 'node:fs'
import { getQuote } from './lib/quote.js'
import { getValue } from './lib/value.js'
import { getRisk } from './lib/risk.js'
import { getConsensus } from './lib/consensus.js'
import { getValuation } from './lib/valuation.js'
import { getKline } from './lib/kline.js'
import { getHotSectors } from './lib/sector.js'
import { compareStocks, formatCompare } from './lib/compare.js'
import { buildReport } from './lib/report.js'

const guarded = (fn, label) => fn().catch((e) => ({ error: `${label}: ${e.message}` }))

async function researchOne(code) {
  const [quote, value, risk, consensus] = await Promise.all([
    guarded(() => getQuote(code), 'quote'),
    guarded(() => getValue(code), 'value'),
    guarded(() => getRisk(code), 'risk'),
    guarded(() => getConsensus(code), 'consensus'),
  ])
  const price = quote && !quote.error ? quote.current_price : null
  const valuation = await guarded(() => getValuation(code, price), 'valuation')
  return {
    code,
    name: value?.name || quote?.name || risk?.name || consensus?.name || '',
    quote, value, risk, consensus, valuation,
    generated_at: new Date().toISOString(),
    disclaimer: '基于公开数据的量化研究，不构成投资建议',
  }
}

const args = process.argv.slice(2)

if (args[0] === '--compare') {
  const codes = args.slice(1)
  if (codes.length < 2) {
    console.error('Usage: node cli.mjs --compare <code1> <code2> [...]')
    process.exit(1)
  }
  const result = await compareStocks(codes)
  console.log(formatCompare(result))
  console.log('\n' + result.disclaimer)
  process.exit(0)
}

if (args[0] === '--kline') {
  const code = args[1]
  const limit = Number(args[2]) || 30
  if (!code) {
    console.error('Usage: node cli.mjs --kline <code> [limit]')
    process.exit(1)
  }
  const k = await getKline(code, 'daily', limit)
  console.log(JSON.stringify(k, null, 2))
  process.exit(0)
}

if (args[0] === '--sectors') {
  const limit = Number(args[1]) || 15
  const s = await getHotSectors(limit)
  console.log(`# ${s.title} (${s.timestamp.slice(0, 10)})`)
  console.log('')
  console.log('| 板块 | 涨跌幅% | 主力净流入 | 领涨股 |')
  console.log('|---|---|---|---|')
  for (const sec of s.sectors) {
    console.log(`| ${sec.name} | ${sec.change_pct ?? '-'} | ${sec.main_inflow_display ?? '-'} | ${sec.leading_stock ?? '-'} |`)
  }
  process.exit(0)
}

// default: single-code research
const code = args[0]
if (!code) {
  console.error(`Usage:
  node cli.mjs 600519
  node cli.mjs 600519 --report
  node cli.mjs --compare 600519 000858
  node cli.mjs --kline 600519 30
  node cli.mjs --sectors 10`)
  process.exit(1)
}

const result = await researchOne(code)
if (args.includes('--report')) {
  const md = buildReport(result)
  const date = new Date().toISOString().slice(0, 10)
  const path = `reports/${code}-${date}.md`
  mkdirSync('reports', { recursive: true })
  writeFileSync(path, md, 'utf8')
  console.log(`Report saved to ${path}`)
  process.exit(0)
}

console.log(JSON.stringify(result, null, 2))
