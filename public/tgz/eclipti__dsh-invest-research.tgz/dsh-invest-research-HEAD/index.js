/**
 * dsh-invest-research host plugin.
 *
 * Registers one model tool (invest_research) that runs the full A-share
 * research chain in parallel — real-time quote, Buffett-style value scoring,
 * risk radar and institutional consensus — and returns the merged result.
 * Data comes from East Money public APIs; no API key required.
 *
 * Research tool only: the output is quantitative data + heuristic scores,
 * never a buy/sell recommendation.
 *
 * @module dsh-invest-research
 */

import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { getQuote } from './lib/quote.js'
import { getValue } from './lib/value.js'
import { getRisk } from './lib/risk.js'
import { getConsensus } from './lib/consensus.js'
import { getValuation } from './lib/valuation.js'
import { getKline } from './lib/kline.js'
import { getHotSectors } from './lib/sector.js'
import { compareStocks, formatCompare } from './lib/compare.js'
import { buildReport } from './lib/report.js'

export const name = 'invest-research'

export const inject = ['tools']

/** Skill body shipped inside this package. */
const SKILL_FILE = fileURLToPath(new URL('./skills/invest-research/SKILL.md', import.meta.url))
const SKILL_NAME = 'invest-research'
const SKILL_DESCRIPTION = 'A股全链路投研：对任意A股代码并行跑行情快照/巴菲特价值评分/风险雷达/机构共识，输出结构化研报数据'

/**
 * Run one module defensively so a single data-source failure does not
 * sink the whole chain.
 * @template T
 * @param {() => Promise<T>} fn
 * @param {string} label
 * @returns {Promise<T | {error: string}>}
 */
async function guarded(fn, label) {
  try {
    return await fn()
  } catch (error) {
    return { error: `${label} 数据获取失败: ${error?.message ?? String(error)}` }
  }
}

/**
 * Register the tool and the runtime skill.
 * @param {import('@deepseek-ai/cordis').Context} ctx - cordis context.
 * @param {object} [config] - optional plugin config (unused for now).
 */
export function apply(ctx, config) {
  const disposers = []

  // Runtime skill: teaches the agent the research workflow on demand.
  const skills = ctx.get('skills')
  if (skills && typeof skills.register === 'function') {
    try {
      const content = readFileSync(SKILL_FILE, 'utf8')
      disposers.push(skills.register({
        name: SKILL_NAME,
        description: SKILL_DESCRIPTION,
        content,
        source: 'runtime',
        provider: 'dsh-invest-research',
      }))
    } catch (error) {
      ctx.logger?.warn?.('dsh-invest-research: failed to register skill: ' + String(error))
    }
  }

  // Human command: instant research without a model round trip.
  const commands = ctx.get('commands')
  if (commands && typeof commands.register === 'function') {
    disposers.push(commands.register({
      name: 'invest',
      description: '对A股代码跑全链路投研(行情/价值/风险/机构共识)',
      input: { hint: '股票代码，如 600519' },
      async handler(invocation) {
        const code = String(invocation.rawInput || '').trim()
        if (!code) return { kind: 'error', text: '/invest 需要一个A股代码，例如 /invest 600519' }
        try {
          const result = await runResearch(code)
          return { kind: 'success', text: formatText(result) }
        } catch (error) {
          return { kind: 'error', text: String(error?.message ?? error) }
        }
      },
    }))
  }

  disposers.push(ctx.tools.register(defineTool({
    name: 'invest_research',
    description:
      '对A股代码跑全链路投研：实时行情快照 + 巴菲特七维价值评分(满分100) + 六类风险扫描(0-100) + ' +
      '机构评级共识与目标价 + 保守DCF估值。各层并行抓取，单层失败不影响其余。' +
      '返回结构化 JSON，适合生成研报或对比多只股票。仅研究数据，不构成投资建议。',
    parameters: {
      code: {
        type: 'string',
        required: true,
        description: 'A股6位代码(如 600519)，也支持港股5位(00700)与美股代码(AAPL)',
      },
    },
    output: {
      schema: { type: 'object', additionalProperties: true },
      render: (_args, value) => [{ type: 'text', text: formatText(value) }],
    },
    async execute(args) {
      const code = String(args.code || '').trim()
      if (!code) throw new Error('invest_research 需要一个股票代码')
      return runResearch(code)
    },
  })))

  disposers.push(ctx.tools.register(defineTool({
    name: 'invest_kline',
    description:
      '获取A股K线数据与前复权技术指标(MA5/MA10/MA20)。用于技术面分析、判断趋势与支撑压力位。' +
      '数据来自腾讯行情接口。',
    parameters: {
      code: {
        type: 'string',
        required: true,
        description: 'A股6位代码，如 600519',
      },
      limit: {
        type: 'number',
        description: 'K线根数，默认 30，最大 500',
      },
    },
    output: {
      schema: { type: 'object', additionalProperties: true },
      render: (_args, value) => [{
        type: 'text',
        text: `${value.code} ${value.period}K线 ${value.count} 根: 区间 ${value.summary?.period_start}~${value.summary?.period_end} ` +
          `涨跌 ${value.summary?.period_change_pct}% | 现价 ${value.candles?.at(-1)?.close} | ` +
          `MA5 ${value.summary?.ma5} / MA10 ${value.summary?.ma10} / MA20 ${value.summary?.ma20}`,
      }],
    },
    async execute(args) {
      const code = String(args.code || '').trim()
      if (!code) throw new Error('invest_kline 需要一个股票代码')
      const limit = Math.min(Math.max(Number(args.limit) || 30, 1), 500)
      return getKline(code, 'daily', limit)
    },
  })))

  disposers.push(ctx.tools.register(defineTool({
    name: 'invest_sectors',
    description:
      '获取A股热门板块排行(按涨幅)与主力资金净流入，用于把握当日市场热点与资金方向。' +
      '数据来自东方财富，实时快照。',
    parameters: {
      limit: {
        type: 'number',
        description: '返回板块数量，默认 15',
      },
    },
    output: {
      schema: { type: 'object', additionalProperties: true },
      render: (_args, value) => [{
        type: 'text',
        text: value.sectors
          ? '热门板块 Top: ' + value.sectors.map((s) => `${s.name}(${s.change_pct ?? '-'}%,流入${s.main_inflow_display ?? '-'})`).join(' | ')
          : '无数据',
      }],
    },
    async execute(args) {
      const limit = Math.min(Math.max(Number(args.limit) || 15, 1), 50)
      return getHotSectors(limit)
    },
  })))

  disposers.push(ctx.tools.register(defineTool({
    name: 'invest_compare',
    description:
      '多股对比：并行跑核心研究链(行情/价值/风险/机构共识)，输出 Markdown 对比表。' +
      '用于「A和B哪只更值得研究」类问题。',
    parameters: {
      codes: {
        type: 'array',
        required: true,
        description: '股票代码数组，2~10 个，如 ["600519","000858"]',
      },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args) {
      const codes = Array.isArray(args.codes) ? args.codes.map((c) => String(c).trim()).filter(Boolean) : []
      if (codes.length < 2) throw new Error('invest_compare 至少需要 2 个代码')
      if (codes.length > 10) throw new Error('invest_compare 最多 10 个代码')
      const result = await compareStocks(codes.slice(0, 10))
      return formatCompare(result) + '\n\n' + result.disclaimer
    },
  })))

  return () => {
    for (const dispose of disposers) {
      try { dispose() } catch { /* disposal must not break unload */ }
    }
  }
}

/** Run the five research modules (valuation needs the quote price, so it runs second). */
async function runResearch(code) {
  const [quote, value, risk, consensus] = await Promise.all([
    guarded(() => getQuote(code), '行情'),
    guarded(() => getValue(code), '价值评分'),
    guarded(() => getRisk(code), '风险扫描'),
    guarded(() => getConsensus(code), '机构共识'),
  ])

  const price = quote && !quote.error ? quote.current_price : null
  const valuation = await guarded(() => getValuation(code, price), '估值')

  const name =
    (value && value.name) || (quote && quote.name) || (risk && risk.name) || (consensus && consensus.name) || ''

  return {
    code,
    name,
    quote,
    value,
    risk,
    consensus,
    valuation,
    generated_at: new Date().toISOString(),
    disclaimer: '基于公开数据的量化研究，不构成投资建议',
  }
}

/** Render the merged result as readable text for the chat renderer. */
export function formatText(result) {
  const lines = []
  lines.push(`## ${result.name || result.code} (${result.code}) 投研快报`)
  lines.push(`*生成时间: ${(result.generated_at || '').slice(0, 16).replace('T', ' ')} | ${result.disclaimer}*\n`)

  const q = result.quote
  if (q && !q.error) {
    lines.push(`### 📈 行情快照`)
    lines.push(`现价 ${q.current_price ?? '-'} (${q.change_percent ?? '-'}%) | PE ${q.pe_ratio ?? '-'} | PB ${q.pb_ratio ?? '-'} | 总市值 ${q.total_market_cap ? (q.total_market_cap / 1e8).toFixed(0) + '亿' : '-'} | 换手率 ${q.turnover_rate ?? '-'}%\n`)
  }

  const v = result.value
  if (v && !v.error) {
    lines.push(`### 🏆 价值评分（巴菲特框架）`)
    lines.push(`总分 **${v.total_score}/100** (${v.rating}) | ROE ${v.metrics?.avg_roe ?? '-'}% | 毛利率 ${v.metrics?.avg_gross_margin ?? '-'}% | 净利率 ${v.metrics?.avg_net_margin ?? '-'}% | 负债率 ${v.metrics?.avg_debt_ratio ?? '-'}%`)
    lines.push(`> ${v.verdict}\n`)
  }

  const r = result.risk
  if (r && !r.error) {
    lines.push(`### 🛡️ 风险扫描`)
    lines.push(`风险分 **${r.risk_score}/100** (${r.risk_level}) | 警报 ${r.alert_count} 条`)
    if (r.alerts && r.alerts.length) {
      for (const a of r.alerts.slice(0, 5)) lines.push(`- [${a.level}] ${a.message}`)
    }
    lines.push('')
  }

  const c = result.consensus
  if (c && !c.error && c.total_reports > 0) {
    lines.push(`### 🏛️ 机构共识`)
    const dist = c.rating_distribution || {}
    lines.push(`共识 **${c.consensus_rating}** | ${c.total_reports} 份研报 (买入${dist['买入'] ?? 0}/增持${dist['增持'] ?? 0}/中性${dist['中性'] ?? 0}) | ${c.institutions_count} 家机构`)
    if (c.avg_target_price) {
      lines.push(`目标价: 均值 ${c.avg_target_price} (区间 ${c.min_target_price}~${c.max_target_price})`)
    }
    lines.push('')
  }

  const val = result.valuation
  if (val && !val.error && val.dcf_estimate) {
    lines.push(`### 💎 估值（保守DCF）`)
    lines.push(`DCF估值 ${val.dcf_estimate} | 安全边际 ${val.margin_of_safety ?? '-'}\n`)
  }

  const failed = [result.quote, result.value, result.risk, result.consensus, result.valuation].filter((x) => x && x.error)
  if (failed.length) {
    lines.push(`*⚠️ ${failed.length} 层数据获取失败: ${failed.map((f) => f.error).join('; ')}*`)
  }

  return lines.join('\n')
}
