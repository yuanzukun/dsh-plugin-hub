# dsh-invest-research

**A股全链路投研插件 for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)** — 一条命令跑完「行情 → 价值 → 风险 → 机构共识 → 估值」五层研究链路，输出结构化研报数据。

> 只做**量化研究与数据呈现**，不构成投资建议。开源免费，面向个人研究使用。

## 特性

| 层 | 内容 | 数据源 |
|---|---|---|
| 📈 行情快照 | 现价/涨跌幅/PE/PB/市值/换手率/量比 | 东方财富 push2delay（无需 Key） |
| 🏆 价值评分 | 巴菲特七维框架，满分 100（ROE/毛利/净利/负债/成长/现金流/估值/护城河） | 东财 F10 财务主指标 |
| 🛡️ 风险扫描 | 0-100 风险分，六类警报（ST/估值/流动性/资金流/价格/波动） | 东财 + 腾讯备用 |
| 🏛️ 机构共识 | 评级分布 + 机构数 + 平均/最高/最低目标价 | 东财研报中心 |
| 💎 保守估值 | DCF 估算 + 安全边际（10%增长/10%折现/3%永续） | 基于 EPS 历史 |

各层**独立容错**：单层数据源失败不影响其余。

## 安装

```sh
dsh plugin --profile web add dsh-invest-research
```

或从 GitHub 安装：

```sh
dsh plugin --profile web add "github:eclipti/dsh-invest-research#main"
```

安装后重启 `dsh --profile web`。可在 Settings → Plugins 中管理。

## 使用

### 模型工具（推荐）

对模型说「**分析 600519**」，模型自动调用 `invest_research`（五层全链）。还提供三个补充工具：

| 工具 | 用途 |
|---|---|
| `invest_kline` | K线 + MA5/10/20 技术指标（技术面） |
| `invest_sectors` | 热门板块排行 + 主力资金流入（当日热点） |
| `invest_compare` | 多股对比表（「A和B哪只更值得研究」） |

### 快捷命令

输入框直接输入：

```
/invest 600519
```

立即返回四层投研快报，无需模型往返。

### 支持范围

- A股：6位代码，如 `600519`、`000001`
- 港股：5位代码，如 `00700`
- 美股：代码，如 `AAPL`

## 输出示例

```
## 贵州茅台 (600519) 投研快报
📈 现价 1341.99 (-0.98%) | PE 18.84 | PB 6.68 | 总市值 16776亿 | 换手率 0.24%
🏆 总分 84/100 (Excellent) | ROE 21.1% | 毛利率 90.4% | 净利率 51.4% | 负债率 14.1%
🛡️ 风险分 0/100 (安全) | 警报 0 条
🏛️ 共识 买入 | 50 份研报 (买入40/增持7/中性3) | 19 家机构 | 目标价均值 1660.99
💎 DCF估值 701.24 | 安全边际 -91.4%（保守假设下估值低于现价）
```

## 命令行使用（无需 Harness）

```sh
node cli.mjs 600519              # 完整五层 JSON
node cli.mjs 600519 --report     # 生成 Markdown 研报到 reports/
node cli.mjs --compare 600519 000858   # 多股对比表
node cli.mjs --kline 600519 30   # K线 + 技术指标
node cli.mjs --sectors 10        # 热门板块
```

## 目录结构

```
index.js              # 插件入口：4 个模型工具 + /invest 命令 + runtime skill
lib/eastmoney.js      # 东财 API 客户端（超时/UA/字段映射）
lib/quote.js          # 行情快照
lib/value.js          # 巴菲特七维评分
lib/risk.js           # 六类风险扫描
lib/consensus.js      # 机构评级共识 + 目标价
lib/valuation.js      # 保守 DCF 估值
lib/kline.js          # K线 + 均线
lib/sector.js         # 板块热度/资金流
lib/compare.js        # 多股对比
lib/report.js         # Markdown 研报生成
skills/invest-research/SKILL.md   # 模型技能手册
tests/                # 11 个单元测试 + 真实 API 冒烟
cli.mjs               # 命令行入口
```

## 开发

```sh
npm test          # 单元测试（纯函数，无需网络）
```

本地直接调试数据层（不经过 cordis）：

```sh
node -e "import('./lib/quote.js').then(async m => console.log(JSON.stringify(await m.getQuote('600519'), null, 2)))"
```

## 合规与边界

- 输出为量化评分与公开数据汇总，**不提供买入/卖出建议**
- 东财公开 API 可能限流或变更；已内置单层容错，可自行扩展备用数据源
- 评分基于启发式规则，不替代专业基本面研究

## License

MIT
