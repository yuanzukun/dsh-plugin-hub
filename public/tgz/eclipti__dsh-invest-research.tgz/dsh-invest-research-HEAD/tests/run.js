/**
 * Single-process test runner (no child_process spawn — works inside sandboxed
 * environments where node --test's runner cannot spawn workers).
 * Usage: node tests/run.js
 */
import assert from 'node:assert/strict'
import { analyzeValue } from '../lib/value.js'
import { buildConsensus } from '../lib/consensus.js'
import { detectMarket, safeFloat, stripJsonp } from '../lib/eastmoney.js'
import { tencentSymbol } from '../lib/kline.js'
import { formatCompare } from '../lib/compare.js'
import { buildReport } from '../lib/report.js'

let passed = 0
let failed = 0
const failures = []

function test(name, fn) {
  try {
    fn()
    passed++
    console.log(`  ✓ ${name}`)
  } catch (error) {
    failed++
    failures.push({ name, error })
    console.log(`  ✗ ${name}\n    ${error.message}`)
  }
}

console.log('dsh-invest-research unit tests\n')

test('detectMarket maps A-share codes', () => {
  assert.equal(detectMarket('600519'), '1.600519')
  assert.equal(detectMarket('000001'), '0.000001')
  assert.equal(detectMarket('300750'), '0.300750')
  assert.equal(detectMarket('00700'), '116.00700')
  assert.equal(detectMarket('AAPL'), '105.AAPL')
})

test('safeFloat handles dirty values', () => {
  assert.equal(safeFloat('12.5'), 12.5)
  assert.equal(safeFloat('-'), undefined)
  assert.equal(safeFloat(''), undefined)
  assert.equal(safeFloat(null, 0), 0)
  assert.equal(safeFloat('abc'), undefined)
})

test('stripJsonp unwraps datatable(...)', () => {
  assert.equal(stripJsonp('datatable({"a":1})'), '{"a":1}')
  assert.equal(stripJsonp('{"a":1}'), '{"a":1}')
})

test('analyzeValue scores a strong company as Excellent', () => {
  const quote = {
    data: {
      f43: 100, f57: '600519', f58: '示例公司',
      f116: 2e11, f162: 20, f167: 5, f168: 1, f170: 0.5,
    },
  }
  const fin = {
    data: [
      { ROEJQ: 25, XSMLL: 90, XSJLL: 50, ZCFZL: 15, TOTALOPERATEREVETZ: 15, JYJDLYXJJE: 12e8, PARENTNETPROFIT: 10e8 },
      { ROEJQ: 24, XSMLL: 91, XSJLL: 51, ZCFZL: 14, TOTALOPERATEREVETZ: 18, JYJDLYXJJE: 11e8, PARENTNETPROFIT: 9e8 },
      { ROEJQ: 26, XSMLL: 89, XSJLL: 49, ZCFZL: 16, TOTALOPERATEREVETZ: 12, JYJDLYXJJE: 13e8, PARENTNETPROFIT: 10e8 },
      { ROEJQ: 23, XSMLL: 92, XSJLL: 52, ZCFZL: 13, TOTALOPERATEREVETZ: 20, JYJDLYXJJE: 10e8, PARENTNETPROFIT: 9e8 },
    ],
  }
  const result = analyzeValue(quote, fin)
  assert.equal(result.code, '600519')
  assert.ok(result.total_score >= 80, `expected >=80, got ${result.total_score}`)
  assert.equal(result.rating, 'Excellent')
  assert.equal(result.scores.roe, 20)
  assert.equal(result.scores.margin, 15)
  assert.equal(result.scores.debt, 15)
  assert.ok(result.scores.moat >= 8)
})

test('analyzeValue handles missing data gracefully', () => {
  const result = analyzeValue({ data: {} }, { data: [] })
  assert.equal(result.total_score, 0)
  assert.equal(result.rating, 'Poor')
  assert.equal(result.scores.roe, 0)
  assert.equal(result.metrics.avg_roe, null)
})

test('buildConsensus aggregates ratings and targets', () => {
  const reports = [
    { emRatingName: '买入', indvAimPriceT: '100', orgSName: '中信', publishDate: '2026-08-10 10:00:00' },
    { emRatingName: '买入', indvAimPriceT: '110', orgSName: '中金', publishDate: '2026-08-11 10:00:00' },
    { emRatingName: '增持', indvAimPriceT: '90', orgSName: '华泰', publishDate: '2026-08-12 10:00:00' },
  ]
  const result = buildConsensus('600519', reports)
  assert.equal(result.total_reports, 3)
  assert.equal(result.consensus_rating, '买入')
  assert.equal(result.institutions_count, 3)
  assert.equal(result.avg_target_price, 100)
  assert.equal(result.max_target_price, 110)
  assert.equal(result.min_target_price, 90)
  assert.equal(result.latest_report_date, '2026-08-12')
})

test('buildConsensus handles empty list', () => {
  const result = buildConsensus('600519', [])
  assert.equal(result.total_reports, 0)
  assert.ok(result.message)
})

test('tencentSymbol converts market codes', () => {
  assert.equal(tencentSymbol('600519'), 'sh600519')
  assert.equal(tencentSymbol('000858'), 'sz000858')
  assert.equal(tencentSymbol('300750'), 'sz300750')
  assert.equal(tencentSymbol('00700'), 'hk00700')
  assert.equal(tencentSymbol('AAPL'), 'usAAPL')
})

test('formatCompare renders a table with per-stock rows', () => {
  const result = {
    stocks: [
      {
        code: '600519', name: '贵州茅台',
        quote: { current_price: 1341.99, pe_ratio: 18.84 },
        value: { total_score: 84, rating: 'Excellent' },
        risk: { risk_score: 0, risk_level: '安全' },
        consensus: { consensus_rating: '买入', avg_target_price: 1660.99 },
      },
      { code: '000001', name: '', error: 'boom' },
    ],
  }
  const table = formatCompare(result)
  assert.ok(table.includes('| 代码 | 名称 |'))
  assert.ok(table.includes('600519'))
  assert.ok(table.includes('84(Excellent)'))
  assert.ok(table.includes('**boom**'))
})

test('buildReport renders every section and the disclaimer', () => {
  const result = {
    code: '600519', name: '贵州茅台',
    generated_at: '2026-08-16T11:00:00.000Z',
    disclaimer: '免责',
    quote: { current_price: 100, change_percent: 1.5, open: 99, high: 102, low: 98, previous_close: 98.5, turnover_rate: 1, pe_ratio: 20, pb_ratio: 5, total_market_cap: 2e11, volume_ratio: 1.1 },
    value: { total_score: 84, rating: 'Excellent', scores: { roe: 20, margin: 15, debt: 15, growth: 6, cashflow: 15, valuation: 3, moat: 10 }, assessment: { roe: 'x', margin: 'y', debt: 'z', growth: 'g', cashflow: 'c', valuation: 'v', moat: 'm' }, verdict: 'ok' },
    risk: { risk_score: 0, risk_level: '安全', alert_count: 0, alerts: [] },
    consensus: { total_reports: 3, consensus_rating: '买入', rating_distribution: { 买入: 2, 增持: 1 }, institutions_count: 2, latest_report_date: '2026-08-16', avg_target_price: 110, min_target_price: 100, max_target_price: 120 },
    valuation: { dcf_estimate: 90, margin_of_safety: '-10%', valuation_note: 'note' },
  }
  const md = buildReport(result)
  assert.ok(md.startsWith('# 贵州茅台'))
  assert.ok(md.includes('## 📈 行情快照'))
  assert.ok(md.includes('## 🏆 价值评分'))
  assert.ok(md.includes('## 🛡️ 风险扫描'))
  assert.ok(md.includes('## 🏛️ 机构共识'))
  assert.ok(md.includes('## 💎 估值'))
  assert.ok(md.includes('不构成任何投资建议'))
})

test('buildReport tolerates failed layers', () => {
  const md = buildReport({
    code: '600519', name: '', generated_at: 'x', disclaimer: 'd',
    quote: { error: 'quote down' }, value: { error: 'value down' },
    risk: { error: 'risk down' }, consensus: { error: 'consensus down' },
    valuation: { error: 'valuation down' },
  })
  assert.ok(md.includes('## ⚠️ 数据获取失败'))
  assert.ok(md.includes('quote down'))
})

console.log(`\n${passed} passed, ${failed} failed`)
if (failed > 0) {
  console.error('Failures:')
  for (const f of failures) console.error(`  - ${f.name}: ${f.error.message}`)
  process.exit(1)
}
