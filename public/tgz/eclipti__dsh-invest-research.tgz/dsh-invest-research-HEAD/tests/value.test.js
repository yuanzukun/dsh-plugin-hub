import { test } from 'node:test'
import assert from 'node:assert/strict'
import { analyzeValue } from '../lib/value.js'
import { buildConsensus } from '../lib/consensus.js'
import { detectMarket, safeFloat, stripJsonp } from '../lib/eastmoney.js'

test('detectMarket maps A-share codes', () => {
  assert.equal(detectMarket('600519'), '1.600519')
  assert.equal(detectMarket('000001'), '0.000001')
  assert.equal(detectMarket('300750'), '0.300750')
  assert.equal(detectMarket('00700'), '116.00700')
  assert.equal(detectMarket('AAPL'), '105.AAPL')
})

test('safeFloat handles dirty values', () => {
  assert.equal(safeFloat('12.5'), 12.5)
  assert.equal(safeFloat('-'), undefined)
  assert.equal(safeFloat(''), undefined)
  assert.equal(safeFloat(null, 0), 0)
  assert.equal(safeFloat('abc'), undefined)
})

test('stripJsonp unwraps datatable(...)', () => {
  assert.equal(stripJsonp('datatable({"a":1})'), '{"a":1}')
  assert.equal(stripJsonp('{"a":1}'), '{"a":1}')
})

test('analyzeValue scores a strong company as Excellent', () => {
  const quote = {
    data: {
      f43: 100, f57: '600519', f58: '示例公司',
      f116: 2e11, f162: 20, f167: 5, f168: 1, f170: 0.5,
    },
  }
  const fin = {
    data: [
      // ROE 25, GM 90, NM 50, debt 15, growth 15, OCF 12亿, NP 10亿
      { ROEJQ: 25, XSMLL: 90, XSJLL: 50, ZCFZL: 15, TOTALOPERATEREVETZ: 15, JYJDLYXJJE: 12e8, PARENTNETPROFIT: 10e8 },
      { ROEJQ: 24, XSMLL: 91, XSJLL: 51, ZCFZL: 14, TOTALOPERATEREVETZ: 18, JYJDLYXJJE: 11e8, PARENTNETPROFIT: 9e8 },
      { ROEJQ: 26, XSMLL: 89, XSJLL: 49, ZCFZL: 16, TOTALOPERATEREVETZ: 12, JYJDLYXJJE: 13e8, PARENTNETPROFIT: 10e8 },
      { ROEJQ: 23, XSMLL: 92, XSJLL: 52, ZCFZL: 13, TOTALOPERATEREVETZ: 20, JYJDLYXJJE: 10e8, PARENTNETPROFIT: 9e8 },
    ],
  }
  const result = analyzeValue(quote, fin)
  assert.equal(result.code, '600519')
  assert.ok(result.total_score >= 80, `expected >=80, got ${result.total_score}`)
  assert.equal(result.rating, 'Excellent')
  assert.equal(result.scores.roe, 20)
  assert.equal(result.scores.margin, 15)
  assert.equal(result.scores.debt, 15)
  assert.ok(result.scores.moat >= 8)
})

test('analyzeValue handles missing data gracefully', () => {
  const result = analyzeValue({ data: {} }, { data: [] })
  assert.equal(result.total_score, 0)
  assert.equal(result.rating, 'Poor')
  assert.equal(result.scores.roe, 0)
  assert.equal(result.metrics.avg_roe, null)
})

test('buildConsensus aggregates ratings and targets', () => {
  const reports = [
    { emRatingName: '买入', indvAimPriceT: '100', orgSName: '中信', publishDate: '2026-08-10 10:00:00' },
    { emRatingName: '买入', indvAimPriceT: '110', orgSName: '中金', publishDate: '2026-08-11 10:00:00' },
    { emRatingName: '增持', indvAimPriceT: '90', orgSName: '华泰', publishDate: '2026-08-12 10:00:00' },
  ]
  const result = buildConsensus('600519', reports)
  assert.equal(result.total_reports, 3)
  assert.equal(result.consensus_rating, '买入')
  assert.equal(result.institutions_count, 3)
  assert.equal(result.avg_target_price, 100)
  assert.equal(result.max_target_price, 110)
  assert.equal(result.min_target_price, 90)
  assert.equal(result.latest_report_date, '2026-08-12')
})

test('buildConsensus handles empty list', () => {
  const result = buildConsensus('600519', [])
  assert.equal(result.total_reports, 0)
  assert.ok(result.message)
})
