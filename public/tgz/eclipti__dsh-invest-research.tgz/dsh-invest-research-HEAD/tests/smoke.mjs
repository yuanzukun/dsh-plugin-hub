/**
 * Smoke test: hit the real East Money APIs through the lib modules.
 * Usage: node tests/smoke.mjs [code]
 */
import { getQuote } from '../lib/quote.js'
import { getValue } from '../lib/value.js'
import { getRisk } from '../lib/risk.js'
import { getConsensus } from '../lib/consensus.js'

const code = process.argv[2] || '600519'

console.log(`Smoke test for ${code} (${new Date().toISOString()})\n`)

const results = await Promise.allSettled([
  getQuote(code),
  getValue(code),
  getRisk(code),
  getConsensus(code),
])

const labels = ['quote', 'value', 'risk', 'consensus']
let ok = 0
for (let i = 0; i < labels.length; i++) {
  const r = results[i]
  if (r.status === 'fulfilled') {
    ok++
    const v = r.value
    console.log(`✓ ${labels[i]}:`, JSON.stringify(v).slice(0, 200))
  } else {
    console.log(`✗ ${labels[i]}: ${r.reason?.message ?? r.reason}`)
  }
  console.log('')
}

console.log(`${ok}/4 modules OK`)
process.exit(ok === 4 ? 0 : 1)
