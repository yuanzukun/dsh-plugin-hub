# Harness 飞书客户端插件

本目录是浏览器侧源码，不包含 App Secret、飞书 SDK 或 Host 长连接逻辑。`index.js`
向 Harness 0.1.0-rc.6 的 `settings.plugins.tab` 注册 `feishu` 页签，所有操作通过
`ctx.connection.rpc.call('/feishu', endpoint, payload)` 交给 Host。

## 多机器人 RPC 契约

响应必须使用 Harness `RpcResult`：成功为 `{ ok: true, value }`，失败为
`{ ok: false, error: { code, message } }`。Host 不得向浏览器返回 App Secret、access
token、owner open_id 或凭据引用。

### `connection.status`

请求 `{}`，一次返回所有机器人，供客户端每 15 秒刷新一次：

```js
{
  schemaVersion: 2,
  revision: 18,
  state: "connected",
  bots: [{
    botId: "opaque-stable-id",
    state: "connected",
    connected: true, // 在线状态的唯一权威判据
    configured: true,
    bot: {
      name: "北汇星河助手",
      avatarUrl: "https://...", // 可选
      appIdMasked: "cli_a12b••••8ef0",
      tenantName: "北汇星河", // 可选
      domain: "feishu"
    },
    health: {
      status: "healthy",
      summary: "长连接运行正常",
      lastCheckedAt: 1786658200000
    },
    error: null
  }],
  totals: { configured: 1, connected: 1 },
  provisioning: undefined
}
```

客户端按 `botId` 隔离操作状态，且从 `bots` 重新计算统计值。即使某项错误地返回
`state: 'connected'`，只要 `connected !== true` 就不会显示在线。

### 扫码新增

- `provision.begin`：请求 `{ locale?: 'zh-CN' }`，返回 `{ attemptId,
  verificationUrl, qrCodeDataUrl, expiresAt, pollIntervalMs }`；
- `provision.poll`：请求 `{ attemptId }`，状态为 `pending | scanned | connecting |
  connected | expired | failed`；成功时必须同时返回新机器人的 `botId`；
- `provision.cancel`：请求 `{ attemptId }`。

扫码期间现有 `bots` 会继续显示并正常工作。`qrCodeDataUrl` 仅接受 base64
PNG/WebP/SVG data URL，`verificationUrl` 仅接受 HTTPS。客户端只有在
`provision.poll` 返回成功、随后 `connection.status` 中对应 `botId` 的
`connected === true` 时才宣告新机器人可用。

### 单机器人操作

- `bot.reconnect`：请求 `{ botId }`。已在线时只做健康检查，不重启 WebSocket；离线时
  尝试重连。返回完整 v2 状态快照；
- `bot.disconnect`：请求 `{ botId }`，保留给 Host/兼容场景；当前 UI 不提供临时断开
  入口，因为 Harness 重启后仍会自动连接已配置机器人；
- `bot.delete`：请求 `{ botId, confirm: true }`，只移除此 Harness 中的配置与凭据，
  不得删除其他机器人，也不表示已删除飞书开放平台应用。

旧 `connection.test`、`connection.disconnect` 仅用于滚动升级兼容，新 UI 不调用。

## 构建

运行：

```sh
node plugin-src/client/build.mjs
```

脚本使用 esbuild 生成浏览器 CJS，把 `react` 保持为 Harness Loader external，并将结果
包装为：

```js
window.__ModuleLoader__.load({
  id: "@xmanrui/dsh-feishu",
  factory: (require) => {
    return module.exports;
  },
});
```

安装或更新客户端插件后需重启 `dsh web`，让 Harness 重新生成客户端模块清单。
