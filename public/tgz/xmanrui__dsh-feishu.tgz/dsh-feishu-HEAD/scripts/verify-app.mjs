import 'dotenv/config';
import { loadConfig } from '../src/config.mjs';

const config = loadConfig();
const tokenResponse = await fetch('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal', {
  method: 'POST',
  headers: { 'content-type': 'application/json; charset=utf-8' },
  body: JSON.stringify({ app_id: config.appId, app_secret: config.appSecret }),
  signal: AbortSignal.timeout(15000),
});
const tokenBody = await tokenResponse.json();
if (!tokenResponse.ok || tokenBody.code !== 0 || !tokenBody.tenant_access_token) {
  throw new Error(`Feishu authentication failed: ${tokenBody.msg || tokenResponse.status}`);
}

const botResponse = await fetch('https://open.feishu.cn/open-apis/bot/v3/info/', {
  headers: { authorization: `Bearer ${tokenBody.tenant_access_token}` },
  signal: AbortSignal.timeout(15000),
});
const botBody = await botResponse.json();
if (!botResponse.ok || botBody.code !== 0) {
  throw new Error(`Feishu bot verification failed: ${botBody.msg || botResponse.status}`);
}

console.log(JSON.stringify({
  ok: true,
  appId: config.appId,
  botName: botBody.bot?.app_name ?? botBody.bot?.bot_name ?? null,
  openId: botBody.bot?.open_id ?? null,
  activated: botBody.bot?.activate_status ?? null,
}, null, 2));
