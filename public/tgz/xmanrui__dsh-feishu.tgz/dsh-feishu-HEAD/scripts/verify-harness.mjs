import 'dotenv/config';
import { loadConfig } from '../src/config.mjs';
import { HarnessClient } from '../src/harness-client.mjs';

const config = loadConfig();
const harness = new HarnessClient({
  baseUrl: config.harnessBaseUrl,
  workspace: config.harnessWorkspace,
  agentPreset: config.harnessAgentPreset,
  autostart: config.harnessAutostart,
  dshBin: config.dshBin,
});

await harness.ensureRunning();
const sessionId = await harness.createSession();
await harness.rpc('session.rename', { sessionId, title: '飞书桥接自动测试' });
const answer = await harness.ask(sessionId, '这是连接测试。请只回复：飞书桥接测试成功');
if (!answer.includes('飞书桥接测试成功')) {
  throw new Error(`Unexpected Harness reply: ${answer.slice(0, 200)}`);
}
console.log(JSON.stringify({ ok: true, sessionId, reply: answer }, null, 2));
