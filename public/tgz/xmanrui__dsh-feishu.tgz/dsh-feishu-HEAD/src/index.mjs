import 'dotenv/config';
import { createServer } from 'node:http';
import * as Lark from '@larksuiteoapi/node-sdk';
import { loadConfig } from './config.mjs';
import { StateStore } from './state-store.mjs';
import { HarnessClient } from './harness-client.mjs';
import { FeishuHarnessBridge } from './bridge.mjs';
import { VerifiedFeishuChannel } from './feishu-channel.mjs';

const config = loadConfig();
const status = {
  startedAt: new Date().toISOString(),
  ready: false,
  feishuLongConnectionState: 'idle',
  harnessReachable: false,
  messagesReceived: 0,
  messagesReplied: 0,
  messagesRejected: 0,
  reactionsAdded: 0,
  reactionsRemoved: 0,
  reactionErrors: 0,
  streamResponses: 0,
  streamUpdates: 0,
  streamFallbacks: 0,
  streamErrors: 0,
  lastMessageAt: null,
  lastReplyAt: null,
  lastRejectedAt: null,
  lastError: null,
  agentPreset: config.harnessAgentPreset,
  authorizationMode: 'sender-open-id-allowlist',
  allowedSenderCount: config.allowedSenderOpenIds.size,
};

const state = await new StateStore(config.statePath).load();
const harness = new HarnessClient({
  baseUrl: config.harnessBaseUrl,
  workspace: config.harnessWorkspace,
  agentPreset: config.harnessAgentPreset,
  autostart: config.harnessAutostart,
  dshBin: config.dshBin,
});

await harness.ensureRunning();
status.harnessReachable = true;

const larkConfig = {
  appId: config.appId,
  appSecret: config.appSecret,
  domain: Lark.Domain.Feishu,
};
const client = new Lark.Client(larkConfig);
const channel = new VerifiedFeishuChannel({
  client,
  initialText: '已连接 DeepSeek Harness，正在思考…',
});
const bridge = new FeishuHarnessBridge({
  client,
  channel,
  harness,
  state,
  status,
  allowedSenderOpenIds: config.allowedSenderOpenIds,
  replyTimeoutMs: config.replyTimeoutMs,
});
const dispatcher = new Lark.EventDispatcher({}).register({
  'im.message.receive_v1': (event) => {
    bridge.accept(event);
    return {};
  },
  // The app receives events for reactions created by the bot itself.
  // They are lifecycle acknowledgements; no second action is required.
  'im.message.reaction.created_v1': () => ({}),
  'im.message.reaction.deleted_v1': () => ({}),
});

const healthServer = createServer(async (request, response) => {
  if (request.url !== '/healthz') {
    response.writeHead(404).end('not found');
    return;
  }
  try {
    await harness.health();
    status.harnessReachable = true;
  } catch (error) {
    status.harnessReachable = false;
    status.lastError = error.message;
  }
  status.feishuLongConnectionState = wsClient?.getConnectionStatus().state ?? status.feishuLongConnectionState;
  const ok = status.ready && status.harnessReachable && status.feishuLongConnectionState === 'connected';
  response.writeHead(ok ? 200 : 503, { 'content-type': 'application/json; charset=utf-8' });
  response.end(JSON.stringify({ ok, ...status }));
});
healthServer.listen(config.healthPort, '127.0.0.1');

let wsClient = new Lark.WSClient({
  ...larkConfig,
  loggerLevel: Lark.LoggerLevel.info,
  handshakeTimeoutMs: 15000,
  onReady: () => {
    status.feishuLongConnectionState = 'connected';
    status.ready = true;
    status.lastError = null;
    console.info('[bridge] Feishu long connection is ready');
  },
  onError: (error) => {
    status.feishuLongConnectionState = 'failed';
    status.ready = false;
    status.lastError = error.message;
    console.error('[bridge] Feishu long connection failed:', error.message);
  },
  onReconnecting: () => {
    status.feishuLongConnectionState = 'reconnecting';
    status.ready = false;
  },
  onReconnected: () => {
    status.feishuLongConnectionState = 'connected';
    status.ready = true;
    status.lastError = null;
  },
});
await wsClient.start({ eventDispatcher: dispatcher });
status.feishuLongConnectionState = wsClient.getConnectionStatus().state;
console.info(`[bridge] starting; health=http://127.0.0.1:${config.healthPort}/healthz`);

function shutdown(signal) {
  console.info(`[bridge] shutting down on ${signal}`);
  status.ready = false;
  wsClient.close({ force: true });
  healthServer.close();
  harness.stopManagedProcess();
  setTimeout(() => process.exit(0), 250).unref();
}
process.once('SIGTERM', () => shutdown('SIGTERM'));
process.once('SIGINT', () => shutdown('SIGINT'));
