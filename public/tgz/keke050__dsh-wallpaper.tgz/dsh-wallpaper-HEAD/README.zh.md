# dsh-wallpaper

为 DeepSeek Harness 桌面端设置自定义背景壁纸。

[![Awesome DSH Plugin](https://awesome-dsh-plugin.com/badge.svg)](https://awesome-dsh-plugin.com)

[English](README.md) | 中文

## 功能

- **预设壁纸** — 内置 6 款渐变壁纸（极光/海洋/日落/森林/夜色/樱花），外加「无」选项。
- **自定义图片 URL** — 粘贴任意 `http(s)` 图片地址。
- **本地上传** — 选择本地 PNG / JPG / GIF / WebP（≤ 10MB），图片存到宿主端，重启后仍保留。
- **透明度滑块** — 控制壁纸透过界面的程度，0%（隐藏）到 100%（铺满）。100% 时底层背景、卡片、甚至消息气泡都会半透明，壁纸充满整个窗口。
- 持久化：配置与上传的图片保存在 `$DSH_HOME/storages/wallpaper/`，通过稳定的 `/dsh-wallpaper/image` 路径回传，桌面端每次随机端口重启也不会丢失。

## 安装

```sh
dsh plugin --profile web add github:keke050/dsh-wallpaper
```

然后重启 DeepSeek Harness，打开 **设置 → 壁纸**。

## 使用

1. 选择预设、粘贴图片 URL，或上传本地图片。
2. 拖动透明度滑块到喜欢的程度——数值越大壁纸越明显。
3. 点 **移除壁纸** 恢复默认背景。

## 原理

- 宿主半区注册三个本地 HTTP 路由（`/dsh-wallpaper/config`、`/dsh-wallpaper/upload`、`/dsh-wallpaper/image`），并把壁纸持久化到 `$DSH_HOME/storages/wallpaper/`。
- 客户端半区渲染设置页，并注入 CSS：把壁纸放到 `body`，同时通过覆盖 `--dsw-alias-bg-*` / `--dsw-specific-*` 设计变量让界面背景变半透明，使壁纸透出对话区而不只是侧栏。

## 许可证

MIT
