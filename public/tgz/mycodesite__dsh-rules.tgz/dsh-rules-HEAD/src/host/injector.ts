// RuleInjector：规则注入与刷新。异步读盘合成字符串缓存，systemPrompt 段 text 同步读缓存。
import { watch, type FSWatcher } from 'node:fs'
import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { createUserMessage } from './contract.ts'
import { globalRulesDir, projectRulesDir } from './paths.ts'
import { MAX_TOTAL_BYTES, type Rule, type RuleStore } from './store.ts'

/** 稳定引导段：静态文本，保 KV Cache 前缀稳定 */
export const GUIDANCE = `## 规则库（RuleBase）

本环境由 DSH 插件 rulebase 注入“规则”。下方【全局规则】/【项目规则】是当前生效的约束，请在对话与执行中严格遵守。（某一级规则目录为空时，该级分区不出现。）`

/** 规则库注入边界标记：全角方括号，规则域/宿主段/VCP 段全库零碰撞（任务031 实测） */
const RULES_BOUNDARY_BEGIN = '［规则库开始］'
const RULES_BOUNDARY_END = '［规则库结束］'
/** 空态占位：替代原 return ''（空段被宿主 renderPrompt filter 丢弃致引导句悬空） */
const RULES_EMPTY = '（当前无全局规则与项目规则）'

/** 全局缓存键（无 cwd 时） */
const GLOBAL_KEY = '__global__'

/** 合成全局+项目规则全文，首尾以边界标记包裹；空态输出占位；超出总量则截断正文（标记恒在截断之外） */
function renderRules(global: Rule[], project: Rule[], cwd?: string): string {
  const parts: string[] = []
  if (global.length > 0) parts.push('### 全局规则', ...global.map(ruleBlock))
  if (project.length > 0) {
    parts.push(`### 项目规则${cwd ? `（cwd：${cwd}）` : ''}`, ...project.map(ruleBlock))
  }
  // 空态：不再返回 ''，改占位（否则宿主 filter 丢弃该段、引导句悬空）
  let body = parts.length > 0 ? parts.join('\n\n') : RULES_EMPTY
  if (Buffer.byteLength(body, 'utf8') > MAX_TOTAL_BYTES) {
    const cut = Buffer.from(body, 'utf8').subarray(0, MAX_TOTAL_BYTES).toString('utf8')
    body = `${cut}\n\n> …（规则总量超限，已截断）`
  }
  // 标记在截断之外，恒在首尾，不会被截断吃掉
  return `${RULES_BOUNDARY_BEGIN}\n\n${body}\n\n${RULES_BOUNDARY_END}`
}

function ruleBlock(rule: Rule): string {
  const heading = rule.title && rule.title !== rule.id ? rule.title : rule.id
  const stripped = stripLeadingTitle(rule.content, heading)  // 剥离首行标题（尽力而为）
  const hMin = scanHeadings(stripped)                         // 扫最浅标题层级
  const shift = hMin > 0 && hMin < 5 ? 5 - hMin : 0           // 差值降级到 H5 起
  return `#### ${heading}\n\n${relevel(stripped, shift)}`
}

/** 剥离首行 ATX 标题（仅当剥 # 后文本 == heading；比对不中绝不误剥） */
export function stripLeadingTitle(content: string, heading: string): string {
  const hasBOM = content.charCodeAt(0) === 0xFEFF
  const body = hasBOM ? content.slice(1) : content
  const lines = body.split('\n')
  const first = lines[0]?.trim() ?? ''
  const m = first.match(/^#{1,6}\s+(.*)$/)  // 与 titleOf 修复后同源
  if (m && m[1].trim() === heading) {
    let start = 1
    if (lines[1] !== undefined && lines[1].trim() === '') start = 2  // 跳过紧随空行
    const rest = lines.slice(start).join('\n')
    return (hasBOM ? '\uFEFF' : '') + rest
  }
  return content  // 比对不中，不剥（绝不误删用户正文）
}

/** 扫描最浅 ATX 标题层级（围栏状态机跳过代码块）；0 = 无标题 */
export function scanHeadings(content: string): number {
  const body = content.charCodeAt(0) === 0xFEFF ? content.slice(1) : content
  const lines = body.split('\n')
  let inFence = false, fenceChar = '', hMin = 0
  for (const line of lines) {
    const fm = line.match(/^ {0,3}(`{3,}|~{3,})/)
    if (fm) {
      const ch = fm[1][0]
      if (!inFence) { inFence = true; fenceChar = ch }
      else if (ch === fenceChar) { inFence = false; fenceChar = '' }
      continue
    }
    if (inFence) continue
    const hm = line.match(/^ {0,3}(#{1,6})([\t ]|$)/)
    if (hm) {
      const lvl = hm[1].length
      if (hMin === 0 || lvl < hMin) hMin = lvl
    }
  }
  return hMin
}

/** 标题行整体 +shift（H6 钳制，严禁 H7）；跳过围栏内与行内代码 */
export function relevel(content: string, shift: number): string {
  if (shift <= 0) return content
  const hasBOM = content.charCodeAt(0) === 0xFEFF
  const body = hasBOM ? content.slice(1) : content
  const lines = body.split('\n')
  let inFence = false, fenceChar = ''
  const out: string[] = []
  for (const line of lines) {
    const fm = line.match(/^ {0,3}(`{3,}|~{3,})/)
    if (fm) {
      const ch = fm[1][0]
      if (!inFence) { inFence = true; fenceChar = ch }
      else if (ch === fenceChar) { inFence = false; fenceChar = '' }
      out.push(line); continue
    }
    if (inFence) { out.push(line); continue }
    const hm = line.match(/^( {0,3})(#{1,6})([\t ]|$)(.*)$/)
    if (hm) {
      const newLevel = Math.min(hm[2].length + shift, 6)  // H6 钳制
      out.push(`${hm[1]}${'#'.repeat(newLevel)}${hm[3]}${hm[4]}`)
    } else {
      out.push(line)
    }
  }
  return (hasBOM ? '\uFEFF' : '') + out.join('\n')
}

export class RuleInjector {
  /** 合成字符串缓存：key = cwd（或 GLOBAL_KEY），value = 全量合成结果 */
  private readonly cache = new Map<string, string>()
  /** 活动 agent → cwd（供显式刷新） */
  private readonly activeAgents = new Map<Agent, string>()
  /** 见过的项目 cwd（reload 重算覆盖） */
  private readonly knownCwds = new Set<string>()
  private readonly watchers = new Map<string, FSWatcher>()
  private reloadPending = false
  private debounceTimer: NodeJS.Timeout | undefined

  private readonly ctx: Context
  private readonly store: RuleStore
  /** 全局规则目录（装配层注入；缺省回退 paths 解析）——与 store 的目录同源，避免 watcher 挂错目录 */
  private readonly globalDir: string | undefined

  constructor(ctx: Context, store: RuleStore, globalDir?: string) {
    this.ctx = ctx
    this.store = store
    this.globalDir = globalDir
  }

  /** 启动：预加载全局规则缓存 */
  async boot(): Promise<void> {
    await this.refresh()
  }

  /** 异步读盘 + 合成 + 写缓存（cwd 为空 = 仅全局） */
  async refresh(cwd?: string): Promise<void> {
    const global = await this.store.list('global')
    await this.renderToCache(global, cwd)
  }

  /** 用已读的全局规则合成并写缓存（复用全局，避免重复读盘） */
  private async renderToCache(global: Rule[], cwd?: string): Promise<void> {
    const project = cwd ? await this.store.list('project', cwd) : []
    this.cache.set(cwd ?? GLOBAL_KEY, renderRules(global, project, cwd))
  }

  /** 同步读缓存（供 systemPrompt 段 text 使用；未命中回退全局） */
  renderFromCache(cwd?: string): string {
    return this.cache.get(cwd ?? GLOBAL_KEY) ?? this.cache.get(GLOBAL_KEY) ?? ''
  }

  /** 变更收敛：异步重算缓存 + 显式 agent.inject（不唤醒驱动）；新旧合成文本一致则跳过注入 */
  async reload(): Promise<void> {
    if (this.reloadPending) return
    this.reloadPending = true
    try {
      const old = new Map(this.cache) // 重算前快照（value 为不可变字符串，浅拷贝安全）
      const global = await this.store.list('global') // 全局只读一次
      await this.renderToCache(global)
      for (const cwd of this.knownCwds) await this.renderToCache(global, cwd) // 仅读项目，复用全局
      // 逐 key 对比新旧合成文本；无变化只刷缓存，跳过注入（根治 touch/临时文件/双通道重复的无效注入）。
      // key 缺失（首次建缓存/启动竞态）视为有变化，保守注入防漏提醒；cache keys 单调增（knownCwds 无删除路径），
      // 旧快照 keys ⊆ 新 keys 恒成立，遍历新 keys 即全量对比。若未来 knownCwds 支持删除，须改为并集遍历。
      const changed = [...this.cache].some(([key, text]) => text !== old.get(key))
      if (!changed) return // finally 复位 reloadPending，提前返回安全
      for (const agent of this.activeAgents.keys()) {
        try {
          agent.inject(createUserMessage({
            content: [{ type: 'text', text: '[规则已更新] 请按最新规则库继续。' }],
            source: { kind: 'rulebase-update' },
          }))
        } catch (err) {
          console.warn('rulebase: agent.inject 失败', err)
        }
      }
    } finally {
      this.reloadPending = false
    }
  }

  /** 装配文件监听与会话生命周期钩子 */
  watch(): void {
    this.watchDir(this.globalDir ?? globalRulesDir())
    this.ctx.on('agent/created', (payload) => {
      const agent = payload.agent
      const cwd = agent.session.header.cwd
      this.activeAgents.set(agent, cwd ?? '')
      if (cwd) {
        this.knownCwds.add(cwd)
        this.watchDir(projectRulesDir(cwd))
        void this.refresh(cwd)
      }
    })
    this.ctx.on('agent/disposed', (payload) => {
      this.activeAgents.delete(payload.agent)
    })
    this.ctx.effect(() => {
      return () => {
        clearTimeout(this.debounceTimer)
        this.debounceTimer = undefined
        for (const w of this.watchers.values()) w.close()
        this.watchers.clear()
      }
    }, 'rulebase.watchers')
  }

  private watchDir(dir: string | undefined): void {
    if (!dir || this.watchers.has(dir)) return
    try {
      const w = watch(dir, () => this.debounceReload())
      this.watchers.set(dir, w)
    } catch {
      // 目录不存在；后续 save 会 mkdir，且极端情况由下次 assemble 重扫兜底
    }
  }

  private debounceReload(): void {
    if (this.debounceTimer) return
    this.debounceTimer = setTimeout(() => {
      this.debounceTimer = undefined
      void this.reload()
    }, 150)
    this.debounceTimer.unref?.()
  }
}