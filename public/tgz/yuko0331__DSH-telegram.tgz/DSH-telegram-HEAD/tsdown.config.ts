import { clientBundle } from '../deepseek-harness/packages/client/tsdown.client.ts'

export default clientBundle('dsh-telegram-bot', ['lib/types/index.js'])
