import type { TelegramApi } from './telegram-api.js';
/** Workspace data safe to expose to the allowlisted administrator. */
export interface WorkspaceSummary {
    id: string;
    title: string;
    path: string;
    status: 'ok' | 'missing-dir';
    sessionCount: number;
}
/** Live session data shown by monitoring commands. */
export interface SessionSummary {
    id: string;
    workspaceTitle?: string;
    status: 'idle' | 'running';
    ownedByBot: boolean;
}
/** Runtime operation exposed by the DSH adapter to the transport controller. */
export interface DshTelegramGateway {
    listWorkspaces(): Promise<WorkspaceSummary[]>;
    listSessions(): Promise<SessionSummary[]>;
    createConversation(workspaceId: string): Promise<string>;
    selectConversation(sessionId: string): Promise<void>;
    sendPrompt(text: string): Promise<void>;
    cancelActive(): Promise<boolean>;
    activeConversation(): SessionSummary | undefined;
    setReplyChat(chatId: number): void;
    dispose(): Promise<void>;
}
/** Controller configuration independent of Cordis and DSH runtime types. */
export interface TelegramControllerOptions {
    adminUserId: number;
    pollingTimeoutSeconds: number;
    retryDelayMs: number;
    maxMessageCharacters: number;
}
/** Split output without exceeding Telegram's message size. */
export declare function splitTelegramText(text: string, maxCharacters: number): string[];
/** Allowlisted Telegram command loop over one DSH gateway. */
export declare class TelegramController {
    private readonly api;
    private readonly gateway;
    private readonly options;
    private readonly log;
    private offset;
    constructor(api: TelegramApi, gateway: DshTelegramGateway, options: TelegramControllerOptions, log: (message: string, error?: unknown) => void);
    run(signal: AbortSignal): Promise<void>;
    notify(chatId: number, text: string): Promise<void>;
    private handleUpdate;
    private handleMessage;
    private sendWorkspaces;
    private sendSessions;
    private sendStatus;
    private delay;
}
