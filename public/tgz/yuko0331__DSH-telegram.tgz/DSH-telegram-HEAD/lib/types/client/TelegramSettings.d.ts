import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { TelegramSettingsFace } from './controller.js';
export type TelegramSettingsProps = PropsRuntime<'settings.section'> & PropsLocale<'settings.telegram'> & InjectFace<TelegramSettingsFace>;
export declare function TelegramSettings(props: TelegramSettingsProps): import("react").JSX.Element;
