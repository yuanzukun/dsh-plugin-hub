import { type SettingsScope, type SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { IApiClient } from '@deepseek-ai/dsh-client-connection/client';
export interface TelegramSettingsValue {
    enabled?: boolean;
    adminUserId?: number;
}
export interface RuntimeStatus {
    state: 'disabled' | 'waiting-credentials' | 'connecting' | 'running' | 'error';
    detail?: string;
}
export interface TelegramSettingsState {
    available: boolean;
    writable: boolean;
    enabled: boolean;
    adminUserIdDraft: string;
    tokenDraft: string;
    tokenConfigured: boolean;
    tokenWritable: boolean;
    dirty: boolean;
    invalid: boolean;
    saving: boolean;
    error?: string;
    testResult?: string;
    runtime: RuntimeStatus;
}
export interface TelegramSettingsFace {
    hooks: {
        telegramSettings: SnapshotStore<TelegramSettingsState>;
    };
    editEnabled(enabled: boolean): void;
    editAdminUserId(value: string): void;
    editToken(value: string): void;
    save(): void;
    testConnection(): void;
}
export declare class TelegramSettingsController {
    private readonly scope;
    private readonly api;
    private readonly store;
    private enabledDraft;
    private adminDraft;
    private tokenDraft;
    private tokenConfigured;
    private tokenWritable;
    private saving;
    private error;
    private testResult;
    private runtime;
    constructor(scope: SettingsScope<TelegramSettingsValue>, api: Pick<IApiClient, 'credentials'>);
    inject(): TelegramSettingsFace;
    refreshCredential(ref?: string): void;
    private project;
    private publish;
    private readCredential;
    private refreshStatus;
    private save;
    private testConnection;
}
