import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type TelegramLocaleKey } from './locales.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'settings.telegram': TelegramLocaleKey;
    }
}
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
