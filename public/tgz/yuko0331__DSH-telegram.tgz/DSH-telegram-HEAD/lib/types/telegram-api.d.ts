/** Minimal Telegram Bot API fields used by the plugin. */
export interface TelegramUser {
    id: number;
    is_bot: boolean;
    first_name: string;
    username?: string;
}
/** Telegram chat identity used as a reply destination. */
export interface TelegramChat {
    id: number;
    type: 'private' | 'group' | 'supergroup' | 'channel';
}
/** Incoming text message accepted by the controller. */
export interface TelegramMessage {
    message_id: number;
    from?: TelegramUser;
    chat: TelegramChat;
    text?: string;
}
/** One Telegram long-poll update. */
export interface TelegramUpdate {
    update_id: number;
    message?: TelegramMessage;
}
/** Transport operations required by the DSH bridge. */
export interface TelegramApi {
    getMe(): Promise<TelegramUser>;
    getUpdates(offset: number, timeoutSeconds: number, signal: AbortSignal): Promise<TelegramUpdate[]>;
    sendMessage(chatId: number, text: string): Promise<void>;
}
/** Telegram Bot API request failure. */
export declare class TelegramApiError extends Error {
    constructor(method: string, detail: string);
}
/** HTTP implementation of the Telegram operations used by the plugin. */
export declare class HttpTelegramApi implements TelegramApi {
    private readonly baseUrl;
    constructor(token: string, apiBaseUrl?: string);
    getMe(): Promise<TelegramUser>;
    getUpdates(offset: number, timeoutSeconds: number, signal: AbortSignal): Promise<TelegramUpdate[]>;
    sendMessage(chatId: number, text: string): Promise<void>;
    private call;
}
