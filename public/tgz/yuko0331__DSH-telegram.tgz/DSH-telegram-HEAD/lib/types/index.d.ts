/**
 * Allowlisted Telegram Bot API ingress for DeepSeek Harness.
 *
 * The plugin creates and owns top-level agents, routes text through the normal
 * inbox, and emits only committed assistant messages. Telegram never answers
 * approval or question interactions; those remain on trusted DSH interfaces.
 *
 * @module dsh-telegram-bot
 */
import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import { type TelegramApi } from './telegram-api.js';
export * from './controller.js';
export * from './telegram-api.js';
export declare const name = "telegram-bot";
export declare const inject: string[];
/** Settings namespace edited by the DSH Web configuration page. */
export declare const TELEGRAM_SETTINGS_NAMESPACE: string;
/** Plugin configuration. The bot token is always named by a credential reference. */
export interface Config {
    /** Whether polling starts when a token and administrator are configured. */
    enabled?: boolean;
    /** Credential reference containing the Telegram bot token. */
    botTokenRef: string;
    /** Immutable numeric Telegram user id allowed to control DSH. */
    adminUserId?: number;
    /** Telegram long-poll timeout in seconds. */
    pollingTimeoutSeconds?: number;
    /** Delay after a failed poll. */
    retryDelayMs?: number;
    /** Maximum characters in one outgoing Telegram message. */
    maxMessageCharacters?: number;
    /** Alternate Telegram-compatible API root. */
    apiBaseUrl?: string;
    /** Runtime-only transport override for tests or private gateways. */
    api?: TelegramApi;
}
export declare const Config: Schema<Config>;
/** Runtime state safe to expose to the settings page. */
export interface TelegramRuntimeStatus {
    state: 'disabled' | 'waiting-credentials' | 'connecting' | 'running' | 'error';
    detail?: string;
}
/** Mount the dynamically configurable Telegram gateway. */
export declare function apply(ctx: Context, config: Config): void;
