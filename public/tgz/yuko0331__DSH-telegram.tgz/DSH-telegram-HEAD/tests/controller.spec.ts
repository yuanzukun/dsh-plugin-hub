import { describe, expect, it } from 'vitest'
import { TelegramController, splitTelegramText, type DshTelegramGateway, type SessionSummary } from '../src/controller.js'
import type { TelegramApi, TelegramUpdate } from '../src/telegram-api.js'

class FakeApi implements TelegramApi {
  readonly sent: Array<{ chatId: number; text: string }> = []
  private delivered = false

  constructor(private readonly updates: TelegramUpdate[]) {}

  async getMe() {
    return { id: 1, is_bot: true, first_name: 'Test Bot' }
  }

  async getUpdates(_offset: number, _timeoutSeconds: number, signal: AbortSignal): Promise<TelegramUpdate[]> {
    if (!this.delivered) {
      this.delivered = true
      return this.updates
    }
    await new Promise<void>(resolve => signal.addEventListener('abort', () => resolve(), { once: true }))
    return []
  }

  async sendMessage(chatId: number, text: string): Promise<void> {
    this.sent.push({ chatId, text })
  }
}

class FakeGateway implements DshTelegramGateway {
  active: SessionSummary | undefined
  readonly prompts: string[] = []
  readonly selected: string[] = []
  readonly replyChats: number[] = []
  cancelled = false

  async listWorkspaces() {
    return [{ id: 'w1', title: 'Harness', path: '/repo', status: 'ok' as const, sessionCount: 2 }]
  }

  async listSessions() {
    return [
      { id: 's1', status: 'running' as const, ownedByBot: true, workspaceTitle: 'Harness' },
      { id: 's2', status: 'idle' as const, ownedByBot: false },
    ]
  }

  async createConversation(workspaceId: string): Promise<string> {
    this.active = { id: `session-${workspaceId}`, status: 'idle', ownedByBot: true }
    return this.active.id
  }

  async selectConversation(sessionId: string): Promise<void> {
    this.selected.push(sessionId)
    this.active = { id: sessionId, status: 'idle', ownedByBot: true }
  }

  async sendPrompt(text: string): Promise<void> {
    this.prompts.push(text)
  }

  async cancelActive(): Promise<boolean> {
    this.cancelled = true
    return this.active !== undefined
  }

  activeConversation(): SessionSummary | undefined {
    return this.active
  }

  setReplyChat(chatId: number): void {
    this.replyChats.push(chatId)
  }

  async dispose(): Promise<void> {}
}

function update(userId: number, text: string, updateId = 1): TelegramUpdate {
  return {
    update_id: updateId,
    message: {
      message_id: updateId,
      from: { id: userId, is_bot: false, first_name: 'Admin' },
      chat: { id: 99, type: 'private' },
      text,
    },
  }
}

async function run(updates: TelegramUpdate[], gateway = new FakeGateway()) {
  const api = new FakeApi(updates)
  const controller = new TelegramController(api, gateway, {
    adminUserId: 42,
    pollingTimeoutSeconds: 1,
    retryDelayMs: 1,
    maxMessageCharacters: 100,
  }, () => {})
  const abort = new AbortController()
  const task = controller.run(abort.signal)
  await new Promise(resolve => setImmediate(resolve))
  abort.abort()
  await task
  return { api, gateway }
}

describe('TelegramController', () => {
  it('ignores every non-allowlisted user without replying', async () => {
    const { api, gateway } = await run([update(7, '/workspaces')])
    expect(api.sent).toEqual([])
    expect(gateway.replyChats).toEqual([])
  })

  it('lists workspaces and creates a selected conversation', async () => {
    const { api, gateway } = await run([
      update(42, '/workspaces', 1),
      update(42, '/new w1', 2),
    ])
    expect(api.sent.map(message => message.text).join('\n')).toContain('Harness')
    expect(api.sent.map(message => message.text)).toContain('Conversation created: session-w1')
    expect(gateway.active?.id).toBe('session-w1')
  })

  it('routes plain text and exposes running sessions as tasks', async () => {
    const gateway = new FakeGateway()
    gateway.active = { id: 's1', status: 'running', ownedByBot: true }
    const { api } = await run([
      update(42, 'check the build', 1),
      update(42, '/tasks', 2),
    ], gateway)
    expect(gateway.prompts).toEqual(['check the build'])
    expect(api.sent.map(message => message.text).join('\n')).toContain('Running tasks')
    expect(api.sent.map(message => message.text).join('\n')).not.toContain('s2')
  })
})

describe('splitTelegramText', () => {
  it('splits at readable boundaries and preserves content', () => {
    const chunks = splitTelegramText('alpha beta gamma delta', 12)
    expect(chunks.every(chunk => chunk.length <= 12)).toBe(true)
    expect(chunks.join(' ')).toBe('alpha beta gamma delta')
  })
})
