import { afterEach, describe, expect, it, vi } from 'vitest'
import { HttpTelegramApi, TelegramApiError } from '../src/telegram-api.js'

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('HttpTelegramApi', () => {
  it('tests the token with getMe and returns the bot identity', async () => {
    const fetch = vi.fn(async () => new Response(JSON.stringify({
      ok: true,
      result: { id: 12, is_bot: true, first_name: 'Harness', username: 'harness_bot' },
    }), { status: 200, headers: { 'content-type': 'application/json' } }))
    vi.stubGlobal('fetch', fetch)

    const bot = await new HttpTelegramApi('secret-token', 'https://telegram.invalid').getMe()

    expect(bot.username).toBe('harness_bot')
    expect(fetch).toHaveBeenCalledWith(
      'https://telegram.invalid/botsecret-token/getMe',
      expect.objectContaining({ method: 'POST', body: '{}' }),
    )
  })

  it('reports Telegram failures without including the token', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({
      ok: false,
      description: 'Unauthorized',
    }), { status: 401, headers: { 'content-type': 'application/json' } })))

    const error = await new HttpTelegramApi('do-not-leak', 'https://telegram.invalid').getMe().catch(value => value)

    expect(error).toBeInstanceOf(TelegramApiError)
    expect(String(error)).toContain('Unauthorized')
    expect(String(error)).not.toContain('do-not-leak')
  })
})
