declare module '@deepseek-ai/cordis' {
  import type { Agent, AgentHandle } from '@deepseek-ai/dsh-agent'
  import type { Session, SessionEvent, SessionId } from '@deepseek-ai/dsh-session'
  import type { Workspace } from '@deepseek-ai/dsh-workspace'

  export interface Context {
    agentDefaultModel: { currentSelection(): Record<string, unknown> }
    agents: {
      create(options: { sessionId: SessionId; meta: { cwd: string }; agentOptions: Record<string, unknown> }): Promise<AgentHandle>
      get(id: SessionId): Agent | undefined
      list(): Agent[]
    }
    credentials: { resolve(ref: string): Promise<{ value: string; source: string } | undefined> }
    settings: {
      register<T>(namespace: string, schema: unknown, options: { base: T }): {
        get(): T
        watch(callback: (next: T, previous: T) => void | Promise<void>): () => void
      }
    }
    webServer: {
      register(route: {
        kind: 'exact'
        path: string
        handler: (req: import('node:http').IncomingMessage, res: import('node:http').ServerResponse) => void | Promise<void>
      }): () => void
    }
    workspaceRegistry: { list(): Workspace[] }
    logger: { warn(...args: unknown[]): void; error(...args: unknown[]): void }
    on(name: 'session/event', listener: (session: Session, event: SessionEvent) => void): () => void
    on(name: 'credentials/updated', listener: (ref: string) => void): () => void
    effect(effect: () => () => void | Promise<void>, label: string): () => void
  }
}

declare module '@deepseek-ai/dsh-agent' {
  import type { Session, SessionId } from '@deepseek-ai/dsh-session'

  export interface Agent {
    id: SessionId
    session: Session
    status: 'idle' | 'running'
    followup(message: unknown): void
    cancel(cause: { kind: 'user' | 'disposed' }): void
  }

  export interface AgentHandle {
    agent: Agent
    dispose(): Promise<void>
  }
}

declare module '@deepseek-ai/dsh-agent-default-model' {}

declare module '@deepseek-ai/dsh-credentials' {
  export function credentialRef(value: string): string
}

declare module '@deepseek-ai/dsh-llm' {
  export function createUserMessage(input: { content: Array<{ type: 'text'; text: string }>; source: { kind: 'user' } }): unknown
}

declare module '@deepseek-ai/dsh-session' {
  export type SessionId = string & { readonly __sessionId: unique symbol }
  export function SessionId(value: string): SessionId

  export interface Session {
    id: SessionId
    header: { id: SessionId; cwd?: string }
  }

  export type SessionEvent =
    | { type: 'assistant/message'; data: { message: { content: Array<{ type: 'text'; text: string } | { type: 'image'; attachment: { attachmentId: string } }> } } }
    | { type: 'turn/end'; data: { reason: { kind: 'error'; error: { message: string } } | { kind: 'completed' | 'aborted' | 'max-tokens' } } }
}

declare module '@deepseek-ai/dsh-settings' {
  export function settingsNamespace(value: string): string
}

declare module '@deepseek-ai/dsh-workspace' {
  import type { SessionId } from '@deepseek-ai/dsh-session'

  export interface Workspace {
    id: string
    title: string
    path: string
    sessionIds: readonly SessionId[]
    status(): Promise<'ok' | 'missing-dir'>
    attachSession(id: SessionId): Promise<void>
  }
}
