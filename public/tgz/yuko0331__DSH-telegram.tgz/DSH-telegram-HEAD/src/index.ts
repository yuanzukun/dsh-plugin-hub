/**
 * Allowlisted Telegram Bot API ingress for DeepSeek Harness.
 *
 * The plugin creates and owns top-level agents, routes text through the normal
 * inbox, and emits only committed assistant messages. Telegram never answers
 * approval or question interactions; those remain on trusted DSH interfaces.
 *
 * @module dsh-telegram-bot
 */

import { randomUUID } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import type { ServerResponse } from 'node:http'
import Schema from '@deepseek-ai/schemastery'
import type { Agent, AgentHandle } from '@deepseek-ai/dsh-agent'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { SessionId, type Session, type SessionEvent } from '@deepseek-ai/dsh-session'
import { settingsNamespace } from '@deepseek-ai/dsh-settings'
import type { Workspace } from '@deepseek-ai/dsh-workspace'
import {
  TelegramController,
  splitTelegramText,
  type DshTelegramGateway,
  type SessionSummary,
  type WorkspaceSummary,
} from './controller.js'
import { HttpTelegramApi, type TelegramApi } from './telegram-api.js'

export * from './controller.js'
export * from './telegram-api.js'

export const name = 'telegram-bot'
export const inject = ['agentDefaultModel', 'agents', 'credentials', 'settings', 'webServer', 'workspaceRegistry']

/** Settings namespace edited by the DSH Web configuration page. */
export const TELEGRAM_SETTINGS_NAMESPACE = settingsNamespace('telegram-bot')

/** Plugin configuration. The bot token is always named by a credential reference. */
export interface Config {
  /** Whether polling starts when a token and administrator are configured. */
  enabled?: boolean
  /** Credential reference containing the Telegram bot token. */
  botTokenRef: string
  /** Immutable numeric Telegram user id allowed to control DSH. */
  adminUserId?: number
  /** Telegram long-poll timeout in seconds. */
  pollingTimeoutSeconds?: number
  /** Delay after a failed poll. */
  retryDelayMs?: number
  /** Maximum characters in one outgoing Telegram message. */
  maxMessageCharacters?: number
  /** Alternate Telegram-compatible API root. */
  apiBaseUrl?: string
  /** Runtime-only transport override for tests or private gateways. */
  api?: TelegramApi
}

export const Config: Schema<Config> = Schema.object({
  enabled: Schema.boolean().default(false),
  botTokenRef: Schema.string().required(),
  adminUserId: Schema.number(),
  pollingTimeoutSeconds: Schema.number().default(25),
  retryDelayMs: Schema.number().default(1_000),
  maxMessageCharacters: Schema.number().default(4_000),
  apiBaseUrl: Schema.string().default('https://api.telegram.org'),
})

/** Extract user-visible text from one committed assistant message. */
function assistantText(event: Extract<SessionEvent, { type: 'assistant/message' }>): string {
  return event.data.message.content.map((block) => {
    if (block.type === 'text') return block.text
    if (block.type === 'image') return `[image attachment ${block.attachment.attachmentId}]`
    return ''
  }).filter(Boolean).join('\n')
}

class HarnessGateway implements DshTelegramGateway {
  private readonly handles = new Map<string, AgentHandle>()
  private activeId: string | undefined
  private replyChatId: number | undefined
  private disposed = false

  constructor(
    private readonly ctx: Context,
    private readonly api: TelegramApi,
    private readonly maxMessageCharacters: number,
  ) {}

  async listWorkspaces(): Promise<WorkspaceSummary[]> {
    return await Promise.all(this.ctx.workspaceRegistry.list().map(async workspace => ({
      id: String(workspace.id),
      title: workspace.title,
      path: workspace.path,
      status: await workspace.status(),
      sessionCount: workspace.sessionIds.length,
    })))
  }

  async listSessions(): Promise<SessionSummary[]> {
    return this.ctx.agents.list().map(agent => this.summary(agent))
  }

  async createConversation(workspaceId: string): Promise<string> {
    this.assertOpen()
    const workspace = this.ctx.workspaceRegistry.list().find(candidate => String(candidate.id) === workspaceId)
    if (workspace === undefined) throw new Error(`unknown workspace: ${workspaceId}`)
    if (await workspace.status() !== 'ok') throw new Error(`workspace directory is unavailable: ${workspace.title}`)
    const selection = this.ctx.agentDefaultModel.currentSelection()
    const id = SessionId(randomUUID())
    const handle = await this.ctx.agents.create({
      sessionId: id,
      meta: { cwd: workspace.path },
      agentOptions: selection,
    })
    this.handles.set(String(id), handle)
    try {
      await workspace.attachSession(id)
    } catch (error) {
      this.handles.delete(String(id))
      await handle.dispose()
      throw error
    }
    this.activeId = String(id)
    return String(id)
  }

  async selectConversation(sessionId: string): Promise<void> {
    this.assertOpen()
    const handle = this.handles.get(sessionId)
    if (handle === undefined || this.ctx.agents.get(handle.agent.id) !== handle.agent) {
      throw new Error('only a live conversation created by this bot can be selected')
    }
    this.activeId = sessionId
  }

  async sendPrompt(text: string): Promise<void> {
    this.assertOpen()
    const agent = this.requireActiveAgent()
    const message = createUserMessage({ content: [{ type: 'text', text }], source: { kind: 'user' } })
    agent.followup(message)
  }

  async cancelActive(): Promise<boolean> {
    const agent = this.activeAgent()
    if (agent === undefined) return false
    agent.cancel({ kind: 'user' })
    return true
  }

  activeConversation(): SessionSummary | undefined {
    const agent = this.activeAgent()
    return agent === undefined ? undefined : this.summary(agent)
  }

  setReplyChat(chatId: number): void {
    this.replyChatId = chatId
  }

  owns(session: Session): boolean {
    const handle = this.handles.get(String(session.id))
    return handle?.agent.session === session
  }

  async publish(event: SessionEvent): Promise<void> {
    const chatId = this.replyChatId
    if (chatId === undefined) return
    if (event.type === 'assistant/message') {
      const text = assistantText(event)
      for (const chunk of splitTelegramText(text, this.maxMessageCharacters)) {
        if (chunk.length > 0) await this.api.sendMessage(chatId, chunk)
      }
      return
    }
    if (event.type === 'turn/end' && event.data.reason.kind === 'error') {
      for (const chunk of splitTelegramText(`DSH turn failed: ${event.data.reason.error.message}`, this.maxMessageCharacters)) {
        await this.api.sendMessage(chatId, chunk)
      }
    }
  }

  async dispose(): Promise<void> {
    if (this.disposed) return
    this.disposed = true
    const handles = [...this.handles.values()]
    this.handles.clear()
    this.activeId = undefined
    for (const handle of handles) handle.agent.cancel({ kind: 'disposed' })
    const results = await Promise.allSettled(handles.map(handle => handle.dispose()))
    const failures = results.filter((result): result is PromiseRejectedResult => result.status === 'rejected')
    if (failures.length === 1) throw failures[0]?.reason
    if (failures.length > 1) throw new AggregateError(failures.map(failure => failure.reason), 'Telegram bot agent teardown failed')
  }

  private summary(agent: Agent): SessionSummary {
    const workspace = this.workspaceFor(agent)
    return {
      id: String(agent.id),
      status: agent.status,
      ownedByBot: this.handles.get(String(agent.id))?.agent === agent,
      ...(workspace === undefined ? {} : { workspaceTitle: workspace.title }),
    }
  }

  private workspaceFor(agent: Agent): Workspace | undefined {
    const cwd = agent.session.header.cwd
    return cwd === undefined
      ? undefined
      : this.ctx.workspaceRegistry.list().find(workspace => workspace.path === cwd)
  }

  private activeAgent(): Agent | undefined {
    if (this.activeId === undefined) return undefined
    const handle = this.handles.get(this.activeId)
    if (handle === undefined || this.ctx.agents.get(handle.agent.id) !== handle.agent) return undefined
    return handle.agent
  }

  private requireActiveAgent(): Agent {
    const agent = this.activeAgent()
    if (agent === undefined) throw new Error('no active conversation; use /new <workspace-id> first')
    return agent
  }

  private assertOpen(): void {
    if (this.disposed) throw new Error('Telegram bot plugin is disposed')
  }
}

interface RunningBot {
  gateway: HarnessGateway
  stop(): Promise<void>
}

/** Runtime state safe to expose to the settings page. */
export interface TelegramRuntimeStatus {
  state: 'disabled' | 'waiting-credentials' | 'connecting' | 'running' | 'error'
  detail?: string
}

/** Dynamic polling owner serialized behind settings and credential changes. */
class TelegramRuntimeManager {
  private running: RunningBot | undefined
  private tail: Promise<void> = Promise.resolve()
  private status: TelegramRuntimeStatus = { state: 'disabled' }
  private disposed = false

  constructor(
    private readonly ctx: Context,
    private readonly source: () => Config,
  ) {}

  snapshot(): TelegramRuntimeStatus {
    return this.status
  }

  async testConnection(): Promise<{ ok: boolean; bot?: string; error?: string }> {
    const config = this.source()
    try {
      validateRuntimeConfig({ ...config, enabled: true })
      const resolved = await this.ctx.credentials.resolve(credentialRef(config.botTokenRef))
      if (resolved === undefined) return { ok: false, error: 'Bot Token 尚未配置' }
      const me = await (config.api ?? new HttpTelegramApi(resolved.value, config.apiBaseUrl)).getMe()
      return { ok: true, bot: me.username === undefined ? me.first_name : `@${me.username}` }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : String(error) }
    }
  }

  reconcile(): Promise<void> {
    const operation = this.tail.then(() => this.replace())
    this.tail = operation.catch((error: unknown) => {
      this.status = { state: 'error', detail: error instanceof Error ? error.message : String(error) }
      this.ctx.logger.warn('telegram-bot: dynamic reconfiguration failed')
      this.ctx.logger.warn(error)
    })
    return operation
  }

  async dispose(): Promise<void> {
    this.disposed = true
    await this.tail
    await this.stopCurrent()
  }

  publish(session: Session, event: SessionEvent): void {
    const gateway = this.running?.gateway
    if (gateway === undefined || !gateway.owns(session)) return
    void gateway.publish(event).catch((error: unknown) => {
      this.ctx.logger.warn('telegram-bot: failed to publish session event')
      this.ctx.logger.warn(error)
    })
  }

  private async replace(): Promise<void> {
    if (this.disposed) return
    await this.stopCurrent()
    const config = this.source()
    if (config.enabled !== true) {
      this.status = { state: 'disabled' }
      return
    }
    validateRuntimeConfig(config)
    const resolved = await this.ctx.credentials.resolve(credentialRef(config.botTokenRef))
    if (resolved === undefined) {
      this.status = { state: 'waiting-credentials' }
      return
    }
    this.status = { state: 'connecting' }
    const api = config.api ?? new HttpTelegramApi(resolved.value, config.apiBaseUrl)
    await api.getMe()
    const maxMessageCharacters = config.maxMessageCharacters ?? 4_000
    const gateway = new HarnessGateway(this.ctx, api, maxMessageCharacters)
    const controller = new TelegramController(api, gateway, {
      adminUserId: config.adminUserId as number,
      pollingTimeoutSeconds: config.pollingTimeoutSeconds ?? 25,
      retryDelayMs: config.retryDelayMs ?? 1_000,
      maxMessageCharacters,
    }, (message, error) => {
      this.ctx.logger.warn(`telegram-bot: ${message}`)
      if (error !== undefined) this.ctx.logger.warn(error)
    })
    const abort = new AbortController()
    const polling = controller.run(abort.signal)
    this.running = {
      gateway,
      stop: async () => {
        abort.abort()
        await polling
        await gateway.dispose()
      },
    }
    this.status = { state: 'running' }
  }

  private async stopCurrent(): Promise<void> {
    const current = this.running
    this.running = undefined
    if (current !== undefined) await current.stop()
  }
}

function validateRuntimeConfig(config: Config): void {
  if (!Number.isSafeInteger(config.adminUserId) || (config.adminUserId ?? 0) <= 0) {
    throw new TypeError('adminUserId must be a positive safe integer while Telegram is enabled')
  }
  for (const [field, value] of [
    ['pollingTimeoutSeconds', config.pollingTimeoutSeconds ?? 25],
    ['retryDelayMs', config.retryDelayMs ?? 1_000],
    ['maxMessageCharacters', config.maxMessageCharacters ?? 4_000],
  ] as const) {
    if (!Number.isSafeInteger(value) || value <= 0) throw new TypeError(`${field} must be a positive safe integer`)
  }
}

function sendJson(res: ServerResponse, status: number, body: unknown): void {
  res.statusCode = status
  res.setHeader('content-type', 'application/json; charset=utf-8')
  res.end(JSON.stringify(body))
}

/** Mount the dynamically configurable Telegram gateway. */
export function apply(ctx: Context, config: Config): void {
  let source = (): Config => config
  const scope = ctx.settings.register(TELEGRAM_SETTINGS_NAMESPACE, Config, { base: config })
  source = () => scope.get()
  const manager = new TelegramRuntimeManager(ctx, () => source())

  ctx.on('session/event', (session, event) => { manager.publish(session, event) })
  ctx.on('credentials/updated', (ref) => {
    if (String(ref) === source().botTokenRef) void manager.reconcile()
  })
  scope.watch(() => manager.reconcile())
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: '/telegram-bot/status',
    handler: (req, res) => {
      if (req.method !== 'GET') {
        sendJson(res, 405, { error: 'method not allowed' })
        return
      }
      sendJson(res, 200, manager.snapshot())
    },
  }), 'telegram-bot.status-route')
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact',
    path: '/telegram-bot/test',
    handler: async (req, res) => {
      if (req.method !== 'POST') {
        sendJson(res, 405, { error: 'method not allowed' })
        return
      }
      sendJson(res, 200, await manager.testConnection())
    },
  }), 'telegram-bot.test-route')
  ctx.effect(() => () => manager.dispose(), 'telegram-bot.lifecycle')
  void manager.reconcile()
}
