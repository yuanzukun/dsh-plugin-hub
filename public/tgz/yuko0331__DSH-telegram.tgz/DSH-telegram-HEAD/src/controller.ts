import type { TelegramApi, TelegramMessage, TelegramUpdate } from './telegram-api.js'

/** Workspace data safe to expose to the allowlisted administrator. */
export interface WorkspaceSummary {
  id: string
  title: string
  path: string
  status: 'ok' | 'missing-dir'
  sessionCount: number
}

/** Live session data shown by monitoring commands. */
export interface SessionSummary {
  id: string
  workspaceTitle?: string
  status: 'idle' | 'running'
  ownedByBot: boolean
}

/** Runtime operation exposed by the DSH adapter to the transport controller. */
export interface DshTelegramGateway {
  listWorkspaces(): Promise<WorkspaceSummary[]>
  listSessions(): Promise<SessionSummary[]>
  createConversation(workspaceId: string): Promise<string>
  selectConversation(sessionId: string): Promise<void>
  sendPrompt(text: string): Promise<void>
  cancelActive(): Promise<boolean>
  activeConversation(): SessionSummary | undefined
  setReplyChat(chatId: number): void
  dispose(): Promise<void>
}

/** Controller configuration independent of Cordis and DSH runtime types. */
export interface TelegramControllerOptions {
  adminUserId: number
  pollingTimeoutSeconds: number
  retryDelayMs: number
  maxMessageCharacters: number
}

const HELP = `DSH Telegram commands:
/help - show this help
/workspaces - list registered workspaces
/new <workspace-id> - create and select a conversation
/sessions - list live sessions
/use <session-id> - select a bot-owned conversation
/status - show the active conversation and live sessions
/tasks - show running sessions as remote tasks
/stop - cancel the active conversation

Any other text is sent to the active DSH conversation.`

/** Split output without exceeding Telegram's message size. */
export function splitTelegramText(text: string, maxCharacters: number): string[] {
  if (text.length <= maxCharacters) return [text]
  const chunks: string[] = []
  let rest = text
  while (rest.length > maxCharacters) {
    const candidate = rest.slice(0, maxCharacters)
    const breakAt = Math.max(candidate.lastIndexOf('\n'), candidate.lastIndexOf(' '))
    const end = breakAt > maxCharacters / 2 ? breakAt : maxCharacters
    chunks.push(rest.slice(0, end))
    rest = rest.slice(end).replace(/^\s+/, '')
  }
  if (rest.length > 0) chunks.push(rest)
  return chunks
}

/** Allowlisted Telegram command loop over one DSH gateway. */
export class TelegramController {
  private offset = 0

  constructor(
    private readonly api: TelegramApi,
    private readonly gateway: DshTelegramGateway,
    private readonly options: TelegramControllerOptions,
    private readonly log: (message: string, error?: unknown) => void,
  ) {}

  async run(signal: AbortSignal): Promise<void> {
    while (!signal.aborted) {
      try {
        const updates = await this.api.getUpdates(this.offset, this.options.pollingTimeoutSeconds, signal)
        for (const update of updates) {
          this.offset = Math.max(this.offset, update.update_id + 1)
          await this.handleUpdate(update)
        }
      } catch (error) {
        if (signal.aborted) return
        this.log('telegram polling failed', error)
        await this.delay(this.options.retryDelayMs, signal)
      }
    }
  }

  async notify(chatId: number, text: string): Promise<void> {
    for (const chunk of splitTelegramText(text, this.options.maxMessageCharacters)) {
      await this.api.sendMessage(chatId, chunk)
    }
  }

  private async handleUpdate(update: TelegramUpdate): Promise<void> {
    const message = update.message
    if (message?.text === undefined || message.from === undefined) return
    if (message.from.id !== this.options.adminUserId) {
      this.log(`ignored Telegram user ${message.from.id}`)
      return
    }
    if (message.chat.type !== 'private') {
      await this.notify(message.chat.id, 'For safety, this bot accepts commands only in a private chat.')
      return
    }
    this.gateway.setReplyChat(message.chat.id)
    try {
      await this.handleMessage(message)
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error)
      this.log('telegram command failed', error)
      await this.notify(message.chat.id, `Command failed: ${detail}`)
    }
  }

  private async handleMessage(message: TelegramMessage): Promise<void> {
    const text = message.text?.trim() ?? ''
    const [command, argument] = text.split(/\s+/, 2)
    switch (command?.toLowerCase()) {
      case '/start':
      case '/help':
        await this.notify(message.chat.id, HELP)
        return
      case '/workspaces':
        await this.sendWorkspaces(message.chat.id)
        return
      case '/new':
        if (argument === undefined) throw new Error('usage: /new <workspace-id>')
        await this.notify(message.chat.id, `Conversation created: ${await this.gateway.createConversation(argument)}`)
        return
      case '/sessions':
        await this.sendSessions(message.chat.id, false)
        return
      case '/tasks':
        await this.sendSessions(message.chat.id, true)
        return
      case '/use':
        if (argument === undefined) throw new Error('usage: /use <session-id>')
        await this.gateway.selectConversation(argument)
        await this.notify(message.chat.id, `Active conversation: ${argument}`)
        return
      case '/status':
        await this.sendStatus(message.chat.id)
        return
      case '/stop':
        await this.notify(message.chat.id, await this.gateway.cancelActive() ? 'Cancellation requested.' : 'No active conversation.')
        return
      default:
        if (text.length === 0) return
        await this.gateway.sendPrompt(text)
        await this.notify(message.chat.id, 'Queued.')
    }
  }

  private async sendWorkspaces(chatId: number): Promise<void> {
    const workspaces = await this.gateway.listWorkspaces()
    if (workspaces.length === 0) {
      await this.notify(chatId, 'No registered DSH workspaces.')
      return
    }
    const lines = workspaces.map(workspace =>
      `${workspace.status === 'ok' ? '●' : '○'} ${workspace.title}\n  id: ${workspace.id}\n  path: ${workspace.path}\n  sessions: ${workspace.sessionCount}`)
    await this.notify(chatId, `Workspaces\n\n${lines.join('\n\n')}`)
  }

  private async sendSessions(chatId: number, runningOnly: boolean): Promise<void> {
    const sessions = (await this.gateway.listSessions()).filter(session => !runningOnly || session.status === 'running')
    if (sessions.length === 0) {
      await this.notify(chatId, runningOnly ? 'No running DSH tasks.' : 'No live DSH sessions.')
      return
    }
    const heading = runningOnly ? 'Running tasks' : 'Live sessions'
    const activeId = this.gateway.activeConversation()?.id
    const lines = sessions.map(session =>
      `${session.id === activeId ? '→' : ' '} ${session.status === 'running' ? '●' : '○'} ${session.id}${session.workspaceTitle === undefined ? '' : ` — ${session.workspaceTitle}`}${session.ownedByBot ? ' [bot]' : ''}`)
    await this.notify(chatId, `${heading}\n${lines.join('\n')}`)
  }

  private async sendStatus(chatId: number): Promise<void> {
    const active = this.gateway.activeConversation()
    const sessions = await this.gateway.listSessions()
    const running = sessions.filter(session => session.status === 'running').length
    await this.notify(chatId, [
      `Active: ${active === undefined ? 'none' : `${active.id} (${active.status})`}`,
      `Live sessions: ${sessions.length}`,
      `Running tasks: ${running}`,
    ].join('\n'))
  }

  private delay(ms: number, signal: AbortSignal): Promise<void> {
    return new Promise((resolve) => {
      const timer = setTimeout(resolve, ms)
      signal.addEventListener('abort', () => {
        clearTimeout(timer)
        resolve()
      }, { once: true })
    })
  }
}
