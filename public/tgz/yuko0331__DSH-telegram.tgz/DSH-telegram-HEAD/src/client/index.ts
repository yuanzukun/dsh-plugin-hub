import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import { TelegramSettings } from './TelegramSettings.js'
import { TelegramSettingsController } from './controller.js'
import { en, zh, type TelegramLocaleKey } from './locales.js'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    'settings.telegram': TelegramLocaleKey
  }
}

const NS = 'settings.telegram'
const SETTINGS_NAMESPACE = 'telegram-bot'

export const inject = ['slots', 'locale', 'connection', 'remote', 'settingsScope']

export function apply(ctx: ClientContext): void {
  const connection = ctx.get('connection') as ConnectionHandle
  const scope = ctx.settingsScope.bind<{ enabled?: boolean; adminUserId?: number }>({ namespace: SETTINGS_NAMESPACE })
  const controller = new TelegramSettingsController(scope, connection.api)
  const t = ctx.locale.bind(NS)

  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'telegram-settings: locale')
  ctx.effect(() => {
    const disposers = [
      ctx.remote.$on('credentials/updated', (ref: unknown) => { controller.refreshCredential(String(ref)) }),
      ctx.on('connection/reset', () => { controller.refreshCredential() }),
    ]
    return () => { for (const dispose of disposers) dispose() }
  }, 'telegram-settings: invalidations')

  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'telegram',
    order: 25,
    label: () => t('nav'),
    locale: NS,
    inject: () => controller.inject(),
  }, TelegramSettings))
}
