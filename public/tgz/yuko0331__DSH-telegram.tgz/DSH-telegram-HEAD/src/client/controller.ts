import { createSnapshotStore, type SettingsScope, type SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client'
import type { IApiClient } from '@deepseek-ai/dsh-client-connection/client'

const TOKEN_REF = 'DSH_TELEGRAM_BOT_TOKEN'

export interface TelegramSettingsValue {
  enabled?: boolean
  adminUserId?: number
}

export interface RuntimeStatus {
  state: 'disabled' | 'waiting-credentials' | 'connecting' | 'running' | 'error'
  detail?: string
}

export interface TelegramSettingsState {
  available: boolean
  writable: boolean
  enabled: boolean
  adminUserIdDraft: string
  tokenDraft: string
  tokenConfigured: boolean
  tokenWritable: boolean
  dirty: boolean
  invalid: boolean
  saving: boolean
  error?: string
  testResult?: string
  runtime: RuntimeStatus
}

export interface TelegramSettingsFace {
  hooks: { telegramSettings: SnapshotStore<TelegramSettingsState> }
  editEnabled(enabled: boolean): void
  editAdminUserId(value: string): void
  editToken(value: string): void
  save(): void
  testConnection(): void
}

export class TelegramSettingsController {
  private readonly store: SnapshotStore<TelegramSettingsState>
  private enabledDraft: boolean | undefined
  private adminDraft: string | undefined
  private tokenDraft = ''
  private tokenConfigured = false
  private tokenWritable = true
  private saving = false
  private error: string | undefined
  private testResult: string | undefined
  private runtime: RuntimeStatus = { state: 'disabled' }

  constructor(
    private readonly scope: SettingsScope<TelegramSettingsValue>,
    private readonly api: Pick<IApiClient, 'credentials'>,
  ) {
    this.store = createSnapshotStore(this.project())
    scope.subscribe(() => { this.publish() })
    void Promise.all([this.refreshCredential(), this.refreshStatus()])
  }

  inject(): TelegramSettingsFace {
    return {
      hooks: { telegramSettings: this.store },
      editEnabled: enabled => {
        this.enabledDraft = enabled
        this.error = undefined
        this.publish()
      },
      editAdminUserId: value => {
        this.adminDraft = value
        this.error = undefined
        this.publish()
      },
      editToken: value => {
        this.tokenDraft = value
        this.error = undefined
        this.publish()
      },
      save: () => { void this.save() },
      testConnection: () => { void this.testConnection() },
    }
  }

  refreshCredential(ref = TOKEN_REF): void {
    if (ref !== TOKEN_REF) return
    void this.readCredential()
  }

  private project(): TelegramSettingsState {
    const snapshot = this.scope.getSnapshot()
    const value = snapshot.value
    const enabled = this.enabledDraft ?? value?.enabled ?? false
    const adminUserIdDraft = this.adminDraft ?? (value?.adminUserId === undefined ? '' : String(value.adminUserId))
    const parsed = Number(adminUserIdDraft)
    const invalid = enabled && (!Number.isSafeInteger(parsed) || parsed <= 0 || (!this.tokenConfigured && this.tokenDraft.trim() === ''))
    const dirty = this.enabledDraft !== undefined || this.adminDraft !== undefined || this.tokenDraft.trim() !== ''
    return {
      available: snapshot.status === 'ready',
      writable: snapshot.writable,
      enabled,
      adminUserIdDraft,
      tokenDraft: this.tokenDraft,
      tokenConfigured: this.tokenConfigured,
      tokenWritable: this.tokenWritable,
      dirty,
      invalid,
      saving: this.saving,
      ...(this.error === undefined ? {} : { error: this.error }),
      ...(this.testResult === undefined ? {} : { testResult: this.testResult }),
      runtime: this.runtime,
    }
  }

  private publish(): void {
    this.store.set(this.project())
  }

  private async readCredential(): Promise<void> {
    try {
      const response = await this.api.credentials.describe({ refs: [TOKEN_REF] })
      if (!response.result.ok) return
      const view = response.result.value.credentials[TOKEN_REF]
      this.tokenConfigured = view?.configured ?? false
      this.tokenWritable = view?.writable ?? true
      this.publish()
    } catch {
      // The settings form remains usable; the Host remains authoritative on save.
    }
  }

  private async refreshStatus(): Promise<void> {
    try {
      const response = await fetch('/telegram-bot/status')
      if (!response.ok) return
      this.runtime = await response.json() as RuntimeStatus
      this.publish()
    } catch {
      // Preserve the last known state while the connection is unavailable.
    }
  }

  private async save(): Promise<void> {
    const state = this.project()
    if (!state.dirty || state.invalid || state.saving) return
    this.saving = true
    this.error = undefined
    this.testResult = undefined
    this.publish()
    try {
      const token = this.tokenDraft.trim()
      if (token !== '') await this.api.credentials.set({ ref: TOKEN_REF, value: token })
      const admin = Number(state.adminUserIdDraft)
      if (state.adminUserIdDraft.trim() !== '') await this.scope.set('adminUserId', admin)
      await this.scope.set('enabled', state.enabled)
      this.enabledDraft = undefined
      this.adminDraft = undefined
      this.tokenDraft = ''
      await this.readCredential()
      await this.refreshStatus()
    } catch (error) {
      this.error = error instanceof Error ? error.message : String(error)
    } finally {
      this.saving = false
      this.publish()
    }
  }

  private async testConnection(): Promise<void> {
    this.testResult = undefined
    this.error = undefined
    this.publish()
    try {
      const response = await fetch('/telegram-bot/test', { method: 'POST' })
      const result = await response.json() as { ok: boolean; bot?: string; error?: string }
      this.testResult = result.ok ? `连接成功：${result.bot ?? 'Telegram Bot'}` : `连接失败：${result.error ?? '未知错误'}`
      await this.refreshStatus()
    } catch (error) {
      this.error = error instanceof Error ? error.message : String(error)
    }
    this.publish()
  }
}
