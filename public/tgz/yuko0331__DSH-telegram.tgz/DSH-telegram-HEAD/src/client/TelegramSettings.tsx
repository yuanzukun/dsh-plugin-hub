import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { TelegramSettingsFace } from './controller.js'
import css from './TelegramSettings.module.css'

export type TelegramSettingsProps =
  PropsRuntime<'settings.section'>
  & PropsLocale<'settings.telegram'>
  & InjectFace<TelegramSettingsFace>

export function TelegramSettings(props: TelegramSettingsProps) {
  const state = props.useTelegramSettings(snapshot => snapshot)
  const { t } = props
  return (
    <section className={css.page}>
      <header>
        <h2>{t('title')}</h2>
        <p>{t('description')}</p>
      </header>

      <div className={css.status} data-state={state.runtime.state}>
        <strong>{t('status')}</strong>
        <span>{t(`state.${state.runtime.state}`)}</span>
        {state.runtime.detail === undefined ? null : <small>{state.runtime.detail}</small>}
      </div>

      <label className={css.switchRow}>
        <input
          type="checkbox"
          checked={state.enabled}
          disabled={!state.available || !state.writable || state.saving}
          onChange={event => props.editEnabled(event.target.checked)}
        />
        <span>{t('enabled')}</span>
      </label>

      <label className={css.field}>
        <span>{t('token')}</span>
        <input
          type="password"
          autoComplete="off"
          value={state.tokenDraft}
          disabled={!state.tokenWritable || state.saving}
          placeholder={state.tokenConfigured ? t('tokenConfigured') : t('tokenPlaceholder')}
          onChange={event => props.editToken(event.target.value)}
        />
        <small>{t('tokenHint')}</small>
      </label>

      <label className={css.field}>
        <span>{t('adminUserId')}</span>
        <input
          type="text"
          inputMode="numeric"
          value={state.adminUserIdDraft}
          disabled={!state.available || !state.writable || state.saving}
          onChange={event => props.editAdminUserId(event.target.value)}
        />
        <small>{t('adminUserIdHint')}</small>
      </label>

      {state.error === undefined ? null : <p className={css.error} role="alert">{state.error}</p>}
      {state.testResult === undefined ? null : <p className={css.result} role="status">{state.testResult}</p>}

      <div className={css.actions}>
        <button type="button" disabled={state.saving} onClick={props.testConnection}>{t('test')}</button>
        <button type="button" disabled={!state.dirty || state.invalid || state.saving} onClick={props.save}>
          {t(state.saving ? 'saving' : 'save')}
        </button>
      </div>
    </section>
  )
}
