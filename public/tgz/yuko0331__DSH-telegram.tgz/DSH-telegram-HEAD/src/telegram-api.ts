/** Minimal Telegram Bot API fields used by the plugin. */
export interface TelegramUser {
  id: number
  is_bot: boolean
  first_name: string
  username?: string
}

/** Telegram chat identity used as a reply destination. */
export interface TelegramChat {
  id: number
  type: 'private' | 'group' | 'supergroup' | 'channel'
}

/** Incoming text message accepted by the controller. */
export interface TelegramMessage {
  message_id: number
  from?: TelegramUser
  chat: TelegramChat
  text?: string
}

/** One Telegram long-poll update. */
export interface TelegramUpdate {
  update_id: number
  message?: TelegramMessage
}

/** Transport operations required by the DSH bridge. */
export interface TelegramApi {
  getMe(): Promise<TelegramUser>
  getUpdates(offset: number, timeoutSeconds: number, signal: AbortSignal): Promise<TelegramUpdate[]>
  sendMessage(chatId: number, text: string): Promise<void>
}

interface TelegramEnvelope<T> {
  ok: boolean
  result?: T
  description?: string
}

/** Telegram Bot API request failure. */
export class TelegramApiError extends Error {
  constructor(method: string, detail: string) {
    super(`Telegram ${method} failed: ${detail}`)
    this.name = 'TelegramApiError'
  }
}

/** HTTP implementation of the Telegram operations used by the plugin. */
export class HttpTelegramApi implements TelegramApi {
  private readonly baseUrl: string

  constructor(token: string, apiBaseUrl = 'https://api.telegram.org') {
    this.baseUrl = `${apiBaseUrl.replace(/\/$/, '')}/bot${token}`
  }

  async getMe(): Promise<TelegramUser> {
    return await this.call<TelegramUser>('getMe', {})
  }

  async getUpdates(offset: number, timeoutSeconds: number, signal: AbortSignal): Promise<TelegramUpdate[]> {
    return await this.call<TelegramUpdate[]>('getUpdates', {
      offset,
      timeout: timeoutSeconds,
      allowed_updates: ['message'],
    }, signal)
  }

  async sendMessage(chatId: number, text: string): Promise<void> {
    await this.call('sendMessage', {
      chat_id: chatId,
      text,
      disable_web_page_preview: true,
    })
  }

  private async call<T>(method: string, body: unknown, signal?: AbortSignal): Promise<T> {
    const response = await fetch(`${this.baseUrl}/${method}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
      ...(signal === undefined ? {} : { signal }),
    })
    const envelope = await response.json() as TelegramEnvelope<T>
    if (!response.ok || !envelope.ok || envelope.result === undefined) {
      throw new TelegramApiError(method, envelope.description ?? `HTTP ${response.status}`)
    }
    return envelope.result
  }
}
