# Changelog

All notable changes to this project are documented in this file.

## [0.4.1] - 2026-08-19

Fix — the plugin never activated, so "Galgame 生成模式" was missing and no game could be built:

- **Declare the cordis services `apply()` reads.** The host half declared only
  `inject = ['tools']` while reading `ctx.get('fs')` and `ctx.get('webServer')`.
  cordis only hands out an implementation whose providing fiber is already active, so
  those reads returned `undefined` and `apply()` returned early — silently registering
  **no model tools, no HTTP routes, and no agent preset**. `inject` is now
  `['tools', 'fs', 'webServer']`, so cordis waits for those services before calling
  `apply()`.
- **Warn instead of failing silently** when a required service is unavailable, so
  "the plugin looks uninstalled" can never again be a silent condition.
- Net effect: `galgame_scan` / `galgame_build` are registered, the player routes
  (`/galgame/api/load`, `/galgame/assets/*`) are served, and the 「Galgame 生成模式」
  agent preset is installed on first load.

## [0.4.0] - 2026-08-19

Fourth release — customizable title screen (开始界面) with a dedicated `img_ui/` asset directory:

- **New asset convention `img_ui/`** — title-screen art (title background, title music). The
  asset scanner now whitelists it, and standalone-HTML embedding includes it, so title art
  ships inside the `.galgame.html` like every other asset.
- **New optional `## 开始界面` section** in the script format: configure the game's start
  screen (title page) layout directly from the markdown:
  - `背景: img_ui/title.png` — title background image;
  - `音乐: audio/title.mp3` — title music (auto-stops when the game starts);
  - `显示人物: 是|否` — whether to show characters on the title page;
  - `布局: 立绘|头像` — characters as full standing figures positioned at the sides
    (`@ 左|中|右`) or as a row of avatar circles (default);
  - `人物: 小美 @ 右, 小明·开心 @ 左` — which characters appear (also `人物: 全部`),
    per-character position and expression variant.
- **Defaults preserved**: scripts without the section (or with fields omitted) keep exactly
  the current title look — gradient background, all characters as avatars, title/intro/buttons
  centered — so existing scripts and generated games are unaffected.
- Player + exported standalone HTML both honor the section; format documented in
  `docs/剧本格式.md` (「开始界面设计」).

## [0.3.0] - 2026-08-18

Third release — Galgame generation mode:

- **New: 🎬 Galgame 生成模式** — an agent preset the plugin installs into
  `~/.dsh/.agent-presets/galgame` on first load. Pick it in the new-session
  preset chip (or set as default in Settings → Agent Presets): sessions in the
  mode get an injected persona that auto-runs `galgame_scan` → `galgame_build`
  when you simply say 「生成」.
- The preset is a full copy of `standard` (full coding agent) with the
  generation-guidance persona; it never clobbers a user-edited preset.
- `agent-preset/` is now shipped in the package (`files`).

## [0.2.0] - 2026-08-18

Second release — stage control, animations, configurable saves and fixes:

- `img_cg/` asset convention: `[op]` opening, `[ed]` ending, `[cg]` CG illustration
  animations (gif / svg / mp4 / webm / avi).
- Configurable save slots: `[存档 N]` (1–20, default 9).
- Multi-pose characters: `名字·表情: 文件.png` variant sprites + `[表情 名字 表情名]`
  switching (saved with save data).
- Multi-character scenes: consecutive `[show 名字 @ 左|右]` lock several characters on
  stage; `[位置 名字 左|右|中]` re-positions them mid-dialogue (saved with save data).
- Hide aliases `[隐藏]`/`[取消显示]`/`[取消]`/`[移除]` and `[退场 名字]` (leave-until-`[show]`).
- Fixed asset scanning: only whitelisted asset dirs are collected, so unrelated
  folders no longer bloat the standalone HTML.
- Fixed binary embedding: manual base64 encoding (btoa in the host sandbox corrupts
  jpg/png/gif/wav by UTF-8 double-encoding bytes >= 0x80).

## [0.1.0] - 2026-08-17

Initial release — the Galgame generator plugin for DeepSeek Harness:

- Script parser: characters / backgrounds / dialogue / narration / choices /
  jumps / endings / variables & if-lines (`[if] … [else] … [endif]`).
- Speaker-following sprites: the current speaker's portrait shows, narration
  hides everyone, 0.35s fade (no flicker); `[show]` / `[hide]` lock explicitly.
- BGM control: `[bgm file]` play (loop), `[bgm off]` / `[bgm stop]` stop,
  `[bgm file 0.5]` volume.
- 9-slot save/load (localStorage) including progress, sprites, background,
  BGM and variables.
- Player: typewriter, auto/skip, backlog, endings; sidebar 🎮 button +
  full-screen overlay.
- Self-contained `<title>.galgame.html` export with embedded assets.
- Model tools: `galgame_scan` and `galgame_build`.
- Asset convention: script at workspace root, characters in `img_human/`,
  backgrounds in `img_bg/`, BGM in `audio/`.
