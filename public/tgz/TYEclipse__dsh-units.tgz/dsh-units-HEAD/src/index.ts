/**
 * dsh-units — unit conversion toolbox for DeepSeek Harness.
 *
 * Three tools, zero runtime dependencies (pure arithmetic):
 *   convert_unit — convert a value between two units of one category:
 *                  length, mass, temperature (affine C/F/K), area, volume
 *                  (incl. US cooking units), speed, time duration, data
 *                  size (decimal MB vs binary MiB), data transfer rate
 *                  (Mbps vs MB/s), acceleration (m/s², g-force),
 *                  illumination (lux, foot-candles), pressure, energy,
 *                  angle, frequency, power (mechanical/metric/electric
 *                  horsepower), force, torque, typography (px/pt/em/rem),
 *                  volumetric flow rate (m³/s, L/min, CFM, gpm), density
 *                  (kg/m³, g/cm³, lb/ft³), fuel economy (L/100km ↔ mpg).
 *   list_units   — discover every supported category, unit symbol and name.
 *   unit_price   — normalize 1–6 "price per unit" offers into one target
 *                  unit, rank them, and report the cheapest and the spread.
 *
 * Safety model: everything is pure synchronous math over a static unit
 * table — no network, no filesystem, no code execution. Invalid units,
 * cross-category pairs, and non-finite values are rejected with clear
 * errors. Results are rounded only for display.
 *
 * @module dsh-units
 */

import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import z from '@deepseek-ai/schemastery'
import { buildUnitsTools, type ToolSet } from './tools.ts'

/** Stable Cordis plugin name (also the config key under `plugins:`). */
export const name = 'dsh-units'

/** Services required before tool registration can start. */
export const inject = ['agents', 'tools']

/** Plugin configuration, resolved with defaults by the loader. */
export interface Config {
  /** Display rounding: decimals for magnitudes ≥ 1, significant digits below (1–12). */
  maxDecimals?: number
}

export const Config: z<Config> = z.object({
  maxDecimals: z.number().step(1).min(1).max(12).default(6),
})

/** Config with every default resolved (all fields guaranteed). */
export interface ResolvedConfig {
  maxDecimals: number
}

/** Resolve loader config into the effective runtime config. */
export function resolveConfig(config: Config): ResolvedConfig {
  return { maxDecimals: config.maxDecimals ?? 6 }
}

/** Register every dsh-units tool on one agent; returns the disposer. */
function decorate(agent: Agent, tools: ToolSet): () => void {
  const disposers = Object.values(tools).map((definition) => agent.ctx.tools.register(definition))
  return () => {
    for (const dispose of disposers) {
      try {
        dispose()
      } catch {
        // already disposed
      }
    }
  }
}

/** Mount the dsh-units tools on every live agent and every future one. */
export function apply(ctx: Context, config: Config): void {
  const resolved = resolveConfig(config)
  const tools = buildUnitsTools(resolved)
  const disposers = new Set<() => void>()

  const decorateAgent = (agent: Agent): void => {
    try {
      disposers.add(decorate(agent, tools))
    } catch (error) {
      ctx.logger('units').warn(`tool registration for agent ${agent.id} failed: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  for (const agent of ctx.agents.list()) decorateAgent(agent)
  const off = ctx.on('agent/created', ({ agent }) => decorateAgent(agent))

  ctx.effect(() => () => {
    off()
    for (const dispose of disposers) {
      try {
        dispose()
      } catch {
        // already disposed
      }
    }
    disposers.clear()
  })
}
