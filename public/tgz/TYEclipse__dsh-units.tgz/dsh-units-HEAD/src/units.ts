/**
 * Unit conversion engine for dsh-units.
 *
 * Pure, synchronous math over a static unit table — zero runtime
 * dependencies, fully offline, deterministic. Every category is expressed
 * through a base unit and per-unit factors, except temperature which uses
 * affine conversions (Celsius / Fahrenheit / Kelvin).
 *
 * @module dsh-units/units
 */

/** A linear unit: `factor` is how many base units this unit contains. */
export interface UnitDef {
  symbol: string
  name: string
  /** Base units per one of this unit (undefined for affine categories). */
  factor?: number
}

/** A unit category (dimension). */
export interface Category {
  id: string
  name: string
  base: string
  /**
   * 'linear' multiplies through the base unit; 'temperature' is affine;
   * 'fuel' is reciprocal (liters per 100 km vs. miles per gallon).
   */
  kind: 'linear' | 'temperature' | 'fuel'
  units: UnitDef[]
}

const L = (symbol: string, name: string, factor: number): UnitDef => ({ symbol, name, factor })

/**
 * The static unit table — the single source of every conversion factor.
 * (Count deliberately not written in prose: it drifted twice already.)
 */
export const CATEGORIES: readonly Category[] = [
  {
    id: 'length', name: 'length', base: 'meter', kind: 'linear',
    units: [
      L('km', 'kilometer', 1_000), L('m', 'meter', 1), L('cm', 'centimeter', 0.01),
      L('mm', 'millimeter', 0.001), L('um', 'micrometer', 1e-6), L('nm', 'nanometer', 1e-9),
      L('in', 'inch', 0.0254), L('ft', 'foot', 0.3048), L('yd', 'yard', 0.9144),
      L('mi', 'mile', 1609.344), L('nmi', 'nautical mile', 1852),
    ],
  },
  {
    id: 'mass', name: 'mass', base: 'kilogram', kind: 'linear',
    units: [
      L('t', 'tonne (metric)', 1_000), L('kg', 'kilogram', 1), L('g', 'gram', 0.001),
      L('mg', 'milligram', 1e-6), L('lb', 'pound', 0.45359237), L('oz', 'ounce', 0.028349523125),
    ],
  },
  {
    id: 'temperature', name: 'temperature', base: 'celsius', kind: 'temperature',
    units: [
      { symbol: 'c', name: 'celsius' },
      { symbol: 'f', name: 'fahrenheit' },
      { symbol: 'k', name: 'kelvin' },
    ],
  },
  {
    id: 'area', name: 'area', base: 'square meter', kind: 'linear',
    units: [
      L('km2', 'square kilometer', 1e6), L('ha', 'hectare', 1e4), L('m2', 'square meter', 1),
      L('cm2', 'square centimeter', 1e-4), L('mm2', 'square millimeter', 1e-6),
      L('mi2', 'square mile', 2_589_988.110336), L('acre', 'acre', 4046.8564224),
      L('yd2', 'square yard', 0.83612736), L('ft2', 'square foot', 0.09290304), L('in2', 'square inch', 0.00064516),
    ],
  },
  {
    id: 'volume', name: 'volume (incl. cooking)', base: 'liter', kind: 'linear',
    units: [
      L('m3', 'cubic meter', 1_000), L('l', 'liter', 1), L('ml', 'milliliter', 0.001),
      L('cm3', 'cubic centimeter', 0.001),
      L('gal', 'US gallon', 3.785411784), L('qt', 'US quart', 0.946352946),
      L('pint', 'US pint', 0.473176473), L('cup', 'US cup', 0.24),
      L('floz', 'US fluid ounce', 0.0295735295625), L('tbsp', 'tablespoon (US)', 0.01478676478125),
      L('tsp', 'teaspoon (US)', 0.00492892159375),
    ],
  },
  {
    id: 'speed', name: 'speed', base: 'meter per second', kind: 'linear',
    units: [
      L('km/h', 'kilometer per hour', 1 / 3.6), L('m/s', 'meter per second', 1),
      L('mph', 'mile per hour', 0.44704), L('knot', 'knot', 1852 / 3600),
      L('ft/s', 'foot per second', 0.3048),
    ],
  },
  {
    id: 'time', name: 'time duration', base: 'second', kind: 'linear',
    units: [
      L('yr', 'year (Julian, 365.25 days)', 31_557_600), L('wk', 'week', 604_800),
      L('d', 'day', 86_400), L('h', 'hour', 3_600), L('min', 'minute', 60),
      L('s', 'second', 1), L('ms', 'millisecond', 0.001),
    ],
  },
  {
    id: 'data', name: 'data size', base: 'bit', kind: 'linear',
    units: [
      L('tbit', 'terabit', 1e12), L('gbit', 'gigabit', 1e9), L('mbit', 'megabit', 1e6),
      L('kbit', 'kilobit', 1e3), L('bit', 'bit', 1),
      L('pb', 'petabyte (decimal)', 8e15), L('tb', 'terabyte (decimal)', 8e12),
      L('gb', 'gigabyte (decimal)', 8e9), L('mb', 'megabyte (decimal)', 8e6),
      L('kb', 'kilobyte (decimal)', 8e3), L('b', 'byte', 8),
      L('pib', 'pebibyte (binary)', 8 * 1024 ** 5), L('tib', 'tebibyte (binary)', 8 * 1024 ** 4),
      L('gib', 'gibibyte (binary)', 8 * 1024 ** 3), L('mib', 'mebibyte (binary)', 8 * 1024 ** 2),
      L('kib', 'kibibyte (binary)', 8 * 1024),
    ],
  },
  {
    id: 'pressure', name: 'pressure', base: 'pascal', kind: 'linear',
    units: [
      L('mpa', 'megapascal', 1e6), L('kpa', 'kilopascal', 1e3), L('bar', 'bar', 1e5),
      L('atm', 'standard atmosphere', 101_325), L('psi', 'pound per square inch', 6894.757293168),
      L('mmhg', 'millimeter of mercury', 133.322387415), L('torr', 'torr', 133.322368421),
      L('pa', 'pascal', 1),
    ],
  },
  {
    id: 'energy', name: 'energy', base: 'joule', kind: 'linear',
    units: [
      L('kwh', 'kilowatt-hour', 3.6e6), L('wh', 'watt-hour', 3_600), L('kcal', 'kilocalorie', 4_184),
      L('kj', 'kilojoule', 1e3), L('cal', 'calorie', 4.184), L('j', 'joule', 1),
      L('ev', 'electronvolt', 1.602176634e-19),
    ],
  },
  {
    id: 'angle', name: 'angle', base: 'radian', kind: 'linear',
    units: [
      L('deg', 'degree', Math.PI / 180), L('rad', 'radian', 1), L('grad', 'gradian (gon)', Math.PI / 200),
    ],
  },
  {
    id: 'frequency', name: 'frequency / rotation', base: 'hertz', kind: 'linear',
    units: [
      L('ghz', 'gigahertz', 1e9), L('mhz', 'megahertz', 1e6), L('khz', 'kilohertz', 1e3),
      L('hz', 'hertz', 1), L('rpm', 'revolution per minute', 1 / 60),
    ],
  },
  {
    // CSS/print typography at the standard 96 DPI reference: 1 pt = 1/72 in,
    // 1 px = 1/96 in, 1 pc (pica) = 12 pt. em/rem are resolved against the
    // common 16 px browser default base font size (a documented assumption).
    id: 'typography', name: 'typography (CSS / print)', base: 'pixel (96 dpi)', kind: 'linear',
    units: [
      L('px', 'pixel (96 dpi)', 1), L('pt', 'point (1/72 inch)', 96 / 72),
      L('pc', 'pica (12 pt)', 16), L('em', 'em (16 px base font)', 16),
      L('rem', 'rem (root em, 16 px base)', 16),
    ],
  },
  {
    // Fuel economy is reciprocal: L/100km and km/L are inverse-style measures
    // versus miles per gallon, so it gets its own conversion kind.
    id: 'fuel', name: 'fuel economy', base: 'liter per 100 km', kind: 'fuel',
    units: [
      { symbol: 'l/100km', name: 'liters per 100 km' },
      { symbol: 'l/km', name: 'liters per km' },
      { symbol: 'mpg', name: 'miles per US gallon' },
      { symbol: 'mpg(uk)', name: 'miles per imperial (UK) gallon' },
      { symbol: 'km/l', name: 'kilometers per liter' },
    ],
  },
  {
    // Mechanical power: three different "horsepower" definitions coexist —
    // mechanical (550 ft·lbf/s), metric (PS, 75 kgf·m/s) and electric (746 W).
    id: 'power', name: 'power', base: 'watt', kind: 'linear',
    units: [
      L('mw', 'megawatt', 1e6), L('kw', 'kilowatt', 1e3), L('w', 'watt', 1),
      L('hp', 'horsepower (mechanical)', 550 * 0.45359237 * 9.80665 * 0.3048),
      L('hp(m)', 'metric horsepower (PS)', 735.49875),
      L('hp(e)', 'electric horsepower', 746),
      L('btu/h', 'BTU per hour (IT)', 1055.05585262 / 3600),
      L('ftlb/s', 'foot-pound per second', 0.45359237 * 9.80665 * 0.3048),
    ],
  },
  {
    // Force: lbf and kgf are weight-based forces at standard gravity
    // (g₀ = 9.80665 m/s²). "kn" as typed input resolves to knot (speed) —
    // kilonewton is reachable by its full name (see aliases).
    id: 'force', name: 'force', base: 'newton', kind: 'linear',
    units: [
      L('kn', 'kilonewton', 1e3), L('n', 'newton', 1), L('dyn', 'dyne', 1e-5),
      L('lbf', 'pound-force', 0.45359237 * 9.80665),
      L('kgf', 'kilogram-force (kp)', 9.80665),
      L('gf', 'gram-force', 0.00980665),
    ],
  },
  {
    // Torque: force × length. The symbol is "n.m" because "nm" is the
    // nanometer in the length category — resolve by symbol or full name.
    id: 'torque', name: 'torque', base: 'newton meter', kind: 'linear',
    units: [
      L('n.m', 'newton meter', 1),
      L('kgf.m', 'kilogram-force meter', 9.80665),
      L('lbfft', 'pound-force foot', 0.45359237 * 9.80665 * 0.3048),
      L('lbfin', 'pound-force inch', (0.45359237 * 9.80665 * 0.3048) / 12),
    ],
  },
  {
    // Data transfer rate — NOT size. The classic mix-up: network speeds are
    // decimal bits per second (100 Mbps), file transfers decimal bytes per
    // second (12.5 MB/s), and binary prefixes (MiB/s) mean 1024-based rates.
    // 'mb/s' follows the data category's rule that mb = megabyte; megabits
    // are mbit/s (aliases: Mbps, kbps, …).
    id: 'datarate', name: 'data transfer rate', base: 'bit per second', kind: 'linear',
    units: [
      L('tbit/s', 'terabit per second', 1e12), L('gbit/s', 'gigabit per second', 1e9),
      L('mbit/s', 'megabit per second', 1e6), L('kbit/s', 'kilobit per second', 1e3),
      L('bit/s', 'bit per second', 1),
      L('tb/s', 'terabyte per second (decimal)', 8e12), L('gb/s', 'gigabyte per second (decimal)', 8e9),
      L('mb/s', 'megabyte per second (decimal)', 8e6), L('kb/s', 'kilobyte per second (decimal)', 8e3),
      L('b/s', 'byte per second', 8),
      L('tib/s', 'tebibyte per second (binary)', 8 * 1024 ** 4),
      L('gib/s', 'gibibyte per second (binary)', 8 * 1024 ** 3),
      L('mib/s', 'mebibyte per second (binary)', 8 * 1024 ** 2),
      L('kib/s', 'kibibyte per second (binary)', 8 * 1024),
    ],
  },
  {
    // Acceleration: standard gravity g₀ = 9.80665 m/s² is the reference behind
    // every g-force figure. 'g' as typed input stays the gram (mass) — reach
    // gravity via 'g0' / 'gravity' / 'g-force'.
    id: 'acceleration', name: 'acceleration', base: 'meter per second squared', kind: 'linear',
    units: [
      L('m/s2', 'meter per second squared', 1),
      L('g0', 'standard gravity (9.80665 m/s²)', 9.80665),
      L('ft/s2', 'foot per second squared', 0.3048),
      L('mph/s', 'mile per hour per second', 0.44704),
    ],
  },
  {
    // Illumination: lux (SI), foot-candle (1 lm/ft² — the photography unit)
    // and phot. All pure ratios against lux.
    id: 'illumination', name: 'illumination', base: 'lux', kind: 'linear',
    units: [
      L('klx', 'kilolux', 1e3), L('lx', 'lux (lumen per square meter)', 1),
      L('fc', 'foot-candle (lumen per square foot)', 1 / 0.09290304),
      L('ph', 'phot', 1e4),
    ],
  },
  {
    // Volumetric flow rate: the SI base is m³/s; cfm (cubic feet per minute)
    // and gpm (US gallons per minute) are the HVAC / plumbing units. Note that
    // "l/min" is a flow, not a volume — volumes stay in the volume category.
    id: 'flow', name: 'volumetric flow rate', base: 'cubic meter per second', kind: 'linear',
    units: [
      L('m3/s', 'cubic meter per second', 1), L('m3/h', 'cubic meter per hour', 1 / 3600),
      L('l/s', 'liter per second', 0.001), L('l/min', 'liter per minute', 0.001 / 60),
      L('l/h', 'liter per hour', 0.001 / 3600),
      L('cfm', 'cubic foot per minute', 0.3048 ** 3 / 60),
      L('gpm', 'US gallon per minute', 3.785411784 / 60_000),
    ],
  },
  {
    // Density: the SI base is kg/m³. 'g/l' is numerically identical to kg/m³
    // (1 g/L = 1 kg/m³); g/cm³ = g/mL = kg/L = t/m³ = 1000 kg/m³. lb/ft³ and
    // lb/US gallon are the imperial units.
    id: 'density', name: 'density', base: 'kilogram per cubic meter', kind: 'linear',
    units: [
      L('kg/m3', 'kilogram per cubic meter', 1), L('g/l', 'gram per liter', 1),
      L('g/cm3', 'gram per cubic centimeter', 1_000), L('g/ml', 'gram per milliliter', 1_000),
      L('kg/l', 'kilogram per liter', 1_000), L('t/m3', 'tonne per cubic meter', 1_000),
      L('lb/ft3', 'pound per cubic foot', 0.45359237 / 0.3048 ** 3),
      L('lb/gal', 'pound per US gallon', 0.45359237 * 1_000 / 3.785411784),
    ],
  },
]

/** Exact fuel-economy anchors: US gallon = 3.785411784 L, imperial gallon =
 * 4.54609 L, mile = 1.609344 km. L/100km per 1 mpg = 100 × gallon / mile. */
const L100KM_PER_MPG_US = (100 * 3.785411784) / 1.609344 // ≈ 235.214583
const L100KM_PER_MPG_UK = (100 * 4.54609) / 1.609344 // ≈ 282.480936

/** Fuel economy → base (L/100km). */
function fuelToBase(value: number, symbol: string): number {
  switch (symbol) {
    case 'l/100km': return value
    case 'l/km': return value * 100
    case 'mpg': return L100KM_PER_MPG_US / value
    case 'mpg(uk)': return L100KM_PER_MPG_UK / value
    case 'km/l': return 100 / value
    default: throw new Error(`internal: unsupported fuel unit "${symbol}"`)
  }
}

/** Base (L/100km) → fuel economy unit. */
function fuelFromBase(value: number, symbol: string): number {
  switch (symbol) {
    case 'l/100km': return value
    case 'l/km': return value / 100
    case 'mpg': return L100KM_PER_MPG_US / value
    case 'mpg(uk)': return L100KM_PER_MPG_UK / value
    case 'km/l': return 100 / value
    default: throw new Error(`internal: unsupported fuel unit "${symbol}"`)
  }
}

/** Human-readable recipe of a unit → base step (x = input value). */
function fuelToBaseText(symbol: string): string {
  switch (symbol) {
    case 'l/km': return 'x × 100'
    case 'mpg': return `${roundForFormula(L100KM_PER_MPG_US)} ÷ x`
    case 'mpg(uk)': return `${roundForFormula(L100KM_PER_MPG_UK)} ÷ x`
    case 'km/l': return '100 ÷ x'
    default: return 'x'
  }
}

/** Human-readable recipe of a base → unit step (x = base value). */
function fuelFromBaseText(symbol: string): string {
  switch (symbol) {
    case 'l/km': return 'x ÷ 100'
    case 'mpg': return `${roundForFormula(L100KM_PER_MPG_US)} ÷ x`
    case 'mpg(uk)': return `${roundForFormula(L100KM_PER_MPG_UK)} ÷ x`
    case 'km/l': return '100 ÷ x'
    default: return 'x'
  }
}

/** Round a constant for display inside a formula string. */
function roundForFormula(value: number): string {
  return String(Number(value.toFixed(6)))
}

/**
 * Alias table: normalized user input → canonical unit symbol.
 * Normalization lowercases, trims, strips spaces and the degree sign, and
 * folds unicode ²/³ (and caret notation) into plain digits.
 */
const ALIASES = new Map<string, string>([
  // length
  ['m', 'm'], ['meter', 'm'], ['meters', 'm'], ['metre', 'm'], ['metres', 'm'],
  ['km', 'km'], ['kilometer', 'km'], ['kilometers', 'km'], ['kilometre', 'km'], ['kilometres', 'km'],
  ['cm', 'cm'], ['centimeter', 'cm'], ['centimeters', 'cm'], ['centimetre', 'cm'], ['centimetres', 'cm'],
  ['mm', 'mm'], ['millimeter', 'mm'], ['millimeters', 'mm'], ['millimetre', 'mm'], ['millimetres', 'mm'],
  ['um', 'um'], ['micron', 'um'], ['microns', 'um'], ['micrometer', 'um'], ['micrometers', 'um'],
  ['nm', 'nm'], ['nanometer', 'nm'], ['nanometers', 'nm'],
  ['in', 'in'], ['inch', 'in'], ['inches', 'in'],
  ['ft', 'ft'], ['foot', 'ft'], ['feet', 'ft'],
  ['yd', 'yd'], ['yard', 'yd'], ['yards', 'yd'],
  ['mi', 'mi'], ['mile', 'mi'], ['miles', 'mi'],
  ['nmi', 'nmi'], ['nauticalmile', 'nmi'], ['nauticalmiles', 'nmi'],
  // mass
  ['kg', 'kg'], ['kilogram', 'kg'], ['kilograms', 'kg'],
  ['g', 'g'], ['gram', 'g'], ['grams', 'g'],
  ['mg', 'mg'], ['milligram', 'mg'], ['milligrams', 'mg'],
  ['t', 't'], ['tonne', 't'], ['tonnes', 't'], ['ton', 't'], ['tons', 't'], ['metrictons', 't'],
  ['lb', 'lb'], ['lbs', 'lb'], ['pound', 'lb'], ['pounds', 'lb'],
  ['oz', 'oz'], ['ounce', 'oz'], ['ounces', 'oz'],
  // temperature
  ['c', 'c'], ['celsius', 'c'], ['f', 'f'], ['fahrenheit', 'f'], ['k', 'k'], ['kelvin', 'k'],
  // area
  ['m2', 'm2'], ['sqm', 'm2'], ['squaremeter', 'm2'], ['squaremeters', 'm2'],
  ['km2', 'km2'], ['sqkm', 'km2'], ['squarekilometer', 'km2'], ['squarekilometers', 'km2'],
  ['cm2', 'cm2'], ['sqcm', 'cm2'], ['mm2', 'mm2'], ['sqmm', 'mm2'],
  ['mi2', 'mi2'], ['sqmi', 'mi2'], ['squaremile', 'mi2'], ['squaremiles', 'mi2'],
  ['yd2', 'yd2'], ['sqyd', 'yd2'], ['ft2', 'ft2'], ['sqft', 'ft2'], ['squarefoot', 'ft2'], ['squarefeet', 'ft2'],
  ['in2', 'in2'], ['sqin', 'in2'], ['squareinch', 'in2'], ['squareinches', 'in2'],
  ['ha', 'ha'], ['hectare', 'ha'], ['hectares', 'ha'],
  ['acre', 'acre'], ['acres', 'acre'],
  // volume
  ['m3', 'm3'], ['cubicmeter', 'm3'], ['cubicmeters', 'm3'],
  ['l', 'l'], ['liter', 'l'], ['liters', 'l'], ['litre', 'l'], ['litres', 'l'],
  ['ml', 'ml'], ['milliliter', 'ml'], ['milliliters', 'ml'],
  ['cm3', 'cm3'], ['cc', 'cm3'], ['cubiccentimeter', 'cm3'],
  ['gal', 'gal'], ['gallon', 'gal'], ['gallons', 'gal'],
  ['qt', 'qt'], ['quart', 'qt'], ['quarts', 'qt'],
  ['pint', 'pint'], ['pints', 'pint'],
  ['cup', 'cup'], ['cups', 'cup'],
  ['floz', 'floz'], ['fluidounce', 'floz'], ['fluidounces', 'floz'],
  ['tbsp', 'tbsp'], ['tablespoon', 'tbsp'], ['tablespoons', 'tbsp'],
  ['tsp', 'tsp'], ['teaspoon', 'tsp'], ['teaspoons', 'tsp'],
  // speed
  ['m/s', 'm/s'], ['mps', 'm/s'], ['meterspersecond', 'm/s'], ['meterpersecond', 'm/s'],
  ['km/h', 'km/h'], ['kmh', 'km/h'], ['kph', 'km/h'],
  ['mph', 'mph'], ['milesperhour', 'mph'],
  ['knot', 'knot'], ['knots', 'knot'], ['kn', 'knot'],
  ['ft/s', 'ft/s'], ['fps', 'ft/s'], ['feetpersecond', 'ft/s'],
  // time
  ['yr', 'yr'], ['year', 'yr'], ['years', 'yr'],
  ['wk', 'wk'], ['week', 'wk'], ['weeks', 'wk'],
  ['d', 'd'], ['day', 'd'], ['days', 'd'],
  ['h', 'h'], ['hr', 'h'], ['hour', 'h'], ['hours', 'h'],
  ['min', 'min'], ['minute', 'min'], ['minutes', 'min'],
  ['s', 's'], ['sec', 's'], ['second', 's'], ['seconds', 's'],
  ['ms', 'ms'], ['millisecond', 'ms'], ['milliseconds', 'ms'],
  // data
  ['tbit', 'tbit'], ['terabit', 'tbit'], ['terabits', 'tbit'],
  ['gbit', 'gbit'], ['gigabit', 'gbit'], ['gigabits', 'gbit'],
  ['mbit', 'mbit'], ['megabit', 'mbit'], ['megabits', 'mbit'],
  ['kbit', 'kbit'], ['kilobit', 'kbit'], ['kilobits', 'kbit'],
  ['bit', 'bit'], ['bits', 'bit'],
  ['b', 'b'], ['byte', 'b'], ['bytes', 'b'],
  ['pb', 'pb'], ['petabyte', 'pb'], ['petabytes', 'pb'],
  ['tb', 'tb'], ['terabyte', 'tb'], ['terabytes', 'tb'],
  ['gb', 'gb'], ['gigabyte', 'gb'], ['gigabytes', 'gb'],
  ['mb', 'mb'], ['megabyte', 'mb'], ['megabytes', 'mb'],
  ['kb', 'kb'], ['kilobyte', 'kb'], ['kilobytes', 'kb'],
  ['pib', 'pib'], ['pebibyte', 'pib'], ['pebibytes', 'pib'],
  ['tib', 'tib'], ['tebibyte', 'tib'], ['tebibytes', 'tib'],
  ['gib', 'gib'], ['gibibyte', 'gib'], ['gibibytes', 'gib'],
  ['mib', 'mib'], ['mebibyte', 'mib'], ['mebibytes', 'mib'],
  ['kib', 'kib'], ['kibibyte', 'kib'], ['kibibytes', 'kib'],
  // pressure
  ['mpa', 'mpa'], ['megapascal', 'mpa'], ['megapascals', 'mpa'],
  ['kpa', 'kpa'], ['kilopascal', 'kpa'], ['kilopascals', 'kpa'],
  ['pa', 'pa'], ['pascal', 'pa'], ['pascals', 'pa'],
  ['bar', 'bar'], ['bars', 'bar'],
  ['atm', 'atm'], ['atmosphere', 'atm'], ['atmospheres', 'atm'],
  ['psi', 'psi'],
  ['mmhg', 'mmhg'], ['torr', 'torr'],
  // energy
  ['kwh', 'kwh'], ['kilowatthour', 'kwh'], ['kilowatthours', 'kwh'],
  ['wh', 'wh'], ['watthour', 'wh'], ['watthours', 'wh'],
  ['kcal', 'kcal'], ['kilocalorie', 'kcal'], ['kilocalories', 'kcal'],
  ['kj', 'kj'], ['kilojoule', 'kj'], ['kilojoules', 'kj'],
  ['cal', 'cal'], ['calorie', 'cal'], ['calories', 'cal'],
  ['j', 'j'], ['joule', 'j'], ['joules', 'j'],
  ['ev', 'ev'], ['electronvolt', 'ev'], ['electronvolts', 'ev'],
  // angle
  ['deg', 'deg'], ['degree', 'deg'], ['degrees', 'deg'],
  ['rad', 'rad'], ['radian', 'rad'], ['radians', 'rad'],
  ['grad', 'grad'], ['gon', 'grad'],
  // frequency
  ['ghz', 'ghz'], ['gigahertz', 'ghz'],
  ['mhz', 'mhz'], ['megahertz', 'mhz'],
  ['khz', 'khz'], ['kilohertz', 'khz'],
  ['hz', 'hz'], ['hertz', 'hz'],
  ['rpm', 'rpm'],
  // typography (CSS / print)
  ['px', 'px'], ['pixel', 'px'], ['pixels', 'px'],
  ['pt', 'pt'], ['point', 'pt'], ['points', 'pt'],
  ['pc', 'pc'], ['pica', 'pc'], ['picas', 'pc'],
  ['em', 'em'], ['ems', 'em'],
  ['rem', 'rem'], ['rems', 'rem'],
  // fuel economy
  ['l/100km', 'l/100km'], ['l100km', 'l/100km'],
  ['litersper100km', 'l/100km'], ['litresper100km', 'l/100km'],
  ['litersper100kilometers', 'l/100km'],
  ['l/km', 'l/km'], ['lkm', 'l/km'], ['litersperkm', 'l/km'], ['litersperkilometer', 'l/km'],
  ['mpg', 'mpg'], ['usmpg', 'mpg'], ['mpgus', 'mpg'], ['mpg(us)', 'mpg'],
  ['mpg(uk)', 'mpg(uk)'], ['mpguk', 'mpg(uk)'], ['ukmpg', 'mpg(uk)'], ['imperialmpg', 'mpg(uk)'],
  ['km/l', 'km/l'], ['kml', 'km/l'], ['kmpl', 'km/l'],
  ['kilometersperliter', 'km/l'], ['kmperliter', 'km/l'],
  // power
  ['mw', 'mw'], ['megawatt', 'mw'], ['megawatts', 'mw'],
  ['kw', 'kw'], ['kilowatt', 'kw'], ['kilowatts', 'kw'],
  ['w', 'w'], ['watt', 'w'], ['watts', 'w'],
  ['hp', 'hp'], ['horsepower', 'hp'],
  ['hp(m)', 'hp(m)'], ['ps', 'hp(m)'], ['cv', 'hp(m)'], ['metrichorsepower', 'hp(m)'],
  ['hp(e)', 'hp(e)'], ['ehp', 'hp(e)'], ['electrichorsepower', 'hp(e)'],
  ['btu/h', 'btu/h'], ['btuh', 'btu/h'], ['btuperhour', 'btu/h'],
  ['ftlb/s', 'ftlb/s'], ['ftlbs', 'ftlb/s'], ['ftlbfs', 'ftlb/s'],
  // force
  ['kilonewton', 'kn'], ['kilonewtons', 'kn'], // "kn" input stays the speed alias (knot)
  ['n', 'n'], ['newton', 'n'], ['newtons', 'n'],
  ['dyn', 'dyn'], ['dyne', 'dyn'], ['dynes', 'dyn'],
  ['lbf', 'lbf'], ['poundforce', 'lbf'], ['poundforces', 'lbf'], ['lbforce', 'lbf'],
  ['kgf', 'kgf'], ['kilogramforce', 'kgf'], ['kilogramforces', 'kgf'], ['kgforce', 'kgf'],
  ['kp', 'kgf'], ['kilopond', 'kgf'], ['kiloponds', 'kgf'],
  ['gf', 'gf'], ['gramforce', 'gf'], ['gramforces', 'gf'],
  // torque
  ['n.m', 'n.m'], ['n·m', 'n.m'],
  ['newtonmeter', 'n.m'], ['newtonmeters', 'n.m'], ['newtonmetre', 'n.m'], ['newtonmetres', 'n.m'],
  ['newton-meter', 'n.m'], ['newton-meters', 'n.m'],
  ['kgf.m', 'kgf.m'], ['kgf·m', 'kgf.m'], ['kgfm', 'kgf.m'],
  ['kilogramforcemeter', 'kgf.m'], ['kilogramforcemeters', 'kgf.m'],
  ['lbfft', 'lbfft'], ['ftlb', 'lbfft'], ['footpound', 'lbfft'], ['footpounds', 'lbfft'], ['lb-ft', 'lbfft'],
  ['lbfin', 'lbfin'], ['lbf.in', 'lbfin'],
  // data transfer rate
  ['bit/s', 'bit/s'], ['bits/s', 'bit/s'], ['bitpersecond', 'bit/s'], ['bitspersecond', 'bit/s'], ['bps', 'bit/s'],
  ['kbit/s', 'kbit/s'], ['kbits/s', 'kbit/s'], ['kilobitpersecond', 'kbit/s'], ['kilobitspersecond', 'kbit/s'], ['kbps', 'kbit/s'],
  ['mbit/s', 'mbit/s'], ['mbits/s', 'mbit/s'], ['megabitpersecond', 'mbit/s'], ['megabitspersecond', 'mbit/s'], ['mbps', 'mbit/s'],
  ['gbit/s', 'gbit/s'], ['gbits/s', 'gbit/s'], ['gigabitpersecond', 'gbit/s'], ['gigabitspersecond', 'gbit/s'], ['gbps', 'gbit/s'],
  ['tbit/s', 'tbit/s'], ['tbits/s', 'tbit/s'], ['terabitpersecond', 'tbit/s'], ['terabitspersecond', 'tbit/s'], ['tbps', 'tbit/s'],
  ['b/s', 'b/s'], ['bytes/s', 'b/s'], ['bytepersecond', 'b/s'], ['bytespersecond', 'b/s'],
  ['kb/s', 'kb/s'], ['kilobytepersecond', 'kb/s'], ['kilobytespersecond', 'kb/s'],
  ['mb/s', 'mb/s'], ['megabytepersecond', 'mb/s'], ['megabytespersecond', 'mb/s'],
  ['gb/s', 'gb/s'], ['gigabytepersecond', 'gb/s'], ['gigabytespersecond', 'gb/s'],
  ['tb/s', 'tb/s'], ['terabytepersecond', 'tb/s'], ['terabytespersecond', 'tb/s'],
  ['kib/s', 'kib/s'], ['kibibytepersecond', 'kib/s'], ['kibibytespersecond', 'kib/s'],
  ['mib/s', 'mib/s'], ['mebibytepersecond', 'mib/s'], ['mebibytespersecond', 'mib/s'],
  ['gib/s', 'gib/s'], ['gibibytepersecond', 'gib/s'], ['gibibytespersecond', 'gib/s'],
  ['tib/s', 'tib/s'], ['tebibytepersecond', 'tib/s'], ['tebibytespersecond', 'tib/s'],
  // acceleration
  ['m/s2', 'm/s2'], ['mps2', 'm/s2'], ['meterpersecondsquared', 'm/s2'], ['meterspersecondsquared', 'm/s2'],
  ['metrepersecondsquared', 'm/s2'], ['metrespersecondsquared', 'm/s2'],
  ['g0', 'g0'], ['gn', 'g0'], ['gravity', 'g0'], ['standardgravity', 'g0'], ['gforce', 'g0'], ['g-force', 'g0'],
  ['ft/s2', 'ft/s2'], ['fps2', 'ft/s2'], ['footpersecondsquared', 'ft/s2'], ['feetpersecondsquared', 'ft/s2'],
  ['mph/s', 'mph/s'], ['mphpersecond', 'mph/s'], ['milesperhourpersecond', 'mph/s'],
  // illumination
  ['lx', 'lx'], ['lux', 'lx'], ['lumenpersquaremeter', 'lx'], ['lumenspersquaremeter', 'lx'],
  ['klx', 'klx'], ['kilolux', 'klx'],
  ['fc', 'fc'], ['footcandle', 'fc'], ['footcandles', 'fc'], ['lumenpersquarefoot', 'fc'], ['lumenspersquarefoot', 'fc'],
  ['ph', 'ph'], ['phot', 'ph'], ['phots', 'ph'],
  // flow rate
  ['m3/s', 'm3/s'], ['cubicmeterpersecond', 'm3/s'], ['cumecs', 'm3/s'],
  ['m3/h', 'm3/h'], ['cubicmeterperhour', 'm3/h'], ['cubicmetersperhour', 'm3/h'],
  ['l/s', 'l/s'], ['literpersecond', 'l/s'], ['literspersecond', 'l/s'], ['lps', 'l/s'],
  ['l/min', 'l/min'], ['literperminute', 'l/min'], ['litersperminute', 'l/min'], ['lpm', 'l/min'],
  ['l/h', 'l/h'], ['literperhour', 'l/h'], ['litersperhour', 'l/h'],
  ['cfm', 'cfm'], ['cubicfootperminute', 'cfm'], ['cubicfeetperminute', 'cfm'],
  ['gpm', 'gpm'], ['gallonsperminute', 'gpm'], ['usgallonsperminute', 'gpm'],
  // density
  ['kg/m3', 'kg/m3'], ['kilogrampercubicmeter', 'kg/m3'], ['kgpercubicmeter', 'kg/m3'],
  ['g/l', 'g/l'], ['gramperliter', 'g/l'], ['gramsperliter', 'g/l'], ['gramperlitre', 'g/l'],
  ['g/cm3', 'g/cm3'], ['grampercubiccentimeter', 'g/cm3'], ['gramspercubiccentimeter', 'g/cm3'],
  ['g/ml', 'g/ml'], ['grampermilliliter', 'g/ml'], ['gramspermilliliter', 'g/ml'],
  ['kg/l', 'kg/l'], ['kilogramperliter', 'kg/l'], ['kilogramsperliter', 'kg/l'],
  ['t/m3', 't/m3'], ['tonnepercubicmeter', 't/m3'], ['tonnespercubicmeter', 't/m3'],
  ['lb/ft3', 'lb/ft3'], ['poundpercubicfoot', 'lb/ft3'], ['poundspercubicfoot', 'lb/ft3'],
  ['lb/gal', 'lb/gal'], ['poundpergallon', 'lb/gal'], ['poundspergallon', 'lb/gal'],
])

/** Normalize raw user input into an alias-table key. */
function normalize(raw: string): string {
  let text = raw.trim().toLowerCase()
  text = text.replace(/\s+/g, '')
  text = text.replace(/°/g, '')
  text = text.replace(/\u00b2/g, '2').replace(/\u00b3/g, '3')
  text = text.replace(/\^/g, '')
  text = text.replace(/\u03bc/g, 'u').replace(/\u00b5/g, 'u') // µ (both codepoints) → u
  return text
}

/** Find the category and unit for a user-supplied unit string. */
export function resolveUnit(raw: string): { category: Category; unit: UnitDef } {
  const key = normalize(raw)
  const symbol = ALIASES.get(key)
  if (symbol === undefined) {
    throw new Error(`unknown unit "${raw}". Use list_units to see supported units ` +
      `(${CATEGORIES.map((cat) => cat.id).join(', ')})`)
  }
  const category = CATEGORIES.find((cat) => cat.units.some((unit) => unit.symbol === symbol))
  if (category === undefined) {
    // Defensive: every alias maps to a real unit symbol.
    throw new Error(`internal: unit symbol "${symbol}" not found in the unit table`)
  }
  const unit = category.units.find((entry) => entry.symbol === symbol)
  if (unit === undefined) {
    throw new Error(`internal: unit symbol "${symbol}" missing from category "${category.id}"`)
  }
  return { category, unit }
}

/** Convert a Celsius value to Fahrenheit / Kelvin (canonical temperature helpers). */
function celsiusTo(value: number, target: string): number {
  switch (target) {
    case 'c': return value
    case 'f': return (value * 9) / 5 + 32
    case 'k': return value + 273.15
    default: throw new Error(`internal: unsupported temperature unit "${target}"`)
  }
}

/** Convert a Fahrenheit / Kelvin value to Celsius. */
function toCelsius(value: number, source: string): number {
  switch (source) {
    case 'c': return value
    case 'f': return ((value - 32) * 5) / 9
    case 'k': return value - 273.15
    default: throw new Error(`internal: unsupported temperature unit "${source}"`)
  }
}

const TEMP_FORMULAS: Readonly<Record<string, string>> = {
  'c->f': '× 9/5 + 32',
  'c->k': '+ 273.15',
  'f->c': '(x − 32) × 5/9',
  'f->k': '(x − 32) × 5/9 + 273.15',
  'k->c': '− 273.15',
  'k->f': '(x − 273.15) × 9/5 + 32',
}

/** Round for display: decimals for magnitudes ≥ 1, significant digits below. */
function roundValue(value: number, maxDecimals: number): number {
  if (!Number.isFinite(value)) return value
  if (value === 0) return 0
  const magnitude = Math.abs(value)
  if (magnitude >= 1) return Number(value.toFixed(maxDecimals))
  return Number(value.toPrecision(maxDecimals))
}

/** Result of a successful conversion. */
export interface ConversionResult {
  value: number
  from_unit: string
  from_symbol: string
  to_unit: string
  to_symbol: string
  result: number
  formula: string
  category: string
}

/**
 * Convert a numeric value between two units of the same category.
 * Throws on unknown units, cross-category pairs, or non-finite values.
 */
export function convert(value: number, fromRaw: string, toRaw: string, maxDecimals = 6): ConversionResult {
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw new Error(`value must be a finite number (got ${String(value)})`)
  }
  const from = resolveUnit(fromRaw)
  const to = resolveUnit(toRaw)
  if (from.category.id !== to.category.id) {
    throw new Error(`cannot convert ${from.unit.name} (${from.category.name}) to ${to.unit.name} ` +
      `(${to.category.name}) — units must share a category`)
  }

  let result: number
  let formula: string
  if (from.category.kind === 'temperature') {
    result = celsiusTo(toCelsius(value, from.unit.symbol), to.unit.symbol)
    formula = TEMP_FORMULAS[`${from.unit.symbol}->${to.unit.symbol}`] ?? '× 1'
  } else if (from.category.kind === 'fuel') {
    result = fuelFromBase(fuelToBase(value, from.unit.symbol), to.unit.symbol)
    formula = `${fuelToBaseText(from.unit.symbol)} → ${fuelFromBaseText(to.unit.symbol)}`
  } else {
    const fromFactor = from.unit.factor
    const toFactor = to.unit.factor
    if (fromFactor === undefined || toFactor === undefined) {
      throw new Error(`internal: linear category "${from.category.id}" has a unit without a factor`)
    }
    result = (value * fromFactor) / toFactor
    formula = fromFactor === toFactor ? '× 1' : `× ${fromFactor / toFactor}`
  }

  return {
    value,
    from_unit: from.unit.name,
    from_symbol: from.unit.symbol,
    to_unit: to.unit.name,
    to_symbol: to.unit.symbol,
    result: roundValue(result, maxDecimals),
    formula,
    category: from.category.name,
  }
}

/** One offer for unit-price math: `price` buys `quantity` (default 1) of `per`. */
export interface PriceOffer {
  price: number
  per: string
  quantity?: number
}

/** One normalized offer inside a unit-price comparison. */
export interface PriceQuote {
  index: number
  price: number
  quantity: number
  per_unit: string
  per_symbol: string
  /** How many target units this offer covers. */
  total_target: number
  /** Price of one target unit (rounded for display). */
  price_per_target: number
  formula: string
}

/** Result of a unit-price normalization (one offer) or comparison (several). */
export interface PriceComparison {
  category: string
  target_unit: string
  target_symbol: string
  offers: PriceQuote[]
  /** 0-based index of the cheapest offer; ties keep the earliest offer. */
  best_index: number
  best_price_per_target: number
  /** How much cheaper the best offer is than the dearest, in percent (0 when equal). */
  spread_percent: number
}

/** Upper bound on offers per unit_price call. */
export const MAX_PRICE_OFFERS = 6

/** The factor-1 unit that a linear category is expressed in. */
function baseUnitOf(category: Category): UnitDef {
  const unit = category.units.find((entry) => entry.factor === 1)
  if (unit === undefined) {
    throw new Error(`internal: linear category "${category.id}" has no factor-1 base unit`)
  }
  return unit
}

/**
 * Normalize 1–6 "price for a quantity of one unit" offers into a price per
 * target unit (default: the category's base unit) and rank them. Only linear
 * categories are accepted: temperatures are affine (an arbitrary zero point
 * makes "price per degree" meaningless) and fuel economy is reciprocal, so
 * both are rejected with an explanatory error instead of a wrong number.
 */
export function unitPrice(offers: readonly PriceOffer[], toRaw?: string, maxDecimals = 6): PriceComparison {
  if (!Array.isArray(offers) || offers.length === 0) {
    throw new Error('offers must be a non-empty array of { price, per, quantity? } objects')
  }
  if (offers.length > MAX_PRICE_OFFERS) {
    throw new Error(`unit_price accepts at most ${MAX_PRICE_OFFERS} offers (got ${offers.length})`)
  }
  const resolved = offers.map((offer, index) => {
    if (offer === null || typeof offer !== 'object') {
      throw new Error(`offer #${index + 1} must be an object with "price" and "per"`)
    }
    if (typeof offer.price !== 'number' || !Number.isFinite(offer.price) || offer.price < 0) {
      throw new Error(`offer #${index + 1}: price must be a finite number ≥ 0 (got ${String(offer.price)})`)
    }
    if (typeof offer.per !== 'string') {
      throw new Error(`offer #${index + 1}: per must be a unit string, e.g. "kg", "lb", "L"`)
    }
    const quantity = offer.quantity ?? 1
    if (typeof quantity !== 'number' || !Number.isFinite(quantity) || quantity <= 0) {
      throw new Error(`offer #${index + 1}: quantity must be a finite number > 0 (got ${String(offer.quantity)})`)
    }
    const { category, unit } = resolveUnit(offer.per)
    if (category.kind !== 'linear') {
      const why = category.kind === 'temperature'
        ? 'temperatures are affine — their zero point is arbitrary, so "price per degree" is not a ratio'
        : 'fuel economy is reciprocal (mpg vs L/100km), so price per unit is not a linear factor'
      throw new Error(`cannot compare prices in "${category.name}" — ${why}: use a linear unit like kg, lb, L or gal`)
    }
    return { index, price: offer.price, quantity, category, unit }
  })

  const first = resolved[0] as (typeof resolved)[number]
  for (const entry of resolved) {
    if (entry.category.id !== first.category.id) {
      throw new Error(`offer #${entry.index + 1} is in ${entry.category.name} (${entry.unit.name}) while offer #1 is ` +
        `in ${first.category.name} (${first.unit.name}) — every offer must share a category`)
    }
  }
  const targetUnit = toRaw !== undefined && toRaw.trim() !== '' ? resolveUnit(toRaw) : undefined
  if (targetUnit !== undefined && targetUnit.category.id !== first.category.id) {
    throw new Error(`cannot express a price in ${first.category.name} as ${targetUnit.unit.name} ` +
      `(${targetUnit.category.name}) — the offer unit and the target unit must share a category`)
  }
  const target = targetUnit === undefined ? baseUnitOf(first.category) : targetUnit.unit
  const targetFactor = target.factor
  if (targetFactor === undefined) {
    throw new Error(`internal: linear category "${first.category.id}" has a unit without a factor`)
  }

  const quotes: PriceQuote[] = []
  let lowest = Infinity
  let highest = -Infinity
  let bestIndex = 0
  for (const entry of resolved) {
    const factorPer = entry.unit.factor as number
    const totalTarget = (entry.quantity * factorPer) / targetFactor
    const perTarget = entry.price / totalTarget
    if (perTarget < lowest) {
      lowest = perTarget
      bestIndex = entry.index
    }
    if (perTarget > highest) highest = perTarget
    quotes.push({
      index: entry.index,
      price: entry.price,
      quantity: entry.quantity,
      per_unit: entry.unit.name,
      per_symbol: entry.unit.symbol,
      total_target: roundValue(totalTarget, maxDecimals),
      price_per_target: roundValue(perTarget, maxDecimals),
      formula: `${entry.price} ÷ (${entry.quantity} × ${roundForFormula(factorPer)}) × ${roundForFormula(targetFactor)}`,
    })
  }

  return {
    category: first.category.name,
    target_unit: target.name,
    target_symbol: target.symbol,
    offers: quotes,
    best_index: bestIndex,
    best_price_per_target: roundValue(lowest, maxDecimals),
    spread_percent: highest > 0 ? roundValue(((highest - lowest) / highest) * 100, maxDecimals) : 0,
  }
}

/** One quantity to add: `value` of `unit`. */
export interface SumItem {
  value: number
  unit: string
}

/** One normalized quantity inside a unit_sum result. */
export interface SumRow {
  index: number
  value: number
  unit: string
  symbol: string
  /** This quantity's contribution in the category base unit (rounded for display). */
  base_value: number
}

/** Result of adding up quantities that share one category. */
export interface SumResult {
  category: string
  base_unit: string
  base_symbol: string
  target_unit: string
  target_symbol: string
  items: SumRow[]
  count: number
  /** Sum of the base-unit contributions (rounded for display). */
  base_total: number
  /** Sum expressed in the target unit (rounded for display). */
  total: number
  /** Arithmetic mean in the target unit (rounded for display). */
  mean: number
  formula: string
}

/** Upper bound on quantities per unit_sum call. */
export const MAX_SUM_ITEMS = 12

/**
 * Neumaier compensated summation — the double nearest to the exact sum.
 *
 * Naive accumulation drifts once the running total dwarfs the addend
 * (`0.1 + 0.2 + …`), which is exactly the case for shopping lists of small
 * quantities. The compensation term collects the rounding error of every
 * addition, so the result no longer depends on the order of the inputs.
 */
function compensatedSum(values: readonly number[]): number {
  let sum = 0
  let compensation = 0
  for (const value of values) {
    const next = sum + value
    compensation += Math.abs(sum) >= Math.abs(value)
      ? (sum - next) + value
      : (value - next) + sum
    sum = next
  }
  return sum + compensation
}

/**
 * Add 1–12 quantities given in any units of a single category and report the
 * total and the mean in a target unit (default: the category base unit).
 *
 * Every quantity is converted to the base unit first, then summed with
 * compensated accumulation, so mixed units and many small addends do not
 * drift. Only linear categories are accepted: temperatures are affine (an
 * arbitrary zero point makes a sum meaningless) and fuel economy is
 * reciprocal — both are rejected with an explanation instead of a number that
 * would look right and be wrong. Negative values are allowed, which makes
 * `unit_sum` usable for differences as well as totals.
 */
export function unitSum(items: readonly SumItem[], toRaw?: string, maxDecimals = 6): SumResult {
  if (!Array.isArray(items) || items.length === 0) {
    throw new Error('items must be a non-empty array of { value, unit } objects')
  }
  if (items.length > MAX_SUM_ITEMS) {
    throw new Error(`unit_sum accepts at most ${MAX_SUM_ITEMS} quantities (got ${items.length})`)
  }

  const resolved = items.map((item, index) => {
    if (item === null || typeof item !== 'object') {
      throw new Error(`item #${index + 1} must be an object with "value" and "unit"`)
    }
    if (typeof item.value !== 'number' || !Number.isFinite(item.value)) {
      throw new Error(`item #${index + 1}: value must be a finite number (got ${String(item.value)})`)
    }
    if (typeof item.unit !== 'string' || item.unit.trim() === '') {
      throw new Error(`item #${index + 1}: unit must be a unit string, e.g. "ft", "kg", "min"`)
    }
    const { category, unit } = resolveUnit(item.unit)
    if (category.kind !== 'linear') {
      const why = category.kind === 'temperature'
        ? 'temperatures are affine — their zero point is arbitrary, so a sum of them means nothing (convert each value instead)'
        : 'fuel economy is reciprocal (mpg vs L/100km), so its numbers do not add up'
      throw new Error(`cannot add quantities in "${category.name}" — ${why}`)
    }
    const factor = unit.factor
    if (factor === undefined) {
      throw new Error(`internal: linear category "${category.id}" has a unit without a factor`)
    }
    return { index, value: item.value, category, unit, factor }
  })

  const first = resolved[0] as (typeof resolved)[number]
  for (const entry of resolved) {
    if (entry.category.id !== first.category.id) {
      throw new Error(`item #${entry.index + 1} is in ${entry.category.name} (${entry.unit.name}) while item #1 is ` +
        `in ${first.category.name} (${first.unit.name}) — every quantity must share a category`)
    }
  }

  const base = baseUnitOf(first.category)
  const targetUnit = toRaw !== undefined && toRaw.trim() !== '' ? resolveUnit(toRaw) : undefined
  if (targetUnit !== undefined && targetUnit.category.id !== first.category.id) {
    throw new Error(`cannot express a ${first.category.name} total as ${targetUnit.unit.name} ` +
      `(${targetUnit.category.name}) — the quantities and the target unit must share a category`)
  }
  const target = targetUnit === undefined ? base : targetUnit.unit
  const targetFactor = target.factor
  if (targetFactor === undefined) {
    throw new Error(`internal: linear category "${first.category.id}" has a unit without a factor`)
  }

  const baseValues = resolved.map((entry) => entry.value * entry.factor)
  const baseTotal = compensatedSum(baseValues)
  const total = baseTotal / targetFactor
  const rows: SumRow[] = resolved.map((entry, index) => ({
    index: entry.index,
    value: entry.value,
    unit: entry.unit.name,
    symbol: entry.unit.symbol,
    base_value: roundValue(baseValues[index] as number, maxDecimals),
  }))

  return {
    category: first.category.name,
    base_unit: base.name,
    base_symbol: base.symbol,
    target_unit: target.name,
    target_symbol: target.symbol,
    items: rows,
    count: resolved.length,
    base_total: roundValue(baseTotal, maxDecimals),
    total: roundValue(total, maxDecimals),
    mean: roundValue(total / resolved.length, maxDecimals),
    formula: `Σ ${resolved.map((entry) => `${entry.value} ${entry.unit.symbol}`).join(' + ')} ` +
      `= ${roundValue(baseTotal, maxDecimals)} ${base.symbol}` +
      (target.symbol === base.symbol ? '' : ` = ${roundValue(total, maxDecimals)} ${target.symbol}`),
  }
}

/** Compact listing of one category for list_units output. */
export interface CategoryListing {
  id: string
  name: string
  base: string
  units: Array<{ symbol: string; name: string }>
}

/** List all categories (optionally one) with their units and symbols. */
export function listUnits(categoryFilter?: string): CategoryListing[] {
  if (categoryFilter === undefined || categoryFilter.trim() === '') {
    return CATEGORIES.map(toListing)
  }
  const key = normalize(categoryFilter)
  const wanted = CATEGORIES.find((cat) => cat.id === key || cat.name === key)
  if (wanted === undefined) {
    throw new Error(`unknown category "${categoryFilter}". Known categories: ` +
      CATEGORIES.map((cat) => cat.id).join(', '))
  }
  return [toListing(wanted)]
}

function toListing(category: Category): CategoryListing {
  return {
    id: category.id,
    name: category.name,
    base: category.base,
    units: category.units.map((unit) => ({ symbol: unit.symbol, name: unit.name })),
  }
}
