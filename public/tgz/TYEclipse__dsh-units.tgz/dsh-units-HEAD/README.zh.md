# dsh-units 📐（中文简介）

dsh-units 是 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)（dsh）的单位换算工具箱插件：**22 个类别、3 个工具、零运行时依赖**，纯算术实现（无网络、无文件系统、无代码执行）。

## 解决什么问题

大模型心算单位换算是高频出错点：温度是仿射换算（有偏移）、数据大小混用十进制与二进制前缀、复合单位（km/h、psi、kcal）因子难记。算错一个单位，报告、菜谱、行程、容量估算全部静默出错。dsh-units 把换算交给确定性的静态单位表，返回结构化结果（原值、两侧单位符号与全名、结果、所用公式、类别），Agent 还能据此解释自己的计算过程。

## 工具

| 工具 | 功能 |
|------|------|
| `convert_unit` | 同一类别内换算数值。符号或全名均可（大小写不敏感，°C、m²、"miles"、"MiB" 都认）；未知单位、跨类别、非有限数值均报清晰错误 |
| `list_units` | 列出全部 22 个类别及每个单位的符号与全名（可按类别过滤，如 `"data"`、`"temperature"`） |
| `unit_price` | 单价归一与比价：传 1–6 条报价 `{ price, per, quantity? }`（`quantity` 默认 1，故 `{ price: 4.29, per: "g", quantity: 500 }` 表示 500 g 装），逐条给出每 1 个目标单位（默认该类别基准单位）的价格、最便宜的一条与相差百分比；温度（仿射）与油耗（倒数）会被明确拒绝而非给出无意义数字 |

## 类别覆盖

长度（km…nmi）、质量（t/kg/g/mg/lb/oz）、温度（c/f/k，仿射）、面积（km2…in2、ha、acre）、体积含美制烹饪单位（gal/qt/pint/cup/floz/tbsp/tsp）、速度（km/h、m/s、mph、knot、ft/s）、时长（yr=儒略年/wk/d/h/min/s/ms）、数据大小（bit 到 tbit、B 到 PB、KiB 到 PiB，**MB 与 MiB 严格区分**）、数据传输速率（bit/s 到 tbit/s、B/s 到 TB/s、KiB/s 到 TiB/s，**100 Mbps = 12.5 MB/s 严格区分**）、加速度（m/s2、g0 标准重力 9.80665 m/s²、ft/s2、mph/s）、照度（klx/lx/fc 英尺烛光/ph 辐透）、压强（pa…psi、bar、atm、torr）、能量（j/kj/cal/kcal/wh/kwh/ev）、角度（deg/rad/grad）、频率（hz…ghz、rpm）、功率（mw/kw/w/hp 机械马力/hp(m) 公制 PS/hp(e) 电动马力/btu/h/ftlb/s——**三种马力定义严格区分**）、力（kn/n/dyn/lbf/kgf/gf，lbf/kgf 基于标准重力 9.80665 m/s²）、扭矩（n.m/kgf.m/lbfft/lbfin，力×长度）、排版印刷（px/pt/pc/em/rem，96 dpi 基准，em/rem 按 16px 默认字号）、体积流量（m3/s、m3/h、l/s、l/min、l/h、cfm 立方英尺每分钟、gpm 美制加仑每分钟——**是流量不是体积**）、密度（kg/m3、g/l、g/cm3=g/mL=kg/L=t/m3、g/ml、kg/l、t/m3、lb/ft3、lb/gal=119.8264 kg/m³）、油耗（l/100km、l/km、mpg 美制、mpg(uk) 英制、km/l——倒数关系，mpg 与 L/100km 互算最容易翻车）。

> **v0.2.0 注意**：`pt` 现指印刷"点"（point，此前为美制品脱 pint）。品脱请用 `pint`——`convert_unit { value: 1, from: "pint", to: "l" }` 依然可用。em/rem 按浏览器常见默认 16px 基准字号换算，px 按 96 dpi——均为文档化的约定假设。
>
> **v0.3.0 注意（符号消歧）**：输入 `kn` 解析为"节"（速度）——千牛请用全名（`convert_unit { value: 1, from: "kilonewton", to: "n" }`）；同理 `nm` 是纳米（长度），扭矩牛米用符号 `n.m`（也支持 `n·m` 或全名）。
>
> **v0.5.0 注意（流量、密度、单价）**：新增两个类别——**体积流量**（m3/s、m3/h、l/s、l/min、l/h、cfm、gpm；流量不是体积，`l/min` 不会换到 `l`）与**密度**（kg/m3、g/l、g/cm3、g/ml、kg/l、t/m3、lb/ft3、lb/gal）；新增工具 **`unit_price`**：把 1–6 条报价归一到同一目标单位并排序，温度（零点是任意的）与油耗（倒数关系）会被拒绝，且所有报价与 `to` 必须同类别。
>
> **v0.4.0 注意（类别拆分与消歧）**：原"数据大小/传输"类别拆为**数据大小**（仅尺寸）与**数据传输速率**——`mb/s` 按数据表惯例是 兆字节每秒、`mbps`/`mbit/s` 才是 兆比特每秒，`100 Mbps → 12.5 MB/s` 精确换算。加速度中 `g` 仍是克（质量），重力用 `g0`/`gravity`/`g-force`；`gal` 仍是美制加仑（不含伽利略单位）；`ph` 是辐透（phot），与 pH 无关。

## 安装

```sh
dsh plugin --profile default add github:TYEclipse/dsh-units
```

## 配置

```yaml
plugins:
  dsh-units:
    maxDecimals: 6   # 显示舍入：≥1 用小数位，<1 用有效数字（1–12）
```

## 安全模型

纯算术、零副作用、严格输入校验、仅对显示结果舍入（内部保留全精度）。物理合理性（如负开尔文）不做判断，交给调用方。

## 许可

MIT © 2026 TYEclipse
