#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_common.sh
source "$SCRIPT_DIR/_common.sh"
require_dependencies
load_token
MAX_ATTEMPTS="${POLLYREACH_QUERY_ATTEMPTS:-300}"
LAST_RESPONSE='{}'

for attempt in $(seq 1 "$MAX_ATTEMPTS"); do
  if api_request POST "/platform/v1/chat/openclaw/query" '{}' "$TOKEN" true; then
    LAST_RESPONSE="$API_BODY"
    if [[ "$(jq -r '.done // false' <<<"$API_BODY")" == "true" ]]; then
      printf '%s\n' "$API_BODY"
      exit 0
    fi
  fi
  [[ "$attempt" -lt "$MAX_ATTEMPTS" ]] && sleep "$POLL_INTERVAL"
done
jq -cn --argjson last "$LAST_RESPONSE" --argjson attempts "$MAX_ATTEMPTS" \
  '{error:"Timed out waiting for call completion",attempts:$attempts,last_response:$last}' >&2
exit 1
