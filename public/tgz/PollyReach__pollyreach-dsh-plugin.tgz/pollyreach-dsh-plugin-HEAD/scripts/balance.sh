#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_common.sh
source "$SCRIPT_DIR/_common.sh"
require_dependencies
load_token
api_request GET "/platform/v1/credits/balance" "" "$TOKEN"
printf '%s\n' "$API_BODY"
