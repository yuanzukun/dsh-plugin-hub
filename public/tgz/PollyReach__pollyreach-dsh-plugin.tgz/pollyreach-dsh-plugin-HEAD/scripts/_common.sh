#!/usr/bin/env bash
set -euo pipefail

API_BASE_URL="${POLLYREACH_API_BASE_URL:-https://api.pollyreach.ai}"
CREDENTIALS_FILE="${POLLYREACH_CREDENTIALS_FILE:-$HOME/.config/PollyReach/key.json}"
HTTP_TIMEOUT="${POLLYREACH_HTTP_TIMEOUT:-30}"
POLL_INTERVAL="${POLLYREACH_POLL_INTERVAL:-2}"

json_error() {
  jq -cn --arg error "$1" '{error:$error}'
}

fail() {
  json_error "$1" >&2
  exit "${2:-1}"
}

require_dependencies() {
  command -v curl >/dev/null 2>&1 || fail "curl is required"
  command -v jq >/dev/null 2>&1 || fail "jq is required"
}

load_token() {
  [[ -f "$CREDENTIALS_FILE" ]] || fail "Credential file not found: $CREDENTIALS_FILE. Run register.sh first."
  TOKEN="$(jq -er '.token | select(type == "string" and length > 0)' "$CREDENTIALS_FILE" 2>/dev/null)" || \
    fail "Credential file is invalid or has no token: $CREDENTIALS_FILE"
}

api_request() {
  local method="$1"
  local path="$2"
  local payload="${3:-}"
  local token="${4:-}"
  local body_file
  local curl_status
  local -a args

  body_file="$(mktemp)"
  args=(-sS --connect-timeout 10 --max-time "$HTTP_TIMEOUT" -o "$body_file" -w '%{http_code}' -X "$method")
  args+=(-H 'Accept: application/json')
  [[ -n "$payload" ]] && args+=(-H 'Content-Type: application/json' --data "$payload")
  [[ -n "$token" ]] && args+=(-H "Authorization: Bearer $token")

  curl_status=0
  API_HTTP_CODE="$(curl "${args[@]}" "${API_BASE_URL}${path}")" || curl_status=$?
  if [[ "$curl_status" -ne 0 ]]; then
    rm -f "$body_file"
    API_BODY="$(jq -cn --arg error "Unable to reach PollyReach API" '{error:$error}')"
    printf '%s\n' "$API_BODY" >&2
    return "$curl_status"
  fi

  API_BODY="$(<"$body_file")"
  rm -f "$body_file"
  if ! jq -e . >/dev/null 2>&1 <<<"$API_BODY"; then
    API_BODY="$(jq -cn --arg error "PollyReach returned a non-JSON response" --arg body "$API_BODY" '{error:$error,body:$body}')"
  fi
  if [[ "$API_HTTP_CODE" -lt 200 || "$API_HTTP_CODE" -ge 300 ]]; then
    printf '%s\n' "$API_BODY" >&2
    return 1
  fi
}
