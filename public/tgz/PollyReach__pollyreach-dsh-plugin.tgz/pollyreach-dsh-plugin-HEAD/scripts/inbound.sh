#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_common.sh
source "$SCRIPT_DIR/_common.sh"
require_dependencies
load_token
MAX_ATTEMPTS="${POLLYREACH_INBOUND_ATTEMPTS:-10}"
LAST_RESPONSE='{}'

for attempt in $(seq 1 "$MAX_ATTEMPTS"); do
  if api_request GET "/platform/v1/sms_messages/unread" "" "$TOKEN" true; then
    LAST_RESPONSE="$API_BODY"
    MESSAGE_COUNT="$(jq 'if (.messages | type) == "array" then (.messages | length) else 0 end' <<<"$API_BODY")"
    CALL_ID="$(jq -r '.call_id // empty' <<<"$API_BODY")"
    if [[ "$MESSAGE_COUNT" -gt 0 || -n "$CALL_ID" ]]; then
      printf '%s\n' "$API_BODY"
      exit 0
    fi
  fi
  [[ "$attempt" -lt "$MAX_ATTEMPTS" ]] && sleep "$POLL_INTERVAL"
done
printf '%s\n' "$LAST_RESPONSE"
exit 2
