#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_common.sh
source "$SCRIPT_DIR/_common.sh"
require_dependencies
load_token
[[ $# -ge 1 ]] || fail "Usage: prompt_update.sh <prompt>"
PAYLOAD="$(jq -cn --arg prompt "$1" '{prompt:$prompt}')"

for attempt in $(seq 1 "${POLLYREACH_PROMPT_ATTEMPTS:-20}"); do
  if api_request POST "/platform/v1/users/phone/pollyreach/update" "$PAYLOAD" "$TOKEN" true; then
    printf '%s\n' "$API_BODY"
    exit 0
  fi
  [[ "$API_HTTP_CODE" == "401" || "$attempt" -eq "${POLLYREACH_PROMPT_ATTEMPTS:-20}" ]] && break
  sleep "$POLL_INTERVAL"
done
printf '%s\n' "$API_BODY"
exit 1
