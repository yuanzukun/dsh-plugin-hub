#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_common.sh
source "$SCRIPT_DIR/_common.sh"
require_dependencies
load_token
MAX_ATTEMPTS="${POLLYREACH_ACTIVATION_ATTEMPTS:-60}"
LAST_RESPONSE='{}'

for attempt in $(seq 1 "$MAX_ATTEMPTS"); do
  if api_request GET "/platform/v1/auths/signin/device/activation-status" "" "$TOKEN" true; then
    LAST_RESPONSE="$API_BODY"
    PHONE="$(jq -r '.ai_virtual_phone // empty' <<<"$API_BODY")"
    if [[ -n "$PHONE" ]]; then
      TEMP_FILE="${CREDENTIALS_FILE}.tmp.$$"
      jq --arg phone "$PHONE" '.ai_virtual_phone=$phone' "$CREDENTIALS_FILE" >"$TEMP_FILE"
      chmod 600 "$TEMP_FILE"
      mv "$TEMP_FILE" "$CREDENTIALS_FILE"
      printf '%s\n' "$API_BODY"
      exit 0
    fi
  fi
  [[ "$attempt" -lt "$MAX_ATTEMPTS" ]] && sleep "$POLL_INTERVAL"
done
printf '%s\n' "$LAST_RESPONSE"
exit 2
