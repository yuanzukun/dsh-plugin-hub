#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_common.sh
source "$SCRIPT_DIR/_common.sh"
require_dependencies
load_token
[[ $# -ge 1 ]] || fail "Usage: send.sh <message>"
PAYLOAD="$(jq -cn --arg message "$1" '{message:$message}')"
api_request POST "/platform/v1/chat/openclaw/completions" "$PAYLOAD" "$TOKEN"
printf '%s\n' "$API_BODY"
[[ "$(jq -r '.status // false' <<<"$API_BODY")" == "true" ]]
