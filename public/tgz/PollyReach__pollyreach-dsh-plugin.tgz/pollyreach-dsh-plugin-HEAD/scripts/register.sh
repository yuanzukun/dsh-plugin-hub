#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_common.sh
source "$SCRIPT_DIR/_common.sh"
require_dependencies

[[ $# -ge 1 ]] || fail "Usage: register.sh <agent-name> [description]"
NAME="$1"
DESCRIPTION="${2:-AI agent powered by DeepSeek Harness}"
PAYLOAD="$(jq -cn --arg name "$NAME" --arg description "$DESCRIPTION" \
  '{name:$name,source:"openclaw",description:$description}')"

api_request POST "/platform/v1/auths/signin/device" "$PAYLOAD"
TOKEN_VALUE="$(jq -er '.agent.token | select(type == "string" and length > 0)' <<<"$API_BODY")" || \
  fail "Registration response did not contain agent.token"
ACTIVATION_URL="$(jq -r '.agent.activation_url // empty' <<<"$API_BODY")"
PHONE="$(jq -r '.agent.ai_virtual_phone // empty' <<<"$API_BODY")"

CREDENTIALS_DIR="$(dirname "$CREDENTIALS_FILE")"
mkdir -p "$CREDENTIALS_DIR"
chmod 700 "$CREDENTIALS_DIR"
TEMP_FILE="${CREDENTIALS_FILE}.tmp.$$"
jq -cn --arg token "$TOKEN_VALUE" --arg name "$NAME" \
  --arg activation "$ACTIVATION_URL" --arg phone "$PHONE" \
  '{token:$token,agent_name:$name,activation_url:(if ($activation|length)>0 then $activation else null end),ai_virtual_phone:(if ($phone|length)>0 then $phone else null end)}' \
  >"$TEMP_FILE"
chmod 600 "$TEMP_FILE"
mv "$TEMP_FILE" "$CREDENTIALS_FILE"
jq -cn --arg activation_url "$ACTIVATION_URL" --arg ai_virtual_phone "$PHONE" \
  '{credential_saved:true,activation_url:(if ($activation_url|length)>0 then $activation_url else null end),ai_virtual_phone:(if ($ai_virtual_phone|length)>0 then $ai_virtual_phone else null end)}'
