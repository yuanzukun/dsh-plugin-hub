import assert from 'node:assert/strict'
import { execFile } from 'node:child_process'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { promisify } from 'node:util'
import test from 'node:test'

const exec = promisify(execFile)
const root = new URL('..', import.meta.url).pathname

test('all shell scripts pass bash syntax validation', async () => {
  const scripts = ['_common.sh', 'register.sh', 'activation.sh', 'send.sh', 'query.sh', 'balance.sh', 'inbound.sh', 'prompt_update.sh']
  await exec('/bin/bash', ['-n', ...scripts.map(name => join(root, 'scripts', name))])
})

test('authenticated shell command fails safely without credentials', async () => {
  const home = await mkdtemp(join(tmpdir(), 'pollyreach-shell-'))
  await assert.rejects(
    exec('/bin/bash', [join(root, 'scripts', 'balance.sh')], { env: { ...process.env, HOME: home } }),
    error => {
      assert.match(error.stderr, /Credential file not found/)
      assert.doesNotMatch(error.stderr, /Bearer|token.*:/i)
      return true
    },
  )
})

test('register shell command handles nullable fields and secures credentials', async t => {
  const { createServer } = await import('node:http')
  const home = await mkdtemp(join(tmpdir(), 'pollyreach-shell-'))
  const credentialPath = join(home, 'config', 'key.json')
  const server = createServer((request, reply) => {
    assert.equal(request.url, '/platform/v1/auths/signin/device')
    reply.writeHead(200, { 'content-type': 'application/json' })
    reply.end(JSON.stringify({ agent: { token: 'shell-secret', activation_url: null, ai_virtual_phone: null } }))
  })
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve))
  t.after(() => server.close())
  const address = server.address()
  const { stdout } = await exec('/bin/bash', [join(root, 'scripts', 'register.sh'), 'shell-agent'], {
    env: {
      ...process.env,
      POLLYREACH_API_BASE_URL: `http://127.0.0.1:${address.port}`,
      POLLYREACH_CREDENTIALS_FILE: credentialPath,
    },
  })
  const output = JSON.parse(stdout)
  assert.equal(output.credential_saved, true)
  assert.equal(output.activation_url, null)
  const saved = JSON.parse(await (await import('node:fs/promises')).readFile(credentialPath, 'utf8'))
  assert.equal(saved.token, 'shell-secret')
  const mode = (await (await import('node:fs/promises')).stat(credentialPath)).mode & 0o777
  assert.equal(mode, 0o600)
})
