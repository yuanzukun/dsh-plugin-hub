import assert from 'node:assert/strict'
import { mkdtemp, readFile, stat } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'
import { apply } from '../index.js'
import { apply as applySkill } from '../skill.js'

function setup(config = {}) {
  const tools = new Map()
  const ctx = { tools: { register(tool) { tools.set(tool.name, tool); return () => tools.delete(tool.name) } } }
  apply(ctx, {
    apiBaseUrl: 'https://mock.pollyreach.test',
    credentialsPath: '/tmp/not-used.json',
    source: 'openclaw',
    requestTimeoutMs: 1000,
    pollIntervalMs: 1,
    activationMaxAttempts: 2,
    queryMaxAttempts: 2,
    inboundMaxAttempts: 2,
    ...config,
  })
  return tools
}

function response(value, status = 200) {
  return new Response(JSON.stringify(value), { status, headers: { 'content-type': 'application/json' } })
}

test('registers all native PollyReach tools', () => {
  const tools = setup()
  assert.deepEqual([...tools.keys()], [
    'pollyreach_register',
    'pollyreach_activation_status',
    'pollyreach_send_call',
    'pollyreach_query_call',
    'pollyreach_balance',
    'pollyreach_inbound_calls',
    'pollyreach_update_inbound_prompt',
  ])
})

test('registration stores token securely but does not return it', async t => {
  const dir = await mkdtemp(join(tmpdir(), 'pollyreach-plugin-'))
  const credentialPath = join(dir, 'key.json')
  const tools = setup({ credentialsPath: credentialPath })
  const originalFetch = globalThis.fetch
  t.after(() => { globalThis.fetch = originalFetch })
  globalThis.fetch = async (_url, init) => {
    assert.equal(init.method, 'POST')
    assert.deepEqual(JSON.parse(init.body), {
      name: 'test-agent',
      source: 'openclaw',
      description: 'test description',
    })
    return response({ agent: { token: 'secret-token', activation_url: 'https://agent.pollyreach.ai/auth?code=test', ai_virtual_phone: null } })
  }

  const result = await tools.get('pollyreach_register').execute(
    { name: 'test-agent', description: 'test description' },
    { signal: new AbortController().signal },
  )
  assert.equal(result.credential_saved, true)
  assert.equal(JSON.stringify(result).includes('secret-token'), false)
  assert.equal(JSON.parse(await readFile(credentialPath, 'utf8')).token, 'secret-token')
  assert.equal((await stat(credentialPath)).mode & 0o777, 0o600)
})

test('send preserves quotes and newlines in JSON payload', async t => {
  const dir = await mkdtemp(join(tmpdir(), 'pollyreach-plugin-'))
  const credentialPath = join(dir, 'key.json')
  const tools = setup({ credentialsPath: credentialPath })
  const register = tools.get('pollyreach_register')
  const send = tools.get('pollyreach_send_call')
  const originalFetch = globalThis.fetch
  t.after(() => { globalThis.fetch = originalFetch })
  globalThis.fetch = async url => url.endsWith('/signin/device')
    ? response({ agent: { token: 'secret-token' } })
    : response({ status: true, task_id: 'task-1' })
  await register.execute({ name: 'agent', overwrite: true }, { signal: new AbortController().signal })

  let sentBody
  globalThis.fetch = async (_url, init) => {
    sentBody = JSON.parse(init.body)
    assert.equal(init.headers.Authorization, 'Bearer secret-token')
    return response({ status: true, task_id: 'task-1' })
  }
  const message = 'Call "Example"\nand ask for a table.'
  const result = await send.execute({ message }, { signal: new AbortController().signal })
  assert.equal(sentBody.message, message)
  assert.equal(result.task_id, 'task-1')
})

test('registers the packaged skill without YAML frontmatter', () => {
  let registered
  applySkill({ skills: { register(skill) { registered = skill; return () => {} } } })
  assert.equal(registered.name, 'pollyreach')
  assert.equal(registered.invocation.modelInvocable, true)
  assert.match(registered.content, /^\s*# PollyReach/)
  assert.doesNotMatch(registered.content, /^---/)
  assert.equal(registered.resourceBase.kind, 'directory')
})
