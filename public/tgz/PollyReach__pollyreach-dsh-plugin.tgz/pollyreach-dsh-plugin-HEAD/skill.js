import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'pollyreach-skill'
export const inject = ['skills']

const root = dirname(fileURLToPath(import.meta.url))
const markdown = readFileSync(join(root, 'SKILL.md'), 'utf8')
const content = markdown.replace(/^---\n[\s\S]*?\n---\n?/, '')

export function apply(ctx) {
  ctx.skills.register({
    name: 'pollyreach',
    description: 'Give the agent a phone number, make outbound calls, retrieve results, answer incoming calls, and manage PollyReach.',
    whenToUse: 'Use when the user wants a real phone call made or wants Polly to answer and summarize incoming calls.',
    invocation: { modelInvocable: true, userInvocable: true },
    source: 'bundled',
    provider: 'dsh-pollyreach',
    resourceBase: { kind: 'directory', path: root },
    content,
    metadata: { version: '1.0.3', homepage: 'https://pollyreach.ai' },
  })
}
