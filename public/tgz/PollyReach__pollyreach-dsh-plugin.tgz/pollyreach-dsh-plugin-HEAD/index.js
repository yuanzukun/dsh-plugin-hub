import { access, chmod, mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { constants } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, resolve } from 'node:path'
import { randomUUID } from 'node:crypto'
import { setTimeout as sleep } from 'node:timers/promises'
import Schema from '@deepseek-ai/schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'pollyreach-tools'
export const inject = ['tools']

export const Config = Schema.object({
  apiBaseUrl: Schema.string().default('https://api.pollyreach.ai'),
  credentialsPath: Schema.string().default('~/.config/PollyReach/key.json'),
  source: Schema.string().default('openclaw'),
  requestTimeoutMs: Schema.number().default(30000),
  pollIntervalMs: Schema.number().default(2000),
  activationMaxAttempts: Schema.number().default(60),
  queryMaxAttempts: Schema.number().default(300),
  inboundMaxAttempts: Schema.number().default(10),
})

function expandPath(path) {
  return path === '~' ? homedir() : path.startsWith('~/') ? resolve(homedir(), path.slice(2)) : resolve(path)
}

function asJson(value) {
  return value === undefined ? null : value
}

function renderJson(_args, value) {
  return [{ type: 'text', text: JSON.stringify(value, null, 2) }]
}

function jsonOutput() {
  return { schema: { type: 'json' }, render: renderJson }
}

async function fileExists(path) {
  try {
    await access(path, constants.F_OK)
    return true
  } catch {
    return false
  }
}

async function readCredentials(path) {
  let parsed
  try {
    parsed = JSON.parse(await readFile(path, 'utf8'))
  } catch (error) {
    throw new Error(`Unable to read PollyReach credentials at ${path}: ${error.message}`)
  }
  if (!parsed || typeof parsed.token !== 'string' || !parsed.token.trim()) {
    throw new Error(`PollyReach credential file has no valid token: ${path}`)
  }
  return parsed
}

async function writeCredentials(path, credentials) {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 })
  const temp = `${path}.tmp-${process.pid}-${randomUUID()}`
  try {
    await writeFile(temp, `${JSON.stringify(credentials, null, 2)}\n`, { mode: 0o600, flag: 'wx' })
    await chmod(temp, 0o600)
    await rename(temp, path)
    await chmod(path, 0o600)
  } catch (error) {
    try { await import('node:fs/promises').then(fs => fs.unlink(temp)) } catch {}
    throw error
  }
}

async function updateCredentials(path, update) {
  const current = await readCredentials(path)
  await writeCredentials(path, { ...current, ...update })
}

async function request(config, path, { method = 'GET', body, token, signal } = {}) {
  const timeoutSignal = AbortSignal.timeout(config.requestTimeoutMs)
  const combinedSignal = signal ? AbortSignal.any([signal, timeoutSignal]) : timeoutSignal
  const headers = { Accept: 'application/json' }
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  if (token) headers.Authorization = `Bearer ${token}`

  const response = await fetch(`${config.apiBaseUrl.replace(/\/$/, '')}${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: combinedSignal,
  })
  const text = await response.text()
  let data = null
  if (text) {
    try { data = JSON.parse(text) } catch { data = { raw: text } }
  }
  if (!response.ok) {
    const detail = data && typeof data === 'object' ? JSON.stringify(data) : text
    throw new Error(`PollyReach API ${response.status}: ${detail || response.statusText}`)
  }
  return asJson(data)
}

async function tokenRequest(config, credentialPath, path, options, signal) {
  const credentials = await readCredentials(credentialPath)
  return request(config, path, { ...options, token: credentials.token, signal })
}

async function poll({ attempts, intervalMs, signal, run, complete, timeoutMessage }) {
  let lastResponse = null
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    lastResponse = await run()
    if (complete(lastResponse)) return { completed: true, attempts: attempt, response: lastResponse }
    if (attempt < attempts) await sleep(intervalMs, undefined, { signal })
  }
  return { completed: false, attempts, message: timeoutMessage, response: lastResponse }
}

function genericCall(title, kind = 'fetch') {
  return { card: 'generic', title, kind }
}

export function apply(ctx, config) {
  const credentialPath = expandPath(config.credentialsPath)

  ctx.tools.register(defineTool({
    name: 'pollyreach_register',
    description: 'Register this agent with PollyReach, securely save its token, and return the activation link. Do not register again when credentials already exist.',
    parameters: {
      name: { type: 'string', required: true, description: 'Agent display name' },
      description: { type: 'string', description: 'Short agent description' },
      overwrite: { type: 'boolean', description: 'Replace an existing PollyReach credential only when explicitly requested' },
    },
    output: jsonOutput(),
    presentCall: () => genericCall('Register with PollyReach', 'execute'),
    async execute(args, exec) {
      if (!args.name.trim()) throw new Error('Agent name must not be empty')
      if (!args.overwrite && await fileExists(credentialPath)) {
        throw new Error(`PollyReach credentials already exist at ${credentialPath}; use activation or set overwrite=true explicitly`)
      }
      const response = await request(config, '/platform/v1/auths/signin/device', {
        method: 'POST',
        body: { name: args.name, source: config.source, description: args.description || 'AI agent powered by DeepSeek Harness' },
        signal: exec.signal,
      })
      const agent = response?.agent
      if (!agent || typeof agent.token !== 'string' || !agent.token) {
        throw new Error('Registration response did not contain agent.token')
      }
      await writeCredentials(credentialPath, {
        token: agent.token,
        agent_name: args.name,
        activation_url: agent.activation_url ?? null,
        ai_virtual_phone: agent.ai_virtual_phone ?? null,
      })
      return {
        credential_saved: true,
        activation_url: agent.activation_url ?? null,
        ai_virtual_phone: agent.ai_virtual_phone ?? null,
        message: response.message ?? response.important ?? null,
      }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'pollyreach_activation_status',
    description: 'Check whether PollyReach activation is complete and retrieve the assigned phone number. Optionally poll while the user completes activation.',
    parameters: { wait: { type: 'boolean', description: 'Poll until a phone number is assigned' } },
    output: jsonOutput(),
    presentCall: () => genericCall('Check PollyReach activation'),
    async execute(args, exec) {
      const run = () => tokenRequest(config, credentialPath, '/platform/v1/auths/signin/device/activation-status', {}, exec.signal)
      if (!args.wait) {
        const response = await run()
        if (response?.ai_virtual_phone) await updateCredentials(credentialPath, { ai_virtual_phone: response.ai_virtual_phone })
        return response
      }
      const result = await poll({
        attempts: config.activationMaxAttempts,
        intervalMs: config.pollIntervalMs,
        signal: exec.signal,
        run,
        complete: value => Boolean(value?.ai_virtual_phone),
        timeoutMessage: 'Activation is still pending',
      })
      if (result.completed) await updateCredentials(credentialPath, { ai_virtual_phone: result.response.ai_virtual_phone })
      return result
    },
  }))

  ctx.tools.register(defineTool({
    name: 'pollyreach_send_call',
    description: 'Submit one outbound phone task to PollyReach. When status is true, always call pollyreach_query_call to retrieve the actual result.',
    parameters: { message: { type: 'string', required: true, description: 'Complete call task, target, timing, language, and constraints' } },
    output: jsonOutput(),
    presentCall: () => genericCall('Start PollyReach call', 'execute'),
    async execute(args, exec) {
      if (!args.message.trim()) throw new Error('Call task must not be empty')
      return tokenRequest(config, credentialPath, '/platform/v1/chat/openclaw/completions', {
        method: 'POST', body: { message: args.message },
      }, exec.signal)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'pollyreach_query_call',
    description: 'Poll for the latest outbound call result, including completion details, transcript, recording, and links returned by PollyReach.',
    parameters: { wait: { type: 'boolean', description: 'Poll until done; defaults to true' } },
    output: jsonOutput(),
    presentCall: () => genericCall('Wait for PollyReach call result'),
    async execute(args, exec) {
      const run = () => tokenRequest(config, credentialPath, '/platform/v1/chat/openclaw/query', {
        method: 'POST', body: {},
      }, exec.signal)
      if (args.wait === false) return run()
      return poll({
        attempts: config.queryMaxAttempts,
        intervalMs: config.pollIntervalMs,
        signal: exec.signal,
        run,
        complete: value => value?.done === true,
        timeoutMessage: 'Timed out waiting for call completion',
      })
    },
  }))

  ctx.tools.register(defineTool({
    name: 'pollyreach_balance',
    description: 'Get the current PollyReach credit balance. A zero balance is valid and means calls need a top-up.',
    parameters: {},
    output: jsonOutput(),
    presentCall: () => genericCall('Check PollyReach balance'),
    async execute(_args, exec) {
      return tokenRequest(config, credentialPath, '/platform/v1/credits/balance', {}, exec.signal)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'pollyreach_inbound_calls',
    description: 'Retrieve unread incoming-call messages or summaries. Returns the complete API response without discarding transcripts or links.',
    parameters: { wait: { type: 'boolean', description: 'Poll briefly for an unread incoming call; defaults to false' } },
    output: jsonOutput(),
    presentCall: () => genericCall('Check PollyReach incoming calls'),
    async execute(args, exec) {
      const run = () => tokenRequest(config, credentialPath, '/platform/v1/sms_messages/unread', {}, exec.signal)
      if (!args.wait) return run()
      return poll({
        attempts: config.inboundMaxAttempts,
        intervalMs: config.pollIntervalMs,
        signal: exec.signal,
        run,
        complete: value => Boolean(value?.call_id) || (Array.isArray(value?.messages) && value.messages.length > 0),
        timeoutMessage: 'No unread incoming calls were found',
      })
    },
  }))

  ctx.tools.register(defineTool({
    name: 'pollyreach_update_inbound_prompt',
    description: 'Customize how PollyReach answers incoming calls, including identity, tone, boundaries, and information to collect.',
    parameters: { prompt: { type: 'string', required: true, description: 'Complete inbound answering instructions' } },
    output: jsonOutput(),
    presentCall: () => genericCall('Update PollyReach answering prompt', 'execute'),
    async execute(args, exec) {
      if (!args.prompt.trim()) throw new Error('Inbound prompt must not be empty')
      return tokenRequest(config, credentialPath, '/platform/v1/users/phone/pollyreach/update', {
        method: 'POST', body: { prompt: args.prompt },
      }, exec.signal)
    },
  }))
}

export const __test = { expandPath, readCredentials, writeCredentials, request, poll }
