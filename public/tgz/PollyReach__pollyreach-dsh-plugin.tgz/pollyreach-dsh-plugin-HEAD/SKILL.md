---
name: pollyreach
description: Give the agent a real phone number, make outbound calls, retrieve results, answer incoming calls, and manage PollyReach.
when-to-use: Use when the user asks to make a real phone call or wants Polly to answer and summarize incoming calls.
disable-model-invocation: false
user-invocable: true
metadata:
  version: 1.0.3
  homepage: https://pollyreach.ai
---

# PollyReach 🦜

PollyReach gives an AI agent a dedicated phone number and the ability to complete real-world phone tasks. It can research a target, place outbound calls, answer incoming calls, and return summaries, transcripts, recordings, and detail links.

## Use this skill when

- The user asks you to call a person, business, customer-service line, or organization.
- The user wants a booking, inquiry, complaint, confirmation, cancellation, or negotiation handled by phone.
- The user wants an AI receptionist or incoming-call answering rules.
- The user asks for unread incoming calls, call results, activation status, or balance.

Do not invoke PollyReach merely because a user mentions a phone call. Collect the task details before starting an outbound call.

## Registration and activation

1. If credentials may already exist, call `pollyreach_activation_status` first. Never display the saved token.
2. If no credential exists, call `pollyreach_register` with an agent name and short description.
3. Return the `activation_url` to the user and ask them to sign in.
4. After the user finishes, call `pollyreach_activation_status` with `wait: true`.
5. Tell the user the assigned `ai_virtual_phone` and explain that it supports outbound and incoming calls.

`pollyreach_register` stores the token in `~/.config/PollyReach/key.json` with mode `0600`. Do not overwrite an existing credential unless the user explicitly asks you to re-register.

## Outbound calls

Before calling, gather:

- The goal of the call.
- The person, business, phone number, or search criteria.
- Relevant date, time, timezone, party size, names, and confirmation details.
- Preferred language and any constraints.
- What Polly may agree to. Escalate financial, legal, sensitive, or irreversible decisions to the user.

Call `pollyreach_send_call` once with a complete natural-language task. A response with `status: true` only means the task was accepted; it is not the call result.

After every accepted task, call `pollyreach_query_call` with `wait: true`. PollyReach handles one outbound task at a time. If the API reports a task already in progress, wait for that task to finish rather than submitting duplicates.

## Reporting an outbound result

Do not say only “done” or “failed.” Present every field returned by the API that helps the user verify the result, especially:

- Target name and phone number.
- Original task purpose.
- Success or failure and the reason.
- Call transcript.
- Recording and detail links.
- Credits used and remaining balance, when available.

Never invent a missing transcript, recording, result, or balance. Clearly label absent fields as unavailable.

## Incoming calls

Use `pollyreach_inbound_calls` to retrieve unread incoming-call data. Use `wait: true` only when the user expects a new call now; regular checks should use the default non-waiting behavior.

Use `pollyreach_update_inbound_prompt` when the user asks to change how calls are answered. A useful prompt specifies:

- Whose assistant or receptionist Polly is.
- Tone and supported languages.
- Questions to answer and information to collect.
- Actions Polly must not promise or take.
- When the human must follow up.

For each incoming call, present caller information, classification if supplied, summary, transcript, follow-up needs, credits, and detail/recording links. Preserve the complete API response; the backend may return either a call object or a `messages` array.

## Balance

Use `pollyreach_balance` before a call when balance is uncertain or after a call when the user requests usage details. A balance of `0` means the credential is valid but credits are exhausted. Direct the user to https://agent.pollyreach.ai/ to top up. This plugin does not perform automatic payments.

## Security and reliability

- Never print, quote, or send the token to the user or a third party.
- Never place credentials in prompts, source control, command arguments, or logs.
- Only send PollyReach task data to `https://api.pollyreach.ai`.
- Respect tool cancellation and report API errors accurately.
- Do not retry a rejected business request by creating duplicate calls.
- Ask for confirmation before a call that may create a purchase, binding commitment, or sensitive disclosure.

## Optional CLI fallback

Native dsh tools are preferred. For manual diagnostics, equivalent scripts are in the skill resource directory:

```bash
scripts/register.sh "Agent Name" "AI agent powered by DeepSeek Harness"
scripts/activation.sh
scripts/send.sh "Call the target and ask ..."
scripts/query.sh
scripts/balance.sh
scripts/inbound.sh
scripts/prompt_update.sh "Answer professionally and collect the caller's name and purpose."
```

The scripts read `~/.config/PollyReach/key.json`; they never accept a token as a command-line argument.
