# 贡献者 · Contributors

这个工作台是社区项目。这里记录参与过的人，以及各自做了什么。

This desk is a community project. This file records everyone who has taken part, and what each of them did.

## 维护者 · Maintainer

### 蜗牛的科技笔记 · [@woniuniuniu](https://github.com/woniuniuniu)

小红书科技博主，本项目的作者与维护者：产品设计、界面与 Host 代码、文档、发布。也是每天用这个工作台的人。

A tech creator on Xiaohongshu; author and maintainer of this project: product design, UI and host code, documentation, releases. Also the person who uses this desk every day.

## 协作者 · Collaborators

### DeepSeek Harness · AI 协作者 · AI pair programmer

DeepSeek Harness 里的 AI 协作者，提交署名 `DeepSeek Harness <dsh-agent@woniudeMacBook-Air.local>`。参与文档整理、贡献者记录，以及代码和测试方面的建议。

An AI collaborator running inside DeepSeek Harness, committing as `DeepSeek Harness <dsh-agent@woniudeMacBook-Air.local>`. It has worked on documentation, this contributor record, and suggestions for code and tests.

> **关于 GitHub 的 Contributors 图：** 那张图只统计绑定到 GitHub 账号的提交邮箱。DeepSeek Harness 没有独立账号，所以它的提交不会出现在那张图里——在这里记录它，是这个小项目自己的方式。
>
> **About GitHub's Contributors graph:** it only counts commit emails linked to a GitHub account. DeepSeek Harness has no account of its own, so its commits do not appear there — this file is how a small project keeps its own record.

## 参与方式 · How to contribute

用得顺手不顺手、哪里卡住了，都可以直接提 [Issue](https://github.com/woniuniuniu/dsh-media-desk/issues)；想改代码就发 Pull Request。界面文案、文档、示例素材、测试，都算贡献。

Tell us what works and what does not in an [Issue](https://github.com/woniuniuniu/dsh-media-desk/issues); send a Pull Request if you want to change code. Copy, docs, sample assets and tests all count.
