# dsh-tint-theme

[English](README.md)

为 DeepSeek Harness (DSH) Web GUI 提供一个皮肤选择器：25 套主题家族。其中 22 套移植自知名开源编辑器配色（Gruvbox、Solarized、Dracula、One Dark/Light、Nord、Catppuccin、Tokyo Night 等等——完整名单、上游仓库和许可证见 [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md)），另外 3 套（Aftertype、Signalwave、Quietloop）是本插件自己的原创设计——不是移植自任何项目，也不指向或关联任何商业编辑器或 AI 编程工具。每套家族都有浅色和深色两个皮肤；切换系统的 `prefers-color-scheme` 时插件会自动跟着换成对应的那一个。

## 环境要求

- 已能正常运行 `dsh web` 的 DeepSeek Harness，`@deepseek-ai/dsh-client-ui-theme` 需 `0.1.0-rc.7` 及以上（这是第一个把第三方 settings 命名空间暴露给浏览器的版本，详见下面"原理"一节）
- Node.js >= 22.19（仅从源码 / 需要构建的 git 源安装时需要）

## 安装

```sh
dsh plugin --profile <你的 profile> add github:OneZero-Y/dsh-tint-theme
```

装完重启该 profile（比如 `dsh web`），刷新浏览器即可。

> **从 git 源第一次安装可能会报 pnpm 的 `allowBuilds` 错误。** 本插件声明了 `prepare` 脚本（安装后会自己构建一次），pnpm 10+ 出于供应链安全考虑，会拒绝运行 git 依赖的构建脚本，除非你显式允许。报错信息里会给出具体的包名——把这个包名加进该 profile 的 `pnpm-workspace.yaml` 的 `allowBuilds` 里，然后重新执行同一条 `add` 命令即可。这是 pnpm 的安全机制在正常工作，不是插件坏了。

### 从本地源码安装

```sh
git clone https://github.com/OneZero-Y/dsh-tint-theme.git
cd dsh-tint-theme
npm install
npm run build
dsh plugin --profile <你的 profile> add "$PWD"
```

## 装完能用到什么

设置导航里会多出一个独立的**"皮肤"**入口，跟"模型""Agent 预设""插件"平级：一整排瓦片，每个瓦片对应一套主题家族，外加一个"默认"瓦片用来把控制权交还给内置的"外观"行。点选某个家族会激活它的浅色或深色皮肤，具体选哪个跟随你当前的系统深浅色偏好；如果某个家族处于激活状态时系统偏好发生切换，插件会自动换成该家族对应的另一个皮肤。

## 卸载

```sh
dsh plugin --profile <你的 profile> remove @onezero-y/dsh-tint-theme
```

## 原理

每个家族的浅色和深色皮肤都注册进官方的 `ThemeService`（`ctx.theme.register(...)`，第三方主题的官方合法入口）；"皮肤"页面通过 `ctx.slots` 注册为独立的 `settings.section` 导航项——跟"模型""Agent 预设""插件"平级，而不是塞进"通用设置"里的一行，因为 25+ 套皮肤挤在一行里体验太差。

选择器里被选中的瓦片始终跟随主题服务自身的活动态（`ctx.theme.getTheme()` 和 `theme/change` 事件）——不管当前生效的主题 id 是别的插件设置的，还是内置"外观"行设置的，瓦片都会正确反映它。用户的**选择**本身跨刷新是否保留，走的是本插件自己的 settings 命名空间（`ctx.settingsScope.bind(...)`，在 `src/index.ts` 里做宿主侧注册）：每次显式选择都会写进去，启动时再把持久化的家族通过 `ctx.theme.setTheme` 应用回去。

这在早期版本里做不到。针对 `dsh-client-ui-theme` `rc.6` 及更早版本的旧版插件无法持久化自己的选择：官方 `deepseek-ai/deepseek-harness` 宿主侧有一份硬编码白名单，拦住了所有第三方 settings 命名空间，插件自己注册的偏好存储在浏览器侧永远读不回来，跟有没有注册无关。这份白名单已经在官方仓库里被移除（"注册即暴露"——详见官方仓库的 `2026-08-12-plugin-owned-settings-surface` Agent Note），`rc.7` 是第一个带上这个修复的版本，本插件现在要求这个版本。

每个家族的配色数值都移植自具名的上游开源项目；从该项目语义化调色板到 DSH 自己的 `--dsw-alias-*`/`--dsw-specific-*` 设计 token 的映射，是本插件自己的实现。逐家族的署名和许可证全文见 [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md)。

## License

[MIT](./LICENSE)
