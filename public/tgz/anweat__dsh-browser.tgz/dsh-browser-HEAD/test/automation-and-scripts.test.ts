import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import http from 'node:http'
import { validateRecipe, recipeNeedsApproval } from '../src/automation.ts'
import { BUILTIN_SCRIPTS, matchUserscriptPattern, validateUserscript } from '../src/scripts.ts'
import { browserPolicyDecision } from '../src/approval-policy.ts'
import { loadBrowserRuntime, runNode } from '../src/deps.ts'
import { BrowserService } from '../src/browser-service.ts'
import { resolveConfig } from '../src/config.ts'
import { ALL_BROWSER_ACTION_NAMES, browserActionsForMode, configuredBrowserActions, configuredBrowserTools, resolveAutomationMode } from '../src/freedom.ts'
import { AutomationAssetStore, resolveAutomationAssetPolicy } from '../src/automation-assets.ts'
import { executeAutomationAsset } from '../src/automation-execution.ts'
import { registerTools } from '../src/tools.ts'

const VALID_SCRIPT = `// ==UserScript==
// @name Read Heading
// @match http://127.0.0.1/*
// @grant none
// ==/UserScript==
return { heading: document.querySelector('h1')?.textContent || '', input: __DSH_INPUTS__.query || '' }`

test('registered tool schemas do not expose host prompt template groups', () => {
  for (const toolSurface of ['indexed', 'flat'] as const) {
    const registered: unknown[] = []
    const ctx = { tools: { register: (tool: unknown) => registered.push(tool) } }

    registerTools(ctx as never, resolveConfig({ automationMode: 'unrestricted', toolSurface }), {} as never)

    assert.ok(registered.length >= 2, `${toolSurface} registered tools`)
    const unsafe = registered.filter(tool => /\{\{[^{}]+\}\}/.test(JSON.stringify(tool)))
    assert.deepEqual(unsafe, [], toolSurface)
  }
})

test('userscript metadata is scoped, hashed, and capability-reported', () => {
  const validation = validateUserscript(VALID_SCRIPT, 'http://127.0.0.1/page')
  assert.equal(validation.valid, true)
  assert.equal(validation.metadata.name, 'Read Heading')
  assert.match(validation.sha256, /^[a-f\d]{64}$/)
  assert.deepEqual(validation.capabilities, ['dom-read'])
  assert.equal(matchUserscriptPattern('*://*.example.com/*', 'https://sub.example.com/a?q=1'), true)
  assert.equal(matchUserscriptPattern('https://example.com/private/*', 'https://example.com/public/a'), false)
})

test('userscript validation rejects remote requires, grants, and wrong hosts', () => {
  const unsafe = VALID_SCRIPT
    .replace('// @grant none', '// @grant GM_xmlhttpRequest\n// @require https://evil.invalid/a.js')
  assert.match(validateUserscript(unsafe, 'http://127.0.0.1/').errors.join(' '), /@require/)
  assert.match(validateUserscript(unsafe, 'http://127.0.0.1/').errors.join(' '), /@grant/)
  assert.match(validateUserscript(VALID_SCRIPT, 'https://example.com/').errors.join(' '), /outside/)
})

test('browser status reports a missing runtime Chromium executable truthfully', async () => {
  const runtime = loadBrowserRuntime('playwright')
  const descriptor = Object.getOwnPropertyDescriptor(runtime.chromium, 'executablePath')
  const missingPath = path.join(os.tmpdir(), `dsh-browser-missing-chromium-${Date.now()}`, 'chrome.exe')
  Object.defineProperty(runtime.chromium, 'executablePath', { configurable: true, value: () => missingPath })
  const service = new BrowserService(resolveConfig({ browserRuntime: 'playwright', autoInstall: false }))
  const channelService = new BrowserService(resolveConfig({ browserRuntime: 'playwright', channel: 'chrome', autoInstall: false }))
  try {
    const status = await service.status()
    assert.equal(status.chromiumInstalled, false)
    assert.equal(status.chromiumExecutablePath, path.resolve(missingPath))
    assert.match(status.runtimeWarnings.join(' '), /Expected Chromium executable is missing/)
    const channelStatus = await channelService.status()
    assert.equal(channelStatus.chromiumInstalled, false)
    assert.doesNotMatch(channelStatus.runtimeWarnings.join(' '), /Expected Chromium executable is missing/)
  } finally {
    await service.close()
    await channelService.close()
    if (descriptor) Object.defineProperty(runtime.chromium, 'executablePath', descriptor)
    else delete runtime.chromium.executablePath
  }
})

test('built-in scripts are valid, read-only, and have stable ids', () => {
  assert.deepEqual(BUILTIN_SCRIPTS.map(script => script.id), ['article-clean', 'links', 'jsonld', 'forms'])
  for (const script of BUILTIN_SCRIPTS) {
    const validation = validateUserscript(script.source, 'https://example.com/')
    assert.equal(validation.valid, true, script.id + ': ' + validation.errors.join('; '))
    assert.deepEqual(validation.capabilities, ['dom-read'])
  }
})

test('recipes bound steps and distinguish read-only from mutating flows', () => {
  const readonly = [
    { type: 'wait' as const, condition: 'selector' as const, value: 'main' },
    { type: 'wait' as const, condition: 'time' as const, waitMs: 5 },
    { type: 'extract' as const, selector: 'main', mode: 'text' as const },
  ]
  validateRecipe(readonly)
  assert.equal(recipeNeedsApproval(readonly), false)
  assert.equal(recipeNeedsApproval([...readonly, { type: 'click' as const, selector: 'button' }]), true)
  assert.throws(() => validateRecipe([{ type: 'scroll', deltaY: 999_999 }]), /deltaY/)
  assert.throws(() => validateRecipe(Array.from({ length: 26 }, () => ({ type: 'screenshot' as const }))), /25/)
})

test('approval policy asks for arbitrary userscripts, OpenCLI, and mutating recipes', () => {
  assert.equal(browserPolicyDecision('script.run_userscript', { source: VALID_SCRIPT, url: 'http://127.0.0.1/' }).kind, 'ask')
  assert.equal(browserPolicyDecision('opencli.run', { args: ['reddit', 'search', 'dsh'] }).kind, 'ask')
  assert.equal(browserPolicyDecision('automation.run_recipe', { steps: [{ type: 'extract', selector: 'main' }] }).kind, 'allow')
  assert.equal(browserPolicyDecision('automation.run_recipe', { steps: [{ type: 'fill', selector: '#q', value: 'dsh' }] }).kind, 'ask')
  assert.equal(browserPolicyDecision('script.run_userscript', { source: 'alert(1)', url: 'https://example.com/' }).kind, 'deny')
  assert.equal(browserPolicyDecision('act.hover', { selector: '#menu' }).kind, 'ask')
  assert.equal(browserPolicyDecision('act.press', { key: 'Enter' }).kind, 'ask')
  assert.equal(browserPolicyDecision('act.select', { selector: '#mode', values: ['b'] }).kind, 'ask')
  assert.equal(browserPolicyDecision('act.check', { selector: '#enabled' }).kind, 'ask')
  assert.equal(browserPolicyDecision('script.evaluate', { expression: 'document.title' }).kind, 'ask')
  assert.equal(browserPolicyDecision('act.upload', { files: ['C:\\fixture.txt'] }).kind, 'ask')
  assert.equal(browserPolicyDecision('act.upload', { files: [] }).kind, 'deny')
  assert.equal(browserPolicyDecision('web_deps', { action: 'check' }, 'standard').kind, 'allow')
  assert.equal(browserPolicyDecision('web_deps', { action: 'install', backend: 'yt-dlp' }, 'standard').kind, 'ask')
  assert.equal(browserPolicyDecision('web_cache_clear', {}, 'standard').kind, 'ask')
  assert.equal(browserPolicyDecision('web_rule', { action: 'upsert' }, 'standard').kind, 'ask')
})

test('automation modes expose predictable tool sets and retain validation when approval is disabled', () => {
  // The 30 former tools map onto 30 actions, plus target.list, act.type, act.clear and target.select.
  assert.equal(ALL_BROWSER_ACTION_NAMES.length, 34)
  assert.equal(browserActionsForMode('read-only').length, 19)
  assert.equal(browserActionsForMode('standard').length, 34)
  assert.equal(browserActionsForMode('autonomous').length, 34)
  assert.equal(browserActionsForMode('unrestricted').length, 34)
  assert.equal(browserActionsForMode('read-only').includes('script.run_userscript'), false)
  assert.equal(browserActionsForMode('read-only').includes('automation.run_recipe'), true)
  assert.equal(browserActionsForMode('read-only').includes('automation.search'), true)
  assert.equal(browserActionsForMode('read-only').includes('automation.develop'), true)
  assert.equal(browserActionsForMode('read-only').includes('automation.run'), false)
  assert.equal(configuredBrowserActions('standard', { modelDevelopmentEnabled: false }).includes('automation.develop'), false)
  assert.deepEqual(configuredBrowserActions('standard', { modelDevelopmentEnabled: true }, false), [])
  // The model-visible tool names are the surface, not the actions.
  assert.deepEqual(configuredBrowserTools('read-only', { modelDevelopmentEnabled: true }), ['browser_index', 'browser_call'])
  assert.deepEqual(configuredBrowserTools('standard', { modelDevelopmentEnabled: true }, false), [])
  assert.equal(configuredBrowserTools('standard', { modelDevelopmentEnabled: true }, true, 'flat').length, 34)
  assert.equal(configuredBrowserTools('read-only', { modelDevelopmentEnabled: true }, true, 'flat').length, 19)

  assert.equal(browserPolicyDecision('act.click', { selector: 'button' }, 'read-only').kind, 'deny')
  assert.equal(browserPolicyDecision('act.click', { selector: 'button' }, 'standard').kind, 'ask')
  assert.equal(browserPolicyDecision('act.click', { selector: 'button' }, 'autonomous').kind, 'allow')
  assert.equal(browserPolicyDecision('script.evaluate', { expression: 'document.title' }, 'autonomous').kind, 'ask')
  assert.equal(browserPolicyDecision('act.upload', { files: ['C:\\fixture.txt'] }, 'autonomous').kind, 'ask')
  assert.equal(browserPolicyDecision('script.evaluate', { expression: 'document.title' }, 'unrestricted').kind, 'allow')
  assert.equal(browserPolicyDecision('act.upload', { files: ['C:\\fixture.txt'] }, 'unrestricted').kind, 'allow')
  assert.equal(browserPolicyDecision('script.evaluate', { expression: 'document.title' }, 'read-only').kind, 'deny')
  assert.equal(browserPolicyDecision('automation.run_recipe', { steps: [{ type: 'fill', selector: '#q', value: 'dsh' }] }, 'read-only').kind, 'deny')
  assert.equal(browserPolicyDecision('automation.run_recipe', { steps: [{ type: 'fill', selector: '#q', value: 'dsh' }] }, 'autonomous').kind, 'allow')
  assert.equal(browserPolicyDecision('automation.run', { id: 'asset' }, 'read-only').kind, 'deny')
  assert.equal(browserPolicyDecision('automation.run', { id: 'asset' }, 'standard').kind, 'ask')
  assert.equal(browserPolicyDecision('automation.run', { id: 'asset' }, 'autonomous').kind, 'ask')
  assert.equal(browserPolicyDecision('automation.run', { id: 'asset' }, 'autonomous', 'recipe').kind, 'allow')
  assert.equal(browserPolicyDecision('automation.run', { id: 'asset' }, 'autonomous', 'userscript').kind, 'ask')
  assert.equal(browserPolicyDecision('automation.develop', { action: 'get' }, 'read-only').kind, 'allow')
  assert.equal(browserPolicyDecision('automation.develop', { action: 'save' }, 'read-only').kind, 'deny')
  assert.equal(browserPolicyDecision('automation.develop', { action: 'save' }, 'standard').kind, 'ask')
  assert.equal(browserPolicyDecision('automation.develop', { action: 'test' }, 'autonomous').kind, 'ask')
  assert.equal(browserPolicyDecision('automation.develop', { action: 'test' }, 'unrestricted').kind, 'allow')
  assert.equal(browserPolicyDecision('script.run_userscript', { source: VALID_SCRIPT, url: 'http://127.0.0.1/' }, 'autonomous').kind, 'ask')
  assert.equal(browserPolicyDecision('opencli.run', { args: ['browser', 'research', 'state'] }, 'autonomous').kind, 'ask')
  assert.equal(browserPolicyDecision('runtime.install', {}, 'autonomous').kind, 'ask')
  assert.equal(browserPolicyDecision('script.run_userscript', { source: VALID_SCRIPT, url: 'http://127.0.0.1/' }, 'unrestricted').kind, 'allow')
  assert.equal(browserPolicyDecision('opencli.run', { args: ['browser', 'research', 'state'] }, 'unrestricted').kind, 'allow')
  assert.equal(browserPolicyDecision('runtime.install', {}, 'unrestricted').kind, 'allow')
  assert.equal(browserPolicyDecision('web_deps', { action: 'install' }, 'read-only').kind, 'deny')
  assert.equal(browserPolicyDecision('web_deps', { action: 'install' }, 'autonomous').kind, 'ask')
  assert.equal(browserPolicyDecision('web_deps', { action: 'install' }, 'unrestricted').kind, 'allow')
  assert.equal(browserPolicyDecision('web_cache_clear', {}, 'read-only').kind, 'deny')
  assert.equal(browserPolicyDecision('web_cache_clear', {}, 'autonomous').kind, 'allow')
  assert.equal(browserPolicyDecision('web_rule', { action: 'remove' }, 'autonomous').kind, 'allow')
  assert.equal(browserPolicyDecision('web_rule', { action: 'list' }, 'read-only').kind, 'allow')
  assert.equal(browserPolicyDecision('script.run_userscript', { source: 'alert(1)', url: 'https://example.com/' }, 'unrestricted').kind, 'deny')
  assert.throws(() => resolveAutomationMode('anything-goes'), /automationMode/)
})

test('disabled browser service exposes no tools and rejects browser execution', async () => {
  const service = new BrowserService(resolveConfig({ enabled: false }))
  try {
    const status = await service.status()
    assert.deepEqual(status.exposedTools, [])
    await assert.rejects(service.open('http://127.0.0.1:1/'), /browser service is disabled/i)
  } finally {
    await service.close()
  }
})

test('runNode passes argv containing spaces verbatim without shell quoting', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-browser-argv-'))
  const script = path.join(dir, 'argv.mjs')
  fs.writeFileSync(script, 'process.stdout.write(JSON.stringify(process.argv.slice(2)))', 'utf8')
  try {
    const result = await runNode(script, ['hello world', 'a"b'], { signal: undefined, timeoutMs: 5_000 })
    assert.equal(result.code, 0)
    assert.deepEqual(JSON.parse(result.stdout), ['hello world', 'a"b'])
  } finally {
    fs.rmSync(dir, { recursive: true, force: true })
  }
})

test('runNode uses real Node when hosted by Electron', { skip: process.platform === 'win32' }, async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-browser-electron-'))
  const fakeElectron = path.join(dir, 'DSH Desktop')
  const script = path.join(dir, 'output.mjs')
  const originalExecPath = Object.getOwnPropertyDescriptor(process, 'execPath')!
  fs.writeFileSync(fakeElectron, '#!/bin/sh\nexit 0\n', { mode: 0o755 })
  fs.writeFileSync(script, 'process.stdout.write("node script ran")', 'utf8')
  try {
    Object.defineProperty(process, 'execPath', { ...originalExecPath, value: fakeElectron })
    const result = await runNode(script, [], { signal: undefined, timeoutMs: 5_000 })
    assert.equal(result.code, 0)
    assert.equal(result.stdout, 'node script ran')
  } finally {
    Object.defineProperty(process, 'execPath', originalExecPath)
    fs.rmSync(dir, { recursive: true, force: true })
  }
})

test('runNode resolves node.exe from Windows PATH and reports a missing Node', { skip: process.platform === 'win32' }, async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-browser-win-node-'))
  const script = path.join(dir, 'output.mjs')
  const nodeExe = path.join(dir, 'node.exe')
  const originalExecPath = Object.getOwnPropertyDescriptor(process, 'execPath')!
  const originalPlatform = Object.getOwnPropertyDescriptor(process, 'platform')!
  fs.writeFileSync(script, 'process.stdout.write("windows node ran")', 'utf8')
  fs.symlinkSync(process.execPath, nodeExe)
  try {
    Object.defineProperty(process, 'execPath', { ...originalExecPath, value: path.join(dir, 'DSH Desktop.exe') })
    Object.defineProperty(process, 'platform', { ...originalPlatform, value: 'win32' })
    const found = await runNode(script, [], { signal: undefined, timeoutMs: 5_000, env: { PATH: dir } })
    assert.equal(found.code, 0)
    assert.equal(found.stdout, 'windows node ran')

    const missing = await runNode(script, [], { signal: undefined, env: { PATH: '' } })
    assert.equal(missing.code, -1)
    assert.match(missing.stderr, /Node\.js executable not found.*DSH_BROWSER_NODE/)
  } finally {
    Object.defineProperty(process, 'execPath', originalExecPath)
    Object.defineProperty(process, 'platform', originalPlatform)
    fs.rmSync(dir, { recursive: true, force: true })
  }
})

test('real Playwright runtime executes built-ins, recipes, and a scoped userscript', async () => {
  const snapshotDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-browser-snapshot-'))
  const server = http.createServer((request, response) => {
    if (request.url?.startsWith('/missing')) {
      response.writeHead(403, { 'content-type': 'text/plain' })
      response.end('forbidden')
      return
    }
    response.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
    response.end('<!doctype html><title>Fixture</title><style>#menu .panel{display:none}#menu:hover .panel{display:inline}</style><main><h1>Hello DSH</h1><p id="copy">Browser automation fixture.</p><div id="menu">Menu <span class="panel">Revealed</span></div><label>Search terms <input id="query" onkeydown="if(event.key===\'Enter\')document.querySelector(\'#pressed\').textContent=\'pressed\'"></label><button aria-label="Run search" onclick="document.querySelector(\'#clicked\').textContent=\'clicked\'">Run</button><p id="pressed"></p><p id="clicked"></p><label>Mode <select id="mode" aria-label="Mode"><option value="a">A</option><option value="b">B</option></select></label><label><input id="enabled" type="checkbox"> Enabled</label><input id="upload" type="file" onchange="document.querySelector(\'#selected\').textContent=this.files[0]?.name||\'\'"><p id="selected"></p><iframe id="frame" srcdoc="<label>Frame input <input id=frame-input></label>"></iframe><a href="/next">Next</a><script>console.error(\'token=fixture-secret failed\'); fetch(\'/missing?token=fixture-secret\').catch(()=>{})</script></main>')
  })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  const address = server.address()
  if (!address || typeof address === 'string') throw new Error('fixture server did not expose a TCP port')
  const url = `http://127.0.0.1:${address.port}/page`
  const bootstrapStatePath = path.join(snapshotDir, 'auth', 'bootstrap.json')
  const service = new BrowserService(resolveConfig({
    enabled: true,
    channel: 'chromium',
    headless: true,
    opencliEnabled: true,
    authProfiles: { bootstrap: { storageStatePath: bootstrapStatePath, allowedDomains: ['127.0.0.1'], persistState: true } },
    snapshotDir,
    autoInstall: false,
    verbose: false,
  }))
  try {
    const builtIn = await service.runBuiltinScript(url, 'article-clean')
    assert.match(builtIn.resultJson, /Hello DSH/)
    assert.equal(fs.existsSync(bootstrapStatePath), false)
    await service.runBuiltinScript(url, 'article-clean', { authProfile: 'bootstrap' })
    assert.equal(fs.existsSync(bootstrapStatePath), true)

    const recipe = await service.recipe([
      { type: 'wait', condition: 'selector', value: '#copy' },
      { type: 'extract', selector: '#copy', mode: 'text' },
    ], { url })
    assert.equal(recipe.outputs[0]?.value, 'Browser automation fixture.')
    assert.equal(recipe.steps[1]?.output, 0, 'the step points at its output instead of repeating the value')

    const external = await service.runUserscript(url, VALID_SCRIPT, { inputs: { query: 'runtime-only' } })
    assert.equal(JSON.parse(external.resultJson).heading, 'Hello DSH')
    assert.equal(JSON.parse(external.resultJson).input, 'runtime-only')

    await service.open(url, { capture: ['console', 'network'] })
    await service.wait({ text: 'Hello DSH', exact: true })
    await service.type({ label: 'Search terms', exact: true }, 'semantic value')
    await service.press({ label: 'Search terms', exact: true }, 'Enter')
    await service.wait({ text: 'pressed', exact: true })
    await service.click({ role: 'button', name: 'Run search', exact: true })
    await service.wait({ text: 'clicked', exact: true })
    await service.select({ label: 'Mode', exact: true }, ['b'])
    await service.check({ label: 'Enabled', exact: true })
    await service.type({ label: 'Frame input', exact: true, frame: { selector: '#frame' } }, 'inside frame')
    const iframeValue = await service.evaluate(`document.querySelector('#frame').contentDocument.querySelector('#frame-input').value`)
    assert.equal(JSON.parse(iframeValue.resultJson), 'inside frame')
    const hovered = await service.hover({ text: 'Menu', exact: false }, { waitMs: 0 })
    assert.match(hovered.text, /Revealed/)
    const uploadPath = path.join(snapshotDir, 'fixture.txt')
    fs.writeFileSync(uploadPath, 'upload fixture', 'utf8')
    const uploaded = await service.setFiles('#upload', [uploadPath])
    assert.deepEqual(uploaded.files, ['fixture.txt'])
    assert.match(uploaded.text, /fixture\.txt/)
    await assert.rejects(() => service.setFiles('#upload', ['relative.txt']), /absolute file paths/)

    const evaluated = await service.evaluate(`(() => {
      document.cookie = 'visible_cookie=fixture; SameSite=Lax'
      localStorage.setItem('fixture', 'stored')
      return { title: document.title, cookie: document.cookie, stored: localStorage.getItem('fixture') }
    })()`)
    assert.deepEqual(JSON.parse(evaluated.resultJson), { title: 'Fixture', cookie: 'visible_cookie=fixture', stored: 'stored' })
    assert.deepEqual(evaluated.capabilities, ['dom', 'page-javascript', 'page-network', 'page-storage'])
    assert.match(evaluated.warnings.join(' '), /non-HttpOnly cookies|site rules|filesystem/)
    const capped = await service.evaluate(`'x'.repeat(100001)`)
    assert.equal(capped.truncated, true)
    await assert.rejects(() => service.evaluate('new Promise(() => {})', { timeoutMs: 1_000 }), /active page remains open/)
    assert.match((await service.read()).text, /Hello DSH/)

    await new Promise(resolve => setTimeout(resolve, 100))
    const consoleRecords = service.consoleMessages()
    assert.equal(consoleRecords.enabled, true)
    assert.match(consoleRecords.records.map(record => record.text).join(' '), /token=\[redacted\]/)
    const requestRecords = service.networkRequests()
    assert.equal(requestRecords.enabled, true)
    assert.equal(requestRecords.records.some(record => record.status === 403), true)
    assert.equal(requestRecords.records.some(record => record.url.includes('fixture-secret')), false)

    const elementShot = await service.screenshot({ target: { role: 'button', name: 'Run search', exact: true }, filename: 'button.png' })
    assert.equal(path.dirname(elementShot.path), snapshotDir)
    assert.equal(fs.existsSync(elementShot.path), true)
    const regionShot = await service.screenshot({ clip: { x: 0, y: 0, width: 64, height: 64 }, fullPage: false, filename: 'region.jpg', format: 'jpeg', quality: 70 })
    assert.equal(fs.existsSync(regionShot.path), true)
    await assert.rejects(() => service.screenshot({ filename: '../escape.png' }), /plain file name/)

    const assetStore = new AutomationAssetStore(resolveAutomationAssetPolicy({ directory: path.join(snapshotDir, 'automations'), persistenceMode: 'manual', minInputSetsForActivation: 1 }))
    const draft = assetStore.saveDraft({ kind: 'userscript', name: 'Reusable heading reader', domains: ['127.0.0.1'], inputNames: ['query'], source: VALID_SCRIPT })
    assert.equal(assetStore.validate(draft.id).testStatus, 'untested')
    assert.throws(() => assetStore.setStatus(draft.id, 'active', { expectedRevision: draft.revision }), /pass testing/)
    const replay = await executeAutomationAsset(service, assetStore, draft.id, url, { query: 'draft-replay' }, 'draft')
    assert.equal(JSON.parse((replay.value as { resultJson: string }).resultJson).input, 'draft-replay')
    assert.equal(assetStore.get(draft.id)?.testStatus, 'passed')
    assert.equal(assetStore.setStatus(draft.id, 'active', { expectedRevision: draft.revision }).status, 'active')

    const extracted = await service.searchResults(url, {
      item: 'main', title: 'h1', link: 'a', text: '#copy',
    }, { count: 1 })
    assert.deepEqual(extracted, [{
      title: 'Hello DSH',
      url: `http://127.0.0.1:${address.port}/next`,
      snippet: 'Browser automation fixture.',
    }])

    const crawl = await service.crawl([url], { maxPages: 2, maxDepth: 1, sameOrigin: true, maxCharsPerPage: 2_000 })
    assert.equal(crawl.pages.length, 2, JSON.stringify(crawl))
    assert.deepEqual(crawl.pages.map(page => page.depth), [0, 1])
    assert.equal(crawl.stats.pagesVisited, 2)
    assert.match(crawl.warnings.join(' '), /terms|robots/i)

    const catalog = await service.opencliCatalog({ site: 'reddit', query: 'search', limit: 5 })
    assert.ok(catalog.length > 0 && catalog.length <= 5)
    assert.ok(catalog.every(item => item.site === 'reddit'))

    const pngBeforeSnapshot = fs.readdirSync(snapshotDir).filter(file => file.endsWith('.png'))
    const snapshot = await service.snapshot(url, [], { outDir: snapshotDir, screenshot: false } as never)
    assert.equal(snapshot.screenshotPath, undefined)
    assert.equal(fs.existsSync(snapshot.htmlPath), true)
    assert.deepEqual(fs.readdirSync(snapshotDir).filter(file => file.endsWith('.png')), pngBeforeSnapshot)

    const status = await service.status()
    assert.equal(status.browserRuntime, 'playwright')
    assert.equal(status.usagePolicy.maxPagesPerRun, 20)
    assert.equal(status.usageGovernor.totalRuns > 0, true)
    assert.equal(status.automationMode, 'standard')
    assert.deepEqual(status.exposedTools, ['browser_index', 'browser_call'])
    assert.equal(status.exposedActions.length, 34)
    assert.equal(status.directInteractionPolicy, 'ask')
    assert.equal(status.pageEvaluatePolicy, 'ask')
    assert.equal(status.fileUploadPolicy, 'ask')
    assert.equal(status.opencliInstalled, true)
  } finally {
    await service.close()
    await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()))
    fs.rmSync(snapshotDir, { recursive: true, force: true })
  }
})

test('real Patchright runtime is selectable and executes a trusted script', async () => {
  const server = http.createServer((_request, response) => {
    response.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
    response.end('<!doctype html><title>Patchright fixture</title><main><h1>Stealth runtime</h1><p>Patchright works through the same browser contract.</p></main>')
  })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  const address = server.address()
  if (!address || typeof address === 'string') throw new Error('fixture server did not expose a TCP port')
  const service = new BrowserService(resolveConfig({
    enabled: true,
    channel: 'chrome',
    headless: true,
    browserRuntime: 'patchright',
    opencliEnabled: false,
    automationMode: 'standard',
    autoInstall: false,
    verbose: false,
  }))
  try {
    const result = await service.runBuiltinScript(`http://127.0.0.1:${address.port}/`, 'article-clean')
    assert.match(result.resultJson, /Stealth runtime/)
    const status = await service.status()
    assert.equal(status.browserRuntime, 'patchright')
    assert.match(status.runtimeWarnings.join(' '), /headed|headless/i)
  } finally {
    await service.close()
    await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()))
  }
})

test('browser service clears stale interactive state and relaunches after disconnect', async () => {
  const server = http.createServer((_request, response) => {
    response.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
    response.end('<!doctype html><title>Recovery</title><main><h1>Recovered browser</h1></main>')
  })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  const address = server.address()
  if (!address || typeof address === 'string') throw new Error('fixture server did not expose a TCP port')
  const url = `http://127.0.0.1:${address.port}/`
  const service = new BrowserService(resolveConfig({
    channel: 'chromium', headless: true, opencliEnabled: false, autoInstall: false, verbose: false,
  }))
  // Interactive state is per session now, so reach the shared bucket that the
  // session-less calls in this test use.
  const runtime = service as unknown as { browser?: { close(): Promise<void> } }
  const sharedPage = () => service.sessionState(undefined)?.page as { close(): Promise<void> } | undefined
  try {
    await service.open(url)
    const firstBrowser = runtime.browser
    assert.ok(firstBrowser)
    await firstBrowser.close()
    await new Promise(resolve => setTimeout(resolve, 25))
    const disconnected = await service.status()
    assert.equal(disconnected.activeUrl, undefined)
    assert.equal(disconnected.activeAuthProfile, undefined)

    const reopened = await service.open(url)
    assert.match(reopened.text, /Recovered browser/)
    assert.notEqual(runtime.browser, firstBrowser)

    const page = sharedPage()
    assert.ok(page)
    await page.close()
    await new Promise(resolve => setTimeout(resolve, 25))
    assert.equal((await service.status()).activeUrl, undefined)
    assert.match((await service.open(url)).text, /Recovered browser/)
  } finally {
    await service.close()
    await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()))
  }
})

test('bounded crawl backs off and retries a real 429 response', async () => {
  let requests = 0
  const observedCookies: string[] = []
  const authDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-browser-crawl-auth-'))
  const storageStatePath = path.join(authDir, 'state.json')
  fs.writeFileSync(storageStatePath, JSON.stringify({ cookies: [{ name: 'crawl_session', value: 'must-not-leak', domain: '127.0.0.1', path: '/', expires: -1, httpOnly: false, secure: false, sameSite: 'Lax' }], origins: [] }), 'utf8')
  const server = http.createServer((request, response) => {
    if (request.url !== '/') {
      response.writeHead(204)
      response.end()
      return
    }
    requests++
    observedCookies.push(request.headers.cookie ?? '')
    if (requests === 1) {
      response.writeHead(429, { 'content-type': 'text/plain', 'retry-after': '0.02' })
      response.end('slow down')
      return
    }
    response.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
    response.end('<!doctype html><title>Recovered</title><main><h1>Recovered after backoff</h1></main>')
  })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  const address = server.address()
  if (!address || typeof address === 'string') throw new Error('fixture server did not expose a TCP port')
  const service = new BrowserService(resolveConfig({
    enabled: true,
    channel: 'chromium',
    headless: true,
    browserRuntime: 'playwright',
    opencliEnabled: false,
    automationMode: 'unrestricted',
    authProfiles: { crawlAuth: { storageStatePath, allowedDomains: ['127.0.0.1'] } },
    defaultAuthProfile: 'crawlAuth',
    usagePolicy: { minDelayMs: 0, maxConcurrency: 2, burst: 3, maxPagesPerRun: 2, maxDepth: 0, retryLimit: 1, backoffBaseMs: 10, cooldownMs: 100 },
    autoInstall: false,
    verbose: false,
  }))
  try {
    const result = await service.crawl([`http://127.0.0.1:${address.port}/`], { maxPages: 1, maxDepth: 0 })
    assert.equal(requests, 2)
    assert.equal(result.pages.length, 1)
    assert.equal(result.errors.length, 0)
    assert.equal(result.stats.backoffEvents, 1)
    assert.match(result.pages[0]?.text ?? '', /Recovered after backoff/)
    assert.ok(observedCookies.every(value => !value.includes('crawl_session')))
    await assert.rejects(() => service.crawl([`http://127.0.0.1:${address.port}/`], { maxPages: 3 }), /maxPages/)
  } finally {
    await service.close()
    await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()))
    fs.rmSync(authDir, { recursive: true, force: true })
  }
})
