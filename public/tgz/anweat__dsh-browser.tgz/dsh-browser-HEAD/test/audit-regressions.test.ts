import test from 'node:test'
import assert from 'node:assert/strict'
import http from 'node:http'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { BrowserService } from '../src/browser-service.ts'
import { resolveConfig } from '../src/config.ts'
import { registerTools } from '../src/tools.ts'
import { browserPolicyDecision } from '../src/approval-policy.ts'
import { validateRecipe } from '../src/automation.ts'
import { registerAutomationAssetRpc } from '../src/automation-assets-rpc.ts'
import { connectionContext } from './rpc-fixture.ts'

test('waits cannot disable timeouts and primitive writes retain approvals', () => {
  assert.throws(() => validateRecipe([{ type: 'wait', condition: 'selector', value: '#missing', timeoutMs: 0 }]), /timeoutMs/)
  assert.throws(() => validateRecipe([{ type: 'wait', condition: 'unknown' } as never]), /condition/)
  for (const name of ['act.press', 'act.select', 'act.check']) {
    assert.equal(browserPolicyDecision(name, {}, 'read-only').kind, 'deny')
    assert.equal(browserPolicyDecision(name, {}, 'standard').kind, 'ask')
    assert.equal(browserPolicyDecision(name, {}, 'autonomous').kind, 'allow')
  }
})

test('real browser handles primitives and hidden uploads; redirects cannot expand script matches', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-browser-audit-'))
  const server = http.createServer((req, res) => {
    if (req.url === '/redirect') { res.writeHead(302, { location: '/outside' }); res.end(); return }
    if (req.url === '/outside') { res.end('<title>outside</title>'); return }
    res.setHeader('content-type', 'text/html')
    res.end('<title>fixture</title><input id="q" onkeydown="if(event.key===\'Enter\')document.body.dataset.enter=\'yes\'"><select id="s"><option value="a">A</option><option value="b">B</option></select><input id="c" type="checkbox"><input id="f" type="file" hidden><p>ready</p>')
  })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  const base = 'http://127.0.0.1:' + (server.address() as { port: number }).port
  const config = resolveConfig({ snapshotDir: dir, channel: 'chrome', headless: true, autoInstall: false, automationMode: 'unrestricted' })
  const service = new BrowserService(config)
  const definitions = new Map<string, any>()
  registerTools({ tools: { register: (tool: any) => definitions.set(tool.name, tool) } } as never, config, service)
  try {
    await assert.rejects(service.open('file:///fixture.txt'), /HTTP/)
    await service.open(base)
    const call = async (action: string, args: unknown) => {
      const reply = await definitions.get('browser_call').execute({ action, args }, { signal: new AbortController().signal })
      assert.equal(reply.ok, true, JSON.stringify(reply))
      return reply
    }
    await call('act.wait', { selector: 'p', timeoutMs: 1000 })
    await call('act.press', { selector: '#q', key: 'Enter' })
    await call('act.select', { selector: '#s', values: ['b'] })
    await call('act.check', { selector: '#c', checked: true })
    const file = path.join(dir, 'fixture.txt'); fs.writeFileSync(file, 'fixture')
    await service.setFiles('#f', [file], { timeoutMs: 1000 })
    const state = await service.evaluate('({enter:document.body.dataset.enter,selected:document.querySelector("#s").value,checked:document.querySelector("#c").checked,files:document.querySelector("#f").files.length})')
    assert.deepEqual(JSON.parse(state.resultJson), { enter: 'yes', selected: 'b', checked: true, files: 1 })
    const source = '// ==UserScript==\n// @name redirect test\n// @match http://127.0.0.1/redirect\n// @grant none\n// ==/UserScript==\nreturn document.title'
    await assert.rejects(service.runUserscript(base + '/redirect', source), /redirected outside/)
  } finally {
    await service.close()
    await new Promise<void>(resolve => server.close(() => resolve()))
    fs.rmSync(dir, { recursive: true, force: true })
  }
})

test('asset API mounts through a derived Context that carries webServer as an own property (cordis 4.1, #49)', async () => {
  const calls: { owner: any; channel: string }[] = []
  let handler: any
  // `rpc.handle` reads `owner.webServer`; on the plain Context that throws, as on DSH 0.2.2-rc.1.
  const ctx = connectionContext((owner, channel, h) => { calls.push({ owner, channel }); handler = h; return async () => {} })
  assert.throws(() => ctx.connection.rpc.handle('/x', () => ({ ok: true })), /cannot get property "webServer" without inject/)
  registerAutomationAssetRpc(ctx, { snapshot: () => ({ assets: [] }) } as never, {} as never)
  assert.equal(calls.length, 1)
  assert.equal(calls[0]!.channel, '/dsh-browser-assets')
  const owner = calls[0]!.owner
  assert.notEqual(owner, ctx, 'handle must be called on the derived Context, not the one the inject callback received')
  assert.ok(Object.hasOwn(owner, 'webServer'), 'webServer must be an own property of the derived Context')
  assert.equal(Object.getPrototypeOf(owner), ctx)
  const peer = { id: 'test-peer', ctx: {} as never, dispose: async () => {} }
  assert.deepEqual(await handler('snapshot', {}, new AbortController().signal, peer), { ok: true, value: { assets: [] } })
})

test('asset API warns with the channel and the reason, without ANSI, when the channel cannot be mounted', () => {
  const failing = connectionContext(() => { throw new Error('\u001b[31mboom: duplicate prefix route\u001b[0m') })
  const warnings: string[] = []
  const realWarn = console.warn
  console.warn = (message: string) => { warnings.push(message) }
  try { registerAutomationAssetRpc(failing, {} as never, {} as never) } finally { console.warn = realWarn }
  assert.equal(warnings.length, 1)
  assert.match(warnings[0]!, /settings-card RPC channel \/dsh-browser-assets was not mounted \(boom: duplicate prefix route\)/)
  assert.doesNotMatch(warnings[0]!, /\u001b/)
})

test('asset API registers its own channel and never intercepts the shared one', async () => {
  let channel: string | undefined
  let handler: any
  const disposers: (() => void)[] = []
  const ctx = connectionContext((_owner, ch, h) => {
    channel = ch; handler = h
    return async () => { channel = undefined; handler = undefined }
  })
  const inject = ctx.inject
  ctx.inject = (names: unknown, setup: (ctx: unknown) => void) => { assert.deepEqual(names, ['connection', 'webServer']); inject(names, setup) }
  ctx.effect = (setup: () => () => void) => { disposers.push(setup()) }
  registerAutomationAssetRpc(ctx, { snapshot: () => ({ assets: [] }) } as never, {} as never)
  assert.equal(channel, '/dsh-browser-assets', 'the plugin must own a private channel')
  assert.ok(handler, 'the channel handler was not registered')

  // The Host transport owns envelope decoding, authentication, and the Peer
  // scope, so the handler receives an endpoint relative to the channel.
  const peer = { id: 'test-peer', ctx: {} as never, dispose: async () => {} }
  const ok = await handler('snapshot', {}, new AbortController().signal, peer)
  assert.deepEqual(ok, { ok: true, value: { assets: [] } })
  const unknown = await handler('unknown', {}, new AbortController().signal, peer)
  assert.equal(unknown.ok, false)
  assert.equal(unknown.error.code, 'not-found')
  for (const dispose of disposers) dispose()
  assert.equal(channel, undefined, 'the channel survived disposal')
})

test('auth profiles filter foreign storage; domains are admission rules, not a network firewall', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-browser-auth-audit-'))
  let foreignHits = 0
  const server = http.createServer((req, res) => {
    if (req.headers.host?.startsWith('localhost')) { foreignHits++; res.end('foreign'); return }
    if (req.url === '/chain') { res.writeHead(302, { location: '/redirect' }); res.end(); return }
    if (req.url === '/redirect') { res.writeHead(302, { location: `http://localhost:${(server.address() as { port: number }).port}/foreign` }); res.end(); return }
    res.end('<title>auth</title>')
  })
  await new Promise<void>(resolve => server.listen(0, resolve))
  const base = `http://127.0.0.1:${(server.address() as { port: number }).port}`
  const storageStatePath = path.join(dir, 'state.json')
  fs.writeFileSync(storageStatePath, JSON.stringify({ cookies: [
    { name: 'allowed', value: 'fixture', domain: '127.0.0.1', path: '/', expires: -1, httpOnly: false, secure: false, sameSite: 'Lax' },
    { name: 'foreign', value: 'fixture', domain: 'localhost', path: '/', expires: -1, httpOnly: false, secure: false, sameSite: 'Lax' },
  ], origins: [] }))
  const service = new BrowserService(resolveConfig({ channel: 'chrome', snapshotDir: dir, autoInstall: false,
    authProfiles: { fixture: { storageStatePath, allowedDomains: ['127.0.0.1'] } },
  }))
  try {
    await service.open(base, { authProfile: 'fixture' })
    // PR #36 moved the active context into per-session state; calls without a session key use the 'shared' bucket.
    const state = await (service as any).sessions.get('shared').context.storageState()
    assert.deepEqual(state.cookies.map((cookie: any) => cookie.name), ['allowed'])
    await assert.rejects(service.open(base.replace('127.0.0.1', 'localhost'), { authProfile: 'fixture' }), /not allowed/)
    assert.equal(foreignHits, 0)
  } finally {
    await service.close()
    await new Promise<void>(resolve => server.close(() => resolve()))
    fs.rmSync(dir, { recursive: true, force: true })
  }
})
