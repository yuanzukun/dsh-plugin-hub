/**
 * Error mapping: Playwright and service errors to the structured codes of the
 * tool contract (§5). The original message is always preserved; the code and
 * hint only add what the model should do next.
 * @module dsh-browser/actions/errors
 */

import { ActionArgError, ActionUnavailableError, type ActionErrorBody, type ErrorCode } from './types.ts'
import { LocatorAmbiguousError, TargetStaleError } from '../locator.ts'

/** The built-in hint of every error code that has one fixed text. These are what `prompts.errorHints` can replace. */
export const DEFAULT_ERROR_HINTS: Readonly<Partial<Record<ErrorCode, string>>> = {
  LOCATOR_NOT_FOUND: 'No element matched. Re-read the page (observe.read), check the locator, and wait for dynamic content (act.wait) before retrying.',
  LOCATOR_AMBIGUOUS: 'More than one element matched and nothing was done. Pick the intended element from candidates: narrow the locator (role+name, exact, label, testId, frame), or give index with indexReason.',
  NOT_ACTIONABLE: 'The element exists but cannot take this action now (hidden, disabled, covered, or still moving). Wait for it or dismiss the overlay.',
  TARGET_CLOSED: 'The page is gone or none is open. Call target.open first.',
  TARGET_STALE: 'The page navigated, reloaded, or changed history since you observed it, and nothing was done. Call observe.read again, check the page is still the one you meant, then retry with the new generation (current.generation).',
  DEADLINE: 'The action ran out of time. Re-read the page to see whether it took effect before retrying.',
  CANCELLED: 'The call was cancelled before it finished.',
  CAPABILITY_UNAVAILABLE: 'This capability is not available in the current setup (see browser_index() for runtime state; runtime.status says which browser launches; runtime.install downloads Chromium when no Chrome / Edge is installed).',
  POLICY_DENIED: 'Blocked by the plugin policy for this automationMode or by input validation.',
  NOT_FOUND: 'The referenced item does not exist. Use automation.search to find valid ids.',
  VALIDATION_FAILED: 'The steps ran but an assert step did not hold, so the business result is not confirmed. Read the page (observe.read) to see what happened; if earlier steps submitted something, do not run them again blindly.',
  OUTCOME_UNKNOWN: 'A side-effecting step timed out, so it may or may not have taken effect. Verify the real result on the page (observe.read) before any retry; never resubmit blindly.',
  VALIDATION_MISSING: 'The steps ran, but nothing in this asset verifies the result, so the test cannot pass. Add an assert step or a postcondition that proves the outcome, save (a new revision), and test again.',
  INVALID_RECIPE: 'The recipe itself is malformed (see the message). Fix the step and send it again; nothing ran.',
}

type HintSource = () => Readonly<Partial<Record<string, string>>>

/**
 * Deployment overrides of the hint per error code (`prompts.errorHints`).
 *
 * `mapError` and `hintFor` are called from places that hold no configuration (recipe execution, asset replay),
 * so the overrides are ambient: the plugin installs a source on apply and removes it when its fiber goes away.
 * The source is read on every call, which is what makes a config change take effect without a restart.
 * The most recently installed source wins; with none installed the built-in texts apply.
 */
const hintSources: HintSource[] = []

/** Install a live source of hint overrides. @returns the function that removes it. */
export function installErrorHints(source: HintSource): () => void {
  hintSources.push(source)
  return () => {
    const index = hintSources.lastIndexOf(source)
    if (index >= 0) hintSources.splice(index, 1)
  }
}

/** The hint for a code: the configured override, else the built-in text (undefined when the code has none). */
export function hintFor(code: ErrorCode): string | undefined {
  const source = hintSources[hintSources.length - 1]
  return source?.()[code] ?? DEFAULT_ERROR_HINTS[code]
}

/** Thrown by a recipe `assert` step whose condition did not become true in time. */
export class RecipeAssertionError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'RecipeAssertionError'
  }
}

/** Thrown for a malformed recipe (bad step fields, out-of-range limits, unknown enum values). */
export class RecipeValidationError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'RecipeValidationError'
  }
}

/** The abort reason of an action whose overall deadline expired, so a stop can be told apart from a user cancel. */
export class DeadlineError extends Error {
  constructor(message = 'deadline') {
    super(message)
    this.name = 'DeadlineError'
  }
}

/** True when the signal was aborted because the overall deadline expired. */
export function abortedByDeadline(signal: AbortSignal | undefined): boolean {
  return signal?.aborted === true && (signal.reason as { name?: unknown } | undefined)?.name === 'DeadlineError'
}

/** True for a Playwright timeout (waiting for a locator, an actionability check, or a navigation). */
export function isTimeoutError(error: unknown): boolean {
  if (error instanceof Error && error.name === 'TimeoutError') return true
  return /Timeout \d+ms exceeded|timed out after/i.test(messageOf(error))
}

/** Playwright colours its call log for terminals; the model and the settings card get plain text. */
export function stripAnsi(text: string): string {
  return text.replace(/\u001b\[[0-9;]*m/g, '')
}

function messageOf(error: unknown): string {
  return stripAnsi(error instanceof Error ? error.message : String(error))
}

const NOT_ACTIONABLE_LOG = /locator resolved to|element is not (visible|enabled|stable|editable)|intercepts pointer events|is outside of the viewport|element is disabled|not receive pointer events|Element is not an <input>|readonly/i
const CLOSED = /Target (page, context or browser has been )?closed|Page closed|has been closed|browser has been closed|Browser closed|Connection closed|Session closed/i
const UNAVAILABLE = /chromium is not installed|No browser is available to launch|channel is \S+ but that browser is not installed|executablePath does not exist|It could not be started|Executable doesn't exist|browser service is disabled|OpenCLI is disabled|persistence is disabled|automation development is disabled|automation assets are unavailable|could not be created/i
const NO_PAGE = /requires url or an active|no active page|active .* page/i
const POLICY = /is not allowed (for|on)|outside its allowed match|userscript is invalid|userscript validation failed|auth profile .* (not allowed|storageState)|requires explicit keywords|limit reached/i
const NOT_FOUND_RE = /(asset|candidate) not found|unknown (auth profile|rule pack|built-in script)/i
const INVALID = /(must be|must contain|must use|must end|must start|must include|requires|exceeds|is invalid|invalid |unsupported|exactly one|only valid with|cannot combine|not a file|absolute file|missing declared|undeclared|is required|only supports|only draft|only http)/i

/** Call-log lines that only appear once Playwright has resolved the element and started working on it. */
const ACTION_STARTED_LOG = /locator resolved to|resolved to \d+ elements|attempting .* action|performing .* action|scrolling into view|waiting for element to be|element is |intercepts pointer events|waiting for scheduled navigations|waiting for navigation/i

/**
 * True when a failure proves the action never touched an element: the locator
 * never matched anything (a timeout whose call log only says "waiting for
 * locator", or a frame that does not exist). A timeout after the element was
 * resolved and the action began says nothing about whether it took effect, so
 * it is not this. Judged from Playwright's call log; a timeout without a call
 * log is treated as "unknown", never as "never reached".
 */
export function neverReachedElement(error: unknown): boolean {
  const message = messageOf(error)
  if (/target frame was not found/i.test(message)) return true
  if (!isTimeoutError(error)) return false
  return /waiting for (locator|selector|getBy|frameLocator)/i.test(message) && !ACTION_STARTED_LOG.test(message)
}

/** Call-log lines that prove Playwright was still waiting for the element to become actionable. */
const WAITING_ON_ELEMENT_LOG = /element is not (visible|enabled|stable|editable)|intercepts pointer events/i
/** Call-log lines that appear only once the action itself is being carried out (or its checks passed for a fill). */
const ACTION_PERFORMED_LOG = /performing .* action|action done|element is visible, enabled and editable/i

/**
 * True when a timeout proves the action never ran although the element was found: the call log shows
 * Playwright waiting for it to become visible, enabled, stable or editable (or for an overlay to move)
 * and never reaches the line that says the action is being performed. Needs a call log; without one
 * (or with a performed marker) the outcome stays unknown.
 */
export function blockedBeforeAction(error: unknown): boolean {
  if (!isTimeoutError(error)) return false
  const message = messageOf(error)
  return /Call log:/i.test(message) && WAITING_ON_ELEMENT_LOG.test(message) && !ACTION_PERFORMED_LOG.test(message)
}

/** Map any thrown value to a structured error body. */
export function mapError(error: unknown, action: string, opts: { signal?: AbortSignal } = {}): ActionErrorBody {
  if (error instanceof ActionArgError) return { code: 'INVALID_ARGS', message: error.message, ...error.hint ? { hint: error.hint } : {} }
  if (error instanceof ActionUnavailableError) return { code: 'CAPABILITY_UNAVAILABLE', message: error.message, hint: error.hint ?? hintFor('CAPABILITY_UNAVAILABLE')! }
  const message = messageOf(error)
  const name = error instanceof Error ? error.name : ''
  const result = (code: ErrorCode, hint = hintFor(code)): ActionErrorBody => ({ code, message, ...hint ? { hint } : {} })

  if (error instanceof LocatorAmbiguousError) return { ...result('LOCATOR_AMBIGUOUS'), candidates: error.ambiguity }
  if (error instanceof TargetStaleError) return { ...result('TARGET_STALE'), current: error.current }
  if (error instanceof RecipeValidationError) return result('INVALID_RECIPE')
  if (error instanceof RecipeAssertionError) return result('VALIDATION_FAILED')
  if (abortedByDeadline(opts.signal)) return result('DEADLINE')
  // A download over its size cap is a failure of the action, not a cancellation: nothing was cancelled by the caller
  // (the word "aborted" in older messages used to land it in CANCELLED below).
  if (/larger than downloadMaxBytes/.test(message)) {
    return { code: 'ACTION_FAILED', message, hint: 'The file is larger than the downloadMaxBytes limit and nothing was saved; this is not a cancellation. The user can raise downloadMaxBytes in the settings, or choose a smaller file.' }
  }
  if (opts.signal?.aborted || name === 'AbortError' || /\baborted\b/i.test(message)) return result('CANCELLED')
  if (CLOSED.test(message)) return result('TARGET_CLOSED')
  if (name === 'TimeoutError' || /Timeout \d+ms exceeded|timed out after/i.test(message)) {
    // Waits time out by design; everything else distinguishes "never found" from "found but blocked".
    if (action === 'act.wait' || /timed out after/i.test(message)) return result('DEADLINE')
    if (NOT_ACTIONABLE_LOG.test(message)) return result('NOT_ACTIONABLE')
    // "Never found" only when the log stops at the wait; once the element was resolved and the action began, the cause is the deadline.
    if (/waiting for (locator|selector|getBy|frameLocator)/i.test(message) && !ACTION_STARTED_LOG.test(message)) return result('LOCATOR_NOT_FOUND')
    return result('DEADLINE')
  }
  if (/strict mode violation/i.test(message)) return result('LOCATOR_AMBIGUOUS')
  if (/target frame was not found/i.test(message)) return result('LOCATOR_NOT_FOUND')
  if (UNAVAILABLE.test(message)) return result('CAPABILITY_UNAVAILABLE')
  if (NO_PAGE.test(message)) return result('TARGET_CLOSED')
  if (NOT_FOUND_RE.test(message)) return result('NOT_FOUND')
  if (POLICY.test(message)) return result('POLICY_DENIED')
  if (INVALID.test(message)) return result('INVALID_ARGS', 'Check the arguments with browser_index({action}).')
  return result('ACTION_FAILED', 'The action failed; read the message, and re-observe the page before retrying side-effecting actions.')
}
