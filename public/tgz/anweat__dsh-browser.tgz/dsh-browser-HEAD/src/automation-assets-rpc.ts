/** Loopback-only Host RPC for the automation asset review UI. */

import type { Context } from '@deepseek-ai/cordis'
import type { ConnectionRpcHandler } from '@deepseek-ai/dsh-client-connection'
import { ActivationRefusedError, type AutomationAsset, type AutomationAssetStatus, type AutomationAssetStore } from './automation-assets.ts'
import type { BrowserService } from './browser-service.ts'
import { executeAutomationAsset, executeDraftInputSets } from './automation-execution.ts'
import { convertV1ToV2Draft } from './automation-convert.ts'
import { promptsDumpText } from './prompts.ts'
import { promptsDumpYaml } from './prompts-yaml.ts'
import { stripAnsi } from './actions/errors.ts'

/**
 * This plugin's own logical RPC channel.
 *
 * NOT the shared `/api`: `intercept('/api', …)` does not share that channel, it
 * REPLACES its fallback — the interceptor's `matches` gate becomes the only
 * route resolution, so every other plugin's endpoint (`settings/describe`,
 * `session/list`, …) starts returning 404 and the whole Web UI loses its API.
 * A plugin that owns its endpoints registers a private channel instead.
 */
const CHANNEL = '/dsh-browser-assets'

function record(payload: unknown): Record<string, unknown> {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new Error('request payload must be an object')
  if (JSON.stringify(payload).length > 100_000) throw new Error('request payload exceeds 100000 characters')
  return payload as Record<string, unknown>
}

function stringField(payload: Record<string, unknown>, name: string): string {
  const value = payload[name]
  if (typeof value !== 'string' || value.length < 1 || value.length > 200) throw new Error(`${name} must be a non-empty string`)
  return value
}

/** A failure the review UI should tell apart from a transport or storage error. `details.errorCode` names it. */
export class AssetRpcFailure extends Error {
  constructor(message: string, readonly details: Record<string, unknown>) {
    super(message)
    this.name = 'AssetRpcFailure'
  }
}

function expectedRevision(payload: Record<string, unknown>): number | undefined {
  const value = payload.expectedRevision
  if (value === undefined || value === null) return undefined
  if (typeof value !== 'number' || !Number.isInteger(value)) throw new Error('expectedRevision must be an integer')
  return value
}

/** The part of the Host's `connection` service this file uses. */
interface ConnectionRegistrar {
  rpc: {
    /** Register one authenticated absolute channel prefix owned by this plugin. */
    handle(channel: string, handler: ConnectionRpcHandler): () => Promise<void>
  }
}

/**
 * The Context to read the Host's `connection` service through.
 *
 * `connection.rpc.handle` mounts the Web route with `owner.webServer.register(route)`, where `owner` is the Context
 * the `rpc` getter captured (`this.ctx`) when the service was read. On cordis 4.0.x any Context could do that. On
 * cordis 4.1 (DSH 0.2.2) the service getter resolves `webServer` against the Connection plugin's own definition site,
 * whose `inject` list does not include `webServer`, so `rpc.handle` throws `cannot get property "webServer" without
 * inject` (DSH master still has this code). The throw happened inside an inject callback and nothing reported it: the
 * channel was never mounted and every `/dsh-browser-assets/*` call from the settings card came back HTTP 405.
 * Reading `connection` through a derived Context that carries the already-injected `webServer` as its own property
 * makes `owner.webServer` resolve there. `Context.extend` is public API, no private Host member is involved, and the
 * route, the envelope, the authentication fence and the Peer scope are the Host's own. The technique is from
 * anweat/dsh-browser#49 (@shuaigekda); it is used on every host, 4.0.x included, so there is one code path.
 * Replacing the root Context with plain `connectionCtx` is not enough.
 */
function connectionWithWebServer(connectionCtx: Context): ConnectionRegistrar {
  const withWebServer = connectionCtx.extend({ webServer: (connectionCtx as unknown as { get(name: string): unknown }).get('webServer') })
  return (withWebServer as unknown as { connection: ConnectionRegistrar }).connection
}

/** `promptsStatus` answers the settings card's "prompt text" section: the overrides in force, diagnostics and the L0 estimate. */
export function registerAutomationAssetRpc(ctx: Context, store: AutomationAssetStore, service: BrowserService, promptsStatus?: () => unknown): void {
  ctx.inject(['connection', 'webServer'], (connectionCtx) => {
    // Register the channel with the Host transport rather than hand-rolling the
    // client-request/server-response envelope on an exact Fetch route. The
    // transport owns envelope decoding, the admission/authentication fence, the
    // cancellation signal, and the Peer scope the handler receives — none of
    // which a manual route can reconstruct.
    // The registrar mounts its Web route through the Context that read it (see connectionWithWebServer);
    // the plugin effect owns cleanup.
    const handler: ConnectionRpcHandler = async (endpoint, rawPayload) => {
      try {
        // The transport hands the handler the endpoint relative to the channel,
        // so a request to `/dsh-browser-assets/snapshot` arrives as `snapshot`.
        const payload = record(rawPayload)
        let value: unknown
        switch (endpoint) {
          case 'snapshot': value = store.snapshot(); break
          case 'get': value = store.get(stringField(payload, 'id')) ?? null; break
          case 'save': value = store.saveDraft(payload.asset as Partial<AutomationAsset> & Pick<AutomationAsset, 'kind' | 'name'>); break
          case 'fork': value = store.fork(stringField(payload, 'id')); break
          case 'summarize': value = store.summarizeCandidate(stringField(payload, 'id')); break
          case 'dismiss': store.dismissCandidate(stringField(payload, 'id')); value = store.snapshot(); break
          case 'validate': value = store.validate(stringField(payload, 'id')); break
          case 'test': {
            if (payload.inputSets !== undefined) {
              if (payload.inputs !== undefined) throw new Error('pass either inputs (one run) or inputSets (2 to 5 runs), not both')
              // Each set runs in a fresh context; the credential the store keeps records every set (digests only), which is what the panel shows.
              const replay = await executeDraftInputSets(service, store, stringField(payload, 'id'), stringField(payload, 'url'), payload.inputSets, { expectedRevision: expectedRevision(payload) })
              if (!replay.succeeded) {
                const failed = replay.sets.find(entry => !entry.passed)
                const errorCode = replay.verifierMissing ? 'VALIDATION_MISSING' : failed?.execution.failedStep?.errorCode ?? (failed?.execution.validationStatus === 'failed' ? 'VALIDATION_FAILED' : 'ACTION_FAILED')
                throw new AssetRpcFailure(
                  replay.verifierMissing?.message ?? `Input set ${(failed?.index ?? 0) + 1} of ${replay.planned} did not pass: ${failed?.execution.failedStep?.message ?? failed?.execution.message ?? 'the replay did not complete'}`,
                  { errorCode, failedSet: failed ? failed.index + 1 : undefined, inputSets: replay.planned, setsRun: replay.sets.length, revision: replay.asset.revision },
                )
              }
              value = replay.asset
              break
            }
            const result = await executeAutomationAsset(service, store, stringField(payload, 'id'), stringField(payload, 'url'), payload.inputs, 'draft', { expectedRevision: expectedRevision(payload) })
            // The review UI shows a failed replay as an error, as it did when a failure threw. The errorCode lets it
            // say "the result did not hold" (VALIDATION_FAILED / VALIDATION_MISSING) apart from a backend problem.
            if (!result.succeeded) {
              const execution = result.execution
              const errorCode = result.verifierMissing ? 'VALIDATION_MISSING' : execution.failedStep?.errorCode ?? (execution.validationStatus === 'failed' ? 'VALIDATION_FAILED' : 'ACTION_FAILED')
              throw new AssetRpcFailure(
                result.verifierMissing?.message ?? execution.failedStep?.message ?? execution.message ?? 'Runtime replay did not complete.',
                { errorCode, executionStatus: execution.executionStatus, validationStatus: execution.validationStatus, effects: execution.effects, revision: result.asset.revision },
              )
            }
            value = result.asset
            break
          }
          case 'convert': {
            // Same conversion as `automation.develop convert`: the source is only read; the result is a NEW v2 draft.
            const source = store.get(stringField(payload, 'id'))
            if (!source) throw new Error('automation asset not found')
            const conversion = convertV1ToV2Draft(source)
            value = { draft: store.saveDraft(conversion.draft), pendingDisambiguation: conversion.pendingDisambiguation, notes: conversion.notes }
            break
          }
          case 'prompts': value = promptsStatus ? promptsStatus() : null; break
          // The policy overlay (see policy-overlay.ts): what the settings card's overlay section shows and clears.
          case 'policy': value = service.policyReport({ auditLimit: 20 }); break
          // Which browser a launch would use and whether OpenCLI is installed: the card's "runtime" notices. Read-only, launches nothing.
          case 'runtime': {
            const status = await service.status()
            value = {
              browser: status.browser, systemBrowsers: status.systemBrowsers, chromiumInstalled: status.chromiumInstalled,
              opencli: { enabled: status.opencliEnabled, installed: status.opencliInstalled, ...status.opencliSource ? { source: status.opencliSource } : {}, ...status.opencliInstallHint ? { hint: status.opencliInstallHint } : {} },
            }
            break
          }
          case 'policyReset': {
            const scope = payload.scope
            if (scope !== 'all' && scope !== 'usagePolicy' && scope !== 'authProfile') throw new Error('scope must be all, usagePolicy or authProfile')
            await service.changePolicy(
              { kind: 'reset', scope, ...typeof payload.id === 'string' ? { id: payload.id } : {} },
              { source: 'panel', action: 'panel.reset', reason: 'Cleared from the settings card', ...expectedRevision(payload) !== undefined ? { expectedRevision: expectedRevision(payload) } : {} },
            )
            value = service.policyReport({ auditLimit: 20 })
            break
          }
          // The same JSON `prompts:dump` prints, for installs that have no script environment.
          case 'promptsDefaults': value = { json: promptsDumpText() }; break
          // The same defaults as commented YAML (every section says where the model reads it), in the card's language.
          case 'promptsDefaultsYaml': value = { yaml: promptsDumpYaml(payload.lang === 'zh' ? 'zh' : 'en') }; break
          case 'status': value = store.setStatus(stringField(payload, 'id'), stringField(payload, 'status') as AutomationAssetStatus, { expectedRevision: expectedRevision(payload) }); break
          default: return { ok: false, error: { code: 'not-found' as const, message: `unknown automation asset endpoint: ${endpoint}`, details: {} } }
        }
        return { ok: true, value }
      } catch (error) {
        const details = error instanceof AssetRpcFailure ? error.details : error instanceof ActivationRefusedError ? { errorCode: 'ACTIVATION_REFUSED', reason: error.reason } : {}
        return { ok: false, error: { code: 'bad-request' as const, message: stripAnsi(String(error instanceof Error ? error.message : error)).slice(0, 500), details } }
      }
    }
    connectionCtx.effect(() => {
      try {
        return connectionWithWebServer(connectionCtx).rpc.handle(CHANNEL, handler)
      } catch (error) {
        // An inject callback's throw is not reported by the Host (this is how the cordis 4.1 failure stayed invisible),
        // so say it ourselves: the card still renders, but every `/dsh-browser-assets/*` request is HTTP 405.
        const message = `dsh-browser: settings-card RPC channel ${CHANNEL} was not mounted (${stripAnsi(String(error instanceof Error ? error.message : error))}); the card's assets, prompts, policy and runtime panels will not load`
        // console, not ctx.logger: the Host's logger was observed dropping this at its default level (nothing reached the log).
        console.warn(message)
        return () => {}
      }
    }, 'dsh-browser: automation asset RPC channel')
  })
}
