/**
 * 牛来桌宠 — DSH/Cordis 插件入口
 *
 * 作为 DSH bundle 挂载后，profile 启动时本插件会在子进程中拉起 Electron
 * 桌宠应用；profile 退出时一并关闭桌宠进程。桌宠应用本体与 DSH 解耦，
 * 也可通过 `npm start` 独立运行。
 *
 * @module niulai-pet/pet
 */
import { spawn } from 'node:child_process'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

export const name = 'niulai-pet'
export const inject = []

// 本包根目录(Electron 应用根)，src/pet/ 上溯两级
const APP_ROOT = fileURLToPath(new URL('../..', import.meta.url))
const require_ = createRequire(import.meta.url)

function resolveElectron(override) {
  if (override) return override
  try {
    // electron 包在 Node 环境下 require 返回的是可执行文件路径字符串
    const p = require_('electron')
    return typeof p === 'string' && p.length > 0 ? p : ''
  } catch {
    return ''
  }
}

export function apply(ctx, config = {}) {
  if (config.enabled === false) return

  const electronPath = resolveElectron(config.electron)
  if (!electronPath) {
    const msg = '[niulai-pet] 未找到 electron 可执行文件：请在该 profile 中安装 electron，或配置 electron 路径'
    ctx.logger?.warn?.(msg)
    console.warn(msg)
    return
  }

  const child = spawn(electronPath, [APP_ROOT], {
    cwd: APP_ROOT,
    // 捕获 stderr 便于诊断；GUI 应用本身不需要 stdio
    stdio: ['ignore', 'ignore', 'pipe'],
    env: { ...process.env }
  })

  let stderr = ''
  child.stderr?.on('data', (d) => { stderr += d.toString() })

  child.on('error', (err) => {
    const msg = `[niulai-pet] 启动失败: ${err.message}`
    ctx.logger?.warn?.(msg)
    console.warn(msg)
  })

  child.on('spawn', () => {
    const msg = `[niulai-pet] 已拉起桌宠进程 (pid=${child.pid})`
    ctx.logger?.info?.(msg)
    console.log(msg)
  })

  child.on('exit', (code, signal) => {
    const tail = stderr.trim() ? ` | stderr: ${stderr.trim().slice(0, 500)}` : ''
    const msg = `[niulai-pet] 桌宠进程退出 (code=${code} signal=${signal})${tail}`
    ctx.logger?.warn?.(msg)
    console.warn(msg)
  })

  // profile 退出时关闭桌宠
  ctx.effect(() => {
    if (child && child.exitCode === null && !child.killed) {
      try {
        child.kill()
      } catch {
        /* 忽略 */
      }
    }
  }, 'niulai-pet.kill()')
}
