/**
 * Preload — 通过 contextBridge 暴露最小化的 IPC 接口给渲染进程。
 * 使用 .cjs 扩展名以保证在 "type": "module" 的项目里仍按 CommonJS 加载。
 */
const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('pet', {
  getQuote: () => ipcRenderer.invoke('pet:get-quote'),
  getState: () => ipcRenderer.invoke('pet:get-state'),
  toggleAutostart: () => ipcRenderer.invoke('pet:toggle-autostart'),

  dragStart: () => ipcRenderer.send('pet:drag-start'),
  dragMove: (dx, dy) => ipcRenderer.send('pet:drag-move', { dx, dy }),
  dragEnd: () => ipcRenderer.send('pet:drag-end'),

  hide: () => ipcRenderer.send('pet:hide'),
  quit: () => ipcRenderer.send('pet:quit'),

  onRefresh: (callback) => ipcRenderer.on('pet:refresh', () => callback())
})
