/**
 * A股实时行情获取 (A-share realtime quote fetcher).
 *
 * 主数据源: 东方财富 push2 接口 (返回 UTF-8 JSON)
 * 备用数据源: 腾讯财经 qt.gtimg.cn (返回 GBK 文本)
 *
 * 两者都通过「现价 vs 昨收」计算涨跌幅，避免依赖各家返回里
 * 涨跌幅字段的小数位缩放差异，保证结果稳定一致。
 *
 * 默认追踪上证指数 (secid=1.000001 / sh000001)，可在下方修改。
 */

const INDEX = {
  name: '上证指数',
  code: '000001',
  secid: '1.000001', // 东方财富: 1=沪市, 0=深市
  tencent: 'sh000001'
}

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36'
const TIMEOUT_MS = 8000

function round(value, digits = 2) {
  const p = 10 ** digits
  return Math.round(value * p) / p
}

function buildQuote(name, code, current, prevClose) {
  const change = current - prevClose
  const changePercent = prevClose === 0 ? 0 : (change / prevClose) * 100
  return {
    name: String(name ?? INDEX.name).trim(),
    code: String(code ?? INDEX.code).trim(),
    current: round(current),
    prevClose: round(prevClose),
    change: round(change),
    changePercent: round(changePercent),
    up: changePercent >= 0,
    time: new Date().toISOString()
  }
}

/** 东方财富 (UTF-8 JSON)。字段 f43=最新价 f57=代码 f58=名称 f60=昨收。 */
async function fetchEastmoney() {
  const url = `https://push2.eastmoney.com/api/qt/stock/get?secid=${INDEX.secid}&fields=f43,f57,f58,f60,f169,f170&invt=2&fltt=1`
  const res = await fetch(url, {
    headers: { 'User-Agent': UA, Referer: 'https://quote.eastmoney.com/' },
    signal: AbortSignal.timeout(TIMEOUT_MS)
  })
  if (!res.ok) throw new Error(`eastmoney HTTP ${res.status}`)
  const json = await res.json()
  const d = json?.data
  // fltt=1 时返回已除 100 的浮点数；若接口回退为整数则再除 100。
  const current = normPrice(d?.f43)
  const prevClose = normPrice(d?.f60)
  if (!Number.isFinite(current) || !Number.isFinite(prevClose) || prevClose === 0) {
    throw new Error('eastmoney 返回数据为空或无效')
  }
  return buildQuote(d?.f58, d?.f57, current, prevClose)
}

/**
 * 归一化价格：fltt=1 时接口直接给小数；部分场景仍给 x100 的整数，
 * 若数值异常大(>1e5)则按 /100 处理。
 */
function normPrice(v) {
  const n = Number(v)
  if (!Number.isFinite(n)) return NaN
  return Math.abs(n) > 1e5 ? n / 100 : n
}

/** 腾讯财经 (GBK 文本)。字段按 ~ 分隔: [1]名称 [2]代码 [3]现价 [4]昨收。 */
async function fetchTencent() {
  const url = `https://qt.gtimg.cn/q=${INDEX.tencent}`
  const res = await fetch(url, {
    headers: { 'User-Agent': UA, Referer: 'https://finance.qq.com/' },
    signal: AbortSignal.timeout(TIMEOUT_MS)
  })
  if (!res.ok) throw new Error(`tencent HTTP ${res.status}`)
  const buf = await res.arrayBuffer()
  const text = decodeGbk(buf)
  const match = /"(.*)"/s.exec(text)
  if (!match) throw new Error('tencent 返回格式异常')
  const parts = match[1].split('~')
  const current = parseFloat(parts[3])
  const prevClose = parseFloat(parts[4])
  if (!Number.isFinite(current) || !Number.isFinite(prevClose) || prevClose === 0) {
    throw new Error('tencent 返回数据无效')
  }
  return buildQuote(parts[1], parts[2], current, prevClose)
}

function decodeGbk(buf) {
  try {
    return new TextDecoder('gb18030').decode(buf)
  } catch {
    return new TextDecoder('utf-8').decode(buf)
  }
}

/**
 * 获取最新行情，主源失败自动切换备用源。
 * @returns {Promise<{name:string, code:string, current:number, prevClose:number,
 *   change:number, changePercent:number, up:boolean, time:string}>}
 */
export async function fetchQuote() {
  let lastError
  for (const fn of [fetchEastmoney, fetchTencent]) {
    try {
      return await fn()
    } catch (err) {
      lastError = err
    }
  }
  throw new Error(`行情获取失败: ${lastError?.message ?? '未知错误'}`)
}
