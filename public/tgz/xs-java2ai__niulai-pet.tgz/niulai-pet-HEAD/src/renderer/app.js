/**
 * 牛来桌宠 — 渲染进程逻辑
 * 拖拽移动(区分点击) + 点击切换图片/显示气泡/播放音效。
 */
const petImg = document.getElementById('pet-img')
const bubble = document.getElementById('bubble')

const ASSET = '../../assets/'
const NORMAL_IMG = `${ASSET}niu.png`
const SPEAK_IMG = `${ASSET}niu_speek.png`

// 音效预加载(异步加载，播放前已就绪)
const sounds = {
  up: new Audio(`${ASSET}niulai.mp3`),
  down: new Audio(`${ASSET}mama.mp3`)
}
for (const s of Object.values(sounds)) {
  s.preload = 'auto'
  s.load()
}

// 说话表情预加载，避免首次点击时闪白
new Image().src = SPEAK_IMG

let press = null
let busy = false
let hideTimer = null
const SPEAK_DURATION = 3800 // 气泡/表情保持时长(ms)
const DRAG_THRESHOLD = 4 // 移动超过该像素判定为拖拽而非点击

// ---------- 拖拽 vs 点击 ----------
window.addEventListener('pointerdown', (event) => {
  if (event.button !== 0) return
  press = {
    sx: event.screenX,
    sy: event.screenY,
    moved: false,
    onPet: event.target === petImg,
    lastDx: 0,
    lastDy: 0
  }
  window.pet.dragStart()
  try {
    event.target.setPointerCapture?.(event.pointerId)
  } catch {
    /* 忽略 */
  }
})

window.addEventListener('pointermove', (event) => {
  if (!press) return
  const dx = event.screenX - press.sx
  const dy = event.screenY - press.sy
  if (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD) {
    press.moved = true
  }
  if (press.moved) {
    // 用 CSS 像素(与窗口坐标同单位)计算增量，并去重，避免高 DPI 下漂移
    const rdx = Math.round(dx)
    const rdy = Math.round(dy)
    if (rdx !== press.lastDx || rdy !== press.lastDy) {
      press.lastDx = rdx
      press.lastDy = rdy
      window.pet.dragMove(rdx, rdy)
    }
  }
})

function endPress(event) {
  if (!press) return
  const wasClick = !press.moved && press.onPet
  press = null
  window.pet.dragEnd()
  if (wasClick) onPetClick()
}

window.addEventListener('pointerup', endPress)
window.addEventListener('pointercancel', endPress)

// ---------- 点击交互 ----------
async function onPetClick() {
  if (busy) return
  busy = true

  // 切换到“说话”表情 + 弹跳动画
  petImg.src = SPEAK_IMG
  petImg.classList.add('speaking')

  try {
    const quote = await window.pet.getQuote()
    renderBubble(quote)
    playSound(quote.up ? 'up' : 'down')
  } catch (err) {
    renderBubble({ error: err?.message ?? '行情获取失败' })
  } finally {
    scheduleReset()
  }
}

function scheduleReset() {
  clearTimeout(hideTimer)
  hideTimer = setTimeout(() => {
    petImg.src = NORMAL_IMG
    petImg.classList.remove('speaking')
    hideBubble()
    busy = false
  }, SPEAK_DURATION)
}

// ---------- 音效 ----------
function playSound(key) {
  const audio = sounds[key]
  if (!audio) return
  try {
    audio.pause()
    audio.currentTime = 0
    const p = audio.play()
    if (p && typeof p.catch === 'function') p.catch(() => {})
  } catch {
    /* 音频失败不影响主流程 */
  }
}

// ---------- 气泡 ----------
function renderBubble(quote) {
  bubble.classList.remove('up', 'down')

  if (quote?.error) {
    bubble.innerHTML = `
      <div class="b-title">牛来桌宠</div>
      <div class="b-err">${escapeHtml(quote.error)}</div>
    `
  } else {
    const cls = quote.up ? 'up' : 'down'
    const arrow = quote.up ? '▲' : '▼'
    const sign = quote.changePercent >= 0 ? '+' : ''
    const signChange = quote.change >= 0 ? '+' : ''
    bubble.innerHTML = `
      <div class="b-title">${escapeHtml(quote.name)}
        <span class="b-code">${escapeHtml(quote.code)}</span>
      </div>
      <div class="b-pct ${cls}">${arrow} ${sign}${quote.changePercent}%</div>
      <div class="b-sub">${escapeHtml(String(quote.current))}　${signChange}${quote.change}</div>
    `
  }

  bubble.classList.add('show')
}

function hideBubble() {
  bubble.classList.remove('show')
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;')
}

// ---------- 托盘“刷新行情” ----------
window.pet.onRefresh(() => onPetClick())
