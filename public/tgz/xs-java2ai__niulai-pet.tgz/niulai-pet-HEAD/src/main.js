/**
 * 牛来桌宠 — Electron 主进程
 *
 * 无边框 + 透明 + 置顶窗口、手动拖拽(区分点击)、系统托盘、开机自启、
 * 行情 IPC。渲染进程只负责展示与交互，行情请求在主进程完成(规避 CORS)。
 */
import { app, BrowserWindow, Tray, Menu, ipcMain, nativeImage, screen } from 'electron'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { fetchQuote } from './stock.js'

const __dirname = dirname(fileURLToPath(import.meta.url))
const ROOT = join(__dirname, '..')
const ASSETS = join(ROOT, 'assets')
const PRELOAD = join(__dirname, 'preload.cjs')
const RENDERER = join(__dirname, 'renderer', 'index.html')
const STATE_FILE = join(app.getPath('userData'), 'window-state.json')

// 窗口尺寸(宠物图 200x267 + 顶部气泡区)，图片保持 3:4 比例自适应
const WIN_W = 260
const WIN_H = 350

let win = null
let tray = null
let quitting = false
let autostart = false
let dragWinStart = null

// ---- 单实例：重复启动时唤起已有窗口 ----
if (!app.requestSingleInstanceLock()) {
  app.quit()
} else {
  app.on('second-instance', () => {
    if (!win) return
    if (win.isMinimized()) win.restore()
    win.show()
    win.focus()
  })

  app.whenReady().then(onReady)
}

function onReady() {
  autostart = app.getLoginItemSettings().openAtLogin
  createWindow()
  createTray()
  registerIpc()

  app.on('activate', () => {
    if (win) win.show()
  })
}

app.on('before-quit', () => {
  quitting = true
})

// 无边框窗口没有关闭按钮，关闭一律最小化到托盘，除非显式退出
app.on('window-all-closed', () => {
  /* 桌面宠物常驻托盘，不随窗口关闭退出 */
})

function createWindow() {
  const { x, y } = loadWindowState()

  win = new BrowserWindow({
    width: WIN_W,
    height: WIN_H,
    x,
    y,
    frame: false, // 无边框
    transparent: true, // 透明背景，只显示宠物剪影
    resizable: false,
    hasShadow: false,
    alwaysOnTop: true, // 置顶
    skipTaskbar: true, // 不占任务栏(托盘常驻)
    fullscreenable: false,
    maximizable: false,
    minimizable: false,
    show: false,
    webPreferences: {
      preload: PRELOAD,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  })

  win.setAlwaysOnTop(true, 'screen-saver')
  win.setMenuBarVisibility(false)
  if (process.platform === 'darwin') {
    win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true })
  }

  win.loadFile(RENDERER)

  win.once('ready-to-show', () => {
    // 开机自启且带 --hidden 时保持隐藏，否则显示
    if (!process.argv.includes('--hidden')) win.show()
  })

  win.on('close', (event) => {
    if (!quitting) {
      event.preventDefault()
      win.hide()
    }
  })

  win.on('move', () => saveWindowState())
  win.on('closed', () => {
    win = null
  })
}

function createTray() {
  const icon = nativeImage.createFromPath(join(ASSETS, 'tray.png'))

  if (tray) tray.destroy()
  tray = new Tray(icon)
  tray.setToolTip('牛来桌宠 · 点击查看 A股行情')

  const menu = Menu.buildFromTemplate([
    {
      label: '显示 / 隐藏桌宠',
      click: () => {
        if (!win) return
        win.isVisible() ? win.hide() : win.show()
      }
    },
    {
      label: '刷新行情',
      click: () => win && win.webContents.send('pet:refresh')
    },
    { type: 'separator' },
    {
      label: '开机自启',
      type: 'checkbox',
      checked: autostart,
      click: (item) => setAutostart(item.checked)
    },
    { type: 'separator' },
    {
      label: '退出',
      click: () => {
        quitting = true
        app.quit()
      }
    }
  ])
  tray.setContextMenu(menu)

  // 单击托盘图标切换显示/隐藏
  tray.on('click', () => {
    if (!win) return
    win.isVisible() ? win.hide() : win.show()
  })
}

function setAutostart(enabled) {
  autostart = enabled
  if (process.platform === 'darwin') {
    app.setLoginItemSettings({ openAtLogin: enabled })
  } else if (process.platform === 'win32') {
    // 开发模式(unpackaged)：electron.exe 需带上应用目录作为首个参数，
    // 否则开机启动时不知道加载哪个应用；打包后 exe 本身即应用。
    app.setLoginItemSettings({
      openAtLogin: enabled,
      path: process.execPath,
      args: app.isPackaged ? [] : [app.getAppPath()]
    })
  } else {
    app.setLoginItemSettings({ openAtLogin: enabled })
  }
  createTray() // 重建菜单同步勾选状态
}

function registerIpc() {
  ipcMain.handle('pet:get-quote', () => fetchQuote())

  ipcMain.handle('pet:get-state', () => ({ autostart, packaged: app.isPackaged }))

  ipcMain.handle('pet:toggle-autostart', () => {
    setAutostart(!autostart)
    return autostart
  })

  // 拖拽：渲染进程用 CSS 像素(与窗口坐标同单位)计算光标位移增量，主进程以
  // 拖拽起点为基准累加。避免直接读 screen.getCursorScreenPoint() 在高 DPI 下
  // 物理像素/DIP 单位不一致造成的窗口漂移。
  ipcMain.on('pet:drag-start', () => {
    dragWinStart = win.getPosition()
  })

  ipcMain.on('pet:drag-move', (_event, delta) => {
    if (!dragWinStart || !delta) return
    win.setPosition(
      Math.round(dragWinStart[0] + (delta.dx || 0)),
      Math.round(dragWinStart[1] + (delta.dy || 0))
    )
  })

  ipcMain.on('pet:drag-end', () => {
    dragWinStart = null
    saveWindowState()
  })

  ipcMain.on('pet:hide', () => win && win.hide())
  ipcMain.on('pet:quit', () => {
    quitting = true
    app.quit()
  })
}

// ---- 窗口位置持久化 ----
function loadWindowState() {
  try {
    if (existsSync(STATE_FILE)) {
      const state = JSON.parse(readFileSync(STATE_FILE, 'utf8'))
      const { x, y } = state
      if (isOnScreen(x, y)) return { x, y }
    }
  } catch {
    /* 忽略损坏的状态文件 */
  }
  // 默认放在主屏右下角
  const { workArea } = screen.getPrimaryDisplay()
  return {
    x: workArea.x + workArea.width - WIN_W - 24,
    y: workArea.y + workArea.height - WIN_H - 24
  }
}

function saveWindowState() {
  if (!win || win.isDestroyed()) return
  try {
    mkdirSync(dirname(STATE_FILE), { recursive: true })
    const [x, y] = win.getPosition()
    writeFileSync(STATE_FILE, JSON.stringify({ x, y }))
  } catch {
    /* 写入失败不影响运行 */
  }
}

function isOnScreen(x, y) {
  return screen.getAllDisplays().some(({ workArea }) =>
    x >= workArea.x - 20 &&
    y >= workArea.y - 20 &&
    x <= workArea.x + workArea.width - 20 &&
    y <= workArea.y + workArea.height - 20
  )
}
