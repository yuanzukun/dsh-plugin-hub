/**
 * 打包脚本：配置国内镜像后调用 electron-builder。
 * 用法：node scripts/build.mjs [electron-builder 参数，如 --dir]
 */
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

// 国内镜像(可用环境变量覆盖)
process.env.ELECTRON_MIRROR ??= 'https://npmmirror.com/mirrors/electron/'
process.env.ELECTRON_BUILDER_BINARIES_MIRROR ??= 'https://npmmirror.com/mirrors/electron-builder-binaries/'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const binName = process.platform === 'win32' ? 'electron-builder.cmd' : 'electron-builder'
const bin = join(root, 'node_modules', '.bin', binName)

// shell:true —— Windows 下 .cmd 需经 cmd.exe 执行，否则 spawnSync 报 EINVAL
const result = spawnSync(bin, process.argv.slice(2), {
  cwd: root,
  stdio: 'inherit',
  env: process.env,
  shell: true
})
if (result.error) {
  console.error(result.error.message)
  process.exit(1)
}
process.exit(result.status ?? 1)
