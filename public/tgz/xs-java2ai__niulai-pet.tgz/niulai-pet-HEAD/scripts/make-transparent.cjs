/**
 * Chroma-key the white background out of the pet sprites and re-encode them
 * as RGBA PNGs with a real alpha channel, so the Electron window can be
 * frameless + transparent (a proper desktop-pet cutout).
 *
 * Why flood fill (not a global "everything near white -> transparent"):
 * the character has its own light areas, and its silhouette touches the image
 * edges. A plain threshold would punch holes in the body. Flood filling from
 * the four borders only removes the *connected* background, so any white patch
 * enclosed by the body survives untouched.
 *
 * Usage:  node scripts/make-transparent.cjs
 * Deps:   sharp (resolved from the local project, or the DSH node_modules fallback)
 */
'use strict'

const fs = require('node:fs')
const path = require('node:path')

const ASSETS = path.join(__dirname, '..', 'assets')
const BACKUP = path.join(ASSETS, 'original')
const TARGETS = ['niu.png', 'niu_speek.png']

// --- sharp resolution: project first, DSH install as offline fallback ---
function loadSharp() {
  try {
    return require('sharp')
  } catch {
    const dshSharp = path.join(
      process.env.APPDATA || process.env.HOME || '',
      'nvm', 'v24.9.0', 'node_modules',
      '@deepseek-ai', 'dsh', 'node_modules', 'sharp'
    )
    return require(dshSharp)
  }
}

// A pixel counts as "background" when it is bright and low-saturation (white-ish).
const BG_MIN = 225 // all channels must be at least this bright

function isBackground(r, g, b) {
  return r >= BG_MIN && g >= BG_MIN && b >= BG_MIN
}

/**
 * Flood fill (BFS) over background pixels, seeded from every border pixel that
 * is already background. Returns a Uint8Array mask (1 = background).
 */
function computeBackgroundMask(rgb, width, height) {
  const total = width * height
  const bg = new Uint8Array(total)
  const queue = new Int32Array(total)
  let head = 0
  let tail = 0

  const push = (x, y) => {
    const i = y * width + x
    if (bg[i]) return
    const o = i * 3
    if (!isBackground(rgb[o], rgb[o + 1], rgb[o + 2])) return
    bg[i] = 1
    queue[tail++] = i
  }

  for (let x = 0; x < width; x++) {
    push(x, 0)
    push(x, height - 1)
  }
  for (let y = 0; y < height; y++) {
    push(0, y)
    push(width - 1, y)
  }

  while (head < tail) {
    const i = queue[head++]
    const x = i % width
    const y = (i - x) / width
    if (x > 0) push(x - 1, y)
    if (x < width - 1) push(x + 1, y)
    if (y > 0) push(x, y - 1)
    if (y < height - 1) push(x, y + 1)
  }

  return bg
}

/**
 * Build an RGBA buffer from RGB + background mask, feathering boundary pixels
 * so anti-aliased white edges don't leave a bright halo on dark desktops.
 */
function buildRgba(rgb, bg, width, height) {
  const total = width * height
  const rgba = Buffer.allocUnsafe(total * 4)

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = y * width + x
      const o = i * 3
      const d = i * 4
      const r = rgb[o]
      const g = rgb[o + 1]
      const b = rgb[o + 2]

      rgba[d] = r
      rgba[d + 1] = g
      rgba[d + 2] = b

      if (bg[i]) {
        rgba[d + 3] = 0
        continue
      }

      // Feather: a foreground pixel next to the background gets partial alpha
      // proportional to how bright it is, softening the silhouette edge.
      const nearBg =
        (x > 0 && bg[i - 1]) ||
        (x < width - 1 && bg[i + 1]) ||
        (y > 0 && bg[i - width]) ||
        (y < height - 1 && bg[i + width])
      if (nearBg) {
        const l = Math.min(r, g, b)
        if (l >= 190) {
          // 190 -> fully opaque, 225+ -> fully transparent, linear between
          rgba[d + 3] = Math.round(((225 - l) / 35) * 255)
          if (rgba[d + 3] < 0) rgba[d + 3] = 0
          if (rgba[d + 3] > 255) rgba[d + 3] = 255
        } else {
          rgba[d + 3] = 255
        }
      } else {
        rgba[d + 3] = 255
      }
    }
  }

  return rgba
}

async function convert(sharp, filename) {
  const src = path.join(ASSETS, filename)
  const meta = await sharp(src).metadata()
  const { width, height } = meta

  const { data: rgb, info } = await sharp(src)
    .removeAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true })
  if (info.channels !== 3) throw new Error(`unexpected channel count ${info.channels}`)

  const bg = computeBackgroundMask(rgb, width, height)
  const rgba = buildRgba(rgb, bg, width, height)

  const out = path.join(ASSETS, filename)
  await sharp(rgba, { raw: { width, height, channels: 4 } })
    .png({ compressionLevel: 9 })
    .toFile(out)

  // quick stats for the log
  const bgCount = bg.reduce((a, v) => a + v, 0)
  const pct = ((bgCount / (width * height)) * 100).toFixed(1)
  console.log(`${filename}: ${width}x${height}, removed ${bgCount} bg px (${pct}%) -> ${out}`)
}

async function main() {
  const sharp = loadSharp()
  if (!fs.existsSync(BACKUP)) fs.mkdirSync(BACKUP, { recursive: true })

  for (const f of TARGETS) {
    const src = path.join(ASSETS, f)
    const backup = path.join(BACKUP, f)
    if (!fs.existsSync(backup)) fs.copyFileSync(src, backup)
  }

  for (const f of TARGETS) {
    await convert(sharp, f)
  }
  console.log('done — originals backed up to assets/original/')
}

main().catch((err) => {
  console.error(err)
  process.exit(1)
})
