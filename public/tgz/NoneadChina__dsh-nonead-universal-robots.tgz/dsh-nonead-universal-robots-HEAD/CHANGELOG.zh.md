# 更新日志 / Changelog

本项目遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/) 与 [语义化版本](https://semver.org/lang/zh-CN/)。

## [0.8.2] - 2026-10-29

### 修复
- **桌面启动可能报 `web boot: 1 entry did not activate` / `dsh-nonead-universal-robots: loading`**：语言绑定直接读取 `ctx.locale`，而 cordis 上下文代理对未经 `inject` 声明的服务会在属性读取时抛错。现在改为经 `ctx.get('locale')` 获取并带回退，同时用 `try/catch` 包住绑定 —— 语言服务异常不再拖垮数字孪生 entry。
- **移除 `dsh.client.inject` 指向 `@deepseek-ai/dsh-client-locale` 的模块图边**：改为运行时发现 locale 服务，宿主即使没有对应的 client-module row，也不会让 entry 停在 `loading`。

### 变更
- 由 `src/client/**` 重建 `lib/client.js`（bundle 恢复可逐字节重建）。
- 新增 cordis 严格上下文回归测试（只允许 `ctx.get`，属性读取抛错）。

## [0.8.1] - 2026-10-29

### 文档 —— 按「已发布到 npm」的口径重写安装说明

- 两份 README（中/英）的安装章节新增 **「方式零 / Option 0：从 npm 安装」**
  （`dsh.cmd plugin add dsh-nonead-universal-robots`，或 `dependencies` 里写 `^0.8.0`），
  并删掉「尚未发布到 npm」那句已过时的说明。
- 手动 bundle 方式里，`dependencies` 的**首选**改为注册表版本范围 `^0.8.0`；`file:` 与 `github:`
  降级为离线/内网环境的退路。
- 新增 **「语言（界面文案）」** 章节：说明 0.8.0 起的 8 种语言、跟随 DSH 桌面程序语言
  （`locale.preference`）、免刷新切换，以及无宿主 locale 服务时的回退顺序。
- **仅文档变更**，`lib/`、`python/`、`src/` 未改动；`lib/client.js` 重新构建以保持与 `src/` 一致。

## [0.8.0] - 2026-10-29

### 新增 —— 客户端文案支持 8 种语言，并跟随桌面程序语言

- **语言**：简体中文、English、日本語、Español、Français、Deutsch、Русский、Português (Brasil)
  （`zh` / `en` / `ja` / `es` / `fr` / `de` / `ru` / `pt`，8 套词条**键集合完全对称**，含
  `safetyMode` / `robotMode` / `programState` 三张枚举表）。
- **与桌面程序语言一致**：接入宿主自带的 `@deepseek-ai/dsh-client-locale`
  （`package.json` 的 `dsh.client.inject` 已声明该包）：把 8 份字典通过
  `ctx.locale.register('ur-twin', …)` 注册给宿主，并读取宿主的 `locale.preference`
  —— 用户在 DSH 设置里换语言，面板与入口卡片**无需刷新页面**即生效。
  宿主不可用时按 `navigator.languages` → `navigator.language` → 中文 回退。
- **区域标签归一**：`pt-BR` / `pt-PT` → `pt`、`es-419` → `es`、`ja-JP` → `ja`、繁体
  `zh-TW` / `zh-Hant` → `zh`；**认不出的语言一律回退中文，绝不因为认不出就退回英文**。
- **修掉一个真缺陷**：面板原先在模块求值期就 `const S = activeStrings()`，语言被**冻结在加载
  那一刻**（宿主支持免刷新切换，界面却不跟着变）。现在改用 `liveStrings()` / `liveNested()`
  两个 Proxy：每次取文案都按当前语言解析，`SAFETY_TEXT` 这类模块级常量也随之"活"起来。
- **测试**：`test/strings.test.mjs` 扩到 12 项 —— 8 语言键/类型对称、枚举表非空、
  非中日文词条不得混入中文字符（抓漏翻）、宿主语言优先于浏览器、热切换、注册与退订、
  注册失败不抛。

## [0.7.6] - 2026-10-28

> **`npm publish` 在还没走到 npm 之前就报 `npm error code 9009`。** 这是 Windows 的"找不到命令"，
> 来源是 `python scripts/check-worker-ops.py` —— 发布门禁假定了 `PATH` 上有一个裸 `python`。本机
> `python` 是 Microsoft Store 的占位别名（根本执行不起来），`py` 又指向一个已被删除的
> `C:\Python314` —— 于是一个干净的仓库无法发布，而报错信息里连"是解释器的问题"都没有。

### 修复 —— 发布门禁不再依赖裸名 `python`

- **新增 `scripts/python-bin.mjs`**：按"**真的能启动**"解析解释器（`-c "import sys; print(sys.executable)"`），
  顺序为 `UR_PYTHON` → `PYTHON` → 项目 `.venv`/`venv` → `python3` → `python` → `py -3` →
  `py -0p` 列出的每个已注册安装（不存在的路径跳过）→ 常见安装目录。每个候选失败都单独报告，并把
  "**没能启动**"（`EPERM`、沙箱拒建管道）与"启动了但退出码非 0"（`9009`、`101`）分开，而不是
  笼统地报 `exit null`。
- **新增 `scripts/run-py.mjs`**：用解析出的解释器执行 Python 脚本（`node scripts/run-py.mjs
  scripts/check-ops.py`）；`node scripts/run-py.mjs --which`（亦即 `npm run python:where`）打印选中的是谁。
  它给子进程钉住 `PYTHONUTF8` / `PYTHONIOENCODING`，门禁里的中文输出不再是乱码。
- **`check:ops`、`test:python`、`verify:models`** 全部改走 `run-py`；`scripts/run-tests.mjs` 与
  `scripts/check-host-compat.mjs` 使用同一个解析器，且 `run-tests` 把解析到的 `sys.executable` 写进
  `PYTHON` / `UR_PYTHON` 再跑子测试 —— 11 个需要 Python 的测试文件不再各自猜名字。
- **`scripts/check-package-metadata.mjs`** 原来不跳过本地构建目录：被 gitignore 的 `.venv` 里
  `numpy/__config__.py` 记录了绝对路径，于是"硬编码作者路径"门禁在一个干净仓库上失败。现在跳过
  `.venv`、`venv`、`.pytest_cache`、`Release`、`dist`、`build`，并加了一条自检：必需条目少一个就失败。

### 修复 —— 发布时可用环境变量指定宿主

- **`DSH_HOST_ASAR`** 现在与既有的 `--host-asar` 参数等效。`prepublishOnly` 传不了命令行参数，而宿主
  装在 `Program Files` 之外时（本机是 `D:\Software\Nonead DSH Desktop`，asar 形态，磁盘上没有
  `resources\app\node_modules`）`check:host:strict` 必然失败。自动发现同时补上了 `%LOCALAPPDATA%\Programs`。
- **peer 范围**补上当前实际安装的宿主版本族：`^0.2.2-alpha.2`（`@deepseek-ai/dsh`、
  `@deepseek-ai/dsh-tools`）、`^4.0.6-alpha.1`（`@deepseek-ai/cordis`）、`^3.18.6-alpha.1`
  （`@deepseek-ai/schemastery`）—— 预发布范围只匹配自身版本三元组，宿主升级后必须显式补一条。

### 验证

- `npm run check` → 全部通过；`npm run check:host:strict`（带 `DSH_HOST_ASAR`）→ 全部通过，
  peer 4/4、104/104 个工具 schema 用宿主真实 DSL 注册成功。
- `npm test` → **56/56 通过、0 失败、0 跳过**（11 个需要 Python 的用例全部真的执行了）。

## [0.7.5] - 2026-10

### 修复
- **`ur_run_program` 可能执行与审批不符的程序**：`play` 前必须确认加载成功（load 已发送、已加载程序非空、basename 与目标一致、应答不是失败文案）。`ur_load_program` 只有拿到正向证据才报 `confirmed: true`。
- **运动类调用超时不再杀 worker**：`MOTION_OPS` 与 `APPROVAL_OPS` 解耦；`ur_wait_steady` 按 `timeout_s` 计预算并带 `killOnTimeout: false`；运动在飞（或状态未知）时，任何超时/取消都不再杀 Python 子进程 —— RTDE/Dashboard 会话、数字孪生与停止机械臂的能力得以保留。
- **预飞安全闸补齐**：`draw_*` 的半径/边长/圆心/原点、加速度（`safetyMaxAccel`）、力控 `limits` / `task_frame` / `wrench` / `selection_vector`、`speedj`/`speedl` 形状全部校验；参数"出现但不合格"一律拒绝，不再当作未提供跳过。
- **审批覆盖**：`set_tcp`、数字/模拟输出、工具电压/输出模式/通信、传送带 tick 纳入门禁（共 53 个）；`stopj` / `stopl` / `end_force_mode` 移出门禁 —— 停止动作不应反过来要人工批准。
- **`ur_delete_program`** 在宿主与 worker 两侧都校验远端路径；**`programDir`** 改为注入 realpath 后的绝对路径，不再让 Python 按自身 cwd 解析；下载增加大小上限。
- **审批 / 审计**：`ur_send_script` 展示完整脚本、sha256 与字节数（上限 64 KiB）；SSH 口令在审批正文与审计账本中脱敏；关闭审批时受门禁 op 仍记审计。
- **数值加固**：轴位移 `distance` 拒绝 NaN/Infinity；`set_tcp` 增加幅值上限。
- **数字孪生**：按机器人共享帧泵（不再 N 倍放大 worker 调用）、最多 4 条并发流（超出返回 429）、写入背压、空闲超时、待审批预览按机器人隔离。
- **工程面**：新增 CI；宿主兼容门禁支持 `--host-asar` / `--strict`；peer 范围接受当前宿主；`THIRD_PARTY_NOTICES.md` 进入 npm 包；README 计数更正。

### 变更
- 审批门禁：49 → 53 个；README 表格与 `check-approval-gate.py` 同步。
- 取消/超时现在会明确提示"机器人可能仍在运动，请用 `ur_stopj` / `ur_stopl` 收尾"，插件不再为此拆除 worker 会话。

## [0.7.4] - 2026-10

### 变更
- **版本统一为 0.7.4**：仓库的 `package.json` 与两份更新日志现在报告同一个版本。本版本不包含功能变更，仅把仓库版本与已发布的 0.7.x 插件线对齐。

## [0.7.3] - 2026-10-15

> **本地程序文件的牢笼在 Windows 上能被走出去，而本该拦住它的那道判据，恰好是唯一看不见这次
> 逃逸的东西。** 一个不解 junction 的 `realpath` 会把 junction 路径原样报回来，于是"父目录
> `realpath` 之后仍要在 `programDir` 内"这条要求**天然成立**。

### 修复 — 牢笼漏掉了 Windows 的 junction，而且三条路径里有两条根本没解

`programDir` 是拦住 `ur_upload_program` 读任意本地文件、`ur_download_program` 写任意本地文件的
那层，所以每一种逃逸都必须被拒。Windows 实测：`programDir` 里的一条 junction（**免特权可建**，
文件级软链则需特权）**不被 `lstat` 报成符号链接**（`isSymbolicLink()` 为 `false`），`readlink`
直接答 `EINVAL`。JS 版 `fs.realpathSync` 是在用户态自己逐级解链接的，于是它把 junction 路径
**原样返回** —— 判据根本看不到逃逸；最小复现确认，经这条 junction 写入的文件确实落在了
`programDir` 之外。

三处缺口，全部补上：

- **根判据**改用 `realpathSync.native`（走 OS 的 `GetFinalPathNameByHandle`），它连同 junction
  在内的所有重解析点一起解开。`rootReal` 与 write 模式的 `parentReal` 共用同一个变量，所以这一
  处同时把两条判定重新武装起来。
- **read 模式**原先对 candidate 只做 `stat`、从不解链接，而 `stat` 会跟着链接走。现在对 candidate
  自身也解一次，并要求结果落在 `rootReal` 内。没有这一步，上传能顺着同一条 junction 读到
  `programDir` 之外的 `.urp`。
- **write 模式**原先只判父目录，于是**已经存在**的目标文件若是一条指向外面的软链，写入仍会跟着
  它走；而一条**悬空**软链会让目标文件在目录外被创建。现在已存在的目标文件也要解一次，解不出
  真实路径的链接一律拒绝，而不是被当成"文件不存在"放行。

`checkProgramTransfer` 仍然只回答放行/拒绝，并把调用方给的 `local_path` 原样交下去，因此下游
行为没有任何变化。

### 测试 — 三个逃逸用例，都真跑

`test/program-files.test.mjs` 新增了 read 模式的 junction 用例与"已存在目标是指向外面的链接"用例；
write 模式的 junction 用例正是当初揪出这个缺陷的那条（它是整个套件里唯一的失败项）。
`node --test test/program-files.test.mjs` → 11/11，无一跳过。

## [0.7.2] - 2026-10-15

> **机器人在动、数字孪生却一直说"数据已停止更新"；运动前的位姿预检，把机械臂"此刻正站着"的位姿报成
> 不可达；而一次传送带 tick 写入，说不清自己到底生效没有。** 三处是同一个毛病：一个辅助函数给出了它
> **其实从未拿到过**的确定答案。

### 修复 — `ur_set_conveyor_tick` 说不清自己生效没有

它下发 `set_conveyor_tick_count()` 之后就 `ok_unverified`，而同族的读取器 `ur_get_conveyor` 早就有完整的
三哨兵回读（probe → start → 载荷 → finish）。真机实测：写入 `tick_count=1234` 后回读仍是 **0**，而调用方
只得到一句"已设置（未校验）"—— 分不清"控制器没配传送带"还是"其实成功了"。

现在复用同一个读取器，并把三种结局如实分开：回读一致 ⇒ `verified: true`；回读不一致 ⇒ **明说没有生效**，
并指向最常见原因（PolyScope 里没配编码器/传送带，URSim 默认如此）；回读本身失败 ⇒ 把 `error`/`code` 交给
调用方。有了回读通道，它也就从"只能声称已下发"的清单里**毕业**（那条契约要求清单内的 op 不得出现
`return ok({...})`）——`UNVERIFIED_OPS` 由 12 项减为 11 项。

### 修复 — 用 `.get("ok")` 检查别的 handler 的结果，恒为假

`python/ur_worker.py` 里的 `ok(data)` 是**恒等函数**（`return data`），`ok: true` 是 `main()` 序列化响应时
才加上去的。所以 handler 之间传阅的字典里**根本没有 `"ok"` 键** —— 任何用 `.get("ok")` 判断"我的回读成功
了吗"的代码都会读到 `None`，于是**每次都走失败分支**。上面那个传送带修复的第一版正是这样写的（会把一个
能自证的写入变成永远"未校验"）；这个错误只是因为"复用了另一个 handler 的返回值"才暴露出来。判据现已改为
`result.get("error") is not None`，两条性质都由探针断言钉住（`discriminates_by_error_key`、
`does_not_inspect_ok_key`），陷阱不会复发。全仓扫描另有一处 `.get("ok")`（`op_pose_list`），读的是它自己
构造的键，因此是正确的。

### 修复 — `ur_check_pose` 报假阴性

这个工具向控制器问两个只读问题（`is_within_safety_limits`、`get_inverse_kin`），并把答案写在首尾哨兵
之间的输出寄存器里。它把**布尔**的安全答案**直接写进了整数寄存器** —— URScript 是强类型的，控制器
**就在那一行抛错中止**：什么都没写下去、`get_inverse_kin` 从未被调用、整数寄存器回读是 `0`，于是工具
对"机械臂此刻正站着的位姿"报出"不在安全限值内 + IK 解不出"，而模型会因此**拒绝完全可达的位姿**。

这是**真机实测**查出来的，不是读代码看出来的：把工具那条原句单独复刻成一段脚本，它的"走到哪一步"标记
停在起始值；而同一个脚本把布尔先赋给 `local`、再用 `if/else` 写下去，就一路跑完。

- 布尔值现在先落 `local`，再由 `if/else` 归一成 `1`/`0`；
- 新增**阶段标记寄存器**记录脚本走到了哪一步，"死在限值那步"与"死在 `get_inverse_kin`"不再被报成同一件事；
- **只有**阶段标记证明限值那步确实跑完，才相信限值寄存器的值；否则报 `NOT_EXECUTED`，**不给**可达性结论。
  原来的守卫（`limits_raw is not None`）恒为真 —— 整数寄存器没被写过时读到的是 `0` 而**不是** `None`，
  这正是"脚本中止"被翻译成一句斩钉截铁的"不可达"的路径；
- 守护：`check_pose_script_types` 对**生成的 URScript 做类型检查**（每个
  `write_output_integer_register` 的第 2 个实参必须是整数字面量），外加 11 项断言。

### 新增 — 预飞安全闸（`lib/safety-gate.js`）

与审批门禁**独立**的第二层：限制"**单条指令最多能要求多少**"，让"人点了头"永远不等于"什么都可以"。上限项：`safetyMaxStepM`（0.5 m）、`safetyMaxLinearSpeed`（0.5 m/s）、`safetyMaxJointSpeed`（1.05 rad/s）、`safetyMaxDurationS`（60 s）、力控的 `safetyMaxForceN` / `safetyMaxTorqueNm`（40 N / 10 N·m），以及针对显式笛卡尔目标的可选包围盒 `safetyWorkspace`。它在**审批之前**判定，与 `requireApprovalForMotion` **解耦**（关掉人工确认不该顺手把物理上限一起关掉），并在 `safetyWorkspace` 写错时 **fail closed** 而不是静默不检查。刻意不覆盖 `ur_send_script`（任意 URScript，不解析）。

### 新增 — 动作审计账本（`lib/audit-log.js`）

每条受门禁的指令追加一行 NDJSON（默认 `<DSH_HOME>/nonead-ur/audit.ndjson`），字段 `{ts, ip, op, tool_name, args, decision, reason}`，`decision ∈ {approved, denied, blocked, unchecked}`。在此之前，审批的唯一痕迹只活在内存里 —— "模型到底对机器人做了什么"事后无从回答。写入失败只回报不抛错：审计绝不能把下发路径弄挂。

### 新增 — `ur_check_pose` 与 `ur_set_speed_scaling`（工具 83 → 85，受门禁 op 40 → 41）

`ur_check_pose` 回答的是**动之前**值得先问的问题：*这个 TCP 位姿在控制器的安全限值内吗？逆运动学解得出吗（可达吗）？* 由控制器执行 `is_within_safety_limits` + `get_inverse_kin`，结果经输出寄存器在首尾哨兵之间回读，因此三种结局分得开 —— 跑完（两个答案都有）、只跑到一半（限值已写、控制器在 IK 那一句中止 ⇒ `reachable: false`，且把这条推论的依据写进返回值）、控制器没执行（未处于远程控制模式 / 固件没有这些函数 ⇒ 报 `NOT_EXECUTED`，不给编造的答案）。它**不能**用 `urScript.py` 的 `get_*` 访问器：那些依赖 RTDE **输入**字段，而本插件刻意没有 send 配方。

`ur_set_speed_scaling` 设置速度滑块（`set_speed_slider`，0 = 停住 / 1 = 满速）—— 交出精细动作前把整体速度压下来，最直接可靠。与其它设置类 op 不同，它**有**回读通道（`target_speed_fraction`）：只有回读一致才报 `verified: true`；又因为 "`set_speed_slider` ⇒ `target_speed_fraction`" 这条映射从未在真机上确认过，会同时回报 `hardware_verified: false`。它已加入审批门禁（它改变的是**此后所有**运动的速度）。

### 新增 — 程序文件 SFTP 传输（工具 85 → 88，受门禁 op 41 → 43）

部署程序不再需要走到示教器：`ur_upload_program`、`ur_download_program`、`ur_delete_program` 在 `programDir` 与机器人之间搬 `.urp`，而且每个都**核对"到底做成了没有"**，而不是"请求已发出" —— 上传回读远端大小、下载回读本地大小、删除在 `remove` 之后重新 `stat`（不一致报 `VERIFY_FAILED`，绝不报成功，因为调用方的下一步通常就是运行这个程序）。下载**绝不静默覆盖**：目标已存在时先改名成 `<path>.bak`，备份失败就拒绝下载。

本地这一半必须设围栏（`lib/program-files.js`）：上传会**读**本地文件、下载会**写**本地文件，没有围栏时模型就能把本机任意文件（私钥、凭据）送到机器人上，或把机器人文件写到本机任意路径 —— 而 `sanitizeArgs` 只挡参数**键**、不挡**取值**。本地路径必须 `realpath` 之后落在 `programDir` 内，因此 `..` 与指向目录外的软链都被拒绝；只处理 `.urp`；`maxProgramBytes` 限大小；`programDir` 缺失则 fail closed。`upload_program` 与 `delete_program` 加入审批门禁（覆盖或删除已存程序的后果不比一次运动轻，且兄弟 op `load_program` 早已受门禁）；`download_program` 不入，因为它只读机器人，写入侧由牢笼管。

### 新增 — 现场消息（工具 88 → 91）

`ur_popup`、`ur_close_popup`、`ur_add_log` 让模型能跟站在机器人旁边的人说话：示教器上的模态提示，以及写进**控制器自己的日志历史**的一行（这正是日后在车间里能回答"当时是谁让它做了什么"的原因）。三者都不会让机械臂运动，因此都不入审批门禁。

文本经过**注入校验**：dashboard 按行解析命令（`dashboard.py` 拼的是 `'popup ' + text + '\n'`），所以文本里的换行会被当成**另一条 dashboard 命令**执行 —— `"x\nshutdown"` 就是一次关机。因此换行（与回车）一律**拒绝**并给出明确错误，而不是悄悄替换；文本长度上限 300 字符。

### 新增 — Modbus / 现场总线 I/O（工具 91 → 99，受门禁 op 43 → 48）

八个面向现场总线的工具：`ur_modbus_add_signal`、`ur_modbus_delete_signal`、`ur_modbus_get_signal_status`、`ur_modbus_send_custom_command`、`ur_modbus_set_output_register`、`ur_modbus_set_output_signal`、`ur_modbus_set_runstate_dependent_choice`、`ur_modbus_set_signal_update_frequency`。

**vendored 的方法无法复用**：`urScript.py` 里那八个 `modbus_*` **全是桩**（`raise NotImplementedError('Function Not yet implemented')`），所以这里的 URScript 是自己拼的，走的是 `ur_check_pose` 那套首尾哨兵运行器。该运行器把"跑完 / 开始但没跑完 / 控制器根本没执行"三者分开 —— 后两种都报失败，但用词不同，因为它们含义不同。

这里的诚实边界比此前任何一处都重要：**Modbus 写类没有应答**（手册原话：`send custom command` "cannot be used to request data, since the response will not be received"）。这些工具能证明的只有"这段 URScript 在控制器上跑过" —— 永远不能证明 PLC 收到，更不能证明设备动了。因此每条回执都带 `fieldbus_confirmed: false`；只有 `ur_modbus_get_signal_status` 会返回真实数值（经输出寄存器在哨兵之间回读；寄存器读不到就报错，不拿 0 冒充）。

接口形状逼出来的两条防线：
- **信号名走白名单**：它会被拼进 URScript 字符串字面量，`a", 0)` 加一个换行就能把任意脚本注入控制器。用白名单（`[A-Za-z0-9_.- ]`，≤64），不做转义。
- **读的时候必须声明 `kind`**：URScript 是强类型的 —— 数字信号返回布尔、寄存器信号返回无符号整数，一段脚本没法安全地把两者都写进浮点寄存器（把 bool 写进浮点寄存器会让程序中止）。工具不猜；`kind` 写错会以 `NOT_EXECUTED` 暴露，并同时说明两种可能。

`ur_modbus_add_signal`、`ur_modbus_delete_signal`、`ur_modbus_send_custom_command`、`ur_modbus_set_output_register`、`ur_modbus_set_output_signal` 加入审批门禁 —— 它们会驱动 PLC，或改变控制器监管哪些现场总线点位；只读那一个与两个信号配置项不入。

### 新增 — 命名位姿表（工具 100 → 104）

`ur_save_pose` / `ur_get_pose` / `ur_list_poses` / `ur_delete_pose`：本机的命名位姿表，一位姿一文件（`<poseDir>/<名字>.json`，默认 `<DSH_HOME>/nonead-ur/poses`）。除"让 `ur_save_pose` 捕获当前姿态"外，它们不碰控制器。

分工与程序文件一致，理由也一样：`lib/pose-store.js` 负责**名字牢笼、配额与向量形状**（纯逻辑、可注入 IO、有单测），worker 只写它拿到手的那份文件。名字会变成文件名 —— 这正是白名单要紧的原因，也是初版写错的地方：它只收 ASCII，于是 `工位 1` 被拒。单测抓到了这一点；现在的规则是"Unicode 字母/数字、必须以其中之一开头、不含路径分隔符与 Windows 非法字符、不是保留设备名、无首尾空白"。

写测试过程中定下来的几处诚实细节：
- **`NOT_FOUND` 与 `CORRUPT` 是两个不同的回答**。混成一句"读不到"，会让调用方去重新保存一个其实已经存在、只是损坏了的位姿。
- 写盘是原子的（`tmp` + `os.replace`），写完**回读比对**；不一致报 `VERIFY_FAILED`，绝不报成功。
- 单个条目损坏**不会**让整张表失败：按条目回报，名字列在 `broken` 里。
- 配额拒绝**新增**，但**更新**一条已存在的位姿仍然放行 —— 否则"改一下再存"都做不了。
- 目录读不了**不会**退化成"0 条"（那会让配额静默失效），而是拒绝写入。

`scripts/check-tool-params.py` 也改了：它的 docstring 一直写着"`_` 开头的键是协议内部字段"，而实现只排除了字面的 `{ip, _timeout_ms}`。现在实现与文档一致（宿主注入的 `_path` / `_dir` / `_pose_count` / `_max_poses` / `_capture` 被排除，且 `sanitizeArgs` 会把模型塞的同名字段丢掉），并**新增**一条规则：禁止把 `_` 开头的名字**声明**成参数 —— 否则模型就能设置一个宿主打算注入的字段。

### 修复 — 长时间运动会让数字孪生冻结（`lib/motion-budget.js`）

真机反馈：让机器人跑 60 秒，3D 孪生就不跟着动了。孪生唯一**不受** worker 单线程 stdin 队列影响的
数据源，是 Python 侧那个遥测推送线程（`_twin_push_loop`）—— 而它与 RTDE、Dashboard 装在**同一个子进程**里。

罪魁是调用预算：每次工具调用都用 `commandTimeoutMs`（默认 **60000 ms**），而 `UrWorker.call()`
**超时即 kill 掉 Python 子进程**（作为通用策略这是对的：单线程 worker 卡死会让之后每个请求都排队）。
于是"合法地跑过 60 秒"的运动把子进程**杀在运动中途**：机器人还在动，推送线程随子进程消失，孪生永久
冻结（机器人连接也一并丢失）。

两处改动，都在 `lib/motion-budget.js`：
- 预算改为**按调用自身的参数推算** —— `t=`（秒）与 `ur_wait_steady` 的 `timeout_s` 各加一份余量，
  `move_force` 因为时长取决于"走多远、被什么挡住"而给宽兜底；配置里的 `commandTimeoutMs` 仍是下限；
  1 小时封顶，避免"很长"变成"永不超时"；
- 运动指令一律以 **`killOnTimeout: false`** 调用：超出预算就**如实报超时**，而不是毁掉会话。这与本插件
  一贯的诚实性纪律一致 ——「我没在预算内拿到确认」不是拆掉连接的许可。

### 修复 — 遥测不再与响应共用通道（`lib/push-channel.js`）

孪生的推送帧原先走 **stdout，并与响应共用同一把 `_PROTOCOL_LOCK`**。那把锁在整条响应写期间都被占着，
所以一条大响应（或宿主一时没抽干导致的 stdout 背压）足以让推送停超过宿主的 `TWIN_PUSH_FRESH_MS`
（300 ms）—— 一过这个窗口，`lib/twin-routes.js` 就**回退**去发一次**显式读**，而那次读正好排在 worker
的 stdin 队列里、堵在运行中的运动指令后面。于是孪生在这次运动的剩余时间里只剩"数据已停止更新"。

现在遥测有独立通道：**stderr + `@@DSH-UR-PUSH@@ ` 前缀，并用自己的锁**（Python 侧 `_write_push_line` /
`_PUSH_LOCK`，宿主侧 `lib/push-channel.js`）。它既不被响应串行化，也不受 stdout 背压影响；普通 stderr
（traceback、URBasic 的 print）仍原样进 `stderrTail`。宿主**两路都收**，所以旧版 Python 侧也能工作。

切分函数是带独立单测的纯函数，因为它的失败模式恰好都是最难看的那些：一行被切成两段、
切点落在**魔数前缀内部**、以及一个最后一行没有换行的 traceback（那条必须立刻交给诊断，否则永久丢失）。

### 修复 — 文档

两份 README 都写「RTDE 配方未暴露单关节电流，故未提供 `ur_get_joint_current`」。实际配方里一直有 `actual_current`，`ur_get_runtime_telemetry` 会以 `joint_currents` 返回它；缺的只是一个**单独的**工具。

## [0.7.0] - 2026-10-14

> **在一台机器上"失败 0"，而那 46 项里有 16 项从来没跑过。** 同一天还发现 `movej`/`movel` 接受
> `t=` 时长、把它写进回执，却从未下发给控制器。两件事是同一个毛病：一盏背后没有东西的绿灯。

### 修复 — movej/movel 的 `t=` 从未下发给控制器

- **根因**（`python/URBasic/urScript.py`）：时长被读进了 `t_val`，而脚本模板里插的是 `tval`。
  结果是一个被**静默丢弃**的参数：`ur_movej`/`ur_movel` 收下 `t`、在回执里带上它，实际执行的却是
  按速度规划的移动。
- **修复**：改一个标识符。`t > 0` 现在真的优先于 `a`/`v`（手册的规定），返回的脚本里也真的包含
  你要的 `t=`。
- **守护**：Python 探针 `motion_t_param` 断言下发的脚本含有请求的时长，且 `t` 确实压过 `a`/`v`。

### 修复 — worker 活得比宿主久，孤儿进程占着 RTDE 会话

- **根因**（`lib/index.js`）：`ctx.effect` 的 disposer 返回 `undefined`。Cordis 只在返回值是 thenable
  时才 await 它（`if (isObject(result) && "then" in result)`），于是优雅的 `worker.shutdown()` 从未被
  等待，`lib/worker.js` 也从未真正 dispose 子进程。UR 控制器上的 RTDE 是**独占**会话：残留的
  Python 进程继续占着它，下一次启动宿主会连不上，直到孤儿进程自己死掉。
- **修复**：disposer 返回清理 promise；退避重连定时器可取消并在 `dispose()` 时拒绝；`_spawnOnce()`
  在 await 之后重查 `_disposed`（teardown 后不得凭空 spawn）；子进程 `stdin` 只挂一个 `error` 监听器。
- **另外**：spawn 时注入 `PYTHONUTF8=1` / `PYTHONIOENCODING=utf-8`，worker 也强制自己的 stdio 为
  UTF-8 —— 非 UTF-8 的控制台区域设置以前会把一个中文字节变成 `UnicodeDecodeError`，直接打死循环。

### 修复 — Dashboard 的应答会落到下一条命令上

- **根因**（`python/URBasic/dashboard.py`）：`run()` 在 `__receive()` 返回 `None`（什么都没读到）时
  也通知条件变量，而 `sendCommand()` 直接把 `self.__last_respond` 交出去。于是第 *N* 条命令的应答
  可能被当成第 *N+1* 条的结果 —— 一台**没有**处于远程控制模式的机器人被报成 `remote_control: true`，
  模型据此下发 URScript，被控制器静默丢弃。
- **修复**：通知只在 `if msg is not None:` 内触发；单调递增的 `respond_seq` 配 `__await_respond(since_seq,
  timeout)`，把"等**这一条**的应答"写明确；`sendCommand()` 核对序号确实前进，否则返回 `(False, '')`
  而不是一个陈旧的答案。
- **另外**：收包从 `recv(1024)` 且完全不累积，改为 `RECV_CHUNK = 4096` + 按换行累积的实例缓冲，
  分片应答不再串进下一条命令。

### 修复 — 无法证实的命令不再声称成功

- **根因**：对一类状态设置型 op，唯一能证明的事实是"字节写进了 socket"，回执却说"已设置/已生效"。
  UR 只在**远程控制模式**下接受 URScript；本地/示教器模式下控制器**静默丢弃**且什么都不报。
- **修复**：统一的 `ok_unverified(result)` 包装把这类回执降级并在 `data` 里带 `verified: false`，
  覆盖 **12** 个 op（`set_tcp`、`set_payload`、`set_payload_inertia`、`set_gravity`、`set_tool_voltage`、
  `tool_communication`、`set_tool_output_mode`、`motion_version`、`force_mode_settings`、`zero_ftsensor`、
  `set_conveyor_tick`、`conveyor_tracking`）。
- **工具数字 I/O** 是同一形状但后果更糟：`set_tool_digital_out()` 完全忽略 `Send()` 的结果，写失败
  也报成功。现在它返回发送结果，worker 把失败转成 `SEND_FAILED`；读工具数字输入改为**哨兵校验**
  （通道探测 + 首尾哨兵），回读不到结束哨兵时拒绝给值，而不是报一个没人能担保的数字。

### 修复 — RTDE 会话被拒绝时 `isRunning()` 仍然为 true

- **根因**（`python/URBasic/rtde.py`）：`RTDE_CONTROL_PACKAGE_START` 分支调了 `__decodePayload()`，
  却**无视**解出的 `accepted` 布尔，无条件置 `STARTED`。控制器拒绝时（最常见的原因是上一次会话还没
  释放）`isRunning()` 说谎、`ensure_connected()` 的 `if not RTDE.isRunning()` 守卫失效，之后每一次
  读姿态都要耗尽 5 s 的 `sync()` 超时，最后报出误导性的"等待新的 RTDE 数据超时"。
- **修复**：只有 `accepted is True` 才置 `STARTED`，否则置 `ERROR` 并记下 `__start_refused` 与一行原因。
  `__sendStart()` 改为自己泵一次 `__receive()` 并按结果状态回答 —— 这样 `run()` 里"重连后重新 setup"
  的分支终于能看到拒绝（旧实现一写出字节就返回 `True`，那个分支永远进不去）。
- **另外**：跨 `recv()` 边界的 RTDE 包以前会被**整帧丢弃**（`byte_buffer` 是局部变量，残缺的尾巴
  连同一句误导性的 "unexpected packet_size" 一起丢掉）。丢掉的是刷新看门狗的 `timestamp` 包时，
  `run()` 会去重建一条本来健康的会话。现在缓冲是实例字段、跨调用累积，半个包留到下一次读，
  畸形长度只丢**一个**字节重新对齐（并计数，通过 `ur_get_status` 的 `rtde_resync_bytes` 暴露），
  而不是把后面整条流扔掉。

### 修复 — 客户端两个永远不会触发的功能

- **关节超限告警**（`src/client/twin-panel.js`）：限位取自 `fkResult?.jointLimits` —— 运动学对象上
  从来没有这个字段，于是超限高亮是死代码。来源改为 `kin.jointLimits`。
- **多机器人选择器**：`updateRobotChoices()` 在 `if (!connected) return` 之后才运行，于是列表只能在
  "已经连上"之后才被填充 —— 而它存在的意义恰恰是"连之前先选机器人"，等于永远用不上。现在它在
  该守卫之前无条件运行；`syncHudVisibility()` 也改用 `children.length`（原先的 `childElementCount`
  在面板运行的最小 DOM 上并不存在）。

### 修复 — 其余几处诚实性缺口

- **孪生陈旧帧**（`lib/twin-routes.js`）：回放会把整块缓存原样交出去，其中包括最多 30 s 前的
  `pending_motion` 预览 —— 审批早已结束，面板却继续把它画出来。该字段属于宿主侧状态，现在**现场
  重读**（没有就不带这个字段）。
- **日志大小上限**（`python/ur_worker.py`）：`_CappedLog` 按**字符**计数，而文件以 UTF-8 打开，中文
  日志能写到声明上限的约 3 倍（8 MB → 约 24 MB）。改为按字节计账；`write()` 的返回值仍是字符数
  （保持 file-like 语义）。
- **`ur_list_programs`**：内置默认口令（`easybot`）与 `AutoAddPolicy()` 的主机密钥立场不再沉默，
  以 `used_default_password` / `host_key_policy` 如实回报；新增可选 `known_hosts` 参数会切到
  `RejectPolicy` 做**真正的**校验。文件不存在直接报错 —— 绝不静默退回 auto-add。
- **`realTimeClient.Send()`** 从不等待上一段程序的看门狗线程，于是一次状态写入可能与那个线程在同一个
  30003 socket 上并发（还会输给它收尾时发的 `prgRest`），而它只回报"已发送"。现在与
  `SendProgram()` 共用 `__quiesce()`。

### 变更 — 门禁不能再靠"跳过"通过

- `scripts/run-tests.mjs` 在全部项目被跳过时也 exit 0。在一台没有 Python 依赖的机器上，它会打印
  "失败 0"，而 11 个测试文件与 5 条门禁从未运行。现在**有跳过即失败**，除非你显式要求
  （`--allow-skip` / `--skip-python`）；全部被跳过则**总是**失败。
- Python 探测改为两级（`interpreter` / `deps`），并把"声明了却从没被读过"的 `needsDeps` 真正用起来
  —— 4 条只做 AST/正则的 Python 门禁不再因为缺 `numpy` 被连带跳过。所有 `spawnSync` 补上 `cwd: root`。
- `scripts/check-host-compat.mjs` 写死了 `C:\Program Files\DSH Desktop\...`，于是在任何别的安装名
  （例如本机的 `Nonead DSH Desktop`）下都找不到宿主，**从未真正执行过**。现在它枚举
  `Program Files\*\resources\app\node_modules`，并可用 `--allow-missing-host` 接入 `npm run check`
  （默认仍然响亮地失败）。首次真跑结果：peer 全部满足、**83/83 工具经宿主的真实 DSL 注册成功**、
  4 条孪生路由齐全。
- `package.json`：`prepublishOnly` 改为跑完整的 `check`；`check` 纳入新的 `check:host`；`devEngines`
  记录真实的 Node 下限（≥22.15 —— 两个测试文件用了 `module.registerHooks`，所以给测试套件声明的
  `engines: >=20` 从来就不是事实）。
- **工具计数只有一个来源**（`scripts/tool-registry.mjs`）。此前一处动态计算、另两处硬编码 `83`：
  加一个工具而漏改其中一处，门禁之间就会自相矛盾。
- **5 个离线探针纳入测试套件**：`scripts/probe-*.mjs` 原先**不接入任何门禁** —— 而"脚本放在那里
  没人跑"恰恰是这一版要治的毛病。它们不需要真机也不需要宿主；其中两条要 `EventSource`，用
  `--experimental-eventsource` 跑（Node ≥22.3，与 `devEngines` 声明的下限一致）。

### 变更 — 发布包

- `lib/client.js.map`（3.5 MB，比 bundle 本身还大）不再随包发布：`files: ["lib"]` 是白名单、优先于
  `.npmignore`，所以排除必须写成取反项 `"!lib/client.js.map"`。

### 新增 — 回归测试（19 条）

上述每一项修复都有会在旧代码上失败的用例守着，包括：用**真 TCP socket 对**驱动 `__receive()`
（START 被拒绝、以及一帧被拆成两次 `recv()`）、用假等待线程证明 `Send()` 会静默、用中文写入证明
日志上限按字节算、用真实的 `pendingMotion` 存储证明陈旧帧会丢掉已结束的审批，以及一个**永不回答的
真 TCP 假 Dashboard**（证明 `sendCommand()` 会如实报失败而不是交出陈旧的 `true`）。

## [0.6.9] - 2026-10-12

> **每个型号画出来的可达范围都一样大，因为那个范围从来没被真正算出来。** 读连杆长度的函数只认
> `links` 的**旧形状**，而真实数据是 6 个 `{x,y,z,roll,pitch,yaw}` 位移 —— 于是 14 个内置型号
> 一律返回 `null`。

### 修复 — 可达范围包络与回退臂重新跟着型号走

- **根因**（`src/client/robot/loader.js`）：`linkLengthsFromKinematics()` 只接受
  `[7 × 4×4 行主序 number[16]]` 且要求 `links.length >= 7`，而 `assets/kinematics.json`（`fk.js`
  文件头明确记载并消费的形状）里是 **6 个 `{x,y,z,roll,pitch,yaw}` 固定位移**。于是每个真实型号
  都拿到 `null`，而这一个 `null` 同时造成了两个症状：
  - `reachRadiusFromKinematics()` 也是 `null` ⇒ `twin-panel` **从不**更新 `reachSphere.scale`：
    包络球永远停在单位半径（1 m），换哪台机器人都一样大；
  - `loadRobotModel()` 的 `armLinks` 永远是 `undefined` ⇒ 未知型号的回退臂永远塌回 UR3 量级。
- **修法**：函数现在认识两种形状。位移形状下每段的长度就是该段位移的模长 `hypot(x,y,z)` —— 与
  `fk.js`、`model-contract.test.mjs` 早已在用的口径一致；旧矩阵形状保持"相邻原点距离"的原行为。
  两种形状都返回恰好 7 段（base + 6 连杆，末段近似）。
- **修后实测**（可达上界 = 6 段模长之和）：`ur3 804 mm` · `ur3e 823` · `ur5 1098` ·
  `ur5e`/`ur7e 1201` · `ur16e 1295` · `ur18 1358` · `ur10 1543` · `ur10e`/`ur12e 1627` ·
  `ur15 1693` · `ur30 1729` · `ur8long 2135` · `ur20 2168` —— UR3 到 UR20 相差 **2.70 倍**。
- **为什么它能一直绿灯**：旧单测喂的是手写的**矩阵**假数据（`straightLinks()`），从不读真实的
  `assets/kinematics.json`。现在补了读**真实数据**的断言：14 个型号都能解出长度、包络随型号单调
  变大、UR20/UR3 > 2.5。
- **这从来不是模型资产的问题**：14 个 GLB 本来就随型号不同（包围盒 ur3 0.35 m → ur20 1.06 m）。
  另外注意相机仍按各自包围盒取景（0.6.3 的设计），所以在**关掉可达范围图层**时机械臂依旧填满同一
  个画框 —— 那是取景归一化，不是尺寸错误。

## [0.6.8] - 2026-10-12

> **数字孪生开始跟随桌面程序的颜色主题。** DOM 部分随宿主设计 token 翻转，WebGL 部分由 JS 重刷；
> 顺带修掉两个在 DSH 设计系统里**并不存在**的 token —— 在深色主题下它们会渲染成一块白底。

### 变更 — 数字孪生跟随桌面程序的颜色主题

- **DOM 部分**改用宿主设计 token 着色（`var(--dsw-alias-*, <原来的深色值>)`）：token 随宿主投影的
  `body[data-ds-dark-theme]` 翻转 ⇒ 面板自动跟随「设置 → 外观」里选的主题，也跟随第三方主题，
  **无需 JS**。逗号后的 fallback 就是原来的深色值，因此在**没有**宿主 token 层的环境里渲染结果
  与改动前逐字一致。
- **WebGL 部分**（CSS 够不到）由 JS 重刷：新增 `src/client/theme.js`（主题判定 + 3D 色板 +
  `MutationObserver` 观察）；`twin-panel` 建场景时按当前主题取色板，切换时调
  `scene.applyTheme()` 重建基座网格（`GridHelper` 把线色烘进几何体顶点色，改色只能换几何体），
  回退臂的材质色同样跟随。
- **判定只认 `body[data-ds-dark-theme]`**，不退回 `prefers-color-scheme` —— 否则
  「浅色主题 + 深色系统」会被判反。拿不到 body 时按浅色处理且不抛错。
- 顺带修掉两个**不存在**的 token 引用（`--dsw-alias-bg-elevated` 与
  `--dsw-alias-border-secondary`，DSH 设计系统里没有定义）：写了只会静默落到 fallback，而浅色
  fallback 落在深色主题上就是一块白底。改动前已在本机 `dsh-client-ui-theme` /
  `-layout` 包里逐个核实真实 token 名。
- 回归用例 4 个（色板真的进网格顶点色、主题判定不退回系统偏好、观察器回调与取消、CSS 只引用
  真实 token）。

## [0.6.7] - 2026-10-10

> **数字孪生不再停在「数据已停止更新 Ns」。** 0.6.6 让停滞**如实可见**，这一版让它**不再发生**：
> 遥测从「孪生去问」改成「worker 主动推」。

### 修复 — 机器人运动期间孪生不再停更（主动推送遥测）

- **根因**：孪生的读与运动指令共用同一条**单线程 stdin 队列**（`python/ur_worker.py` 的
  `for line in sys.stdin`），而运动类工具的确认循环（`_movej_confirm` / `_movel_confirm` /
  `_wait_robot_idle`，60 s 预算）会一直占住它 —— 读只能排队到 2.5 s 预算耗尽。**但数据本身从未
  停过**：RTDE 由 URBasic 自己的接收线程以 500 Hz 写进 `model.dataDir`，读它与命令队列无关。
- **修法**：worker 起一个 20 Hz 的后台线程（`_twin_push_snapshot` + `_twin_push_loop`），把关节角与
  TCP **主动推**成一行**不带 `id`** 的协议 JSON；宿主的 `_onLine` 先于「按 id 匹配响应」识别它，写入
  `latestTelemetry` 缓存；孪生的每一帧**优先读缓存（零 worker 往返）**，只有缓存超过 300 ms 或缺失时
  才回退到显式读。
- **协议向后兼容**：没有 `id` 是唯一标志 —— 旧宿主只会把它记成一条「匹配不上的响应」，无副作用。
- **推送与响应共用一把写锁**（`_PROTOCOL_LOCK`）：并发写 stdout 若不整行原子，两条 JSON 会交错，
  表现为随机丢帧与莫名超时。
- **严格校验**：关节角或 TCP 不足 6 维的推送**直接丢弃**，绝不用半截姿态覆盖上一笔好读数
  （否则机械臂会肉眼可见地跳一下）。
- **可关**：`DSH_UR_TWIN_PUSH=0` 关掉推送做对照（孪生随即退回 0.6.6 的「读 + stale」行为）。
- **实测证据**：新增 `scripts/probe-twin-push-continuity.mjs` —— 假 worker 的 `call()` 永不 settle
  （精确模拟「队列被占住」）时，**有推送：20 帧 / 最大帧间隔 112 ms；无推送：仅 3 个 `stale`**。
  回归用例 5 个（推送优先零调用、过期回退、抛错降级、推送行入缓存且不计 unknown、dispose 清缓存）。

## [0.6.6] - 2026-10-6

> 下面代码注释里写的 `0.6.6` 指的就是这条未发布的改动；`package.json` **已升到 0.6.6**，
> 但还没发布 —— profile 里装的仍是 GitHub 上的 `#086d365`（0.6.5），推送后再改引用并重装。

> **数字孪生跟着机器人动两下就不动了，而且再也不恢复。** 这是三个缺陷叠加的结果：
> 读还没回来时帧泵**彻底静默**（画面就那么冻住，界面上一个字都不说）、孪生的读会因为超时
> **杀掉整条机器人会话**、以及一个坏帧就把客户端整条流拆掉（连来八次就永久死亡）。
> 三个都已修复，每个都有可复现的实测。

### 变更 — 14 个模型资产瘦身 40.6%（35.11 → 20.86 MB：先无损，后有损）

- **第 1 步 · 无损（→ 28.27 MB）**：新增 `scripts/compress-models.mjs`，只做两件**不改变观感**的事 ——
  ① trimesh 把**所有**顶点索引都写成 `UNSIGNED_INT`（4 字节/索引），而这 14 个型号最大索引值只有 24228，
  `UNSIGNED_SHORT` 完全够用；② 删掉每个 primitive 上那个**没有任何材质读取**的非标准属性
  `_color`（three.js 的 `GLTFLoader` 会把它塞进 `geometry.attributes._color`，然后没人用）。
  顺带把因此出现的 BIN 空洞与被孤立的 `accessor` 一并回收。
- **自证而非声明**：脚本对每个文件逐项断言"顶点位置 / UV 的字节**逐字节相同**、索引序列
  **逐值相同**、`accessor` 的 `min`/`max` 与节点名顺序不变、每个 `bufferView` 落在 buffer 内且 4 字节对齐"，
  任一不满足就拒绝写盘。压缩后 `python scripts/verify-models.py`（14/14）、
  `node test/model-contract.test.mjs`（6/6，含 14 型号多姿态装配与相邻连杆间隙）全绿。
- **第 2 步 · 有损、经明确决策（→ 20.86 MB）**：`--texture-size 1024` 把 5 个新型号里**共 8 张**
  2048×2048 底色 PNG（ur15 1 张、ur18 2 张、ur20 1 张、ur30 2 张、ur8long 2 张；其中 ur8long 复用
  ur15 的贴图、ur30 复用 ur20 的）用**块平均**降到 1024×1024（10.67 MB → 3.25 MB）。整数倍降采样用块平均而不是双三次：双三次是插值，降采样会漏掉被跳过的
  像素；块平均把每个 2×2 源像素平均成一个目标像素，正是"降一半分辨率"的语义。
  9 个老型号的内嵌贴图只是 16×8/32×8（合计约 1 KB），**不放大、不改动**。
- **降分辨率实现**：新增 `scripts/texture-resize.mjs`（零依赖、跨平台的 PNG 解码/缩放/编码）。
  没有用 `sharp`/`pngjs`（要给"零第三方依赖"的仓库塞依赖）、没有用 Python PIL（本机没有）、
  也没有用 Windows 的 `System.Drawing`（**只在 Windows 上存在 ⇒ 发布产物无法在 CI/macOS 重建**）。
  解码正确性用两条独立证据夹住：与 Windows GDI+ 对同一张真实贴图做**逐像素交叉比对**（7 个采样点，
  含四角，全部一致），以及 `test/texture-resize.test.mjs` 的往返与真实样本断言。
- **视觉验收**：同一物理区域的原图 1:1 与缩后图放大并排比对（`--texture-size` 的 dry-run 会打印每张
  图的前后尺寸与字节），肉眼无法区分；而孪生面板实际只有几百像素宽。
- **体积构成（实测，`npm run analyze:models`）**：索引 12.78 MB（36.4%）+ 几何 11.78 MB（33.6%）+
  纹理 10.67 MB（30.4%）。**10.67 MB 纹理全部来自那 5 个新型号**。
- **裁定变更记录**：Ruling 24 的"全量原始精度、不抽稀"**只适用于几何**（顶点位置、UV、索引在本步全部
  逐字节/逐值不变）；**底色贴图**经用户 2026-10-09 明确决策降为最长边 1024。`model-contract.test.mjs`
  的体积下限因此从 25 MB 调到 15 MB（并注明最小文件 ur20 0.69 MB 仍远高于 0.5 MB 下限）。
- **仍未做（需要时可再来一档）**：纹理 → 512² 约再省 2.5 MB；无损 WebP 约 −2.5 MB；
  UV 的 `float32` → `uint16`（`KHR_mesh_quantization`，three 支持）约 −2.2 MB；
  位置量化**不建议**（`loader.js` 的 `applyLinksToGroups()` 每帧往这 7 个组的 `matrix` 写**绝对**变换，
  会覆盖量化的节点补偿 ⇒ 手臂会错位）；Draco/meshopt 需要改客户端加载路径 + 多托管一个 wasm。


### 修复 — 孪生停住且不再恢复

- **停滞的帧泵现在会出声，而不是静默**（`lib/twin-routes.js`）。帧泵不会在上一帧的读还没回来时
  叠加第二帧（这是对的：worker 是单线程的，在飞上限只有 8），但它以前在那段时间里**一个事件都不发**
  —— 实测：运动指令占住 worker 的 6 s 内零事件（`scripts/probe-twin-pump-stall.mjs`）。客户端于是
  看到一条"开着的、安静的流"，画面永远停在最后一帧，与"机器人停了"完全无法区分。现在读在飞时
  每秒发一个 `stale` 事件；读超过 15 s 的安全网则发 `frame-error`。两条路都**不关连接、不结束响应**。
- **孪生的读再也不能毁掉机器人会话**（`lib/twin-worker.js`、`lib/worker.js`）。
  `UrWorker.call()` 在请求超预算时会杀掉 Python 子进程（设计如此：卡在库代码里的单线程 worker
  会让它后面的一切都排死）。而孪生既共用这条 60 s 的默认预算、又共用同一条 worker 队列，于是一次
  排在长动作后面的读超时后会杀掉子进程 —— 连带 RTDE 与 Dashboard，孪生此后永远拿不到位姿。
  现在孪生的读走**专用 2.5 s 预算 + `killOnTimeout:false`**：这一帧快速失败、会话留下、下一帧再试。
  运动类工具自己的预算与"超时杀进程"行为完全不变。
- **读"暂时拿不到"降级成陈旧帧，而不是报"未连接"**（`lib/twin-routes.js`）。
  worker 忙/超时以前被答成 `connected:false`，客户端于是把整个 3D 视图藏起来、写上「未连接机器人」
  —— 用户看到的正是"同步两个动作后就不动了"。现在宿主回放最后一笔已知读数并标记 `stale:true`
  （**原始 `ts` 保持不变**，龄期继续增长；回放窗口 30 s），客户端保留画面并显示停滞提示。
  真正的连接错误仍然如实报 `connected:false`。
- **一个坏帧再也不能拆掉客户端的流**（`src/client/robot/twin-stream.js`）。
  `EventSource.onerror` **就是**名为 `error` 的事件的事件处理器，而服务端事件按 `event:` 字段派发
  —— 于是宿主文档里那句"单帧失败只发一个 `error` 事件、绝不拆流"，在真实浏览器里恰好**反过来**：
  每个坏帧都拆一次连接。用符合规范的 `EventSource` 实测（`scripts/probe-twin-stream-error-event.mjs`）：
  一个 `error` 帧 ⇒ 客户端重建了流。现在**按"带不带 `data`"区分**（服务端消息有 data，传输层错误没有），
  并且宿主把这个事件改名为 `frame-error`，两者从此不可能再撞名。
- **流永不放弃**（`src/client/robot/twin-stream.js`）。"连续 8 次重连失败即放弃"是个终态：没有定时器、
  不再建连、画面永远停在最后一帧 —— 而真实世界的断流（宿主重启、窗口最小化时连接被浏览器掐掉、
  笔记本休眠/唤醒）恰恰是"连续失败十几次、之后又能连上"的形状。现在改为无限重连 + 指数退避封顶
  30 s，并且**只有收到真帧**才清零退避（不是 `open`：一个"能连上但一帧都不发"的端点不该被当作恢复）。
- **数据通道的状态看得见、也会自愈**（`src/client/state.js` 新增 `getStreamHealth()` / `retryNow()`；
  `src/client/twin-panel.js` 增加专门一行）。面板会写「数据已停止更新 Ns · 正在重试」（带帧数与失败数）、
  重连时写「数据通道重连中…」，窗口重新可见时立刻重试，停滞 10 s 后**强制重建**通道
  （浏览器的定时器节流可能让退避定时器一直不触发）。
- **worker 错误码机器可读**（`lib/worker.js`）：`WORKER_BUSY` / `WORKER_TIMEOUT` / `WORKER_EXITED` 等，
  孪生据此区分"暂时拿不到答案"与"机器人真的没连上"，不必解析中文散文。

### 测试

- `twin-routes.test.mjs` —— 这条 SSE 路由**以前一条测试都没有**，所以"静默停帧"与"error 撞名"
  才能长期全绿：补上帧/心跳/405 断言、"worker 被占住时发 `stale`（绝不静默）"、读超时安全网、
  单帧串行背压，以及"陈旧帧降级"策略（含 30 s 回放窗口）。
- `twin-stream.test.mjs` —— 假 `EventSource` 现在**按规范派发**（服务端 `error` 消息同样命中
  `onerror`），这正是旧假实现表达不出来的那一面；新增"连续失败 20 次永不放弃"、退避封顶/清零规则
  与 `poke()`。
- `twin-worker.test.mjs`（新增）—— 孪生读策略：短预算、`killOnTimeout:false`、worker 为 null、
  错误码集合。
- `stream-wiring.test.mjs`、`twin-panel.test.mjs` —— `stale`/`frame-error` 事件的停滞标记、
  `getStreamHealth()`、`retryNow()`、「数据已停止更新」提示行与强制重建。
- `worker.test.mjs` —— `killOnTimeout:false` 保住子进程；默认路径仍然杀掉它。
- `scripts/` 里留下三个诊断探针（`probe-twin-pump-stall.mjs`、`probe-twin-stream-error-event.mjs`、
  `probe-sse-lifetime.mjs`），让这三个传输层问题可以在真机上被**重新实测**，而不是靠重新推理。

## [0.6.5] - 2026-10

> 本版把数字孪生从"只读预览"做成现场工具，并把 10 Hz 轮询换成推送通道。同时收尾了一批
> **读取回执的诚实性修复**：好几个工具在报告它们其实读不到的值 —— 工具遥测永远返回 `null`、
> 自由驱动检查把陈旧的 `0` 读成"正常"、`power_off` 把"控制器因为刚断电而不应答"当成失败。
> 以下内容都已在树里，只是从未被写下来；0.6.3 与 0.6.4 没有作为独立条目发布过。

### 新增 — 宿主的第 4 条只读路由：SSE 实时流

- **`/dsh-nonead-ur/twin/stream`**（`lib/twin-routes.js`）：用 Server-Sent Events 取代"轮询碰运气"。
  每 `100 ms` 一帧、15 s 一次 `: ping` 心跳（空闲连接正是代理会在 30–60 s 后切掉的东西）、
  `pumping` 标志做背压（上一帧没写完就不发下一帧）、订阅即推首帧、`x-accel-buffering: no`，
  非 `GET` 一律 `405`。**单帧失败只发一个 `error` 事件，绝不拆掉整条流** —— 客户端保留上一帧好数据。
- **流里的 `detail` 走自己的慢节拍**（`TWIN_STREAM_DETAIL_MS` = 2000 ms）：不能每帧带（每帧一次
  dashboard 往返，10 Hz 会把机器人打满），也不能一帧都不带（安全模式、温度与母线电压会永远是空的）。
- **客户端订阅器**（`src/client/robot/twin-stream.js`）：`EventSource`，断线 1 s 重连，连续 8 次失败
  即放弃**并通知订阅者**；环境没有 `EventSource` 时明确说明，而不是静默什么都不做。
- **流与轮询严格互斥**（`src/client/state.js`）：`stream: true` 时一次 `fetch` 都不发 —— 两者并存会让
  同一帧推两次、机械臂画面抖动。切换机器人会整条重建流，且客户端半现在**默认 `stream: true`**。
- 宿主兼容门禁现在期望 **4** 条 `kind:'exact'` 孪生路由（`state` / `asset` / `models` / `stream`），
  不再是 3 条。这条断言的意义是"注册形状变了要让**人知道**"，不是把条数冻死。

### 新增 — 在多台机器人之间选择，并看清自己在看哪一台

- **`setIp()` 会清掉上一台的读数**（`src/client/state.js`）：切换目标立即丢弃 `connected`、`q`、`tcp`、
  `ts` 与 `detail`。把 A 的位姿当成 B 的显示，比什么都不显示更危险。同一个 IP 是 no-op（连快照对象都
  不重建）；空白或非字符串表示"交回宿主解析"。
- **机器人选择按钮与身份行**（`src/client/twin-panel.js`）：选择器只在签名（`${resolvedIp}|${candidates}`）
  变化时重建 —— 每帧重建会在手指还没抬起时把按钮换掉。数值面板最上面一行现在显示 `型号 · IP`；
  IP 以前只躺在 `data-ur-twin-ip` 属性里，界面上一个字都看不到。
- 未连接的帧**必须保留 `ips` 候选**，否则选择器恰恰在最需要它的时候点不到（连了多台 ⇒ 目标有歧义）；
  `setIp` 会 abort 在飞的请求并立刻重取一次，而不是干等下一个 tick。

### 新增 — 先看后动：待审批运动预览

- **`lib/pending-motion.js`** 把审批弹窗变成一次预览，并且**绝不假装自己知道得更多**：`joints`（可以画
  整条幽灵臂）/ `pose`（本插件没有 IK，只在目标位置放标记）/ `relative`（只给文字 —— 绝对目标要先结合
  当前 TCP）/ `opaque`（画圆方星、跑程序、力控与速度指令没有单一目标）。它**永不抛错**：畸形参数退化成
  `opaque`，摘要截断在 200 字符。
- **`createPendingMotionStore()`** 为每次审批发放专属 **token**，于是两次审批重叠时，先结束的那次
  抹不掉后一次的预览。`read()` 把超过 `PENDING_MOTION_TTL_MS`（10 分钟）的预览视为已结束 ——
  一次被打断的审批就是这样停止在屏幕上留下一层假目标的。
- `lib/index.js` 在弹窗**之前** `begin`、在 `finally` 里 `end`，所以批准、拒绝、以及"审批服务抛异常"
  三种情况都会撤掉预览。
- 状态路由**只在有待审批时**才带 `pending_motion` 字段（没有时字段缺席，而不是 `null`），客户端才能
  区分"当前没有审批"与"有审批但解析不出目标"。与 `detail` 不同，客户端**刻意不**沿用上一帧的
  `pending_motion`。

### 新增 — 孪生面板上的现场工具

- **幽灵臂**（`src/client/robot/ghost-arm.js`）：克隆真臂叠加在实际位姿上，跟随误差、滞后与交融一眼可见。
  geometry 与贴图与真臂**共享**（多一层几乎不额外占显存）—— 也正因为如此，克隆树的 geometry
  **绝不 dispose**：那正是真臂在渲染的同一批对象。待审批目标显示为橙色，控制器当前目标为青色。
- **TCP 坐标轴**（`src/client/robot/tcp-axes.js`）：固定 8 cm 的 `AxesHelper` 在 UR3 上偏大、在 UR30 上
  偏小，而且没有标签。尺寸改为臂半径的 `0.12 ×`，钳在 `[0.03, 0.3]`，并配 X/Y/Z 字母标签（用 canvas
  画，不依赖外部字体，无 canvas 环境优雅退化）。缩放必须写在内层节点：外层节点每帧接收 `tool0` 矩阵，
  而 `scale` 在 `matrix.fromArray` 里是留不住的。
- **工程辅助图层**（`src/client/robot/overlays.js`），默认全关：可达包络、负载重心、TCP 受力箭头
  （死区 1 N、上限 0.6 m）。可达半径取前 6 段连杆长度之和，并明确注明它是**上界**，不是厂商 spec 的
  reach 值。重心标记已实现但**刻意不暴露** —— 插件没有能读回载荷的 op，按钮点下去不会有任何反应。
- **截图导出**（`src/client/robot/screenshot.js`）：PNG 水印带型号、IP、安全模式、速度倍率、关节角、
  TCP 与本地时间。水印画在画布的**副本**上，而副本必须在**渲染之后同步**取 —— 上下文是
  `preserveDrawingBuffer: false`，先让出控制权再取图可能拿到一张全黑图。
- **轨迹控件**：清空 / 暂停-继续 / 导出 CSV。CSV 除位置外**还带关节角**，否则导出的数据无法复现姿态。
  颜色现在随样本新旧从暗蓝渐变到亮青，同时表达方向与相对速度；时间戳全不可用时退化为按序号渐变，
  而不是产出 `NaN`。
- **可访问性**：canvas 是 `role="img"` + `aria-label` + `tabindex="0"`，方向键与 `Home` 驱动既有的视角
  预设 —— 这是纯键盘用户目前唯一能操作 3D 视图的途径。数值面板是 `role="status"` + `aria-live="polite"`
  （只播报变化，不每次重读整块），开关按钮带 `aria-pressed`，被截断的读数补 `title`。

### 新增 — 客户端文案变成一张真正的表

- `src/client/strings.js` 不去赌 `@deepseek-ai/dsh-client-locale`（本机并未安装）：`zh` 与 `en` 的键集合
  **完全对称**（有测试双向断言这一点），带插值的键写成函数，`resolveLocale` 只认主语言子标签，并且
  认不出时**回退中文而不是英文**。右栏入口卡片与覆盖层的文案也取自同一张表。

### 修复 — 读取回执：工具报告了它们读不到的值

- **`ur_get_tool_telemetry` 除了 `null` 什么都返回不了。** 工具侧字段既不在 RTDE 配方里，vendored
  访问器又是 `NotImplementedError` 桩。配方现在声明了它们（`tool_*`、`io_current`、
  `target_speed_fraction`；按 RTDE 文档 `tool_output_voltage` 是 `INT32`，24 V 读作 24000），工具也改为
  直读 `dataDir`。
- **`ur_get_tool_analog_in` 改为优先直读 RTDE**，只在不得不时才回退到"发脚本 + 回读寄存器"那条路 ——
  那条路会打断正在运行的程序。回读寄存器默认 22，以避开 `send_script` 用的 23。
- **`ur_get_speed_scaling` 不再把静止读成"被压到 0"。** `speed_scaling` 是**实际**倍率，
  `target_speed_fraction` 是**请求**倍率；现在两个都给，并在应答里写清语义。
- **`ur_get_freedrive_status` 用哨兵 token** 区分"该固件不支持"与"值真的是 0"。旧实现读到的是一个
  陈旧寄存器，却把它当成正常。
- **`ur_power_off` 以 `robot_status_bits` 的 `PowerOn` 位为准**，于是"控制器正因为刚断电而不应答"
  不再被报告成失败。
- **`ur_draw_circle` 写入起始哨兵**，把一次盲目的 60 s 超时变成即时的 `NOT_EXECUTED`（控制器根本没跑脚本时）。
- **`ur_move_tool_x/y/z` 的工具系→基座系换算放在 worker 侧**（`_tool_axis_move`）：读当前 TCP 位姿，
  用该位姿的旋转矩阵把位移转过去，再发基座系 `movel`。这里**刻意不用** `pose_trans` —— 它在 CB3 /
  URSoftware 3.15 上出现过运行期中止。

### 修复 — 两处肉眼可见的缺陷

- **回退臂永远是 UR3 量级。** `buildFallbackArm()` 无条件使用 `ARM_LINKS`，于是加载失败的未知型号会退回到
  与眼前这台机器人不符的几何。连杆长度现在由 `linkLengthsFromKinematics(kin.links)` 推出，逐值回退，
  且永不产出 `NaN`/`0`/负数 —— 一个 `NaN` 顶点会让整棵子树消失。
- **右栏 3D 视图原先是一个绝对定位的覆盖层。** 它的包含块不是右栏内容体，实测比右栏宽、压到对话区上方。
  现在改为正常流的 flex 子项，并以内联方式隐藏引导列（记录原值，收起时还原）。入口卡片优先**深度克隆
  原生卡片**（主题、圆角与图标槽全都挂在哈希类名上，手工复刻必然漂移），原生卡片缺失时退回自建卡片，
  引导列稍后渲染出来时再升级为克隆卡片；点了别的卡片或引导列消失即自动收起。

### 变更 — worker 背压

- `lib/worker.js` 的 `DEFAULT_MAX_IN_FLIGHT = 8`：超过上限的调用**直接拒绝，不排队**。worker 是单线程的，
  排在卡住的那个请求后面的调用只会各自烧完自己的超时；错误文案现在会点名可能的原因（"机器人可能已无响应"）。

### 新增 / 变更 — 门禁与自检

- **`scripts/check-new-ops.py`** —— 0.6.0 新增的每个 worker op 的行为门禁：对着假控制器断言**实际下发的
  URScript**（力控、`speedj`、`optimove`、`movec`、传送带跟踪、绘图路点序列），外加 14 条必须 fail-closed
  的 `ValueError` 用例。
- **`scripts/check-test-manifest.mjs`** 把 `test/test-manifest.json` 与 `test/**` 里真实的 Python 调用
  **双向**对账：需要 Python 却没登记的用例失败，登记了却根本不碰 Python 的用例同样失败。
- **`scripts/check-package-metadata.mjs`**：`main` / `exports` / `dsh.bundle.patch` 必须可解析、客户端
  bundle 必须以包名注册、`files` 必须覆盖运行时且**不得**含本机的 `python/sitecustomize.py`、任何源文件
  不得硬编码作者机器的路径。**`scripts/check-doc-tools.mjs`** 把 README 工具表与真实注册表对账（只解析
  表格行 —— 旧版扫全文，删掉一整行表格它照样通过），**`scripts/check-tool-params.py`** 双向强制跨语言
  参数契约。有两个坑值得记下来：`check-host-compat.mjs` 把已安装的桌面 `node_modules` 排在向上查找**之前**，
  因为本仓库自带的 `@deepseek-ai/dsh-tools` dev 副本更旧，用它校验会得出误导性的"0/83 注册成功"；
  `check-tool-params.py` 的中文诊断只写文件、stdout 保持 ASCII，否则中文 Windows 控制台会让检查自己
  以 `UnicodeEncodeError` 死掉。
- `npm test` 现跑 **9 条门禁**（4 Node + 5 Python）与 **35 个测试文件**（11 Python、24 Node）；
  `check-host-compat.mjs`（对宿主真实 DSL 的 83/83 个工具、4 条路由）仍走 `npm run verify:host`。
  本机实测 **44 项全部通过**（Python 那一半需要 `numpy`/`paramiko` 可导入 —— 见 `python/sitecustomize.py`）。

- **`tool_mode` 不是工具输出模式，它的含义未确认。** 在 UR30 / PolyScope 5.21 上实测为 253，且
  调用 `ur_set_tool_output_mode(0)` / `(1)` 时**不发生变化**。读它本身没问题 —— 它是从 RTDE
  原样透传的 —— 但 `test/readback-fixes.test.mjs` 的夹具编造了一个看起来很像模式枚举的 `2`，
  让这个字段显得有意义。夹具现改用实测值 253，并写明其含义待定。
- **程序加载/运行/暂停/停止在"控制器没有可运行的程序"时表现得如实。** `ur_run_program` 逐字回报
  控制器的拒绝（`Failed to execute: play`），而不是谎报成功；`ur_load_program` 会拒绝含尖括号的
  名字 —— 这是对的（`<未命名>` 是 PolyScope **显示**未保存程序的方式，不是文件名），但也意味着
  `loaded_program` 那串不能直接喂回 `ur_load_program`。

- **`ur_get_conveyor` 现在会自证那段 URScript 真的执行过，而不是回读一个没人写过的寄存器。**
  传送带 tick 只能靠控制器执行一段 URScript 取回，而**在加载期被拒收**的程序一行都不会执行，
  也不会置"程序执行错误"标志 —— 旧实现于是照样回读 `output_double_register_0`，把那里碰巧残留的
  值报出去。上面那个"函数名写错"的缺陷能潜伏这么久，根因就在这里。现在工具先探测通道，
  再执行一段由首尾哨兵夹住的载荷：哨兵写 **int** 寄存器、tick 写 **double** 寄存器 ——
  刻意分成两个寄存器家族，这样"载荷那条路坏了"不会把哨兵一起带走、把所有结局都塌缩成
  "什么都没发生"。三种结局分开报：**跑到末尾**（`verified: true`，tick 可信）、
  **开始了但没跑到末尾**（`UNSUPPORTED`，不给 tick 值）、**压根没执行**
  （`NOT_EXECUTED`，不给 tick 值并点名最可能的原因）。已在 UR30 / PolyScope 5.21 上验证：
  工具报 `verified: true`，而独立回读 `output_int_register_20` 得到的就是它声称的那个结束哨兵。
  两个可选参数（`register`、`payload_register`）用来挑寄存器，两者的旧值都会被覆盖。
- **`ur_get_double_register` 与 int 寄存器走同一条读取路径。** 它此前直接调
  `OutputDoubleRegister`，访问器缺失或抛异常就变成异常而不是取值；现在改用新增的
  `_read_double_register` helper，读不到时回落原始 RTDE 字段 —— 这正是 `_read_int_register`
  一直以来的做法。

### 修复 — 一次对 URSim（UR30 / PolyScope 5.21.3）的实机测试查出来的

- **`ur_get_conveyor` 只可能返回 0 —— 因为更早的一次"修复"让控制器把整段脚本拒收了。**
  URScript 里写双精度寄存器的函数叫 **`write_output_float_register`**；`output_double_register_0`
  是**同一条数据的 RTDE 字段名**。更早的版本把这两个名字当成了同一个，把调用"改正"为
  `write_output_double_register` —— 一个并不存在的函数。控制器于是在**加载阶段就拒收整段程序**，
  一行都不会执行；`waitRobotIdleOrStopFlag()` 因此永远看不到执行错误，而
  `get_conveyor_tick_count()` 接着去回读寄存器 0 —— 一个从未被写过的值。**一次看得见的报错，
  就这样变成了静默的错值。** 在 PolyScope 5.21 / UR30 上实测：`write_output_float_register(0, 42.5)`
  被接受且 `output_double_register_0` 读回 42.5；而 `write_output_double_register(0, 99.5)` 被直接
  拒收（`ur_send_script` 的哨兵根本不落地）。现已改回，`urScript.py` 里就地写明证据，并由
  `test/readback-fixes.test.mjs` 在错误名字再次出现时失败 —— 当初那次改动**完全没有测试覆盖**，
  它就是这样溜过去的。

- **控制器发来的每一个非 ASCII 字符串都是乱码。** `dashboard.py` 的接收路径用
  `''.join(map(chr, out))` 拼字符串 —— 一个字节取一个码点，等价于按 Latin-1 解码，于是
  PolyScope 5 的 `STOPPED <未命名>` 到手变成 `<æªå½å>`、`(三月 14 2025)` 变成 `(ä¸æ 14 2025)`：
  中文程序名在任何一处读数里都读不出来。现在按 UTF-8 解码，解不开再退回 Latin-1
  （老固件若真发单字节文本仍能工作）。
- **`program_state` / `runtime_state` 把程序名一起带出来了。** 与 `safetymode` / `robotmode`
  只带 `标签:` **前缀**不同，`programState` 回的是「状态词 **加上** 程序名」—— 实测空闲时
  `STOPPED <未命名>`、运行中 `PLAYING <程序名>`。`_enum_token` 只剥前缀，于是客户端按裸枚举词
  查中文表落空，HUD 显示的是「程序 STOPPED <未命名>」而不是「程序 已停止」。新增的
  `_program_state` 在协议边界剥掉尾部的 `<程序名>`，同时**不动** `"<查询失败>"` 哨兵。这与 0.6.2
  修的前缀缺陷是同一类 —— 而夹具又犯了同样的错（`ur_programState` 被伪造成裸值 `"STOPPED"`），
  所以 `test/safety-status.test.mjs` 现在喂真实的 `STOPPED <未命名>`，并把"剥掉程序名"双向钉住。
- **`ur_get_digital_in(which="tool")` 抛出的错误没有信息量，还可能报出陈旧值。** 工具数字输入
  不经 RTDE，只能发一段 URScript 程序 —— 而在**没有接工具**的 UR30/URSim 上，控制器会**让这段
  程序以运行期错误结束**。上游随即抛出 `RuntimeError: Robot program execution error!!!`
  （完全没有信息量），而 `urScript.get_tool_digital_in` 接着去**回读输出寄存器 0** —— 把那里残留的
  值当成输入电平报出去。现在这条失败路径返回可操作的错误（点名常见原因：未连接工具、工具 I/O
  未启用、工具端被 TCI 串口占用），并且**不读任何寄存器**。同时也对着控制器证实了：寄存器这条路
  从来没问题 —— `write_output_integer_register(7, 12345)` 读回来就是 12345，被控制器拒绝的是
  `get_tool_digital_in` 本身。

### 文档

- **补回丢失的 `## [0.6.0]` 标题。** 手册交叉核对的说明（"工具数 67 → 83"）自写下起就一直挂在 0.6.1
  条目内部，没有自己的版本标题；其余每个版本都有。

## [0.6.2] - 2026-09

> 针对 DSH `0.2.0-rc.2` 做了一次兼容核对（并与 `0.1.7-rc.2` 交叉对照），发现有三个工具从未
> 到达模型。它们的参数 schema 写了显式的 `required: false`，而值 schema DSL 直接拒绝这种写法——
> 被拒的参数会让**整个工具**注册失败，只在日志留一行 warning。表里写着 83 个工具，实际能调的只有 80 个。

### 新增 — 面板终于用上了宿主一直在发的遥测

- **`detail=1` 原本没有任何消费者。** 路由一直能返回 dashboard 侧状态（`safety_mode`、
  `robot_mode`、`program_state`、`running`、`speed_scaling`、`joint_temperatures`、
  `joint_currents`、`robot_voltage/current`），但客户端从不请求它。现在它在**既有那条轮询链上
  按慢节拍**取（`detailMs`，默认 2 s）——不新增第二条链，所以"同一时刻只有一次请求在飞行中"
  依然成立，位姿通道也保持 10 Hz。某一轮没带 detail 时沿用上一次的值，数值行不会闪烁。
- 数值面板多了两行（安全/模式/程序/速度，以及关节温度与母线电压电流），并且**安全模式异常时
  会接管状态行**，不再埋在「已连接 · ur5e」后面。不认识的模式串**原样显示并视为异常** ——
  固件新增一个模式，绝不能因此让一次保护性停止看起来像正常。

### 新增 — 视角工具栏、按包围盒取景、按需渲染

- **相机与基座网格不再按 ~0.8 m 的臂写死**，两者都由模型包围盒推导，于是从 UR3（reach ≈0.94 m）
  到 UR20/UR8long（≈2.4 m）开面板都是正确取景；`min/maxDistance`、`near/far` 与网格尺度跟同一个
  半径走。换机型时网格会重建（并释放旧的那一个）。
- **补上了一直不存在的工具栏**：重置视角 + 等轴测/前视/侧视/俯视。`scene.js` 从写下那天起就
  提到过一个"重置视角"控件，但面板里从来没有 —— 视角弄丢之后唯一的办法是收起面板再展开。
- **按需渲染**：只有确实有变化（新采样、尺寸变化、换模型、相机被拖动、切换预设）才真的画一帧。
  以前每帧无条件渲染，包括未连接时和机械臂静止时。
- **后台标签彻底停帧**（`visibilitychange`），回到前台自动继续。轮询早就对后台降频了，渲染没有。

### 修复 — 三个工具被静默漏注册

- 数组参数助手无条件写出 `required`，于是那些要求**可选**数组的调用点生成了 `required: false`。
  值 schema DSL 只接受 `required: true`（`required must be true when present`）；声明"可选"的方式是
  **省略**这个键。助手现在改为省略，而不是写 `false`。
- 恢复的工具：`ur_set_conveyor_tracking`（`direction`、`center`）、`ur_force_mode`（`task_frame`、
  `wrench`、`limits`）与 `ur_set_payload_inertia`（`inertia`）。`scripts/check-host-compat.mjs`
  对 `0.1.7-rc.2` 与 `0.2.0-rc.2` **两个宿主都报 83/83**。
- 该规则在两个宿主版本里逐字节相同，所以这从来不是版本兼容性回归：插件自带的
  `test/tool-schema-dsl.test.mjs` 看不见它，因为它把 `@deepseek-ai/dsh-tools` 换成了桩，只校验
  作者关键字白名单、从不校验 `required` 的取值。

### 修复 — dashboard 应答带着标签前缀，`NORMAL` 被读成安全异常

- **安全模式从来没有以裸枚举词到达客户端。** UR 对 `safetymode` / `robotmode` 这类查询回的是
  带标签的整行（`"Safetymode: NORMAL"`、`"Robotmode: RUNNING"`），而 worker 把整行**逐字**塞进了
  `safety_mode`、`robot_mode` 与 `program_state`。客户端按裸枚举词查表，于是查不到 —— 而
  `isSafetyHazard` 又刻意把"不认识的模式"算作异常，`NORMAL` 就这样被判成了异常。孪生面板底部
  随即**恒挂**「机器人可能已停止，请检查示教器」，**机械臂动与不动都一样**；带前缀的字符串还
  一并渗进了数值行、截图水印与 `ur_get_status`。
- 修法：`_enum_token` 在**协议边界**（唯一知道 dashboard 原始线格式的地方）剥掉 `标签:` 前缀，
  所有枚举字段统一走它。本来就没有前缀的应答（`programState` 回的 `"PLAYING"`）与
  `"<查询失败>"` 哨兵原样透传。
- `test/safety-status.test.mjs` 原先编造了裸值应答（`"PROTECTIVE_STOP"`），这正是套件一直全绿的
  原因。现在它喂真实带前缀格式，并把这条归一化钉成契约。

## [0.6.1] - 2026-09

> 对整个项目做了一次审核（四路并行审计 + 我本人动手复核，报告在 `docs/audit/`），发现了一批
> **测试看不见**的缺陷：运动审批门禁可被**完全绕过**、一个随包发布的文件**没有被 git 跟踪**、
> `test:node` 不可能通过、两个运动工具的行为与文档不符。本版全部修掉，并把审计用的检查
> 变成真正会失败的门禁。

### 安全 — 审批门禁可被完全绕过（host-audit H-1）

- **`lib/worker.js` 拼线上载荷时是 `{ id, op, _timeout_ms, ...params }`（`params` 展开在最后），
  而门禁判定用的是闭包里的 `op`。** DSH 的值 schema 不拒绝未声明的参数，于是模型只要在任意
  **未受门禁**的工具上多传一个 `{"op":"power_off"}`，worker 就会执行 `op_power_off` 而
  **完全不弹确认**。全部 38 个受门禁的指令（`movej`、`send_script`、`run_program`、
  `brake_release`、`force_mode`、`shutdown`…）都能这样触达；多传 `id` 还能让调用挂满超时后被 kill。
- 修法：参数在到达 worker 之前，按**该工具自己声明的参数表**白名单过滤；`op` 永远取门禁判定
  所用的那个闭包值，不可能被参数影响。`test/approval-gate.test.mjs` 驱动真实工具注册表，
  断言注入的 `op` / `id` / `_timeout_ms` 一律到不了 worker。

### 安全 — 门禁依赖 schema 应用默认值（host-audit M-6）

- `requireApprovalForMotion` 是 `Config` 四个字段里**唯一**在 `apply()` 中没有 `??` 兜底的，
  因此任何用"未经 schema 解析的裸 config"调用 `apply()` 的路径都会拿到 `undefined`，
  于是**静默关掉整道门禁**（fail-open）。现在默认值落在代码里
  （`config.requireApprovalForMotion ?? true`），并有测试钉住它。

### 修复 — 受门禁清单不完整（host-audit H-2）

- `set_payload` 没受门禁，而和它同类的 `set_payload_inertia` 受了 —— 两者都发
  `set_payload_mass` + `set_payload_cog`，都会**把力/力矩测量归零**（与受门禁的
  `zero_ftsensor` 同效）。`set_gravity` 同样没受门禁，而设错就是"松手后下坠或上飘"。
  两者现已受门禁，并加了成对断言，防止将来只门禁其中一个。

### 修复 — 两个工具的行为与文档不符（worker-audit HIGH-1 / HIGH-2）

- **`draw_square` / `draw_rectangle` 把距离写进了旋转分量。** `coordinate="z"` 时竖直边写的是
  `wp[1][3] -= border`，而索引 3 是 **rx（弧度）** —— 于是 `draw_square(border=0.2)` 让工具转了
  ≈11.5° 而不是画方。现在两处都用索引 2（z，米），并用测试断言整条路点序列与"姿态分量全程不变"。
- **`conveyor_tracking` 每个实参都在手册的错误槽位。** 它发的是 `conveyor_pulse_decode(a, b, 0)`
  （第一槽是**解码方式**，而 `0` 的含义是"脉冲解码关闭"）、
  `set_conveyor_tick_count(0, ticks_per_meter)`（第二槽是 0-4 位宽枚举）、以及
  `track_conveyor_linear(p[0,…], speed)` / `track_conveyor_circular(p[0,…], radius, speed)`
  （手册要的是方向/圆心位姿、每米/每转脉冲数、布尔量）。已按手册重写为
  `setup_pulse` / `setup_absolute` / `linear` / `circular` / `stop` 五个动作，量纲正确，
  并按固件区分编码器引脚范围（CB3 0-3、e-Series 8-11）。返回值里
  `hardware_verified: false` 如实标注：签名已对过手册，但跟踪行为需要真带编码器的传送带才能确认。

### 修复 — worker 错误处理里的崩溃路径（worker-audit MEDIUM）

- `ur_worker.py` 的未预期异常分支要记 `req.get("op")`，而 `req` 是在 `try` **内部**绑定的 ——
  于是一行坏 JSON 会在**异常处理里再抛** `UnboundLocalError`：既不回应本次请求，还让 worker
  直接退出。现在 `req` 在 `try` 之前初始化；用 `scripts/probe-malformed-request.py` 复现并复核。

### 修复 — 死掉的子进程会污染它的继任者（host-audit H-3）

- `lib/worker.js` 的 `exit` 处理无条件清掉 `this.proc` / `_spawnPromise` 并失败**所有**在飞请求。
  被 kill 的子进程，其 `exit` 事件完全可能在新子进程已经起来并开始服务之后才到达（500 ms 重启
  退避窗口，而孪生面板每秒发约 20 次调用）——于是健康的调用会收到"UR worker exited"，而它的
  子进程其实活着；`stats().running` 说谎；`dispose()` 可能留下一个仍占着控制器独占 RTDE 会话的
  孤儿 Python 进程。现在只清理属于自己的状态、只失败**路由到该子进程**的请求，并为每个子进程
  单独保留 stderr。
- `proc.stdin` 上补了 `error` 监听：子进程死后写入触发的 EPIPE 是**未处理的 'error' 事件**，
  它会掀掉整个 DSH 宿主进程，而不是让这一次调用失败。

### 修复 — 审计仓库本身发现的发布阻断

- **`python/URBasic/rtdeConfiguration.xml` 没有被 git 跟踪**，而 `package.json` 声明要发布它、
  `test/rtde-config.test.mjs` 要求它存在、`rtde.py` 优先解析它（vendored Default 没有
  `target_*` 字段、没有位寄存器 32-63、还带一个 `<send>` 段）。新克隆会静默丢掉这份配方。
  现已纳入跟踪。
- **`npm run test:node` 不可能通过**：`test/selftest.test.mjs` 会 spawn Python，却不在
  `PYTHON_DEPENDENT` 里。名单现在由 `test/test-manifest.json` 描述，并由
  `scripts/check-test-manifest.mjs` 从源码重新推导"哪些测试文件真的会调用 Python"并与名单对账
  —— 漏登记会变成一次失败的自检，而不是一句莫名其妙的 `exit 1`。
- 解释器探针现在验证 **worker 真正需要的依赖**（`import numpy`），而不是"Python 能启动"：
  以前一个没有 numpy 的解释器会让那十个依赖 Python 的文件**被执行并失败**，于是环境问题被
  误报成插件缺陷。
- **`ur_set_analog_out` 从没声明 `full_scale`**，而 worker 会读它、两份 README 与 CHANGELOG 都
  宣传它 —— 结果是 0-20 mA 端口根本用不了（`value=16` 会被"必须在 [0, 10.0] 内"拒掉）。
  现已声明并写清域（电压 10 / 电流 20）的语义。
- **`numberArray()` 把 `required` 写死成 `true`**，让"文档说可选"的数组在 schema 里变成必填
  （`force_mode.task_frame` / `wrench` / `limits`、`set_payload_inertia.inertia`），
  也使 `set_payload_inertia` 文档里写的 CB3 兜底路径完全不可达。现在 `required` 必须显式给。
- 英文 README：审批门禁清单漏掉全部 0.6.0 新工具；安装片段仍写 `^0.4.0`（会装到 0.5.0 之前的版本）。

### 新增 — 审计用的检查变成 `npm test` 里真正会失败的门禁

- **`test/approval-gate.test.mjs`**（新增，9 个用例）：驱动真实工具注册表，逐条证明受门禁的
  op 在获批前绝不下发；四条 fail-closed 路径（无审批服务 / 无 agent / 审批抛异常 / 任何非
  `allowed-once` 应答）全部拒绝；只读 op 不打扰人；`requireApprovalForMotion: false` 才真正放行；
  参数注入无法改派调用。
- 六个审计脚本原来都是**只打印、永远 exit 0** —— 正是本项目自己反复警告的"绿灯说明不了什么"。
  `check-worker-ops.py`、`check-approval-gate.py`、`check-rtde-recipe.py`、`check-tool-params.py`
  现在会在真有问题时**非零退出**，并且全部（连同 `check-test-manifest`、`check-package-metadata`、
  `check-doc-tools`，以及新增的 `check-client-bundle.mjs`）都接进了 `npm test` 与 `npm run check`。
- `check-client-bundle.mjs` 取代了原来的"字面量抽样"启发式（要么只看 6/113 条、要么大量假警报），
  改成**确定性的重建比对**：把 `src/client/**` 重建到临时文件再与提交产物比对，于是"产物落后于
  源码"会让构建失败。它绝不覆盖提交产物 —— `build-client.mjs` 为此新增 `BUILD_CLIENT_OUT`。
- `scripts/probe-malformed-request.py` 与 `scripts/probe-sendprogram-blocking.py` 保留两个无需硬件的
  探针：前者复现"坏 JSON 杀死 worker"的路径，后者是"进入永不结束的模式（力控/自由驱动）不会卡住
  后续发送"的可执行证据（实测 0.25 s —— 记下来，免得将来又有人只读源码重新怀疑一遍）。

### 文档

- `docs/audit/` — 四份带 `file:LINE` 引用与代码原文的审计报告（`worker-audit.md`、`host-audit.md`、
  `client-vendored-audit.md`、`verification-audit.md`），外加 `round2-verification.md`：记录我动手
  复核的结论、**修正了子代理报告中三条评级过高的 HIGH**，并列出"已检查确认无问题"的清单
  （门禁清单完整性、RTDE 配方余量、包元数据、bundle 新鲜度、`SendProgram` 阻塞行为）。

## [0.6.0] - 2026-09

> 本版把插件**逐条对照仓库内三本官方 URScript 手册**（`ScriptManual/scriptManual_3.15.4.pdf`
> 对应 URSoftware 3.x / CB3、`script_directory_Poly5.pdf` 对应 PolyScope 5 / e-Series、
> `script_directory_PolyscopeX.pdf` 对应 PolyScope X / 10.x）重新校对了一遍：补齐了手册里有、
> 插件里没有的能力，改正了三处**默认值与语义与手册不符**的地方，并把交叉核对结果沉淀成
> [`docs/urscript-manual-analysis.md`](./docs/urscript-manual-analysis.md)。
> 工具数 67 → **83**。

### 新增 — 力控（`ur_force_mode` / `ur_end_force_mode` / `ur_force_mode_settings`）

- 这是插件此前**完全没有**的一大块能力：力控让机器人沿/绕选定轴变"柔性"并持续施加指定力/力矩
  （打磨、装配、贴合、拖动示教之外的下压类工艺都要用它）。参数与手册逐条对齐：
  `task_frame` / `selection_vector`（1=柔性）/ `wrench` / `type`（1-3）/ `limits`
  （柔性轴=最大 TCP 速度，刚性轴=最大允许偏差）/ `damping`（0-1）/ `gain_scaling`（0-2）。
- 实现方式与手册语义一致：力控是一个**持续状态**——脚本用
  `while True: force_mode(...); sync() end` 让它在控制器侧一直生效（与 URBasic 的做法相同），
  因此 `ur_force_mode` 只负责"进入"，退出用 `ur_end_force_mode`（发新脚本抢占该程序并调用
  `end_force_mode()`）或在示教器停止程序。
- 按手册建议在进入力控前插入 `sleep(0.02)`（手册 15.12 的 Note 明确要求，用于避免沿柔性轴的
  运动与高减速），并**在本地就校验** `selection_vector` 只能是 0/1、`type` ∈ 1/2/3、
  `damping` ∈ [0,1]、`gain_scaling` ∈ [0,2]——这些越界在控制器上会直接报错或让力控不稳定。
- ⚠️ **如实标注**：`damping` / `gain_scaling` **控制器侧没有回读通道**（手册只定义了
  `force_mode_set_*`），所以 `ur_force_mode_settings` 只回报"本次设置值"并显式给出
  `readback_supported: false`，不假装读到了当前值。

### 新增 — 速度控制与静止判定（`ur_speedj` / `ur_speedl` / `ur_stopj` / `ur_stopl` / `ur_wait_steady`）

- `speedj(qd, a, t)` / `speedl(xd, a, t, aRot)` / `stopj(a)` / `stopl(a, aRot)` 按手册签名实现。
  `aRot` 省略时按手册语义走 `aRot='a'`（与 `a` 同值）。
- ⚠️ 速度指令是**开放式**的：手册说明 `t` 省略时"达到目标速度后函数返回"——**返回不等于停下**。
  因此工具返回值里明确写出"机械臂仍在运动，需要 stop*/wait_steady 收尾"，`t=0`（默认）时不会
  假装动作已经结束。
- `ur_wait_steady` 实现"等机器人静止"：**没有**用 URScript 的 `is_steady()`（手册 Poly5 16.39
  明确写着它在力控/示教模式下恒为 false，且它是表达式、需要额外一段程序+寄存器回读），
  改为轮询**已在 500 Hz RTDE 数据流里**的 `actual_TCP_speed` 与 `actual_qd`——零额外往返、
  在力控模式下同样给出真实判断。超时不报错，而是回报 `steady: false` 与当时的实测速度。

### 新增 — 目标值（`ur_get_target_values`）与 RTDE 配方扩展

- 新增读取"**控制器打算去哪**"：目标关节角/角速度/角加速度、目标 TCP 位姿/速度（并附带实际值
  便于对比）。这是判断"指令已下发但未执行 / 正在交融 / 被安全限速拉住 / 程序被取消"的直接依据。
- 实现方式是给 `URBasic/rtdeConfiguration.xml` 的接收配方补上
  `target_q` / `target_qd` / `target_qdd` / `target_TCP_pose` / `target_TCP_speed` 五个字段
  （74 → 79 个字段；UR 的上限是 96 个数据值，两个 `output_bit_registers*` 只算一个），
  并把 `RobotModel` 里对应的四个 `NotImplementedError` 桩（`TargetQ`/`TargetQD`/`TargetQDD`/
  `TargetTCPPose`/`TargetTCPSpeed`）改成真正读 RTDE 字段。
- 这比发 URScript 表达式再回读寄存器更可靠：零往返、不打断正在运行的程序、也不会因为
  表达式在旧固件上不存在而失败。

### 新增 — 工具端配置与遥测（4 个）

- `ur_set_tool_communication`：工具法兰串口（TCI / RS-485）开关，参数按手册
  `set_tool_communication(enabled, baud_rate, parity, stop_bits, rx_idle_chars, tx_idle_chars)`
  校验（波特率只允许手册列出的 8 档，parity 0-2，stop_bits 1-2，idle chars 按手册范围）。
  ⚠️ 工具描述里写明手册的警告：**启用 TCI 会禁用工具端模拟输入**。
- `ur_set_tool_output_mode`：工具输出模式 0 普通 / 1 power（双针供电）。
- `ur_set_payload_inertia`：一次性设置**质量 + 重心 + 惯性矩阵**（PolyScope 5.10 起的
  `set_target_payload`），按手册校验 Ixx/Iyy/Izz 非负、每个元素 |I| ≤ 133 kg·m²，
  并支持 `transition_time`。**只有在给出 `inertia` 时才使用 `set_target_payload`**；
  没给惯量时退回 `set_payload_mass` + `set_payload_cog`（CB3 3.x 上没有 `set_target_payload`，
  这样两条路径都能用）。工具描述里写明手册的提示：设置负载会**自动把力/力矩测量归零**，
  而 `set_payload(m, cog)` 会**重置**惯性矩阵（手册已将其标为 deprecated）。
- `ur_get_tool_telemetry`：工具输出电流/电压、I/O 电流（RTDE 字段，读取零代价）。
  手册里还有 `get_tool_temp()`，但当前配方没有对应 RTDE 字段，因此**不提供**该值，并在
  工具描述里说明原因，而不是编一个数出来。

### 修复 — 默认值与手册不符（`ur_movej` / `ur_movel`）

- **`ur_movel` 的默认速度是手册值的 4 倍**：旧代码 `movel` 默认 `a=1, v=1`，而手册
  （Poly5 15.30 / PolyScope X 15.29）是 `a=1.2, v=0.25`（250 mm/s）。对协作臂来说
  "没写速度"和"按 1 m/s 跑"是两件完全不同的事，现在改回手册默认值。
- **`ur_movej` 默认值同样不是手册值**（旧 `a=1, v=1`；手册是 `a=1.4, v=1.05`），一并改回。
- 工具描述里同时写明手册的另一条语义：**给了 `t` 就忽略 `a`/`v`**（手册原文 "Time setting has
  priority over speed and acceleration settings."），这是模型最容易搞错的一点。

### 修复 — `ur_movec` 缺少手册的 `mode` 参数

- 手册的 `movec(pose_via, pose_to, a, v, r, mode)`（Poly5 15.28）用 `mode` 选择姿态插补方式：
  `0` 从当前姿态插补到目标姿态，`1` 姿态相对圆弧**切线**保持不变（固定姿态圆弧）。
  旧实现根本不发这个参数，想做固定姿态圆弧只能绕开这个工具。现在补上并默认 0（与手册一致）。

### 新增 — OptiMove、Motion Version 与 freedrive 奇异点状态（`ur_move_optimized` / `ur_motion_version` / `ur_get_freedrive_status`）

- `ur_move_optimized` 暴露 `optimovej(goal, a=0.3, v=0.3, r=0)` / `optimovel(...)`
  （Poly5 15.32/15.33、PolyScope X 15.31/15.32）：目标与 `movej`/`movel` 相同，但用 **jerk 受限**
  的速度剖面，运动更平顺、振动更小。⚠️ 手册明确 `a`/`v` 是"**机器人能力的比例**"
  （`a, v ∈ (0, 1]`，1 = 该构型下能达到的最快），**不是 rad/s 或 m/s** —— 传 `a=1.4`
  （对 `movej` 完全合法的值）在这里就是越界，所以工具在本地校验范围并在描述里写明。
  手册支持的 `struct{pose, frame}` 与"世界模型对象名"两种 goal 形态**被明确拒绝**：
  它们需要 PolyScope 侧的坐标系/世界模型对象，脚本写错只会换来控制器一句运行期报错，
  不如在这里说清；`goal_type` 选择 `joints`（等价 optimovej）或 `pose`（等价 optimovel）。
- `ur_motion_version` 设置 **Motion Version**（手册第 14 章）与/或 **jerk 增益**
  （`jerk_gain_scaling_set`，0.01-1.0）：版本 2 在规划时把速度/加速度**钳到硬件上限**、
  交融半径重叠时**动态收缩**；版本 1 则会跳过整段运动并给 "Overlapping Blends" 警告。
  jerk 增益只作用于 **jerk 受限**的剖面 —— 版本 2 的 `movej`/`movel` 与 `optimovej`/`optimovel`，
  正是 `ur_move_optimized` 走的那条路。⚠️ 手册写明新机型与 PolyScope X **只支持版本 2**，
  CB3 没有这个设置。这两个设置**都没有回读通道**，工具只报告本次设置值（`readback_supported:
  false`），不假装读到了当前值。
- `ur_get_freedrive_status` 读取 `get_freedrive_status()`（PolyScope X 15.20）：当前姿态在
  freedrive 下离**奇异点**有多远 —— `0` 正常 / `1` 接近 / `2` 太接近（拖动阻力明显）。
  它**不是** freedrive 的开关状态位；手册的用意正在于"受限 freedrive 在奇异点附近可用性下降"，
  所以这个值用来建议操作员换一条路径。实现上经一个输出寄存器回读（默认 21 号 int 寄存器，
  旧值会被覆盖）；固件低于引入该函数的版本时，如实回报"没读到值"而不是编一个数。

### 修复 — `servoj` 的取值范围是 3.x 的旧值

- `t` 的默认值从 3.15.4 的 `0.008` 变成了 Poly5 15.44 / PolyScope X 15.43 的 `0.002`
  （手册推荐的"每个控制周期给一个新设定点"），`lookahead_time` 的下限也从 `0.03` 放宽到 `0.01`。
  工具保留 `0.008` 作为默认值（兼容 CB3），但现在**接受 `t ≥ 0.002`、`lookahead_time ≥ 0.01`**
  —— 照新手册传值的调用方不会再被一个过期的范围拦下。

### 修复 — `run-tests.mjs` 只认 `PYTHON` 不认 `UR_PYTHON`

- README 与 `test/selftest.test.mjs` 一直约定 `UR_PYTHON || PYTHON || 'python'`，而
  `scripts/run-tests.mjs` 的探针只读 `PYTHON` ⇒ `UR_PYTHON=... npm test` 会出现
  "探针说没有 Python、于是跳过全部 Python 用例，但被跳过的用例自己其实能跑"的矛盾结果。
  现在探针按 README 的约定取值。

### 工具链 / 文档

- 新增 `scripts/pdf-extract2.py`：**零依赖**（只用标准库）从三本手册 PDF 抽取文本。
  两个 PolyScope 手册的嵌入字体是**子集化的 CID Type0 字体**（`/Encoding /Identity-H`），
  PDF 里的字符码是 **glyph id**，必须走各自的 `ToUnicode` CMap 才能解出文字；3.15.4 则是普通的
  WinAnsi Type1 字体，字节即字符码。脚本两条路都走，并按基线/字距重建词间空格、剔除整页旋转的
  版权水印。抽取结果落在 `ScriptManual/txt/*.txt`（含页码分隔），是本版所有签名与默认值核对的依据。
- `docs/urscript-manual-analysis.md`：三本手册的函数签名、参数范围、版本差异（3.15.4 → Poly5 →
  PolyScope X 的新增 / 删除 / 改名 / 废弃）与安全限值事实，逐条带手册行号引用。
- 工具数门禁同步：`test/tool-schema-dsl.test.mjs` 与 `scripts/check-host-compat.mjs` 的
  `EXPECTED_TOOLS` 由 67 改为 83；README（中英）工具表、审批门禁清单、`67/67`→`83/83` 一并更新。

## [0.5.0] - 2026-09

> 本版是一次**以"还能不能信它"为主题的审计与加固**：一次代码审计发现并修掉了若干会让插件
> **永久卡死**、**回报假成功**、**读到别的命令的应答**的缺陷。工具数 53 → 67。

### 修复 — 会让插件永久卡死（最高优先级）

- **单次掉线会让整个 worker 永久死掉（`RealTimeClient.__sendPrg` 无界重试）**：上游的发送循环
  `while not stopRunningFlag and not programSend` **唯一出口是发送成功**。机器人掉线/断电时，
  `select.select([], [None], …)` 立刻抛 `TypeError` → 裸 `except` → `__connect()`（自身又循环
  60 s）→ **永不返回**。本插件是**单线程** worker（`for line in sys.stdin`），所以一次掉线就占死
  整条调用链：Node 侧 60 s 超时只让那**一个** promise 失败，进程还活着，此后**每一个**工具调用
  都会排队等到超时。现在发送有硬预算（`__sendTimeout`，默认 15 s），失败**如实**记入
  `lastSendFailure` 并逐层返回 `False`；同时 `lib/worker.js` 改为**超时即杀掉子进程**（并在下次
  调用时按 500 ms 退避拉起干净的 worker），因此调用方只需重试一次。
- **RTDE 接收线程会在 60 s 后"正常"退出，留下一个不再更新的连接**：`rtde.py` 的接收循环条件里
  混用了 `__reconnectTimeout`（那是"多久之内必须连上"的预算）当**运行期窗口**；到期后循环退出，
  退出前只发 PAUSE、**不关 socket** ⇒ `isRunning()` 依旧为 True（状态停在 PAUSED），数据却再也
  不更新。此后每次读取姿态都卡在 `dataEvent.wait()` 上。现在运行期用**独立的数据看门狗**
  （`__dataTimeout`，30 s 无任何 RTDE 包即重建会话），`__wait()` 带超时，`__receive()` 在 socket
  为 None 时直接返回而不是抛 `TypeError` 杀掉线程。**`dashboard.py` 有同族缺陷**：它的接收循环
  2 s 后退出且同样不关 socket，于是 2 s 之后每一条 dashboard 命令都会永久卡在 `wait_dbs()` 上，
  `wait_dbs()` 现在带超时（默认 2 s），循环只由 `__stop_event` 结束。
- **每次"读一次关节角"都可能永久自旋**：`urScript.sync()` 的
  `while RobotTimestamp() == initialRobotTime: sleep(0.001)` 与 `waitRobotIdleOrStopFlag()` 都没有
  出口。前者是所有 `get_actual_*` 的必经之路（默认 `wait=True`），后者被 `get_tool_digital_in` /
  `get_conveyor` 使用。两者现在都有超时并抛可读的 `TimeoutError`。
- **RTDE 线程在首次连接失败时当场死亡**：`rtde.py` 的 `__connect()` 在 `except` 里写的是
  `self.sock` —— 一个**不存在的属性**，于是失败时抛 `AttributeError` 冲出 `run()`：既看不到真实
  的 socket 错误，也不会像设计那样重试 60 s，`isRunning()` 永远为 False。改为 `self.__sock`
  （并加 try/except 关闭）。
- **`Dashboard.wait_dbs()` 无参无限等待**：现在必须带超时；`Dashboard.__send()` 也改为带超时等待
  应答。
- **`onLine` 静默丢弃**：`lib/worker.js` 现在统计无法解析的行与未知 id 的响应（`stats()`），
  并把这些线索保留下来——以前它们被完全吞掉，表现为"莫名其妙的超时"。
- **优雅关闭曾经完全没生效**：新增的"关闭控制器"工具与 host 的优雅关闭**撞了 op 名**
  （都是 `shutdown`），于是后者被解析成前者：既报 `KeyError: 'ip'`，又永远不会真的退出 worker。
  现在 host 用 `shutdown_worker`，并新增**跨语言契约测试**（host 的每个 op 必须在 Python
  `HANDLERS` 里存在、op 名不得与 dashboard 命令撞名）。这个缺陷是 `selftest.test.mjs` 端到端
  用例抓到的。

### 修复 — 回报了假成功 / 读到了错的东西

- **`ur_movec` 发的不是圆弧运动**：`UrScript.movec()` 内部把 `movetype` 写死成 `'p'`
  （`_move(movetype='p', …)`），`if movetype == 'c'` 分支永远不成立 ⇒ **`pose_via` 被完全丢弃、
  实际发出去的是 `movep`**（直线/交融运动），而工具回报的却是 `movec(p…, p…)`。即使把 movetype
  改成 `'c'`，那个分支拼出来的也是未替换的模板字面量。现在与 `op_draw_circle` 一样**自己拼原始
  URScript**。（已用真实 vendored 模块执行验证：旧路径确实产出 `movep(...)`。）
- **"移动到位"的判定不是朝向度量**：`_right_pose_tcp` 逐分量比较轴角表示的三个姿态分量，
  于是 `[0,0,2π]` 与 `[0,0,0]`（**同一姿态**）被判成相差 6.28，报出"移动结束但未到达目标"；
  而 `[0.05,0,0]` 与 `[0,0,0.05]`（**不同姿态**）却被判为到位。现在用夹角判据
  `θ = acos((tr(Rₐᵀ R_b) − 1)/2)`（0.05 rad 容差），位置仍用 10 mm 线性容差。
- **四个绘图操作无条件回报"执行完成"**：`_wait_robot_idle()` 在 `SendProgram()` 之后**立刻**问一次
  "在跑吗" —— 而 `SendProgram` 只是把字节写进 socket 就返回（真正的执行由控制器稍后开始），
  所以第一次探测几乎必然看到"没在运行"，于是无论脚本是否真的被执行都回报
  `ok: true`「执行完成」。现在必须**先观察到"确实在运行"**才接受"已空闲"，否则如实报告
  "未观察到脚本开始执行（控制器很可能根本没执行这段 URScript）"。
- **确认轮询读到的是上一条 dashboard 命令的应答**：`Dashboard.__send()` 只等"任意一次 notify"，
  **不校验应答属于哪条命令**，而 `last_respond` 只在真正收到消息时才被覆盖。最典型的事故：
  上一条 `isProgramSaved` 刚回过 "True"，紧接着问 `is in remote control`，于是一台**没在远程
  控制模式**的机器人被报成 `remote_control: true`，模型据此下发 URScript 并被控制器**静默丢弃**，
  而工具全程回报成功。新增 `Dashboard.sendCommand(cmd)`（先清空 `last_respond`，只认本次新到达的
  应答），worker 里所有 dashboard 读取统一经 `_dashboard_send()` / `_dashboard_cmd()`。
- **`ur_set_tool_voltage` 从来没有成功过**：它调用 `UrScript.set_tool_voltage()` —— 一个
  `NotImplementedError` 桩，因此**每一次**调用都必然抛异常并回报 `ok:false`。现在直接发
  `set_tool_voltage(N)` 的 URScript，并校验取值只能是 0/12/24。
- **`ur_set_analog_out` 的量纲错了**：URScript 的 `set_analog_out(n, f)` 收的是**相对电平
  f∈[0,1]**，而工具说明写的是"0-10 或 0-20"。旧实现把调用方的数字**原样**发过去 ⇒ `value=5`
  被当成 f=5 ⇒ 端口输出**满量程**（约 10 V），且完全不校验范围。现在接受工程单位（`full_scale`
  可指定 20 表示电流域），换算成 [0,1] 后发送并回读，返回值同时给出 `value` / `fraction` /
  `read_back`。
- **可配置数字输入的位掩码偏移了 8 位**：`RobotModel.ConfigurableInputBits(n)` 算的是
  `pow(2, n + 8)`，而 `actual_digital_input_bits` 的位分配是 0-7 标准 DI、8-15 可配置 DI、
  16-17 tool DI ⇒ `ur_get_digital_in(which="config", n=8)` 读到的其实是 **tool DI 0**，n=9 是
  **tool DI 1**，n≥10 永远为 False。输出侧（`ConfigurableOutputBits`）有同样的偏移。
  注意本插件自己的批量读取 `_bit_masks` 一直是对的，所以同一台机器人上两个工具会给出**互相矛盾**
  的结果。现在两处都按 `n - 8` 计算。
- **`RobotStatus()` / `SafetyStatus()` 在 RTDE 未就绪时抛 `TypeError`**：`1 & None` 会炸
  （`&` 比 `==` 结合得紧），而这个异常会从 `RealTimeClient.__waitForProgram2Finish` 里抛出并
  **杀死那个守护线程**，留下 `rtcProgramRunning = True` 永不复位，使
  `waitRobotIdleOrStopFlag()` 永久自旋。现在字段缺失时返回**全 False**（"状态未知"）。
- **`ActualJointVoltage()` 返回的是关节电流**：名字是电压，读的却是 `actual_current`（安培）。
  真正的 `actual_joint_voltage` 就在 RTDE 配方里却没有访问器。已修正，并补齐 `ActualCurrent()` /
  `ActualQD()` / `SpeedScaling()` / `StandardAnalogOutput(n)` 等一直接口齐全、数据也一直在 500 Hz
  流里、但上游是桩函数的访问器。
- **`ur_run_program` / `ur_stop_program` / `ur_pause_program` 不看应答**：dashboard 的
  "could not understand / not allowed / failed" 一类应答以前被当作成功；现在只回报"已下发"，
  并**同时给出运行状态**（`running`），让调用方有依据判断。
- **`ur_status` 里的 dashboard 字段可能整片陈旧**：现在每个字段都走"只认本次应答"的读取，
  读不到时明确标记 `<查询失败>` 而不是把旧值当成现值。
- **NaN / Infinity 曾经能一路走到控制器**：JSON 允许 `NaN`，`float("nan")` 也通得过所有校验，
  于是 `movel(p[nan,…])` 会被发出去；而在**返回**路径上，Python 默认把非有限值写成 `NaN` ——
  那不是合法 JSON，Node 的 `JSON.parse` 抛错后 `_onLine` 会**静默丢弃**那一行，调用方只看到
  一句笼统的 "timed out"。现在所有数值入口都拒绝非有限值，`respond()` 用 `allow_nan=False`
  大声失败。

### 新增 — UR 能力（14 个工具，53 → 67）

- **自由驱动 / 示教模式**：`ur_set_freedrive`、`ur_set_teach_mode`（可手动拖动机械臂；退出方式
  说明写在工具描述里）。实现走"永不退出的 URScript 程序"，正是 `freedrive_mode()` 语义所需，
  也避免 URBasic 包装函数在单线程 worker 里阻塞。
- **电源与刹车**：`ur_power_on`、`ur_power_off`、`ur_brake_release`，以及 `ur_shutdown`（关闭
  控制器）。全部带 ⚠️ 说明其物理后果（失去刚性、可能在重力下掉落）。
- **只解保护性停止**：`ur_unlock_protective_stop` —— 与 `ur_reset_error` 的区别是**不做上电、
  不释放刹车**（后者会顺带让机械臂动起来）；解除后会重新读取安全状态位一并返回。
- **实时遥测**：`ur_get_runtime_telemetry` 一次给出关节电流/电压/角速度、TCP 线速度与受力/力矩、
  工具加速度计、速度倍率、整机电压电流、关节温度。**这些字段本来就在 500 Hz 的 RTDE 数据流里**
  （见 `URBasic/rtdeConfiguration.xml`），读取零代价、不需要改配置，只是以前没有任何工具暴露它们。
  另有 `ur_get_speed_scaling`、`ur_get_tcp_force` 两个聚焦工具。
- **安装与 I/O 配置**：`ur_set_gravity`（非水平安装时的重力方向，含归一化与零向量拒绝）、
  `ur_zero_ftsensor`（力/力矩传感器归零）、`ur_get_tool_analog_in`（工具端模拟输入；函数名已对照
  仓库内官方脚本手册确认存在，但**参数语义未经真机验证**，读不到时说明可能原因并可换回读寄存器重试）。
- **传送带跟踪**：`ur_set_conveyor_tracking`（`linear` / `circular` / `stop`），此前只有 tick 计数
  的读写。

### 新增 — 数字孪生（面板与路由）

- **失败原因终于可见**：host 的失败响应新增机器可读的 `code`
  （`no_robot` / `robot_not_connected` / `ambiguous_robot` / `worker_unavailable` / `robot_error`），
  并回显本次解析到的 `ip`、歧义时的候选 `ips` 列表。此前客户端只渲染一句固定的「未连接机器人」，
  于是"worker 进程挂了"、"还没连过机器人"、"两台机器人有歧义"在界面上长得一模一样（而且歧义那种
  情况还会永远白轮询下去）。客户端现在把它们翻译成不同的人话与处置建议。
- **`detail=1` 慢通道**：附带 dashboard 侧的状态（安全模式、机器人模式、程序状态、运行状态、
  速度倍率、关节温度/电流等）。位姿通道仍以 10 Hz 独立轮询，detail 查询失败**不影响**位姿通道。
- **`/dsh-nonead-ur/twin/models` 模型清单**：列出本地真实存在的 GLB，让"机器人报了一个我们没有
  资产的型号"不再表现为静默回退。
- **资产缓存**：GLB 响应带内容哈希强 `ETag` + `immutable`，并支持 `If-None-Match` → 304。
  关闭面板会释放模型句柄，而以前没有任何校验器 ⇒ **每次展开面板都要重新下载并解析 1.5–3.5 MB**。
- **状态响应禁止缓存**（`Cache-Control: no-store`，客户端 `fetch(..., {cache:'no-store'})`）：
  缓存的位姿比没有位姿更糟。
- **模型名按 IP 记忆**：孪生的 10 Hz 轮询以前**每次都**去问一遍机器人型号（一次 Dashboard 往返），
  而型号在连接存续期间不可能变。现在 host 侧缓存，重连时失效。

### 修复 — 数字孪生客户端

- **每次展开面板泄漏一个 WebGL 上下文**：three 的 `renderer.dispose()` **不释放上下文**
  （只丢内部缓存并摘掉自己装的 context-lost 监听），而面板每次挂载都新建 canvas + renderer。
  浏览器上限约 16 个，反复展开/收起后会开始回收最老的 ⇒ 孪生面板或其它 WebGL 视图（例如任务看板）
  变黑。现在 `dispose()` 调 `renderer.forceContextLoss()`；同时释放从未被释放的 `GridHelper`
  几何体/材质，并监听 `webglcontextlost` / `webglcontextrestored` 以如实提示 GPU 重置。
- **HiDPI 屏上画面发虚**：从未调用 `setPixelRatio`（three 默认 1）。现在按 `devicePixelRatio`
  设置（上限 2）。另外新增 `ResizeObserver`：侧栏是用户可拖动改宽的，而 `window.resize` 不会因此
  触发，以前画布会被 CSS 拉伸到下次窗口变化为止。
- **画布尺寸量到 0×0 后永不重试**：面板刚展开时 flex 高度可能还没算出来，旧实现直接跳过并**不再**
  重试，于是那次之后画布一直用默认后备缓冲被 CSS 拉伸。现在记为待处理并逐帧重试。
- **WebGL 不可用时是"永久假加载 + 未处理异常"**：`new WebGLRenderer` 的异常发生在任何 try/catch
  之外，既变成未处理的 promise rejection，又让状态行永远停在「正在加载模型…」而画布空白。现在
  降级为**纯数值模式**（关节角与 TCP 仍更新）并说明原因。
- **轨迹缓冲被重复样本灌满**：`pushTrajectorySample()` 原本**每帧**都跑（60 fps），而采样只有
  10 Hz ⇒ 同一个 `ts` 被重复压入约 6 次，600 点的容量实际只装下约 100 个真样本（≈10 s 而不是
  文档里说的 60 s），且每帧重建约 600 个数组。现在只在新采样时入队，并加了回归测试。
- **数值面板给的是插值中间态**：关节行显示的是为网格平滑而算出的插值值，而 TCP 行用的是原始样本
  ⇒ 两行的时间基准不同（最多相差一个采样周期 + 渲染滞后）。现在两行都用**测量样本**（插值只服务
  于网格观感），并给出行内 `title` 以便读到被省略号截断的 J5/J6。
- **TCP 姿态被按 RPY 误导**：`rx/ry/rz` 是 UR 的**轴角旋转向量**（方向=旋转轴、模长=旋转角，弧度），
  不是 roll/pitch/yaw。HUD 现在明确标注 `TCP(米/轴角弧度)`。
- **状态行不随失败原因变化**：一直未连接时 `applyConnection` 直接 return，于是 host 的原因变了
  （例如从"还没连过"变成"worker 挂了"）界面也不更新。
- **在飞的取数无法取消**：`stop()` 只清定时器，已发出的请求仍会跑完（最长可拖到命令超时）。
  现在用 `AbortController` 取消，并区分"我们主动取消"（不写错误快照）与真实故障。

### 新增 — 工程质量

- **`npm test` 现在真的跑全部测试**（以前只跑一次 worker ping，仓库里另外 20 多个
  `*.test.mjs` —— 客户端轮询状态机、FK、模型契约、孪生路由、vendored 库缺陷 —— **一个都没跑**，
  所以"npm test 绿了"完全不能说明插件是好的）。新增 `scripts/run-tests.mjs` 枚举并逐个执行
  21 个测试文件，汇总成败；`test/selftest.mjs` 升级为真正的 `test/selftest.test.mjs`
  （端到端协议自检，含优雅关闭用例——**正是它抓到了上面那个 op 撞名缺陷**）。
- **`test/vendored-fixes.test.mjs` + `test/ur-python-harness.py`**：把本版修掉的 vendored 缺陷
  逐条钉成**行为**门禁（不是"源码里有没有那段代码"）。探针刻意用**真实的回环 socket** 而不是假
  对象：`__sendPrg` 内部要过 `select.select`，而 select 只接受真 fd —— 假对象会直接抛
  "argument must be an int"，反而绕过了被测路径。
- **`test/tool-schema-dsl.test.mjs` 增加跨语言契约**：host 侧的每个 op 必须在 Python `HANDLERS`
  里真实存在；op 名不得与 dashboard 命令撞名；同一 op 不得被多个工具使用；工具名不得重复。
- **删除死代码**：`src/client/sidebar-entry.js` 与 `src/client/thumbnail.js` 早已不被构建图引用
  （CHANGELOG 0.4.1 就写了"已删除"，但文件与它们的测试还在，让覆盖率看起来比实际好）。
- **`scripts/build-client.mjs` 改为优先使用独立 esbuild 二进制**：JS API 会在启动时校验
  JS 包与平台二进制**版本一致**，而本仓库 `node_modules` 里两者不同步（JS 0.25.12 / 二进制
  0.25.0）⇒ `Cannot start service`，构建直接失败。独立二进制不需要版本配对，banner/footer 用
  内联文本传入（CLI 的 `--banner:js=` 收的是文本，不是文件路径），JS API 仍作为回退。
- **`scripts/check-host-compat.mjs` 优先探测真实的 DSH 安装目录**：本仓库自己的
  `node_modules` 里也有（devDependency 带进来的）旧版 `@deepseek-ai/dsh-tools`，用它去校验 DSL
  与 peer 版本会得到误导性结论。现在命中真实安装时，**67/67 个工具通过宿主真实 DSL**。
  期望值（工具数、路由数）一并更新为 67 / 3。

### 变更

- **有物理后果的新工具全部纳入人工审批**：`set_freedrive` / `set_teach_mode` / `power_on` /
  `power_off` / `brake_release` / `unlock_protective_stop` / `shutdown` / `zero_ftsensor` /
  `conveyor_tracking` —— 它们都能让机械臂脱离程序控制或失去刚性支撑。
- **所有长耗时操作的预算留出余量**（`_budget_ms`）：Node 侧的超时计时从写入请求就开始了，两者
  相等时调用方只会看到 Node 那句笼统的 "timed out"，看不到 worker 更具体的原因。
- **发送失败不再算成功**：`op_send_script` / 四个绘图操作 / 数字与模拟输出 / `set_tcp` /
  `set_payload` 等现在都检查"脚本是否真的送出去了"，失败回报 `SEND_FAILED` 并附原因。
- **`_CappedLog` 线程安全**：RTDE / Dashboard / RealTime 的接收线程都会直接 print，而一次
  `_roll()` 可能正好在另一个线程的 `write()` 中间关掉句柄 ⇒ 那个线程抛 `ValueError` 当场死亡
  （RTDE 线程一死，`isRunning()` 就永远为 False）。
- **未处理异常的完整栈写入日志**：`traceback.format_exc(limit=1)` 只留最后一帧，库里抛出的
  `AttributeError` 因此丢掉全部上下文；协议行改为一句可读摘要 + 稳定错误码。

### 已知事项（如实标注）

- **工具端 I/O 与模拟输出回读用了手册里不存在的函数名（静默失效，不是少个功能）**：仓库内有 UR 官方
  脚本手册（`ScriptManual/script_directory_Poly5.pdf`、`..._PolyscopeX.pdf`），逐一核对后发现 vendored
  代码里有**三个名字在手册中根本不存在**：
  - `get_tool_digital_in()` 发的是 `write_output_int_register(0, read_tool_digital_in(n))` ——
    两个名字都不存在（手册里是 `write_output_integer_register` 与 `get_tool_digital_in`）。
    控制器会拒收整段脚本，而函数随后**回读寄存器 0 的陈旧值并把它当成输入电平报出去**。
  - `set_tool_digital_out()` 发的是 `write_tool_digital_out(n, value)` —— 手册里是
    `set_tool_digital_out(n, b)`。后果是**数字输出从来没被设置过，工具却回报成功**。
  - `get_standard_analog_out()` 读的是 `RobotModel.StandardAnalogOutput0` / `...1` ——
    **这两个属性都不存在**，必然抛 `AttributeError`；而且 `n == 1` 分支把 `return` 写在了
    `if wait:` 里面，`wait=False` 时返回 `None`。
  三处全部改为手册中的真名。顺带发现 `get_tool_digital_out` 在手册里确实存在，因此"工具数字输出无法
  回读"这个结论不成立，已实现回读。
- `scripts/twin-contiguity-check.py`（原仓库根目录的 `.twin-contiguity-check.py`）的链式乘法顺序错了：
  它把 DH 段矩阵写成 `R·Trans`，而真实渲染（`src/client/robot/fk.js` 的 `poseToMatrix4()` =
  URDF `<origin>` 语义）是 **`Trans·R`**。两者在 `links[4]`/`links[5]`（rpy 与 xyz 同时非零）上
  相差约 **0.18 m** —— 也就是说这个脚本报出的 PASS/FAIL 与客户端实际画面无关。已改为 `Trans·R`
  并移入 `scripts/`（仓库根目录的隐藏脚本容易被误认为项目配置）。
- `python/sitecustomize.py` 是**本机私货**（写死了本机 Python 用户级 site-packages 路径），
  它之所以能生效是因为 `lib/worker.js` 把 `PYTHONPATH` 指向插件的 `python/` 目录，而 CPython 启动
  时会 import 该目录下的 `sitecustomize`。**换一台机器、或安装发布版（该文件不在 `files` 清单里）
  之后，`import numpy` 会失败，所有工具调用都会死。** 正确做法是给 worker 用的解释器装好依赖
  （`pip install -r requirements.txt`）或用 `pythonBin` 指向一个 venv；`ur_ping` /
  `--selfcheck` 是这条链路的自检入口。本版**未删除**该文件（它属于使用者的本地环境），
  但已在此明确记录。
- `ur_get_tool_analog_in` 与 `conveyor_tracking`（脚本函数名与参数语义）**未经真机验证**：
  函数名已对照仓库内官方手册确认存在，但**参数语义与真机行为**未在 URSim/真机上跑过。
  两者在读不到/失败时都会**如实报失败**并列出可能原因，而不是返回陈旧值或假装成功。
  请在 URSim 或真机上先验证再用于生产。
- `assets/kinematics.json` 中 `ur3`/`ur3e` 的 `jointLimits[5]` 为 `null`，因此这两个型号暂时做不了
  J6 限位提示（需要新的数据来源）。

## [0.4.1] - 2026-09

### 变更
- **删除不再装配的左栏/中栏模块**：`sidebar-entry.js`（左栏入口行 + 中栏大视图 + `dsh-panel-activate` 协议）与 `thumbnail.js`（缩略 3D）随「只在右栏呈现」一并删除；仍在用的变更自愈 hub 独立为 `mutation-hub.js`（行为未变，全局单例语义保持）。
- **数字孪生的呈现位置迁到右侧栏**：入口改为右侧栏「开始」面板里的一张卡片，位于「工作区文件 / 新建终端 / 浏览器」三张卡片下面；点击后在右侧栏内显示 3D 视图。原先的左栏入口行与缩略视图、覆盖中栏的大视图不再使用。

### 修复
- **`ur_send_script` 的执行校验会假报成功（比不校验更糟：它伪造证据）**：第一版把哨兵拼在**顶层**（`<起> + 脚本 + <止>`）。真机实测：`def dance(): … end` + 顶层调用这种脚本被拼上顶层哨兵后，会变成「**函数体一句都不跑、顶层语句照跑**」的形态——DO3 从不置位，而两行哨兵都回读成功，工具报出「已执行完毕 0.0 s」。现在**含 `def` 的脚本一律把哨兵注入函数体内部**（第一句 / 最后一句，块用深度计数配对，函数体里嵌套的 if/while 不会认错 `end`），**绝不拼顶层**；多个函数又看不出顶层调用哪个时**拒绝校验**（脚本原样发送，`verified: null`，并说明原因）。纯语句脚本（插件自身 movej/movel 的形态）才用顶层注入——那种形态下顶层语句本来就会执行。返回值新增 `injection`（`mode` / `function` / 行号）以便复核注入位置。回归测试用假控制器复现"只跑顶层、不跑函数体"的语义，并对照出旧形状必然假阳性。
- **`ur_send_script` 会谎报成功**：`RealTimeClient.SendProgram()` 是单向的（控制器既不给 ACK，也不回传 URScript 运行期错误），原实现只回一句「脚本程序已发送，请确认执行结果」——模型据此以为动作生效了，而真机上完全可能**一行都没执行**（本地/示教器模式下 URScript 会被设计性地静默丢弃，或脚本在控制器侧报错中止；实测就是这样：位置一动不动，工具却报"已发送"）。现在会在脚本前后各注入一行 `write_output_integer_register(N, token)` 并回读该寄存器，结论分三种：**跑完** / **开始跑了但没跑到末尾** / **连起始哨兵都没出现（≈控制器根本没执行，并点明最常见原因）**。`verified` 为 `true`/`false`；`verify=false` 时为 `null`——那表示"未确认"，不等于成功。默认用 23 号 int 输出寄存器当哨兵（可用 `register` 参数改，注意其旧值会被覆盖）。
- **`remote_control` 探测三态化**：原实现把"没问到"与"问到了，是 false"折叠成同一个 `false`，于是工具会对着状态未知的机器人给出「请去 PolyScope 开启 Remote Control」——那是**基于未知信息的断言**。现在 `_remote_control()` 返回 `True` / `False` / `None`（未知）：`ur_connect` 只在明确 false 时才提这件事（CB3 3.1–3.20 区间说明"设置在默认已启用、但当前不在远程模式时指令仍会被丢弃"），未知时如实说未知；`ur_status` 额外给出 `remote_control_raw` 便于诊断。
- **清掉配方里已失效的输入段**：`rtdeConfiguration.xml` 现在只声明 `receive`（接收配方），`<send>` 段整段删除——写操作全走 URScript，不需要认领输入变量；而上游重连分支**每次重连**都会调 `__setupInput()`，留着非空输入配方会把这个「参数已被认领」的拒绝打成循环（该拒绝会从 `__decodePayload` 冒出来打崩整个 worker）。空配方下它只是一个空请求。
- **连上机器人却黑屏（孪生拿不到 model/q/tcp）**：`lib/twin-routes.js` 按**单层**读 op 结果（`jp.joint_positions`），而真实信封是两层——协议响应是 `{id, ok, data:<op 返回值>}`，每个 op 自己又返回 `{message, data:{…}}`（`ur_worker.py` 的 `ok()` **原样**返回传入的 dict），而 `UrWorker.call()` resolve 的是响应里的 `data` ⇒ 真正的载荷在**再下一层** `.data`。于是 `model`/`q`/`tcp` 恒为空：无论机器人是否连上，孪生面板都只有黑屏，姿态自然也无从同步。路由已改为读 `.data`；`test/twin-routes.test.mjs` 的假 worker 同步改成**真实信封形状**（它此前造的是扁平对象，所以这个缺陷长期全绿），并新增一条反向守卫（扁平返回值不得被当成数据）。
- **worker 日志无限增长 + RTDE 重连紧凑循环**：`rtde.py` 的重连失败分支每次循环都打印且**不 sleep**，断链时等于每秒数万行；实测本机 `python/ur_worker.log` 被推到 **277 MB / 1076 万行**（其中 `RTDE reconnection failed!` 独占 1076 万行）并空转烧 CPU。现在该分支限速到**每 5 s 一行**并 `time.sleep(0.5)`；`ur_worker.py` 再加一道与写入者无关的硬上限：日志超过 8 MB 即滚成 `ur_worker.log.1`（只保留一代 ⇒ 磁盘占用钳在 ~2×上限）。**同一族缺陷还有第二处**：`dashboard.py` 的 `DashboardClient.__send` 在 socket 已死时 `select.select` 会立刻抛，而 except 里无条件 `print("Could not send program!")` —— 实测**同一个会话刷出 296,644 行**并把日志顶到 8 MB 上限、持续空转烧 CPU；已同样改为每 5 s 一行 + `time.sleep(0.2)`。另外，正因为插件配方的输入侧为空，这个**每次重连都会走到 `__setupInput()`** 的分支才不会反复认领输入变量（否则会踩上游那个「参数已被认领」的崩溃）。
- **世界坐标系与基座坐标系对齐**：`GridHelper` 默认躺在 XZ 面（three.js 习惯的 Y 向上，法线 +Y），而机器人的连杆姿态是 FK 直接算出的**基座系**坐标（基座平面是 XY 面、Z 向上）——两者平面不同、三条轴也不重合，表现为「网格像一堵竖墙、基座从网格里穿出来」。现在网格绕 X 轴转 +90° 落在 **XY 面（z=0）**、`camera.up` 设为 **+Z**，于是**基座平面与网格平面重合、基座 X/Y/Z 与世界 X/Y/Z 重合**（`scene.js` 的 `createBaseGrid()`）。
- **CB3 不再被误导去开启 Remote Control**：`ur_connect` 原先只要 dashboard 报 `false` 就提示「未处于远程控制模式，部分运动指令可能无法执行」。但 **URSoftware 3.1–3.20 的 CB3 机器人默认就允许远程控制、无需任何设置**，那条提示对这一档固件是错误指引。现在按 `polyscopeVersion` 分档：落在该区间就说明「设置在默认已启用（无需在设置里开启）」，**并指出 dashboard 报 false 时控制器当前不在远程模式、指令仍会被静默丢弃**；其他固件（e-Series 或区间外的 CB3）才提示去 PolyScope 开启。（措辞随后又按真机观察校准过：见上文三态化那条。）
- **连接构造卡死不再需要人工重启**：`UrScriptExt(...)` 的构造会等 RTDE 数据就绪（`urScript.py` 里 20×1 s），再叠加 rtde / realTimeClient 各自最长 60 s 的重连循环；一旦控制器侧还占着上一次未回收的 RTDE 会话（控制器同时只接受一个客户端），构造就可能几十秒不返回、后续每次调用都跟着卡住。现在 `ur_worker.py` 的 `_connect_or_exit()` 给构造一个硬预算（`CONNECT_TIMEOUT_S = 20 s`，且不超过本次请求的 `_timeout_ms`），超预算就写回一条说明原因的错误并 `os._exit(1)` —— 只有进程退出能可靠释放那些半成品套接字。`lib/worker.js` 已有的行为接管后半程：退出即失败在飞请求，**下次调用**按 500 ms 退避拉起干净进程，调用方重试一次即可。
- **发布包不再夹带 `python/sitecustomize.py`**：该文件是某台机器上的解释器垫片（硬编码本机路径），插件自己的 `files` 已刻意不含它，但两版桌面打包是整目录收 `python/**`。两版 electron-builder 的 `files` 现在显式排除它。
- **数字孪生的关节位置全错**（真机 UR3 上肉眼可见：连杆散开、不在关节上）：`loader.js` 的 `assemble()` 把 7 个装配组串成父子链，而 `applyFK()` 往每个组的**局部** `matrix` 写的是「基座 → 该连杆」的**绝对**变换 ⇒ three.js 的 `matrixWorld` 把父链连乘，肩部之后的每个连杆都被重复施加了前人变换。每个网格的几何本来就写在**它自己的连杆坐标系**里（Ruling 37 已把官方 `ur_macro.xacro` 的 visual origin 烘进网格），所以 6 个连杆组现在都是运动根（单位矩阵）的**直接子节点**。实测 14 个型号 × 3 个姿态下相邻连杆最大间隙 0–1.3 mm（阈值 40–108 mm）。
- **`rtde.py` 的 `self.hasattr` 笔误**：`setData()` 的列表分支写成 `self.hasattr(self.__rtde_input_config.names, ...)`——`RTDE` 没有这个方法，且对列表来说 `hasattr` 也不成立。已改为与标量分支同语义的 `variable_name[ii] in self.__rtde_input_config.names`。
- **所有 RTDE 写操作都会崩**（`ur_set_digital_out` 等在真机上直接抛 `AttributeError: 'NoneType' object has no attribute 'names'`）：根因是插件此前经 `RTDE.setData()` 写输出，而这条路要求先向控制器**认领 RTDE 输入变量**——`rtde.py` 的 `__setupInput()` 是**被注释掉的上游代码**，从不发 SETUP_INPUTS，`__rtde_input_config` 因此恒为 None。**修法是让写操作改走 URScript**（`RealTimeClient.Send("set_standard_digital_out(...)")` 等，与 tool / analog / payload / TCP 的既有做法一致），从此不需要任何 RTDE 输入认领。之所以必须避开输入认领：UR 控制器会拒绝为已认领的变量再发 SETUP_INPUTS（`An input parameter is already in use.`），该异常会从 `__decodePayload` 冒到 RTDE 线程里**打崩整个 worker**，之后除非控制器释放认领，会话无法重建。（曾试过「补输入配方 + 放开 `__setupInput()`」，已被这条更干净的路径取代。）
- **插件自带的 RTDE 配方只服务接收侧、输入侧故意留空**：`python/URBasic/rtdeConfiguration.xml`（`rtde.py` 优先解析它，vendored Default 仅作回退）保留 int/double 寄存器 0..23 并启用 `output_bit_registers32_to_63`；`<send>` 段**零字段**，确保任何 SETUP_INPUTS（含上游重连分支里那次调用）都不会认领输入变量。
- **`ur_get_bit_register` 读 32–63 恒为 null**：接收配方只启用了 `output_bit_registers0_to_31`，而 `RobotModel.OutputBitRegister()` 仅在该字段存在时才填充 32–63。新配方已启用 `output_bit_registers32_to_63`。
- **`ur_set_digital_out` 的 `which="config"` 在 8–15 端口抛 `struct.error`**：URBasic 内部按 0–7 给 8 路 configurable 输出编号（掩码算的是 `2 ** n`），而工具沿用 UR 的全局 I/O 编号 8–15，`n = 8` 会算出 256（`'B' format requires 0 <= number <= 255`）。现在换算成 URBasic 的编号再调用。
- **`ur_list_programs` 拿不到结果**：局部变量 `err` 遮蔽了模块级 `err()` 辅助函数，出错分支等于把一个字符串当函数调用。
- **客户端半此前完全无法激活**：`resolveRobotIp()` 曾读取 `ctx.config` / `ctx.options`，而 cordis 的上下文代理对未通过 `inject` 声明的属性读取会抛 `cannot get property "config" without inject`。该读取发生在 `apply()` 的 `try` 之外，导致该 entry 的 fiber 落为 FAILED、渲染侧只报「1 plugin(s) 未激活」且不给原因。配置现取自 `apply(ctx, config)` 的第二实参。

## [0.4.0] - 2026-09

### 修复
- **注册结果如实上报**：`apply()` 现在统计 `ctx.tools.register` 的实际成功数，并把每个失败工具连同原因列出，不再打印硬编码的工具总数——部分注册失败再也无法在日志里显得“正常”。全部失败时会区分三种原因：worker 初始化失败、宿主未组合 `tools` 服务、宿主 `ctx.tools.register` API 已变更。
- **peer 范围接受当前内核**：`@deepseek-ai/dsh` 与 `@deepseek-ai/dsh-tools` 声明为 `^0.1.2-rc.1 || ^0.1.7-rc.2`。原 `^0.1.2-rc.1` 不匹配 `0.1.7-rc.2`（预发布范围只匹配自身版本三元组），严格 peer 校验会拒绝本插件实际适配的内核。

### 新增
- **`scripts/check-host-compat.mjs`**：一条命令完成对已安装宿主的兼容自检——peer 范围、全部工具参数 schema 过一遍宿主**真实**的 value-schema DSL、`dsh.client` 声明、以及客户端 bundle 的注册 id。升级所适配的内核族后应重跑。
- **只读 3D 数字孪生**：侧边栏缩略视图 + 中栏大视图（three.js 渲染），两者共用同一份轮询状态源，实时同步机器人的关节姿态、工具（TCP）坐标系与近期运动轨迹。数字孪生严格只读，绝不下发任何机器人指令。
- **host 只读孪生路由**：`/dsh-nonead-ur/twin/state` 与 `/dsh-nonead-ur/twin/asset`，均限定 loopback（`localhost` / `[::1]` / `127.0.0.0/8`）调用方。
- **随包分发机器人网格**：14 款 UR 官方视觉网格转换为 `assets/models/*.glb`（约 35 MB）随包分发，并附 `assets/kinematics.json`；许可划分见 `THIRD_PARTY_NOTICES.md`（9 款 BSD-3-Clause、5 款 UR Graphical Documentation）。`assets` 已列入发布 `files`，并新增 `verify:models` 脚本校验 GLB 结构契约。
- **`three` 作为构建期依赖**（`devDependencies`），供 `scripts/build-client.mjs` 构建客户端 bundle。

## [0.3.9] - 2026-09

### 修复
- **16 个工具在 DSH 1.5.3 下消失**：工具参数 schema 使用了 JSON-Schema 的数值约束（`minimum` / `maximum` / `exclusiveMinimum`），而值 schema DSL 不再接受这些关键字，导致受影响工具**整个注册失败**；且收尾那行打印的是硬编码的 `已注册 49 个`，失败是静默的。在仍拒绝这些关键字的宿主上重新实测：仅 **33/49** 个工具注册成功、**16** 个注册失败（`ur_movej`、`ur_movel`、`ur_movep`、`ur_movec`、`ur_servoj`、`ur_draw_*` 以及寄存器 / I/O 类工具）。现约束已移除，范围写进工具 description，权威校验在 `python/ur_worker.py`（`_nonneg_float` / `_bounded_int` / `_bounded_float`）。

### 新增
- **`test/tool-schema-dsl.test.mjs`**：驱动真实的 `apply()`、捕获真实注册的工具定义，逐条校验参数 schema 是否落在值 schema DSL 词表内，并断言 49 个工具全部注册；测试自带自检，证明它并非空转。

## [0.3.8] - 2026-09

### 变更
- **统一远程控制探测**：抽取 `_remote_control(d)` 公共函数，`op_connect` / `op_status` / `op_get_robot_model` 三处共用一个判定（只有精确的 `"true"` 视为远程；类错误响应或探测失败视为非远程），消除三份手写重复逻辑。
- **描述同步**：`ur_get_robot_model` 的描述补充说明其返回的 `remote_control` 字段。

## [0.3.7] - 2026-09

### 修复
- **worker.js 中止计时器清理**：`call()` 的 `onAbort` 现在 `clearTimeout`，已中止的请求不再遗留一个在超时后触发的空 reject（轻微资源泄漏/不干净）。
- **`op_status` 读取失败可辨**：`dash()` 查询失败时返回 `"<查询失败>"` 标记，而非空字符串——避免把"无法读取某字段"误当"字段为空"。

## [0.3.6] - 2026-09

### 健全性
- **运动/绘图参数范围校验**：新增 `_nonneg_float` 校验，拒绝负值/零值运动与绘图参数（控制器会把负速度/负加速度/反向几何当作异常）：
  - `movej` / `movel` / `movep` / `movec`：`a`（加速度）、`v`（速度）须 >0；`t`（时长）、`r`（交融半径）>=0。
  - `draw_circle` / `draw_square` / `draw_rectangle` / `draw_star`：`r` / `border` / `width` / `height` / `side` 须 >0。
  - `servoj`：`lookahead_time` 0.03-0.2、`gain` 100-2000、`t`>=0。
- **工具定义 schema 约束**：为 `MOVE_PARAMS`、`movep`/`movec`、`servoj`、`draw_*` 的参数加 `minimum`/`exclusiveMinimum` 约束，让模型在调用前即看到限制。

## [0.3.5] - 2026-09

### 修复
- **vendored URBasic 运算符优先级**：`RobotModel` 的 `DigitalInputbits` / `ConfigurableInputBits` / `DigitalOutputBits` / `ConfigurableOutputBits` 里 `n >= 0 & n < 8` 被 Python 解析为链式比较，导致 n=8/15 越界时错误返回 True。改为 `0 <= n < 8`（及 `8 <= n < 16`），越界正确返回 None。
- **`urScriptExt.get_in` 签名不匹配**：`BCI` 分支调用 `get_configurable_digital_in` 时多传了 `wait` 参数（该方法只接受 `n`），去除后不再抛 `TypeError`。
- **`urScriptExt.set_output` 空分支**：`BCO`/`BDO` 补 `return True`；`TDO`（工具数字输出）改为调用已实现的 `set_tool_digital_out`；`BAO`（模拟输出）明确抛 `NotImplementedError`（不再静默 pass）。
- **`_right_pose_tcp` 只比较前 3 维**：到位确认改为比较**完整 6 维**位姿（位置 + 姿态），位置容差 0.010m、姿态容差 0.05rad，避免姿态偏差被误判为已到位。
- **`ur_set_analog_out` 崩溃**：原调用 URBasic 桩 `set_standard_analog_out`（`NotImplementedError`）会崩溃，改为直接发送 URScript `set_analog_out` 命令。
- **`_program_running` 连接断开容错**：dashboard 探测失败不再使单线程 worker 崩溃（返回 False，确认循环给出清晰结果）。

### 健全性
- **参数范围校验**：新增 `_bounded_int`，对寄存器（int/double 0-23、bool 0-63）与数字/模拟口（std 0-7、config 8-15、tool 0-1、模拟 0-1）做 worker 端校验；并在工具定义（index.js）为 `index`/`n` 加 JSON-schema 的 `minimum`/`maximum` 约束。越界或非整数返回清晰错误，而非 KeyError。
- 清理未跟踪的 `debug.log` 与 `Release/*.tgz`。

## [0.3.4] - 2026-09

### 修复
- **`ur_get_digital_in` 的 `which="std"` 读取崩溃**：修复 vendored URBasic 的方法名大小写错误——`get_standard_digital_in` 调用的是不存在的 `RobotModel.DigitalInputBits`（大写 B，触发 `AttributeError`），而实际定义为 `DigitalInputbits`（小写 b）。改为匹配定义后，读取标准数字输入恢复正常。该问题在真机 UR3 上发现。

## [0.3.3] - 2026-09

### 新增
- **工具端数字 IO**：在 vendored URBasic 的真实实现基础上，新增并接通 `ur_get_digital_in` / `ur_set_digital_out` 的 `which="tool"` 分支：
  - `get_tool_digital_in`：工具端数字输入不经 RTDE，通过 URScript `read_tool_digital_in(n)`（`SendProgram`）把结果写入 `output_int_register_0`，再经 RTDE 读回（与 `get_conveyor_tick_count` 同模式）。已在真机 UR3 上验证，能正确读取布尔值。
  - `set_tool_digital_out`：经 RealTime 客户端发送 URScript 命令 `write_tool_digital_out(n, v)` 设置工具端数字输出。已在真机 UR3 上验证，set/clear 均被接受。
  - `get_tool_digital_out`：仍为桩并附说明（工具数字输出无可靠的 `read_tool_digital_out` 回读表达式），仅可通过 `set_tool_digital_out` 控制。

### 变更
- `ur_get_digital_in` 的工具描述补充说明：`which="tool"` 读取经由 URScript 发送短程序，可能打断正在运行的程序。
- 此前的 `which="tool"` 分支由"返回未实现提示"改为调用真实实现。

## [0.3.2] - 2026-09

### 修复
- **传送带 tick 读取崩溃**：`ur_get_conveyor` 读取传送带 tick 时，`get_conveyor_tick_count()` 修复两处 vendored URBasic 缺陷——URScript 改用 `write_output_double_register(0, …)`（此前用 `write_output_float_register`，但 RTDE 配置只暴露 `output_double_register_0`，float 值读不进来，会一直返回 0）；Python 侧改用 `RobotModel.OutputDoubleRegister(0)` 读取（此前用不存在的**小写属性** `outputDoubleRegister[0]`，触发 `AttributeError: 'RobotModel' object has no attribute 'outputDoubleRegister'`）。
- **`ur_get_robot_model` 型号污染**：此前的远程控制探测复用 `d.last_respond`，会覆盖型号字符串，且在探测成功时给型号硬拼接一个 `"e"`（如 `UR5` → `UR5e`）。现在 `robot_model` 返回纯净型号，远程控制状态另以 `remote_control` 字段返回，不再污染。
- **运动确认语义**：`_movej_confirm` / `_movel_confirm` 在机器人多次偏移且非程序运行态时，改为如实返回**未到位（`ok=False`）**，此前会谎报为成功送回「移动结束（位置存在偏差）」；读取关节/TCP 位置失败也改为明确报错，而非静默 `break`。
- **`ur_list_programs` 连接报错**：SSH 连接失败现返回清晰中文错误（提示检查 SSH 服务与 username/password），此前会抛原始异常并误报「共 0 个」。

### 健全性
- **向量参数校验**：新增 `_vec` 辅助函数，对 `movej`/`movel`/`move_x|y|z`/`draw_circle|square|rectangle|star`/`set_tcp`/`set_payload`/`movep`/`movec`/`servoj` 的关节/位姿向量统一校验**维度**（长度不足、非数值、缺失均返回明确错误），避免生成畸形 URScript 或越界索引。
- **worker 崩溃退避**：`worker.js` 实现 `restartDelayMs` 崩溃退避（此前字段已定义但从未使用），避免 worker 启动即崩时形成 tight crash loop。
- **worker spawn/exit 竞态**：`call()` 写入前区分「可写 / 不可写 / 进程已退」三种状态并分别清晰报错，不再静默丢弃请求。

## [0.3.1] - (2026-09)

### 修复
- **安全**：`ur_load_program` 纳入运动审批门禁（`APPROVAL_OPS`），并对 `program_name` / `programs_dir` 做白名单校验（拒绝控制字符与 shell/URScript 元字符），封堵「`load <file>\nplay` 注入绕过人工批准」的绕过路径。
- **安全**：`ur_list_programs` 的 `programs_dir` 经 `shlex.quote` 参数化后再进 `find`，消除经 SSH 的远程 shell 注入。
- **可用性**：移除会固定返回 `NotImplementedError` 的 `ur_get_inverse_kin`（URBasic 基类为空实现）；重写 `ur_set_payload` 为直接发送 `set_payload_mass` / `set_payload_cog` URScript（此前同样命中空桩）。
- **健壮性**：JS 侧把 `_timeout_ms` 传给 worker，Python 的 `_movej_confirm` / `_movel_confirm` / draw 完成确认改为**有界超时**，避免单线程 worker 被永不返回的运动循环永久卡死。
- **行为**：`ur_draw_*` 返回前做有界完成确认，不再提前报「已发送」；`ur_get_digital_in` 的 `which="tool"`（URBasic 未实现）改为明确报错提示改用 `std`/`config`。

### 变更
- 工具数由 50 减为 49（移除 `ur_get_inverse_kin`）。

## [0.3.0] - 2026-09

### 新增
- **更多工具**：
  - `ur_movep`（路径移动）、`ur_movec`（圆弧移动）、`ur_servoj`（连续流关节目标，在线控制单步）。
  - `ur_get_digital_in_bits` / `ur_get_digital_out_bits`（**批量**读数字输入/输出位，std0-7+config8-15）。
  - `ur_get_conveyor` / `ur_set_conveyor_tick`（传送带 tick 读取/设置）。

### 变更
- 补全发布元数据：`repository`（Nonead GitHub）、`bugs`。

## [0.2.0] - 2026-09

### 变更
- 插件改名为 `dsh-nonead-universal-robots`（全小写，可 npm 发布），声明宿主要求 `DSH ^0.1.2-rc.1`（`peerDependencies`）。
- 插件简介：一个让 DSH 用自然语言直接控制 Universal Robots（UR）机械臂的插件，由拓德科技（Nonead）基于自研的 nUR MCP Server 同源逻辑开发。

### 新增
- **运动审批门禁**：`ur_movej/ur_movel/ur_move_x|y|z/ur_draw_*/ur_run_program/ur_send_script/ur_reset_error` 会先走 DSH 审批通道（`ctx.approval`），人工确认后才下发；无审批服务/无 agent 时 fail-closed。可用 `requireApprovalForMotion` 关闭。
- **更多工具**：`ur_ping`（健康检查）、`ur_get_digital_in`/`ur_set_digital_out`、`ur_get_analog_in`/`ur_set_analog_out`、`ur_set_tool_voltage`、`ur_set_tcp`、`ur_set_payload`、`ur_get_inverse_kin`、`ur_draw_star`（五角星）。
- **URSim 兼容**：`ur_list_programs` 支持真机 `/programs` 与 URSim `~/URSim_Linux-*/programs.*`，`ur_load_program`/`ur_run_program` 支持完整/URSim 路径与 `programs_dir`。
- **测试**：worker `--selfcheck` 模式与 `npm test`/`npm run test:python`。

### 修复
- 修复 URBasic/RTDE 返回 **numpy 数据无法 JSON 序列化**的问题（worker 的 `_json_default` 递归转换）。
- 修复**中文 Windows stdout 为 GBK**，写入协议管道导致 `UnicodeEncodeError`（改为向 `stdout.buffer` 写 UTF-8 字节）。
- 修复 dashboard `load` 原始响应滞后导致加载结果不可靠（改用 `ur_get_loaded_program` 做权威确认）。
- 修复 `ur_get_joint_temperatures`/`op_status` 中 numpy 值拼进 message 的显示问题。
- 修复 worker 进程管理：首次调用与 spawn 竞态、环境变量清洗、崩溃自动重启。

### 增强
- 新增 `ur_get_status` 的 `remote_control` 字段，便于排查是否处于远程控制模式。
- worker.js 对子进程环境做凭据清洗（剔除 `DSH_*` 与形似密钥的变量）。

## [0.1.0] - 2026-09

- 首个版本：连接/状态/位姿/寄存器/运动/绘图/程序/脚本等 `ur_*` 控制工具。
- 复用 vendored `URBasic` 与拓德科技 nUR MCP Server 同源逻辑，封装为 DSH 原生工具。
