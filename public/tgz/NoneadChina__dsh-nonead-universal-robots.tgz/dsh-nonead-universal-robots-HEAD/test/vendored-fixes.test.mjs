/**
 * test/vendored-fixes.test.mjs — vendored URBasic 缺陷的回归门禁。
 *
 * ## 为什么单独一个文件、而且用 Python 探针
 * 这批缺陷的共同点是**它们是"行为"而不是"可见的一行代码"**：
 *   - `realTimeClient.__sendPrg` 的旧写法是一个"只有成功才退出"的循环 —— 用 grep 找
 *     "有没有 sleep" 之类完全抓不住，必须真的把函数跑起来、在一个**真实断开的回环 socket**
 *     上观察它能不能在上限内返回；
 *   - `ConfigurableInputBits(8)` 的错位是 2**16 vs 2**0，只有构造一个具体的位图才看得出来；
 *   - `RobotStatus()/SafetyStatus()` 在 RTDE 未就绪时抛 TypeError —— 需要真的把 dataDir
 *     留空调用一次；
 *   - `ActualJointVoltage()` 返回的是电流 —— 需要两个不同的数组才能区分。
 * 所以本文件驱动 `test/ur-python-harness.py`（它把结果打成一行 JSON 到真实 stdout），
 * 再逐条断言。探针里的每个假对象都刻意做成"真实形态"（回环 socket 而不是 mock fd），
 * 以免测试通过只是因为假对象恰好绕过了被测路径。
 *
 * 运行：node --test test/vendored-fixes.test.mjs
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { readFileSync, existsSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { join } from 'node:path'

const testDir = fileURLToPath(new URL('.', import.meta.url))
const pythonDir = fileURLToPath(new URL('../python/', import.meta.url))
const harness = join(testDir, 'ur-python-harness.py')

const child = spawnSync(process.env.PYTHON ?? 'python', ['-u', harness], {
  encoding: 'utf8',
  timeout: 180000,
  env: { ...process.env, PYTHONPATH: pythonDir, PYTHONUNBUFFERED: '1', PYTHONIOENCODING: 'utf-8' },
})

assert.equal(child.status, 0, `Python 探针失败（exit ${child.status}）：${child.stderr}`)
const line = (child.stdout ?? '').split('\n').map((l) => l.trim()).find((l) => l.startsWith('{'))
assert.ok(line, `未拿到 JSON 结果：${JSON.stringify(child.stdout)}`)
const probe = JSON.parse(line)

test('realTimeClient 发送：断链时必须在预算内失败，而不是无界重试', () => {
  const r = probe.send_deadline
  assert.equal(r.returned, false, '发送失败必须如实返回 False（不得静默成功）')
  assert.ok(r.within_budget_s, `必须在发送预算内返回（实测 ${r.elapsed_s}s）`)
  assert.ok(r.last_send_failure, '必须记录失败原因供上层回报')
})

test('realTimeClient 发送：成功路径必须真的把字节送到对端', () => {
  const r = probe.send_success
  assert.equal(r.returned, true, '可写 socket 上发送应成功')
  assert.equal(r.received_ok, true, '对端必须真的收到那段 URScript（sendall 而非截断的 send）')
  assert.equal(r.last_send_failure, null, '成功时不得留下失败原因')
})

test('realTimeClient 发送：连不上时必须给出可读原因', () => {
  const r = probe.send_not_connected
  assert.equal(r.returned, false)
  assert.ok((r.last_send_failure ?? '').length > 0, '必须说明为什么没发出去')
})

test('可配置数字 I/O 的位掩码：n=8 必须落在 bit8，而不是 bit16（tool DI）', () => {
  const b = probe.bit_masks
  // 位图：bit0 = 标准 DI0、bit8 = 可配置 DI8、bit16 = tool DI0
  assert.equal(b.std_in_0, true, '标准 DI0 = bit0')
  assert.equal(b.std_in_1, false, '未置位的标准 DI 必须为 false')
  assert.equal(b.config_in_8, true, '可配置 DI8 必须是 bit8')
  assert.equal(b.config_in_9, false, '⚠️ 上游 pow(2, n+8) 会让 n=9 读成 tool DI1 而为 true')
  assert.equal(b.config_in_15, false, '未置位的可配置 DI 必须为 false')
  assert.equal(b.std_out_7, true, '标准 DO7 = bit7')
  assert.equal(b.config_out_15, true, '可配置 DO15 必须是 bit15')
  assert.equal(b.config_out_8, false, '⚠️ 同一处 +8 偏移也出现在输出侧')
})

test('状态位解码：RTDE 字段缺失时返回全 false，绝不抛 TypeError', () => {
  const s = probe.status_none
  assert.equal(s.raised, null, `字段为 None 时不得抛异常（实测 ${s.raised}）`)
  assert.deepEqual(s.robot, {
    PowerOn: false, ProgramRunning: false, TeachButtonPressed: false, PowerButtonPressed: false,
  })
  assert.equal(s.safety_all_false, true, '安全状态位全 false（"状态未知"）')
})

test('遥测访问器：电压/电流/角速度必须读各自的字段', () => {
  const m = probe.measurements
  assert.deepEqual(m.joint_voltage, [1, 2, 3, 4, 5, 6], '⚠️ 上游 ActualJointVoltage 返回的是 actual_current')
  assert.deepEqual(m.joint_current, [0.1, 0.2, 0.3, 0.4, 0.5, 0.6], 'ActualCurrent 必须读 actual_current')
  assert.equal(m.joint_speed.length, 6, 'ActualQD 必须可用（actual_qd 本来就在配方里）')
  assert.equal(m.speed_scaling, 0.75, 'SpeedScaling 必须可用')
  assert.equal(m.analog_out_0, 4.2, 'StandardAnalogOutput(0) 必须可用')
})

test('Dashboard.wait_dbs 必须支持超时（否则调用方永久卡死）', () => {
  const d = probe.dashboard_wait
  assert.equal(d.woke, false, '没人 notify 时必须超时返回 false')
  assert.ok(d.elapsed_s < 2, `显式超时必须真的生效（实测 ${d.elapsed_s}s）`)
  assert.ok(d.elapsed_default_s < 5, `无参调用也必须受默认上限约束（实测 ${d.elapsed_default_s}s）`)
})

test('RTDE.__wait 必须支持超时（否则每次读取姿态都会永久卡住）', () => {
  const r = probe.rtde_wait
  assert.equal(r.woke, false, '无数据时必须超时返回 false')
  assert.ok(r.within_budget_s, `必须在超时预算内返回（实测 ${r.elapsed_s}s）`)
})

test('ur_movec 必须发送真正的 movec（上游 UrScript.movec 固定发 movep 且丢掉 via）', () => {
  assert.equal(probe.movec.uses_raw_urscript, true, 'worker 必须自行拼 movec(p_via, p_to, ...)')
  assert.equal(probe.movec.does_not_call_lib_movec, true,
    '不得调用 UrScript.movec —— 它内部走 movetype="p"，实际发的是 movep')
  assert.equal(probe.movec.upstream_calls_movep, true,
    '上游若已修好 movec，请删掉 worker 里的绕过实现并更新本断言')
})

test('契约：RTDE 接收循环不得再用 __reconnectTimeout 当运行期窗口', () => {
  // 静态契约，配合上面的行为探针：旧写法 `while (not stop_event) and (time.time()-t0<reconnectTimeout)`
  // 会让健康连接在 60 s 后"正常"退出（只发 PAUSE、不关 socket）⇒ isRunning() 仍为 true，
  // 数据却不再更新，此后每次读取都卡在 dataEvent.wait() 上。
  const rtde = readFileSync(join(pythonDir, 'URBasic', 'rtde.py'), 'utf8').replace(/\r\n/g, '\n')
  assert.ok(!/while\s*\(not self\.__stop_event\)\s+and\s+\(time\.time\(\)-t0<self\.__reconnectTimeout\)/.test(rtde),
    '接收循环必须只由 __stop_event / 数据看门狗结束，不得由"启动后 60 s"结束')
  assert.match(rtde, /__dataTimeout/, '必须有运行期数据看门狗窗口')
  assert.match(rtde, /self\.__receive_progress = True/, '必须记录"本次真的收到了数据"')
})

test('契约：Dashboard 接收循环同样不得 60 s 后自杀，且发送必须带超时等待', () => {
  const dash = readFileSync(join(pythonDir, 'URBasic', 'dashboard.py'), 'utf8').replace(/\r\n/g, '\n')
  assert.ok(!/while\s*\(not self\.__stop_event\)\s+and\s+\(time\.time\(\)-t0<self\.__reconnectTimeout\)/.test(dash),
    'Dashboard 接收循环不得由"启动后 2 s"结束（否则 2 s 后所有命令都卡在 wait_dbs）')
  assert.match(dash, /def wait_dbs\(self, timeout=None\)/, 'wait_dbs 必须可超时')
  assert.match(dash, /def sendCommand\(self, cmd\)/, '必须提供"发命令 + 只认本次应答"的包装')
  assert.ok(!/self\.wait_dbs\(\)\s*\n\s*return True/.test(dash),
    '__send 里的 wait_dbs 必须带超时，否则发送失败会永久阻塞')
})

test('契约：rtde.py 不得再用不存在的 self.sock', () => {
  const rtde = readFileSync(join(pythonDir, 'URBasic', 'rtde.py'), 'utf8').replace(/\r\n/g, '\n')
  const block = /def __connect\(self\):[\s\S]*?\n    def /.exec(rtde)
  assert.ok(block, '未找到 RTDE.__connect')
  // 只看**代码**行：这个缺陷的注释里会写明"上游写的是 self.sock"，
  // 把那句注释也算进去会让门禁永远无法通过（也不能因为改了注释就变绿）。
  const code = block[0]
    .split('\n')
    .filter((line) => !/^\s*#/.test(line))
    .join('\n')
  // 否定断言必须排除 `self.__sock`：`self._` 前缀同样匹配 `self\.`。
  const wrong = /self\.(?!_)(\w+\.)?sock\b/.exec(code)
  assert.equal(wrong, null,
    `⚠️ self.sock 不存在（正确属性是 self.__sock）；写错会让 RTDE 线程在首次连接失败时当场死亡。命中：${wrong && wrong[0]}`)
})

test('契约：工具端 I/O 与模拟输出必须使用手册里真实存在的函数名', () => {
  // 仓库内的官方脚本手册（ScriptManual/script_directory_Poly5.pdf）是这几种函数名的权威来源。
  // 上游 vendored 代码里有三个名字在手册中**根本不存在**，而后果不是"少个功能"而是
  // **静默失效**：控制器拒收整段脚本，调用方却回读到陈旧寄存器值（工具数字输入）或
  // 回报"已发送"（工具数字输出）。
  const n = probe.tool_io_names;
  assert.equal(n.get_in_uses_get_tool_digital_in, true, '必须用手册里的 get_tool_digital_in')
  assert.equal(n.get_in_uses_write_output_integer_register, true,
    '必须用手册里的 write_output_integer_register')
  assert.equal(n.get_out_uses_get_tool_digital_out, true, 'get_tool_digital_out 在手册里存在，可以实现回读')
  assert.equal(n.set_out_uses_set_tool_digital_out, true, '必须用手册里的 set_tool_digital_out')
  assert.equal(n.analog_out_uses_accessor_with_index, true,
    'StandardAnalogOutput 必须按端口号取（无参版本不存在）')
  for (const key of [
    'no_write_output_int_register',
    'no_read_tool_digital_in',
    'no_write_tool_digital_out',
    'no_standard_analog_output0_attr',
    'no_standard_analog_output1_attr',
  ]) {
    assert.equal(n[key], true, `${key}：不得再出现手册里没有的名字（旧名字会让控制器拒收脚本）`)
  }
})

test('契约：README 声明的依赖可自检（ur_ping / --selfcheck 的字段存在）', () => {
  // 本仓库曾靠一个不在发布清单里的 python/sitecustomize.py 注入 site-packages，
  // 导致"本机能跑、换台机器 import numpy 就失败"。这里只钉住自检本身必须覆盖依赖。
  const worker = readFileSync(join(pythonDir, 'ur_worker.py'), 'utf8')
  assert.match(worker, /def selfcheck\(\)/)
  for (const dep of ['numpy', 'paramiko', 'rtde_config_exists']) {
    assert.match(worker, new RegExp(`["']${dep}["']`), `自检必须报告 ${dep}`)
  }
  const sitecustomize = join(pythonDir, 'sitecustomize.py')
  assert.ok(!existsSync(sitecustomize) || true,
    '提示：python/sitecustomize.py 若存在则属于本机私货，不得进入发布产物')
})

test('movej/movel 的 t= 必须真的进 URScript（时长参数曾被静默丢弃）', () => {
  // 旧实现把结果赋给了 `tval`，而格式串引用的是 `t_val`（始终为空字符串）⇒ 传 t=5
  // 仍按 a/v 跑，时长完全不受控；而 ur_worker 自拼的 `command` 回报里却带着 t
  // —— 功能失效 + 回报伪造，两条都违反本项目的「诚实读回」底线。
  const r = probe.motion_t_param
  assert.equal(r.j_has_t5, true, `movej 的 t=5 必须出现在脚本里，实测：${r.j_text}`)
  assert.equal(r.l_has_t3, true, `movel 的 t=3 必须出现在脚本里，实测：${r.l_text}`)
  assert.equal(r.j_has_t0, true, 't 缺省（0）也要如实写出 t=0，而不是由格式串留空')
  assert.equal(r.p_has_no_t, true, 'movep 不接受 t，不得凭空塞进脚本')
})

test('错误码：缺字段 / 溢出属于参数错（BADARG），不是内部错误（HUGE）', () => {
  const c = probe.error_codes
  assert.equal(c.key_error, 'BADARG', 'KeyError（handler 直取 p["x"] 而调用方漏传）应为 BADARG')
  assert.equal(c.overflow, 'BADARG', 'OverflowError（int(inf)）应为 BADARG，而不是"插件内部炸了"')
  assert.equal(c.value_error, 'BADARG')
  assert.equal(c.unknown, 'HUGE', '真正未预料的异常仍必须落到 HUGE')
})

test('入站方向也钉死 UTF-8：stdin 必须 reconfigure，且坏字节不能打死进程', () => {
  // Node 侧 JSON.stringify 不转义非 ASCII，写进管道的是 UTF-8 字节；中文 Windows 上
  // 解释器默认 cp936 ⇒ 中文程序名静默乱码、非法字节序列抛 UnicodeDecodeError 把 worker
  // 打死（旧写法 `for line in sys.stdin` 的解码点在 try 之外）。
  const s = probe.stdin_utf8
  assert.equal(s.reconfigures_stdin, true, 'worker 必须把 stdin 也 reconfigure 成 UTF-8')
  assert.equal(s.calls_force_utf8, true, 'main() 必须真的调用它')
  assert.equal(s.loop_reads_line, true, '主循环必须显式 readline()，才能把解码失败变成可诊断的响应')
  assert.equal(s.guards_decode_error, true, '解码失败必须被捕获并如实回报，而不是冲出 main()')
})

test('工具数字输出必须把 Send() 的结果交出去（物理动作不能"发不出去也报成功"）', () => {
  const r = probe.tool_digital_out_send
  assert.equal(r.ok_returns_true, true, 'Send() 返回 true 时 set_tool_digital_out 必须返回 true')
  assert.equal(
    r.fail_returns_false,
    true,
    'Send() 返回 false（掉线 / 非远程控制）时 set_tool_digital_out 必须返回 false —— '
    + '旧实现丢掉了这个返回值，于是 worker 无条件回报"已设置"，而夹爪/气阀根本没动',
  )
  assert.equal(
    r.uses_manual_function_name,
    true,
    `必须用手册里的 set_tool_digital_out（旧名 write_tool_digital_out 会被控制器拒收），实测发出：${r.sent_text}`,
  )
})

test('诚实性契约：工具数字输入必须哨兵验证；状态型命令只能声称"已下发"', () => {
  const h = probe.honesty_contracts
  assert.equal(h.tool_di_uses_verified, true, '工具数字输入必须走哨兵验证过的读取')
  assert.equal(
    h.tool_di_no_stale_readback,
    true,
    '不得再直接调上游封装：它在脚本被静默丢弃时会回读寄存器里上一次遗留的值，把陈旧值当电平回报',
  )
  assert.equal(h.verified_has_probe_sentinel, true, '必须先用通道探测哨兵证明脚本能被执行')
  assert.equal(h.verified_has_read_program, true, '必须把真正的读数夹在首尾哨兵之间')
  assert.equal(h.verified_refuses_without_finish, true, '看不到结束哨兵时必须拒绝给值（NOT_EXECUTED）')
  assert.equal(h.tool_do_checks_send, true, '工具数字输出必须判 set_tool_digital_out 的返回值')
  assert.equal(h.force_mode_unverified, true, 'force_mode 只能声称"已下发"，并带 verified:false')
  assert.equal(h.end_force_unverified, true, 'end_force_mode 同理')
})

test('Dashboard 应答不得串台：没收到应答时必须如实报失败，而不是交出上一条的应答', () => {
  const r = probe.dashboard_crosstalk
  assert.ok(
    r.sent.includes('is in remote control'),
    `命令必须真的发出去（实测服务端收到的命令：${JSON.stringify(r.sent)}）`,
  )
  assert.equal(r.ok, false, '服务端没有回答，"发送成功"不得被当成"拿到了应答"')
  assert.equal(r.respond, '', `不得把陈旧的 "true" 交出去，实测 respond=${JSON.stringify(r.respond)}`)
  assert.equal(r.seq_unchanged, true, '应答序号没有前进 ⇒ 这一条命令没有自己的应答')
})

test('Dashboard 契约：notify 只能由"真的收到消息"触发，收包要按行累积', () => {
  const c = probe.dashboard_contract
  assert.equal(
    c.notify_inside_message_branch,
    true,
    'notifyAll 必须在 `if msg is not None:` 分支内 —— 空轮通知会让 wait_dbs() 假醒，'
    + '__send() 据此误报发送成功，真正的应答落进下一条命令的窗口',
  )
  assert.equal(c.seq_incremented, true, '收到消息必须递增应答序号（__send 靠它判定归属）')
  assert.equal(c.send_awaits_by_seq, true, '__send 必须按应答序号等待，而不是等任意一次 notify')
  assert.equal(c.sendcommand_guards_stale, true, 'sendCommand 必须核对序号是否前进')
  assert.equal(c.recv_accumulates_and_splits, true, '收包必须按换行累积切分，否则分片应答会串到下一条命令')
  assert.equal(c.recv_chunk_is_bigger, true, '单次 recv 不得再用 1024 字节')
})

test('状态型命令一律"未校验"：12 个设置类 op 必须走 ok_unverified', () => {
  const r = probe.unverified_ops
  const names = Object.keys(r)
  assert.equal(
    names.length,
    11,
    `受检 op 数量应固定为 11（实测 ${names.length}）—— 原为 12：set_conveyor_tick 有了回读通道后已毕业`,
  )
  for (const name of names) {
    assert.equal(
      r[name].uses_ok_unverified,
      true,
      `${name} 必须用 ok_unverified：它只能证明"脚本写进了控制器"，不能声称"已生效"`,
    )
    assert.equal(r[name].no_plain_ok_success, true, `${name} 不得再有直接 return ok({ 的成功回报`)
  }
})

test('ok_unverified 的降级是真的（跑一遍函数，而不是匹配源码）', () => {
  const b = probe.ok_unverified_behavior
  assert.equal(b.verified_false, true, 'data 里必须带 verified:false')
  assert.equal(b.keeps_original_fields, true, '原有 data 字段必须保留')
  assert.equal(b.message_keeps_head, true, '原消息必须仍在前半段（不丢信息）')
  assert.equal(b.message_appends_note, true, '消息末尾必须附上"未校验"的说明')
})

test('RTDE START 被拒绝时必须如实反映（isRunning 不得说谎）', () => {
  const r = probe.rtde_start_buffer
  assert.equal(
    r.refused_is_running,
    false,
    'accepted=False 时 isRunning() 必须为 False —— 否则 ensure_connected 的守卫失效，'
    + '之后每次读姿态都要空等 sync() 的 5 s 超时，报出来的却是"等待新的 RTDE 数据超时"',
  )
  assert.equal(r.refused_flag, true, '被拒绝这件事必须被记下来，供上层区分"没连上"与"被拒绝"')
  assert.equal(r.accepted_is_running, true, 'accepted=True 时仍必须正常进入 STARTED')
})

test('RTDE 收包必须跨 recv 边界累积：半个包留着等下一片，不得丢弃', () => {
  const r = probe.rtde_start_buffer
  assert.equal(r.half_not_processed, true, '只有半个包时不得处理（更不得当成已收到）')
  assert.equal(r.half_kept_in_buffer, true, '半个包必须留在缓冲里 —— 旧实现直接丢掉整块缓冲')
  assert.equal(
    r.completed_after_second_half,
    true,
    '补齐后必须处理成功：旧实现把每个跨 recv 边界的包都整帧丢了',
  )
})

test('日志限幅按字节算：中文不得把上限撑到 3 倍', () => {
  const r = probe.capped_log_bytes
  assert.equal(r.rolled, true, '写满就该滚动 —— 按字符算时 5 次 CJK 写入（实际 150 字节）根本不会滚')
  assert.ok(
    r.live_size_bytes <= 90,
    `现役日志必须贴近声明上限（64 B），按字节算是 ≤90；实测 ${r.live_size_bytes} B`,
  )
})

test('realTimeClient.Send 必须先等上一段程序静默（防止两线程并发写同一 socket）', () => {
  const r = probe.send_quiesces
  assert.equal(r.returns_true, true, '可写路径仍应返回 True')
  assert.equal(
    r.joined_waiting_thread,
    true,
    'Send() 必须与 SendProgram() 一样先收尾上一段程序的等待线程 —— 否则两个线程并发'
    + 'sendall 到同一个 30003 socket，行协议可能被交错，而 Send 只回报"写成功"',
  )
  assert.equal(r.sent_payload, 'set_digital_out(0, True)\n', '命令本身必须原样发出去')
})

test('契约：list_programs 必须如实回报"用了内置默认口令"与主机密钥策略', () => {
  const c = probe.list_programs_contract
  assert.equal(c.reports_default_password, true, '不提供 password 时必须回报 used_default_password')
  assert.equal(c.reports_host_key_policy, true, 'AutoAddPolicy 这件事必须出现在返回值里')
  assert.equal(c.warns_about_mitm, true, '必须明确写出"没有中间人防护"')
  assert.equal(c.supports_known_hosts, true, '必须提供 known_hosts 这条严格校验路径（RejectPolicy）')
  assert.equal(c.no_silent_fallback, true, 'known_hosts 文件不存在必须报错，不得静默退回 auto-add')
})

test('契约：ur_check_pose / ur_set_speed_scaling 必须走"能自证"的路径', () => {
  const c = probe.new_ops_contract
  assert.equal(c.check_pose_dispatched, true, 'HANDLERS 必须挂上 check_pose')
  assert.equal(c.speed_dispatched, true, 'HANDLERS 必须挂上 set_speed_scaling')
  assert.equal(c.check_uses_safety_limits, true, '预检必须真的问控制器的 is_within_safety_limits')
  assert.equal(c.check_uses_inverse_kin, true, '可达性必须真的问 get_inverse_kin')
  assert.equal(c.check_has_sentinels, true, '必须用首尾哨兵区分"跑完/跑到一半/没执行"')
  assert.equal(c.check_reports_not_executed, true, '控制器没执行时必须报 NOT_EXECUTED，不能猜')
  assert.equal(
    c.check_writes_registers,
    true,
    '写 double 寄存器必须用 write_output_float_register（不能用 RTDE 字段名当函数名）',
  )
  assert.equal(c.speed_uses_slider, true, '速度倍率必须走 set_speed_slider')
  assert.equal(c.speed_reads_back, true, '★ 必须回读 target_speed_fraction 才敢报 verified')
  assert.equal(c.speed_marks_unverified_hw, true, '未经真机验证的映射必须如实标注')
})

test('★ _pose6 必须挡住畸形输入（BADARG 的来源，不能把垃圾拼进 URScript）', () => {
  const v = probe.pose6_validation
  assert.equal(v.accepts_valid, true, '合法 6 维输入必须通过')
  for (const key of Object.keys(v)) {
    if (key === 'accepts_valid') continue
    assert.equal(v[key], true, `${key} 必须被拒绝（否则会把畸形值拼成 URScript 下发）`)
  }
})

test('★ 程序文件传输必须"核对做成了没有"，而不是"请求已发出"', () => {
  const p = probe.program_ops_contract
  assert.equal(p.all_dispatched, true, 'HANDLERS 必须挂上三个传输 op')
  assert.equal(p.upload_verifies_size, true, '上传必须回读远端大小，不一致报 VERIFY_FAILED')
  assert.equal(p.download_verifies_size, true, '下载必须回读本地大小，不一致报 VERIFY_FAILED')
  assert.equal(p.delete_rechecks, true, '删除必须在 remove 之后再 stat 确认真的没了')
  assert.equal(p.download_backs_up, true, '★ 下载不得静默覆盖：目标已存在时先备份为 .bak')
  assert.equal(
    p.credentials_read_explicitly,
    true,
    '三个 op 都要显式读 username/password/known_hosts（check-tool-params 逐 op 对账）',
  )
})

test('★ 示教器文本必须挡住换行注入（dashboard 按行解析命令）', () => {
  const g = probe.dashboard_text_guard
  assert.equal(g.accepts_normal, true, '正常单行文本必须放行')
  assert.ok(g.max_chars > 0, '必须有长度上限')
  for (const key of Object.keys(g)) {
    if (key === 'accepts_normal' || key === 'max_chars') continue
    assert.equal(
      g[key],
      true,
      `${key} 必须被拒绝 —— 否则 'x\\nshutdown' 这类文本会被 dashboard 当成第二条命令执行`,
    )
  }
})

test('现场消息三个 op 必须走 dashboard 通道，并如实报"没得到应答"', () => {
  const m = probe.messaging_ops_contract
  assert.equal(m.all_dispatched, true, 'HANDLERS 必须挂上 popup/close/add_log')
  assert.equal(m.popup_via_dashboard_args, true, '弹窗必须走带参 dashboard 通道')
  assert.equal(m.close_via_dashboard, true, '关弹窗必须走 dashboard')
  assert.equal(m.log_via_dashboard_args, true, '写日志必须走带参 dashboard 通道')
  assert.equal(m.text_guard_applied, true, '两个吃文本的 op 都必须过注入防线')
  assert.equal(m.honest_on_no_reply, true, '拿不到控制器应答时报 NOT_EXECUTED，不假装成功')
})

test('★ Modbus：八个 op 走哨兵运行器，且如实标注"现场总线未被确认"', () => {
  const m = probe.modbus_contract
  assert.equal(m.all_dispatched, true, 'HANDLERS 必须挂上八个 Modbus op')
  assert.equal(
    m.all_use_sentinel_runner,
    true,
    '八个都要走"首尾哨兵 + 三种结局"的公共运行器 —— 否则"脚本有没有跑"无从判断',
  )
  assert.equal(
    m.declares_fieldbus_unconfirmed,
    true,
    '★ Modbus 写类没有应答：必须回报 fieldbus_confirmed=false，不能声称 PLC 已执行',
  )
  assert.equal(m.status_reads_back, true, '唯一有回读的那条必须真的回读输出寄存器')
  assert.equal(
    m.status_kind_branches,
    true,
    '★ 数字/寄存器两种 kind 必须生成不同脚本（URScript 强类型，bool 写浮点寄存器会让程序中止）',
  )
  assert.equal(m.validators_used, true, '吃信号名的 op 都必须过白名单校验')
  assert.equal(m.byte_list_validated, true, '字节数组必须逐项校验 0-255')
  assert.equal(m.write_ops_gated, true, '五个写类 op 必须入审批门禁（能驱动 PLC）')
  assert.equal(m.read_op_not_gated, true, '只读那条不该入审批门禁')
  assert.equal(m.config_ops_not_gated, true, '两个信号配置项不该入审批门禁')
})

test('★ Modbus 参数防线：信号名注入与越界都必须被拒', () => {
  const v = probe.modbus_validators
  assert.equal(v.accepts_signal_name, true, '正常信号名必须放行')
  assert.equal(v.accepts_ip, true, '正常 IPv4 必须放行')
  assert.equal(v.accepts_bytes, true, '正常字节数组必须放行')
  for (const key of Object.keys(v)) {
    if (key.startsWith('accepts_')) continue
    assert.equal(
      v[key],
      true,
      `${key} 必须被拒绝 —— 信号名会被拼进 URScript 字符串字面量，引号/换行等于注入脚本`,
    )
  }
})

test('★ 力控引导运动：脚本形状对，且绝不碰 RTDE 输入字段', () => {
  const m = probe.move_force_contract
  assert.equal(m.dispatched, true, 'HANDLERS 必须挂上 move_force')
  assert.equal(m.script_shape, true, '必须是 force_mode → movel → stopl → end_force_mode 一段跑完')
  assert.equal(
    m.no_rtde_input_write,
    true,
    '★ 绝不写 RTDE 输入寄存器 —— 本插件没有 send 配方，claim 输入字段会让控制器抛异常并崩掉 RTDE 线程',
  )
  assert.equal(m.reads_pose_before_after, true, '必须用只读 RTDE 读运动前后的实际位姿')
  assert.equal(m.uses_sentinel_runner, true, '必须用首尾哨兵证明脚本真的跑完了')
  assert.equal(m.reports_shortfall, true, '必须给出是否到位 / 是否提前停下')
  assert.equal(m.declares_safety_flag, true, '必须连安全停止标志一起回报，不替调用方下结论')
  assert.equal(m.gated, true, 'move_force 必须入运动审批门禁')
})

test('★ 力控选择向量只接受 6 个 0/1', () => {
  const v = probe.selection_vector_guard
  assert.equal(v.accepts_valid, true, '合法 6 个 0/1 必须放行')
  assert.equal(v.accepts_bool_as_int, true, '布尔应按 0/1 归一化，否则会渲染成 True/False 下发')
  for (const key of Object.keys(v)) {
    if (key.startsWith('accepts_')) continue
    assert.equal(v[key], true, `${key} 必须被拒绝`)
  }
})

test('★ 命名位姿表四个 op 的契约：原子写、回读、区分缺失/损坏、配额', () => {
  const p = probe.pose_ops_contract
  assert.equal(p.all_dispatched, true, 'HANDLERS 必须挂上四个 pose op')
  assert.equal(p.atomic_write, true, '写盘必须是"临时文件 + os.replace"（否则会留下半截 JSON）')
  assert.equal(p.save_reads_back, true, '★ 保存后必须回读比对，不一致报 VERIFY_FAILED')
  assert.equal(p.save_reports_replaced, true, '覆盖已有位姿必须如实回报 replaced')
  assert.equal(
    p.get_separates_missing,
    true,
    '★ 「从没存过」(NOT_FOUND) 与「存过但损坏」(CORRUPT) 必须分开，否则调用方会去重存一个已存在的东西',
  )
  assert.equal(p.get_flags_shape, true, '读回来要指出 pose/joints 是否仍是合法 6 维数')
  assert.equal(p.list_survives_corrupt, true, '★ 单个条目损坏不能让整张表失败')
  assert.equal(p.delete_rechecks, true, '删除必须先确认存在、删完再确认真的没了')
  assert.equal(p.quota_respects_existing, true, '配额只在新增时生效（更新已有位姿仍要放行）')
  assert.equal(
    p.limit_matches_host,
    true,
    '★ 宿主 MAX_POSE_FILE_BYTES 与 worker POSE_FILE_MAX_BYTES 必须同一个数（跨语言常量会漂）',
  )
})

test('★ check_pose 生成的 URScript 必须类型正确：布尔值不得直接写整数寄存器', () => {
  const s = probe.check_pose_script_types
  assert.equal(
    s.int_register_args_are_literals,
    true,
    '★ 所有 write_output_integer_register 的第 2 个实参都必须是整数字面量 —— 布尔表达式会让控制器在该行抛错中止（真机实测：机器人此刻正站着的位姿被报成"不在安全限值内 + IK 解不出"）',
  )
  assert.equal(
    s.no_bool_into_int_register,
    true,
    '整数寄存器的实参里不得出现 is_within_safety_limits 这类布尔表达式',
  )
  assert.equal(s.bool_lands_in_local_first, true, '布尔值必须先落到 local，再由 if/else 归一成 1/0')
  assert.equal(s.writes_both_branches, true, '两个分支都必须各自写整数（只写 true 分支等于没给答案）')
  assert.equal(s.stage_register_distinct_from_limits, true, '阶段标记寄存器不得与限值答案寄存器复用')
  assert.equal(s.stage1_before_ik, true, 'stage1 必须打在限值那步之后、get_inverse_kin 之前')
  assert.equal(
    s.stage2_after_ik_result,
    true,
    '★ stage2 必须打在 IK 解出并写完关节角之后 —— 有它才能把"死在限值那步"与"死在 IK"分开，否则又会得出无依据的"不可达"',
  )
  assert.equal(s.sentinels_bracket_script, true, '首尾哨兵必须把整段围起来（起始在前、结束在最后）')
  assert.equal(s.qnear_optional, true, 'qnear 可给可不给：不给时 get_inverse_kin 只带位姿一个参数')
  assert.equal(s.one_script_per_call, true, '必须是一段完整的 def…end + 调用，不能是裸语句片段')
})

test('★ 传送带 tick 写入必须自证（它已从"只能声称已下发"的清单里毕业）', () => {
  const c = probe.conveyor_set_contract
  assert.equal(c.still_dispatches, true, '仍然要真的下发 set_conveyor_tick_count')
  assert.equal(c.reuses_verified_reader, true, '必须复用同族已有的三哨兵读取器 op_get_conveyor')
  assert.equal(
    c.reports_verified_only_after_readback,
    true,
    '★ 只有回读之后才允许报 verified —— 否则又是"报告一个它从未核实过的答案"',
  )
  assert.equal(
    c.honest_on_mismatch,
    true,
    '★ 回读不一致必须明说"没有生效"（真机实测：写 1234 回读 0 时，旧实现只会说"已设置（未校验）"）',
  )
  assert.equal(c.honest_when_read_fails, true, '连回读都失败时也要把原因交出去，而不是含糊其辞')
  assert.equal(
    c.discriminates_by_error_key,
    true,
    '★ 判断"回读成功与否"必须看 "error" 键：ok(data) 是恒等函数，结果字典里没有 "ok" 键',
  )
  assert.equal(c.does_not_inspect_ok_key, true, '★ 不得用 .get("ok") 判断成功 —— 那是恒为假的写法')
  assert.equal(c.graduates_from_unverified_list, true, '它已不是"只能声称已下发"的 op，必须从该清单移除')
})
