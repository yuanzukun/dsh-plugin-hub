# dsh-chinese-thinking

本插件属于 **`@max-null/*` 插件系列**——这一系列共同构成 **[SSID（思灵 · Seek Soul in Darkness）](https://github.com/Max-Null/seek-soul-in-darkness)** 桌面体验。SSID 是整合它们的盒：`dsh-capture` · `dsh-chat-rail` · `dsh-chinese-thinking` · `dsh-draft-polish` · `dsh-guardian` · `dsh-habit` · `dsh-memory` · `dsh-node-appearance` · `dsh-plugin-center` · `dsh-quick-toolbar` · `dsh-skill-mcp-center` · `dsh-ssid-panels` · `dsh-ssid-zh-ui` · `dsh-achievements`。

This plugin belongs to the **`@max-null/*` family** — a set of plugins that together form the **[SSID (思灵 · Seek Soul in Darkness)](https://github.com/Max-Null/seek-soul-in-darkness)** desktop experience.

一个"小而美"的 DeepSeek Harness 插件，只做一件事：**注入一条固定的 system-prompt section，让 agent 始终用中文思考和回复**——无论用户用什么语言。

无存储、无工具、无状态。一条固定文本，前缀稳定、缓存安全。

## 注入的文案

> 始终使用中文进行思考和回复，无论用户使用什么语言。

## 截图

本插件是**纯提示注入类**：不新增任何按钮、面板或设置项。装完后 agent 会先用中文思考再作答，效果直接体现在会话输出上。

> 按《SSiD 开发手册》§9 截图规范：截图须回答「装完会多出/变成什么」的**入口与面板**。
> 本插件无界面元素，故**不适用**该项要求，改以上述行为效果说明代替。

## 用法

```bash
npm install @max-null/dsh-chinese-thinking
```

在你的 `cordis.patch.yml` 加一条（`system-prompt` 由宿主已有）：

```yaml
- id: chinese-thinking
  name: '@max-null/dsh-chinese-thinking'
```

## 实现

```ts
ctx.systemPrompt.section({
  name: 'chinese-thinking',
  order: -90,   // 身份声明（-100）之后、persona（0）之前——行为指令中排位最靠前
  text: '始终使用中文进行思考和回复，无论用户使用什么语言。',
})
```

## SSID 系列

## 依赖（peerDependencies，由宿主提供）

`@deepseek-ai/cordis`、`@deepseek-ai/dsh-system-prompt`
