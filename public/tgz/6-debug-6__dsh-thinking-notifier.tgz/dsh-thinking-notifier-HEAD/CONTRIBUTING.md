# Contributing

Thanks for considering a contribution to `dsh-thinking-notifier`!

## Development setup

```sh
# Clone the repository
git clone https://github.com/6-debug-6/dsh-thinking-notifier.git
cd dsh-thinking-notifier

# Install into a local DSH web profile
dsh plugin --profile web add .

# Run DSH web
dsh web
```

The plugin is plain JavaScript and needs no build step.

- Host half: `lib/index.js`
- Windows popup: `desktop-popup.ps1`
- macOS/Linux popup: `desktop-popup.py`

## Testing

```sh
# status-machine smoke test (fake cordis context, popup disabled, port 17389)
npm test

# syntax checks
node --check lib/index.js
python -m py_compile desktop-popup.py
```

For Windows popup syntax checking:

```powershell
powershell -NoProfile -Command "& { $t = Get-Content -Raw 'desktop-popup.ps1'; $null = [scriptblock]::Create($t); Write-Output 'parse ok' }"
```

To look at the popup without waiting for a real turn, run a mock status service on a spare port (the real popup on `7389` is not affected, because the plugin only cleans up popup processes for its own port):

```sh
node tools/mock-status.mjs question --port 17389
powershell -NoProfile -ExecutionPolicy Bypass -File desktop-popup.ps1 -Port 17389   # Windows
python3 desktop-popup.py --port 17389                                               # macOS/Linux
```

When changing popup geometry or the collapsed width, keep `desktop-popup.ps1` and `desktop-popup.py` in sync and update both readmes.

## Debug logs

- `~/.dsh/tn-plugin.log`
- `~/.dsh/tn-launcher.log`
- `~/.dsh/tn-popup-debug.log`

## License

By contributing you agree that your contributions will be licensed under the MIT License.
