/**
 * Status-machine smoke test for dsh-thinking-notifier.
 *
 * Runs the real host plugin (`lib/index.js`) against a fake cordis context on a
 * spare port, with the desktop popup disabled, and asserts the status endpoint.
 *
 *   node test/status-smoke.mjs
 *
 * Covers:
 *   - startup rebuild: an unclosed `turn/start` (crashed DSH) must not report "thinking"
 *   - turn lifecycle: turn/start -> running, turn/end -> done
 *   - ask_user_question: the wrapped `ctx.userQuestions.ask` drives mode=question
 *   - approval: approval/asked -> pending, approval/decided -> back to running
 */
process.env.DSH_THINKING_NOTIFIER_NO_POPUP = '1'
process.env.DSH_THINKING_NOTIFIER_PORT = '17389'

const PORT = 17389
const BASE = `http://127.0.0.1:${PORT}`

const failures = []
function check(name, ok, extra) {
  if (!ok) failures.push(name)
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${extra === undefined ? '' : ` -> ${typeof extra === 'string' ? extra : JSON.stringify(extra)}`}`)
}

const listeners = []
const effects = []
const fakeUserQuestions = {
  pending: [],
  ask() {
    return new Promise((resolve, reject) => {
      this.pending.push({ resolve, reject })
    })
  },
}

const staleEvents = [
  { type: 'session/title', seq: 0, time: Date.now() - 600000, data: { title: '会话（崩溃遗留）' } },
  { type: 'turn/start', seq: 1, time: Date.now() - 600000, data: { turn: 1 } },
  { type: 'step/start', seq: 2, time: Date.now() - 600000, data: { turn: 1, step: 1 } },
]
const closedEvents = [
  { type: 'session/title', seq: 0, time: Date.now() - 900000, data: { title: '已结束的会话' } },
  { type: 'turn/start', seq: 1, time: Date.now() - 900000, data: { turn: 1 } },
  { type: 'turn/end', seq: 2, time: Date.now() - 899000, data: { turn: 1, reason: { kind: 'completed' } } },
]

const fakeSessions = {
  list() {
    return [
      { id: 'session-stale', events: staleEvents },
      { id: 'session-closed', events: closedEvents },
      { id: 'session-A', events: [{ type: 'session/title', seq: 0, time: Date.now(), data: { title: '当前会话' } }] },
    ]
  },
}

const ctx = {
  sessions: fakeSessions,
  webServer: { port: 3080 },
  on(event, cb) { listeners.push({ event, cb }) },
  get(name) { return name === 'userQuestions' ? fakeUserQuestions : undefined },
  userQuestions: fakeUserQuestions,
  inject(deps, cb) {
    check('ctx.inject 请求了 userQuestions', Array.isArray(deps) && deps.includes('userQuestions'), deps)
    cb({
      get(name) { return name === 'userQuestions' ? fakeUserQuestions : undefined },
      userQuestions: fakeUserQuestions,
      effect(fn) { effects.push(fn) },
    })
  },
  effect(fn) { effects.push(fn) },
}

async function status() {
  const res = await fetch(`${BASE}/status`)
  return await res.json()
}

async function waitForServer(timeoutMs = 5000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      if ((await fetch(`${BASE}/health`)).ok) return true
    } catch (_err) { /* not up yet */ }
    await new Promise(r => setTimeout(r, 100))
  }
  return false
}

function emit(sessionId, event) {
  for (const l of listeners) {
    if (l.event === 'session/event') l.cb({ id: sessionId }, event)
  }
}

const { apply } = await import(new URL('../lib/index.js', import.meta.url).href)
apply(ctx)
check('状态服务在 17389 起来', await waitForServer())

// 1. Startup rebuild
let s = await status()
check('启动后 idle（未闭合 turn 不误报、历史 turn/end 不弹 done）', s.mode === 'idle', s)
check('启动后 questionCount=0', s.questionCount === 0, s.questionCount)
check('启动后 detailText 字段存在', typeof s.detailText === 'string', s.detailText)

// 2. Turn lifecycle
emit('session-A', { type: 'turn/start', seq: 0, time: Date.now(), data: { turn: 1 } })
s = await status()
check('turn/start -> running', s.mode === 'running', s)
check('running 计时为 mm:ss', /^\d{2}:\d{2}$/.test(s.timeText), s.timeText)
check('running 展示会话标题', s.sessionText === '当前会话', s.sessionText)

// 3. ask_user_question with options
const askPromise = fakeUserQuestions.ask({
  questions: [{
    id: 'style',
    header: 'Choose Mode',
    question: '用哪种弹窗样式？',
    options: [{ label: '样式 A' }, { label: '样式 B' }, { label: '样式 C' }],
    multiSelect: true,
  }],
  agent: { id: 'session-A' },
})
s = await status()
check('提问 -> mode=question', s.mode === 'question', s)
check('提问 -> pendingKind=question', s.pendingKind === 'question', s.pendingKind)
check('提问 -> 文案为等待选择', s.statusText === 'AI 正在等待你的选择', s.statusText)
check('提问 -> 摘要含 header', s.sessionText === 'Choose Mode', s.sessionText)
check('提问 -> detailText 含选项与可多选', /样式 A \/ 样式 B \/ 样式 C/.test(s.detailText) && s.detailText.includes('可多选'), s.detailText)
check('提问 -> timeText 为等待时长', /^已等待 \d{2}:\d{2}$/.test(s.timeText), s.timeText)
check('提问 -> questionCount=1', s.questionCount === 1, s.questionCount)

// 4. Answered -> back to running
fakeUserQuestions.pending.at(-1).resolve({ answers: [{ id: 'style', selected: ['样式 A'] }] })
await askPromise
s = await status()
check('回答后 -> 回到 running', s.mode === 'running', s)
check('回答后 -> questionCount=0', s.questionCount === 0, s.questionCount)
check('回答后 -> detailText 清空', s.detailText === '', s.detailText)

// 5. Multiple questions: options describe the first question only
const multiAsk = fakeUserQuestions.ask({
  questions: [
    { id: 'q1', header: '推送确认', question: '推送吗？', options: [{ label: '推送' }, { label: '不推送' }] },
    { id: 'q2', header: 'npm', question: '发布吗？', options: [{ label: '不发布' }] },
  ],
  agent: { id: 'session-A' },
})
s = await status()
check('多问题 -> 摘要标注共 N 问', s.sessionText === '推送确认（共 2 问）', s.sessionText)
check('多问题 -> detailText 只取第一个问题的选项', s.detailText === '选项：推送 / 不推送', s.detailText)
check('多问题 -> questionCount=1（按会话计）', s.questionCount === 1, s.questionCount)
fakeUserQuestions.pending.at(-1).resolve({ answers: [] })
await multiAsk
s = await status()
check('多问题回答后 -> 回到 running', s.mode === 'running', s)

// 6. Free-form question (no options)
const freeAsk = fakeUserQuestions.ask({ questions: [{ id: 'text', question: '还有别的要补充吗？' }], agent: { id: 'session-A' } })
s = await status()
check('无选项提问 -> detailText 提示自行输入', s.detailText === '需你自己输入回答', s.detailText)
check('无选项提问 -> 摘要用 question 文本', s.sessionText === '还有别的要补充吗？', s.sessionText)
fakeUserQuestions.pending.at(-1).reject(new Error('ASK_ABORTED'))
await freeAsk.catch(() => {})
s = await status()
check('提问被取消后 -> 回到 running', s.mode === 'running', s)
check('提问被取消后 -> questionCount=0', s.questionCount === 0, s.questionCount)

// 7. Approval flow (pre-existing behavior)
emit('session-A', { type: 'approval/asked', seq: 1, time: Date.now(), data: { id: 'ap-1', toolName: 'pwsh' } })
s = await status()
check('approval/asked -> pending', s.mode === 'pending' && s.pendingKind === 'approval', s)
check('pending 时 pendingTool 有值', s.pendingTool === 'pwsh', s.pendingTool)
emit('session-A', { type: 'approval/decided', seq: 2, time: Date.now(), data: { id: 'ap-1' } })
s = await status()
check('approval/decided -> 回到 running', s.mode === 'running', s)

// 8. turn/end -> done
emit('session-A', { type: 'turn/end', seq: 3, time: Date.now(), data: { turn: 1, reason: { kind: 'completed' } } })
s = await status()
check('turn/end -> done', s.mode === 'done', s)
check('done -> 无计时', s.timeText === '', s.timeText)
check('/status 始终 ok:true', s.ok === true, s.ok)

// 9. Cleanup
for (const fn of effects.reverse()) {
  try {
    const cleanup = fn()
    if (typeof cleanup === 'function') cleanup()
  } catch (_err) { /* ignore */ }
}
await new Promise(r => setTimeout(r, 200))
const stillUp = await fetch(`${BASE}/health`).then(() => true).catch(() => false)
check('dispose 后状态服务已关闭', stillUp === false)

console.log(failures.length === 0 ? '\nALL PASS' : `\n${failures.length} FAILED: ${failures.join(' | ')}`)
process.exit(failures.length === 0 ? 0 : 1)
