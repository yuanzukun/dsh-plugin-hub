# Changelog

All notable changes to this project are documented in this file.

## [Unreleased]

## [1.3.0] - 2026-10-07

### Added
- Question state (`question`, violet): when the AI calls `ask_user_question`, the popup shows `AI 正在等待你的选择`, the question heading, the option labels (`（可多选）` for multi-select questions), and how long it has been waiting. It stays expanded until you answer.
- Status JSON fields `detailText` (the first question's options), `questionCount`, and `questionSince`; `pendingKind` is now `approval` or `question`.
- `DSH_THINKING_NOTIFIER_NO_POPUP=1` to run the status server without launching a desktop popup (headless environments and tests).
- Status-machine smoke test (`npm test`, `test/status-smoke.mjs`) and a mock status service (`tools/mock-status.mjs`) for offline popup rendering.
- A "Verification status" section in both readmes stating which states are verified end to end.
- Auto-collapse: while the AI is thinking, the popup shows fully for 5 seconds, then collapses into a slim right-edge tab (25 px wide) so it does not block desktop controls.
- Manual expand: hover or click the edge tab to expand the popup again.
- Automatic expand on new states: new turns, questions, permission requests, and completions expand the popup automatically.

### Changed
- The popup's third line now prefers `detailText` (question options) over `timeText`.
- When one `ask_user_question` call carries several questions, `detailText` describes the **first** question's options only and the heading is suffixed with `（共 N 问）`, instead of merging every question's labels into one ambiguous line.
- Session titles in `sessionText` are capped (first 3, then `等 N 个`) so the field cannot grow into a wall of text.
- Popup cleanup before launch is now scoped to the plugin's own port, so it no longer touches a second DSH instance running on another port.

### Fixed
- Stale "AI is thinking" states: a session whose event log ends inside an open `turn/start` (DSH killed mid-turn) is no longer reported as running forever after a restart, and replaying historical `turn/end` events no longer flashes a fake "AI 已完成思考" at startup.
- The plugin tracked the one-shot popup launcher as if it were the popup process; the launcher exits with code 0 after about a second, so the spawn guard returned early and the shutdown kill was a no-op. The spawn guard is now explicit and shutdown/reload kills the popup processes belonging to its own port.
- Question state is observed by wrapping `ctx.userQuestions.ask`; the flow emits no session event, and registering a second UI provider would fail with `DUPLICATE_PROVIDER`.
- The popup's third line could overflow the card; it is now trimmed like the other lines.

## [1.2.0] - 2026-08-16

### Added
- DeepSeek-style color scheme (`#1E2235` card, `#4D6BFE` running dot).
- Close button (X) on the popup; dismissed popups reappear for the next new turn, permission request, or completion.
- Bilingual documentation (`README.md`, `README.zh.md`), `CONTRIBUTING.md`, `.gitignore`.

### Changed
- Removed click-to-open-webpage behavior from the popup card.
- Hidden the PowerShell console window on Windows and disabled the `Invoke-WebRequest` progress bar.
- Popup script now uses `Show()` + `Dispatcher.Run()` instead of `ShowDialog()` so it stays alive while idle instead of exiting when the window is collapsed.

### Fixed
- `spawnPopup()` never launched the popup because `popupProcess` was initialized to `null` while the guard checked `!== undefined`.
- Popup launched by the plugin exited immediately under idle state (`ShowDialog()` returned for a collapsed window).
- Chinese text in the popup could be garbled on Windows PowerShell 5.1 due to UTF-8 decoding; switched to raw-byte UTF-8 decoding.
- DSH direct `spawn` of PowerShell exited immediately; the plugin now uses a one-shot launcher (`Start-Process`) to create an independent popup process.

## [1.1.0] - 2026-08-16

### Added
- Desktop popup support for Windows (PowerShell + WPF) and macOS/Linux (Python 3 + tkinter).
- Host-side status server (`127.0.0.1:7389/status`).
- Debug logging (`tn-plugin.log`, `tn-launcher.log`, `tn-popup-debug.log`).

## [1.0.0] - 2026-08-15

### Added
- Initial DSH plugin package with persistent bundle mount.
- Browser-side popup (later replaced by native desktop popup in 1.1.0).
