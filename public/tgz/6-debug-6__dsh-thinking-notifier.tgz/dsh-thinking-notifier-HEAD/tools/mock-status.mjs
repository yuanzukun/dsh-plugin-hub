/**
 * Mock status service for offline popup testing.
 *
 * Serves a fixed dsh-thinking-notifier status JSON so you can look at the popup
 * without waiting for a real turn (or without a real approval, which cannot be
 * triggered on a Windows install without a confining sandbox).
 *
 *   node tools/mock-status.mjs question --port 17389
 *   powershell -NoProfile -ExecutionPolicy Bypass -File desktop-popup.ps1 -Port 17389
 *   # macOS/Linux: python3 desktop-popup.py --port 17389
 *
 * Modes: question | pending | running | done | idle   (default: question)
 */
import { createServer } from 'node:http'

const argv = process.argv.slice(2)
const mode = argv.find((a) => !a.startsWith('--')) || 'question'
const portIndex = argv.indexOf('--port')
const port = portIndex >= 0 ? Number(argv[portIndex + 1]) : 17389

const BODIES = {
  question: {
    mode: 'question',
    statusText: 'AI 正在等待你的选择',
    sessionText: 'Choose Mode',
    detailText: '选项：样式 A / 样式 B / 样式 C（可多选）',
    timeText: '已等待 00:12',
    pendingKind: 'question',
    questionCount: 1,
  },
  pending: {
    mode: 'pending',
    statusText: 'AI 请求权限',
    sessionText: 'bash',
    detailText: '',
    timeText: '',
    pendingKind: 'approval',
    pendingTool: 'bash',
    questionCount: 0,
  },
  running: {
    mode: 'running',
    statusText: 'AI 正在思考…',
    sessionText: '当前会话',
    detailText: '',
    timeText: '01:23',
    questionCount: 0,
  },
  done: {
    mode: 'done',
    statusText: 'AI 已完成思考',
    sessionText: '',
    detailText: '',
    timeText: '',
    questionCount: 0,
  },
  idle: {
    mode: 'idle',
    statusText: 'AI 空闲',
    sessionText: '',
    detailText: '',
    timeText: '',
    questionCount: 0,
  },
}

if (BODIES[mode] === undefined) {
  console.error(`unknown mode: ${mode} (expected one of ${Object.keys(BODIES).join(', ')})`)
  process.exit(1)
}

createServer((_req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8')
  res.end(JSON.stringify({ ok: true, ...BODIES[mode], appUrl: 'http://127.0.0.1:3080', now: Date.now() }))
}).listen(port, '127.0.0.1', () => {
  console.log(`mock status: http://127.0.0.1:${port}/status (mode=${mode}) — Ctrl+C to stop`)
})
