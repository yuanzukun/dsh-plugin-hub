# Work Charter for DeepSeek Harness

[简体中文](README.zh-CN.md)

WCDP adapts the installed Codex Work Charter **0.9.1** to DeepSeek Harness. It records the outcome, authority, responsibilities, writer, evidence, acceptance and recovery of consequential work. Ordinary stable work needs no Charter ceremony.

The **0.2.0-alpha.1** release line uses contract **2** and logical storage schema **2**, targeting DSH **0.1.7-rc.2** at `477b4f420553e8a52c2fbccc464d7561b239c443`. Distribution is a [GitHub Pre-release](https://github.com/junwei529/work-charter-dsh/releases/tag/v0.2.0-alpha.1); package metadata retains `private: true`, with no npm publication. Publication state and qualification limits live in [STATUS](docs/STATUS.md) and [VERIFICATION](docs/VERIFICATION.md); the normative scope is [SPEC](docs/SPEC.md#successor-design-work-charter-091-and-scdp-retirement).

## Native Team and Charter policy

The successor removes the `session-coordinator-dsh` runtime dependency. Native DSH supplies Team membership, persistent teammates, mailbox delivery and restart. WCDP keeps only Charter-specific contract state, authority/evidence history, writer observations, result/review/disposition semantics, frozen role models and uncertain-handoff stopping.

| Arrangement | Responsibilities | Native scope |
|---|---|---|
| Direct | primary, applicable independent R | primary Session; optional R in its native Team |
| Team | P, E, applicable independent R | P is Lead; flat teammates |
| Phased | O, P, E, applicable independent R | O is Lead; P owns E/R work and acceptance |

Continuity (current-task/durable) is independent of arrangement. Contract approval is independent of active/paused/closed run state. R supplies technical review; primary/P/O owns outcome acceptance. Existing unrelated root Sessions, cross-Team work and multiple worktrees are outside this candidate's scope.

The Host validates WCDP operations; the Client is read-only. WCDP does not lock files, grant permission, attest human approval, or enforce every DSH tool. Native delivery is not model inspection or semantic acceptance.

## Composition and use

Use a **fresh isolated profile and paired storage** with the exact DSH packages above, Node `^22.19.0 || >=24.0.0`, Cordis `4.0.4` and shared UI React `18.3.1`. The default bundle patch mounts only WCDP on the base Host services (Agent, Session, tools, skills, system prompt and storage domain). No SCDP is mounted.

For multiple responsibilities the profile additionally supplies `@deepseek-ai/dsh-subagent`, `@deepseek-ai/dsh-subagent-spawn-in-process` with provider name `spawn`, and `@deepseek-ai/dsh-experimental-agent-team`, all pinned to the same DSH version. The optional native Team tool package may be added by the profile owner; WCDP role provisioning and notice tools call public Team services directly. Do not change an installed profile without installation authority.

Start from the Work Charter Skill and `work_charter_status`; the [packaged Skill](assets/work-charter-dsh.md) documents all five model tools and contract-2 JSON examples. New roles select complete model objects using 0.9.1 source precedence and freeze them before first dispatch. Supported selected parameters are `reasoning_effort` and `max_output_tokens`; unavailable models or unsupported parameters stop rather than silently changing the request. Existing Lead settings remain host-owned.

Keep Session logs and Charter storage together. A WCDP-marked native child stops if its paired Charter record is missing. Unknown sends remain durable stops; reconciliation records exact external native-log evidence and does not resend. Preserve old profiles and data: schema 1 is rejected, not automatically migrated.

### Install into a new profile

Use an existing official `@deepseek-ai/dsh@0.1.7-rc.2` installation and pnpm `11.7.0`. Download the versioned tarball and its SHA-256 sidecar from the Release page, verify the checksum, and choose an unused profile name:

```powershell
Get-FileHash -Algorithm SHA256 .\work-charter-dsh-0.2.0-alpha.1.tgz
dsh --version
dsh --profile wcdp-new --from-default-profile web --dump-config
dsh plugin --profile wcdp-new add .\work-charter-dsh-0.2.0-alpha.1.tgz --ignore-scripts
dsh --profile wcdp-new
```

This installs the WCDP bundle over base/Web for Direct work; it does not enable native Team automatically. For Team/Phased, supply the native Team composition described above. Do not reuse a legacy WCDP/SCDP store. Repository archival of SCDP does not migrate an existing Charter or replace its old data.

## Development and evidence

After an authorized dependency installation:

```text
pnpm install --frozen-lockfile --ignore-scripts
pnpm build
pnpm typecheck
pnpm lint
pnpm exec vitest run
pnpm verify:runtime
pnpm verify:client
pnpm release:audit
pnpm pack:check
```

Build emits Node ESM Host, generated read-only Remote, and the DSH lazy-CJS browser factory. Runtime qualification uses keyless deterministic adapters and fresh task-local stores; it does not establish natural-language quality or efficacy. Release qualification additionally installs into a fresh dependency graph, runs the native Host and jsdom Client checks there, and installs the bundle with the official DSH CLI into a fresh Web profile. Host health and authenticated HTTP startup pass. Actual browser UI remains unverified because the available browser tool blocked localhost navigation; jsdom and HTTP checks do not replace it.

The previously published [v0.1.0-alpha.1 release](https://github.com/junwei529/work-charter-dsh/releases/tag/v0.1.0-alpha.1), its DSH/SCDP graph and evidence remain historical, runnable subjects. Their results do not qualify this successor. Legacy audit/source/runtime scripts remain for that historical baseline and are not current package commands.
