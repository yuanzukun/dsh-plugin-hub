import assert from 'node:assert/strict'
import { createHash, randomUUID } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { mkdir, readFile, readdir, writeFile, realpath } from 'node:fs/promises'
import { dirname, join, resolve, relative } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { gunzipSync } from 'node:zlib'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(import.meta.url)
const hash = data => createHash('sha256').update(data).digest('hex')
async function files(directory) {
  const result = []
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name)
    if (entry.isDirectory()) result.push(...await files(path))
    else if (entry.isFile()) result.push(path)
    else throw new Error(`unexpected link in generated output: ${path}`)
  }
  return result
}
export function checkMap(map) {
  assert.equal(map.sourcesContent, undefined, 'source map must not embed source')
  for (const path of [map.sourceRoot, map.file, ...(map.sources ?? [])].filter(Boolean)) {
    assert.ok(!/^(?:[A-Za-z]:|\/|\\|\w+:\/\/)/.test(path), `absolute source path: ${path}`)
    assert.ok(!path.includes('.verification'), 'temporary workspace leaked into source map')
  }
}
export async function audit() {
  const manifest = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'))
  assert.equal(manifest.version, '0.2.0-alpha.1')
  assert.equal(manifest.type, 'module')
  assert.equal(manifest.private, true)
  assert.ok(!Object.keys({ ...manifest.dependencies, ...manifest.peerDependencies, ...manifest.devDependencies }).some(name => name.includes('session-coordinator')))
  const versions = {}, identities = new Map()
  for (const [name, expected] of Object.entries({ ...manifest.dependencies, ...manifest.devDependencies })) {
    let path
    try { path = require.resolve(`${name}/package.json`) } catch {
      let dir = dirname(require.resolve(name))
      for (;;) {
        try { const p = join(dir, 'package.json'); const m = JSON.parse(await readFile(p, 'utf8')); if (m.name === name) { path = p; break } } catch { /* parent */ }
        const parent = dirname(dir); assert.notEqual(parent, dir, `manifest missing: ${name}`); dir = parent
      }
    }
    const actual = JSON.parse(await readFile(path, 'utf8'))
    assert.equal(actual.version, expected, `${name} version drift`)
    versions[name] = actual.version
    if (name.startsWith('@deepseek-ai/dsh-')) {
      const local = createRequire(path)
      for (const singleton of ['@deepseek-ai/cordis', 'zod', 'react']) {
        try {
          const id = await realpath(local.resolve(singleton))
          const set = identities.get(singleton) ?? new Set(); set.add(id); identities.set(singleton, set)
        } catch { /* absent dependency does not introduce an identity */ }
      }
    }
  }
  for (const [name, paths] of identities) assert.equal(paths.size, 1, `${name} has multiple runtime identities`)
  const generated = await files(join(root, 'lib'))
  for (const file of generated) {
    if (!/\.(?:js|map|ts)$/.test(file)) continue
    const text = await readFile(file, 'utf8')
    assert.ok(!text.includes('session-coordinator-dsh'), `retired dependency in ${file}`)
    if (file.endsWith('.map')) checkMap(JSON.parse(text))
  }
  const host = await import(pathToFileURL(join(root, 'lib/index.js')).href)
  const types = await import(pathToFileURL(join(root, 'lib/types/types.js')).href)
  assert.equal(types.WORK_CHARTER_CONTRACT_VERSION, 2)
  assert.equal(typeof host.default, 'function')
  const client = await readFile(join(root, 'lib/client.js'), 'utf8')
  assert.ok(client.startsWith('window.__ModuleLoader__.load('))
  const lock = await readFile(join(root, 'pnpm-lock.yaml'))
  assert.ok(!lock.includes(Buffer.from('session-coordinator-dsh')))
  return { status: 'PASS', package: `${manifest.name}@${manifest.version}`, versions, identities: Object.fromEntries([...identities].map(([name, paths]) => [name, [...paths]])), lockSha256: hash(lock), generatedFiles: generated.length }
}
function archiveEntries(buffer) {
  const tar = gunzipSync(buffer), rows = []
  for (let offset = 0; offset + 512 <= tar.length;) {
    const header = tar.subarray(offset, offset + 512)
    if (header.every(value => value === 0)) break
    const name = header.subarray(0, 100).toString().replace(/\0.*$/s, '')
    const size = parseInt(header.subarray(124, 136).toString().replace(/\0.*$/s, '').trim(), 8)
    assert.ok(Number.isFinite(size) && size >= 0)
    assert.ok(name.startsWith('package/') && !name.includes('..') && !name.includes('\\'))
    const type = header[156]
    assert.ok(type === 0 || type === 48, 'only ordinary packaged files are permitted')
    rows.push({ path: name.slice(8), bytes: tar.subarray(offset + 512, offset + 512 + size) })
    offset += 512 + Math.ceil(size / 512) * 512
  }
  return rows
}
export async function pack() {
  const result = await audit()
  const destination = join(root, '.verification/successor-0.2.0-alpha.1/package', randomUUID())
  await mkdir(destination, { recursive: true })
  const pnpm = join(root, '.verification/corepack/v1/pnpm/11.7.0/bin/pnpm.cjs')
  execFileSync(process.execPath, [pnpm, '--config.ignore-scripts=true', 'pack', '--pack-destination', destination], { cwd: root, stdio: 'pipe' })
  const name = (await readdir(destination)).find(file => file.endsWith('.tgz'))
  assert.ok(name)
  const bytes = await readFile(join(destination, name))
  const rows = archiveEntries(bytes)
  for (const required of ['package.json', 'lib/index.js', 'lib/types/types.js', 'lib/types/role-models.js', 'lib/client.js', 'assets/work-charter-dsh.md', 'assets/role-models.default.yaml', 'cordis.patch.yml']) assert.ok(rows.some(row => row.path === required), `missing ${required}`)
  const consumer = join(destination, 'consumer')
  for (const row of rows) {
    assert.ok(!/^(?:tests|scripts|src|\.verification)\//.test(row.path), 'development source leaked into package')
    const path = join(consumer, row.path); await mkdir(dirname(path), { recursive: true }); await writeFile(path, row.bytes)
  }
  execFileSync(process.execPath, ['--input-type=module', '-e', 'const h = await import("./lib/index.js"); const t = await import("./lib/types/types.js"); if (typeof h.default !== "function" || t.WORK_CHARTER_CONTRACT_VERSION !== 2) throw Error("consumer import failed")'], { cwd: consumer, stdio: 'pipe' })
  const evidence = { ...result, archive: relative(root, join(destination, name)), sha256: hash(bytes), bytes: bytes.length,
    files: rows.map(row => ({ path: row.path, bytes: row.bytes.length, sha256: hash(row.bytes) })), consumer: 'extracted tarball imports using approved parent dependency graph; not an independent fresh installation' }
  await writeFile(join(destination, 'result.json'), JSON.stringify(evidence, null, 2))
  return { status: 'PASS', archive: evidence.archive, sha256: evidence.sha256, files: rows.length, lockSha256: result.lockSha256 }
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (process.argv[2] === 'normalize') {
    for (const path of (await files(join(root, 'lib'))).filter(path => path.endsWith('.map'))) {
      const map = JSON.parse(await readFile(path, 'utf8')); if (map.sourceRoot === '') delete map.sourceRoot
      await writeFile(path, JSON.stringify(map))
    }
  } else if (process.argv[2] === 'audit') console.log(JSON.stringify(await audit()))
  else if (process.argv[2] === 'pack') console.log(JSON.stringify(await pack()))
  else throw new Error('expected normalize, audit or pack')
}
