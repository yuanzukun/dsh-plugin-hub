import assert from 'node:assert/strict'
import { mkdir, writeFile, readFile } from 'node:fs/promises'
import { dirname as dirnameOf, join, resolve } from 'node:path'
import { randomUUID } from 'node:crypto'
import { Context } from '@deepseek-ai/cordis'
import { LlmAdapter, ReasoningEffortId } from '@deepseek-ai/dsh-llm'
import { SessionId } from '@deepseek-ai/dsh-session'
import { remoteMethods } from '@deepseek-ai/dsh-typert-protocol'
import Wcdp from '../lib/index.js'

const root = resolve('.verification/successor-0.2.0-alpha.1/runtime', randomUUID())
await mkdir(root, { recursive: true })
const calls = [], errors = [], contexts = []
const holds = new Map()
let ctx
const frozen = { provider: 'fixture-role', model: 'role-model', parameters: { reasoning_effort: 'high', max_output_tokens: 512 } }
class Adapter extends LlmAdapter {
  resolveModel(provider, id) { return Promise.resolve({ provider, id, name: id, reasoning: { efforts: [{ id: ReasoningEffortId('high'), name: 'High' }] } }) }
  async *stream(options) {
    calls.push({ provider: options.provider, model: options.model, reasoningEffort: options.reasoningEffort, maxTokens: options.maxTokens })
    await holds.get(options.model)?.promise
    yield { type: 'block-start', index: 0, blockType: 'text' }
    yield { type: 'text-delta', index: 0, text: 'deterministic fixture complete' }
    yield { type: 'block-end', index: 0, block: { type: 'text', text: 'deterministic fixture complete' } }
    yield { type: 'finish', reason: { kind: 'stop' } }
  }
}
async function runtime(scope, team) {
  const ctx = new Context()
  for (const [name, config] of [
    ['session-projection'], ['session-persistence-jsonl', { root: join(root, scope, 'sessions'), compression: 'none' }],
    ['session'], ['session-query'], ['agent'], ['llm'], ['system-prompt'], ['tools', { mode: 'native' }], ['skill'],
    ['storage'], ['storage-json', { root: join(root, scope, 'storage') }], ['storage-domain', { backend: 'json' }],
    ['agent-loop', { agents: [], maxParallelToolCalls: 1 }],
    ...(team ? [['subagent'], ['subagent-spawn-in-process', { providerName: 'spawn' }], ['experimental-agent-team']] : []),
  ]) {
    const module = await import(`@deepseek-ai/dsh-${name}`)
    await ctx.plugin(module.default ?? module, config)
  }
  ctx.llm.registerAdapter(['fixture-lead', 'fixture-role'], new Adapter())
  ctx.on('agent/error', ({ error }) => { errors.push(String(error)) })
  try { await ctx.plugin(Wcdp) } catch (error) { await ctx.fiber.dispose(); throw error }
  return ctx
}
function input(lead, arrangement = 'team') {
  return {
    charterId: `wc_${randomUUID()}`, arrangement, continuity: 'durable', controlLocator: `fixture:${lead.id}`, managedWorkstream: 'runtime fixture',
    authority: { revision: 0, reference: 'external fixture authority', authorizedActions: ['fixture'], prohibitedActions: ['external effects'] },
    contract: { outcome: 'native successor works', scope: ['fixture'], nonGoals: ['efficacy claim'], confirmedContract: ['isolated native Team'], necessaryGuardrails: ['one writer'], workingProposal: [], openDecisions: [], acceptance: ['owner disposition'], stopConditions: ['unknown delivery'] },
    roles: arrangement === 'direct' ? [{ role: 'primary', name: 'lead' }] : [{ role: 'planner', name: 'lead' }, { role: 'executor', name: 'executor', model: frozen }, { role: 'reviewer', name: 'reviewer', model: frozen }],
  }
}
async function command(actor, row, command) {
  return (await ctx.workCharter.transitionCharter(actor, { charterId: row.id, expectedRevision: row.revision, command })).charter
}
async function approve(actor, row) {
  row = await command(actor, row, { kind: 'propose' })
  return command(actor, row, { kind: 'approve', approvalRef: 'fixture/user-authority' })
}
async function idle() { await Promise.all(ctx.agents.list().map(agent => agent.whenIdle())) }
async function provision(lead, row, role, settle = true) {
  const outcome = await ctx.tools.execute({ callId: `fixture-${randomUUID()}`, name: 'work_charter_provision_role', agent: lead,
    arguments: { charter_id: row.id, expected_revision: row.revision, role, prompt: 'Complete this deterministic fixture.' }, signal: AbortSignal.timeout(10000) })
  assert.equal(outcome.isError, false, JSON.stringify(outcome))
  if (settle) await idle()
  return ctx.workCharter.getCharter({ charterId: row.id })
}
async function inspect(id, charterId) {
  const observed = await ctx.sessionQuery.observeSession(id)
  try {
    const events = observed.events
    assert.ok(JSON.stringify(events).includes(charterId), 'snapshot reconstructable from Session log')
    assert.ok(JSON.stringify(events).includes('role-model'), 'effective role model logged')
    contexts.push({ sessionId: id, eventCount: events.length, charterFound: true, roleModelFound: true })
  } finally { observed[Symbol.dispose]() }
}
try {
  ctx = await runtime('direct', false)
  const direct = await ctx.agentLoop.create(SessionId(`direct-${randomUUID()}`), { provider: 'fixture-lead', model: 'lead-model' })
  let d = (await ctx.workCharter.createCharter(direct, input(direct, 'direct'))).charter
  d = await approve(direct, d)
  d = await command(direct, d, { kind: 'activate' })
  assert.equal((await ctx.workCharter.health()).team, 'unavailable')
  d = await command(direct, d, { kind: 'close', reference: 'direct fixture accepted' })
  assert.equal(d.state, 'closed')
  await ctx.fiber.dispose()
  const legacyPath = join(root, 'legacy', 'storage', 'work_charter_dsh.json')
  await mkdir(dirnameOf(legacyPath), { recursive: true })
  const legacy = JSON.parse(await readFile(join(root, 'direct', 'storage', 'work_charter_dsh.json'), 'utf8'))
  legacy.global = { state: 'ready', schemaVersion: 1 }
  const legacyBytes = JSON.stringify(legacy)
  await writeFile(legacyPath, legacyBytes)
  await assert.rejects(runtime('legacy', false))
  assert.equal(await readFile(legacyPath, 'utf8'), legacyBytes, 'incompatible store must remain byte-identical')

  ctx = await runtime('team', true)
  const leadId = SessionId(`team-${randomUUID()}`)
  const lead = await ctx.agentLoop.create(leadId, { provider: 'fixture-lead', model: 'lead-model' })
  let row = (await ctx.workCharter.createCharter(lead, input(lead))).charter
  row = await approve(lead, row)
  row = await provision(lead, row, 'executor')
  row = await provision(lead, row, 'reviewer')
  const childId = row.roles.find(role => role.role === 'executor').sessionId
  await inspect(childId, row.id)
  const before = calls.filter(call => call.provider === 'fixture-role').length
  assert.equal(before, 2)
  assert.deepEqual(remoteMethods(ctx.workCharter).map(marker => marker.exportName ?? marker.method), ['health', 'chartersList', 'chartersGet', 'sessionChartersList'])
  await ctx.fiber.dispose()

  ctx = await runtime('team', true)
  const resumed = await ctx.agentLoop.resume(ctx, { resumeSessionId: leadId, agentOptions: { provider: 'fixture-lead', model: 'changed-default' } })
  const restored = await ctx.workCharter.getCharter({ charterId: row.id })
  assert.deepEqual(restored.roles, row.roles)
  const delivered = await ctx.workCharter.submitNotice(resumed.agent, { charterId: row.id, expectedRevision: restored.revision,
    notice: { id: 'fact-on-restart', kind: 'fact', checkpoint: 'restart', subject: 'restart fixture', summary: 'Continue deterministic fixture', author: 'planner', recipient: 'executor', findings: [], evidenceIds: [] },
  }, AbortSignal.timeout(10000))
  assert.ok(['accepted', 'queued'].includes(delivered.charter.notices[0].delivery.state))
  await idle()
  assert.equal(calls.filter(call => call.provider === 'fixture-role').length, before + 1)
  for (const call of calls.filter(call => call.provider === 'fixture-role')) assert.deepEqual(call, { provider: 'fixture-role', model: 'role-model', reasoningEffort: 'high', maxTokens: 512 })
  await inspect(childId, row.id)
  assert.deepEqual(errors, [])

  // Inject loss of the successful native reply, not failure of native delivery.
  const teamService = ctx.agentTeams
  const nativeSend = teamService.sendMessage.bind(teamService)
  let acceptedBeforeLoss
  teamService.sendMessage = async (...args) => { acceptedBeforeLoss = await nativeSend(...args); throw new Error('fixture: native reply lost after delivery') }
  let uncertain
  try {
    uncertain = await ctx.workCharter.submitNotice(resumed.agent, { charterId: row.id, expectedRevision: delivered.charter.revision,
      notice: { id: 'lost-reply', kind: 'fact', checkpoint: 'lost-reply', subject: 'lost response', summary: 'one send only', author: 'planner', recipient: 'executor', findings: [], evidenceIds: [] },
    }, AbortSignal.timeout(10000))
  } finally { teamService.sendMessage = nativeSend }
  assert.equal(uncertain.charter.notices.at(-1).delivery.state, 'unknown')
  await idle()
  await ctx.fiber.dispose()
  ctx = await runtime('team', true)
  const afterLoss = await ctx.agentLoop.resume(ctx, { resumeSessionId: leadId, agentOptions: { provider: 'fixture-lead', model: 'changed-default' } })
  const unknownRestored = await ctx.workCharter.getCharter({ charterId: row.id })
  assert.equal(unknownRestored.notices.at(-1).delivery.state, 'unknown')
  await assert.rejects(command(afterLoss.agent, unknownRestored, { kind: 'resume', observation: 'cannot assume delivered' }), /uncertain handoff/)
  await assert.rejects(ctx.workCharter.submitNotice(afterLoss.agent, { charterId: row.id, expectedRevision: unknownRestored.revision,
    notice: { id: 'lost-reply', kind: 'fact', checkpoint: 'lost-reply', subject: 'lost response', summary: 'must not resend', author: 'planner', recipient: 'executor', findings: [], evidenceIds: [] },
  }, AbortSignal.timeout(10000)), /uncertain handoff/)
  const reconciled = await command(afterLoss.agent, unknownRestored, { kind: 'reconcile-notice', noticeId: 'lost-reply', state: acceptedBeforeLoss.status, messageId: acceptedBeforeLoss.messageId, reference: 'fixture retained exact successful native receipt before injected loss' })
  assert.deepEqual(reconciled.notices.at(-1).deliveryHistory.map(item => item.state), ['prepared', 'unknown', acceptedBeforeLoss.status])
  assert.equal(reconciled.state, 'paused')

  // Keep deterministic role turns alive while exercising actual native actors,
  // peer transport, R review, P acceptance and O phase acceptance on one roster.
  const o = await ctx.agentLoop.create(SessionId(`phase-${randomUUID()}`), { provider: 'fixture-lead', model: 'O-model' })
  const phased = input(o)
  phased.arrangement = 'phased'
  phased.roles = [{ role: 'orchestrator', name: 'lead' }, ...['planner', 'executor', 'reviewer'].map(role => ({ role, name: role, model: { ...frozen, model: `phase-${role}` } }))]
  for (const role of ['planner', 'executor', 'reviewer']) {
    let release; const promise = new Promise(resolve => { release = resolve })
    holds.set(`phase-${role}`, { promise, release })
  }
  let phase = await approve(o, (await ctx.workCharter.createCharter(o, phased)).charter)
  for (const role of ['planner', 'executor', 'reviewer']) phase = await provision(o, phase, role, false)
  const actor = role => ctx.agents.get(phase.roles.find(binding => binding.role === role).sessionId)
  const send = async (from, notice) => {
    phase = (await ctx.workCharter.submitNotice(from, { charterId: phase.id, expectedRevision: phase.revision, notice }, AbortSignal.timeout(10000))).charter
    assert.ok(['accepted', 'queued', 'local'].includes(phase.notices.at(-1).delivery.state))
  }
  const base = { checkpoint: 'phase-implementation', subject: 'phase implementation', summary: 'fixture result with bounded observations', findings: [], evidenceIds: [] }
  await assert.rejects(ctx.workCharter.submitNotice(o, { charterId: phase.id, expectedRevision: phase.revision, notice: { ...base, id: 'bypass', kind: 'fact', author: 'orchestrator', recipient: 'executor' } }, AbortSignal.timeout(10000)), /bypass/)
  const mandate = { ...base, checkpoint: 'mandate-v1', subject: 'O direction' }
  await send(o, { ...mandate, id: 'mandate', kind: 'result', author: 'orchestrator', recipient: 'orchestrator', reviewer: 'reviewer' })
  await send(o, { ...mandate, id: 'mandate-review-request', kind: 'review-request', author: 'orchestrator', recipient: 'reviewer', resultId: 'mandate' })
  await send(actor('reviewer'), { ...mandate, id: 'mandate-review', kind: 'review', author: 'reviewer', recipient: 'orchestrator', resultId: 'mandate', reviewVerdict: 'pass' })
  await send(o, { ...mandate, id: 'mandate-accept', kind: 'disposition', author: 'orchestrator', recipient: 'orchestrator', resultId: 'mandate', verdict: 'accepted' })
  await send(actor('executor'), { ...base, id: 'execution', kind: 'result', author: 'executor', recipient: 'planner', reviewer: 'reviewer' })
  await send(actor('reviewer'), { ...base, id: 'review', kind: 'review', author: 'reviewer', recipient: 'executor', resultId: 'execution', reviewVerdict: 'pass' })
  await send(actor('planner'), { ...base, id: 'P-accept', kind: 'disposition', author: 'planner', recipient: 'executor', resultId: 'execution', verdict: 'accepted' })
  const top = { ...base, checkpoint: 'phase-outcome', subject: 'phase outcome' }
  await send(actor('planner'), { ...top, id: 'phase-result', kind: 'result', author: 'planner', recipient: 'orchestrator' })
  await send(o, { ...top, id: 'O-accept', kind: 'disposition', author: 'orchestrator', recipient: 'planner', resultId: 'phase-result', verdict: 'accepted' })
  for (const hold of holds.values()) hold.release()
  holds.clear()
  await idle()
  phase = await command(o, phase, { kind: 'close', reference: 'O accepted exact phase result' })
  assert.equal(phase.state, 'closed')
  assert.deepEqual(errors, [])
  const result = { status: 'PASS', scope: 'built WCDP Direct, legacy-store rejection without writes, Team first call and cold resume, native lost-reply restart/reconciliation, Phased E/R/P/O acceptance, logged context and read-only Remote', root, charterId: row.id, phaseCharterId: phase.id, phaseNotices: phase.notices.map(n => ({ id: n.id, author: n.author, recipient: n.recipient, delivery: n.delivery })), leadId, childId, calls, contexts, errors, delivery: delivered.charter.notices[0].delivery, recoveredDelivery: reconciled.notices.at(-1).deliveryHistory }
  await writeFile(join(root, 'result.json'), JSON.stringify(result, null, 2))
  console.log(JSON.stringify(result))
} catch (error) {
  await writeFile(join(root, 'failure.json'), JSON.stringify({ error: String(error), stack: error.stack, calls, contexts, errors }, null, 2))
  throw error
} finally { for (const hold of holds.values()) hold.release(); await ctx?.fiber.dispose() }
