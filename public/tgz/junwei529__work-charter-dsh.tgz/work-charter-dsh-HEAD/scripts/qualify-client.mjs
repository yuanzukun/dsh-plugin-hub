import assert from 'node:assert/strict'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { readFile, mkdir, writeFile } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { randomUUID } from 'node:crypto'
import { Context } from '@deepseek-ai/cordis'
import { JSDOM } from 'jsdom'
import React, { act } from 'react'
import { createRoot } from 'react-dom/client'

const root = resolve('.verification/successor-0.2.0-alpha.1/client', randomUUID())
await mkdir(root, { recursive: true })
const dom = new JSDOM('<!doctype html><html><body><div id="app"></div></body></html>', { url: 'http://fixture.local' })
globalThis.window = dom.window
globalThis.document = dom.window.document
globalThis.HTMLElement = dom.window.HTMLElement
globalThis.IS_REACT_ACT_ENVIRONMENT = true
const require = createRequire(import.meta.url)
async function load(path) {
  let packet
  const bridge = { load: value => { packet = value } }
  dom.window.__ModuleLoader__ = bridge
  vm.runInNewContext(await readFile(path, 'utf8'), { window: dom.window, document: dom.window.document, console, AbortController, setTimeout, clearTimeout, queueMicrotask, URL, TextEncoder, TextDecoder })
  assert.ok(packet?.factory)
  return packet.factory(require)
}
const ctx = new Context()
let reactRoot
let mounts = 0, reads = 0
const rows = [{ id: 'wc_12345678-1234-4234-8234-123456789abc', arrangement: 'direct', target: { kind: 'session', sessionId: 'fixture' }, state: 'active', contractState: 'approved', revision: 3, managedWorkstream: 'Client fixture', authority: { revision: 0 }, roles: [], notices: [], evidence: [] }]
const remote = {
  health: async () => ({ ok: true, value: { status: 'ok' } }),
  chartersList: async () => { reads++; return { ok: true, value: { ok: true, value: rows } } },
  sessionChartersList: async () => { reads++; return { ok: true, value: { ok: true, value: rows } } },
}
try {
  const native = await load(join(dirname(require.resolve('@deepseek-ai/dsh-client-ui-renderer/package.json')), 'lib/client.js'))
  const slots = new native.SlotRegistry(ctx)
  const frame = () => null
  // The fixture supplies only seat declarations normally owned by base UI.
  slots.register({ name: 'root', children: {
    'sidebar.footer.action': { kind: 'list', scope: 'root' },
    'conversation.session.header.actions': { kind: 'list', scope: 'session' },
    'shell.overlay': { kind: 'list', scope: 'root' },
  } }, frame)
  slots.register({ name: 'sidebar.footer.action', id: 'native-existing' }, () => null)
  ctx.provide('remote', { $mount: async () => { mounts++; return () => { mounts-- } } })
  ctx.provide('remote.workCharter', remote)
  const client = await load(resolve('lib/client.js'))
  let fork = await ctx.plugin(client)
  const expected = ['sidebar.footer.action', 'conversation.session.header.actions', 'shell.overlay']
  for (const slot of expected) assert.equal(slots.entries(slot).filter(e => e.options.id === 'work-charter-dsh').length, 1)
  assert.equal(slots.entries('root')[0].component, frame)
  assert.equal(slots.entries('sidebar.footer.action').filter(e => e.options.id === 'native-existing').length, 1)
  const action = slots.entries('sidebar.footer.action').find(e => e.options.id === 'work-charter-dsh')
  const session = slots.entries('conversation.session.header.actions').find(e => e.options.id === 'work-charter-dsh')
  const overlay = slots.entries('shell.overlay').find(e => e.options.id === 'work-charter-dsh')
  reactRoot = createRoot(document.getElementById('app'))
  await act(async () => {
    reactRoot.render(React.createElement(React.Fragment, {},
      React.createElement(action.component, { ...action.inject(), wide: true }),
      React.createElement(session.component, { ...session.inject(), sessionId: 'fixture' }),
      React.createElement(overlay.component, overlay.inject())))
  })
  assert.ok(document.body.textContent.includes('WC 1'))
  await act(async () => { document.querySelector('[data-testid="work-charter-dsh.action"]').click() })
  assert.ok(document.body.textContent.includes('Client fixture'))
  assert.ok(document.body.textContent.includes('approved'))
  assert.equal(document.querySelectorAll('form,textarea,select,input:not([aria-label="Filter Charters"])').length, 0, 'overlay exposes no mutation form')
  await writeFile(join(root, 'rendered.html'), dom.serialize())
  await act(async () => { reactRoot.unmount() })
  reactRoot = undefined
  await fork.dispose()
  assert.equal(mounts, 0)
  for (const slot of expected) assert.equal(slots.entries(slot).filter(e => e.options.id === 'work-charter-dsh').length, 0)
  assert.equal(slots.entries('root')[0].component, frame)
  fork = await ctx.plugin(client)
  assert.equal(mounts, 1)
  for (const slot of expected) assert.equal(slots.entries(slot).filter(e => e.options.id === 'work-charter-dsh').length, 1)
  await fork.dispose()
  assert.equal(mounts, 0)
  const result = { status: 'PASS', scope: 'built lazy Client factory, actual native SlotRegistry/Cordis lifecycle, React DOM actions/overlay, native-owner coexistence and unload/reload', root, reads, outstandingRemoteMounts: mounts, limitations: 'jsdom; fixture readonly RPC and base seat declarations; no real browser or network Gateway' }
  await writeFile(join(root, 'result.json'), JSON.stringify(result, null, 2))
  console.log(JSON.stringify(result))
} catch (error) {
  await writeFile(join(root, 'failure.json'), JSON.stringify({ error: String(error), stack: error.stack }, null, 2)); throw error
} finally {
  if (reactRoot) await act(async () => { reactRoot.unmount() })
  await ctx.fiber.dispose(); dom.window.close()
}
