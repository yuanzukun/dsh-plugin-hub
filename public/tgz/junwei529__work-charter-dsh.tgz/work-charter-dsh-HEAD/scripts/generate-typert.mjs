import { cp, mkdir, readFile, readdir, writeFile } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { WorkspaceTypertGenerator } from '@deepseek-ai/dsh-typert-generator'

const packageId = 'work-charter-dsh'
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
// A fresh generator workspace preserves prior failed evidence and avoids cleanup
// being coupled to source generation. It never becomes a second source owner.
const workspace = join(root, '.verification', 'successor-0.2.0-alpha.1', 'typert', `${Date.now()}`)
const mirror = join(workspace, 'packages', packageId)
const protocol = join(workspace, 'packages', 'dsh-typert-protocol')
await mkdir(mirror, { recursive: true })
await cp(join(root, 'src'), join(mirror, 'src'), { recursive: true })
await cp(join(root, 'package.json'), join(mirror, 'package.json'))
await mkdir(join(protocol, 'src'), { recursive: true })
for (const name of await readdir(join(root, 'node_modules/@deepseek-ai/dsh-typert-protocol/lib/types'))) {
  if (name.endsWith('.d.ts')) await cp(join(root, 'node_modules/@deepseek-ai/dsh-typert-protocol/lib/types', name), join(protocol, 'src', name.replace('.d.ts', '.ts')))
}
await cp(join(root, 'node_modules/@deepseek-ai/dsh-typert-protocol/package.json'), join(protocol, 'package.json'))
const options = {
  target: 'ES2024', module: 'ESNext', moduleResolution: 'Bundler',
  strict: true, noImplicitAny: true, skipLibCheck: true, allowImportingTsExtensions: true,
  noEmit: true, composite: true, baseUrl: '.', ignoreDeprecations: '6.0',
  types: ['node'],
}
async function json(path, value) { await writeFile(path, JSON.stringify(value, null, 2)) }
await json(join(workspace, 'tsconfig.host.json'), {
  files: [], compilerOptions: { ...options, paths: { '@deepseek-ai/dsh-typert-protocol': ['packages/dsh-typert-protocol/src/index.ts'] } },
  references: [{ path: `packages/${packageId}` }, { path: 'packages/dsh-typert-protocol' }],
})
await json(join(mirror, 'tsconfig.json'), {
  compilerOptions: { ...options, jsx: 'react-jsx', paths: { '@deepseek-ai/dsh-typert-protocol': ['../dsh-typert-protocol/src/index.ts'] } },
  include: ['src/*.ts'],
})
await json(join(protocol, 'tsconfig.json'), { compilerOptions: options, include: ['src'] })
const artifact = new WorkspaceTypertGenerator(workspace).generate([packageId], ['host'])
  .find(item => item.package === packageId && item.face === 'host')
if (!artifact?.remote) throw new Error('required Host/Remote artifacts were not generated')
const output = join(root, 'lib')
await mkdir(output, { recursive: true })
await writeFile(join(output, 'typert.host.js'), artifact.js)
await writeFile(join(output, 'typert.host.d.ts'), artifact.dts)
await writeFile(join(output, 'typert.remote-client.js'), artifact.remote.js.replaceAll('z.object({', 'z.strictObject({'))
await writeFile(join(output, 'typert.remote-client.d.ts'), artifact.remote.dts)
const sourceMap = JSON.parse(artifact.remote.dtsMap)
delete sourceMap.sourcesContent
await writeFile(join(output, 'typert.remote-client.d.ts.map'), JSON.stringify(sourceMap))
const manifest = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'))
console.log(`Generated ${manifest.name}@${manifest.version} Host and read-only Remote interfaces`)
