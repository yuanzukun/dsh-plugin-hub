# 面向 DeepSeek Harness 的 Work Charter

[English](README.md)

WCDP 把已安装的 Codex Work Charter **0.9.1** 适配到 DSH，记录关键工作的目标、授权、责任、写入者、证据、验收和恢复位置。普通稳定工作无需额外 Charter 仪式。

**0.2.0-alpha.1** 版本使用公开合同 **2**、逻辑存储 schema **2**，目标 DSH 为 **0.1.7-rc.2**，精确 commit 为 `477b4f420553e8a52c2fbccc464d7561b239c443`。通过 [GitHub Pre-release](https://github.com/junwei529/work-charter-dsh/releases/tag/v0.2.0-alpha.1) 分发；package 保留 `private: true`，不发布 npm。范围以 [SPEC](docs/SPEC.md#successor-design-work-charter-091-and-scdp-retirement) 为准，实际发布状态见 [STATUS](docs/STATUS.md)，测试结果和限制见 [VERIFICATION](docs/VERIFICATION.md)。

## SCDP 退役后的分工

候选版移除了 `session-coordinator-dsh` 运行依赖。DSH 原生 Team 负责成员、持久子角色、消息投递和重启；WCDP 只保留 Charter 专属的合同/授权/证据状态、写入观察、Result Notice、独立审查与验收、角色模型冻结和未知投递停步。

| 安排 | 责任 | 原生范围 |
|---|---|---|
| Direct | primary 和适用的独立 R | primary Session；需要 R 时使用同一原生 Team |
| Team | P/E 和适用的独立 R | P 是 Lead，其他为平级 teammate |
| Phased | O/P/E 和适用的独立 R | O 是 Lead；P 管理 E/R 工作及验收 |

连续性（current-task/durable）与安排分开；合同批准与 active/paused/closed 运行状态分开。R 提供技术审查，primary/P/O 负责接受结果。已有独立根 Session 的合并、跨 Team、多工作树协调不在此版范围内。

Host 校验 WCDP 自身操作，Client 只读。WCDP 不锁文件、不授予权限、不证明人工批准，也不强制约束所有 DSH 工具。原生投递成功不等于模型已阅读或结果已验收。

## 运行与开发

使用全新的隔离 profile 和成对的 Session 日志/Charter store；保持精确 DSH 版本、Cordis `4.0.4` 和 React `18.3.1` 的单一身份。默认 bundle patch 只挂载 WCDP，Direct 可不加载 Team。

多角色 profile 还需同版本 `dsh-subagent`、`dsh-subagent-spawn-in-process`（provider 为 `spawn`）和 `dsh-experimental-agent-team`。WCDP 通过公开 Team 服务创建已批准角色和投递通知；原生 Team 工具是 profile 的可选能力。不要未经安装授权修改现有 profile。

从 `work_charter_status` 和 [打包 Skill](assets/work-charter-dsh.md) 开始；其中提供五个工具的 JSON 合同。新角色按 0.9.1 的优先级选取完整模型对象，在首次调用前冻结；当前适配支持 `reasoning_effort` 和 `max_output_tokens`，不能支持的参数明确报错，不静默丢弃。现有 Lead 模型由 Host 保持。

缺失配套 Charter 数据时，带 WCDP 标记的子角色停止调用。未知投递禁止盲目重发；只有责任人核对原生日志后才能记录恢复证据，并显式恢复运行。旧 schema 不自动迁移，旧 profile/store 和发布证据保留。

### 安装到新 profile

使用已有的官方 `@deepseek-ai/dsh@0.1.7-rc.2` 与 pnpm `11.7.0`。从 Release 页面下载版本 tarball 和 SHA-256 校验文件，核对校验值后选择未使用过的 profile 名称：

```powershell
Get-FileHash -Algorithm SHA256 .\work-charter-dsh-0.2.0-alpha.1.tgz
dsh --version
dsh --profile wcdp-new --from-default-profile web --dump-config
dsh plugin --profile wcdp-new add .\work-charter-dsh-0.2.0-alpha.1.tgz --ignore-scripts
dsh --profile wcdp-new
```

这条路径在 base/Web 上安装 WCDP bundle，供 Direct 使用，不自动启用 Team。Team/Phased 还需要上文所述原生 Team composition。不要复用旧 WCDP/SCDP store；SCDP 仓库归档也不等于迁移已有 Charter 或替换其数据。

开发验证顺序为 `pnpm build`、`pnpm typecheck`、`pnpm lint`、`pnpm exec vitest run`、`pnpm verify:runtime`、`pnpm verify:client`、`pnpm release:audit`、`pnpm pack:check`。发布验证另建干净依赖图，在其中运行原生 Host 和 jsdom Client 检查，并通过官方 DSH CLI 把 bundle 安装进新 Web profile；Host health 和认证 HTTP 启动检查通过。浏览器工具阻止了 localhost 导航，实际浏览器 UI 仍未验证，jsdom 和 HTTP 不能替代它。无密钥确定性探针也不代表自然语言效果已验证。

旧 [v0.1.0-alpha.1](https://github.com/junwei529/work-charter-dsh/releases/tag/v0.1.0-alpha.1) 及其 DSH/SCDP 图是独立的历史发布对象，原有 PASS 不转移到候选版。旧 audit/source/runtime 脚本只服务其历史基线，不再作为当前 package 命令。
