# Work Charter for DSH

Portable semantics: installed Codex Work Charter 0.9.1, arrangement-v1. WCDP contract 2 is a Harness adaptation, not an authority provider. It checks its own records and transitions. It cannot lock files, enforce all native tools, grant permissions, prove human approval, or turn transport receipts into acceptance.

## Choose proportionately and reuse existing work

At entry or material change, use known context to choose the least sufficient Direct, Team or Phased arrangement. Ordinary stable Direct work requires no Skill ceremony, carrier, role, questionnaire or approval. Read `work_charter_status` when an applicable approved Charter exists or a concrete assessment/recovery need justifies it. Reuse its approval and frozen bindings. Loading this Skill does not adopt a Charter. The user owns adoption and material coordination changes; do not ask again for authority already covering the action.

- Direct: primary in one Session, optional independent R in the same native Team when actually needed.
- Team: P (native Lead), E and applicable independent R.
- Phased: O (native Lead), P, E and applicable independent R in one flat native Team. P owns Definition and implementation/review acceptance; O owns direction and phase acceptance. O does not bypass P to direct E/R. Only native Lead can provision the approved set; P has no nested-spawn capability.
- Continuity is separate: current-task or durable. Durable and Team/Phased work needs a recoverable `controlLocator`.

Do not attach existing independent roots or coordinate across Teams/worktrees. Team shares a process and checkout; role names are not technical isolation. Existing roles and frozen model objects are not silently replaced. Legacy contracts/stores stay on their original profile unless an explicit per-subject transition is approved.

## Contract, work and evidence

Separate Confirmed Contract, Necessary Guardrails, Working Proposal and Open Decisions. Record intended outcome, scope, exclusions, acceptance, stop conditions, authority reference/actions, responsibilities and recovery location. Agent-proposed mechanisms remain replaceable unless a demonstrated boundary or explicit contract requires them.

Contract state is draft/proposed/approved/superseded; run state is active/paused/closed. Create does not approve. Record `approve` only with an actual external approval reference; the Host cannot attest a human decision. Work remains inside existing permissions. Resolve material decisions before activation or dependent handoff. Use the returned revision for every mutation.

One writer observation names a bound non-R carrier, exact workspace and observed ownership. Revalidate actual dirty state and ownership before writing. Record `writer-drift` and stop affected work when uncertain. Release the writer before independent review. The Host record is not a filesystem lock.

Declare evidence by stable subject/checkpoint and its actual consumption point. Record passed/failed/invalid/unknown separately from budget consumption. A failed preflight does not itself consume an undispatched opportunity. Consume exactly once at the declared real point; retain its reference and all failed evidence. Corrected work does not reset budgets. Contract revisions preserve prior contracts, roles, evidence and notices; new authority requires new material result/acceptance.

## Models and dispatch

The complete provider/model/parameters object is selected by frozen delivery, confirmed task object, exact selected file (otherwise existing user file), then package defaults; only primary may use host fallback. The selected file is validated as a whole before lookup. v2 uses arrangement then general roles; v1 new Team/Phased uses l3/l4 compatibility, while new Direct requires l0/l1/l2 effective values to agree (including missing values). Ambiguity requires the user; never pick a convenient level or silently skip the file.

The loader reads inert YAML only: no directives, tags, aliases, anchors, merge keys, secrets, endpoints or executable strings. Portable unused-role JSON settings are retained and validated. This DSH adapter supports selected `reasoning_effort` and `max_output_tokens`; unsupported selected parameters stop dispatch instead of being dropped. The current Lead's model stays host-owned; new native roles freeze their complete object before provisioning. Their first and resumed calls use the public request hook; the roster's displayed inherited model is not actual-call proof. Missing paired Charter storage stops a WCDP-marked carrier.

## Results, review and recovery

Send a complete Result Notice with subject, checkpoint, summary, findings, evidence ids, recipient and any next action. E returns to P; Phased P returns to O only after latest E outcomes are accepted and their dispositions delivered. The Host freezes the current E result ids in the P-to-O result; a new E correction requires renewed P-to-O result/acceptance before closure. Assign R when independent review is required; R records technical pass/findings/blocked, and the named primary/P/O separately returns accepted/repair/rejected/blocked. R does not accept its own work. Review and disposition must cite the exact result, checkpoint and subject. An original author can send `review-request` to the assigned R for its own recorded product. This includes O's own direction/Mandate; O still cannot direct review of E/P products by bypassing P.

Same-subject corrections name `corrects` with the latest result id and preserve original author, recipient and R while using a new checkpoint. Retain cumulative findings and failed evidence. After handing off, stop dependent work unless independent authorized work remains. Factual notices and terminal decisions need no receipt reply. No polling, resend or ACK loop.

WCDP persists the notice id before native non-idempotent send. Native accepted/queued means transport observation only; queued is not delivered. Prepared/unknown and queued material handoffs block dependent work, including after restart. Do not resend. The paused owner may record `reconcile-notice` after inspecting native logs proving the exact notice/author/destination/message id and its status. A queued record can advance only to accepted with the same message id. This records external evidence, does not independently validate that assertion, and still requires explicit resume. If no such evidence exists, leave the pending/UNKNOWN state and stop. A broken or missing profile/store is not authority to create replacement history.

Resume from the paired store, native Team roster, current authority/revision, writer/dirty observation, remaining evidence budget and next authorized action. A persisted child cannot fall back to a host model when Team identity becomes unavailable. Closed contracts are terminal. Supersession requires resolved handoffs and a released writer, preserves predecessor/successor linkage and needs a separately authorized new subject/carrier; it cannot clear uncertainty or reset a budget. No automatic migration or retry.

## Tool input contract

`work_charter_status` reads this Session's Host snapshot. Browser Remote operations are read-only. Mutations derive the exact live executing Agent; no caller-supplied actor identity is accepted.

`work_charter_create_draft` takes `input_json`, a serialized object with:

```json
{"charterId":"wc_12345678-1234-4234-8234-123456789abc","arrangement":"direct","continuity":"current-task","managedWorkstream":"bounded work","authority":{"revision":0,"reference":"actual user instruction locator","authorizedActions":["bounded local work"],"prohibitedActions":["publication"]},"contract":{"outcome":"agreed result","scope":["named files"],"nonGoals":[],"confirmedContract":["agreed acceptance"],"necessaryGuardrails":[],"workingProposal":[],"openDecisions":[],"acceptance":["observed checks"],"stopConditions":["scope or authority drift"]},"roles":[{"role":"primary","name":"lead"}]}
```

Use a new UUID in the required `wc_` form. For Team use P=`planner`/`lead` and E=`executor`/a distinct native name, plus R if needed. For Phased O=`orchestrator`/`lead`, plus P/E/R distinct names. Non-Lead roles may supply an explicitly confirmed `model` object, otherwise normal file/default selection applies. An explicit selected file uses top-level `modelConfigPath` (absolute path). A durable/Team/Phased draft also includes `controlLocator`. Do not submit `sessionId` for unprovisioned roles or a Lead model override.

`work_charter_transition` takes `input_json` with `charterId`, `expectedRevision`, `command`. Commands:

- `propose`; `approve` with `approvalRef`; `activate`; `pause` or `writer-drift` with `reason`; `resume` with `observation`.
- `assign-writer` with `name`, `workspace`, `observation`; `release-writer` with `observation`.
- `update-proposal` with `proposal` string array; `revise-contract` with a complete `contract` and `authority` whose revision advances once, at a paused boundary with writer released. This returns to proposed state.
- `declare-evidence` with `evidence`: `id`, `subject`, `checkpoint`, `required`, `state:"declared"`, `history:[]`, optional `consumptionPoint`.
- `record-evidence` with `evidenceId`, `state` (passed/failed/invalid/unknown), `reference`; `consume-evidence` with `evidenceId`, `point`, `reference`.
- `reconcile-notice` with `noticeId`, `state` (accepted/queued), `messageId`, `reference` as above.
- `close` with `reference` after required evidence and latest outcomes pass owner acceptance; `supersede` with distinct `successor` and `reference` at a paused boundary.

`work_charter_notice` takes `input_json` with `charterId`, `expectedRevision`, `notice`. A notice includes `id`, `kind` (result/review-request/review/disposition/fact), `checkpoint`, `subject`, `summary`, `author`, `recipient`, `findings` string array, `evidenceIds` array and optional `nextAction`. Results may name `reviewer:"reviewer"` and `corrects`; review requests add `resultId` and target the assigned R; reviews add `resultId` and `reviewVerdict`; dispositions add `resultId` and `verdict`. Facts cannot act as decisions. Transport fields, authority revision and execution `dependsOn` are Host-owned.

`work_charter_provision_role` takes `charter_id`, `expected_revision`, `role`, `prompt`. Lead provisions only an approved role under its stored immutable native name. If provisioning fails or its outcome is uncertain, inspect the existing native roster and logs; do not retry the same name or invent a replacement role. New-model availability/credentials remain the native LLM provider's responsibility.
