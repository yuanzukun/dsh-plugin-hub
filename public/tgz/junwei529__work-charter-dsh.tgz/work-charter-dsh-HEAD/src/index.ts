import { Service, type Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { Remote, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import { WorkCharterCoordinator } from './coordinator.ts'
import { renderWorkCharterContext, WORK_CHARTER_CONTEXT_NAME } from './model-context.ts'
import { registerWorkCharterTools } from './model-tools.ts'
import { registerWorkCharterSkill } from './skill.ts'
import { assertWorkCharterStorageReady, workCharterDomainSpec, type WorkCharterDomain } from './storage.ts'
import {
  WORK_CHARTER_UPSTREAM_PACKAGE_TREE, WorkCharterError,
  type CreateWorkCharterInput, type GetWorkCharterInput, type ListWorkChartersInput,
  type ListSessionWorkChartersInput, type SubmitWorkCharterNoticeInput, type TransitionWorkCharterInput,
  type WorkCharterDto, type WorkCharterHealth, type WorkCharterMutationResult,
  type WorkCharterRemoteOutcome, type WorkCharterServiceContract,
} from './types.ts'
declare module '@deepseek-ai/cordis' { interface Context { workCharter: WorkCharterServiceContract } }
export * from './types.ts'
export { renderWorkCharterContext, WORK_CHARTER_CONTEXT_NAME } from './model-context.ts'
export class WorkCharterService extends TypertRemoteService implements WorkCharterServiceContract {
  static inject = ['storageDomain', 'agents', 'sessions', 'systemPrompt', 'skills', 'tools']
  private coordinator?: WorkCharterCoordinator
  private domain?: WorkCharterDomain
  constructor(ctx: Context) { super(ctx, 'workCharter') }
  protected async [Service.init](): Promise<void> {
    const domain = await this.ctx.storageDomain.open(workCharterDomainSpec)
    try { assertWorkCharterStorageReady(domain) } catch (error) { await domain.close(); throw error }
    this.domain = domain
    const coordinator = new WorkCharterCoordinator(domain, this.ctx)
    this.coordinator = coordinator
    this.ctx.effect((): (() => Promise<void>) => async () => { await coordinator.drain(); await domain.close() }, 'work-charter.domain')
    await registerWorkCharterSkill(this.ctx)
    registerWorkCharterTools(this.ctx, coordinator)
    this.ctx.on('agent/request', ({ agent }, next) => coordinator.modelRoute(agent, next))
    this.ctx.on('system-prompt/assemble', async (assembly, context, next) => {
      const agent = context.agent
      if (agent !== undefined) {
        const charters = await coordinator.listSessionCharters({ sessionId: agent.id })
        const text = renderWorkCharterContext({ sessionId: agent.id, charters })
        if (text !== '') assembly.contexts.push({ name: WORK_CHARTER_CONTEXT_NAME, text })
      }
      return next()
    })
  }
  private owner(): WorkCharterCoordinator {
    if (this.coordinator === undefined || this.domain === undefined) throw new WorkCharterError('NOT_READY', 'Work Charter is not ready')
    assertWorkCharterStorageReady(this.domain)
    return this.coordinator
  }
  @Remote('health')
  health(): Promise<WorkCharterHealth> {
    this.owner()
    return Promise.resolve({ service: 'work-charter-dsh', status: 'ok', contractVersion: 2,
      storage: { schemaVersion: 2, state: 'ready' },
      upstream: { version: '0.9.1', packageTree: WORK_CHARTER_UPSTREAM_PACKAGE_TREE },
      team: this.ctx.get('agentTeams') === undefined ? 'unavailable' : 'available' })
  }
  createCharter(actor: Agent, input: CreateWorkCharterInput): Promise<WorkCharterMutationResult> { return this.owner().createCharter(actor, input) }
  getCharter(input: GetWorkCharterInput): Promise<WorkCharterDto> { return this.owner().getCharter(input) }
  listCharters(input: ListWorkChartersInput = {}): Promise<readonly WorkCharterDto[]> { return this.owner().listCharters(input) }
  listSessionCharters(input: ListSessionWorkChartersInput): Promise<readonly WorkCharterDto[]> { return this.owner().listSessionCharters(input) }
  transitionCharter(actor: Agent, input: TransitionWorkCharterInput): Promise<WorkCharterMutationResult> { return this.owner().transitionCharter(actor, input) }
  submitNotice(actor: Agent, input: SubmitWorkCharterNoticeInput, signal: AbortSignal): Promise<WorkCharterMutationResult> { return this.owner().submitNotice(actor, input, signal) }
  @Remote('chartersList')
  chartersList(input: ListWorkChartersInput, signal: AbortSignal): Promise<WorkCharterRemoteOutcome<readonly WorkCharterDto[]>> {
    signal.throwIfAborted(); return remoteOutcome(() => this.listCharters(input))
  }
  @Remote('chartersGet')
  chartersGet(input: GetWorkCharterInput): Promise<WorkCharterRemoteOutcome<WorkCharterDto>> { return remoteOutcome(() => this.getCharter(input)) }
  @Remote('sessionChartersList')
  sessionChartersList(input: ListSessionWorkChartersInput, signal: AbortSignal): Promise<WorkCharterRemoteOutcome<readonly WorkCharterDto[]>> {
    signal.throwIfAborted(); return remoteOutcome(() => this.listSessionCharters(input))
  }
}
async function remoteOutcome<T>(operation: () => Promise<T>): Promise<WorkCharterRemoteOutcome<T>> {
  try { return { ok: true, value: await operation() } } catch (error) {
    const normalized = error instanceof WorkCharterError ? error : new WorkCharterError('INVALID_INPUT', 'Work Charter request failed validation')
    return { ok: false, error: normalized.toDTO() }
  }
}
export { WORK_CHARTER_STORAGE_DOMAIN_ID, WORK_CHARTER_STORAGE_PHYSICAL_VERSION, WORK_CHARTER_TABLE_ID, type WorkCharterDomain } from './storage.ts'
export default WorkCharterService
