import {
  WorkCharterDtoSchema, WorkCharterError,
  type CreateWorkCharterInput, type WorkCharterDto, type WorkCharterNotice,
  type WorkCharterRole, type SessionId, type TransitionWorkCharterInput,
  type SubmitWorkCharterNoticeInput,
} from './types.ts'

export interface WorkCharterPolicyRuntime { readonly now: () => string }
export const defaultPolicyRuntime: WorkCharterPolicyRuntime = { now: () => new Date().toISOString() }
export function createWorkCharterRecord(input: CreateWorkCharterInput, lead: SessionId,
  runtime: WorkCharterPolicyRuntime = defaultPolicyRuntime): WorkCharterDto {
  const now = runtime.now()
  const { charterId, ...fields } = input
  return WorkCharterDtoSchema.parse({
    ...fields, id: charterId,
    contractFormat: 'arrangement-v1',
    target: input.arrangement === 'direct' ? { kind: 'session', sessionId: lead } : { kind: 'team', teamId: lead },
    contractState: 'draft', state: 'paused', revision: 0, evidence: [], notices: [], previousContracts: [],
    createdAt: now, updatedAt: now,
  })
}

export function controlRole(charter: WorkCharterDto): WorkCharterRole {
  return charter.arrangement === 'direct' ? 'primary' : charter.arrangement === 'team' ? 'planner' : 'orchestrator'
}
export function requireRevision(charter: WorkCharterDto, expected: number): void {
  if (charter.revision !== expected) throw new WorkCharterError('STALE_REVISION', 'read the current Charter before changing it')
}
function requireCondition(condition: boolean, message: string): asserts condition {
  if (!condition) throw new WorkCharterError('POLICY_REJECTED', message)
}
export function changed(charter: WorkCharterDto, changes: Partial<WorkCharterDto>, now: string): WorkCharterDto {
  return WorkCharterDtoSchema.parse({ ...charter, ...changes, revision: charter.revision + 1, updatedAt: now })
}
function requireSettledHandoffs(charter: WorkCharterDto): void {
  requireCondition(!charter.notices.some(n => n.delivery.state === 'prepared' || n.delivery.state === 'unknown'),
    'uncertain handoff requires evidence reconciliation; never resend automatically')
  requireCondition(!charter.notices.some(n => n.kind !== 'fact' && n.delivery.state === 'queued'),
    'material handoff is queued, not delivered; record exact native delivery before dependent continuation')
}
function requireReady(charter: WorkCharterDto): void {
  requireCondition(charter.contractState === 'approved', 'approved contract required')
  requireCondition(charter.contract.openDecisions.length === 0, 'resolve material open decisions before continuation')
  requireSettledHandoffs(charter)
}

export function applyWorkCharterTransition(current: WorkCharterDto, input: TransitionWorkCharterInput,
  actor: WorkCharterRole, runtime: WorkCharterPolicyRuntime = defaultPolicyRuntime): WorkCharterDto {
  requireRevision(current, input.expectedRevision)
  requireCondition(current.state !== 'closed', 'closed Charter is terminal')
  const command = input.command
  const controls = actor === controlRole(current)
  const writer = current.roles.find(role => role.role === actor)?.name === current.writer?.name
  const now = runtime.now()
  const edit = (changes: Partial<WorkCharterDto>): WorkCharterDto => changed(current, changes, now)
  switch (command.kind) {
    case 'propose':
      requireCondition(controls && current.contractState === 'draft', 'only the owner proposes a draft')
      return edit({ contractState: 'proposed' })
    case 'approve':
      requireCondition(controls && current.contractState === 'proposed', 'only a proposed contract may record external approval')
      return edit({ contractState: 'approved', authority: { ...current.authority, reference: command.approvalRef } })
    case 'activate':
    case 'resume':
      requireCondition(controls && current.state === 'paused', 'only the owner activates a paused contract')
      requireReady(current)
      return edit({ state: 'active', ...(command.kind === 'resume' ? { lastStop: `resumed: ${command.observation}` } : {}) })
    case 'pause':
    case 'writer-drift':
      return edit({ state: 'paused', lastStop: command.reason })
    case 'assign-writer':
      requireCondition(controls || actor === 'planner', 'only the accountable owner assigns a writer')
      requireCondition(current.writer === undefined && current.state === 'paused', 'release the existing writer before reassignment')
      requireCondition(current.roles.some(role => role.name === command.name && role.role !== 'reviewer'), 'reviewer cannot be a writer')
      return edit({ writer: { name: command.name, workspace: command.workspace, observation: command.observation } })
    case 'release-writer': {
      requireCondition(controls || actor === 'planner' || writer, 'only writer or owner may record release')
      const next = { ...current }
      delete next.writer
      return changed(next, { state: 'paused', lastStop: `writer released: ${command.observation}` }, now)
    }
    case 'update-proposal':
      requireCondition(controls || actor === 'planner' || writer, 'proposal changes require a work owner')
      return edit({ contract: { ...current.contract, workingProposal: command.proposal } })
    case 'revise-contract':
      requireCondition(controls && current.state === 'paused' && current.writer === undefined, 'contract revision needs the owner at a paused boundary with writer released')
      requireCondition(command.authority.revision === current.authority.revision + 1, 'authority revision must advance exactly once')
      return edit({
        contractState: 'proposed', contract: command.contract, authority: command.authority,
        previousContracts: [...current.previousContracts, { contract: current.contract, authority: current.authority, roles: current.roles, revision: current.revision }],
      })
    case 'declare-evidence':
      requireCondition(controls || actor === 'planner', 'owner must declare evidence requirements')
      requireCondition(!current.evidence.some(item => item.id === command.evidence.id), 'evidence ids cannot be replaced')
      requireCondition(command.evidence.state === 'declared' && command.evidence.history.length === 0
        && command.evidence.consumedAt === undefined && command.evidence.consumptionRef === undefined, 'declare evidence before execution or consumption')
      return edit({ evidence: [...current.evidence, command.evidence] })
    case 'record-evidence':
    case 'consume-evidence': {
      const existing = current.evidence.find(item => item.id === command.evidenceId)
      requireCondition(existing !== undefined, 'evidence must be declared')
      const evidence = current.evidence.map(item => {
        if (item.id !== command.evidenceId) return item
        if (command.kind === 'consume-evidence') {
          requireCondition(item.consumedAt === undefined && item.consumptionPoint === command.point, 'only the declared actual consumption point consumes this evidence budget')
          return { ...item, consumedAt: now, consumptionRef: command.reference,
            history: [...item.history, { state: 'consumed', reference: command.reference, at: now }] }
        }
        return { ...item, state: command.state, locator: command.reference,
          history: [...item.history, { state: command.state, reference: command.reference, at: now }] }
      })
      return edit({ evidence })
    }
    case 'close': {
      requireCondition(controls, 'only the accountable owner closes the Charter')
      requireReady(current)
      requireCondition(current.evidence.every(item => !item.required || item.state === 'passed'), 'required evidence is not passed')
      requireCondition(current.arrangement === 'direct' || latestResults(current).some(item => item.author === 'executor'), 'Team closure requires an execution result under the current authority')
      requireCondition(current.arrangement !== 'phased' || latestResults(current).some(item => item.author === 'planner'), 'Phased closure requires P to O acceptance')
      if (current.arrangement === 'phased') {
        const phase = latestResults(current).findLast(item => item.author === 'planner' && item.recipient === 'orchestrator')
        requireCondition(phase !== undefined, 'current phase result required')
        requireCurrentExecutions(current, phase)
      }
      for (const notice of latestResults(current)) requireAccepted(current, notice)
      const next = { ...current }
      delete next.writer
      return changed(next, { state: 'closed', lastStop: command.reference }, now)
    }
    case 'reconcile-notice': {
      requireCondition(controls && current.state === 'paused', 'only the paused owner records native-log reconciliation')
      const notice = current.notices.find(item => item.id === command.noticeId)
      requireCondition(notice !== undefined && ['prepared', 'unknown', 'queued'].includes(notice.delivery.state), 'only pending or uncertain delivery may be reconciled')
      requireCondition(notice.delivery.messageId === undefined || notice.delivery.messageId === command.messageId, 'reconciliation preserves the admitted native message identity')
      requireCondition(notice.delivery.state !== 'queued' || command.state === 'accepted', 'queued reconciliation requires observed delivery')
      return edit({ notices: current.notices.map(item => item.id !== command.noticeId ? item : {
        ...item, delivery: { state: command.state, messageId: command.messageId },
        deliveryHistory: [...item.deliveryHistory, { state: command.state, reference: command.reference, at: now }],
      }), lastStop: `reconciled ${command.noticeId}; explicit resume still required` })
    }
    case 'supersede': {
      requireCondition(controls && current.state === 'paused', 'supersession requires a paused owner boundary')
      requireSettledHandoffs(current)
      requireCondition(current.writer === undefined, 'release and reconcile the existing writer before supersession')
      requireCondition(command.successor !== current.id, 'successor must be distinct')
      const next = { ...current }
      delete next.writer
      return changed(next, { state: 'closed', contractState: 'superseded', successor: command.successor, lastStop: command.reference }, now)
    }
  }
}

function latestResults(charter: WorkCharterDto): WorkCharterNotice[] {
  const latest = new Map<string, WorkCharterNotice>()
  for (const notice of charter.notices) {
    if (notice.kind === 'result' && notice.authorityRevision === charter.authority.revision) {
      const key = `${notice.author}/${notice.recipient}/${notice.subject}`
      // Replacement must keep latest-result order aligned with notice chronology.
      latest.delete(key)
      latest.set(key, notice)
    }
  }
  return [...latest.values()]
}
function requireAccepted(charter: WorkCharterDto, result: WorkCharterNotice): void {
  const disposition = charter.notices.findLast(notice => notice.kind === 'disposition' && notice.resultId === result.id)
  requireCondition(disposition?.verdict === 'accepted', 'latest material result needs a checkpoint-bound owner disposition')
  requireCondition(delivered(result) && delivered(disposition), 'result and disposition must be delivered to their dependent roles')
}
function delivered(notice: WorkCharterNotice): boolean { return ['accepted', 'local'].includes(notice.delivery.state) }
function requireCurrentExecutions(charter: WorkCharterDto, phase: WorkCharterNotice): void {
  const current = latestResults(charter).filter(item => item.author === 'executor').map(item => item.id).sort()
  requireCondition(current.length > 0 && JSON.stringify(current) === JSON.stringify([...phase.dependsOn].sort()),
    'phase result must bind the current execution results; renewed P to O acceptance required')
}

export function admitNotice(current: WorkCharterDto, input: SubmitWorkCharterNoticeInput,
  actor: WorkCharterRole, sessionId: SessionId, runtime: WorkCharterPolicyRuntime = defaultPolicyRuntime): WorkCharterDto {
  requireRevision(current, input.expectedRevision)
  requireReady(current)
  requireCondition(current.state !== 'closed', 'closed Charter cannot admit a notice')
  const notice = input.notice
  requireCondition(actor === notice.author, 'executing role must author its own notice')
  requireCondition(current.roles.some(role => role.role === notice.recipient), 'recipient is not bound')
  requireCondition(!current.notices.some(item => item.id === notice.id), 'notice id already admitted; inspect its delivery without resending')
  requireCondition(!current.notices.some(item => item.kind === notice.kind && item.author === notice.author
    && item.recipient === notice.recipient && item.checkpoint === notice.checkpoint), 'unchanged route/checkpoint already handed off')
  requireCondition(notice.evidenceIds.every(id => current.evidence.some(item => item.id === id)), 'unknown evidence reference')
  if (current.arrangement === 'phased' && actor === 'orchestrator') {
    requireCondition(notice.recipient === 'orchestrator' || notice.recipient === 'planner'
      || notice.kind === 'review-request' && notice.recipient === 'reviewer', 'O may not bypass P to direct E or R')
  }
  if (notice.kind === 'result') {
    requireCondition(actor !== 'reviewer' && notice.recipient !== 'reviewer', 'technical review and outcome acceptance are distinct')
    const owner = actor === 'executor' ? 'planner' : actor === 'planner' && current.arrangement === 'phased' ? 'orchestrator' : actor
    requireCondition(notice.recipient === owner, 'result must go to its designated acceptance owner')
    requireCondition(notice.resultId === undefined && notice.verdict === undefined && notice.reviewVerdict === undefined, 'result cannot claim review or acceptance')
    if (notice.reviewer !== undefined) requireCondition(current.roles.some(role => role.role === 'reviewer'), 'independent reviewer is not bound')
    const previous = latestResults(current).find(item => item.author === actor && item.recipient === notice.recipient && item.subject === notice.subject)
    requireCondition(previous === undefined || notice.corrects === previous.id, 'continuing the same subject must explicitly correct its latest result')
    if (notice.corrects !== undefined) {
      const prior = current.notices.find(item => item.id === notice.corrects)
      requireCondition(prior?.kind === 'result' && prior.author === actor && prior.recipient === notice.recipient
        && prior.subject === notice.subject && prior.reviewer === notice.reviewer && prior.checkpoint !== notice.checkpoint,
      'correction preserves original author, reviewer, subject and route with a new checkpoint')
    }
    if (actor === 'planner' && current.arrangement === 'phased') {
      const executions = latestResults(current).filter(item => item.author === 'executor')
      requireCondition(executions.length > 0, 'phase handoff needs an execution result')
      executions.forEach(result => { requireAccepted(current, result) })
    }
  } else if (notice.kind === 'review' || notice.kind === 'disposition' || notice.kind === 'review-request') {
    const result = current.notices.find(item => item.id === notice.resultId)
    requireCondition(result?.kind === 'result' && result.checkpoint === notice.checkpoint && result.subject === notice.subject,
      'review/disposition must name the exact result, subject and checkpoint')
    requireCondition(latestResults(current).some(item => item.id === result.id), 'superseded result cannot receive a current disposition')
    requireCondition(delivered(result), 'result must reach its designated owner before review or disposition')
    if (notice.kind === 'review-request') {
      requireCondition(actor === result.author && notice.recipient === result.reviewer
        && notice.verdict === undefined && notice.reviewVerdict === undefined, 'only the original author requests review of its own bound product')
    } else if (notice.kind === 'review') {
      requireCondition(current.writer === undefined, 'release the writer before independent review')
      requireCondition(actor === result.reviewer && notice.reviewVerdict !== undefined && notice.verdict === undefined,
        'only the assigned independent R records technical review')
      requireCondition(notice.recipient === result.author || notice.recipient === result.recipient, 'review returns to the author or acceptance owner')
    } else {
      requireCondition(actor === result.recipient && actor !== 'reviewer' && notice.recipient === result.author,
        'only the named acceptance owner returns the disposition to the author')
      requireCondition(notice.verdict !== undefined && notice.reviewVerdict === undefined, 'disposition must record an owner verdict')
      if (notice.verdict === 'accepted') {
        requireCondition(result.evidenceIds.every(id => current.evidence.find(item => item.id === id)?.state === 'passed'), 'result evidence is not passed')
        if (result.reviewer !== undefined) {
          const review = current.notices.findLast(item => item.kind === 'review' && item.resultId === result.id)
          requireCondition(review?.reviewVerdict === 'pass' && delivered(review), 'independent review must pass and be delivered before acceptance')
        }
        if (current.arrangement === 'phased' && result.author === 'planner' && result.recipient === 'orchestrator') requireCurrentExecutions(current, result)
      }
    }
  } else requireCondition(notice.verdict === undefined && notice.reviewVerdict === undefined && notice.resultId === undefined,
    'factual notices cannot act as decisions')
  const now = runtime.now()
  return changed(current, { notices: [...current.notices, {
    ...notice, authorSessionId: sessionId, authorityRevision: current.authority.revision,
    dependsOn: notice.kind === 'result' && actor === 'planner' && current.arrangement === 'phased'
      ? latestResults(current).filter(item => item.author === 'executor').map(item => item.id) : [],
    delivery: { state: notice.author === notice.recipient ? 'local' : 'prepared' },
    deliveryHistory: [{ state: notice.author === notice.recipient ? 'local' : 'prepared', reference: 'Host admission before transport', at: now }], createdAt: now,
  }] }, now)
}
