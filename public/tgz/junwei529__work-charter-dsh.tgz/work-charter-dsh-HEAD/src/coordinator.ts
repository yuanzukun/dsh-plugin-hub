import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type {} from '@deepseek-ai/dsh-experimental-agent-team'
import type { LlmCallConfig } from '@deepseek-ai/dsh-llm'
import { ReasoningEffortId } from '@deepseek-ai/dsh-llm'
import { resolveRoleModelFile } from './role-model-files.ts'
import { toDshModelRoute } from './role-models.ts'
import { admitNotice, applyWorkCharterTransition, changed, controlRole, createWorkCharterRecord, requireRevision, defaultPolicyRuntime } from './policy.ts'
import { WORK_CHARTER_TABLE_ID, type WorkCharterDomain } from './storage.ts'
import {
  CreateWorkCharterInputSchema, GetWorkCharterInputSchema, ListSessionWorkChartersInputSchema,
  ListWorkChartersInputSchema, SubmitWorkCharterNoticeInputSchema, TransitionWorkCharterInputSchema,
  WorkCharterDtoSchema, WorkCharterError,
  type CreateWorkCharterInput, type WorkCharterDto, type WorkCharterMutationResult,
  type GetWorkCharterInput, type ListWorkChartersInput, type ListSessionWorkChartersInput,
  type TransitionWorkCharterInput, type SubmitWorkCharterNoticeInput, type WorkCharterRole,
} from './types.ts'

export class WorkCharterCoordinator {
  private tail: Promise<void> = Promise.resolve()
  private storageUnknown = false
  constructor(private readonly domain: WorkCharterDomain, private readonly ctx: Context) {}
  async drain(): Promise<void> { await this.tail }
  private enqueue<T>(operation: () => Promise<T>): Promise<T> {
    const run = this.tail.then(operation)
    this.tail = run.then(() => undefined, () => undefined)
    return run
  }
  private assertActor(actor: Agent): void {
    if (this.ctx.agents.get(actor.id) !== actor) throw new WorkCharterError('UNAUTHORIZED', 'exact live executing Agent required')
  }
  private rows(): WorkCharterDto[] {
    if (this.storageUnknown) throw new WorkCharterError('STORAGE_UNKNOWN', 'reopen storage and reconcile before further work', false, 'unknown')
    return Array.from(this.domain.table(WORK_CHARTER_TABLE_ID).entries(), ([, value]) => WorkCharterDtoSchema.parse(value))
  }
  private current(id: string): WorkCharterDto {
    const value = this.rows().find(row => row.id === id)
    if (value === undefined) throw new WorkCharterError('NOT_FOUND', 'Charter not found')
    return value
  }
  private async persist(charter: WorkCharterDto): Promise<void> {
    try {
      await this.domain.table(WORK_CHARTER_TABLE_ID).put(charter.id, WorkCharterDtoSchema.parse(charter))
    } catch (cause) {
      this.storageUnknown = true
      throw new WorkCharterError('STORAGE_UNKNOWN', 'write outcome is uncertain; no dependent action or automatic retry', false, 'unknown', { cause })
    }
  }
  private rootId(charter: WorkCharterDto): string {
    return charter.target.kind === 'session' ? charter.target.sessionId : charter.target.teamId
  }
  roleForAgent(charter: WorkCharterDto, actor: Agent): WorkCharterDto['roles'][number] {
    this.assertActor(actor)
    if (charter.target.kind === 'session' && charter.target.sessionId === actor.id) {
      const role = charter.roles.find(binding => binding.name === 'lead')
      if (role !== undefined) return role
    }
    const team = this.ctx.get('agentTeams')
    if (team === undefined) throw new WorkCharterError('TEAM_UNAVAILABLE', 'native Agent Team service is required for this role')
    const membership = team.tryMembership(actor)
    if (membership?.id !== this.rootId(charter)) throw new WorkCharterError('UNAUTHORIZED', 'Agent is detached or belongs to another Team')
    const role = charter.roles.find(binding => binding.name === membership.name)
    if (role === undefined || role.sessionId !== undefined && role.sessionId !== actor.id) {
      throw new WorkCharterError('UNAUTHORIZED', 'current native member is not the bound role carrier')
    }
    return role
  }
  createCharter(actor: Agent, raw: CreateWorkCharterInput): Promise<WorkCharterMutationResult> {
    const input = CreateWorkCharterInputSchema.parse(raw)
    return this.enqueue(async () => {
      this.assertActor(actor)
      if (this.rows().some(row => row.id === input.charterId || this.rootId(row) === actor.id && row.state !== 'closed')) {
        throw new WorkCharterError('CONFLICT', 'existing Charter or active work subject must be reconciled')
      }
      const team = this.ctx.get('agentTeams')
      if (input.arrangement !== 'direct' || input.roles.length > 1) {
        if (team === undefined) throw new WorkCharterError('TEAM_UNAVAILABLE', 'native Team composition is absent')
        if (team.membership(actor).role !== 'lead') throw new WorkCharterError('UNAUTHORIZED', 'create from the native Lead')
        const members = team.listMembers(actor)
        if (input.roles.some(role => role.name !== 'lead' && members.some(member => member.name === role.name))) {
          throw new WorkCharterError('EXISTING_CARRIER', 'existing role carriers require an explicit transition; do not replace their frozen model')
        }
      }
      const roles = input.roles.map(role => {
        if (role.name === 'lead') {
          if (role.model !== undefined) throw new WorkCharterError('EXISTING_CARRIER', 'existing Lead model is host-owned; do not silently change it')
          return { ...role, sessionId: actor.id, modelSource: 'existing host selection; no override' }
        }
        if (role.sessionId !== undefined) throw new WorkCharterError('EXISTING_CARRIER', 'teammates must be provisioned under this approved role binding')
        const selection = resolveRoleModelFile({
          contract: { format: 'arrangement-v1', arrangement: input.arrangement }, responsibility: role.role,
          ...(input.modelConfigPath === undefined ? {} : { explicitPath: input.modelConfigPath }),
          ...(role.model === undefined ? {} : { confirmed: role.model }),
        })
        if (selection.model === undefined) throw new WorkCharterError('MODEL_UNRESOLVED', 'role model is unspecified')
        toDshModelRoute(selection.model)
        return { ...role, model: selection.model, modelSource: `${selection.source}: ${selection.locator}` }
      })
      const charter = createWorkCharterRecord({ ...input, roles }, actor.id)
      await this.persist(charter)
      return { charter, changed: true }
    })
  }
  getCharter(raw: GetWorkCharterInput): Promise<WorkCharterDto> {
    return Promise.resolve(this.current(GetWorkCharterInputSchema.parse(raw).charterId))
  }
  listCharters(raw: ListWorkChartersInput = {}): Promise<readonly WorkCharterDto[]> {
    ListWorkChartersInputSchema.parse(raw)
    return Promise.resolve(this.rows())
  }
  listSessionCharters(raw: ListSessionWorkChartersInput): Promise<readonly WorkCharterDto[]> {
    const { sessionId } = ListSessionWorkChartersInputSchema.parse(raw)
    const actor = this.ctx.agents.get(sessionId)
    return Promise.resolve(this.rows().filter(row => {
      if (this.rootId(row) === sessionId || row.roles.some(role => role.sessionId === sessionId)) return true
      if (actor === undefined) return false
      const membership = this.ctx.get('agentTeams')?.tryMembership(actor)
      return membership?.id === this.rootId(row) && row.roles.some(role => role.name === membership.name)
    }))
  }
  transitionCharter(actor: Agent, raw: TransitionWorkCharterInput): Promise<WorkCharterMutationResult> {
    const input = TransitionWorkCharterInputSchema.parse(raw)
    return this.enqueue(async () => {
      const current = this.current(input.charterId)
      const role = this.roleForAgent(current, actor)
      const charter = applyWorkCharterTransition(current, input, role.role)
      await this.persist(charter)
      return { changed: true, charter }
    })
  }
  submitNotice(actor: Agent, raw: SubmitWorkCharterNoticeInput, signal: AbortSignal): Promise<WorkCharterMutationResult> {
    const input = SubmitWorkCharterNoticeInputSchema.parse(raw)
    return this.enqueue(async () => {
      signal.throwIfAborted()
      const current = this.current(input.charterId)
      const role = this.roleForAgent(current, actor)
      let charter = admitNotice(current, input, role.role, actor.id)
      await this.persist(charter) // Durable identity before the non-idempotent native send.
      const notice = charter.notices.at(-1)
      if (notice === undefined) throw new WorkCharterError('INTERNAL', 'admitted notice missing')
      if (notice.delivery.state === 'local') return { changed: true, charter }
      const recipient = charter.roles.find(binding => binding.role === notice.recipient)
      const team = this.ctx.get('agentTeams')
      try {
        if (team === undefined || recipient === undefined) throw new WorkCharterError('TEAM_UNAVAILABLE', 'native destination unavailable')
        this.roleForAgent(charter, actor)
        const sent = await team.sendMessage(actor, {
          target: recipient.name, content: [{ type: 'text', text: JSON.stringify({ charterId: charter.id, notice }) }], signal,
        })
        notice.delivery = { state: sent.status, messageId: sent.messageId }
        if (sent.status === 'queued' && notice.kind !== 'fact') {
          charter.state = 'paused'
          charter.lastStop = `handoff ${notice.id} is queued; record native delivery before dependent continuation`
        }
      } catch {
        notice.delivery = { state: 'unknown' }
        charter.state = 'paused'
        charter.lastStop = `handoff ${notice.id} outcome UNKNOWN; inspect native logs, do not resend`
      }
      notice.deliveryHistory.push({ state: notice.delivery.state, reference: notice.delivery.messageId ?? 'native send returned no proven result', at: defaultPolicyRuntime.now() })
      charter = changed(charter, {}, defaultPolicyRuntime.now())
      await this.persist(charter)
      return { changed: true, charter }
    })
  }
  provisionRole(actor: Agent, charterId: string, expectedRevision: number, role: WorkCharterRole, prompt: string, signal: AbortSignal): Promise<WorkCharterMutationResult> {
    return this.enqueue(async () => {
      const current = this.current(charterId)
      requireRevision(current, expectedRevision)
      const acting = this.roleForAgent(current, actor)
      const binding = current.roles.find(item => item.role === role && item.name !== 'lead')
      if (acting.role !== controlRole(current) || current.contractState !== 'approved' || current.state === 'closed'
        || current.contract.openDecisions.length > 0 || current.notices.some(n => ['prepared', 'unknown'].includes(n.delivery.state)
          || n.kind !== 'fact' && n.delivery.state === 'queued')
        || binding === undefined || binding.model === undefined) {
        throw new WorkCharterError('UNAUTHORIZED', 'Lead may only provision the approved bounded role set')
      }
      const team = this.ctx.get('agentTeams')
      if (team === undefined) throw new WorkCharterError('TEAM_UNAVAILABLE', 'native Team is not loaded')
      if (team.listMembers(actor).some(member => member.name === binding.name)) throw new WorkCharterError('CONFLICT', 'role name already exists; inspect it without retrying creation')
      const created = await team.spawnTeammate(actor, {
        name: binding.name, description: `WCDP/2:${current.id}:${role}`, context: 'fresh', provider: 'spawn',
        prompt: [{ type: 'text', text: prompt }], signal,
      })
      const charter = changed(current, { roles: current.roles.map(item => item.name === binding.name ? { ...item, sessionId: created.member.id } : item) }, defaultPolicyRuntime.now())
      await this.persist(charter)
      return { changed: true, charter }
    })
  }
  async modelRoute(actor: Agent, next: () => Promise<LlmCallConfig>): Promise<LlmCallConfig> {
    this.assertActor(actor)
    const team = this.ctx.get('agentTeams')
    const membership = team?.tryMembership(actor)
    const carrier = membership?.role === 'teammate'
      ? team?.listMembers(actor).find(member => member.id === actor.id) : undefined
    const charter = this.rows().find(row => row.roles.some(role => role.name !== 'lead'
      && (role.sessionId === actor.id || membership?.id === this.rootId(row) && role.name === membership.name)))
    if (charter === undefined) {
      if (carrier?.description?.startsWith('WCDP/2:')) throw new WorkCharterError('MODEL_BINDING_UNAVAILABLE', 'native carrier has no matching Charter store; restore the paired profile without model fallback')
      return next()
    }
    const role = this.roleForAgent(charter, actor)
    if (carrier?.description !== `WCDP/2:${charter.id}:${role.role}`) throw new WorkCharterError('MODEL_BINDING_UNAVAILABLE', 'native carrier identity disagrees with frozen Charter binding')
    if (charter.contractState !== 'approved' || charter.state === 'closed' || role.model === undefined) {
      throw new WorkCharterError('MODEL_BINDING_UNAVAILABLE', 'approved frozen role model is unavailable')
    }
    const route = toDshModelRoute(role.model)
    return { provider: route.provider, model: route.model,
      ...(route.reasoningEffort === undefined ? {} : { reasoningEffort: ReasoningEffortId(route.reasoningEffort) }),
      ...(route.maxTokens === undefined ? {} : { maxTokens: route.maxTokens }) }
  }
}
