import { z } from 'zod'

// The portable 0.9.1 selector is independent of both the WCDP API version and
// the native Team transport provider. This module performs no I/O or dispatch.
export type Arrangement = 'direct' | 'team' | 'phased'
export type Responsibility = 'primary' | 'orchestrator' | 'planner' | 'executor' | 'reviewer'
export type LegacyLevel = 'l0' | 'l1' | 'l2' | 'l3' | 'l4'
export type ModelContract =
  | { readonly format: 'arrangement-v1'; readonly arrangement: Arrangement }
  | { readonly format: 'legacy-level'; readonly level: LegacyLevel }

const Identifier = z.string().min(1).max(256)
  .regex(/^[a-zA-Z0-9][a-zA-Z0-9_.:/@+-]*$/)
  .refine(value => !value.includes('://'), 'endpoints are not model identifiers')
export type ParameterValue = string | number | boolean | null | ParameterValue[] | { [key: string]: ParameterValue }
const Parameter: z.ZodType<ParameterValue> = z.json()
// Inspect raw input before Zod's record clone can discard reserved own keys.
const Parameters = z.unknown().refine(inertParameters,
  'parameters must be inert model settings').pipe(z.record(Identifier, Parameter))

function inertParameters(value: unknown): boolean {
  if (typeof value === 'string') return !/\$\{|`|:\/\//.test(value)
  if (value === null || typeof value !== 'object') return true
  if (Array.isArray(value)) return value.every(inertParameters)
  return Object.entries(value).every(([key, child]) =>
    !/secret|token(?!s$)|password|credential|endpoint|command|api.?key|^url$|^__proto__$|^constructor$|^prototype$|^<<$/i.test(key)
    && inertParameters(child))
}

function freezeParameters(value: ParameterValue): void {
  if (value === null || typeof value !== 'object') return
  for (const child of Object.values(value)) freezeParameters(child)
  Object.freeze(value)
}

export const RoleModelSchema = z.object({
  provider: Identifier,
  model: Identifier,
  parameters: Parameters.optional(),
}).strict()
export type RoleModel = z.infer<typeof RoleModelSchema>

const DirectRoles = z.object({ primary: RoleModelSchema.optional(), reviewer: RoleModelSchema.optional() }).strict()
const TeamRoles = z.object({
  planner: RoleModelSchema.optional(), executor: RoleModelSchema.optional(), reviewer: RoleModelSchema.optional(),
}).strict()
const PhasedRoles = TeamRoles.extend({ orchestrator: RoleModelSchema.optional() }).strict()
const Roles = PhasedRoles.extend({ primary: RoleModelSchema.optional() }).strict()
const Arrangements = z.object({
  direct: DirectRoles.optional(), team: TeamRoles.optional(), phased: PhasedRoles.optional(),
}).strict()
const Levels = z.object({
  l0: DirectRoles.optional(), l1: DirectRoles.optional(), l2: DirectRoles.optional(),
  l3: TeamRoles.optional(), l4: PhasedRoles.optional(),
}).strict()
const V1 = z.object({
  schema_version: z.literal(1), roles: Roles.optional(), level_overrides: Levels.optional(),
}).strict().refine(value => value.roles !== undefined || value.level_overrides !== undefined,
  'v1 requires roles or level_overrides')
const V2 = z.object({
  schema_version: z.literal(2), roles: Roles.optional(),
  arrangement_overrides: Arrangements.optional(), legacy_level_overrides: Levels.optional(),
}).strict().refine(value => hasModelObject(value), 'v2 requires at least one complete model object')
export const RoleModelConfigurationSchema = z.union([V1, V2])
type Configuration = z.infer<typeof RoleModelConfigurationSchema>

function hasModelObject(value: unknown): boolean {
  if (typeof value !== 'object' || value === null) return false
  if ('provider' in value && 'model' in value) return true
  return Object.values(value).some(hasModelObject)
}

export class RoleModelError extends Error {
  constructor(readonly code: 'INVALID_CONFIGURATION' | 'INVALID_ROLE' | 'AMBIGUOUS_DIRECT'
    | 'MISSING_MODEL' | 'UNSUPPORTED_PARAMETER', message: string) {
    super(message)
    this.name = 'RoleModelError'
  }
}

export interface ModelSource {
  readonly locator: string
  readonly configuration: unknown
}
export interface ModelResolution {
  readonly source: 'frozen' | 'confirmed' | 'selected-file' | 'package' | 'host'
  readonly locator: string
  readonly model: RoleModel | undefined
}
export interface ResolveRoleModelInput {
  readonly contract: ModelContract
  readonly responsibility: Responsibility | 'main'
  readonly frozen?: RoleModel
  readonly confirmed?: RoleModel
  // The caller selects exactly the explicit path, else the existing user file,
  // else none. A selected loader failure propagates: it is never a fallback.
  readonly selectedFile?: () => ModelSource
  readonly packageDefaults: () => ModelSource
}

/** Resolve a whole object without reading lower-priority sources unnecessarily. */
export function resolveRoleModel(input: ResolveRoleModelInput): ModelResolution {
  const role = input.responsibility === 'main' ? 'primary' : input.responsibility
  const arrangement = arrangementFor(input.contract)
  if (!rolesFor(arrangement).includes(role)) {
    throw new RoleModelError('INVALID_ROLE', `${role} is not a responsibility in ${arrangement}`)
  }
  if (input.frozen !== undefined) return resolution('frozen', 'frozen delivery', input.frozen)
  if (input.confirmed !== undefined) return resolution('confirmed', 'confirmed task object', input.confirmed)
  if (input.selectedFile !== undefined) {
    const source = input.selectedFile()
    const model = fromSource(source, input.contract, role)
    if (model !== undefined) return resolution('selected-file', source.locator, model)
  }
  const defaults = input.packageDefaults()
  const model = fromSource(defaults, input.contract, role)
  if (model !== undefined) return resolution('package', defaults.locator, model)
  if (role === 'primary') return { source: 'host', locator: 'host selection', model: undefined }
  throw new RoleModelError('MISSING_MODEL', `no complete model object for ${role}`)
}

function resolution(source: ModelResolution['source'], locator: string, value: unknown): ModelResolution {
  const parsed = RoleModelSchema.safeParse(value)
  if (!parsed.success) throw new RoleModelError('INVALID_CONFIGURATION', 'invalid complete model object')
  // Zod clones input; neither a caller mutation nor later configuration edit
  // may mutate this delivery's frozen selection.
  if (parsed.data.parameters !== undefined) freezeParameters(parsed.data.parameters)
  return Object.freeze({ source, locator, model: Object.freeze(parsed.data) })
}

function fromSource(source: ModelSource, contract: ModelContract, role: Responsibility): RoleModel | undefined {
  const parsed = RoleModelConfigurationSchema.safeParse(source.configuration)
  if (!parsed.success) {
    // Do not include configuration values or parser errors that may echo secrets.
    throw new RoleModelError('INVALID_CONFIGURATION', `invalid role-model configuration at ${source.locator}`)
  }
  return selectObject(parsed.data, contract, role)
}

function roleEntry(map: z.infer<typeof Roles> | undefined, role: Responsibility): RoleModel | undefined {
  return map?.[role]
}

function selectObject(config: Configuration, contract: ModelContract, role: Responsibility): RoleModel | undefined {
  const general = roleEntry(config.roles, role)
  const arrangement = arrangementFor(contract)
  if (config.schema_version === 2) {
    const legacy = contract.format === 'legacy-level'
      ? roleEntry(config.legacy_level_overrides?.[contract.level], role) : undefined
    return legacy ?? roleEntry(config.arrangement_overrides?.[arrangement], role) ?? general
  }
  if (contract.format === 'legacy-level') return roleEntry(config.level_overrides?.[contract.level], role) ?? general
  if (arrangement !== 'direct') {
    return roleEntry(config.level_overrides?.[arrangement === 'team' ? 'l3' : 'l4'], role) ?? general
  }
  const candidates = (['l0', 'l1', 'l2'] as const)
    .map(level => roleEntry(config.level_overrides?.[level], role) ?? general)
  const [first] = candidates
  if (!candidates.every(candidate => sameModel(first, candidate))) {
    throw new RoleModelError('AMBIGUOUS_DIRECT', `v1 Direct ${role} differs between l0, l1 and l2; user decision required`)
  }
  return first
}

function sameModel(left: RoleModel | undefined, right: RoleModel | undefined): boolean {
  if (left === undefined || right === undefined) return left === right
  if (left.provider !== right.provider || left.model !== right.model) return false
  return canonicalParameter(left.parameters ?? {}) === canonicalParameter(right.parameters ?? {})
}

function canonicalParameter(value: ParameterValue): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value)
  if (Array.isArray(value)) return `[${value.map(canonicalParameter).join(',')}]`
  return `{${Object.entries(value).sort(([a], [b]) => a === b ? 0 : a < b ? -1 : 1)
    .map(([key, child]) => `${JSON.stringify(key)}:${canonicalParameter(child)}`).join(',')}}`
}

function arrangementFor(contract: ModelContract): Arrangement {
  if (contract.format === 'arrangement-v1') return contract.arrangement
  return contract.level === 'l4' ? 'phased' : contract.level === 'l3' ? 'team' : 'direct'
}

function rolesFor(arrangement: Arrangement): readonly Responsibility[] {
  switch (arrangement) {
    case 'direct': return ['primary', 'reviewer']
    case 'team': return ['planner', 'executor', 'reviewer']
    case 'phased': return ['orchestrator', 'planner', 'executor', 'reviewer']
  }
}

export interface DshModelRoute {
  readonly provider: string
  readonly model: string
  readonly reasoningEffort?: string
  readonly maxTokens?: number
}

/** Map only supported settings. Native exact-model admission still validates effort. */
export function toDshModelRoute(model: RoleModel): DshModelRoute {
  const parsed = RoleModelSchema.safeParse(model)
  if (!parsed.success) throw new RoleModelError('INVALID_CONFIGURATION', 'invalid complete model object')
  const parameters = parsed.data.parameters ?? {}
  for (const key of Object.keys(parameters)) {
    if (key !== 'reasoning_effort' && key !== 'max_output_tokens') {
      throw new RoleModelError('UNSUPPORTED_PARAMETER', 'selected model includes an unsupported DSH parameter')
    }
  }
  const effort = parameters.reasoning_effort
  const tokens = parameters.max_output_tokens
  if (effort !== undefined && (typeof effort !== 'string' || !/^[a-zA-Z0-9_-]+$/.test(effort))) {
    throw new RoleModelError('UNSUPPORTED_PARAMETER', 'reasoning_effort must be a native effort identifier')
  }
  if (tokens !== undefined && (typeof tokens !== 'number' || !Number.isSafeInteger(tokens) || tokens <= 0)) {
    throw new RoleModelError('UNSUPPORTED_PARAMETER', 'max_output_tokens must be a positive safe integer')
  }
  return {
    provider: parsed.data.provider,
    model: parsed.data.model,
    ...(effort !== undefined ? { reasoningEffort: effort } : {}),
    ...(tokens !== undefined ? { maxTokens: tokens } : {}),
  }
}
