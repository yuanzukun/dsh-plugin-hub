import { defineTool } from '@deepseek-ai/dsh-tools'
import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { WorkCharterCoordinator } from './coordinator.ts'
import {
  CreateWorkCharterInputSchema, SubmitWorkCharterNoticeInputSchema,
  TransitionWorkCharterInputSchema, WorkCharterRoleSchema, WorkCharterError,
} from './types.ts'

const OUTPUT = {
  schema: { type: 'object', additionalProperties: false, properties: { json: { type: 'string', required: true } } } as const,
  render: (_args: unknown, value: { json: string }): Array<{ type: 'text'; text: string }> => [{ type: 'text', text: value.json }],
}
function executingAgent(agent: Agent | undefined): Agent {
  if (agent === undefined) throw new WorkCharterError('UNAUTHORIZED', 'executing Agent is required')
  return agent
}
function json(input: string): unknown {
  try { return JSON.parse(input) } catch { throw new WorkCharterError('INVALID_INPUT', 'input_json must be valid JSON') }
}
export function registerWorkCharterTools(ctx: Context, coordinator: WorkCharterCoordinator): void {
  ctx.tools.register(defineTool({
    name: 'work_charter_status', description: 'Read Host Charter state for this Session; native receipt is not acceptance.',
    parameters: {}, output: OUTPUT, isConcurrencySafe: () => true,
    async execute(_args, exec) {
      return { json: JSON.stringify(await coordinator.listSessionCharters({ sessionId: executingAgent(exec.agent).id })) }
    },
  }))
  ctx.tools.register(defineTool({
    name: 'work_charter_create_draft', description: 'Create an inactive arrangement-v1 draft. This does not adopt or approve a Charter. See the Work Charter Skill for contract-2 JSON.',
    parameters: { input_json: { type: 'string', required: true } }, output: OUTPUT,
    async execute(args, exec) {
      return { json: JSON.stringify(await coordinator.createCharter(executingAgent(exec.agent), CreateWorkCharterInputSchema.parse(json(args.input_json)))) }
    },
  }))
  ctx.tools.register(defineTool({
    name: 'work_charter_transition', description: 'Apply a contract-2 transition with expectedRevision. Record approve only against actual external user authority; never infer approval from transport or model output.',
    parameters: { input_json: { type: 'string', required: true } }, output: OUTPUT,
    async execute(args, exec) {
      return { json: JSON.stringify(await coordinator.transitionCharter(executingAgent(exec.agent), TransitionWorkCharterInputSchema.parse(json(args.input_json)))) }
    },
  }))
  ctx.tools.register(defineTool({
    name: 'work_charter_notice', description: 'Record a material result, independent review, owner disposition or fact, then send once through native Team. On uncertain outcome read existing evidence; never resend.',
    parameters: { input_json: { type: 'string', required: true } }, output: OUTPUT,
    async execute(args, exec) {
      return { json: JSON.stringify(await coordinator.submitNotice(executingAgent(exec.agent), SubmitWorkCharterNoticeInputSchema.parse(json(args.input_json)), exec.signal)) }
    },
  }))
  ctx.tools.register(defineTool({
    name: 'work_charter_provision_role', description: 'Native Lead creates one already approved named role. This does not authorize another role, change an existing carrier, or grant P nested spawn rights.',
    parameters: {
      charter_id: { type: 'string', required: true }, expected_revision: { type: 'number', required: true },
      role: { type: 'string', required: true }, prompt: { type: 'string', required: true },
    }, output: OUTPUT,
    async execute(args, exec) {
      return { json: JSON.stringify(await coordinator.provisionRole(executingAgent(exec.agent), args.charter_id, args.expected_revision, WorkCharterRoleSchema.parse(args.role), args.prompt, exec.signal)) }
    },
  }))
}
