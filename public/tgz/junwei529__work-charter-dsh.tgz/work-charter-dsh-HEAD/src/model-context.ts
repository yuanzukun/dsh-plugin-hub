import type { SessionId, WorkCharterDto } from './types.ts'
export const WORK_CHARTER_CONTEXT_NAME = 'work-charter-dsh:active-charters'
export const WORK_CHARTER_CONTEXT_MAX_CHARS = 32_000
export interface WorkCharterContextInput {
  readonly sessionId: SessionId
  readonly charters: readonly WorkCharterDto[]
  readonly coordinationState?: 'available' | 'unknown'
}
export function renderWorkCharterContext(input: WorkCharterContextInput): string {
  const applicable = input.charters.filter(row => row.state !== 'closed')
  if (applicable.length === 0 && input.coordinationState !== 'unknown') return ''
  const text = [
    '# Work Charter — recorded Host snapshot',
    'Work Charter checks its own mutations. It cannot lock files, grant permissions, authorize external effects, or govern all native DSH tools.',
    'Contract approval records external authority references; transport accepted/queued is not inspection, acceptance or model consumption.',
    'Use Direct, Team or Phased responsibilities. R supplies technical review; the named primary/P/O owns acceptance. Preserve findings, consumed evidence and frozen models.',
    'A prepared or unknown handoff stops dependent work. Never resend it automatically. Factual notices and terminal decisions need no receipt reply.',
    `Session: ${input.sessionId}; coordination: ${input.coordinationState ?? 'available'}`,
    JSON.stringify(applicable),
  ].join('\n')
  if (text.length <= WORK_CHARTER_CONTEXT_MAX_CHARS) return text
  return `${text.slice(0, WORK_CHARTER_CONTEXT_MAX_CHARS - 160)}\n[TRUNCATED: stop affected work and read the authoritative Charter with work_charter_status.]`
}
