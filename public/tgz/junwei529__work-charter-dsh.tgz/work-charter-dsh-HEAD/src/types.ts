import { z } from 'zod'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { SessionId as NativeSessionId } from '@deepseek-ai/dsh-session'
import { RoleModelSchema } from './role-models.ts'

export type SessionId = NativeSessionId
export const SessionIdSchema = z.string().min(1).max(256).transform(value => NativeSessionId(value))
export const WORK_CHARTER_CONTRACT_VERSION = 2 as const
export const WORK_CHARTER_STORAGE_SCHEMA_VERSION = 2 as const
export const WORK_CHARTER_UPSTREAM_VERSION = '0.9.1' as const
export const WORK_CHARTER_UPSTREAM_PACKAGE_SHA256 = '07a4c7579c985d8580387e1cbc48f315289975b6e62369b316c5fdf3fcfb2ec0' as const
export const WORK_CHARTER_UPSTREAM_PACKAGE_TREE = '39659168b5fb20899335dd0923c87b65d5a95e36' as const
const Text = z.string().trim().min(1).max(8192)
const Id = z.string().regex(/^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,255}$/)
const Time = z.iso.datetime({ offset: true })
const Revision = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER)
const Texts = z.array(Text).max(100)
export const WorkCharterIdSchema = z.string().regex(/^wc_[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/)
export type WorkCharterId = z.infer<typeof WorkCharterIdSchema>
export const parseWorkCharterId = (input: unknown): WorkCharterId => WorkCharterIdSchema.parse(input)
export const WorkCharterRoleSchema = z.enum(['primary', 'orchestrator', 'planner', 'executor', 'reviewer'])
export type WorkCharterRole = z.infer<typeof WorkCharterRoleSchema>
export const ArrangementSchema = z.enum(['direct', 'team', 'phased'])
export const WorkCharterTargetSchema = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('session'), sessionId: SessionIdSchema }).strict(),
  z.object({ kind: z.literal('team'), teamId: SessionIdSchema }).strict(),
])
export const WorkCharterRoleAssignmentSchema = z.object({
  role: WorkCharterRoleSchema,
  // Native immutable roster names identify planned teammates before first call.
  name: z.string().regex(/^[a-z][a-z0-9_-]{0,63}$/),
  model: RoleModelSchema.optional(),
  modelSource: Text.optional(),
  sessionId: SessionIdSchema.optional(),
}).strict()
export const WorkCharterAuthoritySchema = z.object({
  revision: Revision,
  reference: Text,
  authorizedActions: Texts,
  prohibitedActions: Texts,
}).strict()
export const WorkCharterContractSchema = z.object({
  outcome: Text, scope: Texts, nonGoals: Texts,
  confirmedContract: Texts, necessaryGuardrails: Texts,
  workingProposal: Texts, openDecisions: Texts,
  acceptance: Texts, stopConditions: Texts,
}).strict()
export const WorkCharterEvidenceSchema = z.object({
  id: Id, subject: Text, checkpoint: Text, required: z.boolean(),
  state: z.enum(['declared', 'passed', 'failed', 'invalid', 'unknown']),
  locator: Text.optional(),
  consumptionPoint: Text.optional(),
  consumedAt: Time.optional(),
  consumptionRef: Text.optional(),
  history: z.array(z.object({ state: Text, reference: Text, at: Time }).strict()).max(1000),
}).strict()
export const WorkCharterNoticeSchema = z.object({
  id: Id, kind: z.enum(['result', 'review-request', 'review', 'disposition', 'fact']),
  checkpoint: Text, subject: Text, summary: Text,
  author: WorkCharterRoleSchema, recipient: WorkCharterRoleSchema,
  authorSessionId: SessionIdSchema,
  authorityRevision: Revision,
  dependsOn: z.array(Id).max(1000),
  resultId: Id.optional(), corrects: Id.optional(),
  reviewer: z.literal('reviewer').optional(),
  verdict: z.enum(['accepted', 'repair', 'rejected', 'blocked']).optional(),
  reviewVerdict: z.enum(['pass', 'findings', 'blocked']).optional(),
  findings: Texts,
  evidenceIds: z.array(Id).max(100),
  nextAction: Text.optional(),
  delivery: z.object({
    state: z.enum(['prepared', 'unknown', 'queued', 'accepted', 'local']),
    messageId: Text.optional(),
  }).strict(),
  deliveryHistory: z.array(z.object({ state: Text, reference: Text, at: Time }).strict()).max(100),
  createdAt: Time,
}).strict()
export type WorkCharterNotice = z.infer<typeof WorkCharterNoticeSchema>

const ContractSnapshot = z.object({
  contract: WorkCharterContractSchema,
  authority: WorkCharterAuthoritySchema,
  roles: z.array(WorkCharterRoleAssignmentSchema),
  revision: Revision,
}).strict()
export const WorkCharterDtoSchema = z.object({
  id: WorkCharterIdSchema,
  contractFormat: z.literal('arrangement-v1'),
  arrangement: ArrangementSchema,
  continuity: z.enum(['current-task', 'durable']),
  controlLocator: Text.optional(),
  modelConfigPath: Text.optional(),
  target: WorkCharterTargetSchema,
  managedWorkstream: Text,
  contractState: z.enum(['draft', 'proposed', 'approved', 'superseded']),
  state: z.enum(['active', 'paused', 'closed']),
  revision: Revision,
  contract: WorkCharterContractSchema,
  authority: WorkCharterAuthoritySchema,
  roles: z.array(WorkCharterRoleAssignmentSchema).min(1).max(5),
  writer: z.object({ name: Text, workspace: Text, observation: Text }).strict().optional(),
  evidence: z.array(WorkCharterEvidenceSchema).max(1000),
  notices: z.array(WorkCharterNoticeSchema).max(2000),
  previousContracts: z.array(ContractSnapshot).max(100),
  predecessor: Text.optional(),
  successor: Text.optional(),
  lastStop: Text.optional(),
  createdAt: Time,
  updatedAt: Time,
}).strict().superRefine((charter, ctx) => {
  const fail = (message: string): void => { ctx.addIssue({ code: 'custom', message }) }
  const allowed = charter.arrangement === 'direct' ? ['primary', 'reviewer']
    : charter.arrangement === 'team' ? ['planner', 'executor', 'reviewer'] : ['orchestrator', 'planner', 'executor', 'reviewer']
  const required = allowed.filter(role => role !== 'reviewer')
  const roles = charter.roles.map(role => role.role)
  if (roles.some(role => !allowed.includes(role)) || required.some(role => !roles.includes(role as WorkCharterRole))) fail('incomplete or inapplicable responsibilities')
  if (new Set(roles).size !== roles.length || new Set(charter.roles.map(role => role.name)).size !== roles.length) fail('roles require distinct carriers')
  const leadRole = charter.arrangement === 'direct' ? 'primary' : charter.arrangement === 'team' ? 'planner' : 'orchestrator'
  if (charter.roles.find(role => role.role === leadRole)?.name !== 'lead') fail('governance lead must bind native lead')
  if ((charter.arrangement === 'direct') !== (charter.target.kind === 'session')) fail('arrangement and target disagree')
  if ((charter.continuity === 'durable' || charter.arrangement !== 'direct') && charter.controlLocator === undefined) fail('recoverable control locator required')
  if (charter.state === 'active' && charter.contractState !== 'approved') fail('only approved contracts may be active')
  if (charter.contractState === 'superseded' && charter.state !== 'closed') fail('superseded contracts must be closed')
  if (charter.writer !== undefined && !charter.roles.some(role => role.name === charter.writer?.name && role.role !== 'reviewer')) fail('writer must be a non-reviewer carrier')
  if (new Set(charter.evidence.map(item => item.id)).size !== charter.evidence.length) fail('duplicate evidence id')
  if (new Set(charter.notices.map(item => item.id)).size !== charter.notices.length) fail('duplicate notice id')
})
export type WorkCharterDto = z.infer<typeof WorkCharterDtoSchema>

export const CreateWorkCharterInputSchema = z.object({
  charterId: WorkCharterIdSchema,
  arrangement: ArrangementSchema,
  continuity: z.enum(['current-task', 'durable']),
  controlLocator: Text.optional(),
  modelConfigPath: Text.optional(),
  managedWorkstream: Text,
  contract: WorkCharterContractSchema,
  authority: WorkCharterAuthoritySchema,
  roles: z.array(WorkCharterRoleAssignmentSchema).min(1).max(5),
  predecessor: Text.optional(),
}).strict()
export type CreateWorkCharterInput = z.infer<typeof CreateWorkCharterInputSchema>
const MutationBase = { charterId: WorkCharterIdSchema, expectedRevision: Revision }
export const WorkCharterCommandSchema = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('propose') }).strict(),
  z.object({ kind: z.literal('approve'), approvalRef: Text }).strict(),
  z.object({ kind: z.literal('activate') }).strict(),
  z.object({ kind: z.literal('pause'), reason: Text }).strict(),
  z.object({ kind: z.literal('resume'), observation: Text }).strict(),
  z.object({ kind: z.literal('assign-writer'), name: Text, workspace: Text, observation: Text }).strict(),
  z.object({ kind: z.literal('release-writer'), observation: Text }).strict(),
  z.object({ kind: z.literal('writer-drift'), reason: Text }).strict(),
  z.object({ kind: z.literal('update-proposal'), proposal: Texts }).strict(),
  z.object({ kind: z.literal('revise-contract'), contract: WorkCharterContractSchema, authority: WorkCharterAuthoritySchema }).strict(),
  z.object({ kind: z.literal('declare-evidence'), evidence: WorkCharterEvidenceSchema }).strict(),
  z.object({ kind: z.literal('record-evidence'), evidenceId: Id, state: z.enum(['passed', 'failed', 'invalid', 'unknown']), reference: Text }).strict(),
  z.object({ kind: z.literal('consume-evidence'), evidenceId: Id, point: Text, reference: Text }).strict(),
  z.object({ kind: z.literal('reconcile-notice'), noticeId: Id, state: z.enum(['accepted', 'queued']), messageId: Text, reference: Text }).strict(),
  z.object({ kind: z.literal('close'), reference: Text }).strict(),
  z.object({ kind: z.literal('supersede'), successor: Text, reference: Text }).strict(),
]).readonly()
export const TransitionWorkCharterInputSchema = z.object({ ...MutationBase, command: WorkCharterCommandSchema }).strict()
export type TransitionWorkCharterInput = z.infer<typeof TransitionWorkCharterInputSchema>
export const SubmitWorkCharterNoticeInputSchema = z.object({
  ...MutationBase,
  notice: WorkCharterNoticeSchema.omit({ authorSessionId: true, authorityRevision: true, dependsOn: true, delivery: true, deliveryHistory: true, createdAt: true }),
}).strict()
export type SubmitWorkCharterNoticeInput = z.infer<typeof SubmitWorkCharterNoticeInputSchema>
export const GetWorkCharterInputSchema = z.object({ charterId: WorkCharterIdSchema }).strict()
export type GetWorkCharterInput = z.infer<typeof GetWorkCharterInputSchema>
export const ListWorkChartersInputSchema = z.object({}).strict()
export type ListWorkChartersInput = z.infer<typeof ListWorkChartersInputSchema>
export const ListSessionWorkChartersInputSchema = z.object({ sessionId: SessionIdSchema }).strict()
export type ListSessionWorkChartersInput = z.infer<typeof ListSessionWorkChartersInputSchema>
export interface WorkCharterMutationResult { readonly changed: boolean; readonly charter: WorkCharterDto }
export interface WorkCharterHealth {
  readonly service: 'work-charter-dsh'; readonly contractVersion: 2; readonly status: 'ok'
  readonly storage: { readonly schemaVersion: 2; readonly state: 'ready' }
  readonly upstream: { readonly version: '0.9.1'; readonly packageTree: string }
  readonly team: 'available' | 'unavailable'
}
export class WorkCharterError extends Error {
  constructor(readonly code: string, message: string, readonly retryable = false,
    readonly outcome: 'failed' | 'unknown' = 'failed', options?: ErrorOptions) {
    super(message, options); this.name = 'WorkCharterError'
  }
  toDTO(): { code: string; message: string; retryable: boolean; outcome: 'failed' | 'unknown' } {
    return { code: this.code, message: this.message, retryable: this.retryable, outcome: this.outcome }
  }
}
export type WorkCharterRemoteOutcome<T> = { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly error: ReturnType<WorkCharterError['toDTO']> }
export interface WorkCharterServiceContract {
  health(): Promise<WorkCharterHealth>
  createCharter(actor: Agent, input: CreateWorkCharterInput): Promise<WorkCharterMutationResult>
  getCharter(input: GetWorkCharterInput): Promise<WorkCharterDto>
  listCharters(input?: ListWorkChartersInput): Promise<readonly WorkCharterDto[]>
  listSessionCharters(input: ListSessionWorkChartersInput): Promise<readonly WorkCharterDto[]>
  transitionCharter(actor: Agent, input: TransitionWorkCharterInput): Promise<WorkCharterMutationResult>
  submitNotice(actor: Agent, input: SubmitWorkCharterNoticeInput, signal: AbortSignal): Promise<WorkCharterMutationResult>
}
