import { openSync, closeSync, readSync, fstatSync } from 'node:fs'
import { homedir } from 'node:os'
import { isAbsolute, join } from 'node:path'
import { createRequire } from 'node:module'
import { RoleModelError, resolveRoleModel, type ModelResolution, type ModelSource, type ResolveRoleModelInput } from './role-models.ts'

interface YamlState { readonly position: number; readonly anchor: string | null }
interface YamlApi {
  readonly JSON_SCHEMA: unknown
  load(source: string, options: {
    schema: unknown
    listener: (event: 'open' | 'close', state: YamlState) => void
  }): unknown
}
// Typed at this library boundary; only the public data parser is used.
const yaml = createRequire(import.meta.url)('js-yaml') as YamlApi
const DEFAULTS = new URL('../assets/role-models.default.yaml', import.meta.url)
const MAX_CONFIG_BYTES = 65_536

export function parseRoleModelYaml(source: string): unknown {
  if (Buffer.byteLength(source, 'utf8') > MAX_CONFIG_BYTES) {
    throw new RoleModelError('INVALID_CONFIGURATION', 'role-model file exceeds the bounded input size')
  }
  const positions: number[] = []
  try {
    if (/^%/m.test(source)) throw new Error('YAML directives are unsupported')
    return yaml.load(source, {
      schema: yaml.JSON_SCHEMA,
      listener: (event, state): void => {
        if (event === 'open') { positions.push(state.position); return }
        const start = positions.pop()
        if (start === undefined) throw new Error('unbalanced YAML node')
        const node = source.slice(start, state.position).replace(/^(?:\s|#[^\n]*(?:\n|$))*/, '')
        if (state.anchor !== null || /^[!&*%]/.test(node)) throw new Error('YAML tags, anchors, aliases and directives are unsupported')
      },
    })
  } catch {
    // Parser diagnostics can echo input values, including accidentally supplied secrets.
    throw new RoleModelError('INVALID_CONFIGURATION', 'invalid or unsupported role-model YAML')
  }
}

function fileSource(path: string | URL): ModelSource {
  const file = openSync(path, 'r')
  try {
    const stat = fstatSync(file)
    if (!stat.isFile() || stat.size > MAX_CONFIG_BYTES) throw new RoleModelError('INVALID_CONFIGURATION', 'role-model source must be a bounded regular file')
    const buffer = Buffer.alloc(MAX_CONFIG_BYTES + 1)
    let length = 0
    while (length < buffer.length) {
      const count = readSync(file, buffer, length, buffer.length - length, null)
      if (count === 0) break
      length += count
    }
    if (length > MAX_CONFIG_BYTES) throw new RoleModelError('INVALID_CONFIGURATION', 'role-model file exceeds the bounded input size')
    return { locator: String(path), configuration: parseRoleModelYaml(buffer.subarray(0, length).toString('utf8')) }
  } finally { closeSync(file) }
}

export function resolveRoleModelFile(input: Omit<ResolveRoleModelInput, 'selectedFile' | 'packageDefaults'> & {
  readonly explicitPath?: string
  readonly userPath?: string
  readonly packagePath?: string | URL
}): ModelResolution {
  const userPath = input.userPath ?? join(homedir(), '.config', 'work-charter', 'role-models.yaml')
  return resolveRoleModel({
    contract: input.contract,
    responsibility: input.responsibility,
    ...(input.frozen === undefined ? {} : { frozen: input.frozen }),
    ...(input.confirmed === undefined ? {} : { confirmed: input.confirmed }),
    selectedFile: (): ModelSource => {
      if (input.explicitPath !== undefined) {
        if (!isAbsolute(input.explicitPath)) throw new RoleModelError('INVALID_CONFIGURATION', 'explicit role-model path must be absolute')
        return fileSource(input.explicitPath)
      }
      try { return fileSource(userPath) } catch (error) {
        if (!(error instanceof Error && 'code' in error && error.code === 'ENOENT')) throw error
        // v1 historically permits an empty mapping. Its all-missing outcome
        // invokes packageDefaults only after the exact optional user file is absent.
        return { locator: userPath, configuration: { schema_version: 1, roles: {} } }
      }
    },
    packageDefaults: (): ModelSource => fileSource(input.packagePath ?? DEFAULTS),
  })
}
