import { describe, expect, it, vi } from 'vitest'
import {
  RoleModelConfigurationSchema,
  resolveRoleModel,
  toDshModelRoute,
  type ModelContract,
  type ModelSource,
  type ResolveRoleModelInput,
  type RoleModel,
} from '../../src/role-models.ts'

const DIRECT: ModelContract = { format: 'arrangement-v1', arrangement: 'direct' }
const TASK_MODEL: RoleModel = { provider: 'fixture', model: 'review-model', parameters: { reasoning_effort: 'high' } }
const DEFAULTS = {
  schema_version: 2,
  roles: { primary: { provider: 'fixture', model: 'primary-default' }, reviewer: TASK_MODEL },
  arrangement_overrides: { direct: { reviewer: { provider: 'fixture', model: 'arrangement-default' } } },
}
function input(overrides: Partial<ResolveRoleModelInput> = {}): ResolveRoleModelInput {
  return {
    contract: DIRECT,
    responsibility: 'reviewer',
    packageDefaults: () => ({ locator: 'package defaults', configuration: DEFAULTS }),
    ...overrides,
  }
}
function selected(configuration: unknown): NonNullable<ResolveRoleModelInput['selectedFile']> {
  return () => ({ locator: 'selected test source', configuration })
}

describe('Work Charter 0.9.1 complete-object model selection', () => {
  it('keeps the frozen object without reading any source or a newer confirmation', () => {
    const read = vi.fn(() => { throw new Error('source must not be read') })
    const result = resolveRoleModel(input({
      frozen: TASK_MODEL, confirmed: { provider: 'other', model: 'new' },
      selectedFile: read, packageDefaults: read,
    }))
    expect(result.source).toBe('frozen')
    expect(result.model).toEqual(TASK_MODEL)
    expect(result.model).not.toBe(TASK_MODEL)
    expect(Object.isFrozen(result.model?.parameters)).toBe(true)
    expect(read).not.toHaveBeenCalled()
  })

  it('does not merge parameters into an explicit confirmed object', () => {
    const model = { provider: 'fixture', model: 'task-selection' }
    const result = resolveRoleModel(input({ confirmed: model }))
    expect(result.model).toEqual(model)
    expect(toDshModelRoute(model)).toEqual(model)
  })

  it('gives a user general role priority over a package arrangement override', () => {
    const packageRead = vi.fn(() => ({ locator: 'package', configuration: DEFAULTS }))
    const result = resolveRoleModel(input({
      selectedFile: selected({ schema_version: 2, roles: { reviewer: TASK_MODEL } }),
      packageDefaults: packageRead,
    }))
    expect(result.source).toBe('selected-file')
    expect(result.model).toEqual(TASK_MODEL)
    expect(packageRead).not.toHaveBeenCalled()
  })

  it('uses the arrangement-specific whole object within the selected v2 file', () => {
    const model = { provider: 'different-provider', model: 'different-model' }
    const result = resolveRoleModel(input({ selectedFile: selected({
      ...DEFAULTS, arrangement_overrides: { direct: { reviewer: model } },
    }) }))
    expect(result.model).toEqual(model)
  })

  it('rejects an invalid unused role and never conceals a selected-file read error', () => {
    expect(() => resolveRoleModel(input({ selectedFile: selected({
      schema_version: 2, roles: { reviewer: TASK_MODEL, executor: { model: 'missing-provider' } },
    }) }))).toThrow(expect.objectContaining({ code: 'INVALID_CONFIGURATION' }))
    expect(() => resolveRoleModel(input({ selectedFile: () => { throw new Error('unreadable explicit source') } })))
      .toThrow('unreadable explicit source')
  })

  it('validates inert unused array/nested settings without applying DSH capability checks to them', () => {
    const result = resolveRoleModel(input({ selectedFile: selected({
      schema_version: 2,
      roles: {
        reviewer: TASK_MODEL,
        executor: { provider: 'other-host', model: 'other', parameters: { stop: ['END'], sampling: { enabled: true } } },
      },
    }) }))
    expect(result.model).toEqual(TASK_MODEL)
    expect(() => toDshModelRoute({ ...TASK_MODEL, parameters: { stop: ['END'] } }))
      .toThrow(expect.objectContaining({ code: 'UNSUPPORTED_PARAMETER' }))
  })

  it('compares nested values structurally and freezes detached arrays and objects', () => {
    const model = { provider: 'fixture', model: 'same', parameters: { stop: ['END'], sampling: { a: 1, b: true } } }
    const reordered = { ...model, parameters: { sampling: { b: true, a: 1 }, stop: ['END'] } }
    const result = resolveRoleModel(input({ selectedFile: selected({
      schema_version: 1, roles: { reviewer: model }, level_overrides: { l1: { reviewer: reordered } },
    }) }))
    expect(result.model).toEqual(model)
    model.parameters.stop.push('AFTER_SELECTION')
    model.parameters.sampling.a = 2
    expect(result.model?.parameters).toEqual({ stop: ['END'], sampling: { a: 1, b: true } })
    expect(Object.isFrozen(result.model?.parameters?.stop)).toBe(true)
    expect(Object.isFrozen(result.model?.parameters?.sampling)).toBe(true)
    expect(() => resolveRoleModel(input({ selectedFile: selected({
      schema_version: 1, roles: { reviewer: model }, level_overrides: { l1: { reviewer: reordered } },
    }) }))).toThrow(expect.objectContaining({ code: 'AMBIGUOUS_DIRECT' }))
  })

  it('rejects raw top-level and nested prohibited keys before the parser can drop them', () => {
    for (const json of ['{"__proto__":"x"}', '{"sampling":{"__proto__":"x"}}']) {
      const parameters: unknown = JSON.parse(json)
      expect(() => resolveRoleModel(input({ selectedFile: selected({
        schema_version: 2,
        roles: { reviewer: TASK_MODEL, executor: { provider: 'fixture', model: 'x', parameters } },
      }) }))).toThrow(expect.objectContaining({ code: 'INVALID_CONFIGURATION' }))
    }
  })

  it('uses an exact key order when distinct Unicode keys collate as equivalent', () => {
    const a = { ...TASK_MODEL, parameters: { sampling: { '\u00e9': 1, 'e\u0301': 2 } } }
    const b = { ...TASK_MODEL, parameters: { sampling: { 'e\u0301': 2, '\u00e9': 1 } } }
    expect(resolveRoleModel(input({ selectedFile: selected({
      schema_version: 1, roles: { reviewer: a }, level_overrides: { l1: { reviewer: b } },
    }) })).model).toEqual(a)
  })

  it.each([
    { schema_version: 2, arrangement_overrides: { direct: {} } },
    { schema_version: 2, roles: { main: TASK_MODEL } },
    { schema_version: 2, arrangement_overrides: { direct: { executor: TASK_MODEL } } },
    { schema_version: 1, arrangement_overrides: { direct: { reviewer: TASK_MODEL } } },
    { schema_version: 3, roles: { reviewer: TASK_MODEL } },
  ])('rejects invalid configuration topology %#', configuration => {
    expect(RoleModelConfigurationSchema.safeParse(configuration).success).toBe(false)
  })

  it('does not hide v1 Direct ambiguity with package fallback', () => {
    const config = {
      schema_version: 1, roles: { reviewer: TASK_MODEL },
      level_overrides: { l1: { reviewer: { ...TASK_MODEL, parameters: { reasoning_effort: 'medium' } } } },
    }
    const packageRead = vi.fn(() => ({ locator: 'package', configuration: DEFAULTS }))
    expect(() => resolveRoleModel(input({ selectedFile: selected(config), packageDefaults: packageRead })))
      .toThrow(expect.objectContaining({ code: 'AMBIGUOUS_DIRECT' }))
    expect(packageRead).not.toHaveBeenCalled()
  })

  it('treats present/missing Direct candidates as ambiguous even with identical model names', () => {
    expect(() => resolveRoleModel(input({ selectedFile: selected({
      schema_version: 1, level_overrides: { l2: { reviewer: TASK_MODEL } },
    }) }))).toThrow(expect.objectContaining({ code: 'AMBIGUOUS_DIRECT' }))
  })

  it('compares effective candidates, ignoring parameter order and omitted versus empty parameters', () => {
    const model = { provider: 'fixture', model: 'same' }
    const result = resolveRoleModel(input({ selectedFile: selected({
      schema_version: 1, roles: { reviewer: model },
      level_overrides: { l0: { reviewer: { ...model, parameters: {} } }, l1: {} },
    }) }))
    expect(result.model).toEqual({ ...model, parameters: {} })
    const a = { ...model, parameters: { reasoning_effort: 'high', max_output_tokens: 100 } }
    const b = { ...model, parameters: { max_output_tokens: 100, reasoning_effort: 'high' } }
    expect(resolveRoleModel(input({ selectedFile: selected({
      schema_version: 1, roles: { reviewer: a }, level_overrides: { l1: { reviewer: b } },
    }) })).model).toEqual(a)
  })

  it('uses legacy l3/l4 only as v1 compatibility candidates for new Team/Phased', () => {
    for (const [arrangement, level] of [['team', 'l3'], ['phased', 'l4']] as const) {
      const result = resolveRoleModel(input({
        contract: { format: 'arrangement-v1', arrangement },
        selectedFile: selected({ schema_version: 1, level_overrides: { [level]: { reviewer: TASK_MODEL } } }),
      }))
      expect(result.model).toEqual(TASK_MODEL)
    }
  })

  it('keeps old-contract exact-level lookup distinct from new Direct ambiguity', () => {
    const result = resolveRoleModel(input({
      contract: { format: 'legacy-level', level: 'l1' },
      selectedFile: selected({ schema_version: 2, legacy_level_overrides: { l1: { reviewer: TASK_MODEL } } }),
    }))
    expect(result.model).toEqual(TASK_MODEL)
  })

  it('falls through historically empty v1 mappings and permits only primary to retain host selection', () => {
    expect(resolveRoleModel(input({ selectedFile: selected({ schema_version: 1, roles: {} }) })).source).toBe('package')
    const defaults = (): ModelSource => ({ locator: 'package', configuration: { schema_version: 2, roles: { executor: TASK_MODEL } } })
    expect(resolveRoleModel(input({ responsibility: 'main', packageDefaults: defaults })))
      .toEqual({ source: 'host', locator: 'host selection', model: undefined })
    expect(() => resolveRoleModel(input({ packageDefaults: defaults })))
      .toThrow(expect.objectContaining({ code: 'MISSING_MODEL' }))
  })

  it('does not let a model object enable an inapplicable responsibility', () => {
    expect(() => resolveRoleModel(input({ responsibility: 'executor', confirmed: TASK_MODEL })))
      .toThrow(expect.objectContaining({ code: 'INVALID_ROLE' }))
  })

  it('maps the complete supported DSH route and rejects unsupported or invalid settings', () => {
    expect(toDshModelRoute({ ...TASK_MODEL, parameters: { reasoning_effort: 'high', max_output_tokens: 200 } }))
      .toEqual({ provider: 'fixture', model: 'review-model', reasoningEffort: 'high', maxTokens: 200 })
    for (const parameters of [{ temperature: 0.2 }, { max_output_tokens: 0 }, { reasoning_effort: 3 }]) {
      expect(() => toDshModelRoute({ ...TASK_MODEL, parameters }))
        .toThrow(expect.objectContaining({ code: 'UNSUPPORTED_PARAMETER' }))
    }
  })

  it('rejects endpoint/credential/command data without including its values in errors', () => {
    for (const model of [
      { provider: 'https://private.example', model: 'x' },
      { ...TASK_MODEL, parameters: { api_key: 'test-secret' } },
      { ...TASK_MODEL, parameters: { extension: { credential: 'nested-secret' } } },
      { ...TASK_MODEL, parameters: { reasoning_effort: '${COMMAND}' } },
    ]) {
      expect(() => resolveRoleModel(input({ confirmed: model }))).toThrow('invalid complete model object')
    }
  })
})
