import { describe, expect, it } from 'vitest'
import { admitNotice, createWorkCharterRecord, applyWorkCharterTransition } from '../../src/policy.ts'
import { WorkCharterDtoSchema, type WorkCharterDto, type SubmitWorkCharterNoticeInput } from '../../src/types.ts'
import { input, ready, transition, result, LEAD } from '../fixtures.ts'

function notice(row: WorkCharterDto, data: SubmitWorkCharterNoticeInput['notice']): WorkCharterDto {
  const next = admitNotice(row, { charterId: row.id, expectedRevision: row.revision, notice: data }, data.author, LEAD)
  // Pure policy fixture represents successful native delivery; transport is tested separately.
  const last = next.notices.at(-1)
  if (last !== undefined) last.delivery = { state: 'accepted', messageId: `native-${data.id}` }
  return next
}
function review(row: WorkCharterDto): WorkCharterDto {
  return notice(row, result({ id: 'review-1', kind: 'review', author: 'reviewer', recipient: 'executor', resultId: 'result-1', reviewer: undefined, reviewVerdict: 'pass' }))
}
function accept(row: WorkCharterDto): WorkCharterDto {
  return notice(row, result({ id: 'accept-1', kind: 'disposition', author: 'planner', recipient: 'executor', resultId: 'result-1', reviewer: undefined, verdict: 'accepted' }))
}
describe('arrangement policy and preserved evidence', () => {
  it('keeps contract approval separate from run state and rejects stale revisions', () => {
    const draft = createWorkCharterRecord(input(), LEAD)
    expect(draft).toMatchObject({ contractState: 'draft', state: 'paused' })
    expect(() => transition(draft, { kind: 'activate' })).toThrow('approved')
    const approved = ready()
    expect(transition(approved, { kind: 'activate' }).state).toBe('active')
    expect(() => applyWorkCharterTransition(approved, { charterId: approved.id, expectedRevision: 0, command: { kind: 'pause', reason: 'x' } }, 'planner')).toThrow('current Charter')
  })
  it('rejects arbitrary-session Team shapes, missing roles and R writers', () => {
    const row = ready()
    expect(WorkCharterDtoSchema.safeParse({ ...row, target: { kind: 'session', sessionId: LEAD } }).success).toBe(false)
    expect(WorkCharterDtoSchema.safeParse({ ...row, roles: [row.roles[0]] }).success).toBe(false)
    expect(() => transition(row, { kind: 'assign-writer', name: 'reviewer', workspace: 'fixture', observation: 'free' })).toThrow('reviewer')
  })
  it('allows ordinary Direct closure without creating a team', () => {
    expect(transition(ready('direct'), { kind: 'close', reference: 'accepted direct result' }).state).toBe('closed')
    expect(() => transition(ready(), { kind: 'close', reference: 'empty' })).toThrow('execution result')
  })
  it('requires released writer, independent review, then separate P disposition', () => {
    let row = transition(ready(), { kind: 'assign-writer', name: 'executor', workspace: 'fixture', observation: 'sole writer' })
    row = notice(row, result())
    expect(() => accept(row)).toThrow('independent review')
    expect(() => review(row)).toThrow('release the writer')
    row = transition(row, { kind: 'release-writer', observation: 'stable diff' }, 'executor')
    row = review(row)
    expect(() => transition(row, { kind: 'close', reference: 'R is not P' })).toThrow('disposition')
    row = accept(row)
    const closed = transition(row, { kind: 'close', reference: 'P accepted checkpoint-1' })
    expect(closed.state).toBe('closed')
    expect(() => transition(closed, { kind: 'resume', observation: 'retry' })).toThrow('terminal')
  })
  it('preserves consumption and failures across contract revisions', () => {
    let row = transition(ready(), { kind: 'declare-evidence', evidence: { id: 'one-shot', subject: 'review', checkpoint: 'a', required: true, state: 'declared', consumptionPoint: 'provider-dispatched', history: [] } })
    row = transition(row, { kind: 'record-evidence', evidenceId: 'one-shot', state: 'failed', reference: 'preflight failed before dispatch' }, 'executor')
    expect(row.evidence[0]?.consumedAt).toBeUndefined()
    expect(() => transition(row, { kind: 'consume-evidence', evidenceId: 'one-shot', point: 'started-shell', reference: 'bad point' })).toThrow('consumption point')
    row = transition(row, { kind: 'consume-evidence', evidenceId: 'one-shot', point: 'provider-dispatched', reference: 'dispatch log' })
    expect(() => transition(row, { kind: 'consume-evidence', evidenceId: 'one-shot', point: 'provider-dispatched', reference: 'again' })).toThrow('consumption point')
    row = transition(row, { kind: 'revise-contract', contract: row.contract, authority: { ...row.authority, revision: 1 } })
    expect(row.evidence[0]?.history).toHaveLength(2)
    expect(row.previousContracts).toHaveLength(1)
    expect(row.contractState).toBe('proposed')
  })
  it('does not let corrections erase reviewer, route or original result', () => {
    let row = notice(ready(), result())
    expect(() => notice(row, result({ id: 'result-2', checkpoint: 'checkpoint-2' }))).toThrow('explicitly correct')
    expect(() => notice(row, result({ id: 'result-2', checkpoint: 'checkpoint-2', corrects: 'result-1', reviewer: undefined }))).toThrow('preserves')
    row = notice(row, result({ id: 'result-2', checkpoint: 'checkpoint-2', corrects: 'result-1' }))
    expect(row.notices).toHaveLength(2)
    expect(() => review(row)).toThrow('superseded')
  })
  it('blocks continuation on uncertain handoff and unresolved decisions', () => {
    let row = ready()
    row = admitNotice(row, { charterId: row.id, expectedRevision: row.revision, notice: result() }, 'executor', LEAD)
    expect(() => transition(row, { kind: 'activate' })).toThrow('uncertain handoff')
    row = transition(row, { kind: 'reconcile-notice', noticeId: 'result-1', state: 'accepted', messageId: 'exact-native-message', reference: 'native log event with matching notice id, author and destination' })
    expect(row.notices[0]?.deliveryHistory.map(item => item.state)).toEqual(['prepared', 'accepted'])
    expect(row.state).toBe('paused')
    row = ready()
    row.contract.openDecisions.push('permission missing')
    expect(() => transition(row, { kind: 'activate' })).toThrow('open decisions')
  })
  it('prevents O bypass and requires accepted E outcome before P to O', () => {
    let row = ready('phased')
    expect(() => notice(row, result({ id: 'fact', kind: 'fact', author: 'orchestrator', recipient: 'executor', reviewer: undefined }))).toThrow('bypass')
    const phase = result({ id: 'phase-1', checkpoint: 'phase-check', subject: 'phase', author: 'planner', recipient: 'orchestrator', reviewer: undefined })
    expect(() => notice(row, phase)).toThrow('execution result')
    row = accept(review(notice(row, result())))
    row = notice(row, phase)
    expect(() => transition(row, { kind: 'close', reference: 'premature' })).toThrow('disposition')
    row = notice(row, { ...phase, id: 'phase-accepted', kind: 'disposition', author: 'orchestrator', recipient: 'planner', resultId: 'phase-1', verdict: 'accepted' })
    expect(transition(row, { kind: 'close', reference: 'O phase acceptance' }).state).toBe('closed')
  })
  it('blocks queued disposition until exact native delivery is recorded without resend', () => {
    let row = accept(review(notice(ready(), result())))
    const pending = row.notices.at(-1)
    if (pending === undefined) throw new Error('fixture missing')
    pending.delivery = { state: 'queued', messageId: 'original-native-id' }
    expect(() => transition(row, { kind: 'close', reference: 'not delivered' })).toThrow('queued')
    expect(() => transition(row, { kind: 'reconcile-notice', noticeId: pending.id, state: 'accepted', messageId: 'new-id', reference: 'cannot replace identity' })).toThrow('message identity')
    row = transition(row, { kind: 'reconcile-notice', noticeId: pending.id, state: 'accepted', messageId: 'original-native-id', reference: 'target inbox logged original message' })
    expect(transition(row, { kind: 'close', reference: 'delivered and accepted' }).state).toBe('closed')
  })
  it('requires current P to O acceptance and preserves chronology across corrected subjects', () => {
    let row = accept(review(notice(ready('phased'), result())))
    const phase = result({ id: 'phase-1', checkpoint: 'phase-check', subject: 'phase', author: 'planner', recipient: 'orchestrator', reviewer: undefined })
    row = notice(row, phase)
    row = notice(row, { ...phase, id: 'phase-accepted', kind: 'disposition', author: 'orchestrator', recipient: 'planner', resultId: 'phase-1', verdict: 'accepted' })
    const other = { ...phase, id: 'other-phase', subject: 'other subject', checkpoint: 'other-check' }
    row = notice(row, other)
    row = notice(row, { ...other, id: 'other-accepted', kind: 'disposition', author: 'orchestrator', recipient: 'planner', resultId: 'other-phase', verdict: 'accepted' })
    row = notice(row, result({ id: 'result-2', checkpoint: 'checkpoint-2', corrects: 'result-1' }))
    row = notice(row, result({ id: 'review-2', checkpoint: 'checkpoint-2', kind: 'review', author: 'reviewer', recipient: 'executor', resultId: 'result-2', reviewer: undefined, reviewVerdict: 'pass' }))
    row = notice(row, result({ id: 'accept-2', checkpoint: 'checkpoint-2', kind: 'disposition', author: 'planner', recipient: 'executor', resultId: 'result-2', reviewer: undefined, verdict: 'accepted' }))
    expect(() => transition(row, { kind: 'close', reference: 'old phase acceptance' })).toThrow('current execution results')
    row = notice(row, { ...phase, id: 'phase-2', checkpoint: 'phase-check-2', corrects: 'phase-1' })
    expect(row.notices.at(-1)?.dependsOn).toEqual(['result-2'])
    row = notice(row, { ...phase, id: 'phase-accepted-2', checkpoint: 'phase-check-2', kind: 'disposition', author: 'orchestrator', recipient: 'planner', resultId: 'phase-2', verdict: 'accepted' })
    expect(transition(row, { kind: 'close', reference: 'renewed O acceptance' }).state).toBe('closed')
  })
  it('does not supersede unresolved handoffs or an unreleased writer', () => {
    let row = ready()
    row = admitNotice(row, { charterId: row.id, expectedRevision: row.revision, notice: result() }, 'executor', LEAD)
    expect(() => transition(row, { kind: 'supersede', successor: 'next', reference: 'cannot escape unknown' })).toThrow('uncertain handoff')
    row = transition(ready(), { kind: 'assign-writer', name: 'executor', workspace: 'fixture', observation: 'still working' })
    expect(() => transition(row, { kind: 'supersede', successor: 'next', reference: 'cannot release by rename' })).toThrow('existing writer')
  })
  it('allows O to request R for its own product but not for E work', () => {
    let row = ready('phased')
    const own = result({ id: 'mandate', checkpoint: 'mandate-v1', subject: 'direction', author: 'orchestrator', recipient: 'orchestrator' })
    row = notice(row, own)
    row = notice(row, { ...own, id: 'mandate-review-request', kind: 'review-request', recipient: 'reviewer', resultId: 'mandate', reviewer: undefined })
    row = notice(row, { ...own, id: 'mandate-review', kind: 'review', author: 'reviewer', resultId: 'mandate', reviewer: undefined, reviewVerdict: 'pass' })
    row = notice(row, { ...own, id: 'mandate-accepted', kind: 'disposition', resultId: 'mandate', reviewer: undefined, verdict: 'accepted' })
    row = notice(row, result())
    expect(() => notice(row, result({ id: 'bypass-request', kind: 'review-request', author: 'orchestrator', recipient: 'reviewer', reviewer: undefined, resultId: 'result-1' }))).toThrow('original author')
  })
})
