import { mkdtempSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { describe, expect, it } from 'vitest'
import { parseRoleModelYaml, resolveRoleModelFile } from '../../src/role-model-files.ts'
import { RoleModelConfigurationSchema } from '../../src/role-models.ts'

const good = 'schema_version: 2\nroles:\n  reviewer:\n    provider: fixture\n    model: reviewer\n'
describe('bounded inert YAML and source identity', () => {
  it('parses the full data file and rejects duplicate keys without echoing values', () => {
    expect(RoleModelConfigurationSchema.safeParse(parseRoleModelYaml(good)).success).toBe(true)
    expect(() => parseRoleModelYaml(`${good}schema_version: secret-value`)).toThrow('invalid or unsupported')
    try { parseRoleModelYaml('x: [secret-value') } catch (error) { expect(String(error)).not.toContain('secret-value') }
  })
  it.each(['x: &anchor value', 'x: !custom value', 'x: !!str value', 'x: *alias', '%YAML 1.2\n---\nx: y'])('rejects non-data YAML: %s', text => {
    expect(() => parseRoleModelYaml(text)).toThrow()
  })
  it('rejects merge keys and secret-bearing nested parameter objects', () => {
    for (const key of ['<<', 'api_key', '__proto__']) {
      const text = `${good}    parameters:\n      ${key}: { value: x }\n`
      expect(RoleModelConfigurationSchema.safeParse(parseRoleModelYaml(text)).success).toBe(false)
    }
  })
  it('uses exact selected file, permits package fallback only when absent, and preserves frozen precedence', () => {
    const dir = mkdtempSync(join(tmpdir(), 'wcdp-models-'))
    const userPath = join(dir, 'user.yaml'); const packagePath = join(dir, 'defaults.yaml')
    writeFileSync(packagePath, good)
    const request = { contract: { format: 'arrangement-v1' as const, arrangement: 'team' as const }, responsibility: 'reviewer' as const, userPath, packagePath }
    expect(resolveRoleModelFile(request).source).toBe('package')
    writeFileSync(userPath, 'schema_version: 3')
    expect(() => resolveRoleModelFile(request)).toThrow('invalid role-model configuration')
    expect(() => resolveRoleModelFile({ ...request, explicitPath: join(dir, 'missing.yaml') })).toThrow()
    expect(resolveRoleModelFile({ ...request, explicitPath: 'relative', frozen: { provider: 'fixed', model: 'fixed' } }).source).toBe('frozen')
    writeFileSync(userPath, 'x'.repeat(65_537))
    expect(() => resolveRoleModelFile(request)).toThrow('bounded regular file')
  })
})
