import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { describe, expect, it } from 'vitest'
import { WorkCharterCoordinator } from '../../src/coordinator.ts'
import { assertWorkCharterStorageReady, type WorkCharterDomain } from '../../src/storage.ts'
import type { WorkCharterDto } from '../../src/types.ts'
import { CHILD, ID, LEAD, input, ready, result } from '../fixtures.ts'

interface Fixture {
  rows: Map<string, WorkCharterDto>
  state: { failPut: boolean; failSend: boolean; sends: number; foreign: boolean; beforeSend: (() => void) | undefined }
  domain: WorkCharterDomain
  ctx: Context
  lead: Agent
  child: Agent
  coordinator: WorkCharterCoordinator
}
function fixture(team = true): Fixture {
  const rows = new Map<string, WorkCharterDto>()
  const agents = new Map<string, Agent>()
  const lead = { id: LEAD } as Agent
  const child = { id: CHILD } as Agent
  agents.set(LEAD, lead); agents.set(CHILD, child)
  const state = { failPut: false, failSend: false, sends: 0, foreign: false, beforeSend: undefined as (() => void) | undefined }
  const service = {
    tryMembership: (actor: Agent): { id: string; name: string; role: string } => ({ id: state.foreign ? 'foreign' : LEAD, name: actor === lead ? 'lead' : 'executor', role: actor === lead ? 'lead' : 'teammate' }),
    membership: (actor: Agent): { id: string; name: string; role: string } => service.tryMembership(actor),
    listMembers: (): { id: string; name: string; description: string }[] => [{ id: CHILD, name: 'executor', description: `WCDP/2:${ID}:executor` }],
    sendMessage: (): Promise<{ status: string; messageId: string }> => {
      state.sends++; state.beforeSend?.()
      if (state.failSend) return Promise.reject(new Error('transport uncertain'))
      return Promise.resolve({ status: 'accepted', messageId: 'native-1' })
    },
  }
  const ctx = { agents: { get: (id: string): Agent | undefined => agents.get(id) }, get: (): typeof service | undefined => team ? service : undefined, agentTeams: service } as unknown as Context
  const domain = {
    global: { get: () => ({ state: 'ready', schemaVersion: 2 }) },
    table: () => ({ entries: (): IterableIterator<[string, WorkCharterDto]> => rows.entries(), put: (key: string, value: WorkCharterDto): Promise<void> => {
      if (state.failPut) return Promise.reject(new Error('disk failure'))
      rows.set(key, structuredClone(value)); return Promise.resolve()
    } }),
  } as unknown as WorkCharterDomain
  return { rows, state, domain, ctx, lead, child, coordinator: new WorkCharterCoordinator(domain, ctx) }
}
describe('native coordinator boundaries', () => {
  it('supports Direct without Team and refuses unsupported Team creation', async () => {
    const f = fixture(false)
    expect((await f.coordinator.createCharter(f.lead, input('direct'))).charter.target.kind).toBe('session')
    const other = fixture(false)
    await expect(other.coordinator.createCharter(other.lead, input())).rejects.toMatchObject({ code: 'TEAM_UNAVAILABLE' })
  })
  it('requires exact live Agent identity and rejects foreign membership', async () => {
    const f = fixture()
    f.rows.set(ID, ready())
    const args = { charterId: ID, expectedRevision: 2, command: { kind: 'pause' as const, reason: 'test' } }
    await expect(f.coordinator.transitionCharter({ id: LEAD } as Agent, args)).rejects.toMatchObject({ code: 'UNAUTHORIZED' })
    f.state.foreign = true
    await expect(f.coordinator.transitionCharter(f.child, args)).rejects.toMatchObject({ code: 'UNAUTHORIZED' })
  })
  it('serializes concurrent mutations so the second cannot use stale revision', async () => {
    const f = fixture()
    f.rows.set(ID, ready())
    const args = { charterId: ID, expectedRevision: 2, command: { kind: 'pause' as const, reason: 'test' } }
    const outcomes = await Promise.allSettled([f.coordinator.transitionCharter(f.lead, args), f.coordinator.transitionCharter(f.lead, args)])
    expect(outcomes.map(outcome => outcome.status)).toEqual(['fulfilled', 'rejected'])
  })
  it('persists notice identity before send, preserves UNKNOWN across reopen and never resends', async () => {
    const f = fixture()
    f.rows.set(ID, ready())
    f.state.beforeSend = (): void => { expect(f.rows.get(ID)?.notices[0]?.delivery.state).toBe('prepared') }
    f.state.failSend = true
    const sent = await f.coordinator.submitNotice(f.child, { charterId: ID, expectedRevision: 2, notice: result() }, new AbortController().signal)
    expect(sent.charter.notices[0]?.delivery.state).toBe('unknown')
    expect(sent.charter.state).toBe('paused')
    const reopened = new WorkCharterCoordinator(f.domain, f.ctx)
    await expect(reopened.submitNotice(f.child, { charterId: ID, expectedRevision: sent.charter.revision, notice: result() }, new AbortController().signal)).rejects.toThrow('uncertain handoff')
    expect(f.state.sends).toBe(1)
  })
  it('never sends after uncertain persistence and latches storage UNKNOWN', async () => {
    const f = fixture()
    f.rows.set(ID, ready()); f.state.failPut = true
    await expect(f.coordinator.submitNotice(f.child, { charterId: ID, expectedRevision: 2, notice: result() }, new AbortController().signal)).rejects.toMatchObject({ code: 'STORAGE_UNKNOWN' })
    expect(f.state.sends).toBe(0)
    expect(() => f.coordinator.listCharters()).toThrow('reopen storage')
  })
  it('routes whole frozen config and refuses missing paired store', async () => {
    const f = fixture()
    f.rows.set(ID, ready())
    let fallback = 0
    const inherited = (): Promise<{ provider: string; model: string }> => { fallback++; return Promise.resolve({ provider: 'lead', model: 'lead' }) }
    expect(await f.coordinator.modelRoute(f.child, inherited)).toEqual({ provider: 'fixture', model: 'role-model', reasoningEffort: 'high', maxTokens: 512 })
    f.rows.clear()
    await expect(f.coordinator.modelRoute(f.child, inherited)).rejects.toMatchObject({ code: 'MODEL_BINDING_UNAVAILABLE' })
    expect(fallback).toBe(0)
  })
  it('never falls back when a persisted role has lost its Team service', async () => {
    const f = fixture(false)
    const row = ready()
    const role = row.roles.find(item => item.role === 'executor')
    if (role === undefined) throw new Error('fixture role missing')
    role.sessionId = CHILD
    f.rows.set(ID, row)
    let fallback = 0
    await expect(f.coordinator.modelRoute(f.child, () => { fallback++; return Promise.resolve({ provider: 'wrong', model: 'wrong' }) })).rejects.toMatchObject({ code: 'TEAM_UNAVAILABLE' })
    expect(fallback).toBe(0)
  })
  it('rejects legacy metadata and incompatible rows without writing', () => {
    const f = fixture()
    const old = { ...f.domain, global: { get: () => ({ state: 'ready', schemaVersion: 1 }) } } as unknown as WorkCharterDomain
    expect(() => { assertWorkCharterStorageReady(old) }).toThrow('metadata')
    f.rows.set(ID, { id: ID, policy: 'l4' } as unknown as WorkCharterDto)
    const before = JSON.stringify([...f.rows])
    expect(() => { assertWorkCharterStorageReady(f.domain) }).toThrow('incompatible row')
    expect(JSON.stringify([...f.rows])).toBe(before)
  })
})
