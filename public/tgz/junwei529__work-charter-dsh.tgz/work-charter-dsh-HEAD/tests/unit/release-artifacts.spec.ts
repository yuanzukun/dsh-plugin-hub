import { readFile } from 'node:fs/promises'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { expect, it } from 'vitest'

interface Factory { id: string; factory: (require: NodeJS.Require) => { apply: (ctx: unknown) => Promise<void>; inject: string[] } }
it('loads the built lazy browser factory without Node imports or extra runtime copies', async () => {
  let contribution: Factory | undefined
  const bundle = await readFile(new URL('../../lib/client.js', import.meta.url), 'utf8')
  vm.runInNewContext(bundle, { window: { __ModuleLoader__: { load: (entry: Factory): void => { contribution = entry } } } })
  expect(contribution?.id).toBe('work-charter-dsh')
  const dependencies: string[] = []
  const realRequire = createRequire(import.meta.url)
  const requireStub = ((id: string): unknown => { dependencies.push(id); return realRequire(id) as unknown }) as NodeJS.Require
  const client = contribution?.factory(requireStub)
  expect(client?.inject).toEqual(['remote', 'slots'])
  expect(typeof client?.apply).toBe('function')
  expect([...new Set(dependencies)].sort()).toEqual(['react', 'react/jsx-runtime'])
})

it('packs the complete runtime schema closure and defaults without SCDP', async () => {
  const manifest = JSON.parse(await readFile(new URL('../../package.json', import.meta.url), 'utf8')) as { files: string[]; peerDependencies: Record<string, string>; dependencies: Record<string, string> }
  expect(manifest.files).toContain('assets/role-models.default.yaml')
  expect(manifest.files).toContain('lib/types/role-models.js')
  expect({ ...manifest.peerDependencies, ...manifest.dependencies }).not.toHaveProperty('session-coordinator-dsh')
  const patch = await readFile(new URL('../../cordis.patch.yml', import.meta.url), 'utf8')
  expect(patch).not.toMatch(/name:\s*session-coordinator-dsh/)
})
