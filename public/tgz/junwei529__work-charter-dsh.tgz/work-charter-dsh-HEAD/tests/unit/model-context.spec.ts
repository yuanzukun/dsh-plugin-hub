import { expect, it } from 'vitest'
import { renderWorkCharterContext, WORK_CHARTER_CONTEXT_MAX_CHARS } from '../../src/model-context.ts'
import { ready, LEAD } from '../fixtures.ts'
it('renders exact snapshot and advisory limits', () => {
  const row = ready()
  const text = renderWorkCharterContext({ sessionId: LEAD, charters: [row] })
  expect(text).toContain(JSON.stringify(row))
  expect(text).toContain('cannot lock files')
  expect(text).toContain('not inspection, acceptance or model consumption')
  expect(renderWorkCharterContext({ sessionId: LEAD, charters: [{ ...row, state: 'closed' }] })).toBe('')
})
it('signals bounded truncation instead of implying a complete snapshot', () => {
  const row = ready()
  row.contract.scope = Array.from({ length: 100 }, () => 'x'.repeat(8000))
  const text = renderWorkCharterContext({ sessionId: LEAD, charters: [row] })
  expect(text.length).toBeLessThanOrEqual(WORK_CHARTER_CONTEXT_MAX_CHARS)
  expect(text).toContain('TRUNCATED: stop affected work')
})
