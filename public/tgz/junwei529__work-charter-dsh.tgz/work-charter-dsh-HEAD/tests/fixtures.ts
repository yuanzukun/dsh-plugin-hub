import { SessionId } from '@deepseek-ai/dsh-session'
import { createWorkCharterRecord, applyWorkCharterTransition } from '../src/policy.ts'
import type { CreateWorkCharterInput, WorkCharterDto, TransitionWorkCharterInput, WorkCharterRole, SubmitWorkCharterNoticeInput } from '../src/types.ts'

export const LEAD = SessionId('fixture-lead')
export const CHILD = SessionId('fixture-child')
export const ID = 'wc_22222222-2222-4222-8222-222222222222'
export const MODEL = { provider: 'fixture', model: 'role-model', parameters: { reasoning_effort: 'high', max_output_tokens: 512 } }
export function input(arrangement: CreateWorkCharterInput['arrangement'] = 'team'): CreateWorkCharterInput {
  return {
    charterId: ID, arrangement, continuity: 'durable', controlLocator: 'fixture/control', managedWorkstream: 'successor fixture',
    contract: { outcome: 'verified result', scope: ['fixture'], nonGoals: ['publication'], confirmedContract: ['native Team'], necessaryGuardrails: ['one writer'], workingProposal: [], openDecisions: [], acceptance: ['evidence and owner acceptance'], stopConditions: ['unknown delivery'] },
    authority: { revision: 0, reference: 'user fixture authority', authorizedActions: ['fixture'], prohibitedActions: ['external effects'] },
    roles: arrangement === 'direct' ? [{ role: 'primary', name: 'lead' }]
      : [...(arrangement === 'phased' ? [{ role: 'orchestrator' as const, name: 'lead' }, { role: 'planner' as const, name: 'planner', model: MODEL }] : [{ role: 'planner' as const, name: 'lead' }]),
        { role: 'executor', name: 'executor', model: MODEL }, { role: 'reviewer', name: 'reviewer', model: MODEL }],
  }
}
export function transition(charter: WorkCharterDto, command: TransitionWorkCharterInput['command'], actor: WorkCharterRole = charter.arrangement === 'direct' ? 'primary' : charter.arrangement === 'team' ? 'planner' : 'orchestrator'): WorkCharterDto {
  return applyWorkCharterTransition(charter, { charterId: charter.id, expectedRevision: charter.revision, command }, actor)
}
export function ready(arrangement: CreateWorkCharterInput['arrangement'] = 'team'): WorkCharterDto {
  let row = createWorkCharterRecord(input(arrangement), LEAD)
  row = transition(row, { kind: 'propose' })
  return transition(row, { kind: 'approve', approvalRef: 'external/user/fixture' })
}
export function result(overrides: Partial<SubmitWorkCharterNoticeInput['notice']> = {}): SubmitWorkCharterNoticeInput['notice'] {
  return { id: 'result-1', kind: 'result', checkpoint: 'checkpoint-1', subject: 'implementation', summary: 'done; fixture checked', author: 'executor', recipient: 'planner', reviewer: 'reviewer', findings: [], evidenceIds: [], ...overrides }
}
