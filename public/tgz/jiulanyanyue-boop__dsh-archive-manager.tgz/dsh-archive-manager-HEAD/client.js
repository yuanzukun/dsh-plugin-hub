/**
 * archive-manager · 浏览器半侧
 *
 * 只做一件事：往设置页的 `settings.section` 槽里挂一个「归档会话管理」整页。
 * 数据、恢复、删除都走 Host 半侧登记的 `/plugins/archive-manager/*` 路由，
 * 浏览器这里不碰任何存储、不依赖设置服务（schemastery / whileServed 那一整套链都不需要）。
 *
 * 三条交互承诺：
 *  ① 每条归档会话的「恢复 / 删除」按钮默认隐藏，指针悬停（或键盘聚焦）时平滑淡入；
 *  ② 恢复：立刻从注册表摘掉归档 id —— 宿主的 workspace 归档帧会自动让会话列表重新出现它，
 *     同时这里主动 `ctx.sessions.refresh()` 兜底，保证不刷新页面就能看到；
 *  ③ 删除：二次确认后才发请求，成功后本地先摘掉这一行再刷新宿主列表，
 *     设置页的列表即时消失、不残留、不需要手动刷新。
 *
 * 界面全部使用宿主既有的主题别名变量（--dsw-alias-*）与圆角变量（--dsw-radius-*），
 * 因此浅色/深色/任何皮肤下都跟宿主保持一致。
 *
 * @module archive-manager/client
 */

window.__ModuleLoader__.load({
  id: 'archive-manager',
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })

    /** 包名，同时是设置 slot 的 id 与路由前缀的一段。 */
    var PKG = 'archive-manager'
    /** Host 半侧登记的路由前缀（与 host.js 的 ROUTE 必须一致）。 */
    var ROUTE = '/plugins/archive-manager'
    /**
     * 插件图标（Q 版鲸鱼娘，由使用者提供的插画切图内嵌）。
     * 内嵌为 data URL 而不是外部文件：桌面端以 file:// 加载 dist，外链图片会受 CSP/跨源限制，
     * 内嵌则在 Web 与桌面端行为完全一致，也不额外暴露一个静态路由。
     */
    var PLUGIN_ICON_DATA_URL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAACwOSURBVHhejZt3VFXZsu79441xx3s3vHPuvSf06dPdtpmggggCiuScM0hOggQBBRQDJhSUICAggiiIgrnNjTliwJwVA5IziOTk7401t9La3efdM8co9tprLfaa3zeralbVnGuMjY1D4oljJxNfvnyTWF1dnzgyMpI4NDT0hYwkDo2QOND1PnHgfWvi40dPEweGRhIBIV/fO5Q4NDA0eu3Nq8rEgwePJJ48cVp87+sbSExYvylx6dLlicV79o7e93vym9/9Qka+fP7Ab6//nki4urp6EgP8FiTO0dRONDa2SgwMDE0cMzw0zD/VBtpguIOqJ/coPXqSB/ef/vqO0TY0NEzx7gPs3lXCz6fOUFJ8iNycnWxJ38q5sxe5e+c+x46eIj+vkI8jH2lpbuPQwWMcO3KKsmu3GBr8//ep60MP505f/PXpf6pJv93e2k5vT7/4PkbqgETC0ODQb2X4IwOdrfTXPKO/9gX9dS+htZLOt485tXcPmzelio63tnWIH5N+5/y5S0QsjOHpk2dfPfjK5es8ffLiq3N7du8jcUMKiyNjefjgERUvX3Hq5Gni123i5PHSr+7t+tDNkcMnuHv7vvh+9/Y9EtYn01DfCB8lYL/T/98RCa9oH2FkeIQxv75hVIaGGezrFaA/g5cdv2SwoQI6a+ipec7pA8WkJW4if3shcXEJZGbmcfL4aSrfVnP7xm2unL/Mz4ePceXnUs4cOkrZleu8fPGad5U19H0aha73H77EKlr04liOHz1JdXUtz5+9FOeaGpvZnltAztZ88f1VxWuSNm5mcGDwHw/i/yD/mABp9DuaZKP/GfyvZLBeRsRw02suHd1PRuJGLp46yfUzpdw5V8rz6xeoeXCdlqfl9Lx6QP2da9w4epjrx37i7L4Sjpfs4/KFa1S+qRWABvr6R0foXWUVm1MyiFuxlpyt20lNzqCqqkZcO116jvTN2eL4+NFTXDx/WRz/BsM/If+AgGFGhob52FZNf90Xo/8PZEAyjY5qaHvHkKQdbZXCVD62vBXkSBojadFAfQUDNc8ZqHpGz+uH1N+6zNmd+WxJTGVX4UEe3HtGf28f7c3tApAANTAkPl++qCBuxToePngsvp849jMnT5xmoH+QZ09e8HFk5Hdw/M/yuwQMD4/Q0drGi7ILDNQ9h/c1DDe/ob++4jfg/2mpfk7328fU375K04ObtD69w/uKB/RXPePNpdMUJGzCxzOE1NRCzp++xMtnr2isaxJgh4dkJLS3dZC8KY3BgQFhww8fPOHjR5nG/BqDZMISjt+c/6cIGBqm60MXl0ovsHf7Tn7eU0h1+WVofi1GerDx9W8B/k8ijX7DK/pqntP15hEdL+5Rd+caVdcv0vbintCI1ZGxjJ3ihrXjSrZtO8Cd8gc01jfT86FbOCypRS9ewY78XZ/0Q6Yhv+6/zH/1MdDVJY5/c/1LAiST+z2mPj+wp6ePG2W3yNuSQ27CBm4dKqbr5V1oecvH1koB6jdgfyWDDa+EedD4ipHGCmh9De1vob9BmErT/Ru8unaR28cOoKXtz3eTA1FUWcDa+J1cuVDG64pK0ZfB/gH27z3CX/+mzJKYVQx90ozf9B3obajlw7P74vjX178ioL25hT7J+XwxlUjtc3zwmQip3b3/GDNjG4I9vDmZn8ubSz9Dwwtof/e7RAw2vqLj+T2qL56mID6eeVbemOi6YWkaiIdjGBuXb6C89CgDjS+g5TVFaSmMk3dn2qwIFFXDGT89nKjY7dy/85Dy6/cZ7BsQ/fj55AWys7YTv24jPd09X5MwNExfaxNdz27RfqOUntqq34D+ioAXqZk83LWbzpY2RkZGhG3V1TbQ093L2zeVnCk9L+ys830nCeuTeP68gqbGVl5VvCFl3UYiPBdQVlIgSPhsHpKzEypfXyEcYM+7pzwrO8+tc6c5sms3bk6RTJwRwUSVaBRmBGJg4IevVxQWlpEC+HT1SGbOjUXDaD1T1JYTFZvH/TsPuH/nCe9bZTGH1E6XniVwfohwgNJACVDDI3RXvaG97Gdarx6n88XjT2B/3xTG9O7YTX1aFi+OnhQ/2tXVzbat+fT19pOZsY262npxflvODsqu3Rh9+PUr5XgFpjFJdRE/jjMlLmQRLy+eYKj68S8q3v6WkcYXDNY/g7bX0FUFnW9pfXQRPePFqBkmoWmajPLc1YxTCGSqxhLmmG5C02gDmsYJMjHZyCSVpWzOOMidm/eoqapDUlep81IL8A9n6ZI14vhzLCDpbFfFU97fuy6OBz/5NalJLvMrAtpzC+nYsp2KohJxw9XL1zl/7iLPnr6gpPiAOFdf10BGWpYM+chHnj58jHdoNnr2WajqxDFjbhxjFQKYNMkUS0N3At3DiPCPItB7MW7zYnBxi8Nl3kq8vOPw9FiBhVUUGoZrBTgJ5GzTjWiaJDJTeznqBuuYbZL4CwHGG1A3TEBRPZZTP5dx41o5TfXNYtSldv/eU/7tD2oixJaaBGp4ZIS+1lZ6mxoZkrRjZISBgUFqHz+jpab2K78gCGhJy6Hi8DHxA4cOHuXtm3cc2P8TTx/Lwllp+oldsoreHmmObiIgPBsTzyLUDdeLTkqjNkt/NUqzlzFNazXyGiuYrBqDvPpylLTjmaGbgIqeJBtQ0l4vjrXMk9G12Yyu9Wb0bNOYa5GMtkUy6gZrhOprGG0QRMwxTRTX1I2TsHBYz/27j3j65KVs3u/vZ0lMIv/3r05ozHHlw/sOEUgNSZHh8AjDn8L8/v4BHh84zKv87TzduJnKW7cFLkkbxnRuL6IyKYPqB4/EyWdPX4pk4XpZOe87Ounv7ydpUzp52fm0VFURvSwb6wWH0LbaLMDrWKUy1zxJaMIc040ChJbZJmabJKBtmYqWeZIgSst0I7qWyehYpaBrnYauTTp6NmkYOGSib7cFXetU9O23oGuThoZhPHMtUmTX7bZgYJ+JsUsu8hor2ZxxgJtlt3nz8i39Pb3k5exG2yCEP491I2lTxqgWfBap1Tx4zJukdLr3HaRr6w4eZeXRWFtLW0MjYz5k5fN02w56+/oEa1KTHMrnkPTI4eMc+em4ON6eU4Kl/y5cIo5h6bYNPalzDlnMNd+IltlGdCxT0LdJE8cSEDPPnXjHXcI58jh6dhkYOmZh5LwVI6et6NlmyO63zxQALXyLcIw4Jr5rW0okbRbkGDhki2cYOGajbb2F2fpLuHb1NuU374+awb07d5GfGY7yLA+aG+qF0/6SgNcXLlOfkkXHtkKkAX+bnsOz1ExeJm9hzOOkdN59UokvmRNO4yMkbUyjtrKG54+e4h6YgX3QfpwCd2PomI2h41bRUS3zTVh4FWDqth0923TmWiRht+AAnisuELTxDoGJ5QSsv4FrTCkui05gF7QPY9dcAVQCZ+W3Gwu/PXiuvIRN4F5BiI7VZgFagP8kRk45TFaJIjEhn+tXb/G+/b3od29XJ/oWy/hOfgHbcnZ+hUVqEr6a5Eze5+1CMnnp80PeLnryihjT2fH+081fTxPCdvr62Lghhcd3nxAZlYGD706hlkZO2ejbZ4mOSuovgXGNOY1tyCEBysxjBz5rruG39hrzN9wkMOGWEPfYszhHncJ6fgnG8/KEphg6bcXIZZv4lDTGwrtQgNWxThMm8VlDpE+J9DkWmzGxXMahfSd496aakeFhrl66iuqcUKbNWYe1XagA/ZkEKb5pqa2nIjVLgJYI+Czd24sYMyI5Cslh/INoMCMtk+CQeGy9t6NjmYqO9ebRzkijr22VgqnUcd8iTOblCYdl6rEDh7Cf8F19heDke3ivuozBvO0YOOdg5JqH/qcRnamzCj1bmRkJkHZbhEi/LWmSRIKF545PRMjIMHLOZZrGYuLXpHP76k0BNDBwKeMU/NEwSmLiFBvi4hK5fv22bLqUwuKREZ7v2c/7zDw+5O6ic1sB7Zl5vN6QKssFpBCzr7tHeM0vCZBaetpWZurFomOdIRzaLyqZLRzg59GROq5nI1N/6br03dyrAKeIYwK0jk366H3iukM2usZL0LZKFqb0pap/FokA18gjmLrn4RSyF13bDGEGqnprMLMOZ/WmEq5ef8KpI6f4caIz0zUjsV18BJu15biHpdHf3TkaydY+esLj9cm8St/K8+w8nhWV8O72XcZIl1tfPKPu8jl6OztHSZBa5etXGFpFo2uTJcAbftE5CYikDdJoyexzq5jL1Y3iMXLOGb1H8vafQX8pmpYZbFiWTqBvIppWkkZlCccoVN4hS/yu9ExL/z2Ye+3Ebv5u9O1kTlHbfBPG/gUE7mjCO+0ZjmHbUZjpj/OKc0TuaSdsTycukTtoqnkncEjmLBVNpBigrbGRrg8fGPyURQoCejs6aLldRuP1Swz0/jIbLF+ZjKpRIjPmLhNe/TNY6VMC//mcrn0mug456JnHoW8Zj4GjjAAhX9iw7JzkP7agbJhEUUoBz44dQtNsI3r2W0cJkz1jq9AmXds04R/0Rv8/S5ie9YIDhO9pZX5mBc7LrxCQ/gLPdeV4rr1ByK423KN20tZQO1ouk0iQIEu4pc/hT+fHdLc0CwIkJ9hVU8VAjyy5qHjxjLkmUahoL0NRxQPDT6A+27/UOWnERKccs9GwSCMtegOubknMtZHN5xJQY9ftmLoXYOq+EzOvIiEm8/KZZZJEkP86Xt6/w6a1ecy2zcHCpxgDRxkREmhty2S0zDf+xkSkPug5ZhOcV0VIXhXeCXdQNVrJLJPleCXeJrSgDZuAdJrrqgSWr5z7R+huaqSnqVEM9Ji6sks0XSql4+Ed2Q2fRj8jYwdT1GIwMfXC0DoOU3dZx6WARLLD2SbrR0d1rm02Di6baCo7jZtvBmom0sywXYiFz26s5+/DJnAfzgv2Yh+0D6v5BzB0zWNf0TF+PnaOgrx9OHtvZq59DibuO4WtC5Itk9E0jhdkCOCfRMwGpptwW3uT0PxaLIP28fcfTPhxrBmTp3kx0zQBn6B4gWM0SRIh8kd662tpvnyajqcPBBljetra6K6vpbvmHYO9fUizwsjwIC6ecShrhhAUEIy2dRIW3sWYeRRi7lWEsWseGoZrRlVa3TyNXdl7eXmnHHPHBAHCKmAflr67sfMvwjNsLx4hxfguLMYjeDeWnjtwCdjOu0f3YaCDoY4mWioriI7dIWYSG698YWLSDDNLfxWGTr+YlK59FnqSH7BMQWnuYow881EzimPKVC+U1COZrhbONM1o9E0CuH/v7hckSH5gQAx0d12NSJAk5y98gMSEzCZkGVN3ZzuaOoF8/6M+P/yoh77jVsw9i2QEeBRi5JLHLL3VQlWN3QowdExj59Y9XDh7jcyMfVi45+EQsAv/yP24h+4lJOYg8xftIzjmEN4hO7FySWX56hJ6Girpa66jp7GKkffN9LXUkp19BFvvPNQMNzDbNFHkBqZuO4XmSaYgZhJJC5xymCA3j3GTrZmuGcpU1TCmqS0Un8qai1FQi2LCFCuKCvcITKOmMDQsCGi/e4Om8jLGSPnzqIp8Uv+fDh5m7CRrxk10RG66t3i4AO+5Cyu/EjHCM3VWYuS8DS37PFas3sWHhioY/MCz23fx8N+Cl28SESuOERh1SAAPiz1M2PLjLIzcirtPCrsKS6GriZ6menqa6+luqmOgrRG6mim/dofABalM14hmjnkSVgF7sfSVNFAiW3LEstxAQSWIceOsUZwZyvRZEYKAzyRI2iCvEsGf/27GggVR1H/yB1LrePGEzueP+FD17peaoHCNQMHOPUxQcOL7CdaMm2DPNLUQjF3yZOD992IduB8z712o6ixH1z4bY+ctPLhxF3ra6G2qY+R9E+lpe4mLTiI8ZjdhsUcEAQtjf8IzrITNq7OJjc3n9cOHjHQ00NdcS0/9O/jQBj2dDHe0SF4KOt6yKjKBqdprsQk8gNX8fVj5l2DmXiAzCcccZhsuRXGaI2MnuTJx6nymKAUjpxyCoqpERDjTZknFlcV8O34e6lqeZGfvoK6mepQI4QNGl8Y+DrF2zSb++oMVU2dF8904U779uz7Ksxdh6LQNS79i0QnJoVn47kHdaAMaBiuJWJzNQJsEpJ6epjqGO5qpfP6SzPTd7Nz+Ez4LiwldeoTgJYfxCsrl5KGf2V/yM3Q20l35jK6nd6CtjrLSk5w8eJC6iucMNldBXxuvb15FyyAGi/kHBXhJEyx89simSOsMbN0zSUg5RNy6Imyd49AxWsQcvQgUZwQwQcGHcXI+jJf3EeT8qLCAv4x1RX66E55e4dTX1YuEb4yE/e6d2zi7LuQvP9gzVW0R02dF8uNkZ/72gznKmpEYOGyVdWD+XtEJiQgl3fXMc1nOzXMXGOlspbuxFrraGelohpYa7l27yfN79zmw9ww+Ybtx9slkydIcklP30vr2OUPtDQzWv+Lu2Z+xtHDiX/7PWMaM+Q/+8N9yKCjMJn9zOnRWExSSjrGPjHRpEKzn7xezgqZpEjZuGezad4trd5u5dLOO05ff8tOpJ+wsvkZK1kmiluUTHr2NyJgcFi7OxNl9PQozfJCT1+XNq9ciaxzj4bWYHyba8c14byZNCxasySsFoKjsjYp6ALP014j83tJPIkCmhjZBB5mml8jGlRnQ1QjdHTDSz52rV7h/5SL1D+9A01tx7eX9+6zfUEhB3iHKL1/n+b2HtFS+5WNXGxXlN1FX0sbG3J6tKensSMskJjQauQkq/Pu/fMOyoIWERW7DJfI45r7F4tmSCUoxhqpBPBZOGzhwtJwbD9q5eLOB6w/auXavlat3Wyh/8oFrd1vE8akLr1m9dgtbMnLYv/cQzU2y9QYRCP3Hf+tjZBmHi3cyrl4biVlRQP7uqxSUlLEx7Qg6ZqtR1lqOqUeBeLjtwqM4LDmDmm0mqatTpDiSJzfKWLJ4Gf/67+P4l//9LRMmzGTFwig6q17yvraKnsYa+NDIQFO1sPv+5hoG2xp4WV7OoysXoacRGt9A1TOoq+DDw5ukxq4ia00C8xftxjPuClYLDgjtsw06iLJWFEqzYxiv4I36bC+y8k5yrPQBCcl72LXvKqcvvWJr/kliYxPYkLiVxIQMym+Wj9r+Z/CCgJ35RcSvS2b1uq2cvVbFlduNnCurpvxJF0dKn2MzLwU5ZV8MHTdjF3ECu5hSHJecwWrhcSwt/OmsqcDO0IoxY/4XXq7+HNxVyLHi3aTFJ/HsxnVGPrTR29xAb30lA5+W2UTVuO4lQ83voL2KnpcP6Ci/SNv1UtpulPLhznl4d5fzJQdxjDyOU/RZbCKPY7fohIgvpigHMlU9gsnTFzB+khtySr7MNljMBDk3FJU9mabiyVwtW7o/dDDQ1/cb0F+K8AEjw0OiqJiQsIWkpK2sXLmRTam7CAjegLJGEJOnuqFusBSnmLO4Lr+Ay5IzBCTcxcA6Dh8bF8b9TZH9WdnQVAkSqPc10NtKX0uj8A19rY0MttUx2PqGobZK+kZXi17SX/OC9/euCuCt10tpKSul4+ZpuspPsWb1TjxWleEQeQLnZecE8boOWUyeHoSC2iLkpgUgPz2AGXOWomGSjJreGlFWn6IUxndjTbl/VxYI/Rr0VwRIf36ZCaRMcJCBgX6OHDrMN9+ZMEUphMnT56MwMxjHyBN4rSnDY/VV3JdfxC1iP6vDY3l55jjDz8vpvHOJDw9u0v30rgDW21RLT2Md7VVvqSq/wduDB6k5dYIbBQW8vnqRIWkafPecrke36Sg/R9v1U2IxgycXOVe0G5/on0SZzHXlJbwTb2MbdpRpGpLq+yKvEsakqQEoKM1nxpwlooCqqrOSmXOXoW64DnnVaCxtFtLTJasa/Rr4VwR8FomIz2Ts2HGA7yf7oDJnCZOmzeeHie7oOmbivaGcoKS7eK64hKXvTuKWptF+6xzvb50Ro/j+7hU+PCqnr/o5vc21DHQ0s29TCldXxNOat4Pa/Hze5OXy7PBBBtqqxX3dzx4Iu++8e4mOu1c4ur2QyIUp2DsuwSrsMH6bH2Mddhg1g7XIKQWiPGcpqjormDLNn+mzFqIyN1aU1tV049A0Wi9EyzwFBY3lePhvpP7T2savwf+GAEmk1tRQh6ZOMKr6CYJVRZVgoQVTZy3C2GsnjhFHCEt/in3YAVzsF3CuoIDWG2fouFkqgPS8fChUvKephqHOVq7t3s2b3BwaD5VQv7+Y+j2FvD52mL7WOvoa3tD37ik9Lx/RV/GYxjs3OL5rP0Vp+XiEF+K+4S56bnmi4iM3PVDkIFIgNMdsI1NVw1HVXi4jwGQj6gZSNTlJZKFSvzXNUpljn4+ZcyIVLyp+l4SvCJBac2MD83zWM8s0VSQ6GkbrBLOKM8OYY7IBNb3VTFEJR99lKx4rrxAQvo2yA/vpe3yDrke36H52j76qZ/Q1VorAaKD5He0vH/CiYAd1RTsF+Ff5udSXX6W/XRYK9zZWydYSpX0GXfXU37uJk8ti5GeHoqwVzVTVRSLcnWuxCVOPnSIOUDdcwyzDDaJvKlqxIjv8XKDVt89mtlEsPvMTMXDJZbZTEY6eCXR1vheLJL9LgNReV7zG2nUd2i6FWPjtF/m+LC9PQXn2UpGNSfG/tGihrLkUVYmMGYFoathx7+RRhqteQnsNAy21shi/qY6eplr62xppfnSHxgultF+/SPPDO/S2SNfr6Wtp4GNnG/S/p7XyJZdPnyLYbwETJ5sxXs4DJY0oNAzWipqDbehPWAfsZ45ZAvIzA8XahLRwIqXMUpJk7rULE7cdYk1C1WAtF86XcePGQ8xdNzLdKIU9xT9/pQWje4TEgmhNLRbO8cxx3o3BvDy0jSPQNN2Ale9eoQlaVmmoG63BKnA/NqGHRc6ubrCWyUoL+fN3VoQGhXPq8GEulpbS/O4Nw+9boL8L+jrFjEBPEx973kvlJxjuEoCl4/c1b7lXdo3czK2U7Cji5LETWFq48rdxzsirhDPHfCOWASXYhx/DKapUpOLyKoFCM0TR5VMt0syrUMQpUt5g4rYdOdVofAKknXSQlVnAj6oriFqxfZQA0T4OfcoFPg4TtWwbMy1zsPZI4/z5m8StykDbWSpo7MHIaZsoYiqohmLstR3nFRdFQKTvuI3xir4U5e+BD628LS9j88o1xC5axqYNKaQmJrMsZgMJ8dmUnT3Hi7JLVNy8RtH2IsIXxrMichVpCenMcw3g4PYcOt88h74uOmoqWRIag7LuUhxizmK/+CTzll3APuwoSpqLmDI9AHUjaQ0xQVakcd2OufcuQYAULEmRqolHAYpqC9mZv5eQ6HyUDFMJj0qTAQce3r+Pu/dSWRzw5tVbtG1SUNZZxv079wQzlm6bMfPbJ3J/KRWVIkGFmeEozAzBPKAYu7BjaNhkE7s8A4Y/0NtQxUD9G1qe3qMor4hTJ66wdGki3/1oxR//YsPUqRbEr0xFc6Yl//WNJX/4ky26+v5cuXSbs0dOgBQhttTSW/8G3tfT8vI+JrbRWEWcwin2vIgBpmvFMEnRh8lKC8QSuuQAzTx3iaqTVDP8nKdIn1LOIJXfZhrEY+S+i1lmGykplq1/XrpwkVnaQaibbZYRUFZ2D2XdtWhZJFBfU01u/hHUzNOEuokkxL9E1PSna8YyWSkUVaMEzLwLmKJgRNm5s9DbKXL6noZqut+94NLPp1m+PJmFwctQUZkn6gpKMxzwX7SViXJmTJjizjffuxITGc/eXUXUPb7DQKtUp6unt+EtIx2NNFc8xs7cDmUtf+wW/8wcm3TkZkYwWSmYSYp+TJk+X6wmS8USSe3FWoNTjkiYpD7bSGm7ewFmnkUYeezB1G45wwM91FZXoaEbiLbdNpFVjpHZfx16lqsx8d6Hk08qmvrR6NjKnIpMnXaiYZqAurQSbJXGLKN4dPW9sTV3pPZRObRVi3i/u7EO+jspzt/DFAUbDhYUM2OGE3/4qwUzlCxIiVnCn7/R4psfLBg7zoRdWflEBobRWvmK/vZmURSRHOZQexPl5y+wOHIVGmo2KCg5imdKYfBsy2RUDdeiorMcNd2Vo3VHc5/dwg9Inyau+diF/IRvQrkYRJN5BRh77aD4wBlWr0pius7a0TKb0AAYInZFJnPssjF0LxIlasm2bIIOMG/pOSx8i5ljmYxZwG7sF5eipOaOkb47S6Pjqbh6XuwM6W2uh74PPL1+iTka9mRl7uXpg4eMn2DJH/9iyfoVm6i4ewdlFU/+7Q9GuDoF0dfdxTy3GEJ9F4naIF2tdFS94eaJ41w6d5kA/+Xo6vqjpGTJ3783Rs8pE7fVZViGHmaaRiRqOiswcy8UYKSqs2SmQv0lX+BfwoKsF/gn3UdJPQwLv2Icow4yXdUTI+e80RrjmIf3nxK1/iC2AQWCPQm0VPSYt+w8CzJf4Bh+HCNXaVkrC7e4S6hbrEdB3gwz8wgWhm/g9NETvLp6nr66tzQ+f4invRdTlZ0YHhyisaGZkLBE/Pzi+OnQOa5fu0fssgyMTRdw4fx1QX3CxkLkFCw4W7KHdzcvcfPsWe7cukt01EZMzcMxMF6I6iwPxo23ExVf17hLeKwtw9gjV8z/UsldctQmbvkibbfwKRJaK61IecXfJPpgD/rzkhk73gLP9eUYeuz4pZwvEeC45DiWEWew8CvBN/E2LjGnWZD1kqi9LbjFXcZ1yRlBjL5LFpYh+1DSWoTiVEeMzRZhYRPLyrjNnDx0jP25BQR4BDFx4hwcnaJGva00x7Y2NlFSfJrqtzW0NjV/2poga1lZh/j2e1MMDexIScwgO2sXYWHrsbZdgpZ+FEbGC/hxvDUK0/35cbw9WraJ2C86wSyTdWKHiQRcqlT7xN/APvwIc8ykYKkAlyWnCUh9SPjuFvzTHotdZ/aRR3GKOcNc8+RfCHBec42ZWqEEbH7MgsznBEvgS5rx3nCT+akPCM56galnAUrayzH2yUdBxZ9Jir4YmoRiahWLmWUMXt4rcHEJQ0dnHj/8oMIUOWNOHDlHTWUNVW9rqa2qo2jXYZ4+fEZLQzNtTe3UVdVR/bYKR4dI/vxXQ8b+qI6OjjtmFuGYWUajaxiFlc0i5BRdkJvqL4qdijOCmDTVE8sFe1HWXYOe41ZM3Hdg6bsH5+jTLCppw33dDfSdc7EK3EdQdgWhBfWE7axDy2oTuo5ZYkrVtpAty0umMCY+IQ+vJXtZXNJOxM5qFuZX47T0LD6b7hKzvw2vNddEOmoWuJe5DpsZN8meqTPDmTDFBQOjIIzNwtHSXoDmbG/kFcz4138fyx/+U4NJ8u6YmIbi6xGNqWkQGpoemJkH4+YaSWjQKmxsF2NsEsbYcdZMmOTIX/+mx4QJuqipe6GtF4iB4XwmTLJmyrT5YsqTipxSTjJxqg+aFpuYbZ4sqxb7FeO05LQw2aCtb4gobiMg4zkmnruYv+UFYYUNhObXoKK3FDP/3Zj67haBk5FTLtNmRzOmIH8ffqn3WbynSYihVy5WIYeIKKxj0e4GvONvCFWSUtJZphsYN8mBqSrBovQsTUfTlOcxQ8WJP/1lNgqKc1mxbCMmJn4oqfgwfoIN2rMc+L//ZcZfv3fmX/9oyeSJNqjPcOBf/s2AP39rz7hJrigpuSCnYI27WyjGhq78/QdTxk5wQm6ar6zUPUsCH8qEKW7M1FuNpnmyWKsw8yzEduERHJaU4p/8gODcSkJ21LKwsAH/zY+FLNzVwIJtlTgvO4tFyBE0DNeLcF5Jaynx8SmM0bKOJyz3NYuLWwhKvY21ZzKBWRVEFNYSWVgrHOGC7Aocl57BOvwo6iZxjJ/kyNSZYUybGYLcVD/+/p0FiyLXcun8NR6UP6WjtZ0nj15w+cJNSk+c58D+Uop2nyQv7yfyt+2jcMcBcnNKyMnex/lz13nxrIJrF2/y+F4F+bnF/PefZzJhkgPyUgaqGoqCUiATp7gwY5YrurabmOuwFXPfErGrRKoS2S4+iW/yAzHaIfk1hOZVCbWfn/6U0MImbJdfJnDVMUwtF4o8xsglnxmzA3nz6gVjIpYX4JF4l5gDnbjHncY2aDtRJW1EFNQICS+sIyjzOc7LL4iFR7e4q2iYrUFeyZ2xP5rx7fdmyCsY0/Ohk+H+QbHPYETawiqtNPXLdnb+XhsZGIRPCzEdre/p7erlTcU7sYwdFbWGP/xRjfETLRk30Z6/fauFt/cirl6+R+nJq2RnFmPjkYSZ717sFp/ELvoULsvPE7azVhAQsr2aBTmvCdz6FptFR8jOPUhrQy1+AStQN03B0Gk7yhrzeXDvHmNG+ruZv7QQ7+waYTM2EUeJKm4aJSCyqAG/5PuiJOWVUI5jVCkO0aWoGkTx7Xe6/PHPujg4+FH1+h3dH7pHNyh9XpPv6+4d3bAsrcUN9fXxcURWeBH79/r66emS/V97S7sgTpoJ/utP+kyRd2WynAMTJloydZodoaEJ3Lx2n+qKN7j4pWA2/xC2EcewXXwCx6ifCd3xiYAdtQTnvMU+9jRHDp8WJO/ZvZ+pmlHC9g0cc1HSCODZk8efcoGKNwQt34Nj3BU8E+8J1RcEFNayeHeDmB4l0P5pz9G2jkNumgM/TrBn/ARHdPT86en6QGfbewYkgL8qOHzevfn5+ENnNzU1TfT3DYjvA/394ppEQF11I3XVtcye48jYCc7IKXggN9UH+ak+TJL34tvvLDE08CAmZj2mvgVYBR/GPqYUi8B9zFt5adQEJPFLf0nY6hKaal+TmpLNdM0w9B0k8Fno2m1FzzScpvraT+kwUhLWydWrdwhZVkRA5itBwsL8KiKL6gne+grLoIPouaSirGyFkpI7CsohjJ3sg4fXSlFUbWlsZXj49/fjfhapSXsPL1+6Q3+f7HUZqQmShoZpbmiht7uHgIBY/j7WWYCXm+qLonIQCsoLUFQJYdYsdyZMMGSKsgvGvjtwjruCZeB+5mc8F1OepAWS19f3yEd9tgd6xgtQnBWJvhTlSps5bLegZ5dFUMhahgb7GdMnvaHR+ssbGutTD+KTUcGiXXUEZb0ivLCBgJx3zDCIYvJ4PaYrezB1hi9TZwYzRTmUGTMdef7kKe0tHV+txf9apGWoiopaAkPSiVm+g+6uXu7eqyAv/5QgQ5L6mkbRhxUrUvnbj/PErvFpamFixpmhHsJ0tWAUlf2QU3BDfrIRk1R80PEpxsingAhpvi9oIKywkeDcdyioSQukMWhbZYidbdKuVKmoomWxGRu3VDK35Ipnjent6SUyOpXdh66TnnsCz/XXWFTcSnhRCxZBhXiuOMGhE7dYH5+NkpIzOvoLsDP3w9V2AX8d646ufqDk0mhtaqO7q0dsW/s1+M+FVr+gdP71zy78x19cWbAwi4zMn8jcelRcq3lXR3tzG08fP0Fdw4XxU7xRmBHMVDUpBQ9HSycEH/dI1GfPx8g0HDkFR1xdFpOZuQfn0BzCi9/jm/KABdvesmjvexxjTqFjuxkNk/hPq1tJzDZNwsmvAC//1ZTfvCUjQPpz5uwNtNxzsFxzH7/ceuZteojvyp84dLAU79B0EbrWVNairBaEmXkYnjae+Np742YTxPhxuiQn5dBc3yJUWLLlL+1eRoCMhLNny9lTch47l/V8P9mfiKhtohNdnV0iOnzf3oaaqjXfjXVgiqIXkxW8UFT2FWGsslowhobBGBiHYWsbxXg5Fx49kL27uDAqFd+sSpyWnULTcj0B6U9YmPcOt1WX0DDdIKrEUtHUyD6d6JV7WLx4laxPw8O/+IAnj56TlHWEVSmHyNlxiprKd5y5eA/94IOcPneL4cFBlq/MZYqCK6YGntgZuxHi6se3Y20IDlkrfkPSgrqqBqHO0lQ4SoTk8YelPf3Dwuu/fVtP2fWn4lprcxsNn1S/o62FyXKmjJvsKeZ9a0MPXK0DMDAKRlnVH0UlH+ztIvh+gjNLlsiqO+8qK5Gf5sYss0Sclp4WWaLK3GVomiagqrtKVIpn6sWjb5PK+pRSPLyXcvuLnbFfFUVlTaaue0uOY+qRikfsYVat2Sx72OtK5Ka5i5UZEz0vJsvboaUbhvxUJy5fuibukUhoqGmgub5JvA8opsP+fiHDA4MyExkYZKC7m5aGFuqqG+hoa6OmuorQ0FX8+3/q4OkYhLetLwH2nnjY+aKu4Ya+wXzMLBczdoo3bh4r6OvtYXCgDwurUMYrBoroVEk9AjV9abd5AppGCajpr2eGzhosXdNJ3nIW/6ANbM8rHAX/FQG/tlnJnmur6+nv/sC5Mxc4sO+Q+MfF0en86Xt3Jk/zEeo4Qz2YSdOCmChnj9u8hQwPytbiPnR00VjXTHVlLbXv6qh5W0NTXROvX1bSVN8iAp/Pzdc3kh/G6jF+kjOKMwKxM3IlwNEHVRVbHI0dMTX2wcR8Ed9P8sTROVYkWVLbtnUnf/rWFrkZoSiohDJVbaHYVaI0eynKWsswsttERGwxmXkX8QuMZ2OiTGu+3BX7uwRIMvqu0KfNddIbmlWVsm0m0TFpyCk6o6oRiJHZIlTnhKGiHsS4idY4OEVy4vhpbt34ejX24/Av7wNL7yGU37pDRcUrlkSv4fsfLRivGMRs7TDMzEMZO8EKK1Mf1NR8UFP3ZYq8PfJKfmzJKGZ4cABGRtiz+ycs7VdhZJOErtkqtI1i0TVdiYltPJ6BmSxbs4/M3AusS9yPq0cM2/MKZP341W7Yf0jAlyJ7j6hevDMkvRsstedPXuDjv5FJit7M0vTH1CwcK+sIFKe78s331vww1oCwsDWkpuQSOH8ZB/Yf49bN2+zatY/Jcub8/QdD5BWs+OY7c5RV5yM/YyEqGqGiAqSpNR9FJQ+mTA/iP791wdomnCsXfnldR3pnWFNvEcFLTrB8w2kytl0gNfM0KZnS8Tk2pR0nelke3n4riYlZx4N7sveNf2+a/lQS++fbvpLDnDpxZvT70SNXmB+cwWzdxegaLsLaNhYdwyVMnxXNeIUgfpjkLQKmcZPd+XGSM99874CiciC6+iHoGYSgpb+UubqR6BstwswiClOLpWjOlTQqEDPbNWzPl72rILWnj5+zt/gA+/YeIjdvL0uXpxOzNI2lyzOIWpJO1JLNLFuRRmJijiBcWuv4n9r/A9QO6g8/vbabAAAAAElFTkSuQmCC'
    /** 本页的词典命名空间。 */
    var NS = 'settings.archiveManager'
    /**
     * settings.section 的条目 id。
     *
     * 设置导航的图标是 `ui-settings-general` 的内置映射表按 id 挑的
     * （`account`→人像、`models`→数据、`plugins`→个性化、`agent-presets`→预设、
     * `archived-sessions`→归档盒），插件没有别的注入图标的入口。
     * 所以这里用宿主为「归档会话」预留的 `archived-sessions`，
     * 图标就是归档盒而不是和「通用设置」撞车的齿轮。
     */
    var SECTION_ID = 'archived-sessions'

    var React = require('react')
    var h = React.createElement

    // -----------------------------------------------------------------------
    // 词典
    // -----------------------------------------------------------------------

    var zh = {
      nav: '归档会话管理',
      title: '归档会话管理',
      intro: '这里按工作区分组列出所有已归档会话。恢复会把会话放回它原来的位置；删除会永久移除本地存储，无法撤销。',
      statEmpty: '当前没有任何归档会话',
      statSummary: '共 {total} 个归档会话 · {groups} 个工作区',
      refresh: '刷新',
      refreshing: '刷新中…',
      loading: '正在读取归档会话…',
      loadFailed: '读取失败：{message}',
      retry: '重试',
      ungrouped: '未归组会话',
      ungroupedHint: '这些会话已不在任何工作区的记账里',
      archivedAt: '归档于 {time}',
      archivedAtUnknown: '归档时间未知',
      relJustNow: '刚刚',
      relMinutes: '{n} 分钟前',
      relHours: '{n} 小时前',
      relDays: '{n} 天前',
      relMonths: '{n} 个月前',
      relYears: '{n} 年前',
      lastActive: '最后活动 {time}',
      createdAt: '创建于 {time}',
      size: '{size}',
      files: '{count} 个文件',
      missingFiles: '存储文件已缺失',
      restore: '恢复',
      restoring: '恢复中…',
      delete: '删除',
      deleting: '删除中…',
      confirmTitle: '永久删除这个会话？',
      confirmBody: '「{title}」的所有本地存储文件都会被删除，包括会话历史与投影缓存；它也会从工作区记账与归档列表中彻底移除。此操作无法撤销，也无法从回收站恢复。',
      confirmMeta: '将删除 {count} 项存储（约 {size}）。',
      confirmCancel: '取消',
      confirmDelete: '永久删除',
      closeLabel: '关闭确认对话框',
      restored: '已恢复「{title}」，会话列表已刷新。',
      deleted: '已永久删除「{title}」。',
      restoreFailed: '恢复失败：{message}',
      deleteFailed: '删除失败：{message}',
      emptyTitle: '还没有归档的会话',
      emptyHint: '在会话列表里把不想看见的会话归档后，它们会出现在这里。',
      orphanTitle: '发现 {count} 条失效的会话引用',
      orphanHint: '这些会话的本地文件已被删除，但工作区里还留着记账，会让侧边栏列出点不开的会话。清理它们不会影响任何现存会话。',
      orphanRepair: '一键清理',
      orphanRepairing: '清理中…',
      repairDone: '已清理 {count} 条失效的会话引用。',
      repairFailed: '清理失败：{message}',
      updateTitle: '插件升级',
      updateHint: '更新方式取决于安装来源：本插件自带升级，直接从 GitHub 拉取新版本；由宿主管理的安装请通过原安装方式更新。',
      updateRuntime: '运行版本',
      updateDisk: '磁盘版本',
      updateLatest: '最新版本',
      updateChecking: '正在检查更新…',
      updateCheckingShort: '检查中…',
      updateApplying: '正在升级，请稍候…',
      updateApplyingShort: '升级中…',
      updateCheck: '检查更新',
      updateApply: '立即升级',
      updateRestartShort: '去重启',
      updateNever: '尚未检查',
      updateUpToDate: '已经是最新版本。',
      updateAvailableTo: '可升级到 {version}',
      updateRestartRequired: '代码已更新，重启 DSH 后生效。',
      updateFailed: '检查失败：{message}',
      updateNoSource: 'package.json 里还没有配置真实的仓库地址，无法自更新。',
      updateApplyFailed: '升级失败：{message}',
      updateApplied: '已从 {from} 升级到 {to}，重启 DSH 后生效。',
      updateAlreadyLatest: '已经是最新版本。',
      updateCheckedAt: '上次检查：{time}',
      updateAutoEvery: '自动检查：每 6 小时',
      starAction: '去 GitHub 点 Star',
      starFailed: '无法打开浏览器，请手动访问仓库页。',
      whaleAlt: '大肥鱼装饰',
      sectionSummary: '{count} 个',
      sessionIdLabel: '会话 ID',
    }

    var en = {
      nav: 'Archived sessions',
      title: 'Archived sessions',
      intro: 'Every archived session, grouped by workspace. Restoring puts a session back where it was; deleting removes its local storage for good.',
      statEmpty: 'No archived sessions',
      statSummary: '{total} archived sessions · {groups} workspaces',
      refresh: 'Refresh',
      refreshing: 'Refreshing…',
      loading: 'Loading archived sessions…',
      loadFailed: 'Could not load: {message}',
      retry: 'Retry',
      ungrouped: 'Ungrouped sessions',
      ungroupedHint: 'These sessions are no longer accounted to any workspace',
      archivedAt: 'Archived {time}',
      archivedAtUnknown: 'Archive time unknown',
      relJustNow: 'just now',
      relMinutes: '{n} min ago',
      relHours: '{n} h ago',
      relDays: '{n} d ago',
      relMonths: '{n} mo ago',
      relYears: '{n} y ago',
      lastActive: 'Last active {time}',
      createdAt: 'Created {time}',
      size: '{size}',
      files: '{count} files',
      missingFiles: 'storage files missing',
      restore: 'Restore',
      restoring: 'Restoring…',
      delete: 'Delete',
      deleting: 'Deleting…',
      confirmTitle: 'Delete this session permanently?',
      confirmBody: 'All local storage for "{title}" will be removed, including its history and projection cache; it is also detached from its workspace and the archive list. This cannot be undone and the files do not go to the recycle bin.',
      confirmMeta: 'About to remove {count} storage entries (~{size}).',
      confirmCancel: 'Cancel',
      confirmDelete: 'Delete permanently',
      closeLabel: 'Close confirmation dialog',
      restored: 'Restored "{title}"; the session list has been refreshed.',
      deleted: 'Permanently deleted "{title}".',
      restoreFailed: 'Restore failed: {message}',
      deleteFailed: 'Delete failed: {message}',
      emptyTitle: 'No archived sessions yet',
      emptyHint: 'Archive a session from the session list and it will show up here.',
      orphanTitle: '{count} stale session references found',
      orphanHint: 'These sessions are gone from disk but still accounted to a workspace, so the sidebar lists entries that cannot be opened. Cleaning them never touches an existing session.',
      orphanRepair: 'Clean up',
      orphanRepairing: 'Cleaning…',
      repairDone: 'Cleaned {count} stale session references.',
      repairFailed: 'Cleanup failed: {message}',
      updateTitle: 'Plugin update',
      updateHint: 'How you update depends on where this was installed: this plugin can update itself straight from GitHub; host-managed installs should use their original channel.',
      updateRuntime: 'Running',
      updateDisk: 'On disk',
      updateLatest: 'Latest',
      updateChecking: 'Checking for updates…',
      updateCheckingShort: 'Checking…',
      updateApplying: 'Updating, please wait…',
      updateApplyingShort: 'Updating…',
      updateCheck: 'Check for updates',
      updateApply: 'Update now',
      updateRestartShort: 'Restart',
      updateNever: 'Not checked yet',
      updateUpToDate: 'Already up to date.',
      updateAvailableTo: 'Can update to {version}',
      updateRestartRequired: 'Code updated; restart DSH to apply.',
      updateFailed: 'Check failed: {message}',
      updateNoSource: 'package.json has no real repository URL yet, so self-update is unavailable.',
      updateApplyFailed: 'Update failed: {message}',
      updateApplied: 'Updated {from} → {to}; restart DSH to apply.',
      updateAlreadyLatest: 'Already up to date.',
      updateCheckedAt: 'Last checked: {time}',
      updateAutoEvery: 'Auto check: every 6 hours',
      starAction: 'Star on GitHub',
      starFailed: 'Could not open the browser; please visit the repository page manually.',
      whaleAlt: 'Whale mascot decoration',
      sectionSummary: '{count}',
      sessionIdLabel: 'Session ID',
    }

    // -----------------------------------------------------------------------
    // 样式（全部走宿主主题别名变量，跟着主题/皮肤走）
    // -----------------------------------------------------------------------

    var css = [
      '.am-section{max-width:720px;color:var(--dsw-alias-label-primary);flex-direction:column;gap:12px;display:flex;position:relative}',
      '.am-head{flex-direction:column;gap:6px;display:flex}',
      '.am-head-row{align-items:flex-start;gap:10px;display:flex}',
      '.am-head-text{flex-direction:column;gap:6px;min-width:0;flex:1 1 auto;display:flex}',
      '.am-plugin-icon{flex:none;box-shadow:0 1px 3px rgba(0,0,0,.12);border-radius:var(--dsw-radius-lg);object-fit:cover;display:block}',
      '.am-update{box-sizing:border-box;border:.5px solid var(--dsw-alias-settings-card-stroke);background:var(--dsw-alias-settings-card-fill);border-radius:var(--dsw-radius-xl);flex-direction:column;gap:10px;padding:14px 16px;display:flex}',
      '.am-update-head{flex-direction:column;gap:2px;display:flex}',
      '.am-update-title{color:var(--dsw-alias-label-primary);margin:0;font-size:14px;font-weight:500;line-height:22px}',
      '.am-update-hint{color:var(--dsw-alias-label-tertiary);margin:0;font-size:12px;line-height:18px}',
      '.am-chips{flex-wrap:wrap;align-items:center;gap:8px;display:flex}',
      '.am-chip-group{align-items:center;gap:6px;display:inline-flex}',
      '.am-chip-label{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}',
      '.am-chip{border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-sm);color:var(--dsw-alias-label-primary);background:0 0;padding:1px 8px;font-size:12px;line-height:18px;display:inline-block}',
      '.am-chip-warn{border-color:var(--dsw-alias-state-warn-label);color:var(--dsw-alias-state-warn-label)}',
      '.am-update-status{font-size:12px;line-height:18px}',
      '.am-update-status-ok{color:var(--dsw-alias-state-success-primary)}',
      '.am-update-status-warn{color:var(--dsw-alias-state-warn-label)}',
      '.am-update-status-error{color:var(--dsw-alias-state-error-primary)}',
      '.am-update-actions{flex-wrap:wrap;align-items:center;gap:8px;display:flex}',
      '.am-update-foot{color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px}',
      '.am-star{border-color:var(--dsw-alias-border-l3)}',
      '.am-star-glyph{color:var(--dsw-alias-state-business-primary,#3b6fe0);font-size:13px;line-height:1}',
      '.am-star:hover:not(:disabled){border-color:var(--dsw-alias-state-business-primary,#3b6fe0);background:var(--dsw-alias-interactive-bg-hover)}',
      '.am-title{color:var(--dsw-alias-label-primary);margin:0;font-size:16px;font-weight:500;line-height:24px}',
      '.am-intro{color:var(--dsw-alias-label-tertiary);margin:0;font-size:14px;line-height:22px}',
      '.am-toolbar{align-items:center;gap:12px;margin-top:2px;display:flex}',
      '.am-stat{color:var(--dsw-alias-label-secondary);flex:1 1 auto;font-size:13px;line-height:20px}',
      '.am-notice{box-sizing:border-box;border:.5px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-settings-card-fill);border-radius:var(--dsw-radius-lg);flex:none;align-items:center;gap:8px;padding:8px 12px;font-size:13px;line-height:20px;display:flex}',
      '.am-notice-success{color:var(--dsw-alias-state-success-primary)}',
      '.am-notice-error{color:var(--dsw-alias-state-error-primary)}',
      '.am-notice-text{flex:1 1 auto;min-width:0;overflow-wrap:anywhere}',
      '.am-notice-dismiss{border:0;background:0 0;color:inherit;cursor:pointer;font:inherit;opacity:.6;flex:none;padding:0 2px;line-height:1}',
      '.am-notice-dismiss:hover{opacity:1}',
      '.am-orphans{box-sizing:border-box;border:.5px solid var(--dsw-alias-state-warn-label);background:var(--dsw-alias-settings-card-fill);border-radius:var(--dsw-radius-lg);align-items:flex-start;gap:12px;padding:10px 12px;display:flex}',
      '.am-orphans-body{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;gap:2px}',
      '.am-orphans-title{color:var(--dsw-alias-state-warn-label);font-size:13px;font-weight:500;line-height:20px}',
      '.am-orphans-hint{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}',
      '.am-groups{flex-direction:column;gap:18px;display:flex}',
      '.am-group{flex-direction:column;gap:8px;display:flex}',
      '.am-group-head{align-items:center;gap:8px;min-width:0;display:flex}',
      '.am-group-title{color:var(--dsw-alias-label-primary);flex:none;font-size:14px;font-weight:500;line-height:22px}',
      '.am-group-path{color:var(--dsw-alias-label-tertiary);text-overflow:ellipsis;white-space:nowrap;flex:1 1 auto;min-width:0;font-size:12px;line-height:18px;overflow:hidden}',
      '.am-group-count{border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-xs);color:var(--dsw-alias-label-secondary);flex:none;padding:1px 6px;font-size:11px;line-height:16px}',
      '.am-rows{flex-direction:column;gap:8px;margin:0;padding:0;list-style:none;display:flex}',
      '.am-row{box-sizing:border-box;border:.5px solid var(--dsw-alias-settings-card-stroke);background:var(--dsw-alias-settings-card-fill);border-radius:var(--dsw-radius-xl);align-items:flex-start;gap:12px;padding:12px 14px;transition:border-color .14s ease,background .14s ease;display:flex}',
      '.am-row:hover{border-color:var(--dsw-alias-border-l4)}',
      '.am-row[data-busy="true"]{opacity:.72}',
      '.am-row-main{flex-direction:column;flex:1 1 auto;gap:4px;min-width:0;display:flex}',
      '.am-row-title{color:var(--dsw-alias-label-primary);overflow-wrap:anywhere;font-size:14px;font-weight:500;line-height:22px}',
      '.am-row-meta{color:var(--dsw-alias-label-tertiary);flex-wrap:wrap;align-items:center;gap:4px 10px;font-size:12px;line-height:18px;display:flex}',
      '.am-meta-item{display:inline-flex;align-items:center;gap:4px;min-width:0}',
      '.am-sep{width:3px;height:3px;border-radius:50%;background:currentColor;opacity:.55;flex:none;corner-shape:round;display:inline-block}',
      '.am-warn{color:var(--dsw-alias-state-warn-label)}',
      '.am-row-actions{flex:none;align-self:center;align-items:center;gap:4px;opacity:0;visibility:hidden;pointer-events:none;transform:translateX(4px);transition:opacity .16s ease,transform .16s ease,visibility 0s linear .16s;display:inline-flex}',
      '.am-row:hover .am-row-actions,.am-row:focus-within .am-row-actions{opacity:1;visibility:visible;pointer-events:auto;transform:none;transition:opacity .16s ease,transform .16s ease,visibility 0s}',
      '@media (hover:none){.am-row-actions{opacity:1;visibility:visible;pointer-events:auto;transform:none}}',
      '.am-btn{box-sizing:border-box;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-sm);height:28px;color:var(--dsw-alias-label-primary);font:inherit;font-size:12px;line-height:18px;cursor:pointer;background:0 0;justify-content:center;align-items:center;gap:4px;padding:0 10px;display:inline-flex;transition:background .12s ease,border-color .12s ease,color .12s ease}',
      '.am-btn:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover-solid)}',
      '.am-btn:focus-visible{outline:2px solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:2px}',
      '.am-btn:disabled{cursor:default;opacity:.55}',
      '.am-btn-danger{border-color:transparent;color:var(--dsw-alias-state-error-primary)}',
      '.am-btn-danger:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover-danger)}',
      '.am-btn-primary{border-color:transparent;background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground);font-weight:500}',
      '.am-btn-primary:hover:not(:disabled){background:var(--dsw-alias-button-primary-hover)}',
      '.am-empty{border:.5px dashed var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-xl);flex-direction:column;justify-content:center;align-items:center;gap:10px;padding:28px 20px 34px;display:flex}',
      '.am-empty-title{color:var(--dsw-alias-label-secondary);margin:0;font-size:14px;line-height:22px}',
      '.am-empty-hint{color:var(--dsw-alias-label-tertiary);margin:0;font-size:12px;line-height:18px;text-align:center}',
      '.am-loading{color:var(--dsw-alias-label-tertiary);align-items:center;gap:8px;padding:24px 0;font-size:13px;line-height:20px;display:flex}',
      '.am-error{border:.5px solid var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-lg);background:var(--dsw-alias-settings-card-fill);flex-direction:column;gap:10px;padding:14px;display:flex}',
      '.am-error-text{color:var(--dsw-alias-state-error-primary);font-size:13px;line-height:20px;overflow-wrap:anywhere}',
      '.am-decor{pointer-events:none;user-select:none;opacity:.16;flex:none;align-self:flex-end;margin-top:4px;display:flex}',
      '.am-decor svg{display:block}',
      '.am-empty .am-decor{opacity:.5;align-self:center;margin-top:2px}',
      '.am-modal-mask{position:fixed;inset:0;background:var(--dsw-alias-bg-mask-1,rgba(0,0,0,.32));z-index:1100;justify-content:center;align-items:center;padding:24px;display:flex}',
      '.am-modal{box-sizing:border-box;width:min(440px,100%);background:var(--dsw-alias-bg-layer-1,#fff);border:.5px solid var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-xl);box-shadow:0 12px 32px rgba(0,0,0,.18);flex-direction:column;gap:12px;padding:20px;display:flex}',
      '.am-modal-title{margin:0;color:var(--dsw-alias-label-primary);font-size:16px;font-weight:500;line-height:24px}',
      '.am-modal-body{margin:0;color:var(--dsw-alias-label-secondary);font-size:14px;line-height:22px;overflow-wrap:anywhere}',
      '.am-modal-meta{margin:0;color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px}',
      '.am-modal-actions{justify-content:flex-end;gap:8px;margin-top:4px;display:flex}',
      '.am-modal-actions .am-btn{height:32px;padding:0 14px;font-size:13px;line-height:20px}',
      '.am-skeleton{border-radius:var(--dsw-radius-xl);background:var(--dsw-alias-bg-skeleton,var(--dsw-alias-interactive-bg-hover));height:64px;animation:am-pulse 1.4s ease-in-out infinite}',
      '@keyframes am-pulse{0%,100%{opacity:.55}50%{opacity:.9}}',
      '@media (prefers-reduced-motion:reduce){.am-row,.am-row-actions,.am-btn,.am-skeleton{transition:none;animation:none}}',
    ].join('')

    var cssTagId = PKG + '/panel.css'
    if (typeof document !== 'undefined') {
      try {
        if (document.querySelector('style[data-plugin-css=' + JSON.stringify(cssTagId) + ']') === null) {
          var styleTag = document.createElement('style')
          styleTag.dataset.plugin = PKG
          styleTag.dataset.pluginCss = cssTagId
          styleTag.textContent = css
          document.head.appendChild(styleTag)
        }
      } catch (error) {
        console.warn('[archive-manager] 样式注入失败（界面仍可用，只是没有装饰性样式）：', error)
      }
    }

    // -----------------------------------------------------------------------
    // 纯函数小工具
    // -----------------------------------------------------------------------

    /**
     * 极简插值：把 `{name}` 换成值。
     * @param template - 含占位符的文案。
     * @param values - 占位符取值表。
     * @returns 替换后的字符串。
     */
    function format(template, values) {
      return String(template).replace(/\{(\w+)\}/g, function (match, key) {
        return values !== undefined && values[key] !== undefined ? String(values[key]) : match
      })
    }

    /**
     * 本地化时间：`2026-10-20 14:03`。
     * @param iso - ISO 时间串。
     * @returns 展示文本或空串。
     */
    function formatTime(iso) {
      if (typeof iso !== 'string' || iso === '') return ''
      var date = new Date(iso)
      if (Number.isNaN(date.getTime())) return ''
      var pad = function (value) {
        return value < 10 ? '0' + value : String(value)
      }
      return (
        date.getFullYear() +
        '-' +
        pad(date.getMonth() + 1) +
        '-' +
        pad(date.getDate()) +
        ' ' +
        pad(date.getHours()) +
        ':' +
        pad(date.getMinutes())
      )
    }

    /**
     * 相对时间（本地化）：刚刚 / 3 分钟前 / 2 天前。
     * @param iso - ISO 时间串。
     * @param now - 参照时刻（毫秒）。
     * @param t - 词典读取函数。
     * @returns 展示文本或空串。
     */
    function relativeText(iso, now, t) {
      if (typeof iso !== 'string' || iso === '') return ''
      var then = Date.parse(iso)
      if (Number.isNaN(then)) return ''
      var diff = Math.max(0, now - then)
      var minutes = Math.floor(diff / 60000)
      if (minutes < 1) return t('relJustNow')
      if (minutes < 60) return format(t('relMinutes'), { n: minutes })
      var hours = Math.floor(minutes / 60)
      if (hours < 24) return format(t('relHours'), { n: hours })
      var days = Math.floor(hours / 24)
      if (days < 30) return format(t('relDays'), { n: days })
      var months = Math.floor(days / 30)
      if (months < 12) return format(t('relMonths'), { n: months })
      return format(t('relYears'), { n: Math.floor(months / 12) })
    }

    /**
     * 字节数 → 人读文本。
     * @param bytes - 字节数。
     * @returns 例如 `1.2 MB`。
     */
    function formatSize(bytes) {
      if (typeof bytes !== 'number' || !Number.isFinite(bytes) || bytes <= 0) return '0 B'
      var units = ['B', 'KB', 'MB', 'GB']
      var value = bytes
      var index = 0
      while (value >= 1024 && index < units.length - 1) {
        value /= 1024
        index += 1
      }
      var digits = value >= 100 || index === 0 ? 0 : 1
      return value.toFixed(digits) + ' ' + units[index]
    }

    /**
     * 发一个同源请求并解出 JSON；非 2xx 或 `ok:false` 统一抛带文案的 Error。
     * @param method - HTTP 方法。
     * @param path - 相对路由路径。
     * @param payload - 可选 JSON 载荷。
     * @returns 响应体。
     */
    async function request(method, path, payload) {
      var init = { method: method, cache: 'no-store', credentials: 'same-origin' }
      if (payload !== undefined) {
        init.headers = { 'content-type': 'application/json' }
        init.body = JSON.stringify(payload)
      }
      var response = await fetch(ROUTE + path, init)
      var body = null
      try {
        body = await response.json()
      } catch {
        body = null
      }
      if (response.status >= 200 && response.status < 300 && body !== null && body.ok !== false) return body
      var detail = body !== null && typeof body === 'object' ? body.message || body.error : undefined
      throw new Error(detail !== undefined && detail !== '' ? detail : 'HTTP ' + response.status)
    }

    // -----------------------------------------------------------------------
    // 状态容器（不可变快照 + 订阅；React 侧用 useStore 订阅）
    // -----------------------------------------------------------------------

    /**
     * @param value - 任意值。
     * @returns 是否为普通对象。
     */
    function isObject(value) {
      return value !== null && typeof value === 'object' && !Array.isArray(value)
    }

    /**
     * 建一个极简快照 store。
     * @param initial - 初始快照。
     * @returns `{ getSnapshot, subscribe, patch }`
     */
    function createStore(initial) {
      var snapshot = initial
      var listeners = new Set()
      return {
        getSnapshot: function () {
          return snapshot
        },
        subscribe: function (listener) {
          listeners.add(listener)
          return function () {
            listeners.delete(listener)
          }
        },
        patch: function (partial) {
          snapshot = Object.assign({}, snapshot, partial)
          listeners.forEach(function (listener) {
            try {
              listener(snapshot)
            } catch (error) {
              console.error('[archive-manager] 订阅回调出错：', error)
            }
          })
        },
      }
    }

    /**
     * 订阅 store 并在变化时重渲染。
     * @param store - createStore 的产物。
     * @returns 当前快照。
     */
    function useStore(store) {
      var state = React.useState(store.getSnapshot())
      var snapshot = state[0]
      var setSnapshot = state[1]
      React.useEffect(
        function () {
          var alive = true
          var sync = function (next) {
            if (alive) setSnapshot(next)
          }
          sync(store.getSnapshot())
          var off = store.subscribe(sync)
          return function () {
            alive = false
            off()
          }
        },
        [store],
      )
      return snapshot
    }

    // -----------------------------------------------------------------------
    // 控制器：唯一的数据出入口
    // -----------------------------------------------------------------------

    /**
     * 建一个控制器。
     * @param options - `{ t, resolveService }`：词典读取函数与宿主客户端服务解析回调。
     * @returns 控制器。
     */
    function createController(options) {
      var t = options.t
      var store = createStore({
        phase: 'loading',
        data: null,
        error: null,
        pending: {},
        notice: null,
        confirm: null,
        update: null,
        updateBusy: null,
      })

      /** 从工作区归档集合里本插件关心的 id（用于跨页签/跨设备变化的重新拉取）。 */
      var lastArchivedKey = ''
      /** /state 请求序号：只接受最后发起的那一次响应，避免旧数据把已删除的行复活。 */
      var loadSeq = 0

      /**
       * 读宿主会话服务并刷新会话列表（删除/恢复后让列表立即跟上）。
       * 服务可能比设置面板晚一步就绪，所以取不到时短暂重试几次，避免「这一次刷新被跳过」。
       * @returns 是否成功触发。
       */
      async function refreshSessions() {
        for (var attempt = 0; attempt < 3; attempt += 1) {
          try {
            var sessions = options.resolveService('sessions')
            if (sessions !== undefined && sessions !== null && typeof sessions.refresh === 'function') {
              await sessions.refresh()
              return true
            }
          } catch (error) {
            console.warn('[archive-manager] 刷新会话列表失败（界面已就地更新）：', error)
            return false
          }
          await new Promise(function (resolve) {
            setTimeout(resolve, 120)
          })
        }
        return false
      }

      /**
       * 读一份最新状态；首次加载失败才把整页置为错误态，后续失败保留旧列表并给轻提示。
       *
       * 带请求序号：并发的 /state 请求（窗口聚焦、归档帧推送、操作后刷新）返回顺序不可依赖，
       * 只接受最后发起的那一次的结果，避免旧响应把刚删除的行又「复活」回来。
       * @param force - 是否忽略 in-flight 去重。
       * @returns 最新状态载荷。
       */
      async function load(force) {
        var current = store.getSnapshot()
        if (current.loading === true && force !== true) return current.data
        var seq = (loadSeq += 1)
        store.patch({ loading: true, phase: current.data === null ? 'loading' : current.phase, error: null })
        try {
          var data = await request('GET', '/state')
          if (seq !== loadSeq) return store.getSnapshot().data
          var archivedIds = []
          if (Array.isArray(data.groups)) {
            data.groups.forEach(function (group) {
              if (!Array.isArray(group.sessions)) return
              group.sessions.forEach(function (row) {
                if (row !== null && typeof row.sessionId === 'string') archivedIds.push(row.sessionId)
              })
            })
          }
          lastArchivedKey = archivedIds.join(',')
          store.patch({ loading: false, phase: 'ready', data: data, error: null })
          return data
        } catch (error) {
          if (seq !== loadSeq) return store.getSnapshot().data
          store.patch({
            loading: false,
            phase: current.data === null ? 'error' : 'ready',
            error: current.data === null ? String((error !== null && error !== undefined && error.message) || error) : null,
            notice:
              current.data === null
                ? null
                : { tone: 'error', text: String((error !== null && error !== undefined && error.message) || error) },
          })
          return current.data
        }
      }

      /**
       * 把一行从当前快照里摘掉（恢复/删除后立即生效，不必等下一次拉取）。
       * @param sessionId - 会话 id。
       */
      function dropRow(sessionId) {
        var current = store.getSnapshot()
        if (current.data === null || !Array.isArray(current.data.groups)) return
        var groups = []
        var total = 0
        current.data.groups.forEach(function (group) {
          var sessions = Array.isArray(group.sessions)
            ? group.sessions.filter(function (row) {
                return row.sessionId !== sessionId
              })
            : []
          if (sessions.length === 0) return
          total += sessions.length
          groups.push(Object.assign({}, group, { sessions: sessions }))
        })
        store.patch({
          data: Object.assign({}, current.data, { groups: groups, total: total, groupCount: groups.length }),
        })
      }

      /**
       * 给某个会话打上进行中的动作（禁用按钮、行半透明）。
       * @param sessionId - 会话 id。
       * @param action - 'restore' | 'delete' | null。
       */
      function setPending(sessionId, action) {
        var current = store.getSnapshot()
        var pending = Object.assign({}, current.pending)
        if (action === null) delete pending[sessionId]
        else pending[sessionId] = action
        store.patch({ pending: pending })
      }

      /**
       * 设置一次性提示。
       * @param notice - `{ tone, text }` 或 null。
       */
      function setNotice(notice) {
        store.patch({ notice: notice })
      }

      /**
       * 恢复一个归档会话。
       * @param sessionId - 会话 id。
       * @param title - 展示用标题。
       * @returns 完成后的 Promise。
       */
      async function restore(sessionId, title) {
        if (store.getSnapshot().pending[sessionId] !== undefined) return
        setPending(sessionId, 'restore')
        setNotice(null)
        try {
          await request('POST', '/restore', { sessionId: sessionId })
          dropRow(sessionId)
          await refreshSessions()
          await load(true)
          setNotice({ tone: 'success', text: format(t('restored'), { title: title }) })
        } catch (error) {
          setNotice({ tone: 'error', text: format(t('restoreFailed'), { message: String((error !== null && error !== undefined && error.message) || error) }) })
          // 失败也要对齐一次：服务端状态可能已经变了（例如别处已经恢复过）。
          await load(true)
        } finally {
          setPending(sessionId, null)
        }
      }

      /**
       * 删除一个会话（调用前必须已经过二次确认）。
       *
       * 删除成功后必须同时刷新两处宿主状态：
       *  ① `ctx.sessions.refresh()` —— 会话列表重新拉取，被删的行立刻消失；
       *  ② `load(true)` —— 本页按服务端的权威结果重建列表。
       * 失败时也跑一次 load，把界面拉回真实状态，绝不让用户对着一行「看起来还在」的条目干瞪眼。
       * @param sessionId - 会话 id。
       * @param title - 展示用标题。
       * @returns 完成后的 Promise。
       */
      async function remove(sessionId, title) {
        if (store.getSnapshot().pending[sessionId] !== undefined) return
        setPending(sessionId, 'delete')
        setNotice(null)
        try {
          await request('POST', '/delete', { sessionId: sessionId })
          dropRow(sessionId)
          await refreshSessions()
          await load(true)
          setNotice({ tone: 'success', text: format(t('deleted'), { title: title }) })
        } catch (error) {
          setNotice({ tone: 'error', text: format(t('deleteFailed'), { message: String((error !== null && error !== undefined && error.message) || error) }) })
          await load(true)
        } finally {
          setPending(sessionId, null)
        }
      }

      /**
       * 清理历史删除操作留下的失效记账（工作区里有引用、磁盘上没文件）。
       * @returns 清理结果。
       */
      async function repair() {
        try {
          var result = await request('POST', '/repair')
          await load(true)
          setNotice({
            tone: 'success',
            text: format(t('repairDone'), { count: typeof result.repaired === 'number' ? result.repaired : 0 }),
          })
          return result
        } catch (error) {
          setNotice({ tone: 'error', text: format(t('repairFailed'), { message: String((error !== null && error !== undefined && error.message) || error) }) })
          return null
        }
      }

      /**
       * 打开/关闭二次确认。
       * @param target - 行数据或 null。
       */
      function confirm(target) {
        store.patch({ confirm: target })
      }

      /**
       * 宿主归档集合变化时决定要不要重新拉取（外部归档/恢复也能跟上）。
       * @param archivedIds - 宿主当前的归档 id 集合。
       */
      function observeArchived(archivedIds) {
        if (!Array.isArray(archivedIds)) return
        var key = archivedIds.slice().sort().join(',')
        if (key === lastArchivedKey) return
        lastArchivedKey = key
        void load(true)
      }

      /**
       * 读更新状态（默认带 Host 侧 6 小时缓存）。
       * @param force - 绕过缓存（「检查更新」按钮）。
       * @returns 状态对象或 null。
       */
      async function loadUpdate(force) {
        var current = store.getSnapshot()
        if (current.updateBusy === 'checking') return current.update
        store.patch({ updateBusy: 'checking' })
        try {
          var status = await request('GET', force === true ? '/update/status?force=1' : '/update/status')
          store.patch({ update: status, updateBusy: null })
          return status
        } catch (error) {
          store.patch({
            updateBusy: null,
            update: Object.assign({}, current.update !== null && typeof current.update === 'object' ? current.update : {}, {
              ok: false,
              error: String((error !== null && error !== undefined && error.message) || error),
            }),
          })
          return store.getSnapshot().update
        }
      }

      /**
       * 执行升级。成功后磁盘版本会变，但运行中的代码仍是旧的 —— 页面据此提示重启。
       * @returns 升级结果或 null。
       */
      async function applyUpdate() {
        var current = store.getSnapshot()
        if (current.updateBusy !== null) return null
        store.patch({ updateBusy: 'applying' })
        try {
          var result = await request('POST', '/update/apply')
          store.patch({ updateBusy: null })
          var status = await loadUpdate(true)
          return { result: result, status: status }
        } catch (error) {
          store.patch({ updateBusy: null })
          void loadUpdate(true)
          return {
            result: {
              ok: false,
              error: String((error !== null && error !== undefined && error.message) || error),
            },
          }
        }
      }

      /**
       * 用系统浏览器打开仓库页（Star）。
       * @returns `{ ok }`。
       */
      async function openRepo() {
        try {
          return await request('POST', '/open-repo')
        } catch (error) {
          return { ok: false, error: String((error !== null && error !== undefined && error.message) || error) }
        }
      }

      return {
        store: store,
        load: load,
        restore: restore,
        remove: remove,
        repair: repair,
        confirm: confirm,
        setNotice: setNotice,
        observeArchived: observeArchived,
        refreshSessions: refreshSessions,
        loadUpdate: loadUpdate,
        applyUpdate: applyUpdate,
        openRepo: openRepo,
      }
    }

    // -----------------------------------------------------------------------
    // 装饰：大肥鱼（Q 版鲸鱼娘）——纯 SVG，颜色跟主题走
    // -----------------------------------------------------------------------

    /**
     * Q 版大肥鱼：圆滚滚的鲸鱼娘，尾鳍、腮红、呆毛、小喷水一应俱全。
     * @param props - `{ size, title }`。
     * @returns SVG 元素。
     */
    function WhaleMascot(props) {
      var size = typeof props.size === 'number' ? props.size : 148
      var width = size
      var height = Math.round((size * 132) / 190)
      return h(
        'svg',
        {
          width: width,
          height: height,
          viewBox: '0 0 190 132',
          fill: 'none',
          role: 'img',
          'aria-label': props.title,
        },
        // 喷水
        h('path', {
          d: 'M96 30c-1-9-6-15-13-19M96 30c3-8 8-13 14-16M96 30c0-6 1-11 3-16',
          stroke: 'var(--dsw-alias-state-business-primary, #4a6fd0)',
          strokeWidth: 2.4,
          strokeLinecap: 'round',
          opacity: 0.75,
        }),
        // 尾鳍
        h('path', {
          d: 'M147 76c12-11 22-13 28-9-2 8-8 14-16 17 9 2 15 8 17 16-7 5-18 3-29-7z',
          fill: 'var(--dsw-alias-state-business-primary, #4a6fd0)',
          opacity: 0.85,
        }),
        // 身体
        h('ellipse', {
          cx: 92,
          cy: 80,
          rx: 58,
          ry: 41,
          fill: 'var(--dsw-alias-state-business-primary, #4a6fd0)',
          opacity: 0.92,
        }),
        // 肚皮
        h('path', {
          d: 'M50 88c6 20 24 32 43 32 20 0 38-12 44-32-13 8-28 12-44 12s-31-4-43-12z',
          fill: 'var(--dsw-alias-label-primary-foreground, #ffffff)',
          opacity: 0.9,
        }),
        // 眼白 + 瞳孔
        h('circle', { cx: 70, cy: 70, r: 9, fill: 'var(--dsw-alias-label-primary-foreground, #ffffff)', opacity: 0.95 }),
        h('circle', { cx: 112, cy: 70, r: 9, fill: 'var(--dsw-alias-label-primary-foreground, #ffffff)', opacity: 0.95 }),
        h('circle', { cx: 71, cy: 71, r: 5, fill: '#1d2b3a' }),
        h('circle', { cx: 113, cy: 71, r: 5, fill: '#1d2b3a' }),
        h('circle', { cx: 72.6, cy: 69, r: 1.6, fill: '#ffffff' }),
        h('circle', { cx: 114.6, cy: 69, r: 1.6, fill: '#ffffff' }),
        // 腮红
        h('ellipse', { cx: 55, cy: 84, rx: 8, ry: 5, fill: '#ff9db8', opacity: 0.6 }),
        h('ellipse', { cx: 126, cy: 84, rx: 8, ry: 5, fill: '#ff9db8', opacity: 0.6 }),
        // 嘴
        h('path', {
          d: 'M86 86c3 5 9 5 12 0',
          stroke: '#1d2b3a',
          strokeWidth: 2.2,
          strokeLinecap: 'round',
        }),
        // 呆毛
        h('path', {
          d: 'M92 39c3-11 12-14 18-10',
          stroke: 'var(--dsw-alias-state-business-primary, #4a6fd0)',
          strokeWidth: 3.4,
          strokeLinecap: 'round',
        }),
      )
    }

    // -----------------------------------------------------------------------
    // 二次确认对话框
    // -----------------------------------------------------------------------

    /**
     * 永久删除的二次确认。Esc 关闭、点遮罩关闭、打开时把焦点放到「取消」。
     * @param props - `{ t, target, onCancel, onConfirm }`。
     * @returns 对话框元素。
     */
    function ConfirmDialog(props) {
      var t = props.t
      var target = props.target
      var cancelRef = React.useRef(null)

      React.useEffect(
        function () {
          var handle = function (event) {
            if (event.key === 'Escape') {
              event.stopPropagation()
              props.onCancel()
            }
          }
          document.addEventListener('keydown', handle, true)
          if (cancelRef.current !== null && typeof cancelRef.current.focus === 'function') cancelRef.current.focus()
          return function () {
            document.removeEventListener('keydown', handle, true)
          }
        },
        [props.target],
      )

      if (target === null || target === undefined) return null

      return h(
        'div',
        {
          className: 'am-modal-mask',
          onClick: function (event) {
            if (event.target === event.currentTarget) props.onCancel()
          },
        },
        h(
          'div',
          {
            className: 'am-modal',
            role: 'dialog',
            'aria-modal': 'true',
            'aria-labelledby': 'am-confirm-title',
            onClick: function (event) {
              event.stopPropagation()
            },
          },
          h('h3', { className: 'am-modal-title', id: 'am-confirm-title' }, t('confirmTitle')),
          h('p', { className: 'am-modal-body' }, format(t('confirmBody'), { title: target.title })),
          h(
            'p',
            { className: 'am-modal-meta' },
            format(t('confirmMeta'), {
              count: target.fileCount > 0 ? target.fileCount : 1,
              size: formatSize(target.sizeBytes),
            }),
          ),
          h(
            'div',
            { className: 'am-modal-actions' },
            h(
              'button',
              {
                type: 'button',
                className: 'am-btn',
                ref: cancelRef,
                onClick: function () {
                  props.onCancel()
                },
              },
              t('confirmCancel'),
            ),
            h(
              'button',
              {
                type: 'button',
                className: 'am-btn am-btn-danger',
                onClick: function () {
                  props.onConfirm(target.sessionId, target.title)
                },
              },
              t('confirmDelete'),
            ),
          ),
        ),
      )
    }

    // -----------------------------------------------------------------------
    // 列表行
    // -----------------------------------------------------------------------

    /**
     * 一行归档会话：完整标题 + 归档时间/最后活动 + 悬停显示的恢复/删除。
     * @param props - `{ t, row, now, pending, onRestore, onDelete }`。
     * @returns 列表项元素。
     */
    function ArchiveRow(props) {
      var t = props.t
      var row = props.row
      var now = props.now
      var pending = props.pending
      var archivedAt = formatTime(row.archivedAt)
      var lastActive = formatTime(row.lastPromptAt)
      var createdAt = formatTime(row.createdAt)
      var metaItems = []
      if (archivedAt !== '') {
        metaItems.push(
          h(
            'span',
            { className: 'am-meta-item', title: archivedAt },
            format(t('archivedAt'), { time: archivedAt }),
            h('span', { className: 'am-sep' }),
            h('span', null, relativeText(row.archivedAt, now, t)),
          ),
        )
      } else {
        metaItems.push(h('span', { className: 'am-meta-item' }, t('archivedAtUnknown')))
      }
      if (lastActive !== '') {
        metaItems.push(h('span', { className: 'am-meta-item' }, format(t('lastActive'), { time: lastActive })))
      } else if (createdAt !== '') {
        metaItems.push(h('span', { className: 'am-meta-item' }, format(t('createdAt'), { time: createdAt })))
      }
      if (row.onDisk === false) {
        metaItems.push(h('span', { className: 'am-meta-item am-warn' }, t('missingFiles')))
      } else if (typeof row.sizeBytes === 'number' && row.sizeBytes > 0) {
        metaItems.push(h('span', { className: 'am-meta-item' }, formatSize(row.sizeBytes)))
      }

      var busy = typeof pending === 'string' ? pending : undefined
      return h(
        'li',
        {
          className: 'am-row',
          'data-busy': busy !== undefined ? 'true' : 'false',
        },
        h(
          'div',
          { className: 'am-row-main' },
          h('div', { className: 'am-row-title', title: row.title }, row.title),
          h('div', { className: 'am-row-meta' }, metaItems),
        ),
        h(
          'div',
          { className: 'am-row-actions' },
          h(
            'button',
            {
              type: 'button',
              className: 'am-btn',
              disabled: busy !== undefined,
              'aria-label': t('restore') + ': ' + row.title,
              title: t('restore'),
              onClick: function () {
                props.onRestore(row.sessionId, row.title)
              },
            },
            busy === 'restore' ? t('restoring') : t('restore'),
          ),
          h(
            'button',
            {
              type: 'button',
              className: 'am-btn am-btn-danger',
              disabled: busy !== undefined,
              'aria-label': t('delete') + ': ' + row.title,
              title: t('delete'),
              onClick: function () {
                props.onDelete(row)
              },
            },
            busy === 'delete' ? t('deleting') : t('delete'),
          ),
        ),
      )
    }

    // -----------------------------------------------------------------------
    // 插件小图标（鲸鱼娘 Q 版）+ 更新卡片
    // -----------------------------------------------------------------------

    /**
     * 插件图标：一个圆角小方块里放 Q 版鲸鱼娘，跟随主题尺寸。
     * @param props - `{ size }`。
     * @returns 图标元素。
     */
    /**
     * 插件图标：Q 版鲸鱼娘（内嵌位图），尺寸跟随调用方。
     * @param props - { size }。
     * @returns 图标元素。
     */
    function PluginIcon(props) {
      var size = typeof props.size === 'number' ? props.size : 28
      return h('img', {
        className: 'am-plugin-icon',
        src: PLUGIN_ICON_DATA_URL,
        width: size,
        height: size,
        alt: '',
        'aria-hidden': 'true',
        draggable: 'false',
      })
    }
    function VersionChip(props) {
      return h('span', { className: 'am-chip' + (props.tone ? ' am-chip-' + props.tone : '') }, props.text)
    }

    /**
     * 更新卡片：版本三联（运行/磁盘/最新）+ 检查更新 + 立即升级 + 去 GitHub 点 Star。
     *
     * 这是本插件自带的能力：数据来自 `/plugins/archive-manager/update/*`，
     * 与其它插件没有任何耦合。
     * @param props - `{ t, update, onCheck, onApply, onStar }`。
     * @returns 卡片元素。
     */
    function UpdateCard(props) {
      var t = props.t
      var update = props.update
      var busy = props.busy
      var info = update !== null && typeof update === 'object' ? update : null
      var runtimeVersion = info !== null && info.runtimeVersion ? info.runtimeVersion : '—'
      var diskVersionText = info !== null && info.diskVersion ? info.diskVersion : '—'
      var latestVersion = info !== null && info.latestVersion ? info.latestVersion : null
      var canSelfUpdate = info !== null && info.canSelfUpdate === true
      var updateAvailable = info !== null && info.updateAvailable === true
      var restartRequired = info !== null && info.restartRequired === true
      var checkedText = info !== null && info.checkedAt ? formatTime(info.checkedAt) : t('updateNever')
      var canStar = info !== null && typeof info.htmlUrl === 'string' && info.htmlUrl !== ''

      var statusLine
      if (busy === 'applying') statusLine = t('updateApplying')
      else if (busy === 'checking') statusLine = t('updateChecking')
      else if (info === null) statusLine = t('updateNever')
      else if (restartRequired) statusLine = t('updateRestartRequired')
      else if (updateAvailable) statusLine = format(t('updateAvailableTo'), { version: latestVersion })
      else if (info.error) statusLine = format(t('updateFailed'), { message: info.error })
      else if (info.message) statusLine = info.message
      else statusLine = t('updateUpToDate')

      var statusTone = restartRequired || updateAvailable ? 'warn' : info !== null && info.error ? 'error' : 'ok'

      return h(
        'section',
        { className: 'am-update' },
        h(
          'div',
          { className: 'am-update-head' },
          h('h3', { className: 'am-update-title' }, t('updateTitle')),
          h('p', { className: 'am-update-hint' }, t('updateHint')),
        ),
        h(
          'div',
          { className: 'am-chips' },
          h('span', { className: 'am-chip-group' }, h('span', { className: 'am-chip-label' }, t('updateRuntime')), h(VersionChip, { text: runtimeVersion })),
          h('span', { className: 'am-chip-group' }, h('span', { className: 'am-chip-label' }, t('updateDisk')), h(VersionChip, { text: diskVersionText })),
          h('span', { className: 'am-chip-group' }, h('span', { className: 'am-chip-label' }, t('updateLatest')), h(VersionChip, { text: latestVersion !== null ? latestVersion : '—' })),
        ),
        h('div', { className: 'am-update-status am-update-status-' + statusTone }, statusLine),
        h(
          'div',
          { className: 'am-update-actions' },
          h(
            'button',
            {
              type: 'button',
              className: 'am-btn',
              disabled: busy !== null,
              onClick: function () {
                props.onCheck()
              },
            },
            busy === 'checking' ? t('updateCheckingShort') : t('updateCheck'),
          ),
          h(
            'button',
            {
              type: 'button',
              className: 'am-btn am-btn-primary',
              disabled: busy !== null || !canSelfUpdate || (!updateAvailable && !restartRequired),
              title: canSelfUpdate ? '' : t('updateNoSource'),
              onClick: function () {
                props.onApply()
              },
            },
            busy === 'applying' ? t('updateApplyingShort') : restartRequired ? t('updateRestartShort') : t('updateApply'),
          ),
          canStar
            ? h(
                'button',
                {
                  type: 'button',
                  className: 'am-btn am-star',
                  disabled: busy !== null,
                  onClick: function () {
                    props.onStar()
                  },
                },
                h('span', { className: 'am-star-glyph', 'aria-hidden': 'true' }, '★'),
                t('starAction'),
              )
            : null,
        ),
        h('div', { className: 'am-update-foot' }, format(t('updateCheckedAt'), { time: checkedText }), ' · ', t('updateAutoEvery')),
      )
    }



    /**
     * 「归档会话管理」整页。
     * @param props - `{ t, controller }`。
     * @returns section 元素。
     */
    function ArchiveSection(props) {
      var t = props.t
      var controller = props.controller
      var snapshot = useStore(controller.store)
      var nowState = React.useState(Date.now())
      var now = nowState[0]
      var setNow = nowState[1]

      // 挂载即拉取一次；离开时清掉所有定时器/监听（不留内存泄漏）。
      React.useEffect(
        function () {
          void controller.load()
          void controller.loadUpdate()
          var timer = setInterval(function () {
            setNow(Date.now())
          }, 30000)
          var onFocus = function () {
            void controller.load()
          }
          window.addEventListener('focus', onFocus)
          return function () {
            clearInterval(timer)
            window.removeEventListener('focus', onFocus)
          }
        },
        [controller, setNow],
      )

      var data = snapshot.data
      var phase = snapshot.phase
      var error = snapshot.error
      var notice = snapshot.notice
      var confirmTarget = snapshot.confirm
      var pending = snapshot.pending !== null && typeof snapshot.pending === 'object' ? snapshot.pending : {}
      var updateBusy = snapshot.updateBusy !== null && snapshot.updateBusy !== undefined ? snapshot.updateBusy : null

      var groups = data !== null && Array.isArray(data.groups) ? data.groups : []
      var total = data !== null && typeof data.total === 'number' ? data.total : 0
      var groupCount = data !== null && typeof data.groupCount === 'number' ? data.groupCount : groups.length

      // 更新卡片：自带能力，与其它插件零耦合。
      var updateNode = h(UpdateCard, {
        t: t,
        update: snapshot.update,
        busy: updateBusy,
        onCheck: function () {
          void controller.loadUpdate(true)
        },
        onApply: function () {
          void controller
            .applyUpdate()
            .then(function (outcome) {
              if (outcome === null || outcome === undefined) return
              var result = outcome.result !== null && outcome.result !== undefined ? outcome.result : {}
              if (result.ok === true) {
                controller.setNotice({
                  tone: 'success',
                  text: result.alreadyLatest === true
                    ? t('updateAlreadyLatest')
                    : format(t('updateApplied'), { from: result.from ?? '—', to: result.to ?? '—' }),
                })
              } else {
                controller.setNotice({
                  tone: 'error',
                  text: format(t('updateApplyFailed'), { message: result.message || result.error || 'unknown' }),
                })
              }
            })
        },
        onStar: function () {
          void controller.openRepo().then(function (result) {
            if (result !== null && result !== undefined && result.ok === true) return
            controller.setNotice({ tone: 'error', text: t('starFailed') })
          })
        },
      })

      var header = h(
        'div',
        { className: 'am-head' },
        h(
          'div',
          { className: 'am-head-row' },
          h(PluginIcon, null),
          h('div', { className: 'am-head-text' }, h('h2', { className: 'am-title' }, t('title')), h('p', { className: 'am-intro' }, t('intro'))),
        ),
      )

      var toolbar = h(
        'div',
        { className: 'am-toolbar' },
        h(
          'span',
          { className: 'am-stat' },
          total === 0 ? t('statEmpty') : format(t('statSummary'), { total: total, groups: groupCount }),
        ),
        h(
          'button',
          {
            type: 'button',
            className: 'am-btn',
            disabled: snapshot.loading === true,
            onClick: function () {
              void controller.load(true)
            },
          },
          snapshot.loading === true ? t('refreshing') : t('refresh'),
        ),
      )

      var noticeNode = null
      if (notice !== null && notice !== undefined) {
        noticeNode = h(
          'div',
          { className: 'am-notice am-notice-' + (notice.tone === 'success' ? 'success' : 'error'), role: 'status' },
          h('span', { className: 'am-notice-text' }, notice.text),
          h(
            'button',
            {
              type: 'button',
              className: 'am-notice-dismiss',
              'aria-label': t('closeLabel'),
              onClick: function () {
                controller.setNotice(null)
              },
            },
            '×',
          ),
        )
      }

      // 失效引用（工作区记账里有、磁盘上已经没有的会话）：历史删除留下的尾巴，一键清掉。
      var orphanCount = data !== null && typeof data.orphanCount === 'number' ? data.orphanCount : 0
      var orphanNode = null
      if (orphanCount > 0) {
        orphanNode = h(
          'div',
          { className: 'am-orphans' },
          h(
            'div',
            { className: 'am-orphans-body' },
            h('div', { className: 'am-orphans-title' }, format(t('orphanTitle'), { count: orphanCount })),
            h('div', { className: 'am-orphans-hint' }, t('orphanHint')),
          ),
          h(
            'button',
            {
              type: 'button',
              className: 'am-btn',
              disabled: snapshot.loading === true,
              onClick: function () {
                void controller.repair()
              },
            },
            snapshot.loading === true ? t('orphanRepairing') : t('orphanRepair'),
          ),
        )
      }

      var body
      if (phase === 'loading' && data === null) {
        body = h(
          'div',
          { className: 'am-loading' },
          h('span', null, t('loading')),
        )
      } else if (phase === 'error' && data === null) {
        body = h(
          'div',
          { className: 'am-error' },
          h('span', { className: 'am-error-text' }, format(t('loadFailed'), { message: error !== null ? error : '' })),
          h(
            'div',
            null,
            h(
              'button',
              {
                type: 'button',
                className: 'am-btn',
                onClick: function () {
                  void controller.load(true)
                },
              },
              t('retry'),
            ),
          ),
        )
      } else if (groups.length === 0) {
        body = h(
          'div',
          { className: 'am-empty' },
          h(WhaleMascot, { size: 160, title: t('whaleAlt') }),
          h('p', { className: 'am-empty-title' }, t('emptyTitle')),
          h('p', { className: 'am-empty-hint' }, t('emptyHint')),
        )
      } else {
        body = h(
          'div',
          { className: 'am-groups' },
          groups.map(function (group) {
            var key = group.workspaceId !== null && group.workspaceId !== undefined ? group.workspaceId : 'ungrouped'
            var title = group.ungrouped === true ? t('ungrouped') : group.title !== null && group.title !== undefined ? group.title : key
            return h(
              'section',
              { className: 'am-group', key: key },
              h(
                'header',
                { className: 'am-group-head' },
                h('span', { className: 'am-group-title', title: title }, title),
                group.pathLabel !== null && group.pathLabel !== undefined && group.pathLabel !== ''
                  ? h('span', { className: 'am-group-path', title: group.pathLabel }, group.pathLabel)
                  : group.ungrouped === true
                    ? h('span', { className: 'am-group-path' }, t('ungroupedHint'))
                    : null,
                h('span', { className: 'am-group-count' }, format(t('sectionSummary'), { count: group.sessions.length })),
              ),
              h(
                'ul',
                { className: 'am-rows' },
                group.sessions.map(function (row) {
                  return h(ArchiveRow, {
                    key: row.sessionId,
                    t: t,
                    row: row,
                    now: now,
                    pending: pending[row.sessionId],
                    onRestore: function (sessionId, rowTitle) {
                      void controller.restore(sessionId, rowTitle)
                    },
                    onDelete: function (target) {
                      controller.confirm(target)
                    },
                  })
                }),
              ),
            )
          }),
          h(
            'div',
            { className: 'am-decor', 'aria-hidden': 'true' },
            h(WhaleMascot, { size: 96, title: t('whaleAlt') }),
          ),
        )
      }

      return h(
        'div',
        { className: 'am-section' },
        header,
        updateNode,
        toolbar,
        noticeNode,
        orphanNode,
        body,
        h(ConfirmDialog, {
          t: t,
          target: confirmTarget,
          onCancel: function () {
            controller.confirm(null)
          },
          onConfirm: function (sessionId, title) {
            controller.confirm(null)
            void controller.remove(sessionId, title)
          },
        }),
      )
    }

    // -----------------------------------------------------------------------
    // 插件入口
    // -----------------------------------------------------------------------

    /**
     * 挂到设置页；拿不到 slots 时安静退场（不抛错、不影响宿主其它功能）。
     * @param ctx - 浏览器插件上下文。
     */
    function apply(ctx) {
      try {
        if (typeof ctx.inject !== 'function') {
          console.warn('[archive-manager] 没有 ctx.inject，跳过设置页注册')
          return
        }
        ctx.inject(['slots', 'locale'], function (owner) {
          var slots = typeof owner.get === 'function' ? owner.get('slots') : owner.slots
          var locale = typeof owner.get === 'function' ? owner.get('locale') : owner.locale
          /**
           * 注册随插件生命周期释放的清理：优先用注入回调自带的 effect（它会跟着插件一起释放），
           * 退化时用外层 ctx.effect。
           * @param setup - 返回 disposer 的函数。
           * @param label - 诊断标签。
           */
          var track = function (setup, label) {
            try {
              if (owner !== null && owner !== undefined && typeof owner.effect === 'function') {
                owner.effect(setup, label)
                return
              }
              if (typeof ctx.effect === 'function') ctx.effect(setup, label)
            } catch (error) {
              console.warn('[archive-manager] 注册清理失败（' + label + '）：', error)
            }
          }
          if (slots === undefined || slots === null || typeof slots.inject !== 'function') {
            console.warn('[archive-manager] slots 服务不可用，跳过设置页注册')
            return
          }

          var bound = null
          if (locale !== undefined && locale !== null && typeof locale.bind === 'function') {
            try {
              bound = locale.bind(NS)
            } catch (error) {
              console.warn('[archive-manager] 词典绑定失败（回退到内置文案）：', error)
            }
          }

          var t = function (key) {
            var fallback = zh[key] !== undefined ? zh[key] : en[key] !== undefined ? en[key] : key
            if (bound === null) return fallback
            try {
              var value = bound(key)
              return typeof value === 'string' && value !== '' ? value : fallback
            } catch {
              return fallback
            }
          }

          try {
            if (locale !== undefined && locale !== null && typeof locale.register === 'function') {
              var offLocale = locale.register(NS, { zh: zh, en: en })
              track(function () {
                return offLocale
              }, 'archive-manager: dictionaries')
            }
          } catch (error) {
            console.warn('[archive-manager] 词典注册失败（回退到内置文案）：', error)
          }

          var controller = createController({
            t: t,
            resolveService: function (name) {
              try {
                if (typeof owner.get === 'function') return owner.get(name)
                return owner[name]
              } catch {
                return undefined
              }
            },
          })

          // 宿主归档集合变化时自动跟上（外部归档/恢复、另一个页签的操作都能看到）。
          try {
            var workspaces = typeof owner.get === 'function' ? owner.get('workspaces') : owner.workspaces
            if (workspaces !== undefined && workspaces !== null && typeof workspaces.subscribe === 'function') {
              var offWorkspaces = workspaces.subscribe(function () {
                try {
                  var snapshot = workspaces.getSnapshot()
                  controller.observeArchived(snapshot !== null && snapshot !== undefined ? snapshot.archivedSessionIds : [])
                } catch (error) {
                  console.warn('[archive-manager] 读取工作区快照失败：', error)
                }
              })
              track(function () {
                return offWorkspaces
              }, 'archive-manager: workspace archive watcher')
            }
          } catch (error) {
            console.warn('[archive-manager] 订阅工作区归档集合失败（改用按需刷新）：', error)
          }

          try {
            slots.inject('settings.section', function () {
              return slots.register(
                {
                  name: 'settings.section',
                  id: SECTION_ID,
                  order: 25,
                  label: function () {
                    return t('nav')
                  },
                  locale: NS,
                  inject: function () {
                    return { t: t, controller: controller }
                  },
                },
                ArchiveSection,
              )
            })
            console.info('[archive-manager] 已注册到设置页 settings.section')
          } catch (error) {
            console.error('[archive-manager] 注册 settings.section 失败：', error)
          }
        })
      } catch (error) {
        console.error('[archive-manager] 客户端接线失败：', error)
      }
    }

    exports.apply = apply
    return module.exports
  },
})
