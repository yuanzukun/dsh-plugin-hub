/**
 * archive-manager · Host 半侧（跑在 DSH 进程内的那一半）
 *
 * 职责：
 *  ① 读取 Workspace 注册表与本地会话存储，按工作区维度汇总「已归档会话」；
 *  ② 提供同源 HTTP 路由，供设置页读取列表、恢复会话、永久删除会话；
 *  ③ 维护归档时间索引（DSH 本身只在注册表里保存已归档的 id 集合，不含时间）。
 *
 * 设计约束（都是踩过的坑，别随手改）：
 *  · 路由必须用 exact —— prefix 会吃掉 `/plugins/archive-manager/client.js`，
 *    那条 URL 是 client-modules 物化本包浏览器半侧的入口，一盖住界面就永远加载不了。
 *  · 所有变更串行执行：恢复/删除都写同一份注册表与同一批文件，并发会互相踩。
 *  · 删除是**不可恢复**的本地文件删除；因此先做存在性与活动性检查，再删文件，
 *    最后才从归档集合里摘掉 id——任何一步失败都不会留下「已恢复但文件还在」的假象。
 *  · 绝不依赖 schemastery / 设置服务：配置以文件与注册表为准，设置页只是入口。
 *
 * @module archive-manager/host
 */

import {
  copyFileSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
} from 'node:fs'
import { basename, dirname, isAbsolute, join, relative, resolve } from 'node:path'
import { homedir, tmpdir } from 'node:os'
import { spawn, spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

export const name = 'archive-manager'

/**
 * 需要的宿主服务：`webServer` 用来登记路由，`workspaceRegistry` 是归档集合与工作区记账的
 * 唯一权威（恢复会话就是往它写），`sessions` 是进程内的会话表——删除时必须把仍活着的会话
 * 从这张表里摘掉，否则 `session/list` 会继续把它列出来（列表会合并 live 会话），
 * 客户端刷新多少次都去不掉那个「幽灵」。
 */
export const inject = ['webServer', 'workspaceRegistry', 'sessions']

/** 本插件独占的路由前缀（exact 路由逐个登记，不注册 prefix）。 */
const ROUTE = '/plugins/archive-manager'

/** 归档时间索引的格式版本。 */
const INDEX_VERSION = 1

/** 请求体上限：本插件的载荷只有 `{ sessionId }`，16 KiB 已经非常宽松。 */
const MAX_BODY_BYTES = 16384

/**
 * 合法的会话 id 形状。
 *
 * 必须是「字母数字开头 + 只含字母/数字/`-`/`_`」——**故意不允许 `.`**：
 * 会话 id 由宿主生成（`session-<uuid>` 或裸 uuid），本来就不含点号，
 * 而允许点号就等于允许 `..`，删除接口会被拿来做路径穿越。
 * 第二个作用是拒绝 `/`、`\`、`:` 与空白，保证拼接出来的路径永远只有一个层级。
 */
const SESSION_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9_-]{0,199}$/

/** 一次列表刷新里允许扫描的会话目录上限（防御异常的巨型目录）。 */
const MAX_SESSION_SCAN = 20000

// ---------------------------------------------------------------------------
// 路径与文件小工具
// ---------------------------------------------------------------------------

/**
 * DSH 数据根目录：优先 `DSH_HOME`，否则 `~/.dsh`。
 * @returns 绝对路径。
 */
function dshHome() {
  const fromEnv = typeof process.env.DSH_HOME === 'string' ? process.env.DSH_HOME.trim() : ''
  return fromEnv === '' ? join(homedir(), '.dsh') : resolve(fromEnv)
}

/** @returns 会话本体根目录（`<home>/sessions`）。 */
function sessionsRoot() {
  return join(dshHome(), 'sessions')
}

/** @returns 会话投影缓存目录（`<home>/storages/session_projcache/sessions`）。 */
function projectionRoot() {
  return join(dshHome(), 'storages', 'session_projcache', 'sessions')
}

/** @returns Workspace 注册表的持久文件。 */
function workspaceFile() {
  return join(dshHome(), 'storages', 'workspace.json')
}

/** @returns 本插件自己的状态目录。 */
function stateDir() {
  return join(dshHome(), 'archive-manager')
}

/** @returns 归档时间索引文件。 */
function indexFile() {
  return join(stateDir(), 'archive-times.json')
}

/**
 * 读 JSON；任何异常都退化为 fallback（插件不能因为一个坏文件就整页不可用）。
 * @param file - 绝对路径。
 * @param fallback - 读取或解析失败时的返回值。
 * @returns 解析结果或 fallback。
 */
function readJson(file, fallback) {
  try {
    const text = readFileSync(file, 'utf8')
    if (text.trim() === '') return fallback
    return JSON.parse(text)
  } catch {
    return fallback
  }
}

/**
 * 原子替换一个 JSON 文件：先写临时文件再 rename，避免半截文件被别的进程读到。
 * @param file - 目标文件。
 * @param value - 要序列化的值。
 */
function writeJsonAtomic(file, value) {
  mkdirSync(dirname(file), { recursive: true })
  const temporary = `${file}.${process.pid}.${Date.now()}.tmp`
  try {
    writeFileSync(temporary, `${JSON.stringify(value, null, 2)}\n`, 'utf8')
    renameSync(temporary, file)
  } catch (error) {
    try {
      rmSync(temporary, { force: true })
    } catch {
      /* 临时文件清不掉也不该盖住真实错误 */
    }
    throw error
  }
}

/**
 * 取目录/文件的递归字节数；读不到时返回 0（仅用于界面展示，不作为正确性依据）。
 * @param path - 目标路径。
 * @returns 字节数。
 */
function sizeOf(path) {
  let total = 0
  const walk = (target) => {
    let stat
    try {
      stat = statSync(target)
    } catch {
      return
    }
    if (stat.isFile()) {
      total += stat.size
      return
    }
    if (!stat.isDirectory()) return
    let entries
    try {
      entries = readdirSync(target, { withFileTypes: true })
    } catch {
      return
    }
    for (const entry of entries) walk(join(target, entry.name))
  }
  walk(path)
  return total
}

/**
 * 宽松解析一个 ISO 时间，失败返回 null。
 * @param value - 候选时间（ISO 字符串 / epoch 毫秒数字）。
 * @returns 毫秒时间戳或 null。
 */
function toMillis(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return value
  if (typeof value !== 'string' || value.trim() === '') return null
  const parsed = Date.parse(value)
  return Number.isNaN(parsed) ? null : parsed
}

/**
 * 毫秒时间戳 → ISO 字符串；无效值返回 null。
 * @param value - 毫秒时间戳或可解析的时间值。
 * @returns ISO 字符串或 null。
 */
function toIso(value) {
  const ms = toMillis(value)
  return ms === null ? null : new Date(ms).toISOString()
}

// ---------------------------------------------------------------------------
// 归档时间索引
// ---------------------------------------------------------------------------

/**
 * 读归档时间索引。
 * @returns `{ sessions: Record<sessionId, { archivedAt, title?, workspaceId?, lastPromptAt? }> }`
 */
function readArchiveIndex() {
  const raw = readJson(indexFile(), null)
  const sessions = {}
  if (raw !== null && typeof raw === 'object' && raw.sessions !== null && typeof raw.sessions === 'object') {
    for (const [sessionId, entry] of Object.entries(raw.sessions)) {
      if (typeof sessionId !== 'string' || sessionId === '') continue
      if (entry === null || typeof entry !== 'object') continue
      const archivedAt = toIso(entry.archivedAt)
      if (archivedAt === null) continue
      sessions[sessionId] = {
        archivedAt,
        ...typeof entry.title === 'string' && entry.title !== '' ? { title: entry.title } : {},
        ...typeof entry.workspaceId === 'string' && entry.workspaceId !== '' ? { workspaceId: entry.workspaceId } : {},
        ...toMillis(entry.lastPromptAt) !== null ? { lastPromptAt: toMillis(entry.lastPromptAt) } : {},
      }
    }
  }
  return { sessions }
}

/**
 * 写归档时间索引。
 * @param sessions - 索引的 sessions 表。
 */
function writeArchiveIndex(sessions) {
  writeJsonAtomic(indexFile(), { version: INDEX_VERSION, updatedAt: new Date().toISOString(), sessions })
}

/**
 * 把索引与当前归档集合对齐：新归档的 id 记下「首次观测时间」，已恢复/删除的 id 从索引移除。
 * 这就是 DSH 缺失的「归档时间」——注册表只有 id 集合，时间只能由本插件在第一次看见它时落盘。
 * @param archivedIds - 宿主当前确认的归档集合。
 * @returns 对齐后的索引表。
 */
function reconcileArchiveIndex(archivedIds) {
  const { sessions } = readArchiveIndex()
  const wanted = new Set(archivedIds)
  let changed = false
  const now = new Date().toISOString()
  for (const sessionId of wanted) {
    if (sessions[sessionId] === undefined) {
      sessions[sessionId] = { archivedAt: now }
      changed = true
    }
  }
  for (const sessionId of Object.keys(sessions)) {
    if (!wanted.has(sessionId)) {
      delete sessions[sessionId]
      changed = true
    }
  }
  if (changed) {
    try {
      writeArchiveIndex(sessions)
    } catch (error) {
      console.error('[archive-manager] 写入归档时间索引失败（不影响列表读取）：', error)
    }
  }
  return sessions
}

/**
 * 更新索引中某个会话的展示快照（标题/工作区/最后活动），不做时间重写。
 * @param sessionId - 会话 id。
 * @param patch - 要合并的字段。
 */
function rememberSnapshot(sessionId, patch) {
  const { sessions } = readArchiveIndex()
  const current = sessions[sessionId]
  if (current === undefined) return
  const next = { ...current }
  let changed = false
  for (const [key, value] of Object.entries(patch)) {
    if (value === undefined || value === null || value === '') continue
    if (next[key] === value) continue
    next[key] = value
    changed = true
  }
  if (!changed) return
  sessions[sessionId] = next
  try {
    writeArchiveIndex(sessions)
  } catch {
    /* 快照只是兜底展示，写失败不该影响列表 */
  }
}

/**
 * 从索引里移除若干 id（恢复/删除后调用）。
 * @param ids - 要移除的会话 id。
 */
function forgetSnapshots(ids) {
  const { sessions } = readArchiveIndex()
  let changed = false
  for (const id of ids) {
    if (sessions[id] === undefined) continue
    delete sessions[id]
    changed = true
  }
  if (!changed) return
  try {
    writeArchiveIndex(sessions)
  } catch (error) {
    console.error('[archive-manager] 清理归档时间索引失败：', error)
  }
}

// ---------------------------------------------------------------------------
// 会话与工作区数据
// ---------------------------------------------------------------------------

/**
 * 读会话投影缓存里展示所需的事实。
 * @param sessionId - 会话 id。
 * @returns `{ title, lastPromptAt, createdAt }`，缺字段为 undefined。
 */
function readProjection(sessionId) {
  const raw = readJson(join(projectionRoot(), `${sessionId}.json`), null)
  if (raw === null || typeof raw !== 'object') return {}
  const record = raw.record !== null && typeof raw.record === 'object' ? raw.record : raw
  const rows = record.rows !== null && typeof record.rows === 'object' ? record.rows : {}
  const titleValue = rows.title !== null && typeof rows.title === 'object' ? rows.title.val : undefined
  const metadataValue =
    rows.sessionListMetadata !== null && typeof rows.sessionListMetadata === 'object'
      ? rows.sessionListMetadata.val
      : undefined
  const identity = record.identity !== null && typeof record.identity === 'object' ? record.identity : {}
  return {
    title: typeof titleValue === 'string' && titleValue.trim() !== '' ? titleValue : undefined,
    lastPromptAt: metadataValue !== null && typeof metadataValue === 'object' ? toMillis(metadataValue.lastPromptAt) ?? undefined : undefined,
    createdAt: toMillis(identity.createdAt) ?? undefined,
  }
}

/**
 * 在 `<home>/sessions/<workspaceSlug>/<sessionId>` 里定位会话目录。
 * 不依赖 slug 生成规则（扫描一层目录），这样目录被外部重命名也能找到。
 * @param sessionId - 会话 id。
 * @returns 命中的绝对目录，或 undefined。
 */
function locateSessionDir(sessionId) {
  const root = sessionsRoot()
  const direct = join(root, sessionId)
  try {
    // 边界校验：只认 sessions 根目录之内的目录，绝不接受 `..` 逃逸出来的路径。
    if (isInside(root, direct) && statSync(direct).isDirectory()) return direct
  } catch {
    /* 继续按 workspace 子目录找 */
  }
  let entries
  try {
    entries = readdirSync(root, { withFileTypes: true })
  } catch {
    return undefined
  }
  let scanned = 0
  for (const entry of entries) {
    if (++scanned > MAX_SESSION_SCAN) break
    if (!entry.isDirectory()) continue
    const candidate = join(root, entry.name, sessionId)
    try {
      if (isInside(root, candidate) && statSync(candidate).isDirectory()) return candidate
    } catch {
      /* 不是这个 workspace */
    }
  }
  return undefined
}

/**
 * 列出某个会话在本地留下的全部存储痕迹。
 * @param sessionId - 会话 id。
 * @returns 命中的路径数组（目录或文件）。
 */
function collectArtifacts(sessionId) {
  const hits = []
  const sessionDir = locateSessionDir(sessionId)
  if (sessionDir !== undefined) hits.push(sessionDir)
  const projectionRootDir = projectionRoot()
  const candidateFiles = [
    join(projectionRootDir, `${sessionId}.json`),
    join(projectionRootDir, `${sessionId}.json.tmp`),
  ]
  for (const file of candidateFiles) {
    // 同一个边界规则：投影缓存只可能落在它自己的根目录里。
    if (isInside(projectionRootDir, file) && existsSync(file)) hits.push(file)
  }
  return hits
}

/**
 * 从磁盘读 Workspace 注册表（workspaceRegistry 服务不可用时的兜底）。
 * @returns `{ workspaces: [{ workspaceId, title, path, sessionIds }], archivedSessionIds }`
 */
function readWorkspaceRegistryFromDisk() {
  const raw = readJson(workspaceFile(), null)
  const empty = { workspaces: [], archivedSessionIds: [] }
  if (raw === null || typeof raw !== 'object') return empty
  const global = raw.global !== null && typeof raw.global === 'object' ? raw.global : {}
  const tables = raw.tables !== null && typeof raw.tables === 'object' ? raw.tables : {}
  const workspacesTable = tables.workspaces !== null && typeof tables.workspaces === 'object' ? tables.workspaces : {}
  const order = Array.isArray(global.workspaceIds) ? global.workspaceIds : Object.keys(workspacesTable)
  const workspaces = []
  for (const workspaceId of order) {
    const row = workspacesTable[workspaceId]
    if (row === null || typeof row !== 'object') continue
    workspaces.push({
      workspaceId,
      title: typeof row.title === 'string' ? row.title : workspaceId,
      path: typeof row.path === 'string' ? row.path : '',
      sessionIds: Array.isArray(row.sessionIds) ? row.sessionIds.filter((id) => typeof id === 'string') : [],
    })
  }
  return {
    workspaces,
    archivedSessionIds: Array.isArray(global.archivedSessionIds)
      ? global.archivedSessionIds.filter((id) => typeof id === 'string')
      : [],
  }
}

/**
 * 取 Workspace 注册表服务（可能尚未就绪）。
 * @param ctx - 插件上下文。
 * @returns 注册表服务或 null。
 */
function registryOf(ctx) {
  try {
    const registry = ctx.workspaceRegistry
    return registry !== undefined && registry !== null ? registry : null
  } catch {
    return null
  }
}

/**
 * 把注册表（服务或磁盘）读成统一形状。
 * @param ctx - 插件上下文。
 * @returns `{ source, workspaces, archivedSessionIds, registry }`
 */
function snapshotRegistry(ctx) {
  const registry = registryOf(ctx)
  if (registry !== null) {
    try {
      const archivedSessionIds = Array.isArray(registry.archivedSessionIds)
        ? registry.archivedSessionIds.map(String)
        : []
      const workspaces = registry.list().map((workspace) => ({
        // Workspace 实体的稳定 id 挂在 `id` 上（`workspaceId` 只是客户端投影的字段名）。
        workspaceId: String(workspace.id ?? workspace.workspaceId ?? ''),
        title: typeof workspace.title === 'string' && workspace.title !== '' ? workspace.title : String(workspace.id ?? ''),
        path: typeof workspace.path === 'string' ? workspace.path : '',
        sessionIds: Array.isArray(workspace.sessionIds) ? workspace.sessionIds.map(String) : [],
        // 原始记账：不受「文件是否还在」过滤，用来发现历史删除留下的幽灵引用。
        rawSessionIds: rawSessionIds(workspace),
      }))
      return { source: 'live', workspaces, archivedSessionIds, registry }
    } catch (error) {
      console.error('[archive-manager] 读取 Workspace 注册表失败，回退到磁盘快照：', error)
    }
  }
  const disk = readWorkspaceRegistryFromDisk()
  return { source: 'disk', ...disk, registry: null }
}

/**
 * 构造一行归档会话的展示数据。
 * @param sessionId - 会话 id。
 * @param indexEntry - 归档时间索引里的条目。
 * @param workspace - 归属工作区（未归组时为 null）。
 * @param onDiskIds - 磁盘上真实存在的会话 id 集合（批量扫描结果，避免逐个目录探测）。
 * @returns 行数据。
 */
function buildRow(sessionId, indexEntry, workspace, onDiskIds) {
  const projection = readProjection(sessionId)
  const artifacts = collectArtifacts(sessionId)
  const onDisk = onDiskIds !== undefined ? onDiskIds.has(sessionId) || artifacts.length > 0 : artifacts.length > 0
  const title = projection.title ?? indexEntry?.title ?? '（未命名会话）'
  const lastPromptAt = projection.lastPromptAt ?? indexEntry?.lastPromptAt ?? null
  const createdAt = projection.createdAt ?? null
  const archivedAt = indexEntry?.archivedAt ?? null
  const sizeBytes = artifacts.reduce((total, path) => total + sizeOf(path), 0)
  if (projection.title !== undefined || projection.lastPromptAt !== undefined) {
    rememberSnapshot(sessionId, {
      title: projection.title,
      lastPromptAt: projection.lastPromptAt,
      workspaceId: workspace?.workspaceId,
    })
  }
  return {
    sessionId,
    title,
    archivedAt,
    lastPromptAt,
    createdAt,
    workspaceId: workspace?.workspaceId ?? null,
    workspaceTitle: workspace?.title ?? null,
    workspacePathLabel: workspace?.path ? basename(workspace.path) : null,
    sizeBytes,
    fileCount: artifacts.length,
    onDisk,
  }
}

/**
 * 汇总整棵归档列表（按工作区分组）。
 * @param ctx - 插件上下文。
 * @returns 完整状态载荷。
 */
function buildState(ctx) {
  const snapshot = snapshotRegistry(ctx)
  const archivedIds = snapshot.archivedSessionIds
  const index = reconcileArchiveIndex(archivedIds)
  const archivedSet = new Set(archivedIds)
  const onDiskIds = diskSessionIds()
  const claimed = new Set()
  const groups = []

  for (const workspace of snapshot.workspaces) {
    const rows = []
    for (const sessionId of workspace.sessionIds) {
      if (!archivedSet.has(sessionId) || claimed.has(sessionId)) continue
      claimed.add(sessionId)
      rows.push(buildRow(sessionId, index[sessionId], workspace, onDiskIds))
    }
    if (rows.length === 0) continue
    rows.sort((left, right) => (toMillis(right.archivedAt) ?? 0) - (toMillis(left.archivedAt) ?? 0))
    groups.push({
      workspaceId: workspace.workspaceId,
      title: workspace.title,
      pathLabel: workspace.path ? basename(workspace.path) : '',
      sessions: rows,
    })
  }

  const ungrouped = []
  for (const sessionId of archivedIds) {
    if (claimed.has(sessionId)) continue
    claimed.add(sessionId)
    ungrouped.push(buildRow(sessionId, index[sessionId], null, onDiskIds))
  }
  if (ungrouped.length > 0) {
    ungrouped.sort((left, right) => (toMillis(right.archivedAt) ?? 0) - (toMillis(left.archivedAt) ?? 0))
    groups.push({ workspaceId: null, title: null, path: null, ungrouped: true, sessions: ungrouped })
  }

  // 幽灵引用：工作区记账里还在，但磁盘上已经没有、也不在归档集合里。
  // 它们不含任何内容，只会让侧边栏列出一个点不开的会话，需要清理掉。
  const orphanIds = []
  const seenOrphan = new Set()
  for (const workspace of snapshot.workspaces) {
    const raw = Array.isArray(workspace.rawSessionIds) ? workspace.rawSessionIds : workspace.sessionIds
    for (const sessionId of raw) {
      if (archivedSet.has(sessionId) || onDiskIds.has(sessionId) || seenOrphan.has(sessionId)) continue
      seenOrphan.add(sessionId)
      orphanIds.push(sessionId)
    }
  }

  const total = groups.reduce((sum, group) => sum + group.sessions.length, 0)
  return {
    ok: true,
    generatedAt: new Date().toISOString(),
    source: snapshot.source,
    // 不返回本机 home / 工作区绝对路径 / 原始 id 列表：
    // 这个接口对本机任何进程可读，路径与用户名没有必要出现在响应里。
    total,
    groupCount: groups.length,
    groups,
    orphanCount: orphanIds.length,
  }
}

// ---------------------------------------------------------------------------
// HTTP 工具
// ---------------------------------------------------------------------------

/**
 * 写 JSON 响应。
 * @param res - HTTP 响应。
 * @param status - 状态码。
 * @param body - 可序列化载荷。
 */
function sendJson(res, status, body) {
  if (res.headersSent) {
    res.end()
    return
  }
  const text = JSON.stringify(body)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'content-length': Buffer.byteLength(text),
  })
  res.end(text)
}

/**
 * 只接受同源请求：桌面端的渲染进程经桥接发起的请求没有 Origin，同样放行。
 * @param req - HTTP 请求。
 * @returns 拒绝原因，放行时为 null。
 */
function rejectForeignOrigin(req) {
  if (req.headers['sec-fetch-site'] === 'cross-site') return 'cross-site'
  const origin = req.headers.origin
  if (typeof origin !== 'string' || origin === '' || origin === 'null') return null
  const host = req.headers.host
  if (typeof host !== 'string' || host === '') return 'missing-host'
  try {
    return new URL(origin).host === host ? null : 'origin-mismatch'
  } catch {
    return 'bad-origin'
  }
}

/**
 * 只接受本机回环 Host 的请求。
 *
 * 这些路由由 `webServer` 直接提供，不经过 `/api` 的浏览器信任栅栏，
 * 所以再加一道 Host 判断：带 Host 就必须是回环地址，挡住 DNS rebinding
 * 和「服务被绑到局域网地址后被别的机器调用」这两种情况。
 * 桌面端渲染进程经 IPC 桥接的 fetch 可能不带 Host，这种请求放行。
 * @param req - HTTP 请求。
 * @returns 拒绝原因，放行时为 null。
 */
function rejectNonLoopbackHost(req) {
  const host = req.headers.host
  if (typeof host !== 'string' || host === '') return null
  let hostname = host
  if (host.startsWith('[')) {
    const end = host.indexOf(']')
    hostname = end > 0 ? host.slice(1, end) : host
  } else {
    const colon = host.lastIndexOf(':')
    if (colon > 0) hostname = host.slice(0, colon)
  }
  const normalized = hostname.trim().toLowerCase()
  if (normalized === '') return 'empty-host'
  if (normalized === 'localhost' || normalized.endsWith('.localhost')) return null
  if (normalized === '::1' || normalized === '0:0:0:0:0:0:0:1') return null
  if (/^127\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(normalized)) return null
  return 'non-loopback-host'
}

/**
 * 请求准入：Host 必须是本机回环、Origin 必须同源。
 * @param req - HTTP 请求。
 * @returns 拒绝原因，放行时为 null。
 */
function rejectUntrustedRequest(req) {
  return rejectNonLoopbackHost(req) ?? rejectForeignOrigin(req)
}

/**
 * 读 JSON 请求体（带体积上限）。
 * @param req - HTTP 请求。
 * @returns `{ ok: true, value }` 或 `{ ok: false, reason }`。
 */
function readJsonBody(req) {
  return new Promise((resolvePromise) => {
    const chunks = []
    let size = 0
    let settled = false
    const finish = (value) => {
      if (settled) return
      settled = true
      resolvePromise(value)
    }
    req.on('data', (chunk) => {
      size += chunk.length
      if (size > MAX_BODY_BYTES) {
        finish({ ok: false, reason: 'body-too-large' })
        req.destroy()
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => {
      if (chunks.length === 0) {
        finish({ ok: true, value: {} })
        return
      }
      try {
        const value = JSON.parse(Buffer.concat(chunks).toString('utf8'))
        if (value === null || typeof value !== 'object' || Array.isArray(value)) {
          finish({ ok: false, reason: 'body-not-object' })
          return
        }
        finish({ ok: true, value })
      } catch {
        finish({ ok: false, reason: 'body-not-json' })
      }
    })
    req.on('error', () => {
      finish({ ok: false, reason: 'body-stream-error' })
    })
  })
}

/**
 * 判断一个路径是否确实落在某个根目录**之内**（不包含根本身）。
 *
 * 这是删除路径的第二道闸：即使第一层 id 校验被绕过（比如未来放宽了字符集），
 * 只要拼出来的路径跑出了 `sessions` / 投影缓存根目录，就一律不碰。
 * @param root - 允许的根目录。
 * @param target - 待校验路径。
 * @returns 是否在根目录内。
 */
function isInside(root, target) {
  try {
    const rel = relative(resolve(root), resolve(target))
    return rel !== '' && !rel.startsWith('..') && !isAbsolute(rel)
  } catch {
    return false
  }
}

/**
 * 校验并取出请求里的 sessionId。
 *
 * 形如 `session-<uuid>`、裸 uuid（子代理会话）都能过；
 * `..\\storages`、`a/b`、`C:\\x`、带点号的任何东西都会被拒绝。
 * @param body - 已解析的请求体。
 * @returns sessionId 或 null。
 */
function sessionIdOf(body) {
  const value = body?.sessionId
  if (typeof value !== 'string') return null
  const trimmed = value.trim()
  if (trimmed === '' || trimmed.length > 200) return null
  if (!SESSION_ID_PATTERN.test(trimmed)) return null
  // 冗余但明确：白名单已经排除了这些字符，这里再挡一次，防止以后改正则时手滑。
  if (trimmed.includes('..') || trimmed.includes('/') || trimmed.includes('\\') || trimmed.includes(':')) return null
  return trimmed
}

/**
 * 问一遍「这个会话现在还有工作在跑吗」。
 * DSH 的归档准入就是同一个 waterfall：返回非空即代表回合/子代理/任务/提醒仍在活动。
 *
 * 注意返回值带 `ok`：探测本身失败时**不能**当成「没有活动」——
 * 那等于在宿主服务异常时盲删一个可能正在跑的会话，所以调用方必须据此取消删除。
 * @param ctx - 插件上下文。
 * @param sessionId - 会话 id。
 * @returns `{ ok, activity }`；`ok:false` 表示无法确认，调用方应拒绝删除。
 */
async function probeActivity(ctx, sessionId) {
  try {
    if (typeof ctx.waterfall !== 'function') return { ok: false, activity: [] }
    const report = await ctx.waterfall('workspace/session-activity', { sessionId }, () => Promise.resolve([]))
    return { ok: true, activity: Array.isArray(report) ? report : [] }
  } catch (error) {
    console.error('[archive-manager] 会话活动探测失败，取消删除：', error)
    return { ok: false, activity: [] }
  }
}

/**
 * 让这个会话上仍在跑的工作全部停下（回合、子代理、后台任务、提醒）。
 * 用的是 DSH 自己的 `workspace/session-stop` 并行事件，和归档时 stopActivity 走同一条路。
 * @param ctx - 插件上下文。
 * @param sessionId - 会话 id。
 * @returns 是否确认停稳；false 时调用方必须取消删除。
 */
async function stopSessionActivity(ctx, sessionId) {
  try {
    if (typeof ctx.parallel !== 'function') return false
    await ctx.parallel('workspace/session-stop', { sessionId })
    return true
  } catch (error) {
    console.error('[archive-manager] 停止会话活动失败，取消删除：', error)
    return false
  }
}

/**
 * 取进程内仍活着的会话实例。
 * @param ctx - 插件上下文。
 * @param sessionId - 会话 id。
 * @returns Session 实例或 null。
 */
function liveSessionOf(ctx, sessionId) {
  try {
    const store = ctx.sessions
    if (store === null || store === undefined || typeof store.get !== 'function') return null
    return store.get(sessionId) ?? null
  } catch {
    return null
  }
}

/**
 * 把一个 live 会话从 `SessionStore` 里摘掉（幂等）。
 *
 * 为什么必须做：`session/list` 的 Host 实现会把「持久化行」和「`ctx.sessions.list()` 的 live 行」
 * 合并后一起返回。只要会话还在内存表里，前端刷新多少次都会把它重新拉回来——
 * 这正是「删了文件、界面还在、点开还能看内容」的根因。
 * `detachEntered` 是 SessionStore 的公开原语：删除 store entry、清挂载钩子，并在已 announce 时
 * 发出配对的 `session/disposed`，各 owner（agent loop、subagent、jobs…）据此收敛。
 * @param ctx - 插件上下文。
 * @param session - 要摘除的 Session 实例。
 * @returns 是否真的摘掉了一个条目。
 */
function detachLiveSession(ctx, session) {
  try {
    const store = ctx.sessions
    if (store === null || store === undefined) return false
    if (typeof store.liveEntryFor !== 'function' || typeof store.detachEntered !== 'function') return false
    const entry = store.liveEntryFor(session)
    if (entry === undefined || entry === null) return false
    store.detachEntered(entry)
    return true
  } catch (error) {
    console.warn('[archive-manager] 从 SessionStore 摘除会话失败（继续删除）：', error)
    return false
  }
}

/**
 * 睡一小会儿，给「停止活动 / 卸载会话」的异步收敛留出时间。
 * @param ms - 毫秒。
 * @returns 完成 Promise。
 */
function sleep(ms) {
  return new Promise((resolve) => {
    const timer = setTimeout(resolve, ms)
    if (typeof timer.unref === 'function') timer.unref()
  })
}

// ---------------------------------------------------------------------------
// 变更操作
// ---------------------------------------------------------------------------

/**
 * 读一个 Workspace 的**原始**会话记账。
 *
 * `workspace.sessionIds` 这个 getter 会按「会话文件是否仍可解析」过滤，所以一旦会话文件被删，
 * 再读 getter 就看不到目标 id 了。清理记账必须用原始记录，因此这里优先摸实体内部的
 * `record.sessionIds`，拿不到再退回公开 getter（宁可少清，也不要漏清）。
 * @param workspace - Workspace 实体。
 * @returns 会话 id 数组。
 */
function rawSessionIds(workspace) {
  try {
    const record = workspace.record
    if (record !== null && typeof record === 'object' && Array.isArray(record.sessionIds)) {
      return record.sessionIds.map(String)
    }
  } catch {
    /* 实体结构变化时退回公开 getter */
  }
  try {
    return Array.isArray(workspace.sessionIds) ? workspace.sessionIds.map(String) : []
  } catch {
    return []
  }
}

/**
 * 找出记账里包含该会话的所有工作区。
 * @param registry - Workspace 注册表服务。
 * @param sessionId - 会话 id。
 * @returns Workspace 实体数组。
 */
function ownersOf(registry, sessionId) {
  const owners = []
  if (registry === null) return owners
  try {
    for (const workspace of registry.list()) {
      if (rawSessionIds(workspace).includes(sessionId)) owners.push(workspace)
    }
  } catch (error) {
    console.error('[archive-manager] 枚举工作区记账失败：', error)
  }
  return owners
}

/**
 * 扫描磁盘上真实存在的会话 id 集合（`sessions/<slug>/<id>`）。
 * @returns 会话 id 的 Set。
 */
function diskSessionIds() {
  const ids = new Set()
  const root = sessionsRoot()
  let entries
  try {
    entries = readdirSync(root, { withFileTypes: true })
  } catch {
    return ids
  }
  let scanned = 0
  for (const entry of entries) {
    if (!entry.isDirectory()) continue
    let children
    try {
      children = readdirSync(join(root, entry.name), { withFileTypes: true })
    } catch {
      continue
    }
    for (const child of children) {
      if (++scanned > MAX_SESSION_SCAN) return ids
      if (child.isDirectory()) ids.add(child.name)
    }
  }
  return ids
}

/**
 * 清理「记账里有、磁盘上已经没有、也不在归档集合里」的失效引用。
 *
 * 这些引用是历史删除操作留下的幽灵：不含任何会话内容，却会让侧边栏继续列出
 * 一个点不开的会话。启动时自动跑一次，设置页也可以手动触发。
 * @param ctx - 插件上下文。
 * @returns `{ ok, repaired, workspaces }`
 */
async function repairOrphans(ctx) {
  const snapshot = snapshotRegistry(ctx)
  const registry = snapshot.registry
  if (registry === null) return { ok: false, repaired: 0, workspaces: 0 }
  const archived = new Set(snapshot.archivedSessionIds)
  const onDisk = diskSessionIds()
  let repaired = 0
  let workspaces = 0
  for (const workspace of registry.list()) {
    const orphans = rawSessionIds(workspace).filter((id) => !archived.has(id) && !onDisk.has(id))
    if (orphans.length === 0) continue
    workspaces += 1
    for (const id of orphans) {
      try {
        await workspace.detachSession(id)
        repaired += 1
      } catch (error) {
        console.error(`[archive-manager] 清理失效记账失败（${workspace.id}/${id}）：`, error)
      }
    }
  }
  if (repaired > 0) {
    console.info(`[archive-manager] 已清理 ${repaired} 条失效的会话记账（覆盖 ${workspaces} 个工作区）`)
  }
  return { ok: true, repaired, workspaces }
}

/**
 * 恢复一个归档会话：只从注册表的归档集合里摘掉 id，记账位置本来就还在。
 * @param ctx - 插件上下文。
 * @param sessionId - 会话 id。
 * @returns `{ status, body }`
 */
async function restoreSession(ctx, sessionId) {
  const snapshot = snapshotRegistry(ctx)
  const registry = snapshot.registry
  if (registry === null) {
    return { status: 503, body: { ok: false, error: 'registry-unavailable', message: 'Workspace 注册表尚未就绪，请稍后重试。' } }
  }
  if (!snapshot.archivedSessionIds.includes(sessionId)) {
    return { status: 404, body: { ok: false, error: 'not-archived', message: '该会话当前不在归档列表中。' } }
  }
  await registry.unarchiveSession(sessionId)
  forgetSnapshots([sessionId])
  return {
    status: 200,
    body: {
      ok: true,
      sessionId,
      archivedSessionIds: Array.isArray(registry.archivedSessionIds) ? [...registry.archivedSessionIds] : [],
    },
  }
}

/**
 * 永久删除一个会话的全部本地痕迹。
 *
 * 上一版的 BUG 就出在这里，三条关键约束别再改回去：
 *  ① 删除的语义是「把这个会话的本地存储彻底抹掉」，而不是「从归档集合里摘一个 id」。
 *     因此**不要求**它当前还在归档集合里——用户完全可能先恢复、再回来删除；
 *     旧实现会在这一步直接 404，于是文件没删、记账没清，界面上却像是操作过了。
 *  ② 磁盘痕迹（会话目录 + 投影缓存）先删；任何一个删不掉就整体失败，不摘任何记账，
 *     避免出现「记账没了、文件还在」或反过来的半吊子状态。
 *  ③ 成功后必须做满三件事：从每个记账工作区 `detachSession`、从归档集合移除、清归档时间索引。
 *     缺了 detach，侧边栏就会一直挂着一个点不开的幽灵会话——这正是主人看到的工作区残留。
 *
 * @param ctx - 插件上下文。
 * @param sessionId - 会话 id。
 * @returns `{ status, body }`
 */
async function deleteSession(ctx, sessionId) {
  const snapshot = snapshotRegistry(ctx)
  const registry = snapshot.registry
  if (registry === null) {
    return { status: 503, body: { ok: false, error: 'registry-unavailable', message: 'Workspace 注册表尚未就绪，请稍后重试。' } }
  }

  const artifacts = collectArtifacts(sessionId)
  const owners = ownersOf(registry, sessionId)
  const archived = snapshot.archivedSessionIds.includes(sessionId)

  if (artifacts.length === 0 && owners.length === 0 && !archived) {
    return {
      status: 404,
      body: {
        ok: false,
        error: 'session-not-found',
        message: '本地已经找不到该会话的任何痕迹，它可能已经被删除过了。',
      },
    }
  }

  const probe = await probeActivity(ctx, sessionId)
  if (probe.ok === false) {
    return {
      status: 503,
      body: {
        ok: false,
        error: 'activity-probe-failed',
        message: '无法确认该会话是否仍在运行，已取消删除。请稍后重试。',
      },
    }
  }
  if (probe.activity.length > 0) {
    return {
      status: 409,
      body: {
        ok: false,
        error: 'session-active',
        message: '该会话还有工作在运行，无法删除。请先让它停止后再试。',
        activity: probe.activity.map((entry) => (typeof entry === 'object' && entry !== null ? entry.kind ?? 'activity' : String(entry))),
      },
    }
  }

  // ② 先把「活在线上的这一份」收掉，再动磁盘。
  //    会话可能还开在某个客户端里：`session/list` 会合并 `ctx.sessions.list()` 的 live 行，
  //    不摘掉它，前端刷新多少次都会把这一行拉回来，点开还能看内存里的内容，发消息则写盘失败（ENOENT）。
  const liveSession = liveSessionOf(ctx, sessionId)
  let detachedLive = false
  if (liveSession !== null) {
    const stopped = await stopSessionActivity(ctx, sessionId)
    if (stopped === false) {
      return {
        status: 503,
        body: {
          ok: false,
          error: 'session-stop-failed',
          message: '无法停止该会话正在运行的工作，已取消删除。请稍后重试或先手动结束它。',
        },
      }
    }
    await sleep(120)
    detachedLive = detachLiveSession(ctx, liveSession)
    // 给 session/disposed 的各个 owner 一点收敛时间，避免它们在文件删掉之后才去落盘。
    if (detachedLive) await sleep(180)
  }

  const removed = []
  const failed = []
  for (const path of artifacts) {
    try {
      rmSync(path, { recursive: true, force: true, maxRetries: 5, retryDelay: 80 })
      removed.push(path)
    } catch (error) {
      failed.push({ path, error: error instanceof Error ? error.message : String(error) })
    }
  }

  if (failed.length > 0) {
    console.error('[archive-manager] 删除会话存储失败：', sessionId, failed)
    return {
      status: 500,
      body: {
        ok: false,
        error: 'delete-failed',
        message: '部分存储文件删除失败，会话与它的记账都保持原样。请关闭正在占用该文件的程序后重试。',
        removedCount: removed.length,
        failed: failed.map((entry) => ({ name: basename(entry.path), error: entry.error })),
      },
    }
  }

  // ② 工作区记账：这是上一版漏掉的一步。
  const detached = []
  for (const workspace of owners) {
    try {
      await workspace.detachSession(sessionId)
      detached.push(String(workspace.id ?? ''))
    } catch (error) {
      console.error(`[archive-manager] 从工作区记账移除失败（${workspace.id}/${sessionId}）：`, error)
    }
  }

  // ③ 归档集合：不在这条集合里的会话（例如刚恢复过的）不需要这一步。
  let archivedSessionIds = [...snapshot.archivedSessionIds]
  if (archived) {
    try {
      await registry.unarchiveSession(sessionId)
      archivedSessionIds = Array.isArray(registry.archivedSessionIds)
        ? [...registry.archivedSessionIds]
        : archivedSessionIds.filter((id) => id !== sessionId)
    } catch (error) {
      console.error('[archive-manager] 从归档集合移除失败：', error)
      archivedSessionIds = archivedSessionIds.filter((id) => id !== sessionId)
    }
  }

  forgetSnapshots([sessionId])
  return {
    status: 200,
    body: {
      ok: true,
      sessionId,
      removedCount: removed.length,
      detached,
      detachedLive,
      // 诊断字段：删除时这台 Host 是否能把 live 会话摘掉（排查「删了界面还在」时先看它）。
      probe: {
        sessionStore: (() => {
          try {
            return ctx.sessions !== undefined && ctx.sessions !== null && typeof ctx.sessions.get === 'function'
          } catch {
            return false
          }
        })(),
        liveAtDelete: liveSession !== null,
      },
      archivedSessionIds,
      message:
        removed.length === 0
          ? '本地已没有该会话的存储文件，已清除它的工作区记账与归档引用。'
          : '会话的本地存储文件、工作区记账与归档引用已全部清除。',
    },
  }
}

// ---------------------------------------------------------------------------
// 自动更新 + Star 引导（完全自包含：只用 GitHub 公开 API 与本机 git/tar，
// 不依赖任何其它插件，也不被任何其它插件依赖）
// ---------------------------------------------------------------------------

/** 插件自身目录（host.js 所在目录）。 */
const SELF_DIR = dirname(fileURLToPath(import.meta.url))

/** 更新检查缓存有效期：6 小时（与页面「自动检查：每 6 小时」一致）。 */
const UPDATE_TTL_MS = 6 * 60 * 60 * 1000

/** Star 按钮只允许打开这些域名。 */
const EXTERNAL_HOSTS = new Set(['github.com', 'www.github.com'])

/** 升级覆盖时要保留的东西：仓库元信息、依赖、用户数据、备份。 */
const UPDATE_SKIP = new Set(['.git', 'node_modules', 'var', '.backup', '.DS_Store', '.gitattributes'])

/**
 * 本进程启动时加载的版本（写死在内存里，升级磁盘后不会变）。
 * 与磁盘版本不一致 ⇒ 已更新但需要重启，页面据此提示。
 */
const RUNTIME_VERSION = (() => {
  try {
    const manifest = JSON.parse(readFileSync(join(SELF_DIR, 'package.json'), 'utf8'))
    return typeof manifest.version === 'string' ? manifest.version : '0.0.0'
  } catch {
    return '0.0.0'
  }
})()

/** 更新检查的内存缓存（每个 Host 进程一份）。 */
const updateState = {
  checkedAt: 0,
  repoSlug: null,
  latestTag: null,
  latestVersion: null,
  error: null,
  message: null,
}

/**
 * 读自己的 package.json。
 * @returns 解析后的清单，失败返回 null。
 */
function readSelfManifest() {
  try {
    return JSON.parse(readFileSync(join(SELF_DIR, 'package.json'), 'utf8'))
  } catch {
    return null
  }
}

/**
 * 磁盘上的版本（每次现读，升级后会变）。
 * @returns 版本字符串。
 */
function diskVersion() {
  const manifest = readSelfManifest()
  return manifest !== null && typeof manifest.version === 'string' ? manifest.version : RUNTIME_VERSION
}

/**
 * 从 package.json 的 repository 字段解析 GitHub 仓库。
 * 占位符（YOUR_GITHUB_USER 之类）视为「没有更新源」。
 * @returns `{ owner, repo, slug, htmlUrl }` 或 null。
 */
function resolveUpdateRepo() {
  const manifest = readSelfManifest()
  if (manifest === null) return null
  const raw = manifest.repository
  const url = typeof raw === 'string' ? raw : typeof raw?.url === 'string' ? raw.url : null
  if (url === null) return null
  const match = /github\.com[/:]([^/\s]+)\/([^/#\s]+)/i.exec(url)
  if (match === null) return null
  const owner = match[1]
  const repo = match[2].replace(/\.git$/i, '').replace(/[.,;]+$/, '')
  if (/^(your[_-]?github[_-]?user|your[_-]?name|owner|user|example)$/i.test(owner)) return null
  return { owner, repo, slug: `${owner}/${repo}`, htmlUrl: `https://github.com/${owner}/${repo}` }
}

/**
 * 解析版本号（允许 `v` 前缀与预发布后缀）。
 * @param value - 版本字符串。
 * @returns `{ parts, pre }` 或 null。
 */
function parseVersion(value) {
  const match = /^v?(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/.exec(String(value ?? '').trim())
  if (match === null) return null
  return { parts: [Number(match[1]), Number(match[2]), Number(match[3])], pre: match[4] ?? '' }
}

/**
 * 比较两个版本号。
 * @param left - 左版本。
 * @param right - 右版本。
 * @returns 负数 / 0 / 正数。
 */
function compareVersions(left, right) {
  const a = parseVersion(left)
  const b = parseVersion(right)
  if (a === null || b === null) return 0
  for (let index = 0; index < 3; index += 1) {
    if (a.parts[index] !== b.parts[index]) return a.parts[index] - b.parts[index]
  }
  if (a.pre === b.pre) return 0
  if (a.pre === '') return 1
  if (b.pre === '') return -1
  return a.pre < b.pre ? -1 : 1
}

/**
 * 问 GitHub 要仓库里最新的 semver tag。
 * @param repo - `{ slug }`。
 * @returns `{ tag, version }` 或 null。
 */
async function fetchLatestTag(repo) {
  const response = await fetch(`https://api.github.com/repos/${repo.slug}/tags?per_page=100`, {
    headers: { accept: 'application/vnd.github+json', 'user-agent': `${name}/update-check` },
    signal: AbortSignal.timeout(12000),
  })
  if (!response.ok) throw new Error(`GitHub API ${response.status}`)
  const payload = await response.json()
  if (!Array.isArray(payload)) throw new Error('GitHub API：返回了非预期结构')
  let best = null
  for (const entry of payload) {
    const tag = typeof entry?.name === 'string' ? entry.name : ''
    if (parseVersion(tag) === null) continue
    if (best === null || compareVersions(tag, best.tag) > 0) best = { tag, version: tag.replace(/^v/i, '') }
  }
  return best
}

/**
 * 组装前端要的状态。
 * @param repo - 更新源（可为 null）。
 * @returns 状态对象。
 */
function updateStatus(repo) {
  const disk = diskVersion()
  const latest = updateState.latestVersion
  const baseline = compareVersions(disk, RUNTIME_VERSION) >= 0 ? disk : RUNTIME_VERSION
  return {
    ok: updateState.error === null,
    packageName: name,
    runtimeVersion: RUNTIME_VERSION,
    diskVersion: disk,
    latestVersion: latest,
    latestTag: updateState.latestTag,
    checkedAt: updateState.checkedAt > 0 ? new Date(updateState.checkedAt).toISOString() : null,
    ttlMs: UPDATE_TTL_MS,
    repo: repo?.slug ?? null,
    htmlUrl: repo?.htmlUrl ?? null,
    canSelfUpdate: repo !== null,
    updateAvailable: latest !== null && compareVersions(latest, baseline) > 0,
    restartRequired: compareVersions(disk, RUNTIME_VERSION) > 0,
    error: updateState.error,
    message: updateState.message,
  }
}

/**
 * 检查更新（默认走 6 小时缓存）。
 * @param force - 忽略缓存。
 * @returns 状态对象。
 */
async function checkUpdate(force) {
  const repo = resolveUpdateRepo()
  if (repo === null) {
    return {
      ...updateStatus(null),
      ok: false,
      canSelfUpdate: false,
      error: null,
      message: 'package.json 里还没有配置真实的 repository 地址，无法检查更新。',
    }
  }
  const fresh =
    updateState.checkedAt > 0 &&
    updateState.repoSlug === repo.slug &&
    Date.now() - updateState.checkedAt < UPDATE_TTL_MS
  if (fresh && force !== true) return updateStatus(repo)

  try {
    const latest = await fetchLatestTag(repo)
    updateState.checkedAt = Date.now()
    updateState.repoSlug = repo.slug
    updateState.latestTag = latest?.tag ?? null
    updateState.latestVersion = latest?.version ?? null
    updateState.error = null
    updateState.message = latest === null ? '仓库里还没有可用的版本 tag。' : null
  } catch (error) {
    updateState.checkedAt = Date.now()
    updateState.repoSlug = repo.slug
    updateState.error = error instanceof Error ? error.message : String(error)
    updateState.message = null
  }
  return updateStatus(repo)
}

/**
 * 跑一个外部命令（git / tar），不走 shell。
 * @param command - 可执行文件。
 * @param args - 参数。
 * @param cwd - 工作目录。
 * @returns `{ ok, code, stdout, stderr }`
 */
function runTool(command, args, cwd) {
  const result = spawnSync(command, args, {
    cwd,
    encoding: 'utf8',
    windowsHide: true,
    timeout: 120000,
    maxBuffer: 8 * 1024 * 1024,
  })
  return {
    ok: result.status === 0 && result.error === undefined,
    code: result.status,
    stdout: result.stdout ?? '',
    stderr: result.stderr ?? (result.error !== undefined ? String(result.error.message) : ''),
  }
}

/**
 * 递归复制目录树。
 * @param source - 源目录。
 * @param destination - 目标目录。
 * @param skip - 跳过的名字集合。
 * @returns 复制的文件数。
 */
function copyTree(source, destination, skip) {
  let count = 0
  const walk = (from, to) => {
    mkdirSync(to, { recursive: true })
    for (const entry of readdirSync(from, { withFileTypes: true })) {
      if (skip.has(entry.name)) continue
      const sourcePath = join(from, entry.name)
      const targetPath = join(to, entry.name)
      if (entry.isDirectory()) walk(sourcePath, targetPath)
      else if (entry.isFile()) {
        copyFileSync(sourcePath, targetPath)
        count += 1
      }
    }
  }
  walk(source, destination)
  return count
}

/**
 * 有 .git 时：fetch + checkout 到 tag（最干净，能保留仓库历史）。
 * @param directory - 插件目录。
 * @param tag - 目标 tag。
 * @returns `{ ok, method, error?, detail? }`
 */
function applyViaGit(directory, tag) {
  const fetched = runTool('git', ['fetch', '--tags', '--force', 'origin'], directory)
  if (!fetched.ok) return { ok: false, error: 'git-fetch-failed', detail: fetched.stderr.trim().slice(0, 400) }
  // 升级要的是 tag 的干净内容，而用户很可能改过 package.json（例如手填仓库地址）。
  // 直接 checkout 会因为「本地改动会被覆盖」而中止，这里先硬还原工作区——这是升级的既定语义：
  // 插件自己的源码以仓库为准，用户数据都在 var/ 与 .gitignore 之外，不会被这次还原碰到。
  const reset = runTool('git', ['reset', '--hard', 'HEAD'], directory)
  if (!reset.ok) return { ok: false, error: 'git-reset-failed', detail: reset.stderr.trim().slice(0, 400) }
  const checkout = runTool('git', ['checkout', '--detach', tag], directory)
  if (!checkout.ok) return { ok: false, error: 'git-checkout-failed', detail: checkout.stderr.trim().slice(0, 400) }
  return { ok: true, method: 'git' }
}

/**
 * 没有 .git 时：下载 tag 的源码包，覆盖插件文件（保留 .git / node_modules / var）。
 * @param directory - 插件目录。
 * @param repo - `{ slug }`。
 * @param tag - 目标 tag。
 * @returns `{ ok, method, files?, error?, detail? }`
 */
async function applyViaTarball(directory, repo, tag) {
  const staging = mkdtempSync(join(tmpdir(), 'archive-manager-update-'))
  try {
    const archivePath = join(staging, 'source.tar.gz')
    const url = `https://codeload.github.com/${repo.slug}/tar.gz/refs/tags/${encodeURIComponent(tag)}`
    const response = await fetch(url, {
      headers: { 'user-agent': `${name}/update` },
      signal: AbortSignal.timeout(60000),
    })
    if (!response.ok) return { ok: false, error: `download-failed-${response.status}` }
    writeFileSync(archivePath, Buffer.from(await response.arrayBuffer()))

    const extracted = runTool('tar', ['-xzf', archivePath, '-C', staging], staging)
    if (!extracted.ok) return { ok: false, error: 'extract-failed', detail: extracted.stderr.trim().slice(0, 400) }

    const root = readdirSync(staging, { withFileTypes: true }).find((entry) => entry.isDirectory())
    if (root === undefined) return { ok: false, error: 'empty-archive' }

    const files = copyTree(join(staging, root.name), directory, UPDATE_SKIP)
    return { ok: true, method: 'tarball', files }
  } finally {
    try {
      rmSync(staging, { recursive: true, force: true })
    } catch {
      /* 临时目录清不掉不影响升级结果 */
    }
  }
}

/**
 * 执行升级。
 * @returns 升级结果（含 restartRequired）。
 */
async function applyUpdate() {
  const status = await checkUpdate(true)
  if (status.canSelfUpdate !== true) {
    return { ok: false, error: 'no-update-source', message: status.message ?? '没有可用的更新源。' }
  }
  if (status.latestTag === null) {
    return { ok: false, error: 'no-release', message: status.message ?? '仓库里还没有可用的版本 tag。' }
  }
  if (!status.updateAvailable) {
    return {
      ok: true,
      alreadyLatest: true,
      from: status.diskVersion,
      to: status.latestVersion,
      restartRequired: status.restartRequired,
      method: 'none',
      message: status.restartRequired ? '代码已更新，重启 DSH 即可生效。' : '已经是最新版本。',
    }
  }
  const repo = resolveUpdateRepo()
  const hasGit = existsSync(join(SELF_DIR, '.git'))
  const result = hasGit ? applyViaGit(SELF_DIR, status.latestTag) : await applyViaTarball(SELF_DIR, repo, status.latestTag)
  return {
    ...result,
    from: status.diskVersion,
    to: status.latestVersion,
    // 升级只改磁盘：必须重启才能加载新代码，页面照实说明。
    restartRequired: result.ok === true,
  }
}

/**
 * 用系统默认浏览器打开 github.com 链接。
 * @param rawUrl - 目标地址。
 * @returns `{ ok, error? }`
 */
function openExternalUrl(rawUrl) {
  let parsed
  try {
    parsed = new URL(String(rawUrl))
  } catch {
    return { ok: false, error: 'bad-url' }
  }
  // 只允许 https + github.com：这个入口不接受任意 URL，避免被当成通用命令执行面。
  if (parsed.protocol !== 'https:' || !EXTERNAL_HOSTS.has(parsed.hostname)) {
    return { ok: false, error: 'unsupported-url' }
  }
  const command = process.platform === 'win32' ? 'cmd' : process.platform === 'darwin' ? 'open' : 'xdg-open'
  const args = process.platform === 'win32' ? ['/c', 'start', '', parsed.href] : [parsed.href]
  try {
    const child = spawn(command, args, { detached: true, stdio: 'ignore', windowsHide: true })
    child.unref()
    return { ok: true, url: parsed.href }
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) }
  }
}

// ---------------------------------------------------------------------------
// 插件入口
// ---------------------------------------------------------------------------

/**
 * 注册路由。
 * @param ctx - 插件上下文。
 */
export function apply(ctx) {
  /** 变更串行队列：恢复/删除共享同一把锁，避免并发写坏注册表或文件。 */
  let queue = Promise.resolve()
  /**
   * @template T
   * @param task - 要在队列里执行的任务。
   * @returns 任务结果。
   */
  const serial = (task) => {
    const run = queue.then(task, task)
    queue = run.catch(() => undefined)
    return run
  }

  const route = (kind, path, handler) =>
    ctx.effect(
      () => ctx.webServer.register({ kind, path, handler }),
      `archive-manager: ${kind} ${path}`,
    )

  const guard = (label, handler) => (req, res) => {
    void (async () => {
      try {
        await handler(req, res)
      } catch (error) {
        console.error(`[archive-manager] ${label} 处理失败：`, error)
        sendJson(res, 500, {
          ok: false,
          error: 'internal',
          message: error instanceof Error ? error.message : String(error),
        })
      }
    })()
  }

  route('exact', `${ROUTE}/ping`, guard('ping', async (req, res) => {
    const refusal = rejectNonLoopbackHost(req)
    if (refusal !== null) {
      sendJson(res, 403, { ok: false, error: 'host-not-allowed', reason: refusal })
      return
    }
    sendJson(res, 200, { ok: true, plugin: name })
  }))

  route('exact', `${ROUTE}/state`, guard('state', async (req, res) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      sendJson(res, 405, { ok: false, error: 'method-not-allowed' })
      return
    }
    const refusal = rejectUntrustedRequest(req)
    if (refusal !== null) {
      sendJson(res, 403, { ok: false, error: 'untrusted-request', reason: refusal })
      return
    }
    const state = await serial(() => buildState(ctx))
    sendJson(res, 200, state)
  }))

  route('exact', `${ROUTE}/restore`, guard('restore', async (req, res) => {
    if (req.method !== 'POST') {
      sendJson(res, 405, { ok: false, error: 'method-not-allowed' })
      return
    }
    const refusal = rejectUntrustedRequest(req)
    if (refusal !== null) {
      sendJson(res, 403, { ok: false, error: 'foreign-origin', reason: refusal })
      return
    }
    const parsed = await readJsonBody(req)
    if (!parsed.ok) {
      sendJson(res, 400, { ok: false, error: parsed.reason })
      return
    }
    const sessionId = sessionIdOf(parsed.value)
    if (sessionId === null) {
      sendJson(res, 400, { ok: false, error: 'invalid-session-id' })
      return
    }
    const outcome = await serial(() => restoreSession(ctx, sessionId))
    sendJson(res, outcome.status, outcome.body)
  }))

  route('exact', `${ROUTE}/delete`, guard('delete', async (req, res) => {
    if (req.method !== 'POST') {
      sendJson(res, 405, { ok: false, error: 'method-not-allowed' })
      return
    }
    const refusal = rejectUntrustedRequest(req)
    if (refusal !== null) {
      sendJson(res, 403, { ok: false, error: 'foreign-origin', reason: refusal })
      return
    }
    const parsed = await readJsonBody(req)
    if (!parsed.ok) {
      sendJson(res, 400, { ok: false, error: parsed.reason })
      return
    }
    const sessionId = sessionIdOf(parsed.value)
    if (sessionId === null) {
      sendJson(res, 400, { ok: false, error: 'invalid-session-id' })
      return
    }
    const outcome = await serial(() => deleteSession(ctx, sessionId))
    sendJson(res, outcome.status, outcome.body)
  }))

  // 清理历史删除操作留下的失效记账（幂等）。设置页与启动自检都走这里。
  route('exact', `${ROUTE}/repair`, guard('repair', async (req, res) => {
    if (req.method !== 'POST') {
      sendJson(res, 405, { ok: false, error: 'method-not-allowed' })
      return
    }
    const refusal = rejectUntrustedRequest(req)
    if (refusal !== null) {
      sendJson(res, 403, { ok: false, error: 'foreign-origin', reason: refusal })
      return
    }
    const result = await serial(() => repairOrphans(ctx))
    sendJson(res, result.ok ? 200 : 503, {
      ok: result.ok,
      repaired: result.repaired,
      workspaces: result.workspaces,
      message:
        result.ok === false
          ? 'Workspace 注册表尚未就绪，请稍后重试。'
          : result.repaired === 0
            ? '没有发现失效的会话引用。'
            : `已清理 ${result.repaired} 条失效的会话引用。`,
    })
  }))

  // 自动更新：检查 / 执行 / Star 引导。全部自包含，不碰其它插件。
  route('exact', `${ROUTE}/update/status`, guard('update-status', async (req, res) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      sendJson(res, 405, { ok: false, error: 'method-not-allowed' })
      return
    }
    const refusal = rejectUntrustedRequest(req)
    if (refusal !== null) {
      sendJson(res, 403, { ok: false, error: 'untrusted-request', reason: refusal })
      return
    }
    // ?force=1 绕过 6 小时缓存（页面的「检查更新」按钮用它）
    const force = /[?&]force=1\b/.test(req.url ?? '')
    const status = await checkUpdate(force)
    sendJson(res, 200, status)
  }))

  route('exact', `${ROUTE}/update/apply`, guard('update-apply', async (req, res) => {
    if (req.method !== 'POST') {
      sendJson(res, 405, { ok: false, error: 'method-not-allowed' })
      return
    }
    const refusal = rejectUntrustedRequest(req)
    if (refusal !== null) {
      sendJson(res, 403, { ok: false, error: 'untrusted-request', reason: refusal })
      return
    }
    // 升级会改写插件目录，和恢复/删除共享同一把串行锁，避免同时动磁盘。
    const result = await serial(() => applyUpdate())
    sendJson(res, result.ok === true ? 200 : 500, result)
  }))

  route('exact', `${ROUTE}/open-repo`, guard('open-repo', async (req, res) => {
    if (req.method !== 'POST') {
      sendJson(res, 405, { ok: false, error: 'method-not-allowed' })
      return
    }
    const refusal = rejectUntrustedRequest(req)
    if (refusal !== null) {
      sendJson(res, 403, { ok: false, error: 'untrusted-request', reason: refusal })
      return
    }
    // 目标只能来自 package.json 的 repository，不接受请求体里的 URL。
    const repo = resolveUpdateRepo()
    if (repo === null) {
      sendJson(res, 400, { ok: false, error: 'no-repository', message: '还没有配置仓库地址。' })
      return
    }
    const opened = openExternalUrl(repo.htmlUrl)
    sendJson(res, opened.ok ? 200 : 400, opened)
  }))

  // 启动自检：给注册表一点时间稳定，然后静默清一次幽灵记账。
  // 这一步是幂等的，正常情况下什么都不会做；它专治旧版本留下的残留。
  ctx.effect(() => {
    const timer = setTimeout(() => {
      void serial(() => repairOrphans(ctx))
        .then((result) => {
          if (result.ok === false) return
          if (result.repaired > 0) {
            console.info(`[archive-manager] 启动自检完成：清理了 ${result.repaired} 条失效会话记账`)
          }
        })
        .catch((error) => {
          console.error('[archive-manager] 启动自检失败（不影响其它功能）：', error)
        })
    }, 3000)
    if (typeof timer.unref === 'function') timer.unref()
    return () => clearTimeout(timer)
  }, 'archive-manager: startup orphan repair')

  console.info(`[archive-manager] 已注册路由 ${ROUTE}/*（home=${dshHome()}）`)
}