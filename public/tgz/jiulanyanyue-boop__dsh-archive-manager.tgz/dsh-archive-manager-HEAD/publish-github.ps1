<#
.SYNOPSIS
  把当前目录发布成一个可被 dsh「添加插件」直接安装的 GitHub 仓库。

.DESCRIPTION
  这个目录本身就是包根目录（package.json / cordis.patch.yml / host.js / client.js 都在根），
  推到 GitHub 后，在 dsh 里填仓库地址即可安装：

      https://github.com/<user>/dsh-archive-manager
      https://github.com/<user>/dsh-archive-manager#v1.1.0

  安全约束（与 codex 的安全审查对齐）：
   · 只 `git add` 显式白名单里的文件 —— 不会把 .env、日志、备份、测试数据顺手推上去。
   · 工作区里出现白名单外的改动时直接停下，要用 -AllowUnexpectedFiles 才继续。
   · 不覆盖已有的 origin；要改必须显式加 -ForceOrigin。
   · 只推当前版本对应的那个 tag，不 `push --tags`。
   · 只推 main 分支；当前不在 main 上时拒绝。

.EXAMPLE
  ./publish-github.ps1 -RepositoryUrl https://github.com/issuser/dsh-archive-manager
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)]
  [string]$RepositoryUrl,

  [string]$Tag = '',

  [switch]$SkipPush,

  [switch]$ForceOrigin,

  [switch]$AllowUnexpectedFiles
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

# 只有这些文件允许被提交 / 推送。新增文件时请显式加进来，别用 `git add -A`。
$whitelist = @(
  'host.js',
  'client.js',
  'cordis.patch.yml',
  'package.json',
  'README.md',
  'README.en.md',
  'LICENSE',
  '.gitignore',
  'plugin-icon.png',
  'publish-github.ps1'
)

function Fail($message) {
  Write-Host "ERROR: $message" -ForegroundColor Red
  exit 1
}

function Invoke-Git {
  param([string[]]$GitArgs)
  & git @GitArgs
  if ($LASTEXITCODE -ne 0) { Fail "git $($GitArgs -join ' ') 失败（退出码 $LASTEXITCODE）" }
}

function Get-StatusPaths {
  $lines = & git status --porcelain
  $paths = @()
  foreach ($line in $lines) {
    if ([string]::IsNullOrWhiteSpace($line)) { continue }
    $path = $line.Substring(3).Trim()
    if ($path -match ' -> (?<target>.+)$') { $path = $Matches['target'] }
    $paths += ($path.Trim('"') -replace '\\', '/')
  }
  return $paths
}

function Test-Whitelisted($path) {
  if ($whitelist -contains $path) { return $true }
  if ($path -match '^screenshots/[^/]+\.png$') { return $true }
  return $false
}

# 1) 解析 owner/repo（支持 https、ssh、github: 简写、裸 owner/repo）
$normalized = $RepositoryUrl.Trim()
$normalized = $normalized -replace '^git\+', '' -replace '\.git$', ''
$normalized = $normalized -replace '^github:', 'https://github.com/'
$normalized = $normalized -replace '^git@github\.com:', 'https://github.com/'
if ($normalized -match 'github\.com/(?<slug>[^/]+/[^/#]+)') {
  $slug = $Matches['slug']
} elseif ($normalized -match '^(?<slug>[^/]+/[^/]+)$') {
  $slug = $Matches['slug']
} else {
  Fail "无法从 '$RepositoryUrl' 解析出 owner/repo。请传 https://github.com/<user>/<repo> 形式。"
}
$httpsUrl = "https://github.com/$slug.git"
Write-Host "仓库：$slug" -ForegroundColor Cyan
Write-Host "地址：$httpsUrl" -ForegroundColor DarkGray

# 2) 替换 package.json 里的占位
$manifestPath = Join-Path $root 'package.json'
$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
$manifest.repository.url = "git+$httpsUrl"
$manifest.homepage = "https://github.com/$slug#readme"
$manifest.bugs.url = "https://github.com/$slug/issues"
$json = $manifest | ConvertTo-Json -Depth 10
# 必须写成无 BOM 的 UTF-8：dsh 读 package.json 用的是 JSON.parse，BOM 会让它直接解析失败。
[System.IO.File]::WriteAllText($manifestPath, $json, [System.Text.UTF8Encoding]::new($false))
Write-Host "已更新 package.json 的 repository / homepage / bugs" -ForegroundColor Green

$version = $manifest.version
if ([string]::IsNullOrWhiteSpace($Tag)) { $Tag = "v$version" }

# 3) 初始化 / 校验 / 提交 / tag
Push-Location $root
try {
  & git rev-parse --is-inside-work-tree *> $null
  if ($LASTEXITCODE -ne 0) {
    Invoke-Git -GitArgs @('init', '-b', 'main')
    Write-Host "已初始化 git 仓库（main）" -ForegroundColor Green
  }

  # 分支必须干净利落是 main，避免把功能分支的历史推上去。
  $branch = (& git rev-parse --abbrev-ref HEAD).Trim()
  if ($branch -ne 'main') {
    Fail "当前分支是 '$branch'，本脚本只发布 main。请先切到 main 再执行。"
  }

  # 工作区里出现白名单外的文件 → 停下（这正是不用 `git add -A` 的原因）
  $unexpected = @(Get-StatusPaths | Where-Object { -not (Test-Whitelisted $_) } | Sort-Object -Unique)
  if ($unexpected.Count -gt 0) {
    Write-Host "检测到白名单外的改动：" -ForegroundColor Yellow
    $unexpected | ForEach-Object { Write-Host "  - $_" -ForegroundColor Yellow }
    if (-not $AllowUnexpectedFiles) {
      Fail "拒绝提交。把它们加进 .gitignore、移出本目录，或确认后加 -AllowUnexpectedFiles 再跑。"
    }
    Write-Host "已按 -AllowUnexpectedFiles 继续，但这些文件不会被提交。" -ForegroundColor Yellow
  }

  # 只 add 白名单里真实存在的文件
  $files = @()
  foreach ($rel in $whitelist) {
    if (Test-Path -LiteralPath (Join-Path $root $rel)) { $files += $rel }
  }
  $shots = @(Get-ChildItem -LiteralPath (Join-Path $root 'screenshots') -Filter *.png -File -ErrorAction SilentlyContinue)
  foreach ($shot in $shots) { $files += "screenshots/$($shot.Name)" }
  if ($files.Count -eq 0) { Fail "白名单里的文件一个都不存在，检查目录是否搞错了。" }

  Invoke-Git -GitArgs (@('add', '--') + $files)

  & git diff --cached --quiet
  if ($LASTEXITCODE -eq 0) {
    Write-Host "没有需要提交的改动" -ForegroundColor Yellow
  } else {
    $staged = @(& git diff --cached --name-only)
    $stagedUnexpected = @($staged | Where-Object { $_ -and -not (Test-Whitelisted ($_ -replace '\\', '/')) })
    if ($stagedUnexpected.Count -gt 0) {
      Fail "暂存区里出现白名单外文件：$($stagedUnexpected -join ', ')"
    }
    Invoke-Git -GitArgs @('commit', '-m', "release: archive-manager $Tag")
    Write-Host "已提交（$($staged.Count) 个文件）" -ForegroundColor Green
  }

  & git rev-parse -q --verify "refs/tags/$Tag" *> $null
  if ($LASTEXITCODE -eq 0) {
    Write-Host "tag $Tag 已存在，跳过" -ForegroundColor Yellow
  } else {
    Invoke-Git -GitArgs @('tag', '-a', $Tag, '-m', "archive-manager $Tag")
    Write-Host "已打 tag $Tag" -ForegroundColor Green
  }

  if (-not $SkipPush) {
    $existing = & git remote get-url origin 2>$null
    if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($existing)) {
      if ($existing.Trim() -ne $httpsUrl) {
        if (-not $ForceOrigin) {
          Fail "origin 已指向 $($existing.Trim())。确认要改成 $httpsUrl 的话，加 -ForceOrigin 重跑。"
        }
        Invoke-Git -GitArgs @('remote', 'set-url', 'origin', $httpsUrl)
      }
    } else {
      Invoke-Git -GitArgs @('remote', 'add', 'origin', $httpsUrl)
    }

    Invoke-Git -GitArgs @('push', '-u', 'origin', 'main')
    # 只推当前版本这一个 tag，不碰本仓库里其它历史 tag。
    Invoke-Git -GitArgs @('push', 'origin', "refs/tags/$Tag")

    Write-Host ""
    Write-Host "完成。现在可以在 dsh 里安装：" -ForegroundColor Cyan
    Write-Host "  https://github.com/$slug" -ForegroundColor White
    Write-Host "  https://github.com/$slug#$Tag" -ForegroundColor White
  } else {
    Write-Host "已跳过推送（-SkipPush）。手动执行：git push -u origin main; git push origin refs/tags/$Tag" -ForegroundColor Yellow
  }
} finally {
  Pop-Location
}
