import { describe, expect, it } from 'vitest'
import {
  buildSystemPrompt,
  buildUserMessage,
  DEFAULT_MAX_CHARS,
  isUsableRoute,
  liveProviderIds,
  MAX_DEPTH,
  MAX_MAX_CHARS,
  MAX_PARENT_CHARS,
  MAX_TEXT_CHARS,
  MIN_MAX_CHARS,
  normalizeEffort,
  parseExplainRequest,
  resolveEffortForRoute,
  resolveModelRoute,
} from './explain.js'
import type { Context } from '@deepseek-ai/cordis'

describe('parseExplainRequest', () => {
  it('normalizes a minimal valid request', () => {
    expect(parseExplainRequest({ text: '  hello  ' })).toEqual({
      text: 'hello',
      parent: null,
      depth: 0,
      maxChars: DEFAULT_MAX_CHARS,
    })
  })

  it('rejects non-record bodies and missing text', () => {
    expect(() => parseExplainRequest(null)).toThrow(TypeError)
    expect(() => parseExplainRequest('text')).toThrow(TypeError)
    expect(() => parseExplainRequest({})).toThrow(/text is required/)
    expect(() => parseExplainRequest({ text: 42 })).toThrow(/text is required/)
  })

  it('rejects empty and over-long text', () => {
    expect(() => parseExplainRequest({ text: '   ' })).toThrow(/must not be empty/)
    expect(() => parseExplainRequest({ text: 'x'.repeat(MAX_TEXT_CHARS + 1) })).toThrow(
      /exceeds 4000 characters/,
    )
    // Exactly at the limit is fine.
    expect(parseExplainRequest({ text: 'x'.repeat(MAX_TEXT_CHARS) }).text.length).toBe(MAX_TEXT_CHARS)
  })

  it('clamps depth to [0, MAX_DEPTH]', () => {
    expect(parseExplainRequest({ text: 'a', depth: -5 }).depth).toBe(0)
    expect(parseExplainRequest({ text: 'a', depth: 2 }).depth).toBe(2)
    expect(parseExplainRequest({ text: 'a', depth: 99 }).depth).toBe(MAX_DEPTH)
    expect(parseExplainRequest({ text: 'a', depth: '2' }).depth).toBe(0) // non-number → 0
  })

  it('clamps maxChars to [MIN_MAX_CHARS, MAX_MAX_CHARS] with fallback', () => {
    expect(parseExplainRequest({ text: 'a', maxChars: 10 }).maxChars).toBe(MIN_MAX_CHARS)
    expect(parseExplainRequest({ text: 'a', maxChars: 5000 }).maxChars).toBe(MAX_MAX_CHARS)
    expect(parseExplainRequest({ text: 'a', maxChars: '300' }).maxChars).toBe(DEFAULT_MAX_CHARS)
    expect(parseExplainRequest({ text: 'a', maxChars: 150.6 }).maxChars).toBe(151)
  })

  it('validates and clips parent', () => {
    expect(() => parseExplainRequest({ text: 'a', parent: 'x' })).toThrow(/parent must be an object/)
    expect(() => parseExplainRequest({ text: 'a', parent: { text: 'x' } })).toThrow(/must be strings/)
    const long = 'y'.repeat(MAX_PARENT_CHARS + 10)
    const out = parseExplainRequest({ text: 'a', parent: { text: long, explanation: long } })
    expect(out.parent?.text.length).toBe(MAX_PARENT_CHARS + 1) // clipped + ellipsis
    expect(out.parent?.explanation.endsWith('…')).toBe(true)
  })
})

describe('buildSystemPrompt', () => {
  it('sets the length bound from maxChars and omits recursion context at depth 0', () => {
    const p = buildSystemPrompt(parseExplainRequest({ text: 'foo', maxChars: 150 }))
    expect(p).toContain('150 字以内')
    expect(p).not.toContain('父级解释全文')
    expect(p).not.toContain('<parent>')
  })

  it('never fences the selection with code-like quotes or classification bait', () => {
    // Regression: `"""` fences made the model answer "这是一个 python 字符串…"
    // instead of explaining the selection.
    const p = buildSystemPrompt(parseExplainRequest({ text: '要解释的东西' }))
    expect(p).not.toContain('"""')
    expect(p).toContain('不要判断它的编程语言类型')
    expect(p).toContain('<选中文字>')
  })

  it('adds recursion context for a follow-up level', () => {
    const req = parseExplainRequest({
      text: 'foo',
      depth: 3,
      parent: { text: 'outer', explanation: 'outer explanation' },
    })
    const p = buildSystemPrompt(req)
    expect(p).toContain('第 3 层递归追问')
    expect(p).toContain('<父级解释>outer explanation</父级解释>')
    expect(p).toContain('<选中文字>\nfoo\n</选中文字>')
    expect(p).not.toContain('"""')
  })
})

describe('buildUserMessage', () => {
  it('includes the parent text when present', () => {
    const msg = buildUserMessage(
      parseExplainRequest({ text: 'foo', parent: { text: 'outer', explanation: 'e' } }),
    )
    expect(msg).toContain('外层选中（父级）')
    expect(msg).toContain('outer')
    expect(msg).toContain('<选中文字>\nfoo\n</选中文字>')
    expect(msg).not.toContain('"""')
  })

  it('omits the parent block for top-level requests', () => {
    const msg = buildUserMessage(parseExplainRequest({ text: 'foo' }))
    expect(msg).not.toContain('外层选中')
    expect(msg).toContain('请解释下面 <选中文字> 标记之间的文字')
  })
})

describe('resolveModelRoute — independent model configuration', () => {
  function makeCtx(providers: { id: string }[] = [], selection?: unknown) {
    return {
      get: (key: string) => (key === 'agentDefaultModel' ? { currentSelection: () => selection } : undefined),
      llm: { listProviders: () => providers },
    } as unknown as Context
  }

  it('prefers an explicit override over the agent default selection', () => {
    const ctx = makeCtx([{ id: 'p-custom' }, { id: 'p-default' }], { provider: 'p-default', model: 'm-default' })
    expect(resolveModelRoute(ctx, undefined, { provider: 'p-custom', model: 'm-custom' })).toEqual({
      provider: 'p-custom',
      model: 'm-custom',
    })
  })

  it('ignores an override whose provider is no longer registered', () => {
    const ctx = makeCtx([{ id: 'p-default' }], { provider: 'p-default', model: 'm-default' })
    expect(resolveModelRoute(ctx, undefined, { provider: 'p-gone', model: 'm-custom' })).toEqual({
      provider: 'p-default',
      model: 'm-default',
    })
  })

  it('ignores a half-configured override', () => {
    const ctx = makeCtx([{ id: 'p-custom' }], { provider: 'p-default', model: 'm-default' })
    expect(resolveModelRoute(ctx, undefined, { provider: 'p-custom', model: '' })).toEqual({
      provider: 'p-default',
      model: 'm-default',
    })
  })

  it('falls back to the captured main-loop route when there is no override or selection', () => {
    const ctx = makeCtx([{ id: 'p-first' }])
    expect(resolveModelRoute(ctx, { provider: 'p-main', model: 'm-main' }, undefined)).toEqual({
      provider: 'p-main',
      model: 'm-main',
    })
  })
})

describe('isUsableRoute / liveProviderIds', () => {
  it('accepts only routes with both halves non-empty', () => {
    expect(isUsableRoute({ provider: 'p', model: 'm' })).toBe(true)
    expect(isUsableRoute({ provider: 'p', model: '' })).toBe(false)
    expect(isUsableRoute({ provider: '', model: 'm' })).toBe(false)
    expect(isUsableRoute(undefined)).toBe(false)
  })

  it('degrades to an empty list when the llm service throws', () => {
    const ctx = {
      llm: {
        listProviders: () => {
          throw new Error('boom')
        },
      },
    } as unknown as Context
    expect(liveProviderIds(ctx)).toEqual([])
  })
})

describe('resolveModelRoute', () => {
  function makeCtx(providers: { id: string }[] = [], selection?: unknown) {
    return {
      get: (key: string) => (key === 'agentDefaultModel' ? { currentSelection: () => selection } : undefined),
      llm: { listProviders: () => providers },
    } as unknown as Context
  }

  it('prefers the agent default selection', () => {
    const ctx = makeCtx([], { provider: 'p1', model: 'm1' })
    expect(resolveModelRoute(ctx)).toEqual({ provider: 'p1', model: 'm1' })
  })

  it('falls through when the default selection is malformed or throws', () => {
    const bad = makeCtx([], { provider: '', model: '' })
    expect(resolveModelRoute(bad, { provider: 'last', model: 'lm' })).toEqual({ provider: 'last', model: 'lm' })

    const throwing = {
      get: () => ({
        currentSelection: () => {
          throw new Error('boom')
        },
      }),
      llm: { listProviders: () => [] },
    } as unknown as Context
    expect(resolveModelRoute(throwing, { provider: 'last', model: 'lm' })).toEqual({
      provider: 'last',
      model: 'lm',
    })
  })

  it('uses the first registered provider as a fallback', () => {
    const ctx = makeCtx([{ id: 'provider-a' }, { id: 'provider-b' }])
    expect(resolveModelRoute(ctx)).toEqual({ provider: 'provider-a', model: 'deepseek-chat' })
  })

  it('throws when nothing is available', () => {
    expect(() => resolveModelRoute(makeCtx([]))).toThrow(/没有可用的 LLM 路由/)
  })
})

describe('normalizeEffort', () => {
  it('passes known ids through and defaults everything else', () => {
    for (const id of ['off', 'low', 'medium', 'high', 'max'] as const) {
      expect(normalizeEffort(id)).toBe(id)
    }
    expect(normalizeEffort('bogus')).toBe('off')
    expect(normalizeEffort(42)).toBe('off')
    expect(normalizeEffort(undefined)).toBe('off')
    expect(normalizeEffort(null)).toBe('off')
  })
})

describe('resolveEffortForRoute', () => {
  const efforts = (ids: string[]) => ids.map((id) => ({ id }))

  it('honors an exact declared match', () => {
    const deepseek = { reasoning: { efforts: efforts(['off', 'high', 'max']) } }
    expect(resolveEffortForRoute(deepseek, 'high')).toBe('high')
    expect(resolveEffortForRoute(deepseek, 'max')).toBe('max')
    expect(resolveEffortForRoute(deepseek, 'off')).toBe('off')
  })

  it('falls back to the strongest declared level not stronger than requested', () => {
    const deepseek = { reasoning: { efforts: efforts(['off', 'high', 'max']) } }
    expect(resolveEffortForRoute(deepseek, 'medium')).toBe('off')
    expect(resolveEffortForRoute(deepseek, 'low')).toBe('off')
    const openai = { reasoning: { efforts: efforts(['off', 'medium', 'high']) } }
    expect(resolveEffortForRoute(openai, 'low')).toBe('off')
    expect(resolveEffortForRoute(openai, 'max')).toBe('high')
  })

  it('uses the weakest declared level when every declared level is stronger', () => {
    const strongOnly = { reasoning: { efforts: efforts(['high', 'max']) } }
    expect(resolveEffortForRoute(strongOnly, 'low')).toBe('high')
  })

  it('returns undefined when no reasoning metadata or only unknown ids are declared', () => {
    expect(resolveEffortForRoute(undefined, 'high')).toBeUndefined()
    expect(resolveEffortForRoute({}, 'high')).toBeUndefined()
    expect(resolveEffortForRoute({ reasoning: { efforts: [] } }, 'high')).toBeUndefined()
    expect(resolveEffortForRoute({ reasoning: { efforts: efforts(['turbo', 'mega']) } }, 'high')).toBeUndefined()
  })
})
