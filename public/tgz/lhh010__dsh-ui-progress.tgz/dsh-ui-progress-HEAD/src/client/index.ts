/**
 * Task-progress plugin, browser half: the resident session-progress strip
 * (input dock). The strip derives live execution state from the Chat view
 * snapshot and the Session lifecycle snapshot — no model-facing tool
 * required; the report_progress toolview was removed in v0.8.0 (hosts that
 * provide the tool render their own surface).
 * Export discipline: packages/client/AGENTS.md — only the cordis apply
 * surface and contract types leave this package.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis'
// Type-only: pulls the locale plugin's Context merge (ctx.locale).
import type {} from '@deepseek-ai/dsh-client-locale/client'
// Type-only: pulls the Conversation service, input-dock SlotMap entry, and
// the SessionStandardProps useConversation merge.
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
// Type-only: pulls the Chat view snapshot types (legacy slice, TodoItem).
import type {} from '@deepseek-ai/dsh-client-ui-chat/client'
// Type-only: pulls the global useSessions/useSessionPendingInteraction seats.
import type {} from '@deepseek-ai/dsh-client-ui-session/client'
// Type-only: pulls the SessionSnapshot lifecycle contract.
import type {} from '@deepseek-ai/dsh-api-session-controller/client'
// Type-only: the `todos` SessionProjectionMap key merge (single source, the todo domain's pure outlet).
import type {} from '@deepseek-ai/dsh-tool-todo/client'
// Type-only: pulls the renderer-owned slots service (ctx.slots Context merge).
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import { SessionProgressBar } from './SessionProgressBar.tsx'
import { en, zh, type ProgressKey } from './locales.ts'
import { applyWithCompat } from './compat.ts'

export type { SessionProgressBarProps } from './SessionProgressBar.tsx'
export type { ProgressKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The progress surfaces' copy. */
    progress: ProgressKey
  }
}

/** Dictionary namespace owned by this plugin. */
const NS = 'progress'

/** Required services (cordis fiber inject): the slots registry and the locale seat. */
export const inject = ['slots', 'locale']

/**
 * Client plugin body: register the `progress` dictionaries and the resident
 * session-progress strip into the input dock. The dock slot is declared by
 * ui-conversation's apply; `slots.inject` waits on that declaration,
 * reruns after redeclaration, and rolls back with this plugin's fiber.
 * @param ctx - client root context.
 */
import { startUpdateChip } from './update-chip.ts'
import { setJobsServiceGetter } from './jobs-source.ts'

export function apply(ctx: ClientContext): void {
  startUpdateChip()
  // Background-job signal (optional service): resolved lazily so a later-mounting
  // jobs capability is still picked up; hosts without it read as zero jobs.
  setJobsServiceGetter(() => {
    // ctx.get(name) reads a service without the inject requirement and returns
    // undefined while its provider fiber is not active — exactly the optional
    // semantics this signal needs (property access requires inject).
    try { return ctx.get('jobs') as import('./jobs-source.ts').JobsServiceLike | undefined } catch { return undefined }
  })
  // Graceful compatibility: if the running DSH lacks the client APIs this
  // plugin needs (e.g. an older DSH without ctx.slots.inject), render a
  // remediation banner instead of throwing.
  applyWithCompat(
    '@dsh-external/dsh-ui-progress',
    '当前 DSH 客户端 API 与插件不匹配',
    [
      '将 DSH 升级到已适配的版本（dsh-v0.1.2-alpha.1，源码构建安装）。',
      '或将插件更新到适配当前 DSH 的版本（仓库最新 tag）。',
      '如仍显示，请在插件目录执行 pnpm run build 后刷新页面。',
    ],
    [
      ['slots.inject', ctx?.slots?.inject],
      ['slots.register', ctx?.slots?.register],
      ['locale.register', ctx?.locale?.register],
    ],
    () => {
      ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'ui-progress: dictionaries')

      ctx.slots.inject('conversation.input.dock', () => ctx.slots.register(
        { name: 'conversation.input.dock', id: 'progress', order: 20, locale: NS },
        SessionProgressBar,
      ))
    },
  )
}
