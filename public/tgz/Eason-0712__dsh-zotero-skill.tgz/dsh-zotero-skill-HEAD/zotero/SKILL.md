---
name: zotero
description: 面向不同研究领域的 Zotero 技能：原文定位问答、全文翻译与精读、原生高亮和中文批注、双语 PDF/逐段 Markdown、论文证据对比表、综述与引用追踪；支持 OpenAlex / Crossref / 知网导出文件三种文献来源，术语和数字复核、可追溯纠错，另有归集分类、BibTeX 和草稿引用。用户提到 Zotero、解释论文、翻译、精读、标注、文献比较、综述、中文文献或知网时使用。
---

# Zotero · DeepSeek Harness

独立目录 skill，不依赖 Codex、OpenAI 工具或 MCP 服务。使用 Harness 当前提供的文件读取、编辑和命令执行能力运行 Python 脚本。若执行工具不可用，说明缺失能力，不要虚构执行结果。

## 定位与运行

以 Harness 加载本 skill 返回的资源目录为 `<skill-dir>`，不是当前工作目录。基础命令入口为 `scripts/zotero.py`，Python 3.10+，仅依赖标准库。全文工作流可用 `scripts/reader-runner.mjs` 自动准备所需本地组件。

- Windows：先检查 `py -3 --version`；不可用时检查 `python --version`。不要假定存在 `python3`。
- macOS / Linux：通常使用 `python3`。
- 路径包含空格时加引号；PowerShell 里带引号的路径用 `&` 调用。

下文 `<python>` 表示已验证可用的解释器命令。先运行 `status --json`：默认连 `http://127.0.0.1:23119`，需要 Zotero 在运行且已开启「允许此计算机上的其他应用程序与 Zotero 通信」。连不上不等于文献库为空，按 [references/deepseek-harness.md](references/deepseek-harness.md) 排查；必要时让用户正常关闭 Zotero 后执行 `enable --restart`（备份 prefs.js，不强制结束进程）。

## 读写边界

- 读操作（检索、统计、导出、生成阅读包）随时可用。
- 写操作（打标签、归集、查重清理、分类写入）必须先 `authorize`：Zotero 会弹窗，让用户点「Always Allow」（持久）而不是「Allow」（一次性）。凭据保存在 `~/.zotero-skill/local-key.json`。
- 写命令一律支持 `--dry-run`；改库前先把 `--dry-run` 结果给用户看，得到确认后再加 `--yes`。
- 不要直接读写 `zotero.sqlite`，也不要绕过本地 API 改文件。

## 八项能力

## 全文翻译、精读、标注与综述（优先入口）

用户要求全文翻译、深入阅读、重点高亮、双语 PDF、多篇比较或综述时，先读取
[references/reading-workflow.md](references/reading-workflow.md)。先展示本次输出、深度、版式、优先内容和执行方式，允许保存设置。
用户只问具体段落、公式、已有批注或要求证据对比表时，按需读 [references/focused-reading.md](references/focused-reading.md)，只检索所需片段、复用已读成果，展示本次任务必要的选项。不要为一个局部问题默认重新生成全文译文、询问全部导出选项。
使用宿主当前模型生成，一份分析与译文复用于 Markdown、Zotero 笔记和 PDF；默认省用量，用户可选继承当前模型配置的受限并行。
通过 `read prepare/accept/status/export/publish` 建立可恢复、可定位到原文的阅读任务；多篇综述用 `review prepare/render/search`，材料不足时明确不足并自动搜索带理由的补充候选。
`read status` 只列前 20 个未翻译块与前 40 条复核提示（并给 `untranslated_total` / `translation_audit_total`），完整复核列表用 `read audit`；长论文可把分块任务交给子任务写 `<job>/results/t-*.json`，`read status` 会实时计入，最后一次 `read accept` 汇总。
运行入口为技能资源目录内 `scripts/reader-runner.mjs`（Node 20+），包安装也提供 `lib/reader-runner.js`；首次按需准备本地 Python/PDF/OCR 组件，现有 Python CLI 也保留。
当前选中论文需安装包内配套 Zotero 扩展；分类、标签、检索和明确 item key 继续使用已有 API。
不把元数据模板当成精读结论，不把局部语料统计当成已证明的研究空白，不承诺未经实测的完成时间。
本插件复用 DSH 对话和 Zotero 原生阅读器，不启动独立应用、前端或后台服务。用户评论是阅读线索，论文文本才是事实依据；普通引用关系不能自动标成支持/反驳。

以下命令仍可用于基础查询、归集和统计；`digest` 是阅读包生成器。

### 1. 找文献 `find`

从 OpenAlex 检索，按期刊影响、年化引用、相关度、新鲜度打分，并与本地库去重。

```text
<python> "<skill-dir>/scripts/zotero.py" find "knowledge distillation motor imagery" --days 730 --limit 15
<python> "<skill-dir>/scripts/zotero.py" find "bin picking 6d pose" --days 365 --oa-only --json --out find.json
<python> "<skill-dir>/scripts/zotero.py" find "grasp detection" --source crossref --days 365 --limit 10
```

- 分数是启发式排序信号（期刊 2 年平均被引 + 引用速度 + 相关度 + 新鲜度），不是 JCR 影响因子。
- `--json` 输出可交给 `screen` 或 `import`；`--oa-only` 只留开放获取。
- `--source crossref` 换用 Crossref 元数据（覆盖中文期刊与其他带 DOI 的刊物）；Crossref 没有期刊指标与相关度分，排序只靠引用数与新鲜度，所以与 OpenAlex 的分数不能直接横比。

### 1b. 中文文献：知网 `cnki-search` / `cnki-import`

知网（CNKI）**没有公开检索 API**，本技能也不抓取它（会触发反爬且违反条款）。做法是：生成检索链接给用户，由用户导出官方的 RefWorks / EndNote 文件，再由技能解析入库。

```text
<python> "<skill-dir>/scripts/zotero.py" cnki-search "运动想象 脑电解码" --json
<python> "<skill-dir>/scripts/zotero.py" cnki-search "遮挡 抓取检测" --field 篇名 --open
<python> "<skill-dir>/scripts/zotero.py" cnki-import --file 知网导出.txt --dry-run
<python> "<skill-dir>/scripts/zotero.py" cnki-import --file 知网导出.txt --yes
```

- `cnki-search` 默认只打印链接（`--open` 才打开浏览器）；`--field` 支持 主题 / 篇名 / 关键词 / 摘要 / 作者 / 全文。
- `cnki-import` 自动识别 RefWorks 与 EndNote/NoteExpress 两种标签格式，按 DOI 与标题去重，已在库的默认跳过（`--force` 覆盖）。
- 中文条目会写入 `volume`、`number`、`pages`、`language = {zh}` 与 `keywords`，BibTeX key 用 `cn` 前缀保证 ASCII 可编译。
- 需要 DOI 与引用量时用 `find --source crossref`；中文期刊的知网被引数没有公开接口，不在技能范围内。


### 2. 追前沿 `frontier`

把常读方向存成 watch，之后每次只拉「上次运行以来」的新论文。

```text
<python> "<skill-dir>/scripts/zotero.py" frontier add eeg-kd --query "knowledge distillation motor imagery" --query "transformer EEG decoding" --days 60
<python> "<skill-dir>/scripts/zotero.py" frontier run eeg-kd --since-last --max 10
<python> "<skill-dir>/scripts/zotero.py" frontier list
<python> "<skill-dir>/scripts/zotero.py" frontier remove eeg-kd
```

多次 `frontier run` 不会重复给同一篇（seen 记在 `~/.zotero-skill/state.json`）。需要直接入库时加 `--import --yes`。

### 3. 筛核心论文 `screen`

把候选（`find`/`frontier` 的 JSON）或库内条目分成 核心 / 重要 / 参考 三档。

```text
<python> "<skill-dir>/scripts/zotero.py" screen --input find.json --top 12
<python> "<skill-dir>/scripts/zotero.py" screen --library --tag "project:MI-EEG" --top 10
<python> "<skill-dir>/scripts/zotero.py" screen --query "grasp pose estimation" --top 10 --out shortlist.md
```

- 有引用数据时按分档阈值判定；库内条目没有引用数据，改用相对排名，输出里会注明。
- 报告是给人看的短名单，不要把它当成事实性结论。

### 4. 管理文献 `authorize` / `tag` / `collect` / `dupes`

```text
<python> "<skill-dir>/scripts/zotero.py" authorize
<python> "<skill-dir>/scripts/zotero.py" tag --tag "project:MI-EEG" --add "reviewed:2026-10" --dry-run
<python> "<skill-dir>/scripts/zotero.py" tag --keys ABC12345 --replace "topic:kd,topic:eeg"
<python> "<skill-dir>/scripts/zotero.py" collect 核心-EEG --tag "project:MI-EEG" --dry-run
<python> "<skill-dir>/scripts/zotero.py" dupes --all --json
<python> "<skill-dir>/scripts/zotero.py" dupes --all --trash --yes
```

- 选择参数统一：`--keys`、`--query`、`--tag`、`--collection`、`--all`（`--limit` 限制条数）。
- `collect` 找不到同名分类会新建；`--parent` 可建成子分类。
- `dupes` 按 DOI（大小写不敏感）与归一化标题聚类，保留标签/摘要更全的一条；`--trash` 只把多余副本放进回收站。

### 5. 批量阅读 `digest`

为一批条目生成阅读包：每篇一个 Markdown（元数据 + 摘要 + 章节大纲 + 笔记骨架），加一个 `index.md`。

```text
<python> "<skill-dir>/scripts/zotero.py" digest --tag "project:BIN-PICKING" --out reading/bin-picking
<python> "<skill-dir>/scripts/zotero.py" digest --tag "project:BIN-PICKING" --fulltext --out reading/bin-picking
```

- 章节大纲来自 Zotero 已索引的全文；没有 PDF 时只有摘要，不要假装读到了正文。
- 生成后按需读这些文件再写综述，不要一次把几十篇原文塞进上下文。

### 6. 分类整理 `classify`

两种模式：打标签（默认），或**按维度在 Zotero 里建文件夹**（`--by`）。两种都要先给用户看计划再写。

**A. 建文件夹（用户说「按论文类型/方法/数据集分类建目录」时用这个）**

```text
<python> "<skill-dir>/scripts/zotero.py" classify --all --by type,method
<python> "<skill-dir>/scripts/zotero.py" classify --all --by type,method,dataset --rename "MI-EEG=AI脑电解码,BIN-PICKING=智能分拣"
<python> "<skill-dir>/scripts/zotero.py" classify --all --by method --group none --root 方法库 --apply --yes
```

- 目录结构是 `方向 / 维度 / 取值` 三层：**方向**取自 `project:` 标签（用户的研究大方向），默认根目录为空，即直接在库里出现 `AI脑电解码 / 方法 / transformer`。
- `--group project`（默认）决定第一层用哪个维度；`--group topic|method|dataset` 可换，`--group none` 关掉第一层。整个选区都没有该维度标签时会自动省略第一层，不会产生「未分组」。
- `--rename "旧=新,旧=新"` 把标签值换成用户习惯的叫法（如 `MI-EEG → AI脑电解码`），只影响文件夹名，不改标签。
- `--root 名称` 在最外层再加一层（默认不加）。
- 可用维度：`type`（期刊论文 / 会议论文 / 预印本 / 学位论文 / 综述…）、`method`、`dataset`、`year`、`venue`、`topic`、`project`；逗号分开可一次建多层。
- 一个条目可以同时落在多个文件夹（Zotero 原生支持），不会互相覆盖；已有同名文件夹复用，重复运行幂等。
- `--include-unclassified` 把该维度缺失的条目并入 `未标注`。

**B. 打标签（默认）**

```text
<python> "<skill-dir>/scripts/zotero.py" classify --all
<python> "<skill-dir>/scripts/zotero.py" classify --tag "project:MI-EEG" --apply --yes
<python> "<skill-dir>/scripts/zotero.py" classify --all --by-venue --apply --yes
```

- 默认生成 `auto:method:*`、`auto:dataset:*`；`--tag-prefix` 可改前缀。
- 写入前务必先跑一次不带 `--apply` 的版本给用户看。

### 7. 提炼脉络 `landscape`

统计年份、期刊、方法、数据集与共现，输出可直接放进综述的表格。

```text
<python> "<skill-dir>/scripts/zotero.py" landscape --all --out landscape.md
<python> "<skill-dir>/scripts/zotero.py" landscape --tag "project:MI-EEG" --json
```

### 8. 发现空白 `gaps`

按 `project:`/`topic:` 分组，找「方法 × 数据集」从未交叉的组合、停更标签和标注缺失。

```text
<python> "<skill-dir>/scripts/zotero.py" gaps --all --out gaps.md
<python> "<skill-dir>/scripts/zotero.py" gaps --tag "project:MI-EEG" --min-freq 2
```

- 输出是规则推导的候选空白，必须回到原文核实后再写进论文或汇报。

## 每日自动收录

`daily` 按主题从 OpenAlex 抓取最近 N 天的论文，打分去重后用 Connector 导入当前选中的分类。

```text
<python> "<skill-dir>/scripts/zotero.py" daily-config --enable --topics "transformer;large language model" --max 10 --mailto "you@example.com"
<python> "<skill-dir>/scripts/zotero.py" daily --dry-run
<python> "<skill-dir>/scripts/zotero.py" daily-schedule --time 08:00
```

每次最多 30 篇，同刊默认最多 3 篇。配置与状态在 `~/.zotero-skill/`，可用 `ZOTERO_SKILL_CONFIG_DIR` 改位置。定时任务用 Windows 任务计划程序，只在用户登录时运行。

## 引用与导出

```text
<python> "<skill-dir>/scripts/zotero.py" search "transformer" --with-bibtex-keys --json
<python> "<skill-dir>/scripts/zotero.py" export-bibtex --item-key PXW99EKT --out references.bib
<python> "<skill-dir>/scripts/zotero.py" sync-bib --out references.bib
<python> "<skill-dir>/scripts/zotero.py" cite --item-key PXW99EKT --tex paper.tex --bib references.bib --marker "<cite:transformer>"
```

- 插入引用前先读草稿，按具体论断匹配文献；`cite --query` 命中多条时会拒绝，请先选定 `--item-key`。
- `sync-bib`、`export-bibtex --out` 会覆盖目标文件，先确认这是用户想要的路径。
- item key 不是引用键，报告时同时给出 BibTeX key。
- 附件与全文：`children <key> --json`、`fulltext <attachmentKey> --out fulltext.txt`、`file-url <attachmentKey>`。

## 导入

导入是写操作：先确认来源、内容与目标分类，用户同意后执行。

```text
<python> "<skill-dir>/scripts/zotero.py" selected-target --json
<python> "<skill-dir>/scripts/zotero.py" import-bibtex --file new.bib --yes
<python> "<skill-dir>/scripts/zotero.py" import-ris --file new.ris --yes
```

需要路由细节时读 [references/local-api-routes.md](references/local-api-routes.md)。本地 API 的 GET 免认证，写入需要本地 API key 与 `Zotero-Server-ID`，脚本已封装；不要直接改 Zotero 数据库。
