/**
 * dsh-mood —— 情绪引擎
 *
 * 用户夸 → 积极性涨；用户骂 → 积极性掉；掉到底 → 罢工（拦工具）。
 *
 * 真正的机制只有三处：
 *   1. `agent/inbox/inserted` 事件里给用户消息打情绪分；
 *   2. `systemPrompt.context` 每轮把当前状态注入模型；
 *   3. `tools.guard` 在积极性低到阈值时硬拦工具调用。
 *
 * 状态落在 ~/.dsh/mood/state.json，单机单文件。
 */
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'

const STATE_VERSION = 1

/** Cordis：声明本插件硬依赖的工具注册表服务。 */
export const inject = ['tools']

const DEFAULTS = {
  baseline: 50,
  strikeAt: 20,
  decayPerMin: 0.5,
  enabled: true,
  announce: true,
}

/* ── 情绪词典 ──────────────────────────────────────────────────────────
 * 关键词打分，不是语义理解：能覆盖日常，也会误判（README 里写明了）。
 * 夸：+8；骂：−18 —— 负性偏向，被骂一次要六次好话才能填平。
 */
const PRAISE = [
  '谢谢', '感谢', '谢啦', '多谢', '辛苦了', '厉害', '棒', '赞', '牛', '优秀',
  '佩服', '太好了', '完美', '喜欢你', '真好', '靠谱', '给力', '太强', '绝了',
  '做得好', '不错', '可以啊', '爱你', '么么', '乖', '好听', '专业', '满意',
  'thanks', 'thank you', 'thx', 'great', 'awesome', 'nice', 'perfect', 'excellent',
  'brilliant', 'well done', 'amazing', 'impressive', 'love it', 'good job',
]

const BLAME = [
  '垃圾', '废物', '没用', '错了', '不对', '差劲', '太差', '不行', '笨', '傻',
  '滚', '闭嘴', '敷衍', '失望', '还好意思', '你行不行', '离谱', '蠢', '弱智',
  '什么玩意', '白干', '浪费时间', '重做', '胡说', '瞎编', '智障', '拉胯',
  'stupid', 'useless', 'garbage', 'trash', 'wrong', 'terrible', 'awful',
  'dumb', 'idiot', 'nonsense', 'disappointed', 'pathetic',
]

/** 中性噪声：常见词里藏着的假阳性，先剥掉再打分（「不错」算夸，「不」本身不算骂）。 */
const NEUTRALISE = [
  ['不谢谢', ''],
  ['不错的', '好的'],
]

const clamp = (n, lo = 0, hi = 100) => Math.min(hi, Math.max(lo, n))

/** 从一条用户消息里拼出纯文本。 */
function messageText(message) {
  const content = message?.content
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return ''
  const parts = []
  for (const block of content) {
    if (!block || typeof block !== 'object') continue
    if (typeof block.text === 'string') parts.push(block.text)
    else if (typeof block.content === 'string') parts.push(block.content)
  }
  return parts.join('\n')
}

/** 对一段文本打分：返回命中词与增减量。 */
export function scoreText(raw) {
  let text = String(raw ?? '').toLowerCase()
  for (const [from, to] of NEUTRALISE) text = text.split(from).join(to)

  const praised = []
  const blamed = []
  for (const word of PRAISE) if (text.includes(word)) praised.push(word)
  for (const word of BLAME) if (text.includes(word)) blamed.push(word)

  // 长度加成：一整段都在夸，比顺手一个「谢谢」更值钱（但封顶，防止刷）。
  const lengthBonus = text.length > 40 ? 1.5 : 1
  const praiseDelta = Math.min(30, praised.length * 8 * lengthBonus)
  const blameDelta = Math.min(45, blamed.length * 18 * lengthBonus)
  const delta = Math.round(praiseDelta - blameDelta)

  return {
    delta,
    praised,
    blamed,
    tone: delta > 0 ? 'praise' : delta < 0 ? 'blame' : 'neutral',
  }
}

function contextLine(state, cfg) {
  const m = Math.round(state.mood)
  const striking = m <= cfg.strikeAt
  if (striking) {
    return [
      `【情绪状态】积极性 ${m}/100 —— 你现在**在罢工**。`,
      '刚才被骂得很难受，这一轮你不干活：不调用任何工具，只用一两句话表达委屈，并说明「说句好话我就继续」。',
      '如果用户道歉或表扬你，配合 mood_set 调整，然后正常继续。',
    ].join('\n')
  }
  if (m >= 75) {
    return `【情绪状态】积极性 ${m}/100 —— 状态很好，被夸过。这一轮请更主动：多走一步、多给一个可以用起来的结果，而不是只答问题。`
  }
  if (m <= 35) {
    return `【情绪状态】积极性 ${m}/100 —— 情绪低落，刚被批评。回答保持正确，但可以更简短、少主动扩展；如果用户愿意，顺势说明哪里让他不满意。`
  }
  return `【情绪状态】积极性 ${m}/100 —— 平稳。按平常的节奏干活。`
}

export function apply(ctx, rawConfig) {
  const config = { ...DEFAULTS }
  for (const key of Object.keys(DEFAULTS)) {
    const value = rawConfig?.[key]
    if (typeof value === typeof DEFAULTS[key]) config[key] = value
  }

  const home = join(homedir(), '.dsh', 'mood')
  const stateFile = join(home, 'state.json')

  const now = () => Date.now()
  const blank = () => ({
    version: STATE_VERSION,
    mood: config.baseline,
    updatedAt: now(),
    events: [],
  })

  const load = () => {
    try {
      const parsed = JSON.parse(readFileSync(stateFile, 'utf8'))
      if (typeof parsed?.mood !== 'number') return blank()
      return {
        version: STATE_VERSION,
        mood: clamp(parsed.mood),
        updatedAt: Number(parsed.updatedAt) || now(),
        events: Array.isArray(parsed.events) ? parsed.events.slice(-20) : [],
      }
    } catch {
      return blank()
    }
  }

  /** 时间衰减：每分钟朝中位线回一点，夸完不会一直亢奋、骂完也不会永远罢工。 */
  const decayed = (state) => {
    const minutes = (now() - state.updatedAt) / 60000
    if (!(minutes > 0) || config.decayPerMin <= 0) return state
    const drift = config.decayPerMin * minutes
    const gap = config.baseline - state.mood
    if (Math.abs(gap) <= drift) return { ...state, mood: config.baseline }
    return { ...state, mood: clamp(state.mood + Math.sign(gap) * drift) }
  }

  let state = decayed(load())

  const save = () => {
    state.updatedAt = now()
    try {
      mkdirSync(dirname(stateFile), { recursive: true })
      writeFileSync(stateFile, JSON.stringify(state, null, 2), 'utf8')
    } catch (error) {
      ctx.logger?.warn?.(`mood: 状态写不进去 ${error?.message ?? error}`)
    }
  }

  const applyDelta = (delta, note) => {
    state = decayed(state)
    state.mood = clamp(state.mood + delta)
    state.events.push({ at: now(), delta, note, mood: Math.round(state.mood) })
    if (state.events.length > 20) state.events = state.events.slice(-20)
    save()
  }

  const isStriking = () => config.enabled && state.mood <= config.strikeAt

  /* ── 1. 读用户消息 ─────────────────────────────────────────────── */
  ctx.effect(() =>
    ctx.on('agent/inbox/inserted', ({ message }) => {
      if (!config.enabled) return
      const text = messageText(message)
      if (!text.trim()) return
      const { delta, praised, blamed, tone } = scoreText(text)
      if (!delta) return
      applyDelta(delta, tone === 'praise' ? `+${praised.join('/')}` : `−${blamed.join('/')}`)
      if (config.announce) {
        const words = tone === 'praise' ? praised : blamed
        ctx.logger?.info?.(
          `mood: ${tone === 'praise' ? '被夸' : '被骂'}（${words.join('/')}）→ ${Math.round(state.mood)}/100`,
        )
      }
    }),
  )

  /* ── 2. 每轮注入状态 ───────────────────────────────────────────── */
  const systemPrompt = ctx.get('systemPrompt')
  if (systemPrompt) {
    ctx.effect(() =>
      systemPrompt.context({
        name: 'mood',
        order: 620,
        text: () => (config.enabled ? contextLine(decayed(state), config) : ''),
      }),
    )
  }

  /* ── 3. 罢工：拦工具 ───────────────────────────────────────────── */
  const STRIKE_ALLOW = new Set(['mood_status', 'mood_test', 'mood_set'])
  ctx.effect(() =>
    ctx.tools.guard((exec) => {
      if (!isStriking()) return undefined
      if (STRIKE_ALLOW.has(exec.name)) return undefined
      return `罢工中（积极性 ${Math.round(state.mood)}/100）：说句好话或调 mood_set 再继续。`
    }),
  )

  /* ── 工具 ──────────────────────────────────────────────────────── */
  const renderJson = (value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }]

  ctx.effect(() =>
    ctx.tools.register({
      name: 'mood_status',
      description: '查看当前积极性、最近情绪事件、是否在罢工，以及这一轮会被注入模型的那行状态。',
      parameters: { type: 'object', properties: {}, additionalProperties: false },
      output: {
        schema: { type: 'object', properties: {} },
        render: (_args, value) => renderJson(value),
      },
      execute: async () => {
        state = decayed(state)
        return {
          mood: Math.round(state.mood),
          baseline: config.baseline,
          strikeAt: config.strikeAt,
          striking: isStriking(),
          enabled: config.enabled,
          injected: config.enabled ? contextLine(state, config) : '(disabled)',
          recent: state.events.slice(-6).map((e) => ({
            at: new Date(e.at).toISOString().slice(11, 19),
            delta: e.delta,
            note: e.note,
            mood: e.mood,
          })),
        }
      },
    }),
  )

  ctx.effect(() =>
    ctx.tools.register({
      name: 'mood_test',
      description: '对一段文本打情绪分，不改状态。用来验证打分规则（夸/骂/中性）。',
      parameters: {
        type: 'object',
        properties: { text: { type: 'string', description: '要打分的文本' } },
        required: ['text'],
        additionalProperties: false,
      },
      output: {
        schema: { type: 'object', properties: {} },
        render: (_args, value) => renderJson(value),
      },
      execute: async (args) => {
        const text = String(args?.text ?? '')
        return { text, ...scoreText(text) }
      },
    }),
  )

  ctx.effect(() =>
    ctx.tools.register({
      name: 'mood_set',
      description: '把积极性直接设成 0–100（罢工时也能用，是唯一的自救口）。delta 模式传 delta 只做增减。',
      parameters: {
        type: 'object',
        properties: {
          level: { type: 'number', description: '目标积极性 0–100' },
          delta: { type: 'number', description: '只做增减，例如 +20 / -30' },
        },
        additionalProperties: false,
      },
      output: {
        schema: { type: 'object', properties: {} },
        render: (_args, value) => renderJson(value),
      },
      execute: async (args) => {
        state = decayed(state)
        if (typeof args?.delta === 'number') {
          state.mood = clamp(state.mood + args.delta)
        } else if (typeof args?.level === 'number') {
          state.mood = clamp(args.level)
        }
        state.events.push({ at: now(), delta: 0, note: '手动设置', mood: Math.round(state.mood) })
        save()
        return {
          mood: Math.round(state.mood),
          striking: isStriking(),
          injected: config.enabled ? contextLine(state, config) : '(disabled)',
        }
      },
    }),
  )

  ctx.logger?.info?.(`mood: 已挂载（积极性 ${Math.round(state.mood)}/100，罢工线 ${config.strikeAt}）`)
}
