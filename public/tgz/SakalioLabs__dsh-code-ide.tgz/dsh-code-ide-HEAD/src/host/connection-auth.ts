import type { IncomingMessage } from 'node:http'
import type { HostConnection, HostPluginContext } from './contracts.js'
import { isTrustedLocalRequest } from './trust.js'

function hasRequestRejection(value: unknown): value is HostConnection {
  return typeof value === 'object' && value !== null
    && typeof (value as { requestRejection?: unknown }).requestRejection === 'function'
}

/**
 * Use the newer Host's browser-auth fence when available. Older Harness
 * versions do not provide Connection, so retain the original loopback fence.
 */
export function requestRejection(
  ctx: Pick<HostPluginContext, 'get'>,
  request: IncomingMessage,
): 401 | 403 | undefined {
  const connection = ctx.get?.('connection')
  if (hasRequestRejection(connection)) return connection.requestRejection(request)
  return isTrustedLocalRequest(request) ? undefined : 403
}

/** Project an authentication rejection without exposing host-auth details. */
export function rejectionMessage(status: 401 | 403): string {
  return status === 401 ? 'Unauthorized' : 'Forbidden'
}
