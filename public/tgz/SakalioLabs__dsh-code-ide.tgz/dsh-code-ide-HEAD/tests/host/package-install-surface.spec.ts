import { access, readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { describe, expect, it } from 'vitest'

const repositoryRoot = resolve(import.meta.dirname, '..', '..')

describe('Git install surface', () => {
  it('does not define lifecycle scripts that build on a user machine', async () => {
    const manifest = JSON.parse(await readFile(resolve(repositoryRoot, 'package.json'), 'utf8')) as {
      scripts?: Record<string, string>
    }
    const lifecycleScripts = ['prepare', 'prepack', 'preinstall', 'install', 'postinstall']

    expect(lifecycleScripts.filter(name => Object.hasOwn(manifest.scripts ?? {}, name))).toEqual([])
  })

  it('injects only client modules still provided by the alpha Harness client graph', async () => {
    const manifest = JSON.parse(await readFile(resolve(repositoryRoot, 'package.json'), 'utf8')) as {
      dsh?: { client?: { inject?: string[] } }
    }

    expect(manifest.dsh?.client?.inject).toEqual([
      '@deepseek-ai/dsh-client-ui-conversation',
      '@deepseek-ai/dsh-client-locale',
    ])
  })

  it('reuses the Harness-owned Cordis and PTY peers without adding duplicate native dependencies', async () => {
    const manifest = JSON.parse(await readFile(resolve(repositoryRoot, 'package.json'), 'utf8')) as {
      peerDependencies?: Record<string, string>
      peerDependenciesMeta?: Record<string, { optional?: boolean }>
    }

    expect(manifest.peerDependencies?.['@deepseek-ai/cordis']).toBe('>=4.0.1-rc.1 <5')
    expect(manifest.peerDependencies?.['node-pty']).toBe('1.1.0 || 1.2.0-beta.15')
    expect(manifest.peerDependenciesMeta?.['@deepseek-ai/cordis']?.optional).toBe(true)
    expect(manifest.peerDependenciesMeta?.['node-pty']?.optional).toBe(true)
  })

  it('ships every entry point required by a source-based Harness install', async () => {
    await Promise.all([
      'dist/host/index.js',
      'dist/client/index.html',
      'dist/harness-client/client.js',
      'cordis.patch.yml',
    ].map(path => access(resolve(repositoryRoot, path))))
  })
})
