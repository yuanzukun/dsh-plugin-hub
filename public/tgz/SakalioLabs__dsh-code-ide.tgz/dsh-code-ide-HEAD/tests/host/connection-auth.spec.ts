import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import type { Duplex } from 'node:stream'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import {
  TERMINAL_CAPABILITY,
  WORKSPACE_FILES_CAPABILITY,
  WORKSPACE_MUTATIONS_CAPABILITY,
  WORKSPACE_SEARCH_CAPABILITY,
  type IdeGatewayContext,
  type WorkspaceMutationsGatewayContext,
} from '../../src/host/capabilities.js'
import type { HostWebRoute, HostWebServer, HostWebUpgradeRoute } from '../../src/host/contracts.js'
import { ideGateway } from '../../src/host/gateway.js'
import { workspaceMutationsGateway } from '../../src/host/workspace-mutations-gateway.js'

class CapturingWebServer implements HostWebServer {
  readonly routes: HostWebRoute[] = []
  readonly upgrades: HostWebUpgradeRoute[] = []

  register(route: HostWebRoute): () => void {
    this.routes.push(route)
    return () => {
      const index = this.routes.indexOf(route)
      if (index >= 0) this.routes.splice(index, 1)
    }
  }

  registerUpgrade(route: HostWebUpgradeRoute): () => void {
    this.upgrades.push(route)
    return () => {
      const index = this.upgrades.indexOf(route)
      if (index >= 0) this.upgrades.splice(index, 1)
    }
  }
}

function request(url: string, headers: Record<string, string>): IncomingMessage {
  return { url, headers } as IncomingMessage
}

function capturedResponse(): {
  readonly response: ServerResponse
  readonly writeHead: ReturnType<typeof vi.fn>
  readonly end: ReturnType<typeof vi.fn>
} {
  const writeHead = vi.fn()
  const end = vi.fn()
  return { response: { writeHead, end } as unknown as ServerResponse, writeHead, end }
}

function logger() {
  return { warn() {}, error() {}, info() {}, debug() {} }
}

describe('Harness Connection authentication bridge', () => {
  let staticRoot: string

  beforeEach(async () => {
    staticRoot = await mkdtemp(join(tmpdir(), 'dsh-code-ide-connection-auth-'))
    await writeFile(join(staticRoot, 'index.html'), '<!doctype html>')
  })

  afterEach(async () => {
    await rm(staticRoot, { recursive: true, force: true, maxRetries: 3 })
  })

  it('uses the alpha Connection fence for custom HTTP, WebSocket, and mutation routes', async () => {
    const webServer = new CapturingWebServer()
    const connection = { requestRejection: vi.fn((): 401 => 401) }
    const get = vi.fn((): unknown => connection)
    const terminal = { upgrade: vi.fn() }
    const mutations = { request: vi.fn() }
    const effect = (execute: () => unknown): void => { void execute() }
    const ideContext = {
      logger: logger(),
      get,
      effect,
      webServer,
      [WORKSPACE_FILES_CAPABILITY]: {},
      [WORKSPACE_SEARCH_CAPABILITY]: {},
      [TERMINAL_CAPABILITY]: terminal,
    } as unknown as IdeGatewayContext
    const mutationsContext = {
      logger: logger(),
      get,
      effect,
      webServer,
      [WORKSPACE_MUTATIONS_CAPABILITY]: mutations,
    } as unknown as WorkspaceMutationsGatewayContext
    ideGateway(ideContext, {
      routePrefix: '/dsh-code-ide',
      staticRoot,
      maxRequestBytes: 1024,
      maxTerminalSessions: 1,
    })
    workspaceMutationsGateway(mutationsContext, { maxRequestBytes: 1024 })

    const httpRoute = webServer.routes.find(route => route.kind === 'prefix')
    const mutationRoute = webServer.routes.find(route => route.kind === 'exact')
    const upgradeRoute = webServer.upgrades[0]
    expect(httpRoute).toBeDefined()
    expect(mutationRoute).toBeDefined()
    expect(upgradeRoute).toBeDefined()

    const http = capturedResponse()
    const httpRequest = request('/dsh-code-ide/terminal', { host: '127.0.0.1:3080' })
    await httpRoute!.handler(httpRequest, http.response)
    expect(http.writeHead).toHaveBeenCalledWith(401, expect.any(Object))
    expect(JSON.parse(String(http.end.mock.calls[0]?.[0]))).toEqual({
      error: { code: 'UNAUTHORIZED', message: 'Unauthorized' },
    })

    const socket = { end: vi.fn() } as unknown as Duplex
    const upgradeRequest = request('/dsh-code-ide/terminal?workspaceId=fixture', { host: '127.0.0.1:3080' })
    await upgradeRoute!.handler(upgradeRequest, socket, Buffer.alloc(0))
    expect(socket.end).toHaveBeenCalledWith(expect.stringContaining('HTTP/1.1 401 Unauthorized'))
    expect(terminal.upgrade).not.toHaveBeenCalled()

    const mutation = capturedResponse()
    const mutationRequest = request('/dsh-code-ide/api/workspace-mutations/v1', { host: '127.0.0.1:3080' })
    await mutationRoute!.handler(mutationRequest, mutation.response)
    expect(mutation.writeHead).toHaveBeenCalledWith(401, expect.any(Object))
    expect(mutations.request).not.toHaveBeenCalled()
    expect(connection.requestRejection).toHaveBeenNthCalledWith(1, httpRequest)
    expect(connection.requestRejection).toHaveBeenNthCalledWith(2, upgradeRequest)
    expect(connection.requestRejection).toHaveBeenNthCalledWith(3, mutationRequest)
    expect(get).toHaveBeenCalledTimes(3)
  })

  it('keeps the rc.2 loopback fallback when Connection is unavailable', async () => {
    const webServer = new CapturingWebServer()
    const get = vi.fn((): undefined => undefined)
    const terminal = { upgrade: vi.fn() }
    const ideContext = {
      logger: logger(),
      get,
      effect: (execute: () => unknown): void => { void execute() },
      webServer,
      [WORKSPACE_FILES_CAPABILITY]: {},
      [WORKSPACE_SEARCH_CAPABILITY]: {},
      [TERMINAL_CAPABILITY]: terminal,
    } as unknown as IdeGatewayContext
    ideGateway(ideContext, {
      routePrefix: '/dsh-code-ide',
      staticRoot,
      maxRequestBytes: 1024,
      maxTerminalSessions: 1,
    })
    const httpRoute = webServer.routes[0]
    const upgradeRoute = webServer.upgrades[0]
    expect(httpRoute).toBeDefined()
    expect(upgradeRoute).toBeDefined()
    const headers = { host: '127.0.0.1:3080', 'sec-fetch-site': 'same-origin' }

    const http = capturedResponse()
    await httpRoute!.handler(request('/dsh-code-ide/terminal', headers), http.response)
    expect(http.writeHead).toHaveBeenCalledWith(426, { connection: 'Upgrade', upgrade: 'websocket' })

    const socket = { end: vi.fn() } as unknown as Duplex
    const upgradeRequest = request('/dsh-code-ide/terminal?workspaceId=fixture', headers)
    await upgradeRoute!.handler(upgradeRequest, socket, Buffer.alloc(0))
    expect(terminal.upgrade).toHaveBeenCalledWith(upgradeRequest, socket, expect.any(Buffer))
    expect(socket.end).not.toHaveBeenCalled()
  })
})
