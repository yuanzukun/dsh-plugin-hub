/** Tests for the host-side favicon fetcher (background task with 3s timeout,
 *  https→http fallback, per-host in-memory caching, concurrent dedupe and
 *  the user-maintained `assets/.favicon` disk cache). */
import { afterAll, describe, expect, it, vi } from 'vitest'
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import {
  createFaviconFetcher,
  FAVICON_TIMEOUT_MS,
  isValidHostname,
  type FaviconFetcher,
  type FaviconFetcherOptions,
} from '../src/host/favicon.ts'

const TEST_ROOT = '.favicon-test'
const BYTES = new Uint8Array([0, 1, 2, 3])

afterAll(async () => {
  await rm(TEST_ROOT, { recursive: true, force: true })
})

function imageResponse(
  type = 'image/x-icon',
  body: Uint8Array = BYTES,
  status = 200,
): Response {
  return new Response(body, { status, headers: { 'content-type': type } })
}

/** Fetcher with persistence disabled by default (tests stay hermetic). */
function makeFetcher(
  fetchImpl: typeof fetch,
  extra?: Omit<FaviconFetcherOptions, 'fetchImpl'>,
): FaviconFetcher {
  return createFaviconFetcher({ fetchImpl, cacheDir: null, ...extra })
}

describe('isValidHostname', () => {
  it('accepts DNS-shaped hostnames (incl. punycode and IPv4)', () => {
    expect(isValidHostname('deepseek.com')).toBe(true)
    expect(isValidHostname('en.wikipedia.org')).toBe(true)
    expect(isValidHostname('xn--bcher-kva.example')).toBe(true)
    expect(isValidHostname('127.0.0.1')).toBe(true)
    expect(isValidHostname('a')).toBe(true)
  })

  it('rejects schemas, ports, userinfo, paths and whitespace', () => {
    expect(isValidHostname('https://deepseek.com')).toBe(false)
    expect(isValidHostname('deepseek.com:8080')).toBe(false)
    expect(isValidHostname('user@deepseek.com')).toBe(false)
    expect(isValidHostname('deepseek.com/path')).toBe(false)
    expect(isValidHostname('deep seek.com')).toBe(false)
    expect(isValidHostname('-deepseek.com')).toBe(false)
    expect(isValidHostname('')).toBe(false)
  })
})

describe('createFaviconFetcher (network path)', () => {
  it('fetches exactly https://<host>/favicon.ico on success', async () => {
    const fetchImpl = vi.fn(async (url: string) => imageResponse('image/x-icon', new Uint8Array([1, 2, 3])))
    const fetcher = makeFetcher(fetchImpl as unknown as typeof fetch)

    const result = await fetcher.fetchFavicon('deepseek.com')

    expect(result).not.toBeNull()
    expect(Array.from(result!.body)).toEqual([1, 2, 3])
    expect(result!.type).toMatch(/^image\//)
    expect(fetchImpl).toHaveBeenCalledTimes(1)
    expect(fetchImpl.mock.calls[0][0]).toBe('https://deepseek.com/favicon.ico')
  })

  it('sends a browser-like user-agent (some WAFs reject custom agents)', async () => {
    const fetchImpl = vi.fn(async () => imageResponse())
    const fetcher = makeFetcher(fetchImpl as unknown as typeof fetch)

    await fetcher.fetchFavicon('ua.example')

    const init = fetchImpl.mock.calls[0][1] as RequestInit
    const ua = (init.headers as Record<string, string>)['user-agent'] ?? ''
    expect(ua).toContain('Mozilla/5.0')
  })

  it('falls back to http when https fails', async () => {
    const fetchImpl = vi.fn(async (url: string) => {
      if (url.startsWith('https://')) return new Response(null, { status: 404 })
      return imageResponse()
    })
    const fetcher = makeFetcher(fetchImpl as unknown as typeof fetch)

    const result = await fetcher.fetchFavicon('example.org')

    expect(result).not.toBeNull()
    expect(fetchImpl).toHaveBeenCalledTimes(2)
    expect(fetchImpl.mock.calls[1][0]).toBe('http://example.org/favicon.ico')
  })

  it('returns null when both schemes fail', async () => {
    const fetchImpl = vi.fn(async () => new Response(null, { status: 404 }))
    const fetcher = makeFetcher(fetchImpl as unknown as typeof fetch)

    expect(await fetcher.fetchFavicon('nope.invalid')).toBeNull()
    expect(fetchImpl).toHaveBeenCalledTimes(2)
  })

  it('rejects 200 responses whose content-type is not an image', async () => {
    const fetchImpl = vi.fn(
      async () => new Response('<html>404 page</html>', { status: 200, headers: { 'content-type': 'text/html' } }),
    )
    const fetcher = makeFetcher(fetchImpl as unknown as typeof fetch)

    expect(await fetcher.fetchFavicon('html.example')).toBeNull()
    expect(fetchImpl).toHaveBeenCalledTimes(2) // https + http attempts
  })

  it('rejects svg favicons (would break the disk cache)', async () => {
    const fetchImpl = vi.fn(async () => imageResponse('image/svg+xml'))
    const fetcher = makeFetcher(fetchImpl as unknown as typeof fetch)

    expect(await fetcher.fetchFavicon('svg.example')).toBeNull()
    expect(fetchImpl).toHaveBeenCalledTimes(2)
  })

  it('skips the http fallback once the 3s budget is spent', async () => {
    let t = 0
    const fetchImpl = vi.fn(async (url: string) => {
      // Pretend this https attempt consumed the whole budget.
      t = 9999
      return new Response(null, { status: 404 })
    })
    const fetcher = makeFetcher(fetchImpl as unknown as typeof fetch, { now: () => t })

    expect(await fetcher.fetchFavicon('slow.example')).toBeNull()
    expect(fetchImpl).toHaveBeenCalledTimes(1) // no http fallback after budget spent
  })

  it('serves cached successes without refetching', async () => {
    const fetchImpl = vi.fn(async () => imageResponse())
    const fetcher = makeFetcher(fetchImpl as unknown as typeof fetch)

    await fetcher.fetchFavicon('cached.example')
    const second = await fetcher.fetchFavicon('cached.example')

    expect(second).not.toBeNull()
    expect(fetchImpl).toHaveBeenCalledTimes(1)
  })

  it('negative-caches failures within the TTL', async () => {
    const fetchImpl = vi.fn(async () => new Response(null, { status: 404 }))
    const fetcher = makeFetcher(fetchImpl as unknown as typeof fetch)

    await fetcher.fetchFavicon('dead.example')
    await fetcher.fetchFavicon('dead.example')

    // First call: https + http. Second call: served from the negative cache.
    expect(fetchImpl).toHaveBeenCalledTimes(2)
  })

  it('dedupes concurrent requests for the same host', async () => {
    let release: (r: Response) => void = () => {}
    const fetchImpl = vi.fn(
      () => new Promise<Response>((resolve) => { release = resolve }),
    )
    const fetcher = makeFetcher(fetchImpl as unknown as typeof fetch)

    const a = fetcher.fetchFavicon('same.example')
    const b = fetcher.fetchFavicon('same.example')
    // The shared task reaches the network only after its async prelude
    // (store init + disk lookup); wait until fetchImpl is actually called.
    await vi.waitFor(() => expect(fetchImpl).toHaveBeenCalledTimes(1))
    release(imageResponse())
    const [ra, rb] = await Promise.all([a, b])

    expect(ra).not.toBeNull()
    expect(rb).not.toBeNull()
    expect(fetchImpl).toHaveBeenCalledTimes(1)
  })
})

describe('createFaviconFetcher (disk persistence)', () => {
  async function freshDir(name: string): Promise<string> {
    const dir = `${TEST_ROOT}/${name}`
    await rm(dir, { recursive: true, force: true })
    await mkdir(dir, { recursive: true })
    return dir
  }

  it('persists a fetched icon: index.json maps host → <12-hex>.ico', async () => {
    const dir = await freshDir('persist')
    const fetchImpl = vi.fn(async () => imageResponse('image/x-icon', new Uint8Array([9, 8, 7])))
    const fetcher = createFaviconFetcher({ fetchImpl: fetchImpl as unknown as typeof fetch, cacheDir: dir })

    const result = await fetcher.fetchFavicon('deepseek.com')

    expect(result).not.toBeNull()
    const rawIndex = await readFile(`${dir}/index.json`)
    const index = JSON.parse(new TextDecoder().decode(rawIndex)) as Record<string, string>
    const file = index['deepseek.com']
    expect(file).toBeDefined()
    // <uuid4.hex[:12]>.ico — 12 lowercase hex chars + extension.
    expect(file).toMatch(/^[0-9a-f]{12}\.ico$/)
    // Stored bytes match what was served.
    const stored = await readFile(`${dir}/${file}`)
    expect(Array.from(stored)).toEqual([9, 8, 7])
  })

  it('serves a persisted icon straight from disk after a restart (no network)', async () => {
    const dir = await freshDir('restart')
    const first = createFaviconFetcher({
      fetchImpl: (async () => imageResponse()) as unknown as typeof fetch,
      cacheDir: dir,
    })
    await first.fetchFavicon('github.com')

    // Fresh fetcher = process restart: disk index is reloaded, network must
    // never be hit again.
    const network = vi.fn(async () => {
      throw new Error('network must not be hit for a cached host')
    })
    const second = createFaviconFetcher({
      fetchImpl: network as unknown as typeof fetch,
      cacheDir: dir,
    })
    const result = await second.fetchFavicon('github.com')

    expect(result).not.toBeNull()
    expect(Array.from(result!.body)).toEqual(Array.from(BYTES))
    expect(network).not.toHaveBeenCalled()
  })

  it('does not persist failures', async () => {
    const dir = await freshDir('failure')
    const fetcher = createFaviconFetcher({
      fetchImpl: (async () => new Response(null, { status: 404 })) as unknown as typeof fetch,
      cacheDir: dir,
    })

    expect(await fetcher.fetchFavicon('dead.example')).toBeNull()

    const index = JSON.parse(new TextDecoder().decode(await readFile(`${dir}/index.json`)))
    expect(index).toEqual({})
  })

  it('re-fetches when the cached file went missing', async () => {
    const dir = await freshDir('missing')
    const first = createFaviconFetcher({
      fetchImpl: (async () => imageResponse('image/x-icon', new Uint8Array([5, 5, 5]))) as unknown as typeof fetch,
      cacheDir: dir,
    })
    await first.fetchFavicon('broken.example')
    // User deleted the icon file but not the index entry.
    const index = JSON.parse(new TextDecoder().decode(await readFile(`${dir}/index.json`)))
    await rm(`${dir}/${index['broken.example']}`, { force: true })

    const network = vi.fn(async (url: string) => imageResponse('image/x-icon', new Uint8Array([7, 7, 7])))
    const second = createFaviconFetcher({
      fetchImpl: network as unknown as typeof fetch,
      cacheDir: dir,
    })
    const result = await second.fetchFavicon('broken.example')

    expect(result).not.toBeNull()
    expect(network).toHaveBeenCalledTimes(1) // https success only, no fallback
    // Re-persisted with a fresh entry.
    const freshIndex = JSON.parse(new TextDecoder().decode(await readFile(`${dir}/index.json`)))
    expect(freshIndex['broken.example']).toMatch(/^[0-9a-f]{12}\.ico$/)
  })

  it('honors a pre-seeded index.json without any network request', async () => {
    const dir = await freshDir('preseed')
    await writeFile(`${dir}/index.json`, JSON.stringify({ 'pre.example': 'a1b2c3d4e5f6.ico' }))
    await writeFile(`${dir}/a1b2c3d4e5f6.ico`, new Uint8Array([1, 1, 1]))

    const network = vi.fn(async () => {
      throw new Error('network must not be hit')
    })
    const fetcher = createFaviconFetcher({
      fetchImpl: network as unknown as typeof fetch,
      cacheDir: dir,
    })
    const result = await fetcher.fetchFavicon('pre.example')

    expect(result).not.toBeNull()
    expect(Array.from(result!.body)).toEqual([1, 1, 1])
    expect(network).not.toHaveBeenCalled()
  })

  it('degenerates to a fresh index when a pre-seeded one is corrupt', async () => {
    const dir = await freshDir('corrupt')
    await writeFile(`${dir}/index.json`, '{not json')
    const fetcher = createFaviconFetcher({
      fetchImpl: (async () => imageResponse('image/x-icon', new Uint8Array([3, 3, 3]))) as unknown as typeof fetch,
      cacheDir: dir,
    })

    const result = await fetcher.fetchFavicon('fresh.example')

    expect(result).not.toBeNull()
    const index = JSON.parse(new TextDecoder().decode(await readFile(`${dir}/index.json`)))
    expect(index['fresh.example']).toMatch(/^[0-9a-f]{12}\.ico$/)
  })
})

describe('FAVICON_TIMEOUT_MS', () => {
  it('is 3 seconds as required', () => {
    expect(FAVICON_TIMEOUT_MS).toBe(3000)
  })
})