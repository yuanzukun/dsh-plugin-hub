

# dsh-anysearch-refs
<p align="left">
  <a href="https://github.com/deepseek-ai"><img src="https://img.shields.io/badge/DeepSeek_Harness-plugin-blue" alt="DSH Plugin"></a>
  <a href="https://github.com/deepseek-ai"><img src="https://img.shields.io/badge/DeepSeek_Harness-web-orange" alt="DSH Web"></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="MIT license"></a>
</p>

[English](#what) · [中文](#这是什么)

## What

A DSH sidebar plugin that shows AnySearch references as cards, with the search query, source snippets and highlighted keywords in the right sidebar.

It captures `anysearch_search` / `anysearch_batch_search` tool results and renders them in a dedicated DSH sidebar tab. Each card shows a favicon fetched from `<hostname>/favicon.ico` as a non-blocking background task (3s timeout, https→http fallback, cached locally in `assets/.favicon`); multi-word queries are split into keywords and let you highlight up to 3 of them from a dropdown, with an 8-color cycling palette that adapts to light/dark skins. Single-keyword queries keep the plain highlight.

Each query block is collapsible via the header chevron: searches from the latest agent turn stay expanded by default while earlier turns collapse to a compact summary strip (stacked site icons + total source count), and your manual expand/collapse choice is remembered per session. Hovering the query keyword shows the full request metadata (request id, result count, latency).

![overview](assets/screenshot-1.png)
*Overview: AnySearch reference cards in the right sidebar.*

![keyword-select](assets/screenshot-2.png)

*Keyword dropdown with multiple highlight selections.*

> **Status**: early iteration. If you send a PR, please rebase onto the latest `main`.

### Prerequisites

Install these separately in your DSH profile first:

| Package | Purpose |
| --- | --- |
| [`@anysearch/anysearch-dsh`](https://github.com/anysearch-team/anysearch-dsh) | AnySearch data source / tool events |
| [`dsh-better-sidebar`](https://github.com/omdsh-dev/DSH-better-sidebar) | Right sidebar / tab hosting |

### Installation

For normal users, these three commands are enough — no `pnpm` needed:

```bash
dsh plugin --profile web add @anysearch/anysearch-dsh
dsh plugin --profile web add dsh-better-sidebar
dsh plugin --profile web add github:v587d/dsh-anysearch-refs
```

Then restart `dsh web` and hard-refresh the browser (`Ctrl+Shift+R` / `Cmd+Shift+R`).

### Build from source

Developers only:

```bash
pnpm install
pnpm run build
pnpm run check
```

### Contributing

- Rebase onto the latest `main` before PR.
- Run `pnpm run check` before pushing.
- Do not modify DSH core or `dsh-better-sidebar` source.

### License

MIT

---

## 这是什么

一个 DSH 侧边栏插件，把 AnySearch 的搜索结果以卡片形式展示在右侧侧边栏中，包括搜索词、来源摘要和关键词高亮。

它捕获 `anysearch_search` / `anysearch_batch_search` 的工具结果，并在 DSH 侧边栏中单独展示。每张卡片左上角展示通过 `<主机名>/favicon.ico` 获取的站点 favicon（后台任务、3 秒超时、https→http 回退，并在 `assets/.favicon` 本地持久化缓存，失败时降级为主机名首字母徽标）；多词查询按空格分词后，可在下拉框中勾选高亮（至多 3 个关键词），使用随明暗皮肤自适应的 8 色循环调色板；单词查询保持原有高亮样式。

每个 query 块可通过表头箭头折叠：最近一轮 agent turn 的搜索默认展开，更早轮次自动收起为一条摘要（站点图标叠加 + 来源总数），手动展开/收起的选择按会话记忆在 localStorage 中。悬停 query 关键词可查看完整请求信息（request id、结果数、耗时）。

![overview](assets/screenshot-1.png)
*整体效果：右侧侧边栏中的 AnySearch 引用卡片。*

![keyword-select](assets/screenshot-2.png)

*关键词下拉：多选高亮效果。*

> **状态**：早期迭代中。如果提交 PR，请先 rebase 到最新的 `main`。

### 前置依赖

需要先在 DSH profile 中单独安装：

| 包 | 作用 |
| --- | --- |
| [`@anysearch/anysearch-dsh`](https://github.com/anysearch-team/anysearch-dsh) | AnySearch 数据源 / 工具事件 |
| [`dsh-better-sidebar`](https://github.com/omdsh-dev/DSH-better-sidebar) | 右侧侧边栏 / tab 容器 |

### 安装

普通用户只需要这三条命令，**不需要 pnpm**：

```bash
dsh plugin --profile web add @anysearch/anysearch-dsh
dsh plugin --profile web add dsh-better-sidebar
dsh plugin --profile web add github:v587d/dsh-anysearch-refs
```

然后重启 `dsh web`，并在浏览器中硬刷新（`Ctrl+Shift+R` / `Cmd+Shift+R`）。

### 源码构建

仅开发者需要：

```bash
pnpm install
pnpm run build
pnpm run check
```

### 贡献

- 提交 PR 前请 rebase 到最新 `main`。
- 推送前运行 `pnpm run check`。
- 不要修改 DSH 核心或 `dsh-better-sidebar` 源码。

### License

MIT
