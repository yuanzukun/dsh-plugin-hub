/** Hard deadline for the whole favicon fetch (https + http attempts). */
export declare const FAVICON_TIMEOUT_MS = 3000;
export interface FaviconResult {
    /** Image bytes (ICO/PNG/…). */
    body: Uint8Array;
    /** Response content-type, e.g. `image/x-icon`. */
    type: string;
}
export interface FaviconFetcher {
    /** Resolve the favicon for one hostname, or null when unavailable. */
    fetchFavicon: (host: string) => Promise<FaviconResult | null>;
    /** Number of cached hosts (diagnostics/tests). */
    size: () => number;
}
export interface FaviconFetcherOptions {
    fetchImpl?: typeof fetch;
    timeoutMs?: number;
    now?: () => number;
    /** Disk-cache directory. `undefined` → package `assets/.favicon`;
     *  `null` → disable persistence (tests / memory-only). */
    cacheDir?: string | null;
}
/** Whether a string is safe to embed as the host part of a favicon URL. */
export declare function isValidHostname(host: string): boolean;
export declare function createFaviconFetcher(options?: FaviconFetcherOptions): FaviconFetcher;
//# sourceMappingURL=favicon.d.ts.map