/**
 * Minimal ambient types for the Node builtins the host half touches.
 *
 * tsconfig.build.json builds src/** with lib ES2024+DOM only — @types/node
 * is NOT pulled into the host build (Buffer was previously reported as
 * unknown). Declaring just the surface we use keeps the host build free of
 * Node type deps while the runtime still runs in Node >= 20.
 */
declare module 'node:fs/promises' {
  export function mkdir(path: string, options?: { recursive?: boolean }): Promise<string | undefined>
  export function readFile(path: string): Promise<Uint8Array>
  export function writeFile(path: string, data: Uint8Array | string): Promise<void>
  export function rm(path: string, options?: { recursive?: boolean; force?: boolean }): Promise<void>
}