/** Host-side favicon fetcher for dsh-anysearch-refs.
 *
 *  Retrieves `GET <scheme>://<hostname>/favicon.ico` as a background task:
 *  the fetch is fully asynchronous (never blocks the event loop), carries a
 *  hard 3s deadline (https attempt first; http fallback takes only the
 *  remaining budget), and results are cached per hostname so repeat card
 *  renders resolve instantly without hammering third-party sites.
 *
 *  ── Disk persistence (per-user, never committed) ─────────────────────
 *  Successfully fetched icons are mirrored into the package-local
 *  `assets/.favicon/` directory (git-ignored; each developer maintains
 *  their own cache):
 *
 *      assets/.favicon/
 *        index.json          { "<hostname>": "<uuid4.hex[:12]>.ico", … }
 *        <uuid4.hex[:12]>.ico  fetched icon bytes
 *
 *  Every request checks the index first: a host already cached is served
 *  straight from the local file (no network, no 3s wait). The index is the
 *  single source of truth between restarts; a missing/corrupt file entry is
 *  dropped and re-fetched. If the cache directory cannot be created or
 *  written (e.g. a read-only npm-store install), the fetcher degrades
 *  silently to memory-only caching.
 *
 *  Testability: `fetchImpl` / `timeoutMs` / `now` / `cacheDir` are injectable.
 */
import { mkdir, readFile, writeFile } from 'node:fs/promises'

// ── Configuration ────────────────────────────────────────────────────

/** Hard deadline for the whole favicon fetch (https + http attempts). */
export const FAVICON_TIMEOUT_MS = 3000

/** Refuse favicon bodies larger than 512 KiB (deepseek.com's is ~205 KiB). */
const MAX_FAVICON_BYTES = 512 * 1024

/** How long a failed host is remembered before retrying. */
const NEGATIVE_CACHE_TTL_MS = 10 * 60 * 1000

/** Max cached hosts; oldest entry evicted first. */
const MAX_CACHE_ENTRIES = 256

/** DNS-label shape only — rejects schemes, ports, userinfo, paths, spaces. */
const HOSTNAME_RE =
  /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/

/** File name of the host → icon mapping. */
const INDEX_FILE_NAME = 'index.json'

/**
 * Default disk-cache location: the package-local `assets/.favicon`
 * (this module ships inside lib/index.js, so `..` from here is the package
 * root — for a `link:` profile install that is the developer's checkout).
 */
const DEFAULT_CACHE_DIR = new URL('../assets/.favicon', import.meta.url).pathname

/**
 * Disk hits serve the bytes as ICO. The real fetched content-type is not
 * persisted (the index maps host → file only); storing SVG is refused at
 * fetch time, so serving everything as `image/x-icon` stays safe (browsers
 * decode `<img>` bytes by content regardless of the header).
 */
const DISK_HIT_TYPE = 'image/x-icon'

// ── Public types & helpers ───────────────────────────────────────────

export interface FaviconResult {
  /** Image bytes (ICO/PNG/…). */
  body: Uint8Array
  /** Response content-type, e.g. `image/x-icon`. */
  type: string
}

export interface FaviconFetcher {
  /** Resolve the favicon for one hostname, or null when unavailable. */
  fetchFavicon: (host: string) => Promise<FaviconResult | null>
  /** Number of cached hosts (diagnostics/tests). */
  size: () => number
}

export interface FaviconFetcherOptions {
  fetchImpl?: typeof fetch
  timeoutMs?: number
  now?: () => number
  /** Disk-cache directory. `undefined` → package `assets/.favicon`;
   *  `null` → disable persistence (tests / memory-only). */
  cacheDir?: string | null
}

/** Whether a string is safe to embed as the host part of a favicon URL. */
export function isValidHostname(host: string): boolean {
  return host.length > 0 && host.length <= 253 && HOSTNAME_RE.test(host)
}

function joinPath(dir: string, name: string): string {
  return dir.endsWith('/') ? `${dir}${name}` : `${dir}/${name}`
}

// ── Factory ──────────────────────────────────────────────────────────

export function createFaviconFetcher(options?: FaviconFetcherOptions): FaviconFetcher {
  const fetchImpl = options?.fetchImpl ?? globalThis.fetch.bind(globalThis)
  const timeoutMs = options?.timeoutMs ?? FAVICON_TIMEOUT_MS
  const now = options?.now ?? Date.now
  const cacheDir = options?.cacheDir !== undefined ? options.cacheDir : DEFAULT_CACHE_DIR
  const indexPath = cacheDir === null ? null : joinPath(cacheDir, INDEX_FILE_NAME)

  // In-memory layers: fast path first, disk second, network last.
  const successCache = new Map<string, FaviconResult>()
  const negativeCache = new Map<string, number>()
  const inflight = new Map<string, Promise<FaviconResult | null>>()

  // Disk persistence state.
  /** host → cached icon file name (loaded from index.json at startup). */
  const diskIndex = new Map<string, string>()
  let persistenceReady = false
  /** Serializes index.json writes so concurrent saves never interleave. */
  let indexWriteQueue: Promise<void> = Promise.resolve()

  const setSuccess = (host: string, result: FaviconResult): void => {
    successCache.set(host, result)
    if (successCache.size > MAX_CACHE_ENTRIES) {
      const oldest = successCache.keys().next().value
      if (oldest !== undefined) successCache.delete(oldest)
    }
  }

  const setFailure = (host: string): void => {
    negativeCache.set(host, now())
    if (negativeCache.size > MAX_CACHE_ENTRIES * 2) {
      for (const [h, at] of negativeCache) {
        if (now() - at >= NEGATIVE_CACHE_TTL_MS) negativeCache.delete(h)
      }
    }
  }

  /** Create assets/.favicon if needed and load/seed index.json. */
  const initStore = async (): Promise<void> => {
    if (cacheDir === null || indexPath === null) return
    try {
      await mkdir(cacheDir, { recursive: true })
      let raw: Uint8Array
      try {
        raw = await readFile(indexPath)
      } catch {
        raw = new Uint8Array(0)
      }
      diskIndex.clear()
      if (raw.byteLength > 0) {
        // Self-heal on a corrupt index: reset to an empty mapping instead of
        // silently dropping persistence for the whole process lifetime.
        try {
          const parsed = JSON.parse(new TextDecoder().decode(raw)) as Record<string, unknown>
          for (const [host, file] of Object.entries(parsed)) {
            if (typeof file === 'string' && file.length > 0) diskIndex.set(host, file)
          }
        } catch {
          await writeFile(indexPath, '{}')
        }
      } else {
        // First initialization: seed the mapping file.
        await writeFile(indexPath, '{}')
      }
      persistenceReady = true
    } catch {
      // Read-only npm-store install or other I/O failure: memory-only fallback.
      persistenceReady = false
    }
  }
  const storeReady = initStore()

  /** Write the full index.json through a serialized queue (never block). */
  const persistIndex = (): void => {
    if (indexPath === null) return
    const serialized = JSON.stringify(Object.fromEntries(diskIndex))
    indexWriteQueue = indexWriteQueue
      .catch(() => {})
      .then(() => writeFile(indexPath, serialized))
      .catch(() => {
        // Persistence failures never break the request path.
      })
  }

  /** Mirror a freshly fetched icon onto disk (index + bytes). */
  const saveFavicon = async (host: string, result: FaviconResult): Promise<void> => {
    if (cacheDir === null || !persistenceReady) return
    const name = crypto.randomUUID().replace(/-/g, '').slice(0, 12) + '.ico'
    try {
      await writeFile(joinPath(cacheDir, name), result.body)
      diskIndex.set(host, name)
      persistIndex()
    } catch {
      // Disk write failed (quota/perms): keep the memory cache only.
    }
  }

  /** Serve a previously persisted icon from the local file, if present. */
  const loadFromDisk = async (host: string): Promise<FaviconResult | null> => {
    if (cacheDir === null || !persistenceReady) return null
    const file = diskIndex.get(host)
    if (file === undefined) return null
    try {
      const body = await readFile(joinPath(cacheDir, file))
      if (body.byteLength === 0) throw new Error('empty cache file')
      return { body, type: DISK_HIT_TYPE }
    } catch {
      // Entry points at a missing/corrupt file: drop it and re-fetch.
      diskIndex.delete(host)
      return null
    }
  }

  const fetchOne = async (url: string, ms: number): Promise<FaviconResult | null> => {
    let res: Response
    try {
      res = await fetchImpl(url, {
        redirect: 'follow',
        signal: AbortSignal.timeout(ms),
        headers: {
          accept:
            'image/avif,image/webp,image/png,image/x-icon,image/vnd.microsoft.icon,*/*',
          // A browser-like UA: some sites' WAFs reject non-browser agents,
          // which would turn otherwise-present favicons into 404s.
          'user-agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        },
      })
    } catch {
      // Network error, DNS failure, TLS failure or timeout — all "no favicon".
      return null
    }
    if (!res.ok) return null
    const type = (res.headers.get('content-type') ?? '').toLowerCase()
    // Some servers answer 200 with an HTML error page for missing icons.
    if (!type.startsWith('image/')) return null
    // SVG is refused: `image/svg+xml` would break disk caching (the persisted
    // bytes carry no content-type, and svg must never ride an ico header).
    if (type === 'image/svg+xml') return null
    let body: Uint8Array
    try {
      body = new Uint8Array(await res.arrayBuffer())
    } catch {
      return null
    }
    if (body.byteLength === 0 || body.byteLength > MAX_FAVICON_BYTES) return null
    return { body, type }
  }

  const fetchWithFallback = async (host: string): Promise<FaviconResult | null> => {
    const deadline = now() + timeoutMs
    const https = await fetchOne(`https://${host}/favicon.ico`, Math.max(1, deadline - now()))
    if (https !== null) return https
    // Fall back to plain http only while the 3s budget remains.
    if (now() >= deadline) return null
    return fetchOne(`http://${host}/favicon.ico`, Math.max(1, deadline - now()))
  }

  const fetchFavicon = (host: string): Promise<FaviconResult | null> => {
    // Fast path: in-memory success cache (before any await, so concurrent
    // callers of the same host always share a single task below).
    const cached = successCache.get(host)
    if (cached !== undefined) return Promise.resolve(cached)

    // Concurrent callers share one in-flight task (network + disk writes).
    const pending = inflight.get(host)
    if (pending !== undefined) return pending

    const run = (async (): Promise<FaviconResult | null> => {
      // Disk path: already persisted before → serve the local file directly.
      await storeReady
      const fromDisk = await loadFromDisk(host)
      if (fromDisk !== null) {
        setSuccess(host, fromDisk)
        return fromDisk
      }

      const lastFail = negativeCache.get(host)
      if (lastFail !== undefined && now() - lastFail < NEGATIVE_CACHE_TTL_MS) {
        return null
      }

      const result = await fetchWithFallback(host)
      if (result !== null) {
        setSuccess(host, result)
        await saveFavicon(host, result)
      } else {
        setFailure(host)
      }
      return result
    })()
    const task = run.finally(() => {
      inflight.delete(host)
    })
    inflight.set(host, task)
    return task
  }

  return { fetchFavicon, size: () => successCache.size }
}