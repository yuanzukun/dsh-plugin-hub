/** Client half of dsh-anysearch-refs: registers the "AnySearch Refs" tab
 *  with ctx.betterSidebar and renders parsed search sources as clickable
 *  cards.
 *
 *  Build: this file is compiled into lib/client.js and
 *  lib/client-registry.js by tsdown (see tsdown.config.ts).
 *  The factory receives `require` for module-table lookups (react, cordis).
 *
 *  Only type-only imports from dsh-better-sidebar (erased at compile time,
 *  no runtime dependency). React is resolved through the module table.
 */
import type {} from 'dsh-better-sidebar'  // triggers ctx.betterSidebar augmentation
import type { Context } from 'cordis'
import { IconSearchOutline16 } from '@deepseek-ai/dsh-client-ui-primitives'

// ── Types (re-declared locally — the shared types module is Node-only) ──

interface AnySearchSource {
  title: string
  url: string
  snippet?: string
}

interface AnySearchBatch {
  timestamp: number
  query?: string
  order?: number
  payload?: Record<string, unknown>
  requestId?: string
  totalResults?: number
  searchTimeMs?: number
  /** Agent turn this batch was captured in (stamped by the host mirror). */
  turn?: number
  sources: AnySearchSource[]
}

interface AnySearchResultsResponse {
  batches: AnySearchBatch[]
}

// ── CSS (injected as <style data-plugin> by the build pipeline) ──────

import css from './styles.module.css'

// ── Constants ────────────────────────────────────────────────────────

const TAB_ID = 'anysearch-refs:anysearch-refs'
/** Content seed used to auto-expand the right panel when opening. */
const AUTO_OPEN_SEED_PATH = 'anysearch://refs'
/** Same sandbox policy as dsh-better-sidebar's built-in browser tab. */
const PREVIEW_IFRAME_SANDBOX =
  'allow-scripts allow-forms allow-popups allow-downloads allow-modals allow-popups-to-escape-sandbox'
// Cordis service dependency. The client bundle must declare this so reading
// `ctx.betterSidebar` is allowed; without it Cordis throws
// `cannot get property "betterSidebar" without inject`.
export const inject = ['betterSidebar']

/**
 * Favicon loading rule: the page displays the hostname (e.g. `deepseek.com`
 * for `https://deepseek.com/harness/en/`), and the favicon is fetched via
 * `<hostname>/favicon.ico`. Two channels:
 *  1. DIRECT: the browser itself loads `<origin>/favicon.ico` — the site
 *     sees a real browser TLS fingerprint / network stack, so WAF-blocked
 *     hosts (openai.com 403s Node fetch but works in a browser) load fine;
 *  2. PROXY: on direct failure/timeout the card falls back to the host's
 *     same-origin proxy route (non-blocking background fetch, 3s timeout,
 *     disk-cache aware) — and every direct hit is echoed to the proxy once
 *     so the `assets/.favicon` disk cache stays populated.
 */
/** Same-origin proxy route that answers with the fetched favicon bytes. */
function faviconProxyUrl(hostname: string): string {
  return `/api/refs/favicon?host=${encodeURIComponent(hostname)}`
}

/** Direct `<origin>/favicon.ico` URL for the browser to load itself. */
function faviconDirectUrl(sourceUrl: string): string {
  try {
    const parsed = new URL(sourceUrl)
    return `${parsed.origin}/favicon.ico`
  } catch {
    return `https://${sourceUrl}/favicon.ico`
  }
}

/** DNS-label shape only (mirrors the host's own validator) — hosts failing
 *  this can never be fetched; don't even issue a request for them. */
const HOSTNAME_SHAPE_RE =
  /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/

function isValidHostnameShape(host: string): boolean {
  return host.length > 0 && host.length <= 253 && HOSTNAME_SHAPE_RE.test(host)
}

// ── Persistent "known-bad direct favicon" memory ─────────────────────
// A direct `<origin>/favicon.ico` request that fails prints ONE red
// "Failed to load resource" line in the browser console — that message is
// emitted by the network layer, so no try/catch can swallow it. The fix is
// to never re-issue doomed requests: hosts whose DIRECT attempt failed are
// remembered in localStorage, and every later page load goes straight to
// the same-origin proxy (which answers 204, console-silent). Net effect:
// each weird host costs at most one console line, ever.

const FAVICON_FAIL_STORE_KEY = 'dsh-anysearch-refs.faviconFail.v1'
/** Max remembered failed hostnames. */
const FAVICON_FAIL_MAX = 200

function loadFaviconFails(): Set<string> {
  try {
    const raw = window.localStorage.getItem(FAVICON_FAIL_STORE_KEY)
    if (!raw) return new Set()
    const parsed: unknown = JSON.parse(raw)
    if (!Array.isArray(parsed)) return new Set()
    return new Set(parsed.filter((h): h is string => typeof h === 'string'))
  } catch {
    return new Set()
  }
}

function saveFaviconFailure(hostname: string): void {
  try {
    const list = [...loadFaviconFails()]
    if (!list.includes(hostname)) list.push(hostname)
    while (list.length > FAVICON_FAIL_MAX) list.shift()
    window.localStorage.setItem(FAVICON_FAIL_STORE_KEY, JSON.stringify(list))
  } catch {
    /* storage full/disabled — the in-memory guard still applies */
  }
}
/** Hostnames whose direct hit was already echoed to the host proxy this
 *  page session, so disk persistence is triggered only once per host. */
const proxiedHosts = new Set<string>()
/** Hostnames whose favicon already loaded this page session, so a
 *  re-render (long-poll refresh) shows the icon directly instead of a
 *  brief letter flash. */
const loadedFavicons = new Set<string>()
/** Hostnames whose favicon already failed this page session — never
 *  re-requested (avoids a console/network storm of identical failing
 *  requests). */
const failedFavicons = new Set<string>()
/** Hostnames whose DIRECT attempt failed in ANY page session (persisted to
 *  localStorage) — future loads skip straight to the proxy channel. */
const persistentFailedHosts = loadFaviconFails()

// ── Fetch helper ─────────────────────────────────────────────────────

async function fetchResults(sessionId: string, signal: AbortSignal, wait = false): Promise<AnySearchResultsResponse> {
  const res = await fetch('/api/refs/anysearch', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ sessionId, wait, timeoutMs: 30_000 }),
    signal,
  })
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`)
  }
  const parsed = await res.json()
  if (!parsed?.ok || !parsed?.value) {
    throw new Error('unexpected response shape')
  }
  return parsed.value
}

// ── Helpers ─────────────────────────────────────────────────────────

function safeHostname(url: string): string {
  try { return new URL(url).hostname } catch { return url }
}

/** Deterministic accent color for the letter badge of a given hostname. */
function fallbackColor(hostname: string): string {
  let hash = 0
  for (let i = 0; i < hostname.length; i++) {
    hash = (hash * 31 + hostname.charCodeAt(i)) >>> 0
  }
  return `hsl(${hash % 360}, 55%, 42%)`
}

function totalSources(batches: AnySearchBatch[]): number {
  return batches.reduce((sum, b) => sum + b.sources.length, 0)
}

function formatTimeAgo(ts: number): string {
  const diffMs = Date.now() - ts
  const diffSec = Math.floor(diffMs / 1000)
  if (diffSec < 60) return `${diffSec}s ago`
  const diffMin = Math.floor(diffSec / 60)
  if (diffMin < 60) return `${diffMin}m ago`
  const diffHr = Math.floor(diffMin / 60)
  if (diffHr < 24) return `${diffHr}h ago`
  return new Date(ts).toLocaleDateString()
}

function formatPayloadValue(value: unknown): string {
  if (typeof value === 'string') return JSON.stringify(value)
  if (value === undefined) return 'undefined'
  if (typeof value === 'object' && value !== null) {
    try { return JSON.stringify(value) } catch { return String(value) }
  }
  return String(value)
}

/** Render every raw payload field as `key: value`, joined for the meta line. */
function formatPayload(payload?: Record<string, unknown>): string {
  if (!payload) return ''
  return Object.entries(payload)
    .map(([key, value]) => `${key}: ${formatPayloadValue(value)}`)
    .join(' · ')
}

function batchSignature(batch: AnySearchBatch): string {
  return JSON.stringify([
    batch.requestId ?? '',
    batch.timestamp ?? 0,
    batch.query ?? '',
    batch.payload ?? null,
    ...batch.sources.map(s => `${s.title}|${s.url}|${s.snippet ?? ''}`),
  ])
}

function resultsSignature(batches: AnySearchBatch[]): string {
  return batches.slice(0, 10).map(batchSignature).join('\n')
}

// ── Conversation-round collapsing ────────────────────────────────────

/** Maximum number of stacked site icons in the collapsed summary row. */
const SUMMARY_ICON_MAX = 10
/** A gap larger than this between consecutive batch timestamps starts a new
 *  conversation round; everything from the last such gap onward is "the
 *  current round" (expanded by default), everything before it is collapsed. */
const ROUND_GAP_MS = 3 * 60_000

/**
 * Timestamp of the first batch of the latest conversation round: walk back
 * through the time-sorted batches and stop at the first gap exceeding
 * ROUND_GAP_MS. Batches at/after this moment are the current round.
 */
function latestRoundStartTime(batches: AnySearchBatch[]): number {
  if (batches.length === 0) return Number.POSITIVE_INFINITY
  const sorted = [...batches]
    .map(batch => batch.timestamp || 0)
    .sort((a, b) => a - b)
  const latest = sorted[sorted.length - 1]
  let start = latest
  for (let i = sorted.length - 1; i >= 1; i--) {
    if (sorted[i] - sorted[i - 1] > ROUND_GAP_MS) break
    start = sorted[i - 1]
  }
  return start
}

/** Stable per-batch key used to persist the user's collapse choice. */
function batchKeyOf(batch: AnySearchBatch): string {
  return `${batch.requestId ?? ''}|${batch.order ?? ''}|${Math.floor(batch.timestamp || 0)}`
}

/**
 * Latest agent-turn number among the batches (−1 when the mirror never
 * saw a turn). "Current round" = every batch captured in this turn.
 */
function latestTurn(batches: AnySearchBatch[]): number {
  let max = -1
  for (const batch of batches) {
    if (typeof batch.turn === 'number' && batch.turn > max) max = batch.turn
  }
  return max
}

// ── localStorage persistence of manual expand/collapse choices ──────

const COLLAPSE_STORE_KEY = 'dsh-anysearch-refs.collapsed.v1'
/** Max remembered sessions / batches — keeps localStorage bounded forever. */
const COLLAPSE_SESSION_MAX = 20
const COLLAPSE_BATCH_MAX = 200

type CollapseStore = Record<string, Record<string, boolean>>

function loadCollapseStore(): CollapseStore {
  try {
    const raw = window.localStorage.getItem(COLLAPSE_STORE_KEY)
    if (!raw) return {}
    const parsed: unknown = JSON.parse(raw)
    return parsed && typeof parsed === 'object' ? parsed as CollapseStore : {}
  } catch {
    return {}
  }
}

function writeCollapseStore(store: CollapseStore): void {
  try {
    // Bounded: keep only the most recent sessions.
    const sessionIds = Object.keys(store)
    if (sessionIds.length > COLLAPSE_SESSION_MAX) {
      for (const sessionId of sessionIds.slice(0, sessionIds.length - COLLAPSE_SESSION_MAX)) {
        delete store[sessionId]
      }
    }
    window.localStorage.setItem(COLLAPSE_STORE_KEY, JSON.stringify(store))
  } catch {
    /* storage full/disabled — user choice just won't persist */
  }
}

/** The user's recorded choice for one batch, or undefined when unset. */
function loadCollapseChoice(sessionId: string, key: string): boolean | undefined {
  try {
    const entry = loadCollapseStore()[sessionId]
    if (!entry || !(key in entry)) return undefined
    const value = entry[key]
    return typeof value === 'boolean' ? value : undefined
  } catch {
    return undefined
  }
}

/** Persist one manual collapse decision (prunes old entries when large). */
function saveCollapseChoice(sessionId: string, key: string, collapsed: boolean): void {
  try {
    const store = loadCollapseStore()
    const entry = store[sessionId] ?? {}
    entry[key] = collapsed
    const keys = Object.keys(entry)
    if (keys.length > COLLAPSE_BATCH_MAX) {
      for (const stale of keys.slice(0, keys.length - COLLAPSE_BATCH_MAX)) delete entry[stale]
    }
    store[sessionId] = entry
    writeCollapseStore(store)
  } catch {
    /* ignore */
  }
}

/** One highlight target: a keyword plus the CSS class of its color. */
interface HighlightTarget {
  word: string
  className: string
}

/** Split a query into keywords the way AnySearch itself requests them. */
function splitKeywords(query?: string): string[] {
  return (query ?? '').split(/\s+/).filter(Boolean)
}

/**
 * Case-insensitive literal highlight for one or more keywords; overlapping
 * ranges keep the earlier keyword's color. Only used in snippets, never
 * titles. A single keyword behaves exactly like the old behavior.
 */
function highlightSnippet(text: string, targets: HighlightTarget[]): Array<string | JSX.Element> {
  if (!text || targets.length === 0) return [text]

  const lowerText = text.toLowerCase()
  const ranges: Array<{ start: number; end: number; className: string }> = []
  for (const target of targets) {
    const lowerWord = target.word.toLowerCase()
    if (!lowerWord) continue
    let start = lowerText.indexOf(lowerWord)
    while (start !== -1) {
      ranges.push({ start, end: start + target.word.length, className: target.className })
      start = lowerText.indexOf(lowerWord, start + 1)
    }
  }
  if (ranges.length === 0) return [text]

  ranges.sort((a, b) => a.start - b.start || a.end - b.end)
  const merged: Array<{ start: number; end: number; className: string }> = []
  let lastEnd = -1
  for (const range of ranges) {
    if (range.start < lastEnd) continue // overlap → keep the earlier keyword
    merged.push(range)
    lastEnd = range.end
  }

  const parts: Array<string | JSX.Element> = []
  let cursor = 0
  let key = 0
  for (const range of merged) {
    if (range.start > cursor) parts.push(text.slice(cursor, range.start))
    parts.push(
      <mark className={range.className} key={key++}>
        {text.slice(range.start, range.end)}
      </mark>,
    )
    cursor = range.end
  }
  if (cursor < text.length) parts.push(text.slice(cursor))
  return parts
}

/** Return the id of the first leaf in the right split tree. */
type SplitNodeLike = { kind?: string; id?: string; children?: SplitNodeLike[]; tabs?: Array<{ type?: string }> }

/** Return the id of the first leaf in the right split tree. */
function firstRightLeafId(state: { splits?: unknown }): string {
  let node = state.splits as SplitNodeLike | undefined
  while (node && node.kind !== 'leaf') {
    const children = node.children
    node = Array.isArray(children) ? children[0] : undefined
  }
  return node?.id ?? ''
}

/** Return the right-pane leaf that already hosts AnySearch Refs, if any. */
function rightLeafForRefs(state: { splits?: unknown }): string {
  const walk = (node: SplitNodeLike | undefined): string | undefined => {
    if (!node) return undefined
    if (node.kind === 'leaf') {
      return Array.isArray(node.tabs) && node.tabs.some(tab => tab.type === TAB_ID)
        ? node.id
        : undefined
    }
    for (const child of node.children ?? []) {
      const found = walk(child)
      if (found !== undefined) return found
    }
    return undefined
  }
  return walk(state.splits as SplitNodeLike | undefined) ?? firstRightLeafId(state)
}

// ── Tab component ────────────────────────────────────────────────────

function AnySearchRefsTab(props: {
  ctx: Context
  scope: { sessionId: string }
  visible: boolean
}): JSX.Element {
  const { scope, visible } = props
  const [batches, setBatches] = useState<Array<AnySearchBatch>>([])
  const controllerRef = useRef<AbortController | undefined>(undefined)
  // "Current round" first choice is the REAL agent turn: the host mirror
  // stamps each batch with the DSH session turn number, so every search of
  // the latest turn defaults to expanded and earlier turns stay collapsed.
  const maxTurn = useMemo(() => latestTurn(batches), [batches])
  // Legacy fallback (mirror without turn stamps, e.g. old installs):
  // batches within ROUND_GAP_MS of the newest one count as current.
  const roundStart = useMemo(() => latestRoundStartTime(batches), [batches])

  useEffect(() => {
    if (!visible) {
      controllerRef.current?.abort()
      return
    }
    const ctrl = new AbortController()
    controllerRef.current = ctrl
    let cancelled = false

    const loop = async (): Promise<void> => {
      // First call returns immediately, then we long-poll so the host wakes
      // us only when new AnySearch data arrives (or the 30s keepalive fires).
      let first = true
      while (!cancelled) {
        try {
          const data = await fetchResults(scope.sessionId, ctrl.signal, !first)
          if (cancelled) return
          setBatches(data.batches ?? [])
          first = false
        } catch (err) {
          if (ctrl.signal.aborted || cancelled) return
          const msg = err instanceof Error ? err.message : String(err)
          console.warn(`[dsh-anysearch-refs] fetch failed: ${msg}`)
          // On transient errors, back off a little instead of hammering.
          await new Promise(r => setTimeout(r, 2000))
        }
      }
    }

    void loop()
    return () => {
      cancelled = true
      ctrl.abort()
    }
  }, [scope.sessionId, visible])

  if (batches.length === 0) {
    return (
      <div className={css.empty}>
        <div className={css.emptyIcon}>🔍</div>
        <div className={css.emptyTitle}>AnySearch Refs</div>
        <div className={css.emptyHint}>
          Search results will appear here when the assistant uses AnySearch.
        </div>
      </div>
    )
  }

  // Highlight palette adapts to the current skin (light vs dark).
  const rootClass = themeLuminance() < 0.5
    ? `${css.container} ${css.dark}`
    : css.container

  return (
    <div className={rootClass}>
      <div className={css.header}>
        <span className={css.headerTitle}>All references</span>
        <span className={css.headerCount}>{totalSources(batches)} sources</span>
      </div>
      <div className={css.scrollArea}>
        {batches.map((batch) => (
          <SearchBatchCard
            key={batch.requestId ?? batchSignature(batch)}
            batch={batch}
            sessionId={scope.sessionId}
            inCurrentRound={
              maxTurn >= 0 ? batch.turn === maxTurn : batch.timestamp >= roundStart
            }
          />
        ))}
      </div>
    </div>
  )
}

// ── Sub-components ───────────────────────────────────────────────────

/** Max keywords that may be highlighted at once (multi-keyword queries). */
const KEYWORD_HIGHLIGHT_MAX = 3

/**
 * Multi-keyword highlight palette: 3 fixed colors (bright yellow, bright
 * green, bright blue), cycled by keyword position. Yellow is the same mark
 * single-keyword queries use, so everything stays consistent. Users pick
 * keywords only — never colors.
 */
const HIGHLIGHT_COLOR_COUNT = 3
const HIGHLIGHT_CLASSES = [
  css.highlight,          /* bright yellow */
  css.highlightGreen,     /* bright green  */
  css.highlightBlue,      /* bright blue   */
]

function keywordHighlightClass(index: number): string {
  return HIGHLIGHT_CLASSES[index % HIGHLIGHT_COLOR_COUNT]
}

/**
 * Luminance (0..1) of DSH's page-background token, used to pick the
 * light/dark highlight palette without guessing the active skin from the
 * OS (DSH can force either theme).
 */
function themeLuminance(): number {
  const bg = getComputedStyle(document.documentElement)
    .getPropertyValue('--dsw-alias-bg-base').trim()
  if (!bg) return 1
  const hex = bg.match(/^#([0-9a-fA-F]{6})$/)
  if (hex) {
    const n = parseInt(hex[1], 16)
    return ((n >> 16 & 255) * 0.299 + (n >> 8 & 255) * 0.587 + (n & 255) * 0.114) / 255
  }
  const rgb = bg.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/)
  if (rgb) {
    return (Number(rgb[1]) * 0.299 + Number(rgb[2]) * 0.587 + Number(rgb[3]) * 0.114) / 255
  }
  const hsl = bg.match(/^hsla?\(\s*([\d.]+)(?:deg)?\s*[, ]\s*([\d.]+)%\s*[, ]\s*([\d.]+)%/)
  if (hsl) {
    return Number(hsl[3]) / 100
  }
  return 1
}

function SearchBatchCard(props: {
  batch: AnySearchBatch
  sessionId: string
  /** Belongs to the latest conversation round (default expanded) vs an
   *  earlier one (default collapsed). */
  inCurrentRound: boolean
}): JSX.Element {
  const { batch, sessionId, inCurrentRound } = props
  const timeAgo = formatTimeAgo(batch.timestamp)
  // Extract the search query: prefer batch.query, fall back to payload.query
  const query = batch.query
    ?? (typeof batch.payload?.query === 'string' ? batch.payload.query : undefined)
  // Keywords are split the same way AnySearch requests them (whitespace).
  const keywords = splitKeywords(query)
  const multi = keywords.length > 1
  // Selected highlight keywords (multi-keyword queries only): the first
  // keyword is highlighted by default; at most KEYWORD_HIGHLIGHT_MAX on.
  const [selected, setSelected] = useState<string[]>(() => (multi ? [keywords[0]] : []))
  const [menuOpen, setMenuOpen] = useState(false)
  // Collapse/expand of this whole query block. Default comes from the
  // conversation round: current round → expanded, earlier rounds → collapsed.
  // The user's manual choice is remembered in localStorage (per session, per
  // batch) and always beats that default — including across page reloads.
  const [override, setOverride] = useState<boolean | undefined>(
    () => loadCollapseChoice(sessionId, batchKeyOf(batch)),
  )
  const collapsed = override !== undefined ? override : !inCurrentRound
  const wrapRef = useRef<HTMLDivElement | null>(null)

  // A different batch landing on this component instance (long-poll refills
  // the array positionally) must reset the selection to its defaults.
  useEffect(() => {
    setSelected(multi ? [keywords[0]] : [])
    setMenuOpen(false)
    setOverride(loadCollapseChoice(sessionId, batchKeyOf(batch)))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query])

  // Close the dropdown when clicking anywhere outside the control.
  useEffect(() => {
    if (!menuOpen) return
    const onDown = (event: PointerEvent): void => {
      const node = wrapRef.current
      if (node && event.target instanceof Node && !node.contains(event.target)) {
        setMenuOpen(false)
      }
    }
    document.addEventListener('pointerdown', onDown)
    return () => document.removeEventListener('pointerdown', onDown)
  }, [menuOpen])

  const toggleKeyword = (keyword: string): void => {
    setSelected((prev) => {
      if (prev.includes(keyword)) {
        // At least one keyword must stay highlighted.
        return prev.length > 1 ? prev.filter(w => w !== keyword) : prev
      }
      if (prev.length >= KEYWORD_HIGHLIGHT_MAX) return prev
      return [...prev, keyword]
    })
  }

  // Highlight targets for every source of this batch: single keyword keeps
  // the legacy yellow; multi-keyword uses the green/blue cycle by position.
  const highlights: HighlightTarget[] = multi
    ? selected.map(keyword => ({
        word: keyword,
        className: keywordHighlightClass(keywords.indexOf(keyword)),
      }))
    : query ? [{ word: query, className: css.highlight }] : []

  /** Manual flip of this card's collapse state; persisted for the session. */
  const toggleCollapsed = (): void => {
    const next = !collapsed
    setOverride(next)
    saveCollapseChoice(sessionId, batchKeyOf(batch), next)
  }

  // Hover info on the query keyword: the raw metadata that used to clutter
  // the header (request id, counts, latency, capture time) lives in the
  // tooltip instead of a permanent meta row.
  const queryInfoTitle = [
    batch.query,
    batch.requestId !== undefined ? `Req: ${batch.requestId}` : null,
    batch.totalResults !== undefined ? `${batch.totalResults} results` : null,
    batch.searchTimeMs !== undefined ? `${batch.searchTimeMs}ms` : null,
    `Captured ${formatTimeAgo(batch.timestamp)}`,
  ].filter(Boolean).join('\n')

  const meta = [
    batch.totalResults !== undefined ? `${batch.totalResults} results` : null,
    batch.searchTimeMs !== undefined ? `${batch.searchTimeMs}ms` : null,
  ].filter(Boolean)

  // Collapsed summary: the first N distinct site hostnames in source order
  // (same-site results collapse into one icon) as one non-wrapping row.
  const seenHostnames = new Set<string>()
  const summaryItems: Array<{ url: string; hostname: string }> = []
  for (const source of batch.sources) {
    const hostname = safeHostname(source.url)
    if (!hostname || seenHostnames.has(hostname)) continue
    seenHostnames.add(hostname)
    summaryItems.push({ url: source.url, hostname })
    if (summaryItems.length >= SUMMARY_ICON_MAX) break
  }

  return (
    <div className={css.batchCard}>
      <div className={css.batchHeader}>
        <div className={css.batchHeaderLeft}>
          {/* Single keyword: plain text, unchanged behavior. Hover shows
              the full request metadata (see queryInfoTitle). */}
          {query && !multi && (
            <div className={css.batchQuery} title={queryInfoTitle}>🔍 {query}</div>
          )}
          {/* Multiple keywords: a dropdown selects which ones to highlight. */}
          {multi && (
            <div className={css.querySelectWrap} ref={wrapRef}>
              <button
                type="button"
                className={css.querySelect}
                title={queryInfoTitle}
                onClick={() => setMenuOpen(open => !open)}
              >
                <span className={css.querySelectIcon}>🔍</span>
                {selected.map(keyword => (
                  <span key={keyword} className={css.querySelectChip}>{keyword}</span>
                ))}
                <span className={css.querySelectCaret}>{menuOpen ? '▴' : '▾'}</span>
              </button>
              {menuOpen && (
                <div className={css.queryMenu}>
                  {keywords.map((keyword, index) => {
                    const active = selected.includes(keyword)
                    const locked = active && selected.length === 1
                    return (
                      <button
                        key={keyword}
                        type="button"
                        className={active ? css.queryOptionActive : css.queryOption}
                        onClick={() => toggleKeyword(keyword)}
                        disabled={locked}
                        title={locked ? 'At least one keyword must stay highlighted' : undefined}
                      >
                        <span className={css.queryOptionText}>{keyword}</span>
                        {active && <span className={css.queryOptionCheck}>✓</span>}
                      </button>
                    )
                  })}
                  <div className={css.queryMenuDivider} />
                  <div className={css.queryMenuHint}>Highlight up to 3 keywords</div>
                </div>
              )}
            </div>
          )}
          {meta.length > 0 && (
            <div className={css.batchMeta}>{meta.join(' · ')}</div>
          )}
        </div>
        <div className={css.batchHeaderRight}>
          <span className={css.batchTime}>{timeAgo}</span>
          {/* Collapse/expand toggle: chevron-only (universally understood);
              the tooltip keeps the verbose hint. */}
          <button
            type="button"
            className={css.collapseBtn}
            onClick={toggleCollapsed}
            aria-expanded={!collapsed}
            aria-label={collapsed ? 'Expand' : 'Collapse'}
            title={collapsed ? 'Expand' : 'Collapse'}
          >
            <span
              className={
                collapsed
                  ? css.collapseChevron
                  : `${css.collapseChevron} ${css.collapseChevronOpen}`
              }
            >
              ▾
            </span>
          </button>
        </div>
      </div>
      {collapsed ? (
        /* Collapsed: keep only the basic info — query keyword (in the
           header above), first-3 site icons and the total source count. */
        <div className={css.collapsedSummary}>
          <span className={css.summaryIcons}>
            {summaryItems.map(item => (
              <Favicon key={item.hostname} url={item.url} hostname={item.hostname} mini />
            ))}
          </span>
          <span className={css.summaryCount}>{batch.sources.length} sources</span>
        </div>
      ) : (
        <div className={css.sourcesList}>
          {batch.sources.map((source, si) => (
            <SourceCard
              key={si}
              source={source}
              highlights={highlights}
            />
          ))}
        </div>
      )}
    </div>
  )
}

function SourceCard(props: {
  source: AnySearchSource
  highlights?: HighlightTarget[]
}): JSX.Element {
  const { source } = props
  const hostname = safeHostname(source.url)
  const label = source.title || hostname

  return (
    <div className={css.sourceCard}>
      <Favicon url={source.url} hostname={hostname} />
      <div className={css.sourceBody}>
        <a
          className={css.sourceTitle}
          href={source.url}
          target="_blank"
          rel="noopener noreferrer"
          title={source.url}
        >
          {label}
        </a>
        <div className={css.sourceUrlLine}>
          <a
            className={css.sourceUrl}
            href={source.url}
            target="_blank"
            rel="noopener noreferrer"
            title={source.url}
          >
            {hostname}
          </a>
        </div>
        {source.snippet && (
          <div className={css.sourceSnippet}>{highlightSnippet(source.snippet, props.highlights ?? [])}</div>
        )}
      </div>
    </div>
  )
}

/**
 * Top-left favicon of one source card — two channels:
 *
 *  1. DIRECT: the BROWSER loads `<origin>/favicon.ico` first (real browser
 *     TLS fingerprint / network stack — hosts like openai.com that 403
 *     Node's fetch work here). A 3s watchdog falls back to the proxy.
 *  2. PROXY: the host's same-origin `/api/refs/favicon` route (background
 *     task, 3s timeout, disk-cache aware). Every direct hit is echoed to
 *     the proxy once per session so `assets/.favicon` stays populated.
 *
 * The card shows the hostname's initial letter as an immediate placeholder
 * (deterministic color per host). On total failure the letter badge stays
 * and both URLs are remembered so the session never re-requests them; a
 * rendered <img> that fails later falls back, never a broken icon.
 */
const DIRECT_FETCH_TIMEOUT_MS = 3000

function Favicon(props: {
  url: string
  hostname: string
  /** 16px variant used by the collapsed summary's stacked icon row. */
  mini?: boolean
}): JSX.Element {
  const { url, hostname } = props
  const proxyUrl = faviconProxyUrl(hostname)
  const directUrl = faviconDirectUrl(url)
  // Invalid hostnames or known-bad direct hosts skip the cross-origin
  // attempt entirely (silent letter badge / proxy only).
  const [attempt, setAttempt] = useState<'direct' | 'proxy'>(() =>
    isValidHostnameShape(hostname) && !persistentFailedHosts.has(hostname)
      ? 'direct'
      : 'proxy',
  )
  const [loaded, setLoaded] = useState(false)
  const currentUrl = attempt === 'direct' ? directUrl : proxyUrl

  useEffect(() => {
    // Hostname can never yield an icon — stay on the letter badge.
    if (!isValidHostnameShape(hostname)) {
      setLoaded(false)
      return
    }
    // Icon already fetched this page session on this channel: show it now.
    if (loadedFavicons.has(currentUrl)) {
      setLoaded(true)
      return
    }
    let settled = false
    const img = new Image()
    let watchdog: ReturnType<typeof setTimeout> | undefined

    if (attempt === 'direct' && !failedFavicons.has(proxyUrl)) {
      // Give the direct browser fetch a hard deadline, then hand over to
      // the host proxy (which answers from disk caches in ~0ms when known).
      watchdog = setTimeout(() => {
        if (settled) return
        settled = true
        img.src = ''
        setAttempt('proxy')
      }, DIRECT_FETCH_TIMEOUT_MS)
    }

    img.onload = () => {
      if (settled) return
      settled = true
      if (watchdog !== undefined) clearTimeout(watchdog)
      loadedFavicons.add(currentUrl)
      setLoaded(true)
      if (attempt === 'direct' && !proxiedHosts.has(hostname)) {
        // The browser showed the icon, but the DISK cache lives on the host:
        // echo one fire-and-forget proxy request so the host fetches and
        // persists it (disk hit → instant; WAF-blocked hosts → negative
        // cache, cost is one request per host per session at most).
        proxiedHosts.add(hostname)
        void fetch(proxyUrl).catch(() => {})
      }
    }
    img.onerror = () => {
      if (settled) return
      settled = true
      if (watchdog !== undefined) clearTimeout(watchdog)
      failedFavicons.add(currentUrl)
      if (attempt === 'direct') {
        // Remember across page loads: next session skips the doomed direct
        // request (which would log one console line) and goes proxy-only.
        saveFaviconFailure(hostname)
        if (failedFavicons.has(proxyUrl)) setLoaded(false)
        else setAttempt('proxy')
      } else {
        setLoaded(false)
      }
    }
    img.src = currentUrl
    return () => {
      settled = true
      if (watchdog !== undefined) clearTimeout(watchdog)
      img.src = ''
    }
  }, [attempt, currentUrl, directUrl, proxyUrl, hostname])

  if (loaded) {
    return (
      <img
        className={props.mini ? css.faviconMini : css.favicon}
        src={currentUrl}
        alt=""
        draggable={false}
        onError={() => {
          // A rendered icon that fails (cache lost, etc.) falls back to the
          // next channel or the letter badge — never a broken-image icon.
          loadedFavicons.delete(currentUrl)
          failedFavicons.add(currentUrl)
          if (attempt === 'direct') saveFaviconFailure(hostname)
          setLoaded(false)
          if (attempt === 'direct' && !failedFavicons.has(proxyUrl)) {
            setAttempt('proxy')
          }
        }}
      />
    )
  }
  return (
    <span
      className={props.mini ? css.faviconMiniFallback : css.faviconFallback}
      style={{ background: fallbackColor(hostname) }}
      title={hostname}
    >
      {(hostname.charAt(0) || '?').toUpperCase()}
    </span>
  )
}

// ── React hooks (from module table) ──────────────────────────────────

const { useState, useEffect, useCallback, useMemo, useRef } = require('react')

// ── Tab descriptor & registration ────────────────────────────────────

/**
 * Client plugin entry point (called by the DSH client runtime).
 * @param ctx - the client cordis context.
 */
export function apply(ctx: Context): void {
  // dsh-better-sidebar may not be installed — guard against it.
  if (!ctx.betterSidebar) {
    console.warn(`[dsh-anysearch-refs] dsh-better-sidebar not available; skipping tab registration`)
    return
  }

  ctx.effect(() =>
    ctx.betterSidebar!.registerTab({
      id: TAB_ID,
      title: 'AnySearch Refs',
      icon: (size: number) => <IconSearchOutline16 size={size} />,
      order: 60,
      single: true,
      // Keep AnySearch Refs in the right-hand workbench even when a search
      // result auto-opens it from another active pane.
      createTab: (state) => ({
        tab: { id: TAB_ID, type: TAB_ID, title: 'AnySearch Refs' },
        patch: { activePane: rightLeafForRefs(state) },
      }),
      component: (props) => <AnySearchRefsTab {...props} />,
    }),
  )

  // Background watcher: when AnySearch result batches appear, open the
  // sidebar tab (and expand the right panel) without waiting for the user to
  // click the + menu. The first observation of a session records the baseline
  // while still surfacing results that were already present; later polls only
  // auto-open on a changed signature.
  ctx.effect(() => {
    const service = ctx.betterSidebar
    if (!service || typeof service.getSnapshot !== 'function' || typeof service.openTab !== 'function') {
      return undefined
    }

    const seen = new Map<string, string>()
    let disposed = false
    let controller: AbortController | undefined

    const loop = async (): Promise<void> => {
      let first = true
      while (!disposed) {
        const sessionId = service.getSnapshot()?.sessionId
        if (!sessionId || service.isTabEnabled?.(TAB_ID) === false) {
          // No active session yet or the tab is disabled. Retry shortly —
          // this watcher runs for the whole profile lifetime and must recover
          // as soon as a session becomes available (unlike a one-shot poll).
          await new Promise(r => setTimeout(r, 1000))
          continue
        }

        controller?.abort()
        const ctrl = new AbortController()
        controller = ctrl
        try {
          // First call immediate, then long-poll: the host wakes us only when
          // this session's AnySearch data changes (or the 30s keepalive fires).
          const data = await fetchResults(sessionId, ctrl.signal, !first)
          if (disposed || ctrl.signal.aborted) return
          if (service.getSnapshot()?.sessionId !== sessionId) {
            // Session switched while the request was in flight — restart for
            // the new session instead of dropping out of the loop.
            first = true
            continue
          }
          const batches = data.batches ?? []
          const signature = resultsSignature(batches)
          const previous = seen.get(sessionId)
          if (signature.length > 0 && signature !== previous) {
            service.openTab(
              { type: TAB_ID, title: 'AnySearch Refs', path: AUTO_OPEN_SEED_PATH },
              { sessionId },
            )
          }
          seen.set(sessionId, signature)
          first = false
        } catch (err) {
          if (ctrl.signal.aborted || disposed) return
          console.warn(`[dsh-anysearch-refs] auto-open poll failed: ${err instanceof Error ? err.message : String(err)}`)
          await new Promise(r => setTimeout(r, 2000))
        }
      }
    }

    void loop()

    return () => {
      disposed = true
      controller?.abort()
    }
  }, 'dsh-anysearch-refs: auto-open watcher')
}
