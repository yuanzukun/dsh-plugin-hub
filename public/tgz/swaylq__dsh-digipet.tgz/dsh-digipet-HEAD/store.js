/**
 * dsh-digipet store — the save file and the feeding valve.
 *
 * One pet per harness home, saved at `$DSH_HOME/digipet/state.json` the same
 * way the official JSON storage backend persists: write a sibling temp file,
 * fsync, then atomically rename over the old save. Feeds are throttled to one
 * disk write per interval so a busy agent doesn't turn every tool call into IO.
 *
 * @module dsh-digipet/store
 */

import { closeSync, fsyncSync, mkdirSync, openSync, readFileSync, renameSync, writeSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join, resolve } from 'node:path'

import { feed as coreFeed, evolve as coreEvolve, layEgg, migrate, rename as coreRename } from './core.js'

/** The harness home, matching the launcher's own resolution. */
export function dshHome() {
  const configured = process.env.DSH_HOME
  return configured !== undefined && configured.trim() !== ''
    ? resolve(configured.trim())
    : join(homedir(), '.dsh')
}

/** Default save location. */
export function defaultStatePath() {
  return join(dshHome(), 'digipet', 'state.json')
}

const SAVE_THROTTLE_MS = 1500

/**
 * Open (or lazily create on first hatch) the save file.
 * @param filePath - where the save lives.
 * @param options.now - injectable clock for tests.
 * @param options.setTimer / options.clearTimer - injectable scheduler for tests.
 */
export function createStore(filePath = defaultStatePath(), options = {}) {
  const now = options.now ?? (() => Date.now())
  const setTimer = options.setTimer ?? setTimeout
  const clearTimer = options.clearTimer ?? clearTimeout

  let dirty = false
  let timer = null
  let state = load()

  function load() {
    try {
      const parsed = JSON.parse(readFileSync(filePath, 'utf8'))
      const upgraded = migrate(parsed)
      // An old save was upgraded in memory; persist the new shape soon.
      if (upgraded && parsed.version !== upgraded.version) dirty = true
      return upgraded
    } catch {
      return null
    }
  }

  function writeNow() {
    if (!dirty || state === null) return
    mkdirSync(dirname(filePath), { recursive: true })
    const tmp = `${filePath}.tmp`
    const fd = openSync(tmp, 'w')
    try {
      writeSync(fd, JSON.stringify(state))
      fsyncSync(fd)
    } finally {
      closeSync(fd)
    }
    renameSync(tmp, filePath)
    dirty = false
  }

  function scheduleSave() {
    dirty = true
    if (timer !== null) return
    timer = setTimer(() => {
      timer = null
      try { writeNow() } catch { /* a pet must never break the harness */ }
    }, SAVE_THROTTLE_MS)
    if (typeof timer?.unref === 'function') timer.unref()
  }

  return {
    /** The live state (null until an egg is laid). Exposed for rendering. */
    get state() { return state },

    /** Digest one observed harness event; silently ignored before the first hatch. */
    feed(event) {
      if (state === null) return
      coreFeed(state, event, now())
      scheduleSave()
    },

    /** Lay the egg. Returns false when a pet already exists. */
    hatch() {
      if (state !== null) return false
      state = layEgg(now())
      scheduleSave()
      return true
    },

    /** Run the evolution ceremony; null when the pet isn't ready (or absent). */
    evolve() {
      if (state === null) return null
      const change = coreEvolve(state, now())
      if (change) scheduleSave()
      return change
    },

    /** Rename the pet; null when the name is unusable or the pet is absent. */
    rename(rawName) {
      if (state === null) return null
      const cleaned = coreRename(state, rawName, now())
      if (cleaned) scheduleSave()
      return cleaned
    },

    /** Flush any pending write and stop the timer. Called on plugin unload. */
    dispose() {
      if (timer !== null) {
        clearTimer(timer)
        timer = null
      }
      try { writeNow() } catch { /* best effort on the way out */ }
    },
  }
}
