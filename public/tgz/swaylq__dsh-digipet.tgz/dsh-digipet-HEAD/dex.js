/**
 * dsh-digipet dex — every form the creature can take, and the cards `/pet` prints.
 *
 * Pure data and string builders; no IO, no harness imports. The roster honors
 * classic V-pet raising canon: three shared baby forms, four lineages whose
 * silhouettes nod to the genre's most iconic evolution arcs (dino-with-skull-
 * helmet warriors, robed sages, winged guardians, network-virus crawlers),
 * and a stray line for care mistakes — the slug, its redemption, and its
 * magnificent doubling-down. All names and art are original; no franchise
 * names or assets are used.
 *
 * Art is deliberately narrow (≤32 columns) and tolerant of proportional
 * fonts: each line reads on its own.
 *
 * @module dsh-digipet/dex
 */

import { STAGE_ZH, STAGE_EN, THRESHOLDS, mood, progress, settleFullness } from './core.js'

/** Display order and labels of the lineages. */
export const LINE_INFO = {
  dragon: { zh: '龙之系谱', hint: '写文件、跑命令喂出来的战斗种' },
  sage: { zh: '贤者系谱', hint: '读代码、查资料喂出来的智慧种' },
  angel: { zh: '圣翼系谱', hint: '一句一句聊出来的守护种' },
  virus: { zh: '病毒系谱', hint: '在报错和事故里泡大的异端种' },
  stray: { zh: '迷途系谱', hint: '照顾失误才会遇见的形态' },
}

/** All 22 forms. `id` = line + stage; egg0/baby1/baby2 shared; slug/bear/king stray. */
export const DEX = {
  egg0: {
    zh: '数码蛋', en: 'DigiEgg', line: null, stage: 0,
    flavor: '有东西在里面敲键盘。',
    art: [
      '    .-""-.',
      '   / ◢◤◢◤ \\',
      '  |  ◥◣◥◣  |',
      '   \\ ◢◤◢◤ /',
      "    '----'",
    ],
  },
  baby1: {
    zh: '比特泡', en: 'Bitpop', line: null, stage: 1,
    flavor: '一颗刚立了 flag 的比特，还不知道自己要变成什么。',
    art: [
      '    ▗▄▚▚▄▖',
      '   ▐ ◉  ◉ ▌',
      '    ▝▚▄▄▞▘  。o',
    ],
  },
  baby2: {
    zh: '字节球', en: 'Bytebun', line: null, stage: 2,
    ceremony: '它蜕了一层皮，个头大了一圈。',
    flavor: '八个比特手拉手，凑成了一个会打滚的字节。',
    art: [
      '   ⌒∩    ∩⌒',
      '  (  ◕  ◕  )',
      '   )  ‿‿  (',
      '  (________)',
    ],
  },

  dragon3: {
    zh: '锤锤龙', en: 'Hammerdino', line: 'dragon', stage: 3,
    flavor: '先敲了再说，这是它的开发流程。',
    art: [
      '     ____',
      '    /o   \\__',
      '   (  ᗢ     \\',
      '    \\_ 🔨 __/',
      '     /|  /|',
    ],
  },
  dragon4: {
    zh: '骨盔暴龙', en: 'Skullhelm Rex', line: 'dragon', stage: 4,
    flavor: '头上的骨盔，是上一个版本的自己留下的。',
    art: [
      '   ▽  ___  ▽',
      '    \\/o o\\/',
      '    |^^^^^|',
      '   _/ΞΞΞΞΞ\\_',
      '    /|   /|',
    ],
  },
  dragon5: {
    zh: '铁腕机暴龙', en: 'Ironclaw Mecha-Rex', line: 'dragon', stage: 5,
    flavor: '左臂换成了液压的，deploy 的时候会喷蒸汽。',
    art: [
      '   ⚡ )))',
      '    (o_■)',
      '   ▐▓▓▓▓▌═╦═🦾',
      '    |◎ ◎ ◎|',
      '    /|   /|',
    ],
  },
  dragon6: {
    zh: '战铠龙皇', en: 'Wardrake Sovereign', line: 'dragon', stage: 6,
    flavor: '双爪专为屠龙而生 —— 屠的是祖传屎山那条。',
    art: [
      '     /\\Λ/\\',
      '    ( ◣_◢ )',
      '   ⟨⟨ ▣▣▣ ⟩⟩',
      '   ╪╪    ╪╪',
      '     /| |\\',
    ],
  },

  sage3: {
    zh: '书虫精', en: 'Bookwyrmling', line: 'sage', stage: 3,
    flavor: '一天不啃文档就浑身发痒。',
    art: [
      '    @@@@',
      '   (◎ _ ◎)',
      '   /|▁▁▁▁|\\',
      '    |▒▒▒▒|',
      '     ~~~~',
    ],
  },
  sage4: {
    zh: '魔导枭', en: 'Grimoire Owl', line: 'sage', stage: 4,
    flavor: '帽子里塞满了没读完的 RFC。',
    art: [
      '      /\\',
      '     /__\\ ˚',
      '   (◉ ∨ ◉)',
      '   /| ⚚  |\\',
      '     ^  ^',
    ],
  },
  sage5: {
    zh: '卷轴阴阳狐', en: 'Scrollkitsune', line: 'sage', stage: 5,
    flavor: '甩出去的每张符，都是一条精心压行的 one-liner。',
    art: [
      '    /\\¸¸/\\',
      '   ( ˘ ᴥ ˘ )',
      '  ⌇)  ☲☲  (⌇',
      '   /|    |\\',
      '   ~ 九条尾巴 ~',
    ],
  },
  sage6: {
    zh: '天书贤神', en: 'Codex Deva', line: 'sage', stage: 6,
    flavor: '它读完了整个互联网，包括 404 的那部分。',
    art: [
      '    ✦  ˚  ✦',
      '    ( ◉‿◉ )',
      '   ╔══▤▤▤══╗',
      '   ╚═══╤═══╝',
      '       ✧',
    ],
  },

  angel3: {
    zh: '守护小翼', en: 'Wingpal', line: 'angel', stage: 3,
    flavor: '翅膀还不够大，先用来给你扇风。',
    art: [
      '   <\\    />',
      '   ( ^  ^ )',
      '   (  ‿‿  )',
      '     v  v',
    ],
  },
  angel4: {
    zh: '六翼守卫', en: 'Hexawing Guard', line: 'angel', stage: 4,
    flavor: '你熬夜的时候，它的光环就是台灯。',
    art: [
      '   ≪≪ ○ ≫≫',
      '     [ō ]',
      '    /|=†=|\\',
      '   ≪  / \\  ≫',
    ],
  },
  angel5: {
    zh: '圣剑大天使', en: 'Holyblade Archon', line: 'angel', stage: 5,
    flavor: '圣剑出鞘只为一件事：替你把 deadline 斩了。',
    art: [
      '  ≪≪≪ ✦ ≫≫≫',
      '     [ō_]',
      '    /| ⊕ |\\',
      '     _/ \\_',
      '   剑光画了个门',
    ],
  },
  angel6: {
    zh: '炽天使皇', en: 'Seraph Prime', line: 'angel', stage: 6,
    flavor: '十片翅膀：一片陪你聊天，九片替你挡事故。',
    art: [
      '  ≪≪≪≪ ✦ ≫≫≫≫',
      '     (■_■)',
      '    ⟨| ♡ |⟩',
      '   ≪≪ / \\ ≫≫',
    ],
  },

  virus3: {
    zh: '独眼比特鬼', en: 'Bitghast', line: 'virus', stage: 3,
    flavor: '在坏道里出生，把报错当摇篮曲。',
    art: [
      '    ▚ __ ▞',
      '   (  ◉  )',
      '   ╱╱|╲╲',
      '    ▞  ▚',
    ],
  },
  virus4: {
    zh: '咯咯虫', en: 'Gigglegrub', line: 'virus', stage: 4,
    flavor: '每吞掉一个异常就咯咯笑一声，你 debug 时它笑个不停。',
    art: [
      '   ▚▚ ____ ▞▞',
      '    ( ◉‿◉ )嘻',
      '    ╱╱|||╲╲',
      '     ~ ~ ~',
    ],
  },
  virus5: {
    zh: '茧速魔蛛', en: 'Cocoonrusher', line: 'virus', stage: 5,
    flavor: '在防火墙之间弹跳，比你的重试逻辑还快。',
    art: [
      '    ╱▔▔▔▔▔╲',
      '   ⟨ ▒◉▒◉▒ ⟩',
      '    ╲▁▁▁▁▁╱',
      '   ╱╱╲╲ ╱╱╲╲',
    ],
  },
  virus6: {
    zh: '末日蛛皇', en: 'Doomweaver', line: 'virus', stage: 6,
    flavor: '它在一千万个进程里同时存在，kill -9 只会让它分裂。',
    art: [
      '     ◢▚▚◣',
      '    ( ⊙▒⊙ )',
      '   ╱╱▔▔|▔▔╲╲',
      '  ╱╱    |    ╲╲',
      '   pid: 全部',
    ],
  },

  slug4: {
    zh: '缓存泥', en: 'Cacheslug', line: 'stray', stage: 4,
    ceremony: '光芒包住了它……等等，这光怎么是绿的？（你在它吃撑的时候按下了进化。）',
    hint: '谣传：吃撑的时候进化，会出事。',
    flavor: '从没清理过的缓存成了精。它不怪你，但它记得。',
    art: [
      '    .▄▄▄▄.',
      '   ( ˃ ﹏ ˂ )',
      '    ))))))))',
      '    ~~ U ~~',
    ],
  },
  bear5: {
    zh: '蜜罐熊', en: 'Honeypot Bear', line: 'stray', stage: 5,
    ceremony: '泥里伸出了一只毛茸茸的手。',
    hint: '谣传：迷途的泥，也能被爱救赎。',
    flavor: '被爱救赎的泥，从此专职抱抱与钓鱼执法。',
    art: [
      '    ʕ •ᴥ• ʔ',
      '   /|  ♥  |\\',
      '   (蜜)  (罐)',
      '     ▙    ▟',
    ],
  },
  king5: {
    zh: '屎山王', en: 'Mount Legacy', line: 'stray', stage: 5,
    ceremony: '它看了看自己，决定摆烂到底。',
    hint: '谣传：一错再错，终成祖传。',
    flavor: '每一坨都是祖传的，动一下就崩，但它引以为荣。',
    art: [
      '       ♛',
      '     ▗▄▀▄▖',
      '    ▗▀▄▀▄▀▖',
      '   ▗▀▄▀▄▀▄▀▖',
      '   // 别动。',
    ],
  },
}

const BAR_CELLS = 10

/** A `██████░░░░` progress bar. */
export function bar(ratio) {
  const filled = Math.round(Math.max(0, Math.min(1, ratio)) * BAR_CELLS)
  return '█'.repeat(filled) + '░'.repeat(BAR_CELLS - filled)
}

const fmtDay = ms => {
  const d = new Date(ms)
  const p = n => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

const STAT_ZH = { build: '锻造', lore: '学识', bond: '羁绊', grit: '皮实' }

/** The pet's display title: given name, or the form's species name. */
export function title(state) {
  const form = DEX[state.form] ?? DEX.egg0
  return state.name ? `${state.name}（${form.zh}）` : `${form.zh} ${form.en}`
}

/** The `/pet` status card. */
export function renderStatus(state, now) {
  settleFullness(state, now)
  const form = DEX[state.form] ?? DEX.egg0
  const lines = []
  // Stage 0's stage name equals the form name; repeating it reads silly.
  lines.push(state.stage === 0 ? title(state) : `${title(state)} · ${STAGE_ZH[state.stage]} ${STAGE_EN[state.stage]}`)
  lines.push('')
  lines.push(...form.art)
  lines.push('')
  const p = progress(state)
  if (state.stage === 0) {
    lines.push(`破壳进度 ${bar(p.ratio)} ${Math.floor(p.ratio * 100)}%（XP ${p.have}/${p.need}）`)
    lines.push('蛋在你干活的时候悄悄吸收数据。聊几句、跑几个工具再回来看看。')
  } else {
    if (p) {
      lines.push(`XP ${p.have} ▸ 下一阶段 ${p.need}   ${bar(p.ratio)}`)
    } else {
      lines.push(`XP ${Math.floor(state.xp)} ▸ 已是究极体，前面没有路了，只有海。`)
    }
    lines.push(`饱食 ${Math.round(state.fullness)}%   心情 ${mood(state, now)}`)
    const s = state.stats
    lines.push(`属性  锻造 ${Math.floor(s.build)} · 学识 ${Math.floor(s.lore)} · 羁绊 ${Math.floor(s.bond)} · 皮实 ${Math.floor(s.grit)}`)
    const c = state.counters
    lines.push(`累计吞食  回合 ${c.turns} · 工具 ${c.toolCalls} · 消息 ${c.messages} · 事故 ${c.mishaps}`)
  }
  if (state.pending) {
    lines.push('')
    lines.push(state.stage === 0 ? '⚡ 蛋壳在动！/pet evolve 见证破壳' : '⚡ 它可以进化了！/pet evolve 见证仪式')
  }
  return lines.join('\n')
}

/** The ceremony card printed by `/pet evolve`. */
export function renderEvolution(state, change) {
  const from = DEX[change.from]
  const to = DEX[change.to]
  const lines = []
  if (change.to === 'baby1') {
    lines.push('蛋壳裂开了 ——')
  } else if (to.ceremony) {
    lines.push(to.ceremony)
  } else {
    lines.push(`光芒包住了${from.zh} —— 这段日子喂得最多的是「${STAT_ZH[change.dominant]}」。`)
  }
  lines.push('')
  lines.push(...to.art)
  lines.push('')
  lines.push(`✨ ${from.zh} 进化为 ${to.zh} ${to.en}（${STAGE_ZH[to.stage]}）`)
  lines.push(`「${to.flavor}」`)
  if (to.line) lines.push(`系谱：${LINE_INFO[to.line].zh} —— ${LINE_INFO[to.line].hint}`)
  lines.push('')
  lines.push('图鉴已记录：/pet dex 查看收集进度')
  return lines.join('\n')
}

/** The `/pet dex` collection page. */
export function renderDex(state) {
  const seen = new Set(state?.discovered ?? [])
  const lines = [`图鉴 ${seen.size}/${Object.keys(DEX).length}`, '']
  const row = (id) => {
    const f = DEX[id]
    const stageTag = f.stage === 0 ? '' : ` · ${STAGE_ZH[f.stage]}`
    if (seen.has(id)) return `  ● ${f.zh} ${f.en}${stageTag} —— ${f.flavor}`
    const veil = f.hint ? ` ——「${f.hint}」` : ''
    return `  ○ ？？？${stageTag || ' · 蛋'}${veil}`
  }
  lines.push('共通', row('egg0'), row('baby1'), row('baby2'), '')
  for (const line of ['dragon', 'sage', 'angel', 'virus']) {
    const info = LINE_INFO[line]
    lines.push(`${info.zh}（${info.hint}）`)
    for (let stage = 3; stage <= 6; stage++) lines.push(row(`${line}${stage}`))
    lines.push('')
  }
  lines.push(`${LINE_INFO.stray.zh}（${LINE_INFO.stray.hint}）`)
  for (const id of ['slug4', 'bear5', 'king5']) lines.push(row(id))
  return lines.join('\n').trimEnd()
}

/** The `/pet story` life journal. */
export function renderStory(state) {
  const lines = [`${title(state)} 的一生`, '']
  for (const entry of state.journal) {
    const day = fmtDay(entry.at)
    if (entry.kind === 'egg') lines.push(`  ${day}  一颗数码蛋落进了 harness。`)
    else if (entry.kind === 'hatch') lines.push(`  ${day}  破壳而出 → ${DEX[entry.to]?.zh ?? entry.to}`)
    else if (entry.kind === 'rename') lines.push(`  ${day}  得到了名字「${entry.to}」`)
    else if (entry.kind === 'evolve') {
      const suffix = entry.dominant ? `（这一阶段最亮眼：${STAT_ZH[entry.dominant] ?? '?'}）` : ''
      lines.push(`  ${day}  进化 → ${DEX[entry.to]?.zh ?? entry.to}${suffix}`)
    }
  }
  return lines.join('\n')
}

/** XP thresholds table for `/pet about`. */
export function renderAbout(commandName) {
  return [
    'dsh-digipet —— 吃你真实工作长大的数码兽。',
    '',
    '它怎么吃：每个完成的回合 +5 XP，每条你的消息 +2，每次工具调用 +3，',
    '每次报错 +2~4（喂「皮实」）。吃撑了会犯困，经验减益，睡醒继续。',
    `进化门槛：${THRESHOLDS.join(' / ')} XP，数码蛋起共 7 个节点。`,
    '成长期起每次进化按这一阶段喂得最多的属性选系谱：',
    '锻造 → 龙之系谱 · 学识 → 贤者系谱 · 羁绊 → 圣翼系谱 · 皮实 → 病毒系谱。',
    '图鉴里还有三个没写在这里的形态。老玩家的忠告：别在它吃撑的时候按进化。',
    '',
    '信任立场：不注册模型工具、不注入上下文 —— 模型不知道它存在，',
    '零 token 开销；不联网；只读写自己的存档 ($DSH_HOME/digipet/state.json)。',
    '事件监听全部包在 try/catch 里，宠物永远不会打断你的工作。',
    '',
    `命令：/${commandName} · /${commandName} hatch · /${commandName} evolve · /${commandName} name <名字> · /${commandName} dex · /${commandName} story`,
  ].join('\n')
}
