import assert from 'node:assert/strict'
import { test } from 'node:test'

import {
  appetite, classify, dominantStat, evolve, feed, layEgg, migrate, progress, rename,
  STUFFED_EVOLUTION_FULLNESS, THRESHOLDS,
} from '../core.js'

/** A clock that jumps a minute per feed, so fullness decay keeps up with meals. */
function makeClock(start = 1_000_000) {
  let t = start
  return { now: () => t, tick: (ms = 60_000) => { t += ms; return t } }
}

test('classify: mutating names feed 锻造, observing names feed 学识, unknown is neutral', () => {
  assert.equal(classify('write_file'), 'toolBuild')
  assert.equal(classify('shell'), 'toolBuild')
  assert.equal(classify('str_replace_editor'), 'toolBuild')
  assert.equal(classify('run_code'), 'toolBuild')
  assert.equal(classify('read_file'), 'toolLore')
  assert.equal(classify('web_search'), 'toolLore')
  assert.equal(classify('grep'), 'toolLore')
  assert.equal(classify('ask_user'), 'toolNeutral')
  assert.equal(classify(undefined), 'toolNeutral')
})

test('an egg absorbs XP and turns pending exactly at the hatch threshold', () => {
  const clock = makeClock()
  const pet = layEgg(clock.now())
  for (let i = 0; i < 5; i++) feed(pet, 'turn', clock.tick())
  assert.equal(pet.pending, false, '25 XP is not enough')
  feed(pet, 'turn', clock.tick())
  assert.equal(Math.floor(pet.xp), 30)
  assert.equal(pet.pending, true)
  assert.equal(pet.stage, 0)
})

test('fullness dampens gains and decays over time', () => {
  const clock = makeClock()
  const pet = layEgg(clock.now())
  // Gorge without letting time pass: fullness climbs, appetite collapses.
  for (let i = 0; i < 100; i++) feed(pet, 'turn', clock.now())
  assert.ok(pet.fullness > 90, `expected stuffed, got ${pet.fullness}`)
  const before = pet.xp
  feed(pet, 'turn', clock.now())
  assert.ok(pet.xp - before < 1, 'a stuffed pet barely nibbles')
  // Sleep an hour: fullness drains back down.
  feed(pet, 'turn', clock.tick(60 * 60_000))
  assert.ok(pet.fullness < 70, `expected digested, got ${pet.fullness}`)
  assert.equal(appetite(0), 1)
  assert.equal(appetite(75), 0.5)
  assert.equal(appetite(95), 0.15)
})

test('the baby chain: egg hatches at 30, molts into Baby Ⅱ at 120', () => {
  const clock = makeClock()
  const pet = layEgg(clock.now())
  while (!pet.pending) feed(pet, 'message', clock.tick())
  const hatch = evolve(pet, clock.tick())
  assert.deepEqual(hatch, { from: 'egg0', to: 'baby1', dominant: null })
  assert.equal(pet.stage, 1)
  assert.deepEqual(pet.window, { build: 0, lore: 0, bond: 0, grit: 0 })
  assert.ok(pet.discovered.includes('baby1'))
  assert.equal(pet.journal.at(-1).kind, 'hatch')
  while (!pet.pending) feed(pet, 'message', clock.tick())
  assert.ok(pet.xp >= THRESHOLDS[1])
  const molt = evolve(pet, clock.tick())
  assert.deepEqual(molt, { from: 'baby1', to: 'baby2', dominant: null })
  assert.equal(pet.stage, 2)
  assert.equal(pet.journal.at(-1).kind, 'evolve')
})

/** Grow a fresh pet to a given stage on a fixed diet. */
function grow(diet, targetStage) {
  const clock = makeClock()
  const pet = layEgg(clock.now())
  while (pet.stage < targetStage) {
    while (!pet.pending) feed(pet, diet, clock.tick())
    evolve(pet, clock.tick())
  }
  return { pet, clock }
}

test('each diet grows its own lineage at Child', () => {
  assert.equal(grow('toolBuild', 3).pet.form, 'dragon3')
  assert.equal(grow('toolLore', 3).pet.form, 'sage3')
  assert.equal(grow('message', 3).pet.form, 'angel3')
  assert.equal(grow('agentError', 3).pet.form, 'virus3')
})

test('a pet can switch lineages when the diet changes between stages', () => {
  const { pet, clock } = grow('toolBuild', 3)
  assert.equal(pet.form, 'dragon3')
  while (!pet.pending) feed(pet, 'agentError', clock.tick())
  const change = evolve(pet, clock.tick())
  assert.equal(change.dominant, 'grit')
  assert.equal(pet.form, 'virus4', 'the new stage reads the new window')
})

test('a neutral-only window falls back to the angel line', () => {
  const { pet } = grow('turn', 3)
  assert.equal(pet.form, 'angel3')
})

test('window ties break toward the rarer stat', () => {
  const pet = layEgg(1000)
  pet.window = { build: 5, lore: 5, bond: 0, grit: 0 }
  assert.equal(dominantStat(pet), 'build')
  pet.window = { build: 5, lore: 5, bond: 5, grit: 5 }
  assert.equal(dominantStat(pet), 'grit')
})

test('the full arc reaches 究极体 and then the road ends', () => {
  const { pet } = grow('toolBuild', 6)
  assert.equal(pet.form, 'dragon6')
  assert.ok(pet.xp >= THRESHOLDS.at(-1))
  assert.equal(pet.pending, false)
  assert.equal(evolve(pet, 9e12), null, 'no stage above ultimate')
  assert.equal(progress(pet), null)
})

test('evolving into Adult while stuffed is a care mistake: hello, slug', () => {
  const { pet, clock } = grow('toolBuild', 3)
  while (!pet.pending) feed(pet, 'turn', clock.tick())
  // Stuff it at the last moment: rapid meals with no time passing.
  while (pet.fullness < STUFFED_EVOLUTION_FULLNESS) feed(pet, 'turn', clock.now())
  const change = evolve(pet, clock.now())
  assert.equal(change.to, 'slug4')
  assert.equal(pet.form, 'slug4')
  assert.equal(pet.line, 'stray')
  assert.equal(pet.stage, 4)
})

/** Grow a slug the canonical way: clean to Child, stuff at the Adult ceremony. */
function growSlug() {
  const { pet, clock } = grow('toolBuild', 3)
  while (!pet.pending) feed(pet, 'turn', clock.tick())
  while (pet.fullness < STUFFED_EVOLUTION_FULLNESS) feed(pet, 'turn', clock.now())
  evolve(pet, clock.now())
  return { pet, clock }
}

test('a bond-heavy slug redeems into the bear; anything else doubles down as the king', () => {
  const redeemed = growSlug()
  while (!redeemed.pet.pending) feed(redeemed.pet, 'message', redeemed.clock.tick())
  assert.equal(evolve(redeemed.pet, redeemed.clock.tick()).to, 'bear5')

  const doubled = growSlug()
  while (!doubled.pet.pending) feed(doubled.pet, 'agentError', doubled.clock.tick())
  assert.equal(evolve(doubled.pet, doubled.clock.tick()).to, 'king5')
})

test('the stray line rejoins a proper lineage at Ultimate', () => {
  const { pet, clock } = growSlug()
  while (!pet.pending) feed(pet, 'agentError', clock.tick())
  evolve(pet, clock.tick())
  assert.equal(pet.form, 'king5')
  while (!pet.pending) feed(pet, 'toolBuild', clock.tick())
  const change = evolve(pet, clock.tick())
  assert.equal(change.to, 'dragon6', 'redemption arc complete')
  assert.equal(pet.line, 'dragon')
})

test('a clean Adult evolution is not slandered as a slug', () => {
  const { pet, clock } = grow('toolBuild', 3)
  while (!pet.pending) feed(pet, 'toolBuild', clock.tick())
  assert.ok(pet.fullness < STUFFED_EVOLUTION_FULLNESS)
  assert.equal(evolve(pet, clock.tick()).to, 'dragon4')
})

test('evolve without pending is refused', () => {
  const clock = makeClock()
  const pet = layEgg(clock.now())
  assert.equal(evolve(pet, clock.now()), null)
})

test('rename trims, collapses whitespace, caps at 16 chars, refuses emptiness', () => {
  const clock = makeClock()
  const pet = layEgg(clock.now())
  assert.equal(rename(pet, '  阿  尔  法  ', clock.now()), '阿 尔 法')
  assert.equal(rename(pet, 'x'.repeat(40), clock.now()), 'x'.repeat(16))
  assert.equal(rename(pet, '   ', clock.now()), null)
  assert.equal(pet.name, 'x'.repeat(16))
})

test('progress reports the band inside the current stage', () => {
  const clock = makeClock()
  const pet = layEgg(clock.now())
  feed(pet, 'turn', clock.tick())
  feed(pet, 'turn', clock.tick())
  feed(pet, 'turn', clock.tick())
  const p = progress(pet)
  assert.equal(p.have, 15)
  assert.equal(p.need, 30)
  assert.ok(Math.abs(p.ratio - 0.5) < 0.01)
})

test('migrate upgrades a v1 save: stages shift, sea creatures become canon forms', () => {
  const v1 = {
    version: 1,
    createdAt: 1000,
    name: '小蓝',
    stage: 3,
    form: 'forge3',
    line: 'forge',
    xp: 1500,
    pending: true,
    stats: { build: 900, lore: 100, bond: 50, grit: 20 },
    window: { build: 40, lore: 0, bond: 0, grit: 0 },
    fullness: 10,
    fullnessAt: 2000,
    counters: { turns: 100, toolCalls: 200, messages: 30, mishaps: 5 },
    discovered: ['egg0', 'baby1', 'forge2', 'forge3'],
    journal: [
      { at: 1000, kind: 'egg' },
      { at: 1100, kind: 'hatch', from: 'egg0', to: 'baby1', dominant: null },
      { at: 1200, kind: 'rename', to: '小蓝' },
      { at: 1300, kind: 'evolve', from: 'baby1', to: 'forge2', dominant: 'build' },
      { at: 1400, kind: 'evolve', from: 'forge2', to: 'forge3', dominant: 'build' },
    ],
    lastSeenAt: 1400,
  }
  const s = migrate(structuredClone(v1))
  assert.equal(s.version, 2)
  assert.equal(s.stage, 4, 'old adult (3) becomes new Adult (4)')
  assert.equal(s.form, 'dragon4')
  assert.equal(s.line, 'dragon')
  assert.deepEqual(s.discovered, ['egg0', 'baby1', 'dragon3', 'dragon4'])
  assert.equal(s.journal[2].to, '小蓝', 'rename entries are not form ids')
  assert.equal(s.journal[3].to, 'dragon3')
  assert.equal(s.journal[4].to, 'dragon4')
  assert.equal(s.pending, false, 'xp 1500 does not clear the new 6000 bar')
  assert.equal(s.xp, 1500, 'progress carries over untouched')

  assert.equal(migrate({ version: 2, anything: true }).version, 2, 'v2 passes through')
  assert.equal(migrate({ version: 99 }), null)
  assert.equal(migrate('garbage'), null)
  assert.equal(migrate(null), null)
})
