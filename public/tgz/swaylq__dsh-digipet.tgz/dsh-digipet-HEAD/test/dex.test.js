import assert from 'node:assert/strict'
import { test } from 'node:test'

import { evolve, feed, layEgg, STUFFED_EVOLUTION_FULLNESS } from '../core.js'
import { DEX, LINE_INFO, bar, renderAbout, renderDex, renderEvolution, renderStatus, renderStory, title } from '../dex.js'

test('the dex is complete: 3 shared + 4 lineages × 4 stages + 3 stray forms', () => {
  assert.equal(Object.keys(DEX).length, 22)
  assert.ok(DEX.egg0 && DEX.baby1 && DEX.baby2)
  for (const line of ['dragon', 'sage', 'angel', 'virus']) {
    for (let stage = 3; stage <= 6; stage++) {
      const form = DEX[`${line}${stage}`]
      assert.ok(form, `${line}${stage} missing`)
      assert.equal(form.line, line)
      assert.equal(form.stage, stage)
    }
  }
  for (const id of ['slug4', 'bear5', 'king5']) {
    assert.equal(DEX[id].line, 'stray')
    assert.ok(DEX[id].hint, `${id} needs a veiled dex hint`)
    assert.ok(DEX[id].ceremony, `${id} needs its own ceremony line`)
  }
  for (const [id, form] of Object.entries(DEX)) {
    assert.ok(form.zh && form.en && form.flavor, `${id} incomplete`)
    assert.ok(Array.isArray(form.art) && form.art.length >= 3, `${id} art too small`)
    assert.ok(form.art.every(row => row.length <= 34), `${id} art too wide`)
    if (form.line) assert.ok(LINE_INFO[form.line], `${id} has unknown line`)
  }
})

test('bar clamps and fills', () => {
  assert.equal(bar(0), '░'.repeat(10))
  assert.equal(bar(1), '█'.repeat(10))
  assert.equal(bar(2), '█'.repeat(10))
  assert.equal(bar(0.52), '█'.repeat(5) + '░'.repeat(5))
})

test('the egg card shows hatch progress; a grown card shows stats', () => {
  const pet = layEgg(1000)
  feed(pet, 'turn', 61_000)
  const eggCard = renderStatus(pet, 61_000)
  assert.match(eggCard, /数码蛋/)
  assert.match(eggCard, /破壳进度/)
  assert.match(eggCard, /XP 5\/30/)
  assert.doesNotMatch(eggCard.split('\n')[0], /数码蛋 DigiEgg · 数码蛋/, 'no doubled stage name at stage 0')

  while (!pet.pending) feed(pet, 'message', pet.lastSeenAt + 60_000)
  evolve(pet, pet.lastSeenAt + 1)
  const fryCard = renderStatus(pet, pet.lastSeenAt + 2)
  assert.match(fryCard, /比特泡/)
  assert.match(fryCard, /幼年期Ⅰ/)
  assert.match(fryCard, /下一阶段 120/)
  assert.match(fryCard, /羁绊/)
  assert.match(fryCard, /累计吞食/)
})

test('a pending pet is invited to evolve', () => {
  const pet = layEgg(1000)
  while (!pet.pending) feed(pet, 'turn', pet.lastSeenAt + 60_000)
  assert.match(renderStatus(pet, pet.lastSeenAt), /pet evolve/)
})

test('ceremony cards: hatch, molt, and a lineage evolution with its dominant stat', () => {
  const pet = layEgg(1000)
  while (!pet.pending) feed(pet, 'agentError', pet.lastSeenAt + 60_000)
  const hatch = evolve(pet, pet.lastSeenAt + 1)
  assert.match(renderEvolution(pet, hatch), /蛋壳裂开/)

  while (!pet.pending) feed(pet, 'agentError', pet.lastSeenAt + 60_000)
  const molt = evolve(pet, pet.lastSeenAt + 1)
  assert.match(renderEvolution(pet, molt), /蜕了一层皮/)

  while (!pet.pending) feed(pet, 'agentError', pet.lastSeenAt + 60_000)
  const branch = evolve(pet, pet.lastSeenAt + 1)
  const card = renderEvolution(pet, branch)
  assert.match(card, /皮实/)
  assert.match(card, /独眼比特鬼/)
  assert.match(card, /病毒系谱/)
})

test('the slug ceremony admits what you did', () => {
  const pet = layEgg(1000)
  const diets = ['toolBuild', 'toolBuild', 'toolBuild']
  for (const diet of diets) {
    while (!pet.pending) feed(pet, diet, pet.lastSeenAt + 60_000)
    evolve(pet, pet.lastSeenAt + 1)
  }
  assert.equal(pet.stage, 3)
  while (!pet.pending) feed(pet, 'turn', pet.lastSeenAt + 60_000)
  while (pet.fullness < STUFFED_EVOLUTION_FULLNESS) feed(pet, 'turn', pet.lastSeenAt)
  const change = evolve(pet, pet.lastSeenAt)
  const card = renderEvolution(pet, change)
  assert.match(card, /这光怎么是绿的/)
  assert.match(card, /缓存泥/)
  assert.match(card, /迷途系谱/)
})

test('the dex page veils the unseen and whispers about the stray line', () => {
  const pet = layEgg(1000)
  const page = renderDex(pet)
  assert.match(page, /图鉴 1\/22/)
  assert.match(page, /● 数码蛋/)
  assert.match(page, /○ ？？？/)
  assert.match(page, /谣传：吃撑的时候进化/)
  assert.doesNotMatch(page, /末日蛛皇/, 'undiscovered names stay hidden')
  assert.doesNotMatch(page, /屎山王/, 'stray names stay hidden until earned')
  assert.match(renderDex(null), /图鉴 0\/22/)
})

test('the story journal narrates egg, hatch, molt, rename and evolutions in order', () => {
  const pet = layEgg(Date.UTC(2026, 7, 15))
  while (!pet.pending) feed(pet, 'toolBuild', pet.lastSeenAt + 60_000)
  evolve(pet, Date.UTC(2026, 7, 16))
  while (!pet.pending) feed(pet, 'toolBuild', pet.lastSeenAt + 60_000)
  evolve(pet, Date.UTC(2026, 7, 17))
  while (!pet.pending) feed(pet, 'toolBuild', pet.lastSeenAt + 60_000)
  evolve(pet, Date.UTC(2026, 7, 18))
  const story = renderStory(pet)
  const lines = story.split('\n')
  assert.match(story, /一颗数码蛋落进了 harness/)
  assert.match(story, /破壳而出 → 比特泡/)
  assert.match(story, /进化 → 字节球/)
  assert.doesNotMatch(story, /字节球（这一阶段最亮眼/, 'baby molts have no dominant stat')
  assert.match(story, /进化 → 锤锤龙（这一阶段最亮眼：锻造）/)
  assert.ok(lines.findIndex(l => l.includes('破壳而出')) < lines.findIndex(l => l.includes('进化 → 锤锤龙')))
})

test('title prefers the given name and falls back to the species', () => {
  const pet = layEgg(1000)
  assert.equal(title(pet), '数码蛋 DigiEgg')
  pet.name = '小蓝'
  assert.equal(title(pet), '小蓝（数码蛋）')
})

test('about explains the diet, the thresholds, the lineages and the warning', () => {
  const about = renderAbout('pet')
  assert.match(about, /30 \/ 120 \/ 500 \/ 1800 \/ 6000 \/ 16000/)
  assert.match(about, /零 token/)
  assert.match(about, /龙之系谱/)
  assert.match(about, /别在它吃撑的时候按进化/)
  assert.match(about, /\/pet hatch/)
})
