import assert from 'node:assert/strict'
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'

import { createStore } from '../store.js'

/** A store on a throwaway file, with a manual clock and captured timers. */
function makeStore(t) {
  const dir = mkdtempSync(join(tmpdir(), 'digipet-'))
  t.after(() => rmSync(dir, { recursive: true, force: true }))
  const file = join(dir, 'pet', 'state.json')
  let clock = 1_000_000
  const timers = []
  const store = createStore(file, {
    now: () => clock,
    setTimer: fn => { timers.push(fn); return timers.length },
    clearTimer: id => { if (id > 0) timers[id - 1] = null },
  })
  return {
    store,
    file,
    tick: (ms = 60_000) => { clock += ms },
    /** Run and clear every pending throttled save. */
    fireTimers: () => { for (let i = 0; i < timers.length; i++) { const fn = timers[i]; timers[i] = null; if (fn) fn() } },
  }
}

test('feeds before the first hatch fall on the ocean floor', (t) => {
  const { store, file, fireTimers } = makeStore(t)
  store.feed('turn')
  fireTimers()
  assert.equal(store.state, null)
  assert.equal(existsSync(file), false, 'nothing to save yet')
})

test('hatch → feed → throttled save → reload round-trip', (t) => {
  const { store, file, tick, fireTimers } = makeStore(t)
  assert.equal(store.hatch(), true)
  assert.equal(store.hatch(), false, 'one pet per home')
  tick(); store.feed('toolBuild')
  tick(); store.feed('message')
  assert.equal(existsSync(file), false, 'write is throttled, not immediate')
  fireTimers()
  assert.equal(existsSync(file), true)
  const saved = JSON.parse(readFileSync(file, 'utf8'))
  assert.equal(saved.version, 2)
  assert.equal(saved.counters.toolCalls, 1)
  assert.equal(saved.counters.messages, 1)

  const reopened = createStore(file, { now: () => 9_999_999 })
  assert.equal(Math.floor(reopened.state.xp), 5)
  assert.equal(reopened.state.counters.messages, 1)
})

test('dispose flushes the pending write', (t) => {
  const { store, file, tick } = makeStore(t)
  store.hatch()
  tick(); store.feed('turn')
  assert.equal(existsSync(file), false)
  store.dispose()
  assert.equal(existsSync(file), true)
  assert.equal(JSON.parse(readFileSync(file, 'utf8')).counters.turns, 1)
})

test('a corrupted or foreign save file opens as no-pet instead of crashing', (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'digipet-'))
  t.after(() => rmSync(dir, { recursive: true, force: true }))
  const file = join(dir, 'state.json')
  writeFileSync(file, '{ not json')
  assert.equal(createStore(file).state, null)
  writeFileSync(file, JSON.stringify({ version: 99, alien: true }))
  assert.equal(createStore(file).state, null)
})

test('a v1 save on disk loads migrated and is rewritten as v2 on the next flush', (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'digipet-'))
  t.after(() => rmSync(dir, { recursive: true, force: true }))
  const file = join(dir, 'state.json')
  writeFileSync(file, JSON.stringify({
    version: 1, createdAt: 1000, name: null, stage: 2, form: 'glitch2', line: 'glitch',
    xp: 400, pending: false, stats: { build: 0, lore: 0, bond: 10, grit: 300 },
    window: { build: 0, lore: 0, bond: 0, grit: 40 }, fullness: 0, fullnessAt: 1000,
    counters: { turns: 10, toolCalls: 5, messages: 3, mishaps: 60 },
    discovered: ['egg0', 'baby1', 'glitch2'],
    journal: [{ at: 1000, kind: 'egg' }], lastSeenAt: 1000,
  }))
  const store = createStore(file, { now: () => 9_999_999 })
  assert.equal(store.state.version, 2)
  assert.equal(store.state.stage, 3, 'old junior (2) becomes new Child (3)')
  assert.equal(store.state.form, 'virus3')
  assert.equal(store.state.line, 'virus')
  assert.ok(store.state.discovered.includes('virus3'))
  store.dispose()
  assert.equal(JSON.parse(readFileSync(file, 'utf8')).version, 2, 'migration persisted')
})

test('evolve and rename persist through the store facade', (t) => {
  const { store, file, tick, fireTimers } = makeStore(t)
  store.hatch()
  assert.equal(store.evolve(), null, 'not pending yet')
  while (!store.state.pending) { tick(); store.feed('turn') }
  const change = store.evolve()
  assert.deepEqual(change, { from: 'egg0', to: 'baby1', dominant: null })
  assert.equal(store.rename('  鲸鲸  '), '鲸鲸')
  assert.equal(store.rename('   '), null)
  fireTimers()
  const saved = JSON.parse(readFileSync(file, 'utf8'))
  assert.equal(saved.stage, 1)
  assert.equal(saved.name, '鲸鲸')
})
