import assert from 'node:assert/strict'
import { existsSync, mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'

import { apply } from '../index.js'

/** The slice of a Cordis context the plugin actually touches. */
function fakeCtx() {
  const listeners = new Map()
  const cleanups = []
  const commands = []
  const ctx = {
    on(event, fn) { listeners.set(event, [...(listeners.get(event) ?? []), fn]) },
    effect(fn) { const dispose = fn(); if (typeof dispose === 'function') cleanups.push(dispose) },
    inject(deps, fn) {
      assert.deepEqual(deps, ['commands'], 'commands is the only injected service')
      fn({ commands: { register: c => commands.push(c) } })
    },
  }
  const emit = (event, ...args) => { for (const fn of listeners.get(event) ?? []) fn(...args) }
  return { ctx, emit, commands, cleanups, listeners }
}

function mount(t, config = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'digipet-plugin-'))
  t.after(() => rmSync(dir, { recursive: true, force: true }))
  const statePath = join(dir, 'state.json')
  const world = fakeCtx()
  apply(world.ctx, { statePath, ...config })
  const command = world.commands[0]
  const run = input => command.handler({ commandId: 'c1', agent: null, rawInput: input, signal: null })
  return { ...world, statePath, command, run }
}

test('apply wires four event taps, one command, one cleanup effect', (t) => {
  const { listeners, commands, cleanups, command } = mount(t)
  assert.deepEqual(
    [...listeners.keys()].sort(),
    ['agent/error', 'agent/inbox/claimed', 'agent/turn-stopping', 'tools/result'],
  )
  assert.equal(commands.length, 1)
  assert.equal(command.name, 'pet')
  assert.match(command.description, /digipet/)
  assert.equal(cleanups.length, 1)
})

test('the whole first day: no pet → hatch → eat real events → ceremony', (t) => {
  const { run, emit } = mount(t)

  assert.match(run('').text, /还没有数码兽/)
  assert.match(run('hatch').text, /数码蛋/)
  assert.match(run('hatch').text, /已经住着/)

  // Six turns of real work reach the 30 XP hatch threshold.
  for (let i = 0; i < 6; i++) emit('agent/turn-stopping', { agent: null, turn: i, signal: null })
  assert.match(run('').text, /蛋壳在动/)
  const ceremony = run('evolve')
  assert.equal(ceremony.kind, 'success')
  assert.match(ceremony.text, /蛋壳裂开/)
  assert.match(ceremony.text, /比特泡/)
  assert.match(run('story').text, /破壳而出/)
})

test('tool results are classified and errors feed 皮实', (t) => {
  const { run, emit } = mount(t)
  run('hatch')
  emit('tools/result', { name: 'write_file' }, { isError: false })
  emit('tools/result', { name: 'web_search' }, { isError: false })
  emit('tools/result', { name: 'shell' }, { isError: true })
  emit('agent/error', { agent: null, turn: 1, step: 1, error: new Error('boom') })
  emit('agent/inbox/claimed', { agent: null, message: {}, turn: 1 })
  const card = run('')
  assert.match(card.text, /XP 14\/30/, '3 + 3 + 2 + 4 + 2 raw XP on an empty stomach')
})

test('malformed event payloads are digested, not thrown', (t) => {
  const { run, emit } = mount(t)
  run('hatch')
  emit('tools/result', undefined, undefined)
  emit('tools/result', {}, {})
  emit('agent/turn-stopping')
  emit('agent/error')
  const card = run('')
  assert.equal(card.kind, 'success', 'the pet absorbed the garbage')
})

test('name, dex, about, unknown subcommand', (t) => {
  const { run } = mount(t)
  assert.equal(run('name 小蓝').kind, 'error')
  run('hatch')
  assert.match(run('name 小蓝').text, /小蓝/)
  assert.match(run('').text, /小蓝（数码蛋）/)
  assert.match(run('dex').text, /图鉴 1\/22/)
  assert.match(run('about').text, /零 token/)
  const unknown = run('feed')
  assert.equal(unknown.kind, 'error')
  assert.match(unknown.text, /不认识/)
})

test('evolve before ready reports progress instead of transforming', (t) => {
  const { run, emit } = mount(t)
  run('hatch')
  emit('agent/turn-stopping', {})
  const refusal = run('evolve')
  assert.equal(refusal.kind, 'success')
  assert.match(refusal.text, /破壳进度|再干点活/)
})

test('the command name is configurable and invalid overrides fall back', (t) => {
  assert.equal(mount(t, { command: 'digipet' }).command.name, 'digipet')
  assert.equal(mount(t, { command: 'Bad Name!' }).command.name, 'pet')
})

test('the cleanup effect flushes the save to disk', (t) => {
  const { run, emit, cleanups, statePath } = mount(t)
  run('hatch')
  emit('agent/turn-stopping', {})
  cleanups[0]()
  assert.equal(existsSync(statePath), true)
})

test('a handler explosion becomes a friendly error result', (t) => {
  const { command } = mount(t)
  const result = command.handler({ rawInput: { toString() { throw new Error('cursed input') } } })
  assert.equal(result.kind, 'error')
  assert.match(result.text, /digipet 摔了一跤/)
})
