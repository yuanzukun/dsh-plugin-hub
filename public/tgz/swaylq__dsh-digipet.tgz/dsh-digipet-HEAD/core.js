/**
 * dsh-digipet core — the creature's entire life as pure functions.
 *
 * No IO, no clock reads, no harness imports: every function takes the state
 * and a millisecond timestamp and returns facts. This is the half that unit
 * tests pin down completely; the plugin half (index.js/store.js) only wires
 * events to `feed` and commands to the renderers.
 *
 * The life cycle follows the classic V-pet canon: egg → Baby Ⅰ → Baby Ⅱ →
 * Child → Adult → Perfect → Ultimate, with branching read from how the
 * keeper actually worked each stage — plus the genre's beloved tradition:
 * evolve into Adult while stuffed (a care mistake) and you get the slug.
 *
 * @module dsh-digipet/core
 */

/** Stage indexes: 0 egg, 1 baby Ⅰ, 2 baby Ⅱ, 3 child, 4 adult, 5 perfect, 6 ultimate. */
export const STAGE_ZH = ['数码蛋', '幼年期Ⅰ', '幼年期Ⅱ', '成长期', '成熟期', '完全体', '究极体']
export const STAGE_EN = ['Egg', 'Baby Ⅰ', 'Baby Ⅱ', 'Child', 'Adult', 'Perfect', 'Ultimate']

/** XP required to leave stage i for stage i+1 (cumulative totals). */
export const THRESHOLDS = [30, 120, 500, 1800, 6000, 16000]

/** The four lineages, keyed by the stat that dominates a growth window. */
export const LINES = { build: 'dragon', lore: 'sage', bond: 'angel', grit: 'virus' }

/** Tie-break priority when window stats are equal: rarest wins. */
const STAT_PRIORITY = ['grit', 'build', 'lore', 'bond']

/** Evolving into Adult at or above this fullness is a care mistake: hello, slug. */
export const STUFFED_EVOLUTION_FULLNESS = 90

/**
 * What each observed harness event feeds the pet.
 * `xp` is the raw gain before the fullness multiplier; `stat` (optional) is
 * the growth-window stat the event nourishes; `counter` is the ledger line.
 */
export const DIET = {
  message: { xp: 2, stat: 'bond', counter: 'messages' },
  turn: { xp: 5, counter: 'turns' },
  toolBuild: { xp: 3, stat: 'build', counter: 'toolCalls' },
  toolLore: { xp: 3, stat: 'lore', counter: 'toolCalls' },
  toolNeutral: { xp: 3, counter: 'toolCalls' },
  toolError: { xp: 2, stat: 'grit', counter: 'mishaps' },
  agentError: { xp: 4, stat: 'grit', counter: 'mishaps' },
}

/** Fullness drains 2 points a minute; eating adds 0.35 per raw XP. */
const FULLNESS_DECAY_PER_MS = 2 / 60_000
const FULLNESS_PER_XP = 0.35

const JOURNAL_CAP = 120

/** Mutating tools nourish the dragon line; observing tools nourish the sage line. */
const BUILD_RE = /write|edit|patch|apply|create|make|mkdir|move|copy|rename|remove|delete|shell|bash|exec|spawn|run|terminal|command|kill|install|git|commit|deploy|code/i
const LORE_RE = /read|cat|open|grep|glob|search|find|list|fetch|web|browse|query|inspect|view|status|log|diff|doc|get|head|tail|show|think/i

/**
 * Map a tool name to the diet event it feeds.
 * @param toolName - the registry name of the tool that just ran.
 * @returns 'toolBuild' | 'toolLore' | 'toolNeutral'
 */
export function classify(toolName) {
  const name = String(toolName ?? '')
  if (BUILD_RE.test(name)) return 'toolBuild'
  if (LORE_RE.test(name)) return 'toolLore'
  return 'toolNeutral'
}

/**
 * A brand-new egg. The pet does not exist until the user hatches one.
 * @param now - millisecond timestamp.
 */
export function layEgg(now) {
  return {
    version: 2,
    createdAt: now,
    name: null,
    stage: 0,
    form: 'egg0',
    line: null,
    xp: 0,
    pending: false,
    stats: { build: 0, lore: 0, bond: 0, grit: 0 },
    window: { build: 0, lore: 0, bond: 0, grit: 0 },
    fullness: 0,
    fullnessAt: now,
    counters: { turns: 0, toolCalls: 0, messages: 0, mishaps: 0 },
    discovered: ['egg0'],
    journal: [{ at: now, kind: 'egg' }],
    lastSeenAt: now,
  }
}

/** Lazily settle fullness decay up to `now`. */
export function settleFullness(state, now) {
  const elapsed = Math.max(0, now - (state.fullnessAt ?? now))
  state.fullness = Math.max(0, (state.fullness ?? 0) - elapsed * FULLNESS_DECAY_PER_MS)
  state.fullnessAt = now
}

/** The XP multiplier a given fullness earns: a stuffed pet barely nibbles. */
export function appetite(fullness) {
  if (fullness < 70) return 1
  if (fullness < 90) return 0.5
  return 0.15
}

/**
 * Digest one observed harness event. Mutates and returns the state.
 * @param state - the pet.
 * @param event - a key of {@link DIET}.
 * @param now - millisecond timestamp.
 */
export function feed(state, event, now) {
  const meal = DIET[event]
  if (!meal) return state
  settleFullness(state, now)
  const gained = meal.xp * appetite(state.fullness)
  state.xp += gained
  state.fullness = Math.min(100, state.fullness + meal.xp * FULLNESS_PER_XP)
  if (meal.stat) {
    state.stats[meal.stat] += gained
    state.window[meal.stat] += gained
  }
  state.counters[meal.counter] += 1
  state.lastSeenAt = now
  state.pending = state.stage < STAGE_ZH.length - 1 && state.xp >= THRESHOLDS[state.stage]
  return state
}

/** The stat that dominated the current growth window (ties: rarest wins). */
export function dominantStat(state) {
  let best = null
  for (const stat of STAT_PRIORITY) {
    if (best === null || state.window[stat] > state.window[best]) best = stat
  }
  return state.window[best] > 0 ? best : 'bond'
}

/**
 * Perform the evolution ceremony the pending flag promised.
 *
 * Stages 0→1→2 are the shared baby forms. From Child on, every evolution
 * re-reads the growth window since the last one, so the creature keeps
 * mirroring how its keeper worked. Two special rules honor V-pet canon:
 * evolving into Adult while stuffed (fullness ≥ 90) is a care mistake and
 * yields the slug regardless of stats; the slug then either redeems into
 * the honey bear (bond-dominant window) or doubles down as the legacy king,
 * and both rejoin a proper lineage at Ultimate.
 *
 * @returns `{ from, to, dominant }`, or null if not ready.
 */
export function evolve(state, now) {
  if (!state.pending || state.stage >= STAGE_ZH.length - 1) return null
  const from = state.form
  const nextStage = state.stage + 1
  let dominant = null
  let nextForm
  if (nextStage === 1) {
    nextForm = 'baby1'
  } else if (nextStage === 2) {
    nextForm = 'baby2'
  } else {
    dominant = dominantStat(state)
    settleFullness(state, now)
    if (nextStage === 4 && state.fullness >= STUFFED_EVOLUTION_FULLNESS) {
      nextForm = 'slug4'
      state.line = 'stray'
    } else if (from === 'slug4') {
      nextForm = dominant === 'bond' ? 'bear5' : 'king5'
      state.line = 'stray'
    } else {
      state.line = LINES[dominant]
      nextForm = `${state.line}${nextStage}`
    }
  }
  state.stage = nextStage
  state.form = nextForm
  state.window = { build: 0, lore: 0, bond: 0, grit: 0 }
  if (!state.discovered.includes(nextForm)) state.discovered.push(nextForm)
  state.journal.push({ at: now, kind: nextStage === 1 ? 'hatch' : 'evolve', from, to: nextForm, dominant })
  if (state.journal.length > JOURNAL_CAP) state.journal.splice(0, state.journal.length - JOURNAL_CAP)
  state.pending = state.stage < STAGE_ZH.length - 1 && state.xp >= THRESHOLDS[state.stage]
  return { from, to: nextForm, dominant }
}

/**
 * Rename the pet.
 * @returns the cleaned name, or null when nothing usable was given.
 */
export function rename(state, rawName, now) {
  const cleaned = String(rawName ?? '').replace(/\s+/g, ' ').trim().slice(0, 16)
  if (cleaned === '') return null
  state.name = cleaned
  state.journal.push({ at: now, kind: 'rename', to: cleaned })
  if (state.journal.length > JOURNAL_CAP) state.journal.splice(0, state.journal.length - JOURNAL_CAP)
  return cleaned
}

/** Progress toward the next stage as `{ have, need, ratio }`; null at the cap. */
export function progress(state) {
  if (state.stage >= STAGE_ZH.length - 1) return null
  const floor = state.stage === 0 ? 0 : THRESHOLDS[state.stage - 1]
  const need = THRESHOLDS[state.stage]
  const ratio = Math.max(0, Math.min(1, (state.xp - floor) / (need - floor)))
  return { have: Math.floor(state.xp), need, ratio }
}

/** A cosmetic mood glyph derived from fullness and pending state. */
export function mood(state, now) {
  settleFullness(state, now)
  if (state.pending) return '✨ 蓄势待发'
  if (state.fullness >= 90) return '😴 吃撑了'
  if (state.fullness < 10) return '🫥 有点饿'
  return '😊 状态不错'
}

// ---- save-file migration ----

/** v1 (sea-creature roster, 6 stages) → v2 (canon roster, 7 stages). */
const V1_STAGE_MAP = [0, 1, 3, 4, 5, 6]
const V1_LINE_MAP = { forge: 'dragon', scholar: 'sage', bond: 'angel', glitch: 'virus' }
const V1_FORM_MAP = {
  egg0: 'egg0', baby1: 'baby1',
  forge2: 'dragon3', forge3: 'dragon4', forge4: 'dragon5', forge5: 'dragon6',
  scholar2: 'sage3', scholar3: 'sage4', scholar4: 'sage5', scholar5: 'sage6',
  bond2: 'angel3', bond3: 'angel4', bond4: 'angel5', bond5: 'angel6',
  glitch2: 'virus3', glitch3: 'virus4', glitch4: 'virus5', glitch5: 'virus6',
}

/**
 * Upgrade a parsed save file to the current version.
 * @returns a v2 state, or null when the file is foreign or unreadable.
 */
export function migrate(parsed) {
  if (!parsed || typeof parsed !== 'object') return null
  if (parsed.version === 2) return parsed
  if (parsed.version !== 1) return null
  const s = structuredClone(parsed)
  s.version = 2
  s.stage = V1_STAGE_MAP[s.stage] ?? 0
  s.form = V1_FORM_MAP[s.form] ?? 'egg0'
  s.line = s.line === null || s.line === undefined ? null : (V1_LINE_MAP[s.line] ?? null)
  s.discovered = [...new Set((s.discovered ?? []).map(f => V1_FORM_MAP[f] ?? f))]
  s.journal = (s.journal ?? []).map((e) => {
    const mapped = { ...e }
    if (mapped.from && V1_FORM_MAP[mapped.from]) mapped.from = V1_FORM_MAP[mapped.from]
    if (mapped.to && V1_FORM_MAP[mapped.to]) mapped.to = V1_FORM_MAP[mapped.to]
    return mapped
  })
  s.pending = s.stage < STAGE_ZH.length - 1 && s.xp >= THRESHOLDS[s.stage]
  return s
}
