/**
 * dsh-digipet — hatch a digital creature that feeds on your actual work.
 *
 * The whole plugin is four event taps and one slash command. It registers no
 * model-facing tool and injects no context: the model never learns the pet
 * exists, so the pet costs zero tokens per request. Every listener body is
 * wrapped so a pet bug can never veto or delay real work — the taps observe
 * emit-mode notifications and return immediately.
 *
 * XP diet: a completed turn +5, each user message +2, each tool result +3
 * (classified into 锻造/学识 by tool name), errors +2~4 (feeding 皮实).
 * Evolution branches by whichever stat dominated the stage — the creature
 * ends up mirroring how its human actually works.
 *
 * @module dsh-digipet
 */

import { classify } from './core.js'
import { renderAbout, renderDex, renderEvolution, renderStatus, renderStory, title } from './dex.js'
import { createStore } from './store.js'

export const name = 'digipet'
export const inject = []

/** Never let a pet exception travel into the agent loop. */
const contained = fn => (...args) => {
  try { fn(...args) } catch { /* the pet absorbs its own mishaps */ }
}

export function apply(ctx, config = {}) {
  const commandName = typeof config.command === 'string' && /^[a-z][a-z0-9-]{0,23}$/.test(config.command)
    ? config.command
    : 'pet'
  const store = createStore(typeof config.statePath === 'string' && config.statePath.trim() !== ''
    ? config.statePath
    : undefined)

  // ---- the diet: observe real work, feed the pet ----
  ctx.on('agent/inbox/claimed', contained(() => store.feed('message')))
  ctx.on('agent/turn-stopping', contained(() => store.feed('turn')))
  ctx.on('agent/error', contained(() => store.feed('agentError')))
  ctx.on('tools/result', contained((exec, result) => {
    store.feed(result?.isError ? 'toolError' : classify(exec?.name))
  }))

  // Flush the throttled save when the plugin unloads or the process leaves.
  ctx.effect(() => () => store.dispose())

  // ---- the one human command ----
  ctx.inject(['commands'], (commandCtx) => {
    commandCtx.commands.register({
      name: commandName,
      description: 'your digipet: status · hatch · evolve · name · dex · story',
      input: { hint: '[hatch|evolve|name <名字>|dex|story|about]' },
      handler: (invocation) => {
        try {
          return dispatch(store, commandName, String(invocation.rawInput ?? ''))
        } catch (error) {
          return { kind: 'error', text: `digipet 摔了一跤：${error?.message ?? error}` }
        }
      },
    })
  })
}

/** Route `/pet <sub>` to a card. Exported for tests. */
export function dispatch(store, commandName, rawInput) {
  const trimmed = rawInput.trim()
  const [sub, ...rest] = trimmed === '' ? [''] : trimmed.split(/\s+/)
  const argument = rest.join(' ')
  const state = store.state
  const nowMs = Date.now()

  switch (sub.toLowerCase()) {
    case '': {
      if (state === null) {
        return {
          kind: 'success',
          text: `这里还没有数码兽。/${commandName} hatch 孵一颗蛋 —— 它会吃你之后的真实工作长大。`,
        }
      }
      return { kind: 'success', text: renderStatus(state, nowMs) }
    }
    case 'hatch': {
      if (store.hatch()) {
        return { kind: 'success', text: renderStatus(store.state, nowMs) }
      }
      // An egg (or grown pet) already lives here; hatch doubles as the ceremony trigger.
      if (state?.pending) return runCeremony(store, commandName)
      return { kind: 'success', text: `这里已经住着 ${title(state)} 了。/${commandName} 看看它。` }
    }
    case 'evolve': {
      if (state === null) return { kind: 'error', text: `还没有蛋。先 /${commandName} hatch。` }
      if (!state.pending) {
        return {
          kind: 'success',
          text: `${title(state)} 还没攒够能量。${renderStatus(state, nowMs).split('\n').filter(l => l.startsWith('XP') || l.startsWith('破壳')).join('\n') || '再干点活吧。'}`,
        }
      }
      return runCeremony(store, commandName)
    }
    case 'name': {
      if (state === null) return { kind: 'error', text: `还没有蛋。先 /${commandName} hatch。` }
      const cleaned = store.rename(argument)
      if (cleaned === null) return { kind: 'error', text: `用法：/${commandName} name <名字>（16 字以内）` }
      return { kind: 'success', text: `从今天起，它叫「${cleaned}」。` }
    }
    case 'dex': {
      return { kind: 'success', text: renderDex(state) }
    }
    case 'story': {
      if (state === null) return { kind: 'error', text: `还没有故事。先 /${commandName} hatch。` }
      return { kind: 'success', text: renderStory(state) }
    }
    case 'about':
    case 'help': {
      return { kind: 'success', text: renderAbout(commandName) }
    }
    default: {
      return { kind: 'error', text: `不认识「${sub}」。可用：/${commandName} · hatch · evolve · name <名字> · dex · story · about` }
    }
  }
}

function runCeremony(store, commandName) {
  const change = store.evolve()
  if (!change) return { kind: 'error', text: `时机未到。/${commandName} 看看还差多少。` }
  return { kind: 'success', text: renderEvolution(store.state, change) }
}
