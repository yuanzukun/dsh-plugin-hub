# dsh-background 🖼️

给 **DSH 桌面版**换背景图的插件：**设置 → 常规 → 自定义背景**，或聊天框输入 `/background`。
图铺在整个窗口最底层，三栏半透明透出壁纸，可调暗/调亮。

## ✨ 功能

- 🖼️ **选择图片…**：系统文件选择器选图（PNG / JPG / WebP / GIF，≤ 8MB），即时生效
- ◐ **调暗** / ◑ **调亮**：一键调遮罩强度（55% / 25%），文字看不清就调暗
- 🗑️ **清除**：恢复默认
- ⌨️ **`/background` 斜杠命令**：聊天框里直接操作
- 💾 **持久化**：图片存在本地（localStorage），重启不丢
- ⚙️ **可选配置**：`~/.config/dsh-background/config.json` 可预设 `image` / `overlay`

## 安装（给使用者，三选一）

### 方式 A：让 DSH 的 AI 帮你装（最简单）

把这句话发给你的 DSH：

> 帮我安装 dsh-background 插件，代码在 `github:SnoWinKK/dsh-background`

### 方式 B：命令安装（需要 `dsh` 和 `pnpm`）

```powershell
# 直接从 GitHub 安装：
dsh plugin --profile <profile> add github:SnoWinKK/dsh-background

# 或者：clone 下来后用本地文件夹安装：
git clone https://github.com/SnoWinKK/dsh-background
cd dsh-background
dsh plugin --profile <profile> add .
```

然后**重启 DSH**。`dsh plugin` 会自动把插件加进 profile 的 bundles，无需手改配置。

> 💡 **`<profile>` 填什么？**
> - 用 **Deepseek-Harness-Desktop 桌面版** → 填 `desktop`
> - 用官方 **`dsh web` 网页版** → 填 `web`
> - **不确定的话**：打开 `C:\Users\你的用户名\.dsh\profiles` 文件夹，里面的文件夹名就是可用的 profile 名
> - **填错不会弄坏东西**：只是装进另一套配置。重启后没生效，就换一个名字再跑一次命令

### 方式 C：手动编辑 profile（不装 dsh CLI）

1. 拿到本仓库（Download ZIP 解压即可）；
2. 编辑 `~/.dsh/profiles/<profile>/package.json`：

   ```json
   {
     "dependencies": { "dsh-background": "link:<解压后的路径>" },
     "dsh": { "profile": { "bundles": [/* ... */, "dsh-background"] } }
   }
   ```

3. 在 profile 目录跑 `pnpm install`，重启 DSH。

## 使用

| 操作 | 方式 |
| --- | --- |
| 换背景图 | 设置 → 常规 → 自定义背景 → 🖼️ 选择图片… |
| 快速操作 | 聊天框输入 `/background` |
| 调暗 / 调亮 | 面板上的 ◐ / ◑ 按钮，或 `/background` 菜单 |
| 清除背景 | 🗑️ 清除（恢复默认） |

## 配置

`~/.config/dsh-background/config.json`（可选，优先级高于 localStorage）：

```json
{
  "image": "file:///C:/path/to/wallpaper.png",
  "overlay": 0.35
}
```

| 字段 | 说明 |
| --- | --- |
| `image` | 背景图来源：data URL / 本地路径 / http(s) 地址 |
| `overlay` | 遮罩强度 `0`（全透）~ `1`（不透明），默认 `0.35` |

## 结构

- `lib/index.js`
- `lib/client.js`
- `cordis.patch.yml` 

## 许可
