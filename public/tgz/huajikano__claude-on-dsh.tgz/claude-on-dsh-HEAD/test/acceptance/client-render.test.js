import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

// Load the browser bundle without a DOM or React install. The fake createElement
// invokes function components recursively, so a broken render path throws here.
let snapshot = null
globalThis.window = {
  __ModuleLoader__: {
    load(module) {
      globalThis.__capturedModule = module
    },
  },
  sessionStorage: {
    getItem: () => snapshot,
    setItem: () => {},
  },
  location: { hash: '', pathname: '', origin: 'http://127.0.0.1:65136' },
}
globalThis.document = {
  querySelector: () => null,
  createElement: () => ({ dataset: {}, remove() {} }),
  head: { appendChild() {} },
}

const source = await readFile(new URL('../../client.js', import.meta.url), 'utf8')
await import('../../client.js')

const components = new Map()
let hookState = null
let hookIndex = 0
const FakeFragment = Symbol('Fragment')
function createElement(type, props, ...children) {
  if (type === FakeFragment) return children
  const merged = { ...(props || {}), children }
  if (typeof type === 'function') {
    components.set(type.name, { type, props: merged })
    return type(merged)
  }
  return { type, props: merged }
}
const React = {
  Fragment: FakeFragment,
  createElement,
  useCallback: (fn) => fn,
  useEffect: () => {},
  useMemo: (fn) => fn(),
  useRef: (value) => ({ current: value }),
  useState(initial) {
    if (!hookState) return [typeof initial === 'function' ? initial() : initial, () => {}]
    const state = hookState
    const index = hookIndex++
    if (!(index in state)) state[index] = typeof initial === 'function' ? initial() : initial
    return [state[index], (value) => { state[index] = typeof value === 'function' ? value(state[index]) : value }]
  },
}

const module = globalThis.__capturedModule.factory((name) => {
  assert.equal(name, 'react')
  return React
})

const dictionaries = {}
let panel = null
let mainOptions = null
const ctx = {
  effect(callback) {
    const disposer = callback()
    return typeof disposer === 'function' ? disposer : () => {}
  },
  locale: {
    register(namespace, value) {
      dictionaries[namespace] = value
      return () => {}
    },
    bind(namespace) {
      return (key) => (dictionaries[namespace] && dictionaries[namespace].zh[key]) || key
    },
  },
  slots: {
    inject(name, callback) {
      callback()
    },
    register(options, component) {
      if (options.name === 'main') {
        panel = component
        mainOptions = options
      }
      return () => {}
    },
  },
  sessions: {},
  uiWorkspace: {},
}
module.apply(ctx)
assert.ok(panel, 'main panel was registered')

const props = {
  panelId: 'claude-on-dsh',
  t: (key) => key,
  pickDirectory: async () => null,
  refreshSessions: async () => {},
  openSession: () => {},
  dispatchTask: async () => ({}),
  archiveTask: async () => {},
  dispatchAcceptance: async () => ({}),
  runClaudeAcceptance: async () => ({}),
  askFirstQuestion: async () => ({}),
  sendFirstQuestion: async () => ({}),
  listSessions: async () => ({ items: [] }),
  currentSessionId: () => 'session-current',
}

function contains(node, text) {
  if (node === null || node === undefined) return false
  if (typeof node === 'string') return node.includes(text)
  if (Array.isArray(node)) return node.some((child) => contains(child, text))
  if (typeof node === 'object') {
    if (Array.isArray(node.children) && node.children.some((child) => contains(child, text))) return true
    if (node.props && Array.isArray(node.props.children)) {
      return node.props.children.some((child) => contains(child, text))
    }
  }
  return false
}

function render(snapshotValue) {
  snapshot = snapshotValue === null ? null : JSON.stringify(snapshotValue)
  return panel(props)
}

test('every tt() key exists in both dictionaries', () => {
  const zh = Object.keys(dictionaries['claude-on-dsh'].zh)
  const en = Object.keys(dictionaries['claude-on-dsh'].en)
  assert.deepEqual([...zh].sort(), [...en].sort(), 'zh and en dictionaries must have the same keys')
  const keys = new Set([...source.matchAll(/tt\('([^']+)'/g)].map((match) => match[1]))
  keys.add('stepSetup')
  keys.add('stepAsk')
  keys.add('stepHandoff')
  for (const key of keys) {
    assert.ok(zh.includes(key), `missing zh key: ${key}`)
    assert.ok(en.includes(key), `missing en key: ${key}`)
  }
})

test('setup phase renders', () => {
  const tree = render(null)
  assert.ok(contains(tree, '从一个目标开始'))
  assert.ok(contains(tree, '继续会话'))
  assert.ok(contains(tree, '项目目录'))
  assert.ok(contains(tree, '项目名称'))
})

function findNodes(node, predicate) {
  if (!node || typeof node !== 'object') return []
  if (Array.isArray(node)) return node.flatMap((child) => findNodes(child, predicate))
  return [
    ...(predicate(node) ? [node] : []),
    ...findNodes(node.props?.children, predicate),
  ]
}

function renderPicker(sessions, query = '', onSelect = () => {}) {
  render({ v: 1, savedAt: Date.now(), activeWorkspace: 'continue' })
  const picker = components.get('SessionPicker')
  assert.ok(picker, 'continue workspace renders the session picker')
  return createElement(picker.type, { ...picker.props, sessions, query, onSelect })
}

test('continue picker distinguishes sessions in one workspace by title and keeps directory context', () => {
  const cwd = 'D:\\new\\new2'
  const sessions = [
    { sessionId: 'session-first', title: '项目调研与优化准备', cwd },
    { sessionId: 'session-second', title: 'CC-dsh', cwd },
    { sessionId: 'session-third', title: '   ', cwd },
    { sessionId: 'session-fourth', cwd: '' },
  ]
  let selected
  const tree = renderPicker(sessions, '', (item) => { selected = item })
  const buttons = findNodes(tree, (node) => node.props?.className === 'cc-sessionPick')
  assert.equal(buttons.length, 4)
  const titles = buttons.map((button) => findNodes(button, (node) => node.props?.className === 'cc-recordTitle')[0].props.children[0])
  assert.deepEqual(titles, ['项目调研与优化准备', 'CC-dsh', 'new2', 'session-fourth'])
  assert.ok(contains(buttons[0], cwd))
  buttons[1].props.onClick()
  assert.equal(selected, sessions[1])
})

test('continue picker searches session title, directory and id', () => {
  const sessions = [
    { sessionId: 'session-first', title: '项目调研与优化准备', cwd: 'D:\\new\\new2' },
    { sessionId: 'session-second', title: 'CC-dsh', cwd: 'D:\\other' },
  ]
  for (const query of [' 优化 ', 'new2', 'FIRST']) {
    const tree = renderPicker(sessions, query)
    const buttons = findNodes(tree, (node) => node.props?.className === 'cc-sessionPick')
    assert.equal(buttons.length, 1)
    assert.ok(contains(buttons[0], '项目调研与优化准备'))
  }
  assert.equal(findNodes(renderPicker(sessions, 'missing'), (node) => node.props?.className === 'cc-sessionPick').length, 0)
})

test('a current ancestor resolves to the latest fork when opening the first-question picker', async () => {
  const latest = { sessionId: 'session-latest', title: 'Latest continuation', cwd: 'D:\\artra', forkSessionIds: ['session-root', 'session-latest'] }
  const ancestor = { sessionId: 'session-root', title: 'Earlier segment', cwd: latest.cwd }
  let listCalls = 0
  const listSessions = async () => ({ items: [++listCalls === 1 ? ancestor : latest] })
  const state = []
  const renderState = () => {
    hookState = state
    hookIndex = 0
    snapshot = null
    try {
      return panel({ ...props, listSessions, currentSessionId: () => 'session-root' })
    } finally { hookState = null }
  }
  let tree = renderState()
  const continueTab = findNodes(tree, (node) => node.props?.role === 'tab' && contains(node, '继续会话'))[0]
  continueTab.props.onClick()
  await Promise.resolve()
  tree = renderState()
  const button = findNodes(tree, (node) => node.props?.className === 'cc-sessionPick')[0]
  assert.ok(contains(button, 'Earlier segment'))
  button.props.onClick()
  await Promise.resolve()
  tree = renderState()
  const select = findNodes(tree, (node) => node.type === 'select' && node.props.value === 'session-latest')[0]
  assert.ok(select, 'first-question picker selects the latest fork')
  const options = findNodes(select, (node) => node.type === 'option')
  assert.equal(options.some((node) => node.props.value === 'session-root'), false)
  assert.ok(contains(select, '[当前]'))
})

test('refined phase focuses on the handoff and folds the setup away', () => {
  const tree = render({
    v: 1,
    savedAt: Date.now(),
    phase: 'refined',
    refined: {
      projectTitle: 'Refined Project',
      summary: 'summary',
      plan: [],
      acceptance: [],
      risks: [],
      dshPrompt: 'prompt',
    },
    promptText: 'prompt',
  })
  assert.ok(contains(tree, 'Refined Project'))
  assert.ok(contains(tree, '项目设定'))
  assert.ok(contains(tree, '派发给 DSH 执行'))
})

test('dispatched phase does not bring back the deleted acceptance section', () => {
  const tree = render({
    v: 1,
    savedAt: Date.now(),
    phase: 'dispatched',
    dispatch: { state: 'done', sessionId: 'session-x', title: 'Done Project', permission: 'danger-full-access' },
  })
  assert.ok(contains(tree, '已派发，DSH 开始执行'))
  assert.ok(contains(tree, 'DSH 会话已创建'))
  assert.ok(contains(tree, '打开会话'))
  assert.ok(!contains(tree, 'Claude 验收（可选，展开查看）'))
  assert.ok(!contains(tree, '立即验收'))
})

test('prompt editor loads current text, preserves drafts on errors, saves and restores defaults', async () => {
  render(null)
  const editor = components.get('PromptEditor').type
  const state = []
  const originalFetch = globalThis.fetch
  let current = { id: 'brief', title: '新项目首问', description: 'Description', variables: ['goal'], required: ['goal'], value: 'DEFAULT {{goal}}', defaultValue: 'DEFAULT {{goal}}', customized: false }
  let failure = false
  const writes = []
  globalThis.fetch = async (_url, options) => {
    if (options.method === 'POST') {
      const body = JSON.parse(options.body)
      writes.push(body)
      if (failure) return { ok: false, status: 400, text: async () => JSON.stringify({ error: { message: '请保留必需占位符：{{goal}}' } }) }
      current = { ...current, value: body.reset ? current.defaultValue : body.value, customized: !body.reset }
    }
    return { ok: true, status: 200, text: async () => JSON.stringify({ items: [current] }) }
  }
  const renderEditor = () => {
    hookState = state; hookIndex = 0
    try { return createElement(editor, { ids: ['brief'], tt: (key) => dictionaries['claude-on-dsh'].zh[key] || key }) }
    finally { hookState = null }
  }
  const textArea = (tree) => findNodes(tree, (node) => node.type === 'textarea')[0]
  const button = (tree, label) => findNodes(tree, (node) => node.type === 'button' && contains(node, label))[0]
  try {
    let tree = renderEditor()
    await tree.props.onToggle({ currentTarget: { open: true } })
    tree = renderEditor()
    assert.equal(textArea(tree).props.value, 'DEFAULT {{goal}}')
    assert.ok(contains(tree, '{{goal}}'))
    assert.ok(contains(tree, '(必需)'))
    textArea(tree).props.onChange({ target: { value: 'CUSTOM {{goal}}' } })
    tree = renderEditor()
    assert.ok(contains(tree, '有未保存修改'))
    failure = true
    await button(tree, '保存提示词').props.onClick()
    tree = renderEditor()
    assert.equal(textArea(tree).props.value, 'CUSTOM {{goal}}')
    assert.ok(contains(tree, '请保留必需占位符'))
    failure = false
    await button(tree, '保存提示词').props.onClick()
    tree = renderEditor()
    assert.equal(writes.at(-1).value, 'CUSTOM {{goal}}')
    assert.ok(contains(tree, '已自定义'))
    assert.ok(contains(tree, '已保存，下次生成生效'))
    await button(tree, '恢复默认').props.onClick()
    tree = renderEditor()
    assert.deepEqual(writes.at(-1), { id: 'brief', reset: true })
    assert.equal(textArea(tree).props.value, 'DEFAULT {{goal}}')
    assert.equal(button(tree, '保存提示词').props.disabled, true)
  } finally { globalThis.fetch = originalFetch }
})

test('prompt editors are available in new-project, continue and development-document steps', () => {
  for (const activeWorkspace of ['new', 'continue', 'devdoc']) {
    const tree = render({ v: 1, savedAt: Date.now(), activeWorkspace })
    assert.ok(findNodes(tree, (node) => node.props?.className === 'cc-promptDetails').length >= 1)
  }
})

test('requests carry a timeout signal and map aborts to a readable error', async () => {
  const originalFetch = globalThis.fetch
  let init
  globalThis.fetch = async (_url, options) => {
    init = options
    return { ok: true, status: 200, text: async () => '{"ok":true}' }
  }
  try {
    await mainOptions.inject().dispatchTask({ brief: 'x' })
    assert.ok(init.signal)
    assert.equal(typeof init.signal.aborted, 'boolean')
    globalThis.fetch = async () => {
      throw Object.assign(new Error('aborted'), { name: 'TimeoutError' })
    }
    await assert.rejects(() => mainOptions.inject().archiveTask('session-x'), /请求超时/)
  } finally {
    globalThis.fetch = originalFetch
  }
})
