#!/usr/bin/env node
/**
 * Kidai Snapshot Guard — test-ksg-backup.mjs
 *
 * End-to-end check of the backup engine on a THROWAWAY profile
 * (`kpr-ksg-test`): manual snapshot, zip export, mutate, zip import, restore,
 * and foreign-backup read/restore (fake dsh-plugin-guard rollback dir +
 * fake dsh-config-manager snapshot). The real desktop profile is untouched;
 * everything created is removed afterwards.
 */
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { createRequire } from "node:module";
import {
  createSnapshot,
  listSnapshots,
  exportSnapshotZip,
  importSnapshotZip,
  restoreSnapshot,
  listForeignBackups,
  restoreForeignBackup,
  readSnapshotMeta,
  updateKnownGoodSnapshot,
  KNOWN_GOOD_ID,
  thirdPartyPackageState,
  detectProfileChanges,
  pruneByQuota,
  quotaStats,
  DEFAULT_QUOTA_BYTES,
} from "../lib/backup.js";
import { maybeFirstInstallSnapshot, loadGuardSettings } from "../lib/api.js";
import { runCloseSnapshot } from "../lib/index.js";

const PROFILE = "kpr-ksg-test";
const HOME = process.env.DSH_HOME ?? join(process.env.USERPROFILE ?? ".", ".dsh");
const profileDir = join(HOME, "profiles", PROFILE);
const pkgDir = join(profileDir, "node_modules", "dsh-fake-pkg");
const write = (p, text) => writeFileSync(p, text, "utf8");
const ok = (cond, label) => {
  console.log(`${cond ? "PASS" : "FAIL"}  ${label}`);
  if (!cond) process.exitCode = 1;
};
const nodeRequire = createRequire(import.meta.url);

console.log("== KSG backup engine (throwaway profile) ==");

// --- setup ---
rmSync(profileDir, { recursive: true, force: true });
rmSync(join(HOME, "rollbacks", PROFILE), { recursive: true, force: true });
rmSync(join(HOME, "dsh-config-manager", "snapshots", "ksg-fake-cm"), { recursive: true, force: true });
mkdirSync(pkgDir, { recursive: true });
write(join(profileDir, "package.json"), JSON.stringify({ name: `dsh-profile-${PROFILE}`, private: true, dependencies: { "dsh-fake-pkg": "file:./node_modules/dsh-fake-pkg" }, dsh: { profile: { bundles: [] } } }, null, 2));
write(join(pkgDir, "package.json"), JSON.stringify({ name: "dsh-fake-pkg", version: "1.0.0", main: "index.js", dsh: { bundle: { patch: "./cordis.patch.yml" } } }, null, 2));
write(join(pkgDir, "index.js"), "export default {}\n");
write(join(pkgDir, "cordis.patch.yml"), "- insert:\n    - id: fake-pkg\n      name: 'dsh-fake-pkg'\n");
write(join(profileDir, "cordis.patch.yml"), "[]\n");
write(join(HOME, "settings.yaml"), "ui-onboarding:\n  welcomeNoticeVersion: test\n");
// Isolate the capacity quota: the real guard settings may carry a different
// quotaCount, which would make the fixed prune assertions below flaky.
const guardSettingsPath = join(HOME, "guard", "kidai-snapshot.json");
const guardSettingsBackup = existsSync(guardSettingsPath) ? readFileSync(guardSettingsPath, "utf8") : null;
mkdirSync(join(HOME, "guard"), { recursive: true });
write(guardSettingsPath, JSON.stringify({ quotaMode: "count", quotaCount: 3, quotaBytes: DEFAULT_QUOTA_BYTES }, null, 2));

// --- 1) manual snapshot ---
const snap = createSnapshot({ home: HOME, profileName: PROFILE, trigger: "manual", note: "test" });
ok(snap !== undefined && snap.status === "verified", `manual snapshot created verified (${snap?.id})`);
ok(Object.keys(snap.packages).includes("dsh-fake-pkg"), "package copied into snapshot");
ok(existsSync(join(HOME, ".kidai-snapshots", snap.id, "settings.yaml")), "settings.yaml included (full backup)");

// --- 2) zip export ---
const exp = exportSnapshotZip({ home: HOME, id: snap.id, profileName: PROFILE });
ok(exp.ok && existsSync(exp.path), `zip export ok: ${exp.path}`);
const AdmZip = nodeRequire("adm-zip");
const zip = new AdmZip(exp.path);
ok(zip.getEntry("manifest.json") !== undefined, "zip has manifest.json");
ok(zip.getEntry("config/profile.package.json") !== undefined, "zip has profile manifest");
ok(zip.getEntry("config/settings.yaml") !== undefined, "zip has settings.yaml");
const pkgEntry = zip.getEntries().find((e) => e.entryName.startsWith("packages/dsh-fake-pkg/"));
ok(pkgEntry !== undefined, "zip has package dirs");

// --- 3) mutate (bad update) ---
write(join(profileDir, "package.json"), JSON.stringify({ name: `dsh-profile-${PROFILE}`, private: true, dependencies: { "dsh-fake-pkg": "file:./node_modules/dsh-fake-pkg" }, dsh: { profile: { bundles: ["dsh-fake-pkg"] } } }, null, 2));
write(join(pkgDir, "package.json"), JSON.stringify({ name: "dsh-fake-pkg", version: "2.0.0", main: "index.js", dsh: { bundle: { patch: "./cordis.patch.yml" } } }, null, 2));
ok(JSON.parse(readFileSync(join(pkgDir, "package.json"), "utf8")).version === "2.0.0", "bad update applied");

// --- 4) import the exported zip back ---
const imp = importSnapshotZip(HOME, exp.path, { profileName: PROFILE });
ok(imp.ok, `zip import ok (${imp.id})`);
ok(readSnapshotMeta(HOME, imp.id).trigger === "import", "imported snapshot marked as import");

// --- 5) restore from the imported snapshot ---
const rb = restoreSnapshot({ home: HOME, id: imp.id, profileName: PROFILE });
ok(rb.ok === true, `restore ok: ${rb.message.split("\n")[0]}`);
const manifestAfter = JSON.parse(readFileSync(join(profileDir, "package.json"), "utf8"));
const pkgAfter = JSON.parse(readFileSync(join(pkgDir, "package.json"), "utf8"));
ok(JSON.stringify(manifestAfter.dsh.profile.bundles) === "[]", "bundles restored to pre-change");
ok(pkgAfter.version === "1.0.0", "package version restored to 1.0.0");

// --- 6) foreign: fake dsh-plugin-guard rollback ---
const guardStamp = "20260820-000000-000";
mkdirSync(join(HOME, "rollbacks", PROFILE, guardStamp), { recursive: true });
write(join(HOME, "rollbacks", PROFILE, guardStamp, "manifest.json"), JSON.stringify({ profile: PROFILE, time: new Date().toISOString(), tag: "manual", reason: "test", files: ["package.json", "cordis.patch.yml"] }, null, 2));
write(join(HOME, "rollbacks", PROFILE, guardStamp, "package.json"), JSON.stringify({ name: `dsh-profile-${PROFILE}`, private: true, dependencies: {}, dsh: { profile: { bundles: [] } } }, null, 2));
write(join(HOME, "rollbacks", PROFILE, guardStamp, "cordis.patch.yml"), "- id: fake\n  disabled: true\n");
const foreign = listForeignBackups(HOME, PROFILE);
ok(foreign.guard.length >= 1 && foreign.guard[0].id === guardStamp, "guard rollback listed");
const gRestore = restoreForeignBackup({ home: HOME, profileName: PROFILE, source: "dsh-plugin-guard", id: guardStamp });
ok(gRestore.ok === true, `guard rollback restore ok (${gRestore.restored} items)`);
ok(JSON.parse(readFileSync(join(profileDir, "package.json"), "utf8")).dependencies === undefined || Object.keys(JSON.parse(readFileSync(join(profileDir, "package.json"), "utf8")).dependencies).length === 0, "guard restore applied (deps emptied)");

// --- 7) foreign: fake dsh-config-manager snapshot ---
const cmId = "ksg-fake-cm";
const cmDir = join(HOME, "dsh-config-manager", "snapshots", cmId);
mkdirSync(join(cmDir, "blobs", "host"), { recursive: true });
write(join(cmDir, "blobs", "host", "blob1"), "settings-copy\n");
write(join(cmDir, "snapshot.json"), JSON.stringify({
  id: cmId, createdAt: new Date().toISOString(), status: "done",
  hostFileBackups: [{ relPath: "settings.yaml", blobPath: "blobs/host/blob1", existed: true }],
}, null, 2));
write(join(HOME, "settings.yaml"), "changed: true\n");
const foreign2 = listForeignBackups(HOME, PROFILE);
ok(foreign2.configManager.some((s) => s.id === cmId), "config-manager snapshot listed");
const cmRestore = restoreForeignBackup({ home: HOME, profileName: PROFILE, source: "dsh-config-manager", id: cmId });
ok(cmRestore.ok === true, `config-manager restore ok (${cmRestore.restored} items)`);
ok(readFileSync(join(HOME, "settings.yaml"), "utf8").includes("settings-copy"), "settings.yaml restored from cm blob");

// --- 8) auto-snapshot pruning: keep at most 3 close snapshots ---
const closeIds = [];
for (let i = 0; i < 5; i++) closeIds.push(createSnapshot({ home: HOME, profileName: PROFILE, trigger: "close", note: `auto-${i}` }).id);
const manualIds = [];
for (let i = 0; i < 2; i++) manualIds.push(createSnapshot({ home: HOME, profileName: PROFILE, trigger: "manual", note: `keep-${i}` }).id);
const all = listSnapshots(HOME, PROFILE);
const closeRemaining = all.filter((s) => s.trigger === "close").length;
const manualRemaining = all.filter((s) => s.trigger === "manual").length;
ok(closeRemaining === 3, `auto snapshots pruned to 3 (got ${closeRemaining})`);
ok(manualRemaining >= 2, `manual snapshots not pruned (${manualRemaining})`);
const newestClose = all.filter((s) => s.trigger === "close").sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
ok(newestClose.every((s) => s.note?.startsWith("auto-") && Number(s.note.slice(5)) >= 2), "only the newest 3 auto snapshots remain");

// --- 9) first-install baseline snapshot (KSG's own first run) ---
rmSync(guardSettingsPath, { recursive: true, force: true });
ok(loadGuardSettings(HOME).firstInstallSnapshotDone === false, "marker absent on first run");
const firstRun = maybeFirstInstallSnapshot({ home: HOME, profileName: PROFILE });
ok(firstRun.snapshot !== undefined && firstRun.snapshot.trigger === "install", `first-install baseline saved (${firstRun.snapshot?.id})`);
ok(firstRun.snapshot.status === "verified", "first-install baseline is verified (install-time state is running)");
ok(loadGuardSettings(HOME).firstInstallSnapshotDone === true, "marker persisted after first run");
const beforeCount = listSnapshots(HOME, PROFILE).length;
const secondRun = maybeFirstInstallSnapshot({ home: HOME, profileName: PROFILE });
ok(secondRun.skipped === true, "no repeat baseline on later runs");
ok(listSnapshots(HOME, PROFILE).length === beforeCount, "snapshot count unchanged on repeat run");

// --- 10) close snapshot: full + dedup + light exit fallback ---
// (restore the dependency first — the guard-rollback test above emptied it)
write(join(profileDir, "package.json"), JSON.stringify({ name: `dsh-profile-${PROFILE}`, private: true, dependencies: { "dsh-fake-pkg": "file:./node_modules/dsh-fake-pkg" }, dsh: { profile: { bundles: [] } } }, null, 2));
const fullClose = runCloseSnapshot({ home: HOME, profileName: PROFILE });
ok(fullClose !== undefined && fullClose.trigger === "close", `close snapshot (full) created: ${fullClose?.id}`);
ok(fullClose.note.includes("最近一次正常运转"), "full close snapshot is the known-good marker");
ok(Object.keys(fullClose.packages ?? {}).length >= 1, "full close snapshot includes third-party package dirs");
const dedup = runCloseSnapshot({ home: HOME, profileName: PROFILE });
ok(dedup === undefined, "dedup: second close within 30s skipped (dispose + exit fire once)");
const light = createSnapshot({ home: HOME, profileName: PROFILE, trigger: "close", note: "light-fallback", status: "verified", includePackages: false });
ok(light !== undefined && Object.keys(light.packages ?? {}).length === 0, "light snapshot has no package dirs (exit-event fallback is fast)");
ok(Object.keys(light.packageVersions ?? {}).includes("dsh-fake-pkg"), "light snapshot still records the package manifest (for external diagnosis)");

// --- 11) running-state known-good snapshot + change detection ---
const kg1 = updateKnownGoodSnapshot({ home: HOME, profileName: PROFILE });
ok(kg1 !== undefined && kg1.id === KNOWN_GOOD_ID && kg1.trigger === "known-good", "known-good snapshot created (pinned id)");
ok(kg1.packageVersions["dsh-fake-pkg"] === "1.0.0", "packageVersions recorded with version");
const state1 = thirdPartyPackageState(profileDir);
ok(detectProfileChanges(profileDir, state1).changed === false, "no change on identical state");
mkdirSync(join(profileDir, "node_modules", "dsh-new-pkg"), { recursive: true });
write(join(profileDir, "node_modules", "dsh-new-pkg", "package.json"), JSON.stringify({ name: "dsh-new-pkg", version: "0.1.0", main: "index.js", dsh: { bundle: { patch: "./cordis.patch.yml" } } }, null, 2));
write(join(profileDir, "node_modules", "dsh-new-pkg", "index.js"), "export default {}\n");
write(join(profileDir, "node_modules", "dsh-new-pkg", "cordis.patch.yml"), "- insert:\n    - id: new-pkg\n      name: 'dsh-new-pkg'\n");
write(join(profileDir, "package.json"), JSON.stringify({ name: `dsh-profile-${PROFILE}`, private: true, dependencies: { "dsh-fake-pkg": "file:./node_modules/dsh-fake-pkg", "dsh-new-pkg": "file:./node_modules/dsh-new-pkg" }, dsh: { profile: { bundles: [] } } }, null, 2));
ok(detectProfileChanges(profileDir, state1).changed === true, "new install detected by change watcher");
const kg2 = updateKnownGoodSnapshot({ home: HOME, profileName: PROFILE });
ok(kg2.packageVersions["dsh-new-pkg"] === "0.1.0", "known-good updated with the new package");
ok(listSnapshots(HOME, PROFILE).filter((s) => s.id === KNOWN_GOOD_ID).length === 1, "known-good stays a single pinned snapshot");

// --- 12) capacity quota: count & bytes pruning + stats + manual preserved ---
const autoOf = (list) => list.filter((s) => s.trigger === "close" || s.trigger === "known-good");
const manualBefore = listSnapshots(HOME, PROFILE).filter((s) => s.trigger === "manual").length;
pruneByQuota(HOME, PROFILE, { quotaMode: "count", quotaCount: 2, quotaBytes: DEFAULT_QUOTA_BYTES });
ok(autoOf(listSnapshots(HOME, PROFILE)).length <= 2, "count quota keeps at most 2 automatic snapshots");
ok(listSnapshots(HOME, PROFILE).filter((s) => s.trigger === "manual").length === manualBefore, "manual snapshots survive count pruning");
pruneByQuota(HOME, PROFILE, { quotaMode: "bytes", quotaCount: 3, quotaBytes: 1 });
ok(autoOf(listSnapshots(HOME, PROFILE)).length === 0, "bytes quota (1 byte) prunes all automatic snapshots");
ok(listSnapshots(HOME, PROFILE).filter((s) => s.trigger === "manual").length === manualBefore, "manual snapshots survive bytes pruning");
const stats = quotaStats(HOME, PROFILE, { quotaMode: "bytes", quotaCount: 3, quotaBytes: 1024 * 1024 });
const otherCount = listSnapshots(HOME, PROFILE).filter((s) => s.trigger !== "close" && s.trigger !== "known-good").length;
ok(stats.count >= 0 && typeof stats.avgPerSnapshot === "number", "quotaStats reports usage/avg");
ok(stats.otherCount === otherCount, `quotaStats counts non-auto snapshots separately (${stats.otherCount})`);

// --- cleanup ---
rmSync(profileDir, { recursive: true, force: true });
rmSync(join(HOME, "rollbacks", PROFILE), { recursive: true, force: true });
rmSync(join(HOME, "dsh-config-manager", "snapshots", cmId), { recursive: true, force: true });
for (const id of [...closeIds, ...manualIds, snap.id, imp.id, ...(firstRun.snapshot ? [firstRun.snapshot.id] : []), fullClose.id, light.id, KNOWN_GOOD_ID]) rmSync(join(HOME, ".kidai-snapshots", id), { recursive: true, force: true });
rmSync(join(HOME, ".kidai-snapshots", "exports"), { recursive: true, force: true });
if (guardSettingsBackup !== null) write(guardSettingsPath, guardSettingsBackup);
else rmSync(guardSettingsPath, { recursive: true, force: true });
write(join(HOME, "settings.yaml"), "ui-onboarding:\n  welcomeNoticeVersion: test\n");
ok(!existsSync(profileDir), "throwaway profile removed");
console.log(process.exitCode === 1 ? "SOME CHECKS FAILED" : "ALL CHECKS PASSED");
