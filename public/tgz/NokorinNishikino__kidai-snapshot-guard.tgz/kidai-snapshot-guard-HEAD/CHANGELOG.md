# Changelog

All notable changes to **Kidai Snapshot Guard (纪代快照守护)** are documented here.

## [1.3.5] - 2026-09-12

### Fixed

- **Import zip path traversal (zip-slip)** — `importSnapshotZip()` now strictly sanitizes zip entry names (rejects `..`, backslashes and absolute segments) and reconstructs packages from the export manifest's `name → rel` map, so a crafted zip can no longer write outside the snapshot directory.
- **Scoped-package round-trip** — exported zips of scoped third-party packages (names containing `/`, e.g. `@scope/demo`) now import back with the correct package key and restore to the right `node_modules/@scope/name` path (previously split at the first `/` and corrupted).
- **Imported snapshots record `packageVersions`** — `importSnapshotZip()` now derives each package's version so the external manager can still diagnose which plugin changed after the snapshot.
- **Pending snapshots only promoted on a known-good boot** — the guard now gates pending→verified (and the boot-time known-good refresh) on `profile-selection.active == lastKnownGood`, mirroring Kidai Plugin Remote, so a pending safety net is not thrown away before a trial boot proves healthy.
- **`plugin-management` path consistency** — `createSnapshot()` / `restoreSnapshot()` resolve the desktop user-data dir via `desktopUserDataDir()` instead of hardcoding `%APPDATA%\DSH Desktop`; `resolveActiveProfile()` now probes the same candidate dirs.
- **Boot not blocked by heavy snapshot work** — the boot-time known-good snapshot + quota prune are deferred off the constructor path instead of copying every package dir synchronously.
- **Export list cap** — the「导出 / 导入」page no longer hides exports beyond the first 10.

### Performance

- **Snapshot size stored in meta** — `createSnapshot()` records `size` in `snapshot.json` and `listSnapshots()` reads it back instead of walking every snapshot directory, so listing snapshots no longer performs a full recursive size scan per entry.

## [1.3.4] - 2026-09-02

### Added

- **Full-environment migration export** — `exportFullEnvironment()` + `/export-full` route + 「💾 导出完整环境」 button. Packs the whole `.dsh` (root config, guard settings, profile manifest/patch, all offline third-party package dirs, and a junction/symlink index) together with the desktop user-data state (profile-selection + plugin-management) into a single self-contained zip. Restores an identical running state on a new machine, or repairs a broken local config/packages without manual fixes.
- **Export zip management** — new `/exports-note`, `/exports-delete`, `/exports-restore` and `/open-exports` routes, plus `setExportNote()` and note-attachment in `listExports()`. Exported zips can now be annotated, deleted, restored back into a snapshot, and their location opened.
- **「导出 / 导入」 page enhancements** — the export list now shows each zip's note and per-row actions (备注 / 打开位置 / 恢复 / 删除); the toolbar shows exported count and total size and gains a refresh button.
- **`/open` accepts an empty id** — opens the snapshot store root (`$DSH_HOME/.kidai-snapshots`) instead of requiring a snapshot id.

### Notes

- Independent plugin: works standalone without Kidai Plugin Remote; the external manager reads the same snapshot store.
- Requires Node.js >= 22 (DSH bundled runtime).
