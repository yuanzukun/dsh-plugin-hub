import { defineConfig } from 'tsdown'

/**
 * Self-contained transpile for published `lib/`. Does not typecheck and does
 * not use the Harness monorepo project graph, so git/npm consumers can rebuild
 * without a sibling checkout.
 */
export default defineConfig({
  entry: ['src/index.ts'],
  outDir: 'lib',
  format: ['esm'],
  platform: 'node',
  target: 'es2024',
  dts: false,
  clean: true,
  fixedExtension: false,
  tsconfig: 'tsconfig.prepare.json',
  deps: { neverBundle: [/^@deepseek-ai\//] },
})
