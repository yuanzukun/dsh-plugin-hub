# dsh-travel-plan

给 DeepSeek Harness 加一套**能照着走的旅行攻略**：输入目的地（日期强烈建议），先从地图 / OTA / 票务把当地词汇和体验类候选扫出来，再从小红书、抖音、微博、B站看这个主题在当地怎么玩，核验营业时间、场次和活动日期，最后排出按天路线。

不是城市介绍，也不是「附近有哪些商场」。最终固定两段：

1. **完整 POI 总表** — 具体店名、楼层、机位、餐厅、演出/体验点，带来源和主题证据
2. **按天行程** — 上午 / 午餐 / 下午 / 晚餐 / 晚上，外加 TopK 备选（含活动/体验、演出/展览）

**POI（Point of Interest，兴趣点）** 是地图上一个有位置、能点名的地方：某家店、某个机位、某家餐厅、某场演出，不是「南京路」「某商场」这种片区。一条 POI 通常带名称、类别、地址、营业时间。攻略做到这个粒度，行程才能照着走。流程是：本地词汇 + 地图票务扫描（低社交热度但可订的体验点不能漏）→ 社交帖里补主题怎么玩（鲜活但不结构化）→ 核验开闭店、展期、场次 → 按区域串成一天。

仓库：[github.com/cosmic-snail/dsh-travel-plan](https://github.com/cosmic-snail/dsh-travel-plan) · 标签 [`dsh-plugin`](https://github.com/topics/dsh-plugin)

## 一眼看懂：它解决什么

直接对模型说「帮我做攻略」，常见结果是百科式介绍、只写到街区/商场、营业时间过时、主题被套成固定模板（比如「二次元 = 谷子店」），或者把「有趣的店」理解成只逛零售。

这个插件把流程钉死：

| 常见问题 | 这个插件怎么处理 |
|---|---|
| 空泛的城市介绍 | 只输出 POI 表和按天行程，要求具体店、具体机位、具体体验点 |
| 套全国通用模板 | 先做本地词汇发现，再搜「这个主题在这里通常怎么玩」，按当地结果建主题画像 |
| 小红书热帖当事实 | 社交结果标成「搜索结果摘要」；营业时间、闭店、展期、场次走核验 |
| 只靠社交热度会漏体验店 | 地图 / OTA / 票务单独扫一遍；弱小红书信号也可以进候选 |
| 「有趣的店」= 只逛零售 | 演出、沉浸式、展览、宠物咖、运动娱乐、手作、密室作为默认体验类 |
| 一天折返半个城 | 按区域聚类，同区串联 |
| 只有一个午餐推荐 | 每个决策位给 TopK：本地 / 平价 / 咖啡 / 活动 / 机位都有替换 |

适合：「上海南京路一天，五个人，二次元，不自驾」「香港旺角两天，复古文艺探店」「某商圈一下午，想找有趣的店和室内活动」。

不适合：只问某家店今天开不开；只要一段营销文案；完全离线、不能搜公开网页。

## 安装

需要 [Node.js](https://nodejs.org/) `^22.19 || >=24` 和 [dsh CLI](https://github.com/deepseek-ai/deepseek-harness)。Web UI / headless 默认带网页搜索。

```sh
dsh plugin --profile web add github:cosmic-snail/dsh-travel-plan
dsh web
```

无头：

```sh
dsh plugin --profile headless add github:cosmic-snail/dsh-travel-plan
dsh --profile headless "使用 /plan-travel-guide，帮我规划 2026-10-03 一天，地点围绕上海南京路。五个人，不自驾，中等预算，节奏适中，主题二次元。"
```

Git 安装已带预构建 `lib/`，**不用** `allowBuilds`。卸载：

```sh
dsh plugin --profile web remove dsh-travel-plan
```

## 怎么用

会话里点名 skill：

```
使用 /plan-travel-guide，帮我规划 2026-10-03 到 2026-10-05 的旅行攻略。
目的地：香港旺角
住宿：香港富荟旺角酒店
人数：5人
交通：不自驾
预算：中等
节奏：适中
主题：二次元、复古文艺探店
```

必填：目的地。日期强烈建议（多日、门票、演出、展期尤其需要）；半日/本地常设路线若没给日期，按当日或近期公开状态核验，并标 `需当日确认`。人数、预算、主题、是否自驾等缺了会用合理默认值，不会为这些停下来追问。用户说「活动 / 有趣的店 / 商圈 / 一下午」时，默认把体验类 POI 算进去。

## 它往 Harness 里加了什么

| 类型 | 名称 | 作用 |
|---|---|---|
| Skill | `plan-travel-guide` | 工作流和输出格式：本地词汇 → 地图票务扫描 → 主题发现 → 核验 → 排程 |
| 工具 | `travel_search_catalog` | 扫地图 / OTA / 点评 / 票务 / 官网导览，挖当地词汇和体验类候选 |
| 工具 | `travel_search_social` | 按平台搜小红书 / 抖音 / 微博 / B站 / 公开网页（也可指定 Instagram / YouTube / Reddit） |
| 工具 | `travel_verify_poi` | 核验地址、营业时间、开闭店、预约、票务、活动日期、场次、限制 |
| 工具 | `travel_plan_route` | 按区域聚类，填上午到晚上的时段 |

社交帖只当发现信号。打不开的帖子不会假装读过，也不会编造链接。地图和票务上能订的点，即使小红书不热也可以进表。

## 配置

在 profile 的 `cordis.patch.yml` 里覆盖这一行（patch 替换整段 `config`，改了就要把用到的键写全）：

```yaml
- id: travel-planner
  config:
    searchMaxResults: 8
    searchTimeoutMs: 30000
    verifyTimeoutMs: 45000
    fetchMaxChars: 8000
```

| 字段 | 默认 | 含义 |
|---|---|---|
| `searchMaxResults` | `8` | 每个平台一次搜索返回的来源上限 |
| `searchTimeoutMs` | `30000` | `travel_search_social` / `travel_search_catalog` 超时（毫秒） |
| `verifyTimeoutMs` | `45000` | `travel_verify_poi` 超时（毫秒） |
| `fetchMaxChars` | `8000` | 核验时抓取页面的字符上限 |

没有可用的网页搜索提供方时，skill 和 `travel_plan_route` 仍会加载，三个搜索类工具不会出现。

## 在 Harness 源码树里开发

把本目录放在 DeepSeek Harness checkout 旁，可直接加载 TypeScript：

```sh
pnpm dsh web --patch ./travel-plugin/cordis.yml
```

`cordis.yml` 里是 `src/index.ts` 的绝对路径。发布前重新构建：

```sh
pnpm install
pnpm build
```

## 来源

工作流和输出格式来自 [TravelPlan-Skill](https://github.com/cosmic-snail/TravelPlan-Skill)（含活动 POI 发现与本地词汇扫描更新）。打包方式见 [dsh 插件发布教程](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.md)。
