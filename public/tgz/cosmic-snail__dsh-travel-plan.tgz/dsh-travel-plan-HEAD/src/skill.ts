import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import type { SkillRegistration } from '@deepseek-ai/dsh-skill'

const SKILL_FILE = new URL('../skill/SKILL.md', import.meta.url)

/** Directory the skill body may resolve relative resources against. */
export const travelSkillResourceBase = {
  kind: 'directory',
  path: fileURLToPath(new URL('../skill/', import.meta.url)),
} as const

const DESCRIPTION =
  'Use when planning destination/date-based travel guides that need current social-platform, map, OTA, ticketing, and local web discovery for dense POI tables, TopK choices, travel themes, restaurants, cafes, shops, attractions, shows, activities, exhibitions, scene/photo spots, and day-by-day routes.'

/**
 * Strip YAML frontmatter so the model sees only the instruction body.
 * @param raw - full SKILL.md text.
 * @returns markdown after the closing `---` fence, or the original text.
 */
export function stripFrontmatter(raw: string): string {
  if (!raw.startsWith('---')) return raw.trim()
  const end = raw.indexOf('\n---', 3)
  if (end === -1) return raw.trim()
  return raw.slice(end + 4).replace(/^\s*\n/, '').trimEnd()
}

/** Instruction body loaded from `skill/SKILL.md`. */
export const travelSkillContent = stripFrontmatter(readFileSync(SKILL_FILE, 'utf8'))

/** Runtime skill contribution registered on `ctx.skills`. */
export const travelSkill: SkillRegistration = {
  name: 'plan-travel-guide',
  description: DESCRIPTION,
  whenToUse: DESCRIPTION,
  source: 'runtime',
  invocation: {
    modelInvocable: true,
    userInvocable: true,
  },
  resourceBase: travelSkillResourceBase,
  content: travelSkillContent,
}
