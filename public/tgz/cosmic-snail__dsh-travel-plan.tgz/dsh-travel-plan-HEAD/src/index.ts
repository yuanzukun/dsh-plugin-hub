import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-skill'
import type {} from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-web'
import { Config, resolveConfig } from './config.ts'
import { travelSkill } from './skill.ts'
import { registerRouteTool } from './tools/route.ts'
import { registerCatalogSearchTool } from './tools/search-catalog.ts'
import { registerSocialSearchTool } from './tools/search-social.ts'
import { registerPoiVerifyTool } from './tools/verify-poi.ts'

export { Config }

/** Cordis plugin name used by loader diagnostics. */
export const name = 'travel-plan'

/** Skill registry and tool registry are required; web is optional so the skill still loads without a search provider. */
export const inject = ['skills', 'tools']

/**
 * Register the `plan-travel-guide` skill and travel tools.
 * @param ctx - plugin context.
 * @param config - schema-defaulted search and fetch limits.
 */
export function apply(ctx: Context, config: Config = Config({})): void {
  const resolved = resolveConfig(Config(config))
  ctx.skills.register(travelSkill)
  registerRouteTool(ctx, resolved)
  ctx.inject(['web'], (webCtx) => {
    registerCatalogSearchTool(webCtx, resolved)
    registerSocialSearchTool(webCtx, resolved)
    registerPoiVerifyTool(webCtx, resolved)
  })
}
