import Schema from '@deepseek-ai/schemastery'

/** Deployment-varying search and fetch limits for the travel plugin. */
export interface Config {
  /** Upper bound on sources returned by one platform search. */
  readonly searchMaxResults: number
  /** Cooperative timeout (ms) for `travel_search_social` and `travel_search_catalog`. */
  readonly searchTimeoutMs: number
  /** Cooperative timeout (ms) for `travel_verify_poi`. */
  readonly verifyTimeoutMs: number
  /** Character cap on an optional fetched verification page. */
  readonly fetchMaxChars: number
}

/** Schemastery schema: defaults live here, not as plugin constants. */
export const Config: Schema<Config> = Schema.object({
  searchMaxResults: Schema.number().default(8),
  searchTimeoutMs: Schema.number().default(30_000),
  verifyTimeoutMs: Schema.number().default(45_000),
  fetchMaxChars: Schema.number().default(8_000),
})

/**
 * Reject non-positive integer config fields at load time.
 * @param config - schema-defaulted plugin config.
 * @returns the same object after the integer checks.
 */
export function resolveConfig(config: Config): Config {
  assertPositiveInteger('searchMaxResults', config.searchMaxResults)
  assertPositiveInteger('searchTimeoutMs', config.searchTimeoutMs)
  assertPositiveInteger('verifyTimeoutMs', config.verifyTimeoutMs)
  assertPositiveInteger('fetchMaxChars', config.fetchMaxChars)
  return config
}

function assertPositiveInteger(name: string, value: number): void {
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(`travel-plan: ${name} must be a positive integer`)
  }
}
