/** Supported social / web discovery families. */
export const SOCIAL_PLATFORMS = [
  'xiaohongshu',
  'douyin',
  'weibo',
  'bilibili',
  'web',
  'instagram',
  'youtube',
  'reddit',
] as const

/** Default first-pass set: Chinese social families plus open web. */
export const DEFAULT_SOCIAL_PLATFORMS = [
  'xiaohongshu',
  'douyin',
  'weibo',
  'bilibili',
  'web',
] as const

/** One discovery family, or the default first-pass set. */
export type SocialPlatform = (typeof SOCIAL_PLATFORMS)[number]

/** Model-facing platform argument, including the fan-out value. */
export type SocialPlatformArg = SocialPlatform | 'all'

/** Non-social catalog families used for vocabulary and category sweeps. */
export const CATALOG_FAMILIES = ['maps', 'ota', 'reviews', 'ticketing', 'official'] as const

/** One catalog family, or all of them in one call. */
export type CatalogFamily = (typeof CATALOG_FAMILIES)[number]

/** Model-facing catalog argument, including the fan-out value. */
export type CatalogFamilyArg = CatalogFamily | 'all'

const SOCIAL_SITE_HINTS: Record<SocialPlatform, string> = {
  xiaohongshu: '(site:xiaohongshu.com OR site:xhslink.com OR site:rednote.com OR 小红书)',
  douyin: '(site:douyin.com OR site:iesdouyin.com OR 抖音 OR TikTok)',
  weibo: '(site:weibo.com OR site:weibo.cn OR 微博)',
  bilibili: '(site:bilibili.com OR site:b23.tv OR B站 OR 哔哩哔哩)',
  web: '',
  instagram: '(site:instagram.com OR Instagram)',
  youtube: '(site:youtube.com OR site:youtu.be OR YouTube)',
  reddit: '(site:reddit.com OR Reddit)',
}

const CATALOG_SITE_HINTS: Record<CatalogFamily, string> = {
  maps: '(高德 OR 百度地图 OR 腾讯地图 OR Google Maps OR Apple Maps OR Amap OR 地图)',
  ota: '(携程 OR 去哪儿 OR Trip.com OR Ctrip OR Klook OR GetYourGuide OR 当地玩乐)',
  reviews: '(大众点评 OR Dianping OR Tripadvisor OR Yelp OR OpenRice OR 点评)',
  ticketing: '(猫眼 OR 大麦 OR 豆瓣同城 OR Eventbrite OR Ticketmaster OR 购票 OR 演出)',
  official: '(官网 OR official OR 导览 OR 楼层目录 OR 旅游局 OR directory OR floor plan)',
}

/**
 * Build the public-web query for one social platform family.
 * @param platform - discovery family.
 * @param destination - city, neighborhood, or corridor.
 * @param query - theme or POI probe.
 * @param area - optional lodging or district qualifier.
 * @returns a search string that prefers that platform's public pages.
 */
export function buildSocialQuery(
  platform: SocialPlatform,
  destination: string,
  query: string,
  area?: string,
): string {
  return joinQuery(destination, query, area, SOCIAL_SITE_HINTS[platform])
}

/**
 * Build the public-web query for one catalog family.
 * @param family - map / OTA / review / ticketing / official.
 * @param destination - city, neighborhood, or corridor.
 * @param query - vocabulary or category probe.
 * @param area - optional container, mall, or district qualifier.
 * @returns a search string that prefers that catalog family's public pages.
 */
export function buildCatalogQuery(
  family: CatalogFamily,
  destination: string,
  query: string,
  area?: string,
): string {
  return joinQuery(destination, query, area, CATALOG_SITE_HINTS[family])
}

/**
 * Expand `all` into the default Chinese+web first pass; otherwise a one-item list.
 * @param platform - model argument.
 * @returns platforms to search.
 */
export function expandPlatforms(platform: SocialPlatformArg): readonly SocialPlatform[] {
  return platform === 'all' ? DEFAULT_SOCIAL_PLATFORMS : [platform]
}

/**
 * Expand `all` into the five catalog families; otherwise a one-item list.
 * @param family - model argument.
 * @returns catalog families to search.
 */
export function expandCatalogFamilies(family: CatalogFamilyArg): readonly CatalogFamily[] {
  return family === 'all' ? CATALOG_FAMILIES : [family]
}

/** Human label used in tool output and evidence notes. */
export function platformLabel(platform: SocialPlatform): string {
  switch (platform) {
    case 'xiaohongshu':
      return '小红书'
    case 'douyin':
      return '抖音'
    case 'weibo':
      return '微博'
    case 'bilibili':
      return 'B站'
    case 'web':
      return '公开网页'
    case 'instagram':
      return 'Instagram'
    case 'youtube':
      return 'YouTube'
    case 'reddit':
      return 'Reddit'
    default: {
      const exhaustive: never = platform
      return exhaustive
    }
  }
}

/** Human label used in catalog-search output. */
export function catalogFamilyLabel(family: CatalogFamily): string {
  switch (family) {
    case 'maps':
      return '地图'
    case 'ota':
      return 'OTA/当地玩乐'
    case 'reviews':
      return '点评'
    case 'ticketing':
      return '票务/演出'
    case 'official':
      return '官网/导览'
    default: {
      const exhaustive: never = family
      return exhaustive
    }
  }
}

function joinQuery(destination: string, query: string, area: string | undefined, hint: string): string {
  const parts = [destination]
  if (area !== undefined && area.length > 0) parts.push(area)
  parts.push(query)
  if (hint.length > 0) parts.push(hint)
  return parts.join(' ')
}
