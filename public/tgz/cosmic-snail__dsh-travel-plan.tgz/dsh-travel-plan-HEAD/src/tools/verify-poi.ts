import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-web'
import type { Config } from '../config.ts'
import {
  citedSourcesSchema,
  extractFetchedText,
  formatSourceList,
  projectSources,
  requireNonEmpty,
} from '../sources.ts'

const FACTS = [
  'address',
  'hours',
  'status',
  'booking',
  'tickets',
  'event-dates',
  'sessions',
  'restrictions',
] as const

const FACT_QUERIES: Record<(typeof FACTS)[number], string> = {
  address: '地址 怎么去',
  hours: '营业时间 开门 关门 休息日',
  status: '停业 装修 闭店 暂停营业 迁址',
  booking: '预约 排队 等位',
  tickets: '门票 票务 预约入场 last entry',
  'event-dates': '展期 快闪 活动日期 开放时间',
  sessions: '场次 排期 演出时间 开放场次 session showtime',
  restrictions: '年龄限制 身高限制 孕妇 心脏病 宠物过敏 着装 last entry',
}

/**
 * Register `travel_verify_poi`.
 * @param ctx - context whose `tools` and `web` services are ready.
 * @param config - search cap, timeout, and fetch character cap.
 */
export function registerPoiVerifyTool(ctx: Context, config: Config): void {
  ctx.tools.register(defineTool({
    name: 'travel_verify_poi',
    description:
      'Verify time-sensitive POI facts from public web search (and an optional official URL). '
      + 'Use after catalog and social discovery, before putting a POI on the itinerary. '
      + 'Returns evidence snippets; interpret conflicts as uncertain rather than inventing hours or session times.',
    parameters: {
      name: {
        type: 'string',
        required: true,
        description: 'Concrete venue, shop, exhibition, show, activity, or scene name.',
      },
      area: {
        type: 'string',
        description: 'District, mall, street, or metro exit that disambiguates branches.',
      },
      dates: {
        type: 'string',
        description: 'Trip dates (ISO), required when checking event-dates / pop-ups.',
      },
      facts: {
        type: 'array',
        items: { type: 'string', enum: FACTS },
        description: 'Facts to check. Default: address, hours, and open/closed status. Add sessions and restrictions for shows, immersive, sports, pet cafes, and ticketed venues.',
      },
      url: {
        type: 'string',
        description: 'Optional official, map, or business page to fetch in full.',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          name: { type: 'string', required: true },
          area: { type: 'string' },
          dates: { type: 'string' },
          checks: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                fact: { type: 'string', required: true, enum: FACTS },
                query: { type: 'string', required: true },
                evidenceKind: { type: 'string', required: true, const: '搜索结果摘要' },
                content: { type: 'string' },
                sources: citedSourcesSchema,
                truncated: { type: 'boolean', required: true },
              },
            },
          },
          fetched: {
            type: 'object',
            additionalProperties: false,
            properties: {
              url: { type: 'string', required: true },
              statusCode: { type: 'integer', required: true },
              truncated: { type: 'boolean', required: true },
              content: { type: 'string', required: true },
            },
          },
        },
      },
      render: (_args, value) => [{ type: 'text', text: renderVerify(value) }],
    },
    timeoutMs: config.verifyTimeoutMs,
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const name = requireNonEmpty(args.name, 'name')
      const area = args.area === undefined ? undefined : requireNonEmpty(args.area, 'area')
      const dates = args.dates === undefined ? undefined : requireNonEmpty(args.dates, 'dates')
      const facts = args.facts === undefined || args.facts.length === 0
        ? ['address', 'hours', 'status'] as const
        : args.facts
      const place = area === undefined ? name : `${name} ${area}`

      const checks = await Promise.all(facts.map(async (fact) => {
        const extra = (fact === 'event-dates' || fact === 'sessions') && dates !== undefined ? dates : ''
        const query = [place, FACT_QUERIES[fact], extra].filter(part => part.length > 0).join(' ')
        const result = await ctx.web.search(
          { query, maxResults: config.searchMaxResults },
          exec.signal,
        )
        return {
          fact,
          query,
          evidenceKind: '搜索结果摘要' as const,
          ...result.content !== undefined && result.content.length > 0 ? { content: result.content } : {},
          sources: projectSources(result),
          truncated: result.truncated,
        }
      }))

      let fetched: ReturnType<typeof extractFetchedText> | undefined
      if (args.url !== undefined) {
        const url = requireNonEmpty(args.url, 'url')
        const result = await ctx.web.fetch({ url }, exec.signal)
        fetched = extractFetchedText(result, config.fetchMaxChars)
      }

      return {
        name,
        ...area !== undefined ? { area } : {},
        ...dates !== undefined ? { dates } : {},
        checks,
        ...fetched !== undefined ? { fetched } : {},
      }
    },
    presentCall(args) {
      return {
        card: 'generic',
        title: `Verify ${args.name}`,
        kind: 'search',
        rawInput: args.area === undefined ? args.name : `${args.name} · ${args.area}`,
      }
    },
  }))
}

function renderVerify(value: {
  name: string
  area?: string
  dates?: string
  checks: readonly {
    fact: string
    query: string
    evidenceKind: string
    content?: string
    sources: readonly { url: string; title?: string; snippet?: string; publishedAt?: string }[]
    truncated: boolean
  }[]
  fetched?: { url: string; statusCode: number; truncated: boolean; content: string }
}): string {
  const header = [
    `# ${value.name}`,
    value.area !== undefined ? `Area: ${value.area}` : undefined,
    value.dates !== undefined ? `Dates: ${value.dates}` : undefined,
    '',
    'Treat the following as public-web evidence. If sources conflict or only snippets exist, mark the fact uncertain in 注意事项. Do not invent hours, closures, session times, or event dates.',
  ].filter((line): line is string => line !== undefined)

  const checks = value.checks.map((check) => {
    const lines = [
      `## ${check.fact}`,
      '',
      `Query: ${check.query}`,
      `Evidence: ${check.evidenceKind}`,
    ]
    if (check.content !== undefined && check.content.length > 0) lines.push('', check.content)
    lines.push('', formatSourceList(check.sources))
    if (check.truncated) lines.push('', `(Showing the first ${check.sources.length} sources.)`)
    return lines.join('\n')
  })

  const fetched = value.fetched === undefined
    ? []
    : [
      '## Fetched page',
      '',
      `URL: ${value.fetched.url}`,
      `Status: ${value.fetched.statusCode}`,
      value.fetched.truncated ? 'Body truncated.' : undefined,
      '',
      value.fetched.content,
    ].filter((line): line is string => line !== undefined)

  return [...header, '', ...checks, ...fetched.length > 0 ? ['', ...fetched] : []].join('\n')
}
