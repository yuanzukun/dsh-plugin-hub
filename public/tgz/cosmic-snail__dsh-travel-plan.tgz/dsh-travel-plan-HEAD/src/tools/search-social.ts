import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-web'
import type { Config } from '../config.ts'
import { buildSocialQuery, expandPlatforms, platformLabel, SOCIAL_PLATFORMS } from '../platforms.ts'
import { citedSourcesSchema, formatSourceList, projectSources, requireNonEmpty } from '../sources.ts'

const PLATFORM_ENUM = [...SOCIAL_PLATFORMS, 'all'] as const

/**
 * Register `travel_search_social`.
 * @param ctx - context whose `tools` and `web` services are ready.
 * @param config - search cap and cooperative timeout.
 */
export function registerSocialSearchTool(ctx: Context, config: Config): void {
  ctx.tools.register(defineTool({
    name: 'travel_search_social',
    description:
      'Search current public results for a travel theme or POI probe on 小红书, 抖音, 微博, B站, Instagram, YouTube, Reddit, or the open web. '
      + 'Use this for platform-led theme discovery. Default all is 小红书+抖音+微博+B站+web. Results are search snippets, not full posts.',
    parameters: {
      destination: {
        type: 'string',
        required: true,
        description: 'City, neighborhood, scenic corridor, or lodging area.',
      },
      query: {
        type: 'string',
        required: true,
        description: 'Theme or POI probe, e.g. 二次元怎么玩, 谷子店, 夜景机位.',
      },
      platform: {
        type: 'string',
        enum: PLATFORM_ENUM,
        description: 'Discovery family. Default all (小红书 + 抖音 + 微博 + B站 + web). Use instagram/youtube/reddit for non-CN destinations.',
      },
      area: {
        type: 'string',
        description: 'Optional smaller area: hotel block, metro corridor, or district.',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          platforms: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                platform: { type: 'string', required: true, enum: SOCIAL_PLATFORMS },
                label: { type: 'string', required: true },
                query: { type: 'string', required: true },
                evidenceKind: { type: 'string', required: true, const: '搜索结果摘要' },
                content: { type: 'string' },
                sources: citedSourcesSchema,
                truncated: { type: 'boolean', required: true },
              },
            },
          },
        },
      },
      render: (_args, value) => [{ type: 'text', text: renderSocialSearch(value) }],
    },
    timeoutMs: config.searchTimeoutMs,
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const destination = requireNonEmpty(args.destination, 'destination')
      const query = requireNonEmpty(args.query, 'query')
      const area = args.area === undefined ? undefined : requireNonEmpty(args.area, 'area')
      const platforms = expandPlatforms(args.platform ?? 'all')
      const results = await Promise.all(platforms.map(async (platform) => {
        const built = buildSocialQuery(platform, destination, query, area)
        const result = await ctx.web.search(
          { query: built, maxResults: config.searchMaxResults },
          exec.signal,
        )
        return {
          platform,
          label: platformLabel(platform),
          query: built,
          evidenceKind: '搜索结果摘要' as const,
          ...result.content !== undefined && result.content.length > 0 ? { content: result.content } : {},
          sources: projectSources(result),
          truncated: result.truncated,
        }
      }))
      return { platforms: results }
    },
    presentCall(args) {
      const platform = args.platform ?? 'all'
      return {
        card: 'generic',
        title: `${args.destination} · ${args.query}`,
        kind: 'search',
        rawInput: `${platform}: ${args.destination} ${args.query}`,
      }
    },
  }))
}

function renderSocialSearch(value: {
  platforms: readonly {
    platform: string
    label: string
    query: string
    evidenceKind: string
    content?: string
    sources: readonly { url: string; title?: string; snippet?: string; publishedAt?: string }[]
    truncated: boolean
  }[]
}): string {
  const blocks = value.platforms.map((entry) => {
    const lines = [
      `## ${entry.label} (\`${entry.platform}\`)`,
      '',
      `Query: ${entry.query}`,
      `Evidence: ${entry.evidenceKind}`,
    ]
    if (entry.content !== undefined && entry.content.length > 0) {
      lines.push('', entry.content)
    }
    lines.push('', formatSourceList(entry.sources))
    if (entry.truncated) {
      lines.push('', `(Showing the first ${entry.sources.length} sources. Refine the query for more.)`)
    }
    return lines.join('\n')
  })
  return `${blocks.join('\n\n')}\n\nCite the relevant URLs above as markdown links. Do not pretend unread posts were opened.`
}
