import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type {} from '@deepseek-ai/dsh-web'
import type { Config } from '../config.ts'
import {
  buildCatalogQuery,
  CATALOG_FAMILIES,
  catalogFamilyLabel,
  expandCatalogFamilies,
} from '../platforms.ts'
import { citedSourcesSchema, formatSourceList, projectSources, requireNonEmpty } from '../sources.ts'

const FAMILY_ENUM = [...CATALOG_FAMILIES, 'all'] as const

/**
 * Register `travel_search_catalog`.
 * @param ctx - context whose `tools` and `web` services are ready.
 * @param config - search cap and cooperative timeout.
 */
export function registerCatalogSearchTool(ctx: Context, config: Config): void {
  ctx.tools.register(defineTool({
    name: 'travel_search_catalog',
    description:
      'Search maps, OTA/local-play, reviews, ticketing, and official directories for travel vocabulary and category POIs. '
      + 'Use this for Local Vocabulary Discovery and Map/OTA/Ticketing Category Sweep before or with social discovery. '
      + 'Results are search snippets, not full pages.',
    parameters: {
      destination: {
        type: 'string',
        required: true,
        description: 'City, neighborhood, scenic corridor, or lodging area.',
      },
      query: {
        type: 'string',
        required: true,
        description: 'Vocabulary or category probe, e.g. neighborhoods official site, 周边玩乐, 商场 楼层目录.',
      },
      family: {
        type: 'string',
        enum: FAMILY_ENUM,
        description: 'Catalog family. Default all (maps + OTA + reviews + ticketing + official).',
      },
      area: {
        type: 'string',
        description: 'Optional container: mall, street, park, venue district, or metro corridor.',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          families: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                family: { type: 'string', required: true, enum: CATALOG_FAMILIES },
                label: { type: 'string', required: true },
                query: { type: 'string', required: true },
                evidenceKind: { type: 'string', required: true, const: '搜索结果摘要' },
                content: { type: 'string' },
                sources: citedSourcesSchema,
                truncated: { type: 'boolean', required: true },
              },
            },
          },
        },
      },
      render: (_args, value) => [{ type: 'text', text: renderCatalogSearch(value) }],
    },
    timeoutMs: config.searchTimeoutMs,
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const destination = requireNonEmpty(args.destination, 'destination')
      const query = requireNonEmpty(args.query, 'query')
      const area = args.area === undefined ? undefined : requireNonEmpty(args.area, 'area')
      const families = expandCatalogFamilies(args.family ?? 'all')
      const results = await Promise.all(families.map(async (family) => {
        const built = buildCatalogQuery(family, destination, query, area)
        const result = await ctx.web.search(
          { query: built, maxResults: config.searchMaxResults },
          exec.signal,
        )
        return {
          family,
          label: catalogFamilyLabel(family),
          query: built,
          evidenceKind: '搜索结果摘要' as const,
          ...result.content !== undefined && result.content.length > 0 ? { content: result.content } : {},
          sources: projectSources(result),
          truncated: result.truncated,
        }
      }))
      return { families: results }
    },
    presentCall(args) {
      const family = args.family ?? 'all'
      return {
        card: 'generic',
        title: `${args.destination} · ${args.query}`,
        kind: 'search',
        rawInput: `${family}: ${args.destination} ${args.query}`,
      }
    },
  }))
}

function renderCatalogSearch(value: {
  families: readonly {
    family: string
    label: string
    query: string
    evidenceKind: string
    content?: string
    sources: readonly { url: string; title?: string; snippet?: string; publishedAt?: string }[]
    truncated: boolean
  }[]
}): string {
  const blocks = value.families.map((entry) => {
    const lines = [
      `## ${entry.label} (\`${entry.family}\`)`,
      '',
      `Query: ${entry.query}`,
      `Evidence: ${entry.evidenceKind}`,
    ]
    if (entry.content !== undefined && entry.content.length > 0) {
      lines.push('', entry.content)
    }
    lines.push('', formatSourceList(entry.sources))
    if (entry.truncated) {
      lines.push('', `(Showing the first ${entry.sources.length} sources. Refine the query for more.)`)
    }
    return lines.join('\n')
  })
  return `${blocks.join('\n\n')}\n\nCite the relevant URLs above as markdown links. Weak social buzz is not a reason to drop a named map/OTA/ticketing venue.`
}
