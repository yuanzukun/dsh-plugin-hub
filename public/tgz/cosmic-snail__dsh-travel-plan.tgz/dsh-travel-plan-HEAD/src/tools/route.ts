import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { Config } from '../config.ts'
import { requireNonEmpty } from '../sources.ts'

const PACES = ['relaxed', 'moderate', 'packed'] as const
const SLOTS = ['morning', 'lunch', 'afternoon', 'dinner', 'evening'] as const
const POI_TYPES = [
  '景点', '餐厅', '小吃', '咖啡', '商店', '市集', '展览',
  '演出', '剧场', '沉浸体验', '宠物咖', '运动娱乐', '手作', '桌游密室',
  '夜生活', '街区', '周边游', '机位', '巡礼', '取景地', '活动', '其他',
] as const

type Pace = (typeof PACES)[number]
type Slot = (typeof SLOTS)[number]
type PoiType = (typeof POI_TYPES)[number]

/** One candidate POI supplied by the model after discovery and verification. */
export interface RoutePoiInput {
  readonly name: string
  readonly type: PoiType
  readonly area: string
  readonly stayMinutes: number
  readonly theme?: string
}

interface AssignedStop {
  readonly name: string
  readonly type: PoiType
  readonly area: string
  readonly stayMinutes: number
  readonly theme?: string
}

interface DayPlan {
  readonly day: number
  readonly area: string
  readonly slots: { readonly slot: Slot; readonly stops: AssignedStop[] }[]
}

const SLOT_PREFERENCE: Record<PoiType, readonly Slot[]> = {
  景点: ['morning', 'afternoon'],
  餐厅: ['lunch', 'dinner'],
  小吃: ['lunch', 'afternoon', 'evening'],
  咖啡: ['morning', 'afternoon'],
  商店: ['afternoon', 'morning'],
  市集: ['afternoon', 'evening'],
  展览: ['morning', 'afternoon'],
  演出: ['evening', 'afternoon'],
  剧场: ['evening', 'afternoon'],
  沉浸体验: ['afternoon', 'evening', 'morning'],
  宠物咖: ['afternoon', 'morning'],
  运动娱乐: ['afternoon', 'morning'],
  手作: ['afternoon', 'morning'],
  桌游密室: ['afternoon', 'evening'],
  夜生活: ['evening'],
  街区: ['morning', 'afternoon'],
  周边游: ['morning', 'afternoon'],
  机位: ['morning', 'afternoon', 'evening'],
  巡礼: ['morning', 'afternoon'],
  取景地: ['morning', 'afternoon', 'evening'],
  活动: ['morning', 'afternoon', 'evening'],
  其他: ['afternoon', 'morning'],
}

const STAY_BUDGET: Record<Pace, number> = {
  relaxed: 240,
  moderate: 360,
  packed: 480,
}

const SLOT_LABEL: Record<Slot, string> = {
  morning: '上午',
  lunch: '午餐',
  afternoon: '下午',
  dinner: '晚餐',
  evening: '晚上',
}

/**
 * Cluster POIs by area, pack them into days by stay-time budget, and assign day parts.
 * @param pois - verified candidate POIs.
 * @param days - trip length in days.
 * @param pace - daily stay-time budget.
 * @returns scheduled days plus leftovers for TopK.
 */
export function planRoute(
  pois: readonly RoutePoiInput[],
  days: number,
  pace: Pace,
): { days: DayPlan[]; unused: AssignedStop[] } {
  const budget = STAY_BUDGET[pace]
  const clusters = clusterByArea(pois)
  const unused: AssignedStop[] = []
  const dayAreas: { area: string; stops: AssignedStop[] }[] = Array.from(
    { length: days },
    () => ({ area: '', stops: [] }),
  )

  for (const cluster of clusters) {
    const target = pickDay(dayAreas, cluster.stops, budget)
    if (target === undefined) {
      unused.push(...cluster.stops)
      continue
    }
    if (target.area.length === 0) target.area = cluster.area
    const room = budget - stayTotal(target.stops)
    const { taken, leftover } = takeUntil(cluster.stops, room)
    target.stops.push(...taken)
    unused.push(...leftover)
  }

  return {
    days: dayAreas.map((entry, index) => ({
      day: index + 1,
      area: entry.area.length > 0 ? entry.area : '未分区',
      slots: assignSlots(entry.stops),
    })),
    unused,
  }
}

/**
 * Register `travel_plan_route`.
 * @param ctx - context whose `tools` service is ready.
 * @param config - cooperative timeout for the (CPU-bound) planner.
 */
export function registerRouteTool(ctx: Context, config: Config): void {
  ctx.tools.register(defineTool({
    name: 'travel_plan_route',
    description:
      'Cluster verified POIs by area and fill morning/lunch/afternoon/dinner/evening slots. '
      + 'Call this after verification. The result is a geographic skeleton; you still write '
      + '`1）完整 POI 总表` and `2）按天行程` with TopK backups for meals, shopping, activities, and shows.',
    parameters: {
      days: {
        type: 'integer',
        required: true,
        description: 'Number of itinerary days (end date minus start date, plus one).',
      },
      pace: {
        type: 'string',
        enum: PACES,
        description: 'Daily density. Default moderate.',
      },
      driving: {
        type: 'boolean',
        description: 'True when the group is self-driving. Default false.',
      },
      pois: {
        type: 'array',
        required: true,
        description: 'Verified candidate POIs to cluster. Extra POIs become unused TopK backups.',
        items: {
          type: 'object',
          additionalProperties: false,
          properties: {
            name: { type: 'string', required: true, description: 'Concrete venue or scene name.' },
            type: { type: 'string', required: true, enum: POI_TYPES },
            area: { type: 'string', required: true, description: 'Neighborhood, mall, or corridor.' },
            stayMinutes: { type: 'integer', required: true, description: 'Suggested stay in minutes.' },
            theme: { type: 'string', description: 'Leading Theme Profile label.' },
          },
        },
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          driving: { type: 'boolean', required: true },
          days: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                day: { type: 'integer', required: true },
                area: { type: 'string', required: true },
                slots: {
                  type: 'array',
                  required: true,
                  items: {
                    type: 'object',
                    additionalProperties: false,
                    properties: {
                      slot: { type: 'string', required: true, enum: SLOTS },
                      stops: {
                        type: 'array',
                        required: true,
                        items: poiOutputSchema(),
                      },
                    },
                  },
                },
              },
            },
          },
          unused: {
            type: 'array',
            required: true,
            items: poiOutputSchema(),
          },
        },
      },
      render: (_args, value) => [{ type: 'text', text: renderRoute(value) }],
    },
    timeoutMs: config.searchTimeoutMs,
    isConcurrencySafe: () => true,
    async execute(args) {
      if (!Number.isInteger(args.days) || args.days < 1) {
        throw new Error('days must be an integer greater than or equal to 1')
      }
      const pois = args.pois.map((poi) => {
        if (!Number.isInteger(poi.stayMinutes) || poi.stayMinutes < 1) {
          throw new Error(`stayMinutes must be a positive integer (${poi.name})`)
        }
        return {
          name: requireNonEmpty(poi.name, 'pois.name'),
          type: poi.type,
          area: requireNonEmpty(poi.area, 'pois.area'),
          stayMinutes: poi.stayMinutes,
          ...poi.theme !== undefined && poi.theme.trim().length > 0
            ? { theme: poi.theme.trim() }
            : {},
        }
      })
      const planned = planRoute(pois, args.days, args.pace ?? 'moderate')
      return {
        driving: args.driving ?? false,
        days: planned.days,
        unused: planned.unused,
      }
    },
    presentCall(args) {
      return {
        card: 'generic',
        title: `Route ${args.days} day(s)`,
        rawInput: `${args.pois.length} POIs`,
      }
    },
  }))
}

function poiOutputSchema() {
  return {
    type: 'object',
    additionalProperties: false,
    properties: {
      name: { type: 'string', required: true },
      type: { type: 'string', required: true, enum: POI_TYPES },
      area: { type: 'string', required: true },
      stayMinutes: { type: 'integer', required: true },
      theme: { type: 'string' },
    },
  } as const
}

function clusterByArea(pois: readonly RoutePoiInput[]): { area: string; stops: AssignedStop[] }[] {
  const groups = new Map<string, AssignedStop[]>()
  for (const poi of pois) {
    const area = poi.area.trim()
    const list = groups.get(area) ?? []
    list.push({
      name: poi.name,
      type: poi.type,
      area,
      stayMinutes: poi.stayMinutes,
      ...poi.theme !== undefined ? { theme: poi.theme } : {},
    })
    groups.set(area, list)
  }
  return [...groups.entries()]
    .map(([area, stops]) => ({ area, stops }))
    .sort((left, right) => stayTotal(right.stops) - stayTotal(left.stops) || right.stops.length - left.stops.length)
}

function pickDay(
  days: { area: string; stops: AssignedStop[] }[],
  incoming: readonly AssignedStop[],
  budget: number,
): { area: string; stops: AssignedStop[] } | undefined {
  const area = incoming[0]?.area ?? ''
  const same = days.find(day => day.area === area && stayTotal(day.stops) < budget)
  if (same !== undefined) return same
  return days.find(day => day.area.length === 0 || stayTotal(day.stops) < budget)
}

function takeUntil(stops: readonly AssignedStop[], room: number): {
  taken: AssignedStop[]
  leftover: AssignedStop[]
} {
  const taken: AssignedStop[] = []
  const leftover: AssignedStop[] = []
  let used = 0
  for (const stop of stops) {
    if (used + stop.stayMinutes <= room || taken.length === 0 && room > 0) {
      taken.push(stop)
      used += stop.stayMinutes
    } else {
      leftover.push(stop)
    }
  }
  return { taken, leftover }
}

function assignSlots(stops: readonly AssignedStop[]): { slot: Slot; stops: AssignedStop[] }[] {
  const buckets: Record<Slot, AssignedStop[]> = {
    morning: [],
    lunch: [],
    afternoon: [],
    dinner: [],
    evening: [],
  }
  for (const stop of stops) {
    const preferred = SLOT_PREFERENCE[stop.type]
    const slot = preferred.find(candidate => buckets[candidate].length < slotCap(candidate)) ?? preferred[0] ?? 'afternoon'
    buckets[slot].push(stop)
  }
  return SLOTS.map(slot => ({ slot, stops: buckets[slot] }))
}

function slotCap(slot: Slot): number {
  if (slot === 'lunch' || slot === 'dinner') return 1
  if (slot === 'evening') return 2
  return 3
}

function stayTotal(stops: readonly AssignedStop[]): number {
  return stops.reduce((sum, stop) => sum + stop.stayMinutes, 0)
}

function renderRoute(value: {
  driving: boolean
  days: readonly DayPlan[]
  unused: readonly AssignedStop[]
}): string {
  const transit = value.driving ? '自驾：预留停车，晚餐前避免酒类为主的安排。' : '不自驾：步行、地铁、出租/网约车优先，同区串联、减少折返。'
  const dayBlocks = value.days.map((day) => {
    const rows = day.slots.map((entry) => {
      const names = entry.stops.length === 0
        ? '（空，从邻区或 TopK 补）'
        : entry.stops.map(stop => `${stop.name}（${stop.type}，${stop.stayMinutes} 分钟）`).join(' → ')
      return `| ${SLOT_LABEL[entry.slot]} | ${names} |`
    })
    return [
      `### Day ${day.day}：${day.area}`,
      '',
      '| 时段 | 安排 |',
      '|---|---|',
      ...rows,
    ].join('\n')
  })
  const unused = value.unused.length === 0
    ? '无多余 POI。'
    : value.unused.map(stop => `- ${stop.name}（${stop.type}，${stop.area}）`).join('\n')
  return [
    transit,
    '',
    'This is a geographic skeleton. Write the user-facing answer as exactly two top-level sections: `1）完整 POI 总表` and `2）按天行程`, including TopK backups for meals, shopping, activities/experiences, shows/exhibitions, and scenes. Every scheduled POI must appear in the table.',
    '',
    ...dayBlocks,
    '',
    '### Unused (TopK backups)',
    '',
    unused,
  ].join('\n')
}
