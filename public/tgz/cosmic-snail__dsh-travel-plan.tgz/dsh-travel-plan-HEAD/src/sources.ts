import type { WebFetchResult, WebSearchResult, WebSearchSource } from '@deepseek-ai/dsh-web'

/** One citeable search hit projected for tool output. */
export interface CitedSource {
  readonly url: string
  readonly title?: string
  readonly snippet?: string
  readonly publishedAt?: string
}

const SOURCE_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    url: { type: 'string', required: true },
    title: { type: 'string' },
    snippet: { type: 'string' },
    publishedAt: { type: 'string' },
  },
} as const

/** Value-schema fragment for a list of {@link CitedSource}. */
export const citedSourcesSchema = {
  type: 'array',
  required: true,
  items: SOURCE_SCHEMA,
} as const

/**
 * Project one seam source, omitting absent optional fields.
 * @param source - a `ctx.web` search source.
 * @returns `{ url }` plus each present optional field.
 */
export function projectSource(source: WebSearchSource): CitedSource {
  return {
    url: source.url,
    ...source.title !== undefined ? { title: source.title } : {},
    ...source.snippet !== undefined ? { snippet: source.snippet } : {},
    ...source.publishedAt !== undefined ? { publishedAt: source.publishedAt } : {},
  }
}

/**
 * Project a search outcome's citeable sources.
 * @param result - a `ctx.web` search result.
 * @returns sources with absent optional fields omitted.
 */
export function projectSources(result: WebSearchResult): CitedSource[] {
  return result.sources.map(projectSource)
}

/** Display label for a source: its title, else its hostname. */
export function sourceLabel(url: string, title: string | undefined): string {
  if (title !== undefined && title.length > 0) return title
  try {
    return new URL(url).hostname
  } catch {
    return url
  }
}

/**
 * Format citeable sources as a markdown list.
 * @param sources - projected search hits.
 * @returns a markdown bullet list, or a placeholder when empty.
 */
export function formatSourceList(sources: readonly CitedSource[]): string {
  if (sources.length === 0) return 'No results found.'
  return sources.map((source) => {
    const label = sourceLabel(source.url, source.title)
    const meta: string[] = []
    if (source.snippet !== undefined && source.snippet.length > 0) meta.push(source.snippet)
    if (source.publishedAt !== undefined && source.publishedAt.length > 0) meta.push(`(${source.publishedAt})`)
    const suffix = meta.length > 0 ? ` — ${meta.join(' ')}` : ''
    return `- [${label}](${source.url})${suffix}`
  }).join('\n')
}

/**
 * Extract a capped text body from a fetch result.
 * @param result - a `ctx.web` fetch outcome.
 * @param maxChars - maximum characters to keep.
 * @returns status, final URL, truncated flag, and body text.
 */
export function extractFetchedText(result: WebFetchResult, maxChars: number): {
  url: string
  statusCode: number
  truncated: boolean
  content: string
} {
  const raw = result.body.content
  const truncated = result.truncated || raw.length > maxChars
  return {
    url: result.url,
    statusCode: result.statusCode,
    truncated,
    content: raw.length > maxChars ? raw.slice(0, maxChars) : raw,
  }
}

/**
 * Reject a blank string argument the schema DSL cannot express.
 * @param value - candidate string.
 * @param field - argument name for the error.
 * @returns the trimmed string.
 */
export function requireNonEmpty(value: string, field: string): string {
  const trimmed = value.trim()
  if (trimmed.length === 0) throw new Error(`${field} must be a non-empty string`)
  return trimmed
}
