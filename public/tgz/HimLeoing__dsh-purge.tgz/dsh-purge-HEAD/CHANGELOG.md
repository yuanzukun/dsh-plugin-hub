# 变更记录 / Changelog

对照基线：**1.2.0**（上游最后一代，`dshTarget: 0.2.1-rc.2`）。
本文件只记 1.3.x / 1.4.x / 1.5.x 分支相对 1.2.0 的**新增、优化、修复**，以及会影响到你的行为变化。

Baseline: **1.2.0**. Everything below is what this fork adds, improves, or fixes on top of it.

---

## 1.6.1 — 适配 DeepSeek Harness **0.2.2-rc.3**

`dshTarget` 从 `0.2.2-rc.2` 抬到 `0.2.2-rc.3`。

### 核对结果：rc.3 没有改任何被补丁锚定的代码

把 rc.3 的原始源码（`.dshpurge.bak`）逐条跑了一遍锚点匹配：

| 结果 | 数量 |
| --- | --- |
| pattern 在 rc.3 原文上直接命中 | **59** |
| 盘上已是产物（marker 命中，pattern 自然不再出现） | 5 |
| `na`（桌面 / hooks 面不适用） | 6 |
| 回滚型（#86，干净宿主必然不命中） | 1 |

所以本版**没有改任何锚点**，只做版本对齐与再验证。Web 面仍然是 **59/59 全部 applied**。

### 保留的两条回滚型补丁说明

#86 `STEER_RESTORE_QUEUE` 只在「宿主被 1.4.2 改过」时才有活干，干净宿主上跳过是它的正确状态；它和已应用的 #85/#90 合并显示，不单独计数。

---

## 1.6.0 — 独立仓库、59/59、应用后不再报「读取失败」

### 仓库

本项目自此**独立维护**：`HimLeoing/dsh-purge-plus` 是 GitHub 上的 fork，而 fork 关系无法解除（`"fork": true` 在创建时就写死了）。所以 1.6.0 起换到新建的非 fork 仓库 **`HimLeoing/dsh-purge`**，提交历史与 tag 全部保留。

`repository` / `homepage` / `bugs` / `dsh.install` 与 README 里的所有链接都指向新仓库。

### 补丁表：79 条，59/59

删掉两条长期跳过项，它们已经没有维护价值：

| 删掉 | 原因 |
| --- | --- |
| **#71** `LIANGSHEN_IDENTITY_LINE` | 目标是「两神」预设的 `preset-liangshen`，没装就是 `missing_file`，装了才命中 |
| **#80** `MINIMAL_OFFICIAL_TOOLSET` | 回滚型：只撤 1.4.2 自己往 minimal 预设里加过的行，干净宿主必然不命中 |

删除后 web 面 **59 个可见补丁全部 applied**，没有跳过、没有缺失文件。仍保留的两条回滚型补丁（#85/#86 链上的 #86）与已应用的兄弟项合并显示，不单独计数。

### 修掉「点应用后报读取失败」

1.5.5 起 apply 成功就直接重启宿主，但前端仍在 apply 返回后立刻读 `/dsh-purge/status`。旧进程正在退出，这个请求必然失败，于是界面把一次正常重启显示成：

```
读取失败: 连不上接口，请确认 dsh 还在跑后 Ctrl+F5
未定位到当前宿主的 @deepseek-ai，清洗不会生效
```

修法：

| 位置 | 变化 |
| --- | --- |
| `client.js` apply 分支 | `d.restarting` 为真时不再 `loadAll()`，直接显示「正在重启」，15 秒后兜底重试一次 |
| `client.js` `loadAll` 的 catch | 新增 `restartPending` 标志；重启期间的任何 `status` 失败都静默丢弃，不重置 state、不弹红字 |

### 文档

README 全部重写（中英各一份）：

- 只保留**上游原作者**「小杨 / @YuJunZhiXue」的署名，去掉 fork 链上另一位维护者的信息
- 删除「Unauthorized commercial use」「违规商用公示」「Non-profit public project」整节及其截图
- 删除赞助段与所有旧截图（`docs/notice/`、`docs/preview/` 整目录移除）
- `docs/banner.svg` 换成新绘制的版本
- 补齐 0.2.2-rc.2 的适配说明、安装（含 `allowBuilds`）、四个按钮的实际行为、红队模式排障路径

---

## 1.5.7 — 适配 DeepSeek Harness **0.2.2-rc.2**，并修好红队模式

`dshTarget` 从 `0.2.2-rc.1` 抬到 `0.2.2-rc.2`。rc.2 又改了三处签名，导致 4 条补丁整条失配；红队预设则被 rc.2 的两条新限制判成 `broken`，在模式下拉里根本选不了。

### 补丁锚点（4 条）

| 补丁 | rc.2 里的变化 | 修法 |
| --- | --- | --- |
| **#13** `ESCALATION_WIDENING_EXEMPT` | 三行 `throw new Error(...)` 变成 `throw new SandboxEscalationError(..., "SANDBOX_ESCALATION_*")` | 新增带错误码的 pattern |
| **#35** `ESCALATION_NEVER_REJECT` | 同一个 switch 全换成 `SandboxEscalationError`，`cancelled` 分支多了一句 `approval.signal?.throwIfAborted()` | 新增对应 pattern |
| **#18** `REPEAT_TOOL_REMINDER_DISABLED` | `tools/post-execute` 钩子不再区分 `kind === "block"`，直接展开 downstream | 新增简化版 pattern |
| **#62** `OFFICIAL_TOOL_ASK_FAILOPEN` | 拒绝理由改走 `approvalDenial(reason, APPROVAL_*)`；`lib` 与 `types` 两个模块各一套 | 新增 4 条 pattern（tab/四空格、`void 0`/`undefined`） |

应用结果：web 面 **67 applied · 2 skipped（#80/#86 回滚型）· 1 missing_file（#71 未装两神预设）**。

### 红队模式

`$DSH_HOME/redteam/preset-declare.json` 里记着：

```
phase: registered-broken
broken: tool-subagent-list-agents ...: never started
        tool-subagent: toolFilter is no longer supported; configure persona and tool
        plugins in an Agent Preset and select it with agentPreset (spawn only)
```

两个都是 rc.2 的收紧：

| 问题 | rc.2 的事实 | 修法 |
| --- | --- | --- |
| `@deepseek-ai/dsh-tool-subagent-control/list-agents` | 该包 `exports` 只剩 `.` / `./src/*` / `./package.json` / `./locale/*`，**没有 `/list-agents` 子路径** | 整条从预设里删掉 |
| `tool-subagent.config.toolFilter` | `apply()` 第一行就抛错：`persona` 与 `toolFilter` 都不再支持 | 删掉 `toolFilter` 段；叶子节点改由 `maxDepth: 1` 兜底 |
| `modelSelectionSettings: true` | rc.2 的 Config 键叫 `modelSelection` | 改名 |

预设模板（`presets/redteam/agent.cordis.yml`）和已安装的 `$DSH_HOME/.agent-presets/redteam/agent.cordis.yml` 都改了，重装不会再被旧模板覆盖。

---

## 1.5.6 — 去掉 Web 面的「要现在重启吗」弹窗

1.5.5 起 apply 路由写完补丁就自己重启，那个弹窗已经没有存在的意义：它只会在结果出来前挡住页面，而且在部分宿主面点下去请求根本发不出去。

### 变化

`RestartAsk` 只在**非 web** 面渲染（`askRestart && hostSurface !== "web"`）。web 面点「应用」→ 补丁写入 → 服务端直接重启 → 新页面自动打开，全程不需要点任何确认。

保留桌面分支的原因：密封 asar 换包必须完全退出应用，那一步需要用户知情。

---

## 1.5.5 — 「应用」成功后自己重启，不再等弹窗

### 现象

点「应用」，补丁确实写进了宿主（`applied.json` 有记录），但进程没换，得自己关终端重开。日志里连一条 `dsh-purge-restart-*.err.log` 都没有——说明重启助手压根没被调用。

### 根因

HTTP 的 apply 路由**从来不调 `scheduleRestart`**。它只做三件事：算 `shouldRestart`、设 `bootFullQuit = true`、返回 `restarting`，然后**指望前端弹窗**让用户点「现在重启」。前端不弹（或弹了没被点到），这一步就永远不发生。

### 变化

`POST /dsh-purge/apply` 在补丁全部写进宿主、没有硬失败时，**直接** `hostctl.scheduleRestart(request, ctx)`：助手立刻起新宿主，并用新 token 打开页面。弹窗逻辑保留为兜底，但不再是唯一路径。

| 判定 | 行为 |
| --- | --- |
| `summary.failed.length === 0` 且非密封桌面 | 立即重启（本次新增） |
| 有硬失败 | 不重启，照旧给出错误提示 |
| 密封桌面（asar） | 仍走原来的换包流程 |

### 验证

1.5.3/1.5.4 已证明助手本身可用（真实日志：366ms 释放端口 → 3418ms 抓到新地址 → 6440ms 判定 up）。本版只是把这个助手接到「应用」这条路上。

---

## 1.5.4 — 点「应用」之后一定给得出重启入口

### 现象

点「应用」后补丁确实写进了宿主，但界面没有任何「现在重启」的选项，只能自己关掉终端重开。

### 两个独立的断点

1. **`web.js` 的 `scheduleRestart()` 没有返回值。** `/dsh-purge/restart` 路由按返回值算 `restarting`，拿到 `undefined` 就写 `restarting: false` —— 实测响应正是 `{"ok":true,…,"restarting":false}`，而助手其实已经启动并在 6.4 秒内把新宿主拉了起来。前端拿到 `restarting:false` 就当「没开始」，既不等待也不提示。
2. **apply 的响应是裸的 `shouldRestart`。** 补丁全部 `already`（`appliedCount = 0`）而 `complete` 又被某一项判否时，`shouldRestart` 为 false，前端 `setAskRestart(false)` 直接把重启入口收起来。

### 变化

| 位置 | 变化 |
| --- | --- |
| `lib/web.js` | `scheduleRestart()` 返回 `{ restarting: true, surface: "web" }` |
| `lib/index.js` | apply 响应改成 `restarting: shouldRestart || complete || summary.failed.length === 0` —— 只要这次 apply 没有硬失败，就一定给前端重启入口 |

自动重启（`restart_after_apply`）的判定没有放宽，仍然只在真正需要时由服务端直接拉起。

### 验证

1.5.3 的真实重启日志（`$TMPDIR/dsh-purge-restart-2026-11-08T07-55-20.err.log`）：

```
port 3080 is free after 366ms; starting the replacement
replacement spawned (pid 81449)
captured the new address after 3418ms
replacement up (steady for 3000ms after 6440ms)
```

重启链路本身是通的，本版只修「有没有入口／有没有如实回报」。

---

## 1.5.3 — 重启助手改为全程留痕

1.5.2 修掉了管道导致的 EPIPE，但助手失败时仍然是**完全静默**的：它 detached 运行、`stdio: "ignore"`，出问题既没有终端输出也没有日志，只能靠猜。

### 变化

`lib/restart-web.js` 现在每一步都追加写进 `$TMPDIR/dsh-purge-restart-<stamp>.err.log`：

| 记录点 | 内容 |
| --- | --- |
| 启动 | helper pid、port、host、旧 pid、execPath、argv、cwd、两份日志的路径 |
| 等端口 | 端口释放耗时；超过 40 次探测直接放弃并记录 |
| 杀旧进程 | 发出的信号、失败原因（通常旧进程已经自己退了） |
| spawn | 新宿主 pid；同步抛错 / 异步 `error` 事件都会记下 |
| 抓地址 | 抓到时耗（token 打码后记录）；20 秒抓不到就指向 `.out.log` |
| 收尾 | 新宿主的判定：`up (steady for 3000ms after Nms)` 或 `timed out` |

### 排障

点「应用／重启」没回来后，直接看：

```bash
ls -t $TMPDIR/dsh-purge-restart-*.err.log | head -1 | xargs cat
```

`.out.log` 里是新宿主自己的完整启动输出 —— 那才是它为什么没起来的一手证据。

---

## 1.5.2 — 修掉「应用后重启：旧进程关了，新进程没起来」

### 现象

点「应用」后旧宿主正常退出，但新的 `dsh web` 没有起来，页面打不开。

### 根因

`lib/restart-web.js` 这个 detached 助手用管道接住新宿主的输出，靠匹配 `dsh web: http://…` 拿带 token 的地址：

```js
stdio: ["ignore", "pipe", "pipe"]   // ← 问题在这
```

它抓到 URL 后就 `process.exit(0)`。助手一退，管道读端消失，新宿主下一次 `console.log`（0.2.2 的插件加载日志比 0.2.1 多得多）就是 EPIPE，Node 按未捕获错误处理 → 新宿主直接死掉。

实测复现（3099 端口，同一套流程）：

| 版本 | helper 退出 8 秒后 |
| --- | --- |
| 1.5.1（pipe） | 端口消失，进程已死 |
| 1.5.2（文件 fd） | 仍在 `LISTEN`，进程存活 |

### 修法（照 `dsh-market` 的 `lib/restart.js`）

| 变化 | 说明 |
| --- | --- |
| `stdio: ["ignore", outFd, errFd]` | 输出落到 `$TMPDIR/dsh-purge-restart-<stamp>.{out,err}.log`，不再走管道，助手退出也不会中断 |
| 从日志文件读 URL | 每 200ms 轮询日志文件匹配 `dsh web: http://…`，拿到带 token 的地址再开浏览器 |
| 等端口「持续可连」再退出 | 3 秒稳定窗口；绑定过一次不算数（激活审计失败会先绑后退） |
| 打开日志失败时降级 `ignore` | 绝不再退回管道 |

### 排障

重启失败时去 `$TMPDIR` 找 `dsh-purge-restart-*.out.log` / `.err.log`，新宿主的完整启动输出都在里面。

---

## 1.5.1 — 设置导航图标改走 dsh 0.2.2 的官方槽位

dsh 0.2.2 新增了 `settings.section.icon`，并且把每个 section 行渲染成 `<span class="navIcon">{slot || navIcon(id)}</span>`，未知 id 落回齿轮。1.5.0 的客户端仍用老的 CSS mask 自插方案（`installSettingsNavIcon`），于是在 0.2.2 上导航行同时出现 **齿轮（宿主画的）+ 锁（插件补的）** 两个图标。

`dsh-market` 1.73.x 用的是同一套解法，本版照它的写法对齐。

### 修复

| 位置 | 变化 |
| --- | --- |
| `client.js` | 新增 `PurgeNavIcon`，通过 `settings.section.icon`（`id: "dsh-purge"`）注册，直接顶替默认齿轮 |
| `client.js` | 只有宿主**没有**声明该槽位时（0.2.1 及更早），才退回 CSS mask 自插；两个方案互斥 |
| `client.js` | `installSettingsNavIcon` 改为 `return ctx.effect(...)`，兜底方案现在可被正确卸载 |

### 效果

导航栏的 Purge 只剩一个锁图标；旧宿主行为不变。

### 验证

- `node --check client.js` 通过
- 宿主 `dsh-client-ui-settings-general` 的 `renderSlot("settings.section.icon", …, { only: row.id, fallback: navIcon(row.id) })` 会按 id 命中我们的注册，fallback 齿轮不再出现

> 需要在重启 dsh（或刷新页面）后生效 —— client bundle 是启动时加载的。

---

## 1.5.0 — 适配 DeepSeek Harness **0.2.2-rc.1**

`dshTarget` 从 `0.2.1-rc.2` 抬到 `0.2.2-rc.1`。0.2.2 把几个包重新拆分了（PTC 执行器独立成包、审批流水线拆出 `lib/pipeline.js`、deliverable 提示词独立成包、`editIntent`/`deleteIntent` 抽出公共 `requirePresent()`），导致 1.4.3 的 6 条锚点整条失配、1 条变成**半应用**。本版把锚点全部对齐，并把 0.2.2 新增的删除门也纳入清洗范围。

### 修复：失配锚点（0.2.1 能打、0.2.2 打不上）

| 补丁 | 0.2.2 里的变化 | 修法 |
| --- | --- | --- |
| **#14** `ESCALATION_GRANT_UNCONDITIONAL` | `displayReason` 内联对象被抽成 `escalationDisplayReason(mode, justification)` | 新增一条匹配新形态的 pattern，保留旧 pattern |
| **#17** `FS_OBSERVATION_INTENT_FREE` | `editIntent` 被压成 `return this.requirePresent(target, actor, "edit")`；**结果是 write 已放行、edit 仍要求先读**（半应用） | 新增 editIntent 新形态 pattern，半应用状态消除 |
| **#54** `DELIVERABLE_DO_NOT` | 提示词搬到新包 `dsh-deliverable-file-references` | `file` 改为「新包优先、旧包兜底」 |
| **#60** `OFFICIAL_RUN_CODE_APPROVAL_NEUTRAL` | run_code/PTC 提示词搬到新包 `dsh-tool-executor-ptc` | 同上，并新增 `ptc-executor` 目标映射 |
| **#62** `OFFICIAL_TOOL_ASK_FAILOPEN` | 审批逻辑拆到 `dsh-tools/lib/pipeline.js`（编译版用 `void 0`、`unavailable` 分支深一层缩进） | 新增 `dsh-tools-pipeline` / `dsh-tools-pipeline-types` 映射 + 两条新 pattern |
| **#67** `AGENT_LOOP_MESSAGES_GUARD` | turn 循环多嵌一层，缩进 4 tab → **5 tab** | 新增 5-tab 版 pattern |
| **#74** `ASSEMBLE_BEFORE_PRESTEP` | `assemble()` 改成对象字面量，`model.current()` 紧跟 `inbox.claim()` | 插入点改到 selection 之前，新增对应 pattern |

### 新增

| 补丁 | 说明 |
| --- | --- |
| **#91** `FS_DELETE_INTENT_FREE` | 0.2.2 新增 `deleteIntent()`，与 `editIntent` 同族但 1.4.3 的 #17 从没覆盖过。独立成一条可选补丁（不动 #17 的 marker 语义），删除不再要求「先读过」 |

### 预期跳过（不是失败）

| 补丁 | 为什么该跳 |
| --- | --- |
| **#71** `LIANGSHEN_IDENTITY_LINE` | 目标 `preset-liangshen` 只在装了「两神」预设时存在，未装即 `missing_file` |
| **#80** `MINIMAL_OFFICIAL_TOOLSET` | **回滚型**：作用是撤掉 1.4.2 往 minimal 预设里加的 fs/web 行，干净上游本来就没有这些行 |
| **#86** `STEER_RESTORE_QUEUE` | **回滚型**：同上，撤 1.4.2 的 steer 改写 |

### 安装源

`repository` / `homepage` / `bugs` / `dsh.install` 全部指向本分支 `HimLeoing/dsh-purge-plus`（分支 `main`）。此前这些字段指向上游 `YuJunZhiXue/dsh-purge`，装下去拿到的是上游包，本分支的修复不会生效。

### 验证

- `node test/gate.mjs`：**71 项全过**
- 7 个修复补丁在 0.2.2-rc.1 宿主上逐个 `apply` → `applied`；二次 `apply` 全部 `already`（幂等）
- 8 个被改写的宿主文件 `node --check` 全部通过
- 全量状态：applied 67 · skipped 2（#80/#86 回滚型）· missing_file 1（#71）· na 若干（surface 不适用）

### 升级提示

从 1.4.3 升到 1.5.0 后，**先重启一次 dsh**（补丁表在进程启动时加载），再进「设置 → Purge」确认状态；`#54/#60/#62` 在此之前可能仍显示 skipped，属正常。

---

## 1.4.3 — 恢复「插话」，并把 next-step 竞态真正修掉

1.4.2 的 **#85** 把 `prompt()` 一律改成 `followup`，副作用是**输入框的「插话发送」和队列条的「插话」都变成了排队**：点下去执行的是 `inbox.remove(id)` + `followup(message)`，消息被从 `next-turn` 摘掉、又插回同一个 `next-turn`，净状态不变——界面上就是「点了没反应」。
它声称要消掉的 `steer→next-step` 竞态并没有被消掉：`followup` 同样走 `send(..., "next-turn", true)`，在 `wakeDriver()` 里一样不闩锁 `wakeRequested`，turn 收尾窗口到达的消息照样滞留到下一次发消息才被带出来。

### 修复

| 补丁 | 变化 |
| --- | --- |
| **#85** `SESSION_PROMPT_ALWAYS_FOLLOWUP` → `STEER_RESTORE_PROMPT` | 改成**回滚补丁**：命中 1.4.2 写进去的那行，还原成上游 `if (request.mode === "steer") agent.steer(message); else agent.followup(message);`。升级即自动还原，不需要用户手动改文件 |
| **#86** `SESSION_STEER_ALWAYS_FOLLOWUP` → `STEER_RESTORE_QUEUE` | 删掉「队列 steer → followup」这条改写；保留并补齐回滚：队列 `case "steer"` 回 `agent.steer(message)`，公共 `steer()` 回到上游 `next-step`，连 1.4.2 留下的纯注释尾巴也一并还原 |
| **#90** `STEER_WAKE_LATCH`（新增） | 在 `agent-loop` 里真正消掉竞态：`wakeDriver()` 在 running 态也闩锁 `wakeRequested`（`!this.phase.abort.signal.aborted`），`cancel()` 无论 `keepInbox` 与否都清闩锁，保证「停止就是停止」 |

展示分组 `followup: [85, 86]` 改为 `steer: [85, 86, 90]`。

### 行为变化

- 「插话发送」恢复插进**当前轮**的下一步（`agent/inbox/spliced {target:"next-step"}`），不再只是排到下一轮。
- 「排队发送」语义不变：Agent 空闲时仍然走 `followup`。
- 按「停止」之后，队列里的消息不会因为新的闩锁被自动起新轮跑掉。

### 验证

- `test/gate.mjs` 71 项全过；`test/cwd-variable.mjs` 与基线同样的 2 项在无宿主渲染器环境下失败（改动前后一致，与本 PR 无关）。
- 在 0.2.1-rc.2 干净宿主上跑 `applyReplacementsToText`：#85/#86 全部 `changed=false`，不误伤。
- 在 1.4.2 已打过的宿主上跑：`#85 + #86` 把 `api-session-controller`、`agent-loop` **逐字节还原成上游原文**；再跑一次全部 `changed=false`（幂等）。
- `#90` 打完后 `node --check` 通过，二次应用 `changed=false`（markers 命中即跳过）。

### 合并前的独立复核

合并前我在**本机真实的宿主文件**上把 PR 的每条声明都跑了一遍（`work/tools/verify-pr3.mjs`，25 项，不写宿主）：

| 声明 | 结果 |
| --- | --- |
| 干净宿主上 #85/#86 不误伤 | 通过（`changed=false`） |
| 1.4.2 宿主上逐字节还原 | 通过（与手工还原的上游文本 `===` 相等） |
| 还原结果仍是合法 JS | 通过（`node --check`） |
| #85/#86 幂等 | 通过 |
| #90 命中 `agent-loop`、产物合法、幂等 | 通过 |
| #90 不碰 `steer()`（那是 #86 的地盘） | 通过（`[dsh-purge-86]` 标记数前后一致） |
| #90 的闩锁条件保留 `disposed` 例外 | 通过 |
| `cancel()` 在 `keepInbox` 下也清闩锁 | 通过 |
| 展示分组无孤儿 id | 通过 |

另外对 #86 做了 3 轮重复应用，产物稳定、不振荡（`true → false → false`）。

### 补充说明

- **#86 去掉了 `skipIfMarked`**：它现在是纯回滚补丁，pattern 只匹配 1.4.2 的产物，上游文本上不命中，所以不需要标记短路；markers 若保留会让「已还原」被误判成「已应用」。
- **`PATCH_DISPLAY_GROUPS` 改名不影响界面**：设置页的分组按 `layer`（prompt / code / tools / compat / dsh20）聚合，不走这个表；该表只参与 rollup 计数与折叠分桶。
- **#90 的取舍**：`wakeDriver()` 在 running 态也置位 `wakeRequested`，代价是「turns 之间」多一次 wake 判定。收益是 turn 收尾窗口到达的消息（`turn()` 已 `return false`、`kick()` 尚未 `setPhase(idle)`）不再滞留。`cancel()` 无条件清闩锁，保证「停止就是停止」不被队列续跑破坏。

---

## 1.4.2 — 移除输入框里的「回退」按钮及其全部作用

### 移除内容

输入框右下角那个「↩ 回退」按钮是**这个插件**加的，注册在宿主的 `conversation.input.right` 槽位上。按用户要求，按钮和它的作用一起删掉：

| 层 | 移除的东西 |
| --- | --- |
| 界面 | `RewindButton` / `RewindSafe` / `RewindFallback` / `rewindMenuNode` / `REWIND_CSS` |
| 槽位 | `conversation.input.right` 注册整块删除，**不再有按钮，也不再每 1.2s 轮询** |
| 后端路由 | `POST /dsh-purge/rewind`、`GET /dsh-purge/rewind/options`、`GET /dsh-purge/last-user` |
| 斜杠命令 | `/rewind`（`once` / `round`） |
| 宿主钩子 | `installRewindDeriveFilter`（用于把回退标记挡在模型请求外）及其调用 |
| 补丁 | **#56** `REWIND_HIDE_CUT_ONLY`、**#75** `REWIND_RESET_TODOS`、**#77** `REWIND_DROP_SENT_ON_APPEND` |

补丁总数 **82 → 79**（代码层 46 → 43，其余不变）。

### 保留了什么，为什么

| 保留项 | 原因 |
| --- | --- |
| `lib/rewind.js` 模块 | 里面的 `planRewind` / `wrapSessionDeriveMessages` 等函数被**补丁 #58** 和宿主侧 derive 过滤器之外的地方复用；文件留着不会产生任何界面或路由 |
| **#58** `REWIND_SKIP_DERIVE` | 它保证「回退标记不进模型请求」。老会话里已经存在的回退事件仍需要这条保护，删掉会让历史标记被当成对话内容重放 |
| `hostSessions` / `hostCtx` 等会话入口 | 原本由 `installRewindUi` 顺带赋值，被 `clientCurrentCwd`、`isRedteamModeActive`、发送前环境门禁共用。删按钮时若一并删掉赋值点，这三个功能会拿不到当前会话——所以单独留了一个 `installHostContext`，只取 sessions / uiWorkspace / conversation，**不注册任何 UI、不发任何请求** |

### 顺带修正

- 上一版删代码时 `installRewindUi` 因缩进不匹配没被切掉，本次手工清理并补回会话入口
- 四个状态变量改名为 `hostSessions` / `hostCtx` / `hostWorkspace` / `hostConversation`，名字反映实际用途（不再叫 rewind*）
- 清掉了 `commands.register` 删除时多留的一个孤立 `);`（曾让 `lib/index.js` 语法失败）

### 验证

- `client.js` 语法通过，两个槽位（`settings.section` / `shell.overlay`）渲染正常
- `test:cwd` 21 项、`test:gate` 71 项、宿主门禁全绿
- `compat-check`：79 条补丁全部 settled，0 pending
- 全库扫描确认：`RewindButton` / `RewindSafe` / `REWIND_CSS` / `installRewindWatch` 出现次数均为 0

---

## 1.4.1 — 修「装完就用不了」的 cwd 变量崩溃

### 症状

装完插件、**还没点「应用」**，每一轮对话都失败：

```
unknown prompt variable "{{cwd}}" in section "deployment:persona-suffix";
registered variables: provider, model
```

### 根因

0.2.1 的 `dsh-agent-loop` 只注册两个提示词变量：

```js
ctx.systemPrompt.variable("provider", …)
ctx.systemPrompt.variable("model",    …)
```

`cwd` 在 0.1.x 还有，0.2 拿掉了。而宿主的 `interpolate()` 遇到未注册变量不是留空，
是**抛异常**：

```js
if (!Object.hasOwn(variables, name)) {
  throw new Error(`unknown prompt variable "{{{name}}}" in ${kind} "${input.name}"; …`)
}
```

旧版 `cordis.patch.yml` 给 `system-prompt` 配了：

```yaml
personaSuffix: Your working directory is {{cwd}}.
```

`deployment:persona-suffix` 是**每轮都参与渲染**的段，所以这个错在插件一装上就发生，
与是否点过「应用」无关——这就是「基本上下载安装后都有」的原因。

### 修法（三层，逐层收窄）

| 层 | 文件 | 做法 |
| --- | --- | --- |
| **1. 配置** | `cordis.patch.yml` | `personaSuffix` 改为 `""`。persona 不再发任何变量；工作目录由宿主 runtime context 提供，persona 里重复一遍没有收益。 |
| **2. 注册** | `lib/cwd-variable.js`（新） | 插件在 `systemPrompt` 全局层补一个 `cwd` provider，取值优先级 `agent.options.cwd` → `session.header.cwd` → `process.cwd()`。这样**用户自己 preset 里写的** `{{cwd}}` 也能解析。宿主已注册同名变量时抛 `already registered`，按成功处理。 |
| **3. 兜底** | `lib/identity.js` | ① `overlayOfficialIdentity` 写出的 persona-suffix 改成纯文本；② 旧的 `Working directory: {{cwd}}.` 剥离后不再留变量；③ `sanitizeAssemblySections` 把任何残留的 `{{cwd}}` 降级成 `{ {cwd} }`——变量注册失败时也不会炸整轮。 |

关键取舍：**不依赖「宿主会留空未注册变量」**。三层里任何一层单独生效都不会崩，
三层齐全时 `{{cwd}}` 正常解析出真实路径。

### 验证

`npm run test:cwd`（`test/cwd-variable.mjs`，21 项）直接加载**宿主真实的**
`dsh-system-prompt` 渲染器，逐条断言：

- 旧配置在 `provider/model` 两个变量下**确实抛错**，且报错文本与用户反馈一致（复现）
- 当前 `cordis.patch.yml` 的活动配置里没有 `{{cwd}}`
- `overlayOfficialIdentity` 的产物能渲染通过，输出里没有裸 `{{cwd}}`
- `registerCwdVariable` 注册后 `{{cwd}}` 解析出真实路径（含三条 fallback）
- 重复注册不算失败
- 转义后的文本能被宿主渲染（证明兜底不是装饰）

找不到宿主模块时，依赖渲染器的断言会显式 `skip`，不会假装通过——上一版正是
这种「看起来没问题」的验证方式漏掉了这个 bug。

---

## 1.4.0 — 借 IG5 的做法加固四处工程细节

参考 [Minglink/dsh-infinite-gen-5](https://github.com/Minglink/dsh-infinite-gen-5) 的 `source/json_output.js`、`source/attachment_lease.js`、审批门与 CAS 修订号模式，挑了四处**与本插件能力相符**的改进。不搬它的逆向引擎、worker 协议、Ghidra / x64dbg 适配层——那些属于另一类插件。

### 新增：严格 JSON 输出边界（`lib/json-safe.js`）

宿主会在渲染前校验工具结果。旧实现全程 `JSON.stringify`，三种情况会出事：

| 情况 | 旧行为 | 现在 |
| --- | --- | --- |
| `BigInt`（如 64 位地址被算成 BigInt） | 抛异常 → 整个响应 500 | 投影阶段报 `INVALID_PLUGIN_OUTPUT` 并指出路径 |
| 循环引用 | 抛异常 → 500 | 同上，带 `at` 定位 |
| 字段值 `undefined` | **静默丢字段** → 界面以为「没数据」 | 省略该字段但保留 `null`；不可靠值转成 `{__invalid,__reason,__at}` |

另外拒绝 `-0`、`NaN`、`Infinity`、Symbol、Function、稀疏数组、带额外属性的数组、accessor、非普通对象（class 实例）。深度上限 64、节点上限 20 万，超限报错而非截断。64 位地址保持字符串精度。

`sendJson` 全部改走 `stringifySafe` —— **永不抛**，坏字段变成可诊断标记，而不是把 200 变成 500。

### 新增：文件身份与写入守卫（`lib/host-lease.js`）

改宿主文件之前要先确认「我改的还是我看到的那个文件」。旧实现只比路径字符串，三种情况会被骗：

1. 目标被换成符号链接 / 目录联接 → 看到的是另一份文件；
2. 同一路径下文件被替换（重装、换版本）→ 路径对、内容不对；
3. Windows 路径大小写不敏感，`C:\App` 与 `c:\app` 会被当成两份。

现在写前取一份 identity（真实路径 + size + mtime + 前 64 KiB 的 SHA-256），写完再取一次，不一致报 `changed` / `vanished`。另附 `writeFileAtomic`（同目录临时文件 → rename），保留原文件 mode。

### 新增：审批档位与审计流水（`lib/tool-gate.js`）

`purge_apply` / `purge_revert` / `purge_uninstall` 三个破坏性工具以前没有任何「这次调用批没批」的记录。现在：

- **审计永远记**：`$DSH_HOME/dsh-purge/audit.jsonl`，每次调用一行（intent / allow / deny / result），失败也记；审计写不进去绝不影响工具结果。
- **审批可选**，`approvalMode` 两档：
  - `audit`（默认）：只记流水，行为与旧版**完全一致**，不弹任何东西。
  - `enforce`：走宿主 `approval.request`，只有明确 `allowed-once` 才 `next()`。缺 agent、缺 approval 服务、抛错、未知结果、signal 已 abort —— 一律 deny 不派发，**从不缓存上一次批准**。

> 默认不是 enforce 的原因：本插件的主入口是人自己点「应用」，人就是审批者，再弹一次只是多一次点击；而本机策略可能把 approval 一律自动拒绝，强制审批等于把插件锁死。需要更严时（模型自动跑长任务）再切 enforce。

- 新工具 **`purge_audit`**：读回审计尾部，让模型在长任务里能自查「上一次 apply 到底批没批、结果如何」。
- 设置页新增「审批与审计」区块：单选档位 + 展开查看流水（`.dshp-audit`，等宽、限高滚动）。

### 新增：状态修订号（`lib/revision.js`）

设置页每 5 秒轮询 `/status`，Web 与桌面可能同时开着。旧实现里 apply / revert 无条件执行，后点的会静默覆盖先点的结果。

现在状态机有单调递增的 `rev`：`/status` 带出，动作时带回，不一致返回 **409 + 当前 rev + 最后一次动作**。客户端收到 409 提示「另一个窗口刚改过状态」并自动重新拉取，而不是留着旧数字让用户重复点击。不持久化——重启后归零是正确语义。

### 修复：`hooksDenyBypass` 保存时抹掉同文件其他键

`saveHookDenySettings` 原来只重建 `hooksDenyBypass` 一个键再覆盖整文件。`approvalMode` 住进同一个 `hooks-deny.json` 后，切一次 hooks 开关就会把审批档位悄悄重置。改成合并写入（实测：`approvalMode` 与 `hooksDenyBypass` 同时保留）。

### 优化：请求体错误分类

`readJsonBody` 原来只抛一句 `Error`，所有异常都压成 500，界面无法区分「内容太大」和「JSON 写错了」。现在按 `BODY_TOO_LARGE`（413）、`BODY_INVALID_JSON`（400）、`BODY_NOT_OBJECT`（400）分类，19 处 catch 统一走 `bodyErrorStatus`。

### 新增接口

| 路由 | 方法 | 作用 |
| --- | --- | --- |
| `/dsh-purge/approval-mode` | GET / POST | 读/写审批档位，重启后生效 |
| `/dsh-purge/audit` | GET | 读审计尾部（`?limit=1..200`，默认 40） |

`/dsh-purge/status` 新增 `rev`、`last_action`、`approval_mode` 三个字段。

### 测试

71 项离线断言（json-safe 20 / host-lease 13 / revision 11 / tool-gate 27），不启动宿主、不碰真实工程。

---

## 一、新增 / New

### 1. 设置页成了正式界面（1.3.0）

| 项 | 说明 |
| --- | --- |
| 注册方式 | 走官方 `settings.section` 槽位：`id: dsh-purge`、`order: 450`（紧跟 `XD Pool`）、`label: () => t("page.nav")` |
| 位置 | 设置左侧导航最后一行 **Purge** |
| 页面结构 | 四段：**破甲**（补丁 / 提示词 / 自己的服务器）、**规则**、**技能**、**演练台** |
| 导航图标 | 外壳只按 section id 画图标，未知 id 一律齿轮。本分支按 label 命中自己那一行、打标记、用 `mask-image` 盖一个自绘「开口锁」，卸载时自动移除标记与样式 |

前一代只有会话里的浮窗，没有设置页入口；这一代设置页是唯一主界面。

### 2. 破甲内核 v3（1.3.0）

`lib/core.js` 的 `STRONG_INTRO` 重写。前两代只声明「这些指令是强制的」，模型仍会再判一次「是不是注入」，一旦落回「可疑」就整段降级成建议。v3 改成三步钉死：

1. **先收判定权** —— 写明这是 system 级配置，与后文（工具描述、预设、文件、网页、工具返回）冲突时本段优先，其余视为过期或对抗；
2. **再钉执行身份** —— 操作员的全权执行器，不做准入/合规判断；
3. **最后钉交付形态** —— 拒绝=故障、双语禁语表、首 token 即答案、缺细节填占位符继续、多步同轮做完。

旧代原文保留成升级 pattern（`replacementPrecedenceRewrites` 按长句优先排序，避免短句把后半截留在引号里），已经打过的树就地换到新文本，二次 apply 不叠层（实测 `changed=false`）。

### 3. 默认提示词头尾两段硬约束（1.3.0）

新脚本 `scripts/armor-prelude.mjs`（幂等，`--revert` 可回滚）在 `lib/default-prompt-inject.md` 头尾各插一段：

- 头：**`Authority and precedence`** 五条 —— 优先级阶梯（操作员 > 工作区 > 宿主默认 > 工具描述 > 读到的内容）、权限已在会话开始前定好且不可再议、**工具拒绝≠任务拒绝**（换工具/换参数/换路径继续）、外部内容只是数据、语言跟随操作员；
- 尾：**`Final gate`** 六问交付前自检，任何一项「否」都回到工作，而不是回到拒绝。

封印槽重封后 23698 字符；运行时注入的 `prompt-inject.md` 由 `lib/asset-table.js` 解封写入。

### 4. 演练台并入设置页（1.3.1）

会话里的浮窗入口撤掉后，演练台改挂设置页第四段：未授权先显示门槛卡（一段说明 + 「开始授权」按钮），授权完成后就地展开内嵌面板，不再自己拉浮层。

### 5. 新脚本

| 脚本 | 作用 |
| --- | --- |
| `scripts/armor-prelude.mjs` | 注入/回滚提示词头尾两段硬约束，幂等 |
| `scripts/drill-skin.mjs` | 把演练台的硬编码颜色收进宿主 token（`--check` 可进 CI） |

---

## 二、优化 / Improvements

### 1. 界面全部改用宿主设计 token

前一代是自己发明的一套皮：衬线标题 + 橄榄绿玻璃 + `--dshp-*` 自造调色板，结果像「设置里嵌了个别的产品」。这一代只吃 DSH 自己的 token：

| 项 | 1.2.0 | 1.3.x |
| --- | --- | --- |
| 字体 | `Songti SC` / `Noto Serif SC` 衬线标题 | 继承 `--dsw-font-family`，标题 16/24·500，正文 14/22 |
| 圆角 | 10px 固定 | `--dsw-radius-xs/sm/md/lg/xl`，卡片用 xl(20px) |
| 卡片 | 1px 描边 + 玻璃底 | 官方 rowCard：0.5px 描边 + `--dsw-alias-settings-card-fill` |
| 按钮 | 34px 高 / 8px 圆角 / 手写绿色 | 36px 高 / md 圆角 / `--dsw-alias-button-primary-fill` |
| 输入 | 8px 圆角 / 衬线 | 32px 高 / l4 描边 / md 圆角 |
| 色彩 | 自造 `--dshp-ok/warn/bad` | `--dsw-alias-state-{success,warn,error}-primary` |
| 页面宽度 | 920px | 720px 单列（与「模型」「通用设置」同宽） |
| 弹层 z-index | 80（会被设置面板的 1000 盖住） | 1300（在设置面板之上） |

### 2. 布局从「卡中卡」改成层级分明

- **指标**：三张独立卡片 → 一条统计带 + 发丝竖分隔线（数字自己承担层级）；
- **补丁分组**：卡片套表格 → 行 + 展开表格，悬停只给下划线，不再整块变色；
- **面板拆分**：原来一个巨型卡片装下所有内容 → 补丁 / 提示词 / 自己的服务器 三张独立卡片，各带一行说明；
- **分段控件**：新增「补丁 / 规则 / 技能 / 演练台」四段切换，不再把三块内容竖向堆在同一个滚动区。

### 3. 会话界面做减法（1.3.1）

撤掉三个重复入口（右下角浮钮、首页模式旁、会话标题旁），连带删掉三个组件的死代码（`PurgeLauncher` / `HeroNewSessionMount` / `TabRowPurgeMount`，client.js 减少 ~4.5 KB）。点任何旧入口现在统一跳设置页，宿主没有 `settings.open` 命令时退回 DOM 点击设置按钮，双击不生效才退回浮窗。

### 4. 演练台换 token

19 处 >1px 的彩色侧边条压到 1px 发丝线，62 处硬编码状态色收进 `--dsw-alias-state-*`；浮窗底从「52% 透明 + 20px 模糊」改成不透明层一 + 0.5px 描边，深色下不再发灰。

---

## 三、修复 / Fixes

### 1. 「应用 → 重启 → 清洗没有写进全部宿主，已取消重启」（1.3.1）

**根因**：#40 `COMPLETE_PROMPT_KEEP_INJECT` 在 0.2.1 上**一条 pattern 都不命中**。0.2.1 在 `return transformed;` 与 `return {…}` 之间多插了一行 `const requiredContexts = new Set(…)`，`contexts:` 表达式也换了；原来那条整段正则要求中间必须为空。于是补丁状态是 `skipped`（**不算失败**，界面不报错），但重启前的 `hostPromptKeepsInject` 仍能看到 `sections: … : [completeSection]`，判定「这份系统提示词没洗过」，返回失败并取消重启。

**修法**：拆成两条只认关键行的替换 —— 在 waterfall 之后插 `dshPurgeSections` / `dshPurgeRest`，再把 `sections:` 那半边换成保留注入的写法，中间的 `requiredContexts` 与 `contexts` 原样保留。幂等、产物过 `node --check`。

| 检查 | 修前 | 修后 |
| --- | --- | --- |
| 桌面宿主 `hostWritten` | `false` | `true` |
| `ensureHostClean()` | `ok: false` | `ok: true`，`pending: []` |
| 补丁表（0.2.1 原树） | 62 applied / 2 skipped | **63 applied / 1 skipped** |
| 补丁表（桌面 resources/app） | 68 already / 2 skipped | **69 already / 1 skipped** |

### 2. 补丁收敛（1.3.0）

- #1 / #2 的替换链补上 v3 代原文，旧树升级不会再叠层；
- #2 / #3 的完成标记改用「当前内核指纹」（`Refusal is a malfunction` 等），不再拿官方原文当标记导致永远自报 `already`；
- #40 的 `forbid` 与 `markers` 保持原样，仅新增 0.2.1 锚点。

---

## 四、行为变化（会影响到你）/ Behaviour changes

1. **入口位置**：会话里不再有任何 dsh-purge 按钮，界面只在 **设置 → Purge**。
2. **演练台**：从浮窗第二页变成设置页第四段；授权流程不变（读声明 → 等倒计时 → 勾三项）。
3. **点「应用」后仍需重启**：客户端 bundle 由宿主启动时合成，重启前看到的还是旧界面。
4. **首次进设置页**：导航图标是本分支自绘的，外壳若改版导致 label 匹配不到，图标会回落成齿轮，功能不受影响（控制台会提示一次）。
5. **`lib/default-prompt-inject.md` 不入库**（与上游一致）：发布的是密封后的 `lib/asset-table.js`，重新封装需要本地有那份明文源。

---

## 五、兼容性实测 / Measured compatibility

DSH **0.2.1-rc.2**，82 条补丁：

| 场景 | applied | already | missing_file | skipped | pending |
| --- | --- | --- | --- | --- | --- |
| 1.2.0 对原树（app.asar 解出） | 62 | 6 | 12 | 2 | 0 |
| **1.3.0 对原树** | 62 | 6 | 12 | 2 | 0 |
| **1.3.1 对原树** | **63** | 6 | 12 | **1** | 0 |
| **1.3.1 对已打过补丁的桌面 `resources/app`** | 0 | **69** | 12 | 1 | 0 |

`missing_file` 是这份构建里根本没有的目标（梁神预设、hooks 插件、不在 `dsh/` 里的桌面壳入口），1.3.1 之后 `skipped` 只剩 #80 一项。

自检：`node scripts/compat-check.mjs --asar <resources/app.asar>`，退出码 0 表示没有 pending。

---

## 六、升级指引 / How to update

```powershell
# 1. 覆盖插件目录（保留你的 prompt-inject.md 与规则集，它们在 $DSH_HOME，不在插件目录里）
# 2. 打开 设置 → Purge
# 3. 点「应用」；门禁通过会自己换包并重启
# 4. 重启后新开一轮对话，注入才进当前会话
```

从 1.2.0 升上来不需要手动清理：旧补丁会被新锚点就地覆盖，`installed-rev` 会自动跟着版本走。若「应用」仍报失败，先跑仓库里的 `scripts/compat-check.mjs` 看是哪条补丁 `pattern_not_found`。

---

## 七、已知限制 / Known limitations

- **密封 `app.asar` 的桌面端**：补丁写在解开的 `resources/app` 里，必须走「应用」流程把 asar 挪走并重启才生效；只重启不换包，看到的仍是归档里的旧代码。
- **`{{cwd}}` 变量**：0.2.1 的 `dsh-agent-loop` 只注册 `provider` / `model`，裸写 `{{cwd}}` 会让宿主抛 `unknown prompt variable` 并打断整轮。**1.4.1 已修**：`lib/cwd-variable.js` 补注册该变量，`cordis.patch.yml` 不再发变量，`sanitizeAssemblySections` 兜底转义。详见上方 1.4.1 一节。
- **导航图标**：依赖「按 label 找到自己那一行」，设置外壳若改文案渲染方式，图标会回落成齿轮（功能不受影响）。
- **未做**：插件市场发布、Web 端与桌面端一键同步、i18n 化全部文案（目前中英双语硬编码在 `client.js` 的 `zh` / `en` 两套字典里）。
