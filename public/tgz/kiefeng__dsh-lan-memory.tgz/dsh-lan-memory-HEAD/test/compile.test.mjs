import { test } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { Store } from '../lib/store.js'
import { createCompiler } from '../lib/compile.js'
import { makeTmp } from './_tmp.mjs'

function makeStore(t) {
  const dir = makeTmp(t, 'compile-')
  const store = new Store({ dataDir: dir, logger: { log() {}, warn() {}, error() {} } })
  store.init()
  store.appendJournal({ id: 'j1', ts: Date.now(), session: 's1', turn: 1, user: '我喜欢深潜，回答尽量直接。', assistant: '记下了。', tools: [] })
  store.appendJournal({ id: 'j2', ts: Date.now(), session: 's1', turn: 2, user: '以后先给结论，不要铺垫。', assistant: '好。', tools: [] })
  return { dir, store }
}

function fakeLlm(respond) {
  return {
    listProviders() { return [{ id: 'fake' }] },
    async listModels() { return [{ id: 'fake-model' }] },
    async *stream(options) {
      const prompt = options.messages[0].content[0].text
      const text = respond(prompt)
      yield { type: 'text-delta', text }
      yield { type: 'finish', reason: { kind: 'stop' } }
    },
  }
}

test('自动编译：抽取事实 → 写 facts/画像 → 标记 compiled', async (t) => {
  const { dir, store } = makeStore(t)
  const llm = fakeLlm((prompt) => {
    if (prompt.includes('摘要器')) return '用户喜欢深潜，偏好先给结论。'
    if (prompt.includes('抽取器')) {
      return JSON.stringify([
        { fact: '用户喜欢深潜', tags: ['兴趣', '深潜'], time: null },
        { fact: '用户偏好先给结论', tags: ['偏好', '沟通'], time: null },
      ])
    }
    return JSON.stringify({
      facts: '用户喜欢深潜；偏好先给结论，不铺垫。',
      today: '上午聊了记忆系统的自动整理。',
      week: '本周在迭代本地记忆插件。',
      longterm: '用户偏好直接、可修改的本地工具。',
      experience: [{ category: '记忆系统', content: '合并事实前先预览，保留长条并写墓碑。' }],
    })
  })
  const compiler = createCompiler({ store, llm, logger: { log() {}, warn() {}, error() {} } })
  const result = await compiler.run({ force: true })
  assert.equal(result.ok, true)
  assert.equal(result.factsAdded, 2)
  assert.equal(store.facts.length, 2)
  assert.equal(store.experienceCandidates.filter((c) => c.status === 'pending').length, 1)
  assert.match(store.experienceCandidates[0].content, /合并事实/)
  assert.ok(Object.keys(store.summaries || {}).length >= 1)
  assert.equal(store.pendingJournal().length, 0)
  assert.ok(existsSync(join(dir, 'memory.md')))
  assert.ok(readFileSync(join(dir, 'memory.md'), 'utf8').includes('## 重要事实'))
  assert.ok(store.memoryProfile.includes('用户喜欢深潜'))
  assert.equal(store.meta.compile.state, 'ok')

  // 再跑一次没有新线索：只重编译画像，不重复写事实
  const again = await compiler.run({ force: true })
  assert.equal(again.ok, true)
  assert.equal(again.compiled, 0)
  assert.equal(store.facts.length, 2)
})

test('待编译不足阈值时预约空闲编译，而不是永远跳过', async (t) => {
  const { store } = makeStore(t)
  const llm = fakeLlm(() => '[]')
  const compiler = createCompiler({ store, llm, logger: { log() {}, warn() {}, error() {} } })
  const result = await compiler.run()
  assert.equal(result.ok, true)
  assert.equal(result.skipped, 'below threshold')
  assert.equal(result.pending, 2)
  assert.ok(result.rescheduledMs > 0)
})

test('经验候选可交给模型合并，重复候选被收敛', async (t) => {
  const { store } = makeStore(t)
  store.addExperienceCandidates([
    { category: '逐项验证', content: '一次性加多项改动容易白屏，回滚后要逐项验证。' },
    { category: '稳定性验证', content: '功能改动逐项验证；白屏先查浏览器旧缓存。' },
    { category: '笔记备份', content: '笔记系统要保留第二份备份。' },
  ])
  const llm = fakeLlm((prompt) => {
    if (prompt.includes('经验整理器')) {
      return JSON.stringify([
        { category: '逐项验证', content: '功能改动逐项验证；白屏先查浏览器旧缓存，回滚后再定位。' },
        { category: '笔记备份', content: '笔记系统要保留第二份备份。' },
      ])
    }
    return '[]'
  })
  const compiler = createCompiler({ store, llm, logger: { log() {}, warn() {}, error() {} } })
  const result = await compiler.consolidateExperience()
  assert.equal(result.ok, true)
  assert.equal(result.before, 3)
  assert.equal(result.after, 2)
  assert.equal(store.experienceCandidates.filter((c) => c.status === 'pending').length, 2)
})

test('编译失败：不标记线索、保留待编译、记录错误', async (t) => {
  const dir = makeTmp(t, 'compile-fail-')
  const store = new Store({ dataDir: dir, logger: { log() {}, warn() {}, error() {} } })
  store.init()
  store.appendJournal({ id: 'j1', ts: Date.now(), session: 's1', turn: 1, user: '继续', assistant: '好。', tools: [] })
  const llm = {
    listProviders() { return [{ id: 'fake' }] },
    async listModels() { return [{ id: 'fake-model' }] },
    async *stream() { throw new Error('network down') },
  }
  const compiler = createCompiler({ store, llm, logger: { log() {}, warn() {}, error() {} } })
  const result = await compiler.run({ force: true })
  assert.equal(result.ok, false)
  assert.match(result.error, /network down/)
  assert.equal(store.pendingJournal().length, 1)
  assert.equal(store.facts.length, 0)
  assert.match(store.meta.compile.lastError, /network down/)
})

test('模型不返回 JSON 时用本地摘要兜底，不丢线索', async (t) => {
  const { store } = makeStore(t)
  store.writeCompiled({ facts: '旧事实', today: '旧今天', week: '旧本周', longterm: '旧长期' })
  const llm = fakeLlm(() => '抱歉，我无法按 JSON 输出。')
  const compiler = createCompiler({ store, llm, logger: { log() {}, warn() {}, error() {} } })
  const result = await compiler.run({ force: true })
  assert.equal(result.ok, true)
  assert.equal(result.fallback, true)
  assert.ok(result.factsAdded >= 1)
  assert.equal(store.pendingJournal().length, 0)
  assert.ok(store.memoryProfile.includes('深潜'))
  assert.equal(store.compiled.today, '旧今天', '兜底不应把原始提问写进 today')
  assert.equal(store.compiled.week, '旧本周')
})

test('memory.md 可手动编辑，下一次编译作为当前画像输入', (t) => {
  const { store } = makeStore(t)
  store.writeCompiled({ facts: '旧事实', today: '旧今天', week: '旧本周', longterm: '旧长期' })
  store.saveMemoryProfile('## 重要事实\n\n手改后的事实\n\n## 今天\n\n（暂无）\n\n## 本周\n\n（暂无）\n\n## 长期\n\n（暂无）')
  assert.equal(store.compiled.facts, '手改后的事实')
  assert.ok(store.readMemoryProfile().includes('手改后的事实'))
})

test('跨天时把旧 today 沉淀进 week 并清空 today', (t) => {
  const { store } = makeStore(t)
  const compiler = createCompiler({ store, llm: fakeLlm(() => '[]'), logger: { log() {}, warn() {}, error() {} } })
  store.writeCompiled({ facts: '事实', today: '昨天做的事', week: '（暂无）', longterm: '长期' })
  store.saveMeta({ compile: { lastLogicalDate: '2000-01-01' } })
  assert.equal(compiler.rollDaily(), true)
  assert.equal(store.compiled.today, '（暂无）')
  assert.ok(store.compiled.week.includes('昨天做的事'))
  assert.ok(store.compiled.week.includes('2000-01-01'))
})
