# Accounts, web search, and retry

Task-specific reference moved from the former root `AGENTS.md`. All source and test paths are relative to the repository root. Consult the relevant source and tests before changing behavior.

- **账号开通与恢复**：`accountEnrollmentTasks` 在写凭据前登记引用和阶段；`pending`（未完成）与 `cleanup`（清理中）账号不进入轮转池，`naming`（已登录待命名）保留可用账号。分配引用同时排除默认账号、已有账号、恢复日志、清理队列以及凭据服务中已占用的引用。宿主设置写入读取最新版本并按字段修改，避免丢失组合配置的密钥。
- **取消补偿**：已开始写入不能撤销，`cancelAndDrain()` 等实际存储结束，再原子登记账号移除和 `credentialCleanupRefs`，最后清理凭据。清理失败仅保留日志，不自动重试；无法确认事实时也不移除日志。恢复中的命名失败保留账号，允许重试或接受已有名称。见[《决策记录》第四章](../决策记录.md#四账号开通过程)及[领域词汇](../../GLOSSARY.md)。

- **请求账号作用域**：宿主从同一次配置读取取得连接与账号定义，`pool.scope()` 固定本次列表、固定账号和模型规则，并把探测绑定原连接。账号健康与显式探测节流按网关及密钥隔离，同网关共享密钥仍共享标记；引用凭据每次选择重新解析，直接填写的密钥随定义固定。用量、模型套餐筛选和网页搜索同样显式传递捕获网关，展示与请求共用恢复规则。见[《决策记录》第三章](../决策记录.md#三网关状态隔离)。

- **API key resolution order** (in `src/index.ts`) 共三层：`config.apiKey`（直接填写的密钥，含
  `Config.accounts[].apiKey`）→ 凭据引用 `apiKeyEnv`（默认 `COMMANDCODE_API_KEY`，经 dsh 凭据服务
  （credentials seam）解析，启动环境已并入这一层、不再是独立一层）→ 官方 CLI 授权文件
  `~/.commandcode/auth.json`（仅默认账号兜底）。**pi/OMP auth files are intentionally NOT scanned** — keep it that way.
  **alpha.3 起凭据服务内部的层序（layer order）反转为「托管存储（stored credential）→ 继承环境 →
  项目 `.env` → `$DSH_HOME/.env`」**（alpha.2 相反，继承的进程环境优先于
  `$DSH_HOME/.credentials.yaml`）：存放于托管存储的 key 现在优先于环境变量，且 `describe()` 恒返回
  `writable: true`，写入不再因环境变量遮蔽而被拒。**headless（无头）profile 有意不挂载
  `credentials`、`authorization`、`deepseek-account` 三行**，插件因此回落到启动环境快照
  （process → 项目 `.env` → `$DSH_HOME/.env`）：只存在于托管存储里的 key 不会到达 headless（无头）
  一次性任务。设置页侧的同一事实见 [client and settings](client-and-settings.md)。
- **Multi-account rotation** (`src/accounts.ts` + the adapter's connect loop): the top-level key forms the
  `default` slot; `Config.accounts` (`[{ label, apiKeyEnv | apiKey }]`) adds more, in rotation order.
  Rotation is **passive** on the request path: a key is marked only on a real pre-stream rejection (429 → `unknown`/`cooldown`
  carrying a `window` or `throttle` cause, 401 → `disabled`), and the adapter's `rotateApiKey` hook re-sends
  the same request with the next account's key (safe: nothing streamed, the body is account-independent,
  `threadId` preserves a valid UUID session identity, deterministically maps prefixed DSH session IDs to
  UUIDv5, and uses a random fallback only when no session ID is supplied — mid-stream failures NEVER
  rotate). **The usage report is the one other writer** (issue #105): `usageReports()` fetches every
  account's report first, feeds each `report.credits` window pair through `windowVerdict()` (the SAME
  verdict `probeWindowLimits()` returns) into `pool.noteWindowReport()`, and only then computes the active
  badge — so a card showing a spent weekly window can no longer sit beside a "current" badge, and auto
  selection skips the account with no wasted request after a restart dropped the in-memory marks. It stamps
  exactly like a probe (`cooldown` to a trusted reset, else `unknown`/`window`), never touches a `disabled`
  key, and NEVER clears a mark: an open window says nothing about a throttle or spend cap (issue #54), so
  clearing stays on the throttled probe paths. When every account is marked, the pool probes `/alpha/billing/credits` per key
  (`probeWindowLimits`, which reads BOTH windows the endpoint publishes — the five-hour and the weekly one)
  to revive reset windows, else throws `RATE_LIMIT` naming the earliest `resetAt` (all-401 →
  `INVALID_CREDENTIAL`). State is keyed by gateway and API key, not slot — same-gateway shared credentials share one mark. **Manual
  selection**: `Config.activeAccount` (a slot id) pins the serving account via the pool's `preferredId` seam
  + `selectActiveAccount()` (shared with the usage view's active badge); a pinned-but-exhausted or unknown
  id falls back to rotation order. **Model routing**: `Config.modelAccountRules` (`[{ models: string[],
  account }]`) lists catalog model ids per account slot; the request's model reaches key resolution
  (`resolveApiKey(connection, model)`), the pool's `modelAccountRules` seam uses the call's captured rules,
  and `matchModelRule()`/`selectAccountForModel()` serve the routed account before preferred/rotation — an
  unusable routed account falls back, so the router is a hint, never a hard gate. **A fallback is never
  permanent, and that is a separate mechanism from the all-marked pass** (issue #51): a 429 marks the key
  `unknown`, which `accountUsable()` refuses until a probe clears it, while the all-marked probe pass runs
  only once NOTHING can serve — so a single 429 against the account the user explicitly chose demoted every
  later request to `default` for the lifetime of the process, and re-selecting that account in settings
  could not help, because the mark lives on the resolved key rather than on the selection (only a restart
  dropped the in-memory state, which is the "重启 dsh 才能换回来" in the report). `resolveKey()` therefore
  re-checks the explicit account — the manual pin, or a rule's routed slot — before serving the fallback:
  its window is probed at most once per `EXPLICIT_ACCOUNT_PROBE_INTERVAL_MS` (60 s, which bounds a probe
  endpoint that keeps failing — the throttle's stamp SURVIVES a revival, because a probe that clears a
  window the chat endpoint still rejects would otherwise buy a second probe on the very next request: one
  billing GET plus one doomed upstream attempt each time), a window that is no longer exceeded drops the
  mark and puts the user's own choice back on that very request, and an exceeded one is stamped as a
  `cooldown` carrying the provider's own `resetAt`, after which the account returns by the clock with no
  further probe. Three gates keep the steady state free: only an `unknown` mark is probed (a `cooldown`
  already expires by itself, and a `disabled`/401 key clears only when the stored credential changes), every
  key this request already used is out of play (the rotation hook resolves with `tried`, and the pool's
  probe pass skips them too), and an account nobody explicitly asked for is still never probed while another
  one can serve. The probe's second effect is visible in the usage card: a pinned 429 now shows a real
  cooldown end instead of an open-ended "rate limited". **A rejection the pool cannot act on must not trap
  the turn either** (issue #51's follow-up report: 《切到一个不可用账号后就报 400，还挺频繁》). Three verified gaps produced
  it. Only 429/401 rotated, while the provider's account-scoped rejections are wider — the official CLI's
  own classifier (command-code@1.56.0: `parseWindowLimitError`, `isInsufficientCreditsRequestError`,
  `parseSpendCapError` and the terminal-marker list `["premium_credits_exhausted", "model_not_in_plan",
  "insufficient credits"]`) accepts the code `RATE_LIMITED` on ANY status (a 5xx that proxies the provider's
  own limit body included — the classifier reads the code BEFORE its status guard, and only a code-less
  5xx/408 keeps the retry cadence for every account), `400 Insufficient credits`, the codes
  `INSUFFICIENT_CREDITS`, `USAGE_EXCEEDED`, `PREMIUM_CREDITS_EXHAUSTED` and `MODEL_NOT_IN_PLAN` (underscored
  and spaced spellings both count, and a code-only body is enough), all of which the adapter reported as a
  permanent `PROVIDER_HTTP_ERROR`. Those four structured codes are matched on EVERY status
  (`ACCOUNT_UNAVAILABLE_CODES`), exactly like `RATE_LIMITED`: only the PROSE scan is confined to 4xx, so a
  5xx that proxies a credits/plan body rotates past the account instead of being retried as `SERVER`.
  Rotating could not have saved them anyway: the pool was asked to exclude only the just-rejected key and
  answered with the first *usable* account — the same key whenever the rejection marked nothing — so the
  adapter's tried guard ended the loop and the accounts behind it were never reached. And the revival probe
  read only `windowLimits.fiveHour`, so an account whose WEEKLY quota was spent while its five-hour window
  was open came back on every all-marked pass. `classifyAccountRejection()` therefore applies the CLI's
  rules and yields exactly four reasons, split by EVIDENCE — what the pool may claim — rather than by what
  it does: `rate-limit` (a usage window the provider NAMED: a 429 or the code, marked as a cooldown when the
  body's `error.rateLimit.reset`, in seconds, or its `resets at <ISO>` wording names the real reset — and
  only while that instant lies within `MAX_TRUSTED_RESET_MS` (30 days), because a bogus magnitude would
  otherwise pin a `cooldown` no probe ever revisits AND throw `RangeError` out of the `toISOString()` in the
  diagnosis; a dropped reset degrades the mark to `unknown`, which the probe pass re-checks — else as an
  `unknown` mark whose window the next all-marked pass probes) and `throttled` (a 429 or bare `RATE_LIMITED`
  that named NO window — `readWindowLimitEvidence()` mirrors the CLI's
  `parseWindowLimitError`/`resolveWindowLabel`, which calls a rejection a window limit only for
  `error.rateLimit.window ∈ fiveHour|weekly|daily` or the "usage limit for your plan" wording). Both rotate
  and both mark the key; only a `window` mark lets `allAccountsUnusable()` report "all N account(s) have
  exhausted their usage window" (naming the earliest reset, or saying the provider published none), while a
  pool marked only by throttles answers "all N account(s) are rate limited (429) — the provider did not
  report an exhausted usage window; retrying" with no window claim and no invented wait. That split is issue
  #54: a bare 429 marked the key, the billing probe never confirmed a spent window, and the pool told the
  reporter its window was exhausted while the account card showed 5-hour 2% and weekly 10%. `markRejected()`
  ignores a reset on a throttle mark on purpose, keeping it `unknown` so a probe can still discover a real
  window limit behind it (and upgrade the mark's `cause` to `window` when it does). `invalid-credential`
  (401, marked) and `unavailable` (no credits, or a model outside this account's plan) complete the four.
  `unavailable` never becomes an ACCOUNT mark: the fact is about the model or the balance rather than the
  key, either can change without the key changing, and a `:free` model is still served by a credits-empty
  account. It DOES become a model-scoped, five-minute PREFERENCE demotion (`markModelUnavailable()` →
  `modelUnavailable`, keyed `key\0model`): the same model skips that account, every other model and every
  `:free` model keep serving it, a pool whose every candidate carries the mark falls back to the full
  candidate list instead of reporting exhaustion, and a 401 clears that key's marks. Without it every later
  request re-hit the same `400 insufficient credits` first — one wasted round trip per step and, when that
  account was the fallback, an error naming an account the user never chose (issue #51's remaining half,
  live-probed 2026-10-21: a $0.0874 balance rejected every paid model while `stealth/glyph-cluster:free`
  still answered 200). The whole `tried` set rides the hook so one request can walk a four-account pool, and a
  pool that cannot serve answers with its own all-exhausted diagnosis (earliest reset + the retry wait)
  rather than the last raw rejection — but only when every account it could consider is MARKED. An account
  that was tried and left UNMARKED always wins instead: `resolveKey()` returns undefined so the caller's own
  rejection is surfaced as itself — in the all-tried branch AND in the branch that merely ran out of untried
  accounts — because calling a credits rejection 'all windows exhausted' would be a lie that also
  under-counts the pool and hands dsh-llm-retry a wait it cannot act on (a permanent refusal retried after
  ~15 minutes). The diagnosis is built from the pool's FULL account list, never from the tried-filtered
  subset, so its count and its earliest reset describe what the user configured; and an unroutable window
  limit that names its own reset ends the turn as a retryable `RATE_LIMIT` (a plain 429 keeps the
  `Retry-After` mapping). A non-account-scoped 4xx (an invalid tool schema, a context overflow) still fails
  fast on the first attempt instead of multiplying the load across accounts. The dedicated-models picker's
  list comes from a Host-side `commandcode/models` Remote (the FULL adapter catalog via `listModels(…, {
  unfiltered: true })`, sorted), so the browser never calls the Command Code API; `SettingsPageApi.models`
  is optional, so legacy transports degrade to the empty-catalog state. Extra-account slot ids are the
  credential reference itself (`COMMANDCODE_API_KEY_2`, …) so a stored selection survives list
  reorders/removals; only literal-only composition entries keep positional `account-N` ids. **Account
  management on the settings page is IMMEDIATE, not staged**: `createAccount` / `renameAccount` /
  `removeAccount` / `setAccountKey` / `clearAccountKey` / `setActiveAccount` / `setAccountModels` on the
  controller each commit at once through one serial queue (`runAccountOp`, refused when the scope is not
  writable), so no page Save is involved and no staged account state can go stale. Two orderings are
  load-bearing: `createAccount` writes the key BEFORE the row and unsets the key again if the row write
  fails (a keyless-yet-keyed ref must never linger, because `nextAccountRef()` would hand it to the next
  account), and `removeAccount` refuses to drop a row whose stored key it could not unset, then drops that
  account's dedicated models and a pin naming it. Browser sign-in for a new account stores a KEYLESS row
  first — the Host's `loginCredentialRef` refuses a ref the stored `accounts` do not name — and the page
  removes that row again if the sign-in fails or is cancelled. The page shows `modelAccountRules` as
  per-account **dedicated models**: `accountModelMap()` folds the stored rules first-match-wins (exactly
  what the runtime would serve), and `setAccountModels` moves each chosen model out of every other account
  and writes one rule per account, so the stored list carries no shadowed entries. The config shape is
  unchanged. `workingDir` stays a valid Config field but is no longer on the page (and not a page field, so
  a save never touches it). The picker's billing-access cache is per gateway and key. The usage Remote result is
  `CommandCodeAccountsReport` (`{ accounts: [...] }`); host and client ship in one bundle, so wire-shape
  changes need no migration — only synced edits in `src/usage-wire.ts`, `src/usage-remote.ts`,
  `src/client/usage.ts`, and `src/commands.ts`. **A blocked usage report names the CAUSE, not just a
  verdict.** `classifyTotalFailure()` returns `network` whenever all four account endpoints threw without a
  status, and that one word covered five unrelated causes — a real outage, the account endpoints' own
  timeout, a key no HTTP header can carry (a paste artifact: `fetch` throws a `TypeError` BEFORE any I/O,
  once per endpoint), and an unparseable `apiBase` — so the card told users to check a connection that was
  fine. Three rules keep it honest: (1) the account path runs the harness's `assertUsableApiKey` in
  `accountHeaders()`, exactly like chat, and `getUsage()` answers `blocked: 'invalid-key'` with the
  credential message instead of four phantom transport failures (a MISSING credential still propagates); (2)
  the four endpoints get `connection.requestTimeoutMs` (the SAME budget as a chat call, default 300 s) rather
  than `MODELS_TIMEOUT_MS`, because a hidden 10 s cap made every account query time out on a slow link while
  chat kept working — the catalog/picker reads keep the short fail-open cap; (3) both surfaces RENDER
  `report.failures` (the settings card as `.cc-usageBlockedDetail`, the panel as `failure.detail`), since
  the endpoint messages are the only place the cause is named. Pinned by `tests/adapter.test.ts` (an
  unheaderable key never reaches `fetch` and reports `invalid-key`; the request budget is proven by a stub
  that waits on the request's own abort signal) and `tests/panel.test.ts`. **`report.credits` distinguishes
  "reported" from "zero", and that distinction is load-bearing**: `monthlyReported` is optional-tri-state
  (`undefined` = a pre-field Host, read as "assume reported"; explicit `false` = the endpoint omitted the
  balance, which the panel renders as `—` and never as a consumed quota), and `fiveHour`/`weekly` are
  OPTIONAL members that are absent when the endpoint reported no such window — a present window with `cap:
  0` means uncapped spend and keeps its row, an absent one keeps no row at all. Reading an absent balance as
  `0` is what turned a transient `/alpha/billing/credits` failure into a confident "100% used, quota
  exhausted"; the official CLI gates its own meter on the credits payload being present (`hasCreditsInfo`)
  and computes no depletion percentage without it. The wire schema validates a PRESENT `monthlyReported` as
  a boolean, so a malformed frame is rejected rather than coerced.
- **Web search (`src/web-search.ts` + the optional `web` seam)**: the model-facing `web_search` tool (from
  `@deepseek-ai/dsh-tool-web`) is served by a `CommandCodeSearchProvider` registered as `commandcode` on
  `ctx.web` — same `Authorization: Bearer <key>` + `x-command-code-version` chain, same `apiBase`, so DSH's
  web search needs NO separate key/endpoint config (unlike `dsh-web-search-deepseek`, which needs its own
  Anthropic-compatible base). It POSTs `{ query, numResults, allowedDomains?, blockedDomains? }` to
  `/alpha/web-search` and maps `{ title, url, snippet }` → `WebSearchSource`. Registration rides
  `ctx.inject(['web'], ...)` exactly like `commands`/`typert`: the provider is registered only when the
  profile mounts the web service, and the fiber never activates otherwise (this stays an LLM-provider-only
  plugin without web). The pool's `resolveKey()` (rotation + auth-file revived) is reused, so search
  benefits from the same multi-account selection; the search endpoint is account-independent so no
  mid-flight rotation happens. **Selection**: whether the `commandcode` provider WINS over the shipped
  `deepseek-official` (or a sibling search plugin's pin, e.g. modsearch's `searchProvider: modsearch`) is
  `Config.webSearch` (default on). **The seam is the supported engines' volatile reference, never a runtime
  property.** `WebRuntime.search()`/`fetch()` read `this.config.searchProvider.get() ?? this.searchProviderEnv`
  on EVERY call, and the pre-rc.2 `searchProviderId` instance field no longer exists, so the plugin never
  assigns a runtime field.
  `createCommandCodeSearchSelection()` in `src/web-search.ts` owns the whole policy: it writes
  through the host settings service — `ctx.settings.update('web', { searchProvider: 'commandcode' })` to take
  the backend, `ctx.settings.replace('web', …)` (with the user's other fields carried along and the composed
  base supplying ours) to give it back. Both land in the `web` profile entry's user layer, and the loader
  commits the value into the RUNNING reference of that entry in place — no remount, and the next search sees
  it. Two writers share that field: the shipped web-search settings page writes `deepseek-search-api` /
  `deepseek-official` there. **This plugin never displaces a pin it did not write**: a non-`commandcode` value
  in the user layer stops the takeover, is recorded on `CommandCodeSearchSelection.foreign`, and is reported
  in one `info` line — the provider then stays registered but unselected. A value the user layer does not
  carry is the deployment's own default, which is what the toggle exists to override. The state machine
  itself: `owner` marks what the plugin may give back; `preexisting` (the field already read `commandcode`
  while the user layer held nothing — i.e. it came from the composed config or `$DSH_WEB_SEARCH_PROVIDER`)
  makes disable a no-op; `displaced` is the config value at takeover time and is what the DEGRADED path
  restores. That degraded path exists because the write can be unavailable: with no settings service, no
  `web` row, or a refused write, the seam commits straight into the running reference via
  `volatileWrite()` (`Symbol.for('cosmokit.volatile.write')`, read back to verify) and finally degrades to
  registered-but-unselected — logging, never throwing. A direct reference write is second choice on purpose:
  it never reaches the profile, so the next commit for that entry re-resolves the raw config and overwrites
  it. Writes are serialized by a small queue that coalesces
  duplicate intents and lets a later one replace a queued one, because the toggle is a state rather than a log. `release()` on fiber unload deliberately
  writes NO profile — `config-editor` needs an ACTIVE entry fiber and the HMR exclusive lock — and only hands
  the running reference back, so the window where `commandcode` is selected while its provider is already
  unregistered (every search failing with `WEB_PROVIDER_CONFIGURED_MISSING`) stays closed; the persisted
  override survives to the next boot, which re-aligns it. A user-layer `commandcode` is treated as ours
  (nothing else writes that id), so disabling restores the composed default for both a previous run of this
  plugin and a deliberate manual pin. The deprecated `selectCommandCodeSearchProvider()` (which forced the
  factory default on disable) was DELETED with the rest of the generation bridge, and with it
  `applyCommandCodeSearchSelection()` — `createCommandCodeSearchSelection()` is the only entry point. `dsh-web`
  is a peer at `>=0.2.1-rc.2 <0.2.2-0` (kept external in tsdown); `tests/web-search.test.ts` pins the
  wire body, header, result mapping and the `WEB_ABORTED`/`WEB_PROVIDER_CREDENTIAL_MISSING`/`WEB_PROVIDER_ERROR`
  taxonomy, and
  drives the selection against the REAL engine — `boot()` plus real Loader, `config-editor` and `settings`
  over a throwaway profile — asserting on `WebRuntime.config.searchProvider.get()`, the value `search()`
  actually reads (take/restore/re-take, foreign pin, `preexisting`, refused write → memory fallback, a missing
  settings service, and unload not writing). A frozen runtime that offers no writable selection surface must
  neither throw nor change anything.
  **Transient network failures are retried inside the provider (issue #117).** `dsh-tool-web` runs the queries
  of one call concurrently and aborts every sibling as soon as the first fails, so one pre-response
  `fetch failed` used to discard the whole multi-query step (the reporter's 4-query calls failed 2/2 while
  retrying the same single query by hand succeeded). `search()` now repeats a fetch that received NO response
  up to `SEARCH_MAX_ATTEMPTS` (3 = the first try plus two retries) with jittered exponential backoff
  (500 ms then 1 s, ±20%), resolving the account once before the first attempt; the wait listens to the
  caller's signal, so a user stop or the tool's cooperative deadline still ends as `WEB_ABORTED` instead of
  sleeping through. Every non-cancel fetch rejection counts as transient: the runtime does not classify
  `error.cause` for us, and a deterministic failure (an expired certificate, an argument the runtime rejects)
  only costs the bounded backoff before the same error surfaces — cheaper than a code allowlist that could
  drop an unlisted blip. A received HTTP status — 401/403/429 included — is never retried: it is the server's
  answer, and replaying a plan/credential rejection helps nobody. A **response-body** failure is not retried
  either, but for the opposite reason: the headers arrived, so the request was already accepted and may have
  been executed; replaying it risks duplicate billing, and the failure is reported as-is. The terminal error
  appends the fetch cause code (`UND_ERR_CONNECT_TIMEOUT`, `ECONNRESET`, …), the target origin from
  `httpOrigin()` (path and query dropped, so a reverse-proxy prefix or a credential cannot leak) plus elapsed
  time and attempt count, so `fetch failed` alone no longer has to cover DNS, proxy and connect-timeout
  causes. Partial results for a multi-query call are still impossible here: the abort-on-first-failure policy
  lives in dsh's `dsh-tool-web`, not in this provider.
  **The retry budget deliberately brushes the tool's own deadline.** undici's connect timeout is ~10 s, so
  three connect-timeout attempts plus the two waits span ~31.5–33 s — past `dsh-tool-web`'s default 30 s
  `searchTimeoutMs`. In that slow-failure case the tool deadline fires mid-retry and the call ends as
  `WEB_ABORTED`, so the terminal transport diagnosis above is never produced; the reporter's 21.7 s first
  failure leaves only ~8 s for the retry, which a fresh connection can still use but a sustained outage
  cannot. A shorter per-attempt timeout is not added (it would be a new user-visible contract), and an
  elapsed-time rule is not used (it would skip the very slow failure this issue reported).
  `tests/web-search.test.ts` pins the retry, the once-only key resolution, the no-retry-on-status rule, the
  abortable wait and the diagnostic suffix.
- **`TRANSPORT` carries its own bounded budget, and the route policy cannot express it**
  (`src/transport-retry.ts` + the `agent/request-error` listener in `src/index.ts`; issue #39's second
  report). `providerRetryPolicy()` is captured once per route, so every code in its whitelist shares one
  window: 1000 attempts, waits doubling to 15 minutes. That shape is needed for a confirmed `RATE_LIMIT`
  window, while `SERVER` now has a separate three-retry cap and a connection that cannot
  be established. The reporter's second event at ~710k tokens was undici's own `Connect Timeout Error ...
  timeout: 10000ms` (its default connect timeout; `requestTimeoutMs` is 300 s and the connect phase never
  runs against the body upload) plus a `read ECONNRESET` on `/alpha/generate`; on the shared cadence the
  wait before attempt 11 alone is 512 s, so a 10-second TCP timeout produced an ~8-minute stall
  (`模型请求重试已取消（11/1000）· 482s` is that 512 s countdown, 30 s in). The listener therefore consumes `TRANSPORT`
  against a per-agent budget (`Config.transportMaxRetries`, default 5, 0–50) and THROWS when it is spent —
  throwing out of the waterfall is the only way to stop dsh-llm-retry, whose own policy would answer
  `TRANSPORT` with another retry. Order is load-bearing: the cancellation check runs BEFORE the budget, or a
  user's own stop would spend a slot a live failure needs. The reset point is `step/start`
  (`transportResetAction()` in the module states it once, and a test pins it) — one step IS one model
  request, so the cap stays per-logical-request and the next step of the same turn gets its own grace.
  `agent/status` → `idle` is NOT the reset: the loop's `setPhase` emits it only on a status CHANGE and a
  turn's steps share one `running` phase, so it never fires between them — resetting only there made the
  budget per-TURN, which is the bug the first version of this shipped with. `assistant/attempt` is wrong for
  the opposite reason: the loop appends it for the FAILED attempt before dispatching `agent/request-error`,
  so resetting on it restores the very loop this exists to stop. `turn/end` drops the session → agent
  mapping the reset needs. The `10s` connect timeout is undici's and reachability is not the plugin's to
  fix: measured against the live endpoint, a 1/8/30 MB body all returned the provider's own 401 in
  1.9/2.7/5.7 s, so the "long context" correlation in the report is not a size rejection.
  `tests/transport-retry.test.ts` pins the budget, per-agent isolation, the cancellation ordering and the
  message.
- **重试策略**：`providerRetryPolicy()` 保留官方 `dsh-llm-retry` 的退避与服务商等待时间处理；其路由级
  `maxRetries: 1000` 仅让明确额度窗口的 `RATE_LIMIT` 能持续等待。插件的 `agent/request-error` 监听器对
  `EMPTY_RESPONSE`、`SERVER`、`TIMEOUT`、`THROTTLED` 共用每次模型请求 3 次的预算；`TRANSPORT` 继续使用
  `transportMaxRetries` 独立预算。无窗口证据的裸 429 归为 `THROTTLED`，不能冒充已耗尽额度窗口。
  `step/start` 重置预算，失败尝试的 `assistant/attempt` 不重置，用户取消也不消耗次数。退避从 500 毫秒
  倍增，最长 15 分钟（±10% 抖动）；明确窗口的 `providerRetryAfterMs` 最多附加到同一上限，超过它会使
  官方执行器放弃重试。永久错误仍不在允许重试的代码列表内。参见[《决策记录》第一章](../决策记录.md#一请求失败恢复)。
- **跨 `stream()` 调用存活的故障状态必须按会话隔离**（`headerTimeoutStreak` → `headerTimeoutStreaks`
  in `src/adapter.ts`；不是 issue #67 本身的回归，是同一批新增重试预算暴露出的既有单例状态问题）。
  `CommandCodeAdapter` 全进程只 `new` 一次并注册一次（`src/index.ts`），供所有并发 agent 共享，而
  `gradeHeaderTimeout()` 用来判断"同一请求连续 N 次 header 超时"的计数曾是该单例上的普通实例字段——
  这个状态必须跨 `stream()` 调用存活（`TIMEOUT` 不在账号轮换循环内重试，一次超时就让整个 `stream()`
  抛出，由 `dsh-llm-retry` 发起下一次 `stream()` 调用），所以不能像别的每调用状态那样收窄到局部变量。
  并发下单例字段导致两种互相矛盾的故障：任意一个会话的成功响应会清空所有会话的计数（升级诊断在并发下
  基本不触发），而不同会话的请求体指纹不同又会不断把计数重置回 1（升级诊断永远打不到阈值）。修复为
  `Map<sessionId, {...}>`：不能照抄 `transient-retry.ts`/`transport-retry.ts` 的 `WeakMap<agent, …>`
  模式，因为 `GenerateOptions` 不携带 `agent` 引用，只有 `sessionId`；字符串 key 的 Map 无法用 WeakMap
  自动回收，改为容量上限 200 条 + 先进先出淘汰。无 `sessionId` 的一次性调用退回旧的单槽全局行为。
  `tests/adapter.test.ts` 新增并发会话独立累计、无会话回退两个用例。参见
  [《决策记录》第一章第 3 条](../决策记录.md#一请求失败恢复)。
  指纹取自**已经序列化好的实发字符串**（`serializedBodies` 里的那份，用 `sha256Hex()` 求摘要），
  不再对 `body` 重新 `JSON.stringify`：超时是最常重复的路径，而带图历史可达数 MB，重走整棵 body
  只为算第二个意见。这也更准确——实发字符串就是网关看到的字节，重新 stringify 会在 surrogate
  清洗真的删掉过字符时描述到不同的字节，把一次连续超时拆成两条 streak。没有实发字符串时
  （正文从未上过线）才回落到对象哈希。
- **设置页账号卡片 / 侧边栏统计的"当前使用"徽章必须和真实请求路由共用同一套自愈逻辑，否则它显示的是过期标记**
  (`CommandCodeAccountPool.activeAccount()` in `src/accounts.ts`; issue #51 的后续报告：账号卡片和侧边栏
  统计一起被"切到另一个账号"，且比真实请求恢复得慢得多)。`resolveKey()`（真实请求路径）对**显式选中**
  的账号（手动 pin 或模型路由命中）有专门的复活探测：一次 429 留下的 `unknown` 标记，会在下一次真实请求
  时主动探测其真实窗口（`EXPLICIT_ACCOUNT_PROBE_INTERVAL_MS`=60 秒节流），发现其实没超限就立刻恢复。但
  `src/index.ts` 的 `usageReports()` 此前直接调用裸 `selectActiveAccount()`——一个纯同步过滤函数，
  从不探测——而清除 `unknown` 标记的唯一途径就是 `resolveKey()` 内部的探测；`accountUsable()` 对
  `unknown` 状态永远返回不可用。结果是：只要用户没有实际发消息（只是打开设置页看看），一个早已可以被
  探测复活的标记会一直显示"已切换"，哪怕下一条真实消息本该立刻自动切回来。**修复**：把 `resolveKey()`
  里"显式账号回退前先探测复活"（原 317-329 行内联逻辑）和"全员被标记时批量探测"（原 338-352 行内联逻辑）
  分别抽成私有方法 `reviveExplicit()` / `probeAllMarked()`，新增公开方法 `activeAccount()` 复用这两个
  方法，`resolveKey()` 与 `activeAccount()` 现在共用同一套判断，不会再各自演化出不一致的行为。
  `activeAccount()` 与 `resolveKey()` 的唯一有意差异：不消耗 `tried` 预算、不区分具体模型（展示的是整个
  账号池的状态，不是某次请求）、且全部账号都不可用时返回 `undefined` 而不是抛错——展示场景不该因为
  "现在没有可用账号"而抛异常。探测节流状态（`explicitProbes`）与 `resolveKey()` 共享，所以刷新设置页
  不会导致探测接口被打两次。`tests/accounts.test.ts` 新增六个 `activeAccount` 用例：复活、真实耗尽时的
  正确回退、与 `resolveKey()` 共享节流、全员标记时的批量复活、真正全部耗尽时返回 `undefined`、空账号池。
  这个改动只覆盖"展示的账号与实际会用的账号不同步"这一半；反馈者截图里另一半"选的是还有额度的账号却
  突然报 400、会话中断"是否是同一根因、是不是需要真实零余额账号复现，仍待验证，未在本条修复范围内。
