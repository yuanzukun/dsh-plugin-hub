/**
 * Host half of the Command Code Remotes (`commandcode/report`,
 * `commandcode/models`, `commandcode/prices`, `commandcode/login*`).
 *
 * The settings page needs facts the browser cannot fetch for itself — it never
 * holds the API key — so this module exposes them through the Typert Gateway:
 * a `TypertRemoteService` provides the receiver the Gateway resolves, and the
 * shared strict descriptors (`src/usage-wire.ts`, `src/login-wire.ts`) are
 * registered on the `typert` registry so the Gateway claims the endpoints.
 *
 * The whole wiring rides an optional `ctx.inject(['typert'], ...)` fiber: a
 * profile without the web stack (no Typert registry, no Gateway) simply never
 * activates it, exactly like the `/commandcode` command rides `commands`.
 *
 * @module dsh-commandcode-provider/usage-remote
 */

import type { Context } from '@deepseek-ai/cordis'
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import type { CommandCodeAdapter, CommandCodeConnectionOptions } from './adapter.ts'
import { USAGE_HOST_CONTRIBUTION } from './usage-wire.ts'
import { MODELS_DESCRIPTOR } from './usage-wire.ts'
import { PRICES_DESCRIPTOR } from './usage-wire.ts'
import type { CommandCodeAccountsReport, CommandCodeCatalog, CommandCodePriceTable } from './usage-wire.ts'
import { modelPriceTable } from './model-prices.ts'
import { LOGIN_HOST_CONTRIBUTION } from './login-wire.ts'
import type { CommandCodeLoginStatus } from './login-wire.ts'
import { ENROLLMENT_DESCRIPTORS, type EnrollmentAction, type EnrollmentInput, type EnrollmentPage, type EnrollmentState } from './enrollment-wire.ts'
import type { AccountEnrollmentManager } from './enrollment.ts'

/**
 * The browser-login face the usage service exposes (`commandcode/login*`).
 * Backed by the Host-half {@link !CommandCodeLoginFlow} when the plugin entry
 * wired one; absent, `status`/`cancel` degrade to the idle status and `begin`
 * rejects with a plain message, so the page's manual paste path stays the
 * fallback instead of hanging.
 */
export interface LoginFlowFacade {
  /** Start (or rejoin) an attempt; rejects when it cannot start at all. */
  begin(targetRef?: string): Promise<CommandCodeLoginStatus>
  /** The current attempt's status. */
  status(): CommandCodeLoginStatus
  /** Cancel a waiting attempt. */
  cancel(): void
}

/** Everything the usage service needs beyond its Cordis context. */
export interface CommandCodeUsageDeps<C extends CommandCodeConnectionOptions = CommandCodeConnectionOptions> {
  /** The registered adapter (for getUsage). */
  adapter: CommandCodeAdapter<C>
  /**
   * Multi-account report source (wired by the plugin entry). Absent in
   * programmatic setups, the service falls back to a single default-account
   * entry around `adapter.getUsage()`.
   */
  reports?: () => Promise<CommandCodeAccountsReport>
  /**
   * Model-catalog source for the settings page's model editors. Absent, the
   * `models` endpoint answers an empty list — the page's editors degrade to
   * the empty state.
   */
  listModels?: () => Promise<CommandCodeCatalog>
  /**
   * Price-table source for the composer's session-cost figure. Defaults to the
   * vendored snapshot, so the endpoint can never silently serve an empty table
   * — an unpriced cost is the failure this feature is meant to remove. Override
   * only to stub it in a test.
   */
  prices?: () => CommandCodePriceTable
  /** The browser-login flow (wired by the plugin entry); see {@link LoginFlowFacade}. */
  login?: LoginFlowFacade
  enrollment?: AccountEnrollmentManager
}

/**
 * The registry method surface this module uses. `Context['typert']` is typed
 * as the read-only `TypertRegistryContract`; contribution registration lives
 * on the concrete registry service, so the cast is spelled out once here. The
 * contribution is the combined one built below, so the type is structural
 * rather than tied to any one endpoint's shape.
 */
interface TypertContributionRegistry {
  register(contribution: {
    package: string
    face: 'host'
    schemas: unknown[]
    model: { services: unknown[]; events: unknown[]; objects: unknown[] }
    invocations: unknown[]
  }): () => void | Promise<void>
}

/**
 * The Remote receiver: a Cordis service the Gateway resolves by key
 * (`commandcodeUsage`) and binds to the wire namespace (`commandcode`). The
 * base class stamps the `typertRemote` binding the Gateway validates on every
 * dispatch; no decorators are needed because the descriptor is registered
 * explicitly (strict path) rather than discovered from source markers.
 */
export class CommandCodeUsageService<C extends CommandCodeConnectionOptions = CommandCodeConnectionOptions>
  extends TypertRemoteService {
  private readonly deps: CommandCodeUsageDeps<C>

  constructor(ctx: Context, deps: CommandCodeUsageDeps<C>) {
    super(ctx, 'commandcodeUsage', { namespace: 'commandcode' })
    this.deps = deps
  }

  /**
   * Account, usage, and credit state for the settings page's account card.
   * Degrades per endpoint like the `/commandcode` command (failures land in
   * `report.failures`); throws `MISSING_CREDENTIAL` when no key resolves, which
   * the Gateway folds into the failure branch the page renders as a hint.
   */
  async report(): Promise<CommandCodeAccountsReport> {
    if (this.deps.reports !== undefined) return this.deps.reports()
    const report = await this.deps.adapter.getUsage()
    return {
      accounts: [{
        id: 'default',
        label: 'Default',
        configured: true,
        active: true,
        mark: '',
        cooldownUntil: 0,
        report,
      }],
    }
  }

  /**
   * The full model catalog for the settings page's model editors. The browser
   * never calls the Command Code API directly — the Host serves the catalog
   * (already fetched/cached by the adapter) so models can be picked from the
   * live list instead of typed by hand.
   */
  async models(): Promise<CommandCodeCatalog> {
    return this.deps.listModels?.() ?? { models: [] }
  }

  /**
   * The model price table the composer prices an in-progress session with.
   * Static vendored data, served Host-side so the browser bundle never carries
   * a copy that could drift from the snapshot, and so a price update reaches an
   * open page without a rebuild.
   */
  async prices(): Promise<CommandCodePriceTable> {
    return (this.deps.prices ?? modelPriceTable)()
  }

  /**
   * Start (or rejoin) a browser-login attempt and return its fresh status —
   * `waiting` carrying the Studio URL. Rejects when the flow cannot start
   * (no free loopback port, disposed plugin).
   */
  async loginBegin(targetRef?: string): Promise<CommandCodeLoginStatus> {
    const login = this.requireLogin()
    return login.begin(targetRef)
  }

  /** Poll a login attempt's status. */
  async loginStatus(): Promise<CommandCodeLoginStatus> {
    return this.deps.login?.status() ?? { state: 'idle' }
  }

  /** Cancel a waiting attempt; returns the post-cancel status. */
  async loginCancel(): Promise<CommandCodeLoginStatus> {
    this.deps.login?.cancel()
    return this.deps.login?.status() ?? { state: 'idle' }
  }

  async enrollmentBegin(input: EnrollmentInput): Promise<EnrollmentState> {
    const manager = this.requireEnrollment()
    const owner = this.enrollmentOwner(input)
    if (!manager.hasPage(owner)) throw new Error('账号开通页面观察流未建立')
    return manager.begin(owner, input)
  }
  async enrollmentStatus(input: EnrollmentAction): Promise<EnrollmentState> {
    return this.requireEnrollment().status(this.enrollmentOwner(input), input.id)
  }
  async enrollmentCancel(input: EnrollmentAction): Promise<EnrollmentState> {
    return this.requireEnrollment().cancel(this.enrollmentOwner(input), input.id)
  }
  async enrollmentName(input: EnrollmentAction): Promise<EnrollmentState> {
    return this.requireEnrollment().name(this.enrollmentOwner(input), input.id, input.name)
  }
  async enrollmentRetry(input: EnrollmentAction): Promise<EnrollmentState> {
    return this.requireEnrollment().retry(this.enrollmentOwner(input), input.id, input.name)
  }
  async enrollmentPending(input: EnrollmentPage): Promise<EnrollmentState[]> { return this.requireEnrollment().pending(this.enrollmentOwner(input)) }
  async *enrollmentWatch(input: EnrollmentPage): AsyncIterable<boolean> {
    const invocation = this.ctx.invocation
    if (!invocation) throw new Error('账号开通必须从已连接的页面调用')
    const manager = this.requireEnrollment()
    const release = manager.watch(this.enrollmentOwner(input))
    let abort: (() => void) | undefined
    try {
      const ended = new Promise<void>((resolve) => {
        abort = () => resolve()
        invocation.signal.addEventListener('abort', abort, { once: true })
        if (invocation.signal.aborted) resolve()
      })
      if (invocation.signal.aborted) return
      yield true
      await ended
    } finally {
      if (abort) invocation.signal.removeEventListener('abort', abort)
      release()
    }
  }
  private enrollmentOwner(input: EnrollmentPage): string { return `${this.enrollmentPeer().id}:${input.pageId}` }
  private enrollmentPeer() {
    const invocation = this.ctx.invocation
    if (!invocation) throw new Error('账号开通必须从已连接的页面调用')
    return invocation.peer
  }
  private requireEnrollment(): AccountEnrollmentManager {
    if (!this.deps.enrollment) throw new Error('宿主不支持账号开通，请更新插件')
    return this.deps.enrollment
  }

  private requireLogin(): LoginFlowFacade {
    const login = this.deps.login
    if (login === undefined) {
      throw new Error('login flow is not wired in this setup; paste the API key instead')
    }
    return login
  }
}

/**
 * Provide the usage service and register its Remote descriptor. The registry
 * contribution is tied to this fiber's lifetime: the registry's own
 * `register()` effect would otherwise outlive the plugin.
 */
export function applyUsageRemote<C extends CommandCodeConnectionOptions>(
  ctx: Context,
  deps: CommandCodeUsageDeps<C>,
): void {
  ctx.inject(['typert'], (remoteCtx) => {
    new CommandCodeUsageService(remoteCtx, deps)
    const registry = remoteCtx.typert as unknown as TypertContributionRegistry
    // One registration carries the report endpoint, the models endpoint, and
    // the login endpoints: the descriptors are unique per endpoint, and a
    // single contribution keeps the Host's registry bookkeeping (and the
    // Client mount) 1:1.
    const unregister = registry.register({
      ...USAGE_HOST_CONTRIBUTION,
      invocations: [...USAGE_HOST_CONTRIBUTION.invocations, MODELS_DESCRIPTOR, PRICES_DESCRIPTOR, ...LOGIN_HOST_CONTRIBUTION.invocations, ...ENROLLMENT_DESCRIPTORS],
    })
    // The registry's own effect would outlive this fiber; withdraw the
    // contribution when the plugin unloads.
    remoteCtx.effect(() => () => void unregister(), 'dsh-commandcode-provider: usage remote')
  })
}
