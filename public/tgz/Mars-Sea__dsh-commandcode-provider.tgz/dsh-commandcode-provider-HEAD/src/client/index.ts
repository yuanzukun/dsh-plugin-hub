/**
 * Browser half of the dsh-commandcode-provider bundle: the "Command Code"
 * settings page (`settings.section`, id `commandcode`), the Models-page
 * provider card (`settings.models.provider-card`, key `llm-commandcode`, see
 * `./card.tsx`), the quota/model-analysis panel's `main` cell + gated
 * `sidebar.footer.action` card, and the composer
 * `conversation.composer.dock` cost entry.
 *
 * The API key is written through the credentials domain (the
 * `COMMANDCODE_API_KEY` reference the plugin resolves via
 * `ctx.remote.credentials`), never as a settings value, and every other fact
 * through the `llm-commandcode` namespace — so a saved key or endpoint reaches
 * the very next request and the key literal cannot land in a settings document.
 */

import type { Context } from '@deepseek-ai/cordis'
import { createSnapshotStore } from './snapshot-store.ts'
import { readableErrorText } from '../readable-error.ts'
// Type-only: the client-service augmentations (`slots`/`remote`/`locale` on
// Context) and the `settings.section` SlotMap entry.
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import { createSettingsScope, type SettingsRemoteNamespace, type SettingsScopeContext } from './settings-scope.ts'
import { CommandCodeSettingsController, COMMANDCODE_NS, type SettingsPageState } from './settings.ts'
import type { SettingsPageApi } from './settings.ts'
import { CommandCodeUsageController, type UsagePageState, type UsageRemote } from './usage.ts'
import { CommandCodePricesController, type SessionCostPricesState } from './prices.ts'
import { CommandCodeLoginController, type LoginPageState, type LoginRemote } from './login.ts'
import { USAGE_REMOTE_CONTRIBUTION, MODELS_REMOTE_CONTRIBUTION, PRICES_REMOTE_CONTRIBUTION } from '../usage-wire.ts'
import { PROBE_REMOTE_CONTRIBUTION } from '../service-probe-wire.ts'
import { LOGIN_REMOTE_CONTRIBUTION } from '../login-wire.ts'
import { ENROLLMENT_REMOTE_CONTRIBUTION } from '../enrollment-wire.ts'
import { AccountEnrollmentController, type EnrollmentRemote } from './enrollment.ts'
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol'
import { CommandCodeSettingsPage } from './section.tsx'
import { CommandCodeProviderCard } from './card.tsx'
import { CommandCodePanel, CommandCodeFooterEntry } from './panel-view.tsx'
import type { PanelInjected } from './panel-view.tsx'
import { CommandCodeSessionCost } from './session-cost-view.tsx'
import type { SessionCostInjected } from './session-cost-view.tsx'
import { startPanelAutoRefresh } from './panel.ts'
import { PAGE_CSS, PAGE_CSS_ID } from './page-styles.ts'
import { PANEL_CSS, PANEL_CSS_ID } from './panel-styles.ts'
// Type-only: pulls in the SlotMap merge for the composer dock
// (`./session-cost-slots.ts`). The sidebar-foot / center-column merge rides the
// `./panel-view.tsx` value import above, which imports `./panel-slots.ts`.
import type {} from './session-cost-slots.ts'
import { zh, en } from './locales.ts'
import { PANEL_COPY_EN, PANEL_COPY_ZH, PANEL_LOCALE_NS } from './panel-copy.ts'
import { ANALYTICS_REMOTE_CONTRIBUTION } from '../analytics-wire.ts'
import { AnalyticsController } from './analytics.ts'
import type { AnalyticsQuery } from '../analytics-wire.ts'



/** Install one stylesheet by id and return a disposer for its owning effect. */
function injectCss(id: string, css: string): () => void {
  if (typeof document === 'undefined') return () => {}
  if (document.querySelector(`style[data-plugin-css="${id}"]`) !== null) return () => {}
  const tag = document.createElement('style')
  tag.dataset.plugin = '@mars-sea/dsh-commandcode-provider'
  tag.dataset.pluginCss = id
  tag.textContent = css
  document.head.appendChild(tag)
  return () => tag.remove()
}

/**
 * Plans & quota panel id. It is the layout's `MainPanelId`: one string shared
 * by the `sidebar.footer.action` card and the `main` slot cell, so the card
 * selects this panel and nothing else. `dsh-client-ui-layout` is not a
 * dependency of this bundle, so its brand is applied at the call site instead
 * of importing the package.
 */
const PANEL_ID = 'commandcode-panel'

/**
 * The composer figure's entry id in `conversation.composer.dock`. Its own id,
 * never the shipped `stats` cell's: reusing that id would REPLACE the tokens /
 * cache-hit / throughput readout rather than inject into it, and that readout
 * is the harness's to format.
 */
const SESSION_COST_ID = 'commandcode-session-cost'

/**
 * The one shot of the `layout` service this plugin needs, declared
 * structurally: importing the package would make the browser resolve a client
 * module this bundle never calls. Read through the reflective
 * `ctx.get('layout')`, never a bare `ctx.layout` property — `layout` is not in
 * the exported inject list, and cordis throws `cannot get property … without
 * inject` for an undeclared service. (The footer card's own gate below IS a
 * static `ctx.inject(['layout'])`, but it is scoped to that one registration.)
 */
interface LayoutSelectionSeam {
  /** `null` shows the Conversation again; a string selects that registered `main` key. */
  selectPanel(id: string | null): void
}

/**
 * Client plugin body. Gates on `slots`, `locale` and `remote` — never on
 * `settingsScope`, whose wrapper service the 0.1.7 settings rewrite removed
 * (the scope below speaks the `remote.settings` wire directly), because
 * gating on a service 0.1.7 does not provide would park EVERY surface below
 * into silence. `settingsScope` must never reappear in the exported inject
 * list at the bottom of this file.
 */
export function apply(ctx: Context): void {
  injectCss(PAGE_CSS_ID, PAGE_CSS)

  // The "Command Code" settings page: register the section once the
  // `settings.section` declaration is on the ledger (ui-settings-general
  // owns the shell; `slots.inject` waits for the declaration, so registration
  // order relative to it does not matter).
  ctx.effect(() => ctx.locale.register('settings.commandcode', { zh, en }), 'dsh-commandcode-provider: page copy')

  // The panel's copy is a namespace of its own: the panel is not part of the
  // settings page, but it follows the SAME active language — declaring
  // `PANEL_LOCALE_NS` on both panel registrations is what binds their `t` seat.
  ctx.effect(
    () => ctx.locale.register(PANEL_LOCALE_NS, { zh: PANEL_COPY_ZH, en: PANEL_COPY_EN }),
    'dsh-commandcode-provider: panel copy',
  )

  // Credentials reach the browser as a Typert Remote namespace. This inject is
  // the activation gate for every surface below, so a profile whose Host
  // serves no credentials namespace simply never mounts the page.
  ctx.inject(['remote.credentials'], (remoteCtx) => {
    const credentials = (remoteCtx.remote as unknown as {
      credentials: SettingsPageApi['credentials']
    }).credentials
    applyClientSurfaces(remoteCtx, { credentials })
  })
}

/** Mount the one shared UI implementation. */
function applyClientSurfaces(
  ctx: Context,
  api: SettingsPageApi,
): void {
  // This plugin's own binding of the `llm-commandcode` namespace over
  // `remote.settings` (see `./settings-scope.ts`).
  //
  // The namespace object is captured from an INJECT-SCOPED context, never read
  // off `ctx.remote`: `remote.settings` is a Cordis service NESTED under
  // `remote`, and cordis answers a read through a context that does not declare
  // it with `Error: cannot get property "remote.settings" without inject` —
  // which lands inside the scope's own `try`/`catch`, so nothing is logged and
  // the page renders read-only with every control disabled (the 0.1.7
  // settings-page report, CHANGELOG 0.11.9; the full incident is in
  // AGENTS.md). The resolver hands the scope the very object the inject
  // resolved, and `refresh()` re-reads once it lands; a profile whose Host
  // serves no settings namespace simply never resolves it, where the page
  // keeps rendering its degraded state instead of crashing.
  let settingsNamespace: SettingsRemoteNamespace | undefined
  const scope = createSettingsScope<Record<string, unknown>>(
    ctx as unknown as SettingsScopeContext,
    COMMANDCODE_NS,
    () => settingsNamespace,
  )
  ctx.effect(() => () => { void scope.dispose() }, 'dsh-commandcode-provider: settings scope')
  ctx.inject(['remote.settings'], (settingsCtx) => {
    settingsNamespace = (settingsCtx.remote as unknown as {
      settings: SettingsRemoteNamespace
    }).settings
    // The first read raced this inject and answered "not mounted"; re-read now
    // that the namespace is here (and again whenever it re-mounts).
    scope.refresh()
    settingsCtx.effect(() => () => {
      settingsNamespace = undefined
    }, 'dsh-commandcode-provider: settings namespace')
  })
  // The model catalog for the settings page's model editors is served by the
  // `commandcode/models` Remote mounted below, which happens after this
  // controller is constructed — so it reads the catalog through this mutable
  // seam. Unset until the mount lands; the controller degrades to the
  // empty-catalog state meanwhile.
  let modelsRemote: NonNullable<SettingsPageApi['models']> | undefined
  const controller = new CommandCodeSettingsController(
    scope,
    { ...api, models: () => modelsRemote?.() ?? Promise.resolve({ ok: false, error: { message: 'commandcode/models remote is not mounted' } }) },
  )
  ctx.effect(() => () => controller.dispose(), 'dsh-commandcode-provider: settings controller')
  const store = createSnapshotStore<SettingsPageState>(controller.state())
  controller.subscribe(() => store.set(controller.state()))
  ctx.effect(
    () => {
      const remote = ctx.remote as unknown as {
        $on(
          event: 'credentials/reference-updated' | 'credentials/record-updated',
          listener: (ref: string) => void,
        ): () => void
      }
      const unregisterReference = remote.$on('credentials/reference-updated', () => {
        controller.refreshCredentials()
      })
      const unregisterRecord = remote.$on('credentials/record-updated', () => {
        controller.refreshCredentials()
      })
      return () => {
        unregisterReference()
        unregisterRecord()
      }
    },
    'dsh-commandcode-provider: credential invalidations',
  )

  // One mount carries every endpoint this plugin serves (report, catalog, price
  // table, login), keeping the Client's bookkeeping 1:1 with the Host's single
  // registry registration. Cordis only serves services a fiber declares in
  // `inject`, and the namespace service exists only after the mount — so the
  // `remote.commandcode` inject is registered DYNAMICALLY once the mount
  // lands; a static one would deadlock the plugin, the mounter waiting for its
  // own mount. A Host half that predates the Remote fails the calls instead,
  // and the surfaces render their error branches.
  let usageNamespace: (typeof ctx.remote)['commandcode'] | undefined
  let usageMountError: string | undefined
  // `pricesController` and `refreshUsage` are declared here and assigned below,
  // because the mount effect's inject callback calls them while cordis runs it
  // synchronously — before their own `const` would be initialized. A read in
  // that temporal dead zone THROWS, which `?.` would not save.
  let pricesController: CommandCodePricesController | undefined
  let refreshUsage: (() => void) | undefined
  let analyticsController: AnalyticsController | undefined
  const contribution: TypertRemoteContribution = {
    package: USAGE_REMOTE_CONTRIBUTION.package,
    descriptors: [
      ...USAGE_REMOTE_CONTRIBUTION.descriptors,
      ...MODELS_REMOTE_CONTRIBUTION.descriptors,
      ...PRICES_REMOTE_CONTRIBUTION.descriptors,
      ...ANALYTICS_REMOTE_CONTRIBUTION.descriptors,
      ...PROBE_REMOTE_CONTRIBUTION.descriptors,
      ...LOGIN_REMOTE_CONTRIBUTION.descriptors,
      ...ENROLLMENT_REMOTE_CONTRIBUTION.descriptors,
    ],
  }
  ctx.effect(() => {
    let cancelled = false
    let unmount: (() => Promise<void>) | undefined
    void ctx.remote.$mount(contribution).then((dispose: () => Promise<void>) => {
      if (cancelled) {
        void dispose()
        return
      }
      unmount = dispose
      ctx.inject(['remote.commandcode'], (namespaceCtx) => {
        usageNamespace = namespaceCtx.remote.commandcode
        // The catalog Remote is live now; (re)fetch it for the model editors,
        // and the price table the composer's cost readout needs — `ensure()` is
        // idempotent, so asking earlier could only fail (the namespace did not
        // exist yet).
        controller.refreshCatalog()
        pricesController?.reload()
        analyticsController?.reload()
        // ...and the usage report. A surface can (and on a boot with the quota
        // card on, always does) ask for it BEFORE this mount lands: the answer
        // then is the synthetic "remote is not mounted" failure, which the
        // controller stores as `status: 'error'` — and its `shouldRefresh` only
        // fires from `idle`, so nothing would ever retry it (`usage.ts`). The
        // namespace is live here, so re-read now and replace that stale answer.
        refreshUsage?.()
        namespaceCtx.effect(() => () => {
          usageNamespace = undefined
          analyticsController?.reload()
        }, 'dsh-commandcode-provider: usage namespace')
      })
    }, (error: unknown) => {
      // A mount failure (e.g. a harness without the Remote mount) leaves the
      // namespace unset; keep the reason so the card can surface it.
      usageMountError = readableErrorText(error)
    })
    return () => {
      cancelled = true
      usageNamespace = undefined
      if (unmount !== undefined) void unmount()
    }
  }, 'dsh-commandcode-provider: usage remote')
  const usageRemote: UsageRemote = {
    report: async () => {
      const namespace = usageNamespace
      if (namespace === undefined) {
        return { ok: false, error: { message: usageMountError ?? 'commandcode/report remote is not mounted' } }
      }
      return namespace.report()
    },
    models: async () => {
      const namespace = usageNamespace
      if (namespace === undefined) {
        return { ok: false, error: { message: usageMountError ?? 'commandcode/models remote is not mounted' } }
      }
      return namespace.models()
    },
    prices: async () => {
      const namespace = usageNamespace
      if (namespace === undefined) {
        return { ok: false, error: { message: usageMountError ?? 'commandcode/prices remote is not mounted' } }
      }
      const call = namespace.prices
      // A Host half older than the price table mounts no such descriptor, so
      // the namespace member is genuinely missing. Report it as a permanent
      // failure the readout understands rather than throwing.
      if (typeof call !== 'function') {
        return { ok: false, error: { message: 'the Host serves no commandcode/prices endpoint', permanent: true } }
      }
      return call.call(namespace)
    },
  }
  modelsRemote = () => usageRemote.models()
  const usageController = new CommandCodeUsageController(usageRemote)
  refreshUsage = () => void usageController.refresh()
  ctx.effect(() => () => usageController.dispose(), 'dsh-commandcode-provider: usage controller')
  const usageStore = createSnapshotStore<UsagePageState>(usageController.state())
  usageController.subscribe(() => usageStore.set(usageController.state()))

  // The composer's session-cost readout prices from a static table, so its
  // controller is a one-shot cache rather than a poll.
  pricesController = new CommandCodePricesController(usageRemote)
  ctx.effect(() => () => pricesController?.dispose(), 'dsh-commandcode-provider: price table')
  const pricesStore = createSnapshotStore<SessionCostPricesState>(pricesController.state())
  pricesController.subscribe(() => pricesStore.set(pricesController.state()))

  analyticsController = new AnalyticsController({ analytics: async query => {
    const namespace = usageNamespace
    if (typeof namespace?.analytics !== 'function') return { ok: false, error: { message: '宿主不支持模型分析，请更新插件' } }
    return namespace.analytics(query)
  } })
  const analyticsStore = createSnapshotStore(analyticsController.state())
  analyticsController.subscribe(() => analyticsStore.set(analyticsController!.state()))
  ctx.effect(() => () => analyticsController?.dispose(), 'commandcode analytics controller')
  const panelMode = createSnapshotStore<'quota' | 'analysis'>('quota')
  const openAnalytics = () => {
    panelMode.set('analysis')
    const layout = ctx.get('layout') as LayoutSelectionSeam | undefined
    layout?.selectPanel(PANEL_ID)
  }

  // The login panel: same namespace, three endpoints. The key NEVER crosses to
  // the browser — the Host validates and stores it through the credentials
  // seam, and a landed login re-reads the credential badges + usage card.
  const loginRemote: LoginRemote = {
    loginBegin: async (targetRef?: string) => {
      if (usageNamespace === undefined) {
        return { ok: false, error: { message: usageMountError ?? 'commandcode remote is not mounted' } }
      }
      return usageNamespace.loginBegin(targetRef)
    },
    loginStatus: async () => {
      if (usageNamespace === undefined) {
        return { ok: false, error: { message: usageMountError ?? 'commandcode remote is not mounted' } }
      }
      return usageNamespace.loginStatus()
    },
    loginCancel: async () => {
      if (usageNamespace === undefined) {
        return { ok: false, error: { message: usageMountError ?? 'commandcode remote is not mounted' } }
      }
      return usageNamespace.loginCancel()
    },
  }
  const loginController = new CommandCodeLoginController(() => loginRemote)
  ctx.effect(() => () => loginController.dispose(), 'dsh-commandcode-provider: login controller')
  const loginStore = createSnapshotStore<LoginPageState>(loginController.state())
  let lastLoginPhase = loginController.state().phase
  loginController.subscribe(() => {
    const phase = loginController.state().phase
    // A landed login stored the key Host-side behind the page's back, so the
    // badges must follow and the account card can finally fetch.
    if (phase === 'success' && lastLoginPhase !== 'success') {
      controller.refreshCredentials()
      void usageController.refresh()
    }
    lastLoginPhase = phase
    loginStore.set(loginController.state())
  })

  const refreshUsageOn = (ok: boolean): boolean => {
    const outcome = controller.state().accountResult
    if (ok || outcome?.config === 'confirmed' || outcome?.credential === 'confirmed') void usageController.refresh()
    return ok
  }
  const injected = () => ({
    // The status row's live half: one probe of the configured API base, run
    // Host-side. A Host older than the probe endpoint mounts no such method, so
    // the row must render "unknown" rather than throw (see section.tsx).
    probeService: () => {
      const namespace = usageNamespace
      if (typeof namespace?.probe !== 'function') {
        return Promise.resolve({ ok: false as const, error: { message: '宿主未提供连通性探测' } })
      }
      return namespace.probe()
    },
    createEnrollment: () => new AccountEnrollmentController(() => {
      if (!usageNamespace?.enrollmentBegin) throw new Error('宿主不支持账号开通，请更新插件')
      return usageNamespace as EnrollmentRemote
    }, () => { scope.refresh(); controller.refreshCredentials(); void usageController.refresh() }),
    hooks: { commandCodeSettings: store, commandCodeUsage: usageStore, commandCodeLogin: loginStore },
    edit: (field: string, text: string) => controller.edit(field, text),
    resetField: (field: string) => controller.resetField(field),
    // 部分完成也可能改变凭据或连接配置，用本次确认结果刷新用量。
    save: () => void controller.save().then(outcome => {
      if (outcome?.config === 'confirmed' || outcome?.credential === 'confirmed') void usageController.refresh()
    }),
    discard: () => controller.discard(),
    refreshCredentials: () => void controller.refreshCredentials(),
    refreshUsage: () => void usageController.refresh(),
    ...(typeof (ctx.get('layout') as LayoutSelectionSeam | undefined)?.selectPanel === 'function' ? { openAnalytics } : {}),
    beginLogin: (targetRef?: string) => void loginController.begin(targetRef),
    cancelLogin: () => void loginController.cancel(),
    // Account operations commit immediately. The ones that change which keys
    // exist refetch the usage report so the account rows follow.
    renameAccount: (ref: string, label: string) => controller.renameAccount(ref, label),
    removeAccount: (ref: string) => controller.removeAccount(ref).then((ok) => {
      // 配置可能已移除、凭据清理仍失败；用量页也应立即跟随新的账户列表。
      if (ok || !controller.state().accounts.some((account) => account.ref === ref)) void usageController.refresh()
      return ok
    }),
    retryCredentialCleanup: (ref: string) => controller.retryCredentialCleanup(ref).then(refreshUsageOn),
    setAccountKey: (target: string, key: string) => controller.setAccountKey(target, key).then(refreshUsageOn),
    clearAccountKey: (target: string) => controller.clearAccountKey(target).then(refreshUsageOn),
    setActiveAccount: (id: string) => controller.setActiveAccount(id).then(refreshUsageOn),
    setAccountModels: (target: string, ids: string[]) => controller.setAccountModels(target, ids),
    editVisibleModels: (ids: string[]) => controller.editVisibleModels(ids),
    clearVisibleModels: () => controller.clearVisibleModels(),
    editContextWindowOverrides: (next: Record<string, string>) => controller.editContextWindowOverrides(next),
  })

  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'commandcode',
    order: 12,
    label: () => ctx.locale.bind('settings.commandcode')('nav'),
    locale: 'settings.commandcode',
    inject: injected,
  }, CommandCodeSettingsPage))

  // The Models-page provider card: a keyed slot the Models section dispatches
  // with `entryKey = settingsNs` on every provider row of an adapter family, so
  // the panel mounts beside the official editor on every Command Code row —
  // including the first-run setup posture, exactly where a user without a key
  // lands. While the official 编辑 toggle is open, the card hides the official
  // editor shell (for this namespace `layoutOf` returns "unknown", so that shell
  // carries only a config hint over a disabled apply) and shows the real
  // controls; see card.tsx. The registration carries its own inject face
  // because the declaring entry is ui-settings-models', not ours; the `t` seat
  // comes from the registration's own `locale` namespace.
  //
  // On a build without this slot the declaration never exists and `slots.inject`
  // never fires — the registration silently does not happen. Do not "harden"
  // that into an error.
  ctx.slots.inject('settings.models.provider-card', () => ctx.slots.register({
    name: 'settings.models.provider-card',
    key: 'llm-commandcode',
    locale: 'settings.commandcode',
    inject: () => ({
      hooks: { commandCodeSettings: store, commandCodeLogin: loginStore },
      edit: (field: string, text: string) => controller.edit(field, text),
      save: () => void controller.save().then(outcome => {
        if (outcome?.config === 'confirmed' || outcome?.credential === 'confirmed') void usageController.refresh()
      }),
      discard: () => controller.discard(),
      refreshCredentials: () => void controller.refreshCredentials(),
      beginLogin: () => void loginController.begin(),
      cancelLogin: () => void loginController.cancel(),
    }),
  }, CommandCodeProviderCard))

  // The plans & quota panel: a footer card pinned at the bottom of the sidebar,
  // on top of the Settings seat, that opens a dashboard in the center column.
  //
  // Two registrations, ONE navigation entry: `sidebar.footer.action` is the
  // list the sidebar shell renders in its foot area directly above the Settings
  // seat (`footArea` = `footerActions` then `settingsArea`), which is what puts
  // this card at the bottom of the column rather than at the top with the
  // global panel icons of `sidebar.panellist`. The layout's keyed `main` slot
  // holds the panel the card opens — `selectPanel(id)` resolves the id against
  // that registry and throws when no cell occupies it, so BOTH registrations
  // are required, and BOTH need the `inject` face below (an entry without one
  // receives none of the panel's data; see the `hooks` → `useX` rule in
  // panel-view.tsx).
  //
  // Unlike a `sidebar.panellist` row, the shell renders NO chrome around a
  // footer action: our component IS the button, it owns the label (so a title
  // carrying live quota needs no re-registration — that dance exists only
  // because the shell caches a panellist entry's label), and it selects the
  // panel itself through the `open` action below.
  //
  // Both registrations declare the panel's own `locale` namespace
  // (`panel.commandcode`, registered in `apply` above): that is what binds the
  // `t` seat the components feed into `buildPanelView`, so the panel follows
  // the harness's active language and a switch re-renders it.
  //
  // The footer card is gated on the `layout` SERVICE (below), not only on its
  // slot: a profile whose `main` declaration exists but whose layout never
  // mounted would otherwise register a card that renders and does nothing —
  // a dead button. The dashboard cell needs no such gate; registering against
  // a declaration that never arrives is a no-op by construction.
  //
  // Shape notes:
  //   * The stylesheet gets its own `ctx.effect` rather than riding an `inject`
  //     callback's return value, so the tag's lifetime is the plugin fiber's and
  //     is unaffected by a slot declaration collapsing and re-declaring.
  //   * Each registration is guarded so a failure in one surface cannot abort
  //     `applyClientSurfaces` and take the OTHER surfaces down with it —
  //     `slots.inject` rethrows a callback failure synchronously once the
  //     declaration exists. The renderer contains a *render* crash by abdicating
  //     the entry with no visible error, so a failure that leaves nothing on
  //     screen must at least be loud in the console.
  const panelFace = (): PanelInjected => ({
    hooks: { commandCodeUsage: usageStore, commandCodeSettings: store, commandCodeAnalytics: analyticsStore, commandCodePanelMode: panelMode },
    selectPanelMode: (mode) => panelMode.set(mode),
    refreshAnalytics: (query?: AnalyticsQuery) => analyticsController?.refresh(query),
    refresh: () => { pricesController?.ensure(); void usageController.refresh() },
    // The Host resolves every credential source, including CLI auth and
    // literals. A browser credential-reference lookup cannot determine
    // availability.
    startAutoRefresh: () => startPanelAutoRefresh(usageController, () => true),
    // `layout` is read reflectively AT CLICK TIME, never captured at setup:
    // ui-layout is not a dependency of this bundle (its types are not imported
    // and its client module is never resolved), and it is not in the exported
    // inject list. The footer registration below is gated on the same seam, so
    // by the time this runs the method exists; the guard stays as the last line
    // of defence against a layout that renames it.
    open: () => {
      panelMode.set('quota')
      const layout = ctx.get('layout') as LayoutSelectionSeam | undefined
      layout?.selectPanel(PANEL_ID)
    },
    // The dashboard's way out (issue #41). It occupies the center column in
    // place of the Conversation, and `open()` above is the ONLY other panel
    // selection this plugin makes — so without an exit the panel is a one-way
    // door: clicking the sidebar card just re-selects it. `selectPanel(null)`
    // is layout's "show the Conversation" selection and leaves the current
    // Session untouched.
    close: () => {
      const layout = ctx.get('layout') as LayoutSelectionSeam | undefined
      layout?.selectPanel(null)
    },
  })

  ctx.effect(() => injectCss(PANEL_CSS_ID, PANEL_CSS), 'dsh-commandcode-provider: panel styles')

  try {
    ctx.slots.inject('main', () => ctx.slots.register(
      { name: 'main', key: PANEL_ID, locale: PANEL_LOCALE_NS, inject: panelFace },
      CommandCodePanel,
    ))
  } catch (error: unknown) {
    console.error('[dsh-commandcode-provider] could not register the plans & quota panel:', error)
  }

  // The footer card is registered only where the layout can actually open the
  // panel behind it: `ctx.inject(['layout'], …)` runs its body when that service
  // is live and re-runs it if the service is replaced, mirroring how the Remote
  // namespace is mounted — so a profile without ui-layout (the TUI, a headless
  // client) never registers the card at all.
  ctx.inject(['layout'], (layoutCtx) => {
    try {
      layoutCtx.slots.inject('sidebar.footer.action', () => layoutCtx.slots.register(
        // `order` is the only control over position inside a list slot, and the
        // renderer sorts ascending. ui-cordis's footer chip registers at the
        // default 0, so 1 sorts after it — but any sibling passing an order ≥ 1
        // lands between this card and Settings, so "directly above Settings" is
        // a preference, not a guarantee.
        { name: 'sidebar.footer.action', id: PANEL_ID, order: 1, locale: PANEL_LOCALE_NS, inject: panelFace },
        CommandCodeFooterEntry,
      ))
    } catch (error: unknown) {
      console.error('[dsh-commandcode-provider] could not register the sidebar footer card:', error)
    }
  })

  // The composer's session-cost figure: an entry in the dock below the input
  // that renders NO surface of its own. The cost is injected into the harness's
  // own token-usage UI — the amount as the last item of the shipped pill's text
  // run, the breakdown as rows inside the usage dialog that pill opens (see
  // `./session-cost-display.ts`).
  //
  // The entry exists for its SEATS, not for a surface: `useProjection` is a
  // standard prop the composer hands every dock occupant, so this registration
  // is the only way to read the session's token accounting. The token buckets
  // and the model selection arrive from the composer itself as standard dock
  // props, so the face carries only the price-table hook.
  //
  // No `locale` namespace and no `t` seat: the figure is English by
  // construction, from `./session-cost.ts`.
  const sessionCostFace = (): SessionCostInjected => ({
    hooks: { commandCodePrices: pricesStore },
  })

  try {
    ctx.slots.inject('conversation.composer.dock', () => ctx.slots.register(
      // No `order`: the entry renders nothing, so its position among the dock's
      // rows cannot matter — the sort only ever decides what a reader sees.
      { name: 'conversation.composer.dock', id: SESSION_COST_ID, inject: sessionCostFace },
      CommandCodeSessionCost,
    ))
  } catch (error: unknown) {
    console.error('[dsh-commandcode-provider] could not register the composer session-cost readout:', error)
  }
}

export const inject: readonly string[] = [
  'slots',
  'locale',
  'remote',
]
