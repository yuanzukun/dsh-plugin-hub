/**
 * Model-select helpers for the settings page's model editors (browser half).
 *
 * The routing-rule editor and the visible-models filter both pick catalog models
 * through the same checkbox multi-select dropdown (`ModelMultiSelect` in
 * section.tsx). The dropdown's data shaping — search filtering, stale-id
 * detection, tier grouping — lives here, React-free, so node tests can drive
 * it directly.
 *
 * The shared tier module is dependency-free and inlined into the client bundle;
 * importing the Host's full capability snapshot here would bloat that bundle.
 *
 * @module dsh-commandcode-provider/model-select
 */

import { PLAN_LABELS } from '../plan-tiers.ts'

/**
 * The dropdown section heading for a catalog model id, or undefined for
 * models outside the known plan tiers (unmapped models and stale ids render
 * unheaded). `knownPlans` is the Host-side `KNOWN_PLANS` table, threaded in
 * by the caller so this module stays dependency-free.
 */
export function tierHeadingFor(
  modelId: string,
  knownPlans: Readonly<Record<string, string>>,
): string | undefined {
  const tier = knownPlans[modelId]
  if (tier === undefined) return undefined
  return PLAN_LABELS[tier] ?? tier
}

/** One selectable catalog model (mirrors `CatalogModelOption` in settings.ts). */
export interface SelectableModel {
  /** Catalog model id (e.g. `deepseek/deepseek-v4-pro`). */
  id: string
  name: string
  /**
   * Per-model monthly allowance in USD, already resolved by the Host. Passed
   * through untouched: this module renders it, it does not interpret it.
   */
  allowance?: number
}

/** One dropdown row: a live catalog model or a stale selection. */
export interface ModelSelectOption {
  /** Catalog model id (stale ids keep their raw id as the value). */
  value: string
  label: string
  /** True when the id is selected but the catalog no longer carries it. */
  stale: boolean
  /**
   * Per-model monthly allowance in USD. Only live catalog rows can carry one —
   * a stale id is no longer priced by the page, so there is nothing to show.
   */
  allowance?: number
}

/** One dropdown section: a plan-tier heading plus its rows. */
export interface ModelSelectGroup {
  /** Section heading, or undefined for models outside the known plan tiers. */
  heading: string | undefined
  /** Rows in this section, in picker order. */
  options: ModelSelectOption[]
}

/**
 * Whether `text` matches `query` as a case-insensitive substring over the
 * model id AND display name. An empty/blank query matches everything.
 */
export function matchesModelQuery(
  model: SelectableModel,
  query: string,
): boolean {
  const needle = query.trim().toLowerCase()
  if (needle === '') return true
  return model.id.toLowerCase().includes(needle)
    || model.name.toLowerCase().includes(needle)
}

/**
 * Build the dropdown options: the catalog (already in picker order) plus any
 * selected ids the catalog no longer carries, flagged stale so a saved
 * selection never silently loses an entry. Stale rows survive a non-blank
 * {@link matchesModelQuery} search only while they match too, so a search for
 * a live model does not surface unrelated stale ids.
 */
export function buildModelSelectOptions(
  catalog: readonly SelectableModel[],
  selected: readonly string[],
  query = '',
): ModelSelectOption[] {
  const catalogIds = new Set(catalog.map((model) => model.id))
  const options = catalog
    .filter((model) => matchesModelQuery(model, query))
    .map((model) => ({
      value: model.id,
      label: model.name,
      stale: false,
      ...(model.allowance === undefined ? {} : { allowance: model.allowance }),
    }))
  // Dedupe defensively (order-preserving): hand-edited settings can repeat
  // or blank an id, and duplicate Menu ids would confuse selection state.
  const seen = new Set(catalogIds)
  for (const id of selected) {
    if (id === '' || seen.has(id)) continue
    seen.add(id)
    if (catalogIds.has(id)) continue
    if (!matchesModelQuery({ id, name: id }, query)) continue
    options.push({ value: id, label: id, stale: true })
  }
  return options
}

/**
 * Group dropdown options under plan-tier headings (`tierOf` maps a model id to
 * its heading, or undefined for unmapped models — see {@link tierHeadingFor}).
 * Live rows keep their relative order and repeats merge, so a catalog
 * interleaving two tiers still renders one section per tier.
 */
export function groupModelSelectOptions(
  options: readonly ModelSelectOption[],
  tierOf: (modelId: string) => string | undefined,
): ModelSelectGroup[] {
  const groups: ModelSelectGroup[] = []
  const byHeading = new Map<string | undefined, ModelSelectGroup>()
  for (const option of options) {
    // Stale ids always render unheaded (their tier is unknowable); unmapped
    // live rows join the same trailing group so `heading: undefined`
    // appears at most once.
    const heading = option.stale ? undefined : tierOf(option.value)
    let group = byHeading.get(heading)
    if (group === undefined) {
      group = { heading, options: [] }
      byHeading.set(heading, group)
      groups.push(group)
    }
    group.options.push(option)
  }
  return groups
}

/**
 * Toggle one model id in a selection: remove it when present, append it
 * when absent (append keeps catalog order irrelevant — the picker re-sorts
 * by plan tier on render).
 */
export function toggleModelSelection(
  selected: readonly string[],
  modelId: string,
): string[] {
  return selected.includes(modelId)
    ? selected.filter((value) => value !== modelId)
    : [...selected, modelId]
}

/**
 * The catalog rows a picker may offer under the visible-models allowlist, in
 * catalog order: the whole catalog while "show all" is active (the empty
 * allowlist means exactly that), otherwise only the allowlisted ids. The
 * per-model context override editor uses this so its dropdown agrees with the
 * whitelist on the same card stack — a staged whitelist edit narrows it
 * immediately, since both read the projected page state.
 */
export function allowlistedModels<T extends SelectableModel>(
  catalog: readonly T[],
  allowlist: readonly string[],
  showAll: boolean,
): T[] {
  if (showAll) return [...catalog]
  const keep = new Set(allowlist)
  return catalog.filter((model) => keep.has(model.id))
}

/** The catalog facts the visible-models card reads (mirrors `SettingsPageState`). */
export interface CatalogReadiness {
  /** Catalog model ids the Host reported (`[]` before the first fetch lands). */
  catalogIds: readonly string[]
  /** Whether the catalog fetch failed (or the Remote is unavailable). */
  catalogFailed: boolean
}

/**
 * Whether the catalog is trustworthy enough to call an unlisted selection
 * "retired". FALSE while the first fetch is in flight, after a failure, and
 * for a loaded-but-empty catalog — an empty list makes every selected id look
 * stale, which would turn the one-click stale cleanup into a button that
 * silently empties the allowlist. Users who really want it cleared have the
 * explicit "show all" entry.
 */
export function catalogIsReady(readiness: CatalogReadiness): boolean {
  return readiness.catalogIds.length > 0 && !readiness.catalogFailed
}

/**
 * Selected ids the loaded catalog no longer carries, in selection order.
 * Callers gate user-visible "stale" affordances on {@link catalogIsReady} —
 * the list itself is informational.
 */
export function staleModelIds(
  selected: readonly string[],
  readiness: CatalogReadiness,
): string[] {
  const catalogIds = new Set(readiness.catalogIds)
  return selected.filter((id) => !catalogIds.has(id))
}
