/**
 * The plugin's own version, read from package.json at build time. The client
 * bundle inlines the JSON import (rolldown resolves it during the tsdown
 * build; node tests read it through tsx), so the rendered value always matches
 * the published package version with no second constant to keep in sync —
 * rendered as a muted footer line so a user can report the exact build.
 *
 * @module dsh-commandcode-provider/client/version
 */

import pkg from '../../package.json'

/** The published package version. */
export const PLUGIN_VERSION: string = pkg.version

/**
 * This package's GitHub releases page, derived from the repository field so
 * the update hint's link target can never drift from the published home.
 * Tolerates both repository shapes (`{ url }` and the plain string form).
 */
export const PLUGIN_RELEASES_URL: string = (() => {
  const repo: unknown = (pkg as { repository?: unknown }).repository
  const url = typeof repo === 'string' ? repo : (repo as { url?: unknown } | undefined)?.url
  return `${typeof url === 'string' ? url.replace(/^git\+/, '').replace(/\.git$/, '') : 'https://github.com/Mars-Sea/dsh-commandcode-provider'}/releases`
})()
