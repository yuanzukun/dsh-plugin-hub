/**
 * The Command Code configuration panel inside the harness Models settings page,
 * rendered through the `settings.models.provider-card` keyed slot with
 * `entryKey = 'llm-commandcode'` (the plugin's settings namespace, the key the
 * Models page dispatches for every Command Code provider row).
 *
 * The official Models page opens one editor per provider row through its own
 * 编辑 button, and for a namespace it curates no layout for (`llm-commandcode`)
 * that editor is a bare shell: a config hint over a permanently disabled apply.
 * This panel takes its place — it watches the slot outlet's siblings and, while
 * the official editor is open, hides the useless shell and shows the real
 * controls in its slot (credential/route badges, API-key field, sign-in,
 * discard/save). Closed, it renders nothing and the row looks exactly like any
 * other provider row.
 *
 * The slot's owner props (`configured`, `keyConfigured`) mirror what the Models
 * page already knows; the authoritative credential facts still come from this
 * plugin's `CommandCodeSettingsController` — shared with the dedicated settings
 * page, so the two surfaces can never disagree about whether a key is stored.
 * A controller-less render (panel mounted before the section registered its
 * inject face — the composition runs one apply) degrades to the stateless
 * registration notice. Styles ride the page stylesheet the client entry injects
 * once; the card adds no CSS of its own.
 */

import { useEffect, useRef, useState } from 'react'
import type { Translate } from '@deepseek-ai/dsh-client-ui-slots'
import { settingsWriteNotice, type SettingsCommandCodeKey } from './locales.ts'
import type { SettingsPageState, StagedField } from './settings.ts'
import type { LoginPageState } from './login.ts'
import { LoginRow } from './login-row.tsx'

/**
 * The Models-page extension slots, merged into the SlotMap with the exact
 * declarations ui-settings-models ships. The merge must stay structurally
 * identical to upstream's (kind/scope/owner), or a dsh carrying its own
 * declaration would fail the duplicate-merge check at compile time.
 */
declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface SlotMap {
    /** One provider card's adapter extension area, keyed by the row's settingsNs. */
    'settings.models.provider-card': { kind: 'keyed'; scope: 'root'; owner: ProviderCardExtrasOwnerProps }
    /** Ordered extension area after the provider rows and the add controls. */
    'settings.models.footer': { kind: 'list'; scope: 'root'; owner: ModelsFooterOwnerProps }
  }
}

/** The provider directory row as the Models page dispatches it. */
export interface ProviderDirectoryRow {
  /** The provider route id (`commandcode` for this plugin). */
  readonly provider: string
  readonly displayName: string
  /** The settings namespace the row configures (the slot's dispatch key). */
  readonly settingsNs: string
  readonly settingsPath: readonly string[]
  /** Whether the provider route is live. */
  readonly active: boolean
  /** Whether the adapter declares the route as shipped. */
  readonly declared?: boolean
}

/** Owner share of one provider-card extension occurrence (upstream's shape). */
export interface ProviderCardExtrasOwnerProps {
  /** The card's directory row. */
  readonly provider: ProviderDirectoryRow
  /** Whether any layer configures this provider (its profile resolves). */
  readonly configured: boolean
  /** The row's referenced api-key credential, confirmed configured by the page's join. */
  readonly keyConfigured: boolean
}

/** Owner share of the footer area (the section supplies nothing). */
export interface ModelsFooterOwnerProps {
  /** Marker field: footer owner props are intentionally empty. */
  children?: never
}

/** Owner props the Models page supplies at its dispatch sites. */
export type ProviderCardOwnerProps = ProviderCardExtrasOwnerProps

/**
 * The slot whose outlet anchors this panel inside the Models row — the
 * renderer's own `data-slot` attribute value, stable across builds (unlike
 * CSS-module class hashes).
 */
export const CARD_SLOT_KEY = 'settings.models.provider-card'

/** The DOM facts the sibling lookup reads (satisfied by real Elements). */
export interface SlotWrapperSiblings {
  previousElementSibling: { className: string } | null
  nextElementSibling: { className: string } | null
}

/**
 * Find the official editor card among the slot outlet's siblings, or null
 * while it is closed. The Models page renders the editor as an immediate
 * sibling of the outlet wrapper — after it in a provider row (the target of
 * the row's 编辑 toggle), before it in the first-run setup and add-provider
 * cards, where it is always open. The editor is the only such sibling whose
 * CSS module class carries the `editor` stem (`<hash>_editor`); the row header
 * and the add card's provider select never do, so the lookup needs no hash
 * knowledge.
 */
export function adjacentEditorCard(wrapper: SlotWrapperSiblings | null): { className: string } | null {
  if (wrapper === null) return null
  for (const sibling of [wrapper.previousElementSibling, wrapper.nextElementSibling]) {
    if (sibling !== null && typeof sibling.className === 'string' && sibling.className.includes('editor')) {
      return sibling
    }
  }
  return null
}

/** The closed-panel style: the outlet stays mounted as the detection anchor. */
const HIDDEN_STYLE = { display: 'none' } as const

/** Injected face the card's slot registration supplies. */
export interface CommandCodeCardProps {
  t: Translate<SettingsCommandCodeKey>
  useCommandCodeSettings<T>(selector: (state: SettingsPageState) => T): T
  useCommandCodeLogin<T>(selector: (state: LoginPageState) => T): T
  edit(field: string, text: string): void
  save(): void
  discard(): void
  refreshCredentials(): void
  beginLogin(): void
  cancelLogin(): void
}

/** The card's two postures. */
type CardMode =
  | { kind: 'registration' }
  | { kind: 'live'; ready: boolean; controllerConfigured: boolean; writable: boolean; apiKeyWritable: boolean }

/**
 * Decide the card's posture from one settings snapshot. Pure: the component
 * subscribes once and passes the snapshot in, so hook order never depends
 * on the registration→live transition. (The owner facts stay on the
 * component — only the snapshot decides the posture.)
 */
export function cardMode(
  snapshot: SettingsPageState | undefined,
): CardMode {
  if (snapshot === undefined) return { kind: 'registration' }
  return {
    kind: 'live',
    ready: snapshot.available,
    controllerConfigured: snapshot.apiKeyConfigured,
    writable: snapshot.writable,
    apiKeyWritable: snapshot.apiKeyWritable,
  }
}

/** Credential-state badge: the solid pill when set, the muted outline when not. */
function StatusBadge({ ok, okLabel, pendingLabel }: {
  ok: boolean
  okLabel: string
  pendingLabel: string
}) {
  return <span className={ok ? 'cc-badge' : 'cc-badgeMuted'}>{ok ? okLabel : pendingLabel}</span>
}

/** The key paste field, with the show/hide toggle over it. */
function CardKeyField({ state, disabled, t, onEdit }: {
  state: StagedField
  disabled: boolean
  t: Translate<SettingsCommandCodeKey>
  onEdit(text: string): void
}) {
  const [visible, setVisible] = useState(false)
  return (
    <div className="cc-field">
      <div className="cc-fieldHead">
        <label className="cc-label" htmlFor="cc-card-api-key">{t('apiKey')}</label>
        <span className="cc-badges">
          <button type="button" className="cc-reset" disabled={disabled} onClick={() => setVisible((value) => !value)}>
            {visible ? t('hide') : t('show')}
          </button>
        </span>
      </div>
      <input
        id="cc-card-api-key"
        className="cc-input"
        type={visible ? 'text' : 'password'}
        autoComplete="new-password"
        spellCheck={false}
        value={state.text}
        disabled={disabled}
        onChange={(event) => onEdit(event.target.value)}
      />
      <p className="cc-hint">{t('apiKeyHint')}</p>
    </div>
  )
}

/**
 * The slot component body. Dispatched on every Command Code provider card of
 * the Models page (saved row, first-run setup posture, add-provider draft).
 *
 * Closed (the official 编辑 toggle off) it renders nothing: the row head the
 * Models page owns already names the provider and shows the credential dot, so
 * a page full of providers stays compact. Open, it hides that editor shell and
 * shows the real controls — badges, API-key field, sign-in, discard/save.
 */
export function CommandCodeProviderCard(props: CommandCodeCardProps & ProviderCardOwnerProps) {
  const { t } = props
  // Single subscription: the whole snapshot drives posture + body together.
  const state = props.useCommandCodeSettings !== undefined
    ? props.useCommandCodeSettings((snapshot) => snapshot)
    : undefined
  const mode = cardMode(state)
  const login = props.useCommandCodeLogin !== undefined
    ? props.useCommandCodeLogin((snapshot) => snapshot)
    : undefined
  const dirty = state?.dirty ?? false
  const saving = state?.saving ?? false
  const invalid = state?.invalid ?? false
  const notice = settingsWriteNotice(state?.saveResult, t) || (state?.failed ? t('saveFailed') : '')
  const savingBlocked = !dirty || invalid
  const configured = mode.kind === 'live' && mode.ready ? mode.controllerConfigured : props.keyConfigured
  const disabled = mode.kind === 'live' && (!mode.writable || (state !== undefined && !mode.apiKeyWritable))
  const showBody = mode.kind === 'live' && mode.ready && state !== undefined
  // The official editor's open state lives in the Models page's own component
  // state and never reaches this slot's props; the outlet wrapper is the stable
  // neighbor, so watch ITS siblings for the editor's mount/unmount. The outlet
  // stays mounted either way — it is the observation anchor — so the closed
  // panel hides its own root instead of unmounting.
  const rootRef = useRef<HTMLDivElement | null>(null)
  const [editorOpen, setEditorOpen] = useState(false)
  useEffect(() => {
    const root = rootRef.current
    if (root === null || typeof MutationObserver === 'undefined') return
    const wrapper = root.closest(`[data-slot="${CARD_SLOT_KEY}"]`) ?? root.parentElement
    if (wrapper === null) return
    const row = wrapper.parentElement
    if (row === null) return
    let hiddenEditor: HTMLElement | null = null
    const sync = () => {
      const editor = adjacentEditorCard(wrapper) as HTMLElement | null
      setEditorOpen(editor !== null)
      if (editor !== null) {
        // React pins no inline style on the editor shell, so this survives the
        // shell's own re-renders; a shell that unmounts and remounts is
        // re-hidden by the next observation.
        editor.style.display = 'none'
        hiddenEditor = editor
      }
    }
    sync()
    const observer = new MutationObserver(sync)
    observer.observe(row, { childList: true })
    return () => {
      observer.disconnect()
      // If the shell outlives the panel (plugin reload), give it back: it is
      // the honest fallback face again.
      if (hiddenEditor !== null) hiddenEditor.style.display = ''
    }
  }, [])
  return (
    <div
      ref={rootRef}
      className="cc-providerCard"
      data-cc-models-card="true"
      style={editorOpen ? undefined : HIDDEN_STYLE}
    >
      {editorOpen && mode.kind === 'registration' ? <p className="cc-hint">{t('cardRegistrationHint')}</p> : null}
      {editorOpen && mode.kind === 'live' && !mode.ready ? <p className="cc-hint">{t('cardLoadingHint')}</p> : null}
      {editorOpen && showBody ? (
        <>
          <div className="cc-field">
            <div className="cc-fieldHead">
              <span className="cc-label">{t('cardTitle')}</span>
              <span className="cc-badges">
                <StatusBadge ok={configured} okLabel={t('apiKeySet')} pendingLabel={t(state.apiKeyKnown ? 'apiKeyUnset' : 'writeStateUnknown')} />
                {props.provider.active ? <span className="cc-badge">{t('cardRouteActive')}</span> : null}
              </span>
            </div>
          </div>
          <CardKeyField
            state={state.apiKey}
            disabled={disabled}
            t={t}
            onEdit={(text) => props.edit('apiKey', text)}
          />
          {login !== undefined ? (
            <LoginRow
              state={login}
              disabled={disabled}
              t={t}
              onBegin={props.beginLogin}
              onCancel={props.cancelLogin}
            />
          ) : null}
          <div className="cc-footer">
            {notice ? <p className="cc-failed" role="status">{notice}</p> : null}
            {state?.credentialRefreshFailed || state?.saveResult?.refreshFailed ? <button type="button" className="cc-reset" onClick={props.refreshCredentials}>{t('writeRefreshRetry')}</button> : null}
            <button
              type="button"
              className="cc-reset"
              disabled={(!dirty && !state?.failed) || saving}
              onClick={props.discard}
            >
              {t('discard')}
            </button>
            <button
              type="button"
              className="cc-reset"
              disabled={savingBlocked || saving}
              onClick={props.save}
            >
              {t(saving ? 'saving' : 'save')}
            </button>
          </div>
        </>
      ) : null}
    </div>
  )
}
