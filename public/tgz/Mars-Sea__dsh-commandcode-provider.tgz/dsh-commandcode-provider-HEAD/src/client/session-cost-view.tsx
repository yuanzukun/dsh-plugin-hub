/**
 * The composer's live session-cost figure (browser half).
 *
 * This component renders NO surface of its own: the cost lives inside the
 * harness's own token-usage UI, the amount as the last item of the shipped
 * pill's text run (`1.2M tokens · Cache hit 87% · $0.0123`) and the breakdown as
 * extra rows in the usage dialog that pill opens. `./session-cost-display.ts`
 * owns that injection and `./session-cost.ts` every number and string; this file
 * owns the two seats the figures come from and the injection's lifetime.
 *
 * It is registered in `conversation.composer.dock` because that registration is
 * what delivers the seats: `useProjection` is a standard prop the composer hands
 * every dock occupant, and registering under the shipped `stats` cell's id would
 * REPLACE the harness's readout instead of extending it.
 *
 * The rendered node is a hidden marker — `display:none`, so it adds neither a box
 * nor a flex gap. It locates THIS composer from the entry (`closest()` on the
 * dock's outlet anchor), so a session-scoped composer reads its own card rather
 * than whichever row comes first, and it renders only while there is something
 * to show.
 *
 * Two seats are read, from two different owners: `useProjection` comes from the
 * composer (a standard prop, not part of this registration) and
 * `useCommandCodePrices` from our own `inject` face. Reading `props.hooks.*`
 * instead finds `undefined` at runtime and crashes the render, which the slot
 * renderer contains by ABDICATING the entry — a surface that vanishes with no
 * visible error. Both effects are `useEffect`, never `useLayoutEffect`: there is
 * nothing on screen to align with, and a layout effect would warn from the
 * server render the tests use.
 *
 * @module dsh-commandcode-provider/client/session-cost-view
 */

import type { SessionCostFacts } from '../cost-facts.ts'
import { useEffect, useRef } from 'react'
import type { SnapshotStore } from './snapshot-store.ts'
import type { SessionCostPricesState } from './prices.ts'
import { SessionCostDisplay } from './session-cost-display.ts'
import {
  buildSessionCostView,
  type SessionModelSelectionProjection,
  type SessionUsageBuckets,
} from './session-cost.ts'

/**
 * The dock outlet this entry renders inside, i.e. what it scopes itself from.
 *
 * The OUTLET, not its parent. The outlet is one `display:contents` div holding
 * exactly this slot's entries (the shipped `stats` cell and ours), so it is the
 * narrowest container that is still per-composer. Its parent is NOT: from
 * 0.1.6-alpha.2 the composer stacks the dock inside a footer that also holds the
 * `ContextMeter`, whose trigger is another `button[aria-haspopup="dialog"]`
 * rendered after the dock — scoping to the parent would let the cost land on the
 * context ring.
 */
const DOCK_ANCHOR = '[data-slot="conversation.composer.dock"]'

/** Module-level constant so the marker's `style` prop never diffs. */
const HIDDEN_STYLE = { display: 'none' } as const

/**
 * The injected face this registration carries. Bound by the client entry so the
 * component stays unaware of the Remote, the controller, and its caching.
 *
 * NOTE the split from {@link SessionCostComponentProps}: the renderer
 * destructures this face's `hooks` compartment and re-exposes each member as a
 * `use<Name>` prop (`commandCodePrices` → `useCommandCodePrices`); it does not
 * hand the component this object verbatim.
 */
export interface SessionCostInjected {
  hooks: {
    commandCodePrices: SnapshotStore<SessionCostPricesState>
  }
}

/**
 * The projection keys this readout reads, declared structurally because the
 * plugin bundle does not depend on the session-controller package (whose
 * `UseProjection` this mirrors).
 */
interface ProjectionSeats {
  commandCodeCost: SessionCostFacts
  tokenUsage: SessionUsageBuckets
  modelSelection: SessionModelSelectionProjection
}

/** The projection reader the composer supplies to every dock occupant. */
export interface UseProjectionLike {
  <K extends keyof ProjectionSeats>(key: K): ProjectionSeats[K] | undefined
  <K extends keyof ProjectionSeats, S>(
    key: K,
    selector: (value: ProjectionSeats[K] | undefined) => S,
    eq?: (a: S, b: S) => boolean,
  ): S
}

/** The props this component actually receives. */
export interface SessionCostComponentProps {
  useCommandCodePrices<T>(selector: (state: SessionCostPricesState) => T): T
  useProjection: UseProjectionLike
}

/** Log a missing seat once per page, so a silent no-op stays diagnosable. */
let warnedMissingSeat = false

/**
 * The composer's session-cost entry. Guards the two seats before rendering the
 * mount: a dsh that does not supply the projection seat to dock occupants gets
 * an absent cost and one console line, never a render crash — which the renderer
 * would answer by abdicating the entry with no visible trace.
 */
export function CommandCodeSessionCost(props: SessionCostComponentProps) {
  if (typeof props.useProjection !== 'function' || typeof props.useCommandCodePrices !== 'function') {
    if (!warnedMissingSeat) {
      warnedMissingSeat = true
      console.error(
        '[dsh-commandcode-provider] the composer does not supply the projection/hook seats the session-cost readout needs; the readout stays hidden',
      )
    }
    return null
  }
  return <SessionCostEntry {...props} />
}

/** The mount: one injection lifetime, one hidden marker. Every hook lives here. */
function SessionCostEntry(props: SessionCostComponentProps) {
  const markerRef = useRef<HTMLSpanElement | null>(null)
  const displayRef = useRef<SessionCostDisplay | null>(null)
  const prices = props.useCommandCodePrices((state) => state)
  const usage = props.useProjection('tokenUsage')
  const selection = props.useProjection('modelSelection')
  const facts = props.useProjection('commandCodeCost')
  const view = buildSessionCostView({ usage, selection, facts, table: prices.table, now: Date.now() })

  useEffect(() => {
    // No DOM outside a browser: the server render used by the tests, and a
    // node-hosted assembly, must both stay no-ops.
    if (typeof document === 'undefined') return
    const display = new SessionCostDisplay({
      doc: document,
      scope: () => markerRef.current?.closest(DOCK_ANCHOR) ?? null,
    })
    displayRef.current = display
    display.start()
    return () => {
      displayRef.current = null
      display.dispose()
    }
  }, [])

  // Every render: the projection is a fresh fold, so there is nothing cheaper to
  // compare than the plan the display derives from it — and the display rewrites
  // a node only when that node's own text actually moved.
  useEffect(() => {
    displayRef.current?.sync(view)
  })

  if (view === undefined) return null
  return <span ref={markerRef} style={HIDDEN_STYLE} data-ccp-session-cost-anchor="" />
}
