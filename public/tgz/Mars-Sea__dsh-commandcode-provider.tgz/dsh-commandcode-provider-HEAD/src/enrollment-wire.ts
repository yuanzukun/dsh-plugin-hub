/** 账号开通的双方使用契约。状态和恢复记录不携带密钥，密钥只出现在手动开通输入。 */
import type { InvocationDescriptor, TypertRemoteContribution, TypertSchema } from '@deepseek-ai/dsh-typert-protocol'
import { makeBoundaryValidator, makeRemoteDescriptor, makeStrictCodec, REMOTE_PACKAGE } from './wire-shared.ts'

export interface EnrollmentInput {
  id: string
  pageId: string
  mode: 'browser' | 'manual'
  label: string
  /** 用户未填写名称时，允许使用浏览器登录返回的账号名。 */
  automaticName: boolean
  key?: string
}
export type EnrollmentPhase = 'creating' | 'waiting' | 'writing' | 'naming' | 'finished' | 'cancelling' | 'cancelled' | 'failed' | 'cleanup-needed'
/**
 * 账号开通状态的语义消息键。
 *
 * 状态消息传键而不是成品文案：界面语言由浏览器侧持有，宿主没有立场去猜；同一条状态
 * 要在中文与英文界面下各自显示，而 `phase` 不足以唯一确定它——`naming` 既有「正在
 * 保存名称」也有「名称保存失败」，`cleanup-needed` 既有「收尾未完成」也有「清理未
 * 完成」，`cancelled` 既有「已取消」也有「已取消并清理」。客户端拿这些键走 `t()`
 * 渲染，不必再匹配自由文本；`SettingsCommandCodeKey` 收录本类型，因此新增键漏写
 * 中文或英文字典都会被类型检查拦下。
 *
 * 其中十五条由宿主产出（`src/enrollment.ts`），`enrollmentCleanupPending` 也在此列——
 * 它在「收尾未完成」时由宿主与页面两侧共用同一个键；另外七条是浏览器侧控制器的专属键
 * （`src/client/enrollment.ts`），只在传输失败或连接断开时由该侧自己产出。宿主抛出的
 * 异常消息不在此列：它们不上屏，客户端在所有失败路径都用自己这一侧的文案覆盖。
 */
export type EnrollmentMessageKey =
  | 'enrollmentCreating'
  | 'enrollmentWaiting'
  | 'enrollmentWriting'
  | 'enrollmentNaming'
  | 'enrollmentNameFailed'
  | 'enrollmentFinished'
  | 'enrollmentCancelling'
  | 'enrollmentCancelled'
  | 'enrollmentCancelledCleaned'
  | 'enrollmentFailed'
  | 'enrollmentFailedCleaned'
  | 'enrollmentCleanupPending'
  | 'enrollmentCleanupFailed'
  | 'enrollmentRecordNaming'
  | 'enrollmentRecordCleanup'
  | 'enrollmentBeginFailed'
  | 'enrollmentCancelUnconfirmed'
  | 'enrollmentNameRequestFailed'
  | 'enrollmentCleanupRequestFailed'
  | 'enrollmentDisconnected'
  | 'enrollmentHostUnavailable'
  | 'enrollmentStatusUnavailable'
export const ENROLLMENT_MESSAGE_KEYS = [
  'enrollmentCreating', 'enrollmentWaiting', 'enrollmentWriting', 'enrollmentNaming', 'enrollmentNameFailed',
  'enrollmentFinished', 'enrollmentCancelling', 'enrollmentCancelled', 'enrollmentCancelledCleaned', 'enrollmentFailed',
  'enrollmentFailedCleaned', 'enrollmentCleanupPending', 'enrollmentCleanupFailed', 'enrollmentRecordNaming', 'enrollmentRecordCleanup',
  'enrollmentBeginFailed', 'enrollmentCancelUnconfirmed', 'enrollmentNameRequestFailed', 'enrollmentCleanupRequestFailed',
  'enrollmentDisconnected', 'enrollmentHostUnavailable', 'enrollmentStatusUnavailable',
] as const satisfies readonly EnrollmentMessageKey[]
/**
 * 键表必须覆盖 {@link EnrollmentMessageKey} 的每一个成员。
 *
 * `satisfies` 只保证数组里不出现类型以外的键，**漏写一项它不会报错**——而漏写的后果
 * 不是少一条文案：`parseEnrollmentState` 会拒绝该键，`enrollmentPending` 的整张表随之
 * 被拒，对应的恢复记录从界面静默消失。所以补一个反方向的编译期断言：数组比类型少时
 * `Exclude` 不为 `never`，这里的 `= true` 直接编译失败。
 */
export const ENROLLMENT_MESSAGE_KEYS_ARE_COMPLETE:
  Exclude<EnrollmentMessageKey, (typeof ENROLLMENT_MESSAGE_KEYS)[number]> extends never ? true : never = true
export interface EnrollmentState {
  id: string
  ref: string
  phase: EnrollmentPhase
  /** 要显示的语义键；文案由浏览器侧按界面语言渲染，见 {@link EnrollmentMessageKey}。 */
  messageKey: EnrollmentMessageKey
  authUrl?: string
  suggestedName?: string
}
/** 配置中的恢复日志：先登记，再写凭据；只保留引用与阶段，不保留密钥或连接身份。 */
export interface EnrollmentRecord {
  id: string
  ref: string
  phase: 'pending' | 'naming' | 'cleanup'
  label: string
}
const guard = makeBoundaryValidator('commandcode/enrollment')
const phases: readonly EnrollmentPhase[] = ['creating', 'waiting', 'writing', 'naming', 'finished', 'cancelling', 'cancelled', 'failed', 'cleanup-needed']
export function parseEnrollmentState(value: unknown): EnrollmentState {
  const source = guard.record(value, 'state')
  const phase = source.phase
  if (!phases.includes(phase as EnrollmentPhase)) return guard.reject('phase')
  const messageKey = source.messageKey
  if (!ENROLLMENT_MESSAGE_KEYS.includes(messageKey as EnrollmentMessageKey)) return guard.reject('messageKey')
  const state: EnrollmentState = {
    id: guard.stringField(source, 'id', 'id'), ref: guard.stringField(source, 'ref', 'ref'),
    phase: phase as EnrollmentPhase, messageKey: messageKey as EnrollmentMessageKey,
  }
  for (const field of ['authUrl', 'suggestedName'] as const) {
    if (source[field] !== undefined) state[field] = guard.stringField(source, field, field)
  }
  return state
}
export function parseEnrollmentInput(value: unknown): EnrollmentInput {
  const source = guard.record(value, 'input')
  const id = guard.stringField(source, 'id', 'id')
  if (!/^[a-zA-Z0-9-]{16,80}$/.test(id)) return guard.reject('id')
  if (source.mode !== 'browser' && source.mode !== 'manual') return guard.reject('mode')
  const input: EnrollmentInput = {
    id, pageId: parsePage(source).pageId, mode: source.mode, label: guard.stringField(source, 'label', 'label').trim(),
    automaticName: guard.booleanField(source, 'automaticName', 'automaticName'),
  }
  if (!input.label || input.label.length > 200) return guard.reject('label')
  if (input.mode === 'manual') {
    input.key = guard.stringField(source, 'key', 'key').trim()
    if (!input.key) return guard.reject('key')
  } else if (source.key !== undefined) return guard.reject('key')
  return input
}
export interface EnrollmentPage { pageId: string }
function parsePage(value: unknown): EnrollmentPage {
  const source = guard.record(value, 'page')
  const pageId = guard.stringField(source, 'pageId', 'pageId')
  if (!/^[a-zA-Z0-9-]{16,80}$/.test(pageId)) return guard.reject('pageId')
  return { pageId }
}
export interface EnrollmentAction extends EnrollmentPage { id: string; name?: string }
const actionSchema: TypertSchema<EnrollmentAction> = {
  parse(value) {
    const source = guard.record(value, 'action')
    const action: EnrollmentAction = { id: guard.stringField(source, 'id', 'id'), ...parsePage(source) }
    if (!/^[a-zA-Z0-9-]{16,80}$/.test(action.id)) return guard.reject('id')
    if (source.name !== undefined) action.name = guard.stringField(source, 'name', 'name').trim()
    if (action.name !== undefined && (!action.name || action.name.length > 200)) return guard.reject('name')
    return action
  },
}
const stateSchema = { parse: parseEnrollmentState }
const listSchema: TypertSchema<EnrollmentState[]> = {
  parse(value) { return Array.isArray(value) ? value.map(parseEnrollmentState) : guard.reject('list') },
}
export const ENROLLMENT_DESCRIPTORS: readonly InvocationDescriptor[] = [
  ...['enrollmentBegin', 'enrollmentStatus', 'enrollmentCancel', 'enrollmentName', 'enrollmentRetry'].map((method) => ({
    ...makeRemoteDescriptor(`commandcode/${method}`, method, `${REMOTE_PACKAGE}#EnrollmentState`, stateSchema),
    parameters: [{ name: 'input', wire: 'input', source: 'json' as const,
      codec: makeStrictCodec(`${REMOTE_PACKAGE}#${method}Input`, method === 'enrollmentBegin' ? { parse: parseEnrollmentInput } : actionSchema) }],
  })),
  { ...makeRemoteDescriptor('commandcode/enrollmentPending', 'enrollmentPending', `${REMOTE_PACKAGE}#EnrollmentStateList`, listSchema),
    parameters: [{ name: 'input', wire: 'input', source: 'json', codec: makeStrictCodec(`${REMOTE_PACKAGE}#EnrollmentPage`, { parse: parsePage }) }] },
  { ...makeRemoteDescriptor('commandcode/enrollmentWatch', 'enrollmentWatch', `${REMOTE_PACKAGE}#EnrollmentReady`, {
      parse(value: unknown) { return value === true ? true : guard.reject('ready') },
    }), mode: 'stream',
    parameters: [{ name: 'input', wire: 'input', source: 'json', codec: makeStrictCodec(`${REMOTE_PACKAGE}#EnrollmentPage`, { parse: parsePage }) }] },
]
export const ENROLLMENT_REMOTE_CONTRIBUTION: TypertRemoteContribution = { package: REMOTE_PACKAGE, descriptors: ENROLLMENT_DESCRIPTORS }
