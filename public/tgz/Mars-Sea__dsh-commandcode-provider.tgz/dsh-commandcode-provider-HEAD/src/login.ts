/**
 * Host half of the Command Code browser login (the loopback flow), mirroring
 * what the official `command-code login` CLI command performs.
 *
 * 1. Bind a temporary HTTP server on `127.0.0.1`, first available port from
 *    5959 upward (10 attempts).
 * 2. Generate a random state token and open
 *    `{studio}/studio/auth/cli?callback=http://localhost:{port}/callback&state={state}`.
 * 3. After the user signs in, the Studio page POSTs the credentials JSON
 *    `{ apiKey, state, userId, userName, keyName }` to the loopback callback —
 *    no OAuth code exchange, the page holds the final API key.
 * 4. The delivered key is validated against `GET {apiBase}/alpha/whoami`
 *    before anything is stored.
 *
 * The server contract is CLI-mirrored: POST-only `/callback`, a 10 KB body
 * cap, JSON responses (`{success:true}` / `{success:false,error}`), and
 * state-token equality as the anti-forgery check. Three deliberate hardenings
 * over the CLI build: the CORS origin is echoed only when allowlisted (the
 * CLI falls back to the first origin), `Connection: close`, and the denial
 * branch checks the state token before it ends the attempt.
 *
 * Storage stays out of this module: the plugin entry supplies
 * {@link CommandCodeLoginFlowDeps.storeKey}, which writes through the dsh
 * credentials seam so the next request resolves the new key with no restart.
 * Everything external (fetch, ports, randomness, timing) is injectable for
 * node tests; the tests drive a real loopback server end to end.
 *
 * @module dsh-commandcode-provider/login
 */

import { createServer as createHttpServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http'
import { createServer as createNetServer } from 'node:net'
import { randomBytes } from 'node:crypto'
import { DEFAULT_API_BASE } from './adapter.ts'
import { IDENTITY_ENCODING_HEADER } from './response-encoding.ts'
import type { CommandCodeLoginFailureReason, CommandCodeLoginStatus } from './login-wire.ts'

/** 登录总期限包含浏览器回调、密钥验证与存储，不能在收到回调后撤掉保护。 */
export const LOGIN_TIMEOUT_MS = 120_000

/** First local port the flow tries (mirrors the CLI). */
export const LOGIN_START_PORT = 5959

/** How many consecutive ports to try from {@link LOGIN_START_PORT}. */
export const LOGIN_MAX_PORT_ATTEMPTS = 10

/** Reject callback bodies larger than this (mirrors the CLI). */
export const LOGIN_BODY_LIMIT_BYTES = 10_000

/** The Studio origins allowed to POST credentials to the loopback server. */
export const LOGIN_ALLOWED_ORIGINS: readonly string[] = [
  'http://localhost:3000',
  'https://staging.commandcode.ai',
  'https://commandcode.ai',
]

/** The Studio route that performs the browser-side login. */
const STUDIO_AUTH_PATH = '/studio/auth/cli'

/** Credentials as delivered by the Studio's callback POST. */
export interface CommandCodeLoginCredentials {
  apiKey: string
  userId: string
  userName: string
  keyName: string
}

/** Outcome of validating a delivered key against `/alpha/whoami`. */
export type ApiKeyValidation =
  | { valid: true }
  | { valid: false; error: 'invalid_key' | 'server_error' | 'network_error' }

export interface CommandCodeLoginFlowDeps {
  /**
   * The Provider API base used for `/alpha/whoami` validation; also selects
   * the matching Studio base (staging api → staging studio). A thunk is fine:
   * it is re-read when each attempt starts, so a settings change reaches the
   * next login. Defaults to the public API base.
   */
  apiBase?: string | (() => string | undefined)
  /** Attempt timeout in millis; defaults to {@link LOGIN_TIMEOUT_MS}. */
  timeoutMs?: number
  /** First port to try; defaults to {@link LOGIN_START_PORT}. */
  startPort?: number
  /** Consecutive-port attempts; defaults to {@link LOGIN_MAX_PORT_ATTEMPTS}. */
  maxPortAttempts?: number
  /** Validation fetch seam; defaults to global `fetch`. */
  fetchImpl?: typeof fetch
  /** Randomness seam; defaults to `node:crypto` randomBytes(32) base64url. */
  randomToken?: (byteLength: number) => string
  /**
   * Receives the validated credentials after a successful login. Rejecting
   * fails the attempt with `unavailable`.
   */
  storeKey(credentials: CommandCodeLoginCredentials, targetRef?: string): Promise<void>
  /** Reject an account target that is not a saved slot before opening Studio. */
  validateTargetRef?(targetRef: string | undefined): void
}

/** Resolve a browser-login destination without allowing arbitrary credential writes. */
export function loginCredentialRef(
  targetRef: string | undefined,
  defaultRef: string,
  accounts: readonly { apiKeyEnv?: string }[],
): string {
  if (targetRef === undefined) return defaultRef
  if (targetRef === defaultRef || !accounts.some((account) => account.apiKeyEnv === targetRef)) {
    throw new Error('the target account must be saved before browser sign-in')
  }
  return targetRef
}

/** Compose the Studio authorization URL (pure, exported for tests). */
export function buildCommandAuthUrl(options: { studioBase: string; port: number; state: string }): string {
  const callback = `http://localhost:${options.port}/callback`
  return `${options.studioBase}${STUDIO_AUTH_PATH}?callback=${encodeURIComponent(callback)}&state=${encodeURIComponent(options.state)}`
}

/** Map an API base onto the Studio base the CLI pairs it with. */
export function studioBaseForApiBase(apiBase: string): string {
  if (/^https:\/\/staging-api\.commandcode\.ai/i.test(apiBase)) return 'https://staging.commandcode.ai'
  if (/^http:\/\/localhost(:\d+)?$/i.test(apiBase)) return 'http://localhost:3000'
  return 'https://commandcode.ai'
}

/**
 * Validate one candidate key against `/alpha/whoami` (pure, exported for
 * tests). Mirrors the CLI's verdicts: 401 → invalid_key, other non-OK →
 * server_error, transport failure → network_error.
 */
export async function validateCommandApiKey(
  fetchImpl: typeof fetch,
  apiBase: string,
  apiKey: string,
  signal?: AbortSignal,
): Promise<ApiKeyValidation> {
  try {
    const response = await fetchImpl(`${apiBase}/alpha/whoami`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json', ...IDENTITY_ENCODING_HEADER, Authorization: `Bearer ${apiKey}` },
      ...(signal === undefined ? {} : { signal }),
    })
    // 身份验证只用状态码，及时释放不再使用的正文连接。
    void response.body?.cancel().catch(() => undefined)
    if (response.status === 401) return { valid: false, error: 'invalid_key' }
    if (response.ok) return { valid: true }
    return { valid: false, error: 'server_error' }
  } catch {
    return { valid: false, error: 'network_error' }
  }
}

/** Whether one loopback port is free right now. */
function checkPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const probe = createNetServer()
    probe.once('error', () => resolve(false))
    probe.once('listening', () => probe.close(() => resolve(true)))
    probe.listen(port, '127.0.0.1')
  })
}

/** Whether a callback body carries every credential field the CLI requires. */
function isCallbackCredentials(value: unknown): value is CommandCodeLoginCredentials & Record<string, unknown> {
  if (typeof value !== 'object' || value === null) return false
  const record = value as Record<string, unknown>
  return typeof record.apiKey === 'string' && record.apiKey !== ''
    && typeof record.state === 'string'
    && typeof record.userId === 'string'
    && typeof record.userName === 'string'
    && typeof record.keyName === 'string'
}

/**
 * One browser-login attempt machine. Single-flight by design: `begin()` while
 * waiting returns the live attempt's status instead of starting a second one;
 * a start that is still binding its port is REJOINED through
 * {@link CommandCodeLoginFlow.begin}'s in-flight promise, because the status
 * face cannot say `waiting` until that bind settles; a terminal state makes the
 * next `begin()` start fresh.
 */
export class CommandCodeLoginFlow {
  private readonly deps: CommandCodeLoginFlowDeps
  private readonly listeners = new Set<() => void>()

  private statusValue: CommandCodeLoginStatus = { state: 'idle' }
  private server: Server | undefined
  private timer: ReturnType<typeof setTimeout> | undefined
  private attemptAbort: AbortController | undefined
  /** Settle hooks of the live attempt's callback promise. */
  private settle: {
    resolve(credentials: CommandCodeLoginCredentials): void
    reject(failure: LoginSettleError): void
  } | undefined
  /**
   * Attempt generation. A delivered callback keeps validating the key
   * asynchronously (`complete()`), and that window is open to a cancel or a
   * fresh `begin()`; the generation lets a late completion recognize that it
   * no longer owns the status face and stop instead of storing a credential
   * the user cancelled.
   */
  private attemptSeq = 0
  /**
   * The start currently binding a port, if any. Every `begin()` arriving before
   * it settles joins it: two independent starts would each bind a loopback
   * server, and only the LAST one is reachable by `teardown()` — the orphan
   * keeps answering `/callback` for the process's lifetime, and ten of them
   * exhaust the port window so browser login dies until the Host restarts.
   */
  private starting: Promise<CommandCodeLoginStatus> | undefined
  /** A live attempt's destination; different rows may not rejoin it. */
  private targetRef: string | undefined
  /** A `cancel()` that arrived while a start was still binding (see {@link CommandCodeLoginFlow.cancel}). */
  private cancelPending = false
  /** 取消只能阻止尚未发出的写入；补偿者须等这些实际存储任务结束。 */
  private readonly pendingStores = new Set<Promise<void>>()
  private disposed = false

  constructor(deps: CommandCodeLoginFlowDeps) {
    this.deps = deps
  }

  /** Subscribe to state transitions. @returns the disposer. */
  onChange(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  /** The current attempt's status face. */
  status(): CommandCodeLoginStatus {
    return this.statusValue
  }

  /**
   * Start an attempt (or rejoin the live one) and resolve with its status —
   * `waiting` carrying the Studio URL once the loopback server is up.
   * Rejects only when the flow cannot start at all (no free port, disposed).
   */
  async begin(targetRef?: string): Promise<CommandCodeLoginStatus> {
    if (this.disposed) throw new Error('login flow has been disposed')
    this.deps.validateTargetRef?.(targetRef)
    // Rejoin only a live attempt. A `waiting` status whose server is already
    // torn down means the callback was consumed and the key is being
    // validated: that attempt can no longer receive anything, so handing its
    // dead authUrl back would give the user a link to a closed port. Starting
    // fresh retires it (the generation check drops its late completion).
    if (this.statusValue.state === 'waiting' && this.server !== undefined) {
      if (this.targetRef !== targetRef) throw new Error('another account login is already in progress')
      return this.statusValue
    }
    // ...and rejoin a start that has not published `waiting` yet — see `starting`.
    if (this.starting !== undefined) {
      if (this.targetRef !== targetRef) throw new Error('another account login is already in progress')
      return this.starting
    }
    this.cancelPending = false
    this.targetRef = targetRef
    const starting = this.startAttempt(targetRef)
    this.starting = starting
    try {
      return await starting
    } finally {
      if (this.starting === starting) this.starting = undefined
    }
  }

  /**
   * The binding half of {@link CommandCodeLoginFlow.begin}: one attempt, one
   * server, one published `waiting` status. Callers reach it only through
   * `begin()`'s single-flight fence.
   */
  private async startAttempt(targetRef: string | undefined): Promise<CommandCodeLoginStatus> {
    this.teardown()
    const attempt = ++this.attemptSeq
    this.attemptAbort = new AbortController()

    const port = await this.findPort()
    const expectedState = this.deps.randomToken?.(32) ?? randomBytes(32).toString('base64url')

    // The attempt settles exactly once: fulfilled with delivered credentials,
    // rejected with a tagged failure the mapping below turns into copy.
    const settled = new Promise<CommandCodeLoginCredentials>((resolve, reject) => {
      this.settle = { resolve, reject }
    })
    // A bind failure must surface before the attempt reports `waiting`.
    await this.bindServer(port, expectedState)

    // The attempt may have been retired while the port was being bound: a
    // `cancel()` or a `dispose()` can arrive before any `waiting` status is
    // visible. Publishing one now would hand the user a live authUrl they
    // already asked to drop, so the freshly bound server is closed here.
    if (this.disposed || this.cancelPending) {
      const cancelled = !this.disposed
      this.cancelPending = false
      this.teardown()
      if (cancelled) this.setStatus({ state: 'failed', reason: 'cancelled' })
      return this.statusValue
    }

    const apiBase = this.readApiBase()
    this.setStatus({
      state: 'waiting',
      authUrl: buildCommandAuthUrl({ studioBase: studioBaseForApiBase(apiBase), port, state: expectedState }),
    })

    // 回调成功只关闭监听服务，验证期间继续使用同一总期限。
    this.timer = setTimeout(() => {
      if (!this.ownsAttempt(attempt)) return
      this.teardown()
      this.setStatus({
        state: 'failed',
        reason: 'timeout',
        message: '登录未在规定时间内完成，请重试。',
      })
    }, this.deps.timeoutMs ?? LOGIN_TIMEOUT_MS)
    this.timer.unref?.()

    void settled.then(
      (credentials) => this.complete(attempt, credentials, targetRef),
      (failure) => this.failFrom(attempt, failure),
    )
    return this.statusValue
  }

  /**
   * Cancel a waiting attempt; terminal states are untouched. A start that is
   * still binding a port is flagged instead of ignored — it cannot be torn
   * down from here (its server does not exist yet), so `startAttempt` observes
   * the flag once the bind settles and retires it.
   */
  cancel(): void {
    if (this.disposed) return
    if (this.statusValue.state === 'waiting') {
      this.teardown()
      this.setStatus({ state: 'failed', reason: 'cancelled' })
      return
    }
    if (this.starting !== undefined) this.cancelPending = true
  }

  /** 结束验证/监听并等待已开始的写入，供账号开通过程安全补偿。 */
  async cancelAndDrain(): Promise<void> {
    this.cancel()
    await this.starting?.catch(() => undefined)
    this.cancel()
    await Promise.allSettled([...this.pendingStores])
  }

  /** Stop everything; a waiting attempt ends cancelled. Idempotent. */
  dispose(): void {
    if (this.disposed) return
    this.disposed = true
    this.cancelPending = false
    const wasWaiting = this.statusValue.state === 'waiting'
    this.teardown()
    if (wasWaiting) this.setStatus({ state: 'failed', reason: 'cancelled' })
  }

  private readApiBase(): string {
    const raw = typeof this.deps.apiBase === 'function' ? this.deps.apiBase() : this.deps.apiBase
    return raw ?? DEFAULT_API_BASE
  }

  private setStatus(next: CommandCodeLoginStatus): void {
    this.statusValue = next
    for (const listener of [...this.listeners]) listener()
  }

  /** First free port among the consecutive candidates. */
  private async findPort(): Promise<number> {
    const startPort = this.deps.startPort ?? LOGIN_START_PORT
    const attempts = this.deps.maxPortAttempts ?? LOGIN_MAX_PORT_ATTEMPTS
    for (let index = 0; index < attempts; index += 1) {
      const candidate = startPort + index
      if (await checkPortAvailable(candidate)) return candidate
    }
    throw new Error(`No available port found after ${attempts} attempts starting from port ${startPort}`)
  }

  /**
   * Bind the attempt's loopback server, resolving when the port is live.
   * Pre-bind failures reject (surfacing from `begin()`); a later server error
   * settles the live attempt as a tagged failure instead.
   */
  private bindServer(port: number, expectedState: string): Promise<void> {
    return new Promise((resolve, reject) => {
      let binding = true
      const server = createHttpServer((request, response) => this.handleCallback(request, response, expectedState))
      this.server = server
      server.once('error', (error: NodeJS.ErrnoException) => {
        if (this.server !== server) {
          // Another attempt owns the tracked server. This one is unreachable by
          // every teardown path, so it is closed here — an orphaned listener
          // would answer /callback for the rest of the process's life and hold
          // a port out of the login window.
          closeServer(server)
          return
        }
        this.server = undefined
        // A post-listen error leaves a server that may still be listening;
        // close() is a no-op (safe) when it never bound or is already gone.
        closeServer(server)
        const tagged = new LoginSettleError(
          'error',
          `Could not bind the login callback server on port ${port}: ${error.code ?? error.message}`,
        )
        if (binding) {
          binding = false
          reject(tagged)
        } else {
          this.settle?.reject(tagged)
        }
      })
      server.listen(port, '127.0.0.1', () => {
        if (!binding) return
        binding = false
        resolve()
      })
    })
  }

  /** One request against the attempt's callback endpoint (CLI-mirrored). */
  private handleCallback(request: IncomingMessage, response: ServerResponse, expectedState: string): void {
    // One-shot responses: the server dies with the attempt, and a client
    // pooling the connection would otherwise race its next request against
    // the close.
    response.setHeader('Connection', 'close')
    response.setHeader('Access-Control-Allow-Origin', corsOrigin(request.headers.origin))
    response.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS')
    response.setHeader('Access-Control-Allow-Headers', 'Content-Type')
    response.setHeader('Content-Type', 'application/json')
    const json = (code: number, body: Record<string, unknown>) => {
      response.writeHead(code)
      response.end(JSON.stringify(body))
    }
    if (request.method === 'OPTIONS') {
      response.writeHead(204)
      response.end()
      return
    }
    const path = request.url?.split('?')[0] ?? '/'
    if (path !== '/callback') {
      json(404, { success: false, error: 'Not found' })
      return
    }
    if (request.method !== 'POST') {
      json(405, { success: false, error: 'Method not allowed. Use POST.' })
      return
    }
    // The cap is on wire bytes, not JS string length: multibyte bodies
    // (CJK/emoji) would otherwise pass ~1.5-2x the limit before tripping it.
    let bodyBytes = 0
    let body = ''
    request.on('data', (chunk: Buffer) => {
      bodyBytes += chunk.length
      body += chunk.toString()
      if (bodyBytes > LOGIN_BODY_LIMIT_BYTES) request.destroy()
    })
    request.on('end', () => {
      // A destroyed (over-limit) request never processes its partial body.
      if (request.destroyed) return
      let payload: unknown
      try {
        payload = JSON.parse(body)
      } catch {
        json(400, { success: false, error: 'Invalid JSON' })
        return
      }
      // The Studio reports a denied authorization as an error object. The
      // state token is checked FIRST, exactly as the CLI does: a denial is
      // terminal, so an unauthenticated caller that could reach this branch
      // without a state match could kill a live login from any web page (the
      // POST rides as a CORS simple request, which the browser sends
      // regardless of our origin allowlist). Only the holder of the state this
      // attempt generated may end it.
      if (typeof payload === 'object' && payload !== null && 'error' in payload) {
        const denial = payload as Record<string, unknown>
        if (denial.state !== expectedState) {
          json(403, { success: false, error: 'Invalid state token' })
          return
        }
        const description = denial.error_description ?? denial.error
        this.settleAttempt(json, 200, { success: true }, new LoginSettleError(
          denial.error === 'access_denied' ? 'denied' : 'error',
          typeof description === 'string' && description !== '' ? description : 'Authorization failed',
        ))
        return
      }
      if (!isCallbackCredentials(payload)) {
        json(400, { success: false, error: 'Missing required fields' })
        return
      }
      if (payload.state !== expectedState) {
        // Not terminal: a stale tab replaying an old state must not kill the
        // live attempt — answer 403 and keep waiting (the CLI does the same).
        json(403, { success: false, error: 'Invalid state token' })
        return
      }
      this.settleAttempt(json, 200, { success: true }, undefined, { ...payload })
    })
    request.on('error', () => {})
  }

  /** Answer a decisive callback, stop listening, and settle the attempt. */
  private settleAttempt(
    json: (code: number, body: Record<string, unknown>) => void,
    code: number,
    body: Record<string, unknown>,
    failure?: LoginSettleError,
    credentials?: CommandCodeLoginCredentials,
  ): void {
    json(code, body)
    // Capture the settle hooks BEFORE teardown clears them.
    const settle = this.settle
    if (failure !== undefined) this.teardown()
    else this.closeCallback()
    if (settle === undefined) return
    if (failure !== undefined) settle.reject(failure)
    else if (credentials !== undefined) settle.resolve(credentials)
  }

  /**
   * Post-validation completion: whoami check, then hand-off to storage.
   *
   * Every step re-checks {@link ownsAttempt} first: the whoami round-trip and
   * the credential write are awaits, and the user may cancel (or start another
   * attempt) while one is in flight. A completion that no longer owns the
   * attempt must not START a key write or publish a status. A write already
   * handed to storage is tracked separately: cancelAndDrain() lets the owning
   * enrollment wait for it before compensation, without pretending it can be
   * aborted halfway through.
   */
  private async complete(attempt: number, credentials: CommandCodeLoginCredentials, targetRef: string | undefined): Promise<void> {
    if (!this.ownsAttempt(attempt)) return
    const validation = await validateCommandApiKey(
      this.deps.fetchImpl ?? fetch,
      this.readApiBase(),
      credentials.apiKey,
      this.attemptAbort?.signal,
    )
    if (!this.ownsAttempt(attempt)) return
    if (!validation.valid) {
      const reason: CommandCodeLoginFailureReason = validation.error === 'invalid_key'
        ? 'invalid-key'
        : validation.error === 'network_error' ? 'network' : 'error'
      this.teardown()
      this.setStatus({
        state: 'failed',
        reason,
        message: `/alpha/whoami rejected the delivered key (${validation.error}).`,
      })
      return
    }
    // Last gate before the side effect: a cancel that arrived during the
    // whoami check must win over storing the key.
    if (!this.ownsAttempt(attempt)) return
    try {
      this.deps.validateTargetRef?.(targetRef)
      const store = Promise.resolve().then(() => {
        // 微任务排队期间的取消仍应阻止副作用。
        if (this.ownsAttempt(attempt)) return this.deps.storeKey(credentials, targetRef)
      })
      this.pendingStores.add(store)
      try { await store } finally { this.pendingStores.delete(store) }
    } catch (error: unknown) {
      if (!this.ownsAttempt(attempt)) return
      this.teardown()
      this.setStatus({
        state: 'failed',
        reason: 'unavailable',
        message: error instanceof Error ? error.message : String(error),
      })
      return
    }
    if (!this.ownsAttempt(attempt)) return
    this.teardown()
    this.setStatus({ state: 'success', userName: credentials.userName, keyName: credentials.keyName })
  }

  /** Whether one attempt still owns the status face (not cancelled, replaced, or disposed). */
  private ownsAttempt(attempt: number): boolean {
    return !this.disposed && this.attemptSeq === attempt && this.statusValue.state === 'waiting'
  }

  /** Map a tagged settle rejection onto the status face. */
  private failFrom(attempt: number, failure: unknown): void {
    if (!(failure instanceof LoginSettleError)) return
    if (!this.ownsAttempt(attempt)) return
    this.teardown()
    this.setStatus({ state: 'failed', reason: failure.reason, message: failure.message })
  }

  private clearTimer(): void {
    if (this.timer !== undefined) {
      clearTimeout(this.timer)
      this.timer = undefined
    }
  }

  /** 消费一次回调后关闭监听；保留总期限以约束后续验证。 */
  private closeCallback(): void {
    closeServer(this.server)
    this.server = undefined
    this.settle = undefined
  }

  /** 结束整个尝试，同时中止验证请求，迟到结果由所有权检查拦截。 */
  private teardown(): void {
    this.clearTimer()
    this.attemptAbort?.abort()
    this.attemptAbort = undefined
    this.closeCallback()
  }
}

/** Close one loopback server without letting "not running"/"already closed" escape. */
function closeServer(server: Server | undefined): void {
  try {
    server?.close()
  } catch {
    // The server never bound, or was already closed: nothing to release.
  }
}

/** A tagged settle failure carrying the stable copy reason. */
class LoginSettleError extends Error {
  constructor(public readonly reason: CommandCodeLoginFailureReason, message: string) {
    super(message)
    this.name = 'LoginSettleError'
  }
}

/** Echo the Origin header only when the Studio allowlist contains it. */
function corsOrigin(origin: string | undefined): string {
  return origin !== undefined && LOGIN_ALLOWED_ORIGINS.includes(origin) ? origin : ''
}
