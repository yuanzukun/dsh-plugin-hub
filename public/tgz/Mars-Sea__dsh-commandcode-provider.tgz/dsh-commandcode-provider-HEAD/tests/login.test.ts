/**
 * Browser-login flow tests (node:test, zero deps). Run with `npm test`.
 *
 * These drive a REAL loopback server end to end, pinning the CLI-mirrored
 * contract: POST-only /callback, state-token equality, JSON responses, whoami
 * validation before storage, and every failure mode landing in a stable
 * `reason` the page can copy.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createServer as createNetServer } from 'node:net'

import {
  CommandCodeLoginFlow,
  buildCommandAuthUrl,
  loginCredentialRef,
  studioBaseForApiBase,
  validateCommandApiKey,
  type CommandCodeLoginCredentials,
} from '../src/login.ts'
import type { CommandCodeLoginStatus } from '../src/login-wire.ts'

/** A whoami stub scripted per call, recording the Authorization header. */
function makeWhoami(impl: (apiKey: string) => ResponseInit & { body?: unknown } | 'throw'): {
  fetchImpl: typeof fetch
  keys: string[]
} {
  const keys: string[] = []
  const fetchImpl = (async (_input: RequestInfo | URL, init?: RequestInit) => {
    const auth = String((init?.headers as Record<string, string> | undefined)?.Authorization ?? '')
    keys.push(auth.replace(/^Bearer /, ''))
    const script = impl(auth.replace(/^Bearer /, ''))
    if (script === 'throw') throw new Error('network down')
    return { status: script.status ?? 200, ok: (script.status ?? 200) >= 200 && (script.status ?? 200) < 300, json: async () => script.body } as Response
  }) as typeof fetch
  return { fetchImpl, keys }
}

interface FlowHarness {
  flow: CommandCodeLoginFlow
  stored: CommandCodeLoginCredentials[]
  whoamiKeys: string[]
  dispose(): void
}

function makeFlow(overrides?: {
  timeoutMs?: number
  storeKey?: (credentials: CommandCodeLoginCredentials, targetRef?: string) => Promise<void>
  validateTargetRef?: (targetRef: string | undefined) => void
  whoami?: (apiKey: string) => ResponseInit & { body?: unknown } | 'throw'
  startPort?: number
  maxPortAttempts?: number
}): FlowHarness {
  const stored: CommandCodeLoginCredentials[] = []
  const whoami = makeWhoami(overrides?.whoami ?? (() => ({ status: 200, body: { user: { id: 'u1' } } })))
  const flow = new CommandCodeLoginFlow({
    // Optional knobs are omitted (not passed as `undefined`): the flow reads
    // every one of them with `??`, so the defaults apply either way.
    ...(overrides?.timeoutMs === undefined ? {} : { timeoutMs: overrides.timeoutMs }),
    ...(overrides?.startPort === undefined ? {} : { startPort: overrides.startPort }),
    ...(overrides?.maxPortAttempts === undefined ? {} : { maxPortAttempts: overrides.maxPortAttempts }),
    fetchImpl: whoami.fetchImpl,
    storeKey: overrides?.storeKey ?? (async (credentials) => void stored.push(credentials)),
    ...(overrides?.validateTargetRef === undefined ? {} : { validateTargetRef: overrides.validateTargetRef }),
  })
  return {
    flow,
    stored,
    whoamiKeys: whoami.keys,
    dispose: () => flow.dispose(),
  }
}

/** Resolve when the flow's status matches, polling via onChange. */
function waitFor(
  flow: CommandCodeLoginFlow,
  predicate: (status: CommandCodeLoginStatus) => boolean,
  boundMs = 2_000,
): Promise<CommandCodeLoginStatus> {
  return new Promise((resolve, reject) => {
    const finish = (status: CommandCodeLoginStatus) => {
      clearTimeout(timer)
      off()
      resolve(status)
    }
    const timer = setTimeout(() => {
      off()
      reject(new Error(`timed out waiting for state; last: ${JSON.stringify(flow.status())}`))
    }, boundMs)
    const off = flow.onChange(() => {
      if (predicate(flow.status())) finish(flow.status())
    })
    if (predicate(flow.status())) finish(flow.status())
  })
}

/** The callback URL an authUrl points at, with its port and state. */
function parseAuthUrl(authUrl: string): { callbackUrl: string; port: number; state: string } {
  const url = new URL(authUrl)
  const callback = url.searchParams.get('callback')
  assert.ok(callback !== null, 'authUrl carries the callback parameter')
  const callbackUrl = new URL(callback)
  return {
    callbackUrl: callbackUrl.toString(),
    port: Number(callbackUrl.port),
    state: url.searchParams.get('state') ?? '',
  }
}

/** The Studio's callback POST body: the stored credentials plus the state token. */
function credentials(state: string, apiKey = 'cc_sk_test_key'): CommandCodeLoginCredentials & { state: string } {
  return { apiKey, state, userId: 'u1', userName: 'mars-sea', keyName: 'cli' }
}

test('取消收尾等待真实存储结束，不等待永远没有回调的监听任务', async () => {
  let release!: () => void
  const stored = new Promise<void>((resolve) => { release = resolve })
  let entered!: () => void
  const started = new Promise<void>((resolve) => { entered = resolve })
  const { flow } = makeFlow({ storeKey: async () => { entered(); await stored } })
  try {
    const status = await flow.begin('COMMANDCODE_API_KEY_2')
    const { callbackUrl, state } = parseAuthUrl(status.authUrl!)
    await fetch(callbackUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(credentials(state)) })
    await started
    let drained = false
    const cancel = flow.cancelAndDrain().then(() => { drained = true })
    await new Promise((resolve) => setTimeout(resolve, 5))
    assert.equal(drained, false)
    release()
    await cancel
    assert.equal(flow.status().reason, 'cancelled')
    await flow.begin('COMMANDCODE_API_KEY_3')
    await flow.cancelAndDrain()
    assert.equal(flow.status().reason, 'cancelled')
  } finally { release(); flow.dispose() }
})

test('回调后的验证仍受登录总期限约束并中止网络请求', async () => {
  let signal: AbortSignal | null | undefined
  let release: (response: Response) => void = () => undefined
  const pending = new Promise<Response>((resolve) => { release = resolve })
  let stored = false
  const flow = new CommandCodeLoginFlow({
    timeoutMs: 100,
    fetchImpl: (async (_input: RequestInfo | URL, init?: RequestInit) => {
      signal = init?.signal
      return pending
    }) as typeof fetch,
    storeKey: async () => { stored = true },
  })
  try {
    const waiting = await flow.begin()
    const { callbackUrl, state } = parseAuthUrl(waiting.authUrl ?? '')
    await fetch(callbackUrl, { method: 'POST', body: JSON.stringify(credentials(state)) })
    const failed = await waitFor(flow, (status) => status.state === 'failed')
    assert.equal(failed.reason, 'timeout')
    assert.equal(signal?.aborted, true)
    // 故意使用忽略取消的网络替身，验证迟到结果也不能落入凭据存储。
    release(new Response('{}'))
    await new Promise((resolve) => setImmediate(resolve))
    assert.equal(stored, false)
    assert.equal(flow.status().reason, 'timeout')
  } finally {
    release(new Response('{}'))
    flow.dispose()
  }
})

test('取消回调后的验证会中止请求并保留取消状态', async () => {
  let signal: AbortSignal | null | undefined
  let stored = false
  const flow = new CommandCodeLoginFlow({
    fetchImpl: (async (_input: RequestInfo | URL, init?: RequestInit) => {
      signal = init?.signal
      return new Promise<Response>((_resolve, reject) => {
        signal?.addEventListener('abort', () => reject(signal?.reason), { once: true })
      })
    }) as typeof fetch,
    storeKey: async () => { stored = true },
  })
  try {
    const waiting = await flow.begin()
    const { callbackUrl, state } = parseAuthUrl(waiting.authUrl ?? '')
    await fetch(callbackUrl, { method: 'POST', body: JSON.stringify(credentials(state)) })
    flow.cancel()
    await new Promise((resolve) => setImmediate(resolve))
    assert.equal(signal?.aborted, true)
    assert.equal(stored, false)
    assert.deepEqual(flow.status(), { state: 'failed', reason: 'cancelled' })
  } finally {
    flow.dispose()
  }
})

test('studio base mapping pairs each API base with the CLI-matching studio', () => {
  assert.equal(studioBaseForApiBase('https://api.commandcode.ai'), 'https://commandcode.ai')
  assert.equal(studioBaseForApiBase('https://staging-api.commandcode.ai'), 'https://staging.commandcode.ai')
  assert.equal(studioBaseForApiBase('http://localhost:3000'), 'http://localhost:3000')
  assert.equal(studioBaseForApiBase('https://elsewhere.example'), 'https://commandcode.ai')
})

test('buildCommandAuthUrl carries the loopback callback and state', () => {
  const url = buildCommandAuthUrl({ studioBase: 'https://commandcode.ai', port: 5959, state: 'abc' })
  assert.ok(url.startsWith('https://commandcode.ai/studio/auth/cli?callback='))
  assert.equal(new URL(url).searchParams.get('callback'), 'http://localhost:5959/callback')
  assert.equal(new URL(url).searchParams.get('state'), 'abc')
})

test('validateCommandApiKey mirrors the CLI verdicts', async () => {
  const ok = (async (_input: RequestInfo | URL, init?: RequestInit) => {
    assert.equal(new Headers(init?.headers).get('accept-encoding'), 'identity')
    return { status: 200, ok: true, json: async () => ({}) }
  }) as unknown as typeof fetch
  const unauthorized = (async () => ({ status: 401, ok: false })) as unknown as typeof fetch
  const boom = (async () => {
    throw new Error('down')
  }) as unknown as typeof fetch
  const serverError = (async () => ({ status: 500, ok: false })) as unknown as typeof fetch
  assert.deepEqual(await validateCommandApiKey(ok, 'https://api.commandcode.ai', 'k'), { valid: true })
  assert.deepEqual(await validateCommandApiKey(unauthorized, 'https://api.commandcode.ai', 'k'), { valid: false, error: 'invalid_key' })
  assert.deepEqual(await validateCommandApiKey(serverError, 'https://api.commandcode.ai', 'k'), { valid: false, error: 'server_error' })
  assert.deepEqual(await validateCommandApiKey(boom, 'https://api.commandcode.ai', 'k'), { valid: false, error: 'network_error' })
})

test('browser login accepts only the default or a saved extra-account credential ref', () => {
  const accounts = [{ apiKeyEnv: 'COMMANDCODE_API_KEY_2' }]
  assert.equal(loginCredentialRef(undefined, 'COMMANDCODE_API_KEY', accounts), 'COMMANDCODE_API_KEY')
  assert.equal(loginCredentialRef('COMMANDCODE_API_KEY_2', 'COMMANDCODE_API_KEY', accounts), 'COMMANDCODE_API_KEY_2')
  assert.throws(() => loginCredentialRef('OTHER_SECRET', 'COMMANDCODE_API_KEY', accounts), /must be saved/)
  assert.throws(() => loginCredentialRef('COMMANDCODE_API_KEY', 'COMMANDCODE_API_KEY', [{ apiKeyEnv: 'COMMANDCODE_API_KEY' }]), /must be saved/)
})

test('happy path: callback credentials validate, store, and report success', async () => {
  const harness = makeFlow()
  try {
    const waiting = await harness.flow.begin()
    assert.equal(waiting.state, 'waiting')
    const { callbackUrl, state } = parseAuthUrl(waiting.authUrl ?? '')
    assert.ok(state.length > 20, 'the state token is 32 random bytes base64url')

    const response = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials(state)),
    })
    assert.equal(response.status, 200)
    assert.deepEqual(await response.json(), { success: true })

    const status = await waitFor(harness.flow, (s) => s.state !== 'waiting')
    assert.equal(status.state, 'success')
    assert.equal(status.userName, 'mars-sea')
    assert.equal(harness.stored.length, 1)
    assert.equal(harness.stored[0]?.apiKey, 'cc_sk_test_key')
    assert.deepEqual(harness.whoamiKeys, ['cc_sk_test_key'])
    // The server stopped listening after the attempt settled.
    await assert.rejects(fetch(callbackUrl, { method: 'POST', body: '{}' }))
  } finally {
    harness.dispose()
  }
})

test('a saved extra account login stores its key under that account, not default', async () => {
  const targets: Array<string | undefined> = []
  const harness = makeFlow({
    storeKey: async (_credentials, targetRef) => { targets.push(targetRef) },
  })
  try {
    const waiting = await harness.flow.begin('COMMANDCODE_API_KEY_2')
    const { callbackUrl, state } = parseAuthUrl(waiting.authUrl ?? '')
    const response = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials(state, 'cc_sk_second_account')),
    })
    assert.equal(response.status, 200)
    assert.equal((await waitFor(harness.flow, (s) => s.state !== 'waiting')).state, 'success')
    assert.deepEqual(targets, ['COMMANDCODE_API_KEY_2'])
    assert.deepEqual(harness.whoamiKeys, ['cc_sk_second_account'])
  } finally {
    harness.dispose()
  }
})

test('another account cannot rejoin a live login or supply an unsaved target', async () => {
  const harness = makeFlow({
    validateTargetRef: (targetRef) => {
      if (targetRef !== undefined && targetRef !== 'SAVED_ACCOUNT') throw new Error('account must be saved')
    },
  })
  try {
    await assert.rejects(harness.flow.begin('UNSAVED_ACCOUNT'), /account must be saved/)
    const first = await harness.flow.begin('SAVED_ACCOUNT')
    await assert.rejects(harness.flow.begin(), /another account login/)
    assert.equal((await harness.flow.begin('SAVED_ACCOUNT')).authUrl, first.authUrl)
  } finally {
    harness.dispose()
  }
})

test('a stale state token is rejected but does not kill the live attempt', async () => {
  const harness = makeFlow()
  try {
    const waiting = await harness.flow.begin()
    const { callbackUrl } = parseAuthUrl(waiting.authUrl ?? '')
    const response = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials('forged-state')),
    })
    assert.equal(response.status, 403)
    assert.deepEqual(await response.json(), { success: false, error: 'Invalid state token' })
    assert.equal(harness.flow.status().state, 'waiting')
    assert.equal(harness.stored.length, 0)
  } finally {
    harness.dispose()
  }
})

test('the callback endpoint mirrors the CLI method and path rules', async () => {
  const harness = makeFlow()
  try {
    const waiting = await harness.flow.begin()
    const { callbackUrl } = parseAuthUrl(waiting.authUrl ?? '')
    const base = new URL(callbackUrl)

    const options = await fetch(callbackUrl, { method: 'OPTIONS', headers: { Origin: 'https://commandcode.ai' } })
    assert.equal(options.status, 204)
    assert.equal(options.headers.get('access-control-allow-origin'), 'https://commandcode.ai')

    const wrongPath = await fetch(new URL('/other', base).toString(), { method: 'POST' })
    assert.equal(wrongPath.status, 404)

    const wrongMethod = await fetch(callbackUrl)
    assert.equal(wrongMethod.status, 405)

    const badJson = await fetch(callbackUrl, { method: 'POST', body: '{nope' })
    assert.equal(badJson.status, 400)

    const missingFields = await fetch(callbackUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ apiKey: 'k' }) })
    assert.equal(missingFields.status, 400)
    assert.equal(harness.flow.status().state, 'waiting')
  } finally {
    harness.dispose()
  }
})

test('a foreign origin gets no CORS echo', async () => {
  const harness = makeFlow()
  try {
    const waiting = await harness.flow.begin()
    const { callbackUrl } = parseAuthUrl(waiting.authUrl ?? '')
    const response = await fetch(callbackUrl, {
      method: 'OPTIONS',
      headers: { Origin: 'https://evil.example' },
    })
    const echoed = response.headers.get('access-control-allow-origin')
    assert.ok(echoed === null || echoed === '', 'unallowlisted origins must not be echoed')
  } finally {
    harness.dispose()
  }
})

test('a denied authorization fails the attempt with reason denied', async () => {
  const harness = makeFlow()
  try {
    const waiting = await harness.flow.begin()
    const { callbackUrl, state } = parseAuthUrl(waiting.authUrl ?? '')
    await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'access_denied', state, error_description: 'user clicked deny' }),
    })
    const status = await waitFor(harness.flow, (s) => s.state === 'failed')
    assert.equal(status.reason, 'denied')
    assert.equal(harness.stored.length, 0)
  } finally {
    harness.dispose()
  }
})

test('an invalid delivered key fails validation and is never stored', async () => {
  const harness = makeFlow({ whoami: () => ({ status: 401 }) })
  try {
    const waiting = await harness.flow.begin()
    const { callbackUrl, state } = parseAuthUrl(waiting.authUrl ?? '')
    await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials(state)),
    })
    const status = await waitFor(harness.flow, (s) => s.state === 'failed')
    assert.equal(status.reason, 'invalid-key')
    assert.equal(harness.stored.length, 0)
  } finally {
    harness.dispose()
  }
})

test('an unreachable validation API fails with reason network', async () => {
  const harness = makeFlow({ whoami: () => 'throw' })
  try {
    const waiting = await harness.flow.begin()
    const { callbackUrl, state } = parseAuthUrl(waiting.authUrl ?? '')
    await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials(state)),
    })
    const status = await waitFor(harness.flow, (s) => s.state === 'failed')
    assert.equal(status.reason, 'network')
    assert.equal(harness.stored.length, 0)
  } finally {
    harness.dispose()
  }
})

test('a rejecting storage seam fails with reason unavailable', async () => {
  const harness = makeFlow({
    storeKey: async () => {
      throw new Error('credentials service unavailable')
    },
  })
  try {
    const waiting = await harness.flow.begin()
    const { callbackUrl, state } = parseAuthUrl(waiting.authUrl ?? '')
    await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials(state)),
    })
    const status = await waitFor(harness.flow, (s) => s.state === 'failed')
    assert.equal(status.reason, 'unavailable')
    assert.match(status.message ?? '', /credentials service unavailable/)
  } finally {
    harness.dispose()
  }
})

test('the attempt times out when no callback arrives', async () => {
  const harness = makeFlow({ timeoutMs: 40 })
  try {
    await harness.flow.begin()
    const status = await waitFor(harness.flow, (s) => s.state === 'failed', 2_000)
    assert.equal(status.reason, 'timeout')
  } finally {
    harness.dispose()
  }
})

test('cancel stops the attempt and closes the callback server', async () => {
  const harness = makeFlow()
  try {
    const waiting = await harness.flow.begin()
    const { callbackUrl } = parseAuthUrl(waiting.authUrl ?? '')
    harness.flow.cancel()
    assert.equal(harness.flow.status().state, 'failed')
    assert.equal(harness.flow.status().reason, 'cancelled')
    await assert.rejects(fetch(callbackUrl, { method: 'POST', body: '{}' }))
  } finally {
    harness.dispose()
  }
})

test('dispose during a waiting attempt ends it cancelled', async () => {
  const harness = makeFlow()
  try {
    await harness.flow.begin()
    harness.dispose()
    assert.equal(harness.flow.status().reason, 'cancelled')
  } finally {
    harness.dispose()
  }
})

test('begin while waiting rejoins the live attempt', async () => {
  const harness = makeFlow()
  try {
    const first = await harness.flow.begin()
    const second = await harness.flow.begin()
    assert.equal(first.authUrl, second.authUrl)
  } finally {
    harness.dispose()
  }
})

test('a terminal state makes the next begin start fresh', async () => {
  const harness = makeFlow({ timeoutMs: 30 })
  try {
    await harness.flow.begin()
    await waitFor(harness.flow, (s) => s.state === 'failed')
    const second = await harness.flow.begin()
    assert.equal(second.state, 'waiting')
    assert.notEqual(second.authUrl, undefined)
  } finally {
    harness.dispose()
  }
})

test('two concurrent begin() calls share one attempt and one server', async () => {
  // Two GUI tabs (or a double click) can issue two `loginBegin` RPCs at once and
  // the rejoin check cannot see them: the status only becomes `waiting` AFTER
  // the port is bound, so without a single-flight fence each call bound its own
  // orphan loopback server.
  const harness = makeFlow()
  try {
    const [first, second] = await Promise.all([harness.flow.begin(), harness.flow.begin()])
    assert.equal(first.state, 'waiting')
    assert.equal(second.state, 'waiting')
    assert.equal(first.authUrl, second.authUrl, 'both callers rejoin the SAME attempt')
    const { callbackUrl } = parseAuthUrl(first.authUrl ?? '')
    // One server, and it is the tracked one: tearing the flow down closes it.
    harness.dispose()
    await assert.rejects(fetch(callbackUrl, { method: 'POST', body: '{}' }))
  } finally {
    harness.dispose()
  }
})

test('cancel() during a start retires the attempt instead of publishing it', async () => {
  // The status cannot say `waiting` while the port is still binding, so a
  // cancel in that window used to be dropped on the floor and the attempt
  // published a live authUrl the user had already dismissed.
  const harness = makeFlow()
  try {
    const started = harness.flow.begin()
    harness.flow.cancel()
    const status = await started
    assert.equal(status.state, 'failed')
    assert.equal(status.reason, 'cancelled')
    assert.equal(harness.flow.status().state, 'failed')
  } finally {
    harness.dispose()
  }
})

test('begin rejects when no candidate port is free', async () => {
  // Occupy a real port, then aim the flow at exactly that one.
  const occupant = createNetServer()
  await new Promise<void>((resolve) => occupant.listen(0, '127.0.0.1', resolve))
  const address = occupant.address()
  assert.ok(address !== null && typeof address === 'object')
  const busyPort = address.port
  const harness = makeFlow({ startPort: busyPort, maxPortAttempts: 1 })
  try {
    await assert.rejects(harness.flow.begin(), /No available port found/)
  } finally {
    harness.dispose()
    await new Promise<void>((resolve) => occupant.close(() => resolve()))
  }
})

// Callback authentication and attempt ownership

test('a denial without the state token cannot end a live attempt', async () => {
  // The denial branch is terminal, and a POST carrying `Content-Type:
  // text/plain` rides as a CORS simple request — the browser sends it whatever
  // our origin allowlist says, so any open page could otherwise kill a login by
  // blindly posting `{"error":"access_denied"}`. The state token is what makes
  // ending an attempt an authorized act (the official CLI checks it too).
  const harness = makeFlow()
  try {
    const waiting = await harness.flow.begin()
    const { callbackUrl } = parseAuthUrl(waiting.authUrl ?? '')
    const response = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain', Origin: 'https://evil.example' },
      body: JSON.stringify({ error: 'access_denied' }),
    })
    assert.equal(response.status, 403)
    assert.deepEqual(await response.json(), { success: false, error: 'Invalid state token' })
    // The attempt is untouched and can still be completed.
    assert.equal(harness.flow.status().state, 'waiting')
  } finally {
    harness.dispose()
  }
})

test('a denial carrying the state token still fails the attempt', async () => {
  // The Studio's own path must keep working: the same POST carrying the
  // attempt's state is decisive.
  const harness = makeFlow()
  try {
    const waiting = await harness.flow.begin()
    const { callbackUrl, state } = parseAuthUrl(waiting.authUrl ?? '')
    const response = await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'access_denied', state, error_description: 'user clicked deny' }),
    })
    assert.equal(response.status, 200)
    const status = await waitFor(harness.flow, (s) => s.state === 'failed')
    assert.equal(status.reason, 'denied')
  } finally {
    harness.dispose()
  }
})

test('cancel during key validation wins over the delivered credential', async () => {
  // The whoami round-trip is an await: cancelling while it is in flight must
  // not store the key afterwards nor flip the finished status back to success.
  const stored: CommandCodeLoginCredentials[] = []
  let releaseWhoami: (() => void) | undefined
  const gate = new Promise<void>((resolve) => { releaseWhoami = resolve })
  const flow = new CommandCodeLoginFlow({
    storeKey: async (credentials) => void stored.push(credentials),
    fetchImpl: (async (input: RequestInfo | URL) => {
      if (String(input).includes('/alpha/whoami')) {
        await gate
        return { status: 200, ok: true, json: async () => ({ user: { id: 'u1' } }) } as Response
      }
      return { status: 200, ok: true, json: async () => ({}) } as Response
    }) as typeof fetch,
  })
  try {
    const waiting = await flow.begin()
    const { callbackUrl, state } = parseAuthUrl(waiting.authUrl ?? '')
    await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials(state)),
    })
    // The callback is consumed; the flow is validating the key.
    flow.cancel()
    assert.deepEqual(flow.status(), { state: 'failed', reason: 'cancelled' })

    releaseWhoami!()
    await new Promise((resolve) => setTimeout(resolve, 50))
    assert.equal(stored.length, 0, 'a cancelled attempt never stores the key')
    assert.deepEqual(flow.status(), { state: 'failed', reason: 'cancelled' })
  } finally {
    flow.dispose()
  }
})

test('begin() after the callback starts a fresh attempt instead of reusing the closed port', async () => {
  // Once the callback is consumed the loopback server is closed, so the stored
  // `waiting` status no longer has anything listening — handing it back would
  // give the user a dead port. The whoami stub is gated here so the status
  // really is `waiting` with a closed server.
  let releaseWhoami: (() => void) | undefined
  const gate = new Promise<void>((resolve) => { releaseWhoami = resolve })
  const harness = makeFlow({
    whoami: () => ({ status: 200, body: { user: { id: 'u1' } } }),
  })
  // A second flow whose fetch is gated, so validation cannot finish early.
  const gated = new CommandCodeLoginFlow({
    storeKey: async () => {},
    fetchImpl: (async (input: RequestInfo | URL) => {
      if (String(input).includes('/alpha/whoami')) {
        await gate
        return { status: 200, ok: true, json: async () => ({ user: { id: 'u1' } }) } as Response
      }
      return { status: 200, ok: true, json: async () => ({}) } as Response
    }) as typeof fetch,
  })
  harness.dispose()
  try {
    const waiting = await gated.begin()
    const { callbackUrl, state } = parseAuthUrl(waiting.authUrl ?? '')
    await fetch(callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials(state)),
    })
    // Still validating: `waiting`, but its server is already closed.
    assert.equal(gated.status().state, 'waiting')
    const again = await gated.begin()
    assert.equal(again.state, 'waiting')
    assert.notEqual(again.authUrl, waiting.authUrl)
    // The fresh URL is live: its callback still reaches a listening server.
    const parsed = parseAuthUrl(again.authUrl ?? '')
    const response = await fetch(parsed.callbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials(parsed.state)),
    })
    assert.equal(response.status, 200)
    releaseWhoami!()
    await new Promise((resolve) => setTimeout(resolve, 30))
  } finally {
    gated.dispose()
  }
})
