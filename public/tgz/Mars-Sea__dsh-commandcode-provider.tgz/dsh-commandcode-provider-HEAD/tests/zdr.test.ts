/**
 * Zero-data-retention capability snapshot tests (node:test, zero deps).
 *
 * The snapshot is informational: `x-cmd-zdr: 1` is sent on EVERY request when
 * ZDR is enabled, never omitted based on this table — the provider REFUSES an
 * unsupported request (422 `cmd_zdr_no_providers`) rather than serving it from a
 * retaining provider. The table mirrors the CLI's own exclusion set, so this
 * file pins the list: a sync that moves membership must be a deliberate diff.
 * Run with `npm test`.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'

import {
  KNOWN_NON_ZDR_MODELS,
  supportsZeroDataRetention,
} from '../src/capabilities.ts'

test('the ZDR exception list is the live catalog zdr verdict (command-code@1.84.0)', () => {
  // command-code@1.82.4 moved the authority for this verdict out of the CLI
  // artifact: `knownModelSupportsZdr` no longer negates a bundled Set, it reads
  // `resolveKnownCatalogModel({model,catalog})?.zdr ?? false`. So this list is
  // now the live catalog's `zdr:false` membership, read from
  // `GET /provider/v1/models?view=client`, cross-checked against the artifact's
  // canonical helper set. A sync that moves membership must be a deliberate diff.
  //
  // History: 1.74.1 dropped `meituan/LongCat-2.0:free` from the anchor that the
  // old extractor read while the canonical helper `modelSupportsZdr2` kept it,
  // so the two anchor sets disagreed by exactly that one id (22 vs 23) for eight
  // releases; 1.82.4 ends the disagreement and serves `zdr:false` for the row,
  // which is why it is listed again here. Both retired stealth previews (Pixel
  // Canary, retired 2026-10-01; Space Bunny Alpha, retired 2026-10-06) left the
  // list in 1.77.0. 1.79.0 added the free `stealth/glyph-cluster:free` preview —
  // the one entry the pricing page itself flags "Not routed under ZDR" — and
  // 1.80.0 added `meta/muse-wonder-1.0`, bringing the set to 22. 1.82.4 then
  // adds `stealth/cat-jam:free` (the second live stealth preview), for 24
  // members: LongCat + cat-jam with nothing removed.
  //
  // 1.84.0 re-keys LongCat instead of widening coverage, so the set grows by a
  // net one and 25 is the membership to pin. The catalog flipped the `:free`
  // row the other way — it now serves `zdr:true` for `meituan/LongCat-2.0:free`
  // — while the paid `meituan/LongCat-2.0` id, the one a request can still name,
  // took that slot with `zdr:false`. Both ids therefore crossed this snapshot in
  // opposite directions, which is why the `:free` row is absent below and the
  // bare id is present: only the pair together tells the story, and dropping
  // just one of them would read as a coverage change rather than a re-key.
  //
  // 1.84.0 also adds `reflection/beam:free`, a catalog-only row: the artifact's
  // embedded model snapshot does not carry it, so `?view=client` is the sole
  // evidence for its `zdr:false` verdict — the same position `stealth/cat-jam:free`
  // was in at 1.82.4.
  assert.deepEqual([...KNOWN_NON_ZDR_MODELS].sort(), [
    'MiniMaxAI/MiniMax-M3',
    'Qwen/Qwen3.8-Max-0902',
    'deepseek/deepseek-v4.1-flash-fast',
    'meituan/LongCat-2.0',
    'meta/muse-spark-1.1',
    'meta/muse-spark-1.2',
    'meta/muse-spark-1.2-contributor',
    'meta/muse-spark-1.3',
    'meta/muse-spark-1.3-contributor',
    'meta/muse-wonder-1.0',
    'minimax/minimax-m3-free',
    'poolside/laguna-s-2.1-free',
    'reflection/beam:free',
    'sakana/fugu-ultra',
    'stealth/cat-jam:free',
    'stealth/glyph-cluster:free',
    'stepfun/Step-3.7-Flash',
    'stepfun/Step-5-Preview',
    'xai/grok-4.5',
    'xai/grok-4.6',
    'xiaomi/mimo-v2.6-flash',
    'xiaomi/mimo-v2.6-pro',
    'xiaomi/mimo-v2.6-pro-ultraspeed',
    'z-ai/glm-5.3-flashx',
    'zai-org/GLM-5.2-Fast',
  ])
})

test('supportsZeroDataRetention answers false for every listed model and true otherwise', () => {
  for (const id of KNOWN_NON_ZDR_MODELS) {
    assert.equal(supportsZeroDataRetention(id), false, `${id} has no ZDR upstream`)
  }
  // One per family served through the Provider API, plus unseen ids: the table
  // only shrinks the answer for listed ids, and the header rides either way.
  // `meituan/LongCat-2.0` left this group in 1.84.0: the live catalog serves
  // `zdr:false` for the paid id, so it now sits in the exception set above —
  // exactly the reverse of 1.82.4, when the `:free` row held that slot and this
  // id was still ZDR covered. Both retired stealth previews stay here on
  // purpose: they left the CLI's exclusion sets in 1.77.0, so the snapshot
  // still answers true for them.
  for (const id of [
    'deepseek/deepseek-v4.1-flash',
    'deepseek/deepseek-v4-flash',
    'stealth/pixel-canary',
    'stealth/space-bunny-alpha',
    'claude-opus-5',
    'claude-sonnet-5',
    'gpt-5.6-luna',
    'google/gemini-3.8-flash',
    'Qwen/Qwen3.8-Omni-Flash',
    'moonshotai/Kimi-K3',
    'z-ai/glm-5.3-flash',
    'zai-org/GLM-5',
    'MiniMaxAI/MiniMax-M2.5',
    'a-model-from-the-future',
  ]) {
    assert.equal(supportsZeroDataRetention(id), true, `${id} is ZDR-covered`)
  }
})
