/**
 * Login-panel controller tests (node:test, zero deps). Run with `npm test`.
 *
 * These pin the settings page's login fetch/poll lifecycle: begin → waiting
 * (with the Studio URL) → terminal, transport failures degrading to
 * `unavailable`, cancel, superseded loops from a fresh begin, and dispose.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'

import {
  CommandCodeLoginController,
  loginFailureCopy,
  loginHint,
  loginStateForTarget,
  type LoginCallResult,
  type LoginPageState,
  type LoginRemote,
} from '../src/client/login.ts'
import type { CommandCodeLoginFailureReason, CommandCodeLoginStatus } from '../src/login-wire.ts'

const POLL_MS = 5

/** A scripted Remote whose call results are queued per endpoint. */
function makeRemote(script: {
  begin?: Array<LoginCallResult | Error>
  status?: Array<LoginCallResult>
  cancel?: LoginCallResult
} = {}): LoginRemote & { calls: string[] } {
  const calls: string[] = []
  const shift = <T>(queue: Array<T> | undefined, label: string): T => {
    calls.push(label)
    const queue_ = queue ?? []
    if (queue_.length === 0) throw new Error(`no scripted ${label} response`)
    return queue_.shift() as T
  }
  return {
    get calls() {
      return [...calls]
    },
    loginBegin: async () => {
      const item = shift(script.begin, 'begin')
      if (item instanceof Error) throw item
      return item
    },
    loginStatus: async () => shift(script.status, 'status'),
    loginCancel: async () => {
      const item = script.cancel ?? { ok: true as const, value: { state: 'idle' } satisfies CommandCodeLoginStatus }
      calls.push('cancel')
      if (item instanceof Error) throw item
      return item
    },
  }
}

test('account login keeps its target while polling and leaves the default row separate', async () => {
  const requested: Array<string | undefined> = []
  let status: LoginCallResult = { ok: true, value: { state: 'waiting', authUrl: 'https://commandcode.ai/auth' } }
  const remote: LoginRemote = {
    loginBegin: async (targetRef) => {
      requested.push(targetRef)
      return status
    },
    loginStatus: async () => status,
    loginCancel: async () => ({ ok: true, value: { state: 'failed', reason: 'cancelled' } }),
  }
  const controller = new CommandCodeLoginController(() => remote, POLL_MS)
  try {
    void controller.begin('COMMANDCODE_API_KEY_2')
    await waitForPhase(controller, 'waiting')
    assert.deepEqual(requested, ['COMMANDCODE_API_KEY_2'])
    assert.equal(controller.state().targetRef, 'COMMANDCODE_API_KEY_2')
    assert.equal(loginStateForTarget(controller.state(), undefined).visible.phase, 'idle')
    assert.equal(loginStateForTarget(controller.state(), undefined).busyElsewhere, true)
    assert.equal(loginStateForTarget(controller.state(), 'COMMANDCODE_API_KEY_2').visible.phase, 'waiting')
    status = { ok: true, value: { state: 'success', userName: 'second', keyName: 'cli' } }
    await waitForPhase(controller, 'success')
    assert.equal(controller.state().targetRef, 'COMMANDCODE_API_KEY_2')
    assert.equal(loginStateForTarget(controller.state(), undefined).visible.phase, 'idle')
    assert.equal(loginStateForTarget(controller.state(), 'COMMANDCODE_API_KEY_2').visible.phase, 'success')
    await controller.begin()
    assert.deepEqual(requested, ['COMMANDCODE_API_KEY_2', undefined])
    assert.equal(controller.state().targetRef, undefined)
  } finally {
    controller.dispose()
  }
})

/** Resolve once the controller's projected phase matches. */
function waitForPhase(
  controller: CommandCodeLoginController,
  phase: string,
  boundMs = 2_000,
): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      off()
      reject(new Error(`timed out waiting for phase ${phase}; at ${controller.state().phase}`))
    }, boundMs)
    const check = () => {
      if (controller.state().phase === phase) {
        clearTimeout(timer)
        off()
        resolve()
      }
    }
    const off = controller.subscribe(check)
    check()
  })
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

test('收到授权地址后才自动开页，重复轮询及取消后的迟到地址不再开页，拦截不终止登录', async () => {
  const previousWindow = Object.getOwnPropertyDescriptor(globalThis, 'window')
  const opened: unknown[][] = []
  let throwOnOpen = false
  Object.defineProperty(globalThis, 'window', { configurable: true, value: {
    open: (...args: unknown[]) => { opened.push(args); if (throwOnOpen) throw new Error('浏览器阻止打开'); return null },
  } })
  let reply!: (value: LoginCallResult) => void
  let polls = 0
  const waiting: LoginCallResult = { ok: true, value: { state: 'waiting', authUrl: 'https://example.invalid/auth' } }
  const remote: LoginRemote = {
    loginBegin: () => new Promise((resolve) => { reply = resolve }),
    loginStatus: async () => { polls++; return waiting },
    loginCancel: async () => ({ ok: true, value: { state: 'failed', reason: 'cancelled' } }),
  }
  const controller = new CommandCodeLoginController(() => remote, POLL_MS)
  try {
    const begin = controller.begin()
    assert.deepEqual(opened, [], '没有地址时不开准备页')
    reply(waiting)
    await begin
    assert.deepEqual(opened, [['https://example.invalid/auth', '_blank', 'noopener,noreferrer']])
    for (let n = 0; n < 100 && polls < 2; n++) await sleep(POLL_MS)
    assert.ok(polls >= 2)
    assert.equal(opened.length, 1, '成功返回 null 也不在轮询中重开')
    await controller.cancel()
    throwOnOpen = true
    const retry = controller.begin()
    reply(waiting)
    await retry
    assert.equal(opened.length, 2, '新的登录尝试允许再次打开')
    assert.equal(controller.state().phase, 'waiting', '浏览器抛错仍保留授权状态和手动链接')
    assert.equal(controller.state().authUrl, 'https://example.invalid/auth')
    await controller.cancel()
    const cancelled = controller.begin()
    await controller.cancel()
    reply(waiting)
    await cancelled
    assert.equal(opened.length, 2, '取消后迟到的地址不会打开')
  } finally {
    controller.dispose()
    if (previousWindow) Object.defineProperty(globalThis, 'window', previousWindow)
    else Reflect.deleteProperty(globalThis, 'window')
  }
})

test('a fresh begin walks starting → waiting with the Studio URL', async () => {
  let statusResult: LoginCallResult = { ok: true, value: { state: 'waiting', authUrl: 'https://commandcode.ai/studio/auth/cli?callback=x' } }
  const remote = makeRemote({
    begin: [{ ok: true, value: { state: 'waiting', authUrl: 'https://commandcode.ai/studio/auth/cli?callback=x' } }],
  })
  let polls = 0
  remote.loginStatus = async () => {
    polls += 1
    await sleep(1)
    return statusResult
  }
  const controller = new CommandCodeLoginController(() => remote, POLL_MS)
  try {
    void controller.begin()
    await waitForPhase(controller, 'waiting')
    assert.equal(controller.state().authUrl, 'https://commandcode.ai/studio/auth/cli?callback=x')
    assert.equal(remote.calls[0], 'begin')

    // The terminal success lands through polling; polling then stops.
    statusResult = { ok: true, value: { state: 'success', userName: 'mars-sea', keyName: 'cli' } }
    await waitForPhase(controller, 'success')
    assert.equal(controller.state().userName, 'mars-sea')
    const pollsAtSuccess = polls
    await sleep(POLL_MS * 4)
    assert.ok(polls > pollsAtSuccess - 1 && polls < pollsAtSuccess + 2, `polling stops at a terminal state (polls=${polls})`)
    await sleep(POLL_MS * 4)
    assert.equal(polls, pollsAtSuccess + (polls > pollsAtSuccess ? 1 : 0), 'no further polls after the terminal state settles')
  } finally {
    controller.dispose()
  }
})

test('begin is a no-op while an attempt is live', async () => {
  const remote = makeRemote({
    begin: [{ ok: true, value: { state: 'waiting', authUrl: 'u' } }],
    status: [],
  })
  const controller = new CommandCodeLoginController(() => remote, POLL_MS)
  try {
    void controller.begin()
    await waitForPhase(controller, 'waiting')
    await controller.begin()
    assert.equal(remote.calls.filter((call) => call === 'begin').length, 1)
  } finally {
    controller.dispose()
  }
})

test('a rejected begin lands in unavailable with the gateway message', async () => {
  const remote = makeRemote({
    begin: [{ ok: false, error: { message: 'no free port' } }],
  })
  const controller = new CommandCodeLoginController(() => remote, POLL_MS)
  try {
    await controller.begin()
    const state = controller.state()
    assert.equal(state.phase, 'unavailable')
    assert.equal(state.message, 'no free port')
  } finally {
    controller.dispose()
  }
})

test('a thrown begin reads as unavailable too', async () => {
  const remote = makeRemote({ begin: [new Error('remote not mounted')] })
  const controller = new CommandCodeLoginController(() => remote, POLL_MS)
  try {
    await controller.begin()
    assert.equal(controller.state().phase, 'unavailable')
  } finally {
    controller.dispose()
  }
})

test('a missing remote goes straight to unavailable', async () => {
  const controller = new CommandCodeLoginController(() => undefined, POLL_MS)
  try {
    await controller.begin()
    assert.equal(controller.state().phase, 'unavailable')
    assert.match(controller.state().message ?? '', /not mounted/)
  } finally {
    controller.dispose()
  }
})

test('cancel ends a waiting attempt', async () => {
  const remote = makeRemote({
    begin: [{ ok: true, value: { state: 'waiting', authUrl: 'u' } }],
    status: [],
    cancel: { ok: true, value: { state: 'failed', reason: 'cancelled' } },
  })
  const controller = new CommandCodeLoginController(() => remote, POLL_MS)
  try {
    void controller.begin()
    await waitForPhase(controller, 'waiting')
    await controller.cancel()
    assert.equal(controller.state().phase, 'failed')
    assert.equal(controller.state().reason, 'cancelled')
  } finally {
    controller.dispose()
  }
})

test('a failed status carries reason and message', async () => {
  let statusResult: LoginCallResult = { ok: true, value: { state: 'waiting' } }
  const remote = makeRemote({
    begin: [{ ok: true, value: { state: 'waiting', authUrl: 'u' } }],
  })
  remote.loginStatus = async () => {
    await sleep(1)
    return statusResult
  }
  const controller = new CommandCodeLoginController(() => remote, POLL_MS)
  try {
    void controller.begin()
    await waitForPhase(controller, 'waiting')
    statusResult = { ok: true, value: { state: 'failed', reason: 'invalid-key', message: 'whoami rejected' } }
    await waitForPhase(controller, 'failed')
    assert.equal(controller.state().reason, 'invalid-key')
    assert.equal(controller.state().message, 'whoami rejected')
  } finally {
    controller.dispose()
  }
})

test('an idle status mid-poll means the attempt is gone', async () => {
  let statusResult: LoginCallResult = { ok: true, value: { state: 'waiting', authUrl: 'u' } }
  const remote = makeRemote({
    begin: [{ ok: true, value: { state: 'waiting', authUrl: 'u' } }],
  })
  remote.loginStatus = async () => {
    await sleep(1)
    return statusResult
  }
  const controller = new CommandCodeLoginController(() => remote, POLL_MS)
  try {
    void controller.begin()
    await waitForPhase(controller, 'waiting')
    statusResult = { ok: true, value: { state: 'idle' } }
    await waitForPhase(controller, 'failed')
    assert.equal(controller.state().reason, 'cancelled')
  } finally {
    controller.dispose()
  }
})

test('a terminal state lets the next begin start a fresh, polling loop', async () => {
  let statusResult: LoginCallResult = { ok: true, value: { state: 'waiting', authUrl: 'old' } }
  const remote = makeRemote({
    begin: [
      { ok: true, value: { state: 'waiting', authUrl: 'first' } },
      { ok: true, value: { state: 'waiting', authUrl: 'second' } },
    ],
  })
  remote.loginStatus = async () => {
    await sleep(1)
    return statusResult
  }
  const controller = new CommandCodeLoginController(() => remote, POLL_MS)
  try {
    void controller.begin()
    await waitForPhase(controller, 'waiting')
    // The first attempt fails through its poll loop; the loop then stops.
    statusResult = { ok: true, value: { state: 'failed', reason: 'timeout', message: 'stale' } }
    await waitForPhase(controller, 'failed')
    assert.equal(controller.state().reason, 'timeout')
    // A fresh begin restarts cleanly and its own poll loop drives the outcome.
    void controller.begin()
    await waitForPhase(controller, 'waiting')
    assert.equal(controller.state().authUrl, 'second')
    statusResult = { ok: true, value: { state: 'success', userName: 'again' } }
    await waitForPhase(controller, 'success')
    assert.equal(controller.state().userName, 'again')
  } finally {
    controller.dispose()
  }
})

test('dispose stops polling and detaches listeners', async () => {
  const remote = makeRemote({
    begin: [{ ok: true, value: { state: 'waiting', authUrl: 'u' } }],
    status: [{ ok: true, value: { state: 'waiting', authUrl: 'u' } }],
  })
  const controller = new CommandCodeLoginController(() => remote, POLL_MS)
  void controller.begin()
  await waitForPhase(controller, 'waiting')
  const calls = remote.calls.length
  controller.dispose()
  await sleep(POLL_MS * 5)
  assert.ok(remote.calls.length <= calls + 1, 'polling stops after dispose')
})

// loginHint / loginFailureCopy (the shared login-row hint state machine)

/** A translate stub that echoes its key, so composed text is predictable. */
const echoT = ((key: string) => key) as (key: string) => string

function hintFor(phase: LoginPageState['phase'], extra: Partial<LoginPageState> = {}) {
  return loginHint({ phase, authUrl: undefined, userName: undefined, keyName: undefined, reason: undefined, message: undefined, ...extra }, echoT)
}

test('loginHint renders every phase with the matching class', () => {
  assert.deepEqual(hintFor('idle'), { text: 'loginHintIdle', className: 'cc-hint', title: undefined })
  assert.deepEqual(hintFor('starting'), { text: 'loginStarting', className: 'cc-hint', title: undefined })
  assert.deepEqual(hintFor('waiting'), { text: 'loginWaiting', className: 'cc-hint', title: undefined })
})

test('loginHint composes the success line with user and key name', () => {
  assert.deepEqual(
    hintFor('success', { userName: 'mars-sea' }),
    { text: 'loginSuccess mars-sea', className: 'cc-loginDone', title: undefined },
  )
  assert.deepEqual(
    hintFor('success', { userName: 'mars-sea', keyName: 'cli' }),
    { text: 'loginSuccess mars-sea · cli', className: 'cc-loginDone', title: undefined },
  )
})

test('loginFailureCopy maps every documented reason', () => {
  const reasons: Array<[CommandCodeLoginFailureReason, string]> = [
    ['denied', 'loginDenied'],
    ['timeout', 'loginTimeout'],
    ['invalid-key', 'loginInvalidKey'],
    ['network', 'loginNetwork'],
    ['unavailable', 'loginStoreFailed'],
    ['cancelled', 'loginCancelled'],
  ]
  for (const [reason, key] of reasons) {
    assert.equal(loginFailureCopy(reason, echoT), key)
  }
  assert.equal(loginFailureCopy(undefined, echoT), 'loginFailedGeneric')
  assert.equal(loginFailureCopy('error', echoT), 'loginFailedGeneric')
})

test('loginHint failed carries the secondary message as title', () => {
  assert.deepEqual(
    hintFor('failed', { reason: 'timeout', message: 'too slow' }),
    { text: 'loginTimeout', className: 'cc-loginError', title: 'too slow' },
  )
  assert.deepEqual(
    hintFor('failed', { reason: 'timeout' }),
    { text: 'loginTimeout', className: 'cc-loginError', title: undefined },
  )
})

test('loginHint unavailable appends the message to the hint text', () => {
  assert.deepEqual(
    hintFor('unavailable', { message: 'remote missing' }),
    { text: 'loginUnavailable remote missing', className: 'cc-loginError', title: undefined },
  )
  assert.deepEqual(
    hintFor('unavailable'),
    { text: 'loginUnavailable', className: 'cc-loginError', title: undefined },
  )
})
