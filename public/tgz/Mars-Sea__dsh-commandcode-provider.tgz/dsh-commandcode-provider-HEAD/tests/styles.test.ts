/**
 * Injected-stylesheet containment tests (node:test, zero deps). Run with
 * `npm test`.
 *
 * Both stylesheets are plain GLOBAL CSS, so every rule they carry can match
 * markup this plugin did not render — and one did (issue #48): a
 * `[class*="_footerActions"]` rule written for the sidebar's action row also
 * matched the ask-user-question dialog's button row and stacked its buttons.
 *
 * So containment is pinned in two layers: a STRUCTURAL audit (every compound of
 * every selector must be qualified by our own `cc-`/`ccp-` class, or be one of
 * the documented sidebar region anchors, and the shared `footerActions` stem
 * may only appear alongside the `footArea` anchor that scopes it), and a
 * SIMULATION — a miniature selector matcher against the real foreign class
 * stems, proving the dialog's row is not matched and the sidebar's still is.
 * The fixture is asserted to reproduce the old behaviour first, so the
 * simulation can never pass vacuously.
 *
 * Both sheets are imported from their modules, never re-typed here.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'

import { PAGE_CSS, PAGE_CSS_ID } from '../src/client/page-styles.ts'
import { PANEL_CSS, PANEL_CSS_ID } from '../src/client/panel-styles.ts'

// Selector parsing (the constrained subset these stylesheets use)

/** One declaration block, with the at-rule prelude it sits under. */
interface Rule {
  /** The comma-separated selector list, verbatim. */
  selector: string
  /** The declarations between the braces. */
  body: string
  /** Enclosing at-rule prelude (`@media …`), or null at the top level. */
  media: string | null
}

/** Drop `/* … *\/` comments. */
function stripComments(css: string): string {
  return css.replace(/\/\*[\s\S]*?\*\//g, '')
}

/**
 * Walk a stylesheet into flat rules. At-rules recurse instead of being treated
 * as rules, so a `@media` wrapper cannot hide a selector from the audit. Braces
 * inside declaration values would break this — the stylesheets have none (their
 * only URL is a percent-encoded SVG data URI).
 */
function parseRules(css: string): Rule[] {
  const out: Rule[] = []
  const walk = (text: string, media: string | null): void => {
    let i = 0
    while (i < text.length) {
      const open = text.indexOf('{', i)
      if (open < 0) break
      const prelude = text.slice(i, open).trim()
      let depth = 1
      let j = open + 1
      while (j < text.length && depth > 0) {
        if (text[j] === '{') depth += 1
        else if (text[j] === '}') depth -= 1
        j += 1
      }
      const body = text.slice(open + 1, j - 1)
      if (prelude.startsWith('@')) walk(body, prelude)
      else if (prelude !== '') out.push({ selector: prelude, body, media })
      i = j
    }
  }
  walk(stripComments(css), null)
  return out
}

/** One compound of a selector, with the combinator that precedes it. */
interface Part {
  compound: string
  /** `null` for the first compound, else `>` / `+` / `~` / ` ` (descendant). */
  combinator: string | null
}

/** Split a selector on its top-level combinators (brackets/parens/quotes aware). */
function splitParts(selector: string): Part[] {
  const parts: Part[] = []
  let buf = ''
  let depth = 0
  let quote = ''
  let pending: string | null = null
  const flush = (): void => {
    const compound = buf.trim()
    if (compound !== '') parts.push({ compound, combinator: pending })
    pending = null
    buf = ''
  }
  for (const ch of selector.trim()) {
    if (quote !== '') {
      buf += ch
      if (ch === quote) quote = ''
      continue
    }
    if (ch === '"' || ch === "'") {
      quote = ch
      buf += ch
      continue
    }
    if (ch === '[' || ch === '(') depth += 1
    if (ch === ']' || ch === ')') depth -= 1
    if (depth === 0 && (ch === '>' || ch === '+' || ch === '~')) {
      flush()
      pending = ch
      continue
    }
    if (depth === 0 && /\s/.test(ch)) {
      const hadBuf = buf.trim() !== ''
      flush()
      if (hadBuf && pending === null) pending = ' '
      continue
    }
    buf += ch
  }
  flush()
  return parts
}

/** A compound's class-substring attribute values: `[class*="x"]` → `x`. */
function attrStems(compound: string): string[] {
  return [...compound.matchAll(/\[\s*class\s*\*=\s*"([^"]*)"\s*\]/g)].map((m) => m[1] ?? '')
}

/** A compound's own classes and type selector, ignoring attributes/pseudos. */
function compoundParts(compound: string): { classes: string[]; type: string } {
  // Strip attribute selectors, then pseudos — including their parens (`:has(…)`,
  // `:not(…)`). Nested parens would need real parsing; none are used here.
  const rest = compound
    .replace(/\[[^\]]*\]/g, '')
    .replace(/::?[A-Za-z-]+(\([^)]*\))?/g, '')
  const classes = [...rest.matchAll(/\.([A-Za-z0-9_-]+)/g)].map((m) => m[1] ?? '')
  const type = rest.replace(/\.[A-Za-z0-9_-]+/g, '').trim()
  return { classes, type }
}

// Containment policy

/** Our own class namespaces: `cc-` (settings page) and `ccp-` (panel). */
const OWN_CLASS = /^(?:cc|ccp)-/

/**
 * The two sidebar class stems this plugin's stylesheet may reach, measured
 * against every client bundle of the 0.1.6-alpha.1 engine.
 *
 * `_footArea` is declared by `dsh-client-ui-sidebar` ALONE, which is why it is
 * the SCOPING anchor. `_footerActions` is NOT exclusive to it: the
 * ask-user-question dialog renders its button row with the same stem
 * (`Mbwy4a_footerActions`, issue #48), so it may only appear in a selector that
 * also requires that region ancestor.
 */
const REGION_STEM = '_footArea'
const SHARED_STEM = '_footerActions'
const FOREIGN_STEMS = new Set([REGION_STEM, SHARED_STEM])

/** Every complete selector in one stylesheet, flattened. */
function selectorsOf(css: string): { selector: string; rule: Rule }[] {
  return parseRules(css).flatMap((rule) =>
    rule.selector.split(',').map((selector) => ({ selector: selector.trim(), rule })),
  )
}

const SHEETS = [
  { name: 'PAGE_CSS', id: PAGE_CSS_ID, css: PAGE_CSS },
  { name: 'PANEL_CSS', id: PANEL_CSS_ID, css: PANEL_CSS },
]

// Structural audit: every compound is ours, or a documented region anchor

for (const sheet of SHEETS) {
  test(`${sheet.name}: every selector compound is qualified by one of our own classes or a documented sidebar anchor`, () => {
    const offenders: string[] = []
    for (const { selector } of selectorsOf(sheet.css)) {
      // Once a compound is qualified by one of our own classes, every compound
      // after it can only match inside our own markup, so an element like
      // `span` there is contained by the selector as a whole.
      let insideOwnSubtree = false
      for (const part of splitParts(selector)) {
        const { classes } = compoundParts(part.compound)
        const stems = attrStems(part.compound)
        const own = classes.some((name) => OWN_CLASS.test(name))
        // The documented region anchors: attribute-substring compounds naming
        // only sidebar stems this plugin is allowed to lay out.
        const anchored =
          stems.length > 0 && classes.length === 0 && stems.every((stem) => FOREIGN_STEMS.has(stem))
        if (!own && !anchored && !(insideOwnSubtree && classes.length === 0)) {
          offenders.push(`${selector}  →  ${part.compound}`)
        }
        if (own) insideOwnSubtree = true
      }
    }
    assert.deepEqual(
      offenders,
      [],
      `${sheet.name} carries selector compounds that can match foreign markup — qualify them with a cc-/ccp- class, or anchor them to the sidebar region and document them here:\n${offenders.join('\n')}`,
    )
  })

  test(`${sheet.name}: the shared footerActions stem is always scoped by the sidebar region anchor`, () => {
    const offenders: string[] = []
    for (const { selector } of selectorsOf(sheet.css)) {
      const parts = splitParts(selector)
      parts.forEach((part, index) => {
        if (!attrStems(part.compound).includes(SHARED_STEM)) return
        const scoped = parts
          .slice(0, index)
          .some((earlier) => attrStems(earlier.compound).includes(REGION_STEM))
        if (!scoped) offenders.push(selector)
      })
    }
    assert.deepEqual(
      offenders,
      [],
      `"${SHARED_STEM}" is declared by the ask-user-question dialog as well as the sidebar (issue #48), so a selector using it must also constrain an ancestor with "${REGION_STEM}":\n${offenders.join('\n')}`,
    )
  })
}

test('the two stylesheets carry distinct ids under the plugin package prefix', () => {
  assert.notEqual(PAGE_CSS_ID, PANEL_CSS_ID)
  for (const id of [PAGE_CSS_ID, PANEL_CSS_ID]) {
    assert.match(id, /^@mars-sea\/dsh-commandcode-provider\//)
  }
})

// Simulation: the real foreign class stems

/** A fixture element, with `ancestors[0]` as its parent. */
interface Element {
  tag: string
  classes: string[]
  ancestors: Element[]
}

function el(tag: string, classes: string[], ancestors: Element[] = []): Element {
  return { tag, classes, ancestors }
}

/**
 * The ask-user-question dialog's card as `dsh-client-ui-user-questions` renders
 * it (measured on 0.1.6-alpha.1): `div.frame > section.card > footer.footer`,
 * whose `div.footerActions` holds the next/submit buttons beside `div.pager` —
 * a side-by-side `display:flex` row with NO `flex-direction`, which is what the
 * plugin's rule overrode. The hash prefixes are a measurement too; the rule keys
 * on the STEMS, so a re-hash does not invalidate the fixture.
 */
const ASK_DIALOG_FRAME = el('div', ['Mbwy4a_frame'])
const ASK_DIALOG_CARD = el('section', ['Mbwy4a_card'], [ASK_DIALOG_FRAME])
const ASK_DIALOG_FOOTER = el('footer', ['Mbwy4a_footer'], [ASK_DIALOG_CARD])
const ASK_DIALOG_ROW = el('div', ['Mbwy4a_footerActions'], [ASK_DIALOG_FOOTER])

/** The sidebar shell's foot area and the action row inside it (`footArea` is its direct parent). */
const SIDEBAR_FOOT_AREA = el('div', ['hHd-Xa_footArea'])
const SIDEBAR_ROW = el('div', ['hHd-Xa_footerActions'], [SIDEBAR_FOOT_AREA])

/** Match one compound: attributes, own classes, and the type selector. */
function matchCompound(element: Element, compound: string): boolean {
  const stems = attrStems(compound)
  if (!stems.every((stem) => element.classes.some((name) => name.includes(stem)))) return false
  const { classes, type } = compoundParts(compound)
  if (!classes.every((name) => element.classes.includes(name))) return false
  if (type !== '' && type !== element.tag) return false
  // State pseudos (`:hover`, `:checked`, `:has(…)`) are treated as satisfied:
  // they refine WHEN a rule applies, not WHICH elements it can reach, and this
  // matcher is only ever asked whether a selector can reach foreign markup.
  return true
}

/** Can `selector` match `element`? Right-to-left, with real ancestor walks. */
function matches(element: Element, selector: string): boolean {
  const parts = splitParts(selector)
  const at = (current: Element | undefined, index: number): boolean => {
    if (index < 0) return true
    if (current === undefined) return false
    if (!matchCompound(current, parts[index]!.compound)) return false
    if (index === 0) return true
    const combinator = parts[index]!.combinator
    if (combinator === '>') return at(current.ancestors[0], index - 1)
    if (combinator === '+') return false // no adjacent-sibling selectors are shipped
    return current.ancestors.some((ancestor) => at(ancestor, index - 1))
  }
  return at(element, parts.length - 1)
}

test('the fixture reproduces issue #48: the unanchored selector did match the dialog row', () => {
  // The bug in one line. If this ever stops being true the fixture — not the
  // fix — has gone stale, and the assertions below would pass vacuously.
  assert.equal(matches(ASK_DIALOG_ROW, '[class*="_footerActions"]'), true)
  assert.equal(matches(SIDEBAR_ROW, '[class*="_footerActions"]'), true)
})

for (const sheet of SHEETS) {
  test(`${sheet.name}: no selector matches the ask-user-question dialog's button row`, () => {
    const matching = selectorsOf(sheet.css)
      .map(({ selector }) => selector)
      .filter((selector) => matches(ASK_DIALOG_ROW, selector))
    assert.deepEqual(
      matching,
      [],
      `${sheet.name} styles the ask-user-question dialog's footer row, which is official component markup (issue #48):\n${matching.join('\n')}`,
    )
  })
}

test('the sidebar action row is still forced into a column', () => {
  const matching = parseRules(PANEL_CSS).filter((entry) =>
    entry.selector.split(',').some((selector) => matches(SIDEBAR_ROW, selector.trim())),
  )
  assert.ok(
    matching.length > 0,
    'no rule matches the sidebar footer-action row — the wide card would overflow the column',
  )
  assert.ok(
    matching.some((rule) => /flex-direction:\s*column/.test(rule.body)),
    'the rule that reaches the sidebar action row no longer forces it into a column',
  )
  // ...and none of them may also reach the dialog row: that is the entire point
  // of anchoring the rule to the sidebar's foot area.
  for (const rule of matching) {
    assert.equal(matches(ASK_DIALOG_ROW, rule.selector), false, rule.selector)
  }
})

// Settings-page motion and hover policy (2026-10-29)

const PAGE_RULES = parseRules(PAGE_CSS)
const HOVER_MEDIA = '@media (hover:hover) and (pointer:fine)'
const REDUCED_MEDIA = '@media (prefers-reduced-motion:reduce)'

test('PAGE_CSS: every :hover rule sits in the fine-pointer hover block, so a tap leaves no stuck hover colour', () => {
  const offenders = PAGE_RULES.filter((rule) => rule.selector.includes(':hover') && rule.media !== HOVER_MEDIA)
    // A cursor change cannot stick on touch, so it may stay outside the block.
    .filter((rule) => rule.body.trim() !== 'cursor:pointer')
    .map((rule) => rule.selector)
  assert.deepEqual(offenders, [])
})

test('PAGE_CSS: press feedback stays outside the hover block and every scale is undone under reduced motion', () => {
  const pressed = PAGE_RULES.filter((rule) => rule.selector.includes(':active') && /transform:scale\(/.test(rule.body))
  assert.ok(pressed.length >= 4, 'buttons, segments, icon and reset buttons each scale on press')
  for (const rule of pressed) assert.equal(rule.media, null, rule.selector)
  const undone = PAGE_RULES.filter((rule) => rule.media === REDUCED_MEDIA && /transform:none/.test(rule.body))
    .flatMap((rule) => rule.selector.split(',').map((selector) => selector.trim()))
  for (const selector of pressed.flatMap((rule) => rule.selector.split(',').map((part) => part.trim()))) {
    assert.ok(undone.includes(selector), `${selector} still scales under prefers-reduced-motion`)
  }
})

test('PAGE_CSS: transitions name their properties and never animate layout', () => {
  const offenders = PAGE_RULES.flatMap((rule) =>
    [...rule.body.matchAll(/transition:([^;]+)/g)].flatMap((m) =>
      (m[1] ?? '').split(',').map((part) => part.trim().split(/\s+/)[0] ?? '')
        .filter((prop) => /^(?:all|width|height|padding|margin|top|left|right|bottom)$/.test(prop))
        .map((prop) => `${rule.selector} → ${prop}`),
    ),
  )
  assert.deepEqual(offenders, [])
})

test('PAGE_CSS: an invalid field keeps its error border under the pointer', () => {
  const block = PAGE_RULES.filter((rule) => rule.media === HOVER_MEDIA).map((rule) => rule.selector)
  const plain = block.findIndex((selector) => selector.includes('.cc-fieldInput:hover:not(:disabled)'))
  const invalid = block.findIndex((selector) => selector.includes('.cc-fieldInputInvalid:hover:not(:disabled)'))
  assert.ok(plain >= 0 && invalid > plain, 'the invalid hover border must follow the plain one at equal specificity')
  assert.ok(block[invalid]!.includes('.cc-unitBoxInvalid:hover'))
})
