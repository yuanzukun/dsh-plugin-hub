/**
 * Plans & quota panel projection tests (node:test, zero deps). Run with `npm test`.
 *
 * The panel is the sidebar footer card + the center dashboard, and its whole
 * user-visible truth is one projection (`buildPanelView`), driven here from
 * hand-built usage snapshots plus the shared auto-refresh loop.
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'

import {
  PANEL_AUTO_REFRESH_MS,
  buildPanelView,
  resetPanelAutoRefresh,
  startPanelAutoRefresh,
  type AutoRefreshTimer,
} from '../src/client/panel.ts'
import type { UsagePageState } from '../src/client/usage.ts'
import { PANEL_COPY_EN, PANEL_COPY_ZH, PANEL_KEYS } from '../src/client/panel-copy.ts'
import type { CommandCodeAccountUsage } from '../src/usage-wire.ts'
import type { CommandCodeUsageReport } from '../src/adapter.ts'

/** One account entry with only the fields a test cares about spelled out. */
function entry(overrides: {
  id?: string
  label?: string
  active?: boolean
  configured?: boolean
  mark?: string
  cooldownUntil?: number
  report?: Partial<CommandCodeUsageReport>
} = {}): CommandCodeAccountUsage {
  return {
    id: overrides.id ?? 'default',
    label: overrides.label ?? 'Default',
    configured: overrides.configured ?? true,
    active: overrides.active ?? true,
    mark: overrides.mark ?? '',
    cooldownUntil: overrides.cooldownUntil ?? 0,
    report: {
      failures: [],
      ...overrides.report,
    } as CommandCodeUsageReport,
  }
}

function usage(overrides: Partial<UsagePageState> = {}): UsagePageState {
  return {
    status: 'ready',
    report: { accounts: [] },
    error: undefined,
    fetchedAt: undefined,
    ...overrides,
  }
}

const CREDITS = {
  monthlyCredits: 60,
  purchasedCredits: 5,
  freeCredits: 2,
  fiveHour: { used: 3, cap: 3, exceeded: true, resetAt: 0 },
  weekly: { used: 1.32, cap: 6, exceeded: false, resetAt: 0 },
}

test('credential-reference absence alone does not rule out Host fallback keys', () => {
  const view = buildPanelView({ usage: usage(), apiKeyConfigured: false })
  assert.equal(view.noKey, false)
  assert.equal(view.accounts.length, 0)
})

test('the panel follows the injected translator, so it reads in the harness language', () => {
  const input = {
    usage: usage({ report: { accounts: [entry({ report: { credits: CREDITS } })] } }),
    apiKeyConfigured: true,
  }
  // No translator: the English fallback an engine without a locale face would
  // render. Every label is resolved through it, not looked up here.
  const english = buildPanelView(input)
  assert.equal(english.text.monthly, 'Monthly')
  assert.ok(english.footTitle.includes('5-hour'), english.footTitle)

  const chinese = buildPanelView({ ...input, t: (key) => PANEL_COPY_ZH[key] })
  assert.equal(chinese.text.monthly, '月额度')
  // The tooltip is composed INSIDE the projection, so a translator that only
  // reached `text` would leave it English.
  assert.ok(chinese.footTitle.includes('5 小时'), chinese.footTitle)
  assert.ok(!chinese.footTitle.includes('5-hour'), chinese.footTitle)
  assert.deepEqual(chinese.footerBars.map((bar) => bar.detail), english.footerBars.map((bar) => bar.detail))

  // `status` is composed in the projection too: only a non-active mark reaches
  // it (an active account shows its plan).
  const cooling = {
    usage: usage({ report: { accounts: [entry({ active: false, mark: 'rate-limit' })] } }),
    apiKeyConfigured: true,
  }
  assert.equal(buildPanelView(cooling).status, 'Cooling down')
  assert.equal(buildPanelView({ ...cooling, t: (key) => PANEL_COPY_ZH[key] }).status, '限额冷却中')
})

test('the zh and en panel dictionaries carry exactly the same keys', () => {
  assert.deepEqual(Object.keys(PANEL_COPY_ZH).sort(), Object.keys(PANEL_COPY_EN).sort())
  assert.deepEqual(PANEL_KEYS, Object.keys(PANEL_COPY_EN))
})

test('a first fetch with no data renders the loading state', () => {
  const view = buildPanelView({
    usage: usage({ status: 'loading', report: undefined }),
    apiKeyConfigured: true,
  })
  assert.equal(view.loading, true)
  assert.equal(view.noKey, false)
})

test('accounts are deduplicated by id', () => {
  const view = buildPanelView({
    usage: usage({
      report: {
        accounts: [
          entry({ id: 'default', label: 'A' }),
          entry({ id: 'default', label: 'A again' }),
          entry({ id: 'COMMANDCODE_API_KEY_2', label: 'B' }),
        ],
      },
    }),
    apiKeyConfigured: true,
  })
  assert.deepEqual(view.accounts.map((account) => account.id), ['default', 'COMMANDCODE_API_KEY_2'])
})

test('the panel opens on the serving account, not the first one', () => {
  const view = buildPanelView({
    usage: usage({
      report: {
        accounts: [
          entry({ id: 'default', active: false }),
          entry({ id: 'COMMANDCODE_API_KEY_2', active: true, label: 'Second' }),
        ],
      },
    }),
    apiKeyConfigured: true,
  })
  assert.equal(view.selectedId, 'COMMANDCODE_API_KEY_2')
  assert.equal(view.selected?.label, 'Second')
})

test('an over-cap window keeps its true percentage and clamps only the bar', () => {
  const view = buildPanelView({
    usage: usage({
      report: { accounts: [entry({ report: { credits: { ...CREDITS, fiveHour: { used: 4.5, cap: 3, exceeded: true, resetAt: 0 } } } })] },
    }),
    apiKeyConfigured: true,
  })
  const fiveHour = view.selected?.windows.find((window) => window.label === 'fiveHour')
  assert.ok(fiveHour)
  assert.equal(fiveHour.percent, 150)
  assert.equal(fiveHour.barPercent, 100)
  assert.equal(fiveHour.exceeded, true)
})

test('the footer card stacks 5-hour then weekly, and leaves uncapped windows out', () => {
  const view = buildPanelView({
    usage: usage({ report: { accounts: [entry({ report: { credits: CREDITS } })] } }),
    apiKeyConfigured: true,
  })
  assert.deepEqual(view.footerBars.map((bar) => bar.label), ['fiveHourShort', 'weeklyShort'])
  assert.equal(view.footerBars[0]?.percent, '100%')
  assert.equal(view.footerBars[0]?.warn, true)
  assert.equal(view.footerBars[0]?.detail, '$3.00 / $3.00')
  assert.equal(view.footerBars[1]?.percent, '22%')
  assert.equal(view.footerBars[1]?.warn, false)

  const uncapped = buildPanelView({
    usage: usage({
      report: {
        accounts: [entry({ report: { credits: { ...CREDITS, weekly: { used: 1, cap: 0, exceeded: false, resetAt: 0 } } } })],
      },
    }),
    apiKeyConfigured: true,
  })
  assert.deepEqual(uncapped.footerBars.map((bar) => bar.label), ['fiveHourShort'])
})

test('the accessible footer title carries the visible figures', () => {
  const view = buildPanelView({
    usage: usage({
      report: {
        accounts: [entry({
          report: {
            credits: CREDITS,
            plan: { planId: 'individual-pro', name: 'Pro', status: 'active', monthlyCredits: 60, currentPeriodEnd: 0 },
            usage: {
              totalCount: 12,
              totalCost: 1.32,
              successRate: 99.9,
              completedCount: 11,
              failedCount: 1,
              totalCredits: 1.4,
              totalTokensIn: 1000,
              totalTokensOut: 200,
              periodBasis: 'billing-period',
            },
          },
        })],
      },
    }),
    apiKeyConfigured: true,
  })
  assert.match(view.footTitle, /^Command Code · Pro/)
  assert.match(view.footTitle, /5-hour \$3\.00 \/ \$3\.00 \(100%\)/)
  assert.match(view.footTitle, /Weekly \$1\.32 \/ \$6\.00 \(22%\)/)
  assert.match(view.footTitle, /\$1\.32/)
  assert.equal(view.planName, 'Pro')
})

test('官方汇总显示请求总数，仅在汇总与订阅起点一致时标明完整账期', () => {
  const start = Date.parse('2026-09-19T10:15:00Z')
  const end = Date.parse('2026-10-19T10:15:00Z')
  const report: CommandCodeUsageReport = {
    failures: [],
    plan: { planId: 'individual-pro', name: 'Pro', status: 'active', monthlyCredits: 60, currentPeriodStart: start, currentPeriodEnd: end },
    usage: { totalCount: 12, completedCount: 9, failedCount: 2, totalCost: 1.32, totalCredits: 1.4, totalTokensIn: 1000, totalTokensOut: 200, successRate: 75, periodBasis: 'billing-period', periodStart: start },
  }
  const view = () => buildPanelView({ usage: usage({ report: { accounts: [entry({ report })] } }), apiKeyConfigured: true, t: key => PANEL_COPY_ZH[key] }).selected!
  assert.equal(view().stats.find(stat => stat.label === 'requests')?.value, '12')
  assert.equal(view().stats.find(stat => stat.label === 'requests')?.sub, '9 成功 / 2 失败')
  assert.equal(view().usagePeriod, `官方账期用量 ${new Date(start).toLocaleDateString()} – ${new Date(end).toLocaleDateString()}`)
  report.usage!.periodStart = start + 1000
  assert.equal(view().usagePeriod, '官方用量汇总，统计周期未确认')
  delete report.usage!.periodStart
  assert.equal(view().usagePeriod, '官方用量汇总，统计周期未确认')
  report.usage!.periodStart = start
  delete report.plan!.currentPeriodStart
  assert.equal(view().usagePeriod, '官方用量汇总，统计周期未确认')
  report.plan!.currentPeriodStart = start
  report.plan!.currentPeriodEnd = start
  assert.equal(view().usagePeriod, '官方用量汇总，统计周期未确认')
})

test('monthly consumption is the CLI\'s limit-minus-remaining derivation', () => {
  // The fixture makes the two halves DIFFERENT on purpose: the plan publishes a
  // 30-credit limit while the billing endpoint reports 8.68 left. A fixture
  // where `remaining === limit` would let a hardcoded `$0.00` pass unchanged.
  const view = buildPanelView({
    usage: usage({
      report: {
        accounts: [entry({
          report: {
            credits: { ...CREDITS, monthlyCredits: 8.68 },
            plan: { planId: 'individual-pro', name: 'Pro', status: 'active', monthlyCredits: 30, currentPeriodEnd: 0 },
          },
        })],
      },
    }),
    apiKeyConfigured: true,
  })
  const monthly = view.selected?.monthly
  assert.ok(monthly)
  assert.equal(monthly.known, true)
  assert.equal(monthly.limit, '$30.00')
  // 30 credit limit minus the 8.68 the billing endpoint reported left.
  assert.equal(monthly.used, '$21.32')
  assert.equal(monthly.remaining, '$8.68')
  assert.equal(monthly.percent, 71)
  assert.equal(monthly.exhausted, false)
  assert.equal(monthly.purchased, '$5.00')
  assert.equal(monthly.free, '$2.00')
})

test('a billing endpoint that reported nothing never reads as a consumed quota', () => {
  // The regression this pins: `/alpha/billing/credits` is one of four endpoints
  // fetched in parallel, so it fails ON ITS OWN while the plan still arrives.
  // Reading the absent balance as 0 turned that partial failure into a confident
  // "100% used, quota exhausted".
  const view = buildPanelView({
    usage: usage({
      report: {
        accounts: [entry({
          report: {
            plan: { planId: 'individual-pro', name: 'Pro', status: 'active', monthlyCredits: 30, currentPeriodEnd: 0 },
            failures: ['/alpha/billing/credits: service unavailable'],
          },
        })],
      },
    }),
    apiKeyConfigured: true,
  })
  const monthly = view.selected?.monthly
  assert.ok(monthly)
  // No ratio, no bar, and above all no "exhausted".
  assert.equal(monthly.known, false)
  assert.equal(monthly.exhausted, false)
  assert.equal(monthly.percent, 0)
  assert.equal(monthly.barPercent, 0)
  // Unreported figures read as a dash, never as a zero.
  assert.equal(monthly.remaining, '—')
  assert.equal(monthly.used, '—')
  // The plan's own limit IS known from the subscriptions endpoint, so it shows.
  assert.equal(monthly.limit, '$30.00')
})

test('an explicit unreported flag dashes the balance while an absent flag does not', () => {
  const base = {
    plan: { planId: 'individual-pro', name: 'Pro', status: 'active', monthlyCredits: 30, currentPeriodEnd: 0 },
  }
  const unreported = buildPanelView({
    usage: usage({
      report: {
        accounts: [entry({
          report: { ...base, credits: { ...CREDITS, monthlyCredits: 0, monthlyReported: false } },
        })],
      },
    }),
    apiKeyConfigured: true,
  }).selected?.monthly
  assert.ok(unreported)
  assert.equal(unreported.known, false)
  assert.equal(unreported.exhausted, false)
  assert.equal(unreported.remaining, '—')

  // `undefined` is a Host half older than the flag, which always sent a real
  // number: it keeps rendering instead of dashing every balance.
  const legacy = buildPanelView({
    usage: usage({
      report: {
        accounts: [entry({ report: { ...base, credits: { ...CREDITS, monthlyCredits: 0 } } })],
      },
    }),
    apiKeyConfigured: true,
  }).selected?.monthly
  assert.ok(legacy)
  assert.equal(legacy.known, true)
  assert.equal(legacy.remaining, '$0.00')
  // A genuine zero balance IS an exhausted plan, and still says so.
  assert.equal(legacy.exhausted, true)
})

test('only the quota windows the endpoint reported get a row', () => {
  const unlimited = buildPanelView({
    usage: usage({
      report: {
        accounts: [entry({ report: { credits: { monthlyCredits: 5, purchasedCredits: 0, freeCredits: 0 } } })],
      },
    }),
    apiKeyConfigured: true,
  }).selected
  assert.ok(unlimited)
  // No windowLimits at all: an unlimited plan. Drawing two zeroed rows for it
  // would invent limits the account does not have.
  assert.deepEqual(unlimited.windows, [])

  // A window that WAS reported with a zero cap is uncapped spend, not an absent
  // window, and it keeps its row.
  const uncapped = buildPanelView({
    usage: usage({
      report: {
        accounts: [entry({
          report: {
            credits: {
              monthlyCredits: 5,
              purchasedCredits: 0,
              freeCredits: 0,
              fiveHour: { used: 2.4, cap: 0, exceeded: false, resetAt: 0 },
            },
          },
        })],
      },
    }),
    apiKeyConfigured: true,
  }).selected
  assert.ok(uncapped)
  assert.equal(uncapped.windows.length, 1)
  assert.equal(uncapped.windows[0]?.capped, false)
  // Spend only, with no `used / cap` it does not have; the row's percentage
  // label reads "unlimited" instead of a fabricated 0%.
  assert.equal(uncapped.windows[0]?.value, '$2.40')
})

test('an unknown limit draws no percentage rather than inventing a denominator', () => {
  const view = buildPanelView({
    usage: usage({
      report: {
        accounts: [entry({
          report: {
            credits: CREDITS,
            plan: { planId: 'individual-unknown', name: 'Unknown', status: 'active', monthlyCredits: null, currentPeriodEnd: 0 },
          },
        })],
      },
    }),
    apiKeyConfigured: true,
  })
  const monthly = view.selected?.monthly
  assert.ok(monthly)
  // No denominator means no ratio: the view reports `known: false` and a zero
  // percentage, so the dashboard draws no bar instead of a fabricated 100%.
  assert.equal(monthly.known, false)
  assert.equal(monthly.percent, 0)
  assert.equal(monthly.barPercent, 0)
  assert.equal(monthly.exhausted, false)
  // The balances the billing endpoint did report still render.
  assert.equal(monthly.purchased, '$5.00')
  assert.equal(monthly.free, '$2.00')
})

test('an exhausted plan and a cooling-down account both read as states', () => {
  const view = buildPanelView({
    usage: usage({
      report: {
        accounts: [entry({
          active: false,
          mark: 'rate-limit',
          cooldownUntil: 1_700_000_000_000,
          report: {
            credits: { ...CREDITS, monthlyCredits: 0 },
            plan: { planId: 'individual-pro', name: 'Pro', status: 'active', monthlyCredits: 60, currentPeriodEnd: 0 },
          },
        })],
      },
    }),
    apiKeyConfigured: true,
  })
  assert.equal(view.selected?.mark, 'coolingDown')
  assert.notEqual(view.selected?.cooldownUntil, '')
  assert.equal(view.selected?.monthly?.exhausted, true)
})

test('a 401 across every endpoint surfaces the invalid-key box, not a generic error', () => {
  const view = buildPanelView({
    usage: usage({
      status: 'error',
      report: { accounts: [entry({ report: { failures: ['credits: 401'], blocked: 'invalid-key' } })] },
    }),
    apiKeyConfigured: true,
  })
  assert.equal(view.failure?.title, 'errorInvalidKey')
  assert.equal(view.failure?.hint, 'errorInvalidKeyHint')
})

test('a received but unreadable response does not claim the network is down', () => {
  const view = buildPanelView({
    usage: usage({
      status: 'ready',
      report: { accounts: [entry({ report: { failures: ['/alpha/whoami: HTTP 200 returned an unreadable body'], blocked: 'invalid-response' } })] },
    }),
    apiKeyConfigured: true,
  })
  assert.equal(view.failure?.title, 'errorInvalidResponse')
  assert.equal(view.failure?.hint, 'errorInvalidResponseHint')
})

test('a blocked verdict carries the endpoint messages as its detail', () => {
  // ONE verdict ('network') covers a real outage, a per-request timeout, a key
  // no HTTP header can carry and an unparseable API base, so the per-endpoint
  // messages — the only place the cause is named — ride along as the detail.
  const view = buildPanelView({
    usage: usage({
      status: 'ready',
      report: {
        accounts: [entry({
          report: {
            blocked: 'network',
            failures: ['/alpha/whoami: fetch failed', '/alpha/billing/credits: The operation was aborted due to timeout'],
          },
        })],
      },
    }),
    apiKeyConfigured: true,
  })
  assert.equal(view.failure?.title, 'errorNetwork')
  assert.match(view.failure?.detail ?? '', /^\/alpha\/whoami: fetch failed · /)
  assert.match(view.failure?.detail ?? '', /aborted due to timeout/)
})

test('a transport failure with no report renders the generic box with its reason', () => {
  const view = buildPanelView({
    usage: usage({ status: 'error', report: undefined, error: 'commandcode/report remote is not mounted' }),
    apiKeyConfigured: true,
  })
  assert.equal(view.failure?.title, 'errorGeneric')
  assert.equal(view.failure?.detail, 'commandcode/report remote is not mounted')
})

test('a failed refetch keeps the last good data on screen as stale', () => {
  const view = buildPanelView({
    usage: usage({
      status: 'error',
      error: 'network down',
      report: { accounts: [entry({ report: { credits: CREDITS } })] },
    }),
    apiKeyConfigured: true,
  })
  assert.equal(view.staleError, 'network down')
  assert.equal(view.accounts.length, 1)
  assert.equal(view.failure, undefined)
})

test('every string the view references exists in the copy table', () => {
  const view = buildPanelView({
    usage: usage({ report: { accounts: [entry({ report: { credits: CREDITS } })] } }),
    apiKeyConfigured: true,
  })
  const referenced = [
    ...view.footerBars.map((bar) => bar.label),
    ...(view.selected?.windows.map((window) => window.label) ?? []),
    ...(view.selected?.stats.map((stat) => stat.label) ?? []),
  ]
  for (const key of referenced) {
    assert.equal(typeof view.text[key], 'string', `${key} must render text, not a raw key`)
    assert.notEqual(view.text[key], '')
  }
})

// startPanelAutoRefresh

/** A timer seam that records schedules and lets a test fire them by hand. */
function fakeTimer(): AutoRefreshTimer & { fire(): void; pending(): number } {
  let callback: (() => void) | undefined
  let handle: unknown
  return {
    set(next: () => void): unknown {
      callback = next
      handle = {}
      return handle
    },
    clear(target: unknown): void {
      if (target === handle) {
        callback = undefined
        handle = undefined
      }
    },
    fire(): void {
      const next = callback
      callback = undefined
      next?.()
    },
    pending(): number {
      return callback === undefined ? 0 : 1
    },
  }
}

test('the auto-refresh loop fetches on mount, ticks, and stops on the last unmount', () => {
  resetPanelAutoRefresh()
  const timer = fakeTimer()
  let refreshes = 0
  const source = {
    state: () => usage(),
    refresh: async () => {
      refreshes += 1
    },
  }

  const stop = startPanelAutoRefresh(source, () => true, timer)
  assert.equal(refreshes, 1, 'the row must be current on arrival, not after a tick')
  assert.equal(timer.pending(), 1)

  timer.fire()
  assert.equal(refreshes, 2)
  assert.equal(timer.pending(), 1, 'the loop reschedules itself')

  stop()
  assert.equal(timer.pending(), 0)
  resetPanelAutoRefresh()
})

test('an unconfigured account is never polled, and a later key starts it', () => {
  resetPanelAutoRefresh()
  const timer = fakeTimer()
  let refreshes = 0
  let configured = false
  const source = {
    state: () => usage(),
    refresh: async () => {
      refreshes += 1
    },
  }

  const stop = startPanelAutoRefresh(source, () => configured, timer)
  assert.equal(refreshes, 0, 'no key means nothing to fetch')

  // The configuration fact is re-read per tick, so a key pasted mid-session
  // starts fresh data without re-registering the surface.
  configured = true
  timer.fire()
  assert.equal(refreshes, 1)

  stop()
  resetPanelAutoRefresh()
})

test('two mounted surfaces share one loop and one fetch', () => {
  resetPanelAutoRefresh()
  const timer = fakeTimer()
  let refreshes = 0
  const source = {
    state: () => usage(),
    refresh: async () => {
      refreshes += 1
    },
  }

  const stopSidebar = startPanelAutoRefresh(source, () => true, timer)
  const stopDashboard = startPanelAutoRefresh(source, () => true, timer)
  assert.equal(refreshes, 1, 'the second mount joins the running loop')

  // The surface that started the loop unmounting first must not stop it while
  // the other is still mounted.
  stopSidebar()
  timer.fire()
  assert.equal(refreshes, 2)

  stopDashboard()
  assert.equal(timer.pending(), 0)
  assert.equal(PANEL_AUTO_REFRESH_MS, 120_000)
  resetPanelAutoRefresh()
})

test('面板的自动刷新走 auto 路径，显式刷新不受影响', () => {
  // 面板首屏与后台 tick 都不是用户点的：它们和账户卡片问的是同一个问题，
  // 所以必须走可以合并的自动路径。按钮/保存那条路径由 startPanelAutoRefresh
  // 之外调用 refresh()，不接受任何合并。
  resetPanelAutoRefresh()
  const timer = fakeTimer()
  const modes: Array<{ auto?: boolean } | undefined> = []
  const source = {
    state: () => usage(),
    refresh: async (options?: { auto?: boolean }) => {
      modes.push(options)
    },
  }
  const stop = startPanelAutoRefresh(source, () => true, timer)
  timer.fire()
  assert.deepEqual(modes, [{ auto: true }, { auto: true }], '首屏与 tick 都必须标记为自动')
  stop()
  resetPanelAutoRefresh()
})

test('隐藏的页面不再轮询，重新可见时立刻补读一次', () => {
  // 后台标签页的 React 树仍然挂载着，若不看可见性，它就会为一个没人看的页面
  // 每两分钟付四次上游调用。tick 照旧重排（循环不能断），但隐藏时跳过读取；
  // 重新可见是唯一「已知数据已过期」的时刻，所以要立即补读。
  resetPanelAutoRefresh()
  const timer = fakeTimer()
  let refreshes = 0
  let visible = false
  let notify: (() => void) | undefined
  const visibility = {
    isVisible: () => visible,
    subscribe: (onChange: () => void) => { notify = onChange; return () => { notify = undefined } },
  }
  const source = {
    state: () => usage(),
    refresh: async () => {
      refreshes += 1
    },
  }
  const stop = startPanelAutoRefresh(source, () => true, timer, visibility)
  // 首屏无条件读取：那一刻行刚要出现，没有数据就没得显示。
  assert.equal(refreshes, 1, '首屏必须读一次，哪怕此刻不可见')

  timer.fire()
  assert.equal(refreshes, 1, '隐藏时的 tick 不发起读取')
  assert.equal(timer.pending(), 1, '循环必须继续重排，否则恢复可见后也不会再跑')

  visible = true
  notify?.()
  assert.equal(refreshes, 2, '重新可见要立刻补读一次')

  timer.fire()
  assert.equal(refreshes, 3, '可见后 tick 恢复读取')

  // 停止后必须解绑可见性监听，否则重挂载会累积监听。
  stop()
  assert.equal(notify, undefined)
  resetPanelAutoRefresh()
})

test('omitted purchased and free balances remain unknown while explicit zero is shown', () => {
  const view = buildPanelView({ apiKeyConfigured: false, usage: usage({ report: { accounts: [entry({ report: {
    credits: { ...CREDITS, purchasedCredits: 0, freeCredits: 0, purchasedReported: true, freeReported: false },
  } })] } }) })
  assert.equal(view.noKey, false, 'Host-resolved literal or CLI keys override an absent browser credential ref')
  assert.equal(view.accounts[0]?.monthly?.purchased, '$0.00')
  assert.equal(view.accounts[0]?.monthly?.free, '—')
  const missing = buildPanelView({ apiKeyConfigured: true, usage: usage({ report: { accounts: [entry({ configured: false })] } }) })
  assert.equal(missing.noKey, true, 'only the Host can establish that no usable key exists')
})

test('启动者先卸载时可见性监听也必须解绑，任意卸载顺序都不泄漏', () => {
  // 只有启动循环的那次 start 拿到订阅句柄，但它不一定是最后卸载的 surface。
  // 句柄若留在函数局部，启动者先停就永远走不到解绑分支，监听随挂载周期累积。
  resetPanelAutoRefresh()
  const timer = fakeTimer()
  let subscribes = 0
  let unsubscribes = 0
  const visibility = {
    isVisible: () => true,
    subscribe: () => { subscribes += 1; return () => { unsubscribes += 1 } },
  }
  const source = { state: () => usage(), refresh: async () => {} }
  const stopStarter = startPanelAutoRefresh(source, () => true, timer, visibility)
  const stopSecond = startPanelAutoRefresh(source, () => true, timer, visibility)
  assert.equal(subscribes, 1, '只有启动循环的那次订阅')
  stopStarter()
  stopSecond()
  assert.equal(unsubscribes, 1, '任意卸载顺序都必须解绑一次')
  resetPanelAutoRefresh()
})
