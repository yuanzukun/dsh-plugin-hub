# Third-party notices

## DeepSeek Harness icon

The files below are derived from the favicon distributed with
`@deepseek-ai/dsh-web-frontend`:

- `assets/deepseek-black.svg`
- `assets/deepseek-black.png`
- `assets/deepseek-black.ico`
- `assets/dsh-web-launcher-whale-rounded.ico`

Source project: [deepseek-ai/deepseek-harness](https://github.com/deepseek-ai/deepseek-harness),
`apps/web/dist/favicon.svg` (distributed in the npm package under `dist/favicon.svg`).

The source package declares the MIT License:

> Copyright (c) 2026 DeepSeek

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

DeepSeek and related marks belong to their respective owners. This independent
launcher is not an official DeepSeek product.
