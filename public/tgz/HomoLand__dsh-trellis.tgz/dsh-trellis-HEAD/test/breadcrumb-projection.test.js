import { test } from "node:test";
import assert from "node:assert/strict";
import { readFile, readdir } from "node:fs/promises";
import { createUserMessage } from "@deepseek-ai/dsh-llm";
import { breadcrumbMessage } from "../lib/breadcrumb.js";
import {
  BREADCRUMB_PROJECTION_KEY as KEY,
  breadcrumbFingerprint,
  breadcrumbProjection,
  registerBreadcrumbProjection,
} from "../lib/breadcrumb-projection.js";
import { sessionRuntime } from "./helpers/session-runtime.js";

const crumb = (digest = "A", maxBytes = 4096) => breadcrumbMessage(
  { status: "no_task", taskPath: null, body: `Workflow ${digest}`, digest },
  maxBytes,
);
const user = (text) => createUserMessage({ content: [{ type: "text", text }] });
const append = (session, message) => session.append("user/message", message, { surfaceOp: "append" });
const replace = (session, seqs, message = user("Compacted history")) =>
  session.append("user/message", message, {
    surfaceOp: { op: "replace", startSeq: seqs[0], endSeq: seqs.at(-1) },
    sourceEventSeqs: seqs,
  });

test("projection ignores unrelated events and retains only stable payload fingerprints", () => {
  const initial = breadcrumbProjection.init();
  const message = crumb();
  assert.equal(breadcrumbProjection.apply(initial, { type: "turn/start" }), initial);
  assert.equal(breadcrumbProjection.apply(initial, { type: "user/message", data: user("hello") }), initial);
  const state = breadcrumbProjection.apply(initial, { seq: 0, type: "user/message", data: message });
  assert.deepEqual(initial, {});
  assert.deepEqual(breadcrumbProjection.stateSchema.parse(state), { 0: breadcrumbFingerprint(message) });
  const reordered = { ...crumb(), source: Object.fromEntries(Object.entries(message.source).reverse()) };
  assert.equal(breadcrumbFingerprint(message), breadcrumbFingerprint(reordered));
  assert.notEqual(breadcrumbFingerprint(message), breadcrumbFingerprint(crumb("A", 30)));
  assert.notEqual(breadcrumbFingerprint(message), breadcrumbFingerprint({ ...message, source: { ...message.source, task: "changed" } }));
  assert.throws(() => breadcrumbProjection.stateSchema.parse({ 0: "invalid" }));
});

test("late registration replays existing Session history without exposing host state on the wire", async (t) => {
  const ctx = await sessionRuntime(t);
  const session = ctx.sessions.create("late-registration");
  append(session, crumb());
  const projection = registerBreadcrumbProjection(ctx);
  await projection.ready;
  assert.equal(projection.isVisible(session, crumb()), true);
  assert.deepEqual(ctx.sessionProjections.snapshot(session).values, {});
  assert.equal(ctx.sessionProjections.checkpoint(session)[KEY].ver, 1);
});

test("live projection advances from committed events without synchronous history reads", async (t) => {
  const ctx = await sessionRuntime(t);
  const projection = registerBreadcrumbProjection(ctx);
  await projection.ready;
  const session = ctx.sessions.create("incremental");
  for (const method of ["snapshotEvents", "eventAt", "ownEvents"]) {
    t.mock.method(session, method, () => { throw new Error(`Unexpected ${method}`); });
  }
  append(session, crumb("A"));
  assert.equal(projection.isVisible(session, crumb("A")), true);
  append(session, user("Unrelated user prompt"));
  assert.equal(projection.isVisible(session, crumb("A")), true);
  append(session, crumb("B"));
  assert.equal(projection.isVisible(session, crumb("A")), false);
  assert.equal(projection.isVisible(session, crumb("B")), true);
  append(session, crumb("A"));
  assert.equal(projection.isVisible(session, crumb("A")), true);
});

test("compaction removes visibility and an identical payload can be reinjected", async (t) => {
  const ctx = await sessionRuntime(t);
  const projection = registerBreadcrumbProjection(ctx);
  await projection.ready;
  const session = ctx.sessions.create("compaction");
  append(session, crumb());
  replace(session, [...session.surface.nodes]);
  assert.equal(projection.isVisible(session, crumb()), false);
  append(session, crumb());
  assert.equal(projection.isVisible(session, crumb()), true);
});

test("surface order wins over event sequence after an early-node replacement", async (t) => {
  const ctx = await sessionRuntime(t);
  const projection = registerBreadcrumbProjection(ctx);
  await projection.ready;
  const session = ctx.sessions.create("surface-order");
  append(session, crumb("A"));
  append(session, crumb("B"));
  replace(session, [0], crumb("C"));
  assert.deepEqual(session.surface.nodes, [2, 1]);
  assert.equal(projection.isVisible(session, crumb("B")), true);
  assert.equal(projection.isVisible(session, crumb("C")), false);
});

test("provenance does not erase a still-visible breadcrumb", async (t) => {
  const ctx = await sessionRuntime(t);
  const projection = registerBreadcrumbProjection(ctx);
  await projection.ready;
  const session = ctx.sessions.create("provenance");
  append(session, crumb());
  append(session, user("Other text"));
  session.append("user/message", user("Rewrite"), {
    surfaceOp: { op: "replace", startSeq: 1, endSeq: 1 }, sourceEventSeqs: [0, 1],
  });
  assert.equal(projection.isVisible(session, crumb()), true);
});

test("resumed and forked sessions dedupe on their first read and stay isolated", async (t) => {
  const ctx = await sessionRuntime(t);
  const projection = registerBreadcrumbProjection(ctx);
  await projection.ready;
  const parent = ctx.sessions.create("parent");
  const seed = [append(parent, crumb())];
  const resumed = ctx.sessions.create("resumed", { seed });
  const fork = ctx.sessions.create("fork", {
    seed, inheritedEventCount: seed.length,
    meta: { isSeeded: true, parentSession: parent.id },
  });
  assert.equal(projection.isVisible(resumed, crumb()), true);
  assert.equal(projection.isVisible(fork, crumb()), true);
  append(fork, crumb("B"));
  assert.equal(projection.isVisible(fork, crumb()), false);
  assert.equal(projection.isVisible(parent, crumb()), true);
  assert.equal(projection.isVisible(ctx.sessions.create("unrelated"), crumb()), false);
});

test("checkpoint JSON roundtrip and tail replay produce the same domain state", async (t) => {
  const ctx = await sessionRuntime(t);
  await registerBreadcrumbProjection(ctx).ready;
  const session = ctx.sessions.create("checkpoint");
  const events = [append(session, crumb())];
  const checkpoint = JSON.parse(JSON.stringify(ctx.sessionProjections.checkpoint(session)));
  events.push(append(session, crumb("B")));
  const floor = ctx.sessionProjections.restoreFloor(checkpoint);
  const restored = ctx.sessionProjections.restore(
    checkpoint, events.filter((event) => event.seq >= floor), floor, session.header, session.inheritedEventCount,
  );
  assert.deepEqual(restored.checkpoint, ctx.sessionProjections.checkpoint(session));
  assert.deepEqual(restored.snapshot.values, {});
  checkpoint[KEY].val[0] = "0".repeat(64);
  assert.notDeepEqual(checkpoint[KEY].val, ctx.sessionProjections.stateOf(session, KEY));
});

test("registration reference counts and runtime remount preserve replay correctness", async (t) => {
  const ctx = await sessionRuntime(t);
  const session = ctx.sessions.create("reload");
  const first = registerBreadcrumbProjection(ctx);
  const second = registerBreadcrumbProjection(ctx);
  await Promise.all([first.ready, second.ready]);
  append(session, crumb());
  first.dispose();
  assert.equal(second.isVisible(session, crumb()), true);
  second.dispose();
  assert.equal(ctx.sessionProjections.stateOf(session, KEY), undefined);
  assert.throws(() => second.isVisible(session, crumb()), /not registered/);
  const reloaded = registerBreadcrumbProjection(ctx);
  await reloaded.ready;
  assert.equal(reloaded.isVisible(session, crumb()), true);
});

test("Cordis unload removes only the owning plugin's projection", async (t) => {
  const ctx = await sessionRuntime(t);
  const fiber = ctx.plugin({
    inject: ["sessionProjections"],
    apply(owner) {
      return registerBreadcrumbProjection(owner).ready;
    },
  });
  await fiber.await();
  const session = ctx.sessions.create("owning-scope");
  append(session, crumb());
  assert.ok(ctx.sessionProjections.stateOf(session, KEY)[0]);
  await fiber.dispose();
  assert.equal(ctx.sessionProjections.stateOf(session, KEY), undefined);
  assert.ok(ctx.sessions.get(session.id));
});

test("legacy registry uses a schema-validated projection view, not a Session snapshot", () => {
  let definition;
  let removed = false;
  const registry = {
    register(value) { definition = value; return () => { removed = true; }; },
    snapshot() {
      const state = definition.apply(definition.init(), { seq: 5, type: "user/message", data: crumb() });
      return { values: { [KEY]: definition.schema.parse(definition.view(state)) } };
    },
  };
  const projection = registerBreadcrumbProjection({ sessionProjections: registry });
  const session = { surface: { nodes: [5] } };
  assert.equal(projection.isVisible(session, crumb()), true);
  assert.equal(projection.isVisible(session, crumb("B")), false);
  projection.dispose();
  assert.equal(removed, true);
  assert.throws(() => registerBreadcrumbProjection({}), /requires.*sessionProjections/);
});

test("production modules never read synchronous Session history", async () => {
  const directory = new URL("../lib/", import.meta.url);
  for (const file of await readdir(directory)) {
    if (!file.endsWith(".js")) continue;
    const source = await readFile(new URL(file, directory), "utf8");
    assert.doesNotMatch(source, /\b(?:eventAt|snapshotEvents|ownEvents)\s*\(|\bsession\.events\b/, file);
  }
});

test("async registration reads its handle without deprecated registry reads", async () => {
  const pending = Promise.withResolvers();
  let disposals = 0;
  const session = { surface: { nodes: [5] } };
  const projection = registerBreadcrumbProjection({ sessionProjections: {
    register: () => pending.promise,
    stateOf() { assert.fail("must read the acquired handle"); },
  } });
  assert.throws(() => projection.isVisible(session, crumb()), /not ready/);
  pending.resolve({ stateOf(value) {
    assert.equal(value, session);
    return { 5: breadcrumbFingerprint(crumb()) };
  }, async dispose() { disposals++; } });
  assert.equal(await projection.ready, undefined);
  assert.equal(projection.isVisible(session, crumb()), true);
  await projection.dispose();
  await projection.dispose();
  assert.equal(disposals, 1);
  assert.throws(() => projection.isVisible(session, crumb()), /not registered/);
});

test("async registration failure cannot read another owner's projection", async () => {
  const failure = new Error("projection key conflict");
  const projection = registerBreadcrumbProjection({ sessionProjections: {
    register: () => Promise.reject(failure),
    stateOf() { assert.fail("failed registration must not read another owner"); },
  } });
  await assert.rejects(projection.ready, (error) => error === failure);
  assert.throws(() => projection.isVisible({}, crumb()), (error) => error === failure);
  projection.dispose();
});

test("unload before an async handle arrives releases it exactly once", async () => {
  const pending = Promise.withResolvers();
  let disposals = 0;
  const projection = registerBreadcrumbProjection({ sessionProjections: {
    register: () => pending.promise,
  } });
  projection.dispose();
  pending.resolve({ stateOf: () => assert.fail("unloaded handle cannot read"), async dispose() { disposals++; } });
  await projection.ready;
  projection.dispose();
  assert.equal(disposals, 1);
});

test("a canceled registration rejection is observed during unload", async () => {
  const pending = Promise.withResolvers();
  const projection = registerBreadcrumbProjection({ sessionProjections: {
    register: () => pending.promise,
  } });
  projection.dispose();
  pending.reject(new Error("owner disposed during acquire"));
  await projection.ready;
});

test("legacy Cordis thenable disposer resolves without a projection handle", async () => {
  let disposals = 0;
  const dispose = Object.assign(() => { disposals++; }, {
    then: (resolve, reject) => Promise.resolve({}).then(resolve, reject),
  });
  const projection = registerBreadcrumbProjection({ sessionProjections: {
    register: () => dispose,
    stateOf: () => ({ 5: breadcrumbFingerprint(crumb()) }),
  } });
  await projection.ready;
  assert.equal(projection.isVisible({ surface: { nodes: [5] } }, crumb()), true);
  await projection.dispose();
  assert.equal(disposals, 1);
});

test("a native Promise with an invalid handle fails before any registry read", async () => {
  const projection = registerBreadcrumbProjection({ sessionProjections: {
    register: () => Promise.resolve({}),
    stateOf: () => assert.fail("invalid acquisition cannot read legacy state"),
  } });
  await assert.rejects(projection.ready, /invalid projection handle/);
  projection.dispose();
});

test("stateSchema validates plain objects, integer keys, sha256 values, and rejects symbols/classes/zod", async () => {
  const digest = "a".repeat(64);
  const nullProto = Object.assign(Object.create(null), { 0: digest, 12: digest });
  const parsed = breadcrumbProjection.stateSchema.parse(nullProto);
  assert.deepEqual(parsed, { 0: digest, 12: digest });
  assert.equal(Object.getPrototypeOf(parsed), Object.prototype);
  assert.notEqual(parsed, nullProto);

  for (const bad of [
    null,
    undefined,
    [],
    "string",
    new Date(),
    new Map(),
    { [Symbol("extra")]: digest },
    { "01": digest },
    { "-1": digest },
    { foo: digest },
    JSON.parse(`{"__proto__":"${digest}"}`),
    { 0: "A".repeat(64) },
    { 0: "a".repeat(63) },
    { 0: 123 },
  ]) {
    assert.throws(() => breadcrumbProjection.stateSchema.parse(bad), TypeError);
  }

  const pkg = JSON.parse(await readFile(new URL("../package.json", import.meta.url), "utf8"));
  const libDir = new URL("../lib/", import.meta.url);
  for (const file of await readdir(libDir)) {
    if (!file.endsWith(".js")) continue;
    const source = await readFile(new URL(file, libDir), "utf8");
    assert.doesNotMatch(source, /from\s+["']zod["']/, file);
  }
  assert.ok(pkg.name === "dsh-trellis");
});

test("pending async projection dispose propagates handle.dispose errors and ignores cancellation failures", async () => {
  const boom = Promise.withResolvers();
  let disposals = 0;
  const projection = registerBreadcrumbProjection({
    sessionProjections: { register: () => boom.promise },
  });
  const disposing = projection.dispose();
  boom.resolve({
    stateOf: () => ({}),
    async dispose() {
      disposals++;
      throw new Error("handle dispose failed");
    },
  });
  await assert.rejects(disposing, /handle dispose failed/);
  await projection.ready;
  assert.equal(disposals, 1);

  const canceled = Promise.withResolvers();
  const canceledProjection = registerBreadcrumbProjection({
    sessionProjections: { register: () => canceled.promise },
  });
  const canceledDispose = canceledProjection.dispose();
  canceled.reject(new Error("registration canceled"));
  assert.equal(await canceledDispose, undefined);
  await canceledProjection.ready;
});

test("beforeRegister serializes projection acquisition and cancels cleanly if disposed early", async () => {
  const gate = Promise.withResolvers();
  let calls = 0;
  let disposals = 0;
  const session = { surface: { nodes: [5] } };
  const projection = registerBreadcrumbProjection(
    {
      sessionProjections: {
        register: () => {
          calls++;
          return Promise.resolve({
            stateOf: () => ({ 5: breadcrumbFingerprint(crumb()) }),
            async dispose() { disposals++; },
          });
        },
      },
    },
    { beforeRegister: gate.promise },
  );
  assert.equal(calls, 0);
  assert.throws(() => projection.isVisible(session, crumb()), /not ready/);
  gate.resolve();
  await projection.ready;
  assert.equal(calls, 1);
  assert.equal(projection.isVisible(session, crumb()), true);
  await projection.dispose();
  assert.equal(disposals, 1);

  const abortedGate = Promise.withResolvers();
  let canceledCalls = 0;
  const canceled = registerBreadcrumbProjection(
    {
      sessionProjections: {
        register: () => {
          canceledCalls++;
          return () => {};
        },
      },
    },
    { beforeRegister: abortedGate.promise },
  );
  assert.equal(canceled.dispose(), undefined);
  abortedGate.resolve();
  await canceled.ready;
  assert.equal(canceledCalls, 0);

  const failedGate = Promise.reject(new Error("prior teardown boom"));
  const failed = registerBreadcrumbProjection(
    { sessionProjections: { register: () => assert.fail("must not register after failed gate") } },
    { beforeRegister: failedGate },
  );
  await assert.rejects(failed.ready, /prior teardown boom/);
  assert.throws(() => failed.isVisible(session, crumb()), /prior teardown boom/);
});
