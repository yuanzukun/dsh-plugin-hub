# DSH 0.2.3-alpha.2 兼容验证

2026-11-24。基于 `d5c81c9` 工作树适配并准备发布 `0.1.26`，本地使用 Node `24.22.1`、pnpm `10.33.0` 和 Python `3.12.10`。

## 上游契约与适配

- **拒绝 `0.2.3-alpha.1`、准入 `0.2.3-alpha.2`**：实测上游 `0.2.3-alpha.1` 仍绑定 `@deepseek-ai/cordis@~4.1.0`，而其核心包已迁移至 Cordis `4.0.0-rc.12` 的 `Context.root` symbol，启动即报 `cannot get property "undefined" without inject`。上游随后发布 vendor `cordis@4.2.0-alpha.1`、`schemastery@3.20.0-alpha.1`、`include@1.2.0-alpha.1`、`loader@1.2.0-alpha.1`、`group@1.2.0-alpha.1` 及 `0.2.3-alpha.2`。本包参照 `0.2.1-alpha.2` / `0.2.2-alpha.2` 规则，在 `engines.dsh` 与七项 DSH peer 新增 `>=0.2.3-alpha.2 <0.2.4-0`，并扩展 Cordis / Schemastery peer 范围，继续明确拒绝 `0.2.3-alpha.1` 与 `0.2.4-*`。
- **移除 `@deepseek-ai/dsh-client-ui-settings-plugins`**：上游删除「设置 → 内置插件」及该包（`0.2.3-alpha.2` 返回 `404`）。核对 DSH `packages/client/modules/src/client/system.ts` 确认浏览器模块加载器会静默跳过未出现在启动图中的 `dsh.client.inject` 项，且 `plugins.bundle.config` 槽位保留；`compat-hosts.mjs` 为 `0.2.3-alpha.2` 剔除该测试依赖，保留旧宿主兼容。
- **PTC `PtcInspectableValue`、`discardCompletion` 与默认 `scoped-repl`**：`0.2.3` 的 `PtcExecutor` 将对象工具结果包装为 `PtcInspectableValue`，并默认在 `scoped-repl` 下以 `discardCompletion: true` 消费 `result.output`。`test/executors.test.js` 补齐对 `PtcInspectableValue` 与 `result.output` 的双代验证，`e2e/model.mjs` 在 `run_code` 工具描述包含 `inspect(` 时改为生成 `inspect(await tools[...](...));`，兼容 `0.2.2` 与 `0.2.3+`。
- **Node.js 最低版本说明**：DSH `0.2.3-alpha.2` 声明 `engines.node` 为 `^24.22.3 || >=26.13.1`；本插件保持 `engines.node: ">=24"` 以兼容旧宿主。

相关参考：[DSH v0.2.3-alpha.1](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.3-alpha.1) · [DSH v0.2.3-alpha.2](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.3-alpha.2)

## Windows 本地验证

冻结安装、E2E 冻结锁文件校验、客户端构建与产物一致性、`scripts/verify-pack.mjs`（`dsh-trellis-0.1.26.tgz`）均通过。

| 验证 | 通过 | 按宿主能力跳过 | 失败 |
| --- | ---: | ---: | ---: |
| 开发基线 `0.2.0-rc.1` | 243 | 10 | 0 |
| `0.2.3-alpha.2` 完整套件 | 253 | 0 | 0 |
| 22 个非基线宿主隔离矩阵（`0.1.5-rc.2..0.2.3-alpha.2`） | 5427 | 139 | 0 |
| 23 宿主总计（基线 + 22 隔离宿主） | 5670 | 149 | 0 |

## SDK E2E

E2E 锁定官方 `@deepseek-ai/dsh@0.2.3-alpha.2`、`@deepseek-ai/cordis-plugin-group@1.2.0-alpha.1` 和 `@mindfoldhq/trellis@0.7.0-beta.4`，通过正常 `prepack` 打包安装 `dsh-trellis-0.1.26.tgz`。

| E2E 模式 | 权限 | 结果 |
| --- | --- | --- |
| Native | 隔离 `danger-full-access` 对照 | 通过，33 次回环模型请求（12 项断言全通过） |
| PTC（默认 `scoped-repl` + `inspect`） | 隔离 `danger-full-access` 对照 | 通过，33 次回环模型请求（12 项断言全通过） |

## 边界与未覆盖项

- 本轮在 Windows Node `24.22.1` 上完成验证；未升级本机全局 Node 至 `24.22.3+`，未在 Linux 容器中重建 `e2e/Dockerfile`（仍固定 `node:24.12.0-bookworm-slim`）执行容器 E2E，亦未验证 Windows 默认 `workspace-write` 沙箱、真实 Web 浏览器 UI 热替换与付费外部模型调用。
- 远端双平台 CI 与 OIDC 发布状态以 `v0.1.26` 对应的 GitHub Actions 运行结果及 npm 注册表为准。

## 原始证据

- 正式仓库 SDK E2E 报告位于 `%TEMP%/dsh-trellis-e2e-3AbStJ/report.json`。
