export const DEFAULTS = Object.freeze({
  enabled: true,
  maxBytes: 4096,
  projectRootMarkers: Object.freeze([".trellis", ".git"]),
  skipKeyword: "no-trellis",
  pythonCmd: "",
  commandsEnabled: true,
});

export const FIELD_NAMES = Object.freeze(Object.keys(DEFAULTS));

function record(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value)
    ? value
    : {};
}

export function sameValue(left, right) {
  if (Number.isNaN(left) || Number.isNaN(right)) {
    return Object.is(left, right);
  }
  return JSON.stringify(left) === JSON.stringify(right);
}

export function fallbackValue(snapshot, field) {
  const base = record(snapshot.base);
  return Object.hasOwn(base, field) ? base[field] : DEFAULTS[field];
}

export function makeDraft(snapshot) {
  const value = record(snapshot?.value);
  return Object.fromEntries(
    FIELD_NAMES.map((field) => [
      field,
      { mode: "clean", value: value[field] ?? DEFAULTS[field] },
    ]),
  );
}

function displayValue(field, value) {
  if (field === "projectRootMarkers") {
    return Array.isArray(value) ? value.join("\n") : String(value ?? "");
  }
  if (field === "enabled" || field === "commandsEnabled") {
    return Boolean(value);
  }
  return String(value ?? "");
}

/** Merge-sync clean fields from snapshot while preserving uncommitted user text. */
export function syncDraft(snapshot, draft) {
  if (snapshot?.status !== "ready") return draft;
  const value = record(snapshot.value);
  const user = record(snapshot.user);
  let changed = false;
  const next = {};
  for (const field of FIELD_NAMES) {
    const entry = draft[field];
    const target = value[field] ?? DEFAULTS[field];
    if (entry.mode === "clean") {
      if (!sameValue(entry.value, target)) {
        changed = true;
        next[field] = { mode: "clean", value: target };
        continue;
      }
      next[field] = entry;
      continue;
    }
    if (entry.mode === "set") {
      if (displayValue(field, entry.value) === displayValue(field, target)) {
        changed = true;
        next[field] = { mode: "clean", value: target };
        continue;
      }
    } else if (entry.mode === "unset") {
      if (!Object.hasOwn(user, field)) {
        changed = true;
        next[field] = { mode: "clean", value: target };
        continue;
      }
      const fallback = fallbackValue(snapshot, field);
      if (!sameValue(entry.value, fallback)) {
        changed = true;
        next[field] = { mode: "unset", value: fallback };
        continue;
      }
    }
    next[field] = entry;
  }
  return changed ? next : draft;
}

export function editDraft(draft, field, value) {
  return { ...draft, [field]: { mode: "set", value } };
}

export function resetDraft(snapshot, draft, field) {
  return {
    ...draft,
    [field]: { mode: "unset", value: fallbackValue(snapshot, field) },
  };
}

export function parseMarkers(text) {
  return [...new Set(text.split(/\r?\n/).map((entry) => entry.trim()).filter(Boolean))];
}

export function parseDraft(draft) {
  const maxBytesText = String(draft.maxBytes.value).trim();
  const parsedMaxBytes = /^\d+$/.test(maxBytesText)
    ? Number(maxBytesText)
    : Number.NaN;
  const validMaxBytes =
    Number.isSafeInteger(parsedMaxBytes) && parsedMaxBytes >= 0;
  const maxBytes = validMaxBytes ? parsedMaxBytes : Number.NaN;
  const markersValue = draft.projectRootMarkers.value;
  return {
    invalid:
      !validMaxBytes ||
      typeof draft.enabled.value !== "boolean" ||
      typeof draft.commandsEnabled.value !== "boolean",
    value: {
      enabled: draft.enabled.value,
      maxBytes,
      projectRootMarkers: parseMarkers(
        Array.isArray(markersValue)
          ? markersValue.join("\n")
          : String(markersValue),
      ),
      skipKeyword: String(draft.skipKeyword.value).trim(),
      pythonCmd: String(draft.pythonCmd.value).trim(),
      commandsEnabled: draft.commandsEnabled.value,
    },
  };
}

export function planDraft(snapshot, draft) {
  const user = record(snapshot.user);
  const current = record(snapshot.value);
  const parsed = parseDraft(draft);
  const writes = [];
  for (const field of FIELD_NAMES) {
    const staged = draft[field];
    if (staged.mode === "clean") continue;
    if (staged.mode === "unset") {
      if (Object.hasOwn(user, field)) writes.push({ field, kind: "unset" });
      continue;
    }
    const value = parsed.value[field];
    if (!sameValue(current[field], value)) {
      writes.push({ field, kind: "set", value });
    }
  }
  return { invalid: parsed.invalid, writes };
}

export function isOverridden(snapshot, draft, field) {
  if (draft[field].mode === "set") return true;
  if (draft[field].mode === "unset") return false;
  return Object.hasOwn(record(snapshot.user), field);
}

export function planLanded(snapshot, writes) {
  const user = record(snapshot.user);
  return writes.every((write) =>
    write.kind === "unset"
      ? !Object.hasOwn(user, write.field)
      : Object.hasOwn(user, write.field) && sameValue(user[write.field], write.value),
  );
}

/** New hosts commit a staged form atomically against its edit-start revision. */
export async function savePlan(scope, writes, revision) {
  if (typeof scope.mutate === "function") {
    const accepted = await scope.mutate(writes.map(({ kind, field, value }) =>
      kind === "unset" ? { op: "unset", path: [field] }
        : { op: "set", path: [field], value },
    ), revision);
    if (accepted === false) return false;
  } else {
    for (const write of writes) {
      const accepted = write.kind === "unset"
        ? await scope.unset(write.field) : await scope.set(write.field, write.value);
      if (accepted === false) return false;
    }
  }
  return planLanded(scope.getSnapshot(), writes);
}
