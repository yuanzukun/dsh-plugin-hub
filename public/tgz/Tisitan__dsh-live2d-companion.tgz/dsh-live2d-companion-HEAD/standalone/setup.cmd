@echo off
setlocal
cd /d "%~dp0"
where node.exe >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install Node.js 22.12 or later, then run this file again.
  pause
  exit /b 1
)
call npm.cmd install
if errorlevel 1 (
  echo.
  echo Installation failed. Check the network connection and the messages above.
  pause
  exit /b 1
)
set "ELECTRON_EXE=%~dp0node_modules\electron\dist\electron.exe"
if not exist "%ELECTRON_EXE%" (
  echo.
  echo Downloading the Electron runtime binary...
  node "%~dp0node_modules\electron\install.js"
  if errorlevel 1 (
    echo.
    echo Electron binary download failed.
    echo On a restricted network, set the mirror in a Command Prompt and rerun:
    echo   set ELECTRON_MIRROR=https://npmmirror.com/mirrors/electron/
    echo   setup.cmd
    pause
    exit /b 1
  )
)
echo.
echo Setup complete. You can now run start.cmd.
pause
