/**
 * dsh-files-git — end-to-end transport tests (Phase 1 + Phase 2 + review fixes).
 *
 * Exercises the REAL host half (lib/index.js apply) and the REAL sidecar
 * (lib/server/server.js) as spawned processes, over loopback HTTP:
 *
 *   1.  service-info bootstrap (real ensureService flow)
 *   2.  single-flight / reuse (second call → same pid)
 *   3.  direct RPC with Bearer token (real git status against a temp repo)
 *   4.  CORS: loopback origin echoed, foreign origin suppressed
 *   5.  OPTIONS preflight: 204 + private-network header, no auth needed
 *   6.  SSE /events: initial snapshot + live push on create + push on delete
 *   7.  /events with a bad repo → 400
 *   8.  oversized body → readable 413 (not a bare connection reset)
 *   9.  per-fingerprint isolation: a second host with a DIFFERENT config
 *       gets its OWN sidecar and does NOT kill the first one (regression
 *       test for the runtime-file singleton fight)
 *   10. runtime files exist, one per fingerprint, distinct paths
 *   11. self-heal: killed sidecar → next RPC respawns a fresh pid
 *   12. raw file channel: /files/upload (bytes round-trip, overwrite 409 →
 *       overwrite=1, traversal/illegal-name/missing-parent rejection),
 *       /files/download (byte-equal + RFC 5987 headers, traversal reject),
 *       exportZip + /files/export (central-directory parse, inflate, CRC,
 *       UTF-8 names, explicit dir entry), token gate, host route wiring
 *   16. malformed request-target (`GET //:80`) → 400, sidecar survives
 *   17. rev option-injection rejected (`--output=`), legit revs still work
 *   18. /vendor: no-token serving + traversal fenced + 404s
 *
 * Run: node scripts/e2e.mjs
 */
import { execFileSync } from "node:child_process";
import { createServer } from "node:http";
import { existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { connect as netConnect } from "node:net";
import { inflateRawSync } from "node:zlib";
import * as host from "../lib/index.js";
import { configFingerprint, runtimeFilePath } from "../lib/server/shared.js";

const pluginVersion = String(JSON.parse(readFileSync(new URL("../package.json", import.meta.url), "utf8")).version ?? "");

let passed = 0;
let failed = 0;
const results = [];
function check(name, cond, detail = "") {
	if (cond) {
		passed++;
		results.push(`PASS  ${name}`);
	} else {
		failed++;
		results.push(`FAIL  ${name}${detail ? ` — ${detail}` : ""}`);
	}
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function makeHost(config) {
	let handler = null;
	const rawRoutes = [];
	const ctx = {
		// cordis ctx.effect runs the registration callback immediately and
		// keeps its return value as the disposer — same call shape as the
		// real host.
		effect: (fn) => fn(),
		connection: {
			register: (_self, _channel, fn) => { handler = fn; },
			requestRejection: () => undefined   // the raw channel's fence, stubbed for direct handler checks
		},
		webServer: { register: (route) => { rawRoutes.push(route); return () => {}; } }
	};
	host.apply(ctx, config);
	return {
		rpc: async (endpoint, payload = {}) => {
			const ac = new AbortController();
			const out = await handler(endpoint, payload, ac.signal);
			if (!out || typeof out !== "object" || !("ok" in out)) throw new Error(`bad RpcResult for ${endpoint}`);
			return out;
		},
		rawRoutes
	};
}

function git(repo, ...args) {
	return execFileSync("git", ["-C", repo, ...args], { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] });
}

function killTree(pid) {
	execFileSync("taskkill", ["/PID", String(pid), "/T", "/F"], { stdio: "ignore" });
}

async function directCall(info, endpoint, payload, { method = "POST", headers = {}, body } = {}) {
	// One transport-level retry, mirroring the client's read-class retry: git
	// process storms (branch switches, merges in earlier sections) can
	// transiently reset a loopback connection — the NEXT request recovers.
	const doFetch = () => fetch(`http://127.0.0.1:${info.port}/git/${encodeURIComponent(endpoint)}`, {
		method,
		headers: { authorization: `Bearer ${info.token}`, "content-type": "application/json", ...headers },
		body: body ?? (payload === undefined ? undefined : JSON.stringify(payload))
	});
	try {
		return await doFetch();
	} catch (error) {
		await sleep(300);
		return doFetch();
	}
}

async function main() {
	const repo = mkdtempSync(join(tmpdir(), "fg-e2e-"));
	git(repo, "init", "-b", "main");
	git(repo, "config", "user.email", "e2e@test");
	git(repo, "config", "user.name", "e2e");
	writeFileSync(join(repo, "a.txt"), "hello\n", "utf8");
	git(repo, "add", ".");
	git(repo, "commit", "-m", "init");

	let shutdownUrls = [];
	try {
		// ── 1+2: service-info bootstrap via the real host ────────────────────
		const hostA = makeHost({});
		const info1 = await hostA.rpc("service-info");
		check("1. service-info returns ok with port/token/pid", info1.ok && info1.value.port > 0 && /^[0-9a-f]{64}$/.test(info1.value.token) && info1.value.pid > 0);
		check("1b. version matches package.json", info1.value.version === pluginVersion, `${info1.value?.version} vs ${pluginVersion}`);
		const pidA = info1.value.pid;
		const infoA2 = await hostA.rpc("service-info");
		check("2. second call reuses the same instance", infoA2.ok && infoA2.value.pid === pidA, `${infoA2.value?.pid} vs ${pidA}`);
		const info = info1.value;
		shutdownUrls.push({ port: info.port, token: info.token });

		// ── 3: direct RPC with Bearer token ──────────────────────────────────
		const st = await directCall(info, "status", { repo });
		const stJson = await st.json();
		check(
			"3. direct status RPC ok",
			st.status === 200 && stJson.ok && stJson.value.branch === "main" && stJson.value.staged.length === 0 && stJson.value.untracked.length === 0
		);
		const noAuth = await fetch(`http://127.0.0.1:${info.port}/git/status`, { method: "POST", body: "{}" });
		check("3b. missing token → 401", noAuth.status === 401);
		const directoryNoAuth = await fetch(`http://127.0.0.1:${info.port}/git/openDirectory`, { method: "POST", body: "{}" });
		check("3c. desktop opening requires token", directoryNoAuth.status === 401);
		const directoryEscape = await (await directCall(info, "openDirectory", { repo, path: "../" })).json();
		check("3d. desktop opening rejects workspace escape", !directoryEscape.ok && directoryEscape.error.code === "invalid-path");
		const directoryFile = await (await directCall(info, "openDirectory", { repo, path: "a.txt" })).json();
		check("3e. desktop opening rejects a file target", !directoryFile.ok && directoryFile.error.code === "directory-open-failed");
		const fileNoAuth = await fetch(`http://127.0.0.1:${info.port}/git/openFile`, { method: "POST", body: "{}" });
		check("3f. associated-file opening requires token", fileNoAuth.status === 401);
		const fileEscape = await (await directCall(info, "openFile", { repo, path: "../" })).json();
		check("3g. associated-file opening rejects workspace escape", !fileEscape.ok && fileEscape.error.code === "invalid-path");
		const fileDirectory = await (await directCall(info, "openFile", { repo, path: "." })).json();
		check("3h. associated-file opening rejects a directory target", !fileDirectory.ok && fileDirectory.error.code === "file-open-failed");

		// ── 4+5: CORS + preflight ────────────────────────────────────────────
		const corsEcho = await fetch(`http://127.0.0.1:${info.port}/health`, { headers: { origin: "http://127.0.0.1:3080" } });
		check("4. loopback origin echoed", corsEcho.headers.get("access-control-allow-origin") === "http://127.0.0.1:3080");
		const corsForeign = await fetch(`http://127.0.0.1:${info.port}/health`, { headers: { origin: "https://evil.example" } });
		check("4b. foreign origin suppressed", corsForeign.headers.get("access-control-allow-origin") === null);
		const pre = await fetch(`http://127.0.0.1:${info.port}/git/status`, {
			method: "OPTIONS",
			headers: { origin: "http://localhost:3080", "access-control-request-method": "POST", "access-control-request-headers": "authorization" }
		});
		check("5. preflight 204 no-auth", pre.status === 204);
		check("5b. preflight PNA header present", pre.headers.get("access-control-allow-private-network") === "true");

		// ── 6+7: SSE (phase-based, cursor over the event sequence) ───────────
		// Position-indexed assertions are flaky: if the service's FIRST git
		// status is slow (Defender/cold cache), the create-change coalesces
		// into the initial snapshot. Phase waits over a moving cursor are
		// deterministic: snapshot → wait event WITH new.txt → wait event
		// WITHOUT it.
		const sseCtl = new AbortController();
		const sseEvents = [];
		{
			const res = await fetch(`http://127.0.0.1:${info.port}/events?repo=${encodeURIComponent(repo)}`, {
				headers: { authorization: `Bearer ${info.token}` },
				signal: sseCtl.signal
			});
			const reader = res.body.getReader();
			const decoder = new TextDecoder();
			let buffer = "";
			(async () => {
				try {
					for (;;) {
						const { value, done: fin } = await reader.read();
						if (fin) break;
						buffer += decoder.decode(value, { stream: true });
						let idx;
						while ((idx = buffer.indexOf("\n\n")) !== -1) {
							const frame = buffer.slice(0, idx);
							buffer = buffer.slice(idx + 2);
							const dataLine = frame.split("\n").find((l) => l.startsWith("data:"));
							if (!dataLine) continue;
							try { sseEvents.push(JSON.parse(dataLine.slice(5).trim())); } catch { /* ignore */ }
						}
					}
				} catch { /* aborted at the end */ }
			})();
		}
		let cursor = 0;
		const waitEvent = async (pred, ms) => {
			const deadline = Date.now() + ms;
			for (;;) {
				for (; cursor < sseEvents.length; cursor++) {
					if (pred(sseEvents[cursor])) return sseEvents[cursor];
				}
				if (Date.now() > deadline) return null;
				await sleep(80);
			}
		};
		const hasNew = (e) => !e.error && e.untracked.some((u) => u.path === "new.txt");
		try {
			const snapshot = await waitEvent((e) => !e.error, 15000);
			check(
				"6. SSE initial snapshot",
				Boolean(snapshot) && snapshot.repo === repo && snapshot.branch === "main",
				JSON.stringify(snapshot)?.slice(0, 300)
			);
			writeFileSync(join(repo, "new.txt"), "x\n", "utf8");
			const created = await waitEvent(hasNew, 10000);
			check("6b. file create pushed live", Boolean(created), `cursor=${cursor}/${sseEvents.length}`);
			rmSync(join(repo, "new.txt"));
			const deleted = await waitEvent((e) => !e.error && !hasNew(e), 10000);
			check("6c. file delete pushed live", Boolean(deleted), `cursor=${cursor}/${sseEvents.length}`);
		} finally {
			sseCtl.abort();
		}
		const evBad = await fetch(`http://127.0.0.1:${info.port}/events?repo=${encodeURIComponent(join(repo, "nope"))}`, { headers: { authorization: `Bearer ${info.token}` } });
		check("7. events bad repo → 400", evBad.status === 400);

		// ── 8: oversized body → 413 ──────────────────────────────────────────
		const big = Buffer.alloc(9 * 1024 * 1024, 0x61);
		const tooBig = await directCall(info, "status", undefined, { body: big });
		const tooBigJson = await tooBig.json().catch(() => null);
		check("8. oversized body → readable 413", tooBig.status === 413 && tooBigJson?.error === "payload-too-large", `status=${tooBig.status}`);

		// ── 9+10: per-fingerprint isolation ──────────────────────────────────
		const hostB = makeHost({ defaultRoot: repo });
		const infoB = await hostB.rpc("service-info");
		const pidB = infoB.value?.pid;
		check("9. second config spawns its own sidecar", infoB.ok && pidB > 0 && pidB !== pidA, `${pidB} vs ${pidA}`);
		if (infoB.ok) shutdownUrls.push({ port: infoB.value.port, token: infoB.value.token });
		const infoA3 = await hostA.rpc("service-info");
		check("9b. host A unaffected by host B (no mutual kill)", infoA3.ok && infoA3.value.pid === pidA, `${infoA3.value?.pid} vs ${pidA}`);
		const stB = await directCall(infoB.value, "status", { repo });
		const stBJson = await stB.json();
		check("9c. host B sidecar serves git too", stB.status === 200 && stBJson.ok && stBJson.value.branch === "main");
		const fpA = configFingerprint("", "");
		const fpB = configFingerprint("", repo);
		check(
			"10. runtime files exist per fingerprint",
			existsSync(runtimeFilePath(fpA)) && existsSync(runtimeFilePath(fpB)) && runtimeFilePath(fpA) !== runtimeFilePath(fpB)
		);

		// ── 11: self-heal respawn ────────────────────────────────────────────
		killTree(pidA);
		await sleep(300);
		const infoA4 = await hostA.rpc("service-info");
		check("11. killed sidecar respawns on next RPC", infoA4.ok && infoA4.value.pid !== pidA, `${infoA4.value?.pid} vs ${pidA}`);
		shutdownUrls[0] = { port: infoA4.value.port, token: infoA4.value.token };
		const st2 = await directCall(infoA4.value, "status", { repo });
		const st2Json = await st2.json();
		check("11b. respawned sidecar serves status", st2.status === 200 && st2Json.ok && st2Json.value.branch === "main");

		// ── 12: raw file channel (upload / download / exportZip) ─────────────
		check("12a. host registers the /git-api-files raw route", hostA.rawRoutes.some((r) => r.kind === "prefix" && r.path === "/git-api-files"));
		const filesUrl = (route, params) => `http://127.0.0.1:${infoA4.value.port}/files/${route}?${new URLSearchParams(params).toString()}`;
		const filesAuth = { authorization: `Bearer ${infoA4.value.token}` };
		const noAuthFiles = await fetch(filesUrl("download", { repo, path: "a.txt" }));
		check("12b. files channel missing token → 401", noAuthFiles.status === 401);

		const upPayload = Buffer.from("upload-payload-你好\n", "utf8");
		const up = await fetch(filesUrl("upload", { repo, path: "uploaded 文件.txt" }), { method: "POST", headers: { ...filesAuth, "content-type": "application/octet-stream" }, body: upPayload });
		const upJson = await up.json().catch(() => null);
		check("12c. upload writes bytes (UTF-8 name)", up.status === 200 && upJson?.ok === true && upJson?.value?.size === upPayload.length, JSON.stringify(upJson)?.slice(0, 200));
		check("12d. uploaded bytes round-trip on disk", readFileSync(join(repo, "uploaded 文件.txt")).equals(upPayload));

		const upDup = await fetch(filesUrl("upload", { repo, path: "uploaded 文件.txt" }), { method: "POST", headers: { ...filesAuth, "content-type": "application/octet-stream" }, body: upPayload });
		check("12e. duplicate upload without overwrite → 409", upDup.status === 409);
		const upOvr = await fetch(filesUrl("upload", { repo, path: "uploaded 文件.txt", overwrite: "1" }), { method: "POST", headers: { ...filesAuth, "content-type": "application/octet-stream" }, body: Buffer.from("overwritten\n", "utf8") });
		check("12f. duplicate upload with overwrite=1 → 200", upOvr.status === 200 && (await upOvr.json())?.ok === true);
		check("12g. overwritten content on disk", readFileSync(join(repo, "uploaded 文件.txt"), "utf8") === "overwritten\n");

		const upEscape = await fetch(filesUrl("upload", { repo, path: "../escape.txt" }), { method: "POST", headers: { ...filesAuth }, body: "x" });
		check("12h. upload path traversal rejected", upEscape.status === 400);
		const upColon = await fetch(filesUrl("upload", { repo, path: "a:bad.txt" }), { method: "POST", headers: { ...filesAuth }, body: "x" });
		check("12i. upload illegal filename rejected", upColon.status === 400);
		const upNoDir = await fetch(filesUrl("upload", { repo, path: "no-such-dir/x.txt" }), { method: "POST", headers: { ...filesAuth }, body: "x" });
		check("12j. upload into missing parent dir rejected", upNoDir.status === 400);

		const dl = await fetch(filesUrl("download", { repo, path: "a.txt" }), { headers: filesAuth });
		const dlBytes = Buffer.from(await dl.arrayBuffer());
		check("12k. download streams the file back", dl.status === 200 && dlBytes.equals(Buffer.from("hello\n", "utf8")));
		check("12l. download attachment headers (RFC 5987)", (dl.headers.get("content-disposition") ?? "").includes("attachment") && (dl.headers.get("content-disposition") ?? "").includes("filename*=UTF-8''a.txt"));
		const dlEscape = await fetch(filesUrl("download", { repo, path: "../outside.txt" }), { headers: filesAuth });
		check("12m. download path traversal rejected", dlEscape.status === 400);

		mkdirSync(join(repo, "sub"), { recursive: true });
		writeFileSync(join(repo, "sub", "nested.txt"), "nested-content\n", "utf8");
		const ex = await directCall(infoA4.value, "exportZip", { repo, paths: ["a.txt", "uploaded 文件.txt", "sub"] });
		const exJson = await ex.json();
		const exVal = exJson?.value;
		check("12n. exportZip builds an archive", ex.status === 200 && exJson.ok === true && typeof exVal?.exportId === "string" && exVal.fileCount === 3 && exVal.dirCount === 1, JSON.stringify(exJson)?.slice(0, 240));
		const zipRes = await fetch(filesUrl("export", { id: exVal.exportId }), { headers: filesAuth });
		const zipBuf = Buffer.from(await zipRes.arrayBuffer());
		check("12o. export download streams the zip", zipRes.status === 200 && zipBuf.length > 0 && (zipRes.headers.get("content-disposition") ?? "").includes(".zip"));
		const missingExport = await fetch(filesUrl("export", { id: "deadbeef" }), { headers: filesAuth });
		check("12p. unknown export id → 404", missingExport.status === 404);

		// Minimal ZIP reader: EOCD → central directory → per-entry inflate +
		// CRC verification against a local crc32 implementation.
		const CRC_TABLE = (() => {
			const table = new Int32Array(256);
			for (let n = 0; n < 256; n++) {
				let c = n;
				for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
				table[n] = c;
			}
			return table;
		})();
		const crc32Of = (buf) => {
			let c = 0xFFFFFFFF;
			for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
			return (c ^ 0xFFFFFFFF) >>> 0;
		};
		function readZip(buf) {
			let eocd = -1;
			for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 0xFFFF); i--) {
				if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
			}
			if (eocd === -1) throw new Error("EOCD not found");
			const count = buf.readUInt16LE(eocd + 10);
			const cdOffset = buf.readUInt32LE(eocd + 16);
			const entries = [];
			let at = cdOffset;
			for (let k = 0; k < count; k++) {
				if (buf.readUInt32LE(at) !== 0x02014b50) throw new Error("bad central directory entry");
				const flags = buf.readUInt16LE(at + 8);
				const method = buf.readUInt16LE(at + 10);
				const crc = buf.readUInt32LE(at + 16);
				const csize = buf.readUInt32LE(at + 20);
				const usize = buf.readUInt32LE(at + 24);
				const nameLen = buf.readUInt16LE(at + 28);
				const extraLen = buf.readUInt16LE(at + 30);
				const commentLen = buf.readUInt16LE(at + 32);
				const localOffset = buf.readUInt32LE(at + 42);
				const name = buf.subarray(at + 46, at + 46 + nameLen).toString("utf8");
				const localNameLen = buf.readUInt16LE(localOffset + 26);
				const localExtraLen = buf.readUInt16LE(localOffset + 28);
				const dataAt = localOffset + 30 + localNameLen + localExtraLen;
				const data = buf.subarray(dataAt, dataAt + csize);
				const plain = method === 8 ? inflateRawSync(data) : Buffer.from(data);
				entries.push({ name, flags, method, crc, csize, usize, plain });
				at += 46 + nameLen + extraLen + commentLen;
			}
			return { count, entries };
		}
		const zip = readZip(zipBuf);
		const zipNames = zip.entries.map((e) => e.name).sort();
		check("12q. zip entries match the selection (dir structure kept)", zip.count === 4 && zipNames.join("|") === ["a.txt", "sub/", "sub/nested.txt", "uploaded 文件.txt"].join("|"), zipNames.join(","));
		const aEntry = zip.entries.find((e) => e.name === "a.txt");
		check("12r. zip entry content + CRC verified", Boolean(aEntry) && aEntry.plain.equals(Buffer.from("hello\n", "utf8")) && aEntry.crc === crc32Of(Buffer.from("hello\n", "utf8")));
		const nestedEntry = zip.entries.find((e) => e.name === "sub/nested.txt");
		check("12s. zip nested file content verified", Boolean(nestedEntry) && nestedEntry.plain.equals(Buffer.from("nested-content\n", "utf8")));
		const uploadedEntry = zip.entries.find((e) => e.name === "uploaded 文件.txt");
		check("12t. zip UTF-8 entry name round-trips", Boolean(uploadedEntry) && uploadedEntry.plain.equals(Buffer.from("overwritten\n", "utf8")));
		const dirEntry = zip.entries.find((e) => e.name === "sub/");
		check("12u. explicit directory entry present", Boolean(dirEntry) && dirEntry.method === 0 && (dirEntry.flags & 0x0800) !== 0);

		// 12v: an EMPTY directory survives as an explicit entry (regression
		// guard for the dir-entry emission path, distinct from 12u's populated dir).
		mkdirSync(join(repo, "empty-dir"), { recursive: true });
		const exEmpty = await directCall(infoA4.value, "exportZip", { repo, paths: ["empty-dir"] });
		const exEmptyJson = await exEmpty.json();
		let emptyZipOk = false;
		if (exEmptyJson?.ok === true) {
			const zipEmptyRes = await fetch(filesUrl("export", { id: exEmptyJson.value.exportId }), { headers: filesAuth });
			const zipEmpty = readZip(Buffer.from(await zipEmptyRes.arrayBuffer()));
			emptyZipOk = zipEmpty.count === 1 && zipEmpty.entries[0]?.name === "empty-dir/" && zipEmpty.entries[0]?.usize === 0;
		}
		check("12v. empty directory survives as an explicit zip entry", emptyZipOk, JSON.stringify(exEmptyJson).slice(0, 120));

		// ── 12w-12z: review regression tests ─────────────────────────────────
		// 12w drives the REGISTERED host raw route through a real HTTP server
		// with the CLIENT-shaped URL — the proxy path every non-loopback page
		// takes (regression: /git-api-files/files/<route> used to 404 because
		// the client glued an extra /files segment onto the proxy base).
		const capturedRoute = hostA.rawRoutes.find((r) => r.kind === "prefix" && r.path === "/git-api-files");
		const proxySrv = createServer((req, res) => { void capturedRoute.handler(req, res); });
		await new Promise((resolve) => proxySrv.listen(0, "127.0.0.1", resolve));
		const proxyPort = proxySrv.address().port;
		const proxyDl = await fetch(`http://127.0.0.1:${proxyPort}/git-api-files/download?${new URLSearchParams({ repo, path: "a.txt" })}`);
		const proxyDlBytes = Buffer.from(await proxyDl.arrayBuffer());
		check("12w. proxy route serves the client-shaped URL (byte round-trip)", proxyDl.status === 200 && proxyDlBytes.equals(Buffer.from("hello\n", "utf8")), `status=${proxyDl.status} body=${proxyDlBytes.toString("utf8").slice(0, 60)}`);
		const proxyStale = await fetch(`http://127.0.0.1:${proxyPort}/git-api-files/files/download?${new URLSearchParams({ repo, path: "a.txt" })}`);
		check("12x. stale /git-api-files/files/* shape rejected (404)", proxyStale.status === 404, `status=${proxyStale.status}`);
		proxySrv.close();

		// 12y: a caps-configured host must boot its sidecar — host and sidecar
		// must agree on the runtime-file fingerprint (regression: the sidecar
		// computed its fingerprint WITHOUT caps, so the host polled a runtime
		// file that never appeared and every RPC failed the 8s boot window).
		const hostCaps = makeHost({ maxUploadBytes: 1024 * 1024 });
		const infoCaps = await hostCaps.rpc("service-info");
		check("12y. caps-configured host boots its sidecar (fingerprint parity)", infoCaps.ok === true && infoCaps.value?.port > 0, JSON.stringify(infoCaps).slice(0, 160));
		if (infoCaps.ok) {
			shutdownUrls.push({ port: infoCaps.value.port, token: infoCaps.value.token });
			// 12z: the configured cap actually reaches the upload route.
			const capsUrl = (route, params) => `http://127.0.0.1:${infoCaps.value.port}/files/${route}?${new URLSearchParams(params).toString()}`;
			const bigPayload = Buffer.alloc(1024 * 1024 + 64, 7);
			const upBig = await fetch(capsUrl("upload", { repo, path: "big.bin" }), { method: "POST", headers: { authorization: `Bearer ${infoCaps.value.token}`, "content-type": "application/octet-stream" }, body: bigPayload });
			check("12z. configured upload cap enforced (413 over 1MB)", upBig.status === 413, `status=${upBig.status}`);
		}

		// ── 13: aborted upload leaves no temp litter ──────────────────────────
		// A stalled body aborted mid-flight must clean up its .dshup-* temp and
		// never publish the target file.
		const abortCtl = new AbortController();
		const slowBody = new ReadableStream({
			start(controller) {
				controller.enqueue(Buffer.alloc(64 * 1024));
				// never close: the transfer stalls until the client aborts
			}
		});
		const abortFetch = fetch(filesUrl("upload", { repo, path: "aborted-upload.bin" }), {
			method: "POST",
			headers: { ...filesAuth, "content-type": "application/octet-stream" },
			body: slowBody,
			signal: abortCtl.signal,
			duplex: "half"
		}).catch(() => "aborted");
		setTimeout(() => abortCtl.abort(), 250);
		await abortFetch;
		await sleep(400);   // let the sidecar's error path unlink the temp
		// The temp form is `<target>.dshup-<hex>` (SUFFIX match — an anchored
		// ^\.dshup regex here once made this assertion vacuously pass).
		const litter = readdirSync(repo).filter((n) => /\.dshup-[0-9a-f]{8}$/.test(n));
		check("13a. aborted upload leaves no .dshup-* temp litter", litter.length === 0, litter.join(","));
		check("13b. aborted upload never published the target", !existsSync(join(repo, "aborted-upload.bin")));

		// ── 14: non-ASCII paths come back RAW from status ─────────────────────
		// (regression: -c core.quotePath=false must reach every git call — with
		// git's default, "uploaded 文件.txt" arrives octal-escaped and quoted
		// ("uploaded \346\226\207…txt") and the change list displays that
		// verbatim; LC_ALL=C in the sidecar makes the default escape certain)
		const stRaw = await directCall(infoA4.value, "status", { repo });
		const stRawJson = await stRaw.json();
		const stFlat = JSON.stringify(stRawJson?.value ?? {});
		check("14. status returns raw UTF-8 paths (no quotePath escaping)", stRawJson.ok === true && stFlat.includes("uploaded 文件.txt") && !stFlat.includes("\\346"), stFlat.slice(0, 160));

		// ── 15: log exposes parents for the git graph ──────────────────────────
		// A real merge commit must carry BOTH parents (the client lane
		// algorithm draws fan-out from %P alone).
		git(repo, "checkout", "-b", "graph-side");
		writeFileSync(join(repo, "graph-side.txt"), "side\n", "utf8");
		git(repo, "add", ".");
		git(repo, "commit", "-m", "graph side commit");
		git(repo, "checkout", "main");
		writeFileSync(join(repo, "graph-main.txt"), "main\n", "utf8");
		git(repo, "add", ".");
		git(repo, "commit", "-m", "graph main commit");
		git(repo, "merge", "--no-ff", "graph-side", "-m", "graph merge commit");
		const lg = await directCall(infoA4.value, "log", { repo, count: 10 });
		const lgJson = await lg.json();
		const lgLines = lgJson?.value?.lines ?? [];
		const mergeEntry = lgLines.find((l) => l.subject === "graph merge commit");
		const firstLinear = lgLines.find((l) => l.subject === "graph main commit");
		check("15. log returns parents (merge has two, linear has one)", lgJson.ok === true && Array.isArray(mergeEntry?.parents) && mergeEntry.parents.length === 2 && Array.isArray(firstLinear?.parents) && firstLinear.parents.length === 1, JSON.stringify(lgLines.slice(0, 3)).slice(0, 240));

		// ── 16: malformed request-target must 400, never crash ────────────────
		// (regression: `GET //:80` threw inside new URL() BEFORE the token
		// gate; the unhandled rejection killed the whole sidecar — an
		// unauthenticated local DoS.)
		const malformedStatus = await new Promise((resolveMal) => {
			const sock = netConnect(infoA4.value.port, "127.0.0.1", () => {
				sock.write("GET //:80 HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n");
			});
			let head = "";
			sock.on("data", (d) => { head += d.toString("latin1"); });
			sock.on("error", () => resolveMal(null));
			sock.on("close", () => resolveMal(/^HTTP\/1\.[01] (\d{3})/.exec(head)?.[1] ?? null));
		});
		check("16a. malformed request-target answers 400 (not a crash)", malformedStatus === "400", `status=${malformedStatus}`);
		const afterMal = await directCall(infoA4.value, "status", { repo });
		const afterMalJson = await afterMal.json();
		check("16b. sidecar still alive after malformed request", afterMalJson.ok === true, JSON.stringify(afterMalJson).slice(0, 120));

		// ── 17: rev-shaped params reject option injection ─────────────────────
		// (regression: `show --output=<path>` placed user input before `--`,
		// letting a token holder turn "view a commit" into an arbitrary
		// file-write primitive.)
		const pwnPath = join(repo, "rev-inject-pwned.txt");
		const showInject = await directCall(infoA4.value, "show", { repo, target: `--output=${pwnPath}`, path: "a.txt" });
		const showInjectJson = await showInject.json();
		check("17a. show rejects option-shaped rev (invalid-rev)", showInjectJson.ok === false && showInjectJson.error?.code === "invalid-rev", JSON.stringify(showInjectJson).slice(0, 160));
		check("17b. injected --output file was NOT written", !existsSync(pwnPath));
		const resetInject = await directCall(infoA4.value, "reset", { repo, target: "--output=" + join(repo, "reset-pwned.txt"), mode: "soft" });
		const resetInjectJson = await resetInject.json();
		check("17c. reset rejects option-shaped rev", resetInjectJson.ok === false && resetInjectJson.error?.code === "invalid-rev", JSON.stringify(resetInjectJson).slice(0, 160));
		const showOk = await directCall(infoA4.value, "show", { repo, target: mergeEntry.hash });
		const showOkJson = await showOk.json();
		check("17d. legitimate rev (full hash) still works", showOkJson.ok === true && Array.isArray(showOkJson.value?.files), JSON.stringify(showOkJson).slice(0, 120));

		// ── 18: /vendor serves without token; traversal fenced ────────────────
		const vendorUrl = (p) => `http://127.0.0.1:${infoA4.value.port}/vendor/${p}`;
		const vOk = await fetch(vendorUrl("monaco/vs/loader.js"));
		check("18a. vendor asset served without token (Monaco loader)", vOk.status === 200 && /javascript/.test(vOk.headers.get("content-type") ?? ""), `status=${vOk.status} type=${vOk.headers.get("content-type")}`);
		check("18b. vendor response carries content-length (streamed, not buffered blindly)", Number(vOk.headers.get("content-length") ?? 0) > 0);
		// Traversal fencing, two layers:
		// (a) `%2e%2e`-style segments are normalized away by WHATWG URL
		//     parsing (client AND server re-parse alike) — the path falls out
		//     of /vendor/ entirely and dies at the TOKEN gate: 401, fail-closed,
		//     no bytes served.
		// (b) `..%2F`-style (encoded SEPARATOR) survives URL parsing as one
		//     segment but decodes to ../ inside handleVendor — this is the
		//     case the resolve+startsWith fence exists for: 403.
		const vEscapeNorm = await fetch(vendorUrl("%2e%2e/package.json"));
		check("18c. vendor traversal (normalizable) fail-closed 401", vEscapeNorm.status === 401, `status=${vEscapeNorm.status}`);
		const vEscape = await fetch(vendorUrl("..%2Fpackage.json"));
		check("18c2. vendor traversal (encoded separator) rejected 403", vEscape.status === 403, `status=${vEscape.status}`);
		const vMissing = await fetch(vendorUrl("monaco/vs/no-such-file.js"));
		check("18d. vendor missing asset 404s", vMissing.status === 404, `status=${vMissing.status}`);
	} finally {
		for (const { port, token } of shutdownUrls) {
			await fetch(`http://127.0.0.1:${port}/shutdown`, { method: "POST", headers: { authorization: `Bearer ${token}` } }).catch(() => {});
		}
		await sleep(400);
		try { rmSync(repo, { recursive: true, force: true }); } catch { /* temp dir */ }
	}

	console.log(results.join("\n"));
	console.log(`\n${passed} passed, ${failed} failed`);
	process.exit(failed === 0 ? 0 : 1);
}

main().catch((error) => {
	console.error("E2E fatal:", error?.stack ?? error);
	process.exit(1);
});
