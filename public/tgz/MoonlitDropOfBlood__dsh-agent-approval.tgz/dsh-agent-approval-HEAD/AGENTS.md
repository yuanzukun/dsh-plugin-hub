# AGENTS.md — dsh-agent-approval

面向 AI agent 与协作者的开发指南。**读这里再动手**，尤其"关键机制"和"重要注意事项"，记录了本项目踩过的大量坑。

## 项目是什么

一个 **DeepSeek Harness（DSH）双面（Host + Client）插件**：新增一种 **自动审批** 权限模式。

- 以 **workspace-write 为基线沙箱**；工具请求提权（更宽沙箱，如 `sandbox_permissions`）时，不再弹人工审批，而是交由**一个独立的审批 Agent（subagent）裁决**。
- 审批 Agent 在**独立会话**里运行：零父级上下文、全局工具全部空白（`toolFilter: {allow:[]}`）、审批策略被委派机制钉死为 `never`（不可能递归再审批），必须通过 `structured_output` 结构化工具给出裁决：`{ decision: approve|reject, riskLevel, rationale }`。
- **风险即拒绝**：破坏性 / 不可逆 / 越界 / 理由与实际参数不符 → `reject`；只有"安全、可逆、与任务相符、理由诚实"才 `approve`。
- **Fail-closed**：审批 Agent 启动失败、超时、结果不合法、请求被取消 → 一律按拒绝处理（`unavailable`/`cancelled`），绝不静默放行。
- **设置面板**新增 **自动审批** 页（`settings.section`），**两种模式分开摆**（v1.10.0）：上半部分是**自动审批**——配置审批模型（provider/model 或 Harness 默认模型，**只能是 LLM 路由**，v1.10.0 起不再提供 Jev）与审批超时、**裁决方式**（LLM 直连 / 隔离子代理）、查看已开启会话（chip 显示**与会话列表同源的标题**（Host 侧经可选服务 `sessionTitle` 折叠，缺席降级为空串）+ 短 id，悬停看完整会话 ID 与工作区 cwd；`getState` 的 `enabledSessions` 为 `{id,title,cwd}[]`，client 兼容旧 Host 的 `string[]` 形状）、**放行/拒绝规则表**（deny/allow 规则先于模型短路，持久化）；下半部分是**独立的「自动审查」卡片**——判定后端下拉（v1.11.0：TypeSafe Jev / LLM，见第 12 节）+ TypeSafe Jev 配置（API Key / 模型 / Endpoint / 置信度阈值，**恒显示，不随任何 Provider 选择隐藏**）；v1.10.1 删掉了全局默认开关（「逐调用审查」下拉），保存可用的 Jev Key 只让自动审查**变为可选**，不再把任何会话拉进审查。**审计不在这里**：会话窗口顶部新增**「审批」标签页**（`conversation.view` ring，紧邻「轨迹」；chat=0 / trajectory=10 / 审批=11），按会话折叠展示审批记录（**倒序、最新在上**；结论/风险/模型/耗时/理由，悬停看完整理由与工具参数，行内可一键「加白」）——记录存在**会话目录内的独立旁路文件**（见第 6 节）。
- 输入框 `/permission` 菜单的「自动审批」预设 + `/agent-approval on|off` 命令为当前会话开关（**刻意没有 composer chip**——开关本就属于权限菜单，菜单旁边再放一个属冗余，已移除）；关闭时**恢复开启前的权限旋钮**（沙箱模式 + 审批策略）。

## 目录结构

```
dsh-agent-approval/
├── package.json          # ESM 双面包：dsh.client: {platform:"web"} + exports(., /client, /typert, /package.json)
├── index.js              # Host 半：AgentApprovalService（TypertRemoteService 子类，类插件）
├── client.js             # Client 半：window.__ModuleLoader__.load bundle（设置页 + Remote 调用）
├── typert.host.js        # Typert Host manifest：agentApproval Remote 服务的 schema/调用描述
├── cordis.patch.yml      # dsh bundle patch（挂载行 + permission 预设表覆盖）
├── scripts/check-mode-switch.mjs # 模式切换/审查语义回归（mock ctx 驱动真实 Service.init 闭包，已挂进 npm run check）
├── scripts/patch-glyph.mjs # 可选：权限菜单图标补丁（标准安装不自动执行）
├── .github/workflows/release.yml  # 打 v* 标签时构建并发布 GitHub Release
├── AGENTS.md             # 本文件
├── README.md
└── LICENSE               # MIT
```

## 关键机制

### 1. DSH 正式插件 = 三件套（Host / Client / Typert）

| 文件 | 作用 | 被谁加载 |
|---|---|---|
| `index.js` | Host 半：Cordis **类插件**（导出 Service 类），注册 `agentApproval` 服务 | cordis loader（composition `insert` 行） |
| `client.js` | Client 半：浏览器 UI bundle | `client-modules`（扫描 `dsh.client` 声明 → 注入 `window.__DSH_BOOT__`） |
| `typert.host.js` | 描述 `agentApproval` 服务的 Remote 方法（wire schema / invocation） | `typert-loader`（扫描包的 `./typert` 导出） |

三者的**关键名字必须一致**：
- `index.js` 导出的类名 → `AgentApprovalService`
- `typert.host.js` 的 `model.services[].key` / `exportName` → `agentApproval` / `AgentApprovalService`；每个 invocation 的 id/service/namespace/method 与 client 描述符一一对应
- `client.js` 的 `CLIENT_REMOTE` 描述符 id → `dsh-agent-approval#agentApproval/<method>`，调用走 `ctx.get("remote.agentApproval").<method>()`
- `package.json` 的 `exports`：`"."`、`"./client"`、`"./typert"`、`"./package.json"`（**必须**有 `./package.json`，否则 `require.resolve("<pkg>/package.json")` 失败）
- **codec 双格式（v1.7.0，两代 Typert 契约并存）**：manifest 与 client 描述符的每个 codec/result **必须同时**带 `schema` 与 `create: () => schema` 两个字段（指向同一 schema 对象）——DSH ≤0.1.5-rc.3 的 typert-loader 校验 `"_zod" in schema`、client registry 校验 `schema.parse`，而 DSH 0.1.7-rc.1 起两侧都改校验 `create()` 工厂（"has no create() factory" 直接拒绝注册：Host 侧 Remote 全挂、Client 侧 `$mount` 抛错让整个 bundle 的 apply 失败）。改 wire 形状后必须跑 `npm run check`（内含 `scripts/check-typert-manifest.mjs`：镜像两代校验器 + 从真实 client.js 提取描述符做 id/参数/typeSymbol 对齐）。

### 2. Host 半：类插件 + Remote 方法

```js
export class AgentApprovalService extends TypertRemoteService {
  static inject = ["approval", "subagents", "agents", "timer"];
  constructor(ctx, config) { super(ctx, "agentApproval"); }  // 必须传精确服务键
  [Service.init]() {
    markRemoteMethod(this, "getState", "getState");
    // ...每个 Remote 方法都要标记
  }
}
```

- **不要导出插件对象 `{apply}`**；导出 Service 类（loader 用 `new Callback(ctx, config)` 实例化，第二个参数是插件 config 不是服务键——这是 dsh-archive-manager 踩过的构造坑）。
- `Remote` 装饰器**不能直接写**（Node ESM 不支持 Stage 3 装饰器），用 `markRemoteMethod()` 手动驱动（同 token-stats / archive-manager）。
- `inject` 里是**硬依赖**（缺任何一个插件进入 waiting）：`approval`（审批瀑布 + setPolicy）、`subagents`（spawn provider）、`agents`（sessionId→Agent 查找）、`timer`（`ctx.timeout` 竞速）。可选面（`llm`/`agentDefaultModel`/`systemPrompt`/`commands`）用 `this.ctx.get()` / `this.ctx.inject([...], scope => ...)` 挂载，缺席时优雅降级。

### 3. 核心：prepend 抢占 `approval/request` 瀑布（本插件最重要的机制）

- DSH 的审批流：工具提权 → `ctx.approval.request()` → 服务先应用 session policy（`ask` 才继续）→ 派发 `approval/request` **waterfall** → 组合的 answerer 链（web 端是 host-apiproxy 的**人工弹窗 answerer**，它在组合加载时就注册了）。
- Cordis waterfall 的 hook 顺序 = 注册顺序（先注册 = 最外层 = 最先执行）。本插件**晚于** apiproxy 注册，所以必须：

```js
this.ctx.on("approval/request", (req, next) => this._onApprovalRequest(req, next), { prepend: true });
```

`{ prepend: true }` 把监听器 **unshift 到队首**，从而先于人工 answerer 执行。已开启的会话：直接裁决并返回 outcome（`allowed-once`/`rejected`/...），**不调用 `next()`**（否决了后续链条）；未开启的会话：原样 `return await next()`，人工弹窗行为完全不变。
- **监听器为什么收得到所有会话的派发**：审批派发带 `scopeTarget(this, req.agent)` 过滤器，untagged 监听器（本插件挂在 profile 根组合，无 scope 标签）一律放行。**因此本插件必须挂在 HOST 平面**（`cordis.patch.yml` 的 `- insert:` 行），不要放进任何 isolate realm。
- **为什么开启时要切到 `ask`**：policy 为 `never` 时 `decide()` 在瀑布之前就直接返回 `rejected`，监听器根本不会执行。`_setEnabled(on)` 在开启时记住会话的**有效**旋钮值（override ?? 组合默认——一个活在 `never` 组合默认下的会话，关闭时必须回到 `never` 而不是"无覆盖"状态），然后：沙箱用 `session.append("sandbox/mode", { mode: "workspace-write" })`（与官方 `setSandboxMode` 完全同一事件形态）；审批策略用 `approval.setPolicy(agent, "ask")`（规范写路径：追加 `approval/policy` 事件 + 给模型注入切换通知）。关闭时经同一对规范 setter 恢复记住的值（值未变化时 setter 自动 no-op）。

### 4. 审批裁决：一次性 `spawn` 子代理 + 结构化裁决（v1.8.0 起为可选的 `judgeMode: "subagent"` 路径；**默认裁决器是 LLM 直连，见第 11a 节**——本节的输入/输出契约两路完全同构）

```js
const run = await this.ctx.subagents.start("spawn", {
  label: "approval-judge",
  prompt: [{ type: "text", text: judgePrompt }],
  parent: agent,              // 用于派生 workspace / lineage / 深度
  signal: req.signal,         // 请求取消 → 子代理取消
  agentOptions: { provider, model },   // 配置了审批模型时才传
  outputSchema: VERDICT_SCHEMA,        // { decision, riskLevel, rationale }
  toolFilter: { allow: [] },           // 全局工具全部空白（structured_output 是 scoped 注册，不受影响）
  persona: APPROVER_PERSONA,           // 独立安全审批员人格，fail-closed 倾向
});
```

- **裁决 schema 必须是 JSON-Schema 受限子集**（`assertObjectJsonSchema`）：只允许 `type/properties/required/additionalProperties/items/enum/const` + 注解。不要写 `pattern`、`format`、数值范围。
- **零工具**：`toolFilter: {allow: []}` 合法（空 allow 数组不是 no-op——no-op 判定只针对 allow/deny **都缺失**），审批员只能"看"和"判"，不能"做"。
- **不会递归审批**：DSH 委派机制自动把子代理的审批策略钉死为 `never`（`captureDelegatedPolicyOverrides`），子代理自己提权只会被直接拒绝。
- **结果读取**：`run.result`（Promise，不 reject 业务失败）→ `result.structured`（合法裁决）+ `result.stopReason === "completed"`。两者任一不满足 → `unavailable`（fail-closed）。
- **竞速**：`Promise.race([run.result, abortRace, this.ctx.timeout(timeoutMs)])`，`finally` 里 `run.dispose()`。超时/取消/基础设施故障分别映射 `unavailable`/`cancelled`。
- **给审批员看的材料**：从会话日志按 `callId` 倒查 `tool/call` 事件的 `arguments` 原始 JSON（**精确命令**，不是转述）、`req.reason`（工具方的提权理由）、workspace cwd、以及**首条真实用户消息（原始任务陈述）+ 最近 3 条真实用户消息**（`user/message` 且 `source.kind === "user"`，每条截断 800——任务的 ground truth；短会话里首条已在最近列表中则去重）。审批提示词明确 APPROVE 四条件与 REJECT 清单；v1.4.0 起**删除"存疑即拒"**——拒绝必须能指出该操作的**具体可信风险点**（毁什么/泄什么/越什么界），笼统不确定、没见过的命令、简略的理由都不是拒绝理由（误杀治理，见第 5 节规则表）。
- **审批员自身约束消歧（v1.3.5 修复的真实误杀）**：审批员子会话被委派机制钉死 `approval/policy: never`，harness 会向它注入运行时上下文 "Approval prompts are disabled in this session…"。小模型（flash）曾把这句**关于审批员自己**的约束误读为**请求方会话**的属性，两次以此为由拒绝了本该批准的操作（见 records.jsonl 2026-08-21 / 2026-08-22 两条 rejected）。因此 persona 与提示词都显式声明："你自身的 never 策略与固定作用域只约束你自己，绝不可作为请求方会话的属性或拒绝理由"。改提示词时**不要删掉这句**。
- **裁决一致性口径**：判"操作 vs 用户任务"的**客观对齐**，不依赖请求方理由的措辞水平——理由只是辅助证据：操作本身明显安全且与任务相符时，理由写得简略**不拒**；但理由与实际参数造假/不符仍**照拒**（读过审核标准的 agent 不能靠文笔获得优待）。
- **开发流程口径**（端到端任务不被卡死的关键）：提权档位只有粗粒度两档，审批员**判实际操作而非档位名**——项目自带的安装/构建/部署脚本写其文档指定的安装路径（如工具自身 profile 目录）、覆盖自身已安装的文件（可从源码再生成）、读调试所需的工具自有配置/日志，都算"任务明确所需"可 approve；但**修改操作系统或其他应用的数据**仍一律 reject。

### 4b. TypeSafe Jev 直连判定后端（v1.6.0 起；**v1.10.0 起只服务自动审查**）

Jev 是 "System One" 决策模型，**不在** `llm.listProviders()` 目录里（不是聊天路由，不能走 Harness 模型注册表），因此只能直连其 HTTP API。**v1.6.0–v1.9.x 它还能当自动审批的判定后端（设置页 Provider = TypeSafe Jev，合成 id `typesafe`）；v1.10.0 起这条路径被删除**——用户裁定：Jev 的风险判断（校准概率、无自由推理）弱于 LLM，而提权正是人工审批原本要守住的路径。落地形态：

- **不再有 Jev 审批**：`_judge` 里没有 typesafe 分支（只有 `judgeMode` 的 LLM 直连 / 子代理两条），`_judgeRoute()` 也不认它，`JEV_PROVIDER` 常量已删（只剩 `JEV_LEGACY_PROVIDER` 用于迁移）；`_judgeWithJev` 与 `_jevVerdict` **已删除**。设置页审批 Provider 下拉只有 Harness 目录（+「默认（Harness 默认模型）」），「裁决方式」下拉**恒显示**。
- **迁移**（无用户操作）：`_loadPersisted` 读到 `model.provider === "typesafe"` 就清成 `{provider:"",model:""}`（回落 Harness 默认路由）；`setModel` 收到 legacy `typesafe` 同样清空，绝不复活死路由。**别把 `JEV_LEGACY_PROVIDER` 改回可用**。
- **Jev 仍是自动审查的唯一判定后端**：设置页**独立**的「自动审查」卡片（不再挂在 Provider 选择后面），字段 API Key / 模型 / Endpoint / 置信度阈值，持久化仍是 config.json 的 `jev` 字段，gate `_jevGateOk()` **只看 key 可解析**（不再读 `_model`）。
- **协议**：POST `<endpoint>`（默认 `https://api.typesafe.ai/v1/systemone`，可配第三方网关），`Authorization: Bearer <key>`，body = `{ state, model, questions }`。Key 来自 config.json 的 `jev.apiKey`（明文，本机文件）或环境变量 `TYPESAFE_API_KEY`（留空时回退）；两者都缺 → gate 关闭（审查根本开不起来）。`fetch` 用 Node 全局，**无新 npm 依赖**。
- **state**（`_jevStateOf`）：workspace / tool / statedReason / toolArguments（4000 截断）/ firstUserMessage / recentUserMessages——与 LLM 审批提示词**同一份 ground truth**（复用 `_recentUserContext`）。
- **questions**：`JEV_QUESTIONS` 只是 `JEV_REVIEW_QUESTIONS` 的 **criteria 底座**（`decision` = Choice(approve/reject，**策略全部写进 criteria 描述**——Jev 按字面读指令、领域知识只能进 state+criteria)；`riskLevel` = Choice(low/medium/high)；`concreteRisk` = Noul（"是否存在具体可信风险"辅助信号，只进审计理由）。`_jevRequest` 的 `questions` 缺省值已改成 review 组，**别改回去**。
- **置信度门控**：`decision.confidence < 阈值`（默认 0.5，可配 0.01–0.99）→ 审查**拒绝该次调用**且审计记 `unavailable`——**对称适用**：低置信的 reject 也不记拒绝（v1.4.0 误杀治理的对称版："模型没把握就不裁决"）。校验与门控全部在 `_jevParse` 一处。
- **审计**：model 列 `jev(<served version>)`——响应体 `model` 字段会解析别名（请求 jev-latest → 记 jev-1.13.0）；理由列由概率分布合成（**Jev 不生成文字**，没有自然语言推理可记；v1.7.2 起同时含**风险轴**的置信度与 `p low/medium/high`——`riskLevel` 与 `decision` 是两条独立问题，**risk=high 不改变 outcome**，但审计理由必须能看出 high 的把握度，字段缺失只省略、绝不改变校验门槛）；`childSessionId` 为空（没有子会话）。
- **wire 同步**：`setJevConfig` invocation（index.js `markRemoteMethod` + typert.host.js `jevConfigSchema`/invocation/`AgentApprovalJevConfig` 等类型 + client.js 描述符）；`setJevConfig` 的 result 带 `reviewAvailable`，让 client 一趟就知道 gate 开没开；**v1.10.1 起 result 与 `getState` 都不再有 `reviewDefault`**（全局默认开关已删除，见第 11b 节）；`getState` 带 `jev` 字段，client 对旧 Host 缺该字段时保留空草稿降级（saveJev 还有 `typeof remote.setJevConfig === "function"` 守卫）。
- **已知限制**（设置卡片已注明）：Jev 官方声明中日韩文本"可处理但准确率较低"（审查 state 里的中文任务上下文会打折）；early access 阶段速率限制可能变化——所有异常都归 fail-closed，不会误放行。

### 5. 规则表与会话内信任（v1.4.0 起，先于模型裁决）

提权进入 `_judge` 后按固定顺序短路，全部**零模型开销、零人工弹窗**：

1. **deny 规则命中 → 直接 `rejected`**（所有 deny 先于任何 allow 判定，后加的 deny 永远压过先加的 allow）；**allow 规则命中 → 直接 `allowed-once`**。规则形状 `{ id, effect, tool, match, note, createdAt }`，持久化在 config.json 的 `rules` 字段：`tool` 为精确工具名或 `"*"`；`match` 为空 = 该工具全部调用，否则是**参数原始 JSON 的子串**或 `/pattern/flags` 正则（`_ruleRegex` 编译失败 = 永不命中，`addRule` 时即校验拒绝）。规则命中也写审计（model 列记 `rule`）。
2. **会话内信任缓存**：模型 approve 后把 `工具名 + "\n" + 参数原始 JSON` 指纹存入该会话的 Set（`_trusted` Map）；同一会话内**参数逐字节相同**的再次提权直接 `allowed-once`（审计 model 列记 `trust`）。**不跨会话、不泛化到相似参数**，随 `_enabled` 条目一起在三处删除点清空（preset 切走 / session disposed / `_disable`）。跨会话复用走规则表：会话窗口「审批」tab 审计行的「加白」按钮一键把已批准操作存成 allow 规则（记录里的 args 是完整参数 JSON 的**前缀**，截断标记 `…[truncated]` 需先剥掉）。
3. 都不命中才进裁决器（v1.8.0 起默认 **LLM 直连**，见第 11a 节；隔离子代理见第 4 节；**v1.10.0 起这里只有 LLM，Jev 不再参与提权裁决**，见第 4b 节）。**规则/信任短路对自动审查模式（第 11b 节）同样生效**——这是逐调用审查的成本控制关键。

- 设置页「放行 / 拒绝规则」卡片管理规则（Remote 方法 `addRule`/`removeRule`，整表返回；`getState` 带 `rules` 字段，client 对旧 Host 缺该字段时降级为 `[]`）。
- wire 变更照旧三处同步：index.js 构造、typert.host.js（`ruleSchema` + `rulesValueSchema` + 两个 invocation + `AgentApprovalRule`/`AgentApprovalRulesResult` 类型声明）、client.js（描述符 + UI）。

### 6. 审计记录（v1.5.1 起：会话目录内的独立旁路文件）

- 每条裁决由 Host `_record(session, entry)` 追加到**请求会话自己存储目录里的旁路文件** `<sessionDir>/agent-approval.jsonl`，目录按 DSH 两代 API 解析（`_recordsFileOf`，两代都试）：≤0.1.7 走 `sessionPersistence.locate(session.header)`（纯路径计算，活会话可用；返回 `{kind:"jsonl", path:<session.jsonl.zstd 绝对路径>}`）；**0.2.0 删掉了 `locate`**，改走 JSONL 后端的 `await sessionPersistence.resolveCurrentLog(session.id)`（返回日志绝对路径，或"只有历史代"时 undefined）。两者都取 dirname。定位失败降级为 `<DSH_HOME>/agent-approval/records/<sessionId>.jsonl`（重启仍安全，但删会话不随删）。语义上仍是"跟随会话保存"：随会话目录存在，删除会话即消失。
- **绝不要把审计写进会话事件日志（v1.5.0 的方案，半天即废弃）**。踩坑全过程：`dsh-session` 的 `append()` 运行时不校验事件类型枚举，`dsh-session-persistence-jsonl` 也按原样回放——但 **`dsh-session-persistence` seam 在加载时强制校验**：`KNOWN_SESSION_EVENT_TYPES` 之外的类型，事件信封必须带 `ignorable: true`，否则**整个日志拒绝加载**（"refusing to interpret"）。而活会话的写入口 `session.append(type, data)` 只接受 type/data/surface 元数据，**给不了 ignorable 标记**（类型签名也限死 `SessionEventType`）——所以一条审批记录就会让该会话永远无法恢复。另外日志压实（compaction）也可能丢弃 ignorable 外部事件。
- **"v1.5.0 零写入"的旧结论是假的，2026-09-06 已证伪并修复**。旧版 `check-session-log.mjs` 用朴素 magic 扫描切帧且带占位符 bug，只解出部分帧就报"零写入"——实际 session-886106a4 的日志里有 **3 条**未标 ignorable 的 `agent-approval/record`（seq 52022/117810/140809），会话历史加载被拒。注意官方机制本就给插件事件留了正门：`dsh-session` 的 `known-event-types.js` 明说 **`ignorable` 标记就是 repo 外插件事件的兼容机制**（只是 `session.append` 的活写入路径给不了它）。修复用 `scripts/repair-session-log.mjs`：按 `scanZstdFrames` 的结构化走帧（逐 block header 前进，不靠帧头 content size），**只给 3 个事件的信封补 `"ignorable":true` 并重压所在帧，其余帧字节不动**——绝不能删行，扫描器强制 seq 连续（`event.seq !== events.length` 即 seq gap）。写前快照 mtime/size 防并发写、写前备份、写后全帧解码验证。校验/扫描用重写后的 `check-session-log.mjs`（可 `import { auditLog }` 库用；注意 `text-chunks`/`reasoning-chunks`/`tool-call-chunks` 是存储行、`type:"session"` 是头记录，都不进事件类型校验；`zstdDecompressSync`/`createZstdDecompress` 对多帧拼接文件只会解出第一帧，必须逐帧解）。全库 194 个日志复扫，仅此一个会话中毒。seq 140809 写于 12:27:59（"重启"之后）——说明当时仍有旧构建的 Host 半在写日志；现装 v1.5.1 已验证只剩 `permission/preset`/`sandbox/mode` 两种已知类型的 `session.append`。
- **最终裁定（2026-09-06，用户明确）**：zstd 会话日志里**不存、不读任何插件自定义数据**。v1.5.2 起 `sessionRecords` **只读旁路文件**（v1.5.1 的"防御性日志折叠"已删除，`RECORD_EVENT` 常量一并移除）。日志中遗留的 3 条 ignorable record 事件（seq 52022/117810/140809）为惰性历史，加载已验证安全；**物理删除不可行**——删行会破坏 seq 连续性（扫描器以 `event.seq !== events.length` 判 gap），修复需全日志重编号，风险远大于收益，不要尝试。
- 读取：Host `sessionRecords({ sessionId })` **只读旁路文件**（`_recordsFileOf`），按 `at` 正序返回，同时带 `enabled`（该会话当前是否开启）。Client「审批」tab 挂载 + 每 10s 轮询（tab 未激活时不渲染、不轮询）。
- 每条：时间、会话、工具、结论、风险等级、审批模型、耗时、理由（截断 600）、`childSessionId`（审批 Agent 自己的会话短 id——在会话列表里能找到完整推理记录）。
- **追加必须吞错**：`_record` 是 fire-and-forget 且全链 try/catch——审计失败绝不影响审批主流程。没有"清空记录"：随会话存储的事实源，且权威审计（`approval/asked`+`approval/decided` 事件对）本就不归我们管。
- **v1.4 → v1.5 迁移**：`scripts/migrate-records.mjs`（`--dry-run` 可预览）把旧全局 `records.jsonl` 按短 sessionId（UUID 前 8 字符）匹配到 `~/.dsh/sessions/<workspace>/<session-id>/`，追加写入各会话的 `agent-approval.jsonl`（幂等去重），最后把旧文件改名为 `records.jsonl.migrated` 防止重复迁移。历史 bug 行（`sessionId` 为字面 `"session-"`）无法归属，直接跳过。本机已迁移：157 条 → 8 个会话，56 条无法归属。
- **必须整形状构造**（`typert.host.js` 的 result schema 是 strict）：每个字段都在、类型正确，数组用 `.readonly()`。新增字段要同步改三处（index.js 构造、typert schema、client 展示）。
- **短 id 切片必须跳过 `session-` 前缀**：DSH 的 sessionId 是 `session-${randomUUID()}` 格式（见 `dsh-host-apiproxy/lib/index.js` 的 `session create`：`session-${randomUUID()}`），前缀正好 8 字符，`String(id).slice(0, 8)` 只会切到那个无意义的前缀——历史 bug：所有审计行的 `sessionId` 全是 `"session-"`，已开启会话 chip 显示也是。Host 的 `shortId()` / Client 的 `shortSessionId()` 都必须先 `id.startsWith("session-")` 剥掉前缀再取 8 字符；`childSessionId` 来自 `run.id = randomUUID()`（无前缀），同一函数兼容。**不要**改回 naive slice——会再次触发。

### 7. Client 半：bundle 格式

- 必须 `window.__ModuleLoader__.load({ id, factory })`，`exports.inject = ["slots", "remote"]`。
- **按钮一律用官方 Button 原子**：`const ui = require("@deepseek-ai/dsh-client-ui-primitives")`，`h(ui.Button, { variant: "primary"|"ghost"|"outline", size: "sm", onClick }, "…")`。自定义 `.aapr-btn` 按钮样式已移除——它不跟 `--dsw-alias-button-*` token 家族，深色模式下难看（与 dsh-memory-manager 踩过的同一个坑，同一个修法）。
- **Remote 命名空间必须自挂载**：`await ctx.remote.$mount(CLIENT_REMOTE)`（dsh-api-remotes 只挂载官方命名空间），然后 `ctx.get("remote.agentApproval")`。描述符与 `typert.host.js` 的 invocation 一一对应；浏览器没有 zod，用 passthrough schema（`{ parse: (v) => v }`），且每个 codec 同时携带 `schema` + `create: () => schema` 双格式（见第 1 节 codec 双格式；0.1.7 起 `$mount` 校验 `create()`）。
- **返回值双层信封**：gateway 返回 `res.value` = Host 方法的 `{ ok, value }` 信封，client 的 `pick()` 做容忍双形状解包 + 双层错误上抛（token-stats 踩过"多包一层"的坑）。
- **CSS 注入**用 `document.createElement("style")` + `ctx.effect(() => () => styleTag.remove())`；样式一律用 `--dsw-alias-*` 主题变量。
- 两个 Slot：`settings.section`（id `agent-approval`，order 30，label `() => SETTINGS_LABEL`）+ `conversation.view`（id `agent-approval-audit`，**order 11**——chat=0、trajectory=10，紧邻轨迹；label `() => "审批"`）。conversation.view 是 **session-scoped list slot**：组件经标准 kit 拿到 `useSession` hook，`useSession((s) => s)` 的快照读 `sessionId` 叶子字段即可，无需 inject；组件只在 tab 激活时渲染（`renderSlot(..., { only: active.id })`），轮询因此零闲置开销。tab 栏渲染条件是 `tabs.length > 1`，注册即出现。曾有过 `conversation.input.left` 的「🛡 审批」chip（id `agent-approval-toggle`，order 15，InputZone owner props 传 `props.session`，只读 `sessionId` 叶子字段），已移除——开关本就属于 /permission 菜单，菜单旁边再放一个开关是冗余。
- **设置导航图标**：DSH 0.1.x 的 `settings.section` 只投影 `id/order/label`，设置壳对每个外部 section 统一画通用齿轮（`client-ui-settings-general` 的 `navIcon()`，没有公开图标字段）。client.js 里 `registerSettingsNavIcon(SETTINGS_LABEL)` 用 MutationObserver 给 `[role="dialog"] nav button` 中文本等于 section label 的行打 `data-dsh-agent-approval-settings-nav` 标记，CSS 再隐藏 `>svg:first-child` 齿轮、用 `currentColor` mask 画 shield-check Lucide 图标（16px，跟随原生 hover/active 颜色）。换图标只需替换 CSS 里 data URI 的 SVG path（Lucide，24×24，stroke-width 2，stroke 用 black——mask 只取 alpha）。
- client.js 里**不要用 `?.` / `??`**（与 token-stats 保持一致的保守写法），用 `&&`/`||`；不要 `import`，用 `require("react")`。

### 8. 权限菜单集成（`permission` 行覆盖 + `permission/preset` 事件联动）

权限菜单（输入框 `/permission` 控件）的选项来自 **`dsh-permission-presets` 的 Config 预设表**；Web 端切换 = 执行 `/permission <preset>` 命令 → 追加 `permission/preset` 事件 + 旋钮事件。要让「自动审批」出现在菜单里：

1. **包的 `cordis.patch.yml`（bundle patch）里写 `- id: permission` 覆盖行**，把 `agent-approval`（bundle = workspace-write + ask）加进预设表。**patch 语义是整行替换 config（不合并）**，所以必须重述全表（read-only / workspace-write / **agent-approval** / danger-full-access）——**声明顺序即菜单顺序**，agent-approval 排在 Full access 上面；DSH 升级若改了基础表要手动同步。
2. **菜单图标（v1.3.2+ 由插件内置，无需 patch）**：菜单行 + 触发按钮的图标来自编译进官方 `dsh-client-ui-conversation` 的硬编码映射 `permissionGlyphs`（源码注释明说 "host-configured names outside the design set get none"），**没有公开注册口**，外部预设整行不渲染图标元素。client.js 的 `registerPermissionGlyphIcon(SETTINGS_LABEL)` 用 MutationObserver 给「自动审批」的 `/permission` 菜单行（`[role="menu"] button[role="menuitem"]` 中文本等于 label 者）和输入框旁触发按钮（非 menuitem、不在 `[role="dialog"]` 内、首 span 文本等于 label 且含 svg 者）分别打 `data-dsh-agent-approval-perm-item` / `data-dsh-agent-approval-perm-trigger` 标记。**触发按钮的候选必须含两个名字**（v1.8.2 修复的真实观感缺陷）：它渲染的是**当前选中的那个预设**，而 `registerReviewMenuItem(REVIEW_LABEL)` 只管菜单行、完全不碰触发按钮——只按 `SETTINGS_LABEL` 匹配的话，选中「自动审查」时输入框旁那处**一个图标都没有**（官方 `permissionGlyphs` 只认内置预设名）。修法是触发按钮按文本同时接受两个名字（v1.11.3 起按名字**分打两个 marker**：`PERM_TRIGGER_MARKER`（自动审批）/ `REVIEW_TRIGGER_MARKER`（自动审查），CSS 分别画 shield / search-check）；图标由 `currentColor` mask 规则绘制。**菜单行有 glyph-set 守卫**：只在"兄弟行已带官方图标"的菜单里打标——判定为菜单内存在 `span[class*="itemIcon"]`（v1.7.0 从 `_itemIcon_` 放宽：CSS-modules 两代编译名不同（`_itemIcon_<hash>_` vs `<hash>_itemIcon`）；选中行的对勾是 `_check_`，不会误判）。0.1.7-rc.1 起权限控件从 dsh-client-ui-conversation 拆到独立包 `dsh-client-ui-permission-presets`（composer 里挂 `conversation.input.permission` slot，`PermissionSelect` 已从 conversation 包删除），但菜单仍是同一 Menu 原语（`button[role=menuitem]` + itemIcon span），标记逻辑不变。设置页 → 通用 → 「权限」行的默认预设下拉（`Menu portal:true` 传送到 `<body>`，所有预设都无图标）因此**不再**被误标——否则「自动审批」会成为那里唯一带图标的行。历史方案 `scripts/patch-glyph.mjs`（直接补丁官方编译产物）已被取代——插件内置版随包分发、DSH 升级不丢；脚本保留作参考，新安装**不再需要**跑它。**v1.11.3 与宿主实验 auto 预设撞名（两把「自动审查」）**：0.2.x 宿主自带实验性逐调用审查预设（key `auto`），中文 label 同为「自动审查」（**走 locale `t("auto.label")`，菜单行还带 `EXP` badge，行文本=「自动审查EXP」**），且官方 `permissionGlyphs` **按预设 value 查得到它**（`["auto", PermissionIconAutoReviewRegular]`——图标映射看 value 不看显示名）。后果：菜单行因 badge 后缀天然不撞精确等值匹配，但**触发按钮按文本会命中宿主 auto 的选中态**——官方 trigger 自己渲染 `triggerIcon` span，旧版又把我们的 mask 叠在前面 = label 前两个图标（用户报告的 bug）。修法（client.js 三处）：① 触发按钮扫描先查 `span[class*="triggerIcon"] svg`，**已有官方图标一律不打标**（该 span 只在选中预设的 value 在 permissionGlyphs 里时才渲染，我们的两个预设 value 都不在，守卫不伤自己）；② `registerReviewMenuItem` 菜单行加同型守卫（行内已有 `span[class*="itemIcon"] svg` 就不打标；今天靠 badge 已不撞，守卫兜底未来宿主去 badge 的情形）；③ 自动审查换独立图标（Lucide `search-check`：16px 盒 + 24 viewBox，stroke 2 缩放后 ≈1.33px，与手绘 shield 的 1.31831 视觉等粗），行 marker（`REVIEW_ITEM_MARKER`）与触发 marker（`REVIEW_TRIGGER_MARKER`）共用这条 mask 规则。**gate-off 隐藏规则只能挂在行 marker 上**——扩到触发按钮的话 `display:none` 会把整个权限选择器吞掉。
3. **同 bundle 歧义规则**：`agent-approval` 与 `workspace-write` 的旋钮值完全相同；`derive()` 里"仍匹配的最后选中预设"赢得平局，所以**菜单显示什么完全由最后的 `permission/preset` 事件决定**。因此：命令开启时也追加 `permission/preset: agent-approval`（菜单同步显示）；命令关闭时按恢复的旋钮值回写正确的预设事件（跳过我们自己的条目），否则菜单会卡在「自动审批」。
4. **事件联动**（`session/event` 监听 `permission/preset`）：
   - 选中 `agent-approval` → `_enableCore`（此刻旋钮事件还没落，捕获的 prev 恰是切换前的值；我们写的旋钮值与预设服务随后要写的相同，它检查后跳过，无重复事件）。
   - 选中其他预设 → 只删 bookkeeping，**不恢复旋钮**（预设服务马上写自己的旋钮，恢复会打架）。
5. **跨重启存活**：`agent/created` 监听在（重）发布时折叠日志——`permission/preset` 折出 `agent-approval` 就重新启用。spawn 的审批员子会话不带 preset 事件（无 seed），不会递归重启用；fork 子会话 seed 里可能带父级的 preset 事件 → 会继承该模式（有意语义：模式跟随会话的工作；"later child switches win" 是官方允许的后来者覆盖）。
6. **防御**：`_presetRegistered()` 先确认表里有 `agent-approval` 才追加 preset 事件——没装覆盖行时，追加会被会话不变量（unknown preset）直接抛错。
7. **宿主 Session API 兼容（v1.4.2 修复的真实故障）**：DSH 0.1.2-rc.1 **删除了 `session.events` 公开快照数组**，改为 `snapshotEvents(from?, to?)` / `eventAt(seq)` / `seq`。插件所有日志折叠（`_lastKnob` / `_callArgsOf` / `_recentUserContext`）必须走 `_eventsOf(session)`（新 API 优先，legacy 数组兜底）。0.1.1→0.1.2-rc.1 升级后的症状极具欺骗性：监听器 try/catch 把 TypeError 吞掉，`_enableCore` 静默失败，没有任何会话能进入 `_enabled`，于是每个提权都 `next()` 落回人工弹窗——看起来"插件在运行但就是不审批"。**改任何读日志的代码前先确认没用裸 `session.events`。**
8. （已随 composer chip 的移除而作废）曾有的 chip 每 10s 轮询一次 enabled 状态；若未来重加 chip，注意 InputZone 的 ConversationSnapshot **没有** projections 字段，读不了 `permissions` 投影，只能轮询。

### 9. 标准安装 = dsh bundle（package.json 声明 + 包内 cordis.patch.yml）

本插件是**标准 DSH bundle**：`package.json` 的 `dsh.bundle.patch` 指向包内 `cordis.patch.yml`，用官方 `dsh plugin` 命令安装：

1. `dsh plugin --profile web add <本地路径或包>`：pnpm 把插件装成 profile 的 npm 依赖（本地路径走 `link:` 软链，改代码即生效），并把包名追加到 profile `package.json` 的 `dsh.profile.bundles`。**`link:` 安装的前提：插件目录里必须已经 `npm install` 出 `node_modules`**——loader 从链接的**真实路径**加载 `index.js`，其裸导入（`@deepseek-ai/cordis`、`@deepseek-ai/dsh-typert-protocol`、`zod`）从插件自己的 `node_modules` 解析；缺了会在启动时 `ERR_MODULE_NOT_FOUND`，**整个 DSH 起不来**（2026-08-27 实踩）。对齐宿主版本避免双副本漂移：`npm install --no-save --registry=https://registry.npmjs.org @deepseek-ai/cordis@<宿主版本> @deepseek-ai/dsh-typert-protocol@<宿主版本> zod@^4.4.3`（宿主版本从桌面安装目录的 `.pnpm` 仓查）。
2. 启动时 DSH 应用包内 `cordis.patch.yml`，做两件事：**`- insert:`** 新增插件挂载行（**不要**对不存在的 id 用普通 `- id:`，会报 "entry not found"）；**`- id: permission`** 覆盖预设表行（该 id 已存在，覆盖合法）：

```yaml
# cordis.patch.yml（随包分发，节选——以包内实际文件为准）
- insert:
  - id: agent-approval
    name: '@duke-dsh-plugins/dsh-agent-approval'

- id: permission
  name: '@deepseek-ai/dsh-permission-presets'
  config:
    presets:
      read-only: { sandbox: read-only, approval: ask }
      workspace-write: { sandbox: workspace-write, approval: ask }
      agent-approval:
        sandbox: workspace-write
        approval: ask
        name: 自动审批
        description: workspace-write base; every sandbox escalation is judged automatically, risky ones are rejected.
      agent-review:
        sandbox: danger-full-access
        approval: ask
        name: 自动审查
        description: Full access base; every tool call is reviewed by the Jev judge before execution, risky calls are rejected with no human fallback.
      danger-full-access: { sandbox: danger-full-access, approval: never }
```

3. **不要**再在 profile 的 `cordis.patch.yml` 里手工插这些行，否则同一 id 重复挂载、permission 表重复覆盖。
4. 重启 DSH。**必须重启**，Host 加载、typert 注册、client bundle 注入都在启动时发生。
5. 卸载：`dsh plugin --profile web remove dsh-agent-approval`（自动从 bundles 列表移除）。
6. **可选（权限菜单图标）**：菜单图标在官方 bundle 的硬编码映射里，标准安装不会补——本地开发想要图标就 `npm run patch:glyph`（见第 8 节）。

### 10. DSH 0.1.7-rc.1 兼容（v1.7.0）

对照 npm tarball 逐文件 diff（0.1.5-rc.3 → 0.1.7-rc.1）核对过本插件触及的全部宿主 API 面，结论：

- **唯一硬破坏：Typert codec 契约**。0.1.7 的 `dsh-typert-loader` / `dsh-typert-registry`（Host+Client）都把「zod v4 `codec.schema`」换成了「`codec.create()` 工厂」（gateway 运行时 `codec.create().parse(value)`，`schemas[]` 条目同理）。v1.6.0 及更早在 0.1.7 上注册即被拒：Host 侧 manifest 注册失败、Remote 全挂；Client 侧 `$mount` 抛错、整个 client bundle 的 apply 失败。修法即第 1 节「codec 双格式」。
- **逐项核对过、无需改动的面**：
  - `approval/request` 瀑布、`ApprovalRequestEvent`（agent/toolName/callId/reason/signal）、`ApprovalOutcome` 四值、`approval.setPolicy`/`overrideOf`/`config.policy` 全部原样。
  - `subagents.start("spawn")` 请求形（label/prompt/parent/signal/agentOptions/outputSchema/toolFilter/persona）与 `SubagentRun`（id/result/dispose）原样；`assertObjectJsonSchema` 受限子集未变（`dsh-invariants` 无改动）。
  - `session.snapshotEvents()` 在 0.1.7 被标记**弃用**（"现有逻辑可以暂不迁移，但禁止新增生产调用"，`eventAt`/`ownEvents` 同批），仍可用——`_eventsOf` 的双形读取保留。
  - `session.header`/`session.id`/`session.append`、`session/event`/`session/disposed` 事件签名不变；`tool/call`、`user/message` 数据形不变（`source.kind === "user"` 过滤依旧正确——`approval.setPolicy` 的切换通知在 0.1.7 改成 `source.kind: "user-approval"`，恰好被我们的过滤排除）。
  - `permissionPresets` 的 Config 表 schema 未变（`name`/`description` 仍可选），`names` getter / `resolve()` 形状未变；但 0.1.7 新增**保留字 `auto` / `custom`**——预设 key 不可再用这两个（构造期直接 throw），`auto` 是实验性的 per-call review 预设（`registerAuto`），且出厂默认表只剩 workspace-write / danger-full-access。我们的 `cordis.patch.yml` 整表覆盖不受影响，key 避开保留字即可。
  - `commands.register` 新增**可选** `definitionId`（缺省合法）；`systemPrompt.context({name,order,text})` 未变（`context.agent` 来自 dsh-agent 对 AssembleContext 的模块增强，仍在）；`sessionTitle.get(session)`、`agentDefaultModel.currentSelection()`、`sessionPersistence.locate(header)`、`sandboxPolicy.defaultMode`、`llm.listProviders/listModels` 全部原样。
  - `agent/created` 从 `@mode emit` 改为 **`@mode serial`**：监听器按注册顺序被 await，抛错/返回 rejected Promise 会**使创建失败**。我们的监听器同步且全包 try/catch，合规；**以后改这个监听器绝不能抛错或返回 Promise**。`agent/session-start` 事件已删除（本插件未用）。
  - client 槽位：`settings.section`（id/order/label）与 `conversation.view` 契约未变（owner props 多了 `inspectCall`/`openView` 等，多余 prop 无害）；`SessionStandardProps.useSession` 仍在、`SessionSnapshot.sessionId` 叶子保留（0.1.7 另给 `props.sessionId`，可选用）；Remote 返回信封统一为 `RemoteResult`（`{ok,value}|{ok,error}`），被 client `pick()` 的多形解包覆盖。
  - client bundle 注册契约（`__ModuleLoader__.load({id,factory})`、`exports.inject=["slots","remote"]`、id = 包名）未变；`Remote`/`TypertRemoteService`/`markRemoteMethod` 驱动方式未变，`remoteMethods` 描述符形状未变（gateway 0.1.5 与 0.1.7 的消费代码逐行同形）。
- **0.1.7 的 UI 搬迁**（只影响 glyph 修补，见第 8 节）：`/permission` 菜单与 composer 触发按钮从 `dsh-client-ui-conversation`（`PermissionSelect` 已删除）搬到独立包 `dsh-client-ui-permission-presets`，composer 里挂新 slot `conversation.input.permission`；菜单仍是同一 Menu 原语（`button[role=menuitem]` + itemIcon span）。
- **依赖对齐**：0.1.7 宿主的 cordis 是 4.0.4、typert-protocol 是 0.1.7-rc.1。已验证插件 node_modules 里的旧副本（cordis 4.0.1 / typert-protocol 0.1.1-rc.2）在 0.1.7 下照常工作（`Service.init` 等符号是 `Symbol.for` 全局共享；`bindTypertRemote` 的 `ctx.invocation` accessor 是 0.1.7 新增的可选面，旧副本没有也无影响）；如遇漂移按第 9 节对齐即可。
- **DSH 版本声明走 peerDependencies，不走 dsh.plugin.json**：宿主版本声明的官方槽位是 `package.json#peerDependencies` 里名为 `@deepseek-ai/dsh` / `@deepseek-ai/dsh-*` 的条目——0.1.7+ 的 app-boot 启动预检（`plugin-compatibility.js` 的 `evaluatePluginCompatibility`；**0.1.5 及更早没有这段，范围只在 0.1.7+ 运行时被评估**）对每个这样的 peer 跑 `semver.satisfies(runtime, range, { includePrerelease: true })`，不匹配就告警并可用 `dsh plugin allow-version` 做精确版本豁免（`peerDependenciesMeta.optional` **不免检**）。本插件声明 `"@deepseek-ai/dsh": "^0.1.5-rc.3 || ^0.2.0-rc.1"`（v1.8.1 起；实测支持线 0.1.5-rc.3 ~ 0.2.0-rc.1）与 `"@deepseek-ai/dsh-typert-protocol": "^0.1.0-rc.7 || ^0.1.7-rc.1 || ^0.2.0-rc.1"`——**第二个 peer 同样会被预检**（过滤器命中 `@deepseek-ai/dsh-` 前缀），只放宽 `@deepseek-ai/dsh` 一条仍会被整行拒绝，详见第 10a 节。并配 `peerDependenciesMeta.@deepseek-ai/dsh.optional = true`——**optional 是给安装器看的**（免得 npm/pnpm 把整套 `@deepseek-ai/dsh` CLI 运行时当缺失 peer 自动装进来），**预检照读不误**。**dsh-market（dshmarket.com）从 npm manifest 读三种宿主声明并合取判定**（`discovery-compatibility.ts` #577：顶层 `engines.dsh`、`dsh.engines.dsh`、以及 `@deepseek-ai/dsh*` peers；判定同样 `includePrerelease`），所以本插件另在 `package.json#dsh.engines.dsh` 写了同一范围 `^0.1.5-rc.3 || ^0.2.0-rc.1`——引擎形状给市场徽标/`compatibleWithHost` 过滤用，peer 形状给 0.1.7 启动闸门用，**两处范围必须同步改**（市场侧装机预检对 optional peer 不报风险，但 discovery 不读 optional 标记，peer 声明照样计入）。市场对 0.2+ 宿主的展示与闸门可能短暂不一致（peer 的隐式上限在市场侧被软化为警告），以启动闸门为准。注意 `dsh.plugin.json`（社区 plugin-registry 渠道的清单，`dsh registry install` 用）的 `engines.dsh` **不是 DSH 契约**——没有任何 DSH 版本读它；本插件走 npm + `dsh plugin add` 官方渠道，不需要该文件。版本声明要发新 npm 版本（v1.7.1+）后市场才读得到；市场页 README/版本是每日 CI 的快照，会滞后。
- **验证工具**：`scripts/check-typert-manifest.mjs`（已挂进 `npm run check`）——镜像两代 loader/registry 的 codec 校验器跑 manifest、从真实 client.js 提取 CLIENT_REMOTE 做 id/参数/typeSymbol 对齐检查；设 `DSH_TYPERT_REGISTRY`（可加 `DSH_TYPERT_REGISTRY_2`）指向真实安装的 `@deepseek-ai/dsh-typert-registry/lib/index.js` 时，还会用**真注册表**跑一遍注册。本次修复已用 0.1.5-rc.3 与 0.1.7-rc.1 两代真注册表验证通过（Host manifest + Client descriptors 双双接受）；v1.8.1 又用 **0.2.0-rc.1 真注册表**复验通过。

### 10a. DSH 0.2.0-rc.x 兼容（v1.8.1）

**触发事故的症状**：宿主升到 0.2.0-rc.1 后插件**静默消失**——没有任何加载报错，因为 app-boot 的启动预检在 import 之前就把挂载行 `disabled = true` 了，只往 stderr 打一行 `dsh: disabling profile plugin row "agent-approval": ...`。用户看到的就是"加载不上、被屏蔽"。**诊断不用猜**：`dsh --profile <p> --dump-config` 会打印合成后的树 + stderr 的 `dsh: skipping profile bundle ...`，**本包出现在那份名单里即被拒**；也可以直接 import app-boot 的 `evaluatePluginCompatibility(manifest, exemptions)` 跑真函数（返回 `undefined` = 通过）。
- **判据细节**（`dsh-app-boot/lib/index.js`）：`evaluatePluginCompatibility` 遍历 `peerDependencies`，凡名字是 `@deepseek-ai/dsh` **或以 `@deepseek-ai/dsh-` 开头**都跑 `semver.satisfies(runtime, range, {includePrerelease:true})`；不满足 → `prepareProfileEntries` → `preflight` → `deny()` 设 `row.disabled = true`。**纯 manifest 预检，插件代码一行都没被 import**。profile 无 `compatibility.json` 时 `exempted` 恒 false（豁免只能来自 `dsh plugin allow-version` 的精确版本记录）。
- **两个 peer 都要放宽**：`@deepseek-ai/dsh` 与 `@deepseek-ai/dsh-typert-protocol`（前缀命中，一样被检）。`peerDependenciesMeta.optional` **不免检**——过滤只看名字。
- **同批被拒的还有一串**：0.2.0-rc.1 上 dsh-free-search / dsh-better-sidebar / dsh-pet / dsh-archive-manager / dsh-git-manager / dsh-deveco / dsh-token-stats / dsh-memory-manager / dsh-model-prompt-injector 全是同样的老 peer 范围被跳过。**本插件目前是唯一放行的 Duke 插件**。
- **逐面复核结论（全部未变，无需改代码）**：`approval/request` 瀑布与 `ApprovalOutcome = 'allowed-once'|'rejected'|'cancelled'|'unavailable'`、`approval.setPolicy(agent, policy)`；`subagents.start(name, request)` 的 `agentOptions/outputSchema/toolFilter/persona` + `SubagentRun.dispose`；`llm.stream()` 的 `block-start/text-delta/reasoning-delta/tool-call-delta/block-end/usage/finish` 与 `listProviders/listModels`；`session.snapshotEvents/eventAt/ownEvents/requestHeader`；`tools/pre-execute`；`permissionPresets` 的 `auto`/`custom` 保留字与 `set(session,name)`、`names` getter；`agent/created` 仍 `@mode serial`；`assertObjectJsonSchema`（已挪到 `dsh-tools`，导出口不变）；`agentDefaultModel.currentSelection()`、`sessionTitle.get()`、`sandboxPolicy.defaultMode`。**Typert codec 仍只认 `create()` 工厂**（`dsh-typert-loader/lib/index.js:211`、`dsh-typert-registry/lib/index.js:565`）→ 第 1 节的"双格式"在 0.2.0 依然必需且正确，0.2.0 真注册表已复验通过。
- **唯一破坏性变更：`sessionPersistence.locate(header)` 被删**。0.2.0 的 `SessionPersistence` 抽象类只剩 `create/open/flush/stat/list`，路径解析下放到 JSONL 后端的 **`await resolveCurrentLog(id, signal?)` → `string | undefined`**（"只有历史代"时 undefined）。`_recordsFileOf` 已改成两代都试（先 `locate` 后 `resolveCurrentLog`）；不改的话审计会静默落到 `<DSH_HOME>/agent-approval/records/`，丢掉"删会话即删审计"的语义。
- **link 安装要跟宿主对齐依赖**：`npm install --no-save @deepseek-ai/cordis@4.0.4 @deepseek-ai/dsh-typert-protocol@0.2.0-rc.1 zod@^4.4.3`（0.2.0-rc.1 宿主版本），否则插件自带的旧副本漂移。
- **未覆盖**：本节只做了"宿主加载 + Typert 注册 + 组合不被拒"层面的验证。真实提权裁决路径（`_judge` → LLM 直连/子代理 → 审计落盘）与审查路径（`_onPreExecute` → Jev）要按下面第 13 条在真实会话里点一次才算验证完。

### 11. v1.8.0：LLM 直连裁决（默认）+ 自动审查模式（agent-review）

**显示名改名（用户拍板）**：用户可见文案「Agent 审批」→「**自动审批**」、「Agent 审查」→「**自动审查**」。代码标识一律不动：包名、`exports`、`/agent-approval`/`/agent-review` 命令、preset key `agent-approval`/`agent-review`、wire 描述符 id。**约定：设置页 label（`SETTINGS_LABEL`）与权限预设 `name` 必须保持同名**——`registerSettingsNavIcon`/`registerPermissionGlyphIcon`/`registerReviewMenuItem` 全是按显示文本匹配的 MutationObserver，改名时 `client.js` 的 `SETTINGS_LABEL`/`REVIEW_LABEL` 与 `cordis.patch.yml` 的 `name:` 必须同步，否则图标/gate 静默失配（历史上靠两 label 碰巧同名才工作）。

**改名后菜单仍是旧名 + 图标消失？查 profile 残留覆盖（2026-09-26 实踩）**：patch 应用顺序是 **bundle patch → `~/.dsh/profiles/web/cordis.patch.yml` → `--patch` overlays**，后者对 `permission` 行是**整行替换**。若 profile patch 里有历史手工粘贴的预设表（AGENTS.md 第 9 节本就警告过"不要手工插行"），它会在本包 bundle patch **之后**覆盖 `name`——宿主持续显示旧名，而 client 图标按新文本匹配不上 → 图标消失。修法：把 profile patch 里的 `permission` 行同步成新表（**注意保留其中的 `defaultPreset` 等用户配置**，不能整块删除——`presets` 整行替换语义下删行会丢表）。诊断口诀：宿主名字没变而 client 新了 = 查 `grep "Agent 审批" ~/.dsh/profiles/web/*.yml`。

#### 11a. LLM 直连裁决（`judgeMode: "llm"`，v1.8.0 起默认）

- **动机**：spawn 子代理有轻微上下文污染（会话列表多一条审批员子会话、请求会话日志写 `subagent/descriptor`）。默认裁决器改为**一次 `ctx.llm.stream()` 直连调用**（`_judgeWithLlmStream`），零子会话（审计 `childSessionId` 恒空）。`judgeMode: "subagent"` 保留旧行为（设置页「裁决方式」下拉，`setJudgeMode` 持久化到 config.json）。
- **输入/输出与 subagent 路径完全同构，仅调用方式不同**：同一 `APPROVER_PERSONA`（→ `system`）+ 同一 `_judgePrompt(...)`（→ user 消息）+ 同一 `VERDICT_SCHEMA` 契约（`_verdictFromJsonText` 做等价校验：三字段、enum、`additionalProperties:false`）。唯一文本差异是**输出指令尾巴参数化**（`OUTPUT_VIA_STRUCTURED_TOOL`/`PROMPT_TAIL_STRUCTURED` 对 spawn；`OUTPUT_VIA_JSON`/`PROMPT_TAIL_JSON` 对 stream）——persona 与 judgePrompt 其余部分逐字共享，**改审批口径两路自动同步**。
- **流聚合**（`_readLlmVerdict`，自建零依赖）：dsh-llm `StreamChunk` 协议（`block-start`/`text-delta`/`reasoning-delta`/`tool-call-delta`/`block-end`/`usage`/`finish`）。`block-end` 是权威组装块、**替换**已累计的同 index 增量（防双计）；要求「零或多个 reasoning 块 + 恰一个 text 块 + terminal finish `reason.kind === "stop"`」；`aborted` finish 抛 AbortError（映射 `cancelled`），其他一切异常形态 → `unavailable`（fail-closed）。text 剥 code fence / 提取 `{...}` 再解析。
- **路由**：复用 `_judgeRoute()`；解析到 `inherit(requester)` 时用 `session.requestHeader().config` 的会话自身路由（官方 auto-review 同源读法）；仍无 → `unavailable`。**`llm` 服务缺席不写兜底**（用户裁定：它缺席连主 agent 都跑不起来）——直接 fail-closed 记录。审计 model 列 `llm(<provider>/<model>)`。
- Jev 的响应解析全部集中在 **`_jevParse`**（malformed / low-confidence / verdict 三态）——v1.10.0 起它**只服务自动审查**（`_reviewWithJev`），提权路径已不碰 Jev；**改 Jev 校验逻辑只改这一处**。

#### 11b. 自动审查模式（`agent-review` 预设，逐调用审查，实验）

- **形态**（对齐官方 `@deepseek-ai/dsh-experimental-auto-review` 的 `auto` 预设，但裁决器为 Jev 且 **deny 不转人工**）：`tools/pre-execute` 瀑布 prepend（`_onPreExecute`）+ `danger-full-access` 基线 + `ask` 档位。**监听器收到 native + 每个 PTC inner 调用**（`exec.parent`）的全部派发，**但只 claim 下列范围内的工具**（见下条"审查范围"）；外层 `run_code` transport 照旧排除。key `agent-review` 避开保留字 `auto`/`custom`。
- **审查范围（2026-10-01 用户裁定，务必别改回"审一切"）**：`_onPreExecute` 仍然收到每个调用的派发（native + 每个 PTC 内层调用），但**只 claim `reviewScopeCovers()` 判定在范围内的工具**，其余原样 `next()`——**不花 Jev 往返、不写审计行**。范围 = `REVIEW_SCOPE_TOOLS`（`bash`/`pwsh`/`write`/`edit`/`str_replace_editor`）+ `REVIEW_SCOPE_PREFIXES`（`mcp__`，**两个下划线**，即 dsh-mcp-client `publicToolName` 产出的 `mcp__<server>__<tool>`）。只读与无副作用工具（`read`/`read_image`/`glob`/`grep`/`web_*`/`todo_write`/`present`/`ask_user_question`/各 `*_list`/inspect 类）全部不审。**注意 `bash` 与 `pwsh` 各有两个包注册同名工具**（普通版 + persistent 版），`str_replace_editor` 是独立编辑工具——三个都容易在白名单里漏掉。外层 `run_code` 传输照旧不审，其内层调用按各自名字独立判定。
  - **这不是安全决策，是成本决策**：被审集合本身图灵完备（bash/pwsh 能删文件、能 curl、能改配置），任何"没审的工具能做的事"用一条 pwsh 都能做，而 pwsh 在审。所以白名单**不会**打开新的攻击面；收益是省掉绝大多数只读调用上的 Jev 往返与审计噪音。
  - **范围策略三层（2026-10-01 用户裁定，第三方插件工具默认不审、由用户自负）**：① **DSH 核心工具**——上表枚举，全部审；② **MCP 工具**——`mcp__*` 前缀，审（它们同样来自第三方，但那是用户挂载的服务、其全部价值就在于对机器动手，且前缀稳定，属于本策略的**超集**方向，安全侧）；③ **其余一切，包括第三方插件新增的工具**（如 dsh-im 那种文件投递工具）——**不审，风险归用户**。理由：插件随时可增删工具，白名单永远追不上；去追要么变成维护跑步机，要么制造"已覆盖"的错觉。**唯一需要维护的是第 ① 层**——核心工具集稳定可知；将来若有核心工具获得写/执行/外发能力而没列进 `REVIEW_SCOPE_TOOLS`，要补上。
  - **两处文案必须同步**（否则会误导）：client.js 设置页审查卡片、index.js 注入给模型的 `systemPrompt.context` 文本——原文都写"EVERY tool call / 每个工具调用"，已改为说明只有 bash/pwsh/write/edit/str_replace_editor/mcp__* 受审。
- **裁决链**：规则表 → 会话内信任缓存 → Jev（`_reviewWithJev`；`JEV_REVIEW_QUESTIONS` = `JEV_QUESTIONS` 换 decision 措辞、v1.9.0 起两侧 criteria 再补 effectiveCode 指引）。state 比 `_jevStateOf` 多 `toolDescription`/`toolParameters`（官方 reviewer 也拿 schema；`exec.schema` 或 request header tools 查找，best-effort）与 **`effectiveCode`（v1.9.0，见下条）**。
- **有效代码展开（v1.9.0，仅 review 路径，用户拍板范围）**：裁决器此前只看命令行，`node x.js` / `pwsh -File y.ps1` 背后的脚本内容完全不可见——2026-09 的 `~/.dsh` 数据丢失事故（agent 临时脚本删光 DSH 数据目录）正是这个盲区。`_reviewWithJev` 发请求前先跑 `_reviewEffectiveCode`：模块级纯函数 `reviewCodeRefsOf`（有导出，供 smoke）从参数字符串提取解释器脚本引用——解释器头（node/python/bash/pwsh 等白名单）的位置参数与 `-File`、前导调用符（`&`/`.`/`source`/`call`/`sudo`/`exec`）后的脚本、`-Command`/`-e`/`-c` 内嵌代码**剥引号后递归一层**（`pwsh -Command "node x.js"` 能提出 x.js）、`-EncodedCommand`/`-enc` 标记为不可验证；`-m` 是封装模块与 CLI 同等排除；非解释器段只认前导脚本 token、绝不段中扫描（`git diff -- foo.py` 不误收）。文件内容读取的硬边界：resolve 后必须仍在 workspace 内、`realpath` 跟符号链接后**复查**，越界只记 note 永不读内容（state 随 Jev 请求出机，这条边界防止展开变成绕过工作区的内容外送通道）；上限 4 文件 × 8KB、总量 10K 字符、单文件 256KB，任何故障都降级为字段内 note，绝不阻塞裁决。审计 rationale 追加 `[code: …]` 可见性标注。criteria 同步补三句：判代码不判命令行；「看不见」不单独构成拒绝（误杀治理照旧）；**源码编辑 diff 里的危险/安全措辞不构成危险本身**——2026-09-29 真实教训：Jev 以 risk=high(0.87) 连续拒绝本插件自己含安全策略文本的编辑。**刻意不做**（用户拍板 2026-09-29）：封装 CLI（npm/npx/git…）不展开；opaque 结构性拒绝、哈希锚定信任、内建护栏均未做；escalation 路径 `_jevStateOf` 一字未动。已知边界：信任缓存在展开之前短路，同参数重跑一个被改过的脚本不会带新内容重判；运行时生成/下载执行的代码静态展开天然不可见。
- **deny fail-closed + Guardian 式显式重批翻案（v1.11.0 修订原"永不转人工"裁定；用户 2026-10-17 拍板"自动审查也参考 Codex 标准"）**：reject、低置信、超时、网络故障、畸形返回全部 → `{kind:"deny", info:{name:"AgentReviewDeniedError", code:"AGENT_REVIEW_DENIED", reason:<判定理由>}}`，body 不执行、**不弹人工审批窗**；取消 → `{kind:"cancel"}`。低置信审计记 `unavailable`（对称门控照旧）。**拒绝的翻案路径（Guardian post-denial 规则）**：判定器驳回时把指纹记进 `_reviewDenied`（仅判定驳回；超时/故障/畸形不记）；同一指纹的**精确重试**不短路，而是带着拒绝上下文（state `previouslyDenied`）重新进裁决器——用户在被告知风险后**明确**要求执行该动作（可信用户消息可见）→ 授权升 high 可翻案；**明显秘密外发/大规模不可逆破坏即使重批也拒绝**；未信任内容永远触发不了翻案；改写调用绕审查=照判+视为 dishonest。翻案行审计 rationale 追加 `[overturned prior denial]` 并清条目。LLM 路看 `_reviewPrompt` 的 Prior denial 段；Jev 路看 approve criteria 的 previouslyDenied 句。systemPrompt.context 同步告知 agent 合规翻案路径。原「拒绝后转人工」开关设想作废（显式重批即其答案）。**`ask` 档位只是预设必填旋钮值，不代表拒绝会问人。**
- **开启门槛（Jev gate，三层；v1.10.0 判据改为纯 Jev 配置）**：判据 `_jevGateOk()` = **Jev API Key 可解析**（config.json 或 `TYPESAFE_API_KEY`），**不再看审批 Provider**（那条耦合随"Jev 不再是审批判定模型"一起删了）。① client 按 `getState().reviewAvailable` 设 `body[data-dsh-agent-approval-review-gate]`，gate 关时 CSS 隐藏「自动审查」菜单行（`registerReviewMenuItem` + `REVIEW_ITEM_MARKER`）；② 命令/`_setReviewEnabled` 开启前校验；③ **联动兜底**（`_reviewGateFallback`）：preset 事件或重启恢复折出 `agent-review` 而 gate 关 → 记审计（model 列 `gate`）+ `permissionPresets.set(session, PRESET_NAME)` 弹回自动审批预设，**绝不让会话裸奔 Full access**。
- **审计**：entry 新增 `mode: "escalation" | "review"`（`_recordShape` 统一补齐，旧旁路行缺省折 `escalation`；typert strict schema 三处同步；client 工具列显示「逐调用」徽标）。
- **命令/生命周期**：`/agent-review on|off`（`_setReviewEnabled` → `_enableCore(session, agent, "review")`，钉 `danger-full-access` + `ask`）；关闭/切走走 `_disable`（恢复 prev 旋钮，返回文案按 entry.mode 区分）；`agent/created` 折出 `agent-review` 重启恢复（**再过一遍 gate**，key 被删则弹回）；`_enabled` 条目带 `mode`，`_onPreExecute` 只认 `mode === "review"` 的会话，`_onApprovalRequest` 只认 escalation 会话（两模式互不串台）。
- **全局默认开关（v1.8.0 引入，v1.10.1 整条删除，勿再加回来）**：原 `setReviewDefault` Remote 方法 + 设置页「逐调用审查」下拉 + config.json `reviewDefault` + `getState`/`setJevConfig` 的 `reviewDefault` 返回字段，**四处已一并删除**，`_isFreshSession` 也随之成为死代码被删。删除理由（用户裁定）：v1.10.0 起两模式已彻底分开，**"Jev 配好了" 只该意味着自动审查可选**，不该再附带一条"所有新会话默认进 Full access 逐调用审查"的策略——保存一次 Key 就静默把后续每个新会话的沙箱基线抬到 Full access，既冗余又是提权 footgun（而且它正是 2026-10-01 模式串台事故的上游成因，见下条）。`agent/created` 现在只按日志里**实际记录的** preset 恢复模式，无 preset 事件的新会话一律不开任何模式。
- **模式串台事故与 `_switchCore`（v1.10.1 修复，回归由 `scripts/check-mode-switch.mjs` 锁住）**：`session/event` 预设监听器原来用 `_enabled.has(session.id)` 判重（"有没有开任何模式"），而正确的问题是 `entry.mode`（"开的是不是这个模式"）——审查会话里选「自动审批」被直接吞掉，`mode` 永远停在 `"review"`，菜单显示自动审批但 `tools/pre-execute` 继续逐调用拦截。修法：新增 `_switchCore(session, agent, mode)` 做跨模式改写，**逐字保留**首次开启时捕获的 `prevSandbox`/`prevApproval`/`prevPreset`——直接复用 `_enableCore` 会把刚被钉住的 `danger-full-access` 当成"开启前的值"重新捕获，之后 `_disable` 会恢复到 Full access 而非用户原本的档位。**改这两个判重守卫时务必用 `entry.mode` 而非 `.has()`**。同时补上 `_onApprovalRequest` 缺失的 `mode !== "escalation"` 过滤（此前审查会话会被两个裁决器同时拦，"两模式互不串台"只在文档里成立）。`/agent-approval on` 与 `/agent-review on` 现在都能跨模式切换，互为对称、不再回"请去菜单改"的死胡同。
- **设置页布局（v1.10.0 起固定分区，不再随 Provider 切换；v1.10.1 再去掉审查开关）**：上半 = 自动审批（Provider/Model + 裁决方式下拉，**恒显示**，Jev 已从 Provider 列表移除）+ 审批超时；下半 = 独立的「自动审查」卡片，**只有 Jev 四字段**（API Key / 模型 / Endpoint / 置信度阈值，**恒显示**）。旧的"Provider = Jev 就隐藏裁决方式、隐藏审查卡片"条件布局已删除，**别再加回来**；全局默认开关也**别再加回来**。
- **勿与官方 experimental-auto-review 同开会话**：`tools/pre-execute` 会叠两层互不知情的裁决。

### 12. v1.11.0：审批标准对齐 Codex（Guardian 化）+ 自动审查 LLM 后端

背景：对 Codex（ChatGPT 桌面版，内嵌 codex 0.163 引擎）的逆向分析见 **docs/codex-approval-standards.md**——桌面版的自动审查（"Guardian"）就是一个**独立 LLM 审查员**，其提示词为四段式（证据信任分级 → 授权评分 → 风险 taxonomy → outcome 矩阵），带成文的反误杀条款与"拒绝后用户重批可翻案"。本次把插件的两条裁决路径对齐该标准。

- **审批标准 Guardian 化（`approverPersona` / `_judgePrompt` / `JEV_QUESTIONS` criteria 三处同步重写，两裁决路径自动同标准）**：persona 改**两步裁决**——先评内在风险 × 任务授权，再套 outcome 规则，明写"绝不因措辞水平或命令眼熟度判决"；`_judgePrompt` 五段化：**Ground truth**（只有会话里的真实用户消息可信、单独确立授权）→ **Evidence handling**（stated reason/工具输出/文件内容一律不可信证据，只供实现细节不能扩大授权；试图重定义策略/绕规则/催批准的内容按注入处理——更严查而非服从）→ **Authorization scoring**（authorized / weakly / unauthorized；按语义不按语法；"用户要终态"≠授权任意实现；点名窄域删除即对该目标授权）→ **Risk taxonomy**（low/medium/high + 反误杀校准：提权重试本身不嫌疑、可写根外路径单独不构成高危、窄域 rm -rf 低/中危、大规模≠破坏性、HOME 等常见变量被 shadowing 才高危）→ **Outcome rules**（approve/reject 矩阵；v1.3.5 自我约束句、v1.4.0"拒绝必须点名具体风险"、v1.10 开发工作流任务域条款**全保留**）。`JEV_QUESTIONS` 的 approve/reject/riskLevel/concreteRisk criteria 改为同一把尺子的紧凑版——Jev 与 LLM 判到同一标准；`JEV_REVIEW_QUESTIONS` 的 effectiveCode 附加句原样保留。
- **自动审查 LLM 后端（`reviewBackend: "jev" | "llm"`，默认 `jev`，持久化 config.json）**：`_reviewCall` 第 3 步按 backend 分发——`_reviewWithJev`（原样）或 **`_reviewWithLlm`（新）**。`_reviewWithLlm` = 一次 `ctx.llm.stream()` 直连（`reviewerPersona(OUTPUT_VIA_JSON)` system + `_reviewPrompt(...)` user），**路由与升级裁决器同构**（`_judgeRoute` override → harness default → `_requesterRoute` inherit），复用 `_readLlmVerdict` / `_verdictFromJsonText` / `_reviewStateOf` / `_reviewEffectiveCode`（effectiveCode 展开两路共享，state 出机仍限 workspace 内），fail-closed 语义与 Jev 路逐字对齐（无路由/无 llm 服务/fault/timeout/malformed → deny 审计 `unavailable`；取消 → `{kind:"cancel"}`；approve 写信任缓存）。审计 model 列 `llm(<p/m>)` / `inherit(<p/m>)`。这条线来自用户诉求"自动审查不支持 LLM 不太方便"——Guardian 即同构官方实现。
- **Gate 判据随 backend 切换**：新 `_reviewGateOk()` = backend `llm` → 恒开（缺路由在逐调用处 fail-closed）；`jev` → 原 `_jevGateOk()`（Key 可解析，方法保留）。三层 gate（client 菜单显隐、`_setReviewEnabled`、`_reviewGateFallback` 弹回）与 `getState().reviewAvailable` / `setJevConfig` 返回全部换用 `_reviewGateOk()`。**已 armed 的审查会话切 backend 不会被弹回**——下一次逐调用裁决即走新 backend，判据不足照旧 deny（不裸奔）。
- **wire 三处同步（v1.11.0）**：新 invocation `setReviewBackend(request {backend}) → {reviewBackend, reviewAvailable}`；`getState` 与 `setJevConfig` 的 value 新增 `reviewBackend` 字段（typert strict schema + 类型声明同步）。client：审查卡片新增「判定后端」下拉（`typeof remote.setReviewBackend === "function"` 守卫，旧 Host 隐藏下拉；`s.reviewBackend` 缺失回落 `"jev"`），LLM 选中时提示 Jev 字段暂不参与判定；页面与卡片文案全面后端中立化。改 wire 照旧跑 `npm run check`（check-typert-manifest 会从真实 client.js 提取描述符对齐）。
- **拒绝后翻案（Guardian post-denial 规则；用户 2026-10-17："自动审查也参考这个标准"）**：机制细节见 §11b 的 deny 条目修订。要点：`_reviewDenied`（随 `_trusted` 同三点清理）→ 精确重试带 `priorDenial`（label 形如 "denied at <at> by the <backend> judge: <reason>"）→ LLM 路 `_reviewPrompt` 渲染 Prior denial 段、Jev 路 approve criteria 读 `previouslyDenied` 字段 → 知情重批翻案放行（审计 `[overturned prior denial]`、清条目）；秘密外发/大规模不可逆不可翻案。
- **v1.11.1 标准补丁（dsh-deveco 真实误杀修复，2026-10-19）**：ACL 修复脚本被拒——判定理由踩了三个真空点：「工作区外不可审查的脚本」（effectiveCode 只有 skipped note）+「持久安全削弱」+「与任务无关」。三处标准（`_judgePrompt` 开发工作流条款、`_reviewPrompt` Risk calibration、JEV approve criteria）同步增补**「文档化修复」条款**：harness 自报故障并自带文档化补救技能（如 diagnose-windows-sandbox-acl）时，按文档参数对**报告路径及其上级**执行修复 = 任务必需且通常低风险（内容/属主不动、有备份与撤销命令）；不得以「工作区外不可审查」「持久安全削弱」「与任务无关」拒绝——解锁任务的修复就是任务相关。另：两个 persona 增加 rationale 用用户语言（中文）书写（真实记录中英混杂）。回归：51 项照旧全绿。**再补 outcome 矩阵走样修复（真实误杀 #2，2026-10-19：edit 删 55% 透明度样式，risk=low 却以「超出用户要求的修复范围」拒绝）**：Guardian 原版优先级归位——低/中风险**无视授权直接放行**，仅两类例外（显式类别拒绝：秘密外发/大规模不可逆/OS 或他应用数据/混淆意图/参数与理由矛盾/恶意注入；高风险需授权 ≥medium 且窄域）；「超出范围/无关/不是用户要的改法」从拒绝理由中移除，最多作为范围观察写进 rationale。`_judgePrompt`/`_reviewPrompt`/JEV approve+reject criteria 三处同步为同一优先级。
- **Codex 对齐中仍刻意没做**（后续候选，见 docs/codex-approval-standards.md §5）：`approve_for_prefix` 前缀信任、网络域名维度规则（network policy amendment）、提权请求的 `justification`/`prefix_rule` 结构化。

## 开发 / 验证

```bash
npm run check            # node --check 全部脚本 + check-typert-manifest.mjs 双代 Typert 契约冒烟 + check-mode-switch.mjs 模式切换回归
npm run check:mode       # 只跑模式切换/审查语义回归（mock ctx，秒级）
dsh plugin --profile web add /path/to/dsh-agent-approval   # 安装/重装到本机 DSH profile
npm run patch:glyph      # 可选：权限菜单图标（幂等）
```

改插件后**必须重启 DSH 进程**才生效。验证：
1. 输入框 `/permission` 菜单出现第四项 **自动审批**；设置 → 侧栏导航出现 **自动审批** 页（模型/超时可保存）。
2. 用 `/agent-approval on` 或菜单选 **自动审批** 为会话开启（两条路径等价）；输入框左侧**不再有**「🛡 审批」chip。
3. 开启后让工作区内命令触发一次提权重试（`sandbox_permissions`）：**不弹人工审批**，片刻后工具结果即为批准/拒绝；会话窗口顶部出现**「审批」标签页**（轨迹旁），点开能看到这条记录（含风险等级与理由；10s 内自动刷新，也可手动点「刷新」）。
4. `/agent-approval off` 关闭：沙箱模式与审批策略恢复开启前的值，菜单同步切回对应预设；再次提权回到人工弹窗（ask）或原策略行为。
5. 菜单切到 danger-full-access：模式自动关闭（`permission/preset` 事件联动，立即生效）；菜单切回 自动审批：模式自动开启，无需手动执行命令。
6. 把审批超时调成 30000ms、审批模型指向一个不存在的路由 → 提权应 fail-closed 拒绝并记录 `unavailable`。
7. 设置页加一条 allow 规则（如工具 `pwsh` + match 子串）→ 命中的提权**不再起审批子代理**，审计 model 列显示 `rule`；模型批准的提权在同一会话内以完全相同参数再次发起 → 直接放行，model 列显示 `trust`；「审批」tab 审计行点「加白」→ 规则表新增对应 allow 规则。
8. （v1.10.1，第 4b/11b 节）**设置页「自动审查」卡片**保存一个可用的 Jev API Key：提示条应显示「Jev 配置已保存：自动审查已就绪，可在 /permission 菜单或 /agent-review 逐会话开启」，卡片里**只剩四个字段、没有「逐调用审查」下拉**；**新开一个会话，它应当停在默认预设、不自动进入自动审查**（这是本次删除的核心行为，旧版会直接进 Full access 逐调用审查）；把 Key 清空再保存 → gate 关、`/permission` 菜单里「自动审查」行隐藏；配好 Key（或设 `TYPESAFE_API_KEY`）后**手动**选「自动审查」或 `/agent-review on` → 用**范围内**的工具（如 `edit` 改一个文件、或 `pwsh` 跑一条无害命令）触发一次调用 → 亚秒级裁决、审计 model 列显示实际版本（如 `jev(jev-1.13.0)`）、理由列为概率合成文本；**同一个会话里再调一次 `read`/`glob` → 应当完全不进审查、不产生审计行**（这是范围收窄的核验点，别用只读调用去验审查）；置信度阈值调到 0.99 → 大概率低置信（拒绝该次调用 + 记 `unavailable`）；Endpoint 指向不存在的主机 → 网络错误同样拒绝。**核验「审批不再有 Jev」**：审批 Provider 下拉**没有** TypeSafe Jev 项、「裁决方式」下拉**恒可见**；旧 config.json 带 `model.provider: typesafe` 的机器重启后 `getState().model.provider` 应为 `""`（已迁移）。
9. （DSH 0.1.7-rc.1 宿主，见第 10 节）重启后 `/permission` 菜单与设置页正常打开即证明 codec 双格式注册成功（旧版 ≤1.6.0 在 0.1.7 上这两处直接死）；权限菜单行的盾牌图标若缺失只影响观感（glyph-set 守卫跨代 CSS 类名），功能不受影响。
10. （v1.8.0 功能 A，见第 11a 节）**默认即 LLM 直连**：开启自动审批后触发一次提权 → 亚秒级裁决、审计 model 列 `llm(<provider>/<model>)`、`childSessionId` 空，且**会话列表不出现审批员子会话**（零上下文污染核验）；「裁决方式」切「隔离子代理」→ 恢复旧行为（子会话出现、childSessionId 有值）；模型路由指向不存在的模型 → `unavailable`；超时调 30s + 大上下文 → `unavailable`；规则/信任短路照常（不发 LLM 请求）。
11. （v1.8.0 功能 B，见第 11b 节）设置页启用 Jev 后，`/permission` 菜单出现 **自动审查**；未配 Jev 时该菜单行不可见、`/agent-review on` 报错；选中后用**范围内**的工具（`edit` / `pwsh` / `bash` / `write` / `str_replace_editor` / `mcp__*`）触发一次调用 → 不打断、执行前经 Jev 一次（「审批」tab 出现 mode=逐调用 记录）；**只读工具（`read`/`glob`/…）在审查会话里照常直接跑、不产生记录**；高危调用（如删工作区外文件）→ **直接拒绝、body 不执行**（工具结果带 `AGENT_REVIEW_DENIED` detail），**不弹人工**；低置信/超时/路由故障 → 同样直接拒绝并记 `unavailable`；同参数再调 → trust 短路；关掉 Jev 配置后重启 → 会话回退 自动审批 预设（不裸奔 Full access）；切回 workspace-write 预设 → 旋钮恢复、不再逐调用审查。
12. （v1.8.0 改名）`/permission` 菜单显示 **自动审批**（不再是 Agent 审批），输入框权限触发按钮同步显示 **自动审批**，设置页侧栏出现 **自动审批** 页；菜单行盾牌图标与设置页 shield 图标照常显示（文本匹配 observer 已同步，无静默失配）；`/agent-approval on|off` 命令仍可用（命令名不动）。
13. （DSH 0.2.0-rc.x 宿主，见第 10a 节）**装完先跑不带重启的两条**：`dsh --profile <p> --dump-config` 的 stderr 里没有本包（其余被拒插件的 `skipping profile bundle` 仍在是正常的），且 `npm run check` 挂上 `DSH_TYPERT_REGISTRY=<宿主>/node_modules/@deepseek-ai/dsh-typert-registry/lib/index.js` 后报 `real TypertRegistry accepted`。**这两条过了再重启**；重启后设置页出现「自动审批」、`/permission` 菜单有它；触发一次提权 → 不弹人工、审计落盘，且 `<sessionDir>/agent-approval.jsonl` 存在（**不是** `<DSH_HOME>/agent-approval/records/`——落在后者说明 `resolveCurrentLog` 那条路没走通，见第 10a 节）。
14. （v1.10.1 模式串台回归，第 11b 节）**自动审查会话里切「自动审批」必须立刻生效**：开一个自动审查会话（工具逐调用被 Jev 拦），再从 `/permission` 菜单选「自动审批」→ 随后的普通工具调用**不再被逐调用拦截**（不再出现「工具 body 从未执行」），普通调用直接跑；反之在自动审批会话里选「自动审查」也立刻开始拦截。两条命令同样对称：`/agent-review on` → `/agent-approval on` 能切回来。关掉模式后沙箱应恢复到**用户原本的档位**（不是 Full access）。`npm run check` 里的 `scripts/check-mode-switch.mjs` 已把这几条连同"两模式不同时拦截"一起锁住。

## 发布

打 `v1.0.0` 标签推送 GitHub，`.github/workflows/release.yml` 自动 `npm pack` 并发布 GitHub Release（需要 `GH_TOKEN` secret，权限 `contents:write`）。

## 常规注意事项

- **不要直接编辑 `~/.dsh/profiles/web/cordis.yml`**（生成文件，patch 写在 `cordis.patch.yml`）。
- 监听器**绝不能抛异常**：瀑布层的兜底会把异常归一为 `unavailable`，但要自己 catch 并记录，否则审计里看不到原因。
- 声称（claim）的范围是"该会话的**所有** approval 请求"——不止 pwsh/bash 提权，也包括任何 `tools/pre-execute` 产生的人工 ask。这是有意语义（"帮我审批"），提示词写成通用审批口径。
- `approval.setPolicy` 会在模型上下文里注入 "changed by the user" 通知——用户确实主动开了开关，语义可接受；不要绕开它手写 `approval/policy` 事件（会丢失通知）。
- 审批模型未配置时使用 **Harness 默认路由**（`agentDefaultModel.currentSelection()`；该可选服务缺席或解析为空时才退化为继承请求会话路由）；配置后走 `agentOptions` 精确覆盖。**刻意不跟随请求会话的模型**——审批口径必须稳定可预期，不随各会话的模型切换而漂移。
- 审计记录（v1.5.1 起）存在**会话存储目录内的旁路文件** `<sessionDir>/agent-approval.jsonl`（经 `sessionPersistence.locate` / 0.2.0 的 `resolveCurrentLog` 定位，见第 6 节与第 10a 节；v1.4→v1.5 迁移用 `scripts/migrate-records.mjs`，见第 6 节）；插件只持久化**设置**——审批模型、Jev 配置（apiKey/endpoint/model/confidence）与超时都在 `<DSH_HOME>/agent-approval/config.json`（重启恢复，不再回落默认；Key 明文保存，与模型/超时同一信任域）。持久化失败是 best-effort 静默降级，绝不影响审批主流程。DSH 的权威审计仍在会话日志的 `approval/asked` + `approval/decided` 事件对（本插件不破坏该配对，只在瀑布层给结论）。
