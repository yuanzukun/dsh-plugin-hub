# 按需动词输入与返回契约

> 自动生成，勿手改。唯一维护源：[verb-operation-contracts.json](../houdini/verb-operation-contracts.json)。
> 生成：`npm run docs:generate`；漂移检查：`npm run docs:check`。

## 使用方式与维护范围

模型通过 `verb_help("build_module")` 或名称列表取得简明调用资料；使用 `detail="full"` 按需查询完整说明，不把本页全部内容拼入常驻提示。
`signature`、`return_type`、`call_mode` 从真实函数取得；brief 的 `doc` 是简短用途，full 才含完整 `doc`。已维护的动词在 full 中还返回 `operation_contract`，
包含输入和返回字段、可执行 Python 示例、结果读取方式及接口边界。其他动词仍使用运行时签名与说明。

JSON Schema subsets describe serializable arguments and successful verb-ledger result projections. Additional properties remain open unless the actual nested input spec is closed. Runtime signature/doc remains authoritative; these schemas are discovery metadata, not dispatch validation.

All Python examples run inside one Houdini exec/inspect request. Live hou.Node values and Python locals are scoped to that request. Persist explicit path strings in __result__ and use those strings in later requests; ledger {node:path} snapshots are observations, not callable Node objects.

JSON Schema是描述字段结构的格式。这里维护可序列化输入与成功动词回执的结构子集，开放未枚举的返回字段；
它不在执行时验证请求，不增加流程、审批或执行门槛。失败继续使用真实异常、动词回执及恢复事实。
函数签名/默认值不在JSON重复维护；节点参数、菜单与默认值由 `node_info` 或实际节点参数查询取得。

实现：[按需运行时帮助](../houdini/python3.11libs/dsh_execution.py)、[Houdini动词](../houdini/python3.11libs/dsh_hou_helpers.py)。
验证：[模块与帮助边界](../tools/tests/dsh-module-boundaries.test.py)、[生成器](../tools/gen-verb-contract-docs.mjs)。

## 已维护目录

- [verb_help](#verb_help)
- [node_info](#node_info)
- [tab_create](#tab_create)
- [build_module](#build_module)
- [verify_network](#verify_network)
- [set_parms](#set_parms)
- [connect](#connect)
- [network_controls](#network_controls)
- [present_nodes](#present_nodes)
- [focus_node](#focus_node)
- [network_boxes](#network_boxes)
- [cook_node](#cook_node)
- [sop_recipe](#sop_recipe)
- [geo_curve_clearance](#geo_curve_clearance)
- [geo_piece_stats](#geo_piece_stats)
- [create_spare_parms](#create_spare_parms)
- [sop_set_output](#sop_set_output)
- [render_view](#render_view)
- [scene_save](#scene_save)
- [tool_catalog](#tool_catalog)
- [tool_inspect](#tool_inspect)
- [hda_create](#hda_create)
- [hda_fork](#hda_fork)
- [tool_package_action](#tool_package_action)
- [package_catalog](#package_catalog)
- [package_inspect](#package_inspect)
- [tool_package_create](#tool_package_create)
- [viewport_screenshot](#viewport_screenshot)
- [network_notes](#network_notes)
- [cop_layer_stats](#cop_layer_stats)
- [cop_compare_layers](#cop_compare_layers)
- [test_cop_controls](#test_cop_controls)
- [hda_version](#hda_version)
- [hda_switch_version](#hda_switch_version)

## verb_help

Read actual callable signatures and brief purpose; detail='full' adds complete documentation, argument/result schemas and examples.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "name": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "array",
          "items": {
            "type": "string"
          },
          "minItems": 1,
          "maxItems": 16,
          "uniqueItems": true
        }
      ]
    },
    "detail": {
      "type": "string",
      "enum": [
        "brief",
        "full"
      ],
      "default": "brief",
      "description": "Brief returns callable facts and concise purpose. Full adds complete doc and maintained operation_contract; applies to one name or every item in a batch."
    }
  },
  "required": [
    "name"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "anyOf": [
    {
      "type": "object",
      "properties": {
        "name": {
          "type": "string"
        },
        "signature": {
          "anyOf": [
            {
              "type": "string"
            },
            {
              "type": "null"
            }
          ]
        },
        "return_type": {
          "anyOf": [
            {
              "type": "string"
            },
            {
              "type": "null"
            }
          ]
        },
        "call_mode": {
          "type": "string"
        },
        "detail": {
          "type": "string",
          "enum": [
            "brief",
            "full"
          ]
        },
        "doc": {
          "type": "string",
          "description": "Concise purpose in brief mode; complete callable documentation in full mode."
        },
        "full_help": {
          "type": "string",
          "description": "Executable full-help query, supplied in brief mode."
        },
        "operation_contract": {
          "type": "object"
        }
      },
      "required": [
        "name",
        "signature",
        "return_type",
        "call_mode",
        "detail",
        "doc"
      ],
      "additionalProperties": true
    },
    {
      "type": "object",
      "properties": {
        "items": {
          "type": "array",
          "items": {
            "type": "object"
          }
        },
        "count": {
          "type": "integer"
        }
      },
      "required": [
        "items",
        "count"
      ],
      "additionalProperties": true
    }
  ]
}
```

### Inspect a focused group

调用工具：`houdini_inspect`。

```python
__result__ = verb_help(['build_module', 'network_boxes', 'node_info', 'tab_create'])
```

items contains actual signatures, return types, execution modes, concise purposes and executable full_help queries. No full schemas are included by default.

### Read the complete contract for a selected operation

调用工具：`houdini_inspect`。

```python
__result__ = verb_help('build_module', detail='full')
```

doc contains the complete callable documentation; operation_contract, where maintained, supplies input/output schemas and executable examples.

### 接口边界

- List input returns items/count, not a mapping keyed by verb name. Both scalar and list inputs default to brief; use detail='full' when complete documentation or nested input/output shapes are needed.
- call_mode=exec means houdini_exec or houdini_job_submit; query_or_exec is also available through houdini_inspect. Python names, live Node objects and local variables do not persist across separate tool calls.

## node_info

Read static node type and parameter templates in a real creation network without creating a probe.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "parent": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "type_name": {
      "type": "string"
    },
    "parm_filter": {
      "type": "string"
    },
    "limit": {
      "type": "integer"
    }
  },
  "required": [
    "parent",
    "type_name"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "parent": {
      "type": "string"
    },
    "type": {
      "type": "string"
    },
    "requested_type": {
      "type": "string",
      "description": "The caller's requested family or exact type. type is the actual resolved version used by creation."
    },
    "category": {
      "type": "string"
    },
    "parameters": {
      "type": "array",
      "items": {
        "type": "object"
      }
    },
    "parameter_count": {
      "type": "integer"
    },
    "total_parameter_count": {
      "type": "integer"
    },
    "operation_parameters": {
      "type": "array",
      "items": {
        "type": "object"
      }
    },
    "operation_card": {
      "type": "object"
    },
    "truncated": {
      "type": "boolean"
    },
    "filter_mode": {
      "type": "string"
    }
  },
  "required": [
    "parent",
    "requested_type",
    "type",
    "category",
    "parameters",
    "parameter_count",
    "total_parameter_count",
    "truncated"
  ],
  "additionalProperties": true
}
```

### Discover Box SOP after creating its container

调用工具：`houdini_exec`。

```python
geo = tab_create('/obj', 'geo', name='example_geo')
__result__ = node_info(geo, 'box', parm_filter='size')
```

Read parameters (not parms or setting_cards); operation_parameters, when present, remains unfiltered.

### Query an existing SOP network

调用工具：`houdini_inspect`。

```python
__result__ = node_info('/obj/example_geo', 'box', parm_filter='', limit=64)
```

This query requires example_geo to exist; /obj creates OBJ nodes and cannot supply a Box SOP card.

### 接口边界

- parm_filter is a literal substring, not regex, glob or a pipe-separated list. Static defaults and menus do not describe shelf initialization or dynamic menus on a live node.
- Parameter cards preserve their own native conditionals, not evaluated enablement or inherited folder conditions. menu_kind=toggle_strip uses integer bits from menu.set_value (0 clears all); exclusive_strip uses indices. These are storage facts, not permission to enable a mode automatically.
- parent must be an existing creation network. Unknown types report nearby visible registered names/labels in that context; suggestions do not substitute for the requested type.

## tab_create

Create and initialize one node, then optionally wire inputs and set strict parameters.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "parent": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "type_name": {
      "type": "string"
    },
    "name": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    },
    "inputs": {
      "anyOf": [
        {
          "type": "array",
          "items": {
            "anyOf": [
              {
                "type": "string",
                "description": "Existing node path, absolute or relative to the explicit parent; a live hou.Node is also accepted within the same exec."
              },
              {
                "type": "null"
              }
            ]
          }
        },
        {
          "type": "null"
        }
      ]
    },
    "parms": {
      "anyOf": [
        {
          "type": "object",
          "minProperties": 1
        },
        {
          "type": "null"
        }
      ]
    }
  },
  "required": [
    "parent",
    "type_name"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "anyOf": [
    {
      "type": "object",
      "properties": {
        "node": {
          "type": "string"
        }
      },
      "required": [
        "node"
      ],
      "additionalProperties": true
    },
    {
      "type": "null"
    }
  ]
}
```

### Use a live Node immediately and return a reusable path

调用工具：`houdini_exec`。

```python
geo = tab_create('/obj', 'geo', name='example_geo')
box = tab_create(geo, 'box', name='box1')
set_parms(box, {'sizex': 2.0})
__result__ = {'geo_path': geo.path(), 'box_path': box.path()}
```

Python returns a live hou.Node. The verb ledger projects it as {node: path}; __result__ explicitly returns path strings for a later tool call.

### Preserve an empty first input

调用工具：`houdini_exec`。

```python
node = tab_create('/obj/example_geo', 'attribwrangle', name='lookup', inputs=[None, 'box1'])
__result__ = node.path()
```

box1 must already exist inside example_geo. None leaves input 0 empty and wires box1 to input 1.

### 接口边界

- A successful Python return is a Node, not a dict with ok/created. Do not pass the ledger snapshot {node: path} back as a Node; use its path string.
- Input references are resolved relative to parent; cross-network dataflow requires explicit subnet ports or Object Merge. OBJ parenting uses set_object_parent.

## build_module

Build a new editable SOP batch with explicit node specs and a nonempty output.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "parent": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "nodes": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "name": {
            "type": "string"
          },
          "type": {
            "type": "string"
          },
          "parms": {
            "type": "object"
          },
          "inputs": {
            "type": "array",
            "items": {
              "anyOf": [
                {
                  "type": "string"
                },
                {
                  "type": "null"
                }
              ]
            }
          }
        },
        "required": [
          "name",
          "type"
        ],
        "additionalProperties": false
      },
      "minItems": 1
    },
    "output": {
      "type": "string"
    },
    "dry_run": {
      "type": "boolean"
    },
    "interfaces": {
      "anyOf": [
        {
          "type": "array",
          "items": {
            "type": "object"
          }
        },
        {
          "type": "null"
        }
      ]
    },
    "required_outputs": {
      "anyOf": [
        {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        {
          "type": "null"
        }
      ]
    }
  },
  "required": [
    "parent",
    "nodes",
    "output"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "anyOf": [
    {
      "type": "object",
      "properties": {
        "valid": {
          "const": true
        },
        "dry_run": {
          "const": true
        },
        "parent": {
          "type": "string"
        },
        "node_count": {
          "type": "integer"
        },
        "output": {
          "type": "string"
        },
        "scene_writes": {
          "const": 0
        },
        "applied": {
          "const": false
        },
        "interface_status": {
          "type": "string"
        }
      },
      "required": [
        "valid",
        "dry_run",
        "parent",
        "node_count",
        "output",
        "scene_writes",
        "applied"
      ],
      "additionalProperties": true
    },
    {
      "type": "object",
      "properties": {
        "valid": {
          "const": true
        },
        "dry_run": {
          "const": false
        },
        "parent": {
          "type": "string"
        },
        "created": {
          "type": "object",
          "additionalProperties": {
            "type": "string"
          }
        },
        "validation": {
          "type": "object"
        },
        "interface_checks": {
          "type": "object"
        }
      },
      "required": [
        "valid",
        "dry_run",
        "parent",
        "created",
        "validation"
      ],
      "additionalProperties": true
    }
  ]
}
```

### Build and retain the real output path

调用工具：`houdini_exec`。

```python
r = build_module('/obj/example_geo', [
    {'name': 'source', 'type': 'box', 'parms': {'sizex': 2.0}},
    {'name': 'OUT', 'type': 'null', 'inputs': ['source']},
], output='OUT')
__result__ = {'output_path': r['created']['OUT'], 'validation': r['validation']}
```

On applied success read created[name] and validation. There is no top-level ok or output in this applied return.

### Preview without creating nodes

调用工具：`houdini_exec`。

```python
__result__ = build_module('/obj/example_geo', [
    {'name': 'OUT_preview', 'type': 'null', 'inputs': ['box1']},
], output='OUT_preview', dry_run=True)
```

dry_run returns node_count/output/valid and zero writes; it does not return created/validation or prove VEX/cook/geometry.

### 接口边界

- nodes entries accept exactly name/type/parms/inputs; no comment, flags or position field. References may name any declared spec or an existing direct child; declaration order does not control wiring.
- None retains an input slot. output and required_outputs name newly declared nodes. Empty controls/helpers can be created separately with tab_create; dry-run cannot prove the resulting geometry.

## verify_network

Cook a declared SOP scope and report actual output content, errors and warnings.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "parent": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "output": {
      "type": "string",
      "description": "Existing node path, absolute or relative to the explicit parent; a live hou.Node is also accepted within the same exec."
    },
    "nodes": {
      "anyOf": [
        {
          "type": "array",
          "items": {
            "type": "string",
            "description": "Existing node path, absolute or relative to the explicit parent; a live hou.Node is also accepted within the same exec."
          }
        },
        {
          "type": "null"
        }
      ]
    },
    "limit": {
      "type": "integer"
    },
    "require_valid": {
      "type": "boolean"
    },
    "output_index": {
      "anyOf": [
        {
          "type": "integer"
        },
        {
          "type": "null"
        }
      ]
    }
  },
  "required": [
    "parent",
    "output"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "ok": {
      "type": "boolean"
    },
    "output": {
      "type": "string"
    },
    "parent": {
      "type": "string"
    },
    "scope": {
      "type": "string"
    },
    "checked_nodes": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "node_count": {
      "type": "integer"
    },
    "nonempty": {
      "anyOf": [
        {
          "type": "boolean"
        },
        {
          "type": "null"
        }
      ]
    },
    "healthy": {
      "type": "boolean"
    },
    "warning_free": {
      "type": "boolean"
    },
    "error_nodes": {
      "type": "array",
      "items": {
        "type": "object"
      }
    },
    "warning_nodes": {
      "type": "array",
      "items": {
        "type": "object"
      }
    },
    "geometry": {
      "anyOf": [
        {
          "type": "object"
        },
        {
          "type": "null"
        }
      ]
    },
    "semantic_status": {
      "type": "string"
    },
    "failure_reasons": {
      "type": "array",
      "items": {
        "type": "string"
      }
    }
  },
  "required": [
    "ok",
    "output",
    "parent",
    "scope",
    "node_count",
    "nonempty",
    "healthy",
    "warning_free"
  ],
  "additionalProperties": true
}
```

### Verify the explicit output

调用工具：`houdini_exec`。

```python
__result__ = verify_network('/obj/example_geo', output='OUT', nodes=['source', 'OUT'])
```

Read output, checked_nodes, nonempty, error_nodes and warning_nodes. Paths may be parent-relative.

### Read a failed checkpoint diagnostically

调用工具：`houdini_exec`。

```python
__result__ = verify_network('/obj/example_geo', output='OUT', require_valid=False)
```

require_valid=False returns diagnostic facts, including ok=False; it does not turn errors or an empty output into success.

### 接口边界

- output must be explicit; omission never selects displayNode. Default scope is direct children, explicit nodes limits it. Cook/content checks do not prove relationships or visual quality.

## set_parms

Apply a strict parameter batch to one node, preserving actual errors and restoring snapshotted parameter state on failure.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "values": {
      "type": "object",
      "minProperties": 1,
      "description": "Parameter or tuple names to literal values, numeric expressions, explicit expression/language objects, or supported literal string patches. Literal source synchronization accepts {expected_sha256: current raw UTF-8 SHA-256, source: full text}."
    },
    "allow_foreign": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    },
    "strict": {
      "type": "boolean"
    }
  },
  "required": [
    "node",
    "values"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string"
    },
    "ok": {
      "type": "boolean"
    },
    "set": {
      "type": "object"
    },
    "failed": {
      "type": "object"
    },
    "evaluations": {
      "type": "object"
    },
    "effect_status": {
      "type": "string"
    },
    "notes": {
      "type": "object"
    }
  },
  "required": [
    "node",
    "ok",
    "set"
  ],
  "additionalProperties": true
}
```

### Use exact parameter names and explicit expressions

调用工具：`houdini_exec`。

```python
__result__ = set_parms('/obj/example_geo/box1', {
    'sizex': 2.0,
    'sizey': {'expression': 'ch("sizex") * 0.5', 'language': 'hscript'},
})
```

Read set/evaluations. A parameter write does not itself certify downstream geometry; cook or verify that output when needed.

### Synchronize file-maintained source without overwriting a changed scene

调用工具：`houdini_exec`。

```python
current = read_parms('/obj/example/shape', names=['snippet'])[0]
# Preserve this hash while editing the authoritative file; do not refresh it to bypass a conflict.
text = open('/explicit/project/shape.vfl', encoding='utf-8', newline='').read()
__result__ = set_parms('/obj/example/shape', {'snippet': {'expected_sha256': current['source_sha256'], 'source': text}})
```

Read patch.before_sha256/after_sha256 and changed. Verify the affected final output; matching text alone does not prove geometry.

### 接口边界

- Parameter names and menu set_value come from node_info/list_parms/read_parms. Numeric tuple literals use full components; tuple expressions use individual component names.
- Toggle button/icon strips accept an exact integer bitmask: 0 clears all, combine declared set_value bits for multiple choices. A token selects only that entry's bit, not an incremental toggle. Writing a conditional parameter does not automatically enable its controlling mode or prove an output effect.
- strict defaults to True. strict=False allows explicit partial diagnostic success and returns failed; it is not required for ordinary editing. Restoration covers parameter values/expressions/keys, not external callback effects.
- Complete source synchronization uses the same atomic preflight as literal patches. Stale source rejects the entire batch before writing; equal source is a no-op. The source file remains managed by ordinary file tools.

## connect

Connect exact source/output and destination/input ports in the same dataflow network.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "src": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "dst": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "index": {
      "type": [
        "integer",
        "string"
      ]
    },
    "output": {
      "type": [
        "integer",
        "string"
      ]
    },
    "allow_foreign": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    }
  },
  "required": [
    "src",
    "dst"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string"
    },
    "source": {
      "type": "string"
    },
    "input": {
      "type": "integer"
    },
    "source_output": {
      "type": "integer"
    },
    "verified": {
      "type": "boolean"
    },
    "position_adjusted": {
      "type": "boolean"
    },
    "placement_status": {
      "type": "string"
    },
    "inputs_after": {
      "type": "object",
      "properties": {
        "connections": {
          "type": "array",
          "items": {
            "type": "object"
          }
        },
        "count": {
          "type": "integer"
        },
        "truncated": {
          "type": "boolean"
        }
      },
      "required": [
        "connections",
        "count",
        "truncated"
      ],
      "additionalProperties": true
    }
  },
  "required": [
    "node",
    "source",
    "input",
    "source_output",
    "verified",
    "position_adjusted",
    "placement_status"
  ],
  "additionalProperties": true
}
```

### Replace one wire without a separate disconnect

调用工具：`houdini_exec`。

```python
__result__ = connect('/obj/example_geo/source', '/obj/example_geo/OUT', index=0, output=0)
```

node is the destination; input/source_output report the actual ports and inputs_after shows the current wiring.

### 接口边界

- output is keyword-only. Port strings are exact port names, not labels. connect replaces the current occupant; OBJ parenting is a separate set_object_parent operation.

## network_controls

Declare persistent control entry labels on explicit nodes, or list the same declarations for native navigation. Names and parameter counts do not infer control roles.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "parent": {
      "type": "string"
    },
    "controls": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "node": {
            "type": "string"
          },
          "label": {
            "type": "string"
          }
        },
        "required": [
          "node",
          "label"
        ],
        "additionalProperties": false
      }
    },
    "remove": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "allow_foreign": {
      "type": "string"
    }
  },
  "required": [
    "parent"
  ]
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "parent": {
      "type": "string"
    },
    "controls": {
      "type": "array",
      "items": {
        "type": "object"
      }
    }
  }
}
```

### Declare the actual controller

调用工具：`houdini_exec`。

```python
__result__ = network_controls('/obj/example_geo', [{'node': 'CTRL_ENGINEERING', 'label': 'Engineering controls'}])
```

controls contains the current declared paths and labels; this does not verify parameter bindings.

### Read declarations without cooking

调用工具：`houdini_exec`。

```python
__result__ = network_controls('/obj/example_geo')
```

The exec entry's listing branch performs no scene writes or cooking; controls is read from the actual node declarations.

### 接口边界

- Declarations are presentation metadata stored on the actual nodes. Ownership is still checked for every explicit write; a control role does not grant edit permissions.
- Node delivery cards consume these same declarations. No named-path registry or CTRL-name inference is maintained.

## present_nodes

Publish explicit node entry cards from the original execution result. Persistent IDs are stored on actual nodes and saved with the HIP; navigation roles do not verify control bindings or geometry.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "nodes": {
      "type": "array",
      "minItems": 1,
      "maxItems": 16,
      "items": {
        "type": "object",
        "properties": {
          "node": {
            "type": "string"
          },
          "label": {
            "type": "string"
          },
          "role": {
            "type": "string",
            "enum": [
              "control",
              "output",
              "node"
            ]
          },
          "new_identity": {
            "type": "boolean"
          },
          "description": {
            "type": "string",
            "minLength": 1,
            "maxLength": 200,
            "description": "A short, explicit description of what the user can edit or do at this entry. This is not a validation certificate."
          }
        },
        "required": [
          "node"
        ],
        "additionalProperties": false
      }
    },
    "allow_foreign": {
      "type": "string"
    }
  },
  "required": [
    "nodes"
  ]
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "kind": {
      "type": "string",
      "const": "houdini/node-delivery-v1"
    },
    "nodes": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string"
          },
          "path": {
            "type": "string"
          },
          "label": {
            "type": "string"
          },
          "role": {
            "type": "string"
          },
          "type": {
            "type": "string"
          },
          "context": {
            "type": "string",
            "description": "Actual Houdini node category at delivery time."
          },
          "description": {
            "type": "string"
          }
        }
      }
    },
    "scene_writes": {
      "type": "integer"
    },
    "requires_save": {
      "type": "boolean"
    }
  }
}
```

### Deliver saved control and output entries

调用工具：`houdini_exec`。

```python
entries = present_nodes([{'node':'/obj/asset/CTRL','label':'工程控制','role':'control','description':'调整尺寸和重复数量'}, {'node':'/obj/asset/OUT','label':'模型输出','role':'output'}])
scene_save(expected_path='D:/project/asset.hip')
__result__ = entries
```

Successful present_nodes verb receipts supply the node cards even when __result__ is nested or omitted; failed batches publish none. Save after declaration to persist newly assigned entry IDs; files remain delivered through DSH present.

### 接口边界

- Requires a named HIP. Metadata writes use the same ownership boundary as other edits; references never grant geometry mutation permissions.
- Reopening the same HIP and renaming a node preserve the reference. Deletion or duplicate IDs are reported; an old path is never used as a fallback.
- new_identity=True explicitly changes a copied node's ID and invalidates earlier references to that particular ID.

## focus_node

Navigate to a persistent delivered node ID in its expected current HIP through the main-thread queue. No HIP loading/saving or model parameter edits.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "reference": {
      "type": "object",
      "properties": {
        "id": {
          "type": "string",
          "pattern": "^[0-9a-f]{32}$"
        }
      },
      "required": [
        "id"
      ],
      "additionalProperties": false
    },
    "expected_hip": {
      "type": "string"
    }
  },
  "required": [
    "reference",
    "expected_hip"
  ]
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "id": {
      "type": "string"
    },
    "path": {
      "type": "string"
    },
    "network_current": {
      "type": "string"
    },
    "parameter_current": {
      "type": "string"
    },
    "scene_writes": {
      "type": "integer",
      "const": 0
    }
  }
}
```

### Locate an explicitly delivered entry

调用工具：`houdini_inspect`。

```python
__result__ = focus_node({'id':'0123456789abcdef0123456789abcdef'}, expected_hip='D:/project/asset.hip')
```

Use an actual ID from present_nodes. This only changes editor navigation and reveals containing boxes; missing/duplicated IDs or a different HIP are rejected.

### 接口边界

- The Host's node card click re-reads the original execution fact and current task binding. Browser-supplied paths, UUIDs or Bridge URLs are not accepted as target authority.

## network_boxes

Create, update or remove presentation groups without moving or cooking nodes.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "parent": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "groups": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "name": {
            "type": "string"
          },
          "members": {
            "type": "array",
            "items": {
              "type": "string",
              "description": "Existing node path, absolute or relative to the explicit parent; a live hou.Node is also accepted within the same exec."
            }
          },
          "boxes": {
            "type": "array",
            "items": {
              "type": "string"
            }
          },
          "label": {
            "type": "string"
          },
          "role": {
            "type": [
              "string",
              "null"
            ]
          },
          "color": {
            "type": "array",
            "items": {
              "type": "number"
            },
            "minItems": 3,
            "maxItems": 3
          }
        },
        "required": [
          "name"
        ],
        "additionalProperties": false
      }
    },
    "remove": {
      "anyOf": [
        {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        {
          "type": "null"
        }
      ]
    },
    "dry_run": {
      "type": "boolean"
    },
    "expected_plan": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    },
    "allow_foreign": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    }
  },
  "required": [
    "parent",
    "groups"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "ok": {
      "type": "boolean"
    },
    "dry_run": {
      "type": "boolean"
    },
    "applied": {
      "type": "boolean"
    },
    "scene_writes": {
      "type": "integer"
    },
    "phase": {
      "type": "string"
    },
    "parent": {
      "type": "string"
    },
    "plan_sha256": {
      "type": "string"
    },
    "boxes": {
      "type": "array",
      "items": {
        "type": "object"
      }
    },
    "created": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "updated": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "removed": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "unchanged": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "layout_status": {
      "type": "string"
    }
  },
  "required": [
    "ok",
    "dry_run",
    "applied",
    "scene_writes",
    "phase",
    "parent",
    "plan_sha256",
    "boxes",
    "layout_status"
  ],
  "additionalProperties": true
}
```

### Apply a simple group directly

调用工具：`houdini_exec`。

```python
__result__ = network_boxes('/obj/example_geo', [
    {'name': 'shape', 'members': ['source', 'OUT'], 'label': 'Shape'},
])
```

Direct application is supported. Read boxes and created/updated/unchanged; there is no native box_count field.

### Declare a container before its child

调用工具：`houdini_exec`。

```python
__result__ = network_boxes('/obj/example_geo', [
    {'name': 'assembly', 'boxes': ['shape'], 'role': 'component'},
    {'name': 'shape', 'members': ['source', 'OUT'], 'role': 'model'},
], dry_run=True)
```

The preview resolves same-call box names regardless of declaration order; it writes nothing. To pin this preview, pass expected_plan=preview[plan_sha256] on the applying call.

### 接口边界

- members and boxes may coexist. label defaults to name; role is an optional color hint and is not a fixed enum or leaf/component gate. Containment cycles are rejected.
- expected_plan is optional; preview plus hash is useful when a caller chooses to require unchanged presentation state. Grouping reports presentation, not geometry correctness.

## cook_node

Evaluate one node and report cook health without treating warnings or Manual mode as success.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "force": {
      "type": "boolean"
    },
    "timeout_ms": {
      "type": "integer"
    }
  },
  "required": [
    "node"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "path": {
      "type": "string"
    },
    "ok": {
      "type": "boolean"
    },
    "healthy": {
      "type": "boolean"
    },
    "warning_free": {
      "type": "boolean"
    },
    "errors": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "warnings": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "forced": {
      "type": "boolean"
    },
    "status": {
      "type": "string"
    }
  },
  "required": [
    "path",
    "ok",
    "healthy",
    "warning_free",
    "errors",
    "warnings",
    "forced"
  ],
  "additionalProperties": true
}
```

### Read actual cook health

调用工具：`houdini_exec`。

```python
__result__ = cook_node('/obj/example_geo/OUT', force=True)
```

path identifies the node. ok covers errors; healthy also requires no warnings. Manual mode reports not_cooked_manual.

### 接口边界

- timeout_ms is cooperative native interruption, not an immediate kill. A successful cook does not assert nonempty geometry or visual quality.

## sop_recipe

Plan ordinary editable SOP construction; curve_path turns named anchors and symmetric handle offsets into native Add, cubic Bezier Curve and Resample specs.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "kind": {
      "type": "string",
      "enum": [
        "catalog",
        "hinge",
        "slider",
        "guided_slider",
        "surface_attach",
        "gusset",
        "fastener",
        "repeat",
        "curve_path",
        "sweep_tube",
        "profile_shell"
      ]
    },
    "spec": {
      "anyOf": [
        {
          "type": "object"
        },
        {
          "type": "null"
        }
      ],
      "description": "Call sop_recipe(kind) for the exact example. curve_path accepts name/controller/segment_length and 2..32 anchors, each exactly {name, position:[x,y,z], handle:[x,y,z]}. Components accept numbers or {parm:name} referencing the single existing controller. handle is an outgoing control-point displacement, not a unit tangent. Shared symmetric handles give C1 joins before native edits; no geometry binding, automatic routing or obstacle avoidance."
    }
  },
  "required": [
    "kind"
  ],
  "additionalProperties": false
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "nodes": {
      "type": "array",
      "items": {
        "type": "object"
      }
    },
    "output": {
      "type": "string"
    },
    "required_outputs": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "anchors": {
      "type": "array",
      "items": {
        "type": "object"
      },
      "description": "curve_path anchor names mapped to native Add anchor/in/out point numbers."
    },
    "edit_nodes": {
      "type": "object",
      "description": "curve_path source control points, native Curve 2.0 and sampled polyline node names."
    },
    "scope": {
      "type": "string"
    }
  },
  "additionalProperties": true
}
```

### Create an editable smooth path from two anchors

调用工具：`houdini_exec`。

```python
plan=sop_recipe('curve_path', {'name':'lead','segment_length':0.005,'anchors':[{'name':'start','position':[0,0,0],'handle':[0,0.1,0]},{'name':'end','position':[0.3,0,0],'handle':[0,-0.1,0]}]})
__result__=build_module('/obj/example_geo',plan['nodes'],output=plan['output'],required_outputs=plan['required_outputs'])
```

The planning call writes nothing. Build uses native Add control points -> Curve 2.0 Bezier -> Resample. Inspect plan.anchors/edit_nodes for local editing. Path shape, collisions and downstream swept surfaces require separate evidence.

### 接口边界

- curve_path is an open smooth cubic path. Zero handles have no regular tangent; native edits may change continuity. Resample is an approximation to the Bezier, and sampled envelopes do not certify the smooth curve. Other recipes retain their existing exact schemas from sop_recipe(kind).

## geo_curve_clearance

Measure finite polyline segment/radius-envelope gaps, with explicit local self exclusions and bounded complete pair coverage; no final Sweep or obstacle certification.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string"
    },
    "radius": {
      "anyOf": [
        {
          "type": "number",
          "exclusiveMinimum": 0
        },
        {
          "type": "string",
          "minLength": 1
        }
      ],
      "description": "Positive SOP-local constant radius, or exact scalar numeric primitive radius attribute name; one constant radius per curve."
    },
    "group": {
      "anyOf": [
        {
          "type": "string",
          "minLength": 1
        },
        {
          "type": "null"
        }
      ],
      "description": "One exact primitive group; omitted means every primitive. Unselected primitives remain unverified."
    },
    "clearance": {
      "type": "number",
      "minimum": 0,
      "default": 0
    },
    "self_exclusion": {
      "anyOf": [
        {
          "type": "number",
          "minimum": 0
        },
        {
          "type": "null"
        }
      ],
      "description": "Exclude only same-curve point pairs within this arc distance by clipping each segment-pair parameter domain; long adjacent and backtracking segments retain nonlocal regions. None uses pi*(that_curve_radius+clearance/2), a half-circle arc at the effective radius. Explicit zero keeps joint envelopes and can flag their expected local overlap. Exact repeated endpoints identify a geometric loop and its seam neighborhood."
    },
    "max_segments": {
      "type": "integer",
      "minimum": 1,
      "maximum": 8192,
      "default": 2048
    },
    "max_pairs": {
      "type": "integer",
      "minimum": 1,
      "maximum": 2000000,
      "default": 500000,
      "description": "Candidate pairs before local exclusion; exceeded budget returns unverified with measured_pairs=0."
    },
    "max_results": {
      "type": "integer",
      "minimum": 1,
      "maximum": 64,
      "default": 16
    }
  },
  "required": [
    "node",
    "radius"
  ],
  "additionalProperties": false
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "status": {
      "type": "string",
      "enum": [
        "pass",
        "fail",
        "unverified"
      ]
    },
    "ok": {
      "type": "boolean"
    },
    "reason": {
      "type": "string"
    },
    "coverage": {
      "type": "object"
    },
    "min_envelope_gap": {
      "type": "number"
    },
    "violation_pairs": {
      "type": "integer"
    },
    "worst_pairs": {
      "type": "array",
      "items": {
        "type": "object"
      },
      "description": "Bounded smallest gaps with primitive/segment indices, segment_u, actual closest positions and path_distance on each side; gap=finite-segment distance minus both radii."
    },
    "scope": {
      "type": "string"
    }
  },
  "required": [
    "status",
    "ok",
    "scope"
  ],
  "additionalProperties": true
}
```

### Check the actual sampled centerlines and declared radius

调用工具：`houdini_inspect`。

```python
__result__=geo_curve_clearance('/obj/example_geo/lead_SAMPLED',0.002,clearance=0.0005)
```

Read status, coverage.curves/self_exclusion, measured_pairs and worst_pairs. Pass covers only eligible actual polyline segment envelopes. Smooth Bezier input, closed Polygon faces, unsupported primitives, degeneracy and budgets remain unverified; no silent sampling.

### 接口边界

- Read-only, SOP-local, no scene nodes or viewport changes. No local curvature, connector contact, obstacle, smooth-curve or final swept Polygon mesh certification. Radius is constant per selected curve. Loop endpoints must be exactly equal; near-equal endpoints are not inferred as a seam.

## geo_piece_stats

Observe connected-piece geometry or bounded Polygon surface integrity without modifying the source network.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "piece_attrib": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    },
    "sample": {
      "type": "integer"
    },
    "inspect": {
      "type": "boolean"
    },
    "group": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    },
    "basis": {
      "anyOf": [
        {
          "type": "array",
          "items": {
            "type": "array",
            "items": {
              "type": "number"
            },
            "minItems": 3,
            "maxItems": 3
          },
          "minItems": 3,
          "maxItems": 3
        },
        {
          "type": "null"
        }
      ]
    },
    "integrity_only": {
      "type": "boolean"
    }
  },
  "required": [
    "node"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "anyOf": [
    {
      "type": "object",
      "properties": {
        "node": {
          "type": "string"
        },
        "piece_count": {
          "type": "integer"
        },
        "piece_attrib": {
          "type": "string"
        },
        "piece_attrib_class": {
          "type": "string"
        },
        "sampled_pieces": {
          "type": "array",
          "items": {
            "type": "object"
          }
        },
        "degenerate_surface_pieces": {
          "type": "integer"
        }
      },
      "required": [
        "node",
        "piece_count",
        "sampled_pieces"
      ],
      "additionalProperties": true
    },
    {
      "type": "object",
      "properties": {
        "node": {
          "type": "string"
        },
        "frame": {
          "type": "number"
        },
        "status": {
          "type": "string"
        },
        "scope": {
          "type": "string"
        },
        "semantic_status": {
          "type": "string"
        },
        "risk_status": {
          "type": "string"
        }
      },
      "required": [
        "node",
        "frame",
        "status",
        "semantic_status"
      ],
      "additionalProperties": true
    }
  ]
}
```

### Observe connected pieces

调用工具：`houdini_inspect`。

```python
__result__ = geo_piece_stats('/obj/example_geo/OUT', sample=16)
```

Read piece_count and sampled_pieces. Their extents/area are observations, not proof that parts meet each other.

### Inspect supported Polygon integrity

调用工具：`houdini_inspect`。

```python
__result__ = geo_piece_stats('/obj/example_geo/OUT', inspect=True, integrity_only=True)
```

Read status, supported/unverified scope and risk_status; planar_face_crossings supplies its own coverage/skipped counts. These are not a product-quality pass.

### 接口边界

- group/basis require inspect=True; integrity_only also requires inspect=True. Default piece statistics and Polygon inspection return different shapes; unsupported geometry remains unverified.

## create_spare_parms

Create editable parameter controls on one node by explicit scalar specs, code references, or the parameter UI layout vocabulary.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "code_parm": {
      "type": "string"
    },
    "defaults": {
      "anyOf": [
        {
          "type": "object"
        },
        {
          "type": "null"
        }
      ]
    },
    "spec": {
      "anyOf": [
        {
          "type": "array",
          "items": {
            "type": "object"
          }
        },
        {
          "type": "null"
        }
      ]
    },
    "allow_foreign": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    },
    "update_defaults": {
      "anyOf": [
        {
          "type": "object"
        },
        {
          "type": "null"
        }
      ]
    },
    "layout": {
      "anyOf": [
        {
          "type": "array",
          "items": {
            "type": "object"
          }
        },
        {
          "type": "null"
        }
      ]
    },
    "dry_run": {
      "type": "boolean"
    }
  },
  "required": [
    "node"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string"
    },
    "mode": {
      "type": "string"
    },
    "created": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "leaf_values": {
      "type": "object"
    },
    "code_parm": {
      "type": "string"
    },
    "references": {
      "type": "object",
      "additionalProperties": {
        "type": "string"
      }
    },
    "existing": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "unsupported": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "refreshed_code_parm": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    }
  },
  "required": [
    "node"
  ],
  "additionalProperties": true
}
```

### Add a scalar control explicitly

调用工具：`houdini_exec`。

```python
__result__ = create_spare_parms('/obj/example_geo/CTRL', spec=[
    {'type': 'float', 'name': 'width', 'label': 'Width', 'default': 2.0, 'min': 0.1, 'max': 10.0},
])
```

CTRL must exist. Explicit spec returns node/mode/created/leaf_values; it does not return the scanned-reference shape.

### 接口边界

- Simplified spec supports recursive folders and toggle/int/float/string scalars. Use verb_help('hda_set_interface', detail='full') for the complete layout vocabulary; do not mix layout fields into simplified spec.
- layout is exclusive with spec/defaults/update_defaults; dry_run is available in layout mode. update_defaults changes existing spare defaults and preserves current values/keys.

## sop_set_output

Set the explicit SOP display/render output for the user and optionally publish a native subnet Output port.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "render": {
      "type": "boolean"
    },
    "allow_foreign": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    },
    "output_index": {
      "anyOf": [
        {
          "type": "integer"
        },
        {
          "type": "null"
        }
      ]
    }
  },
  "required": [
    "node"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "context": {
      "const": "sop"
    },
    "node": {
      "type": "string"
    },
    "display": {
      "type": "boolean"
    },
    "render": {
      "type": "boolean"
    },
    "source": {
      "type": "string"
    },
    "public_output": {
      "anyOf": [
        {
          "type": "object"
        },
        {
          "type": "null"
        }
      ]
    }
  },
  "required": [
    "context",
    "node",
    "display",
    "render",
    "source",
    "public_output"
  ],
  "additionalProperties": true
}
```

### Make the chosen SOP visible

调用工具：`houdini_exec`。

```python
__result__ = sop_set_output('/obj/example_geo/OUT')
```

Read node/source/display/render. A named Null alone is not a public subnet port; an explicit output_index requests that publication.

### 接口边界

- This changes the user output flag and is separate from offscreen render_view, which uses an explicit target. It does not verify geometry or infer deliverable quality.

## render_view

Render an explicit SOP through the Houdini GUI preview service and return real image, framing and pixel observations. Managed checks and delivery images accept an omitted picture or safe basename; custom paths require output_policy='explicit'.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string",
      "description": "Existing absolute node path. Within the same exec a live hou.Node is also accepted; JSON node snapshots are not hou.Node objects."
    },
    "direction": {
      "anyOf": [
        {
          "type": "string",
          "enum": [
            "iso",
            "front",
            "side",
            "top"
          ]
        },
        {
          "type": "array",
          "items": {
            "type": "number"
          },
          "minItems": 3,
          "maxItems": 3
        }
      ],
      "description": "World-space target-to-camera direction. Named previews are fixed: iso=[1,0.7,1], front=[0,0.25,1], side=[1,0.25,0], top=[0.001,1,0.001]; front/side include elevation and are not object-relative orthographic axes. Pass a nonzero xyz vector for a specific object axis; orthographic projection alone does not choose that axis."
    },
    "frame": {
      "anyOf": [
        {
          "type": "number"
        },
        {
          "type": "null"
        }
      ]
    },
    "width": {
      "type": "integer"
    },
    "height": {
      "type": "integer"
    },
    "picture": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    },
    "framing": {
      "type": "string",
      "enum": [
        "full",
        "detail"
      ]
    },
    "coverage": {
      "type": "number"
    },
    "framing_frame": {
      "anyOf": [
        {
          "type": "number"
        },
        {
          "type": "null"
        }
      ]
    },
    "output_policy": {
      "type": "string",
      "enum": [
        "managed",
        "delivery",
        "explicit"
      ],
      "description": "managed: temporary visual checks under $HIP/dsh-artifacts/checks/previews/<HIPNAME>/<run-id>. delivery: requested final image under $HIP/dsh-artifacts/renders/<HIPNAME>, safe basename only, unique filename returned. explicit: caller supplied destination."
    },
    "focus_group": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    },
    "isolate": {
      "type": "boolean"
    },
    "projection": {
      "type": "string",
      "enum": [
        "perspective",
        "orthographic"
      ]
    },
    "framing_bounds": {
      "anyOf": [
        {
          "type": "array",
          "items": {
            "type": "array",
            "items": {
              "type": "number"
            },
            "minItems": 3,
            "maxItems": 3
          },
          "minItems": 2,
          "maxItems": 2
        },
        {
          "type": "null"
        }
      ]
    },
    "depth_bounds": {
      "anyOf": [
        {
          "type": "array",
          "items": {
            "type": "array",
            "items": {
              "type": "number"
            },
            "minItems": 3,
            "maxItems": 3
          },
          "minItems": 2,
          "maxItems": 2
        },
        {
          "type": "null"
        }
      ]
    }
  },
  "required": [
    "node"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "ok": {
      "type": "boolean"
    },
    "errors": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "output": {
      "type": "string"
    },
    "artifact": {
      "type": "object"
    },
    "framing": {
      "type": "object"
    },
    "check": {
      "anyOf": [
        {
          "type": "object"
        },
        {
          "type": "null"
        }
      ]
    },
    "pixels": {
      "anyOf": [
        {
          "type": "object"
        },
        {
          "type": "null"
        }
      ]
    },
    "stale": {
      "type": "boolean"
    },
    "semantic_status": {
      "type": "string"
    },
    "user_state_restored": {
      "type": "boolean"
    }
  },
  "required": [
    "ok",
    "errors",
    "output",
    "framing",
    "check",
    "pixels",
    "stale"
  ],
  "additionalProperties": true
}
```

### Produce a managed observation image

调用工具：`houdini_exec`。

```python
__result__ = render_view('/obj/example_geo/OUT', direction='iso', width=1280, height=720, picture='shape_iso.png')
```

Read output/artifact and errors, framing, check, stale. The returned image is sent through the Host to the model; the model still needs to inspect it.

### 接口边界

- Requires the GUI preview service; headless renderer checks use render_frame. Managed checks are under $HIP/dsh-artifacts/checks/previews/<HIPNAME>/<run-id>; delivery images are under $HIP/dsh-artifacts/renders/<HIPNAME>. Both return unique actual paths and reject executable filename expressions; explicit destinations require output_policy=explicit.
- A/B observations use the same framing_frame, direction, framing.bounds and framing.depth_bounds. Pixels and file delivery do not certify visual semantics.
- 过程观察、显示故障和A/B诊断保留managed，写入visual_check；明确要给用户保留的成图才选择delivery，进入$HIP/dsh-artifacts/renders/<HIPNAME>，核对artifact.actual_path与精确hip_path后再present。目录不证明已验收或已交付，不自动移动历史图片。

## scene_save

Save the current named HIP and report actual filesystem and dirty-state facts.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "expected_path": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    }
  },
  "required": [],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "path": {
      "type": "string"
    },
    "dirty_before": {
      "type": "boolean"
    },
    "dirty_after": {
      "type": "boolean"
    },
    "dirty_reliable": {
      "type": "boolean"
    },
    "clean_on_disk": {
      "anyOf": [
        {
          "type": "boolean"
        },
        {
          "type": "null"
        }
      ]
    },
    "bytes": {
      "type": "integer"
    },
    "mtime_ns": {
      "type": "string",
      "description": "Exact decimal nanoseconds; text preserves the value through JavaScript JSON consumers."
    }
  },
  "required": [
    "path",
    "dirty_before",
    "dirty_after",
    "dirty_reliable",
    "clean_on_disk",
    "bytes",
    "mtime_ns"
  ],
  "additionalProperties": true
}
```

### Save the current named scene

调用工具：`houdini_exec`。

```python
__result__ = scene_save(expected_path=scene_info()['hip_path'])
```

Read path and bytes; clean_on_disk can be None when GUI dirty state is unavailable. An unnamed scene needs explicit scene_save_as instead.

### 接口边界

- scene_save does not perform Save As, load or clear. expected_path is optional but, when given, must match the actual current HIP. mtime_ns is exact decimal text; do not coerce it to a JavaScript Number.

## tool_catalog

按需查询当前Houdini实际工具注册目录、来源和版本；不执行工具或推断修改授权。

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "query": {
      "type": "string"
    },
    "kind": {
      "enum": [
        "node_type",
        "shelf",
        "panel",
        "viewer_state",
        "radial"
      ]
    },
    "category": {
      "type": "string"
    },
    "origin": {
      "enum": [
        "factory",
        "external",
        "embedded",
        "unknown"
      ]
    },
    "offset": {
      "type": "integer"
    },
    "limit": {
      "type": "integer"
    }
  },
  "required": [],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "additionalProperties": true
}
```

### 最小明确调用

调用工具：`houdini_inspect`。

```python
__result__=tool_catalog(query='scatter', kind='node_type', category='Sop', limit=32)
```

通过__result__读取本次真实结果；失败、部分写入与未验证范围以原始回执为准。

### 接口边界

- 分页查询当前注册事实，不扫磁盘；factory仅代表$HFS资源位置，不认证发行方。
- GUI-only registry缺失明确unavailable；未生效Shelf/Panel定义、独立state源码与编译内部实现不猜测。

## tool_inspect

精确读取当前工具来源、HDA实际/候选定义、界面与有界公开代码；不创建实例。

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "kind": {
      "type": "string"
    },
    "name": {
      "type": "string"
    },
    "category": {
      "type": "string"
    },
    "include_code": {
      "type": "boolean"
    },
    "max_chars": {
      "type": "integer"
    }
  },
  "required": [
    "kind",
    "name"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "additionalProperties": true
}
```

### 最小明确调用

调用工具：`houdini_inspect`。

```python
__result__=tool_inspect('node_type','scatteralign',category='Sop',include_code=False)
```

通过__result__读取本次真实结果；失败、部分写入与未验证范围以原始回执为准。

### 接口边界

- node_type/viewer_state要求准确category；include_code为明确读取公开文本，不执行回调。
- 实际来源不代表库写入权限；Package只报告原生资源根路径关系。

## hda_create

从明确节点创建全新独立HDA类型与库，保留其他工具；不支持整体replace。

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string"
    },
    "name": {
      "type": "string"
    },
    "hda_file": {
      "type": "string"
    },
    "description": {
      "type": "string"
    },
    "min_inputs": {
      "type": "integer"
    },
    "max_inputs": {
      "type": "integer"
    },
    "max_outputs": {
      "type": "integer"
    },
    "replace": {
      "type": "boolean"
    },
    "allow_foreign": {
      "type": "string"
    }
  },
  "required": [
    "node",
    "name"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "additionalProperties": true
}
```

### 最小明确调用

调用工具：`houdini_exec`。

```python
n=tab_create('/obj','subnet',name='my_tool_source')
__result__=hda_create(n,'artist_tools::my_tool::1.0',hda_file='$HIP/otls/my_tool_1_0.hda')
```

通过__result__读取本次真实结果；失败、部分写入与未验证范围以原始回执为准。

### 接口边界

- 已有目标库和类型冲突写前拒绝；replace=True拒绝并提示分叉或原位维护。
- 成功的新库登记当前session定义来源，节点ownership不授予已有共享库权限；spare迁移、新实例和输出另验。

## hda_fork

复制实际HDA定义到全新类型和独立库；不修改或迁移原实例。

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string"
    },
    "name": {
      "type": "string"
    },
    "hda_file": {
      "type": "string"
    },
    "description": {
      "type": "string"
    }
  },
  "required": [
    "node",
    "name",
    "hda_file"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "additionalProperties": true
}
```

### 最小明确调用

调用工具：`houdini_exec`。

```python
__result__=hda_fork('/obj/existing_tool','artist_tools::derived_tool::1.0','$HIP/otls/derived_tool_1_0.hda')
```

通过__result__读取本次真实结果；失败、部分写入与未验证范围以原始回执为准。

### 接口边界

- 源只读，可来自用户明确参考的自定义或官方可编辑HDA；编译内部实现不支持。
- 目标类型及文件必须不存在，返回真实category/type/source_library；后续另建新实例，不自动修改原工具。

## tool_package_action

对明确原生JSON执行当前进程load/activate/deactivate/unload，源配置与资源保持。

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "package_file": {
      "type": "string"
    },
    "action": {
      "enum": [
        "load",
        "activate",
        "deactivate",
        "unload"
      ]
    },
    "dry_run": {
      "type": "boolean"
    },
    "expected_sha256": {
      "type": "string"
    }
  },
  "required": [
    "package_file",
    "action"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "additionalProperties": true
}
```

### 明确原生Package目标

调用工具：`houdini_exec`。

```python
__result__=tool_package_action('C:/Users/artist/Documents/houdini21.0/packages/MyTools.json','load',dry_run=True)
```

通过__result__读取配置、声明路径和本进程原生加载事实；未知条件和未验证范围保持明确。

### 接口边界

- dry_run默认只预览；正式执行明确传False，可核对先读的config_sha256。
- load不隐式reload已加载工具。运行态动作不编辑enable/条件/依赖、不删除JSON或源、不强清Python模块/窗口。
- 停用前核对当前实际资源/HDA实例，加载检查注册名称冲突与声明/实际路径；未知动态路径不冒充安全正确。
- 前置拒绝明确零派发，原生派发失败后保留原错误、回读错误与实际部分状态，不把sceneUndo当完整恢复。

## package_catalog

有界发现原生注册JSON与当前Houdini加载事实，支持任意包名和多个资源位置。

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "directories": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "query": {
      "type": "string"
    },
    "offset": {
      "type": "integer"
    },
    "limit": {
      "type": "integer"
    }
  },
  "required": [],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "additionalProperties": true
}
```

### 明确原生Package目标

调用工具：`houdini_inspect`。

```python
__result__=package_catalog(query='Tools',limit=32)
```

通过__result__读取配置、声明路径和本进程原生加载事实；未知条件和未验证范围保持明确。

### 接口边界

- 只扫默认原生搜索目录/已加载配置父目录及明确追加目录的顶层JSON；不递归全盘源码。
- 磁盘已配置、声明条件和实际运行态分别报告；动态package_path、跨包变量或条件不自行执行猜算。
- 发现不授予修改权限。用户已选目标直接核对，缺开发归属才询问已有包扩展或新包及两个位置。

## package_inspect

精确读取普通原生Package配置、hash、多路径、加载关系及浅资源/显式文件事实。

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "package_file": {
      "type": "string"
    },
    "files": {
      "type": "array",
      "items": {
        "type": "string"
      }
    }
  },
  "required": [
    "package_file"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "additionalProperties": true
}
```

### 明确原生Package目标

调用工具：`houdini_inspect`。

```python
__result__=package_inspect('C:/Users/artist/Documents/houdini21.0/packages/MyTools.json',files=['toolbar/mytools.shelf'])
```

通过__result__读取配置、声明路径和本进程原生加载事实；未知条件和未验证范围保持明确。

### 接口边界

- 兼容env/path/hpath与未知字段结构；敏感值脱敏，不执行模块或未知条件。
- 共享运行态路径关系不是发行方或独占ownership；声明与加载不一致时不能猜测实际源码。
- 扩展已有包若原搜索路径已覆盖新资源，直接在确认源目录维护相关文件，保留原JSON字节。

## tool_package_create

仅创建新原生JSON追加注册明确的唯一源目录，不复制、归档或加载资源。

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "resource_root": {
      "type": "string"
    },
    "package_file": {
      "type": "string"
    },
    "houdini_versions": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "enable": {
      "type": "boolean"
    }
  },
  "required": [
    "resource_root",
    "package_file"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "additionalProperties": true
}
```

### 明确原生Package目标

调用工具：`houdini_exec`。

```python
__result__=tool_package_create('E:/HoudiniTools/MyTools','C:/Users/artist/Documents/houdini21.0/packages/MyTools.json',houdini_versions=['21.0'],enable=True)
```

通过__result__读取配置、声明路径和本进程原生加载事实；未知条件和未验证范围保持明确。

### 接口边界

- 用户先确认资源源码位置与JSON注册位置，已有授权沿用；文件名不限制DSH前缀或版本目录。
- 目标JSON必须不存在；不覆盖旧配置、不改已有资源、不写$HFS。版本表达式只是声明加载条件，不证明兼容。
- 需要多路径或更复杂条件时沿用完整原生JSON与DSH通用write/edit，明确字段与影响，不造额外文件工具。

## viewport_screenshot

Capture the user viewport for diagnosis, or a requested delivery image. This observes the user display state; it does not prove model geometry or semantic quality.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "path": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Omit or pass a safe PNG basename for managed/delivery output; explicit accepts a caller destination. Consume the returned allocated path."
    },
    "frame": {
      "anyOf": [
        {
          "type": "number"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Finite frame to capture; null uses the current frame. The original frame is restored."
    },
    "clean": {
      "type": "boolean",
      "default": true,
      "description": "Temporarily hide supported viewport guides and decorations, then restore them."
    },
    "frame_target": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "const": true
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Optional node path to frame temporarily; true selects the first displayed OBJ child. Null preserves the current framing. Live hou.Node values are also accepted inside one request."
    },
    "textures": {
      "anyOf": [
        {
          "type": "boolean"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Optional temporary texture display override; null preserves the current setting."
    },
    "backface_cull": {
      "type": "boolean",
      "default": false,
      "description": "Temporarily enable backface culling when true; false preserves the current setting."
    },
    "output_policy": {
      "type": "string",
      "enum": [
        "managed",
        "delivery",
        "explicit"
      ],
      "description": "managed defaults to $HIP/dsh-artifacts/checks/previews/<HIPNAME>/<run-id>. delivery allocates under $HIP/dsh-artifacts/renders/<HIPNAME>. Both require a named HIP and an omitted path or safe basename; explicit uses a caller destination."
    }
  }
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "ok": {
      "type": "boolean"
    },
    "path": {
      "type": "string"
    },
    "artifact": {
      "type": "object"
    },
    "fresh": {
      "type": "boolean"
    },
    "user_state_restored": {
      "type": "boolean"
    },
    "semantic_status": {
      "type": "string"
    }
  },
  "required": [
    "ok",
    "path",
    "artifact",
    "fresh",
    "user_state_restored",
    "semantic_status"
  ],
  "additionalProperties": true
}
```

### Capture a requested delivery image

调用工具：`houdini_exec`。

```python
__result__ = viewport_screenshot(path='viewport.png', output_policy='delivery')
```

Read the actual path and artifact before present. fresh and user_state_restored describe capture/recovery; semantic_status remains unverified until the image is actually inspected.

### 接口边界

- Consume the actual returned path/artifact.actual_path for presentation. Allocation never overwrites an existing image. A dispatched capture whose completion is unknown retains its reservation; do not remove it as ordinary temporary debris.

## network_notes

Read or locally maintain named native Sticky Notes. Notes have their own runtime identity/owner; a parent or name does not grant write authority.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "parent": {
      "type": "string"
    },
    "notes": {
      "anyOf": [
        {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "name": {
                "type": "string",
                "description": "Native ASCII item name. Existing node/box/item name collisions are rejected."
              },
              "text": {
                "type": "string",
                "maxLength": 4096
              },
              "position": {
                "type": "array",
                "minItems": 2,
                "maxItems": 2,
                "items": {
                  "type": "number"
                }
              },
              "size": {
                "type": "array",
                "minItems": 2,
                "maxItems": 2,
                "items": {
                  "type": "number"
                }
              },
              "color": {
                "type": "array",
                "minItems": 3,
                "maxItems": 3,
                "items": {
                  "type": "number"
                }
              }
            },
            "required": [
              "name",
              "text"
            ],
            "additionalProperties": false
          }
        },
        {
          "type": "null"
        }
      ]
    },
    "remove": {
      "anyOf": [
        {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        {
          "type": "null"
        }
      ]
    },
    "allow_foreign": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ]
    }
  },
  "required": [
    "parent"
  ],
  "additionalProperties": false
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "ok": {
      "type": "boolean"
    },
    "parent": {
      "type": "string"
    },
    "notes": {
      "type": "array",
      "items": {
        "type": "object"
      }
    },
    "scene_writes": {
      "type": "integer"
    },
    "restored": {
      "type": "boolean"
    },
    "restore_errors": {
      "type": "array"
    }
  },
  "required": [
    "ok",
    "parent",
    "notes",
    "scene_writes"
  ],
  "additionalProperties": true
}
```

### Place concise instructions beside a network

调用工具：`houdini_exec`。

```python
__result__ = network_notes("/obj/example", [{"name":"start_here", "text":"Start from ARRAY. Replace PATH or SOURCE to change the inputs."}])
```

Read actual text, position, size and provenance. Inspect placement when visual clarity matters; notes do not prove functional correctness.

### Read actual existing notes

调用工具：`houdini_exec`。

```python
__result__ = network_notes("/obj/example")
```

Omitted notes/remove performs no presentation writes; actual runtime mode remains exec.

### 接口边界

- Only explicit standalone notes are changed. Notes already in Network Boxes are refused before writing because the current Box recovery scope does not include note members; native Houdini itself supports note membership. Names, labels, colors, and an owned parent never establish note ownership.
- The same ownership preflight also applies when delete_node would destroy a parent containing notes. Runtime identity is removed on successful deletion and only a causally restored note can recover its prior owner.

## cop_layer_stats

Read the explicit native Copernicus ImageLayer in exec; report full-buffer numeric facts and freshness separately from appearance.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string",
      "description": "Exact existing Copernicus node path. Live hou.Node is also accepted inside one request."
    },
    "output": {
      "anyOf": [
        {
          "type": "integer",
          "minimum": 0
        },
        {
          "type": "string",
          "minLength": 1
        }
      ],
      "description": "Actual source output index or exact name from describe(node).ports."
    },
    "max_pixels": {
      "type": "integer",
      "minimum": 1,
      "maximum": 16777216,
      "description": "Full buffer pixel limit; does not cap upstream GPU cook allocation."
    }
  },
  "required": [
    "node"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "ok": {
      "type": "boolean"
    },
    "status": {
      "type": "string",
      "enum": [
        "pass",
        "fail",
        "unverified"
      ]
    },
    "node": {
      "type": "string"
    },
    "output": {
      "type": "integer"
    },
    "output_name": {
      "type": "string"
    },
    "resolution": {
      "type": "array",
      "items": {
        "type": "integer"
      },
      "minItems": 2,
      "maxItems": 2
    },
    "channels": {
      "type": "integer"
    },
    "storage_type": {
      "type": "string"
    },
    "statistics": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "channel": {
            "type": "integer"
          },
          "min": {
            "anyOf": [
              {
                "type": "number"
              },
              {
                "type": "null"
              }
            ]
          },
          "max": {
            "anyOf": [
              {
                "type": "number"
              },
              {
                "type": "null"
              }
            ]
          },
          "mean": {
            "anyOf": [
              {
                "type": "number"
              },
              {
                "type": "null"
              }
            ]
          },
          "nonfinite_count": {
            "type": "integer"
          },
          "mean_abs_gradient_u": {
            "anyOf": [
              {
                "type": "number"
              },
              {
                "type": "null"
              }
            ]
          },
          "mean_abs_gradient_v": {
            "anyOf": [
              {
                "type": "number"
              },
              {
                "type": "null"
              }
            ]
          }
        },
        "required": [],
        "additionalProperties": true
      }
    },
    "sha256": {
      "type": "string"
    },
    "freshness": {
      "type": "string"
    },
    "cache": {
      "type": "object"
    },
    "sampled": {
      "const": false
    },
    "semantic_status": {
      "const": "unverified"
    }
  },
  "required": [
    "ok",
    "status",
    "node",
    "output",
    "resolution",
    "channels",
    "statistics",
    "sha256",
    "freshness",
    "sampled"
  ],
  "additionalProperties": true
}
```

### Inspect a bounded scalar calibration layer

调用工具：`houdini_exec`。

```python
g = tab_create('/obj', 'geo', name='cop_stats_example')
c = tab_create(g, 'copnet', name='images')
a = tab_create(c, 'layer', name='source')
set_parms(a, {'setres': 1, 'resx': 32, 'resy': 16, 'f1': 0.25})
__result__ = cop_layer_stats(a, output=0, max_pixels=512)
```

Expect resolution [32,16], one channel and mean 0.25. Read status and freshness; these values do not certify visual appearance or external-source freshness.

### 接口边界

- Must use houdini_exec: cooking and reading native layers are not inspect-only operations.
- Supports Float16/Float32 and signed Int8/Int16/Int32 buffers with 1..4 channels. Unsupported storage, empty/oversized output and failed cook reject without implicit conversion or sampling.
- A valid all-zero data layer is not an empty image. Use the declared channel/range meaning, not render_check nonblack heuristics.
- Sticky upstream Cache yields unverified freshness. Dynamic/external dependencies and GPU allocations remain outside the bounded native dependency observation.

## cop_compare_layers

Measure aligned native layer AFTER - BEFORE; optionally test a declared increment without resampling or semantic inference.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "before": {
      "type": "string",
      "description": "Exact existing Copernicus node path. Live hou.Node is also accepted inside one request."
    },
    "after": {
      "type": "string",
      "description": "Exact existing Copernicus node path. Live hou.Node is also accepted inside one request."
    },
    "before_output": {
      "anyOf": [
        {
          "type": "integer",
          "minimum": 0
        },
        {
          "type": "string",
          "minLength": 1
        }
      ],
      "description": "Actual source output index or exact name from describe(node).ports."
    },
    "after_output": {
      "anyOf": [
        {
          "type": "integer",
          "minimum": 0
        },
        {
          "type": "string",
          "minLength": 1
        }
      ],
      "description": "Actual source output index or exact name from describe(node).ports."
    },
    "expected_delta": {
      "anyOf": [
        {
          "type": "object",
          "properties": {
            "node": {
              "type": "string",
              "description": "Exact existing Copernicus node path. Live hou.Node is also accepted inside one request."
            },
            "output": {
              "anyOf": [
                {
                  "type": "integer",
                  "minimum": 0
                },
                {
                  "type": "string",
                  "minLength": 1
                }
              ],
              "description": "Actual source output index or exact name from describe(node).ports."
            }
          },
          "required": [
            "node"
          ],
          "additionalProperties": false
        },
        {
          "type": "null"
        }
      ]
    },
    "tolerance": {
      "type": "number",
      "minimum": 0
    },
    "max_pixels": {
      "type": "integer",
      "minimum": 1,
      "maximum": 16777216,
      "description": "Full buffer pixel limit; does not cap upstream GPU cook allocation."
    }
  },
  "required": [
    "before",
    "after"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "before": {
      "type": "object"
    },
    "after": {
      "type": "object"
    },
    "formula": {
      "type": "string"
    },
    "statistics": {
      "type": "array"
    },
    "max_abs_difference": {
      "type": "number"
    },
    "expected_delta": {
      "type": "object"
    },
    "max_abs_error": {
      "type": "number"
    },
    "tolerance": {
      "type": "number"
    },
    "ok": {
      "anyOf": [
        {
          "type": "boolean"
        },
        {
          "type": "null"
        }
      ]
    },
    "status": {
      "type": "string",
      "enum": [
        "pass",
        "fail",
        "unverified"
      ]
    },
    "semantic_status": {
      "const": "unverified"
    }
  },
  "required": [
    "before",
    "after",
    "formula",
    "statistics",
    "max_abs_difference",
    "ok",
    "status",
    "semantic_status"
  ],
  "additionalProperties": true
}
```

### Check a declared additive relation

调用工具：`houdini_exec`。

```python
g = tab_create('/obj', 'geo', name='cop_relation_example')
c = tab_create(g, 'copnet', name='images')
a = tab_create(c, 'layer', name='source')
set_parms(a, {'setres': 1, 'resx': 32, 'resy': 16, 'f1': 0.25})
b = tab_create(c, 'layer', name='after')
d = tab_create(c, 'layer', name='increment')
set_parms(b, {'setres': 1, 'resx': 32, 'resy': 16, 'f1': 0.75})
set_parms(d, {'setres': 1, 'resx': 32, 'resy': 16, 'f1': 0.5})
__result__ = cop_compare_layers(a, b, expected_delta={'node': d}, tolerance=1e-6, max_pixels=512)
```

Here after-before equals increment, so max_abs_error is zero. This calibrates the formula; it does not prove that an arbitrary artistic operation should be additive.

### 接口边界

- Must use exec. Without expected_delta returns measurements with status=unverified and ok=null.
- Channel count, dimensions, data/display windows, pixel scale/aspect, transforms, projection and frame must align. Nonfinite data rejects; no automatic resizing, color conversion or coordinate mapping.
- Sticky Cache cannot certify the relation. The caller names the operands and mathematical role; a successful difference is not a material or visual verdict.

## test_cop_controls

Temporarily perturb declared scalar controls, measure their explicit COP output, then restore channels/frame and compare the full native layer fingerprint.

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "controller": {
      "type": "string",
      "description": "Exact current-session control node path, or explicitly authorized existing target."
    },
    "output": {
      "type": "string",
      "description": "Exact existing Copernicus node path. Live hou.Node is also accepted inside one request."
    },
    "tests": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "minLength": 1
          },
          "values": {
            "type": "object",
            "minProperties": 1,
            "maxProperties": 8,
            "additionalProperties": {
              "type": "number"
            }
          },
          "expectations": {
            "type": "array",
            "items": {
              "type": "object",
              "properties": {
                "metric": {
                  "type": "string",
                  "enum": [
                    "mean",
                    "min",
                    "max",
                    "mean_abs_change",
                    "max_abs_change"
                  ]
                },
                "channel": {
                  "type": "integer",
                  "minimum": 0
                },
                "delta": {
                  "type": "array",
                  "items": {
                    "type": "number"
                  },
                  "minItems": 2,
                  "maxItems": 2,
                  "description": "Finite ordered [min,max]."
                },
                "range": {
                  "type": "array",
                  "items": {
                    "type": "number"
                  },
                  "minItems": 2,
                  "maxItems": 2,
                  "description": "Finite ordered [min,max]."
                }
              },
              "required": [
                "metric",
                "channel",
                "delta"
              ],
              "additionalProperties": false
            },
            "minItems": 1,
            "maxItems": 16
          }
        },
        "required": [
          "id",
          "values",
          "expectations"
        ],
        "additionalProperties": false
      },
      "minItems": 1,
      "maxItems": 16
    },
    "output_port": {
      "anyOf": [
        {
          "type": "integer",
          "minimum": 0
        },
        {
          "type": "string",
          "minLength": 1
        }
      ],
      "description": "Actual source output index or exact name from describe(node).ports."
    },
    "max_pixels": {
      "type": "integer",
      "minimum": 1,
      "maximum": 16777216,
      "description": "Full buffer pixel limit; does not cap upstream GPU cook allocation."
    },
    "allow_foreign": {
      "anyOf": [
        {
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "description": "One-call explicit user authorization for the specified existing controller; never inferred from paths or selection."
    }
  },
  "required": [
    "controller",
    "output",
    "tests"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "properties": {
    "ok": {
      "type": "boolean"
    },
    "status": {
      "type": "string",
      "enum": [
        "pass",
        "fail",
        "unverified"
      ]
    },
    "restored": {
      "type": "boolean"
    },
    "controller": {
      "type": "string"
    },
    "output": {
      "type": "string"
    },
    "parameter_writes": {
      "type": "integer"
    },
    "baseline": {
      "type": "object"
    },
    "results": {
      "type": "array",
      "items": {
        "type": "object"
      }
    },
    "reason": {
      "type": "string"
    },
    "coverage": {
      "type": "object"
    },
    "semantic_status": {
      "const": "unverified"
    }
  },
  "required": [
    "ok",
    "status",
    "restored",
    "controller",
    "output",
    "parameter_writes",
    "results",
    "semantic_status"
  ],
  "additionalProperties": true
}
```

### Test and restore a real scalar response

调用工具：`houdini_exec`。

```python
g = tab_create('/obj', 'geo', name='cop_control_example')
c = tab_create(g, 'copnet', name='images')
a = tab_create(c, 'layer', name='source')
set_parms(a, {'setres': 1, 'resx': 32, 'resy': 16, 'f1': 0.25})
tests = [{'id': 'gain', 'values': {'f1': 0.5}, 'expectations': [{'metric': 'mean', 'channel': 0, 'delta': [0.249, 0.251], 'range': [0, 1]}]}]
__result__ = test_cop_controls(a, a, tests, output_port=0, max_pixels=512)
```

The baseline is 0.25 and the requested value is 0.5. Inspect status, each actual_values/measurement and restored; after the call f1 and the full layer must be back at baseline. A restored failed test remains fail.

### 接口边界

- Must use exec. Each case needs at least one nonzero expected delta. Invariants can be additional expectations; range checks both baseline and perturbed values.
- Only changed scalar numeric components are supported. Menus, buttons, callbacks, multiparms, tuples, sticky Cache, unsupported storage and invalid baseline reject before testing.
- mean_abs_change/max_abs_change use a zero baseline. Their nonzero response proves only the declared pixel change, not the intended region, edge or artistic effect.
- Normal returns include restored=true even when a declared measurement fails. Restoration failure raises CheckpointError with evidence; do not continue editing.
- Restoration covers snapshotted parameters, expressions/keys, frame and full layer fingerprint. External files, arbitrary Python/solver effects and unobserved dynamic dependencies are not transactional.

## hda_version

在来源库内追加原生类型版本，保留原类型和其他定义；不会切换实例。

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string"
    },
    "version": {
      "type": "string"
    },
    "dry_run": {
      "type": "boolean"
    },
    "allow_foreign": {
      "type": "string"
    }
  },
  "required": [
    "node",
    "version"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "additionalProperties": true
}
```

### 原库原生版本维护

调用工具：`houdini_exec`。

```python
__result__=hda_version('/obj/my_tool','1.1',allow_foreign='用户明确要求升级此原工具')
```

回读精确类型、来源库、applied和实际受影响实例；再验证新版公开入口。

### 接口边界

- HDADefinition.version元数据与::version类型版本不同；不以setVersion冒充原生版本并存。
- 已有package资产维护始终沿用实际来源库。独立衍生才用hda_fork；新工具选择工程otls或package资源目录。

## hda_switch_version

将明确实例切换到同家族精确版本，保留公共参数并加载目标内部网络。

### 输入结构

```json
{
  "type": "object",
  "properties": {
    "node": {
      "type": "string"
    },
    "type_name": {
      "type": "string"
    },
    "dry_run": {
      "type": "boolean"
    },
    "allow_foreign": {
      "type": "string"
    }
  },
  "required": [
    "node",
    "type_name"
  ],
  "additionalProperties": true
}
```

### 成功动词回执的返回结构

```json
{
  "type": "object",
  "additionalProperties": true
}
```

### 原库原生版本维护

调用工具：`houdini_exec`。

```python
__result__=hda_switch_version('/obj/my_tool','artist_tools::my_tool::1.1',allow_foreign='用户明确要求切换此实例')
```

回读精确类型、来源库、applied和实际受影响实例；再验证新版公开入口。

### 接口边界

- HDADefinition.version元数据与::version类型版本不同；不以setVersion冒充原生版本并存。
- 已有package资产维护始终沿用实际来源库。独立衍生才用hda_fork；新工具选择工程otls或package资源目录。
