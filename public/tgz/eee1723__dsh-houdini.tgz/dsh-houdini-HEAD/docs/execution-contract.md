# 执行与证据契约

本页维护工具链真实执行条件和返回事实的含义。用户目标、任务策略及领域方法见对应 [skills](../skills/)；公开工具、动词签名和执行版本见[工具设计](tool-design.md)。系统提供准确操作与反馈，模型决定方法及完成质量。

实现入口：[Bridge](../houdini/python3.11libs/dsh_bridge.py)、[执行内核](../houdini/python3.11libs/dsh_execution.py)、[执行结果](../houdini/python3.11libs/dsh_execution_results.py)、[节点归属](../houdini/python3.11libs/dsh_ownership.py)、[动词导出](../houdini/python3.11libs/dsh_hou_helpers.py)。

## DSH 与工具职责

DSH 提供模型、会话、通用 Agent 循环、提示词组合、压缩和原生工具能力。插件只注册一个 Houdini preset，并通过 [DSH 适配](../src/dsh-adapter.ts)和原生 context producer 提供 Houdini 事实。领域计划没有执行准入条件；生产工具没有产品要求账本或作者自报完成登记。

| 工具 | 执行范围 |
|---|---|
| houdini_exec | 在目标 Houdini 主线程执行修改或验证批次 |
| houdini_inspect | 只读 Python 与现场查询；不准备编辑 Undo 和创建登记 |
| houdini_job_submit | 原生DSH jobs准入后提交现场长任务；job_output收集、job_kill请求取消，完成通知送原作者 |
| houdini_request | 查回原 request_ref 的接收/执行回执、原job结果和图片；活动job可恢复本机观察，不重发代码 |
| houdini_resource | 在 Host 读取用户来源或已保留结果的分页正文 |
| houdini_capabilities | 返回当前模型与附件通道的声明能力 |
| houdini_isolated | 新hython中的builder、HIP副本或副本加载后的受管准备操作；不修改live，不自动合并 |
| image_models / image_generate | Host读取配置或请求图片API；managed目的地经Bridge只读观察所选HIP，explicit不查询Houdini；不修改场景、不提供几何验证 |

[工具运行层](../src/tool-runtime.ts)负责身份、执行端路由和图像附件；[资源读取](../src/tool-query.ts)只消费历史材料。结果正文或来源不成为新的现场观察、授权或任务指令。DSH 已有的文件、终端、网络与会话工具按其原生职责使用。

## 主线程、执行端与归属

所有 HOM 调用经 Bridge 主线程队列串行执行。HTTP 线程只接收、排队和等候回包；泵不可用时拒绝，不退回网络线程执行。GUI 线程不得进行阻塞 socket、进程枚举或 netstat 探测。

执行端、会话和调用分别具有不同身份：executor ID 确定目标进程，owner_session 确定当前作者，owner_call 定位单次调用。身份来自 Host 与执行端登记，模型不自行填写。Bridge 在场景执行前核对目标与执行合同；错目标或版本不一致返回明确错误，不自动重启 live。

首次现场操作前，用户的目标选择通过DSH原生事件持久化；历史记录和新的默认目标各自保留。明确选择可以更换已有操作的对话目标，但不能转移节点归属或改变旧请求/job的查回目标。选择本身不load/clear、不迁目录、不授予作者预留。

只读查询核对选定executor/runtime/scene epoch，不领取writer、不要求保存点恢复；修改才核对单作者与节点权限。票据准备和主线程入场均核对现场代际，同路径重载、同进程打开另一HIP及选择后迟到的请求均不能落到新现场。

普通用户消息不强制恢复原工程。原session的节点归属恢复只消费可信保存点和加载基线；材料不足不能禁止连接和只读，明确新目标也不能被旧工程自动定位覆盖。需要重新加载或丢弃未保存内容时必须有明确用户动作，Raw Gate的load/clear边界保持。恢复、连接和节点授权不互相代替。
请求票携带主线程发布的场景代际，在真正入场时再核对；同一进程Open/New后的旧排队请求也不得进入另一工程。

节点 ownership 来自 runtime 创建的 identity 和会话归属；路径、父网络、节点名称及可复制 userdata 都不授权。foreign 节点可以读和作为输入。单次写入仅在用户明确指定目标时使用非空 allow_foreign，不能形成长期所有权。持久 render 服务永不豁免；删除容器前检查其后代权限。HDA库权限与实例分开；整体销毁旧实例的replace拒绝，分叉只产生独立新类型和库。

节点登记、当前作者、嵌套创建记录和原生身份接续只由ownership模块写入。领域模块通过作用域、不可变快照及恢复接口调用，不读取或回写其私有注册表。只有外层Undo边界采集一次存活identity及当时路径；局部创建清理不重复遍历现场。组件导入记录的恢复由component模块执行，图片由media_output的请求作用域收集，异常退出不得污染后续请求。公开动词入口仅导出能力；运行环境修复在无活动请求时按依赖顺序重载实现，再绑定动词与Bridge。

## 查询、修改与 Raw Gate

inspect 使用只读 namespace 与同一 Python 语法分析结果；exec 提供修改能力。动词是主要修改接口，裸 hou 适用于只读查询及尚无对应动词的低层缺口。Raw Gate 默认开启；已覆盖的 create/set/cook/delete 等操作不能用 allow_raw 旁路。直接、导入别名、绑定及literal getattr调用共用词法归属：区分精确内建值、可信标准库API、HOM和未知来源。普通Python调用不因方法名前缀成为HOM修改；未知对象方法保留原保守判断，不新增普通裸helper函数的命名门槛。

标准库API依据解释器的模块spec与来源判断，不执行待分析import；已加载模块的实际HOM重导出仍按原方法检查。遮蔽、重绑定、显式成员覆写及可变namespace外逸会使普通API证明失效，返回值不继承模块身份。此分析不递归解释任意模块、自定义import hook或回调副作用，不能作为通用Python沙箱。

低层逃生舱只接受单次明确用途；不隐式放开整段已覆盖修改。静态分析服务正常模型调用，不是任意 Python 沙箱。已观察的非终止 VEX 删除循环写前拒绝；其他 VEX 仍由原生编译与计算反馈判断。

每个批次的分类、准入和执行证据共用同一 Python 语法树。动词签名绑定失败返回实际 signature、dispatched=false 和 scene_writes=0；内部 TypeError 保留原始原因。零写入只说明该次未派发调用，不能抵消同批此前修改。

`houdini_exec`和`houdini_job_submit`接受内联`code`或绝对`script`文件；有`script`时，`code`是可选调用尾段。Host通过DSH文件服务读取一次UTF-8字节、固定摘要，并可用`expected_sha256`核对已验证版本；失败不选择写入目标。Bridge不重新读取路径，核对所收源码的摘要和字节数；文件与尾段分别解析，合成同一语法树后检查和执行，不能用尾段补齐损坏文件。原始脚本摘要、路径及实际调用尾段随同一执行回执保存，查回不重读文件或重放代码。

脚本以临时Python模块作用域执行，`__file__`是所读源路径；单独执行时`__name__='__main__'`，有调用尾段时为`__dsh_builder__`。退出后恢复先前模块，不建立常驻builder注册表，不自动修改`sys.path`、清除import缓存或固定未声明依赖。摘要只绑定该文件，不能证明调用参数、外部输入、现场状态或后续改动与独立检查等价。

默认Raw Gate及只读入口在取得已知内置`exec/eval`引用时拒绝，避免经容器、条件表达式或函数返回值隐藏第二段可执行源码，并提示使用完整`code`或`script`入口；普通`compile`仍可用于生成或检查工具源码。此限制维持可见源码的执行边界，不修改Python内建函数、不递归解释import，也不声称任意动态Python或外部副作用已被沙箱保护。团队可默认交付builder和明确输入/入口，真实节点快照仍按需使用，不强制所有编辑先生成文件。

原生 OBJ parent/unparent 使用 set_object_parent，普通 connect/disconnect 表达数据流。set_object_parent 的 reason 是可选自由用途说明；任务可选择 OBJ、KineFX 或其他适用表示，执行层不强制建模方法。

## 事务、错误与长任务

exec 的未处理异常使批次失败并恢复 Houdini 可撤销状态。动词异常被代码捕获后仍记录失败；修改失败且恢复未确认时，同一 exec 后续修改、cook、渲染及保存在派发前停止，只读诊断可以继续。此类修复在新批次提交；零写入或已确认恢复的失败按实际回执处理，避免把半成品误报为成功。

结果投影的 `outcome` 分开报告批次完成/失败、动词异常次数和实际返回的验证状态。捕获只读查询错误后使用合法fallback，可保留批次成功与返回数据，但模型和Trace必须显示子操作失败。已被动词确认恢复、零写入的失败不冒充未恢复修改；既有mutation阻断规则仍按实际恢复事实判断。验证未通过、操作抛异常、传输未知分别表达，不合成为任务是否完成。

读取 transaction 的最终状态：同批后项失败可能撤销前面成功的构建。headless 没有原生 Undo 时，不报告已完成整批回滚；动词内部清理和实际 rollback.applied 分别返回。补充清理只处理本调用准确登记的新 identity，foreign 后代不自动删除。Undo 复活节点后的原生初始化后代只按本批已登记删除身份、原生类型和存活祖先重新对账，不能认领旧作者节点。

文件写入、HDA 库和任意 Python/solver/外部进程副作用不属于场景 Undo 保证。参数与界面动词的内部恢复范围由各自结果说明；已成功的外部文件写入不会因后续批次失败而声称撤销。

长任务仍在同一主线程串行执行，不提供并发 HOM。queued 任务可在代码运行前取消；running 任务的取消依赖原生协作检查点，不能强杀用户进程。jobId 来自实际提交结果，状态/等待/取消只接受所属会话；后台提交成功不等于计算完成。

独立执行复用DSH作业与一次性worker。manifest的`hip/script/files`以明确输入根定位，保持相对结构及本次字节版本；HIP和script可以组合，driver先加载副本并登记新identity，再以同一隔离作者运行准备代码和checks。准备代码仍走相同Raw Gate，不允许自行raw load/clear。安装来自当前明确选择的执行端登记，断连记录仍可提供静态安装事实；可显式指定`houdini_installation`，不从Host HFS/PATH或其他现场降级选择。无登记的固定Bridge配置保留在线安装信息入口。安装选择不授现场权限，也不证明原执行结束。默认run目录取当前DSH工作区的共享角色，不为分配目录查询live或自动搬动用户文件。

worker/report中的执行投影只控制显示大小，不重算状态；大信封单份归档到run的`executions/`，保留路径、摘要及字段pointer。归档或详情读取失败与原执行结果分开，不能以报告体积、stdout或旧progress猜测完成。manifest小文档预算和同源完整结果预算分别应用。运行中的progress会变化，不冒充不可变档案。`released`表示GO已发出；只有自有Job中的实际进程归零才返回`tree_reaped=true`，随后才可清理本次独占临时prefs。工程、固定输入、报告与产物不属于这项清理。

HTTP 请求使用一次性 request_ref。断联、超时或坏回包后先通过 houdini_request 读取原请求状态；缺回执表示未知，不能据此认定零执行。查回 jobId 只证明提交，后续仍读取 job 状态。job入场回执正文过期不代表计算结束；Bridge同时返回实际job是否结束及结果是否仍保留。已结束且结果已清理时，Host保留结果未知事实并清除活动任务提示，不再要求轮询不存在的job或重新提交。运行实例改变或回执过期不自动重复修改。

调用日志完整记录实际动词，不以日志条数拒绝批量操作。大结果在 Host 保留并通过 resource 分页读取；模型正文优先返回显式选择的结果、检查与恢复事实，完整 canonical 仍供 Trace 和历史投影使用。重复帮助、已呈现的动词结果和稳定身份清单可用明确详情指针表示；未知诊断、失败与恢复异常不因体积大而静默丢弃。DSH文件策略只读时不向工程写结果档案；归档失败或不可写时保留完整反馈，显示精简不改变执行事实。

参数目录保留数组/字典结构，不因条目多改成Python repr。每份JSON快照在转换期间使用4 MiB预算及深度上限；循环、超预算或深层内容明确标记省略，不能当作完整数据。作者已选择`__result__`、原始归档成功且`list_parms`确为完整成功目录时，模型正文可用目录数量与详情指针代替重复全表；失败、未知和省略诊断仍显示。对应验证为[参数目录](../tools/tests/dsh-parameter-catalog.test.py)、[投影](../tools/tests/compact-results.test.mjs)及[原生/嵌套DSH消费](../tools/tests/dsh-host-smoke.test.py)。

## 事实、上下文与观察

每次执行返回 runtime_id、sequence、observed_at、frame、HIP 路径和实际影响记录。节点 identity 与运行实例共同解释；同路径重新创建的节点不是原节点。影响观察来自原生输出和最近计算可见依赖，truncated/unavailable/global 直接保留，不推断未列出的依赖不存在。

[execution-history](../src/execution-history.ts)统一关联公开调用、结果与回执；[execution-state](../src/execution-state.ts)的完整观察保留最近失败，动态上下文只携带未决请求、活动 job 及原结果不可取得的恢复事实。已送达的普通同步错误留在原工具结果，后续成功不再触发整份现场快照重发；无关观察的sequence、时间和路径也不改变未决提醒。几何检查和任务质量判断保留在原结果中，Host 不建立第二套完成状态解释器。开发评测中的 [delivery-audit](../tools/delivery-audit.mjs)只读取历史，生产上下文不注入评测完成门。

[scene-context](../src/scene-context.ts)为每条收到的用户消息采集一次轻量元数据，帮助解释“这个节点”“选中对象”“当前场景”等现场指代。切换视角、网络、选择或 frame 不把新现场绑定到旧消息；当前状态需要显式 inspect。选择是指代线索，不是修改授权。

[context](../src/context.ts)通过 DSH 原生 context section 提供现场、待决执行和声明图像能力；通用历史压缩、消息更新和 token 管理由 DSH 完成。没有另一个可写任务账本或自建 surface 压缩器。

图像能力取当前模型 route 与附件服务元数据；houdini_capabilities 可显式查询。它不请求模型、不渲染、不自动换模型。文件传输、GUI 启动、图像显示及模型实际语义识图分别判断；没有成功内容级识图就保持视觉未验证。

## 类型、参数与网络操作

node_info 读取实际 parent 下的类型、端口和参数模板，不创建 scratch。真实 Tab/Shelf 初始化与静态默认值分别报告；操作卡关键参数保持可读。节点知识只有 [node-operation-contracts.json](../houdini/node-operation-contracts.json)一个来源，不从缺字段自动推导设计缺口。

`verb_help(name)` 默认返回标注brief的真实签名、执行入口、返回类型和简短用途；`detail='full'`取得完整说明及已维护的结构契约。批量名称遵循同一规则。`node_info`要求现有创建网络，返回请求名称与解析后的实际类型；未知类型只提供真实可见名称候选，不自动替换为猜测的建模方法。

严格设参拒绝未知字段、非法菜单和不相符值形状。菜单使用真实 token/set_value；标量及单独组件接受有限数值、HScript 字符串或显式 expression/language；多分量 tuple 接受等长数值列表，表达式写组件名。multiparm 先设置 count 再写实例字段。

静态参数卡、批量预检与实时设参以原生模板维数为准，分量名称推导缺失不能把多分量误判成标量。内置BeginEnd、StartEnd、MinMax、MaxMin等命名按目标版本真实HOM回读验证；参数错误同时指出实际解析的节点类型，避免将旧版本参数用于新节点。

写入与求值分别报告。合法 0 不算失败；明确新参数诊断、非有限求值或实际写入失败恢复本调用参数及 keys。旧缓存或无法归属的诊断保留 warning/unverified，随后可显式 cook 检查修复。参数求值成功不证明几何响应正确。

multiparm数量修改的快照包含全部嵌套实例。失败恢复先重建数量与结构，再按原节点identity/参数名恢复值、表达式、keys和锁定状态，并回读确认；仅数量相同不构成恢复成功。render_frame的临时输出/前台参数或frame恢复失败同样进入未恢复修改处理，同批后续写入和保存停止，已写出的外部图像/缓存仍保留为独立事实。

read_parms(names=[...])读取明确字段，string 返回 source_sha256。字符串patch使用原文expected_sha256、old/new与精确count；完整源码同步使用同一expected_sha256与source字面文本，两者互斥。过期hash或锚点不匹配时本批参数写前拒绝；同步相同源码返回changed=False。只写指定字符串，不执行脚本/正则，不回写源文件；调用方明确文件或现场哪个是当前编辑来源。set_parms继续strict，写后失败恢复本批值/keys。

connect 返回原生接线，None 保留空槽；subnet 间接输入不猜成普通 Node。disconnect 后输入可能压缩，后续读取 inputs_after。跨 subnet 使用 Object Merge 或明确端口，不猜输出口。delete/rename 返回实际影响，不因同名新节点推断引用恢复。

## SOP 批量构建与检查

[SOP contracts](../houdini/python3.11libs/dsh_sop_contracts.py)负责批量新增、静态检查、计算和清理。build_module 接受非空节点声明列表；inputs 可引用任意声明或现有直属 child。先创建全部节点，再连线和设参，声明顺序自由，表达式也可引用本批任意节点。None 保留空槽；不覆盖既有节点或输出旗标。

dry_run 只检查真实类型、参数和引用，独立静态错误汇总返回；不证明表达式、VEX 或计算结果。没有固定节点数量和 required_outputs 数量上限。实际构建显式指定新 output；required_outputs 和 interfaces 仅在调用方声明时检查。失败清理本批新节点并保留原错误。

verify_network 必须明确 output，默认拒绝 empty/error，require_valid=False 只作诊断。检查返回所选范围的 cook、非空、几何概要、显示/公共出口和单位事实，不按 OUT_ASSET 等名称追加领域检查。limit 是调用方声明的观察范围，不对任务网络大小设另一层硬上限。

Manual 模式不触发 geometry/camera/render 求值，不把缓存当作新鲜结果；需要计算时显式切换更新模式。失败 cook 后不经 geometry() 隐式重算。warning、计算成功和语义正确分别报告。

SOP subnet/HDA 的公共输出用 sop_set_output 发布原生 Output；普通 geo 只需明确最终 SOP 和 display/render。output_index 指定时检查真实公共接线，不自动猜祖先、调整 OBJ 可见性或保存定义。嵌入 Packed 的包装点/面不算实际内容；外部 Packed 或无法展开的表示保持 unverified。

## 几何、关系与控制

[geometry observation](../houdini/python3.11libs/dsh_geometry_observation.py)及 [quality contracts](../houdini/python3.11libs/dsh_quality_contracts.py)量测实际输出。作者按问题选择指标和关系；没有声明的关系不自动加入完成门。

| 观察 | 实际范围 |
|---|---|
| Polygon inspect/integrity | 指定输出/组的边界、连通、非流形、朝向、局部退化和条件性壳体积；不证明任意自交或艺术质量 |
| center-axis surface hits | bbox中心轴与实际平面多边形边界的交点，覆盖凹面；非平面估算及共面射线保留unverified，不以扇形覆盖空洞证明表面存在 |
| planar face crossings | 单个近似平面 Polygon 非相邻边的严格内部交叉；不外推三维面间自交 |
| attrib unique / point spacing | 精确属性唯一性或显式有序点相邻弦长；不替代容差焊接或曲面接触 |
| named surface / section proximity | 声明实际表面及截面的距离与部件覆盖；不证明连续全表面关系 |
| axis_gap | 实际 primitive 组的轴向投影间隙及横向重叠 |
| solid_overlap | 完整闭合朝外 Polygon 操作数的实际 Boolean 交集体积；零交集不证明轴穿孔或接触 |
| axis_passage / bore_clearance | 显式轴线或声明区间、半径的空域；不从整件 bbox 推断孔径或板厚 |
| component_count / physical_extent | 声明最终组的连通件数或经 HIP 单位换算的轴向尺寸；组身份仍由作者核对 |
| stable-ID displacement/transform | 相同 Polygon 拓扑与唯一点 ID 下的位移和仿射残差；driver 点不替代实际成品 |

返回范围、预算和 unsupported/unverified，不能用 bbox、响应非零或无报错冒充实体关系。内嵌 Packed 可在受限副本上展开观察；磁盘/Alembic/Fragment 及超展开预算保持 unverified。

test_controls 必须 exec，声明数字控制、指标/关系和扰动；随后恢复参数值、表达式、keys、frame 及完整 bgeo。顶层 interfaces 适用于基准与所有 case，baseline_interfaces 只验基准，case.interfaces 只验该扰动。具体状态应声明适用关系。

大型最终输出中，primitive关系按明确组提取；control的每项指标均具名group且所有关系/拓扑可用primitive组表达时，复用同一采集。原点/面/内存预算作用于实际选中副本，不提高单次量测上限。geometry_scope保留来源总量、实际选择及未测范围；点到面旧合同和无组整件指标仍受整件预算。大型control的恢复另外以完整原生bgeo文件流核对全部输出，未选部分漂移仍失败；文件快照最多2GiB，解析后排除写入时间/group_summary并解析字符串引用，不能误删同名用户属性。完整内容指纹不一致不能标恢复成功，未知编码/不等价的表示变化保持恢复未确认。小输出继续使用原有规范化bgeo比较；外部副作用保证不扩大。

小输出中的原生numeric属性按[HDK属性分页格式](https://www.sidefx.com/docs/hdk/_h_d_k__g_a__using.html)展开已知的packing、pagesize和constantpageflags，再逐元素精确比较；不同压缩方式不构成值变化，存储精度、默认值、颜色、位置及其他属性信息仍保留。不舍入、不忽略属性，非法分页拒绝，未知扩展保持原样而不推断等价。差异定位跳过完全相同的子树，避免大型无变化属性消耗定位预算；定位预算不决定恢复是否通过。

基准计算失败返回 not_run；results=[] 不算通过。恢复前后回读通道和几何，任何不匹配都不能报告 restored=true。外部文件、Python 和 solver 副作用不属恢复保证。单个 case 不外推整个参数域，控制响应非零也不等于设计正确。

测量方法不支持所选表示时，`measurement_failure`指出实际case、判据与选择；area额外给不支持的primitive类型、编号和开闭样本。基准失败零参数写入，所有未执行case仍标not_run；扰动后出现同类问题仍执行原恢复流程。诊断帮助选择适用方法，不自动改变测量指标或把局部支持部分冒充整个选择。

## HDA、界面与节点整理

HDA section 的写后回读/hash 只证明文本写入。PythonModule 语法检查不执行回调；真实按钮、内部函数、计算后的公共输出和新实例依赖分别观察。输入/输出上限不是接线证明；实例 spare 与定义界面分开管理。

HDA定义编辑的工作量以可编辑内容为边界：锁定嵌套HDA计一个节点，其内建实现不展开计入512上限；明确解锁的内容重新计入。此边界与原生源码快照一致，不缩小ownership或恢复范围。原生容器转换仍保存并核对完整内部identity及定义来源，lock丢弃仍检查全部后代；公开参数变化仍使旧计划失效。回执的descendant_count保留全部后代数量，editable_descendant_count单独报告工作量。lock的editable_discarded_descendants由同次原生遍历明确列出可编辑范围，完整discarded_descendants继续作为全部丢弃/重建清单保留。归档成功时，模型呈现可将已知HDA原生identity迁移与内部重建清单改为计数/详情指针，全部可编辑目标、影响实例、计划hash和应用状态仍直接可读。历史回执缺少该范围、结构不一致或出现未知诊断字段时不推断精简范围；未知自选结果保持原状。

HDA维护沿用实际来源库。hda_version在同库追加原生`::version`类型，保持scope/namespace/base与旧定义，失败恢复本调用的库/新增类型，不自动迁移实例或认领foreign库；Version元数据不代表类型版本。hda_switch_version只切换明确已锁定实例，原生保留共同参数通道和连线、加载新版内部内容。当前session自有实例在本次切换内展开新版内部网络，仅登记本次新建的内部identity，已有identity不因路径/父级变化被认领；foreign实例的单次切换授权不形成后代长期归属。未保存内部内容先由hda_edit处理。新建/独立衍生资产使用明确目标路径，Package、工程或用户选择的个人otls/hda目录均可；目录选择由工具开发skill按用户意图维护，不作为执行层强制Package策略。既有资产仍保留实际源库，所有作者写入继续拒绝$HFS及覆盖未授权的旧库。跨进程Package加载、任意回调外部效果和GUI菜单须分别验证，见[HDA维护](../skills/houdini-tool-development/references/hda-maintenance.md)。

section、界面与save/promote复用共享定义写入保护：实际新库/定义的session登记及指纹、全部受影响实例同时检查。自建已有类型实例不授权原共享库；外部改写后的旧登记不继续有效。单次明确allow_foreign不永久认领定义；所有作者写入拒绝$HFS。unlock不授予后代ownership。save/promote/lock只登记本次明确原生操作为当前session自有实例重建的新identity；已有identity及foreign实例/后代不被认领。失败Undo也可能替换此前仍存活的内部节点，归属恢复需对应batch开始时的准确记录，并排除Undo前已存在的候选。写后失败恢复本调用定义section、实际变化的实例界面/通道和磁盘库，范围由回执说明；后续exec失败不撤销已经成功的库写入。普通spare追加、定义重建及持续绑定分别使用对应动词，方法见[控制参数与绑定](parameter-controls.md)。

原生工具Package默认JSON直接指向用户确认的唯一资源源目录，不复制或归档；开发前区分工具修改意图与已有包扩展/新包及两个存放位置。创建注册只写全新JSON；旧配置由明确目标的通用文件编辑最小维护，原有条件/依赖/未知字段保留。当前进程load/activate/deactivate/unload不编辑持久enable、不删除配置/源或强清模块缓存。配置文件与实际原生Package/定义分别回读，停用/卸载不能从磁盘文件存在与否推断场景依赖；部分失败保留真实文件、回读错误与加载状态，不承诺撤销任意回调效果。

Network Box、Sticky Note和layout是编辑器presentation mutation，不代表业务或几何质量。节点、Box和Note使用各自identity归属；名字、颜色、成员与自有parent都不授权。Note只局部维护明确对象，不隐式加入Box；已有Note是布局固定障碍。失败补偿和编辑事务恢复保留真实范围。layout默认只处理当前会话节点，持久服务与未选障碍保持固定。详细用法见[跨领域网络交接](../skills/houdini-network-handoff/SKILL.md)。

顶层houdini_ui_list在Bridge主线程队列发现当前显示的原生pane、同进程可见QWidget顶层窗口与QDockWidget面板，返回对象引用、实际区域和当次支持条件。引用来自现有runtime及实际对象身份，每次捕获重枚举匹配，不按标题/历史路径猜对象、不包装传入指针、不设另一登记表。隐藏标签、菜单/Tooltip、任意Qt子控件不作为独立目标；模态对话框当前保持unverified。纯QWindow/Qt Quick窗口不在当前发现范围。

houdini_ui_screenshot只接受target及图片输出选项，原样使用发现所得引用，仅截当前表面；不接受node/view/width/height，不创建面板、切页、滚动、改节点、resize、激活、移动或关闭窗口。pane区域来自原生qtScreenGeometry，Qt停靠面板来自实际容器几何，不用整个父窗口冒充某pane；目标对象及区域在各阶段重新核对。打开节点、切换视图或检查宽窄尺寸作为单独的明确界面交互，之后重新发现并捕获实际显示；截图不调用会改变真实选择的setPwd，不回放已有pane的导航缓存。阶段之间返回正常GUI事件循环绘制，不修改模型参数或借截图保存工程，不泵嵌套事件循环、不在同步Python批次内等待UI刷新。发现与捕获共用原请求票据及执行事实，同票据查回原结果，不重新拍摄。返回实际图片/尺寸/状态保持，沿同源图片附件消费；清理只释放本请求绘制信号和图片路径预留，不关闭借用表面。

参数截图显示当前参数页，不替用户按按钮或切换业务模式；原生显示可能求值控件现有表达式/动态菜单，任意自定义脚本副作用不属于截图恢复保证。scene_writes=0说明截图接口没有直接设参或保存，不认证未知回调无副作用。

Windows H21/H22按已有原生窗口句柄截取所选区域；使用const effectiveWinId，不以winId强制建立用户窗口的native句柄。阶段就绪由外层GUI回调通知：H21使用Qt事件，H22等待原生空闲；回调只设置Event，注册/注销和全部HOM仍在Bridge队列。已有空白/纯色画布可以是合法当前显示，不以像素变化冒充内容正确。GUI不可用明确unsupported；目标发现、捕获/传输和模型识图分别判断。通用方法只在[工具开发证据指导](../skills/houdini-tool-development/references/evidence-and-validation.md#观察实际工作界面)维护，截图不替代绑定、输出或其他页的测试。

窗口捕获会读取所选区域的屏幕像素，按[Qt接口](https://doc.qt.io/qt-6/qscreen.html#grabWindow)的实际条件要求目标完整在屏内；采样前后核对父窗口上方的可见原生窗口，遮挡或出屏明确拒绝，不移除外部窗口或以系统置顶绕开。支持条件不等于内容正确，主窗内部绘制遮挡、物理键鼠、额外字体/DPI与任意第三方GL表面不因普通pane验证而自动通过。初始尺寸、实际尺寸、实际区域与捕获方法保留在回执，不把窄面板通过外推任意桌面状态。

## 渲染、构图与保存

[camera framing](../houdini/python3.11libs/dsh_camera_framing.py)按实际透视/正交投影求解。full 完整包络，detail 仅改变二维取景大小。A/B 使用同 framing_frame，并复用覆盖全部状态的 framing_bounds/depth_bounds、方向、画幅和模式；越界不能悄悄移动相机。

near/behind/far_clip 错误在渲染前拒绝；detail 的二维 intentional_crop 与深度错误分开。camera_fit 修改明确相机并保留其焦距合同；预览服务相机不改作正式相机。渲染或像素差异不证明模型外形和关系正确。

render_view(EXPLICIT_SOP)使用持久 __dsh_houdini_* 服务，任务结束复用不删除。服务和预览临时状态独立于作者建模 Undo；图片文件是外部效果。返回 source/framing/pixel/check/artifact 的实际事实，无法解码或旧文件不报新鲜图像。

画面检查的共用合同独立于所选原生后端。H21的OpenGL与H22的Flipbook沿用[工具设计](tool-design.md)中已验证的兼容边界；节点存在和不透明图像成功不证明几何透明、颜色接口或所有参数等价。render_view仍只支持当前GUI合同；原生Flipbook的headless能力不因此被否定，也未扩展为本接口的已验证范围。

渲染和缓存相对路径锚 $HIP，必须有后缀。render_view 与 viewport_screenshot 默认将验证图分配到 `$HIP/dsh-artifacts/checks/previews/<HIPNAME>/<run-id>/`；最终图片可选 delivery，分配到 `$HIP/dsh-artifacts/renders/<HIPNAME>/`。HIPNAME保留版本与原名，只去掉标准HIP扩展；命名组不是工程身份，精确来源由artifact的hip_path记录。两种分配要求已命名 HIP，只接受省略文件名或安全 basename，拒绝可执行表达式，并返回唯一、不覆盖已有文件的实际路径；自定路径选择 explicit，裸文件名仍进入visual_check的HIPNAME目录。输出位置不证明视觉质量或完成。正式 render_frame/ROP 使用明确的输出目标，已有含目录的用户路径优先；新建Karma Render Settings（含Karma Setup）默认关闭景深，picture与checkpoint使用同源render目录和原生$HIPNAME。后续渲染不暗改已配置的景深。Save As只影响后续默认输出，不迁移或删除旧图。

USD Render ROP的outputimage留空时，render_frame沿当前ROP的实际输入和RenderSettings观察磁盘raster产品，保留原生多产品设置；多文件逐个保留freshness，output仅单文件时为路径，多文件使用outputs。delegate/deep/checkpoint及非磁盘产品明确保留未验证，不以周期checkpoint缺失判成图失败。Husk文件名使用原生expandHuskFilePath，不二次执行backticks；相对产品位置、未明确的settings选择与RenderPass不推断。显式picture仍为本次覆盖并恢复。USD预检与渲染期的frame恢复失败同样产生render_restore事实。

viewport screenshot 在成功和失败后恢复视角、相机绑定、frame、selection/flags 等声明状态；异步捕获尚无完成证据时保留未知及本次 reservation。文件、传输、显示和语义识图分别返回；没有模型内容级观察时保持视觉未验证。

scene_save 只写当前明确路径；scene_save_as 需要用户授权的目标、expected_current_path 和用途说明。raw load/clear 不开放。保存回执是当时文件事实，重开检查、可编辑性与最终结果由对应观察确认。

文件回执的mtime_ns以十进制字符串保留纳秒原值，避免Python整数经过JavaScript JSON数字后舍入；只作指纹比较，不转换为Number计算。历史数字回执沿原记录读取，不补造已经丢失的末位。

## 验证入口

日常按改动选检查，完整方法见[开发维护](development.md)。执行内核核心回归覆盖 [Raw Gate](../tools/tests/dsh-bridge-raw-gate.test.py)、[节点归属](../tools/tests/dsh-node-ownership.test.py)、[捕获失败](../tools/tests/dsh-bridge-caught-failure.test.py)、[创建清理](../tools/tests/dsh-tab-create-failure.test.py)、[OBJ 父级](../tools/tests/dsh-object-parenting.test.py)和[场景/网络/渲染](../tools/tests/dsh-scene-network-render-contract.test.py)。

批量构建见 [module-preflight](../tools/tests/dsh-module-preflight.test.py)，参数恢复见 [control-state-restoration](../tools/tests/dsh-control-state-restoration.test.py)，请求未知与查回见 [request-recovery](../tools/tests/dsh-request-recovery.test.py)，实际节点知识见 [node-knowledge](../tools/tests/dsh-node-knowledge.test.py)。隔离机制检查不替代用户 live 加载或自然模型任务质量。
