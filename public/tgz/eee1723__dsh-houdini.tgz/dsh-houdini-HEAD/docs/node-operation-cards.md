# 节点操作卡参考

> 自动生成，勿手改。唯一数据源：[node-operation-contracts.json](../houdini/node-operation-contracts.json)。
> 生成：`npm run docs:generate`；只读校验：`npm run docs:check`；正常构建会自动更新。

Schema: 2 · Cards: 21 · Source SHA-256: `85255fe74c60de2a44e7ca8380f147a2e356d54806d4ae48b470114ba6c3167d`

## 数据与设计契约

- JSON维护输入语义、决策、反例与来源；本页逐项镜像，英文操作说明不另行手译成第二份真相。
- `id`标识知识修订；`node_types`限定精确类型，省略时按现有family规则匹配。`tested_versions`是证据范围，省略不表示已验证所有版本。
- `critical_parameters`只维护关键参数名；实际类型、默认值、组件名、菜单token/set_value由Houdini运行时模板提供，不在文档固化菜单索引。
- `decisions[].any_of`列出备选字段组合：满足任一组合仅表示显式提供字段，不证明值或建模意图正确。`always_advisories`保存每次采用该节点都必须看到的参数语义反例；两者的`guidance`都解释边界。
- `node_info`返回不受普通filter/limit裁切的`operation_parameters`及缺字段提示；静态模板不等于Shelf初始化后的实际值。
- `build_module.operation_advisories`按类型合并缺字段和常驻语义反例，最多16条并报告总数/截断。不阻断、不改默认值、不cook、不解析VEX；未决选择可先dry_run。
- 精确类型不匹配时不套用受限卡；复制返回值不应修改缓存。新增字段必须同时更新生成器、运行时消费者和测试。

实现：[卡加载器](../houdini/python3.11libs/dsh_operation_cards.py)、[node_info](../houdini/python3.11libs/dsh_hou_helpers.py)、[模块构建](../houdini/python3.11libs/dsh_sop_contracts.py)。
契约：[工具设计](tool-design.md)；验证：[节点行为回归](../tools/tests/dsh-node-knowledge.test.py)。

## 卡片目录

- [mirror](#mirror)
- [bend](#bend)
- [skin](#skin)
- [pathdeform](#pathdeform)
- [sweep](#sweep)
- [polyextrude](#polyextrude)
- [polybevel](#polybevel)
- [sphere](#sphere)
- [tube](#tube)
- [circle](#circle)
- [box](#box)
- [revolve](#revolve)
- [normal](#normal)
- [reverse](#reverse)
- [copytopoints](#copytopoints)
- [object_merge](#object_merge)
- [blast](#blast)
- [attribwrangle](#attribwrangle)
- [cam](#cam)
- [karmarendersettings](#karmarendersettings)
- [boolean](#boolean)

## mirror

标识：`mirror-plane-and-seam-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/mirror.html)。

精确类型：`mirror`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`operation`、`dirtype`、`origin`、`dir`、`t`、`r`、`dist`、`keepOriginal`、`consolidatepts`、`consolidatetol`、`consolidateunshared`、`reversenml`。

### 操作与边界

- Input 0 is geometry to mirror. operation=all reflects all selected primitives; operation=clip first keeps the positive side of the mirror plane. keepOriginal is case-sensitive. Default direction plane is X=0; dist offsets it along its normal.
- consolidatepts joins eligible original/reflected points on the plane within consolidatetol, optionally restricted to unshared edges. It is not a union operation for overlapping solids. Check seam connectivity separately from symmetry or matching coordinates; an intentional open sheet remains open after joining its seam. Retain the editable half/source upstream so later width/detail changes propagate.
- Isolated evidence covers polygon sheet copy/clip, optional shared seam and an upstream width edit; it does not certify overlapping solid unions.

## bend

标识：`bend-capture-and-enables-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/bend.html)。

精确类型：`bend`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`dodeform`、`enablebend`、`bendmode`、`bend`、`enabletwist`、`twist`、`origin`、`dir`、`length`、`upvectorcontrol`、`up`、`limit_deformation`、`userest`。

### 操作与边界

- Input 0 is geometry to deform; optional input 1 supplies rest positions when userest is enabled. origin/dir/length define the capture spine; up sets the bending plane. Bend in angle mode and Twist use degrees. A different axis or capture length changes the resulting shape even at the same angle.
- Bend moves existing points; it does not add samples. A two-point segment remains a straight chord after bending, so retain enough upstream samples for the requested silhouette. Twist is off by default; a point on its axis does not move. With limited bend, geometry beyond the capture end follows the end transform rigidly; disabling the limit continues curvature. Recheck intended curvature, dimensions and local overlaps after editing rather than inferring them from successful angle assignment.
- Isolated geometry evidence covers sampled line bending and twisting, capture axes/length/limits and inactive Twist; other deformation modes and rest-input combinations are not covered by those fixtures.

## skin

标识：`skin-ordered-sections-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/skin.html)。

精确类型：`skin`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`uprims`、`vprims`、`surftype`、`keepshape`、`closev`、`skinops`、`prim`、`polys`。

### 操作与边界

- For a one-direction loft, input 0 contains the ordered section primitives. Input 1 supplies optional V sections for a different, cross-skin construction; it is not simply the next section in the loft.
- Section order, direction and seam correspondence define the surface. Reordering three valid sections can still cook without errors while joining nonadjacent sections. Preserve separate editable section sources and inspect their correspondence before and after edits.
- With polygon circles, keepshape=1, polys=1 and surftype=quads produce polygon strips through the section vertices. Output Polygons does not convert NURBS/Bezier outputs. closev closes the loft direction; it is not an end-cap switch. An intentionally open loft is a valid surface.
- Isolated evidence covers equal-point polygon sections and a local section edit, not automatic correspondence for arbitrary mixed curves.

## pathdeform

标识：`path-deform-source-frame-and-mapping-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/pathdeform.html)。

精确类型：`pathdeform`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`geo_controlaxis`、`geo_controlup`、`curve_controlup`、`geo_origin`、`geo_centeroncurve`、`geo_offsetunit`、`geo_capturestart`、`geo_captureend`、`curve_endunit`、`curve_posend`、`curve_posoffset`、`startbehavior`、`endbehavior`。

### 操作与边界

- Input 0 is existing geometry to deform; input 1 is the spine curve. Unlike Sweep, this reshapes an already modeled source. Source subdivisions must support the intended bend; deformation does not add sampling along a coarse source.
- Establish the source forward/up axes and curve up separately. Defaults are geo_controlaxis=z, geo_controlup=y and curve_controlup=yaxis. A wrong source axis can cook without errors while stretching the cross-section across the whole curve. Custom axis modes have separate vector parameters; inspect the active templates.
- curve_endunit=fractioncurvelength with curve_posend=1 spans the full curve; fractiongeolength with 1 preserves the source length along its forward axis. These are different valid intents. Capture bounds and centering determine which source interval bends; uncaptured regions can extend along the endpoint tangents.
- Retain the source and spine independently. After changing the path, check corresponding source landmarks, section orientation and thickness, and endpoint placement against the selected length/capture policy. Nonempty output and unchanged topology do not prove correct mapping.
- Isolated evidence covers a subdivided polygon solid mapped onto a planar sampled arc with a fixed up axis; complex spatial twist, rigidity and arbitrary self-intersection remain outside that fixture.

## sweep

标识：`sweep-cross-section-v2`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/sweep.html)。

精确类型：`sweep::2.0`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`surfaceshape`、`endcaptype`、`radius`、`cols`、`primtype`。

### 构建前决策

- `section_source`：`surfaceshape`。Choose external input sections or a built-in section explicitly; wiring alone does not express the intended profile.
- `end_closure`：`endcaptype`。Choose open ends or an applicable cap type; an intentionally open tube/ribbon must not be capped automatically.

### 操作与边界

- With an explicit backbone, input 0 supplies the backbone and input 1 supplies optional custom cross-sections. Custom sections normally use the origin in the XY plane, +Y up (normal along Z), not the path start.
- When input 0 contains no backbone curve, Sweep can use an implicit backbone with one vertex per input-1 cross-section, all at the origin. An unconnected input 0 with multiple sections on input 1 is supported when surfaceshape=input; it does not infer a spatial path from section centers. closeifnocurveinput closes that section sequence, not the cross-sections themselves or end caps. Inspect section order/correspondence and the actual generated surface for this input arrangement.
- For a circular cable, feed the open centerline to input 0 and use the built-in tube with explicit radius/columns/endcaptype; a second input is only for a custom cross-section. In VEX addprim(..., "poly", points) makes a closed path; use "polyline" for a free-ended cable. A closed path can Sweep to a clean watertight shell while adding a wrong return segment. Reversed input order can cook a surface with the wrong shape. The centerline's loose end must meet the preceding tangent smoothly; Sweep cannot remove an upstream sharp turn. For custom sections explicitly establish section plane and path frame/up. tab_create with explicit input 1 reconciles the shipped Sweep 2.0 initializer to surfaceshape=input after wiring; explicit build parms may override this.
- A non-XY section may be intentional with Pitch/Yaw or upstream pre-rotation; do not rotate it blindly. Inspect local section extents and actual end boundaries; world bbox alone cannot prove a tube.
- On the listed tested versions, isolated Bridge evidence covers Tab-visible Sweep 2.0 with input 0 unconnected and two equal-count open polylines on input 1: input sections, default section order, quadrilateral surfaces and no caps produced the corresponding open quad strip. tab_create and build_module both preserved the None input slot. This scope does not certify unequal-count or other curve representations, implicit loop closure, arbitrary section correspondence, self-intersections, GUI appearance or artistic quality.

## polyextrude

标识：`extrusion-surfaces-v2`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/polyextrude.html)。

精确类型：`polyextrude::2.0`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`outputfront`、`outputback`、`outputside`、`dist`、`inset`、`group`、`splittype`。

### 构建前决策

- `extrusion_surfaces`：`outputfront` + `outputback` + `outputside`。Choose displaced front/original back/connecting sides for the input: sheet thickening differs from extrusion on an existing solid. Front/back do not mean world top/bottom.

### 操作与边界

- Front is the displaced face; Back is the original face; Side bridges them. These names are relative to extrusion, not world up/down.
- When thickening an open sheet into a closed slab, explicitly choose outputfront/outputback/outputside and inspect the final boundary edges and world position.
- Do not enable Output Back universally: extruding faces of an existing solid can create unwanted interior faces.

## polybevel

标识：`bevel-selection-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/polybevel.html)。

精确类型：`polybevel::3.0`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`group`、`grouptype`、`ignoreflatedges`、`flatangle`、`offset`、`divisions`。

### 构建前决策

- `bevel_selection`：`group` + `grouptype` **或** `ignoreflatedges` + `flatangle`。Choose a typed selection or an explicit flat-edge policy. Empty group can intentionally mean all eligible edges; angle filtering alone is not a semantic part selection.

### 操作与边界

- Direct creation has empty group, grouptype=guess, ignoreflatedges=0. Maximum Normal Angle is flatangle (degrees): with ignoreflatedges=1, smaller adjacent face-normal angles are excluded. It is not a maximum angle to bevel.
- For controlled hard-surface fillets, build a procedural edge group from construction boundaries/part identity and geometric criteria, then set group and grouptype=edges. Avoid persistent hard-coded edge numbers after topology changes. Explicit all-edge or point bevels remain valid intents.
- Choose width against local feature spacing and inspect the selected edges and resulting corner geometry; nonempty output/collision options do not prove no overlap or correct detail. Increasing divisions cannot fix a wrong selection.
- On H21.0.440, a complex network has crashed during PolyBevel viewport guide cook despite successful output cook/render/save. A simple H21/H22 GUI smoke passed. For a risky final topology, retain a bypassable source and test its actual GUI selection/guide path before claiming it stable.

## sphere

标识：`sphere-representation-and-resolution-v2`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/sphere.html)。

精确类型：`sphere`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`type`、`freq`、`rows`、`cols`。

### 构建前决策

- `representation`：`type`。Choose the representation before face editing: a native sphere is not a polygon mesh. Preserve native/NURBS/packed representations when required by the downstream task.

### 常驻语义提示

- `effective_resolution`：Sphere type=poly (Polygon) uses freq; rows/cols can accept values without changing its geometry. type=polymesh (Polygon Mesh) uses rows/cols and ignores freq. Select the representation first, then vary its effective resolution control and inspect actual polygon count and silhouette; successful parameter assignment is not evidence of finer geometry.

### 操作与边界

- Direct creation type=prim is an analytic Sphere. Polygon and Polygon Mesh are distinct menu choices with different tessellation controls; use the current menu tokens, not a shared numeric index.
- For polygon modeling, explicitly choose the polygon representation and inspect actual primitive types and silhouette density. Houdini's generic primitive count also counts native/packed objects; it is not a polygon face count.
- Inactive tessellation fields retain readable values. A high rows/cols value on type=poly does not establish a smooth surface, and a Normal SOP cannot improve a coarse silhouette. Check resolution on the actual source and again after the consuming operation; do not increase every subdivision control indiscriminately.

## tube

标识：`tube-representation-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/tube.html)。

精确类型：`tube`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`type`、`cap`、`rows`、`cols`、`orient`、`height`、`rad`。

### 构建前决策

- `representation`：`type`。Choose polygon output for polygon face operations; native Tube is a legitimate alternative, not a failed polygon.
- `end_closure`：`cap`。Choose whether end caps are intended. Open pipes and closed solid cylinders have different contracts.

### 常驻语义提示

- `radius_axes`：Tube rad1/rad2 are the X/Y ellipse radii of one cross-section, never outer/inner radii. A capped Tube is a filled cylinder even when rad1 and rad2 differ; use a construction that creates an actual inner surface for a pipe, washer or through-hole.

### 操作与边界

- Direct creation type=prim and cap=0. Explicit polygon type and caps are separate decisions; a nonempty native Tube does not establish polygon topology.
- rad1/rad2 are the X/Y ellipse radii of one cross-section, not outer/inner radii. Inspect the actual axis, radius, end boundaries and resolution before using the unit in booleans or instancing. A capped cylinder does not by itself model a hollow pipe wall.

## circle

标识：`circle-representation-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/circle.html)。

精确类型：`circle`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`type`、`arc`、`orient`、`divs`、`rad`。

### 构建前决策

- `representation`：`type`。Choose a polygon or smooth curve representation for the downstream profile operation; do not assume a native circle provides editable perimeter points.

### 操作与边界

- Direct creation type=prim. For a polygon profile, explicitly choose type=poly and establish plane, arc/closure and subdivisions. A closed perimeter, filled polygon and thick closed solid are different deliverables.
- Native or NURBS curves can be intentional; do not insert Convert blindly. Verify the resulting representation after the consuming surface operation.

## box

标识：`box-representation-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/box.html)。

精确类型：`box`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`type`、`size`、`divrate`。

### 操作与边界

- Unlike Sphere/Tube/Circle, direct Box creation already defaults to type=poly. Do not globally set type=0: numeric menu indices differ between node families.
- Set dimensions and only the subdivisions needed by the intended operation; a dense flat box does not gain construction detail merely from more faces. Native/mesh output remains an explicit alternative.

## revolve

标识：`revolve-solid-input-v4`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/revolve.html)。

精确类型：`revolve::2.0`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`origin`、`dir`、`divs`、`type`、`surftype`、`primtype`、`swaprowcol`、`reversecrosssections`、`cap`。

### 构建前决策

- `axis`：`origin` + `dir`。Choose the actual rotation axis relative to the profile; a centered Y-axis is only one valid intent.
- `surface_output`：`surftype` + `primtype`。Choose the surface grid and output primitive type. Automatic primitive type follows the input curve; nonempty output does not prove Polygon faces.
- `end_closure`：`cap`。Choose whether to cap the ends of an open profile. Closed revolution around the axis alone does not cap those ends.

### 常驻语义提示

- `surface_orientation`：A revolved Polygon may be closed and consistently wound yet face inward. Before instancing or solid operations, inspect a representative source with geo_piece_stats(..., inspect=True, integrity_only=True): read boundary_edges, orientation_conflicts and shell_orientation separately. Confirm facing against a known exterior face; then correct one direction control and recheck. Never default reversecrosssections=True or use Normal to repair winding.

### 操作与边界

- Facing comes from the ordered profile swept around the chosen axis, not from closure or cook success. With the same axis/settings, reversing profile vertex order reverses surface facing. Inspect the actual profile order and origin/dir; looking clockwise in an arbitrary viewport is not an orientation test.
- reversecrosssections treats the input curves as reversed. Toggling swaprowcol also reverses facing while changing grid ordering. For a confirmed inward simple shell, change one relevant setting or the profile order, then read the output again; toggling both can cancel the facing correction. There is no universal outward value of reversecrosssections.
- Revolve Type closed spans the full circle; Closed Arc adds a point on the axis and produces a different shape. End Caps applies to open input curves. Check the actual profile and final boundaries before instancing.
- A profile whose open endpoints merely coincide is not topologically closed. Establish intended profile closure, or target only a confirmed coincident seam with a scale-appropriate Fuse; recheck boundaries and shape. Fuse repairs connectivity, not facing; preserve intentional gaps.
- Normal computes or flips N without changing polygon vertex order. Double-sided shading, zero boundary edges and zero orientation_conflicts do not prove outward facing. shell_orientation positive follows outward HOM winding only for simple unnested closed shells; nested cavities, self-intersections and open surfaces need separate interpretation. Check mixed-direction profiles separately instead of reversing the entire output.
- After changing the profile order, axis or grid-direction settings, refresh the affected source check and its Copy/Boolean consumers. A passed group does not certify other profiles or the complete assembly.

## normal

标识：`normal-attribute-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/normal.html)。

精确类型：`normal`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`group`、`grouptype`、`docompute`、`type`、`cuspangle`、`reverse`。

### 常驻语义提示

- `winding_vs_normal`：Normal computes or changes the N attribute. Its reverse parameter multiplies N by -1; it does not reverse polygon vertex order or repair inconsistent winding.

### 操作与边界

- Choose point, vertex, primitive or detail normals for the shading need. For an actual wrong-facing Polygon, correct its winding upstream or with a targeted Reverse SOP, then recompute N if needed.

## reverse

标识：`reverse-vertex-order-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/reverse.html)。

精确类型：`reverse`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`group`、`vtxsort`。

### 构建前决策

- `vertex_order`：`vtxsort`。Choose the vertex operation explicitly using the current menu token; Reverse, Reverse U/V, Swap and Shift have different effects.

### 操作与边界

- Reverse changes vertex order on selected faces. Repair only the affected primitive group when the problem is local, then recheck topology orientation and any existing N attribute.

## copytopoints

标识：`copy-local-frame-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/copy/instanceattrs.html)。

精确类型：未另限定（按family匹配）。
已测版本：此卡未列出，不外推版本保证。

### 操作与边界

- Input 0 is the source unit, input 1 the destination points. Establish the unit local axes and destination P/orient/scale before copying.
- Inspect attribute class and instance identity at the final output; do not assume a template name automatically identifies final primitives. Packed transform changes cannot be certified by P-only comparison.

## object_merge

标识：`object-merge-space-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/object_merge.html)。

精确类型：`object_merge`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`objpath1`、`xformtype`。

### 构建前决策

- `transform_space`：`xformtype`。Choose whether the import preserves source object placement or intentionally reads SOP-local coordinates. Cross-object assembly and render proxies normally require Into This Object.

### 操作与边界

- An object path alone does not preserve assembly placement. For a source under another OBJ, explicitly use Into This Object when the final relationship depends on that OBJ's translate/rotate/scale; local-space import is only valid when ignoring those transforms is intentional.
- Before using a merged proxy for relationship or visual acceptance, compare its bbox with the contributing sources in the same world space and resolve attribute-mismatch warnings. A nonempty render of a local-space proxy is not evidence for the placed assembly.

## blast

标识：`selection-class-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/blast.html)。

精确类型：未另限定（按family匹配）。
已测版本：此卡未列出，不外推版本保证。

### 操作与边界

- Set group type explicitly when selecting point numbers. A polyline with many points is still one primitive; primitive 0 is not point 0.
- Check surviving point/primitive counts before using the output as instance templates.

## attribwrangle

标识：`wrangle-execution-v4`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/attribwrangle.html)。

精确类型：`attribwrangle`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`class`、`group`、`grouptype`、`vex_numcount`、`vex_cwdpath`。

### 构建前决策

- `execution_class`：`class`。Choose Run Over before writing VEX: point/primitive/vertex for existing components, detail for one global execution, number for intentional iteration-count execution. Use current menu tokens, not guessed integers or a parameter named runover.

### 操作与边界

- The snippet is VEX; numeric parameter expressions outside the snippet are HScript unless explicitly tagged Python. Do not copy VEX chf/chi calls into HScript parameter expressions.
- vex_cwdpath is Evaluation Node Path: it changes the node-relative base for VEX ch() parameter lookup, not the filesystem directory for #include. Keep the default '.' unless deliberately evaluating relative to another node. Use an explicit project-relative include such as #include "$HIP/vex/shared.h" for an external file; check parameter values and actual output after changes.
- Declare attribute class/type and input slots. Use stable names/ids for module interfaces rather than recovering identity from bounding-box sort order.
- Run Over uses parameter class: detail executes once, point executes per input point (none on empty input), number repeats Number Count times. A snippet already looping over the entire generation domain usually needs detail, not number. Intentional Numbers generators use elemnum/numelem; do not change their mode blindly.
- Before Copy to Points, verify the template count and exact P/id tuple uniqueness with geo_attrib_stats(..., unique=True). Nonempty output and unchanged bounds do not rule out overlapping copies.

## cam

标识：`camera-framing-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/ref/cameralenses.html)。

精确类型：未另限定（按family匹配）。
已测版本：此卡未列出，不外推版本保证。

### 操作与边界

- For an owned static OBJ camera and explicit SOP target, use camera_fit to solve perspective depth and both screen axes before rendering. It preserves focal length, clears lookatpath, and reports actual projection margins; no preview service camera reuse as a delivery camera.
- Camera resolution/pixel aspect and the final USD RenderProduct may differ. After Scene Import, render_frame(..., framing={target: USD_asset_path}) checks the actual composed products. Do not infer full framing from camera distance or a nonempty image.

## karmarendersettings

标识：`karma-product-resolution-v1`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/lop/karmarendersettings.html)。

精确类型：未另限定（按family匹配）。
已测版本：此卡未列出，不外推版本保证。

### 操作与边界

- Karma Setup may derive and lock resolution components. Inspect list_parms locked_components and the actual RenderProduct before assigning both dimensions; do not unlock a recipe expression to suppress a strict-setting failure.
- Keep settings/product/camera paths explicit. Use render_frame's optional framing preflight for full-asset images; intentional crops and unsupported lens effects are separate contracts.

## boolean

标识：`boolean-solid-inputs-and-shading-v3`。来源：[SideFX 官方说明](https://www.sidefx.com/docs/houdini/nodes/sop/boolean.html)。

精确类型：`boolean::2.0`。
已测版本：`21.0.440`、`22.0.368`。

关键运行时参数：`booleanop`、`subtractchoices`。

### 构建前决策

- `operation`：`booleanop`。Choose the operation explicitly. For subtraction, inspect subtractchoices and the actual input order: A is input 0, B is input 1; a node name does not establish which solid is removed.

### 常驻语义提示

- `solid_input_validity`：For solid operations, inspect input closure and winding with geo_piece_stats(..., inspect=True); an inward shell can make A-B retain cutter material even when Boolean reports no warning. An ordinary solid A-B cannot extend outside A: expanded output bounds disprove the intended subtraction, while unchanged bounds alone do not prove a valid cut. Check the local cut surface and intended opening after cooking. Sheet operations remain valid with their explicitly chosen surface semantics.

### 操作与边界

- agroup/bgroup select INPUT primitive groups, not output names. Tag input primitives upstream and inspect groups on actual output; topology/group counts may change with parameters.
- Boolean triangulates inputs internally, then may join triangles back into large n-gons. A cut planar face with repeated bridge points can be closed and correctly wound but shade unevenly in the viewport. When integrity inspection reports planar_repeated_point_ngons, compare the affected Boolean node's Detriangulate=Only Unchanged Polygons with the current result; do not change every Boolean by default. Keep the change only after checking the face and connected parts at representative control states.
- If the face is geometrically flat but shades unevenly, compare a Normal SOP with vertex normals and suitable cusp/face-area weighting after the final Boolean and before placement. Explicit N changes shading, not polygon winding or solid overlap; preserve intended bevel highlights and verify the same closeup in more than one state.
