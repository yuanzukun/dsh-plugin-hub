# 设计与维护文档

本目录保存当前实现的设计规范、执行契约和长期维护说明；[当前交接](handoff.md)是唯一滚动待办例外。
不记录迭代日记、单次尝试、测试流水、模型成绩或退役原型。源码说明不等于已部署；运行态以实际诊断为准。

## 导航与唯一维护位置

| 文档 | 职责 / 对应实现 |
|---|---|
| [当前交接](handoff.md) | 未完成动作的优先级、依赖、验证缺口与移除条件；完成即删，不积累历史 |
| [系统架构](architecture.md) | Host、Bridge、启动器、UI、视觉和所有生产模块的代码索引 |
| [主要开发方向](development-directions.md) | 三项主要方向、COP按需能力边界、共用可靠性能力、目标交付与验收原则；不复制活动待办，不包含自动知识沉淀 |
| [Houdini Trace设计](houdini-trace-design.md) | 记录/资料/诊断信息架构、详情规范、提示词/工具/技能来源、版本同步与计数契约；明确生产接入边界 |
| [工具说明](tools.md) | 工具分别为何存在、输入、返回与执行位置；由tool-catalog生成 |
| [工具设计与词表](tool-design.md) | 动词目录唯一源、版本握手、设计准入；生成Host/浏览器目录 |
| [按需动词契约](verb-contracts.md) | verb_help读取的输入/成功返回结构、Python示例和作用域；由verb-operation-contracts.json生成 |
| [执行与证据契约](execution-contract.md) | ownership、Raw Gate、事务、模块构建、几何/控制/渲染边界 |
| [工程文件与图像目录](project-files.md) | 同源目录角色、真实HIP锚点、显式目的地、Save As与文件生命周期 |
| [节点操作卡](node-operation-cards.md) | JSON同源生成的全部节点卡、schema与维护约定 |
| [安装与更新](setup.md) | 当前源码安装与正式受管安装合同、机器态、工作区、启动、重载和卸载 |
| [故障报告](support-reports.md) | 本地诊断包、用户预览与分享、精确会话读取、脱敏边界及离线分析 |
| [多实例与任务恢复](multi-instance.md) | 独立工作台、明确现场选择、工程状态组件、只读/写入边界及按需节点恢复 |
| [节点片段交换](component-collaboration.md) | 普通节点文件导出、导入与显式替换；无额外Agent模式 |
| [DSH兼容设计](dsh-update-compatibility.md) | 正式发行组合/发布门、精确版本清单、DSH耦合点与唯一源码、鉴权/RPC/Qt/profile升级检查入口 |
| [Rig与动画设计](rig-animation-design.md) | 领域路由、driver→evaluation→deliverable和动画完成门 |
| [程序化产品模型开发评测](product-modeling-evaluation.md) | 产品细节、连接、可编辑性和交付的验收原则；公开任务与评审材料隔离，不保存批次结果 |
| [开发维护规范](development.md) | 代码/文档同步、生成门禁、测试入口、发布及文档生命周期 |
| [控制参数、界面与绑定设计](parameter-controls.md) | 跨建模/场景总控/HDA的分层职责、多种推进顺序与实施完成门 |

领域操作方法的唯一维护源仍在[随包skills](../skills/)；本目录提供设计和实现入口，不复制另一份recipe。

[任务拆分skill](../skills/houdini-task-decomposition/SKILL.md)维护跨领域的模块粒度、依赖、逐模块观察与集成；[完整源组件](../skills/houdini-sop-workflow/references/modeling-methods.md#完整源组件与布局)维护SOP的组件内部构造、布局与装配分工。由preset按需路由，注册入口为[src/skill.ts](../src/skill.ts)，上下文与方法验证见[开发维护](development.md)。

[曲线方法](../skills/houdini-sop-workflow/references/curves-and-routing.md)维护稀疏锚点、原生编辑、平滑、绕行与截面朝向的选择；节点事实由同源操作卡提供，[节点知识回归](../tools/tests/dsh-node-knowledge.test.py)核对实际修改及最终消费者，任意避障和自然造型质量不由这些机制检查认证。

[独立执行skill](../skills/houdini-isolated-execution/SKILL.md)维护作者与DSH团队成员按需使用一次性hython的输入、依赖、检查、原生图片和结果接入；工具由[isolated-execution](../src/isolated-execution.ts)提供，复用现有Python检查器及DSH作业，验证入口见[开发维护](development.md)。

[网络交接skill](../skills/houdini-network-handoff/SKILL.md)维护跨SOP/COP/LOP/rig/工具的主动节点入口、Network Box、Sticky Note和布局判断；参数布局判断由参数UI skill负责，通用已有界面的发现/捕获方法由[工具开发证据指导](../skills/houdini-tool-development/references/evidence-and-validation.md)维护，功能验收留在各领域。注册入口为[src/skill.ts](../src/skill.ts)，执行与验证入口见[开发维护](development.md)。

教程工程的目的/原片回看/差异核对/替代顺序及交付门唯一维护在
[复现协议](../skills/houdini-video-tutorial/references/reconstruction.md)，由video skill进入复现阶段时读取。
视频资料分层、章节/模块索引、定向取证、原文分页与真实测试方法唯一维护在
[视频运行与证据契约](../skills/houdini-video-tutorial/references/video-processing.md)；原始材料和单次结果不进入docs。

[COP workflow](../skills/houdini-cop-workflow/SKILL.md)维护 Copernicus 图层、关系验证与纹理交付，
由教程复现按当前阶段加载，不用于只解析视频或仅消费贴图；来源/版本与验证入口见其
[验收矩阵](../skills/houdini-cop-workflow/references/evidence-and-validation.md)，注册由 `src/skill.ts` 维护。

[表面外观skill](../skills/houdini-surface-workflow/SKILL.md)维护跨任务的参考分析、表面细化程度、纹理来源、UV与SOP统一预览；[生成贴图](../skills/houdini-surface-workflow/references/generated-textures.md)维护图像角色、提示词、文件消费与混合加工；[COP图案方法](../skills/houdini-cop-workflow/references/pattern-design.md)维护可编辑图层设计。注册、模型上下文传输及隔离SOP显示验证见[开发维护](development.md)，正式渲染沿Solaris/Karma。

HDA封装、PythonModule/回调、脚本打包、Shelf/Tab、快捷键及Panel/Viewer State由
[Houdini 工具开发 skill](../skills/houdini-tool-development/SKILL.md)维护；共享控制定义、参数UI组件与绑定由
[参数界面skill](../skills/houdini-parameter-ui/SKILL.md)维护，适用于普通控制节点和HDA。注册入口为
[src/skill.ts](../src/skill.ts)，来源、版本范围与验证入口见其
[证据与验收](../skills/houdini-tool-development/references/evidence-and-validation.md)。

## 文档准入

新增文档必须回答一个长期维护问题，并列出对应源码/配置、适用范围和验证入口。
优先修改上表现有文档；确需新增时同步索引。实现变更就地替换现行说明，不追加“vN本轮修复”章节。
稳定测试方法与保证边界应保留；某次运行的通过数量、耗时、截图、session ID和实验叙事不进入docs。
过程输出留在会话/CI或不打包的临时产物中，历史由Git保留；不建立docs归档库继续堆积。
交接只在handoff.md原位更新，体量与清理规则见[开发维护](development.md#交接文档生命周期)；
不把它扩成所有产品方向的任务清单，也不把本机tools/out当跨电脑交接的唯一依据。
