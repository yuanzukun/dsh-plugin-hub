# HDA 代码与交付维护

适用：HDA/OTL的端口规划、封装交付、模块/回调/动态菜单维护及依赖检查。
不适用：普通参数赋值/改名或未要求封装的模型；内部几何按对应领域流程验收。
维护当前HDA定义、实例与文件边界，不替代package安装或跨机器入口验证；整体工作流仍是候选。

## 定位与依赖

新建时先明确端口数量、顺序/名称、数据含义、必需/可选、空输入行为和各输出的消费者。
纯生成器可为0输入/1输出；加工器按需求声明，不照抄subnet默认四输入。hda_create的min_inputs/
max_inputs及max_outputs只声明边界，内部Output仍须实际接线；多输出逐口验证，display/render旗标不等于端口。
SOP公共端口用sop_set_output(末端,output_index=端口索引)复用/创建并接线，再用verify_network(parent,output=末端,output_index=同索引)验收。
仅在subnet/HDA边界发布，不自动猜根输出；普通geo不要求Output节点，明确最终SOP及display/render即可。Geometry类型HDA还要把根层最终SOP显示设好。内部Object Merge/表达式用实例相对引用，
不得硬编码某个源实例路径；在不同名称/位置创建两个实例，各改一个控制，确认互不串读。外置材质也是交付依赖。
先用最小几何验证公开控制→定义界面→新实例→下游消费者，再扩展复杂网络。新实例的HOM identity须重新取得。
原实例spare不会自动证明定义已携带参数；冲突写前拒绝时保留源实例，用显式promote迁移，不能删除唯一状态来赌修复。

“解锁内容”“将修改保存到定义”“匹配定义重新锁定”“拆解/移除资产封装”是不同动作。
重新匹配会丢弃未保存的内部修改，保存定义会影响共享实例；都不等于普通参数编辑。执行层只接续本次明确操作为自有实例重建的新identity，已有或foreign后代不被认领；失败回滚的身份恢复也由执行层核对，不自行用allow_foreign绕过。
hda_edit分别提供unlock/save/lock/promote；每次先dry_run，核对plan_sha256、共享实例与丢弃范围，应用时传expected_plan。
save要求已解锁且无实例界面覆盖；promote显式把源spare提升到定义，保留已有根参数/keys/locks，拒绝其他实例覆盖。
lock对未匹配内容要求discard_changes=True及后代权限；先保存再锁定也须重新预览，不能把保存当成授权丢弃其他内容。
unlock不认领后代，不递归解锁嵌套HDA；不能通过裸HOM或拆包绕过这些边界。
成功后从新实例公共端口重验；生命周期返回值仅证明状态/文件，不证明内部几何、回调或依赖。

1. 从目标实例读 parameter_ui，确认完整类型名、实际定义库、section 与参数接口；读 hda_get_section 和关联菜单/按钮 callback。不要猜 HDADefinition 的属性名或丢失命名空间。批量磁盘盘点可在 Bridge 用只读 HOM 查询定义；将文件列表与实际检查过的定义逐项对齐，不用 loadedFiles 数量代替覆盖。
2. 普通源码读取、备份、编辑和纯 Python 导入实验使用已有 Host 文件/shell 工具；HOM 只经 Bridge。Host 无权访问时明确路径缺口，不绕过沙箱。历史结果用 result_ref 回读，不在 Houdini 里打开结果存储实现文件。修改 sys.path、写临时文件或执行未知模块不属于只读 query。
3. 拆开三类运行依赖：Python import、内部自定义节点/HDA 定义、外部文件/资源。检查与本次修改相关的入口、事件脚本和内部代码；文本无 import 不能证明动态导入或自定义节点依赖不存在。无法覆盖的范围保留 unverified。只在本机找到依赖链时，将远端缺文件、路径遮蔽等列为候选原因，不断言远端根因。

## 修改与恢复

维护已有资产默认沿用实际来源库；若来自Package，始终在该Package原库内通过原生类型版本维护，不另存到用户偏好otls、工程目录或另一个安装副本。新建/独立衍生工具的目标位置按[工具归属决策](../SKILL.md#先明确会改变交付的选择)选择：优先已有工具包，用户选择独立资产时可用工程或个人otls/hda目录；独立衍生需有对应用户意图。来源未知时回读tool_inspect的实际library与packages，不按文件名猜包归属。

**原生版本与Version元数据是两套机制**：`name::1.1`才是可并存/切换的类型版本；`HDADefinition.setVersion()`只改用户自定义元数据，不能用来冒充原生版本升级。保持scope/namespace/base，先`hda_version(node,'1.1',allow_foreign=明确原库授权)`在来源库追加已保存定义，再`hda_switch_version(node,精确新版类型,allow_foreign=明确实例授权)`切换需要维护的实例，随后在新版上修改section/界面/内部内容。旧版定义和其他实例保留。用tool_inspect的type_versions、type_version和definition_version_metadata分别回读；新建精确新版实例验证公开入口。版本创建不复制未保存内部修改；切换前先通过hda_edit保存/锁定或显式处理丢弃，不把旧内部网络带入新版。任意资产回调的外部副作用不受scene undo保证。

实例身份和共享定义/库的写权限分开。创建一个实例、知道路径或同一package归属，不授权修改其共享HDA库。新建或hda_fork成功生成此前不存在的独立库时，执行层记录当前session与库/section指纹；由受控写入刷新，外部文件或定义改变后不能沿用旧指纹。维护用户明确指定的既有定义需单次allow_foreign，且所有受影响实例仍须有对应授权；这不建立长期认领关系。

section、界面重建/增量和save/promote统一经过定义写入保护并按本次调用恢复库/定义。不能靠实例ownership、原始HOM或先写一个section绕过。hda_create拒绝已安装同名类型与已存在目标库，replace=True也拒绝，不删除共享定义和已有实例。独立制作使用hda_fork复制当前实际定义到新类型/新库，保留原实例；它不复制原实例未保存的内部修改、不创建实例或自动迁移用户内容。返回后用精确新类型创建自有实例，验证依赖与公共端口。

不写$HFS内的库，即使给出allow_foreign；Embedded定义先分支到独立磁盘库再维护。用户明确要改变原工具时先查受影响定义/实例与文件，按维护合同操作，不默认把维护转成独立新产品或整库替换。

先分清修改对象：实例普通参数用set_parms；内部网络在明确实例中通过节点/连线动词修改；定义界面用hda_set_interface；PythonModule/回调先读section，必要时在Host编辑并检查源码，再用hda_set_section/hda_patch_section写回。package外置模块在其唯一源码处修改，独立验证后再按授权加载。不要为一处section修改重建整个HDA，也不直接解压/改写.hda二进制。

维护已有库前确认实际定义文件、同类型其他实例及package归属。用户要求维护指定工具时，以原库追加新类型版本完成，allow_foreign只描述本次明确范围。需要隔离验证时可用临时工作副本，它不是交付/安装来源，不能加载到live抢占同名定义；最终仍更新原库。新实例/副本不自动继承原节点ownership。

用现有计划简记目标文件/类型、受影响入口、依赖和下一验证即可。保留唯一源码来源：由源码生成内嵌 section 时同步构建入口，避免下次生成还原旧转发器；不把手工 section 与外部源码当成两个互不关联的权威版本。

- 修改 foreign 定义需针对用户明确目标的单次 allow_foreign；临时实例不授权修改无关共享库。
- 写前备份目标库，并离线编译要作为 Python 执行的代码。hda_set_section 的语法预检只覆盖 PythonModule，不自动识别任意命名的嵌入 section。首次整模块替换用 hda_set_section；局部修正先回读并用 hda_patch_section 的唯一锚点，不全文重发。
- 多section更新先核对依赖，最后切换入口；逐项section写入不是整库原子事务。hda_edit的save/promote与界面重建拥有本调用的定义/根界面/通道/库恢复，定义写入与场景Undo隔离，后续exec失败不撤销已成功的库写入。恢复失败会显式报告，任意回调/进程/外部文件不在保证内。
- 修改定义可能影响所有使用该定义的实例。临时节点 finally 清理不证明 selection/display/render flags 或 dirty 状态未变；需要声称保持时须有前后观察。

## 实例控制提升与定义保存

适用于用户已明确要求HDA，且普通子网的spare控制要成为资产公共接口。hda_create返回pending_spare_parameters/count；实例有参数而定义没有时，先读hda_edit帮助，在已授权的全部受影响实例范围内preview unlock（仅锁定时），再preview promote并以对应expected_plan应用。原地提升保留已验证网络，不能默认delete/replace整型。已有定义接口的局部修改走增量接口，不把promote当任意模板迁移器。

各模式hda_set_interface dry_run返回ok=true、dry_run=true、applied=false、scene_writes=0；应用成功才返回applied=true。实例内部内容与磁盘定义分别回读：后续内部建模完成需hda_edit(save)，再创建新实例验证控制与公共输出。matchesCurrentDefinition为false本身不证明保存失败，lock的discard_changes保护保持有效。

机制入口为H21/H22的dsh-authoring-contract与dsh-hda-lifecycle回归；不覆盖未知第三方回调副作用或自然任务采用。转换后不可通过路径/tag认领未知后代；原生身份接续限工具执行契约的有界受信转换。

## 同层验收与停止

先做最便宜的代码/section 回读，再验证受影响的公开入口和实际结果。重复失败没有新信息时确认失败位于定义加载、回调上下文、业务函数还是输出层，回到已通过的层查 verb_help/实际接口，不继续猜拼写。

| 改动/承诺 | 对应证据 | 不能替代它的检查 |
|---|---|---|
| 菜单默认值或按钮修复 | 全新实例保持默认值，经真实 HDA module/回调入口调用；核对菜单 token、参数实际值与业务结果 | 手动 exec 源码后只调用内部 helper |
| SOP 输出正确 | 在 exec 中 cook 明确交付 output，检查 errors/warnings、非空几何、任务相关属性/分支关系 | 节点存在、分支数量、未 cook 的 errors() |
| 同步/替换操作 | 在隔离夹具执行实际替换，核对目标范围、参数保留、输入输出连线与清理 | 加载器成功、函数存在、纯函数抽查 |
| 无外部包、可移机 | 在无原包路径/模块缓存的隔离目标环境，只安装交付 HDA 及声明依赖并运行实际入口 | 合成模块的 __file__、本机正常、扫描无包名 |

默认空值、明确失效 token、用户已选值分别验收；菜单显示标签不证明底层值已写入。只修新建空值时不要自动扩大成失效选择的静默替换。选择适用反例：无输入、无属性、多个属性、class 切换、已选属性消失，且确认失败没有留下未声明的写入。

测试副作用操作使用隔离场景和自建夹具，不能以“验收”为由运行会改用户现有网络的任意按钮。弹窗妨碍自动测试时隔离通知层、保留业务入口；如果只能测内部函数，明确入口未测。没有受控 callback 动词不等于允许绕过已有 Raw Gate；无法安全执行的路径保留 unverified。

另启hython进程不等于环境隔离：继承用户偏好、Package或Python路径仍会抢占同名定义、提前导入真实SDK。交付入口验证优先使用下述hda-delivery-check，它创建隔离偏好和搜索路径；自建夹具也使用同源houdini_test_environment，仅声明本次依赖。先核对实例实际library与目标文件一致，再判断业务结果；不能靠反复setIsPreferred掩盖测试环境污染。模拟CGT等外部服务时明确模拟边界，离线通过不证明真实账号/字段API可用。

最后回读实际文件路径/hash/大小和依赖清单，给出已测版本与未测范围。简单功能维护无需艺术渲染或动画验证；任一核心承诺缺证据就按部分完成交付，不以 todo 清零补证。

## 证据与验证入口

作者交付测试可使用包根tools/hda-delivery-check.py：普通Host进程传manifest和目标hython，
复制声明HDA/Python目录后在独立进程创建新实例，测试真实按钮/动态菜单及显式参数或SOP输出判据。
manifest格式和调用见仓库docs/development.md的“HDA交付检查器”；回归入口为
tools/tests/dsh-hda-delivery.test.py。只运行获授权的可信资产，不把进程隔离当不可信代码沙箱。
H21/H22的pressButton可能只向原生stderr报告异常；不能只以返回无异常判成功。
检查器拒绝子HDA定义来自未声明开发路径；GUI/Shelf/快捷键和动态依赖闭包仍未验证。

`tools/tests/dsh-hda-lifecycle.test.py`在H21/H22用普通几何HDA和重复参数界面验证preview/save/lock/promote、
过期/foreign/Raw Gate拒绝以及写后失败恢复；这是机制证据，不证明未见自然任务采用或已部署。

来源：仓库 `houdini/python3.11libs/dsh_hou_helpers.py` 的 HDA section 实现，以及 `docs/execution-contract.md` 的恢复边界与证据分层。本路径提炼自一次真实 HDA 维护审计与已有同层验收合同；不携带用户资产代码、路径或专有类型。
证据等级：E1 工作流候选；目标是 H21/H22，尚缺新 session 的未见 HDA 任务行为验收。原实例内部函数测试不证明新路径已采用，也不证明跨版本已通过。
下一验证：隔离目标环境的依赖完整正例、缺子 HDA/实际入口失败反例、全新动态菜单实例，以及普通参数编辑不触发完整部署流程的反例。源码/提示加载与自然任务效果分别判断。
