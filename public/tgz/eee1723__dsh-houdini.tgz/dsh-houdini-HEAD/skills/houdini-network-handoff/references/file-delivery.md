# 文件与图片交付

节点导航归本skill，文件使用DSH `present`。先核对实际文件与必要依赖，再发布权威路径；Session workspace可能不同于$HIP。HDA、HIP、贴图、缓存或脚本各自说明使用和加载条件，不把其中一个存在当成整项完成。

## 工程命名与保存

任务包含保存或交付工程时，默认在当前工程目录另存本轮成果，保留用户原文件。用户明确指定文件名、目的地或要求原位保存时遵从其要求。已有保存授权允许按以下规则确定目标，不为可自行判断的命名重复询问；未命名工程使用用户任务明确的目的地，不猜测无关目录。

- **有意义的工程名**：保留项目、产品、镜头或资产名称及业务编号，只递增版本。沿用已有版本格式；没有版本时追加`_v001`。例如`Desk_Lamp_v007.hip`另存为`Desk_Lamp_v008.hip`，`Desk_Lamp.hip`另存为`Desk_Lamp_v001.hip`。编号、日期和型号不自动当作版本号。
- **明确的临时名称**：未命名场景或结合任务可确定无业务含义的占位名，可改成简短、能辨认成果的名称并追加版本。不确定含义时保留原名；名称短、含数字或使用中文都不是改名理由。
- 核对同一工程的已有版本，选择下一个未占用的版本路径，保持当前许可对应的HIP扩展名，不为取名覆盖已有文件。同一轮选定新版本后，过程保存继续写入该版本；不是每次保存或每条消息都生成一个版本。

另存用`scene_save_as`，`expected_current_path`来自最新`scene_info().hip_path`，`reason`记录实际任务授权与目标；保存本轮版本用`scene_save`。消费真实保存回执再发布文件。跨目录另存后，等下一模型步骤接续工程目录，再重新读取`project_layout`用于后续文件；Save As不自动搬运贴图或缓存，需要迁移时核对实际依赖与引用。

## 直接交付与使用说明

默认直接呈现HIP、必要依赖和需要的说明文件，用户可以在工程目录中打开和继续编辑。只有用户明确要求压缩包时才创建ZIP；不为普通交付增加压缩、解压或另一份工程副本。

需要独立使用说明时，默认写可在浏览器直接打开的UTF-8 HTML，不交付Markdown说明文件。正文用用户的语言，围绕对应工程版本、打开入口、常用控制、必要依赖和已知限制；内容随当前成果更新。简短操作在回复和节点注释中已说清时，不强制生成文档。用户明确指定其他文档格式时遵从其要求。

说明及其专用图片放在`scene_info()['project_layout']['directories']['documentation']`（默认`$HIP/dsh-artifacts/docs/`），按需要创建；说明可用对应HIP的文件主名命名。HTML声明UTF-8，采用简单离线排版，以相对路径引用本地资源；已有贴图和成图保留原位置。写完核对文字与本地引用可用，再`present`实际文件。用户指定目的地优先，现有文档不自动搬移或删除。

后续版本以当前成果能独立接手为目标：主入口说明、必要依赖和最终消费者对应本次保存状态。新增模块可以有专项说明，但用户应能从当前主说明找到全部常用操作，无需拼接旧版本说明。仅维护本次需要的文档，不把过程记录和旧版本全部追加到交付中。

## 路径、图片与清理

工程目录按用途统一，实际位置读取`scene_info()['project_layout']['directories']`：网络参考使用`reference_downloaded`，生成辅助参考使用`reference_generated`，材质依赖使用`texture`，几何/模拟/通道缓存使用`cache`，教程与任务分析使用`analysis`，使用说明使用`documentation`，成图使用`render`，过程检查使用`visual_check`。目录角色与生命周期合同见[工程文件](../../../docs/project-files.md)，不要另建资料清单来替代原始来源或DSH回执。自动输出返回实际路径后再交付；不因另存为而移动历史图片或重写旧卡片。

需要交付视觉结果时，给用户已经核对的整体图和必要局部图，避免只交隐藏工程。`render_view`针对明确SOP结果，`viewport_screenshot`针对SceneViewer当时显示，`houdini_ui_screenshot`针对明确界面的当前实际显示；用途不同，不互相代替。已有表面的选择与捕获边界见[通用界面观察](../../houdini-tool-development/references/evidence-and-validation.md#观察实际工作界面)。

最终图片用`output_policy='delivery'`生成到已命名HIP旁的`dsh-artifacts/renders/`，消费回执的实际文件后再present。picture只传安全basename，分配器追加frame/capture标识，不猜文件名。普通managed观察图在`dsh-artifacts/checks/previews/<run-id>/`，不自动全部交付。未命名HIP的临时UI观察可用explicit绝对路径；不为截图强制Save As。

```python
__result__ = render_view('/obj/example/OUT', picture='overview.png', output_policy='delivery')
# 核对返回的实际文件及图片内容后，通过DSH present声明该路径。
```

正式ROP图片可在渲染前选择`$HIP/dsh-artifacts/renders/asset_final.png`；临时picture覆盖不证明持久ROP设置已保存。已有用户目的地和ROP优先，不为统一目录默默重设。无识图能力时不能宣称视觉通过；用户需要的图片仍可交付并注明观察范围。

检查用途由意图决定：采样、法线、透明通道、显示异常和测试渲染的对照图使用visual_check。`render_frame`做诊断时显式指定`picture='$HIP/dsh-artifacts/checks/previews/<task>/check.png'`，不要因为它叫render就写入dsh-artifacts/renders，也不要为了“稍后可能交付”提前把每张检查图声明为delivery。视频抽帧等资料仍随教程放入analysis；建模过程的图像诊断不混入教程/Trace报告。

图片在聊天中看起来异常，而网络或几何检查不能解释时，可先核对原文件、图像通道和实际模型输入；必要时生成同取景的不透明对照图，再决定是否修改几何。文件可读、通道正常或某次模型描述都不能单独证明几何正确。

已发布卡片指向源文件，不复制内容。移动、删除或改写源文件会影响历史入口；明确迁移时核对新文件并发布新路径，不重写历史回执。

任务内收尾只处理本次创建、确认不再用于运行/恢复/交付的明确临时探针、画稿和图片，保留依赖、参考、在途捕获和执行归档。普通文件用DSH通用文件工具，Houdini对象用Bridge动词。未知来源保持不动，不建立另一套交付或清理账本。
