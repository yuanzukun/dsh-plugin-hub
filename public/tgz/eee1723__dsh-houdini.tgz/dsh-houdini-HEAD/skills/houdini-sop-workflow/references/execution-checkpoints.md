# SOP构造与验收边界

按当前阶段查阅；工具能力与当前预算以verb_help为准。

## 构造与检查的选择

表示的默认偏好与例外统一见[建模方法](modeling-methods.md#1-从表示和构造选方法)，工作顺序按当前问题选择。
算法离线验证只能说明算法原型，涉及Houdini的结果仍要在实际网络cook和观察。

复杂装配可用整体代理或高风险局部原型尽早发现比例、接口与构造问题；已有工程从受影响的部分开始。
读取陌生节点的`node_info`及实际构建反馈，按风险补充参数、选择范围或形体检查。
模块划分、共享控制和集成观察见[模块资料](module-quality-contracts.md)；不要求固定的阶段顺序。

Boolean按输入的Solid/Surface前提、接缝、朝向及实际切除结果判断。实体孔道可以用
`axis_passage`检查声明孔轴，孔径可用`bore_clearance`检查被穿透板厚区间的空域；
两者的范围由真实部件决定，整件包围盒不是板厚，工具结果也不替代孔壁和闭壳观察。

交付需要清楚的最终输出；非平凡网络可用`OUT_ASSET`等稳定名称。Subnet/HDA公共接口
使用原生Output明确发布，内部Null和display/render旗标不能代替公共端口。
网络布局按规模和用户接手需要采用[网络交接skill](../../houdini-network-handoff/SKILL.md)，短链无需套完整布局。

## 执行与恢复

- 自写旋转矩阵先用非零角验证pivot不动及离轴点方向，再复制/接入整机；活动件控制须在最终输出复查与固定承接件的接点，整件bbox响应不证明连接。组、状态及失败边界见[模块合同](module-quality-contracts.md#控制契约改变什么什么必须不变)。
- 创建、接线、设参和局部源码修改的调用示例集中在[fast path](sop-patterns.md#9-小模块构建与检查-fast-path)；实际签名和返回类型读verb_help，节点菜单与组件名读node_info/list_parms。输入预检和advisories不证明几何正确，也不替模型选择构造。
- 消费transaction的最终状态；同批后方失败可能撤销前方修改，不沿用已回滚的依赖。恢复范围外的文件、库和Python副作用另行判断；节点名相同不证明身份或状态相同。批次划分依据工作能否独立保留，具体方式见fast path。
- 重复失败而没有新信息时，回到最后有效输出缩小诊断范围或换方法；修改/cook异常先读恢复事实，恢复未确认时保留停止状态并在新批次修复。比较实际输入、参数回读、选择成员及输出，不用总数相同推导选择失效；换方法成功不能证明原生节点有bug。
- 节点替换前记录输入、输出消费者及参数引用；删除结果中的受影响连接必须回读并显式重接。
  同名新节点不继承旧接线/控制证据；对最终OUT做控制扰动，避免孤立形变节点和旁路控制。
- 填充、镜像、细分后检查表面面积、边界与重复覆盖。闭合Polygon已可为面，不能再填一层后仅按
  点数/cook通过；geo_piece_stats(inspect=True)的平面闭壳/重合边界诊断是风险线索，不自动认证实体有效。
- 已通过的独立模块及时保存，不把所有持久化推迟到最后；未知高成本循环先隔离验证，超时不等于原生方法有缺陷。
- 记录当前输出、实际状态、受影响修改和下一动作；复杂要求使用DSH计划或工作区文件。继续修改时回查原始材料与新增要求，只更新受影响输出和检查。
- 平铺模块提升为Subnet时核对输入、输出消费者、控制与接口，按现有权限和可恢复范围选择迁移方式；依赖复杂或用户需要保留原结构时，建立候选公共输出并验证后再切消费者。容器变化不自动授权HDA升级或component导出。

## 外部代码依赖

维护较长的建网脚本时，用函数组织原生节点和共享接口；脚本是施工方式，不要求把最终几何集中到Python SOP。已有网络继续维护其有效编辑入口。
代码文件与现场snippet选择一个当前编辑来源。由文件更新节点时，先用`read_parms(node,names=['snippet'])`取得现场`source_sha256`，再以`set_parms(node,{'snippet':{'expected_sha256':记录的现场hash,'source':完整文本}})`同步。文本可通过`open(path,encoding='utf-8',newline='').read()`保持原换行；回执给出前后hash，不重复整份源码。已有局部补丁仍适用。过期hash说明现场发生过变化，应先核对/合并，不能重读hash后直接覆盖来消除冲突。明确采用现场编辑时更新受影响源文件或说明旧脚本已非重建入口，不维护两份互相矛盾的权威源码。外部文件不随场景Undo恢复。

普通单个HIP中的局部VEX默认保存在Wrangle内；多个消费者确需共享算法、用户要求源码库或脚本工具时可使用工程内文件。
文件编辑负责源码，Houdini工具负责现场创建、设参、计算与检查；写文件成功不证明当前节点已经使用新代码。

- 外置include是运行依赖，路径锚定工程；编译后的节点可能继续使用旧代码。改库后观察一个能区分新旧行为的输出，
  必要时通过节点参数触发重新编译，再检查受影响消费者。`cook_node(force=True)`不等于必然重编译include。
- 文件位置与节点参数求值路径不同；Wrangle的`vex_cwdpath`含义和默认值读节点卡，不能拿它配置文件搜索目录。
- 交付列出并提供实际需要的文件。声称可搬移或重开时，在授权的独立副本/会话验证路径与重新计算；未验证就说明范围，
  不为验证擅自重载live。文件修改不随Houdini场景Undo回滚，失败后按实际文件与场景状态继续。

## 观察与关键方法

大型最终输出的`geo_check_interfaces`会按声明的primitive关系组取证。`test_controls`需要每项指标有明确`group`且关系/拓扑都有primitive组，才能使用相同的有界采集；量测仍来自最终输出，恢复核对覆盖整件bgeo，未选部件漂移也不算恢复。读取`geometry_scope`区分来源总量、实际选中量及未测范围。不要为了通过预算改测driver或换成较容易通过的指标；点到面合同和无group的整件指标仍保留原范围限制。

- geo_piece_stats默认按连接性或指定身份属性统计局部extent/面积；inspect=True观察命名primitive组的Polygon边界/边连通/非流形和basis下extent；shell_orientation保留有向体积条件。半径用到轴的欧氏距离，轴向投影不是半径。observed仅量测，分组切口可有意开放。
- geo_attrib_stats读驱动属性；复制前用unique=True检查模板P/id的精确tuple唯一性及预期基数，bbox不变不能排除重叠复制。geo_point_spacing只测有序点弦长。test_controls位移/变换误差要求稳定唯一id_attrib和相同面连接；选中件及其附属件查同一预期变换，未选中件查identity，见[模块合同](module-quality-contracts.md)。混合网格点均值不是设计中心，native/packed不靠P-only。
- Copy to Points承担实例变换，模板orient/scale与原型局部轴需一致；Copy/Merge明确属性class和传播。带状物用有面积截面，非刚性成形通常先作用中心线/低维结构再生成厚度。细节见[方法参考](sop-patterns.md)。
- 需要选择基础成形方法、局部倒角/分组或高细节细化时读[建模方法与细节预算](modeling-methods.md)。不要用纯VEX比例或节点数评分，也不能因调试失败悄悄放弃用户指定的方法/结构。需要文件复用或显式替换时读[模块文件与复用](module-design-collaboration.md)。场景构建与收尾由当前作者完成，不借allow_foreign或共享身份绕过ownership。
- 跨OBJ汇总实际装配时显式处理Object Merge坐标空间；要保留场景放置就使用`Into This Object`等价模式，local-space合并只在有意忽略OBJ变换时成立。用于关系或渲染的代理需核对实际成员、变换及world bbox；warning按属性用途与下游影响判断，见[属性传播](sop-patterns.md#4-属性传播)。
- 每图绑定问题和部件。render_view用focus_group/isolate选关注范围；full保证完整入镜，detail仅允许画框裁切，不允许近远裁面切断。framing_bounds在full中不是局部ROI。A/B同时复用framing.bounds和framing.depth_bounds（全部渲染内容）及方向/画幅/模式；深度或完整构图越界零渲染失败，不漂移相机。普通预览不必创建正式相机调用camera_fit。
- 消费render_view.check（pixels兼容别名）与framing.depth_check；看到断口先排除深度裁切，不能用拓扑pass或不同条件的图确诊着色问题。空白、近黑、错误目标不通过；detail有意裁框仍须读图确认所需局部可辨认。直接查看工具结果中的原生图像附件，先描述事实再核销疑点；遮挡不等于缺件，无地面参照不能断言接地。
- viewport_screenshot只用于SceneViewer实际显示；参数/网络布局判断分别读参数UI/网络交接skill，当前Spreadsheet或其他工作界面的捕获按[通用界面观察](../../houdini-tool-development/references/evidence-and-validation.md#观察实际工作界面)选择可见目标。模型本体优先render_view(明确最终SOP)，复用版本原生低成本后端与持久__dsh_houdini_*服务。两者默认managed，把验证图放进`$HIP/dsh-artifacts/checks/previews/<run-id>/`；只有用户明确要交付路径或隔离测试自管目的地时才传`output_policy='explicit'`，不得为方便把agent预览散放HIP根目录。原型和最后一次相关修改后各检查必要视角，关键接口看局部，不对每次无关调用重复追图。纯查询/改名/无可见变化的维护不强制预览；无GUI、预览/识图失败或用户明确禁止时报告具体限制与视觉未验证，不默认改走Karma。未请求成品图片不是省略建模视觉验证的理由。
- 动画至少两个相隔帧的实际几何/固定构图图像证据；A/B同framing_frame且覆盖帧包络。完全静止/方向错误是反例；细微审美无法裁定交给用户播放判断，不无限追图。

## 完成范围

用户给出物理尺寸时，先核对图纸端点所属零件与尺寸性质，再将少量决定构造的外形尺寸
用最终零件primitive组的`geo_check_interfaces(method='physical_extent')`声明毫米值、轴和误差；
最后一次几何修改后复验，失败不能由健康cook或整件包围盒覆盖。该检查不证实图纸归属或组完整。
整体包络另读最终`verify_network.geometry.bbox_size`与`bbox_size_sop_local_mm`，
计入OBJ变换；bbox_min/max是端点，不能单独当跨度。

声称“轴穿过铰耳”等真实通孔时，在复制/装配前先检查单个闭合零件的孔道；
最终同一SOP中的完整闭合实体组可用`geo_check_interfaces(method='solid_overlap')`
查轴与铰耳是否占据同一空间，再分别查同轴与孔壁间隙。活动状态在
`test_controls`各case中复查；组开放或只截了部分壳体时保留unverified，
不能把零交集单独说成已穿孔。

复杂产品收尾对照原要求、新增需求与当前输出，区分计算、表面、结构、控制与视觉证据，见[检查与所声称的性质](procedural-quality-contract.md#检查与所声称的性质)。显式输出的error或意外空结果需修复；warning按实际影响处理，保留有用身份与分组。必要时从`houdini_resource`读取原始资料和完整回执。带锁扣、铰链、密封等接口的产品，在所测状态检查任务要求的连接、对齐或分离，不能拿bbox或零件一起移动代替。用户明确要求真实密封、受力或传动时另验相应物理/功能关系；普通设计模型不因未请求的性能未验证而判失败，有意的几何预压可作为结构示意，但相交体积不证明密封压力。缺少要求的部件或关系证据时明确缺口，不臆测是用户或GUI改动。关键控制应通过共享依赖维护，不靠重复修改多个VEX常量。

近看交付的Polygon产品件，按当前观察问题用`geo_piece_stats(...,inspect=True,integrity_only=True)`显式检查源模块或最终输出；`verify_network`只负责计算与非空状态，不按输出名称追加表面检查。出现风险或unverified时按部件组定位。非流形、零面积、零长度、重复面和反向闭壳不因cook无warning或出图而消失；开放边按接口解释。几何检查与接点、造型、视觉各有观察范围。相关修改后更新受影响的关系、控制和图像结果；控制失败修正后须在同一最终输出重测对应case。

给用户交付时先说模型在哪里打开、能改什么、实际检查了什么、哪些地方仍是示意或没查。`healthy`表示所查范围可正常计算，`warning_free`表示该范围没报warning，两者均不证明造型正确；`restored`表示恢复了工具明确覆盖的状态。精确节点名、数值和错误留在技术补充中，不能为了好懂而省掉影响结果的失败。

收尾由当前作者完成输出、关系和控制检查，复用已有工具事实与原生图像；核心未验证项如实保留。
