# 实际输出的模块质量合同

## 适用与边界

适用：多部件SOP装配、带明确连接端的模块、需要用户调参仍保持连接的资产。
不适用：简单单参修改、纯骨架/调试helper交付、模拟求解器、文件写盘或带外部副作用的控制；
不把本流程强套到所有场景。版本：H21.0.440/H22.0.368工具回归；自然弱模型增益待新会话。

## SOP模块的集成观察

任务粒度、依赖、局部反馈和推进由[任务拆分skill](../../houdini-task-decomposition/SKILL.md)维护；重复对象的完整源与布局见[组件构造](modeling-methods.md#完整源组件与布局)，共享控制、引用及容器选择见[逻辑模块](modeling-methods.md#逻辑模块与容器选择)。这里维护实际SOP输出的成员、空间、接口与控制证据，适用于同层分支、Subnet或HDA中的相应输出。

按当前要求明确待检查部件、观察距离、允许简化、连接面/轴和间隙；结果关联实际输出及调用引用，已测和未测范围分开。局部完成与集成正确分别判断，不要求额外表单。

集成先由需求与当前控制状态导出期望成员及基数，再确认这些声明部件在实际最终输出中非空且基数一致，最后复验变换后的关系。不能以最终输出里幸存的组反向定义期望集合。源模块可cook、
build_module.required_outputs通过，只证明源分支存在，不能证明下游Switch/选择/Merge还包含它。
代理体与正式模块保留可区分身份；替换代理后复核最终成员，不能让代理继续填补正式部件的缺失。
Packed外壳非空不证明内容非空或部件齐全；verify_network只验证有实际内容，成员/基数仍从交付几何另查。
模块接口同时声明local/world空间、up/forward轴和rest/current状态；正式新建的普通Houdini交付从首个源/骨架开始使用世界Y-up（X宽、Y高、Z深），不把根旋转当默认建模步骤。复制只接受约定的局部原型，世界空间附件不能再次套实例变换。旧工程或确有独立局部frame的模块使用Z-up时，在父装配的稳定`OUT_ASSET`之前只做一次显式local→world适配，并在适配后的真实输出上重测世界包络和接地；`OUT_ASSET`之后的Transform旁路不是修复。
共享运动控制的附件必须消费同一当前状态，静止位置公式通过不能替代运动后的连接。
自写刚体旋转矩阵先在一个非零角做最小反例：声明的pivot经同一实际应用函数变换后必须保持原位，另选一个离轴点确认旋转方向；不满足就停在局部原型，核对矩阵存储/乘法约定或改用原生变换，不复制到整机。此检查只挡住错误变换，不能替代最终几何接点。

观察色只承担接手和视觉分辨：优先由稳定`part`/piece身份在装配末端派生`Cd`，同组件一致、不同组件可辨认；不要把节点路径、primitive序号或拓扑偶然顺序当颜色身份。若输入已有用户颜色、材质或下游lookdev合同，默认保留并改用隔离预览/分组观察。`Cd`存在或画面颜色不同不证明部件存在、关系正确或材质交付完成。

后续修改先回读目标：接口/共享控制变更使相关邻接检查失效；计数、组、拓扑或输出身份变化还会使旧成员范围和接口合同失效。证据需绑定输出身份、frame、相关参数及可用指纹；内部细节变化至少刷新本模块及实际受影响的集成证据。
用graph及已记录execution影响提示缩小范围，未观察的动态/外部依赖仍需核对。不能从路径未变推断身份或证据仍有效。
续接时读取原要求、当前输出和新增资料，保留未满足项；要求理解与检查选择见[质量合同](procedural-quality-contract.md#检查与所声称的性质)。
历史pass和任务摘要均不赋予foreign修改权限。

机制验证：仓库`tools/tests/dsh-module-integration.test.py`覆盖局部通过但集成漏件、局部坐标正确但实例脱离、
共享控制联动/恢复以及独立已提交模块保留；`tools/tests/dsh-output-publication.test.py`覆盖公共输出/内部显示分离、
多端口、foreign拒绝与空Packed内容。它们不运行LLM，不能证明自然任务的模块聚焦行为或美术质量提升。

## 构建前：选择接口，不发明一个“正确”布尔值

先按表示选择方法：两个仍独立的表面用下述interfaces距离合同；Boolean融合后的共享表面用
`test_controls`的`topology=[{id,groups:[部件primitive组,...],require_closed:true}]`。后者检查共享
边连通、闭合与非流形/朝向问题，当前仅Polygon，不证明自交、强度或目标形状；至少两个
非空且不重叠的部件组。`test_controls(...,topology=...)`在基准及扰动输出复查它。
未焊接但空间接触的两部件不能用共享拓扑证明；融合缝也不能用“共享点到自身距离0”自证。
更换方法时保留用户要求的连接义务；当前数据不能自行决定哪些部件必须交付。

一个模块至少明确输出、连接位置/轴向、共享控制与允许连接误差。生成几何使用同一接口作为
位置来源；另在实际最终表面保留可识别的组。point group选连接端的表面顶点，primitive group
选对方实际接触区域，不选整个场景；不能放几个无关driver点冒充最终几何。

适用时把这些组随Copy/Merge一路传到交付OUT；顶点数改变后更新明确基数，不静默接受空选择。
组名来自当前任务，不由库固定。一个模块可以有多个出口/接口，每个需独立检查。
原型通过不能代替复制/变换后的实例关系。最终输出保留可选择的部件身份和接口组；附属件
随主体一起移动只证明共同运动，不证明二者连接。先验证原型内部连接，再检查各实例的外部接口。

## 最小执行路径

```python
interfaces = [{
    'id': 'mating_interface',
    'source_group': 'port_vertices',
    'target_group': 'receiver_surface',
    'expected_points': 4,
    'max_distance': 0.001,
}]
# spec自行生成；必须包含这两个属于真实表面的命名组。
result = build_module(parent, spec, output='OUT_MODULE', interfaces=interfaces)
```

上述数值仅展示schema；容差、点数要由单位/连接要求与实际构造决定，不是所有任务的固定标准。
`dry_run=True`只预检声明，不能证明几何接口。正常build会在最终输出检查接口；fail或unverified
使该新增模块失败并清理本批节点。修改已有节点后，用 `geo_check_interfaces(out, interfaces)`
再次读取实际结果；它是诊断返回，不会替你修模或强制完成。

检查含义：全部source表面顶点到指定target表面的最近距离须不超过容差。
支持target为closed Polygon、Mesh、Sphere、Tube；source必须是polygon/mesh表面顶点。
嵌入PackedGeometry经有界内存展开；外部Packed/volume/NURBS等未支持表示返回unverified。超点数/内存/查询预算拒绝，不抽样假绿。
这个检查**不证明**整个表面无穿插、包含深度、焊接、机械强度，也不能把方向平行当成连接。
需要插入或实体相交时应选择对应独立方法，不通过放大max_distance来使错误结果变绿。
顶点对顶点的最小距离是完整表面最小距离的上界，不是安全间隙下界；面中部相交时顶点仍可远离。
源顶点到真实目标表面也只覆盖这些样本，不证明连续全表面无穿插。要求贴合时检查指定接口的
全部声明样本；要求无碰撞却无适用检测时保留unverified。独立装配允许经设计确认的间隙，
不因没有共享点就强制Fuse/Boolean，也不把封闭且朝外的各部件当作装配关系已通过。

## 控制契约：改变什么，什么必须不变

### 实际表面组的轴向间隙（v12）

上下叠放/沿轴布置的部件，可用最终输出primitive组计算投影间隙，避免重复构造公式自证。
例如声明source为上方部件、target为下方部件：

```python
relations = [{'id': 'stack_projection', 'method': 'axis_gap',
              'source_group': 'upper_surface', 'target_group': 'lower_surface',
              'axis': 1, 'gap_range': [-0.001, 0.001], 'min_overlap': 0.01}]
measured = geo_check_interfaces(out, relations)
# 同一关系可以进入参数扰动窗口，在基准与每个case上复查：
tested = test_controls(controller, out, tests, interfaces=relations)
```

数值仅示schema，范围按设计单位明确。量测是source.min[axis]−target.max[axis]；正数为分離，
负数为轴向投影重叠。另外两轴区间重叠须≥min_overlap。曲面bbox相接不证明表面实际接触，
需要真实接触时再加适用的点到面接口；不用于任意弯曲榫接、实体穿透深度或强度认证。
source/target必须为实际交付中的非空且互不重叠primitive组；不得临时加入driver点伪造表面。
观察→参数扰动→关系复查→完整恢复应在test_controls内完成，不能以恢复了几个bbox替代bgeo恢复证据。顶层`interfaces`是基准和每个case共同成立的静态合同；`baseline_interfaces`只验基准；每个case的`interfaces`只验该扰动状态，适合接触变分离等状态转换。三者都是明确列表，不执行回调或自动猜成员；若计数变化后无法为新状态声明完整选择和基数，就拆成有明确范围的受支持检查，未覆盖部分保留unverified，不能删expected_points或只测旧固定子集。

从控制的实际含义选择输出部件、测试状态和适用指标，再填写test_controls所需的metric与有符号delta区间。
优先测相关primitive group，避免整体bbox掩盖局部变化；相互依赖的控制再选择少量组合。
参数响应只证明所测性质，已测与未测范围分开报告，结构语义的选择见[检查与所声称的性质](procedural-quality-contract.md#检查与所声称的性质)。
有活动件的控制还须在最终输出上声明它与固定承接件在各要求状态的实际接点或允许间隙；基准接触与打开分离分别放入`baseline_interfaces`/对应case的`interfaces`，不把活动件自身的位移或整件bbox变化当作连接通过。若当前组/方法无法量测，保持该关系unverified并靠清晰近景复核，不能填一个预期大位移窗口使明显脱节变绿。
报告关系时说明对应控制状态及实际interface结果；不能将一条基准测量用于“全部开合状态”。控制响应与部件关系分别判断，两者不互相替代。

```python
tests = [{
    'id': 'length_response',
    'values': {'length': 1.2},
    'expectations': [{
        'group': 'driven_part', 'metric': 'bounds_size', 'axis': 0,
        'delta': [0.199, 0.201],
    }],
}]
report = test_controls(controller, out, tests, interfaces=interfaces)
```

示例基准length为1、单位米且输出长度一比一响应；实际参数/目标变化由任务决定。
metric精确为bounds_size、bounds_center、bounds_min、bounds_max（axis0/1/2）、point_count、primitive_count、area；不接受center/min/max缩写。
v11另支持point_mean（axis）、boundary_edges、piece_count（Polygon共享边连通）、max_point_displacement/mean_point_displacement。
位移必须提供id_attrib：稳定唯一integer/string point ID，面连接在ID空间保持一致；对应关系变化返回unverified。
已知变换的控制可附max_transform_error，提供同样id_attrib、实际primitive group和transform（16数row-major仿射矩阵，Houdini行向量约定，SOP-local空间）。它测量全组真实点相对`P_baseline * transform`的最大残差，baseline残差定义为0；delta/range使用设计容差，另加一项非零位移响应。将主体和附属件声明为同一变换，未选中组声明identity，可检出“主体动了但附属件不跟随”。它不是拟合当前结果来反推正确变换，也不证明全部姿态/碰撞；混合几何的点均值不能当设计轴心。修改生成器后需重新建立基准。
expectation可带range=[min,max]检查基准及扰动绝对范围，例如封闭面的boundary_edges要求range=[0,0]、delta=[0,0]；
单纯delta=0不能证明基准已闭合。仍需至少一条响应delta排除0；有意分组切口不能无条件要求闭合。
每case至少一个delta区间必须排除0以声明实际响应；不变量可作为额外expectation。
这是数值标量测试，只传组件名，不直接传元组、菜单、按钮、multiparm或callback控制。
测试值被范围钳制而未按要求生效时判失败，不把未真正执行的case计为通过。

需要控制前后视觉对照时，先确认当前模型图像能力，再在`test_controls`中传`views`；可用方向以`verb_help`为准。
工具先拍基准，再让各case复用该方向的取景/深度包络及同一`framing_frame`。运动会超出基准包络时，提前用
`view_bounds=[world_min_xyz,world_max_xyz]`声明覆盖基准和所有测试状态的世界空间范围；它同时约束取景与深度，
不让每个case重新对焦。越界、基准出图失败或无GUI时截图保持未验证，不改变数值检查的含义；消费
`baseline_captures`、各case的`captures`及`capture_status`，数值pass不补成视觉pass。固定构图只保证可比观察条件，
仍须当前作者实际读图检查连接、方向与局部形态；截图和附件送达都不证明语义正确。

每个case先改值/cook，再测指标与接口，最后恢复原值、表达式、关键帧、frame，并核对实际
output完整bgeo解码数据恢复：排除导出头date和派生group_summary，已知组目录按组名规范排列；
保留所有组成员、ordered group内部顺序、用户属性及几何。原生Tube/Sphere半径不靠P-only判定。控制测试当前仅支持
Polygon/Mesh/Sphere/Tube、点几何及预算内的内嵌PackedGeometry；外部Packed、NURBS、volume等在写参数前返回unverified。
内嵌PackedGeometry的临时地址规范为递归内容标识，实际载荷/属性/变换仍完整比较；不使用未经规范的原始bgeo hash判断恢复。外部Packed等未支持表示仍写前unverified。
恢复失败必须停止继续改场景并检查，不自动抹掉错误；无法测量的类型保持unverified。
文件I/O、Python/solver状态、未声明外部回调不属参数恢复范围，不要对此类控制运行测试。

实体通孔的最终轴线可声明 `{'id':'mount_axis','method':'axis_passage',
'target_group':'final_housing','axis':2,'start':[x,y,z0],'end':[x,y,z1]}`，
在 `geo_check_interfaces(OUT_ASSET, [...])` 或控制测试的interfaces中检查。
start/end是SOP local坐标，必须位于所选最终Polygon组的轴向包络两侧；缺组fail，
不跨包络或不支持的面类型保持unverified。pass只证明这条中心线未撞到最终表面，
孔径、孔壁、孔周承载与其他对称轴仍需单独验证；新增凸台、盖面后重新检查。
对称重复件可先从图纸/要求声明期望个数，再用 `{'id':'rails',
'method':'component_count','target_group':'final_rails','expected_components':4}`
查最终Polygon组的共享边连通岛。它能发现少一个或多一个独立岛，不能判断四处
是否在正确角位，也不能证明螺钉进入承载轨；各实例的真实接口另测。

## 读结果与返工

- 先读control_summary的status/reason/case_counts和restored；results=[]可能是基准失败或unsupported，not_run不是pass。摘要保留controller/output、失败case/判据和基准值，不能只打印results后丢掉失败原因。
- `status=fail`：看具体接口点/最近primitive/距离，或控制测量的baseline/measured/delta。range同时约束基准与扰动；只希望约束变化时用delta。验证恒定件时连同应响应的主体一起选取，保留非零响应以排除死控制。
- `status=unverified`：证据方法不支持，不得改写成pass；换经过验证的数据表示或独立方法。
- `restored=False`：状态恢复异常，先处理，不重试下一case。
- `ok=True`：仅已声明接口/控制case通过；其他结构或视觉目标仍按对应证据判断，warning按实际影响处理。
- 检查结果只覆盖调用指定的输出、组、方法和状态；细节/视觉不能借数值检查认证，未声明的关系也不会自动被发现。
- 数值最近距离是无符号邻近，不等于插入深度；整组bbox极值对称不是镜像几何。需要局部轴、明确部件对和覆盖范围，方法不能证明的关系保持unverified。
- 可保存草稿或部分交付，完成报告保留未完成项。

修订生成器后刷新受影响检查，不沿用旧geometry_sha256/contract_sha256。接口检测和构造可
共享设计坐标，但验证必须从真实交付表面取值，不能只检设计anchor的一致性。
期望写错可以依据独立解析或已知几何纠正，但修正后必须复跑受影响case；语言解释不能替代新结果。

## 来源与验证

SideFX [Prim.nearestToPosition](https://www.sidefx.com/docs/houdini/hom/hou/Prim.html#nearestToPosition)
和 [Geometry.freeze/data](https://www.sidefx.com/docs/houdini/hom/hou/Geometry.html)；本项目
`dsh-quality-contracts.test.py`覆盖连接正例、方向正确但脱开、先通后加盖封轴、默认通过/扰动失败、空组、基数、
自重叠、游离driver点、unsupported target、预算、死控制、原生Tube、表达式/cook恢复、ownership。
`dsh-interface-evidence.test.py`另覆盖真实实例脱开、允许间隙、接触及相交时顶点距离仍为正的反例。
工具合同以目标版本回归为据；SOP工作流自然采用仍需新会话验证，不宣称制造认证。


## v13：不改变交付网格的截面观察

Applies when：独立Polygon部件在明确轴平面处应邻近另一表面，现有顶点太稀或点组选取随参数跳变。
Do not use when：任意实体碰撞、融合部件、自交或需要证明整面接触；共面面/歧义截面保持unverified。

```python
interfaces = [{'id':'section_fit', 'method':'section_proximity',
  'source_group':'supports', 'target_group':'cross_member',
  'axis':1, 'plane_at':'target_center', 'expected_components':4,
  'max_distance':0.002}]
report = geo_check_interfaces(out, interfaces)
```

示例数字只是schema；组件数量和容差来自任务。每个源组件都需非空闭合截面，取实际交线段中点到目标面的距离。
不需要给交付网格加Resample，也不把expected_points简单删除。component_coverage明确各组件样本量，
预算/不支持保持显式状态。参数扰动复用同一interfaces，target_center每次来自目标实际几何。

派生参数域可用数据化线性右值，例如移动量必须低于可用尺寸减去壁厚和余量：

```python
domain = [{'id':'clearance', 'left':'travel', 'op':'lt',
  'right':{'terms':{'available_length':1, 'wall_thickness':-1}, 'constant':-0.01}}]
```

不执行表达式字符串、不自动钳制；它只验证声明case。至少选一个接近耦合边界的组合，
对真实输出关系复验，不能用两个公开参数大小关系代替全部派生锚点。

源件朝向、着色与复用后的检查范围统一见[源构件与成形检查](modeling-methods.md#源构件与成形检查)。

实现回归见`dsh-modeling-semantics.test.py`；过程证据留在会话/CI或非发布临时产物，
新模型自然采用及质量提升仍待新会话验收。
