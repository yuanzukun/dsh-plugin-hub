---
name: houdini-sop-workflow
description: 设计、构建、修改和交付可编辑的Houdini SOP程序化网络。用于建模、散布、曲线成形、属性、VEX和SOP动画。纯场景查询直接用工具；HDA工具、rig、COP和Solaris使用对应领域技能。
---

# Houdini SOP Workflow

## 构造分工

交付形体、关系与性能符合要求，用户能继续修改的网络。先确定用户要改的路径、截面、源部件与局部工序；参数面板或可改源码不能替代这些入口。模块可以是重复组件、独有零件或连续形体的一段构造/形变过程；按编辑目标和依赖选择边界，完整源与布局的方法用于重复构造。已有工程保留有效结构，只改相关部分。

| 构造职责 | 普通可编辑建模的默认方法 |
|---|---|
| 标准实体、封口、厚化、复制、局部加工 | 原生SOP承担成形：Box/Tube、Revolve、Sweep、PolyExtrude、Copy等；批量组合相关节点 |
| 锚点、布局、轮廓、中心线、方向、身份和属性规律 | 原生Curve/Line/Circle等能清楚表达时直接使用；不易表达的规律用VEX输出中间数据，再接成形节点 |
| 已有几何的自定义形变、属性计算 | VEX处理相应数据，保留输入形体和所需编辑入口 |

**直接生成网格的例外：**所需自定义拓扑/对应关系超出适用原生方法、必须使用专用库，或同等输出下已测得计算瓶颈时，可用VEX/Python或混合构造。数量多、公式复杂、熟悉代码或少写节点，本身不是重写标准成形的理由。性能看构建、计算、验证与后续修改总成本，不按节点数或Wrangle比例评分。

重复构造把数量、采样和变化规律保留为运行参数：VEX内循环生成模板点或中心线，再由Copy/Sweep成形；避免在Python里逐件、逐点拼接重复VEX语句。具体选择、外部数据例外及下游编译观察见[重复规律与代码生成](references/modeling-methods.md#重复规律与代码生成)。

用户明确指定实现方式时遵从要求；教程已明确的方法沿[视频复现协议](../houdini-video-tutorial/references/reconstruction.md)，未规定部分再按这里选择。接口调用失败先查实际输入、模式和参数，不能据此认定原生方法不适用。

## 当前问题与资料

只读当前构造或疑点对应的小节。组合方法在下表资料中；精确参数、默认值和版本行为读`node_info(parent,type_name)`，现有参数读`list_parms`/`read_parms`，动词签名读`verb_help`。

| 当前决策 | 资料或入口 |
|---|---|
| 复杂任务如何拆分、逐个观察并集成 | 按名加载[任务拆分skill](../houdini-task-decomposition/SKILL.md) |
| 完整重复组件、内部细化与布局的边界 | [完整源组件与布局](references/modeling-methods.md#完整源组件与布局) |
| 路径、截面、重复源如何组合 | [建模方法](references/modeling-methods.md#1-从表示和构造选方法) |
| 曲线不平滑、穿插、贴附偏离或扫掠扭转；需要可手调路径与净空反馈 | [可编辑路径与曲线](references/curves-and-routing.md)，分别选择造型、走向、采样和截面朝向；`sop_recipe('curve_path')`给原生可编辑路径，`geo_curve_clearance`仅查实际折线半径包络 |
| 重复细节数量增长、VEX代码生成和下游编译失败 | [重复规律与代码生成](references/modeling-methods.md#重复规律与代码生成) |
| 大量复制前验源；闭合却反向；同源错误扩散 | [源构件与成形检查](references/modeling-methods.md#源构件与成形检查)；Revolve先读`node_info(parent,'revolve')`的方向说明 |
| 倒角、细节、表面表示 | [局部操作](references/modeling-methods.md#2-选择先于倒角与局部操作)、[分层细化](references/modeling-methods.md#3-一个模块分层细化)、[表面表示](references/modeling-methods.md#表面表示与外观制作) |
| 新模型/部件外观、参考图细节、UV与统一SOP预览 | 按名加载[表面外观skill](../houdini-surface-workflow/SKILL.md)，决定细化程度；纯色也有明确表面入口 |
| 转轴、滑轨、重复、管线、附着 | [构造模板](references/procedural-recipes.md) |
| 模块接口、共享控制与关系检查 | [模块合同](references/module-quality-contracts.md) |
| 所声称性质该测什么；图像与统计冲突 | [质量与检查选择](references/procedural-quality-contract.md) |
| 批量建网、VEX参数、属性传播 | [SOP patterns](references/sop-patterns.md) |
| Boolean、坐标、恢复、图像范围或代码文件依赖 | [执行与观察边界](references/execution-checkpoints.md) |
| 用户明确要求组件文件交换 | [模块文件与复用](references/module-design-collaboration.md) |

参数界面、骨架、图像数据制作、材质渲染分别按名加载`houdini-parameter-ui`、`houdini-rig-animation-workflow`、`houdini-cop-workflow`、`houdini-solaris-karma-workflow`；HDA/回调/打包使用`houdini-tool-development`。

## 构建、观察与继续修改

读取相关现场、要求和参考；复杂任务的粒度与推进使用[任务拆分skill](../houdini-task-decomposition/SKILL.md)。尺寸、厚度、间隙和连接基准共享来源；新资产使用米制与Y-up，`modeling_dimensions`可换算原始单位，已有工程按现场适配。同层模块默认沿数据流组织；稳定公共接口或独立替换需要时再用Subnet。

用`build_module`或一批动词组合构建当前单元；`None`保留空输入槽。重复对象默认先形成符合编辑目标的完整源组件，再由独立布局复制；源内部可以继续使用Box/Tube、Copy和局部工序。单件与实例的检查、改源后的消费者复查见上表。`build_module`的批次成功不判断组件划分和外观质量。

按目标选择证据：`verify_network`检查明确输出的计算与非空；`geo_piece_stats(..., inspect=True, integrity_only=True)`观察选定表面；`test_controls`执行所需代表性控制状态并报告恢复。局部组通过不扩展为整个模块通过，unsupported或超预算保留未验证。

用`render_view`观察正在判断的实际SOP，局部疑点用局部图，A/B对照保持可比取景。形状不符时回到负责它的轮廓、截面、成形或连接：尺寸偏差可以调参，现有源无法表达的曲率、层次或结构需要换该部分构造，增加倒角、纹理或渲染采样不能替代。保留有效输出接口，只复验受影响的源与消费者；没有成功识图时视觉仍未验证。

## 交付

非平凡资产保留明确最终输出，如`OUT_ASSET`；Subnet/HDA用原生Output发布公共接口。检查最后修改后的相关输出，再保存实际HIP并说明有效控制和未验证范围。仅要代码或说明时按请求交付。

用户接手新资产或多支路网络时，按名加载`houdini-network-handoff`组织入口、分组和文件交付；小改动不必重排整网。续接时结合原要求、已有输出和新增需求继续。
