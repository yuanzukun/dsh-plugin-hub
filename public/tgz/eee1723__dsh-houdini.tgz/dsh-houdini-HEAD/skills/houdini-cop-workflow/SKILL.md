---
name: houdini-cop-workflow
description: 在 Houdini Copernicus 中制作、诊断和验证程序纹理与图像处理网络，包括建模中的涂装遮罩、标识/贴花、图像校正、微表面纹理、COP教程复现和文件导出。需要制作或修改图像数据时加载；纯几何建模、常量材质参数、只解析视频或仅消费已有贴图不触发。
---

# Houdini COP / Copernicus Workflow

交付可解释、可验证的图层数据流，而不只是能 cook 的节点图。本 skill 负责 COP；
教程证据由 `houdini-video-tutorial` 负责，源几何与最终渲染分别按需联用 SOP、Solaris/Karma workflow。
不自动加载所有领域或所有参考文件，不以视频中的操作顺序代替依赖顺序。

COP负责需要生成或加工的图像数据；表面细化程度、参考分析与来源选择由[表面外观skill](../houdini-surface-workflow/SKILL.md)维护。制作程序纹理时先读[图案设计方法](references/pattern-design.md)，按结构关系组织算子、共享mask和通道，不套单一产品配方。要求还原教程方法时保留作者的图层职责、处理方法与数据语义，必要适配和可切回优化沿[视频复现协议](../houdini-video-tutorial/references/reconstruction.md)。

## 任务边界与执行脊柱

1. **分类与版本**：确认 runtime、实际 parent、Copernicus 或旧 Compositing/COP2；旧网络不静默迁移。
   类别查询用`cop`/`copernicus`，旧网络明确`cop2`；已有parent优先`search_tab_entries(parent,query)`。
   简单单参数编辑只做对应回读；跨模块、缓存、材质绑定或文件交付时，在现有任务笔记中写紧凑合同：
   交付物、允许差异、模块输入/输出角色、核心关系、预览与最终规格。
2. **最小骨架**：从当前 parent 的 Tab 发现可见节点，先打通一个可检查的输入→操作→输出。
   图像处理先用已知小图核对通道和采样；SOP表面按实际材质消费者接入，正式渲染任务才按需联用Karma做低成本预览，
   验证承载几何的 UV 两维、材质绑定、相机和纹理采样。纯贴图任务不强制建立渲染场景。
3. **模块构建**：先读 [图层与端口](references/layers-and-ports.md)。写清坐标、ID、颜色、
   高度、增量或遮罩的角色；确认源输出与目标输入的实际名称、索引、类型及运算模式，再连接和回读。
   先用 `verb_help`、`search_tab_entries`、`list_parms` 等现有能力；不猜 API、不绕 Raw Gate。
4. **关系 checkpoint**：多层组合、随机驱动或控制任务先读 [关系与控制验证](references/relations-and-controls.md)。
   分开检查数据有效性、实际依赖和预期响应；异常先校准测量对象/公式，再改资产。
   重复失败没有新信息时，回到已验证 checkpoint，查目标版本帮助或换一个最小诊断。
5. **按需集成**：要导出、处理缓存、法线或交给材质时读 [缓存与交付](references/cache-and-delivery.md)。
   接入已有资产时，常用图案/动画控制按[总控与模块控制](../houdini-parameter-ui/references/control-bindings.md#总控与模块控制)融入原编辑入口；COP容器和实际消费者按network-handoff整理到上层交接，局部图层输出不代替整体集成。
   跨到复杂几何/UV 时加载 `houdini-sop-workflow`，进入 USD/MaterialX/Karma 时加载
   `houdini-solaris-karma-workflow`；需要集中控制界面才加载 `houdini-parameter-ui`。
   时间依赖不等于模拟；涉及反馈/solver 时另核初始化、顺序求值和重置，不把静态纹理路线用于模拟。
   反馈求解与缓存修改按需加载houdini-simulation-workflow。
6. **交付与复验**：最后一次相关接线、参数、分辨率、缓存或绑定修改使受影响的旧证据失效。
   刷新对应关系、导出和视觉验收，不无差别重做全部步骤。恢复临时控制/诊断状态，
   按授权保存；重开使用隔离副本，不重启 live、不加载覆盖用户当前 HIP。

## 完成门

用户接手新网络或教学工程时，联用houdini-network-handoff交付入口、分组与短说明；具体方法不在COP重复维护。
当前图像视窗、参数页或工具窗口需要观察时，按[通用界面观察](../houdini-tool-development/references/evidence-and-validation.md#观察实际工作界面)选择实际可见目标；视窗的显示图层、通道、曝光与缩放条件不能替代真实图层数据和最终导出验收。

- 每个核心模块都有实际输出和同层证据；cook、非零数据、像素变化不证明目标关系或外观正确。
- 仅声明实际测过的控制与范围；恢复参数不等于恢复输出，恢复失败时停止后续调参并报告差异。
- 最终纹理按实际用途核对每个输出的尺寸、通道、精度、颜色解释、范围及落盘读回；
  只有要求平铺时才做最终分辨率 U/V 接缝与重复铺贴视觉检查。
- 有参考外观要求时，分别检查核心形态、细节和材质表现；允许的灯光变化不豁免其他要求。
  需要还原作者方法时按video skill的复现协议处理；图层与最终材质必须分别对照，
  不因节点同名或识别出同类对象就声称还原。没有成功语义读图写“视觉未验证”；纹理铺满画面本身不是构图失败。
- 教学工程按需求保留阶段输出、少量有意义且测过的控制，以及意图/原理说明；命名不替代教学验收。
- 资料、结构、关系、视觉、文件/重开分别报告；核心项未过只能部分完成，不能用局部通过覆盖。

## 证据与能力范围

当前执行合同提供具名 `connect`、`cop_layer_stats`、`cop_compare_layers` 和 `test_cop_controls`，
后三者必须 exec；先以 runtime `verb_help` 确认版本，不把源码能力当已加载。图层/端口及控制恢复
机制有 H21/H22 隔离回归，完整教程与自然任务采用仍为候选，不是已发布的泛化质量保证。
维护或验收本 skill 时才读 [来源与验收矩阵](references/evidence-and-validation.md)。
