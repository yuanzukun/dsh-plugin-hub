# Solaris / Karma patterns

本文件记录会改变 agent 决策的版本化工作流，不复制完整 SideFX 手册。运行时先信当前
Houdini 安装的 node/tool/help，再用官方在线文档核对概念与新版本变化。

## 目录

1. H21 标准 Tab tools
2. 材质 render context
3. SOP/USD 动画
4. Render Settings 与交付 ROP
5. 灯光
6. Copernicus 接口
7. 官方参考

## 1. H21 标准 Tab tools

H21.0.440 本机 shipped shelf：

- `lop_karma_setup`，label `Karma (Setup)`：创建名为 `karmarendersettings` 的 Karma
  Render Settings 与 `usdrender_rop`；ROP 表达式引用 settings prim、motion blur 和
  CPU/XPU engine。它是多节点 setup，不是 `createNode('karma')`。
- `vop_karmamtlxsubnet`，label `Karma Material Builder`：在 Material Library 根层创建
  `karmamaterial` subnet，配置 Karma/MaterialX tab mask 与 `kma` render context；内部
  默认包含 MtlX Standard Surface、MtlX Displacement、Karma Material Properties 和
  Material Outputs/AOVs。

工具 id 可能随版本变化；每次用 `search_tab_entries(actual_parent, query)` 发现，不能把
本节当作跳过运行时查询的理由。`tab_apply` allowlist 暂只覆盖上述两个已回归意图。

H22.0.368 的 shipped shelf 仍登记同名 `lop_karma_setup` / `vop_karmamtlxsubnet` 与相同 label，
但当前完整 setup/material-builder 状态恢复和 USD Render ROP 出图回归只在 H21 GUI 执行过。
因此“入口仍存在”是 H21/H22 已确认事实，“H22 完整 recipe 已通过”仍是未验证项；H22 任务
必须先运行 parent-aware discovery 和最小 GUI 验收，不能由 shelf 文本直接外推。

## 2. 材质 render context

优先级不是“哪个节点能 cook”，而是目标 delegate 能消费哪个 render context：

- Karma Material Builder：Karma/MaterialX 混合能力，默认 `outputs:kma`。
- USD MaterialX Builder：纯 `outputs:mtlx`，适合跨 renderer。
- USD Preview Material Builder：通用 preview。
- VEX/Principled：主要是 Karma CPU/旧资产兼容；XPU 可能自动转换为有限的 preview，
  画面有颜色不能证明原网络完整受支持。

读取 SOP `Cd` 时，先在 `usd_prim_info` 确认导入后的 primvar 名和 class。SOP Import 常把
它变成 `primvars:displayColor`；MaterialX 使用 Geometry Property Value 或兼容 primvar
reader 显式读取。薄片植物的双面行为应由 MaterialX/Karma 几何或材质设置明确控制，
不要依赖旧 Principled 的单一 toggle 名跨版本迁移。

## 3. SOP/USD 动画

- SOP Import 的 Author Time Samples 控制 authoring 策略，但某次 cook 只看到一个 sample
  不等价于序列静止，也不等价于序列已验证。
- 先在 SOP 用 `geo_frame_diff` 证明源数据随时间变化；再在最终 stage 检查 time-sampled
  points/xform/primvars；最后用同一 USD camera 渲染两个间隔帧。
- Motion blur 还依赖 camera shutter、Render Settings 和足够的 stage samples；它与“每帧
  重新 cook 能产生动画”是两个不同契约。

## 4. Render Settings 与交付 ROP

标准职责分离：

```text
LOP scene chain -> Karma Render Settings
                         |
                         +-> USD Render ROP / husk process
```

- Render Settings/Product/Var 是 USD prim，属于 stage 数据。
- USD Render ROP 是可执行 `hou.RopNode`，负责进程、frame range、output override、husk、
  Slap Comp 等交付行为。
- `render_frame` 接收可执行 ROP；普通 LopNode 即便有 `execute` 按钮也不应被当作
  `render()` 对象。
- AOV/denoiser 不在简单 beauty 测试时强制开启；用户要求合成、深度、Cryptomatte、
  去噪或生产 EXR 时才配置并用 stage summary 检查 RenderVar/Product。

查看EXR的颜色与材质前，确认实际scene-linear空间及显示变换。不要直接把线性通道裁到8位，或固定猜测另一个OCIO版本的display/view名字；这种转换可能把正确的材质看成过暗或过饱和。Houdini侧可以只读`PyOpenColorIO.GetCurrentConfig()`，用`getColorSpace('scene_linear').getName()`、`getDisplays()`及`getViews(display)`读取当前事实，`hou.getenv('OCIO')`确认本进程配置。再查当前随Houdini的`iconvert --help`，以同一配置中真实存在的输入空间和display/view转成可读PNG；记录这些转换条件。终端返回或工具外层成功不能覆盖转换进程非零退出，也不重复渲染来处理纯显示转换问题。

静态整物镜头使用camera_fit：显式OBJ cam与SOP目标，保留焦距、清lookatpath、写入世界构图并回验。
width/height应与最终产品一致；list_parms的locked_components能识别setup派生字段，不解锁表达式来凑分辨率。
Scene Import后用render_frame的framing={target:实际USD资产路径,coverage:.82}预检，不认为OBJ通过就等于USD通过。
检查包括全部产品的camera、resolution/pixelAspect、aspectRatioConformPolicy与dataWindowNDC；不支持的ROP
override/外部USD/前置脚本/lens/Volume/PointInstancer明确拒绝，不暗中更改镜头或增加重渲染。
此fast path适用于当前帧普通透视/正交包络，不用于艺术裁切、动画相机、位移/快门包络或语义质量认证。
诊断材质细节时另查景深启用状态、焦点距离和光圈；camera_fit不设置焦点，包络通过不证明画面清晰。
移动相机或改变焦距后重新检查清晰度。仅在自有诊断镜头且不要求景深时临时关闭景深；
艺术镜头保留原意并校准焦点，不把失焦误诊为纹理分辨率或继续增加细节。此项有H22单任务对照，
跨版本默认值与未见任务采用仍待验，不固定某个版本的默认焦点/参数token。
技术版本与回归状态见development的v14记录；未见任务自然采用仍待验。

## 5. 灯光

- 中性测试：Distant + Dome 合理。
- 自然日光：Karma Physical Sky 把 sun 与 sky rig 合在一个物理模型中，优先于手工模拟
  “真实天空”；艺术化灯光仍可自由组合。
- HDRI：Dome Light；检查纹理路径、颜色空间与缺失纹理错误。

灯光“最佳”取决于任务，不把 Physical Sky 设成所有场景的硬规则。

## 6. Copernicus 接口

COP 图层构建、关系与导出由按需加载的 `houdini-cop-workflow` 维护；本节只维护 Solaris
消费接口，不在 system prompt 预载节点清单。仅消费现有贴图不加载 COP workflow。常见接口：

- Texture Material Library LOP + USD Material COP（H22起；H21先发现实际可用接口，不照搬节点名）。
- Quick Surface Material LOP。
- Karma Material Builder 内 MtlX Image/Tiled Image 的 `op:/path/to/cop` 输入。
- USD Render ROP Slap Comp。

几何的UV/空间、图像的颜色/数据角色与shader输入需要相互对应；连续涂装边界直接在材质里采样，
不转成逐面颜色阈值分类。只设置常量颜色/roughness时无需创建COP。写盘读回及`$HIP/dsh-texture`约定
由COP的[文件合同](../../houdini-cop-workflow/references/cache-and-delivery.md#文件合同)维护，不在此复制另一份导出流程。

只有在真实 trace 需要低成本验证图层、分辨率、数据类型、保存或 slap comp 结果时，才
新增 COP 自省/交付动词。

## 7. 官方参考

- Karma materials: https://www.sidefx.com/docs/houdini/solaris/kug/materials.html
- Material Library: https://www.sidefx.com/docs/houdini/nodes/lop/materiallibrary.html
- Karma XPU: https://www.sidefx.com/docs/houdini/solaris/karma_xpu.html
- Karma Render Settings: https://www.sidefx.com/docs/houdini/nodes/lop/karmarendersettings.html
- USD Render ROP: https://www.sidefx.com/docs/houdini/nodes/out/usdrender.html
- Karma Physical Sky: https://www.sidefx.com/docs/houdini/nodes/lop/karmaphysicalsky.html
- Copernicus workflows: https://www.sidefx.com/docs/houdini/copernicus/working_with_cops.html
