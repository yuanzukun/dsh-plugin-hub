function tryJson(text) {
  if (typeof text !== 'string') return text;
  try { return JSON.parse(text); }
  catch { return null; }
}

/** A shell tool can deliver normally while its child exits unsuccessfully.
 * Only the known shell formatter's final trailer (or structured metadata) is
 * an exit fact. Printed Error/FAIL text, arbitrary tools and partial output
 * cannot establish a process outcome. Shared by extraction and the client.
 */
export function processOutcomeFor(tool, text, metadata) {
  if (tool !== 'pwsh' && tool !== 'bash') return null;
  if (metadata && Object.prototype.hasOwnProperty.call(metadata, 'shellExit')) {
    if (!metadata.shellExit || typeof metadata.shellExit !== 'object' || Array.isArray(metadata.shellExit))
      return {status:'unknown',exitCode:null,source:'structured_metadata'};
    metadata = metadata.shellExit;
  }
  if (!metadata || !['exitCode','timedOut','aborted','stopped','signal'].some(key=>Object.prototype.hasOwnProperty.call(metadata,key))) {
    const record = typeof text === 'string' ? /\n\[process-result: (\{[^\n]*\})\]\s*$/.exec(text) : null;
    if (record) metadata = tryJson(record[1]) || {exitCode:null};
  }
  let exitCode = null, source = 'not_recorded', interruption = null;
  if (metadata && ['exitCode','timedOut','aborted','stopped','signal'].some(key => Object.prototype.hasOwnProperty.call(metadata, key))) {
    exitCode = Number.isSafeInteger(metadata.exitCode) ? metadata.exitCode : null;
    source = 'structured_metadata';
    interruption = metadata.timedOut === true ? 'timed_out' : metadata.aborted === true || typeof metadata.stopped === 'string'
      ? 'stopped' : typeof metadata.signal === 'string' ? 'signal' : null;
  } else {
    const lines = typeof text === 'string' ? text.replaceAll('\r', '').trimEnd().split('\n') : [];
    for (let index = lines.length - 1; index >= 0; index--) {
      const marker = /^\[(?:exit code: (-?\d+)|timed out after (\d+)ms|stopped: ([^\]]*)|killed by signal: ([^\]]+))\]$/.exec(lines[index]);
      if (!marker) break;
      source = 'shell_result_trailer';
      if (exitCode === null && marker[1] !== undefined && Number.isSafeInteger(Number(marker[1]))) exitCode = Number(marker[1]);
      if (marker[2] !== undefined) interruption = 'timed_out';
      else if (marker[3] !== undefined && interruption !== 'timed_out') interruption = 'stopped';
      else if (marker[4] !== undefined && interruption === null) interruption = 'signal';
    }
  }
  return {status: interruption ? 'interrupted' : exitCode === null ? 'unknown' : exitCode === 0 ? 'succeeded' : 'failed',
    exitCode, source, ...(typeof metadata?.hasStderr === 'boolean' ? {hasStderr:metadata.hasStderr} : {}), ...(interruption ? {interruption} : {})};
}

/** Diagnostic retry candidates, not semantic equivalence or avoidable cost.
 * Input must be normalized unique calls; replay removal belongs upstream.
 */
export function collectRetryWork(steps = []) {
  const calls = steps.filter(s => typeof s.code === 'string' && s.code.length);
  const rolledBack = calls.filter(s => s.rollback?.applied === true);
  const limit = {lookbackCodeCalls:8, minCodeChars:512, maxCodeChars:65536, minLineOverlap:0.8};
  const lineMap = code => {
    const lines = new Map();
    for (const raw of code.split(/\r?\n/)) {
      const line = raw.trim();
      if (line) lines.set(line,(lines.get(line)||0)+1);
    }
    return lines;
  };
  const sized = calls.map(s => ({...s, lines:s.code.length >= limit.minCodeChars
    && s.code.length <= limit.maxCodeChars ? lineMap(s.code) : null}));
  const weight = lines => [...lines].reduce((n,[line,count])=>n+line.length*count,0);
  const excerpt = (a,b) => [...a].filter(([line,count])=>count>(b.get(line)||0))
    .slice(0,6).map(([line,count])=>({line:line.slice(0,180),count:count-(b.get(line)||0),truncated:line.length>180}));
  const candidates=[];
  for(let i=0;i<sized.length;i++) {
    const current=sized[i];
    if(!current.lines)continue;
    let best=null;
    for(let j=i-1;j>=Math.max(0,i-limit.lookbackCodeCalls);j--) {
      const prior=sized[j];
      if(!prior.failed || !prior.lines || prior.tool!==current.tool)continue;
      let common=0;
      for(const [line,count] of current.lines)common+=line.length*Math.min(count,prior.lines.get(line)||0);
      const score=common/Math.max(weight(current.lines),weight(prior.lines),1);
      if(score<limit.minLineOverlap || (best && best.lineOverlap>=score))continue;
      best={from:prior.index,to:current.index,lineOverlap:score,
        priorCodeChars:prior.code.length,currentCodeChars:current.code.length,
        currentFailed:!!current.failed,priorRollbackApplied:prior.rollback?.applied===true,
        changedLineExcerpts:{removed:excerpt(prior.lines,current.lines),added:excerpt(current.lines,prior.lines)},
        kind:'failed_call_followed_by_similar_code_candidate'};
    }
    if(best)candidates.push({...best,lineOverlap:Number(best.lineOverlap.toFixed(4))});
  }
  return {codeCalls:calls.length,totalCodeChars:calls.reduce((n,s)=>n+s.code.length,0),
    failedCodeChars:calls.filter(s=>s.failed).reduce((n,s)=>n+s.code.length,0),
    appliedRollbackCalls:rolledBack.length,appliedRollbackCodeChars:rolledBack.reduce((n,s)=>n+s.code.length,0),
    successfulBuildEntriesInAppliedRollbacks:rolledBack.flatMap(s=>(s.verbs||[])
      .filter(v=>v.verb==='build_module' && v.ok===true)
      .map(v=>({step:s.index,ledgerIndex:v.ledgerIndex??null,verb:v.verb}))),
    candidates,limits:limit,hostWork:collectHostWork(steps),similaritySkippedCalls:sized.filter(s=>!s.lines).map(s=>s.index),
    note:'Raw code characters, not tokens, time or savings. Applied rollback code is a subset of submitted code, not an additional cost. Similarity is trimmed exact-line multiset overlap (order/indentation ignored), not Python equivalence; candidates may be necessary retries or distinct module work. Successful build ledger entries were later rolled back, not retained outputs. Full source remains in the corresponding trace steps.'};
}

/** Observations only: host work can be necessary research/building, not a stall. */
export function collectHostWork(steps = []) {
  const writes = new Map(), commands = new Map(), runs = [];
  let run = null;
  const finish = () => { if (run) runs.push(run); run = null; };
  for (const s of steps) {
    const args = s.args || {};
    const file = ['write','edit'].includes(s.tool) ? args.file_path : null;
    const command = ['pwsh','bash'].includes(s.tool) ? args.command : null;
    const host = typeof file === 'string' || typeof command === 'string';
    if (typeof file === 'string') {
      const key = file.replaceAll('\\','/');
      const item = writes.get(key) || {path:key,steps:[],writeCalls:0,editCalls:0,failedCalls:0};
      item.steps.push(s.index);item[s.tool==='write'?'writeCalls':'editCalls']++;
      if(s.failed)item.failedCalls++;
      writes.set(key,item);
    }
    if (typeof command === 'string') {
      // Exact text only; do not assume different commands share effects, or
      // infer execution success from printed PASS/FAIL words.
      const item = commands.get(command) || {commandPreview:command.slice(0,240),
        truncated:command.length>240,steps:[],failedCalls:0,processFailures:0};
      item.steps.push(s.index);if(s.failed)item.failedCalls++;
      if(s.processOutcome?.status==='failed')item.processFailures++;
      commands.set(command,item);
    }
    if (s.isHoudini || s.tool?.startsWith('houdini_')) { finish(); continue; }
    if (run && s.turn !== run.turn) finish();
    if (host) {
      run ||= {turn:s.turn,firstStep:s.index,lastStep:s.index,hostCalls:0};
      run.lastStep=s.index;run.hostCalls++;
    }
  }
  finish();
  return {fileWrites:[...writes.values()].sort((a,b)=>b.steps.length-a.steps.length),
    repeatedCommands:[...commands.values()].filter(x=>x.steps.length>1)
      .sort((a,b)=>b.steps.length-a.steps.length),
    hostIntervalsWithoutHoudiniCalls:runs,
    scope:'Exact host write/edit targets and shell commands in deduplicated steps. Intervals may include reads/research. No inference of semantic progress, file contents or geometry correctness. failedCalls records tool failures; processFailures records known shell exit facts separately. Printed Error/FAIL alone is not an exit verdict.'};
}

export function extractAvailableSkills(text) {
  if (typeof text !== 'string' || !text.includes('<available_skills>')) return [];
  return [...text.matchAll(/^- `([^`]+)`: /gm)].map((match) => match[1]);
}

export function skillCatalogNames(message) {
  const source = message?.source;
  if (source?.kind === 'skill-catalog' && source?.form === 'catalog' && Array.isArray(source.entries)) {
    return [...new Set(source.entries.map(entry => entry?.name).filter(name => typeof name === 'string' && name))];
  }
  return extractAvailableSkills((message?.content || []).filter(block => block?.type === 'text')
    .map(block => block.text).join('\n'));
}

export function parseLedgerArgs(value) {
  if (Array.isArray(value)) return { positional: value, kwargs: {} };
  if (value && typeof value === 'object') return { positional: [], kwargs: value };
  const text = String(value ?? '').trim();
  if (!text) return { positional: [], kwargs: {} };

  const direct = tryJson(text);
  if (Array.isArray(direct)) return { positional: direct, kwargs: {} };
  if (direct && typeof direct === 'object') return { positional: [], kwargs: direct };

  const wrapped = tryJson(`[${text}]`);
  if (Array.isArray(wrapped)) {
    const positional = Array.isArray(wrapped[0]) ? wrapped[0] : [];
    const kwargs = wrapped[1] && !Array.isArray(wrapped[1]) && typeof wrapped[1] === 'object'
      ? wrapped[1]
      : {};
    return { positional, kwargs };
  }
  return { positional: [], kwargs: {}, unparsed: text };
}

/** Parse one rendered verb-ledger line without confusing arrows inside JSON strings/results. */
export function parseVerbLedgerLine(line) {
  if (typeof line !== 'string') return null;
  const prefix = line.match(/^(\d+)\. \[(ok|FAIL)\] (\w+)\(/);
  if (!prefix) return null;
  const tail = line.match(/ \(([\d.]+)ms\)\s*$/);
  if (!tail || tail.index === undefined) return null;
  const body = line.slice(prefix[0].length, tail.index);
  let inString = false;
  let escaped = false;
  let square = 0;
  let curly = 0;
  for (let index = 0; index < body.length; index++) {
    const char = body[index];
    if (inString) {
      if (escaped) escaped = false;
      else if (char === '\\') escaped = true;
      else if (char === '"') inString = false;
      continue;
    }
    if (char === '"') { inString = true; continue; }
    if (char === '[') square++;
    else if (char === ']') square--;
    else if (char === '{') curly++;
    else if (char === '}') curly--;
    else if (char === ')' && square === 0 && curly === 0 && body.startsWith(') -> ', index)) {
      return {
        ledgerIndex: Number(prefix[1]),
        ok: prefix[2] === 'ok',
        verb: prefix[3],
        args: body.slice(0, index),
        result: body.slice(index + 5),
        ms: Number(tail[1]),
      };
    }
    if (square < 0 || curly < 0) return null;
  }
  return null;
}

function nodePath(value) {
  if (typeof value === 'string') return value;
  if (value && typeof value === 'object' && typeof value.node === 'string') return value.node;
  return null;
}

export function findBatchSetParmOpportunities(steps, threshold = 3) {
  const opportunities = [];
  for (const step of steps) {
    const batched = new Map();
    for (const verb of step.verbs || []) {
      if (verb.verb !== 'set_parms') continue;
      const { positional } = parseLedgerArgs(verb.args ?? verb.argsText);
      const node = nodePath(positional[0]);
      const values = positional[1];
      if (!node || !values || Array.isArray(values) || typeof values !== 'object') continue;
      const fields = batched.get(node) || new Set();
      for (const name of Object.keys(values)) fields.add(name);
      batched.set(node, fields);
    }

    const byNode = new Map();
    for (const verb of step.verbs || []) {
      if (verb.verb !== 'set_parm') continue;
      const { positional } = parseLedgerArgs(verb.args ?? verb.argsText);
      const node = nodePath(positional[0]);
      const parm = typeof positional[1] === 'string' ? positional[1] : null;
      if (!node || !parm || batched.get(node)?.has(parm)) continue;
      const fields = byNode.get(node) || new Set();
      fields.add(parm);
      byNode.set(node, fields);
    }

    for (const [node, fields] of byNode) {
      if (fields.size < threshold) continue;
      opportunities.push({
        index: step.index,
        time: step.time,
        node,
        count: fields.size,
        parms: [...fields].sort(),
      });
    }
  }
  return opportunities;
}

const MUTATING_METHOD = /^(?:set|add|create|delete|destroy|remove|rename|save|cook|render|bake|lock|unlock|install|copy|move|enable|disable|press)(?:$|[A-Z_])/;
const READ_ONLY_PREFIX_COLLISIONS = new Set(['displayNode', 'renderNode']);

export function isMutatingRawMethodName(name) {
  return MUTATING_METHOD.test(String(name || '')) && !READ_ONLY_PREFIX_COLLISIONS.has(name);
}

export function rawMethodNames(code) {
  const methods = [];
  for (const match of String(code || '').matchAll(/\.([A-Za-z_]\w*)\s*\(/g)) methods.push(match[1]);
  return methods;
}

export function mutatingRawMethodNames(code) {
  return rawMethodNames(code).filter(isMutatingRawMethodName);
}

const SUPPRESSED_COOK_FAILURE = /(?:^|\n)(?:[A-Z][A-Z ]{0,24} )?cook FAIL(?:ED)?(?=[:\s]|$)/i;

/**
 * Find Houdini calls whose transport envelope succeeded while agent code
 * printed that a raw cook failed.  These are semantic/artifact failures, not
 * tool transport failures, and commonly result from catching without re-raise.
 */
export function findSuppressedCookFailures(steps) {
  return steps.filter((step) => (
    step.isHoudini
    && !step.failed
    && SUPPRESSED_COOK_FAILURE.test(String(step.resultPreview || ''))
  )).map((step) => ({
    index: step.index,
    time: step.time,
    tool: step.tool,
    resultPreview: step.resultPreview,
  }));
}

export function frameFromPath(value) {
  if (typeof value !== 'string') return null;
  const match = value.match(/(?:^|[_./\\-])f(-?\d+(?:p\d+)?)(?=[_.\\/-]|$)/i);
  if (!match) return null;
  const frame = Number(match[1].replace('p', '.'));
  return Number.isFinite(frame) ? frame : null;
}

function finiteFrame(value) {
  if (value === null || value === undefined || value === '') return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function uniqueFrames(values) {
  return [...new Set(values.filter((value) => value !== null))].sort((a, b) => a - b);
}

function verbResult(value) {
  if (value && typeof value === 'object') return value;
  return tryJson(value) || {};
}

/** Recover the full __result__ JSON block rendered before a truncated verb ledger. */
export function execResultFromPreview(value) {
  const text = String(value ?? '');
  const marker = '__result__:';
  const markerIndex = text.indexOf(marker);
  if (markerIndex < 0) return {};
  const start = text.indexOf('{', markerIndex + marker.length);
  if (start < 0) return {};
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < text.length; index++) {
    const char = text[index];
    if (inString) {
      if (escaped) escaped = false;
      else if (char === '\\') escaped = true;
      else if (char === '"') inString = false;
      continue;
    }
    if (char === '"') { inString = true; continue; }
    if (char === '{') depth++;
    else if (char === '}') {
      depth--;
      if (depth === 0) return tryJson(text.slice(start, index + 1)) || {};
    }
  }
  return {};
}

function partialJsonString(value, key) {
  const pattern = new RegExp(`"${key}"\\s*:\\s*"((?:\\\\.|[^"\\\\])*)"`, 'g');
  const values = [];
  for (const match of String(value ?? '').matchAll(pattern)) {
    try { values.push(JSON.parse(`"${match[1]}"`)); } catch {}
  }
  return values;
}

function partialJsonArray(value, key) {
  const match = String(value ?? '').match(new RegExp(`"${key}"\\s*:\\s*(\\[[^\\]]*\\])`));
  return match ? tryJson(match[1]) : null;
}

function partialJsonNumber(value, key) {
  const match = String(value ?? '').match(new RegExp(`"${key}"\\s*:\\s*(-?[\\d.]+)`));
  return match ? Number(match[1]) : null;
}

/** Ordered unique render outputs visible anywhere in the unabridged tool result. */
export function renderOutputsFromPreview(value) {
  return [...new Set(partialJsonString(value, 'output'))];
}

const VISION_REFUSAL = [
  /无法.{0,20}(?:查看|看到|访问|读取|分析).{0,20}(?:图像|图片|图)/i,
  /模型仅接受文本输入/i,
  /图片已被省略/i,
  /(?:cannot|can't|unable to).{0,30}(?:view|see|access|inspect|analy[sz]e).{0,20}images?/i,
  /images?.{0,20}(?:omitted|not (?:available|provided|attached))/i,
];

/** Native output delivery is observable; model interpretation remains a separate judgement. */
export function nativeImageEvidence(steps) {
  return steps.flatMap(step => (Array.isArray(step.canonical?.imageAttachments) ? step.canonical.imageAttachments : [])
    .map(item => ({index:step.index,path:item.from,attachmentId:item.attachment?.attachmentId ?? null,
      delivered:!!item.attachment?.attachmentId && !item.error,error:item.error ?? null,semanticStatus:'unverified'})));
}

/** Link a delivered image to the next recorded assistant response, without
 * treating the model's own description as an independent semantic verdict. */
export function linkNativeImageResponses(images, steps, events) {
  const stepByIndex = new Map(steps.map(step => [step.index, step]));
  const responses = events.filter(event => event.type === 'assistant/message'
    && Array.isArray(event.data?.message?.content));
  return images.map(item => {
    if (!item.delivered) return item;
    const step = stepByIndex.get(item.index);
    const next = responses.find(event => Number.isInteger(step?.resultSeq)
      && event.seq > step.resultSeq && (step.turn == null || event.data?.turn === step.turn));
    if (!next) return {...item,followingAssistant:null};
    const blocks = next.data.message.content;
    const prose = blocks.filter(block => block.type === 'reasoning' || block.type === 'text')
      .map(block => String(block.text || '')).join('\n');
    return {...item,followingAssistant:{seq:next.seq,time:next.time,
      proseChars:prose.length,excerpt:prose.slice(0,300),
      status:'requires_manual_image_comparison'}};
  });
}

/** Distinguish tool transport, image delivery, setup, and actual semantic inspection. */
export function classifyVisionEvidence(step) {
  const tool = String(step.tool || '');
  const semanticTools = new Set([
    'vision_glance', 'vision_ground', 'vision_detect',
    'vision_long_screenshot_ocr',
  ]);
  const role = tool === 'vision_present'
    ? 'presentation'
    : tool === 'vision_bootstrap'
      ? 'setup'
      : tool === 'read_image' ? 'image_access' : semanticTools.has(tool)
        ? 'inspection'
        : 'pixel';
  const transportOk = !step.failed;
  const text = String(step.resultPreview ?? step.resultText ?? '').trim();
  const structured = tryJson(text);
  const structuredFailure = structured && typeof structured === 'object' && structured.ok === false;
  const textualRefusal = VISION_REFUSAL.some((pattern) => pattern.test(text));
  const semanticFailure = !transportOk || Boolean(structuredFailure) || textualRefusal;
  const images = Array.isArray(step.args?.images)
    ? step.args.images
    : Array.isArray(step.args?.paths)
      ? step.args.paths
      : [step.args?.path, step.args?.file_path, step.args?.image].filter(Boolean);
  return {
    role,
    transportOk,
    accessOk: !semanticFailure,
    // A returned description is evidence to review, never an automatic verdict
    // on whether the actual image matches the task or that description.
    descriptionText: role === 'inspection' && !semanticFailure ? text || null : null,
    semanticOk: ['inspection','image_access'].includes(role) && semanticFailure ? false : null,
    semanticStatus: ['inspection','image_access'].includes(role)
      ? semanticFailure ? 'access_failed' : 'requires_image_comparison' : 'not_semantic_inspection',
    ok: !semanticFailure,
    reason: !transportOk
      ? 'tool_transport_failed'
      : structuredFailure
        ? String(structured.code || structured.reason || 'structured_result_ok_false')
        : textualRefusal
          ? 'textual_image_access_refusal'
          : null,
    images,
    frames: uniqueFrames(images.map(frameFromPath)),
  };
}

/** Metrics that separate vocabulary breadth from actual execution adoption. */
export function isStructuredHoudiniCall(step) {
  return ['houdini_ui_list','houdini_ui_screenshot'].includes(step.tool)
    || step.tool==='houdini_exec' && !step.code && Boolean(step.args?.delivery || step.args?.review || step.args?.review_test)
}

export function isHoudiniDetailRead(step) {
  return ['houdini_resource', 'houdini_request'].includes(step.tool)
    || (step.tool === 'houdini_query' && Boolean(step.args?.result_ref || step.args?.request_ref || step.args?.source_ref));
}

export function isHoudiniHostCall(step) {
  return isHoudiniDetailRead(step) || ['houdini_capabilities', 'houdini_job_cancel'].includes(step.tool) || step.tool === 'houdini_product'
    || (step.tool === 'houdini_query' && Boolean(step.args?.capabilities));
}

/** Classify evidence, not arbitrary Python semantics. Kept dependency-free so
 * the generated Trace client uses exactly the same rules as offline reports.
 * Gate "read_only" describes static raw scanning, even for mutating verbs;
 * no_scene_change excludes neither file I/O nor module/global side effects.
 */
export function classifyRawEffect(step) {
  if (isStructuredHoudiniCall(step)) return null;
  const usage = step.canonical?.rawUsage ?? step.rawUsage;
  const failed = step.failed || step.canonical?.ok === false;
  const outcome = usage?.gateOutcome;
  const text = String(step.resultText ?? step.resultPreview ?? '');
  if (outcome === 'blocked' || outcome === 'read_only_blocked'
    || (failed && /raw-hou gate: blocked BEFORE execution|houdini_(?:inspect|query) is read-only and rejected this code BEFORE execution/i.test(text))) return 'gate_blocked';
  // Canonical/raw-usage arrays take precedence over method-name heuristics.
  if (usage && !usage._raw) {
    if (usage.coveredMutations?.length) return 'mutation_candidate';
    if (usage.suspectedMutations?.length || outcome === 'exempted') return 'suspected_effect';
  } else if (step.mutatingRawMethods?.length) return 'mutation_candidate';
  if (failed) return 'failed';
  if (['houdini_inspect', 'houdini_query'].includes(step.tool) && step.canonical?.execution?.read_only !== false) return 'read_only_query';
  return 'unknown';
}

export function collectVerbAdoption(steps) {
  const detailReads = steps.filter(isHoudiniDetailRead);
  const hostProducts = steps.filter(step => step.tool === 'houdini_product');
  const hostCapabilities = steps.filter(step => step.tool === 'houdini_capabilities'
    || (step.tool === 'houdini_query' && step.args?.capabilities));
  const houdini = steps.filter((step) => step.isHoudini && !isHoudiniHostCall(step));
  const structured = houdini.filter(isStructuredHoudiniCall);
  const python = houdini.filter(step=>!isStructuredHoudiniCall(step));
  const withVerbs = houdini.filter((step) => (step.verbs || []).length > 0);
  const verbCalls = houdini.reduce((sum, step) => sum + (step.verbs || []).length, 0);
  const raw = python.filter(step => !(step.verbs || []).length);
  const rawReadOnly = raw.filter(step => classifyRawEffect(step) === 'read_only_query');
  const exec = python.filter((step) => step.tool === 'houdini_exec');
  const successfulExec = exec.filter((step) => !step.failed);
  const successfulExecWithVerbs = successfulExec.filter((step) => (step.verbs || []).length > 0);
  const blockedRawMutation = raw.filter(step => classifyRawEffect(step) === 'gate_blocked');
  const successfulRawMutation = raw.filter(step => !step.failed && classifyRawEffect(step) === 'mutation_candidate');
  const pct = (part, total) => total ? Math.round((part / total) * 1000) / 10 : null;
  return {
    houdiniCalls: houdini.length,
    hostResultDetailReads: detailReads.length,
    ...(hostProducts.length ? {hostProductCalls:hostProducts.length} : {}),
    ...(hostCapabilities.length ? {hostCapabilityReads:hostCapabilities.length} : {}),
    callsWithVerbs: withVerbs.length,
    callCoveragePct: pct(withVerbs.length, houdini.length),
    verbCalls,
    verbDensity: houdini.length ? Math.round((verbCalls / houdini.length) * 100) / 100 : 0,
    rawReadOnlyCalls: rawReadOnly.length,
    rawSuspectedEffectCalls: raw.filter(step => classifyRawEffect(step) === 'suspected_effect').length,
    rawUnknownEffectCalls: raw.filter(step => classifyRawEffect(step) === 'unknown').length,
    rawFailedCalls: raw.filter(step => classifyRawEffect(step) === 'failed').length,
    execCalls: exec.length,
    successfulExecCalls: successfulExec.length,
    successfulExecWithVerbs: successfulExecWithVerbs.length,
    successfulExecVerbCoveragePct: pct(successfulExecWithVerbs.length, successfulExec.length),
    blockedVerblessRawMutationCalls: blockedRawMutation.length,
    successfulVerblessRawMutationCalls: successfulRawMutation.length,
    ...(structured.length ? {structuredCalls:structured.length,pythonCalls:python.length,
      pythonCallCoveragePct:pct(withVerbs.length,python.length)} : {}),
  };
}

const OPEN_ENDED_QUALITY_REQUEST = /(?:细节丰富|高质量|写实|逼真|真实感|电影感|镜头级|可靠(?:的)?验证|复杂(?:资产|模型)|真实\s*solver|有效缓存|可重算|产品视觉开发|正式(?:的)?\s*(?:Karma\s*)?渲染|(?:可调|可以调节|参数化).{0,16}(?:效果|模拟|系统)|high[- ]?quality|detail(?:ed| rich)|realistic|cinematic|shot[- ]?quality|reliable (?:verification|validation)|real solver|valid cache|recomputable|product lookdev|final Karma render|(?:adjustable|configurable|parameterized).{0,16}(?:effect|simulation|system))/i;
const PROCEDURAL_ASSEMBLY_QUALITY_REQUEST = /(?:(?:程序化|可调|参数化).{0,96}(?:部件关系|关系(?:仍要)?正确|连接细节|装配关系|网络(?:要)?清楚)|(?:procedural|adjustable|parameterized).{0,96}(?:part relationships?|assembly relations?|connection details?|clear network))/i;
const EXTERNAL_TRUTH_SIGNAL = /(?:(?:符合|属于|处于|均在).{0,40}(?:真实|现实|行业|规格|标准|范围)|(?:典型|真实|行业|标准).{0,40}(?:标定|尺寸|规格|比例|范围|标准)|(?:real[- ]?world|industry|spec(?:ification)?|physically accurate).{0,40}(?:dimension|proportion|range|standard|accurate))/i;
const ASSUMPTION_BOUNDARY = /(?:无外部参考|没有外部参考|基于假设|假设值|(?:值|比例|尺寸|数值|典型值).{0,16}假设|非已核实规格|未验证|内部一致|风格化|用户授权|用户选择|no external reference|assum(?:e|ed|ption)|unverified|stylized)/i;
const UNVERIFIED_MARKER = /(?:unverified|未验证|无法验证|待验证)/i;
const COMPLETION_MARKER = /(?:^|[\s：:。])(?:完成|已完成|交付|complete(?:d)?|delivered)(?:[\s：:。]|$)/i;
const REQUESTED_GOAL_SIGNALS = [
  ['cinematic', /(?:电影感|cinematic)/i],
  ['quality', /(?:高质量|镜头级|产品级|high[- ]?quality|shot[- ]?quality|production[- ]?quality)/i],
  ['realism', /(?:写实|逼真|真实感|realistic|photoreal)/i],
  ['adjustability', /(?:可调|可以调节|参数化|adjustable|configurable|parameterized)/i],
  ['animation', /(?:动画|动态|animation|motion)/i],
  ['simulation', /(?:模拟|仿真|simulation)/i],
  ['rendering', /(?:渲染|render(?:ing)?)/i],
  ['verification', /(?:可靠(?:的)?验证|可靠(?:的)?验收|reliable (?:verification|validation))/i],
];
const MUTATING_VERBS = new Set([
  'component_import', 'component_replace',
  'scene_save', 'scene_save_as', 'tab_create', 'tab_apply', 'connect', 'set_object_parent', 'disconnect_input', 'rename_node', 'delete_node', 'set_parm', 'set_parms',
  'set_keyframes', 'create_spare_parms', 'set_timeline', 'create_bookmark', 'delete_bookmark',
  'hda_create', 'hda_edit', 'hda_set_section', 'hda_patch_section', 'hda_set_interface', 'sop_set_output',
  'set_object_visible', 'layout_nodes', 'camera_fit',
]);
const QUERY_SIDE_EFFECT_VERBS = new Set([
  'component_export',
  ...MUTATING_VERBS,
  'cook_node', 'verify_network', 'build_module', 'test_controls', 'render_frame', 'render_view', 'viewport_screenshot',
]);
const VALIDATION_VERBS = new Set([
  'cook_node', 'describe', 'geo_piece_stats', 'geo_attrib_stats', 'geo_frame_diff', 'render_view',
  'render_frame', 'render_check', 'verify_network', 'geo_point_spacing', 'geo_check_interfaces', 'test_controls',
]);
const RELATION_PATTERN = /(?:coincident|共轴|轴线|anchor(?:ed)? endpoint|锚点|端点|distance|距离|clearance|间隙|intersection|相交|穿插|contact|接触|contain(?:ed)?|包含|insert(?:ed)?|插入|embed(?:ded)?|嵌入|penetrat(?:e|ed|ion)|穿透|tangent|切线|flush|齐平|贴合|bearing|support|承托|ground(?:ed|ing)?|落地|deviation|偏差)/ig;

export function findQueryMutationSteps(steps) {
  return (steps || []).filter((step) => (
    ['houdini_inspect', 'houdini_query'].includes(step.tool)
    && (
      (step.mutatingRawMethods || []).length > 0
      || (step.verbs || []).some((verb) => QUERY_SIDE_EFFECT_VERBS.has(verb.verb))
    )
  )).map((step) => ({
    index: step.index,
    time: step.time,
    tool: step.tool,
    codePreview: step.codePreview,
    mutatingRawMethods: step.mutatingRawMethods || [],
    mutatingVerbs: [...new Set(
      (step.verbs || []).map((verb) => verb.verb).filter((name) => QUERY_SIDE_EFFECT_VERBS.has(name)),
    )],
  }));
}

function messageText(messages) {
  return (messages || []).map((message) => String(message?.text || '')).filter(Boolean).join('\n');
}

function stepIndex(step, fallback) {
  return Number.isFinite(step?.index) ? step.index : fallback;
}

function sceneMutation(step) {
  if (step.recoveredExecution || step.executionReplay || step.canonical?.requestReceipt?.retrieved) return false;
  if (step.failed) return false;
  if ((step.verbs || []).some((verb) => verb.verb === 'build_module' && parseLedgerArgs(verb.args ?? verb.argsText).kwargs.dry_run !== true)) return true;
  if ((step.verbs || []).some((verb) => MUTATING_VERBS.has(verb.verb)
      && !(verb.verb === 'hda_edit' && (verb.result?.scene_writes === 0
        || parseLedgerArgs(verb.args ?? verb.argsText).kwargs.dry_run === true)))) return true;
  return (step.mutatingRawMethods || []).some((name) => !['save', 'render'].includes(String(name)));
}

function confirmedAnswers(indexed) {
  const rows=[];
  for(const step of indexed) {
    if(step.tool!=='ask_user_question' || step.failed)continue;
    const result=tryJson(String(step.resultText ?? step.resultPreview ?? ''));
    for(const answer of Array.isArray(result?.answers)?result.answers:[]) {
      if(typeof answer?.id!=='string'||!answer.id)continue;
      const matches=(step.args?.questions||[]).filter(q=>q.id===answer.id);
      if(matches.length!==1)continue;
      const q=matches[0];
      const selected=Array.isArray(answer.selected)?answer.selected.filter(v=>typeof v==='string'&&v):[];
      const options=selected.flatMap(label=>{
        const found=(q.options||[]).filter(o=>o.label===label);
        return found.length===1 ? [{label,description:found[0].description||''}] : [];
      });
      const custom=typeof answer.custom==='string'?answer.custom.trim():'';
      if(!options.length&&!custom)continue;
      rows.push({index:step.index,question_id:answer.id,selected:options,custom,
        text:[...options.map(o=>`${o.label} ${o.description}`),custom].filter(Boolean).join('\n'),
        question_header:q.header||'',provenance:'successful answer matched by question id; only selected option descriptions and actual custom text'});
    }
  }
  return rows;
}

function handwrittenRelationProbe(step) {
  if(step.failed || ['rolled_back','recovery_unverified'].includes(step.transaction?.status) || step.rollback?.applied)return null;
  // Remove embedded source and comments before looking for actual Python
  // geometry access. This is lexical candidate detection, not dataflow proof.
  const code=String(step.code||'').replace(/'''[\s\S]*?'''|"""[\s\S]*?"""/g,'"embedded_source"')
    .replace(/^\s*#.*$/gm,'');
  const executable=code.replace(/'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"/g,'"literal"').replace(/#.*$/gm,'');
  const directGeometry=/\.\s*(?:geometry(?:AtFrame)?|boundingBox|attribValue|position)\s*\(/.test(executable);
  const measuredGeometry=(step.verbs||[]).some(v=>v.ok!==false&&['geo_piece_stats','geo_attrib_stats'].includes(v.verb));
  if((!directGeometry&&!measuredGeometry)||!/\bprint\s*\(|__result__\s*=/.test(executable))return null;
  const canonical=step.canonical;
  let output=canonical ? [canonical.stdout,canonical.result===undefined?'':JSON.stringify(canonical.result)].filter(Boolean).join('\n') : '';
  if(!canonical) {
    const text=String(step.resultText??step.resultPreview??'');
    const stdout=text.match(/(?:^|\n\n)stdout:\n([\s\S]*?)(?=\n\n[\w_-]+(?:[^\n]*)?:\n|$)/)?.[1];
    const result=text.includes('__result__:')?execResultFromPreview(text):null;
    output=[stdout,result===null||result===undefined?'':JSON.stringify(result)].filter(Boolean).join('\n');
    if(!output&&!/verbs \(\d+\):|operation-evidence:/.test(text))output=text;
  }
  output=output.split('\n').filter(line=>!line.startsWith('[verb] ')).join('\n');
  const relation=new RegExp(RELATION_PATTERN.source+'|gap|offset_error|alignment|同心|对齐|端口','i');
  const numeric=v=>typeof v==='number'&&Number.isFinite(v)||typeof v==='boolean'
    || Array.isArray(v)&&v.length>0&&v.every(numeric);
  const measured=[];
  const inspect=(value,path='')=>{
    if(value===null||typeof value!=='object')return;
    for(const [name,v] of Object.entries(value)) {
      if(['parms','parameters','snippet','code','source_code'].includes(name))continue;
      if(relation.test(path+'/'+name)&&numeric(v))measured.push({field:path+'/'+name,value:v});
      else if(typeof v==='object')inspect(v,path+'/'+name);
    }
  };
  const parsed=canonical?.result??(String(step.resultText??step.resultPreview??'').includes('__result__:')?execResultFromPreview(step.resultText??step.resultPreview):tryJson(output));
  inspect(parsed);
  // Piece-oriented probes often read a governed geometry summary, then emit
  // an empty/non-empty issues list rather than a field literally named
  // "distance". Retain that as a candidate only when executable code contains
  // relationship language and the structured result exposes the diagnostic
  // verdict. This records that a probe happened; it never certifies its maths.
  const relationCode=new RegExp(RELATION_PATTERN.source,'i').test(code);
  const issueVerdict=parsed&&typeof parsed==='object'&&(Array.isArray(parsed.issues)
    || Number.isFinite(parsed.issue_count)||Number.isFinite(parsed.issue_total)
    || typeof parsed.pass==='boolean'||typeof parsed.ok==='boolean');
  if(!measured.length&&relationCode&&issueVerdict) {
    for(const name of ['issue_count','issue_total','pass','ok'])if(numeric(parsed[name]))measured.push({field:'/'+name,value:parsed[name]});
    if(!measured.length&&Array.isArray(parsed.issues))measured.push({field:'/issues/count',value:parsed.issues.length});
  }
  const printed=new RegExp('(?:'+relation.source+')\\s*(?:[:=]\\s*|\\s+)(?:[+-]?\\d|true\\b|false\\b)','i');
  // Structured source dumps are not free-form diagnostic lines.
  const printedMeasurement=!parsed&&output.split('\n').some(line=>printed.test(line));
  if(!measured.length&&!printedMeasurement)return null;
  return {index:step.index,kind:'handwritten_measurement_candidate',
    measuredFields:measured.slice(0,16),
    resultExcerpt:output.slice(0,800),
    scope:'Geometry access and relation-labelled numeric/boolean output observed; correctness, entity scope, thresholds and artistic quality are not certified.'};
}

function visualFreshness(indexed, assistantMessages) {
  const produced=[],inspections=[];
  const key=p=>typeof p==='string'?p.replaceAll('\\','/').replace(/^([A-Z]):/,(_,d)=>d.toLowerCase()+':'):null;
  for(const step of indexed) {
    if(step.recoveredExecution || step.executionReplay || step.canonical?.requestReceipt?.retrieved)continue;
    for(const v of step.verbs||[]) {
      if(!['render_view','render_frame'].includes(v.verb)||v.ok===false||step.failed)continue;
      const result=verbResult(v.result??v.detail);
      const media=step.canonical?.media||[];
      const path=result.output||result.picture||partialJsonString(v.result??v.detail,'output')[0];
      if(typeof path!=='string')continue;
      const target=nodePath(parseLedgerArgs(v.args??v.argsText).positional[0]);
      const kwargs=parseLedgerArgs(v.args??v.argsText).kwargs;
      const view=JSON.stringify([kwargs.direction??null,kwargs.focus_group??null,kwargs.framing??null,kwargs.frame??result.frame??null]);
      const aliases=[path,...media.filter(m=>key(m.from)===key(path)&&!m.error).map(m=>m.to)];
      // Legacy native events only retained the explicit textual relay mapping.
      // Never guess links by matching a basename or content-hash prefix.
      for(const line of String(step.resultText??step.resultPreview??'').split('\n')) {
        const mapped=line.trim().match(/^- (.+?) -> (.+) \(\d+ KB\)$/);
        if(mapped&&key(mapped[1])===key(path))aliases.push(mapped[2]);
      }
      produced.push({index:step.index,verb:v.verb,path,target,view,aliases:aliases.map(key),
        invalidTransaction:step.transaction?.status==='rolled_back'||step.rollback?.applied===true,
        source:result.source||null});
    }
    const vision=classifyVisionEvidence(step);
    if(!['inspection','image_access'].includes(vision.role))continue;
    for(const path of vision.images) {
      const image=[...produced].reverse().find(p=>p.aliases.includes(key(path)));
      const row={index:step.index,path,accessSucceeded:vision.accessOk,
        view:image?.view??null,
        productionIndex:image?.index??null,target:image?.target??null,
        status:!vision.accessOk?'inspection_access_failed':!image?'unlinked_image':image.invalidTransaction?'invalidated_transaction':'no_recorded_change',
        changedAt:[]};
      if(image&&vision.accessOk&&!image.invalidTransaction)for(const later of indexed.filter(s=>s.index>image.index)) {
        const uncertain=later.transaction?.status==='recovery_unverified'||later.rollback?.error
          || (later.failed&&later.rollback?.supported===false);
        if(!sceneMutation(later)&&!uncertain)continue;
        if(uncertain) {
          if(row.status!=='stale_after_recorded_target_change')row.status='freshness_unverified_after_failed_execution';
          row.changedAt.push(later.index);continue;
        }
        const verbs=later.verbs||[];
        if(verbs.length&&verbs.every(v=>['scene_save','layout_nodes','create_bookmark','delete_bookmark'].includes(v.verb)))continue;
        const impact=later.canonical?.execution?.impact;
        const paths=impact?.nodes?.map(n=>n.path)||verbs.flatMap(v=>parseLedgerArgs(v.args??v.argsText).positional.filter(p=>typeof p==='string'&&p.startsWith('/')));
        const target=image.target;
        const matched=target&&paths.some(p=>p===target||target.startsWith(p+'/'));
        if(matched||impact?.global) {
          row.status='stale_after_recorded_target_change';row.changedAt.push(later.index);
        }else {
          if(row.status==='no_recorded_change')row.status='freshness_unverified_after_unscoped_change';
          row.changedAt.push(later.index);
        }
      }
      inspections.push(row);
    }
  }
  const latest=new Map();
  for(const row of inspections)if(row.target) {
    const key=JSON.stringify([row.target,row.view]);
    if(row.accessSucceeded || !latest.get(key)?.accessSucceeded)latest.set(key,row);
  }
  const final=String(assistantMessages?.at(-1)?.text||'');
  const claimsPass=/(?:视觉|图像|各视角).{0,28}(?:通过|确认无误|均正常)|visual.{0,28}(?:passed|verified)/i.test(final)
    && !/(?:视觉|图像).{0,12}(?:未验证|未通过)|visual.{0,12}unverified/i.test(final);
  return {inspections,latestInspections:[...latest.values()],finalClaimsVisualPass:claimsPass,
    scope:'Links rendered paths and canonical relay aliases. Freshness is evaluated through trace end, not inspection time. Latest views are grouped by known target/framing inputs, not inferred complete view coverage. Successful access does not prove correct visual judgement; no_recorded_change is not live validity.'};
}

function stableValue(value) {
  try { return JSON.stringify(value); }
  catch { return String(value); }
}

function isObjectRoot(node) {
  return typeof node === 'string' && /^\/obj\/[^/]+$/.test(node);
}

function specDefaults(spec, target = {}) {
  for (const item of Array.isArray(spec) ? spec : []) {
    if (!item || typeof item !== 'object') continue;
    if (item.type === 'folder') specDefaults(item.parms, target);
    else if (typeof item.name === 'string' && Object.hasOwn(item, 'default')) {
      target[item.name] = item.default;
    }
  }
  return target;
}

function setParmEvents(steps) {
  const events = new Map();
  const controlNodes = new Set();
  for (const step of steps) {
    if (step.failed) continue;
    for (const verb of step.verbs || []) {
      if (verb.verb !== 'create_spare_parms') continue;
      const { positional } = parseLedgerArgs(verb.args ?? verb.argsText);
      const node = nodePath(positional[0]);
      if (node) controlNodes.add(node);
    }
  }
  for (let offset = 0; offset < steps.length; offset++) {
    const step = steps[offset];
    const index = stepIndex(step, offset + 1);
    if (step.failed) continue;
    for (const verb of step.verbs || []) {
      if (verb.ok === false) continue;
      const { positional, kwargs } = parseLedgerArgs(verb.args ?? verb.argsText);
      const node = nodePath(positional[0]);
      if (!node || (!isObjectRoot(node) && !controlNodes.has(node))) continue;
      if (verb.verb === 'create_spare_parms') {
        const result = verbResult(verb.result ?? verb.detail);
        const values = result.leaf_values || specDefaults(kwargs.spec);
        if (!values || Array.isArray(values) || typeof values !== 'object') continue;
        for (const [parm, value] of Object.entries(values)) {
          const key = `${node}\u0000${parm}`;
          const list = events.get(key) || [];
          list.push({ index, node, parm, value, stable: stableValue(value), source: 'default' });
          events.set(key, list);
        }
        continue;
      }
      if (!['set_parm', 'set_parms'].includes(verb.verb)) continue;
      const values = verb.verb === 'set_parm'
        ? { [positional[1]]: positional[2] }
        : positional[1];
      if (!values || Array.isArray(values) || typeof values !== 'object') continue;
      for (const [parm, value] of Object.entries(values)) {
        if (!parm || parm === 'undefined') continue;
        const result = verbResult(verb.result ?? verb.detail);
        if (result.failed && Object.hasOwn(result.failed, parm)) continue;
        const key = `${node}\u0000${parm}`;
        const list = events.get(key) || [];
        list.push({ index, node, parm, value, stable: stableValue(value) });
        events.set(key, list);
      }
    }
  }
  return events;
}

function restoredPerturbations(steps) {
  const validations = steps.map((step, offset) => ({
    index: stepIndex(step, offset + 1),
    valid: !step.failed && (
      ['houdini_inspect', 'houdini_query'].includes(step.tool)
      || (step.verbs || []).some((verb) => VALIDATION_VERBS.has(verb.verb))
    ),
  })).filter((item) => item.valid).map((item) => item.index);
  const restored = [];
  for (const list of setParmEvents(steps).values()) {
    if (list.length < 3 || list[0].stable !== list.at(-1).stable) continue;
    const changed = list.slice(1, -1).find((item) => item.stable !== list[0].stable);
    if (!changed) continue;
    const restore = list.at(-1);
    const validationSteps = validations.filter((index) => index >= changed.index && index <= restore.index);
    if (!validationSteps.length) continue;
    restored.push({
      node: list[0].node,
      parm: list[0].parm,
      original: list[0].value,
      changed: changed.value,
      restored: restore.value,
      setSteps: list.map((item) => item.index),
      validationSteps,
    });
  }
  return restored;
}

function latestGeometryCounts(steps, fromIndex) {
  let latest = null;
  const patterns = [
    /(?:"?points"?|pts|点)\s*[:=]?\s*([\d,]+)[\s,;/|，／]*(?:"?prims"?|primitives?|面)\s*[:=]?\s*([\d,]+)/ig,
    /([\d,]+)\s*(?:点|points?)\s*(?:\/|／|,|，|和|and)\s*([\d,]+)\s*(?:面|prim(?:s|itives?)?)/ig,
  ];
  for (let offset = 0; offset < steps.length; offset++) {
    const step = steps[offset];
    const index = stepIndex(step, offset + 1);
    if (index < fromIndex || step.failed) continue;
    const text = String(step.resultText ?? step.resultPreview ?? '');
    for (const pattern of patterns) {
      for (const match of text.matchAll(pattern)) {
        latest = {
          index,
          points: Number(match[1].replaceAll(',', '')),
          prims: Number(match[2].replaceAll(',', '')),
        };
      }
    }
  }
  return latest;
}

function finalGeometryCountClaim(assistantMessages) {
  const final = String(assistantMessages?.at(-1)?.text || '');
  const matches = [...final.matchAll(/([\d,]+)\s*(?:点|points?)\s*(?:\/|／|,|，|和|and)\s*([\d,]+)\s*(?:面|prim(?:s|itives?)?)/ig)];
  if (!matches.length) return null;
  const match = matches.at(-1);
  return {
    points: Number(match[1].replaceAll(',', '')),
    prims: Number(match[2].replaceAll(',', '')),
  };
}

function auditReviewEvidence(steps, assistantMessages) {
  const sourceReads=[], inspections=[];
  const excerpt=text=>({text:String(text||'').slice(0,1600),truncated:String(text||'').length>1600});
  for(const step of steps) {
    const sourceRef = step.tool==='houdini_resource' && step.args?.kind==='source'
      ? step.args?.ref : step.tool==='houdini_query' ? step.args?.source_ref : undefined;
    if(typeof sourceRef==='string') {
      const page=step.canonical?.result ?? execResultFromPreview(step.resultText??step.resultPreview);
      const available=!step.failed && step.canonical?.ok!==false
        && page?.source_ref===sourceRef && page?.format==='json_text_page' && typeof page.text==='string';
      sourceReads.push({index:step.index,source_ref:sourceRef,
        mode:sourceRef==='index'?'discovery':'source_body',
        status:available?'page_returned':step.failed||step.canonical?.ok===false?'read_failed':'return_unverified',
        ...(available?{offset:page.offset,returned_chars:page.text.length,total_chars:page.total_chars,next_offset:page.next_offset}:{}),
      });
    }
    const vision=classifyVisionEvidence(step);
    const hasImageAccess=['inspection','image_access'].includes(vision.role);
    const nextTime=hasImageAccess
      ? steps.reduce((next,s)=>Number.isFinite(s.time)&&s.time>step.time?Math.min(next,s.time):next,Infinity) : Infinity;
    if(hasImageAccess)inspections.push({index:step.index,images:vision.images,
      accessSucceeded:vision.accessOk,
      toolResult:excerpt(step.resultText??step.resultPreview),
      // Image-only tools have no semantic prose. Retain subsequent model text
      // separately: successful image delivery never certifies that judgement.
      followingAssistant:assistantMessages.filter(m=>Number.isFinite(step.time)&&Number.isFinite(m.time)
        && m.time>=step.time && m.time<=nextTime)
        .map(m=>({time:m.time,...excerpt(m.text)})),
    });
  }
  const discovered=sourceReads.some(r=>r.mode==='discovery'&&r.status==='page_returned');
  const bodyReturned=sourceReads.some(r=>r.mode==='source_body'&&r.status==='page_returned'&&r.returned_chars>0);
  return {
    taskSources:{reads:sourceReads,discoveryWithoutBodyReadObserved:discovered&&!bodyReturned,
      scope:'Records returned source pages only. An index is discovery, not source-body retrieval; pages may be partial. Original input or injected excerpts may already be available. No inference of model consumption, requirement completeness or permission.'},
    visualComparison:{inspections,finalStatement:excerpt(assistantMessages.at(-1)?.text),
      verdict:'requires_semantic_review',
      scope:'Compare inspection results, subsequent model interpretation and final claims manually, with image version and target scope. Access success does not mean visual correctness; conflicting, agreeing and ambiguous prose are not classified by keywords.'},
    probeScope:'Handwritten probes remain candidates; entity coverage, thresholds, geometry dataflow and relation correctness require source review even when a numeric result exists.',
  };
}

/**
 * Task, measurement and claim evidence. Lexical fields are navigation cues;
 * they cannot mandate a modeling workflow or certify completion.
 */
export function collectQualityLoopEvidence({
  steps = [], userMessages = [], assistantMessages = [], availableTools = [], activatedSkills = [],
} = {}) {
  const request = messageText(userMessages);
  const assistant = messageText(assistantMessages);
  let applicable = OPEN_ENDED_QUALITY_REQUEST.test(request)
    || PROCEDURAL_ASSEMBLY_QUALITY_REQUEST.test(request)
    || /(?:精细|细致|近景|测绘|实景|表面质感|close[- ]?up|fine detail|surface texture|survey reference)/i.test(request);
  const indexed = steps.map((step, offset) => ({ ...step, code: step.code, resultText: step.resultText, canonical:step.canonical,
    index: stepIndex(step, offset + 1) }));
  const firstMutation = indexed.find(sceneMutation) || null;
  const firstMutationTime = firstMutation?.time ?? Infinity;
  const clarifications=confirmedAnswers(indexed);
  const initialChoices=clarifications.filter(row=>!firstMutation||row.index<firstMutation.index);
  const confirmedChoiceText=initialChoices.map(row=>row.text);
  const agreedRequest=[request,...confirmedChoiceText].join('\n');
  applicable ||= OPEN_ENDED_QUALITY_REQUEST.test(confirmedChoiceText.join('\n'))
    || PROCEDURAL_ASSEMBLY_QUALITY_REQUEST.test(confirmedChoiceText.join('\n'))
    || /高细节|精细|近景|high[- ]detail|close[- ]up/i.test(confirmedChoiceText.join('\n'));
  const preMutationText = [
    ...confirmedChoiceText,
    messageText(userMessages.filter(message=>!Number.isFinite(message.time)||message.time<=firstMutationTime)),
    messageText(
      assistantMessages.filter((message) => !Number.isFinite(message.time) || message.time <= firstMutationTime),
    ),
    ...indexed.filter((step) => (
      (!firstMutation || step.index < firstMutation.index)
      && ['create_goal', 'todo_write'].includes(String(step.tool || ''))
    )).map((step) => JSON.stringify(step.args || {})),
  ].filter(Boolean).join('\n');
  const contractFields = {
    target: /(?:目标|对象|效果|target|deliverable|交付)/i.test(preMutationText),
    referenceStatus: /(?:参考|来源|无外部参考|假设|reference|source)/i.test(preMutationText),
    qualityLod: /(?:质量(?:标准|门|级别)|LOD|轮廓级|镜头级|产品级|预览级|观察距离|高细节|细节丰富|精细|细致|近景|high[- ]detail|fine detail|close[- ]up|quality bar|quality level)/i.test(preMutationText),
    simplifications: /(?:简化|省略|不做|允许.*(?:略|省)|边界|simplif|omit|out of scope)/i.test(preMutationText),
    unitsDimensions: /(?:单位|尺寸|范围|半径|长度|角度|米|厘米|mm|cm|\bm\b|units?|dimensions?)/i.test(preMutationText),
    controls: /(?:总控|统一调整|联动|控制参数|可调参数|需要暴露|spare parm|HDA interface|controls?)/i.test(preMutationText),
    relations: /(?:连接|装配|接地|贴轮|贴合|不炸|共轴|轴线|端点|包含|间隙|穿插|接触|关系|relations?|clearance|intersection)/i.test(preMutationText),
    evidencePlan: /(?:验证|验收|证据|视角|特写|render|evidence|check)/i.test(preMutationText),
  };
  const requiresControls = /(?:总控|统一调整|联动|程序化|可调|可以调节|参数化|controls?|procedural|parameter[- ]driven|adjustable|configurable|parameterized)/i.test(agreedRequest);
  const requiresRelations = /(?:连接|装配|机械|结构|穿插|间隙|自行车|汽车|车辆|产品|建筑|角色|assembly|mechanical|structur|intersection|clearance)/i.test(agreedRequest);

  const researchSteps = indexed.filter((step) => /(?:web_search|browser|research)/i.test(String(step.tool || '')))
    .map((step) => step.index);
  const userProvidedReference = /(?:https?:\/\/|参考(?:图|文件|链接|如下)|规格表|用户提供|attached reference|reference (?:image|file|link))/i.test(request);
  const userAuthorizedNoResearch = /(?:不要|无需|不需要|不用).{0,12}(?:外部)?参考|(?:风格化|抽象).{0,12}(?:即可|就行)|(?:比例|尺寸|造型).{0,12}(?:你决定|自行决定)|no (?:external )?reference|do not research/i.test(request);
  const externalTruthClaims = (assistantMessages || []).filter((message) => EXTERNAL_TRUTH_SIGNAL.test(String(message.text || '')));
  const unsupportedExternalTruthClaims = externalTruthClaims.filter(
    (message) => !ASSUMPTION_BOUNDARY.test(String(message.text || '')),
  ).map((message) => ({ time: message.time, text: String(message.text || '').slice(0, 500) }));
  const assumptionBoundaryDisclosed = ASSUMPTION_BOUNDARY.test(preMutationText) || ASSUMPTION_BOUNDARY.test(assistant);

  const firstRender = indexed.find((step) => (
    !step.failed && (step.verbs || []).some((verb) => ['render_view', 'render_frame'].includes(verb.verb))
  )) || null;
  const tabCreatesBeforeFirstRender = indexed
    .filter((step) => !firstRender || step.index < firstRender.index)
    .reduce((sum, step) => sum + (step.verbs || []).filter((verb) => verb.verb === 'tab_create' && verb.ok !== false).length, 0);
  const skeletonCheckpointMentions = (assistantMessages || []).filter((message) => {
    const text = String(message.text || '');
    return /(?:骨架|中心线|代理体|anchors?).{0,60}(?:验证|验收|通过|成功|check|validate)/i.test(text)
      || /(?:验证|验收|通过|成功|check|validate).{0,60}(?:骨架|中心线|代理体|anchors?)/i.test(text);
  }).map((message) => ({ time: message.time, text: String(message.text || '').slice(0, 300) }));
  if (firstRender) {
    for (const verb of firstRender.verbs || []) {
      if (verb.verb !== 'render_view' || verb.ok === false) continue;
      const target = nodePath(parseLedgerArgs(verb.args ?? verb.argsText).positional[0]);
      if (target && /(?:skeleton|proxy|blockout|anchors?|骨架|代理)/i.test(target)) {
        skeletonCheckpointMentions.push({time: firstRender.time, index: firstRender.index,
          text: `Explicit skeleton/proxy render target: ${target}`, source: 'render_target'});
      }
    }
  }

  const relationshipProbeSteps = [];
  const relationCandidates=[];
  const relationshipKeywords = new Set();
  for (const step of indexed) {
    if (!step.failed && !['rolled_back','recovery_unverified'].includes(step.transaction?.status) && !step.rollback?.applied && (step.verbs || []).some(v => v.ok!==false && (v.verb === 'geo_check_interfaces'
        || (v.verb === 'build_module' && verbResult(v.result ?? v.detail).interface_checks)))) {
      relationshipProbeSteps.push(step.index);
      relationshipKeywords.add('declared_final_surface_interfaces');
    }
    const candidate=handwrittenRelationProbe(step);
    if(!candidate)continue;
    relationCandidates.push(candidate);
    relationshipProbeSteps.push(step.index);
    for (const hit of candidate.resultExcerpt.matchAll(RELATION_PATTERN)) relationshipKeywords.add(hit[0].toLowerCase());
  }

  const perturbations = restoredPerturbations(indexed);
  const controlTests = indexed.flatMap(step => (step.verbs || []).filter(v => v.verb === 'test_controls')
    .map(v => ({index:step.index, ...verbResult(v.result ?? v.detail)})));
  for(const step of indexed.filter(s=>s.args?.review_test && !s.failed)) {
    const result=execResultFromPreview(step.resultText || step.resultPreview || '');
    if(result?.cases?.length)controlTests.push({index:step.index,...result,results:result.cases,
      executed:result.cases.some(c=>c.actual_values && c.restored===true)});
  }
  const lastMutation = [...indexed].reverse().find(sceneMutation) || null;
  const latestCounts = latestGeometryCounts(indexed, lastMutation?.index ?? 0);
  const finalCountClaim = finalGeometryCountClaim(assistantMessages);
  const finalCountMatchesEvidence = !finalCountClaim || !latestCounts
    ? null
    : finalCountClaim.points === latestCounts.points && finalCountClaim.prims === latestCounts.prims;
  const checkpoints = new Map();
  for (const step of indexed) {
    if (step.transaction?.status === 'rolled_back' || step.rollback?.applied === true) continue;
    for (const node of step.transaction?.nodes || []) {
      if (node.exists === false && node.prior_path && step.transaction.status === 'committed') {
        for (const value of checkpoints.values()) if (value.output === node.prior_path) {
          value.lifecycle = 'removed'; value.removedAt = step.index;
        }
      }
    }
    for (const verb of step.verbs || []) {
      if (!['verify_network','build_module'].includes(verb.verb)) continue;
      const raw = verbResult(verb.result ?? verb.detail);
      const r = raw.validation || raw;
      if (typeof r.output !== 'string' || typeof r.ok !== 'boolean') continue;
      // A successful check in a different scope cannot erase a failed one.
      const key = JSON.stringify([r.output, r.scope, r.scope_signature ?? r.checked_nodes ?? null]);
      checkpoints.set(key, {index: step.index, output:r.output, scope:r.scope ?? null,
        ok:r.ok, reasons:r.failure_reasons ?? (r.nonempty === false ? ['empty_output'] : [])});
    }
  }

  return {
    applicable,
    manualReview:auditReviewEvidence(indexed,assistantMessages),
    outputCheckpoints: [...checkpoints.values()],
    requestSignals: [...new Set(request.match(OPEN_ENDED_QUALITY_REQUEST) || [])],
    available: {
      webSearch: availableTools.some((name) => /web_search|browser/i.test(String(name))),
      tools: [...new Set(availableTools)].sort(),
    },
    contract: {
      clarifications,
      detectionScope:'Lexical evidence of stated fields and matched user answers, not proof that acceptance criteria are measurable, complete or satisfied.',
      firstMutationIndex: firstMutation?.index ?? null,
      requirements: { controls: requiresControls, relations: requiresRelations },
      fields: contractFields,
    },
    reference: {
      researchSteps,
      userProvidedReference,
      userAuthorizedNoResearch,
      externalTruthClaimCount: externalTruthClaims.length,
      unsupportedExternalTruthClaims,
      assumptionBoundaryDisclosed,
    },
    skeleton: {
      firstRenderIndex: firstRender?.index ?? null,
      tabCreatesBeforeFirstRender,
      checkpointMentions: skeletonCheckpointMentions,
    },
    relations: {
      candidates:relationCandidates,
      probeSteps: [...new Set(relationshipProbeSteps)],
      keywords: [...relationshipKeywords].sort(),
    },
    perturbation: {
      restored: perturbations,
      controlTests,
    },
    freshness: {
      visual:visualFreshness(indexed,assistantMessages),
      lastMutationIndex: lastMutation?.index ?? null,
      latestGeometryCounts: latestCounts,
      finalGeometryCountClaim: finalCountClaim,
      finalCountMatchesEvidence,
    },
  };
}

/**
 * Find user-requested quality dimensions that the final delivery itself leaves
 * unverified while also presenting the task as complete. This is an audit risk,
 * not an automatic artistic-quality verdict.
 */
export function requestedGoalReportedUnverified(userMessages = [], assistantMessages = []) {
  const request = messageText(userMessages);
  const final = String(assistantMessages?.at(-1)?.text || '');
  if (!COMPLETION_MARKER.test(final)) return [];
  const unverifiedLines = final.split(/\r?\n/).filter((line) => UNVERIFIED_MARKER.test(line));
  if (!unverifiedLines.length) return [];
  return REQUESTED_GOAL_SIGNALS.flatMap(([signal, pattern]) => {
    if (!pattern.test(request)) return [];
    const line = unverifiedLines.find((candidate) => pattern.test(candidate));
    return line ? [{ signal, line: line.trim().slice(0, 500) }] : [];
  });
}

export function qualityLoopRisks(evidence) {
  const risks = [];
  if (!evidence) return risks;
  const visual=evidence.freshness?.visual;
  if(visual?.finalClaimsVisualPass && visual.latestInspections.some(r=>r.status==='stale_after_recorded_target_change'))risks.push({
    code:'visual_completion_claim_with_stale_evidence',
    detail:'Final visual-pass language coexists with latest inspected views preceding a recorded target change. Review claim scope; this is not an automatic artistic-quality verdict.',
    inspections:visual.latestInspections.filter(r=>r.status==='stale_after_recorded_target_change')});
  if (evidence.available.webSearch
      && evidence.reference.externalTruthClaimCount
      && !evidence.reference.userProvidedReference
      && !evidence.reference.userAuthorizedNoResearch
      && !evidence.reference.researchSteps.length) {
    risks.push({
      code: 'external_reference_available_but_unused',
      detail: 'External-truth language was used while web/research capability was available, but no research call was recorded.',
    });
  }
  if (evidence.reference.unsupportedExternalTruthClaims.length) {
    risks.push({
      code: 'external_truth_without_source',
      detail: `${evidence.reference.unsupportedExternalTruthClaims.length} external-truth claim(s) lack a source or an assumption boundary.`,
    });
  }
  if (evidence.contract.requirements.controls && !evidence.perturbation.restored.length
      && !(evidence.perturbation.controlTests || []).some(t => (t.ok === true || t.executed === true) && t.restored === true && t.results?.length)) {
    risks.push({
      code: 'procedural_control_not_perturbed',
      detail: 'User control intent was detected, but no set → validate → restore observation was recorded. Review whether this matters to the requested delivery; this is not a mandatory workflow.',
    });
  }
  if (evidence.contract.requirements.relations && !evidence.relations.probeSteps.length) {
    risks.push({
      code: 'relationship_contract_without_evidence',
      detail: 'Relationship intent was detected in the user task, but no relationship-oriented measurement was recorded. Review scope against the requested result; geometry or visual evidence may use other methods.',
    });
  }
  const contradictoryRelationCandidates=(evidence.relations.candidates||[]).filter(candidate=>{
    const fields=Object.fromEntries((candidate.measuredFields||[]).map(row=>[row.field,row.value]));
    const count=fields['/issue_count']??fields['/issue_total']??fields['/issues/count'];
    return (count===0&&fields['/pass']===false)||(typeof count==='number'&&count>0&&fields['/pass']===true);
  });
  if(contradictoryRelationCandidates.length)risks.push({
    code:'handwritten_relation_probe_conflict',
    detail:'A handwritten relationship probe reported an issue count and pass verdict that contradict each other. Treat the checker as failed/unverified until its formula and final verdict are corrected and rerun.',
    candidates:contradictoryRelationCandidates});
  if (evidence.freshness.finalCountMatchesEvidence === false) {
    risks.push({
      code: 'stale_final_geometry_counts',
      detail: 'The final points/prims claim does not match the latest post-mutation geometry evidence.',
      claim: evidence.freshness.finalGeometryCountClaim,
      evidence: evidence.freshness.latestGeometryCounts,
    });
  }
  const unresolved = (evidence.outputCheckpoints || []).filter(c => !c.ok);
  if (unresolved.length) risks.push({code:'unresolved_output_checkpoints',
    detail:'Output checkpoints failed without a later successful check of the same output/scope. Diagnostic probes may be intentional; review against the deliverable contract.',
    checkpoints:unresolved});
  return risks;
}

export function completedVisionTodoWithoutEvidence(latestTodo, successfulVisionEvidence = []) {
  if ((successfulVisionEvidence || []).length > 0) return false;
  return Boolean((latestTodo || []).some((item) => {
    const content = String(item?.content || '');
    return item?.status === 'completed'
      && /(?:\bvision\b|视觉|图像检查|图片检查)/i.test(content)
      && !/(?:unverified|未验证|无法|失败|不可用|凭据|待用户|人工确认|交给用户)/i.test(content);
  }));
}

export function collectValidationCoverage(steps) {
  const geometry = [];
  const renders = [];
  const comparisons = [];
  const vision = [];

  for (const step of steps) {
    const fullResult = step.resultText ?? step.resultPreview;
    const execResult = execResultFromPreview(fullResult);
    const renderOutputs = renderOutputsFromPreview(fullResult);
    let renderOutputIndex = 0;
    for (const verb of step.verbs || []) {
      const { positional, kwargs } = parseLedgerArgs(verb.args ?? verb.argsText);
      const ledgerResult = verbResult(verb.result ?? verb.detail);
      const result = Object.keys(ledgerResult).length ? ledgerResult : execResult;
      if (verb.verb === 'geo_frame_diff') {
        const frameA = finiteFrame(positional[1]);
        const frameB = finiteFrame(positional[2]);
        geometry.push({
          index: step.index,
          time: step.time,
          node: nodePath(positional[0]),
          attrib: kwargs.attrib ?? positional[3] ?? 'P',
          frame_a: frameA,
          frame_b: frameB,
          frames: uniqueFrames([frameA, frameB]),
          ok: verb.ok,
        });
      } else if (verb.verb === 'render_view' || verb.verb === 'render_frame') {
        const frame = finiteFrame(kwargs.frame ?? result.frame);
        const framingFrame = finiteFrame(kwargs.framing_frame ?? result?.framing?.frame);
        const output = result.output ?? result.image ?? kwargs.picture
          ?? renderOutputs[renderOutputIndex] ?? null;
        renderOutputIndex++;
        renders.push({
          index: step.index,
          time: step.time,
          verb: verb.verb,
          target: nodePath(positional[0]),
          frame: frame ?? frameFromPath(output),
          framing_frame: framingFrame,
          output,
          ok: verb.ok,
        });
      } else if (verb.verb === 'render_check') {
        const partial = verb.result ?? verb.detail;
        const imagePath = positional[0] ?? result.path ?? null;
        const ref = kwargs.ref ?? null;
        const contentBbox = result.content_bbox ?? result.contentBbox
          ?? partialJsonArray(partial, 'content_bbox') ?? null;
        const width = result.width ?? partialJsonNumber(partial, 'width');
        const height = result.height ?? partialJsonNumber(partial, 'height');
        const imageSize = result.size ?? result.image_size
          ?? (width !== null && height !== null ? [width, height] : null);
        const touchesEdge = Array.isArray(contentBbox) && contentBbox.length === 4
          && Array.isArray(imageSize) && imageSize.length >= 2
          ? contentBbox[0] <= 0 || contentBbox[1] <= 0
            || contentBbox[2] >= Number(imageSize[0]) - 1
            || contentBbox[3] >= Number(imageSize[1]) - 1
          : null;
        comparisons.push({
          index: step.index,
          time: step.time,
          path: imagePath,
          ref,
          content_bbox: contentBbox,
          image_size: imageSize,
          touches_edge: touchesEdge,
          frames: uniqueFrames([frameFromPath(imagePath), frameFromPath(ref)]),
          ok: verb.ok,
        });
      }
    }

    if (String(step.tool || '').startsWith('vision_') || step.tool === 'read_image') {
      const outcome = classifyVisionEvidence(step);
      vision.push({
        index: step.index,
        time: step.time,
        tool: step.tool,
        ...outcome,
      });
    }
  }

  const geometryFrames = uniqueFrames(geometry.flatMap((item) => item.frames));
  const renderFrames = uniqueFrames(renders.map((item) => item.frame));
  const framingFrames = uniqueFrames(renders.map((item) => item.framing_frame));
  const comparisonFrames = uniqueFrames(comparisons.flatMap((item) => item.frames));
  const visionFrames = uniqueFrames(vision.flatMap((item) => item.frames));
  const visionInspectionFrames = uniqueFrames(
    vision.filter((item) => ['inspection','image_access'].includes(item.role)).flatMap((item) => item.frames),
  );
  return {
    geometry,
    renders,
    comparisons,
    vision,
    frames: {
      geometry: geometryFrames,
      render: renderFrames,
      framing: framingFrames,
      comparison: comparisonFrames,
      vision: visionFrames,
      visionInspection: visionInspectionFrames,
      all: uniqueFrames([
        ...geometryFrames,
        ...renderFrames,
        ...comparisonFrames,
        ...visionFrames,
      ]),
    },
  };
}
