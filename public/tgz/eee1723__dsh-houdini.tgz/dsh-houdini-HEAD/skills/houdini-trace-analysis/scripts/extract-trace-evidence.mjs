#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCatalog } from '../../../tools/catalog-lib.mjs';
import {
  loadSessionEvents,
  newestSessionFile,
  resolveSessionFile,
  sessionIdFromFile,
  collectRequestTelemetry,
  collectRequestContexts,
} from '../../../tools/trace-session-lib.mjs';
import { normalizeTraceSteps, unresolvedExecutionRequests } from '../../../tools/normalized-trace-steps.mjs';
import { executionHistory } from '../../../lib/execution-history.js';
import {
  collectValidationCoverage,
  collectRetryWork,
  collectQualityLoopEvidence,
  completedVisionTodoWithoutEvidence,
  classifyVisionEvidence,
  nativeImageEvidence,
  linkNativeImageResponses,
  collectVerbAdoption,
  classifyRawEffect,
  isHoudiniHostCall,
  isStructuredHoudiniCall,
  skillCatalogNames,
  findBatchSetParmOpportunities,
  findQueryMutationSteps,
  findSuppressedCookFailures,
  qualityLoopRisks,
  requestedGoalReportedUnverified,
} from './evidence-helpers.mjs';

const SKILL_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PACKAGE_ROOT = path.resolve(SKILL_ROOT, '..', '..');

function usage() {
  console.log(`Usage:
  node extract-trace-evidence.mjs [sessionDir|session.jsonl.zstd ...]
       [--catalog <tool-design.md>] [--out <evidence.json>]
       [--max-preview <chars>] [--compact]

With no session argument, analyzes the newest ~/.dsh/sessions trace.
Multiple inputs produce per-trace evidence plus cross-trace aggregate counts.`);
}

const argv = process.argv.slice(2);
const inputs = [];
let catalogPath = path.join(PACKAGE_ROOT, 'docs', 'tool-design.md');
let outPath = null;
let maxPreview = 3000;
let compact = false;
for (let i = 0; i < argv.length; i++) {
  const arg = argv[i];
  if (arg === '--help' || arg === '-h') { usage(); process.exit(0); }
  if (arg === '--catalog') catalogPath = path.resolve(argv[++i]);
  else if (arg === '--out') outPath = path.resolve(argv[++i]);
  else if (arg === '--max-preview') maxPreview = Number(argv[++i]);
  else if (arg === '--compact') compact = true;
  else if (arg.startsWith('--')) throw new Error(`unknown option: ${arg}`);
  else inputs.push(arg);
}
if (!Number.isSafeInteger(maxPreview) || maxPreview < 200) {
  throw new Error('--max-preview must be an integer >= 200');
}

const latest = inputs.length ? null : newestSessionFile();
if (!inputs.length && !latest) throw new Error('no session.jsonl.zstd under the DSH session store');
const sessionFiles = (inputs.length ? inputs : [latest]).map(resolveSessionFile);
const catalog = loadCatalog(catalogPath);
const catalogNames = catalog.flatMap((domain) => domain.verbs.map((verb) => verb.name));
const catalogByName = new Map();
for (const domain of catalog) {
  for (const verb of domain.verbs) catalogByName.set(verb.name, { domain: domain.domain, ...verb });
}

const clip = (value, max = maxPreview) => {
  const text = String(value ?? '');
  return text.length <= max ? text : `${text.slice(0, max)}…[+${text.length - max}ch]`;
};
const addCount = (target, key, amount = 1) => { target[key] = (target[key] || 0) + amount; };
const sortCounts = (counts) => Object.fromEntries(
  Object.entries(counts).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])),
);
const digest = (text) => crypto.createHash('sha256').update(text).digest('hex').slice(0, 16);

function directText(content) {
  return (content || []).filter((item) => item.type === 'text').map((item) => item.text).join('\n');
}

function analyzeTrace(file) {
  const loaded = loadSessionEvents(file);
  const { events } = loaded;
  const executionObservations = executionHistory(events);
  const normalized = normalizeTraceSteps(events);
  const { replayedResults, unmatchedResults } = normalized;

  const userMessages = [];
  const assistantMessages = [];
  const capabilitySnapshots = [];
  const skillCatalogSnapshots = [];
  const seenCapabilityHashes = new Set();
  const steps = [];
  const toolCounts = {};
  const verbCounts = {};
  const verbFailures = {};
  const rawMethodCounts = {};
  let firstTime = Infinity;
  let lastTime = 0;
  let lastToolTime = 0;
  let firstToolTime = Infinity;
  let lastAssistantTime = 0;

  for (const event of events) {
    if (Number.isFinite(event.time)) {
      firstTime = Math.min(firstTime, event.time);
      lastTime = Math.max(lastTime, event.time);
    }
    if (event.type === 'user/message') {
      const text = directText(event.data.content);
      const availableSkills = skillCatalogNames(event.data);
      if (availableSkills.length) {
        skillCatalogSnapshots.push({
          seq: event.seq,
          time: event.time,
          turn: event.data?.turn,
          step: event.data?.step,
          skills: availableSkills,
        });
      }
      if (event.data?.source?.kind === 'user'
          && text && !text.startsWith('<system-reminder>')
          && !text.startsWith('Current runtime context')) {
        userMessages.push({ seq: event.seq, time: event.time, text });
      }
    } else if (event.type === 'assistant/message') {
      const text = directText(event.data?.message?.content);
      if (text.trim()) {
        assistantMessages.push({ seq: event.seq, time: event.time, text });
        lastAssistantTime = Math.max(lastAssistantTime, event.time || 0);
      }
    }
  }

  const requestContexts = collectRequestContexts(events, {includeSystemText:true});
  for (const context of requestContexts) {
    const system = context.systemText || "";
    const availableTools = context.availableTools;
    const snapshotHash = digest(JSON.stringify({system:context.systemHash,availableTools}));
    if ((!context.projectionComplete || system || availableTools?.length) && !seenCapabilityHashes.has(snapshotHash)) {
      seenCapabilityHashes.add(snapshotHash);
      const listedSkills = [...system.matchAll(/^- `([^`]+)`: /gm)].map(match=>match[1]);
      capabilitySnapshots.push({
        seq:context.seq,time:context.time,turn:context.turn,step:context.step,model:context.model,
        systemChars:context.systemChars,systemHash:context.systemHash,
        systemSource:context.systemSource,projectionComplete:context.projectionComplete,projectionError:context.projectionError,
        personaLines:context.projectionComplete ? system.split('\n').filter(line=>/^You are (?:a|an) /.test(line)).slice(0,4) : null,
        mentionedCatalogVerbs:context.projectionComplete ? catalogNames.filter(name=>new RegExp(`\\b${name}\\b`).test(system)) : null,
        availableTools,availableSkills:listedSkills.length ? listedSkills : null,
      });
    }
  }

  for (const source of normalized.steps) {
    const code = source.code;
    const verbs = source.verbs.map((verb) => ({
      ledgerIndex: verb.ledgerIndex,
      ok: verb.ok,
      verb: verb.verb,
      args: clip(verb.args),
      result: verb.result,
      ms: verb.ms,
    }));
    const step = {
      index: source.index,
      callSeq: source.callSeq,
      resultSeq: source.resultSeq,
      time: source.time,
      callTime: source.callTime,
      durationMs: source.durationMs,
      canonical: compact ? undefined : source.canonical,
      canonicalStatus: source.canonicalStatus,
      executionScopes: source.executionScopes,
      recoveredExecution: source.recoveredExecution,
      executionReplay: source.executionReplay,
      turn: source.turn,
      step: source.step,
      tool: source.tool,
      isHoudini: source.isHoudini,
      failed: source.failed,
      processOutcome: source.processOutcome,
      args: compact && code ? { ...source.args, code: undefined } : source.args,
      codeChars: code.length,
      codeHash: code ? digest(code) : null,
      code: compact ? undefined : code,
      codePreview: code ? clip(code.replace(/\s+/g, ' '), 800) : null,
      resultPreview: clip(source.resultText),
      verbs,
      rawMethods: source.rawMethods,
      mutatingRawMethods: source.mutatingRawMethods,
      advisory: source.advisory,
      transaction: source.transaction,
      rollback: source.rollback?._raw ? { _raw: clip(source.rollback._raw) } : source.rollback,
      rawUsage: source.rawUsage?._raw ? { _raw: clip(source.rawUsage._raw) } : source.rawUsage,
    };
    if (compact && source.canonical) Object.defineProperty(step,'canonical',{value:source.canonical,enumerable:false});
    // Keep the unabridged result only in memory for coverage extraction. It is
    // deliberately non-enumerable so compact/full evidence JSON does not
    // duplicate potentially huge tool output, while render paths and nested
    // render_check facts remain recoverable before serialization.
    Object.defineProperty(step, 'resultText', { value: source.resultText, enumerable: false });
    // Compact is a serialization choice, not an analysis input. Dropping code
    // here used to erase relationship probes from otherwise identical traces.
    Object.defineProperty(step, 'code', { value: code, enumerable: !compact });
    steps.push(step);
    firstToolTime = Math.min(firstToolTime, source.callTime ?? source.time ?? Infinity);
    lastToolTime = Math.max(lastToolTime, source.time || 0);
    addCount(toolCounts, step.tool);
    for (const method of source.rawMethods) addCount(rawMethodCounts, method);
    for (const verb of verbs) {
      addCount(verbCounts, verb.verb);
      if (!verb.ok) addCount(verbFailures, verb.verb);
    }
  }

  const failedCalls = steps.filter((step) => step.failed).map((step) => ({
    index: step.index,
    time: step.time,
    tool: step.tool,
    resultPreview: step.resultPreview,
  }));
  const processFailures = steps.filter(step => step.processOutcome?.status === 'failed').map(step => ({
    index:step.index,callSeq:step.callSeq,resultSeq:step.resultSeq,time:step.time,
    tool:step.tool,toolFailed:step.failed,...step.processOutcome,resultPreview:step.resultPreview,
  }));
  const processInterruptions = steps.filter(step => step.processOutcome?.status === 'interrupted').map(step => ({
    index:step.index,callSeq:step.callSeq,resultSeq:step.resultSeq,time:step.time,
    tool:step.tool,toolFailed:step.failed,...step.processOutcome,resultPreview:step.resultPreview,
  }));
  const failedVerbCalls = steps.flatMap((step) => step.verbs
    .filter((verb) => !verb.ok)
    .map((verb) => ({ index: step.index, time: step.time, ...verb })));
  const partialParameterFailures = steps.flatMap((step) => step.verbs
    .filter((verb) => verb.verb === 'set_parms' && verb.ok && verb.result?.failed && Object.keys(verb.result.failed).length)
    .map((verb) => ({index: step.index, time: step.time, failed: verb.result.failed})));
  const rawHoudiniNoVerb = steps.filter((step) => step.isHoudini && !isHoudiniHostCall(step) && !isStructuredHoudiniCall(step) && !step.verbs.length).map((step) => ({
    index: step.index,
    time: step.time,
    tool: step.tool,
    codePreview: step.codePreview,
    rawMethods: step.rawMethods,
    mutatingRawMethods: step.mutatingRawMethods,
    effect: classifyRawEffect(step),
    rawUsage: step.rawUsage,
  }));
  const rawMutationSteps = steps.filter(
    (step) => step.isHoudini && step.mutatingRawMethods.length,
  ).map((step) => ({
    index: step.index,
    time: step.time,
    tool: step.tool,
    codePreview: step.codePreview,
    mutatingRawMethods: step.mutatingRawMethods,
    mixedWithVerbs: step.verbs.length > 0,
  }));
  const verblessMutations = rawMutationSteps.filter((step) => !step.mixedWithVerbs);
  // Kept for schema compatibility; absence of detected writes never proves an
  // exec was read-only. Unknown dynamic calls are retained with their evidence.
  const execUsedForReadOnly = [];
  const execWithoutVerbEvidence = rawHoudiniNoVerb.filter(step => step.tool === 'houdini_exec');
  const queryWithMutation = findQueryMutationSteps(steps);
  const batchSetParmOpportunities = findBatchSetParmOpportunities(steps);
  const suppressedCookFailureSteps = findSuppressedCookFailures(steps);
  const renderEvidence = steps.flatMap((step) => step.verbs
    .filter((verb) => ['render_view', 'render_frame', 'render_check'].includes(verb.verb))
    .map((verb) => ({ index: step.index, time: step.time, verb: verb.verb, ok: verb.ok, result: verb.result })));
  const visionEvidence = steps.filter(
    (step) => step.tool.startsWith('vision_') || step.tool === 'read_image',
  ).map((step) => ({
    index: step.index,
    time: step.time,
    tool: step.tool,
    args: step.args,
    resultPreview: step.resultPreview,
    ...classifyVisionEvidence(step),
  }));
  const successfulVisionEvidence = visionEvidence.filter(
    (item) => ['inspection','image_access'].includes(item.role) && item.accessOk === true,
  );
  const nativeImages = linkNativeImageResponses(nativeImageEvidence(steps), steps, events);
  const skillActivations = steps.filter((step) => step.tool === 'skill').map((step) => ({
    index: step.index,
    time: step.time,
    name: typeof step.args?.name === 'string' ? step.args.name : null,
    succeeded: !step.failed,
  }));
  const qualityLoopEvidence = collectQualityLoopEvidence({
    steps,
    userMessages,
    assistantMessages,
    availableTools: capabilitySnapshots.flatMap((snapshot) => snapshot.availableTools || []),
    activatedSkills: skillActivations.filter((item) => item.succeeded).map((item) => item.name),
  });
  const completionRisks = [];
  const unresolvedRequests = unresolvedExecutionRequests(normalized.steps);
  if (unresolvedRequests.length) completionRisks.push({code: 'unresolved_execution_receipt',
    detail: `${unresolvedRequests.length} request(s) have nonterminal or uncertain observations; running/queued differ from unknown transport. These are retained trace states, not live checks or completed outcomes.`,
    steps: unresolvedRequests.map(item => item.index)});
  if (executionObservations.activeJobs.length) completionRisks.push({code: 'active_houdini_jobs',
    detail: 'Retained job observations are nonterminal or their results remain uncollected. A recovered submission receipt does not establish job completion; these are trace observations, not current live status.',
    jobs: executionObservations.activeJobs});
  if (executionObservations.unavailableResults.length) completionRisks.push({code: 'execution_result_unavailable',
    detail: 'Execution/job results were observed unavailable after retention. Finished does not establish their outcome; retained observations remain unverified.',
    results: executionObservations.unavailableResults});
  const turnEnd = [...events].reverse().find((event) => event.type === 'turn/end') || null;
  const terminalReason = turnEnd?.data?.reason || null;
  const terminalMessage = String(
    terminalReason?.error?.message
    || terminalReason?.failure?.message
    || terminalReason?.message
    || '',
  );
  const terminalCode = terminalReason?.error?.code || terminalReason?.failure?.code || terminalReason?.code || null;
  const terminalCategory = /insufficient_quota|quota has been exhausted/i.test(terminalMessage)
    ? 'quota_exhausted'
    : terminalReason?.kind === 'error'
      ? 'external_error'
      : terminalReason?.kind || null;
  if (terminalCategory === 'quota_exhausted') {
    completionRisks.push({
      code: 'quota_exhausted',
      detail: 'The run ended because the model/provider quota was exhausted, not because the task reached delivery.',
    });
  }
  if (renderEvidence.length && !successfulVisionEvidence.length && !nativeImages.some(i=>i.delivered)) {
    completionRisks.push({
      code: 'render_without_image_access',
      detail: 'Render evidence exists, but no native image attachment delivery or successful image-access/inspection tool was recorded.',
    });
  }
  const renderWarningSteps = renderEvidence.filter((item) => (
    item.ok !== false
    && (
      (Array.isArray(item.result?.warnings) && item.result.warnings.length > 0)
      || Number(item.result?.warnings_count) > 0
    )
  )).map((item) => item.index);
  if (renderWarningSteps.length) {
    completionRisks.push({
      code: 'render_with_warnings',
      detail: 'At least one retained render completed with warnings; inspect their scope before judging the result.',
      steps: [...new Set(renderWarningSteps)],
    });
  }
  if (nativeImages.some(i=>i.delivered)) completionRisks.push({
    code:'native_image_interpretation_requires_review',
    detail:'Native image attachments were delivered to the model channel. Compare subsequent model interpretation with the actual images; delivery does not certify visual semantics and requires no extra vision tool.',
  });
  if (visionEvidence.some((item) => item.accessOk === false)) {
    completionRisks.push({
      code: 'vision_tool_failed',
      detail: 'At least one attempted image access or inspection returned a failure.',
    });
  }
  const workStarted = steps.length > 0 || assistantMessages.length > 0;
  if (workStarted) completionRisks.push(...qualityLoopRisks(qualityLoopEvidence));
  const unverifiedRequestedGoals = requestedGoalReportedUnverified(userMessages, assistantMessages);
  if (unverifiedRequestedGoals.length) {
    completionRisks.push({
      code: 'requested_goal_reported_unverified',
      detail: `The final delivery presents the task as complete while user-requested dimension(s) remain unverified: ${unverifiedRequestedGoals.map((item) => item.signal).join(', ')}.`,
      items: unverifiedRequestedGoals,
    });
  }
  const validationCoverage = collectValidationCoverage(steps);
  const edgeContact = validationCoverage.comparisons.filter((item) => item.touches_edge === true);
  if (edgeContact.length) {
    completionRisks.push({
      code: 'render_framing_edge_contact',
      detail: `${edgeContact.length} render_check result(s) have content touching the image edge; fixed-camera evidence may be clipped.`,
      steps: [...new Set(edgeContact.map((item) => item.index))],
    });
  }
  const verbAdoption = collectVerbAdoption(steps);
  const repeatedCode = Object.entries(steps.reduce((groups, step) => {
    if (!step.codeHash) return groups;
    (groups[step.codeHash] ||= []).push(step.index);
    return groups;
  }, {})).filter(([, indices]) => indices.length > 1).map(([hash, indices]) => ({ hash, indices }));
  const gaps = [];
  for (let i = 1; i < steps.length; i++) {
    const ms = steps[i].time - steps[i - 1].time;
    if (ms >= 60_000) gaps.push({ after: steps[i - 1].index, before: steps[i].index, ms });
  }
  const usedVerbs = Object.keys(verbCounts);
  const usedDomains = [...new Set(usedVerbs.map((name) => catalogByName.get(name)?.domain).filter(Boolean))];
  let latestTodo = null;
  for (const step of steps) {
    if (step.tool !== 'todo_write' || !step.args?.todos) continue;
    latestTodo = step.args.todos;
  }
  const unfinishedTodoCount = latestTodo?.filter((item) => item.status !== 'completed').length ?? null;
  const completedVisionTodoRisk = completedVisionTodoWithoutEvidence(
    latestTodo,
    successfulVisionEvidence,
  );
  if (completedVisionTodoRisk) {
    completionRisks.push({
      code: 'completed_vision_todo_without_image_access',
      detail: 'A vision-related todo was marked complete without recorded image access. Compare actual image/description evidence before judging completion.',
    });
  }
  const assistantAfterLastTool = lastAssistantTime > lastToolTime;
  if (suppressedCookFailureSteps.length) {
    completionRisks.push({
      code: 'suppressed_cook_failure',
      detail: `${suppressedCookFailureSteps.length} successful tool envelope(s) printed a raw cook failure.`,
      steps: suppressedCookFailureSteps.map((item) => item.index),
    });
  }
  if (unfinishedTodoCount > 0) {
    completionRisks.push({
      code: 'unfinished_todos',
      detail: `${unfinishedTodoCount} todo item(s) were not completed when the trace ended.`,
    });
  }
  if (lastToolTime && !assistantAfterLastTool) {
    completionRisks.push({
      code: 'no_final_delivery_after_last_tool',
      detail: 'No assistant delivery message followed the final tool result.',
    });
  }
  const initialRequest = userMessages.find(
    (message) => message.time <= firstToolTime,
  ) || null;
  return {
    sessionId: sessionIdFromFile(file),
    file: loaded.file,
    frames: loaded.frames,
    frameErrors: loaded.frameErrors,
    lineErrors: loaded.lineErrors,
    replayedResults,
    unmatchedResults,
    eventCount: events.length,
    effectivePreset: {
      initial: events.find(e => e.type === 'session')?.agentPreset ?? null,
      changes: events.filter(e => e.type === 'agent-preset/selected').map(e => ({seq:e.seq,time:e.time,preset:e.data?.agentPreset})),
    },
    observationContexts: events.filter(e => e.type === 'user/message' && ['runtime-context','plugin'].includes(e.data?.source?.kind))
      .flatMap(e => (e.data?.source?.sections || []).filter(s => s.name === 'dsh-houdini:scene-context')
        .map(s => ({seq:e.seq,time:e.time,text:s.text}))),
    executionCost: {
      toolDurationSumMs: steps.reduce((n,s) => n + (s.durationMs ?? 0), 0),
      measuredToolDurations: steps.filter(s => s.durationMs !== null).length,
      resultChars: normalized.steps.reduce((n,s) => n+s.resultText.length,0),
      note: 'Call-to-result sum includes waits and possible overlap; gaps are not a direct model inference-time measurement.',
    },
    requestTelemetry: collectRequestTelemetry(events),
    requestContexts: requestContexts.map(({systemText,...context})=>context),
    executionAccounting: {records:normalized.uniqueExecutions,
      uniqueExecutions:normalized.uniqueExecutions.length,
      uniqueVerbCalls:normalized.uniqueExecutions.reduce((n,e)=>n+e.verbCalls,0),
      note:'Only canonical runtime/sequence observations; missing historical observations are unmeasured. Transport polls and result retrievals are separate calls, never new executions.'},
    startTime: Number.isFinite(firstTime) ? firstTime : null,
    endTime: lastTime || null,
    durationMs: Number.isFinite(firstTime) && lastTime ? lastTime - firstTime : null,
    taskTiming: {
      initialRequest,
      firstToolTime: Number.isFinite(firstToolTime) ? firstToolTime : null,
      lastToolTime: lastToolTime || null,
      firstToolLatencyMs: initialRequest && Number.isFinite(firstToolTime)
        ? firstToolTime - initialRequest.time
        : null,
      requestToLastToolMs: initialRequest && lastToolTime
        ? lastToolTime - initialRequest.time
        : null,
      toolSpanMs: Number.isFinite(firstToolTime) && lastToolTime
        ? lastToolTime - firstToolTime
        : null,
    },
    userMessages,
    capabilitySnapshots,
    skillCatalogSnapshots,
    skillActivations,
    assistantMessages: compact ? undefined : assistantMessages,
    toolCalls: steps.length,
    toolCounts: sortCounts(toolCounts),
    verbCalls: Object.values(verbCounts).reduce((sum, count) => sum + count, 0),
    verbCounts: sortCounts(verbCounts),
    verbFailures: sortCounts(verbFailures),
    verbAdoption,
    catalog: {
      scope: 'current_repository_catalog; historical exposure is reported separately',
      initiallyExposedNames: capabilitySnapshots[0]?.mentionedCatalogVerbs ?? null,
      total: catalogNames.length,
      used: usedVerbs.length,
      usedNames: usedVerbs.sort(),
      unusedNames: catalogNames.filter((name) => !verbCounts[name]),
      usedDomains: usedDomains.sort(),
    },
    failedCalls,
    processFailures,
    processInterruptions,
    failedVerbCalls,
    partialParameterFailures,
    rawHoudiniNoVerb,
    rawMutationSteps,
    verblessMutations,
    execUsedForReadOnly,
    execWithoutVerbEvidence,
    queryWithMutation,
    rawMethodCounts: sortCounts(rawMethodCounts),
    advisorySteps: steps.filter((step) => step.advisory).map((step) => step.index),
    rollbackSteps: steps.filter((step) => step.rollback).map((step) => ({
      index: step.index, rollback: step.rollback,
    })),
    batchSetParmOpportunities,
    suppressedCookFailureSteps,
    renderEvidence,
    unresolvedRequests,
    activeJobs: executionObservations.activeJobs,
    unavailableResults: executionObservations.unavailableResults,
    executionObservationScope: 'executionHistory(raw_session_events): last retained observations in this trace, including native/nested submission receipts. No unresolved request receipt does not prove all background jobs completed; absent or unavailable results do not establish an execution outcome. Not a current live-state query.',
    visionEvidence,
    nativeImages,
    completionRisks,
    qualityLoopEvidence,
    validationCoverage,
    repeatedCode,
    retryWork: collectRetryWork(normalized.steps),
    timelineGaps: gaps,
    totalCodeChars: steps.reduce((sum, step) => sum + step.codeChars, 0),
    execCodeChars: steps.filter((step) => step.tool === 'houdini_exec').reduce((sum, step) => sum + step.codeChars, 0),
    latestTodo,
    terminal: {
      lastEventType: events.at(-1)?.type || null,
      reason: terminalCategory,
      reasonCode: terminalCode,
      reasonMessage: terminalMessage || null,
      lastToolTime: lastToolTime || null,
      lastAssistantTime: lastAssistantTime || null,
      assistantAfterLastTool,
      unfinishedTodoCount,
    },
    steps,
  };
}

const traces = sessionFiles.map(analyzeTrace);
const aggregateToolCounts = {};
const aggregateVerbCounts = {};
const aggregateVerbFailures = {};
const verbTraceHits = {};
for (const trace of traces) {
  for (const [name, count] of Object.entries(trace.toolCounts)) addCount(aggregateToolCounts, name, count);
  for (const [name, count] of Object.entries(trace.verbCounts)) {
    addCount(aggregateVerbCounts, name, count);
    addCount(verbTraceHits, name);
  }
  for (const [name, count] of Object.entries(trace.verbFailures)) addCount(aggregateVerbFailures, name, count);
}
const output = {
  schemaVersion: 2,
  generatedAt: new Date().toISOString(),
  catalogPath: path.resolve(catalogPath),
  traceCount: traces.length,
  aggregate: {
    toolCalls: traces.reduce((sum, trace) => sum + trace.toolCalls, 0),
    processFailures: traces.reduce((sum, trace) => sum + trace.processFailures.length, 0),
    processInterruptions: traces.reduce((sum, trace) => sum + trace.processInterruptions.length, 0),
    verbCalls: traces.reduce((sum, trace) => sum + trace.verbCalls, 0),
    toolCounts: sortCounts(aggregateToolCounts),
    verbCounts: sortCounts(aggregateVerbCounts),
    verbFailures: sortCounts(aggregateVerbFailures),
    verbTraceHits: sortCounts(verbTraceHits),
    neverUsedCatalogVerbs: catalogNames.filter((name) => !aggregateVerbCounts[name]),
  },
  traces,
};
const json = `${JSON.stringify(output, null, 2)}\n`;
if (outPath) {
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, json, 'utf8');
  console.error(`wrote ${outPath}: ${traces.length} trace(s), ${output.aggregate.toolCalls} tool calls`);
} else {
  process.stdout.write(json);
}
