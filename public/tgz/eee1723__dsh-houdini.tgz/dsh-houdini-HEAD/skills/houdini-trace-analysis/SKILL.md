---
name: houdini-trace-analysis
description: 分析 dsh-houdini 与 DeepSeek Harness 的原始会话日志，定位 Houdini 任务的完成差距、运行与工作区错位、工具合同、执行反馈、观察和性能问题。用户要求复盘指定或最新 trace、比较会话或据证据调整工具与审计技能时使用。
---

# Houdini Trace Analysis

用原始事件解释用户任务为何得到当前结果。系统负责准确现场、可发现的能力、真实执行反馈与可观察产物；模型负责理解、方法、步骤与效果判断。审计不能把一次模型误用变成新的永久工作流或执行限制。

## 取数与定位

在仓库中先核对分支、工作树和目标分支交接；不要把当前源码或新合同当作旧运行事实。先运行证据提取，再生成导航报告：

```powershell
node <skill-dir>/scripts/extract-trace-evidence.mjs <session-file-or-directory> --out <task-output>/dsh-artifacts/analysis/trace/trace-evidence-<id>.json
node <skill-dir>/../../tools/trace-report.mjs <session-file-or-directory> --out <task-output>/dsh-artifacts/analysis/trace/trace-session-<id>.html
```

`<skill-dir>` 是本技能实际安装目录，`<task-output>` 是本次诊断的输出根目录；新分析产物统一放在其 `dsh-artifacts/analysis/trace/` 下。插件/接续故障复盘默认使用独立诊断目录（源码可用`tools/out/<case>/`，受管安装可用独立临时目录），不因被分析的HIP位于某目录就自动向该工程写报告。用户明确要求报告随工程保存时再使用其工程目录。已有或用户指定的输出路径保留。源码与受管安装使用同一入口，不依赖当前工作目录。

支持 `session.v4.jsonl.zstd`、v3 和历史文件；无参数选择存储中最新修改的日志。核对选中文件的会话 ID、时间、用户原话与 cwd。路径由用户明确指定时使用该路径。多会话提取可连续传多个输入。

检查 `frameErrors`、`lineErrors`、`unmatchedResults`、`replayedResults`、有效请求 surface 与末轮终止原因。存在读取缺口时说明缺了什么。报告 HTML 是导航，关键因果回到原始 call/result、runtime-context、执行回执及用户消息。完整结果已转存时按 result_ref 定位原始产物，不能把摘要省略当作没有事实。
分别读取 `unresolvedRequests`、`activeJobs` 和 `unavailableResults`：提交回执已查回不等于后台任务已结束，任务结束也不证明结果可取或正确。后台状态复用客户端的 `executionHistory`，仅表示此日志最后保留的观察，不代表当前 live；不为审计另写状态解释器。
请求状态沿运行时共用的归并规则：后续running/queued应替换unknown_transport，结果过期由unavailableResults单独表达。houdini_request不经过HOM队列；场景查询和界面发现/捕获会排在主线程计算之后。Shell进程枚举没有结果只说明该执行环境没有观察到进程，不能推翻同代Bridge的运行回执或证明崩溃；超时本身不证明取消。

## 因果分析

阅读 [审计判据](references/audit-rubric.md)。需要解释重复系统问题时再读 [通用诊断线索](references/known-patterns.md)。领域方法只在任务确实需要时加载，不强制 SOP、Rig、HDA 或某一种节点结构。

从用户消息与已确认选择重建目标、输入资料、工程/文件交付、后续可编辑要求；模型计划只是其策略记录。按实际状态变化组织时间线，围绕造成返工、信息缺失、错误执行或错误完成声明的链路展开，无固定阶段或章节数量。

逐层检查：入口与加载 → DSH workspace/session → preset、实际模型输入和曝光工具 → 资料与现场获取 → 操作派发与执行 → 结果/请求/长任务状态 → 图片和文件传递 → 模型解读与最终交付。对重要发现给出事件 seq、步骤 #N 或时间，并分清确认缺陷、证据候选与未知范围。

工具分析围绕当时意图：已有且正确使用、已曝光却绕路、误用、合同/实现缺陷、能力缺失、不适用。按输入、副作用、生命周期和返回职责讨论合并或拆分；调用少或一次未使用不能独自证明冗余，也不设置必须累计几条 trace 才能设计工具的数量门。

## 证据边界

- 工具成功、动词成功、事务提交、结果正确和交付完成分别判断；失败的子动词也完整保留。回滚成功不能抹掉已尝试操作和外部文件/Python副作用。
- 终端工具返回成功不等于子进程退出成功。分别读取`processFailures`、`processInterruptions`和原始退出事实；缺少结构化退出字段或明确尾标时保持unknown，不从stdout含Error或没有报错推断。
- 实际 runtime、execution sequence、request_ref 与 session/author 身份不可互相代替。未知响应必须用同一请求和运行代际查回，后续成功查询或已有文件不能证明原请求没执行。
- `capabilitySnapshots` 描述当时曝光；当前目录只提供现役背景。目录广度、调用含动词率、动词密度、只读裸探针、Gate 拦截、成功裸修改候选与未知副作用分别解释。
- 图片资料访问、附件送达、返回内容描述、正确语义核对分别记录。`read_image` 成功只证明访问通道；视觉工具的描述也是待核证据。逐图核对原图、版本/目标、后续描述与最终声称，没有核图保持语义未验证。像素、bbox、亮度与变化不能自动认证对象、连接或质量。
- 数据测量保留 output、piece/稳定 ID、局部坐标、实体覆盖、关系类型与阈值来源；上游 driver、整体 bbox 和响应非零不能替代最终实体关系。unsupported 与未覆盖维度保持 unverified。
- 动画、控制、HDA 回调与重开检查按用户目标选证据；声明动态需最终输出的时序证据，声明可调关系需相应修改观察。无需为普通改名、节点维护或网络交付强制艺术渲染和长流程。
- 自动 `completionRisks`、词法计划字段与重复代码只用于找证据，不能评分或直接判失败。没有关键词、没有某份 skill、节点多、首图晚均不自动构成系统缺陷。
- 用量区分工具 call-to-result、模型请求记录、provider usage 和上下文字符；累计 usage 重复计历史，字符不是 token/费用，时间空档不是已测推理时间。只测到什么就报告什么。

## 建议与交付

先说明结果、影响和根因，再给证据、优先级与修复验证入口。区分系统实现、信息/合同、领域知识、模型误用和审计器取数问题；反事实建议说明应减少哪种绕路，不凭空计算节省。

若用户只要求分析，提出具体修改建议；用户授权修复技能时修改唯一维护源，并用原日志及直接受影响的夹具验证事实抽取与报告。历史案例用于解释线索，不保存过时的发布状态、测试流水或永久禁令。
