"""Candidate executor discovery and cooperative HIP writer leases.

No hou, process termination, credentials or DSH account copies. Records are
discovery hints; the Host must still verify executor identity on every request.
Discovery publication uses workers. Actor-side admission and explicit saves use
non-blocking OS leases; this module performs no network or process probes.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import threading
import uuid
from contextlib import contextmanager

from dsh_deployment import FileLease, _process_started, atomic_json

if '_ACTIVE' not in globals():
    _ACTIVE = None

# This process's own render lease, so nested renders (render_view → render_frame)
# never conflict with themselves across the decorator boundary.
if '_HELD_RENDER_SLOT' not in globals():
    _HELD_RENDER_SLOT = None


def active_registration():
    if _ACTIVE is None:
        raise RuntimeError('Shared executor registration is not enabled')
    return _ACTIVE


def is_shared_executor():
    return _ACTIVE is not None and not _ACTIVE._closed


def activate(root, executor_id, *, installation, version, port, runtime_id, hip, workbench=False, scene=None, runtime=None, helper=None):
    """Explicit worker-side registration after the Bridge is listening."""
    global _ACTIVE
    if _ACTIVE is not None:
        raise RuntimeError('An executor registration is already active')
    item = ExecutorRegistration(root, executor_id, installation=installation, version=version, workbench=workbench, runtime=runtime, helper=helper)
    try:
        item.publish(port, runtime_id, hip=hip, scene=scene)
    except BaseException:
        item.close()
        raise
    _ACTIVE = item
    return item


def _identity(value):
    if not isinstance(value, str) or not re.fullmatch('[0-9a-f]{32}', value):
        raise ValueError('invalid executor identity')
    return value


def _absolute(value):
    path = Path(value)
    if not path.is_absolute():
        raise ValueError('absolute path required')
    return path.resolve()


def _runtime_facts(runtime):
    if (not isinstance(runtime, dict)
            or any(not isinstance(runtime.get(key), str) or not Path(runtime[key]).is_absolute()
                   for key in ('hfs', 'python', 'executable'))
            or not isinstance(runtime.get('pythonVersion'), str)
            or not re.fullmatch(r'\d+\.\d+\.\d+', runtime['pythonVersion'])):
        raise ValueError('invalid Houdini installation runtime')
    return dict(runtime)


def _helper_facts(helper):
    # Auxiliary update information is not an executor admission condition.
    # Older or incomplete observations remain usable with unknown helper facts.
    value = helper if isinstance(helper, dict) else {}
    identity, version = value.get('id'), value.get('version')
    return {'id': identity if isinstance(identity, str) and re.fullmatch('[0-9a-f]{16}', identity) else None,
            'version': version if isinstance(version, str) and 0 < len(version) <= 128 else None}


def _spelling(value):
    """Lexical display form of an observed path: what hou.hipFile showed.

    Published as the record's hip_path so Host/conversation comparisons match
    the recorded spelling. Lease identity keeps using the resolved form.
    """
    return os.path.normpath(str(value))


def _hip_key(path):
    # Resolve case/symlink aliases; existing hard links share the filesystem ID.
    path = _absolute(path)
    if path.suffix.lower() not in ('.hip', '.hiplc', '.hipnc'):
        raise ValueError('expected a HIP path')
    canonical = os.path.normcase(str(path))
    keys = ['path:' + canonical]
    if path.exists():
        if not path.is_file():
            raise ValueError('HIP target is not a file')
        if os.name == 'nt':
            # Python 3.11/3.13 expose different Windows stat inode formats.
            # Use one native identity on both H21 and H22, including hard links.
            import ctypes
            from ctypes import wintypes
            import msvcrt
            class FileInfo(ctypes.Structure):
                _fields_ = [(name, wintypes.DWORD) for name in (
                    'attributes','creationLow','creationHigh','accessLow','accessHigh',
                    'writeLow','writeHigh','volume','sizeHigh','sizeLow','links','indexHigh','indexLow')]
            kernel = ctypes.WinDLL('kernel32', use_last_error=True)
            kernel.GetFileInformationByHandle.argtypes = [wintypes.HANDLE, ctypes.POINTER(FileInfo)]
            info = FileInfo()
            with path.open('rb') as source:
                if not kernel.GetFileInformationByHandle(msvcrt.get_osfhandle(source.fileno()), ctypes.byref(info)):
                    raise OSError(ctypes.get_last_error(), 'Cannot establish HIP file identity')
            keys.append(f'file:{info.volume}:{info.indexHigh}:{info.indexLow}')
        else:
            info = path.stat()
            if not info.st_ino:
                raise ValueError('filesystem cannot establish HIP identity')
            keys.append(f'file:{info.st_dev}:{info.st_ino}')
    return path, [hashlib.sha256(k.encode('utf-8')).hexdigest() for k in sorted(keys)]


class ExecutorRegistration:
    """One executor's registration; its OS lease ends on process death.

    This is not a liveness oracle or automatic task recovery authority.
    A registration never adopts another process's existing record or writer.
    """
    def __init__(self, root, executor_id, *, installation, version, workbench=False, runtime=None, helper=None):
        self.root = _absolute(root)
        self.executor_id = _identity(executor_id)
        self.installation = str(_absolute(installation))
        if not isinstance(version, str) or not re.fullmatch(r'\d+\.\d+\.\d+', version):
            raise ValueError('expected exact Houdini version')
        self.version = version
        self.runtime = _runtime_facts(runtime) if runtime is not None else None
        self.helper = _helper_facts(helper) if helper is not None else None
        self._guard = threading.RLock()
        self._writers = []
        self._writer_keys = []
        self.workbench = workbench
        self.scene = {}
        self._task = None
        self._hip = None
        self._closed = False
        self._lease = FileLease(self.root / 'leases' / (self.executor_id + '.lock'))
        self._file = self.root / 'endpoints' / (self.executor_id + '.json')
        if self._file.exists():
            self._lease.close()
            raise RuntimeError('executor identity already recorded; new processes require a fresh identity')
        self._generation = uuid.uuid4().hex
        self._port = None
        self._runtime_id = None
        self._observed_hip = None
        self._hip_display = None
        # Birth identity is published with the record so presence can reject a
        # reused pid after a crash instead of treating the stale row as live.
        self._process_started = _process_started(os.getpid())

    def _open(self):
        if self._closed:
            raise RuntimeError('executor registration is closed')

    def registered_hip(self):
        """Published HIP before a task claims it; reserved HIP afterwards."""
        with self._guard:
            self._open()
            return self._hip or self._observed_hip

    def observe(self, hip, scene, *, is_current=None):
        with self._guard:
            self._open()
            if is_current is not None and not is_current():
                return False
            if not self.workbench:
                return False
            if self.scene.get('scene_epoch') != scene['scene_epoch'] and self._hip != str(_absolute(hip)):
                for lease in self._writers:
                    lease.close()
                self._writers, self._writer_keys = [], []
                self._task = self._hip = self._hip_display = None
            elif self._hip and not scene.get('hip_is_new'):
                with self.save_target(hip):
                    pass
            self.publish(self._port, self._runtime_id, hip=hip, scene=scene)
            return True

    def claim_writer(self, task_id, hip, *, replace=False):
        """Acquire before enabling mutations. Never create/save/load the HIP.

        replace=True is the single mechanical takeover path; it is reachable
        only through an explicit user-authorized claim (Host target selection
        or recovery choice), never from verification or routing. Only protects
        participating runtimes; GUI saves and arbitrary filesystem writes are
        not intercepted. Save As must acquire its new target first.
        """
        if not isinstance(task_id, str) or not task_id.strip() or len(task_id) > 256:
            raise ValueError('invalid task identity')
        target, keys = (_absolute(hip), []) if self.workbench and self.scene.get('hip_is_new') else _hip_key(hip)
        with self._guard:
            self._open()
            if self._task is not None:
                if (self._task, self._hip) == (task_id, str(target)):
                    return
                if replace and self.workbench and self._hip == str(target):
                    self._task = task_id
                    return
                raise RuntimeError('executor already has a scene author; release explicitly before changing task or HIP')
            leases = []
            try:
                for key in keys:
                    leases.append(FileLease(self.root / 'writers' / (key + '.lock')))
            except BaseException:
                for lease in reversed(leases):
                    lease.close()
                raise
            self._writers, self._task, self._hip = leases, task_id, str(target)
            self._hip_display = _spelling(hip)
            self._writer_keys = keys

    def publish(self, port, runtime_id, *, hip=None, scene=None):
        """Publish an already listening Bridge, never close-and-rebind a probe port."""
        _identity(runtime_id)
        if type(port) is not int or not 1024 <= port <= 65535:
            raise ValueError('invalid loopback port')
        with self._guard:
            self._open()
            if hip is not None:
                self._observed_hip = str(_absolute(hip))
                self._hip_display = _spelling(hip)
            if scene is not None:
                if self.scene.get('scene_epoch') and self.scene['scene_epoch'] != scene.get('scene_epoch'):
                    self._generation = uuid.uuid4().hex
                self.scene = dict(scene)
            display = self._hip_display or self._hip or self._observed_hip
            record = {'schema': 1, 'executor_id': self.executor_id,
                      'registration_id': self._generation, 'runtime_id': runtime_id,
                      'pid': os.getpid(), 'processStarted': self._process_started,
                      'installation': self.installation, 'houdini_version': self.version,
                      'bridge_url': f'http://127.0.0.1:{port}', 'state': 'registered',
                      'task_id': self._task, 'hip_path': display,
                      # Resolved identity for alias-aware matching; hip_path stays
                      # the spelling the user and Houdini display.
                      'hip_key': os.path.normcase(self._observed_hip or self._hip or str(_absolute(display))) if display else None,
                      'boundary': 'Discovery only; verify executor header and task binding before any operation'}
            if self.workbench:
                record.update(workbench=True, **{key: self.scene.get(key) for key in ('scene_id', 'scene_epoch', 'hip_is_new', 'workspace_path')})
            if self.runtime is not None:
                record['runtime'] = self.runtime
            if self.helper is not None:
                record['helper'] = self.helper
            atomic_json(self._file, record)
            self._port, self._runtime_id = port, runtime_id
            return record

    def claim(self, task_id, registration_id, expected_hip, actual_hip, *, idle=False):
        """Called after the Bridge main thread captures the actual current HIP.

        Reaching this method means an explicit claim (user-selected target or
        recovery choice). idle only decides whether such a claim may take over
        an idle workbench reservation; there is no implicit takeover from
        verification or routing.
        """
        with self._guard:
            self._open()
            if registration_id != self._generation or self._port is None:
                raise RuntimeError('Stale executor registration; refresh before selecting')
            expected = _absolute(expected_hip)
            if expected != _absolute(actual_hip) or str(expected) != self._observed_hip:
                raise RuntimeError('HIP changed after discovery; refresh and confirm the actual target')
            if not expected.is_file() and not (self.workbench and self.scene.get('hip_is_new')):
                raise RuntimeError('Save and name this HIP before binding a shared task')
            if self.workbench and self._task is not None and self._task != task_id and not idle:
                raise RuntimeError('当前工程仍有操作未完成，请等待完成后再切换对话。')
            # Pass the original spelling: claim_writer re-resolves for lease
            # keys and records the display form from what the user confirmed.
            self.claim_writer(task_id, expected_hip, replace=idle and self._task is not None)
            # If publication fails, keep the acquired reservation. A retry by the
            # same task is safe; do not let a competing author take over unknown state.
            return self.publish(self._port, self._runtime_id)

    def require_writer(self, task_id, actual_hip):
        with self._guard:
            self._open()
            # The fast path compares the published spelling. Only a spelling
            # mismatch pays for resolution, so a junction/UNC alias does not
            # reject a valid reservation while the common path stays I/O-free.
            if self._task is not None and self._task == task_id:
                if os.path.normcase(self._hip_display or self._hip) == os.path.normcase(_spelling(actual_hip)):
                    return
                # Resolve only on a spelling mismatch: samefile follows hard
                # links and junctions without accepting an old path key.
                try:
                    if self._hip and os.path.samefile(actual_hip, self._hip):
                        return
                except OSError:
                    pass
                if self._hip and os.path.normcase(self._hip) == os.path.normcase(str(_absolute(actual_hip))):
                    return
            raise RuntimeError('Shared executor task/HIP reservation mismatch; no scene operation allowed')

    @contextmanager
    def save_target(self, target):
        if not self.workbench:
            require_save_target(target)
            yield
            return
        display = _spelling(target)
        target, keys = _hip_key(target)
        acquired = []
        with self._guard:
            self._open()
            try:
                for key in keys:
                    if key not in self._writer_keys:
                        acquired.append((key, FileLease(self.root / 'writers' / (key + '.lock'))))
                yield
            except BaseException:
                for key, lease in acquired:
                    lease.close()
                raise
            self._writer_keys.extend(key for key, lease in acquired)
            self._writers.extend(lease for key, lease in acquired)
            target, keys = _hip_key(target)
            for key in keys:
                if key not in self._writer_keys:
                    self._writers.append(FileLease(self.root / 'writers' / (key + '.lock')))
                    self._writer_keys.append(key)
            self._hip = self._observed_hip = str(target)
            self._hip_display = display
            self.scene['hip_is_new'] = False
            self.scene['workspace_path'] = str(target.parent)
            self.publish(self._port, self._runtime_id)
            retained = []
            for key, lease in zip(self._writer_keys, self._writers):
                if key in keys:
                    retained.append((key, lease))
                else:
                    lease.close()
            self._writer_keys = [key for key, lease in retained]
            self._writers = [lease for key, lease in retained]


    def close(self):
        with self._guard:
            if self._closed:
                return
            # Do not mark unknown executions completed. Retain evidence on disk.
            try:
                if self._file.exists():
                    value = json.loads(self._file.read_text(encoding='utf-8'))
                    if value.get('registration_id') != self._generation:
                        raise RuntimeError('registration changed; refusing to overwrite another generation')
                    atomic_json(self._file, {**value, 'state': 'disconnected'})
            finally:
                for lease in reversed(self._writers):
                    lease.close()
                self._writers = []
                self._lease.close()
                self._closed = True


def require_active_writer(task_id, actual_hip):
    if _ACTIVE is not None:
        _ACTIVE.require_writer(task_id, actual_hip)


def require_save_target(path):
    if _ACTIVE is not None and os.path.normcase(os.path.abspath(path)) != os.path.normcase(_ACTIVE._hip or ''):
        raise RuntimeError('Shared executor Save As requires a new writer reservation; use the explicit handoff flow, not this scene call')


@contextmanager
def save_target(path):
    if _ACTIVE is None:
        yield
    else:
        with _ACTIVE.save_target(path):
            yield


def render_slot():
    """One cross-process render lease per shared registry; None outside shared-executor mode.

    Fail-fast: a busy slot refuses instead of queueing inside the Bridge request
    budget, so a waiting caller never holds the GUI main thread hostage. Without
    an active registry the Bridge main-thread queue already serializes this
    process, so no lease is taken. The lease is OS-held: a crashed renderer
    releases it without deleting any file. Re-entrant within this process: a
    nested render (render_view calls render_frame) does not conflict with itself.
    Long renders belong in houdini_job_* and are not covered by this slot.
    """
    if not is_shared_executor():
        return None
    global _HELD_RENDER_SLOT
    if _HELD_RENDER_SLOT is not None:
        return None
    try:
        lease = FileLease(_ACTIVE.root / 'render.lock')
    except RuntimeError:
        raise RuntimeError('render slot is busy on the shared host: another executor is rendering; '
                           'retry after it finishes, or submit long renders via houdini_job_submit') from None
    _HELD_RENDER_SLOT = lease
    return lease


def release_render_slot(lease):
    """Release the lease returned by render_slot; nested renders get None and no-op."""
    global _HELD_RENDER_SLOT
    if lease is not None and lease is _HELD_RENDER_SLOT:
        _HELD_RENDER_SLOT = None
        lease.close()


def read_candidates(root, *, installation):
    """Read-only discovery. Stale records remain candidates, never 'connected'."""
    root, install = _absolute(root), str(_absolute(installation))
    folder = root / 'endpoints'
    if not folder.exists():
        return []
    files = sorted(folder.glob('*.json'))
    rows = []
    registered = 0
    for file in files:
        if file.is_symlink() or file.resolve().parent != folder.resolve() or file.stat().st_size > 16384:
            raise ValueError('invalid endpoint record path/size')
        value = json.loads(file.read_text(encoding='utf-8'))
        if (not isinstance(value, dict) or type(value.get('schema')) is not int or value.get('schema') != 1 or value.get('executor_id') != file.stem
                or not re.fullmatch(r'http://127\.0\.0\.1:[0-9]{4,5}', value.get('bridge_url', ''))
                or value.get('state') not in ('registered', 'disconnected')):
            raise ValueError('invalid executor record')
        _identity(value['executor_id'])
        _identity(value.get('runtime_id'))
        _identity(value.get('registration_id'))
        if 'runtime' in value:
            _runtime_facts(value['runtime'])
        if 'helper' in value:
            value['helper'] = _helper_facts(value['helper'])
        if not 1024 <= int(value['bridge_url'].rsplit(':', 1)[1]) <= 65535:
            raise ValueError('invalid registered port')
        if value.get('installation') == install:
            if value['state'] == 'registered':
                registered += 1
                if registered > 256:
                    raise ValueError('executor discovery exceeds 256 registered records; explicit maintenance required')
            rows.append({**value, 'connection_status': 'unverified'})
    return rows
