"""Bounded final-geometry checks with optional controlled review preview capture.

All calls run through the owning-thread Bridge. Named groups are explicit user/
agent-selected interfaces, not inferred semantics. Only declared, bounded
closed Polygon selections can be checked for solid overlap; this is not a
continuous collision solver. Unsupported representations stay unverified.
"""
from __future__ import annotations

import dsh_errors
import dsh_node_access
import dsh_node_operations
import dsh_ownership
import dsh_parameter_values
import dsh_render

import hashlib
from collections import Counter, defaultdict
import json
import math
import operator
import time
import hou
import hjson

_MAX_GEOMETRY_BYTES = 32 * 1024 * 1024
_MAX_POINTS = 250000
_MAX_PRIMS = 100000
_SURFACE_TYPES = {'Polygon', 'Mesh', 'Sphere', 'Tube'}


class UnsupportedEvidence(ValueError):
    def __init__(self, message, *, diagnostic=None):
        super().__init__(message)
        self.diagnostic = diagnostic or {}


def validate_domain(domain):
    if not isinstance(domain,list) or len(domain)>32:
        raise ValueError('domain must contain at most 32 scalar comparisons')
    ids=set()
    for c in domain:
        _exact_keys(c,{'id','left','op','right'},'domain condition')
        if set(c)!={'id','left','op','right'}:raise ValueError('domain needs id/left/op/right')
        for name in ('id','left'):
            if not isinstance(c[name],str) or not c[name].strip():raise ValueError(f'domain {name} must be nonempty')
        if c['id'] in ids:raise ValueError('domain ids must be unique')
        ids.add(c['id'])
        if c['op'] not in ('lt','le','gt','ge','eq','ne'):raise ValueError('domain op must be exactly lt, le, gt, ge, eq or ne')
        if isinstance(c['right'],str):
            if not c['right'].strip():raise ValueError('domain right control must be nonempty')
        elif isinstance(c['right'],dict):
            _exact_keys(c['right'],{'terms','constant'},'domain linear right')
            terms=c['right'].get('terms')
            if not isinstance(terms,dict) or not 1<=len(terms)<=8:raise ValueError('domain terms must contain 1..8 numeric control coefficients')
            for name,coefficient in terms.items():
                if not isinstance(name,str) or not name.strip():raise ValueError('domain term control must be nonempty')
                _finite(coefficient,'domain coefficient')
            _finite(c['right'].get('constant',0),'domain constant')
        else:_finite(c['right'],'domain right')


def _control_parameter(ctrl, name):
    """One declared scalar control, whether spare or defined by an HDA."""
    p = ctrl.parm(name)
    if p is None or p.parmTemplate().type() not in (hou.parmTemplateType.Float, hou.parmTemplateType.Int, hou.parmTemplateType.Toggle):
        raise ValueError(f'{name}: only existing numeric scalar controls supported')
    tpl = p.parmTemplate()
    if tpl.scriptCallback() or p.isMultiParmInstance():
        raise ValueError(f'{name}: callbacks/multiparms are not supported control-test targets')
    try:
        if tpl.menuItems() or tpl.itemGeneratorScript():
            raise ValueError(f'{name}: menu controls are not supported')
    except AttributeError:
        pass
    return p


def domain_checks(ctrl, domain, overrides=None):
    """Compare declared numeric controls; no eval strings, solving or writes."""
    def value(name):
        p = _control_parameter(ctrl, name)
        return _finite(overrides[name] if overrides and name in overrides else p.eval(),'domain value')
    compare={'lt':operator.lt,'le':operator.le,'gt':operator.gt,'ge':operator.ge,'eq':operator.eq,'ne':operator.ne}
    rows=[]
    for c in domain:
        left=value(c['left'])
        rhs=c['right']
        right=value(rhs) if isinstance(rhs,str) else math.fsum(value(n)*k for n,k in rhs['terms'].items())+rhs.get('constant',0) if isinstance(rhs,dict) else rhs
        right=_finite(right,'domain evaluated right')
        rows.append({'id':c['id'],'kind':'domain','status':'pass' if compare[c['op']](left,right) else 'fail',
                     'condition':dict(c),'left_value':left,'right_value':right,
                     'scope':'current or proposed scalar values only; not proof of all combinations',
                     'next_action':'Restore a design-valid value or explicitly revise the design contract; no silent clamping.'})
    return rows


def _finite(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f'{label} must be a finite number')
    return float(value)


def _exact_keys(obj, allowed, label):
    if not isinstance(obj, dict) or set(obj) - set(allowed):
        raise ValueError(f'{label} supports only {sorted(allowed)}')


def validate_interfaces(interfaces):
    if not isinstance(interfaces, list) or not 1 <= len(interfaces) <= 16:
        raise ValueError('interfaces must contain 1..16 explicit contracts')
    ids = set()
    for item in interfaces:
        if not isinstance(item,dict):raise ValueError('interface must be an object')
        axis_gap = item.get('method') == 'axis_gap'
        section = item.get('method') == 'section_proximity'
        solid_overlap = item.get('method') == 'solid_overlap'
        axis_passage = item.get('method') == 'axis_passage'
        bore_clearance = item.get('method') == 'bore_clearance'
        component_count = item.get('method') == 'component_count'
        physical_extent = item.get('method') == 'physical_extent'
        allowed = {'id','method','target_group','axis','expected_mm','tolerance_mm'} if physical_extent else {'id','method','target_group','expected_components'} if component_count else {'id','method','target_group','axis','start','end','radius'} if bore_clearance else {'id','method','target_group','axis','start','end'} if axis_passage else {'id','method','source_group','target_group','axis','gap_range','min_overlap'} if axis_gap else {'id','method','source_group','target_group','axis','plane_at','expected_components','max_distance'} if section else {'id','method','source_group','target_group','max_overlap_volume'} if solid_overlap else {'id','source_group','target_group','max_distance','expected_points'}
        _exact_keys(item, allowed, 'interface')
        for key in (('id','target_group') if axis_passage or bore_clearance or component_count or physical_extent else ('id','source_group','target_group')):
            if not isinstance(item.get(key), str) or not item[key].strip():
                raise ValueError(f'interface {key} must be nonempty')
        if item['id'] in ids:
            raise ValueError('interface ids must be unique')
        ids.add(item['id'])
        if physical_extent:
            if type(item.get('axis')) is not int or not 0 <= item['axis'] <= 2:
                raise ValueError('physical_extent requires axis=0/1/2')
            expected=_finite(item.get('expected_mm'),'physical_extent expected_mm')
            tolerance=_finite(item.get('tolerance_mm'),'physical_extent tolerance_mm')
            if expected <= 0 or tolerance < 0 or tolerance >= expected:
                raise ValueError('physical_extent needs positive expected_mm and tolerance_mm in [0, expected_mm)')
            continue
        if component_count:
            if type(item.get('expected_components')) is not int or not 1 <= item['expected_components'] <= 32:
                raise ValueError('component_count expected_components must be 1..32')
            continue
        if axis_passage or bore_clearance:
            axis = item.get('axis')
            if type(axis) is not int or not 0 <= axis <= 2:
                raise ValueError(f"{item['method']} requires axis=0/1/2")
            for key in ('start','end'):
                point = item.get(key)
                if not isinstance(point,(list,tuple)) or len(point)!=3:
                    raise ValueError(f"{item['method']} {key} must be a 3D SOP-local point")
                for value in point:_finite(value, f"{item['method']} {key}")
            start,end=item['start'],item['end']
            if abs(float(end[axis])-float(start[axis])) <= 1e-6 or any(
                    abs(float(end[i])-float(start[i])) > 1e-9 for i in range(3) if i!=axis):
                raise ValueError(f"{item['method']} needs a nonzero axis-aligned segment")
            if bore_clearance and _finite(item.get('radius'),'bore_clearance radius') <= 0:
                raise ValueError('bore_clearance radius must be positive in SOP local units')
            continue
        if axis_gap:
            if type(item.get('axis')) is not int or not 0 <= item['axis'] <= 2:
                raise ValueError('axis_gap requires axis=0/1/2')
            limits = item.get('gap_range')
            if not isinstance(limits,(list,tuple)) or len(limits)!=2 or _finite(limits[0],'gap_range')>_finite(limits[1],'gap_range'):
                raise ValueError('gap_range must be finite [min,max] in SOP local units')
            if _finite(item.get('min_overlap'),'min_overlap') <= 0:
                raise ValueError('axis_gap requires positive min_overlap on both transverse axes')
            continue
        if solid_overlap:
            if _finite(item.get('max_overlap_volume'), 'max_overlap_volume') < 0:
                raise ValueError('max_overlap_volume must be nonnegative (SOP local units cubed)')
            continue
        if _finite(item.get('max_distance'), 'max_distance') < 0:
            raise ValueError('max_distance must be nonnegative (SOP local units)')
        if section:
            if type(item.get('axis')) is not int or not 0<=item['axis']<=2:raise ValueError('section axis must be 0/1/2')
            if item.get('plane_at') != 'target_center':_finite(item.get('plane_at'),'section plane_at')
            if type(item.get('expected_components')) is not int or not 1<=item['expected_components']<=32:
                raise ValueError('section expected_components must be 1..32')
            continue
        if type(item.get('expected_points')) is not int or not 1 <= item['expected_points'] <= 512:
            raise ValueError('expected_points must be an integer in 1..512; do not silently accept missing endpoints')


def _geometry(output):

    node = dsh_node_access._resolve(output)
    if node.type().category() != hou.sopNodeTypeCategory():
        raise ValueError('explicit output must be a SOP')
    from dsh_cook_control import require_evaluation
    require_evaluation('geometry quality check')
    g = node.geometry()
    if g is None or node.errors():
        raise ValueError(f'output has no healthy geometry: {node.path()}: {node.errors()}')
    if (g.intrinsicValue('pointcount') > _MAX_POINTS or g.intrinsicValue('primitivecount') > _MAX_PRIMS
            or g.intrinsicValue('memoryusage') > _MAX_GEOMETRY_BYTES):
        raise ValueError('geometry evidence budget exceeded; use a smaller explicit deliverable module')
    return node, g.freeze(read_only=True)


def _canonical_geometry_payload(data, _depth=0):
    """Canonicalize writer order while retaining group members and attribute values."""
    if _depth>8:raise ValueError('packed fingerprint nesting exceeds 8 levels')
    payload=hjson.loads(data) if isinstance(data,(bytes,str)) else data
    if (not isinstance(payload,list) or len(payload)%2
            or any(not isinstance(k,str) for k in payload[::2])
            or len(set(payload[::2])) != len(payload[::2])):
        raise ValueError('unsupported bgeo root schema; no restoration fingerprint fallback')
    for i in range(0,len(payload),2):
        key, value = payload[i:i+2]
        if key in ('pointgroups','primitivegroups','vertexgroups','edgegroups'):
            if not isinstance(value,list):
                raise ValueError(f'unsupported bgeo {key} schema')
            names, seen = [], set()
            for record in value:
                if (not isinstance(record,list) or len(record)!=2
                        or not isinstance(record[0],list) or len(record[0])%2
                        or any(not isinstance(k,str) for k in record[0][::2])
                        or len(set(record[0][::2])) != len(record[0][::2])):
                    raise ValueError(f'unsupported bgeo {key} record; preserve unknown group semantics')
                descriptor=dict(zip(record[0][::2],record[0][1::2]))
                name=descriptor.get('name')
                if not isinstance(name,str) or not name or name in seen:
                    raise ValueError(f'unsupported bgeo {key} group names')
                names.append(name)
                seen.add(name)
            # Houdini may enumerate independent named groups in a different
            # serialization order after recooking. Keep each descriptor and
            # selection payload intact, including ordered-group element order.
            payload[i+1]=[record for _,record in sorted(zip(names,value),key=lambda pair:pair[0])]
        elif key=='attributes' and isinstance(value,list) and len(value)%2==0:
            # Houdini may assign string-table indices in cook order. The table
            # order is not an attribute value: remap the known GA rawpagedata
            # schema while preserving every element's actual string and all
            # other attribute metadata. Unknown encodings stay byte-distinct.
            for records in value[1::2]:
                if not isinstance(records,list):continue
                for record in records:
                    if not isinstance(record,list) or len(record)!=2:continue
                    descriptor,body=record
                    if (not isinstance(descriptor,list) or len(descriptor)%2
                            or any(not isinstance(k,str) for k in descriptor[::2])
                            or len(set(descriptor[::2]))!=len(descriptor)//2
                            or dict(zip(descriptor[::2],descriptor[1::2])).get('type')!='string'
                            or not isinstance(body,list) or len(body)%2
                            or any(not isinstance(k,str) for k in body[::2])
                            or len(set(body[::2]))!=len(body)//2):continue
                    fields=dict(zip(body[::2],body[1::2]))
                    if set(fields)!={'size','storage','strings','indices'}:continue
                    strings,indices=fields['strings'],fields['indices']
                    if (not isinstance(strings,list) or any(not isinstance(s,str) for s in strings)
                            or len(set(strings))!=len(strings) or not isinstance(indices,list)
                            or len(indices)%2 or any(not isinstance(k,str) for k in indices[::2])
                            or len(set(indices[::2]))!=len(indices)//2):continue
                    index_fields=dict(zip(indices[::2],indices[1::2]))
                    if (set(index_fields)-{'size','storage','pagesize','constantpageflags','rawpagedata'}
                            or 'rawpagedata' not in index_fields):continue
                    raw=index_fields['rawpagedata']
                    if (not isinstance(raw,list) or any(type(n) is not int or n<-1 or n>=len(strings)
                                                        for n in raw)):continue
                    ordered=sorted(strings)
                    positions={name:index for index,name in enumerate(ordered)}
                    mapping={old:positions[name] for old,name in enumerate(strings)}
                    body[body.index('strings')+1]=ordered
                    indices[indices.index('rawpagedata')+1]=[mapping[n] if n>=0 else n for n in raw]
        elif key=='info' and isinstance(value,dict):
            # Both are writer-generated descriptions, not user attributes.
            # The actual group names, membership and selection order stay above.
            payload[i+1]={k:v for k,v in value.items() if k not in ('date','group_summary')}
    if 'sharedprimitivedata' in payload[::2]:
        shared=payload[payload.index('sharedprimitivedata')+1]
        if not isinstance(shared,list) or len(shared)%2:raise ValueError('unsupported packed payload schema')
        remap={};normalized_shared=[]
        for kind,entries in zip(shared[::2],shared[1::2]):
            if kind!='PackedGeometry':
                # Preserve unknown/native shared payload verbatim. Only the
                # established embedded-packed schema is address-normalized.
                normalized_shared.extend([kind,entries]);continue
            if not isinstance(entries,list) or len(entries)%3:
                raise ValueError('unsupported embedded packed representation')
            records=[]
            for i in range(0,len(entries),3):
                tag,key,child=entries[i:i+3]
                if tag!='gu:embeddedgeo' or not isinstance(key,str):raise ValueError('unsupported embedded geometry record')
                canonical=_canonical_geometry_payload(child,_depth+1)
                digest=hashlib.sha256(json.dumps(canonical,sort_keys=True,allow_nan=False).encode()).hexdigest()
                remap[key]='content:'+digest;records.append((digest,canonical))
            normalized=[]
            for digest,child in sorted(dict(records).items()):normalized.extend(['gu:embeddedgeo','content:'+digest,child])
            normalized_shared.extend([kind,normalized])
        payload[payload.index('sharedprimitivedata')+1]=normalized_shared
        # Writer seek index/byte offsets refer to transient embedded addresses.
        # The full canonical payload above carries every referenced value.
        for field in ('index','indexposition'):
            if remap and field in payload[::2]:payload[payload.index(field)+1]=None
        for record in payload[payload.index('primitives')+1]:
            descriptor,body=record
            if dict(zip(descriptor[::2],descriptor[1::2])).get('type')!='PackedGeometry':continue
            parameters=body[body.index('parameters')+1]
            if parameters.get('embedded') not in remap:raise ValueError('missing packed payload')
            parameters['embedded']=remap[parameters['embedded']]
    return payload


def _data_signature(g):
    # bgeo contains topology, attributes AND primitive intrinsics (native Tube
    # radius, packed transforms, etc.). P-only signatures miss such changes.
    data = g.data()
    if len(data) > _MAX_GEOMETRY_BYTES:
        raise ValueError('serialized geometry evidence budget exceeded')
    payload=_canonical_geometry_payload(data)
    canonical=json.dumps(payload,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')
    if len(canonical)>4*_MAX_GEOMETRY_BYTES:raise ValueError('decoded geometry evidence budget exceeded')
    return hashlib.sha256(canonical).hexdigest()


def _first_geometry_difference(before, after, limit=50000):
    """Locate a bounded bgeo difference without returning arbitrary attribute data."""
    pending=[('',before,after)]
    visited=0
    while pending and visited<limit:
        path,left,right=pending.pop()
        visited+=1
        if type(left) is not type(right):
            return {'path':path or '/', 'kind':'type',
                    'baseline_type':type(left).__name__,'restored_type':type(right).__name__}
        if isinstance(left,dict):
            missing=set(left)^set(right)
            if missing:
                key=sorted(missing)[0]
                child=path+'/'+str(key).replace('~','~0').replace('/','~1')
                return {'path':child,'kind':'missing_key',
                        'present_in':'baseline' if key in left else 'restored'}
            for key in sorted(left,reverse=True):
                child=path+'/'+str(key).replace('~','~0').replace('/','~1')
                pending.append((child,left[key],right[key]))
        elif isinstance(left,list):
            if len(left)!=len(right):
                return {'path':path or '/', 'kind':'length',
                        'baseline_length':len(left),'restored_length':len(right)}
            pending.extend((path+'/'+str(i),left[i],right[i]) for i in range(len(left)-1,-1,-1))
        elif left!=right:
            detail={'path':path or '/', 'kind':'value'}
            if type(left) in (int,float,bool) and type(right) in (int,float,bool):
                detail.update(baseline_value=left,restored_value=right)
            return detail
    return {'path':'/', 'kind':'comparison_budget_exceeded'} if pending else None


def _geometry_restore_diagnostic(baseline, restored, baseline_hash, restored_hash):
    result={'matches':baseline_hash==restored_hash,
            'baseline_sha256':baseline_hash,'restored_sha256':restored_hash}
    if result['matches']:return result
    before=_canonical_geometry_payload(baseline.data())
    after=_canonical_geometry_payload(restored.data())
    before_sections=dict(zip(before[::2],before[1::2]))
    after_sections=dict(zip(after[::2],after[1::2]))
    differing=[]
    for name in sorted(set(before_sections)|set(after_sections)):
        if name not in before_sections or name not in after_sections:
            differing.append({'section':name,'kind':'missing_section'})
        elif before_sections[name]!=after_sections[name]:
            differing.append({'section':name,
                              'first_difference':_first_geometry_difference(before_sections[name],after_sections[name])})
    result['differing_sections']=differing[:12]
    result['differing_section_count']=len(differing)
    return result


def _supported_surface(prim):
    kind = prim.type().name()
    return kind in _SURFACE_TYPES and (kind != 'Polygon' or (bool(prim.intrinsicValue('closed')) and prim.numVertices() >= 3))


def _check_interfaces(g, interfaces, max_pairs, output_node=None):
    total_pairs = 0
    selections = []
    results = []
    for item in interfaces:
        if item.get('method') == 'physical_extent':
            results.append(_physical_extent(g,item,output_node))
            continue
        if item.get('method') == 'axis_gap':
            results.append(_axis_gap(g, item))
            continue
        if item.get('method') == 'section_proximity':
            row, pairs = _section_proximity(g,item,max_pairs-total_pairs)
            results.append(row);total_pairs+=pairs
            continue
        if item.get('method') == 'solid_overlap':
            row, pairs = _solid_overlap(g,item,max_pairs-total_pairs)
            results.append(row);total_pairs+=pairs
            continue
        if item.get('method') == 'axis_passage':
            results.append(_axis_passage(g,item))
            continue
        if item.get('method') == 'bore_clearance':
            row, pairs = _bore_clearance(g,item,max_pairs-total_pairs)
            results.append(row);total_pairs+=pairs
            continue
        if item.get('method') == 'component_count':
            results.append(_component_count(g,item))
            continue
        pg = g.findPointGroup(item['source_group'])
        tg = g.findPrimGroup(item['target_group'])
        points = list(pg.points()) if pg else []
        prims = list(tg.prims()) if tg else []
        base = {'id':item['id'],'source_group':item['source_group'],'target_group':item['target_group'],
                'source_count':len(points),'target_count':len(prims),'expected_points':item['expected_points'],
                'tolerance':item['max_distance']}
        # Diagnostic identities only: labels are author data, not proof of ownership
        # or semantic completeness. Never silently filter contaminated selections.
        identities = {}
        for attr_name in ('name', 'part'):
            attr = g.findPrimAttrib(attr_name)
            if attr is None or attr.dataType() != hou.attribData.String:
                continue
            source_counts = {}
            target_counts = {}
            for point in points:
                for label in {v.prim().stringAttribValue(attr_name) for v in point.vertices()}:
                    source_counts[label] = source_counts.get(label, 0) + 1
            for prim in prims:
                label = prim.stringAttribValue(attr_name)
                target_counts[label] = target_counts.get(label, 0) + 1
            identities[attr_name] = {
                'source_point_memberships':dict(sorted(source_counts.items())[:32]),
                'target_primitive_memberships':dict(sorted(target_counts.items())[:32]),
                'truncated':len(source_counts)>32 or len(target_counts)>32}
        if identities:
            base['selection_identities'] = identities
        if g.findPrimAttrib('name'):
            source_names = sorted({v.prim().stringAttribValue('name') for p in points for v in p.vertices()})
            target_names = sorted({p.stringAttribValue('name') for p in prims})
            base.update(source_pieces=source_names[:32], target_pieces=target_names[:32],
                        piece_coverage_truncated=len(source_names)>32 or len(target_names)>32)
        if len(points) != item['expected_points'] or not prims:
            results.append({**base,'status':'fail','reason':'missing_group_or_cardinality_mismatch'})
            continue
        total_pairs += len(points) * len(prims)
        if total_pairs > max_pairs:
            raise ValueError('interface nearest-surface budget exceeded; narrow the explicit interface groups')
        if any(not _supported_surface(p) for p in prims):
            results.append({**base,'status':'unverified','reason':'unsupported_target_surface_type'})
            continue
        # Source ports must be actual polygon/mesh vertices, not the center of
        # a quadric or free-standing driver/anchor points included in the output.
        if any(not p.vertices() or not any(v.prim().type().name() in ('Polygon','Mesh') and _supported_surface(v.prim())
                                         for v in p.vertices()) for p in points):
            results.append({**base,'status':'unverified','reason':'source_group_not_on_final_surface_vertices'})
            continue
        target_point_ids = {p.number() for prim in prims for p in prim.points()}
        shared_ids = [p.number() for p in points if p.number() in target_point_ids]
        if shared_ids:
            results.append({**base,'status':'fail','reason':'source_and_target_overlap_cannot_self_validate',
                            'shared_point_count':len(shared_ids),'shared_point_ids':shared_ids[:32],
                            'next_action':'The same point identities occur in source and target; coincident positions on independent parts are allowed. Inspect selection_identities for mixed parts in BOTH groups. Build interface selections from part identity and the actual attachment region before merging; do not silently filter, enlarge tolerance, or remove correct fused vertices. For genuinely fused polygon parts use test_controls topology.'})
            continue
        selections.append((base, points, prims))
    for base, points, prims in selections:
        distances = []
        failure = []
        try:
            for point in points:
                candidates = []
                pos = point.position()
                if not all(math.isfinite(float(v)) for v in pos):
                    raise UnsupportedEvidence('nonfinite source point')
                for prim in prims:
                    u, v, distance = prim.nearestToPosition(pos)
                    if not math.isfinite(distance) or distance < 0:
                        raise UnsupportedEvidence('invalid nearest surface result')
                    candidates.append((float(distance),prim.number()))
                distance, target_prim = min(candidates)
                distances.append(distance)
                if distance > base['tolerance']:
                    failure.append({'point':point.number(),'nearest_prim':target_prim,'distance':distance,'position':list(pos)})
        except (hou.Error, UnsupportedEvidence) as error:
            results.append({**base,'status':'unverified','reason':str(error)})
            continue
        results.append({**base,'status':'fail' if failure else 'pass','min_distance':min(distances),
                        'max_distance':max(distances),'failure_count':len(failure),
                        'failures':sorted(failure,key=lambda r:r['distance'],reverse=True)[:8]})
    order = {i['id']:n for n,i in enumerate(interfaces)}
    results.sort(key=lambda r:order[r['id']])
    status = 'fail' if any(r['status']=='fail' for r in results) else 'unverified' if any(r['status']=='unverified' for r in results) else 'pass'
    return {'ok':status=='pass','status':status,'results':results,'pair_tests':total_pairs,
            'coverage':'per-method declared selections; physical_extent compares one selected final Polygon group span in scene millimeters, proximity checks every source vertex against every target surface, solid_overlap uses bounded Boolean intersection of closed Polygon selections, axis_passage checks one declared line, bore_clearance checks a circumscribed 24-sided prism against the selected final solid, component_count counts edge-connected islands in a selected final Polygon group',
            'coordinate_space':'explicit output SOP local',
            'scope':'declared physical span, proximity, axis-projection, bounded solid-overlap, declared cylindrical clearance envelope, single-axis clearance or selected-group component count only; not continuous collision, full bore shape, mechanical strength or unspecified part completeness'}


def _physical_extent(g,item,node):
    group=g.findPrimGroup(item['target_group'])
    prims=list(group.prims()) if group else []
    base={'id':item['id'],'method':'physical_extent','target_group':item['target_group'],
          'axis':item['axis'],'expected_mm':item['expected_mm'],
          'tolerance_mm':item['tolerance_mm'],'target_count':len(prims),
          'scope':'one final Polygon primitive group, SOP-local axis span converted with HIP unit length; group semantics and shape are not certified'}
    if not prims:
        return {**base,'status':'fail','reason':'missing_target_group'}
    if len(prims)>20000:
        return {**base,'status':'unverified','reason':'physical_extent_polygon_budget_exceeded'}
    if any(p.type()!=hou.primType.Polygon or not _supported_surface(p) for p in prims):
        return {**base,'status':'unverified','reason':'physical_extent_requires_closed_polygon_surfaces'}
    vertex_count=sum(p.numVertices() for p in prims)
    if vertex_count>100000:
        return {**base,'status':'unverified','reason':'physical_extent_vertex_budget_exceeded'}
    obj=node
    while obj is not None and obj.type().category()!=hou.objNodeTypeCategory():
        obj=obj.parent()
    if obj is None:
        return {**base,'status':'unverified','reason':'missing_object_transform_context'}
    matrix=obj.worldTransform().asTuple()
    if any(not math.isfinite(float(value)) or abs(float(value)-float(identity))>1e-9 for value,identity in
           zip(matrix,hou.Matrix4(1).asTuple())):
        return {**base,'status':'unverified','reason':'object_transform_requires_world_space_review'}
    from dsh_context import unit_length_meters
    unit=unit_length_meters()
    if unit is None:
        return {**base,'status':'unverified','reason':'scene_unit_length_unavailable'}
    values=[float(point.position()[item['axis']]) for prim in prims for point in prim.points()]
    if not values or any(not math.isfinite(value) for value in values):
        return {**base,'status':'unverified','reason':'invalid_selected_point_positions'}
    span=max(values)-min(values)
    observed=span*unit*1000
    delta=observed-item['expected_mm']
    return {**base,'status':'pass' if abs(delta)<=item['tolerance_mm'] else 'fail',
            'observed_sop_local_span':span,'scene_unit_length_meters':unit,
            'observed_mm':observed,'delta_mm':delta,
            'selected_points':len(values),
            'boundary':'Checks only this selected group axis. Verify source dimension ownership, complete part identity and other required axes separately.'}


def _component_count(g, item):
    group=g.findPrimGroup(item['target_group'])
    prims=list(group.prims()) if group else []
    base={'id':item['id'],'method':'component_count','target_group':item['target_group'],
          'target_count':len(prims),'expected_components':item['expected_components'],
          'scope':'edge-connected Polygon islands in one declared final-output group; not semantic part identity, shape or connection to the rest of the asset'}
    if not prims:
        return {**base,'status':'fail','reason':'missing_target_group'}
    if len(prims)>20000:
        raise ValueError('component_count polygon budget exceeded; narrow the final part group')
    if any(p.type().name()!='Polygon' or not _supported_surface(p) for p in prims):
        return {**base,'status':'unverified','reason':'component_count_requires_polygon_surfaces'}
    parents={p.number():p.number() for p in prims}
    edges=defaultdict(list);vertices=0
    def root(n):
        while parents[n]!=n:
            parents[n]=parents[parents[n]];n=parents[n]
        return n
    for prim in prims:
        ids=[v.point().number() for v in prim.vertices()]
        vertices+=len(ids)
        if vertices>100000:
            raise ValueError('component_count vertex budget exceeded; narrow the final part group')
        area=float(prim.intrinsicValue('measuredarea'))
        if len(set(ids))!=len(ids) or not math.isfinite(area) or area<=0:
            return {**base,'status':'unverified','reason':'degenerate_selected_polygon'}
        for a,b in zip(ids,ids[1:]+ids[:1]):
            edges[tuple(sorted((a,b)))].append(prim.number())
    for owners in edges.values():
        for n in owners[1:]:parents[root(n)]=root(owners[0])
    components=len({root(n) for n in parents})
    return {**base,'status':'pass' if components==item['expected_components'] else 'fail',
            'observed_components':components,'selected_vertices':vertices,
            'boundary':'Only edge connectivity of the declared Polygon group was counted. Declare expected members from the request before inspecting survivors; separately verify each required connection and visible shape.'}


def _axis_passage(g, item):
    group=g.findPrimGroup(item['target_group'])
    prims=list(group.prims()) if group else []
    base={'id':item['id'],'method':'axis_passage','target_group':item['target_group'],
          'target_count':len(prims),'axis':item['axis'],'start':list(item['start']),
          'end':list(item['end']),'scope':'single declared centerline in final SOP-local Polygon group; bore radius and surrounding material are not certified'}
    if not prims:
        return {**base,'status':'fail','reason':'missing_target_group'}
    if any(p.type().name()!='Polygon' or not _supported_surface(p) for p in prims):
        return {**base,'status':'unverified','reason':'axis_passage_requires_closed_polygon_surfaces'}
    axis=item['axis'];start=item['start'];end=item['end']
    lower=[min(float(p.boundingBox().minvec()[i]) for p in prims) for i in range(3)]
    upper=[max(float(p.boundingBox().maxvec()[i]) for p in prims) for i in range(3)]
    if (min(float(start[axis]),float(end[axis])) >= lower[axis]-1e-6
            or max(float(start[axis]),float(end[axis])) <= upper[axis]+1e-6
            or any(not lower[i]+1e-6 < float(start[i]) < upper[i]-1e-6 for i in range(3) if i!=axis)):
        return {**base,'status':'unverified','reason':'segment_does_not_cross_target_bounds',
                'target_bounds':[lower,upper]}
    origin=hou.Vector3(start)
    direction=hou.Vector3(end)-origin
    length=direction.length()
    direction/=length
    position=hou.Vector3();normal=hou.Vector3();uvw=hou.Vector3()
    try:
        hit=g.intersect(origin,direction,position,normal,uvw,pattern=item['target_group'],
                        min_hit=0.0,max_hit=length,tolerance=1e-6)
    except hou.Error as error:
        return {**base,'status':'unverified','reason':str(error)}
    if hit >= 0:
        return {**base,'status':'fail','reason':'axis_intersects_final_surface',
                'hit_primitive':hit,'hit_position':list(position),
                'hit_distance':float(origin.distanceTo(position))}
    return {**base,'status':'pass','clear_length':float(length),
            'boundary':'Only this centerline is clear; check bore radius, rim geometry and other required axes separately.'}


def _bore_clearance(g, item, budget):
    """Intersect a circumscribed cylinder envelope with one final closed part group."""
    axis=item['axis'];start=[float(v) for v in item['start']];end=[float(v) for v in item['end']]
    radius=float(item['radius']);sides=24
    base={'id':item['id'],'method':'bore_clearance','target_group':item['target_group'],
          'axis':axis,'start':start,'end':end,'radius':radius,'sides':sides,
          'coordinate_space':'explicit output SOP local',
          'scope':'declared straight cylindrical clearance envelope over exactly the start/end interval in one final closed Polygon group; no proof of material around it, continuation beyond either end, nominal bore shape, tolerance, other holes or motion'}
    group=g.findPrimGroup(item['target_group'])
    prims=list(group.prims()) if group else []
    base['target_count']=len(prims)
    if not prims:
        return {**base,'status':'fail','reason':'missing_target_group'},0
    if len(prims)>4000 or len(prims)*sides>budget:
        raise ValueError('bore_clearance Boolean budget exceeded; narrow the final part group or raise max_pairs')
    if any(p.type()!=hou.primType.Polygon or not _supported_surface(p) for p in prims):
        return {**base,'status':'unverified','reason':'bore_clearance_requires_closed_polygon_surfaces'},0
    lower=[min(float(p.boundingBox().minvec()[i]) for p in prims) for i in range(3)]
    upper=[max(float(p.boundingBox().maxvec()[i]) for p in prims) for i in range(3)]
    if (min(start[axis],end[axis]) >= upper[axis]-1e-6
            or max(start[axis],end[axis]) <= lower[axis]+1e-6
            or any(not lower[i]+1e-6 < start[i] < upper[i]-1e-6 for i in range(3) if i!=axis)):
        return {**base,'status':'unverified','reason':'segment_does_not_overlap_target_bounds',
                'target_bounds':[lower,upper]},0
    from dsh_geometry_observation import polygon_observation
    observed=polygon_observation(g,group=item['target_group'],integrity_only=True)
    shell=observed.get('shell_orientation',{})
    check={key:observed.get(key) for key in ('status','boundary_edges','nonmanifold_edges',
            'orientation_conflicts','zero_area_faces','zero_length_edges','duplicate_boundary_faces')}
    check.update(positive_closed_shells=shell.get('positive_count'),
                 negative_closed_shells=shell.get('negative_count'),
                 unverified_shells=shell.get('unverified_count'))
    if (observed.get('status')!='observed' or any(observed.get(key) for key in
            ('boundary_edges','nonmanifold_edges','orientation_conflicts','zero_area_faces',
             'zero_length_edges','duplicate_boundary_faces')) or
            not shell.get('positive_count') or shell.get('negative_count') or shell.get('unverified_count')):
        return {**base,'status':'unverified','reason':'selection_not_complete_consistent_outward_polygon_solid',
                'selection_check':check},0
    # The polygon's apothem equals the requested radius. A clear circumscribed
    # prism therefore contains the whole requested circular cross-section.
    u,v=((1,2),(2,0),(0,1))[axis]
    vertex_radius=radius/math.cos(math.pi/sides)
    envelope=hou.Geometry()
    rings=[]
    for axial in (min(start[axis],end[axis]),max(start[axis],end[axis])):
        ring=[]
        for index in range(sides):
            angle=2*math.pi*(index+.5)/sides
            position=list(start);position[axis]=axial
            position[u]+=vertex_radius*math.cos(angle)
            position[v]+=vertex_radius*math.sin(angle)
            point=envelope.createPoint();point.setPosition(position);ring.append(point)
        rings.append(ring)
    def face(points):
        polygon=envelope.createPolygon()
        for point in points:polygon.addVertex(point)
    face(rings[0])
    face(list(reversed(rings[1])))
    for index in range(sides):
        following=(index+1)%sides
        face((rings[1][index],rings[1][following],rings[0][following],rings[0][index]))
    envelope_check=polygon_observation(envelope,integrity_only=True)
    envelope_shell=envelope_check.get('shell_orientation',{})
    if not envelope_shell.get('positive_count') or envelope_shell.get('negative_count'):
        return {**base,'status':'unverified','reason':'internal_clearance_envelope_not_outward',
                'envelope_check':envelope_check},0
    target=hou.Geometry(g)
    keep={p.number() for p in prims}
    target.deletePrims([p for p in target.prims() if p.number() not in keep],False)
    target.incrementAllDataIds();envelope.incrementAllDataIds()
    verb=hou.sopNodeTypeCategory().nodeVerb('boolean::2.0')
    if verb is None:
        return {**base,'status':'unverified','reason':'boolean_verb_unavailable','selection_check':check},0
    pairs=len(prims)*sides
    try:
        verb.setParms({'booleanop':1,'asurface':0,'bsurface':0})
        intersection=hou.Geometry()
        verb.execute(intersection,[target,envelope])
        count=len(intersection.prims())
        if not count:
            return {**base,'status':'pass','intersection_primitives':0,
                    'overlap_volume':0.0,'selection_check':check},pairs
        if count>5000 or intersection.intrinsicValue('memoryusage')>16*1024*1024:
            return {**base,'status':'unverified','reason':'intersection_output_budget_exceeded',
                    'intersection_primitives':count,'selection_check':check},pairs
        result=polygon_observation(intersection,integrity_only=True)
        result_shell=result.get('shell_orientation',{})
        if (result.get('status')!='observed' or any(result.get(key) for key in
                ('boundary_edges','nonmanifold_edges','orientation_conflicts','zero_area_faces',
                 'zero_length_edges','duplicate_boundary_faces')) or
                not result_shell.get('positive_count') or result_shell.get('negative_count') or result_shell.get('unverified_count')):
            return {**base,'status':'unverified','reason':'intersection_not_complete_consistent_polygon_solid',
                    'intersection_primitives':count,'selection_check':check},pairs
        volume=math.fsum(float(p.intrinsicValue('measuredvolume')) for p in intersection.prims())
        scale=max(float(v) for v in envelope.boundingBox().sizevec())
        floor=max(scale**3*1e-12,1e-18)
        if not math.isfinite(volume) or volume<=floor:
            return {**base,'status':'unverified','reason':'intersection_volume_at_numeric_noise_floor',
                    'overlap_volume':volume if math.isfinite(volume) else None,
                    'numeric_noise_floor':floor,'intersection_primitives':count,'selection_check':check},pairs
        bounds=intersection.boundingBox()
        return {**base,'status':'fail','reason':'declared_clearance_intersects_final_solid',
                'overlap_volume':volume,'numeric_noise_floor':floor,
                'overlap_bounds':[[float(v) for v in bounds.minvec()],
                                  [float(v) for v in bounds.maxvec()]],
                'intersection_primitives':count,'selection_check':check},pairs
    except (hou.Error,ValueError,TypeError,OverflowError) as error:
        return {**base,'status':'unverified','reason':'boolean_intersection_failed',
                'detail':str(error)[:200],'selection_check':check},pairs


def _solid_overlap(g, item, budget):
    """Bounded Boolean intersection of two named complete Polygon solids."""
    base={**item,'coordinate_space':'explicit output SOP local',
          'scope':'selected closed Polygon solids only; no continuous sweep, load or strength claim'}
    selected=[]
    for name in (item['source_group'],item['target_group']):
        group=g.findPrimGroup(name)
        selected.append(list(group.prims()) if group else [])
    source,target=selected
    counts={'source_count':len(source),'target_count':len(target)}
    if not source or not target:
        return {**base,**counts,'status':'fail','reason':'missing_or_empty_primitive_group'},0
    if {p.number() for p in source} & {p.number() for p in target}:
        return {**base,**counts,'status':'fail','reason':'source_and_target_overlap_cannot_self_validate'},0
    if {p.number() for prim in source for p in prim.points()} & {p.number() for prim in target for p in prim.points()}:
        return {**base,**counts,'status':'fail','reason':'source_and_target_share_points_cannot_self_validate'},0
    if len(source)>20000 or len(target)>20000:
        raise ValueError('solid_overlap operand exceeds 20000 face budget; select complete parts')
    from dsh_geometry_evidence import candidate_face_pairs
    pairs=candidate_face_pairs(source,target,budget)
    base['broad_phase']={'candidate_face_pairs':pairs,'cartesian_face_pairs':len(source)*len(target),
                         'method':'axis sweep of face bounds; full operands retained for Boolean containment'}
    from dsh_geometry_observation import polygon_observation
    checks=[]
    for name in (item['source_group'],item['target_group']):
        observed=polygon_observation(g,group=name,integrity_only=True)
        shell=observed.get('shell_orientation',{})
        checks.append({'group':name,**{key:observed.get(key) for key in
                       ('status','boundary_edges','nonmanifold_edges','orientation_conflicts',
                        'zero_area_faces','zero_length_edges','duplicate_boundary_faces')},
                       'positive_closed_shells':shell.get('positive_count'),
                       'negative_closed_shells':shell.get('negative_count'),
                       'unverified_shells':shell.get('unverified_count')})
        if (observed.get('status')!='observed' or any(observed.get(key) for key in
                ('boundary_edges','nonmanifold_edges','orientation_conflicts','zero_area_faces',
                 'zero_length_edges','duplicate_boundary_faces')) or
                not shell.get('positive_count') or shell.get('negative_count') or shell.get('unverified_count')):
            return {**base,**counts,'status':'unverified',
                    'reason':'selection_not_complete_consistent_outward_polygon_solid',
                    'selection_checks':checks},0
    copies=[]
    for prims in selected:
        copy=hou.Geometry(g)
        keep={p.number() for p in prims}
        copy.deletePrims([p for p in copy.prims() if p.number() not in keep],False)
        # A modified standalone Geometry passed into a SOP Verb must publish
        # fresh data IDs; otherwise the verb may reuse stale cached inputs.
        copy.incrementAllDataIds()
        copies.append(copy)
    verb=hou.sopNodeTypeCategory().nodeVerb('boolean::2.0')
    if verb is None:
        return {**base,**counts,'status':'unverified','reason':'boolean_verb_unavailable',
                'selection_checks':checks},0
    try:
        verb.setParms({'booleanop':1,'asurface':0,'bsurface':0})  # Solid/Solid Intersect; no scene node.
        intersection=hou.Geometry()
        verb.execute(intersection,copies)
        count=len(intersection.prims())
        if count==0:
            return {**base,**counts,'status':'pass','overlap_volume':0.0,
                    'intersection_primitives':0,'selection_checks':checks},pairs
        if count>5000 or intersection.intrinsicValue('memoryusage')>16*1024*1024:
            return {**base,**counts,'status':'unverified','reason':'intersection_output_budget_exceeded',
                    'intersection_primitives':count,'selection_checks':checks},pairs
        observed=polygon_observation(intersection,integrity_only=True)
        shell=observed.get('shell_orientation',{})
        if (observed.get('status')!='observed' or any(observed.get(key) for key in
                ('boundary_edges','nonmanifold_edges','orientation_conflicts','zero_area_faces',
                 'zero_length_edges','duplicate_boundary_faces')) or
                not shell.get('positive_count') or shell.get('negative_count') or shell.get('unverified_count')):
            return {**base,**counts,'status':'unverified',
                    'reason':'intersection_not_complete_consistent_polygon_solid',
                    'intersection_primitives':count,'selection_checks':checks},pairs
        volume=math.fsum(float(prim.intrinsicValue('measuredvolume')) for prim in intersection.prims())
        scale=max(float(v) for copy in copies for v in copy.boundingBox().sizevec())
        noise_floor=max(scale**3*1e-12,1e-18)
        if not math.isfinite(volume) or volume<=noise_floor:
            return {**base,**counts,'status':'unverified',
                    'reason':'intersection_volume_at_numeric_noise_floor',
                    'overlap_volume':volume if math.isfinite(volume) else None,
                    'numeric_noise_floor':noise_floor,'intersection_primitives':count,
                    'selection_checks':checks},pairs
        bounds=intersection.boundingBox()
        bounds_min=[float(v) for v in bounds.minvec()]
        bounds_max=[float(v) for v in bounds.maxvec()]
        return {**base,**counts,'status':'pass' if volume<=item['max_overlap_volume'] else 'fail',
                'overlap_volume':volume,'numeric_noise_floor':noise_floor,
                'overlap_bounds':[bounds_min,bounds_max],
                'overlap_bounds_center':[(lo+hi)*.5 for lo,hi in zip(bounds_min,bounds_max)],
                'overlap_bounds_scope':'SOP-local axis-aligned envelope of all Boolean intersection pieces; not a contact point or single-island location',
                'intersection_primitives':count,'selection_checks':checks},pairs
    except (hou.Error, ValueError, TypeError, OverflowError) as error:
        return {**base,**counts,'status':'unverified','reason':'boolean_intersection_failed',
                'detail':str(error)[:200],'selection_checks':checks},pairs


def _section_proximity(g,item,budget):
    base={**item,'scope':'actual polygon-plane section segment midpoints to target surfaces; not full-surface contact, penetration or strength'}
    source=g.findPrimGroup(item['source_group']);target=g.findPrimGroup(item['target_group'])
    sp=list(source.prims()) if source else [];tp=list(target.prims()) if target else []
    if not sp or not tp:return {**base,'status':'fail','reason':'missing_or_empty_primitive_group'},0
    if {p.number() for s in sp for p in s.points()} & {p.number() for s in tp for p in s.points()}:
        return {**base,'status':'fail','reason':'source_and_target_overlap_cannot_self_validate'},0
    if any(not _supported_surface(p) for p in tp):return {**base,'status':'unverified','reason':'unsupported_target_surface_type'},0
    axis=item['axis'];position=item['plane_at']
    if position=='target_center':
        position=(min(p.boundingBox().minvec()[axis] for p in tp)+max(p.boundingBox().maxvec()[axis] for p in tp))*.5
    if not math.isfinite(position):return {**base,'status':'unverified','reason':'nonfinite plane'},0
    from dsh_geometry_observation import surface_sections
    try:samples,coverage=surface_sections(sp,axis,position,item['expected_components'])
    except ValueError as error:
        missing=str(error) in ('source component count differs from expected_components','each source component must have a nonempty closed section')
        return {**base,'status':'fail' if missing else 'unverified','reason':str(error),'plane_position':position},0
    pairs=len(samples)*len(tp)
    if pairs>budget:raise ValueError('interface nearest-surface budget exceeded; narrow explicit groups')
    distances=[];failures=[]
    try:
        for sample in samples:
            candidates=[p.nearestToPosition(sample['position'])[2] for p in tp]
            if any(not math.isfinite(d) or d<0 for d in candidates):raise UnsupportedEvidence('invalid nearest surface result')
            distance=min(candidates);distances.append(distance)
            if distance>item['max_distance']:
                failures.append({'distance':distance,'position':list(sample['position']),'component':sample['component']})
    except (hou.Error,UnsupportedEvidence) as error:return {**base,'status':'unverified','reason':str(error)},pairs
    return {**base,'status':'fail' if failures else 'pass','plane_position':position,
            'source_count':len(samples),'component_coverage':coverage,'min_distance':min(distances),'max_distance':max(distances),
            'failure_count':len(failures),'failures':sorted(failures,key=lambda r:r['distance'],reverse=True)[:8]},pairs


def _axis_gap(g, item):
    """Actual selected surface bounds, not design anchors or duplicated formulas.

    Positive gap means source is above target along the declared axis. Transverse
    interval overlap is necessary but never sufficient to prove surface contact.
    """
    base = {**item, 'coordinate_space':'explicit output SOP local',
            'scope':'source bounds_min minus target bounds_max; transverse interval overlap only, not physical contact/penetration'}
    groups = [g.findPrimGroup(item[k]) for k in ('source_group','target_group')]
    selections = [list(group.prims()) if group else [] for group in groups]
    if any(not s for s in selections):
        return {**base,'status':'fail','reason':'missing_or_empty_primitive_group'}
    if {p.number() for p in selections[0]} & {p.number() for p in selections[1]}:
        return {**base,'status':'fail','reason':'source_and_target_overlap_cannot_self_validate'}
    if any(not _supported_surface(p) for s in selections for p in s):
        return {**base,'status':'unverified','reason':'unsupported_surface_type'}
    bounds = []
    for prims in selections:
        box = prims[0].boundingBox()
        for prim in prims[1:]:box.enlargeToContain(prim.boundingBox())
        bounds.append(([float(v) for v in box.minvec()],[float(v) for v in box.maxvec()]))
    if not all(math.isfinite(v) for box in bounds for side in box for v in side):
        return {**base,'status':'unverified','reason':'nonfinite_bounds'}
    axis=item['axis'];gap=bounds[0][0][axis]-bounds[1][1][axis]
    overlap={str(i):min(bounds[0][1][i],bounds[1][1][i])-max(bounds[0][0][i],bounds[1][0][i]) for i in range(3) if i!=axis}
    ok=item['gap_range'][0]<=gap<=item['gap_range'][1] and all(v>=item['min_overlap'] for v in overlap.values())
    return {**base,'status':'pass' if ok else 'fail','gap':gap,'transverse_overlap':overlap,
            'source_bounds':bounds[0],'target_bounds':bounds[1],
            'source_primitive_count':len(selections[0]),'target_primitive_count':len(selections[1])}


def geo_check_interfaces(output, interfaces, max_pairs=50000):
    """Measure declared surface interfaces in ONE actual output, not proxy nodes."""
    validate_interfaces(interfaces)
    if type(max_pairs) is not int or not 1 <= max_pairs <= 100000:
        raise ValueError('max_pairs must be in 1..100000')
    node, g = _geometry(output)
    from dsh_geometry_evidence import expanded_view
    try:
        observed,representation=expanded_view(g,allow_native_unknown=True)
    except ValueError as error:
        return {'ok':False,'status':'unverified','output':node.path(),'reason':str(error),
                'results':[],'semantic_status':'unverified',
                'contract_sha256':hashlib.sha256(json.dumps(interfaces,sort_keys=True).encode()).hexdigest()}
    result = _check_interfaces(observed, interfaces, max_pairs, node)
    result['representation']=representation
    return {**result,'output':node.path(),'frame':float(hou.frame()),'checked_at':time.time(),
            'geometry_sha256':_data_signature(g),'contract_sha256':hashlib.sha256(json.dumps(interfaces,sort_keys=True).encode()).hexdigest(),
            'semantic_status':'unverified','next_action':'Repair failing declared interfaces then rerun; this does not certify unspecified relationships.'}


def validate_topology(topology):
    if not isinstance(topology,list) or not 1<=len(topology)<=16:
        raise ValueError('topology needs 1..16 shared-surface contracts')
    ids=set()
    for c in topology:
        _exact_keys(c,{'id','groups','require_closed'},'topology')
        if not isinstance(c.get('id'),str) or not c['id'].strip() or c['id'] in ids:raise ValueError('topology ids must be nonempty and unique')
        ids.add(c['id']);groups=c.get('groups')
        if (not isinstance(groups,list) or not 2<=len(groups)<=16 or any(not isinstance(n,str) or not n.strip() for n in groups)
                or len(set(groups))!=len(groups)):raise ValueError('topology groups must name 2..16 distinct nonempty primitive groups')
        if type(c.get('require_closed',True)) is not bool:raise ValueError('require_closed must be bool')


def _check_topology(g, topology):
    """Shared polygon EDGE connectivity of named final surfaces, never proximity.

    A point-touch, disconnected overlapping boxes or unrelated driver points do
    not prove a fused surface. Not a solid intersection/strength/shape oracle.
    """
    results=[]
    for c in topology:
        row={'id':c['id'],'method':'shared_polygon_edges','groups':c['groups'],
             'require_closed':c.get('require_closed',True),'scope':'selected final polygon surface topology only; not strength, self-intersection or intended shape'}
        selected={};reason=None
        for name in c['groups']:
            group=g.findPrimGroup(name);prims=list(group.prims()) if group is not None else []
            if not prims:reason='missing_or_empty_part_group';break
            if any(p.number() in selected for p in prims):reason='overlapping_part_groups_cannot_self_validate';break
            selected.update((p.number(),p) for p in prims)
        if reason:
            results.append({**row,'status':'fail','reason':reason});continue
        if len(selected)>20000:raise ValueError('topology budget exceeded; narrow selected surfaces')
        if any(p.type().name()!='Polygon' or not bool(p.intrinsicValue('closed')) for p in selected.values()):
            results.append({**row,'status':'unverified','reason':'shared topology supports closed Polygon faces only'});continue
        edges=defaultdict(list);directed=Counter();parents={n:n for n in selected};vertices=0
        def root(n):
            while parents[n]!=n:
                parents[n]=parents[parents[n]];n=parents[n]
            return n
        for n,p in selected.items():
            ids=[v.point().number() for v in p.vertices()];vertices+=len(ids)
            if vertices>100000:raise ValueError('topology vertex budget exceeded')
            area=float(p.intrinsicValue('measuredarea'))
            if len(set(ids))!=len(ids) or len(ids)<3 or not math.isfinite(area) or area<=0:
                reason='degenerate_polygon_face';break
            positions=[tuple(v.point().position()) for v in p.vertices()]
            if any(not math.isfinite(x) for pos in positions for x in pos) or any(a==b for a,b in zip(positions,positions[1:]+positions[:1])):
                reason='nonfinite_or_zero_length_surface_edge';break
            for a,b in zip(ids,ids[1:]+ids[:1]):edges[tuple(sorted((a,b)))].append(n);directed[a,b]+=1
        if reason:
            results.append({**row,'status':'fail','reason':reason});continue
        for owners in edges.values():
            for n in owners[1:]:parents[root(n)]=root(owners[0])
        components=len({root(n) for n in parents})
        boundary=sum(len(v)==1 for v in edges.values());nonmanifold=sum(len(v)>2 for v in edges.values())
        orientation=sum(len(owners)==2 and directed[a,b]!=directed[b,a] for (a,b),owners in edges.items())
        failures=[]
        if components!=1:failures.append('disconnected_selected_surfaces')
        if nonmanifold:failures.append('nonmanifold_edges')
        if row['require_closed'] and boundary:failures.append('open_selected_surface')
        if orientation:failures.append('inconsistent_face_orientation')
        results.append({**row,'status':'fail' if failures else 'pass','failure_reasons':failures,
                        'surface_components':components,'boundary_edges':boundary,'nonmanifold_edges':nonmanifold,
                        'orientation_conflicts':orientation,'selected_prims':len(selected),
                        'next_action':'For fused parts fix shared final topology; for separate touching parts use independent surface interfaces, not this method.'})
    status='fail' if any(r['status']=='fail' for r in results) else 'unverified' if any(r['status']=='unverified' for r in results) else 'pass'
    return {'ok':status=='pass','status':status,'results':results,'semantic_status':'unverified'}


def _validate_expectation(item):
    _exact_keys(item, {'group','metric','axis','delta','range','id_attrib','transform'}, 'expectation')
    metric = item.get('metric')
    if metric not in ('bounds_size','bounds_center','bounds_min','bounds_max','point_count','primitive_count','area','point_mean','boundary_edges','piece_count','max_point_displacement','mean_point_displacement','max_transform_error'):
        raise ValueError('unsupported metric; exact values: bounds_size, bounds_center, bounds_min, bounds_max, point_count, primitive_count, area, point_mean, boundary_edges, piece_count, max_point_displacement, mean_point_displacement, max_transform_error')
    if (metric.startswith('bounds_') or metric == 'point_mean') and (type(item.get('axis')) is not int or not 0 <= item['axis'] <= 2):
        raise ValueError('bounds metric needs axis=0/1/2')
    if 'group' in item and (not isinstance(item['group'],str) or not item['group']):
        raise ValueError('group must name a nonempty primitive group in the actual output')
    delta = item.get('delta')
    if not isinstance(delta, (list,tuple)) or len(delta) != 2:
        raise ValueError('expected signed delta must be [minimum,maximum]')
    lo, hi = [_finite(v,'delta') for v in delta]
    if lo > hi:
        raise ValueError('delta minimum must be <= maximum')
    if ('displacement' in metric or metric=='max_transform_error') and (not isinstance(item.get('id_attrib'),str) or not item['id_attrib']):
        raise ValueError('point displacement requires stable unique point id_attrib')
    if metric == 'max_transform_error':
        matrix=item.get('transform')
        if not isinstance(matrix,list) or len(matrix)!=16:
            raise ValueError('transform must be a row-major 16-number SOP-local affine matrix (Houdini row-vector convention)')
        values=[_finite(v,'transform') for v in matrix]
        if any(abs(values[i])>1e-10 for i in (3,7,11)) or abs(values[15]-1)>1e-10:
            raise ValueError('transform must be affine')
    elif 'transform' in item:
        raise ValueError('transform is only valid with max_transform_error')
    if 'range' in item:
        r=item['range']
        if not isinstance(r,(list,tuple)) or len(r)!=2 or _finite(r[0],'range')>_finite(r[1],'range'):
            raise ValueError('range must be finite [minimum,maximum] for both baseline and test value')


def _measure(g, item, reference=None):
    group = g.findPrimGroup(item['group']) if item.get('group') else None
    if item.get('group') and group is None:
        raise ValueError(f'missing measurement group {item["group"]!r}')
    prims = list(group.prims()) if group is not None else list(g.prims())
    metric = item['metric']
    if metric in ('max_point_displacement','mean_point_displacement','max_transform_error'):
        from dsh_geometry_observation import point_displacement
        # Baseline residual is zero against identity, not against the future
        # perturbation transform. Still validate identity/topology and finiteness.
        measure_item = {**item,'transform':list(hou.Matrix4(1).asTuple())} if metric=='max_transform_error' and reference is None else item
        try:return point_displacement(g, reference if reference is not None else g, measure_item)
        except ValueError as error:raise UnsupportedEvidence(str(error)) from error
    if metric in ('boundary_edges','piece_count'):
        from dsh_geometry_observation import polygon_observation
        report=polygon_observation(g,item.get('group'))
        if report['status']!='observed':raise UnsupportedEvidence(report['reason'])
        return report['boundary_edges' if metric=='boundary_edges' else 'edge_connected_components']
    if metric == 'point_mean':
        if any(p.type()!=hou.primType.Polygon for p in prims):raise UnsupportedEvidence('point_mean is polygon point observation only, not native primitive response')
        points={p.number():p for prim in prims for p in prim.points()}
        if not points:raise ValueError('empty point selection')
        if len(points)>50000:raise UnsupportedEvidence('point_mean exceeds 50000 point budget')
        return sum(float(p.position()[item['axis']]) for p in points.values())/len(points)
    if group is not None and not prims:
        raise ValueError('measurement selection is empty')
    if not prims and metric != 'point_count':
        raise ValueError('measurement selection is empty')
    if metric == 'primitive_count':return len(prims)
    if metric == 'point_count':
        return len({p.number() for prim in prims for p in prim.points()}) if group is not None else int(g.intrinsicValue('pointcount'))
    # Bounds are explicitly spatial response metrics, not proof of connectivity.
    if metric.startswith('bounds_'):
        # The default hou.BoundingBox contains the origin; it is not an empty
        # accumulator. Starting there corrupts local measurements off-origin.
        bbox = prims[0].boundingBox()
        for prim in prims[1:]:bbox.enlargeToContain(prim.boundingBox())
        values = {'bounds_min':bbox.minvec(),'bounds_max':bbox.maxvec(),'bounds_size':bbox.sizevec(),'bounds_center':bbox.center()}
        return float(values[metric][item['axis']])
    unsupported = [p for p in prims if not _supported_surface(p)]
    if unsupported:
        raise UnsupportedEvidence('area not verified for this primitive representation', diagnostic={
            'selected_primitives': len(prims), 'unsupported_primitives': len(unsupported),
            'primitive_types': dict(Counter(p.type().name() for p in prims)),
            'unsupported_sample': [{'primitive': p.number(), 'type': p.type().name(),
                                    'vertices': p.numVertices(),
                                    **({'closed': bool(p.intrinsicValue('closed'))}
                                       if p.type() == hou.primType.Polygon else {})} for p in unsupported[:8]],
            'sample_truncated': len(unsupported) > 8,
            'supported_surfaces': 'closed Polygon faces with at least three vertices, Mesh, Sphere, Tube',
            'next_action': 'Inspect the reported primitive selection. For surface area select an actual surface group; for curves choose a measurement of the intended curve behavior. Changing the metric does not verify the original claim.',
        })
    return sum(float(p.intrinsicValue('measuredarea')) for p in prims)


def _measure_case(g, test, index, item, reference=None):
    """Attach the exact failed selection, without changing measurement semantics."""
    try:
        return _measure(g, item, reference)
    except UnsupportedEvidence as error:
        raise UnsupportedEvidence(str(error), diagnostic={
            'case_id': test['id'], 'expectation_index': index,
            'expectation': item, **error.diagnostic,
        }) from error


def validate_capture_views(views):
    if not isinstance(views,list) or len(views)>2 or any(v not in ('iso','front','side','top') for v in views):
        raise ValueError('views must be at most two of iso/front/side/top')


def capture_views(output, views, *, locks=None, view_bounds=None, frame=None):

    validate_capture_views(views)
    captures=[]
    for view in views:
        if not hou.isUIAvailable():
            captures.append({'view':view,'status':'unverified','reason':'GUI/OpenGL unavailable'});continue
        options = {'frame':frame, 'framing_frame':frame}
        if locks is not None:
            lock=locks.get(view)
            if lock is None:
                captures.append({'view':view,'status':'unverified','reason':'baseline capture unavailable; camera was not refitted'})
                continue
            options.update(framing_bounds=lock['bounds'],depth_bounds=lock['depth_bounds'])
        elif view_bounds is not None:
            options.update(framing_bounds=view_bounds,depth_bounds=view_bounds)
        try:
            result=dsh_render.render_view(output,direction=view,**options)
        except dsh_errors.CheckpointError as error:
            facts=error.evidence
            if facts.get('render_started') is not False or facts.get('framing_status')!='failed' or facts.get('user_state_restored') is not True:
                raise
            captures.append({**facts,'view':view,'status':'unverified','reason':str(error)[:400]})
            continue
        except (ValueError, hou.Error) as error:
            captures.append({'view':view,'status':'unverified','reason':str(error)[:400]})
            continue
        captures.append({k:result[k] for k in ('ok','output','picture','artifact','file_status','pixel_status','semantic_status','stale','camera','framing','check','errors','user_state_restored') if k in result} | {'view':view})
        if result.get('user_state_restored') is False:
            raise dsh_errors.CheckpointError('review capture did not restore user state',{'restored':False,'captures':captures})
    return captures


def _control_summary(result, tests, interfaces=None, topology=None, baseline_interfaces=None):
    """Keep zero-write baseline failures visible even when results is empty."""
    rows = result.get('results', [])
    by_id = {r['id']: r for r in rows}
    cases = []
    for test in tests:
        row = by_id.get(test['id'], {})
        measurements = row.get('measurements', [])
        cases.append({'id': test['id'],
                      'status':'fail' if row.get('restored') is False else row.get('status', 'not_run'),
                      'measurement_status':row.get('status', 'not_run'),
                      'controls': sorted(test['values']),
                      'output_data_changed': row.get('geometry_changed'),
                      'measured_groups': sorted({m['expectation']['group'] for m in measurements
                                                 if m['expectation'].get('group') is not None}),
                      'whole_output_measurements': sum(m['expectation'].get('group') is None for m in measurements),
                      'measurement_count': len(measurements),
                      'interface_count': len(interfaces or []) + len(test.get('interfaces') or []),
                      'interface_status': row.get('interfaces', {}).get('status') if isinstance(row.get('interfaces'), dict) else 'not_checked',
                      'topology_status': row.get('topology', {}).get('status') if isinstance(row.get('topology'), dict) else 'not_checked',
                      'changed_output_with_failed_measurements': row.get('geometry_changed') is True and any(not m['pass'] for m in measurements)})
    counts = {status: sum(c['status'] == status for c in cases)
              for status in ('pass', 'fail', 'unverified', 'not_run')}
    baseline_result=result.get('baseline_interfaces')
    baseline_status=(baseline_result.get('status') if isinstance(baseline_result,dict) else 'not_checked')
    checked_cases=sum(case['interface_status']!='not_checked' for case in cases)
    executed_interfaces=(len(baseline_result.get('results',[])) if isinstance(baseline_result,dict) else 0)
    executed_interfaces+=sum(len(row['interfaces'].get('results',[])) for row in rows
                             if isinstance(row.get('interfaces'),dict))
    topology_observed=isinstance(result.get('baseline_topology'),dict) or any(
        case['topology_status']!='not_checked' for case in cases)
    declared_interfaces=(len(interfaces or [])+len(baseline_interfaces or [])+
                         sum(len(test.get('interfaces',[])) for test in tests))
    failures = []
    for row in rows:
        if row['status'] == 'pass' and row.get('restored') is not False:
            continue
        failed = [m for m in row.get('measurements', []) if not m['pass']]
        failures.append({'id': row['id'], 'status': row['status'],
                         **{k: row[k] for k in ('reason', 'restored', 'geometry_changed', 'restore_errors', 'measurement_failure',
                                               'parameter_restore', 'geometry_restore') if k in row},
                         'failed_measurements': failed[:8],
                         'failed_measurement_count': len(failed),
                         'relation_status': {k: row[k]['status'] for k in ('interfaces', 'topology')
                                             if isinstance(row.get(k), dict)}})
    return {'status': result['status'], 'ok': result['ok'], 'restored': result['restored'],
            'capture_status':result.get('capture_status','not_requested'),
            'requested_cases': len(tests), 'case_counts': counts, 'cases': cases,
            'coverage': {'acceptance': 'declared_checks_only',
                         'declared_controls': sorted({name for t in tests for name in t['values']}),
                         'declared_interfaces': declared_interfaces,
                         'baseline_interface_contracts_declared': len(interfaces or [])+len(baseline_interfaces or []),
                         'case_interface_contracts_declared': sum(len(test.get('interfaces',[])) for test in tests),
                         'baseline_interface_status': baseline_status,
                         'cases_with_interface_checks': checked_cases,
                         'executed_interface_checks': executed_interfaces,
                         'declared_topology_contracts': len(topology or []),
                         'measured_cases': sum(c['measurement_count'] > 0 for c in cases),
                         'relationship_scope': 'declared_contracts_only' if executed_interfaces or topology_observed
                                               else 'declared_not_run' if declared_interfaces or topology else 'not_checked',
                         'boundary': 'Declared interface counts are plans; executed counts report observed checks. '
                                     'Global interfaces cover baseline and every case, baseline_interfaces only baseline, '
                                     'case interfaces only their perturbed state. '
                                     'Bounds/count response does not prove attachment, clearance or uniform transforms. '
                                     'A changed output fingerprint with failed metrics is not an unconnected/dead control: '
                                     'inspect local geometry and intended dependencies before rewiring. '
                                     'Fingerprint changes may include attributes, not only point motion. '
                                     'No inference about undeclared controls, relationships or the full parameter domain.'},
            'failures': failures[:8], 'failure_count': len(failures),
            **{k: result[k] for k in ('controller', 'output', 'frame', 'contract_sha256',
                                     'reason', 'case_id', 'baseline', 'expectation', 'parameter_writes',
                                     'measurement_failure') if k in result},
            'next_action': ('Only the declared cases and measurements passed; untested relationships remain unverified.'
                if result['ok'] else 'Locked baseline/case captures are incomplete; inspect their framing/backend evidence. Numeric case results and restoration are reported separately; visual semantics remain unverified.'
                if result.get('capture_status')=='unverified' else result.get('next_action',
                'Read the top-level failure before results; not_run cases are not passes. '
                'range applies to baseline AND perturbed values; delta is the signed change. '
                'Correct a mistaken expectation with independent evidence, then rerun affected cases.'))}


def test_controls(controller, output, tests, interfaces=None, allow_foreign=None, *, domain=None, topology=None,
                  baseline_interfaces=None, views=None, response_only=False, view_bounds=None):
    # Bind early failures and restoration exceptions to the same declaration as
    # successful retests. Never use call identity as the contract identity.

    declaration={'controller_identity':dsh_node_access._resolve(controller).sessionId(),
                 'tests':tests,'interfaces':interfaces,'baseline_interfaces':baseline_interfaces,
                 'domain':domain,'topology':topology}
    if views or view_bounds is not None:
        declaration.update(views=views,view_bounds=view_bounds)
    contract_hash=hashlib.sha256(json.dumps(declaration,sort_keys=True).encode()).hexdigest()
    try:
        result = _test_controls(controller, output, tests, interfaces, allow_foreign,
                                domain=domain, topology=topology, baseline_interfaces=baseline_interfaces,
                                views=views, response_only=response_only, view_bounds=view_bounds)
    except dsh_errors.CheckpointError as error:
        error.evidence['contract_sha256']=contract_hash
        if isinstance(error.evidence.get('control_summary'),dict):
            error.evidence['control_summary']['contract_sha256']=contract_hash
            error.evidence['next_action']=error.evidence['control_summary']['next_action']
        raise
    result['contract_sha256']=contract_hash
    result['control_summary'] = _control_summary(result, tests, interfaces, topology, baseline_interfaces)
    result['next_action'] = result['control_summary']['next_action']
    return result


def _test_controls(controller, output, tests, interfaces=None, allow_foreign=None, *, domain=None, topology=None,
                   baseline_interfaces=None, views=None, response_only=False, view_bounds=None):
    """Bounded numeric-control perturbation, declared measurement and restoration.

    Each test has id, numeric values dict and expectations [{metric,axis?,group?,
    delta:[min,max]}]. Global interfaces are checked at baseline and in every
    case; baseline_interfaces are checked only at baseline; each test may also
    declare interfaces checked only at its perturbed state.
    Operates only on numeric scalar controller parms, no menus/buttons/multiparms.
    Geometry bgeo fingerprints include primitive intrinsics, not just P. External
    files, Python/solver side effects and user callbacks are NOT transactional.
    """

    ctrl=dsh_node_access._resolve(controller)
    dsh_ownership.require_owned(ctrl,'test_controls',allow_foreign)
    from dsh_cook_control import require_evaluation
    require_evaluation('test_controls')
    if type(response_only) is not bool:raise ValueError('response_only must be boolean')
    views=[] if views is None else views
    validate_capture_views(views)
    if view_bounds is not None:
        if not views or not isinstance(view_bounds,(list,tuple)) or len(view_bounds)!=2:
            raise ValueError('view_bounds requires views and [world_min_xyz,world_max_xyz]')
        if any(not isinstance(side,(list,tuple)) or len(side)!=3 for side in view_bounds):
            raise ValueError('view_bounds requires two 3D corners')
        for i in range(3):
            if _finite(view_bounds[0][i],'view_bounds') >= _finite(view_bounds[1][i],'view_bounds'):
                raise ValueError('view_bounds must have positive extent on each world axis')
    if not isinstance(tests,list) or not 1 <= len(tests) <= 16:
        raise ValueError('tests must contain 1..16 bounded cases')
    if interfaces is not None:validate_interfaces(interfaces)
    if baseline_interfaces is not None:
        validate_interfaces(baseline_interfaces)
        if interfaces:validate_interfaces(interfaces+baseline_interfaces)
    if domain is not None:validate_domain(domain)
    if topology is not None:validate_topology(topology)
    ids=set();names=set()
    for test in tests:
        _exact_keys(test, {'id','values','expectations','interfaces'}, 'control test')
        if not isinstance(test.get('id'),str) or not test['id'] or test['id'] in ids:
            raise ValueError('test ids must be nonempty and unique')
        ids.add(test['id'])
        values=test.get('values')
        expectations=test.get('expectations',[]) if response_only else test.get('expectations')
        if not isinstance(values,dict) or not 1 <= len(values) <= 8:
            raise ValueError('each test needs 1..8 numeric scalar parameter values')
        if not isinstance(expectations,list) or not (0 if response_only else 1) <= len(expectations) <= 16:
            raise ValueError(
                'each test needs 1..16 declared measurement expectations; '
                'split a larger check into multiple test cases with the same control values'
            )
        for name,value in values.items():
            _finite(value,'control value')
            p=_control_parameter(ctrl,name)
            tpl=p.parmTemplate()
            if tpl.type()==hou.parmTemplateType.Int and type(value) is not int:
                raise ValueError(f'{name}: integer parameter needs integer value')
            if tpl.type()==hou.parmTemplateType.Toggle and (type(value) is not int or value not in (0,1)):
                raise ValueError(f'{name}: toggle needs integer 0 or 1')
            if float(p.eval())==float(value):
                raise ValueError(f'{name}: perturbation must differ from current value')
            names.add(name)
        for expectation in expectations:_validate_expectation(expectation)
        if 'interfaces' in test:
            validate_interfaces(test['interfaces'])
            if interfaces:
                validate_interfaces(interfaces + test['interfaces'])
        if expectations and not any(e['delta'][0] > 0 or e['delta'][1] < 0 for e in expectations):
            raise ValueError('each control case needs at least one non-zero expected response; add invariants as additional expectations')
    snapshots=dsh_parameter_values._parameter_snapshot([ctrl.parm(n) for n in sorted(names)])
    original_frame=float(hou.frame())
    baseline_domain=domain_checks(ctrl,domain or [])
    if any(r['status']=='fail' for r in baseline_domain):
        return {'ok':False,'status':'fail','controller':ctrl.path(),'output':dsh_node_access._resolve(output).path(),
                'results':[],'baseline_domain':baseline_domain,'restored':True,'parameter_writes':0,
                'reason':'baseline outside declared parameter domain','semantic_status':'unverified'}
    # Normalize evaluation before sampling the baseline: a plain first cook
    # compared against later force recooks mixes evaluation policy into the
    # restoration comparison domain and yields signature false positives.
    baseline_cook=dsh_node_operations.cook_node(dsh_node_access._resolve(output), force=True)
    baseline_state=dsh_parameter_values._parameter_restore_evidence(snapshots)
    if not baseline_state['ok'] or float(hou.frame())!=original_frame:
        raise dsh_errors.CheckpointError('test_controls baseline cook changed controller or frame before testing',
                                {'ok':False,'status':'fail','controller':ctrl.path(),
                                 'output':dsh_node_access._resolve(output).path(),'restored':False,
                                 'parameter_writes':0,'parameter_restore':baseline_state,
                                 'frame_restored':float(hou.frame())==original_frame,'results':[]})
    if not baseline_cook['ok']:
        return {'ok':False,'status':'fail','controller':ctrl.path(),'output':dsh_node_access._resolve(output).path(),
                'results':[],'restored':True,'parameter_writes':0,
                'reason':'baseline cook failed before any control write',
                'cook_errors':baseline_cook['errors'],'semantic_status':'unverified'}
    node, baseline=_geometry(output)
    from dsh_geometry_evidence import expanded_view
    try:
        measured_baseline,representation=expanded_view(baseline)
    except ValueError as error:
        return {'ok':False,'status':'unverified','controller':ctrl.path(),'output':node.path(),
                'frame':original_frame,'checked_at':time.time(),'restored':True,'results':[],
                'reason':str(error),'parameter_writes':0,'semantic_status':'unverified',
                'scope':'unsupported or over-budget evidence representation; zero parameter writes'}
    baseline_hash=_data_signature(baseline)
    baseline_contracts=(interfaces or [])+(baseline_interfaces or [])
    baseline_relations=_check_interfaces(measured_baseline,baseline_contracts,50000,node) if baseline_contracts else None
    baseline_topology=_check_topology(measured_baseline,topology) if topology is not None else None
    baseline_checks={'baseline_interfaces':baseline_relations,'baseline_topology':baseline_topology,
                     'baseline_domain':baseline_domain}
    if baseline_topology is not None and not baseline_topology['ok']:
        return {'ok':False,'status':baseline_topology['status'],'controller':ctrl.path(),'output':node.path(),
                'frame':original_frame,'checked_at':time.time(),'restored':True,**baseline_checks,
                'parameter_writes':0,'results':[],'semantic_status':'unverified',
                'next_action':'Fix the baseline selected surface topology before testing controls; zero parameter writes.'}
    if baseline_relations is not None and not baseline_relations['ok']:
        return {'ok':False,'status':baseline_relations['status'],'controller':ctrl.path(),'output':node.path(),
                'frame':original_frame,'checked_at':time.time(),'restored':True,**baseline_checks,
                'results':[],'parameter_writes':0,'semantic_status':'unverified',
                'next_action':'Fix the baseline interface before perturbing controls; zero parameter writes.'}
    # Resolve every measurement BEFORE the first write.
    try:
        baselines={test['id']:[_measure_case(measured_baseline,test,i,e)
                              for i,e in enumerate(test.get('expectations',[]))] for test in tests}
        if not all(math.isfinite(float(v)) for values in baselines.values() for v in values):
            raise UnsupportedEvidence('nonfinite baseline measurement; zero parameter writes')
        for test in tests:
            for exp,value in zip(test.get('expectations',[]),baselines[test['id']]):
                if 'range' in exp and not exp['range'][0]<=value<=exp['range'][1]:
                    return {'ok':False,'status':'fail','controller':ctrl.path(),'output':node.path(),
                            'frame':original_frame,'checked_at':time.time(),
                            'restored':True,'parameter_writes':0,'results':[],**baseline_checks,'case_id':test['id'],
                            'reason':'baseline outside declared absolute range','expectation':exp,'baseline':value,
                            'semantic_status':'unverified'}
    except UnsupportedEvidence as error:
        return {'ok':False,'status':'unverified','controller':ctrl.path(),'output':node.path(),
                'frame':original_frame,'checked_at':time.time(),'restored':True,'results':[],**baseline_checks,
                'parameter_writes':0, 'measurement_failure':error.diagnostic,
                'reason':str(error),'semantic_status':'unverified','scope':'unsupported metric; zero parameter writes'}
    baseline_captures=capture_views(node,views,view_bounds=view_bounds,frame=original_frame) if views else []
    capture_locks={c['view']:c['framing'] for c in baseline_captures
                   if c.get('ok') is True and not c.get('stale') and c.get('framing',{}).get('bounds')
                   and c['framing'].get('depth_bounds')}
    rows=[];all_restored=True;restoration=None
    for test in tests:
        row={'id':test['id'],'values':test['values'],'status':'fail'}
        # Independent unkeyed controls permit zero-write candidate preflight.
        # Expressions/animation may couple other domain variables: check their
        # actual values AFTER applying the case instead of predicting them.
        domain_names={c['left'] for c in domain or []} | {c['right'] for c in domain or [] if isinstance(c['right'],str)}
        domain_names.update(n for c in domain or [] if isinstance(c['right'],dict) for n in c['right']['terms'])
        if domain and not any(ctrl.parm(n).keyframes() for n in domain_names | set(test['values'])):
            proposed=domain_checks(ctrl,domain,test['values'])
            if any(r['status']=='fail' for r in proposed):
                rows.append({**row,'domain':proposed,'reason':'test value outside declared parameter domain',
                             'restored':True,'parameter_writes':0})
                continue
        try:
            dsh_parameter_values.set_parms(ctrl,test['values'],allow_foreign=allow_foreign)
            actual={name:ctrl.parm(name).eval() for name in test['values']}
            row['actual_values']=actual
            if any(not math.isclose(float(actual[name]),float(value),rel_tol=1e-9,abs_tol=1e-12)
                   for name,value in test['values'].items()):
                raise ValueError('requested test value did not apply exactly (possibly clamped); do not accept an unexercised case')
            if domain:
                row['domain']=domain_checks(ctrl,domain)
                if any(r['status']=='fail' for r in row['domain']):
                    raise ValueError('actual perturbed values outside declared parameter domain')
            cook=dsh_node_operations.cook_node(node,force=True)
            if not cook['ok']:raise ValueError(f'perturbed cook failed: {cook["errors"]}')
            _,g=_geometry(node)
            try: measured_geometry,_=expanded_view(g)
            except ValueError as error: raise UnsupportedEvidence(str(error)) from error
            measurements=[]
            for index,(exp,start) in enumerate(zip(test.get('expectations',[]),baselines[test['id']])):
                end=_measure_case(measured_geometry,test,index,exp,measured_baseline);delta=end-start;lo,hi=exp['delta']
                if not math.isfinite(float(end)):raise UnsupportedEvidence('nonfinite measured value')
                range_pass='range' not in exp or exp['range'][0]<=end<=exp['range'][1]
                measurements.append({'expectation':exp,'baseline':start,'measured':end,'delta':delta,'pass':lo<=delta<=hi and range_pass})
            case_interfaces=(interfaces or []) + test.get('interfaces',[])
            relations=_check_interfaces(measured_geometry,case_interfaces,50000,node) if case_interfaces else None
            topology_check=_check_topology(measured_geometry,topology) if topology is not None else None
            measurements_pass=all(m['pass'] for m in measurements)
            checks=[r for r in (relations,topology_check) if r is not None]
            case_status='fail' if not measurements_pass or any(r['status']=='fail' for r in checks) else 'unverified' if any(r['status']=='unverified' for r in checks) else 'pass'
            row.update({'status':case_status,'measurements':measurements,'interfaces':relations,'topology':topology_check,
                        'geometry_changed':_data_signature(g)!=baseline_hash,'warnings':cook['warnings']})
            if not measurements:
                row['response_status']='responsive' if row['geometry_changed'] else 'unchanged'
                if row['status']=='pass':row['status']='unverified'
            if views:row['captures']=capture_views(node,views,locks=capture_locks,frame=original_frame)
        except UnsupportedEvidence as error:
            row.update({'status':'unverified','reason':str(error),'measurement_failure':error.diagnostic})
        except dsh_errors.CheckpointError:
            # Restoring numeric controls cannot erase a broader user-state fault.
            raise
        except Exception as error:
            row.update({'status':'fail','reason':str(error)})
        finally:
            errors=dsh_parameter_values._restore_parameters(snapshots)
            if float(hou.frame())!=original_frame:
                try:hou.setFrame(original_frame)
                except Exception as error:errors.append('frame: '+str(error))
            try:
                cook=dsh_node_operations.cook_node(node,force=True)
                # geometry() can implicitly retry a failed/interrupted cook.
                # Missing restoration evidence must remain unknown, not trigger
                # another evaluation after the explicit attempt already failed.
                if not cook['ok']:
                    raise ValueError(f'restoration cook failed: {cook["errors"]}')
                _,restored=_geometry(node)
                restored_hash=_data_signature(restored)
                geometry_restore=_geometry_restore_diagnostic(baseline,restored,baseline_hash,restored_hash)
                geometry_restored=geometry_restore['matches']
                if not geometry_restored:errors.append('output bgeo differs from baseline; inspect geometry_restore')
            except Exception as error:
                errors.append('output restore: '+str(error));geometry_restored=False
                geometry_restore={'matches':False,'status':'not_verified','reason':str(error)}
            # Read AFTER recooking: expressions/solver/Python code can affect
            # channel state during evaluation even when the bgeo is unchanged.
            restoration=dsh_parameter_values._parameter_restore_evidence(snapshots)
            errors.extend(restoration['errors'])
            row['parameter_restore']=restoration
            row['geometry_restore']=geometry_restore
            if float(hou.frame())!=original_frame:
                errors.append('frame differs after output restoration cook')
            row['restored']=not errors and geometry_restored
            row['restore_errors']=errors
            if not row['restored']:
                all_restored=False
                failure={'ok':False,'status':'fail','controller':ctrl.path(),'output':node.path(),
                         'restored':False,'results':rows+[row],**baseline_checks}
                failure['control_summary']=_control_summary(failure,tests,interfaces,topology,baseline_interfaces)
                raise dsh_errors.CheckpointError('test_controls restoration failed; inspect controller/output before continuing',
                                        failure)
        rows.append(row)
    ok=all(r['status']=='pass' for r in rows) and (baseline_relations is None or baseline_relations['ok'])
    status='pass' if ok else 'fail' if any(r['status']=='fail' for r in rows) or (baseline_relations and baseline_relations['status']=='fail') else 'unverified'
    captures=baseline_captures+[c for row in rows for c in row.get('captures',[])]
    capture_status=('not_requested' if not views else 'observed' if
        len(captures)==len(views)*(len(tests)+1) and all(c.get('ok') is True and not c.get('stale') for c in captures)
        else 'unverified')
    if views and capture_status!='observed' and status=='pass':
        status='unverified';ok=False
    return {'ok':ok,'status':status,'controller':ctrl.path(),'output':node.path(),
            'frame':original_frame,'checked_at':time.time(),'restored':all_restored,'baseline_sha256':baseline_hash,
            'parameter_restore':restoration,
            'baseline_interfaces':baseline_relations,'baseline_topology':baseline_topology,'baseline_domain':baseline_domain,'results':rows,'semantic_status':'unverified',
            'baseline_captures':baseline_captures,'capture_status':capture_status,'representation':representation,
            'scope':'only declared control cases and explicit-output measurements; not all combinations or unspecified relationships'}
