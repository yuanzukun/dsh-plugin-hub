"""Independent desktop lifetime and authenticated local activation, without HOM."""
from __future__ import annotations

import argparse
import hmac
import hashlib
import json
import os
from pathlib import Path
import queue
import secrets
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import uuid
from concurrent.futures import Future
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from dsh_deployment import FileLease, LeaseBusyError, Store, _process_started, atomic_json, read_json, runtime_env


def desktop_environment(hfs, python, debug_port=None):
    hfs, python = Path(hfs), Path(python)
    env = dict(os.environ)
    for key in list(env):
        if key.upper().startswith(('QT_', 'QTWEBENGINE_', 'QML', 'PYSIDE', 'SHIBOKEN')):
            env.pop(key)
    for key in ('PYTHONHOME', 'PYTHONPATH', 'QT_PLUGIN_PATH', 'QT_QPA_PLATFORM_PLUGIN_PATH',
                'QTWEBENGINEPROCESS_PATH', 'QTWEBENGINE_RESOURCES_PATH', 'QTWEBENGINE_LOCALES_PATH'):
        env.pop(key, None)
    env.update(HFS=str(hfs), PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8',
               QT_QPA_PLATFORM='windows',
               PYTHONPATH=str(python.parent / 'lib/site-packages-forced'),
               PATH=str(hfs / 'bin') + os.pathsep + env.get('PATH', ''),
               QT_PLUGIN_PATH=str(hfs / 'qt/plugins'),
               QTWEBENGINEPROCESS_PATH=str(hfs / 'qt/bin/QtWebEngineProcess.exe'),
               QTWEBENGINE_RESOURCES_PATH=str(hfs / 'qt/resources'),
               QTWEBENGINE_LOCALES_PATH=str(hfs / 'qt/translations/qtwebengine_locales'))
    if debug_port is not None:
        if type(debug_port) is not int or not 1024 <= debug_port <= 65535:
            raise ValueError('Invalid explicit desktop debug port')
        env['QTWEBENGINE_REMOTE_DEBUGGING'] = '127.0.0.1:' + str(debug_port)
    return env


def control(record, action, payload=None, timeout=120):
    request = urllib.request.Request('http://127.0.0.1:' + str(record['controlPort']) + '/' + action,
        data=json.dumps(payload or {}).encode(), headers={'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + record['token']}, method='POST')
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(request, timeout=timeout) as response:
        value = json.load(response)
    if value.get('generation') != record['generation']:
        raise RuntimeError('工作台启动身份已变化，请重新打开工作区。')
    if not value.get('ok'):
        raise RuntimeError(value.get('error', '工作台没有完成此操作。'))
    return value['result']


def running(root):
    filename = Path(root) / 'workbench/desktop.json'
    try:
        record = read_json(filename, limit=32768)
    except FileNotFoundError:
        return None
    if (record.get('schema') != 1 or type(record.get('pid')) is not int
            or not isinstance(record.get('processStarted'), str)
            or not isinstance(record.get('token'), str) or len(record['token']) != 64
            or type(record.get('controlPort')) is not int or not 1024 <= record['controlPort'] <= 65535):
        raise RuntimeError('工作台登记损坏；未连接其他程序，也未结束任何进程。')
    if _process_started(record['pid']) != record['processStarted']:
        return None
    return record


def require_idle(activity):
    """One native DSH activity/durability result authorizes an ordinary close."""
    if not isinstance(activity, dict) or activity.get('durable') is not True:
        raise RuntimeError('最近对话尚未确认可靠保存，请稍后重试。')
    count = activity.get('activeConversations')
    if type(count) is not int or count < 0:
        raise RuntimeError('无法确认工作台任务状态，未关闭运行环境。')
    if count:
        raise RuntimeError('还有对话或后台任务正在运行，请等待完成后再重新加载。')
    return activity


def close_when_idle(config, record, progress=lambda message: None):
    """Worker-only close; wait for the exact old desktop to release its Host."""
    if record['installation'] != config['installation']:
        raise RuntimeError('工作台安装已变化，请从对应版本的入口重新打开。')
    progress('正在保存对话并关闭工作台…')
    control(record, 'close', timeout=15)
    deadline = time.monotonic() + 30
    while _process_started(record['pid']) == record['processStarted']:
        if time.monotonic() >= deadline:
            raise RuntimeError('工作台尚未退出，请正常关闭后重新打开；没有强制结束进程。')
        time.sleep(.1)


def reject_legacy_frontend(marker, *, home, cli_roots, port, listener_pid):
    """Worker-only: a diagnostic PID is a hint, never a live Host identity.

    Old records lack the data home and native creation time. They can only
    establish a still-running legacy entry from this installation, after its
    exact DSH command and actual listener have both been identified.
    """
    marker = Path(marker)
    try:
        record = read_json(marker)
    except (OSError, ValueError):
        return  # Missing/damaged diagnostic history cannot identify a live Host.
    if not isinstance(record, dict):
        return
    pid = record.get('pid')
    if type(pid) is not int or pid <= 0:
        return
    started = _process_started(pid)
    if started is None or (record.get('processStarted') is not None and record['processStarted'] != started):
        return
    if (isinstance(record.get('home'), str)
            and os.path.normcase(os.path.realpath(record['home'])) != os.path.normcase(os.path.realpath(home))):
        return
    legacy_port = record.get('frontendPort', port)
    if type(legacy_port) is not int or not 1024 <= legacy_port <= 65535 or listener_pid(legacy_port) != pid:
        return
    from dsh_managed_runtime import inspect_frontend
    try:
        inspect_frontend(pid, cli_roots=cli_roots, port=legacy_port)
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError):
        return  # Another program or an unconfirmed identity is not an old Host.
    if _process_started(pid) == started and listener_pid(legacy_port) == pid:
        raise RuntimeError('此安装的旧版内嵌工作区后台仍在运行。请先保存任务并正常退出原 Houdini，再打开独立工作台；没有启动第二个后台或结束原进程。')


def ensure(config, progress=lambda message: None):
    progress('正在打开 DSH-Houdini 工作台…')
    root = Path(config['root'])
    root.mkdir(parents=True, exist_ok=True)
    lock_deadline = time.monotonic() + 150
    while True:
        try:
            lease = FileLease(root / 'workbench/start.lock')
            break
        except LeaseBusyError:
            if time.monotonic() >= lock_deadline:
                raise RuntimeError('工作台仍在启动，请稍后重试；没有重复启动后台。')
            time.sleep(.1)
    try:
        record = running(root)
        if record:
            if record['installation'] != config['installation']:
                raise RuntimeError('工作台正在使用另一个插件版本。请先结束工作台中的任务并退出工作台，再打开新版；Houdini 不会被关闭。')
            if config.get('managed') and config['houdiniVersion'] not in Store(root, config['trustData']).manifest(config['installation'])['houdini']:
                raise RuntimeError('当前工作台版本不支持这个 Houdini 版本，未加载不兼容的执行端。')
            return control(record, 'status', timeout=5)
        attempt = uuid.uuid4().hex
        atomic_json(root / 'workbench/launch-config.json', config)
        request = root / 'workbench' / ('launch-' + attempt + '.json')
        atomic_json(request, config)
        python = Path(config['python'])
        env = desktop_environment(config['hfs'], python, config.get('debugPort'))
        with (root / 'workbench/desktop.log').open('ab') as output:
            output.write(('\nDesktop Python: ' + str(python) + '\nHoudini runtime: ' + config['hfs'] + '\n').encode('utf-8'))
            output.flush()
            process = subprocess.Popen([str(python), '-X', 'faulthandler', str(Path(__file__).resolve()), '--config', str(request)],
                cwd=Path(config['hfs']) / 'bin', env=env, stdin=subprocess.DEVNULL,
                stdout=output, stderr=subprocess.STDOUT, close_fds=True,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        try:
            # The child owns preparation and its phase timeouts. Keep observing
            # its real ready/exit state instead of reporting a second timeout
            # while it is still starting in the visible progress window.
            while True:
                record = running(root)
                if record and record['pid'] == process.pid:
                    return control(record, 'status', timeout=5)
                if process.poll() is not None:
                    failure = root / 'workbench' / ('failed-' + attempt + '.json')
                    error = read_json(failure)['error'] if failure.exists() else '启动程序退出，代码 ' + str(process.returncode) + '。请通过报告问题查看启动记录。'
                    raise RuntimeError('独立工作台未启动：' + error)
                time.sleep(.1)
        finally:
            request.unlink(missing_ok=True)
    finally:
        lease.close()


def browser_origin(root, installation, home):
    """Keep DSH's native browser stores on one origin within one data identity.

    Called on the startup worker with the installation lease already held.
    The stored port is a browser preference, never evidence of process ownership.
    """
    identity = json.dumps([str(installation), str(Path(home).resolve())], ensure_ascii=False).encode('utf-8')
    storage = Path(root) / 'workbench' / 'browser' / hashlib.sha256(identity).hexdigest()[:24]
    filename = storage / 'origin.json'
    port = read_json(filename).get('port') if filename.exists() else 0
    if type(port) is not int or port != 0 and not 1024 <= port <= 65535:
        raise RuntimeError('工作台浏览器地址配置损坏，请通过报告问题提供诊断。')
    with socket.socket() as probe:
        try:
            probe.bind(('127.0.0.1', port))
        except OSError as error:
            raise RuntimeError(f'工作台地址 127.0.0.1:{port} 被其他程序占用。请关闭占用程序后重试；没有接管或终止它，输入草稿仍保留。') from error
        port = probe.getsockname()[1]
    atomic_json(filename, {'port': port})
    return port, str(storage)


def prepare(config, progress=lambda message: None):
    root = Path(config['root'])
    runtime = root / 'workbench' / uuid.uuid4().hex
    runtime.mkdir(parents=True)
    context_file = runtime / 'context.json'

    def prepare_managed(context, progress):
        progress('正在准备对话配置…')
        port, storage = browser_origin(root, config['installation'], context['home'])
        context.update(frontendPort=port, browserStorage=storage, runtimeDir=str(runtime), workbench=True,
                       executorRegistry=str(root / 'workbench/executors'))
        atomic_json(context_file, context)
        install = Path(context['install'])
        result = subprocess.run([str(install / 'node/node.exe'), str(install / 'app/prepare-profile.mjs'), str(context_file)],
            cwd=install / 'app', env=runtime_env(context), capture_output=True, text=True,
            encoding='utf-8', errors='replace', timeout=120, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if result.returncode:
            raise RuntimeError('工作台配置准备失败：' + result.stderr[-3000:])

    if config.get('managed'):
        progress('正在读取工作台配置…')
        store = Store(root, config['trustData'])
        context, lease = store.activate(config['installation'], config['houdiniVersion'], progress=progress, prepare=prepare_managed,
                                        owner={'application': 'DSH-Houdini Workbench'})
        plugin = Path(context['install']) / 'app/node_modules/dsh-houdini'
        node = Path(context['install']) / 'node/node.exe'
        binary = Path(context['install']) / 'app/node_modules/@deepseek-ai/dsh/lib/bin.js'
        env = runtime_env(context)
        env['DSH_HOUDINI_MANAGED_CONTEXT'] = str(context_file)
        os.environ['DSH_HOUDINI_MANAGED_CONTEXT'] = str(context_file)
    else:
        lease = FileLease(root / 'runtime.lock')
        try:
            plugin, node, binary = Path(config['plugin']), Path(config['node']), Path(config['binary'])
            port, storage = browser_origin(root, config['installation'], config['home'])
            context = {'root': str(root), 'home': config['home'], 'frontendPort': port,
                       'browserStorage': storage,
                       'runtimeDir': str(runtime), 'workbench': True,
                       'executorRegistry': str(root / 'workbench/executors')}
            env = dict(os.environ, DSH_HOME=config['home'])
            env.pop('DSH_HOUDINI_MANAGED_CONTEXT', None)
            sys.path.insert(0, str(plugin / 'houdini/python3.11libs'))
            from dsh_profile_sync import sync_profile_plugins
            progress('正在检查对话配置…')
            sync_profile_plugins([str(node), str(binary)], use_shell=False, project_root=plugin, env=env)
        except BaseException:
            lease.close()
            raise
    env.update(DSH_HOUDINI_EXECUTOR_REGISTRY=context['executorRegistry'], DSH_HOUDINI_WORKBENCH='1')
    context['contextFile'] = str(context_file)
    try:
        atomic_json(context_file, context)
    except BaseException:
        lease.close()
        raise
    env['DSH_HOUDINI_WORKBENCH_CONTEXT'] = str(context_file)
    env.pop('DSH_HOUDINI_EXECUTOR_ID', None)
    env.pop('DSH_HOUDINI_BRIDGE_URL', None)
    return context, lease, plugin, node, binary, env


def _start_runtime(config, progress):
    """Disk, process and HTTP preparation only; run on the startup worker."""
    context, lease, plugin, node, binary, env = prepare(config, progress)
    sys.path.insert(0, str(plugin / 'houdini/python3.11libs'))
    from dsh_managed_runtime import spawn_frontend, stop_owned
    from dsh_web_auth import DshWebSession
    runtime = Path(context['runtimeDir'])
    base = 'http://127.0.0.1:' + str(context['frontendPort'])
    auth = DshWebSession(base, str(runtime / 'frontend.log'), str(runtime / 'runtime.json'))

    def rpc(method, payload, argument='input', timeout=90):
        request = urllib.request.Request(base + '/api/' + method, data=json.dumps({
            'type': 'client-request', 'rpcId': uuid.uuid4().hex, 'method': method,
            'payload': {'args': {} if method == 'houdiniTargets/activity' else {argument: payload}}}).encode(), headers={'Content-Type': 'application/json'})
        with auth.open(request, timeout=timeout) as response:
            value = json.load(response)['result']
        if not value['ok']:
            raise RuntimeError(value['error']['message'])
        return value['value']

    host = None
    try:
        progress('正在启动对话服务…')
        with (runtime / 'frontend.log').open('wb') as output:
            host = spawn_frontend([str(node), str(binary), 'web', '--patch', str(plugin / 'shared-host.cordis.yml'),
                '--port', str(context['frontendPort']), '--no-open'], node=str(node), cwd=plugin,
                env=env, stdout=output, stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        atomic_json(runtime / 'runtime.json', {'pid': host.pid, 'source': 'workbench', 'authLogOffset': 0,
            'version': read_json(binary.parent.parent / 'package.json')['version'],
            'pluginVersion': read_json(plugin / 'package.json')['version'],
            'startedAt': time.strftime('%Y-%m-%dT%H:%M:%S%z')})
        deadline = time.monotonic() + 90
        while True:
            if host.poll() is not None:
                raise RuntimeError('DSH 后台在启动时退出，请查看诊断记录。')
            try:
                auth.authorize(2)
                break
            except Exception as error:
                if time.monotonic() >= deadline:
                    raise RuntimeError('对话服务未在等待时间内就绪：' + str(error)) from error
                time.sleep(.2)
        progress('正在打开工作区…')
        if config.get('initialWorkspace'):
            rpc('houdiniTargets/prepareWorkspace', {'path': config['initialWorkspace'], 'isNew': config.get('initialWorkspaceIsNew') is True})
        else:
            workspace = Path(context['root']) / 'workspaces/工作台'
            workspace.mkdir(parents=True, exist_ok=True)
            rpc('houdiniTargets/prepareWorkspace', {'path': str(workspace), 'isNew': False, 'onlyIfEmpty': True})
        return context, lease, plugin, host, base, auth, rpc
    except BaseException:
        if host is not None:
            stop_owned(host)
        lease.close()
        raise


def _startup_message(message):
    for prefix, label in (
        ('Checking files · ', '正在检查安装文件 · '),
        ('Checking the bundled Node, DSH and plugin', '正在检查配套运行环境…'),
        ('Copying a version-isolated snapshot of your DSH data', '正在为新版本保留对话和设置…'),
    ):
        if message.startswith(prefix):
            return label + message[len(prefix):]
    return message


def _prepare_with_feedback(config):
    """Display before hashing/profile/Host startup; the Qt thread only paints."""
    started = time.monotonic()
    if os.name == 'nt':
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('DSH.Houdini.Workbench')
        dll_directory = os.add_dll_directory(str(Path(config['hfs']) / 'bin'))
    from PySide6.QtCore import QCoreApplication, QEventLoop, QTimer, Qt
    from PySide6.QtGui import QIcon
    from PySide6.QtWidgets import QApplication, QDialog, QLabel, QProgressBar, QPushButton, QVBoxLayout
    from dsh_ui_style import style_dialog
    if QApplication.instance() is None:
        QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    app = QApplication.instance() or QApplication([])
    if os.name == 'nt':
        app._dsh_dll_directory = dll_directory
    app.setApplicationName('DSH-Houdini')
    app.setQuitOnLastWindowClosed(False)
    dialog = QDialog()
    style_dialog(dialog)
    dialog.setWindowTitle('DSH-Houdini · 正在打开工作台')
    dialog.setMinimumWidth(420)
    icon = QIcon(str(Path(__file__).resolve().parents[2] / 'assets/dsh-houdini.ico'))
    dialog.setWindowIcon(icon)
    app.setWindowIcon(icon)
    layout = QVBoxLayout(dialog)
    layout.setContentsMargins(24, 22, 24, 20)
    layout.setSpacing(14)
    phase = QLabel('正在准备工作台…')
    phase.setWordWrap(True)
    elapsed = QLabel('已等待 0 秒')
    note = QLabel('关闭此窗口会继续在后台打开工作台。')
    note.setObjectName('caption')
    bar = QProgressBar()
    bar.setRange(0, 0)
    background = QPushButton('后台打开')
    background.clicked.connect(dialog.hide)
    for widget in (phase, elapsed, bar, note, background):
        layout.addWidget(widget)
    events = queue.Queue()
    result = {}

    def progress(message):
        message = _startup_message(message)
        value = {'message': message, 'elapsedSeconds': round(time.monotonic() - started, 3)}
        events.put(value)
        print('[dsh-houdini/startup] ' + json.dumps(value, ensure_ascii=False), flush=True)

    def worker():
        try:
            result['value'] = _start_runtime(config, progress)
            progress('正在加载工作台页面…')
        except BaseException as error:
            result['error'] = error
        finally:
            events.put(None)

    loop = QEventLoop()
    def tick():
        while not events.empty():
            value = events.get_nowait()
            if value is None:
                loop.quit()
                return
            phase.setText(value['message'])
        elapsed.setText('已等待 ' + str(int(time.monotonic() - started)) + ' 秒')
    timer = QTimer(dialog)
    timer.timeout.connect(tick)
    timer.start(100)
    dialog.show()
    # Queue the worker after creating the native window; Qt keeps painting.
    QTimer.singleShot(0, lambda: threading.Thread(target=worker, daemon=True).start())
    loop.exec()
    timer.stop()
    if 'error' in result:
        dialog.close()
        raise result['error']
    return app, dialog, result['value']


def run(config):
    app, startup, ready = _prepare_with_feedback(config)
    context, lease, plugin, host, base, auth, rpc = ready
    from dsh_managed_runtime import stop_owned
    try:
        _run_window(config, app, startup, ready)
    finally:
        startup.close()
        stop_owned(host)
        lease.close()


def open_browser(context, base, auth):
    """Carry desktop state through the existing context, including on rollback."""
    os.environ['DSH_HOUDINI_WORKBENCH_CONTEXT'] = context['contextFile']
    import dsh_webview
    dsh_webview.show_webview(authenticated_url=auth.launch_url(), frontend_url=base, standalone=True)
    return dsh_webview


def _run_window(config, app, startup, ready):
    context, lease, plugin, host, base, auth, rpc = ready
    intents = queue.Queue()
    generation, token = uuid.uuid4().hex, secrets.token_hex(32)
    from dsh_workbench_projects import ProjectManager, show_project_dialog, dialog_request
    projects = ProjectManager(config, context, plugin, generation, rpc, intents)
    dialogs = queue.Queue()
    window_requests = queue.Queue()
    from dsh_release_policy import ReleaseCheck, update_notice
    release_check = ReleaseCheck()
    manager_requests = queue.Queue()
    close_requests = queue.Queue()
    close_results = queue.Queue()

    def update_status():
        versions = [context['version']] if config.get('managed') else [read_json(plugin / 'package.json')['version']]
        if config.get('managed'):
            selected = Store(config['root'], config['trustData']).state()
            versions.extend(ident.split('-')[0] for ident in (selected['current'], selected['pending']) if ident)
        return update_notice(release_check.snapshot(), versions)

    class Control(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            status, result = 200, {'ok': False, 'generation': generation}
            try:
                if not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + token):
                    status = 403
                    raise RuntimeError('工作台请求未认证。')
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 <= length <= 16384:
                    raise ValueError('工作台请求过大。')
                payload = json.loads(self.rfile.read(length) or b'{}')
                if self.path == '/status' and payload == {}:
                    value = {'record': record, 'context': context, 'plugin': str(plugin),
                             'runtime': read_json(Path(context['runtimeDir']) / 'runtime.json')}
                elif self.path == '/activity' and payload == {}:
                    value = rpc('houdiniTargets/activity', {}, timeout=5)
                elif self.path == '/close' and payload == {}:
                    require_idle(rpc('houdiniTargets/activity', {}, timeout=5))
                    reply = Future()
                    expired = threading.Event()
                    close_requests.put((reply, expired))
                    try:
                        value = reply.result(timeout=8)
                    finally:
                        expired.set()
                        reply.cancel()
                elif self.path == '/open':
                    value = rpc('houdiniTargets/openWorkspace', payload)
                    intents.put(value)
                elif self.path == '/show' and isinstance(payload, dict) and (payload == {} or
                        set(payload) == {'sessionId'} and isinstance(payload['sessionId'], str) and 0 < len(payload['sessionId']) <= 256):
                    value = payload
                    intents.put(value)
                elif self.path == '/projects/presence' and payload == {}:
                    value = projects.presence()
                elif self.path == '/updates/status' and payload == {}:
                    value = update_status()
                elif self.path == '/updates/open' and payload == {}:
                    reply = Future()
                    manager_requests.put(reply)
                    try:
                        value = reply.result(timeout=4)
                    finally:
                        reply.cancel()
                elif self.path == '/window/pin':
                    if (not isinstance(payload, dict) or set(payload) - {'pinned'}
                            or ('pinned' in payload and type(payload['pinned']) is not bool)):
                        raise ValueError('无效的窗口置顶请求。')
                    reply = Future()
                    window_requests.put((payload, reply))
                    try:
                        value = reply.result(timeout=4)
                    finally:
                        reply.cancel()  # A timed-out queued command must not run later.
                elif self.path == '/projects/dialog':
                    dialogs.put(dialog_request(payload))
                    value = {'accepted': True}
                elif self.path == '/projects/attached':
                    value = projects.attached(payload)
                elif self.path == '/projects/failed':
                    value = projects.failed(payload)
                else:
                    raise ValueError('未知的工作台操作。')
                result.update(ok=True, result=value)
            except Exception as error:
                # Product errors carry the user-facing message; anything else
                # surfaces its type and detail instead of an opaque fallback.
                detail = str(error).strip()
                result['error'] = detail if isinstance(error, (ValueError, RuntimeError)) else (
                    type(error).__name__ + ': ' + (detail or '未知错误'))
            data = json.dumps(result).encode()
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    server = ThreadingHTTPServer(('127.0.0.1', 0), Control)
    record = {'schema': 1, 'pid': os.getpid(), 'processStarted': _process_started(os.getpid()),
              'controlPort': server.server_port, 'generation': generation, 'token': token,
              'installation': config['installation']}
    serving = False
    try:
        from PySide6.QtCore import QTimer, QObject, QEvent
        from PySide6.QtWidgets import QMessageBox
        from PySide6.QtGui import QIcon
        icon = QIcon(str(plugin / 'assets/dsh-houdini.ico'))
        app.setWindowIcon(icon)
        dsh_webview = open_browser(context, base, auth)
        dsh_webview._window.setWindowIcon(icon)
        startup.close()
        app.setQuitOnLastWindowClosed(True)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        serving = True
        atomic_json(Path(config['root']) / 'workbench/desktop.json', record)
        closing = queue.Queue()
        # Discovery never participates in startup/connection readiness. The
        # same in-memory result is consumed by the header and version manager.
        release_check.start()
        update_timer = QTimer(dsh_webview._window)
        update_timer.timeout.connect(release_check.start)
        update_timer.start(6 * 60 * 60 * 1000)

        class CloseGuard(QObject):
            allowed = False
            checking = False

            def eventFilter(self, watched, event):
                if event.type() != QEvent.Close or self.allowed:
                    return False
                event.ignore()
                if not self.checking:
                    self.checking = True
                    def check():
                        try:
                            closing.put(rpc('houdiniTargets/activity', {}, timeout=3))
                        except Exception as error:
                            closing.put({'error': str(error)})
                    threading.Thread(target=check, daemon=True).start()
                return True

        guard = CloseGuard(dsh_webview._window)
        dsh_webview._window.installEventFilter(guard)
        project_dialog = {'value': None}

        def drain():
            while not close_requests.empty():
                reply, expired = close_requests.get_nowait()
                if reply.set_running_or_notify_cancel():
                    if guard.checking:
                        reply.set_exception(RuntimeError('工作台正在核对退出状态，请稍后重试。'))
                        continue
                    guard.checking = True
                    dsh_webview._window.setEnabled(False)
                    def check_close(reply=reply, expired=expired):
                        error = None
                        try:
                            require_idle(rpc('houdiniTargets/activity', {}, timeout=5))
                        except Exception as failure:
                            error = failure
                        close_results.put((reply, expired, error))
                    threading.Thread(target=check_close, daemon=True).start()
            while not close_results.empty():
                reply, expired, error = close_results.get_nowait()
                guard.checking = False
                if expired.is_set() or error is not None:
                    dsh_webview._window.setEnabled(True)
                    if not expired.is_set():
                        reply.set_exception(error)
                else:
                    guard.allowed = True
                    reply.set_result({'closing': True})
                    QTimer.singleShot(0, dsh_webview._window.close)
                    return
            while not manager_requests.empty():
                reply = manager_requests.get_nowait()
                if not reply.set_running_or_notify_cancel():
                    continue
                try:
                    import dsh_install_ui
                    if config.get('managed'):
                        dsh_install_ui.show(Store(config['root'], config['trustData']),
                            pinned=config['installation'], loaded=context, parent=dsh_webview._window,
                            release_check=release_check, workbench=True)
                    else:
                        dsh_install_ui.show(source_root=plugin, parent=dsh_webview._window,
                            release_check=release_check, workbench=True)
                    reply.set_result({'opened': True})
                except Exception as error:
                    reply.set_exception(error)
            while not window_requests.empty():
                request, reply = window_requests.get_nowait()
                if reply.set_running_or_notify_cancel():
                    try:
                        reply.set_result(dsh_webview.window_pin(request.get('pinned')))
                    except Exception as error:
                        reply.set_exception(error)
            while not dialogs.empty():
                request = dialogs.get_nowait()
                if project_dialog['value'] is not None:
                    project_dialog['value'].raise_()
                    project_dialog['value'].activateWindow()
                    continue
                dialog = show_project_dialog(projects, dsh_webview._window, request['action'], request.get('hip'), request.get('sessionId'), request.get('executorId'), request.get('bindSessionId'))
                project_dialog['value'] = dialog
                dialog.finished.connect(lambda *_: project_dialog.update(value=None))
            if not closing.empty():
                activity = closing.get_nowait()
                guard.checking = False
                try:
                    require_idle(activity)
                    accepted = True
                except RuntimeError:
                    accepted = False
                if not accepted:
                    dialog = QMessageBox(dsh_webview._window)
                    from dsh_ui_style import style_dialog
                    style_dialog(dialog)
                    dialog.setWindowTitle('退出 DSH-Houdini')
                    dialog.setText(('还有对话或后台任务尚未结束。' if activity and activity.get('activeConversations') else '暂时无法确认后台及对话保存状态。')
                                   + '退出将停止工作台后台，但不会关闭 Houdini；已经开始的工程操作不会因此撤销。')
                    if activity and activity.get('error'):
                        dialog.setDetailedText(activity['error'])
                    leave = dialog.addButton('退出工作台', QMessageBox.AcceptRole)
                    cancel = dialog.addButton('继续保留', QMessageBox.RejectRole)
                    dialog.setDefaultButton(cancel)
                    dialog.exec()
                    accepted = dialog.clickedButton() is leave
                if accepted:
                    guard.allowed = True
                    dsh_webview._window.close()
                    return
            latest = None
            while not intents.empty():
                latest = intents.get_nowait()
            if latest is not None:
                session_id = latest.get('sessionId')
                if session_id:
                    target = dsh_webview._navigation_url(None, session_id, base)
                    dsh_webview._issue_launch_intent(target)
                dsh_webview._window.showNormal()
                dsh_webview._window.raise_()
                dsh_webview._window.activateWindow()

        timer = QTimer()
        timer.timeout.connect(drain)
        timer.start(100)
        app.exec()
        dsh_webview._dispose_webview()
    finally:
        if serving:
            server.shutdown()
        server.server_close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    config = read_json(args.config)
    try:
        run(config)
    except Exception as error:
        atomic_json(args.config.with_name(args.config.name.replace('launch-', 'failed-')), {'error': str(error)})
        raise


if __name__ == '__main__':
    main()
