"""dsh-houdini: 按 Houdini 数据流与真实 Tab 语义操作/检查场景。

解决两个问题：

1. **通用初始化** —— 部分单节点（如 ``copytopoints::2.0``）通过 Tab Menu 创建时，
   shelf tool 脚本会做额外初始化（按初始化按钮、建配套节点、设参数等）。裸
   ``hou.Node.createNode`` 不会做这些。本模块用 ``toolutils.testTool`` 跑真实的
   shelf tool，完整保留初始化语义，且对未来 SideFX 改动脚本自动跟随——不为任何
   节点写死「按哪个按钮」。

2. **真实菜单与 setup tool** —— node type 注册表不是用户菜单。parent-aware
   ``search_tab_entries`` 排除 hidden/deprecated 和 builder mask 外类型；多节点
   Karma Setup/Material Builder 走受限 ``tab_apply``，不压进单节点返回契约。

3. **永远最新版本** —— ``hou.preferredNodeType`` 实测不可靠（返回 None），这里枚举
   ``nodeTypes()`` 取 ``::N`` 最大的版本，创建和自省共用同一解析。

只依赖 ``hou`` / ``toolutils`` / 标准库，不导入项目 venv 任何包（进程边界）。
本模块被 ``dsh_bridge`` 预置进 exec namespace，agent 写 Python 时可直接：

    geo = tab_create(hou.node('/obj'), 'geo', name='my_geo')
    cop = tab_create(geo, 'copytopoints', inputs=[box, points])
    search_tab_menu('sop', 'cone')     # 查不猜：列出匹配类型 + 最新版
    search_tab_entries('/stage', 'karma')
    tab_apply('/stage', 'lop_karma_setup')

注意：``tab_create`` 返回 ``hou.Node``（供 agent 继续链式操作）；要回传结构化数据，
请手动转 JSON（``__result__ = {'path': node.path()}``），不要直接把 hou 对象塞进
``__result__``。
"""

from __future__ import annotations

import contextlib
import difflib
import fnmatch
import functools
import hashlib
import math
import os
import re
import struct
import time
import zlib
from typing import Any

import hou
import dsh_cook_control as _cook_control
from dsh_project_paths import directory_path as _project_directory
import toolutils


def _with_render_slot(fn):
    """Serialize render_frame/render_view across shared-host executors (fail-fast)."""
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        import dsh_executor_registry
        slot = dsh_executor_registry.render_slot()
        try:
            return fn(*args, **kwargs)
        finally:
            dsh_executor_registry.release_render_slot(slot)
    return wrapper


def _preserve_render_service_on_undo(fn):
    """Keep preview service edits out of a caller's deliverable undo group.

    A later Python error in the same exec rolls back authored nodes. If the
    first preview created an OpenGL ROP inside that group, native undo could
    delete the persistent renderer after it had rendered. Preview state is
    restored by render_view itself and its image is an external file effect.
    """
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        with hou.undos.disabler():
            return fn(*args, **kwargs)
    return wrapper


class CheckpointError(RuntimeError):
    """A failed operation retains machine-readable evidence in the Bridge ledger."""
    def __init__(self, message, evidence):
        super().__init__(message)
        self.evidence = evidence


class PreflightError(ValueError):
    """Independent static errors collected before module creation starts."""
    def __init__(self, errors):
        self.evidence = {'ok': False, 'phase': 'static_preflight', 'scene_writes': 0,
                         'errors': errors[:32], 'error_count': len(errors),
                         'errors_truncated': len(errors) > 32,
                         'next_action': 'Fix the listed fields together; no nodes were created by this module.'}
        super().__init__('module static preflight failed (zero scene writes): ' +
                         '; '.join(f"{e['node']}: {e['message']}" for e in errors[:32]))


class ParameterPatchError(ValueError):
    """Literal patch validation failed before any parameter in the batch changed."""
    def __init__(self, message, parameter):
        super().__init__(message)
        self.evidence = {'ok': False, 'phase': 'parameter_patch_preflight', 'scene_writes': 0,
                         'parameter': parameter, 'next_action': 'Read the current raw string and source_sha256 with read_parms; fix all patch anchors before retrying.'}


# ``render_view`` infrastructure is session-scoped service state, not a
# per-task probe. Deleting an OpenGL ROP (or a node it references) after a
# successful render can make H21 enter its process-fatal GL capability path.
# Keep these constants near the generic node verbs so ``delete_node`` can
# enforce the ownership boundary before it asks Houdini for references.
_RENDER_OWNER_KEY = "dsh_houdini_owner"
_RENDER_OWNER_VALUE = "render_view_v2"
_RENDER_OBJ_BOX_NAME = "__dsh_houdini_render_service"
_RENDER_OUT_BOX_NAME = "__dsh_houdini_render_service"
# A semicolon in a native Network Box comment breaks its saved metadata load
# on H21/H22, resetting the title and fixed bounds to their defaults.
_RENDER_BOX_COMMENT = "DSH-Houdini Render Service (persistent)"

# Ordinary task nodes use runtime provenance, not their parent/path/name, as the
# authority boundary.  A user can create or duplicate a node inside an
# agent-created network at any time; that must not make the node agent-owned.
# ``userData`` is durable audit metadata, while the process-local sessionId
# registry is authoritative for automatic mutation/cleanup.  A copied node may
# copy userData, but receives a new Houdini sessionId and therefore remains
# foreign until the user explicitly authorizes an edit.
_TASK_OWNER_KEY = "dsh_houdini_task_owner"
_TASK_OWNER_CALL_KEY = "dsh_houdini_created_by_call"
_ACTIVE_OWNER_SESSION: str | None = None
_ACTIVE_OWNER_CALL: str | None = None
if globals().get('_OWNED_NODE_PID') != os.getpid():
    _OWNED_NODE_PID = os.getpid()
    _OWNED_NODE_SESSIONS: dict[int, dict] = {}
_CREATION_JOURNAL = None


@contextlib.contextmanager
def _track_created_nodes():
    """Retain exact created identities across nested module/provenance cleanup."""
    global _CREATION_JOURNAL
    previous = _CREATION_JOURNAL
    created = set()
    _CREATION_JOURNAL = created
    try:
        yield created
    finally:
        _CREATION_JOURNAL = previous


def _cleanup_failed_creations(created, ownership_before):
    removed = []
    # Never infer ownership from paths or an agent-created parent. A partial
    # shelf/undo recovery can resurrect a registered identity after its registry
    # entry was removed; only identities recorded in this call are eligible.
    with hou.undos.disabler():
        for node_id in sorted(created - set(ownership_before), reverse=True):
            node = hou.nodeBySessionId(node_id)
            if node is None:continue
            descendants = node.allSubChildren()
            if any(n.sessionId() not in created for n in descendants):
                raise RuntimeError(f'rollback cleanup refused foreign descendants of {node.path()}')
            removed.append(node.path())
            node.destroy()
            _OWNED_NODE_SESSIONS.pop(node_id, None)
    return removed


def _reconcile_undo_resurrected(owned_at_start, *, exclude_ids=()):
    """Restore fresh native identities after this batch's own Undo.

    Candidates are owned identities alive at batch start, resolved at their
    batch-start path and type only after the original identity disappeared.
    exclude_ids contains every identity alive just before Undo, so an existing
    foreign replacement cannot be adopted. Undo can itself replace children
    that were still alive before rollback (not just resurrect deleted nodes).
    A registered live ancestor and an unconsumed record are also required.
    """
    restored = []
    for old_id, (entry, batch_start_path) in owned_at_start.items():
        if hou.nodeBySessionId(old_id) is not None:
            continue
        candidate = hou.node(batch_start_path) if isinstance(batch_start_path, str) else None
        if candidate is None or int(candidate.sessionId()) in _OWNED_NODE_SESSIONS or int(candidate.sessionId()) in exclude_ids:
            continue
        if entry.get('type') is not None and candidate.type().name() != entry['type']:
            continue
        ancestor = candidate.parent()
        while ancestor is not None and int(ancestor.sessionId()) not in _OWNED_NODE_SESSIONS:
            ancestor = ancestor.parent()
        if ancestor is None:
            continue
        _OWNED_NODE_SESSIONS[int(candidate.sessionId())] = dict(entry)
        # Consume the dead entry: ids are never reused, so after adoption the
        # old record must not linger as a stale candidate for later batches.
        _OWNED_NODE_SESSIONS.pop(int(old_id), None)
        if _CREATION_JOURNAL is not None:
            _CREATION_JOURNAL.add(int(candidate.sessionId()))
        candidate.setUserData(_TASK_OWNER_KEY, entry.get('session'))
        if entry.get('call'):
            candidate.setUserData(_TASK_OWNER_CALL_KEY, entry['call'])
        restored.append(candidate.path())
    return restored


def _set_execution_owner(session_id: str | None, call_id: str | None):
    """Install trusted host provenance for one serialized bridge execution."""
    global _ACTIVE_OWNER_SESSION, _ACTIVE_OWNER_CALL
    previous = (_ACTIVE_OWNER_SESSION, _ACTIVE_OWNER_CALL)
    _ACTIVE_OWNER_SESSION = str(session_id) if session_id else None
    _ACTIVE_OWNER_CALL = str(call_id) if call_id else None
    return previous


def _restore_execution_owner(previous) -> None:
    global _ACTIVE_OWNER_SESSION, _ACTIVE_OWNER_CALL
    _ACTIVE_OWNER_SESSION, _ACTIVE_OWNER_CALL = previous


@contextlib.contextmanager
def _execution_owner(session_id: str | None, call_id: str | None):
    """Scope trusted host provenance to exactly one serialized execution."""
    previous = _set_execution_owner(session_id, call_id)
    try:
        yield
    finally:
        _restore_execution_owner(previous)


def _register_owned_node(node, *, exclude_ids=()) -> None:
    """Record a verb-created subtree, excluding identities predating a replacement."""
    if node is None or _ACTIVE_OWNER_SESSION is None:
        return
    items = [node]
    try:
        # Materialize the newly created HDA's delayed definition NOW. Otherwise
        # its native children first appear on cook and incorrectly look foreign.
        # Never do this later to adopt arbitrary children of an owned parent.
        items.extend(node.allSubChildren(sync_delayed_definition=True))
    except Exception:
        pass
    for item in items:
        if int(item.sessionId()) in exclude_ids:
            continue
        entry = {
            "session": _ACTIVE_OWNER_SESSION,
            "call": _ACTIVE_OWNER_CALL,
            "path_at_creation": item.path(),
            "type": item.type().name(),
        }
        _OWNED_NODE_SESSIONS[int(item.sessionId())] = entry
        if _CREATION_JOURNAL is not None:
            _CREATION_JOURNAL.add(int(item.sessionId()))
        item.setUserData(_TASK_OWNER_KEY, _ACTIVE_OWNER_SESSION)
        if _ACTIVE_OWNER_CALL:
            item.setUserData(_TASK_OWNER_CALL_KEY, _ACTIVE_OWNER_CALL)


@contextlib.contextmanager
def _track_owned_definition_rebuilds(instances):
    """Attribute only fresh identities produced by this explicit native operation.

    An explicitly allowed foreign instance stays foreign. Existing identities,
    including user children moved during a callback, never become owned.
    Materialize delayed definitions inside this boundary, before later cooks.
    """
    owned = [n for n in instances if _ACTIVE_OWNER_SESSION is not None and
             _OWNED_NODE_SESSIONS.get(int(n.sessionId()), {}).get('session') == _ACTIVE_OWNER_SESSION]
    before = {int(n.sessionId()) for n in hou.node('/').allSubChildren()} if owned else set()
    descendants = {int(child.sessionId()) for n in owned for child in n.allSubChildren()}
    foreign_before = before - {identity for identity, entry in _OWNED_NODE_SESSIONS.items()
                               if entry.get('session') == _ACTIVE_OWNER_SESSION}
    try:
        yield
    finally:
        for n in owned:
            if hou.nodeBySessionId(int(n.sessionId())) is not None:
                blocked = set(before)
                for child in n.allSubChildren(sync_delayed_definition=True):
                    ancestor = child
                    while ancestor != n:
                        if int(ancestor.sessionId()) in foreign_before:
                            blocked.add(int(child.sessionId()))
                            break
                        ancestor = ancestor.parent()
                _register_owned_node(n, exclude_ids=blocked)
        for identity in descendants:
            if hou.nodeBySessionId(identity) is None:
                _OWNED_NODE_SESSIONS.pop(identity, None)


def node_provenance(node) -> dict:
    """Report runtime ownership separately from durable, copyable audit tags."""
    n = _resolve(node)
    if n.userData(_RENDER_OWNER_KEY) == _RENDER_OWNER_VALUE:
        status = "dsh_service"
        runtime_owner = None
    else:
        runtime_owner = _OWNED_NODE_SESSIONS.get(int(n.sessionId()))
        if runtime_owner is None:
            status = "foreign"
        elif runtime_owner.get("session") == _ACTIVE_OWNER_SESSION:
            status = "owned_current_session"
        else:
            status = "owned_other_session"
    return {
        "path": n.path(),
        "session_id": int(n.sessionId()),
        "status": status,
        "writable": status == "owned_current_session" or _ACTIVE_OWNER_SESSION is None,
        "runtime_owner": dict(runtime_owner) if runtime_owner else None,
        "audit_owner_session": n.userData(_TASK_OWNER_KEY),
        "audit_created_by_call": n.userData(_TASK_OWNER_CALL_KEY),
    }


def _require_owned(node, operation: str, allow_foreign: str | None = None) -> None:
    """Guard one node mutation while preserving direct Python-shell workflows."""
    # Validate BEFORE the owned/direct-call fast paths. Python annotations are
    # not runtime checks: an accidental port number must never become authority.
    if allow_foreign is not None and (not isinstance(allow_foreign, str) or not allow_foreign.strip()):
        raise ValueError('allow_foreign must be a nonempty explicit authorization reason string, or None')
    if _ACTIVE_OWNER_SESSION is None:
        return
    info = node_provenance(node)
    if info["status"] == "owned_current_session":
        return
    if info["status"] == "dsh_service":
        raise ValueError(
            f"{info['path']} belongs to the persistent dsh-houdini service; "
            f"{operation} is not allowed"
        )
    reason = allow_foreign.strip() if allow_foreign is not None else ""
    if reason:
        print(
            f"[ownership] foreign-node exemption for {operation}: "
            f"{info['path']} — {reason}"
        )
        return
    raise ValueError(
        f"ownership guard: {operation} refused for foreign node {info['path']}. "
        "Nodes are not owned merely because they are inside an agent-created network. "
        "Read/inspect it freely; mutate it only when the user explicitly requested that "
        f"target, then retry with allow_foreign=\"<why the user authorized {operation}>\"."
    )

# ---------------------------------------------------------------------------
# 分类映射与版本解析
# ---------------------------------------------------------------------------

_CATEGORIES = {
    "obj": hou.objNodeTypeCategory,
    "sop": hou.sopNodeTypeCategory,
    "dop": hou.dopNodeTypeCategory,
    "chop": hou.chopNodeTypeCategory,
    "cop": hou.copNodeTypeCategory,
    "cop2": hou.cop2NodeTypeCategory,
    "shop": hou.shopNodeTypeCategory,
    "vop": hou.vopNodeTypeCategory,
    "rop": hou.ropNodeTypeCategory,
    "top": hou.topNodeTypeCategory,
    "lop": hou.lopNodeTypeCategory,
}

# UI 名/常见写法 → 内部名（2026-08-20 OTL 会话：agent 连猜 'Object'/'driver' 两次才蒙对）
_CATEGORY_ALIASES = {
    "object": "obj", "objects": "obj", "geometry": "sop", "sops": "sop",
    "driver": "rop", "drivers": "rop", "out": "rop", "dops": "dop",
    "chops": "chop", "vops": "vop", "tops": "top", "lops": "lop",
    "stage": "lop", "material": "shop", "materials": "shop",
    "shopnet": "shop", "copernicus": "cop", "cops": "cop", "img": "cop2",
}

_VERSION_RE = re.compile(r"^(.*)::(\d+(?:\.\d+)*)$")

# Tab tools execute arbitrary SideFX/user scripts. Start with the two deterministic,
# network-local setup intents proven by session-71d76525 and H21's shipped shelf files;
# expand only with a concrete trace + GUI state-restoration regression.
_TAB_TOOL_ALLOWLIST = {
    "lop_karma_setup",
    "vop_karmamtlxsubnet",
}
_PENDING_TAB_USER_STATE = None
_TAB_RESTORE_POSTED = False


def _category(category):
    if isinstance(category, hou.NodeTypeCategory):
        return category
    if isinstance(category, str):
        key = category.strip().lower()
        key = _CATEGORY_ALIASES.get(key, key)
        factory = _CATEGORIES.get(key)
        if factory is None:
            valid = ", ".join(sorted(_CATEGORIES))
            alias = ", ".join(f"{a}→{b}" for a, b in sorted(_CATEGORY_ALIASES.items()))
            raise ValueError(
                f"unknown node type category: {category!r}；"
                f"合法类别：{valid}；别名：{alias}"
            )
        return factory()
    raise ValueError(f"unknown node type category: {category!r}（合法：{', '.join(sorted(_CATEGORIES))}）")


def context_name(category) -> str:
    """hou.sopNodeTypeCategory() -> 'sop'（用于构造 shelf tool 名）。"""
    return _category(category).name().lower()


# --- scene 域 ---------------------------------------------------------------

def scene_info() -> dict:
    """只读场景/时间线、HIP单位及project_layout目录；不创建目录、不证明写权限。"""
    from dsh_context import hip_file_state, unit_length_meters
    hip = hip_file_state()
    file_exists = hip['file_exists']
    has_unsaved_changes = bool(hou.hipFile.hasUnsavedChanges())
    ui_available = bool(hou.isUIAvailable())
    return {
        **hip,
        "hip_name": hou.hipFile.name(),
        "has_unsaved_changes": has_unsaved_changes,
        "dirty_reliable": ui_available,
        "clean_on_disk": file_exists and not has_unsaved_changes if ui_available else None,
        "version": hou.applicationVersionString(),
        "unit_length_meters": unit_length_meters(),
        "update_mode": {hou.updateMode.AutoUpdate:'auto', hou.updateMode.Manual:'manual', hou.updateMode.OnMouseUp:'on_mouse_up'}[hou.updateModeSetting()],
        "fps": float(hou.fps()),
        "frame": float(hou.frame()),
        "time": float(hou.time()),
        "frame_range": [float(v) for v in hou.playbar.frameRange()],
        "playback_range": [float(v) for v in hou.playbar.playbackRange()],
        "range_restricted": bool(hou.playbar.isRangeRestricted()),
        "playing": bool(hou.playbar.isPlaying()),
        "ui_available": ui_available,
    }


def scene_save(expected_path: str | None = None) -> dict:
    """保存当前已命名 HIP，并回报真实 dirty/file 状态；不承担 Save As。"""
    path = os.path.abspath(hou.hipFile.path())
    if not scene_info()["has_named_path"]:
        raise ValueError("当前 HIP 尚未命名；确认目标路径后用 scene_save_as，或先在 Houdini UI 中 Save As")
    if expected_path is not None:
        expected = os.path.abspath(hou.expandString(str(expected_path)))
        if os.path.normcase(expected) != os.path.normcase(path):
            raise ValueError(f"expected_path 与当前 HIP 不一致：expected={expected!r}, current={path!r}")
    dirty_before = bool(hou.hipFile.hasUnsavedChanges())
    hou.hipFile.save()
    dirty_after = bool(hou.hipFile.hasUnsavedChanges())
    dirty_reliable = bool(hou.isUIAvailable())
    if not os.path.isfile(path):
        raise RuntimeError(f"hou.hipFile.save() 返回后文件不存在：{path}")
    stat = os.stat(path)
    if stat.st_size == 0:
        raise RuntimeError(f"保存后 HIP 文件为空：{path}")
    return {
        "path": path,
        "dirty_before": dirty_before,
        "dirty_after": dirty_after,
        "dirty_reliable": dirty_reliable,
        "clean_on_disk": not dirty_after if dirty_reliable else None,
        "bytes": int(stat.st_size),
        "mtime_ns": int(stat.st_mtime_ns),
    }


def scene_save_as(path: str, expected_current_path: str, reason: str,
                  overwrite: bool = False) -> dict:
    """Save As to an explicitly authorized absolute HIP path; never load/clear.

    ``expected_current_path`` must match the current scene. Existing targets
    require explicit ``overwrite=True`` and user authorization in ``reason``.
    File I/O is not undoable; a failed save may leave a partial new target.
    After a workspace change, use Open Workspace to select the matching DSH session.
    """
    if not isinstance(reason, str) or not reason.strip():
        raise ValueError("reason 必须记录用户对目标路径/覆盖的明确授权")
    if not isinstance(overwrite, bool):
        raise ValueError("overwrite 必须是 bool")
    current = os.path.abspath(hou.hipFile.path())
    if not isinstance(expected_current_path, str) or not expected_current_path:
        raise ValueError("expected_current_path 必须来自 scene_info().hip_path")
    expected = os.path.abspath(hou.expandString(expected_current_path))
    if os.path.normcase(expected) != os.path.normcase(current):
        raise ValueError(f"expected_current_path 不匹配：{expected!r} != {current!r}")
    if not isinstance(path, str) or not path.strip():
        raise ValueError("path 必须是明确的绝对 HIP 路径")
    target = hou.expandString(path)
    if not os.path.isabs(target) or os.path.splitext(target)[1].lower() not in (".hip", ".hiplc", ".hipnc"):
        raise ValueError("path 必须是绝对路径，扩展名为 .hip/.hiplc/.hipnc")
    target = os.path.realpath(target)
    from dsh_executor_registry import require_save_target
    require_save_target(target)
    repo = os.path.realpath(os.path.join(os.path.dirname(__file__), "..", ".."))
    try:
        in_repo = os.path.commonpath([repo, target]) == repo
    except ValueError:
        in_repo = False
    if in_repo:
        raise ValueError("HIP 产物不能保存到插件仓库；请选择用户项目目录")
    existed = os.path.lexists(target)
    if existed and not overwrite:
        raise ValueError(f"target exists: {target}; 当前文件请用 scene_save，另存覆盖需要明确授权 overwrite=True")
    if existed and not os.path.isfile(target):
        raise ValueError(f"target is not a regular file: {target}")
    dirty_before = bool(hou.hipFile.hasUnsavedChanges())
    os.makedirs(os.path.dirname(target), exist_ok=True)
    if not overwrite:
        # Reserve without a check-then-overwrite race. Only a new empty file is
        # created; a concurrent existing target causes FileExistsError.
        with open(target, "xb"):
            pass
    try:
        # H21 file-event callbacks do not consistently escape Windows backslashes.
        hou.hipFile.save(file_name=target.replace("\\", "/"))
        if os.path.normcase(os.path.realpath(hou.hipFile.path())) != os.path.normcase(target):
            raise RuntimeError("Save As 返回后当前 HIP 路径与目标不一致")
        stat = os.stat(target)
        if stat.st_size == 0:
            raise RuntimeError("Save As 返回后目标 HIP 为空")
    except BaseException:
        # Restoring the in-memory name is not a claim that disk I/O rolled back.
        hou.hipFile.setName(current.replace("\\", "/"))
        raise
    reliable = bool(hou.isUIAvailable())
    dirty_after = bool(hou.hipFile.hasUnsavedChanges())
    return {"path": target, "previous_path": current, "reason": reason.strip(),
            "overwrote": existed, "dirty_before": dirty_before, "dirty_after": dirty_after,
            "dirty_reliable": reliable, "clean_on_disk": not dirty_after if reliable else None,
            "bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns,
            "workspace_changed": os.path.normcase(os.path.dirname(current)) != os.path.normcase(os.path.dirname(target)),
            "note": "文件写入不能撤销。更换工程目录后，请选择 DSH-Houdini → Open Workspace。"}


def _frame_pair(value, label: str) -> tuple[float, float]:
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError(f"{label} 必须是 [start, end]")
    start, end = float(value[0]), float(value[1])
    if not math.isfinite(start) or not math.isfinite(end):
        raise ValueError(f"{label} 必须是有限帧数")
    if end < start:
        raise ValueError(f"{label} end 不能小于 start：{start}, {end}")
    return start, end


def set_timeline(fps=None, frame_range=None, playback_range=None,
                 current_frame=None) -> dict:
    """设置时间线；先验证所有字段，写入失败恢复原fps、范围与当前帧。"""
    changed = {}
    try:
        if all(value is None for value in (fps, frame_range, playback_range, current_frame)):
            raise ValueError("至少提供 fps/frame_range/playback_range/current_frame 一项")
        if fps is not None:
            value = float(fps)
            if not math.isfinite(value) or value <= 0:
                raise ValueError("fps 必须是大于 0 的有限数值")
            changed['fps'] = value
        for key, value in (('frame_range', frame_range), ('playback_range', playback_range)):
            if value is not None:
                changed[key] = list(_frame_pair(value, key))
        if current_frame is not None:
            value = float(current_frame)
            if not math.isfinite(value):
                raise ValueError('current_frame 必须是有限帧数')
            changed['current_frame'] = value
        before = scene_info()
    except (ValueError, TypeError, OverflowError, hou.Error) as error:
        raise CheckpointError(str(error), {'ok': False, 'phase': 'timeline_preflight',
            'scene_writes': 0, 'applied': False}) from error
    setters = {'fps': lambda v: hou.setFps(v),
               'frame_range': lambda v: hou.playbar.setFrameRange(*v),
               'playback_range': lambda v: hou.playbar.setPlaybackRange(*v),
               'current_frame': lambda v: hou.setFrame(v)}
    writes = 0
    try:
        for key, value in changed.items():
            writes += 1
            setters[key](value)
        return {'changed': changed, 'scene': scene_info(), 'scene_writes': writes}
    except BaseException as error:
        restore_errors = []
        # FPS/ranges can affect the frame; restore the original frame last.
        for key, value in (('fps', before['fps']), ('frame_range', before['frame_range']),
                           ('playback_range', before['playback_range']), ('current_frame', before['frame'])):
            try:
                setters[key](value)
            except Exception as failure:
                restore_errors.append(f'{key}: {failure}')
        try:
            after = scene_info()
            for key in ('fps', 'frame_range', 'playback_range', 'frame'):
                if after[key] != before[key]:
                    restore_errors.append(f'{key}: restoration readback differs')
        except Exception as failure:
            restore_errors.append(f'restoration readback: {failure}')
        raise CheckpointError(f'set_timeline failed: {error}; restore_errors={restore_errors}',
            {'ok': False, 'phase': 'timeline_write', 'scene_writes': writes,
             'restored': not restore_errors, 'restore_errors': restore_errors,
             'scope': 'timeline state only; cooks and external side effects are not restored'}) from error


def list_bookmarks() -> list:
    """列出动画时间线 bookmarks。"""
    return [
        {
            "id": bookmark.sessionId(),
            "name": bookmark.name(),
            "start": float(bookmark.startFrame()),
            "end": float(bookmark.endFrame()),
            "enabled": bool(bookmark.isEnabled()),
            "visible": bool(bookmark.visible()),
            "temporary": bool(bookmark.isTemporary()),
            "comment": bookmark.comment(),
        }
        for bookmark in hou.anim.bookmarks()
    ]


def create_bookmark(name: str, start, end, replace: bool = False) -> dict:
    """创建 bookmark；同名默认拒绝，``replace=True`` 精确替换同名项。"""
    if not isinstance(name, str) or not name.strip():
        raise ValueError("bookmark name 必须是非空字符串")
    name = name.strip()
    start_frame, end_frame = _frame_pair((start, end), "bookmark range")
    if not start_frame.is_integer() or not end_frame.is_integer():
        raise ValueError("bookmark start/end 必须是整数帧")
    existing = [bookmark for bookmark in hou.anim.bookmarks() if bookmark.name() == name]
    if existing and not replace:
        raise ValueError(f"bookmark {name!r} 已存在；确认替换时传 replace=True")
    if existing:
        hou.anim.removeBookmarks(existing)
    bookmark = hou.anim.newBookmark(name, int(start_frame), int(end_frame))
    return {
        "id": bookmark.sessionId(),
        "name": bookmark.name(),
        "start": float(bookmark.startFrame()),
        "end": float(bookmark.endFrame()),
        "replaced": len(existing),
    }


def delete_bookmark(name_or_id) -> dict:
    """按精确名称或 session id 删除 bookmark。"""
    matches = []
    for bookmark in hou.anim.bookmarks():
        if isinstance(name_or_id, int) and bookmark.sessionId() == name_or_id:
            matches.append(bookmark)
        elif isinstance(name_or_id, str) and bookmark.name() == name_or_id:
            matches.append(bookmark)
    if not matches:
        raise ValueError(
            f"找不到 bookmark {name_or_id!r}；现有："
            f"{[(item['id'], item['name']) for item in list_bookmarks()]}"
        )
    deleted = [
        {"id": bookmark.sessionId(), "name": bookmark.name()}
        for bookmark in matches
    ]
    hou.anim.removeBookmarks(matches)
    return {"deleted": deleted}


def _version_key(version: str):
    return tuple(int(p) for p in version.split("."))


def resolve_latest_type(category, base: str) -> str:
    """返回某节点族的最新版本全名，如 'copytopoints' -> 'copytopoints::2.0'。

    无版本化条目时返回已注册的 ``base``；有多个 ``::N`` 时取 ``N`` 最大者。
    只以 namespace 形式注册的族（'rigdoctor' -> 'kinefx::rigdoctor'）返回带
    namespace 的全名：`createNode(exact_type_name=True)` 不接受裸别名。
    多 namespace 同名时按名称排序取第一个（确定性兜底）。
    当前类别不存在该族时明确失败，不把未验证的输入伪装成解析结果。
    """
    cat = _category(category)
    names = cat.nodeTypes().keys()
    prefix = base + "::"
    best_key: tuple[int, ...] = ()
    best_name = base if base in names else None
    for name in names:
        if not name.startswith(prefix):
            continue
        m = _VERSION_RE.match(name)
        if not m:
            continue
        key = _version_key(m.group(2))
        if key > best_key:
            best_key = key
            best_name = name
    if best_name is not None:
        return best_name
    ns_key: tuple[int, ...] = ()
    ns_name = None
    for name in sorted(names):
        parts = name.split("::")
        if len(parts) == 2 and parts[1] == base and ns_name is None:
            ns_name = name
        elif len(parts) == 3 and parts[1] == base:
            key = _version_key(parts[2])
            if key > ns_key:
                ns_key = key
                ns_name = name
    if ns_name is not None:
        return ns_name
    raise ValueError(
        f"未知节点类型族：{base!r}；category={cat.name()}；"
        "用 search_tab_menu(category, query) 或 search_tab_entries(parent, query) 查当前版本的真实类型"
    )


# ---------------------------------------------------------------------------
# 通用 Tab Menu 创建
# ---------------------------------------------------------------------------

def _network_editor():
    if not hou.isUIAvailable():
        return None
    pane = toolutils.networkEditor()
    if pane is not None:
        return pane
    for tab in hou.ui.paneTabs():
        if tab.type() == hou.paneTabType.NetworkEditor:
            return tab
    return None


def _run_shelf_tool(tool, parent: hou.Node, type_name: str) -> hou.Node | None:
    """在目标网络中跑 shelf tool，返回其新建的节点；无 pane/失败时返回 None。"""
    pane = _network_editor()
    if pane is None:
        return None

    prev_pwd = pane.pwd()
    try:
        pane.setPwd(parent)
        if pane.pwd() is None or pane.pwd().path() != parent.path():
            return None
    except Exception:
        return None

    before = {c.sessionId() for c in parent.children()}
    try:
        toolutils.testTool(
            tool,
            kwargs={
                "pane": pane,
                "toolname": type_name,
                "autoplace": True,
                "shiftclick": False,
                "ctrlclick": False,
                "altclick": False,
            },
        )
    except BaseException:
        # A failed shelf script may already have created part of its network.
        # Never let tab_create reinterpret that semantic failure as permission
        # to create a weaker bare node; clean the known partial creations and
        # re-raise so the bridge can roll back any other undoable edits.
        for child in reversed(parent.children()):
            if child.sessionId() not in before:
                ids = [int(n.sessionId()) for n in (child, *child.allSubChildren())]
                try:
                    child.destroy()
                except Exception:
                    continue  # a live node keeps its registration
                # Headless has no undo, so the bridge registry restore never runs;
                # a partial child destroyed here must not leave a stale entry that
                # a later batch's undo reconcile could adopt.
                for identity in ids:
                    _OWNED_NODE_SESSIONS.pop(identity, None)
        raise
    finally:
        try:
            if prev_pwd is not None:
                pane.setPwd(prev_pwd)
        except Exception:
            pass

    created = [c for c in parent.children() if c.sessionId() not in before]
    for child in created:
        _register_owned_node(child)
    if len(created) == 1:
        return created[0]
    # 多个新节点：优先类型完全匹配；否则取第一个（绝不回退 createNode——
    # tool 已经建过节点，再建一次就是场景里的重复残留）
    match = next((c for c in created if c.type().name() == type_name), None)
    if match is not None:
        return match
    return created[0] if created else None


def _tool_context(tool, parent: hou.Node) -> dict:
    """Return Network Editor menu metadata and whether *tool* applies to parent."""
    pane_type = hou.paneTabType.NetworkEditor
    try:
        categories = tuple(tool.toolMenuCategories(pane_type) or ())
    except Exception:
        categories = ()
    try:
        op_type = str(tool.toolMenuOpType(pane_type) or "")
    except Exception:
        op_type = ""
    try:
        locations = list(tool.toolMenuLocations() or ())
    except Exception:
        locations = []

    child_category = parent.childTypeCategory()
    category_match = child_category in categories
    op_type_match = False
    if op_type:
        category_name, _, operator_name = op_type.partition("/")
        if category_name.lower() == child_category.name().lower():
            # Material Library presents a Vop/materialbuilder network even though its
            # owning node is a Lop/materiallibrary. This is the shipped context for the
            # Karma/USD Material Builder tools.
            if operator_name == "materialbuilder":
                op_type_match = (
                    parent.type().category() == hou.lopNodeTypeCategory()
                    and parent.type().name().split("::", 1)[0] == "materiallibrary"
                )
            else:
                parent_type = parent.type().name().split("::", 1)[0]
                op_type_match = parent_type == operator_name
    return {
        "categories": [category.name() for category in categories],
        "op_type": op_type or None,
        "locations": locations,
        "matches": bool(category_match or op_type_match),
    }


def _visible_node_type(node_type) -> bool:
    try:
        if node_type.hidden() or node_type.deprecated():
            return False
    except Exception:
        pass
    return True


def search_tab_entries(parent, query: str = "") -> dict:
    """列出父网络真实可见的节点/Tab tool entry，不把类型注册表冒充菜单。

    返回 entry 的 ``kind`` 为 ``node_type`` 或 ``tool``。Material Library 根层只
    暴露 builder tool；shader 应进入对应 builder 后再创建。隐藏/废弃 node type
    不进入 entries，但计入 excluded。``executable`` 仅表示 dsh 当前安全 allowlist，
    不是 SideFX 工具是否存在。
    """
    parent = _resolve(parent)
    if not parent.isNetwork():
        raise ValueError(f"{parent.path()} 不是可创建子节点的网络")
    q = str(query or "").strip().lower()
    child_category = parent.childTypeCategory()
    entries = []
    excluded_hidden = 0

    # Since H20 the Material Library root is a builder launcher, not a free-form VOP
    # graph. Its tool entries below are the truthful UI surface.
    material_library_root = (
        parent.type().category() == hou.lopNodeTypeCategory()
        and parent.type().name().split("::", 1)[0] == "materiallibrary"
    )
    if not material_library_root:
        families: dict[str, list] = {}
        for name, node_type in child_category.nodeTypes().items():
            label = node_type.description() or name
            if q and q not in name.lower() and q not in label.lower():
                continue
            if not _visible_node_type(node_type):
                excluded_hidden += 1
                continue
            match = _VERSION_RE.match(name)
            base = match.group(1) if match else name
            families.setdefault(base, []).append(node_type)
        for base, node_types in families.items():
            def version_key(node_type):
                match = _VERSION_RE.match(node_type.name())
                return _version_key(match.group(2)) if match else ()
            latest = max(node_types, key=version_key)
            entries.append({
                "kind": "node_type",
                "name": latest.name(),
                "base": base,
                "label": latest.description() or latest.name(),
                "versions": sorted(node_type.name() for node_type in node_types),
                "executable": True,
            })

    for tool_id, tool in hou.shelves.tools().items():
        try:
            label = tool.label() or tool_id
        except Exception:
            continue
        if q and q not in tool_id.lower() and q not in label.lower():
            continue
        context = _tool_context(tool, parent)
        if not context["matches"]:
            continue
        entries.append({
            "kind": "tool",
            "name": tool_id,
            "label": label,
            "locations": context["locations"],
            "op_type": context["op_type"],
            "executable": tool_id in _TAB_TOOL_ALLOWLIST,
        })

    entries.sort(key=lambda item: (item["label"].lower(), item["kind"], item["name"]))
    return {
        "parent": parent.path(),
        "child_category": child_category.name(),
        "query": query,
        "entries": entries,
        "excluded_hidden_or_deprecated": excluded_hidden,
    }


def _apply_karma_setup_recipe(parent: hou.Node) -> list:
    """Non-interactive adapter for SideFX ``lop_karma_setup`` semantics."""
    settings = parent.createNode("karmarendersettings", node_name="karmarendersettings")
    rop = parent.createNode("usdrender_rop")
    rop.setInput(0, settings)
    settings_name = settings.name()
    required = {
        "rendersettings": f'chs("../{settings_name}/primpath")',
        "husk_instantshutter": f'1 - ch("../{settings_name}/enablemblur")',
        "renderer": (
            f'"BRAY_HdKarma" + ifs(strmatch(chs("../{settings_name}/engine"), '
            '"xpu"), "XPU", "")'
        ),
    }
    for parm_name, expression in required.items():
        parm = rop.parm(parm_name)
        if parm is None:
            raise RuntimeError(
                f"当前 Houdini 的 {rop.type().name()} 缺少 Karma Setup 参数 {parm_name!r}"
            )
        parm.setExpression(expression, language=hou.exprLanguage.Hscript)
    return [settings, rop]


def _apply_karma_material_builder_recipe(parent: hou.Node) -> list:
    """Use the installed SideFX builder initializer without its selection UI."""
    import voptoolutils

    setup = getattr(voptoolutils, "_setupMtlXBuilderSubnet", None)
    mask = getattr(voptoolutils, "KARMAMTLX_TAB_MASK", None)
    if setup is None or not mask:
        raise RuntimeError(
            "当前 Houdini 缺少 Karma Material Builder initializer；"
            "请检查 voptoolutils 版本"
        )
    builder = parent.createNode("subnet", node_name="karmamaterial")
    result = setup(
        subnet_node=builder,
        name="karmamaterial",
        mask=mask,
        folder_label="Karma Material Builder",
        render_context="kma",
    )
    if result is None:
        raise RuntimeError("SideFX Karma Material Builder initializer 返回空")
    return [result]


def _capture_tab_user_state(pane) -> dict:
    selected = list(hou.selectedNodes())
    pane_current = None
    try:
        pane_current = pane.currentNode() if pane is not None else None
    except Exception:
        pass
    return {
        "pane": pane,
        "pwd": pane.pwd().path() if pane is not None and pane.pwd() is not None else None,
        "selected": [node.path() for node in selected],
        "current": [node.path() for node in selected if node.isCurrent()],
        "pane_current": pane_current.path() if pane_current is not None else None,
    }


def _apply_tab_user_state(state: dict) -> dict:
    pane = state.get("pane")
    pwd_path = state.get("pwd")
    if pane is not None and pwd_path:
        pwd = hou.node(pwd_path)
        if pwd is not None:
            pane.setPwd(pwd)
    hou.clearAllSelected()
    for path in state.get("current", []):
        node = hou.node(path)
        if node is not None:
            node.setCurrent(True)
    pane_current = hou.node(state.get("pane_current")) if state.get("pane_current") else None
    if pane is not None and pane_current is not None:
        pane.setCurrentNode(pane_current)
    for path in state.get("selected", []):
        node = hou.node(path)
        if node is not None:
            node.setSelected(True)
    actual_selected = sorted(node.path() for node in hou.selectedNodes())
    expected_selected = sorted(
        path for path in state.get("selected", []) if hou.node(path) is not None
    )
    return {
        "network_pwd": pane is None or not pwd_path or (
            pane.pwd() is not None and pane.pwd().path() == pwd_path
        ),
        "selection": actual_selected == expected_selected,
    }


def _finish_pending_tab_restore():
    global _PENDING_TAB_USER_STATE, _TAB_RESTORE_POSTED
    state = _PENDING_TAB_USER_STATE
    _PENDING_TAB_USER_STATE = None
    _TAB_RESTORE_POSTED = False
    if state is not None:
        try:
            _apply_tab_user_state(state)
        except Exception:
            pass


def _queue_final_tab_restore():
    """Second event-loop hop: run after Houdini's deferred node-selection post."""
    try:
        hou.ui.postEventCallback(_finish_pending_tab_restore)
    except Exception:
        _finish_pending_tab_restore()


def tab_apply(parent, tool_id: str) -> dict:
    """应用 allowlist 内的非交互 Tab setup recipe，返回全部新增节点。

    这和 ``tab_create`` 的单节点契约不同。当前只允许 H21/H22 的 Karma (Setup)
    与 Karma Material Builder；运行时仍验证真实 tool/context，但通过 SideFX recipe
    adapter 避开通用 shelf UI 的 selection/current/modal 副作用。未知工具明确拒绝。
    """
    parent = _resolve(parent)
    if not parent.isNetwork():
        raise ValueError(f"{parent.path()} 不是可应用 Tab tool 的网络")
    if not isinstance(tool_id, str) or not tool_id.strip():
        raise ValueError("tool_id 必须是非空字符串")
    tool_id = tool_id.strip()
    tool = hou.shelves.tool(tool_id)
    if tool is None:
        raise ValueError(f"找不到 Tab tool {tool_id!r}")
    context = _tool_context(tool, parent)
    if not context["matches"]:
        raise ValueError(
            f"Tab tool {tool_id!r} 不适用于 {parent.path()}"
            f"（child category={parent.childTypeCategory().name()}, "
            f"tool categories={context['categories']}, op_type={context['op_type']!r}）"
        )
    if tool_id not in _TAB_TOOL_ALLOWLIST:
        raise ValueError(
            f"Tab tool {tool_id!r} 存在但不在 dsh 安全 allowlist；"
            f"当前允许：{sorted(_TAB_TOOL_ALLOWLIST)}"
        )
    global _PENDING_TAB_USER_STATE, _TAB_RESTORE_POSTED
    pane = _network_editor() if hou.isUIAvailable() else None
    if pane is not None:
        if _PENDING_TAB_USER_STATE is None:
            _PENDING_TAB_USER_STATE = _capture_tab_user_state(pane)
        user_state = _PENDING_TAB_USER_STATE
    else:
        user_state = _capture_tab_user_state(None)
    before = {child.sessionId() for child in parent.children()}
    try:
        try:
            if tool_id == "lop_karma_setup":
                recipe_nodes = _apply_karma_setup_recipe(parent)
            elif tool_id == "vop_karmamtlxsubnet":
                recipe_nodes = _apply_karma_material_builder_recipe(parent)
            else:  # guarded by allowlist, defensive for future edits
                raise ValueError(f"Tab tool {tool_id!r} 没有安全 recipe adapter")
        except BaseException:
            # GUI exec has an undo transaction, but headless does not. Clean only
            # children created by this recipe attempt so a partial setup never leaks.
            for child in reversed(parent.children()):
                if child.sessionId() not in before:
                    ids = [int(n.sessionId()) for n in (child, *child.allSubChildren())]
                    try:
                        child.destroy()
                    except Exception:
                        continue  # a live node keeps its registration
                    for identity in ids:
                        _OWNED_NODE_SESSIONS.pop(identity, None)
            raise
        created = [child for child in parent.children() if child.sessionId() not in before]
        if not created:
            raise RuntimeError(f"Tab tool {tool_id!r} 没有在 {parent.path()} 创建节点")
        for child in created:
            _register_owned_node(child)
        if not all(node in created for node in recipe_nodes):
            raise RuntimeError(f"Tab tool {tool_id!r} recipe 返回了父网络外节点")
        created.sort(key=lambda node: node.path())
        result = {
            "tool_id": tool_id,
            "label": tool.label() or tool_id,
            "parent": parent.path(),
            "execution": "sidefx_recipe_adapter",
            "created": [
                {
                    "path": node.path(),
                    "type": node.type().name(),
                    "category": node.type().category().name(),
                    "inputs": [source.path() if source is not None else None for source in node.inputs()],
                }
                for node in created
            ],
        }
    finally:
        try:
            immediate_state = _apply_tab_user_state(user_state)
        except Exception:
            immediate_state = {"network_pwd": False, "selection": False}
        if pane is not None and not _TAB_RESTORE_POSTED:
            try:
                # First hop runs after the surrounding exec unwinds; it queues the
                # actual restoration one event turn later than node creation's own
                # deferred selection update.
                hou.ui.postEventCallback(_queue_final_tab_restore)
                _TAB_RESTORE_POSTED = True
            except Exception:
                _finish_pending_tab_restore()

    result["state_restored"] = immediate_state
    result["final_restore"] = "posted" if pane is not None else "synchronous"
    return result


def _tool_has_extra_init(tool) -> bool:
    """判断 shelf tool 是否在 genericTool 之外还有「实质性」初始化。

    只有会真正改场景的操作才算额外初始化（按初始化按钮 / 建配套节点 / 连输入 /
    应用 recipe）；给 ``kwargs`` 设默认值（bbox/parms）或普通赋值不算——那些
    agent 直接设参数即可，不值得为每个节点做昂贵的 pane 导航 + testTool。
    """
    markers = ("pressButton(", "createNode(", "setInput(", "applyTabToolRecipe", ".parm(")
    script = tool.script() or ""
    for line in script.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if s.startswith("import ") or s.startswith("from "):
            continue
        if "genericTool(" in s:
            continue
        if any(m in s for m in markers):
            return True
    return False


def _flow_gaps(nodes):
    """由节点实际网络尺寸推导 flow 落位的水平/垂直间距（不用拍脑袋常量）。"""
    width = height = 0.0
    for n in nodes:
        try:
            size = n.size()
            width = max(width, float(size.x()))
            height = max(height, float(size.y()))
        except Exception:
            continue
    h_gap = (width if width > 0 else 2.0) + 0.8
    v_gap = (height if height > 0 else 1.0) + 0.4
    return h_gap, v_gap


def _local_free_position(node, preferred):
    from dsh_network_layout import Rect, find_free_translation
    from dsh_network_boxes import _effective_box_rect,collect_editor_obstacles
    parent=node.parent();size=node.size();width,height=float(size.x()),float(size.y())
    source=Rect(0,0,width,height);current_box=node.parentNetworkBox()
    obstacles=collect_editor_obstacles(parent,excluded_node_ids=[int(node.sessionId())],
        excluded_box_ids=[] if current_box is None else [int(current_box.sessionId())],
        dot_footprint=(width*.5,height))
    container=None if current_box is None else _effective_box_rect(current_box)
    result=find_free_translation(source,obstacles,preferred=preferred,
        step=(max(width*1.5,1e-3),max(height*2.0,1e-3)),
        clearance=(width*.5,height*.75),container=container,max_candidates=512)
    return {'ok':result['ok'],'status':'adjusted' if result['ok'] else 'blocked',
            'position':result.get('translation'),'blockers':result.get('blocked_by') or []}


def _place_created_node(node):
    """tab_create 智能落位：有输入放到输入下游，无输入放右侧新列（空网络落原点）。

    网络坐标 y 向下为负：输入下游 = 更小的 y；「最顶部」= 最大的 y。
    """
    parent = node.parent()
    inputs = [n for n in node.inputs() if n is not None]
    if inputs:
        _h_gap, v_gap = _flow_gaps([node, *inputs])
        x = sum(float(n.position().x()) for n in inputs) / len(inputs)
        y = min(float(n.position().y()) for n in inputs) - v_gap
    else:
        siblings = [c for c in parent.children() if c.sessionId() != node.sessionId()]
        if siblings:
            x = max(float(c.position().x()) + float(c.size().x()) for c in siblings) + 0.8
            y = max(float(c.position().y()) for c in siblings)
        else:
            x=y=0.0
    placement=_local_free_position(node,(x,y))
    if not placement['ok']:
        raise RuntimeError(f"no bounded collision-free position for {node.path()}: {placement['blockers']}")
    node.setPosition(hou.Vector2(*placement['position']))


def _snap_into_flow(node):
    """connect 纠流：节点违反自顶向下流（不在所有输入下游）时 snap 到输入正下方。

    已在下游（y 严格小于所有输入的 min y）的节点绝不动。返回是否移动了节点。
    """
    inputs = [n for n in node.inputs() if n is not None]
    if not inputs:
        return {'adjusted':False,'status':'unchanged','blockers':[]}
    min_y = min(float(n.position().y()) for n in inputs)
    if float(node.position().y()) < min_y:
        return {'adjusted':False,'status':'unchanged','blockers':[]}
    _h_gap, v_gap = _flow_gaps([node, *inputs])
    x = sum(float(n.position().x()) for n in inputs) / len(inputs)
    from dsh_network_boxes import journal_containing_boxes
    try:
        placement=_local_free_position(node,(x,min_y-v_gap))
    except Exception as error:
        return {'adjusted':False,'status':'blocked',
                'blockers':['obstacle_measurement_failed:'+str(error)]}
    if not placement['ok']:
        return {'adjusted':False,'status':'blocked','blockers':placement['blockers']}
    journal_containing_boxes([node], 'connect_position_before')
    node.setPosition(hou.Vector2(*placement['position']))
    return {'adjusted':True,'status':'adjusted','blockers':[]}


def _initialize_created_inputs(node, input_nodes):
    """Reconcile the shipped Sweep initializer with an explicit second input."""
    if node.type().name() == 'sweep::2.0' and len(input_nodes) > 1 and input_nodes[1] is not None:
        shape = node.parm('surfaceshape')
        if shape is None or 'input' not in shape.menuItems():
            raise ValueError('Sweep 2.0 input initializer contract changed; cannot select supplied cross-section')
        shape.set('input')


def _prepare_tab_create(parent, type_name, inputs, parms):
    """Resolve creation and wires completely before calling a shelf or createNode."""
    parent = _resolve(parent)
    cat = parent.childTypeCategory()
    if cat is None:
        raise ValueError(
            f'tab_create parent={parent.path()!r} is not a network that can create nodes; '
            f'use its existing creation network {parent.parent().path()!r}'
        )
    ctx = context_name(cat)
    latest = resolve_latest_type(cat, type_name)
    node_type = hou.nodeType(cat, latest)
    if inputs is not None and not isinstance(inputs, list):
        raise ValueError("inputs 必须是 source 节点/path 的 list")
    if parms is not None and (not isinstance(parms, dict) or not parms):
        raise ValueError("parms 必须是非空 {参数名: 值} dict")
    if inputs and cat == hou.objNodeTypeCategory():
        raise ValueError("Object inputs are parenting; create first, then use set_object_parent")
    input_nodes = [None if source is None else _resolve_in_parent(parent, source) for source in (inputs or [])]
    for source in input_nodes:
        if source is not None and source.parent() != parent:
            raise ValueError(f'different_parent: source={source.path()} parent={source.parent().path()}, destination parent={parent.path()}; use an Object Merge inside the destination SOP network or an explicit subnet input, not cross-network wires')
    if node_type is not None and len(input_nodes) > node_type.maxNumInputs():
        raise ValueError(f"{latest} 最多接受 {node_type.maxNumInputs()} 个输入，收到 {len(input_nodes)}")
    if node_type is not None and not _visible_node_type(node_type):
        raise ValueError(f"节点类型 {latest!r} 在当前 Houdini 中 hidden/deprecated；请用 search_tab_entries(parent, query) 查真实 Tab entry，setup 工具用 tab_apply(parent, tool_id)")
    if (parent.type().category() == hou.lopNodeTypeCategory()
            and parent.type().name().split("::", 1)[0] == "materiallibrary"):
        raise ValueError(f"Material Library 根层不直接创建 {latest!r}；先用 search_tab_entries(parent, query) 选择 Karma/USD/Preview Builder，再用 tab_apply 执行对应 builder tool")
    return parent, ctx, latest, input_nodes


def tab_create(
    parent: hou.Node,
    type_name: str,
    name: str | None = None,
    inputs: list | None = None,
    parms: dict | None = None,
) -> hou.Node | None:
    """按 Tab Menu 语义创建节点：最新版本 + 完整初始化，返回创建的节点。

    - ``parent``：目标父节点（hou.Node 或 path 字符串，如 '/obj'）。
    - ``type_name``：基名即可（'copytopoints'、'box'、'geo'），内部解析最新版。
    - ``inputs``：可选，创建后按序连到 input 0..n（节点、绝对路径或parent相对路径；None保留空槽；
      连接失败会抛错，不会静默跳过）。
    - ``parms``：可选非空严格参数批次，创建/接线后通过set_parms应用；
      任一字段失败会连同新节点一起清理。复杂模块仍优先build_module。
      Sweep 2.0声明第二输入时在接线后校正surfaceshape=input；build_module显式parms随后可覆盖。
    - 有对应 shelf tool 且其带额外初始化时走 tool；否则回退 createNode(latest)
      （避免对 box/grid 这类纯节点做昂贵的 pane 导航）。
    - 落位：连完 inputs 后自动摆放——有输入时以下游均值为首选；无输入时以父网络
      右侧新列为首选（空网络落原点）。再对兄弟节点、其他Network Box、Sticky Note和
      Network Dot做有界避障；找不到安全位置则创建失败并由调用事务清理。间距由节点
      实际尺寸推导，见``_place_created_node``。
    """
    try:
        parent, ctx, latest, input_nodes = _prepare_tab_create(parent, type_name, inputs, parms)
    except Exception as error:
        raise CheckpointError(str(error), {'ok': False, 'phase': 'preflight',
            'scene_writes': 0, 'dispatched': False, 'restored': True,
            'scope': 'Tab creation/type/input resolution; no shelf or node creation was dispatched'}) from error

    tool = None
    try:
        tool = hou.shelves.tool(f"{ctx}_{latest}")
    except Exception:
        tool = None

    before = set(parent.children())
    provenance = dict(_OWNED_NODE_SESSIONS)
    node: hou.Node | None = None
    try:
        if tool is not None and _tool_has_extra_init(tool):
            node = _run_shelf_tool(tool, parent, latest)
        if node is None:
            node = parent.createNode(latest, node_name=name, exact_type_name=True)
            _register_owned_node(node)
        elif name is not None:
            node.setName(name, unique_name=True)
        for index, source in enumerate(input_nodes):
            if source is not None:
                node.setInput(index, source)
        # Sweep's shipped shelf selects a built-in tube before our explicit
        # second input is connected. Reconcile this known input-dependent
        # initializer after wiring. build_module applies explicit parms later.
        _initialize_created_inputs(node, input_nodes)
        if parms is not None:
            set_parms(node, parms)
        _place_created_node(node)
    except BaseException as error:
        # Headless has no undo stack. Never leave a half-created semantic node
        # or provenance after a failed shelf initializer/input/name operation.
        restore_errors = []
        partials = [partial for partial in reversed(parent.children()) if partial not in before]
        for partial in partials:
            try:
                partial.destroy()
            except BaseException as restore_error:
                restore_errors.append(str(restore_error))
        _OWNED_NODE_SESSIONS.clear()
        _OWNED_NODE_SESSIONS.update(provenance)
        raise CheckpointError(str(error), {'ok': False, 'phase': 'apply_failure',
            'scene_writes': None, 'dispatched': True, 'created_node_count': len(partials),
            'restored': not restore_errors, 'restore_errors': restore_errors,
            'scope': 'new direct children removed; external shelf/Python side effects are not covered'}) from error
    return node


# ---------------------------------------------------------------------------
# 只读查询：查不猜
# ---------------------------------------------------------------------------

def search_tab_menu(category, query: str = "") -> dict:
    """只读：列出某 context 下匹配 ``query`` 的节点族，标注各自最新版本。

    返回 ``{families: [...], latest_of_query: ...}``。用于回答「有没有 cone /
    这个节点叫什么 / 最新版是什么」，而不是让模型去猜类型名。
    """
    cat = _category(category)
    q = query.lower().strip()
    q_key = re.sub(r"[^a-z0-9]+", "", q)

    # 按族键聚合（去版本），族键 = 名字去掉末尾 ::N
    families: dict[str, list[str]] = {}
    labels: dict[str, set[str]] = {}
    for name, node_type in cat.nodeTypes().items():
        m = _VERSION_RE.match(name)
        base = m.group(1) if m else name
        try:
            label = node_type.description() or ""
        except Exception:
            label = ""
        haystacks = (name.lower(), base.lower(), label.lower())
        compact = tuple(re.sub(r"[^a-z0-9]+", "", value) for value in haystacks)
        if q and not any(q in value for value in haystacks) and not (
            q_key and any(q_key in value for value in compact)
        ):
            continue
        families.setdefault(base, []).append(name)
        if label:
            labels.setdefault(base, set()).add(label)

    result = []
    for base in sorted(families):
        latest = resolve_latest_type(cat, base)
        result.append(
            {
                "base": base,
                "latest": latest,
                "versions": sorted(families[base]),
            }
        )

    # 若 query 精确命中某个族名，给出它的最新版
    exact = None
    if q:
        for entry in result:
            base_key = re.sub(r"[^a-z0-9]+", "", entry["base"].lower())
            label_keys = {
                re.sub(r"[^a-z0-9]+", "", label.lower())
                for label in labels.get(entry["base"], set())
            }
            if entry["base"].lower() == q or base_key == q_key or q_key in label_keys:
                exact = entry["latest"]
                break
    return {"families": result, "latest_of_query": exact}


# ---------------------------------------------------------------------------
# Solaris / USD 只读自省
# ---------------------------------------------------------------------------

def _lop_stage(node):
    node = _resolve(node)
    if node.type().category() != hou.lopNodeTypeCategory() or not hasattr(node, "stage"):
        raise ValueError(f"{node.path()} 不是可提供 USD stage 的 LOP 节点")
    stage = node.stage()
    if stage is None:
        raise ValueError(f"{node.path()} 没有可用的 USD stage")
    return node, stage


def _usd_value_preview(value, limit: int = 8):
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        return 0.0 if value == 0.0 else value
    try:
        if hasattr(value, "pathString"):
            return str(value)
    except Exception:
        pass
    if isinstance(value, dict):
        items = list(value.items())
        return {
            "size": len(items),
            "preview": {
                str(key): _usd_value_preview(item, limit)
                for key, item in items[:limit]
            },
        }
    if isinstance(value, (list, tuple)):
        return {
            "size": len(value),
            "preview": [_usd_value_preview(item, limit) for item in value[:limit]],
        }
    # Vt arrays and Gf vectors are iterable but should never dump full mesh data.
    try:
        size = len(value)
        return {
            "size": int(size),
            "preview": [
                _usd_value_preview(value[index], limit)
                for index in range(min(int(size), limit))
            ],
        }
    except Exception:
        pass
    return str(value)


def _usd_relationships(prim) -> list:
    result = []
    for relationship in prim.GetRelationships():
        result.append({
            "name": str(relationship.GetName()),
            "targets": [str(target) for target in relationship.GetTargets()],
        })
    result.sort(key=lambda item: item["name"])
    return result


def usd_stage_summary(node, max_paths: int = 64) -> dict:
    """只读概览 LOP 的 USD stage：prim 类型、材质绑定、渲染和时间采样语义。"""
    from pxr import UsdLux
    node, stage = _lop_stage(node)
    max_paths = int(max_paths)
    if max_paths < 1 or max_paths > 500:
        raise ValueError("max_paths 必须在 1..500")

    groups = {
        "geometry": [],
        "materials": [],
        "lights": [],
        "cameras": [],
        "render_settings": [],
        "render_products": [],
        "render_vars": [],
        "other": [],
    }
    group_counts = {name: 0 for name in groups}
    material_bindings = []
    time_sampled = []
    time_sampled_total = 0
    total_prims = 0
    geometry_types = {
        "Mesh", "BasisCurves", "NurbsCurves", "Points", "Volume", "Capsule",
        "Cone", "Cube", "Cylinder", "Plane", "Sphere",
    }

    for prim in stage.Traverse():
        total_prims += 1
        path = str(prim.GetPath())
        type_name = str(prim.GetTypeName() or "")
        if prim.HasAPI(UsdLux.LightAPI):
            group = "lights"
        elif type_name in geometry_types:
            group = "geometry"
        elif type_name == "Material":
            group = "materials"
        elif type_name == "Camera":
            group = "cameras"
        elif type_name == "RenderSettings":
            group = "render_settings"
        elif type_name == "RenderProduct":
            group = "render_products"
        elif type_name == "RenderVar":
            group = "render_vars"
        else:
            group = "other"
        roles = [group]
        # Applied light APIs do not erase the prim's geometry role. An emissive
        # mesh must remain discoverable as geometry as well as a light source.
        if group == "lights" and type_name in geometry_types:
            roles.append("geometry")
        for role in roles:
            group_counts[role] += 1
            if len(groups[role]) < max_paths:
                groups[role].append({"path": path, "type": type_name or None})

        relationships = _usd_relationships(prim)
        bindings = [
            relationship for relationship in relationships
            if relationship["name"].startswith("material:binding")
        ]
        if bindings and len(material_bindings) < max_paths:
            material_bindings.append({"prim": path, "bindings": bindings})

        for attribute in prim.GetAttributes():
            try:
                count = int(attribute.GetNumTimeSamples())
            except Exception:
                count = 0
            if count:
                time_sampled_total += 1
            if count and len(time_sampled) < max_paths:
                samples = list(attribute.GetTimeSamples())
                time_sampled.append({
                    "prim": path,
                    "attribute": str(attribute.GetName()),
                    "count": count,
                    "samples": [float(sample) for sample in samples[:16]],
                    "samples_truncated": len(samples) > 16,
                })

    return {
        "node": node.path(),
        "total_prims": total_prims,
        "counts": group_counts,
        "prims": groups,
        "paths_truncated": {
            name: group_counts[name] > len(groups[name]) for name in groups
        },
        "material_bindings": material_bindings,
        "time_sampled_attributes": time_sampled,
        "time_samples_truncated": time_sampled_total > len(time_sampled),
        "errors": list(node.errors()),
        "warnings": list(node.warnings()),
    }


def usd_prim_info(node, prim_path: str, max_properties: int = 200) -> dict:
    """只读检查一个 USD prim 的属性、primvar、关系、绑定和 time samples。"""
    node, stage = _lop_stage(node)
    max_properties = int(max_properties)
    if max_properties < 1 or max_properties > 1000:
        raise ValueError("max_properties 必须在 1..1000")
    prim = stage.GetPrimAtPath(str(prim_path))
    if not prim or not prim.IsValid():
        similar = []
        needle = str(prim_path).lower().rsplit("/", 1)[-1]
        for candidate in stage.Traverse():
            path = str(candidate.GetPath())
            if needle and needle in path.lower():
                similar.append(path)
            if len(similar) >= 12:
                break
        raise ValueError(f"找不到 USD prim {prim_path!r}；相似：{similar}")

    attributes = []
    primvars = []
    properties = list(prim.GetProperties())
    for prop in properties[:max_properties]:
        if not hasattr(prop, "GetTypeName"):
            continue
        name = str(prop.GetName())
        samples = list(prop.GetTimeSamples())
        # Avoid pulling full topology/point arrays merely to answer structure.
        heavy = name in {
            "points", "normals", "faceVertexCounts", "faceVertexIndices",
            "velocities", "accelerations",
        }
        value = None
        if not heavy:
            try:
                value = _usd_value_preview(prop.Get())
            except Exception:
                value = None
        item = {
            "name": name,
            "type": str(prop.GetTypeName()),
            "value": value,
            "value_omitted": heavy,
            "time_sample_count": len(samples),
            "time_samples": [float(sample) for sample in samples[:16]],
            "time_samples_truncated": len(samples) > 16,
        }
        attributes.append(item)
        if name.startswith("primvars:"):
            primvars.append(item)

    relationships = _usd_relationships(prim)
    material_bindings = [
        relationship for relationship in relationships
        if relationship["name"].startswith("material:binding")
    ]
    return {
        "node": node.path(),
        "path": str(prim.GetPath()),
        "name": str(prim.GetName()),
        "type": str(prim.GetTypeName() or "") or None,
        "active": bool(prim.IsActive()),
        "defined": bool(prim.IsDefined()),
        "loaded": bool(prim.IsLoaded()),
        "instance": bool(prim.IsInstance()),
        "instanceable": bool(prim.IsInstanceable()),
        "kind": prim.GetMetadata("kind"),
        "attributes": attributes,
        "primvars": primvars,
        "relationships": relationships,
        "material_bindings": material_bindings,
        "property_count": len(properties),
        "properties_truncated": len(properties) > max_properties,
    }


# ---------------------------------------------------------------------------
# 通用动词层（node 域 + parm 域）
# 设计见 docs/tool-design.md。铁律：节点参数统一接受 hou.Node 或 path 字符串；
# 返回精简 JSON 安全；只增不改；hou 永远是逃生舱。
# ---------------------------------------------------------------------------

def _resolve(node) -> hou.Node:
    """把 hou.Node 或 path 字符串统一解析成 hou.Node；不存在抛明确错误。"""
    if isinstance(node, hou.Node):
        return node
    if isinstance(node, str):
        n = hou.node(node)
        if n is None:
            raise ValueError(f"no node at path '{node}'")
        return n
    raise ValueError(f"expected a node or path string, got {type(node).__name__}")


def _resolve_in_parent(parent, value) -> hou.Node:
    """A node reference uses an explicit parent, never Houdini's ambient cwd."""
    if isinstance(value, str) and not value.startswith('/'):
        node = parent.node(value)
        if node is None:
            raise ValueError(f"节点不存在：{value!r} relative to {parent.path()}")
        return node
    return _resolve(value)


def _val(v):
    """把 HOM 值转成 JSON 安全（Vector/Matrix/Color → list），其余原样返回。"""
    if isinstance(v, (hou.Vector2, hou.Vector3, hou.Vector4)):
        return [float(x) for x in v]
    if isinstance(v, hou.Color):
        return [float(v.r()), float(v.g()), float(v.b()), float(v.a())]
    if isinstance(v, (hou.Matrix3, hou.Matrix4)):
        return [[float(x) for x in row] for row in v]
    return v


# --- node 域：查 -----------------------------------------------------------

def find_nodes(pattern: str = "*", category=None, node_type=None, root=None) -> list:
    """在场景里找**已存在**的节点，返回扁平 path 列表（按路径排序）。

    - ``pattern``：glob 匹配节点名（``fnmatch``）。
    - ``category``：可选，按节点类别过滤（'sop'/'obj'/...）。
    - ``node_type``：可选，按类型名过滤（基名或全名，不区分大小写）。
    - ``root``：从哪个节点开始搜（默认 '/'）。
    """
    root_node = _resolve(root) if root is not None else hou.node("/")
    cat = _category(category) if category else None
    qtype = node_type.lower() if isinstance(node_type, str) else None

    results = []
    for n in root_node.allSubChildren():
        if pattern and pattern != "*" and not fnmatch.fnmatch(n.name(), pattern):
            continue
        if cat is not None and n.type().category().name() != cat.name():
            continue
        if qtype is not None:
            tname = n.type().name()
            base = tname.split("::", 1)[0]
            if qtype not in (tname.lower(), base.lower()):
                continue
        results.append(n.path())
    results.sort()
    return results


def _neighbors(node: hou.Node, direction: str) -> list:
    # 防御：HOM 文档口径里 inputs() 可能含 None 占位（未连接的输入），
    # 实测 H21/H22 是紧凑元组，但此处不赌版本行为。
    if direction == "up":
        return [n for n in node.inputs() if n is not None]
    if direction == "down":
        return [n for n in node.outputs() if n is not None]
    raise ValueError(f"bad direction {direction!r}")


def _hop_paths(node: hou.Node, direction: str, depth: int) -> list:
    """BFS 收集 depth 跳内的邻接节点 path（不含自身），去重、按 path 排序。"""
    if depth < 1:
        return []
    seen: set[str] = set()
    frontier = [node]
    for _ in range(depth):
        nxt = []
        for x in frontier:
            for nb in _neighbors(x, direction):
                p = nb.path()
                if p not in seen:
                    seen.add(p)
                    nxt.append(nb)
        frontier = nxt
    return sorted(seen)


def graph(node, depth: int = 1, direction: str = "both") -> dict:
    """返回节点的直接依赖关系（默认 1 跳）。

    - ``inputs``：直接上游（数据流输入）。
    - ``outputs``：直接下游（谁把本节点当输入）。
    - ``parm_refs``：通过 ``ch()`` 等表达式引用本节点的节点（`outputs()` 看不到的隐形边）。
    - ``depth``：按需递归（>1 时 BFS）；``direction``：'up'/'down'/'both'。
    """
    n = _resolve(node)
    up = _hop_paths(n, "up", depth) if direction in ("both", "up") else []
    down = _hop_paths(n, "down", depth) if direction in ("both", "down") else []
    refs = sorted(x.path() for x in n.parmsReferencingThis()
                  if x.node() != n and not x.node().path().startswith(n.path() + '/'))
    return {"path": n.path(), "inputs": up, "outputs": down, "parm_refs": refs}


def _geo_summary(geo) -> dict:
    s: dict = {}
    for intrinsic, key in (
        ("pointcount", "points"),
        ("primitivecount", "prims"),
        ("vertexcount", "verts"),
        ("pointattributes", "point_attrs"),
        ("primitiveattributes", "prim_attrs"),
        ("vertexattributes", "vertex_attrs"),
        ("detailattributes", "detail_attrs"),
    ):
        try:
            s[key] = geo.intrinsicValue(intrinsic)
        except Exception:
            s[key] = None
    try:
        bb = geo.boundingBox()
        s["bbox_min"] = [float(x) for x in bb.minvec()]
        s["bbox_max"] = [float(x) for x in bb.maxvec()]
        s["bbox_size"] = [float(x) for x in bb.sizevec()]
    except Exception:
        pass
    return s


def describe(node) -> dict:
    """节点状态 + 几何摘要 + 帮助元数据（Stage 1）——一次拿到「它现在什么状态、流着什么数据」。"""
    n = _resolve(node)
    t = n.type()
    info: dict = {
        "path": n.path(),
        "name": n.name(),
        "type": t.name(),
        "category": t.category().name(),
    }
    info['ports'] = _port_metadata(n)

    # 生命周期状态
    try:
        info["bypassed"] = n.isBypassed()
    except Exception:
        info["bypassed"] = False
    try:
        info["locked_hda"] = n.isLockedHDA()
    except Exception:
        info["locked_hda"] = False
    try:
        info["needs_cook"] = n.needsToCook()
    except Exception:
        info["needs_cook"] = None
    try:
        info["errors"] = list(n.errors())
    except Exception:
        info["errors"] = []
    try:
        info["warnings"] = list(n.warnings())
    except Exception:
        info["warnings"] = []

    # 几何摘要（仅 SOP 有 geometry()）。用类别对象比较而非名字字符串：
    # category().name() 返回 'Sop'（首字母大写），== 'sop' 永不成立——这个
    # 大小写 bug 让 describe 长期静默不返回 geometry（2026-08-19 实证：草地
    # trace 里 agent 在 describe 之后仍手写 bbox/点数循环，就是因为拿不到）。
    if t.category() == hou.sopNodeTypeCategory():
        if hou.updateModeSetting() == hou.updateMode.Manual:
            info['geometry'] = None
            info['geometry_status'] = 'not_evaluated_manual'
            info['update_mode'] = 'manual'
            info['geometry_note'] = 'Metadata only: no geometry evaluation requested in Manual mode; not proof of empty geometry.'
            return info
        geo = None
        try:
            geo = n.geometry()
            info["geometry"] = _geo_summary(geo) if geo is not None else None
        except Exception:
            info["geometry"] = None

        # 属性增量（attrib_delta）：本节点相对 input 0 增/删了哪些属性——
        # MMB 节点信息里美术心算的那一步（「这个节点对数据干了什么」），
        # 固化为动词输出。只对 input 0 做 diff（merge 类多输入节点的语义
        # 是合并，diff 无意义）；只报名称增删，不报值变化（贵且误导）。
        # cook 本节点已拉起上游 cook，两个几何体都在缓存里，代价≈集合运算。
        if geo is not None:
            try:
                inputs = n.inputs()
                up = inputs[0] if inputs else None
                if up is not None and up.type().category() == hou.sopNodeTypeCategory():
                    up_geo = up.geometry()
                    if up_geo is not None:
                        delta: dict[str, Any] = {}
                        for intrinsic, cls in (
                            ("pointattributes", "point"),
                            ("primitiveattributes", "prim"),
                            ("vertexattributes", "vertex"),
                            ("detailattributes", "detail"),
                        ):
                            try:
                                before = set(up_geo.intrinsicValue(intrinsic) or [])
                                after = set(geo.intrinsicValue(intrinsic) or [])
                            except Exception:
                                continue
                            added = sorted(after - before)
                            removed = sorted(before - after)
                            if added:
                                delta.setdefault("added", {})[cls] = added
                            if removed:
                                delta.setdefault("removed", {})[cls] = removed
                        if delta:
                            info["attrib_delta"] = delta
            except Exception:
                pass

    # 帮助元数据（Stage 1：免费元数据，完整帮助见 tool-design.md 三阶段）
    help_meta: dict = {}
    try:
        help_meta["description"] = t.description()
    except Exception:
        help_meta["description"] = None
    try:
        help_meta["default_help_url"] = t.defaultHelpUrl()
    except Exception:
        help_meta["default_help_url"] = None
    try:
        help_meta["embedded_help"] = t.embeddedHelp() or None
    except Exception:
        help_meta["embedded_help"] = None
    info["help"] = help_meta

    return info


# --- node 域：写 -----------------------------------------------------------

def _matrix_values(matrix) -> list[float]:
    return [float(value) for value in matrix.asTuple()]


def set_object_parent(child, parent, keep_world: bool = True, reason: str = "",
                      index: int = 0, allow_foreign: str | None = None) -> dict:
    """显式设置 OBJ parent，参数顺序是 ``child, parent``。

    只表达明确的 OBJ hierarchy 操作，建模/rig 表示由当前任务决定。``reason``
    可记录可选的用途说明，不限制用途。``parent=None`` 表示 unparent；普通父级
    使用 ``index=0``，Blend 等明确多输入对象可指定其他 input。
    ``keep_world=True`` 在改层级后恢复 child 的原世界变换，并回读验证 parent。
    """
    c = _resolve(child)
    p = None if parent is None else _resolve(parent)
    obj_category = hou.objNodeTypeCategory()
    if c.type().category() != obj_category:
        raise ValueError(f"set_object_parent 的 child 必须是 OBJ，收到 {c.path()}")
    if p is not None and p.type().category() != obj_category:
        raise ValueError(f"set_object_parent 的 parent 必须是 OBJ 或 None，收到 {p.path()}")
    reason = str(reason or "").strip()
    if p is not None and int(p.sessionId()) == int(c.sessionId()):
        raise ValueError("对象不能 parent 到自身")
    index = int(index)
    if index < 0 or index >= len(c.inputConnectors()):
        raise ValueError(
            f"input index {index} 超出 {c.path()} 的有效范围 "
            f"0..{len(c.inputConnectors()) - 1}"
        )
    if p is not None:
        pending = [p]
        seen = set()
        while pending:
            cursor = pending.pop()
            sid = int(cursor.sessionId())
            if sid in seen:
                continue
            seen.add(sid)
            if int(cursor.sessionId()) == int(c.sessionId()):
                raise ValueError(
                    f"OBJ parenting 会形成环：{c.path()} <- {p.path()}"
                )
            pending.extend(item for item in cursor.inputs() if item is not None)

    _require_owned(c, "set_object_parent child", allow_foreign)
    previous = c.input(index)
    world_before = c.worldTransform()
    local_before = {
        "t": [float(v) for v in c.parmTuple("t").eval()],
        "r": [float(v) for v in c.parmTuple("r").eval()],
        "s": [float(v) for v in c.parmTuple("s").eval()],
    }
    c.setInput(index, p)
    if bool(keep_world):
        c.setWorldTransform(world_before)
    actual = c.input(index)
    actual_matches = (
        (actual is None and p is None)
        or (actual is not None and p is not None
            and int(actual.sessionId()) == int(p.sessionId()))
    )
    if not actual_matches:
        raise RuntimeError(
            f"OBJ parenting 回读不一致：requested={p.path() if p else None}, "
            f"actual={actual.path() if actual else None}"
        )
    world_after = c.worldTransform()
    before_values = _matrix_values(world_before)
    after_values = _matrix_values(world_after)
    world_delta = max(abs(a - b) for a, b in zip(before_values, after_values))
    return {
        "child": c.path(),
        "parent": p.path() if p is not None else None,
        "previous_parent": previous.path() if previous is not None else None,
        "input": index,
        "reason": reason,
        "keep_world": bool(keep_world),
        "verified": actual_matches,
        "world_transform_preserved": world_delta <= 1e-6 if keep_world else None,
        "world_delta_max": world_delta,
        "local_before": local_before,
        "local_after": {
            "t": [float(v) for v in c.parmTuple("t").eval()],
            "r": [float(v) for v in c.parmTuple("r").eval()],
            "s": [float(v) for v in c.parmTuple("s").eval()],
        },
    }

def _input_state(node):
    connections = node.inputConnections()
    rows = []
    for connection in connections[:128]:
        source = connection.inputNode()
        # A native subnet indirect input is a NetworkMovableItem, not a Node.
        # Preserve that distinction instead of inventing a node or dropping it.
        indirect = connection.subnetIndirectInput() if source is None else None
        rows.append({'input': connection.inputIndex(),
                     'source': source.path() if source is not None else None,
                     'source_kind': 'node' if source is not None else
                                    'subnet_indirect_input' if indirect is not None else 'non_node',
                     'source_output': connection.outputIndex()})
    return {'connections': rows, 'count': len(connections), 'truncated': len(connections) > 128}


def _port_metadata(node):
    """Native connector metadata; no cook, guessing or name-to-role inference."""
    result = {}
    for direction in ('input', 'output'):
        names = tuple(getattr(node, direction + 'Names')())
        labels = tuple(getattr(node, direction + 'Labels')())
        types_method = getattr(node, direction + 'DataTypes', None)
        types = tuple(types_method()) if types_method else ()
        count = max(len(names), len(labels), len(getattr(node, direction + 'Connectors')()))
        result[direction + 's'] = [dict(index=i, name=names[i] if i < len(names) else None,
            label=labels[i] if i < len(labels) else None, data_type=types[i] if i < len(types) else None)
            for i in range(min(count, 128))]
        result[direction + '_count'] = count
        result[direction + '_truncated'] = count > 128
    return result


def _resolve_port(node, selector, direction):
    names = tuple(getattr(node, direction + 'Names')())
    if isinstance(selector, str):
        matches = [i for i, name in enumerate(names) if name == selector]
        if not selector or len(matches) != 1:
            raise ValueError(f'{direction} port name must match exactly once: {selector!r}; available={names[:128]}')
        return matches[0]
    if type(selector) is not int or selector < 0:
        raise ValueError(f'{direction} port must be a nonnegative integer or exact name')
    count = (node.type().maxNumInputs() if direction == 'input'
             else max(len(names), len(node.outputConnectors())))
    if selector >= count:
        raise ValueError(f'{direction} port index {selector} outside 0..{count - 1} on {node.path()}')
    return selector


def connect(src, dst, index: int | str = 0, *, output: int | str = 0, allow_foreign: str | None = None) -> dict:
    """把 ``src`` 的输出连到 ``dst`` 的第 ``index`` 个输入。

    只表达普通网络 dataflow；OBJ→OBJ 是 parenting，明确拒绝并要求
    ``set_object_parent(child, parent)``。
    返回 ``{"node": dst path, "input": 实际落到的输入口, "position_adjusted": bool}``。
    请求的端口不存在或连接失败时明确拒绝，不尝试改接其他端口。
    index 为目标输入名/索引；keyword-only output 为源输出名/索引，默认0保持兼容。
    先解析两端并检查类型，再写入；不按label猜名称、不自动改接；第4位置参数拒绝。
    连接成功后做 flow 纠流（``_snap_into_flow``）：dst 不在所有输入下游时，以输入
    正下方为首选并对节点、Box与注释项做有界避障；已在下游的节点绝不动。若没有
    安全落位，接线保留并以``placement_status='blocked'``报告，不移动dst。
    """
    s = _resolve(src)
    d = _resolve(dst)
    if (s.type().category() == hou.objNodeTypeCategory()
            and d.type().category() == hou.objNodeTypeCategory()):
        raise ValueError(
            "connect 只表达网络数据流，不执行 OBJ parenting。"
            f"当前连线会把 {s.path()} 作为 parent、{d.path()} 作为 child；"
            "请改用 set_object_parent(child, parent, keep_world=True)。"
        )
    _require_owned(d, "connect destination", allow_foreign)
    if s.parent() != d.parent():
        raise ValueError(f'different_parent: source={s.path()} parent={s.parent().path()}, destination={d.path()} parent={d.parent().path()}; use an Object Merge inside the destination SOP network or an explicit subnet input. Changing the input index cannot fix this boundary')
    index = _resolve_port(d, index, 'input')
    output = _resolve_port(s, output, 'output')
    compatible = getattr(d, 'isInputCompatible', None)
    # COP Cache/Null-like ports acquire their signature from the first wire.
    # Native isInputCompatible reports false while they are still 'undef'.
    dynamic_type = (isinstance(d, hou.CopNode) and
                    (index >= len(d.inputDataTypes()) or d.inputDataTypes()[index] == 'undef'))
    # H22 USD Material COP reports incompatible even for native RGB->RGB
    # and Mono->Mono wires that setInput accepts. Keep the exception narrow:
    # concrete, identical image signatures only; no implicit channel coercion.
    material_signature = False
    if (isinstance(s, hou.CopNode) and isinstance(d, hou.CopNode)
            and d.type().nameComponents()[2] == 'usdmaterial'):
        source_types, target_types = s.outputDataTypes(), d.inputDataTypes()
        material_signature = (output < len(source_types) and index < len(target_types)
                              and source_types[output] == target_types[index]
                              and source_types[output] in ('Mono', 'UV', 'RGB', 'RGBA'))
    if compatible is not None and not dynamic_type and not material_signature and not compatible(index, s, output):
        raise ValueError(f'incompatible ports: {s.path()} output {output} -> {d.path()} input {index}; zero connection writes')
    before = _input_state(d)
    try:
        d.setInput(index, s, output)
    except Exception as e:
        raise ValueError(f"连接失败：{s.path()} → {d.path()} input {index}（{e}）；未尝试其他端口") from e
    actual = [c for c in d.inputConnections() if c.inputIndex() == index]
    if len(actual) != 1 or actual[0].inputNode() != s or actual[0].outputIndex() != output:
        raise RuntimeError('connect readback mismatch; transaction must roll back')
    placement = _snap_into_flow(d)
    return {"node": d.path(), "input": index, "source": s.path(), "source_output": output,
            'source_output_name': s.outputNames()[output] if output < len(s.outputNames()) else None,
            'input_name': d.inputNames()[index] if index < len(d.inputNames()) else None,
            'type_check': 'cop_material_exact_signature' if material_signature else 'deferred_dynamic_signature' if dynamic_type else 'native' if compatible else 'native_setInput',
            'verified': True, 'semantic_status': 'unverified', "position_adjusted": placement['adjusted'],
            'placement_status':placement['status'],'placement_blockers':placement['blockers'],
            'inputs_before':before, 'inputs_after':_input_state(d),
            'note':'connect replaces the current occupant; do not disconnect first to replace a Merge input'}


def disconnect_input(dst, index: int = 0, *, allow_foreign: str | None = None) -> dict:
    """断开普通网络 ``dst`` 输入；OBJ unparent 改用 ``set_object_parent``。"""
    d = _resolve(dst)
    if d.type().category() == hou.objNodeTypeCategory():
        raise ValueError(
            "disconnect_input 不执行 OBJ unparent；请用 "
            "set_object_parent(child, None, keep_world=True, reason=...)"
        )
    _require_owned(d, "disconnect_input", allow_foreign)
    index = int(index)
    if index < 0 or index >= len(d.inputConnectors()):
        raise ValueError(f"输入口 {index} 超出 {d.path()} 的有效范围 0..{len(d.inputConnectors()) - 1}")
    previous = d.input(index)
    before = _input_state(d)
    d.setInput(index, None)
    return {
        "node": d.path(),
        "input": index,
        "disconnected": previous.path() if previous is not None else None,
        'inputs_before':before, 'inputs_after':_input_state(d),
        'next_action':'Use inputs_after: variable inputs may shift after disconnect; old indices are no longer reliable.',
    }


def rename_node(node, name: str, allow_foreign: str | None = None) -> str:
    """重命名节点（自动去重），返回新 path。"""
    n = _resolve(node)
    _require_owned(n, "rename_node", allow_foreign)
    n.setName(name, unique_name=True)
    return n.path()


def delete_node(node, allow_foreign: str | None = None) -> dict:
    """删除前检查节点及所有后代权限；持久render_view服务始终受保护。"""
    n = _resolve(node)
    if n.userData(_RENDER_OWNER_KEY) == _RENDER_OWNER_VALUE:
        raise ValueError(
            f"{n.path()} belongs to the persistent dsh-houdini render service; "
            "do not delete it during the Houdini session. render_view reuses "
            "this infrastructure and clears its live source reference after each render."
        )
    _require_owned(n, "delete_node", allow_foreign)
    for child in n.allSubChildren():
        _require_owned(child, "delete_node descendant", allow_foreign)
    from dsh_network_boxes import prepare_parent_deletion, commit_parent_deletion
    box_deletion = prepare_parent_deletion(
        n, active_owner_session=_ACTIVE_OWNER_SESSION,
        allow_foreign=allow_foreign, require_node_owned=_require_owned)
    from dsh_network_notes import prepare_parent_deletion as prepare_note_deletion, commit_parent_deletion as commit_note_deletion
    note_deletion = prepare_note_deletion(
        n, active_owner_session=_ACTIVE_OWNER_SESSION, allow_foreign=allow_foreign)
    refs = sorted(x.path() for x in n.parmsReferencingThis())
    session_ids = [int(n.sessionId())]
    session_ids.extend(int(child.sessionId()) for child in n.allSubChildren())
    consumers = []
    for connection in n.outputConnections():
        consumer = connection.outputNode()
        if consumer is not None:
            consumers.append((consumer, connection.inputIndex(), connection.outputIndex()))
    path = n.path()
    n.destroy()
    commit_parent_deletion(box_deletion)
    commit_note_deletion(note_deletion)
    for session_id in session_ids:
        _OWNED_NODE_SESSIONS.pop(session_id, None)
    result: dict = {"deleted": path}
    result['affected_connections'] = [
        {'destination': consumer.path(), 'input': index, 'deleted_source_output': port,
         'inputs_after': _input_state(consumer)} for consumer, index, port in consumers[:64]]
    result['affected_connections_truncated'] = len(consumers) > 64
    result['next_action'] = 'Deletion may reconnect/bypass native wires. A same-named replacement does not restore them; inspect affected_connections and explicitly reconnect, then retest final-output controls.'
    if refs:
        result["orphaned_parm_refs"] = refs
    return result


def set_update_mode(mode: str, expected_mode: str) -> dict:
    """Explicit global auto/manual/on_mouse_up switch; requires current expected_mode.
    Switching to auto may trigger dirty networks. Never an interrupt or automatic recovery.
    """
    from dsh_cook_control import set_update_mode as change
    return change(mode, expected_mode)


def cook_node(node, force: bool = False, timeout_ms: int = 30000) -> dict:
    """Cook and read health; refresh an existing error once to avoid stale diagnostics."""
    return _cook_node(node, force, timeout_ms)


def _cook_node(node, force=False, timeout_ms=30000, *, preflight=True):
    """Internal cook core; only verify_network's already-checked batch skips DFS."""
    n = _resolve(node)
    if type(timeout_ms) is not int or not 1 <= timeout_ms <= 120000:
        raise ValueError('timeout_ms must be 1..120000; cooperative timeout, not an OOM guarantee')
    mode = hou.updateModeSetting()
    if mode == hou.updateMode.Manual:
        return {'path':n.path(), 'ok':False, 'healthy':False, 'warning_free':True,
                'status':'not_cooked_manual', 'errors':[], 'warnings':[], 'forced':False,
                'update_mode':'manual', 'next_action':'Keep Manual for inspection/editing; explicitly authorize a policy change before evaluation. Missing geometry is not an empty successful output.'}
    if preflight:
        from dsh_cook_control import preflight as check_dependencies
        check_dependencies([n])
    effective_force = bool(force) or bool(n.errors())
    cook_error = None
    try:
        with hou.InterruptableOperation('DSH cook', timeout_ms=timeout_ms) as operation:
            operation.updateProgress(0)
            n.cook(force=effective_force)
            operation.updateProgress(1)
    except Exception as e:  # hou.OperationFailed 等
        cook_error = str(e) or type(e).__name__
    errors = list(n.errors())
    if cook_error and cook_error not in errors:
        errors.insert(0, cook_error)
    warnings = list(n.warnings())
    return {
        "path": n.path(),
        "errors": errors,
        "warnings": warnings,
        "ok": not errors,
        "warning_free": not warnings,
        "healthy": not errors and not warnings,
        "forced": effective_force,
        'timeout_ms':timeout_ms, 'interrupt_scope':'cooperative native checkpoints only; cannot guarantee immediate interruption or memory safety',
    }


def verify_network(parent, output=None, nodes=None, limit: int = 512, require_valid: bool = True,
                   *, output_index: int | None = None) -> dict:
    """SOP network cook/geometry checkpoint, including upstream warning nodes.

    Checks direct children by default; optional nodes limits scope explicitly.
    Explicit output is always required; no display fallback. Empty/error output
    raises CheckpointError by default; require_valid=False is diagnostic only.
    No viewport changes. output_index=0..63 additionally requires the matching
    native Output to be this source or directly wired to it. Packed wrapper
    counts alone do not prove nonempty embedded content.
    Parent-relative references and absolute paths use the same explicit parent.
    Healthy still means cook/output
    health, not correct shape, relationship or visual finish.
    healthy != task/visual success; relationships remain unverified.
    """
    from dsh_sop_contracts import verify_network as verify
    return verify(parent, output=output, nodes=nodes, limit=limit, require_valid=require_valid,
                  output_index=output_index)


def modeling_dimensions(quantities, require_meter_scene=True) -> dict:
    """Read-only typed source quantities -> meter/area/volume values and CTRL spec.

    quantities={name:{value:number,unit:m|cm|mm|um|in|ft|m2|cm2|mm2|m3|cm3|mm3|deg|rad|count|ratio,
    min?:number,max?:number,source?:string}}. Requires actual HIP unit length 1m
    by default. Existing nonmeter scenes need explicit False and scene_values
    adaptation; never changes HIP settings. Counts/angles are not length-scaled.
    Example: modeling_dimensions({'length':{'value':120,'unit':'mm'}})
    returns canonical_values['length']=0.12. Use converted values in construction.
    Source meanings and final physical dimensions remain separately verified.
    """
    from dsh_modeling_units import modeling_dimensions as convert
    return convert(quantities,require_meter_scene)


def sop_recipe(kind, spec=None) -> dict:
    """Read-only ordinary SOP specs; kind=catalog/hinge/slider/guided_slider/surface_attach/gusset/fastener/repeat/sweep_tube/profile_shell.

    Read catalog or sop_recipe(kind) for examples of every recipe. guided_slider bounds
    travel against actual polygon source/guide projections. surface_attach projects
    a source Y=0 foot to a named receiver surface; complete-foot contact remains
    separately verified. gusset/fastener generate editable local detail sources.
    Inputs are direct source children; one
    named CTRL supplies parameter references and shared frame origin. Returns
    nodes/output/required_outputs for build_module, never creates/cooks nodes.
    Hinge uses degrees about a normalized axis and a source-local origin pivot;
    slider translates along axis; repeat uses integer count 1..256 and spacing.
    Numeric origin/dimensions or {parm:name} reference one shared controller.
    No automatic interfaces, world-space conversion, HDA, ownership or acceptance.
    """
    from dsh_procedural_plans import sop_recipe as plan
    return plan(kind, spec)


def control_test_plan(controller, parameters, max_cases=16, domain=None) -> dict:
    """Read scalar current values and plan <=16 pairwise representative cases.

    parameters={scalar:[2..8 explicit boundary/intermediate levels]}, <=8 controls,
    <=4096 candidate combinations. domain uses test_controls scalar constraints.
    No writes/cook. Returned tests contain EMPTY expectations: author must add
    independent response/invariant measurements and state-specific interfaces.
    Coverage reports exact uncovered requested levels/pairs, never a full-domain
    proof. Run accepted cases with test_controls; no auto-pass or silent clamping.
    """
    from dsh_procedural_plans import control_test_plan as plan
    return plan(controller, parameters, max_cases, domain)


def build_module(parent, nodes: list, output: str, dry_run: bool = False, interfaces=None, *, required_outputs=None) -> dict:
    """Build NEW SOP nodes from a nonempty {name,type,parms?,inputs?} spec list.

    Inputs name any declared spec or existing direct child; declaration order is
    free. All nodes exist before wiring and parameter expressions. None retains an empty input.
    For secondary Wrangle lookup use inputs=[None, 'source']. No overwrite or flags.
    dry_run is static preflight (no scratch node); VEX/cook not yet verified.
    Failed creation/parameters/cook removes only this batch's new nodes.
    Output must contain geometry. Create empty controllers/helpers with tab_create.
    Returned validation reports warnings separately from errors and semantics.
    Optional interfaces are final-output point-group → primitive-group proximity
    contracts, checked after construction; failing/unverified contracts fail the
    module and clean its new nodes. See geo_check_interfaces for exact schema.
    required_outputs=[new_node_name,...] optionally requires nonempty module
    branches, so a healthy merge cannot hide missing deliverable pieces. Empty
    helpers remain allowed when not declared required. Independent static field
    errors are returned together before creation; retain parameter components.
    Query node_info for operation knowledge when needed; construction returns
    execution and output facts without inferring unresolved design choices.
    """
    from dsh_sop_contracts import build_module as build
    return build(parent, nodes, output=output, dry_run=dry_run, interfaces=interfaces, required_outputs=required_outputs)


def sop_set_output(node, render: bool = True,
                   allow_foreign: str | None = None, *, output_index: int | None = None) -> dict:
    """把 SOP display（默认连同 render）旗标移到指定输出节点。

    这是用户 viewport/交付状态，不是 ``render_view`` 的前置条件；agent 的
    离屏验证会从显式 SOP 建 proxy，不依赖这里的旗标。
    output_index=None只切旗标；显式0..63在同一父网络复用/创建并接线原生Output，
    普通geo交付保持None，无需Output节点；subnet/HDA公共交付才指定索引。
    固定容器公共出口，再把旗标设到该Output。逐层发布，不猜祖先输出。
    不cook、不保存定义；用verify_network(parent,output=源SOP,output_index=同索引)
    另验接线和几何。公共出口、显示和HDA新实例验收是不同层。
    """
    n = _resolve(node)
    _require_owned(n, "sop_set_output", allow_foreign)
    if n.type().category() != hou.sopNodeTypeCategory():
        raise ValueError(
            f"sop_set_output 只接受 SOP，收到 {n.path()} "
            f"({n.type().category().name()})；OBJ 可见性请用 set_object_visible"
        )
    if not isinstance(render, bool):
        raise ValueError('render must be bool')
    source = n
    published = None
    if output_index is not None:
        from dsh_sop_contracts import publish_output
        published = publish_output(n, output_index, allow_foreign)
        n = _resolve(published['node'])
    n.setDisplayFlag(True)
    if render:
        n.setRenderFlag(True)
    return {'context': 'sop', 'node': n.path(), 'display': True, 'render': render,
            'source': source.path(), 'public_output': published}


def sop_output_node(parent) -> dict:
    """报告 SOP 网络的 singular display/render 输出节点。"""
    p = _resolve(parent)
    try:
        child_category = p.childTypeCategory()
    except Exception:
        child_category = None
    if child_category != hou.sopNodeTypeCategory():
        raise ValueError(
            f"sop_output_node 需要包含 SOP 的父网络，收到 {p.path()}；"
            "OBJ 层是 plural visibility，请用 visible_objects('/obj')"
        )

    def _flag(name):
        try:
            return getattr(p, name)()
        except Exception:
            return None

    d = _flag("displayNode")
    r = _flag("renderNode")
    result: dict = {
        "context": "sop",
        "parent": p.path(),
        "display": d.path() if d is not None else None,
        "render": r.path() if r is not None else None,
    }
    if d is not None:
        downstream = [o.path() for o in d.outputs()]
        result["is_leaf"] = not downstream
        if downstream:
            result["note"] = (
                f"display 旗标不在链尾，下游 {len(downstream)} 个节点 "
                f"({', '.join(downstream[:5])}) 不会显示/渲染；"
                "如需以链尾为输出，用 sop_set_output 把旗标移过去"
            )
    return result


def set_object_visible(node, visible: bool = True,
                       allow_foreign: str | None = None) -> dict:
    """设置单个 OBJ 的 viewport 可见性；OBJ 没有 SOP 式 render flag。"""
    n = _resolve(node)
    _require_owned(n, "set_object_visible", allow_foreign)
    if n.type().category() != hou.objNodeTypeCategory():
        raise ValueError(
            f"set_object_visible 只接受 OBJ，收到 {n.path()} "
            f"({n.type().category().name()})；SOP 输出请用 sop_set_output"
        )
    n.setDisplayFlag(bool(visible))
    effective = None
    try:
        effective = bool(n.isObjectDisplayed())
    except Exception:
        pass
    return {
        "context": "obj",
        "node": n.path(),
        "visible": bool(n.isDisplayFlagSet()),
        "effective_visible": effective,
    }


def visible_objects(root="/obj") -> dict:
    """列出 OBJ 层所有对象的 plural visibility 状态。"""
    p = _resolve(root)
    try:
        child_category = p.childTypeCategory()
    except Exception:
        child_category = None
    if child_category != hou.objNodeTypeCategory():
        raise ValueError(
            f"visible_objects 需要 OBJ manager（通常 /obj），收到 {p.path()}"
        )
    objects = []
    for child in p.children():
        try:
            visible = bool(child.isDisplayFlagSet())
        except Exception:
            continue
        try:
            effective = bool(child.isObjectDisplayed())
        except Exception:
            effective = None
        objects.append({
            "path": child.path(),
            "type": child.type().name(),
            "visible": visible,
            "effective_visible": effective,
            "agent_owned": child.userData(_RENDER_OWNER_KEY) == _RENDER_OWNER_VALUE,
            "provenance": node_provenance(child)["status"],
        })
    return {"context": "obj", "root": p.path(), "objects": objects}


def _layout_flow(items, horizontal_spacing: float, vertical_spacing: float) -> None:
    """flow 布局：按最长路径深度分行（深度 0 最上），同深度按当前 x 排序保持
    左右阅读顺序、等距排开并整体居中。有环时环上边按 0 深度贡献兜底，不断裂。"""
    item_ids = {int(n.sessionId()) for n in items}
    depth: dict[int, int] = {}

    def visit(node, visiting: set) -> int:
        sid = int(node.sessionId())
        if sid in depth:
            return depth[sid]
        if sid in visiting:  # 环：按 0 贡献兜底
            return 0
        visiting.add(sid)
        ups = [i for i in node.inputs() if i is not None and int(i.sessionId()) in item_ids]
        d = 0 if not ups else 1 + max(visit(i, visiting) for i in ups)
        visiting.discard(sid)
        depth[sid] = d
        return d

    for n in items:
        visit(n, set())

    h_gap, v_gap = _flow_gaps(items)
    h_pitch = float(horizontal_spacing) if horizontal_spacing > 0 else h_gap
    v_pitch = float(vertical_spacing) if vertical_spacing > 0 else v_gap

    rows: dict[int, list] = {}
    for n in items:
        rows.setdefault(depth[int(n.sessionId())], []).append(n)
    for d, row in rows.items():
        row.sort(key=lambda n: (float(n.position().x()), n.path()))
        for i, n in enumerate(row):
            x = (i - (len(row) - 1) / 2.0) * h_pitch
            n.setPosition(hou.Vector2(x, -d * v_pitch))


def layout_nodes(parent, nodes=None, horizontal_spacing: float = -1.0,
                 vertical_spacing: float = -1.0,
                 allow_foreign: str | None = None,
                 mode: str = "children", *, boxes=None,
                 profile: str = "comfortable", dry_run: bool = False,
                 expected_plan=None) -> dict:
    """布局全部或显式指定的网络项。

    ``mode='children'``（默认）= 原生 layoutChildren，行为不变；
    ``mode='flow'`` = 自研拓扑分层（``_layout_flow``）：深度 0 最上、
    y = −depth × 垂直间距，同深度按当前 x 排序居中，环上边兜底不断裂。
    ownership 过滤与 ``foreign_nodes_skipped`` 语义两种模式一致。
    ``mode='handoff'`` = 对显式叶子Network Box排布；comfortable保留宽松分层，
    readable让连续主输入链竖直对齐、侧支分列，并把声明的控制/检查区分开。
    ``mode='component'`` = 对显式一层组件容器布局，整体移动其叶子框及节点。
    两者可直接应用；dry_run和expected_plan供需要预览/确认状态的调用使用。
    其他网络项全部作为固定障碍。
    """
    if mode not in ("children", "flow", "handoff", "component"):
        raise ValueError(f"mode 必须是 'children'、'flow'、'handoff' 或 'component'，收到 {mode!r}")
    p = _resolve(parent)
    if mode in ('handoff','component'):
        if nodes is not None:raise ValueError(f'{mode} mode derives items from boxes; nodes must be None')
        if boxes is None:raise ValueError(f'{mode} mode requires explicit boxes')
        if horizontal_spacing!=-1.0 or vertical_spacing!=-1.0:
            raise ValueError(f'{mode} mode uses profile clearances, not children/flow spacing')
        from dsh_network_boxes import NetworkBoxOperationError,apply_component_layout,apply_handoff_layout
        try:
            operation=apply_handoff_layout if mode=='handoff' else apply_component_layout
            return operation(p,boxes,profile=profile,dry_run=dry_run,
                expected_plan=expected_plan,active_owner_session=_ACTIVE_OWNER_SESSION,
                node_provenance=node_provenance,allow_foreign=allow_foreign,
                require_node_owned=_require_owned)
        except NetworkBoxOperationError as error:
            raise CheckpointError(str(error),error.evidence) from error
    if boxes is not None or profile!='comfortable' or dry_run is not False or expected_plan is not None:
        raise ValueError('boxes/profile/dry_run/expected_plan are handoff-only arguments')
    if nodes is None and any(any(isinstance(item, hou.Node) for item in box.items(recurse=True))
                             for box in p.networkBoxes()):
        raise ValueError("layout_nodes broad children/flow would scatter Network Box members; "
                         "use mode='handoff' with explicit leaf boxes, "
                         "or pass an explicit node subset for a local edit")
    items = []
    foreign_skipped = []
    if nodes is not None:
        if not isinstance(nodes, (list, tuple)):
            raise ValueError("nodes 必须是 Node/path 列表或 None（None = 全部子项）")
        for item in nodes:
            n = _resolve_in_parent(p, item)
            if n.parent() != p:
                raise ValueError(f"节点 {n.path()} 不属于父网络 {p.path()}")
            _require_owned(n, "layout_nodes", allow_foreign)
            items.append(n)
    elif _ACTIVE_OWNER_SESSION is not None:
        for child in p.children():
            if node_provenance(child)["status"] == "owned_current_session":
                items.append(child)
            else:
                foreign_skipped.append(child.path())
    else:
        items = list(p.children())
    if items:
        from dsh_network_boxes import journal_containing_boxes
        journal_containing_boxes(items, 'layout_nodes_before')
        if mode == "children":
            p.layoutChildren(
                items=tuple(items),
                horizontal_spacing=float(horizontal_spacing),
                vertical_spacing=float(vertical_spacing),
            )
        else:
            _layout_flow(items, horizontal_spacing, vertical_spacing)
    return {
        "parent": p.path(),
        "mode": mode,
        "nodes": [
            {"path": n.path(), "position": [float(v) for v in n.position()]}
            for n in items
        ],
        "foreign_nodes_skipped": foreign_skipped,
    }


def network_boxes(parent, groups, *, remove=None, dry_run=False,
                  expected_plan=None, allow_foreign=None) -> dict:
    """Create/update/remove Network Boxes without moving or cooking nodes.

    groups=[{name, members?: [Node|absolute|parent-relative path], boxes?: [name],
    label?: string, role?: string, color?: [r,g,b]}]. members and boxes may coexist;
    child boxes may be existing or declared anywhere in this batch. Cycles fail
    before creation. role is a color hint, never a component/leaf restriction.
    Labels default to names; unknown roles use neutral colors. dry_run previews
    without writes; expected_plan optionally requires that preview to remain
    current. By default the call directly applies. Membership and appearance
    are presentation facts, not geometry or task-quality evidence.
    """
    try:
        p = _resolve(parent)
    except (ValueError, TypeError) as error:
        raise CheckpointError(str(error), {
            'ok':False,'dry_run':bool(dry_run) if type(dry_run) is bool else None,
            'applied':False,'phase':'preflight','scene_writes':0,
            'parent':str(parent),'restored':True,'restore_errors':[],
            'layout_status':'not_performed','scope':'Network Box parent resolution; zero scene writes'}) from error
    from dsh_network_boxes import NetworkBoxOperationError, apply_network_boxes
    try:
        return apply_network_boxes(
            p, groups, remove=remove, dry_run=dry_run,
            expected_plan=expected_plan, allow_foreign=allow_foreign,
            active_owner_session=_ACTIVE_OWNER_SESSION,
            active_owner_call=_ACTIVE_OWNER_CALL,
            resolve_node=lambda value: _resolve_in_parent(p, value), require_node_owned=_require_owned)
    except NetworkBoxOperationError as error:
        raise CheckpointError(str(error), error.evidence) from error


def network_notes(parent, notes=None, *, remove=None, allow_foreign=None) -> dict:
    """Read or locally maintain named Sticky Notes without changing nodes.

    With no notes/remove, return actual text/position/size/color/provenance.
    notes=[{name,text,position?:[x,y],size?:[w,h],color?:[r,g,b]}] upserts only
    explicit notes. New notes default beside existing network content. remove
    names are explicit; a name or owned parent never grants note ownership.
    Notes remain standalone fixed layout obstacles, not implicit Box members.
    """
    from dsh_network_notes import apply_network_notes
    return apply_network_notes(_resolve(parent), notes, remove=remove,
        active_owner_session=_ACTIVE_OWNER_SESSION, active_owner_call=_ACTIVE_OWNER_CALL,
        allow_foreign=allow_foreign)


# --- parm 域 ---------------------------------------------------------------

def _menu_entries(tpl, tokens, labels):
    """One setting-value contract for static cards and live setters."""
    numeric = tpl.type() == hou.parmTemplateType.Int
    try: use_tokens = bool(tpl.menuUseToken())
    except (AttributeError, hou.Error): use_tokens = False
    rows = []
    for i, token in enumerate(tokens):
        value = i if numeric else token
        if numeric and use_tokens:
            try: value = int(token)
            except ValueError:
                raise ValueError('integer token-valued menu contains noninteger tokens; use an explicit expression')
        rows.append({'index':i, 'token':token, 'label':labels[i] if i < len(labels) else token, 'set_value':value})
    return rows


def _menu_setting(entries, value):
    if isinstance(value, str):
        for item in entries:
            if item['token'] == value: return item['set_value']
    elif type(value) is int:
        # Native ordered menus also accept indices; Int menus expose storage values.
        for item in entries:
            if value == item['set_value'] or (isinstance(item['set_value'], str) and value == item['index']):
                return item['set_value']
    raise ValueError(f'invalid menu value {value!r}; use a menu token/set_value from node_info or list_parms; expressions require {{expression,language}}')


def _parm_template_card(tpl) -> dict:
    entry = {"name": tpl.name(), "label": tpl.label(), "type": tpl.type().name(),
             "size": tpl.numComponents()}
    if tpl.numComponents() == 1:
        entry["components"] = [tpl.name()]
    else:
        scheme = tpl.namingScheme().name()
        entry['naming_scheme'] = scheme
        suffixes = {"XYZW": "xyzw", "RGBA": "rgba", "UVW": "uvw", "XYWH": "xywh",
                    "MinMax": ("min", "max"), "MaxMin": ("max", "min"),
                    "StartEnd": ("start", "end")}.get(scheme)
        if suffixes:
            entry["components"] = [tpl.name() + s for s in suffixes[:tpl.numComponents()]]
        elif scheme == "BeginEnd":
            # Built-in H21/H22 tuples use prefixes (beginangle/endangle),
            # unlike the suffix-based StartEnd scheme. No scratch node needed.
            entry["components"] = [s + tpl.name() for s in ("begin", "end")[:tpl.numComponents()]]
        elif scheme in ("Base0", "Base1"):
            start = 0 if scheme == "Base0" else 1
            entry["components"] = [tpl.name() + str(i + start) for i in range(tpl.numComponents())]
    for field, method in (("help", "help"), ("default", "defaultValue")):
        try:
            value = getattr(tpl, method)()
            if value is not None:
                entry[field] = _val(value)
        except (AttributeError, hou.Error):
            pass
    try:
        tokens, labels = tpl.menuItems(), tpl.menuLabels()
        if tokens:
            entry["menu"] = _menu_entries(tpl, tokens, labels)
            entry['menu_setting'] = 'token_or_set_value; explicit expression object for numeric menu expressions'
        elif tpl.itemGeneratorScript():
            entry["menu_dynamic"] = True
    except (AttributeError, hou.Error):
        pass
    return entry


def _node_parameter_cards(typ, counts=None):
    """Expand bounded static multiparm instances without creating scratch nodes."""
    counts = counts or {}
    cards = []
    def expand(name, indices):
        for i in indices:
            name = name.replace('#', str(i), 1)
        return name
    def visit(templates, indices=(), parents=()):
        for tpl in templates:
            name = expand(tpl.name(), indices)
            if isinstance(tpl, hou.FolderParmTemplate):
                if tpl.folderType() in (hou.folderType.MultiparmBlock, hou.folderType.ScrollingMultiparmBlock, hou.folderType.TabbedMultiparmBlock):
                    count = counts.get(name, tpl.defaultValue())
                    if type(count) is not int or not 0 <= count <= 64:
                        raise ValueError(f'{name}: static multiparm count must be an integer in 0..64; use tab_create/list_parms for dynamic counts')
                    cards.append({'name':name,'label':tpl.label(),'type':'Folder','size':1,'components':[name],
                                  'default':tpl.defaultValue(),'multiparm_count':True,'multiparm_parents':list(parents)})
                    start = int(tpl.tags().get('multistartoffset', '1'))
                    for i in range(start, start + count):
                        visit(tpl.parmTemplates(), indices + (i,), parents + (name,))
                else:
                    visit(tpl.parmTemplates(), indices, parents)
            else:
                card = _parm_template_card(tpl)
                card['name'] = name
                card['components'] = [expand(c, indices) for c in card.get('components', [])]
                if parents:
                    card['multiparm_parents'] = list(parents)
                cards.append(card)
            if len(cards) > 2048:
                raise ValueError('static parameter expansion exceeds 2048 entries; use primitive verbs')
    visit(typ.parmTemplates())
    return cards


def _node_type_suggestions(category, requested):
    """Suggest registered visible types by name/label, without resolving aliases."""
    query = _VERSION_RE.sub(r'\1', requested).lower()
    candidates = []
    for name, typ in category.nodeTypes().items():
        if not _visible_node_type(typ):
            continue
        family = _VERSION_RE.sub(r'\1', name).lower()
        label = (typ.description() or name).lower()
        score = max(difflib.SequenceMatcher(None, query, family).ratio(),
                    difflib.SequenceMatcher(None, query, label).ratio())
        if query == family or query in family or query in label:
            score = max(score, 0.9)
        if score >= 0.85:
            version = _VERSION_RE.match(name)
            candidates.append((score, _version_key(version.group(2)) if version else (),
                               family, name, typ.description() or name))
    # One visible version per family, keeping the newest registered candidate.
    result, seen = [], set()
    for _, _, family, name, label in sorted(candidates, reverse=True):
        if family not in seen:
            result.append({'type': name, 'label': label})
            seen.add(family)
        if len(result) == 6:
            break
    return result


def node_info(parent, type_name: str, parm_filter: str = "", limit: int = 24) -> dict:
    """Read a static version-resolved node card in an existing network (no scratch nodes).

    parm_filter is a literal case-insensitive substring, NOT regex or glob.
    An empty match is not an empty type: retry with parm_filter=''.
    Static templates include menu tokens/labels/defaults. Dynamic menus require
    ``list_parms`` on an actual node; this card does not run shelf scripts.
    operation_parameters additionally carries unfiltered critical settings and
    operation_card.decisions; retain these even when filtering other parameters.
    ``parent`` supplies an existing creation network, not a guessed category.
    requested_type preserves your input; type is the exact resolved node type.
    Unknown types report nearby registered visible types; no alias is created.
    SOP example: ``node_info(existing_geo, "box")``. With no SOP container,
    first create one via ``tab_create("/obj", "geo", name=...)`` in exec;
    querying ``node_info("/obj", "box")`` cannot discover an SOP Box.
    """
    if isinstance(parent, str) and not parent.startswith('/'):
        raise ValueError('node_info(parent,type): parent must be an existing absolute network path, not a category; create the geometry container with tab_create("/obj","geo",name) first')
    p = _resolve(parent)
    if not p.isNetwork() or p.childTypeCategory() is None:
        raise ValueError(f'node_info parent={p.path()!r} is not a network that can create nodes; use its existing creation network {p.parent().path()!r}')
    if not isinstance(type_name, str) or not type_name.strip():
        raise ValueError('type_name must be a non-empty registered type name; e.g. node_info(existing_geo, "box")')
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 256:
        raise ValueError("limit 必须在 1..256")
    cat = p.childTypeCategory()
    try:
        latest = resolve_latest_type(cat, type_name)
    except ValueError as error:
        candidates = _node_type_suggestions(cat, type_name)
        raise ValueError(
            f'Unknown node type {type_name!r}; existing parent={p.path()!r} creates {cat.name()} nodes. '
            f'Registered visible name/label suggestions (not replacements): {candidates}. '
            f'Use search_tab_entries({p.path()!r}, query="part of a type name or label") to discover this context. '
            'For SOP nodes the parent must be an existing geometry network, not /obj.'
        ) from error
    typ = hou.nodeType(cat, latest)
    if typ is None:
        raise ValueError(f"未知节点类型：{type_name}; parent={p.path()} creates {cat.name()} nodes. For SOP types use an existing geometry container, not /obj; search_tab_entries(parent,query) lists valid types.")
    if not isinstance(parm_filter, str):
        raise ValueError('parm_filter must be a literal substring string')
    all_parameters = _node_parameter_cards(typ)
    from dsh_operation_cards import operation_card, operation_metadata, operation_parameters
    operation = operation_card(latest)
    important, missing = operation_parameters(operation, all_parameters) if operation else ([], [])
    parameters = [c for c in all_parameters if not parm_filter or parm_filter.lower() in (c['name'] + ' ' + c['label']).lower()]
    return {"parent": p.path(), "requested_type": type_name, "type": latest, "category": cat.name(),
            **({'usage_notes': operation['notes'], 'operation_card': operation_metadata(operation),
                'operation_parameters': important, 'operation_parameters_missing': missing,
                'operation_parameter_scope': 'Unfiltered critical static templates; defaults are not Shelf-created values. Missing fields require runtime inspection, not guessed replacements.'} if operation else {}),
            "version": hou.applicationVersionString(), "description": typ.description(),
            "visible": _visible_node_type(typ), "min_inputs": typ.minNumInputs(),
            "max_inputs": typ.maxNumInputs(), "max_outputs": typ.maxNumOutputs(),
            "parameters": parameters[:limit], "parameter_count": len(parameters),
            "total_parameter_count": len(all_parameters), "filter_mode": "literal_substring",
            "filter": parm_filter,
            **({'next_action': "No literal matches; retry node_info with parm_filter='' before creating a probe. Pipe/glob/regex syntax is not interpreted."} if parm_filter and not parameters else {}),
            "truncated": len(parameters) > limit, "help_url": typ.defaultHelpUrl(),
            "note": "Static type contract; dynamic menus and shelf initialization may add parameters."}


def network_controls(parent, controls=None, *, remove=None,
                     allow_foreign: str | None = None) -> dict:
    """Declare or list the actual user control entry nodes in a network.

    controls=[{'node':'CTRL_ENGINEERING','label':'Engineering controls'}] explicitly
    marks explicit nodes inside parent with a label saved in their HIP userData.
    remove is an explicit node/path list. Neither names nor spare parms imply a role.
    Omit controls/remove to list declared entries recursively without cooking.
    Declarations only aid navigation; they prove no bindings or model correctness.
    present_nodes publishes these entries as clickable node delivery cards.
    """
    from dsh_network_navigation import declare_controls, list_controls
    p = _resolve(parent)
    if controls is None and remove is None:
        return {'parent': p.path(), 'controls': list_controls(p), 'scene_writes': 0}
    return declare_controls(p, controls if controls is not None else [],
                            remove if remove is not None else [],
                            require_owned=_require_owned, allow_foreign=allow_foreign)


def present_nodes(nodes, *, allow_foreign: str | None = None) -> dict:
    """Declare clickable node entries for delivery alongside DSH's file cards.

    nodes=[{'node':'/obj/asset/CTRL','label':'Engineering controls','role':'control',
            'description':'Adjust dimensions and repetition'},
           {'node':'/obj/asset/OUT','label':'Model output','role':'output'}].
    Saves a persistent reference ID on explicit nodes when absent; ownership applies.
    Save the named HIP after first declaration so cards survive reopening it.
    role is navigation intent, never control/geometry certification. new_identity=True
    is for explicitly renewing a copied entry and invalidates its previous ID.
    The successful verb receipt publishes cards independently of __result__ wrapping.
    Failed batches do not publish cards; the returned value remains inspectable.
    """
    from dsh_network_navigation import present_nodes as present
    return present(nodes, require_owned=_require_owned, allow_foreign=allow_foreign)


def focus_node(reference, *, expected_hip: str) -> dict:
    """Explicit UI navigation by a delivered persistent ID in the expected HIP.

    Used by node delivery clicks through the main-thread queue. Expands containing
    boxes, locates the actual node and opens parameters; no geometry/parameter
    edits or HIP load/save. Renames and same-HIP reopen keep the entry valid;
    missing or duplicated IDs and a different HIP are reported without guessing.
    """
    from dsh_network_navigation import focus_reference
    return focus_reference(reference, expected_hip=expected_hip)


def list_parms(node) -> list:
    """参数**目录**：名字/标签/类型/帮助，不给值（导航用，回答「想改的参数叫什么」）。"""
    n = _resolve(node)
    out = []
    for pt in n.parmTuples():
        entry: dict = {"name": pt.name()}
        entry['components'] = [p.name() for p in pt]
        entry['locked_components'] = [p.name() for p in pt if p.isLocked()]
        tpl = pt.parmTemplate()
        if tpl is not None:
            try:
                entry["label"] = tpl.label()
            except Exception:
                entry["label"] = None
            try:
                entry["type"] = tpl.type().name()
            except Exception:
                entry["type"] = None
            try:
                entry["size"] = tpl.numComponents()
            except Exception:
                try:
                    entry["size"] = len(pt)
                except Exception:
                    pass
            for field, getter in (("help", "help"), ("description", "description")):
                try:
                    v = getattr(tpl, getter)()
                    if v:
                        entry[field] = v
                except Exception:
                    pass
            try:
                card = _parm_template_card(tpl)
                entry.update({k: v for k, v in card.items() if k in ("menu", "menu_dynamic", "default")})
                if len(pt) == 1:
                    tokens, labels = pt[0].menuItems(), pt[0].menuLabels()
                    if tokens:
                        entry["menu"] = _menu_entries(tpl, tokens, labels)
            except (AttributeError, hou.Error):
                pass
        else:
            entry["label"] = None
        out.append(entry)
    return out


def read_parms(node, changed_only: bool = True, *, names: list | None = None) -> list:
    """参数值：默认保留非默认值、表达式、引用、关键帧或时间依赖的参数。

    带表达式的参数会顺带解析引用目标（``referenced_parm``），被其他参数引用的
    参数会标 ``referenced_by``——两个方向的依赖对 agent 判断「动谁会波及谁」都需要。
    返回 ``list[dict]``，每项至少有 ``name/value``；不是 name→value 字典。
    Ramp value为{type:'ramp',basis:[名称],keys:[位置],values:[标量或RGB数组]}，
    可直接json.dumps；仅当前求值控制点，不证明动画恢复，也不是setter输入格式。
    changed_only必须为bool；选择名称用read_parms(node, names=['radius', 'scale'])。
    names可显式选1..32个唯一标量或tuple参数，按请求顺序返回且不受changed_only过滤；
    tuple返回聚合value和带完整诊断的components；缺失字段报错。
    无动画的string含原始UTF-8源码source_sha256；求值不同于原文时另含raw_value。
    """
    if type(changed_only) is not bool:
        raise ValueError("changed_only must be boolean; select parameters with read_parms(node, names=['radius', 'scale'])")
    n = _resolve(node)
    out = []
    requested = None
    if names is not None:
        if (not isinstance(names, list) or not 1 <= len(names) <= 32
                or any(not isinstance(name, str) or not name for name in names) or len(set(names)) != len(names)):
            raise ValueError('names must contain 1..32 unique scalar/tuple parameter names')
        requested = []
        missing = []
        parameters = []
        seen = set()
        for name in names:
            scalar = n.parm(name)
            if scalar is not None:
                group = ('scalar', name, (scalar,))
            else:
                parm_tuple = n.parmTuple(name)
                if parm_tuple is None:
                    missing.append(name)
                    continue
                group = ('tuple', name, tuple(parm_tuple))
            requested.append(group)
            for parm in group[2]:
                if parm.name() not in seen:
                    seen.add(parm.name())
                    parameters.append(parm)
        if missing:
            raise ValueError(f'missing scalar/tuple parameter names: {missing}; use list_parms for the current interface')
    else:
        parameters = n.parms()
    for p in parameters:
        # hou.Parm 没有 hasExpression()（H21/H22 均无；静默 try/except 曾让表达式
        # 维度整个失效）。正确判定：expression() 在无表达式时抛 OperationFailed。
        try:
            expr = p.expression()
            has_expr = True
        except Exception:
            expr = None
            has_expr = False
        try:
            # hou.Parm 也没有 isReferencedBy()；引用自省用 parmsReferencingThis()。
            is_ref = bool(p.parmsReferencingThis())
        except Exception:
            is_ref = False
        try:
            keys = list(p.keyframes())
        except Exception:
            keys = []
        try:
            time_dependent = bool(p.isTimeDependent())
        except Exception:
            time_dependent = False
        tpl = p.parmTemplate()
        if (names is None and changed_only and not has_expr and not is_ref
                and not keys and not time_dependent):
            # A ramp's ordinary default query only covers its multiparm count;
            # the dedicated API compares its actual knots and values.
            is_default = (p.isAtRampDefault() if tpl is not None and tpl.type() == hou.parmTemplateType.Ramp
                          else p.isAtDefault())
            if is_default:
                continue
        entry: dict = {"name": p.name()}
        if tpl is not None:
            try:
                entry["label"] = tpl.label()
            except Exception:
                entry["label"] = None
        previous_errors=tuple(str(e) for e in n.errors()) if has_expr else ()
        try:
            value = p.eval()
            if isinstance(value, hou.Ramp):
                entry['value'] = {'type': 'ramp', 'basis': [str(b).rsplit('.', 1)[-1] for b in value.basis()],
                                  'keys': [float(k) for k in value.keys()],
                                  'values': [[float(v.r()),float(v.g()),float(v.b())] if isinstance(v,hou.Color)
                                             else _val(v) for v in value.values()]}
                entry['value_scope'] = 'evaluated ramp knots only; not animation, callbacks or a setter payload'
            else:
                entry["value"] = _val(value)
        except Exception:
            try:
                entry["value"] = p.evalAsString()
            except Exception:
                entry["value"] = None
        if has_expr:
            entry["expression"] = expr
            try:
                language='python' if p.expressionLanguage()==hou.exprLanguage.Python else 'hscript'
                entry['language']=language
                entry['evaluation']=_expression_evaluation(p,entry.get('value'),language,previous_errors)
                entry['value']=entry['evaluation']['value']
                entry['effect_status']='unverified'
            except Exception as error:
                entry['evaluation']={'status':'unverified','reason':str(error)}
            try:
                ref = p.getReferencedParm()
                if ref is not None:
                    entry["referenced_parm"] = ref.path()
            except Exception:
                pass
        if tpl is not None and tpl.type() == hou.parmTemplateType.String and not keys and not has_expr:
            raw = p.unexpandedString()
            entry['source_sha256'] = hashlib.sha256(raw.encode('utf-8')).hexdigest()
            if raw != entry.get('value'):
                entry['raw_value'] = raw
        if is_ref:
            entry["referenced_by"] = True
        if keys or time_dependent:
            entry["animated"] = True
            entry["time_dependent"] = time_dependent
        if keys:
            frames = sorted(float(key.frame()) for key in keys)
            curves = []
            for key in keys:
                try:
                    curve = key.expression()
                except Exception:
                    curve = None
                if curve and curve not in curves:
                    curves.append(curve)
            entry.update({
                "key_count": len(keys),
                "first_frame": frames[0],
                "last_frame": frames[-1],
            })
            if curves:
                entry["curves"] = curves
        out.append(entry)
    if requested is not None:
        by_name = {entry['name']: entry for entry in out}
        selected = []
        for kind, name, parms in requested:
            components = [by_name[parm.name()] for parm in parms]
            if kind == 'scalar':
                selected.append(components[0])
                continue
            parm_tuple = n.parmTuple(name)
            template = parm_tuple.parmTemplate() if parm_tuple is not None else None
            entry = {
                'name': name,
                'label': template.label() if template is not None else None,
                'type': 'tuple',
                'size': len(components),
                'component_names': [component['name'] for component in components],
                'value': [component.get('value') for component in components],
                'components': components,
            }
            if any(component.get('animated') for component in components):
                entry['animated'] = True
            if any(component.get('time_dependent') for component in components):
                entry['time_dependent'] = True
            selected.append(entry)
        return selected
    return out


def _clear_animation(p) -> str | None:
    """参数上有表达式/关键帧时清除并返回描述；没有则返回 None。

    2026-08-20 OTL 会话（seq 28944）：``parm.set`` 被 ``$FEND`` 表达式静默架空，
    eval 纹丝不动但无报错。「set 就是 set」——清掉再设，并在返回里告知清了什么。
    """
    try:
        expr = p.expression()
    except Exception:
        expr = None
    keys = []
    try:
        keys = list(p.keyframes())
    except Exception:
        pass
    if expr is None and not keys:
        return None
    desc = f"expression {expr!r}" if expr is not None else f"{len(keys)} keyframe(s)"
    p.deleteAllKeyframes()
    return desc


class _ParameterReference:
    """Stable channel address while native multiparm instances are recreated."""
    def __init__(self, parm):
        self.node_identity = parm.node().sessionId()
        self.name = parm.name()
        self.path = parm.path()
        self.locked = parm.isLocked()
        self.multiparm = parm.isMultiParmParent()
        self.depth = len(parm.multiParmInstanceIndices())
        self.instances = tuple(p.name() for p in parm.multiParmInstances()) if self.multiparm else None

    def resolve(self):
        node = hou.nodeBySessionId(self.node_identity)
        parm = node.parm(self.name) if node is not None else None
        if parm is None:
            raise RuntimeError(f'{self.path}: original parameter identity no longer exists')
        return parm


def _parameter_snapshot(targets) -> dict:
    """Snapshot explicit channels and every instance removed by a count edit."""
    targets = tuple(targets)
    for target in targets:
        if target.isLocked():
            raise ValueError(f"参数已锁定：{target.path()}")
    snapshots = {}

    def capture(target):
        if target.name() in snapshots:
            return
        if target.parmTemplate().type() == hou.parmTemplateType.Data:
            raise ValueError(f'{target.path()}: data parameters are not scalar values; zero writes. Use the documented node initialization workflow (for example Stash Input), not set_parm(s) on embedded geometry.')
        keys = tuple(target.keyframes())
        value = (target.unexpandedString() if target.parmTemplate().type() == hou.parmTemplateType.String
                 else target.eval()) if not keys else None
        reference = _ParameterReference(target)
        snapshots[reference.name] = (reference, keys, value)
        if reference.multiparm:
            # HOM returns immediate instances only; nested count channels need
            # their own complete snapshots before any outer count can shrink.
            for instance in target.multiParmInstances():
                capture(instance)

    for target in targets:
        capture(target)
    return snapshots


def _parameter_restore_evidence(snapshots) -> dict:
    """Read back exact channel state; matching output geometry is insufficient.

    Re-resolve by original node identity and parameter name, never by a path
    that could now identify a replacement node. No parameter or geometry writes.
    """
    errors, channels = [], []
    for reference, keys, value in snapshots.values():
        try:
            p = reference.resolve()
            actual_keys = tuple(p.keyframes())
            raw = (p.unexpandedString() if p.parmTemplate().type() == hou.parmTemplateType.String
                   else p.eval()) if not actual_keys else None
            # H21 Ramp equality is not a structural channel comparison. The
            # basis, knot positions and values are the native ramp payload.
            value_matches = (raw.basis() == value.basis() and raw.keys() == value.keys()
                             and raw.values() == value.values()
                             if isinstance(raw, hou.Ramp) and isinstance(value, hou.Ramp)
                             else raw == value)
            exact = actual_keys == keys and (bool(keys) or value_matches)
            structure_matches = (not reference.multiparm or
                p.isMultiParmParent() and tuple(child.name() for child in p.multiParmInstances()) == reference.instances)
            exact = exact and structure_matches and p.isLocked() == reference.locked
            channels.append({'node_identity':reference.node_identity,'parameter':p.path(),
                'key_count_before':len(keys),'key_count_after':len(actual_keys),
                'state_matches':exact,
                **({'multiparm_structure_matches':structure_matches} if reference.multiparm else {}),
                **({'expected_value':_val(value),'actual_value':_val(raw)} if not keys
                   else {'animation_matches':actual_keys == keys})})
            if not exact:
                errors.append(f'{p.path()}: restored value/expression/keyframes/lock or multiparm structure differ from snapshot')
        except Exception as error:
            errors.append(f'parameter restoration readback: {error}')
    return {'ok':not errors,'channels':channels,'errors':errors,
            'scope':'exact snapshotted channels and multiparm instance structure only; no external side effects or future-state guarantee'}


def _restore_parameters(snapshots) -> list:
    errors = []
    # Counts rebuild the parameter tree, outermost first. Restore leaves only
    # after all counts exist, irrespective of the caller's dictionary order.
    ordered = sorted(snapshots.values(), key=lambda state: (
        not state[0].multiparm, state[0].depth))
    for reference, keys, value in ordered:
        try:
            target = reference.resolve()
            # An implicit instance may originally be locked. Its containing
            # count was authorized, so restore its data and original lock as
            # one state. A newly locked, originally unlocked target still
            # reports a restoration failure rather than overriding callbacks.
            if reference.locked:
                target.lock(False)
            try:
                target.deleteAllKeyframes()
                if keys:
                    target.setKeyframes(keys)
                else:
                    target.set(value, follow_parm_reference=False)
            finally:
                if reference.locked:
                    target.lock(True)
        except Exception as error:
            errors.append(f"{reference.path}: {error}")
    errors.extend(_parameter_restore_evidence(snapshots)['errors'])
    return errors


def _prepare_parameter_patch(p, value):
    """Bounded sequential literal replacements, fully planned before writes."""
    def reject(message):
        raise ParameterPatchError(f'{p.path()}: {message}', p.path())
    if set(value) != {'patch', 'expected_sha256'}:
        reject('patch object requires only patch and expected_sha256')
    expected = value['expected_sha256']
    if not isinstance(expected, str) or not re.fullmatch('[0-9a-f]{64}', expected):
        reject('expected_sha256 must be the current raw UTF-8 string SHA-256')
    tpl = p.parmTemplate()
    if tpl.type() != hou.parmTemplateType.String or tpl.numComponents() != 1:
        reject('patch requires a literal scalar string parameter')
    if p.isLocked() or p.keyframes():
        reject('patch refuses locked, animated or expression-driven strings')
    # Wrangle source editors have a StringReplace snippet menu; that is an
    # editable source field, not an enum. Never evaluate its menu generator.
    if tpl.scriptCallback() or ((tpl.menuItems() or tpl.itemGeneratorScript())
                               and tpl.menuType() == hou.menuType.Normal):
        reject('patch refuses callback and fixed-menu parameters')
    patches = value['patch']
    if not isinstance(patches, list) or not 1 <= len(patches) <= 32:
        reject('patch requires 1..32 literal replacement objects')
    source = p.unexpandedString()
    if len(source) > 524288:
        reject('source exceeds 524288 characters; split into smaller editable modules')
    before_hash = hashlib.sha256(source.encode('utf-8')).hexdigest()
    if before_hash != expected:
        reject(f'stale source: expected {expected}, current {before_hash}')
    result, matches, text_budget = source, [], 0
    for index, edit in enumerate(patches):
        if not isinstance(edit, dict) or set(edit) != {'old', 'new', 'count'}:
            reject(f'patch[{index}] requires only old/new/count')
        old, new, count = edit['old'], edit['new'], edit['count']
        if not isinstance(old, str) or not old or not isinstance(new, str) or old == new:
            reject(f'patch[{index}] needs a nonempty old string and a different new string')
        text_budget += len(old) + len(new)
        if text_budget > 131072 or type(count) is not int or not 1 <= count <= 256:
            reject(f'patch[{index}] exceeds text budget or needs integer count in 1..256')
        actual = result.count(old)
        if actual != count:
            reject(f'patch[{index}] anchor count: expected {count}, found {actual}; no parameters written')
        result = result.replace(old, new, count)
        if len(result) > 524288:
            reject('patched source exceeds 524288 characters')
        matches.append({'count': count, 'old_chars': len(old), 'new_chars': len(new)})
    if result == source:
        reject('patch sequence makes no net change')
    return {'source': source, 'result': result, 'evidence': {
        'before_sha256': before_hash, 'after_sha256': hashlib.sha256(result.encode('utf-8')).hexdigest(),
        'before_chars': len(source), 'after_chars': len(result), 'replacements': matches}}


def _apply_parameter_patch(p, plan):
    # Another parameter callback in this batch may have changed the source;
    # this is a write-phase failure, never zero-write evidence for the batch.
    if p.keyframes() or p.unexpandedString() != plan['source']:
        raise RuntimeError(f'{p.path()}: source changed after patch preflight')
    p.set(plan['result'], follow_parm_reference=False)
    if p.keyframes() or p.unexpandedString() != plan['result']:
        raise RuntimeError(f'{p.path()}: literal patch readback mismatch')
    return {'parm': p.name(), 'patch': plan['evidence'], 'value_omitted': True}


def set_parm(node, name: str, value,
             allow_foreign: str | None = None) -> dict:
    """设参；numeric string 是表达式，Menu string 是精确 token。

    失败恢复本参数的值/表达式/关键帧，不跟随引用修改其他节点。菜单动画可显式传
    {"expression": "...", "language": "hscript"|"python"}。外部回调不属回滚范围。
    multiparm数量修改同时快照全部嵌套实例；恢复先重建数量/结构，再恢复实例通道与锁定状态。
    Data/内嵌Geometry参数在快照与写入前拒绝；按节点原生初始化流程处理，不用标量setter。
    字面string可用{"expected_sha256":原始UTF8源码hash,"patch":[{"old":锚点,"new":替换,"count":精确次数}]}。
    1..32项顺序替换，先验证全部锚点/版本；拒绝锁定、动画/表达式、callback和固定菜单。
    源码上限524288字符，替换文本累计131072字符，count为1..256；不执行正则或补丁脚本。
    返回patch的前后hash/字符数/替换次数，value_omitted=True；不证明VEX或几何通过，另做cook/verify_network。
    表达式返回language/write_status/evaluation/effect_status；合法0不算错误。本次新增且原生明确指向本参数的求值
    错误或非有限数值抛CheckpointError并恢复参数；节点/tuple warning只报告范围，不认证几何或全部引用。
    """
    n = _resolve(node)
    _require_owned(n, "set_parm", allow_foreign)
    if name == 'snippet' and isinstance(value, str) and 'wrangle' in n.type().name():
        from dsh_cook_control import validate_vex
        validate_vex(value)
    p = n.parm(name)
    targets = (p,) if p is not None else n.parmTuple(name)
    is_patch = isinstance(value, dict) and 'patch' in value
    if is_patch and p is None:
        raise ParameterPatchError(f'{name}: patch requires an existing scalar string parameter', n.path())
    plan = _prepare_parameter_patch(p, value) if is_patch else None
    snapshots = _parameter_snapshot(targets) if targets is not None else {}
    try:
        if plan is not None:
            return _apply_parameter_patch(p, plan)
        return _set_parm_impl(n, name, value, allow_foreign)
    except BaseException as error:
        restore_errors = _restore_parameters(snapshots)
        evidence = error.evidence if isinstance(error, CheckpointError) else {
            'ok': False, 'node': n.path(), 'parm': name, 'phase': 'parameter_write'}
        evidence.update({'restored': not restore_errors,
            'parameter_state_restored': not restore_errors, 'parameter_restore_errors': restore_errors,
            'restore_errors': restore_errors, 'write_status': 'restored' if not restore_errors else 'recovery_unverified',
            'restoration_scope': 'snapshotted parameter values, expressions and keys only; callbacks, cooks and external side effects are separate'})
        error.evidence = evidence
        raise


def _validate_numeric_parameter_value(value, components=(), *, size=None) -> None:
    """Shared static/runtime value-shape check; never evaluate an expression.

    A size-one template names a scalar Parm, not a ParmTuple-only setter.
    Full numeric tuples accept finite literals; scalar/component fields accept
    literals or explicit expressions. Menus retain their separate token policy.
    """
    # Tuple width is a template fact, independent of whether its naming scheme
    # is known here. An unrecognized scheme must never turn a tuple into scalar.
    size = size if size is not None else len(components) or 1
    if size > 1:
        names = f': {list(components)}' if components else ''
        if not isinstance(value, (list, tuple)) or len(value) != size:
            raise ValueError(f'tuple needs {size} components{names}')
        if any(not isinstance(v, (int, float)) or not math.isfinite(v) for v in value):
            target = str(list(components)) if components else 'from list_parms on the created node'
            raise ValueError(f'numeric tuple requires finite numeric values; expressions use component names {target}')
        return
    if isinstance(value, str):
        return  # Numeric strings are HScript, not implicit menu tokens.
    if isinstance(value, dict):
        if set(value) - {'expression', 'language'} or not isinstance(value.get('expression'), str):
            raise ValueError('scalar expression object accepts expression string and optional language only')
        if value.get('language', 'hscript') not in ('hscript', 'python'):
            raise ValueError('expression language must be hscript/python')
        return
    if not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError('numeric scalar requires a finite number or expression, not a list/tuple or null')


def _expression_evaluation(p, value, language, previous_errors=()):
    """Use Houdini's diagnostics, never infer failure from a zero value.

    This reads the last evaluation diagnostics, without cooking the node or
    evaluating the expression again. Tuple warnings can concern a sibling.
    """
    node=p.node()
    errors=[str(e) for e in node.errors()]
    warnings=[str(e) for e in node.warnings()]
    exact=re.compile(re.escape(p.path())+r'(?![A-Za-z0-9_])')
    evaluation_path=re.compile(re.escape('('+p.path()+'))')+r'\.?\s*$')
    own_errors=[e for e in errors if 'Unable to evaluate expression' in e and evaluation_path.search(e)]
    new_errors=[e for e in own_errors if e not in previous_errors]
    tuple_path=node.path()+'/'+p.tuple().name()
    related=re.compile(re.escape(tuple_path)+r'(?![A-Za-z0-9_])')
    related_warnings=[w for w in warnings if exact.search(w) or related.search(w)]
    finite=not isinstance(value,(int,float)) or math.isfinite(value)
    if not finite:
        own_errors.append('expression evaluated to a non-finite numeric value')
        new_errors.append(own_errors[-1])
    status='failed' if new_errors else 'unverified' if own_errors else 'warning' if related_warnings else 'unverified' if errors or warnings else 'evaluated'
    return {'status':status,'parameter':p.path(),'language':language,'frame':float(hou.frame()),
        'value':_val(value) if finite else repr(value),'errors':own_errors,
        'new_errors':new_errors,'prior_diagnostics_present':bool(previous_errors),
        'warnings':related_warnings,'node_errors':errors,'node_warnings':warnings,
        **({'next_action':'Inspect reference targets and explicitly cook/check the intended output; unchanged node errors may be cached from an earlier cook, and a zero value alone proves neither success nor failure.'} if status in ('warning','unverified') else {}),
        'scope':'last parameter evaluation; tuple warnings may concern a sibling, node diagnostics may predate this write; no geometry cook or effect validation'}


def _set_expression(p, expression, language):
    previous_errors=tuple(str(e) for e in p.node().errors())
    try:
        _clear_animation(p)
        p.setExpression(expression,language=hou.exprLanguage.Hscript if language=='hscript' else hou.exprLanguage.Python)
    except Exception as error:
        raise CheckpointError(f'expression write failed at {p.path()} ({language}): {error}',
            {'ok':False,'node':p.node().path(),'parm':p.name(),'expression':expression,'language':language,
             'failure_stage':'write','write_status':'failed','evaluation':{'status':'not_run'},'effect_status':'unverified'}) from error
    try:
        value=p.eval()
        evaluation=_expression_evaluation(p,value,language,previous_errors)
    except Exception as error:
        raise CheckpointError(f'expression evaluation raised at {p.path()} ({language}): {error}',
            {'ok':False,'node':p.node().path(),'parm':p.name(),'expression':expression,'language':language,
             'failure_stage':'evaluation','write_status':'written','evaluation':{'status':'failed','errors':[str(error)]},'effect_status':'unverified'}) from error
    result={'parm':p.name(),'node':p.node().path(),'expression':expression,'language':language,
            'value':evaluation['value'],'write_status':'written','evaluation':evaluation,'effect_status':'unverified'}
    if evaluation['status']=='failed':
        raise CheckpointError(f'expression evaluation failed at {p.path()} ({language}): '+ '; '.join(evaluation['errors']),
                              {'ok':False,'failure_stage':'evaluation',**result})
    return result


def _set_parm_impl(node, name: str, value,
                   allow_foreign: str | None = None) -> dict:
    """设参数（组件名或元组名均可）；失败时列出相似参数名供自纠。

    数值型参数收到字符串值时按**表达式**处理（H21/H22 实测 ``Parm.set(str)``
    对数值参数直接抛 TypeError，必须走 ``setExpression``）——这让
    ``set_parm(n, 'tx', 'ch(\"ty\")')`` 这类最高频操作可用。

    参数上已有表达式/关键帧时**自动清除再设值**（2026-08-20 拍板），返回带
    ``note`` 说明清掉了什么；想保留动画请显式传字符串表达式。
    """
    n = _resolve(node)
    _require_owned(n, "set_parm", allow_foreign)
    p = n.parm(name)
    if p is not None:
        if isinstance(value, dict):
            if set(value) - {"expression", "language"} or not isinstance(value.get("expression"), str):
                raise ValueError("表达式对象只接受 expression 和可选 language")
            language = value.get("language", "hscript")
            if language not in ("hscript", "python"):
                raise ValueError("expression language 必须为 hscript/python")
            return _set_expression(p,value['expression'],language)
        # Menu tokens are not expressions. Do not let an invalid token silently
        # evaluate to 0 or leave an animated parameter with its keys deleted.
        tpl = p.parmTemplate()
        try: tokens = tuple(p.menuItems()) if tpl.type() in (hou.parmTemplateType.Menu, hou.parmTemplateType.Int) else ()
        except hou.OperationFailed:
            if tpl.type() == hou.parmTemplateType.Menu: raise
            tokens = ()  # plain integer controls are not menus
        if tokens or tpl.type() == hou.parmTemplateType.Menu:
            setting = _menu_setting(_menu_entries(tpl, tokens, p.menuLabels()), value)
            cleared = _clear_animation(p)
            p.set(setting)
            return {"parm": p.name(), "value": _val(p.eval()), "menu_token": p.evalAsString(),
                    **({"note": f"cleared {cleared}"} if cleared else {})}
        if tpl.type() in (hou.parmTemplateType.Int, hou.parmTemplateType.Float):
            _validate_numeric_parameter_value(value)
        if isinstance(value, str):
            tpl_type = None
            try:
                tpl_type = p.parmTemplate().type()
            except Exception:
                pass
            if tpl_type in (hou.parmTemplateType.Int, hou.parmTemplateType.Float):
                return _set_expression(p,value,'hscript')
        cleared = _clear_animation(p)
        p.set(value)
        out = {"parm": p.name(), "value": _val(p.eval())}
        if cleared:
            out["note"] = f"cleared {cleared}"
        return out

    pt = n.parmTuple(name)
    if pt is not None:
        if isinstance(value, (list, tuple)):
            if len(value) != len(pt):
                raise ValueError(f"{pt.name()} 需要 {len(pt)} 个分量，收到 {len(value)}")
            if pt.parmTemplate().type() in (hou.parmTemplateType.Int, hou.parmTemplateType.Float):
                _validate_numeric_parameter_value(value, [p.name() for p in pt])
            cleared = [c for pp in pt for c in [_clear_animation(pp)] if c]
            pt.set(value)
            out = {"parm": pt.name(), "value": [_val(v) for v in pt.eval()]}
            if cleared:
                out["note"] = f"cleared {', '.join(cleared)}"
            return out
        comps = [pp.name() for pp in n.parms() if pp.tuple().name() == name]
        raise ValueError(
            f"'{name}' 在 '{n.path()}' 上是 {len(comps)} 分量元组 "
            f"({', '.join(comps)})；请传 list/tuple"
        )

    names = [pp.name() for pp in n.parms()]
    suggestions = difflib.get_close_matches(name, names, n=5, cutoff=0.4)
    raise ValueError(
        f"节点 '{n.path()}' (type={n.type().name()}) 没有参数 '{name}'。相似参数：{suggestions}；请用 list_parms 查询实际节点"
    )


def set_parms(node, values: dict,
              allow_foreign: str | None = None, strict: bool = True) -> dict:
    """批量设参：``{name: value}`` 逐项走 ``set_parm`` 同一套语义（含表达式/关键帧清除）。

    默认 strict：预检参数名，失败恢复本批参数（含表达式/关键帧）并抛错。
    multiparm数量包含其全部嵌套实例快照；恢复后回读实例结构、值、keys与锁定状态。
    ``strict=False`` 仅用于明确允许部分成功的诊断/恢复，返回 ``ok/set/failed``。
    参数回调的外部副作用不能靠参数快照回滚，复杂批次仍需 Bridge undo 事务。
    value支持set_parm的字面string patch对象；只允许strict=True，整批patch验证通过后才写任何参数。
    补丁字段在set中返回前后hash/字符数/替换次数（不回传整份源码），patched列出这些字段名。
    预检限本节点本批values；其他节点/其他调用不属此预检范围。
    表达式字段另给evaluations；明确求值失败在strict模式恢复本批值/keys，warning/unverified单独报告。
    """
    n = _resolve(node)
    _require_owned(n, "set_parms", allow_foreign)
    if not isinstance(values, dict) or not values:
        raise ValueError("values 必须是非空 dict：{参数名: 值}")
    if not isinstance(strict, bool):
        raise ValueError("strict 必须是 bool")
    snapshots, patch_plans = {}, {}
    if not strict and any(isinstance(v, dict) and 'patch' in v for v in values.values()):
        raise ParameterPatchError('literal patches require strict=True', n.path())
    if strict:
        explicit_targets = {}
        for key in values:
            parm = n.parm(key)
            targets = (parm,) if parm is not None else n.parmTuple(key)
            if targets is None:
                raise ValueError(f"{n.path()} (type={n.type().name()}) 没有参数 {key!r}；请用 list_parms 查询实际节点")
            for target in targets:
                if target.name() in explicit_targets:
                    raise ValueError(f"同批参数重叠：{key!r} 与 {target.name()!r}")
                explicit_targets[target.name()] = target
        snapshots = _parameter_snapshot(explicit_targets.values())
        # Validate EVERY patch before the first regular or patch parameter write.
        for key, value in values.items():
            if isinstance(value, dict) and 'patch' in value:
                parm = n.parm(key)
                if parm is None:
                    raise ParameterPatchError(f'{key}: patch requires a scalar string parameter', n.path())
                patch_plans[key] = _prepare_parameter_patch(parm, value)
    done, failed, notes, evaluations = {}, {}, {}, {}
    for key, value in values.items():
        try:
            r = (_apply_parameter_patch(n.parm(key), patch_plans[key]) if key in patch_plans
                 else set_parm(n, key, value, allow_foreign=allow_foreign))
            done[r["parm"]] = r['patch'] if 'patch' in r else r.get("value", r.get("expression"))
            if "note" in r:
                notes[r["parm"]] = r["note"]
            if 'evaluation' in r:evaluations[r['parm']]=r['evaluation']
        except Exception as e:
            failed[key] = str(e)
            if strict:
                restore_errors = _restore_parameters(snapshots)
                if isinstance(e,CheckpointError):
                    e.evidence.update({'restored':not restore_errors, 'restore_errors':restore_errors,
                                       'batch_parameter_state_restored':not restore_errors,
                                       'batch_restore_errors':restore_errors,'write_status':'restored' if not restore_errors else 'recovery_unverified',
                                       'restoration_scope':'all snapshotted parameters in this batch; callbacks, cooks and external side effects are separate'})
                    raise
                raise CheckpointError(f"set_parms failed at {key!r}: {e}; parameter_restore_errors={restore_errors}",
                    {'ok':False, 'node':n.path(), 'phase':'parameter_write',
                     'restored':not restore_errors, 'restore_errors':restore_errors,
                     'restoration_scope':'all snapshotted parameters in this batch; callbacks, cooks and external side effects are separate'}) from e
    out = {"node": n.path(), "ok": not failed, "set": done}
    if patch_plans:
        out['patched'] = list(patch_plans)
    if notes:
        out["notes"] = notes
    if failed:
        out["failed"] = failed
    if evaluations:
        out['evaluations']=evaluations
        out['effect_status']='unverified'
        if any(e['status']=='unverified' for e in evaluations.values()):out['status']='unverified'
        if any(e['status'] in ('warning','unverified') for e in evaluations.values()):out['warning_free']=False
    return out


_KEYFRAME_CURVES = {
    "constant": "constant()",
    "linear": "linear()",
    "bezier": "bezier()",
}
_KEYFRAME_INPUT_LIMIT = 10_000
_KEYFRAME_RESULT_LIMIT = 64
_KEYFRAME_SAMPLE_LIMIT = 32


def set_keyframes(node, channels: dict, replace: bool = True,
                  allow_foreign: str | None = None) -> dict:
    """批量写入标量数值参数关键帧，统一使用 frame 单位并提交后回读。

    ``channels`` 形如 ``{"tx": [{"frame": 1, "value": 0, "curve": "linear"}]}``。
    curve 仅支持 ``constant/linear/bezier``；它描述从该 key 离开的 segment。
    所有 channel 在修改前完成校验；任一写入失败会恢复本次涉及参数的原值、表达式、关键帧与当前帧；恢复错误保留在返回证据。
    ``replace=False`` 保留旧 keys，但拒绝覆盖同一 frame。该动词只负责 channel 数据，
    不替代有序状态机、KineFX/APEX rig logic 或 Animation Editor。
    """
    try:
        n = _resolve(node)
        _require_owned(n, "set_keyframes", allow_foreign)
        if not isinstance(channels, dict) or not channels:
            raise ValueError("channels 必须是非空 dict：{标量参数名: key spec 列表}")
        if not isinstance(replace, bool):
            raise ValueError("replace 必须是 bool")

        prepared = {}
        originals = {}
        for parm_name, specs in channels.items():
            if not isinstance(parm_name, str) or not parm_name:
                raise ValueError(f"channel 名必须是非空字符串，收到 {parm_name!r}")
            parm = n.parm(parm_name)
            if parm is None:
                if n.parmTuple(parm_name) is not None:
                    raise ValueError(
                        f"{n.path()}/{parm_name} 是参数元组；请按组件名分别提供 channel"
                    )
                suggestions = difflib.get_close_matches(
                    parm_name, [item.name() for item in n.parms()], n=5, cutoff=0.4
                )
                raise ValueError(
                    f"节点 {n.path()} 没有标量参数 {parm_name!r}；相似参数：{suggestions}"
                )
            template = parm.parmTemplate()
            try:
                template_type = template.type()
            except Exception:
                template_type = None
            if template_type not in (hou.parmTemplateType.Int, hou.parmTemplateType.Float):
                raise ValueError(
                    f"{parm.path()} 不是数值标量参数（类型={template_type}），不能写数值 keyframes"
                )
            if not isinstance(specs, (list, tuple)) or not specs:
                raise ValueError(f"channels[{parm_name!r}] 必须是非空 key spec 列表")
            if len(specs) > _KEYFRAME_INPUT_LIMIT:
                raise ValueError(
                    f"channels[{parm_name!r}] 超过 {_KEYFRAME_INPUT_LIMIT} keys；"
                    "请拆分任务或使用缓存/clip 工作流"
                )

            existing_keys = tuple(parm.keyframes())
            originals[parm_name] = existing_keys
            existing_frames = {float(key.frame()) for key in existing_keys}
            seen_frames = set()
            keys = []
            for index, spec in enumerate(specs):
                path = f"channels[{parm_name!r}][{index}]"
                if not isinstance(spec, dict):
                    raise ValueError(f"{path} 必须是 dict")
                unknown = set(spec) - {"frame", "value", "curve"}
                if unknown:
                    raise ValueError(f"{path} 有未知字段：{sorted(unknown)}")
                if "frame" not in spec or "value" not in spec:
                    raise ValueError(f"{path} 必须同时提供 frame 和 value")
                if isinstance(spec["frame"], bool) or isinstance(spec["value"], bool):
                    raise ValueError(f"{path}.frame/value 不能是 bool")
                frame = float(spec["frame"])
                value = float(spec["value"])
                if not math.isfinite(frame) or not math.isfinite(value):
                    raise ValueError(f"{path}.frame/value 必须是有限数值")
                if frame in seen_frames:
                    raise ValueError(f"{path}.frame={frame} 在同一 channel 重复")
                if not replace and frame in existing_frames:
                    raise ValueError(
                        f"{path}.frame={frame} 已存在；replace=False 不允许覆盖旧 key"
                    )
                seen_frames.add(frame)
                curve_name = str(spec.get("curve", "bezier")).strip().lower()
                expression = _KEYFRAME_CURVES.get(curve_name)
                if expression is None:
                    raise ValueError(
                        f"{path}.curve={curve_name!r} 不支持；可用 {sorted(_KEYFRAME_CURVES)}"
                    )
                key = hou.Keyframe(value)
                key.setFrame(frame)
                key.setExpression(expression, hou.exprLanguage.Hscript)
                keys.append(key)
            prepared[parm_name] = (parm, tuple(sorted(keys, key=lambda key: key.frame())))

        snapshots = _parameter_snapshot([parm for parm, _ in prepared.values()])
    except (ValueError, TypeError, OverflowError, hou.Error) as error:
        raise CheckpointError(str(error), {'ok': False, 'phase': 'keyframes_preflight',
            'scene_writes': 0, 'applied': False}) from error

    saved_frame = float(hou.frame())
    writes = 0
    try:
        for parm_name, (parm, keys) in prepared.items():
            writes += 1
            if replace:
                parm.deleteAllKeyframes()
            parm.setKeyframes(keys)
        if float(hou.frame()) != saved_frame:
            hou.setFrame(saved_frame)
        result = {}
        for parm_name, (parm, _) in prepared.items():
            keys = tuple(parm.keyframes())
            frames = [float(key.frame()) for key in keys]
            key_data = []
            for key in keys:
                try:
                    curve = key.expression()
                except Exception:
                    curve = None
                key_data.append({
                    "frame": float(key.frame()),
                    "value": float(key.value()),
                    "curve": curve,
                })
            if len(key_data) > _KEYFRAME_RESULT_LIMIT:
                key_preview = (
                    key_data[:_KEYFRAME_RESULT_LIMIT // 2]
                    + key_data[-_KEYFRAME_RESULT_LIMIT // 2:]
                )
                keys_truncated = len(key_data) - len(key_preview)
            else:
                key_preview = key_data
                keys_truncated = 0
            sample_candidates = sorted(set([
                frames[0],
                frames[-1],
                *(
                    (frames[index] + frames[index + 1]) / 2.0
                    for index in range(len(frames) - 1)
                ),
            ]))
            if len(sample_candidates) > _KEYFRAME_SAMPLE_LIMIT:
                sample_frames = (
                    sample_candidates[:_KEYFRAME_SAMPLE_LIMIT // 2]
                    + sample_candidates[-_KEYFRAME_SAMPLE_LIMIT // 2:]
                )
            else:
                sample_frames = sample_candidates
            result[parm_name] = {
                "key_count": len(keys),
                "first_frame": frames[0],
                "last_frame": frames[-1],
                "keys": key_preview,
                "samples": {
                    str(frame): float(parm.evalAtFrame(frame)) for frame in sample_frames
                },
                "replaced_existing": len(originals[parm_name]) if replace else 0,
            }
            if keys_truncated:
                result[parm_name]["keys_truncated"] = keys_truncated
        return {
            "node": n.path(),
            "replace": replace,
            "channels": result,
            "frame_restored": float(hou.frame()) == saved_frame,
            "scene_writes": writes,
        }

    except BaseException as error:
        restore_errors = _restore_parameters(snapshots)
        if float(hou.frame()) != saved_frame:
            try:
                hou.setFrame(saved_frame)
            except Exception as failure:
                restore_errors.append(f'frame: {failure}')
        if float(hou.frame()) != saved_frame:
            restore_errors.append('frame: restoration readback differs')
        raise CheckpointError(f'set_keyframes failed: {error}; restore_errors={restore_errors}',
            {'ok': False, 'phase': 'keyframes_write', 'scene_writes': writes,
             'restored': not restore_errors, 'restore_errors': restore_errors,
             'frame_restored': float(hou.frame()) == saved_frame,
             'scope': 'snapshotted channel values, expressions, keys and frame; external side effects are separate'}) from error


def _spare_spec_template(item: dict, path: str, names: set):
    if not isinstance(item, dict):
        raise ValueError(f"{path} 必须是 dict")
    kind = str(item.get("type", "")).strip().lower()
    if kind not in {"folder", "toggle", "int", "float", "string"}:
        raise ValueError(
            f"{path}.type 不支持 {kind!r}；可用 folder/toggle/int/float/string"
        )
    name = item.get("name")
    if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        raise ValueError(f"{path}.name 必须是合法 Houdini 参数名")
    if name in names:
        raise ValueError(f"参数/文件夹名 {name!r} 重复")
    names.add(name)
    label = str(item.get("label", name.replace("_", " ").title()))
    if kind == "folder":
        children = item.get("parms", [])
        if not isinstance(children, (list, tuple)) or not children:
            raise ValueError(f"{path}.parms 必须是非空 list")
        template = hou.FolderParmTemplate(name, label, folder_type=hou.folderType.Simple)
        for index, child in enumerate(children):
            template.addParmTemplate(
                _spare_spec_template(child, f"{path}.parms[{index}]", names)
            )
    elif kind == "toggle":
        template = hou.ToggleParmTemplate(
            name, label, default_value=bool(item.get("default", False))
        )
    elif kind in ("int", "float"):
        default = item.get("default", 0)
        minimum = item.get("min", 0)
        maximum = item.get("max", 10)
        kwargs = {
            "default_value": (float(default),) if kind == "float" else (int(default),),
            "min": float(minimum) if kind == "float" else int(minimum),
            "max": float(maximum) if kind == "float" else int(maximum),
            "min_is_strict": bool(item.get("min_strict", False)),
            "max_is_strict": bool(item.get("max_strict", False)),
        }
        cls = hou.FloatParmTemplate if kind == "float" else hou.IntParmTemplate
        template = cls(name, label, 1, **kwargs)
    else:
        template = hou.StringParmTemplate(
            name, label, 1, default_value=(str(item.get("default", "")),)
        )
    if item.get("help") is not None:
        template.setHelp(str(item["help"]))
    return template


def _update_spare_defaults(n, updates):
    """Update only literal scalar spare defaults; preserve live values/animation."""
    if not isinstance(updates, dict) or not 1 <= len(updates) <= 32:
        raise ValueError('update_defaults must contain 1..32 existing scalar spare parameters')
    group = n.parmTemplateGroup()
    before_group = n.parmTemplateGroup()
    targets, changes = [], {}
    for name, value in updates.items():
        if not isinstance(name, str) or not name:
            raise ValueError('update_defaults keys must be nonempty parameter names')
        p = n.parm(name)
        if p is None or not p.isSpare():
            raise ValueError(f'{name}: update_defaults requires an existing spare parameter')
        tpl = p.parmTemplate()
        kind = tpl.type()
        if (tpl.numComponents() != 1 or p.isMultiParmInstance() or tpl.scriptCallback()
                or kind not in (hou.parmTemplateType.Float, hou.parmTemplateType.Int,
                                hou.parmTemplateType.Toggle, hou.parmTemplateType.String)):
            raise ValueError(f'{name}: only scalar float/int/toggle/string defaults without callbacks or multiparms are supported')
        if getattr(tpl, 'menuItems', lambda: ())():
            raise ValueError(f'{name}: menu defaults are unsupported')
        if any(getattr(tpl, 'defaultExpression', lambda: ())()):
            raise ValueError(f'{name}: expression defaults are unsupported; do not silently replace their meaning')
        if kind == hou.parmTemplateType.String:
            valid = isinstance(value, str)
        elif kind == hou.parmTemplateType.Toggle:
            valid = type(value) is bool or (type(value) is int and value in (0, 1))
        elif kind == hou.parmTemplateType.Int:
            valid = type(value) is int and -(2**31) <= value < 2**31
        else:
            valid = type(value) in (int, float) and math.isfinite(value)
        if not valid:
            raise ValueError(f'{name}: invalid literal default for {kind.name()}')
        if kind in (hou.parmTemplateType.Float, hou.parmTemplateType.Int):
            if ((tpl.minIsStrict() and value < tpl.minValue())
                    or (tpl.maxIsStrict() and value > tpl.maxValue())):
                raise ValueError(f'{name}: default is outside strict parameter limits')
        old = tpl.defaultValue()
        # ToggleParmTemplate uses a scalar default; other scalar templates use a tuple.
        tpl.setDefaultValue(bool(value) if kind == hou.parmTemplateType.Toggle else (value,))
        group.replace(name, tpl)
        targets.append(p)
        changes[name] = {'before': _val(old), 'after': _val(tpl.defaultValue())}
    snapshots = _parameter_snapshot(targets)  # preflight locks before the first write

    def restore_values():
        # Reacquire parms after replacing their templates.
        return _restore_parameters(snapshots)

    try:
        n.setParmTemplateGroup(group, rename_conflicting_parms=False)
        errors = restore_values()
        if errors:
            raise RuntimeError(f'current parameter state restore failed: {errors}')
        for name, change in changes.items():
            p = n.parm(name)
            actual = _val(p.parmTemplate().defaultValue())
            if actual != change['after']:
                raise RuntimeError(f'{name}: default readback mismatch: {actual!r}')
            _, keys, value = snapshots[name]
            current = (p.unexpandedString() if p.parmTemplate().type() == hou.parmTemplateType.String
                       else p.eval()) if not keys else None
            if tuple(p.keyframes()) != keys or current != value:
                raise RuntimeError(f'{name}: current value or animation changed during default update')
        return {'node': n.path(), 'mode': 'update_defaults', 'ok': True,
                'updated': changes, 'current_state_preserved': True,
                'current_values': {name: _val(n.parm(name).eval()) for name in changes}}
    except Exception as error:
        restore_errors = []
        try:
            n.setParmTemplateGroup(before_group, rename_conflicting_parms=False)
        except Exception as rollback_error:
            restore_errors.append(str(rollback_error))
        restore_errors.extend(restore_values())
        if restore_errors:
            raise CheckpointError(f'default update restoration failed: {restore_errors}',
                                  {'ok': False, 'node': n.path(), 'restored': False}) from error
        raise


def _apply_spare_interface(n, group, code_parm):
    """Refresh a code parm without flattening its source, references or animation.

    A wrangle cooked before its local channels exist can retain missing-channel
    dependencies after setParmTemplateGroup, even on a forced cook. Reassigning
    the original source/keyframes invalidates those compiled dependencies.
    """
    source = n.parm(code_parm)
    if source is not None and source.parmTemplate().type() != hou.parmTemplateType.String:
        raise ValueError(f'{code_parm}: code parameter must be a string')
    snapshots = _parameter_snapshot([source]) if source is not None else {}
    before = n.parmTemplateGroup()

    def refresh():
        errors = _restore_parameters(snapshots)
        if errors:
            raise RuntimeError(f'code dependency refresh failed: {errors}')
        for name, (_, keys, value) in snapshots.items():
            current = n.parm(name)
            if tuple(current.keyframes()) != keys or (not keys and current.unexpandedString() != value):
                raise RuntimeError(f'{name}: code state changed during dependency refresh')

    try:
        n.setParmTemplateGroup(group, rename_conflicting_parms=False)
        refresh()
    except Exception as error:
        try:
            n.setParmTemplateGroup(before, rename_conflicting_parms=False)
            refresh()
        except Exception as restore_error:
            raise CheckpointError(f'spare interface restoration failed: {restore_error}',
                                  {'ok': False, 'node': n.path(), 'restored': False}) from error
        raise
    return code_parm if snapshots else None


def create_spare_parms(node, code_parm: str = "snippet",
                       defaults: dict | None = None,
                       spec: list | None = None,
                       allow_foreign: str | None = None, *, update_defaults: dict | None = None,
                       layout: list | None = None, dry_run: bool = False) -> dict:
    """从代码参数的 ch/chf/chi/chv/chs 引用创建缺失 spare parameters。

    layout可选模式：与spec/defaults/update_defaults互斥，复用houdini-parameter-ui
    组件，默认追加到单节点而不改HDA定义。dry_run=True返回展开界面/建议且零写入。
    拒绝同名模板/通道；保持已有值/keys/locks，失败恢复旧接口和通道；不创建绑定。
    菜单/颜色tuple/ramp等完整layout字段和可执行示例见verb_help('hda_set_interface', detail='full')；
    下方简化spec只支持folder与scalar，不要将完整layout字段混入简化spec。

    对齐 Wrangle 参数编辑器的 Create Parameters 意图，但要求默认值显式可审计；
    已存在参数默认不重建。``chramp`` 等复杂引用列入 unsupported，交给 HDA/interface
    或裸 hou 处理。

    ``spec`` 的精确递归 schema：folder 条目是
    ``{"type":"folder","name":"controls","label":"Controls","parms":[...]}``；
    scalar 条目是 ``{"type":"toggle|int|float|string","name":"speed",
    "label":"Speed","default":1,"min":0,"max":10,
    "min_strict":False,"max_strict":False,"help":"..."}``。只有 folder 接受
    ``parms``；scalar 必须有 ``name``，其余字段可选。例如::

        create_spare_parms(node, spec=[
            {"type": "folder", "name": "controls", "parms": [
                {"type": "toggle", "name": "enabled", "default": True},
                {"type": "float", "name": "speed", "default": 1.0,
                 "min": 0.0, "max": 10.0},
            ]},
        ])

    新建参数接口后重新赋写code_parm原始源码/keys以刷新编译依赖，不改源码或烘焙表达式。
    返回refreshed_code_parm（未刷新为None）；源码锁定在写入接口前拒绝。
    spec 模式返回 ``node/mode/created/leaf_values``；扫描模式返回
    ``node/code_parm/references/created/existing/defaults_applied/unsupported``。
    显式 ``update_defaults={name:literal}`` 仅更新1..32个已有scalar spare默认值，
    与spec/defaults/非默认code_parm互斥；保留当前值、表达式和keys，不重置当前值。
    仅float/int/toggle/string，拒绝内建参数、tuple/menu/callback/multiparm、表达式默认值。
    返回updated前后默认值、current_values/current_state_preserved；要同时改变当前值另用set_parms。
    """
    if not isinstance(code_parm, str):
        raise ValueError('code_parm must be a parameter name string; pass a parameter specification as spec=[...]')
    n = _resolve(node)
    _require_owned(n, "create_spare_parms", allow_foreign)
    if layout is not None:
        if spec is not None or defaults is not None or update_defaults is not None:
            raise ValueError('layout is exclusive with spec/defaults/update_defaults')
        from dsh_parameter_ui import apply_spare_layout
        try:
            return apply_spare_layout(n, layout, code_parm, dry_run)
        except CheckpointError:
            raise
        except Exception as error:
            raise CheckpointError(str(error), {'ok': False, 'mode': 'layout',
                'phase': 'preflight', 'scene_writes': 0}) from error
    if dry_run is not False:
        raise ValueError('dry_run requires layout mode')
    if update_defaults is not None:
        if spec is not None or defaults is not None or code_parm != 'snippet':
            raise ValueError('update_defaults is exclusive with spec/defaults/code_parm scanning')
        return _update_spare_defaults(n, update_defaults)
    if spec is not None:
        if not isinstance(spec, (list, tuple)) or not spec:
            raise ValueError("spec 必须是非空 list")
        names = set()
        templates = [
            _spare_spec_template(item, f"spec[{index}]", names)
            for index, item in enumerate(spec)
        ]
        conflicts = sorted(
            name for name in names
            if n.parm(name) is not None or n.parmTuple(name) is not None
        )
        if conflicts:
            raise ValueError(
                f"节点 {n.path()} 已存在同名参数/文件夹：{conflicts}；"
                "显式 spec 不做隐式覆盖"
            )
        group = n.parmTemplateGroup()
        for template in templates:
            group.append(template)
        refreshed = _apply_spare_interface(n, group, code_parm)
        leaves = []
        def collect(items):
            for item in items:
                if str(item.get("type", "")).strip().lower() == "folder":
                    collect(item.get("parms", []))
                else:
                    leaves.append(item["name"])
        collect(spec)
        return {
            "node": n.path(),
            "mode": "spec",
            "created": sorted(names),
            "refreshed_code_parm": refreshed,
            "leaf_values": {
                name: _val(n.parm(name).eval()) for name in leaves
            },
        }
    defaults = {} if defaults is None else defaults
    if not isinstance(defaults, dict):
        raise ValueError("defaults 必须是 dict：{参数名: 默认值}")
    code_parameter = n.parm(code_parm)
    if code_parameter is None:
        raise ValueError(
            f"节点 {n.path()} 没有代码参数 {code_parm!r}；"
            "先用 list_parms 找真实代码参数名"
        )
    code = code_parameter.evalAsString()
    pattern = re.compile(
        r"\b(?P<func>ch|chf|chi|chv|chs)\s*\(\s*['\"](?P<name>[A-Za-z_]\w*)['\"]"
    )
    references = {}
    for match in pattern.finditer(code):
        references.setdefault(match.group("name"), match.group("func"))
    unsupported = sorted(set(
        match.group(1) for match in re.finditer(
            r"\b(chramp|chdict|chsop|chsoplist)\s*\(", code
        )
    ))
    if not references:
        return {
            "node": n.path(), "code_parm": code_parm,
            "created": [], "existing": [], "unsupported": unsupported,
        }
    group = n.parmTemplateGroup()
    templates = []
    created_names = []
    existing = []
    for name, func in references.items():
        if n.parm(name) is not None or n.parmTuple(name) is not None:
            existing.append(name)
            continue
        label = name.replace("_", " ").title()
        default = defaults.get(name)
        if func == "chi":
            value = int(0 if default is None else default)
            template = hou.IntParmTemplate(name, label, 1, default_value=(value,))
        elif func == "chv":
            if default is None:
                values = (0.0, 0.0, 0.0)
            elif isinstance(default, (list, tuple)) and len(default) == 3:
                values = tuple(float(value) for value in default)
            else:
                raise ValueError(f"chv 参数 {name!r} 的默认值必须是 3 分量 list/tuple")
            template = hou.FloatParmTemplate(name, label, 3, default_value=values)
        elif func == "chs":
            value = "" if default is None else str(default)
            template = hou.StringParmTemplate(name, label, 1, default_value=(value,))
        else:  # ch / chf
            value = float(0.0 if default is None else default)
            template = hou.FloatParmTemplate(name, label, 1, default_value=(value,))
        templates.append(template)
        created_names.append(name)
    for template in templates:
        group.append(template)
    refreshed = _apply_spare_interface(n, group, code_parm) if templates else None
    applied = {}
    for name in created_names:
        if name in defaults:
            result = set_parm(n, name, defaults[name])
            applied[name] = result.get("value", result.get("expression"))
    return {
        "node": n.path(),
        "code_parm": code_parm,
        "references": references,
        "created": created_names,
        "existing": existing,
        "defaults_applied": applied,
        "unsupported": unsupported,
        "refreshed_code_parm": refreshed,
    }


# --- asset 域（HDA / 数字资产） ---------------------------------------------

_HDA_MANAGED_TAG = "dsh_houdini::managed"
_PARM_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _hda_definition(node) -> tuple[hou.Node, hou.HDADefinition]:
    n = _resolve(node)
    definition = n.type().definition()
    if definition is None:
        raise ValueError(
            f"节点 '{n.path()}' 不是数字资产（node.type().definition() 为 None）；"
            "请先用 hda_create 把 subnet 转为 HDA"
        )
    return n, definition


def _default_hda_file(name: str) -> str:
    hip_path = hou.hipFile.path()
    hip_dir = os.path.dirname(hip_path)
    if not hip_dir or os.path.basename(hip_path).lower() == "untitled.hip":
        raise ValueError(
            "当前 hip 尚未保存，无法推导默认 HDA 位置；请先保存 hip，"
            "或显式传 hda_file"
        )
    file_stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", name).strip("._") or "asset"
    return os.path.join(hip_dir, "otls", file_stem + ".hda")


def _native_definition_identity(node, libraries):
    """Trust only an unchanged locked definition shipped inside this HFS."""
    definition = node.type().definition()
    if definition is None or not node.isLockedHDA() or not node.matchesCurrentDefinition():
        return None
    hfs = os.path.realpath(hou.expandString('$HFS'))
    library = os.path.realpath(definition.libraryFilePath())
    try:
        if os.path.commonpath([hfs, library]) != hfs or not os.path.isfile(library):
            return None
    except ValueError:
        return None
    if library not in libraries:
        size = os.path.getsize(library)
        if size > 32 * 1024 * 1024 or libraries.get('_bytes', 0) + size > 64 * 1024 * 1024:
            return None
        with open(library, 'rb') as stream:
            libraries[library] = hashlib.sha256(stream.read()).hexdigest()
        libraries['_bytes'] = libraries.get('_bytes', 0) + size
    return (node.type().category().name(), node.type().name(), library, libraries[library])


def _snapshot_native_conversion(root):
    """Capture wholly owned, locked native subtrees BEFORE conversion.

    A path is only a slot within an unchanged native definition rooted at a
    surviving owned HOM identity, never independent proof of ownership.
    """
    owner = _OWNED_NODE_SESSIONS.get(int(root.sessionId()))
    if owner is None or owner['session'] != _ACTIVE_OWNER_SESSION:
        return []
    candidates = list(root.allSubChildren())
    if len(candidates) > 512:
        return []
    libraries, captured, covered = {}, [], set()
    for anchor in candidates:
        aid = int(anchor.sessionId())
        if aid in covered:
            continue
        entry = _OWNED_NODE_SESSIONS.get(aid)
        if not entry or entry['session'] != _ACTIVE_OWNER_SESSION:
            continue
        definition = _native_definition_identity(anchor, libraries)
        if definition is None:
            continue
        members = [anchor, *anchor.allSubChildren(sync_delayed_definition=True)]
        if any(not (e := _OWNED_NODE_SESSIONS.get(int(n.sessionId())))
               or e['session'] != _ACTIVE_OWNER_SESSION
               or n.userData(_RENDER_OWNER_KEY) == _RENDER_OWNER_VALUE for n in members):
            continue
        inventory = {anchor.relativePathTo(n): {
            'identity': int(n.sessionId()), 'type': (n.type().category().name(), n.type().name()),
            'owner': dict(_OWNED_NODE_SESSIONS[int(n.sessionId())])} for n in members[1:]}
        captured.append((aid, definition, inventory))
        covered.update(int(n.sessionId()) for n in members)
    return captured


def _reconcile_native_conversion(captured):
    """Transfer only extinct identities in the exact captured native inventory."""
    libraries, materialized, transferred = {}, [], []
    for aid, definition, before in captured:
        anchor = hou.nodeBySessionId(aid)
        if anchor is None or _OWNED_NODE_SESSIONS.get(aid, {}).get('session') != _ACTIVE_OWNER_SESSION \
                or _native_definition_identity(anchor, libraries) != definition:
            continue
        anchor.allSubChildren(sync_delayed_definition=True)
        materialized.append((aid, definition, before))
    # Recheck actual definition bytes after ALL materialization, not a cached
    # pre-materialization digest. No further delayed loading during transfers.
    libraries = {}
    for aid, definition, before in materialized:
        anchor = hou.nodeBySessionId(aid)
        if anchor is None or _OWNED_NODE_SESSIONS.get(aid, {}).get('session') != _ACTIVE_OWNER_SESSION \
                or _native_definition_identity(anchor, libraries) != definition:
            continue
        after = {anchor.relativePathTo(n): n for n in anchor.allSubChildren()}
        if set(before) != set(after) or any(
                (n.type().category().name(), n.type().name()) != before[slot]['type']
                or n.userData(_RENDER_OWNER_KEY) == _RENDER_OWNER_VALUE for slot, n in after.items()):
            continue
        for slot, n in after.items():
            old = before[slot]
            new_id = int(n.sessionId())
            if old['owner']['session'] != _ACTIVE_OWNER_SESSION or old['identity'] == new_id or hou.nodeBySessionId(old['identity']) is not None:
                continue
            # Never overwrite a registered identity, even one with copied tags.
            if new_id in _OWNED_NODE_SESSIONS:
                continue
            _OWNED_NODE_SESSIONS[new_id] = dict(old['owner'])
            _OWNED_NODE_SESSIONS.pop(old['identity'], None)
            if _CREATION_JOURNAL is not None and old['identity'] in _CREATION_JOURNAL:
                _CREATION_JOURNAL.add(new_id)
            transferred.append({'node': n.path(), 'previous_identity': old['identity'],
                                'identity': new_id, 'native_anchor_identity': aid})
    return transferred


def hda_create(
    node,
    name: str,
    description: str | None = None,
    hda_file: str | None = None,
    min_inputs: int = 0,
    max_inputs: int = 0,
    replace: bool = False,
    allow_foreign: str | None = None,
    *,
    max_outputs: int | None = None,
) -> dict:
    """把已有节点（通常 subnet）转为 HDA；默认写到 ``$HIP/otls``。

    同名已安装类型或已存在目标文件在写前拒绝。replace=True不再支持；维护已有
    工具用hda_version在来源库追加原生版本，再hda_switch_version切换指定实例。
    hda_fork仅用于独立衍生新工具；项目新工具默认$HIP/otls，共享新工具指定package资源路径。
    max_outputs可选1..64，None保留原生默认；这是端口上限，不会自动接线。
    实例spare不保证进入定义；返回pending_spare_parameters与原地hda_edit('promote')指引。
    不以创建成功替代新实例/公共输出验证；转换只接续可证明来自同一锁定原生定义的自有后代。
    """
    n = _resolve(node)
    _require_owned(n, "hda_create", allow_foreign)
    if type(replace) is not bool:
        raise ValueError('replace must be boolean')
    if replace:
        raise ValueError('hda_create replace=True is not supported: it would destroy shared instances/definitions. '
                         'Maintain the source with hda_version, then hda_switch_version on selected instances. Use hda_fork only for an independent derived tool.')
    if not isinstance(name, str) or not name.strip():
        raise ValueError("name 必须是非空 HDA 类型名")
    name = name.strip()
    if not isinstance(min_inputs, int) or not isinstance(max_inputs, int):
        raise ValueError("min_inputs/max_inputs 必须是整数")
    if min_inputs < 0 or max_inputs < min_inputs:
        raise ValueError(
            f"输入数不合法：需要 0 <= min_inputs <= max_inputs，"
            f"收到 {min_inputs}/{max_inputs}"
        )
    if max_outputs is not None and (type(max_outputs) is not int or not 1 <= max_outputs <= 64):
        raise ValueError('max_outputs must be an integer in 1..64 or None (native default)')

    category = n.type().category()
    existing_type = category.nodeTypes().get(name)
    if existing_type is not None:
        definitions = list(existing_type.allInstalledDefinitions())
        files = sorted({d.libraryFilePath() for d in definitions})
        raise ValueError(f"HDA 类型 '{name}' 已存在或为原生类型；definitions={files}。"
                         "已有工具用hda_version在来源库追加版本，再hda_switch_version；独立衍生才用hda_fork。")

    target = _default_hda_file(name) if hda_file is None else hou.expandString(str(hda_file))
    target = os.path.abspath(target)
    from dsh_hda_interfaces import require_library_location
    require_library_location(target)
    if os.path.lexists(target):
        raise ValueError(f'HDA target file already exists: {target}; hda_create only creates new tools/libraries. '
                         'For existing tool maintenance use hda_version to append a type version in its actual source library.')
    parent_dir = os.path.dirname(target)
    if parent_dir:
        os.makedirs(parent_dir, exist_ok=True)

    source_identity = int(n.sessionId())
    source_owner = _OWNED_NODE_SESSIONS.get(source_identity)
    native_before = _snapshot_native_conversion(n)
    created = n.createDigitalAsset(
        name=name,
        hda_file_name=target,
        description=description,
        min_num_inputs=min_inputs,
        max_num_inputs=max_inputs,
        change_node_type=True,
        create_backup=True,
    )
    definition = created.type().definition()
    if definition is None:
        raise RuntimeError(f"createDigitalAsset 返回后类型 '{name}' 没有 definition")
    if max_outputs is not None:
        definition.setMaxNumOutputs(max_outputs)
    from dsh_hda_interfaces import register_created_definition
    register_created_definition(definition)
    # Conversion invalidates native delayed internals (e.g. a Wrangle's VOP).
    # Materialize only captured native anchors within this serialized mutation,
    # never arbitrary user definitions or a future cook/adoption rule.
    native_transfers = _reconcile_native_conversion(native_before)
    # Conversion may replace the root HOM identity. Transfer only its trusted
    # existing provenance; never adopt foreign descendants or an allowed foreign source.
    if source_owner is not None:
        _OWNED_NODE_SESSIONS[int(created.sessionId())] = dict(source_owner)
        if _CREATION_JOURNAL is not None and source_identity in _CREATION_JOURNAL:
            _CREATION_JOURNAL.add(int(created.sessionId()))
        if hou.nodeBySessionId(source_identity) is None:
            _OWNED_NODE_SESSIONS.pop(source_identity, None)
    pending_spares = [p.name() for p in created.spareParms()
                      if definition.parmTemplateGroup().find(p.name()) is None]
    return {
        "node": created.path(),
        "type": created.type().name(),
        "description": created.type().description(),
        "hda_file": definition.libraryFilePath(),
        "min_inputs": definition.minNumInputs(),
        "max_inputs": definition.maxNumInputs(),
        "max_outputs": definition.maxNumOutputs(),
        "instance_interface_entries": len(created.parmTemplateGroup().entries()),
        "definition_interface_entries": len(definition.parmTemplateGroup().entries()),
        "pending_spare_parameters": pending_spares[:64],
        "pending_spare_parameter_count": len(pending_spares),
        "native_identity_transfers": native_transfers,
        "next_action": ("Instance spare controls are not yet in the definition. Read hda_edit help; "
                        "preview unlock if locked, then promote with expected_plan to migrate in place. "
                        "Verify a fresh instance before considering replacement."
                        if pending_spares else "Verify fresh-instance parameters and public outputs; later internal edits require hda_edit save."),
        "verification_scope": "definition created; spare migration, public outputs and fresh-instance behavior require separate verification",
        "replaced": False,
        "destroyed_instances": [],
        "removed_definitions": [],
    }


def hda_fork(node, name: str, hda_file: str, description: str | None = None) -> dict:
    """Copy the source's actual HDA definition into a NEW type and NEW library.

    Reading the source does not require node ownership. Never copies unsaved
    instance edits, changes the original definition, migrates original instances,
    or creates an instance. The new type is installed only in this process; use
    tab_create with the returned exact type and verify its public behavior.
    """
    n, source = _hda_definition(node)
    if not isinstance(name, str) or not name.strip():
        raise ValueError('name must be an explicit nonempty new HDA type name')
    name = name.strip()
    category = n.type().category()
    if name == n.type().name() or name in category.nodeTypes():
        raise ValueError('hda_fork requires a new type name; never shadows an installed type or migrates its instances')
    if not isinstance(hda_file, str) or not hda_file.strip():
        raise ValueError('hda_file must be an explicit new independent library path')
    if description is not None and (not isinstance(description, str) or not description.strip()):
        raise ValueError('description must be a nonempty string or None')
    target = os.path.abspath(hou.expandString(hda_file))
    from dsh_hda_interfaces import require_library_location
    require_library_location(target)
    if os.path.lexists(target):
        raise ValueError(f'HDA target file already exists: {target}; fork requires a new independent library')
    os.makedirs(os.path.dirname(target), exist_ok=True)
    source_file = source.libraryFilePath()
    try:
        source.copyToHDAFile(target, new_name=name, new_menu_name=description)
        hou.hda.installFile(target)
        fork_type = category.nodeTypes().get(name)
        definition = fork_type.definition() if fork_type else None
        if definition is None or os.path.normcase(os.path.realpath(definition.libraryFilePath())) != os.path.normcase(os.path.realpath(target)):
            raise RuntimeError('fork did not resolve to its newly created library')
        from dsh_hda_interfaces import register_created_definition
        register_created_definition(definition)
    except Exception:
        # Only this absent-before file/new type is eligible for failed-copy cleanup.
        for loaded in hou.hda.loadedFiles():
            if os.path.normcase(os.path.realpath(loaded)) == os.path.normcase(os.path.realpath(target)):
                hou.hda.uninstallFile(loaded)
        if os.path.isfile(target):
            os.unlink(target)
        raise
    return {'ok': True, 'category': category.name(), 'type': definition.nodeTypeName(),
            'description': definition.description(), 'hda_file': definition.libraryFilePath(),
            'source_node': n.path(), 'source_type': n.type().name(), 'source_library': source_file,
            'copied': 'current definition only; unsaved instance changes excluded',
            'source_instances_migrated': 0, 'instances_created': 0,
            'next_action': 'Create an instance with tab_create using this exact type, then verify controls, public outputs and dependencies.'}


def hda_version(node, version: str, *, dry_run=False, allow_foreign=None) -> dict:
    """Append a native ::version type to the actual SOURCE library; preserve older definitions.

    version is a numeric suffix such as 1.1, not HDADefinition Version metadata.
    Copies saved definition only, preserves scope/namespace, never migrates instances.
    Refuses duplicate types; restores library/new type on failure. Foreign library
    needs one-call allow_foreign and is not adopted by creating a version inside it.
    Then hda_switch_version the selected instance before editing the new definition.
    """
    from dsh_hda_versions import create_version
    return create_version(node, version, dry_run=dry_run, allow_foreign=allow_foreign)


def hda_switch_version(node, type_name: str, *, dry_run=False, allow_foreign=None) -> dict:
    """Switch one locked HDA instance to an exact installed version of the same family.

    Native changeNodeType keeps name/common parameter channels and connections,
    loads target contents; never migrates other instances. For a current-session
    instance, only internal identities newly created by this switch are registered;
    existing identities and foreign instances never gain ownership from a switch.
    Read tool_inspect type_versions and source libraries first; dry_run reports scope.
    Unlocked contents require hda_edit save/lock or explicit discard before switching.
    Node and replaced descendants require ownership or one-call allow_foreign.
    Scene undo covers scene edits only; arbitrary asset callback effects are excluded.
    """
    from dsh_hda_versions import switch_version
    return switch_version(node, type_name, dry_run=dry_run, allow_foreign=allow_foreign)


def hda_edit(node, action, *, dry_run=False, expected_plan=None, discard_changes=False, allow_foreign=None) -> dict:
    """Preview-bound unlock/save/lock/promote of a disk HDA, never flatten/unpack.

    First dry_run=True, review plan_sha256/affected_instances; apply with expected_plan.
    lock requires discard_changes=True for unmatched contents; discarded descendants
    must also be owned/explicitly authorized. Unlock never grants descendant ownership.
    save requires unlocked source with definition interface (no spare overlays), checks
    every affected instance, restores this call's definition/library on write failure.
    promote moves the source additive spare interface into the definition while
    preserving existing root channels/keys/locks; rejects other instance overlays.
    <=64 instances/512 descendants/32MiB library/2MiB source. No cook/GUI/semantic proof.
    """
    from dsh_hda_lifecycle import edit
    return edit(node, action, dry_run=dry_run, expected_plan=expected_plan,
                discard_changes=discard_changes, allow_foreign=allow_foreign)


def _enum_name(value) -> str:
    try:
        return value.name()
    except Exception:
        return str(value).split(".")[-1]


def _template_info(template, depth: int, max_depth: int) -> dict:
    entry = {
        "name": template.name(),
        "label": template.label(),
        "type": _enum_name(template.type()),
    }
    for key, getter in (
        ("hidden", "isHidden"),
        ("join_next", "joinsWithNext"),
        ("hide_label", "isLabelHidden"),
        ("help", "help"),
        ("default", "defaultValue"),
        ("menu_items", "menuItems"),
        ("menu_labels", "menuLabels"),
        ("column_labels", "columnLabels"),
        ("components", "numComponents"),
        ("min", "minValue"),
        ("max", "maxValue"),
        ("min_strict", "minIsStrict"),
        ("max_strict", "maxIsStrict"),
        ("callback", "scriptCallback"),
        ("menu_generator", "itemGeneratorScript"),
        ("default_expression", "defaultExpression"),
    ):
        try:
            value = getattr(template, getter)()
        except Exception:
            continue
        if value not in (None, "", (), [], {}):
            entry[key] = _val(value)
    try:
        conditions = {
            _enum_name(k): v for k, v in template.conditionals().items()
        }
        if conditions:
            entry["conditionals"] = conditions
    except Exception:
        pass
    try:
        tags = template.tags()
        if tags:
            entry["tags"] = dict(tags)
    except Exception:
        pass
    for key, getter in (("callback_language", "scriptCallbackLanguage"),
                        ("menu_generator_language", "itemGeneratorScriptLanguage"),
                        ("menu_type", "menuType"), ("string_type", "stringType"),
                        ("file_type", "fileType"), ("look", "look"), ("naming_scheme", "namingScheme")):
        try:
            entry[key] = _enum_name(getattr(template, getter)())
        except (AttributeError, hou.Error):
            pass
    if isinstance(template, hou.FolderParmTemplate):
        entry["folder_type"] = _enum_name(template.folderType())
        entry['tab_conditionals'] = {_enum_name(k): v for k, v in template.tabConditionals().items()}
        entry['ends_tab_group'] = template.endsTabGroup()
        children = list(template.parmTemplates())
        if depth < max_depth:
            entry["parms"] = [
                _template_info(child, depth + 1, max_depth) for child in children
            ]
        elif children:
            entry["parms_omitted"] = len(children)
    if isinstance(template, hou.RampParmTemplate):
        entry['ramp_type'] = _enum_name(template.parmType())
        entry['show_controls'] = template.showsControls()
        entry['basis'] = _enum_name(template.defaultBasis())
    return entry


def bind_controls(controller, bindings: list, *, dry_run: bool = False,
                  expected_plan: str | None = None, replace_existing: bool = False,
                  allow_foreign: str | None = None) -> dict:
    """Bind explicit numeric controls to target parameter paths; never chooses targets.

    bindings=[{source:'control_name',target:'/obj/node/parm',scale:1,offset:0}].
    First dry_run=True; apply requires its expected_plan=plan_sha256. Protects
    existing keys/expressions unless replace_existing=True. Source expressions,
    menus/callbacks/multiparms and source-target chains in a batch are unsupported.
    Integer targets need integer sources and scale/offset. Failure restores target
    channels; expression/value readback does not verify final domain geometry.
    """
    from dsh_control_bindings import bind_controls as bind
    return bind(controller, bindings, dry_run, expected_plan, replace_existing, allow_foreign)


def parameter_ui(node, max_depth: int = 6, include_state: bool = False, analyze_ui: bool = False) -> dict:
    """只读任意节点的实例/定义模板树与interface_sha256。

    analyze_ui=True给出计数/深度、标题/条件引用、菜单token与密集行建议；仅分析
    返回树，截断见omitted_children。不求值表达式/菜单，不cook或自动修复。
    """
    n = _resolve(node)
    if type(include_state) is not bool:
        raise ValueError('include_state must be boolean')
    if type(analyze_ui) is not bool:
        raise ValueError('analyze_ui must be boolean')
    if not isinstance(max_depth, int) or max_depth < 0 or max_depth > 20:
        raise ValueError("max_depth 必须是 0..20 的整数")
    definition = n.type().definition()
    out = {
        "node": n.path(),
        "category": n.type().category().name(),
        "type": n.type().name(),
        "description": n.type().description(),
        "definition": None,
        "interface": [
            _template_info(entry, 0, max_depth)
            for entry in n.parmTemplateGroup().entries()
        ],
    }
    if definition is not None:
        from dsh_hda_interfaces import interface_revision
        out['interface_sha256'] = interface_revision(n)
        sections = []
        for name, section in sorted(definition.sections().items()):
            try:
                size = len(section.contents())
            except Exception:
                size = None
            sections.append({"name": name, "chars": size})
        out["definition"] = {
            "library_file": definition.libraryFilePath(),
            "node_type": definition.nodeTypeName(),
            "description": definition.description(),
            "version": definition.version(),
            "min_inputs": definition.minNumInputs(),
            "max_inputs": definition.maxNumInputs(),
            "max_outputs": definition.maxNumOutputs(),
            "sections": sections,
            "interface": [_template_info(entry, 0, max_depth)
                          for entry in definition.parmTemplateGroup().entries()],
        }
        out['matches_definition'] = n.matchesCurrentDefinition()
        out['locked'] = n.isLockedHDA()
    if include_state:
        from dsh_hda_interfaces import parameter_states
        out['parameter_states'] = parameter_states(n)
    if analyze_ui:
        from dsh_parameter_ui import analyze_ui as inspect_ui
        out['ui_analysis'] = inspect_ui(out['interface'])
        out['ui_analysis']['max_depth_requested'] = max_depth
    return out


def _section_contents(definition: hou.HDADefinition, section: str) -> str:
    if not isinstance(section, str) or not section.strip():
        raise ValueError("section 必须是非空字符串")
    section = section.strip()
    sections = definition.sections()
    if section not in sections:
        raise ValueError(
            f"HDA 没有 section {section!r}；现有：{sorted(sections)}"
        )
    return sections[section].contents()


def hda_get_section(node, section: str = "PythonModule") -> dict:
    """读取 HDA section 全文；不存在时列出现有 section 名。"""
    n, definition = _hda_definition(node)
    code = _section_contents(definition, section)
    return {
        "node": n.path(),
        "section": section,
        "code": code,
        "chars": len(code),
        "sha256": hashlib.sha256(code.encode("utf-8")).hexdigest(),
    }


def _validate_section_code(section: str, code: str) -> None:
    if not isinstance(code, str):
        raise ValueError("code 必须是字符串")
    if section.lower().endswith("pythonmodule"):
        try:
            compile(code, f"<HDA:{section}>", "exec")
        except SyntaxError as e:
            source = (e.text or "").strip()
            where = f"line {e.lineno}" + (f", column {e.offset}" if e.offset else "")
            raise ValueError(
                f"{section} Python 语法错误（{where}）：{e.msg}"
                + (f"；{source}" if source else "")
            ) from e


def _write_hda_section(definition: hou.HDADefinition, section: str, code: str) -> dict:
    _validate_section_code(section, code)
    before = None
    existing = definition.sections().get(section)
    if existing is not None:
        before = existing.contents()
    definition.addSection(section, code)
    actual = _section_contents(definition, section)
    if actual != code:
        raise RuntimeError(
            f"HDA section {section!r} 写后读回不一致："
            f"expected {len(code)} chars, got {len(actual)}"
        )
    return {
        "section": section,
        "changed": before != code,
        "chars": len(code),
        "lines": code.count("\n") + (1 if code else 0),
        "sha256": hashlib.sha256(code.encode("utf-8")).hexdigest(),
    }


def hda_set_section(node, section: str, code: str,
                    allow_foreign: str | None = None) -> dict:
    """Shared-definition/library authorization and recovery; PythonModule compiles first."""
    n, definition = _hda_definition(node)
    _require_owned(n, "hda_set_section", allow_foreign)
    if not isinstance(section, str) or not section.strip():
        raise ValueError("section 必须是非空字符串")
    section = section.strip()
    _validate_section_code(section, code)
    from dsh_hda_interfaces import definition_write_guard
    with definition_write_guard(n, 'hda_set_section', allow_foreign):
        out = _write_hda_section(definition, section, code)
    out["node"] = n.path()
    return out


def hda_patch_section(
    node,
    section: str,
    old: str,
    new: str,
    count: int = 1,
    allow_foreign: str | None = None,
) -> dict:
    """按唯一锚点局部替换 HDA section，拒绝缺失或歧义锚点。"""
    n, definition = _hda_definition(node)
    _require_owned(n, "hda_patch_section", allow_foreign)
    if not isinstance(old, str) or not old:
        raise ValueError("old 必须是非空字符串（空锚点会产生歧义）")
    if not isinstance(new, str):
        raise ValueError("new 必须是字符串")
    if not isinstance(count, int) or count <= 0:
        raise ValueError("count 必须是正整数")
    source = _section_contents(definition, section)
    actual_count = source.count(old)
    if actual_count != count:
        raise ValueError(
            f"section {section!r} 中锚点期望出现 {count} 次，实际 {actual_count} 次；"
            "0 次说明锚点过期，多于期望说明锚点不唯一，请扩大 old 上下文"
        )
    patched = source.replace(old, new, count)
    _validate_section_code(section, patched)
    from dsh_hda_interfaces import definition_write_guard
    with definition_write_guard(n, 'hda_patch_section', allow_foreign):
        out = _write_hda_section(definition, section, patched)
    out.update({"node": n.path(), "replacements": count})
    return out


def _spec_name(item: dict, path: str, multiparm_depth: int = 0) -> str:
    name = item.get("name")
    if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_#]*', name) or name.count('#') != multiparm_depth:
        raise ValueError(
            f"{path}.name requires a stable identifier and {multiparm_depth} multiparm # placeholders, received {name!r}"
        )
    return name


def _menu_data(item: dict, path: str) -> tuple[list[str], list[str]]:
    menu = item.get("menu")
    if not isinstance(menu, dict):
        raise ValueError(f"{path}.menu 必须是 {{items:[...], labels:[...]}}")
    items = menu.get("items")
    labels = menu.get("labels", items)
    if not isinstance(items, (list, tuple)) or not items:
        raise ValueError(f"{path}.menu.items 必须是非空 list")
    if not isinstance(labels, (list, tuple)) or len(labels) != len(items):
        raise ValueError(f"{path}.menu.labels 必须与 items 等长")
    return [str(x) for x in items], [str(x) for x in labels]


def _normalize_hide_when(value, path: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{path}.hide_when 必须是非空字符串")
    value = value.strip()
    if not (value.startswith("{") and value.endswith("}")):
        value = "{ " + value + " }"
    return value


def _apply_template_common(template, item: dict, path: str, conditions: dict) -> None:
    help_text = item.get("help")
    if help_text is not None:
        template.setHelp(str(help_text))
    if item.get("join_next"):
        template.setJoinWithNext(True)
    hide_when = _normalize_hide_when(item.get("hide_when"), path)
    if hide_when is not None:
        template.setConditional(hou.parmCondType.HideWhen, hide_when)
        conditions[template.name()] = hide_when
    disable_when = _normalize_hide_when(item.get('disable_when'), path)
    if disable_when:
        template.setConditional(hou.parmCondType.DisableWhen, disable_when)
    if 'hidden' in item:
        template.hide(bool(item['hidden']))
    if 'hide_label' in item:
        template.setLabelHidden(bool(item['hide_label']))
    tags = dict(template.tags())
    user_tags = item.get("tags", {})
    if not isinstance(user_tags, dict):
        raise ValueError(f"{path}.tags 必须是 dict")
    tags.update({str(k): str(v) for k, v in user_tags.items()})
    tags[_HDA_MANAGED_TAG] = "1"
    template.setTags(tags)


def _build_interface_template(
    item: dict,
    path: str,
    names: set,
    conditions: dict,
    multiparm_depth: int = 0,
):
    if not isinstance(item, dict):
        raise ValueError(f"{path} 必须是 dict")
    kind = str(item.get("type", "")).strip().lower()
    if kind not in {
        "folder", "separator", "toggle", "int", "float", "string", "button", "menu", "ramp", "label"
    }:
        raise ValueError(
            f"{path}.type 不支持 {kind!r}；可用 folder/separator/toggle/int/float/"
            "string/button/menu"
        )
    name = _spec_name(item, path, multiparm_depth)
    if name in names:
        raise ValueError(f"参数/文件夹名 {name!r} 重复（Houdini 参数名全局唯一）")
    names.add(name)
    label = str(item.get("label", name))

    if kind == "folder":
        folder_type = str(item.get("folder_type", "simple")).strip().lower()
        folder_types = {
            "simple": hou.folderType.Simple,
            "tabs": hou.folderType.Tabs,
            "collapsible": hou.folderType.Collapsible,
            "multiparm_list": hou.folderType.MultiparmBlock,
            "multiparm_tabs": hou.folderType.TabbedMultiparmBlock,
            "multiparm_scroll": hou.folderType.ScrollingMultiparmBlock,
        }
        if folder_type not in folder_types:
            raise ValueError(f"{path}.folder_type 只能是 {sorted(folder_types)}")
        children = item.get("parms", [])
        if not isinstance(children, (list, tuple)):
            raise ValueError(f"{path}.parms 必须是 list")
        template = hou.FolderParmTemplate(
            name, label, folder_type=folder_types[folder_type], ends_tab_group=bool(item.get('ends_tab_group', False))
        )
        is_multi = folder_type.startswith('multiparm_')
        if is_multi:
            count = item.get('default', 0)
            if type(count) is not int or not 0 <= count <= 64:
                raise ValueError('multiparm default count must be 0..64')
            template.setDefaultValue(count)
        for field, condition in [('tab_hide_when', hou.parmCondType.HideWhen), ('tab_disable_when', hou.parmCondType.DisableWhen)]:
            if item.get(field):
                if is_multi:
                    raise ValueError('tab conditionals are unsupported on multiparm folders')
                template.setTabConditional(condition, _normalize_hide_when(item[field], path))
        for index, child in enumerate(children):
            template.addParmTemplate(
                _build_interface_template(
                    child, f"{path}.parms[{index}]", names, conditions, multiparm_depth + int(is_multi)
                )
            )
    elif kind == "separator":
        template = hou.SeparatorParmTemplate(name, label)
    elif kind == 'label':
        template = hou.LabelParmTemplate(name, label, column_labels=(label,))
    elif kind == 'ramp':
        ramp_type = item.get('ramp_type', 'float')
        if ramp_type not in ('float', 'color'):
            raise ValueError('ramp_type must be float/color')
        basis = item.get('basis', 'linear')
        bases = {'linear': hou.rampBasis.Linear, 'constant': hou.rampBasis.Constant,
                 'catmullrom': hou.rampBasis.CatmullRom, 'bspline': hou.rampBasis.BSpline}
        if basis not in bases:
            raise ValueError('unsupported ramp basis')
        points = item.get('points', 2)
        if type(points) is not int or not 2 <= points <= 16:
            raise ValueError('ramp points must be 2..16')
        template = hou.RampParmTemplate(name, label,
            hou.rampParmType.Float if ramp_type == 'float' else hou.rampParmType.Color,
            default_value=points, default_basis=bases[basis], show_controls=bool(item.get('show_controls', False)))
    elif kind == "toggle":
        template = hou.ToggleParmTemplate(
            name, label, default_value=bool(item.get("default", False))
        )
    elif kind in ("int", "float"):
        components = item.get('components', 1)
        if type(components) is not int or not 1 <= components <= 4:
            raise ValueError('numeric components must be 1..4')
        default = item.get("default", 0 if components == 1 else [0]*components)
        if components > 1 and (not isinstance(default, (list, tuple)) or len(default) != components):
            raise ValueError('tuple default must match components')
        values = [default] if components == 1 else default
        if any(type(v) not in (int, float) or not math.isfinite(v) or kind == 'int' and type(v) is not int for v in values):
            raise ValueError('numeric defaults must be finite and match numeric type')
        minimum = item.get("min", 0)
        maximum = item.get("max", 10)
        if kind == "float" and "menu" in item:
            raise ValueError(
                f"{path}: Houdini FloatParmTemplate 不支持菜单；"
                "需要菜单请用 int+menu（值为索引）或 type=menu；string只存文本，不创建菜单"
            )
        kwargs = {
            "default_value": tuple(float(v) for v in values) if kind == "float" else tuple(values),
            "min": float(minimum) if kind == "float" else int(minimum),
            "max": float(maximum) if kind == "float" else int(maximum),
            "min_is_strict": bool(item.get("min_strict", False)),
            "max_is_strict": bool(item.get("max_strict", False)),
        }
        if kind == "int" and "menu" in item:
            if components != 1:
                raise ValueError('menus require scalar components')
            items, labels = _menu_data(item, path)
            index = int(default)
            if not 0 <= index < len(items):
                raise ValueError(
                    f"{path}.default={index} 超出菜单索引 0..{len(items) - 1}；"
                    "Houdini 的 Int 菜单存索引，不存 item token"
                )
            kwargs.update(menu_items=items, menu_labels=labels)
        cls = hou.FloatParmTemplate if kind == "float" else hou.IntParmTemplate
        template = cls(name, label, components, **kwargs)
        look = item.get('look', 'regular')
        if look not in ('regular', 'vector', 'color') or look == 'color' and components not in (3, 4):
            raise ValueError('numeric look must be regular/vector/color (color needs 3/4 components)')
        template.setLook({'regular': hou.parmLook.Regular, 'vector': hou.parmLook.Vector, 'color': hou.parmLook.ColorSquare}[look])
        if look == 'color':
            template.setNamingScheme(hou.parmNamingScheme.RGBA)
    elif kind == "string":
        default = str(item.get("default", ""))
        file_kind = item.get("file")
        string_kind = item.get('string_type', 'regular')
        if string_kind not in ('regular', 'node'):
            raise ValueError(f'{path}.string_type must be regular/node')
        if string_kind == 'node' and file_kind is not None:
            raise ValueError(f'{path}: node reference and file selector are mutually exclusive')
        kwargs = {"default_value": (default,)}
        if string_kind == 'node':
            kwargs['string_type'] = hou.stringParmType.NodeReference
        if file_kind is not None:
            file_key = str(file_kind).strip().lower()
            file_types = {
                "dir": hou.fileType.Directory,
                "geo": hou.fileType.Geometry,
                "alembic": hou.fileType.Geometry,
                "image": hou.fileType.Image,
                "any": hou.fileType.Any,
            }
            if file_key not in file_types:
                raise ValueError(f"{path}.file 只能是 {sorted(file_types)}")
            kwargs.update(
                string_type=hou.stringParmType.FileReference,
                file_type=file_types[file_key],
            )
        template = hou.StringParmTemplate(name, label, 1, **kwargs)
    elif kind == "button":
        callback = item.get("callback")
        if not isinstance(callback, str) or not callback.strip():
            raise ValueError(f"{path}.callback 必须是非空 Python 回调字符串")
        template = hou.ButtonParmTemplate(name, label)
        template.setScriptCallback(callback)
        template.setScriptCallbackLanguage(hou.scriptLanguage.Python)
    else:  # menu
        items, labels = _menu_data(item, path)
        default = int(item.get("default", 0))
        if not 0 <= default < len(items):
            raise ValueError(f"{path}.default 必须是菜单索引 0..{len(items) - 1}")
        template = hou.MenuParmTemplate(
            name, label, items, menu_labels=labels, default_value=default
        )

    _apply_template_common(template, item, path, conditions)
    return template


def _template_has_managed(template) -> bool:
    try:
        if template.tags().get(_HDA_MANAGED_TAG) == "1":
            return True
    except Exception:
        pass
    if isinstance(template, hou.FolderParmTemplate):
        return any(_template_has_managed(c) for c in template.parmTemplates())
    return False


def _standard_interface_entries(node: hou.Node) -> list:
    """取 HDA 源 subnet 的标准界面；找不到基型时保留未受本动词管理的旧条目。"""
    source_name = _enum_name(node.type().source()).lower()
    if source_name == "subnet":
        base_type = node.type().category().nodeTypes().get("subnet")
        if base_type is not None and base_type is not node.type():
            return [entry.clone() for entry in base_type.parmTemplateGroup().entries()]
    return [
        entry.clone() for entry in node.parmTemplateGroup().entries()
        if not _template_has_managed(entry)
    ]


def _all_template_names(templates) -> set:
    names = set()
    for template in templates:
        names.add(template.name())
        if isinstance(template, hou.FolderParmTemplate):
            names.update(_all_template_names(template.parmTemplates()))
    return names


def _balanced_block_end(text: str, start: int) -> int:
    brace = text.find("{", start)
    if brace < 0:
        raise ValueError("DialogScript parm 块缺少 '{'")
    depth = 0
    quote = None
    escaped = False
    for index in range(brace, len(text)):
        ch = text[index]
        if quote is not None:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = None
            continue
        if ch in ("'", '"'):
            quote = ch
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return index + 1
    raise ValueError("DialogScript parm 块大括号不平衡")


def _patch_dialog_hide_when(dialog: str, name: str, condition: str) -> str:
    block_re = re.compile(r"(?m)^[ \t]*parm[ \t]*\{[ \t]*$")
    name_re = re.compile(r"(?m)^[ \t]*name[ \t]+\"" + re.escape(name) + r"\"[ \t]*$")
    for match in block_re.finditer(dialog):
        end = _balanced_block_end(dialog, match.start())
        block = dialog[match.start():end]
        name_match = name_re.search(block)
        if name_match is None:
            continue
        escaped = condition.replace("\\", "\\\\").replace('"', '\\"')
        hide_re = re.compile(r"(?m)^(?P<indent>[ \t]*)hidewhen[ \t]+\".*\"[ \t]*$")
        existing = hide_re.search(block)
        if existing is not None:
            replacement = existing.group("indent") + f'hidewhen "{escaped}"'
            block = block[:existing.start()] + replacement + block[existing.end():]
        else:
            indent = re.match(r"[ \t]*", block[name_match.start():]).group(0)
            close_line = block.rfind("\n", 0, len(block) - 1) + 1
            newline = "\r\n" if "\r\n" in block else "\n"
            insertion = indent + f'hidewhen "{escaped}"' + newline
            block = block[:close_line] + insertion + block[close_line:]
        return dialog[:match.start()] + block + dialog[end:]
    raise ValueError(f"DialogScript 中找不到参数 {name!r} 的 parm 块")


def hda_set_interface(
    node,
    spec: list | None = None,
    keep_std: bool = True,
    hide_builtin_tabs: bool = False,
    allow_foreign: str | None = None,
    *,
    edits: list | None = None,
    expected_sha256: str | None = None,
    dry_run: bool = False,
    layout: list | None = None,
) -> dict:
    """按 JSON 安全 spec 声明式重建 HDA 参数面板并验证 conditional。

    原始spec字段（同样适用于create_spare_parms的layout，不适用于其简化spec）：
    每项必填type/name；label默认name。全局唯一稳定name，multiparm内每层含一个#。
    float/int: default为标量；components=2..4时default须等长数组；look=regular/vector/color，
    color要求3/4分量。min/max是建议范围，min_strict/max_strict才是硬限制。
    int+menu: menu={items:[token,...],labels:[label,...]}，default是整数索引，不是token；
    type=menu同样以整数索引指定default。float不接受menu，string不创建菜单。
    toggle: default布尔。string: default文本，可选file=dir/geo/alembic/image/any。
    folder: parms子项，folder_type=simple/tabs/collapsible/multiparm_list/multiparm_tabs/
    multiparm_scroll；multiparm的default为0..64条目数。separator/label只需type/name。
    ramp: ramp_type=float/color，points=2..16，basis=linear/constant/catmullrom/bspline，
    show_controls布尔。button必须给非空Python callback；创建不执行callback。
    通用可选字段：help/join_next/hidden/hide_label/tags/hide_when/disable_when。
    条件为Houdini条件字符串，例如{ enabled == 0 }，不是Python表达式。
    未列字段不要猜测；先用小layout及dry_run验证，不需要读取插件实现源码。

    最小示例（先预检，确认后原样应用；输出/绑定仍须单独实现）::

        layout = [{"type":"folder","name":"controls","parms":[
            {"type":"float","name":"width","default":1.0,"min":0.1,"max":5.0},
            {"type":"int","name":"mode","default":0,
             "menu":{"items":["draft","final"],"labels":["Draft","Final"]}},
            {"type":"float","name":"tint","components":3,"look":"color",
             "default":[0.6,0.3,0.1]}]}]
        hda_set_interface(node, layout=layout, dry_run=True)

    普通Null/子网的实例参数用create_spare_parms(node,layout=layout,dry_run=True)，
    不为创建控制面板强制转HDA。只读参数值/元数据用parameter_ui/read_parms。

    layout为可选组件列表，与spec/edits互斥，仍是整组重建。component支持section
    (name/label/parms, enabled?/collapsed?/header_parm?)、row(parms)、remap
    (name/label/enabled?/ramp_type?)、repeater(name/label/parms/style?/count?/label_ref?)。
    可混用普通spec；新增label/ramp、numeric components/look、multiparm与tab条件。
    dry_run=True只预检并返回展开interface/ui_analysis，不写入；各模式仍须exec。
    layout成功仍是整组替换、不保证旧通道保持；写后失败恢复本调用定义/实例界面/通道/库。
    定义写入与场景undo隔离，后续同exec失败不撤销已经成功的库写入；布局组件不代表业务功能。

    增量模式：spec省略，传edits=[{op:'update',name,fields}或{op:'add',spec,folder?}]
    并把parameter_ui返回的interface_sha256传为expected_sha256。update支持label/help/default/min/max/min_strict/
    max_strict/hidden/join_next/disable_when/hide_when。dry_run=True预览但仍须exec。
    所有受影响实例均检查ownership；保留旧通道值/keys/locks，新实例用新默认。
    不支持删除/改名/移动/类型转换/ramp/multiparm/实例界面覆盖；最多32项、64实例。
    同步失败恢复本调用的定义、通道、磁盘库，不保证外部副作用或后续exec失败恢复。

    自定义部分是**整组重建**，不是 merge。``keep_std`` 对 subnet HDA 从原生
    subnet 类型重新取得 Transform/Subnet 等标准页，避免把旧自定义参数夹带回来；
    ``hide_builtin_tabs`` 通过公开的 ParmTemplateGroup.hide 隐藏这些页。所有
    ``hide_when`` 在提交后读回验证，Houdini 若吞掉 conditional，则自动补丁
    DialogScript 的 ``hidewhen`` 并再次验证。
    SOP subnet标准label1..label4管理字段保留但隐藏，不影响输入名称/接线或自定义Label。
    与现有实例spare同名的重建在定义/磁盘写入前拒绝，不隐式合并或丢弃spare。
    """
    if edits is None:
        kwargs = dict(spec=spec, keep_std=keep_std, hide_builtin_tabs=hide_builtin_tabs,
                      allow_foreign=allow_foreign, expected_sha256=expected_sha256, layout=layout)
        if type(dry_run) is not bool:
            raise ValueError('dry_run must be boolean')
        preview = _rebuild_hda_interface(node, dry_run=True, **kwargs)
        if dry_run:
            return preview
        from dsh_hda_interfaces import definition_write_guard
        n, _ = _hda_definition(node)
        with definition_write_guard(n, 'hda_set_interface rebuild', allow_foreign):
            return _rebuild_hda_interface(node, dry_run=False, **kwargs)
    return _rebuild_hda_interface(node, spec, keep_std, hide_builtin_tabs, allow_foreign,
                                  edits=edits, expected_sha256=expected_sha256, dry_run=dry_run, layout=layout)


def _rebuild_hda_interface(node, spec=None, keep_std=True, hide_builtin_tabs=False, allow_foreign=None,
                           *, edits=None, expected_sha256=None, dry_run=False, layout=None):
    if layout is not None:
        if spec is not None or edits is not None or expected_sha256 is not None:
            raise ValueError('layout is exclusive with spec/edits/expected_sha256')
        from dsh_parameter_ui import expand_layout, validate_layout_spec
        spec = expand_layout(layout)
        validate_layout_spec(spec)
    if edits is not None:
        if spec is not None or keep_std is not True or hide_builtin_tabs is not False:
            raise ValueError('edits is exclusive with spec/keep_std/hide_builtin_tabs options')
        from dsh_hda_interfaces import patch_interface
        return patch_interface(node, edits, expected_sha256, dry_run, allow_foreign)
    if expected_sha256 is not None:
        raise ValueError('expected_sha256 requires edits mode')
    if type(dry_run) is not bool:
        raise ValueError('dry_run must be boolean')
    n, definition = _hda_definition(node)
    _require_owned(n, "hda_set_interface", allow_foreign)
    from dsh_hda_interfaces import require_definition_owned
    require_definition_owned(definition, 'hda_set_interface rebuild', allow_foreign)
    for instance in n.type().instances():
        _require_owned(instance, 'hda_set_interface rebuild affected instance', allow_foreign)
    if not isinstance(spec, (list, tuple)):
        raise ValueError("spec 必须是参数条目 list")
    names: set = set()
    conditions: dict[str, str] = {}
    custom = [
        _build_interface_template(item, f"spec[{index}]", names, conditions)
        for index, item in enumerate(spec)
    ]
    # An instance overlay can survive definition replacement and merge multiparm
    # children. Refuse the ambiguity BEFORE touching the shared library.
    definition_names = _all_template_names(definition.parmTemplateGroup().entries())
    for instance in n.type().instances():
        overlay_names = _all_template_names(instance.parmTemplateGroup().entries()) - definition_names
        collisions = names & overlay_names
        if collisions:
            raise ValueError(f'instance spare interface conflicts with definition rebuild on {instance.path()}: '
                             f'{sorted(collisions)}; no definition/library writes. '
                             'Keep the source intact; use a clean definition instance and verify migration separately.')

    standard = _standard_interface_entries(n) if keep_std else []
    conflicts = names & _all_template_names(standard)
    if conflicts:
        raise ValueError(
            f"自定义 spec 与 Houdini 标准参数重名：{sorted(conflicts)}；"
            "请改自定义 name（不要覆盖 tx/rx 等内置参数）"
        )

    group = hou.ParmTemplateGroup()
    # 自定义界面优先：顶层按钮会自然出现在最上方，标准页排在其后。
    for template in custom:
        group.append(template)
    standard_names = []
    for template in standard:
        # Native SOP subnet input-label editors are authoring metadata, not
        # business controls. Keep their values/port semantics, hide only these
        # standard templates; do not hide custom Label/heading controls.
        if (n.type().category() == hou.sopNodeTypeCategory()
                and template.name() in {'label1', 'label2', 'label3', 'label4'}):
            template.hide(True)
        group.append(template)
        standard_names.append(template.name())
    if hide_builtin_tabs:
        for name in standard_names:
            try:
                group.hide(name, True)
            except Exception as e:
                raise ValueError(f"隐藏标准页 {name!r} 失败：{e}") from e

    from dsh_parameter_ui import analyze_ui as inspect_ui
    preview_tree = [_template_info(t, 0, 20) for t in group.entries()]
    if dry_run:
        return {'node': n.path(), 'mode': 'layout' if layout is not None else 'rebuild',
                'ok': True, 'dry_run': True, 'applied': False, 'scene_writes': 0,
                'interface': preview_tree, 'ui_analysis': inspect_ui(preview_tree)}
    definition.setParmTemplateGroup(group, rename_conflicting_parms=False)

    # H21 实测 setParmTemplateGroup 会吞一部分 API setConditional：先读回，
    # 只对丢失项走 DialogScript 兜底，避免无谓改写定义源码。
    after = n.parmTemplateGroup()
    missing = {}
    for name, expected in conditions.items():
        template = after.find(name)
        actual = None
        if template is not None:
            actual = template.conditionals().get(hou.parmCondType.HideWhen)
        if actual != expected:
            missing[name] = expected
    patched = []
    if missing:
        sections = definition.sections()
        if "DialogScript" not in sections:
            raise RuntimeError(
                f"conditional 被 Houdini 吞掉，但定义没有 DialogScript section：{sorted(missing)}"
            )
        dialog = sections["DialogScript"].contents()
        for name, condition in missing.items():
            dialog = _patch_dialog_hide_when(dialog, name, condition)
            patched.append(name)
        definition.addSection("DialogScript", dialog)

    verified = {}
    final_group = n.parmTemplateGroup()
    from dsh_hda_interfaces import _walk
    observed_templates = list(_walk(final_group.entries()))
    business_order = []
    for index, template in enumerate(custom):
        def verify_template(expected, actual):
            if actual.type() != expected.type() or actual.label() != expected.label():
                raise RuntimeError(f'UI template order/type/label mismatch: {expected.name()}')
            for key, value in expected.tags().items():
                if actual.tags().get(key) != value:
                    raise RuntimeError(f'UI tag readback mismatch: {expected.name()}/{key}')
            for getter in ('joinsWithNext', 'isLabelHidden', 'numComponents', 'defaultValue'):
                if hasattr(expected, getter) and getattr(actual, getter)() != getattr(expected, getter)():
                    raise RuntimeError(f'UI property readback mismatch: {expected.name()}/{getter}')
            for condition, value in expected.conditionals().items():
                if actual.conditionals().get(condition) != value:
                    raise RuntimeError(f'UI conditional readback mismatch: {expected.name()}/{condition}')
            if isinstance(expected, hou.FolderParmTemplate):
                if actual.folderType() != expected.folderType():
                    raise RuntimeError(f'UI folder layout mismatch: {expected.name()}')
                if actual.tabConditionals() != expected.tabConditionals():
                    raise RuntimeError(f'UI tab conditional readback mismatch: {expected.name()}')
                children = actual.parmTemplates()
                if len(children) != len(expected.parmTemplates()):
                    raise RuntimeError(f'UI folder child count mismatch: {expected.name()}')
                for child, actual_child in zip(expected.parmTemplates(), children):
                    verify_template(child, actual_child)
        # Existing hide_when fallback below owns legacy HideWhen verification.
        if layout is not None:
            actual = final_group.find(template.name())
            if actual is None and isinstance(template, hou.FolderParmTemplate):
                # Houdini normalizes tab-set names and can wrap OBJ controls in
                # a spare folder. Match a renamed folder only when its native
                # type/label is unique, never by its old positional index.
                candidates = [t for t in _walk(final_group.entries())
                              if isinstance(t, hou.FolderParmTemplate)
                              and t.label()==template.label() and t.folderType()==template.folderType()]
                if len(candidates)==1:
                    actual=candidates[0]
            if actual is None:
                raise RuntimeError(f'UI template missing or ambiguous after native normalization: {template.name()}')
            positions = [i for i,t in enumerate(observed_templates) if t.name()==actual.name() and t.type()==actual.type()]
            if len(positions)!=1:
                raise RuntimeError(f'UI template order is ambiguous: {template.name()}')
            business_order.append(positions[0])
            verify_template(template, actual)
    if business_order != sorted(set(business_order)):
        raise RuntimeError('UI custom template order changed during native normalization')
    for name, expected in conditions.items():
        template = final_group.find(name)
        actual = None if template is None else template.conditionals().get(
            hou.parmCondType.HideWhen
        )
        if actual != expected:
            raise RuntimeError(
                f"参数 {name!r} hide_when 写后验证失败：expected={expected!r}, actual={actual!r}"
            )
        verified[name] = actual

    hidden_std = []
    if hide_builtin_tabs:
        final_group = n.parmTemplateGroup()
        for template in final_group.entries():
            try:
                if template.isHidden() and template.label() in {
                    t.label() for t in standard
                }:
                    hidden_std.append(template.label())
            except Exception:
                pass
    return {
        "node": n.path(),
        "custom_entries": [t.name() for t in custom],
        "custom_parms": sorted(names),
        "standard_kept": bool(keep_std),
        "standard_entries": standard_names,
        "hidden_standard_tabs": sorted(hidden_std),
        "hide_when_verified": verified,
        "dialogscript_patched": patched,
        'mode': 'layout' if layout is not None else 'rebuild',
        'ok': True, 'applied': True,
        'ui_analysis': inspect_ui([_template_info(t, 0, 20) for t in final_group.entries()]),
    }


# --- geometry 域 -------------------------------------------------------------

def geo_check_interfaces(output, interfaces, max_pairs: int = 50000) -> dict:
    """验证实际最终SOP上的连接接口，不用另建的anchor/proxy代替部件。

    interfaces=[{id,source_group,target_group,max_distance,expected_points}]。
    source_group为最终polygon/mesh表面顶点的命名point group；target_group为不相交
    的命名primitive group（closed Polygon/Mesh/Sphere/Tube）。全source点都须在容差内。
    只测SOP local点到指定表面的距离，不证明整体穿插/强度/所有表面最小间隙。
    空选择/基数不符fail；不支持表示unverified；超max_pairs拒绝不抽样。
    可选method='axis_gap'时source_group/target_group均为实际primitive组，带axis(0..2)、
    gap_range=[min,max]和正数min_overlap。测source.min-target.max及横向投影重叠；
    正数表示轴向分離，负数表示投影重叠，仅此，不能称为真实接触或插入深度。
    method='solid_overlap'时两组都是同一最终SOP内完整、独立、闭合且朝外的
    Polygon实体primitive组，另给max_overlap_volume（SOP local单位的三次方）。
    内存Boolean Intersect量实体相交体积；正体积超限fail，零交集pass；
    不完整/开放/非Polygon或数值模糊为unverified，不添加场景节点。
    例：{id:'shaft_clearance',method:'solid_overlap',source_group:'lug',
    target_group:'shaft',max_overlap_volume:0}。须另验同轴和孔壁距离；
    零交集不证明轴已穿孔，逐状态检查也不证明连续扫掠或力学。
    method='axis_passage'只需最终输出的target_group primitive组、axis(0..2)、
    start/end两个SOP local轴对齐三维点。两端须在所选组轴向包络之外，横向
    位于包络内；在最终Polygon表面上射线碰到任何面即fail，单轴无遮挡才pass。
    缺组fail；不支持表示或线段未跨包络为unverified。只证明这一条中心线，
    不证明孔径、孔壁、周围材料或其他轴；后续增材修改后必须复验。
    method='bore_clearance'增加正数radius（SOP local单位），在声明的start/end
    区间内以外切24边棱柱与最终闭合朝外Polygon组做Boolean相交；零交集pass，
    有效正体积fail，不完整实体/数值含糊unverified。区间须按安装板等实际待验
    壁厚指定；若组还有远处的铰耳，不要求整组包围盒都被孔轴贯穿。它不证明
    区间两端之外仍通畅、孔周有材料、图纸孔位正确或加工公差。
    method='component_count'用最终Polygon primitive组target_group和
    expected_components(1..32)测共享边连通岛数；缺组或数目不符fail，
    不支持表示/退化面unverified。期望件数须先从要求得出，不能从幸存件反推；
    数目通过不证明每件身份、对称位置、形状或连接到主体。
    method='physical_extent'用最终闭合Polygon primitive组target_group、axis(0..2)、
    expected_mm(正数)和tolerance_mm(0..expected_mm)量选中点的逐轴跨度，按HIP
    unitlength换算毫米。尺寸归属与允许误差须先由用户/厂家图核对，不能从现有模型反推。
    缺组或超差fail；非Polygon、单位未知、非单位OBJ变换等为unverified。
    只证明所选最终组的一轴数值，不证明完整零件身份、孔径、造型或装配。
    """
    from dsh_quality_contracts import geo_check_interfaces as check
    return check(output, interfaces, max_pairs=max_pairs)


def test_controls(controller, output, tests, interfaces=None, allow_foreign=None, *, domain=None, topology=None,
                  baseline_interfaces=None, views=None, view_bounds=None) -> dict:
    """数字标量控制的可恢复测试；必须用exec（会临时改参数/cook）。

    tests为1..16个case；每个case是
    {id,values:{parm:number},expectations:[{metric,axis?,group?,id_attrib?,delta:[min,max],range?}],interfaces?}，
    values只放相对当前基准实际改变的参数；未变化字段和基准状态不要作为扰动case传入。
    每个case最多16个expectations；同一扰动的大检查按相同values拆成多个case。
    metric精确枚举：bounds_size、bounds_center、bounds_min、bounds_max（axis0..2）、
    point_count、primitive_count、area、point_mean(axis)、boundary_edges、piece_count（Polygon共享边）。
    max_point_displacement/mean_point_displacement需id_attrib稳定唯一point ID及相同面连接；
    max_transform_error另给transform（16数row-major仿射矩阵，SOP-local行向量约定），
    测max(|P_baseline*transform-P_test|)，baseline残差=0；仍需另有非零响应项。
    range=[min,max]验证基准/扰动绝对范围，delta是相对响应；center/min/max不是有效缩写。
    先消费control_summary的status/reason/case_counts；results=[]可能是基准失败，绝非通过。
    control_summary保留未运行case、输出变化与失败测量，coverage区分全输出/部件测量和接口覆盖。
    bounds/count通过不证明连接或均匀变换；输出变化而所选指标失败不等于控制未接线。
    修正判据后复跑，不能用文字解释替代新结果。
    group为实际output内命名primitive group。delta是变化前后的有符号允许区间。
    顶层interfaces在基准及每次扰动均检查；baseline_interfaces只在基准状态检查，
    case内interfaces只在该扰动状态检查，用于合盖接触与开盖分离等不同状态合同。
    三者均用geo_check_interfaces同一schema；实体禁穿插可用solid_overlap，
    但所选组须完整闭合，孔轴无遮挡可用axis_passage，声明孔径空域可用
    bore_clearance；这些检查均不认证整件孔系或制造公差。
    每case最终恢复原参数/keys/frame，
    用完整bgeo内容核对输出恢复（包括原生primitive intrinsic）。
    拒绝foreign控制（除单次授权）、menu/button/callback/multiparm/tuple；只声明已测case，
    当前控制输出支持Polygon/Mesh/Sphere/Tube及点几何；内嵌PackedGeometry有界内存展开量测，
    原Packed内容与变换单独做恢复指纹。磁盘/Alembic/Fragment等其他类型写前unverified。
    每case至少一项预期delta排除0；不保证外部文件/Python或solver副作用可撤销。
    可选domain=[{id,left:数值spare参数名,op:lt|le|gt|ge|eq|ne,right:参数名或有限数值}]。
    检查基准和实际扰动值；独立无key控制还可写前拒绝无效测试值。不求解/钳制，不证明全范围。
    可选topology=[{id,groups:[最终primitive组名,...],require_closed:true}]检查融合表面的
    共享边连通/闭合；在基准与每次扰动实际输出上复查。不用于未焊接独立部件的距离/强度证明。
    views可选最多两个iso/front/side/top；先拍基准，再用相同取景/深度包络拍各case。
    view_bounds可显式给覆盖全部状态的世界坐标[min_xyz,max_xyz]；省略则锁定基准包络。
    状态超出包络不重新取景；GUI/图片不可用保持unverified，几何恢复仍执行。图片不证明语义正确。
    """
    from dsh_quality_contracts import test_controls as test
    return test(controller, output, tests, interfaces=interfaces, allow_foreign=allow_foreign,
                domain=domain, topology=topology, baseline_interfaces=baseline_interfaces,
                views=views, view_bounds=view_bounds)


def cop_layer_stats(node, output=0, *, max_pixels=4194304) -> dict:
    """exec-only: full bounded ImageLayer statistics, metadata and exact buffer fingerprint.

    output is an exact output name/index. No sampling, normalization or Geometry conversion.
    max_pixels is 1..16777216; memory/cook cost is not a hard process budget.
    Manual, failed cook, unsupported output and oversized buffer reject; sticky upstream cache
    remains explicitly unknown. Returns per-channel min/max/mean/nonfinite and XY variation.
    """
    from dsh_cop_contracts import layer_stats
    return layer_stats(node, output, max_pixels=max_pixels)


def cop_compare_layers(before, after, *, before_output=0, after_output=0, expected_delta=None,
                       tolerance=1e-6, max_pixels=4194304) -> dict:
    """exec-only: full aligned buffer difference AFTER - BEFORE; no implicit resampling.

    expected_delta is optional {node,output?} naming a declared increment layer; when provided
    check max(abs((after-before)-expected_delta)) <= tolerance. Without it return measurement,
    status=unverified, never artistic/semantic success. Channel/window/space mismatch rejects.
    """
    from dsh_cop_contracts import compare_layers
    return compare_layers(before, after, before_output=before_output, after_output=after_output,
                          expected_delta=expected_delta, tolerance=tolerance, max_pixels=max_pixels)


def test_cop_controls(controller, output, tests, *, output_port=0, max_pixels=4194304,
                      allow_foreign=None) -> dict:
    """exec-only reversible numeric scalar COP controls, exact channel/frame/output restoration.

    tests=[{id,values:{parm:number},expectations:[{metric,channel,delta:[min,max],range?:[min,max]}]}].
    Metrics: mean,min,max,mean_abs_change,max_abs_change; change metrics baseline=0.
    Every case needs a nonzero expected response; range checks baseline and perturbation.
    Reject menus/callbacks/multiparms/tuples, Manual, unsupported/nonfinite layers before writes.
    Uses full ImageLayer fingerprint (not bgeo), checks all controlled channels after recook.
    Sticky Cache upstream is rejected; external files/Python/solver effects are not restored.
    A restored failed test is status=fail; restoration failure raises CheckpointError.
    """
    from dsh_cop_contracts import test_controls
    return test_controls(controller, output, tests, output_port=output_port,
                         max_pixels=max_pixels, allow_foreign=allow_foreign)


def geo_point_spacing(node, expected: float, tolerance: float, closed: bool = False,
                      order_attrib=None, max_points: int = 10000) -> dict:
    """全量检查一条有序点序列的相邻弦长（SOP local单位），不是曲线弧长或表面关系。

    默认按point number；可用唯一数值order_attrib排序。closed=True检查末→首。
    超max_points拒绝，不抽样；返回全量min/max/failure_count及最多16个最差相邻对。
    ok仅证明本条距离约束，geometry/视觉/实际零件关系须另外验证。
    """
    from dsh_sop_contracts import geo_point_spacing as check
    return check(node, expected, tolerance, closed=closed, order_attrib=order_attrib, max_points=max_points)


def geo_attrib_stats(node, name: str, attrib_class: str = "point", *, unique: bool = False,
                     max_elements: int = 100000) -> dict:
    """属性**值**统计：min/max/mean/count（`describe` 只给属性名清单，不给值）。

    用于验证驱动数据（@Cd/@curveu/@pscale…）是否符合预期，不用手写逐点循环。
    attrib_class: "point" / "prim" / "vertex" / "detail"。数值属性支持多分量
    （vector 按分量给 min/max/mean）。unique=True全量检查属性完整tuple的精确唯一性，
    返回unique_count/duplicate_count/all_unique和重复样本，支持int/float/string。
    用P检查精确重叠模板点，用id检查身份；不是容差焊接或几何碰撞判断。
    超max_elements或非有限值拒绝，不抽样后宣称唯一；不自动删除重复。
    """
    n = _resolve(node)
    _cook_control.require_evaluation('geo_attrib_stats')
    g = n.geometry()
    finders = {
        "point": (g.findPointAttrib, g.pointFloatAttribValues, g.pointIntAttribValues),
        "prim": (g.findPrimAttrib, g.primFloatAttribValues, g.primIntAttribValues),
        "vertex": (g.findVertexAttrib, g.vertexFloatAttribValues, g.vertexIntAttribValues),
        # detail 属性只有一个值，没有批量取值 API，用 attribValue 特判
        "detail": (g.findGlobalAttrib, None, None),
    }
    if attrib_class not in finders:
        raise ValueError(f"attrib_class 只能是 {sorted(finders)}，收到 {attrib_class!r}")
    find, floats, ints = finders[attrib_class]
    attrib = find(name)
    if attrib is None:
        pool = {
            "point": [a.name() for a in g.pointAttribs()],
            "prim": [a.name() for a in g.primAttribs()],
            "vertex": [a.name() for a in g.vertexAttribs()],
            "detail": [a.name() for a in g.globalAttribs()],
        }[attrib_class]
        suggestions = difflib.get_close_matches(name, pool, n=5, cutoff=0.4)
        raise ValueError(
            f"节点 '{n.path()}' 没有 {attrib_class} 属性 '{name}'。相似属性：{suggestions}"
        )
    data_type = attrib.dataType()
    size = attrib.size()
    if not isinstance(unique, bool) or type(max_elements) is not int or not 1 <= max_elements <= 1000000:
        raise ValueError('unique must be bool; max_elements integer in 1..1000000')
    uniqueness = {}
    if unique:
        from dsh_geometry_observation import attribute_uniqueness
        uniqueness = attribute_uniqueness(g, attrib, attrib_class, max_elements)
    if data_type == hou.attribData.String and not unique:
        raise ValueError(f"属性 '{name}' 是字符串属性，geo_attrib_stats 只统计数值属性")
    if data_type == hou.attribData.String:
        return {'node': n.path(), 'attrib': name, 'class': attrib_class,
                'data_type': 'string', 'size': size, **uniqueness}
    if attrib_class == "detail":
        v = g.attribValue(name)
        values = list(v) if isinstance(v, (tuple, list)) else [v]
    else:
        values = list(floats(name) if data_type == hou.attribData.Float else ints(name))
    count = len(values) // size if size else 0
    mins, maxs, means = [], [], []
    for comp in range(size):
        col = values[comp::size]
        if not col:
            mins.append(None); maxs.append(None); means.append(None)
            continue
        mins.append(min(col)); maxs.append(max(col))
        means.append(sum(col) / len(col))
    def _collapse(v):
        return v[0] if size == 1 else v
    return {
        "node": n.path(),
        "attrib": name,
        "class": attrib_class,
        "data_type": "float" if data_type == hou.attribData.Float else "int",
        "size": size,
        "count": count,
        "min": _collapse(mins),
        "max": _collapse(maxs),
        "mean": _collapse(means),
        **uniqueness,
    }


def _summary(values: list) -> dict:
    if not values:
        return {"min": None, "max": None, "mean": None}
    return {
        "min": min(values),
        "max": max(values),
        "mean": sum(values) / len(values),
    }


def geo_piece_stats(node, piece_attrib: str | None = None,
                    sample: int = 16, *, inspect: bool = False, group=None, basis=None,
                    integrity_only: bool = False) -> dict:
    """按 primitive piece 报局部 bbox/面积，识别整体 bbox 掩盖的局部退化。

    ``piece_attrib=None`` 时用原生 Connectivity SOP Verb 在内存副本上生成临时
    primitive ``__dsh_piece``，不向用户网络加节点。也可传已有 primitive int/string
    piece 属性。返回全部 piece 的摘要和有限样本，避免 9000 个实例爆 token。
    inspect=True改为有界Polygon观测：group为精确primitive组，basis为3个正交单位轴；
    integrity_only=True统计最终Polygon表面完整性及闭合连通壳的有向体积符号，
    扩大有界预算并跳过昂贵的截面/中心线诊断；负号只提示检查单独部件是否整壳反向，
    嵌套空腔可有意出现反向内壳，不自动判错；还对比显式N属性与几何面朝向，
    反向着色法线只提示复核，不自动改写几何；
    boundary_edges单独提示核对有意开放接口，不一概当破面。
    平面大面若以重复点桥接孔，另报shading_review_status供视窗近景复核；
    这不是拓扑失败，也不证明已有可见着色瑕疵。
    planar_face_crossings只查单个近似平面闭合Polygon内非相邻边的严格内部交叉；
    每面最多256顶点、总计250000对边，须看coverage/skipped_faces；不查非平面面、
    端点接触、共线重合或跨面自交，合法洞桥不因重复边判错。已有风险只作非阻断复核。
    返回边界/非流形/边连通/零面积、surface_area与局部extent；center_axis_surface_hits
    量测三条basis轴向包围盒中心线与表面的交点（实心封口通常为2，通孔轴可为0，但须结合
    闭合/流形与轴向图像）；duplicate_boundary_faces及
    closed_planar_components是重合边界/闭合共面壳风险，不是任意重叠检测。observed不是形态pass。
    曲线/native/packed及超预算保持unverified；group/basis不能用于默认piece统计。
    """
    n = _resolve(node)
    if n.type().category() != hou.sopNodeTypeCategory():
        raise ValueError("geo_piece_stats 只接受 SOP 节点")
    if not isinstance(sample, int) or sample <= 0 or sample > 256:
        raise ValueError("sample 必须是 1..256 的整数")
    _cook_control.require_evaluation('geo_piece_stats')
    source = n.geometry()
    if source is None:
        raise ValueError(f"节点 {n.path()} 没有 geometry")
    if not isinstance(inspect, bool): raise ValueError('inspect must be boolean')
    if type(integrity_only) is not bool: raise ValueError('integrity_only must be boolean')
    if integrity_only and not inspect:
        raise ValueError('integrity_only requires inspect=True')
    if inspect:
        from dsh_geometry_observation import polygon_observation
        return {'node': n.path(), 'frame': float(hou.frame()), 'checked_at': time.time(),
                **polygon_observation(source, group, basis, integrity_only=integrity_only)}
    if group is not None or basis is not None:
        raise ValueError('group/basis require inspect=True (selected polygon observation)')
    geometry = source
    generated = False
    attrib_name = piece_attrib
    attrib_class = "prim"
    if attrib_name is None:
        generated = True
        attrib_name = "__dsh_piece"
        verb = hou.sopNodeTypeCategory().nodeVerb("connectivity")
        if verb is None:
            raise RuntimeError("当前 Houdini 没有 Connectivity SOP Verb")
        verb.setParms({"attribname": attrib_name, "attribtype": 0, "connecttype": 0})
        geometry = hou.Geometry()
        verb.execute(geometry, [source])
        attrib_class = "point"
    else:
        attrib = geometry.findPrimAttrib(attrib_name)
        if attrib is None:
            attrib = geometry.findPointAttrib(attrib_name)
            attrib_class = "point"
        if attrib is None:
            raise ValueError(
                f"节点 {n.path()} 没有 primitive/point piece 属性 {attrib_name!r}；"
                "省略 piece_attrib 可按连接性自动生成"
            )
        if attrib.size() != 1:
            raise ValueError("piece_attrib 必须是单分量 primitive 属性")

    pieces = {}
    for prim in geometry.iterPrims():
        try:
            if attrib_class == "prim":
                piece_id = prim.attribValue(attrib_name)
            else:
                points = prim.points()
                if not points:
                    continue
                piece_id = points[0].attribValue(attrib_name)
        except Exception as error:
            raise ValueError(f"无法读取 {attrib_class} 属性 {attrib_name!r}: {error}") from error
        key = str(piece_id)
        record = pieces.get(key)
        if record is None:
            record = {
                "id": piece_id,
                "prims": 0,
                "vertices": 0,
                "surface_prims": 0,
                "area": 0.0,
                "min": [math.inf, math.inf, math.inf],
                "max": [-math.inf, -math.inf, -math.inf],
            }
            pieces[key] = record
        record["prims"] += 1
        points = prim.points()
        record["vertices"] += len(points)
        try:
            closed = bool(prim.intrinsicValue("closed"))
        except Exception:
            closed = False
        if closed and len(points) >= 3:
            try:
                area = float(prim.intrinsicValue("measuredarea"))
                record["area"] += max(0.0, area)
                record["surface_prims"] += 1
            except Exception:
                pass
        for point in points:
            position = point.position()
            for axis in range(3):
                value = float(position[axis])
                record["min"][axis] = min(record["min"][axis], value)
                record["max"][axis] = max(record["max"][axis], value)

    records = []
    for record in pieces.values():
        extents = [record["max"][i] - record["min"][i] for i in range(3)]
        records.append({
            "id": _val(record["id"]),
            "prims": record["prims"],
            "vertices": record["vertices"],
            "surface_prims": record["surface_prims"],
            "area": record["area"],
            "bbox_min": record["min"],
            "bbox_max": record["max"],
            "extents": extents,
            "min_extent": min(extents),
            "max_extent": max(extents),
        })
    records.sort(key=lambda item: (
        0, float(item["id"])
    ) if isinstance(item["id"], (int, float)) else (1, str(item["id"])))
    source_bbox = source.boundingBox()
    source_scale = max(float(v) for v in source_bbox.sizevec()) if records else 1.0
    area_epsilon = max(source_scale * source_scale * 1e-12, 1e-16)
    degenerate = sum(
        1 for item in records
        if item["surface_prims"] > 0 and item["area"] <= area_epsilon
    )
    if len(records) <= sample:
        sampled = records
    elif sample == 1:
        sampled = [records[0]]
    else:
        indices = sorted({
            round(i * (len(records) - 1) / (sample - 1)) for i in range(sample)
        })
        sampled = [records[i] for i in indices]
    axis_extents = [[item["extents"][axis] for item in records] for axis in range(3)]
    return {
        "node": n.path(),
        "piece_attrib": attrib_name,
        "piece_attrib_class": attrib_class,
        "piece_attrib_generated": generated,
        "piece_count": len(records),
        "degenerate_surface_pieces": degenerate,
        "area_epsilon": area_epsilon,
        "area": _summary([item["area"] for item in records]),
        "extent_x": _summary(axis_extents[0]),
        "extent_y": _summary(axis_extents[1]),
        "extent_z": _summary(axis_extents[2]),
        "sampled_pieces": sampled,
    }


def geo_frame_diff(node, frame_a, frame_b, attrib: str = "P",
                   sample: int = 4096, tolerance: float = 1e-6) -> dict:
    """比较 SOP 两帧的 point 数值属性，不移动用户 playbar。

    使用 ``geometryAtFrame`` 取得冻结几何；拓扑一致时返回抽样点的 mean/max delta、
    p50/p90/p99、逐分量位移统计与 unchanged 百分比。适合区分“真实几何静止”和
    “ROP/图片缓存”；这些数值证明数据在动，不自动证明运动的审美语义。

    可比较结果的精确键是 ``mean_delta``、``max_delta``、
    ``delta_percentiles``（``p50/p90/p99``）、``component_delta``
    （``min/max/mean`` 数组）、``unchanged_pct``、``sampled_points``、
    ``tolerance``、``data_type`` 和 ``size``；不要读取不存在的简写
    ``mean``/``max``。所有结果另含 node/attrib/frame/counts/bbox。
    """
    n = _resolve(node)
    if n.type().category() != hou.sopNodeTypeCategory():
        raise ValueError("geo_frame_diff 只接受 SOP 节点")
    if not isinstance(sample, int) or sample <= 0 or sample > 1_000_000:
        raise ValueError("sample 必须是 1..1000000 的整数")
    if tolerance < 0:
        raise ValueError("tolerance 不能为负")
    fa, fb = float(frame_a), float(frame_b)
    _cook_control.require_evaluation('geo_frame_diff')
    ga = n.geometryAtFrame(fa)
    gb = n.geometryAtFrame(fb)
    if ga is None or gb is None:
        raise ValueError(f"节点 {n.path()} 在指定帧没有 geometry")
    counts_a = {"points": len(ga.points()), "prims": len(ga.prims())}
    counts_b = {"points": len(gb.points()), "prims": len(gb.prims())}
    bbox_a, bbox_b = ga.boundingBox(), gb.boundingBox()
    base = {
        "node": n.path(),
        'correspondence': 'point_number',
        'scope': 'sampled attribute arrays aligned by point number after count/type checks; stable IDs and matching primitive topology are not verified, so point reordering can appear as change',
        "attrib": attrib,
        "frame_a": fa,
        "frame_b": fb,
        "counts_a": counts_a,
        "counts_b": counts_b,
        "bbox_a": {
            "min": [float(v) for v in bbox_a.minvec()],
            "max": [float(v) for v in bbox_a.maxvec()],
        },
        "bbox_b": {
            "min": [float(v) for v in bbox_b.minvec()],
            "max": [float(v) for v in bbox_b.maxvec()],
        },
    }
    if counts_a != counts_b:
        base.update({"comparable": False, "reason": "topology counts differ"})
        return base
    aa, ab = ga.findPointAttrib(attrib), gb.findPointAttrib(attrib)
    if aa is None or ab is None:
        raise ValueError(f"两帧都必须有 point 属性 {attrib!r}")
    if aa.size() != ab.size() or aa.dataType() != ab.dataType():
        base.update({"comparable": False, "reason": "attribute type/size differs"})
        return base
    if aa.dataType() == hou.attribData.String:
        raise ValueError("geo_frame_diff 只支持数值 point 属性")
    getter = "pointFloatAttribValues" if aa.dataType() == hou.attribData.Float else "pointIntAttribValues"
    values_a = list(getattr(ga, getter)(attrib))
    values_b = list(getattr(gb, getter)(attrib))
    size = aa.size()
    point_count = counts_a["points"]
    if point_count <= sample:
        indices = range(point_count)
    elif sample == 1:
        indices = [0]
    else:
        indices = sorted({
            round(i * (point_count - 1) / (sample - 1)) for i in range(sample)
        })
    deltas = []
    component_deltas = [[] for _ in range(size)]
    for index in indices:
        offset = index * size
        components = [
            float(values_b[offset + c]) - float(values_a[offset + c])
            for c in range(size)
        ]
        deltas.append(math.sqrt(sum(value * value for value in components)))
        for component, value in enumerate(components):
            component_deltas[component].append(value)
    unchanged = sum(1 for value in deltas if value <= tolerance)
    ordered = sorted(deltas)

    def percentile(fraction: float) -> float:
        if not ordered:
            return 0.0
        if len(ordered) == 1:
            return ordered[0]
        position = fraction * (len(ordered) - 1)
        lower = int(math.floor(position))
        upper = int(math.ceil(position))
        if lower == upper:
            return ordered[lower]
        weight = position - lower
        return ordered[lower] * (1.0 - weight) + ordered[upper] * weight

    base.update({
        "comparable": True,
        "data_type": "float" if aa.dataType() == hou.attribData.Float else "int",
        "size": size,
        "sampled_points": len(deltas),
        "tolerance": float(tolerance),
        "mean_delta": sum(deltas) / len(deltas) if deltas else 0.0,
        "max_delta": max(deltas) if deltas else 0.0,
        "delta_percentiles": {
            "p50": percentile(0.50),
            "p90": percentile(0.90),
            "p99": percentile(0.99),
        },
        "component_delta": {
            "min": [min(values) if values else 0.0 for values in component_deltas],
            "max": [max(values) if values else 0.0 for values in component_deltas],
            "mean": [
                sum(values) / len(values) if values else 0.0
                for values in component_deltas
            ],
        },
        "unchanged_pct": unchanged * 100.0 / len(deltas) if deltas else 100.0,
    })
    return base


# --- render / sim 域 ---------------------------------------------------------

# --- 图片产出登记（media relay 数据源） --------------------------------------
# 记录本请求产出的图片路径；Bridge放进images，Host经/media读取字节并写入
# DSH原生附件存储，不复制到会话工作区。附件送达不代表模型已完成语义观察。
_PRODUCED_IMAGES: list = []
_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tga", ".webp"}
_PREVIEW_IMAGE_EXTS = {
    ".png", ".jpg", ".jpeg", ".bmp", ".tga", ".tif", ".tiff",
    ".exr", ".hdr", ".pic", ".rat",
}


def report_image(path: str) -> str:
    """登记一张本次 exec 产出的图片（返回绝对路径）。动词外手写的产出也可登记。

    只登记图片扩展名——geometry ROP 的 .bgeo 等产物不该进 media relay。
    """
    p = os.path.abspath(path)
    if os.path.splitext(p)[1].lower() in _IMAGE_EXTS and p not in _PRODUCED_IMAGES:
        _PRODUCED_IMAGES.append(p)
    return p


def _resolve_output_path(path, *, frame, default_subdir=None) -> str:
    """Resolve output files BEFORE mutation; never use the process cwd.

    A bare filename goes to $HIP/default_subdir (dsh-render by default); a relative subpath is $HIP
    relative. Absolute paths remain explicit caller intent except repository
    paths. Relative traversal/junction escapes and extensionless files fail.
    """
    default_subdir = _project_directory('render') if default_subdir is None else default_subdir
    raw = os.fspath(path)
    if not isinstance(raw, str) or not raw.strip() or '\x00' in raw:
        raise ValueError('output path must be a nonempty file path')
    expanded = hou.expandStringAtFrame(raw, float(frame)).replace('\\', '/')
    if not os.path.splitext(os.path.basename(expanded))[1]:
        raise ValueError('output extension is required; use .png for previews, .exr for linear images or the intended cache extension')
    if not os.path.isabs(expanded):
        if os.path.splitdrive(expanded)[0] or not scene_info()['has_named_path']:
            raise ValueError('relative output requires a named HIP; confirm a project and use scene_save_as first')
        hip = os.path.realpath(os.path.dirname(hou.hipFile.path()))
        relative = expanded if '/' in expanded else os.path.join(default_subdir, expanded)
        target = os.path.realpath(os.path.join(hip, relative))
        if os.path.commonpath([hip, target]) != hip:
            raise ValueError(f'relative output is outside $HIP: {raw!r}')
    else:
        target = os.path.realpath(expanded)
    repo = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', '..'))
    try:
        in_repo = os.path.commonpath([repo, target]) == repo
    except ValueError:
        in_repo = False
    if in_repo:
        raise ValueError('output cannot be written into the plugin repository; choose the HIP project directory')
    return target.replace('\\', '/')


def _preview_artifact(path, *, frame, purpose, output_policy, default_label,
                      default_subdir, allowed_extensions=_PREVIEW_IMAGE_EXTS):
    """Resolve preview output policy before renderer/viewer state changes."""
    if output_policy not in ("managed", "delivery", "explicit"):
        raise ValueError("output_policy must be 'managed', 'delivery' or 'explicit'")
    scene = scene_info()
    hip_path = scene["hip_path"] if scene["has_named_path"] else None
    from dsh_preview_paths import allocate_managed, explicit_artifact, _safe_component
    if output_policy in ("managed", "delivery"):
        # Validate literal caller input before expansion/allocation. Only this
        # pure filename check proves zero scene writes; later failures keep
        # their own recovery semantics (including expression/renderer effects).
        if isinstance(path, str):
            try:
                _safe_component(path, field="filename")
            except ValueError as error:
                raise CheckpointError(str(error), {
                    'ok': False, 'phase': 'output_path_preflight', 'scene_writes': 0,
                    'field': 'filename', 'output_policy': output_policy,
                }) from error
        artifact = allocate_managed(
            hip_path,
            path,
            frame=frame,
            purpose=purpose,
            owner_session=_ACTIVE_OWNER_SESSION,
            repository_root=os.path.join(os.path.dirname(__file__), '..', '..'),
            default_label=default_label,
            default_extension=".png",
            allowed_extensions=allowed_extensions,
            expand=lambda value: hou.expandStringAtFrame(value, float(frame)),
            output_policy=output_policy,
        )
        return artifact["actual_path"], artifact, hip_path
    if path is None:
        frame_tag = str(float(frame)).replace('-', 'm').replace('.', 'p')
        path = f"{default_label}_{time.time_ns()}_f{frame_tag}.png"
    target = _resolve_output_path(path, frame=frame, default_subdir=default_subdir)
    extension = os.path.splitext(target)[1].lower()
    if allowed_extensions and extension not in allowed_extensions:
        raise ValueError(f"unsupported preview image extension: {extension}; use PNG or EXR")
    return target, explicit_artifact(hip_path, target, frame=frame, purpose=purpose), hip_path


def _release_preview_reservation(artifact) -> list[str]:
    from dsh_preview_paths import release_reservation
    return release_reservation(artifact)


def _render_validation(rendered, check, stale, pixel_supported=True, warnings=None) -> dict:
    errors = list(rendered.get('errors') or [])
    warnings = list(warnings or [])
    file_ok = bool(rendered.get('fresh') and rendered.get('file_bytes') and not errors)
    if not file_ok and not errors:
        errors.append('render output missing, empty or stale on disk')
    pixel_status = 'unverified'
    if pixel_supported:
        if not isinstance(check, dict) or check.get('error'):
            pixel_status = 'failed'
            errors.append('pixel inspection failed: ' + str((check or {}).get('error', 'missing check')))
        elif 'no_nonblack_content' in check.get('presentation', {}).get('reasons', []):
            pixel_status = 'failed'
            errors.append('pixel inspection: no_nonblack_content')
        elif check.get('presentation', {}).get('needs_review'):
            pixel_status = 'needs_review'
        else:
            pixel_status = 'passed'
    if stale:
        errors.append('target/proxy changed during rendering; recapture evidence')
    if warnings:
        errors.append(
            'render source has cook warnings; image retained for diagnosis but cannot pass acceptance: '
            + '; '.join(dict.fromkeys(str(item) for item in warnings))
        )
    return {'ok': not errors, 'errors': errors, 'file_status': 'passed' if file_ok else 'failed',
            'pixel_status': pixel_status, 'semantic_status': 'unverified'}


def camera_fit(camera, target, direction='iso', coverage: float = .82,
               width=None, height=None, frame=None, *, dry_run: bool = False,
               allow_foreign: str | None = None) -> dict:
    """拟合一个正式 OBJ cam 到显式 SOP 的世界空间包络，不渲染、不动用户视口。

    保留焦距/投影，按direction和coverage安全框求距离（正交则求orthowidth），
    写入后按实际矩阵回验。width/height默认取相机分辨率。允许parent变换，
    拒绝动画/表达式/约束相机、偏移或裁切窗口和lens shader。lookatpath会清空，
    只改指定相机、不移动目标；失败恢复参数。dry_run返回拟合计划，仍须exec。
    ownership及单次allow_foreign适用；持久render_view服务相机永不允许改作交付。
    Solaris用Scene Import导入此相机；render_frame(framing=...)按最终USD相机/产品
    预检，不能把OBJ取景通过当成USD产品通过。只证明当前帧包络，不证明位移/运动模糊。
    """
    _cook_control.require_evaluation('camera_fit')
    from dsh_camera_framing import fit_camera
    return fit_camera(camera, target, direction, coverage, width, height, frame, dry_run, allow_foreign)


@_with_render_slot
def render_frame(rop, picture=None, frame=None, timeout: float = 110, *, framing=None) -> dict:
    """渲染单帧并**验证产物**（等文件落盘 + 非空 + 采集 ROP 错误）。

    固化「设 picture → setFrame → rop.render() → 等产物 → 报大小」的样板：
    ``render()`` 不抛异常**不等于**产物存在（ROP 参数错、输出目录不可写、
    渲染器挂起都是静默失败），所以本动词等到文件落盘且非空才返回
    ``file_bytes``，否则在 ``errors`` 里说明。

    - rop：ROP 节点（hou.Node 或 path）。输出参数按常见名自动解析；图像参数
      ``outputimage`` 优先于 USD ``lopoutput``，Karma/Mantra/geometry 等 ROP 都覆盖。
      有 ``soho_foreground`` 时调用期临时等待渲染完成并在 finally 恢复。
    - picture：输出路径（含 $F 变量可直接传）；None = 用 ROP 当前设置。
      裸文件名按输出用途放入$HIP/dsh-render；COP copoutput放入dsh-texture，
      几何/模拟/通道缓存放入dsh-cache。已有含目录的ROP路径和显式绝对目的地不改写。
    - frame：帧号；None = 当前帧。
    - timeout：等产物的上限（秒）。超过 ~110s 的渲染请走 houdini_job_submit
      （host 侧桥请求超时 120s），本动词面向单帧测试渲染。
    - framing：可选{target:绝对USD资产prim路径, coverage:.82}。只支持USD Render ROP，
      在renderer启动/文件写入前验证实际stage全部RenderProducts的相机与目标包络。
      包含resolution/pixelAspect/aperture conform/dataWindow；失败零渲染，不自动移动相机。
      未传则保留正式/艺术裁切镜头语义。只证明本帧USD bounds，不证明位移/快门/语义质量。
    """
    _cook_control.require_evaluation('render_frame')
    n = _resolve(rop)
    if not isinstance(n, hou.RopNode) or not hasattr(n, "render"):
        if n.type().category() == hou.lopNodeTypeCategory():
            raise ValueError(
                f"{n.path()} 是普通 LOP（{n.type().name()}），不是可执行 ROP；"
                "请用 search_tab_entries('/stage', 'Karma (Setup)') + "
                "tab_apply('/stage', 'lop_karma_setup') 创建 USD Render ROP，"
                "再把该 usdrender_rop 传给 render_frame"
            )
        raise ValueError(f"{n.path()} 不是可执行 ROP，缺少 render()")
    p = None
    # USD Render ROP owns both `lopoutput` (temporary/exported USD) and
    # `outputimage` (rendered image override). Image output must win or a PNG
    # path is accidentally assigned as the USD file and no image is produced.
    for pname in ("picture", "vm_picture", "outputimage", "sopoutput",
                  "lopoutput", "dopoutput", "copoutput", "choutput"):
        p = n.parm(pname)
        if p is not None:
            break
    if p is None:
        raise ValueError(
            f"节点 '{n.path()}' 找不到输出路径参数（试过 picture/vm_picture/"
            "outputimage/sopoutput/lopoutput/dopoutput/copoutput/choutput）——"
            "它不是 ROP？（非常规输出参数请裸写 hou，词表不覆盖）"
        )
    f = hou.frame() if frame is None else float(frame)
    if not math.isfinite(f) or not math.isfinite(float(timeout)) or float(timeout) <= 0:
        raise ValueError('frame must be finite and timeout must be positive/finite')
    # Resolving before any parameter/frame write also rejects extensionless
    # outputs and relative files outside the project with zero scene effects.
    original_output = p.unexpandedString()
    output_subdir = (_project_directory('cache') if p.name() in ('sopoutput', 'dopoutput', 'choutput') else
                     _project_directory('texture') if p.name() == 'copoutput' else
                     _project_directory('render'))
    target = _resolve_output_path(original_output if picture is None else picture, frame=f,
                                  default_subdir=output_subdir)
    original_frame = float(hou.frame())
    foreground_parm = n.parm("soho_foreground")
    original_foreground = foreground_parm.eval() if foreground_parm is not None else None
    parameter_state = _parameter_snapshot([p] + ([foreground_parm] if foreground_parm is not None else []))
    framing_evidence = None
    if framing is not None:
        from dsh_camera_framing import usd_check
        try:
            if float(hou.frame()) != f:
                hou.setFrame(f)
            framing_evidence = usd_check(n, framing, f)
            if not framing_evidence['ok']:
                raise CheckpointError('USD framing failed before renderer start; fit the explicit camera or revise the intentional crop', framing_evidence)
        finally:
            if float(hou.frame()) != original_frame:
                hou.setFrame(original_frame)
    t0 = time.time()
    render_err = None
    file_bytes = None
    pre_fingerprint = None
    post_fingerprint = None

    def fingerprint(path):
        if not path or not os.path.isfile(path):
            return None
        stat = os.stat(path)
        digest = hashlib.sha256()
        with open(path, "rb") as handle:
            digest.update(handle.read(64 * 1024))
            if stat.st_size > 64 * 1024:
                handle.seek(max(0, stat.st_size - 64 * 1024))
                digest.update(handle.read(64 * 1024))
        return {
            "bytes": int(stat.st_size),
            "mtime_ns": int(stat.st_mtime_ns),
            "sample_sha256": digest.hexdigest(),
        }

    try:
        _clear_animation(p)
        p.set(target, follow_parm_reference=False)
        hou.setFrame(f)
        if foreground_parm is not None:
            _clear_animation(foreground_parm)
            foreground_parm.set(1, follow_parm_reference=False)
        pre_fingerprint = fingerprint(target)
        out_dir = os.path.dirname(target)
        if out_dir and not os.path.isdir(out_dir):
            os.makedirs(out_dir, exist_ok=True)
        try:
            if framing_evidence is not None:
                framing_evidence['render_started'] = True
            n.render(frame_range=(f, f))
        except Exception as e:  # hou.Error 等
            render_err = str(e)

        deadline = t0 + float(timeout)
        # Native render() is synchronous and can exceed the file-wait budget.
        # Always inspect the output once after it returns before reporting absence.
        while not render_err:
            post_fingerprint = fingerprint(target)
            if post_fingerprint is not None and post_fingerprint['bytes'] > 0 and post_fingerprint != pre_fingerprint:
                file_bytes = post_fingerprint["bytes"]
                break
            remaining = deadline - time.time()
            if remaining <= 0:
                break
            time.sleep(min(1, remaining))
    finally:
        restore_errors = _restore_parameters(parameter_state)
        # 渲染帧属于 agent 验证状态，不占用用户 playbar；即使 ROP 失败也还原。
        if float(hou.frame()) != original_frame:
            try:
                hou.setFrame(original_frame)
            except Exception as error:
                restore_errors.append(f'frame: {error}')
        if float(hou.frame()) != original_frame:
            restore_errors.append('frame: restoration readback differs')
        if restore_errors:
            # Failed image/output checks are ordinary returned diagnostics.
            # An unrecovered temporary scene write is different: retain its
            # evidence and let the existing exec protocol block later writes,
            # cooks, renders and saves even when agent code catches this error.
            raise CheckpointError('render_frame temporary state restoration failed', {
                'ok': False, 'phase': 'render_restore', 'restored': False,
                'restore_errors': restore_errors,
                'frame_restored': float(hou.frame()) == original_frame,
                'path': n.path(), 'output': target, 'frame': f,
                'fresh': file_bytes is not None, 'file_bytes': file_bytes,
                'pre_fingerprint': pre_fingerprint, 'post_fingerprint': post_fingerprint,
                'errors': ([render_err] if render_err else []) +
                          [f'restore failed: {error}' for error in restore_errors],
                'scope': 'snapshotted output/foreground parameters and frame only; '
                         'written files, renderer and callback side effects are separate',
            })

    errors: list[str] = []
    if render_err:
        errors.append(render_err)
    try:
        for e in n.errors():
            if e and e not in errors:
                errors.append(e)
    except Exception:
        pass
    if not render_err and file_bytes is None:
        errors.append(f"render() 未报错但产物缺失、为空或与渲染前指纹相同：{target}")
    if file_bytes:
        report_image(target)
    return {
        "path": n.path(),
        "output": target,
        "frame": f,
        "file_bytes": file_bytes,
        "preexisting": pre_fingerprint is not None,
        "fresh": file_bytes is not None,
        "pre_fingerprint": pre_fingerprint,
        "post_fingerprint": post_fingerprint,
        **({'framing': framing_evidence} if framing_evidence is not None else {}),
        "errors": errors,
        "ms": int((time.time() - t0) * 1000),
    }


_MAX_IMAGE_PIXELS = 16 * 1024 * 1024
_MAX_IMAGE_FILE_BYTES = 64 * 1024 * 1024


class _QtPixelRows:
    """Retain the decoded image, not millions of Python RGB tuple objects."""
    def __init__(self, image):
        self.image = image

    def __getitem__(self, y):
        image = self.image
        class Row:
            def __getitem__(self, x):
                color = image.pixelColor(x, y)
                return (color.red(), color.green(), color.blue())
        return Row()


class _BytePixelRows:
    def __init__(self, rows, channels):
        self.rows, self.channels = rows, channels

    def __getitem__(self, y):
        data, channels = self.rows[y], self.channels
        class Row:
            def __getitem__(self, x):
                offset = x * channels
                return (data[offset],) * 3 if channels == 1 else tuple(data[offset:offset + 3])
        return Row()


def _read_pixels_qt(path: str):
    """QImage 读像素（Houdini GUI/hython 均带 PySide6）；失败返回 None。"""
    try:
        from PySide6.QtGui import QImage, QImageReader
        reader = QImageReader(path)
        size = reader.size()
        if size.width() <= 0 or size.height() <= 0 or size.width() * size.height() > _MAX_IMAGE_PIXELS:
            return None
        img = reader.read()
        if img.isNull():
            return None
        img = img.convertToFormat(QImage.Format.Format_RGB888)
        w, h = img.width(), img.height()
        return w, h, _QtPixelRows(img)
    except Exception:
        return None


def _paeth(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    return a if pa <= pb and pa <= pc else (b if pb <= pc else c)


def _read_pixels_png(path: str):
    """纯标准库 PNG 解码（8-bit grey/RGB/RGBA，无交错）——hython 无 GUI 时的
    fallback。返回 (w, h, pixels)；不支持的格式返回 None。"""
    try:
        with open(path, "rb") as source:
            data = source.read(_MAX_IMAGE_FILE_BYTES + 1)
        if len(data) > _MAX_IMAGE_FILE_BYTES:
            return None
        if data[:8] != b"\x89PNG\r\n\x1a\n":
            return None
        pos = 8
        idat = []
        w = h = bitd = colort = None
        while pos < len(data):
            ln = struct.unpack(">I", data[pos:pos+4])[0]
            if pos + 12 + ln > len(data):
                return None
            typ = data[pos+4:pos+8]
            chunk = data[pos+8:pos+8+ln]
            if typ == b"IHDR":
                if len(chunk) != 13 or chunk[10:] != b'\x00\x00\x00':
                    return None  # nonstandard compression/filtering or Adam7
                w, h, bitd, colort = struct.unpack(">IIBB", chunk[:10])
                if w <= 0 or h <= 0 or w * h > _MAX_IMAGE_PIXELS:
                    return None
            elif typ == b"IDAT":
                idat.append(chunk)
            elif typ == b"IEND":
                break
            pos += 12 + ln
        if bitd != 8 or colort not in (0, 2, 6):
            return None
        channels = {0: 1, 2: 3, 6: 4}[colort]
        stride = w * channels
        expected = h * (stride + 1)
        decoder = zlib.decompressobj()
        raw = decoder.decompress(b''.join(idat), expected + 1)
        if len(raw) != expected or not decoder.eof or decoder.unconsumed_tail:
            return None
        pixels = []
        prev = bytearray(stride)
        off = 0
        for _y in range(h):
            filt = raw[off]
            if filt > 4:
                return None
            line = bytearray(raw[off+1:off+1+stride])
            off += 1 + stride
            for i in range(stride):
                a = line[i-channels] if i >= channels else 0
                b = prev[i]
                c = prev[i-channels] if i >= channels else 0
                if filt == 1:
                    line[i] = (line[i] + a) & 0xFF
                elif filt == 2:
                    line[i] = (line[i] + b) & 0xFF
                elif filt == 3:
                    line[i] = (line[i] + (a + b) // 2) & 0xFF
                elif filt == 4:
                    line[i] = (line[i] + _paeth(a, b, c)) & 0xFF
            pixels.append(bytes(line))
            prev = line
        return w, h, _BytePixelRows(pixels, channels)
    except Exception:
        return None


def _read_pixels(path: str):
    return _read_pixels_qt(path) or _read_pixels_png(path)


def _image_stats(w: int, h: int, pixels, max_samples: int = 512) -> dict:
    """从像素矩阵算客观指标（大图先按网格抽样，上限 max_samples 边长）。"""
    step = max(1, int(max(w, h) / max_samples) + 1)
    lumas = []
    rs = gs = bs = nb = 0
    bbox = None
    for y in range(0, h, step):
        for x in range(0, w, step):
            r, g, b = pixels[y][x]
            luma = 0.2126 * r + 0.7152 * g + 0.0722 * b
            lumas.append(luma)
            if luma > 8:  # 非黑
                nb += 1
                rs += r; gs += g; bs += b
                if bbox is None:
                    bbox = [x, y, x, y]
                else:
                    bbox[0] = min(bbox[0], x); bbox[1] = min(bbox[1], y)
                    bbox[2] = max(bbox[2], x); bbox[3] = max(bbox[3], y)
    total = len(lumas) or 1
    risk_reasons = []
    if bbox is None:
        risk_reasons.append('no_nonblack_content')
    bbox_coverage = (100 * (bbox[2] - bbox[0] + step) * (bbox[3] - bbox[1] + step) / (w * h)) if bbox else 0
    if bbox and (bbox[0] <= step or bbox[1] <= step or w - 1 - bbox[2] <= step or h - 1 - bbox[3] <= step):
        risk_reasons.append('nonblack_content_at_image_edge')
    if bbox and bbox_coverage < 10:
        risk_reasons.append('small_nonblack_bbox')
    return {
        "mean_luma": round(sum(lumas) / total, 2),
        "max_luma": round(max(lumas), 2) if lumas else 0,
        "nonblack_pct": round(nb * 100.0 / total, 2),
        "dominant": [rs // nb, gs // nb, bs // nb] if nb else None,
        "content_bbox": bbox,
        "presentation": {"needs_review": bool(risk_reasons), "reasons": risk_reasons,
                         "bbox_coverage_pct": round(min(100, bbox_coverage), 2),
                         "scope": "nonblack pixels, not object segmentation", "semantic_status": "unverified"},
    }


def render_check(path: str, ref=None) -> dict:
    """渲染产物的**客观验证**——无视觉模型时的盲验手段。

    返回亮度统计 / 非黑像素占比 / 主色 / 内容 bbox，回答「渲染是不是黑的、
    有没有内容、内容在哪」；传 ``ref``（另一张图路径）再算两图差异
    （``identical`` / ``mean_abs_diff``），用于循环帧一致性、A/B 对比。

    解码优先 PySide6 QImage（PNG/JPEG/BMP/TGA），hython 无 GUI 时退回纯
    Python PNG 解码（8-bit）；EXR 等 HDR 格式不在覆盖范围（裸 hou 逃生舱）。
    """
    result = _read_pixels(path)
    if result is None:
        raise ValueError(
            f"无法解码 '{path}'（支持 PNG/JPEG/BMP/TGA，EXR 等请裸写 hou.image）"
        )
    w, h, pixels = result
    out: dict[str, Any] = {
        "path": path,
        "width": w,
        "height": h,
        "bytes": os.path.getsize(path),
    }
    out.update(_image_stats(w, h, pixels))

    if ref is not None:
        result2 = _read_pixels(ref)
        if result2 is None:
            raise ValueError(f"无法解码 ref 图 '{ref}'")
        w2, h2, pixels2 = result2
        if (w2, h2) != (w, h):
            out["diff_vs_ref"] = {"comparable": False, "ref_size": [w2, h2]}
        else:
            step = max(1, int(max(w, h) / 512) + 1)
            diffs = []
            squared = 0.0
            channel_abs = 0.0
            changed = meaningful = 0
            for y in range(0, h, step):
                for x in range(0, w, step):
                    p1, p2 = pixels[y][x], pixels2[y][x]
                    channels = [abs(p1[i] - p2[i]) for i in range(3)]
                    pixel_diff = max(channels)
                    diffs.append(pixel_diff)
                    channel_abs += sum(channels)
                    squared += sum(value * value for value in channels)
                    if pixel_diff > 0:
                        changed += 1
                    if pixel_diff > 2:
                        meaningful += 1
            count = len(diffs)
            out["diff_vs_ref"] = {
                "comparable": True,
                "identical": max(diffs) == 0 if diffs else True,
                # 不过早舍入：40054277 草地 frame 1/12 的微小非零差异曾被
                # round(..., 3) 压成 0，掩盖“几乎静止”的关键证据。
                "mean_abs_diff": round(channel_abs / (count * 3), 8) if count else 0,
                "mean_max_channel_diff": round(sum(diffs) / count, 8) if count else 0,
                "rmse": round(math.sqrt(squared / (count * 3)), 8) if count else 0,
                "max_abs_diff": max(diffs) if diffs else 0,
                "changed_pixel_pct": round(changed * 100.0 / count, 6) if count else 0,
                "meaningful_pixel_pct": round(meaningful * 100.0 / count, 6) if count else 0,
                "sample_step": step,
                "sampled_pixels": count,
            }
    return out


# --- viewport 域 -------------------------------------------------------------

# clean 模式要隐藏的视口装饰（hou.viewportGuide 枚举名）：参考平面网格、
# 坐标指示器、手柄、物体标签、相机遮幅/安全框、性能 HUD、视图中心点。
# 网格线横穿模型会给图像识别（VLM 或 render_check 的 bbox）注入大量杂边，
# 隐藏后主体更突出；纹理（displayTextures）保留并强制开启——材质是识别线索。
_CLEAN_GUIDES = (
    "XYPlane", "YZPlane", "XZPlane",
    "OriginGnomon", "FloatingGnomon",
    "NodeHandles", "NodeGuides",
    "ObjectNames", "ObjectPaths",
    "CameraMask", "SafeArea",
    "ShowDrawTime", "ViewPivot",
)


def _display_bbox(n):
    """节点的显示几何 bbox：obj 级取其 displayNode，SOP 直接取。"""
    _cook_control.require_evaluation('display geometry bounds')
    try:
        d = n.displayNode()
        if d is not None:
            return d.geometry().boundingBox()
    except Exception:
        pass
    return n.geometry().boundingBox()


def _webview_was_minimized():
    """Return the pre-capture minimized state when the optional WebView exists."""
    try:
        import dsh_webview
        win = getattr(dsh_webview, "_window", None)
        return None if win is None else bool(win.isMinimized())
    except Exception:
        return None


def _restore_webview_window(was_minimized=None) -> None:
    """截图后还原被最小化的内嵌 web UI 窗口（dsh_webview）。

    用户报告（2026-08-18）：agent 截图时 agent 窗口会最小化，要手动从
    任务栏点回。只在确实处于最小化状态时还原——用户只是切去 Houdini
    干活（失焦/被遮）时不抢焦点。可选依赖：webview 未开过/导入失败就静默。
    """
    try:
        import dsh_webview
    except Exception:
        return
    win = getattr(dsh_webview, "_window", None)
    if win is None:
        return
    try:
        if was_minimized is not True and win.isMinimized():
            win.showNormal()
            dsh_webview._bring_to_front(win)
    except Exception:
        pass


def _viewport_camera_state(camera) -> tuple:
    """Comparable readback for the documented H21/H22 viewport-camera surface."""
    values = []
    for name in ('translation', 'rotation', 'pivot', 'aperture', 'aspectRatio',
                 'clipPlanes', 'focalLength', 'focalUnitScale', 'orthoWidth',
                 'windowOffset', 'windowSize', 'isOrthographic'):
        method = getattr(camera, name, None)
        if not callable(method):
            raise RuntimeError(f'viewport camera readback unavailable: {name}')
        value = method()
        if isinstance(value, (hou.Matrix3, hou.Matrix4)):
            value = tuple(float(item) for item in value.asTuple())
        elif isinstance(value, (tuple, list, hou.Vector2, hou.Vector3, hou.Vector4)):
            value = tuple(float(item) for item in value)
        elif isinstance(value, bool):
            value = bool(value)
        else:
            value = float(value)
        values.append((name, value))
    return tuple(values)


def _viewport_camera_states_equal(before, after, tolerance=1e-8) -> bool:
    before_map, after_map = dict(before), dict(after)
    if set(before_map) != set(after_map):
        return False
    for name_a, value_a in before:
        if name_a == 'orthoWidth' and not before_map['isOrthographic'] and not after_map['isOrthographic']:
            continue  # inactive perspective-camera field is normalized by setDefaultCamera
        value_b = after_map[name_a]
        if isinstance(value_a, tuple):
            if not isinstance(value_b, tuple) or len(value_a) != len(value_b):
                return False
            if any(not math.isclose(float(a), float(b), rel_tol=0.0, abs_tol=tolerance)
                   for a, b in zip(value_a, value_b)):
                return False
        elif isinstance(value_a, bool):
            if value_a is not value_b:
                return False
        elif not math.isclose(float(value_a), float(value_b), rel_tol=0.0, abs_tol=tolerance):
            return False
    return True


def _same_network_item(left, right) -> bool:
    if left is right:
        return True
    try:
        return int(left.sessionId()) == int(right.sessionId())
    except Exception:
        try:
            return left.path() == right.path()
        except Exception:
            return False


def _readable_tga(path: str) -> bool:
    """Bounded structural completeness check for common TGA flipbook output."""
    if os.path.splitext(path)[1].lower() != '.tga':
        return False
    try:
        with open(path, 'rb') as source:
            data = source.read(_MAX_IMAGE_FILE_BYTES + 1)
        if len(data) > _MAX_IMAGE_FILE_BYTES or len(data) < 18:
            return False
        ident, cmap, kind = data[0], data[1], data[2]
        cmap_len = int.from_bytes(data[5:7], 'little')
        cmap_bits = data[7]
        width = int.from_bytes(data[12:14], 'little')
        height = int.from_bytes(data[14:16], 'little')
        depth = data[16]
        if not width or not height or width * height > _MAX_IMAGE_PIXELS:
            return False
        if cmap not in (0, 1) or kind not in (2, 3, 10, 11) or depth not in (8, 16, 24, 32):
            return False
        offset = 18 + ident + ((cmap_len * cmap_bits + 7) // 8 if cmap else 0)
        bytes_per_pixel = (depth + 7) // 8
        pixels = width * height
        if kind in (2, 3):
            return len(data) >= offset + pixels * bytes_per_pixel
        produced = 0
        while produced < pixels and offset < len(data):
            header = data[offset]; offset += 1
            count = (header & 0x7f) + 1
            payload = bytes_per_pixel if header & 0x80 else count * bytes_per_pixel
            if offset + payload > len(data):
                return False
            offset += payload; produced += count
        return produced == pixels
    except Exception:
        return False


def _screenshot_readable(path: str) -> bool:
    return (_read_pixels_qt(path) is not None or _read_pixels_png(path) is not None
            or _readable_tga(path))


def viewport_screenshot(path=None, frame=None, clean=True, frame_target=None,
                        textures=None, backface_cull=False, *,
                        output_policy: str = "managed") -> dict:
    """Capture the selected viewport with bounded freshness and full restoration.

    Managed output (the default) accepts only an omitted filename or safe
    basename and writes under ``$HIP/dsh-visual-checks/<run-id>/``. Deliberate
    Delivery images use ``output_policy='delivery'`` under ``$HIP/dsh-render``;
    custom destinations use ``output_policy='explicit'``; an explicit bare
    filename goes under ``$HIP/dsh-visual-checks/``. The capture is a user-screen
    diagnostic: readable pixels are required, but visual semantics remain
    unverified.  H21/H22 require stashed flipbook and viewport-camera state;
    unsupported restoration combinations reject before mutation.
    """
    if not hou.isUIAvailable():
        raise ValueError("viewport_screenshot 需要 Houdini GUI（当前无 UI）；headless 环境请用 render_frame")
    f = float(hou.frame()) if frame is None else float(frame)
    if not math.isfinite(f):
        raise ValueError('frame must be finite')
    viewer = hou.ui.curDesktop().paneTabOfType(hou.paneTabType.SceneViewer)
    if viewer is None:
        raise ValueError("当前桌面没有 Scene Viewer 面板——请先打开一个场景视口")
    vp = viewer.curViewport()
    if vp is None:
        raise ValueError("Scene Viewer 没有活动视口")
    st = vp.settings()

    # Resolve identity only. Geometry is evaluated after path validation and
    # after switching to the requested frame inside the protected lifecycle.
    target_node = None
    if frame_target is True:
        try:
            frame_target = next((c for c in hou.node('/obj').children() if c.isDisplayFlagSet()), None)
        except Exception:
            frame_target = None
    if frame_target is not None:
        target_node = _resolve(frame_target)
    framed = target_node.path() if target_node is not None else None

    live_settings = viewer.flipbookSettings()
    stash_settings = getattr(live_settings, 'stash', None)
    if not callable(stash_settings):
        raise RuntimeError('copied flipbook settings are unavailable on this Houdini build')
    settings = stash_settings()
    if settings is None or settings is live_settings:
        raise RuntimeError('flipbook settings stash did not return an independent copy')
    leave_getter = getattr(live_settings, 'leaveFrameAtEnd', None)
    live_before = (live_settings.output(), live_settings.outputToMPlay(), live_settings.frameRange(),
                   leave_getter() if callable(leave_getter) else None)

    camera_snapshot = None
    camera_state_before = None
    linked_camera = None
    camera_lock_before = None
    if target_node is not None:
        camera = vp.defaultCamera()
        stash_camera = getattr(camera, 'stash', None)
        if not callable(stash_camera) or not callable(getattr(vp, 'setDefaultCamera', None)):
            raise RuntimeError('full viewport camera restoration is unavailable on this Houdini build')
        camera_snapshot = stash_camera()
        camera_state_before = _viewport_camera_state(camera)
        for name in ('camera', 'setCamera', 'useDefaultCamera', 'isCameraLockedToView', 'lockCameraToView'):
            if not callable(getattr(vp, name, None)):
                raise RuntimeError(f'viewport camera association restoration is unavailable: {name}')
        linked_camera = vp.camera()
        camera_lock_before = bool(vp.isCameraLockedToView())

    path, artifact, artifact_hip_path = _preview_artifact(
        path, frame=f, purpose='viewport_diagnostic', output_policy=output_policy,
        default_label='viewport', default_subdir=_project_directory('visual_check'),
        allowed_extensions={'.png', '.jpg', '.jpeg', '.bmp', '.tga'})

    import glob as _glob
    stem, ext = os.path.splitext(path)

    def candidate_allowed(candidate):
        if os.path.normcase(os.path.abspath(candidate)) == os.path.normcase(os.path.abspath(path)):
            return True
        if not float(f).is_integer():
            return False
        if os.path.dirname(os.path.abspath(candidate)) != os.path.dirname(os.path.abspath(path)):
            return False
        name = os.path.basename(candidate)
        base = os.path.basename(stem)
        if not name.lower().endswith(ext.lower()) or not name.startswith(base):
            return False
        suffix = name[len(base):len(name) - len(ext)]
        match = re.fullmatch(r'[._-](\d+)', suffix)
        return bool(match and int(match.group(1)) == int(f))

    def candidates():
        found = {os.path.normcase(os.path.abspath(path)): path}
        pattern = _glob.escape(stem) + '*' + _glob.escape(ext)
        for item in _glob.glob(pattern):
            if candidate_allowed(item):
                found.setdefault(os.path.normcase(os.path.abspath(item)), item)
        return sorted(found.values())

    def fingerprint(candidate):
        if not os.path.isfile(candidate):
            return None
        stat = os.stat(candidate)
        digest = hashlib.sha256()
        with open(candidate, 'rb') as handle:
            digest.update(handle.read(64 * 1024))
            if stat.st_size > 64 * 1024:
                handle.seek(max(0, stat.st_size - 64 * 1024))
                digest.update(handle.read(64 * 1024))
        return (int(stat.st_size), int(stat.st_mtime_ns), digest.hexdigest())

    original_frame = float(hou.frame())
    webview_was_minimized = _webview_was_minimized()
    before_files = {}
    actual = None
    capture_error = None
    capture_unresolved = False
    dispatch_attempted = False
    capture_settled = False
    restore_errors = []
    saved_guides = []
    saved_textures = None
    saved_backface = None
    refplane = None
    refplane_was = False
    lock_attempted = detach_attempted = detached = False

    try:
        out_dir = os.path.dirname(path)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        before_files = {candidate: fingerprint(candidate) for candidate in candidates()}

        # A linked camera is detached before frame or viewport manipulation.
        if target_node is not None and linked_camera is not None:
            if camera_lock_before:
                lock_attempted = True
                vp.lockCameraToView(False)
                if vp.isCameraLockedToView():
                    raise RuntimeError('viewport camera remained locked after unlock')
            detach_attempted = True
            vp.useDefaultCamera()
            detached = vp.camera() is None
            if not detached:
                raise RuntimeError('viewport camera remained linked after detachment')

        hou.setFrame(f)
        if float(hou.frame()) != f:
            raise RuntimeError('requested capture frame was not applied')

        if clean:
            try:
                refplane = viewer.referencePlane()
                refplane_was = bool(refplane.isVisible())
            except Exception:
                refplane = None
            if refplane is not None and refplane_was:
                refplane.setIsVisible(False)
            for name in _CLEAN_GUIDES:
                guide = getattr(hou.viewportGuide, name, None)
                if guide is None:
                    continue
                try:
                    enabled = bool(st.guideEnabled(guide))
                except Exception:
                    continue
                if enabled:
                    saved_guides.append(guide)
                    st.enableGuide(guide, False)
        if textures is not None:
            saved_textures = bool(st.displayTextures())
            st.setDisplayTextures(bool(textures))
        if backface_cull:
            saved_backface = bool(st.removeBackfaces())
            st.setRemoveBackfaces(True)
        if target_node is not None:
            vp.frameBoundingBox(_display_bbox(target_node))

        settings.output(path)
        settings.outputToMPlay(False)
        settings.frameRange((f, f))
        leave_at_end = getattr(settings, 'leaveFrameAtEnd', None)
        if callable(leave_at_end):
            leave_at_end(False)
        dispatch_attempted = True
        viewer.flipbook(viewport=vp, settings=settings)

        deadline = time.time() + 15
        stable = {}
        while time.time() < deadline:
            changed = []
            for candidate in candidates():
                current = fingerprint(candidate)
                if current is not None and current[0] > 0 and current != before_files.get(candidate):
                    changed.append((candidate, current))
            if len(changed) > 1:
                raise RuntimeError(f"flipbook produced ambiguous screenshot candidates: {[item[0] for item in changed]}")
            if changed:
                candidate, current = changed[0]
                if _screenshot_readable(candidate):
                    if stable.get(candidate) == current:
                        actual = candidate
                        break
                    stable = {candidate: current}
                else:
                    stable = {}
            time.sleep(0.2)
        else:
            capture_unresolved = True
            raise RuntimeError(f"flipbook did not produce a stable readable screenshot: {path}")
    except BaseException as error:
        capture_error = error
        if dispatch_attempted and not capture_settled:
            capture_unresolved = True
    finally:
        # Restore display state first while the viewport remains safely detached.
        if refplane is not None and refplane_was:
            try:
                refplane.setIsVisible(True)
                if not refplane.isVisible():
                    raise RuntimeError('readback remained hidden')
            except Exception as error:
                restore_errors.append(f'reference plane: {error}')
        for guide in saved_guides:
            try:
                st.enableGuide(guide, True)
                if not st.guideEnabled(guide):
                    raise RuntimeError('readback remained disabled')
            except Exception as error:
                restore_errors.append(f'viewport guide: {error}')
        if saved_textures is not None:
            try:
                st.setDisplayTextures(saved_textures)
                if bool(st.displayTextures()) != saved_textures:
                    raise RuntimeError('readback mismatch')
            except Exception as error:
                restore_errors.append(f'textures: {error}')
        if saved_backface is not None:
            try:
                st.setRemoveBackfaces(saved_backface)
                if bool(st.removeBackfaces()) != saved_backface:
                    raise RuntimeError('readback mismatch')
            except Exception as error:
                restore_errors.append(f'backface culling: {error}')

        # If detachment partially failed, retry a safe detach before any
        # viewport-camera snapshot is applied. Never setDefaultCamera while a
        # linked, locked scene camera remains active.
        safe_default = target_node is not None and linked_camera is None
        if target_node is not None and linked_camera is not None:
            try:
                if vp.isCameraLockedToView():
                    vp.lockCameraToView(False)
                if vp.camera() is not None:
                    vp.useDefaultCamera()
                safe_default = vp.camera() is None and not vp.isCameraLockedToView()
                if not safe_default:
                    raise RuntimeError('could not obtain a safely detached viewport')
            except Exception as error:
                restore_errors.append(f'camera detachment: {error}')
                safe_default = False
        try:
            if float(hou.frame()) != original_frame:
                hou.setFrame(original_frame)
            if float(hou.frame()) != original_frame:
                raise RuntimeError('frame readback mismatch')
        except Exception as error:
            restore_errors.append(f'frame: {error}')

        if target_node is not None and safe_default:
            try:
                vp.setDefaultCamera(camera_snapshot)
                camera_state_after = _viewport_camera_state(vp.defaultCamera())
                if not _viewport_camera_states_equal(camera_state_before, camera_state_after):
                    raise RuntimeError(f'viewport camera readback mismatch: before={camera_state_before!r}, after={camera_state_after!r}')
            except Exception as error:
                restore_errors.append(f'viewport camera: {error}')
        if target_node is not None and linked_camera is not None:
            try:
                vp.setCamera(linked_camera)
                if not _same_network_item(vp.camera(), linked_camera):
                    raise RuntimeError('linked camera readback mismatch')
            except Exception as error:
                restore_errors.append(f'linked camera: {error}')
            try:
                vp.lockCameraToView(camera_lock_before)
                if bool(vp.isCameraLockedToView()) != camera_lock_before:
                    raise RuntimeError('camera lock readback mismatch')
            except Exception as error:
                restore_errors.append(f'camera lock: {error}')

        try:
            leave_now = leave_getter() if callable(leave_getter) else None
            live_after = (live_settings.output(), live_settings.outputToMPlay(),
                          live_settings.frameRange(), leave_now)
            if live_after != live_before:
                raise RuntimeError('interactive flipbook settings changed')
        except Exception as error:
            restore_errors.append(f'flipbook settings: {error}')
        _restore_webview_window(webview_was_minimized)

    from dsh_preview_paths import retain_reservation, with_actual_path
    validated_artifact = None
    actual_validated = False
    try:
        validated_artifact = with_actual_path(artifact, actual or path, artifact_hip_path)
        actual_validated = actual is not None
        if actual_validated:
            capture_settled = True
    except Exception as error:
        capture_error = capture_error or error
    if dispatch_attempted and not capture_settled:
        capture_unresolved = True
    if capture_unresolved:
        retain_reservation(artifact)
    else:
        restore_errors.extend(_release_preview_reservation(artifact))
    if validated_artifact is not None:
        if artifact.get('reservation_retained'):
            validated_artifact['reservation_retained'] = True
        artifact = validated_artifact
    else:
        artifact = {key: value for key, value in artifact.items()
                    if not key.startswith('_reservation')}
    if actual_validated:
        report_image(actual)
    failure_evidence = {
        'ok': False, 'path': actual or path, 'artifact': artifact, 'frame': f,
        'fresh': actual_validated, 'file_status': 'passed' if actual_validated else 'failed',
        'capture_unresolved': capture_unresolved,
        'semantic_status': 'unverified', 'user_state_restored': not restore_errors,
        'restore_errors': restore_errors,
        'scope': 'frame, copied flipbook settings, changed viewport guides/display settings, framing camera and camera association',
    }
    if capture_error is not None or restore_errors:
        reasons = ([str(capture_error)] if capture_error is not None else [])
        reasons.extend(f'restore failed: {item}' for item in restore_errors)
        failure_evidence['errors'] = reasons
        raise CheckpointError('viewport screenshot failed: ' + '; '.join(reasons), failure_evidence)

    result: dict[str, Any] = {
        'ok': True, 'path': actual, 'artifact': artifact,
        'viewer': viewer.name(), 'viewport': vp.name(), 'frame': f,
        'bytes': os.path.getsize(actual), 'fresh': True, 'file_status': 'passed',
        'semantic_status': 'unverified', 'user_state_restored': True,
        'restore_errors': [],
        'scope': 'frame, copied flipbook settings, changed viewport guides/display settings, framing camera and camera association',
        'clean': bool(clean),
    }
    if framed is not None:
        result['framed'] = framed
    return result


def _try_set(node: hou.Node, name: str, value) -> bool:
    """防御性设参：参数存在才设，返回是否成功（跨版本参数名可能不同）。"""
    p = node.parm(name)
    if p is None:
        return False
    try:
        p.set(value)
        return True
    except Exception:
        return False


_RENDER_PROXY_NAME = "__dsh_houdini_render_proxy"
_RENDER_CAMERA_NAME = "__dsh_houdini_cam"
_RENDER_TARGET_NAME = "__dsh_houdini_target"
_RENDER_ROP_NAME = "__dsh_houdini_opengl"
_RENDER_FLIPBOOK_NAME = "__dsh_houdini_flipbook"


def _owned_node(parent: hou.Node, name: str, type_name: str) -> hou.Node:
    node = parent.node(name)
    if node is not None:
        if node.userData(_RENDER_OWNER_KEY) != _RENDER_OWNER_VALUE:
            raise ValueError(
                f"agent render 基础设施路径 {node.path()} 已被用户节点占用；"
                f"请重命名该节点后重试（不会自动接管/删除用户节点）"
            )
        return node
    node = parent.createNode(type_name, node_name=name)
    node.setUserData(_RENDER_OWNER_KEY, _RENDER_OWNER_VALUE)
    # A current preview may add Flipbook to a HIP retaining the legacy OpenGL
    # renderer. Place only this newly created root service node beside the
    # existing service group; its default origin would enlarge the box again.
    if (parent.path() in ('/obj', '/out')
            and parent.findNetworkBox(_RENDER_OBJ_BOX_NAME) is not None):
        existing = [child for child in parent.children()
                    if child != node
                    and child.userData(_RENDER_OWNER_KEY) == _RENDER_OWNER_VALUE]
        if existing:
            node.setPosition(hou.Vector2(
                min(float(child.position()[0]) for child in existing),
                min(float(child.position()[1]) for child in existing) - 1.5))
    return node


def _render_service_box(parent: hou.Node, name: str,
                        nodes: list[hou.Node]) -> hou.NetworkBox:
    """Keep persistent render infrastructure grouped away from user nodes.

    Only the first creation chooses a position. Subsequent calls preserve any
    placement the user made while still repairing box membership/comment.
    Persist a fixed fit. The title must round-trip through HIP metadata; an
    invalid native title can reset the bounds to the origin on the next load.
    """
    box = parent.findNetworkBox(name)
    created = box is None
    if box is None:
        box = parent.createNetworkBox(name)

    if created:
        owned = set(nodes)
        positions = [
            child.position() for child in parent.children()
            if child not in owned
        ]
        anchor_x = max((float(pos[0]) for pos in positions), default=0.0) + 6.0
        anchor_y = max((float(pos[1]) for pos in positions), default=0.0)
        for index, node in enumerate(nodes):
            node.setPosition(hou.Vector2(anchor_x, anchor_y - index * 1.5))

    # A HIP can retain both a legacy OpenGL ROP and the current Flipbook ROP. They are
    # persistent service nodes even when only one is used by this preview.
    owned = {
        child for child in parent.children()
        if child.userData(_RENDER_OWNER_KEY) == _RENDER_OWNER_VALUE
    }
    members = set(box.items(recurse=False))
    for item in members - owned:
        box.removeItem(item)
    for node in owned - members:
        box.addItem(node)
    box.setComment(_RENDER_BOX_COMMENT)
    box.setColor(hou.Color((0.12, 0.20, 0.30)))
    box.setAutoFit(False)
    box.fitAroundContents()
    from dsh_network_boxes import register_service_box
    register_service_box(box)
    return box


def _resolve_render_sop(node) -> tuple[hou.Node, str | None]:
    target = _resolve(node)
    category = target.type().category()
    if category == hou.sopNodeTypeCategory():
        return target, None
    if category == hou.objNodeTypeCategory():
        resolved = None
        for getter in ("renderNode", "displayNode"):
            try:
                resolved = getattr(target, getter)()
            except Exception:
                resolved = None
            if resolved is not None:
                break
        if resolved is None:
            raise ValueError(
                f"OBJ {target.path()} 没有可解析的 render/display SOP；"
                "为确定性验证请直接传显式 SOP 输出节点"
            )
        return resolved, (
            f"传入 OBJ {target.path()}，调用开始时解析为 {resolved.path()}；"
            "用户可移动 OBJ 内旗标，确定性验证建议直接传 SOP path"
        )
    raise ValueError(
        f"render_view 只接受 SOP 或 Geometry OBJ，收到 {target.path()} "
        f"({category.name()})"
    )


def _geometry_fingerprint(node: hou.Node, frame: float) -> dict:
    _cook_control.require_evaluation('geometry fingerprint')
    geometry = node.geometryAtFrame(frame)
    if geometry is None:
        raise ValueError(f"节点 {node.path()} 在 frame {frame} 没有 geometry")
    points = int(geometry.intrinsicValue("pointcount"))
    prims = int(geometry.intrinsicValue("primitivecount"))
    if points == 0 and prims == 0:
        raise ValueError(
            f"节点 {node.path()} 在 frame {frame} cook 成功但没有可渲染几何；"
            "请传非空显式输出 SOP"
        )
    bbox = geometry.boundingBox()
    bbox_min = [float(v) for v in bbox.minvec()]
    bbox_max = [float(v) for v in bbox.maxvec()]
    signature = hashlib.sha256()
    signature.update(f"{points}|{prims}|{bbox_min}|{bbox_max}".encode("utf-8"))
    # 有界抽样 P：检测用户/上游在验证期间改变真实目标，不遍历百万点全量。
    if points and geometry.findPointAttrib("P") is not None:
        count = min(points, 257)
        indices = [0] if count == 1 else sorted({
            round(i * (points - 1) / (count - 1)) for i in range(count)
        })
        for index in indices:
            position = geometry.point(index).position()
            signature.update(struct.pack(
                "<3d",
                float(position[0]),
                float(position[1]),
                float(position[2]),
            ))
    errors = list(node.errors())
    warnings = list(node.warnings())
    return {
        "path": node.path(),
        "session_id": node.sessionId(),
        "type": node.type().name(),
        "frame": float(frame),
        "points": points,
        "prims": prims,
        "bbox_min": bbox_min,
        "bbox_max": bbox_max,
        "point_attrs": sorted(a.name() for a in geometry.pointAttribs()),
        "prim_attrs": sorted(a.name() for a in geometry.primAttribs()),
        "errors": errors,
        "warnings": warnings,
        "signature": signature.hexdigest()[:24],
        'signature_scope': 'counts, bounds and at most 257 sampled point positions; excludes unsampled positions, attribute values, primitive topology/intrinsics and object transforms. Equal signatures mean no sampled change detected, not complete geometry identity',
    }


def _ensure_render_proxy(target_sop: hou.Node) -> tuple[hou.Node, hou.Node]:
    obj = hou.node("/obj")
    proxy = _owned_node(obj, _RENDER_PROXY_NAME, "geo")
    if target_sop.parent() == proxy:
        raise ValueError("render_view 不能把 agent render proxy 自身作为源")
    source = proxy.node("source")
    if source is None:
        for child in list(proxy.children()):
            child.destroy()
        source = proxy.createNode("object_merge", node_name="source")
        source.setUserData(_RENDER_OWNER_KEY, _RENDER_OWNER_VALUE)
    elif source.userData(_RENDER_OWNER_KEY) != _RENDER_OWNER_VALUE:
        raise ValueError(f"agent proxy 内部路径 {source.path()} 被非 agent 节点占用")
    output = proxy.node("OUT")
    if output is None:
        output = proxy.createNode("null", node_name="OUT")
        output.setUserData(_RENDER_OWNER_KEY, _RENDER_OWNER_VALUE)
    elif output.userData(_RENDER_OWNER_KEY) != _RENDER_OWNER_VALUE:
        raise ValueError(f"agent proxy 内部路径 {output.path()} 被非 agent 节点占用")
    source.parm("objpath1").set(target_sop.path())
    proxy.setUserData("dsh_render_state", "active")
    proxy.setUserData("dsh_last_target", target_sop.path())
    source.setComment(
        "Temporary render_view source; bound only for the active render.\n"
        f"Current target: {target_sop.path()}"
    )
    _try_set(source, "xformtype", 1)  # Into This Object：保留源 OBJ 世界变换
    output.setInput(0, source)
    output.setDisplayFlag(True)
    output.setRenderFlag(True)
    output.cook(force=True)
    proxy.setDisplayFlag(False)  # forceobjects 仍可渲染；用户 viewport 不出现 proxy
    return proxy, output


def _snapshot_obj_visibility() -> dict:
    states = {}
    for child in hou.node("/obj").children():
        try:
            states[child.path()] = bool(child.isDisplayFlagSet())
        except Exception:
            pass
    return states


def _restore_obj_visibility(states: dict) -> list:
    errors = []
    for path, visible in states.items():
        node = hou.node(path)
        if node is None:
            errors.append(f"missing object during restore: {path}")
            continue
        try:
            node.setDisplayFlag(bool(visible))
        except Exception as error:
            errors.append(f"{path}: {error}")
    return errors


def _snapshot_selection() -> list:
    try:
        return [node.path() for node in hou.selectedNodes()]
    except Exception:
        return []


def _restore_selection(paths: list) -> list:
    errors = []
    try:
        hou.clearAllSelected()
    except Exception as error:
        return [str(error)]
    for path in paths:
        node = hou.node(path)
        if node is not None:
            try:
                node.setSelected(True)
            except Exception as error:
                errors.append(f"{path}: {error}")
    return errors


# render_view 的命名视角（direction 接受这些字符串）：意图层词汇，
# top 故意不沿正 Y（与 up 向量共线会导致 lookat 退化）。
_NAMED_DIRECTIONS = {
    "iso": (1.0, 0.7, 1.0),
    "front": (0.0, 0.25, 1.0),
    "side": (1.0, 0.25, 0.0),
    "top": (0.001, 1.0, 0.001),
}


# ``render_view`` is a visual-inspection/presentation path, so its default PNG
# must be display encoded. The viewport renderer produces scene-linear values; writing
# those values unchanged to an 8-bit PNG makes ordinary image viewers treat
# linear samples as sRGB and crushes the shadows.  EXR/HDR remain scene-linear
# for compositing applications such as Nuke.
_DISPLAY_IMAGE_EXTENSIONS = frozenset({
    ".png", ".jpg", ".jpeg", ".bmp", ".tga", ".tif", ".tiff",
})
_LINEAR_IMAGE_EXTENSIONS = frozenset({".exr", ".hdr", ".pic", ".rat"})
_SRGB_OCIO_SPACE_PREFERENCES = (
    # Houdini 22 / OCIO config 3 (ACES 2).
    "sRGB Encoded Rec.709 (sRGB)",
    # Houdini 21 / OCIO config 2.1 (ACES 1.3).
    "sRGB - Texture",
    # Common studio/legacy alias.
    "Utility - sRGB - Texture",
)


def _select_srgb_ocio_space(spaces=None) -> str | None:
    """Return an encoded sRGB output space across shipped H21/H22 configs."""
    if spaces is None:
        try:
            spaces = hou.Color.ocio_spaces()
        except Exception:
            spaces = ()
    available = {str(space) for space in spaces}
    for preferred in _SRGB_OCIO_SPACE_PREFERENCES:
        if preferred in available:
            return preferred

    # Custom configs often rename the utility space.  Prefer an encoded or
    # texture sRGB space, but never silently select a display reference space:
    # the OpenGL ROP parameter expects an output colorspace, not a display/view
    # pair.
    candidates = sorted(
        space for space in available
        if "srgb" in space.lower()
        and "display" not in space.lower()
        and ("encoded" in space.lower() or "texture" in space.lower())
    )
    return candidates[0] if candidates else None


def _render_output_color_plan(picture, ocio_spaces=None) -> dict:
    """Choose scene-linear vs display encoding from the requested file type."""
    extension = os.path.splitext(os.fspath(picture))[1].lower()
    if extension in _LINEAR_IMAGE_EXTENSIONS:
        return {
            "mode": "scene_linear",
            "extension": extension,
            "method": "none",
            "ocio_colorspace": None,
            "approximate": False,
            "settings": {
                "colorcorrect": "none",
                "gamma": 1.0,
                "lut": "",
                "ociocolorspace": "",
                "ociolooks": "",
            },
        }

    # Unknown extensions follow render_view's presentation intent.  Known
    # display formats are listed explicitly for diagnostics, but defaulting an
    # unfamiliar 8-bit writer to linear would recreate the original dark-image
    # failure.
    target = _select_srgb_ocio_space(ocio_spaces)
    if target:
        return {
            "mode": "display_srgb",
            "extension": extension,
            "known_display_extension": extension in _DISPLAY_IMAGE_EXTENSIONS,
            "method": "ocio_colorspace",
            "ocio_colorspace": target,
            "approximate": False,
            "settings": {
                "colorcorrect": "ocio",
                "gamma": 1.0,
                "lut": "",
                "ociocolorspace": target,
                "ociolooks": "",
            },
        }

    # A custom OCIO config may expose no encoded sRGB output space.  Preserve a
    # usable visual-inspection PNG with the OpenGL ROP's gamma path, and report
    # that this is an approximation rather than pretending it is an exact sRGB
    # transfer function.
    return {
        "mode": "display_srgb",
        "extension": extension,
        "known_display_extension": extension in _DISPLAY_IMAGE_EXTENSIONS,
        "method": "gamma_fallback",
        "ocio_colorspace": None,
        "approximate": True,
        "settings": {
            "colorcorrect": "lut_gamma",
            "gamma": 2.2,
            "lut": "",
            "ociocolorspace": "",
            "ociolooks": "",
        },
    }


@_with_render_slot
@_preserve_render_service_on_undo
def render_view(node, direction="iso", frame=None,
                width: int = 1280, height: int = 720, picture=None,
                framing: str = "full", coverage: float = 0.82,
                framing_frame=None, *, output_policy: str = "managed",
                focus_group=None, isolate: bool = False,
                projection: str = 'perspective', framing_bounds=None, depth_bounds=None) -> dict:
    """显式 SOP → agent proxy → viewport ROP → render_check 的隔离验证。
    H22使用Flipbook/Vulkan及独立Work Lights；H21保持原OpenGL ROP设置。

    用户可随时把源 OBJ 的 display/render flag 切到空节点：本动词不跟随它，
    而是让 agent-owned Object Merge 指向传入的**具体 SOP**，OpenGL ROP 用
    ``forceobjects`` 只渲染 proxy。用户 OBJ 可见性、selection、playbar 均恢复。

    - ``node``：强烈建议显式 SOP；传 OBJ 时只在调用开始解析一次 render/display SOP。
    - ``direction``：视线方向（从目标指向相机的偏移向量），默认 3/4 俯视。
      也接受命名视角：``'iso'``（3/4 俯视）、``'front'``、``'side'``、
      ``'top'``（草地重跑 trace：agent 直觉写法就是 ``'iso'``——命名视角
      是意图，向量是实现）。
    - ``frame``：帧号；None = 当前帧。
    - ``picture/output_policy``：默认managed，只接收省略或安全basename并写入
      ``$HIP/dsh-visual-checks/<run-id>/``。
      最终交付用``output_policy='delivery'``分配到``$HIP/dsh-render/``；自定路径用
      ``output_policy='explicit'``，其中裸文件名放进``$HIP/dsh-visual-checks/``。
      各模式均返回``artifact``路径事实，输出位置不证明验收通过。
    - ``framing``：``full`` 完整入镜；``detail`` 缩小画幅（正交宽度/透视视角），不推进相机。
      detail仅允许画框外裁切，near/far深度裁切始终拒绝；不以拓扑正确排除相机切断。
    - ``coverage``：full中央安全框宽/高占比（0.1..0.95）；.82为每侧至少9%边距。
    - ``framing_frame``：用哪一帧的 bbox 计算相机；None = 跟随 ``frame``。动画
      A/B 应给两次调用传同一个 framing_frame，确保相机 center/eye/dist 完全一致。
    - 输出颜色按扩展名自动管理：PNG/JPEG/TIFF 等展示格式从当前
      ``scene_linear`` 经 OCIO 转为编码 sRGB；EXR/HDR 保持线性供 Nuke/合成。
      返回 ``output_color`` 记录实际方法与目标空间，不用 gamma 猜测冒充 OCIO。
    - 返回 source/proxy fingerprint；真实目标在验证期间变化时 ``stale=True``。
    - focus_group为精确primitive组，空/缺失拒绝；isolate只在持久proxy中保留该组。
      projection为perspective/orthographic。framing_bounds=[min_xyz,max_xyz]使用proxy世界坐标；
      full中是完整取景包络，不是局部ROI。局部观察用focus_group，或detail配合局部bounds。
    - depth_bounds=[min_xyz,max_xyz]是全部实际渲染内容的深度包络，含未隔离上下文。
      默认取framing_frame的全部proxy；给framing_bounds但没给depth_bounds时沿用同一包络。
      A/B同时复用返回framing.bounds和framing.depth_bounds及相同方向/画幅/模式；越界拒绝不漂移。
    - 返回dict含output/check/framing/errors/stale；check含presentation/content_bbox等像素事实。
      pixels是check兼容别名，Bridge证据也提供check/pixels；不能把ok当视觉语义通过。
      源或proxy有cook warning时仍保留诊断图片，但返回ok=False并把warning写入errors，
      不能用文件/像素成功核销视觉完成门。

    本工具仍要求GUI会话；这不是对Flipbook原生headless能力的限制声明。
    H22要求Vulkan兼容设备，H21保持原GUI边界；headless另走render_frame。
    硬件预览在Windows锁屏/远程桌面断开时可能失败，
    失败会体现在返回的 ``errors`` 里。
    """
    if not hou.isUIAvailable():
        raise ValueError(
            "render_view 当前支持范围需要 Houdini GUI；"
            "headless 环境请用 render_frame 走 CPU 渲染器"
        )
    _cook_control.require_evaluation('render_view')
    if framing not in ("full", "detail"):
        raise ValueError("framing 只能是 'full' 或 'detail'")
    if not isinstance(isolate, bool) or (isolate and focus_group is None):
        raise ValueError('isolate requires an explicit focus_group')
    if projection not in ('perspective', 'orthographic'):
        raise ValueError('projection must be perspective or orthographic')
    if focus_group is not None and (not isinstance(focus_group,str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',focus_group)):
        raise ValueError('focus_group must be an exact named primitive group, not a pattern')
    coverage = float(coverage)
    if not 0.1 <= coverage <= 0.95:
        raise ValueError("coverage 必须在 0.1..0.95")
    if int(width) <= 0 or int(height) <= 0:
        raise ValueError("width/height 必须为正整数")

    target, resolution_note = _resolve_render_sop(node)
    f = float(hou.frame()) if frame is None else float(frame)
    framing_f = f if framing_frame is None else float(framing_frame)
    if not math.isfinite(f) or not math.isfinite(framing_f):
        raise ValueError('frame/framing_frame must be finite')
    direction_label = direction if isinstance(direction, str) else 'view'
    picture, artifact, _artifact_hip_path = _preview_artifact(
        picture,
        frame=f,
        purpose='model_visual_verification',
        output_policy=output_policy,
        default_label=f'{target.name()}_{direction_label}',
        default_subdir=_project_directory('visual_check'),
    )
    try:
        image_ext = os.path.splitext(picture)[1].lower()
        if image_ext not in ('.png','.jpg','.jpeg','.bmp','.tga','.tif','.tiff','.exr','.hdr','.pic','.rat'):
            raise ValueError(f'unsupported render_view image extension: {image_ext}; use PNG or EXR')
        before = _geometry_fingerprint(target, f)
        if before["errors"]:
            raise ValueError(f"目标 {target.path()} cook error：{before['errors']}")
        obj_visibility = _snapshot_obj_visibility()
        selection = _snapshot_selection()
    except BaseException as error:
        reservation_errors = _release_preview_reservation(artifact)
        if reservation_errors:
            raise RuntimeError(str(error) + '; ' + '; '.join(reservation_errors)) from error
        raise
    proxy = proxy_out = cam = aim = rop = None
    result_payload = None
    failure_payload = None
    pending_error = None
    try:
        proxy, proxy_out = _ensure_render_proxy(target)
        focus_bounds = None
        if focus_group is not None:
            from dsh_geometry_observation import selected_prims
            focus_geometry = proxy_out.geometryAtFrame(framing_f)
            focus_prims = selected_prims(focus_geometry, focus_group)
            focus_bounds = focus_prims[0].boundingBox()
            for prim in focus_prims[1:]: focus_bounds.enlargeToContain(prim.boundingBox())
            # Check the rendered frame too; never silently fall back to an empty group.
            selected_prims(proxy_out.geometryAtFrame(f), focus_group)
            if isolate:
                focus_node = _owned_node(proxy, 'focus', 'blast')
                focus_node.setInput(0, proxy.node('source'))
                focus_node.parm('grouptype').set('prims')
                focus_node.parm('group').set(focus_group)
                focus_node.parm('negate').set(1)
                proxy_out.setInput(0, focus_node)
                proxy_out.cook(force=True)
        proxy_before = _geometry_fingerprint(proxy_out, f)
        if proxy_before["errors"]:
            raise ValueError(
                f"agent render proxy 无法读取 {target.path()}：{proxy_before['errors']}"
            )
        framing_fingerprint = _geometry_fingerprint(target, framing_f)
        if framing_fingerprint["errors"]:
            raise ValueError(
                f"目标 {target.path()} 在 framing_frame={framing_f} cook error："
                f"{framing_fingerprint['errors']}"
            )
        framing_geometry = proxy_out.geometryAtFrame(framing_f)
        if framing_geometry is None or len(framing_geometry.points()) == 0:
            raise ValueError(
                f"目标 {target.path()} 在 framing_frame={framing_f} 没有可取景几何"
            )
        bb = focus_bounds if focus_bounds is not None else framing_geometry.boundingBox()
        if framing_bounds is not None:
            if not isinstance(framing_bounds,(list,tuple)) or len(framing_bounds)!=2 or any(not isinstance(v,(list,tuple)) or len(v)!=3 for v in framing_bounds):
                raise ValueError('framing_bounds must be [min_xyz,max_xyz] in render-proxy world space')
            low,high = [[float(x) for x in v] for v in framing_bounds]
            if not all(math.isfinite(x) for v in (low,high) for x in v) or any(a>b for a,b in zip(low,high)) or low==high:
                raise ValueError('framing_bounds must be finite ordered nonzero bounds')
            bb = hou.BoundingBox(*(low+high))
        reference_depth_bounds = depth_bounds if depth_bounds is not None else framing_bounds
        depth_source = 'explicit' if depth_bounds is not None else 'framing_bounds' if framing_bounds is not None else 'framing_frame_output'
        if reference_depth_bounds is None:
            depth_bb = framing_geometry.boundingBox()
            reference_depth_bounds = [list(depth_bb.minvec()), list(depth_bb.maxvec())]
        center = bb.center()
        extents = bb.sizevec()
        size = max(float(extents[0]), float(extents[1]), float(extents[2]))

        obj = hou.node("/obj")
        out = hou.node("/out")
        cam = _owned_node(obj, _RENDER_CAMERA_NAME, "cam")
        cam.parm('projection').set('ortho' if projection == 'orthographic' else 'perspective')
        aim = _owned_node(obj, _RENDER_TARGET_NAME, "null")
        # Both supported versions provide Flipbook, but H21.0.440 Work Lights
        # ignore geometry Alpha; its original OpenGL path still composites it.
        # Keep the tested renderer boundary until the supported H21 build also
        # passes the real transparency contract, not only the shared node schema.
        use_flipbook = hou.applicationVersion()[0] >= 22
        rop = _owned_node(out, _RENDER_FLIPBOOK_NAME if use_flipbook else _RENDER_ROP_NAME,
                          "flipbook" if use_flipbook else "opengl")
        obj_service_box = _render_service_box(
            obj, _RENDER_OBJ_BOX_NAME, [proxy, cam, aim])
        out_service_box = _render_service_box(
            out, _RENDER_OUT_BOX_NAME, [rop])
        for infra in (cam, aim, proxy):
            try:
                infra.setDisplayFlag(False)
            except Exception:
                pass
        # 创建 agent 节点可能改变 OBJ flags；渲染前立即还原用户现场。
        _restore_obj_visibility(obj_visibility)
        aim.parmTuple("t").set([float(center[0]), float(center[1]), float(center[2])])

        from dsh_camera_framing import corners, preview_plan, preview_check, obj_lens
        if isinstance(direction, str):
            named = _NAMED_DIRECTIONS.get(direction.strip().lower())
            if named is None:
                raise ValueError(
                    f"direction 收到未知名称 {direction!r}；可用："
                    f"{sorted(_NAMED_DIRECTIONS)} 或三分量向量 [x, y, z]"
                )
            direction = named
        # Service state must not inherit a prior shot's lens/window settings.
        for name, value in {'focal':50.0, 'aperture':41.4214, 'aspect':1.0,
                            'winx':0, 'winy':0, 'winsizex':1, 'winsizey':1,
                            'cropl':0, 'cropr':1, 'cropb':0, 'cropt':1, 'constraints_on':0,
                            'lookatpath':'', 'resx':int(width), 'resy':int(height),
                            'vm_lensshader':''}.items():
            parm = cam.parm(name)
            if parm is not None:
                _clear_animation(parm)
                parm.set(value, follow_parm_reference=False)
        plan = preview_plan([list(bb.minvec()), list(bb.maxvec())], reference_depth_bounds,
                            direction, width, height, coverage=coverage, projection=projection, framing=framing)
        dist = plan['dist']
        d = hou.Vector3(plan['direction'])
        eye = center + d*dist
        matrix = plan['matrix']
        matrix.setAt(3, 0, eye[0]); matrix.setAt(3, 1, eye[1]); matrix.setAt(3, 2, eye[2])
        cam.setWorldTransform(matrix)
        cam.parm('near').set(plan['near'])
        cam.parm('far').set(plan['far'])
        cam.parm('focal').set(plan['focal'])
        if projection == 'orthographic':
            cam.parm('orthowidth').set(plan['orthowidth'])
        # Check the rendered state, not only framing_frame/explicit bounds. A
        # stale A/B envelope must fail, never move the supposedly locked camera.
        current_geo = proxy_out.geometryAtFrame(f)
        current_bb = current_geo.boundingBox()
        rendered_points = corners([list(current_bb.minvec()), list(current_bb.maxvec())])
        if focus_group is not None:
            current_prims = selected_prims(current_geo, focus_group)
            current_bb = current_prims[0].boundingBox()
            for prim in current_prims[1:]: current_bb.enlargeToContain(prim.boundingBox())
        framing_check = preview_check(corners([list(current_bb.minvec()), list(current_bb.maxvec())]),
            rendered_points, cam.worldTransform(), width, height, framing=framing, coverage=coverage, **obj_lens(cam))
        if not framing_check['ok']:
            action = ('Depth clipping is never an intentional crop. Supply shared depth_bounds covering all rendered context, '
                      'or isolate an explicit focus_group; no automatic camera drift.' if not framing_check['depth_check']['ok'] else
                      'full framing_bounds must cover the whole focus, not a local ROI. For a close-up use focus_group or '
                      'framing="detail"; for A/B provide fixed framing_bounds AND depth_bounds covering the test states.')
            if framing == 'full' and 'outside_safe_frame' in framing_check['reasons'] and not framing_check['depth_check']['ok']:
                action += ' full also requires complete focus framing: local ROI needs focus_group or framing="detail", not repeated envelope guesses.'
            raise CheckpointError('render_view framing failed before render. ' + action,
                                  {**framing_check, 'render_started': False, 'target': target.path(), 'next_action': action})

        output_color = _render_output_color_plan(picture)

        # OpenGL ROP 完全拥有自己的对象/灯光/颜色设置，不消费用户 display/light。
        # 颜色设置由目标文件类型决定：展示格式写 display-encoded sRGB，
        # EXR/HDR 保持 scene-linear。不能把 linear RGB 原样量化进 PNG。
        settings = {
            "camera": cam.path(),
            "vobjects": proxy.path(),
            "forceobjects": proxy.path(),
            "excludeobjects": f"{cam.path()} {aim.path()}",
            "alights": "",
            "forcelights": "",
            "excludelights": "*",
            "shadingmode": "smooth",
            "usegeocolor": True,
            "tres": True,
            "override_camerares": True,
            "res1": int(width),
            "res2": int(height),
            **output_color["settings"],
        }
        if use_flipbook:
            # Flipbook has explicit work lighting and no legacy gamma knob.
            # Do not inherit Scene Lights (its default) or the user's viewport.
            if output_color['method'] == 'gamma_fallback':
                raise RuntimeError('H22 Flipbook requires an available encoded sRGB OCIO colorspace; no legacy gamma fallback')
            settings.pop('gamma', None)
            settings.pop('lut', None)
            settings.pop('override_camerares', None)
            settings.update(opsource='obj', scenepath='/obj', sopsource='render',
                            lighting='headlight', worklighttype='headlight',
                            headlightint=1.0, headlightrotate1=22.0, headlightrotate2=22.0,
                            useraytrace=False, motionblur=False, dof=False, bloom=False,
                            uniformfog=False, volumefog=False, onionskin=False, slapcomp=False,
                            ociolooks='', bgimage='', aspect=1.0)
        applied = {name: _try_set(rop, name, value) for name, value in settings.items()}
        if use_flipbook:
            missing = [name for name, ok in applied.items() if not ok]
            if missing:
                raise RuntimeError(f'Flipbook preview settings unavailable: {missing}')

        color_required = ["colorcorrect"] if use_flipbook else ["colorcorrect", "gamma"]
        if output_color["method"] == "ocio_colorspace":
            color_required.append("ociocolorspace")
        missing_color_settings = [name for name in color_required if not applied.get(name)]
        if missing_color_settings:
            raise RuntimeError(
                "OpenGL ROP 无法应用输出颜色管理参数："
                f"{missing_color_settings}；拒绝生成颜色空间不明的 {picture}"
            )
        output_color = {
            key: value for key, value in output_color.items() if key != "settings"
        }
        try:
            output_color["ocio_config"] = hou.Color.ocio_configPath()
        except Exception:
            output_color["ocio_config"] = None
        output_color["applied"] = {
            "colorcorrect": rop.parm("colorcorrect").rawValue(),
            "gamma": None if use_flipbook else float(rop.parm("gamma").eval()),
            "ocio_colorspace": rop.parm("ociocolorspace").eval(),
        }

        rendered = render_frame(rop, picture=picture, frame=f)
        check = None
        if rendered.get("file_bytes"):
            try:
                check = render_check(rendered["output"])
            except Exception as error:
                check = {"error": str(error)}
        after = _geometry_fingerprint(target, f)
        proxy_after = _geometry_fingerprint(proxy_out, f)
        stale = before["signature"] != after["signature"]
        proxy_stale = proxy_before["signature"] != proxy_after["signature"]
        render_warnings = list(dict.fromkeys(before["warnings"] + proxy_before["warnings"]))
        validation = _render_validation(
            rendered,
            check,
            stale or proxy_stale,
            pixel_supported=image_ext not in ('.exr','.hdr','.pic','.rat'),
            warnings=render_warnings,
        )
        result_payload = {
            **validation,
            "artifact": artifact,
            "preview_backend": "flipbook_vulkan" if use_flipbook else "opengl_legacy",
            "output": rendered["output"],
            "frame": f,
            "stale": stale or proxy_stale,
            "target": target.path(),
            "resolved_from": _resolve(node).path(),
            "proxy": proxy.path(),
            "proxy_output": proxy_out.path(),
            "camera": cam.path(),
            "rop": rop.path(),
            "render_service": {
                "persistent": True,
                "delete_during_session": False,
                "obj_network_box": obj_service_box.name(),
                "out_network_box": out_service_box.name(),
            },
            "output": rendered["output"],
            "frame": f,
            "file_bytes": rendered["file_bytes"],
            "errors": validation['errors'],
            "warnings": render_warnings,
            "stale": stale or proxy_stale,
            "source_fingerprint_before": before,
            "source_fingerprint_after": after,
            "proxy_signature_before": proxy_before["signature"],
            "proxy_signature_after": proxy_after["signature"],
            "framing": {
                **framing_check,
                "focus_group": focus_group, "isolated": isolate, "projection": projection,
                "bounds": [[float(x) for x in bb.minvec()],[float(x) for x in bb.maxvec()]],
                "bounds_source": 'explicit' if framing_bounds is not None else 'focus_group' if focus_group else 'output',
                "depth_bounds": plan['depth_bounds'], "depth_bounds_source": depth_source,
                "coordinate_space": 'render proxy world space',
                "mode": framing,
                "frame": framing_f,
                "coverage": coverage,
                "center": [float(x) for x in center],
                "size": float(size),
                "dist": round(float(dist), 6),
                "eye": [float(x) for x in eye],
                "direction": [float(x) for x in d],
                "source_signature": framing_fingerprint["signature"],
            },
            "rop_settings_applied": applied,
            "output_color": output_color,
            "check": check,
            "pixels": check,
        }
        if resolution_note:
            result_payload["note"] = resolution_note
        if result_payload["stale"]:
            result_payload["stale_reason"] = (
                "target/proxy geometry changed during visual verification；"
                "不要据此宣称成功，请重新检查并渲染"
            )
        return result_payload
    except BaseException as error:
        pending_error = error
        if isinstance(error, CheckpointError):
            failure_payload = error.evidence
        raise
    finally:
        restore_errors = _release_preview_reservation(artifact)
        restore_errors.extend(_restore_obj_visibility(obj_visibility))
        restore_errors.extend(_restore_selection(selection))
        # _ensure_render_proxy may fail after binding its source but before it
        # returns. The service is intentionally non-undoable, so idle that
        # owned partial proxy here instead of relying on Bridge rollback.
        if proxy is None:
            partial = hou.node('/obj/' + _RENDER_PROXY_NAME)
            if (partial is not None and partial.userData(_RENDER_OWNER_KEY) == _RENDER_OWNER_VALUE
                    and partial.userData('dsh_render_state') == 'active'):
                proxy = partial
        if proxy is not None:
            try:
                proxy.setDisplayFlag(False)
            except Exception as error:
                restore_errors.append(f"{proxy.path()}: {error}")
            # 空闲 proxy 不长期引用用户节点；下一次 render_view 会重新绑定显式 SOP。
            try:
                source = proxy.node("source")
                if (source is not None and source.userData(_RENDER_OWNER_KEY) == _RENDER_OWNER_VALUE
                        and source.parm("objpath1") is not None):
                    source.parm("objpath1").set("")
                    last_target = target.path()
                    last_frame = result_payload.get("frame") if result_payload else f
                    last_output = result_payload.get("output") if result_payload else None
                    proxy.setUserData("dsh_render_state", "idle")
                    proxy.setUserData("dsh_last_target", last_target)
                    proxy.setUserData("dsh_last_frame", str(last_frame))
                    if last_output:
                        proxy.setUserData("dsh_last_output", str(last_output))
                    source.setComment(
                        "Temporary render_view source; objpath1 is bound only while rendering "
                        "and cleared afterward.\n"
                        f"Last target: {last_target}\nLast frame: {last_frame}"
                    )
            except Exception as error:
                restore_errors.append(f"{proxy.path()}/source: {error}")
        if failure_payload is not None:
            failure_payload['user_state_restored'] = not restore_errors
            if restore_errors:
                failure_payload['restore_errors'] = restore_errors
        elif pending_error is not None and restore_errors:
            raise CheckpointError('render_view failed and user state restoration failed',
                                  {'ok':False,'user_state_restored':False,'restore_errors':restore_errors,
                                   'original_error':str(pending_error)[:400]}) from pending_error
        if result_payload is not None:
            result_payload["user_state_restored"] = not restore_errors
            if restore_errors:
                result_payload["restore_errors"] = restore_errors
                result_payload['ok'] = False
                result_payload['errors'].extend(f'user state restore failed: {e}' for e in restore_errors)
