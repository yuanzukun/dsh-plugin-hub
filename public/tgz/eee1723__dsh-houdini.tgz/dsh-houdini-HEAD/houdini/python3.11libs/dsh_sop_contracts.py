"""Small SOP construction/checkpoint contracts. No host, network or UI services.

Only called by the main-thread verb layer. Helpers are imported lazily to keep
the original primitive API independent of this higher-level composition layer.
"""
from __future__ import annotations

import re
import time
import math
import hashlib
import struct
import hou


def geo_point_spacing(node, expected: float, tolerance: float, closed: bool = False,
                      order_attrib=None, max_points: int = 10000) -> dict:
    """Check EVERY adjacent point in one explicitly ordered sequence, local space.

    This measures Euclidean chord distances, not arc length, mesh connectivity,
    surface clearance or physical link assembly. Point-number order is the
    default and reported; a scalar unique numeric order attribute may override.
    Reject oversize inputs instead of silently sampling and missing an interior
    defect. Failed constraints return measured evidence (diagnostic read).
    """
    import dsh_hou_helpers as h
    n = h._resolve(node)
    expected, tolerance = float(expected), float(tolerance)
    if not math.isfinite(expected) or expected <= 0 or not math.isfinite(tolerance) or tolerance < 0:
        raise ValueError('expected must be positive/finite; tolerance nonnegative/finite (SOP local units)')
    if not isinstance(closed, bool) or type(max_points) is not int or not 2 <= max_points <= 100000:
        raise ValueError('closed must be bool; max_points integer in 2..100000')
    from dsh_cook_control import require_evaluation
    require_evaluation('geo_point_spacing')
    g = n.geometry() if n.type().category() == hou.sopNodeTypeCategory() else None
    if g is None or n.errors():
        raise ValueError('geo_point_spacing requires an error-free SOP geometry output')
    count = int(g.intrinsicValue('pointcount'))
    if not 2 <= count <= max_points or (closed and count < 3):
        raise ValueError(f'point count={count}, requires 2..{max_points} (closed >=3); split oversized sequences, no sampling')
    points = list(g.points())
    if order_attrib is not None:
        if not isinstance(order_attrib, str):
            raise ValueError('order_attrib must be a scalar unique numeric point attribute name')
        attrib = g.findPointAttrib(order_attrib)
        if attrib is None or attrib.size() != 1 or attrib.dataType() not in (hou.attribData.Int, hou.attribData.Float):
            raise ValueError('order_attrib must be a scalar unique numeric point attribute')
        keys = [p.attribValue(attrib) for p in points]
        if len(set(keys)) != count or not all(math.isfinite(float(k)) for k in keys):
            raise ValueError('order_attrib has duplicate or nonfinite values')
        points = [p for _, p in sorted(zip(keys, points), key=lambda pair: pair[0])]
    positions = [p.position() for p in points]
    if not all(math.isfinite(float(v)) for pos in positions for v in pos):
        raise ValueError('sequence contains nonfinite positions')
    pairs = [(i, (i + 1) % count) for i in range(count if closed else count - 1)]
    distances = [(positions[j] - positions[i]).length() for i, j in pairs]
    failed = [{'from_point': points[i].number(), 'to_point': points[j].number(),
               'distance': d, 'error': abs(d - expected)}
              for (i, j), d in zip(pairs, distances) if abs(d - expected) > tolerance]
    digest = hashlib.sha256()
    for p, pos in zip(points, positions):
        digest.update(struct.pack('<q3d', p.number(), *pos))
    return {'ok': not failed, 'status': 'pass' if not failed else 'fail', 'node': n.path(),
            'frame': float(hou.frame()), 'checked_at': time.time(), 'expected': expected,
            'tolerance': tolerance, 'closed': closed, 'order': order_attrib or 'point_number',
            'coordinate_space': 'SOP local', 'point_count': count, 'pair_count': len(pairs),
            'coverage': 'all_adjacent_pairs', 'min_distance': min(distances), 'max_distance': max(distances),
            'mean_distance': sum(distances) / len(distances), 'failure_count': len(failed),
            'failures': sorted(failed, key=lambda f: f['error'], reverse=True)[:16],
            'failures_truncated': len(failed) > 16, 'sequence_sha256': digest.hexdigest(),
            'semantic_status': 'unverified',
            'note': 'Only the specified point sequence/chord spacing is checked; not curve arc length or final surface/assembly correctness.'}


def _output_ports(parent):
    return [n for n in parent.children() if n.type().name() == 'output']


def _output_index(index):
    if type(index) is not int or not 0 <= index <= 63:
        raise ValueError('output_index must be an integer in 0..63, or None for display-only')


def _public_output(parent, source, index):
    _output_index(index)
    ports = [n for n in _output_ports(parent) if n.evalParm('outputidx') == index]
    port = ports[0] if len(ports) == 1 else None
    valid = port is not None and (port == source or any(
        c.inputIndex() == 0 and c.inputNode() == source and c.outputIndex() == 0
        for c in port.inputConnections()))
    return {'ok': valid, 'index': index, 'node': port.path() if port else None,
            'source': source.path(), 'matches': [n.path() for n in ports],
            'reason': None if valid else 'missing_duplicate_or_unwired_public_output',
            'scope': 'direct Output wiring only; not ancestor visibility or fresh-instance behavior'}


def publish_output(source, index, allow_foreign=None):
    """Explicit port authoring, no cooking or automatic ancestor publication."""
    import dsh_hou_helpers as h
    _output_index(index)
    parent = source.parent()
    ports = [n for n in _output_ports(parent) if n.evalParm('outputidx') == index]
    if len(ports) > 1:
        raise ValueError(f'duplicate Output index {index}; inspect and resolve explicitly')
    port = ports[0] if ports else None
    if source.type().name() == 'output':
        if port != source:
            raise ValueError('source is an Output with a different index; edit the port explicitly')
    else:
        if port is not None and port in source.inputAncestors():
            raise ValueError('publishing this source would create an Output dependency cycle')
        # An owned child does not authorize replacing a foreign public interface.
        h._require_owned(parent, 'publish SOP output', allow_foreign)
        if port is not None:
            h._require_owned(port, 'publish SOP output', allow_foreign)
        else:
            port = h.tab_create(parent, 'output', name=f'output{index}')
            h.set_parms(port, {'outputidx': index})
        h.connect(source, port, allow_foreign=allow_foreign)
    result = _public_output(parent, source, index)
    if not result['ok']:
        raise ValueError('public Output wiring readback failed')
    return result


def _content_nonempty(geometry, max_prims=100000, max_depth=16):
    """Existence witness inside embedded packs, not membership or shape proof.

    Point-only data is valid; wrapper points do not prove embedded content.
    Bound traversal and never load external packed files to obtain a witness.
    """
    pending = [(geometry, 0)]
    checked = 0
    unknown = False
    while pending:
        geo, depth = pending.pop()
        if geo is None:
            unknown = True
            continue
        count = int(geo.intrinsicValue('primitivecount'))
        points = int(geo.intrinsicValue('pointcount'))
        if not count:
            if points:
                return {'nonempty': True, 'status': 'observed_content'}
            continue
        # One concrete non-packed primitive is an existence witness, not a
        # sample-based claim about the remaining geometry. Large meshes stay cheap.
        if 'Packed' not in str(geo.prim(0).type()):
            return {'nonempty': True, 'status': 'observed_content'}
        if depth > max_depth or checked + count > max_prims:
            unknown = True
            continue
        checked += count
        wrapper_points = set()
        for prim in geo.prims():
            if 'Packed' not in str(prim.type()):
                return {'nonempty': True, 'status': 'observed_content'}
            wrapper_points.update(v.point().number() for v in prim.vertices())
            if isinstance(prim, hou.PackedGeometry):
                pending.append((prim.getEmbeddedGeometry(), depth + 1))
            else:
                unknown = True
        if points > len(wrapper_points):
            return {'nonempty': True, 'status': 'observed_content'}
    return {'nonempty': None if unknown else False,
            'status': 'unverified_content' if unknown else 'empty_content'}


def _vex_source_context(report):
    """Best-effort compiler location against an existing Wrangle snippet."""
    error_text='\n'.join(str(error) for error in report.get('errors',[]))
    location=re.search(r'\((\d+),\s*(\d+)(?::\d+)?\)',error_text)
    if not location:return None
    source=re.search(r'Invalid source\s+(\S+)',error_text)
    node=hou.node(source.group(1).rstrip('.')) if source else hou.node(report['path'])
    for _ in range(4):
        if node is None:break
        parm=node.parm('snippet')
        if parm is not None:
            try:lines=parm.unexpandedString().splitlines()
            except Exception:return None
            line=int(location.group(1));column=int(location.group(2))
            if not 1<=line<=len(lines):
                return {'source_node':node.path(),'compiler_line':line,'column':column,
                        'snippet_line_count':len(lines),'status':'compiler_line_not_mapped_to_snippet'}
            return {'source_node':node.path(),'compiler_line':line,'column':column,
                    'snippet_context':[{'line':index,'text':lines[index-1][:240]}
                                       for index in range(max(1,line-2),min(len(lines),line+2)+1)],
                    'status':'candidate_snippet_context',
                    'scope':'Compiler line may refer to generated VEX; verify this mapping against the source before editing.'}
        node=node.parent()
    return None


def verify_network(parent, output=None, nodes=None, limit: int = 512, require_valid: bool = True,
                   *, output_index: int | None = None) -> dict:
    """Cook/check SOP children, not just OUT. No display/frame/selection changes.

    Default scope is all direct SOP children (not HDA internals). Explicit nodes
    restrict the scope; the report lists it. A limit overrun fails, never samples
    and reports healthy. Warnings, empty output and semantic verification differ.
    output_index checks the parent public Output is this source (or directly
    wired to it); omission remains an internal construction checkpoint.
    Surface/path review is explicit through geometry queries; output names never
    select extra domain checks.
    """
    import dsh_hou_helpers as h
    p = h._resolve(parent)
    if p.childTypeCategory() != hou.sopNodeTypeCategory():
        raise ValueError("verify_network currently accepts a SOP network parent only")
    if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
        raise ValueError("limit must be a positive integer")
    if not isinstance(require_valid, bool):
        raise ValueError('require_valid must be bool')
    if output is None:
        candidates = [n.path() for n in p.children() if n.name().upper().startswith('OUT')][:12]
        raise ValueError(f'explicit output required; no display-node fallback. Call verify_network(parent, output=<deliverable SOP>); candidates={candidates}')
    if nodes is not None and not isinstance(nodes, (list, tuple)):
        raise ValueError('nodes must be a list of explicit SOP nodes/paths')
    selected = list(p.children()) if nodes is None else [h._resolve_in_parent(p, n) for n in nodes]
    out = h._resolve_in_parent(p, output)
    if out is None or out.parent() != p:
        raise ValueError("output must be an explicit direct SOP child")
    handoff_output = {
        'path': out.path(),
        'name': out.name(),
        'type': out.type().name(),
        'is_null': out.type().name() == 'null',
        'has_stable_name': bool(re.fullmatch(r'OUT(?:_[A-Za-z0-9]+)*', out.name(), re.IGNORECASE)),
        'is_leaf': not bool(out.outputs()),
        'display_flag': bool(out.isDisplayFlagSet()),
        'render_flag': bool(out.isRenderFlagSet()),
        'active_display_output': p.displayNode().path() if p.displayNode() else None,
        'active_render_output': p.renderNode().path() if p.renderNode() else None,
        'status': ('stable_null_checkpoint'
                   if out.type().name() == 'null' and re.fullmatch(r'OUT(?:_[A-Za-z0-9]+)*', out.name(), re.IGNORECASE)
                   else 'implementation_output'),
        'scope': ('SOP publication/readability facts only; OBJ visibility and viewport framing are separate. A named Null is not a public subnet port, geometry proof, '
                  'relationship proof or requirement to wrap every simple chain.'),
    }
    public = _public_output(p, out, output_index) if output_index is not None else None
    if public is not None and public['node']:
        selected.append(h._resolve(public['node']))
    if out not in selected:
        selected.append(out)
    selected = list(dict.fromkeys(selected))
    if len(selected) > limit:
        raise ValueError(f"verification scope has {len(selected)} nodes, exceeding limit={limit}; select a module")
    if any(n.parent() != p or n.type().category() != hou.sopNodeTypeCategory() for n in selected):
        raise ValueError("all nodes must be direct SOP children of parent")
    if hou.updateModeSetting() == hou.updateMode.Manual:
        result = {'ok':False, 'healthy':False, 'warning_free':None, 'parent':p.path(),
                  'output':out.path(), 'status':'not_evaluated_manual', 'update_mode':'manual',
                  'failure_reasons':['not_evaluated_manual'], 'geometry':None, 'nonempty':None,
                  'output_fingerprint':None, 'semantic_status':'unverified',
                  'public_output':public, 'handoff_output':handoff_output,
                  'content_check':{'nonempty':None,'status':'not_evaluated'},
                  'frame':float(hou.frame()), 'checked_at':time.time(),
                  'scope':'direct_children' if nodes is None else 'explicit_nodes',
                  'scope_signature':hashlib.sha256('\n'.join(sorted(n.path() for n in selected)).encode()).hexdigest(),
                  'requested_nodes':[n.path() for n in selected], 'checked_nodes':[], 'node_count':0,
                  'error_nodes':[], 'error_nodes_count':0, 'warning_nodes':[], 'warning_nodes_count':0, 'issues':[],
                  'next_action':'Manual mode: metadata inspection/editing remains available. Use set_update_mode before geometry evaluation; geometry is unknown, not empty.'}
        if require_valid:
            raise h.CheckpointError(result['next_action'], result)
        return result
    # This internal read-only batch authors no source or wiring changes. Scan
    # its complete dependency union once, before the first cook; do not retain
    # validation across calls or use an upstream-size cap as a danger signal.
    from dsh_cook_control import preflight
    preflight(selected)
    reports = [h._cook_node(n, preflight=False) for n in selected]
    errors = [r['path'] for r in reports if not r['ok']]
    warnings = [r['path'] for r in reports if not r['warning_free']]
    output_cooked = next(r['ok'] for r in reports if r['path'] == out.path())
    # Never turn a failed/interrupted explicit cook into an unbounded implicit
    # retry through geometry()/geometryAtFrame(), or certify its stale cache.
    geometry = out.geometry() if output_cooked else None
    summary = h._geo_summary(geometry) if geometry is not None else None
    content = _content_nonempty(geometry) if geometry is not None else {'nonempty':None, 'status':'not_evaluated'}
    nonempty = content['nonempty']
    fingerprint = h._geometry_fingerprint(out, hou.frame()) if nonempty and not out.errors() else None
    reasons = (['cook_error'] if errors else []) + (['empty_output'] if output_cooked and not nonempty else [])
    if output_cooked and nonempty is None:
        reasons = [r for r in reasons if r != 'empty_output'] + ['unverified_output_content']
    if public is not None and not public['ok']:
        reasons.append('public_output')
    result = {'ok': not reasons, 'output': out.path(), 'failure_reasons': reasons,
            'parent': p.path(), 'frame': float(hou.frame()),
            'checked_at': time.time(), 'scope': 'direct_children' if nodes is None else 'explicit_nodes',
            'scope_signature': hashlib.sha256('\n'.join(sorted(n.path() for n in selected)).encode()).hexdigest(),
            'checked_nodes': [n.path() for n in selected], 'node_count': len(selected),
            'warning_free': not warnings,
            'healthy': not reasons and not warnings and nonempty is True, 'nonempty': nonempty,
            'content_check': content, 'public_output': public, 'handoff_output': handoff_output,
            'error_nodes': errors, 'error_nodes_count': len(errors),
            'warning_nodes': warnings, 'warning_nodes_count': len(warnings),
            'issues': [r for r in reports if not r['healthy']], 'geometry': summary,
            'scene_unit_length_meters':None,
            'geometry_status':'evaluated' if output_cooked else 'not_evaluated_cook_failed',
            'output_fingerprint': fingerprint, 'semantic_status': 'unverified',
            'next_action': ('Inspect error_nodes and cook_details for the requested output.' if reasons else
                            'Inspect warning_nodes for the reported diagnostics.' if warnings else
                            'Requested output cooked successfully and contains geometry.'),
            'note': 'Cook/geometry evidence only; no assertion of relationships, art quality or unsampled HDA internals.'}
    # Unit facts depend on the HIP, never on an author's choice of output name.
    # These remain SOP-local measurements, not an assembly or dimension pass.
    from dsh_context import unit_length_meters
    result['scene_unit_length_meters'] = unit_length_meters()
    size = (summary or {}).get('bbox_size')
    unit = result['scene_unit_length_meters']
    result['bbox_size_sop_local_mm'] = (
        [round(float(span) * unit * 1000, 6) for span in size]
        if unit is not None and isinstance(size, (list, tuple)) and len(size) == 3
        else None
    )
    if errors:
        result['cook_details']=[{'path':r['path'],'errors':r['errors'],
                                 'source_context':_vex_source_context(r)} for r in reports if not r['ok']][:3]
    if reasons and require_valid:
        details=result.get('cook_details',[])
        raise h.CheckpointError(f'verify_network failed: {reasons}; output={out.path()}; errors={errors}; cook_details={str(details)[:3000]}. {result["next_action"]}', result)
    return result


def _prepare_module(parent, nodes, output, dry_run, interfaces, required_outputs):
    """Read-only validation boundary: no creation, parameter edits or flag changes."""
    import dsh_hou_helpers as h
    if interfaces is not None:
        from dsh_quality_contracts import validate_interfaces
        validate_interfaces(interfaces)
    p = h._resolve(parent)
    if p.childTypeCategory() != hou.sopNodeTypeCategory():
        raise ValueError('build_module only creates SOP modules; use primitive verbs for other contexts')
    if not isinstance(dry_run, bool):
        raise ValueError('dry_run must be bool')
    if not isinstance(nodes, list) or not nodes:
        raise ValueError('nodes must contain at least one SOP node spec')
    existing = {n.name(): n for n in p.children()}
    specs, names, preflight_errors = [], set(), []
    def problem(name, field, message, **details):
        preflight_errors.append({'node': name, 'field': field, 'message': message, **details})
    for spec in nodes:
        if not isinstance(spec, dict) or set(spec) - {'name', 'type', 'parms', 'inputs'}:
            raise ValueError('node spec supports only name/type/parms/inputs')
        name, typ = spec.get('name'), spec.get('type')
        if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', name):
            raise ValueError('each new node needs a simple explicit name')
        if name in existing or name in names:
            raise ValueError(f'node exists or duplicate name: {name}')
        names.add(name)
    known = set(existing) | names
    category = p.childTypeCategory()
    for spec in nodes:
        name, typ = spec['name'], spec.get('type')
        if not isinstance(typ, str) or not typ:
            raise ValueError(f'{name}: missing type')
        latest = h.resolve_latest_type(category, typ)
        typ_obj = hou.nodeType(category, latest)
        if typ_obj is None:
            raise ValueError(f'{name}: 未知节点类型 {typ!r}; parent={p.path()}')
        if not h._visible_node_type(typ_obj):
            raise ValueError(f'{name}: hidden/deprecated type {typ}; use search_tab_entries')
        values, inputs = spec.get('parms', {}), spec.get('inputs', [])
        if not isinstance(values, dict) or not isinstance(inputs, list):
            raise ValueError(f'{name}: parms must be dict and inputs must be list')
        # Actual numbered multiparm names must be validated against the declared
        # count (or the static default), not the uninstantiated '#' template.
        parameters = h._node_parameter_cards(typ_obj, values)
        allowed = {c['name'] for c in parameters}
        allowed.update(k for c in parameters for k in c.get('components', []))
        unknown = set(values) - allowed
        if unknown:
            import difflib
            for field in sorted(unknown):
                similar = difflib.get_close_matches(field, sorted(allowed), n=5, cutoff=0.25)
                problem(name, field, f'unknown parameter(s) {field!r} on resolved type {latest!r}; candidates={similar}; use node_info with the same parent/type and a literal filter', candidates=similar, resolved_type=latest)
        for parameter in parameters:
            if parameter.get('type') in ('Float', 'Int') and not parameter.get('menu') and not parameter.get('menu_dynamic'):
                components = parameter.get('components', [])
                fields = ([parameter['name']] if parameter['name'] in values else [])
                fields += [c for c in components if c != parameter['name'] and c in values]
                for field in fields:
                    try:
                        h._validate_numeric_parameter_value(values[field], components if field == parameter['name'] else (),
                                                            size=parameter['size'] if field == parameter['name'] else 1)
                    except (ValueError, OverflowError) as error:
                        problem(name, field, str(error), components=components)
            if parameter['name'] in values and parameter.get('menu') and parameter.get('type') in ('Menu','Int') and not parameter.get('menu_dynamic'):
                value = values[parameter['name']]
                tokens = [item['token'] for item in parameter['menu']]
                if not isinstance(value, dict):
                    try: h._menu_setting(parameter['menu'], value)
                    except ValueError as error: problem(name, parameter['name'], str(error), tokens=tokens)
        if len(inputs) > typ_obj.maxNumInputs():
            problem(name, 'inputs', f'too many input slots ({len(inputs)} > {typ_obj.maxNumInputs()})')
        for source in inputs:
            if source is None:
                continue  # explicit empty input; e.g. Wrangle lookup on input 1
            if not isinstance(source, str) or source not in known:
                problem(name, 'inputs', f'input {source!r} must name a declared spec or existing direct child')
        count_names = [c['name'] for c in parameters if c.get('multiparm_count') and c['name'] in values]
        ordered_values = {k:values[k] for k in count_names}
        ordered_values.update(values)
        specs.append({**spec, 'type': latest, 'parms': ordered_values, 'inputs': inputs, '_counts':count_names})
    if output not in {s['name'] for s in specs}:
        raise ValueError('output must name one of the newly created nodes')
    if required_outputs is not None:
        if not isinstance(required_outputs, list) or not required_outputs or any(not isinstance(n,str) for n in required_outputs) or len(set(required_outputs)) != len(required_outputs):
            raise ValueError('required_outputs must contain unique new node names')
        if any(n not in {s['name'] for s in specs} for n in required_outputs):
            raise ValueError('required_outputs must name newly declared module nodes')
    if preflight_errors:
        raise h.PreflightError(preflight_errors)
    return p, existing, specs


def build_module(parent, nodes: list, output: str, dry_run: bool = False, interfaces=None, *, required_outputs=None) -> dict:
    """Create an explicit SOP batch after zero-write type/parameter/input preflight.

    Inputs reference any declared spec or existing direct child; None retains
    empty input slots. All nodes exist before wiring or parameter expressions.
    dry_run cannot prove VEX/cook/geometry. After creation
    starts, cleanup and transaction recovery keep their existing strict rules.
    """
    import dsh_hou_helpers as h
    try:
        p, existing, specs = _prepare_module(parent, nodes, output, dry_run, interfaces, required_outputs)
    except h.PreflightError:
        raise
    except (ValueError, TypeError, hou.Error) as error:
        raise h.PreflightError([{'node':'module','field':'preflight','message':str(error)}]) from error
    if dry_run:
        return {'valid': True, 'dry_run': True, 'scene_writes': 0, 'applied': False,
                'parent': p.path(), 'node_count': len(specs),
                'output': output, 'interface_status': 'unverified' if interfaces is not None else 'not_requested',
                'required_outputs': list(required_outputs or []),
                'note': 'Static preflight only; VEX, dynamic menus, cooking and interface geometry remain unverified.'}
    from dsh_cook_control import require_evaluation
    require_evaluation('build_module')
    baseline = set(p.children())
    provenance = dict(h._OWNED_NODE_SESSIONS)
    # renderNode() can fall back to displayNode() even without a render flag.
    # Snapshot flags themselves; restoring the effective node would add a flag.
    display_flags = {n for n in baseline if n.isDisplayFlagSet()}
    render_flags = {n for n in baseline if n.isRenderFlagSet()}
    created = {}
    try:
        for spec in specs:
            created[spec['name']] = h.tab_create(p, spec['type'], name=spec['name'])
        sources = existing | created
        for spec in specs:
            n = created[spec['name']]
            input_nodes = [None if s is None else sources[s] for s in spec['inputs']]
            for index, source in enumerate(input_nodes):
                if source is not None:
                    n.setInput(index, source)
            h._initialize_created_inputs(n, input_nodes)
            h._snap_into_flow(n)
        for spec in specs:
            n = created[spec['name']]
            if spec['parms']:
                # Counts instantiate parameters. This remains inside the new-
                # module transaction; any later failure removes the whole batch.
                for count in spec['_counts']:
                    h.set_parm(n,count,spec['parms'][count])
                remaining={k:v for k,v in spec['parms'].items() if k not in spec['_counts']}
                if remaining:h.set_parms(n, remaining)
        validation = verify_network(p, output=created[output], nodes=list(created.values()),
                                    limit=max(512, len(created)))
        required_checks = []
        for name in required_outputs or []:
            node = created[name]
            geometry = node.geometry()
            content = _content_nonempty(geometry) if geometry is not None else {'nonempty':None, 'status':'not_evaluated'}
            required_checks.append({'output':node.path(), **content, 'errors':list(node.errors())})
        if any(not row['nonempty'] or row['errors'] for row in required_checks):
            raise h.CheckpointError('required module output is empty or has cook errors; newly created module removed',
                                    {**validation, 'ok':False, 'failure_reasons':['required_output'], 'required_outputs':required_checks})
        if required_checks: validation['required_outputs'] = required_checks
        if not validation['ok']:
            raise RuntimeError(f'module cook/output failed: {validation["issues"]}; nonempty={validation["nonempty"]}')
        interface_checks = h.geo_check_interfaces(created[output], interfaces) if interfaces is not None else None
        if interface_checks is not None and not interface_checks['ok']:
            raise h.CheckpointError('build_module interface contract failed/unverified; new module removed',
                                    {**validation,'ok':False,'failure_reasons':['interface_contract'],
                                     'interface_checks':interface_checks})
        return {'valid': True, 'dry_run': False, 'parent': p.path(),
                'created': {name: n.path() for name, n in created.items()}, 'validation': validation,
                **({'interface_checks':interface_checks} if interfaces is not None else {})}
    except BaseException as error:
        for n in reversed(p.children()):
            if n not in baseline:
                n.destroy()
        h._OWNED_NODE_SESSIONS.clear()
        h._OWNED_NODE_SESSIONS.update(provenance)
        raise
    finally:
        # Creation may auto-select a display node; existing flags stay user-owned.
        for n in p.children():
            if n.isDisplayFlagSet() and n not in display_flags:
                n.setDisplayFlag(False)
            if n.isRenderFlagSet() and n not in render_flags:
                n.setRenderFlag(False)
        for n in display_flags:
            n.setDisplayFlag(True)
        for n in render_flags:
            n.setRenderFlag(True)
