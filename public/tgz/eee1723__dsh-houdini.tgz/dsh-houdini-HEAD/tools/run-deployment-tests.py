"""Run deployment regressions, optionally with both licensed isolated H21/H22 hythons."""
from __future__ import annotations
import argparse
from pathlib import Path
import subprocess
import sys
import tempfile
import re
from houdini_test_environment import isolated_environment, launch_directory, reexec_unpacked_test_cli

ROOT = Path(__file__).resolve().parents[1]
PURE = ["dsh-test-environment", "dsh-request-registry", "dsh-executor-discovery", "dsh-isolated-manifest", "dsh-worker-limits", "dsh-hda-report", "dsh-bgeo-fingerprint", "dsh-release-policy", "dsh-install-runtime", "dsh-runtime-compat", "dsh-deployment", "dsh-installer-bootstrap", "dsh-managed-preview-paths", "dsh-network-layout", "video-runtime-package"]
HOUDINI = ["dsh-manager-update", "dsh-launcher-preflight", "dsh-frontend-lifetime", "dsh-force-repair", "dsh-profile-sync", "dsh-install-ui", "dsh-network-ui",
           "dsh-bridge-raw-gate", "dsh-bridge-transport", "dsh-request-recovery", "dsh-node-ownership", "dsh-bridge-caught-failure", "dsh-tab-create-failure",
           "dsh-object-parenting", "dsh-layout-flow", "dsh-network-boxes", "dsh-network-notes", "dsh-handoff-layout", "dsh-scene-network-render-contract", "dsh-multiparm-restoration", "dsh-output-checkpoint", "dsh-viewport-screenshot", "dsh-preview-backend", "dsh-render-color-management", "dsh-render-service-box", "dsh-cop-contracts",
           "dsh-hda-public-contract", "dsh-output-publication", "dsh-hda-lifecycle", "dsh-authoring-contract", "dsh-tutorial-contracts", "dsh-repeated-layout", "dsh-scoped-observation", "dsh-snapshot-worker", "dsh-shared-continuity", "dsh-parameter-patch"]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--hython", action="append", type=Path, default=[])
parser.add_argument('--suite', action='append', choices=sorted(set(PURE + HOUDINI)))
reexec_unpacked_test_cli()
args = parser.parse_args()
targets = [(sys.executable, PURE)] if not args.hython else [(str(binary), PURE + HOUDINI) for binary in args.hython]
if args.suite:
    if not args.hython and any(suite not in PURE for suite in args.suite):
        parser.error('Houdini suites require --hython')
    targets = [(binary, [suite for suite in suites if suite in args.suite]) for binary, suites in targets]
observed_versions = set()
for binary, suites in targets:
    if not Path(binary).is_file():
        raise RuntimeError("Hython/interpreter not found: " + binary)
    # Explicitly isolated user preferences; never inherit installed user packages.
    prefs = tempfile.mkdtemp(prefix="dsh-deployment-regression-")
    env = isolated_environment(prefs, executable=binary if args.hython else None)
    env['DSH_HOUDINI_RECOVERY_ROOT'] = str(Path(prefs) / 'recovery')
    cwd = launch_directory(binary) if args.hython else ROOT
    if args.hython:
        probe = subprocess.run([binary, "-c", "import hou; print('DSH_TEST_HOUDINI=' + '.'.join(map(str,hou.applicationVersion()[:2])))"],
                               cwd=cwd, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", check=True,
                               timeout=120, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        match = re.search(r"DSH_TEST_HOUDINI=(\d+\.\d+)", probe.stdout)
        if match is None or match[1] not in ("21.0", "22.0") or match[1] in observed_versions:
            raise RuntimeError("Expected distinct supported H21/H22 interpreters, not duplicate or mislabeled paths")
        observed_versions.add(match[1])
    for suite in suites:
        print(f"[{Path(binary).parent.parent.name}] {suite}", flush=True)
        completed = subprocess.run([binary, str(ROOT / "tools/tests" / (suite + ".test.py"))],
                                   cwd=cwd, env=env, capture_output=True, text=True,
                                   encoding="utf-8", errors="replace", timeout=300,
                                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if completed.returncode:
            print(f"{suite} exited {completed.returncode}", flush=True)
            if completed.stdout:
                print("stdout:\n" + completed.stdout[-4000:], flush=True)
            if completed.stderr:
                print("stderr:\n" + completed.stderr[-4000:], flush=True)
            raise subprocess.CalledProcessError(completed.returncode, completed.args)
print("Deployment regression suites passed", flush=True)
