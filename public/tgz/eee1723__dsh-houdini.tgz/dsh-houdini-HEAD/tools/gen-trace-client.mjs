import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import vm from "node:vm";
import ts from "typescript";
import { fileURLToPath } from "node:url";
import { classifyRawEffect, isHoudiniDetailRead, isHoudiniHostCall, isStructuredHoudiniCall, collectVerbAdoption, processOutcomeFor } from "../skills/houdini-trace-analysis/scripts/evidence-helpers.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (p) =>
  fs.readFileSync(path.join(root, p), "utf8").replaceAll("\r\n", "\n");
const hash = (text) => crypto.createHash("sha256").update(text).digest("hex");
const paragraphStarts = (text) => text.split(/\n\s*\n/)
  .map(part => part.replaceAll("`", "").trimStart().split("{{")[0].slice(0, 90))
  .filter(start => start.length >= 25);
const sourceIdentity = (text) => ({ hash: hash(text), bytes: Buffer.byteLength(text) });
export function resourceIdentity(file, bytes) {
  // Text resources describe repository content, independent of checkout EOLs.
  // Keep binary resources byte-exact, including any CRLF byte sequences.
  if (/\.(?:md|py|m?js|json|ya?ml)$/i.test(file))
    bytes = Buffer.from(bytes.toString("utf8").replaceAll("\r\n", "\n"));
  return { hash: hash(bytes), bytes: bytes.length };
}
function initializer(file, name, bindings = {}) {
  const source = ts.createSourceFile(
    file,
    read(file),
    ts.ScriptTarget.Latest,
    true,
  );
  let found;
  function visit(node) {
    if (
      ts.isVariableDeclaration(node) &&
      ts.isIdentifier(node.name) &&
      node.name.text === name
    )
      found = node.initializer;
    ts.forEachChild(node, visit);
  }
  visit(source);
  if (!found) throw new Error(`${file}: missing ${name}`);
  const js = ts.transpile(`const value = ${found.getText(source)}; value;`);
  return vm.runInNewContext(js, bindings, { timeout: 1000 });
}
export function traceSources() {
  const summary = initializer(
    "src/generated-verb-contract.ts",
    "VERB_CATALOG_SUMMARY",
  );
  const guidance = initializer("src/index.ts", "GUIDANCE", {
    VERB_CATALOG_SUMMARY: summary,
  });
  const skills = initializer("src/skill.ts", "SKILLS").map(({ name, dir }) => {
    const base = `skills/${dir}`;
    const files = [];
    function walk(relative) {
      for (const entry of fs
        .readdirSync(path.join(root, relative), { withFileTypes: true })
        .sort((a, b) => a.name.localeCompare(b.name))) {
        if (
          entry.name.startsWith(".") ||
          entry.name === "__pycache__" ||
          entry.isSymbolicLink()
        )
          continue;
        const file = `${relative}/${entry.name}`;
        if (entry.isDirectory()) walk(file);
        else {
          const bytes = fs.readFileSync(path.join(root, file));
          files.push({
            path: file.slice(base.length + 1),
            ...resourceIdentity(file, bytes),
          });
        }
      }
    }
    walk(base);
    const markdown = read(`${base}/SKILL.md`);
    const description = markdown.match(/^description:\s*(.+)$/m)?.[1] || "";
    return { name, description, base, files };
  });
  const presets = fs
    .readdirSync(path.join(root, "presets"))
    .sort()
    .flatMap((name) => {
      const presetFile = `presets/${name}/cordis.patch.yml`;
      if (!fs.existsSync(path.join(root, presetFile))) return [];
      const file = `presets/${name}/persona.md`;
      const prefix = read(file).trim();
      return [
        {
          name,
          file,
          presetFile,
          ...sourceIdentity(prefix),
          paragraphStarts: paragraphStarts(prefix),
        },
      ];
    });
  return {
    guidance: {
      name: guidance.name,
      order: guidance.order,
      ...sourceIdentity(guidance.text),
      paragraphStarts: paragraphStarts(guidance.text),
      source: "src/index.ts",
    },
    skills,
    presets,
    tools: initializer('src/tool-catalog.ts', 'PLUGIN_TOOLS', {
      HOUDINI_TOOLS: initializer('src/tool-catalog.ts', 'HOUDINI_TOOLS'),
      IMAGE_TOOLS: initializer('src/tool-catalog.ts', 'IMAGE_TOOLS'),
      VIDEO_TOOLS: initializer('src/tool-catalog.ts', 'VIDEO_TOOLS'),
    }),
  };
}
export function generatedTraceBlock() {
  const adapter = ts.createSourceFile('src/dsh-adapter.ts', read('src/dsh-adapter.ts'), ts.ScriptTarget.Latest, true);
  const decoder = adapter.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'liveJobResult');
  if (!decoder) throw new Error('Missing canonical live-job decoder');
  const liveJobDecoder = ts.transpile(decoder.getText(adapter), {target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext})
    .replace(/^export /m, '');
  const runtime = read("client/trace-runtime.js");
  const model = read("client/trace-model.js");
  const view = read("client/trace-view.js");
  const css = read("client/trace-view.css");
  const analysis = [classifyRawEffect, isHoudiniDetailRead, isHoudiniHostCall, isStructuredHoudiniCall, collectVerbAdoption, processOutcomeFor]
    .map(fn => `var ${fn.name} = (${fn.toString().replaceAll('\r\n', '\n')});`).join('\n    ');
  return `// >>> houdini-trace (generated by tools/gen-trace-client.mjs — do not edit)
    var LIVE_JOB_KIND = ${JSON.stringify(initializer('src/dsh-adapter.ts','LIVE_JOB_KIND'))};
    var LIVE_JOB_RESULT = ${JSON.stringify(initializer('src/dsh-adapter.ts','LIVE_JOB_RESULT'))};
    ${liveJobDecoder.trim()}
    var traceView;
    function getTraceView(React) {
      if (traceView) return traceView;
      var sources = ${JSON.stringify(traceSources())};
      var css = ${JSON.stringify(css)};
      ${analysis}
      var analysis = { classifyRawEffect, isHoudiniDetailRead, isHoudiniHostCall, isStructuredHoudiniCall, collectVerbAdoption, processOutcomeFor };
      var createModel = (${model.trim()});
      var createView = (${view.trim()});
      var createRuntime = (${runtime.trim()});
      traceView = createRuntime(React, getTraceCatalog(), sources, css, createModel, createView, analysis, readHoudiniCanonical);
      return traceView;
    }
    // <<< houdini-trace`;
}
export function generatedNodeDeliveryFactory() {
  const shared = ts.transpile(read('src/node-delivery-record.ts'), {target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext})
    .replace(/^export /gm, '');
  return read('client/node-delivery.js').replace('/* NODE_DELIVERY_RECORD */', shared);
}
export function generatedNodeDeliveryBlock() {
  const source = generatedNodeDeliveryFactory();
  return `// >>> houdini-node-delivery (generated by tools/gen-trace-client.mjs — do not edit)
    var nodeDeliveryFactory = (${source.trim()});
    // <<< houdini-node-delivery`;
}
if (
  process.argv[1] &&
  path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  const file = path.join(root, "client.js");
  const old = read("client.js");
  const pattern =
    /\/\/ >>> houdini-trace[^\n]*\n[\s\S]*?\/\/ <<< houdini-trace/;
  if (!pattern.test(old)) throw new Error("Missing trace generation markers");
  const deliveryPattern =
    /\/\/ >>> houdini-node-delivery[^\n]*\n[\s\S]*?\/\/ <<< houdini-node-delivery/;
  if (!deliveryPattern.test(old)) throw new Error("Missing node delivery generation markers");
  const next = old.replace(pattern, () => generatedTraceBlock())
    .replace(deliveryPattern, () => generatedNodeDeliveryBlock());
  if (process.argv.includes("--check")) {
    if (next !== old)
      throw new Error(
        "Trace bundle/source inventory drifted; run npm run build",
      );
  } else if (next !== old) fs.writeFileSync(file, next);
  console.log("Trace client and source inventory in sync");
}
