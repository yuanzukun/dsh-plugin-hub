import assert from 'node:assert/strict';
import {
  normalizeTraceSteps,
  parseToolArguments,
  toolResultFailed,
  toolResultText,
  unresolvedExecutionRequests,
} from '../normalized-trace-steps.mjs';
import {isStructuredHoudiniCall,collectVerbAdoption,nativeImageEvidence,linkNativeImageResponses} from '../../skills/houdini-trace-analysis/scripts/evidence-helpers.mjs';
import {LIVE_JOB_KIND,LIVE_JOB_RESULT} from '../../lib/dsh-adapter.js';

const call = (seq, callId, name, args) => ({
  seq,
  time: 1_000 + seq,
  type: 'tool/call',
  data: { callId, name, arguments: args },
});
const result = (seq, callId, text, isError = false) => ({
  seq,
  time: 1_000 + seq,
  type: 'tool/result',
  data: {
    turn: 2,
    step: 3,
    message: {
      source: { callId },
      content: [{ type: 'tool_result', isError, content: [{ type: 'text', text }] }],
    },
  },
});

const ledger = [
  'done',
  '',
  'verbs (1):',
  '1. [ok] set_parm(["/obj/a","tx",1]) -> {"ok":true} (1.5ms)',
  '',
  'raw-usage:',
  '{"coveredMutations":[{"name":"setInput","count":2}],"suspectedMutations":[]}',
  '',
  'rollback:',
  '{"attempted":true,"succeeded":true}',
  '',
  'hint:',
  'prefer the verb',
].join('\n');

const original = result(2, 'call-a', ledger);
const replay = result(7, 'call-a', ledger);
const events = [
  call(1, 'call-a', 'houdini_exec', '{"code":"hou.node(\\"/obj/a\\").setInput(0, None)"}'),
  original,
  replay,
  result(8, 'missing-call', 'orphan'),
  call(9, 'call-b', 'houdini_query', '{broken'),
  result(10, 'call-b', 'Error: query failed'),
];

const normalized = normalizeTraceSteps(events);
assert.equal(normalized.steps.length, 2);
assert.equal(normalized.replayedResults.length, 1);
assert.deepEqual(normalized.unmatchedResults, [{ callId: 'missing-call', resultSeq: 8, time: 1_008 }]);

const first = normalized.steps[0];
assert.equal(first.callSeq, 1);
assert.equal(first.resultSeq, 2);
assert.equal(first.tool, 'houdini_exec');
assert.equal(first.failed, false);
assert.deepEqual(first.verbs, [{
  ledgerIndex: 1,
  ok: true,
  verb: 'set_parm',
  args: '["/obj/a","tx",1]',
  result: { ok: true },
  resultText: '{"ok":true}',
  ms: 1.5,
}]);
assert.deepEqual(first.mutatingRawMethods, ['setInput', 'setInput']);
assert.deepEqual(first.rollback, { attempted: true, succeeded: true });
assert.equal(first.advisory, 'prefer the verb');

// Native display truncation and PTC log text must resolve through the same producer decoder.
const actualJob={ok:true,stdout:'original HOM diagnostic',stderr:'',status:'done',jobId:'a'.repeat(12),
  execution:{runtime_id:'b'.repeat(32),sequence:42,observed_at:42},
  verbs:[{verb:'set_parm',ok:true,args:['/obj/part','tx',3],result:{value:3},ms:1}],
  result:{output:'/obj/part/OUT'}};
const jobRead={job:{kind:LIVE_JOB_KIND,id:'houdini-live-original'},text:JSON.stringify({
  kind:LIVE_JOB_RESULT,job_id:'houdini-live-original',value:actualJob})};
for(const mode of ['native','metadata','legacy']) {
  const nested=mode!=='native';
  const jobEvents=nested?[
    {seq:1,type:'tool/ptc-dispatch-start',data:{subCallId:'collect',name:'job_output',arguments:{job_id:jobRead.job.id}}},
    {seq:2,type:'tool/ptc-dispatch',data:{subCallId:'collect',name:'job_output',
      ...(mode==='metadata'?{meta:{canonical:jobRead},content:[{type:'text',text:'[output truncated]'}]}:{content:[{type:'text',text:JSON.stringify({
        kind:'dsh-houdini/execution-v1',callId:'collect',tool:'job_output',value:jobRead})}]})}},
  ]:[call(1,'collect','job_output',{job_id:jobRead.job.id}),{...result(2,'collect','[output truncated]'),data:{
    ...result(2,'collect','[output truncated]').data,meta:{canonical:jobRead}}}];
  const read=normalizeTraceSteps(jobEvents);
  assert.equal(read.steps[0].isHoudini,true);
  assert.deepEqual(read.steps[0].canonical,actualJob);
  assert.equal(read.steps[0].verbs[0].verb,'set_parm');
  assert.equal(read.uniqueExecutions.length,1);
  assert.equal(read.steps[0].resultText,nested?jobEvents[1].data.content[0].text:'[output truncated]',
    'cost accounting retains actual visible/logged text instead of substituting audit metadata');
  const generic=structuredClone(jobRead);generic.job.kind='bash';
  const genericEvents=[call(1,'generic','job_output',{}),{...result(2,'generic','ordinary process output'),data:{
    ...result(2,'generic','ordinary process output').data,meta:{canonical:generic}}}];
  const ignored=normalizeTraceSteps(genericEvents);
  assert.equal(ignored.steps[0].isHoudini,false);
  assert.equal(ignored.steps[0].canonical,null);
  assert.deepEqual(ignored.uniqueExecutions,[]);
}

assert.deepEqual(normalized.steps[1].args, { _raw: '{broken' });
assert.equal(normalized.steps[1].failed, true);
assert.equal(toolResultText(original.data.message), ledger);
const currentResult = {role:'tool',source:{kind:'tool',callId:'v4'},
  content:[{type:'text',text:ledger}]};
assert.equal(toolResultText(currentResult), ledger, 'DSH 0.2 role=tool text is preserved');
assert.equal(toolResultText({content:[{type:'tool-result',content:[{type:'text',text:ledger}]}]}), ledger);
const current = normalizeTraceSteps([call(11,'v4','houdini_inspect',{code:'scene_info()'}),
  {seq:12,time:1012,type:'tool/result',data:{message:currentResult}}]).steps[0];
assert.equal(current.resultText.length,ledger.length);
assert.equal(current.verbs[0].verb,'set_parm');
assert.equal(toolResultFailed(original.data.message, '\nExecution failed: later'), true);
assert.deepEqual(parseToolArguments({ x: 1 }), { x: 1 });
assert.deepEqual(parseToolArguments('null'), { _raw: 'null' });

const childId='parent:ptc:1', nestedValue={ok:true,result:{observed:1},verbs:[{verb:'scene_info',ok:true,args:[],kwargs:{},result:{},ms:1}]};
const nestedEvents=[
  {seq:20,time:20,type:'tool/ptc-dispatch-start',data:{subCallId:childId,parentCallId:'parent',name:'houdini_inspect',arguments:{code:'__result__=scene_info()'}}},
  {seq:21,time:21,type:'tool/ptc-dispatch',data:{subCallId:childId,parentCallId:'parent',name:'houdini_inspect',content:[{type:'text',text:JSON.stringify({kind:'dsh-houdini/execution-v1',callId:childId,tool:'houdini_inspect',value:nestedValue})}]}},
];
const nested=normalizeTraceSteps(nestedEvents).steps[0];
assert.deepEqual(nested.canonical,nestedValue);
assert.equal(nested.parentCallId,'parent');
assert.equal(nested.canonicalStatus,'retained_in_dispatch');
assert.equal(nested.verbs[0].verb,'scene_info');
const unrelated=structuredClone(nestedEvents);
unrelated[1].data.content[0].text=unrelated[1].data.content[0].text.replace(childId,'wrong-id');
assert.equal(normalizeTraceSteps(unrelated).steps[0].canonical,null, 'other sub-call records cannot become execution facts');

console.log('normalized trace step tests passed');

const evidenceText = 'operation-evidence:\n' + JSON.stringify([
  {ledgerIndex:1,verb:'render_view',output:'Z:/project/render/a.png',frame:7,ok:false,pixel_status:'failed'},
]) + '\n\nverbs (1):\n1. [ok] render_view(["/obj/a/OUT"]) -> {"service":"a huge truncated… (1ms)';
const structured = normalizeTraceSteps([call(1,'e','houdini_exec',{code:'render_view(out)'}),result(2,'e',evidenceText)]).steps[0];
assert.equal(structured.verbs[0].ok, true, 'transport ledger success stays distinct from pixel failure');
assert.equal(structured.verbs[0].result.ok, false);
assert.equal(structured.verbs[0].result.frame, 7);
assert.equal(structured.verbs[0].result.output, 'Z:/project/render/a.png');
const rolled = normalizeTraceSteps([call(10,'r','houdini_exec',{}),result(15,'r','transaction:\n{"status":"rolled_back","nodes":[]}\n\n'+evidenceText,true)]).steps[0];
assert.equal(rolled.durationMs,5);
assert.equal(rolled.transaction.status,'rolled_back');

const receiptStep = (index, status, runtime='one', ref='request') => ({index,
  tool:'houdini_exec', canonical:{requestReceipt:{runtime_id:runtime,request_ref:ref,status}}});
assert.equal(unresolvedExecutionRequests([receiptStep(1,'unknown_transport')]).length,1);
assert.equal(unresolvedExecutionRequests([receiptStep(1,'unknown_transport'),receiptStep(2,'done')]).length,0);
assert.equal(unresolvedExecutionRequests([receiptStep(1,'unknown_transport'),receiptStep(2,'done','two')]).length,1);
assert.equal(unresolvedExecutionRequests([receiptStep(1,'unknown_transport'),receiptStep(2,'done','one','other')]).length,1);
assert.equal(unresolvedExecutionRequests([receiptStep(1,'done'),receiptStep(2,'unknown_transport')]).length,0);
const runningReceipts=[receiptStep(1,'unknown_transport'),receiptStep(2,'queued'),receiptStep(3,'running')];
assert.equal(unresolvedExecutionRequests(runningReceipts)[0].status,'running');
assert.equal(unresolvedExecutionRequests(runningReceipts)[0].index,3,'report locates the latest observation');
for(const terminal of ['result_expired','result_unavailable','done','not_executed']){
  assert.deepEqual(unresolvedExecutionRequests([...runningReceipts,receiptStep(4,terminal)]),[],
    'expired results and confirmed terminal receipts are not still-running or transport-unknown requests');
}
assert.equal(unresolvedExecutionRequests([{index:1,resultText:'request-receipt:\n'+JSON.stringify({runtime_id:'one',request_ref:'q',status:'unknown_transport'})}]).length,1);

const captureValue={ok:true,result:{node:'/obj/demo/CTRL',path:'C:/capture.png',scene_writes:0,semantic_status:'unverified'},
  images:['C:/capture.png'],imageAttachments:[{from:'C:/capture.png',attachment:{attachmentId:'ui-image'}}],
  evidence:[{operation:'ui_capture',scene_writes:0,semantic_status:'unverified'}],
  outcome:{batch:'completed',operations:{total:1,failed:0},checks:{failed:0,warning:0,unverified:0}},
  transaction:{status:'no_scene_change'},execution:{runtime_id:'ui-runtime',sequence:1,observed_at:30},
  requestReceipt:{request_ref:'ui-ref',runtime_id:'ui-runtime',owner_call:'capture',status:'done'}};
const captureNative=result(31,'capture','Native pane captured; visual interpretation unverified.');
captureNative.data.meta={canonical:captureValue};
const captureRecovery=result(35,'recover-ui','Original native capture recovered.');
captureRecovery.data.meta={canonical:{...captureValue,requestReceipt:{...captureValue.requestReceipt,retrieved:true}}};
const captureNestedId='program:capture';
const captures=normalizeTraceSteps([
  call(30,'capture','houdini_ui_screenshot',{node:'/obj/demo/CTRL',view:'parameters'}),captureNative,
  {seq:32,time:32,type:'tool/ptc-dispatch-start',data:{subCallId:captureNestedId,parentCallId:'program',name:'houdini_ui_screenshot',arguments:{node:'/obj/demo',view:'network'}}},
  {seq:33,time:33,type:'tool/ptc-dispatch',data:{subCallId:captureNestedId,parentCallId:'program',name:'houdini_ui_screenshot',content:[{type:'text',text:JSON.stringify({
    kind:'dsh-houdini/execution-v1',callId:captureNestedId,tool:'houdini_ui_screenshot',value:{...captureValue,execution:{...captureValue.execution,sequence:2}}})}]}},
]);
assert.equal(captures.steps.length,2);
assert.equal(captures.uniqueExecutions.length,2);
assert.deepEqual(captures.uniqueExecutions.map(row=>row.verbCalls),[0,0],'capture has no fabricated Python verb ledger');
for(const step of captures.steps){
  assert.equal(step.code,'');assert.deepEqual(step.verbs,[]);assert.equal(step.transaction.status,'no_scene_change');
  assert.equal(isStructuredHoudiniCall(step),true);
  assert.deepEqual(step.canonical.images,['C:/capture.png']);
  assert.equal(step.canonical.result.semantic_status,'unverified');
  assert.equal(step.canonical.evidence[0].operation,'ui_capture');
}
const captureAdoption=collectVerbAdoption(captures.steps);
assert.equal(captureAdoption.structuredCalls,2);assert.equal(captureAdoption.pythonCalls,0);
assert.equal(captureAdoption.rawUnknownEffectCalls,0);assert.equal(captureAdoption.rawFailedCalls,0);
assert.equal(captureAdoption.execCalls,0);
assert.equal(nativeImageEvidence(captures.steps).filter(row=>row.delivered).length,2);
assert(nativeImageEvidence(captures.steps).every(row=>row.semanticStatus==='unverified'));
const recoveredTrace=normalizeTraceSteps([
  call(30,'capture','houdini_ui_screenshot',{node:'/obj/demo/CTRL'}),captureNative,
  call(34,'recover-ui','houdini_request',{request_ref:'ui-ref'}),captureRecovery,
]);
assert.equal(recoveredTrace.uniqueExecutions.length,1,'request recovery does not invent a second capture');
assert.equal(recoveredTrace.steps[1].executionReplay,true);
assert.equal(recoveredTrace.steps[1].recoveredExecution,true);
assert.deepEqual(recoveredTrace.steps[1].canonical.images,captureValue.images);
assert.deepEqual(recoveredTrace.steps[1].verbs,[]);
const unknownCapture={index:1,tool:'houdini_ui_screenshot',canonical:{requestReceipt:{request_ref:'ui-q',runtime_id:'ui-runtime',status:'unknown_transport'}}};
const recoveredCapture={index:2,tool:'houdini_request',canonical:{...captureValue,requestReceipt:{request_ref:'ui-q',runtime_id:'ui-runtime',status:'done',retrieved:true}}};
assert.equal(unresolvedExecutionRequests([unknownCapture]).length,1);
assert.equal(unresolvedExecutionRequests([unknownCapture,recoveredCapture]).length,0);
console.log('UI capture trace: native/nested canonical images, structured non-Python classification and recovery passed');

// Real isolated-read shape from refinement-surfaces seq 725/910: unlike the
// initial run response it has no top-level ok, while DSH retains both canonical
// imageAttachments and native image blocks. Compaction later replays the call.
const isolatedImages=(names)=>({kind:'isolated-houdini',run_directory:'C:/fixture/run',
  report_path:'C:/fixture/run/report.json',report:{ok:true,finished:true,checks:[]},scope:'Independent run only',
  imageAttachments:names.map(name=>({from:'C:/fixture/run/'+name+'.png',
    attachment:{attachmentId:'sha256:fixture-'+name,mediaType:'image/jpeg',width:512,height:512,bytes:100,name:name+'.png'},
    semantic_status:'unverified'}))});
const isolatedRead=isolatedImages(['wood','screen','document','ruler','deskmat']);
const isolatedFollowup=isolatedImages(['coin','normal','phone']);
const readNative=result(54,'read-isolated',JSON.stringify(isolatedRead));
readNative.data.meta={canonical:isolatedRead};
readNative.data.message.content.push(...isolatedRead.imageAttachments.map(i=>({type:'image',attachment:i.attachment})));
const nestedRead={seq:62,time:1062,type:'tool/ptc-dispatch',data:{subCallId:'program:read-isolated',parentCallId:'program',
  name:'houdini_isolated',meta:{canonical:isolatedFollowup},content:[{type:'text',text:JSON.stringify(isolatedFollowup)},
    ...isolatedFollowup.imageAttachments.map(i=>({type:'image',attachment:i.attachment}))]}};
const isolatedTrace=normalizeTraceSteps([
  call(50,'read-isolated','houdini_isolated',{operation:'read',output_dir:'C:/fixture/run'}),
  call(51,'already-pending','read',{file_path:'other.json'}),readNative,
  result(55,'already-pending','Earlier unrelated call returned after the image'),
  call(56,'after-images','grep',{pattern:'resolution'}),result(57,'after-images','result'),
  {seq:60,time:1060,type:'tool/ptc-dispatch-start',data:{subCallId:'program:read-isolated',parentCallId:'program',
    name:'houdini_isolated',arguments:{operation:'read',output_dir:'C:/fixture/run'}}},nestedRead,
  call(63,'after-nested','read',{file_path:'followup.json'}),result(64,'after-nested','result'),
  {...readNative,seq:70,time:1070},{...nestedRead,seq:72,time:1072},
]);
assert.equal(isolatedTrace.replayedResults.length,2);
assert.equal(isolatedTrace.uniqueExecutions.length,0,'isolated report content must not be counted as a live HOM execution');
assert.deepEqual(isolatedTrace.steps[0].canonical,isolatedRead);
assert.deepEqual(isolatedTrace.steps[3].canonical,isolatedFollowup);
assert.equal(isolatedTrace.steps[3].canonicalStatus,'retained_in_dispatch');
const isolatedObservations=linkNativeImageResponses(nativeImageEvidence(isolatedTrace.steps),isolatedTrace.steps,[]);
assert.equal(isolatedObservations.length,8,'five native plus three nested images, without compaction replay duplication');
assert(isolatedObservations.every(row=>row.delivered&&row.semanticStatus==='unverified'));
assert(isolatedObservations.slice(0,5).every(row=>row.nextToolStep.index===3&&row.nextToolStep.tool==='grep'),
  'a pending call that returns later is not a response to the images');
assert(isolatedObservations.slice(5).every(row=>row.nextToolStep.index===5&&row.nextToolStep.tool==='read'));
const proseOnly=normalizeTraceSteps([call(80,'unretained','houdini_isolated',{}),result(81,'unretained',JSON.stringify(isolatedRead))]);
assert.equal(nativeImageEvidence(proseOnly.steps).length,0,'do not reconstruct canonical image facts from rendered text');
console.log('Isolated read images: native/nested public wrappers, replay deduplication and subsequent-call links passed');
