"""Static module errors carry zero writes; preceding or subsequent edits do not."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'houdini/python3.11libs'))
import hou
import dsh_hou_helpers as h
import dsh_bridge as b

root=h.tab_create('/obj','geo','__module_preflight')
source=h.tab_create(root,'box','source')
try:
    # Static validation must agree with actual HOM setters for size-one fields.
    # The old preflight demanded [64] for circle.divs, then the setter rejected it.
    scalar_specs=[
        {'name':'profile','type':'circle','parms':{'type':'poly','divs':64}},
        {'name':'body','type':'tube','parms':{'type':'poly','height':2.5,'cols':18,'cap':1}},
        {'name':'wire','type':'polywire','inputs':['profile'],'parms':{'radius':0.02,'div':8}},
        {'name':'expr','type':'circle','parms':{'type':'poly','divs':{'expression':'16*2','language':'hscript'}}},
        {'name':'string_expr','type':'tube','parms':{'type':'poly','height':'1+2'}},
        {'name':'python_expr','type':'circle','parms':{'type':'poly','divs':{'expression':'8*4','language':'python'}}},
    ]
    before={n.sessionId() for n in root.children()}
    assert h.build_module(root,scalar_specs,output='wire',dry_run=True)['valid']
    assert before=={n.sessionId() for n in root.children()}
    built=h.build_module(root,scalar_specs,output='wire',required_outputs=['body','expr','string_expr','python_expr'])
    assert built['validation']['ok']
    for node,field,value in [('profile','divs',64),('body','height',2.5),('body','cols',18),
                              ('wire','radius',.02),('wire','div',8),('expr','divs',32),
                              ('string_expr','height',3),('python_expr','divs',32)]:
        assert root.node(node).evalParm(field)==value,(node,field)
        h.set_parm(root.node(node),field,value)
        assert root.node(node).evalParm(field)==value
    for spec in reversed(scalar_specs):h.delete_node(root.node(spec['name']))
    # Native BeginEnd tuples use prefixes, including names beyond angle.
    # Static cards, dry-run, creation and live setters must agree on width/name.
    for typ,field in [('revolve','angle'),('torus','angleu'),('uvtransform','tandeg'),
                      ('delete','range'),('agentlookat','distancerange')]:
        info=h.node_info(root,typ,parm_filter=field)
        card=next(c for c in info['parameters'] if c['name']==field)
        native=h.tab_create(root,typ,'native_tuple_probe')
        assert native.type().name()==info['type'],(typ,info['type'],native.type().name())
        pt=native.parmTuple(field)
        assert card['size']==len(pt)==2,card
        assert card['components']==[p.name() for p in pt],card
        h.set_parm(native,field,list(pt.eval()))
        h.delete_node(native)
    for parms,expected in [({'angle':[0,180]},(0,180)),
                           ({'beginangle':{'expression':'10+5','language':'hscript'},'endangle':180},(15,180))]:
        specs=[{'name':'revolved','type':'revolve','inputs':['source'],'parms':parms}]
        before={n.sessionId() for n in root.children()}
        assert h.build_module(root,specs,output='revolved',dry_run=True)['valid']
        assert before=={n.sessionId() for n in root.children()}
        h.build_module(root,specs,output='revolved')
        assert root.node('revolved').parmTuple('angle').eval()==expected
        h.delete_node(root.node('revolved'))
    # A missing component-name mapping still has a reliable template width.
    # It must not reintroduce the contradictory scalar/list preflight behavior.
    original_cards=h._node_parameter_cards
    def unnamed_components(typ,counts=None):
        return [{**c,'components':[]} if c['name']=='angle' else c
                for c in original_cards(typ,counts)]
    h._node_parameter_cards=unnamed_components
    try:
        specs=[{'name':'unnamed_tuple','type':'revolve','parms':{'angle':[0,180]}}]
        assert h.build_module(root,specs,output='unnamed_tuple',dry_run=True)['valid']
        specs[0]['parms']['angle']=180
        try:h.build_module(root,specs,output='unnamed_tuple',dry_run=True)
        except h.PreflightError as error:assert 'tuple needs 2' in str(error)
        else:raise AssertionError('unnamed tuple became scalar')
    finally:h._node_parameter_cards=original_cards
    # Reject nonfinite literals in dry-run before creating nodes, and preserve
    # existing parameter animation in the primitive setter's failure path.
    for field,value in [('sizex',float('nan')),('size',[1,float('inf'),1])]:
        before={n.sessionId() for n in root.children()}
        try:h.build_module(root,[{'name':'nonfinite','type':'box','parms':{field:value}}],output='nonfinite',dry_run=True)
        except h.PreflightError as error:assert 'finite' in str(error)
        else:raise AssertionError('nonfinite preflight accepted')
        assert before=={n.sessionId() for n in root.children()}
    source.parm('sizex').setExpression('1+0*$F',hou.exprLanguage.Hscript)
    keys=source.parm('sizex').keyframes()
    try:h.set_parm(source,'sizex',[1])
    except ValueError as error:assert 'scalar' in str(error)
    else:raise AssertionError('scalar list accepted')
    assert source.parm('sizex').keyframes()==keys
    h.set_parm(source,'sizex',1)
    cases=[
        ([{'name':'hidden','type':'partition'}],'hidden','hidden/deprecated'),
        ([{'name':'unknown','type':'nonexistent_test_type'}],'unknown','未知节点类型'),
        ([{'name':'bad','type':'box','parms':{'bad_parm':1}}],'bad','unknown parameter'),
        ([{'name':'bad','type':'tube','parms':{'rad':1.2}}],'bad','tuple needs 2'),
        ([{'name':'bad','type':'revolve','parms':{'angle':360}}],'bad','tuple needs 2'),
        ([{'name':'bad','type':'revolve','parms':{'angle':[0,180,360]}}],'bad','tuple needs 2'),
        ([{'name':'bad','type':'revolve','parms':{'endangle':[180]}}],'bad','scalar'),
        ([{'name':'bad','type':'sphere','parms':{'rad':1.2}}],'bad','tuple needs 3'),
        ([{'name':'bad','type':'sphere','parms':{'rad':{'expression':'1'}}}],'bad','tuple needs 3'),
        ([{'name':'bad','type':'xform','inputs':['missing']}],'bad','declared spec'),
        ([{'name':'valid','type':'box'}],'missing','newly created'),
        ([{'name':'source','type':'box'}],'source','exists'),
        ([{'name':'bad','type':'circle','parms':{'divs':[64]}}],'bad','scalar'),
        ([{'name':'bad','type':'tube','parms':{'height':[1]}}],'bad','scalar'),
        ([{'name':'bad','type':'box','parms':{'sizex':[1]}}],'bad','scalar'),
        ([{'name':'bad','type':'circle','parms':{'divs':{'expression':'8','language':'vex'}}}],'bad','language'),
        ([{'name':'bad','type':'circle','parms':{'divs':{'expression':8}}}],'bad','expression'),
        ([{'name':'bad','type':'sphere','parms':{'rad':['1','2','3']}}],'bad','numeric tuple'),
    ]
    for specs,output,message in cases:
        before={n.sessionId() for n in root.children()}
        dry=b.run_code(f'build_module({root.path()!r},{specs!r},output={output!r},dry_run=True)')
        assert not dry['ok'] and message in dry['error'],dry
        assert before=={n.sessionId() for n in root.children()}
        env=b.run_code(f'build_module({root.path()!r},{specs!r},output={output!r})')
        assert not env['ok'] and message in env['error'],env
        assert env['transaction']['status']=='no_scene_change',env
        evidence=env['evidence'][0]
        assert evidence['phase']=='static_preflight' and evidence['scene_writes']==0,env
        assert before=={n.sessionId() for n in root.children()}
    # Valid tuple literals and component expressions retain the existing API.
    for parms in ({'rad':[1,2,3]}, {'radx':{'expression':'0+1','language':'hscript'}}):
        specs=[{'name':'valid_shape','type':'sphere','parms':parms}]
        assert h.build_module(root,specs,output='valid_shape',dry_run=True)['valid']
        h.build_module(root,specs,output='valid_shape')
        assert len(root.node('valid_shape').geometry().prims())>0
        h.delete_node(root.node('valid_shape'))
    # Batch declarations are a graph, not an execution order. Forward wires,
    # expression references and an explicit empty input slot remain exact.
    unordered = [
        {'name':'forward_out','type':'null','inputs':['forward_lookup']},
        {'name':'forward_lookup','type':'attribwrangle','inputs':[None,'later_shape'],
         'parms':{'class':'detail','snippet':'vector pos=point(1, "P", 0); addpoint(0, pos);'}},
        {'name':'later_shape','type':'box','parms':{'sizex':'ch("../last_shape/sizex")'}},
        {'name':'last_shape','type':'box','parms':{'sizex':3}},
    ]
    assert h.build_module(root,unordered,output='forward_out',dry_run=True)['valid']
    built=h.build_module(root,unordered,output='forward_out')
    assert built['validation']['ok'] and built['validation']['semantic_status']=='unverified'
    assert root.node('forward_lookup').input(0) is None
    assert root.node('forward_lookup').input(1)==root.node('later_shape')
    assert root.node('later_shape').evalParm('sizex')==3
    assert len(root.node('forward_out').geometry().points())==1
    for spec in unordered:h.delete_node(root.node(spec['name']))
    wide=[{'name':f'wide_{i}','type':'box'} for i in range(65)]
    assert h.build_module(root,wide,output='wide_64',dry_run=True)['node_count']==65
    assert root.node('wide_0') is None
    before={n.sessionId() for n in root.children()}
    try:h.build_module(root,[{'name':'cycle_a','type':'null','inputs':['cycle_b']},
                              {'name':'cycle_b','type':'null','inputs':['cycle_a']}],output='cycle_a')
    except Exception:pass
    else:raise AssertionError('cyclic batch accepted')
    assert before=={n.sessionId() for n in root.children()}
    # Zero-write information concerns this module, never preceding mutations.
    env=b.run_code(f'set_parm({source.path()!r},"sizex",3)\n'
                   f'build_module({root.path()!r},[{{"name":"hidden","type":"partition"}}],output="hidden")')
    assert not env['ok'] and env['transaction']['status']=='rolled_back',env
    assert source.evalParm('sizex')==1
    # A handled zero-write preflight failure may be corrected in the same batch.
    env=b.run_code(f'try:\n build_module({root.path()!r},[{{"name":"hidden","type":"partition"}}],output="hidden")\n'
                   f'except ValueError:\n pass\nset_parm({source.path()!r},"sizex",4)')
    assert env['ok'] and env['transaction']['status']=='committed',env
    assert env['verbs'][0]['summary']['scene_writes']==0 and env['verbs'][-1]['ok'],env
    assert source.evalParm('sizex')==4
    # Cook/VEX failure happens AFTER writes and may never acquire zero-write metadata.
    env=b.run_code(f'build_module({root.path()!r},[{{"name":"made","type":"box"}},'
                   '{"name":"bad_vex","type":"attribwrangle","inputs":["made"],'
                   '"parms":{"snippet":"nonexistent_function_probe();"}}],output="bad_vex")')
    assert not env['ok'] and env['transaction']['status']!='no_scene_change',env
    assert all(e.get('scene_writes')!=0 for e in env.get('evidence',[])),env
    assert root.node('made') is None and root.node('bad_vex') is None
finally:
    root.destroy()
print('module preflight zero-write/previous mutation/caught failure/post-write recovery passed on '+hou.applicationVersionString())
