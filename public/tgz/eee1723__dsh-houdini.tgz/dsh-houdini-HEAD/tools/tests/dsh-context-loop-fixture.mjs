// Run the real mounted Houdini preset and DSH agent loop with a local scripted
// provider and an owned HTTP Bridge fixture. No model API or Houdini process.
import assert from 'node:assert/strict'
import fs from 'node:fs'
import http from 'node:http'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import {createHash,randomUUID} from 'node:crypto'
import {LlmAdapter} from '@deepseek-ai/dsh-llm'
import {normalizeTraceSteps} from '../normalized-trace-steps.mjs'
import {EXPECTED_EXECUTION_CONTRACT_VERSION, EXPECTED_VERB_CATALOG_HASH, EXPECTED_VERB_NAMES}
  from '../../lib/generated-verb-contract.js'

export const inject = ['loader', 'llm', 'sessions', 'agents', 'sessionController']
const provider = 'houdini-context-fixture', model = 'scripted-local'
const runtimeId = 'a'.repeat(32), jobId = 'b'.repeat(12)
const largePayload = 'FIXTURE_BULK_BEGIN:' + 'x'.repeat(70000) + ':FIXTURE_BULK_END'

export function apply(ctx) {
  const output = process.env.DSH_CONTEXT_FIXTURE_OUT
  const outcomeReceipts = process.env.DSH_OUTCOME_FIXTURE
    ? JSON.parse(fs.readFileSync(process.env.DSH_OUTCOME_FIXTURE,'utf8')) : null
  const expiryStart = outcomeReceipts ? 12 : 10
  const catalogReceipt = process.env.DSH_CATALOG_FIXTURE
    ? JSON.parse(fs.readFileSync(process.env.DSH_CATALOG_FIXTURE,'utf8')) : null
  // Exercise both official DSH transports only in this owned fixture scope;
  // production Houdini stays in its configured presentation mode.
  ctx.on('agent/created',({agent})=>{ agent.ctx.tools.presentAs('both') })
  const catalogStart = expiryStart + 4
  const repetitionMethod = process.env.DSH_REPETITION_METHOD_FIXTURE === '1'
  const repetitionStart = catalogStart + (catalogReceipt ? 6 : 0)
  const surfaceMethod = process.env.DSH_SURFACE_METHOD_FIXTURE === '1'
  const surfaceStart = repetitionStart + (repetitionMethod ? 2 : 0) + 1
  const surfaceResources = [
    ['skill','houdini-surface-workflow','houdini-surface-workflow/SKILL.md'],
    ['read',null,'houdini-surface-workflow/references/appearance-and-sources.md'],
    ['read',null,'houdini-surface-workflow/references/generated-textures.md'],
    ['nested',null,'houdini-surface-workflow/references/sop-preview-and-uv.md'],
    ['skill','houdini-cop-workflow','houdini-cop-workflow/SKILL.md'],
    ['nested',null,'houdini-cop-workflow/references/pattern-design.md'],
    ['skill','houdini-parameter-ui','houdini-parameter-ui/SKILL.md'],
    ['nested',null,'houdini-parameter-ui/references/control-bindings.md'],
    ['skill','houdini-network-handoff','houdini-network-handoff/SKILL.md'],
    ['read',null,'houdini-network-handoff/references/network-layout.md'],
    ['nested',null,'houdini-network-handoff/references/file-delivery.md'],
  ].map(([kind,name,relative])=>{
    const file=fileURLToPath(new URL('../../skills/'+relative,import.meta.url))
    const source=fs.readFileSync(file,'utf8').replaceAll('\r\n','\n')
    return {kind,name,file,body:kind==='skill'?source.replace(/^---\n[\s\S]*?\n---\n/,'').trim():source.trim()}
  })
  const receiptStart = surfaceStart + (surfaceMethod ? surfaceResources.length : 0)
  const finalStep = receiptStart + 5
  const methodFile = fileURLToPath(new URL('../../skills/houdini-sop-workflow/references/modeling-methods.md',import.meta.url))
  const methodText = repetitionMethod ? fs.readFileSync(methodFile,'utf8').replaceAll('\r\n','\n') : ''
  const personaBody = fs.readFileSync(new URL('../../presets/houdini/persona.md',import.meta.url),'utf8')
    .replaceAll('\r\n','\n').trim().split('\n\n').slice(1)
  const skillBody = fs.readFileSync(new URL('../../skills/houdini-sop-workflow/SKILL.md',import.meta.url),'utf8')
    .replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/,'').trim().replaceAll('\r\n','\n')
  const decompositionBody = fs.readFileSync(new URL('../../skills/houdini-task-decomposition/SKILL.md',import.meta.url),'utf8')
    .replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/,'').trim().replaceAll('\r\n','\n')
  const requests = [], bridgeCalls = [], receipts = new Map()
  let sequence = 0, jobPolls = 0, expiryPolls = 0, expiryRef, busyRef, busyPolls=0, failure
  const expiredJob = 'c'.repeat(12)
  const writeReport = value => {
    fs.writeFileSync(output+'.tmp',JSON.stringify(value,null,2))
    fs.renameSync(output+'.tmp',output)
  }
  const fail = error => {
    failure ??= String(error.stack || error)
    writeReport({error:failure, requests, bridgeCalls})
  }
  const health = () => ({ok:true, runtimeId, executorId:process.env.DSH_HOUDINI_EXECUTOR_ID,
    executionContractVersion:EXPECTED_EXECUTION_CONTRACT_VERSION,
    verbCatalog:{hash:EXPECTED_VERB_CATALOG_HASH, names:EXPECTED_VERB_NAMES, count:EXPECTED_VERB_NAMES.length}})
  const observed = extra => ({ok:true, stdout:'', stderr:'', ...extra,
    execution:{...extra?.execution, runtime_id:runtimeId, executor_id:process.env.DSH_HOUDINI_EXECUTOR_ID,
      hip_path:'context-fixture.hip', sequence:++sequence, observed_at:sequence}})
  const server = http.createServer(async (req,res) => {
    try {
      let raw = ''
      for await (const chunk of req) raw += chunk
      const body = raw ? JSON.parse(raw) : {}
      bridgeCalls.push({method:req.method, path:req.url, body})
      let value
      if (req.url === '/context') value = {ok:true, result:{hip_path:'context-fixture.hip', frame:1,
        selection:[{path:'/obj/context_fixture',type:'geo'}], fixture_marker:'initial-scene-once'}}
      else if (req.url === '/health') value = health()
      else if (req.url === '/requests/prepare') {
        const requestRef = runtimeId + '.' + randomUUID().replaceAll('-','')
        receipts.set(requestRef,{owner_session:body.owner_session})
        value = {...health(), requestRef}
      } else if (req.url === '/exec') {
        const receipt = {request_ref:body.request_ref, owner_call:body.owner_call, runtime_id:runtimeId, status:'done'}
        receipts.set(body.request_ref, receipt)
        if (body.code === 'fixture_transport_unknown' || body.code === 'fixture_busy_receipt') {
          if(body.code==='fixture_busy_receipt')busyRef=body.request_ref
          res.writeHead(502, {'Content-Type':'application/json'})
          res.end(JSON.stringify({error:'fixture transport lost after admission'}))
          return
        }
        value = catalogReceipt && body.code === 'fixture_catalog'
          ? observed({...catalogReceipt,requestReceipt:receipt})
          : outcomeReceipts && body.code.startsWith('fixture_outcome_')
          ? observed({...outcomeReceipts[body.code.slice('fixture_outcome_'.length)],requestReceipt:receipt})
          : body.code === 'fixture_sync_failure'
          ? observed({ok:false,error:'FIXTURE_UNKNOWN_PARAMETER: expected angle tuple',
              result:{payload:largePayload},requestReceipt:receipt,
              transaction:{status:'rolled_back',parameter_state_restored:true},
              rollback:{success:true,scope:'FIXTURE_PARAMETER_VALUES_AND_KEYS_ONLY'},
              checks:[{verb:'set_parms',status:'unverified',reason:'FIXTURE_EFFECT_UNVERIFIED'}],
              evidence:[{verb:'set_parms',ok:false,restored:true,effect_status:'unverified',reason:'FIXTURE_GEOMETRY_UNVERIFIED'}]})
          : observed({result:{operation:body.code},requestReceipt:receipt})
      } else if (req.url === '/requests/status') {
        assert(receipts.has(body.request_ref), 'must retrieve an original reference')
        value = body.request_ref===busyRef && ++busyPolls<4
          ? {ok:true,stdout:'',stderr:'',requestReceipt:{...receipts.get(body.request_ref),status:busyPolls===1?'queued':'running'}}
          : body.request_ref===expiryRef
          ? {ok:true,stdout:'',stderr:'',requestReceipt:{...receipts.get(body.request_ref),
              status:'result_expired',jobId:expiredJob,job_finished:++expiryPolls>1,
              job_result_available:false,...(expiryPolls===1?{job_status:'running'}:{})}}
          : {ok:true,stdout:'',stderr:'',requestReceipt:{...receipts.get(body.request_ref),
              result:observed({result:{recovered:true}})}}
      } else if (req.url === '/jobs') {
        const submittedJob=body.code==='fixture_expiring_work'?expiredJob:jobId
        value = {jobId:submittedJob,requestReceipt:{request_ref:body.request_ref,owner_call:body.owner_call,
          runtime_id:runtimeId,status:'job_submitted',jobId:submittedJob}}
        receipts.set(body.request_ref,value.requestReceipt)
        if(submittedJob===expiredJob)expiryRef=body.request_ref
      } else if (req.url === '/jobs/' + jobId + '/status') {
        value = observed({jobId,status:++jobPolls === 1 ? 'running' : 'done',result:{fixture:true}})
      } else throw Error('Unexpected Bridge route: ' + req.url)
      res.writeHead(200, {'Content-Type':'application/json'})
      res.end(JSON.stringify(value))
    } catch (error) { fail(error); res.writeHead(500); res.end(String(error)) }
  })
  const port = Number(new URL(process.env.DSH_HOUDINI_BRIDGE_URL).port)
  const ready = new Promise((resolve,reject) => {server.once('error',reject);server.listen(port,'127.0.0.1',resolve)})
  const textChunks = text => [
    {type:'block-start',index:0,blockType:'text'},
    {type:'block-end',index:0,block:{type:'text',text}},
    {type:'finish',reason:{kind:'stop'}},
  ]
  class ContextFixture extends LlmAdapter {
    async listModels() { return [{provider,id:model,name:'Houdini context fixture',inputModalities:['text','image']}] }
    async resolveModel(route,id) {
      return {provider:route,id,name:'Houdini context fixture',inputModalities:['text','image'],context:{contextWindow:500000}}
    }
    async *stream(options) {
      if (options.purpose) { yield* textChunks('Context fixture'); return }
      try {
        assert(!failure, failure)
        const step = requests.length
        assert(step <= finalStep, 'fixture must converge within scripted requests')
        const system = options.messages.filter(message => message.role === 'system')
          .flatMap(message => message.content.filter(block => block.type === 'text').map(block => block.text))
          .join('\n').replaceAll('\r\n','\n')
        for (const paragraph of personaBody) assert.equal(system.split(paragraph).length-1,1,
          'the actual provider must receive each maintained persona section exactly once')
        assert(!system.includes(skillBody),'domain methods must not be eagerly duplicated in System')
        assert(!system.includes(decompositionBody),'task decomposition must remain an on-demand skill')
        for(const resource of surfaceResources)assert(!system.includes(resource.body),'surface methods must remain on demand')
        if(surfaceMethod){
          assert(system.includes('houdini-surface-workflow'),'surface routing must reach the provider')
          for(const [index,resource] of surfaceResources.entries()){
            if(step<=surfaceStart+index)continue
            const message=options.messages.find(m=>m.role==='tool'&&m.toolCallId==='context-'+(surfaceStart+index))
            const raw=message?.content.filter(b=>b.type==='text').map(b=>b.text).join('\n')??''
            const visible=raw.replaceAll('\r\n','\n')
            // Native read is text; nested read may be JSON encoded. Preserve
            // literal backslash-n in code examples rather than unescaping all text.
            const missing=resource.body.split('\n').filter(line=>line.trim())
              .find(line=>!visible.includes(line)&&!visible.includes(JSON.stringify(line).slice(1,-1)))
            assert(!missing,`complete ${resource.kind} resource must reach the actual provider: ${resource.file}; missing: ${missing}`)
          }
        }
        if (step === finalStep) {
          const skillResult=options.messages.filter(message=>message.role==='tool')
            .flatMap(message=>message.content.filter(block=>block.type==='text').map(block=>block.text)).join('\n')
          assert(skillResult.replaceAll('\r\n','\n').includes(skillBody),'on-demand skill reaches the actual provider intact')
          assert(skillResult.replaceAll('\r\n','\n').includes(decompositionBody),'registered decomposition skill reaches the actual provider intact')
        }
        const snapshots = options.messages.map(message => message.content.filter(block => block.type === 'text')
          .map(block => block.text).join('\n')).filter(text => text.includes('Houdini metadata observation.'))
        const current = snapshots.at(-1)
        assert(current, 'provider must receive the real scene context')
        assert(current.includes('Houdini image input capability'), 'provider must receive image capability')
        const runtimeEvents = ctx.sessions.get(options.sessionId).snapshotEvents()
          .filter(event => event.type === 'user/message' && event.data?.source?.kind === 'runtime-context')
        assert(runtimeEvents.length >= snapshots.length, 'snapshots must originate from the native loop events')
        const row = {step,sessionId:options.sessionId,snapshotCount:snapshots.length,
          runtimeEventCount:runtimeEvents.length,messages:options.messages}
        requests.push(row)
        fs.writeFileSync(output+'.requests.json',JSON.stringify(requests,null,2))
        if(step>=receiptStart+2){
          const expected=step===receiptStart+2?'queued':'running'
          if(step<finalStep)assert(current.includes(JSON.stringify([busyRef,expected])),
            'latest same-runtime receipt state reaches the real provider')
          for(let offset=1;offset<=Math.min(step-receiptStart-1,3);offset++){
            const message=options.messages.find(m=>m.role==='tool'&&m.toolCallId==='context-'+(receiptStart+offset))
            const visible=message?.content.filter(b=>b.type==='text').map(b=>b.text).join('\n')??''
            assert(visible.includes(offset===1?'not independent liveness probes':'HTTP timeout did not cancel'),
              'native and nested receipt values deliver the queue/recovery meaning')
          }
          if(step===receiptStart+4)assert.equal(snapshots.length,requests[receiptStart+3].snapshotCount,
            'repeating the same running receipt does not append a new context snapshot')
          if(step===finalStep){
            assert(!current.includes(busyRef),'completion retires this request without clearing unrelated facts')
            assert.equal(bridgeCalls.filter(c=>c.path==='/exec'&&c.body.code==='fixture_busy_receipt').length,1,
              'status recovery never resubmits the original operation')
          }
        }
        if (step === 1 || step === 2) {
          assert.equal(snapshots.length,requests[0].snapshotCount,'settled failure/repair must not append scene and vision again')
          const error = options.messages.find(message => message.role === 'tool' && message.toolCallId === 'context-0')
          const visible = error?.content.filter(block => block.type === 'text').map(block => block.text).join('\n')
          assert(error && visible.includes('FIXTURE_UNKNOWN_PARAMETER'),'original actionable tool error must remain visible')
          assert(visible.length < largePayload.length,'the real DSH consumer must truncate the oversized result')
          for (const marker of ['"status":"rolled_back"','"parameter_state_restored":true','"success":true',
            '"effect_status":"unverified"','FIXTURE_PARAMETER_VALUES_AND_KEYS_ONLY',
            'FIXTURE_EFFECT_UNVERIFIED','FIXTURE_GEOMETRY_UNVERIFIED','houdini_resource']) {
            assert(visible.includes(marker),'critical recovery/check/detail information must survive DSH truncation: '+marker)
          }
          const canonical = ctx.sessions.get(options.sessionId).snapshotEvents().find(event =>
            event.type === 'tool/result' && event.data?.message?.source?.callId === 'context-0')?.data?.meta?.canonical
          assert.equal(canonical?.result?.payload,largePayload,'canonical result must remain lossless')
          assert.equal(canonical?.details?.stored,true,'the real runtime must retain details')
          assert(visible.includes(canonical.details.sha256),'provider must receive the actual retained detail reference')
          const retained = fs.readFileSync(canonical.details.path)
          assert.equal(createHash('sha256').update(retained).digest('hex'),canonical.details.sha256)
          assert.equal(JSON.parse(retained).result.payload,largePayload)
        }
        if (step === 3 || step === 4) {
          assert(current.includes('unknown_transport') && current.includes('houdini_request'),'uncertain execution needs recovery context')
          if (step === 4) assert.equal(snapshots.length,requests[3].snapshotCount,'unrelated observation must not repeat an unresolved notice')
        }
        if (step === 5 || step === 9) {
          assert(!current.includes('Houdini recorded execution state.'),'completed recovery/job must clear outstanding context')
        }
        if (step === 6 || step === 7 || step === 8) {
          assert(current.includes(jobId) && current.includes('houdini_job_status'),'active jobs must stay observable')
          if (step === 7) assert.equal(snapshots.length,requests[6].snapshotCount,'unrelated observation must not repeat an active job notice')
          if (step === 8) assert(current.includes('running'),'job state transition must reach provider')
        }
        if (outcomeReceipts && (step === 10 || step === 11)) {
          const name=step===10?'caught_read':'failed_check'
          const callId='context-'+(step-1)
          const expected=outcomeReceipts[name]
          const message=options.messages.find(message=>message.role==='tool' && message.toolCallId===callId)
          const visible=message?.content.filter(block=>block.type==='text').map(block=>block.text).join('\n')
          assert(visible.includes(JSON.stringify(expected.outcome)),'actual model input receives the Python outcome')
          assert.match(visible,name==='caught_read'?/Batch completed; one or more operations raised errors/:/checks failed or contain warnings/)
          assert.doesNotMatch(visible,/Executed successfully/)
          const canonical=ctx.sessions.get(options.sessionId).snapshotEvents().find(event=>
            event.type==='tool/result' && event.data?.message?.source?.callId===callId)?.data?.meta?.canonical
          assert.deepEqual(canonical.outcome,expected.outcome)
          assert.deepEqual(canonical.result,expected.result,'fallback and scoped validation are preserved')
          assert.equal(snapshots.length,requests[9].snapshotCount,'caught read/returned validation adds no duplicate scene snapshot')
        }
        if(step===expiryStart+2){
          assert(current.includes('running')&&current.includes(expiredJob),'admission expiry must retain genuinely running work')
          assert(current.includes('"unavailable_results":[]'),'running work is not an unavailable finished result')
        }
        if(step>=expiryStart+3){
          assert(current.includes('"active_jobs":[]')&&current.includes('finished_result_unavailable'),
            'the actual provider must receive terminal unavailable outcome without an active-job loop')
          assert(current.includes(expiredJob),'unavailable execution retains its job identity')
          const recoveredMessage=options.messages.find(m=>m.role==='tool'&&m.toolCallId==='context-'+(expiryStart+2))
          assert(recoveredMessage?.content.some(b=>b.type==='text'&&b.text.includes('Do not poll the missing job')),
            'the actual tool response must tell the provider not to poll or resubmit a pruned job')
          if(step===receiptStart)assert.equal(snapshots.length,requests[expiryStart+3].snapshotCount,'unrelated reads do not repeat expired-result context')
        }
        const currentEvents=ctx.sessions.get(options.sessionId).snapshotEvents()
        if(repetitionMethod && step>repetitionStart){
          const reference = options.messages.find(m=>m.role==='tool'&&m.toolCallId==='context-'+repetitionStart)
          const visible=reference?.content.filter(b=>b.type==='text').map(b=>b.text).join('\n').replaceAll('\r\n','\n')
          const section=methodText.split('### 重复规律与代码生成')[1].split('### 源构件与成形检查')[0]
          const relevant=section.split('\n').filter(line=>line.trim()&&!line.startsWith('```'))
          assert(relevant.every(line=>visible?.includes(line)), 'the actual provider must receive the shipped repetition method and exact VEX example')
          const componentSection=methodText.split('### 完整源组件与布局')[1].split('### 重复规律与代码生成')[0]
          assert(componentSection.split('\n').filter(line=>line.trim()).every(line=>visible?.includes(line)),
            'the actual provider must receive the complete component-source reference through the mounted read tool')
        }
        if(repetitionMethod && step===finalStep){
          const events=normalizeTraceSteps(currentEvents).steps.filter(s=>s.tool==='read')
          assert.equal(events.length,2+(surfaceMethod?surfaceResources.filter(r=>r.kind!=='skill').length:0),'native and nested on-demand reference reads both execute')
          assert(events.every(s=>!s.failed),'reference delivery cannot be inferred from configuration')
        }
        const nativeCatalog=currentEvents.find(e=>e.type==='tool/result'&&e.data?.message?.source?.callId==='context-'+catalogStart)?.data?.meta?.canonical
        if(catalogReceipt && step>catalogStart){
          assert.deepEqual(nativeCatalog.result,catalogReceipt.result,'native provider result preserves the selected catalog fields')
          if(catalogReceipt.result.conditions){
            const conditions=nativeCatalog.result.conditions
            assert.deepEqual(conditions,catalogReceipt.result.conditions,'native conditionals and bit-field settings are execution facts')
            const materialParameters=conditions.static.parameters
            assert(materialParameters.some(p=>p.name==='elementscale'&&p.conditionals?.HideWhen),'native parameter enablement must remain visible')
          }
          assert.deepEqual(nativeCatalog.verbs[0].result,catalogReceipt.verbs[0].result,'native canonical catalog stays typed and complete')
          const message=options.messages.find(m=>m.role==='tool'&&m.toolCallId==='context-'+catalogStart)
          const visible=message?.content.filter(b=>b.type==='text').map(b=>b.text).join('\n')
          assert(visible.includes('resolutiony')&&visible.includes('parameter_catalog')&&visible.includes('/verbs/0/result'))
          if(catalogReceipt.result.conditions)assert(visible.includes('HideWhen')&&visible.includes('toggle_strip'),
            'actual provider text retains native parameter conditions and strip semantics')
          for(const card of Object.values(catalogReceipt.result.surface_cards??{})){
            assert(card.usage_notes.every(note=>visible.includes(note)),
              'actual provider receives the current Boolean/PolyBevel operation knowledge')
          }
          if(catalogReceipt.result.interface_observation){
            assert(visible.includes('target_primitive_limit_exceeded')&&visible.includes('required_pairs')&&visible.includes('runtime_limits'),
              'actual provider receives capacity reasons and execution-owned limits without a fabricated geometric failure')
          }
          assert(!visible.includes('Full formatted result stored'),'selected catalog no longer triggers DSH spill')
          assert(visible.length<JSON.stringify(catalogReceipt.verbs[0].result).length/2,'full ledger does not undo Python selection')
        }
        if(catalogReceipt && step>catalogStart+1){
          const nested=currentEvents.find(e=>e.type==='tool/ptc-dispatch'&&e.data?.name==='houdini_inspect')
          const canonical=nested?.data?.content.map(b=>{try{return JSON.parse(b.text)}catch{return null}})
            .find(v=>v?.kind==='dsh-houdini/execution-v1')?.value
          assert.deepEqual(canonical?.result,catalogReceipt.result,'real PTC execution receives the selected result')
          assert.deepEqual(canonical?.verbs[0].result,catalogReceipt.verbs[0].result,'PTC durable catalog stays typed')
          const message=options.messages.find(m=>m.role==='tool'&&m.toolCallId==='context-'+(catalogStart+1))
          const visible=message?.content.filter(b=>b.type==='text').map(b=>b.text).join('\n')
          assert(visible.includes('resolutiony')&&!visible.includes('parameter_catalog'),'PTC returns only its selected value, not durable audit data')
          if(catalogReceipt.result.conditions)assert(visible.includes('HideWhen')&&visible.includes('toggle_strip'),
            'nested selected values retain parameter conditions and strip semantics at the actual provider')
          for(const card of Object.values(catalogReceipt.result.surface_cards??{})){
            assert(card.usage_notes.every(note=>visible.includes(note)),
              'nested selected values retain complete Boolean/PolyBevel operation knowledge')
          }
          if(catalogReceipt.result.interface_observation){
            assert(visible.includes('target_primitive_limit_exceeded')&&visible.includes('Increasing max_pairs cannot remove'),
              'nested selected results preserve the supported recovery action')
          }
        }
        if(catalogReceipt && step>catalogStart+2){
          const read=currentEvents.find(e=>e.type==='tool/result'&&e.data?.message?.source?.callId==='context-'+(catalogStart+2))?.data?.meta?.canonical
          assert.equal(JSON.parse(read.result.text),catalogReceipt.verbs[0].result.at(-1).name,'real resource tool resolves a nested catalog leaf')
        }
        if(catalogReceipt && step>catalogStart+3){
          const read=currentEvents.filter(e=>e.type==='tool/ptc-dispatch'&&e.data?.name==='houdini_resource').at(-1)
          const canonical=read?.data?.content.map(b=>{try{return JSON.parse(b.text)}catch{return null}})
            .find(v=>v?.kind==='dsh-houdini/execution-v1')?.value
          assert.equal(JSON.parse(canonical.result.text),catalogReceipt.verbs[0].result.at(-1).name,'PTC resource read resolves the same typed leaf')
        }
        if(catalogReceipt && step===finalStep){
          const processes=normalizeTraceSteps(currentEvents).steps.filter(s=>s.tool==='pwsh')
          assert.equal(processes.length,2,'real native and PTC shell calls both returned')
          assert(processes.every(s=>!s.failed&&s.processOutcome?.exitCode===7&&s.processOutcome?.status==='failed'),
            'actual DSH native/nested process exits remain separate from successful tool delivery')
        }
        const uncertain = ctx.sessions.get(options.sessionId).snapshotEvents()
          .find(event => event.type === 'tool/result' && event.data?.message?.source?.callId === 'context-2')
        const ref = uncertain?.data?.meta?.canonical?.requestReceipt?.request_ref
        const calls = [
          ['houdini_exec',{code:'fixture_sync_failure'}], ['houdini_exec',{code:'fixture_sync_success'}],
          ['houdini_exec',{code:'fixture_transport_unknown'}], ['houdini_inspect',{code:'fixture_unknown_observation'}],
          ['houdini_request',{request_ref:ref}], ['houdini_job_submit',{code:'fixture_long_work'}],
          ['houdini_inspect',{code:'fixture_job_observation'}], ['houdini_job_status',{jobId}], ['houdini_job_status',{jobId}],
          ...(outcomeReceipts ? [['houdini_inspect',{code:'fixture_outcome_caught_read'}],
            ['houdini_exec',{code:'fixture_outcome_failed_check'}]] : []),
          ['skill',{name:'houdini-sop-workflow'}],
          ['houdini_job_submit',{code:'fixture_expiring_work'}],
          ['houdini_request',{request_ref:expiryRef}],
          ['houdini_request',{request_ref:expiryRef}],
          ['houdini_inspect',{code:'fixture_after_expired_job'}],
          ...(catalogReceipt ? [
            ['houdini_inspect',{code:'fixture_catalog'}],
            ['run_code',{code:'const value = await tools.houdini_inspect({code:"fixture_catalog"}); return {selected:value.result};',description:'Inspect selected native parameter metadata'}],
            ['houdini_resource',{kind:'result',ref:nativeCatalog?.details?.sha256,pointer:'/verbs/0/result/'+(catalogReceipt.verbs[0].result.length-1)+'/name'}],
            ['run_code',{code:'const value = await tools.houdini_resource('+JSON.stringify({kind:'result',ref:nativeCatalog?.details?.sha256,pointer:'/verbs/0/result/'+(catalogReceipt.verbs[0].result.length-1)+'/name'})+'); return value.result;',description:'Read an archived parameter catalog leaf'}],
            ['pwsh',{command:"Write-Output 'process-outcome-fixture'; exit 7",description:'Exercise an isolated known process exit'}],
            ['run_code',{code:'return await tools.pwsh({command:"Write-Output \'process-outcome-fixture\'; exit 7",description:"Exercise nested known process exit"});',description:'Observe a shell process exit through PTC'}],
          ] : []),
          ...(repetitionMethod ? [
            ['read',{file_path:methodFile}],
            ['run_code',{code:'return await tools.read('+JSON.stringify({file_path:methodFile})+');',description:'Read the shipped repeated-layout method through the mounted tool'}],
          ] : []),
          ['skill',{name:'houdini-task-decomposition'}],
          ...(surfaceMethod ? surfaceResources.map(resource=>resource.kind==='skill'
            ? ['skill',{name:resource.name}]
            : resource.kind==='read' ? ['read',{file_path:resource.file}]
            : ['run_code',{code:'return await tools.read('+JSON.stringify({file_path:resource.file})+');',description:'Read the relevant surface method through the mounted tool'}]) : []),
          ['houdini_exec',{code:'fixture_busy_receipt'}],
          ['houdini_request',{request_ref:busyRef}],
          ['run_code',{code:'return await tools.houdini_request('+JSON.stringify({request_ref:busyRef})+');',description:'Read the same busy request through the nested tool'}],
          ['houdini_request',{request_ref:busyRef}],
          ['houdini_request',{request_ref:busyRef}],
        ]
        if (step === finalStep) { yield* textChunks('Context fixture completed.'); return }
        const [name,args] = calls[step]
        assert(options.tools.some(tool => tool.name === name),'tool must come from the actual preset: '+name)
        if (name === 'houdini_request') assert(ref,'uncertain result must retain the original request reference')
        yield {type:'block-start',index:0,blockType:'tool-call'}
        yield {type:'block-end',index:0,block:{type:'tool-call',id:'context-'+step,name,arguments:JSON.stringify(args)}}
        yield {type:'finish',reason:{kind:'tool-calls'}}
      } catch(error) {fail(error); throw error}
    }
  }
  ctx.llm.registerAdapter([provider],new ContextFixture())
  ctx.effect(() => {
    queueMicrotask(async () => {
      try {
        await ready
        await ctx.loader.await()
        const {sessionId} = await ctx.sessionController.create({cwd:path.dirname(output),agentPreset:'houdini'})
        await ctx.sessionController.selectModel({sessionId,provider,model})
        await ctx.sessionController.prompt({sessionId,requestId:randomUUID(),mode:'queue',
          content:[{type:'text',text:'Run the isolated Houdini execution context fixture.'}]},AbortSignal.timeout(60000))
        const agent = ctx.agents.get(sessionId)
        await agent.whenIdle()
        assert(!failure,failure)
        assert.equal(requests.length,finalStep+1,'real loop must complete all scripted phases')
        assert.equal(bridgeCalls.filter(call => call.path === '/context').length,1,'capture one scene per user message')
        await ctx.sessions.flush(agent.session)
        writeReport({ok:true,sessionId,provider,model,requests:requests.map(({messages,...row})=>row),
          bridgeCalls,events:agent.session.snapshotEvents()})
      } catch(error) {fail(error)}
    })
    return () => server.close()
  })
}
