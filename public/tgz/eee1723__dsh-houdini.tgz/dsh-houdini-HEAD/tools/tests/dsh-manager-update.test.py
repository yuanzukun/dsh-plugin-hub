"""Isolated hython regression for version state and safe activation."""

from __future__ import annotations

import json
import os
from pathlib import Path
import sys
import tempfile
import types
import hashlib


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "houdini" / "python3.11libs"))
import hou  # Bridge imports real toolutils/HOM; run with isolated hython.

import dsh_launcher as launcher
import dsh_manager as manager
import dsh_bridge as bridge


assert manager._PACKAGE_VERSION_RE.fullmatch("0.1.1-rc.2")
assert not manager._PACKAGE_VERSION_RE.fullmatch("0.1.1 && whoami")


# Streamed npm output yields a deterministic missing-package denominator and
# completed tarball numerator. Byte/s formatting is independent of Qt.
tracker = manager._NpmDownloadTracker()
tarballs = (
    "https://registry.example.test/foo/-/foo-1.0.0.tgz",
    "https://registry.example.test/bar/-/bar-2.0.0.tgz",
)
for url in tarballs:
    tracker.feed(f"npm silly tarball no local data for pkg@{url}. Extracting by manifest.")
tracker.feed(f"npm http fetch GET 200 {tarballs[0]} 125ms (cache miss)")
snapshot = tracker.snapshot()
assert snapshot["packages_done"] == 1 and snapshot["packages_total"] == 2, snapshot
assert snapshot["stage"] == "Downloading packages", snapshot
message = manager._download_progress_message({
    **snapshot,
    "bytes_downloaded": 3 * 1024 * 1024,
    "speed_bps": 1.5 * 1024 * 1024,
    "elapsed": 65,
})
assert "1/2 packages" in message and "3.0 MiB received" in message, message
assert "1.5 MiB/s" in message and "01:05" in message, message

with bridge._jobs_lock:
    original_jobs = dict(bridge._jobs)
    bridge._jobs.clear()
    bridge._jobs.update({
        "queued": {"status": "queued"},
        "running": {"status": "running"},
        "done": {"status": "done"},
    })
try:
    assert bridge._job_activity() == {"activeJobs": 2, "queuedJobs": 1, "runningJobs": 1}
finally:
    with bridge._jobs_lock:
        bridge._jobs.clear()
        bridge._jobs.update(original_jobs)


# Repair validates the required cached release, never promotes by modification time.
original_cache = manager._NPM_CACHE
try:
    with tempfile.TemporaryDirectory() as raw_cache:
        manager._NPM_CACHE = raw_cache
        npx_root = Path(raw_cache) / "_npx"
        target = manager.dsh_runtime_compat.preferred_version()
        for index, version in enumerate(("0.1.1-rc.2", target), start=1):
            package = npx_root / str(index) / "node_modules" / "@deepseek-ai" / "dsh"
            (package / "lib").mkdir(parents=True)
            (package / "package.json").write_text(
                json.dumps({"name": "@deepseek-ai/dsh", "version": version}), encoding="utf-8",
            )
            bin_path = package / "lib" / "bin.js"
            bin_path.write_text("// test", encoding="utf-8")
            os.utime(bin_path, (index, index))
            if version == target:
                definition = json.loads((ROOT / 'deployment/dsh-runtime-fixes/manifest.json').read_text(encoding='utf8'))
                paths = [f"node_modules/@deepseek-ai/dsh-{p['name']}/lib/{e}.js" for p in definition['hostPackages'] for e in p['entries']]
                paths += [f"node_modules/@deepseek-ai/dsh-{p['name']}/{a}" for p in definition['hostPackages'] for a in p.get('assets', [])]
                paths += [f"node_modules/@deepseek-ai/dsh-client-{name}/lib/client.js" for name in definition['clientPackages']]
                files = {}
                for relative in paths:
                    item = npx_root / str(index) / relative
                    item.parent.mkdir(parents=True, exist_ok=True)
                    item.write_text('// isolated inventory fixture', encoding='utf8')
                    files[relative] = hashlib.sha256(item.read_bytes()).hexdigest()
                (npx_root / str(index) / '.dsh-runtime-fixes.json').write_text(json.dumps({
                    'schemaVersion':1, 'revision':definition['revision'], 'dshVersion':version,
                    'patchSha256':definition['patchSha256'], 'files':files}), encoding='utf8')

        assert manager._selected_cached_dsh_version() == target
        manager._require_cached_dsh(target)
        assert manager._selected_cached_dsh_version() == target
        # GUI metadata lookup stays cheap; the startup worker checks actual bytes.
        verified = manager.dsh_runtime_compat.runtime_fix_identity(bin_path, verify_files=True)
        assert verified['filesVerified']
        item.write_text('// tampered implementation', encoding='utf8')
        assert not manager.dsh_runtime_compat.runtime_fix_identity(bin_path)['filesVerified']
        try:
            manager._require_cached_dsh(target)
        except RuntimeError as exc:
            assert 'differs' in str(exc), exc
        else:
            raise AssertionError('startup accepted a changed runtime implementation')
        item.write_text('// isolated inventory fixture', encoding='utf8')
        proof_path = npx_root / '2' / '.dsh-runtime-fixes.json'
        proof = json.loads(proof_path.read_text(encoding='utf8'))
        missing = dict(proof, files={key:value for key,value in files.items() if key != relative})
        proof_path.write_text(json.dumps(missing), encoding='utf8')
        assert manager._selected_cached_dsh_version() is None, 'incomplete runtime inventory selected'
        proof_path.write_text(json.dumps(proof), encoding='utf8')
        try:
            manager._require_cached_dsh("0.1.1-rc.2")
        except RuntimeError as exc:
            assert "not compatibility-verified" in str(exc)
        else:
            raise AssertionError("unverified cached DSH must not be promoted")
finally:
    manager._NPM_CACHE = original_cache


# A matching old PID is not process ownership. Only our live native Job can
# authenticate that a runtime marker still describes the listening service.
original_runtime = manager._RUNTIME_STATE
original_port_open = manager._port_open
original_port_pid = manager._port_pid
original_owns_pid = manager.dsh_managed_runtime.owns_pid
try:
    with tempfile.TemporaryDirectory() as raw_dir:
        marker = Path(raw_dir) / "runtime.json"
        marker.write_text(json.dumps({"pid": 42, "version": "0.1.1-rc.2", "source": "test"}))
        manager._RUNTIME_STATE = str(marker)
        manager._port_open = lambda port: True
        manager._port_pid = lambda port: 42
        manager.dsh_managed_runtime.owns_pid = lambda pid: False
        info = manager._runtime_dsh_info()
        assert info["verified"] is False and info["version"] is None, info
        manager.dsh_managed_runtime.owns_pid = lambda pid: pid == 42
        info = manager._runtime_dsh_info()
        assert info["verified"] is True and info["version"] == "0.1.1-rc.2", info
        manager._port_pid = lambda port: 43
        info = manager._runtime_dsh_info()
        assert info["verified"] is False and info["version"] is None, info
finally:
    manager._RUNTIME_STATE = original_runtime
    manager._port_open = original_port_open
    manager._port_pid = original_port_pid
    manager.dsh_managed_runtime.owns_pid = original_owns_pid


assert manager._summary_for_state({"dsh_status": "current"}) == "运行环境与配套版本一致。"
assert "不同" in manager._summary_for_state({"dsh_status": "update"})
assert "管理" in manager._summary_for_state({"dsh_status": "blocked"})


originals = {
    "required": manager.dsh_runtime_compat.preferred_version,
    "selected": manager._selected_cached_dsh_version,
    "runtime": manager._runtime_dsh_info,
    "override": manager._dsh_launch_override,
    "port_open": manager._port_open,
    "rpc_wire": manager._dsh_rpc_wire,
    "http": manager._http_json,
    "run_npx": manager._prepare_source_dsh,
    "cached": manager._require_cached_dsh,
    "activity": manager._runtime_activity,
}
try:
    manager.dsh_runtime_compat.preferred_version = lambda: target
    manager._selected_cached_dsh_version = lambda: "0.1.6-alpha.1"
    manager._runtime_dsh_info = lambda: {
        "online": True, "verified": True, "version": "0.1.6-alpha.1", "note": "PID 42",
    }
    manager._dsh_launch_override = lambda: None
    def forbidden_process(*args, **kwargs):
        raise AssertionError("runtime diagnostics must not invoke package installation during a check")
    manager._port_open = lambda port: True
    state = {"busy": True}
    manager._check_updates(state)
    assert state["dsh_status"] == "update" and state["dsh_can_update"] is True, state
    assert not any(key.startswith("plugin_") for key in state), "release status belongs to installation UI"

    manager._selected_cached_dsh_version = lambda: target
    state = {"busy": True}
    manager._check_updates(state)
    assert state["dsh_status"] == "staged" and state["dsh_action"] == "Start required version", state
    manager._selected_cached_dsh_version = lambda: "0.1.6-alpha.1"

    manager.dsh_runtime_compat.preferred_version = lambda: "0.1.3-unverified"
    state = {"busy": True}
    manager._check_updates(state)
    assert state["dsh_status"] == "blocked" and state["dsh_can_update"] is False, state
    assert state["dsh_action"] == "Await compatibility", state
    manager.dsh_runtime_compat.preferred_version = lambda: target

    manager._dsh_launch_override = lambda: "DSH_HOUDINI_DSH_SPEC=@deepseek-ai/dsh@old"
    state = {"busy": True}
    manager._check_updates(state)
    assert state["dsh_status"] == "blocked" and state["dsh_can_update"] is False, state
    manager._dsh_launch_override = lambda: None

    # Both DSH turns and bridge jobs participate in the restart guard.
    manager._port_open = lambda port: True
    rpc_calls = []
    def runtime_sessions(method, payload):
        rpc_calls.append((method, payload))
        return {"items": [{"running": True}, {"running": False}]}
    manager._dsh_rpc_wire = runtime_sessions
    manager._http_json = lambda url, data=None, timeout=5: {"ok": True, "activeJobs": 2, "activeRequests": 0}
    activity = manager._runtime_activity()
    assert activity["safe"] is False
    assert activity["activeSessions"] == 1 and activity["activeJobs"] == 2, activity
    assert rpc_calls == [("session/list", {"args": {"_request": {}}})]

    # An unavailable or invalid activity read must never authorize a restart or
    # try another protocol, including the former dotted endpoint.
    for detail in ("over HTTP 404", "over HTTP 503", "gateway/bad-request", "transport failed"):
        rpc_calls.clear()
        def unavailable(method, payload):
            rpc_calls.append((method, payload))
            raise RuntimeError(detail)
        manager._dsh_rpc_wire = unavailable
        activity = manager._runtime_activity()
        assert not activity["safe"] and detail in activity["note"], activity
        assert rpc_calls == [("session/list", {"args": {"_request": {}}})]
    manager._dsh_rpc_wire = lambda method, payload: {"items": None}
    activity = manager._runtime_activity()
    assert not activity["safe"] and "items is not a list" in activity["note"], activity

    # A stopped Host can leave its foreground HOM queued/running. Read the
    # actual Registry count through the actual health projection before Repair.
    from unittest.mock import patch
    from dsh_requests import RequestRegistry
    registry = RequestRegistry('a' * 32)
    manager._dsh_rpc_wire = lambda method, payload: {'items': [{'running': False}]}
    health_handler = object.__new__(bridge._Handler)
    with patch.object(bridge, '_request_registry', registry), patch.dict(bridge._jobs, {}, clear=True):
        manager._http_json = lambda *args, **kwargs: health_handler._health()
        ticket = registry.issue('stopped-host')
        assert manager._runtime_activity()['safe'], 'unused ticket is not executing work'
        registry.reserve(ticket, 'stopped-host', {'code': 'x'})
        for status in ('queued', 'running'):
            if status == 'running': registry.running(ticket)
            activity = manager._runtime_activity()
            assert activity['activeRequests'] == 1 and activity['activeJobs'] == 0 and not activity['safe'], activity
            decision = {}
            manager._prepare_activation(decision, 'repair')
            assert decision['result'] == 'render' and 'deferred' in decision['message'], decision
        registry.complete(ticket, {'ok': True})
        assert manager._runtime_activity()['safe']
        decision = {}
        manager._prepare_activation(decision, 'repair')
        assert decision['result'] == 'activate'

    # Worker preflight can be stale by the time the GUI dispatches the restart.
    with patch.object(bridge, '_request_registry', registry), \
         patch.object(bridge, '_job_activity', return_value={'activeJobs':0}), \
         patch.object(bridge, 'stop', side_effect=AssertionError('active Bridge stopped')), \
         patch.object(launcher.importlib, 'reload', side_effect=AssertionError('active modules reloaded')):
        ticket=registry.issue('late-request')
        registry.reserve(ticket,'late-request',{'code':'x'})
        try:
            launcher.restart_bridge()
        except RuntimeError as error:
            assert 'arrived after preflight' in str(error),error
        else:
            raise AssertionError('late request did not prevent reload')
        registry.complete(ticket,{'ok':True})

    for invalid_health in ({}, {'ok': True, 'activeJobs': 0},
                           {'ok': False, 'activeJobs': 0, 'activeRequests': 0},
                           {'ok': True, 'activeJobs': 0, 'activeRequests': -1},
                           {'ok': True, 'activeJobs': 0, 'activeRequests': False},
                           {'ok': True, 'activeJobs': 0, 'activeRequests': '0'}):
        manager._http_json = lambda *args, **kwargs: invalid_health
        activity = manager._runtime_activity()
        assert not activity['safe'] and activity['activeRequests'] is None, activity
        decision = {}
        manager._prepare_activation(decision, 'repair')
        assert decision['result'] == 'render', 'missing/invalid activity is not idle'

    manager._runtime_activity = lambda: {"safe": False, "note": "1 session is running"}
    state = {}
    manager._stage_or_activate(state, "dsh", "Ready.")
    assert state["result"] == "render" and state["dsh_status"] == "staged", state
    # Explicit force repair delegates identity/HOM guards to launcher preflight;
    # an unresponsive or running DSH session must not prevent that guarded path.
    state = {}
    manager._prepare_activation(state, 'repair', force_frontend=True)
    assert state['result']=='activate' and state['activation']=='force-services',state
    state = {}
    manager._prepare_activation(state, 'dsh', force_frontend=True)
    assert state['result']=='render' and 'only available' in state['message'],state

    manager._runtime_activity = lambda: {"safe": True, "note": "Runtime is idle"}
    state = {}
    manager._stage_or_activate(state, "dsh", "Ready.")
    assert state["result"] == "activate" and state["activation"] == "services", state

    def fake_run_npx(version, on_progress=None):
        if on_progress is not None:
            on_progress({
                "stage": "Downloading packages",
                "packages_done": 2,
                "packages_total": 4,
                "bytes_downloaded": 1024,
                "speed_bps": 512,
                "elapsed": 2,
                "current": "fixture",
            })
        return version

    manager._prepare_source_dsh = fake_run_npx
    manager._require_cached_dsh = lambda version: None
    state = {"busy": True, "dsh_target": target}
    manager._update_dsh(state)
    assert state["result"] == "activate", state
    assert state["download_progress"] is None, state
    state = {"busy": True, "dsh_target": "0.1.1-rc.2"}
    manager._prepare_source_dsh = forbidden_process
    manager._update_dsh(state)
    assert state["result"] == "render" and state["dsh_status"] == "error", state
    assert "refresh" in state["message"], state
    state = {"dsh_target": "0.1.1-rc.2"}
    manager._prepare_activation(state, "dsh")
    assert state["result"] == "render" and "refresh" in state["message"], state
finally:
    manager.dsh_runtime_compat.preferred_version = originals["required"]
    manager._selected_cached_dsh_version = originals["selected"]
    manager._runtime_dsh_info = originals["runtime"]
    manager._dsh_launch_override = originals["override"]
    manager._port_open = originals["port_open"]
    manager._dsh_rpc_wire = originals["rpc_wire"]
    manager._http_json = originals["http"]
    manager._prepare_source_dsh = originals["run_npx"]
    manager._require_cached_dsh = originals["cached"]
    manager._runtime_activity = originals["activity"]


# Launcher marker is atomic data derived from the selected CLI package.
original_launcher_state = launcher.FRONTEND_RUNTIME_STATE
original_pending = dict(launcher._PENDING)
try:
    with tempfile.TemporaryDirectory() as raw_dir:
        package = Path(raw_dir) / "dsh"
        (package / "lib").mkdir(parents=True)
        (package / "package.json").write_text(json.dumps({"version": "9.9.9-test"}), encoding="utf-8")
        bin_path = package / "lib" / "bin.js"
        bin_path.write_text("// test", encoding="utf-8")
        launcher.FRONTEND_RUNTIME_STATE = str(Path(raw_dir) / "runtime.json")
        launcher._PENDING.clear()
        launcher._PENDING.update(frontend_bin=str(bin_path), frontend_source="test-cli")
        launcher._PENDING["frontend_version"] = launcher._dsh_version_for_bin(str(bin_path))
        launcher._write_frontend_runtime_state(1234)
        marker = json.loads(Path(launcher.FRONTEND_RUNTIME_STATE).read_text(encoding="utf-8"))
        assert marker["pid"] == 1234 and marker["version"] == "9.9.9-test", marker
        launcher._clear_frontend_runtime_state()
        assert not Path(launcher.FRONTEND_RUNTIME_STATE).exists()
finally:
    launcher.FRONTEND_RUNTIME_STATE = original_launcher_state
    launcher._PENDING.clear()
    launcher._PENDING.update(original_pending)


print("dsh manager update tests passed")
