import {fixturePresentation} from './fixture-presentation.mjs'
// Real persisted DSH session, ordinary browser prompt and native/nested tools. Scripted model only.
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {randomUUID} from 'node:crypto'
import {LlmAdapter} from '@deepseek-ai/dsh-llm'
import {setSandboxMode} from '@deepseek-ai/dsh-sandbox-policy'
import {literalData} from '../../lib/prompt-data.js'
export const inject=['loader','llm','sessions','agents','sessionController','sandboxPolicy','workspaceRegistry']
export function apply(ctx){
 const folder=process.env.DSH_RECOVERY_TEST_ROOT,phase=process.env.DSH_RECOVERY_PHASE,sessionId=process.env.DSH_RECOVERY_TASK
 const dirtyChoice=phase==='resume'?process.env.DSH_RECOVERY_DIRTY_CHOICE:''
 const originalChoice=phase==='resume'?process.env.DSH_RECOVERY_ORIGINAL_CHOICE:'',keepDirty=dirtyChoice==='keep'||originalChoice==='keep'
 const longWarning=phase==='resume'&&process.env.DSH_RECOVERY_LONG_WARNING==='1'
 const warningArchiveFailure=process.env.DSH_RECOVERY_WARNING_ARCHIVE_FAILURE==='1'
 const saveAs=process.env.DSH_RECOVERY_SAVE_AS==='1',cwd=saveAs?path.join(folder,'original'):folder
 const file=path.join(folder,saveAs?'saved-as/project.hip':'project.hip').replaceAll('\\','/'),output=path.join(folder,phase+'-result.json')
 const report=value=>fs.writeFileSync(output,JSON.stringify(value,null,2));let step=0,failure,modelStarted=false
 const text=function*(value){yield {type:'block-start',index:0,blockType:'text'};yield {type:'block-end',index:0,block:{type:'text',text:value}};yield {type:'finish',reason:{kind:'stop'}}}
 const historicalCode="__result__={'payload':'ARCHIVED_BEFORE_SAVE_AS-'*5000}"
 const calls=phase==='save'?[
  ...(saveAs?[
   ['houdini_inspect',{code:historicalCode}],
   ['run_code',{code:'return await tools.houdini_inspect('+JSON.stringify({code:historicalCode.replace('SAVE_AS','NESTED_SAVE_AS')})+');',description:'Retain nested historical details before Save As'}],
  ]:[]),
  ['houdini_exec',{code:`p=tab_create('/obj','geo',name='asset')\nn=tab_create(p,'box',name='source')\n__result__=scene_save_as(${JSON.stringify(file)},scene_info()['hip_path'],'User requested this isolated fixture destination')`}],
  ...(saveAs?[['write',{file_path:'continuation.txt',content:'The same conversation follows Save As.'}]]:[]),
  ['houdini_exec',{code:"set_parms('/obj/asset/source',{'sizex':3})\n__result__=hou.node('/obj/asset/source').parm('sizex').eval()"}],
 ]:[
  ['houdini_inspect',{code:"__result__={'size':hou.node('/obj/asset/source').parm('sizex').eval(),'owner':node_provenance('/obj/asset/source')}"}],
  ['run_code',{code:'return await tools.houdini_exec('+JSON.stringify({code:"set_parms('/obj/asset/source',{'sizex':2.5})\n__result__={'size':hou.node('/obj/asset/source').parm('sizex').eval(),'saved':scene_save()}"})+');',description:'Continue the recovered saved scene through a nested tool'}],
 ]
 class Driver extends LlmAdapter{
  async listModels(){return [{provider:'recovery-fixture',id:'scripted',name:'Recovery fixture',inputModalities:['text']}]}
  async resolveModel(provider,id){return {provider,id,name:'Recovery fixture',inputModalities:['text'],context:{contextWindow:300000}}}
  async *stream(options){
   if(options.purpose){yield*text('Recovery fixture');return}
   try{
    modelStarted=true
    const events=ctx.sessions.get(sessionId).snapshotEvents()
    if(saveAs&&(phase==='resume'||step>2)){
     assert.equal(path.resolve(ctx.sessions.get(sessionId).header.cwd).toLowerCase(),path.resolve(path.dirname(file)).toLowerCase(),'actual session cwd follows the saved HIP')
     if(phase==='save'&&step===3)assert(JSON.stringify(options).includes('Saved-as workspace fixture instructions.'),'next model request receives the new workspace instructions')
     const runtime=events.filter(e=>e.type==='user/message'&&e.data.source?.kind==='runtime-context').at(-1)
     const policy=runtime?.data.source.sections?.find(section=>section.name==='sandbox-policy')
     assert(JSON.stringify(policy??runtime).toLowerCase().includes('saved-as'),'model runtime context must use the relocated file policy immediately')
    }
    if(phase==='resume'&&step===0){
     if(saveAs){
      const original=events.find(e=>e.type==='tool/result'&&e.data.message.source?.callId==='save-0')?.data.meta.canonical
      const nested=events.find(e=>e.type==='tool/ptc-dispatch'&&e.data.name==='houdini_inspect')
      const nestedValue=nested?.data.content.map(x=>{try{return JSON.parse(x.text)}catch{return null}}).find(x=>x?.kind==='dsh-houdini/execution-v1')?.value
      for(const value of [original,nestedValue]){
       assert(value?.details?.stored,'actual original native/nested result was retained')
       assert(path.resolve(value.details.path).startsWith(path.resolve(cwd)+path.sep),'artifact stays in the original project directory')
       calls.unshift(['houdini_resource',{kind:'result',ref:value.details.sha256,pointer:'/result/payload',limit:1000}])
      }
     }
     assert(events.some(e=>e.type==='user/message'&&e.data.source?.kind==='user'
       &&e.data.content?.some(part=>part.type==='text'&&part.text==='继续')),
       'the resumed turn must originate from the actual browser composer')
     if(keepDirty){
      assert(!events.some(e=>e.type==='user/message'&&e.data.source?.sections?.some(s=>s.text.includes('"kind":"executor_recovery"'))),
        'keeping unsaved edits must not rebind or reload the scene')
      assert(events.some(e=>e.type==='user/message'&&e.data.source?.sections?.some(s=>s.name==='dsh-houdini:recovery-required'
        &&s.text.includes(originalChoice?'已保留当前工程':'已保留当前未保存内容'))),'the native keep choice must reach the model as the actual recovery outcome')
      yield*text('Fixture kept the unsaved scene and continued the conversation without live tools.');return
     }
     assert(events.some(e=>e.type==='user/message'&&e.data.source?.sections?.some(s=>s.name==='dsh-houdini:executor-binding'
       &&s.text.includes('"kind":"executor_recovery"'))),
       'automatic recovery must commit before the first model tool call')
     if(process.env.DSH_RECOVERY_EXPECT_WARNING==='1'){
      const binding=events.filter(e=>e.type==='user/message').flatMap(e=>e.data.source?.sections??[])
       .filter(s=>s.name==='dsh-houdini:executor-binding').at(-1)
      const value=JSON.parse(binding.text.slice(binding.text.indexOf('\n')+1))
      assert(value.load_warnings?.some(text=>text.includes('skysaturation')),'actual cross-version load warnings must reach the same resumed model step')
     }
     if(longWarning){
      const binding=events.filter(e=>e.type==='user/message').flatMap(e=>e.data.source?.sections??[])
       .filter(s=>s.name==='dsh-houdini:executor-binding').at(-1)
      const value=JSON.parse(binding.text.slice(binding.text.indexOf('\n')+1)),detail=value.load_warning_details
      assert(detail.truncated&&detail.original_chars>100000)
      assert(Buffer.byteLength(literalData(JSON.stringify(value.load_warnings)))<=4096)
      assert(!JSON.stringify(options).includes('MIDDLE_DIAGNOSTIC_MARKER'),'model receives no hidden original before reading the resource')
      if(warningArchiveFailure){assert.equal(detail.status,'unavailable');assert.equal(detail.stored,false);assert(!detail.sha256)}
      else{
       assert(detail.stored)
       const original=JSON.parse(fs.readFileSync(detail.path,'utf8')).result.load_warnings[0]
       const serialized=JSON.stringify(original,null,2),offset=serialized.indexOf('MIDDLE_DIAGNOSTIC_MARKER')
       assert(offset>4096)
       calls.unshift(['houdini_resource',{kind:'result',ref:detail.sha256,pointer:'/result/load_warnings/0',offset,limit:1000}])
      }
     }
    }
    if(step){
     const result=events.find(e=>e.type==='tool/result'&&e.data?.message?.source?.callId===phase+'-'+(step-1))
     assert(result&&!result.data.message.isError,JSON.stringify(result))
     if(phase==='resume'&&calls[step-1][0]==='houdini_resource'){
      const page=result.data.meta.canonical.result.text
      assert(page.includes(saveAs?'ARCHIVED_BEFORE_':'MIDDLE_DIAGNOSTIC_MARKER'),'existing tool retrieves original details after directory/process changes without HOM execution')
     }
     if(phase==='resume'&&calls[step-1][0]==='houdini_inspect'){
      const value=result.data.meta.canonical;assert(value.ok,JSON.stringify(value));assert.equal(value.result.size,1,'unsaved old progress must not masquerade as saved')
      assert.equal(value.result.owner.status,'owned_current_session');assert.equal(value.execution.executor_id,process.env.DSH_HOUDINI_EXECUTOR_ID)
      if(longWarning){assert(!Object.hasOwn(value.execution.scene_recovery,'load_warnings'));assert.equal(value.execution.scene_recovery.load_warning_details.status,warningArchiveFailure?'unavailable':'stored')}
     }
    }
    if(step===calls.length){yield*text(phase==='resume'?'Fixture resumed through the normal conversation.':'Fixture complete');return}
    presentation.after(phase+'-'+step,calls[step+1]?.[0])
    const [name,args]=calls[step],id=phase+'-'+step++
    assert(options.tools.some(t=>t.name===name),name)
    yield {type:'block-start',index:0,blockType:'tool-call'}
    yield {type:'block-end',index:0,block:{type:'tool-call',id,name,arguments:JSON.stringify(args)}}
    yield {type:'finish',reason:{kind:'tool-calls'}}
   }catch(error){failure=String(error.stack||error);report({ok:false,error:failure});throw error}
  }
 }
 ctx.llm.registerAdapter(['recovery-fixture'],new Driver())
 const presentation=fixturePresentation(ctx)
 ctx.effect(()=>{queueMicrotask(async()=>{
  try{
   await ctx.loader.await()
   if(phase==='save'){
    const workspace=await ctx.workspaceRegistry.create(cwd)
    await ctx.sessionController.create({sessionId,workspaceId:workspace.id,agentPreset:'houdini'})
    setSandboxMode(ctx.sessions.get(sessionId),'workspace-write')
    await ctx.sessionController.selectModel({sessionId,provider:'recovery-fixture',model:'scripted'})
    if(saveAs){
     fs.writeFileSync(path.join(folder,'save-ready.json'),JSON.stringify({sessionId}))
     const deadline=Date.now()+90000
     while(!modelStarted&&!failure){assert(Date.now()<deadline,'Save As browser prompt timeout');await new Promise(r=>setTimeout(r,100))}
    }
   }else{
    await ctx.sessionController.resolveAgent(sessionId)
    assert.equal(step,0,'opening a saved task must not run a model turn')
    fs.writeFileSync(path.join(folder,'resume-ready.json'),JSON.stringify({sessionId}))
    const deadline=Date.now()+90000
    while(!modelStarted&&!failure){assert(Date.now()<deadline,'ordinary browser prompt timeout');await new Promise(r=>setTimeout(r,100))}
   }
   if(phase==='save'&&!saveAs)await ctx.sessionController.prompt({sessionId,requestId:randomUUID(),mode:'queue',content:[{type:'text',text:'Build, save, then make an unsaved fixture change.'}]},AbortSignal.timeout(90000))
   const agent=ctx.agents.get(sessionId);await agent.whenIdle();assert(!failure,failure);assert.equal(step,keepDirty?0:calls.length)
   if(saveAs){assert(fs.existsSync(path.join(path.dirname(file),'continuation.txt')));assert(!fs.existsSync(path.join(cwd,'continuation.txt')))}
   assert(await ctx.sessions.flush(agent.session))
   const events=agent.session.snapshotEvents()
   const receipts=events.filter(e=>e.type==='tool/result').map(e=>e.data.meta?.canonical).filter(Boolean)
   if(keepDirty){
    assert.equal(events.filter(e=>e.type==='tool/call'&&e.data.callId.startsWith('resume-')).length,0)
    assert.equal(events.filter(e=>e.type==='user/message'&&e.data.source?.sections?.some(s=>s.text.includes('"kind":"executor_recovery"'))).length,0)
   }else if(phase==='resume'){
    const nested=events.filter(e=>e.type==='tool/ptc-dispatch'&&e.data.name==='houdini_exec').at(-1)
    const result=nested?.data.content.map(x=>{try{return JSON.parse(x.text)}catch{return null}}).find(x=>x?.kind==='dsh-houdini/execution-v1')?.value
    assert(result?.ok,JSON.stringify(nested));assert.equal(result.result.size,2.5)
    assert.equal(result.execution.owner_session,sessionId);assert.equal(result.execution.executor_id,process.env.DSH_HOUDINI_EXECUTOR_ID)
    assert.equal(events.filter(e=>e.type==='user/message'&&e.data.source?.sections?.some(s=>s.text.includes('"kind":"executor_recovery"'))).length,1)
   }
   report({ok:true,sessionId,phase,dirtyChoice,receipts,boundary:'Real persisted DSH, ordinary browser continuation, automatic recovery or native conversation choice, real HOM; scripted model, no autonomous quality claim.'})
  }catch(error){report({ok:false,error:String(error.stack||error)})}
 })})
}
