import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import http from 'node:http'
import {pathToFileURL,fileURLToPath} from 'node:url'
import {Context} from '@deepseek-ai/cordis'
import {Session} from '@deepseek-ai/dsh-session'
import {SessionProjectionRegistry} from '@deepseek-ai/dsh-session-projection'
import {agentPresetProjectionDefinition} from '@deepseek-ai/dsh-agent-preset-registry'
import {remoteMethods} from '@deepseek-ai/dsh-typert-protocol'
import {ExecutorDirectory,ExecutorRouter} from '../../lib/executor-routing.js'
import {ExecutorController} from '../../lib/executor-controller.js'
import {registerExecutorIdentityProjection} from '../../lib/executor-identity-projection.js'
import * as executorHost from '../../lib/executor-host.js'
import {ExecutorBinding,recordedExecutorIdentity} from '../../lib/executor-binding.js'
import {registerHoudiniTools} from '../../lib/tools.js'
import {EXPECTED_EXECUTION_CONTRACT_VERSION as version,EXPECTED_VERB_CATALOG_HASH as hash} from '../../lib/generated-verb-contract.js'

const directory=await fs.mkdtemp(path.join(os.tmpdir(),'dsh-routing-'))
const endpoints=path.join(directory,'endpoints')
await fs.mkdir(endpoints)
const servers=[],records=[],agents=[],calls=[],flushed=[]
const write=r=>fs.writeFile(path.join(endpoints,r.executor_id+'.json'),JSON.stringify(r))
const routeCounts=[{},{}]
try {
  for(let i=0;i<2;i++) {
    const id=String(i+1).repeat(32),runtime=String(i+3).repeat(32),task='task-'+i
    const session=Session.create(task,[],{version:4,id:task,createdAt:1,isSeeded:false,agentPreset:'houdini'})
    agents.push({id:task,status:'idle',session})
    const server=http.createServer(async(req,res)=>{
      res.setHeader('content-type','application/json')
      routeCounts[i][req.url]=(routeCounts[i][req.url]||0)+1
      if(req.headers['x-dsh-houdini-executor']!==id){res.writeHead(409);res.end('{}');return}
      let text='';for await(const chunk of req)text+=chunk
      const body=text?JSON.parse(text):{}
      if(req.url==='/health'||req.url==='/requests/prepare'){
        res.end(JSON.stringify({ok:true,executorId:id,houVersion:i?'22.0.368':'21.0.440',runtimeId:runtime,
          executionContractVersion:version,verbCatalog:{hash},requestRef:runtime+'.'+'a'.repeat(32)}));return
      }
      if(req.url==='/exec'||req.url==='/jobs') {
        assert.equal(body.owner_session,task,'a shared tool instance sent the other task to this Bridge')
      }
      if(req.url==='/jobs') {
        assert.equal(body.owner_call,'submit-'+i,'job admission carries the submit call callId')
        assert.deepEqual(body.expected_contract,{version,hash},'job admission carries the expected contract')
      }
      if(req.url==='/jobs/'+String(i).repeat(12)+'/status') {
        assert.equal(body.owner_session,task,'job status must carry the owning session')
        assert.equal(body.owner_call,'status-'+i,'job status carries THIS call, not a cached submit callId')
        assert.deepEqual(body.expected_contract,{version,hash},'job status carries the expected contract')
      }
      if(req.url==='/jobs/'+String(i).repeat(12)+'/cancel') {
        assert.equal(body.owner_session,task,'job cancel must carry the owning session')
        assert.equal(body.owner_call,'cancel-'+i,'job cancel carries THIS call, not a cached submit callId')
        assert.deepEqual(body.expected_contract,{version,hash},'job cancel carries the expected contract')
      }
      calls.push([task,req.url])
      // Force interleaving so a mutable global target would send the wrong task.
      await new Promise(resolve=>setTimeout(resolve,i?1:15))
      res.end(JSON.stringify({ok:true,stdout:'',stderr:'',result:{target:id},jobId:String(i).repeat(12),status:'done',
        requestReceipt:{request_ref:runtime+'.'+'a'.repeat(32),runtime_id:runtime,status:'done'}}))
    })
    servers.push(server)
    await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve))
    const record={schema:1,executor_id:id,registration_id:String(i+5).repeat(32),runtime_id:runtime,
      installation:directory,bridge_url:`http://127.0.0.1:${server.address().port}`,
      houdini_version:i?'22.0.368':'21.0.440',pid:100+i,state:'registered',task_id:task,hip_path:path.join(directory,task+'.hip')}
    records.push(record);await write(record)
  }
  const flush=async s=>{flushed.push(s.id);return true}
  const identityOf=session=>recordedExecutorIdentity(session.snapshotEvents())
  const router=new ExecutorRouter(new ExecutorDirectory(directory,directory),1000,
    new ExecutorBinding(),identityOf)
  assert.equal((await router.directory.list()).length,2,
    'the exact configured installation must retain its registry records')
  const ctx=new Context()
  const projections=new SessionProjectionRegistry(ctx)
  projections.register(agentPresetProjectionDefinition)
  registerExecutorIdentityProjection(ctx)
  ctx.provide('agents',{get:id=>agents.find(a=>a.id===id)})
  const controller=new ExecutorController(ctx,router)
  assert.equal(projections.stateOf(agents[0].session,'agentPreset'),'houdini')
  const different=Session.create('not-houdini',[],{version:4,id:'not-houdini',createdAt:1,
    isSeeded:false,agentPreset:'houdini'})
  different.append('agent-preset/selected',{agentPreset:'standard'})
  agents.push({id:'not-houdini',status:'idle',session:different})
  await assert.rejects(controller.select({sessionId:'not-houdini',executorId:records[0].executor_id,
    registrationId:records[0].registration_id,expectedHip:records[0].hip_path},
    new AbortController().signal),/restricted to Houdini tasks/)
  agents.pop()
  assert.deepEqual(remoteMethods(controller).map(m=>m.method),['list','select'])
  assert.equal(controller.typertRemote.namespace,'houdiniTargets')
  const legacyList=await controller.list(undefined)
  assert.equal(legacyList.candidates.length,2)
  assert.equal(legacyList.recovery.status,'session_required')
  const initialList=await controller.list({sessionId:agents[0].id})
  assert.equal(initialList.candidates.length,2)
  assert.equal(initialList.recovery.status,'unbound')
  assert(initialList.candidates.every(r=>r.binding_status==='not_confirmed'))
  let gateway
  if(process.env.DSH_TEST_GATEWAY_ROOT) {
    const modules=process.env.DSH_TEST_GATEWAY_ROOT
    const {default:Registry}=await import(pathToFileURL(path.join(modules,'dsh-typert-registry/lib/index.js')))
    const {default:Gateway}=await import(pathToFileURL(path.join(modules,'dsh-api-gateway/lib/index.js')))
    new Registry(ctx)
    gateway=new Gateway(ctx,{websocketHeartbeatIntervalMs:2000})
    assert.equal((await gateway.invoke({namespace:'houdiniTargets',method:'list',args:{input:{sessionId:agents[0].id}}})).candidates.length,2)
  }
  const context=(i,op)=>({agent:agents[i],callId:(op||'call')+'-'+i})
  await assert.rejects(controller.select({sessionId:agents[0].id,executorId:records[0].executor_id,
    registrationId:records[0].registration_id,expectedHip:path.join(directory,'wrong.hip')},new AbortController().signal),/HIP changed/)
  await assert.rejects(router.resolve(context(0)),/Choose a Houdini/)
  await assert.rejects(router.sceneContextFor(agents[0].session),/No Houdini target/)
  await assert.rejects(router.selectInitial(agents[0],records[1].executor_id,records[1].registration_id),/writer reservation/)
  await assert.rejects(router.selectInitial(agents[0],records[0].executor_id,'stale'),/stale/)
  agents[0].status='running'
  await assert.rejects(router.selectInitial(agents[0],records[0].executor_id,records[0].registration_id),/idle/)
  agents[0].status='idle'
  for(let i=0;i<2;i++) {
    const input={sessionId:agents[i].id,executorId:records[i].executor_id,registrationId:records[i].registration_id,expectedHip:records[i].hip_path}
    if(gateway) await gateway.invoke({namespace:'houdiniTargets',method:'select',args:{input},signal:new AbortController().signal})
    else await controller.select(input,new AbortController().signal)
  }
  if(gateway) console.log('Real DSH Typert Gateway list/select dispatch passed')
  assert.equal(recordedExecutorIdentity(agents[0].session.snapshotEvents()),records[0].executor_id)
  const boundList=await controller.list({sessionId:agents[0].id})
  assert.equal(boundList.recovery.status,'bound_available')
  assert(boundList.candidates.every(r=>r.binding_status==='bound'))
  await assert.rejects(router.selectInitial(agents[0],records[1].executor_id,records[1].registration_id),/recovery/)
  const defs=new Map()
  registerHoudiniTools({on(){},tools:{register:d=>defs.set(d.name,d)}},router)
  const values=await Promise.all([0,1].map(i=>defs.get('houdini_exec').execute({code:'pass'},context(i,'exec'))))
  assert.deepEqual(values.map(v=>v.result.target),records.map(r=>r.executor_id))
  await Promise.all([0,1].map(i=>defs.get('houdini_job_submit').execute({code:'pass'},context(i,'submit'))))
  await Promise.all([0,1].map(i=>defs.get('houdini_job_status').execute({jobId:String(i).repeat(12)},context(i,'status'))))
  await Promise.all([0,1].map(i=>defs.get('houdini_job_cancel').execute({jobId:String(i).repeat(12)},context(i,'cancel'))))
  assert(calls.some(c=>c[0]==='task-0'&&c[1]==='/jobs/000000000000/cancel'))
  assert(calls.some(c=>c[0]==='task-1'&&c[1]==='/jobs/111111111111/cancel'))
  // Route-count proof: every job-control branch was actually reached exactly
  // once per session, and job control prepared no execution tickets.
  for(let i=0;i<2;i++) {
    const jid=String(i).repeat(12)
    assert.equal(routeCounts[i]['/jobs/'+jid+'/status'],1,'job status route reached exactly once')
    assert.equal(routeCounts[i]['/jobs/'+jid+'/cancel'],1,'job cancel route reached exactly once')
    assert.equal(routeCounts[i]['/jobs'],1,'job admission route reached exactly once')
  }
  assert.equal(routeCounts[0]['/requests/prepare']+routeCounts[1]['/requests/prepare'],4,'exec+submit prepare tickets; job control prepares none')
  const before=calls.length
  // One Host-plane controller survives removal of either preset consumer.
  const hostContext=new Context()
  const hostProjections=new SessionProjectionRegistry(hostContext)
  hostProjections.register(agentPresetProjectionDefinition)
  hostContext.provide('agents',{get:id=>agents.find(a=>a.id===id)})
  hostContext.provide('sessions',{flush})
  // Fixture installation must be the actual candidate root used by Host apply.
  const candidateRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..')
  for(const record of records) await write({...record,installation:candidateRoot})
  let host=await hostContext.plugin(executorHost,{executorRegistry:directory,requestTimeoutMs:1000})
  const controller1=hostContext.get('houdiniTargets')
  assert(controller1)
  assert.throws(()=>executorHost.apply(hostContext,{executorRegistry:directory,requestTimeoutMs:1000}),/already mounted/)
  await assert.rejects(async()=>executorHost.sharedExecutorConnection(hostContext,path.join(directory,'other')).resolve(context(0)),/configuration differs/)
  let consumerA,consumerB
  const presetA=await hostContext.plugin({apply(c){consumerA=executorHost.sharedExecutorConnection(c,directory)}})
  const presetB=await hostContext.plugin({apply(c){consumerB=executorHost.sharedExecutorConnection(c,directory)}})
  const stateOf=hostProjections.stateOf
  let identityReads=0
  hostProjections.stateOf=function(session,key){
    if(key==='houdiniExecutorIdentity'){
      identityReads++
      throw new Error('fixture projection conflict')
    }
    return stateOf.call(this,session,key)
  }
  const beforeRejectedRoute=JSON.stringify(routeCounts)
  await assert.rejects(consumerB.resolve(context(1)),/fixture projection conflict/)
  await assert.rejects(controller1.select({sessionId:agents[0].id,executorId:records[0].executor_id,
    registrationId:records[0].registration_id,expectedHip:records[0].hip_path},
    new AbortController().signal),/fixture projection conflict/)
  await assert.rejects(controller1.getRouter(directory).sceneContextFor(agents[0].session),/fixture projection conflict/)
  assert.equal(JSON.stringify(routeCounts),beforeRejectedRoute,'projection conflict must precede Bridge traffic')
  hostProjections.stateOf=stateOf
  const oldBridge=await consumerB.resolve(context(1))
  assert(identityReads>0,'Host router must consume the registered identity projection')
  await presetA.dispose()
  assert.equal(hostContext.get('houdiniTargets').typertRemote.namespace,'houdiniTargets')
  await host.dispose()
  assert.equal(hostProjections.stateOf(agents[0].session,'houdiniExecutorIdentity'),undefined)
  await assert.rejects(async()=>consumerB.resolve(context(1)),/unavailable/)
  await assert.rejects(oldBridge.exec('pass',{sessionId:agents[1].id,callId:'old'}),/unloaded|aborted/)
  assert.equal(calls.length,before,'unloaded service cannot dispatch through a retained Bridge')
  host=await hostContext.plugin(executorHost,{executorRegistry:directory,requestTimeoutMs:1000})
  assert.equal(hostContext.get('houdiniTargets').typertRemote.namespace,'houdiniTargets')
  assert.equal(hostProjections.stateOf(agents[0].session,'houdiniExecutorIdentity').identity,records[0].executor_id)
  await consumerB.resolve(context(1))
  await presetB.dispose();await host.dispose()
  for(const record of records) await write(record)
  await write({...records[0],state:'disconnected'})
  await assert.rejects(defs.get('houdini_exec').execute({code:'pass'},context(0)),/disconnected/)
  assert.equal(calls.length,before)
  assert.equal((await defs.get('houdini_exec').execute({code:'pass'},context(1))).result.target,records[1].executor_id)
  await write({...records[0],bridge_url:'http://example.com:8765'})
  await assert.rejects(router.directory.list(),/Invalid executor record/)
  await write({...records[0],runtime_id:'f'.repeat(32)})
  await assert.rejects(router.resolve(context(0)),/generation changed/)
  await write({...records[0],task_id:null,hip_path:null})
  await assert.rejects(router.resolve(context(0)),/writer reservation/)
  // Normal process retirement preserves recovery evidence without exhausting
  // discovery or making each bound tool enumerate the entire registry history.
  const retired=Array.from({length:256},(_,index)=>({...records[1],
    executor_id:index.toString(16).padStart(32,'0'),state:'disconnected'}))
  await Promise.all(retired.map(write))
  const withHistory=await router.directory.list()
  assert.equal(withHistory.length,258)
  assert.equal(withHistory.filter(r=>r.state==='disconnected').length,256)
  assert.equal((await router.directory.find(records[1].executor_id)).executor_id,records[1].executor_id)
  await assert.rejects(router.directory.find(retired[0].executor_id),/disconnected/)
  const foreign={...records[1],executor_id:'e'.repeat(32),installation:path.join(directory,'other-install')}
  await write(foreign)
  await assert.rejects(router.directory.find(foreign.executor_id),/disconnected or absent/)
  assert.equal((await router.directory.list()).length,258)
  const malformed='f'.repeat(32)
  const malformedFile=path.join(endpoints,malformed+'.json')
  await fs.writeFile(malformedFile,'{}')
  assert.equal((await router.directory.find(records[1].executor_id)).executor_id,records[1].executor_id,
    'unrelated malformed history cannot redirect or block an already bound target')
  await assert.rejects(router.directory.find(malformed),/Invalid executor record/)
  await assert.rejects(router.directory.list(),/Invalid executor record/)
  await fs.unlink(malformedFile)
  await assert.rejects(router.directory.find('../outside'),/Invalid executor identity/)
  await fs.symlink(directory,malformedFile,process.platform==='win32'?'junction':'dir')
  await assert.rejects(router.directory.find(malformed),/Invalid executor record path\/size/)
  await fs.unlink(malformedFile)
  await Promise.all(retired.map(record=>write({...record,state:'registered'})))
  await assert.rejects(router.directory.list(),/Registered executor discovery budget exceeded/)
  assert.equal((await router.directory.find(records[1].executor_id)).executor_id,records[1].executor_id,
    'discovery capacity cannot block an existing bound identity')
  console.log('shared executor routing: explicit selection, concurrent tools, job isolation, disconnect and fail-closed discovery passed')
}finally{
  await Promise.all(servers.map(s=>new Promise(resolve=>s.close(resolve))))
  await fs.rm(directory,{recursive:true,force:true})
}
