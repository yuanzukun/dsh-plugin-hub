"""Disposable H21/H22 regression: explicit outputs, bounded evidence and paths."""

from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'houdini/python3.11libs'))
import dsh_media_output
import dsh_ownership
import dsh_render
import hou
import dsh_hou_helpers as h
import dsh_bridge as bridge


def reject(fn, expected):
    try:
        fn()
    except Exception as error:
        assert expected in str(error), str(error)
        return
    raise AssertionError('expected failure: ' + expected)


root = hou.node('/obj').createNode('geo', '__checkpoint_test')
try:
    source = root.createNode('box', 'source')
    ctrl = root.createNode('null', 'CONTROLS'); ctrl.setDisplayFlag(True)
    out = root.createNode('null', 'OUT'); out.setInput(0, source)
    reject(lambda: h.verify_network(root), 'output')
    assert h.verify_network(root, output=out)['ok']
    reject(lambda: h.verify_network(root, output=ctrl), 'empty_output')
    diagnostic = h.verify_network(root, output=ctrl, require_valid=False)
    assert not diagnostic['ok'] and diagnostic['failure_reasons'] == ['empty_output']
    assert diagnostic['output'] == ctrl.path() and diagnostic['next_action']
    failed = bridge.run_code(f'verify_network({root.path()!r}, output={ctrl.path()!r})')
    assert not failed['ok'] and failed['evidence'][0]['failure_reasons']==['empty_output']
    assert failed['evidence'][0]['output']==ctrl.path()

    subnet = root.createNode('subnet', 'module')
    child = subnet.createNode('null', 'consumer')
    reject(lambda: h.connect(source, child, 1), 'different_parent')
    assert not child.inputs()
    reject(lambda: h.tab_create(subnet, 'xform', 'bad', inputs=[source]), 'different_parent')
    assert subnet.node('bad') is None
    local= subnet.createNode('object_merge','imported')
    h.set_parms(local, {'objpath1':source.path(),'xformtype':'none'})
    h.connect(local,child)
    assert child.geometry().intrinsicValue('pointcount')==8

    # Sparse secondary-input geometry is a normal Wrangle pattern, not a reason
    # to avoid the module constructor. An explicit port map avoids dummy nodes.
    specs = [
        {'name':'lookup', 'type':'attribwrangle', 'parms':{'class':'detail',
          'snippet':'vector p = point(1, "P", 0); addpoint(0, p);'},
         'inputs':[None, 'source']},
        {'name':'MODULE_OUT', 'type':'null', 'inputs':['lookup']},
    ]
    assert h.build_module(root, specs, output='MODULE_OUT', dry_run=True)['valid']
    built = h.build_module(root, specs, output='MODULE_OUT')
    assert built['validation']['geometry']['points'] == 1
    assert root.node('lookup').input(0) is None
    assert root.node('lookup').input(1) == source
    reject(lambda: h.build_module(root, [{'name':'badmenu','type':'attribwrangle',
        'parms':{'class':'not-valid'}}], output='badmenu', dry_run=True), 'menu')
    assert root.node('badmenu') is None

    sequence=root.createNode('attribwrangle','sequence')
    h.set_parms(sequence, {'class':'detail','snippet': 'float xs[]=array(0.,1.,2.,2.1,3.1); foreach(float x;xs) addpoint(0,set(x,0,0));'})
    spacing=h.geo_point_spacing(sequence,expected=1,tolerance=.001)
    assert not spacing['ok'] and spacing['pair_count']==4 and spacing['failure_count']==1
    assert spacing['failures'][0]['from_point']==2 and spacing['failures'][0]['to_point']==3
    assert spacing['coverage']=='all_adjacent_pairs'
    reject(lambda:h.geo_point_spacing(sequence,1,.001,max_points=3), 'no sampling')
    h.set_parms(sequence, {'snippet':'vector ps[]=array(set(0,0,0),set(1,0,0),set(1,1,0),set(0,1,0)); foreach(int i;vector p;ps) {int pt=addpoint(0,p);setpointattrib(0,"order",pt,i);} '})
    assert h.geo_point_spacing(sequence,1,.001,closed=True,order_attrib='order')['ok']
    reject(lambda:h.geo_point_spacing(sequence,1,.001,order_attrib='missing'), 'order_attrib')
    failed_check=bridge.run_code(f'__result__=geo_point_spacing({sequence.path()!r}, 2, 0.01, closed=True)',read_only=True)
    assert failed_check['ok'] and failed_check['checks'][0]['status']=='failed'
    assert failed_check['evidence'][0]['failure_count']==4

    # Missing evidence cannot become success simply because Python returned.
    missing = dsh_render._render_validation({'fresh':True, 'file_bytes':10, 'errors':[]}, {'error':'decode'}, False)
    assert not missing['ok'] and missing['pixel_status'] == 'failed'
    ledger=[]
    bridge._make_tracer('render_view', lambda:{**missing,'output':'Z:/test/render/a.png','frame':1,'check':{'error':'decode'}},ledger)()
    assert ledger[0]['check_status']=='failed' and ledger[0]['summary']['pixel_status']=='failed'
    hdr = dsh_render._render_validation({'fresh':True, 'file_bytes':10, 'errors':[]}, None, False, pixel_supported=False)
    assert hdr['ok'] and hdr['pixel_status'] == 'unverified'
    stale = dsh_render._render_validation({'fresh':True, 'file_bytes':10, 'errors':[]}, {'presentation':{}}, True)
    assert not stale['ok']
    artifact = {'purpose':'viewport_diagnostic','output_policy':'managed',
        'actual_path':'Z:/checks/run/a.png','hip_relative_path':'dsh-visual-checks/run/a.png',
        'managed_root':'Z:/checks/run','run_id':'run','capture_id':'a','frame':1}
    shot_summary = bridge._operation_summary('viewport_screenshot', {
        'ok':False,'path':artifact['actual_path'],'artifact':artifact,'frame':1,
        'fresh':True,'file_status':'passed','semantic_status':'unverified',
        'user_state_restored':False,'restore_errors':['frame: injected'],'errors':['restore failed']})
    assert all(shot_summary['artifact'][key]==value for key,value in artifact.items())
    assert shot_summary['artifact'] == artifact, 'summary must preserve missing fields rather than invent null facts'
    assert shot_summary['user_state_restored'] is False
    assert shot_summary['restore_errors']==['frame: injected']
    unresolved_artifact={**artifact,'reservation_retained':True}
    unresolved_summary=bridge._operation_summary('viewport_screenshot',{
        'ok':False,'path':artifact['actual_path'],'artifact':unresolved_artifact,
        'frame':1,'fresh':False,'file_status':'failed','semantic_status':'unverified',
        'capture_unresolved':True,'user_state_restored':True,'restore_errors':[],
        'errors':['injected post-dispatch failure']})
    assert unresolved_summary['capture_unresolved'] is True
    assert unresolved_summary['artifact']['reservation_retained'] is True
    assert not any(key.startswith('_reservation') for key in unresolved_summary['artifact'])
    explicit_null = bridge._operation_summary('viewport_screenshot', {
        'ok':True,'artifact':{**artifact,'reservation_retained':None}})
    assert explicit_null['artifact']['reservation_retained'] is None, 'explicit null remains a captured fact'
    ledger=[]
    bridge._make_tracer('verify_network',lambda: diagnostic,ledger)()
    assert ledger[0]['summary']['output'] == ctrl.path()
    assert ledger[0]['summary']['failure_reasons'] == ['empty_output']

    with tempfile.TemporaryDirectory(prefix='dsh-checkpoint-') as tmp:
        base=Path(tmp); hip=base/'project.hip'
        hou.hipFile.save(hip.as_posix())
        path=dsh_media_output._resolve_output_path('preview.$F4.png', frame=3, default_subdir='render')
        assert Path(path)==base/'render'/'preview.0003.png', path
        assert Path(dsh_media_output._resolve_output_path('render/preview.png', frame=1, default_subdir='render'))==base/'render'/'preview.png'
        assert Path(dsh_media_output._resolve_output_path('preview.png', frame=1)) == base/'dsh-render'/'preview.png'
        reject(lambda:dsh_media_output._resolve_output_path('../outside.png',frame=1,default_subdir='render'), 'outside')
        reject(lambda:dsh_media_output._resolve_output_path('no_extension',frame=1,default_subdir='render'), 'extension')
        reject(lambda:dsh_media_output._resolve_output_path(str(Path(__file__).resolve().parents[2]/'bad.png'),frame=1,default_subdir='render'), 'repository')
        with dsh_ownership.execution_owner('managed-checkpoint-session','capture'):
            managed, managed_artifact, _ = dsh_media_output._preview_artifact(
                '检查 图.$F4.png', frame=3, purpose='model_visual_verification',
                output_policy='managed', default_label='preview', default_subdir='render')
        assert Path(managed).parent.parent==base/'dsh-visual-checks'
        assert managed_artifact['output_policy']=='managed' and '0003' in Path(managed).name
        assert managed_artifact['role']=='visual_check' and Path(managed_artifact['project_root'])==base
        assert dsh_media_output._release_preview_reservation(managed_artifact)==[]
        explicit, explicit_artifact, _ = dsh_media_output._preview_artifact(
            (base/'delivery'/'preview.png').as_posix(), frame=3,
            purpose='model_visual_verification', output_policy='explicit',
            default_label='preview', default_subdir='render')
        assert Path(explicit)==base/'delivery'/'preview.png'
        assert explicit_artifact['managed_root'] is None
        assert explicit_artifact['role']=='visual_check' and explicit_artifact['lifecycle']=='visual-check'
        from dsh_project_paths import directory_path
        explicit_name, _, _ = dsh_media_output._preview_artifact(
            'current-ui.png', frame=3, purpose='existing_ui', output_policy='explicit',
            default_label='ui', default_subdir=directory_path('visual_check'))
        assert Path(explicit_name)==base/'dsh-visual-checks'/'current-ui.png'
        reject(lambda:dsh_media_output._preview_artifact('../bad.png',frame=1,purpose='test',
            output_policy='managed',default_label='x',default_subdir='render'),'basename')
        rop=hou.node('/out').createNode('geometry','__checkpoint_rop')
        try:
            rop.parm('soppath').set(source.path())
            old=rop.parm('sopoutput').unexpandedString()
            result=h.render_frame(rop,picture='cache.$F4.bgeo.sc',frame=3,timeout=5)
            assert Path(result['output'])==base/'dsh-cache'/'cache.0003.bgeo.sc', result
            assert Path(result['output']).exists() and result['fresh']
            assert rop.parm('sopoutput').unexpandedString()==old
            reject(lambda:h.render_frame(rop,picture='no_extension',frame=4), 'extension')
            assert rop.parm('sopoutput').unexpandedString()==old
        finally:rop.destroy()
        # Native image ROP routing is resolved before render/parameter writes;
        # stop at that boundary so this path check does not need a GUI renderer.
        image_rop=hou.node('/out').createNode('opengl','__checkpoint_image_rop')
        original_resolve=dsh_media_output._resolve_output_path
        resolved=[]
        class PathObserved(Exception): pass
        def observe_path(*args, **kwargs):
            resolved.append(original_resolve(*args, **kwargs))
            raise PathObserved('resolved before rendering')
        try:
            before=image_rop.parm('picture').unexpandedString()
            with patch.object(dsh_media_output,'_resolve_output_path',observe_path):
                reject(lambda:h.render_frame(image_rop,picture='beauty.$F4.png',frame=3),'resolved before rendering')
            assert Path(resolved[0])==base/'dsh-render'/'beauty.0003.png'
            assert image_rop.parm('picture').unexpandedString()==before
        finally:image_rop.destroy()
        # The native USD export ROP uses the same declared render directory
        # for a bare output; its existing explicit path remains untouched.
        usd_rop=hou.node('/out').createNode('usd','__checkpoint_usd_rop')
        try:
            before=usd_rop.parm('lopoutput').unexpandedString()
            with patch.object(dsh_media_output,'_resolve_output_path',observe_path):
                reject(lambda:h.render_frame(usd_rop,picture='stage.$F4.usd',frame=3),'resolved before rendering')
            assert Path(resolved[-1])==base/'dsh-render'/'stage.0003.usd'
            assert usd_rop.parm('lopoutput').unexpandedString()==before
        finally:usd_rop.destroy()
        # A tiny real COP export proves the distinct dependency default and
        # original node parameter restoration without creating a USD renderer.
        copnet=root.createNode('copnet','path_textures')
        layer=copnet.createNode('layer','value')
        h.set_parms(layer,{'setres':1,'resx':16,'resy':8,'f1':.5})
        image_rop=copnet.createNode('rop_image','export_value')
        h.set_parms(image_rop,{'coppath':layer.path(),'colorconversion':'raw','size1':'float32','raw1':1,'useport1':1,'port1':0})
        before=image_rop.parm('copoutput').unexpandedString()
        texture=h.render_frame(image_rop,picture='roughness.$F4.exr',frame=3,timeout=10)
        assert Path(texture['output'])==base/'dsh-texture'/'roughness.0003.exr'
        assert Path(texture['output']).is_file() and texture['fresh'] and texture['file_bytes']>0
        assert image_rop.parm('copoutput').unexpandedString()==before
finally:root.destroy()

print('explicit output/path/checkpoint regressions passed')
