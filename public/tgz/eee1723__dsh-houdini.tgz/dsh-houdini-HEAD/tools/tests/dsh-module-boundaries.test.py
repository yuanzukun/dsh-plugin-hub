"""Independent exec checkpoints survive later modules/discovery/integration failures."""

import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'houdini/python3.11libs'))
import dsh_ownership
import hou
import dsh_hou_helpers as h
import dsh_bridge as b

with dsh_ownership.execution_owner('boundary-owner','setup'):
    root=h.tab_create('/obj','geo','__module_boundaries')
try:
    def run(code, **options):
        return b.run_code(code,owner_session='boundary-owner',**options)
    def module(name):
        return f'build_module({root.path()!r},[{{"name":{name!r},"type":"box"}}],output={name!r})'
    first=run(module('module_a'))
    assert first['ok'] and first['transaction']['status']=='committed',first
    original=root.node('module_a')
    identity=original.sessionId()
    points=len(original.geometry().points())
    bad_query=run(f'list_parms({original.path()!r},filter="size")',read_only=True)
    assert not bad_query['ok'] and bad_query['transaction']['status']=='no_scene_change',bad_query
    assert bad_query['evidence'][0]['phase']=='argument_binding' and 'signature' in bad_query['evidence'][0]
    assert root.node('module_a').sessionId()==identity
    bad_module=f'build_module({root.path()!r},[{{"name":"bad","type":"attribwrangle","inputs":["module_a"],"parms":{{"snippet":"unknown_boundary_probe();"}}}}],output="bad")'
    failed=run(module('module_b')+'\n'+bad_module)
    assert not failed['ok'] and failed['transaction']['status']=='rolled_back',failed
    assert root.node('module_b') is None and root.node('bad') is None
    assert root.node('module_a').sessionId()==identity and len(original.geometry().points())==points
    # No heuristic partial commit for a supposedly harmless tail query.
    failed=run(module('module_c')+f'\nlist_parms({original.path()!r},filter="size")')
    assert not failed['ok'] and failed['transaction']['status']=='rolled_back',failed
    assert root.node('module_c') is None and root.node('module_a').sessionId()==identity
    assert run(module('module_b'))['ok']
    failed=run(f'build_module({root.path()!r},[{{"name":"join","type":"merge","inputs":["module_a","missing"]}}],output="join")')
    assert not failed['ok'] and root.node('join') is None
    assert root.node('module_a') is not None and root.node('module_b') is not None
    joined=run(f'build_module({root.path()!r},[{{"name":"join","type":"merge","inputs":["module_a","module_b"]}}],output="join")')
    assert joined['ok'] and len(root.node('join').geometry().prims())==12,joined
    # Binding errors are detected before dispatch; implementation TypeErrors
    # retain their actual traceback and are never labelled zero-write binding.
    for name, call in [('set_parms',f'set_parms({original.path()!r},{{"sizex":4}},filter="wrong")'),
                       ('node_info','node_info(type="box",context="sop")')]:
        failed=run(call)
        assert not failed['ok'] and failed['evidence'][0]['phase']=='argument_binding',failed
        assert failed['transaction']['status']=='no_scene_change',failed
    def internal_error(value):
        raise TypeError('inside implementation')
    ledger=[]
    try:
        b._make_tracer('set_parm',internal_error,ledger)(1)
    except TypeError:
        pass
    assert ledger[0]['error']=='inside implementation' and 'summary' not in ledger[0],ledger
    for name, mode, returned in [('tab_create','exec','Node'),('list_parms','query_or_exec','list'),('read_parms','query_or_exec','list')]:
        info=b._verb_help(name)
        assert info['call_mode']==mode and returned in info['return_type'],info
    # On-demand schemas describe real callable arguments. The successful Node
    # ledger snapshot is an observation; return a path explicitly for a later exec.
    import inspect
    import json
    source=json.loads((Path(__file__).resolve().parents[2]/'houdini/verb-operation-contracts.json').read_text(encoding='utf8'))
    for name, contract in source['verbs'].items():
        help_item=b._verb_help(name, detail='full')
        args=inspect.signature(b._VERBS[name]).parameters
        assert set(contract['input_schema']['properties'])<=set(args),(name,contract,args)
        assert help_item['operation_contract']['examples']==contract['examples'],name
        help_item['operation_contract']['examples'][0]['code']='changed consumer copy'
        assert b._verb_help(name, detail='full')['operation_contract']['examples'][0]['code']!='changed consumer copy',name
    documentation=b._verb_help('build_module', detail='full')['operation_contract']
    assert documentation['output_schema']['anyOf'][1]['required']==['valid','dry_run','parent','created','validation'],documentation
    discovered=run("__result__=verb_help(['build_module','tab_create','network_boxes'])",read_only=True)
    assert discovered['ok'] and discovered['verbs'][0]['result']==discovered['result'],discovered
    example=run("node=tab_create("+repr(root.path())+", 'null', name='path_example')\n__result__={'node_path':node.path()}")
    assert example['ok'] and example['result']['node_path']==root.path()+'/path_example',example
    assert example['verbs'][0]['result']=={'node':root.path()+'/path_example'},example
    batch=b._verb_help(['tab_create','read_parms'])
    assert batch['count']==2 and [item['name'] for item in batch['items']]==['tab_create','read_parms'],batch
    # Real test56 discovery requested 12 help records; default help should supply
    # executable callable facts without automatically attaching full schemas.
    names=['build_module','modeling_dimensions','create_spare_parms','tab_create',
           'verify_network','sop_recipe','geo_piece_stats','render_view','layout_nodes',
           'set_parms','test_controls','geo_check_interfaces']
    brief=b._verb_help(names)
    full=b._verb_help(names, detail='full')
    assert len(json.dumps(brief, ensure_ascii=False)) < len(json.dumps(full, ensure_ascii=False)) / 3
    for short, complete in zip(brief['items'], full['items']):
        assert short['detail']=='brief' and 'operation_contract' not in short,short
        assert complete['detail']=='full',complete
        for field in ('name','signature','return_type','call_mode'):
            assert short[field]==complete[field],(field,short,complete)
        followup=run('__result__='+short['full_help'], read_only=True)
        assert followup['ok'] and followup['result']==complete,followup
    assert b._verb_help('hda_set_interface')['doc'] != b._verb_help('hda_set_interface', detail='full')['doc']
    try:b._verb_help('build_module', detail='unknown')
    except ValueError as error:assert "detail='full'" in str(error)
    else:raise AssertionError('unknown help detail accepted')
    for bad in ([], ['tab_create','tab_create'], ['tab_create', 3], ['tab_create'] * 17):
        try:b._verb_help(bad)
        except ValueError:pass
        else:raise AssertionError('invalid verb_help batch accepted: '+repr(bad))
finally:
    root.destroy()
print('module checkpoint/discovery failure/integration retry/atomic rollback/signature discovery passed on '+hou.applicationVersionString())
