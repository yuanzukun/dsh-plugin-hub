import {
  isMutatingRawMethodName,
  mutatingRawMethodNames,
  parseVerbLedgerLine,
  rawMethodNames,
  processOutcomeFor,
} from '../skills/houdini-trace-analysis/scripts/evidence-helpers.mjs';
import { toolResultCallId, uniqueToolResultEvents } from './trace-session-lib.mjs';
import { executionResult, returnedExecutions, isHoudiniTool } from '../lib/dsh-adapter.js';
import { mergeRequestStatus, isPendingRequestStatus } from '../lib/execution-history.js';

function nestedResultContent(message) {
  return (message?.content || []).flatMap(item =>
    ['tool_result', 'tool-result'].includes(item?.type)
      ? nestedResultContent(item) : [item]);
}

export function toolResultText(message) {
  return nestedResultContent(message)
    .filter((item) => item?.type === 'text')
    .map((item) => String(item.text || ''))
    .join('\n');
}

export function parseToolArguments(value) {
  if (value && typeof value === 'object') return value;
  try {
    const parsed = JSON.parse(value || '{}');
    return parsed && typeof parsed === 'object' ? parsed : { _raw: String(value ?? '') };
  }
  catch { return { _raw: String(value ?? '') }; }
}

function parseJsonBlock(text, label) {
  const match = text.match(new RegExp(`${label}:\\n([\\s\\S]*?)(?:\\n\\n|$)`));
  if (!match) return null;
  try { return JSON.parse(match[1]); }
  catch { return { _raw: match[1] }; }
}

export function parseVerbLedger(text) {
  const match = text.match(/verbs \((\d+)\):\n([\s\S]*?)(?:\n\n|$)/);
  if (!match) return [];
  const evidence = parseJsonBlock(text, 'operation-evidence');
  return match[2].split('\n').flatMap((line) => {
    const parsed = parseVerbLedgerLine(line);
    if (!parsed) return [];
    let result = parsed.result;
    try { result = JSON.parse(parsed.result); } catch {}
    const summary = Array.isArray(evidence) ? evidence.find(e => e.ledgerIndex === parsed.ledgerIndex && e.verb === parsed.verb) : null;
    if (summary) {
      const {ledgerIndex, verb, ...facts} = summary;
      result = {...(result && typeof result === 'object' ? result : {}), ...facts};
    }
    return [{
      ledgerIndex: parsed.ledgerIndex,
      ok: parsed.ok,
      verb: parsed.verb,
      args: parsed.args,
      result,
      resultText: parsed.result,
      ms: parsed.ms,
    }];
  });
}

export function toolResultFailed(message, text = toolResultText(message), tool) {
  const deliveredError = Boolean(message?.isError || message?.content?.some((item) => item?.isError));
  if (deliveredError || processOutcomeFor(tool, text)) return deliveredError;
  return /^Execution failed\b/.test(text)
    || /\nExecution failed:/.test(text)
    || /^Error:/.test(text);
}

/** Present the latest same-runtime receipt using the live transition policy.
 * Nonterminal running/queued observations replace transport uncertainty.
 * A later successful unrelated query or an image file is not a receipt.
 */
export function unresolvedExecutionRequests(steps) {
  const observations = new Map();
  for (const step of steps) {
    const receipt = step.canonical?.requestReceipt ?? parseJsonBlock(step.resultText || '', 'request-receipt');
    if (!receipt?.request_ref || !receipt.runtime_id) continue;
    const key = JSON.stringify([receipt.runtime_id, receipt.request_ref]);
    const prior=observations.get(key);
    const status=mergeRequestStatus(prior?.status,receipt.status);
    observations.set(key,{index:step.index,time:step.time,tool:step.tool,
      request_ref:receipt.request_ref,runtime_id:receipt.runtime_id,status,
      scope:'last retained request observation, not current live state or completed execution outcome'});
  }
  return [...observations.values()].filter(row=>isPendingRequestStatus(row.status));
}

/**
 * Correlate tool calls with their first execution result and expose one stable,
 * consumer-neutral step shape. Compaction replays remain diagnostics and never
 * become a second step.
 */
export function normalizeTraceSteps(events) {
  const calls = new Map();
  for (const event of events || []) {
    const callId = event?.type === 'tool/call' ? event.data?.callId
      : event?.type === 'tool/ptc-dispatch-start' ? event.data?.subCallId : null;
    if (callId) {
      calls.set(callId, {
        ...event.data,
        callId,
        eventSeq: event.seq,
        time: event.time,
      });
    }
  }

  const { uniqueResults, replayedResults } = uniqueToolResultEvents(events || []);
  const steps = [];
  const executions = new Map();
  const unmatchedResults = [];
  for (const event of uniqueResults) {
    const callId = toolResultCallId(event);
    const call = calls.get(callId);
    if (!call) {
      unmatchedResults.push({
        callId,
        resultSeq: event.seq ?? null,
        time: event.time ?? null,
      });
      continue;
    }

    const nested = event.type === 'tool/ptc-dispatch';
    const message = nested ? {isError: event.data?.isError,
      content:[{type:'tool_result',content:event.data?.content || []}]} : event.data?.message || {};
    const args = parseToolArguments(call.arguments);
    const code = typeof args.code === 'string' ? args.code : '';
    const resultText = toolResultText(message);
    const outcome = executionResult(event),canonical = outcome?.value;
    const isHoudini = isHoudiniTool(call.name) || call.name === 'job_output' && outcome?.producer === 'live-job';
    // Isolated operation=read returns the same retained report/images without
    // the run response's top-level ok. Keep its exact public wrapper; nested
    // report executions remain independent and are not flattened into live HOM.
    const envelope = isHoudini && canonical && typeof canonical === 'object'
      && (typeof canonical.ok === 'boolean' || canonical.kind === 'isolated-houdini') ? canonical : null;
    const scoped=returnedExecutions(outcome?.tool??call.name,envelope);
    const live=scoped.find(item=>item.domain==='live')?.execution;
    const observation = live?.execution;
    const executionKey = typeof observation?.runtime_id === 'string' && Number.isFinite(observation.sequence)
      ? `${observation.runtime_id}:${observation.sequence}` : null;
    const executionReplay = executionKey !== null && executions.has(executionKey);
    if(executionKey && !executionReplay)executions.set(executionKey,{
      runtimeId:observation.runtime_id,sequence:observation.sequence,firstResultSeq:event.seq,
      firstTool:call.name,recovered:envelope?.requestReceipt?.retrieved===true,
      verbCalls:Array.isArray(envelope.verbs)?envelope.verbs.length:0,
      transaction:envelope.transaction?.status??null,
    });
    const rawUsage = envelope?.rawUsage ?? parseJsonBlock(resultText, 'raw-usage');
    const mutatingRawMethods = rawUsage && !rawUsage._raw
      ? [...(rawUsage.coveredMutations || []), ...(rawUsage.suspectedMutations || [])]
        .filter((item) => isMutatingRawMethodName(item?.name))
        .flatMap((item) => Array(Number(item.count) || 1).fill(String(item.name)))
      : mutatingRawMethodNames(code);
    const advisoryMatch = resultText.match(/hint:\n([\s\S]*?)$/);

    steps.push({
      index: steps.length + 1,
      callId,
      ...(nested ? {parentCallId:event.data.parentCallId} : {}),
      callSeq: call.eventSeq ?? null,
      resultSeq: event.seq ?? null,
      time: event.time ?? null,
      callTime: call.time ?? null,
      durationMs: Number.isFinite(call.time) && Number.isFinite(event.time) ? event.time - call.time : null,
      turn: event.data?.turn ?? null,
      step: event.data?.step ?? null,
      tool: call.name || '?',
      isHoudini,
      failed: toolResultFailed(message, resultText, call.name) || (envelope?.status ? envelope.status === 'failed' : envelope?.ok === false),
      processOutcome: processOutcomeFor(call.name, resultText, event.data?.meta),
      args,
      code,
      resultText,
      verbs: executionReplay || envelope?.requestReceipt?.retrieved ? [] : Array.isArray(envelope?.verbs) ? envelope.verbs.map((v,i) => ({
        ledgerIndex:i+1,ok:v.ok,verb:v.verb,
        args:JSON.stringify(v.args)+(v.kwargs && Object.keys(v.kwargs).length ? ', '+JSON.stringify(v.kwargs) : ''),
        result:v.summary ? {...(typeof v.result === 'object' && v.result !== null ? v.result : {}),...v.summary} : v.result,
        resultText:JSON.stringify(v.result),ms:v.ms,
      })) : parseVerbLedger(resultText),
      rawMethods: rawMethodNames(code),
      mutatingRawMethods,
      advisory: advisoryMatch ? advisoryMatch[1].trim() : null,
      rollback: envelope?.rollback ?? parseJsonBlock(resultText, 'rollback'),
      transaction: envelope?.transaction ?? parseJsonBlock(resultText, 'transaction'),
      canonical: envelope,
      executionScopes:scoped.map(({domain,archive,execution})=>({domain,archive,
        runtime_id:execution.execution?.runtime_id??null,sequence:execution.execution?.sequence??null,
        details:execution.details??null})),
      recoveredExecution: envelope?.requestReceipt?.retrieved === true,
      executionReplay,
      canonicalStatus: envelope ? nested ? 'retained_in_dispatch' : 'retained_in_metadata' : parseJsonBlock(resultText, 'result-details')?.stored ? 'referenced_artifact_only' : 'legacy_model_text',
      executionLocation: (call.name === 'houdini_resource' && args.kind === 'result')
        || (call.name === 'houdini_query' && args.result_ref) ? 'host_result_artifact' : null,
      rawUsage,
    });
  }

  return { steps, replayedResults, unmatchedResults, uniqueExecutions:[...executions.values()] };
}
