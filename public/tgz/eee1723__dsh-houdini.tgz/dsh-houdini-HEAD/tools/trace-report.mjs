#!/usr/bin/env node
// trace-report：把 dsh session 的 houdini 操作 trace 生成单文件 HTML 复盘报告。
//
// 用法：
//   node tools/trace-report.mjs [sessionDir|session.jsonl.zstd] [--out <file>]
//   缺省 session：~/.dsh/sessions 下最新修改的一个。
//
// 报告内容：
//   1. 概览：工具调用统计 / 动词命中 / 裸 hou / 失败 / advisory
//   2. 词表目录（从 docs/tool-design.md 解析，按域分组，标注本次会话使用次数）
//   3. 调用时间线：按真实顺序（工具结果时间 + ledger 顺序），时间戳 + 耗时，
//      必要信息平铺，代码与完整返回折叠在 <details> 里
//   4. 分析段落：裸 hou 段落、失败调用、advisory 触发——词表改进的直接输入
//
// 数据边界：session.jsonl.zstd 是多帧拼接，按魔数 28 B5 2F FD 切帧逐段解压；
// 模型可见文本里的 `verbs (N):` 块是动词 ledger 的渲染（src/tools.ts renderVerbs）。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCatalog } from './catalog-lib.mjs';
import {
  loadSessionEvents,
  newestSessionFile,
  resolveSessionFile,
  collectRequestTelemetry,
  collectRequestContexts,
} from './trace-session-lib.mjs';
import { normalizeTraceSteps, unresolvedExecutionRequests } from './normalized-trace-steps.mjs';
import { executionHistory } from '../lib/execution-history.js';
import {
  collectQualityLoopEvidence,
  collectRetryWork,
  collectVerbAdoption,
  classifyRawEffect,
  isHoudiniHostCall,
  isStructuredHoudiniCall,
  collectValidationCoverage,
  nativeImageEvidence,
  linkNativeImageResponses,
  qualityLoopRisks,
  requestedGoalReportedUnverified,
} from '../skills/houdini-trace-analysis/scripts/evidence-helpers.mjs';

const REPO_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DOC_PATH = path.join(REPO_ROOT, 'docs', 'tool-design.md');

// ---------- args ----------
const argv = process.argv.slice(2);
let sessionArg = null;
let outArg = null;
for (let i = 0; i < argv.length; i++) {
  if (argv[i] === '--out') outArg = argv[++i];
  else if (!argv[i].startsWith('--')) sessionArg = argv[i];
}

let sessionFile = sessionArg;
if (sessionArg && fs.statSync(sessionArg).isDirectory()) {
  sessionFile = resolveSessionFile(sessionArg);
}
if (!sessionFile) sessionFile = newestSessionFile();
if (!sessionFile || !fs.existsSync(sessionFile)) {
  console.error('session 文件不存在:', sessionFile);
  process.exit(1);
}

// ---------- catalog from tool-design.md ----------
// 解析逻辑在 tools/catalog-lib.mjs（与 gen-client-catalog.mjs 共用）。

// ---------- parse trace ----------
const loadedSession = loadSessionEvents(sessionFile);
const { events } = loadedSession;
const executionObservations = executionHistory(events);
const requestTelemetry = collectRequestTelemetry(events);
const requestContexts = collectRequestContexts(events);
const normalized = normalizeTraceSteps(events);
const retryWork = collectRetryWork(normalized.steps);
const { replayedResults, unmatchedResults } = normalized;

const userMsgs = [];
const assistantMsgs = [];
const availableTools = new Set();
for (const e of events) {
  if (e.type === 'request/header') {
    for (const tool of e.data?.header?.tools || []) {
      const name = tool?.name || tool?.function?.name;
      if (name) availableTools.add(name);
    }
  } else if (e.type === 'user/message') {
    const d = e.data || {};
    if (d.source?.kind !== 'user') continue;
    const text = (d.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('\n');
    if (!text || text.startsWith('<system-reminder>') || text.startsWith('Current runtime context')) continue;
    userMsgs.push({ time: e.time, text });
  } else if (e.type === 'assistant/message') {
    const text = (e.data?.message?.content || [])
      .filter((c) => c.type === 'text').map((c) => c.text).join('\n');
    if (text.trim()) assistantMsgs.push({ time: e.time, text });
  }
}

const steps = normalized.steps.map((step) => ({
  ...step,
  code: step.code || null,
  errorTail: step.failed ? step.resultText.split('\n').slice(-3).join('\n') : null,
}));
steps.sort((a, b) => a.time - b.time);

// 动词使用统计 → 回填目录
const catalog = loadCatalog(DOC_PATH);
const verbCount = {};
for (const s of steps) for (const v of s.verbs) verbCount[v.verb] = (verbCount[v.verb] || 0) + 1;
let catalogVerbs = 0;
let usedVerbs = 0;
for (const d of catalog) {
  for (const v of d.verbs) {
    v.used = verbCount[v.name] || 0;
    catalogVerbs++;
    if (v.used > 0) usedVerbs++;
  }
}
const unknownVerbs = Object.keys(verbCount).filter(
  (n) => !catalog.some((d) => d.verbs.some((v) => v.name === n)),
);

// 概览统计
const toolCount = {};
for (const s of steps) toolCount[s.tool] = (toolCount[s.tool] || 0) + 1;
const rawHouSteps = steps.filter((s) => s.isHoudini && !isHoudiniHostCall(s) && !isStructuredHoudiniCall(s) && s.verbs.length === 0);
const failedSteps = steps.filter((s) => s.failed);
const processFailures = steps.filter(s => s.processOutcome?.status === 'failed');
const processInterruptions = steps.filter(s => s.processOutcome?.status === 'interrupted');
const advisorySteps = steps.filter((s) => s.advisory);
const totalVerbCalls = Object.values(verbCount).reduce((a, b) => a + b, 0);
const validationCoverage = collectValidationCoverage(
  steps.map((step, index) => ({ ...step, index: index + 1 })),
);
const indexedSteps = steps.map((step, index) => ({ ...step, index: index + 1 }));
const nativeImages = linkNativeImageResponses(nativeImageEvidence(indexedSteps),indexedSteps,events);
const activatedSkills = indexedSteps.filter((step) => step.tool === 'skill' && !step.failed)
  .map((step) => step.args?.name).filter(Boolean);
const qualityLoopEvidence = collectQualityLoopEvidence({
  steps: indexedSteps,
  userMessages: userMsgs,
  assistantMessages: assistantMsgs,
  availableTools: [...availableTools],
  activatedSkills,
});
const qualityRisks = qualityLoopRisks(qualityLoopEvidence);
const unresolvedRequests = unresolvedExecutionRequests(normalized.steps);
if (unresolvedRequests.length) qualityRisks.push({code:'unresolved_execution_receipt',
  detail:'Missing execution ledger does not mean not executed; artifacts do not resolve a request receipt.',
  requests:unresolvedRequests});
if (executionObservations.activeJobs.length) qualityRisks.push({code:'active_houdini_jobs',
  detail:'Retained job observations are nonterminal or results remain uncollected; a recovered submission receipt does not prove completion. This is trace scope, not current live status.',
  jobs:executionObservations.activeJobs});
if (executionObservations.unavailableResults.length) qualityRisks.push({code:'execution_result_unavailable',
  detail:'Retained execution/job results are unavailable; finished does not establish their outcome.',
  results:executionObservations.unavailableResults});
const unverifiedRequestedGoals = requestedGoalReportedUnverified(userMsgs, assistantMsgs);
if (unverifiedRequestedGoals.length) {
  qualityRisks.push({
    code: 'requested_goal_reported_unverified',
    detail: `The final delivery presents the task as complete while user-requested dimension(s) remain unverified: ${unverifiedRequestedGoals.map((item) => item.signal).join(', ')}.`,
    items: unverifiedRequestedGoals,
  });
}
const verbAdoption = collectVerbAdoption(steps);
const visionInspections = validationCoverage.vision.filter((item) => ['inspection','image_access'].includes(item.role));
const successfulVisionInspections = visionInspections.filter((item) => item.accessOk === true);

// ---------- HTML ----------
const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const fmtTime = (ms) => {
  const d = new Date(ms);
  const p = (n, w = 2) => String(n).padStart(w, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
};

const chip = (text, cls) => `<span class="chip ${cls}">${esc(text)}</span>`;
const frameList = (frames) => frames.length ? frames.map((frame) => esc(frame)).join(', ') : '无';

const validationHtml = `
  <div class="cards">
    <div class="card"><div class="num">${validationCoverage.geometry.length}</div><div class="cap">geometry A/B</div></div>
    <div class="card"><div class="num">${validationCoverage.renders.length}</div><div class="cap">render calls</div></div>
    <div class="card"><div class="num">${validationCoverage.comparisons.length}</div><div class="cap">image comparisons</div></div>
    <div class="card"><div class="num">${successfulVisionInspections.length}/${visionInspections.length}</div><div class="cap">图片访问成功（语义需核图）</div></div>
    <div class="card"><div class="num">${nativeImages.filter(item=>item.delivered).length}</div><div class="cap">原生图附件（需人工核图）</div></div>
  </div>
  <p class="dim-text">几何帧: ${frameList(validationCoverage.frames.geometry)} ｜ 渲染帧: ${frameList(validationCoverage.frames.render)} ｜ 锁定构图帧: ${frameList(validationCoverage.frames.framing)} ｜ 图片比较帧: ${frameList(validationCoverage.frames.comparison)} ｜ 视觉检查帧: ${frameList(validationCoverage.frames.visionInspection)}</p>
  <details><summary>原生图片与后续模型描述（非语义认证）</summary><pre>${esc(JSON.stringify(nativeImages, null, 2))}</pre></details>
  <details><summary>验证覆盖明细</summary><pre>${esc(JSON.stringify(validationCoverage, null, 2))}</pre></details>`;

const qualityLoopHtml = `
  <div class="cards">
    <div class="card"><div class="num">${qualityLoopEvidence.applicable ? '是' : '否'}</div><div class="cap">开放式质量任务</div></div>
    <div class="card"><div class="num">${qualityLoopEvidence.reference.researchSteps.length}</div><div class="cap">research/web 调用</div></div>
    <div class="card"><div class="num">${qualityLoopEvidence.skeleton.tabCreatesBeforeFirstRender}</div><div class="cap">首张 render 前建节点</div></div>
    <div class="card"><div class="num">${qualityLoopEvidence.relations.probeSteps.length}</div><div class="cap">关系检查 / 手写测量候选（非正确性认证）</div></div>
    <div class="card"><div class="num">${qualityLoopEvidence.perturbation.restored.length}</div><div class="cap">控制扰动并恢复</div></div>
    <div class="card"><div class="num" style="color:${qualityRisks.length ? 'var(--bad)' : 'var(--ok)'}">${qualityRisks.length}</div><div class="cap">质量闭环风险</div></div>
  </div>
  ${qualityRisks.length
    ? `<pre class="err">${esc(JSON.stringify(qualityRisks, null, 2))}</pre>`
    : '<p class="dim-text">未检测到确定性质量闭环风险；这不等于主观艺术质量已经通过。</p>'}
  <details><summary>质量闭环证据明细</summary><pre>${esc(JSON.stringify(qualityLoopEvidence, null, 2))}</pre></details>`;

const catalogHtml = catalog.map((d) => `
  <div class="domain">
    <div class="domain-name">${esc(d.note)}</div>
    ${d.verbs.map((v) => `
      <div class="verb ${v.used ? 'used' : 'unused'}">
        <span class="verb-name">${esc(v.name)}</span>
        <span class="verb-sig">${esc(v.sig)}</span>
        ${v.used ? `<span class="badge ok">×${v.used}</span>` : '<span class="badge dim">未用</span>'}
        <div class="verb-desc">${esc(v.desc)}</div>
      </div>`).join('')}
  </div>`).join('');

const timelineHtml = steps.map((s, i) => {
  const verbChips = s.verbs.map((v) =>
    `<span class="chip verb-chip ${v.ok ? '' : 'fail'}" title="${esc(v.args)} -> ${esc(v.resultText)}">${esc(v.verb)} <span class="ms">${v.ms}ms</span></span>`,
  ).join('');
  const badges = [
    s.failed ? chip('失败', 'fail') : '',
    s.processOutcome?.status === 'failed' ? chip(`进程退出 ${s.processOutcome.exitCode}`, 'fail') : '',
    s.processOutcome?.status === 'interrupted' ? chip(`进程终止 · ${s.processOutcome.interruption}`, 'warn') : '',
    s.processOutcome?.status === 'succeeded' && s.processOutcome.hasStderr ? chip('有诊断输出 · 进程退出 0', 'warn') : '',
    s.rawMethods.length > 0 ? chip(
      `裸 HOM ×${s.rawMethods.length}`,
      s.mutatingRawMethods.length ? 'bad' : 'warn',
    ) : '',
    s.advisory ? chip('advisory', 'warn') : '',
    s.verbs.length ? chip(`动词 ×${s.verbs.length}`, 'ok') : '',
  ].join('');
  const detailParts = [];
  if (s.code) detailParts.push(`<div class="lbl">code</div><pre>${esc(s.code)}</pre>`);
  if (Object.keys(s.args).length && !s.code) detailParts.push(`<div class="lbl">args</div><pre>${esc(JSON.stringify(s.args, null, 2))}</pre>`);
  if (s.advisory) detailParts.push(`<div class="lbl">advisory</div><pre class="adv">${esc(s.advisory)}</pre>`);
  if (s.processOutcome) detailParts.push(`<div class="lbl">process outcome (separate from tool delivery)</div><pre>${esc(JSON.stringify(s.processOutcome))}</pre>`);
  detailParts.push(`<div class="lbl">model-facing result</div><pre>${esc(s.resultText)}</pre>`);
  if (s.canonical) detailParts.push(`<div class="lbl">canonical returned envelope (audit metadata)</div><pre>${esc(JSON.stringify(s.canonical,null,2))}</pre>`);
  else if(s.canonicalStatus==='referenced_artifact_only')detailParts.push('<p>Full envelope is referenced by result-details; this trace event has no canonical metadata. Do not treat omitted fields as absent facts.</p>');
  return `
  <div class="step ${s.failed || s.processOutcome?.status === 'failed' ? 'failed' : ''}">
    <div class="step-head">
      <span class="t">${fmtTime(s.time)}</span>
      <span class="seq">#${i + 1}</span>
      <span class="tool ${s.isHoudini ? 'hou' : ''}">${esc(s.tool)}</span>
      ${badges}
      <span class="verb-chips">${verbChips}</span>
    </div>
    <details><summary>详情</summary>${detailParts.join('')}</details>
  </div>`;
}).join('');

const rawEffectLabels = {
  gate_blocked: 'Gate 执行前拦截', mutation_candidate: '检测到裸修改候选',
  suspected_effect: '疑似副作用 / 外部操作', read_only_query: '只读 query（守卫范围）',
  failed: '失败；未证明只读', unknown: '副作用未知（含动态调用）',
};
const rawHouHtml = rawHouSteps.length
  ? rawHouSteps.map((s) => {
      const idx = steps.indexOf(s) + 1;
      return `<div class="step"><div class="step-head"><span class="t">${fmtTime(s.time)}</span><span class="seq">#${idx}</span><span class="tool hou">${esc(s.tool)}</span>${chip(
        rawEffectLabels[classifyRawEffect(s)],
        classifyRawEffect(s) === 'gate_blocked' ? 'bad' : 'warn',
      )}</div>
      <details><summary>代码</summary><pre>${esc(s.code)}</pre></details></div>`;
    }).join('')
  : '<p class="dim-text">无</p>';

const failedHtml = failedSteps.length
  ? failedSteps.map((s) => {
      const idx = steps.indexOf(s) + 1;
      return `<div class="step failed"><div class="step-head"><span class="t">${fmtTime(s.time)}</span><span class="seq">#${idx}</span><span class="tool hou">${esc(s.tool)}</span>${chip('失败', 'fail')}</div>
      <pre class="err">${esc(s.errorTail)}</pre>
      <details><summary>完整结果与代码</summary><pre>${esc(s.code || '')}</pre><pre>${esc(s.resultText)}</pre></details></div>`;
    }).join('')
  : '<p class="dim-text">无</p>';

const sessionId = path.basename(path.dirname(sessionFile));
const html = `<!DOCTYPE html>
<html lang="zh"><head><meta charset="utf-8">
<title>houdini trace 复盘 — ${esc(sessionId)}</title>
<style>
  :root { --bg:#1b1c20; --panel:#24262b; --line:#34363d; --fg:#e8e9ec; --dim:#9a9ba2;
          --ok:#4ec98a; --warn:#e5b567; --bad:#e06c75; --acc:#5b9dff; }
  * { box-sizing: border-box; }
  body { margin:0; background:var(--bg); color:var(--fg); font:14px/1.6 "Microsoft YaHei",system-ui,sans-serif; }
  header { padding:18px 28px; border-bottom:1px solid var(--line); }
  header h1 { margin:0 0 4px; font-size:18px; }
  header .meta { color:var(--dim); font-size:12px; }
  main { display:grid; grid-template-columns: 380px 1fr; gap:0; align-items:start; }
  .col { padding:18px 24px; }
  .col.left { border-right:1px solid var(--line); position:sticky; top:0; max-height:100vh; overflow:auto; }
  h2 { font-size:15px; margin:6px 0 12px; color:var(--acc); }
  .cards { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:14px; }
  .card { background:var(--panel); border:1px solid var(--line); border-radius:8px; padding:8px 14px; }
  .card .num { font-size:20px; font-weight:700; }
  .card .cap { color:var(--dim); font-size:12px; }
  .domain { background:var(--panel); border:1px solid var(--line); border-radius:8px; padding:10px 12px; margin-bottom:10px; }
  .domain-name { font-weight:700; margin-bottom:6px; color:var(--acc); }
  .verb { padding:5px 6px; border-top:1px dashed var(--line); }
  .verb.unused { opacity:.55; }
  .verb-name { font-family:Consolas,monospace; font-weight:700; }
  .verb-sig { font-family:Consolas,monospace; color:var(--dim); font-size:11px; margin-left:6px; }
  .verb-desc { color:var(--dim); font-size:12px; }
  .badge { float:right; font-size:11px; border-radius:4px; padding:0 6px; }
  .badge.ok { color:var(--ok); border:1px solid var(--ok); }
  .badge.dim { color:var(--dim); border:1px solid var(--line); }
  .step { background:var(--panel); border:1px solid var(--line); border-radius:8px; padding:8px 12px; margin-bottom:8px; }
  .step.failed { border-color:var(--bad); }
  .step-head { display:flex; align-items:center; flex-wrap:wrap; gap:8px; }
  .t { font-family:Consolas,monospace; color:var(--acc); font-weight:700; }
  .seq { color:var(--dim); font-size:12px; }
  .tool { font-family:Consolas,monospace; font-size:12px; background:#313340; border-radius:4px; padding:1px 8px; }
  .tool.hou { background:#2c3a2e; color:#a6d189; }
  .chip { font-size:11px; border-radius:4px; padding:0 6px; border:1px solid var(--line); color:var(--dim); }
  .chip.ok { color:var(--ok); border-color:var(--ok); }
  .chip.warn { color:var(--warn); border-color:var(--warn); }
  .chip.bad, .chip.fail { color:var(--bad); border-color:var(--bad); }
  .verb-chips { display:flex; flex-wrap:wrap; gap:4px; }
  .verb-chip { font-family:Consolas,monospace; font-size:11px; background:#2b3049; color:#c6d0f5; border:none; border-radius:4px; padding:1px 7px; }
  .verb-chip.fail { background:#4a2b2b; color:#f0a8a8; }
  .verb-chip .ms { color:var(--dim); }
  details { margin-top:6px; }
  summary { cursor:pointer; color:var(--dim); font-size:12px; }
  pre { background:#17181b; border:1px solid var(--line); border-radius:6px; padding:8px 10px;
        overflow:auto; font:12px/1.5 Consolas,monospace; white-space:pre-wrap; word-break:break-all; }
  pre.err { color:#f0a8a8; }
  pre.adv { color:var(--warn); }
  .lbl { color:var(--dim); font-size:11px; margin-top:6px; }
  .dim-text { color:var(--dim); }
  .user-msg { background:#26313d; border:1px solid #33506b; border-radius:8px; padding:8px 12px; margin-bottom:8px; }
  .user-msg .t { color:#7ab8f5; }
</style></head><body>
<header>
  <h1>houdini trace 复盘报告</h1>
  <div class="meta">session: ${esc(sessionId)} ｜ 生成: ${esc(new Date().toLocaleString('zh-CN'))} ｜ 事件 ${events.length} 条</div>
</header>
<main>
  <div class="col left">
    <h2>词表目录广度（${usedVerbs}/${catalogVerbs}；不是使用率或合规率）</h2>
    ${catalogHtml}
    ${unknownVerbs.length ? `<p class="dim-text">未收录进目录的动词调用: ${unknownVerbs.map(esc).join(', ')}（tool-design.md 需同步）</p>` : ''}
  </div>
  <div class="col">
    <h2>概览</h2>
    ${loadedSession.frameErrors.length || loadedSession.lineErrors.length ? `<pre class="err">${esc(JSON.stringify({frameErrors:loadedSession.frameErrors,lineErrors:loadedSession.lineErrors},null,2))}</pre><p>日志读取不完整，结论仅覆盖成功读取的事件。</p>` : ''}
    <div class="cards">
      <div class="card"><div class="num">${steps.length}</div><div class="cap">工具调用</div></div>
      <div class="card"><div class="num">${totalVerbCalls}</div><div class="cap">动词调用</div></div>
      <div class="card"><div class="num">${verbAdoption.callsWithVerbs}/${verbAdoption.houdiniCalls}</div><div class="cap">Houdini 调用含动词（${verbAdoption.callCoveragePct ?? 0}%）</div></div>
      <div class="card"><div class="num">${verbAdoption.verbDensity}</div><div class="cap">每次 Houdini 调用动词数</div></div>
      <div class="card"><div class="num">${usedVerbs}/${catalogVerbs}</div><div class="cap">目录广度（非合规率）</div></div>
      <div class="card"><div class="num">${verbAdoption.rawReadOnlyCalls}</div><div class="cap">无动词只读 query（守卫范围）</div></div>
      <div class="card"><div class="num">${verbAdoption.rawSuspectedEffectCalls}</div><div class="cap">无动词疑似副作用 / 外部操作</div></div>
      <div class="card"><div class="num">${verbAdoption.rawUnknownEffectCalls}</div><div class="cap">无动词副作用未知</div></div>
      <div class="card"><div class="num">${verbAdoption.rawFailedCalls}</div><div class="cap">无动词失败（未证明只读）</div></div>
      <div class="card"><div class="num">${verbAdoption.successfulVerblessRawMutationCalls}</div><div class="cap">成功返回的无动词裸修改候选</div></div>
      <div class="card"><div class="num">${verbAdoption.blockedVerblessRawMutationCalls}</div><div class="cap">Gate 执行前拦截</div></div>
      <div class="card"><div class="num" style="color:${failedSteps.length ? 'var(--bad)' : 'var(--ok)'}">${failedSteps.length}</div><div class="cap">失败调用</div></div>
      <div class="card"><div class="num" style="color:${processFailures.length ? 'var(--bad)' : 'var(--ok)'}">${processFailures.length}</div><div class="cap">命令进程退出失败（独立统计）</div></div>
      <div class="card"><div class="num">${processInterruptions.length}</div><div class="cap">命令进程终止（超时、停止或信号）</div></div>
      <div class="card"><div class="num">${advisorySteps.length}</div><div class="cap">advisory 触发</div></div>
      <div class="card"><div class="num">${replayedResults.length}</div><div class="cap">compaction replay</div></div>
      <div class="card"><div class="num" style="color:${unmatchedResults.length ? 'var(--bad)' : 'var(--ok)'}">${unmatchedResults.length}</div><div class="cap">无匹配 call 的 result</div></div>
    </div>
    <p class="dim-text">工具分布: ${Object.entries(toolCount).map(([k, v]) => `${esc(k)} ×${v}`).join(' ｜ ')}</p>
    <p class="dim-text">成功 exec 含动词 ${verbAdoption.successfulExecWithVerbs}/${verbAdoption.successfulExecCalls}（${verbAdoption.successfulExecVerbCoveragePct ?? '—'}%）只描述调用形态，分母包含验证/动态函数；不代表修改采用率。${verbAdoption.structuredCalls ? `另有${verbAdoption.structuredCalls}次结构化调用不执行Python，已从无动词裸调用统计排除；Python调用含动词${verbAdoption.callsWithVerbs}/${verbAdoption.pythonCalls}。` : ''}Gate read_only 是静态扫描结果，no_scene_change 不排除文件或 Python 全局副作用；零裸修改候选不证明没有修改。</p>
    ${replayedResults.length ? `<p class="dim-text">已按 callId 排除 ${replayedResults.length} 条历史 tool/result replay；它们不计入调用、动词、失败或耗时。</p>` : ''}
    ${unmatchedResults.length ? `<p class="dim-text">另有 ${unmatchedResults.length} 条 tool/result 无法关联原始 call，已排除并列为 trace schema/integrity diagnostics。</p>` : ''}
    ${userMsgs.map((m) => `<div class="user-msg"><span class="t">${fmtTime(m.time)}</span> 👤 ${esc(m.text)}</div>`).join('')}
    <p class="dim-text">有canonical运行序号的独立执行：${normalized.uniqueExecutions.length}；独立执行内动词 ${normalized.uniqueExecutions.reduce((n,e)=>n+e.verbCalls,0)}。仅覆盖实际保留runtime/sequence的事件，不代表旧轨迹无执行；轮询和查回仍是独立工具调用，不能重复计场景执行。</p>
    <h2>执行回执与后台任务范围</h2>
    <p>提交/执行回执未查回 ${unresolvedRequests.length} 项；后台任务仍在进行或结果尚未领取 ${executionObservations.activeJobs.length} 项；已结束但结果不可取得 ${executionObservations.unavailableResults.length} 项。</p>
    <p class="dim-text">这些状态复用 executionHistory 对原始会话事件的投影，只描述日志中最后保留的观察，包含原生和嵌套调用的提交回执；不是当前现场查询。无未查回回执不等于全部后台任务已完成；提交成功、任务结束、结果可取与结果正确分别判断。缺失结果或过期结果保持结果未验证。</p>
    ${executionObservations.activeJobs.length ? `<details open><summary>后台任务的最后保留状态</summary><pre>${esc(JSON.stringify(executionObservations.activeJobs,null,2))}</pre></details>` : ''}
    ${executionObservations.unavailableResults.length ? `<details open><summary>不可取得的执行结果（未验证）</summary><pre>${esc(JSON.stringify(executionObservations.unavailableResults,null,2))}</pre></details>` : ''}
    <h2>回滚与近重复重试候选</h2>
    <p>提交代码 ${retryWork.totalCodeChars} 字符；失败调用代码 ${retryWork.failedCodeChars} 字符；已应用回滚 ${retryWork.appliedRollbackCalls} 次，涉及代码 ${retryWork.appliedRollbackCodeChars} 字符。
    ${retryWork.successfulBuildEntriesInAppliedRollbacks.length} 个成功的 build_module ledger 条目随后被所在调用回滚；近重复重试候选 ${retryWork.candidates.length} 对。</p>
    <p>Host 文件写入目标 ${retryWork.hostWork.fileWrites.length} 个，相同 shell 命令重跑 ${retryWork.hostWork.repeatedCommands.length} 组。下方明细保留步骤范围；重复不等于无进展，离线工作不等于停滞，不能据此自动停止。</p>
    <p class="dim-text">字符数不是token、耗时或可节省量；回滚代码已包含在提交量中。相似度只比较去首尾空白的相同行，忽略行序和缩进，不证明语义等价或浪费；必要重试和不同模块可能相似。候选附步骤定位和有限差异片段，完整代码在下方调用详情。</p>
    <details><summary>候选对、差异片段、统计口径与分析范围</summary><pre>${esc(JSON.stringify(retryWork,null,2))}</pre></details>
    <h2>请求用量与逐轮运行状态</h2>
    <p>记录到 ${requestTelemetry.requestCount} 个请求的 usage；末请求输入含缓存 ${requestTelemetry.last?.inputWithCache ?? '未知'} tokens。
    累计报告 input ${requestTelemetry.totals.inputTokens ?? '未知'} / cache read ${requestTelemetry.totals.cacheReadTokens ?? '未知'} / output ${requestTelemetry.totals.outputTokens ?? '未知'}，其中 reasoning ${requestTelemetry.totals.reasoningTokens ?? '未知'}（已包含在 output 中）。
    逐轮上游错误 ${requestTelemetry.upstreamTurnErrors.length}；compaction 事件 ${requestTelemetry.compactionEvents.length}；usage 去重 ${requestTelemetry.duplicateUsageEvents}，更新 ${requestTelemetry.updatedUsageEvents}。</p>
    <p class="dim-text">请求累计重复计算历史，不是独立文本量或账单；缺失字段为未知。输入含缓存仅在字段算术一致时推导；未记录压缩不能证明原文全部保留。上游错误与工具失败分别统计。</p>
    ${requestTelemetry.upstreamTurnErrors.map(e => `<p>turn ${esc(e.turn)} · ${esc(e.code)} · ${esc(e.message)}</p>`).join('')}
    <details><summary>完整请求、逐轮与目标变更记录</summary><pre>${esc(JSON.stringify(requestTelemetry,null,2))}</pre></details>
    <p>最后请求前可重建消息 ${requestContexts.at(-1)?.contentChars ?? '未知'} 字符；system ${requestContexts.at(-1)?.systemChars ?? '未知'} 字符；工具 schema ${requestContexts.at(-1)?.toolsSchemaChars ?? '未知'} 字符。字符不是 token；只折叠日志中的有效 surface，不把 stream 或 canonical metadata 加入模型消息。</p>
    <details><summary>逐请求上下文组成与来源（不含推理正文）</summary><pre>${esc(JSON.stringify(requestContexts,null,2))}</pre></details>
    <h2>动画 / 多帧验证覆盖</h2>
    ${validationHtml}
    <h2>任务、测量与声明复核线索</h2>
    ${qualityLoopHtml}
    <h2>调用时间线（真实顺序）</h2>
    ${timelineHtml}
    <h2>无动词 Houdini 调用（拦截、只读 query 与未知副作用）</h2>
    ${rawHouHtml}
    <h2>失败调用</h2>
    ${failedHtml}
  </div>
</main>
</body></html>`;

const outFile = outArg || path.join(REPO_ROOT, 'tools', 'out', `trace-${sessionId}.html`);
fs.mkdirSync(path.dirname(outFile), { recursive: true });
fs.writeFileSync(outFile, html);
console.log('session :', sessionFile);
console.log('events  :', events.length, '| steps:', steps.length, '| verbs:', totalVerbCalls, `(${usedVerbs}/${catalogVerbs})`, '| replays:', replayedResults.length, '| unmatched:', unmatchedResults.length);
console.log('frames  : geometry=[' + validationCoverage.frames.geometry.join(',') + '] render=[' + validationCoverage.frames.render.join(',') + '] vision-inspection=[' + validationCoverage.frames.visionInspection.join(',') + ']');
console.log('review  : cues=[' + qualityRisks.map((risk) => risk.code).join(',') + ']');
console.log('state   : unresolvedRequests=' + unresolvedRequests.length + ' activeJobs=' + executionObservations.activeJobs.length + ' unavailableResults=' + executionObservations.unavailableResults.length + ' (last retained trace observations; not current live status)');
console.log('report  :', outFile);
