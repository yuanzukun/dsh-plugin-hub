/**
 * HTTP client for the Houdini-side bridge (`houdini/python3.11libs/dsh_bridge.py`).
 *
 * The bridge runs inside Houdini's own Python, where the `hou` module lives;
 * this client is the only channel the plugin uses to reach it.
 */
/** Bridge wire JSON is independent of DSH's version-specific type re-exports. */
export type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue }
import { EXPECTED_EXECUTION_CONTRACT_VERSION, EXPECTED_VERB_CATALOG_HASH, EXPECTED_VERB_NAMES } from './generated-verb-contract.js'

/** Result envelope returned by the bridge for `/exec` and job status polls. */
export interface ExecResult {
  job_id?: string
  jobId?: string
  status?: 'queued' | 'running' | 'done' | 'failed' | 'cancelled'
  ok: boolean
  stdout: string
  stderr: string
  /** JSON value the executed code bound to `__result__`, if any. */
  result?: JsonValue
  /** Runtime ledger of verb-vocabulary calls, when any were traced. */
  verbs?: JsonValue
  /** Bridge projection: batch execution, raised operations and returned checks. */
  outcome?: JsonValue
  /** Python traceback, present when `ok` is false. */
  error?: string
  /** Failure-time Houdini undo rollback outcome, when execution reached Python. */
  rollback?: JsonValue
  transaction?: JsonValue
  /** Structured Raw Gate/read-only HOM classification produced by the bridge AST. */
  rawUsage?: JsonValue
  /** Advisory hint, present when the code bypassed the verb vocabulary with raw hou calls. */
  advisory?: string
  /** Absolute paths of images produced during this exec (render/screenshot verbs). */
  images?: JsonValue
  /** Native DSH image attachment references; no workspace file copies. */
  imageAttachments?: JsonValue
  /** Existing authoritative paths for Agent review; never automatic deliveries. */
  artifactCandidates?: JsonValue
  /** Failed/warning operation checks despite successful Python execution. */
  checks?: JsonValue
  /** Compact operation evidence, retained independently of verbose ledger previews. */
  evidence?: JsonValue
  /** Bridge runtime/order and bounded impact observation; not a scene lock. */
  execution?: JsonValue
  /** Immutable returned-envelope reference, filled host-side for large results. */
  details?: JsonValue
  /** Same-runtime execution receipt, including uncertain transport outcomes. */
  requestReceipt?: JsonValue
  /** Exact builder source identity verified and returned by the Python executor. */
  script?: JsonValue
}

/** Frozen Host-read source. The Bridge verifies this against the transmitted code. */
export interface ScriptSource {path:string;sha256:string;bytes:number;entry?:string}

/** Handle returned when a background job is accepted by the bridge. */
export interface JobHandle {
  /** Native DSH observer id; the Bridge jobId remains original execution provenance. */
  job_id?: string
  jobId?: string
  requestReceipt?: JsonValue
  error?: string
}

/** Poll snapshot of a bridge-side background job. */
export interface JobStatus extends ExecResult {
  jobId: string
  status: 'queued' | 'running' | 'done' | 'failed' | 'cancelled'
}

/** Host-authenticated provenance attached to one bridge execution. */
export interface OwnershipScope {
  sessionId: string
  callId: string
}

export interface UiCaptureOptions {
  target: string
  path?: string
  output_policy?: 'managed' | 'delivery' | 'explicit'
}

/** Runtime identity check for callers that bypass TypeScript types. Values
 *  must be nonempty, non-whitespace strings and are sent verbatim — never
 *  coerced or trimmed. Runs before any network request. */
function assertOwnership(owner: OwnershipScope, action: string): void {
  const valid = (value: unknown): value is string => typeof value === 'string' && value.trim() !== ''
  if (!owner || typeof owner !== 'object'
      || !valid((owner as OwnershipScope).sessionId) || !valid((owner as OwnershipScope).callId)) {
    throw new Error(
      `${action} requires the current Host session identity (agent.id and callId); `
      + 'missing, blank or mistyped identity is rejected before any Houdini request')
  }
}

/** Immutable installation/interpreter facts cached on Houdini's owning thread. */
export interface HoudiniRuntimeFacts {
  hfs: string
  python: string
  pythonVersion: string
  executable: string
}

export interface BridgeHealth {
  ok: boolean
  executorId?: string
  runtimeId?: string
  activeRequests?: number
  activeJobs?: number
  requestRef?: string
  sceneEpoch?: string
  houVersion?: string
  runtime?: HoudiniRuntimeFacts
  rawGate?: boolean
  executionContractVersion?: number
  verbCatalog?: {
    hash?: string
    count?: number
    names?: string[]
  }
  error?: string
}

/** Normalize a user-supplied base URL so path joins never produce double slashes. */
function normalizeBaseUrl(url: string): string {
  return url.replace(/\/+$/, '')
}

/** A call is pinned to one process and, for live work, one loaded scene. */
export interface BridgeTargetExpectation { runtimeId?:string; sceneEpoch?:string }

export class HoudiniBridge {
  readonly baseUrl: string

  constructor(baseUrl: string, private readonly timeoutMs: number, private readonly executorId?: string,
    private readonly lifetime?:AbortSignal, private readonly expectedTarget?:BridgeTargetExpectation) {
    this.baseUrl = normalizeBaseUrl(baseUrl)
    if (executorId !== undefined && !/^[0-9a-f]{32}$/.test(executorId)) throw new Error('Invalid Houdini executor identity')
  }

  private targetHeaders(): Record<string, string> {
    return this.executorId ? {'X-DSH-Houdini-Executor': this.executorId} : {}
  }

  /** Host routing identity, never a tool argument or node edit permission. */
  get targetExecutorId(): string | undefined { return this.executorId }
  get targetRuntimeId(): string | undefined { return this.expectedTarget?.runtimeId }
  get targetSceneEpoch(): string | undefined { return this.expectedTarget?.sceneEpoch }

  /** Historical results belong to a runtime, independent of its current loaded scene. */
  forRuntime(runtimeId:string):HoudiniBridge {
    if(!/^[0-9a-f]{32}$/.test(runtimeId))throw new Error('Invalid historical Houdini runtime')
    return new HoudiniBridge(this.baseUrl,this.timeoutMs,this.executorId,this.lifetime,{runtimeId})
  }

  private expectedTargetBody():Record<string,string> {
    return {...(this.expectedTarget?.runtimeId?{runtime_id:this.expectedTarget.runtimeId}:{}),
      ...(this.expectedTarget?.sceneEpoch?{scene_epoch:this.expectedTarget.sceneEpoch}:{})}
  }

  /** Non-HOM identity/contract check for an explicit target selection. */
  async inspectExecutor(signal?: AbortSignal): Promise<BridgeHealth> {
    return this.checkContract(signal)
  }

  /** Fixed Host/UI recovery protocol. No model-authored Python or file paths. */
  async recover(action:'assess'|'prepare'|'activate'|'locate'|'open',input:Record<string,unknown>,signal?:AbortSignal):Promise<any> {
    await this.checkContract(signal)
    const result=await this.post<any>('/recovery/'+action,{...input,expected_contract:this.expectedContract(),...this.expectedTargetBody()},signal)
    if(result.ok!==true)throw new Error(result.error||'工程接续未完成')
    return result
  }
  async claimWriter(taskId:string,registrationId:string,expectedHip:string,signal?:AbortSignal):Promise<void> {
    const result=await this.post<{ok:boolean;error?:string}>('/executor/claim',{
      task_id:taskId,registration_id:registrationId,expected_hip:expectedHip,...this.expectedTargetBody()},signal)
    if(result.ok!==true) throw new Error(result.error||'Writer reservation failed')
  }

  /** Run Python code in the Houdini session and wait for completion.
   *  allowRaw: one-time raw-hou exemption reason when the bridge gate is on.
   *  owner is mandatory: every HTTP execution carries the Host session
   *  identity, the per-call id and a one-time Bridge-issued ticket. */
  async exec(code: string, owner: OwnershipScope, signal?: AbortSignal, allowRaw?: string, readOnly = false, script?:ScriptSource): Promise<ExecResult> {
    assertOwnership(owner, 'Houdini execution')
    const { runtimeId, requestRef: ref } = await this.checkContract(signal, owner)
    const body: Record<string, unknown> = {
      code,
      owner_session: owner.sessionId,
      owner_call: owner.callId,
      expected_contract: this.expectedContract(),
      request_ref: ref,
    }
    if (allowRaw) body.allow_raw = allowRaw
    if (readOnly) body.read_only = 'true'
    if (script) body.script = script
    try {
      return await this.post<ExecResult>('/exec', body, signal)
    } catch (error) {
      if (!ref) throw error
      // HTTP status/body/JSON failures can all occur after side effects.
      return {ok:false,stdout:'',stderr:'',error:String(error),
        requestReceipt:{request_ref:ref,runtime_id:runtimeId!,status:'unknown_transport',
          ...(this.expectedTarget?.sceneEpoch?{scene_epoch:this.expectedTarget.sceneEpoch}:{}),
          ...(this.executorId ? {executor_id:this.executorId} : {}),
          next_action:'Use houdini_request(request_ref=...) to retrieve the admitted request. Do not resubmit the scene code.'}}
    }
  }

  /** Fixed UI-only navigation. Cancellation retires its issued/queued ticket;
   *  native navigation already running on the main thread completes normally. */
  async navigateNode(reference:{id:string}, expectedHip:string, owner:OwnershipScope, signal?:AbortSignal):Promise<ExecResult> {
    assertOwnership(owner,'Houdini node navigation')
    const interaction=AbortSignal.any([AbortSignal.timeout(this.timeoutMs),
      ...(signal?[signal]:[]),...(this.lifetime?[this.lifetime]:[])])
    const {requestRef:ref}=await this.checkContract(interaction,owner,'node_navigation')
    let cancellation:Promise<unknown>|undefined
    let cancellationError:unknown
    const cancel=()=>{
      if(cancellation)return
      // The interaction and plugin lifetime may both have ended. This cleanup
      // must still reach the registry, so only its own transport timeout applies.
      cancellation=this.requestJson<{ok:boolean;error?:string}>('/nodes/cancel',{
        method:'POST',headers:{'content-type':'application/json'},
        body:JSON.stringify({request_ref:ref,owner_session:owner.sessionId,owner_call:owner.callId,
          expected_contract:this.expectedContract()}),
      },undefined,0,false).then(result=>{
        if(!result.ok)throw new Error(result.error||'Node navigation cancellation failed')
      }).catch(error=>{cancellationError=error})
    }
    interaction.addEventListener('abort',cancel,{once:true})
    try {
      if(interaction.aborted)cancel()
      interaction.throwIfAborted()
      return await this.post<ExecResult>('/nodes/navigate',{
        reference,expected_hip:expectedHip,owner_session:owner.sessionId,owner_call:owner.callId,
        expected_contract:this.expectedContract(),request_ref:ref,
      },interaction)
    } finally {
      interaction.removeEventListener('abort',cancel)
      if(cancellation)await cancellation
      if(cancellationError)throw new Error('Node navigation cancellation could not be confirmed: '+String(cancellationError))
    }
  }

  /** Native UI preparation, binding refresh and capture yield to the normal GUI loop between
   *  main-thread queue stages. The original ticket remains recoverable. */
  async captureUi(options:UiCaptureOptions, owner:OwnershipScope, signal?:AbortSignal):Promise<ExecResult> {
    assertOwnership(owner,'Houdini UI capture')
    const {runtimeId,requestRef:ref}=await this.checkContract(signal,owner)
    try {
      return await this.post<ExecResult>('/ui/capture',{
        ...options,owner_session:owner.sessionId,owner_call:owner.callId,
        expected_contract:this.expectedContract(),request_ref:ref,
      },signal)
    } catch(error) {
      return {ok:false,stdout:'',stderr:'',error:String(error),requestReceipt:{
        request_ref:ref!,runtime_id:runtimeId!,status:'unknown_transport',
        ...(this.expectedTarget?.sceneEpoch?{scene_epoch:this.expectedTarget.sceneEpoch}:{}),
        ...(this.executorId?{executor_id:this.executorId}:{}),
        next_action:'Use houdini_request with this original reference to recover the UI capture. Do not start another capture while its result is unknown.',
      }}
    }
  }

  /** Discover currently visible UI targets on the existing main-thread queue. */
  async listUi(owner:OwnershipScope, signal?:AbortSignal):Promise<ExecResult> {
    assertOwnership(owner,'Houdini UI discovery')
    const {runtimeId,requestRef:ref}=await this.checkContract(signal,owner)
    try {
      return await this.post<ExecResult>('/ui/list',{
        owner_session:owner.sessionId,owner_call:owner.callId,
        expected_contract:this.expectedContract(),request_ref:ref,
      },signal)
    } catch(error) {
      return {ok:false,stdout:'',stderr:'',error:String(error),requestReceipt:{
        request_ref:ref!,runtime_id:runtimeId!,status:'unknown_transport',
        ...(this.expectedTarget?.sceneEpoch?{scene_epoch:this.expectedTarget.sceneEpoch}:{}),
        ...(this.executorId?{executor_id:this.executorId}:{}),
        next_action:'Use houdini_request with this original reference to recover the UI target discovery.',
      }}
    }
  }

  /** Queue Python code as a bridge-side background job; returns immediately. */
  async submitJob(code: string, owner: OwnershipScope, signal?: AbortSignal, allowRaw?: string, script?:ScriptSource): Promise<JobHandle> {
    assertOwnership(owner, 'Houdini job submission')
    const { runtimeId, requestRef: ref } = await this.checkContract(signal, owner)
    const body: Record<string, unknown> = {
      code,
      owner_session: owner.sessionId,
      owner_call: owner.callId,
      expected_contract: this.expectedContract(),
      request_ref: ref,
    }
    if (allowRaw) body.allow_raw = allowRaw
    if (script) body.script = script
    try {
      const handle = await this.post<JobHandle>('/jobs', body, signal)
      // Admission provenance must survive changing this conversation's default target.
      handle.requestReceipt = {...(handle.requestReceipt as Record<string,JsonValue>||{}),
        request_ref:ref!,runtime_id:runtimeId!,
        ...(!handle.requestReceipt?{status:'job_submitted'}:{}),
        ...(this.expectedTarget?.sceneEpoch?{scene_epoch:this.expectedTarget.sceneEpoch}:{}),
        ...(this.executorId?{executor_id:this.executorId}:{})}

      return handle
    }
    catch (error) {
      if (!ref) throw error
      return {error:String(error),requestReceipt:{request_ref:ref,runtime_id:runtimeId!,status:'unknown_transport',
          ...(this.expectedTarget?.sceneEpoch?{scene_epoch:this.expectedTarget.sceneEpoch}:{}),
        ...(this.executorId ? {executor_id:this.executorId} : {}),
        next_action:'Use houdini_request(request_ref=...) to recover the original jobId. Do not submit this job again.'}}
    }
  }

  private expectedContract() {
    return { version: EXPECTED_EXECUTION_CONTRACT_VERSION, hash: EXPECTED_VERB_CATALOG_HASH }
  }

  private async checkContract(signal?: AbortSignal, owner?: OwnershipScope, requestKind?:'node_navigation'): Promise<BridgeHealth> {
    // No cached handshake: the process can restart on the same port. Preparing
    // a ticket also returns the contract, so admission costs no extra round trip.
    const health = owner
      ? await this.post<BridgeHealth>('/requests/prepare', { owner_session: owner.sessionId,
        ...(requestKind?{request_kind:requestKind}:{}),...this.expectedTargetBody() }, signal)
      : await this.get<BridgeHealth>('/health', signal)
    if(this.expectedTarget?.runtimeId && health.runtimeId!==this.expectedTarget.runtimeId)
      throw new Error('所选 Houdini 的运行实例已变化，请重新选择现场。本次没有发送场景操作。')
    if(this.expectedTarget?.sceneEpoch && health.sceneEpoch!==this.expectedTarget.sceneEpoch)
      throw new Error('所选 Houdini 已切换或重新加载工程，请重新选择当前现场。本次没有发送场景操作。')
    const actual = health.verbCatalog
    if (this.executorId && health.executorId !== this.executorId) {
      throw new Error('当前连接指向另一个 Houdini，本次操作没有发送到工程。请从要操作的 Houdini 中重新打开 Open Workspace；同时开着多个窗口时，请先确认插件由哪个窗口使用。\n技术信息：Houdini executor mismatch: no scene code was submitted. Do not automatically rebind by port/HIP path.')
    }
    if (health.ok && actual?.hash === EXPECTED_VERB_CATALOG_HASH
        && health.executionContractVersion === EXPECTED_EXECUTION_CONTRACT_VERSION) {
      if (owner && (typeof health.runtimeId !== 'string' || typeof health.requestRef !== 'string'
          || !/^[0-9a-f]{32}\.[0-9a-f]{32}$/.test(health.requestRef)
          || !health.requestRef.startsWith(health.runtimeId + '.'))) {
        throw new Error('Houdini bridge did not prepare a valid same-runtime request ticket; no scene code was submitted. 修复并重启运行时 before retrying.')
      }
      return health
    }

    const expectedNames = new Set<string>(EXPECTED_VERB_NAMES)
    const actualNames = new Set(Array.isArray(actual?.names) ? actual.names : [])
    const missing = [...expectedNames].filter((name) => !actualNames.has(name))
    const extra = [...actualNames].filter((name) => !expectedNames.has(name))
    const detail = [
      `host=${EXPECTED_VERB_CATALOG_HASH.slice(0, 12)} (${EXPECTED_VERB_NAMES.length})`,
      `bridge=${actual?.hash?.slice(0, 12) ?? 'missing'} (${actual?.count ?? 'unknown'})`,
      `semantics=host:${EXPECTED_EXECUTION_CONTRACT_VERSION}/bridge:${health.executionContractVersion ?? 'missing'}`,
      missing.length ? `missing=${missing.join(',')}` : '',
      extra.length ? `extra=${extra.join(',')}` : '',
      health.error ? `health=${health.error}` : '',
    ].filter(Boolean).join('; ')
    throw new Error(
      'Houdini 连接版本不一致。请打开「DSH-Houdini → Version & Updates → 高级设置 → 运行诊断」，'
      + '选择「修复并重启运行环境」后重试。'
      + `\n诊断信息：Houdini bridge contract mismatch: ${detail}.`,
    )
  }

  /** Poll a bridge-side background job. Pass `wait` (seconds) to long-poll:
   *  the call waits for a terminal state or the requested duration. Read-only
   *  status queries are split below Node fetch's 300s response-header timeout.
   *  Job control is authorized by the owning session, so the request carries
   *  the current identity and expected contract; a non-HOM health check runs
   *  first so an old Bridge that ignores owner fields is rejected before any
   *  job state is read or changed (no ticket is prepared or code submitted). */
  async jobStatus(jobId: string, owner: OwnershipScope, wait?: number, signal?: AbortSignal): Promise<JobStatus> {
    assertOwnership(owner, 'Houdini job status')
    await this.checkContract(signal)
    const body: Record<string, unknown> = {
      owner_session: owner.sessionId,
      owner_call: owner.callId,
      expected_contract: this.expectedContract(),
      ...(this.expectedTarget?.runtimeId?{runtime_id:this.expectedTarget.runtimeId}:{}),
    }
    const route = `/jobs/${encodeURIComponent(jobId)}/status`
    if (!wait || wait <= 0) return this.post(route, body, signal)
    const deadline = performance.now() + Math.min(wait, 600) * 1000
    while (true) {
      signal?.throwIfAborted()
      // Extending AbortSignal alone does not extend Undici's default 300s
      // headersTimeout. Keep each status wait below it without changing the
      // process-wide dispatcher or retrying uncertain requests/submissions.
      const remaining = Math.max(0, (deadline - performance.now()) / 1000)
      const pollSeconds = Math.min(remaining, 240)
      const status = await this.post<JobStatus>(route, {...body, wait:pollSeconds},
        signal, pollSeconds * 1000 + 10000)
      if (!['queued','running'].includes(status.status) || performance.now() >= deadline) return status
    }
  }

  /** Cooperatively cancel a queued or running bridge-side job. */
  async cancelJob(jobId: string, owner: OwnershipScope, signal?: AbortSignal): Promise<JobStatus> {
    assertOwnership(owner, 'Houdini job cancellation')
    await this.checkContract(signal)
    return this.post(`/jobs/${encodeURIComponent(jobId)}/cancel`, {
      owner_session: owner.sessionId,
      owner_call: owner.callId,
      expected_contract: this.expectedContract(),
      ...(this.expectedTarget?.runtimeId?{runtime_id:this.expectedTarget.runtimeId}:{}),
    }, signal)
  }

  /**
   * Fetch image bytes from the bridge's `/media` endpoint. The bridge process
   * can read $HIP-side outputs that dsh-side tools (sandboxed to the session
   * workspace) cannot; the caller commits bytes to native DSH attachments.
   */
  async fetchMedia(path: string, signal?: AbortSignal, maxBytes = 32 * 1024 * 1024): Promise<Buffer> {
    const url = `${this.baseUrl}/media?path=${encodeURIComponent(path)}`
    let res: Response
    try {
      res = await fetch(url, { headers: this.targetHeaders(), signal: this.withTimeout(signal) })
    } catch (cause) {
      const reason = cause instanceof Error ? cause.message : String(cause)
      throw new Error(`cannot reach the Houdini bridge at ${this.baseUrl} (${reason})`)
    }
    if (!res.ok) {
      const detail = await res.text().catch(() => '')
      throw new Error(`bridge /media returned HTTP ${res.status}${detail ? `: ${detail}` : ''}`)
    }
    if (Number(res.headers.get('content-length')) > maxBytes) { await res.body?.cancel(); throw new Error('image exceeds attachment byte limit') }
    const chunks: Uint8Array[] = []
    let length = 0
    if (!res.body) throw new Error('empty image response')
    const reader = res.body.getReader()
    try {
      while (true) {
        const {done,value} = await reader.read()
        if (done) break
        length += value.length
        if (length > maxBytes) { await reader.cancel(); throw new Error('image exceeds attachment byte limit') }
        chunks.push(value)
      }
    } finally { reader.releaseLock() }
    return Buffer.concat(chunks)
  }

  /** Fixed, non-evaluating metadata route; old bridges degrade without executing code. */
  async sceneContext(signal?: AbortSignal): Promise<unknown> {
    const timeout = AbortSignal.timeout(2000)
    return this.post('/context', { schema_version: 1,...this.expectedTargetBody() },
      signal ? AbortSignal.any([signal, timeout]) : timeout)
  }

  async requestStatus(ref: string, owner: OwnershipScope, signal?: AbortSignal): Promise<ExecResult> {
    if (ref !== 'index' && !/^[0-9a-f]{32}\.[0-9a-f]{32}$/.test(ref)) throw new Error('request_ref must be index or an execution receipt returned by Houdini')
    assertOwnership(owner,'Houdini request status')
    // The historical connection is pinned to its original runtime, never the current scene.
    if(this.expectedTarget?.runtimeId)await this.checkContract(signal)
    return this.post('/requests/status',{request_ref:ref,owner_session:owner.sessionId},signal)
  }

  private withTimeout(signal: AbortSignal | undefined, extraMs = 0, honorLifetime = true): AbortSignal {
    // Monotonic-clock poll budgets can contain fractional milliseconds. The
    // native timer requires an integer; round up so transport keeps its margin.
    const timeout = AbortSignal.timeout(Math.ceil(this.timeoutMs + extraMs))
    return AbortSignal.any([timeout,...(signal?[signal]:[]),...(honorLifetime&&this.lifetime?[this.lifetime]:[])])
  }

  private async get<T>(path: string, signal?: AbortSignal): Promise<T> {
    return this.requestJson<T>(path, { method: 'GET' }, signal)
  }

  private async post<T>(path: string, body: unknown, signal?: AbortSignal, extraMs = 0): Promise<T> {
    return this.requestJson<T>(path, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    }, signal, extraMs)
  }

  private async requestJson<T>(
    path: string,
    init: RequestInit,
    signal?: AbortSignal,
    extraMs = 0,
    honorLifetime = true,
  ): Promise<T> {
    let res: Response
    try {
      res = await fetch(`${this.baseUrl}${path}`, {
        ...init,
        headers: {...Object.fromEntries(new Headers(init.headers)), ...this.targetHeaders()},
        signal: this.withTimeout(signal, extraMs, honorLifetime),
      })
    } catch (cause) {
      const reason = cause instanceof Error ? cause.message : String(cause)
      throw new Error(
        `Houdini bridge request ${path} at ${this.baseUrl} failed (${reason}); `
        + (init.method === 'POST' && ['/exec','/jobs','/ui/list','/ui/capture'].includes(path)
          ? 'execution may still be queued/running or already applied; inspect scene/job state before retrying, and do not blindly resubmit.'
          : 'check bridge availability; see README'),
      )
    }
    if (!res.ok) {
      const detail = await res.text().catch(() => '')
      throw new Error(`Houdini bridge ${path} returned HTTP ${res.status}${detail ? `: ${detail}` : ''}`)
    }
    try {
      return (await res.json()) as T
    } catch (cause) {
      const reason = cause instanceof Error ? cause.message : String(cause)
      throw new Error(`Houdini bridge ${path} returned a non-JSON response (${reason})`)
    }
  }
}
