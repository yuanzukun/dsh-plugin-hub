/**
 * Browser half of the dsh-home-ui plugin: mounts the DOM-side controller
 * (the [data-dsh-home-ui] scope attribute) and injects the global stylesheet
 * (home-ui.css) with this bundle as a <style data-plugin> tag. The stock GUI
 * stays byte-identical without the plugin row.
 *
 * Visual refinements, all via the plugin-owned sheet keyed under the scope:
 *   1. Sidebar palette unified with the conversation feed (same bg-base).
 *   2. Feed header aligned with the sidebar controls (same title line).
 *   3. Header hairline replaced by a soft gradient fade band.
 *
 * The former wide/standard feed-width mode was removed: official dsh now
 * ships its own content-width control, which supersedes the plugin's
 * [data-dsh-wide] attribute and its General-section preference row.
 */
// The client context type: cordis' Context merged with the plugin surfaces
// this program references (locale's Context merge below). The old
// `@deepseek-ai/dsh-client-runtime/client` module was removed upstream
// (dsh 0.1.2+); first-party plugins now type the apply parameter as the
// plain cordis Context.
import type { Context as ClientContext } from 'cordis'
// Type-only: pulls the locale plugin's Context merge (ctx.locale) — kept so
// any future locale-registered surface typechecks; the plugin currently
// declares the dependency its bundle was built against.
import type {} from '@deepseek-ai/dsh-client-locale/client'
import { HomeUiController } from './controller.ts'
// Plugin-owned global stylesheet (injected as a <style data-plugin> tag).
import './home-ui.css'

/**
 * Client plugin body: apply the visual-refinement scope with the plugin.
 * @param ctx - client cordis context.
 */
export function apply(ctx: ClientContext): void {
  // The [data-dsh-home-ui] scope (visual refinements) mounts with the plugin.
  ctx.effect(() => {
    const controller = new HomeUiController()
    controller.mount()
    return () => { controller.dispose() }
  }, 'dsh-home-ui: DOM controller')
}
