import { test } from "node:test";
import assert from "node:assert/strict";
import { cp, mkdtemp, readFile, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { decodeSessionBuffer, eventsSeqOk } from "../src/decode.mjs";
import { planRepair, repairFile } from "../src/repair.mjs";
import { containsLoneSurrogate } from "../src/redact.mjs";

const FIX = join(dirname(fileURLToPath(import.meta.url)), "../fixtures/synthetic");

async function copyFixture(name) {
  const dir = await mkdtemp(join(tmpdir(), "surgeon-repair-"));
  const dest = join(dir, "session.jsonl.zstd");
  await cp(join(FIX, name), dest);
  return dest;
}

test("decreasing seq is treated as overlap even when it equals the index", () => {
  const header = { version: 0, id: "session-overlap", createdAt: 1, delegationDepth: 0 };
  const events = [
    { type: "turn/start", seq: 0, time: 1, data: { turn: 1 } },
    { type: "turn/end", seq: 1, time: 2, data: { turn: 1, reason: { kind: "completed" } } },
    { type: "turn/start", seq: 2, time: 3, data: { turn: 2 } },
    { type: "turn/end", seq: 2, time: 4, data: { turn: 2, reason: { kind: "completed" } } },
  ];
  const plan = planRepair({
    header,
    headerClass: { ok: true, code: "header-ok", header },
    events,
    health: "ok",
    issues: [],
    failedFrames: 0,
  });
  assert.ok(plan.actions.some((a) => a.code === "seq-overlap-replay"));
  assert.ok(plan.events.every((event, i) => event.seq === i));
  assert.equal(plan.events.filter((e) => e.type === "turn/end" && e.seq === 2).length, 0);
});

test("apply on a healthy file reports dryRun false and wrote false", async () => {
  const dest = await copyFixture("healthy-packed.session.jsonl.zstd");
  const result = await repairFile(dest, { dryRun: false });
  assert.equal(result.dryRun, false);
  assert.equal(result.wrote, false);
  assert.equal(result.plan.mustWrite, false);
});

test("dry-run does not rewrite the file", async () => {
  const dest = await copyFixture("torn-tail.session.jsonl.zstd");
  const before = await readFile(dest);
  const result = await repairFile(dest, { dryRun: true });
  assert.equal(result.wrote, false);
  assert.deepEqual(await readFile(dest), before);
});

test("torn-tail --apply yields continuous seq and a turn/end", async () => {
  const dest = await copyFixture("torn-tail.session.jsonl.zstd");
  const result = await repairFile(dest, { dryRun: false });
  assert.equal(result.wrote, true);
  const after = decodeSessionBuffer(await readFile(dest));
  assert.ok(eventsSeqOk(after.events));
  assert.equal(after.events.at(-1)?.type, "turn/end");
  assert.equal(after.tornStart, undefined);
});

test("seq-gap-committed --apply keeps the last turn/end before the hole", async () => {
  const dest = await copyFixture("seq-gap-committed.session.jsonl.zstd");
  const result = await repairFile(dest, { dryRun: false });
  assert.equal(result.wrote, true);
  const after = decodeSessionBuffer(await readFile(dest));
  assert.ok(eventsSeqOk(after.events));
  assert.equal(after.events.at(-1)?.type, "turn/end");
  assert.ok(!after.events.some((e) => e.type === "turn/start" && e.data?.turn === 2));
});

test("lone-surrogate --apply strips isolated surrogates and keeps seq", async () => {
  const dest = await copyFixture("lone-surrogate.session.jsonl.zstd");
  const before = decodeSessionBuffer(await readFile(dest));
  const result = await repairFile(dest, { dryRun: false });
  assert.equal(result.wrote, true);
  const after = decodeSessionBuffer(await readFile(dest));
  assert.equal(after.events.length, before.events.length);
  assert.ok(eventsSeqOk(after.events));
  assert.equal(after.health, "ok");
  const dump = JSON.stringify(after.events);
  assert.equal(containsLoneSurrogate(dump), false);
});

test("zero-filled tail is diagnosed and dropped without losing a committed event (#9372)", async () => {
  const dest = await copyFixture("zero-fill-tail.session.jsonl.zstd");
  const clean = decodeSessionBuffer(await readFile(join(FIX, "healthy-packed.session.jsonl.zstd")));

  const damaged = decodeSessionBuffer(await readFile(dest));
  assert.equal(damaged.health, "zero-fill-tail");
  const issue = damaged.issues.find((i) => i.code === "zero-fill-tail");
  assert.equal(damaged.zeroTailBytes, 512);
  assert.match(issue.message, /512 zero byte/);
  assert.deepEqual(damaged.events, clean.events, "the committed prefix stays readable");

  const result = await repairFile(dest, { dryRun: false });
  assert.equal(result.wrote, true);
  assert.ok(result.plan.actions.some((a) => a.code === "zero-fill-tail"));
  const after = decodeSessionBuffer(await readFile(dest));
  assert.equal(after.health, "ok");
  assert.deepEqual(after.events, clean.events, "not one committed event changes");
  // The zeros are gone, and the frames now cover the whole file.
  const bytes = await readFile(dest);
  assert.equal(bytes.length, after.frames.at(-1).end);
});

test("mid-turn committed gap truncates to the previous turn/end, not an open turn", async () => {
  const { encodeSession } = await import("../src/encode.mjs");
  const { atomicWrite } = await import("../src/encode.mjs");
  const header = { version: 0, id: "session-midgap", createdAt: 1, delegationDepth: 0 };
  const events = [
    { type: "turn/start", seq: 0, time: 1, data: { turn: 1 } },
    { type: "turn/end", seq: 1, time: 2, data: { turn: 1, reason: { kind: "completed" } } },
    { type: "turn/start", seq: 2, time: 3, data: { turn: 2 } },
    { type: "user/message", seq: 3, time: 4, data: { id: "u", role: "user", source: { kind: "user" }, content: [{ type: "text", text: "x" }] } },
    { type: "assistant/message", seq: 9, time: 5, data: { turn: 2, step: 1, message: { id: "a", role: "assistant", source: { kind: "model", provider: "x", model: "y" }, content: [{ type: "text", text: "y" }] } } },
    { type: "turn/end", seq: 10, time: 6, data: { turn: 2, reason: { kind: "completed" } } },
  ];
  const dir = await (await import("node:fs/promises")).mkdtemp((await import("node:path")).join((await import("node:os")).tmpdir(), "surgeon-midgap-"));
  const dest = (await import("node:path")).join(dir, "session.jsonl.zstd");
  await atomicWrite(dest, await encodeSession({ header, events, packChunks: false }));
  const result = await repairFile(dest, { dryRun: false });
  assert.equal(result.wrote, true);
  const after = decodeSessionBuffer(await readFile(dest));
  assert.ok(eventsSeqOk(after.events));
  assert.equal(after.events.at(-1)?.type, "turn/end");
  assert.ok(!after.events.some((e) => e.type === "turn/start" && e.data?.turn === 2));
});

test("repair refuses a failed middle frame and does not write", async () => {
  const dest = await copyFixture("healthy-packed.session.jsonl.zstd");
  const before = await readFile(dest);
  const decoded = decodeSessionBuffer(before);
  decoded.failedFrames = 1;
  const { applyRepair } = await import("../src/repair.mjs");
  const result = await applyRepair({ file: dest, decoded, dryRun: false });
  assert.equal(result.wrote, false);
  assert.match(result.plan.refuse ?? "", /middle frame/);
  assert.deepEqual(await readFile(dest), before);
});

test("apply writes a .bak.* sibling", async () => {
  const dest = await copyFixture("torn-tail.session.jsonl.zstd");
  await repairFile(dest, { dryRun: false });
  const { readdir } = await import("node:fs/promises");
  const names = await readdir(dirname(dest));
  assert.ok(names.some((n) => n.startsWith("session.jsonl.zstd.bak.")));
});
