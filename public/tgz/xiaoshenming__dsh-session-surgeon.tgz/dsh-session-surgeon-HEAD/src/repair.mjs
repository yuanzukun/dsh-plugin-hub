import { readFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { decodeSessionBuffer, eventsSeqOk, missingMessageIds } from "./decode.mjs";
import { backupThenWrite, encodeSession } from "./encode.mjs";
import { interruptedTurnClosers } from "./closers.mjs";
import { replaceLoneSurrogatesIn } from "./redact.mjs";
import { stitchLiveWriterTail } from "./stitch.mjs";
import { applyMigrationFixes, MIGRATES_V0_ON_LOAD } from "./migrate.mjs";
import { applyForwardEventShims } from "./forward-events.mjs";
import { rewriteLiteralPluginSources } from "./message-shapes.mjs";
import { disambiguateDuplicateToolCallIds } from "./duplicates.mjs";
import { planPruneTail, prunePassHits } from "./prune-tail.mjs";
import { turnStepImbalances } from "./turn-step.mjs";
import { wrapFlatReplayStates } from "./replay-state.mjs";
import { repairRetryChains, retryChainHits } from "./retry-chains.mjs";
import { ptcHits, repairPtcSubCallIds } from "./ptc.mjs";
import { settleAssistantFields } from "./settle.mjs";
import { INSTALLED_CATALOG } from "./runtime.mjs";

const DEFAULT_STEPS = {
  tornTail: true,
  zeroFillTail: true,
  overlap: true,
  committedGap: true,
  dropDirtyTail: true,
  liveWriter: true,
  packedOverlap: true,
  forwardEvents: true,
  compressedRanges: true,
  v0Migration: true,
  duplicateToolCalls: true,
  literalPluginSource: true,
  pruneTail: true,
  legacyReplayState: true,
  retryChains: true,
  ptcSubCalls: true,
  loneSurrogate: true,
  messageId: true,
  settlement: true,
  closers: true,
};

function lastTurnEndIndex(events) {
  for (let i = events.length - 1; i >= 0; i--) {
    if (events[i].type === "turn/end") return i;
  }
  return -1;
}

function firstGapIndex(events) {
  for (let i = 0; i < events.length; i++) {
    if (events[i].seq !== i) return i;
  }
  return -1;
}

/** Fill a non-empty id into user/message, assistant/message and tool/result
 *  events that the official replay boundary would refuse. Never drops events. */
function fillMissingMessageIds(events) {
  const seqs = missingMessageIds(events);
  if (seqs.length === 0) return { value: events, fixed: 0 };
  const value = events.map((event) => {
    const type = event.type;
    if (type !== "user/message" && type !== "assistant/message" && type !== "tool/result") return event;
    const data = event.data;
    const record = data && typeof data === "object" ? data : undefined;
    const message = type === "user/message" ? record : record?.message;
    if (!message || typeof message !== "object" || (typeof message.id === "string" && message.id !== "")) {
      return event;
    }
    const patched = { ...message, id: randomUUID() };
    if (type === "user/message") {
      return { ...event, data: { ...record, ...patched } };
    }
    return { ...event, data: { ...record, message: patched } };
  });
  return { value, fixed: seqs.length };
}

/**
 * Plan a repair against an already-decoded buffer.
 * Never invents missing seqs in the committed middle.
 */
export function planRepair(decoded, { steps: stepOverrides } = {}) {
  const steps = { ...DEFAULT_STEPS, ...stepOverrides };
  const actions = [];
  const header = decoded.header;
  const headerCode = decoded.headerClass?.code ?? (header ? "header-ok" : "header-frame-corrupt");

  // A newer generation than the installed runtime has no decoded header, so
  // this has to be checked before the "cannot be decoded" branch: the user
  // needs "upgrade the harness", not a corrupt-header message.
  if (headerCode === "foreign-version") {
    return { actions, events: [], header, mustWrite: false, refuse: "foreign format version — upgrade the harness" };
  }
  if (!header || headerCode === "header-frame-corrupt" || headerCode === "header-parse-error") {
    return { actions, events: [], header, mustWrite: false, refuse: "header cannot be decoded" };
  }
  if (headerCode === "retired-fields") {
    return { actions, events: [], header, mustWrite: false, refuse: "header carries retired policy fields" };
  }
  if (decoded.failedFrames > 0) {
    return { actions, events: decoded.events.slice(), header, mustWrite: false, refuse: "middle frame failed decompression" };
  }

  let events = decoded.events.map((event) => event);
  const overflow = Array.isArray(decoded.overflow) ? decoded.overflow : [];
  let stitchedLive = false;

  if (steps.liveWriter) {
    const stitched = stitchLiveWriterTail(events, overflow);
    if (stitched) {
      events = stitched.events;
      stitchedLive = true;
      actions.push({
        code: "live-writer-tail",
        detail:
          "dropped " +
          stitched.droppedClosers +
          " crash-recovery closer(s) and kept " +
          stitched.keptLive +
          " live-writer event(s) from seq " +
          stitched.stitchSeq,
      });
    }
  }

  const shimWanted = INSTALLED_CATALOG
    ? !INSTALLED_CATALOG.has("model/selection")
    : decoded.unknownTypes?.includes("model/selection");
  if (steps.forwardEvents && shimWanted) {
    const shimmed = applyForwardEventShims(events);
    if (shimmed.shims.length > 0) {
      events = shimmed.value;
      actions.push({
        code: "forward-event-shim",
        detail:
          "marked " +
          shimmed.shims.map((shim) => `${shim.type}@${shim.seq}`).join(", ") +
          " ignorable for older harnesses; preserved type, data, seq, and time",
      });
    }
  }

  const rangeFix = steps.compressedRanges && decoded.health === "newer-format-ranges";
  const converterFix =
    steps.v0Migration && MIGRATES_V0_ON_LOAD &&
    typeof decoded.health === "string" && decoded.health.startsWith("v0-");
  if (rangeFix || converterFix) {
    try {
      const fixed = applyMigrationFixes(events, {
        expandRanges: rangeFix,
        converters: converterFix,
      });
      events = fixed.value;
      actions.push(...fixed.actions);
    } catch (error) {
      return {
        actions,
        events,
        header,
        mustWrite: false,
        refuse: error instanceof Error ? error.message : "migration fix failed",
      };
    }
  }

  if (steps.legacyReplayState && decoded.health === "legacy-replay-state") {
    const wrapped = wrapFlatReplayStates(events);
    if (wrapped.wrapped > 0) {
      events = wrapped.value;
      actions.push({
        code: "legacy-replay-state",
        detail:
          "wrapped " +
          wrapped.wrapped +
          " flat pi-ai replayState field(s) into {response, blocks} (#5694/#5909)",
      });
    }
  }

  if (steps.retryChains && (decoded.health === "llm-retry-chain" || retryChainHits(events).seqs.length > 0)) {
    const chains = repairRetryChains(events);
    if (chains.refusals.length > 0) {
      return {
        actions,
        events: decoded.events.slice(),
        header,
        mustWrite: false,
        refuse:
          "cannot repair the llm/retry chains — " +
          chains.refusals.slice(0, 3).join("; ") +
          " (#9163); the attempt number and chain id are not recoverable from this log",
      };
    }
    if (chains.fixed > 0) {
      events = chains.value;
      actions.push({
        code: "llm-retry-chain",
        detail: "renumbered " + chains.fixed + " llm/retry row(s) inside their policy chains (#9163)",
      });
    }
  }

  if (steps.ptcSubCalls && (decoded.health === "ptc-dispatch-invalid" || ptcHits(events).length > 0)) {
    const renumbered = repairPtcSubCallIds(events);
    if (renumbered.renamed > 0) {
      // A repeated id is only one of the ways this family is refused. Renaming
      // cannot fix a dispatch that disagrees with its own start, so the result
      // has to come back clean or nothing is written.
      const still = ptcHits(renumbered.value);
      if (still.length > 0) {
        return {
          actions,
          events: decoded.events.slice(),
          header,
          mustWrite: false,
          refuse:
            "cannot repair the PTC dispatches — " +
            still[0].type +
            " at seq " +
            still[0].seq +
            ": " +
            still[0].detail +
            " (#9677); renaming a repeated sub-call id fixes only the repetition, and this row is refused for another reason",
        };
      }
      events = renumbered.value;
      actions.push({
        code: "ptc-dispatch-invalid",
        detail: "renamed " + renumbered.renamed + " row(s) in repeated PTC sub-call occurrence(s), leaving every first id untouched (#9677)",
      });
    } else if (decoded.health === "ptc-dispatch-invalid") {
      const first = ptcHits(events)[0];
      return {
        actions,
        events: decoded.events.slice(),
        header,
        mustWrite: false,
        refuse:
          "cannot repair the PTC dispatches — " +
          (first === undefined ? "no repeated sub-call id found" : first.type + " at seq " + first.seq + ": " + first.detail) +
          " (#9677); a repeated id can be renamed, this row cannot",
      };
    }
  }

  if (steps.duplicateToolCalls && decoded.health === "duplicate-tool-call-id") {
    const rewritten = disambiguateDuplicateToolCallIds(events);
    if (rewritten.rewritten > 0) {
      events = rewritten.value;
      actions.push({
        code: "duplicate-tool-call-id",
        detail:
          "suffixed " +
          rewritten.rewritten +
          " later duplicate advertised tool-call id(s) in the same step (#5909)",
      });
    }
  }

  if (steps.pruneTail && decoded.health === "prune-tail-outside-turn") {
    const planned = planPruneTail(events);
    if ("refuse" in planned) {
      return { actions, events, header, mustWrite: false, refuse: planned.refuse };
    }
    const kept = events.slice(0, planned.cutIndex + 1);
    // Cutting the tail must leave nothing else behind: the dropped rows are
    // themselves step-scoped, so the sibling detector would have flagged them.
    if (prunePassHits(kept).length > 0 || turnStepImbalances(kept).length > 0) {
      return {
        actions,
        events,
        header,
        mustWrite: false,
        refuse: "truncating the idle prune pass would leave another refusal behind, so repair would trade one unloadable log for another",
      };
    }
    events = kept;
    actions.push({
      code: "prune-tail-outside-turn",
      detail:
        "dropped " + planned.dropped + " idle-prune event(s) (" + planned.types.join(", ") +
        ") after turn/end at seq " + planned.cutSeq + " (#8812); every replacement only shadowed surface nodes that are still in the log, so no message, turn or tool result is lost",
    });
  }

  if (steps.literalPluginSource && decoded.health === "v4-literal-plugin-source") {
    const literal = rewriteLiteralPluginSources(events);
    if (literal.rewritten > 0) {
      events = literal.value;
      actions.push({
        code: "v4-literal-plugin-source",
        detail:
          "replaced " + literal.rewritten +
          " retired {kind:\"plugin\", plugin} message source(s) with the producer kind the released v3→v4 stage derives for that name (#7772)",
      });
    }
  }

  if (steps.packedOverlap && (decoded.packedOverlapKept ?? 0) > 0) {
    actions.push({
      code: "packed-overlap-suffix",
      detail:
        "kept " +
        decoded.packedOverlapKept +
        " event(s) after a packed row's already-committed prefix",
    });
  }

  if (!stitchedLive && decoded.health === "seq-gap-committed" && steps.committedGap) {
    const keepThrough = lastTurnEndIndex(events);
    events = keepThrough >= 0 ? events.slice(0, keepThrough + 1) : events;
    actions.push({
      code: "seq-gap-committed",
      detail: "truncated to last turn/end before the committed gap",
    });
  } else if (!stitchedLive && decoded.health === "seq-gap-tail" && steps.dropDirtyTail) {
    actions.push({
      code: "seq-gap-tail",
      detail: "rewrite committed prefix, dropping the on-disk dirty tail",
    });
  } else if (decoded.health === "unparsable-line" && steps.dropDirtyTail) {
    actions.push({
      code: "unparsable-line",
      detail: "rewrite committed prefix, dropping the on-disk dirty tail",
    });
  }

  if (steps.tornTail && decoded.tornStart !== undefined) {
    actions.push({ code: "torn-tail", detail: "dropped incomplete frame at byte " + decoded.tornStart });
  }

  if (steps.zeroFillTail && decoded.zeroTailAt !== undefined) {
    actions.push({
      code: "zero-fill-tail",
      detail: "dropped " + (decoded.zeroTailBytes ?? 0) + " zero byte(s) after byte " + decoded.zeroTailAt,
    });
  }

  if (steps.overlap) {
    let cut = -1;
    const seen = new Set();
    for (let i = 0; i < events.length; i++) {
      const seq = events[i].seq;
      if (seen.has(seq) || (i > 0 && seq <= events[i - 1].seq)) {
        cut = i;
        break;
      }
      seen.add(seq);
    }
    if (cut >= 0) {
      events = events.slice(0, cut);
      actions.push({ code: "seq-overlap-replay", detail: "dropped replay tail from index " + cut });
    }
  }

  const gapAt = firstGapIndex(events);
  if (gapAt >= 0) {
    const rest = events.slice(gapAt);
    const hasTurnEnd = rest.some((event) => event.type === "turn/end");
    if (hasTurnEnd && steps.committedGap) {
      const keepThrough = lastTurnEndIndex(events.slice(0, gapAt));
      events = keepThrough >= 0 ? events.slice(0, keepThrough + 1) : [];
      actions.push({ code: "seq-gap-committed", detail: "truncated to last turn/end before gap at " + gapAt });
    } else if (steps.dropDirtyTail) {
      events = events.slice(0, gapAt);
      actions.push({ code: "seq-gap-tail", detail: "dropped dirty tail from index " + gapAt });
    }
  }

  if (steps.loneSurrogate) {
    const swept = replaceLoneSurrogatesIn(events);
    if (swept.replaced > 0) {
      events = swept.value;
      actions.push({ code: "lone-surrogate", detail: "replaced " + swept.replaced + " lone-surrogate string(s)" });
    }
  }

  if (steps.messageId) {
    const filled = fillMissingMessageIds(events);
    if (filled.fixed > 0) {
      events = filled.value;
      actions.push({ code: "message-missing-id", detail: "filled " + filled.fixed + " missing message id(s)" });
    }
  }

  // The settlement gate is a current-generation invariant: a released v0 row
  // may legitimately carry no `stream` at all, so v0 is left to v0-missing-member.
  const fileVersion = decoded.header?.version;
  if (steps.settlement && typeof fileVersion === "number" && fileVersion >= 1) {
    const settled = settleAssistantFields(events);
    if (settled.actions.length > 0) {
      events = settled.value;
      actions.push(...settled.actions);
    }
  }

  if (steps.closers) {
    const closers = interruptedTurnClosers(events);
    if (closers.length > 0) {
      events = events.concat(closers);
      actions.push({ code: "open-tail", detail: "appended " + closers.length + " synthetic closer(s)" });
    }
  }

  if (!eventsSeqOk(events)) {
    return { actions, events, header, mustWrite: false, refuse: "repair did not produce continuous seq" };
  }

  const mustWrite = actions.length > 0;
  return { actions, events, header, mustWrite, refuse: undefined };
}

export async function applyRepair({ file, decoded, dryRun = true, steps } = {}) {
  const plan = planRepair(decoded ?? decodeSessionBuffer(await readFile(file)), { steps });
  if (plan.refuse) {
    return { dryRun, wrote: false, plan, afterHealth: decoded?.health };
  }
  if (dryRun || !plan.mustWrite) {
    return { dryRun, wrote: false, plan, afterHealth: decoded?.health };
  }
  const buf = await encodeSession({ header: plan.header, events: plan.events });
  await backupThenWrite(file, buf);
  const after = decodeSessionBuffer(await readFile(file));
  if (!eventsSeqOk(after.events)) {
    throw new Error("post-repair seq is not continuous; original preserved in .bak.*");
  }
  return { dryRun: false, wrote: true, backup: true, plan, afterHealth: after.health };
}

export async function repairFile(file, { dryRun = true, steps } = {}) {
  const decoded = decodeSessionBuffer(await readFile(file));
  return applyRepair({ file, decoded, dryRun, steps });
}
