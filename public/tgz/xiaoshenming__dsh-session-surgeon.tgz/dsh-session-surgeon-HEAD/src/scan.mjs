import { readFile, stat } from "node:fs/promises";
import { classifyHeader } from "./header.mjs";
import { decodeFrames } from "./zstd-frames.mjs";
import { isExactHeaderRecord } from "./scanner.mjs";
import { defaultSessionRoot, listSessionFiles } from "./find.mjs";

export { defaultSessionRoot, listSessionFiles };

/**
 * Header-only listing of one session artifact.
 * Full inspect lives in src/inspect.mjs.
 */
export async function scanHeader(entry) {
  const orphanTmp = Array.isArray(entry.tmpFiles) && entry.tmpFiles.length > 0;
  const flags = orphanTmp ? ["orphan-tmp"] : [];
  if (!entry.file || !entry.kind) {
    return {
      ...entry,
      bytes: 0,
      mtimeMs: 0,
      health: "orphan-tmp",
      orphanTmp: true,
      flags,
      note: "tmp present but no canonical session log",
    };
  }
  const st = await stat(entry.file);
  const base = { ...entry, bytes: st.size, mtimeMs: st.mtimeMs, orphanTmp, flags };

  if (entry.kind !== "zstd") {
    return { ...base, health: "raw-jsonl", note: "uncompressed log" };
  }

  const buf = await readFile(entry.file);
  let frames;
  try {
    frames = decodeFrames(buf);
  } catch (error) {
    return {
      ...base,
      frames: 0,
      health: "header-frame-corrupt",
      error: error instanceof Error ? error.message : String(error),
    };
  }
  if (frames.length === 0) {
    return { ...base, frames: 0, health: "no-zstd-frame" };
  }
  const headerFrame = frames[0];
  // Same split as `decode.mjs`: a file compressed into one frame is refused by
  // the reader for the frame boundary alone, and its first line is still a
  // header (discussion #10440).
  let headerText = headerFrame.text ?? "";
  let multiline = false;
  if (headerFrame.ok && !headerFrame.torn && !isExactHeaderRecord(headerText)) {
    const cut = headerText.indexOf("\n");
    const firstLine = cut < 0 ? headerText : headerText.slice(0, cut + 1);
    if (cut >= 0 && isExactHeaderRecord(firstLine) && cut + 1 < headerText.length) {
      multiline = true;
      headerText = firstLine;
    }
  }
  if (!headerFrame.ok || headerFrame.torn || !isExactHeaderRecord(headerText)) {
    return {
      ...base,
      frames: frames.length,
      health: "header-frame-corrupt",
      error: headerFrame.error ?? "corrupt Zstandard session log: first frame is not exactly one header line",
    };
  }
  const classified = classifyHeader(headerText);
  const failed = frames.filter((f) => !f.ok && !f.torn).length;
  const torn = frames.some((f) => f.torn);
  let health = classified.ok
    ? (multiline ? "header-frame-multiline" : failed ? "failed-middle-frame" : "header-ok")
    : classified.code;
  if (torn && classified.ok && health === "header-ok") flags.push("torn-tail");
  return {
    ...base,
    frames: frames.length,
    failedFrames: failed,
    health,
    // Absent members are omitted, never present-as-`undefined`: the payload has
    // to be lossless JSON, and one `undefined` member made the harness refuse
    // the entire report ("value is not lossless JSON"). A healthy session used
    // to carry `error: undefined` on every entry, so session_scan never worked.
    ...(classified.ok ? { header: classified.header } : {}),
    ...(classified.ok ? {} : { error: classified.error }),
    flags,
  };
}

export async function scanAll(root) {
  const entries = await listSessionFiles(root);
  const sessions = [];
  for (const entry of entries) sessions.push(await scanHeader(entry));
  return { root, count: sessions.length, sessions };
}
