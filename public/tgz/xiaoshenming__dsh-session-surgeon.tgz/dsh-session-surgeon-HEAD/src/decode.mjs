import { decodeFrames, scanZstdFrames } from "./zstd-frames.mjs";
import { classifyHeader } from "./header.mjs";
import { loneSurrogateLocations } from "./redact.mjs";
import { SessionLogScanner, isExactHeaderRecord } from "./scanner.mjs";
import { hasCompressedSeqRanges } from "./provenance.mjs";
import { MIGRATION_REFUSES_DUPLICATE_TOOL_CALL_IDS, SUPPORTS_NATIVE_SEQ_RANGES } from "./runtime.mjs";
import { forwardEventShims } from "./forward-events.mjs";
import { danglingToolCalls, emptyToolCallIds, missingMessageIds } from "./integrity.mjs";
import { duplicateAdvertisedToolCallIds } from "./duplicates.mjs";
import { flatReplayStateHits } from "./replay-state.mjs";
import { MIGRATES_V0_ON_LOAD, migrationRefusalIssues } from "./migrate.mjs";
import { missingMemberHits } from "./released-shape.mjs";
import { settlementShapeHits } from "./settlement.mjs";
import { catalogFactHits } from "./catalog-fact.mjs";
import { literalPluginSourceHits, producerSourceHits } from "./message-shapes.mjs";
import { turnStepImbalances, turnStepIssuesFrom } from "./turn-step.mjs";
import { prunePassHits } from "./prune-tail.mjs";
import { retryChainHits } from "./retry-chains.mjs";
export { danglingToolCalls, emptyToolCallIds, missingMessageIds } from "./integrity.mjs";
export { duplicateAdvertisedToolCallIds } from "./duplicates.mjs";
export { turnStepImbalances } from "./turn-step.mjs";
export { prunePassHits, planPruneTail } from "./prune-tail.mjs";

/** Worst-first list of every health code `decodeSessionBuffer` can report. */
export const HEALTH_RANK = [
  "header-frame-corrupt",
  "header-parse-error",
  "foreign-version",
  "retired-fields",
  "newer-format-ranges",
  "failed-middle-frame",
  "seq-gap-committed",
  "unparsable-line",
  "duplicate-tool-call-id",
  "legacy-replay-state",
  "v0-preset-extra-member",
  "v0-descriptor-version",
  "v0-plugin-source-form",
  "v0-chunk-provenance",
  "v0-retired-source-kind",
  "v0-inbox-inserted-message",
  "v0-missing-member",
  "invalid-settlement-fields",
  "descriptor-catalog-fact",
  "v4-literal-plugin-source",
  "producer-source-invalid",
  "prune-tail-outside-turn",
  "turn-end-while-step-open",
  "step-after-turn-end",
  "seq-gap-tail",
  "message-missing-id",
  "llm-retry-chain",
  "lone-surrogate",
  "zero-fill-tail",
  "torn-tail",
  "packed-overlap-suffix",
  "unknown-type",
  "empty-tool-call-id",
  "dangling-tool-call",
  "ok",
];

function rank(code) {
  const i = HEALTH_RANK.indexOf(code);
  return i === -1 ? HEALTH_RANK.length : i;
}

function worse(current, next) {
  return rank(next) < rank(current) ? next : current;
}

function emptyResult({ headerClass, frames, tornStart, zeroTailAt, issues, failedFrames, health, unknownTypes }) {
  return {
    header: headerClass.header ?? null,
    headerClass,
    frames,
    // Omit an absent torn tail instead of carrying `undefined`. The tool payload
    // has to be lossless JSON and the harness rejects a value holding
    // `undefined` outright ("value is not lossless JSON" for the whole report).
    ...(tornStart === undefined ? {} : { tornStart }),
    ...(zeroTailAt === undefined ? {} : { zeroTailAt }),
    events: [],
    overflow: [],
    issues,
    logicalLines: 0,
    packedRows: 0,
    packedOverlapKept: 0,
    overflowEvents: 0,
    failedFrames,
    unknownTypes,
    lastSeq: -1,
    // Callers read these as arrays (`inspectEntry` iterates turnStepImbalances).
    // An early return that omitted them made inspect throw "not iterable".
    turnStepImbalances: [],
    pruneHits: [],
    missingMembers: [],
    settlementHits: [],
    catalogHits: [],
    health,
  };
}

/**
 * Decode a session.jsonl.zstd buffer into the committed event prefix.
 * Complete frames are concatenated into one SessionLogScanner (official path).
 */
export function decodeSessionBuffer(buf) {
  const unknownTypes = [];
  let health = "ok";
  let scanned;
  try {
    scanned = scanZstdFrames(buf);
  } catch (error) {
    return emptyResult({
      headerClass: { ok: false, code: "header-frame-corrupt", error: String(error) },
      frames: [],
      tornStart: undefined,
      issues: [{ code: "header-frame-corrupt", message: String(error) }],
      failedFrames: 0,
      health: "header-frame-corrupt",
      unknownTypes,
    });
  }

  const frames = decodeFrames(buf);
  const failedFrames = frames.filter((f) => !f.ok && !f.torn).length;
  const tornStart = scanned.tornStart;

  if (frames.length === 0) {
    return emptyResult({
      headerClass: { ok: false, code: "header-frame-corrupt", error: "no-zstd-frame" },
      frames,
      tornStart,
      issues: [{ code: "header-frame-corrupt", message: "no zstd frame" }],
      failedFrames,
      health: "header-frame-corrupt",
      unknownTypes,
    });
  }

  const headerFrame = frames[0];
  if (!headerFrame.ok || headerFrame.torn || !isExactHeaderRecord(headerFrame.text ?? "")) {
    const issues = [{
      code: "header-frame-corrupt",
      message: headerFrame.error ?? "corrupt Zstandard session log: first frame is not exactly one header line",
      frame: 0,
    }];
    return emptyResult({
      headerClass: { ok: false, code: "header-frame-corrupt", error: issues[0].message },
      frames,
      tornStart,
      issues,
      failedFrames,
      health: "header-frame-corrupt",
      unknownTypes,
    });
  }

  const headerClass = classifyHeader(headerFrame.text);
  if (!headerClass.ok) {
    health = headerClass.code === "foreign-version" || headerClass.code === "retired-fields"
      ? headerClass.code
      : "header-parse-error";
    return emptyResult({
      headerClass,
      frames,
      tornStart,
      issues: [{ code: health, message: headerClass.error ?? health, line: 0, frame: 0 }],
      failedFrames,
      health,
      unknownTypes,
    });
  }

  const scanner = new SessionLogScanner(Buffer.from(headerFrame.text, "utf8"));
  const issues = [];
  let tornText = null;

  for (let fi = 1; fi < frames.length; fi++) {
    const frame = frames[fi];
    if (!frame.ok && !frame.torn) {
      health = worse(health, "failed-middle-frame");
      issues.push({ code: "failed-middle-frame", message: frame.error ?? "frame failed", frame: fi });
      continue;
    }
    if (!frame.ok || frame.text == null) continue;
    if (frame.torn) {
      tornText = frame.text;
      continue;
    }
    scanner.write(Buffer.from(frame.text, "utf8"));
  }

  const complete = scanner.checkpoint();
  if (complete.committedBytes !== complete.inputBytes && scanner.issue == null) {
    const next = {
      code: "unparsable-line",
      message: "complete frame contains a torn JSONL record",
    };
    scanner.issue = next;
    scanner.issues.push(next);
  }
  if (tornText != null) scanner.write(Buffer.from(tornText, "utf8"));

  const finished = scanner.finish();
  issues.push(...finished.issues);
  unknownTypes.push(...finished.unknownTypes);

  for (const issue of finished.issues) {
    if (issue.code === "seq-gap-committed") health = worse(health, "seq-gap-committed");
    else if (issue.code === "seq-gap-tail") health = worse(health, "seq-gap-tail");
    else if (issue.code === "unparsable-line") health = worse(health, "unparsable-line");
    else if (issue.code === "packed-overlap-suffix") health = worse(health, "packed-overlap-suffix");
  }
  if (failedFrames > 0) health = worse(health, "failed-middle-frame");
  if (tornStart !== undefined) {
    health = worse(health, "torn-tail");
    if (!issues.some((i) => i.code === "torn-tail")) {
      issues.push({ code: "torn-tail", message: "incomplete final frame at byte " + tornStart });
    }
  }
  const zeroTailAt = scanned.zeroTailAt;
  if (zeroTailAt !== undefined) {
    health = worse(health, "zero-fill-tail");
    if (!issues.some((i) => i.code === "zero-fill-tail")) {
      issues.push({
        code: "zero-fill-tail",
        message:
          `the file grew to ${buf.length} bytes but the frame data after byte ${zeroTailAt} never reached disk — it reads back as ${buf.length - zeroTailAt} zero byte(s) (#9372); every committed frame before it is intact, and repair drops the zeros`,
      });
    }
  }
  const surrogate = loneSurrogateLocations(headerClass.header, finished.events);
  if (surrogate.total > 0) {
    health = worse(health, "lone-surrogate");
    if (!issues.some((i) => i.code === "lone-surrogate")) {
      const where = [];
      if (surrogate.seqs.length > 0) {
        where.push(surrogate.seqs.map((seq, i) => `seq ${seq} (${surrogate.types[i]})`).join(", "));
      }
      if (surrogate.inHeader) where.push("the header");
      const issue = {
        code: "lone-surrogate",
        message:
          `isolated UTF-16 surrogate in ${where.join(" and ")} — JSON.stringify escapes it and the provider rejects every later request body (HTTP 400, #8466); repair replaces it with U+FFFD` +
          (surrogate.inHeader
            ? ", but a surrogate in the header is only reported: the header names the directory this log lives in"
            : ""),
      };
      if (surrogate.seqs.length > 0) issue.seqs = surrogate.seqs;
      issues.push(issue);
    }
  }
  const compressedRanges =
    hasCompressedSeqRanges(finished.events) || hasCompressedSeqRanges(finished.overflow ?? []);
  if (compressedRanges && !SUPPORTS_NATIVE_SEQ_RANGES) {
    health = worse(health, "newer-format-ranges");
    if (!issues.some((i) => i.code === "newer-format-ranges")) {
      issues.push({
        code: "newer-format-ranges",
        message:
          "sourceEventSeqs uses compressed [start,end] ranges (still labeled v0); this harness cannot expand them — repair writes dense integers so foldSurface can load the file",
      });
    }
  }
  if (finished.unknownTypes.length > 0) {
    health = worse(health, "unknown-type");
    if (!issues.some((i) => i.code === "unknown-type")) {
      issues.push({ code: "unknown-type", message: "unknown types: " + finished.unknownTypes.join(", ") });
    }
  }
  const unknownTypeSet = new Set(finished.unknownTypes);
  const forwardShims = forwardEventShims(
    finished.events.filter((event) => unknownTypeSet.has(event.type)),
  );
  if (forwardShims.length > 0) {
    issues.push({
      code: "forward-event-shim",
      message:
        "validated newer official log-only event(s) can be marked ignorable for this harness: " +
        forwardShims.map((shim) => `${shim.type}@${shim.seq}`).join(", "),
      seqs: forwardShims.map((shim) => shim.seq),
    });
  }
  const duplicateIds = duplicateAdvertisedToolCallIds(finished.events);
  if (duplicateIds.length > 0) {
    const seqs = duplicateIds.map((d) => d.seq);
    const message =
      "assistant/message repeats advertised tool call at seq " +
      seqs.join(", ") +
      (MIGRATION_REFUSES_DUPLICATE_TOOL_CALL_IDS
        ? " — 0.1.3+ v0→v1 migration refuses the session (#5909); repair suffixes later duplicates"
        : " — v0 harness still loads; 0.1.3+ migration will refuse (#5909)");
    if (MIGRATION_REFUSES_DUPLICATE_TOOL_CALL_IDS) {
      health = worse(health, "duplicate-tool-call-id");
    }
    if (!issues.some((i) => i.code === "duplicate-tool-call-id")) {
      issues.push({
        code: "duplicate-tool-call-id",
        message,
        seqs,
        callIds: duplicateIds.map((d) => d.callId),
      });
    }
  }
  const replayHits = flatReplayStateHits(finished.events);
  if (replayHits.length > 0) {
    const message =
      "flat pi-ai replayState (unexpected member kind) at seq " +
      replayHits.join(", ") +
      (MIGRATION_REFUSES_DUPLICATE_TOOL_CALL_IDS
        ? " — 0.1.3+ v0→v1 migration refuses (#5694/#5909); repair wraps into {response,blocks}"
        : " — v0 harness still loads; 0.1.3+ migration will refuse (#5694/#5909)");
    if (MIGRATION_REFUSES_DUPLICATE_TOOL_CALL_IDS) health = worse(health, "legacy-replay-state");
    if (!issues.some((i) => i.code === "legacy-replay-state")) {
      issues.push({ code: "legacy-replay-state", message, seqs: replayHits });
    }
  }
  const retryHits = retryChainHits(finished.events);
  if (retryHits.seqs.length > 0 || retryHits.refusals.length > 0) {
    const located = retryHits.seqs.length > 0 ? " at seq " + retryHits.seqs.join(", ") : "";
    const message =
      "llm/retry attempts do not sequence inside their policy chain" +
      located +
      (retryHits.refusals.length > 0
        ? " — " + retryHits.refusals.slice(0, 3).join("; ")
        : " — the released fold refuses the whole log with `llm/retry skips its policy attempt sequence` (#9163); repair renumbers each chain from 1 and unifies its retryId") +
      (retryHits.seqs.length > 0 && retryHits.refusals.length > 0 ? " — repair refuses: " + retryHits.refusals.slice(0, 3).join("; ") : "");
    health = worse(health, "llm-retry-chain");
    if (!issues.some((i) => i.code === "llm-retry-chain")) {
      const issue = { code: "llm-retry-chain", message };
      if (retryHits.seqs.length > 0) issue.seqs = retryHits.seqs;
      issues.push(issue);
    }
  }
  const migrationHits = migrationRefusalIssues(finished.events);
  if (migrationHits.length > 0) {
    if (MIGRATES_V0_ON_LOAD) {
      for (const hit of migrationHits) health = worse(health, hit.code);
    }
    if (!issues.some((i) => i.code === migrationHits[0].code)) {
      issues.push(...migrationHits);
    }
  }
  const emptyIds = emptyToolCallIds(finished.events);
  if (emptyIds.length > 0) {
    health = worse(health, "empty-tool-call-id");
    if (!issues.some((i) => i.code === "empty-tool-call-id")) {
      const seqs = emptyIds.map((d) => d.seq);
      issues.push({
        code: "empty-tool-call-id",
        message:
          "empty tool-call id at seq " +
          seqs.join(", ") +
          " — next model request will 400 (id cannot be empty); inspect only, do not invent an id",
        seqs,
        where: emptyIds.map((d) => d.where),
      });
    }
  }
  const fileVersion = headerClass.header?.version;
  if (typeof fileVersion === "number" && fileVersion >= 4) {
    const literalPlugin = literalPluginSourceHits(finished.events);
    if (literalPlugin.length > 0) {
      health = worse(health, "v4-literal-plugin-source");
      if (!issues.some((i) => i.code === "v4-literal-plugin-source")) {
        const seqs = literalPlugin.map((hit) => hit.seq);
        issues.push({
          code: "v4-literal-plugin-source",
          message:
            "message source is still the retired {kind:\"plugin\", plugin} wrapper at seq " +
            seqs.join(", ") +
            " — format v4 admission requires a producer-owned kind, so this harness refuses the whole log on read (#7772); repair writes the kind the released v3→v4 stage derives for that plugin name (its rename table plus the `plugin:<name>` fallback), keeping every other member, and leaves a source whose `plugin` is not a string alone",
          seqs,
          plugins: literalPlugin.map((hit) => hit.plugin),
        });
      }
    }
  }
  const missingMembers = fileVersion === 0 ? missingMemberHits(finished.events) : [];
  if (missingMembers.length > 0) {
    if (MIGRATES_V0_ON_LOAD) health = worse(health, "v0-missing-member");
    if (!issues.some((i) => i.code === "v0-missing-member")) {
      const rows = missingMembers.slice(0, 12);
      issues.push({
        code: "v0-missing-member",
        message:
          "released v0 shape is incomplete at seq " +
          rows.map((hit) => `${hit.seq} (${hit.type} lacks ${hit.member})`).join(", ") +
          " — the v0→v1 payload gate refuses the session over one such row; the member is not recoverable from the artifact, so repair only reports",
        seqs: missingMembers.map((hit) => hit.seq),
        missing: rows.map((hit) => `${hit.type}:${hit.member}`),
      });
    }
  }
  const settlementHits =
    typeof fileVersion === "number" && fileVersion >= 1 ? settlementShapeHits(finished.events) : [];
  if (settlementHits.length > 0) {
    health = worse(health, "invalid-settlement-fields");
    if (!issues.some((i) => i.code === "invalid-settlement-fields")) {
      const rows = settlementHits.slice(0, 12);
      issues.push({
        code: "invalid-settlement-fields",
        message:
          "assistant settlement fields are invalid at seq " +
          rows.map((hit) => `${hit.seq} (${hit.type}: ${hit.members.join(", ")})`).join(", ") +
          " — the seed/restore gate requires turn/step to be non-negative safe integers and stream to be an array, and refuses the whole session over one such row (\"seed assistant/message at index N has invalid settlement fields\", #8084); stream carries the streamed blocks and is not recoverable from the artifact, so repair only reports",
        seqs: settlementHits.map((hit) => hit.seq),
        settlement: rows.map((hit) => `${hit.type}:${hit.members.join("+")}`),
      });
    }
  }
  // The catalog path runs on the way into v4, so only a pre-v4 artifact can
  // trip it; a stored v4 log is read as-is.
  const catalogHits =
    typeof fileVersion === "number" && fileVersion >= 1 && fileVersion <= 3
      ? catalogFactHits(headerClass.header, finished.events)
      : [];
  if (catalogHits.length > 0) {
    health = worse(health, "descriptor-catalog-fact");
    if (!issues.some((i) => i.code === "descriptor-catalog-fact")) {
      issues.push({
        code: "descriptor-catalog-fact",
        message:
          "subagent descriptor at seq " +
          catalogHits.map((hit) => `${hit.seq} (${hit.reason})`).join(", ") +
          " — the v3→v4 child-catalog path interprets a child's own descriptor and refuses this one (\"has an invalid subagent descriptor mode\" for a mode outside continuable/one-shot, \"requires a supported versioned catalog fact\" for a missing label, which a continuable descriptor — including every version 1 row — must carry); the mode is a real property and the label is free text, so neither can be invented offline — repair only reports (#7995)",
        seqs: catalogHits.map((hit) => hit.seq),
        reasons: catalogHits.map((hit) => hit.reason),
      });
    }
  }
  const pruneHits = prunePassHits(finished.events);
  if (pruneHits.length > 0) {
    health = worse(health, "prune-tail-outside-turn");
    if (!issues.some((i) => i.code === "prune-tail-outside-turn")) {
      const seqs = pruneHits.map((hit) => hit.seq);
      const shown = seqs.length > 12 ? seqs.slice(0, 12) : seqs;
      issues.push({
        code: "prune-tail-outside-turn",
        message:
          "replacement tool/result outside an open turn at seq " +
          shown.join(", ") + (seqs.length > shown.length ? " (first " + shown.length + " of " + seqs.length + ")" : "") +
          " — the idle tool-result pruner appends its replacements after turn/end, but the released fold routes every non-append tool/result through requireTurn() and refuses the whole session with \"tool/result is outside an open turn\" (#8812); the replacements only shadow surface nodes that are still in the log, so repair cuts back to the turn/end the pass followed and drops nothing else",
        seqs: shown,
        count: seqs.length,
        types: [...new Set(pruneHits.map((hit) => hit.type))],
      });
    }
  }
  const sourceHits = finished.header && finished.header.version >= 4 ? producerSourceHits(finished.events) : [];
  if (sourceHits.length > 0) {
    health = worse(health, "producer-source-invalid");
    if (!issues.some((i) => i.code === "producer-source-invalid")) {
      const seqs = sourceHits.map((hit) => hit.seq);
      const shown = seqs.length > 12 ? seqs.slice(0, 12) : seqs;
      issues.push({
        code: "producer-source-invalid",
        message:
          "message source the released v4 admission refuses at seq " +
          shown.join(", ") + (seqs.length > shown.length ? " (first " + shown.length + " of " + seqs.length + ")" : "") +
          " — " + sourceHits[0].problem +
          "; the reader refuses the whole log with \"format v4 message requires a producer-owned source kind\" (or the slot's own message) and the correct value is not recoverable from the artifact, so repair only reports",
        seqs: shown,
        count: seqs.length,
        problems: [...new Set(sourceHits.map((hit) => hit.problem))],
        types: [...new Set(sourceHits.map((hit) => hit.type))],
      });
    }
  }
  const turnStepHits = turnStepImbalances(finished.events);
  for (const issue of turnStepIssuesFrom(turnStepHits)) {
    if (MIGRATES_V0_ON_LOAD) health = worse(health, issue.code);
    if (!issues.some((i) => i.code === issue.code)) issues.push(issue);
  }
  const dangling = danglingToolCalls(finished.events);
  if (dangling.length > 0) {
    health = worse(health, "dangling-tool-call");
    if (!issues.some((i) => i.code === "dangling-tool-call")) {
      const seqs = dangling.map((d) => d.seq);
      issues.push({
        code: "dangling-tool-call",
        message:
          "tool/call whose step closed without a tool/result: " + seqs.join(", ") +
          " — next model request will 400; a call whose step is still open at the tail is the ordinary crash shape and is not reported here (the engine's interrupted-turn closers write its result on resume); on 0.1.7 the same inner assertion (\"step/end leaves unresolved tool call\") refuses the session from both entry points, but the wrappers differ and that is how you tell them apart: reading a stored v4 log surfaces it inside SessionPersistenceCorruptionError as \"stored log is corrupt: … (raw log: <path>)\", while the v3→v4 restore/publish path surfaces a bare SessionFormatError (#4549) — and the result cannot be added offline (the step is closed) — probe: fixtures/probes/dangling-tool-call.json",
        seqs,
        callIds: dangling.map((d) => d.callId),
      });
    }
  }
  const missingIds = missingMessageIds(finished.events);
  if (missingIds.length > 0) {
    health = worse(health, "message-missing-id");
    if (!issues.some((i) => i.code === "message-missing-id")) {
      issues.push({
        code: "message-missing-id",
        message: "events lack an identified message: " + missingIds.join(", "),
        seqs: missingIds,
      });
    }
  }

  return {
    header: headerClass.header,
    headerClass,
    frames,
    tornStart,
    ...(zeroTailAt === undefined ? {} : { zeroTailAt, zeroTailBytes: buf.length - zeroTailAt }),
    events: finished.events,
    overflow: finished.overflow ?? [],
    issues,
    logicalLines: finished.logicalLines,
    packedRows: finished.packedRows,
    packedOverlapKept: finished.packedOverlapKept ?? 0,
    failedFrames,
    unknownTypes: finished.unknownTypes,
    lastSeq: finished.events.length === 0 ? -1 : finished.events[finished.events.length - 1].seq,
    overflowEvents: (finished.overflow ?? []).length,
    turnStepImbalances: turnStepHits,
    producerSourceHits: sourceHits,
    pruneHits,
    missingMembers,
    settlementHits,
    catalogHits,
    health,
  };
}

export function eventsSeqOk(events) {
  return events.every((event, i) => event.seq === i);
}
