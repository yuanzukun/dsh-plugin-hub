/**
 * Session event vocabulary aligned with the installed @deepseek-ai/dsh-session catalog.
 * Unknown types without the envelope `ignorable: true` marker are reported,
 * not dropped.
 */
import { pathToFileURL } from "node:url";
import { catalogModulePath, resolveInstalledPackage } from "./runtime.mjs";

const FALLBACK_SESSION_EVENT_TYPES = [
  "agent-preset/selected",
  "agent/inbox/spliced",
  "approval/asked",
  "approval/decided",
  "approval/policy",
  "assistant/chunk",
  "assistant/message",
  "command/done",
  "command/run",
  "compaction/end",
  "compaction/prune",
  "compaction/start",
  "compaction/summary",
  "feedback/record",
  "goal/change",
  "hook/invoked",
  "hook/result",
  "llm/retry",
  "llm/retry-started",
  "permission/preset",
  "plan/mode",
  "request/context",
  "request/header",
  "sandbox/mode",
  "schedule/change",
  "session/end-seed",
  "session/title",
  "session/title-llm-request",
  "step/end",
  "step/start",
  "subagent/descriptor",
  "team/member",
  "team/message/delivered",
  "team/message/queued",
  "team/task",
  "todo/write",
  "tool-workflow/agent-end",
  "tool-workflow/agent-start",
  "tool-workflow/run-end",
  "tool-workflow/run-start",
  "tool/call",
  "tool/code-dispatch",
  "tool/code-dispatch-start",
  "tool/result",
  "turn/end",
  "turn/start",
  "user/message",
  "web/deepseek-search-llm-request",
];

async function installedCatalog() {
  const root = resolveInstalledPackage("@deepseek-ai/dsh-session");
  if (root !== null) {
    try {
      const modulePath = catalogModulePath(root);
      const loaded = await import(pathToFileURL(modulePath).href);
      const catalog = loaded.KNOWN_SESSION_EVENT_TYPES;
      if (catalog instanceof Set && [...catalog].every((type) => typeof type === "string")) {
        return { catalog: new Set(catalog), source: modulePath };
      }
    } catch {
      // A layout without the catalog file keeps the fallback vocabulary.
    }
  }
  return { catalog: new Set(FALLBACK_SESSION_EVENT_TYPES), source: "fallback" };
}

const installed = await installedCatalog();
export const KNOWN_SESSION_EVENT_TYPES = installed.catalog;
export const KNOWN_SESSION_EVENT_TYPES_SOURCE = installed.source;

// A v0 artifact may legitimately carry types the current catalog retired
// (assistant/chunk on 0.1.5+). Classification accepts either vocabulary; the
// exact catalog stays available for downgrade-shim gating.
const KNOWN_OR_LEGACY = new Set([...installed.catalog, ...FALLBACK_SESSION_EVENT_TYPES]);

/** True when `type` (or `event.type`) is in this build's session vocabulary. */
export function isKnownEventType(typeOrEvent) {
  const type = typeof typeOrEvent === "string" ? typeOrEvent : typeOrEvent?.type;
  return typeof type === "string" && KNOWN_OR_LEGACY.has(type);
}

/** True when the event envelope carries the official `ignorable: true` marker. */
export function isIgnorable(event) {
  return event != null && typeof event === "object" && event.ignorable === true;
}
