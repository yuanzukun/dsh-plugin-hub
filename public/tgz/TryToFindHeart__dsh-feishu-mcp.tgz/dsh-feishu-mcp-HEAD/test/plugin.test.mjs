import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { apply } from '../index.js'
import { buildContentCards, NO_MODEL_FOOTER, withModelFooter } from '../lib/card.js'
import { buildContentCards as buildAppCards } from '../lib/markdown.js'
import { modelFooter } from '../lib/models.js'
import { createNotifier, turnNotice } from '../lib/notifier.js'
import { createNotifier as createFullNotifier } from '../lib/notify-full.js'
import { createModels, modelLabel } from '../lib/models.js'
import { sendWebhook } from '../lib/webhook.js'

const baseState = {
  webhookUrl: 'https://open.feishu.cn/open-apis/bot/v2/hook/test',
  webhookAtAll: true,
  notifyTurnEnd: true,
  cardTitle: 'DSH 任务结束提醒',
  maxChars: 1200,
  trace: false,
}

function installFetch(handler) {
  const original = globalThis.fetch
  const calls = []
  globalThis.fetch = async (url, init) => {
    calls.push({ url, init })
    return handler(url, init)
  }
  return { calls, restore: () => { globalThis.fetch = original } }
}

test('卡片构造：Card 2.0、@all 内嵌、markdown 表格、长正文分页不截断', () => {
  const basic = buildContentCards({ title: '测试', markdown: '**正文**', mentionAll: true })
  assert.equal(basic.length, 1)
  assert.equal(basic[0].schema, '2.0')
  assert.equal(basic[0].header.title.content, '测试')
  assert.match(basic[0].body.elements[0].content, /<at id=all>/)

  const table = buildContentCards({ title: '表格', markdown: '| 列 A | 列 B |\n| --- | --- |\n| 1 | 2 |' })
  const tableContent = table[0].body.elements.map((element) => element.content).join('\n')
  assert.match(tableContent, /\| 列 A \| 列 B \|/)
  assert.ok(!table[0].body.elements.some((element) => element.tag === 'table'))

  for (const build of [buildContentCards, buildAppCards]) {
    const lines = Array.from({ length: 300 }, (_, index) => `第 ${index + 1} 行内容`)
    const cards = build({ title: '长文', markdown: lines.join('\n'), bodyLimit: 200 })
    assert.ok(cards.length > 6)
    const joined = cards.map((card) => card.body.elements.map((element) => element.content || '').join('\n')).join('\n')
    assert.match(joined, /第 300 行内容/)
    assert.doesNotMatch(joined, /已省略/)
  }
})

test('模型小字：统一生成、只追加一次、切换卡排除', async () => {
  const models = {
    current: () => ({ provider: 'magpie', model: 'auto/hy4flash-free' }),
    catalog: async () => undefined,
  }
  assert.equal(await modelFooter(models, 'session-1'), '模型：magpie/auto/hy4flash-free')

  const card10 = { config: {}, header: {}, elements: [{ tag: 'div' }] }
  const once = withModelFooter(card10, '模型：deepseek/deepseek-chat')
  assert.equal(once.elements.length, 2)
  assert.doesNotMatch(JSON.stringify(card10), /模型：/)
  assert.equal(withModelFooter(once, '模型：deepseek/deepseek-chat').elements.length, 2)

  const card20 = { schema: '2.0', body: { elements: [{ tag: 'markdown', content: '正文' }] } }
  const withFooter = withModelFooter(card20, '模型：magpie/auto/hy4flash-free')
  assert.match(withFooter.body.elements.at(-1).content, /模型：magpie/)

  const switching = { ...card10, [NO_MODEL_FOOTER]: true }
  assert.equal(withModelFooter(switching, '模型：x'), switching)
})

test('turnNotice 不再截断正文，maxChars 只作为分页预算', () => {
  const notice = turnNotice({
    session: { id: 'session-abc123', header: { cwd: '/workspace/demo' } },
    reason: { kind: 'completed' },
    text: 'x'.repeat(100),
    durationMs: 65000,
    maxChars: 20,
  })
  assert.match(notice.title, /任务完成/)
  assert.equal(notice.template, 'green')
  assert.doesNotMatch(notice.markdown, /已截断/)
  assert.match(notice.markdown, /x{100}/)
})

test('sendWebhook 把非 0 code 当作失败', async () => {
  const fake = installFetch(async () => new Response(JSON.stringify({ code: 1, msg: 'bad token' }), { status: 200 }))
  try {
    await assert.rejects(
      () => sendWebhook(baseState.webhookUrl, { msg_type: 'text' }),
      /bad token/,
    )
    assert.equal(fake.calls.length, 1)
  } finally {
    fake.restore()
  }
})

test('notifier 在 turn/end 只发一张含 @all 的卡片，取消轮次静默', async () => {
  const fake = installFetch(async () => new Response(JSON.stringify({ code: 0 }), { status: 200 }))
  const calls = []
  const notifier = createNotifier({
    readState: async () => ({ ...baseState, maxChars: 1200 }),
    log: () => {},
    trace: (kind) => calls.push(kind),
  })
  const session = { id: 'session-1', header: { cwd: '/workspace/demo' } }

  try {
    await notifier.onSessionEvent(session, { type: 'turn/start' })
    await notifier.onSessionEvent(session, { type: 'assistant/message', data: { message: { content: [{ type: 'text', text: '任务完成' }] } } })
    await notifier.onSessionEvent(session, { type: 'turn/end', data: { reason: { kind: 'completed' } } })
    await new Promise((resolve) => setTimeout(resolve, 20))
    assert.deepEqual(calls, ['card-sent'])
    assert.equal(fake.calls.length, 1)
    const sent = JSON.parse(fake.calls[0].init.body)
    assert.equal(sent.msg_type, 'interactive')
    assert.match(sent.card.body.elements[0].content, /<at id=all>/)

    calls.length = 0
    fake.calls.length = 0
    await notifier.onSessionEvent(session, { type: 'turn/end', data: { reason: { kind: 'cancelled' } } })
    await new Promise((resolve) => setTimeout(resolve, 20))
    assert.deepEqual(calls, [])
    assert.equal(fake.calls.length, 0)
  } finally {
    fake.restore()
  }
})

test('由飞书私聊发起的轮次只回原对话，不重复发 webhook', async () => {
  const fake = installFetch(async () => new Response(JSON.stringify({ code: 0 }), { status: 200 }))
  const chatCards = []
  const calls = []
  const notifier = createNotifier({
    readState: async () => ({ ...baseState, maxChars: 1200, inboundReply: true }),
    log: () => {},
    trace: (kind) => calls.push(kind),
    takeReply: (sessionId) => sessionId === 'session-chat' ? { chatId: 'oc_chat_1', messageId: 'om_1' } : undefined,
    sendChatCard: async (chatId, card) => { chatCards.push({ chatId, card }) },
  })
  const session = { id: 'session-chat', header: { cwd: '/workspace/demo' } }

  try {
    await notifier.onSessionEvent(session, { type: 'turn/start' })
    await notifier.onSessionEvent(session, { type: 'assistant/message', data: { message: { content: [{ type: 'text', text: '任务完成' }] } } })
    await notifier.onSessionEvent(session, { type: 'turn/end', data: { reason: { kind: 'completed' } } })
    await new Promise((resolve) => setTimeout(resolve, 20))

    assert.equal(fake.calls.length, 0)
    assert.equal(chatCards.length, 1)
    assert.equal(chatCards[0].chatId, 'oc_chat_1')
    const chatContent = chatCards[0].card.body.elements.map((element) => element.content || '').join('\n')
    assert.match(chatContent, /任务完成/)
    assert.ok(calls.includes('chat-card-sent'))
  } finally {
    fake.restore()
  }
})

test('/test 使用已保存的 webhook 地址发送测试卡片', async () => {
  const originalHome = process.env.DSH_HOME
  const home = mkdtempSync(join(tmpdir(), 'dsh-feishu-mcp-test-'))
  const { mkdirSync } = await import('node:fs')
  mkdirSync(join(home, 'dsh-feishu-mcp'), { recursive: true })
  writeFileSync(
    join(home, 'dsh-feishu-mcp', 'state.json'),
    JSON.stringify({ version: 3, ...baseState, webhookAtAll: false }),
  )
  process.env.DSH_HOME = home

  const routes = []
  const ctx = {
    logger: { warn() {} },
    effect() {},
    on() {},
    get() { return undefined },
    inject(names, callback) {
      if (names.includes('connection')) {
        callback({
          connection: {
            fetch: {
              register(route) { routes.push(route) },
            },
          },
          effect(fn) { fn() },
        })
      } else {
        callback({ tools: { register() {} } })
      }
    },
  }

  apply(ctx)
  const route = routes.find((item) => item.path === '/api/feishu-mcp/test')
  assert.ok(route, '应注册 /api/feishu-mcp/test 路由')

  const fake = installFetch(async () => new Response(JSON.stringify({ code: 0 }), { status: 200 }))
  try {
    const response = await route.fetch(new Request('http://localhost/api/feishu-mcp/test', { method: 'POST' }))
    const payload = await response.json()
    assert.equal(response.status, 200)
    assert.equal(payload.ok, true)
    assert.equal(fake.calls.length, 1)
    assert.equal(fake.calls[0].url, baseState.webhookUrl)
  } finally {
    fake.restore()
    if (originalHome === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = originalHome
  }
})

test('启用 Webhook 时普通轮次只发群卡片，不重复发应用机器人', async () => {
  const fake = installFetch(async () => new Response(JSON.stringify({ code: 0 }), { status: 200 }))
  const state = {
    ...baseState,
    enableWebhook: true,
    appId: 'cli_test',
    appSecret: 'secret',
    ownerOpenId: 'ou_test',
    notify: { turnEnd: true, approval: true, question: true },
  }
  const notifier = createFullNotifier({
    readState: async () => state,
    log() {},
    trace() {},
    takeReply() { return null },
    takeTyping() { return null },
  })
  const session = { id: 'session-webhook', header: { cwd: '/workspace/demo' } }
  try {
    await notifier.onSessionEvent(session, { type: 'turn/start' })
    await notifier.onSessionEvent(session, { type: 'assistant/message', data: { message: { content: [{ type: 'text', text: '任务完成' }] } } })
    await notifier.onSessionEvent(session, { type: 'turn/end', data: { reason: { kind: 'completed' } } })
    await new Promise((resolve) => setTimeout(resolve, 30))
    assert.equal(fake.calls.length, 1)
    assert.equal(fake.calls[0].url, baseState.webhookUrl)
  } finally {
    fake.restore()
  }
})

test('关闭 Webhook 后普通轮次由应用机器人发回绑定会话并携带会话信息', async () => {
  const fake = installFetch(async (url) => {
    if (String(url).includes('tenant_access_token')) {
      return new Response(JSON.stringify({ code: 0, tenant_access_token: 't-token' }), { status: 200 })
    }
    return new Response(JSON.stringify({ code: 0, data: { message_id: 'om_sent' } }), { status: 200 })
  })
  const state = {
    ...baseState,
    webhookUrl: '',
    enableWebhook: false,
    appId: 'cli_test',
    appSecret: 'secret',
    homeChatId: 'oc_home',
    ownerOpenId: 'ou_test',
    notify: { turnEnd: true, approval: true, question: true },
  }
  const notifier = createFullNotifier({
    readState: async () => state,
    log() {},
    trace() {},
    takeReply() { return null },
    takeTyping() { return null },
    chatOfSession: async () => ({ chatId: 'oc_bound' }),
  })
  const session = { id: 'session-bound', header: { cwd: '/workspace/demo' } }
  try {
    await notifier.onSessionEvent(session, { type: 'turn/start' })
    await notifier.onSessionEvent(session, { type: 'assistant/message', data: { message: { content: [{ type: 'text', text: '任务完成' }] } } })
    await notifier.onSessionEvent(session, { type: 'turn/end', data: { reason: { kind: 'completed' } } })
    await new Promise((resolve) => setTimeout(resolve, 30))
    const send = fake.calls.find((call) => String(call.url).includes('/im/v1/messages'))
    assert.ok(send, '应通过应用机器人发送消息')
    assert.match(String(send.url), /receive_id_type=chat_id/)
    const body = JSON.parse(send.init.body)
    assert.equal(body.receive_id, 'oc_bound')
    const content = typeof body.content === 'string' ? JSON.parse(body.content) : body.content
    const text = JSON.stringify(content)
    assert.match(text, /会话/)
    assert.match(text, /任务完成/)
  } finally {
    fake.restore()
  }
})

test('关闭 Webhook 的普通轮次会立即把收通知的飞书对话重绑到通知所属会话', async () => {
  const fake = installFetch(async (url) => {
    if (String(url).includes('tenant_access_token')) {
      return new Response(JSON.stringify({ code: 0, tenant_access_token: 't-token' }), { status: 200 })
    }
    return new Response(JSON.stringify({ code: 0, data: { message_id: 'om_sent' } }), { status: 200 })
  })
  const state = {
    ...baseState,
    webhookUrl: '',
    enableWebhook: false,
    followNoticeSwitch: true,
    appId: 'cli_test',
    appSecret: 'secret',
    ownerOpenId: 'ou_test',
    notify: { turnEnd: true, approval: true, question: true },
  }
  const writes = []
  const notifier = createFullNotifier({
    readState: async () => state,
    writeState: async (next) => { writes.push(next); return next },
    log() {},
    trace() {},
    takeReply() { return null },
    takeTyping() { return null },
    chatOfSession: async () => ({ chatId: 'oc_bound' }),
  })
  const session = { id: 'session-notice', header: { cwd: '/workspace/demo' } }
  try {
    await notifier.onSessionEvent(session, { type: 'turn/start' })
    await notifier.onSessionEvent(session, { type: 'assistant/message', data: { message: { content: [{ type: 'text', text: '任务完成' }] } } })
    await notifier.onSessionEvent(session, { type: 'turn/end', data: { reason: { kind: 'completed' } } })
    await new Promise((resolve) => setTimeout(resolve, 30))
    assert.equal(writes.length, 1)
    assert.equal(writes[0].chatSessions.oc_bound, 'session-notice')
    assert.equal(writes[0].lastNoticeSessionId, '')
    assert.equal(writes[0].lastNoticeAt, 0)
  } finally {
    fake.restore()
  }
})

test('没有绑定对话时，通知直接重绑首页飞书会话，而不是只留 lastNotice', async () => {
  const fake = installFetch(async (url) => {
    if (String(url).includes('tenant_access_token')) {
      return new Response(JSON.stringify({ code: 0, tenant_access_token: 't-token' }), { status: 200 })
    }
    return new Response(JSON.stringify({ code: 0, data: { message_id: 'om_sent' } }), { status: 200 })
  })
  const state = {
    ...baseState,
    webhookUrl: '',
    enableWebhook: false,
    followNoticeSwitch: true,
    appId: 'cli_test',
    appSecret: 'secret',
    homeChatId: 'oc_home',
    ownerOpenId: 'ou_test',
    chatSessions: {},
    notify: { turnEnd: true, approval: true, question: true },
  }
  const writes = []
  const notifier = createFullNotifier({
    readState: async () => state,
    writeState: async (next) => { writes.push(next); return next },
    log() {},
    trace() {},
    takeReply() { return null },
    takeTyping() { return null },
    chatOfSession: async () => undefined,
  })
  const session = { id: 'session-notice', header: { cwd: '/workspace/demo' } }
  try {
    await notifier.onSessionEvent(session, { type: 'turn/start' })
    await notifier.onSessionEvent(session, { type: 'assistant/message', data: { message: { content: [{ type: 'text', text: '任务完成' }] } } })
    await notifier.onSessionEvent(session, { type: 'turn/end', data: { reason: { kind: 'completed' } } })
    await new Promise((resolve) => setTimeout(resolve, 30))
    assert.equal(writes.length, 1)
    assert.equal(writes[0].chatSessions.oc_home, 'session-notice')
    assert.equal(writes[0].lastNoticeSessionId, '')
  } finally {
    fake.restore()
  }
})

test('turn/end 即使用 cancelled 也会撤销 Typing 反应', async () => {
  const fake = installFetch(async (url, init) => {
    if (String(url).includes('/auth/v3/tenant_access_token/internal')) {
      return new Response(JSON.stringify({ code: 0, tenant_access_token: 'token-typing', expire: 7200 }), { status: 200 })
    }
    if (String(url).includes('/reactions')) {
      return new Response(JSON.stringify({ code: 0 }), { status: 200 })
    }
    return new Response(JSON.stringify({ code: 0, data: { message_id: 'om_x' } }), { status: 200 })
  })
  const state = {
    appId: 'cli_typing_test',
    appSecret: 'secret',
    domain: 'feishu',
    notify: { turnEnd: true },
    enableWebhook: false,
    ownerOpenId: 'ou_owner',
    allowedOpenIds: ['ou_owner'],
    chatSessions: {},
  }
  let taken = 0
  const notifier = createFullNotifier({
    readState: async () => state,
    log() {},
    trace() {},
    takeReply() { return null },
    takeTyping() {
      taken += 1
      return { messageId: 'om_user', reactionId: 'reaction-typing' }
    },
    chatOfSession: async () => undefined,
  })
  const session = { id: 'session-typing', header: { cwd: '/workspace/demo' } }
  try {
    await notifier.onSessionEvent(session, { type: 'turn/end', data: { reason: { kind: 'cancelled' } } })
    await new Promise((resolve) => setTimeout(resolve, 30))
    assert.equal(taken, 1)
    assert.ok(fake.calls.some((call) => call.init?.method === 'DELETE' && call.url.includes('/reactions/reaction-typing')))
  } finally {
    fake.restore()
  }
})

test('每张通知卡片底部带当前模型小字', async () => {
  const fake = installFetch(async () => new Response(JSON.stringify({ code: 0 }), { status: 200 }))
  const state = {
    webhookUrl: 'https://open.feishu.cn/open-apis/bot/v2/hook/test',
    webhookAtAll: false,
    notify: { turnEnd: true },
    appId: '',
    appSecret: '',
  }
  const notifier = createFullNotifier({
    readState: async () => state,
    log() {},
    trace() {},
    models: {
      current: () => ({ provider: 'deepseek', model: 'deepseek-chat' }),
      catalog: async () => undefined,
    },
  })
  const session = { id: 'session-footer', header: { cwd: '/workspace/demo' } }
  try {
    await notifier.onSessionEvent(session, { type: 'turn/start' })
    await notifier.onSessionEvent(session, { type: 'assistant/message', data: { message: { content: [{ type: 'text', text: '完成' }] } } })
    await notifier.onSessionEvent(session, { type: 'turn/end', data: { reason: { kind: 'completed' } } })
    await new Promise((resolve) => setTimeout(resolve, 30))
    assert.equal(fake.calls.length, 1)
    const sent = JSON.parse(fake.calls[0].init.body)
    const footer = sent.card.body.elements.map((element) => element.content || '').join('\n')
    assert.match(footer, /模型：deepseek\/deepseek-chat/)
  } finally {
    fake.restore()
  }
})

test('模型读取回退链：agent → header → 投影，used 报告本轮实际路由', () => {
  const agentCtx = {
    get(name) {
      if (name === 'agents') {
        return { get: () => ({ model: { current: () => ({ provider: 'deepseek', model: 'deepseek-chat' }) } }) }
      }
      return undefined
    },
  }
  const fromAgent = createModels({ ctx: agentCtx })
  assert.deepEqual(fromAgent.current('session-1'), { provider: 'deepseek', model: 'deepseek-chat' })
  assert.equal(
    modelLabel({ provider: 'deepseek', model: 'deepseek-chat', reasoningEffort: 'high' }, {
      groups: [{ id: 'deepseek', models: [{ id: 'deepseek-chat', name: 'DeepSeek V3' }] }],
    }),
    'deepseek/deepseek-chat（DeepSeek V3） · high',
  )
  assert.equal(modelLabel(undefined), '默认模型（未读取到具体路由）')

  const headerSession = { requestHeader: () => ({ config: { provider: 'magpie', model: 'auto/hy4flash-free' } }) }
  const noAgent = createModels({ ctx: { get: () => undefined } })
  assert.deepEqual(noAgent.current('session-1', headerSession), { provider: 'magpie', model: 'auto/hy4flash-free' })
  assert.deepEqual(noAgent.used('session-1', headerSession), { provider: 'magpie', model: 'auto/hy4flash-free' })

  const projected = createModels({
    ctx: {
      get(name) {
        if (name === 'sessionProjections') {
          return { snapshot: () => ({ values: { modelSelection: { lastUsed: { provider: 'deepseek', model: 'deepseek-chat' }, next: null } } }) }
        }
        return undefined
      },
    },
  })
  const emptySession = { requestHeader: () => undefined }
  assert.deepEqual(projected.current('session-1', emptySession), { provider: 'deepseek', model: 'deepseek-chat' })
  assert.deepEqual(projected.used('session-1', emptySession), { provider: 'deepseek', model: 'deepseek-chat' })

  const mixed = createModels({ ctx: agentCtx })
  assert.deepEqual(mixed.current('session-1', headerSession), { provider: 'deepseek', model: 'deepseek-chat' })
  assert.deepEqual(mixed.used('session-1', headerSession), { provider: 'magpie', model: 'auto/hy4flash-free' })
})

test('通知底部在没有 agent 模型时仍显示 header 里的实际路由', async () => {
  const fake = installFetch(async () => new Response(JSON.stringify({ code: 0 }), { status: 200 }))
  const state = {
    webhookUrl: 'https://open.feishu.cn/open-apis/bot/v2/hook/test',
    webhookAtAll: false,
    notify: { turnEnd: true },
    appId: '',
    appSecret: '',
  }
  const ctx = {
    get(name) {
      if (name === 'agents') return { get: () => undefined }
      return undefined
    },
  }
  const models = createModels({ ctx })
  const notifier = createFullNotifier({
    readState: async () => state,
    log() {},
    trace() {},
    models,
  })
  const session = {
    id: 'session-header-model',
    header: { cwd: '/workspace/demo' },
    requestHeader: () => ({ config: { provider: 'magpie', model: 'auto/hy4flash-free' } }),
  }
  try {
    await notifier.onSessionEvent(session, { type: 'turn/start' })
    await notifier.onSessionEvent(session, { type: 'assistant/message', data: { message: { content: [{ type: 'text', text: '完成' }] } } })
    await notifier.onSessionEvent(session, { type: 'turn/end', data: { reason: { kind: 'completed' } } })
    await new Promise((resolve) => setTimeout(resolve, 30))
    assert.equal(fake.calls.length, 1)
    const sent = JSON.parse(fake.calls[0].init.body)
    const footer = sent.card.body.elements.map((element) => element.content || '').join('\n')
    assert.match(footer, /模型：magpie\/auto\/hy4flash-free/)
  } finally {
    fake.restore()
  }
})
