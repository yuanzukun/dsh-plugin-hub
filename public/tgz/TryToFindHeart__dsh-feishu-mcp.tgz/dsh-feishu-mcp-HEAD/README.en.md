# dsh-feishu-mcp

A Feishu notification and control plugin for DeepSeek Harness. It pushes session progress to Feishu and lets you drive DSH from a Feishu chat with text, images or files; every message is processed by DSH before it is returned.

[![DSH](https://img.shields.io/badge/DSH-DeepSeek%20Harness-blue?labelColor=555555&color=1f6feb)](https://github.com/deepseek-ai/deepseek-harness) [![Node.js](https://img.shields.io/badge/Node.js-22%2B-blue?labelColor=555555&color=1f6feb)](https://nodejs.org/) ![JavaScript](https://img.shields.io/badge/JavaScript-ESM-blue?labelColor=555555&color=6f42c1) ![Cordis](https://img.shields.io/badge/Cordis-plugin-orange?labelColor=555555&color=e3632d) ![tests](https://img.shields.io/badge/tests-32%2F32-green?labelColor=555555&color=2ea043) ![license](https://img.shields.io/badge/license-MIT-green?labelColor=555555&color=2ea043)

The plugin has two separate channels with separate test buttons:

- **Group webhook reminders**: a custom-bot webhook pushes each turn result to a group, with optional `@all`.
- **Feishu app bot**: connect a self-built app by scanning a QR code or entering credentials manually. It supports private-chat control with text, images and files, approval/question cards, typing reactions and session binding.

## Features

- Turn-end cards with conclusion, duration and failure reason; cancelled and sub-agent turns stay silent.
- Webhook toggle: enabled sends group cards only; disabled sends notifications through the app bot only. First-time app credentials apply a template default (webhook off, private-chat long-connection intake on, plus `@all`, session-switch limit and answer timeout preferences). Secrets, allowlists and session bindings stay yours; later explicit choices always win.
- Session model visibility and switching: every reply and notification card carries the current model in a small grey footer and warns about paid routes; a successful session switch also shows it; send `/model` in Feishu for a button card that switches the session's model.
- `@all` mention is embedded in the group card; no separate text message is sent; affects presentation, not whether a notice is sent.
- Scan-to-create a dedicated Feishu app, or enter App ID / App Secret manually if your tenant disables device-code registration.
- Approval cards with "allow once / deny"; question cards with option buttons and a free-text answer.
- Typing reaction while processing, removed on success and replaced by CrossMark on failure.
- Private messages drive DSH sessions and the result returns to the same chat. Images are downloaded as real bytes; `file` messages are downloaded, uploaded into the target session and handed to the model by receipt under the original filename.
- Busy turns default to `steer` (inline guidance); `/queue` switches to queued delivery.
- Session commands: `/sessions`, `/resume <no|id|title>`, `/new`, `/current`, `/id`.
- Send "切换会话" in a Feishu chat to get a numbered, one-button-per-row session card; each button carries a `#short-code` derived from the session ID, so auto-renamed sessions stay identifiable. Tapping one switches immediately. Unlimited by default, capped at 20; archived sessions are excluded.
- Follow-notice session switching: when Webhook is off, the Feishu chat that receives a notice is rebound to the notified session immediately, so replies naturally continue in the right session.
- Four permission modes: readonly / workspace / Auto Review / full, scoped per Feishu chat.
- Session location is configurable; the default workspace is `飞书 DSH` under `~/dsh-feishu-mcp`.
- Card 2.0 rendering: native tables for app messages, markdown tables for webhook, long content paginated.

## Notification and session rules

1. Webhook on: normal turn-end notices go to the group webhook only.
2. Webhook off: normal turn-end notices go through the app bot, carry the session title and answer, and are delivered to the bound Feishu chat; if none is bound, they fall back to the home chat or owner chat.
3. Turns started from Feishu always answer in the originating chat and never duplicate to the group webhook.
4. Follow-notice switching is on by default. When Webhook is off, sending a notice immediately binds the receiving Feishu chat to the notified session, overwriting any previous binding. Turn it off to keep the previous session resolution behavior.
5. Sending "切换会话" returns an all-button card; tapping a session button switches to that session. The card shows at most the configured number of sessions (1–20; 0 means unlimited).

> DSH does not expose a Host API for changing the session selected in the web UI. This plugin switches the **Feishu chat → DSH session binding**, so continuing in Feishu lands in the notified session; the web UI selection is not changed.

## Prerequisites

1. Create an enterprise self-built app in the Feishu Open Platform and enable the bot capability.
2. Grant the private-message read scope. The code references it through our own constant `FSMCP_SCOPE_P2P_READ`; proactive sending is `FSMCP_SCOPE_MESSAGE_SEND`.
3. Under event subscriptions, choose "use long connection to receive events" and add the message receive event; the code references it through `FSMCP_EVENT_MESSAGE_RECEIVE`. No public IP, domain or callback whitelist is needed.
4. Publish a version so permissions and events take effect.
5. Create a custom-bot webhook in a Feishu group for outbound strong reminders.

The platform identifiers are centralized only in `lib/constants.js`; business code and docs do not scatter them.

## Settings

Open the "飞书通知" section in DSH settings. It is organized into three cards:

- **Global**: turn-end / approval / question notification switches, card title, summary length, session location, default permission, plus a note that every card shows the current model and `/model` switches it per session.
- **Feishu app bot**: connection status, scan/manual onboarding, test / verify / disconnect, inbound control, reply-back-to-chat, follow-notice switching, session routing, session-button limit, dual-surface asking, wait window and the allowlist.
- **Group webhook (optional)**: webhook address, `@all`, enable switch, save / test — webhook-only settings, with no duplicated global switches.

Secrets are stored in `$DSH_HOME/dsh-feishu-mcp/state.json` with mode `0600`; the browser only ever sees masked tails.

## Routes

`GET /api/feishu-mcp/state`, `POST /api/feishu-mcp/{onboarding/begin,onboarding/poll,onboarding/cancel,credentials,prefs,verify,test,test-app,disconnect,clear}`, `GET|POST /api/feishu-mcp/service`.

## Status

- `npm test`: 24/24 passing; all JS/MJS files pass `node --check`.
- Outbound webhook verified against a real Feishu bot (`StatusCode:0`, `code:0`).
- App bot connection and test message verified in the UI.
- Follow-notice switching verified with a real notice and `state.json` changes.
- Model footer and switching: unit-tested that every card shows the current model; `/model` button card and session-switch receipts carry it too.
- Inbound long connection is implemented and unit-tested; final live verification needs the inbound switch, App ID / App Secret and event subscription.

## Install

```bash
npm install
```

Then install the local directory with the DSH plugin manager, or update the installed version in settings. Plugin entry: `include:feishu-mcp`.
