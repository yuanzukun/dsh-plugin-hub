import { promptText } from "../../prompts/loader.mjs";
import { randomUUID } from 'node:crypto';
import { ChannelError } from "../../shared/contracts.mjs";
import { availableModel, visionSelection } from "./models.mjs";
import { webSearchTool } from "../tasks/conversation-tools.mjs";
import { REPLY_STYLE_REVIEW_NOTE, needsConversationalRewrite } from "./reply-style.mjs";
import { SearchService } from "../search/service.mjs";
import { memoryCompressionPrompt } from "../../shared/memory-policy.mjs";
import {
  INTERNAL_OUTPUT_MODES,
  buildWechatPrompt,
  buildPersonaPassPrompt,
  messageWithHistory,
  memoryContext,
  identityData,
  scheduledData,
  imageQualityContext,
  applyFixedReplyBoundaries,
} from "../../prompts/reply/compose.mjs";
import { completedText, retryableEmptyResponse } from "./output.mjs";
import { emptyResponseRetryNote } from '../../prompts/reply/delivery.mjs';
import { resetWechatSessionContext } from "./request-context.mjs";
import { registerAgentWorkspace } from './workspace.mjs';
import { publishWorkSessionHistory } from '../work/session-history.mjs';
import { registerModelTools } from '../tools/registry.mjs';
import { planProgressiveTools } from '../tools/progressive.mjs';
import { observeModelRequests } from './request-metrics.mjs';
import { polishWorkResult } from '../work/polish.mjs';
import { reviewMemoryDraft } from '../memory/roles/reflection.mjs';
import { stickerDescriptions } from '../media/description.mjs';
import { observeExecutionSession } from '../traces/model.mjs';
import { currentTrace } from '../traces/context.mjs';
import { TIME_DEFAULTS } from '../../shared/time-settings.mjs';
import { publicText } from '../../backend/wechat/ai/public-output.ts';
import { conversationInputMessages } from './conversation-input.mjs';
import { replyClock } from '../../prompts/shared/time.mjs';
import { PERSONA_PLANNING_PROMPT, PERSONA_NATURAL_PLANNING_PROMPT, parsePersonaOutput, personaPassInput, personaModeOf } from './persona-pass.mjs';
import { naturalDecisionInstructions } from '../../prompts/conversation/decision.mjs';

export class DshAgentRunner {
  constructor(ctx, getModelChoice = () => null, getRuntimeSettings = () => ({})) {
    this.ctx = ctx;
    this.getModelChoice = getModelChoice;
    this.getRuntimeSettings = getRuntimeSettings;
    this.lastSearch = null;
    this.search = new SearchService(ctx, { getAttemptTimeoutMs: () => (this.getRuntimeSettings()?.timeSettings?.searchTimeoutSeconds ?? TIME_DEFAULTS.searchTimeoutSeconds) * 1000 });
  }
  searchStatus() {
    return this.lastSearch ? { ...this.lastSearch } : null;
  }
  searchTool(config = {}, options) {
    const settings = structuredClone(config);
    return webSearchTool(() => this.search.forConfig(settings, options), result => {
      this.lastSearch = { ...result, provider: Object.hasOwn(result, 'provider') ? result.provider : settings.searchProvider ?? 'tavily' };
    }, options);
  }
  defaultSelection() {
    const selection = this.ctx.agentDefaultModel.currentSelection();
    if (!selection?.provider || !selection?.model)
      throw new ChannelError('MODEL_MISSING', '请先在 DSH 中选择可用的模型');
    return selection;
  }
  selection() {
    return this.getModelChoice() ?? this.defaultSelection();
  }
  extractLongTermMemory(request) {
    return this.run(request);
  }
  extractRoleCard(request) {
    // run() creates an independent DSH agent/session when no sessionId is set.
    return this.run({ ...request, sessionId: undefined, mode: 'role-memory', tools: [] });
  }
  reviewMemoryReply(input, draft, options) {
    return reviewMemoryDraft(this, input, draft, options);
  }
  async polishReport(text,request,signal,presentation) {
    return (await polishWorkResult(this,text,request,signal,presentation)).text;
  }
  async polishReply(reply, request, signal, persona, context = {}) {
    signal.throwIfAborted();
    const runtime = context.runtime ?? structuredClone(this.getRuntimeSettings() ?? {});
    const style = { persona: persona ?? runtime.persona, prompt: context.prompt, identityMarkdown: runtime.identityMarkdown };
    // Style review stays read-only. Complete the owner's exact fixed lines
    // without rewriting the body or requesting another model response.
    if (needsConversationalRewrite(reply, request, style)) context.onStyleWarning?.(REPLY_STYLE_REVIEW_NOTE);
    return applyFixedReplyBoundaries(reply, { prompt: context.prompt, identityMarkdown: runtime.identityMarkdown });
  }
  async describeImage(image, signal, { question, executionSnapshot } = {}) {
    if (image.type === 'face' || image.kind === 'sticker')
      throw new ChannelError('STICKER_VISION_SKIPPED', '表情包不调用图像理解');
    const result = await this.run({
      text:
        promptText("vision/requests.json", "runner-text-1") +
        imageQualityContext([image]) +
        (question ? promptText("vision/requests.json", "runner-text-2") + JSON.stringify({ question }) : ''),
      images: [image],
      signal,
      mode: 'vision',
      executionSnapshot,
      systemOverride:
        promptText("vision/requests.json", "runner-systemOverride-3"),
    });
    return result.text;
  }
  async describeImages(images, signal) {
    if (images.some((image) => image.type === 'face' || image.kind === 'sticker'))
      throw new ChannelError('STICKER_VISION_SKIPPED', '表情包不调用图像理解');
    if (images.length === 1) return [await this.describeImage(images[0], signal)];
    const result = await this.run({
      text: promptText("vision/requests.json", "runner-text-4", [images.length, imageQualityContext(images)]),
      images,
      signal,
      mode: 'vision',
      systemOverride:
        promptText("vision/requests.json", "runner-systemOverride-5"),
    });
    let values;
    try {
      values = JSON.parse(result.text.replace(/^```(?:json)?\s*|\s*```$/g, ''));
    } catch {}
    if (
      !Array.isArray(values) ||
      values.length !== images.length ||
      values.some((value) => typeof value !== 'string' || !value.trim() || value.length > 1500)
    )
      throw new ChannelError(
        'IMAGE_DESCRIPTION_FAILED',
        '模型返回的图像说明与图片数量不匹配，未混用图片内容，可稍后重新理解'
      );
    return values;
  }
  async describeStickers(images, signal) {
    if (!Array.isArray(images) || !images.length || images.length > 4)
      throw new ChannelError('STICKER_DESCRIPTION_INVALID', '每次最多理解四张已保存表情');
    const result = await this.run({
      text: promptText('vision/requests.json', 'sticker-text', [images.length]), images, signal, mode: 'vision',
      systemOverride: promptText('vision/requests.json', 'sticker-system'),
    });
    return stickerDescriptions(result.text, images.length);
  }
  async summarize(text, maxChars, signal, retry = {}) {
    const result = await this.run({
      ...memoryCompressionPrompt(text, maxChars, retry),
      signal,
      mode: 'memory',
      executionSnapshot: retry.executionSnapshot,
    });
    return result.text;
  }
  async memoryExecutionSnapshot(signal) {
    signal.throwIfAborted();
    const runtime = structuredClone(this.getRuntimeSettings() ?? {});
    const chosen = structuredClone(this.getModelChoice());
    const selection = chosen ? await availableModel(this.ctx, chosen, signal) : structuredClone(this.defaultSelection());
    return { runtime, selection };
  }
  async run({
    text,
    group,
    prompt,
    persona,
    adminNotes,
    sessionId,
    signal,
    onSession,
    mode = 'default',
    history = [],
    memory,
    images = [],
    tools = [],
    systemOverride,
    speaker,
    account,
    allowEmptyReply = false,
    executionSnapshot,
    selectReplyText,
    naturalDecision,
    naturalOutputInstructions,
    scheduledTask,
    workContext,
    personaModeOverride,
    selectedReply,
    now = Date.now,
    messageTime,
    timeZone,
    clock: suppliedClock,
    onRequestMetrics,
    onBeforeTool,
    assertAllowed = () => {},
  }) {
    signal.throwIfAborted(); assertAllowed();
    // Freeze attribution and evidence before asynchronous model lookup or tool work.
    history = structuredClone(history);
    speaker = speaker && structuredClone(speaker);
    account = account && structuredClone(account);
    memory = typeof memory === 'string' ? memory : memory == null ? memory : structuredClone(memory);
    if (images.some((image) => image.type === 'face' || image.kind === 'sticker'))
      throw new ChannelError('STICKER_VISION_SKIPPED', '表情包不调用图像理解');
    // Capture once: picker/default changes apply to the next queued task,
    // without interrupting or silently rerouting the task already underway.
    const runtime = structuredClone(executionSnapshot?.runtime ?? this.getRuntimeSettings() ?? {});
    const promptStrategy = runtime.modelConfig?.promptStrategy ?? 'legacy';
    const requestMetrics = [];
    const executionTrace = currentTrace();
    if (persona) runtime.persona = structuredClone(persona);
    const chosen = executionSnapshot ? null : structuredClone(this.getModelChoice());
    let selected = structuredClone(executionSnapshot?.selection ?? chosen ?? this.defaultSelection());
    // Retrieval supplements recent dialogue. Supplying memory must never erase
    // the immediately preceding question, correction or speaker context.
    const memoryData = memoryContext(memory);
    const workDialogue = mode === 'work-dialogue';
    const workSnapshot = workDialogue ? structuredClone(workContext) : undefined;
    const internalOutput = INTERNAL_OUTPUT_MODES.has(mode);
    const personaMode = mode === 'persona-expression' || !internalOutput && !workDialogue && !systemOverride
      ? personaModeOf(runtime.persona, personaModeOverride) : null;
    const highPrecision = !internalOutput && personaMode === 'high-precision';
    const replyNow = typeof now === 'function' ? now() : now;
    const clock = structuredClone(suppliedClock ?? replyClock({ now: replyNow, messageTime, timeZone: timeZone ?? runtime.timeZone }));
    const dialogue = !internalOutput && !workDialogue && !systemOverride
      ? conversationInputMessages({ reference: [scheduledData(scheduledTask, mode), memoryData].filter(Boolean).join('\n\n'),
          history, speaker, timeZone: clock.timeZone, clock,
          currentIdentity: identityData(speaker, account, highPrecision ? null : runtime.persona),
          current: messageWithHistory(text, [], mode, undefined) })
      : null;
    const inputText = workDialogue || mode === 'work-routing' ? text : [identityData(speaker, account, runtime.persona), scheduledData(scheduledTask, mode), memoryData,
      messageWithHistory(text, history, mode, sessionId)]
      .filter(Boolean)
      .join('\n\n');
    if (chosen) selected = await availableModel(this.ctx, chosen, signal);
    if (images.length) selected = await visionSelection(this.ctx, selected, runtime.modelConfig?.visionModel, signal);
    // Omission delegates the output budget to the exact DSH model/adapter,
    // including its reasoning tokens. Never replace it with a plugin cap.
    const agentOptions = { ...selected };
    if (runtime.modelConfig?.maxTokens != null) agentOptions.maxTokens = runtime.modelConfig.maxTokens;
    const temperature = runtime.modelConfig?.temperature;
    // These modes and their output contracts are supplied by backend helpers,
    // never parsed from chat text. Internal isolation also applies without an override.
    const materialTools = ['moments-materials', 'moments-publish'].includes(mode);
    const natural = ['natural', 'participate'].includes(mode) && naturalDecision;
    const personTools = ['moments-reply', 'moments-interaction'].includes(mode);
    const definitions =
      workDialogue ? [...tools] : materialTools ? tools.filter(tool => ['wechat_moments_material_search', 'wechat_moments_material_download', 'wechat_moments_material_generate'].includes(tool.name)) :
        natural ? tools.filter(tool => ['wechat_role_card', 'wechat_sticker_read', 'wechat_sticker_send'].includes(tool.name)) :
        personTools ? tools.filter(tool => tool.name === 'wechat_role_card') : internalOutput || systemOverride
        ? []
        : [
            ...tools,
            ...(runtime.modelConfig?.webSearch
              ? [
                  this.searchTool(runtime.modelConfig, { assertAllowed }),
                ]
              : []),
          ];
    const toolResults = [];
    const capabilities = definitions.map((definition) => ({
      ...definition,
      execute: async (args, execution) => {
        const result = await definition.execute(args, {
          ...execution,
          executionSnapshot: structuredClone({ runtime, selection: selected }),
        });
        // Actual completed results, never merely proposed tool arguments, feed expression.
        toolResults.push({ name: definition.name, callId: execution?.id,
          content: typeof result === 'string' ? result : JSON.stringify(result ?? null) });
        return result;
      },
    }));
    const userMessageId = randomUUID();
    let resumedContextPending = !!sessionId;
    let durableModelSelection = false;
    const setup = (ctx, agent) => {
      durableModelSelection = typeof agent?.model?.select === 'function';
      // Do not load the desktop/coding preset or grant host tools to WeChat.
      const plan = promptStrategy === 'progressive-v1' ? planProgressiveTools(capabilities, text) : { initial: capabilities, deferredGroups: [] };
      const visibleCapabilities = registerModelTools(ctx, plan.initial, { deferredGroups: plan.deferredGroups, assertAllowed, agent,
        quiet: !internalOutput || workDialogue,
        onBeforeTool: internalOutput && !workDialogue ? undefined : onBeforeTool,
        native: promptStrategy === 'progressive-v1' || workDialogue || materialTools || ['work-result','work-progress','work-routing'].includes(mode), denied: '微信会话只能使用管理员开放的会话工具' });
      observeModelRequests(ctx, { strategy: promptStrategy, mode, sessionId: id, rows: requestMetrics, onUpdate: rows => {
        for (const row of requestMetrics) { row.personaMode = personaMode; row.personaPass = highPrecision ? 'planning' : mode === 'persona-expression' ? 'expression' : 'single'; }
        onRequestMetrics?.(structuredClone(requestMetrics));
      } });
      observeExecutionSession(ctx, { sessionId: id, agent, selection: selected, mode, context: executionTrace });
      ctx.systemPrompt.suppressRuntimeContext();
      // The host's working-directory fact is otherwise marked required and
      // appended as a second user message even without filesystem tools.
      // Override only this agent's prompt contribution; its real workspace,
      // persistence header and working-directory service remain untouched.
      ctx.systemPrompt.context?.({ name: 'working-directory:current', order: 0,
        required: false, interpolate: false, text: '' });
      // Apply this turn's controls after Host defaults, including on resume.
      if (sessionId || (temperature !== null && temperature !== undefined)) ctx.on('agent/request', async (position, next) => {
        // The native step is open here, so the surface replacement is a valid
        // replayable event. Do this only before this run's first model call.
        if (resumedContextPending) {
          resetWechatSessionContext(handle.agent.session, position);
          resumedContextPending = false;
        }
        const request = { ...(await next()) };
        // Older hosts have no durable model selector. Newer hosts fix route and
        // effort during preparation, before this hook, so never rewrite them here.
        if (!durableModelSelection) {
          if (selected.reasoningEffort !== undefined) request.reasoningEffort = selected.reasoningEffort;
          else if (sessionId) delete request.reasoningEffort;
        }
        // AgentOptions omits temperature in rc.5; this scoped waterfall reaches
        // the actual provider controls without changing the Host's settings.
        if (temperature !== null && temperature !== undefined) request.temperature = temperature;
        return request;
      }, { prepend: true });
      ctx.systemPrompt.section({
        name: 'wechat-agent',
        order: 0,
        complete: true,
        interpolate: false,
        text: buildWechatPrompt({
          group,
          mode,
          persona: runtime.persona,
          prompt,
          adminNotes,
          identityMarkdown: runtime.identityMarkdown,
          modelConfig: runtime.modelConfig,
          promptStrategy,
          capabilities: visibleCapabilities,
          searchAvailable: capabilities.some(tool => tool.name === 'wechat_web_search'),
          memoryAvailable: capabilities.some(tool => tool.name === 'wechat_memory'),
          systemOverride,
          naturalDecision,
          naturalOutputInstructions: highPrecision && natural
            ? naturalDecisionInstructions(naturalDecision).split('只输出一个 JSON 对象')[0] + '\n' + PERSONA_NATURAL_PLANNING_PROMPT
            : naturalOutputInstructions,
          requestText: text,
          history,
          speaker,
          workContext: workSnapshot,
          now: new Date(replyNow), clock, includePersona: !highPrecision,
        }) + (highPrecision && !natural ? '\n\n' + PERSONA_PLANNING_PROMPT : ''),
      });
    };
    signal.throwIfAborted();
    const id = sessionId || randomUUID();
    const workspace = runtime.workspacePath ? await registerAgentWorkspace(this.ctx, runtime.workspacePath) : null;
    signal.throwIfAborted();
    let handle;
    try {
      handle = sessionId
        ? await this.ctx.agents.resume({ resumeSessionId: id, agentOptions, setup, signal })
        : await this.ctx.agents.create({
            sessionId: id,
            agentOptions,
            setup,
            signal,
            ...(runtime.workspacePath ? { meta: { cwd: runtime.workspacePath } } : {}),
          });
      signal.throwIfAborted();
      // Public Agent.model selection is applied after construction, before any
      // followup can prepare a step. Omitted effort explicitly returns to Auto.
      if (typeof handle.agent.model?.select === 'function') {
        durableModelSelection = true;
        await handle.agent.model.select(structuredClone(selected));
        signal.throwIfAborted();
      }
      if (!sessionId) await workspace?.attachSession(id);
      if (!sessionId) {
        let titles;
        try { titles = handle.agent.ctx?.get?.('sessionTitle') ?? handle.agent.ctx?.sessionTitle; } catch {}
        if (titles?.rename) await titles.rename(handle.agent.session, workDialogue ? '微信聊天 · 工作调度' : '微信聊天 · 内部会话');
      }
      signal.throwIfAborted();
      await onSession?.(id);
      const agent = handle.agent;
      // DSH accepts one native user message per followup. Preserve the ordered,
      // author-labelled reference turns inside its single text block, with current last.
      let content = [{ type: 'text', text: dialogue ? dialogue.map(message => message.content).join('\n\n') : inputText }];
      if (images.length) {
        if (!this.ctx.attachments?.admitPromptContent)
          throw new ChannelError('VISION_UNAVAILABLE', 'DSH 未提供图像输入组件，请检查宿主的图像功能');
        try {
          content = await this.ctx.attachments.admitPromptContent([
            ...content,
            ...images.map((image) => ({
              type: 'image',
              data: image.data,
              mediaType: image.mediaType,
              name: '微信图片',
            })),
          ]);
        } catch {
          throw new ChannelError('IMAGE_INVALID', '图片未通过 DSH 的解码或大小检查，未将其当作已理解内容');
        }
        signal.throwIfAborted();
      }
      const cancel = () => agent.cancel({ kind: 'user' });
      signal.addEventListener('abort', cancel, { once: true });
      try {
        signal.throwIfAborted();
        // Same wire contract as dsh-llm.createUserMessage; no private DSH SDK
        // dependency is bundled, so the host owns every Cordis service.
        let reply, emptyResponseRetries = 0, partialPlanning = false;
        for (;;) {
          const from = agent.session.seq;
          agent.followup(
            Object.freeze({
              id: emptyResponseRetries ? randomUUID() : userMessageId,
              role: 'user',
              content: emptyResponseRetries ? [...content, { type: 'text', text: emptyResponseRetryNote() }] : content,
              source: { kind: workDialogue ? 'user' : 'wechat-agent' },
            })
          );
          await agent.whenIdle();
          signal.throwIfAborted();
          const events = agent.session.snapshotEvents(from);
          try {
            reply = completedText(events,
              typeof allowEmptyReply === 'function' ? allowEmptyReply() : allowEmptyReply, highPrecision ? undefined : selectReplyText);
            break;
          } catch (error) {
            // A clipped planning note is internal evidence, never a sendable answer.
            // Only a real text-only max-token terminal may continue to expression.
            const end = events.findLast(event => event.type === 'turn/end');
            const blocks = events.findLast(event => event.type === 'assistant/message' && event.data?.turn === end?.data?.turn)?.data?.message?.content;
            if (highPrecision && !natural && end?.data?.reason?.kind === 'max-tokens' && Array.isArray(blocks) &&
                !blocks.some(block => block.type === 'tool-call')) {
              const notes = publicText(blocks.filter(block => block.type === 'text').map(block => block.text ?? '').join(''));
              if (notes) { reply = notes; partialPlanning = true; break; }
            }
            if (error.code === 'MODEL_EMPTY' && emptyResponseRetries)
              throw new ChannelError('MODEL_EMPTY', '同一模型重试一次后仍没有返回可用的最终正文；未发送回复，请检查所选模型服务');
            if (error.code !== 'MODEL_EMPTY' || emptyResponseRetries || toolResults.length || !retryableEmptyResponse(events)) throw error;
            emptyResponseRetries++;
          }
        }
        let personaApplied = false;
        if (highPrecision) {
          signal.throwIfAborted(); assertAllowed();
          const media = typeof selectedReply === 'function' ? structuredClone(selectedReply()) : null;
          const decisionText = natural && typeof selectReplyText === 'function' ? publicText(selectReplyText(reply)) : null;
          if (media && !(media.text ?? media.caption)?.trim() || natural && !decisionText) {
            reply = '';
          } else {
            if (!reply?.trim()) throw new ChannelError('MODEL_EMPTY', '信息整理阶段没有返回内容，未发送内部资料。');
            const packet = parsePersonaOutput(reply, { natural: !!natural });
            if (partialPlanning) packet.incomplete = true;
            const planningMetrics = structuredClone(requestMetrics);
            // A fresh, internal native session cannot recurse into planning or inherit tools.
            const expression = await this.run({ mode: 'persona-expression',
              text: personaPassInput(text, packet, { history, speaker, account, selectedReply: media, memory: memoryData, toolResults, clock }),
              systemOverride: buildPersonaPassPrompt({ group, persona: runtime.persona, prompt, adminNotes,
                identityMarkdown: runtime.identityMarkdown, requestText: text, clock }),
              tools: [], signal, assertAllowed, executionSnapshot: structuredClone({ runtime, selection: selected }), clock,
              onRequestMetrics: rows => onRequestMetrics?.([...planningMetrics, ...rows]),
            });
            signal.throwIfAborted(); assertAllowed();
            if (!expression.text?.trim()) throw new ChannelError('MODEL_EMPTY', '人设表达阶段未返回正文，未发送内部资料。');
            requestMetrics.push(...expression.requestMetrics);
            reply = media || natural ? expression.text : publicText(typeof selectReplyText === 'function' ? selectReplyText(expression.text) : expression.text);
            personaApplied = true;
          }
        }
        let replyStyleWarning;
        if (!internalOutput && !workDialogue && (!systemOverride || mode === 'confirmation') && reply)
          reply = await this.polishReply(reply, text, signal, runtime.persona, {
            prompt,
            runtime,
            onStyleWarning: (note) => {
              replyStyleWarning = note;
            },
          });
        return { text: reply, sessionId: id, requestMetrics, personaMode, personaPasses: personaApplied ? 2 : 1, personaApplied,
          ...(partialPlanning ? { planningIncomplete: true } : {}), ...(emptyResponseRetries ? { emptyResponseRetries } : {}),
          ...(replyStyleWarning ? { replyStyleWarning } : {}) };
      } finally {
        signal.removeEventListener('abort', cancel);
      }
    } catch (error) {
      if (signal.aborted || error instanceof ChannelError) throw error;
      throw new ChannelError('DSH_AGENT_FAILED', 'DSH 会话未能完成，请检查模型配置或在 DSH 查看会话；未发送微信回复');
    } finally {
      if (handle) {
        handle.agent.cancel({ kind: 'disposed' });
        await handle.agent.whenIdle();
        await handle.dispose();
        if (workDialogue) await publishWorkSessionHistory(this.ctx, id);
      }
    }
  }
}
