import { resourcePath } from "../../backend/platform/resources.mjs";
import { configurationFor } from '../../backend/config/repository.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';

import { ChannelError } from "../../shared/contracts.mjs";
import { retireBuiltinStickers, saveWechatSticker, reconcileFavorites, validStickerMd5 } from './wechat-stickers.mjs';
import { assetThumbnail } from './thumbnail.mjs';
import { describeAssets } from './description.mjs';
import { MEDIA_LIBRARY_LIMITS, IMAGE_TYPES, IMAGE_EXTENSIONS } from "./limits.mjs";
import { error, accountId, decodeBase64, plain, normalizeKind } from "./validation.mjs";
import { inspectAssetImage } from "./image-format.mjs";
import { prepareStickerImage } from './sticker-image.mjs';
import { readAssetZip } from "./zip.mjs";
import { selectStickerCandidates } from './sticker-candidates.mjs';

export const SETTINGS = Object.freeze({ enabled: true, probability: 20, minGapMessages: 3 });
export const STICKER_SETTINGS = Object.freeze({ captureIncoming: true, preferNative: true, autoDescribe: true });

export const UPLOADED_PACK = 'user-uploads';

export const assetPack = (asset) => asset.packId || UPLOADED_PACK;

export const validPackId = (value) => typeof value === 'string' && /^[a-z0-9][a-z0-9-]{0,79}$/.test(value);

export const clone = (value) => structuredClone(value);

export const sha = (data) => createHash('sha256').update(data).digest('hex');

function mediaConfiguration(data) {
  return Object.fromEntries(Object.entries(data.accounts).map(([id, record]) => [id, {
    settings: record.settings,
    packs: Object.fromEntries(Object.entries(record.packs || {}).map(([key, pack]) => [key, pack.enabled])),
    assets: Object.fromEntries(record.assets.map(asset => [asset.id, asset.enabled])),
  }]));
}
function mediaSnapshot(data) {
  return { ...data, configurationVersion: 1, accounts: Object.fromEntries(Object.entries(data.accounts).map(([id, record]) => {
    const { settings, ...state } = record;
    return [id, { ...state,
      packs: Object.fromEntries(Object.entries(record.packs || {}).map(([key, pack]) => { const { enabled, ...metadata } = pack; return [key, metadata]; })),
      assets: record.assets.map(asset => { const { enabled, ...metadata } = asset; return metadata; }),
    }];
  })) };
}

export function atomic(file, data) {
  const temporary = path.join(path.dirname(file), '.' + path.basename(file) + '-' + randomUUID() + '.tmp');
  try {
    fs.writeFileSync(temporary, JSON.stringify(data, null, 2), { flag: 'wx', mode: 0o600 });
    fs.renameSync(temporary, file);
  } catch {
    throw error('STATE_WRITE_FAILED', '素材库未能保存，请检查磁盘空间和目录权限');
  } finally {
    try {
      fs.unlinkSync(temporary);
    } catch (failure) {
      if (failure.code !== 'ENOENT') {
      }
    }
  }
}

export function settings(input, previous = STICKER_SETTINGS) {
  if (
    !input ||
    typeof input.enabled !== 'boolean' ||
    !Number.isInteger(input.probability) ||
    input.probability < 0 ||
    input.probability > 100 ||
    !Number.isInteger(input.minGapMessages) ||
    input.minGapMessages < 0 ||
    input.minGapMessages > 100
  )
    throw error('ASSET_SETTINGS_INVALID', '请设置是否开启，自动使用概率 0–100%，以及至少间隔 0–100 条消息');
  const extra = Object.fromEntries(Object.entries(STICKER_SETTINGS).map(([key, fallback]) => [key, input[key] ?? previous[key] ?? fallback]));
  if (Object.values(extra).some(value => typeof value !== 'boolean')) throw error('ASSET_SETTINGS_INVALID', '请选择是否收集聊天表情和使用原生表情');
  return { enabled: input.enabled, probability: input.probability, minGapMessages: input.minGapMessages, ...extra };
}

export class MediaLibrary {
  constructor(store, { now = Date.now, pythonPath, conversionTimeoutMs = 15000 } = {}) {
    configurationFor(store);
    this.store = store;
    this.now = now;
    this.root = path.resolve(store.root, 'storage/assets');
    this.indexFile = path.join(this.root, 'index.json');
    this.uploads = new Map();
    this.completedUploads = new Map();
    this.jobs = new Map();
    this.runtimePath = resourcePath('runtime');
    this.pythonPath = pythonPath || path.join(this.runtimePath, 'python/python.exe');
    this.conversionTimeoutMs = conversionTimeoutMs;
    fs.mkdirSync(this.root, { recursive: true, mode: 0o700 });
    this.assertLocal(this.root);
    try {
      this.assertLocal(this.indexFile, false);
      this.data = JSON.parse(fs.readFileSync(this.indexFile, 'utf8'));
    } catch (failure) {
      if (failure.code !== 'ENOENT') throw error('ASSET_INDEX_INVALID', '素材库索引无法读取，未重置已有素材');
    }
    this.data ??= { version: 1, configurationVersion: 1, ownerStoreId: store.data.storeId, revision: 0, accounts: {} };
    if (
      this.data.version !== 1 ||
      this.data.ownerStoreId !== store.data.storeId ||
      !this.data.accounts ||
      typeof this.data.accounts !== 'object' ||
      Array.isArray(this.data.accounts)
    )
      throw error('ASSET_INDEX_INVALID', '素材库格式或归属有误');
    for (const record of Object.values(this.data.accounts)) {
      if (!record || !Array.isArray(record.assets)) throw error('ASSET_INDEX_INVALID', '素材库条目格式有误');
      if (this.data.configurationVersion === 1) {
        const id = Object.keys(this.data.accounts).find(key => this.data.accounts[key] === record);
        const configuration = store.config.section('media')[id] ?? { settings: store.config.section('mediaDefaults'), packs: {}, assets: {} };
        record.settings = configuration.settings;
        for (const [key, pack] of Object.entries(record.packs || {})) pack.enabled = configuration.packs[key] ?? !key.startsWith('builtin-');
        for (const asset of record.assets) asset.enabled = configuration.assets[asset.id] ?? true;
      }
      record.settings = settings(record.settings);
      if (
        record.packs !== undefined &&
        (!record.packs ||
          typeof record.packs !== 'object' ||
          Array.isArray(record.packs) ||
          Object.entries(record.packs).some(
            ([id, pack]) =>
              !validPackId(id) || !pack || typeof pack.enabled !== 'boolean' || typeof pack.name !== 'string'
          ))
      )
        throw error('ASSET_INDEX_INVALID', '素材分组设置损坏，未重置已有设置');
      for (const asset of record.assets)
        if (
          !/^[a-f0-9]{64}$/.test(asset.id) ||
          (!(asset.bytes === 0 && validStickerMd5(asset.nativeSticker?.md5)) && (!IMAGE_TYPES.has(asset.mediaType) || !['png', 'jpg', 'gif', 'webp'].includes(asset.extension))) ||
          (asset.nativeSticker !== undefined && (!validStickerMd5(asset.nativeSticker?.md5) || typeof asset.nativeSticker.favorite !== 'boolean')) ||
          (asset.contentSha256 !== undefined && !/^[a-f0-9]{64}$/.test(asset.contentSha256)) ||
          typeof asset.enabled !== 'boolean' ||
          typeof asset.name !== 'string' ||
          typeof asset.description !== 'string' || (asset.usage !== undefined && typeof asset.usage !== 'string') ||
          !Array.isArray(asset.tags) ||
          (asset.packId !== undefined && !validPackId(asset.packId))
        )
          throw error('ASSET_INDEX_INVALID', '素材条目损坏，未读取任意路径');
    }
    if (this.data.configurationVersion !== 1) {
      store.config.update('media', { ...store.config.section('media'), ...mediaConfiguration(this.data) }, store.data,
        [{ file: this.indexFile, bytes: Buffer.from(JSON.stringify(mediaSnapshot(this.data), null, 2) + '\n') }]);
      this.data.configurationVersion = 1;
    }
    retireBuiltinStickers(this);
  }
  assertLocal(file, required = true) {
    const relative = path.relative(this.root, file);
    if (relative.startsWith('..') || path.isAbsolute(relative))
      throw error('ASSET_PATH_INVALID', '素材不在当前素材库目录中');
    let current = file;
    while (true) {
      try {
        if (fs.lstatSync(current).isSymbolicLink()) throw error('ASSET_PATH_INVALID', '素材目录不能使用重定向链接');
      } catch (failure) {
        if (failure.code !== 'ENOENT' || (required && current === file)) throw failure;
      }
      if (current === this.root) break;
      current = path.dirname(current);
    }
  }
  account(id, create = false, data = this.data) {
    accountId(id);
    if (create && !Object.hasOwn(data.accounts, id))
      Object.defineProperty(data.accounts, id, {
        value: { settings: settings(this.store.config.section('media')[id]?.settings ?? this.store.config.data.mediaDefaults), assets: [] },
        enumerable: true,
        writable: true,
        configurable: true,
      });
    return Object.hasOwn(data.accounts, id) ? data.accounts[id] : { settings: settings(this.store.config.section('media')[id]?.settings ?? this.store.config.data.mediaDefaults), assets: [] };
  }
  folder(id) {
    accountId(id);
    return path.join(this.root, sha(id).slice(0, 24));
  }
  file(id, asset) {
    return path.join(this.folder(id), (asset.contentSha256 || asset.id) + '.' + asset.extension);
  }
  mutate(action) {
    const next = clone(this.data);
    const result = action(next);
    next.revision++;
    this.assertLocal(this.indexFile, false);
    this.store.config.update('media', { ...this.store.config.section('media'), ...mediaConfiguration(next) }, this.store.data,
      [{ file: this.indexFile, bytes: Buffer.from(JSON.stringify(mediaSnapshot(next), null, 2) + '\n') }]);
    this.data = next;
    return result;
  }
  packEnabled(record, packId) {
    return record.packs?.[packId]?.enabled ?? !packId.startsWith('builtin-');
  }
  assetEnabled(record, asset) {
    return asset.enabled && this.packEnabled(record, assetPack(asset));
  }
  packs(id) {
    const record = this.account(id);
    const known = new Set();
    const imported = new Map(
      Object.entries(record.packs || {}).filter(([id]) => !known.has(id) && !id.startsWith('builtin-'))
    );
    for (const asset of record.assets)
      if (!known.has(assetPack(asset)) && !imported.has(assetPack(asset)))
        imported.set(assetPack(asset), { name: '我导入的图片', enabled: true });
    const counts = (packId) => {
      const assets = record.assets.filter((asset) => assetPack(asset) === packId);
      return {
        installed: assets.length,
        enabledAssets: assets.filter((asset) => this.assetEnabled(record, asset)).length,
      };
    };
    return [
      ...[...imported].map(([id, pack]) => ({
        id,
        name: pack.name,
        builtin: false,
        enabled: this.packEnabled(record, id),
        ...counts(id),
      })),
    ];
  }
  validatePackSetting(id, packId, enabled) {
    if (!validPackId(packId) || typeof enabled !== 'boolean')
      throw error('ASSET_PACK_INVALID', '请选择素材分组并设置是否启用');
    const pack = this.packs(id).find((value) => value.id === packId);
    if (!pack) throw error('ASSET_PACK_NOT_FOUND', '这组素材不存在，请刷新后重试');
    return {
      ...pack,
      assetIds: this.account(id)
        .assets.filter((asset) => assetPack(asset) === packId)
        .map((asset) => asset.id),
    };
  }
  configurePack(id, packId, enabled) {
    const pack = this.validatePackSetting(id, packId, enabled);
    this.mutate((data) => {
      const record = this.account(id, true, data);
      record.packs ??= {};
      record.packs[packId] = { name: pack.name, enabled };
    });
    return { packId, enabled };
  }
  configure(id, input) {
    const next = settings(input, this.account(id).settings);
    this.mutate((data) => {
      this.account(id, true, data).settings = next;
    });
    return this.list(id);
  }
  list(id, { query = '', kind, packId, source, enabled, offset = 0, limit = 24 } = {}) {
    if (source && !['favorite', 'chat', 'upload'].includes(source)) throw error('ASSET_SOURCE_INVALID', '请选择微信收藏、聊天收集或自行导入');
    const record = this.account(id),
      normalized = String(query).normalize('NFKC').trim().toLocaleLowerCase();
    if (!Number.isInteger(offset) || offset < 0 || !Number.isInteger(limit) || limit < 1 || limit > 100)
      throw error('ASSET_PAGE_INVALID', '素材分页范围无效');
    const matching = record.assets
      .filter(
        (asset) =>
          (!kind || asset.kind === kind) &&
          (!packId || assetPack(asset) === packId) &&
          (!source || (source === 'favorite' ? asset.nativeSticker?.favorite === true : source === 'chat' ? !!asset.sourceMessage : !asset.nativeSticker && !asset.sourceMessage)) &&
          (enabled === undefined || this.assetEnabled(record, asset) === enabled) &&
          (!normalized ||
            [asset.name, asset.description, asset.usage || '', ...asset.tags]
              .join('\n')
              .normalize('NFKC')
              .toLocaleLowerCase()
              .includes(normalized))
      )
      .sort((a, b) => b.createdAt - a.createdAt || a.name.localeCompare(b.name, 'zh-CN'));
    return {
      items: matching
        .slice(offset, offset + limit)
        .map((asset) => ({
          ...clone(asset),
          packId: assetPack(asset),
          packEnabled: this.packEnabled(record, assetPack(asset)),
          effectiveEnabled: this.assetEnabled(record, asset),
        })),
      total: matching.length,
      offset,
      limit,
      settings: clone(record.settings),
      revision: this.data.revision,
      packs: clone(this.packs(id)),
      counts: {
        all: record.assets.length,
        enabled: record.assets.filter((asset) => this.assetEnabled(record, asset)).length,
        described: record.assets.filter((asset) => asset.description).length,
        bytes: record.assets.reduce((sum, asset) => sum + asset.bytes, 0),
        favorites: record.assets.filter(asset => asset.nativeSticker?.favorite).length,
        collected: record.assets.filter(asset => asset.sourceMessage).length,
        native: record.assets.filter(asset => asset.nativeSticker).length,
      },
      stickerSync: clone(record.stickerSync || null),
      retiredBuiltinCount: record.retiredBuiltinCount || 0,
      progress: clone(this.jobs.get(id) || null),
      path: this.folder(id),
      limits: MEDIA_LIBRARY_LIMITS,
    };
  }
  replyStickerCandidates(id, options = {}) {
    const record = this.account(id);
    if (!record.settings.enabled) return { candidates: [], eligibleCount: 0, relevantCount: 0 };
    return selectStickerCandidates(record.assets.filter(asset => asset.kind === 'sticker' && this.assetEnabled(record, asset)), options);
  }
  search(id, query = '', { kind, limit = 12 } = {}) {
    if (!this.account(id).settings.enabled) return [];
    return this.list(id, { query, kind, enabled: true, limit: Math.min(50, Math.max(1, limit)) }).items;
  }
  resolveAsset(id, assetId, { enabledOnly = true } = {}) {
    if (!/^[a-f0-9]{64}$/.test(assetId || '')) throw error('ASSET_NOT_FOUND', '这张素材不存在');
    const record = this.account(id),
      asset = record.assets.find((value) => value.id === assetId);
    if (!asset || (enabledOnly && (!record.settings.enabled || !this.assetEnabled(record, asset))))
      throw error('ASSET_NOT_FOUND', '这张素材不存在、所属分组或素材已停用，或不属于当前账号');
    return clone(asset);
  }
  getContent(id, assetId, options) {
    const asset = this.resolveAsset(id, assetId, options),
      file = this.file(id, asset);
    if (!asset.bytes) throw error('STICKER_PREVIEW_UNAVAILABLE', '微信暂未提供表情预览，仍可使用原生表情发送');
    try {
      this.assertLocal(file);
      const stat = fs.statSync(file);
      if (!stat.isFile() || stat.size !== asset.bytes || stat.size > MEDIA_LIBRARY_LIMITS.imageBytes)
        throw error('ASSET_CONTENT_INVALID', '素材文件大小已变化');
      const content = fs.readFileSync(file);
      if (sha(content) !== (asset.contentSha256 || asset.id)) throw error('ASSET_CONTENT_INVALID', '素材内容已改变，未读取被替换的文件');
      return { ...asset, data: content.toString('base64') };
    } catch (failure) {
      if (failure instanceof ChannelError) throw failure;
      throw error('ASSET_CONTENT_MISSING', '素材文件无法读取，可能已被移动或删除');
    }
  }
  async prepareSendContent(id, assetId, signal = new AbortController().signal) {
    signal.throwIfAborted();
    const asset = this.getContent(id, assetId);
    if (['image/png', 'image/jpeg'].includes(asset.mediaType) && asset.nativeSticker) {
      const pixels = prepareStickerImage(Buffer.from(asset.data, 'base64')).content;
      return { ...asset, bytes: pixels.length, data: pixels.toString('base64') };
    }
    if (['image/png', 'image/jpeg'].includes(asset.mediaType)) return asset;
    const script = path.join(this.runtimePath, 'prepare_reply_image.py');
    if (!fs.existsSync(script) || (path.isAbsolute(this.pythonPath) && !fs.existsSync(this.pythonPath)))
      throw error('ASSET_CONVERTER_MISSING', '图片转换组件尚未就绪，请安装完整插件包；当前可发送 PNG 或 JPEG');
    const source = Buffer.from(asset.data, 'base64');
    const converted = await new Promise((resolve, reject) => {
      let child,
        finished = false,
        bytes = 0,
        failure,
        timer;
      const parts = [];
      const complete = (cause) => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        signal.removeEventListener('abort', abort);
        cause ? reject(cause) : resolve(Buffer.concat(parts));
      };
      const stop = (cause) => {
        failure ??= cause;
        if (child && child.exitCode === null && child.signalCode === null) child.kill();
      };
      const abort = () => stop(signal.reason || error('CANCELLED', '图片转换已取消'));
      try {
        child = spawn(this.pythonPath, ['-B', script], {
          windowsHide: true,
          shell: false,
          stdio: ['pipe', 'pipe', 'pipe'],
        });
        signal.addEventListener('abort', abort, { once: true });
        if (signal.aborted) abort();
        timer = setTimeout(
          () => stop(error('ASSET_CONVERSION_TIMEOUT', '图片转换超时，未继续发送')),
          this.conversionTimeoutMs
        );
        timer.unref?.();
        child.once('error', () =>
          complete(error('ASSET_CONVERTER_MISSING', '图片转换组件无法启动，请重新安装完整插件包'))
        );
        child.stdout.on('data', (chunk) => {
          bytes += chunk.length;
          if (bytes > MEDIA_LIBRARY_LIMITS.imageBytes)
            stop(error('ASSET_CONVERTED_TOO_LARGE', '转换后的图片超过 10 MiB，未继续发送'));
          else parts.push(chunk);
        });
        let stderr = '';
        child.stderr.on('data', (chunk) => {
          if (stderr.length < 200) stderr += chunk.toString('utf8').slice(0, 200 - stderr.length);
        });
        child.stdin.on('error', () => {});
        child.once('close', (code) => {
          if (failure) complete(failure);
          else if (code !== 0)
            complete(
              error(
                stderr.includes('OUTPUT_TOO_LARGE') ? 'ASSET_CONVERTED_TOO_LARGE' : 'ASSET_CONVERSION_FAILED',
                stderr.includes('OUTPUT_TOO_LARGE')
                  ? '转换后的图片超过 10 MiB，未继续发送'
                  : 'GIF 或 WebP 不能转换为有效静态图片，请检查素材或换一张'
              )
            );
          else complete();
        });
        child.stdin.end(source);
      } catch {
        complete(error('ASSET_CONVERTER_MISSING', '图片转换组件无法启动，请重新安装完整插件包'));
      }
    });
    signal.throwIfAborted();
    const info = inspectAssetImage(converted);
    if (info.mediaType !== 'image/png') throw error('ASSET_CONVERSION_FAILED', '转换组件没有返回有效 PNG，未继续发送');
    // Recheck owner settings and deletion after asynchronous conversion.
    this.resolveAsset(id, assetId);
    return {
      ...asset,
      ...info,
      bytes: converted.length,
      data: converted.toString('base64'),
      sourceMediaType: asset.mediaType,
      staticFrame: true,
    };
  }
  import(id, input) {
    accountId(id);
    const name = plain(input?.name, '文件名', 1000, false),
      kind = normalizeKind(input.kind),
      data = decodeBase64(input.data, MEDIA_LIBRARY_LIMITS.uploadBytes);
    if (!/\.zip$/i.test(name) && !IMAGE_EXTENSIONS.test(name))
      throw error('ASSET_IMAGE_INVALID', '请选择 ZIP、PNG、JPEG、GIF 或 WebP 文件');
    const bundle = /\.zip$/i.test(name)
      ? readAssetZip(data)
      : { images: [{ name, data, info: inspectAssetImage(data) }], skipped: 0 };
    const packName =
      name
        .replaceAll('\\', '/')
        .split('/')
        .at(-1)
        .replace(/\.zip$/i, '')
        .trim()
        .slice(0, 120) || '导入的表情包';
    const pack = /\.zip$/i.test(name)
      ? { id: 'import-' + sha(packName.normalize('NFKC')).slice(0, 24), name: packName }
      : { id: UPLOADED_PACK, name: '我导入的图片' };
    return this.importImages(id, { ...bundle, kind, pack });
  }
  saveWechatSticker(id, input) { return saveWechatSticker(this, id, input); }
  thumbnail(id, assetId, signal) { return assetThumbnail(this, id, assetId, signal); }
  reconcileFavorites(id, md5s, fetchedAt) { return reconcileFavorites(this, id, md5s, fetchedAt); }
  randomSticker(id, { query = '', excludeIds = [], random = Math.random } = {}) {
    if (!this.account(id).settings.enabled) return null;
    const record = this.account(id), normalized = query.normalize('NFKC').trim().toLocaleLowerCase();
    let pool = record.assets.filter(asset => asset.kind === 'sticker' && this.assetEnabled(record, asset) && (!normalized || [asset.name, asset.description, asset.usage || '', ...asset.tags].join(' ').normalize('NFKC').toLocaleLowerCase().includes(normalized)));
    const favorites = pool.filter(asset => asset.nativeSticker?.favorite);
    if (favorites.length) pool = favorites;
    const fresh = pool.filter(asset => !excludeIds.includes(asset.id)); if (fresh.length) pool = fresh;
    if (!pool.length) return null;
    return clone(pool[Math.floor(Math.max(0, Math.min(0.999999999, random())) * pool.length)]);
  }
  async prepareSendSegment(id, assetId, signal = new AbortController().signal, { nativeReady = true } = {}) {
    const asset = this.resolveAsset(id, assetId);
    const native = asset.kind === 'sticker' && asset.nativeSticker && this.account(id).settings.preferNative && nativeReady;
    let prepared;
    try { prepared = await this.prepareSendContent(id, assetId, signal); }
    catch (failure) {
      signal.throwIfAborted();
      if (!native || !['STICKER_PREVIEW_UNAVAILABLE', 'ASSET_CONVERTER_MISSING', 'ASSET_CONVERSION_FAILED', 'ASSET_CONVERSION_TIMEOUT'].includes(failure.code)) throw failure;
    }
    signal.throwIfAborted(); this.resolveAsset(id, assetId);
    return { type: native || asset.kind === 'sticker' ? 'face' : 'image', data: {
      ...(native ? { nativeSticker: { md5: asset.nativeSticker.md5 } } : {}),
      ...(prepared ? { base64: prepared.data, mediaType: prepared.mediaType } : {}),
    } };
  }
  importImages(id, { images, skipped = 0, kind, pack, enablePack }) {
    const previous = this.account(id),
      known = new Map(previous.assets.map((asset) => [asset.contentSha256 || asset.id, asset.id])),
      added = [],
      duplicateIds = [];
    let bytes = previous.assets.reduce((sum, asset) => sum + asset.bytes, 0);
    for (const image of images) {
      const hash = sha(image.data);
      if (known.has(hash)) {
        duplicateIds.push(known.get(hash));
        continue;
      }
      known.set(hash, hash);
      bytes += image.data.length;
      const basename =
        image.name
          .replaceAll('\\', '/')
          .split('/')
          .at(-1)
          .replace(/\.[^.]+$/, '')
          .trim()
          .slice(0, 120) || '未命名图片';
      const folders = image.name
        .replaceAll('\\', '/')
        .split('/')
        .slice(0, -1)
        .filter(Boolean)
        .slice(-3)
        .map((value) => value.slice(0, 40));
      added.push({
        content: image.data,
        asset: {
          id: hash,
          name: image.metadata?.name ?? basename,
          description: image.metadata?.description ?? '',
          usage: image.metadata?.usage ?? '',
          tags: image.metadata?.tags ?? [...new Set(folders)],
          kind,
          enabled: true,
          packId: pack.id,
          ...image.info,
          bytes: image.data.length,
          originalName: image.name.slice(0, 1000),
          createdAt: this.now(),
          updatedAt: this.now(),
          revision: 1,
          descriptionError: null,
        },
      });
    }
    if (
      bytes > MEDIA_LIBRARY_LIMITS.accountBytes ||
      previous.assets.length + added.length > MEDIA_LIBRARY_LIMITS.accountAssets
    )
      throw error('ASSET_QUOTA', '当前账号素材库最多 2000 张、512 MiB，请先清理不再使用的素材');
    const created = [];
    fs.mkdirSync(this.folder(id), { recursive: true, mode: 0o700 });
    this.assertLocal(this.folder(id));
    try {
      for (const { asset, content } of added) {
        const file = this.file(id, asset);
        this.assertLocal(file, false);
        if (fs.existsSync(file)) {
          if (sha(fs.readFileSync(file)) !== asset.id)
            throw error('ASSET_CONTENT_INVALID', '同名素材文件内容异常，未覆盖');
        } else {
          fs.writeFileSync(file, content, { flag: 'wx', mode: 0o600 });
          created.push(file);
        }
      }
      if (added.length || enablePack !== undefined)
        this.mutate((next) => {
          const record = this.account(id, true, next);
          record.packs ??= {};
          record.packs[pack.id] = { name: pack.name, enabled: enablePack ?? this.packEnabled(record, pack.id) };
          record.assets.push(...added.map((value) => value.asset));
        });
    } catch (failure) {
      for (const file of created) {
        try {
          this.assertLocal(file);
          fs.unlinkSync(file);
        } catch {}
      }
      throw failure;
    }
    return {
      imported: added.length,
      duplicates: duplicateIds.length,
      skipped,
      assetIds: added.map((value) => value.asset.id),
      duplicateIds,
      total: this.account(id).assets.length,
    };
  }
  edit(id, assetId, patch) {
    const previous = this.resolveAsset(id, assetId, { enabledOnly: false });
    if (
      !patch ||
      typeof patch !== 'object' ||
      Array.isArray(patch) ||
      Object.keys(patch).some((key) => !['name', 'description', 'usage', 'tags', 'kind', 'enabled', 'revision'].includes(key))
    )
      throw error('ASSET_METADATA_INVALID', '素材设置格式无效');
    if (patch.revision !== undefined && patch.revision !== previous.revision)
      throw error('ASSET_CHANGED', '素材已被更新，请重新打开后编辑');
    const value = { ...previous };
    if (patch.name !== undefined) value.name = plain(patch.name, '素材名称', 120, false);
    if (patch.description !== undefined) {
      value.description = plain(patch.description, '素材含义', 1600);
      value.descriptionError = null;
    }
    if (patch.usage !== undefined) { value.usage = plain(patch.usage, '适用情景', 600); value.descriptionError = null; }
    if (patch.tags !== undefined) {
      if (!Array.isArray(patch.tags) || patch.tags.length > 16)
        throw error('ASSET_METADATA_INVALID', '每张素材最多 16 个标签');
      value.tags = [...new Set(patch.tags.map((tag) => plain(tag, '标签', 40, false)))];
    }
    if (patch.kind !== undefined) value.kind = normalizeKind(patch.kind);
    if (patch.enabled !== undefined) {
      if (typeof patch.enabled !== 'boolean') throw error('ASSET_METADATA_INVALID', '请选择是否启用这张素材');
      value.enabled = patch.enabled;
    }
    value.revision++;
    value.updatedAt = this.now();
    this.mutate((next) => {
      const assets = this.account(id, true, next).assets;
      assets[assets.findIndex((asset) => asset.id === assetId)] = value;
    });
    return clone(value);
  }
  remove(id, assetIds) {
    if (!Array.isArray(assetIds) || !assetIds.length || assetIds.length > 300)
      throw error('ASSET_SELECTION_INVALID', '请选择 1–300 张要删除的素材');
    const targets = [...new Set(assetIds)].map((assetId) => this.resolveAsset(id, assetId, { enabledOnly: false })),
      ids = new Set(targets.map((asset) => asset.id));
    this.mutate((next) => {
      const record = this.account(id, true, next);
      record.deletedStickers = [...new Set([...(record.deletedStickers || []), ...targets.filter(asset => asset.nativeSticker || asset.sourceMessage).flatMap(asset =>
        [asset.nativeSticker?.md5, asset.id, asset.contentSha256].filter(Boolean))])];
      record.assets = record.assets.filter((asset) => !ids.has(asset.id));
    });
    let retainedFiles = 0;
    for (const asset of targets) {
      try {
        const file = this.file(id, asset);
        if (!asset.bytes || this.account(id).assets.some(item => this.file(id, item) === file)) continue;
        this.assertLocal(file);
        fs.unlinkSync(file);
      } catch (failure) {
        if (failure.code !== 'ENOENT') retainedFiles++;
      }
    }
    return { removed: targets.length, retainedFiles };
  }
  beginUpload(id, input) {
    accountId(id);
    const name = plain(input?.name, '文件名', 1000, false),
      kind = normalizeKind(input.kind),
      size = input.size;
    if (!Number.isSafeInteger(size) || size < 1 || size > MEDIA_LIBRARY_LIMITS.uploadBytes)
      throw error('ASSET_TOO_LARGE', '单次上传最多 32 MiB');
    if (this.uploads.size >= 8) throw error('ASSET_UPLOAD_BUSY', '同时上传的文件过多，请完成当前上传后再试');
    const uploadId = randomUUID(),
      directory = path.join(this.root, 'uploads');
    fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
    this.assertLocal(directory);
    for (const entry of fs.readdirSync(directory))
      if (/^[a-f0-9-]{36}\.part$/.test(entry)) {
        const file = path.join(directory, entry);
        this.assertLocal(file);
        if (this.now() - fs.statSync(file).mtimeMs > 86400000) fs.unlinkSync(file);
      }
    const file = path.join(directory, uploadId + '.part');
    fs.writeFileSync(file, Buffer.alloc(0), { flag: 'wx', mode: 0o600 });
    this.uploads.set(uploadId, {
      id: uploadId,
      accountId: id,
      name,
      kind,
      size,
      received: 0,
      file,
      startedAt: this.now(),
    });
    return { uploadId, chunkBytes: MEDIA_LIBRARY_LIMITS.chunkBytes, received: 0, total: size };
  }
  upload(id, uploadId) {
    accountId(id);
    const upload = this.uploads.get(uploadId);
    if (!upload || upload.accountId !== id)
      throw error('ASSET_UPLOAD_MISSING', '上传已结束或不属于当前账号，请重新选择文件');
    return upload;
  }
  appendUpload(id, uploadId, input) {
    const upload = this.upload(id, uploadId),
      content = decodeBase64(input?.data, MEDIA_LIBRARY_LIMITS.chunkBytes),
      offset = input.offset;
    if (!Number.isSafeInteger(offset) || offset < 0 || offset + content.length > upload.size)
      throw error('ASSET_UPLOAD_INVALID', '上传分块范围无效');
    this.assertLocal(upload.file);
    const stat = fs.statSync(upload.file);
    if (stat.size !== upload.received) throw error('ASSET_UPLOAD_INVALID', '上传临时文件已变化，请重新上传');
    if (offset < upload.received && offset + content.length <= upload.received) {
      const previous = Buffer.alloc(content.length),
        descriptor = fs.openSync(upload.file, 'r');
      try {
        fs.readSync(descriptor, previous, 0, previous.length, offset);
      } finally {
        fs.closeSync(descriptor);
      }
      if (!previous.equals(content)) throw error('ASSET_UPLOAD_INVALID', '重试分块与已接收内容不一致');
    } else {
      if (offset !== upload.received) throw error('ASSET_UPLOAD_INVALID', '上传分块顺序不正确，请重试当前分块');
      fs.appendFileSync(upload.file, content);
      upload.received += content.length;
    }
    return { uploadId, received: upload.received, total: upload.size };
  }
  finishUpload(id, uploadId) {
    const completed = this.completedUploads.get(uploadId);
    if (completed?.accountId === id) return clone(completed.result);
    const upload = this.upload(id, uploadId);
    if (upload.received !== upload.size) throw error('ASSET_UPLOAD_INCOMPLETE', '文件尚未上传完整');
    this.assertLocal(upload.file);
    try {
      if (fs.statSync(upload.file).size !== upload.size)
        throw error('ASSET_UPLOAD_INVALID', '上传临时文件长度已改变，请重新上传');
      const result = this.import(id, {
        name: upload.name,
        kind: upload.kind,
        data: fs.readFileSync(upload.file).toString('base64'),
      });
      this.completedUploads.set(uploadId, { accountId: id, result });
      while (this.completedUploads.size > 100) this.completedUploads.delete(this.completedUploads.keys().next().value);
      return clone(result);
    } finally {
      this.releaseUpload(uploadId);
    }
  }
  /** Drops the upload registry entry even when the temp file cannot be removed. */
  releaseUpload(uploadId) {
    const upload = this.uploads.get(uploadId);
    if (!upload) return;
    this.uploads.delete(uploadId);
    try {
      fs.unlinkSync(upload.file);
    } catch {
      /* The import already succeeded; a leftover temp file must not fail it. */
    }
  }
  abortUpload(id, uploadId) {
    const upload = this.uploads.get(uploadId);
    if (!upload) return { cancelled: false };
    if (upload.accountId !== accountId(id)) throw error('ASSET_UPLOAD_MISSING', '上传不属于当前账号');
    this.assertLocal(upload.file, false);
    this.uploads.delete(uploadId);
    try {
      fs.unlinkSync(upload.file);
    } catch (failure) {
      if (failure.code !== 'ENOENT') throw error('ASSET_UPLOAD_INVALID', '上传已取消，临时文件暂未清理');
    }
    return { cancelled: true };
  }
  describe(id, assetIds, runner, signal, options) { return describeAssets(this, id, assetIds, runner, signal, options); }
  close() {
    for (const upload of [...this.uploads.values()]) {
      try {
        this.abortUpload(upload.accountId, upload.id);
      } catch {
        /* One unruly temp file must not strand the remaining uploads. */
      }
    }
  }
}
