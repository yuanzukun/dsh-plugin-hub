import { TasksPage } from "./pages/tasks/page.jsx";
import { WorkPage } from './pages/work/page.jsx';
import { MomentsPage } from './pages/moments/page.jsx';
import { MediaWorkspace } from "./pages/media/workspace.jsx";
import { DiagnosticsPage } from "./pages/diagnostics/page.jsx";
import { RecoveryPage } from "./pages/recovery/page.jsx";
import { DigestsPage } from "./pages/digests/page.jsx";
import { peerId, peerType, splitLines } from "./shared/conversations.mjs";
import { same, personaDraft, modelDraft, storageDraft, configDraft, configPayload, remoteDraft } from "./shared/drafts.mjs";
import { AdministratorSettings } from './pages/settings/administrators-page.jsx';
import { call, withTimeout, memoryRpcTimeoutMs } from "./shared/rpc.mjs";
import { PageHead } from "./components/page-ui.jsx";
import { Overview } from "./pages/overview/page.jsx";
import { Authorization } from "./pages/conversations/authorization-page.jsx";
import { ConversationSettings } from "./pages/conversations/settings-page.jsx";
import { SettingsIndex } from "./pages/settings/page.jsx";
import { IdentitySettings } from "./pages/settings/identity-page.jsx";
import { Changelog } from "./pages/settings/changelog-page.jsx";
import { WorkspaceTabs } from "./components/workspace-tabs.jsx";
import { MemoryWorkspace } from "./pages/memory/workspace.jsx";
import { ModelSettings } from "./pages/settings/model-page.jsx";
import { ImageGenerationSettings } from './pages/settings/image-generation-page.jsx';
import { PersonaSettings } from "./pages/settings/persona-page.jsx";
import { StorageSettings } from "./pages/settings/storage-page.jsx";
import { TimeSettings } from './pages/settings/time-page.jsx';
import { AutomationSettings } from './pages/settings/automation-page.jsx';
import { preserveTimeValues } from '../shared/time-settings.mjs';
import { Records } from "./pages/records/page.jsx";
import { ExecutionTracesPage } from './pages/traces/page.jsx';

export function PanelContent({ connection, catalog, state }) {
  const {
    motion,
    status,
    page,
    setPage,
    memoryTab,
    setMemoryTab,
    automationTarget,
    error,
    busy,
    busyArea,
    notice,
    contacts,
    authQuery,
    setAuthQuery,
    authType,
    setAuthType,
    authTab,
    setAuthTab,
    drafts,
    recordQuery,
    setRecordQuery,
    recordType,
    setRecordType,
    recordOffset,
    recordData,
    recordLoading,
    recordError,
    statusRef,
    draftsRef,
    workspaceRef,
    rows,
    detail,
    recordRows,
    recordSelected,
    setDraft,
    action,
    navigate,
    restoreDefaultPersona,
    back,
    backLabel,
    openDetail,
    selectRecord,
    holdRecordPosition,
    changeRecordPage,
    refreshRecords,
    openRecords,
    saveSettings,
    grant,
    grantMany,
    blocked,
    navPage,
    warning,
  } = state;
  let content;

  if (!status || !drafts.persona || !drafts.model || !drafts.storage)
    content = (
      <>
        <PageHead title="微信 Agent" description="正在读取你的工作台…" />
        <div className="wa-card wa-loading-block">
          <div className="wa-skeleton" style={{ width: '42%' }} />
          <div className="wa-skeleton" style={{ width: '78%' }} />
          <div className="wa-skeleton" />
        </div>
      </>
    );
  else if (page === 'overview')
    content = <Overview status={status} busy={busy} blocked={blocked} onAction={action} onNavigate={navigate} />;
  else if (page === 'traces') content = <ExecutionTracesPage key={status.account?.id || 'offline'} status={status}
    rpc={(endpoint, payload, signal) => call(connection, endpoint, payload, withTimeout(signal, 120000))} />;
  else if (['diagnostics', 'digests', 'work', 'moments'].includes(page)) {
    const Page = { diagnostics: DiagnosticsPage, digests: DigestsPage, work: WorkPage, moments: MomentsPage }[page];
    content = (
      <Page
        key={page + ':' + (status.account?.id || 'offline')}
        rpc={(endpoint, payload, signal) => call(connection, endpoint, payload, signal || AbortSignal.timeout(300000))}
        status={status}
        onNavigate={navigate}
      />
    );
  } else if (page === 'authorization')
    content = (
      <Authorization
        key={status.account?.id || 'offline'}
        status={status}
        rows={rows}
        contacts={contacts}
        query={authQuery}
        setQuery={setAuthQuery}
        type={authType}
        setType={setAuthType}
        tab={authTab}
        setTab={setAuthTab}
        blocked={blocked}
        busy={busy}
        notice={notice}
        onAction={action}
        onGrant={grant}
        onGrantMany={grantMany}
        onDetail={openDetail}
        onNavigate={navigate}
      />
    );
  else if (page === 'settings') content = <SettingsIndex status={status} onNavigate={navigate} />;
  else if (page === 'automation') content = <AutomationSettings key={status.account?.id || 'offline'} status={status} rows={recordRows}
    target={automationTarget} blocked={blocked} notice={notice} onNavigate={navigate} onBack={back} backLabel={backLabel}
    rpc={(endpoint, payload, signal) => call(connection, endpoint, payload, withTimeout(signal, 120000))}
    onToggle={(feature, enabled) => {
      const current = statusRef.current.settings || {},
        next = { ...current, schedules: current.schedules ?? current.enabled, moments: current.moments ?? current.enabled };
      if (feature === 'replies') next.enabled = enabled; else next[feature] = enabled;
      saveSettings(next, { area: 'automation', text: {
        replies: enabled ? '自动回复已开启，开始处理之后收到的新消息。' : '自动回复已暂停，定时任务和朋友圈按各自的开关运行。',
        schedules: enabled ? '定时任务已开启，按计划发送。' : '定时任务已暂停，已有任务和时间设置继续保留。',
        moments: enabled ? '朋友圈自动功能已开启。' : '朋友圈自动功能已暂停，各分组设置继续保留。',
      }[feature] });
    }} />;
  else if (page === 'time') content = <TimeSettings key={status.account?.id || 'offline'} status={status} blocked={blocked}
    rpc={(endpoint, payload, signal) => call(connection, endpoint, payload, withTimeout(signal, 120000))} onBack={back} backLabel={backLabel} />;
  else if (page === 'image-generation') content = <ImageGenerationSettings status={status} blocked={blocked}
    onAction={(endpoint, payload) => action(endpoint, payload, { area: 'image-generation' })} onBack={back} backLabel={backLabel} />;
  else if (page === 'identity')
    content = (
      <IdentitySettings
        connection={connection}
        blocked={blocked}
        onSave={(payload) => action('identity.save', payload, { area: 'identity' })}
        onBack={back}
        backLabel={backLabel}
      />
    );
  else if (page === 'changelog') content = <Changelog connection={connection} onBack={() => setPage('settings')} />;
  else if (page === 'administrators') content = <AdministratorSettings
    rpc={(endpoint, payload, signal) => call(connection, endpoint, payload, signal)} status={status} draft={drafts.remote || remoteDraft(status.remote)}
    blocked={blocked} busy={busyArea === 'administrators' ? busy : ''} notice={notice}
    dirty={!same(drafts.remote, remoteDraft(status.remote))} onChange={value => setDraft('remote', value)}
    onSave={() => action('administrators.configure', { accountId: status.account.id, remote: draftsRef.current.remote },
      { area: 'administrators', force: ['remote'], text: '全局管理员已保存，远程查询权限立即按新名单检查。' })}
    onReset={() => setDraft('remote', remoteDraft(status.remote))} onBack={() => setPage('settings')} />;
  else if (page === 'model')
    content = (
      <ModelSettings
        connection={connection}
        catalog={catalog}
        status={status}
        draft={drafts.model}
        prompt={drafts.prompt}
        blocked={blocked}
        busy={busyArea === 'model' ? busy : ''}
        notice={notice}
        modelDirty={!same(drafts.model, modelDraft(status.modelConfig))}
        promptDirty={drafts.prompt !== (status.settings?.prompt || '')}
        onModelChange={(value) => setDraft('model', value)}
        onModelSave={() =>
          action(
            'model.configure',
            {
              modelConfig: {
                promptStrategy: draftsRef.current.model.promptStrategy ?? 'legacy',
                vision: draftsRef.current.model.vision,
                visionModel: draftsRef.current.model.visionModel,
                webSearch: draftsRef.current.model.webSearch,
                searchProvider: draftsRef.current.model.searchProvider,
                tavilyBaseURL: draftsRef.current.model.tavilyBaseURL,
                deepseekBaseURL: draftsRef.current.model.deepseekBaseURL,
                deepseekModel: draftsRef.current.model.deepseekModel,
                maxTokens:
                  draftsRef.current.model.maxTokens.trim() === '' ? null : Number(draftsRef.current.model.maxTokens),
                temperature:
                  draftsRef.current.model.temperature.trim() === ''
                    ? null
                    : Number(draftsRef.current.model.temperature),
              },
            },
            { area: 'model', force: ['model'], text: '生成参数已保存，从下一个任务开始生效。' }
          )
        }
        onModelReset={() => setDraft('model', modelDraft(status.modelConfig))}
        onPromptChange={(value) => setDraft('prompt', value)}
        onPromptSave={() =>
          saveSettings(
            { ...statusRef.current.settings, prompt: draftsRef.current.prompt },
            { area: 'model', force: ['prompt'], text: '当前账号的补充回复要求已保存。' }
          )
        }
        onPromptReset={() => setDraft('prompt', status.settings?.prompt || '')}
        onSearchCredential={(provider, apiKey) =>
          action(
            'search.credentials',
            { provider, apiKey },
            { area: 'model', text: '搜索密钥已保存，之后的查询使用新凭据。' }
          )
        }
        onSelect={(selection) =>
          action(
            'model.select',
            { selection },
            {
              area: 'model',
              text: selection
                ? '回复模型与推理强度设置已保存，从下一个任务开始生效。'
                : '已跟随 DSH 默认模型，从下一个任务开始生效。',
            }
          )
        }
        onBack={back}
        backLabel={backLabel}
        onNavigate={navigate}
      />
    );
  else if (page === 'persona')
    content = (
      <PersonaSettings
        draft={drafts.persona}
        personas={status.personas}
        blocked={blocked}
        busy={busyArea === 'persona' ? busy : ''}
        dirty={!same(drafts.persona, personaDraft(status.persona))}
        notice={notice}
        onChange={(value) => setDraft('persona', value)}
        onSave={() =>
          action(
            'persona.save',
            {
              id: status.personas?.activeId,
              persona: {
                personaMode: draftsRef.current.persona.personaMode || 'standard',
                prompt: draftsRef.current.persona.prompt,
                name: draftsRef.current.persona.name.trim(),
                aliases: splitLines(draftsRef.current.persona.aliases),
              },
            },
            { area: 'persona', force: ['persona'], text: '全局助手设定已保存，所有会话的后续回复共用。' }
          )
        }
        onReset={() => setDraft('persona', personaDraft(status.persona))}
        onBack={back}
        backLabel={backLabel}
        onRestoreDefault={restoreDefaultPersona}
        rpc={(endpoint, payload, signal) => call(connection, endpoint, payload, signal)}
        accountId={status.account?.id}
        onSelectPersona={(id) => action('persona.select', { id }, { area: 'persona', force: ['persona'], text: '已切换人设，之后的回复使用新的人设。' })}
        onCreatePersona={({ persona, name, source = 'distilled' }) =>
          action('persona.create', { persona, name, source: source === 'manual' ? 'manual' : 'distilled' },
            { area: 'persona', force: ['persona'], text: '新人设已保存并选用，之后的回复使用它。' })}
        onDeletePersona={(id) => action('persona.delete', { id }, { area: 'persona', force: ['persona'], text: '人设已删除。' })}
      />
    );
  else if (page === 'storage')
    content = (
      <StorageSettings
        status={status}
        draft={drafts.storage}
        blocked={blocked}
        busy={busyArea === 'storage' ? busy : ''}
        dirty={!same(drafts.storage, storageDraft(status.storage))}
        notice={notice}
        onChange={(value) => setDraft('storage', value)}
        onSave={() =>
          action(
            'storage.save',
            { storage: { basePath: draftsRef.current.storage.basePath.trim() } },
            {
              area: 'storage',
              force: ['storage'],
              text: '全局工作目录已应用，插件数据已整理到新位置；旧目录继续保留。',
            }
          )
        }
        onReset={() => setDraft('storage', storageDraft(status.storage))}
        onBack={back}
        backLabel={backLabel}
      />
    );
  else if (page === 'conversation')
    content = (
      <ConversationSettings
        key={(status.account?.id || '') + ':' + (detail?.peerId || '')}
        rpc={(endpoint, payload, signal) => call(connection, endpoint, payload, signal)}
        peer={detail}
        draft={drafts.conversation}
        status={status}
        blocked={blocked}
        busy={busyArea === 'conversation' ? busy : ''}
        notice={notice}
        dirty={!same(drafts.conversation, configDraft(detail?.config, status.persona))}
        onChange={(value) => setDraft('conversation', value)}
        onSave={() =>
          action(
            'conversation.configure',
            {
              accountId: status.account.id,
              chatType: peerType(detail),
              peerId: peerId(detail),
              config: configPayload({ ...draftsRef.current.conversation,
                natural: preserveTimeValues('natural', draftsRef.current.conversation.natural, detail?.config?.natural ?? {}) }),
              preserveTimeSettings: true,
            },
            { area: 'conversation', force: ['conversation'], text: '此会话的设置已保存，之后的回复使用新设置。' }
          )
        }
        onReset={() => setDraft('conversation', configDraft(detail?.config, status.persona))}
        onBack={() => setPage('authorization')}
        onNavigate={navigate}
        onRecords={openRecords}
        onRevoke={(peer) => grant(peer, false)}
        onResumeNatural={(blockedKey) =>
          action(
            'natural.resume',
            {
              accountId: status.account.id,
              chatType: peerType(detail),
              peerId: peerId(detail),
              blockedKey,
              confirmReviewed: true,
            },
            { area: 'conversation', text: '已恢复主动参与，将按当前间隔安排新机会；此前消息不会自动重发。' }
          )
        }
      />
    );
  else if (page === 'memory')
    content = (
      <MemoryWorkspace
        key={status.account?.id || 'offline'}
        tab={memoryTab}
        setTab={setMemoryTab}
        rpc={(endpoint, payload, signal) => call(connection, endpoint, payload, withTimeout(signal, memoryRpcTimeoutMs(endpoint)))}
        status={status}
        rows={recordRows}
        initialPeer={detail}
        onNavigate={navigate}
      />
    );
  else if (page === 'assets')
    content = (
      <MediaWorkspace
        key={status.account?.id || 'offline'}
        rpc={(endpoint, payload, signal) =>
          call(
            connection,
            endpoint,
            payload,
            signal || AbortSignal.timeout(endpoint === 'assets.describe' ? 300000 : 30000)
          )
        }
        status={status}
        onNavigate={navigate}
      />
    );
  else if (page === 'tasks')
    content = (
      <TasksPage
        key={status.account?.id || 'offline'}
        rpc={(endpoint, payload, signal) => call(connection, endpoint, payload, signal || AbortSignal.timeout(30000))}
        status={status}
        rows={rows}
        initialPeer={detail}
        onNavigate={navigate}
      />
    );
  else if (page === 'records')
    content = (
      <Records
        rows={recordRows}
        selected={recordSelected}
        onSelect={selectRecord}
        query={recordQuery}
        setQuery={setRecordQuery}
        type={recordType}
        setType={setRecordType}
        data={recordData}
        loading={recordLoading}
        error={recordError}
        offset={recordOffset}
        onOffset={changeRecordPage}
        onRefresh={refreshRecords}
        onInspect={holdRecordPosition}
        blocked={blocked}
        processing={status.processing}
        notice={notice}
        onCancelAll={() => action('cancel', {}, { area: 'records', text: '已取消全部会话的当前任务和等待任务。' })}
        onCancel={() =>
          recordSelected &&
          action(
            'cancel',
            { accountId: status.account.id, chatType: peerType(recordSelected), peerId: peerId(recordSelected) },
            { area: 'records', text: '已取消此会话的当前任务和等待任务，其他会话继续处理。' }
          )
        }
      />
    );
  else if (page === 'recovery')
    content = (
      <RecoveryPage
        key={status.account?.id || 'offline'}
        rpc={(endpoint, payload, signal) => call(connection, endpoint, payload, signal || AbortSignal.timeout(300000))}
        status={status}
      />
    );
  if (status && ['records', 'recovery'].includes(page)) {
    const active = page === 'recovery' ? 'recovery' : 'history';
    content = (
      <>
        <WorkspaceTabs
          name="records"
          label="处理记录分类"
          className="wa-records-tabs"
          tabs={[
            ['history', '处理记录', '查看消息、任务与发送结果'],
            ['recovery', '发送恢复', '核对回执与整理恢复项'],
          ]}
          active={active}
          onChange={(id) => navigate(id === 'recovery' ? 'recovery' : 'records')}
        />
        <div
          id="wa-records-panel-history"
          role="tabpanel"
          aria-labelledby="wa-records-tab-history"
          hidden={active !== 'history'}
        >
          {active === 'history' && content}
        </div>
        <div
          id="wa-records-panel-recovery"
          role="tabpanel"
          aria-labelledby="wa-records-tab-recovery"
          hidden={active !== 'recovery'}
        >
          {active === 'recovery' && content}
        </div>
      </>
    );
  }

  return content;
}
