import { date } from "../../shared/peers.mjs";
import { ScheduleCountdown } from '../../components/schedule-countdown.jsx';

export const taskStates = {
  pending: '等待执行',
  running: '正在执行',
  paused: '已暂停',
  completed: '已完成',
  cancelled: '已取消',
  expired: '已过期',
  sent: '微信已确认',
  failed: '失败',
  unknown: '结果不明',
  partial: '部分已确认',
  queued: '等待处理',
  settling: '等待最终结果',
};

export function localDateInput(ms) {
  const time = new Date(ms);
  return new Date(ms - time.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
}

/** A send that slipped past its minute is worth showing: the reader should know
 * a 0:00 greeting left at 8:00 rather than assume it was on time. */
export function lateLabel(ms) {
  if (!(ms >= 60000)) return '';
  return ms >= 3600000 ? Math.round(ms / 3600000) + ' 小时' : Math.round(ms / 60000) + ' 分钟';
}

export function scheduleLabel(schedule) {
  return schedule.kind === 'once'
    ? '一次性'
    : schedule.kind === 'daily'
      ? '每天 ' + schedule.time + '（北京时间）'
      : '每 ' + schedule.minutes + ' 分钟';
}

export function TaskBadge({ state }) {
  return <span className={'wa-task-badge is-' + state}><span className="wa-state-mark" aria-hidden="true" />{taskStates[state] || state}</span>;
}

export function TaskDetails({ task, runs = [], paused, status }) {
  return (
    <div className="wa-task-detail-content">
      <p className="wa-task-content">{task.content}</p>
      <div className="wa-task-facts">
        <span>
          {task.kind === 'agent' ? 'Agent 任务' : '发送消息'} · {scheduleLabel(task.schedule)}
        </span>
        <span>{task.source === 'chat' ? task.senderName + ' 在聊天中创建' : '管理员创建'}</span>
        {task.targets?.length > 0 && (
          <span>提醒对象：{task.targets.map((target) => '@' + target.name).join('、')}</span>
        )}
        <span>创建时间：{date(task.createdAt)}</span>
        <span className="wa-schedule-time">
          <span>{task.state === 'pending' ? '下次计划' : '计划时间'}：{date(task.nextRunAt)}</span>
          {['pending', 'running', 'paused'].includes(task.state) && <ScheduleCountdown
            at={Math.max(task.nextRunAt, task.retryAt || 0)} running={task.state === 'running'} paused={paused || task.state === 'paused'}
            status={status} action={task.retryAt > task.nextRunAt ? '重试' : '执行'} />}
        </span>
        {task.state === 'cancelled' && <span>状态更新：{date(task.updatedAt)}</span>}
      </div>
      {task.lastError && <p className="wa-task-warning">{task.lastError}</p>}
      {runs.length > 0 && (
        <div className="wa-task-executions">
          <h3>最近执行记录</h3>
          {runs.map((run) => (
            <div className="wa-task-execution" key={run.id}>
              <div className="wa-row">
                <TaskBadge state={run.state} />
                <span>{run.finishedAt ? '结束时间：' + date(run.finishedAt) : '开始时间：' + date(run.startedAt)}</span>
              </div>
              <p className="wa-help">
                本次计划：{date(run.scheduledAt)}
                {lateLabel(run.lateMs) ? ` · 迟到 ${lateLabel(run.lateMs)}` : ''}
                {run.acknowledgedMessageIds?.length ? ` · 微信确认 ${run.acknowledgedMessageIds.length} 条` : ''}
              </p>
              {run.reason && <p className="wa-task-warning">{run.reason}</p>}
              {run.acknowledgedMessageIds?.length > 0 && (
                <p className="wa-help wa-task-receipts">回执：{run.acknowledgedMessageIds.join('、')}</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
