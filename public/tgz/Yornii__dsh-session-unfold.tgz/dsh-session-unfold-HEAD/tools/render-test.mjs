/**
 * Offline render harness: loads the plugin's client module with a fake
 * __ModuleLoader__, renders the board against synthetic session events, and
 * prints the resulting static HTML. No Host, no browser.
 * Run: node tools/render-test.mjs
 * Needs React and ReactDOM >= 18 resolvable from the DSH source checkout
 * (set DSH_ROOT to that checkout; defaults to ~/deepseek-harness).
 */
import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import os from 'node:os'
import path from 'node:path'

// React is only a test dependency; resolve it from a DSH checkout (a pnpm store)
// or from a plain `npm i react react-dom` in this repository.
const root = process.env.DSH_ROOT ?? path.join(os.homedir(), 'deepseek-harness')
const require = createRequire(
  process.env.REACT_ROOT
    ? path.join(process.env.REACT_ROOT, 'package.json')
    : path.join(root, 'node_modules', '.pnpm', 'react@18.3.1', 'node_modules', 'react', 'package.json'),
)
const React = require('react')
const { renderToStaticMarkup } = require('react-dom/server')

// SSR uses getServerSnapshot; the board reads its open flag from getSnapshot,
// so make the hook resolve that snapshot here (client behaviour).
React.useSyncExternalStore = (_subscribe, getSnapshot) => getSnapshot()

const here = path.dirname(fileURLToPath(import.meta.url))
const clientPath = path.join(here, '..', 'client.js')
const source = readFileSync(clientPath, 'utf8')

let mod
globalThis.window = {
  __ModuleLoader__: { load: ({ factory }) => { mod = factory((name) => require(name)) } },
  localStorage: {
    store: new Map(),
    getItem(key) { return this.store.has(key) ? this.store.get(key) : null },
    setItem(key, value) { this.store.set(key, value) },
  },
  addEventListener() {}, removeEventListener() {}, setInterval() { return 0 }, clearInterval() {},
}
globalThis.document = { createElement: () => ({ innerHTML: '' }) }

new Function('module', 'exports', source.replace('let isOpen = false', 'let isOpen = true'))({}, {})

// ---- synthetic host: sessions with an event window per session ----
const now = Date.now()
// One clarification exchange: the assistant asks two questions, answers one and
// skips the other. A second, still-pending question proves the question bubble
// does not depend on a tool result.
const clarifyEntries = () => [
  { type: 'event', event: { type: 'tool/call', time: now - 4500, data: { name: 'ask_user_question', callId: 'call_q1', arguments: JSON.stringify({ questions: [
    { id: 'when', header: '发布窗口', question: '什么时候发？', options: [{ label: '今晚', description: '低峰期' }, { label: '明早' }] },
    { id: 'scope', header: '范围', question: '要带哪些改动？' },
  ] }) } } },
  { type: 'event', event: { type: 'tool/result', time: now - 4400, data: { toolCallId: 'call_q1', message: { role: 'tool', toolCallId: 'call_q1', isError: false, content: [{ type: 'text', text: JSON.stringify({ answers: [{ id: 'when', selected: ['今晚'] }, { id: 'scope', selected: [] }] }) }] } } } },
  { type: 'event', event: { type: 'assistant/message', time: now - 4300, data: { message: { content: [{ type: 'text', text: '好，今晚发。' }] } } } },
]
const pendingEntries = () => [
  { type: 'event', event: { type: 'tool/call', time: now - 1000, data: { name: 'ask_user_question', callId: 'call_q2', arguments: JSON.stringify({ questions: [{ id: 'check', header: '确认', question: '要跑权限检查吗？', options: [{ label: '跑' }, { label: '不跑' }] }] }) } } },
]
const mkEntries = (title, running) => {
  const entries = [
    { type: 'event', event: { type: 'user/message', time: now - 9000, data: { source: { kind: 'user' }, content: [{ type: 'text', text: `帮我看下 ${title}` }] } } },
    { type: 'event', event: { type: 'turn/start', time: now - 8000, data: {} } },
    { type: 'event', event: { type: 'tool/call', time: now - 7000, data: { name: 'bash' } } },
    { type: 'event', event: { type: 'tool/call', time: now - 6000, data: { name: 'bash' } } },
    { type: 'event', event: { type: 'assistant/message', time: now - 5000, data: { message: { content: [{ type: 'text', text: `## 结论\n\n**${title}** 已处理完，无异常\n\n- \`ok\`` }] } } } },
  ]
  if (title === 'Draft release notes') entries.push(...clarifyEntries())
  if (running) entries.push(...pendingEntries())
  if (!running) entries.push({ type: 'event', event: { type: 'turn/end', time: now - 4000, data: { reason: { kind: 'completed' } } } })
  return entries
}
const sessions = [
  { id: 'a', title: 'Refactor auth middleware', running: true, at: now - 60e3 },
  { id: 'b', title: 'Investigate p99 latency', running: false, at: now - 900e3 },
  { id: 'c', title: 'Draft release notes', running: false, at: now - 3600e3 },
  { id: 'd', title: 'Security ticket triage', running: false, at: now - 7200e3 },
  { id: 'e', title: 'Empty scratch session', running: false, at: now - 86400e3 },
]
const windows = new Map(sessions.map(s => [s.id, mkEntries(s.title, s.running)]))

const byId = Object.fromEntries(sessions.map(s => [s.id, {
  id: s.id, displayTitle: s.title, running: s.running, updatedAt: s.at, blank: false, retainedBy: {},
}]))
byId.s = {
  id: 's', displayTitle: 'Subagent worker', running: false, updatedAt: now - 30e3,
  blank: false, origin: 'subagent', parentId: 'a', retainedBy: {},
}
const workspaces = [
  { workspaceId: 'w1', title: 'web-app', sessionIds: ['a', 'b', 'c'] },
  { workspaceId: 'w2', title: 'docs', sessionIds: ['d', 'e'] },
]

function makeHook(getSnapshot) {
  return (selector) => selector(getSnapshot())
}

const value = mod

// Grab the registered components by intercepting ctx.slots.register.
let Board, Launcher
const ctx = {
  // The balance hook optionally injects `remote.account`; this fake has none,
  // which is the signed-out/unavailable path.
  inject: (_deps, callback) => {
    callback({ remote: { account: undefined }, effect: (fn) => fn() })
    return () => {}
  },
  locale: { register: () => () => {}, bind: () => (key, params) => {
    const dict = { subtitle: `${params ? params.total : ''} 个任务`, title: '任务大屏' }
    return dict[key] ?? key
  } },
  sessions: {
    retain: (sessionId) => {
      const listeners = new Set()
      const windowValue = { entries: windows.get(sessionId) }
      return {
        sessionId,
        binding: {
          eventSource: { getSnapshot: () => windowValue, subscribe: (fn) => { listeners.add(fn); return () => listeners.delete(fn) } },
          session: { prompt: async () => ({ ok: true, value: { accepted: true } }) },
        },
        release: () => {},
      }
    },
  },
  uiWorkspace: { openSession: () => {} },
  effect: (fn) => { const d = fn(); return () => { if (typeof d === 'function') d() } },
  slots: {
    inject: (_key, fn) => fn(),
    register: (_options, component) => {
      if (_options.name === 'shell.overlay') Board = component
      else Launcher = component
      return () => {}
    },
  },
}

value.apply(ctx)

const t = (key, params) => {
  const dict = {
    title: 'Task board',
    subtitle: '{total} tasks · {running} in progress',
    close: 'Close', search: 'Search tasks', filterHint: 'Filter by status',
    more: 'Show {n} more', resetSizes: 'Reset sizes', resizeHint: 'Resize',
    loadOlder: 'Load earlier', loadingOlder: 'Loading earlier…',
    batchMode: 'Batch', done: 'Done', selectedCount: '{n} selected', selectAll: 'Select shown',
    clearSelection: 'Clear', deleteWindows: 'Delete windows',
    deleteWindowsTitle: 'Permanently delete {n} windows?', deleteWindowsDesc: 'Delete windows description',
    continue: 'Continue', cancel: 'Cancel', back: 'Back', deleteSessionsTitle: 'Permanently delete {n} sessions?',
    deleteSessionsDesc: 'Delete sessions description', deleteSessionsWarning: 'Delete warning',
    confirmDeleteForever: 'Delete permanently', deleting: 'Deleting…',
    deletedWindows: 'Deleted {n}', deleteFailed: 'Delete failed {n}',
    newWindow: 'New window', newWindowHint: 'Create a session window without leaving the task board',
  creatingWindow: 'Creating…', newWindowNoWorkspace: 'No workspace', newWindowFailed: 'Failed: {message}',
  openSession: 'Open session', editTitle: 'Edit title', renameFailed: 'Rename failed',
    selectWindow: 'Select window', messageFilter: 'Message display', allMessages: 'All', userOnly: 'User only',
    clarifySkipped: 'Skipped', clarifyAnswerLine: '{label}: {answer}',
    dropFiles: 'Drop to upload', uploadingFiles: 'Uploading {n} attachment(s)…',
    attachmentsUploading: 'Attachments are still uploading', filesAttached: 'Added {n} attachment(s)',
    uploadFailed: 'Upload failed: {message}', uploadFailedCount: '{n} attachment(s) failed to upload',
    uploadBlocked: 'This conversation cannot accept attachments', uploadUnavailable: 'Attachments are not available',
    attachments: '{n} attachment(s)',
    questionWaiting: 'Assistant question', questionSubmit: 'Submit', questionSkip: 'Skip',
    questionCustom: 'Custom answer (optional)', questionAnswerAll: 'Choose or type an answer for every question',
    balanceHint: 'Account balance', balanceBonus: 'Bonus {amount}',
    tool: 'tool', approvalWaiting: 'Waiting: {tool}',
    allowOnce: 'Allow once', reject: 'Reject', approvalFailed: 'Approval failed',
    noSessions: 'No tasks', noMatch: 'No matches', loadingCard: 'Loading…', loadFailed: 'Load failed',
    noMessages: 'No messages yet', noUserMessages: 'No user messages yet', reply: 'Reply here', send: 'Send', statusHint: 'Status',
    'status.all': 'all', 'status.todo': 'to decide', 'status.doing': 'in progress', 'status.done': 'done',
    justNow: 'just now', minutesAgo: '{n}m ago', hoursAgo: '{n}h ago', daysAgo: '{n}d ago',
  }
  let out = dict[key] ?? key
  if (params) for (const [k, v] of Object.entries(params)) out = out.replace(`{${k}}`, String(v))
  return out
}

const pendingQuestion = {
  kind: 'question',
  key: 'question:s|c',
  sessionId: 'c',
  questions: [{
    id: 'window',
    header: 'Release window',
    question: 'When should it ship?',
    options: [{ label: 'Option A', description: 'tonight' }, { label: 'Option B' }],
  }],
  answer: async () => {},
}
const sessionStatus = new Map([
  ['a', { running: true, pendingInteraction: undefined, completionUnread: false }],
  ['b', { running: false, pendingInteraction: undefined, completionUnread: true }],
  ['d', { running: false, pendingInteraction: undefined, completionUnread: true }],
  ['c', { running: false, pendingInteraction: pendingQuestion, completionUnread: false }],
])
const props = {
  t,
  sessions: ctx.sessions,
  openSession: () => {},
  deleteSession: async () => {},
  useSessions: makeHook(() => ({ ids: sessions.map(s => s.id), byId, phase: 'ready', projectionsBySession: {} })),
  useSessionStatus: (selector) => selector(sessionStatus),
  useRemoteAccess: (action) => action === 'session/create',
  createSession: async () => 'new-session',
  useWorkspaces: makeHook(() => ({ items: workspaces, archivedSessionIds: [], pinnedSessionIds: ['b'], state: 'idle', phase: 'ready', error: null })),
}

// Open the board before rendering.
const launcherHtml = renderToStaticMarkup(React.createElement(Launcher, { ...props, wide: true }))
console.log('LAUNCHER_OK:', launcherHtml.includes('dshtb-launch'))

// The shared flag starts closed; flip it through the module's own launcher path
// is not reachable from outside, so call the store via a synthetic click hook.
// Instead: render the board after the flag is set by a click handler on the launcher.
const boardHtml = renderToStaticMarkup(React.createElement(Board, props))
console.log('BOARD_HTML_BYTES:', boardHtml.length)
const noAccessHtml = renderToStaticMarkup(React.createElement(Board, {
  ...props,
  useRemoteAccess: () => false,
}))
for (const probe of ['Refactor auth middleware', 'web-app', 'docs', 'in progress', 'to decide', 'Reply here', 'dshtb-card', 'dshtb-cardWrap', 'dshtb-resize', 'dshtb-open', 'dshtb-filter', 'dshtb-bubbleAssistant', 'dshtb-md', 'dshtb-subagents', 'dshtb-pin']) {
  console.log(`HAS ${probe}:`, boardHtml.includes(probe))
}
const cards = (boardHtml.match(/class="dshtb-card"/g) || []).length
console.log('CARDS:', cards)
const order = [...boardHtml.matchAll(/class="dshtb-cardTitle"[^>]*>([^<]+)</g)].map(m => m[1])
console.log('ORDER:', order.join(' | '))
console.log('HAS_RESIZE_HANDLE:', boardHtml.includes('dshtb-resize'))
console.log('HAS_DEFAULT_CARD_SIZE:', boardHtml.includes('width:380px;height:250px'))
console.log('HAS_SEND_BUTTON:', boardHtml.includes('dshtb-sendBtn'))
console.log('HAS_TEXTAREA:', boardHtml.includes('<textarea'))
console.log('HAS_GREEN_BUBBLE_CSS:', boardHtml.includes('dshtb-bubbleDoing'))
console.log('HAS_STATUS_LABEL:', (boardHtml.match(/dshtb-stateLabel/g) || []).length)
console.log('HAS_AUTO_DONE:', boardHtml.includes('data-status="done"'))

// ---- clarification folding (questions live in tool/call, answers in tool/result) ----
// The board body fills from `useEffect`, which static rendering skips, so the
// timeline is asserted against the module's own folding seam instead.
const { summarize, answerText, MarkdownText, filesFromList, attachFilesToSession, buildQuestionAnswers, formatMoney, formatBalanceSummary } = value.__test
const folded = summarize(windows.get('c'))
const questionItem = folded.items.find(item => item.clarify === true && item.kind === 'assistant')
const answerItem = folded.items.find(item => item.clarify === true && item.kind === 'user')
const questionHtml = questionItem === undefined
  ? ''
  : renderToStaticMarkup(React.createElement(MarkdownText, { text: questionItem.text }))
const answer = answerItem === undefined ? '' : answerText(answerItem, t)
const pendingFolded = summarize(windows.get('a'))

// ---- dropped files become the target Session's draft attachments ----
const attachCalls = []
const releasedDrafts = []
const fakeConversation = {
  createDrafts: (_sessionId, files) => files.map((file, index) => ({ id: `draft-${index}`, kind: 'file', file })),
  releaseDraftAttachments: (drafts) => { for (const draft of drafts) releasedDrafts.push(draft.id) },
  input: { for: () => ({ actions: { addAttachments: (ids) => { attachCalls.push(...ids); return true } } }) },
  fileUploads: { subscribe: () => () => {}, getSnapshot: () => ({}) },
}
const fakeSessions = { scope: () => ({ get: () => fakeConversation }) }
const attachOk = attachFilesToSession(fakeSessions, 'a', [
  { name: 'notes.md', size: 12 },
  { name: 'shot.png', size: 34 },
], undefined)
const attachJunk = filesFromList([null, { name: 'missing-size' }, { name: 'ok.txt', size: 1 }])
const attachBlocked = attachFilesToSession(
  { scope: () => ({ get: () => ({ ...fakeConversation, input: { for: () => ({ actions: { addAttachments: () => false } }) } }) }) },
  'a',
  [{ name: 'x.txt', size: 1 }],
  undefined,
)
const attachFailed = attachFilesToSession(
  { scope: () => ({ get: () => ({ createDrafts: () => { throw new Error('nope') } }) }) },
  'a',
  [{ name: 'x.txt', size: 1 }],
  undefined,
)
const attachUnavailable = attachFilesToSession({ scope: () => ({ get: () => undefined }) }, 'a', [{ name: 'x.txt', size: 1 }], undefined)
console.log('ATTACH_OK:', JSON.stringify(attachOk.ok), attachCalls.join(','), 'RELEASED:', releasedDrafts.join(','))

// ---- pending ask_user_question answers ----
const askQuestions = [
  { id: 'q1', question: 'Pick one', options: [{ label: 'A' }, { label: 'B' }] },
  { id: 'q2', question: 'Pick many', multiSelect: true, options: [{ label: 'X' }, { label: 'Y' }] },
]
const answerSingle = buildQuestionAnswers(askQuestions, { q1: ['A'], q2: ['X', 'Y'] }, {}, false)
const answerCustom = buildQuestionAnswers([{ id: 'q1', question: 'Free', options: [{ label: 'A' }] }], { q1: ['A'] }, { q1: 'typed' }, false)
const answerMultiCustom = buildQuestionAnswers([askQuestions[1]], { q2: ['X'] }, { q2: 'extra' }, false)
const answerMissing = buildQuestionAnswers(askQuestions, { q1: ['A'] }, {}, false)
const answerSkipped = buildQuestionAnswers(askQuestions, {}, {}, true)
console.log('ANSWERS:', JSON.stringify({ answerSingle, answerCustom, answerMissing }))

// ---- account balance formatting ----
const moneyZero = formatMoney('0', 'USD')
const moneySubCent = formatMoney('0.001', 'CNY')
const moneyFloor = formatMoney('12.345', 'CNY')
const moneySummary = formatBalanceSummary({ wallets: [{ currency: 'CNY', balance: '5' }], bonusWallets: [] })
const moneyBonus = formatBalanceSummary({ wallets: [], bonusWallets: [{ currency: 'USD', balance: '1' }] })
const moneyNone = formatBalanceSummary(null)
console.log('MONEY:', JSON.stringify({ moneyZero, moneySubCent, moneyFloor, moneySummary }))
console.log('CLARIFY_QUESTION_HTML:', questionHtml)
console.log('CLARIFY_ANSWER:', JSON.stringify(answer))

// Simulate opening: the launcher's onClick calls setOpen(true); invoke it through
// React's props by rendering with a synthetic event is not needed — instead use
// the module's exported behaviour: dispatch a click on a mounted tree is DOM-only.
// Fallback: re-load module and patch isOpen through a second render pass.
// Exit non-zero when any expectation fails, so CI (and npm run check) can gate on it.
const failures = []
if (!launcherHtml.includes('dshtb-launch')) failures.push('launcher button missing')
if (!boardHtml.includes('dshtb-card')) failures.push('board did not render')
if (cards !== 5) failures.push(`expected 5 cards, got ${cards}`)
if (!source.includes("assistant/message")) failures.push('assistant messages are not projected')
if (questionItem === undefined
  || !questionItem.text.includes('什么时候发？')
  || !questionItem.text.includes('- 今晚 — 低峰期')) failures.push('clarifying question is not folded as an assistant message')
if (!questionHtml.includes('<strong>发布窗口</strong>') || !questionHtml.includes('<li>今晚')) failures.push('clarifying question does not render as Markdown')
if (answer !== '发布窗口: 今晚\n范围: Skipped') failures.push(`clarification answer is wrong: ${JSON.stringify(answer)}`)
const questionIndex = folded.items.indexOf(questionItem)
const answerIndex = folded.items.indexOf(answerItem)
if (questionItem === undefined || answerItem === undefined || questionIndex > answerIndex) failures.push('clarification answer does not follow its question')
if (!pendingFolded.items.some(item => item.clarify === true && item.kind === 'assistant' && item.text.includes('要跑权限检查吗？'))) failures.push('pending clarifying question is not folded')
if (pendingFolded.items.some(item => item.clarify === true && item.kind === 'user')) failures.push('unanswered question produced an answer bubble')
if (!source.includes('__test')) failures.push('folding seam missing')
if (!source.includes("const QUESTION_TOOL = 'ask_user_question'")) failures.push('clarifying question tool is not recognized')
if (attachOk.ok !== true || attachOk.drafts.length !== 2) failures.push('dropped files are not attached as drafts')
if (attachCalls.join(',') !== 'draft-0,draft-1') failures.push(`attachment ids are not published to the input shell: ${attachCalls.join(',')}`)
if (attachJunk.length !== 1 || attachJunk[0].name !== 'ok.txt') failures.push('non-file drop items are not filtered')
if (attachBlocked.ok !== false || attachBlocked.reason !== 'blocked' || !releasedDrafts.includes('draft-0')) failures.push('blocked attachment drop does not release drafts')
if (attachFailed.ok !== false || attachFailed.reason !== 'failed' || attachFailed.message !== 'nope') failures.push('failing draft creation is not reported')
if (attachUnavailable.ok !== false || attachUnavailable.reason !== 'unavailable') failures.push('session without the conversation service is not reported')
if (!source.includes('createDrafts') || !source.includes('addAttachments')) failures.push('dropped files are not routed through the conversation service')
if (!source.includes('dshtb-dropCue') || !source.includes('dshtb-attachChip')) failures.push('drop handling UI missing')
if (!source.includes('createPortal') || !source.includes('z-index:1001')) failures.push('board is not lifted above the host drag mask')
if (!source.includes('function QuestionPanel') || !source.includes('pending.answer')) failures.push('question answer panel missing')
if (!source.includes('dshtb-questionSubmit')) failures.push('question submit control missing')
if (!boardHtml.includes('Assistant question') || !boardHtml.includes('Option A') || !boardHtml.includes('dshtb-questionSubmit')) failures.push('pending question panel is not rendered on the card')
if (JSON.stringify(answerSingle) !== '[{"id":"q1","selected":["A"]},{"id":"q2","selected":["X","Y"]}]') failures.push(`single/multi answer batch is wrong: ${JSON.stringify(answerSingle)}`)
if (JSON.stringify(answerCustom) !== '[{"id":"q1","selected":[],"custom":"typed"}]') failures.push(`custom answer does not override the choice: ${JSON.stringify(answerCustom)}`)
if (JSON.stringify(answerMultiCustom) !== '[{"id":"q2","selected":["X"],"custom":"extra"}]') failures.push(`multi-select custom answer is wrong: ${JSON.stringify(answerMultiCustom)}`)
if (answerMissing !== null) failures.push('unanswered question does not block submit')
if (JSON.stringify(answerSkipped) !== '[{"id":"q1","selected":[]},{"id":"q2","selected":[]}]') failures.push('skip-all batch is wrong')
if (moneyZero !== '$0.00') failures.push(`zero balance is wrong: ${moneyZero}`)
if (moneySubCent !== '<¥0.01') failures.push(`sub-cent balance is wrong: ${moneySubCent}`)
if (moneyFloor !== '¥12.34') failures.push(`balance is not floored to cents: ${moneyFloor}`)
if (moneySummary !== '¥5.00') failures.push(`balance summary is wrong: ${moneySummary}`)
if (moneyBonus !== '$1.00') failures.push(`bonus-only summary is wrong: ${moneyBonus}`)
if (moneyNone !== '') failures.push('missing balance should render nothing')
if (!source.includes('readBalance') || !source.includes('dshtb-balance')) failures.push('top-bar balance display missing')
if (!source.includes('dragSessionId') || !source.includes('onDropCapture')) failures.push('board-level drag tracking missing')
if (!source.includes("type: 'file', receiptId")) failures.push('inline reply does not send uploaded attachments')
if (order[0] !== 'Investigate p99 latency') failures.push(`pinned task should sort first, got ${order[0]}`)
if (order[1] !== 'Refactor auth middleware' || order[2] !== 'Security ticket triage' || order[3] !== 'Draft release notes') {
  failures.push(`expected in progress → done → to decide, got ${order.join(' | ')}`)
}
if (!source.includes('const STATUS_RANK = { doing: 0, done: 1, todo: 2 }')) failures.push('status ranking does not put done before to decide')
if (!source.includes('.dshtb-state[data-status=done] .dshtb-stateDot{background:var(--dsw-alias-state-error-primary)')) failures.push('done status dot is not red')
if (!boardHtml.includes('dshtb-cardWrap')) failures.push('resizable card wrapper missing')
if (!boardHtml.includes('dshtb-resize')) failures.push('card resize handle missing')
if (!boardHtml.includes('dshtb-open')) failures.push('open-session button missing')
if (!boardHtml.includes('class="dshtb-new"')) failures.push('new-session button missing')
if (!boardHtml.includes('without leaving the task board')) failures.push('new-window hint missing')
if (noAccessHtml.includes('class="dshtb-new"')) failures.push('new-window button ignores the session/create access gate')
if (!source.includes('ctx.sessions.create({ workspaceId })')) failures.push('new window does not create a Session')
if (source.includes('uiWorkspace.startSession()')) failures.push('new window still navigates away from the board')
if (!source.includes('/delete-session ${sessionId}')) failures.push('batch delete does not use the session-delete command')
if (source.includes('archiveSession')) failures.push('batch delete still archives instead of deleting')
if (source.includes('hideSessions') || source.includes('dsh.task-board.hidden')) failures.push('local-only window hiding still present')
if (!source.includes('deletedWindows')) failures.push('permanent delete result notice missing')
if (!boardHtml.includes('width:380px;height:250px')) failures.push('default card size missing')
if (!boardHtml.includes('dshtb-subagents')) failures.push('subagent toggle missing')
if (!boardHtml.includes('dshtb-pin')) failures.push('window pin control missing')
if (!source.includes('dshtb-readonly') || !source.includes('subagentReadOnly')) failures.push('subagent read-only view missing')
if (boardHtml.includes('Subagent worker')) failures.push('subagent window should be hidden by default')
if (!source.includes('pinSession')) failures.push('window pin does not use the Session pin service')
if (!boardHtml.includes('dshtb-sendBtn')) failures.push('inline reply missing')
if (!boardHtml.includes('dshtb-sendIcon')) failures.push('send icon missing')
if (boardHtml.includes('↵')) failures.push('old return-arrow send glyph still present')
if (!boardHtml.includes('border-radius:999px')) failures.push('maximum input rounding missing')
if (!boardHtml.includes('scrollbar-width:none')) failures.push('input scrollbar line still visible')
if (!boardHtml.includes('border-radius:50%;background:var(--dsw-alias-brand-primary)')) failures.push('circular blue send button missing')
if (!boardHtml.includes('dshtb-filterBar') || !boardHtml.includes('dshtb-bubbleAssistant') || !boardHtml.includes('dshtb-md')) failures.push('assistant timeline or user-only toggle missing')
if (boardHtml.includes('dshtb-toolName')) failures.push('tool call rows still visible')
if (!boardHtml.includes('dshtb-mdH2') || !boardHtml.includes('.dshtb-md code')) failures.push('assistant Markdown styles missing')
if (!boardHtml.includes('<textarea')) failures.push('wrapping draft textarea missing')
if (!boardHtml.includes('dshtb-bubbleDoing')) failures.push('in-progress bubble style missing')
if (boardHtml.includes('dshtb-stateSelect') || source.includes('dsh.task-board.status.v1')) failures.push('manual status control still present')
if (!boardHtml.includes('dshtb-stateLabel')) failures.push('read-only status label missing')
if (!boardHtml.includes('data-status="done"')) failures.push('automatic done status missing')
if (!boardHtml.includes('box-shadow:0 2px 6px rgba(0,0,0,.10)')) failures.push('card outer shadow missing')
if (!boardHtml.includes('web-app')) failures.push('workspace chip missing')
if (!boardHtml.includes('--dsh-frame-chrome-top')) failures.push('window chrome safe area missing')
if (failures.length > 0) {
  console.error('FAIL:', failures.join('; '))
  process.exit(1)
}
console.log('ALL ASSERTIONS PASSED')
