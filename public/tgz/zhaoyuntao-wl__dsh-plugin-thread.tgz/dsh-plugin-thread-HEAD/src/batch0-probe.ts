// MAX v3 批 0 底座能力验证探针（spike 产物，env 门控：THREAD_B0_PROBE=1 时随 dsh-thread 加载）。
// 六项 smoke 结论写 JSONL fixture（THREAD_B0_FIXTURE），供批 1-4 决策 + live 事件形状快照固件。
import type { Context } from '@deepseek-ai/cordis'
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { ThreadStore, defaultPaths, deriveProjectKey } from '@thread-memory/core'
import { appendFileSync, mkdirSync } from 'node:fs'
import { dirname } from 'node:path'
import { B0_DRILL_SOURCE_KIND, B0_SOURCE_KIND } from './source-kind.js'

export const B0_MARKER_PREFIX = 'THREAD-B0-MARKER-'
// 探针注入源 kind 在 source-kind.ts 声明（0.2.0 起 MessageSourceMap 按生产者合并扩展，无 catch-all
// 'plugin' kind）：主采集按 kind 跳过本插件自身注入，探针标记不污染 Thread 事件流。

// 运行时形状声明（dsh-skill/dsh-compaction/dsh-token-meter 类型不在本仓依赖树，按官方契约声明最小面）
interface SkillRegistryLike {
  register(skill: { name: string; description?: string; source: string; content: string; invocation?: unknown }): () => void
  list(options?: { cwd?: string }): Promise<Array<{ name: string; description?: string }>>
}
interface CompactionEngineLike {
  compactNow(agent: unknown, signal: AbortSignal, sourceCommandId?: string): Promise<{ compactionId?: string } | null>
  compactRegion(start: number, end: number, agent: unknown, signal?: AbortSignal): Promise<{ compactionId?: string } | null>
}
interface TokenMeterLike {
  measure(session: Session, requestHeader?: unknown): { pressureTokens?: number; [key: string]: unknown }
}
interface ToolRuntimeLike {
  register(definition: unknown): () => void
  schemas(): Array<{ name: string }>
}
interface AgentsRegistryLike {
  get(id: string | number): Agent | undefined
}

export interface Batch0ProbeEnv {
  fixturePath: string
  compact: boolean
  followup: boolean
  deltaDrill: boolean
  // ⑧ 自动压缩路径 live 实证（2026-08-25 修复后验证）：pre-step 同步 await compactRegion
  //（自动压缩 compactIfNeeded 同款 API + 同款时序——压缩完成模型才继续下一步）
  autocRegion: boolean
}

export function runBatch0Probes(ctx: Context, env: Batch0ProbeEnv): void {
  mkdirSync(dirname(env.fixturePath), { recursive: true })
  const log = (probe: string, data: Record<string, unknown> = {}): void => {
    try {
      appendFileSync(env.fixturePath, JSON.stringify({ t: new Date().toISOString(), probe, ...data }) + '\n')
    } catch {
      // fixture 写入失败不阻塞插件主路径
    }
  }
  const extractText = (content: readonly { type: string; text?: string }[] | undefined): string =>
    (content ?? []).map((b) => (b.type === 'text' ? b.text ?? '' : '')).join('\n').trim()
  // strict=true 强制激活惰性服务（headless 下 compaction/tokenMeter 无消费者拉取时不在注册表）
  const get = (name: string): unknown => {
    try {
      return ctx.get?.(name, true)
    } catch (err) {
      log('00-service-activate-error', { name, error: String(err) })
      return undefined
    }
  }
  const tools = get('tools') as ToolRuntimeLike | undefined
  const skills = get('skills') as SkillRegistryLike | undefined
  const compaction = get('compaction') as CompactionEngineLike | undefined
  const tokenMeter = get('tokenMeter') as TokenMeterLike | undefined
  const agents = get('agents') as AgentsRegistryLike | undefined
  log('00-services', {
    tools: tools !== undefined,
    skills: skills !== undefined,
    compaction: compaction !== undefined,
    tokenMeter: tokenMeter !== undefined,
    agents: agents !== undefined,
  })

  // ① ctx.tools.register → schemas() 含探针工具（模型工具面）
  try {
    if (!tools) {
      log('01-tool', { ok: false, reason: 'no tools service' })
    } else {
      const dispose = tools.register(defineTool({
        name: 'thread_b0_probe',
        description: '批 0 探针工具：回显 message 参数。仅用于验证 Thread 插件注册的工具出现在模型工具面并可被调用。',
        parameters: {
          message: { type: 'string', required: true, description: '要回显的文本' },
        },
        output: {
          schema: { type: 'object', properties: { echoed: { type: 'string' } }, additionalProperties: true },
          render: (_args, value) => [{ type: 'text', text: `thread_b0_probe 回显: ${String(value.echoed)}` }],
        },
        execute: async (args) => {
          log('01-tool-executed', { message: String(args.message) })
          return { echoed: String(args.message) }
        },
      }))
      ctx.effect(() => () => dispose())
      const names = tools.schemas().map((s) => s.name)
      log('01-tool', { ok: names.includes('thread_b0_probe'), inSchemas: names.includes('thread_b0_probe'), schemaCount: names.length })
    }
  } catch (err) {
    log('01-tool', { ok: false, error: String(err) })
  }

  // ② ctx.skills.register → list() 目录含 thread-b0（模型可发现面）
  void (async () => {
    try {
      if (!skills) {
        log('02-skill', { ok: false, reason: 'no skills service' })
        return
      }
      const dispose = skills.register({
        name: 'thread-b0',
        description: '批 0 探针技能：验证动态 SKILL 注册进目录且可被 skill 工具加载。',
        source: 'runtime',
        content: 'thread-b0 探针技能正文。调用方加载本技能即证明动态注册生效。',
      })
      ctx.effect(() => () => dispose())
      const catalog = await skills.list()
      log('02-skill', { ok: catalog.some((s) => s.name === 'thread-b0'), catalogNames: catalog.map((s) => s.name) })
    } catch (err) {
      log('02-skill', { ok: false, error: String(err) })
    }
  })()

  // ⑤ compaction/* 事件形状 + 事件类型目录（快照固件）+ ④ tokenMeter + ③ compactNow + ⑥ 压缩后重锚定
  const seenTypes = new Set<string>()
  // ③ compactNow/compactRegion 已多轮实测完毕（见 spike 报告），后续轮次不再触发压缩
  const compactionTriggered = false
  let markerInjected = false
  let drillFired = false
  // ⑧ 自动压缩路径模拟：第二个 pre-step（surface 已有首轮消息）时同步 await compactRegion。
  // 与真实自动压缩同款时序（pre-step 中间件同步等待 → 模型不并发跑 → whole-surface 稳定性检查可过）；
  // 不设一次性 flag——首 pre-step 时 surface 未成形（nodes<2）跳过，等下一个 pre-step。
  let autocRegionDone = false
  ctx.on('agent/pre-step', async (payload: { agent: Agent; signal?: AbortSignal }, next) => {
    if (!env.autocRegion || autocRegionDone) return next()
    try {
      if (!compaction || !tokenMeter) {
        autocRegionDone = true
        log('08-autoc-region', { ok: false, reason: `service missing compaction=${!!compaction} meter=${!!tokenMeter}` })
        return next()
      }
      const m = tokenMeter.measure(payload.agent.session)
      const nodes = (m as { nodes?: Array<{ seq: number }> }).nodes ?? []
      if (nodes.length < 2) {
        log('08-autoc-region', { ok: false, reason: 'surface too small', nodes: nodes.length })
        return next()
      }
      // end 从倒数第二个节点起向前回退：compactRegion 拒绝不平衡边界（tool-call/result 配对不可拆），
      // 真实自动压缩用 selectCompactableRange 找平衡点（dsh 私有），探针以只读 validate 失败为信号回退。
      const start = nodes[0].seq
      let lastError = ''
      for (let endIdx = nodes.length - 2; endIdx >= 1; endIdx -= 1) {
        try {
          const result = await compaction.compactRegion(start, nodes[endIdx].seq, payload.agent, payload.signal)
          autocRegionDone = true
          log('08-autoc-region', {
            ok: result !== null,
            reason: result === null ? 'null range (no compactable surface)' : undefined,
            start,
            end: nodes[endIdx].seq,
            attempts: nodes.length - 1 - endIdx,
            compactionId: result === null ? null : (result as { compactionId?: string }).compactionId,
          })
          return next()
        } catch (err) {
          lastError = String(err)
        }
      }
      autocRegionDone = true
      log('08-autoc-region', { ok: false, error: `no balanced boundary: ${lastError}` })
    } catch (err) {
      autocRegionDone = true
      log('08-autoc-region', { ok: false, error: String(err) })
    }
    return next()
  })
  ctx.on('session/event', (session: Session, event: SessionEvent) => {
    try {
      const eventType = (event as unknown as { type: string }).type
      if (!seenTypes.has(eventType)) {
        seenTypes.add(eventType)
        log('05-event-type', { type: eventType })
      }
      if (eventType.startsWith('compaction/')) {
        log('05-compaction-event', { type: eventType, data: (event as { data: unknown }).data })
      }
      if (eventType === 'compaction/summary') {
        const compactionId = (event as { data: { compactionId?: string } }).data?.compactionId ?? 'unknown'
        // ⑥ 压缩后重锚定：事件驱动 agent.inject。
        // 关键约束（round6 实证）：session/event 分发内同步 inject 会 append 重入被拒——
        // 必须推迟到当前事件 append 完成后（queueMicrotask）
        queueMicrotask(() => {
          try {
            const agent = agents?.get(String(session.id))
            if (agent) {
              agent.inject(createUserMessage({
                content: [{ type: 'text', text: `${B0_MARKER_PREFIX}${compactionId}（压缩后重锚定探针标记）` }],
                source: { kind: B0_SOURCE_KIND, form: 'instructions' },
              }))
              log('06-reanchor', { injected: true, compactionId, agentStatus: agent.status })
              if (env.followup) {
                agent.steer(createUserMessage({
                  content: [{ type: 'text', text: '批 0 探针问题：如果你当前上下文里看到了以 THREAD-B0-MARKER- 开头的标记，请在你的最终汇报里原样包含该标记。' }],
                  source: { kind: B0_SOURCE_KIND, form: 'instructions' },
                }))
                log('06-reanchor', { steerQueued: true, compactionId })
              }
            } else {
              log('06-reanchor', { injected: false, reason: 'no agent handle', compactionId })
            }
          } catch (err) {
            log('06-reanchor', { injected: false, error: String(err), compactionId })
          }
        })
      }
      if (eventType === 'user/message') {
        const body = extractText((event as { data: { content: Array<{ type: string; text?: string }> } }).data.content ?? [])
        if (body.includes(B0_MARKER_PREFIX)) {
          log('06-marker-landed', { body: body.slice(0, 200) })
        }
        // ⑧ 主插件压缩后重锚定卡进入 surface 的证据（自动路径 live 验证点）
        if (body.includes('[Thread 压缩后重锚定]')) {
          log('08-reanchor-landed', { body: body.slice(0, 160) })
        }
        if (body.startsWith('[Thread 状态更新（来自其他会话）]')) {
          log('07-delta-injected', { body: body.slice(0, 300) })
        }
      }
      if (eventType === 'assistant/message') {
        const body = (event as unknown as { data: { message: { content: Array<{ type: string; text?: string }> } } }).data.message.content
          .map((b) => (b.type === 'text' ? b.text ?? '' : ''))
          .join('\n')
        if (body.includes(B0_MARKER_PREFIX)) {
          log('06-marker-visible', { body: body.slice(0, 500) })
        }
      }
      if (eventType === 'turn/end' && !compactionTriggered) {
        // ④ tokenMeter 压力读取点（回合边界）
        try {
          if (!tokenMeter) {
            log('04-token-meter', { ok: false, reason: 'no tokenMeter service' })
          } else {
            const m = tokenMeter.measure(session)
            log('04-token-meter', {
              ok: true,
              totalTokens: m.totalTokens,
              surfaceTokens: m.surfaceTokens,
              surfaceDeltaTokens: m.surfaceDeltaTokens,
              keys: Object.keys(m),
              nodesSample: JSON.stringify(m.nodes).slice(0, 400),
            })
          }
        } catch (err) {
          log('04-token-meter', { ok: false, error: String(err) })
        }
      }
      // ⑦ G5 delta 现网实测（env.deltaDrill）：turn 内（tool/result，driver 活跃期）写入"他代理"决策
      // → followup 排队第二轮（runner 收尾前可见）→ 第二轮 pre-step 主插件 delta 块应注入 → 模型复述
      if (eventType === 'tool/result' && env.deltaDrill && !drillFired) {
        drillFired = true
        try {
          const paths = defaultPaths(process.cwd())
          const drillStore = new ThreadStore({ eventsPath: paths.eventsDbPath, structuredPath: paths.structuredDbPath, projectKey: deriveProjectKey(process.cwd()) })
          drillStore.proposeDecision('drill-other-agent', 'Thread 发布叙事主打模型工作质量（可靠性向）', { projectKey: deriveProjectKey(process.cwd()) })
          drillStore.close()
          log('07-drill', { decisionWritten: true })
          queueMicrotask(() => {
            const agent = agents?.get(String(session.id))
            // 注意：source 不能用 dsh-thread（主插件 isOwnInjection 会把第二轮当纯卡片轮跳过 delta）；
            // 用独立 kind 让主插件按正常轮处理（delta 块才会跑）——真实双代理场景第二轮即真实用户消息
            agent?.followup(createUserMessage({
              content: [{ type: 'text', text: 'drill 提问：你在最近上下文里是否看到以 [Thread 状态更新（来自其他会话）] 开头的增量块？如果看到，原样复述其中决策内容。' }],
              source: { kind: B0_DRILL_SOURCE_KIND, form: 'instructions' },
            }))
            log('07-drill', { followupQueued: true })
          })
        } catch (err) {
          log('07-drill', { ok: false, error: String(err) })
        }
      }
      // ⑥ 直达测试（不依赖压缩事务）：事件驱动 inject + steer → 下一 step 模型可见性。
      // 压缩后重锚定 = 同一机制把触发点换成 compaction/summary（⑤ 订阅已证、compaction/start 锁语义已证）。
      // compactNow 契约已另证（内部 runMaintenance + idle 认领 + busy 语义；one-shot 终轮被 teardown 赛跑取消）
      if (eventType === 'tool/result' && !markerInjected && env.followup) {
        markerInjected = true
        queueMicrotask(() => {
          const agent = agents?.get(String(session.id))
          if (!agent) {
            log('06-direct', { ok: false, reason: 'no agent handle' })
            return
          }
          try {
            agent.inject(createUserMessage({
              content: [{ type: 'text', text: `${B0_MARKER_PREFIX}direct-${Date.now()}` }],
              source: { kind: B0_SOURCE_KIND, form: 'instructions' },
            }))
            agent.steer(createUserMessage({
              content: [{ type: 'text', text: '批 0 探针问题：如果你当前上下文里看到了以 THREAD-B0-MARKER- 开头的标记，请在你的最终汇报中原样包含该标记。' }],
              source: { kind: B0_SOURCE_KIND, form: 'instructions' },
            }))
            log('06-direct', { injected: true, steered: true })
          } catch (err) {
            log('06-direct', { ok: false, error: String(err) })
          }
        })
      }
    } catch (err) {
      log('05-error', { error: String(err) })
    }
  })
  log('00-registered', { env })
}
