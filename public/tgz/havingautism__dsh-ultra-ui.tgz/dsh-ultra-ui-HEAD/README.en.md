# 🪄 dsh-ultra-ui · Ultra UI

English | [中文](README.md)

> A Codemini-inspired Web UI extension for DeepSeek Harness that only presents every Tool call as a compact, expandable, replay-safe disclosure row.

**Status** Preview · **Version** 0.1.1 · **Branch** `main`

## ✨ Features

- 📦 Collapse any Tool call, including tools contributed by third-party plugins.
- 👀 Keep the tool name and a useful argument summary visible while collapsed.
- 🔍 Expand exact arguments, results, errors, and the trajectory inspection action.
- 🔄 Derive state only from logged call/result blocks so live rendering matches replay.
- 🧠 Add no model tools, system instructions, or request tokens.

## 🚀 Quick Start

```sh
dsh plugin --profile web add github:havingautism/dsh-ultra-ui
dsh web
```

## 🧪 How to Verify

Open DSH Web and ask the model to call any tool, such as reading a file, running a command, or using a third-party plugin:

1. The Tool call initially appears as a compact one-line summary.
2. Click it or press Enter/Space to expand arguments and results.
3. Running, successful, and failed calls show distinct states.
4. The expanded row can open the matching call in the trajectory inspector.
5. Reopening the session preserves the same rendered content.

## 🛠️ How It Works

The Harness Tool tree routes every root call and subcall through `tool.call.presentation`. Ultra UI occupies that presentation layer and renders directly from the logged tool name, arguments, results, and errors. It maintains no business-tool allowlist, so tools contributed by other plugins use the same UI.

## 🧪 Verification and Development

```sh
npm run verify
```

Installable `lib/` artifacts are committed; run `npm run verify` for a syntax check.

## ⚠️ Known Limitations

- The Harness build must provide the single `tool.call.presentation` slot; on older builds without it, the plugin does not take over rendering.
- Only one plugin can occupy that presentation slot in a Session.
- Summaries prefer common fields such as `title`, `question`, `query`, `path`, and `command`; unfamiliar arguments fall back to the logged JSON prefix.
