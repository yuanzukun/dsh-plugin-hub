/** Ultra UI node half. Browser behavior ships through the client export. */

/** Host loader entry; this UI-only plugin owns no Host service. */
export function apply(): void {}
