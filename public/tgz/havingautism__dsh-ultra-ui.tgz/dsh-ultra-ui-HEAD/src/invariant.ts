/** Package-owned invariant companion for Ultra UI. */

import type { Context } from '@deepseek-ai/cordis'
import type { InvariantInstaller } from '@deepseek-ai/dsh-invariants'

/**
 * No runtime invariant: keyed UI slots own all registrations and dispose
 * them with the plugin lifecycle.
 */
const install: InvariantInstaller = () => {}

/** Companion name. */
export const name = 'ultra-ui-invariant'
/** Required registry. */
export const inject = ['invariants']
/** Reserve this package's invariant ownership. */
export const apply = (ctx: Context): Promise<() => void> =>
  Promise.resolve(ctx.invariants.register('@deepseek-ai/dsh-ultra-ui', install))
