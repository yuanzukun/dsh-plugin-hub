/** Codemini-inspired compact presentation for every Tool call. */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-tool/client'
import { UltraToolRow } from './UltraToolRow.tsx'

/** Required service: the declared Tool presentation slot. */
export const inject = ['slots']

/** Replace Tool presentation without owning any Tool name or business data. */
export function apply(ctx: ClientContext): void {
  ctx.slots.inject('tool.call.presentation', () =>
    ctx.slots.register({ name: 'tool.call.presentation' }, UltraToolRow))
}
