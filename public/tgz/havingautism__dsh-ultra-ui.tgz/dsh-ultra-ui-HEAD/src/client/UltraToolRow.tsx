/** Compact disclosure row for any Tool call. */

import { useState, type KeyboardEvent } from 'react'
import type { ToolCallBlock } from '@deepseek-ai/dsh-client-runtime/client'
import type { ToolCallOwnerProps } from '@deepseek-ai/dsh-client-ui-tool/client'
import css from './tool-row.module.css'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface SlotMap {
    /** Optional whole-Tool presentation seat supplied by current Harness builds. */
    'tool.call.presentation': {
      kind: 'single'
      scope: 'session'
      owner: ToolCallOwnerProps
    }
  }
}

/** Render one Tool as a one-line summary with replay-stable details. */
export function UltraToolRow({ toolName, block, inspect }: ToolCallOwnerProps) {
  const [open, setOpen] = useState(false)
  const settled = 'kind' in block
  const argsRaw = (settled ? block.call?.argsRaw : block.argsRaw) ?? ''
  const output = settled ? resultText(block) : null
  const expandable = argsRaw !== '' || output !== null
  const state = !settled ? 'running' : block.isError ? 'error' : 'ok'
  const summary = summarize(toolName, argsRaw)
  const toggle = () => { if (expandable) setOpen(value => !value) }
  const keyToggle = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key !== 'Enter' && event.key !== ' ') return
    event.preventDefault()
    toggle()
  }
  return (
    <div className={css.card} data-state={state}>
      <div className={css.row} role={expandable ? 'button' : undefined} tabIndex={expandable ? 0 : undefined} aria-expanded={expandable ? open : undefined} onClick={toggle} onKeyDown={keyToggle}>
        <span className={css.chevron} data-open={open || undefined}>›</span>
        <span className={css.dot} />
        <span className={css.title}>{toolTitle(toolName)}</span>
        <span className={css.separator} />
        <span className={css.summary}>{summary}</span>
      </div>
      {open ? (
        <div className={css.details}>
          <section><div className={css.detailsTitle}>参数</div><pre>{prettyJson(argsRaw)}</pre></section>
          {output === null ? null : <section><div className={css.detailsTitle}>结果</div><pre>{output}</pre></section>}
          {inspect === undefined ? null : <button className={css.inspect} type="button" onClick={inspect}>在轨迹中检查</button>}
        </div>
      ) : null}
    </div>
  )
}

function summarize(toolName: string, argsRaw: string): string {
  try {
    const args = JSON.parse(argsRaw) as Record<string, unknown>
    const candidate = args.title ?? args.question ?? args.source ?? args.query ?? args.path ?? args.command ?? args.id
    if (typeof candidate === 'string' && candidate !== '') return candidate.split('\n', 1)[0] ?? candidate
  } catch {
    // Streaming may expose a JSON prefix; the raw first line remains useful.
  }
  return argsRaw === '' ? (toolName.includes('list') ? '读取中' : '处理中') : argsRaw.split('\n', 1)[0] ?? argsRaw
}

function toolTitle(toolName: string): string {
  const title = toolName.replaceAll('_', ' ').replaceAll('-', ' ').trim()
  return title === '' ? 'Tool' : title
}

function prettyJson(raw: string): string {
  try { return JSON.stringify(JSON.parse(raw) as unknown, null, 2) } catch { return raw }
}

function resultText(block: Extract<ToolCallBlock, { kind: string }>): string | null {
  const parts = block.content.map(item => item.type === 'text' ? item.text : JSON.stringify(item, null, 2))
  if (parts.length === 0 && block.error !== undefined) parts.push(`${block.error.name}: ${block.error.code}`)
  return parts.join('\n') || null
}
