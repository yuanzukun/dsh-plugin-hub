// @vitest-environment jsdom

import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type { RunningToolCall, ToolResultNode } from '@deepseek-ai/dsh-client-runtime/client'
import type { ToolCallOwnerProps } from '@deepseek-ai/dsh-client-ui-tool/client'
import { apply } from '../src/client/index.ts'
import { UltraToolRow } from '../src/client/UltraToolRow.tsx'

type Props = ToolCallOwnerProps

afterEach(cleanup)

function running(argsRaw = '{"command":"pnpm test"}'): RunningToolCall {
  return {
    callId: 'call-research',
    name: 'bash',
    argsRaw,
    turn: 1,
    step: 1,
    time: 2_000,
    callView: null,
    subCalls: [],
  }
}

function settled(over: Partial<ToolResultNode> = {}): ToolResultNode {
  return {
    kind: 'tool-result',
    seq: 3,
    time: 3_000,
    callId: 'call-note',
    call: { name: 'read_file', argsRaw: '{"path":"docs/testing.md"}' },
    callTime: 2_000,
    content: [{ type: 'text', text: 'Testing policy.' }],
    isError: false,
    callView: null,
    resultView: null,
    subCalls: [],
    ...over,
  }
}

function props(toolName: string, block: Props['block'], inspect?: () => void): Props {
  return { callId: block.callId, toolName, block, openFile: vi.fn(), inspect } as unknown as Props
}

describe('UltraToolRow', () => {
  it('registers the whole-Tool presentation seat without claiming Tool names', () => {
    const register = vi.fn(() => vi.fn())
    const inject = vi.fn((_key: string, callback: () => unknown) => callback())
    apply({ slots: { inject, register } } as never)
    expect(inject).toHaveBeenCalledWith('tool.call.presentation', expect.any(Function))
    expect(register).toHaveBeenCalledWith({ name: 'tool.call.presentation' }, expect.any(Function))
  })

  it('summarizes any running Tool call from logged arguments', () => {
    const view = render(<UltraToolRow {...props('bash', running())} />)
    expect(view.container.querySelector('[data-state="running"]')).not.toBeNull()
    expect(view.container.textContent).toContain('bash')
    expect(view.container.textContent).toContain('pnpm test')
  })

  it('discloses exact arguments and results and hands off inspection', () => {
    const inspect = vi.fn()
    render(<UltraToolRow {...props('read_file', settled(), inspect)} />)
    const row = screen.getByRole('button')
    expect(row.getAttribute('aria-expanded')).toBe('false')
    fireEvent.keyDown(row, { key: 'Enter' })
    expect(row.getAttribute('aria-expanded')).toBe('true')
    expect(screen.getByText('Testing policy.')).not.toBeNull()
    expect(screen.getByText(/"path": "docs\/testing\.md"/u)).not.toBeNull()
    fireEvent.click(screen.getByRole('button', { name: '在轨迹中检查' }))
    expect(inspect).toHaveBeenCalledTimes(1)
  })

  it('keeps malformed streaming arguments visible and marks errors', () => {
    const failed = settled({
      call: { name: 'custom_tool', argsRaw: '{"title":\n' },
      content: [],
      isError: true,
      error: { name: 'ToolCallError', code: 'invalid-args' },
    })
    const view = render(<UltraToolRow {...props('custom_tool', failed)} />)
    expect(view.container.querySelector('[data-state="error"]')).not.toBeNull()
    fireEvent.click(screen.getByRole('button'))
    expect(view.container.textContent).toContain('{"title":')
    expect(view.container.textContent).toContain('ToolCallError: invalid-args')
  })
})
