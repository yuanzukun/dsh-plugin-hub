/** Package-owned invariant companion for Ultra UI. */
import type { Context } from '@deepseek-ai/cordis';
/** Companion name. */
export declare const name = "ultra-ui-invariant";
/** Required registry. */
export declare const inject: string[];
/** Reserve this package's invariant ownership. */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map