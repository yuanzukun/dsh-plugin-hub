/** Ultra UI node half. Browser behavior ships through the client export. */
/** Host loader entry; this UI-only plugin owns no Host service. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map