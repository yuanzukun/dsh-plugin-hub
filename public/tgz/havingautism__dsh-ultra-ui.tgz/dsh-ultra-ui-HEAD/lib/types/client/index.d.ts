/** Codemini-inspired compact presentation for every Tool call. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Required service: the declared Tool presentation slot. */
export declare const inject: string[];
/** Replace Tool presentation without owning any Tool name or business data. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map