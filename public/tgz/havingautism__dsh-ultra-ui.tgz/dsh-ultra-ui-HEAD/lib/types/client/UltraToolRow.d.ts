/** Compact disclosure row for any Tool call. */
import type { ToolCallOwnerProps } from '@deepseek-ai/dsh-client-ui-tool/client';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /** Optional whole-Tool presentation seat supplied by current Harness builds. */
        'tool.call.presentation': {
            kind: 'single';
            scope: 'session';
            owner: ToolCallOwnerProps;
        };
    }
}
/** Render one Tool as a one-line summary with replay-stable details. */
export declare function UltraToolRow({ toolName, block, inspect }: ToolCallOwnerProps): import("react").JSX.Element;
//# sourceMappingURL=UltraToolRow.d.ts.map