# dsh-gpt-perm-strip

A DeepSeek Harness plugin that runs **only for GPT-family models**. Before a tool body hits DSH's sandbox escalation check, it removes `sandbox_permissions` / `justification` that are **not strictly wider** than the current session.

## Why

DSH requires `sandbox_permissions` to be *strictly* wider than the session. The same (or a narrower) mode fails immediately:

```
sandbox escalation to "danger-full-access" is not strictly wider than this call's current "danger-full-access" mode
```

GPT-family models habitually send a permission field even when the session already has that access. This plugin drops those leftover fields and leaves real escalations (`workspace-write` → `danger-full-access`) untouched.

`tools/pre-execute` cannot rewrite frozen arguments. The plugin wraps each tool's `execute` and passes a cloned argument object with the unnecessary fields removed. The durable `tool/call` record still shows what the model emitted.

## GPT-only

Matching is by model id, not provider (OpenAI-compatible gateways often host GPT, Grok, and DeepSeek under one provider):

- `gpt-4o`, `gpt-5.6-sol`, `chatgpt-4o-latest`, `openai/gpt-4.1`, `ft:gpt-4o:…`
- optional: `o1` / `o3` / `o4` (`includeOpenAiReasoning`, default on)

Grok and DeepSeek are ignored unless you add `extraModelPatterns`.

Repo: https://github.com/FengLingYaaa/dsh-gpt-perm-strip

## Install

```sh
dsh plugin --profile web add github:FengLingYaaa/dsh-gpt-perm-strip
```

Or from a local checkout:

```sh
git clone https://github.com/FengLingYaaa/dsh-gpt-perm-strip.git
cd dsh-gpt-perm-strip
pnpm install
pnpm test
pnpm build
dsh plugin --profile web add .
```

## Config

| Field | Default | Meaning |
|---|---|---|
| `includeOpenAiReasoning` | `true` | Treat o1/o3/o4 as GPT-family |
| `extraModelPatterns` | `[]` | Extra regexes against `provider`, `model`, or `provider/model` |
| `injectPrompt` | `true` | GPT-only runtime-context reminder |
| `logStrips` | `true` | Log each strip as `[gpt-perm-strip] stripped …` |

## Behavior

| Session | GPT argument | Result |
|---|---|---|
| `danger-full-access` | `sandbox_permissions: danger-full-access` | stripped, call runs |
| `workspace-write` | `sandbox_permissions: workspace-write` | stripped |
| `workspace-write` | `sandbox_permissions: danger-full-access` | **kept** (real escalation) |
| `read-only` | `sandbox_permissions: workspace-write` | **kept** |
| non-GPT model | any permission | unchanged |

`permission` / `permissions` are treated as sandbox fields only when the value is a known sandbox mode.
