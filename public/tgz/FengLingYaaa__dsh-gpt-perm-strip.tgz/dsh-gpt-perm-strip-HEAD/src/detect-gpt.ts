import type { GptDetectConfig, ModelRoute } from './types.js'

/** `gpt-4`, `gpt-5.6-sol`, `ft:gpt-4o:…`, `openai/gpt-4o`, `chatgpt-4o-latest`. */
const GPT_NAME = /(^|[^a-z0-9])(chat)?gpt(\d|[-._]|$)/i

/** OpenAI reasoning models that share GPT tool-calling habits. */
const OPENAI_REASONING = /(^|[^a-z0-9])o[1-4]([.-]|mini|pro|preview|$)/i

function haystacks(route: ModelRoute): string[] {
  const provider = route.provider?.trim() ?? ''
  const model = route.model?.trim() ?? ''
  const items = [provider, model]
  if (provider && model) items.push(`${provider}/${model}`)
  return items.filter(item => item.length > 0)
}

function matchesExtra(text: string, patterns: readonly string[]): boolean {
  for (const raw of patterns) {
    try {
      if (new RegExp(raw, 'i').test(text)) return true
    } catch {
      if (text.toLowerCase().includes(raw.toLowerCase())) return true
    }
  }
  return false
}

/**
 * True only for GPT-series (and optionally OpenAI o-series) routes.
 * Provider-only matching is intentionally omitted: many OpenAI-compatible
 * gateways host GPT, Grok, and DeepSeek under the same provider id.
 */
export function isGptSeries(route: ModelRoute | undefined, config: GptDetectConfig): boolean {
  if (route === undefined) return false
  const texts = haystacks(route)
  if (texts.length === 0) return false
  for (const text of texts) {
    if (GPT_NAME.test(text)) return true
    if (config.includeOpenAiReasoning && OPENAI_REASONING.test(text)) return true
    if (config.extraModelPatterns.length > 0 && matchesExtra(text, config.extraModelPatterns)) return true
  }
  return false
}

/** Read the live route from an agent, preferring the last logged request header. */
export function resolveRoute(agent: { options?: ModelRoute; session?: { requestHeader?(): { config?: ModelRoute } | undefined } } | undefined): ModelRoute {
  const header = safeRequestHeader(agent)
  return {
    provider: header?.provider || agent?.options?.provider,
    model: header?.model || agent?.options?.model,
  }
}

function safeRequestHeader(agent: { session?: { requestHeader?(): { config?: ModelRoute } | undefined } } | undefined): ModelRoute | undefined {
  try {
    return agent?.session?.requestHeader?.()?.config
  } catch {
    return undefined
  }
}
