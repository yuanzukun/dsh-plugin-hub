import { isGptSeries, resolveRoute } from './detect-gpt.js'
import {
  SANDBOX_MODES,
  WIDER_MODES,
  type GptDetectConfig,
  type SandboxMode,
  type SandboxPolicyLike,
  type SessionLike,
  type StripDecision,
  type ToolExecLike,
} from './types.js'

const PERMISSION_KEYS = ['sandbox_permissions', 'permission', 'permissions'] as const
const JUSTIFICATION_KEY = 'justification'

export function isSandboxMode(value: unknown): value is SandboxMode {
  return typeof value === 'string' && (SANDBOX_MODES as readonly string[]).includes(value)
}

export function isStrictlyWider(effective: SandboxMode, requested: string): boolean {
  return (WIDER_MODES[effective] ?? []).includes(requested as SandboxMode)
}

export function readRequestedMode(args: Record<string, unknown>): { key: string; mode: string } | undefined {
  for (const key of PERMISSION_KEYS) {
    const value = args[key]
    if (typeof value !== 'string' || value.trim().length === 0) continue
    const mode = value.trim()
    // Only treat aliases as sandbox fields when the value is a known mode.
    // That keeps unrelated `permission: "admin"` arguments intact.
    if (key !== 'sandbox_permissions' && !isSandboxMode(mode)) continue
    return { key, mode }
  }
  return undefined
}

export function resolveEffectiveMode(
  exec: ToolExecLike,
  sandboxPolicy: SandboxPolicyLike | undefined,
): SandboxMode | undefined {
  const session = exec.agent?.session
  if (sandboxPolicy?.resolve) {
    try {
      const resolved = sandboxPolicy.resolve(session === undefined ? {} : { session })
      if (isSandboxMode(resolved?.mode)) return resolved.mode
    } catch {
      // fall through
    }
  }
  if (isSandboxMode(sandboxPolicy?.defaultMode)) return sandboxPolicy.defaultMode
  return foldSessionMode(session)
}

function foldSessionMode(session: SessionLike | undefined): SandboxMode | undefined {
  const events = session?.events
  if (!Array.isArray(events)) return undefined
  for (let i = events.length - 1; i >= 0; i -= 1) {
    const event = events[i]
    if (!event || typeof event !== 'object') continue
    const typed = event as { type?: string; data?: { mode?: unknown } }
    if (typed.type === 'sandbox/mode' && isSandboxMode(typed.data?.mode)) return typed.data.mode
  }
  return undefined
}

function cloneArgs(args: Record<string, unknown>): Record<string, unknown> {
  return { ...args }
}

/**
 * Drop permission fields that DSH would reject because they are not strictly
 * wider than the current session. Genuine escalations are left untouched.
 */
export function stripUnnecessaryPermissions(
  args: unknown,
  exec: ToolExecLike,
  config: GptDetectConfig,
  sandboxPolicy: SandboxPolicyLike | undefined,
): StripDecision {
  if (args === null || typeof args !== 'object' || Array.isArray(args)) {
    return { changed: false, args, strippedKeys: [] }
  }
  if (!isGptSeries(resolveRoute(exec.agent), config)) {
    return { changed: false, args, strippedKeys: [], reason: 'not-gpt' }
  }

  const record = args as Record<string, unknown>
  const requested = readRequestedMode(record)
  const effectiveMode = resolveEffectiveMode(exec, sandboxPolicy)

  if (requested === undefined) {
    return { changed: false, args, strippedKeys: [], effectiveMode, reason: 'no-permission-field' }
  }

  if (effectiveMode === undefined) {
    return { changed: false, args, strippedKeys: [], requestedMode: requested.mode, reason: 'unknown-effective-mode' }
  }

  if (isStrictlyWider(effectiveMode, requested.mode)) {
    return {
      changed: false,
      args,
      strippedKeys: [],
      requestedMode: requested.mode,
      effectiveMode,
      reason: 'strictly-wider',
    }
  }

  const next = cloneArgs(record)
  const strippedKeys: string[] = []
  for (const key of PERMISSION_KEYS) {
    if (key in next && (key === 'sandbox_permissions' || isSandboxMode(next[key]))) {
      delete next[key]
      strippedKeys.push(key)
    }
  }
  if (JUSTIFICATION_KEY in next) {
    delete next[JUSTIFICATION_KEY]
    strippedKeys.push(JUSTIFICATION_KEY)
  }

  return {
    changed: true,
    args: next,
    strippedKeys,
    requestedMode: requested.mode,
    effectiveMode,
    reason: 'not-strictly-wider',
  }
}
