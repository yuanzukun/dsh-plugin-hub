import type { PluginConfig, ResolvedPluginConfig } from './types.js'

const DEFAULTS: ResolvedPluginConfig = {
  includeOpenAiReasoning: true,
  extraModelPatterns: [],
  injectPrompt: true,
  logStrips: true,
}

function issue(message: string, path: Array<string | number> = []) {
  return { message, path }
}

function asStringArray(value: unknown, path: string): { value?: string[]; issues?: ReturnType<typeof issue>[] } {
  if (value === undefined) return { value: [] }
  if (!Array.isArray(value) || value.some(item => typeof item !== 'string')) {
    return { issues: [issue(`expected string[]`, [path])] }
  }
  return { value: value.filter(item => item.trim().length > 0) }
}

function asBoolean(value: unknown, path: string, fallback: boolean): { value?: boolean; issues?: ReturnType<typeof issue>[] } {
  if (value === undefined) return { value: fallback }
  if (typeof value !== 'boolean') return { issues: [issue('expected boolean', [path])] }
  return { value }
}

/** Normalize user config and apply defaults. */
export function resolvePluginConfig(raw: PluginConfig | undefined): ResolvedPluginConfig {
  return {
    includeOpenAiReasoning: raw?.includeOpenAiReasoning ?? DEFAULTS.includeOpenAiReasoning,
    extraModelPatterns: raw?.extraModelPatterns ?? [],
    injectPrompt: raw?.injectPrompt ?? DEFAULTS.injectPrompt,
    logStrips: raw?.logStrips ?? DEFAULTS.logStrips,
  }
}

/**
 * Standard Schema v1 so Cordis can validate the plugin row.
 * Avoids a hard schemastery runtime dependency.
 */
export const Config = {
  '~standard': {
    version: 1 as const,
    vendor: 'dsh-gpt-perm-strip',
    validate(value: unknown) {
      if (value === undefined || value === null) {
        return { value: { ...DEFAULTS } }
      }
      if (typeof value !== 'object' || Array.isArray(value)) {
        return { issues: [issue('expected a config object')] }
      }
      const input = value as PluginConfig
      const extra = asStringArray(input.extraModelPatterns, 'extraModelPatterns')
      const reasoning = asBoolean(input.includeOpenAiReasoning, 'includeOpenAiReasoning', DEFAULTS.includeOpenAiReasoning)
      const prompt = asBoolean(input.injectPrompt, 'injectPrompt', DEFAULTS.injectPrompt)
      const log = asBoolean(input.logStrips, 'logStrips', DEFAULTS.logStrips)
      const issues = [
        ...extra.issues ?? [],
        ...reasoning.issues ?? [],
        ...prompt.issues ?? [],
        ...log.issues ?? [],
      ]
      if (issues.length > 0) return { issues }
      return {
        value: {
          includeOpenAiReasoning: reasoning.value ?? DEFAULTS.includeOpenAiReasoning,
          extraModelPatterns: extra.value ?? [],
          injectPrompt: prompt.value ?? DEFAULTS.injectPrompt,
          logStrips: log.value ?? DEFAULTS.logStrips,
        } satisfies ResolvedPluginConfig,
      }
    },
  },
}
