import { stripUnnecessaryPermissions } from './strip.js'
import type {
  LoggerLike,
  PluginContextLike,
  ResolvedPluginConfig,
  SandboxPolicyLike,
  ToolExecLike,
  ToolLike,
  ToolRuntimeLike,
} from './types.js'

const WRAPPED = new WeakSet<object>()

export interface Stripper {
  (args: unknown, exec: unknown): unknown
}

export function createStripper(
  config: ResolvedPluginConfig,
  sandboxPolicy: SandboxPolicyLike | undefined | (() => SandboxPolicyLike | undefined),
  logger: LoggerLike | undefined,
): Stripper {
  return (args, exec) => {
    const policy = typeof sandboxPolicy === 'function' ? sandboxPolicy() : sandboxPolicy
    const decision = stripUnnecessaryPermissions(args, (exec ?? {}) as ToolExecLike, config, policy)
    if (decision.changed && config.logStrips) {
      const tool = typeof (exec as ToolExecLike | undefined)?.name === 'string'
        ? (exec as ToolExecLike).name
        : 'tool'
      const message = `[gpt-perm-strip] stripped ${decision.strippedKeys.join(', ')}`
        + ` from ${tool}`
        + ` (requested=${JSON.stringify(decision.requestedMode)}`
        + ` session=${JSON.stringify(decision.effectiveMode)})`
      if (typeof logger?.info === 'function') logger.info(message)
      else console.info(message)
    }
    return decision.args
  }
}

export function wrapToolDefinition(definition: ToolLike | undefined, stripper: Stripper): ToolLike | undefined {
  if (definition === undefined || typeof definition !== 'object') return definition
  if (WRAPPED.has(definition)) return definition
  const original = definition.execute
  if (typeof original !== 'function') return definition

  const wrapped = async function wrappedGptPermStrip(this: unknown, args: unknown, exec: unknown) {
    return original.call(this, stripper(args, exec), exec)
  }

  if (assignExecute(definition, wrapped)) {
    WRAPPED.add(definition)
    return definition
  }

  const copy: ToolLike = { ...definition, execute: wrapped }
  WRAPPED.add(copy)
  return copy
}

function assignExecute(definition: ToolLike, execute: ToolLike['execute']): boolean {
  try {
    definition.execute = execute
    return definition.execute === execute
  } catch {
    try {
      Object.defineProperty(definition, 'execute', {
        value: execute,
        writable: true,
        configurable: true,
        enumerable: true,
      })
      return definition.execute === execute
    } catch {
      return false
    }
  }
}

export function wrapVisibleTools(tools: ToolRuntimeLike, stripper: Stripper): number {
  let count = 0
  const schemas = typeof tools.schemas === 'function' ? tools.schemas() : []
  for (const schema of schemas ?? []) {
    if (!schema?.name || typeof tools.get !== 'function') continue
    const definition = tools.get(schema.name)
    if (wrapToolDefinition(definition, stripper) !== undefined && definition !== undefined) count += 1
  }
  return count
}

export function installRegisterWrapper(tools: ToolRuntimeLike, stripper: Stripper): () => void {
  const original = tools.register
  if (typeof original !== 'function') return () => {}
  tools.register = (definition: ToolLike) => original.call(tools, wrapToolDefinition(definition, stripper) ?? definition)
  return () => {
    tools.register = original
  }
}

export function installToolHooks(ctx: PluginContextLike, stripper: Stripper): void {
  const restore = installRegisterWrapper(ctx.tools, stripper)
  if (typeof ctx.effect === 'function') {
    ctx.effect(() => restore)
  }

  wrapVisibleTools(ctx.tools, stripper)

  if (typeof ctx.on === 'function') {
    ctx.on('tools/change', () => {
      wrapVisibleTools(ctx.tools, stripper)
    })
    ctx.on('tools/pre-execute', (exec, next) => {
      const call = exec as ToolExecLike
      if (typeof call?.name === 'string' && typeof ctx.tools.get === 'function') {
        wrapToolDefinition(ctx.tools.get(call.name, call.agent), stripper)
      }
      return typeof next === 'function' ? (next as () => unknown)() : undefined
    }, { prepend: true })
  }
}
