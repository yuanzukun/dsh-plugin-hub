import { Config, resolvePluginConfig } from './config.js'
import { isGptSeries, resolveRoute } from './detect-gpt.js'
import { createStripper, installToolHooks } from './wrap.js'
import type {
  AssembleContextLike,
  PluginConfig,
  PluginContextLike,
  ResolvedPluginConfig,
  SandboxPolicyLike,
} from './types.js'

export const name = 'gpt-perm-strip'
export const inject = ['tools']
export { Config }

export type { PluginConfig, ResolvedPluginConfig }
export { isGptSeries, resolveRoute, resolvePluginConfig }
export { isStrictlyWider, stripUnnecessaryPermissions } from './strip.js'

const PROMPT_TEXT = [
  'GPT compatibility shim is active for this model.',
  'Do not set sandbox_permissions or justification unless the requested mode is strictly wider than the current session file policy.',
  'Same-or-narrower permission fields are stripped automatically before DSH validates them.',
].join(' ')

function sandboxPolicyOf(ctx: PluginContextLike): SandboxPolicyLike | undefined {
  const fromGet = typeof ctx.get === 'function' ? ctx.get('sandboxPolicy') : undefined
  if (fromGet && typeof fromGet === 'object') return fromGet as SandboxPolicyLike
  return ctx.sandboxPolicy
}

function installPrompt(ctx: PluginContextLike, config: ResolvedPluginConfig): void {
  const attach = (scope: PluginContextLike) => {
    scope.systemPrompt?.context?.({
      name: 'gpt-perm-strip:policy',
      order: 115,
      text: (context: AssembleContextLike) => (
        isGptSeries(resolveRoute(context.agent), config) ? PROMPT_TEXT : ''
      ),
    })
  }

  if (typeof ctx.inject === 'function') {
    ctx.inject(['systemPrompt'], attach)
    return
  }
  if (ctx.systemPrompt) attach(ctx)
}

/** Cordis plugin entry: wrap tool execute so GPT's leftover permission args never reach escalation checks. */
export function apply(ctx: PluginContextLike, rawConfig: PluginConfig = {}): void {
  const config = resolvePluginConfig(rawConfig)
  const stripper = createStripper(config, () => sandboxPolicyOf(ctx), ctx.logger)
  installToolHooks(ctx, stripper)
  if (config.injectPrompt) installPrompt(ctx, config)
}
