/** Closed DSH sandbox ladder. Must stay aligned with `@deepseek-ai/dsh-sandbox`. */
export const SANDBOX_MODES = ['read-only', 'workspace-write', 'danger-full-access'] as const

export type SandboxMode = (typeof SANDBOX_MODES)[number]

/**
 * What a call whose effective mode is the key may escalate TO.
 * Copied from DSH `WIDER_MODES`: the request must be *strictly* wider.
 */
export const WIDER_MODES: Record<SandboxMode, readonly SandboxMode[]> = {
  'read-only': ['workspace-write', 'danger-full-access'],
  'workspace-write': ['danger-full-access'],
  'danger-full-access': [],
}

/** Provider / model pair used to decide whether this plugin should run. */
export interface ModelRoute {
  provider?: string
  model?: string
}

export interface GptDetectConfig {
  /**
   * Also treat OpenAI o1/o3/o4 reasoning models as GPT-family.
   * They share the same tool-calling habit. Default: true.
   */
  includeOpenAiReasoning: boolean
  /**
   * Extra case-insensitive regexes tested against `provider`, `model`,
   * and `provider/model`. Use this for grok / custom Azure deployment names.
   */
  extraModelPatterns: readonly string[]
}

export interface PluginConfig {
  includeOpenAiReasoning?: boolean
  extraModelPatterns?: string[]
  /**
   * Inject a GPT-only runtime-context reminder. Default: true.
   * The text is empty for non-GPT models, so it does not affect them.
   */
  injectPrompt?: boolean
  /** Log each stripped field to the harness logger. Default: true. */
  logStrips?: boolean
}

export interface ResolvedPluginConfig extends GptDetectConfig {
  injectPrompt: boolean
  logStrips: boolean
}

export interface StripDecision {
  changed: boolean
  args: unknown
  strippedKeys: string[]
  requestedMode?: string
  effectiveMode?: SandboxMode
  reason?: string
}

export interface ToolLike {
  name?: string
  execute?: (args: unknown, exec: unknown) => unknown
  [key: string]: unknown
}

export interface ToolRuntimeLike {
  register?(definition: ToolLike): unknown
  get?(name: string, scope?: unknown): ToolLike | undefined
  schemas?(scope?: unknown): Array<{ name: string }>
}

export interface SandboxPolicyLike {
  defaultMode?: SandboxMode
  resolve?(request?: { session?: unknown; mode?: SandboxMode }): { mode?: SandboxMode }
}

export interface LoggerLike {
  info?(message: string, ...args: unknown[]): void
  debug?(message: string, ...args: unknown[]): void
}

export interface AgentLike {
  options?: ModelRoute
  session?: SessionLike
}

export interface SessionLike {
  requestHeader?(): { config?: ModelRoute } | undefined
  events?: readonly unknown[]
}

export interface ToolExecLike {
  name?: string
  arguments?: unknown
  agent?: AgentLike
}

export interface AssembleContextLike {
  agent?: AgentLike
}

export interface SystemPromptLike {
  context?(entry: {
    name: string
    order: number
    text: string | ((context: AssembleContextLike) => string)
  }): unknown
}

export interface PluginContextLike {
  tools: ToolRuntimeLike
  get?(name: string): unknown
  inject?(deps: string[], callback: (scope: PluginContextLike) => void): unknown
  on?(event: string, listener: (...args: unknown[]) => unknown, options?: { prepend?: boolean }): () => void
  effect?(callback: () => (() => void) | void): unknown
  logger?: LoggerLike
  systemPrompt?: SystemPromptLike
  sandboxPolicy?: SandboxPolicyLike
}
