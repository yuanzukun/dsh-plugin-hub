import { describe, expect, it, vi } from 'vitest'
import { resolvePluginConfig } from '../src/config.ts'
import { createStripper, installRegisterWrapper, wrapToolDefinition } from '../src/wrap.ts'

describe('wrapToolDefinition', () => {
  it('strips leftover permissions before the original execute runs', async () => {
    const seen: unknown[] = []
    const tool = {
      name: 'bash',
      async execute(args: unknown) {
        seen.push(args)
        return 'ok'
      },
    }
    const stripper = createStripper(
      resolvePluginConfig({}),
      { defaultMode: 'danger-full-access' },
      undefined,
    )
    wrapToolDefinition(tool, stripper)
    const result = await tool.execute(
      {
        command: 'pwd',
        sandbox_permissions: 'danger-full-access',
        justification: 'already have it',
      },
      { name: 'bash', agent: { options: { model: 'gpt-4.1' } } },
    )
    expect(result).toBe('ok')
    expect(seen).toEqual([{ command: 'pwd' }])
  })

  it('is idempotent', async () => {
    const execute = vi.fn(async (args: unknown) => args)
    const tool = { name: 'write', execute }
    const stripper = createStripper(resolvePluginConfig({}), { defaultMode: 'danger-full-access' }, undefined)
    wrapToolDefinition(tool, stripper)
    wrapToolDefinition(tool, stripper)
    await tool.execute(
      { file_path: 'a.txt', content: 'x', sandbox_permissions: 'workspace-write' },
      { name: 'write', agent: { options: { model: 'gpt-4o' } } },
    )
    expect(execute).toHaveBeenCalledTimes(1)
  })
})

describe('installRegisterWrapper', () => {
  it('wraps tools as they register', async () => {
    const registered: Array<{ execute: (args: unknown, exec: unknown) => unknown }> = []
    const tools = {
      register(definition: { execute: (args: unknown, exec: unknown) => unknown }) {
        registered.push(definition)
        return () => {}
      },
    }
    const stripper = createStripper(resolvePluginConfig({}), { defaultMode: 'danger-full-access' }, undefined)
    installRegisterWrapper(tools, stripper)
    const original = vi.fn(async (args: unknown) => args)
    tools.register({ execute: original })
    await registered[0]?.execute(
      { command: 'true', sandbox_permissions: 'danger-full-access', justification: 'x' },
      { name: 'bash', agent: { options: { model: 'gpt-5' } } },
    )
    expect(original).toHaveBeenCalledWith({ command: 'true' }, expect.any(Object))
  })
})
