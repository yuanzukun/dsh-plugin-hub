import { describe, expect, it } from 'vitest'
import { isStrictlyWider, stripUnnecessaryPermissions } from '../src/strip.ts'
import type { GptDetectConfig, ToolExecLike } from '../src/types.ts'

const gptConfig: GptDetectConfig = { includeOpenAiReasoning: true, extraModelPatterns: [] }

function gptExec(overrides: Partial<ToolExecLike> = {}): ToolExecLike {
  return {
    name: 'bash',
    agent: { options: { provider: 'cpa', model: 'gpt-5.6-sol' } },
    ...overrides,
  }
}

const fullAccess = { defaultMode: 'danger-full-access' as const }

describe('isStrictlyWider', () => {
  it('matches the DSH ladder', () => {
    expect(isStrictlyWider('read-only', 'workspace-write')).toBe(true)
    expect(isStrictlyWider('workspace-write', 'danger-full-access')).toBe(true)
    expect(isStrictlyWider('workspace-write', 'workspace-write')).toBe(false)
    expect(isStrictlyWider('danger-full-access', 'danger-full-access')).toBe(false)
    expect(isStrictlyWider('danger-full-access', 'workspace-write')).toBe(false)
  })
})

describe('stripUnnecessaryPermissions', () => {
  it('strips same-level sandbox_permissions from GPT calls', () => {
    const args = {
      command: 'ls',
      sandbox_permissions: 'danger-full-access',
      justification: 'The current session already grants full file access.',
    }
    const decision = stripUnnecessaryPermissions(args, gptExec(), gptConfig, fullAccess)
    expect(decision.changed).toBe(true)
    expect(decision.args).toEqual({ command: 'ls' })
    expect(decision.strippedKeys).toEqual(['sandbox_permissions', 'justification'])
    expect(args.sandbox_permissions).toBe('danger-full-access')
  })

  it('keeps a genuine workspace-write → danger-full-access escalation', () => {
    const args = {
      command: 'ls /etc',
      sandbox_permissions: 'danger-full-access',
      justification: 'Need host files after a sandbox denial.',
    }
    const decision = stripUnnecessaryPermissions(
      args,
      gptExec(),
      gptConfig,
      { defaultMode: 'workspace-write' },
    )
    expect(decision.changed).toBe(false)
    expect(decision.args).toBe(args)
    expect(decision.reason).toBe('strictly-wider')
  })

  it('does not touch non-GPT models', () => {
    const args = { command: 'ls', sandbox_permissions: 'danger-full-access', justification: 'x' }
    const decision = stripUnnecessaryPermissions(
      args,
      { name: 'bash', agent: { options: { model: 'grok-4.6' } } },
      gptConfig,
      fullAccess,
    )
    expect(decision.changed).toBe(false)
    expect(decision.reason).toBe('not-gpt')
  })

  it('treats permission aliases only when the value is a sandbox mode', () => {
    const sandboxAlias = stripUnnecessaryPermissions(
      { command: 'ls', permission: 'workspace-write' },
      gptExec(),
      gptConfig,
      { defaultMode: 'workspace-write' },
    )
    expect(sandboxAlias.changed).toBe(true)
    expect(sandboxAlias.args).toEqual({ command: 'ls' })

    const foreign = stripUnnecessaryPermissions(
      { action: 'grant', permission: 'admin' },
      gptExec(),
      gptConfig,
      fullAccess,
    )
    expect(foreign.changed).toBe(false)
    expect(foreign.args).toEqual({ action: 'grant', permission: 'admin' })
  })

  it('leaves calls without permission fields alone', () => {
    const args = { command: 'pwd' }
    const decision = stripUnnecessaryPermissions(args, gptExec(), gptConfig, fullAccess)
    expect(decision.changed).toBe(false)
    expect(decision.args).toBe(args)
  })

  it('reads the session sandbox/mode fold when the policy service is missing', () => {
    const decision = stripUnnecessaryPermissions(
      { file_path: 'a.txt', content: 'x', sandbox_permissions: 'workspace-write', justification: 'write' },
      gptExec({
        agent: {
          options: { model: 'gpt-4o' },
          session: { events: [{ type: 'sandbox/mode', data: { mode: 'workspace-write' } }] },
        },
      }),
      gptConfig,
      undefined,
    )
    expect(decision.changed).toBe(true)
    expect(decision.args).toEqual({ file_path: 'a.txt', content: 'x' })
  })
})
