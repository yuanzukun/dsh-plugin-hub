import { describe, expect, it, vi } from 'vitest'
import { apply, Config } from '../src/index.ts'
import type { PluginContextLike, ToolLike } from '../src/types.ts'

function createCtx() {
  const tools = new Map<string, ToolLike>()
  const listeners = new Map<string, Array<(...args: unknown[]) => unknown>>()
  const ctx: PluginContextLike = {
    tools: {
      register(definition) {
        if (definition.name) tools.set(definition.name, definition)
        return () => {
          if (definition.name) tools.delete(definition.name)
        }
      },
      get(name) {
        return tools.get(name)
      },
      schemas() {
        return [...tools.keys()].map(name => ({ name }))
      },
    },
    get(name) {
      return name === 'sandboxPolicy' ? { defaultMode: 'danger-full-access' } : undefined
    },
    on(event, listener) {
      const bucket = listeners.get(event) ?? []
      bucket.push(listener)
      listeners.set(event, bucket)
      return () => {
        listeners.set(event, (listeners.get(event) ?? []).filter(item => item !== listener))
      }
    },
    effect() {
      return () => {}
    },
    logger: { info: vi.fn() },
  }
  return { ctx, tools, listeners }
}

describe('Config schema', () => {
  it('fills defaults and rejects bad types', () => {
    const ok = Config['~standard'].validate(undefined)
    expect('value' in ok && ok.value).toMatchObject({
      includeOpenAiReasoning: true,
      injectPrompt: true,
      logStrips: true,
    })
    const bad = Config['~standard'].validate({ includeOpenAiReasoning: 'yes' })
    expect('issues' in bad && bad.issues?.length).toBeGreaterThan(0)
  })
})

describe('apply', () => {
  it('wraps already-registered and later-registered tools', async () => {
    const { ctx, tools, listeners } = createCtx()
    const earlyExecute = vi.fn(async (args: unknown) => args)
    const early = {
      name: 'bash',
      execute: earlyExecute,
    }
    ctx.tools.register?.(early)
    apply(ctx, { injectPrompt: false })

    const lateExecute = vi.fn(async (args: unknown) => args)
    const late = {
      name: 'write',
      execute: lateExecute,
    }
    ctx.tools.register?.(late)
    for (const listener of listeners.get('tools/change') ?? []) listener()

    const exec = { name: 'bash', agent: { options: { model: 'gpt-5.6-sol' } } }
    await tools.get('bash')?.execute?.(
      { command: 'pwd', sandbox_permissions: 'danger-full-access', justification: 'already full access' },
      exec,
    )
    await tools.get('write')?.execute?.(
      { file_path: 'a.txt', content: 'x', sandbox_permissions: 'danger-full-access', justification: 'already full access' },
      { ...exec, name: 'write' },
    )

    expect(earlyExecute).toHaveBeenCalledWith({ command: 'pwd' }, exec)
    expect(lateExecute).toHaveBeenCalledWith({ file_path: 'a.txt', content: 'x' }, expect.objectContaining({ name: 'write' }))
  })
})
