import { describe, expect, it } from 'vitest'
import { isGptSeries, resolveRoute } from '../src/detect-gpt.ts'

const base = { includeOpenAiReasoning: true, extraModelPatterns: [] as string[] }

describe('isGptSeries', () => {
  it('matches common GPT model ids regardless of provider', () => {
    expect(isGptSeries({ provider: 'cpa', model: 'gpt-5.6-sol' }, base)).toBe(true)
    expect(isGptSeries({ provider: 'openai', model: 'gpt-4o' }, base)).toBe(true)
    expect(isGptSeries({ provider: 'openrouter', model: 'openai/gpt-4.1' }, base)).toBe(true)
    expect(isGptSeries({ model: 'chatgpt-4o-latest' }, base)).toBe(true)
    expect(isGptSeries({ model: 'ft:gpt-4o-2024-08-06:org:name:id' }, base)).toBe(true)
  })

  it('does not match DeepSeek or Grok on an OpenAI-compatible provider', () => {
    expect(isGptSeries({ provider: 'cpa', model: 'grok-4.6' }, base)).toBe(false)
    expect(isGptSeries({ provider: 'cpa', model: 'deepseek-v4-flash' }, base)).toBe(false)
    expect(isGptSeries({ provider: 'openai', model: 'deepseek-chat' }, base)).toBe(false)
  })

  it('optionally matches OpenAI reasoning models', () => {
    expect(isGptSeries({ model: 'o3-mini' }, base)).toBe(true)
    expect(isGptSeries({ model: 'o4-mini' }, { ...base, includeOpenAiReasoning: false })).toBe(false)
    expect(isGptSeries({ model: 'foo1-bar' }, base)).toBe(false)
  })

  it('honors extra patterns for non-GPT models that share the habit', () => {
    expect(isGptSeries({ model: 'grok-4.6' }, { ...base, extraModelPatterns: ['^grok'] })).toBe(true)
  })

  it('returns false when the route is empty', () => {
    expect(isGptSeries(undefined, base)).toBe(false)
    expect(isGptSeries({}, base)).toBe(false)
  })
})

describe('resolveRoute', () => {
  it('prefers the last request header over agent options', () => {
    const route = resolveRoute({
      options: { provider: 'old', model: 'stale' },
      session: {
        requestHeader: () => ({ config: { provider: 'cpa', model: 'gpt-5.6-luna' } }),
      },
    })
    expect(route).toEqual({ provider: 'cpa', model: 'gpt-5.6-luna' })
  })
})
