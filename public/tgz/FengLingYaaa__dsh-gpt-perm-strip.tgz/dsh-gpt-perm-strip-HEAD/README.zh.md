# dsh-gpt-perm-strip

只对 **GPT 系列模型** 生效的 DSH 插件：在工具真正执行、进入沙箱升权校验之前，删掉 GPT 习惯性带上、但又**并不比当前会话更宽**的 `sandbox_permissions` / `justification`。

## 为什么需要它

DSH 的规则是：`sandbox_permissions` 必须**严格宽于**当前会话权限。同级或更窄的请求会直接失败：

```
sandbox escalation to "danger-full-access" is not strictly wider than this call's current "danger-full-access" mode
```

GPT（以及同一套 function calling 习惯的 o 系列）经常在已经是 `workspace-write` / `danger-full-access` 的会话里，仍然带上同级 `sandbox_permissions`。插件只删这种无效字段；`workspace-write → danger-full-access` 这种真升权原样保留。

`tools/pre-execute` 不能改参数（参数在进入流水线前已被冻住，且已写入 `tool/call`）。本插件包装工具的 `execute`，把一份去掉多余权限字段的参数副本交给工具体。审计日志里仍能看到模型原始参数。

## 只适配 GPT

默认只匹配模型 id，不匹配 provider（很多网关把 GPT / Grok / DeepSeek 挂在同一个 provider 下）：

- `gpt-4o`、`gpt-5.6-sol`、`chatgpt-4o-latest`、`openai/gpt-4.1`、`ft:gpt-4o:…`
- 可选：`o1` / `o3` / `o4`（`includeOpenAiReasoning`，默认开启）

Grok、DeepSeek 等默认不处理。若它们也有同样习惯，用 `extraModelPatterns` 自行加白。

仓库：https://github.com/FengLingYaaa/dsh-gpt-perm-strip

## 安装

直接从 GitHub 装进 profile：

```sh
dsh plugin --profile web add github:FengLingYaaa/dsh-gpt-perm-strip
```

或本地 checkout 后安装：

```sh
git clone https://github.com/FengLingYaaa/dsh-gpt-perm-strip.git
cd dsh-gpt-perm-strip
pnpm install
pnpm test
pnpm build

dsh plugin --profile web add .
```

本机当前 GUI 使用的是 `web` profile。装好后重启或等待插件热加载。

也可在 profile 的 `cordis.patch.yml` 里手动 insert（`dsh plugin add` 通常会代劳）：

```yaml
- insert:
    - id: gpt-perm-strip
      name: dsh-gpt-perm-strip
      config:
        includeOpenAiReasoning: true
        injectPrompt: true
        logStrips: true
```

## 配置

| 字段 | 默认 | 含义 |
|---|---|---|
| `includeOpenAiReasoning` | `true` | 把 o1/o3/o4 当成 GPT 家族 |
| `extraModelPatterns` | `[]` | 额外正则，匹配 `provider`、`model` 或 `provider/model` |
| `injectPrompt` | `true` | 仅对 GPT 注入一条 runtime context 提醒 |
| `logStrips` | `true` | 每次剥离打一条 `[gpt-perm-strip] stripped …` 日志 |

让 Grok 也走同一逻辑：

```yaml
config:
  extraModelPatterns:
    - '^grok'
```

## 行为摘要

| 当前会话 | GPT 传入 | 结果 |
|---|---|---|
| `danger-full-access` | `sandbox_permissions: danger-full-access` | 删除权限字段，命令照常执行 |
| `workspace-write` | `sandbox_permissions: workspace-write` | 删除 |
| `workspace-write` | `sandbox_permissions: danger-full-access` | **保留**（真升权） |
| `read-only` | `sandbox_permissions: workspace-write` | **保留** |
| 非 GPT 模型 | 任意 permission | 不改 |

`permission` / `permissions` 仅当值是 `read-only` / `workspace-write` / `danger-full-access` 时才当作沙箱字段，避免误删别的工具自己的 `permission` 参数。
