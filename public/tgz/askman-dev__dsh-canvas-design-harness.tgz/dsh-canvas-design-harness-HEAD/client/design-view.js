// client/design-view.js — BROWSER half of the DSH canvas wrapper (方案 A tabs).
//
// This file is the BODY of the client plugin bundle. scripts/build-client.mjs
// wraps it into client/bundle.js, which the DSH web shell loads as a client
// module (a classic script that registers a factory via
// window.__ModuleLoader__.load({ id, factory })). The wrapper provides `React`
// (the shell instance, a platform seed word) and exports the cordis plugin
// face (`inject` / `apply`) after this body.
//
// It implements, inside the DSH web GUI:
//   - the persistent `设计大厅` / `Design Gallery` tab on the conversation.view
//     ring (order 20 — right of the chat tab, order 0, and the trajectory tab,
//     order 10),
//   - concise empty / onboarding state with conversation guidance tips,
//   - high-fidelity design card gallery with canvas preview mockups,
//   - embedded canvas viewer iframe (host route /canvas/open, which 302s
//     to the canvas daemon's /open viewer),
//   - postMessage click-to-ask bridge: node:selected messages from the
//     viewer set the composer draft through the conversation standard kit.
//
// All user-facing strings go through the DSH locale service (zh/en
// dictionaries registered under NS).
const { useState, useEffect, useCallback, createElement: h } = React;

// --- inlined from client/logic.js (keep in sync; Part D tests logic.js) ---
function designTabLabel(name) {
  return String(name ?? "design").replace(/\.html$/i, "");
}
function nodeSelectedMessageOk(message) {
  return (
    !!message &&
    message.source === "canvas-design-harness" &&
    message.type === "node:selected" &&
    !!message.payload &&
    typeof message.payload === "object" &&
    (typeof message.payload.nodeId === "string" || message.payload.nodeId === null)
  );
}

// --- conversation.view ring placement ---
const GALLERY_TAB_ID = "design-gallery";
const GALLERY_TAB_ORDER = 20;

// --- locale dictionaries (zh / en) ---
const NS = "dsh.canvas";
const zh = {
  "tab.label": "设计大厅",
  "gallery.title": "设计大厅",
  "gallery.subtitle": "基于 Canvas Design Harness 的可视化画板中心",
  "gallery.count": "{count} 个设计稿",
  "gallery.loading": "加载设计中…",
  "gallery.refresh": "刷新",
  "gallery.emptyTitle": "暂无设计稿",
  "gallery.emptyDesc": "当前工作区 docs/designs 目录下暂无设计稿。",
  "gallery.pathLabel": "设计稿保存目录：",
  "gallery.tipTitle": "💬 对话生成设计稿",
  "gallery.tipDesc": "在会话中向 Agent 描述你的产品界面需求，Agent 将自动调用技能在当前工作区的 docs/designs 目录下创建和绘制多画板设计稿。",
  "gallery.tipSample": "帮我设计一个用户登录界面的设计稿",
  "gallery.useSamplePrompt": "填入提问草稿",
  "gallery.promptFilled": "已填入输入框",
  "gallery.back": "← 返回设计大厅",
  "gallery.openNewTab": "新窗口打开",
  "gallery.openInCanvas": "进入画布",
  "gallery.meta": "{pages} 页 · {frames} 帧",
  "gallery.copyPath": "复制路径",
  "gallery.copied": "已复制",
  "err.no-root": "无法确定设计稿目录（缺少 root，且会话不属于任何工作区）",
  "err.designs-dir-missing": "设计稿目录未创建",
  "err.internal": "服务错误: {message}",
  "err.network": "网络连接失败，请检查服务状态",
  "draft.prefix": "请修改设计稿中的{kind}节点{label}{id}：",
};
const en = {
  "tab.label": "Design Gallery",
  "gallery.title": "Design Gallery",
  "gallery.subtitle": "Interactive Canvas Design Harness workspace",
  "gallery.count": "{count} designs",
  "gallery.loading": "Loading designs…",
  "gallery.refresh": "Refresh",
  "gallery.emptyTitle": "No Design Files Yet",
  "gallery.emptyDesc": "No design files found under docs/designs in this workspace.",
  "gallery.pathLabel": "Designs Storage Directory:",
  "gallery.tipTitle": "💬 Generate Designs in Chat",
  "gallery.tipDesc": "Describe your UI requirements to Agent in chat. Agent will automatically invoke canvas tools to generate and render design files under docs/designs.",
  "gallery.tipSample": "Design a user login interface for me",
  "gallery.useSamplePrompt": "Fill prompt draft",
  "gallery.promptFilled": "Draft filled",
  "gallery.back": "← Back to Gallery",
  "gallery.openNewTab": "Open in New Window",
  "gallery.openInCanvas": "Open Design",
  "gallery.meta": "{pages} pages · {frames} frames",
  "gallery.copyPath": "Copy Path",
  "gallery.copied": "Copied",
  "err.no-root": "Cannot determine designs directory (missing root, session has no workspace)",
  "err.designs-dir-missing": "Designs directory not created yet",
  "err.internal": "Service error: {message}",
  "err.network": "Network connection failed",
  "draft.prefix": "Please modify the {kind} node {label}{id} in the design:",
};

// --- SVG Icons ---
function IconFolder(props) {
  return h(
    "svg",
    {
      width: props.size || 16,
      height: props.size || 16,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      style: props.style,
    },
    h("path", { d: "M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z" }),
  );
}

function IconRefresh(props) {
  return h(
    "svg",
    {
      width: props.size || 16,
      height: props.size || 16,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      style: props.style,
    },
    h("path", { d: "M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" }),
    h("path", { d: "M3 3v5h5" }),
    h("path", { d: "M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" }),
    h("path", { d: "M16 21h5v-5" }),
  );
}

function IconExternalLink(props) {
  return h(
    "svg",
    {
      width: props.size || 14,
      height: props.size || 14,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      style: props.style,
    },
    h("path", { d: "M15 3h6v6" }),
    h("path", { d: "M10 14 21 3" }),
    h("path", { d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" }),
  );
}

function IconCopy(props) {
  return h(
    "svg",
    {
      width: props.size || 14,
      height: props.size || 14,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      style: props.style,
    },
    h("rect", { width: 14, height: 14, x: 8, y: 8, rx: 2, ry: 2 }),
    h("path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" }),
  );
}

function IconCheck(props) {
  return h(
    "svg",
    {
      width: props.size || 14,
      height: props.size || 14,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      style: props.style,
    },
    h("polyline", { points: "20 6 9 17 4 12" }),
  );
}

function IconLayout(props) {
  return h(
    "svg",
    {
      width: props.size || 24,
      height: props.size || 24,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      style: props.style,
    },
    h("rect", { width: 18, height: 18, x: 3, y: 3, rx: 2 }),
    h("path", { d: "M3 9h18" }),
    h("path", { d: "M9 21V9" }),
  );
}

function IconMessage(props) {
  return h(
    "svg",
    {
      width: props.size || 16,
      height: props.size || 16,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: 2,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      style: props.style,
    },
    h("path", { d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" }),
  );
}

// Mini Canvas Mockup Art for Design Card preview
function CardMockupArt() {
  return h(
    "div",
    {
      style: {
        width: "100%",
        height: "100%",
        position: "relative",
        background: "linear-gradient(135deg, #f8fafc 0%, #edf2f7 100%)",
        backgroundImage: "radial-gradient(#cbd5e1 1px, transparent 1px)",
        backgroundSize: "16px 16px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        overflow: "hidden",
      },
    },
    h(
      "div",
      {
        style: {
          width: "180px",
          height: "100px",
          background: "#ffffff",
          borderRadius: "8px",
          boxShadow: "0 4px 12px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.04)",
          border: "1px solid #e2e8f0",
          display: "flex",
          flexDirection: "column",
          padding: "8px 10px",
          gap: "6px",
        },
      },
      h(
        "div",
        { style: { display: "flex", alignItems: "center", justifyContent: "space-between" } },
        h("div", { style: { width: "40px", height: "6px", borderRadius: "3px", background: "#3b82f6" } }),
        h("div", { style: { display: "flex", gap: "3px" } }, [
          h("div", { key: 1, style: { width: "4px", height: "4px", borderRadius: "2px", background: "#cbd5e1" } }),
          h("div", { key: 2, style: { width: "4px", height: "4px", borderRadius: "2px", background: "#cbd5e1" } }),
        ]),
      ),
      h("div", { style: { width: "80px", height: "5px", borderRadius: "3px", background: "#94a3b8" } }),
      h(
        "div",
        { style: { display: "flex", gap: "6px", marginTop: "4px", flex: 1 } },
        h("div", {
          style: {
            flex: 1,
            borderRadius: "4px",
            background: "#f1f5f9",
            border: "1px dashed #cbd5e1",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          },
        }),
        h("div", {
          style: {
            flex: 1,
            borderRadius: "4px",
            background: "#f8fafc",
            border: "1px solid #e2e8f0",
          },
        }),
      ),
    ),
  );
}

// --- Main Design Gallery Component ---
function DesignGallery(props) {
  const { sessionId, t, setDraft } = props;
  const [data, setData] = useState({ phase: "loading", root: null, files: [], errorCode: null, errorMessage: null });
  const [openFile, setOpenFile] = useState(null);
  const [copied, setCopied] = useState(false);
  const [promptFilled, setPromptFilled] = useState(false);

  const reload = useCallback(() => {
    setData((prev) => ({ ...prev, phase: prev.phase === "ready" ? "ready" : "loading" }));
    fetch("/canvas/designs?sessionId=" + encodeURIComponent(sessionId), { headers: { accept: "application/json" } })
      .then((res) => res.json().catch(() => null))
      .then((body) => {
        if (body && body.ok) {
          setData({ phase: "ready", root: body.root, files: Array.isArray(body.files) ? body.files : [], errorCode: null, errorMessage: null });
        } else {
          setData({
            phase: "error",
            root: body && body.root ? body.root : null,
            files: [],
            errorCode: body && body.code ? body.code : "generic",
            errorMessage: body && body.error ? body.error : "",
          });
        }
      })
      .catch(() => setData({ phase: "error", root: null, files: [], errorCode: "network", errorMessage: "" }));
  }, [sessionId]);

  useEffect(() => {
    reload();
  }, [reload]);

  // Click-to-ask bridge: canvas viewer iframe posts node:selected messages
  useEffect(() => {
    function onMessage(event) {
      const msg = event.data;
      if (!nodeSelectedMessageOk(msg)) return;
      const payload = msg.payload;
      const label = payload.nodeLabel ? "「" + payload.nodeLabel + "」" : "";
      const id = payload.nodeId ? " (ID: " + payload.nodeId + ")" : "";
      const kind = payload.nodeType && payload.nodeType !== "frame" ? "(" + payload.nodeType + ")" : "";
      const text = t("draft.prefix", { kind, label, id });
      if (typeof setDraft === "function") {
        try {
          setDraft(text);
        } catch (err) {
          console.error("design-view: setDraft failed", err);
        }
      }
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [setDraft, t]);

  const copyPath = () => {
    if (!data.root) return;
    navigator.clipboard.writeText(data.root).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handleFillSamplePrompt = () => {
    const promptText = t("gallery.tipSample");
    if (typeof setDraft === "function") {
      try {
        setDraft(promptText);
        setPromptFilled(true);
        setTimeout(() => setPromptFilled(false), 2500);
      } catch (err) {
        console.error("design-view: setDraft failed", err);
      }
    }
  };

  // --- 1. Canvas View when a file is open ---
  if (openFile) {
    return h(
      "div",
      { style: { display: "flex", flexDirection: "column", height: "100%", minHeight: 0, background: "var(--dsw-alias-bg-base, #ffffff)" } },
      // Top bar
      h(
        "div",
        {
          style: {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "10px 16px",
            borderBottom: "1px solid var(--dsw-alias-border-l2, #e2e8f0)",
            background: "var(--dsw-alias-bg-layer-1, #ffffff)",
            flex: "none",
            gap: "12px",
          },
        },
        h(
          "div",
          { style: { display: "flex", alignItems: "center", gap: "12px", minWidth: 0 } },
          h(
            "button",
            {
              onClick: () => setOpenFile(null),
              style: {
                display: "inline-flex",
                alignItems: "center",
                gap: "6px",
                border: "1px solid var(--dsw-alias-border-l2, #e2e8f0)",
                background: "var(--dsw-alias-bg-base, #ffffff)",
                color: "var(--dsw-alias-label-primary, #1e293b)",
                cursor: "pointer",
                fontSize: "13px",
                fontWeight: 500,
                padding: "6px 12px",
                borderRadius: "8px",
                transition: "all 0.15s ease",
              },
            },
            t("gallery.back"),
          ),
          h("div", { style: { height: "16px", width: "1px", background: "var(--dsw-alias-border-l2, #e2e8f0)" } }),
          h(
            "div",
            { style: { display: "flex", alignItems: "center", gap: "8px", minWidth: 0 } },
            h("span", { style: { fontSize: "14px", fontWeight: 600, color: "var(--dsw-alias-label-primary, #0f172a)" } }, openFile.name),
            h("span", { style: { fontSize: "11px", color: "var(--dsw-alias-label-tertiary, #64748b)", background: "var(--dsw-alias-bg-module-platform, #f1f5f9)", padding: "2px 6px", borderRadius: "4px" } }, ".html"),
          ),
        ),
        h(
          "div",
          { style: { display: "flex", alignItems: "center", gap: "10px" } },
          h(
            "a",
            {
              href: openFile.url,
              target: "_blank",
              rel: "noreferrer",
              style: {
                display: "inline-flex",
                alignItems: "center",
                gap: "4px",
                fontSize: "12px",
                color: "var(--dsw-alias-label-secondary, #475569)",
                textDecoration: "none",
                padding: "5px 10px",
                borderRadius: "6px",
                border: "1px solid var(--dsw-alias-border-l2, #e2e8f0)",
              },
            },
            h(IconExternalLink, { size: 12 }),
            t("gallery.openNewTab"),
          ),
        ),
      ),
      // Canvas Iframe
      h("iframe", {
        key: openFile.id,
        style: { flex: 1, border: "none", width: "100%", height: "100%", background: "#ffffff" },
        src: openFile.url,
        title: openFile.name,
      }),
    );
  }

  // --- 2. Empty / Guide State (docs/designs not created or empty) ---
  const isMissingDir = data.phase === "error" && (data.errorCode === "designs-dir-missing" || data.errorCode === "no-root");
  const isEmptyDir = data.phase === "ready" && data.files.length === 0;

  if (isMissingDir || isEmptyDir) {
    return h(
      "div",
      {
        style: {
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "flex-start",
          height: "100%",
          padding: "48px 20px",
          overflowY: "auto",
          background: "linear-gradient(180deg, var(--dsw-alias-bg-base, #ffffff) 0%, var(--dsw-alias-bg-module-platform, #f8fafc) 100%)",
        },
      },
      h(
        "div",
        {
          style: {
            maxWidth: "540px",
            width: "100%",
            background: "var(--dsw-alias-bg-layer-1, #ffffff)",
            border: "1px solid var(--dsw-alias-border-l2, rgba(0,0,0,0.08))",
            borderRadius: "20px",
            boxShadow: "0 12px 36px -4px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.04)",
            padding: "36px 32px",
            display: "flex",
            flexDirection: "column",
            alignItems: "stretch",
          },
        },
        // Header with Icon & Title
        h(
          "div",
          { style: { display: "flex", alignItems: "center", gap: "16px", marginBottom: "16px" } },
          h(
            "div",
            {
              style: {
                width: "48px",
                height: "48px",
                borderRadius: "14px",
                background: "linear-gradient(135deg, rgba(65, 118, 230, 0.12) 0%, rgba(103, 158, 254, 0.22) 100%)",
                border: "1px solid rgba(65, 118, 230, 0.2)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "var(--dsw-static-deepseek-500, #4176e6)",
                flex: "none",
              },
            },
            h(IconLayout, { size: 26 }),
          ),
          h(
            "div",
            { style: { display: "flex", flexDirection: "column", gap: "2px" } },
            h("h2", { style: { fontSize: "18px", fontWeight: 700, color: "var(--dsw-alias-label-primary, #0f172a)", margin: 0 } }, t("gallery.emptyTitle")),
            h("p", { style: { fontSize: "13px", color: "var(--dsw-alias-label-secondary, #64748b)", margin: 0 } }, t("gallery.emptyDesc")),
          ),
        ),
        // Path Box
        data.root &&
          h(
            "div",
            {
              style: {
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                background: "var(--dsw-alias-bg-module-platform, #f8fafc)",
                border: "1px solid var(--dsw-alias-border-l1, #e2e8f0)",
                borderRadius: "10px",
                padding: "8px 12px",
                margin: "8px 0 20px 0",
                gap: "8px",
              },
            },
            h(
              "div",
              { style: { display: "flex", alignItems: "center", gap: "8px", minWidth: 0 } },
              h(IconFolder, { size: 14, style: { color: "var(--dsw-alias-label-tertiary, #94a3b8)", flex: "none" } }),
              h("span", { style: { fontSize: "12px", color: "var(--dsw-alias-label-secondary, #475569)", fontFamily: "monospace", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, data.root),
            ),
            h(
              "button",
              {
                onClick: copyPath,
                style: {
                  border: "none",
                  background: "transparent",
                  color: copied ? "var(--dsw-static-green-500, #22c55e)" : "var(--dsw-alias-label-tertiary, #64748b)",
                  cursor: "pointer",
                  fontSize: "12px",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "4px",
                  padding: "4px 8px",
                  borderRadius: "6px",
                  flex: "none",
                  fontWeight: 500,
                },
              },
              copied ? h(IconCheck, { size: 12 }) : h(IconCopy, { size: 12 }),
              copied ? t("gallery.copied") : t("gallery.copyPath"),
            ),
          ),
        // Single focused Tip Card: Chat Design
        h(
          "div",
          {
            style: {
              background: "rgba(59, 130, 246, 0.04)",
              border: "1px solid rgba(59, 130, 246, 0.14)",
              borderRadius: "12px",
              padding: "16px",
              display: "flex",
              flexDirection: "column",
              gap: "10px",
              marginBottom: "24px",
            },
          },
          h(
            "div",
            { style: { display: "flex", alignItems: "center", gap: "8px" } },
            h(IconMessage, { size: 16, style: { color: "var(--dsw-static-deepseek-500, #4176e6)" } }),
            h("span", { style: { fontSize: "13px", fontWeight: 600, color: "var(--dsw-alias-label-primary, #0f172a)" } }, t("gallery.tipTitle")),
          ),
          h("p", { style: { fontSize: "12px", color: "var(--dsw-alias-label-secondary, #475569)", margin: 0, lineHeight: "1.6" } }, t("gallery.tipDesc")),
          // Sample Prompt Pill
          h(
            "div",
            {
              style: {
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                background: "#ffffff",
                border: "1px solid rgba(59, 130, 246, 0.2)",
                borderRadius: "8px",
                padding: "8px 12px",
                marginTop: "4px",
                gap: "8px",
              },
            },
            h("span", { style: { fontSize: "12px", color: "var(--dsw-static-deepseek-500, #3b82f6)", fontStyle: "italic", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, "“" + t("gallery.tipSample") + "”"),
            h(
              "button",
              {
                onClick: handleFillSamplePrompt,
                style: {
                  border: "none",
                  background: promptFilled ? "var(--dsw-static-green-500, #22c55e)" : "var(--dsw-static-deepseek-500, #4176e6)",
                  color: "#ffffff",
                  borderRadius: "6px",
                  padding: "4px 10px",
                  fontSize: "11px",
                  fontWeight: 500,
                  cursor: "pointer",
                  flex: "none",
                  transition: "all 0.15s ease",
                },
              },
              promptFilled ? t("gallery.promptFilled") : t("gallery.useSamplePrompt"),
            ),
          ),
        ),
        // Refresh Button
        h(
          "div",
          { style: { display: "flex", justifyContent: "center" } },
          h(
            "button",
            {
              onClick: reload,
              style: {
                display: "inline-flex",
                alignItems: "center",
                gap: "6px",
                border: "1px solid var(--dsw-alias-border-l2, #cbd5e1)",
                background: "var(--dsw-alias-bg-base, #ffffff)",
                color: "var(--dsw-alias-label-primary, #0f172a)",
                borderRadius: "8px",
                padding: "8px 20px",
                fontSize: "13px",
                fontWeight: 500,
                cursor: "pointer",
                boxShadow: "0 1px 2px rgba(0, 0, 0, 0.04)",
              },
            },
            h(IconRefresh, { size: 14 }),
            t("gallery.refresh"),
          ),
        ),
      ),
    );
  }

  // --- 3. Normal Gallery Card Grid (files exist) ---
  return h(
    "div",
    {
      style: {
        display: "flex",
        flexDirection: "column",
        height: "100%",
        minHeight: 0,
        background: "var(--dsw-alias-bg-base, #ffffff)",
      },
    },
    // Gallery Header Toolbar
    h(
      "div",
      {
        style: {
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "14px 24px",
          borderBottom: "1px solid var(--dsw-alias-border-l2, #e2e8f0)",
          background: "var(--dsw-alias-bg-layer-1, #ffffff)",
          flex: "none",
        },
      },
      h(
        "div",
        { style: { display: "flex", alignItems: "center", gap: "12px" } },
        h("div", { style: { display: "flex", alignItems: "center", gap: "8px" } }, [
          h("h1", { key: 1, style: { fontSize: "16px", fontWeight: 700, color: "var(--dsw-alias-label-primary, #0f172a)", margin: 0 } }, t("gallery.title")),
          h("span", {
            key: 2,
            style: {
              fontSize: "12px",
              fontWeight: 500,
              color: "var(--dsw-static-deepseek-500, #4176e6)",
              background: "rgba(65, 118, 230, 0.08)",
              padding: "2px 8px",
              borderRadius: "999px",
            },
          }, t("gallery.count", { count: data.files.length })),
        ]),
        data.root &&
          h(
            "button",
            {
              onClick: copyPath,
              title: t("gallery.copyPath"),
              style: {
                display: "inline-flex",
                alignItems: "center",
                gap: "5px",
                border: "1px solid var(--dsw-alias-border-l1, #e2e8f0)",
                background: "var(--dsw-alias-bg-module-platform, #f8fafc)",
                color: copied ? "var(--dsw-static-green-500, #22c55e)" : "var(--dsw-alias-label-secondary, #64748b)",
                cursor: "pointer",
                fontSize: "11px",
                padding: "3px 8px",
                borderRadius: "6px",
              },
            },
            copied ? h(IconCheck, { size: 11 }) : h(IconFolder, { size: 11 }),
            copied ? t("gallery.copied") : "docs/designs",
          ),
      ),
      h(
        "div",
        { style: { display: "flex", alignItems: "center", gap: "10px" } },
        h(
          "button",
          {
            onClick: reload,
            title: t("gallery.refresh"),
            style: {
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "6px",
              padding: "6px 12px",
              border: "1px solid var(--dsw-alias-border-l2, #e2e8f0)",
              background: "var(--dsw-alias-bg-base, #ffffff)",
              color: "var(--dsw-alias-label-secondary, #64748b)",
              borderRadius: "8px",
              cursor: "pointer",
              fontSize: "13px",
            },
          },
          h(IconRefresh, { size: 14 }),
          t("gallery.refresh"),
        ),
      ),
    ),
    // Card Grid Area
    h(
      "div",
      {
        style: {
          flex: 1,
          overflowY: "auto",
          padding: "24px",
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
          gap: "20px",
          alignContent: "start",
        },
      },
      data.files.map((file) => {
        const title = designTabLabel(file.name);
        return h(
          "div",
          {
            key: file.id,
            onClick: () =>
              setOpenFile({
                id: file.id,
                name: title,
                url: "/canvas/open?file=" + encodeURIComponent(file.id),
              }),
            style: {
              background: "var(--dsw-alias-bg-base, #ffffff)",
              border: "1px solid var(--dsw-alias-border-l2, #e2e8f0)",
              borderRadius: "16px",
              boxShadow: "0 2px 8px rgba(0, 0, 0, 0.04), 0 1px 2px rgba(0, 0, 0, 0.02)",
              cursor: "pointer",
              overflow: "hidden",
              display: "flex",
              flexDirection: "column",
              transition: "all 0.2s cubic-bezier(0.16, 1, 0.3, 1)",
            },
            onMouseEnter: (e) => {
              e.currentTarget.style.transform = "translateY(-3px)";
              e.currentTarget.style.boxShadow = "0 12px 28px -4px rgba(0, 0, 0, 0.09)";
              e.currentTarget.style.borderColor = "var(--dsw-static-deepseek-400, #679efe)";
            },
            onMouseLeave: (e) => {
              e.currentTarget.style.transform = "translateY(0)";
              e.currentTarget.style.boxShadow = "0 2px 8px rgba(0, 0, 0, 0.04), 0 1px 2px rgba(0, 0, 0, 0.02)";
              e.currentTarget.style.borderColor = "var(--dsw-alias-border-l2, #e2e8f0)";
            },
          },
          // Preview Artwork
          h("div", { style: { height: "130px", width: "100%", position: "relative" } }, [
            h(CardMockupArt, { key: 1 }),
            h(
              "div",
              {
                key: 2,
                style: {
                  position: "absolute",
                  top: "10px",
                  left: "10px",
                  background: "rgba(15, 23, 42, 0.7)",
                  backdropFilter: "blur(4px)",
                  color: "#ffffff",
                  fontSize: "10px",
                  fontWeight: 600,
                  padding: "2px 6px",
                  borderRadius: "4px",
                  letterSpacing: "0.5px",
                },
              },
              "CANVAS",
            ),
          ]),
          // Body Meta
          h(
            "div",
            { style: { padding: "16px", display: "flex", flexDirection: "column", gap: "8px" } },
            h("div", { style: { fontSize: "15px", fontWeight: 600, color: "var(--dsw-alias-label-primary, #0f172a)", lineHeight: "1.3" } }, title),
            h(
              "div",
              { style: { display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "4px" } },
              h(
                "span",
                {
                  style: {
                    fontSize: "12px",
                    color: "var(--dsw-alias-label-secondary, #64748b)",
                    background: "var(--dsw-alias-bg-module-platform, #f1f5f9)",
                    padding: "3px 8px",
                    borderRadius: "6px",
                    fontWeight: 500,
                  },
                },
                t("gallery.meta", { pages: file.pageCount ?? 0, frames: file.frameCount ?? 0 }),
              ),
              h("span", { style: { fontSize: "12px", color: "var(--dsw-static-deepseek-500, #4176e6)", fontWeight: 500 } }, t("gallery.openInCanvas") + " →"),
            ),
          ),
        );
      }),
    ),
  );
}

// --- cordis client plugin face ---
const inject = ["slots", "sessions", "locale"];

function apply(ctx) {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), "dsh-canvas: locale dictionaries");
  const t = ctx.locale.bind(NS);
  ctx.slots.inject(
    "conversation.view",
    () =>
      ctx.slots.register(
        {
          name: "conversation.view",
          id: GALLERY_TAB_ID,
          order: GALLERY_TAB_ORDER,
          locale: NS,
          label: () => t("tab.label"),
          inject: (sessionId) => ({
            sessionId,
            t,
            setDraft: (text) => {
              const sessions = ctx.sessions;
              if (!sessions || typeof sessions.provideInfo !== "function") return;
              const info = sessions.provideInfo(sessionId);
              const actions = info && info.props ? info.props.inputActions : undefined;
              if (actions && typeof actions.setDraft === "function") actions.setDraft(text);
            },
          }),
        },
        DesignGallery,
      ),
  );
}
