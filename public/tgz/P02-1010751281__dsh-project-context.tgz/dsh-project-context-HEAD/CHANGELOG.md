# 更新日志

本仓库以 **`v0.1.0`** 作为首个发布（`package.json` 为 `0.1.0`）。更早的 `v0.1.0`/`v0.2.0`
标签因对应提交上的代码有误，已在本地与远端一并删除并作废。

- **未发布**：`v0.4.3` 之后的变更按时间倒序写在本文件里；发版时整段搬进 `docs/changelog/<version>.md`，
  本文件重新开一个空小节。
- **已发布**：每个版本一份 `docs/changelog/<version>.md`，本文件末尾的「版本目录」是唯一索引。
- 标注「修复」的条目都伴随一条**变异校验过**的回归测试（把修复改回原样，测试必须失败）。

### 未发布（`v0.4.3` 之后）

**project-memory（`record_memory` 参数 JSON 非法时，退一次无工具重试）**

- 现象：`errors.log` 记 `plugin model call failed (MALFORMED_RESPONSE): Tool call "record_memory":
  Expected ',' or ']' …`，9 天 4 次（11-11×2、11-18、11-20）。该次 pass 整次没写盘（journal 逐字节
  未变），因为 `callWithToolsFallback` 只对请求形状类错误码（`INVALID_REQUEST` / `HTTP_400` /
  `HTTP_413`）花掉那次「无工具重试」。
- 判定：这不是请求形状拒绝——路由**接受了** `tools`、回答不可用；而提示词本来就要求「工具不可用时
  给 `memory_markdown` + `context`」，解析器还能从坏的外层 JSON 里救回完整记忆串，所以同一次无工具
  重试就是最便宜的恢复。
- 改法：`callWithToolsFallback` 增加可选的 `ToolsFallbackOptions`（`extraCodes` + `onRetry`），
  **只有记忆整理**这一个调用方声明 `MALFORMED_RESPONSE`；共享允许集与 autolearn 策略未改。重试前
  照旧置 `toolsDisabled`，`toolsAttempted` 的粘滞语义未动，输入/会话/effort/token 预算完全相同，
  只去掉 `tools`。
- 日志有界：只记一行 `the model's record_memory reply was unusable (CODE); the pass was retried once
  without tools`——**不回显 message**，因为真实的 message 里带着模型生成的整段记忆参数。
- 已知代价：`MALFORMED_RESPONSE` 与「SSE JSON 非法」共用同一 code、没有更细的子类型
  （`llm-pi-ai/src/stream.ts:228` 构造，只带 code + message），因此这次重试偶尔会花在无关的
  不可用回复上。
- 验证：`pnpm test` **695 → 697**；变异轮——去掉 `extraCodes` 的接受分支后两条新用例各自变红
  （含「tier C 仍然拒绝、journal 逐字节不变」那条），还原后全绿；`lib/` 重建，`lib/client.js`
  37,349 B 不变。
- 生效条件：宿主代码，需重启。

**project-memory（`/memory` 回执改为分段多行）**

- 裸 `/memory` 回执原本是 10 个事实用 ` · ` 连成的**单行**；Batch V 加入 `stale N` 子句后实测 **416 字符**，
  终端与界面里都放不下一行。现在按事实组分段，组内仍用 ` · ` 分隔。
- **根因不是单行，是折叠**：客户端把命令回执渲染成 `GenericCommandCard`——折叠态是
  `white-space: nowrap` + 省略号的一行摘要，**内容是把整段回执压平**（换行当空白），正文
  （`<pre>`，`pre-wrap`）只在 `text.includes("\n")` 时才可展开，且默认收起。因此
  **单行回执永远无法展开**，416 字符只能被裁掉；换行本身也是展开的前提。强模型（`gpt-6.2-astra`）
  的独立评审复核了整条链路（`GenericCommandCard.tsx:30/40/51`、`DisclosureRow.tsx:64/92`、
  `command.ts:65`），并纠正一处措辞：可见的是**压平文本的前缀**，不是「只有第一行」。
- 因此首行必须是**度量**而不是路径：绝对路径会把「长度/上限、四节条目数、stale」顶出裁剪区。
  现在首行是 `Memory: <len>/<cap> chars (<pct>%) · <四节条目数>`（实测 96 字符），
  来源路径改为独占一行 `source <path>` 且仅当它不是 journal 本身时出现（journal 行已点名该文件）。
- **cap 诊断分成两态**（评审复现的真缺陷）：`isMemoryTruncated` 只证明文档还带着**某次旧 cap**
  写下的标记行，标记随每次渲染被带下去；真正的拒绝条件是本次读的隐藏字符数（`consolidate.ts` 的
  `readCapHidden` = `cappedDroppedChars`）。原实现只看标记就断言「this read is cut」并预告
  `read-capped-refused`——74 字符的文档在 52,000 上限下也会这么报。现在 `cappedDroppedChars > 0`
  才出警告；只有标记时出一条 `Note:`（旧 cap 的标记仍在，但本次读没扣下任何字符），不预告拒绝。
- capped 警告原本追加在首行末尾（本身是一句 200 字符的说明），现在独占一行。
- 事实与措辞一字未改，只改换行、行序与 cap 两态；相应更新 8 处依赖原布局的断言
  （`test/logic.test.mjs` 6 处、`test/memory-status.test.mjs` 2 处），其余断言都是独立正则，未改动。
- 验证：`pnpm test` **695 通过 / 0 失败**；`lib/` 重建后 `lib/client.js` 37,349 B 不变；
  用 `loadMemory` + `memoryStatusReply` 渲染真实项目，回执 **346 字符 / 5 行 / 首行 96**。
- 生效条件：宿主代码，需重启。

**project-memory（Batch V：记忆条目的内容漂移）**

- 每条记忆条目现在可以把**它引用的仓库文件**绑进 `entries.json` 的 `sources`（路径 → sha256 前 16 位），
  `/memory` 与整理回执会报 `stale N`：文件在条目写入后被改过。这是锚点校验原本看不到的第三类失效——
  路径还在、行号还够、事实已经变了。
- **只标不删**：`stale` 绝不删除条目、不改写文档、不写 tombstone；`missing` 仍交给既有 `anchor-drift`
  退休通道，`unverifiable`（读不了 / 仓外 / 自引用 / 生成物）单独计数，三者绝不折叠成 `fresh`。
- **绑定只写一次**（first-wins）：条目 id 是正文哈希，模型重写该事实＝新 id＝新基线；未重写的条目
  即使经过多轮 pass 也保持原基线，否则「复制一遍就变干净」会让这个特性变成同义反复。
- 只绑**仓库相对路径**的普通文件，排除 `.agents/memory/`（本 pass 自己会改写）、`lib/`（构建产物，
  实测本仓库有 4 条引用 `lib/client.js`，不排除会让每次 `pnpm build` 都产生假 stale）、本地产物
  （`errors.log` 等）与仓外绝对路径。
- 核心/外层分离：`anchors.ts`（纯词法规则，与退休通道共用，各消费点只保留自己的过滤）、
  `staleness.ts`（四态判定与回执措辞，零 IO）、`entry-sidecar.ts`（`entries.json` 的唯一所有者，
  read-modify-write 在 `withMemoryLock` 内，未知键原样保留）、`staleness-source.ts`（唯一知道
  「路径在这台机器上是什么」的文件）。
- 验证：`pnpm test` **682 → 695**（+13）；变异轮 6/6 各自只红其具名用例（刷新基线→「第二轮不清除」
  变红；绑生成物→自引用/生成物用例变红；missing 当 stale→三态用例变红；丢弃未知键→升级用例变红；
  不透明文档清空绑定→opaque 用例变红；未测量打印 0→措辞用例变红）。`lib/` 重建，`lib/client.js`
  尺寸不变。
- 生效条件：宿主代码，需重启。

**project-handoff（交接给用户的说明：丢了多少、留在哪）**

- 交接后的新会话，其第一条消息（种子）现在带一段**给用户的说明**，排在 `Handoff from session …` 之后：这是从哪个会话续接的、带过来最近多少条消息（约多少 token）、多少个文件的清单、是否还有未答问题、**更早多少条消息不在本会话里**、归档原文的绝对路径，以及旧会话仍可从侧栏「全部对话（显示已归档）」打开。
- 数字来自切分本身：`handoffSplit` 新增 `olderMessages`（与 `tailMessages` 同一次切分计数），种子渲染不重算；`carriedTokens` 是尾料字符 / 4 的估值，文案写「约」。旧会话的 `older` 字符串经过 `truncateMiddle`，不能用来回答「丢了多少」，所以说明里引用的是条数而不是被截断后的字符量。
- 位置是硬约束：`isHandoffContinuationText` 靠 `Handoff from session` / `从会话 ` 开头识别生成消息，说明只能排在其后，否则种子会被计成用户发言（轮数、标题、自动学习闸门全部连锁）。
- 验证：`pnpm test` **675 → 682**（+7：说明的每个形状、零尾料、语言、`performHandoff` 真实接线、`runManual` 自己切分的那条分支）。变异轮 3 个有效变异：不渲染说明 → 6 条红；`olderMessages` 恒 0 → 2 条红；`openQuestion` 恒 false → 1 条红（正好是断言未答问题的那条）。
- 生效条件：宿主代码，需重启。

**project-context（W1-A：`/context find` 只读检索）**

- 新增 `/context find <query>`：检索 `MEMORY.md` 条目、`CONTEXT.md`、`tasks/*.md`、每个会话的 `meta.json`，以及最近 20 个会话的 `HANDOFF.md` / `session.md`；输出 Top 8，带 `path:line` 与原文行，整块 8 KB 预算，超额写「还有 N 条」。
- 排序与匹配是粗而可复核的：整串 3 / 全词 2 / 任一词 1，同分新到旧；英文**按词边界**（`cat` 不命中 `catalog`——这一条落地时先写错成「子串命中优先」，被本批用例打红后改的），CJK 用相邻 bigram 兜底。摘要保留原文的 Markdown 标记：回执引的是文件里的那一行，不是对它的转述。
- 只读是机械钉住的：用例在查询前后逐文件比字节（`treeSnapshot`），任何缓存文件、journal 行或索引写入都会让它红。
- 同一文档最多 3 条命中：在本仓库上实测，`handoff threshold` 命中 5,498 行、226 份文档，未设限时回执是同一个 `session.md` 的八行；限额后记忆条目回到前面，被留下的行仍计入「还有 N 条」。
- 核心/外层分离：`search.ts`（纯）＋ `search-source.ts`（唯一知道 `.agents/memory` 布局的地方）。
- 验证：`pnpm typecheck` 0、`pnpm test` **632 → 644**（+12）、`pnpm build` ok、`lib/client.js` 不变。

**project-context（W2-F：`/context task` 列表补数字；W3：`/context export`）**

- 任务列表行从 `slug · 状态 · 标题` 扩为再带 `sessions N · open todos M · last seen <date>`：会话数来自 `session-logs/*/meta.json` 的 `task` 绑定，未完成项来自任务文档的 `- [todo]` 行，最近活动取两者较新者。核心 `task-usage.ts` 纯函数，读盘在 `task-usage-source.ts`。
- 新增 `/context export [--write]`：打印 `AGENTS.md` 兼容的四节摘要（Project / Invariants / Pitfalls + 指针），`--write` 只原子写 `.agents/memory/EXPORT.md`；**永不改项目自己的 `AGENTS.md`**，重复导出字节稳定。
- 验证同上批：同一分支、同一轮门禁。

**project-memory（W1-B：裸 `/memory` 报可复算的现状）**

- 裸 `/memory` 现在报：字符数 / `maxMemoryChars`（含百分比）、四节条目数、journal 行数与字节、备份数、归档会话数、`errors.log` 行数。四节条目经 `sectionsFromMarkdown` 解析，**文档不是四节形状时写「无法解析」而不是 0**；capped / damaged / poisoned / unreadable 的既有警告语义不变。
- 不报「上一次整理的结果」：该值没有持久化，编一个出来就是伪造证据——这一条同时写进了 `docs/behavior.md`。
- 核心 `status-report.ts`（DTO → 字符串）＋ `status-source.ts`（读盘并归一）；`memoryStatusReply` 只做组合。改动波及 `test/logic.test.mjs` 里既有的精确字符串断言（同一批更新）。
- 验证：`pnpm test` **+10**（`test/memory-status.test.mjs` 覆盖空 / 有 journal / 有备份 / 有归档四态与 capped 警告），合并后全量 **674**。

**project-handoff（W2-D：交接回执补种子的三个数字）**

- `/handoff status` 对**本进程刚创建**的续接会话多报一行：尾料消息数、文件清单条数、未答问题的处置（`answered` / `deferred` / `nothing`）。
- 数字不重算：`tailMessages` 在切分处计数（`handoffSplit` 的产物），文件数从 `HANDOFF.md` 与种子共用的索引字符串里数，问题处置来自与 `handoffCarry` 同一次 `readSessionInputs`。空尾料打印 `0` 而不是省略。
- 回执记在**子会话** id 下：被替换的父会话只保留 `already handed off`，不会显示别人的数字；录用发生在种子与文档落地之后，所以被拒绝或瞬态失败的尝试不留回执。进程内存，与 `handedOff` 同性质，`HANDOFF.md` 才是持久副本。
- 验证：`pnpm test` **632 → 645**（+13）；其中一个用例最初写错了预期（把「defer」当成 reject 的 `HandoffDeferred`，实际是静默 skip），按实现改正的是用例而不是代码。

**project-autolearn（W2-E：采纳证据与机械冲突检查）**

- 采纳（`/autolearn approve`）在晋升的 `SKILL.md` 写可选 frontmatter：`derived_from: autolearn` + 被核对的 session id 列表；正文与既有解析不变，老的手写技能（无此段）照旧可用，`autolearn-generated` 标记的语义一个字节都没动。
- `/autolearn list` 与采纳回执显示证据条数与 id 的显著前缀（先剥掉 `session-`，否则每条都印同样的八个字符）。
- 机械冲突检查：候选正文里的反引号 token（路径 / `path:line` / 命令）与既有技能、`MEMORY.md` 比对，重叠即报；只报不拦、不做语义判断、不调模型——假阴性的代价只是少一条建议，假阳性会让读者学会忽略这份报告。
- 核心 `evidence.ts`（纯）＋ `evidence-source.ts`（skills 目录布局）。
- 验证：`pnpm test` **632 → 639**（+7）。

**repo（W1-C 收尾：压缩折叠与 dsh 事件 shim 解耦；SH-10 登记）**

- `src/project-handoff/compaction.ts` 现在只认 `CompactionRecord` DTO 并折叠 / 渲染；`compaction-events.ts` 是唯一知道 `compaction/*` 四种宿主形状的文件（`SH-10`）。宿主形状变了只改后者，核心不再需要会话夹具即可测。
- `docs/harness/integration.md`：`compaction/*` 从「不接（无可用钩子）」改为「不接钩子；只读日志」，并登记 `SH-10` 与拆除条件（把 `@deepseek-ai/dsh-compaction` 加为 type-only devDependency，照 `SH-1` 的判据）。
- `docs/compaction-vs-handoff.md` §6 的探针清单换成**源码级结论**：插件能拿到 `Agent` 并直接调 `compactNow`（`compaction-basic` 自己调 `runMaintenance`），但 `turn/end` 那一刻驱动器仍持有 agent（`busy`），可行时机是紧接着的 `agent/status = idle` 或命令处理器；**实测仍未做**。§9 追加同日裁定：**不实现自动兜底**（推翻「交接零模型调用」的契约、在被 defer 的最不该时刻改写视图、要六面新键与一条新兼容面、未实测且有退休竞态），重开条件写在那一节。
- 验证：`pnpm test` **627 → 632**（+5：核心与 shim 分开测），合并后全量 **674**。
- 合并后的跨批次变异轮（4 个有效变异，均从 `/tmp` 哈希副本恢复并重建）：把词边界换回子串 → 只红 `cat`/`catalog` 一条；把 `unparseable` 改成 0 条 → 只红不透明文档一条；把回执键从子会话换成父会话 → 红掉子会话键那一组（4 条，同一契约）；让 frontmatter 永不写入 → 红掉证据写入那一组（3 条，同一契约）。另有一个变异因 `TS6133`（删掉词边界后 `containsWord` 无人引用）编译失败，按纪律剔除后改写重跑。

**project-handoff（批次 W1-C：`/handoff status` 报宿主的压缩历史）**

- 新增 `src/project-handoff/compaction.ts`：从会话的 durable 日志只读折叠 `compaction/summary|end|prune`（`start` 只用于认类型），得到 `summarized`/`pruned`/`failed`/`reclaimedTokens` 与最近一次成功/失败。标题数字是 `summarized + pruned`——只有真正回收了上下文的动作才算一次压缩；成功的 `end` 不再重复计一遍，带 `error` 的 `end` 单列 `failed` 且不计入。
- 事件类型由 `@deepseek-ai/dsh-compaction/types` 声明，本包**不**依赖它（那会把压缩服务拉进一个以「不碰压缩」为边界的插件），所以按 `session-index.ts` 读 `session/title` 的方式结构化读取。认识前缀但不认识的 `compaction/*` 类型、缺 `compactionId` 的 `summary`/`end`、非数组事件源一律 `unavailable`（`malformed`/`unreadable`），**不当 0**：未来宿主加一种压缩事件时，静默少数比具名缺口更糟。
- `/handoff status` 新增一行，紧跟占用组（`context`/阈值行）之后，且在路由或 meter 不可用时**仍然输出**——那正是用户打开回执的场景。两种语言的措辞与规格见 `docs/compaction-vs-handoff.md` §3–4（该文状态已从「规格」改为「第 3、4 节已落地」）。
- 约束：不注册压缩后端、不碰 `agent/pre-step`/`ctx.compaction`、不改阈值、不写盘、不新增配置键；只读 `session.snapshotEvents()`。
- 验证：`pnpm typecheck` 0、`pnpm test` **617 → 627**（`test/handoff-compaction.test.mjs` 10 条）、`pnpm build` ok、`lib/client.js` 不变（37349）。变异轮 4 个有效变异各自只红目标用例（删 id 去重 → 重放用例；未知类型静默跳过 → 防御用例；缺失金额读作 0 → 字段缺失用例；把行挪回「有路由才输出」→ 无 meter 用例）；第 5 个变异因 `TS2339` 编译失败，按纪律不计入。
- 生效条件：宿主代码，需重启。

**project-memory（批次 Z8f：条目 id 由四位十六进制压到三位）**

- 变更（用户 2026-11-12 决定）：`MEMORY.md` 条目尾标从 `（29f8）` 缩到 `（29f）`，每条省 1 个字符——本机 146 条的文档因此多出 146 字符余量（压到 44,908/45,000 时只剩 92）。id 空间从 65536 降到 4096，派生方式没变（正文 sha256 前缀），同一文档内的碰撞仍由既有盐循环解决：碰撞只让后一个条目换一个加盐 id，绝不会出现两条同 id。
- 迁移（关键）：旧的四位 id **按截断迁移**，不重新派生——派生从未变过，截断后的 id 就是同一事实的身份，所以 `entries.json` 记的首次见到日期继续适用，不会把每条年龄重置成今天。`readEntryDatesRaw` 把四位键发布成三位键（同一截断撞车取更早日期），并在下次写入时只落三位键；`stripEntryTid` 同时剥三/四位尾标，迁移不会留下两个 id；被 `supersedes:` 点名的旧四位目标也能解析到迁移后的 id（否则声明被消费而目标存活，是一次静默空转）。
- 未迁移窗口：文档仍带四位 id 时做 pass 也安全——回复里的四位 `supersedes:` 目标照旧生效，条目在写入时迁移。
- 影响面：`TID_MARKER` / `LEGACY_TID_MARKER` / `TID_TAIL` / `SUPERSEDES_MARKER` / `ENTRY_ID`，`tidFor` 的宽度与 `TID_STAMP_CHARS`（6 → 5，部分盖章的预算按新宽度算），以及模型侧规则 `MEMORY_ENTRY_ID_RULE` 的示例（`（4f2a）` → `（4f2）`）。
- 验证：`pnpm typecheck` 0、`pnpm test` **613 → 617**（+4：截断迁移、截断撞车重铸、日期侧车归一、旧四位 `supersedes:` 目标解析），`pnpm build` ok、`lib/client.js` 不变（37349）。五个有效变异各自只红到命名用例：宽度改回四位 → 迁移与预算用例；删掉截断继承 → 迁移用例；侧车保留四位键 → 侧车用例；`supersedes:` 不做截断回退 → 旧目标用例；`TID_STAMP_CHARS` 改回六 → near-cap 与优先级用例。（另两个变异先因 `TS6133` 编译失败，按纪律不计入，改写后重跑。）
- 生效条件：宿主代码，需重启。本机 desktop 的现有宿主仍是 613cb9f，重启前那次 `/memory update` 会继续写四位 id——不影响正确性，只是暂时拿不到这 146 字符。

**repo（清理：收窄导出面，只导出被别的模块读到的符号）**

- 去掉 **94 个**「只在本文件内使用、声明文件之外零引用」的 `export` 关键字，跨 `src/` 与 `client/` 共 40 个文件。判据是先统计每个导出声明在其**声明文件之外**（含 `test/` 与 `scripts/`）的出现次数，为 0 才收窄；这是上一批「六个零引用导出」的同一条用户裁定（「没用的、没有复用价值的就不要留」）的下一层——那些是彻底没人读，这些是出了本模块没人读。
- 保留的导出各有读者：四个插件入口的 `name` / `inject` / `apply` / `Config`（cordis loader 直接读），`client/index.ts` 整份（客户端 bundle 入口），以及被 `test/` 或别的模块 import 的符号。
- 行为零变化：这不是删代码，是把仅内部使用的东西从模块对外接口上摘下来。`tsc`（含 declaration emit）通过——被导出签名引用的非导出类型（如 `ConsolidateReport`）由 TS 作为本地 `type` 声明写进 `.d.ts`（`lib/project-memory/index.d.ts:68`），签名不变；`pnpm test` **613 通过 / 0 失败**；`pnpm build` ok；`lib/client.js` 不变（37349，类型收窄不进运行时 bundle），`lib/*.js` 只少了 `export` 关键字。
- 顺带核过、未收窄的：`docs/` 里 `ConsolidateReport` / `ThresholdRefusal` 的出现都是历史 changelog 与归档批次说明，或一条 triage 用的 grep 配方，没有「这是导出符号」的断言，所以不需要改文档。

**project-memory / shared（清理：删掉六个没有读者的导出）**

- 删除 `sectionsHaveEntries`（`retirement.ts`）、`TASK_STATUSES` 与 `TASK_MODES` 与 `hasTasks`（`tasks.ts`）、`TodoStatus`（`todo.ts`）、`modelOutputLimit`（`shared/model-call.ts`）。判据是全仓 `src`/`client`/`test`/`scripts` 的标识符引用数：这六个各自只有**定义那一处**，`export` 是它们唯一的露面方式（与上一批的 gate 机制同一条用户裁定，2026-11-11「没用的、没有复用价值的就不要留」）。删完后同一扫描归零。
- 每个都是真死，不是暂时没接：`sectionsHaveEntries`、`TASK_STATUSES`、`TASK_MODES`、`hasTasks`、`TodoStatus` 自引入提交起就没有调用者（`git log -S` 只回到各自的新增提交）；`modelOutputLimit` 最后一次有调用者是 `111b1a3` 的自动学习路径，`f2acbae` 把那个调用点改掉后它就成了只剩定义的导出。`TASK_MODES` 尤其值得删：`config.ts` 校验 `taskMode` 用的是自己的三条字面量比较，这个数组是**从未接上的第二份真值**，留着只会在有人「顺手用它」时和校验器分叉。
- 行为零变化：`tsc` 两个 `noUnusedLocals` 都没报（说明删的全是导出面，不是内部引用断链），`pnpm typecheck` 0、`pnpm test` **613 通过 / 0 失败**（无一条用例读它们）、`pnpm build` ok、`lib/` 重建确定。净减 69 行、增 0 行，`lib/client.js` 不变（37349）。
- 保留但核过的：`TaskStatus` / `TaskMode` / `TaskRecord` 等类型仍被多处引用；`shared/model-call.ts` 的 `resolveModelMetadata` 仍由 `consolidate.ts` 与自动学习的 `pass.ts` 各自调用（`modelOutputLimit` 只是它的一个没人用的薄包装）。

**client（清理：删掉没有使用者的模式 gate 机制）**

- 删除 `FieldGate`、`FieldRow.appliesWhen`、`rowVisible`、`FieldDraftState`，以及 `settings-card.tsx` 里为它维护的 `state.modes` 投影与 `effectiveMode` 方法。Z8e 把触发器的两行（开关 + 比例）合并成一行后**没有任何行再带 gate**，`rowVisible` 恒为 `true`；渲染改为直接 `section.rows.map(...)`。依据用户 2026-11-11 的裁定「没用的、没有复用价值的就不要留」。
- 顺带删除 `DEFAULT_THRESHOLD_RATIO`：生产代码没有读者（唯一用点是 `test/threshold-floor.test.mjs` 手算 `0.4 × 窗口`），而它的注释还宣称是「自适应之外的默认」——Z8e 之后默认是 `auto`，这个常量只会误导。测试改用字面量 `160_000`。
- 卡片行为不变：`test/card-render.test.mjs` 的「表的每个字段恰好上一页一次」仍以 `ROWS.length` 为判据，源码里已不存在任何隐藏路径；`lib/client.js` 38791 → 37349。
- 测试 **615 → 613**（−2：只为 gate 存在的两条用例 `the trigger row is never gated now that it is one key`、`a gate names a boolean row, or it can never be satisfied`），`pnpm typecheck` 0、`pnpm build` ok、`lib/` 重建确定。客户端改动一次硬刷新即生效，无需重启宿主（`DEFAULT_THRESHOLD_RATIO` 那个共享常量运行时无人读取）。

**project-handoff（批次 Z8e：阈值合成一个键，绝对 token 数也能写）**

- 变更（用户 2026-11-11 裁定）：`/handoff threshold` 与设置卡片合成**一个**事实、一个键 `handoffThreshold`，三种拼写 —— `auto`（守门rail 自己决定）、窗口比例（`0.1`–`0.95`，也接受 `40` / `40%`）、绝对 token 数（`400k` / `400000`）。旧的 `handoffThresholdAuto` + `handoffThresholdRatio` 退役，**不留别名**（与既往 rename 同一规矩：profile 必须先改、再重启；新键在旧代码下是 unknown key，旧键在新代码下同样抛错，两头都不静默）。此前 `400k` 被拒且报错只说「0.1 到 0.95」，既没说是窗口比例、也没说 token 数是合法触发 —— 一个把原因说错的拒绝。
- 消歧规则（唯一读者 `src/shared/threshold-spec.ts`）：裸数字 ≤ `0.95` 是比例、≤ `95` 是百分比、`> 95` 只能是 token 数（没有合法比例那么大）；`%` 显式表示比例，`k` 显式表示千。所以 `5` / `1` / `0` 仍然是「比例越界」的拒绝，而不是悄悄变成 5 token 的触发器（那会先通过解析、再在下限处报另一个原因，把一次错误变成两次）。
- 围栏（用户裁定「截断 + 具名」）：绝对数超过窗口容量 `W − 4000` 时**截断并写明**（label `400000 tokens (capped to 96000)`，`override.setting:"tokens"`），绝不静默保留一个永远点不着的触发点；低于物理下限（`overhead + recent + 8000`）**拒绝**，且建议仍按当前模式给 —— token 模式建议 `/handoff threshold <floor>`，比例模式给最小可行比例。`no-positive-threshold` 与 `fixed-below-floor` 两句都不再假定「比例」，否则就是在说一个用户没设过的旋钮。
- 回执：label 三态（`auto N (x%)` / `40% of window` / `400000 tokens`，后两者带 `(capped to N)`）；`/handoff status` 的固定模式摘要写 `fixed ratio 40%` 或 `fixed threshold N tokens`；`statusText` 的 pending patch 走**同一个** reader —— 直接把写回字符串铺进已解析的 config 会让合并对象没有 `mode`，把刚写下的值解释成 `fixed 0%`（本轮自查抓到，已由 `/handoff threshold 0.1` 的端到端用例钉住）。
- 卡片：开关 + 比例两行换成一行文本框（`thresholdField`），draft 用同一个 parser、写入规范拼写（`400k` 存成 `400000`）；文案换成 `field.handoffThresholdHint`，默认写成 `auto`（schema 默认值就是它）。
- 配置读取：`resolvePluginConfig` 接受**已解析**的 spec —— `publishProjectContextSettings` 会把 entry 的 config 再解析一次，字符串仍是唯一存储形状；这条容忍让那次重解析不再抛错回退。
- profile 迁移（与重启同一步）：`~/.dsh/profiles/desktop/cordis.patch.yml` 的 `handoffThresholdAuto: false` + `handoffThresholdRatio: 0.4` 已改写为 `handoffThreshold: "0.4"`（备份 `cordis.patch.yml.bak-*-z8e-threshold-merge`）；web profile 本来没有这对键，默认 `auto` 不变。用户在重启前不要再保存设置卡片：旧代码会按旧键重写文件。
- 测试：新增 `test/threshold-spec.test.mjs`（7 条，三种拼写 + 消歧边界 + 规范拼写往返）与 `test/threshold-tokens.test.mjs`（4 条，数量照用 / 超窗截断具名 / 低于下限拒绝且建议同模式）；`card-render`、`settings-form`、`config-vocabulary`、`threshold-floor`、`handoff-decide`、`logic` 的夹具与断言按合并改写，两条只为 gate 存在的用例删除（合并后没有任何行再被 gate）。
- 变异 3 个，各只红自己的目标：去掉 token 的窗口截断 → 「超窗截断并具名」红；建议忽略 token 模式 → 「低于下限建议同模式」红；放宽「小裸数字是比例」的守卫 → 解析器的消歧用例红（第一次的 M3 因 `bare` 变成未引用触发 TS6133，属无效变异，换锚点后重跑）。
- `pnpm test` **615 通过 / 0 失败**（原 609：+7 +4 −5），`pnpm typecheck` 0，`pnpm build` ok（`lib/client.js` 38791）。
- 残留：`rowVisible` / `appliesWhen` 这套 gate 机制现在没有使用者（唯一被 gate 的行合并掉了）；本批保留不动，下一批决定删除还是复用。**（已由紧随的清理批删除，见本节上方。）**
- 文档同步（同批补记）：`README.md` 的命令表与配置键表、`docs/settings.md` 的键表、`docs/vocabulary-conventions.md` 的键映射都改成合并后的单一键 `handoffThreshold`，`/handoff threshold 400k` 与「超窗截断并具名 / 低于下限拒绝」写进命令表；`docs/vocabulary-conventions.md` §K 保留批 H 当时的映射、另加一段「批 H 之后」说明本次合并（不改写历史）。同时改正四处仍在写已退役键名或旧默认的注释：`client/card-fields.ts` 的 `FieldGate`（现已无行被 gate）、`src/shared/ratio.ts`、`src/shared/limits.ts`（`DEFAULT_THRESHOLD_RATIO` 不再是「自适应之外的默认」，默认是 `auto`）、`src/project-handoff/index.ts` 的触发摘要。

**project-memory（批次 Z8d：id 记账不再吞事实，也不再谎报丢事实）**

- 修复（2026-11-11T03:33Z 的假警报）：Z2 的 id 盖章会在计划阶段给文档带上 id、回写阶段因装不下而整份去掉，而回归守卫 `removedSectionEntries` 逐字比较新旧条目，于是把每一条未改动的 Invariants/Pitfalls 条目都判成「已消失」——`errors.log` 里是 107 条，实测其中 96 条只差 id、11 条是真改写。现在两侧都先 `stripEntryTid` 再归一化比较；守卫仍然只报告、不阻断，Project/Index 仍排除。新用例 `batch Z8d`（`test/logic.test.mjs`）用 4000 字符 cap 复现「计划带 id、回写不带 id」的完整链路，变异后红在 `removedEntries.count`。
- 机制（用户 2026-11-11 裁定 A）：`retireWithinBudget` 不再全有全无。带 id 渲染干净 → 全量盖章；不带 id 干净而带 id 不干净 → **按 Invariants → Pitfalls → Project → Index 的顺序，用剩余字符盖多少算多少**，每盖一批先用渲染器复核，宁可少盖也绝不丢条目；两份都脏（溢出是文档自己的）→ 保留全部 id；没有任何条目既装得下又盖得上 → `stamped:false`（新语义：只有真的零个 id 落地）。预算按纯文本渲染后的剩余字符算，再逐个降到渲染器接受为止——盖 id 会改变分配里的条目需求，算术值只是上界。
- 两条边界约束：① **盖好之后长度仍超过 800 单条上限的条目直接跳过**（条目在预算之前已被盖章，阈值看的是含标记的长度，正文 ≥ 795；794 + 标记正好 800，照常盖章）——否则一条近上限条目会让每个包含它的前缀都被渲染器拒绝，预算一路降到 0，`stamped:false` 时旁边 20 条明明装得下的条目一个 id 都没有（已由 `a near-cap entry postpones only itself` 钉住）；② **id 派生不再用 sidecar 播种**——把 `entries.json` 里已有的 id 当作「被占用」会让未盖章条目撞到自己的旧 id、换一个盐，同一个正文换 id、年龄必然重置（`the pass keeps the clock of an entry its partial stamp could not mark` 钉住）。
- `entries.json` 的裁剪改用 `keepIds`：文档**拥有**的全部 id（含未盖章但仍在文档里的条目），不是只在正文里出现的那些。所以推迟盖章不会重置年龄，也不会让一个「等装得下再盖」的条目在下次盖章时从当天重新计时；`stamped:false` 时同样会裁剪掉真正离开文档的 id。
- 本机算例（cap 45 000，在 fe5dfed 的文档上测得：44 589 字符 / 140 条，17/64/44/15）：剩余 411 字符 = 68 个 id，恰好盖上全部 64 个 Invariants + 44 个 Pitfalls 里的 4 个；Project（17）与 Index（15）全部推迟，40 个 Pitfalls 尾部也等下一次空间。全量税 840 会丢 3 个整条目——旧行为下这 840 字符一旦装不下，140 个 id 会一起消失。这些数字只是那次测量的快照（此后一次自动 pass 已把该文档重写为 44 997 字符、131 个 id），引用前现读 `MEMORY.md` 与 `renderMemoryDocument`。
- id 仍由正文 sha256 派生（同一正文同一 id，部分盖章与全量盖章一致），因此「等一次装得下的 pass」不改变身份；Project/Index 本来就每轮重写，把它们排最后是价值判断，不是「退休只读这两个 section」——退休触发对四个 section 都跑。
- 新用例 6 条（`test/retirement.test.mjs`：部分盖章不丢条目 / 预算花在 Invariants+Pitfalls 上 / 两份都脏时保留 id / 不到 6 字符空位时零 id 但保住时钟 / 近上限条目只推迟自己 / 真实 pass 里未盖章条目的年龄不被重置），替换原来的「装不下就整份不盖」1 条；5 个变异各只红自己的目标（预算归零、优先级反转、`keepIds` 退化成 carried ids、id 派生退回用 sidecar 播种、去掉近上限过滤）。
- `pnpm test` **609 通过 / 0 失败**（原 604，−1 +6），`pnpm typecheck` 与 `pnpm build` 均 0（`lib/client.js` 38274 未变）。
- 本批动了 `src/`，**需要重启宿主才生效**。

**project-handoff（批次 Z8c：放弃的交接不再留下空会话目录）**

- 发现方式（2026-11-11）：Z7/Z8 的测试跑完后按 Z1 的口径核对存档——`session-logs/` 有 196 个目录而 `INDEX.md` 只有 194 行；差的两个里，一个是本次会话（尚未归档，理应缺行），另一个是空目录 `child-1`（无 `meta.json`、无 `session.jsonl`）。
- 根因：Z7 的绑定必须写在种子之前（子会话的第一个请求在 admission 读它），而失败路径的 `discardHandoffBinding` 只删 `meta.json`，目录留在盘上。`binding.ts` 的注释把这解释成「generation 会跳过没有元数据的目录」，但同一段事务在 `perform.ts` 里承诺的是「an abandoned handoff leaves nothing behind in the project」——两句话互相矛盾，按后者修。
- 修法：`bindHandoffChild` 在 `writeSessionMeta`（它会 `mkdir`）**之前**读目录是否已存在，记进 `HandoffBinding.createdDir`；`discardHandoffBinding` 删掉 `meta.json` 之后，只有「这次创建的」且「仍为空」的目录才 `rmdir`。用 `rmdir` 而不是 `rm -r`：空检查与删除之间出现的任何新字节都必须存活，递归删除可能吃掉已落盘的归档。
- 守卫不变：`session.jsonl` 已存在就元数据与目录都不动（归档已经拥有它）；**预先存在**的目录也不动（不是这次尝试的，删了会丢别人的东西）。
- 测试隔离（同一缺陷的另一半暴露点）：`test/logic.test.mjs` 里三条会真的跑完交接事务的门禁用例原先给会话 `cwd: process.cwd()`，于是事务把绑定写进**本仓库自己的** `.agents/memory/session-logs/`——一次被中断的测试就会留下假会话目录与悬空索引行；改用 `mkdtemp` 临时根。
- 新用例：`test/handoff-binding.test.mjs` 4 → 5 条（放弃后目录不存在；预先存在的目录不被删；归档已认领时目录与元数据都留）。
- 变异：2 个各只红自己的目标——`createdDir` 恒 `false`（放弃用例红）、恒 `true`（所有权用例红）。
- `pnpm test` **603 通过 / 0 失败**（原 602 + 1 条新用例），`pnpm typecheck` 与 `pnpm build` 均 0（`lib/client.js` 38274 未变）。
- 本批动了 `src/`，**需要重启宿主才生效**。

**project-handoff（批次 Z8a：陈旧 provider/model 配对的失败变成用户可见）**

- 设计来源：`docs/batch-z-six-problems-spec.md` §11.10(a)（§11.8 Z7 落地小节留下的残留，用户 2026-11-11 裁定要做）。
- 修的是什么：本会话路由（`resolveTarget`：插件配置优先，其次**会话请求头**——所以一次中途切换模型会留下旧配对）指向本机解析不出来的组合时，`ctx.llm.resolveModelInfo` 抛 `LlmError`；旧行为只有一行 `warn` + `errors.log` + 5 分钟退避，而唯一会讲成因的 `/handoff status` **自己也在同一处抛错**，用户端彻底不可见。
- 新模块 `src/project-handoff/route-failure.ts`：`withRouteFailure(route, read, signal)` 是**唯一**的包装点（触发端的 gate 与回执共用），把非取消异常包成 `HandoffRouteError`（带 `failure {provider, model, code}` 与 `detail`）。`signal.aborted` 时**原样重抛**——「调用方取消」不能被记成「路由坏了」。
- 注入行与越线共用一条 `systemPrompt.context`（`display.ts` 的 `handoffPressureText` 把两半拼成一行）。两半各自冻结，重复同一失败**不重渲染**：一次文本变化就是一次 ~37KB runtime-context 快照追加。注入行只写 route + harness code，不写适配器 message（message 会随瞬时故障变化，且它属于按需渲染的回执，长度免费）。成功的 `recordHandoffGate` 与会话销毁各自清除它，所以恢复之后那行不再声称失败。
- `/handoff status` 不再抛：捕获后推一行 `route p/m cannot be resolved (CODE): <message>; …` 并跳过数字段。连带的正确性收益：`/handoff threshold <ratio>` 写已落地时，回执不再退化成「回执无法构建」——两个分支各有用例。
- 残留：告警是**模型转述**，不是客户端横幅（本包没有客户端通知通道）；路由修好后最长等一次失败退避（≤5 分钟）才重试并清行。
- 新用例 7 条（`test/handoff-route-failure.test.mjs`，含真 `apply()` 的 `turn/end` 接线与「关掉交接就不记录」负控）+ `test/threshold-floor.test.mjs` 新增 1 条；8 个变异各只红自己的目标（不包路由失败、取消也包装、重复重录、清除变空操作、成功解析不清行、注入行丢掉路由半句、回执吞掉失败、触发端不记录）。
- 本批动了 `src/`，**需要重启宿主才生效**。

**project-context（批次 Z8b：`/session-log tree`——把 `meta.json` 的 `parentId` 读成树）**

- 设计来源：`docs/batch-z-six-problems-spec.md` §11.10(b) 与 §11.2（Z3 把 `parentId` 写成数据之后，它一直没有读出口）。
- 新模块 `src/project-context/session-tree.ts`（`buildSessionTree` / `renderSessionTree` / `readSessionTree`）+ `src/project-context/session-index.ts` 的只读读口 `listArchivedSessions`（`regenerateSessionIndex` 是同一次走查加上迁移写回，不能当读口复用）；命令 `/session-log tree` 接在裸读那一侧，不与 `import` 争同一个回落分支。
- 三种形状是**处理**而不是假设掉的：孤儿（`parentId` 不在存档）→ 作根并写明缺哪个父，否则它会被静默丢掉；环（只有手改 meta 才可能）→ 已发出的节点当叶子，保证终止且每个会话恰好出现一次；子代理档案（`kind: "subagent"`）→ 不渲染（`INDEX.md` 也不列）但表头计数，免得「我的子会话去哪了」。
- 上限 500 行并在尾部指向 `INDEX.md`：回执没有滚动条，无界清单本来就是 `INDEX.md` 的角色。`kind` 只标在根节点（子节点的缩进已经说明它是续接），另有 `task` 与孤儿标注。
- 新用例 7 条（`test/session-tree.test.mjs`，含真 `apply()` 的命令接线与临时项目里的 meta 文件）：嵌套与根序、孤儿标注、环与自环、子代理隐藏并计数、空存档与任务标注、行数上限、命令接线；5 个变异各只红自己的目标（子代理进树、行数上限放大、去掉环守卫、孤儿不标记、`tree` 未接线）。
- 本批动了 `src/`，**需要重启宿主才生效**。

**project-handoff（批次 Z7：交接种子按任务切片——子会话继承父会话的任务绑定）**

- 设计来源：`docs/batch-z-six-problems-spec.md` §11.8 Z7（§6 问题 6 第 2 条「种子只能带全量上下文」）。依赖 Z3（任务维度）与 Z5（todo 接线）。
- 新模块 `src/project-handoff/binding.ts`：交接时把子会话的 `session-logs/<childId>/meta.json` 写成 `{id, date, title, kind:"handoff", parentId, task}`，`task` 从父会话自己的 meta 读（`readSessionTaskSync`）。**这是种子切片唯一需要写的东西**：注入侧按会话 id 解析上下文文档（`boundTaskSync`），所以绑定一落地，子会话注入的就是 `tasks/<slug>.md`，而不是含全部跨任务 Open tasks 的项目级 `CONTEXT.md`。
- **写在种子落地之前**：子会话的第一个请求在 admission 时读同一个 `meta.json`，晚写会让第一轮看到项目级文档。用例在种子投递点同步读盘钉这个顺序；写失败只丢继承（回到旧行为）并写一行 `warn`，不让整个交接失败。
- **放弃的交接要把元数据取回**：`discardHandoffBinding` 删掉本次写的 `meta.json`——有 meta 没有归档会在下一次生成里变成一条指向不存在文件的索引行（Z1 消掉的状态）。守卫是子会话自己的 `session.jsonl`：一旦归档写了它，目录就不再属于这次尝试，元数据必须留；两个方向都有用例。**（目录本身当时被留在了盘上，Z8c 补修。）**
- **todo 半边不需要新通道**：Z5 的机械 `- [todo] …` 行写在会话自己的文档里（绑定的是 `tasks/<slug>.md`，未绑定的是 `CONTEXT.md`），子会话读的正是同一份，所以「种子带当前 todo」由共享文档自动成立——没有第二份拷贝，也没有新的种子字段。
- `kind`/`parentId` 同时把 §11.2 的会话树变成数据（归档写的 `preserveForeign` 会继承它们）；`/session-log tree` 命令当时未实现，由上面 2026-11-11 的 Z8b 补上。
- **后续**：§10.9 Z7 的后半「陈旧 provider/model 配对失败改为用户可见提示」当时等用户裁定；用户 2026-11-11 裁定要做，实现见上面的 Z8a。
- 新用例 4 条（`test/handoff-binding.test.mjs`，真跑 `performHandoff` + 真临时项目 + 假控制器/假 Agent 注册表）：绑定继承与注入解析、绑定先于种子、未绑定负控、放弃清理与归档守卫；5 个变异各只红自己的目标（不写 task、绑定挪到种子之后、放弃不清理、清理忽略归档声明、从子会话而不是父会话读 task）。
- 本批动了 `src/`，**需要重启宿主才生效**。

**docs/skills（批次 Z6：路由型技能——四块维护任务一张表，`MEMORY.md` 一行指针）**

- 设计来源：`docs/batch-z-six-problems-spec.md` §11.7（用户 2026-11-10 裁定：一个短的入口技能、渐进式披露；并明确**否决** `ctx.skills.register` 注入——要的是磁盘上可 review 的技能）。
- 新文件 `.agents/skills/dsh-project-context-maintenance/SKILL.md`（`.agents/skills` 现有 33 个技能，这一批新增入口技能）。正文只有一张四列表——`插件 | 任务 | 第一步 | 专项技能`，15 行覆盖记忆维护、索引与归档、交接、技能沉淀四块；专项细节**不复制**，全部指向既有技能（cap-guard、loss-repair、recovery、four-section-migration、index-adoption、store-maintenance、archive-repair、handoff 两个 forensics、corpus-consolidation）。表里给的是**第一动作**（跑哪条命令 / 读哪个文件），因为那才是判断分支的依据。
- **模型可调用而不是只在手边**：`description` 常驻并前置触发分支（记忆编辑与 cap 压力、归档索引缺口、交接是否触发、autolearn 沉淀），因为 Z6 要解决的是「模型不知道该用哪个专项技能」，人手记的方式解决不了它。代价是一行常驻上下文，所以正文压到 3000 字符以内并禁止代码块。
- **项目层技能是 watcher 热加载的**：落盘后同一会话里 `skill` 工具即可载入（本次实测，宿主没重启），所以这一批**不欠重启**。
- `MEMORY.md` 的 `## Index` 加一行指针（走插件的 `loadMemory` → `renderMemoryDocument` → `recordMemoryDocument` 路径，不手工编辑），保证它被看见；顺带把两处会被读-now 命令再生的枚举（test/ 套件名、`.agents/evidence` 的日期目录）压成一句话，净增 133 字符，落盘 **44688/45000**、无整条目丢弃、渲染→解析→渲染逐字节一致。
- 新用例 5 条（`test/routing-skill.test.mjs`）：frontmatter 名 = 目录名、全语料无重名（重名会被 provider 静默遮蔽）、每个 `dsh-*` 指向的技能在 `.agents/skills/` 存在（用户层的 `agents-memory-recovery` / `dsh-session-archive-repair` 显式白名单声明）、每个 `/命令` 都在 `src/*/index.ts` 真注册、正文 < 3000 字符且四块各有行；9 个变异各只红自己的目标（名字与目录不一致、第二个技能抢占同名、指向不存在的技能、指向未注册的命令、某块丢掉整行、正文长出过程、表头改成散文、行尾改成散文、指向未声明的用户层技能）。
- 文档：`AGENTS.md` 的「29 个程序性技能」是过期快照，改成读-now 命令；README 的目录树注明 `.agents/skills/` 里既有沉淀产物也有人写的入口技能。

**project-memory（批次 Z5：todo 接线——未完成项按 `[todo]` 行写进 Open tasks）**

- 设计来源：`docs/batch-z-six-problems-spec.md` §11.6（用户 2026-11-10 两裁决：只收当前会话、写入时机用 `turn/end`）。
- 新模块 `src/project-memory/todo.ts`。会话自己的 todo 列表是上下文文档里**唯一不属于模型意见**的部分：`todo_write` 的 `todos` 投影才是真相，所以 `turn/end` 时把未完成项按 `- [todo] …` 写进该会话文档的 Open tasks 顶部，其余条目与全文其余字节逐个不变；`in_progress` 带 `(in progress)`，`completed` 不写。**不调模型**，Summary / Key points 仍只在整理 pass 更新。
- **两种「没有」必须区分**：投影为 `null`（本轮没写 todo，上游在每次 `turn/start` 清空）就**不写任何东西**，上次的快照继续站着；只有**空列表**（工具说没有剩余工作）才清掉机械行。把两者混为一谈会在每个不写 todo 的轮次删掉未完成清单，而那正是交接前最该留下的东西。
- **整理 pass 必须接着维护同一段**，否则每次 `turn/end` 之后几秒跑的那次 pass 会把它擦掉（pass 是整份重写）。两个写方共用同一个 `withTodoLines`：pass 优先用投影，投影没有意见时用**已存文档里的机械行**，所以一次 pass 既不会复活已完成的项，也不会吞掉刚写下的项。
- **快照不变就不写**（多数轮次），判据是重渲染后的整份文档逐字节相等；因此 `CONTEXT.md` 不会每轮多点 diff。写入位置是会话自己的文档：绑定了任务就是 `tasks/<slug>.md`（Z3），否则 `CONTEXT.md`；文档不存在就**不创建**——这是 pass 产物上的机械补丁，不是第二个创建者。
- 机械行受 Open tasks 的**段落预算**与 50 条上限约束：写不下的项计入 `droppedItems` 并写一行 `errors.log`，而不是留给下一次 pass 去裁模型写的条目（那会把「加了一行 todo」变成「删了一条事实」）。
- 新用例 18 条（`test/todo.test.mjs`）：行格式、空列表 vs `null`、围栏里的假标题、占位行、幂等（`mtimeNs` 证明没写）、绑定任务文件、pass 保留与回退；14 个变异各只红自己的目标（两个是同一缺陷的多处观察点）。

**project-memory（批次 Z4：清洗通道——tar → 删 → `purge.log`，`/memory prune`）**

- 设计来源：`docs/batch-z-six-problems-spec.md` §11.5（用户 2026-11-10 三裁决：自动跑、删前先 tar、清理记录写独立日志）。
- 新模块 `src/project-memory/prune.ts`。四类长期只涨不落的本地产物终于有了地板：`*.memory-backup-*` 只留最新 **3** 份（写入路径自己那套 5 份 + 1 小时下限是突发闸，这是长期地板）、`memory-log-*.jsonl` 超 **90 天**、`memory.jsonl.*.tmp`（原子写崩溃残留）超 **90 天**、`errors.log` 超 **1 MB** 时归档后原地截断到最新约 64000 字符的整行尾巴、`skill-candidates/*.md` 超 **60 天**。
- **`session-logs/` 与活的 `memory.jsonl` 永不在候选里**：时间线就是审计线，批次 Z2 的「被取代」「久未证实」两个触发都读它，删一个会话目录会静默废掉两条机械到期；活 journal 是真相本身。计划只扫记忆目录一层与 `skill-candidates/`，不递归、不跟随符号链接。
- **先归档、再校验、最后才删**，且归档器写在进程内（`src/` 不许有命令能力，这条不变量由 `test/project-root.test.mjs` 钉住）：ustar 512 字节头 + 补零 + 两个零块，写完后用同一个解析器读回**磁盘上的字节**逐成员核对，任一步失败就一个文件都不删、`purge.log` 记 `result=failed`。未压缩是刻意的——同一天第二次运行要**追加**（压缩包不能追加），早上那份证据不能被覆盖；超过 100 字节的成员名按 ustar 的 prefix 拆分，真 `tar -tf` 能读回原名。
- `/memory prune` 是预览（**一行日志都不写**，看过不留痕），`/memory prune --apply` 才真删；自动路径在每次**真的跑了**的整理 pass 之后执行同一套逻辑（deduped 的 pass 不算），失败只 `warn` + 写自己的日志，绝不把已落地的写报成失败命令。
- `purge.log` **每次一行**——这里的「每次」是「真的发生了清理的那次」：自动路径无事可清时不写（否则每个 pass 一行），显式 `--apply` 即使无事可做也写 `result=nothing`（用户问了就要回执）。行格式：`时间 reason=auto|manual removed= truncated= bytes= trash= targets= result=ok|nothing|partial|failed`，`targets` 超过 6 个只列前 6 个并给计数，避免一次突发写成 4 KB。
- `purge.log` 与 `trash/` 进 `MEMORY_GITIGNORE_LINES`（本地产物，不入库）；`errors.log` 的「保留多少」只有一份实现：轮转函数与清理通道共用 `errorLogAfterRotation`。`/memory` 的用法串与 `input.hint` 加上 `prune [--apply]`。
- 用例（`test/prune.test.mjs`，17 条）：预览零写入零日志、保留最新 3 份且被删成员都在 tar 里、**会话目录数与内容在自动/手动两条路径后都不变**（正控：同一次真的删了文件）、90/89 天与 60/59 天边界、活 journal 与外来名字（`MEMORY.md.user-backup`、`CONTEXT.md`、`entries.json`、`notes.txt`、`old.md~`）永不成为候选、1 MB 之上截断/之下不动、空目录也写日志/自动路径空闲不写、归档写不成则一个都不删、同日追加不重复成员、超长成员名、以及走真整理 pass 的自动钩子。
- 变异校验：11 个变异各只让目标用例转红——保留份数、两个年龄地平线、错误日志阈值、名字过滤放宽、计划扫进 `session-logs`、tmp 规则误吞活 journal、归档写到别处却按内存校验、空闲也记日志、预览变成执行、自动钩子摘掉；还原后 `src` 与哈希备份逐字节一致并重建。
- 门禁（现跑）：`pnpm typecheck` 0；`pnpm build` 0（`lib/client.js` 38274，重建字节一致）；`pnpm test` **560 通过 / 0 失败**。
- **需要重启宿主**（`src/` 改了）。重启后可见：`/memory prune` 有回执、整理 pass 之后 `.agents/memory/purge.log` 出现行、`.agents/memory/trash/` 出现当天的 tar（本机当前有 2 份超出保留份数的备份，第一次 pass 就会触发）。

**project-memory + project-context（批次 Z3：任务维度——`tasks/<slug>.md`、三态、绑定命令）**

- 设计来源：`docs/batch-z-six-problems-spec.md` §11.4（用户 2026-11-10 四轮裁定）。
- 新模块 `src/project-memory/tasks.ts`：`tasks/<slug>.md` 的格式（`# Project Task: <slug>` + `> created … · status … · lastSeen … · title …` + 同一套 Summary / Key points / Open tasks）、三态的**派生**、绑定读取、状态改写。渲染走 `context-doc.ts` 的同一个核心，所以任务文档不是第二套格式。
- **状态只派生不双写**：`active` / `dormant` 由 `lastSeen` 年龄现算，`archived` 是唯一自主值；> 30 天 dormant、> 90 天由 `delegated` 自动归档，`assisted` 只自动降级，`manual` 完全不派生。这同时消掉了规格里「dormant 满 90 天」与验收「91 天」的矛盾（dormant 不是持久状态，唯一可测的边界是年龄）。
- `/context task <slug>` 把绑定写进该会话的 `session-logs/<id>/meta.json`（落盘，重启不丢）；`new` 造任务、`none` 解绑、`archive` / `activate` 改状态；裸 `/context task` 列出 slug + 状态 + 标题。三种模式的差别是**制造权限**：`assisted`（默认）/`manual` 拒绝裸 slug 并点名 `new`，`delegated` 把裸 slug 当声明并建文件（模型主动提议的通道仍未实现，规格 §11.4 已记为残留）。
- **绑定必须由归档写保护**：`meta.json` 每轮从活会话重建，原来会把命令写的 `task` 擦掉（症状是"命令用一次就失效"）。`preserveForeign` 让新元数据缺失的 `kind`/`parentId`/`task` 从已存文件继承，解绑走同一条队列与锁所以不会被下一次 settle 复活；`parentId` 的写方（`performHandoff`）仍未实现，这是给它留的前置。
- **`archived` 既不注入也不写入**：只读与写侧共用一个判定 `boundTaskSync`，否则一次 pass 刷新 `lastSeen` 就会把归档任务自动复活；绑定本身留在 `meta.json`，`activate` 之后立刻恢复。
- 注入：绑定的会话注入 `tasks/<slug>.md`（`## Project Task (slug)` + 指向该文件的指针块），否则仍是 `CONTEXT.md`；两种情况都在有其他任务时追加一行一个的清单（只给 slug / 状态 / 标题）。无任务的会话注入与改动前**逐字节一致**（用例直接比字符串）。
- `/context` 的裸调用多一行 `Task:` 状态；命令面新增 `input.hint`，但 `/context` 仍是读命令，`task` 是它的子命令（无别名、无旧拼写）。
- 配置新增 `taskMode`（`assisted`/`delegated`/`manual`，默认 `assisted`），六处一起动：`config.ts`（接口 / 默认值 / 校验）、`settings.ts`、`client/card-fields.ts`、`client/locales.ts`（zh/en）、读取方（状态派生与命令）；第六处「写回键」在本批不存在——没有命令写这个键，只有设置卡写它，所以没有 `settingPatch` 入口要改。**这是破坏性的配置面变更**：`config.ts` 对未知键抛错，`assisted` 之外的取值只影响新行为，缺省值不变。
- 回执：绑定会话的整理回执点名真正落地的文件（`.agents/memory/tasks/<slug>.md`），不再说 `CONTEXT.md`——后者这次一个字节都没动。
- 用例（`test/tasks.test.mjs`，19 条）：元信息行往返（标题含 ` · `）、30/31 与 90/91 边界、`manual` 冻结、`archived` 粘滞、slug 校验、坏文件不遮蔽其他任务、绑定读取与 `meta.json` 往返、归档写继承绑定与解绑不被复活、任务/上下文注入与"无任务逐字节一致"、绑定会话只写任务文件（`CONTEXT.md` 逐字节不动、`created` 保留、`lastSeen` 刷新）、归档绑定写项目文档、下一趟 pass 读到的是任务文档、以及命令的列出/新建/拒绝裸 slug/`delegated` 新建/解绑/归档/激活/绑定已归档被拒。
- 变异校验：11 个变异各只让目标用例转红——dormant 边界、`manual` 冻结、`delegated` 归档、`archived` 粘滞、绑定继承、`archived` 注入、写目标、`lastSeen`、`created`、任务注入源、空清单块；还原后 `src` 与哈希备份逐字节一致并重建。
- 门禁（现跑）：`pnpm typecheck` 0；`pnpm build` 0（`lib/client.js` 38274，重建字节一致）；`pnpm test` **543 通过 / 0 失败**。
- **需要重启宿主**（`src/` 改了，配置键也变了）。重启后可见：`/context` 多一行 `Task:`、`/context task` 可用、设置卡多一行「任务维护模式」。

**project-memory（批次 Z2：退休通道——删正文 + 写墓碑 + 三条机械触发）**

- 设计来源：`docs/batch-z-six-problems-spec.md` §11.3（用户 2026-11-10 裁定「退休 = 立即删除 + 墓碑」，防复活摘要「只给日期与标题、最多 20 条」）。
- 新模块：`src/project-memory/retired.ts`（墓碑文件的格式/解析/追加/压缩/摘要）与 `src/project-memory/retirement.ts`（条目 id 与三条触发）。
- 三条触发都不靠模型观感：**锚点漂移**（条目里的路径不存在、或行号越界）、**被取代**（新条目写 `supersedes:<id>`）、**久未证实**（条目超过 180 天且 180 天内的归档会话都不再提到它）。第三条扫 `session-logs/*/session.jsonl`，按 32 MB 字节预算**从新到旧**读；扫描没跑完就**一条都不退**——「没找到」与「没找完」必须区分，否则会删掉还在用的事实。
- 防复活：整理提示词注入 `<retired-facts>`，只给日期与标题（不给原因，`superseded-by:<id>` 会从后门把退休内容带回来），最多 20 条，超出只报数量；没有墓碑时提示词逐字节不变。
- **与规格不同的两处（均为实测驱动，已回写 §11.3）**：① 条目标记只写 `（4f2a）`，日期改由侧车 `entries.json` 记录——带日期的 23 字符标记在本机文档上会让渲染器丢 **7 条整条目**，只带 id 的 6 字符标记是 0 条（43720 → 44524 / 45000）。② 锚点判据收紧到「末段带源码/文档扩展名 + 父目录必须存在 + 排除插件自己的本地生成物」，因为更宽的判据把 30 条散文当成了路径、次宽的把 7 条外部 checkout 路径当成漂移；定稿规则在真机文档上 0 误判。
- 写入顺序：墓碑只在**内存真的落地之后**追加（`snapshot.written`），所以 tier C 拒绝、Q2 拒绝、`basisKey` 竞态、空骨架闸都不会留下「事实已死但其实还在」的记录；追加失败只记 `errors.log`，不把已落地的写报成命令失败。
- id 是内容派生的四字符十六进制（同一正文永远得到同一 id），`（id）` 跟在条目正文尾部（`sectionsFromMarkdown` 只认四节 bullet，标记不能占行首）。盖 id 会让文档变长 6 字符/条，因此**先问渲染器**：若盖 id 会让文档丢整条目、而不盖不会，则本趟退回不盖并记一行——元数据不许以条目为代价。
- 用例（`test/retirement.test.mjs`，17 条）：墓碑往返/去重/压缩不丢行、摘要上限与计数、id 稳定与去重、三条触发各自的**正负对照**（含「扫描没跑完不退」与「180 天内不退」）、盖 id 的预算回退、以及两条走真整理 pass 的端到端（漂移条目从 `MEMORY.md` 消失 + 墓碑多一行 + 提示词不再展示它；下一次 pass 的摘要点名它、且不含原因）。
- 变异校验：6 个变异各只让对应那条用例转红——锚点父目录判定、回声保护、摘要注入、墓碑压缩、扫描完整性、未落地不留碑；还原后 `src` 与哈希备份逐字节一致并重建。
- 门禁（现跑）：`pnpm typecheck` 0；`pnpm build` 0（`lib/client.js` 37270 不变，重建后 md5 一致）；`pnpm test` **523 通过 / 0 失败**。
- 真机文档（只读）：`stamped=true retired=0 added=134`，渲染 44524/45000、0 丢条、0 截断、往返逐字节一致、10 ms。
- **需要重启宿主**（`src/` 改了）；重启后可见：`MEMORY.md` 每条尾部出现 `（xxxx）`、`entries.json` 生成并被 `.gitignore` 覆盖、`retired.md` 只在第一次真的退掉条目时出现。

**project-context（批次 Z1：会话索引改为 `meta.json` 的生成物，删除 200 行上限）**

- 设计来源：`docs/batch-z-six-problems-spec.md` §11.1（用户 2026-11-10 裁定「生成式」，并接受 `date`/`title` 因此进入 `meta.json`）。
- 改动：新增 `src/project-context/session-meta.ts`（`SessionMeta`、`readSessionMeta`、`writeSessionMeta`、`isDirectory`；写盘前 `mkdir -p`，因此索引可以先于归档字节落地）。`session-index.ts` 的写入路径从「读旧文档 → 合并 → 按日期排序 → 截断到 200 行」换成「写本会话的 `meta.json` → 扫 `session-logs/*/` → 读各 `meta.json` → 整份重写」。`MAX_INDEX_LINES`、`dedupeIndexLines`、`orderIndexLines` 与那段 `N older sessions dropped` 注释一并删除。
- 结构收益：漏写（目录在、行不在）与悬空（行在、目录不在）不再是「要修的 bug」，而是写不出来的状态——行的存在性与目录的存在性同源；重复也不可能，因为目录名就是键。
- 迁移（一次性、幂等）：目录没有 `meta.json` 时，日期与标题先取旧 `INDEX.md` 的行（再退到 pre-move 的 `session-index.md`），仍没有则读 `session.jsonl` 首行头的 `createdAt`/`timestamp` 取日期、标题留 `Untitled session`；随后把 meta 写回，下次生成不再打开归档。`subagent` 会话（会话头的 `origin`）写 meta 但不入索引，与归档路径的 `isTopLevel` 闸一致。
- 本批自己引入又当场修掉的一个回归：新的生成路径最初直接 `readOptional(session-index.md)`，而该路径可能是 FIFO——读一个没有写者的 FIFO 会永久阻塞，既有的「FIFO 不能拖住索引写入」用例以 15 s 超时抓住了它；改为走已有的 `readLegacyIndexForAdoption`（先 `stat`，非普通文件直接放弃）。
- 用例：改 6 条（旧的上限与 adoption 语义），把 2 条上限用例换成「行随目录存在/消失」，新增 2 条（子代理不入索引；无 meta 时从旧行或归档头回填）。子代理那条做了定向变异：删掉 `meta.kind === "subagent"` 分支后该用例转红，还原并重建后转绿。
- 门禁（现跑）：`pnpm typecheck` 0；`pnpm build` 0（`lib/client.js` 37270 不变）；`pnpm test` **504 通过 / 0 失败**。
- **需要重启宿主**（`src/` 改了，`lib/` 随提交入库）；判据是「承载宿主的进程启动时刻晚于本提交」。重启后可核对：`session-logs/*/meta.json` 出现、`INDEX.md` 行数等于目录数、且文档里没有任何 `<!-- N older sessions dropped -->`。
- 启动对账（用户 2026-11-10 裁定「宿主启动时扫一次」）：新增 `reconcileSessionIndexOnce(projectRoot)`，接在 `agent/created` 上，每项目每进程一次，遵守 `archiveEnabled`；失败写本项目 `errors.log` 并清掉「已跑」标记，让下一次触发能重试。它不修任何东西——每次写入本来就整份重生成——存在的意义是让「目录在、行不在」这种**没有任何会话写入过**的状态不必等到下一次无关写入。
- Z1 验收（真机镜像，不是构造用例）：把本仓库 187 个会话目录与现有 `INDEX.md` 结构镜像到 `/tmp`，跑一次生成 → **187/187 行全保留、0 缺失、0 多余、0 重复、无 dropped 注释、整份重生成 61 ms**。首次重生成会重排行序（旧文档是历史追加序）：157/187 行换位，日期序列仍非降，25 个同日日期改由 id 定序——这正是 autolearn 取最新 50 行所依赖的性质。


**shared + project-memory + project-autolearn（修复：辅助模型调用不点名 `reasoningEffort`，被 SCNet 网关以 400 拒绝）**

- 症状与证据：`/memory update` 连续两次失败，`.agents/memory/errors.log` 里该文案累计 **14 次**（2026-11-03 08:24Z → 2026-11-07 08:18Z，全部是 `[memory]` 行）：`400 SCNet: thinking.type=disabled cannot be translated: configure model_info.thinking_disable_mode only after verifying the upstream contract`。**两份文档未被改写**（`MEMORY.md` mtime 仍是 11-06 20:57、`CONTEXT.md` 是当轮 11:28 那次、`git status` 干净）——拒绝发生在写入之前，无损。链路是 插件 → `ctx.llm.stream` → 本机 magpie（`127.0.0.1:3425`）→ `api.scnet.cn`；`~/.config/magpie/providers.json` 里 scnet 三个端点中有一个 `anthropic`（`https://api.scnet.cn/api/llm/anthropic`），这正是 `thinking.type` 这套词汇的来源。
- 根因（错误成因类，非本插件逻辑错）：两条辅助调用（`consolidate.ts` 的记忆整理、`autolearn/pass.ts` 的技能决策）都**没有**传 `reasoningEffort`。dsh 的 pi-ai 适配器在调用方不点名时省略 `reasoning`，pi-ai 的 anthropic 翻译路径于是写出 `thinking: { type: "disabled" }`（`llm-pi-ai` / pi-ai 的 `anthropic-messages`），而 SCNet 网关拒绝这种拼写，直到它**自己的** `model_info.thinking_disable_mode` 说明怎么翻译——那是服务端配置，本插件够不到。**`off` 不是逃生口**：`llm-pi-ai/src/adapter.ts` 的 `profileOptions` 把 `reasoning === 'off'` 重写成 `undefined` 再交给 pi-ai，所以「点名 off」与「什么都不点名」产生**逐字节相同**的请求，都会写出 disabled。这也是为什么不照抄 dsh 自家辅助插件的 `efforts[0].id`——对这条路由，`efforts[0]` 恰好就是 `off`。
- 修法：`src/shared/model-call.ts` 新增 `auxiliaryReasoningEffort(info)`，返回**第一个非 `off` 的启用档**（无 `reasoning`、或只声明了 `off` 时返回 `undefined`，保持原请求不变）；两处调用点各自在已有的那一次 `resolveModelMetadata` 上顺手取出它（**不新增 RPC**），并在 `PluginCallOptions` 里带上 `reasoningEffort`。
- 行为变化（登记）：在**声明了 disabled 档**的路由上，辅助调用现在以最低启用档思考，而不是不思考。这不只覆盖出问题的 scnet 路由，也覆盖此前从未坏过的路由（如 `deepseek/deepseek-flash`，其辅助调用 09:00 那一批是 200）。代价落在既有的思考预算函数里（`reasoningReserveTokens`、`adaptiveOutputTokens`、tier C 的重试头寸本来就把隐藏思考算进同一个输出 cap），不是新引入的未预算开销。
- 残差（登记，本批不修）：①**用户自己在 UI 选 Off 仍会 400**——因为 `off` 被适配器丢掉，本插件只能管住自己的两条辅助调用；根治要在网关/上游配 `model_info.thinking_disable_mode`。②`~/.config/magpie/routing/<date>.jsonl` 的 `effort` 字段是 **magpie 自己解析后**的值，不能用来证明客户端「有没有点名」；本批的机制结论来自 pi-ai 源码链，不是从该字段反推。
- 用例（+2，总数 500 → **502**）：`test/memory-store.test.mjs` 一条（整理路径：声明 `off/low/high/max` 时线上带 `low`，**负控制**为只声明 `off` 的路由不带该字段，且两半都先断 `calls.length`，不会空转）、`test/autolearn.test.mjs` 一条（技能决策路径，同样两半）。另在既有的「tools 被拒后重试一次」用例里 **+2 条断言**，钉住重试**不会静默丢掉** effort——这一条是对未来重构的钉子（两次调用共享同一个捕获值，今天没有变异体能区分它），如实记为钉子而非覆盖。
- 变异轮（3 个变异体，全部被杀；均过有效性三连：`tsc` 0 错、标记进了 `lib/`、行为确实改变；判红后从 `/tmp/mut-src/` 的哈希快照还原并 `sha256sum -c` 复验 70 个文件全部匹配，`lib/` 标记归 0）：M1 把筛选条件从 `!== off` 翻转成 `=== off` → 两条新用例**同时**红；M2 `consolidate` 侧改成 `auxiliaryReasoningEffort(undefined)` → **只有**整理那条红、autolearn 保持绿；M3 `autolearn` 侧同样处理 → **只有** autolearn 那条红、整理保持绿。M2 的第一版是「把调用点的实参删掉」，`tsc` 报 `TS6133`（局部变量不再被读）——按有效性三连这属于**无效变异体**，改形状后重跑，没有把编译失败当成证据。
- 独立只读复核（对抗式，未能推翻主结论，但确证了三件事并纠正了我的一处证据误读）：①`adapter.ts` 确实在 pi-ai 之前丢掉 `off`，因此「跳过 off」不只是「更便宜」，而是**唯一可行**；②`getSupportedThinkingLevels` 的顺序使 `off` 排在最前，配置文件与它一致；③我把 magpie 日志的 `effort` 字段当成了「客户端点名了什么」——**错了**，它是 magpie 解析后的值（09:00:40 那批带 `tools:[record_memory]`、`effort:"none"`、200 的记录，在当时的代码下不可能由客户端点名）。据其复核重写了两条注释：删掉会随本会话调用量增长的固定计数（528→608/591 都只是某一刻的快照）、并把「辅助调用不能不带 effort」这句过强的断言改成按路由与协议限定，同时补记了上面那条「路由选择 off 仍会 400」的残差与「从未坏过的路由也会开始思考」的代价。
- 门禁（现跑）：`pnpm typecheck` 0、`pnpm build` 0（`lib/client.js` 37270 不变）、`pnpm test` **502 通过 / 0 失败**；`tsc` 重新 emit 到临时目录与入库 `lib/` 比对只有 `lib/client.js` 一项差异（esbuild 产物，预期内）；`src/` 与 `lib/` 变异标记均 0。
- **需要重启宿主**：`src/` 改了，`lib/` 随提交入库；判据是「承载宿主的进程启动时刻晚于本提交」。加载后仍需一次 `/memory update`（用户侧）做行为验证——本批只能证明「辅助调用现在点名了启用档」，不能证明 SCNet 网关一定接受（`low` 在该路由上尚未被实测到，`high/max` 是实测通的）。

**project-handoff（修复：手动 `/handoff now` 交接后旧会话不归档，且不留任何记录）**

- 症状与证据：本项目 81 次交接逐个对账（把 `.agents/memory/session-logs/*/session.jsonl` 里种子横幅的「上一会话 id」与 `~/.dsh/storages/workspace.json` 的 `global.archivedSessionIds` 对照），**自动路径 80/80 归档了父会话**，唯一失败的是手动 `/handoff now`：`session-88ada514` 至今仍排在它自己的续接会话之上。它的日志给出判别式：`turn/end#384` → `command/run#385` → `command/done#386`（末事件），即**命令跑在没有任何 turn 的位置**。
- 根因（错误成因类）：`perform.ts` 用 `reason === "manual"` 冒充「这个会话自己的 turn 是否开着」，而 `scheduleRetirement` 的第三参数问的正是后者。手动路径因此被无条件延后到 `turn/end`，可那个 turn 根本不存在，于是一条只由 `turn/end` 消费的 `pendingRetire` 条目永远不会被消费——而且全程**一行日志都没有**（`retireSession` 只在真正被调用后才可能报错）。
- 修法：`guard.ts` 新增 `turnOpenNow(session)`，读会话自己的事件日志（`ownEventsOf`，优先 `ownEvents()`），从末尾找第一个 `turn/start`/`turn/end`，只有前者算「turn 开着」；fork 继承的父前缀不算本会话的 turn。`perform.ts` 改用它。**没有**改用 `ctx.agents.turnBoundaryOf()`（`openTurnStartSeq` 是非空即开着，语义等价）：那会把**回退分支**变成唯一被测试的路径，而生产上跑的投影分支无人覆盖——本仓已被这个坑咬过一次。
- 第二处静默改响：`session/disposed` 原先 `pendingRetire.delete(key)` 直接丢弃。丢弃本身是有意为之（归档是往 workspace store 写，处置中的会话不是做这件事的时机），所以保留 drop，但真的丢到条目时写一行 `errors.log`。文案只声明本处理器知道的事（退休没了 + 若仍列在客户端就手动归档），**不**再断言未核实的「它仍排在续接会话之上」。
- 行为变化（两处，都朝更安全的方向）：①闲置会话上的 `/handoff now` 现在立即归档，不再等一个不会来的事件；②自动路径在「最后一次 settle 检查 → 归档派发」之间的 ms 级窗口里若新开了 turn，会改为等该 turn 的 `turn/end`，而不是用 `stopActivity` 把刚起步的 turn 掐掉。
- 残差（登记，不修）：手动交接若发生在 turn **真的**开着时仍延后到 `turn/end`；若会话在那之前被 dispose，只在 `errors.log` 留一行而不归档。
- 用例（+3，总数 497 → **500**）：`turnOpenNow` 判据矩阵（含「无边界」「只认末个边界」「`step/*` 不参与」「fork 继承前缀不算」）；经真实 `runManual` 的两个方向（闲置→立即归档且带 `stopActivity`；turn 真开着→延后，消费后仍落地）；处置丢弃必须留下 `errors.log` 记录。另修两处既有 fixture 的自相矛盾——一个声称「命令跑在自己的 turn 内」却给了**空日志**，另一个在 `turn/end(seq 10)` 之后追加 `turn/start(seq 4)`（`seq` 即日志下标，真实日志不可能）。这两处此前不显形，正因为旧判据根本不读日志。
- 变异轮（3 个变异体，全部被杀；均过有效性三连：`tsc` 0 错、标记进了 `lib/`、行为确实改变；判红后逐字节还原并 `sha256sum -c` 复验）：M1 调用点退回 `reason === "manual"` → 只有新端到端用例红；M2 `turnOpenNow` 恒 false → 4 条红（判据矩阵、端到端正控制、处置用例、既有 never-mid-turn）；M3 丢弃改回静默 → 只有处置用例红。
- 独立只读复核：未能证伪主结论，但抓到本批 2 处判断错误并已修（「自动路径放行后必为 false」过强；拒绝 `turnBoundaryOf` 的理由写错），另其「本批新增第二个弃用调用点」的前提不成立（`session.ownEvents()` 全仓仅 `guard.ts` 的 `ownEventsOf` 一处，且不在本批 diff 内）。据其复核还修掉一行会断言未核实状态的日志文案。
- 门禁（现跑）：`pnpm typecheck` 0、`pnpm build` 0（`lib/client.js` 37270 不变）、`pnpm test` **500 通过 / 0 失败**；`tsc` 重新 emit 到临时目录与入库 `lib/` 比对 0 差异（`client.js` 除外）；`src/` 与 `lib/` 变异标记均 0。
- **需要重启宿主**：`src/` 改了，`lib/` 随提交入库；判据是「承载宿主的进程启动时刻晚于本提交」。被误留的 `session-88ada514` 需在客户端手动归档。

**project-memory（收口：移除结构性不可达的 `clipped` 状态与落地隐藏计数）**

- 性质：**纯删除**，收口上一批登记的已知残差。没有新增门禁、没有改动任何可达路径的行为。唯一可观察的变化是一行 `errors.log` 消失，而那行本来就在说谎（见下）。
- 前提复核（本批现读源码重新证明，不采信上一批的登记）：`consolidateProjectState` 的两条输入门禁都在**模型调用之前**返回——`readCapHidden > 0` → `read-capped-refused`；`fitted.clipped` → `fit-capped-refused`。过了门禁必然 `existing.cappedDroppedChars === 0`、`contextReadHiddenChars === 0`、`fitted.clipped === false`；而 `usedInput` 只在 `retryFitted.clipped === false` 时才被赋成 `retryFitted`，所以 `usedInput.clipped === false`。于是旧的派生式 `clipped: usedInput.clipped || existing.cappedDroppedChars > 0 || contextReadHiddenChars > 0` 恒为 false，`clippedLanded` 恒为 false，`status: "clipped"` 不可达。
- 删掉的面（`src/project-memory/`）：`ConsolidateStatus` 的 `"clipped"`；`ConsolidationOutcome` 的 `clipped` / `memoryHiddenChars` / `contextHiddenChars`；`ConsolidateReport` 与 `ConsolidateLoss` 上的两个隐藏计数（`NO_LOSS` 同步）；`memoryUpdateReply` 的 `clipped` 回执分支；`memoryLossDetail` 的「the model was not shown …」一段；`clippedLanded` 派生与 `status: clippedLanded ? "clipped" : "updated"`。
- **顺带修掉一处真实的错误成因**（本批唯一的行为变化）：`write()` 里 `if (outcome.clipped)` 那条日志——「consolidation was given a shortened version of the existing memory or context (the read cap or the output budget)」——在门禁落地之后**只在两条拒绝路径上触发**，而那两条路径**根本没跑模型**，所以这句话对每一次触发都是假的；更要紧的是它把读上限与输出预算两个不同杠杆含糊成一句，正是本仓库登记的头号缺陷类（把不同失败归并成一个错误成因）。拒绝路径已各自写了点名的那一行，故直接删除。同理删掉 info 行末尾的 `" (the pass ran on a shortened view of the existing content)"` 后缀。
- 保留（仍是活的）：`MemoryInput` 的 `clipped` 与两个计数（`fitMemoryInput` 的产物，两条门禁就是读它）；`readCappedRefused` / `fitCappedRefused` 两个拒绝载荷各自携带的计数——那是回执给出杠杆的依据。
- 用例：删除 11 行断言与 2 段注释。测试**总数不变（497）**，因为这些是既有用例内部的断言，不是独立用例——上一批 CHANGELOG 写的「约 10 条单测」在数量上不准确，本批按实况记。另**新增 3 条 `doesNotMatch` 断言**（两条读上限拒绝 + 一条输出预算拒绝），钉住「一次拒绝只留一行、且不出现那句含糊成因」；这三条在本批之前**必然是红的**（当时 `outcome.clipped` 在两条拒绝路径上均为 true，那句话会被写出）。
- 变异轮（4 个变异体，全部被杀；每个都过有效性三连：`tsc` 0 错、标记进了 `lib/`、行为确实改变；判红后逐字节还原并 `sha256sum -c` 复验）：
  - M1 把删掉的那行日志加回**读上限**拒绝分支 → 两条读上限用例红，输出预算那条保持绿（说明红的是日志断言，不是连带）。
  - M2 让 `readCapHidden > 0` 恒不成立（等于拆掉读上限门禁）→ 6 条红（两条计数用例、双 cap 用例、三条 read-capped 用例），证明门禁仍被测试覆盖。
  - M3 让 `fitted.clipped` 恒不成立（拆掉输出预算门禁）→ 2 条 fit 用例红。
  - M4 把同一行日志加回**输出预算**拒绝分支 → 只有 fit 那条红（另一条 fit 用例保持绿），单独证明 fit 侧的 `doesNotMatch` 也会开火。
- 门禁（现跑）：`pnpm typecheck` 0、`pnpm build` 0（`lib/client.js` 37270 不变）、`pnpm test` **497 通过 / 0 失败**；把 `tsc` 重新 emit 到临时目录与入库的 `lib/` 比对，只有 `lib/client.js` 一项差异（esbuild 产物，预期内）；`src/` 与 `lib/` 的变异标记计数均为 0。
- 顺带修掉验收探针的一处缺陷（`.agents/evidence/2026-11-07-restart-acceptance/`）：它把判据**写死**成 `44b70d4 @ 09:27:32`，所以在 `49083b7` 之后再跑仍按旧判据衡量，对早于新提交的宿主报 `PASS`——正是它存在的意义所在。改成每次现算 `git log -1 -- src/`，并把「判据推不出来」做成独立失败项（拿空值参与 `[ "$start" -gt "$crit" ]` 只会得到 `integer expression expected`，那不是判定）。三支都实测开火：宿主早于判据 → `NOT LOADED` / exit 1；判据推不出来（`PATH` 上放一个失败的 `git` shim）→ `FAIL criterion` + `FAIL load` / exit 1；宿主晚于判据（临时副本钉到 `09:27:32`）→ `RESULT: PASS` / exit 0。 另外两行 `INFO` 也改成诚实的：`errors.log` 那行原来只数某一消息的出现次数、把「有没有比重启更新」留给操作者人眼看，现在是真检查（把 `Z` 结尾的 UTC 条目时刻与 `ps lstart` 的本地时刻都换成 epoch 再比，不可解析时刻自身算失败），实测三支都开火（真实 → PASS / 伪造未来时刻 → FAIL / 不可解析 → FAIL 且不吐 `integer expression expected`）；`memory` 那行原本写「值超过 40000 就说明抬高的 cap 生效了」，而当时的 39587 低于 40000、文档长度本来也证明不了配置的 cap，改成明说它不具判别力。
- 同类的退场残留清掉一处：`.agents/evidence/2026-11-06-read-cap-writeback/probe.mjs` 仍在读被删掉的 `outcome.clipped` 与两个 pass 级隐藏计数，重跑会打印 `undefined`——取证脚本静默误报，比没有脚本更坏。改为读 `readCappedRefused` 上的计数，并在其 README 里标明该字段已删除；重跑读数 `calls 0; refusal read-capped at cap 4000; hidden 2510`、`RESULT: LOSSLESS`、exit 0。
- **需要重启宿主**：`src/` 改了，`lib/` 随提交入库；判据是「承载宿主的进程启动时刻晚于本提交」。

**project-memory（输出预算的截断视图也不再写回：`fit-capped-refused`；骨架回复不再发布 context 半边）**

- 性质：同一类缺陷的另一半收口。上一批（`read-capped-refused`，`5efaef8`）堵住了**读上限**造成的截断视图写回，但 `fitMemoryInput` 因**输出预算装不下两份文档**而做的头尾裁剪仍是「报告、不拒绝」，而回复是整篇替换——被剪掉的字符照样消失。本轮把它变成拒绝，并顺手堵住读代码时发现的一处半写。
- 缺陷 1（实测，非推断）：`.agents/evidence/2026-11-07-fit-clip-writeback/probe.mjs` 在宿主加载的 `lib/` 上跑网格，**默认 `maxOutputTokens` 32768 下就能命中**——memory 42199 + CONTEXT 16048（两者都在 45000 cap 与 32000 读上限内）时第一次 fit 干净，**截断重试的 fit 隐藏 4232 字符**；memory 45247 + CONTEXT 8164 隐藏 3218。原因写死在 `fitMemoryInput` 里：重试头寸（`max(4096, 真实思考量)`）是**从同一个 cap 里留走**的，所以「多要头寸」必然「少发内容」。这条路径此前被一个用例正面钉着（原名 `clipped follows the input that was actually sent last`，断言重试确实发了更少的内容）。
- 门禁 1（`src/project-memory/consolidate.ts`）：
  - **首次 fit** 命中裁剪 → 在模型调用之前返回 `fitCappedRefused`：状态 `fit-capped-refused`、两个产物都不落盘、`errors.log` 一条写明隐藏量与预算、回执的杠杆是 **`maxOutputTokens`（或压小文档）**，且**明确不出现 `maxMemoryChars`**——抬记忆上限买不到输出预算一个 token，给错杠杆就是死杠杆。
  - **截断重试的 fit** 会隐藏内容时**不发送该重试**：重试只为救回一个被截断的回复，不该拿存储文档换一个更长的回复。同时把失败原因改写成真实成因（`the retry was not sent because its extra headroom would have hidden …` + 杠杆），而不是沿用「被输出上限截断」那句——那句会把操作者指向门禁刚刚拒绝的同一个旋钮。
  - 缓存：该拒绝**只设节流、不进 `lastOutcome`**。那个缓存按 `maxMemoryChars` 记，而这个拒绝的杠杆是 `maxOutputTokens`，缓存它会让操作者抬了回执点名的旋钮之后仍拿到按旧预算作出的拒绝。
- 缺陷 2（实测）：`memoryChanged` 排除了 `semanticEmpty`，于是写入块整段跳过、`memoryKeptStale`（只在该块内赋值）永远是 `false`，而 `contextRefused = memoryRefused || memoryKeptStale` 因此看不到这次拒绝——**骨架回复的 context 半边照常发布**。2026-11-06 22:28:58 的现场：memory 被判「不是可写的记忆文档」原样保住，`CONTEXT.md` 却从 11439 字符被换成 3160，且没有任何一行记录这次差异。
- 门禁 2（`src/project-memory/index.ts`）：`contextRefused` 增加第三个条件臂 `memoryKeptUnderSkeleton = outcome.semanticEmpty && outcome.basisKey.trim().length > 0`。用 `basisKey`（存储在盘的 memory）而不是「有没有 context」作判据，与同处那条诊断的触发条件逐字一致；**空库时不拦**，所以新项目照样能拿到第一份 CONTEXT.md，不会被冻住。
- 用例（`test/logic.test.mjs` + `test/memory-store.test.mjs`，总量 496 → **497**）：新增 3 条（fit 拒绝含正控制、fit 拒绝不动既有 `CONTEXT.md`、骨架回复不换 `CONTEXT.md` 含空库正控制）；**6 条旧用例按新契约改写/退役**（读上限那批同样改写了 4 条）：`clipped follows the input…` → 改写成「重试会隐藏内容时不发送」；`a shortening that did not land…` 与 `a clipped pass that landed nothing…` → 改写成 fit 拒绝的两条；`the consolidation prompt sends the fitted, clipped artifacts` → 改成在**干净 fit** 下钉自适应 cap（夹具 60k CJK 现在根本到不了模型）；tier C 空骨架与 prose 回复两条的断言从「context 仍然落地」翻成「两个产物都不落」。截断重试用例的夹具从 30k CJK 降到 8k，并新增一条断言：重试**只能靠抬高请求 cap 腾地方，不能靠少发内容**。
- 变异轮（3 个变异体，全部被杀；每个都过有效性三连：`tsc` 0 错、标记进了 `lib/`、行为确实改变；判红后从 `/tmp/mutx-20261107/` 的哈希快照还原并 `sha256sum -c` 复验）：
  - M1 把门禁的 `return refusal` 改成 `void refusal`（判定还在、拒绝没了）→ fit 拒绝两条红。
  - M2 把「重试 fit 裁剪」的判定换成永不成立的比较（重试照发）→ A2 那条红，**batch R 的「重试仍会运行」保持绿**（它的夹具已改为不裁剪，两条各自钉各自的行为）。
  - M3 删掉 `contextRefused` 的第三个条件臂（保留变量引用以免触发 TS6133）→ 骨架回复那条红。
  - 第一版 M2/M3 收窄成 `if (true)` / `false && …`，`tsc` 报 TS18048 等错——按有效性三连这属于无效变异体，改形状后重跑，**没有把编译失败当证据**。
- **已知残差（本批未收口，明确记录）**：写入路径上现在**只能**产出 `updated`。`status: "clipped"` 与 `ConsolidateReport` 的落地隐藏计数（`memoryHiddenChars`/`contextHiddenChars`）已**结构性不可达**——任何会让模型看到不完整内容的路径都在模型调用前拒绝。移除它们要连带删掉 `memoryUpdateReply` 的 `clipped` 分支、`memoryLossDetail` 的一段文案，以及约 10 条用手搓 report 测回执的单测，属独立清理批次；本批保留并在此登记，避免它被当成「今天还会发生」。（**已在后续清理批次收口**：移除 `clipped` 状态、两个落地隐藏计数、回执分支与相应断言，并顺带删掉那条把两个杠杆含糊成一句的拒绝日志，见本节上方条目。）
- 门禁（现跑）：`pnpm typecheck` 0、`pnpm build` 0（`lib/client.js` 37270 不变）、`pnpm test` **497 通过 / 0 失败**、`lib/` 里三个变异标记计数均为 0。
- **需要重启宿主**：`src/` 改了，`lib/` 随提交入库；判据是「承载宿主的进程启动时刻晚于本提交」。

**project-memory（读上限的截断视图不再被写回：`read-capped-refused`）**

- 性质：一处**新增拒绝门**，改的是已有失败路径的分类而不是正常路径。用户在 22:20 问「我能直接填 64K 吗」，上一轮的答复里已经把 `maxMemoryChars` 说成「读写同一把尺」，但那条结论停在「先压文档再降 cap」的劝告上——本轮把它变成机器保证：**文档比 cap 长时，整理 pass 拒绝运行，而不是把截断视图写回**。
- 缺陷（实测，非推断）：`maxMemoryChars` 同时是读上限（注入 `loadMemorySync`、整理 `loadMemory`）。cap 低于存储文档时，模型只看到头部，而回复的 memory 是**整篇替换**，于是「照抄所见」的正常回复把尾部删掉——`.agents/evidence/2026-11-06-read-cap-writeback/probe.mjs` 的读数：6482 字符的文档在 cap 4000 下，回复落地后 **3983 字符，Pitfalls 与 Index 两节整节消失**，状态报 `clipped`，tier C 放行（它拿回复和写上限比，回复装得下）。`CONTEXT.md` 同理（`MAX_CONTEXT_CHARS` 32000 这一刀）。
- 门禁：`consolidateProjectState` 在**模型调用之前**判定 `existing.cappedDroppedChars + contextReadHiddenChars > 0`，命中即返回 `readCappedRefused` 的 outcome：状态 `read-capped-refused`、两个产物都不落盘（沿用批次 T2 的「拒绝只发布一个产物」规则）、`errors.log` 一条写明隐藏量与该侧的上限、回执照**被截断的那一侧**给杠杆（memory → 抬 `maxMemoryChars` 或压文档；context → 只能压 `CONTEXT.md`，那个 cap 是常量，给错杠杆就是死杠杆）。缓存按 cap 记，抬高 `maxMemoryChars` 的强制 pass 会重跑。
- 新增 4 条用例（`test/memory-store.test.mjs`，总量 492 → **496**）：读上限拒绝（字节不变、0 次模型调用、回执含 `raise maxMemoryChars`、`errors.log` 只有门禁那一行、不把成因错记成「回复没带 context」）、**正控制**（文档在 cap 内时照常整理，证明门不是常开）、context 侧拒绝（杠杆写成 `shorten CONTEXT.md`，且不得出现 `raise maxMemoryChars`）、抬高 cap 后缓存拒绝重跑。
- 变异轮（2 个变异体，全部被杀；判红后从 `/tmp/readcap-mut/` 的哈希快照逐字节还原并复验 sha256）：
  - M1 把 `readCapHidden` 恒置 0（等于回到门禁前）→ 3 条新用例红（拒绝、context 侧、缓存重跑），**正控制仍绿**（说明红的是门而不是夹具）。
  - M2 让拒绝仍然构造并写入 session 派生的占位 context（恢复成 `update = …fallbackUpdate(…)`）→ 红在「不得把缺失的 context 归因给一次不存在的回复」。
- 既有用例改写 4 条（都是**读上限相关**，语义已由门禁接管）：3 条读上限计数用例从「落地后报 `clipped` + 隐藏量」改成「拒绝 + 隐藏量落在 `readCappedRefused`、落地计数为 0」；「两种上限相加不互相吸收」改用单元断言（`cappedDroppedChars + fit.memoryHiddenChars == stored − fitted.text`），因为 pass 已不再在截断视图上运行。另有 1 条 fit 夹具从 60k/60k 改成 30k/30k——两个文档都必须留在**读**上限内，否则门禁先于 fit 触发。
- `docs/settings.md` 的 `maxMemoryChars` 行同步订正：原来写「下一轮 pass 写回的就是这个截断视图」，现在是「不会写回，pass 在模型调用前拒绝」。README 的速查表只写「超限按行截断并标记」，未涉及写回，未动。
- 体积：`src/project-memory/consolidate.ts` 809 → **863** 行（RULES 3.3 要求说明）。不拆分：新增的是门禁与一条 outcome 字段，它读的 `loadMemory` / context 切片 / `nextVersion` / `throttle` / `lastOutcome` 都在这个函数的闭包里，搬走就要把这五个状态一起外置，属于该批明确不碰的高风险重构。
- 门禁（现跑）：`pnpm typecheck` exit 0、`pnpm build` exit 0（`lib/client.js` 37270 不变）、`pnpm test` **496 通过 / 0 失败**、`git diff --exit-code -- lib` 在提交后为空。
- **需要重启宿主**：`src/` 改了，`lib/` 随提交入库；判据仍是「承载宿主的进程启动时刻晚于本提交」，重启由用户执行。
- **边界（本批未收口，已实测）**：门禁只覆盖**读**上限。`fitMemoryInput` 在输出预算装不下两份文档时的头尾裁剪仍是「报告、不拒绝」，而回复是整篇替换，所以**被截断后的那次重试**一旦落地，写回的就是这个剪过的视图：落地状态只会是 `clipped`，自动路径没有回执，`errors.log` 那行「given a shortened version …」也不说文件短了多少。`.agents/evidence/2026-11-06-memory-compression-headroom/cap-sweep.mjs` 现跑（当天的 CONTEXT 3160 字符、`auxModel` 带 reasoning）：第一次调用到 memory 48251 字符仍 `clipped false`；同一段文本带 4096 重试头寸时 memory 46181 起裁剪（隐藏 265）、50178 时隐藏 **5275**；用本提交前的 CONTEXT（11439 字符）实测重试隐藏 memory **5167** + context **1441** 字符。CONTEXT 长回约 **7000** 字符以上就会走到这条（实测 6000 不裁、7000 起裁 6 字符、8000 起裁 1619）。是否把它也改成拒绝是设计取舍：拒绝会让「文档大到输出装不下」的项目彻底停更，而现在的裁剪至少还能压缩——留给用户裁决。
- **一处过期注释**：落地 pass 的 `clipped` 现在只可能由输入拟合产生（读上限会在模型调用前被拒），`src/project-memory/index.ts` 里「落地隐藏计数覆盖读上限与输出拟合、命名输出预算会指错原因」那句因此半错——现在恰恰只有输出预算能造成它。改注释会移动「最后 `src/` 提交」这个重启判据，与下一批行为改动一起改。

**文档（批次档案归档 + CHANGELOG 按版本拆分）**

- 性质：纯文档重排，`src/`、`client/`、`lib/` 零改动，**不需要重启宿主**。用户 2026-11-06 在「要不要再往下做一层」里选了 **2 + 3**：归档批次档案、拆分 CHANGELOG。
- 归档：18 个 `docs/batch-*.md` 用 `git mv` 移进 `docs/archive/`（`git status` 为 18 条 rename，内容改动只有路径）；`batch-w-decision-seam-spec.md` **留在 `docs/`**，因为 `src/project-handoff/{auto,decide}.ts` 与 `test/handoff-decide.test.mjs` 直接引用它，移走会让代码注释指向空路径。新增 `docs/README.md`：生效文档表、归档表（18 行）、写作与引用约定。
- CHANGELOG：主文件 **1719 → 269 行**（拆分后、本条之外；含本条现为 278 行），只留「未发布」与 `## 版本目录`；8 个已发布版本各一份 `docs/changelog/v*.md`（标题 `###` 升 `#`，正文逐字搬移，各带一行索引回链）。搬移不是凭印象：以 `git show HEAD:CHANGELOG.md` 的原始分节为基准逐行比对，把 `docs/archive/` 前缀归一化后 **9 个分节（未发布 + 8 个版本）差异行全为 0**。
- 引用：`docs/batch-*` → `docs/archive/batch-*` 共 **46 行**（README、CHANGELOG、`docs/upstream-pi-triage.md`、`docs/vocabulary-conventions.md`、归档文件互引、`pi-upstream-triage-pass` 技能、MEMORY/CONTEXT）；归档文件里 3 处指向 `docs/` 根的相对链接补 `../`，`docs/harness/integration.md` 的证据链补一层 `../`。`.agents/evidence/` **不回改**（冻结证据里的旧路径描述的是当时读到的树），规则写进 `docs/README.md`。
- 发布流程变更：发版从「在 `CHANGELOG.md` 里新开版本小节」改为「未发布整段搬进 `docs/changelog/v<new>.md` + 目录加一行 + 重开空 `### 未发布`」；`dsh-project-context-release` 技能第 2/4 步与 MEMORY 的发布不变量同步更新。
- 门禁（现跑）：117 个受跟踪 md 逐个解析相对链接，live 文档 **0 死链**（唯一命中是 `docs/behavior.md` 用代码块演示 `INDEX.md` 行格式时写的 `[id](id/session.md)`，不是真链接）；`pnpm test` **492 通过 / 0 失败**；`pnpm build` 后 `git diff --exit-code -- lib` **为空**（源码未动，产物确定性）；`share-fit.mjs` 与 `roundtrip.mjs` 均 `sectionDropped 0 / droppedItems 0 / itemTruncated 0`、round-trip 字节相同。

**文档（README 瘦身：手册留在 README，机制搬进 `docs/`）**

- 性质：纯文档重排，代码零改动。起因是用户问「README 怎么有这么长段的文字」——`说明` 一节 101 行、单条 bullet 跨越 20+ 行、配置表的单元格 260+ 字符，一本用户手册被写成了机制论文。
- 结构：README **446 → 141 行**，只留「是什么 / 文档分工 / 四个插件 / 安装 / 命令 / 它在项目里写什么 / 配置速查表 / 行为与边界 / 常见问题 / 开发 / 更新日志 / 许可」。机制搬进四个新文件：`docs/architecture.md`（数据流、数据布局、源码结构）、`docs/behavior.md`（① 归档、①补 回填、②③④ 说明）、`docs/settings.md`（配置详解，含每个键的完整语义）、`docs/development.md`（门禁、依赖边界、破坏性变更）。
- 不丢字：搬移是**按节整块移动**而不是改写——取 `git diff -- README.md` 的 **393** 行删除行，逐行在「新 README + 四个 docs」的并集里查找，只有 1 行（`## 命令（web/交互 profile）` 标题，改名为 `## 命令`）不在原位，其余逐字存在。
- 顺带补两处缺口：README 的配置表原本**漏了 `maxMemoryChars`**（只在正文里提过），现已在速查表与 `docs/settings.md` 都补上；「21 行 / 5 布尔 / 3 枚举」这类会过期的计数不再进手册。
- 校验（现跑）：21 个 schema 键在 README 速查表与 `docs/settings.md` 均**无一缺失**（脚本对照 `PluginSettingsSchema` 实测）；五个文件代码围栏均为偶数；README 的 7 个相对链接全部可达；表格行首尾格式无一异常；`pnpm test` 仍 **492 通过 / 0 失败**。
- 边界：`src/`、`client/`、`lib/` 未动，不需要重启。

**project-handoff（`handoffRetireReplaced`：交接后是否归档被替换的旧会话，默认仍归档）**

- 性质：一处**新增配置**，默认值等于现状（`true`），只有用户主动关掉才改变行为；不动既有语义、不动停活动时机。起因是用户 2026-11-06 20:10 报「交接后老的就没了、被归档了」：20:17 那次自动交接把 `c35a7f0f` 写成归档集第 769 条，而 `scheduleRetirement` 当时是无条件的、没有配置键。
- 新增 `handoffRetireReplaced`（默认 `true`）：`performHandoff` 收尾时按它决定是否 `scheduleRetirement`。关掉时**既不归档也不停活动**——`stopActivity` 只是为了让宿主接受对「仍有工作」的会话做归档（不带它宿主直接拒绝），没有归档就没有要停的东西；代价是分叉出来的旧会话会排在自己的续接会话上面，也就是当初加退休要治的那个症状，所以文案把它写成一桩交易而不是一个自由开关。默认保留 `true`：不加配置的人看到的仍是现状。
- 六个面全部就位：`config.ts`（接口 + `DEFAULT_CONFIG` + `resolvePluginConfig` 的 `boolean(...)` 校验）、`settings.ts`（带 `volatile` 标记的 schema 字段，缺标记会让整张卡无错误消失）、`client/card-fields.ts`（`ProjectContextSettings` 与行表末行）、`locales.ts`（zh/en 的 `field.*` 与 `field.*Hint`）、README（配置表一行 + ④ 段一句）。**两个 profile 都不用改**：schema 自带默认值，缺键即取默认，不存在第 H 批那种「破坏性改名、profile 与重启必须同步」的问题。
- 判别器：新增 **1 条**用例（`handoffRetireReplaced off keeps the replaced session: nothing archived, nothing scheduled`），走真实 `apply()` 接线而非直接调函数：默认值与被显式关掉两种解析各断言一次、命令成功、**种子仍在**（正控制——排除「交接悄悄失败所以什么都没归档」的假绿）、`pendingRetire` 里没有该会话、`turn/end` 之后 `archived` 仍为空。默认态由既有用例 `a handoff retires the session it replaced, and never mid-turn` 继续钉住。总数 491 → **492**。
- 变异轮（2 个变异体，全部被杀；每个都先 `tsc` 让源码进 `lib/`，判红后再从哈希快照逐字节还原并 `diff -q` 复验）：
  - M1 去掉 `if (config.handoffRetireReplaced)` 这道门（即恢复成硬编码无条件退休）→ 新用例红在「nothing is scheduled for this session's turn end」。
  - M2 让 `resolvePluginConfig` 忽略输入、恒回默认 → 新用例红在「the option reaches the resolved config」。
- 顺带修掉两处会过期的说明：README 里「21 行 = …」改成不写数字、点名 `test/settings-form.test.mjs` 的逐键相等断言；「21 行各出现一次、5 个布尔是开关、3 个枚举」改成按字段表核对——实测今天（加本键之后）是 **21 行 / 6 布尔 / 2 枚举**，后两项在加本键之前就已经不对了。
- 门禁（现跑，不引用历史数字）：`pnpm typecheck` 0；`pnpm test` **492 通过 / 0 失败**；`pnpm build` 0（`lib/client.js` **37270** 字节；`handoffRetireReplaced` 在 bundle 里 **5** 处，`lib/shared/config.js` 与 `lib/project-handoff/perform.js` 各 **2** 处）。
- 生效复核（2026-11-06 20:32:25 重启后实测，四条互不依赖）：①host pid 82102 启动晚于最后 `src/` 提交 `8dc97c5`（20:28:48）②`dsh-live-inventory-probe.mjs --url http://127.0.0.1:38961` 四行 `active`、enabled 非 active 0、store == wrapper、`RESULT: PASS`（条目 241）③宿主派发的 `plugins/??dsh-project-context/client.js&rev=5e876189861f` 与磁盘 `lib/client.js` **前 37270 字节逐字节相同**（只多 76 字节 sourceMappingURL 尾），且含 `handoffRetireReplaced` ④`cordis_inspect_query` 的 host `Config` 对 `include:project-context` 投影出的 schema 已声明该键（`default: true`、`volatile: true`）——即卡片那一行由宿主自己声明，不是客户端单方面画出来的。
- 边界：改了 `src/` 与 `client/` ⇒ **需要一次宿主重启**。客户端 bundle 由 client-hmr 派发（刷新即可），但新键的解析在 host 半，所以重启之前把开关关掉不会有任何效果；重启后卡片上会出现「交接后归档旧会话」一行。

**文档（区分两种「归档」：① 写存档 vs ④ 交接后旧会话被隐藏）**

- 性质：纯文档（README 一段要点），不改代码、不改配置键与任何默认值；起因是用户读完 §自动归档（①）后问「为什么交接后老的就没了、被归档了」，而实际原因是 ④ 的退休步骤，不是这一节。
- 改动：README §自动归档（①）的要点列表加首条——本节的「归档」只指写 `session-logs/`；交接后的隐藏来自 ④ 的 `workspaceRegistry.archiveSession()`（硬编码、无配置键、与 `archiveEnabled` 无关）；恢复路径是侧栏「全部对话（显示已归档）」→「取消归档」，日志与存档都还在。
- 判别器：无（文档）。本批不动 `src/`、`client/`、`lib/`，故不需要重启，也不改变运行时行为。

**project-context 设置卡（模式门只留在固定比例行上）**

- 性质：一处**行为纠正**，撤回上一批对「摘要目标」这一行下的门；只改 `client/` 与重新构建的 `lib/client.js`，`src/`、配置键、profile 都没动。
- 修复 ①（门比命令更严，而且是在治一场已经治好的病）：上一批把 `handoffBudgetSummaryTokens` 也纳入模式门，固定模式下隐藏。但被隐藏的不是触发器，而是一项**预算**：`/handoff budget summary <n>` 在任何模式下都接受写入，`config.ts` 在任何模式下都校验它，而它的唯一读点在 `resolveThreshold` 的自适应分支，只服务于「目标没被完整采纳」的回执。误读的来源是旧名字「触发点目标（token）」，而同一批已经把它改成「摘要目标（仅报告）」——改名之后这道门只剩副作用：卡片比命令更严，固定模式下唯一能改这个值的控件消失，而「有覆盖值就保留该行」的例外恰好只救得起已经设置过的人（默认值反而最看不见）。真机复核（2026-11-06 18:01 用户实测报「关掉自适应后摘要目标消失」）后改回：只给 `handoffThresholdRatio` 留门，理由是它**就是**另一模式的触发器；两者的区别写进行表上方的注释，免得下次又按「对称」把它们一起藏。
- 门（语义未变，仍写在 `rowVisible`）：当前模式不读这一项**且**用户注意力不在它上面时才隐藏；存储层已有覆盖、或非法草稿阻塞保存时保留该行。区别只在于不再有第二行受它管。
- 判别器：不为凑数字新增用例，改写 **3 条**既有用例并新增 **1 条**断言（`row("handoffBudgetSummaryTokens").appliesWhen === undefined` 且两种模式下都可见；`card-render` 的互换用例改为「只有比例行互换、目标行留在两种模式」；numeric 输入用例对摘要目标加验固定模式）。总数仍是 **491**。
- 变异轮（2 个变异体，全部被杀；每个都先改源码让目标用例变红，再从哈希快照逐字节还原并 `diff -q` 复验）：
  - M1 把摘要目标的门加回去（即撤回本批修复）→ **3 条**红：`the report-only target keeps rendering…`、`handoffBudgetSummaryTokens must render an input`、「`appliesWhen` … must not be gated」。
  - M2 把门的比较反向（`===` → `!==`）→ **5 条**红：比例行在自适应下反而出现、`Reset` 预览用例、被覆盖的门行用例等 —— 证明剩下的那道门仍承重。
- 门禁（现跑，不引用历史数字）：`pnpm typecheck` 0；`pnpm test` **491 通过 / 0 失败**；`pnpm build` 0（`lib/client.js` **35750** 字节，本批前 35579）；bundle 里 `appliesWhen` 由 4 处降到 3 处，`rowVisible` 仍是 2 处。
- 边界：`src/` 未动 ⇒ 不需要为宿主代码重启。客户端 bundle 也已实测在派发、同样不需要重启（2026-11-06 18:24，宿主 pid 58434 于 10:51:53 启动）：宿主**确实**把 bundle 缓存在内存表里按请求派发（`packages/client/modules/src/index.ts` 的 `buildCombo` 用 `record.bundle`），但这份 host 的组合里挂着 `include:client-hmr @deepseek-ai/dsh-client-hmr`（由 `@deepseek-ai/dsh-web-app` 的 `cordis.patch.yml` 插入），它以 500 ms 统计轮询每个条目的 bundle 元数据、变化时调 `clientModules.rebuilt()` 重读磁盘并重新 compose，页面侧 `entries.reload()` → `replace()` 再失效模块缓存、拆旧 fiber、重新 `import` 并 `entry.refresh()`。决定性判别（不看 UI）：带签名 cookie 取 `/`，从 `window["__DSH_BOOT__"]` 读本插件的 combo URL（本次 `plugins/??dsh-project-context/client.js&rev=805a30a0ec8f`），取其字节与 `lib/client.js` 比对 —— 前 35750 字节逐字节相同，只多 76 字节的 `;\n//# sourceMappingURL=…` 尾。README 的设置表同步了这一行的可见性说明。

**project-context 设置卡（预算金额本机校验 / 保存失败按成因说真话 / 模式下预览修正）**

- 性质：两处修复 + 一处**上一批引入的缺陷**修正（由独立对抗审查发现），都带变异校验过的回归测试。
- 修复 ①（越界只留给 Host 拒绝）：`handoffBudgetSummaryTokens`（8000–200000）与 `handoffBudgetRecentTokens`（0–200000）在卡片侧接受任意数字，越界（含 `z.natural()` 不接受的非整数）要等到 Host 拒绝，用户看到的是那句「保存未生效」。四处各自写着同一对数字（`settings.ts` 的 schema、`config.ts` 的校验、`/handoff budget` 的解析、卡片的行表），现收成 `limits.ts` 的 `MIN/MAX_HANDOFF_SUMMARY_TOKENS` 与 `MIN/MAX_HANDOFF_RECENT_TOKENS`；卡片行新增 `bounds` + `boundedNumberField`，越界与非整数草稿在本机就被拒、保存按钮置灰、写入根本不会发出。命令的两条错误文案也改为插值同一对常量（文本不变）。
- 修复 ②（一个 `failed` 布尔掩盖两种成因）：平台 `SettingsFormScope.mutate` 只返回 `boolean`，`SettingsFormModel.save()` 把「值被 Host 拒绝」与「revision 冲突」都塌成 `failed = true`，异常还被 `catch (_error)` 吞掉 —— 所以「请重试」对两种成因都错。卡片改为从**文档 revision** 判别：记录本次脏会话第一次编辑时的 revision，失败后比较，未动＝值被拒（同一草稿重试必然再失败），已动＝有并发写入（暂存 revision 已失效，重试同一草稿同样必然再失败，只能刷新重建）。`formLabels` 按成因选文案（`chrome.saveFailedRejected` / `chrome.saveFailedConflict`），判别不了时退回原来的合并句。
- 修复 ③（上一批的模式门读错了输入，**真 bug**）：门读的是**格式化后的草稿文本**。`Reset` 暂存的草稿由空的合成层格式化而来（`format(undefined)` → `"false"`），而写入是 `unset`、会在 Host 侧重新继承 schema 默认 `true` —— 于是在「自适应阈值」上按重置，卡片会显示固定比例行、隐藏摘要目标行，与实际保存结果相反，且这个反状态持续整个编辑过程。改为读**待写入后的有效模式**：有暂存 `set` 用草稿，否则用 Host 供的已解析值。
- 顺带修掉审查指出的声称不准与门禁缺口：①「触发计算不读它」被写成「校验不读它」——`config.ts` 在任何模式下都校验两个键；②「只在 `threshold.ts` 一处出现」实为两处；③`ratio.ts` 把失败机制写成「下次加载时丢弃」，实际是**写入时拒绝**；④`rowVisible` 文档替暂存 `unset` 开了它并不提供的例外；⑤摘要目标的「默认 64000」改为读 `limits.ts` 的 `DEFAULT_HANDOFF_SUMMARY_TOKENS`（`config.ts` 带 `node:` 模块，浏览器侧不能导入——第一次尝试正是这样构建失败的）；⑥比例 hint 的「早于 dsh 内置压缩的 0.8」只在范围下半段成立（`compaction-basic` 默认 `0.8`，回源核对），改成条件式；⑦`numeric` 此前无测试（拖掉 `|| row.kind === "ratio"` 全绿），补 `inputMode` 用例；⑧`pnpm test` 现在也跑 `tsc -p tsconfig.client.json --noEmit`（此前 `client/**` 只在 `pnpm typecheck` 里编，`test` 绿不代表客户端类型对）；⑨测试的可见行推导改为读卡片真实投影，不再在测试里手搓第二份镜像；⑩比例越界改读 `MAX_THRESHOLD_RATIO`。
- 判别器：新增 **7 条**用例（预算边界端到端：`7999` / `200001` 拒、`0` 收；`boundedNumberField` 与 schema `meta.min/max` 逐字相等且 `min`/`max` 收、`min−1`/`max+1`/小数拒；失败成因三态渲染；`formLabels` 按成因选键；模式切换立即互换；**`Reset` 预览修正**；比例与两个金额行都渲染成 numeric 输入）。
- 变异轮（3 个变异体，全部被杀，逐个先编译进 `lib/` 并确认标记在位，每次从哈希快照还原后复验逐字节相同）：N1 去掉边界的本机校验 → 2 条边界用例红；N2 把成因塌回单一 `failed` → 只有「失败成因」用例红；N3 把门改回读草稿文本 → 只有「`Reset` 预览」用例红。
- 门禁（现跑，不引用历史数字）：`pnpm typecheck` 0；`pnpm test` **491 通过 / 0 失败**（本批前 485）；`pnpm build` 0（`lib/client.js` 35579 字节）；`lib/` 与新鲜 `tsc --outDir` 编译 `diff -rq` 只剩 `client.js`。
- 边界：`src/` 与 `client/` 都改了 ⇒ 仍需一次宿主重启（用户操作）。不改配置键、不加依赖、两个 profile 无需改动。README 的设置表与命令表同步。

**project-context 设置卡（阈值行按模式显示 / 比例三种写法 / 保存失败文案）**

- 性质：三处**一致性修复**（不是等价重构）。三条各自有独立的成因与判据，互不依赖。
- 修复 ①（名字与实际作用不符）：`handoffBudgetSummaryTokens` 的卡片标签是「触发点目标（token）」，但它**不移动触发点**。自适应分支的阈值只有两个来源 —— `qualityLimit` 的膝曲线/上游上限与 `capacityLimit` 的可用窗口（`capacityLimit` 里的 `keep` 读的是 `handoffBudgetRecentTokens`）——`handoffBudgetSummaryTokens` 在 `threshold.ts` 只出现两处（`const asked = room.overhead + room.keep + config.handoffBudgetSummaryTokens` 与回执里对它的插值），都只服务于「没被完整采纳」的回执；`handoffRoom()` 不读它，固定模式下一次都不读。标签改为「摘要目标（仅报告）」，hint 明说不移动触发点、不产生模型调用。同时新增卡片侧的**模式门**：`client/card-fields.ts` 的 `FieldRow.appliesWhen` + `rowVisible()`，让固定比例行只在 `handoffThresholdAuto` 关闭时渲染、摘要目标行只在开启时渲染 —— 两个控件不再并排出现在同一个模式下，读起来才不像两个竞争触发器（例外：该行带覆盖值或非法草稿时仍渲染，理由见下一条「门」）。
- 修复 ②（同一设置的两套输入规则）：固定比例在命令里接受 `0.4` / `40` / `40%`（`parseRatio` + 注释里的三个样例），卡片却只收小数 —— 平台的 `settingsNumberField.parse` 就是 `Number(text)`，于是 `40` 原样提交被 `z.number().min(0.1).max(0.95)` 拒绝（保存失败且无解释），`40%` 更早死在 `Number("40%") === NaN` 判 invalid、保存按钮直接置灰。折叠规则收进新文件 `src/shared/ratio.ts` 的 `parseRatioInput`，`src/project-handoff/command.ts` 的 `parseRatio` 与卡片新增的 `ratio` 行**共用同一份实现**；边界仍只来自 `limits.ts` 的那一对。这不是新增一种写法，而是把已存在的那一种接到卡片上，并顺手消灭第二份副本。
- 修复 ③（错归因的文案）：`chrome.saveFailed` 原文「保存未生效，请重试」把两种互不相同的成因说成一种可重试的失败。平台的 `SettingsForm` 只有一个 `failed` 布尔，而 `SettingsFormModel.save()` 的两种失败都**不可重试**：值被 Host 拒绝（同一个草稿、同一套校验，必然再失败）与 revision 冲突（`this.baseline ??= scope.getSnapshot()` 只在首次编辑时取值，失败后不刷新，重试仍拿旧 revision）。改为「值可能被拒绝，或设置已被别处改动；修正后重存，或刷新页面再试」，给出真正能救场的两个动作（改值、刷新重建草稿），而不是一个无效的「重试」。
- 门（唯一的语义判断，写在 `rowVisible` 里）：只有当「当前模式不读这一项」**且**「用户注意力不在它上面」时才隐藏。存储层已有覆盖、或草稿非法阻塞保存时保留该行 —— 否则那个值会变成看不见也重置不了，非法草稿更会挡住保存而页面上没有任何控件能修好它。暂存的 `unset`（重置/清空）**不**保留：它虽然不可见但仍会落地，因为 Host 会重新继承 schema 默认值。
- 判别器：新增 **8 条**用例（`test/card-render.test.mjs` 3 条：两行随模式互换、被覆盖的门行仍可见且只多一行、比例行把 `0.4`/`40`/`40%` 都 stage 成 `0.4` 并把 `0.96` 挡在 Host 之外；`test/settings-form.test.mjs` 5 条：`rowVisible` 五态表、门只能指向布尔行且不能自指、`ratioField` 的三种写法与越界拒绝、旧 `saveFailed` 文案不得回归、hint 承诺的百分比写法必须被卡片接受）。
- 变异轮（5 个变异体，全部被杀；每个都先编译进 `lib/` 并确认标记在位）：M1 把摘要目标行的门反向（`text: "false"`，即自适应开启时反而隐藏、固定模式下反而显示）→ 2 条模式用例红；M1 最初试的「把门写成一个永远不满足的乱字面量」在把 `FieldGate.text` 收窄成 `"true" | "false"` 之后**编译失败**，按规矩无效变异的红不算证据，故改成反向门；M2 把 `ratioField` 的 parse 换回 `Number(text)` 直通 → 3 条比例用例红；M3 删掉 `src/shared/ratio.ts` 的 `> 1` 折算 → 卡片 3 条 **加** `test/logic.test.mjs` 的「parseRatio accepts only the range…」与 settingPatch 用例一并红（同一份实现同时被两个面钉住，正是本批要的证明）；M4 把 `chrome.saveFailed` 退回旧串 → 只有文案门红；M5 把 hint 里的 `40%` 换成解析不了的写法 → 只有 hint 门红。
- 门禁（现跑，不引用历史数字）：`pnpm typecheck` 0；`pnpm test` **485 通过 / 0 失败**（本批前 477）；`pnpm build` 0（`lib/client.js` 30731 字节，本批前 28575 —— 增量来自文案与两处新逻辑，不是重复打包）。
- 边界：`src/` 与 `client/` 都改了 ⇒ **需要一次宿主重启**才上线（用户操作；桌面重启脚本与 `/memory update` 属用户）。不改配置键、不加依赖，两个 profile 无需改动。README 的设置表已同步这两行的实际作用与三种写法。

**project-handoff（`SH-1` 拆除：投影读取改用声明类型，删除手写结构化视图）**

- 性质：**行为等价重构 + 一处依赖声明**，无「修复」项。`src/project-handoff/runtime.ts` 的 `SessionProjectionsLike` 删除，`projectionEnvelope` / `measuredContext` 改用 `SessionProjectionRegistry`，`gate.ts` / `command.ts` 的 `ctx.get("sessionProjections") as …` 断言一并去掉；运行时逻辑与回执文案一字未改（`projectionEnvelope` 仍对畸形值返回 `undefined`，仍不从两个计量器输出相减）。
- 为什么**必须两个包**：那一行同时依赖两份类型 —— `sessionProjections` 服务由 `@deepseek-ai/dsh-session-projection` 声明，而 `contextBreakdown` 这个**键**不在该包自己的 `SessionProjectionMap` 里，由 `@deepseek-ai/dsh-token-meter` 的 module augmentation 贡献。实测只 import 前者时键类型塌成 `never` 且属性报不存在；两个都 import 时 0 错。
- 依赖只进 `devDependencies`（`0.1.7-rc.2`，与我们六包同线），**不进 `peerDependencies`**：两个服务都是可选的（缺失时 `projectionEnvelope` 返回 `undefined`，回执写 `harness envelope unavailable`），而 peer 是「宿主必须提供」的契约；加进 peer 会把门禁从 6 条收紧到 8 条，并让能优雅降级的老宿主在 peer 判定上失败。类型导入编译后擦除，运行时不依赖它们。
- 判别器：新增 `test/projection-typing.test.mjs` + `test/fixtures/projection-typing/`，一次 `tsc` 跑两个同构 fixture —— 正确键必须 0 诊断，差一个字的键必须恰好 1 条且点名该键。**两侧对照都真开火**：去掉 token-meter import → 正控制挂；把读取降级成 `: any` → 判别器挂（这一步还暴露并改掉了判别器自己的一句错误归因：它原本会把「两个 fixture 都通过」报成「tsc 没编译 fixture」）。
- 变异轮（3 个 mutator，全部被杀，逐个先编译到 `lib/` 并确认标记在位）：M1 `projectionEnvelope` 只返回 `systemTokens` → 2 条回执用例红；M2 删掉「两个字段都不是数字 → `undefined`」守卫 → 1 条红；M3 `measuredContext` 把 `envelopeSource: "projection"` 错标成 `"meter"` → 1 条红。恢复走哈希校验过的 `/tmp` 快照，`sha256sum -c` 通过后重建，`lib/` 0 标记。
- 门禁（现跑）：`pnpm typecheck` 0；`pnpm test` **477 通过 / 0 失败**（本批前 476）；`pnpm build` 0（`lib/client.js` 28575 字节）；`src/` 里 `SessionProjectionsLike` 0 命中。
- **纠正预检的一处错结论**：预检称同线加载 `peers check` 输出 `No peer dependency issues found` —— 那条跑在干净 `/tmp` 沙盒，pnpm 自解析到 cordis 4.0.5。真实锁文件钉 `cordis 4.0.2`，而 `dsh-agent@0.1.7-rc.2` 本来就要求 `~4.0.4`；把 HEAD 三件套复制到 `/tmp` 用同一把 pnpm 跑对照，未满足的仍是同样 **2 条**（`cordis`、`schemastery`）。所以真实结论是**新增 0 条未满足的 peer 名**，不是「0 条」；这 2 条是既存残差，修它要动 cordis / schemastery 的 devDeps，属独立批次。
- 判据从「版本相等」改为「**锁定版签名是运行线的子集**」：0.1.7 的 `snapshot` 入参是 `readonly Extract<keyof SessionProjectionMap, string>[]`，运行线 `0.2.2-rc.1` 是 `ProjectionKeySelection`（同一数组形式 ∪ `ReadonlySet`）；返回的 `ProjectionSnapshot` 与 `ContextBreakdownProjection` 两线逐字相同。下一版若把 `keys` 收窄或改返回形状，判别器会先红。
- 边界：**改了 `src/` ⇒ 需要一次宿主重启才上线**（用户操作）；`SH-2`（`ctx.get` 读未声明服务）**没有**因本批消失，这一批只换掉了类型。证据与复核命令：`.agents/evidence/2026-11-05-sh1-removal/README.md`。

**project-handoff（批次 W：决策 seam —— 把自动交接的闸链切成「纯判据 + 适配器」）**

- 性质：**行为等价重构**，不是缺陷修复 —— 因此本条目没有「修复」项，那句「修复都伴随变异校验」不适用本批；判别力证据来自下面 A–F 的实测变异。目的只有一个：把「该不该交接」的判断从宿主读取里切出来，让第二个宿主能复用同一份判据，而不是各写一套阈值。
- 结构：新增 `src/project-handoff/decide.ts`（`decideAutoHandoff(inputs, config) → Decision`，只**比较**不**求解**）与 `src/project-handoff/measure.ts`（`MeasuredContext` / `ThresholdTerms` 的纯类型宿主）；`auto.ts` 由十六个 `if` 串起的闸链改为「取 inputs → `decide` → 按 `Decision` 派发」，新增 `gatherDecisionInputs` 作为唯一的宿主读取点；`gate.ts` / `runtime.ts` 相应收口。
- 抽链必须保住的五条（逐条有据）：① 闸序 = 阈值 → 未答问题（**仅当** `handoffPendingQuestion: "defer"`）→ 在跑子代理 → 无可丢 → 交接；② `GateInputs` 带整块 `MeasuredContext`，**绝不**折成 `totalTokens` —— 跨底座相减是本仓库最坏的缺陷类；③ 五个具名结局（`handoff` / `defer(question|subagents)` / `skip(nothing-to-drop)` / `below-threshold` / `unmeasurable`）不再是静默 `return`；④ 副作用（`recordHandoffGate`、三行决策日志、`skippedSince` 节流、`recordHandoffDeferral`）全部留在适配器；⑤ 输入的**读取顺序**保持旧形态（读未答问题 → `await` 子代理列表 → 取 split）：顺序决定每个输入看到哪一版会话快照，跨 `await` 期间子代理结算的微任务仍会跑。
- `measure.ts` 的存在理由（实做才发现）：判据 1.2 要求核心不加载宿主包，而 `MeasuredContext` 原本在 `runtime.ts`，后者 import `dsh-session`；`verbatimModuleSyntax` 下 type-only import 仍发射 `import {}`，是**真加载**。两个纯类型搬出后，「零宿主依赖」成为可实测项而不是声称：`decide.js` 的传递 `@deepseek-ai/*` import 计数实测 **0**。
- 判别器：新增 `test/handoff-decide.test.mjs`（**14 条**，每条自带阴性对照）＋ `test/logic.test.mjs:3117` 一条适配器级「未越线 ⇒ 不交接」双边对照（同一条会话、同一份可丢内容，只改 meter 读数：50 000 对 40 000 触发器红、120 000 正控绿，断言 `controller.create` 调用数 0 对 1）。变异实测**如实写**：六个变异里只有 **B**（`guard.ts:183` 的 `?? outstandingSubagents(...)` → `?? []`）被**既有**用例独立抓到（3 条）；A/C/D/E/F 只红本批新写的文件，属「自己写的测试验证自己写的实现」，证明力弱于 B。C 曾证实删掉阈值闸时**既有 461 条一条不红** —— 缺口不是本批引入的（旧代码同形），但本批把它显式化并补了门禁；F 曾证实两个 profile 都在用的 `wait` 分支 0 覆盖。
- 第二轮独立对抗审查（两名只读审查者，攻击面：行为等价 / 测试判别力）改掉的七条，逐条先复现再改：① **读序被交换**（真行为差异）：旧形态「读未答问题 → `await` 子代理列表 → 取 split」被抽成「取 split 在前」，已恢复旧序并把「此顺序不能顺手整理」写进 `gatherDecisionInputs` 的注释；② **`refusal` 是死链**：`gate.ts` 产出 → `GateInputs` → `Decision`，全仓无人读（`/handoff status` 在 `command.ts:137` 自己算），已整条删除，顺带省掉每次 `turn/end` 一次纯计算；③ **`wait` 分支零覆盖**（判 blocking）：变异 F 补用例前 0 红、补后红 1 条；④ `switch` 缺**穷尽守卫**：加 `assertNever(decision)`（参数类型 `never`），第六种结局变成编译错而不是静默「不交接」，运行时零开销；⑤ 注释数字算错：那条适配器用例写「~15 000 token / `/4` 启发式」，实为 `CHARS_PER_TOKEN = 3.5`、50 042 字符（`MAX_CONVERSATION_CHARS = 50 000` 截断 + 标记）→ **14 298**，结论（≥ 8 000）不变但推导改对；⑥ 锚点与失效引用：`gate.ts:55` 实为 `:56-57`，且 `decide` 从不读 `contextWindow`（归因也错）；用例里的「§5 row 1/2/4」指向已不存在的编号表、其中一条还引了文件自己判为**无效**的变异 —— 已改为直接描述那处编辑；⑦ c12 的负控写错：它钉的是「floor 忽略 envelope」而非「决策输出折成裸数」，已改正并写明为什么。
- 门禁（现跑，不引用历史数字）：`pnpm typecheck` 0；`pnpm test` **476 通过 / 0 失败**（本批前 461：S2 新增 13 条、补门禁 1 条、第二轮 `wait` 1 条）；`pnpm build` 0（`lib/client.js` 仍 28575 字节）；`lib/` 与新鲜 `tsc --outDir` 编译 `diff -rq` 只剩 `client.js`。
- 边界：**行为等价 ⇒ 不为行为重启宿主**；但 `lib/` 已变，要在线证明「跑的是新代码」仍需一次宿主重启（用户操作）。不改配置键、无新依赖、两个 profile 无需改动。登记残留（规格 §7）：① 每次 `turn/end` 现在都会算一次 `handoffSplit` 与一次子代理列表（旧形态只在闸 3/4 通过后才算）—— 两者自身无持久写入，但这是**真实成本前移**，不是「无副作用」；未越线时多一次宿主观测，且读序一变就改变决策看到的快照；要省只能让核心接受惰性输入，不能把闸搬回适配器（那会重新造出两处判据）。② `triggerSeq` 仍在适配器侧传递。③ `below-threshold` / `unmeasurable` 首次有名字，但不加日志、无新行为。规格 `docs/batch-w-decision-seam-spec.md`，只读审计 `.agents/evidence/2026-11-03-handoff-decision-seam/audit.md`。

**project-handoff（批次 U1：种子读 append-origin 日志 —— 压缩不再让后继把摘要当对话收下）**

- 修复（缺陷类：错误归因）：**交接的五个读取点此前都读 `session.deriveMessages()`，也就是模型可见的 surface，而压缩 checkpoint 恰恰是 surface 上的一个「替换副本」**。于是一次压缩之后，种子交给后继的「对话」是那段对话的**摘要**，而不是对话本身：`<recent-conversation>` 里是被压缩过的分支，`<read-files>` / `<modified-files>` 丢掉压缩 span 里的全部 read/write/edit，未答问题的 defer 门看一眼 surface 会认为「没有未答问题」，回执报的语种可能和种子实际渲染的语种不同。后继被告知「这是本会话说过的话」而实际拿到摘要 —— 本仓库最坏的缺陷类（把一种失败归因成另一种原因）。dsh 没有 pi 的 `session_before_compact` 可取消钩子，但日志是 append-only 的，而这个差异本来就不需要取消压缩才能解决：读 append-origin 事件即可让被摘要的 span 回来、让顶替它的摘要消失。
- 修复（同一个 seam）：`src/shared/conversation.ts` 新增 `conversationMessages(session, source)`，`source` 为 `surface`（默认，行为不变）或 `append-origin`；`conversationMessageSections` 透传同一参数。append-origin 不是「再折一遍 surface」，而是走 append-only 日志、把每个 append-origin 事件交给会话自己的 `deriveEventMessage` 投影 —— 所以日志侧的 message 投影仍然生效，恢复出来的消息保持其持久身份。project-handoff 的五个读者改读 append-origin：`readSessionInputs`（`pendingQuestion` defer 门 + 种子里的待答/决定块）、`handoffLabel`（续接会话命名）、`fileOperations`（文件索引）、`sessionLanguageMessages`（回执与门记录的语种）、`handoffSplit`（尾料与语种判定的共同来源）。
- 判别器（`isReplacementSurfaceEvent`，而不是 `isAppendSurfaceEvent`）：判断「这是不是顶替别人的副本」，不是「这是不是一次追加」。上游对**活会话**把这条区分做得很硬 —— `surfaceOpOf` 直接拒绝没有标记的 surface 事件，fork 又是整段复制事件（`buildForkSeed` 切片前缀）因而保留标记 —— 所以这个容忍只对「手工构造的会话对象」成立（本插件的测试就是这种对象，不能被静默截短）。没有标记的事件不可能在顶替别的节点，因此按追加读。三个替换生产者两条路径已逐个核对：压缩 checkpoint → `replace`（原 seq 不在 `projectedMessages` ⇒ 读回原文）；tool-result pruner → `replace`（读回剪枝前更长的原文，section 自己的渲染上限仍然生效）；image-offload → `project`（日志投影胜出，恢复出的仍是投影后的消息）；boundary / job / meter 这类纯日志记录不产生消息，`deriveEventMessage` 对它们返回 null。**退化兜底**（投影为空时回落到 surface）是完整性保证、不是生产路径：`replace` 只能引用更早的 seq、fork 复制整段、`snapshotEvents()` 从 seq 0 起，所以任何有消息的真实会话至少有一个 append-origin 事件；它存在只是为了手工构造的会话对象读到的对话不会比这个 seam 之前更少。
- 判别器（测试）：新增 `test/handoff-durable.test.mjs`（9 条）与夹具模块 `test/session-views.mjs`（`sessionViews` / `compensatingSessionViews`：后者按上游 compaction producer 的形状造「checkpoint 替换 + 原事件仍在日志里」）。九条每条都带**阴性对照**，证明夹具真的会失败：surface 读法确实丢掉被摘要的 span、确实拿不到用户母语样本、确实只剩 checkpoint 节点 —— 不是空夹具上的假通过。
- 判别器（变异，四条各自只红目标项）：① `readSessionInputs` 回退 surface → 只红「open question ... counts as pending」；② `sessionLanguageMessages` 回退 surface → 只红「receipt's language is the seed's language」；③ `handoffLabel` 回退 surface → 只红「named after the user's own words」；④ 把谓词换成朴素的「不是 append 就跳过」→ 只红「no surface marker is read」。第 ④ 条两次失败后才有效，两次都是真教训：先是因为夹具全是无标记事件、日志投影为空、**退化兜底把消息救了回来**（于是必须先造一条有标记 + 一条无标记的混合夹具）；再是因为被替换掉的符号变成未引用、`tsc` 报 `TS6133` 使变异体根本没跑起来（无效变异的红不是证据）。
- 修复（同轮，测试发现范围）：`node --test` 会把 `test/` 下**任何**模块当测试文件，一个只导出夹具、不注册断言的模块会被记成 1 条通过 —— 于是夹具模块会带来一条恒绿的幽灵用例（461 会报成 462）。test 脚本从 `node --test` 收窄为 `node --test 'test/**/*.test.mjs'`：保留递归发现，只跑真正的用例文件。本仓库此前 `test/` 下没有任何非 `*.test.mjs` 文件，这条幽灵是本批新文件引入的。
- 独立审查：本批的第五个读取点 `handoffLabel` 是**只读对抗式审查**发现的（首轮四处修复漏了它），并先用真实压缩夹具探针复现（`handoffLabel(surface) = "9f3c1a2b"` 而期望是用户原话）再采纳。审查同时指出两处注释把「无标记事件」的来源说成了「迁移或 fork 的前缀」—— 那是**事实错误**（上游会拒绝这种日志、fork 保留标记），已改正为「手工构造的会话对象」。同理修正了 `isSurfaceEligibleType` 守卫的注释（它与上游 fold 对齐、不是防缺陷）与退化兜底的注释（完整性保证、非生产路径）。
- 门禁（现跑，不引用历史数字）：`pnpm typecheck` 0；`pnpm test` **461 通过 / 0 失败**（本批前 452，新增 9 条）；`pnpm build` 0（`lib/client.js` 仍 28575 字节）；`lib/` 与新鲜 `tsc --outDir` 编译 `diff -rq` 只剩 `client.js`。
- 边界：改了 `src/` 行为 ⇒ **需要宿主重启才在线**。不改配置键、无新依赖、两个 profile 无需改动。登记残留：① `append-origin` 读法会让一条**被替换**的 assistant 回复仍然被读到这里（安全方向：模型真问过的问题一定被带上，被摘要替换掉的旧版本不会）；② `pendingQuestion` 那条是防御性的 —— 未答问题按定义是最后一条消息，通常落在压缩保留的尾部，实战够不到，但同一逻辑必须读同一来源；③ 语种不一致那条属于**实用**缺陷（回执报 `en` 而种子渲染 `zh`），可复现；④ 审查第 3 条（夹具不是上游真实事件信封形状，含 `sourceEventSeqs`）与本批范围外的 `conversationText` 仍读 surface，都未在本批处理。

**project-handoff（批次 U：交接种子说明「带入了多少」—— 三态 carry 行，与 pi post-J 对齐）**

- 裁决（用户 2026-10-26）：交接要「和 pi 一样」—— `handoffBudgetRecentTokens` 回到 `DEFAULT_CONFIG` 的 **20000**（pi 的默认值），两个 profile 里显式写的 `0` 一并改掉。那个 `0` 是生成式摘要还在的时代定的；批次 J 删掉摘要后它的含义变成「什么都不逐字带」，所以上一轮的回答不会跟着交接走（现场：问题被 `## 用户最后一次输入` 带过去了，回答没带）。
- 修复：**种子此前只有一句「已原文带入」，且只在有尾料时出现**；`0` 预算下它整句消失，后继无法区分「什么都没带，去读日志」与「本来就没有要知道的」，而尾料里只要有一条消息被渲染上限裁过，那句话仍然说「原文带入」—— 一次错误归因。现在 carry 行恒在，按 pi 的 `carryKept` / `carryTrimmed` / `carryNothing` 三态取值：`src/project-handoff/language.ts` 新增 `continuationTrimmed` / `continuationNothing`；`src/shared/conversation.ts` 的 `ConversationSection` 增 `clipped`（4000 字符消息上限 / 1500 字符工具结果上限，渲染时判定）；`handoffSplit` 返回 `trimmedTail`，经 `perform.ts` 的 `handoffArtifacts` 传到 `continuation`。carry 行移到 preamble 之后（pi 的位置），`<recent-conversation>` 块自此只装尾料。
- 修复（同轮，去重）：**`## 用户最后一次输入` 块不再和尾料同时出现**。它本来是为 `0` 预算造的（`904152d`：一条已解决的询问被后继再问一遍），而尾料本身就含那条输入；现在条件收敛为 `tail.length === 0`，即「尾料带不了它时才渲染」。带尾料时结尾回到 usual closing，`pending` 块不受影响（pi 也有）。
- 判别器：新增 `test/handoff-carry.test.mjs`（9 条：三态各一、工具结果上限、`0` 预算、块的去重正反两例、pending 两态、六种形状仍被 `isHandoffContinuationText` 认作自家种子 + 一条结构负例、wiring 传递、双语）。两个变异体都 `tsc` 0 错、标记进 `lib/` 已核对、`src/` 从 `sha256sum` 校验过的 `/tmp` 快照恢复、重建后 `lib/` 0 标记：① `continuation` 的 trimmed 支恒走 verbatim → 打红 3 条具名用例；② 决策块去掉 `tail.length === 0` 条件 → 只打红「块只在尾料带不了它时渲染」。
- 离线见证：`.agents/evidence/2026-10-26-handoff-carry-20000/` 的 `probe.mjs` 驱动构建后的 `lib/`，打印 20000 与 0 两种预算下的真实种子，`RESULT: PASS`（退出码按因分 10/11/12/13）；`probe-output.txt` 是现跑输出。
- 门禁（现跑，不引用历史数字）：`pnpm typecheck` 0；`pnpm test` **452 通过 / 0 失败**（本批前 443，新增 9 条）；`pnpm build` 0（`lib/client.js` 仍 28575 字节）；`lib/` 与新鲜 `tsc --outDir` 编译 `diff -rq` 只剩 `client.js`。
- 边界：改了 `src/` 行为 ⇒ **需要宿主重启才在线**。同一次重启还覆盖两处 profile 改动（备份 `~/.dsh/profiles/*/cordis.patch.yml.bak-20261026-1715-*`）：① desktop 与 web 的 `handoffBudgetRecentTokens: 0 → 20000`；② desktop 那条 `disabled: true` 的 `subagent-codex-tool` 里过期的 `backgroundMode: one-shot` 删除（该键自 0.2.1-alpha.2 起不在 `tool-subagent` 的 Config schema 里，schemastery 不拒未知键 ⇒ 一直被静默接受、无作用；两处注释同步改写成「已删除」，免得继续把死键写成活约束）。登记残留：尾料开起来后种子会带上整段最近对话（最长约 20000 token 的字符预算），比 `0` 时更长；「过长的单条消息被裁剪」的说明只在确有裁剪时出现（`trimmedTail`），此后继能自行决定要不要去日志取全文。`test/context-injection.test.mjs` 读的是仓库自己的 `MEMORY.md` / `CONTEXT.md`，插件在别处并发整理时会瞬时打红（本批遇到一次、三连跑复绿），不是本批引入。

**project-memory（批次 T2：被拒回复不得发布其 context 段 —— 一次拒绝不落半个 pass，第十次 pi triage）**

- 修复：**context 写入对所有结局都执行，于是被插件拒绝存储的回复仍然整文件替换 `CONTEXT.md`**。`src/project-memory/index.ts` 的写半段里，context 块排在 `stale-context` 与 `lossy-refused` / `partial-refused` 的返回**之前**，而 context 是整文件替换 —— pi 的现场案例是一条被策划过的 open-task 列表被旧快照改回来（`11bd38a`）。现在写入以 memory 半边为闸：`contextRefused = memoryRefused || memoryKeptStale`，被拒 pass **两个产物都不发布**；日志按「回复自带 context / 本地占位 fallback」分两支，既不留下静默 no-op，也不把占位说成回复的 ctx 段。`/memory update` 的 `stale-context` 状态随之不可达，已从状态联合与回执分支删除，`lossy-refused` / `partial-refused` 回执里已成死码的「The context was updated」子句一并删除。
- 裁决（用户 2026-10-20，选项 A「严格对齐 pi」）：fresh 项目那个由**活会话首条用户消息**生成的 `fallbackUpdate` 占位 context **也不落盘** —— 它不是被拒回复的 context，但被拒 pass 是「什么都没决定」的 pass，所以什么都不发布；pi `56dda5d` 的 fresh-project 教训由此在本地实现（占位被跳过的日志不再声称「previous CONTEXT.md stays effective」）。
- 判别器：新增 `test/refusal-publish.test.mjs`（3 条：被策划的 `CONTEXT.md` 逐字节不变；fresh 项目拿不到占位；**正向对照** —— 同一 fresh 形状无拒绝时占位照常落盘）。变异「把 `contextRefused` 置为 `false`」`tsc` 0 错、标记进 `lib/` 已核对，打红 5 条具名用例（两条新的拒绝用例、unwritable-CONTEXT.md 那条、`external-edit` 的 stale 用例、tier C 的 context 落盘断言），正向对照保持绿；`src/` 从 `sha256sum` 校验过的 `/tmp` 快照恢复、重建后 `lib/` 0 标记。
- **被本批改写的既有测试信号**（被测语义真的变了，不是迁就）：`external-edit` 的 stale 用例从 `stale-context` + context 落盘改为 `stale` + 两个产物都不落盘；tier C 用例的 `contextWritten: true` 改为 `false`；「a failure after a refusal」用例的注入点（`CONTEXT.md` 建成目录）随闸一起失效，改为钉**新语义**：被拒 pass 根本不尝试写，所以不可写的 `CONTEXT.md` 不能再把拒绝变成 `failed`；`a clipped CONTEXT.md render` 的夹具补成完整四段文档（第二 pass 原先是靠「被拒仍写 context」才走到 clipped 渲染的）。
- 门禁（现跑，不引用历史数字）：`pnpm typecheck` 0；`pnpm test` **443 通过 / 0 失败**（本批前 440，新增 3 条）；`pnpm build` 0（`lib/client.js` 仍 28575 字节）；`lib/` 与新鲜 `tsc --outDir` 编译 `diff -rq` 只剩 `client.js`。
- 边界：不改配置键、无新依赖、两个 profile 无需改动；**改了 `src/` 行为，需要宿主重启才在线**（与 `6109688`、`2fc8957` 同一次重启覆盖）。登记残留：被拒 pass 之后已没有可达的普通抛出点（`readOptional` / `readMemoryJournal` / `logError` 都自吞异常），所以「拒绝在一次晚到的抛出里存活」这一覆盖随本批变为不可达；`refusedLoss` 跨抛出的携带仍留在代码里作未来改动的护栏。

**project-memory（批次 T1：读一致性标志看见 ctime —— 保留 mtime 的同尺寸替换不再隐形，第十次 pi triage）**

- 修复：**保留 mtime 的同尺寸替换此前对读一致性标志不可见，而发布侧正靠这个标志决定「不写」⇒ 方向 fail open**。`readRenderWithMtime` / `readRenderWithMtimeSync` 的 `changed` 来自 `renderChangedUnderRead`，旧判据只比 `mtime` + `size`：`cp -p` / `rsync -t` 这类写回保留 mtime、且落下的字节数相同，两样都不动，于是那次替换被当成「读到的同一版」——`externalRenderWins` 因此采纳被换掉的内容，`adoptExternalEdit` 的 append 前复核也因此放行（批次 O 登记的残留①）。现在判据加入 **`ctimeMs`**：用户态改不动 ctime，所以同尺寸、同 mtime、内容被换过也判为变更，写回让给下一次 pass；两个读者与 adopt 仍只经这一个纯判据（没有第二份副本）。pi `1952178`。
- 判别器：`test/memory-store.test.mjs` 的纯决策用例从 5 格边界扩到 6 格，新增「same-size mtime-preserving replacement」。变异「去掉 ctime 子句」只打红这一行（`AssertionError: a same-size mtime-preserving replacement is a replacement: only ctime moves`），其余五格保持绿；`tsc` 0 错、标记进 `lib/` 已核对、`src/` 从 `sha256sum` 校验过的 `/tmp` 快照逐文件恢复、重建后 `lib/` 0 标记。
- 门禁（现跑，不引用这里的历史数字）：`pnpm typecheck` 0；`pnpm test` **440 通过 / 0 失败**（本批未增删用例，只把既有纯决策用例的边界从 5 格扩到 6 格并改名）；`pnpm build` 0（`lib/client.js` 仍 28575 字节）；`lib/` 与新鲜 `tsc --outDir` 编译 `diff -rq` 只剩 `client.js`。
- 边界：残留只剩**落在文件系统 ctime 粒度内的那次替换**——`stat` 看不见，任何基于 stat 的判据都看不见，已写进 `renderChangedUnderRead` 的注释（原注释的「accepted residual」措辞随之删除）。本批不改配置键、无新依赖、两个 profile 无需改动，但**改了 `src/` 行为，需要宿主重启才在线**；它与 `6109688` 的同一次重启覆盖。

**project-memory / project-autolearn（批次 S：辅助模型调用的会话身份，以及它带出的 checkpoint 环路）**

- 修复：**在要求会话身份的路由上，本插件的辅助模型调用一律 400**（`opencode-go` 回 `{"type":"MissingSessionID","message":"Request is missing x-opencode-session and cannot be routed efficiently."}`），于是 `/memory update` 与技能沉淀在**拿到回复之前**就失败，整理 pass 从未走到写路径。链路五环，每条可复读：本会话路由是 `opencode-go`（profile 的 `agent-default-model`）→ pi-ai 的 opencode provider **只在请求带 `sessionId` 时**挂该头（`@earendil-works/pi-ai@0.87.1/dist/providers/opencode-headers.js` 的 `if (!options?.sessionId || hasHeader(...)) return options`）→ dsh 自己的两个辅助调用都盖章（`packages/compaction/compaction-basic/src/summarizer.ts:160`、`packages/session/session-title-llm/src/index.ts:268`）→ 本插件**故意**不盖（旧注释：「Deliberately no `sessionId`: an auxiliary call must not enter the loop's session-checkpoint path…」）→ 网关 400，`requestPluginTextWithMeta` 把 provider 的错误原样上抛（这是正确行为，未改）。**不是 N/O/Q/R/Q2 的回归**：那五批改的是对回复的验收/合并/拒绝与重试头寸，本错误发生在拿到回复之前。
- 修复（同轮，破环）：盖章会进入 dsh 的 checkpoint policy（`packages/session/session-checkpoint-policy/src/index.ts:64-68`：请求带**活会话 id** 时先 `sessions.flush(session)` 再派发）。而本插件四个插件都注册了 `session/flush` → `SessionWorkTracker.flush`，tracker 收的又是**整段 pass**——也就是正在等这次派发的那一段 ⇒ 环路 `llm/stream` → flush → 等 pass → 等这次 stream。它不挂死（`FLUSH_WAIT_MS = 90_000` 到点即返回），但每次辅助调用白等 90 秒，且那次 flush 会在 pass 写下任何东西之前就给出「durable」的结论。现在 tracker 只收 pass 的**写阶段**：`agent/status` / `agent/disposed` 两处把 `pending.track(session, pass)` 改成 `track: (work) => pending.track(session, work)`，`consolidateProject` / `runAutolearn` 在模型调用**之后**、任何落盘**之前**注册（`consolidateProject` 的 dedupe 早返回不注册——它没有东西要写；`/memory update` 命令路径自己 await 整个 pass，不注册）。`GenerateOptions.sessionId` 现在由 `PluginCallOptions.sessionId` 强制（漏填是编译错误，不是网关 400）。
- 判别器（入库探针，驱动构建后的 `lib/`，仓库根按探针自身位置解析，只写 `$TMPDIR`）：`.agents/evidence/2026-10-11-batchS-aux-route/aux-route-probe.mjs`，三段各钉一环，退出码按**因**分：`0` = 三段全过；`10` = 请求不带会话身份（现场的 `MissingSessionID`）；`11` = checkpoint flush 被 pass 挡住（环路）；`12` = 夹具没跑到模型调用；`1` = 等价构造对照回归。修复前 `RESULT: FAIL` / `exit 10`（`sessionId=undefined`、`checkpointFlushes=0`、`registrations=0`、`registeredAfterFirstCall=true`），修复后 `RESULT: PASS` / `exit 0`（`sessionId="session-probe-memory"`、`checkpointFlushes=1`、`flushReturnedBeforeDispatch=true`、`registrations=1`）。第 2 段是**故意**保留的修复前布线等价构造（整段 pass 挂 tracker），两次运行都打印「parked」——它证明环路真实存在，且本批的对照不依赖树的状态。两次输出留档在证据目录（`1-pre-fix-probe.txt` / `2-post-fix-probe.txt`）。
- 门禁（现跑，不引用这里的历史数字）：`pnpm typecheck` 0；`pnpm build` 0（`lib/client.js` 仍 28575 字节，本批未动客户端）；`pnpm test` **439 通过 / 0 失败**（本批前 436；新增 3 条具名用例，并在既有的 tools 用例里加了一条身份断言）；`lib/` 与新鲜 `tsc --outDir` 编译 `diff -rq` 只剩 `client.js`。**3 个变异体全部被杀**，每个都 `tsc` 0 错、标记进 `lib/` 已核对、`src/` 从 `sha256sum` 校验过的 `/tmp` 快照逐文件恢复、收尾重建后 `grep -rn "MUTANT_" lib/` = 0：① `model-call.ts` 不发 `sessionId` → 打红三个身份 pin（两个 composition 用例 + tools 用例）；② `agent/status` 把整段 pass 交回 tracker → 只打红环路用例；③ 删掉写阶段的 `options.track?.(work)` → 只打红「写阶段恰好注册一次」用例。
- **被本批改写的既有测试信号**（不是迁就，是被测语义真的变了）：`test/top-level-gate.test.mjs` 的 `fire()` 与 `test/autolearn.test.mjs` 的开关用例原先用 `session/flush` 当「整段 pass 完成」的信号——而那正是本批窄化掉的东西。两处改为按该文件既有的「有界窗口 + 阳性对照」观察**模型调用本身**（500 ms 窗口；同一测试里的阳性对照证明窗口够长，实测 pass 抵达 stream 远小于 10 ms）。断言一条未放松：`project-memory`/`project-autolearn` 的委派门、两个开关、上下文归档的负例都仍各自带阳性对照。
- 独立只读复核：本轮按流程发起（只读、不写仓库、`src/` 冻结、不跑会重写 `lib/` 的 `pnpm build`/`pnpm test`），但**结论在本提交时尚未返回**——复核到达后按「发现 → 独立复现 → 最小修复 + 变异校验」单独一轮处理，不在这里预写结论。Lead 已就两点逐行走查（复核提纲里的最高风险项）：`consolidateProject` 的 `catch` 同时覆盖模型调用与**写阶段**两处抛错（`await work` 在 try 内），失败仍是 `logError` + `logger.warn` + `status: "failed"`，且 memory 已落盘时不删除 version 声明；`index.ts` 两处 `void … .catch(() => undefined)` 与旧的 `pending.track` 吞掉拒绝的方式等价。
- 边界：本批不改配置键、无新依赖、不新增 session 事件类型、两个 profile 无需改动，但**改了 `src/` 行为，需要宿主重启才在线**（判据照旧：19387 持有者启动晚于最后一个 `src/` 提交）。**B2（盖一个稳定的非活会话路由键）未采用**，理由与 B1-a 的已接受代价写在 `docs/archive/batch-s-opencode-aux-route-brief.md` §6：破环只要求「注册进 tracker 的那一段不等待派发」，而写阶段本来就不等待任何派发，所以 tracker 的语义没有被削弱、只是被说准（契约写在 `src/shared/lifecycle.ts` 的类注释里）；B2 的代价是语义谎报（字段名是会话身份、放的是传输元数据）。**已接受代价**：`agent/status` / `agent/disposed` 那次自动 pass 的**模型调用**不再被 `session/flush` await（写阶段仍被 await）——模型调用不是可持久化的工作，它的失败由 pass 自己的报告与 `errors.log` 承担；`index.ts` 两处 `void … .catch(() => undefined)` 与旧的 `pending.track` 吞掉拒绝的方式等价（tracker 的 `work.then(() => undefined, () => undefined)` 同样不上抛）。**B1-b（重入守卫）未采用**：它会让该窗口内**任何** flush 提前返回，比 B1-a 粗。
- **立即解锁（与代码解耦，用户操作）**：设置卡片里的 `Provider` / `Model` 是整理与技能沉淀共用的路由覆盖（`resolveTarget` 第一优先读它），填成非 opencode 路线即可让 `/memory update` **今天**就能跑（`settings.mutate` 设置写入，无需重启；候选见 brief §7）；本批重启后可以撤掉。**端到端验收（重启后，用户操作）**：在本仓库跑一次 `/memory update`，`.agents/memory/errors.log` 不得再出现 `MissingSessionID`——这是本批唯一无法离线见证的一条，探针只证明加载的 `lib/` 具备该行为。

**project-memory（批次 R：重试头寸带上真实花掉的隐藏思考，第九次 pi triage）**

- 修复：**被输出上限截断后的重试只肯多要固定的 `RETRY_OUTPUT_HEADROOM_TOKENS = 4096`，而忽略这次调用实际花掉的隐藏思考**（`src/project-memory/consolidate.ts` 的重试支；`attempt.reasoningTokens` 在修复前只出现在失败文案里）。这条路径的真正天花板是同一个 cap 里给自己留的 reserve **也封顶在 8192**（`MAX_REASONING_RESERVE_TOKENS`），而推理型 route 能花得多得多：pi 的现场案例（Quantum_Matrix，2026-10-08）第一次调用花掉 **20489** token 思考、可见回复只剩 11721 而需要约 33k，于是被截断；重试只多要 4096，**被同一笔思考再截一次**，整轮失败，而报出来的原因（`raise maxOutputTokens or trim MEMORY.md`）指向操作者调不动的那个旋钮。现在重试头寸是 `Math.max(RETRY_OUTPUT_HEADROOM_TOKENS, attempt.reasoningTokens)`（pi `099ebf3`）：适配器不报时该值是 `0`，于是**非推理 route 的重试与修复前逐字节相同**；报了就至少带上它真实花掉的那一份。`fitMemoryInput` 的 `extraHeadroomTokens` 同时进入 `needed`（抬高请求 cap，再由 `adaptiveOutputTokens` 对模型自身上限与 `max(configured, ceiling)` 双侧钳制）与 `desiredReserve`（从同一 cap 里留走），所以「要么要到更大的 cap、要么同一 cap 下少发内容」两条都算这笔头寸真被扣了。
- **与 pi 的一处有意形状差异（记住，别当成 bug 修回去）**：pi 是两臂 `truncated ? fitMemoryInput(..., retryHeadroom) : fitted`，头寸只在 `stopReason === "length"` 时带；dsh 是**单支**重试，进入条件是 `stopReason === "max-tokens" || truncatedToolCall`（后者由 `toolCallIsTruncated` 判定：带 tool call 且 finish 为 `max-tokens` 或**空**）。本改动在该支内**无条件**取 `max`，差异只出现在「空 finish 却仍报了 usage」这一种组合，方向是**只会多给、不会少给**，因此不跟随 pi 的两臂写法。`max` 而非三元（`attempt.reasoningTokens > 0 ? … : …`）是必要条件：报告值**小于**扁平常量（含 0）时若把常量丢掉，非推理 route 的房间反而**变小**——第二个具名用例对 `0` 与 `1024` 两个取值都断言 `growth === RETRY_OUTPUT_HEADROOM_TOKENS`，就是这个判别器。
- 判别器（入库探针，驱动构建后的 `lib/`，仓库根由探针自身位置解析，只写 `$TMPDIR`）：`.agents/evidence/2026-10-11-batchR-retry-headroom/probe.mjs`。它脚本化两次调用（第一次停在 cap 并报 `reasoningTokens: 20000`，第二次完整），打印两次请求的 cap：修复前 `10032 -> 14128 (growth 4096)`、`exit 10`（DEFECT PRESENT）；修复后 `10032 -> 30032 (growth 20000)`、`exit 0`（DEFECT CLOSED）。判据是**等号**（该夹具的 ceiling 不 binding，cap₂ 30032 < 131072），因此「只带上部分花费」的实现（复核举出的 `max(4096, observed - 4096)`，growth 15904）也翻红——早先写成「≥ observed − 4096」等于把判据放宽到「至少 79.5%」，那是比修复本身更弱的断言。四种退出码都**实证**可达：0 = 现行树；10 = 改回扁平常量 / 按 reserve 上限截断；11 = CONTROL REGRESSION（带上花费却丢掉常量）；1 = 夹具没跑起来（`/tmp` 副本把第一次回包的 finish 改成 `stop`，打印 `FIXTURE FAILED: calls=1`）。**11 这个码是复核促成的**：原先「对照回归」会被打印成缺陷句并 `exit 1`，把错的因说成对的因——本项目的中心缺陷类，现在两种失败各自命名、各自给码。
- 门禁（现跑，不引用这里的历史数字）：`pnpm typecheck` 0；`pnpm build` 0（`lib/client.js` 仍 28575 字节，本批未动客户端）；`pnpm test` **432 通过 / 0 失败**（本批前 430，新增 2 条具名用例）；`lib/` 与新鲜 `tsc --outDir` 编译 `diff -rq` 只剩 `client.js`。**4 个变异体全部被杀**，每个都 `tsc` 0 错、标记进 `lib/` 已核对、`src/` 从 `sha256sum` 校验过的 `/tmp` 快照恢复、恢复后重建 `lib/` 0 标记、逐文件复核 67/67：① 改回扁平常量 → 打红「带上观察到的花费」（`caps 10032 -> 14128`），探针同时 `exit 10`；② `attempt.reasoningTokens > 0 ? attempt.reasoningTokens : RETRY_OUTPUT_HEADROOM_TOKENS` → 打红对照用例在 `1024` 那一格（探针仍 0：它只喂 20000 与 0，这正是第二条用例存在的理由）；③ `Math.min(8192, Math.max(...))`（照 reserve 上限截断）→ 打红「带上观察到的花费」（growth 8192 < 20000），探针同时 `exit 10`；④ `Math.max(RETRY_OUTPUT_HEADROOM_TOKENS - 4095, attempt.reasoningTokens)`（带上花费但丢掉常量）→ 打红对照用例两格、探针 `exit 11`。**一处操作陷阱**：恢复脚本用的是 `cp -r <快照> src`，而快照本身是 `cp -r src <快照>` 建的，于是 `SHA256SUMS` 被一起复原成 `src/SHA256SUMS`；它不出现在任何 `.ts` 编译面里，但会作为未跟踪文件混进 `git status`——已按绝对路径核对后删除，并以逐文件 `sha256` 复核 `src/` 完整。
- **独立只读复核：NO BLOCKING DEFECT**（读两侧源码 + `node --test test/*.test.mjs` 432/0；`src/` 冻结、不许 build）。它最有用的一条纠正了我此前没说的：**pi 那个 `truncated ? … : 0` 三元是死代码**（重新拟合本身也被 `truncated` 门着），所以 dsh 单支里的无条件 `Math.max` 在 `max-tokens` 的所有路径上与 pi 行为等价，只有「空 finish + tool call」那一条是有意偏离（见下面的残留）。它确认对照用例是真的判别器、主用例不是自证，并给我三处该修的，均已修并复跑：① 主用例的 `>= observed − 4096` 放宽判据 → 改等号（见上）；② **既有 `test/logic.test.mjs:4815` 的注释在本批之后成了假话**（它说重试多留 `RETRY_OUTPUT_HEADROOM_TOKENS`，而该夹具报 `reasoningTokens: 5000`，两个 cap 都被 32768 的 ceiling 钳住所以用例仍绿、错误只写在注释里）→ 改成「扁平常量与花费取大者」；③ 探针的误归因分支 → 拆出 `exit 11` 与各自的措辞。
- 同批**未端口**的另外半边（`068b7e8` + `5783610`，命令等待提示）：**探到的答案是 dsh 宿主侧没有通道**——handler 只返回一个 `CommandResult`、注册表在 `await` 之后才 append `command/done`，`command/run`/`command/done` 都是 log-only 非 surface；现跑 `cordis_inspect_query` 的 host Service 目录里没有 notification/notice/toast 类 service（唯一命中的 `announce` 是 session 启动来源与 `sessions.announce`，后者源码里写着 `was already announced`，是创建期一次性播音）；客户端确实有 notice 面（`ui-commands` 的 `noticeFor`）但只由**客户端自己**的派发结果喂；本仓库自己的源码扫描用例还禁止 `src/`、`client/` 出现任何 `.append(`；内置长时间命令 `/compact` 同样不吭声。**但 dsh 本来就有「运行中」反馈**：ui-chat 的 `GenericCommandCard` 对 `outcome === null` 渲染 `执行中…` / `Running…` + shimmer，所以缺的只是命令专属的说明句。探测另发现的替代物是**按命令名 keyed 的客户端 slot** `conversation.chat.commandview`（占据 `memory` / `autolearn` 即可给出专属运行文案，正是 `/compact` 的机制），代价是占据 key 会**替换**内置卡片、而 `GenericCommandCard` 不在 ui-chat 的公开导出面里，需要复刻 75 行 + CSS 或写一张更简陋的行——属**用户可见 UI**的取舍，已连同代价写进 `docs/archive/batch-r-retry-headroom-brief.md` §8；**用户 2026-10-11 裁定：按残留收档，不做**（接受「等待期间只有通用的 `执行中…`」这一半，理由与重开入口见 §8 末尾）。
- 边界：本批不改配置键、无新依赖、不新增 session 事件类型、两个 profile 无需改动，但**改了 `src/` 行为，需要宿主重启才在线**（判据照旧：19387 持有者启动晚于最后一个 `src/` 提交）。只动重试头寸；第一次调用的 reserve 仍封顶 8192，注释里「带上观察到的花费」指的是**传给 `fitMemoryInput` 的参数**，不等于最终生效的 reserve（后者被 `max(1024, cap/2)` 饱和）。**三处登记残留**：① 更大的头寸会从同一 cap 里多留走输入（复核实算：cap 32768、观察值 20489 时 reserve 落到 16384，重试正文从 27648 字符降到 16384），但重试的可见房间（`cap − 观察值`）不变、少发正是「压缩」要的，被剪字符仍由 hidden-character 计数报告；② `观察值 ≤ cap₁` 使重试请求可到约 `2 × cap₁`（旧写法只到 `cap₁ + 4096`），在「route 未公布 `maxTokens` 且用户的 `maxOutputTokens` 高于其真实上限」的窄组合下，重试可能被 provider 拒而旧写法会被接受——文档化的 `max(configured, ceiling)` 上界未破，pi 有同一暴露；是否额外夹在「上一次被接受的 cap」需另行裁决；③ 「空 finish + tool call」是唯一偏离 pi 的入口（pi 在 `truncated=false` 时根本不重新拟合），usage 可早于缺失的 finish 到达，故该路径可能为非 cap 原因多留头寸；复核读两个已装适配器判定它只具防御意义、无已知生产者。

**project-memory（批次 Q2：部分文档的验收守卫 —— 合并 / 拒绝 / 报告，用户 2026-10-11 裁决）**

- 修复：**一句「部分文档」就能让 store 里没被提到的段整段消失，且没有任何诊断**。batch Q 新加的形状门接受四段的任意子集（`## Project\n- x` 算我们的形状），而 `sectionsFromMarkdown` 要求四段齐全（`src/project-memory/sections.ts` 的 `seen.size !== SECTION_KEYS.length`）⇒ 只带一段的回复落 `fallback-opaque`，被 `index.ts` **逐字**写成 `MEMORY.md`，其余三段无声消失（dsh 侧 `grep -rn 'removedSectionEntries\|RemovedEntries' src/` = 0，也没有任何 `memory regression` 措辞）。入库探针 `.agents/evidence/2026-10-11-batchQ2-acceptance-guard/probe.mjs` 修复前 `exit 10`（逐条点名 4 个未满足的期望）、现在 `exit 0`。
- 修复（用户裁决「都做」的分层落地，四层各管一种后果）：**① 条目级丢失＝只报告**（pi `pass.ts:123-133` 的 `removedSectionEntries` 原样照抄：只比 Invariants/Pitfalls 的归一化条目，Project/Index 故意排除，`memory regression: N …` 一行，**绝不拦截**——拒绝它会让每次压缩都变成永久拒绝）；**② 段级省略＝合并**（形状合法但不完整的回复按**补丁**应用：带上的段替换、没带的段从 store 保留后走同一个渲染器，`report.mergedFromStore` 点名保留的段）；**③ 不可合并＝拒绝**（段里夹 prose、未知标题、`*`/缩进条目，或 store 本身不是四段 ⇒ 不写、store 逐字节不变、`status: "partial-refused"` 一条具名拒绝）；**④ 两条路径都可见**（拒绝写 `errors.log`，`mergedFromStore` / `removedEntries` 进报告；合并**不**记例行日志——那不是损失，理由见 brief §5）。
- 修复（**独立只读复核发现的 blocking 缺陷，同轮修掉**）：refusal 原先在 tier C **之前**判定，而 tier C 的重试可以把它换掉——重试若答一份「不可合并的部分文档」，`resolved` 变成 `unmergeable-partial` 而 `partialRefused` 仍是 `false`，于是**那份部分文档被逐字写入，status 报 `updated`、整份 store 消失**（复核用 `/tmp` 自己的驱动复现，`exit 10`）。现在「不可合并的重试**永不**替换一份可存储的首次回复」（`retryResolved.kind !== "unmergeable-partial"`），拒绝因此归属于**将要被写入的那份回复**；由 `batch Q2: a retry that answers with an unmergeable partial cannot replace a storable reply` 与探针的 F 段钉住（变异体 M5 只打红这一条）。同轮按复核意见修掉另外三处**错误归因**：拒绝文案原先说「只带了文档形状的一部分」（对一份**完整但段里夹 prose** 的文档是假话）并把「交完整四段」当解药（那份回复本来就是完整四段）——现在按**哪一半读不出来**分成两种原因与两种解药（`store-not-sections` ⇒ 只有完整四段能替换；`reply-not-sections` ⇒ 把段内每行改成第 0 列的 `- ` 条目，或交子集去合并）；`memory regression` 一行从判定处**移到写入处**（`snapshot.written` 之后），否则 tier C 拒绝或 basis-key 竞态会留下一条「有条目不见了」的假话而 store 逐字节未变。
- 边界（**不要读成已修**）：① 拒绝是**有意的收紧**，代价确定——store 不是四段文档（自由格式/旧版 memory）时，**任何**不完整形状的回复都被拒，只有完整四段能替换它；段里夹 prose 的**完整**四段文档也会被拒（它的段读不出来，无法保证不丢东西）。两者都**不丢数据**（store 逐字节不变 + 具名拒绝 + 解药），但都会让一次本可成功的整理变成一次重试。② `partialSectionsFromMarkdown` 与 `sectionsFromMarkdown` 共用**同一个**结构解析循环（`parseStructuralSections`），完整性判据只留在后者自己的调用点，所以两条接受规则不会漂移；`sectionsFromMarkdown` 的行为一字未改（`test/sections.test.mjs` 的形状表是它的 pin）。③ 合并**不保留**回复里位于段落之外的文本（标题下的 prose、段尾注记）：合并的语义是「段」而不是「任意文本」。④ 本批不改配置键、无新依赖、两个 profile 无需改动，但**改了 `src/` 行为，需要宿主重启才在线**（判据照旧：19387 持有者启动晚于最后一个 `src/` 提交）。
- 变异校验（**5 个变异体全部被杀**，每个都 `tsc` 0 错、标记进 `lib/` 已核对、`src/` 从 `sha256sum` 校验过的快照恢复、重建后 `lib/` 0 标记）：① 合并丢掉 store 的段 → 只打红合并用例；② 去掉拒绝 → 打红拒绝用例与重试用例；③ 报告永不触发 → 只打红报告用例；④ 把报告改成拦截 → 打红报告用例与合并用例；⑤ **接受不可合并的重试**（复核那条 blocking）→ 只打红新重试用例。**一处自查**：最初写的「tier C 之后重算 `partialRefused`」被 M5 证明是**死代码**（真正堵住漏洞的是那条闸门），已按「一个所有者、不留死代码」删除，注释里写明闸门是唯一所有者。
- 门禁（现跑，不引用这里的历史数字）：`pnpm typecheck` 0；`pnpm build` 0（`lib/client.js` 仍 28575 字节，本批未动客户端）；`node --test test/*.test.mjs` **436 通过 / 0 失败**（本批前 432，新增 4 条具名用例）；`lib/` 与新鲜 `tsc --outDir` 编译只差 `client.js`。规格、分层规则与验收标准：`docs/archive/batch-q2-acceptance-guard-brief.md`；独立复核结论与它促成的四处修改都在本条目内。

**project-memory（批次 Q：回复只有带上本扩展的文档形状才算 memory，第九次 pi triage）**

- 修复：**opaque 路径的唯一守卫是单边的，一句寒暄就能整体替换掉已存的 memory**。追链：`src/shared/reply-json.ts:116` `if (!looksLikeJsonReply(text)) return { memory: text };` → `resolveReply` 在 `sectionsFromMarkdown` 读不出四段时退回 `fallback-opaque` → 门 `replyIsSemanticallyEmpty` 的 opaque 分支**只**问 `isHeadingOnlyDocument` → `index.ts` 只要变化 ≥ 40 字符就写。而 `isHeadingOnlyDocument` 故意是单边的（任何去掉装饰后还含字母/数字的行都算内容，因为「另一个答案是把模型真写下的 memory 拒之门外」），于是 `# Project Memory\n\nI'll review the frozen revision and record the durable lessons now.` 这种**带着规范标题的寒暄**通过门、整体替换掉全部存储内容——pi v0.4.7 的现场事故形状。tier C 在这里从不介入（opaque 回复没有 sections，`writeCapDroppedChars` 是 0），所以整条替换**静默**发生。现在新增 `src/project-memory/sections.ts` 的 `hasMemoryDocumentShape`：回复只有在**第 0 列的已知 `## <section>` 标题下**、**第 0 列有一条 `- ` 条目**时才算一份文档，围栏之外才算；四段的一个子集是合法的部分文档（`## Project\n- x` 通过形状门，且仍走 opaque 逐字保存，不会被渲染成四段），而别的标题层级、setext/HTML 标题、`*`、编号、缩进条目、prose、有标题没条目都不是本扩展写过的形状。门因此变成两侧：`isHeadingOnlyDocument(reply) || isConversationalOpaque(reply, existing.text)`，**只在 opaque 分支生效**（sectioned 分支一字未动）；`storedIsDocument` 保证只有在 store **本身值得保护**时才拒绝（能解析成四段，或剥掉开头的 `# Project Memory` 标题后还剩 ≥ 40 字符），所以空项目与只剩标题的 store 走既有的「太短不算变化」报告，而不是被这里拒掉。
- 修复（同一事实一个所有者）：**围栏规则此前只写在 `isHeadingOnlyDocument` 的函数体里**。形状门要读同一份规则，再手写一遍就是本仓库登记过的「近似副本」残留，所以抽出 `FenceToken` / `readFenceLine` / `fenceCloses` 供两个读者共用（`isHeadingOnlyDocument` 的断言未改一字，行为等价）；同时把 `SECTION_KEY_BY_HEADING` 从 `sectionsFromMarkdown` 每次现建的局部 map 提升为模块常量，并把只以字面量写在 `index.ts` 的长度下限提成 `OPAQUE_DOCUMENT_MIN_CHARS = 40`（导出自 `sections.ts`，`index.ts` 改读它），于是「小得不像 memory」是一个数。
- 修复（**必须同轮改名的一处假话**）：`consolidate.ts` 末尾的诊断串原为 `the consolidation reply carried no entries; the stored memory was kept unchanged`，而 route B 之后被拒的这一类**包含「prose + 一条 bullet」——它明确带着条目**。现为 `the consolidation reply was not a writable memory document; the stored memory was kept unchanged`，并由新用例按字段串钉住。
- 判别器（入库探针，驱动构建后的 `lib/`，只写 `$TMPDIR`）：`.agents/evidence/2026-10-10-opaque-reply-acceptance/probe.mjs` 修复前 `exit 10`（DEFECT PRESENT：两条 prose 回复都 `memoryWritten=true`、存储被替换），现在 `exit 0`（DEFECT CLOSED：两条都 `memoryWritten=false`、`stored byte-identical=true`，只剩标题的裸骨架仍被拒）。README 里两份预期输出都留档，探针不删。
- 门禁：`pnpm typecheck` 0；`pnpm build` 0（`lib/client.js` 仍 28575 字节）；`pnpm test` **430 通过 / 0 失败**（本批前 428，新增 2 条具名用例）；`lib/` 与新鲜 `tsc --outDir` 编译 `diff -rq` 只剩 `client.js`。**7 个变异体全部被杀**，每个都 `tsc` 0 错、标记进 `lib/` 已核对、恢复后 `sha256sum -c` 全通过、重建后 `lib/` 0 标记：① 形状门的标题判据改成「任何 `## 标题` 都算我们的」→ 打红形状表用例；② 去掉 `endsSectionScope` 的 `underKnownHeading = false` 复位 → 打红形状表用例；③ 条目判据 `&&` 改 `||`（第 0 列任何 `- ` 都算）→ 打红形状表用例 + `isHeadingOnlyDocument` 边界那条；④ 围栏状态不记录 → 打红形状表用例（围栏里的 `## Project` 也成立）；⑤ `storedIsDocument` 恒真 → 打红新端到端用例的「store 低于下限」断言，另打红 3 条写上限用例；⑥ 诊断串改回旧措辞 → 打红新端到端用例与骨架用例（后者正是按新字段串钉的）；⑦ `isConversationalOpaque` 恒假（门整体失效）→ 只打红新端到端用例（含复核后新增的「成熟 store 由形状门拦下」那一对）。**一处自查陷阱**：第一轮 4 个变异体的标记核对全部报 0，看着像「变异体没进 `lib/`」——实际是 `tsc` 用**空格**缩进而 `grep -F` 收到的是**制表符**，且多行标记根本不能喂给按行匹配的 `grep`；改用不带前导空白的片段后全部命中（**标记核对失败不等于变异体无效**）。另一处：⑦ 是在 `src/` 快照之后才补的，它的 `trap` 恢复把**快照之后**改的 `index.ts` 注释一并回滚了——恢复脚本只保证回到快照，不等于回到「最新」；重新落地注释并**重新快照**后才做最终门禁。
- 逐条按新语义**正确**改写的既有夹具（不是迁就，是被拒类别真的变了）：① `test/external-edit.test.mjs` 的 `REPLY_MEMORY` 从自由格式改成带 `## Project` 形状（理由写在该行注释里——不然它会先在语义门被拒，这条套件要测的竞态就测不到了）；**该夹具在批次 Q2 又改成完整四段**（Q2 的形状合法但不可合并的部分回复同样会被拒），措辞与理由见那一行的注释；② `test/logic.test.mjs` 两条读上限夹具的回复同样带上形状，使它们仍在测「读上限与输入拟合各记一次」；③ 骨架用例的断言从 `carried no entries` 改为新诊断串。三处的测试意图与名字都未变。
- 边界/残留（**不要读成已修**）：① **有意多拒的一类就是代价**——一份**自由格式**（标题 + 第 0 列 bullet、没有任何 `## <section>`）的旧 memory，被模型用**同样的自由格式**改写时会被拒（`storedIsDocument` 为真而回复没有形状），于是它逐字节不变、每个 pass 记一条诊断，**在模型交出规范四段文档之前不会更新**；pi 的裁决是接受它（宁可拒绝一份本扩展读不懂的 memory，也不接受一次静默的整份替换），dsh 的提示词本来就要求四段，所以这是「模型没照 schema 写」的可见后果；② **保留的 fail-open**：section 的作用域只被 ATX 标题、setext 下划线、HTML 块起始结束，**prose 不结束它**，所以 `## Project\nsome prose\n- a` 仍通过形状门，已用「prose between the heading and a later entry」的名字钉住，免得被当成 bug 顺手「修」成新的 fail-open（同一处**继承 pi** 的 fail-open 也保留：`endsSectionScope` 不进入「HTML 块吞掉后续行」的状态，`<div>\n## Project\n- a\n</div>` 仍算形状并端到端落地，pi `origin/master` 逐字节相同，要关它得与 pi 同轮补一个多行 HTML 块状态机）；③ `storedIsDocument` 读的是**经过 `loadMemory` 上限裁剪后的** `existing.text` 而不是磁盘原文（裁剪只可能让 store 更短，对「有没有东西可保护」够用），标题剥离按**整篇文本**剥一次；④ 与 tier C 的分界由 **store** 决定，两端都被用例钉住：写上限那条既有用例的 store 让 `storedIsDocument` **两项同时为假**（解析不出四段；剥标题后 21 字符 < 40），所以回复落 tier C 的写上限路径（`calls=2`、`status=lossy-refused`、`refusedLoss.writeCapDroppedChars>0`）；同一回复换成熟四段 store 就改由形状门先拦下（`calls=1`、`status=updated`、`refusedLoss=undefined`、store 逐字节不变），新端到端用例把这一对钉住，免得只按「store 低于下限」一半去理解那条既有用例——那只是两项同时为假的唯一组合，不是 over-cap opaque 回复的通用情形；两条路径各自命名自己的原因、不会互相冒名（`if (semanticEmpty) memoryLossyRefused = false;`）；⑤ **本批真正的承载性残留**：门是「至少一个 section」，不是完整性检查——回复 `## Project\n- <够长的一条>` 通过形状门（`sectionsFromMarkdown` 读不出四段 ⇒ 逐字落地），**已存的 Invariants/Pitfalls/Index 会连带消失，且这条路径没有任何守卫、也没有诊断**（dsh 没有 pi 的 `RemovedEntries` 回归守卫，`grep -n 'removedSectionEntries\|RemovedEntries' -- src/` 为 0；pi 的守卫在「本轮没有产出 sections」时也只记一行 `memory regression guard skipped: this pass did not produce sections` 而跳过）。也就是说 Q 关掉了「一段 section 都不带」的门，**「只带一段」的门当时仍然开着**；它与本批要修的是同一个损失类，用户 2026-10-11 定案后作为**批次 Q2** 落地（合并 / 拒绝 / 报告三层，见上面 Q2 条目）；⑥ **没有现场频率**：缺陷由代码追踪 + 探针证明可达，但**没有 dsh 的现场事故记录**，实际频率未测；⑦ 批次 O 残留④（只由标题组成的 render 仍赢读取）**本批不动并判定不需要动**：那是读侧的「最新者赢」契约（`externalRenderWins` 把被手动清空的 `MEMORY.md` 当外部编辑），而 Q 的存储侧下限让这种 store 在接受方向上也无足轻重（`storedIsDocument("# Project Memory\n")` 为假），要改它得动 O 的判据并与 `cleared-render-probe.mjs` 的判定冲突，必须单独一轮；⑧ 本批不改配置键、无新依赖、两个 profile 无需改动，但**改了 `src/` 行为，需要宿主重启才在线**（判据照旧：持有者启动晚于最后一个 `src/` 提交）。

**project-memory（批次 O：一次读取 + 一版本纪律，第九次 pi triage）**

- 修复：**纯读路径会把「旧版本的字节」配上「新版本的 mtime」**。`loadMemory` 原先 `readOptional(target)` 读字节、随后再 `stat(target)` 取时间，两次调用之间落下的替换让读者拿到旧字节却盖上新文件的 mtime，于是**被替换掉的那一版赢下了这次读取**（`source` 指向 `MEMORY.md`，注入进提示词的就是那份旧内容）。写路径同一形状：`recordMemoryDocument` 的 adopt 拿「本轮开始时读到的 key」配「写前新 `stat` 的 mtime」判定，FIFO 注入下 journal 末行是**文件已经丢掉的那一版**——journal 的 mtime 因此被推新，更新的手改被永久压住，下一次发布再从磁盘把它抹掉（pi 报告 I1/B1 的同一类）。现在 `src/project-memory/load.ts` 新增 `readRenderWithMtime`（`stat → 读 → stat`，`changed` = mtime 或 size 变了）与同步版 `readRenderWithMtimeSync`，两处读取都只有在一致（`!changed`）时才采纳 render。
- 修复：**同一条判据此前写了三遍**（异步读 `load.ts:96`、同步读 `load.ts:182`、adopt `record.ts:66` 各一份 `mtimeMs >`），这正是本项目自己登记的既有残留（「one shared function is the fix, not another copy」）。现在判据只有一处 `renderIsNewerThanJournal`；两个**读者**共用**同一个纯决策** `externalRenderWins`。**adopt 不走它**（它记的是写入方借来的那个 key，而不是自己读到的字节算出的 key）：它与读者共用的只是更下层的时间判据，另有自己的两道守卫 + append 前复核——复核把这条框架性出入记为 F2/F7，是本批保留的重复。抽成纯函数照的是 pi 修同一条复核发现（I2「该分支零覆盖」）的办法：**每个时序都能从测试直接驱动，不需要并发写者**，所以同步读者那条没有夹具的分支也终于有主。
- 修复：**adopt 在 `appendMemoryOp` 之前没有任何复核**。新导出的 `adoptExternalEdit` 在 append 前再取一次一致读取：文件已不是那串字节（或被再次替换）就拒绝，并写一条 `the memory render changed before the memory journal could record the edit; both were left for the next pass`。**借键路径**（`recordMemoryDocument` 交给它的、本轮开始时读到的那个 key）同样只由这一次复核裁决：`verify.changed` 早退与它重叠（删掉它测试仍绿），故只留复核一处——与 pi M10 的结论一致。
- 修复（**本批自己的第一版引入的回归**，由本会话的等价网格发现、独立只读复核同轮独立复现）：**「空 key 就是文件被清空」这个推断是错的**。`memoryComparisonKeyWithDrop` 对任何输入都至少产出规范化的裸标题——实测 `""` / `" "` / `"\n\t "` 的 key 都是 `"# Project Memory\n"`（17 字符，永不等于 `""`），所以第一版删掉旧的 `renderRaw.trim()` 外层守卫、改用 `!renderKey` 之后，**一个被手工清空（或被 `chmod 000` 变成不可读——`readOptional` 把读错误折叠成 `""`）且比 journal 新的 `MEMORY.md` 会赢下两个读者**：模型看到的是 `"# Project Memory\n"`，而 `recordMemoryDocument` 会**拒绝一次真实整理**并把那个裸标题称作「更新的内容」（`written:false`，并记下 `the memory changed while this pass's reply was being built`）——正是本仓库的中心缺陷类（错误归因）。现在判据测的是 render 的**正文**（`render.text.trim()`），而不是它的 key；同一轮把 key 参数从 `string` 收紧成 `NormalizedMemory`，两个读者传的都是**由自己那份字节算出**的归一化结果。**但这只是形状、不是来源证明**：模块级调用者仍可把一版的 key 配到另一版的 mtime 上（复核 claim 4 实测返回 `true`）；`externalRenderWins` 也不在包面上（`memory-store.ts` 只再导出五个具名函数），仓内两个调用点都从同一份 `render.text` 取 key。
- 判别器（入库探针，驱动构建后的 `lib/`，仓库根由探针自身位置解析，只写 `$TMPDIR`）：`.agents/evidence/2026-10-11-batchO-single-read/` 三个探针。读侧 `read-race-probe.mjs` 与写侧 `write-race-probe.mjs` 把 render 路径做成 **FIFO**，写入端用**阻塞的 `open(…, "w")`** 当调度屏障（读者拿到旧字节之后，路径才被替换），所以竞态是确定性的：对**修复前**的 `lib/`（`cccabf2`）都 `exit 10`，对修复后 `exit 0`；两者各带**正向对照**（稳定文件上的较新外部编辑仍被采纳 / 这一轮仍照常发布），写侧还把「拒绝原因确实写进 `errors.log`」算进判据（`exit 4` 单列）。第三个 `cleared-render-probe.mjs` 是上面那条回归的判别器：清空 render 后两个读者必须仍返回 journal 的 fold、带 `basisKey` 的一轮必须照常写入；把 `!render.text.trim()` 去掉（变异体 M3）它立刻 `exit 10`，并打印 `source: MEMORY.md` / `pass published: false` / `wrong-cause refusal: true`。
- 等价网格（本会话的一次性工具，不入库）：把 `git show cccabf2:` 里的旧判据逐字抄下来，与新的判据在 864 格上对拍——**第一版 60 格不一致，修好之后 0 格**（唯一的有意差异是「陈旧借键被拒绝」，单独断言）。同一张网格是那条回归的发现器，不是我的推理。
- 门禁：`pnpm typecheck` 0；`pnpm build` 0（`lib/client.js` 仍 28575 字节）；`pnpm test` **428 通过 / 0 失败**（本批新增 9 条具名用例）。**8 个变异体全部被杀**，每个都 `tsc` 0 错、标记进 `lib/` 已核对、恢复后 `sha256sum -c` 全通过、重建后 `lib/` 0 标记：① `externalRenderWins` 忽略 `changed` → 打红 2 条（纯决策用例 + FIFO 读竞态用例），读竞态探针同时回 `DEFECT`；② 去掉「等于 fold 就不是外部编辑」→ 打红 2 条；③ **去掉 `render.text.trim()` 空正文守卫（即上面那条回归本身）→ 打红 2 条（纯决策用例 + 清空 render 用例），`cleared-render-probe.mjs` 同时回 `DEFECT`**；④ 时间判据改成 `>=`（并列即算更新）→ 打红 3–5 条（**随同毫秒写入的时序变动**：复核连跑 5 次得 3/4/5/4/3，每次都被杀，但哪条 `loadMemorySync` 用例撞上并列不固定，所以「4 条」只是本会话的一个采样）；⑤ `renderChangedUnderRead` 去掉 size 那一半 → 打红它的纯用例；⑥ adopt 去掉 append 前复核 → 打红 2 条（借键过期 + FIFO adopt 竞态），写竞态探针同时回 `DEFECT`；⑦ adopt 去掉「等于 fold」守卫 → 打红 1 条；⑧ adopt 去掉「必须比 journal 新」守卫 → 打红 1 条。**没有存活变异体**；⑦⑧ 的「朴素写法」（直接删守卫）会因 `noUnusedLocals` 报 `TS6133`，按纪律重塑成保留符号引用的形式后才算有效变异体。
- 与 pi 的两处差异（有意）：① pi 只把 `loadMemory` 收敛到一致读取，本批把**同步读者**也收敛（同一缺陷类），代价是同步路径多两次 `statSync`；② pi 的 `flushActionFor` / `flushMemoryRender` **本批不端口**——它属**批次 P**（退出不再调模型生成），用户尚未裁决，而 dsh 今天没有 flush 调用点，先落这张纯表就是死代码。
- 边界/残留（**不要读成已修**）：① `readRenderWithMtime` 的 `changed` 是 **mtime + size 启发式**，同尺寸且落在文件系统时间戳粒度内的替换仍看不见——**登记残留**（发布决策本身走内容键 `memoryComparisonKey`/`basisKey`/`nowKey`，mtime 只决定「要不要把读到的那一版当基准」这一次级判断）；② 从最后一次读取到 `appendMemoryOp` 之间的窗口仍在，与本模块其余写路径同宽；③ **同步读者的 `changed` 分支没有夹具能驱动**（同步读取无法在进程内被替换打断），由 `renderChangedUnderRead` 的具名用例 +「同步读者与异步读者对稳定文件读法一致」的正向控制覆盖，「同步读者在真实跨进程替换下会拒绝」本批**无法证明**；④ **只由标题组成的 render**（`"# Project Memory\n"` 这种）**在修复前就赢读取**——既有的洞，本批没有改变它（网格确认两版一致），它属**批次 Q** 的判据（「回复须是本扩展文档形状」）；⑤ adopt 的 append 前复核在「文件被同内容重写」时会保守拒绝并记一条（措辞已改成对两种分支都成立的说法，不再声称「更新的编辑到了」）；⑥ `journalInfo` 在 render 读之后取，仍有同样的固有窗口；⑦ **只由标题组成的 render** 那条（见上）同时是复目标出的 **MEDIUM/既有**，也是「同一个用户意图、最便宜的下一步」——但它属 Q 的判据面，本批不动；⑧ 测试文件的 `/tmp` 残留：`project()` 没有清理，本文件跑一次留下 44 个 `dsh-memory-*` 根目录（**全套件既有行为**，本批未改；三个探针自己 `finally` 清理）；⑨ 不改配置键、无新依赖、两个 profile 无需改动，但**改了 `src/` 行为，需要宿主重启才在线**（判据照旧：持有者启动晚于最后一个 `src/` 提交）。

**project-memory（批次 N：段配额从硬上限降为目标值，第九次 pi triage）**

- 修复：**渲染器此前为「段配额」丢条目，而文档本身还有余量**。四条 share（Project 0.17 / Invariants 0.45 / Pitfalls 0.29 / Index 0.09）被当作每段硬上限，`renderMemoryDocument` 从任何超额的段里整条丢弃，于是「闲置段的余量」无法补「超额段的超支」——本项目自己的 Pitfall 记的就是这一类损失，而 `sectionDropped` / `droppedItems` 把它误报成「某段超预算」。现在（pi `e2184af`）分配分两步：每段先拿 `min(需求, 自己的目标)`，用不完的进池；超额段按**超出量比例**从池里借（`allocationFor`）。池能覆盖全部超额时比例分配精确等于各自超额，一条不丢；只有整个文档到达 `maxMemoryChars` 才丢条目。每项的 per-item cap 跟随**借到的额度**而不是旧 share，所以借到额度的段能把长条目整条留下（只裁到 `MAX_LIST_ITEM_CHARS`）。
- 修复（同一轮，复核级发现）：**池的口径是文档的真实 body，不是 Σtargets 的目标和**。`memoryStructureOverheadChars()`（header + 每段 `## H\n` + 段间空行 = 67）与 `memorySchemaOverheadChars()`（保守版 = 76）不同：后者故意多留空行给 share 当分母，前者才是渲染器真正的结构开销。用 Σtargets（cap 4000 时 3922）当池的分母，会在文档还有 11 字符余量时丢条目——正是本条要修的那类浪费。新夹具（内容逐文档装得下、但超过目标和）钉住它。
- 修复（独立复核 F1，本批修掉）：**分配器量的是未裁剪的条目长度，打包却按裁剪后的长度收费**。任何超过 per-item cap（800，或借到的更小 cap）的条目都会把自己所在段在 `overTotal` 里放大，于是真正超额的那一段拿不到应得的份额，**在文档远没满的时候丢掉整条**。复核给出的最小复现（本会话第一手复现过）：cap 4000、Project 一条 2000 字符、Invariants 三条 700 字符 ⇒ `droppedItems 1`、渲染 2276，而规范文档只有 **2979 / 4000**；去掉那条长条目的对照则 0 丢弃。端到端后果是一次 `lossy-refused`——**一条拟合法的回复被拒绝，并报成「文档到达上限」**，正是本批要消灭的误归因。现在需求按 `min(条目长度, MAX_LIST_ITEM_CHARS)` 计：item cap 永不超过该值，所以这是真实成本的上界，且在段被借到 item cap 时精确。**这是 dsh 对 pi 的一处有意偏离**——pi `origin/master` 的同一行同样未裁剪，本批不跟随。
- 回归证据（判别器，不只是证据）：把入库模糊探针「装得下就不丢」的前提改成按 item cap 裁剪后，对**修复前**的 lib（`ee62e3e`）跑出 P2 **违反 4,598 / 148,978 组（≈3.1%）**，对修复后 0 违反。新增具名用例「an over-long entry does not cost a neighbour its entry」（带同内容对照），强化后的性质测试（生成器进入 `>800` 字符区间）也一并打红——旧生成器只出 1–300 字符，结构上永远进不了这条缺陷所在的区间。
- 同一轮的复核级文案/注释修正：`MEMORY_SURVIVAL_CAPTION` 从「a **section** that does not fit its budget」改为「a **document** that does not fit its cap」（pi `e2184af` 改的正是这一句，本批此前漏了，于是提示词一边说「段可以超过自己的 share」一边说「段不合预算就要压缩」）；`index.ts` 四处注释（「to their budget」/「overflow a section's share」/「their section's budget was full」）改为「文档到达上限」；`sections.ts` 的「smallest section budget is 588」改为 353（重平衡后的真值）。
- **保留的边界（未关掉，已写进 `renderMemoryDocument` 的文档注释）**：需求是上界而不是打包后的真实成本，所以当某段借到的额度**小于** item cap、且持有**多条**长条目时，仍可能丢掉一条本可保住的条目。真正的修法是让分配与 item cap 迭代到不动点（`min(len, itemCap(allowance))` 的自洽解），那是另一个设计而非一行修正，本批不做。
- **保留 dsh 的重平衡数字，只改语义**（与 pi 相反）：pi 在**旧**数字（0.2/0.4/0.25/0.15）上改语义，dsh 的 `f38a0ba` 在**旧**语义上只改数字（→ 0.17/0.45/0.29/0.09 + `MEMORY_SECTION_PROMPT_SHARE` 0.9）。本轮两个都保：share 仍是 prompt 展示的数字与池的分母，但不再是每段拒发线。
- 同一轮改齐的四面（都带既有断言更新）：① `errors.log` 行与 `/memory update` 回执从「`N section(s) exceeded their budget and M whole entry(ies) were dropped`」改为「`M whole entry(ies) were dropped from N section(s) because the memory document reached its character cap`」（`index.ts` 四处：落地损失行、refused 损失行、`memoryLossDetail`、`refusedLossCause`）；② 提示词的段规则从「`aim for about T characters; never past U`」改为「`aim for about T characters; its U-character share is a target, not a cap`」，引导句改为「每段列出它预期占的 share，段可以在文档整体仍在 cap 内时超过自己的 share」；③ `memoryBudgetRule` 补一句「每段数字是目标不是上限，只有整个文档超了才丢整条」；④ tier C 重试的末句不再把损失二分给「段预算」。
- **tier C 的重试算术复用同一个分配器**：`memorySectionOverage` 的 `budget` 现在是**借用后的额度**而非 share（`allocationForSections` 被两者共用）。否则重试提示会让模型按错的数额压缩——本项目自己的不变量：第二个估算比不重试更糟。该条由 `test/sections.test.mjs` 的 overage 用例钉住（报告值 806 而非 share 353）。
- 逐条按新语义**正确**改写的既有断言（不是迁就，是缺陷被修掉）：① `memorySectionOverage` 的 `budget` 断言（353 → 借满后的 803）；② `clipped-then-dropped` 夹具——池上线后那两条条目真的都装得下（文档只用了 1406 / 3933），改为「先把 Project 的借用额度填满，再让一条 900 字符条目无处置放」；③ tier C 的「小上限拒绝 / 大上限存储」夹具——120 条短条目只占 2280 字符，池上线后**真的装得下**，按测试原意给每条加长，使其在小上限真超、在大上限仍装得下。
- 门禁：`pnpm typecheck` 0；`pnpm build` 0（`lib/client.js` 仍 28575 字节）；`pnpm test` **419 通过 / 0 失败**（本批新增 3 条具名用例，另扩展 1 条性质用例）。**5 个变异体全部被杀**，每个都 `tsc` 0 错、标记进/出 `lib/` 已核对、恢复后 `sha256sum -c` 全通过、重建后 `lib/` 0 标记：① 池按目标和起算 → 只打红「池是文档真实 body」那条（`1 !== 0`）；② 完全忽略池（硬 share）→ 打红 6 条，含借用与长条目用例；③ per-item cap 取自 share → 打红 2 条（借用、长条目）；④ overage 报 share 而非额度 → 只打红 overage 用例（`353 !== 803`）；⑤ **需求改回未裁剪（即 F1 本身，修复前它存活）→ 打红 3 条：新增的长条目用例、强化后的性质测试、overage 的 `806 !== 803`**。**一个变异体被判无效而不是存活**：把池的表达式换成 Σtargets 会让 `memoryStructureOverheadChars` 变成未使用，`tsc` 报 TS6133（退出 2）——按纪律重塑为「池被目标和封顶」后才是有效变异体。
- 边界/残留（**不要读成已修**）：① `cap < memoryStructureOverheadChars()`（= 67）时文档骨架本身超上限、渲染返回 67 字符，这是**端口前 `4e0aa0f` 就有的既有行为**（比对 602 组 cap/内容：`overNewOnly 0`），生产不可达（`maxMemoryChars` 下限是 `MIN_MEMORY_CHARS` 4000），入库探针按「排除并打印排除数」处理；② 本批**提交信息里**写的 66 / 3934 / 3924 是错的（函数返回 67、body 3933、Σtargets 3922）——提交已推送不重写，正确数字在本文件与测试注释里；③ pi 的 `droppedSamples`（在回执里列 `Dropped, e.g. …`）**未端口**——dsh 每次有损写入都写 `errors.log`，pi 那条的存在理由是「日志行可能没写」，属 pi-only；④ `MEMORY.md`/`CONTEXT.md` 里写下的「占用份额」散文不随本批改变，仍按现跑 `share-fit.mjs` 判读；⑤ 本批不改配置键、无新依赖、两个 profile 无需改动，但**改了 `src/` 行为，需要宿主重启才在线**（判据照旧：持有者启动晚于最后一个 `src/` 提交）。

**project-handoff（档 5 事后自愈：标题写入必须离开事件派发信封）**

- 修复：**档 5 的写入此前从未落地过一次**。它在 `Session.append` 的观察者派发**内部**同步调用 `SessionTitleService.rename`，而 `rename` 自己会 `session.append('session/title', …)`（`packages/session/session-title/src/index.ts:412`）—— 宿主的重入守卫直接拒绝：`packages/core/session/src/index.ts:740-743` 抛 `session append cannot reenter while another append is being published`，因为 `:754` 已把 `entry.appending = true`、`:764` 调观察者、`:412` 同步执行 `callback(...)`（`invokeContainedSessionObservers`，宿主自己的用例就叫 `contains a reentrant observer append…`）。该拒绝被本模块自己的 `catch` 吃掉，只留一条**读不到**的 warn（`relabel.ts`），症状于是是「什么都没发生」。宿主自己的标题服务就是现成证据：它把兜底写放进 `this.defer(async () => …)`（`session-title/src/index.ts:515`，`defer` = `Promise.resolve().then`，`:726`），理由与此完全相同。现改为只在**判定**阶段同步（前缀判据、`firstHandoffInput`、seq 门禁一字未动），写入放进一个微任务；服务方法读一次并用 `.call(titles, …)` 保留接收者（服务靠 `this` 才能 append）。「每条续接最多写一次」仍由 seq 门禁保证，不是由标题比较保证。
- 为什么以前的具名用例全绿：`test/handoff-relabel.test.mjs` 用的是**手写 fake session**，它没有重入守卫，所以「同步写」这个缺陷在它上面不可观测。新增真 `SessionStore` 用例（`Context` + `await ctx.plugin(SessionStore)` + 一个挂在 `sessionTitle` 键上、`rename` 真 append 的服务）：先跑**对照**——同一个 `rename` 在信封内被拒、标题不动、宿主点出 `cannot reenter`；再走与 `index.ts` 相同的接线，断言信封未关时**不写**、unwind 后**恰好写第二条** `↪ handoff · 按档 5 动手`、且没有 `title not updated` 警告。该文件现为 **9 条具名用例**（上一批 8 条）。
- 变异校验（1 个变异体，被杀死）：把微任务改回同步 IIFE（`void Promise.resolve().then(() => {` → `void (() => {`），`tsc` 0 错、标记进 `lib/`、`node --test test/handoff-relabel.test.mjs` **8 通过 / 1 失败** —— 只打红新增那条真 store 用例，其余 8 条 fake-session 断言照旧全绿（这正是缺陷当初能上线的原因）。恢复用 `/tmp` 哈希副本 + `sha256sum -c`，重建后 `lib/` 0 标记、`lib/client.js` 仍 28575 字节。全量门禁 **416 通过 / 0 失败**（上一批 415，本批 +1）；`lib/` 与新鲜 `tsc --outDir` 编译 `diff -rq` 只剩 `client.js`。
- 复现/验收探针：`.agents/evidence/2026-10-07-handoff-relabel-reentry/probe.mjs`（驱动 `lib/`，`exit 0` = 5/5 全过，其中两条是对照）。修复前同一探针打红「信封 unwind 后写入」那条，并印出真实拒绝原因 `session append cannot reenter while another append is being published`。
- 宿主侧验收探针（本轮新增，`src/` 未动）：`node .agents/evidence/2026-10-07-handoff-retitle-accept/retitle-accept.mjs` —— 判据是某条续接的**首条人类输入**落在持有者启动之后（用 `lib/` 的真实 `firstHandoffInput` 取 seq 与时间，不用会话创建时间、也不用文件 mtime；迁移过的会话目录里旧版 `session.vN` 与新文件并存，只读最高版本，否则标题事件会被数两遍）。退出码是三态：`0` = 已写出第二条 `session/title`、`1` = 该写却没写（真红）、`2` = 判据为负或还没有可判的续接（**不是**绿）。`--selftest` 在 `/tmp` 的合成会话目录上把三种判定全跑通（失败路径可达）。现跑 `exit 2`：判据为负（持有者 22:45 早于 `bb8bc2a`），两条候选本该被记 note 而不是假红 —— `42bcc5f4` / DSH-AV `440ccfc9` 的首条输入都在 22:47，早于修复落地。
- 现场证据（只读，两个 workspace）：宿主 pid 4890 起于 22:44:59（重启）之后，只有 2 个带前缀的交接子会话收到过**自己首条 `kind=user`** 输入 —— 本 workspace `42bcc5f4`（「检查？」，seq 123 @ 22:47:06）与 DSH-AV `440ccfc9`（「继续」，seq 447 @ 22:47:10）—— 两者都只有 **1 条** `session/title`，与「每次都抛重入」一致；两条日志里判据本身都成立（首条人类输入的 seq 就是触发事件的 seq，存标题就是 `↪ handoff · <父 id>`，不是用户改名）。
- 顺带排掉的两个旧疑点（只读核对，都不是原因）：① **不是事件顺序** —— `session/src/index.ts` 先 `this.log.push(event)`（`:761`）再派发观察者（`:764`），所以监听器读到的 `snapshotEvents()` 已包含该事件；② **`ctx.get("sessionTitle")` 在本部署可用** —— 宿主 `SessionController` 的 `static inject`（`packages/api/session-controller/src/index.ts:100-112`）**不含** `sessionTitle`，却用同一个 `ctx.get('sessionTitle')` 读写（`commands.ts:195`），而这条路径确实 work（本会话标题就是它写下的）；宿主发布的 Service 契约也把 `ctx.get("sessionTitle")` 列为 optional 访问式。
- 边界（**不要读成已修**）：标签质量不变（机械文本、不是摘要；旧播种路径的注入状态行仍可能当上标签）；「最多一条」仍来自**事件只投递一次**、不是来自标题比较；首条人类输入早于本插件实例的子会话不受影响；`handoffEnabled: false` 与 `sessionTitle` 缺席仍安静不动，`rename` 抛错（会话已不 live）仍只记一条 warn，绝不打断承载输入的那一轮。
- 状态：**已落地 `src/`/`lib/`，尚未在宿主重启后验收** —— 判据照旧「19387 持有者启动晚于最后一个 `src/` 提交」。不改配置键、无新依赖、两个 profile 无需改动。

**project-handoff（交接子会话标题：事后自愈，档 5）**

- 新增：交接子会话收到**自己第一条可用人类输入**时，把标题从「父会话 id」改成那句话（`src/project-handoff/relabel.ts`；触发在 `index.ts` 的 `session/event` 的 `user/message` 分支）。上一批（档 1/3）在交接那一刻只能拿父会话的输入，父会话没有人类输入时退回父 id——本链每一棒都如此，所以侧栏永远显示旧 id。子会话自己的日志是唯一出现更好标签的地方，读它零成本：没有模型调用、没有新依赖、没有新事件类型。
- 写入**无进程状态、每条续接最多一次**：标签取子会话第一条「命名得出来」的输入（`conversation.ts` 的 `firstHandoffInput`），它读的是**持久日志**（`session.snapshotEvents()`，与宿主自己的标题读者 `collectSessionTitleMessages(session.snapshotEvents())` 同源）而不是 `deriveMessages()`——压缩会把早先的 surface 节点删掉，派生出来的「第一条」会悄悄变成另一条；同时它连那条输入自己的 `seq` 一起返回，`relabel.ts` 只在**正在处理的事件就是承载它的那条**时才写。所以一个子会话最多写一条 `session/title`，插件重启也不会重复写，**用户自己起的名字永远赢**（不带前缀即不认）。取第一条而不是跟踪最新，是为了标题稳定——每来一条消息就变的侧栏条目比过期 id 更糟。
- 判据与档 1/3 同源（`source.kind === "user"` + `isHandoffContinuationText` + `hasVisibleText`），只是读会话的另一端；只由不可见字符组成的第一条**跳过而不终止**，不占用它唯一那次机会。前缀照旧保留（`marker.ts` 的切换判据），写的是与 dsh 自己 rename 相同的 `session/title{source.kind:'user'}`，所以服务此后同样不再自动改名。服务存的是它归一化后的标题，所以「被整体剥掉」的标签（正文可打印的转义序列是可达那一类）用同一个 `retitleAfterRename` 兜底，把**上一版标题**写回去——上一版是同一服务接受过的，不可能再丢前缀。
- 门禁：`handoffEnabled: false` 时不写（README 对应行已写明）；`isTopLevel` 仍拦子代理会话；`sessionTitle` 服务缺席时安静不动；`rename` 抛错（会话已不 live）只记一条 warn，绝不让显示层的小事打断承载那条输入的一轮。
- 具名用例 8 条（`test/handoff-relabel.test.mjs`），每条负例都在同一用例里带正例控制。全量门禁 **415 通过 / 0 失败**（本批新增 8；上一批落地时 407）。**4 个变异体全部被杀**，每个都 `tsc` 0 错、标记进 `lib/`、恢复后 `sha256sum -c` 全通过、重建后 `lib/` 0 个标记（`lib/client.js` 仍 28575 字节）：①`humanUserText` 不再过滤旧交接横幅 → 打红 5 条（本批 1 条，加上已有的 `conversation-turns`/`logic` 横幅 pin——同一个事实的既有读者）；②`storedHandoffLabel` 去掉前缀校验 → 打红「不是交接会话的标题永不改写」+ 接线用例里的用户改名负例；③`firstHandoffInput` 改成只认压缩后表面还留着的那条输入 → 只打红「按持久日志命名」那条；④`relabel.ts` 忽略触发 seq → 只打红「无论服务存什么都只写一次」那条。**另有一个变异体被判无效而不是存活**：去掉 `index.ts` 的 `source.kind === "user"` 早退没有任何行为变化（`humanUserText` 本来就按 kind 过滤），所以它不构成缺口——那行只是省一次标题折叠的优化，判据仍然只有一处。
- 真实语料（只读探针 `.agents/evidence/2026-10-07-handoff-relabel/probe.mjs`，`exit 0` = 13/13 全过）：本 workspace 113 个归档会话、99 个交接子会话里，这条规则会命名 **49** 个，其余 50 个（还没人打字）保持交接时给的标题；49 个标签里 31 条是真指令、6 条「继续」、7 条 ≤4 字、5 条是旧播种路径注入的状态行。三个负例控制都在真数据上成立：去掉横幅谓词后翻红（27 个横幅全部成为标签、「横幅之后还有输入」的子会话从 20 掉到 0）；**4 个子会话带压缩（`compact-checkpoint` 的 ranged `replace`），4 个按持久日志与按压缩后表面会被命名成不同的标题**，所以「读日志」不是一个空头保证；`storedHandoffLabel` 对 99 个带前缀的标题与 14 个不带前缀的标题判得完全一致。**计数随会话增长，引用必须现跑。**
- 修复（独立只读复核，同一未发布条目内）：**「一条」这条声明原先站不住**，两处都被复现。① `firstHandoffInput` 原来读 `deriveMessages()`；宿主的 surface 折叠会把被 `replace` 遮蔽的节点从派生里删掉（`packages/core/session/src/index.ts`），实测 `session-0868f73f-63b` 压缩后派生的第一条人类输入从 seq 13 变成 seq 721，于是标签会变、下一次输入就会再写一条 `session/title`——正好是这套设计要避免的「标题在用户眼皮底下变」。② 触发判据原来是「标题已经等于前缀+标签就跳过」，而服务存的是它归一化后的标题（`cleanTitleText` 去 ANSI/`Cc`/`Cf`、折叠空白），所以凡是会被服务改写的标签，这个比较**永远不相等**，每来一条输入就再写一次同样的标题（用宿主自己的 `normalizeSessionTitle` 驱动 4 条事件：4 次 rename；裸 ANSI 那一类因为兜底回写而 8 次）。真实语料可达性 0/49，属「可达但未观测」。现在改成 ①读持久日志、②触发只认首个命名输入那条事件的 seq，两条都由具名用例钉住（后者用一个模仿宿主归一化结果的 fake service，因为语料碰不到）。同一轮还修掉探针两处：第 1 节的检查宣称「fits the byte budget」却只量字符数（现按 `Buffer.byteLength(前缀+标签) ≤ 80` 真量），README 里「探针按 `deriveMessages()` 重建、与插件一一对应」的说法在①修好之前是错的（现在两者同源）。
- 边界（**不要读成已修**）：标签仍是机械文本、不是摘要——第一条输入是「继续」就显示「继续」；旧播种路径的注入状态行（`handoff Auto handoff ON · context …` 之类）若恰好是第一条可用输入，仍会当上标签（没有现成谓词，本批不为它们再写一个措辞启发式）；只写一次，所以子会话后来的更好输入不会再改标题；这个后缀也仍不是交接判据（`marker.ts` 只认前缀）。「最多一条」的保证来自**触发点只发生一次**（事件只投递一次），不是来自标题比较：同一条事件若被重复处理，被服务归一化的标签会再写一次——host 不这样做，这条写在用例的注释里而不是当成已修。「首条人类输入早于本插件实例」的子会话不会被改名（旧交接子会话因此不会事后自愈）。
- 状态：**已落地 `src/`/`lib/`，尚未在宿主重启后验收**——判据照旧「19387 持有者启动晚于最后一个 `src/` 提交」。不改配置键、无新依赖、两个 profile 无需改动。

**project-handoff（子会话标题改用父会话最后一条人类输入）**

- 新增：交接那一刻写给子会话的标题从 `↪ handoff · <父会话前 8 位>` 改为 `↪ handoff · <父会话最后一条人类输入>`（裁剪到 20 字符、单行；算不出则退回父 id）。前缀是浏览器半边自动切会话的判据（`marker.ts` 的 `planHandoffWatch` 只看 `startsWith`），只有前缀之后的部分是自由的。动机是实测：93 个已归档交接子会话的侧栏一律显示父 id，而按此口径 **31 条**会变成有意义的指令（38 条父会话没有任何人类输入、只能退回 id，其余是「继续」/≤4 字/旧横幅之类的噪声）——这些计数随会话增长，写在这里的是当时口径，现跑见该探针的打印输出。零模型调用、零新依赖——批次 J 之后交接路径刻意不带模型调用，这条只用会话里已有的文本（`conversation.ts` 的 `handoffLabel` 读 `session.deriveMessages()`）。判据是 `role === "user" && source.kind === "user"` **且文本不满足 `isHandoffContinuationText`**：注入的运行时上下文快照（`runtime-context`）、本插件自己的种子横幅（`dsh-project-context`）与子代理消息各有自己的 kind，都被 kind 拦掉；第二种判据拦的是旧播种路径留下的横幅，见下一条修复。
- 新增：`src/shared/text.ts` 的 `clipTitle(value, limit)`——单行标签裁剪（先折叠空白、切点不落在半个代理对上、截断处以 `…` 结尾）；`src/project-context/session-index.ts` 原有的同名私有 `clip` 改为直接复用它，于是索引标题与侧栏标题是同一套裁剪。20 字符这个上限是**按字节**定的：dsh 服务把标题静默截到 `maxTitleBytes: 80`，而 `↪ handoff · ` 占 15 字节，20 字符的标签最多 60 字节（全 CJK 也是每字符 3 字节，结尾的 `…` 就占其中一位、不是第 21 位），合计 75 —— 永远不会被服务再从中间切一刀。
- 边界（**不要读成已修**）：标签是机械文本、不是摘要——父会话最后一句是「继续」就显示「继续」；要真摘要必须让交接路径重新调一次模型（取舍 brief 里的档 6，与批次 J 的决定相反，本批未采用）。`handoff deferred · `/`handoff failed · ` 两个失败前缀保持父 id 不变。旧播种路径的注入状态行（`handoff Auto handoff ON · context …` 之类）也仍是噪声标签：它们是历史文本、没有现成谓词，本批不为它们再写一个措辞启发式。
- 修复：**只按 `source.kind === "user"` 过滤，会让旧播种留下的横幅当上标题**。播种曾走 prompt RPC，而那个 RPC 硬编码 `source.kind = "user"`（`perform.ts` 正是因此不再用它），所以旧子会话自己的横幅是一条**人类 kind** 的消息；它若恰好是父会话最后一条 `kind=user`，新子会话的标题就变成 `↪ handoff · 从会话 session-<另一个会话>…`——点名了父会话的上一棒，比退回父 id 更误导。现在 `handoffLabel` 复用与另两个「用户说过什么」的读者（`readSessionInputs`、`shared/conversation.ts` 的 `humanUserText`）相同的谓词 `isHandoffContinuationText`。回归测试是**独立具名**用例 `a legacy kind=user seed banner does not name the continuation`——删掉谓词时同文件的对照用例 `the child's title is named after the parent's own last input…` 保持**绿**，证明两条 pin 各自独立。变异体（把 `handoffLabel` 的循环改回 pre-fix 的 `if (text.length > 0) last = text;`）：`tsc` 0 错、标记进 `lib/`、只打红该条。真实语料可复跑：`.agents/evidence/2026-10-07-handoff-label-banner-repro/probe.mjs` 直接驱动 `lib/` 的 `handoffLabel`——97 个交接子会话里 6 个的父会话最后一条人类 kind 消息是横幅，六条全部被拦（pre-fix 会把它们变成 `从会话 session-…`）；把谓词从 `lib/` 改回 pre-fix 后该探针 exit 1 并逐条点名，失败路径可达。补上后全量门禁 **406 通过 / 0 失败**（这一条落地时 405；下一轮 retitle 修复加用例后 407，本轮结束仍是 407）。
- 变异校验（1 个变异体，被杀死）：把 `handoffLabel` 的返回值从 `clipTitle(last, HANDOFF_LABEL_CHARS)` 改成 `clipTitle(fallback, HANDOFF_LABEL_CHARS)`（标签退回父 id，同时保证 `last` 仍被引用、不触发 `TS6133`）——`tsc` 0 错、标记进 `lib/`、恢复后 `sha256sum -c` 全通过、`pnpm build` 后 `lib/client.js` 仍是 28575 字节。**该轮只有一个标签用例，所以当时只打红那一条；下一条修复加了第二个用例后，今天重跑同一变异体会打红 2 条**（标签用例与横幅用例），别把它读成「只打红一条」的永久承诺。
- 修复（独立只读复核，同一未发布条目内）：**服务存储的是它归一化后的标题，而归一化可能吃掉前缀自己的那个空格**。`rename()` 把 `cleanTitleText`（丢控制字符/不可见字符 + 末尾 trim）+ `truncateTitleUtf8` 的结果落盘，所以一个**只由这类字符组成**的标签会让标题变成 `↪ handoff ·`（14 字节，少一个空格）——`planHandoffWatch` 用 `startsWith('↪ handoff · ')` 匹配，于是浏览器**永远不会切到子会话**，而插件这边 `rename` 成功返回、日志照常。实测（宿主自己的 `normalizeSessionTitle` + 本插件 `handoffLabel`）：`"\u200B"`、`"\u0001"`、裸 ANSI 序列三种标签都会这样落地；真实语料里 0 例（97 个交接子会话，其中 96 个能取到父会话日志），所以这是**可达但未观测**的静默失败，而不是历史故障。修法用的是宿主自己的答复、不复制它的清洗逻辑：`sessionController.rename` 返回已被接受的标题（`{title, seq}`，宿主 `packages/api/session-controller/src/types.ts`），`perform.ts` 新增 `retitleAfterRename(accepted, label, fallback)` —— 接受值不含前缀且标签不是 id 本身就再写一次 `↪ handoff · <父 id>`（纯 ASCII，不可能再被吃掉）；返回值不可辨（旧运行时不回值、或形状不认识）或标签本来就是 id 时**什么都不做**，不把「读不懂的回执」当成失败。回归测试 `a title the service normalized down to the bare prefix is written again with the parent id`（含六条负例控制），变异体（去掉前缀校验）只打红该条。同一轮还修掉三处**写错的事实**：本条的字节算术（78→75，见上一条）、`A longer label would be cut … at a byte boundary we never chose` 的措辞（宿主 `truncateTitleUtf8` 是按码点迭代、不会切半个字符），以及上面那条变异体的「只打红一条」。语料探针同时改为从子会话**自己的种子横幅**取父 id（原来从标题里取，本批落地后标题不再含父 id，探针会停止覆盖新会话、还可能把标签误认成某个会话 id 的前缀）；现在按播种横幅解析（该轮 97/97 走 seed 路径，unresolved 0）。
- 复核闭环（同一只读评审的第二轮）：**上面这次写入只是兜底，不是保证**，两点必须说清。① 整条标签都不可见的那一类现在**在第一次写入之前就被挡住**：`conversation.ts` 的 `hasVisibleText(label)`（`\p{Cc}`/`\p{Cf}`/**空白**之外还有可见字符吗）为假时直接退回父 id，于是根本不产生「前缀少一个空格」的中间标题。空白必须算进去——它是 `Zs` 而不是控制字符、`clipTitle` 只折叠不删除，所以「不可见字符夹一个空格」的标签（`"\u200B \u200B"`）会带着空格落到服务端，服务端删掉两侧不可见字符再 trim，前缀照样丢；这条是复核第三轮抓到的，由断言 `invisible characters around a space still name nothing` 钉住，把 `\s` 从这一类里去掉（变异体）只打红标签那条用例。这是**我们自己关于标签的政策**（不可见/空白的标签不命名任何东西），**范围故意比宿主的清洗器宽**——宿主只删它自己那份方向控制字符表加大部分 C0/C1、折叠空白并 trim 末尾，软连字符、ZWNJ/ZWJ 等 `\p{Cf}` 它其实**原样保留**，所以挡住它们属于政策而不是防前缀丢失；只有转义序列（引导字节在类里、正文可打印）它看不见，仍交给 `retitleAfterRename` 兜。② **兜底挽不回浏览器已经做过的判断**：`planHandoffWatch` 会把它走过、标题是字符串但不含前缀的行加进 `markSeen`（它扫到第一行带前缀的候选就返回，之后的行这一趟不标记），而这个集合不再复查，所以若客户端在第二次写入之前扫到了那个中间标题，它已经把这个子会话标记为「看过了」——纠正恢复的是**落盘标题**（侧栏与之后任何读者看到的），不是「一定会切换」。这个残留写在 `retitleAfterRename` 的 JSDoc 里，不当作已修。判据：`hasVisibleText` 的变异体（改成恒真）只打红标签那条用例（同文件其余 22 条全绿）；探针仍 `exit 0`。
- 状态：**已落地 `src/`/`lib/`，尚未在宿主重启后验收**——本批是宿主行为，需要用户重启桌面宿主；判据仍是「19387 持有者启动晚于最后一个 `src/` 提交」。不改配置键、无新依赖、两个 profile 无需改动。

**project-handoff（越线可见：注入式压力行，批次 M）**

- 新增：**会话越过自动交接阈值时，把这一状态注入模型上下文，由模型在下一轮转述给用户**。此前越线是静默的——触发只在 `turn/end` 评估，而 `↪ handoff · a00eb4ce`（`54cdf479`）在一个**未结束的 turn** 里坐到 316,189/1,000,000 对阈值 157,000（**2.01×**），从未被评估过，用户只能自己手算发现。两个新模块：`gate.ts` 把「解析路由 → 取 `contextWindow` → `measuredContext` → `resolveThreshold`」抽成**唯一入口**（自动路径与显示层读同一个对象，避免出现第二份公式）；`display.ts` 持有按会话冻结的行。计算点是 `step/start` 而非 `turn/end`——动机案例的轮次从未结束，只有 step 能看到它；该 tick 在行已冻结后直接跳过，不再重复测量。
- 设计约束（**实测得出，非估算**）：`systemPrompt.context` 会被 harness 物化成一条**持久的 user 角色运行时上下文快照**，而快照在文本变化时是**追加**的（`surface-fold.ts` 的 `planSurfaceTokens` 对 `surfaceOp:"append"` 直接 `deltaTokens = tokens`，只有带 `startSeq/endSeq` 的 ranged op 才会 splice 掉旧节点）。证据取自本仓归档的上一个会话：`session-3a19d454` 的 log 里有 **5 条** `Current runtime context`（长度 37274/37274/37761/37513/37875，其中两条等长而 sha 不同），且该会话 **74 个 surface 事件全为 `append`、零 ranged replace**。所以一行的代价是**每次文本变化 ≈ 一次 ~37 KB 追加**，不是「每轮几个 token」；`display.ts` 因此只在**跨线**与**原因变化**时改文本，跨线后逐字节冻结。
- 新增：行内容为「占用 / 窗口 / 阈值 + 越线百分比」，并在触发被拦住时点名原因（`question` / `subagents` / `nothing-to-drop`，由自动路径在它真正做出该判断的地方记录）；文案跟随会话语言（zh/en），子会话因 `isTopLevel` 不注入，`/handoff off` 不注入。
- 修复：**语言是在每次组装时现解析的**，于是双语会话一旦越过检测器阈值，行会在 zh/en 之间翻转——那同样是文本变化，即又一次 ~37 KB 快照追加；而且每个请求都要付一次会话解析。现在语言与数字一起冻结在跨线上（`recordHandoffGate` 收下它，`handoffPressureText(session)` 只读回），context provider 退回成一次纯查表。
- 修复：**一次在 `session/disposed` 之后才落地的 tick 会把刚被清掉的行写回去**。`clearHandoffPressure` 在会话被处置时清掉冻结的跨线，但停在 `resolveModelInfo` 里的 `step/start` tick 更晚才 resolve，它的 `.then` 随即重新记录门禁——为一个再也不会组装提示词的会话留下一条**活到进程结束**的映射项，正是 `clearHandoffPressure` 本来要防的泄漏。修复前先离线复现（把 tick 停在 deferred resolver 上、中间处置会话：处置后读 `isOver` 为 false，tick 落地后读成 true）。现在 tick 只在「它飞行期间没有发生处置」时回写（`disposedDuringTick`），并由自己的 `.finally` 摘掉标记，集合规模仍只与真正在飞的 tick 数有关。由 `a tick that settles after disposal does not re-insert the line` 钉住：它的 deferred resolver 正是让该竞态可达的东西；删掉守卫只打红这一条。
- 边界（**不要读成已修**）：这一行是给模型读的，**模型是否转述无法离线证明**（与批次 I 的合规性同类，需要真实使用）。行的刷新时机仍是既有语义：自动交接只在 `turn/end` 尝试，本批**没有**改变触发时机（那是候选 (b)，仍是设计决策）。跨线后若上下文被压缩回阈值以下，行要到下一次 `turn/end` 才会被清掉——行内的数字是跨线那一刻的事实，不是实时读数。
- 变异校验（3 个变异体，均被杀死；每个都 `tsc` 0 错、标记进 `lib/`、只打红该打的那条用例）：① 把 `if (previous !== undefined) return` 改成「仅当占用未变才冻结」——`the line is frozen while the crossing holds: the text is byte-identical as occupancy grows` 变红；② 保留冻结的数字但让后续解析重盖语言——`a language flip does not re-render a frozen crossing` 变红（带着它自己的断言信息“a later en resolution must not re-render”），而占用那条保持**绿**，证明两条 pin 各自独立、不是同一条断言数两遍；③ 删掉「tick 落地晚于 disposed 时不得回写」的守卫——`a tick that settles after disposal does not re-insert the line` 变红。恢复后 `sha256sum -c` 全通过、`pnpm build` 后 `lib/` 中 0 个变异标记、`git diff --exit-code -- lib` 干净、全量门禁 **404 通过 / 0 失败**（新增 9 个用例）。离线探针 `.agents/evidence/2026-10-06-batchM-pressure-line/probe.mjs` 6/6 通过，其自身失败路径也已证明可达（把冻结条件改坏后报 5/6 并 exit 1）。
- 状态：**已落地 `src/`/`lib/`，尚未在宿主重启后验收**——本批是宿主行为，需要用户重启桌面宿主；判据仍是「19387 持有者启动晚于最后一个 `src/` 提交」。不改配置键、无新依赖、两个 profile 无需改动。

**project-memory（批次 P：teardown 不生成内容 —— 已裁决不端口，第九次 pi triage）**

- **决策（2026-10-11，用户）：不端口**。dsh 侧对 pi 那条动机链的判定是 **NOT REACHABLE**：宿主的 `emitDisposed` 对每个 listener `try/catch` **并** `.catch` 它返回的 promise，而插件自己的 `SessionWorkTracker.track` 早已用 `work.then(() => undefined, () => undefined)` 吞掉拒绝；pi 之所以中招，是它的 handler 是 `async` 且 **await**。代价那侧则是确定的：`force: true` 绕过节流，只剩 `forceDedupeMs`（15 s）去重，于是**几乎每次 dispose 都跑一次模型调用**。
- 因此**保持现状**：`src/project-memory/index.ts` 的 `agent/disposed` 仍触发 forced 的、会调模型的整理，不引入 pi 的 model-free flush；pi 的代价（两次节流整理之间结束的会话不再把尾巴写进 `MEMORY.md`）不被接受。
- 登记为**已裁决的残留**，不是待办也不是缺陷：不要重开。若宿主侧的 `emitDisposed` 抑制链将来变了，判据与探针在 `.agents/evidence/2026-10-10-batchP-dispose-escape/`（`RESULT: CONTAINED`），条目在 `docs/upstream-pi-triage.md` 的 batch P 段。

## 版本目录

| 版本 | 日期 | 主要变更 | 明细 |
|---|---|---|---|
| `v0.4.3` | 2026-10-06 | 整理提示词改为「压缩而不是删除」（批次 L） | [v0.4.3](./docs/changelog/v0.4.3.md) |
| `v0.4.2` | 2026-10-06 | 记忆分区预算、注入文档渐进披露、交接不再生成摘要、固定阈值不自称成功等 6 条 | [v0.4.2](./docs/changelog/v0.4.2.md) |
| `v0.4.1` | 2026-10-05 | `lib/` 纳入跟踪、项目根查找 | [v0.4.1](./docs/changelog/v0.4.1.md) |
| `v0.4.0` | 2026-10-05 | 命令面收口、设置名口径、autolearn 拉取模型、批 H 配置键 | [v0.4.0](./docs/changelog/v0.4.0.md) |
| `v0.3.0` | 2026-10-05 | 归档范围与会话索引、四节预算记忆、丢失回执与档 C、批 D/E 等 15 条 | [v0.3.0](./docs/changelog/v0.3.0.md) |
| `v0.2.1` | 2026-09-26 | 设置卡片改用平台组件、并发写入保护、自动沉淀 | [v0.2.1](./docs/changelog/v0.2.1.md) |
| `v0.2.0` | — | dsh 0.1.7-rc.2 宿主 API 适配、设置卡片、源码结构 | [v0.2.0](./docs/changelog/v0.2.0.md) |
| `v0.1.0` | 首个正式版本 | 归档 / 记忆整理 / 自动沉淀 / 交接四阶段首版 | [v0.1.0](./docs/changelog/v0.1.0.md) |
