/**
 * Mechanical session index: `<memory>/session-logs/INDEX.md`.
 *
 * One line per archived session, written without any model call — the archive
 * step (S0) owns it. The title comes from dsh's own `session/title` event,
 * falling back to the first user message. Later passes (autolearn backtracking,
 * handoff pointers) read the index to navigate the raw archive.
 */
import type { Session } from "@deepseek-ai/dsh-session";
import type { SessionMeta } from "./session-meta.js";
interface SessionIndexEntry {
    id: string;
    date: string;
    title: string;
    /** Absolute path of the session's Markdown rendering. */
    file: string;
    /** Absolute path of the canonical JSONL archive (the source for backtracking). */
    raw: string;
}
/**
 * Title from a bare event list: `session/title`, else the first user message a handoff did not
 * generate, else a fallback. Both harnesses that write into `.agents/` are read — dsh's named
 * events and pi's bare `message` event — so a pi archive imported by dsh gets the same title the
 * live path would.
 */
export declare function sessionTitleFromEntries(events: readonly unknown[]): string;
/** Title dsh itself assigned to the session, else the first user message, else a fallback. */
export declare function sessionTitle(session: Session): string;
/**
 * One Markdown index line from its parts. Links are relative to `session-logs/`.
 *
 * The link points at `session.jsonl`, the canonical log, rather than the rendered
 * `session.md`: the JSONL is what every reader actually opens (autolearn's backtrack,
 * the import completeness check) and it is never pruned, while the rendering is
 * reproducible from it and may be deleted to reclaim disk. Deleting it is only safe
 * once that is acceptable to every pointer: `performHandoff` writes the successor's
 * handoff document against `session.md`, so a deleted rendering leaves that pointer
 * dangling until the session renders again. Parsing ignores the target, so both
 * forms read identically.
 */
export declare function sessionIndexLineFrom(id: string, createdAt: number, title: string): string;
/** One Markdown index line. Links are relative to `session-logs/`. */
export declare function sessionIndexLine(session: Session, title?: string): string;
/** Parse an INDEX.md body; unrecognized lines are ignored. */
export declare function parseSessionIndex(text: string): Array<{
    id: string;
    date: string;
    title: string;
}>;
/**
 * Whether an adopted file still has the size and mtime it had when it was read. Exported for its
 * own unit test: the check has to notice an *append* (same inode, new size/mtime), and the
 * end-to-end adoption test cannot reach that case — there the write replaces the path and so
 * changes the inode too, which an identity-based (and append-blind) check would also catch.
 */
export declare function untouchedSince(file: string, adopted: {
    size: number;
    mtimeMs: number;
}): Promise<boolean>;
/** Read the index with absolute paths so later passes can open the archives directly. */
export declare function readSessionIndex(projectRoot: string): Promise<SessionIndexEntry[]>;
/**
 * Every archived session's metadata, in directory-name order.
 *
 * The read-only half of the walk `regenerateSessionIndex` performs below; that one also writes metadata
 * back for a directory that predates `meta.json`, so it cannot serve a reader. A directory whose
 * metadata is unreadable is skipped rather than failing the listing: the next index write rebuilds it
 * from the archive, and a navigation command must not be the thing that breaks on one bad file.
 * @param projectRoot - the project whose archive to list.
 * @returns every session's metadata; empty when the archive directory does not exist yet.
 */
export declare function listArchivedSessions(projectRoot: string): Promise<SessionMeta[]>;
/**
 * Bind (or unbind) this session to a task, then refresh the index.
 *
 * The binding lives in `meta.json` so it survives a restart, and it is written through the same
 * queue and locked section as every other metadata write: a concurrent archive write must not
 * interleave with it, or the binding and the row would disagree. `undefined` removes the field —
 * an unbind is an authored decision, not a missing value, so it must not be restored by the merge
 * above.
 * @param projectRoot - the project whose `session-logs/` holds this session's metadata.
 * @param session - the live session being bound.
 * @param task - the slug to bind, or `undefined` to unbind.
 * @returns the metadata that landed.
 */
export declare function setSessionTask(projectRoot: string, session: Session, task: string | undefined): Promise<SessionMeta>;
/**
 * Regenerate the index once per project per process, at startup.
 *
 * Every index write already reconciles, so this is not a repair path: it is what makes a directory
 * that appeared without any session write (a wholesale migration, an install whose archive path
 * never ran) show up without waiting for the next unrelated write. Idempotent by construction —
 * generation reads the directory listing, not the document — so a repeat costs one scan and no
 * change. A failed pass drops the marker so a later trigger can retry; a silent failure would leave
 * the index wrong until some session happened to write.
 */
export declare function reconcileSessionIndexOnce(projectRoot: string): Promise<void>;
/** Record this session in the index. Idempotent: the directory is the key and the title is refreshed. */
export declare function queueSessionIndexEntry(projectRoot: string, session: Session): Promise<void>;
/**
 * Record one index line (import and backfill callers that have a rendered line rather than a session).
 *
 * The line is parsed back into metadata rather than kept as text: the index is a projection, so a
 * line that never reached `meta.json` would vanish on the next generation. A line the pattern cannot
 * parse keeps its own text as the title and today's date.
 */
export declare function queueIndexLine(projectRoot: string, id: string, line: string): Promise<void>;
export {};
