/**
 * The continuation session itself: create it in the parent's workspace, carry the model
 * selection and the permission preset the user had switched to, and undo it when the
 * handoff is abandoned. Every step fails open — a child that already exists must not be
 * failed by configuration that could not be carried.
 */
import { type Context } from "@deepseek-ai/cordis";
import { type Session } from "@deepseek-ai/dsh-session";
import { type SessionControllerLike } from "./runtime.js";
/**
 * Start the handoff child session in the parent's workspace.
 *
 * The web client groups sessions by workspace membership, not by cwd: a child
 * created from `cwd` alone is listed under "未分组" even though its directory is
 * the project root. `session.create` also takes `workspaceId` (mutually exclusive
 * with `cwd`), which derives the cwd from the workspace record and attaches the
 * child to it. Only an exact canonical cwd match counts: the registry resolves by
 * exact path, and guessing an ancestor would silently move the child's cwd.
 * Resolution stays best-effort so profiles without a workspace registry keep the
 * previous cwd-only behavior.
 *
 * The child is an ordinary session in the same workspace: `SessionCreateRequest` is
 * only `{workspaceId?, cwd?, sessionId?, agentPreset?}`, so a handoff cannot chain a
 * parent link, and pi's ever-deepening handoff tree (its 8a2e6e4 flattens a chain
 * that grew one level per handoff in the selector) has no dsh counterpart. The
 * workstream stays reachable through the handoff prompt, `HANDOFF.md` and the index.
 * @param ctx - plugin context carrying the optional workspace registry service.
 * @param controller - the session controller that creates the child.
 * @param cwd - the parent session's cwd, when it has one.
 * @param agentPreset - the parent's agent preset, when dsh composed this session
 *   from one. The preset decides the session's tools and prompt, so dropping it
 *   would resume the work under the deployment default instead.
 * @returns the created child session id.
 */
export declare function createChildSession(ctx: Context, controller: SessionControllerLike, cwd: string | undefined, agentPreset?: string): Promise<string>;
/**
 * Carry the parent's permission preset into the continuation. `SessionCreateRequest` has no
 * permission field either, so the child otherwise starts on the deployment/user default: a parent
 * the user had switched to full access hands off to a child that asks for approval again (observed
 * 2026-09-16 — parent `danger-full-access`/`never`, child `workspace-write`/`ask`), which stalls the
 * continuation on its first sensitive tool call.
 *
 * The preset service writes through the child's live Session (`session.append` + the sandbox and
 * approval knob setters), and `session/create` publishes that Session into the in-memory store
 * before it returns, so the child is reachable here. Fail-open in every direction: no service, a
 * child that is not resident, a derived `custom` combination (which the service refuses as a switch
 * target), or a rejected switch must never fail a handoff whose child already exists.
 * @param ctx - plugin context, for the optional services and the warning log.
 * @param childId - the child session to configure.
 * @param session - the parent session being handed off.
 */
export declare function carryPermissionPreset(ctx: Context, childId: string, session: Session): void;
/**
 * The model selection to carry into the continuation: whatever the parent was last routed to, as
 * recorded in its request header. The selection is Session-local (the browser's model picker writes
 * it through `session/selectModel`), and `create` takes no model at all — `SessionCreateRequest` is
 * only cwd/workspaceId/agentPreset — so without this the child would start on the deployment default
 * and silently drop the model and thinking level the user had switched to. Returns `undefined` when
 * the parent has not routed a request yet or the header carries no usable pair.
 * @param session - the parent session being handed off.
 * @returns the provider/model/effort triple, or `undefined`.
 */
export declare function parentModelSelection(session: Session): {
    provider: string;
    model: string;
    reasoningEffort?: string;
} | undefined;
/**
 * Apply {@link parentModelSelection} to the freshly created child. Fail-open in every direction: a
 * runtime without `selectModel`, a parent that never routed a request, or a rejected selection must
 * never fail a handoff whose child already exists.
 * @param ctx - plugin context, for the warning log.
 * @param controller - the session controller that owns the child.
 * @param childId - the child session to configure.
 * @param session - the parent session being handed off.
 */
export declare function carryModelSelection(ctx: Context, controller: SessionControllerLike, childId: string, session: Session): Promise<void>;
/**
 * Admit the continuation prompt to the freshly created child.
 *
 * The prompt goes straight into the child's Agent inbox carrying this plugin's own message source
 * kind, instead of through `sessionController.prompt`. That RPC hardcodes `source = {kind:"user",
 * rpcId}` — `SessionPromptRequest` has no source field — which makes a machine-written seed
 * indistinguishable from something the person typed. Three consumers paid for that: `userTurnCount`
 * counted the banner as a human turn, the index title fallback had to recognize it structurally, and
 * dsh's goal tools grant `create_goal` / `update_goal edit|pause|resume` to "a direct human turn",
 * which `goal/tool-goal/src/authority.ts` decides by `source.kind === "user"`. A seed runs before the
 * user has said anything, so it must not carry that authority.
 *
 * This performs the same delivery the RPC did (`agent.followup(message)`). Leaving the RPC behind
 * also leaves behind its content validation (the prompt is never empty) and its error translation,
 * but not its model check: `requireModel` belongs to `session/selectModel`, which
 * {@link carryModelSelection} still calls. Its request-id dedupe could never fire here either — it
 * matched only `kind: "user"` messages carrying a reused id, and each attempt mints a fresh one.
 *
 * The registry is read directly with no fallback to the RPC: falling back would silently reinstate
 * exactly the human authority this exists to remove, so a child that is not resident fails the
 * handoff loudly instead.
 * @param ctx - plugin context carrying the host's live `agents` registry.
 * @param childId - the child session that receives the seed.
 * @param prompt - the continuation prompt.
 */
export declare function seedChildSession(ctx: Context, childId: string, prompt: string): void;
/**
 * Undo a child whose handoff was abandoned. The child is already published and dsh has no delete
 * RPC, so the visible facts are reversed instead: a possibly admitted seed is cancelled, the switch
 * marker is replaced by a plain title, and a deferral's session is archived so it does not sit in
 * the workspace list. Every step is best effort, but the *decision to hide* a child is not: a child
 * whose seed could not be cancelled keeps running a duplicate continuation, so it stays visible
 * instead of being quietly archived. Cancelling an unseeded child is a no-op, so it is always tried.
 * @param ctx - plugin context, for the optional registry and the warning log.
 * @param controller - the session controller that owns the child.
 * @param childId - the abandoned child.
 * @param parentLabel - the parent's short label, for the title.
 * @param error - the failure that abandoned the handoff.
 * @param promptAttempted - whether the seed prompt was already sent (it can be admitted before the
 *   call rejects, so a rejection is not proof that the child is idle).
 */
export declare function abandonChild(ctx: Context, controller: SessionControllerLike, childId: string, parentLabel: string, error: unknown, promptAttempted: boolean): Promise<void>;
/**
 * Retire the session a handoff replaced: stop whatever still runs for it, then archive it.
 *
 * dsh's handoff *forks* — the child is a separate session — so the session that was handed off stays
 * live, and because the workspace list groups by activity the still-running old session sits above its
 * own continuation. The host has no "end session" RPC; its archive is the closest thing, and
 * `stopActivity` is what makes it apply to a session with running work (without it the host *refuses*
 * rather than stopping anything). The archive only hides: the log, the archive artifacts and the
 * workspace position all survive, and the client can undo it.
 *
 * Failures are logged, never thrown: the handoff itself already succeeded.
 * @param ctx - plugin context carrying the optional workspace registry service.
 * @param session - the session that was handed off.
 */
export declare function retireSession(ctx: Context, session: Session): Promise<void>;
/**
 * Retire the handed-off session now, or — when its own turn is still open — when that turn ends.
 * @param ctx - plugin context.
 * @param session - the session that was handed off.
 * @param turnOpen - whether the handoff ran inside that session's own open turn (the manual path).
 */
export declare function scheduleRetirement(ctx: Context, session: Session, turnOpen: boolean): void;
/** Consume a scheduled retirement; called on every `turn/end` so a deferred one is not forgotten. */
export declare function retireIfPending(ctx: Context, session: Session): void;
