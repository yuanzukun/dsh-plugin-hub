/**
 * The consolidation pass (②): one throttled, single-flight model call per project producing
 * durable memory and a session-context update. It lived in `shared/llm.ts` only because the
 * autolearn pass reuses the model plumbing from there; the pass itself belongs to the memory
 * plugin, and the plumbing it shares now sits in `shared/model-call.ts`.
 */
import { type Context } from "@deepseek-ai/cordis";
import { type Agent } from "@deepseek-ai/dsh-agent";
import { type Session } from "@deepseek-ai/dsh-session";
import { type PluginConfig } from "../shared/config.js";
import { type ConsolidationResult, type ContextUpdate } from "../shared/reply-json.js";
import { type MemorySectionOverage } from "./sections.js";
/**
 * Which entry produced the memory this pass would write, or `"none"` when the pass was refused before
 * any model call (the read-cap gate): there is no reply, so nothing produced the document.
 */
export type ConsolidateKind = "structured" | "fallback-sections" | "fallback-opaque" | "merged-partial" | "unmergeable-partial" | "none";
/**
 * Which half of batch Q2's merge could not be read: the stored document (nothing to merge into) or the
 * reply itself. The two are different causes with different levers, so the refusal names one of them
 * rather than collapsing both into "the reply was partial" — which is false for a complete document
 * whose sections are not plain `- ` entries.
 */
export type PartialRefusalReason = "store-not-sections" | "reply-not-sections";
/** A consolidation result plus a monotonic version so each plugin writes a given pass at most once. */
export type ConsolidationOutcome = {
    result: ConsolidationResult;
    version: number;
    /**
     * The memory this pass's prompt was built from, byte for byte. The write path refuses a reply
     * whose baseline no longer matches what is stored: publishing it would overwrite a newer edit.
     */
    basisKey: string;
    /**
     * Which entry the memory came from. Reported for diagnostics and tests; no receipt reads it yet,
     * so a pass is never worded differently because of it.
     */
    kind: ConsolidateKind;
    /** No section held an entry worth storing, so the memory must not be written at all. */
    semanticEmpty: boolean;
    /** Sections that lost at least one entry to their budget. */
    sectionDropped: number;
    /** Entries dropped because their section's budget was full. */
    droppedItems: number;
    /** Entries clipped to their section's per-item cap. */
    itemTruncated: number;
    /**
     * Characters of this reply the memory cap would drop on write, measured here rather than at the
     * write so the loss can be retried and refused like any other. The write path measures the landed
     * value separately; this one describes the reply tier C decided about.
     */
    memoryWriteCapDroppedChars: number;
    /**
     * True when tier C refused this reply: it would have been stored lossily and the one targeted
     * retry did not fix it, so the write must not happen and the stored memory stays effective.
     */
    memoryLossyRefused: boolean;
    /**
     * The `maxMemoryChars` this outcome was measured under.
     *
     * A cached outcome is re-reported as it stands — the throttled path serves it without re-running —
     * so a caller that names "the cap" must read this, not the config in force at report time, or it
     * names a cap that never measured the loss it is describing.
     */
    maxMemoryChars: number;
    /**
     * True when batch Q2's guard refused this reply: it carried our document shape but could not be
     * merged into the stored one, so writing it would have replaced content this pass cannot account
     * for. The write must not happen; the refusal is logged where it is decided.
     */
    partialRefused: boolean;
    /** Which half of the merge could not be read, when `partialRefused` is set. */
    partialRefusal?: PartialRefusalReason;
    /** Headings the stored document contributed to a merged partial reply (batch Q2); empty otherwise. */
    mergedFromStore: string[];
    /**
     * Invariants/Pitfalls entries the reply no longer carries (batch Q2's report layer). Reported, never
     * blocking: a compression pass is supposed to drop entries, and refusing that would be permanent.
     */
    removedEntries?: {
        count: number;
        samples: string[];
    };
    /**
     * Set when the pass refused before the model call because the read cap had shortened the stored
     * document: the view was incomplete, so a reply built from it would have deleted everything the cap
     * kept back, and tier C would have called that write clean — it measures a reply against a cap the
     * reply does fit. The numbers are this pass's own, so a cached refusal re-reported under a raised
     * `maxMemoryChars` cannot name the wrong cap.
     */
    readCappedRefused?: {
        cap: number;
        memoryHiddenChars: number;
        contextHiddenChars: number;
    };
    /**
     * Set when the pass refused before the model call because the output budget could not hold both
     * documents whole: `fitMemoryInput` shortened them head-and-tail, and a reply built from that view
     * replaces the stored file with it — the same deletion `readCappedRefused` exists to prevent, one
     * budget further out. Separate from it because the levers differ: the read cap is `maxMemoryChars`
     * (or the stored document), while this one is `maxOutputTokens` (or both documents), and a receipt
     * that named the wrong knob would be a dead lever.
     */
    fitCappedRefused?: {
        maxOutputTokens: number;
        memoryHiddenChars: number;
        contextHiddenChars: number;
    };
};
export interface ConsolidationOptions {
    force?: boolean;
    signal?: AbortSignal;
}
/**
 * The cross-project boundary, stated as a rule.
 *
 * The pass hands the model the whole session conversation and asks it to regenerate the documents
 * from that, so a session that quotes a sibling repository's state (its sizes, counts, research
 * values) writes it into this project's memory — hand-cleaning does not hold, because the next pass
 * writes it again. Naming another project stays legal for recording who owns an open item: this repo
 * keeps exactly those pointers on purpose.
 */
export declare const FOREIGN_STATE_RULE = "Write only durable facts about this project itself. Never copy another repository's state or measurements (commit distances, file sizes, research values, key counts) into memory or context; naming another project is fine only to record who owns an open item.";
/**
 * The same boundary where the foreign text actually enters: the first line inside
 * `<recent-conversation>`, which is the block built from the session's own transcript.
 */
export declare const CONVERSATION_CAPTION = "[This session's working state. It may quote other projects and their numbers; those are not memory material \u2014 write only durable facts about this project.]";
/**
 * The fixed instructions of the consolidation prompt. Exported so a test can assert the shape
 * contract the model is actually given: naming the `context` keys without their types is what let
 * a mis-shaped reply hollow out CONTEXT.md silently.
 */
export declare const CONSOLIDATION_PROMPT_RULES: readonly string[];
/**
 * The compression ladder both prompt layers state (batch L, ported from pi v0.4.4).
 *
 * The sentence this replaces — "When over budget, merge duplicates within a section, then drop the
 * least durable entries" — was the only permission the prompt gave for an overflow, and it made
 * deletion the closing step. Measured on 2026-10-06, this repo's memory sat at 98.8% / 97.9% of two
 * section budgets, one added line away from a whole-entry drop, and the tier C retry that fires on
 * exactly that loss repeated the same instruction — asking for the loss the gate refuses.
 * Compression is now the default and a deletion has to name a reason; one constant, so the two
 * layers cannot drift apart.
 */
export declare const MEMORY_KEEP_RULE = "Keep every entry that is still true and make each section fit its stated target above: merge duplicates within a section, deduplicate across sections, then condense the wording. Delete an entry only when it is superseded or already covered elsewhere, never to make room for a new one.";
/**
 * The same rule at the block whose text the reply rewrites (pi's second layer): the material arrives
 * with the instruction attached, rather than only in the rules above it.
 */
export declare const MEMORY_SURVIVAL_CAPTION = "The existing-memory block below is what has to survive this pass: every entry that is still true must reappear unless it is superseded or already covered elsewhere, and a document that does not fit its cap is fixed by condensing its wording, not by dropping entries.";
/**
 * The memory layout the pass actually writes, stated with the real per-section budgets.
 *
 * The stored memory carries these exact sections in this order. `renderMemoryDocument` treats each
 * section's share as a target rather than a cap: it pools what an under-target section leaves and lends
 * it to the over-target ones, dropping whole entries only when the whole document reaches
 * `maxMemoryChars`. The cap is per project, so the section budgets have to be built per pass instead of
 * sitting in the static rules — and like `memoryBudgetRule`, every number here is in characters.
 *
 * Each section states two numbers: the figure the prompt asks for, and the share it expects to take.
 * The gap is deliberate — a reply written to the share spends the headroom the next pass needs, and the
 * model cannot count characters — so the target, not the share, is what the model is told to aim at.
 * Both come from the one table so neither can drift.
 */
export declare function memorySectionRule(maxMemoryChars: number): string;
/**
 * The memory bound the pass actually enforces, stated with the real numbers.
 *
 * A word hint is not the enforced bound: the document is cut at `maxMemoryChars` **characters** on
 * write, so a reply that satisfies a word count can still lose whatever sat at the end — and the
 * model had no way to know. The cap is per project, so the line has to be built per pass. The
 * per-section figures above are targets the renderer may exceed by borrowing, so the cap is named here
 * as the only hard limit.
 */
export declare function memoryBudgetRule(maxMemoryChars: number, currentChars: number): string;
/**
 * The targeted retry a complete-but-lossy reply is allowed (tier C).
 *
 * The reply was usable and the model simply over-filled a section, which a second, specific
 * instruction can fix — that is the whole difference between tier C and tier B. The rule names
 * sections and counts only: the previous reply is not an input to it, so it can neither leak a
 * section's text into the prompt nor invite a rewrite from memory.
 *
 * @param overage - what each section would give up, from `memorySectionOverage`.
 * @param writeCapDroppedChars - characters the memory cap would drop from the reply, 0 when it fits.
 */
export declare function memoryLossRetryRule(overage: readonly MemorySectionOverage[], writeCapDroppedChars: number): string;
export declare function fallbackUpdate(session: Session): ContextUpdate;
/**
 * Run the consolidation pass (durable memory + session context).
 * Callers own persisting their artifact; results are cached per project so the memory and
 * session-context plugins can consume the same pass without a second model call.
 */
export declare function consolidateProjectState(ctx: Context, agent: Agent, config: PluginConfig, options?: ConsolidationOptions): Promise<ConsolidationOutcome | undefined>;
