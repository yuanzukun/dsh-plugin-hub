/**
 * The `isTopLevel` gate: project-wide work must not run once per delegated child.
 *
 * Four plugins schedule per-project work from session lifecycle events — `project-memory` and
 * `project-autolearn` on `agent/status`/`agent/disposed`, `project-handoff` on `session/event`
 * (`turn/end`), and `project-context` on all four of those (it writes the session archive and its
 * index line). Each refuses a session whose header carries `origin: "subagent"`, the single origin
 * upstream writes on its one child-creation path (one-shot subagents and continuable Agent Team
 * members alike). Without the gate every child would consolidate the same `MEMORY.md`, distil the
 * same skills from the same index, try to hand itself off, and archive itself into the project's
 * `session-logs/` — that last one was missing until 2026-09-27, by which time a census found 67 of
 * the 113 archive directories were children (the purged originals are kept in
 * `/mnt/Data/Backups/dsh-project-context/session-logs-subagent-2026-09-27.tar.gz`), and they were
 * already a majority of the newest-50 window autolearn reads (`MAX_INDEX_ENTRIES` in
 * project-autolearn).
 *
 * Every case drives the plugin's real `apply()` wiring twice on its own throwaway project: once as
 * a delegated session (nothing happens) and once as a top-level one (the very same event does the
 * work). The positive half is what makes the negative half evidence — a fixture that simply cannot
 * schedule any work would satisfy the negative half on its own.
 *
 * `project-context`'s fifth lifecycle point, `agent/created`, stays ungated on purpose and is not
 * covered here: it only warms a cache the parent already warmed and writes nothing, so a gate there
 * would be an untestable branch.
 *
 * The auxiliary-route contract of batch S is pinned here too, because it is decided on these same
 * events: an automatic pass stamps the live session on the model call it makes (`opencode` refuses a
 * request that arrives without one), and the tracker `session/flush` drains carries only that pass's
 * write phase — dsh flushes a session *before* dispatching a request that names it, so a tracker
 * holding the whole pass would park that flush behind the very call it is dispatching.
 *
 * This file also owns the sibling refusal that is not about delegation: `archiveEnabled: false` must
 * stop every automatic write too. Three of `project-context`'s four points honoured that flag;
 * `session/disposed` wrote anyway (a session.jsonl + session.md + index line on dispose) until
 * 2026-09-27, against `README.md`'s "关掉后不再自动写会话存档与索引".
 *
 * Run `pnpm test`, which builds `lib/` first and then runs `node --test`.
 */

import assert from "node:assert/strict";
import { mkdir, mkdtemp, readFile, readdir, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";
import { apply as applyAutolearn } from "../lib/project-autolearn/index.js";
import { apply as applyContext } from "../lib/project-context/index.js";
import { apply as applyHandoff } from "../lib/project-handoff/index.js";
import { apply as applyMemory, consolidateProject } from "../lib/project-memory/index.js";
import { resolvePluginConfig } from "../lib/shared/config.js";
import { contextFile, logsDir, memoryFile, sessionIndexFile } from "../lib/shared/project-state.js";

/** A complete consolidation reply: a memory rewrite plus a context update. */
const COMPLETE_REPLY = '{"memory_markdown":"# Project Memory\\n\\n- keep the suite green\\n","context":{"title":"t","summary":"s","key_points":[],"open_tasks":[]}}';

/**
 * A throwaway project both learn passes can run against: the two documents they read, plus one
 * archived session and its index line so the autolearn evidence path has something to cite.
 */
async function project(prefix) {
	const root = await mkdtemp(path.join(tmpdir(), prefix));
	await mkdir(path.join(root, ".agents", "memory"), { recursive: true });
	await writeFile(memoryFile(root), "# Project Memory\n\n- keep the suite green\n");
	await writeFile(contextFile(root), "# Project Context\n\nLast updated: 2026-09-13\n\n## Summary\n\nA fixture project.\n");
	await mkdir(path.join(logsDir(root), "session-archived"), { recursive: true });
	await writeFile(
		path.join(logsDir(root), "session-archived", "session.jsonl"),
		`${JSON.stringify({ type: "user/message", data: { source: { kind: "user" }, content: [{ type: "text", text: "run the release checklist" }] } })}\n`,
	);
	await writeFile(sessionIndexFile(root), "# Session Index\n\n- [session-archived](session-archived/session.md) — 2026-09-13 — Fixture\n");
	return root;
}

/** A minimal Agent stand-in; `origin` is written into the header only when the case asks for it. */
function fakeAgent(cwd, { id, origin, turns = 3 } = {}) {
	const events = Array.from({ length: turns }, (_, index) => ({
		type: "user/message",
		seq: index + 1,
		time: Date.now(),
		data: { source: { kind: "user" }, content: [{ type: "text", text: `turn ${index + 1}` }] },
	}));
	const header = { cwd, createdAt: Date.now() };
	if (origin !== undefined) header.origin = origin;
	return {
		options: { provider: "test-provider", model: "test-model" },
		session: {
			id,
			header,
			snapshotEvents: () => events,
			// These fixtures' logs carry control records only (turn ends, catalog rows,
			// settled markers); projecting them to messages is not modelled here, so the
			// append-origin read finds nothing and falls back to the surface, exactly as before.
			deriveEventMessage: () => null,
			ownEvents: () => events,
			// Derived messages carry a `source.kind`; the conversation renderer reads it to tell a
			// tool result from a human turn.
			deriveMessages: () => [
				{ role: "user", source: { kind: "user" }, content: [{ type: "text", text: "turn 1" }] },
				{ role: "assistant", source: { kind: "assistant" }, content: [{ type: "text", text: "done" }] },
			],
			requestHeader: () => undefined,
		},
	};
}

/** A Context stand-in that records the handlers `apply()` registers, in registration order. */
function handlerContext(extra = {}) {
	const handlers = new Map();
	const on = (type, handler) => {
		(handlers.get(type) ?? handlers.set(type, []).get(type)).push(handler);
		return () => undefined;
	};
	return { handlers, on, ...extra };
}

/** Resolve `true` as soon as `probe()` holds, or `false` once `ms` elapse without it. */
async function waitFor(probe, ms) {
	const deadline = Date.now() + ms;
	for (;;) {
		if (await probe()) return true;
		if (Date.now() >= deadline) return false;
		await new Promise((resolve) => setTimeout(resolve, 5));
	}
}

/** A promise plus the handle that settles it. */
function deferred() {
	let resolve;
	const promise = new Promise((settle) => {
		resolve = settle;
	});
	return { promise, resolve };
}

/**
 * Fire one lifecycle event through the registered handler(s), then drain the plugin's flush hook.
 *
 * `session/flush` is no longer a pass-completion signal: batch S narrowed the tracker to the write
 * phase, because dsh flushes a session *before* dispatching a request that names it, and these
 * passes name one. The observable step is therefore the model call itself. Each caller's positive
 * control (the same event on a top-level session) proves this window is long enough for it to
 * arrive; measured on this machine a pass reaches its stream in well under 10 ms, so 500 ms is ~50×
 * the latency being waited for.
 */
async function fire(handlers, type, agent, calls) {
	for (const handler of handlers.get(type)) await handler({ agent, status: "idle" });
	await waitFor(() => calls.length > 0, 500);
	const flush = handlers.get("session/flush")?.[0];
	if (flush) await flush(agent.session);
}

/**
 * Model calls the memory plugin makes for one event on one fresh project, with optional config
 * overrides. Pass `calls` to also read the requests themselves.
 */
async function memoryCalls(event, origin, extra = {}, calls = []) {
	const root = await project("dsh-gate-memory-");
	const { handlers, on } = handlerContext();
	applyMemory(
		{
			logger: { info() {}, warn() {} },
			systemPrompt: { context: () => undefined },
			on,
			commands: { register: () => undefined },
			llm: {
				resolveModelInfo: async () => ({ context: { contextWindow: 200_000 } }),
				stream: (options) => {
					calls.push(options);
					return (async function* generate() {
						yield { type: "text-delta", text: COMPLETE_REPLY };
						yield { type: "finish", reason: { kind: "stop" } };
					})();
				},
			},
		},
		resolvePluginConfig({ consolidateTurns: 1, consolidateIntervalMs: 1000, provider: "test-provider", model: "test-model", ...extra }),
	);
	const agent = fakeAgent(root, { id: `session-${event}-${origin ?? "top"}`, origin });
	await fire(handlers, event, agent, calls);
	return calls.length;
}

/**
 * Model calls the autolearn plugin makes for one event on one fresh project. Pass `calls` to also
 * read the requests themselves.
 */
async function autolearnCalls(event, origin, calls = []) {
	const root = await project("dsh-gate-autolearn-");
	const { handlers, on } = handlerContext();
	applyAutolearn(
		{
			logger: { info() {}, warn() {} },
			effect: (callback) => callback(),
			inject: (_deps, callback) => callback({ settings: { installSection: () => undefined } }),
			on,
			commands: { register: () => undefined },
			llm: {
				resolveModelInfo: async () => ({ provider: "test-provider", id: "test-model", name: "test-model" }),
				stream: (options) => {
					calls.push(options);
					return (async function* generate() {
						yield { type: "text-delta", text: '{"skill": null}' };
					})();
				},
			},
		},
		resolvePluginConfig({ autolearnTurns: 1, autolearnIntervalMs: 1000, provider: "test-provider", model: "test-model" }),
	);
	const agent = fakeAgent(root, { id: `session-${event}-${origin ?? "top"}`, origin });
	await fire(handlers, event, agent, calls);
	return calls.length;
}

/** Children the handoff plugin creates for one `turn/end` on one fresh project. */
async function handoffCreates(origin) {
	const root = await project("dsh-gate-handoff-");
	const created = [];
	// The handoff generates nothing any more: any model call from this path is a regression.
	let modelCalls = 0;
	const { handlers, on } = handlerContext();
	const own = [{ type: "turn/end", seq: 10, time: Date.now() }];
	const conversation = Array.from({ length: 40 }, (_, index) => ({
		role: index % 2 === 0 ? "user" : "assistant",
		source: { kind: index % 2 === 0 ? "user" : "assistant" },
		content: [{ type: "text", text: "x".repeat(1500) }],
	}));
	const agent = fakeAgent(root, { id: `session-handoff-${origin ?? "top"}`, origin });
	// A conversation far past the threshold with a settled trailing turn: the only thing that can
	// keep this from handing off is the gate under test.
	agent.session.deriveMessages = () => conversation;
	agent.session.snapshotEvents = () => own;
	agent.session.ownEvents = () => own;
	applyHandoff(
		{
			logger: { info() {}, warn() {} },
			on,
			effect: () => () => undefined,
			inject: () => () => undefined,
			commands: { register: () => () => undefined },
			// The pressure-line contribution registers here; this case is about the gate, not about
			// what that line says (test/handoff-pressure.test.mjs owns it).
			systemPrompt: { context: () => undefined },
			get: (name) =>
				name === "sessionController"
					? {
							create: async () => {
								created.push(1);
								return { sessionId: "child-1" };
							},
							rename: async () => undefined,
							prompt: async () => undefined,
						}
					: name === "tokenMeter"
						? { measure: () => ({ totalTokens: 190_000, surfaceTokens: 100_000 }) }
						: undefined,
			llm: {
				resolveModelInfo: async () => ({ context: { contextWindow: 200_000 } }),
				stream: () => { modelCalls += 1; throw new Error("the handoff must not call a model"); },
			},
		},
		resolvePluginConfig({ provider: "test-provider", model: "test-model", handoffBudgetRecentTokens: 0 }),
	);
	const listener = handlers.get("session/event")?.[0];
	assert.ok(listener, "apply registers a session/event listener");
	listener(agent.session, { type: "turn/end", seq: 10, time: Date.now() });
	// The positive control below proves this window is long enough for a child to appear, so an
	// empty result here means the event was refused rather than that it had not finished yet.
	for (let i = 0; i < 400 && created.length === 0; i += 1) await new Promise((resolve) => setTimeout(resolve, 5));
	assert.equal(modelCalls, 0, "the handoff must not call a model");
	return created.length;
}

test("project-memory: a delegated session runs no consolidation on either lifecycle event", async () => {
	for (const event of ["agent/status", "agent/disposed"]) {
		assert.equal(await memoryCalls(event, "subagent"), 0, `${event}: a delegated session must not consolidate the project`);
		assert.equal(await memoryCalls(event), 1, `${event}: the same event on a top-level session consolidates once`);
	}
});

test("project-memory: the memoryEnabled switch alone suppresses the automatic pass", async () => {
	// The positive half is the control: the same event with the switch on spends a model call, so a zero
	// from the off case is the switch's doing rather than a fixture that cannot schedule work at all.
	// Without this pair, a reader of the *sibling* switch (`autolearnEnabled`, which defaults to true)
	// would read `memoryEnabled` nowhere and pass the whole suite.
	assert.equal(await memoryCalls("agent/status", undefined, { memoryEnabled: false }), 0, "memoryEnabled: false must not run a pass");
	assert.equal(await memoryCalls("agent/status", undefined, { memoryEnabled: true }), 1, "the same event with the switch on consolidates once");
});

test("project-autolearn: a delegated session runs no distill pass on either lifecycle event", async () => {
	for (const event of ["agent/status", "agent/disposed"]) {
		assert.equal(await autolearnCalls(event, "subagent"), 0, `${event}: a delegated session must not distil project skills`);
		assert.equal(await autolearnCalls(event), 1, `${event}: the same event on a top-level session distils once`);
	}
});

test("an automatic pass stamps the live session on its auxiliary request", async () => {
	// Batch S: a route is entitled to require a session identity — `opencode` answers 400
	// `MissingSessionID` without one — and the identity is also what enters dsh's checkpoint path,
	// so the request carrying it is half of the contract the tracker's write-only scope answers for.
	// Both automatic passes make such a call, so both must be checked here.
	const memory = [];
	assert.equal(await memoryCalls("agent/status", undefined, {}, memory), 1);
	assert.equal(memory[0].sessionId, "session-agent/status-top", "the consolidation request must name the live session");
	const autolearn = [];
	assert.equal(await autolearnCalls("agent/status", undefined, autolearn), 1);
	assert.equal(autolearn[0].sessionId, "session-agent/status-top", "the distill request must name the live session");
});

test("the flush a stamped request triggers returns while the model call is still parked", async () => {
	// dsh's checkpoint policy flushes a session *before* dispatching a request that names it. A pass
	// that registered its whole self with the tracker would therefore make that flush await the very
	// call it is dispatching; `SessionWorkTracker` releases only at `FLUSH_WAIT_MS` (90 s), so every
	// auxiliary call would stall for the full budget. The pass registers its write phase alone, which
	// is the only half with anything to make durable — and that half must still land.
	const root = await project("dsh-gate-aux-cycle-");
	// A distinct starting document, so the write that follows the model call is observable on disk.
	await writeFile(memoryFile(root), "# Project Memory\n\n- before the pass\n");
	const entered = deferred();
	const release = deferred();
	let checkpoints = 0;
	let agent;
	const { handlers, on } = handlerContext();
	applyMemory(
		{
			logger: { info() {}, warn() {} },
			systemPrompt: { context: () => undefined },
			on,
			commands: { register: () => undefined },
			llm: {
				resolveModelInfo: async () => ({ context: { contextWindow: 200_000 } }),
				// `session-checkpoint-policy`, inlined: a request that names a live session is flushed
				// before the adapter is reached; one that names nothing is passed straight through.
				stream: (options) => (async function* generate() {
					if (options.sessionId !== undefined) {
						checkpoints += 1;
						await handlers.get("session/flush")[0](agent.session);
					}
					entered.resolve();
					await release.promise;
					yield { type: "text-delta", text: COMPLETE_REPLY };
					yield { type: "finish", reason: { kind: "stop" } };
				})(),
			},
		},
		resolvePluginConfig({ consolidateTurns: 1, consolidateIntervalMs: 1000, provider: "test-provider", model: "test-model" }),
	);
	agent = fakeAgent(root, { id: "session-aux-cycle" });
	let flushReturnedWhileParked = false;
	void entered.promise.then(() => {
		flushReturnedWhileParked = true;
	});
	handlers.get("agent/status")[0]({ agent, status: "idle" });
	const returnedBeforeRelease = await waitFor(() => flushReturnedWhileParked, 1000);
	// Released before the assertions: a regressed tracker parks the flush for its full budget, and
	// this keeps that regressed run from holding the suite open even after the case has failed.
	release.resolve();
	assert.equal(checkpoints, 1, "the request must name the session the checkpoint policy flushes");
	assert.equal(returnedBeforeRelease, true, "the flush must return before the dispatch it triggered, not behind it");
	assert.equal(
		await waitFor(async () => (await readFile(memoryFile(root), "utf8")).includes("- keep the suite green"), 2000),
		true,
		"the write phase must still land once the parked call is released",
	);
});

test("the pass hands the tracker its write phase alone", async () => {
	// The other half of the cycle: the flush must have something to await *after* the call, or the
	// narrowing would have bought latency at the price of durability. Nothing may be registered while
	// the call is in flight, exactly one write phase must be registered once it returns, and that
	// write is the one that lands.
	const root = await project("dsh-gate-aux-register-");
	await writeFile(memoryFile(root), "# Project Memory\n\n- before the pass\n");
	const entered = deferred();
	const release = deferred();
	const registered = [];
	const agent = fakeAgent(root, { id: "session-aux-register" });
	const pass = consolidateProject(
		{
			logger: { info() {}, warn() {} },
			systemPrompt: { context: () => undefined },
			llm: {
				resolveModelInfo: async () => ({ context: { contextWindow: 200_000 } }),
				stream: () => (async function* generate() {
					entered.resolve();
					await release.promise;
					yield { type: "text-delta", text: COMPLETE_REPLY };
					yield { type: "finish", reason: { kind: "stop" } };
				})(),
			},
		},
		resolvePluginConfig({ consolidateTurns: 1, consolidateIntervalMs: 1000, provider: "test-provider", model: "test-model" }),
		agent,
		{ force: false, silent: false, track: (work) => registered.push(work) },
	);
	await entered.promise;
	assert.equal(registered.length, 0, "no write may be registered while the model call is in flight");
	release.resolve();
	await pass;
	assert.equal(registered.length, 1, "the write phase is registered exactly once, after the call");
	await registered[0];
	assert.equal(
		await readFile(memoryFile(root), "utf8"),
		"# Project Memory\n\n- keep the suite green\n",
		"the registered write is the one that landed",
	);
});

test("project-handoff: a delegated session's settled turn end starts no handoff", async () => {
	assert.equal(await handoffCreates("subagent"), 0, "a delegated session must not hand itself off");
	assert.equal(await handoffCreates(), 1, "the same settled turn end hands a top-level session off once");
});

/** Session directories this fixture's own archive produced (the pre-seeded one does not count). */
async function archivedChildren(root) {
	const entries = await readdir(logsDir(root), { withFileTypes: true });
	return entries.filter((entry) => entry.isDirectory() && entry.name !== "session-archived").map((entry) => entry.name);
}

/** Archive directories the context plugin writes for one lifecycle event on one fresh project. */
async function contextArchives(event, origin, overrides = {}) {
	const root = await project("dsh-gate-context-");
	const { handlers, on } = handlerContext();
	applyContext(
		{
			logger: { info() {}, warn() {} },
			// `publishProjectContextSettings` registers a disposer through `ctx.effect`.
			effect: (callback) => callback(),
			on,
			commands: { register: () => () => undefined },
		},
		resolvePluginConfig({ provider: "test-provider", model: "test-model", ...overrides }),
	);
	const agent = fakeAgent(root, { id: `session-${event.replace(/\W/g, "-")}-${origin ?? "top"}`, origin });
	// The real payload shapes, not `fire()`'s generic one: `agent/disposed` carries the agent and
	// `session/disposed` the session itself.
	const dispatch = {
		"agent/status": () => handlers.get("agent/status")[0]({ agent, status: "idle" }),
		"agent/disposed": () => handlers.get("agent/disposed")[0]({ agent }),
		"session/disposed": () => handlers.get("session/disposed")[0](agent.session),
		"session/event": () => handlers.get("session/event")[0](agent.session, { type: "turn/end", seq: 10, time: Date.now() }),
	};
	dispatch[event]();
	const flush = handlers.get("session/flush")?.[0];
	if (flush) await flush(agent.session);
	// Only the `markdown: true` writes are tracked, so the other two points get a bounded window; the
	// positive control (same write, no gate) proves it is long enough. Measured on this machine: the
	// archive write resolves in 6–8 ms, so 200 ms is ~25× the latency being waited for.
	for (let i = 0; i < 40 && (await archivedChildren(root)).length === 0; i += 1) await new Promise((resolve) => setTimeout(resolve, 5));
	return (await archivedChildren(root)).length;
}

test("project-context: a delegated session is not archived on any lifecycle event", async () => {
	for (const event of ["agent/status", "agent/disposed", "session/disposed", "session/event"]) {
		assert.equal(await contextArchives(event, "subagent"), 0, `${event}: a delegated session must not archive itself into the project`);
		assert.equal(await contextArchives(event), 1, `${event}: the same event on a top-level session archives once`);
	}
});

test("project-context: archiving disabled writes nothing on any lifecycle event", async () => {
	// `archiveEnabled: false` is the user turning the feature off, and the README promises no
	// automatic archive or index write — `/session-log` is the documented escape hatch, which is why
	// the commands are not covered here. Each negative keeps its own positive control.
	for (const event of ["agent/status", "agent/disposed", "session/disposed", "session/event"]) {
		assert.equal(await contextArchives(event, undefined, { archiveEnabled: false }), 0, `${event}: archiving is off, so nothing may be written automatically`);
		assert.equal(await contextArchives(event), 1, `${event}: the same event with archiving on writes once`);
	}
});
