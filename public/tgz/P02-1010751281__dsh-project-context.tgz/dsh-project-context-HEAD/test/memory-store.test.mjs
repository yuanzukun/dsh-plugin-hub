/**
 * Tests for the durable memory store: the append-only journal, the rendered MEMORY.md, the
 * backup-before-overwrite rule, the stored-reply decoder and the cross-process write lock.
 *
 * Ported with the feature from the pi sibling's `tests/consolidation-test.mjs`; the cases below
 * mirror its coverage so a regression on either side is visible here too.
 *
 * Run `pnpm test`, which builds `lib/` first and then runs `node --test`.
 */

import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { existsSync } from "node:fs";
import { mkdir, mkdtemp, open, readFile, readdir, rm, stat, utimes, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";
import {
	appendMemoryOp,
	backupMemoryBeforeWrite,
	foldMemoryJournal,
	importLegacyMemory,
	isMemoryTruncated,
	loadMemory,
	loadMemorySync,
	memoryJournalFile,
	memoryTruncationMarker,
	normalizeMemoryDocument,
	normalizeMemoryWithDrop,
	readMemoryJournal,
	recordMemoryDocument,
} from "../lib/project-memory/memory-store.js";
import { memoryComparisonKey, memoryComparisonKeyWithDrop } from "../lib/project-memory/poison.js";
import { externalRenderWins, renderChangedUnderRead, renderIsNewerThanJournal } from "../lib/project-memory/load.js";
import { adoptExternalEdit } from "../lib/project-memory/record.js";
import { MEMORY_LOCK_STALE_MS, MEMORY_LOCK_WAIT_MS, staleLockAge, withMemoryLock } from "../lib/shared/lock.js";
import { MAX_CONTEXT_CHARS, MAX_MEMORY_CHARS, MAX_MEMORY_CHARS_LIMIT, MIN_MEMORY_CHARS, ensureMemoryGitignore, legacyOmpDir, logError, memoryDir, memoryFile } from "../lib/shared/project-state.js";
import { consolidateProject, memoryUpdateReply } from "../lib/project-memory/index.js";
import { consolidateProjectState } from "../lib/project-memory/consolidate.js";
import { DEFAULT_CONFIG, resolvePluginConfig } from "../lib/shared/config.js";
import { fitMemoryInput } from "../lib/shared/conversation.js";

/** A project root with the memory directory present. */
async function project() {
	const root = await mkdtemp(path.join(tmpdir(), "dsh-memory-"));
	await mkdir(path.join(root, ".agents", "memory"), { recursive: true });
	return root;
}

test("the journal folds replace and append records in order", () => {
	const entries = [
		{ op: "replace", text: "# Project Memory\n\nfirst" },
		{ op: "append", text: "second" },
		{ op: "append", text: "third" },
	];
	const folded = foldMemoryJournal(entries);
	assert.match(folded, /^# Project Memory\n\nfirst\n\nsecond\n\nthird\n$/);
	// A later replace supersedes everything before it.
	assert.equal(foldMemoryJournal([...entries, { op: "replace", text: "final" }]), "# Project Memory\n\nfinal\n");
	assert.equal(foldMemoryJournal([]), "");
});

test("appendMemoryOp appends one record per call and repairs a torn tail", async () => {
	const root = await project();
	const journal = memoryJournalFile(root);
	await appendMemoryOp(journal, "replace", "one");
	await appendMemoryOp(journal, "append", "two");
	assert.deepEqual((await readMemoryJournal(journal)).entries.map((entry) => entry.text), ["one", "two"]);

	// A crash can leave a partial last line; the next append must terminate it instead of gluing
	// its own record onto the fragment.
	await writeFile(journal, `${await readFile(journal, "utf8")}{"op":"rep`, "utf8");
	await appendMemoryOp(journal, "append", "three");
	const after = await readMemoryJournal(journal);
	assert.equal(after.unreadable, false);
	assert.equal(after.damaged, 1, "the torn fragment is counted, not silently merged");
	assert.deepEqual(after.entries.map((entry) => entry.text), ["one", "two", "three"]);
});

test("an unreadable journal fails closed instead of falling back to the render", async () => {
	const root = await project();
	await writeFile(memoryFile(root), "# Project Memory\n\nfrom the render\n");
	await writeFile(memoryJournalFile(root), "not json at all\n", "utf8");

	const loaded = await loadMemory(root);
	assert.equal(loaded.unreadable, true, "content that yields no record must not be shown as empty");
	assert.equal(loaded.text, "");
	assert.equal(loaded.source, memoryJournalFile(root));
});

test("loadMemory decodes a stored JSON reply left by the old bug", async () => {
	const root = await project();
	const reply = `\`\`\`json\n{"memory_markdown":"# Project Memory\\n\\n- durable fact","context":{"title":"t"}}\n\`\`\``;
	await writeFile(memoryFile(root), reply, "utf8");

	const loaded = await loadMemory(root);
	assert.equal(loaded.poisoned, true);
	assert.match(loaded.text, /durable fact/);
	assert.doesNotMatch(loaded.text, /memory_markdown/);

	// A documented example inside a real document is not a stored reply.
	const documented = "# Project Memory\n\nsee the sample:\n\n```json\n{\"memory_markdown\":\"# Project Memory\"}\n```\n";
	await writeFile(memoryFile(root), documented, "utf8");
	const kept = await loadMemory(root);
	assert.equal(kept.poisoned, false, "a nested example must not be decoded");
	assert.match(kept.text, /see the sample/);
});

test("the loader reports the characters its own cap kept back, on every read path", async () => {
	// The read cap is applied inside `loadMemory`, before the consolidation pass sees the text, so the
	// pass can only count it if the loader reports the cut. The count is the normalizer's own
	// `dropped` — never a length difference against the raw bytes, which would report normalization's
	// edits, and the stored-reply wrapper, as characters the model was not shown.
	const body = Array.from({ length: 50 }, (_, i) => `- fact ${i} ${"字".repeat(100)}`).join("\n");
	const stored = `# Project Memory\n\n${body}\n`;
	const cap = MIN_MEMORY_CHARS;

	// A plain render and no journal: the clip is the cap site, so it is the exact difference.
	const plainRoot = await project();
	await writeFile(memoryFile(plainRoot), stored, "utf8");
	const plain = await loadMemory(plainRoot, cap);
	assert.ok(plain.cappedDroppedChars > 0, `fixture: the stored document is over the cap (${stored.trimEnd().length} vs ${cap})`);
	assert.equal(plain.text.length + plain.cappedDroppedChars, stored.trimEnd().length, "the cut is the exact difference on this path");
	assert.equal(isMemoryTruncated(plain.text), false, "this path clips without writing a marker, which is why the count is the only trace");

	// Inside the cap there is nothing to report.
	const smallRoot = await project();
	await writeFile(memoryFile(smallRoot), "# Project Memory\n\n- short\n", "utf8");
	assert.equal((await loadMemory(smallRoot, cap)).cappedDroppedChars, 0, "a document inside the cap reports no cut");

	// A stored reply is decoded — and capped — inside the decoder, so the count must be the decoder's
	// own cut. A length difference against the raw reply would report its JSON wrapper as a loss.
	const replyRoot = await project();
	const reply = `\`\`\`json\n${JSON.stringify({ memory_markdown: "# Project Memory\n\n- durable fact\n", context: { title: "t" } })}\n\`\`\``;
	await writeFile(memoryFile(replyRoot), reply, "utf8");
	const decoded = await loadMemory(replyRoot, cap);
	assert.equal(decoded.poisoned, true, "fixture: the bytes are a stored reply");
	assert.match(decoded.text, /durable fact/);
	assert.equal(decoded.cappedDroppedChars, 0, "nothing was cut, so the wrapper must not be reported as a cut");
	assert.ok(reply.length - decoded.text.length > 40, "fixture: a length difference would be large and wrong here");

	// And when the decoded field really is over the cap, its own cut is what comes back — the number
	// the decoder's normalizer produced, not any difference against the reply's bytes.
	const bigField = `# Project Memory\n\n${"字".repeat(30_000)}\n`;
	const bigReply = JSON.stringify({ memory_markdown: bigField, context: { title: "t" } });
	const bigRoot = await project();
	await writeFile(memoryFile(bigRoot), bigReply, "utf8");
	const big = await loadMemory(bigRoot, cap);
	assert.equal(big.poisoned, true);
	assert.equal(big.cappedDroppedChars, normalizeMemoryWithDrop(bigField, cap).dropped, "the decoded field's own cut");

	// An external render newer than the journal: this path normalizes twice (decode, then normalize),
	// so the count is the sum of the two cuts.
	const externalRoot = await project();
	await appendMemoryOp(memoryJournalFile(externalRoot), "replace", "# Project Memory\n\n- old fact\n");
	await writeFile(memoryFile(externalRoot), stored, "utf8");
	const future = new Date(Date.now() + 5_000);
	await utimes(memoryFile(externalRoot), future, future);
	const external = await loadMemory(externalRoot, cap);
	assert.equal(external.source, memoryFile(externalRoot), "fixture: the newer external render wins");
	assert.ok(external.cappedDroppedChars > 0, "the external render's cut is reported");
	assert.ok(external.text.length <= cap, "and the returned document still honours the cap");

	// The journal fold's own cut, for a journal whose records exceed the cap.
	const foldRoot = await project();
	await appendMemoryOp(memoryJournalFile(foldRoot), "replace", stored);
	const folded = await loadMemory(foldRoot, cap);
	assert.equal(folded.source, memoryJournalFile(foldRoot), "fixture: the fold is the source");
	assert.equal(folded.cappedDroppedChars, normalizeMemoryWithDrop(stored, cap).dropped, "the fold's own cut");
	assert.equal(isMemoryTruncated(folded.text), true, "the journal path does write the marker");

	// The comparison key keeps its bytes while carrying the same cut: it is the write path's baseline,
	// and one normalization is not a fixed point on this fixture, so a key that skipped the second
	// normalization would come out different.
	const render = `# Project Memory\n\n- ${"字".repeat(30_000)}\n`;
	const once = normalizeMemoryDocument(render, cap);
	assert.notEqual(normalizeMemoryDocument(once, cap), once, "fixture: a second normalization changes this document");
	const poisonedRender = JSON.stringify({ memory_markdown: render, context: { title: "t" } });
	const plainKey = memoryComparisonKeyWithDrop(render, cap);
	assert.equal(plainKey.text, memoryComparisonKey(render, cap), "a plain render's key is unchanged");
	assert.ok(plainKey.dropped > 0, "and its cut is reported");
	const poisonedKey = memoryComparisonKeyWithDrop(poisonedRender, cap);
	assert.equal(poisonedKey.text, memoryComparisonKey(poisonedRender, cap), "a stored reply's key is unchanged");
	assert.equal(normalizeMemoryDocument(poisonedKey.text, cap), poisonedKey.text, "the second normalization the key applies is still applied");
});

test("recordMemoryDocument seeds the journal from the memory a project already has", async () => {
	const root = await project();
	await writeFile(memoryFile(root), "# Project Memory\n\nlegacy line\n", "utf8");

	await recordMemoryDocument(root, "new line");
	const journal = await readMemoryJournal(memoryJournalFile(root));
	assert.deepEqual(journal.entries.map((entry) => entry.op), ["replace", "replace"]);
	assert.match(journal.entries[0].text, /legacy line/, "the pre-journal document becomes the base record");
	assert.match(journal.entries[1].text, /new line/);
	// The render is derived from the last record and the directory ignores its local artifacts.
	assert.equal(await readFile(memoryFile(root), "utf8"), "# Project Memory\n\nnew line\n");
	assert.match(await readFile(path.join(root, ".agents", "memory", ".gitignore"), "utf8"), /memory\.jsonl/);

	// The journal (not the render) is what a reader gets.
	const loaded = await loadMemory(root);
	assert.match(loaded.text, /new line/);
	assert.equal(loaded.source, memoryJournalFile(root));
});

test("an external edit wins the read and is adopted into the journal on the next write", async () => {
	const root = await project();
	await recordMemoryDocument(root, "written by the plugin");
	const journal = memoryJournalFile(root);
	// Backdate the journal so the hand edit is unambiguously newer.
	const past = new Date(Date.now() - 60_000);
	await utimes(journal, past, past);
	await writeFile(memoryFile(root), "# Project Memory\n\nedited by hand\n", "utf8");

	const loaded = await loadMemory(root);
	assert.match(loaded.text, /edited by hand/, "a newer, different render is an external edit");
	assert.equal(loaded.source, memoryFile(root));

	await recordMemoryDocument(root, "after the edit");
	const entries = (await readMemoryJournal(journal)).entries;
	assert.equal(entries.length, 3, "the edit entered the journal before the new document");
	assert.match(entries[1].text, /edited by hand/);
	assert.match((await loadMemory(root)).text, /after the edit/);
	assert.match(await readFile(path.join(root, ".agents", "memory", "errors.log"), "utf8"), /externally edited/);
});

/**
 * Stage a replacement under a reader's nose, deterministically, through a FIFO at `file`: the reader
 * is handed `older`, and by the time its read returns the path already holds `newer`. `start` must be
 * the read that is already in flight (its promise is returned). This is the only fixture that can
 * make a replacement land *inside* a read, which is what the consistent read exists to detect.
 */
async function replaceUnderRead({ root, file, start, older, newer }) {
	const pending = start();
	const watchdog = setTimeout(() => {
		console.error("FAIL: the FIFO fixture never got a reader within 30s");
		// SIGKILL cannot run the fixture's cleanup, so clear the tree first - synchronously, and without
		// letting a failing cleanup become the thing that stops the run from ending.
		try {
			execFileSync("rm", ["-rf", root]);
		} catch {}
		process.kill(process.pid, "SIGKILL");
	}, 30_000);
	try {
		// A blocking "w" is the scheduling barrier: the write end returns only once the reader holds
		// the FIFO open, so the reader is guaranteed to take the older bytes and only then see the
		// replacement at the path.
		const writer = await open(file, "w");
		await writer.writeFile(older);
		await rm(file);
		await writeFile(file, newer, "utf8");
		await writer.close();
	} finally {
		clearTimeout(watchdog);
	}
	return pending;
}

test("renderIsNewerThanJournal is the one mtime rule the readers and the adopt share", () => {
	assert.equal(renderIsNewerThanJournal(200, 100), true, "a newer render is an external edit");
	assert.equal(renderIsNewerThanJournal(100, 100), false, "equal times are not newer: the journal wins ties");
	assert.equal(renderIsNewerThanJournal(100, 200), false, "an older render is a torn write window");
	assert.equal(renderIsNewerThanJournal(undefined, 100), false, "a missing render supersedes nothing");
	assert.equal(renderIsNewerThanJournal(100, undefined), false, "an unreadable journal time is not a newer render");
});

test("a read that spans a replacement is detected by mtime, size or ctime, and a stable read is not", () => {
	// The three fields the decision reads, chosen so each case moves exactly one of them. The
	// mtime-preserving replacement is the case that only ctime can see: mutation "drop the ctime
	// clause" must redden that line alone.
	const version = (mtimeMs, size, ctimeMs) => ({ mtimeMs, size, ctimeMs });
	assert.equal(renderChangedUnderRead(version(10, 100, 500), version(10, 100, 500)), false, "an unchanged file is not a replacement");
	assert.equal(renderChangedUnderRead(version(10, 100, 500), version(11, 100, 500)), true, "a newer mtime is a replacement");
	assert.equal(renderChangedUnderRead(version(10, 100, 500), version(10, 101, 500)), true, "a different size at the same mtime is a replacement");
	assert.equal(renderChangedUnderRead(version(10, 100, 500), version(10, 100, 501)), true, "a same-size mtime-preserving replacement is a replacement: only ctime moves");
	assert.equal(renderChangedUnderRead(undefined, version(10, 100, 500)), true, "a file that appeared under the read is one");
	assert.equal(renderChangedUnderRead(version(10, 100, 500), undefined), false, "a file that vanished has no version to vouch for");
});

test("externalRenderWins is the one external-edit rule both readers share", () => {
	const read = (over) => ({ text: "# Project Memory", changed: false, mtimeMs: 200, ...over });
	const key = (text) => ({ text, dropped: 0 });
	assert.equal(externalRenderWins(read(), key("edit"), "fold", 100), true, "a newer, different render is an external edit");
	assert.equal(externalRenderWins(read({ changed: true }), key("edit"), "fold", 100), false, "a read that raced decides nothing");
	assert.equal(externalRenderWins(read({ text: "" }), key("edit"), "fold", 100), false, "an empty render is a file cleared by hand, not an edit");
	assert.equal(externalRenderWins(read({ text: " \n\t" }), key("edit"), "fold", 100), false, "so is a whitespace-only render");
	assert.equal(externalRenderWins(read(), key(""), "fold", 100), false, "a render with no key has nothing to compare");
	assert.equal(externalRenderWins(read(), key("fold"), "fold", 100), false, "our own output is not an edit");
	assert.equal(externalRenderWins(read({ mtimeMs: 100 }), key("edit"), "fold", 100), false, "a tie is not newer: the journal keeps the document");
	assert.equal(externalRenderWins(read({ mtimeMs: 50 }), key("edit"), "fold", 100), false, "an older render is a torn window");
	assert.equal(externalRenderWins(read({ mtimeMs: undefined }), key("edit"), "fold", 100), false, "a render with no time cannot win");
	assert.equal(externalRenderWins(read(), key("edit"), "fold", undefined), false, "a journal with no time is not older than the render");
});

test("a render replaced under the read does not win it, and a stable newer render still does", async () => {
	const root = await project();
	await recordMemoryDocument(root, "# Project Memory\n\n- the journal seed\n");
	const journal = memoryJournalFile(root);
	const past = new Date(Date.now() - 60_000);
	await utimes(journal, past, past);
	const file = memoryFile(root);
	await rm(file, { force: true });
	execFileSync("mkfifo", [file]);

	const loaded = await replaceUnderRead({
		root,
		file,
		start: () => loadMemory(root),
		older: "# Project Memory\n\n- older bytes handed to the reader\n",
		newer: "# Project Memory\n\n- external edit newer than the journal\n",
	});

	// The pair below is the discriminator: a reader that started after the replacement would adopt
	// the replacement (source === file), so this cannot pass unless the read really spanned it.
	assert.equal(loaded.source, journal, "the fold stands instead of bytes the read cannot vouch for");
	assert.match(loaded.text, /journal seed/);
	assert.ok(!loaded.text.includes("older bytes"), "the older version is not adopted");
	assert.match(await readFile(file, "utf8"), /external edit newer than the journal/, "the replacement really landed under the read");

	// Without this half the guard would be a blanket refusal of external edits.
	const stable = await loadMemory(root);
	assert.equal(stable.source, file);
	assert.match(stable.text, /external edit newer than the journal/);
});

test("the adopt refuses a key the file no longer holds, and still takes the file's current one", async () => {
	const root = await project();
	await recordMemoryDocument(root, "# Project Memory\n\n- the journal seed\n");
	const journal = memoryJournalFile(root);
	const past = new Date(Date.now() - 60_000);
	await utimes(journal, past, past);
	const file = memoryFile(root);
	const replacement = "# Project Memory\n\n- the replacement the borrowed key must not shadow\n";
	await writeFile(file, replacement, "utf8");

	// A key the write path could have taken and then had invalidated (this test fabricates it):
	// journaling it would push the journal's mtime past the replacement, so the adopt must refuse it.
	const stale = memoryComparisonKey("# Project Memory\n\n- the bytes the caller read before the model call\n", MAX_MEMORY_CHARS);
	// Without this the case would also pass if the key function collapsed every render to one key:
	// the refusal below has to be about staleness, not about an empty or shared key.
	assert.ok(stale && stale !== memoryComparisonKey(replacement, MAX_MEMORY_CHARS), "the borrowed key is a real, different key");
	assert.equal(await adoptExternalEdit(root, MAX_MEMORY_CHARS, { renderKey: stale }), false);
	assert.ok(!(await readFile(journal, "utf8")).includes("before the model call"), "the stale version never entered the journal");
	assert.match(await readFile(path.join(root, ".agents", "memory", "errors.log"), "utf8"), /the memory render changed before the memory journal could record the edit/);
	assert.equal(await readFile(file, "utf8"), replacement, "the replacement is untouched");

	// The guard refuses staleness, not edits: the file's own key is still adopted.
	assert.equal(await adoptExternalEdit(root, MAX_MEMORY_CHARS, { renderKey: memoryComparisonKey(replacement, MAX_MEMORY_CHARS) }), true);
	assert.match(await readFile(journal, "utf8"), /replacement the borrowed key must not shadow/);
});

test("the adopt leaves a render that already equals the fold alone, and one older than the journal too", async () => {
	const root = await project();
	await recordMemoryDocument(root, "# Project Memory\n\n- the document the journal already holds\n");
	const journal = memoryJournalFile(root);
	const file = memoryFile(root);
	const past = new Date(Date.now() - 60_000);

	// Our own output, re-stamped newer: adopting it would only duplicate a record the journal has.
	const own = await readFile(file, "utf8");
	await utimes(journal, past, past);
	await writeFile(file, own, "utf8");
	const before = (await readMemoryJournal(journal)).entries.length;
	assert.equal(await adoptExternalEdit(root), false, "a render equal to the fold is our own output");
	assert.equal((await readMemoryJournal(journal)).entries.length, before, "nothing was journalled");

	// A render older than the journal and different from it is a torn write window, not an edit.
	await writeFile(file, "# Project Memory\n\n- a render older than the journal\n", "utf8");
	await utimes(file, past, past);
	assert.equal(await adoptExternalEdit(root), false, "an older render is not an edit to adopt");
	assert.ok(!(await readFile(journal, "utf8")).includes("older than the journal"), "the older bytes never entered the journal");

	// The positive control: a newer, different render is adopted.
	await writeFile(file, "# Project Memory\n\n- a hand edit newer than the journal\n", "utf8");
	assert.equal(await adoptExternalEdit(root), true, "a newer, different render is adopted");
	assert.match(await readFile(journal, "utf8"), /a hand edit newer than the journal/);
});

test("loadMemorySync still adopts a stable newer render", async () => {
	const root = await project();
	await recordMemoryDocument(root, "# Project Memory\n\n- written by the plugin\n");
	const journal = memoryJournalFile(root);
	const past = new Date(Date.now() - 60_000);
	await utimes(journal, past, past);
	await writeFile(memoryFile(root), "# Project Memory\n\n- edited by hand\n", "utf8");
	assert.match(loadMemorySync(root), /edited by hand/, "the sync reader and the async one share the rule");
	assert.equal(loadMemorySync(root), (await loadMemory(root)).text);
});

test("a render cleared by hand does not win the read, and does not make a pass look stale", async () => {
	const root = await project();
	await recordMemoryDocument(root, "# Project Memory\n\n- the document the journal holds\n");
	const journal = memoryJournalFile(root);
	const fold = (await loadMemory(root)).text;
	// Truncated by hand after the journal was written, so it is newer than the journal. The comparison
	// key of an empty document is the canonical bare header, not "", so this cannot be decided by key.
	await writeFile(memoryFile(root), "", "utf8");
	const loaded = await loadMemory(root);
	assert.equal(loaded.source, journal, "a blank render is not an external edit");
	assert.match(loaded.text, /the document the journal holds/);
	assert.equal(loadMemorySync(root), loaded.text, "both readers agree");

	// The write path too. A pass that built its reply from the fold must not be told the memory changed,
	// which would refuse a real consolidation and name the bare header as "the newer content".
	const result = await recordMemoryDocument(root, "# Project Memory\n\n- this pass's reply\n", MAX_MEMORY_CHARS, { basisKey: fold });
	assert.equal(result.written, true, "a cleared render does not make the pass look stale");
	assert.match(await readFile(memoryFile(root), "utf8"), /this pass's reply/);
	assert.ok(!(await readFile(path.join(root, ".agents", "memory", "errors.log"), "utf8").catch(() => "")).includes("the memory changed while this pass's reply was being built"), "and that refusal is not logged with a wrong cause");

	// Whitespace-only is the same state, and it is the one the key cannot tell apart from content.
	await writeFile(memoryFile(root), " \n\t\n", "utf8");
	assert.equal((await loadMemory(root)).source, journal, "a whitespace-only render is not an edit either");
});

test("an edit landing under the adopt's own read is left for the next pass", async () => {
	const root = await project();
	await recordMemoryDocument(root, "# Project Memory\n\n- the journal seed\n");
	const journal = memoryJournalFile(root);
	const past = new Date(Date.now() - 60_000);
	await utimes(journal, past, past);
	const file = memoryFile(root);
	await rm(file, { force: true });
	execFileSync("mkfifo", [file]);

	const adopted = await replaceUnderRead({
		root,
		file,
		start: () => adoptExternalEdit(root),
		older: "# Project Memory\n\n- older bytes handed to the reader\n",
		newer: "# Project Memory\n\n- external edit newer than the journal\n",
	});

	assert.equal(adopted, false, "nothing is journalled for a read that spanned a replacement");
	const journalText = await readFile(journal, "utf8");
	assert.ok(!journalText.includes("older bytes"), "the version the file dropped never entered the journal");
	assert.match(await readFile(file, "utf8"), /external edit newer than the journal/, "the replacement is still the file's content");
	assert.match(await readFile(path.join(root, ".agents", "memory", "errors.log"), "utf8"), /the memory render changed before the memory journal could record the edit/);
});

test("loadMemorySync folds the same document the async reader returns", async () => {
	const root = await project();
	await recordMemoryDocument(root, "sync and async agree");
	assert.equal(loadMemorySync(root), (await loadMemory(root)).text);

	// A render that never reached disk (crash between append and render) must not hide the record.
	await appendMemoryOp(memoryJournalFile(root), "replace", "only in the journal");
	assert.match(loadMemorySync(root), /only in the journal/);
	assert.match((await loadMemory(root)).text, /only in the journal/);

	// With no journal at all the rendered document is still readable, poison decoded.
	const legacy = await project();
	await writeFile(memoryFile(legacy), "# Project Memory\n\nlegacy only\n", "utf8");
	assert.match(loadMemorySync(legacy), /legacy only/);
	assert.equal(loadMemorySync(await project()), "");
});

test("loadMemorySync folds a journal whose render is missing, and fails closed on a corrupt one", async () => {
	// The append lands before the render does, so a crash in that window (or a hand-deleted
	// MEMORY.md) leaves records that only the journal holds. Losing them here would silently drop
	// the project's memory from the system prompt.
	const root = await project();
	await recordMemoryDocument(root, "journal only");
	await rm(memoryFile(root));
	assert.match(loadMemorySync(root), /journal only/);
	assert.equal(loadMemorySync(root), (await loadMemory(root)).text);

	// A torn tail is skipped record-by-record, so the good records still beat a stale render.
	await writeFile(memoryFile(root), "# Project Memory\n\nstale render\n", "utf8");
	await writeFile(memoryJournalFile(root), `${await readFile(memoryJournalFile(root), "utf8")}{"op":"rep`, "utf8");
	assert.match(loadMemorySync(root), /journal only/);
	assert.doesNotMatch(loadMemorySync(root), /stale render/);
	assert.equal(loadMemorySync(root), (await loadMemory(root)).text);

	// Nothing usable at all: fail closed instead of injecting a render the journal superseded.
	const corrupt = await project();
	await writeFile(memoryFile(corrupt), "# Project Memory\n\nstale render\n", "utf8");
	await writeFile(memoryJournalFile(corrupt), "not a journal at all\n", "utf8");
	assert.equal(loadMemorySync(corrupt), "");
	assert.equal((await loadMemory(corrupt)).text, "");
});

test("an unreadable render fails closed in both readers", async () => {
	const root = await project();
	// A directory where the render belongs: it exists, and it cannot be read.
	await mkdir(memoryFile(root), { recursive: true });
	await mkdir(path.join(root, ".pi"), { recursive: true });
	await writeFile(path.join(root, ".pi", "MEMORY.md"), "# Project Memory\n\npi legacy\n", "utf8");

	assert.equal((await loadMemory(root)).unreadable, true, "the async reader reports it");
	assert.equal(loadMemorySync(root), "", "and the sync reader must not serve the legacy file instead");
});

test("the legacy .omp import never overrides a journal, and the sync reader reads it", async () => {
	// `legacyOmpDir` resolves against the home directory at call time, so point HOME at a fixture.
	const home = await mkdtemp(path.join(tmpdir(), "dsh-home-"));
	const previousHome = process.env.HOME;
	process.env.HOME = home;
	try {
		const root = await project();
		await mkdir(legacyOmpDir(root), { recursive: true });
		await writeFile(path.join(legacyOmpDir(root), "MEMORY.md"), "# Project Memory\n\nlegacy omp\n", "utf8");
		// Nothing owns the project yet: the sync reader injects the legacy document.
		assert.match(loadMemorySync(root), /legacy omp/);

		// Once a journal exists, the legacy file must never be imported over it — even when the
		// render is gone (which is when an unguarded import would look like an external edit).
		await recordMemoryDocument(root, "consolidated memory");
		await rm(memoryFile(root), { force: true });
		assert.equal(await importLegacyMemory(root), false, "the journal owns the memory");
		assert.match((await loadMemory(root)).text, /consolidated memory/);

		// A fresh project with no journal does import it.
		const fresh = await project();
		await mkdir(legacyOmpDir(fresh), { recursive: true });
		await writeFile(path.join(legacyOmpDir(fresh), "MEMORY.md"), "# Project Memory\n\nlegacy omp\n", "utf8");
		assert.equal(await importLegacyMemory(fresh), true);
		assert.match((await loadMemory(fresh)).text, /legacy omp/);
	} finally {
		if (previousHome === undefined) delete process.env.HOME;
		else process.env.HOME = previousHome;
		await rm(home, { recursive: true, force: true });
	}
});

test("a failed pass releases its version claim so the next forced pass retries", async () => {
	const root = await project();
	// Make the memory write fail for good: the render path is a directory.
	await mkdir(memoryFile(root), { recursive: true });
	const reply = JSON.stringify({ memory_markdown: `# Project Memory\n\n${"x".repeat(200)}`, context: { title: "t", summary: "s", key_points: [], open_tasks: [] } });
	const ctx = {
		logger: { info() {}, warn() {} },
		llm: {
			stream() {
				return (async function* generate() {
					yield { type: "text-delta", text: reply };
				})();
			},
		},
	};
	const agent = {
		options: { provider: "test-provider", model: "test-model" },
		session: { id: "session-claim", header: { cwd: root, createdAt: Date.now() }, snapshotEvents: () => [], deriveMessages: () => [], requestHeader: () => undefined },
	};
	// Keep the default force-dedupe window: the second forced pass then reuses the *cached*
	// outcome (same version), which is exactly the case the release protects.
	const config = resolvePluginConfig({ maxTokens: 8192 });

	assert.equal((await consolidateProject(ctx, config, agent, { force: true, silent: true })).status, "failed");
	// Without the release this would answer "deduped" — a false "already up to date" after a write
	// that never landed.
	assert.notEqual((await consolidateProject(ctx, config, agent, { force: true, silent: true })).status, "deduped");
});

test("a malformed model reply cannot leak credentials into the logs", async () => {
	// `replyHead` embeds the reply the model actually sent, and the consolidation failure is
	// reported twice from the same thrown error: `errors.log` (redacted on the append path) and
	// `ctx.logger.warn`, which writes whatever it is handed. Before this test the console copy was
	// verbatim, so one bad reply printed the credentials it contained.
	const root = await project();
	const jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.signaturepart";
	const key = "sk-abcdefghijklmnop";
	const warnings = [];
	const ctx = {
		logger: { info() {}, warn: (format, ...args) => { warnings.push(`${format} ${args.join(" ")}`); } },
		llm: {
			stream() {
				return (async function* generate() {
					// JSON-looking but truncated: `looksLikeJsonReply` is true, the parse fails, and the
					// reply holds no recoverable `memory_markdown` field, so the pass throws with the raw
					// reply attached — the credential-bearing path. (A plain non-JSON reply is accepted
					// as Markdown memory by design, so it never reaches this error.)
					yield { type: "text-delta", text: `{\n"context": {"apiKey": "${key}"},\n"raw": "authorization: Bearer ${jwt}"` };
				})();
			},
		},
	};
	const agent = {
		options: { provider: "test-provider", model: "test-model" },
		session: { id: "session-redact", header: { cwd: root, createdAt: Date.now() }, snapshotEvents: () => [], deriveMessages: () => [], requestHeader: () => undefined },
	};
	const config = resolvePluginConfig({ maxTokens: 8192 });

	assert.equal((await consolidateProject(ctx, config, agent, { force: true, silent: false })).status, "failed");
	assert.equal(warnings.length, 1, `expected one warning, got ${JSON.stringify(warnings)}`);

	// The console is the unguarded sink: mask and bound there.
	assert.ok(!warnings[0].includes(jwt), "the JWT must not reach the console");
	assert.ok(!warnings[0].includes(key), "the key must not reach the console");
	assert.match(warnings[0], /\[redacted/);
	assert.ok(warnings[0].length < 1000, `the console line must stay bounded, got ${warnings[0].length} chars`);

	// The file sink keeps the raw head for diagnosis, but never the credential itself.
	const logged = await readFile(path.join(root, ".agents", "memory", "errors.log"), "utf8");
	assert.ok(!logged.includes(jwt), "the JWT must not reach errors.log");
	assert.ok(!logged.includes(key), "the key must not reach errors.log");
	assert.match(logged, /--- raw reply ---/, "the raw reply is still attached for diagnosis");
});

test("the console copy of a failure is redacted even when its source is not", async () => {
	// The console sink must hold on its own: `ctx.logger.warn` is handed error text from paths whose
	// source is not redacted (a filesystem path, a lock error), so this drives one of those through
	// the real pass rather than relying on the redaction `replyHead` already applied upstream.
	const key = "sk-abcdefghijklmnop";
	// A credential in the project path reaches the logger verbatim: the failing write reports the
	// path it could not open ("ENOTDIR: …/.agents/memory/MEMORY.md.lock") and no upstream layer
	// masks a path.
	const dir = await mkdtemp(path.join(tmpdir(), `dsh-${key}-`));
	// `.agents` as a regular file makes every write under it fail with the full path in the message.
	await writeFile(path.join(dir, ".agents"), "not a directory", "utf8");
	const warnings = [];
	const ctx = {
		logger: { info() {}, warn: (format, ...args) => { warnings.push(`${format} ${args.join(" ")}`); } },
		llm: {
			stream() {
				return (async function* generate() {
					yield { type: "text-delta", text: JSON.stringify({ memory_markdown: `# Project Memory\n\n${"x".repeat(200)}` }) };
				})();
			},
		},
	};
	const agent = {
		options: { provider: "test-provider", model: "test-model" },
		session: { id: "session-path-redact", header: { cwd: dir, createdAt: Date.now() }, snapshotEvents: () => [], deriveMessages: () => [], requestHeader: () => undefined },
	};
	const config = resolvePluginConfig({ maxTokens: 8192 });

	assert.equal((await consolidateProject(ctx, config, agent, { force: true, silent: false })).status, "failed");
	assert.equal(warnings.length, 1, `expected one warning, got ${JSON.stringify(warnings)}`);
	assert.ok(warnings[0].includes(".agents/memory"), "the failure is the memory write, not something else");
	assert.ok(!warnings[0].includes(key), "the console sink must mask a secret it was not given masked");
	assert.match(warnings[0], /\[redacted-key\]/);
});

test("the consolidation prompt sends the fitted artifacts inside the configured ceiling", async () => {
	// The budget only matters if it reaches the model call, so this pins the adaptive cap: the request
	// asks for more than `maxTokens`, and never more than `maxOutputTokens`.
	// Batch X narrowed the fixture: 60k dense CJK characters no longer reach the model at all — the fit
	// hides them and the pass refuses before the call — so the case that exercises *this* wiring is the one
	// where the documents fit and the reply still needs room. 12000 + 12000 CJK asks for 25040 tokens and
	// hides nothing, which is the only shape that can still reach a prompt.
	const root = await project();
	const memory = `# Project Memory\n\n${"记".repeat(12_000)}\n`;
	const context = `# Project Context\n\n${"录".repeat(12_000)}\n`;
	await writeFile(memoryFile(root), memory, "utf8");
	await writeFile(path.join(root, ".agents", "memory", "CONTEXT.md"), context, "utf8");

	// Guard the fixture: this test proves nothing if the fit itself hides content.
	const fitted = fitMemoryInput(memory, context, 8192, {}, 32_768);
	assert.equal(fitted.clipped, false, `fixture: the fit must show both documents whole (${JSON.stringify(fitted)})`);
	assert.ok(fitted.maxTokens > 8192, "fixture: the adaptive cap must be raised by the documents");

	const calls = [];
	const ctx = {
		logger: { info() {}, warn() {} },
		llm: {
			stream(options) {
				calls.push(options);
				return (async function* generate() {
					yield { type: "text-delta", text: '{"memory_markdown":"# Project Memory\\n\\nshort","context":{"title":"t","summary":"s","key_points":[],"open_tasks":[]}}' };
				})();
			},
		},
	};
	const agent = {
		options: { provider: "test-provider", model: "test-model" },
		session: {
			id: "session-consolidate",
			header: { cwd: root, createdAt: Date.now() },
			snapshotEvents: () => [],
			deriveMessages: () => [],
			requestHeader: () => undefined,
		},
	};
	const config = resolvePluginConfig({ maxTokens: 8192, maxOutputTokens: 32_768, consolidateTurns: 1 });

	await consolidateProjectState(ctx, agent, config, { force: true });

	assert.equal(calls.length, 1, "one model call");
	const prompt = calls[0].messages[0].content.map((block) => block.text ?? "").join("\n");
	const sent = /<existing-memory>\n([\s\S]*?)\n<\/existing-memory>/.exec(prompt)[1];
	assert.equal(sent.length, memory.trimEnd().length, "the prompt carries the whole memory, not a shortened view");
	assert.ok(calls[0].maxTokens > config.maxTokens, "the adaptive cap was raised to fit the reply");
	assert.equal(calls[0].maxTokens, fitted.maxTokens, "and it is the fit's own number, not a second estimate");
	assert.ok(calls[0].maxTokens <= config.maxOutputTokens, "and stayed inside the configured ceiling");
});

test("the sync reader falls back to legacy layouts, and the locked import respects a journal", async () => {
	const root = await project();
	await mkdir(path.join(root, ".pi"), { recursive: true });
	await writeFile(path.join(root, ".pi", "MEMORY.md"), "# Project Memory\n\npi legacy\n", "utf8");

	// The synchronous reader (prompt injection) falls back exactly like the asynchronous one.
	assert.match(loadMemorySync(root), /pi legacy/);
	assert.match((await loadMemory(root)).text, /pi legacy/);

	// The legacy `.omp` import holds the lock and refuses to run once the journal owns the project.
	await recordMemoryDocument(root, "consolidated");
	assert.equal(await importLegacyMemory(root), false, "a journal already owns the memory");
	assert.match((await loadMemory(root)).text, /consolidated/);
});

test("logError also writes the memory ignore file and redacts credentials", async () => {
	const root = await project();
	await logError(root, "test", new Error("failed with sk-abcdefghijklmnop and ghp_abcdefghijklmnop"));

	const directory = path.join(root, ".agents", "memory");
	assert.ok((await readdir(directory)).includes(".gitignore"), "logging alone creates the ignore file");
	assert.match(await readFile(path.join(directory, ".gitignore"), "utf8"), /errors\.log/);
	const logged = await readFile(path.join(directory, "errors.log"), "utf8");
	assert.doesNotMatch(logged, /sk-abcdefghijklmnop/, "the credential is masked");
	assert.doesNotMatch(logged, /ghp_abcdefghijklmnop/);
	assert.match(logged, /\[redacted/);
});

test("backupMemoryBeforeWrite keeps the exact bytes and flags a stored reply", async () => {
	const root = await project();
	const target = memoryFile(root);
	await writeFile(target, "# Project Memory\n\noriginal\n", "utf8");

	const kept = await backupMemoryBeforeWrite(target);
	assert.equal(kept.poisoned, false);
	assert.ok(kept.path);
	assert.equal(await readFile(kept.path, "utf8"), "# Project Memory\n\noriginal\n");

	const poisoned = await project();
	await writeFile(memoryFile(poisoned), '```json\n{"memory_markdown":"# Project Memory\\n\\nx"}\n```\n', "utf8");
	assert.equal((await backupMemoryBeforeWrite(memoryFile(poisoned))).poisoned, true);

	// Nothing to keep is not an error.
	assert.deepEqual(await backupMemoryBeforeWrite(path.join(await project(), "MEMORY.md")), { poisoned: false });
});

test("backup pruning keeps the newest few and never a user file", async () => {
	const root = await project();
	const target = memoryFile(root);
	await writeFile(target, "current\n", "utf8");
	const directory = path.dirname(target);
	const old = new Date(Date.now() - 2 * 60 * 60 * 1000);
	for (let index = 0; index < 9; index += 1) {
		const name = `MEMORY.md.memory-backup-2026-01-0${index}T00-00-00-000Z-${String(index).repeat(8)}`;
		await writeFile(path.join(directory, name), `old ${index}\n`, "utf8");
		await utimes(path.join(directory, name), old, old);
	}
	// A user file that merely looks similar must survive.
	await writeFile(path.join(directory, "MEMORY.md.memory-backup-notes.md"), "mine\n", "utf8");

	await backupMemoryBeforeWrite(target);

	const names = await readdir(directory);
	const generated = names.filter((name) => /^MEMORY\.md\.memory-backup-\d{4}-/.test(name));
	assert.equal(generated.length, 5, `kept ${generated.join(", ")}`);
	assert.ok(names.includes("MEMORY.md.memory-backup-notes.md"), "an unrelated file is never pruned");
});

test("withMemoryLock serializes writers and steals a stale lock", async () => {
	const root = await project();
	const target = memoryFile(root);
	const events = [];
	let releaseFirst;
	let firstLocked;
	const held = new Promise((resolve) => { releaseFirst = resolve; });
	const acquired = new Promise((resolve) => { firstLocked = resolve; });
	const first = withMemoryLock(target, async () => {
		events.push("first:start");
		firstLocked();
		await held;
		events.push("first:end");
	});
	// Wait until the first writer actually owns the lock, then start the second.
	await acquired;
	const second = withMemoryLock(target, async () => {
		events.push("second:start");
		events.push("second:end");
	});
	releaseFirst();
	await Promise.all([first, second]);
	assert.deepEqual(events, ["first:start", "first:end", "second:start", "second:end"], "the second writer waits for the first");
	assert.equal(existsSync(`${target}.lock`), false, "the lock is released");
	assert.equal(existsSync(`${target}.lock.steal`), false, "the claim is released");

	// A lock left by a crashed writer is stolen once it is older than any live write.
	await writeFile(`${target}.lock`, "999-dead\n", { mode: 0o600 });
	const old = new Date(Date.now() - 60_000);
	await utimes(`${target}.lock`, old, old);
	let ran = false;
	await withMemoryLock(target, async () => {
		ran = true;
	});
	assert.equal(ran, true, "a stale lock does not block the write forever");
	assert.equal(existsSync(`${target}.lock`), false);
});

test("an oversized journal collapses into one record and archives the previous bytes", async () => {
	const root = await project();
	const journal = memoryJournalFile(root);
	const body = "x".repeat(1_000);
	for (let index = 0; index < 600; index += 1) await appendMemoryOp(journal, "append", `${body}${index}`);
	assert.ok((await stat(journal)).size > 512 * 1024, "the journal grew past the rotation threshold");

	await recordMemoryDocument(root, "collapsed");

	const entries = (await readMemoryJournal(journal)).entries;
	assert.ok(entries.length <= 2, `journal collapsed to ${entries.length} record(s)`);
	const archives = (await readdir(path.dirname(journal))).filter((name) => /^memory-log-.*\.jsonl$/.test(name));
	assert.equal(archives.length, 1, "the previous bytes are archived, not deleted");
	assert.ok((await readFile(path.join(path.dirname(journal), archives[0]), "utf8")).length > 0);
});

test("a missing journal is recovered from its rotation archive, not from the stale render", async () => {
	// Rotation copies the previous bytes to `memory-log-*.jsonl` before replacing the journal, so when
	// `memory.jsonl` is gone the archive is the surviving copy of the document the pass wrote. The read
	// path used to fall straight through to `MEMORY.md`, which can predate the pass entirely — a
	// healthy-looking, stale document while the real content sat unread beside it.
	const root = await project();
	const passDocument = "# Project Memory\n\n- the pass's document\n";
	await writeFile(memoryFile(root), "# Project Memory\n\n- a stale pre-pass render\n");
	await writeFile(
		path.join(memoryDir(root), "memory-log-2026-01-01T00-00-00-000Z-00000000.jsonl"),
		`${JSON.stringify({ ts: "2026-01-01T00:00:00.000Z", op: "replace", text: passDocument })}\n`,
	);

	const loaded = await loadMemory(root, MAX_MEMORY_CHARS);
	assert.match(loaded.text, /the pass's document/, "the archive decides, not the render");
	assert.doesNotMatch(loaded.text, /stale pre-pass render/);
	assert.match(loaded.source, /memory-log-2026-01-01/, "the read names the archive it recovered from");
	assert.match(loadMemorySync(root, MAX_MEMORY_CHARS), /the pass's document/, "the sync reader recovers too");
});

test("normalizeMemoryDocument rebuilds one canonical document", () => {
	assert.equal(normalizeMemoryDocument("```markdown\n# Project Memory\n\nbody\n```"), "# Project Memory\n\nbody\n");
	assert.equal(normalizeMemoryDocument("body only"), "# Project Memory\n\nbody only\n");
	assert.equal(normalizeMemoryDocument(""), "# Project Memory\n");
	// The default cap keeps a document that fits exactly as it is.
	assert.equal(normalizeMemoryDocument("tiny"), "# Project Memory\n\ntiny\n");
	assert.equal(MAX_MEMORY_CHARS, 40_000, "the default cap is the documented 40000");
});

/** A memory document of `count` complete lines, each well under any line-length cap. */
function lines(count) {
	return Array.from({ length: count }, (_, index) => `- fact ${index} ${"x".repeat(40)}`).join("\n");
}

test("a capped memory keeps whole lines and reports the cut", () => {
	// The cap used to be a bare `.slice(0, MAX_MEMORY_CHARS)`: the last line was cut mid-sentence,
	// so a fact lost its tail with nothing to show for it, and the document looked complete.
	const source = lines(200);
	const limit = 4_000;
	const out = normalizeMemoryDocument(source, limit);
	const bodyLines = out.trimEnd().split("\n").slice(2, -2);

	// Every kept line is a complete line of the source (the marker line is not a source line).
	assert.ok(bodyLines.length > 0, "something is kept");
	for (const line of bodyLines) assert.equal(source.split("\n").includes(line), true, `line is complete: ${line}`);
	// And the body is the source's prefix, unbroken: no line was silently cut or reordered.
	assert.equal(bodyLines.join("\n"), source.split("\n").slice(0, bodyLines.length).join("\n"));
	assert.equal(bodyLines[0].startsWith("- fact 0 "), true, "the body starts at the first source line");

	// The marker is the last line and names the limit; `isMemoryTruncated` sees it.
	const marker = out.trimEnd().split("\n").pop();
	assert.match(marker, /^_\[memory truncated at 4000 characters: \d+ dropped\]_$/);
	assert.equal(isMemoryTruncated(out), true, "a capped memory is visibly capped");
	assert.equal(isMemoryTruncated("# Project Memory\n\n- fact\n"), false);

	// The character budget is honoured, marker included.
	assert.ok(out.trimEnd().length <= limit, `document is ${out.trimEnd().length} chars, over the ${limit} cap`);
	// Nothing was thrown away silently: the marker accounts for the whole loss.
	const document = `# Project Memory\n\n${source.trim()}`;
	const dropped = Number(/: (\d+) dropped\]_$/.exec(marker)[1]);
	assert.equal(document.length - out.trimEnd().split("\n").slice(0, -2).join("\n").length, dropped, "the marker accounts for exactly the loss");
});

test("the truncation marker names the limit and the dropped characters", () => {
	const source = lines(200);
	const limit = 4_000;
	const out = normalizeMemoryDocument(source, limit);
	const marker = out.trimEnd().split("\n").pop();
	const named = /^_\[memory truncated at (\d+) characters: (\d+) dropped\]_$/.exec(marker);
	assert.ok(named, `marker shape: ${marker}`);
	assert.equal(Number(named[1]), limit, "the limit is named");
	// The dropped count is the number of source characters that did not make it: the whole
	// document minus what was kept, exactly as the marker promises.
	const document = `# Project Memory\n\n${source.trim()}`;
	const keptLength = out.trimEnd().split("\n").slice(0, -2).join("\n").length;
	assert.equal(Number(named[2]), document.length - keptLength, "the dropped count is the real loss");
	assert.equal(memoryTruncationMarker(7, 100), "_[memory truncated at 100 characters: 7 dropped]_");
});

test("a capped document that is written back unchanged stays capped the same way", () => {
	// The store re-normalizes on every write (journal append and render). A document that is
	// already capped must come back byte-identical, or every pass would shave another line off
	// the memory — the compounding loss in its other form.
	const limit = 6_000;
	const first = normalizeMemoryDocument(lines(300), limit);
	assert.equal(isMemoryTruncated(first), true);
	assert.equal(normalizeMemoryDocument(first, limit), first);
	// Rendering it back through the normalizer sees the same bytes a read would.
	assert.equal(normalizeMemoryDocument(first.trim(), limit), first);
	// And the marker's count does not drift as the document is re-emitted repeatedly.
	for (let pass = 0; pass < 5; pass += 1) assert.equal(normalizeMemoryDocument(first, limit), first, `pass ${pass}`);
});

test("normalizing a capped document twice is idempotent", () => {
	const limit = 4_000;
	const once = normalizeMemoryDocument(lines(200), limit);
	assert.equal(isMemoryTruncated(once), true);
	const twice = normalizeMemoryDocument(once, limit);
	assert.equal(twice, once, "the marker is stripped and recomputed, not appended again");
	assert.equal(normalizeMemoryDocument(twice, limit), once, "and it stays stable");
	// A document that fits keeps a marker an earlier cap left behind as its last line, so a memory
	// that shrank (a smaller cap was configured) still reports why it is short instead of silently
	// dropping the notice.
	const shrunk = normalizeMemoryDocument(once, 200_000);
	assert.equal(isMemoryTruncated(shrunk), true, "the notice survives a raise of the cap");
	assert.match(shrunk, /- fact 0 /);
});

test("a memory line beginning with the marker words is not a marker", () => {
	// Only the exact shape is a marker. A real memory line that happens to start the same way must
	// neither be read as a cap (a fitted document that carries one is not truncated) nor be moved
	// to the end of the document when a real marker is appended.
	const lookalike = "_[memory truncated at some point in the past]_";
	assert.equal(isMemoryTruncated(`# Project Memory\n\n${lookalike}\n`), false, "the lookalike alone is not a marker");

	// Kept verbatim and in place when the document fits.
	const fits = `${lookalike}\n\ntiny tail`;
	const kept = normalizeMemoryDocument(fits);
	assert.equal(isMemoryTruncated(kept), false, "a fitted document is not reported as capped");
	assert.equal(kept.indexOf(lookalike) < kept.indexOf("tiny tail"), true, "the lookalike stays where it was written");

	// Over the cap: a real marker is added, and the lookalike is still an ordinary line that was
	// neither stripped nor hoisted to the end.
	const limit = 4_000;
	const out = normalizeMemoryDocument(`${lookalike}\n${lines(200)}`, limit);
	assert.equal(out.split(lookalike).length - 1, 1, "the lookalike appears exactly once, not duplicated to the end");
	assert.equal(out.indexOf(lookalike) < out.indexOf("- fact 0 "), true, "and it precedes the source body");
	assert.match(out.trimEnd().split("\n").pop(), /^_\[memory truncated at 4000 characters: \d+ dropped\]_$/, "a real marker is still added");
	// Idempotent afterwards: the real marker is stripped and recomputed, the lookalike is untouched.
	assert.equal(normalizeMemoryDocument(out, limit), out);
});

test("an explicit limit is honoured, and the default cap is the documented one", () => {
	// Each fixture genuinely exceeds its limit, so every case really exercises the cap.
	for (const [limit, count] of [[MIN_MEMORY_CHARS, 90], [6_000, 200], [20_000, 500]]) {
		const source = lines(count);
		assert.ok(source.length > limit, `fixture ${count} lines exceeds ${limit}`);
		const out = normalizeMemoryDocument(source, limit);
		const marker = out.trimEnd().split("\n").pop();
		assert.match(marker, new RegExp(`^_\\[memory truncated at ${limit} characters: \\d+ dropped\\]_$`));
		assert.equal(isMemoryTruncated(out), true);
		// The whole document, marker included, fits the configured limit.
		assert.ok(out.trimEnd().length <= limit, `document is ${out.trimEnd().length} chars, over the ${limit} cap`);
		// A larger limit keeps strictly more body than a smaller one.
		const body = out.trimEnd().split("\n").slice(0, -2).join("\n").length;
		assert.ok(body > 0 && body < source.length, `body ${body} is a real prefix of ${source.length}`);
	}
	// The default cap is the documented one, and it is now wide enough that a document the old 32000
	// default cut comes through whole — that headroom is the point of the raise, and it is exactly
	// what a profile relying on the bundle insert (no `maxMemoryChars` of its own) now gets.
	const withinDefault = lines(650);
	assert.ok(withinDefault.length > 32_000, `fixture is ${withinDefault.length} chars, past the old default`);
	const kept = normalizeMemoryDocument(withinDefault);
	assert.equal(isMemoryTruncated(kept), false, "the default cap keeps a document the old 32000 default cut");
	assert.ok(kept.length > 32_000, `the default keeps ${kept.length} chars`);

	// And it still cuts, on a line boundary, naming the default it used.
	const large = normalizeMemoryDocument(lines(800), MAX_MEMORY_CHARS);
	assert.match(large.trimEnd().split("\n").pop(), /^_\[memory truncated at 40000 characters: \d+ dropped\]_$/);
	assert.ok(large.trimEnd().length > 24_000, `the default keeps ${large.trimEnd().length} chars, more than the old cap`);
	assert.equal(normalizeMemoryDocument("tiny", MIN_MEMORY_CHARS), "# Project Memory\n\ntiny\n", "a short document is untouched");
});

test("new memory appended to a capped document survives the next write", async () => {
	// The defect this whole change is about: new memory is appended at the end, which is exactly
	// what the cap dropped, so every consolidation pass silently discarded the learning it had
	// just produced. Against a memory already over the cap, appending must keep the new line.
	const limit = 4_000;
	let document = normalizeMemoryDocument(lines(200), limit);
	assert.equal(isMemoryTruncated(document), true, "the fixture starts capped");
	for (let pass = 1; pass <= 3; pass += 1) {
		const before = document.length;
		document = normalizeMemoryDocument(`${document}\n\nNEW fact ${pass}`, limit);
		assert.ok(document.includes(`NEW fact ${pass}`), `pass ${pass}: the new line survived`);
		assert.equal(isMemoryTruncated(document), true, "and the cap is still reported");
		assert.match(document.trimEnd().split("\n").pop(), /^_\[memory truncated at 4000 characters: \d+ dropped\]_$/);
		assert.ok(document.length <= limit + 200, `pass ${pass}: the document stays near the cap (${before} -> ${document.length})`);
	}
	// The line is durable through the store too, not only through the pure normalizer.
	const root = await project();
	await writeFile(memoryFile(root), normalizeMemoryDocument(lines(200), limit), "utf8");
	await recordMemoryDocument(root, `${await readFile(memoryFile(root), "utf8")}\n\nNEW durable fact`, limit);
	const loaded = await loadMemory(root, limit);
	assert.match(loaded.text, /NEW durable fact/, "the store keeps the appended fact");
	assert.equal(isMemoryTruncated(loaded.text), true, "and reports the cap it applied");
});

test("the lock waiter outlives the staleness horizon", () => {
	// A lock is only stealable once it is older than the staleness horizon, so a wait shorter than
	// that horizon would make a pass fail for the rest of the window instead of taking the abandoned
	// lock over. This pins the production relationship; the behavior is exercised below.
	assert.ok(MEMORY_LOCK_WAIT_MS > MEMORY_LOCK_STALE_MS, `wait ${MEMORY_LOCK_WAIT_MS} must exceed stale ${MEMORY_LOCK_STALE_MS}`);
});

test("an orphaned lock is stolen past the horizon and left alone before it", async () => {
	const root = await project();
	const target = memoryFile(root);
	const lock = `${target}.lock`;
	let ran = 0;

	// Younger than the horizon: the writer waits its budget out and fails rather than stealing.
	await writeFile(lock, "orphan-token");
	const young = new Date(Date.now() - 20);
	await utimes(lock, young, young);
	await assert.rejects(() => withMemoryLock(target, async () => { ran += 1; }, { staleMs: 5_000, waitMs: 150 }), /timed out waiting for the write lock/);
	assert.equal(ran, 0, "a lock inside the horizon is never stolen");

	// Older than the horizon: the same orphan is taken over and the write goes through.
	const old = new Date(Date.now() - 200);
	await utimes(lock, old, old);
	const result = await withMemoryLock(target, async () => { ran += 1; return "written"; }, { staleMs: 50, waitMs: 2_000 });
	assert.equal(result, "written");
	assert.equal(ran, 1, "the abandoned lock is stolen instead of failing the pass");
});

test("a lock that is gone is not a stale lock", () => {
	// `lockMtimeMs` reports 0 for a lock file that is gone. Reading that 0 as an age makes the steal
	// test true for any horizon, so a waiter whose `tryLock` failed a moment earlier enters the steal
	// branch for a lock that no longer exists; the `.steal` claim it creates makes the writer that is
	// just finishing bail out of `releaseLock` without deleting its own lock, and every later writer
	// then waits out the whole staleness horizon. Measured before this guard: 5 of 20 runs of the
	// session-index concurrency test stalled ~30.9 s (two leaks exceed its 60 s timeout).
	const now = 1_700_000_000_000;
	assert.equal(staleLockAge(0, now, 30_000), false, "a missing lock is not stealable");
	assert.equal(staleLockAge(Number.POSITIVE_INFINITY, now, 30_000), false, "an unreadable lock stays");
	assert.equal(staleLockAge(now - 29_999, now, 30_000), false, "a lock inside the horizon is not");
	assert.equal(staleLockAge(now - 30_001, now, 30_000), true, "a lock past the horizon is");
});

/** The ignore-file header the plugin owns; the tests below count occurrences of it. */
const GITIGNORE_HEADER = "# project-context: local artifacts, do not commit";

/** Count exact header lines in an ignore file's text. */
function headerCount(text) {
	return text.split(/\r?\n/).filter((line) => line.trim() === GITIGNORE_HEADER).length;
}

test("adding a line to an ignore file that already has the header does not repeat the header", async () => {
	// `MEMORY_GITIGNORE_LINES` grows as the plugin gains artifacts, and the header used to be emitted
	// with every batch that added a line. A project whose file was written before the list grew then
	// got a second copy of the comment in the middle of the file. `ensureMemoryGitignore` is cached
	// per process, so this and the sibling tests each use their own directory.
	const root = await project();
	const file = path.join(root, ".agents", "memory", ".gitignore");
	// The state a project is in just before the list grows: header present, one owned line missing.
	await writeFile(file, `${GITIGNORE_HEADER}\n*.memory-backup-*\nmy-own-note\n`);
	await ensureMemoryGitignore(path.join(root, ".agents", "memory"));
	const text = await readFile(file, "utf8");
	assert.equal(headerCount(text), 1, "exactly one header survives the batch");
	assert.match(text, /^# project-context: local artifacts, do not commit$/m, "the original header stays first");
	assert.match(text, /my-own-note/, "a hand-written line is preserved");
	assert.match(text, /errors\.log/, "the missing owned line is added");
	assert.match(text, /autolearn-state\.json/, "every missing owned line is added, not just the first");
});

test("an ignore file without the header gains it once and keeps the user's lines", async () => {
	const root = await project();
	const file = path.join(root, ".agents", "memory", ".gitignore");
	await writeFile(file, "user-line-a\nuser-line-b\n");
	await ensureMemoryGitignore(path.join(root, ".agents", "memory"));
	const text = await readFile(file, "utf8");
	assert.equal(headerCount(text), 1, "the header is emitted exactly once");
	assert.match(text, /user-line-a/);
	assert.match(text, /user-line-b/);
	assert.match(text, /errors\.log/);
});

test("a differently-cased header does not earn a second standard header", async () => {
	// Case-folded presence check: a file carrying the comment in another capitalisation is treated as
	// already headed. The accepted residual is that the file keeps its variant spelling and gains no
	// second copy of the canonical one.
	const root = await project();
	const file = path.join(root, ".agents", "memory", ".gitignore");
	await writeFile(file, `${GITIGNORE_HEADER.toUpperCase()}\n`);
	await ensureMemoryGitignore(path.join(root, ".agents", "memory"));
	const text = await readFile(file, "utf8");
	assert.equal(headerCount(text), 0, "no canonical header is appended");
	assert.equal(text.split(/\r?\n/).filter((line) => line.trim().toLowerCase() === GITIGNORE_HEADER.toLowerCase()).length, 1);
	assert.match(text, /errors\.log/, "the missing owned lines are still added");
});

test("a second call over a complete ignore file leaves it byte-identical", async () => {
	// The early return is not enough on its own: the first call must produce a file the second call
	// finds complete, or every pass would append another batch.
	const root = await project();
	const memory = path.join(root, ".agents", "memory");
	await ensureMemoryGitignore(memory);
	const file = path.join(memory, ".gitignore");
	const first = await readFile(file, "utf8");
	assert.equal(headerCount(first), 1, "the first write emits one header");
	// The early return is what makes a repeated pass a no-op, and it keys off the same list the writer
	// uses. Assert the file really is complete by that list, so a batch that forgot a line would fail
	// here instead of silently re-adding it on every pass.
	for (const owned of ["*.memory-backup-*", "errors.log", "*.lock", "*.steal", "*.broken-*", "memory.jsonl", "memory-log-*.jsonl", "memory.jsonl.*.tmp", "autolearn-state.json"]) {
		assert.ok(first.split(/\r?\n/).includes(owned), `the completed file lists ${owned}`);
	}
});

/**
 * A stored memory longer than `maxMemoryChars`, four sections deep, so that a read cap hides whole
 * sections: the Pitfalls and Index tails are what a write-back would delete.
 */
function overCapMemory(count = 16) {
	const section = (heading, tag) => [`## ${heading}`, ...Array.from({ length: count }, (_, i) => `- ${tag}${String(i).padStart(3, "0")} ${"字".repeat(90)}`)].join("\n");
	return `# Project Memory\n\n${section("Project", "PROJ")}\n\n${section("Invariants", "INV")}\n\n${section("Pitfalls", "PIT")}\n\n${section("Index", "IDX")}\n`;
}

/**
 * A pass fixture whose model re-emits exactly the view it was shown (the honest reply, not a hostile
 * one): the four-section document the prompt asks for, built only from the lines the model could see.
 */
async function viewEchoFixture(root, { efforts } = {}) {
	const calls = [];
	const ctx = {
		logger: { info() {}, warn() {} },
		llm: {
			// Opt-in, so every pre-existing caller keeps a context whose `resolveModelInfo` is missing —
			// the shape a route with no catalog answers, which is what the effort gate must tolerate.
			...(efforts === undefined ? {} : {
				async resolveModelInfo() {
					return { provider: "test-provider", id: "test-model", name: "test-model", reasoning: { efforts: efforts.map((id) => ({ id, name: id })) } };
				},
			}),
			stream(options) {
				calls.push(options);
				const prompt = options.messages[0].content.map((block) => block.text ?? "").join("\n");
				const shown = /<existing-memory>\n([\s\S]*?)\n<\/existing-memory>/.exec(prompt)[1];
				return (async function* generate() {
					const headings = ["Project", "Invariants", "Pitfalls", "Index"];
					const body = shown.split("\n").filter((line) => !/^_\[memory truncated/.test(line)).join("\n").trimEnd();
					const missing = headings.filter((heading) => !body.includes(`## ${heading}`));
					const memory = missing.length === 0 ? body : `${body}\n\n${missing.map((heading) => `## ${heading}`).join("\n\n")}\n`;
					yield { type: "text-delta", text: JSON.stringify({ memory_markdown: memory, context: { title: "t", summary: "s", key_points: [], open_tasks: [] } }) };
				})();
			},
		},
	};
	const agent = {
		options: { provider: "test-provider", model: "test-model" },
		session: { id: "session-view-echo", header: { cwd: root, createdAt: Date.now() }, snapshotEvents: () => [], deriveMessages: () => [], requestHeader: () => undefined },
	};
	return { calls, ctx, agent };
}

test("a read-capped stored memory refuses the pass instead of writing the truncation back", async () => {
	// The defect: `loadMemory` applies `maxMemoryChars` on read, so a stored document over the cap reaches
	// the model as a shortened view, and a reply built from that view replaces the whole file — tier C
	// cannot see it, because the reply fits the write cap. Measured before the gate existed: a
	// 6482-character memory under a 4000-character cap landed as a 3983-character document with the
	// Pitfalls and Index tails gone and the status reading `clipped`.
	const root = await project();
	const stored = overCapMemory();
	await writeFile(memoryFile(root), stored, "utf8");
	const loaded = await loadMemory(root, 4000);
	assert.ok(loaded.cappedDroppedChars > 0, `fixture: the cap really hides part of the document (${stored.length} stored, ${loaded.text.length} shown)`);

	const { calls, ctx, agent } = await viewEchoFixture(root);
	const config = resolvePluginConfig({ maxTokens: 8192, maxOutputTokens: 32_768, consolidateTurns: 1, maxMemoryChars: 4000 });
	const report = await consolidateProject(ctx, config, agent, { force: true, silent: true });

	assert.equal(calls.length, 0, "the gate runs before the model call: a refusal must not spend one");
	assert.equal(report.status, "read-capped-refused", JSON.stringify(report));
	assert.equal(report.memoryWritten, false, "a refusal publishes no memory");
	assert.equal(report.contextWritten, false, "and no context either");
	assert.equal(await readFile(memoryFile(root), "utf8"), stored, "MEMORY.md stays byte-identical, tail included");
	assert.equal(report.readCappedRefused?.memoryHiddenChars, loaded.cappedDroppedChars, "the refusal names this read's own cut");
	assert.equal(report.readCappedRefused?.cap, 4000, "and the cap it was measured under");
	// The lever has to be the one that applies: `maxMemoryChars` is what hides the memory.
	assert.match(memoryUpdateReply(report).text, /raise maxMemoryChars/i, memoryUpdateReply(report).text);
	const logged = await readFile(path.join(root, ".agents", "memory", "errors.log"), "utf8");
	assert.match(logged, /the consolidation pass was not run/, "a silent refusal is this repo's failure class");
	// No reply existed, so no line may attribute the missing context to one: naming "the reply's context
	// section" here would be the wrong cause for a pass that never called the model.
	assert.doesNotMatch(logged, /context section/, `the gate is not a reply's refusal: ${logged}`);
});

test("the read-cap gate is not always on: a document inside the cap still consolidates", async () => {
	// Control for the case above. Without it, a gate that refused every pass would pass the first test.
	const root = await project();
	const stored = overCapMemory();
	await writeFile(memoryFile(root), stored, "utf8");
	const { calls, ctx, agent } = await viewEchoFixture(root);
	const config = resolvePluginConfig({ maxTokens: 8192, maxOutputTokens: 32_768, consolidateTurns: 1, maxMemoryChars: MAX_MEMORY_CHARS });
	const report = await consolidateProject(ctx, config, agent, { force: true, silent: true });

	assert.equal(calls.length, 1, "nothing is hidden, so the pass runs");
	assert.equal(report.status, "updated", JSON.stringify(report));
	assert.equal(report.memoryWritten, true);
	assert.equal(report.readCappedRefused, undefined);
});

test("the context read cap refuses the same way, with its own lever", async () => {
	// `MAX_CONTEXT_CHARS` slices the stored context before the model sees it, and a reply's context
	// replaces the whole file — the same write-back, on an artifact whose cap is a constant, so the
	// receipt must advise shortening CONTEXT.md rather than raising a setting that cannot move it.
	const root = await project();
	await writeFile(memoryFile(root), "# Project Memory\n\n## Project\n- kept\n", "utf8");
	const contextDocument = `# Project Context\n\n## Summary\n\n${"录".repeat(MAX_CONTEXT_CHARS + 2000)}\n`;
	await writeFile(path.join(root, ".agents", "memory", "CONTEXT.md"), contextDocument, "utf8");

	const { calls, ctx, agent } = await viewEchoFixture(root);
	const config = resolvePluginConfig({ maxTokens: 8192, maxOutputTokens: 32_768, consolidateTurns: 1, maxMemoryChars: MAX_MEMORY_CHARS });
	const report = await consolidateProject(ctx, config, agent, { force: true, silent: true });

	assert.equal(calls.length, 0, "the gate runs before the model call");
	assert.equal(report.status, "read-capped-refused", JSON.stringify(report));
	assert.ok((report.readCappedRefused?.contextHiddenChars ?? 0) > 0, "the refusal names the context cut");
	assert.equal(report.readCappedRefused?.memoryHiddenChars, 0, "the memory was not the side that was cut");
	assert.equal(await readFile(path.join(root, ".agents", "memory", "CONTEXT.md"), "utf8"), contextDocument, "CONTEXT.md stays byte-identical");
	const receipt = memoryUpdateReply(report).text;
	assert.match(receipt, /shorten CONTEXT\.md/i, "the lever must fit the context side");
	assert.doesNotMatch(receipt, /raise maxMemoryChars/i, "and must not offer a knob that cannot raise a constant cap");
});

test("raising maxMemoryChars re-runs a cached read-cap refusal", async () => {
	// The refusal is cached like any other outcome; a cached decision is only reused while the cap it was
	// decided under still applies, which is what makes "raise the cap" a live lever rather than advice.
	const root = await project();
	const stored = overCapMemory();
	await writeFile(memoryFile(root), stored, "utf8");
	const { calls, ctx, agent } = await viewEchoFixture(root);
	const small = resolvePluginConfig({ maxTokens: 8192, maxOutputTokens: 32_768, consolidateTurns: 1, maxMemoryChars: 4000 });
	const first = await consolidateProject(ctx, small, agent, { force: true, silent: true });
	assert.equal(first.status, "read-capped-refused", JSON.stringify(first));

	const roomy = resolvePluginConfig({ maxTokens: 8192, maxOutputTokens: 32_768, consolidateTurns: 1, maxMemoryChars: MAX_MEMORY_CHARS });
	const second = await consolidateProject(ctx, roomy, agent, { force: true, silent: true });
	assert.equal(calls.length, 1, "the raised cap re-runs the pass instead of re-reporting the refusal");
	assert.equal(second.status, "updated", JSON.stringify(second));
});

test("an auxiliary call names the route's cheapest enabled reasoning effort", async () => {
	// The defect: a call that names no effort is sent as thinking-disabled, and a gateway may refuse that
	// outright. Measured on 2026-11-07 against `scnet/DeepSeek-V4.1-Flash-1017` (levels off/low/high/max):
	// 528 dsh requests that named an effort answered 200 and 31 that named none answered 400 `SCNet:
	// thinking.type=disabled cannot be translated`. The route's *lowest* level is `off`, so "the least
	// supported effort" is precisely the value that must not travel.
	const config = resolvePluginConfig({ maxTokens: 8192, maxOutputTokens: 32_768, consolidateTurns: 1, maxMemoryChars: MAX_MEMORY_CHARS });

	const root = await project();
	await writeFile(memoryFile(root), overCapMemory(), "utf8");
	const enabled = await viewEchoFixture(root, { efforts: ["off", "low", "high", "max"] });
	const report = await consolidateProject(enabled.ctx, config, enabled.agent, { force: true, silent: true });
	assert.equal(report.status, "updated", JSON.stringify(report));
	assert.equal(enabled.calls.length, 1, "one model call");
	assert.equal(enabled.calls[0].reasoningEffort, "low", "the disabled level is skipped, not sent as the cheapest");

	// Control: a route that declares no enabled level must send no effort field at all, rather than `off`.
	const offOnlyRoot = await project();
	await writeFile(memoryFile(offOnlyRoot), overCapMemory(), "utf8");
	const offOnly = await viewEchoFixture(offOnlyRoot, { efforts: ["off"] });
	const offOnlyReport = await consolidateProject(offOnly.ctx, config, offOnly.agent, { force: true, silent: true });
	assert.equal(offOnlyReport.status, "updated", JSON.stringify(offOnlyReport));
	assert.equal(offOnly.calls.length, 1, "one model call");
	assert.equal("reasoningEffort" in offOnly.calls[0], false, "a route with no enabled level carries no effort field");
});
