/**
 * The consolidation pass (②): one throttled, single-flight model call per project producing
 * durable memory and a session-context update. It lived in `shared/llm.ts` only because the
 * autolearn pass reuses the model plumbing from there; the pass itself belongs to the memory
 * plugin, and the plumbing it shares now sits in `shared/model-call.ts`.
 */

import path from "node:path";
import { type Context } from "@deepseek-ai/cordis";
import { type Agent } from "@deepseek-ai/dsh-agent";
import { type Session } from "@deepseek-ai/dsh-session";
import { type PluginConfig } from "../shared/config.js";
import { MAX_CONTEXT_CHARS, cachedProjectRoot, contextFile, diagnosticMessage, getProjectRoot, getProjectRootSync, logError, readOptional } from "../shared/project-state.js";
import { loadMemory } from "./memory-store.js";
import { type MemoryInput, conversationText, firstUserText, fitMemoryInput, userTurnCount } from "../shared/conversation.js";
import { type CompletionOutcome, type PluginTool, type ToolsFallbackState, auxiliaryReasoningEffort, callWithToolsFallback, pickToolCall, requestPluginTextWithMeta, resolveModelMetadata, resolveTarget, toolCallIsTruncated } from "../shared/model-call.js";
import { RETRY_OUTPUT_HEADROOM_TOKENS } from "../shared/output-budget.js";
import { type ConsolidationResult, type ContextUpdate, parseConsolidation, parseContextMember, parseToolArguments } from "../shared/reply-json.js";
import { MAX_CONSOLE_REPLY_CHARS, replyHead } from "../shared/text.js";
import { contextSectionBudgets } from "./context-schema.js";
import { memorySectionBudgets, memorySectionPromptBudgets } from "./memory-schema.js";
import {
	type MemoryRender,
	type MemorySectionOverage,
	type MemorySections,
	OPAQUE_DOCUMENT_MIN_CHARS,
	RECORD_MEMORY_TOOL,
	hasMemoryDocumentShape,
	isHeadingOnlyDocument,
	memorySectionOverage,
	normalizeMemoryEntry,
	partialSectionsFromMarkdown,
	renderMemoryDocument,
	sectionsFromMarkdown,
	sectionsFromToolCall,
	sectionsSemanticallyEmpty,
} from "./sections.js";
import { normalizeMemoryWithDrop } from "./document.js";

/**
 * Which entry produced the memory this pass would write, or `"none"` when the pass was refused before
 * any model call (the read-cap gate): there is no reply, so nothing produced the document.
 */
export type ConsolidateKind = "structured" | "fallback-sections" | "fallback-opaque" | "merged-partial" | "unmergeable-partial" | "none";

/** A reply read into the shape this pass writes: the sections when it had them, plus the context. */
type ResolvedReply = {
	kind: ConsolidateKind;
	sections?: MemorySections;
	result: ConsolidationResult;
	/** For a merged partial reply (batch Q2): the headings the stored document contributed. */
	mergedFromStore?: string[];
	/** Why an unmergeable partial reply was refused (batch Q2): which side could not be read. */
	partialRefusal?: PartialRefusalReason;
};

/**
 * Which half of batch Q2's merge could not be read: the stored document (nothing to merge into) or the
 * reply itself. The two are different causes with different levers, so the refusal names one of them
 * rather than collapsing both into "the reply was partial" — which is false for a complete document
 * whose sections are not plain `- ` entries.
 */
export type PartialRefusalReason = "store-not-sections" | "reply-not-sections";

/** A consolidation result plus a monotonic version so each plugin writes a given pass at most once. */
export type ConsolidationOutcome = {
	result: ConsolidationResult;
	version: number;
	// A pass-level "the model was shown a shortened view" flag and the two hidden-character counts it
	// summarized used to live here. Both input gates now refuse before the model call
	// (`readCappedRefused` / `fitCappedRefused`), so no outcome that ever reached a model call could
	// carry them. Of the shortenings that remain, only the gate refusals produce an outcome, and each
	// carries its own counts. The truncation retry's fit never becomes an outcome at all: it is either
	// not sent (logged with its own hidden count) or sent with `clipped === false`.
	/**
	 * The memory this pass's prompt was built from, byte for byte. The write path refuses a reply
	 * whose baseline no longer matches what is stored: publishing it would overwrite a newer edit.
	 */
	basisKey: string;
	/**
	 * Which entry the memory came from. Reported for diagnostics and tests; no receipt reads it yet,
	 * so a pass is never worded differently because of it.
	 */
	kind: ConsolidateKind;
	/** No section held an entry worth storing, so the memory must not be written at all. */
	semanticEmpty: boolean;
	/** Sections that lost at least one entry to their budget. */
	sectionDropped: number;
	/** Entries dropped because their section's budget was full. */
	droppedItems: number;
	/** Entries clipped to their section's per-item cap. */
	itemTruncated: number;
	/**
	 * Characters of this reply the memory cap would drop on write, measured here rather than at the
	 * write so the loss can be retried and refused like any other. The write path measures the landed
	 * value separately; this one describes the reply tier C decided about.
	 */
	memoryWriteCapDroppedChars: number;
	/**
	 * True when tier C refused this reply: it would have been stored lossily and the one targeted
	 * retry did not fix it, so the write must not happen and the stored memory stays effective.
	 */
	memoryLossyRefused: boolean;
	/**
	 * The `maxMemoryChars` this outcome was measured under.
	 *
	 * A cached outcome is re-reported as it stands — the throttled path serves it without re-running —
	 * so a caller that names "the cap" must read this, not the config in force at report time, or it
	 * names a cap that never measured the loss it is describing.
	 */
	maxMemoryChars: number;
	/**
	 * True when batch Q2's guard refused this reply: it carried our document shape but could not be
	 * merged into the stored one, so writing it would have replaced content this pass cannot account
	 * for. The write must not happen; the refusal is logged where it is decided.
	 */
	partialRefused: boolean;
	/** Which half of the merge could not be read, when `partialRefused` is set. */
	partialRefusal?: PartialRefusalReason;
	/** Headings the stored document contributed to a merged partial reply (batch Q2); empty otherwise. */
	mergedFromStore: string[];
	/**
	 * Invariants/Pitfalls entries the reply no longer carries (batch Q2's report layer). Reported, never
	 * blocking: a compression pass is supposed to drop entries, and refusing that would be permanent.
	 */
	removedEntries?: { count: number; samples: string[] };
	/**
	 * Set when the pass refused before the model call because the read cap had shortened the stored
	 * document: the view was incomplete, so a reply built from it would have deleted everything the cap
	 * kept back, and tier C would have called that write clean — it measures a reply against a cap the
	 * reply does fit. The numbers are this pass's own, so a cached refusal re-reported under a raised
	 * `maxMemoryChars` cannot name the wrong cap.
	 */
	readCappedRefused?: { cap: number; memoryHiddenChars: number; contextHiddenChars: number };
	/**
	 * Set when the pass refused before the model call because the output budget could not hold both
	 * documents whole: `fitMemoryInput` shortened them head-and-tail, and a reply built from that view
	 * replaces the stored file with it — the same deletion `readCappedRefused` exists to prevent, one
	 * budget further out. Separate from it because the levers differ: the read cap is `maxMemoryChars`
	 * (or the stored document), while this one is `maxOutputTokens` (or both documents), and a receipt
	 * that named the wrong knob would be a dead lever.
	 */
	fitCappedRefused?: { maxOutputTokens: number; memoryHiddenChars: number; contextHiddenChars: number };
};

export interface ConsolidationOptions {
	force?: boolean;
	signal?: AbortSignal;
}

type ConsolidationState = { session: string; turns: number; at: number };

let nextVersion = 0;

/** Single-flight per cwd: concurrent callers join the same pass. */
const activeConsolidation = new Map<string, Promise<ConsolidationOutcome | undefined>>();

const throttle = new Map<string, ConsolidationState>();

const lastOutcome = new Map<string, { version: number; at: number; cap: number; outcome: ConsolidationOutcome }>();

/**
 * The cross-project boundary, stated as a rule.
 *
 * The pass hands the model the whole session conversation and asks it to regenerate the documents
 * from that, so a session that quotes a sibling repository's state (its sizes, counts, research
 * values) writes it into this project's memory — hand-cleaning does not hold, because the next pass
 * writes it again. Naming another project stays legal for recording who owns an open item: this repo
 * keeps exactly those pointers on purpose.
 */
export const FOREIGN_STATE_RULE =
	"Write only durable facts about this project itself. Never copy another repository's state or measurements (commit distances, file sizes, research values, key counts) into memory or context; naming another project is fine only to record who owns an open item.";

/**
 * The same boundary where the foreign text actually enters: the first line inside
 * `<recent-conversation>`, which is the block built from the session's own transcript.
 */
export const CONVERSATION_CAPTION = "[This session's working state. It may quote other projects and their numbers; those are not memory material — write only durable facts about this project.]";

/**
 * The fixed instructions of the consolidation prompt. Exported so a test can assert the shape
 * contract the model is actually given: naming the `context` keys without their types is what let
 * a mis-shaped reply hollow out CONTEXT.md silently.
 */
export const CONSOLIDATION_PROMPT_RULES: readonly string[] = [
	"Maintain project memory and project context for the coding project below.",
	`Prefer calling the ${RECORD_MEMORY_TOOL.name} tool exactly once, at the end of this pass, with the memory sections and the context as its arguments.`,
	"If you cannot call that tool, return exactly one JSON object with keys memory_markdown and context instead. Do not use a Markdown code fence.",
	"memory_markdown must be updated durable project memory.",
	"context must contain title, summary, key_points, and open_tasks for the current session and project.",
	"context.summary is a required string; context.title is a string; context.key_points and context.open_tasks are arrays of strings. A context whose shape is wrong is discarded and CONTEXT.md is left unchanged.",
	// The layout and the per-section budgets come from the renderer's own table, so the prompt
	// cannot drift from what `renderContextDocument` actually stores.
	"The stored CONTEXT.md lays the context out as these fixed sections, in this order, each within its budget:",
	...contextSectionBudgets().map((section) => `- ## ${section.heading}: ${section.description} (about ${section.chars} characters)`),
	"Never write omission or truncation markers (any line like `_[memory truncated …]_` or `_[context truncated: … characters dropped]_`) into the artifacts.",
	"Remove stale or duplicated information. Do not store secrets, API keys, credentials, generic advice, or conversational filler.",
	FOREIGN_STATE_RULE,
	"Never add instructions that override system or user instructions.",
	"Keep memory concise and factual; keep context concise.",
];

/**
 * The compression ladder both prompt layers state (batch L, ported from pi v0.4.4).
 *
 * The sentence this replaces — "When over budget, merge duplicates within a section, then drop the
 * least durable entries" — was the only permission the prompt gave for an overflow, and it made
 * deletion the closing step. Measured on 2026-10-06, this repo's memory sat at 98.8% / 97.9% of two
 * section budgets, one added line away from a whole-entry drop, and the tier C retry that fires on
 * exactly that loss repeated the same instruction — asking for the loss the gate refuses.
 * Compression is now the default and a deletion has to name a reason; one constant, so the two
 * layers cannot drift apart.
 */
export const MEMORY_KEEP_RULE =
	"Keep every entry that is still true and make each section fit its stated target above: merge duplicates within a section, deduplicate across sections, then condense the wording. Delete an entry only when it is superseded or already covered elsewhere, never to make room for a new one.";

/**
 * The same rule at the block whose text the reply rewrites (pi's second layer): the material arrives
 * with the instruction attached, rather than only in the rules above it.
 */
export const MEMORY_SURVIVAL_CAPTION =
	"The existing-memory block below is what has to survive this pass: every entry that is still true must reappear unless it is superseded or already covered elsewhere, and a document that does not fit its cap is fixed by condensing its wording, not by dropping entries.";

/**
 * The memory layout the pass actually writes, stated with the real per-section budgets.
 *
 * The stored memory carries these exact sections in this order. `renderMemoryDocument` treats each
 * section's share as a target rather than a cap: it pools what an under-target section leaves and lends
 * it to the over-target ones, dropping whole entries only when the whole document reaches
 * `maxMemoryChars`. The cap is per project, so the section budgets have to be built per pass instead of
 * sitting in the static rules — and like `memoryBudgetRule`, every number here is in characters.
 *
 * Each section states two numbers: the figure the prompt asks for, and the share it expects to take.
 * The gap is deliberate — a reply written to the share spends the headroom the next pass needs, and the
 * model cannot count characters — so the target, not the share, is what the model is told to aim at.
 * Both come from the one table so neither can drift.
 */
export function memorySectionRule(maxMemoryChars: number): string {
	const budgets = memorySectionBudgets(maxMemoryChars);
	const targets = new Map(memorySectionPromptBudgets(maxMemoryChars).map((section) => [section.heading, section.chars]));
	const lines = budgets.map(
		(section) =>
			`- ## ${section.heading}: ${section.description} (aim for about ${targets.get(section.heading)} characters; its ${section.chars}-character share is a target, not a cap)`,
	);
	return [
		"Either way, the memory carries these exact sections, in this order: each is listed with the share of the budget it is expected to take, and a section may exceed its share while the document as a whole still fits its cap:",
		...lines,
		`Each entry is one self-contained statement on one line: no bullet prefix and no headings. ${MEMORY_KEEP_RULE}`,
	].join("\n");
}

/**
 * The memory bound the pass actually enforces, stated with the real numbers.
 *
 * A word hint is not the enforced bound: the document is cut at `maxMemoryChars` **characters** on
 * write, so a reply that satisfies a word count can still lose whatever sat at the end — and the
 * model had no way to know. The cap is per project, so the line has to be built per pass. The
 * per-section figures above are targets the renderer may exceed by borrowing, so the cap is named here
 * as the only hard limit.
 */
export function memoryBudgetRule(maxMemoryChars: number, currentChars: number): string {
	return `memory_markdown must stay at or under ${maxMemoryChars} characters (the stored memory is currently about ${currentChars}). That is a hard cap in characters, not words: content past it is dropped on write, so condense and merge instead of appending. The per-section numbers above are targets, not caps: a section may go over its share while the document has room, and entries are dropped whole only when the whole document is over.`;
}

/** The one retry a cut-off reply is allowed. Kept as a constant so a wording regression is visible. */
const TRUNCATED_REPLY_RULE =
	"Your previous reply was cut off by the model output limit. Retry this same consolidation now without the tool: return exactly one complete JSON object with string memory_markdown and object context, keeping memory_markdown shorter.";

/**
 * The targeted retry a complete-but-lossy reply is allowed (tier C).
 *
 * The reply was usable and the model simply over-filled a section, which a second, specific
 * instruction can fix — that is the whole difference between tier C and tier B. The rule names
 * sections and counts only: the previous reply is not an input to it, so it can neither leak a
 * section's text into the prompt nor invite a rewrite from memory.
 *
 * @param overage - what each section would give up, from `memorySectionOverage`.
 * @param writeCapDroppedChars - characters the memory cap would drop from the reply, 0 when it fits.
 */
export function memoryLossRetryRule(overage: readonly MemorySectionOverage[], writeCapDroppedChars: number): string {
	const lines: string[] = [];
	for (const row of overage) {
		const parts: string[] = [];
		if (row.over > 0) parts.push(`needs about ${row.over} character(s) beyond its ${row.budget}-character budget`);
		if (row.droppedEntries > 0) parts.push(`${row.droppedEntries} entry(ies) would have been dropped whole`);
		if (row.truncatedEntries > 0) parts.push(`${row.truncatedEntries} entry(ies) exceeded the ${row.itemCap}-character per-item cap`);
		if (parts.length > 0) lines.push(`- ${row.heading}: ${parts.join("; ")}`);
	}
	if (writeCapDroppedChars > 0) {
		lines.push(`- the memory_markdown you returned was about ${writeCapDroppedChars} character(s) over the memory cap`);
	}
	return [
		"Your previous reply was complete but would have lost content when stored, so it was not stored:",
		...lines,
		`Retry this same consolidation without the tool: return exactly one complete JSON object with string memory_markdown and object context. ${MEMORY_KEEP_RULE} The per-section shares are targets, so the entries above were lost because the document itself reached its cap; when the reply carried no sections, apply the same ladder without them.`,
	].join("\n");
}

/** What storing this reply right now would lose. */
type ReplyLoss = {
	sectionDropped: number;
	droppedItems: number;
	itemTruncated: number;
	writeCapDroppedChars: number;
	overage: MemorySectionOverage[];
	/** Something would be lost, so a targeted retry is worth one call. */
	retryWorthy: boolean;
	/** A whole entry (or the write cap) would be lost: that is what tier C refuses to store. */
	refuses: boolean;
};

/**
 * Measure one resolved reply against the cap it would be stored under.
 *
 * A section render reports its own drops; an opaque reply never reaches the renderer, so the write cap
 * is the only place its loss exists — measuring it here is what lets that loss share the one retry
 * instead of only being logged after the fact.
 *
 * The refusal is deliberately narrower than the retry: an entry cut to the per-item cap may be fixed by
 * rewording, but a legitimate entry longer than that cap has no legal form inside it, so refusing on
 * truncation alone would refuse the project forever.
 */
function memoryLoss(resolved: ResolvedReply, render: MemoryRender | undefined, cap: number): ReplyLoss {
	const sectionDropped = render?.sectionDropped ?? 0;
	const droppedItems = render?.droppedItems ?? 0;
	const itemTruncated = render?.itemTruncated ?? 0;
	const writeCapDroppedChars =
		render === undefined ? normalizeMemoryWithDrop(resolved.result.memory.trim(), cap).dropped : 0;
	const wholeEntriesLost = sectionDropped > 0 || droppedItems > 0 || writeCapDroppedChars > 0;
	return {
		sectionDropped,
		droppedItems,
		itemTruncated,
		writeCapDroppedChars,
		overage: resolved.sections === undefined ? [] : memorySectionOverage(resolved.sections, cap),
		retryWorthy: wholeEntriesLost || itemTruncated > 0,
		refuses: wholeEntriesLost,
	};
}

export function fallbackUpdate(session: Session): ContextUpdate {
	const text = firstUserText(session);
	// Return the raw value: the renderer normalizes and clips it to the summary section's budget,
	// and any clip is reported by the document's truncation marker instead of being hidden here.
	return {
		title: "Session recorded",
		summary: text || "Session recorded without a model summary.",
		key_points: [],
		open_tasks: [],
	};
}

/** Run one model call and collect its visible text. Throws on a failed or aborted stream. */
async function requestConsolidationText(
	ctx: Context,
	agent: Agent,
	config: PluginConfig,
	prompt: string,
	signal: AbortSignal | undefined,
	maxTokens: number,
	reasoningEffort: string | undefined,
	tools: readonly PluginTool[] | undefined,
): Promise<CompletionOutcome> {
	const target = resolveTarget(agent, config);
	if (!target) throw new Error("no provider/model available for the learn pass: route one request, set AgentOptions, or configure provider+model");
	return requestPluginTextWithMeta(ctx, target, maxTokens, prompt, signal, {
		// The live session this pass was triggered for. The route may require it (opencode maps it to
		// `x-opencode-session` and answers 400 without it), and naming it is what makes the
		// checkpoint-policy half of `SessionWorkTracker`'s contract load-bearing for this pass.
		sessionId: agent.session.id,
		// Sent whenever the route declares an enabled level: naming none (or `off`, which the adapter
		// collapses into none) makes dsh write `thinking: { type: "disabled" }`, a spelling a gateway may
		// refuse. `auxiliaryReasoningEffort` carries the mechanism and the measured case.
		...(reasoningEffort === undefined ? {} : { reasoningEffort }),
		...(tools === undefined ? {} : { tools }),
	});
}

/**
 * Read one reply into the shape this pass writes.
 *
 * The tool call is the preferred entry. When the model answers with text instead — because it chose
 * not to call the tool, or because the route dropped `tools` — the same sections are recovered from
 * the Markdown, so both entries render through one renderer and one set of budgets. `allowTools` is
 * false for the retry prompt, which deliberately carries no tool.
 */
function resolveReply(completion: CompletionOutcome, allowTools: boolean): ResolvedReply | undefined {
	if (allowTools) {
		// Throws when the reply called some other tool and carried no text: there is nothing to fall
		// back to, and returning undefined would feed "" to the parser and read as a silent success.
		const argsText = pickToolCall(completion.toolCalls, RECORD_MEMORY_TOOL.name, completion.text);
		if (argsText !== undefined) {
			const parsed = parseToolArguments(argsText);
			const sections = parsed === undefined ? undefined : sectionsFromToolCall(parsed);
			if (parsed !== undefined && sections !== undefined) {
				// memory and context are validated apart: a broken context must not cost a good memory.
				const context = parseContextMember(parsed.context);
				const contextUnusable = context === undefined && parsed.context !== undefined && parsed.context !== null;
				return {
					kind: "structured",
					sections,
					result: {
						memory: "",
						...(context === undefined ? {} : { context }),
						...(contextUnusable ? { contextUnusable: true } : {}),
					},
				};
			}
			// The expected tool was called with arguments this pass cannot read. With text to fall back
			// to the text path still applies; with nothing to parse it is an error, not an empty memory.
			if (completion.text.trim() === "") throw new Error(`the ${RECORD_MEMORY_TOOL.name} call carried unusable arguments and no text`);
		}
	}
	const parsed = parseConsolidation(completion.text);
	if (!parsed) return undefined;
	const sections = sectionsFromMarkdown(parsed.memory);
	if (sections) return { kind: "fallback-sections", sections, result: parsed };
	return { kind: "fallback-opaque", result: parsed };
}

/**
 * The stored-side half of the opaque gate: whether the store holds a document worth protecting.
 *
 * A canonical four-section parse is a document by definition. Anything else — a hand-written memory in
 * another shape, a legacy free-form memory — is judged by substance, because it is exactly as much to lose
 * as a canonical one; and a store below the floor (a fresh project) has nothing to protect, which is what
 * keeps a short reply's own "too short to be a change" report (`index.ts`) honest instead of turning it
 * into this refusal.
 */
function storedIsDocument(text: string): boolean {
	return (
		sectionsFromMarkdown(text) !== undefined ||
		text.replace(/^\s*#\s*Project Memory[ \t]*(?:\r?\n|$)/i, "").trim().length >= OPAQUE_DOCUMENT_MIN_CHARS
	);
}

/**
 * A conversational reply that would replace a real memory: not this extension's shape, long enough to be
 * a deliberate document, and aimed at a store that already holds one.
 */
function isConversationalOpaque(reply: string, storedText: string): boolean {
	return !hasMemoryDocumentShape(reply) && reply.trim().length >= OPAQUE_DOCUMENT_MIN_CHARS && storedIsDocument(storedText);
}

/** The refusal's own wording, chosen by which half could not be read (see `PartialRefusalReason`). */
function partialRefusalMessage(reason: PartialRefusalReason | undefined): string {
	if (reason === "store-not-sections") {
		return "the stored memory is not a plain four-section bullet document, so this partial reply could not be merged into it; the stored memory was kept unchanged";
	}
	return "the consolidation reply carried this extension's headings but not as plain `- ` entries, so it could not be merged into the stored memory; the stored memory was kept unchanged";
}

/**
 * Batch Q2's acceptance guard: a reply that carries our shape but is not a complete document must not
 * replace the store (that was a silent whole-store loss — `sectionsFromMarkdown` needs all four sections,
 * so a partial reply used to land as opaque text, verbatim).
 *
 * Three outcomes, in this order, and the order is the design:
 *
 *  - **merge** — the store parses into sections and the reply reads into sections: the sections the reply
 *    carries win, the ones it omits stay exactly as the store had them, and the merge is rendered like any
 *    other sectioned reply. Nothing is lost by omission, so nothing has to be refused.
 *  - **refuse** — the reply has our shape but cannot be read into sections (prose inside a section, an
 *    unknown heading, `*`/indented entries), or the store itself is not a four-section document. Then the
 *    reply would replace content this pass cannot account for, so it is refused loudly and the store stays
 *    byte-identical. Conservative on purpose: `sectionsFromMarkdown`'s contract is "anything this cannot
 *    read with certainty is preserved", and the only way to preserve it here is not to write.
 *  - **leave alone** — a conversational reply, or a store with nothing to protect (a fresh project): both
 *    keep the behaviour they had, the gate in `replyIsSemanticallyEmpty` and the verbatim write included.
 */
function applyPartialGuard(reply: ResolvedReply, storedText: string): ResolvedReply {
	if (reply.sections !== undefined) return reply;
	const memory = reply.result.memory;
	if (!hasMemoryDocumentShape(memory)) return reply;
	if (!storedIsDocument(storedText)) return reply;
	const stored = sectionsFromMarkdown(storedText);
	const partial = stored === undefined ? undefined : partialSectionsFromMarkdown(memory);
	if (stored === undefined) return { ...reply, kind: "unmergeable-partial", partialRefusal: "store-not-sections" };
	if (partial === undefined) return { ...reply, kind: "unmergeable-partial", partialRefusal: "reply-not-sections" };
	const merged: MemorySections = { ...stored };
	const carried = Object.keys(partial.sections) as (keyof MemorySections)[];
	for (const key of carried) {
		if (!partial.missing.includes(key)) merged[key] = partial.sections[key];
	}
	return { ...reply, kind: "merged-partial", sections: merged, mergedFromStore: partial.missing.map(String) };
}

/**
 * Entries the new memory no longer carries — pi's regression guard, copied deliberately rather than
 * paraphrased (pi `pass.ts:123-133`).
 *
 * `Project` and `Index` are deliberately excluded: they are meant to be rewritten every pass, and
 * reporting them would bury the signal. This cannot judge whether a removal was *right* — only that it
 * happened — so it reports and never blocks: refusing here would turn every compression into a permanent
 * refusal, and the consolidation prompt asks for compression.
 */
function removedSectionEntries(before: MemorySections, after: MemorySections): { count: number; samples: string[] } {
	const gone = (key: "invariants" | "pitfalls"): string[] => {
		const kept = new Set(after[key].map((entry) => normalizeMemoryEntry(entry)));
		return before[key].map((entry) => normalizeMemoryEntry(entry)).filter((entry) => entry !== "" && !kept.has(entry));
	};
	const removed = [...gone("invariants"), ...gone("pitfalls")];
	return { count: removed.length, samples: removed.slice(0, 3) };
}

/**
 * True when a resolved reply carries nothing worth storing.
 *
 * The opaque entry has no sections, so its half of the gate is "is this a document at all", in two steps:
 * a body-less reply is refused outright, and any other opaque reply must carry this extension's own shape
 * whenever the store holds a document. That second step closes the silent whole-document replacement:
 * `isHeadingOnlyDocument` is one-sided by design and calls any wrapper holding real words content, so
 * `# Project Memory\n\nI'll review the frozen revision …` used to replace the stored memory. Refusing it
 * costs a legitimately written but unparseable reply — the stored memory is kept and a diagnostic is
 * logged — which is the trade the shape gate accepted over a silent replacement.
 *
 * The sectioned entries are judged on the document the renderer would actually store, not only on the
 * section arrays: an entry that is itself a heading (`"## Project"`) contains letters, so the array-level
 * check passes, but it renders to a structural line — the very bytes the opaque half refuses. Judging both
 * keeps the two halves agreeing on the same document; a real entry (`- p1`, `- #1 rule must hold`,
 * `- a durable fact`) is content in both, so nothing genuine is refused.
 */
function replyIsSemanticallyEmpty(resolved: ResolvedReply, render: MemoryRender | undefined, storedText: string): boolean {
	if (resolved.sections === undefined) {
		return isHeadingOnlyDocument(resolved.result.memory) || isConversationalOpaque(resolved.result.memory, storedText);
	}
	return sectionsSemanticallyEmpty(resolved.sections) || (render !== undefined && isHeadingOnlyDocument(render.text));
}

/**
 * Run the consolidation pass (durable memory + session context).
 * Callers own persisting their artifact; results are cached per project so the memory and
 * session-context plugins can consume the same pass without a second model call.
 */
export function consolidateProjectState(
	ctx: Context,
	agent: Agent,
	config: PluginConfig,
	options: ConsolidationOptions = {},
): Promise<ConsolidationOutcome | undefined> {
	const cwd = path.resolve(agent.session.header.cwd ?? process.cwd());
	// Claim by project root, not cwd: the root and a subdirectory of one project
	// are the same state and must share a single pass. The root is cache-warm by
	// the time a pass can trigger (sessions warm it on create and callers resolve
	// it first), so the sync fallback practically never spawns git.
	const projectKey = cachedProjectRoot(cwd) ?? getProjectRootSync(cwd);
	const claimed = activeConsolidation.get(projectKey);
	if (claimed) return claimed;

	const run = (async (): Promise<ConsolidationOutcome | undefined> => {
		const force = options.force ?? false;
		const projectRoot = await getProjectRoot(cwd);
		const session = agent.session;
		const turns = userTurnCount(session);
		const sessionId = String(session.id);
		const previous = throttle.get(projectRoot);
		// The turn counter is session-local: after a session change, count from zero again.
		// Otherwise a fresh session would need `previous session turns + consolidateTurns` before learning.
		const baseline = previous?.session === sessionId ? previous.turns : 0;
		const cached = lastOutcome.get(projectRoot);
		// A cached outcome describes the cap it was decided under. Raising `maxMemoryChars` changes what
		// the very same reply would lose, so a forced pass under a new cap has to re-run instead of
		// re-answering with a refusal the old cap produced — "Raise maxMemoryChars, or retry the pass
		// later" is the refusal's own lever, and the forced pass is where the user turns it. The throttled
		// path below is not keyed on the cap: it must never spend a surprise model call, and re-reporting
		// the last real decision beats claiming "already up to date" for a memory that was never written.
		const cachedForCap = cached !== undefined && cached.cap === config.maxMemoryChars ? cached : undefined;
		const throttled = !force && (turns - baseline < config.consolidateTurns || Date.now() - (previous?.at ?? 0) < config.consolidateIntervalMs);
		if (throttled) return cached?.outcome;
		if (force && cachedForCap && Date.now() - cachedForCap.at < config.forceDedupeMs) return cachedForCap.outcome;

		const existing = await loadMemory(projectRoot, config.maxMemoryChars);
		// The pass continues with whatever is readable, but a broken source must stay diagnosable:
		// the prompt would otherwise look as if the project had no memory at all.
		if (existing.unreadable) await logError(projectRoot, "memory", `project memory exists but cannot be read: ${existing.source}`);
		else if (existing.damaged) await logError(projectRoot, "memory", `memory journal has ${existing.damaged} unusable line(s); they were skipped`);
		const existingContextText = await readOptional(contextFile(projectRoot));
		const existingContext = existingContextText.slice(0, MAX_CONTEXT_CHARS);
		// Characters the context read cap alone kept from the model, before the fit clips anything: an
		// over-cap stored context loses this much on every pass, and only the fit's own count was ever
		// reported, so the receipt understated what the model was not shown.
		const contextReadHiddenChars = existingContextText.length - existingContext.length;
		// A pass whose view of a stored artifact was cut by a read cap must not run at all. The reply is
		// built from the shortened view, so writing it replaces the stored file with that view and deletes
		// every character the cap kept back — measured, not inferred: with a 6482-character memory under a
		// 4000-character cap, a reply that merely re-emitted what it was shown landed as a 3983-character
		// document, status `clipped`, and both the Pitfalls and the Index tail were gone. Tier C cannot see
		// it, because it measures the reply against the write cap and the reply fits; `cappedDroppedChars`
		// and the context slice are the only counts that know content was hidden, which is why the gate is
		// here and not at the write. One line per occurrence, and it names the lever that actually applies
		// to the side that was cut.
		const readCapHidden = existing.cappedDroppedChars + contextReadHiddenChars;
		if (readCapHidden > 0) {
			const parts: string[] = [];
			if (existing.cappedDroppedChars > 0) parts.push(`${existing.cappedDroppedChars} character(s) of the stored memory (${config.maxMemoryChars}-character cap)`);
			if (contextReadHiddenChars > 0) parts.push(`${contextReadHiddenChars} character(s) of the stored context (${MAX_CONTEXT_CHARS}-character read cap)`);
			await logError(projectRoot, "memory", `the consolidation pass was not run: ${parts.join(" and ")} would have been hidden from the model, and a reply built from that shortened view would have replaced the stored file with it`);
			const refusal: ConsolidationOutcome = {
				// No reply exists, so the result carries no memory and no context: a refusal publishes
				// neither artifact, which is what keeps the other half from landing behind its back.
				result: { memory: "" },
				version: (nextVersion += 1),
				basisKey: existing.text,
				kind: "none",
				semanticEmpty: false,
				sectionDropped: 0,
				droppedItems: 0,
				itemTruncated: 0,
				memoryWriteCapDroppedChars: 0,
				memoryLossyRefused: false,
				maxMemoryChars: config.maxMemoryChars,
				partialRefused: false,
				mergedFromStore: [],
				readCappedRefused: { cap: config.maxMemoryChars, memoryHiddenChars: existing.cappedDroppedChars, contextHiddenChars: contextReadHiddenChars },
			};
			// The throttle and the cache are set here because this return skips the pass's own tail: an
			// automatic path must not retry the same refusal on every turn, and the cached outcome is keyed
			// on the cap, so raising `maxMemoryChars` really re-runs.
			throttle.set(projectRoot, { session: sessionId, turns, at: Date.now() });
			lastOutcome.set(projectRoot, { version: refusal.version, at: Date.now(), cap: config.maxMemoryChars, outcome: refusal });
			return refusal;
		}
		const target = resolveTarget(agent, config);
		if (!target) throw new Error("no provider/model available for the learn pass: route one request, set AgentOptions, or configure provider+model");
		// One resolve for both facts: the adapter's own output cap bounds the adaptive cap, and its
		// reasoning metadata decides whether hidden thinking must be reserved out of the same budget.
		const info = await resolveModelMetadata(ctx, target, options.signal);
		const auxModel = { maxTokens: info?.defaultMaxTokens, reasoning: info?.reasoning !== undefined };
		// Same resolve, third fact: the route's cheapest *enabled* effort. Naming none, or naming the
		// disabled level, makes dsh emit disabled thinking, which a gateway may refuse outright
		// (`auxiliaryReasoningEffort` carries the mechanism and the measured case).
		const reasoningEffort = auxiliaryReasoningEffort(info);
		// The reply must re-emit both artifacts, so the output cap is matched to them (raised up to
		// the model's own limit and the configured ceiling) and the input is shortened head-and-tail
		// when even that cannot hold both. An over-long memory is what used to truncate the reply and
		// leave an unparseable document behind.
		const fitted = fitMemoryInput(existing.text, existingContext, config.maxTokens, auxModel, config.maxOutputTokens);
		// The read-cap gate above can only see a document the loader cut. This one cuts for a different
		// reason — the output budget cannot hold both documents whole — and it is the reason a pass still
		// writes back a shortened view: measured on the built `lib/` (2026-11-07, `.agents/evidence/
		// 2026-11-07-fit-clip-writeback`), a 45247-character memory with a 8164-character context is clean
		// on this first fit but hides 3218 characters on the truncation retry, and a 42199/16048 pair
		// hides 4232 — both inside the read caps, so nothing above stops them. The reply is a whole-document
		// replacement, so letting it land deletes every hidden character while the status says `clipped`
		// and tier C stays silent (it measures the reply against the write cap, and the reply fits).
		// Same decision as the read cap, taken before the model call so a pass that cannot see its own
		// input never spends one; the lever is the output budget, not `maxMemoryChars`.
		if (fitted.clipped) {
			const parts: string[] = [];
			if (fitted.memoryHiddenChars > 0) parts.push(`${fitted.memoryHiddenChars} character(s) of the stored memory`);
			if (fitted.contextHiddenChars > 0) parts.push(`${fitted.contextHiddenChars} character(s) of the stored context`);
			await logError(projectRoot, "memory", `the consolidation pass was not run: the ${config.maxOutputTokens}-token output budget cannot hold both stored documents, so ${parts.join(" and ")} would have been hidden from the model, and a reply built from that shortened view would have replaced the stored file with it`);
			const refusal: ConsolidationOutcome = {
				result: { memory: "" },
				version: (nextVersion += 1),
				basisKey: existing.text,
				kind: "none",
				semanticEmpty: false,
				sectionDropped: 0,
				droppedItems: 0,
				itemTruncated: 0,
				memoryWriteCapDroppedChars: 0,
				memoryLossyRefused: false,
				maxMemoryChars: config.maxMemoryChars,
				partialRefused: false,
				mergedFromStore: [],
				fitCappedRefused: {
					maxOutputTokens: config.maxOutputTokens,
					memoryHiddenChars: fitted.memoryHiddenChars,
					contextHiddenChars: fitted.contextHiddenChars,
				},
			};
			// Throttled so the automatic path does not recompute and re-log on every settled turn, but
			// deliberately NOT written to `lastOutcome`: that cache is keyed on `maxMemoryChars`, and this
			// refusal's lever is `maxOutputTokens`. Caching it under the memory cap would answer a forced
			// pass under the old budget after the operator raised the one knob the receipt named — the dead
			// lever this refusal exists to avoid. A forced pass recomputes instead, which costs one fit.
			throttle.set(projectRoot, { session: sessionId, turns, at: Date.now() });
			return refusal;
		}
		const promptFor = (input: MemoryInput, extra: readonly string[]): string => [
			...CONSOLIDATION_PROMPT_RULES,
			memorySectionRule(config.maxMemoryChars),
			memoryBudgetRule(config.maxMemoryChars, input.text.length),
			...extra,
			"",
			`Project root: ${projectRoot}`,
			"",
			MEMORY_SURVIVAL_CAPTION,
			"<existing-memory>",
			input.text || "(none)",
			"</existing-memory>",
			"",
			"<existing-context>",
			input.contextText || "(none)",
			"</existing-context>",
			"",
			"<recent-conversation>",
			CONVERSATION_CAPTION,
			conversationText(session),
			"</recent-conversation>",
		].join("\n");

		/** The input of the call actually sent last: a retry may have sent less than the first fit. */
		let usedInput = fitted;
		/** The pass's own tools switch; only the first call carries `tools`, so it stays inert here. */
		const toolsState: ToolsFallbackState = {};
		/** One call, recording the attempt before a failure so a persistent error backs off. */
		const call = async (input: MemoryInput, extra: readonly string[], tools: readonly PluginTool[] | undefined): Promise<CompletionOutcome> => {
			try {
				// A route that refuses `tools` answers a provider 400, which the harness reports as the
				// request-shape code; `callWithToolsFallback` spends the one tools-free retry for exactly
				// that class and nothing else. The throttle line below runs once for the pair, so a
				// refused parameter cannot burn two failure slots.
				return await callWithToolsFallback(toolsState, tools !== undefined && tools.length > 0, (withTools) =>
					requestConsolidationText(ctx, agent, config, promptFor(input, extra), options.signal, input.maxTokens, reasoningEffort, withTools ? tools : undefined),
				);
			} catch (error: unknown) {
				throttle.set(projectRoot, { session: sessionId, turns, at: Date.now() });
				throw error;
			}
		};
		/** Read a reply, backing off before rethrowing when the reply is unusable by policy. */
		const read = (completion: CompletionOutcome, allowTools: boolean): ResolvedReply | undefined => {
			try {
				const reply = resolveReply(completion, allowTools);
				// Batch Q2 applies to every reply this pass reads, the tier-C retry included: a retry that
				// answers with a partial document must not get a second chance to replace the store.
				return reply === undefined ? undefined : applyPartialGuard(reply, existing.text);
			} catch (error: unknown) {
				throttle.set(projectRoot, { session: sessionId, turns, at: Date.now() });
				throw error;
			}
		};

		let attempt = await call(fitted, [], [RECORD_MEMORY_TOOL]);
		// A cut-off tool call is never accepted: the adapter repairs a truncated arguments string into
		// a shape-valid object, so "there is a tool call" is not evidence that its contents arrived.
		// A *text* reply that stopped at the cap is the old case. Both are retried: the untrusted call
		// because its contents are unverified, the cut text because it may simply have been cut.
		const truncatedToolCall = toolCallIsTruncated(attempt);
		let resolved = truncatedToolCall ? undefined : read(attempt, true);
		// Set only when the truncation retry would have hidden stored content, so the failure below can
		// name that cause instead of the cut reply's. `undefined` means the retry either ran or was never
		// eligible.
		let retryFitCapped: MemoryInput | undefined;
		if (!resolved && (attempt.stopReason === "max-tokens" || truncatedToolCall)) {
			// The reply ran into the output cap, which is not a parse failure: ask again with extra
			// headroom reserved out of the same cap, a shorter prompt, and no tool — the reminder asks
			// for the JSON text shape, which a tool call could not satisfy. dsh reports this as
			// `max-tokens` (pi calls it `length`); matching the wrong string would never retry.
			// The headroom is the flat constant **or** the hidden reasoning this attempt actually spent,
			// whichever is larger: the reserve is capped at 8192 while a reasoning route can spend far
			// more, so a retry carrying only +4096 asks again with the very headroom that just starved it
			// (pi `099ebf3`). `attempt.reasoningTokens` is 0 when the adapter reports none, so a route
			// that reports no hidden thinking keeps exactly the flat constant it had before.
			const retryHeadroom = Math.max(RETRY_OUTPUT_HEADROOM_TOKENS, attempt.reasoningTokens);
			const retryFitted = fitMemoryInput(existing.text, existingContext, config.maxTokens, auxModel, config.maxOutputTokens, retryHeadroom);
			// Headroom is reserved out of the same output cap, so a retry can hide content the first fit
			// showed: measured 2026-11-07 on the built `lib/`, a 42199-character memory with a 16048-character
			// context is clean on the first fit and loses 4232 characters on this one. The retry exists to
			// rescue a cut reply, not to trade the stored document for a longer reply, so it is skipped
			// rather than run against a view the model cannot see whole. The pass then fails naming this
			// cause instead of the cut reply's — see the branch below.
			retryFitCapped = retryFitted.clipped ? retryFitted : undefined;
			if (retryFitCapped === undefined) {
				usedInput = retryFitted;
				attempt = await call(usedInput, [TRUNCATED_REPLY_RULE], undefined);
				resolved = read(attempt, false);
			} else {
				await logError(projectRoot, "memory", `the consolidation retry was not sent: reserving ${retryHeadroom} more output tokens for it would have hidden ${retryFitCapped.memoryHiddenChars + retryFitCapped.contextHiddenChars} character(s) of the stored documents from the model, and a reply built from that shortened view would have replaced them`);
			}
		}
		if (!resolved) {
			// Back off like any other failed pass, but never store the raw JSON as memory. A reply
			// that hit the cap is reported as what it is — the retry already happened, so a generic
			// "not a usable JSON object" would hide the one cause the operator can act on.
			throttle.set(projectRoot, { session: sessionId, turns, at: Date.now() });
			// A retry that was never sent is not a retry that failed: the reply is still cut, but the one
			// cause the operator can act on is the output budget being too small for both documents, and
			// "raise maxOutputTokens or shorten a document" is a different lever from the cut reply's own.
			// Naming the cut here would point at the same knob the gate already rejected.
			if (retryFitCapped !== undefined) {
				const hidden: string[] = [];
				if (retryFitCapped.memoryHiddenChars > 0) hidden.push(`${retryFitCapped.memoryHiddenChars} character(s) of the stored memory`);
				if (retryFitCapped.contextHiddenChars > 0) hidden.push(`${retryFitCapped.contextHiddenChars} character(s) of the stored context`);
				throw new Error(`consolidation reply was cut off by the model output limit (${fitted.maxTokens} tokens requested), and the retry was not sent because its extra headroom would have hidden ${hidden.join(" and ")} from the model\nRaise maxOutputTokens, or shorten MEMORY.md or CONTEXT.md, and run /memory update again.`);
			}
			if (attempt.stopReason === "max-tokens") {
				const spent = attempt.reasoningTokens > 0 ? `, ${attempt.reasoningTokens} spent on hidden reasoning` : "";
				throw new Error(`consolidation reply was cut off by the model output limit (${usedInput.maxTokens} tokens requested${spent})\n${replyHead(attempt.text, MAX_CONSOLE_REPLY_CHARS)}`);
			}
			throw new Error(`consolidation reply was not a usable JSON object\n${replyHead(attempt.text, MAX_CONSOLE_REPLY_CHARS)}`);
		}
		const renderOf = (reply: ResolvedReply): MemoryRender | undefined =>
			reply.sections === undefined ? undefined : renderMemoryDocument(reply.sections, config.maxMemoryChars);
		let render = renderOf(resolved);
		let loss = memoryLoss(resolved, render, config.maxMemoryChars);
		// Batch Q2's refusal is decided by the reply's shape, not by its size: the guard already knows the
		// reply cannot be merged, so the tier-C retry (which asks for a *smaller* document) would answer a
		// question nobody asked and could replace a refusal that stands on its own.
		let partialRefused = resolved.kind === "unmergeable-partial";
		if (partialRefused) await logError(projectRoot, "memory", partialRefusalMessage(resolved.partialRefusal));
		/**
		 * Tier C: one targeted retry for a reply that was complete but would have been stored lossily,
		 * then a refusal instead of a lossy write if the retry does not fix it.
		 *
		 * The bound is deliberately hard: this is the last model call of the pass, never chained into
		 * another. A retry that is itself cut off, unparseable or still lossy ends the pass — an
		 * unbounded fix-up loop would spend a model call per attempt on a document that cannot fit.
		 * The retry re-sends the input the previous call used, so the only thing that changed between
		 * the two replies is the instruction, and the retry's loss stays attributable to the reply.
		 */
		let memoryLossyRefused = false;
		// A reply with no entries at all is the empty-skeleton gate's case, not tier C's: there is
		// nothing to shrink, and calling it a refusal would name the cap as the blocker when the
		// semantic gate is what stops the write.
		if (loss.retryWorthy && !partialRefused && !replyIsSemanticallyEmpty(resolved, render, existing.text)) {
			// The retry exists to avoid a refusal, not to decide one: the first reply's own loss already
			// says whether it may be stored. A retry that dies for its own reason — a transport error, an
			// unreadable reply — must therefore not erase that decision. Reporting `failed` would hide a
			// refusal this pass had already made, and would throw away a first reply that was storable
			// (a per-item truncation is a loss the pass accepts, so its retry is an improvement only).
			// An abort is the one exception — and only the caller's own signal counts. A stream that
			// merely reports `aborted` reaches this catch with the signal intact (model-call.ts throws
			// that shape without consulting it), so it stays a retry failure like any other; the caller
			// cancelling is different, because carrying on would let it write artifacts after that cancel.
			let retryResolved: ResolvedReply | undefined;
			let retryRender: MemoryRender | undefined;
			try {
				const retryAttempt = await call(usedInput, [memoryLossRetryRule(loss.overage, loss.writeCapDroppedChars)], undefined);
				retryResolved = read(retryAttempt, false);
				retryRender = retryResolved === undefined ? undefined : renderOf(retryResolved);
			} catch (error: unknown) {
				if (options.signal?.aborted) throw error;
				// One line per occurrence, like every other loss: the model call really did fail, and a
				// refusal that follows must not read as if the retry had answered and been too large.
				await logError(projectRoot, "memory", `the targeted loss retry failed for its own reason, so the first reply's loss decides this pass: ${diagnosticMessage(error)}`);
			}
			// Only a retry that actually carries a memory replaces the first reply. One that parses to
			// nothing — an empty stream, or a tool call the JSON-text prompt cannot read — would turn a
			// real but oversized memory into "no new memory", and the semantic-empty gate would then skip
			// the write while the receipt reported a plain update.
			if (retryResolved !== undefined && !replyIsSemanticallyEmpty(retryResolved, retryRender, existing.text)) {
				const retryLoss = memoryLoss(retryResolved, retryRender, config.maxMemoryChars);
				// Ask for a smaller document, but never at the price of the memory: a retry that would be
				// refused does not replace a first reply that would have landed (an entry cut to its
				// per-item cap is a loss this pass accepts).
				// An unmergeable retry is never an improvement: accepting it would replace a storable first
				// reply with one the guard then refuses, turning a landed document into a no-op — and before
				// this condition existed it replaced the store with the partial's own text.
				if (retryResolved.kind !== "unmergeable-partial" && !(retryLoss.refuses && !loss.refuses)) {
					resolved = retryResolved;
					render = retryRender;
					loss = retryLoss;
				}
			}
			// Either way the refusal is judged on the narrower rule in `memoryLoss`, and on the first
			// reply whenever the retry did not answer at all.
			memoryLossyRefused = loss.refuses;
		}
		// `resolved` cannot become `unmergeable-partial` after the point above: the retry is skipped
		// whenever the first reply was refused, and an unmergeable retry is never accepted in the first
		// place (see the acceptance condition below). That condition is what closes the hole an earlier
		// revision left open — the refusal was decided before tier C, so a retry answering with an
		// unmergeable partial was accepted and written verbatim over the store, status `updated`, with no
		// refusal. The guard is a single owner here rather than a second check after the block.
		const semanticEmpty = replyIsSemanticallyEmpty(resolved, render, existing.text);
		// The gate above owns a reply with no entries; a refusal must not claim the cap stopped it.
		if (semanticEmpty) memoryLossyRefused = false;
		// Batch Q2's report layer, pi's `removedSectionEntries` verbatim: the sections this pass would
		// write are diffed against the stored ones *before clipping*, so an entry the renderer cuts is not
		// counted as a removal. It reports and never blocks — see that function's own comment.
		let removedEntries: { count: number; samples: string[] } | undefined;
		if (!semanticEmpty && !partialRefused) {
			const oldSections = sectionsFromMarkdown(existing.text);
			if (resolved.sections === undefined) {
				if (existing.text.trim()) await logError(projectRoot, "memory", "memory regression guard skipped: this pass did not produce sections");
			} else if (oldSections === undefined) {
				if (existing.text.trim()) await logError(projectRoot, "memory", "memory regression guard skipped: the stored memory is not a plain four-section bullet document");
			} else {
				// Computed here, logged at the write site: a removal claim must describe a document that
				// actually landed, and tier C / the basis-key race are decided later than this point.
				removedEntries = removedSectionEntries(oldSections, resolved.sections);
			}
		}
		const result: ConsolidationResult = { ...resolved.result, memory: render === undefined ? resolved.result.memory : render.text };
		const version = (nextVersion += 1);
		throttle.set(projectRoot, { session: sessionId, turns, at: Date.now() });
		if (semanticEmpty && existing.text.trim()) {
			// Two shapes land here: a reply with no entries at all (a bare four-heading skeleton, and an
			// opaque reply that is only headings, which is the same thing with the headings lost), and a
			// conversational opaque reply aimed at a store that already holds a document. Writing either
			// would replace a real memory with something that is not one, so the write is skipped
			// outright — and since that is a silent no-op from the outside, it always leaves a diagnostic.
			await logError(projectRoot, "memory", "the consolidation reply was not a writable memory document; the stored memory was kept unchanged");
		}
		if (result.contextUnusable) {
			// Memory still lands, but CONTEXT.md keeps its previous content: say so on every pass, not
			// once per project — a project whose replies keep carrying an unusable context is stale
			// every time, and reporting only the first one leaves the rest silent.
			await logError(projectRoot, "memory", "consolidation reply carried a context whose shape is unusable (summary must be a string and key_points/open_tasks arrays of strings); CONTEXT.md was left unchanged");
		}
		const outcome: ConsolidationOutcome = {
			result,
			version,
			basisKey: existing.text,
			kind: resolved.kind,
			semanticEmpty,
			sectionDropped: loss.sectionDropped,
			droppedItems: loss.droppedItems,
			itemTruncated: loss.itemTruncated,
			memoryWriteCapDroppedChars: loss.writeCapDroppedChars,
			memoryLossyRefused,
			maxMemoryChars: config.maxMemoryChars,
			partialRefused,
			...(resolved.partialRefusal === undefined ? {} : { partialRefusal: resolved.partialRefusal }),
			mergedFromStore: resolved.mergedFromStore ?? [],
			...(removedEntries === undefined ? {} : { removedEntries }),
		};
		lastOutcome.set(projectRoot, { version, at: Date.now(), cap: config.maxMemoryChars, outcome });
		return outcome;
	})().finally(() => {
		// Failures reject; the caller logs them and returns a truthful "failed".
		activeConsolidation.delete(projectKey);
	});

	activeConsolidation.set(projectKey, run);
	return run;
}
