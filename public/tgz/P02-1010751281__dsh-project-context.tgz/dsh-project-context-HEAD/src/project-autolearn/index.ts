/**
 * project-autolearn — the skill-distillation feature (pass ③).
 *
 * Low-frequency pass over `.agents/memory/CONTEXT.md` + `MEMORY.md` plus the
 * mechanical session index; when those documents lack the concrete steps it
 * backtracks into the archived sessions named by the index, reading each one's
 * canonical `session.jsonl` rather than its rendered `session.md`. Output is
 * `.agents/skills/<name>/SKILL.md`; dsh discovers skills natively, so only the
 * description enters the prompt while the body loads on demand.
 *
 * Commands: /autolearn
 */

import path from "node:path";
import type { Context } from "@deepseek-ai/cordis";
// Type-only: pulls the commands service Context merge (ctx.commands).
import type {} from "@deepseek-ai/dsh-commands";
import type { Agent } from "@deepseek-ai/dsh-agent";
import { resolvePluginConfig, type PluginConfig } from "../shared/config.js";
import { effectivePluginConfig } from "../shared/settings.js";
import { isTopLevel, projectCwd, SerialQueue, SessionWorkTracker } from "../shared/lifecycle.js";
import { approveCandidate, listCandidates, rejectCandidate } from "./candidate.js";
import { autolearnProjectSkills, type AutolearnOutcome } from "./pass.js";
import { diagnosticMessage, getProjectRoot, logError, skillsDir } from "../shared/project-state.js";

export const name = "project-autolearn";
export const inject = ["llm", "commands"];

/** Serialize passes so a forced command waits for an in-flight automatic one. */
const updates = new SerialQueue();

interface RunOptions {
	force: boolean;
	silent: boolean;
	signal?: AbortSignal | undefined;
	/**
	 * Hand the pass's write segments to the caller's durability tracker.
	 *
	 * The pass registers only segments that await no model call: its auxiliary call names a live
	 * session, so a registration spanning that call would make the call's own checkpoint flush await
	 * the call it is dispatching (`SessionWorkTracker`).
	 */
	track?: ((work: Promise<unknown>) => void) | undefined;
}

/** Run one pass; the outcome is kept for command reporting while the queue only sees void. */
function runAutolearn(ctx: Context, config: PluginConfig, agent: Agent, options: RunOptions): Promise<AutolearnOutcome | undefined> {
	let outcome: AutolearnOutcome | undefined;
	return updates.run(async () => {
		const projectRoot = await getProjectRoot(projectCwd(agent.session));
		try {
			outcome = await autolearnProjectSkills(ctx, agent, config, { force: options.force, signal: options.signal, track: options.track });
			if (outcome?.candidate && !options.silent) {
				ctx.logger.info(`dsh-project-context: skill candidate saved for review: /autolearn approve ${outcome.skill?.name ?? ""}`);
			} else if (outcome?.skill && !options.silent) {
				ctx.logger.info(`dsh-project-context: project skill created: ${path.join(skillsDir(projectRoot), outcome.skill.name, "SKILL.md")}`);
			}
		} catch (error) {
			await logError(projectRoot, "autolearn", error);
			if (!options.silent) ctx.logger.warn(`dsh-project-context: autolearn failed: ${diagnosticMessage(error)}`);
		}
	}).then(() => outcome);
}

export function apply(ctx: Context, rawConfig: unknown): void {
	const entry = resolvePluginConfig(rawConfig);
	/** In-flight autolearn work per session, awaited by durability flushes. */
	const pending = new SessionWorkTracker();

	ctx.on("agent/status", ({ agent, status }) => {
		if (status !== "idle" || !isTopLevel(agent.session)) return;
		const current = effectivePluginConfig(entry);
		if (!current.autolearnEnabled) return;
		// Only the pass's write segments reach the tracker (`SessionWorkTracker`); the span itself is
		// observed here so a rejection stays as invisible as it was when the tracker carried it.
		void runAutolearn(ctx, current, agent, { force: false, silent: false, track: (work) => pending.track(agent.session, work) }).catch(() => undefined);
	});

	ctx.on("agent/disposed", ({ agent }) => {
		if (!isTopLevel(agent.session)) return;
		const current = effectivePluginConfig(entry);
		if (!current.autolearnEnabled) return;
		// Silent: the UI may already be rebuilding for a session switch.
		void runAutolearn(ctx, current, agent, { force: false, silent: true, track: (work) => pending.track(agent.session, work) }).catch(() => undefined);
	});

	ctx.on("session/flush", (session) => pending.flush(session));

	ctx.commands.register({
		name: "autolearn",
		description: "Distill a project skill from memory, context, and archived sessions; also: list | approve <name> | reject <name>",
		input: { hint: "list | approve <name> | reject <name>" },
		handler: async ({ agent, rawInput, signal }) => {
			const parts = (rawInput ?? "").trim().split(/\s+/).filter(Boolean);
			const verb = (parts[0] ?? "").toLowerCase();
			const projectRoot = await getProjectRoot(projectCwd(agent.session));
			if (verb === "list") {
				const names = await listCandidates(projectRoot);
				return names.length > 0
					? { kind: "success" as const, text: `Skill candidates: ${names.join(", ")} (/autolearn approve <name>)` }
					: { kind: "success" as const, text: "No skill candidates." };
			}
			if (verb === "approve") {
				const result = await approveCandidate(projectRoot, parts[1]);
				return result.ok ? { kind: "success" as const, text: result.message } : { kind: "error" as const, text: result.message };
			}
			if (verb === "reject") {
				const result = await rejectCandidate(projectRoot, parts[1]);
				return result.ok ? { kind: "success" as const, text: result.message } : { kind: "error" as const, text: result.message };
			}
			const outcome = await runAutolearn(ctx, effectivePluginConfig(entry), agent, { force: true, silent: false, signal });
			if (outcome === undefined) return { kind: "error", text: "Autolearn did not run (no provider/model, or the pass failed; see errors.log)." };
			if (outcome.candidate && outcome.skill) {
				return { kind: "success", text: `Skill candidate "${outcome.skill.name}" saved for review — /autolearn approve ${outcome.skill.name}` };
			}
			return outcome.skill
				? { kind: "success", text: `Skill created: ${outcome.skill.name}` }
				// Report the actual cause instead of "No new skill was warranted", which asserted the
				// model proposed nothing. That claim is false on three reachable paths: an admission
				// rule refused a real proposal, the pass skipped the model call entirely, or the
				// model answered with an unusable payload. Each gets its own sentence; only the last
				// one talks about the model, and it says only what is verifiable.
				: outcome.rejected !== undefined
					? { kind: "success", text: `Skill rejected: ${outcome.rejected}. Nothing was written; adjust the project material or the skill shape and run /autolearn again.` }
					: outcome.skipped !== undefined
						? { kind: "success", text: `No skill was considered: ${outcome.skipped}.` }
						: { kind: "success", text: "No new skill was created: the model's answer contained no usable skill." };
		},
	});
}
