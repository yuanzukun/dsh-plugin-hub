/**
 * Reading the session: the rendered split a handoff drops, the pending question it
 * may have to carry, the file index beside the prompt, and the language of the messages.
 *
 * Pure functions over a `Session`; nothing here talks to the host or the model.
 */

import { type Session } from "@deepseek-ai/dsh-session";
import { type PluginConfig } from "../shared/config.js";
import { conversationMessageSections, conversationMessages, humanUserText, type ConversationSection } from "../shared/conversation.js";
import { clipTitle, truncateMiddle } from "../shared/text.js";
import { MAX_CONVERSATION_CHARS } from "../shared/project-state.js";
import { type HandoffLanguage, type HandoffLanguageMessage, REPLAY_MARKER, isHandoffContinuationText, resolveLanguage } from "./language.js";

/** Rough character budget per token for the carried-over recent tail. */
export const CHARS_PER_TOKEN = 3.5;

/** Phrasings that mark the assistant's last message as awaiting a user decision. */
const PENDING_QUESTION_PATTERNS =
	/would you like|shall i\b|should i\b|do you want|let me know|your call|which (?:one|option|approach|direction|do you)|please (?:confirm|choose|decide)|awaiting your|waiting for your|需要我|要不要|是否需要|是否要|请你(?:确认|选择|决定)|等你(?:确认|回复|决定)/i;

function messageText(content: readonly { type: string; text?: string }[]): string {
	return content
		.filter((block) => block.type === "text" && typeof block.text === "string")
		.map((block) => block.text as string)
		.join("\n")
		.trim();
}

/** Exported for tests: whether an assistant message ends in a question. */
export function textAsksQuestion(text: string): boolean {
	// Fenced code must not contribute a stray "?" to the check.
	const clean = text.replace(/```[\s\S]*?```/g, " ");
	const lines = clean.split("\n").map((line) => line.trim()).filter((line) => line.length > 0);
	const lastLine = lines.length > 0 ? lines[lines.length - 1] : "";
	const stripped = lastLine.replace(/[*_`~)\]"'）】》]+$/g, "").trimEnd();
	if (stripped.endsWith("?") || stripped.endsWith("？")) return true;
	return PENDING_QUESTION_PATTERNS.test(clean.slice(-400));
}

/**
 * The question the session is waiting on, when its last conversational message is an assistant
 * question. Exported for tests, and this is the definition `auto.ts`'s `defer` gate has always used:
 * every user-role message counts as the last conversational one, injected context included, so an
 * injected block after a question means "no pending question" here, exactly as it did before the
 * decision carry existed.
 *
 * {@link handoffCarry} deliberately does NOT reuse this notion: it compares the last assistant
 * question against the user's own last input, because it must never present an answered question as
 * open. The two can disagree when an injected user-role block follows an open question — this rule
 * then reports no pending question while the carry still reports the question, which is the safe
 * direction: the child waits for the user instead of re-asking.
 */
export function pendingQuestion(session: Session): string | undefined {
	const { conversational } = readSessionInputs(session);
	if (conversational === undefined || conversational.role !== "assistant") return undefined;
	return textAsksQuestion(conversational.text) ? conversational.text : undefined;
}

/** The tool whose result carries a user's choice, and the only one whose call/result pair is read. */
const ASK_USER_QUESTION = "ask_user_question";

/** One prompt the model asked through `ask_user_question`, as the call recorded it. */
interface AskedQuestion {
	/** The question's own id, which ties it to one entry of the result's `answers`. */
	readonly id: string;
	readonly question: string;
	readonly options: readonly string[];
}

/** One question of a carried decision, with the answer the result supplied for it. */
export interface UserDecisionEntry {
	readonly question: string;
	readonly options: readonly string[];
	/** Labels the user picked; empty when they typed an answer instead. */
	readonly selected: readonly string[];
	/** Text the user typed instead of picking a label; empty when they picked. */
	readonly custom: string;
}

/**
 * The user's own last input, whichever channel carried it.
 *
 * A decision reaches a session two ways and both were lost the same way: the user types a message
 * (`kind: "message"`), or they answer `ask_user_question`, which lands as a *tool result* rather than
 * a user message (`kind: "answer"`). Reading only the tool channel misses plain conversation; reading
 * only text blocks of user messages misses an answer and any decision the summary prose dropped.
 * `handoffBudgetRecentTokens: 0` leaves no verbatim tail, so this is the only carrier that survives
 * independently of that budget.
 *
 * "Input" is meant strictly: a question the user skipped and the timed tool's `pending` placeholder
 * are not inputs and produce no decision at all (see {@link decisionEntries}).
 */
export interface UserDecision {
	readonly kind: "message" | "answer";
	/** The user's own words for `kind: "message"`; empty for an answer. */
	readonly text: string;
	/** The questions the user actually answered; empty for a message, and never empty for an answer. */
	readonly entries: readonly UserDecisionEntry[];
}

/**
 * Parse an `ask_user_question` call's `arguments`. `undefined` when the payload is not the expected
 * shape, so an unreadable call carries nothing instead of a guess.
 */
function askedQuestions(argumentsText: string): readonly AskedQuestion[] | undefined {
	let parsed: unknown;
	try {
		parsed = JSON.parse(argumentsText);
	} catch {
		return undefined;
	}
	const questions = (parsed as { questions?: unknown } | null)?.questions;
	if (!Array.isArray(questions)) return undefined;
	const asked: AskedQuestion[] = [];
	for (const entry of questions) {
		const record = entry as { id?: unknown; question?: unknown; options?: unknown } | null;
		const question = typeof record?.question === "string" ? record.question.trim() : "";
		const id = typeof record?.id === "string" ? record.id : String(asked.length);
		const options = Array.isArray(record?.options)
			? record.options
					.map((option) => (typeof (option as { label?: unknown } | null)?.label === "string" ? (option as { label: string }).label : ""))
					.filter((label) => label.length > 0)
			: [];
		asked.push({ id, question, options });
	}
	return asked.length > 0 ? asked : undefined;
}

/** One answered question, as the result's `answers` entry records it. */
interface GivenAnswer {
	readonly id: string;
	readonly selected: readonly string[];
	readonly custom: string;
}

/**
 * Parse an `ask_user_question` result's answer batch.
 *
 * Upstream defines exactly two result shapes: `{answers:[{id,selected,custom?}]}` (one item per
 * question) and, in the opt-in timed mode, `{pending:true,callId,message}`. Only the first carries an
 * answer, and this returns `undefined` for anything else — including the timed `pending` placeholder,
 * whose `message` must never be mistaken for something the user said. A selection arrives as
 * `selected` and a free-form answer as `custom`; both are read, because a carrier that dropped
 * `custom` would lose exactly the replies a user bothered to write out.
 */
function givenAnswers(text: string): readonly GivenAnswer[] | undefined {
	let parsed: unknown;
	try {
		parsed = JSON.parse(text);
	} catch {
		return undefined;
	}
	const answers = (parsed as { answers?: unknown } | null)?.answers;
	if (!Array.isArray(answers)) return undefined;
	const given: GivenAnswer[] = [];
	for (const entry of answers) {
		const record = entry as { id?: unknown; selected?: unknown; custom?: unknown } | null;
		const id = typeof record?.id === "string" ? record.id : String(given.length);
		const selected = Array.isArray(record?.selected)
			? record.selected.filter((label): label is string => typeof label === "string" && label.length > 0)
			: [];
		const custom = typeof record?.custom === "string" ? record.custom.trim() : "";
		given.push({ id, selected, custom });
	}
	return given.length > 0 ? given : undefined;
}

/**
 * Pair each asked question with the answer recorded for it, dropping the questions the user did not
 * answer.
 *
 * The tool documents `answers` as "one item per question", so POSITION is the contract and a matching
 * `id` confirms it; the id is only a fallback, and only while it is unambiguous. Looking the id up
 * first would let one answer answer every question that repeats that id, and the blocking tool does
 * not require unique ids — only the opt-in timed one validates them.
 *
 * A skipped question arrives as `selected: []` with no `custom` ("the user explicitly skipped this
 * question"), which is not something the user said; it is dropped rather than rendered as an answer,
 * so an all-skipped batch carries nothing at all. An unreadable result is likewise not an answer: it
 * may be the timed form's `{pending:true, …}` notice, and printing that notice as the user's own
 * words is exactly the misattribution this repo treats as its worst defect.
 */
function decisionEntries(asked: readonly AskedQuestion[], rawResult: string): readonly UserDecisionEntry[] {
	const answers = givenAnswers(rawResult) ?? [];
	const entries: UserDecisionEntry[] = [];
	asked.forEach((question, index) => {
		const at = answers[index];
		const unambiguousId =
			answers.filter((entry) => entry.id === question.id).length === 1 && asked.filter((other) => other.id === question.id).length === 1;
		const answer =
			at !== undefined && at.id === question.id ? at : unambiguousId ? answers.find((entry) => entry.id === question.id) : undefined;
		if (answer === undefined) return;
		if (answer.selected.length === 0 && answer.custom.length === 0) return;
		entries.push({ question: question.question, options: question.options, selected: answer.selected, custom: answer.custom });
	});
	return entries;
}

/** What one pass over the derived messages found, and where it sat. */
interface SessionInputs {
	/** The last conversational message, for {@link pendingQuestion}'s own definition. */
	readonly conversational: { readonly role: string; readonly text: string; readonly index: number } | undefined;
	/** The last assistant message whose text asks a question, and its position. */
	readonly question: { readonly text: string; readonly index: number } | undefined;
	/** The user's own last input, whichever channel carried it. */
	readonly decision: UserDecision | undefined;
	/** Position of `decision`, or -1 when there is none. */
	readonly decisionIndex: number;
}

/**
 * One pass over the transcript's messages, in order. See {@link UserDecision} for why this exists.
 *
 * Positions are kept, not just the winners: the user's last input and an open question can both be
 * present, and which of them owns the continuation's closing depends on which came last. The question
 * is tracked on its own axis rather than as "the last conversational message", because an injected
 * user-role block arriving after an open question would otherwise look like it superseded it.
 *
 * Read from the **append-origin** log, like {@link handoffSplit}, and for the same reason: what a
 * successor is told was said must not depend on what a compaction left on the model-visible surface.
 * The surface can shadow an `ask_user_question` call while its answer stays in the retained tail, and
 * a checkpoint user-role node then counts as the newest user turn — two ways for the same defect, a
 * deferral gate that reads a different conversation than the tail it guards. The cost of the log read
 * is that a *replaced* assistant reply still reads here, which is the safe direction: a question the
 * model really asked is carried, never the summary that stood in for it.
 */
function readSessionInputs(session: Session): SessionInputs {
	const asked = new Map<string, readonly AskedQuestion[]>();
	let conversational: { role: string; text: string; index: number } | undefined;
	let question: { text: string; index: number } | undefined;
	let decision: UserDecision | undefined;
	let decisionIndex = -1;
	let index = 0;
	for (const message of conversationMessages(session, "append-origin")) {
		const at = index;
		index += 1;
		if (message.role === "assistant") {
			for (const block of message.content) {
				if (block.type !== "tool-call" || block.name !== ASK_USER_QUESTION) continue;
				const questions = askedQuestions(block.arguments);
				if (questions !== undefined) asked.set(block.id, questions);
			}
			const text = messageText(message.content);
			if (text.length > 0) {
				conversational = { role: "assistant", text, index: at };
				if (textAsksQuestion(text)) question = { text, index: at };
			}
			continue;
		}
		if (message.role === "tool") {
			// A failed invocation is not an answer. Carrying its error text as the user's own words
			// would be the misattribution this repo treats as its worst defect class, so an errored
			// result contributes nothing and any earlier real input stays the carried decision.
			if (message.isError === true) continue;
			const questions = asked.get(message.toolCallId);
			if (questions === undefined) continue;
			const entries = decisionEntries(questions, messageText(message.content));
			// Nothing was answered — a skipped batch, the timed form's `pending` notice, or an
			// unreadable result — so the user said nothing and this channel records no decision.
			if (entries.length === 0) continue;
			decision = { kind: "answer", text: "", entries };
			decisionIndex = at;
			continue;
		}
		if (message.role !== "user") continue;
		const text = messageText(message.content);
		if (text.length === 0) continue;
		// `conversational` counts every user-role message — injected context and the handoff's own
		// banner included — because that is exactly what {@link pendingQuestion} has always counted.
		// Only the decision below skips them, so the carrier never hands the child our own prompt back
		// as something the user said. The asymmetry is deliberate and observable: a session whose last
		// message is an injected context block has no question to defer on, exactly as before.
		conversational = { role: "user", text, index: at };
		if (message.source.kind !== "user" || isHandoffContinuationText(text)) continue;
		decision = { kind: "message", text, entries: [] };
		decisionIndex = at;
	}
	return { conversational, question, decision, decisionIndex };
}

/**
 * What the continuation carries. At most one block owns the closing, so the seed can never tell the
 * child both "wait for the user" and "the user has already decided".
 */
export interface HandoffCarry {
	/** The assistant question still awaiting an answer, when it is the newest of the two. */
	readonly pending?: string;
	/** The user's own last input, when it is the newest of the two. */
	readonly decision?: UserDecision;
}

/**
 * The current state to carry into the continuation. Exported for tests.
 *
 * The newest of the user's own last input and the last assistant question wins, compared by position
 * on their own axes. A fixed precedence cannot do this job: an answered `ask_user_question` leaves
 * the assistant's asking text as the last conversational message, so a question that outranked the
 * answer would tell the child to wait for something the user already supplied — while a question
 * asked *after* an answer is genuinely newer and must not be dropped for the older input.
 *
 * `pendingEnabled` is the `handoffPendingQuestion: "wait"` opt-in. With `defer` no question is carried
 * here, because the automatic path defers the whole handoff instead (`auto.ts`) and only a manual
 * `/handoff now` reaches this with the opt-in off; a question newer than the user's input then carries
 * nothing at all, rather than the superseded input under a "do not ask again" closing.
 */
export function handoffCarry(session: Session, pendingEnabled: boolean): HandoffCarry {
	const { question, decision, decisionIndex } = readSessionInputs(session);
	if (question !== undefined && question.index > decisionIndex) {
		return pendingEnabled ? { pending: question.text } : {};
	}
	if (decision !== undefined) return { decision };
	return pendingEnabled && question !== undefined ? { pending: question.text } : {};
}

/**
 * Characters of the parent's own input kept in the child's title.
 *
 * The service caps a title at 80 UTF-8 bytes (`maxTitleBytes`) and clips silently, so the budget is
 * really bytes, not characters: the 15-byte prefix plus a 20-character label is at most 75 bytes,
 * because even an all-CJK label is 3 bytes per character and the trailing `…` is one of the 20, not an
 * extra one. A longer label would be cut by the service instead of by us, mid-word and at a cut we
 * never chose.
 */
const HANDOFF_LABEL_CHARS = 20;

/**
 * The label a handoff puts after `HANDOFF_TITLE_PREFIX`, or the parent's short id when it has none.
 *
 * The prefix is the browser half's switch signal, so it is fixed; only this part is ours. A message
 * the user actually typed is the most useful thing to name the continuation after, and it is already
 * in the session — so the handoff stays model-free. Two filters, and the second is not redundant:
 * `source.kind === "user"` drops the injected runtime-context snapshots, this plugin's own seed
 * banner and a subagent's messages, which each carry their own kind; `isHandoffContinuationText`
 * drops that same banner arriving as a *human* message, which is how seeding wrote it before
 * `perform.ts` stopped using the RPC that hardcodes `kind: "user"`. Those legacy banners are real,
 * and titling a continuation after the session its own parent was continued from is worse than
 * titling it after the parent's id. These are the same two filters the other readers of "what the
 * user said" apply ({@link readSessionInputs}, `humanUserText`).
 *
 * The loop deliberately is not `readSessionInputs(...).decision`: an `ask_user_question` answer
 * *replaces* that decision with an entry carrying no text of its own, while a title is better served
 * by the last thing the person typed even when they then answered a question. A session with no typed
 * input at all keeps the id — the title is never empty, which `rename()` would refuse. What the
 * service *stores* is its own normalized form, so that the prefix survives it is checked after the
 * call rather than assumed — see `retitleAfterRename` in `perform.ts`; a label with no visible
 * character never reaches the service at all, see {@link hasVisibleText}.
 * The label names the continuation after the parent's **last human input**, and it reads that input
 * from the append-origin log for the same reason {@link handoffSplit} does: a compaction that
 * summarizes the user's instruction (realistic — one sentence followed by a long tool span can fall
 * out of the retained window) leaves only the checkpoint node on the surface, whose `source.kind` is
 * not `user`. The filter below would then skip every candidate and fall back to the parent id, so the
 * seed would quote the user's words while its own title said `↪ handoff · 9f3c1a2b`.
 * @param session - the session being handed off.
 * @param fallback - the parent's short id, used when the session carries no human input.
 * @returns the label, without the prefix.
 */
export function handoffLabel(session: Session, fallback: string): string {
	let last = "";
	for (const message of conversationMessages(session, "append-origin")) {
		if (message.role !== "user" || message.source.kind !== "user") continue;
		const text = messageText(message.content);
		if (text.length === 0 || isHandoffContinuationText(text)) continue;
		last = text;
	}
	if (last.length === 0) return fallback;
	const label = clipTitle(last, HANDOFF_LABEL_CHARS);
	return hasVisibleText(label) ? label : fallback;
}

/**
 * Whether a label says anything a reader can see.
 *
 * This is a policy about our labels, not a copy of the title service's cleaner: controls (`\p{Cc}`),
 * invisible formatters (`\p{Cf}`: zero-width spaces and joiners, bidi controls, a soft hyphen, a BOM)
 * and whitespace all render as nothing, so a label made only of them names no session. It runs before
 * the write, so the class never produces the prefix-less intermediate title the service would store.
 * The class is deliberately wider than what the service strips — its directional-control list plus most
 * C0/C1, whitespace collapsed, the end trimmed — because it keeps the rest (a soft hyphen, ZWNJ/ZWJ and
 * other `\p{Cf}` code points), so withholding those is policy rather than preservation. What this test
 * cannot see is an escape sequence: its introducer (`\u001B`/`\u009B`/`\u009D`) is in the class but the
 * body is printable, and the service swallows the whole sequence — caught after the call by
 * `retitleAfterRename` in `perform.ts`.
 * @param label - a clipped, single-line label.
 * @returns true when at least one character of it is not a control, an invisible formatter or whitespace.
 */
export function hasVisibleText(label: string): boolean {
	return /[^\p{Cc}\p{Cf}\s]/u.test(label);
}

/**
 * The first input that may name a continuation, with the seq of the log event that carried it.
 *
 * {@link handoffLabel} names a fresh continuation after its *parent's* last input, which is all the
 * handoff has at that moment; this is the deferred half, read once the continuation itself has been
 * talked to. Both apply the same judgments — `source.kind === "user"`, `isHandoffContinuationText`,
 * {@link hasVisibleText} — and differ only in which end of the conversation they read.
 *
 * Two deliberate choices, both in service of a rewrite that happens exactly once with no process
 * state (see `relabel.ts`). The messages are read from the **durable log** through {@link humanUserText}
 * rather than from `deriveMessages()`: a compaction replaces surface nodes, so a derived first message
 * can vanish and the "first" input would quietly become a different one — the log keeps it, and it is
 * what the host's own title readers fold. And the input's own `seq` comes back with the label, so the
 * caller can require the event that carried it to be the one being handled; the *stored* title is the
 * service's normalized form, so comparing titles could never be a fixed point for a label it rewrites.
 *
 * The judgments are the shared ones and are not re-applied here: `humanUserText` already selects a
 * human `user/message` and rejects a generated continuation banner, and {@link hasVisibleText} decides
 * the rest. An input whose clip names nothing is skipped rather than ending the search, so an invisible
 * first message does not consume the continuation's single chance at a label.
 * @param session - the continuation.
 * @returns the label without the prefix plus its `user/message` seq, or `undefined` while nothing names it.
 */
export function firstHandoffInput(session: Session): { seq: number; label: string } | undefined {
	for (const event of session.snapshotEvents()) {
		const text = humanUserText(event);
		if (text === undefined || text.length === 0) continue;
		const label = clipTitle(text, HANDOFF_LABEL_CHARS);
		if (hasVisibleText(label)) return { seq: event.seq, label };
	}
	return undefined;
}

/**
 * File index from tool calls (read/write/edit), mirroring pi's compaction file tracking.
 *
 * Read from the append-origin log rather than the surface. A compaction shadows the span it
 * summarized, so every `read`/`write`/`edit` call inside that span would leave the index — the
 * successor would be handed "what this session touched" minus everything it did early on, which is
 * the misattribution this repo treats as its worst defect class. pi avoided the same loss by
 * cancelling the compaction before it happened; dsh has no cancellable pre-compaction hook, but it
 * does keep the log, and upstream names append-origin events as a transcript's durable source.
 * @param session - the session being handed off.
 * @returns the `<read-files>` / `<modified-files>` blocks, or `""` when no call qualifies.
 */
export function fileOperations(session: Session): string {
	const read = new Set<string>();
	const modified = new Set<string>();
	for (const message of conversationMessages(session, "append-origin")) {
		if (message.role !== "assistant") continue;
		for (const block of message.content) {
			if (block.type !== "tool-call") continue;
			if (block.name !== "read" && block.name !== "write" && block.name !== "edit") continue;
			let parsed: unknown;
			try {
				parsed = JSON.parse(block.arguments);
			} catch {
				continue;
			}
			const file = (parsed as { path?: unknown } | null)?.path;
			if (typeof file !== "string" || file.length === 0) continue;
			if (block.name === "read") read.add(file);
			else modified.add(file);
		}
	}
	const readOnly = [...read].filter((file) => !modified.has(file)).sort();
	const sections: string[] = [];
	if (readOnly.length > 0) sections.push(`<read-files>\n${readOnly.join("\n")}\n</read-files>`);
	if (modified.size > 0) sections.push(`<modified-files>\n${[...modified].sort().join("\n")}\n</modified-files>`);
	return sections.join("\n\n");
}

/** Raw user-source messages for `auto` language resolution. */
function languageMessagesOf(sections: readonly ConversationSection[]): HandoffLanguageMessage[] {
	const messages: HandoffLanguageMessage[] = [];
	for (const section of sections) {
		if (section.userText === undefined || section.sourceKind === undefined) continue;
		messages.push({ role: "user", sourceKind: section.sourceKind, text: section.userText });
	}
	return messages;
}

/**
 * Raw messages of a whole session, for a status read that does not split it.
 *
 * The same **append-origin** source {@link handoffSplit} feeds the `auto` decision from, so the
 * language a receipt names is the language the seed was rendered in. Reading the surface here let a
 * compaction summarize away every message in the user's own language: the detector samples the whole
 * conversation ({@link languageSamples}), the checkpoint that replaced the span is not the user's text
 * (`sourceKind` filters it out), so the receipt could report `en` while the seed carried Chinese.
 */
export function sessionLanguageMessages(session: Session): HandoffLanguageMessage[] {
	return languageMessagesOf(conversationMessageSections(session, "append-origin"));
}

/** A previous continuation prompt is replaced in place, keeping the message order around it. */
function replaySection(section: ConversationSection): string {
	if (section.userText !== undefined && isHandoffContinuationText(section.userText)) {
		return `## user\n${REPLAY_MARKER}`;
	}
	return section.rendered;
}

export interface HandoffSplit {
	/** The older part, dropped from the continuation and reachable only through the session log. */
	older: string;
	/** The recent tail carried verbatim; stale continuation prompts are already marked. */
	tail: string;
	/** Raw user messages of both parts, for `auto` language resolution. */
	languageMessages: HandoffLanguageMessage[];
	/**
	 * True when at least one carried section was cut at its render cap, so the tail is not that
	 * conversation verbatim. The seed reads it to choose between the "verbatim" and "trimmed" carry
	 * statements (pi's `carryKept` / `carryTrimmed`); `false` for an empty tail, which gets the
	 * "nothing was carried" statement instead.
	 */
	trimmedTail: boolean;
}

/**
 * Split of the rendered conversation for a handoff. Works from `conversationMessageSections` so it
 * can (a) replace a recognized continuation prompt in the carried tail with {@link REPLAY_MARKER}
 * and (b) hand `auto` detection the unclipped text, since the rendered section cuts user text at
 * 4000 characters — shorter than a real continuation, which would hide its closing line.
 *
 * The section list is read from **append-origin** events, not the model-visible surface. This is the
 * dsh-native answer to pi's `session_before_compact` cancel: pi stopped the compaction from running
 * so the handoff could carry an intact branch, while dsh cannot cancel one and does not need to — the
 * log is append-only and a compaction's checkpoint is itself a surface *replacement*, so reading
 * append-origin events renders the summarized span and drops the summary that stood in for it.
 * Reading the surface here would hand the successor a compressed branch as if it were the
 * conversation, which is exactly the wrong-cause defect this repo treats as its worst.
 * @param session - the session being handed off.
 * @param keepChars - characters of the most recent messages to carry verbatim; `0` carries no tail.
 * @returns the older span, the verbatim tail and whether that tail was clipped at a render cap.
 */
export function handoffSplit(session: Session, keepChars: number): HandoffSplit {
	const sections = conversationMessageSections(session, "append-origin");
	let start = sections.length;
	if (keepChars > 0) {
		let used = 0;
		while (start > 0) {
			const size = sections[start - 1].rendered.length + 2;
			if (used > 0 && used + size > keepChars) break;
			used += size;
			start -= 1;
		}
	}
	// The cut lands between whole messages, so the tail may exceed the budget by at most the one
	// message this loop is forced to keep (`used > 0`). That floor is also why the pi fix
	// "cut mid-turn so one huge turn cannot block the handoff" (pi 093dbf3) has no dsh counterpart:
	// pi pulled the cut back to a turn start and could leave nothing to drop, while every
	// rendered section here is clipped to 4000 chars (`conversationMessageSections`), far below a
	// realistic keep budget, so a session larger than the budget always leaves an older span —
	// only a conversation that genuinely fits the window has none (the empty-span guard).
	const olderSections = sections.slice(0, start);
	const tailSections = sections.slice(start);
	return {
		older: truncateMiddle(olderSections.map((section) => section.rendered).join("\n\n"), MAX_CONVERSATION_CHARS),
		tail: tailSections.map(replaySection).join("\n\n"),
		languageMessages: languageMessagesOf([...olderSections, ...tailSections]),
		trimmedTail: tailSections.some((section) => section.clipped === true),
	};
}

/** Resolve the language for one handoff: explicit config wins, otherwise the conversation decides. */
export function resolveHandoffLanguage(messages: readonly HandoffLanguageMessage[], config: PluginConfig): HandoffLanguage {
	return resolveLanguage(messages, config.handoffLang);
}
