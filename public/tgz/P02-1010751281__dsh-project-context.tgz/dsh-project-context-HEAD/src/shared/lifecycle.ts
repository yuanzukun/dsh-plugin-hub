/**
 * Shared plugin lifecycle helpers: session identity, serialized background
 * work, and per-session durability tracking. Both context plugins and the
 * handoff plugin keep the same lifecycle shape, so it lives here once.
 */

import type { Session } from "@deepseek-ai/dsh-session";

/** Longest a durability flush waits for in-flight work before letting shutdown proceed. */
export const FLUSH_WAIT_MS = 90_000;

export function isTopLevel(session: Session): boolean {
	return session.header.origin !== "subagent";
}

export function projectCwd(session: Session): string {
	return session.header.cwd ?? process.cwd();
}

/** Wait for a promise, but never longer than the flush budget. */
export function waitBounded(promise: Promise<void>): Promise<void> {
	return new Promise<void>((resolve) => {
		const timer = setTimeout(resolve, FLUSH_WAIT_MS);
		timer.unref?.();
		void promise.finally(() => {
			clearTimeout(timer);
			resolve();
		});
	});
}

/**
 * Serialize background writes. A failed task reaches its caller through the
 * returned promise, but never poisons later tasks on the same queue.
 */
export class SerialQueue {
	private tail: Promise<void> = Promise.resolve();

	/**
	 * Run one task after the previous one settles.
	 * @param work - the task; its value or rejection reaches this caller only.
	 * @returns the task's own promise, so callers can read what it produced.
	 */
	run<T>(work: () => Promise<T>): Promise<T> {
		const next = this.tail.then(work);
		this.tail = next.then(
			() => undefined,
			() => undefined,
		);
		return next;
	}
}

/**
 * Per-session in-flight work, awaited by the `session/flush` durability handler.
 *
 * Only the **write phase** of a pass belongs here — never a span that is waiting on a model call.
 * dsh's checkpoint policy flushes a live session *before dispatching a request that names it*, and
 * the plugins' own auxiliary calls name one (`PluginCallOptions.sessionId`), so a pass that
 * registered its whole self would have that request's flush await the very call it is dispatching.
 * It would not deadlock — `waitBounded` releases at `FLUSH_WAIT_MS` — but every auxiliary call would
 * stall for the full budget, and the flush would hand back a "durable" verdict for a pass that had
 * not written anything yet. A registered write never waits on a dispatch, so awaiting it is both
 * safe and the point of registering it.
 */
export class SessionWorkTracker {
	private readonly pending = new Map<string, Promise<void>>();

	/** @param work - in-flight work; its value is ignored, only its settlement matters. */
	track(session: Session, work: Promise<unknown>): void {
		const key = String(session.id);
		const tracked = work.then(() => undefined, () => undefined);
		this.pending.set(key, tracked);
		void tracked.finally(() => {
			if (this.pending.get(key) === tracked) this.pending.delete(key);
		});
	}

	flush(session: Session): Promise<void> | undefined {
		const work = this.pending.get(String(session.id));
		return work ? waitBounded(work) : undefined;
	}
}
