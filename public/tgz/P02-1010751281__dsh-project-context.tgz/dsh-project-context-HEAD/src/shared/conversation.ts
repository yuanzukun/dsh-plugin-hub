/**
 * Reading a session as rendered conversation sections — the shape the consolidation prompt,
 * the handoff split and the language detector all consume — plus the input fitting that keeps
 * a consolidation request inside its budget.
 */

import { type Message, type ToolCallBlock } from "@deepseek-ai/dsh-llm";
import { isReplacementSurfaceEvent, isSurfaceEligibleType, type Session } from "@deepseek-ai/dsh-session";
import { isHandoffContinuationText } from "../project-handoff/language.js";
import { MAX_CONVERSATION_CHARS } from "./project-state.js";
import { MAX_ADAPTIVE_OUTPUT_TOKENS, MIN_CLIP_CHARS, REPLY_OUTPUT_MARGIN_TOKENS, adaptiveOutputTokens, allocateTokens, reasoningReserveTokens } from "./output-budget.js";
import { clip, clipTo, replyTokenRate, textOf, truncateMiddle } from "./text.js";

/**
 * What the pass sends instead of the stored artifacts, plus the budget it asks for.
 *
 * The clip is reported per artifact as a character count, not just a boolean: the receipt has to say
 * which of the two was shortened and by how much, and a bare flag cannot distinguish a pass that hid
 * a few characters of memory from one that hid a whole context. `clipped` stays the derived "either
 * one was shortened" answer the call sites already read.
 */
export type MemoryInput = {
	text: string;
	contextText: string;
	maxTokens: number;
	/** True when either stored artifact had to be shortened to fit the output budget. */
	clipped: boolean;
	/** Characters of the stored memory the model was not shown (head-and-tail clip); 0 when whole. */
	memoryHiddenChars: number;
	/** Characters of the stored context the model was not shown; 0 when whole. */
	contextHiddenChars: number;
};

/**
 * Match the output budget to everything the reply must re-emit. A large memory is what truncated
 * replies (and the poisoned files they used to leave) came from: the cap is raised up to the
 * model's own limit, and when even that cannot hold memory plus context, both are shortened
 * head-and-tail so the reply can still come back complete and parseable. Each artifact is budgeted
 * by its own token rate, so a large cheap context cannot let a small dense memory pass the cap.
 */
export function fitMemoryInput(
	memory: string,
	context: string,
	configuredMaxTokens: number,
	model: { maxTokens?: number; reasoning?: boolean },
	ceilingTokens: number = MAX_ADAPTIVE_OUTPUT_TOKENS,
	extraHeadroomTokens: number = 0,
): MemoryInput {
	const memoryRate = replyTokenRate(memory);
	const contextRate = replyTokenRate(context);
	const contentTokens = memory.length * memoryRate + context.length * contextRate;
	// Hidden thinking and a retry's extra headroom are charged to the same output cap as the visible
	// reply, so they widen the request and shrink what the input may consume.
	const reasoningReserve = reasoningReserveTokens(contentTokens, model);
	const needed = Math.ceil(contentTokens) + REPLY_OUTPUT_MARGIN_TOKENS + reasoningReserve + extraHeadroomTokens;
	const maxTokens = adaptiveOutputTokens(configuredMaxTokens, needed, model, ceilingTokens);
	// Keep a JSON-scaffolding margin plus whatever is reserved for thinking, with a small absolute
	// floor so a tiny cap cannot spend every token on content and then truncate the reply's own
	// braces and keys. The half-cap arm keeps a large reserve from eating the whole budget.
	const desiredReserve = REPLY_OUTPUT_MARGIN_TOKENS + reasoningReserve + extraHeadroomTokens;
	const reserved = Math.min(desiredReserve, Math.max(0, maxTokens - MIN_CLIP_CHARS), Math.max(REPLY_OUTPUT_MARGIN_TOKENS, Math.round(maxTokens * 0.5)));
	const budget = Math.max(0, maxTokens - reserved);
	if (contentTokens <= budget) {
		return { text: memory, contextText: context, maxTokens, clipped: false, memoryHiddenChars: 0, contextHiddenChars: 0 };
	}
	// Over budget: each artifact keeps a floor in tokens and the rest follows its measured need, so
	// a big cheap artifact cannot crowd out a small dense one. Repeat with the clipped texts' own
	// rates: clipping can change the density, and the reallocation only shrinks what is over.
	const initial = allocateTokens(budget, memory.length * memoryRate, context.length * contextRate);
	let text = clipTo(memory, Math.floor(initial.memory / Math.max(memoryRate, 0.001)));
	let contextText = clipTo(context, Math.floor(initial.context / Math.max(contextRate, 0.001)));
	for (let attempt = 0; attempt < 10; attempt += 1) {
		const textTokens = text.length * replyTokenRate(text);
		const contextTokens = contextText.length * replyTokenRate(contextText);
		if (textTokens + contextTokens <= budget + 0.5) break;
		const next = allocateTokens(budget, textTokens, contextTokens);
		const stepText = clipTo(memory, Math.floor(next.memory / Math.max(replyTokenRate(text), 0.001)));
		const stepContext = clipTo(context, Math.floor(next.context / Math.max(replyTokenRate(contextText), 0.001)));
		if (stepText.length === text.length && stepContext.length === contextText.length) break;
		text = stepText;
		contextText = stepContext;
	}
	// Clipping can also come out lighter than the original text, leaving budget unused. Fill it by
	// growing both artifacts toward their full length; a step that overshoots is retried smaller,
	// and the last fitting result is kept.
	let step = 1;
	for (let attempt = 0; attempt < 12 && step > 0.002; attempt += 1) {
		const textTokens = text.length * replyTokenRate(text);
		const contextTokens = contextText.length * replyTokenRate(contextText);
		const spare = budget - (textTokens + contextTokens);
		if (spare <= Math.max(0.5, budget * 0.005)) break;
		const rateText = Math.max(replyTokenRate(text), 0.001);
		const rateContext = Math.max(replyTokenRate(contextText), 0.001);
		const needText = Math.max(0, memory.length - text.length) * rateText;
		const needContext = Math.max(0, context.length - contextText.length) * rateContext;
		if (needText + needContext <= 0) break;
		const growText = (spare * step * needText) / (needText + needContext) / rateText;
		const growContext = (spare * step * needContext) / (needText + needContext) / rateContext;
		const grownText = clipTo(memory, Math.min(memory.length, text.length + Math.ceil(growText)));
		const grownContext = clipTo(context, Math.min(context.length, contextText.length + Math.ceil(growContext)));
		const grownTokens = grownText.length * replyTokenRate(grownText) + grownContext.length * replyTokenRate(grownContext);
		if (grownTokens > budget + 0.5) {
			step /= 2;
			continue;
		}
		text = grownText;
		contextText = grownContext;
		step = 1;
	}
	// Absolute safety: the char count of a clip cannot exceed its token count (rate ≤ 1.0).
	if (text.length * replyTokenRate(text) + contextText.length * replyTokenRate(contextText) > budget + 0.5) {
		const safe = allocateTokens(budget, text.length * replyTokenRate(text), contextText.length * replyTokenRate(contextText));
		text = clipTo(text, Math.floor(safe.memory));
		contextText = clipTo(contextText, Math.floor(safe.context));
	}
	// Exact trim: char rounding in the limits can leave a fraction of a token over budget.
	for (let attempt = 0; attempt < 4; attempt += 1) {
		const textTokens = text.length * replyTokenRate(text);
		const contextTokens = contextText.length * replyTokenRate(contextText);
		const over = textTokens + contextTokens - budget;
		if (over <= 0.0001) break;
		if (textTokens >= contextTokens && text.length > 0) {
			text = clipTo(text, text.length - Math.max(1, Math.ceil(over / Math.max(replyTokenRate(text), 0.001))));
		} else if (contextText.length > 0) {
			contextText = clipTo(contextText, contextText.length - Math.max(1, Math.ceil(over / Math.max(replyTokenRate(contextText), 0.001))));
		} else break;
	}
	// The counts are what the receipt reports; `clipped` is their boolean summary. `clipTo` only ever
	// shortens, so neither count can go negative even after the growth passes above.
	const memoryHiddenChars = memory.length - text.length;
	const contextHiddenChars = context.length - contextText.length;
	return {
		text,
		contextText,
		maxTokens,
		clipped: memoryHiddenChars > 0 || contextHiddenChars > 0,
		memoryHiddenChars,
		contextHiddenChars,
	};
}

/**
 * One rendered conversation section, with the unclipped user text kept alongside it.
 *
 * The handoff pass must recognize a previous continuation prompt in the *raw* text — the render
 * clips a user message to 4000 characters, which is shorter than a real continuation — so both
 * callers share this one pass instead of each re-implementing the rendering and drifting apart.
 */
export interface ConversationSection {
	/** The rendered `## user` / `## assistant` / `## tool result` block. */
	readonly rendered: string;
	/** Unclipped text, present only for user-role messages. */
	readonly userText?: string;
	/** dsh source kind of that user message. */
	readonly sourceKind?: string;
	/**
	 * True when the rendered body was cut at its render cap (4000 chars for a message, 1500 for a tool
	 * result), so the block is not the message verbatim. The handoff's carry statement reads this: a tail
	 * that contains a clipped section must not tell the successor it was carried verbatim.
	 */
	readonly clipped?: boolean;
}

/**
 * Which events a rendered conversation is read from.
 *
 * `surface` is what the model's own history holds: `deriveMessages()`, the fold of the
 * model-visible surface, where a replacement copy stands in for whatever it shadowed.
 * `append-origin` is every event that entered the surface at its own log position and was never a
 * replacement copy — which upstream's `isAppendSurfaceEvent` documents as a *transcript's* durable
 * source material precisely because the surface "would erase conversation the user already saw".
 * A compaction's checkpoint is such a replacement, so reading append-origin events lets the span it
 * summarized be rendered instead of the summary that replaced it.
 */
export type ConversationSource = "surface" | "append-origin";

/**
 * The messages of one session under a {@link ConversationSource}.
 *
 * The append-origin read is not a second fold of the surface: it walks the append-only log and
 * projects each append-origin event through the session's own `deriveEventMessage`, so logged
 * message projections still apply and the restored messages keep their durable identity.
 *
 * Reading a replacement copy is what a compaction hides, so dropping the copy instead of the node it
 * replaced is the whole difference. Two replacement producers make that visible, and both are
 * deliberate: a compaction checkpoint disappears while the messages it summarized return, and a
 * pruned tool result reads as its original, longer content (the section's own render cap still
 * bounds it). A runtime-context snapshot is a `system/message`, so no section renders it either way.
 *
 * The test is "is a replacement copy", not "is an append". Upstream makes that distinction hard for a
 * *live* session — `surfaceOpOf` refuses a surface-eligible event that carries no marker, so such an
 * event cannot enter a log at all, and a fork copies whole events (`buildForkSeed` slices the prefix),
 * so a forked session keeps its markers too. The tolerance is therefore for the remaining caller: an
 * object built by hand, which this plugin is handed in tests and must not silently shorten. An event
 * without the marker cannot be standing in for another node, so it is read like an append.
 * @param session - the session to read.
 * @param source - which event family to read; defaults to the model-visible surface.
 * @returns the projected messages, in log order.
 */
export function conversationMessages(session: Session, source: ConversationSource = "surface"): readonly Message[] {
	if (source === "surface") return session.deriveMessages();
	const messages: Message[] = [];
	for (const event of session.snapshotEvents()) {
		// A log-only record (a boundary, a job registration, a meter sample) never projects a message —
		// `deriveEventMessage`'s default branch returns null for exactly these — so the guard is kept in
		// step with upstream's own fold rather than to prevent a defect: it spares the projector a call
		// that would answer null, and it is the same eligibility test that fold applies.
		if (!isSurfaceEligibleType(event.type)) continue;
		if (isReplacementSurfaceEvent(event)) continue;
		const message = session.deriveEventMessage(event);
		if (message !== null) messages.push(message);
	}
	// A totality guarantee, not a production path: on a live session this branch is unreachable. A
	// replace op may only cite earlier seqs, a fork copies the whole prefix and `snapshotEvents()`
	// starts at seq 0, so every real session with a message has at least one append-origin event (and
	// the "no message yet" case returns `[]` from both sources anyway). It exists so a caller that
	// builds a session object by hand gets the same conversation it would have read before this seam,
	// instead of an empty transcript it would report as "the session said nothing" — a wrong cause for
	// a true statement. The 25 integration fixtures in `test/logic.test.mjs` take this branch.
	return messages.length === 0 ? session.deriveMessages() : messages;
}

/**
 * Compact section-per-message rendering of a conversation.
 * @param session - the session to read.
 * @param source - which event family to read; see {@link ConversationSource}.
 * @returns one section per message that renders any text.
 */
export function conversationMessageSections(session: Session, source: ConversationSource = "surface"): ConversationSection[] {
	const sections: ConversationSection[] = [];
	for (const message of conversationMessages(session, source)) {
		if (message.role === "system") continue;
		if (message.source.kind === "tool") {
			const text = textOf(message.content);
			if (text) sections.push({ rendered: `## tool result\n${clip(text, 1500)}`, ...(text.trim().length > 1500 ? { clipped: true } : {}) });
			continue;
		}
		if (message.role === "user") {
			const text = textOf(message.content);
			if (text) sections.push({ rendered: `## user\n${clip(text, 4000)}`, userText: text, sourceKind: message.source.kind, ...(text.trim().length > 4000 ? { clipped: true } : {}) });
			continue;
		}
		const text = textOf(message.content);
		const tools = message.content
			.filter((block): block is ToolCallBlock => block.type === "tool-call")
			.map((block) => `[tool: ${block.name}]`)
			.join(" ");
		const parts = [text ? clip(text, 4000) : "", tools].filter(Boolean);
		if (parts.length > 0) sections.push({ rendered: `## assistant\n${parts.join("\n")}`, ...(text.trim().length > 4000 ? { clipped: true } : {}) });
	}
	return sections;
}

/** The rendered sections alone, for the learn prompt. */
function conversationSections(session: Session): string[] {
	return conversationMessageSections(session).map((section) => section.rendered);
}

/** Compact, budgeted rendering of the derived conversation for the learn prompt. */
export function conversationText(session: Session): string {
	return truncateMiddle(conversationSections(session).join("\n\n"), MAX_CONVERSATION_CHARS);
}

/** One event as `session.snapshotEvents()` returns them. */
type SessionEvent = ReturnType<Session["snapshotEvents"]>[number];

/**
 * Text of a `user/message` a person wrote, else `undefined`.
 *
 * The handoff's own continuation prompt is injected through the same prompt RPC as a real user
 * message — dsh's `SessionPromptRequest` carries no source kind, so the host records the seed as
 * `{kind:"user"}` like any other — and it must not read as a human turn. Counting it would start
 * every handoff child one turn nearer the autolearn/consolidation gates than the person actually
 * drove it, and would hand `firstUserText` a 70K-character banner instead of what was asked.
 * `isHandoffContinuationText` is reused rather than re-implemented, so this and the session
 * index's title fallback agree on what a generated prompt is; both carry the same accepted
 * residual, that a message reproducing a banner verbatim is indistinguishable from one.
 *
 * The pi sibling's prompt is deliberately not composed in here: it reaches a log only as a bare
 * `message` line in a pi archive, which the index title and the Markdown renderer read as raw
 * entries — never through a live dsh session's `snapshotEvents()`.
 *
 * Returns `""` for a human message with no text, which `userTurnCount` still counts as a turn.
 *
 * Exported because it is the one reader of "what a person said" over the **durable log** — the same
 * source the host's own title readers fold (`collectSessionTitleMessages(session.snapshotEvents())`)
 * — and the deferred handoff title needs that basis rather than the derived surface: a compaction
 * replaces surface nodes, so a derived message can disappear while the log keeps it.
 */
export function humanUserText(event: SessionEvent): string | undefined {
	if (event.type !== "user/message" || event.data.source.kind !== "user") return undefined;
	const text = textOf(event.data.content);
	return isHandoffContinuationText(text) ? undefined : text;
}

/** Human turns only: injected user-role context and handoff banners do not count. */
export function userTurnCount(session: Session): number {
	return session.snapshotEvents().filter((event) => humanUserText(event) !== undefined).length;
}

/** First message a person wrote; injected context and handoff banners are skipped. */
export function firstUserText(session: Session): string {
	for (const event of session.snapshotEvents()) {
		const text = humanUserText(event);
		if (text) return text;
	}
	return "";
}
