# Memory compression headroom (2026-11-06)

## The claim

`MEMORY.md` was compressed 39696 → 37780 chars on 2026-11-06 because two consolidation passes
(`01:36:29` and `01:47:06` UTC, both in `.agents/memory/errors.log`) refused with
`4 whole entry(ies) would have been dropped from 3 section(s) because the memory document reached
its character cap`. That message is the **budget half**: the renderer dropped whole entries, not the
model's output being cut. This probe re-measures both halves at the compressed size.

**Result: at 37780 chars both halves are clear** — the renderer keeps every entry with a
byte-identical round trip, and `fitMemoryInput` requests 29611 output tokens without clipping.

**Residual:** the pass lands only if the model's rewrite grows the document by at most the
remaining 2220 chars. Measured over the 6 mature passes in the journals (`input >= 34000`),
growth was `-156 … +3475`, median `+532`; **1 of 6 exceeded 2220**. So the compression is a
probability, not a guarantee — the exact growth of the refused reply is not recoverable, because the
journal records only landed writes and `.agents/memory/memory.jsonl` keeps no `refusedLoss` rows.

## How to re-run

```sh
node .agents/evidence/2026-11-06-memory-compression-headroom/probe.mjs --self-test   # both failure branches must trip
node .agents/evidence/2026-11-06-memory-compression-headroom/probe.mjs --model-cap 328000
```

`--model-cap` is the live model's `defaultMaxTokens`, read from the desktop profile's model catalog:

```sh
grep -n -A 4 'id: auto/deepseek-v4.1-flash' ~/.dsh/profiles/desktop/cordis.patch.yml
```

Omit it to treat the model cap as unbounded; the configured ceiling `maxOutputTokens` then binds,
which is what actually decided the outcome here (29611 < 32768). A stale cap can only fail **loud**
— a value below the requested tokens flips `clipped` to true and the probe exits 1.

Exit codes: `0` both halves clear at the current size, `1` the current documents already lose data,
`2` the probe cannot judge (document not a plain four-section bullet list, or a bad `--model-cap`),
`3` the self-test's own failure branches did not trip.

## Observed (2026-11-06, HEAD `0aee0af`)

```
inputs: MEMORY.md 37780 chars, CONTEXT.md 9820 chars

A. budget half
  Project     entries  14    5228 /   6787 (77.0% of its share)
  Invariants  entries  52   17690 /  17965 (98.5% of its share)
  Pitfalls    entries  36   11517 /  11577 (99.5% of its share)
  Index       entries  12    3278 /   3593 (91.2% of its share)
  render: sectionDropped 0, droppedItems 0, itemTruncated 0, bytes identical true
  headroom: 2220 chars (37780 / 40000); schema overhead 76

B. growth history (4 journal files, 58 full-text records, 35 landed passes)
  mature (>=34000) n=6  min -156  p50 532  p90 3475  max 3475
  headroom vs measured growth: p50 532 fits the 2220-char headroom; max 3475 EXCEEDS it

C. output half
  configured maxTokens 8192, ceiling maxOutputTokens 32768, model defaultMaxTokens 328000
  requested maxTokens 29611 (bound 32768); clipped false; hidden memory 0 / context 0
```

## Why each number is what it is

- **`clipped false` is decided by the ceiling, not the model cap.** `adaptiveOutputTokens` returns
  `min(min(needed, model.maxTokens), max(configured, ceiling))`; with `needed` 29611 and ceiling
  32768 the model's 328000 never binds. `needed` = `contentTokens` 21175 + `REPLY_OUTPUT_MARGIN_TOKENS`
  1024 + the reasoning reserve (cap at `MAX_REASONING_RESERVE_TOKENS`).
- **The reserve exists because the model is a reasoning route.** `consolidate.js` builds
  `auxModel = { maxTokens: info?.defaultMaxTokens, reasoning: info?.reasoning !== undefined }`, so a
  non-reasoning route would request 22200 instead — either way below the ceiling.
- **Per-section occupancy is diagnostic, not the gate.** Batch N makes the four shares targets, so
  `Invariants` at 98.5% and `Pitfalls` at 99.5% of their own share is not a refusal; only the whole
  document reaching `maxMemoryChars` drops an entry. That is why the headroom is `cap - length`.
- **Growth is measured per landed pass, one row per second.** Several journal appends can share one
  second; the last one is what that pass landed. Taking the first instead moves the mature maximum
  from +3475 to +2346 — both above the fold, but the tail matters, so the probe keeps the last.

## The 10:13:33 refusal, and why it does not settle the question

A third refusal was logged at `2026-11-06T02:13:33Z` (local 10:13:33), this one dropping
`3 whole entry(ies)` from `2 section(s)`, with the targeted retry dying on its own error
(`cannot get required service "llm" in inactive context`), so the first reply's loss decided the pass:

```
the targeted loss retry failed for its own reason, so the first reply's loss decides this pass
the consolidation reply would have been stored lossily (3 whole entry(ies) ... from 2 section(s)
  because the memory document reached its character cap) ...; the stored memory was kept unchanged
```

**Which document that pass read is unresolved, and this record must not claim otherwise.**
The argument for the compressed version is only that `MEMORY.md`'s mtime is `10:10:04`, earlier than
the refusal. The argument against: a pass makes up to two model calls, each emitting roughly the whole
document, so it can easily span several minutes and may have read the pre-compression document.
No disk record settles it — the request body is not logged, the cost-meter ledger aggregates per
session rather than per call, and the host writes no `[memory]` lines. A weak hint points at the
smaller input (the earlier refusals at 39696 dropped `4` entries from `3` sections; this one dropped
`3` from `2`), but reply sizes vary, so it is a hint and not evidence.

The clean discriminator: `MEMORY.md` has not changed since `10:10:04`, so **any refusal logged after
the 10:51:25 restart is unambiguously against 37780**. Until one appears, "the compression was not
enough" is unproven, and so is its opposite.

Two things this event does rule out, independently of which document it read:

- **Not a prompt gap.** `memoryBudgetRule` states the hard cap and the current size
  (`must stay at or under 40000 characters (the stored memory is currently about N)`).
- **Not the output half.** `needed` at 37780 with the current 10314-char context is 29941, under the
  32768 ceiling.

And the cap has very little room left to grow: at real token density `maxMemoryChars` 43000 gives
`needed` 32732 (fits), 43500 gives `clipped true` — about +5% of document, or the equivalent of
deleting facts instead.

## What this does not prove

- It cannot prove the *next* pass lands. This one did (see the section above), leaving 633 characters
  of headroom at 39367 — and 3 of the 7 measured mature passes grew past that, so the next refusal is
  a probability, not an impossibility.
- It does not say what the model will write. The growth distribution is empirical and small (n=6 in
  the comparable band), and it is survivor-biased: refusals leave no journal row.
- It does not cover the live config: the numbers assume the schema defaults `maxTokens` 8192 /
  `maxOutputTokens` 32768 / `maxMemoryChars` 40000. Re-read them through `cordis_inspect_query`
  (`Config`, entry `include:project-context`) if a profile ever overrides them.

## The pass that answered the question

The pass this document was waiting for ran on `2026-11-06T02:58:25.989Z` (local 10:58:25) and
**landed**: `memory.jsonl`'s last record is `op: replace` with a 39216-character text, `MEMORY.md`
went 37780 -> 39216 and `CONTEXT.md` 10981 -> 5278, and `errors.log` records no refusal for it.

It is also the first pass after the 10:51:25 restart, so by this document's own anchor it read the
37780-character document — no ambiguity this time. That settles the question the earlier refusals left
open: **the compression was enough**, and the refusals before it were the model failing to compress
further, not the document being too large for the write path.

It is not a clean pass, and the two blemishes are worth naming:

- `memory regression: 8 Invariants/Pitfalls entry(ies) are no longer present` is a **false positive**.
  A bullet-set comparison against `HEAD` finds all 8 present in reworded form; the check compares
  text exactly, so a rewording reads as a disappearance. It is a post-write report and refuses
  nothing, and the same line has appeared with 30 / 55 / 7 / 4 / 8 entries, so it must not be read as
  evidence that memory was lost.
- Two facts really did vanish and were restored by hand: the historical note that a cross-metric
  subtraction once left auto mode thresholdless (re-attached to the `floor` entry) and the clause that
  a seed's own wording is the cheapest disambiguator. Both were restored by whole-line replacement;
  the re-measured document is 39367 with 633 characters of headroom, `sectionDropped 0 /
  droppedItems 0 / itemTruncated 0`, a byte-identical round trip, and `needed` 26929 under the 32768
  output bound.

## Reading the next refusal's log lines

`errors.log` mixes two unrelated populations that both contain the same string, so a refusal's
"retry failed for its own reason" line is not evidence that the model could not compress:

- **A whole pass that died at its first model call** — `Error: cannot get required service "llm" in
  inactive context`, stack through `consolidate.js`'s first `call(...)`. The plugin context is
  already disposed, so no request is ever made.
- **A tier C retry that died after a real first reply** — `the targeted loss retry failed for its own
  reason, so the first reply's loss decides this pass: cannot get required service "llm" ...`.

15 such rows exist since 2026-10-20, and attribution is partial on purpose:

- `2026-11-06T01:26:41Z` (x2) sits 1.4 s before the next host booted (09:26:43 +08:00): it is the
  outgoing host's dispose-time `agent/disposed` pass. That context is inactive before the pass even
  starts, so this trigger's failures at host teardown are expected — noise, not a defect.
- `2026-11-06T02:23:37Z` (x3) coincides with three session projection caches updating, i.e. three
  top-level agents disposed at once, but the host was not restarting then and *why* the plugin
  context was inactive is unresolved.
- The `02:13:33Z` retry death is the one that decided a refusal. It is also unresolved.

So the retry line dates such a failure without explaining it, and none of the "inactive context" rows
may be counted as the model failing to compress.

## After the next pass

```sh
# 1. (passed on the 10:51:25 restart; re-run only after a further restart)
#    the two batches are live: holder start later than 30e0ba1 (2026-11-06T09:59:03+08:00)
ss -ltnp | grep -E '127\.0\.0\.1:(35|19)[0-9]{3}'
ps -o lstart= -p <pid>
git -C /mnt/Data/Projects/dsh-project-context diff --exit-code -- lib

# 2. re-measure at whatever size the pass left behind, then read the refusal reason if it refused
node .agents/evidence/2026-11-06-memory-compression-headroom/probe.mjs --model-cap 328000
tail -n 20 /mnt/Data/Projects/dsh-project-context/.agents/memory/errors.log
```

A refusal that reads `N section(s) exceeded their budget` is the budget half: shrink again.
A refusal that reads `cut off by the model output limit` is the output half: lowering `maxMemoryChars`
will not help, the request itself is what got clamped.

## The cap has now bitten in production (2026-11-06 21:27–21:31 +08:00)

Measured on the same stored documents, after the 20:58 round:

- `MEMORY.md` 39587 chars against `maxMemoryChars` 40000 — **413 chars of headroom**.
- `.agents/memory/errors.log` carries 35 `stored lossily` lines. The two newest are
  `13:27:00.051Z` and `13:30:57.690Z`, each
  `4 whole entry(ies) would have been dropped from 3 section(s) because the memory document reached
  its character cap` followed by `the refused reply's context section was not published`.
  `MEMORY.md` has not changed since `12:57:32Z`, so both refusals discarded that pass's work.
- The probe's own growth history says this is the expected outcome rather than bad luck: over the 7
  mature passes (input ≥ 34000) growth was −734 … +3475 with p50 **+532**, and 5 of the 7 exceed 413.

The state is therefore "memory frozen": every pass that adds anything is refused, and neither
artifact is written.

## Re-measured clip boundary (corrects the earlier `43500` note)

`fitMemoryInput` was called with the shape the plugin actually builds —
`auxModel = { maxTokens: info.defaultMaxTokens, reasoning: info.reasoning !== undefined }`
(`lib/project-memory/consolidate.js:412`), i.e. `{ reasoning: true, maxTokens: 328000 }` for
`auto/deepseek-v4.1-flash` — with `configuredMaxTokens` 8192, ceiling 32768 and the real
`CONTEXT.md` (9077 chars):

| MEMORY.md chars | requested `maxTokens` | `clipped` |
|---|---|---|
| 34020 | 26668 | false |
| 39587 (the real document) | 29678 | false |
| 43007 | 31534 | false |
| 43798 | 31960 | false |
| 45242 | 32711 | false |
| 48251 | 32768 | **true**, `memoryHiddenChars` 2297 |

The earlier note "43000 → needed 32732, 43500 起 clipped" does not reproduce: with the call shape the
plugin really uses, the first clip sits between 45242 and 48251 chars at this CONTEXT size, so
**43000 keeps 1234 tokens of slack**, not 36. Caveat: every row except 39587 is a synthetic document
grown by repeating real `- ` lines, so its character→token rate can differ slightly from the stored
document's; the 39587 row is the real file and matches `probe.mjs` exactly. With `reasoning: false`
every size fits (48251 → 25739), so the reasoning reserve is what binds, not the document alone.

### The two documents share that budget

The table above was measured against `CONTEXT.md` at 9077 chars. Recording this round's own bullets
grew it to 9956, and re-running the same sweep moved every row up by ~726 tokens:

| MEMORY.md chars | requested `maxTokens` (CONTEXT 9956) | `clipped` |
|---|---|---|
| 39587 | 30404 | false |
| 43007 | 32260 | false |
| 43798 | 32670 | false |
| 45242 | 32768 | **true**, `memoryHiddenChars` 939 |

So the cap decision cannot be made from `MEMORY.md` alone: 879 chars of new CONTEXT bought 726 tokens
of the same output reserve. At 43000 the slack is **508 tokens**, not 1234 — real, but it shrinks with
every CONTEXT bullet. Recompute with `cap-sweep.mjs` in this directory before relying on any row: it
reads whichever documents are stored at the moment it runs.

## Consequences for the cap choice

- `maxMemoryChars` 43000 buys 3413 more chars of headroom and still fits the output cap, but only just:
  508 tokens to spare at CONTEXT 9956 and ~400 at 10101, because every CONTEXT character costs about
  0.8 of the same reserve.
- It does not shrink anything: the per-turn injection cost follows whatever a pass actually writes,
  and the output slack follows CONTEXT.md's own growth.
- Shrinking stays the durable lever. The cheapest cut is closed-batch narrative: 18 of the 116
  entries match batch/CHANGELOG wording and account for 7135 chars — moving them to a doc loses no
  fact, only their presence in the injected set.
