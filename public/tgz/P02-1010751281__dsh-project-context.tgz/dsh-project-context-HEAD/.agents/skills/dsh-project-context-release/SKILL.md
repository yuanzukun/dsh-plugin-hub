---
name: dsh-project-context-release
description: "Cut and publish a versioned release of the dsh-project-context plugins: update version and CHANGELOG, run the full gate, create and push an annotated tag with a release note, and verify the tag on origin."
---

Release workflow for the dsh-project-context plugins (repo root /mnt/Data/Projects/dsh-project-context).

1. Check the working tree and concurrent-session state.
   Run `git status --short`. Untracked `.agents/` and `thinking-effort-loaded.json` are normal. A second dsh agent session may be working in this repo and can leave changes staged, so use the scoped commit: stage only this task's paths and never `git add -A` — the full rule (the exact add, `git commit -F <msg> -- <paths>`, and the `git diff --cached` check) lives in `dsh-project-context-concurrent-writer-guard` step 5.

2. Update version and changelog.
   The changelog is `CHANGELOG.md`, not the README; the README only points to it. Since the 2026-11-06 split, `CHANGELOG.md` holds **only** the `未发布` section (newest first) plus the `## 版本目录` table, and every released body lives verbatim in `docs/changelog/<version>.md`. A release therefore moves the whole `未发布` body into a new `docs/changelog/v<new>.md` (`# v<new>（<date>）` heading, a `> 已发布版本明细…` blockquote line linking back to `CHANGELOG.md`, then the body unchanged), adds one row to the `版本目录` table, and in that same edit opens a fresh empty `### 未发布（`<new tag>` 之后）` section at the top of `CHANGELOG.md` (the first release after the split sets the precedent); if the release commit misses the empty section, add it in a **post-tag** docs commit — a released tag is never rewritten or re-cut. Set `version` in `package.json` to the release version. Keep README prose wrapped at 100 columns and never split an inline code span across lines. Use English Conventional Commits (`feat:`, `fix:`, `docs:`, `chore(release):`). The CHANGELOG edit rides the **pre-tag** release commit: anything that documents the release afterwards — evidence under `.agents/evidence/`, a decision doc, the memory/context render — lands as its own **post-tag** commit, because a released tag is never rewritten and a released section gets dated addenda rather than rewrites.

3. Run the full gate under the correct Node.
   Run `node -v`; the Nix store path and version rotate on rebuild, so prepend the node it reports — `PATH="$(dirname "$(command -v node)"):$PATH"` — never a pasted store path. Run `pnpm typecheck`, `pnpm test`, and `pnpm build`. `pnpm test` must pass (expected count). When stdout is not a TTY, `node --test` prints TAP (`# pass N`) instead of `ℹ pass`; check the exit code, not a grep for the reporter.

4. Commit the release changes.
   Stage only the files changed for the release (e.g. `package.json`, `CHANGELOG.md`, `docs/changelog/v<new>.md`, `README.md`). Commit with a message such as `chore(release): vX.Y.Z`. Slices must be **self-consistent**: when two concerns assert in the same test file, splitting them leaves an intermediate commit whose suite is red, so keep them in one slice — a bisect-broken split is worse than a mixed slice. `lib/` is **tracked** (since 2026-10-05, so a clone and a fixed Commit carry the runtime artifacts every catalog reads), so a span that touched `src/` or `client/` must also carry the rebuilt `lib/` in the same release commit: build first, then `git diff --exit-code -- lib` must be empty, and stage `lib` alongside the source paths. A release whose `lib/` is stale ships the old behaviour to every `link:` install while the tag claims the new one.

5. Create and push an annotated tag.
   Write the release note to a file (a `/tmp` path is fine; the durable copy is the tag object once pushed). Create the tag with `git tag -a vX.Y.Z -F <note-file>`. Push the branch with `git push origin main` and the tag with `git push origin refs/tags/vX.Y.Z`.

6. Verify the tag on origin.
   `git ls-remote origin refs/tags/vX.Y.Z` must show both the tag object and the peeled `^{}` commit. `github.com` is unreachable from this host; only `ssh.github.com:443` works. An `ls-remote` can fail transiently through the local proxy; retry it. `gh` is not installed, so any GitHub UI step is for the user.

7. Wrong or superseded tags.
   Delete a wrong local tag with `git tag -d vX.Y.Z` and the remote with `git push origin :refs/tags/vX.Y.Z`. This repo has no GitHub Releases, so a removed tag leaves nothing to clean up on the Releases page; do not hunt for one.

8. After the release.
   If host-side code changed, run `pnpm build` and propose a host restart (do not restart the user's `dsh web` or desktop host unprompted); host code loads only from the built `lib/*.js`. Client bundle changes are live via HMR after `pnpm build`, but open tabs need a hard reload.
