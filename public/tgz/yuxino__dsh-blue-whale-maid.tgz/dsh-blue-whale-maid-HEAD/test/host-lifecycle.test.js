import test from "node:test";
import assert from "node:assert/strict";
import { Context } from "@deepseek-ai/cordis";
import * as plugin from "../lib/index.js";

async function localHost(t, persistence) {
	const root = new Context();
	t.after(() => root.fiber.dispose());
	const routes = new Map();
	let credentialReads = 0;
	root.provide("credentials", {
		async resolve() {
			credentialReads += 1;
			throw new Error("cost tests must not read credentials");
		}
	});
	root.provide("webServer", {
		register(route) {
			assert.equal(routes.has(route.path), false);
			routes.set(route.path, route);
			return () => routes.delete(route.path);
		}
	});
	if (persistence) root.provide("sessionPersistence", persistence);
	const fiber = await root.plugin(plugin);
	return { root, routes, fiber, credentialReads: () => credentialReads };
}

test("Cordis unload and reload release both routes and the session subscription", async (t) => {
	const host = await localHost(t);
	for (const fiber of [host.fiber, null]) {
		const current = fiber ?? await host.root.plugin(plugin);
		assert.equal(host.routes.size, 2);
		assert.equal(host.root.events._hooks["session/event"].length, 1);
		await current.dispose();
		assert.equal(host.routes.size, 0);
		assert.equal(host.root.events._hooks["session/event"].length, 0);
	}
	assert.equal(host.credentialReads(), 0);
});

test("the host cost route merges replay and redelivered live usage without credentials", async (t) => {
	const at = Date.parse("2026-08-24T10:00:00+08:00");
	const events = [
		{ type: "step/start", seq: 1, time: at, data: { turn: 1, step: 1 } },
		{ type: "request/context", seq: 2, time: at, data: { provider: "deepseek-official", model: "deepseek-v4-pro" } },
		{ type: "assistant/chunk", seq: 3, time: at + 1, data: { turn: 1, step: 1, chunk: { type: "usage", usage: { inputTokens: 500, outputTokens: 20 } } } },
		{ type: "assistant/chunk", seq: 4, time: at + 2, data: { turn: 1, step: 1, chunk: { type: "finish", reason: { kind: "error" } } } }
	];
	const host = await localHost(t, {
		async readStoredRevision() { return 4; },
		async readFrom() { return { events: structuredClone(events) }; }
	});
	const session = { id: "test-session", events };
	host.root.emit("session/event", session, events.at(-1));
	host.root.emit("session/event", session, structuredClone(events[2]));
	let response;
	await host.routes.get("/api/blue-whale-maid/session-cost").handler({
		method: "GET", url: "/api/blue-whale-maid/session-cost?sessionId=test-session",
		headers: { host: "localhost:3080" }, socket: { remoteAddress: "127.0.0.1" }
	}, {
		writeHead(status) { assert.equal(status, 200); },
		end(body) { response = JSON.parse(body); }
	});
	assert.equal(response.source, "log");
	assert.equal(response.sessionId, "test-session");
	assert.equal(response.calls, 1);
	assert.equal(response.inputTokens, 500);
	assert.equal(response.outputTokens, 20);
	assert.equal(host.credentialReads(), 0);
});
