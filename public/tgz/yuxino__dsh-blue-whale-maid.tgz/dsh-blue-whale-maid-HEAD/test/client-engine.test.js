import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { runInNewContext } from "node:vm";
import { setImmediate } from "node:timers/promises";

const template = readFileSync(new URL("../src/client.template.js", import.meta.url), "utf8");
// Exercise the actual engine without mounting a browser, loading artwork, or
// calling a real host. This test-only export never enters the shipped bundle.
const source = template.replace("exports.apply = apply;", "exports.createPetEngine = createPetEngine;\nexports.apply = apply;");

function eventTarget() {
	const listeners = new Map();
	return {
		listeners,
		addEventListener(type, listener) {
			if (!listeners.has(type)) listeners.set(type, new Set());
			listeners.get(type).add(listener);
		},
		removeEventListener(type, listener) {
			listeners.get(type)?.delete(listener);
			if (listeners.get(type)?.size === 0) listeners.delete(type);
		}
	};
}

function harness(t) {
	let now = 0;
	let nextId = 0;
	let plugin;
	let signal = { rows: [], current: undefined };
	const frames = new Map();
	const timers = new Map();
	const requests = [];
	const notices = [];
	const opened = [];
	const badge = { textContent: "", classList: { toggle() {} } };
	const root = { ...eventTarget(), style: {}, querySelector: () => badge };
	const document = {
		...eventTarget(), hidden: false,
		documentElement: { clientWidth: 1280, clientHeight: 800 },
		querySelector: () => ({ textContent: "" })
	};
	const window = {
		...eventTarget(), devicePixelRatio: 1,
		__ModuleLoader__: { load: ({ factory }) => { plugin = factory(() => ({})); } }
	};
	runInNewContext(source, {
		window, document, AbortController, AbortSignal,
		performance: { now: () => now },
		Image: class {},
		matchMedia: () => ({ matches: true }),
		localStorage: { getItem: () => null, setItem() {} },
		requestAnimationFrame: (callback) => { frames.set(++nextId, callback); return nextId; },
		cancelAnimationFrame: (id) => frames.delete(id),
		setTimeout: (callback, delay) => { timers.set(++nextId, { callback, delay }); return nextId; },
		clearTimeout: (id) => timers.delete(id),
		fetch: (url, { signal: requestSignal }) => new Promise((resolve, reject) => {
			const onAbort = () => reject(requestSignal.reason);
			requestSignal.addEventListener("abort", onAbort, { once: true });
			requests.push({
				url, signal: requestSignal,
				respond(body, status = 200) {
					requestSignal.removeEventListener("abort", onAbort);
					resolve({ ok: status >= 200 && status < 300, status, json: async () => body });
				}
			});
			if (requestSignal.aborted) onAbort();
		})
	});
	const engine = plugin.createPetEngine({
		root,
		canvas: { getContext: () => ({ setTransform() {}, clearRect() {} }) },
		getSignal: () => signal,
		show: (content, duration, options) => notices.push({ content, duration, ...options }),
		openSession: (id) => opened.push(id)
	});
	t.after(() => engine.dispose());
	return {
		engine, requests, notices, opened, badge, root, window, document, frames, timers,
		observe(rows, at, current = signal.current) {
			now = at;
			signal = { rows, current };
			engine.observeSignal(signal);
		},
		frame(at) {
			now = at;
			const pending = [...frames.values()];
			frames.clear();
			for (const callback of pending) callback(now);
		},
		timeout(delay) {
			const [id, timer] = [...timers].find(([, timer]) => timer.delay === delay) ?? [];
			assert.ok(timer, `expected a ${delay} ms timer`);
			timers.delete(id);
			timer.callback();
		}
	};
}

const session = (id, overrides = {}) => ({ id, rawTitle: `任务 ${id}`, blank: false, running: false, jobs: [], ...overrides });
const balance = (total = "10.00", currency = "CNY") => ({
	ok: true, todayConsumed: null, balance: { balance_infos: [{ currency, total_balance: total }] }
});

test("disposing the engine aborts a pending balance read and removes owned listeners", async (t) => {
	const h = harness(t);
	const pending = h.engine.queryAccount();
	h.engine.dispose();
	assert.equal(h.requests[0].signal.aborted, true);
	await pending;
	assert.equal(h.root.listeners.size, 0);
	assert.equal(h.window.listeners.size, 0);
	assert.equal(h.document.listeners.size, 0);
	assert.equal(h.frames.size, 0);
	assert.equal(h.timers.size, 0);
	assert.equal(h.notices.length, 1); // only the original loading notice
});

test("a newer manual account query cancels the previous read without replacing its result", async (t) => {
	const h = harness(t);
	const first = h.engine.queryAccount();
	const second = h.engine.queryAccount();
	assert.equal(h.requests[0].signal.aborted, true);
	h.requests[1].respond(balance("20.00"));
	await Promise.all([first, second]);
	assert.equal(h.badge.textContent, "¥20.00");
	assert.equal(h.notices.at(-1).kind, "balance");
	assert.equal(h.timers.size, 1); // only the next badge refresh
});

test("disposing also cancels the optional session-cost read", async (t) => {
	const h = harness(t);
	h.observe([session("a")], 0, "a");
	const pending = h.engine.queryAccount();
	h.requests[0].respond(balance());
	await setImmediate();
	assert.match(h.requests[1].url, /session-cost\?sessionId=a$/);
	h.engine.dispose();
	assert.equal(h.requests[1].signal.aborted, true);
	await pending;
	assert.equal(h.notices.length, 1);
	assert.equal(h.timers.size, 0);
});

test("balance timeouts fail cleanly and a later manual refresh can recover", async (t) => {
	const h = harness(t);
	const pending = h.engine.queryAccount();
	h.timeout(15000);
	await pending;
	assert.equal(h.requests[0].signal.aborted, true);
	assert.equal(h.badge.textContent, "?");
	assert.equal(h.notices.at(-1).kind, "failed");
	const retry = h.engine.queryAccount();
	h.requests[1].respond(balance("12.00"));
	await retry;
	assert.equal(h.badge.textContent, "¥12.00");
	assert.equal(h.timers.size, 1);
});

test("an optional cost timeout preserves the balance without inventing a zero cost", async (t) => {
	const h = harness(t);
	h.observe([session("a")], 0, "a");
	const pending = h.engine.queryAccount();
	h.requests[0].respond(balance());
	await setImmediate();
	h.timeout(8000);
	await pending;
	assert.equal(h.notices.at(-1).kind, "balance");
	assert.equal(h.notices.at(-1).content.meta, undefined);
	assert.equal(h.badge.textContent, "¥10.00");
	assert.equal(h.timers.size, 1);
});

test("background refresh cannot supersede a manual query and session switching hides stale costs", async (t) => {
	const h = harness(t);
	h.observe([session("a"), session("b")], 0, "a");
	const pending = h.engine.queryAccount();
	await h.engine.queryAccount(true);
	assert.equal(h.requests.length, 1);
	h.requests[0].respond(balance());
	await setImmediate();
	h.observe([session("a"), session("b")], 1, "b");
	h.requests[1].respond({ ok: true, cost: 4, costUsd: 0.5, unpricedCalls: 1 });
	await pending;
	assert.equal(h.notices.at(-1).kind, "balance");
	assert.equal(h.notices.at(-1).content.meta, undefined);
});

test("the balance panel preserves USD and unknown-price information", async (t) => {
	const h = harness(t);
	h.observe([session("a")], 0, "a");
	const pending = h.engine.queryAccount();
	h.requests[0].respond(balance("20.00", "USD"));
	await setImmediate();
	h.requests[1].respond({ ok: true, cost: 4, costUsd: 0.5, unpricedCalls: 1 });
	await pending;
	assert.equal(h.notices.at(-1).content.meta, "本会话已用 $0.5000 · 另有未定价调用");
});

test("background start and end snapshots notify once even when animation frames pause", (t) => {
	const h = harness(t);
	h.document.hidden = true;
	h.observe([session("a", { running: true })], 100);
	h.observe([session("a")], 5100);
	h.observe([session("a")], 5200);
	assert.equal(h.notices.length, 0);
	h.document.hidden = false;
	h.frame(5300);
	assert.equal(h.notices.length, 1);
	assert.equal(h.notices[0].kind, "ended");
	h.notices[0].action.fn();
	assert.deepEqual(h.opened, ["a"]);
	h.frame(18000);
	assert.equal(h.notices.length, 1);
});

test("a failed background job is notified once across duplicate and partial snapshots", (t) => {
	const h = harness(t);
	h.observe([session("a")], 0);
	const failed = session("a", { jobs: [{ id: "job-a", status: "failed" }] });
	h.observe([failed], 100);
	h.observe([structuredClone(failed)], 200);
	h.frame(300);
	assert.equal(h.notices.at(-1).kind, "failed");
	h.observe([session("a")], 400);
	h.observe([failed], 500);
	h.frame(10000);
	assert.equal(h.notices.filter((notice) => notice.kind === "failed").length, 1);
});

test("a task notice arriving during an account read keeps its bubble ownership", async (t) => {
	const h = harness(t);
	h.observe([session("a", { running: true })], 100);
	const pending = h.engine.queryAccount();
	h.observe([session("a")], 5100);
	h.frame(5200);
	assert.equal(h.notices.at(-1).kind, "ended");
	h.requests[0].respond(balance());
	await pending;
	assert.equal(h.badge.textContent, "¥10.00");
	assert.equal(h.notices.at(-1).kind, "ended");
});

test("a full completion queue retains a new failure and notification ownership blocks account reads", async (t) => {
	const h = harness(t);
	const ids = ["a", "b", "c", "d", "e", "f"];
	h.observe(ids.map((id) => session(id, { running: true })), 100);
	h.observe(ids.map((id) => session(id, id === "f" ? { jobs: [{ id: "failed-job", status: "failed" }] } : {})), 5100);
	h.frame(5200);
	await h.engine.queryAccount();
	assert.equal(h.requests.length, 0);
	for (const at of [18000, 31000, 44000, 57000]) h.frame(at);
	assert.deepEqual(h.notices.map((notice) => notice.kind), ["ended", "ended", "ended", "ended", "failed"]);
});
