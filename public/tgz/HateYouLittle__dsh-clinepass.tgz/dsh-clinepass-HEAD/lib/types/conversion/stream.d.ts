/**
 * pi-ai assistant event translation into the Harness streaming protocol.
 *
 * pi-ai tool-call arguments are parsed objects while the Harness keeps their
 * raw JSON representation. pi-ai also reports failures as terminal stream
 * events, which this module maps into Harness finish chunks.
 *
 * @module dsh-clinepass/conversion/stream
 */
import type { FinishReason, StreamChunk, TokenUsage } from '@deepseek-ai/dsh-llm';
import type { AssistantMessage, AssistantMessageEvent, Usage as PiUsage } from '../sdk-types.ts';
/**
 * Map pi-ai usage (reasoning folded into output by pi-ai).
 * @param usage - cumulative usage from the terminal pi-ai event.
 * @returns harness counts with pi-ai's exact total; cache fields appear only
 *   when non-zero (pi-ai reports zeros, not absence).
 */
export declare function mapUsage(usage: PiUsage): TokenUsage;
/**
 * Map a terminal pi-ai event to the harness finish reason.
 * @param message - the assistant message carried by the `done` or `error` event.
 * @param contextWindow - resolved catalog capacity for usage-based overflow detection.
 * @param reservedMaxTokens - requested output allowance before SDK context clamping.
 * @returns the mapped harness reason. Recognized error text, `stop` usage above
 *   `contextWindow`, and zero-output `length` usage that fills the window map
 *   to `CONTEXT_WINDOW_EXCEEDED`; a `stop` with no content blocks maps to an
 *   `EMPTY_RESPONSE` error. Other empty `length` responses map to `INVALID_REQUEST`
 *   with output-limit or compaction guidance. Terminal `pending` and `deferred`
 *   states map to non-retryable `PI_AI_ERROR` failures.
 */
export declare function mapStopReason(message: AssistantMessage, contextWindow?: number, reservedMaxTokens?: number): FinishReason;
/**
 * Translate the pi-ai event stream into StreamChunks. pi-ai never throws
 * mid-stream — failures arrive as `error` events, which become error/aborted
 * `finish` chunks (the harness protocol's other error-delivery style).
 * @param events - one assistant turn's pi-ai event stream.
 * @param contextWindow - resolved catalog capacity for usage-based overflow detection.
 * @param callerSignal - caller cancellation state; an aborted caller makes any
 *   in-band terminal error an aborted finish.
 * @param requestedModel - request model identity recorded for durable replay.
 * @param requestedProvider - DSH provider identity recorded for durable replay.
 * @param reservedMaxTokens - requested output allowance before SDK context clamping.
 * @returns the harness chunks, ending with measured `usage` then `finish`;
 *   failures with no measured tokens omit usage to preserve context pressure. Throws
 *   `LlmError` (`STREAM_CLOSED`) if the source ends without a terminal event.
 */
export declare function toStreamChunks(events: AsyncIterable<AssistantMessageEvent>, contextWindow?: number, callerSignal?: AbortSignal, requestedModel?: string, requestedProvider?: string, reservedMaxTokens?: number): AsyncGenerator<StreamChunk>;
