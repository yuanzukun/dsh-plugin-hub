import type { ClineAccountSettlement } from './adapter.ts'
import { accountRefOf, accountsOf, moveAccountFirst, type ClineAccountSwitch } from './accounts.ts'
import { accountCommitMatches, accountSelectionPatch, commitAccountSettings } from './account-commit.ts'
import type { ClinePassConfig } from './config.ts'

import { accountSettingsRow, settingsWriteResult, type AccountSettingsWriter } from './settings-bridge.ts'
export type { AccountSettingsWriter } from './settings-bridge.ts'

function identity(config: ClinePassConfig): string {
  return JSON.stringify([config.enabled, accountRefOf(config), config.accounts, config.autoSwitch, config.baseURL, config.proxyURL])
}

/** Owns both the fallback notice and its optional persisted account selection. */
export class ClineAccountSelection {
  private settings: AccountSettingsWriter | undefined
  private connection = 0
  private credentials = 0
  private version = 0
  private signature = ''
  private latestSeq = -1
  private notice: ClineAccountSwitch | undefined

  constructor(
    private readonly config: () => ClinePassConfig,
    private readonly logger: { debug(message: string): void; warn(message: string): void },
  ) {}

  connect(settings: AccountSettingsWriter): () => void {
    this.settings = settings
    this.connection++
    this.capture()
    return () => {
      if (this.settings !== settings) return
      this.settings = undefined
      this.connection++
      this.capture()
    }
  }

  private row() {
    try {
      return this.settings && accountSettingsRow(this.settings)
    } catch { return undefined }
  }

  /** Reading the revision also catches A → C → A before async change watchers run. */
  capture(): number {
    const row = this.row()
    const signature = JSON.stringify([identity(this.config()), this.connection, this.credentials, row?.ns, row?.revision])
    if (signature !== this.signature) {
      this.signature = signature
      this.version++
      this.notice = undefined
    }
    return this.version
  }

  credentialChanged(): void {
    this.credentials++
    this.capture()
  }

  lastSwitch(): ClineAccountSwitch | undefined {
    this.capture()
    return this.notice
  }

  /** One freshness decision governs both side effects of a request's outcome. */
  settle(event: ClineAccountSettlement): void {
    if (event.generation !== this.capture() || event.seq < this.latestSeq) return
    const config = this.config()
    if (identity(config) !== identity(event.config)
      || !accountsOf(config).some(account => account.apiKeyEnv === event.ref)) return
    this.latestSeq = event.seq
    this.notice = event.notice
    if (event.notice && config.enabled && config.autoSwitch) void this.adopt(event)
  }

  private async adopt(event: ClineAccountSettlement): Promise<void> {
    const settings = this.settings
    if (!settings) return
    const connection = this.connection
    const credentials = this.credentials
    try {
      const row = this.row()
      if (!row) {
        this.logger.debug('llm-clinepass: no editable account settings row; the fallback stays per request')
        return
      }
      const selected = (row.value as { apiKeyEnv?: unknown } | undefined)?.apiKeyEnv
      // describe() may itself publish settings events. Recheck immediately
      // before the revision-guarded write, including the stored selection.
      if (event.generation !== this.capture() || event.seq !== this.latestSeq
        || selected !== accountRefOf(event.config)) return
      const accounts = [...moveAccountFirst(accountsOf(event.config), event.ref)]
      const expected = identity({ ...event.config, accounts, apiKeyEnv: event.ref })
      const result = await commitAccountSettings(settings, row, accountSelectionPatch(accounts, event.ref))
      // A committed selection invalidates in-flight requests like any settings
      // edit. Restore its notice only after confirming this exact write. No
      // pending reference can leak from a refused write into a later user edit.
      this.capture()
      const committed = this.row()
      if (settingsWriteResult(result, () => this.connection === connection && this.credentials === credentials
        && event.seq === this.latestSeq && accountCommitMatches(row, committed)
        && identity(this.config()) === expected, 'observed') === 'applied') this.notice = event.notice
    } catch (error: unknown) {
      this.logger.warn(`llm-clinepass: could not make "${event.ref}" the current account (${String(error)})`)
    }
  }
}
