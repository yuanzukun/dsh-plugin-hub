/**
 * The ClinePass settings page's staged form over the `llm-clinepass`
 * settings namespace, plus the gateway model listing the page reports.
 *
 * The key is the one control that does not live in the section: its literal
 * never rides a response, so the page learns only whether one is configured
 * and writes it through the host account service, pinned to the account where
 * the draft began. It is still staged with the rest of the form, so one save
 * covers everything the page shows.
 */

import type { Context as ClientContext } from '@deepseek-ai/cordis'
// Type-only: pulls the ctx.remote merge into this program.
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol'
import type { ClineModel, ClineModelCatalog } from '../models-contract.ts'
import type { AnalyticsQuery, AnalyticsReport } from '../analytics-contract.ts'
import type { ClineUsage } from '../usage-contract.ts'
import { PROVIDER_ID } from '../provider-identity.ts'
import { DEFAULT_USAGE_DISPLAY, USAGE_DISPLAY_MODES, type UsageDisplayMode } from '../usage-display.ts'
import type {} from '@deepseek-ai/dsh-api-settings-controller/remote'
import type { SnapshotStore } from '@deepseek-ai/dsh-client-store'
import type { SettingsScope, SettingsScopeSnapshot } from './settings.ts'
import type { ClineAccount } from '../accounts.ts'
import { accountsOf, accountRefOf } from '../accounts.ts'
import { SETTINGS_NAMESPACE } from '../config-contract.ts'
import { settingsWriteResult } from '../settings-bridge.ts'
import type { ClinePassSettings, ClinePassModelLimit, ClinePassModelLimits } from '../config-contract.ts'
export type { ClinePassSettings, ClinePassModelLimit, ClinePassModelLimits } from '../config-contract.ts'
import { assertProxyURL } from '../proxy-url.ts'
import { ClineAccountsController, type ClineAccountsState, type ClineAccountsActions, type ExecuteAccountCommand } from './accounts-controller.ts'
import {
  StagedForm,
  booleanField,
  jsonField,
  numberField,
  textField,
  type FieldState,
  type FormActions,
  type FormShell,
} from './staged-form.ts'

/** Namespace shared with the host through the browser-safe configuration contract. */
export const CLINEPASS_NS = SETTINGS_NAMESPACE

/** Form field the credential control stages under. */
const API_KEY_FIELD = 'apiKey'

/** What the credentials domain last reported, and for which reference. */
interface CredentialState {
  /** Reference this answer describes; a stale response for another one is dropped. */
  ref: string
  /** Whether any layer supplies a value for it. */
  configured: boolean
  /** Whether `credentials/set` can affect it; false disables the control. */
  writable: boolean
}

/** The gateway's model listing as the page reports it. */
export type ClinePassModels =
  /** Not asked for yet; the page asks once it mounts. */
  | { readonly status: 'idle' }
  /** A listing request is outstanding. */
  | { readonly status: 'loading' }
  /**
   * The gateway answered: a count/preview for the compact summary plus every
   * discovered entry used by the capacity editor.
   */
  | {
    readonly status: 'ready'
    readonly count: number
    readonly preview: readonly string[]
    readonly entries: readonly ClineModel[]
    readonly stale?: boolean
    readonly message?: string
    readonly refreshing?: boolean
    readonly sources?: ClineModelCatalog['sources']
  }
  /** The listing could not be read; `message` is the Host's own diagnostic. */
  | { readonly status: 'failed'; readonly message?: string; readonly sources?: ClineModelCatalog['sources'] }

/** What the settings page renders. */
export interface ClinePassSectionState extends FormShell {
  accounts?: ClineAccountsState
  /**
   * Whether the adapter currently serves its route. Resolved from the section
   * rather than staged: the switch writes on the click that flips it, because
   * a withdrawn route is what the user is trying to observe.
   */
  enabled: boolean
  usageDisplay: FieldState
  modelVisibility: Readonly<Record<string, boolean>>
  pickerSaving: boolean
  pickerFailed: boolean
  /** The gateway endpoint. */
  baseURL: FieldState
  proxyURL: FieldState
  /** Live catalog re-resolution interval, in minutes. */
  refreshMinutes: FieldState
  /** Largest idle gap between stream events, in milliseconds. */
  streamIdleTimeoutMs: FieldState
  /** Optional retained image occurrence cap; blank inherits the base configuration. */
  maxImages: FieldState
  /** Accumulated base64 image payload bound for one request. */
  maxRequestImageBytes: FieldState
  /** Total-pixel budget for one request image. */
  requestImagePixelBudget: FieldState
  /** Raw encoded-byte target for one request image. */
  requestImageMaxBytes: FieldState
  /** The staged credential, which starts blank on every load. */
  apiKey: FieldState
  /** Whether the Host reports a credential configured for the referenced key. */
  apiKeyConfigured: boolean
  /** Whether the credentials domain accepts a write for it; false disables the control. */
  apiKeyWritable: boolean
  /** The gateway's current model listing. */
  models: ClinePassModels
  /** The staged JSON field backing the capacity table. */
  modelLimits: FieldState
  /** The parsed overrides currently shown by the capacity table. */
  modelLimitDraft: ClinePassModelLimits
}

/** The registration-side face the page's slot entry injects. */
export interface ClinePassSectionFace extends FormActions, ClineAccountsActions {
  hooks: {
    /** Page snapshot bound by the UI renderer as useClinePass. */
    clinePass: SnapshotStore<ClinePassSectionState>
  }
  /** Read the gateway's model listing, now or again after a failure. */
  loadModels: () => void
  /** Read one aggregate usage report over local session history. */
  readAnalytics: (query: AnalyticsQuery, signal?: AbortSignal) => Promise<AnalyticsReport>
  /** Read one account's official quota; the dashboard shows it beside the estimate. */
  readQuota: (ref: string) => Promise<ClineUsage>
  /**
   * Turn the adapter's route on or off, writing immediately.
   * @param next - the state the switch asks for.
   */
  setEnabled: (next: boolean) => void
  setModelEnabled: (id: string, next: boolean) => void
}

/** Bridges the `llm-clinepass` scope and the credentials domain onto the page. */
export class ClinePassSectionController {
  private readonly form: StagedForm
  private readonly store: SnapshotStore<ClinePassSectionState>
  private credential: CredentialState = { ref: '', configured: false, writable: true }
  private models: ClinePassModels = { status: 'idle' }
  private modelsRequest = 0
  private pickerSaving = false
  private pickerFailed = false
  private face: ClinePassSectionFace | undefined
  private readonly unsubscribe: () => void
  private accounts: ClineAccountsController | undefined
  private credentialRequest = 0
  private keyDraftRef: string | undefined

  /**
   * @param scope - the bound settings scope for the `llm-clinepass` namespace.
   * @param ctx - the page plugin's context, whose `remote.credentials` namespace
   *   answers for the credential the section references.
   */
  constructor(
    private readonly scope: SettingsScope<ClinePassSettings>,
    private readonly ctx: ClientContext,
    private readonly readModels: () => Promise<RemoteResult<ClineModelCatalog>> = async () => {
      const result = await ctx.remote.llm.discoverModels(CLINEPASS_NS, { provider: PROVIDER_ID })
      return result.ok ? { ok: true, value: { models: result.value, stale: false } } : result
    },
    private readonly readUsage: (ref: string) => Promise<ClineUsage> = async ref => {
      const result = await ctx.remote.clinePassUsage.readAccount(ref)
      if (!result.ok) throw result.error
      return result.value
    },
    private readonly executeAccountCommand: ExecuteAccountCommand = async command => {
      const result = await ctx.remote.clinePassAccounts.execute(command)
      return result.ok ? result.value : 'unknown'
    },
    private readonly readAnalytics: (query: AnalyticsQuery, signal?: AbortSignal) => Promise<AnalyticsReport> = async () => {
      throw Object.assign(new Error('ClinePass analytics is unavailable in this session'), {
        code: 'clinepass/analytics-unavailable', details: { reason: 'no-session-query', retryable: false },
      })
    },
  ) {
    this.form = new StagedForm(
      scope as SettingsScope<Record<string, unknown>>,
      [
        // Present so the shared override/reset machinery tracks the field; the
        // page's switch writes it directly instead of staging it.
        booleanField('enabled'),
        {
          field: 'usageDisplay',
          format: value => typeof value === 'string' ? value : DEFAULT_USAGE_DISPLAY,
          parse: text => USAGE_DISPLAY_MODES.some(mode => mode === text) ? { kind: 'set', value: text } : undefined,
        },
        textField('baseURL'),
        {
          ...textField('proxyURL'),
          // Blank explicitly disables an inherited proxy; Reset removes the override.
          parse: text => {
            try { assertProxyURL(text); return { kind: 'set', value: text.trim() } }
            catch { return undefined }
          },
        },
        numberField('refreshMinutes'),
        numberField('streamIdleTimeoutMs'),
        numberField('maxImages', value => Number.isSafeInteger(value) && value > 0),
        numberField('maxRequestImageBytes'),
        numberField('requestImagePixelBudget'),
        numberField('requestImageMaxBytes'),
        jsonField('modelLimits'),
      ],
      [{ field: API_KEY_FIELD, write: text => this.writeKey(text) }],
    )
    this.store = this.form.bind(() => this.projection())
    this.accounts = new ClineAccountsController(scope, ctx, readUsage,
      () => { this.store.set(this.projection()) },
      () => this.form.shell().saving || this.pickerSaving || Boolean(this.form.field(API_KEY_FIELD).text.trim()),
      this.executeAccountCommand)
    this.store.set(this.projection())
    const networkIdentity = () => JSON.stringify([
      scope.getSnapshot().value?.baseURL, scope.getSnapshot().value?.proxyURL,
    ])
    let modelsEndpoint = networkIdentity()
    this.unsubscribe = scope.subscribe(() => {
      this.accounts?.sync()
      this.store.set(this.projection())
      const endpoint = networkIdentity()
      if (endpoint !== modelsEndpoint) {
        modelsEndpoint = endpoint
        this.modelsRequest++
        this.models = { status: 'idle' }
        this.store.set(this.projection())
      }
      void this.readCredential()
    })
    void this.readCredential()
  }

  /** Release subscriptions without disposing the host's shared form. */
  dispose(): void {
    this.credentialRequest++
    this.accounts?.dispose()
    this.modelsRequest++
    this.unsubscribe()
    this.form.dispose()
  }

  private projection(): ClinePassSectionState {
    return {
      ...this.form.shell(),
      saving: this.form.shell().saving || this.accounts?.snapshot().busy === true,
      accounts: this.accounts?.snapshot(),
      enabled: this.enabled(),
      usageDisplay: this.form.field('usageDisplay'),
      modelVisibility: this.scope.getSnapshot().value?.modelVisibility ?? {},
      pickerSaving: this.pickerSaving,
      pickerFailed: this.pickerFailed,
      baseURL: this.form.field('baseURL'),
      proxyURL: this.form.field('proxyURL'),
      refreshMinutes: this.form.field('refreshMinutes'),
      streamIdleTimeoutMs: this.form.field('streamIdleTimeoutMs'),
      maxImages: this.form.field('maxImages'),
      maxRequestImageBytes: this.form.field('maxRequestImageBytes'),
      requestImagePixelBudget: this.form.field('requestImagePixelBudget'),
      requestImageMaxBytes: this.form.field('requestImageMaxBytes'),
      apiKey: this.form.field(API_KEY_FIELD),
      apiKeyConfigured: this.credential.ref === refOf(this.scope.getSnapshot()) && this.credential.configured
        && accountsOf(this.scope.getSnapshot().value ?? {}).length > 0,
      apiKeyWritable: this.credential.writable,
      models: this.models,
      modelLimits: this.form.field('modelLimits'),
      modelLimitDraft: this.limitDraft(),
    }
  }

  /**
   * Read the overrides as the page currently shows them. A staged JSON draft
   * wins while it is valid; malformed text falls back to the last accepted
   * settings value so the table never renders phantom rows.
   */
  private limitDraft(): ClinePassModelLimits {
    const staged = this.form.field('modelLimits')
    if (staged.invalid) return modelLimitsOf(this.scope.getSnapshot().value?.modelLimits)
    if (staged.overridden || this.form.shell().dirty) {
      try {
        return modelLimitsOf(JSON.parse(staged.text) as unknown)
      } catch {
        return modelLimitsOf(this.scope.getSnapshot().value?.modelLimits)
      }
    }
    return modelLimitsOf(this.scope.getSnapshot().value?.modelLimits)
  }

  /**
   * The adapter's effective switch state: the resolved section's value, over
   * the Host's own default when the section carries none.
   * @returns whether the route is currently served.
   */
  private enabled(): boolean {
    return this.scope.getSnapshot().value?.enabled ?? true
  }

  /**
   * Flip the switch by writing the field on the click itself.
   *
   * Like the per-model switches, this control does not wait for Save: the point
   * of turning it off is to watch the models leave the pickers, and the point
   * of turning it back on is to use the route again — staging either behind a
   * second gesture would report a state the Host does not hold. The write is
   * revision-fenced by the scope like every other, and a refusal surfaces as a
   * failed save through the shared shell rather than a silent revert.
   * @param next - the state the switch asks for.
   */
  async setEnabled(next: boolean): Promise<void> {
    await this.writePickerSetting('enabled', next, () => this.enabled() === next)
  }

  /** Each model switch has one committed value and takes effect without Save. */
  async setModelEnabled(id: string, next: boolean): Promise<void> {
    if (this.models.status === 'ready' && this.models.entries.some(model => model.id === id && model.configurationMissing)) return
    await this.writePickerSetting('modelVisibility',
      { ...this.scope.getSnapshot().value?.modelVisibility, [id]: next },
      () => this.scope.getSnapshot().value?.modelVisibility?.[id] === next)
  }

  /** Serialize immediate switches with form saves; refused writes retain committed values. */
  private async writePickerSetting(field: string, value: unknown, accepted: () => boolean): Promise<void> {
    if (this.pickerSaving || this.form.shell().saving || this.accounts?.snapshot().busy || !this.scope.getSnapshot().writable) return
    this.pickerSaving = true
    this.pickerFailed = false
    this.store.set(this.projection())
    try {
      const verdict = await this.scope.set(field, value)
      this.pickerFailed = settingsWriteResult(verdict, accepted) !== 'applied'
    } catch {
      this.pickerFailed = true
    } finally {
      this.pickerSaving = false
      this.store.set(this.projection())
    }
  }

  /**
   * Read the gateway's model listing through the Host's discovery for this
   * adapter. Called when the page mounts and again from its refresh control.
   * A rejection settles as a failure too: the refresh control is disabled
   * while loading and the next read starts only from `idle`, so leaving the
   * state loading would strand the page with no way to ask the gateway again.
   */
  loadModels(): void {
    const request = ++this.modelsRequest
    const previous = this.models.status === 'ready' ? this.models : undefined
    this.models = previous ? { ...previous, refreshing: true } : { status: 'loading' }
    this.store.set(this.projection())
    const failed = (message: string): void => {
      this.models = previous
        ? { ...previous, refreshing: false, stale: true, message, sources: undefined }
        : { status: 'failed', message }
    }
    // A later read owns the page, including its cached entries and diagnostic.
    void this.readModels()
      .then((response) => {
        if (request !== this.modelsRequest) return
        if (!response.ok) failed(response.error.message)
        else if (response.value.stale && response.value.models.length === 0) {
          this.models = { status: 'failed', ...(response.value.error ? { message: response.value.error } : {}),
            ...(response.value.sources ? { sources: response.value.sources } : {}) }
        } else {
          this.models = {
            status: 'ready',
            count: response.value.models.length,
            preview: response.value.models.map(model => model.name ?? model.id),
            entries: response.value.models,
            stale: response.value.stale,
            ...(response.value.sources ? { sources: response.value.sources } : {}),
            ...(response.value.error ? { message: response.value.error } : {}),
          }
        }
        this.store.set(this.projection())
      })
      .catch((error: unknown) => {
        if (request !== this.modelsRequest) return
        failed(error instanceof Error ? error.message : String(error))
        this.store.set(this.projection())
      })
  }

  /**
   * Ask the credentials domain about the reference the section currently names.
   *
   * The answer is stored with the reference it describes: `apiKeyEnv` can
   * change between the request and its response, and two reads can settle out
   * of order, so a response is published only while it still answers for the
   * reference in force.
   */
  private async readCredential(): Promise<void> {
    const request = ++this.credentialRequest
    const ref = refOf(this.scope.getSnapshot())
    if (accountsOf(this.scope.getSnapshot().value ?? {}).length === 0) {
      this.credential = { ref, configured: false, writable: false }
      this.store.set(this.projection())
      return
    }
    if (ref !== this.credential.ref) {
      // A new reference knows nothing yet; keeping the old answer would claim
      // the key is configured under a name nobody has checked.
      this.credential = { ref, configured: false, writable: true }
      this.store.set(this.projection())
    }
    const response = await this.ctx.remote.credentials.describe([ref]).catch(() => undefined)
    if (!response?.ok || request !== this.credentialRequest || ref !== refOf(this.scope.getSnapshot())) return
    const view = response.value[ref]
    const next: CredentialState = {
      ref,
      configured: view?.configured ?? false,
      // An unknown reference is treated as writable: the control stays usable
      // and the Host is what refuses, rather than the page guessing a refusal.
      writable: view?.writable ?? true,
    }
    if (next.configured === this.credential.configured && next.writable === this.credential.writable) return
    this.credential = next
    this.store.set(this.projection())
  }

  /**
   * Re-read after the Host reports a change to the reference this page watches.
   *
   * A key can be written from somewhere else — the Models page addresses the
   * same reference — and the settings section does not change when it is, so
   * without this the badge keeps reporting a state the Host already replaced.
   * @param ref - the reference the Host reports as changed.
   */
  refreshCredential(ref: string): void {
    this.accounts?.invalidate(ref)
    if (ref !== this.credential.ref) return
    void this.readCredential()
  }

  /**
   * Build the face the page's slot registration injects. Built once: the store
   * is what changes, and the renderer binds the same callbacks across renders.
   * @returns the page snapshot and its form actions.
   */
  inject(): ClinePassSectionFace {
    this.face ??= {
      hooks: { clinePass: this.store },
      loadModels: () => { this.loadModels() },
      readAnalytics: (query, signal) => this.readAnalytics(query, signal),
      readQuota: (ref) => this.readUsage(ref),
      setEnabled: (next) => { void this.setEnabled(next) },
      setModelEnabled: (id, next) => { void this.setModelEnabled(id, next) },
      ...this.form.actions(),
      ...this.accounts!.actions(),
      edit: (field, text) => {
        if (field === API_KEY_FIELD) {
          if (text.trim()) this.keyDraftRef ??= refOf(this.scope.getSnapshot())
          else this.keyDraftRef = undefined
        }
        this.form.actions().edit(field, text)
      },
      discard: () => { this.keyDraftRef = undefined; this.form.actions().discard() },
      save: () => {
        if (!this.accounts?.snapshot().busy) void this.form.save().then(() => {
          if (!this.form.field(API_KEY_FIELD).text.trim()) this.keyDraftRef = undefined
        })
      },
    }
    return this.face
  }

  /**
   * Ask the account service to write the staged key, then refresh its display.
   * @param value - the staged credential literal.
   * @returns whether the Host confirmed the write.
   */
  private async writeKey(value: string): Promise<boolean> {
    const ref = this.keyDraftRef ?? refOf(this.scope.getSnapshot())
    if (await this.executeAccountCommand({ kind: 'replace-key', ref, key: value }) !== 'applied') return false
    this.accounts?.invalidate(ref)
    await this.readCredential()
    return true
  }
}

/**
 * Read a stored override map without trusting its hand-editable shape. Only
 * positive safe integers and explicit catalog resets are accepted by the table.
 */
function modelLimitsOf(value: unknown): ClinePassModelLimits {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return {}
  const limits: ClinePassModelLimits = {}
  for (const [id, entry] of Object.entries(value as Record<string, unknown>)) {
    if (entry === null) { limits[id] = null; continue }
    if (typeof entry !== 'object' || Array.isArray(entry)) continue
    const fields = entry as Record<string, unknown>
    const limit: ClinePassModelLimit = {}
    if (fields.contextWindow === null) limit.contextWindow = null
    if (fields.maxTokens === null) limit.maxTokens = null
    if (fields.thinkingBudgets === null) limit.thinkingBudgets = null
    if (Array.isArray(fields.thinkingBudgets) && fields.thinkingBudgets.length <= 16
      && fields.thinkingBudgets.every(value => typeof value === 'number' && Number.isSafeInteger(value) && value > 0)) {
      limit.thinkingBudgets = fields.thinkingBudgets
    }
    if (typeof fields.contextWindow === 'number' && Number.isSafeInteger(fields.contextWindow) && fields.contextWindow > 0) {
      limit.contextWindow = fields.contextWindow
    }
    if (typeof fields.maxTokens === 'number' && Number.isSafeInteger(fields.maxTokens) && fields.maxTokens > 0) {
      limit.maxTokens = fields.maxTokens
    }
    if (limit.contextWindow !== undefined || limit.maxTokens !== undefined || limit.thinkingBudgets !== undefined) limits[id] = limit
  }
  return limits
}

/**
 * The credential reference the section names, or the provider's default.
 * @param snapshot - the current scope snapshot.
 * @returns the reference to address.
 */
function refOf(snapshot: SettingsScopeSnapshot<ClinePassSettings>): string {
  return accountRefOf(snapshot.value ?? {})
}
