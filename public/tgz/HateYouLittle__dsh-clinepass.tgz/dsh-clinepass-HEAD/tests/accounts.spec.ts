import { afterEach, expect, it, vi } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import Gateway from '@deepseek-ai/dsh-api-gateway'
import Registry from '@deepseek-ai/dsh-typert-registry'
import LlmRuntime, { createUserMessage, LlmError } from '@deepseek-ai/dsh-llm'
import type { GenerateOptions, StreamChunk } from '@deepseek-ai/dsh-llm'
import { accountsOf, assertAccounts } from '../src/accounts.ts'
import { Config, PlainConfig, type LiveConfig, type ClinePassConfig } from '../src/config.ts'
import { ClinePassAdapter } from '../src/adapter.ts'
import { ClinePassRequestExecutor } from '../src/request-executor.ts'
import { apply } from '../src/index.ts'
import { configOf } from './config-of.ts'
import { mockGateway, listingBody, textEvents, closeMockGateways } from './mock-gateway.ts'

const accounts = [
  { id: 'a', name: 'Primary', apiKeyEnv: 'ACCOUNT_A' },
  { id: 'b', name: 'Backup', apiKeyEnv: 'ACCOUNT_B' },
]
const request = () => ({ provider: 'dsh-clinepass', model: 'cline-pass/deepseek-v4.1-flash', sessionId: 'account-session' as never,
  messages: [createUserMessage({ content: [{ type: 'text', text: 'hello' }], source: { kind: 'plugin', plugin: 'test' } })] })
const drain = async (stream: AsyncIterable<StreamChunk>) => { const chunks: StreamChunk[] = []; for await (const chunk of stream) chunks.push(chunk); return chunks }
afterEach(closeMockGateways)

it('preserves legacy credential configuration and distinguishes explicitly removing every account', () => {
  expect(PlainConfig().accounts).not.toEqual([])
  expect(accountsOf(PlainConfig())).toEqual([{ id: 'legacy:CLINE_API_KEY', name: '', apiKeyEnv: 'CLINE_API_KEY' }])
  expect(accountsOf({ accounts: [], apiKeyEnv: 'ACCOUNT_A' })).toEqual([])
  expect(accountsOf({ accounts, apiKeyEnv: 'ACCOUNT_A' })).toEqual(accounts)
  expect(() => assertAccounts([...accounts, { ...accounts[0]!, id: 'duplicate' }])).toThrow(/duplicate/)
  expect(() => assertAccounts([{ ...accounts[0]!, apiKeyEnv: 'not a reference' }])).toThrow(/Invalid/)
  expect(() => assertAccounts(Array.from({ length: 21 }, (_, i) => ({ id: String(i), name: String(i), apiKeyEnv: `KEY_${i}` })))).toThrow(/20/)
})

it.each([
  { status: 401, message: 'Invalid API key', reason: 'credential' },
  { status: 429, message: 'Monthly usage limit exceeded', reason: 'quota' },
])('tries the next account before output after $message, preserving model, transcript and session identity', async failure => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: failure.status, body: JSON.stringify({ error: { message: failure.message } }) })
  gateway.pushCompletions({ events: textEvents })
  const config = configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true })
  const switched = vi.fn()
  const adapter = new ClinePassAdapter({ config: () => config, resolveApiKey: async config => `${config.apiKeyEnv}-secret`, onAccountSwitch: switched })
  const chunks = await drain(adapter.stream(request()))
  expect(chunks.filter(chunk => chunk.type === 'finish')).toEqual([expect.objectContaining({ reason: { kind: 'stop' } })])
  expect(chunks.filter(chunk => chunk.type === 'usage')).toHaveLength(1)
  const headers = gateway.headers.filter(header => header.authorization)
  expect(headers.map(header => header.authorization)).toEqual(['Bearer ACCOUNT_A-secret', 'Bearer ACCOUNT_B-secret'])
  expect(headers.map(header => header['x-task-id'])).toEqual(['account-session', 'account-session'])
  expect(gateway.bodies[0]).toEqual(gateway.bodies[1])
  expect(config.apiKeyEnv).toBe('ACCOUNT_A')
  expect(switched).toHaveBeenCalledWith({ fromRef: 'ACCOUNT_A', toRef: 'ACCOUNT_B', reason: failure.reason, at: expect.any(Number) }, expect.any(Object), expect.any(Number))
  expect(JSON.stringify(switched.mock.calls)).not.toContain('secret')
})

it.each([
  { mode: 'direct', sessionId: undefined },
  { mode: 'direct', sessionId: '' },
  { mode: 'prepared', sessionId: undefined },
  { mode: 'prepared', sessionId: '' },
])('keeps one fallback session across account attempts for $mode calls with sessionId=$sessionId', async ({ mode, sessionId }) => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: 401, body: JSON.stringify({ error: { message: 'Invalid API key' } }) })
  gateway.pushCompletions({ events: textEvents })
  const config = configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true })
  const adapter = new ClinePassAdapter({ config: () => config, resolveApiKey: async config => `${config.apiKeyEnv}-secret` })
  const input = Object.freeze({ ...request(), sessionId: sessionId as GenerateOptions['sessionId'] })
  try {
    const stream = mode === 'prepared'
      ? (await adapter.prepareCall(input.provider, input.model)).stream
      : adapter.stream.bind(adapter)
    expect((await drain(stream(input))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    const attempts = gateway.headers.filter(header => header.authorization)
    expect(attempts.map(header => header.authorization)).toEqual(['Bearer ACCOUNT_A-secret', 'Bearer ACCOUNT_B-secret'])
    const identity = attempts[0]?.['x-task-id']
    expect(identity).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/)
    expect(attempts[1]?.['x-task-id']).toBe(identity)

    // Reusing the caller envelope or prepared stream is a new logical call.
    gateway.pushCompletions({ events: textEvents })
    expect((await drain(stream(input))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    expect(gateway.headers.at(-1)?.['x-task-id']).not.toBe(identity)
    expect(input.sessionId).toBe(sessionId)
  } finally { await adapter.dispose() }
})

it.each([
  { status: 429, message: 'Rate limit exceeded' },
  { status: 403, message: 'Forbidden' },
  { status: 503, message: 'Service unavailable' },
  { status: 400, message: 'Invalid request' },
])('keeps $status $message in host recovery instead of trying another account', async failure => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: failure.status, body: JSON.stringify({ error: { message: failure.message } }) })
  const adapter = new ClinePassAdapter({ config: () => configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }),
    resolveApiKey: async config => config.apiKeyEnv })
  const chunks = await drain(adapter.stream(request()))
  expect(chunks.at(-1)).toMatchObject({ type: 'finish', reason: { kind: 'error' } })
  expect(gateway.bodies).toHaveLength(1)
})

it('leaves automatic fallback off by default and bounds all-rejected attempts to the number of accounts', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  const rejection = { status: 401, body: JSON.stringify({ error: { message: 'Invalid API key' } }) }
  gateway.pushCompletions(rejection)
  let config = configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A' })
  const adapter = new ClinePassAdapter({ config: () => config, resolveApiKey: async config => config.apiKeyEnv })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'error' } })
  expect(gateway.bodies).toHaveLength(1)
  config = { ...config, autoSwitch: true }
  gateway.pushCompletions(rejection)
  gateway.pushCompletions(rejection)
  const chunks = await drain(adapter.stream(request()))
  expect(gateway.bodies).toHaveLength(3)
  expect(chunks.filter(chunk => chunk.type === 'finish')).toHaveLength(1)
})

it('does not replay a partially emitted response on another account', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ events: textEvents.slice(0, 2) })
  const adapter = new ClinePassAdapter({ config: () => configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }),
    resolveApiKey: async config => config.apiKeyEnv })
  const chunks = await drain(adapter.stream(request()))
  expect(chunks.some(chunk => chunk.type === 'text-delta')).toBe(true)
  expect(chunks.at(-1)).toMatchObject({ reason: { kind: 'error' } })
  expect(gateway.bodies).toHaveLength(1)
})

it.each(['finish', 'throw'])('does not retry billed work after usage is received and the attempt fails by %s', async failureMode => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  const adapter = new ClinePassAdapter({ config: () => configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }),
    resolveApiKey: async config => config.apiKeyEnv })
  const attempt = vi.spyOn(ClinePassRequestExecutor.prototype, 'stream').mockImplementation(async function* (): AsyncIterable<StreamChunk> {
    yield { type: 'usage', usage: { inputTokens: 3, outputTokens: 0, totalTokens: 3 } }
    if (failureMode === 'throw') throw new LlmError('Monthly usage limit exceeded', 'QUOTA')
    yield { type: 'finish', reason: { kind: 'error', failure: { code: 'QUOTA', message: 'Monthly usage limit exceeded' } } }
  })
  try {
    if (failureMode === 'throw') await expect(drain(adapter.stream(request()))).rejects.toMatchObject({ code: 'QUOTA' })
    else expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'error', failure: { code: 'QUOTA' } } })
    expect(attempt).toHaveBeenCalledTimes(1)
  } finally { attempt.mockRestore() }
})

it('attributes a multi-hop fallback notice to the first account that failed', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: 429, body: JSON.stringify({ error: { message: 'Monthly usage limit exceeded' } }) })
  gateway.pushCompletions({ status: 401, body: JSON.stringify({ error: { message: 'Invalid API key' } }) })
  gateway.pushCompletions({ events: textEvents })
  const three = [...accounts, { id: 'c', name: 'Third', apiKeyEnv: 'ACCOUNT_C' }]
  const config = configOf(gateway.url, { accounts: three, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true })
  const switched = vi.fn()
  const adapter = new ClinePassAdapter({ config: () => config, resolveApiKey: async config => config.apiKeyEnv, onAccountSwitch: switched })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  expect(switched).toHaveBeenCalledWith({ fromRef: 'ACCOUNT_A', toRef: 'ACCOUNT_C', reason: 'quota', at: expect.any(Number) }, expect.any(Object), expect.any(Number))
})

it('skips a gateway-rejected key on later requests until the credential changes', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  const rejection = { status: 401, body: JSON.stringify({ error: { message: 'Invalid API key' } }) }
  gateway.pushCompletions(rejection)
  gateway.pushCompletions({ events: textEvents })
  const config = configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true })
  const adapter = new ClinePassAdapter({ config: () => config, resolveApiKey: async config => config.apiKeyEnv })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  expect(gateway.bodies).toHaveLength(2)
  gateway.pushCompletions({ events: textEvents })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  // The rejected preferred key is not re-sent; the backup answers directly.
  expect(gateway.bodies).toHaveLength(3)
  expect(gateway.headers.filter(header => header.authorization).at(-1)!.authorization).toBe('Bearer ACCOUNT_B')
  // A stored change to the reference outranks the remembered rejection.
  adapter.forgetRejectedKey('ACCOUNT_A')
  gateway.pushCompletions(rejection)
  gateway.pushCompletions({ events: textEvents })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  expect(gateway.bodies).toHaveLength(5)
})

it.each(['ACCOUNT_A', 'ACCOUNT_B'] as const)(
  'fences late credential rejections only for the reference that changed (%s)', async changedRef => {
    const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
    gateway.pushCompletions({ status: 401, body: JSON.stringify({ error: { message: 'Invalid API key' } }) })
    gateway.pushCompletions({ events: textEvents })
    gateway.pushCompletions({ events: textEvents })
    const started = Promise.withResolvers<void>(), release = Promise.withResolvers<void>()
    const fetcher = globalThis.fetch
    vi.stubGlobal('fetch', async (input: string | URL | Request, init?: RequestInit) => {
      if (new Headers(init?.headers ?? (input instanceof Request ? input.headers : undefined)).get('Authorization') === 'Bearer old-key') {
        started.resolve()
        await release.promise
      }
      return fetcher(input, init)
    })
    let keyA = 'old-key', generation = 0
    const config = configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true })
    const adapter = new ClinePassAdapter({ config: () => config, accountGeneration: () => generation,
      resolveApiKey: async config => config.apiKeyEnv === 'ACCOUNT_A' ? keyA : 'backup-key' })
    const old = drain(adapter.stream(request()))
    try {
      await started.promise
      if (changedRef === 'ACCOUNT_A') keyA = 'new-key'
      generation++
      adapter.forgetRejectedKey(changedRef)
    } finally { release.resolve() }
    expect((await old).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    try {
      expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
      expect(gateway.headers.filter(header => header.authorization).map(header => header.authorization)).toEqual([
        'Bearer old-key', 'Bearer backup-key', changedRef === 'ACCOUNT_A' ? 'Bearer new-key' : 'Bearer backup-key',
      ])
    } finally { await adapter.dispose() }
  },
)

it('isolates rejected credentials by gateway while retaining each gateway rejection', async () => {
  const first = await mockGateway({ status: 200, body: listingBody([request().model]) })
  const second = await mockGateway({ status: 200, body: listingBody([request().model]) })
  first.pushCompletions({ status: 401, body: JSON.stringify({ error: { message: 'Invalid API key' } }) })
  first.pushCompletions({ events: textEvents })
  let config = configOf(first.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true })
  const adapter = new ClinePassAdapter({ config: () => config, resolveApiKey: async config => config.apiKeyEnv })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })

  config = { ...config, baseURL: second.url }
  second.pushCompletions({ events: textEvents })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  expect(second.headers.filter(header => header.authorization).map(header => header.authorization)).toEqual(['Bearer ACCOUNT_A'])

  // An equivalent URL must still remember this gateway's rejection.
  config = { ...config, baseURL: first.url + '/' }
  first.pushCompletions({ events: textEvents })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  expect(first.headers.filter(header => header.authorization).map(header => header.authorization)).toEqual([
    'Bearer ACCOUNT_A', 'Bearer ACCOUNT_B', 'Bearer ACCOUNT_B',
  ])
})

it('invalidates a changed credential on every gateway where it was rejected', async () => {
  const gateways = await Promise.all([0, 1].map(() => mockGateway({ status: 200, body: listingBody([request().model]) })))
  let config = configOf(gateways[0]!.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true })
  const adapter = new ClinePassAdapter({ config: () => config, resolveApiKey: async config => config.apiKeyEnv })
  for (const gateway of gateways) {
    config = { ...config, baseURL: gateway.url }
    gateway.pushCompletions({ status: 401, body: JSON.stringify({ error: { message: 'Invalid API key' } }) })
    gateway.pushCompletions({ events: textEvents })
    expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  }
  adapter.forgetRejectedKey('ACCOUNT_A')
  for (const gateway of gateways) {
    config = { ...config, baseURL: gateway.url }
    gateway.pushCompletions({ events: textEvents })
    expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    expect(gateway.headers.filter(header => header.authorization).map(header => header.authorization)).toEqual([
      'Bearer ACCOUNT_A', 'Bearer ACCOUNT_B', 'Bearer ACCOUNT_A',
    ])
  }
})

it('can use a backup when the preferred credential is missing and stops fallback on cancellation', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ events: textEvents })
  const signal = new AbortController()
  let cancel = false
  const resolve = vi.fn(async (config: ClinePassConfig) => {
    if (cancel) signal.abort()
    if (config.apiKeyEnv === 'ACCOUNT_A') throw new LlmError('missing', 'MISSING_CREDENTIAL')
    return 'backup-secret'
  })
  const adapter = new ClinePassAdapter({ config: () => configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }), resolveApiKey: resolve })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  cancel = true
  resolve.mockClear()
  expect((await drain(adapter.stream({ ...request(), signal: signal.signal }))).at(-1)).toMatchObject({ reason: { kind: 'aborted', failure: { code: 'ABORTED' } } })
  expect(resolve).toHaveBeenCalledTimes(1)
})

it('keeps the newest request\'s switch outcome when an older request announces late', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  const ctx = new Context()
  await ctx.plugin(LlmRuntime)
  await ctx.plugin(Registry)
  await ctx.plugin(Gateway)
  ctx.provide('credentials', {
    describe: async () => ({ configured: true, writable: true }),
    resolve: async ref => ({ value: `${ref}-secret`, source: 'test' }),
  } as never)
  apply(ctx, configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }))
  try {
    await vi.waitFor(() => { expect(ctx.llm.listProviders().some(provider => provider.id === 'dsh-clinepass')).toBe(true) })
    // R1: the preferred account is over quota, and the backup's content is slow.
    gateway.pushCompletions({ status: 429, body: JSON.stringify({ error: { message: 'Monthly usage limit exceeded' } }) })
    gateway.pushCompletions({ events: textEvents, delayMs: 120 })
    const first = drain(ctx.llm.stream(request()))
    await vi.waitFor(() => { expect(gateway.bodies).toHaveLength(2) })
    // R2 starts later and succeeds on the preferred account immediately; its
    // outcome must survive R1's fallback notice arriving after it.
    gateway.pushCompletions({ events: textEvents })
    await drain(ctx.llm.stream(request()))
    await first
    const limits = [
      { type: 'five_hour', percentUsed: 10, resetsAt: '2026-09-21T00:00:00Z' },
      { type: 'weekly', percentUsed: 10, resetsAt: '2026-09-21T00:00:00Z' },
      { type: 'monthly', percentUsed: 10, resetsAt: '2026-09-21T00:00:00Z' },
    ]
    gateway.pushCompletions({ status: 200, body: JSON.stringify({ data: { limits } }) })
    const read = await ctx.typertGateway.invoke({ namespace: 'clinePassUsage', method: 'read', args: {} })
    expect(read.lastSwitch).toBeUndefined()
  } finally { await ctx.fiber.dispose() }
})

it('ignores an old credential check after the user switches the active reference', async () => {
  let config = configOf('https://example.test/v1', { accounts, apiKeyEnv: 'ACCOUNT_A' })
  const oldChecks: Array<(value: { configured: boolean; writable: boolean }) => void> = []
  const ctx = new Context()
  await ctx.plugin(LlmRuntime)
  ctx.provide('credentials', {
    describe: (ref: string) => ref === 'ACCOUNT_A' ? new Promise(resolve => { oldChecks.push(resolve) }) : Promise.resolve({ configured: true, writable: true }),
    resolve: async () => ({ value: 'test', source: 'test' }),
  })
  const live = Object.fromEntries(Object.keys(Config()).map(key => [key, { get: () => config[key as keyof ClinePassConfig] }])) as LiveConfig
  apply(ctx, live)
  try {
    config = { ...config, apiKeyEnv: 'ACCOUNT_B' }
    ctx.emit('loader/volatile-update', [])
    await vi.waitFor(() => { expect(ctx.llm.listProviders().some(provider => provider.id === 'dsh-clinepass')).toBe(true) })
    for (const settle of oldChecks) settle({ configured: false, writable: true })
    await Promise.resolve()
    expect(ctx.llm.listProviders().some(provider => provider.id === 'dsh-clinepass')).toBe(true)
  } finally { await ctx.fiber.dispose() }
})

it('settles a pre-output fallback once with its captured identity and notice', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: 429, body: JSON.stringify({ error: { message: 'Monthly usage limit exceeded' } }) })
  gateway.pushCompletions({ events: textEvents })
  const config = configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true })
  const settled = vi.fn()
  const adapter = new ClinePassAdapter({
    config: () => config, accountGeneration: () => 7,
    resolveApiKey: async config => config.apiKeyEnv, onAccountSettled: settled,
  })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  expect(settled).toHaveBeenCalledExactlyOnceWith({
    seq: 1, generation: 7, config, ref: 'ACCOUNT_B',
    notice: { fromRef: 'ACCOUNT_A', toRef: 'ACCOUNT_B', reason: 'quota', at: expect.any(Number) },
  })
})

it('settles a preferred-account success once without a fallback notice', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ events: textEvents })
  const config = configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true })
  const settled = vi.fn()
  const adapter = new ClinePassAdapter({
    config: () => config, accountGeneration: () => 7,
    resolveApiKey: async config => config.apiKeyEnv, onAccountSettled: settled,
  })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  expect(settled).toHaveBeenCalledExactlyOnceWith({
    seq: 1, generation: 7, config, ref: 'ACCOUNT_A', notice: undefined,
  })
})

it('settles no account when every account fails before output', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  const rejection = { status: 401, body: JSON.stringify({ error: { message: 'Invalid API key' } }) }
  gateway.pushCompletions(rejection)
  gateway.pushCompletions(rejection)
  const settled = vi.fn()
  const adapter = new ClinePassAdapter({
    config: () => configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }),
    resolveApiKey: async config => config.apiKeyEnv, onAccountSettled: settled,
  })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'error' } })
  expect(settled).not.toHaveBeenCalled()
})

it('keeps the first-output settlement when the response later fails', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ events: textEvents.slice(0, 2) })
  const config = configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true })
  const settled = vi.fn()
  const adapter = new ClinePassAdapter({
    config: () => config, accountGeneration: () => 7,
    resolveApiKey: async config => config.apiKeyEnv, onAccountSettled: settled,
  })
  const chunks = await drain(adapter.stream(request()))
  expect(chunks.some(chunk => chunk.type === 'text-delta')).toBe(true)
  expect(chunks.at(-1)).toMatchObject({ reason: { kind: 'error' } })
  expect(settled).toHaveBeenCalledExactlyOnceWith({
    seq: 1, generation: 7, config, ref: 'ACCOUNT_A', notice: undefined,
  })
})

it('settles the backup even when a remembered rejection made it the first candidate', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: 401, body: JSON.stringify({ error: { message: 'Invalid API key' } }) })
  gateway.pushCompletions({ events: textEvents })
  const config = configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true })
  const settled = vi.fn()
  const adapter = new ClinePassAdapter({
    config: () => config, accountGeneration: () => 7,
    resolveApiKey: async config => config.apiKeyEnv, onAccountSettled: settled,
  })
  // Request 1: the preferred key is rejected and the backup serves it.
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  expect(settled).toHaveBeenCalledExactlyOnceWith({
    seq: 1, generation: 7, config, ref: 'ACCOUNT_B',
    notice: { fromRef: 'ACCOUNT_A', toRef: 'ACCOUNT_B', reason: 'credential', at: expect.any(Number) },
  })
  settled.mockClear()
  // Request 2: the rejection is remembered, so the backup is attempted first —
  // its settlement still names the skipped preferred account in the notice.
  gateway.pushCompletions({ events: textEvents })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  expect(settled).toHaveBeenCalledExactlyOnceWith({
    seq: 2, generation: 7, config, ref: 'ACCOUNT_B',
    notice: { fromRef: 'ACCOUNT_A', toRef: 'ACCOUNT_B', reason: 'credential', at: expect.any(Number) },
  })
})

it('does not switch or remember a key rejection for a 401 ModelError', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: 401, body: JSON.stringify({ error: { type: 'ModelError', message: 'Model not supported' } }) })
  gateway.pushCompletions({ events: textEvents })
  const switched = vi.fn()
  const adapter = new ClinePassAdapter({ config: () => configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }),
    resolveApiKey: async config => config.apiKeyEnv, onAccountSwitch: switched })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'error', failure: { code: 'UNKNOWN_MODEL' } } })
  expect(gateway.bodies).toHaveLength(1)
  expect(switched).not.toHaveBeenCalled()
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  expect(gateway.headers.filter(header => header.authorization).map(header => header.authorization)).toEqual(['Bearer ACCOUNT_A', 'Bearer ACCOUNT_A'])
})

it.each(['CreditsError', 'MonthlyLimitError', 'UserLimitError'])('switches on 401 %s as quota without blacklisting the key', async type => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: 401, body: JSON.stringify({ error: { type, message: 'Subscription unavailable' } }) })
  gateway.pushCompletions({ events: textEvents })
  gateway.pushCompletions({ events: textEvents })
  const switched = vi.fn()
  const adapter = new ClinePassAdapter({ config: () => configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }),
    resolveApiKey: async config => config.apiKeyEnv, onAccountSwitch: switched })
  await drain(adapter.stream(request()))
  expect(switched.mock.calls[0]?.[0]).toMatchObject({ reason: 'quota' })
  await drain(adapter.stream(request()))
  expect(gateway.headers.filter(header => header.authorization).map(header => header.authorization)).toEqual(['Bearer ACCOUNT_A', 'Bearer ACCOUNT_B', 'Bearer ACCOUNT_A'])
})

it('does not switch accounts for an untyped 500 quoting a previous quota failure', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: 500, body: JSON.stringify({ error: { message: 'Previous request had insufficient credits' } }) })
  const switched = vi.fn(), trace = vi.fn()
  const adapter = new ClinePassAdapter({ config: () => configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }),
    resolveApiKey: async config => config.apiKeyEnv, onAccountSwitch: switched, onCallTrace: trace })
  expect((await drain(adapter.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'error', failure: { code: 'SERVER' } } })
  expect(gateway.bodies).toHaveLength(1)
  expect(switched).not.toHaveBeenCalled()
  expect(trace.mock.calls[0]?.[0]).toMatchObject({ attempts: 1, attemptDetails: [{ attempt: 1, outcome: 'failed', code: 'SERVER', httpStatus: 500 }] })
})

it('records each failed and serving attempt without account references or content', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: 401, body: JSON.stringify({ error: { type: 'CreditsError' } }), headers: { 'x-request-id': 'quota-edge-1' } })
  gateway.pushCompletions({ events: textEvents, headers: { 'x-request-id': 'success-edge-2' } })
  const trace = vi.fn()
  const adapter = new ClinePassAdapter({ config: () => configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }),
    resolveApiKey: async config => config.apiKeyEnv, onCallTrace: trace })
  await drain(adapter.stream(request()))
  expect(trace.mock.calls[0]?.[0]).toMatchObject({ attempts: 2, outcome: 'completed', attemptDetails: [
    { attempt: 1, outcome: 'failed', code: 'QUOTA', httpStatus: 401, requestId: 'quota-edge-1', stages: { credential: expect.any(Number) } },
    { attempt: 2, outcome: 'completed', httpStatus: 200, requestId: 'success-edge-2', firstOutputMs: expect.any(Number) },
  ] })
  expect(JSON.stringify(trace.mock.calls)).not.toMatch(/ACCOUNT_A|ACCOUNT_B|"hi"/)
})
