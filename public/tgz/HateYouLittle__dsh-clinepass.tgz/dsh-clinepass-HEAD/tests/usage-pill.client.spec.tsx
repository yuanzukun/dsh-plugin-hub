// @vitest-environment jsdom
import { act, cleanup, fireEvent, render, screen, within } from '@testing-library/react'
import { createSnapshotStore } from '@deepseek-ai/dsh-client-store'
import type { ModelDirectoryState } from '@deepseek-ai/dsh-client-ui-model-selection/client'
import type { ClineUsage } from '../src/usage-contract.ts'
import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { UsagePill } from '../src/client/UsagePill.tsx'
import { en } from '../src/client/locales.ts'
import { setGoTheme } from '../src/client/theme.ts'
import { stubSettingsScope } from './support/settings-scope.ts'
import type { ClinePassSettings } from '../src/client/section-controller.ts'
import type { SettingsScope } from '../src/client/settings.ts'
import css from '../src/client/UsagePill.module.css'

const usageSettings = (value: ClinePassSettings = {}) => {
  const host = stubSettingsScope<ClinePassSettings>()
  host.publish({ status: 'ready', value })
  return host
}
let settings: SettingsScope<ClinePassSettings>
beforeEach(() => { vi.useFakeTimers(); settings = usageSettings().scope; localStorage.clear(); setGoTheme('graphite') })
afterEach(() => { cleanup(); vi.useRealTimers(); vi.restoreAllMocks() })
const t = (key: string) => en[key as keyof typeof en]
const usageWindow = { status: 'ok' as const, percent: 10, resetsAt: '2026-09-21T00:00:00Z' }
const usage = { source: 'account-a', rolling: { ...usageWindow, percent: 0 }, weekly: usageWindow, monthly: { ...usageWindow, percent: 7 } }
const updated = { ...usage, rolling: { ...usageWindow, percent: 25 }, weekly: { ...usageWindow, percent: 30 } }
const transientMessage = 'usage request failed: network error (ECONNRESET)'
const analyticsReport = {
  generatedAt: Date.UTC(2026, 9, 18), range: { from: Date.UTC(2026, 8, 18), to: Date.UTC(2026, 9, 18) }, timeZone: 'UTC',
  totals: { requests: 1, unsettledAttempts: 0, summaries: 0, inputTokens: 10, outputTokens: 5, cacheReadTokens: 0,
    cacheWriteTokens: 0, estimatedMicroUsd: 100, pricedRequests: 1, unpricedRequests: 0, missingUsage: 0 },
  byModel: [], byDay: [],
  coverage: { listedSessions: 1, scannedSessions: 1, matchedSessions: 1, failedSessions: 0, eventsScanned: 2,
    summaries: 0, legacyRequests: 0, missingUsage: 0, truncated: false, scanMs: 3 },
  pricing: { source: 'models.dev', unpricedModels: [] },
}
const directory = (provider = 'deepseek') => createSnapshotStore<ModelDirectoryState>({
  current: { provider, model: provider === 'dsh-clinepass' ? 'cline-pass/deepseek-v4-pro' : 'deepseek-chat' }, routable: true,
  groups: [], failures: [], status: 'ready', error: null,
})
const usageError = (options: { retainPrevious?: boolean; retryable?: boolean; source?: string | null; message?: string } = {}) =>
  Object.assign(new Error(options.message ?? transientMessage), {
    code: 'clinepass/usage-unavailable',
    details: {
      retryable: options.retryable ?? true,
      retainPrevious: options.retainPrevious ?? true,
      ...(options.source === null ? {} : { source: options.source ?? 'account-a' }),
    },
  })
const trigger = () => screen.getByRole<HTMLButtonElement>('button', { name: new RegExp(en.usageTitle) })
const percentageLabel = (value: ClineUsage) => `${en.usageRollingShort} ${value.rolling.percent}% · ${en.usageWeekShort} ${value.weekly.percent}%`
/** The multi-account suffix carries the active account's full name. */
const accountSuffix = (name: string) => ` · ${name}`
const twoAccounts = [
  { id: 'a', name: 'Primary', apiKeyEnv: 'ACCOUNT_A' },
  { id: 'b', name: 'Backup', apiKeyEnv: 'ACCOUNT_B' },
]
const threeAccounts = [
  ...twoAccounts,
  { id: 'c', name: 'Travel', apiKeyEnv: 'ACCOUNT_C' },
]
const tick = async (milliseconds = 60_000) => { await act(async () => { await vi.advanceTimersByTimeAsync(milliseconds) }) }
const showDetails = () => { fireEvent.click(trigger()) }

it.each(['deepseek', 'clinepass', 'dsh-clinepass'])('keeps usage visible in always mode while using %s', async provider => {
  const host = usageSettings({ usageDisplay: 'always' })
  const store = directory(provider)
  const read = vi.fn().mockResolvedValue(usage)
  await act(async () => { render(<UsagePill settings={host.scope} directory={store} readUsage={read} t={t} />) })
  expect(trigger().textContent).toContain(percentageLabel(usage))
  expect(trigger().getAttribute('aria-expanded')).toBe('false')
  expect(screen.queryByRole('dialog')).toBeNull()
  await act(async () => { store.set({ ...store.getSnapshot(), current: null }) })
  expect(trigger().textContent).toContain(percentageLabel(usage))
  await tick()
  expect(read).toHaveBeenCalledTimes(2)
  showDetails()
  expect(screen.getAllByRole('progressbar')).toHaveLength(3)
})

it('reads a class-shaped host scope through its own receiver', async () => {
  const host = usageSettings({ usageDisplay: 'always' })
  // The real Host scope keeps getSnapshot/subscribe on the prototype, so a
  // reference handed over as a value loses `this`; the pill must call them on
  // the instance instead.
  expect(Object.hasOwn(host.scope, 'getSnapshot')).toBe(false)
  expect(Object.hasOwn(host.scope, 'subscribe')).toBe(false)
  const read = vi.fn().mockResolvedValue(usage)
  let unmount: () => void
  await act(async () => { ({ unmount } = render(<UsagePill settings={host.scope} directory={directory('deepseek')} readUsage={read} t={t} />)) })
  expect(trigger().textContent).toContain(percentageLabel(usage))
  expect(host.listenerCount()).toBe(1)
  await act(async () => { host.publish({ value: { usageDisplay: 'off' } }) })
  expect(screen.queryByRole('button')).toBeNull()
  expect(host.listenerCount()).toBe(1)
  unmount!()
  expect(host.listenerCount()).toBe(0)
})

it('applies live display changes and tears down polling and visibility refreshes while off', async () => {
  const host = usageSettings()
  const read = vi.fn().mockResolvedValue(usage)
  await act(async () => { render(<UsagePill settings={host.scope} directory={directory()} readUsage={read} t={t} />) })
  expect(screen.queryByRole('button')).toBeNull()
  expect(read).not.toHaveBeenCalled()
  await act(async () => { host.publish({ value: { usageDisplay: 'always' } }) })
  expect(trigger().textContent).toContain(percentageLabel(usage))
  await act(async () => { host.publish({ value: { usageDisplay: 'off' } }) })
  expect(screen.queryByRole('button')).toBeNull()
  expect(vi.getTimerCount()).toBe(0)
  await tick()
  await act(async () => { document.dispatchEvent(new Event('visibilitychange')) })
  expect(read).toHaveBeenCalledTimes(1)
  await act(async () => { host.publish({ value: { usageDisplay: 'always' } }) })
  expect(read).toHaveBeenCalledTimes(2)
  await act(async () => { host.publish({ value: {} }) })
  expect(screen.queryByRole('button')).toBeNull()
  await tick()
  expect(read).toHaveBeenCalledTimes(2)
})

it('sends no usage requests in off mode even when this plugin model is selected', async () => {
  const host = usageSettings({ usageDisplay: 'off' })
  const read = vi.fn().mockResolvedValue(usage)
  await act(async () => { render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')} readUsage={read} t={t} />) })
  await tick()
  expect(screen.queryByRole('button')).toBeNull()
  expect(read).not.toHaveBeenCalled()
})

it.each(['auto', 'always'] as const)('hides usage and stops polling when the plugin is disabled in %s mode', async usageDisplay => {
  const host = usageSettings({ usageDisplay, enabled: true })
  const read = vi.fn().mockResolvedValue(usage)
  await act(async () => { render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')} readUsage={read} t={t} />) })
  showDetails()
  await act(async () => { host.publish({ value: { usageDisplay, enabled: false } }) })
  expect(screen.queryByRole('button')).toBeNull()
  expect(screen.queryByRole('dialog')).toBeNull()
  await tick()
  await act(async () => { document.dispatchEvent(new Event('visibilitychange')) })
  expect(read).toHaveBeenCalledTimes(1)
  await act(async () => { host.publish({ value: { usageDisplay, enabled: true } }) })
  expect(read).toHaveBeenCalledTimes(2)
  expect(trigger().getAttribute('aria-expanded')).toBe('false')
})

it.each(['loading', 'unavailable'] as const)('waits for available settings before polling (%s)', async status => {
  const host = usageSettings({ usageDisplay: 'always' })
  host.publish({ status })
  const read = vi.fn().mockResolvedValue(usage)
  await act(async () => { render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')} readUsage={read} t={t} />) })
  await tick()
  expect(read).not.toHaveBeenCalled()
  expect(screen.queryByRole('button')).toBeNull()
  await act(async () => { host.publish({ status: 'ready' }) })
  expect(read).toHaveBeenCalledTimes(1)
})

it.each(['deepseek', 'clinepass'])('shows plugin usage only on its route and stops polling when switching to %s', async otherProvider => {
  const store = directory(otherProvider)
  const read = vi.fn().mockResolvedValue(usage)
  render(<UsagePill settings={settings} directory={store} readUsage={read} t={t} />)
  expect(read).not.toHaveBeenCalled()
  await act(async () => { store.set({ ...store.getSnapshot(), current: { provider: 'dsh-clinepass', model: 'cline-pass/deepseek-v4-pro' } }) })
  expect(trigger().textContent).toContain(percentageLabel(usage))
  // The label stays one string for accessibility and for textContent, but renders as addressable spans
  // for the narrow-composer tiers: reading (with a stale flag) and two unit words. No stale or
  // account segment while a single account is configured.
  expect(trigger().title).toBe(percentageLabel(usage))
  expect(trigger().querySelectorAll(`.${css.unit}`)).toHaveLength(2)
  expect(trigger().querySelector(`.${css.reading}`)?.hasAttribute('data-stale')).toBe(false)
  expect(trigger().querySelector(`.${css.stale}`)).toBeNull()
  expect(trigger().querySelector(`.${css.account}`)).toBeNull()
  showDetails()
  expect(screen.getByRole('progressbar', { name: en.usage_monthly }).getAttribute('value')).toBe('7')
  await tick()
  expect(read).toHaveBeenCalledTimes(2)
  await act(async () => { store.set({ ...store.getSnapshot(), current: { provider: otherProvider, model: 'deepseek-chat' } }) })
  expect(screen.queryByRole('button')).toBeNull()
  await tick()
  expect(read).toHaveBeenCalledTimes(2)
})

it('retains same-account percentages after a temporary failure and recovers through a single manual retry', async () => {
  const store = directory('dsh-clinepass')
  let finishRetry!: (value: ClineUsage) => void
  const read = vi.fn().mockResolvedValueOnce(usage).mockRejectedValueOnce(usageError())
    .mockImplementationOnce(() => new Promise<ClineUsage>(resolve => { finishRetry = resolve }))
    .mockResolvedValue(updated)
  await act(async () => { render(<UsagePill settings={settings} directory={store} readUsage={read} t={t} />) })
  showDetails()
  const lastUpdated = () => screen.getByText(new RegExp(`^${en.usageLastUpdated}`)).textContent
  const firstUpdated = lastUpdated()
  await tick()
  expect(trigger().textContent).toContain(percentageLabel(usage))
  expect(trigger().textContent).toContain(en.usageStaleShort)
  expect(trigger().title).toBe(`${percentageLabel(usage)} · ${en.usageStaleShort}`)
  expect(trigger().querySelector(`.${css.reading}`)?.getAttribute('data-stale')).toBe('')
  expect(trigger().querySelector(`.${css.stale}`)?.textContent).toContain(en.usageStaleShort)
  expect(lastUpdated()).toBe(firstUpdated)
  expect(screen.getAllByRole('progressbar')).toHaveLength(3)
  expect(screen.getByText(en.usageRefreshFailed)).toBeTruthy()
  expect(screen.getByText(en.usageStaleHint)).toBeTruthy()
  expect(screen.getByText(transientMessage)).toBeTruthy()

  fireEvent.click(screen.getByRole('button', { name: en.usageRetry }))
  const retry = screen.getByRole<HTMLButtonElement>('button', { name: en.usageRefreshing })
  expect(retry.disabled).toBe(true)
  fireEvent.click(retry)
  // The hung retry holds the refresh latch: while it is in flight, visibility changes
  // cannot stack another read onto it (asserted inside the ~30s latch window).
  await tick(29_000)
  await act(async () => { document.dispatchEvent(new Event('visibilitychange')) })
  expect(read).toHaveBeenCalledTimes(3)

  await act(async () => { finishRetry(updated) })
  expect(trigger().textContent).toContain(percentageLabel(updated))
  expect(trigger().textContent).not.toContain(en.usageStaleShort)
  expect(trigger().title).toBe(percentageLabel(updated))
  expect(trigger().querySelector(`.${css.stale}`)).toBeNull()
  expect(trigger().querySelector(`.${css.reading}`)?.hasAttribute('data-stale')).toBe(false)
  expect(screen.queryByText(en.usageStaleHint)).toBeNull()
  expect(screen.queryByText(transientMessage)).toBeNull()
  expect(lastUpdated()).not.toBe(firstUpdated)
  expect(screen.getByRole('progressbar', { name: en.usage_rolling }).getAttribute('value')).toBe('25')
  await tick()
  expect(read).toHaveBeenCalledTimes(4)
})

it.each([
  { reason: 'HTTP 401', cached: usage, error: usageError({ retainPrevious: false, retryable: false, message: 'usage request failed: HTTP 401' }) },
  { reason: 'HTTP 403', cached: usage, error: usageError({ retainPrevious: false, retryable: false, message: 'usage request failed: HTTP 403' }) },
  { reason: 'an explicit account reset', cached: usage, error: usageError({ retainPrevious: false, source: 'account-b' }) },
  { reason: 'a different source despite a retain hint', cached: usage, error: usageError({ source: 'account-b' }) },
  { reason: 'an error without source identity', cached: usage, error: usageError({ source: null }) },
  { reason: 'a cached result without source identity', cached: { rolling: usage.rolling, weekly: usage.weekly, monthly: usage.monthly }, error: usageError() },
])('clears previous percentages after $reason', async ({ cached, error }) => {
  const read = vi.fn().mockResolvedValueOnce(cached).mockRejectedValue(error)
  await act(async () => { render(<UsagePill settings={settings} directory={directory('dsh-clinepass')} readUsage={read} t={t} />) })
  expect(trigger().textContent).toContain(percentageLabel(cached))
  await tick()
  expect(trigger().textContent).toContain(en.usageUnavailable)
  expect(trigger().textContent).not.toContain('%')
  expect(trigger().textContent).not.toContain(en.usageStaleShort)
  // The non-usage state carries no reading, no unit words and no stale segment.
  expect(trigger().querySelector(`.${css.reading}`)).toBeNull()
  expect(trigger().querySelector(`.${css.unit}`)).toBeNull()
  expect(trigger().querySelector(`.${css.stale}`)).toBeNull()
  showDetails()
  expect(screen.queryByRole('progressbar')).toBeNull()
  expect(screen.queryByText(en.usageStaleHint)).toBeNull()
  expect(screen.getByText(error.message)).toBeTruthy()
})

it('shows the reason for the first failure without inventing cached usage and allows retry', async () => {
  const read = vi.fn().mockRejectedValueOnce(usageError()).mockResolvedValue(usage)
  await act(async () => { render(<UsagePill settings={settings} directory={directory('dsh-clinepass')} readUsage={read} t={t} />) })
  expect(trigger().textContent).toContain(en.usageUnavailable)
  expect(trigger().textContent).not.toContain(en.usageStaleShort)
  expect(trigger().title).toBe(trigger().textContent)
  expect(trigger().querySelector(`.${css.account}`)).toBeNull()
  showDetails()
  expect(screen.queryByRole('progressbar')).toBeNull()
  expect(screen.getByText(transientMessage)).toBeTruthy()
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: en.usageRetry })) })
  expect(read).toHaveBeenCalledTimes(2)
  expect(trigger().textContent).toContain(percentageLabel(usage))
  expect(screen.queryByText(transientMessage)).toBeNull()
})

it('clears cached usage for an unclassified error and does not display its raw message', async () => {
  const privateMessage = 'upstream rejected private-token=secret'
  const read = vi.fn().mockResolvedValueOnce(usage).mockRejectedValue(new Error(privateMessage))
  await act(async () => { render(<UsagePill settings={settings} directory={directory('dsh-clinepass')} readUsage={read} t={t} />) })
  await tick()
  expect(trigger().textContent).toContain(en.usageUnavailable)
  expect(trigger().textContent).not.toContain('%')
  expect(trigger().title).toBe(trigger().textContent)
  showDetails()
  expect(screen.getByRole('alert').textContent).toContain(en.usageRefreshFailed)
  expect(screen.getByRole('alert').textContent).toContain(en.usageUnavailable)
  expect(screen.queryByText(privateMessage)).toBeNull()
  expect(screen.queryByRole('progressbar')).toBeNull()
})

it('resumes polling when visible and avoids concurrent reads while one is in flight', async () => {
  const visibility = vi.spyOn(document, 'visibilityState', 'get').mockReturnValue('hidden')
  let finish!: (value: ClineUsage) => void
  const read = vi.fn().mockImplementationOnce(() => new Promise<ClineUsage>(resolve => { finish = resolve })).mockResolvedValue(usage)
  await act(async () => { render(<UsagePill settings={settings} directory={directory('dsh-clinepass')} readUsage={read} t={t} />) })
  await tick()
  expect(read).not.toHaveBeenCalled()
  visibility.mockReturnValue('visible')
  await act(async () => { document.dispatchEvent(new Event('visibilitychange')) })
  // While that read is in flight, a second visibility change cannot stack another read.
  await act(async () => { document.dispatchEvent(new Event('visibilitychange')) })
  expect(read).toHaveBeenCalledTimes(1)
  await act(async () => { finish(usage) })
  expect(trigger().textContent).toContain(percentageLabel(usage))
  await act(async () => { document.dispatchEvent(new Event('visibilitychange')) })
  expect(read).toHaveBeenCalledTimes(2)
  await tick()
  expect(read).toHaveBeenCalledTimes(3)
})

// Latch-timeout semantics (migrated from the former "a hung read blocks the minute
// timer forever" expectation): a read that never settles may only hold the refresh
// latch for ~30s, after which timer and visibility refreshes regain their turn.
it('releases the busy latch when a usage read never settles and resumes timer refreshes without a fabricated failure', async () => {
  const read = vi.fn().mockImplementation(() => new Promise<ClineUsage>(() => {}))
  await act(async () => { render(<UsagePill settings={settings} directory={directory('dsh-clinepass')} readUsage={read} t={t} />) })
  expect(read).toHaveBeenCalledTimes(1)
  expect(trigger().textContent).toBe('…')
  // Just before the sentinel, the minute timer stays latched out behind the hung read.
  await tick(29_000)
  expect(read).toHaveBeenCalledTimes(1)
  // The ~30s sentinel frees the latch without reporting a failure, and the next
  // minute cycle regains its turn.
  await tick(31_000)
  expect(read).toHaveBeenCalledTimes(2)
  expect(trigger().textContent).toBe('…')
  expect(screen.queryByText(en.usageUnavailable)).toBeNull()
})

it('frees the busy latch when a hung retry never settles so a later manual refresh can fire', async () => {
  const read = vi.fn().mockRejectedValueOnce(usageError())
    .mockImplementationOnce(() => new Promise<ClineUsage>(() => {}))
    .mockResolvedValue(updated)
  await act(async () => { render(<UsagePill settings={settings} directory={directory('dsh-clinepass')} readUsage={read} t={t} />) })
  expect(trigger().textContent).toContain(en.usageUnavailable)
  showDetails()
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: en.usageRetry })) })
  expect(read).toHaveBeenCalledTimes(2)
  expect(screen.getByRole('button', { name: en.usageRefreshing }).disabled).toBe(true)
  // While the hung retry holds the latch, visibility refreshes cannot stack another read.
  await act(async () => { document.dispatchEvent(new Event('visibilitychange')) })
  expect(read).toHaveBeenCalledTimes(2)
  // At ~30s the sentinel frees the latch; the retry control revives and the next
  // manual refresh can be issued and lands.
  await tick(30_000)
  expect(read).toHaveBeenCalledTimes(2)
  const retryButton = screen.getByRole<HTMLButtonElement>('button', { name: en.usageRetry })
  expect(retryButton.disabled).toBe(false)
  await act(async () => { fireEvent.click(retryButton) })
  expect(read).toHaveBeenCalledTimes(3)
  await act(async () => { await Promise.resolve() })
  expect(trigger().textContent).toContain(percentageLabel(updated))
  expect(trigger().textContent).not.toContain(en.usageStaleShort)
})

it('clears usage when its source reader changes and ignores the previous reader’s late response', async () => {
  const store = directory('dsh-clinepass')
  let finishOld!: (value: ClineUsage) => void
  let finishNew!: (value: ClineUsage) => void
  const readOld = vi.fn().mockResolvedValueOnce(usage)
    .mockImplementationOnce(() => new Promise<ClineUsage>(resolve => { finishOld = resolve }))
  const readNew = vi.fn().mockImplementationOnce(() => new Promise<ClineUsage>(resolve => { finishNew = resolve }))
  const view = render(<UsagePill settings={settings} directory={store} readUsage={readOld} t={t} />)
  await act(async () => { await Promise.resolve() })
  await tick()
  expect(readOld).toHaveBeenCalledTimes(2)

  await act(async () => { view.rerender(<UsagePill settings={settings} directory={store} readUsage={readNew} t={t} />) })
  expect(trigger().textContent).not.toContain('%')
  expect(readNew).toHaveBeenCalledTimes(1)
  const otherAccount = { ...updated, source: 'account-b' }
  await act(async () => { finishNew(otherAccount) })
  expect(trigger().textContent).toContain(percentageLabel(otherAccount))
  await act(async () => { finishOld(usage) })
  expect(trigger().textContent).toContain(percentageLabel(otherAccount))
})

it('marks windows near or at their limit so the bars are not all shown as healthy', async () => {
  const levels = { ...usage, rolling: { ...usageWindow, percent: 20 }, weekly: { ...usageWindow, percent: 85 }, monthly: { ...usageWindow, status: 'rate-limited' as const, percent: 60 } }
  await act(async () => { render(<UsagePill settings={settings} directory={directory('dsh-clinepass')} readUsage={vi.fn().mockResolvedValue(levels)} t={t} />) })
  showDetails()
  const bar = (name: string) => screen.getByRole('progressbar', { name })
  expect(bar(en.usage_rolling).classList.contains(css.high)).toBe(false)
  expect(bar(en.usage_weekly).classList.contains(css.high)).toBe(true)
  expect(bar(en.usage_monthly).classList.contains(css.limited)).toBe(true)
  expect(bar(en.usage_weekly).classList.contains(css.limited)).toBe(false)
  expect(screen.getByText(en.usageLimited)).toBeTruthy()
})

it('renders the active account’s full name as a truncatable span with more than one account', async () => {
  const host = usageSettings({ usageDisplay: 'always', accounts: twoAccounts, apiKeyEnv: 'ACCOUNT_B' })
  const read = vi.fn().mockResolvedValue(usage)
  await act(async () => { render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')} readUsage={read} t={t} />) })
  // The name is part of the spoken label itself, so visible and accessible strings agree.
  expect(trigger().textContent).toBe(`${percentageLabel(usage)}${accountSuffix('Backup')}`)
  expect(trigger().title).toContain('Backup')
  expect(trigger().querySelectorAll(`.${css.account}`)).toHaveLength(1)
  expect(trigger().querySelector(`.${css.account}`)?.textContent).toBe('Backup')
  expect(trigger().textContent).not.toMatch(/\+\d/)
  expect(trigger().querySelectorAll(`.${css.unit}`)).toHaveLength(2)
})

it('keeps the account segment in the non-usage state with more than one account', async () => {
  const host = usageSettings({ usageDisplay: 'always', accounts: twoAccounts, apiKeyEnv: 'ACCOUNT_B' })
  const read = vi.fn().mockRejectedValue(usageError())
  await act(async () => { render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')} readUsage={read} t={t} />) })
  expect(trigger().textContent).toBe(`${en.usageUnavailable}${accountSuffix('Backup')}`)
  expect(trigger().title).toContain('Backup')
  expect(trigger().querySelector(`.${css.account}`)?.textContent).toBe('Backup')
  expect(trigger().querySelector(`.${css.reading}`)).toBeNull()
  expect(trigger().querySelector(`.${css.unit}`)).toBeNull()
})

it('omits the account segment when at most one account is configured', async () => {
  const host = usageSettings({ usageDisplay: 'always', apiKeyEnv: 'CLINE_API_KEY' })
  const read = vi.fn().mockResolvedValue(usage)
  await act(async () => { render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')} readUsage={read} t={t} />) })
  expect(trigger().textContent).toBe(percentageLabel(usage))
  expect(trigger().querySelector(`.${css.account}`)).toBeNull()
})

const openPanel = () => screen.getByRole('dialog', { name: en.usageTitle })
/** The account switch writes through the settings scope, so those cases need a writable host. */
const writableSettings = (apiKeyEnv = 'ACCOUNT_A') => {
  const host = stubSettingsScope<ClinePassSettings>()
  host.publish({ status: 'ready', writable: true, value: { usageDisplay: 'always', accounts: twoAccounts, apiKeyEnv } })
  return host
}
const switchButton = () => screen.getByRole('button', { name: new RegExp(en.accountSwitchAction) })

it('shows the account on a card row instead of a native picker, and drops the hint line', async () => {
  const host = writableSettings()
  const read = vi.fn().mockResolvedValue(usage)
  await act(async () => { render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')} readUsage={read} t={t} selectAccount={vi.fn()} />) })
  showDetails()
  expect(within(openPanel()).getByText('Primary')).toBeTruthy()
  expect(within(openPanel()).getByText(en.accountPreferredTag)).toBeTruthy()
  expect(within(openPanel()).getByRole('button', { name: new RegExp(en.accountSwitchAction) })).toBeTruthy()
  // The removed explainer must not come back, and the native <select> is gone with it.
  expect(within(openPanel()).queryByText(/refreshes every minute/)).toBeNull()
  expect(within(openPanel()).queryByRole('combobox')).toBeNull()
  // One account leaves nothing to choose, so no drill-down is offered.
  cleanup()
  const single = usageSettings({ usageDisplay: 'always', accounts: [twoAccounts[0]!], apiKeyEnv: 'ACCOUNT_A' })
  await act(async () => { render(<UsagePill settings={single.scope} directory={directory('dsh-clinepass')} readUsage={read} t={t} selectAccount={vi.fn()} />) })
  showDetails()
  expect(within(openPanel()).queryByRole('button', { name: new RegExp(en.accountSwitchAction) })).toBeNull()
})

it('switches the spending account through the drill-down list and returns to the reading', async () => {
  const host = writableSettings()
  const read = vi.fn().mockResolvedValue(usage)
  const selectAccount = vi.fn().mockResolvedValue(true)
  await act(async () => { render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')} readUsage={read} t={t} selectAccount={selectAccount} />) })
  showDetails()
  fireEvent.click(switchButton())
  const list = screen.getByRole('listbox', { name: en.accountSwitchTitle })
  const options = within(list).getAllByRole('option')
  expect(options.map(option => option.textContent)).toEqual(['Primary', 'Backup'])
  expect(options[0]!.getAttribute('aria-selected')).toBe('true')
  expect(options[1]!.getAttribute('aria-selected')).toBe('false')
  // The choice is the user's own; the copy says the order still lives in Settings.
  expect(screen.getByText(en.accountSwitchHint)).toBeTruthy()
  await act(async () => { fireEvent.click(options[1]!) })
  expect(selectAccount).toHaveBeenCalledWith('ACCOUNT_B')
  expect(screen.queryByRole('listbox')).toBeNull()
  expect(within(openPanel()).getAllByRole('progressbar')).toHaveLength(3)
})

it('keeps the list open with the failure notice when the host refuses the switch', async () => {
  const host = writableSettings()
  const selectAccount = vi.fn().mockRejectedValue(new Error('settings are read-only'))
  await act(async () => { render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')} readUsage={vi.fn().mockResolvedValue(usage)} t={t} selectAccount={selectAccount} />) })
  showDetails()
  fireEvent.click(switchButton())
  const options = within(screen.getByRole('listbox', { name: en.accountSwitchTitle })).getAllByRole('option')
  await act(async () => { fireEvent.click(options[1]!) })
  expect(screen.getByRole('alert').textContent).toBe(en.accountSwitchFailed)
  expect(screen.getByRole('listbox', { name: en.accountSwitchTitle })).toBeTruthy()
})

it('walks the account list with the arrow keys and leaves it with Escape before the panel', async () => {
  const host = writableSettings()
  await act(async () => { render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')} readUsage={vi.fn().mockResolvedValue(usage)} t={t} selectAccount={vi.fn()} />) })
  showDetails()
  fireEvent.click(switchButton())
  const list = screen.getByRole('listbox', { name: en.accountSwitchTitle })
  const options = within(list).getAllByRole('option')
  options[0]!.focus()
  fireEvent.keyDown(list, { key: 'ArrowDown' })
  expect(document.activeElement).toBe(options[1])
  fireEvent.keyDown(list, { key: 'ArrowDown' })
  expect(document.activeElement).toBe(options[0])
  fireEvent.keyDown(list, { key: 'Escape' })
  // Escape steps back to the reading; the panel itself stays open.
  expect(screen.queryByRole('listbox')).toBeNull()
  expect(openPanel()).toBeTruthy()
  expect(within(openPanel()).getAllByRole('progressbar')).toHaveLength(3)
})

it('opens the shared analytics dialog from the expanded panel', async () => {
  const host = usageSettings({ usageDisplay: 'always' })
  const analytics = vi.fn().mockResolvedValue(analyticsReport)
  await act(async () => {
    render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')} readUsage={vi.fn().mockResolvedValue(usage)}
      readAnalytics={analytics} t={t} />)
  })
  showDetails()
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: en.analyticsOpen })) })
  expect(screen.getByRole('dialog', { name: en.analyticsTitle })).toBeTruthy()
  expect(analytics).toHaveBeenCalledTimes(1)
})

it('keeps the analytics dialog open when a credential revision bump remounts the pill', async () => {
  const host = usageSettings({ usageDisplay: 'always' })
  const credentials = createSnapshotStore<number>(0)
  const analytics = vi.fn().mockResolvedValue(analyticsReport)
  await act(async () => {
    render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')} readUsage={vi.fn().mockResolvedValue(usage)}
      readAnalytics={analytics} t={t} credentialChanges={credentials} />)
  })
  showDetails()
  await act(async () => { fireEvent.click(screen.getByRole('button', { name: en.analyticsOpen })) })
  expect(screen.getByRole('dialog', { name: en.analyticsTitle })).toBeTruthy()
  expect(analytics).toHaveBeenCalledTimes(1)
  // A credential change is part of the pill's remount key; the dashboard lives above
  // that key, so it must stay open with its already-fetched report (no second read).
  await act(async () => { credentials.set(1) })
  expect(screen.getByRole('dialog', { name: en.analyticsTitle })).toBeTruthy()
  expect(analytics).toHaveBeenCalledTimes(1)
})

it('names the active account in full no matter how many accounts follow it', async () => {
  const host = usageSettings({ usageDisplay: 'always', accounts: threeAccounts, apiKeyEnv: 'ACCOUNT_B' })
  await act(async () => {
    render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')}
      readUsage={vi.fn().mockResolvedValue(usage)} t={t} />)
  })
  const account = trigger().querySelector(`.${css.account}`) as HTMLElement
  expect(account.textContent).toBe('Backup')
  expect(trigger().textContent).toContain('Backup')
  expect(trigger().textContent).not.toContain('+2')
})

const manyAccounts = (count: number) => Array.from({ length: count }, (_, index) => ({
  id: `account-${index + 1}`, name: `Account ${index + 1}`, apiKeyEnv: `ACCOUNT_${index + 1}`,
}))

it('uses the full name instead of an extra-count badge with many accounts', async () => {
  const eleven = usageSettings({ usageDisplay: 'always', accounts: manyAccounts(11), apiKeyEnv: 'ACCOUNT_2' })
  await act(async () => {
    render(<UsagePill settings={eleven.scope} directory={directory('dsh-clinepass')}
      readUsage={vi.fn().mockResolvedValue(usage)} t={t} />)
  })
  expect(trigger().querySelector(`.${css.account}`)?.textContent).toBe('Account 2')
  expect(trigger().textContent).not.toContain('+9')
  expect(trigger().textContent).not.toContain('9+')
})

it('keeps the styling choice out of the popover', async () => {
  const host = usageSettings({ usageDisplay: 'always' })
  await act(async () => {
    render(<UsagePill settings={host.scope} directory={directory('dsh-clinepass')}
      readUsage={vi.fn().mockResolvedValue(usage)} t={t} />)
  })
  const root = trigger().parentElement as HTMLElement
  expect(['#111214', '#f6f7f9']).toContain(root.style.getPropertyValue('--go-bg'))
  showDetails()
  // The stored style still paints the pill; only the Settings page may change it.
  await act(async () => { setGoTheme('silent-black') })
  expect(['#101010', '#f8f8f8']).toContain(root.style.getPropertyValue('--go-bg'))
  expect(within(openPanel()).queryByRole('group', { name: en.themeLabel })).toBeNull()
  expect(within(openPanel()).queryByRole('button', { name: en.themeSilentBlack })).toBeNull()
})
