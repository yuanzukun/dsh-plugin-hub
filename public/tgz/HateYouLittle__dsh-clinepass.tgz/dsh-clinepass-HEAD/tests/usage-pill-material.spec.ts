import { readFileSync } from 'node:fs'
import { expect, it } from 'vitest'

/**
 * The usage panel's frosted glass was lost three times to the same trap: this
 * repo's CSS modules are minified by lightningcss, which merges backdrop-filter
 * with -webkit-backdrop-filter and ships only the LAST spelling. Current
 * Chromium ignores -webkit-backdrop-filter entirely, so a source file that
 * carries both (prefix last) compiles to a stylesheet with no working blur.
 * These guards pin the structure that survives the build: the blur on a
 * dedicated material child (the host MenuSurface's shape), unprefixed.
 */
/** Declarations only: comments may quote the forbidden prefixed spelling. */
const source = readFileSync('src/client/UsagePill.module.css', 'utf8').replace(/\/\*[\s\S]*?\*\//g, '')

const rule = (name: string): string => source.match(new RegExp('\\' + name + ' \\{([^}]*)\\}'))?.[1] ?? ''

it('declares only the unprefixed backdrop-filter', () => {
  expect(source).toContain('backdrop-filter')
  expect(source).not.toContain('-webkit-backdrop-filter')
})

it('keeps the blur on the material child, never on the panel or its scroller', () => {
  expect(rule('.material')).toContain('backdrop-filter')
  expect(rule('.panel')).not.toContain('backdrop-filter')
  expect(rule('.panel')).not.toContain('overflow')
  expect(rule('.body')).toContain('overflow-y: auto')
})

it('keeps an opaque fallback for hosts without backdrop-filter', () => {
  expect(source).toMatch(/@supports not \(backdrop-filter: blur\(1px\)\)/)
})

/**
 * The switch label's ink rides half a pixel below the button's centre line — the
 * line box is strutted by the Latin font while the CJK glyphs come from the
 * fallback one — so the box-centred 14px chevron reads high beside 切换 / Switch.
 * The arrow therefore carries its own half-pixel shift onto the label.
 */
it('nudges the switch chevron onto the label\u2019s optical centre', () => {
  expect(rule('.switch svg')).toContain('display: block')
  expect(rule('.switch svg')).toContain('transform: translateY(.5px)')
})

/**
 * The pill sits beside the Host's own model chip; the reporter asked for the outer
 * frame and its text to grow with that control without turning the composer row into
 * a second toolbar. These values are the accepted size (2026-10-19).
 */
it('keeps the composer pill at its enlarged size', () => {
  expect(rule('.trigger')).toContain('font-size: 12.5px')
  expect(rule('.trigger')).toContain('padding: 4px 9px')
  expect(rule('.trigger')).toContain('border-radius: 12px')
})
