// @vitest-environment node
import { afterEach, expect, it, vi } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import Gateway from '@deepseek-ai/dsh-api-gateway'
import Registry from '@deepseek-ai/dsh-typert-registry'
import LlmRuntime, { createUserMessage } from '@deepseek-ai/dsh-llm'
import type { StreamChunk } from '@deepseek-ai/dsh-llm'
import FileSettingsProvider from '@deepseek-ai/dsh-settings-file'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { apply } from '../src/index.ts'
import { accountsOf } from '../src/accounts.ts'
import type { ClinePassConfig } from '../src/config.ts'
import { configOf } from './config-of.ts'
import { mockGateway, listingBody, textEvents, closeMockGateways, CURATED_IDS } from './mock-gateway.ts'
import type { MockGateway } from './mock-gateway.ts'
import { curatedModelIds } from '../src/clinepass-models.ts'

/**
 * A fallback that lands on a usable account has to become the current one: the
 * Settings page and the usage pill follow the stored preference, so the write is
 * what makes the next request start from the account that just worked. These
 * tests drive the real route and watch the settings face the plugin writes
 * through.
 */
const accounts = [
  { id: 'a', name: 'Primary', apiKeyEnv: 'ACCOUNT_A' },
  { id: 'b', name: 'Backup', apiKeyEnv: 'ACCOUNT_B' },
]
const request = () => ({ provider: 'dsh-clinepass', model: 'cline-pass/deepseek-v4.1-flash', sessionId: 'adopt-session' as never,
  messages: [createUserMessage({ content: [{ type: 'text', text: 'hello' }], source: { kind: 'plugin', plugin: 'test' } })] })
const drain = async (stream: AsyncIterable<StreamChunk>): Promise<StreamChunk[]> => {
  const chunks: StreamChunk[] = []
  for await (const chunk of stream) chunks.push(chunk)
  return chunks
}
afterEach(closeMockGateways)

/** The Host settings face an adoption writes through: editable rows, one atomic batch. */
function stubSettings(rows: { ns: string; revision: number; value: unknown } | { ns: string; revision: number; value: unknown }[],
  mutate = vi.fn(async () => {})) {
  return { describe: () => Array.isArray(rows) ? rows : [rows], mutate, configure: () => () => {} }
}

async function mount(settings: ReturnType<typeof stubSettings> | undefined, config: ReturnType<typeof configOf>) {
  const ctx = new Context()
  await ctx.plugin(LlmRuntime)
  await ctx.plugin(Registry)
  await ctx.plugin(Gateway)
  ctx.provide('credentials', {
    describe: async () => ({ configured: true, writable: true }),
    resolve: async (ref: string) => ({ value: `${ref}-secret`, source: 'test' }),
  } as never)
  if (settings !== undefined) ctx.provide('settings', settings as never)
  apply(ctx, config)
  await vi.waitFor(() => { expect(ctx.llm.listProviders().some(provider => provider.id === 'dsh-clinepass')).toBe(true) })
  return ctx
}

/** One request whose preferred account is over quota and whose backup answers. */
async function quotaThenText() {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: 429, body: JSON.stringify({ error: { message: 'Monthly usage limit exceeded' } }) })
  gateway.pushCompletions({ events: textEvents })
  return gateway
}

async function withFileSettings(config: ClinePassConfig, run: (ctx: Context, path: string) => Promise<void>): Promise<void> {
  const dir = await mkdtemp(join(tmpdir(), 'clinepass-adopt-'))
  const ctx = new Context()
  try {
    const path = join(dir, 'settings.yaml')
    await writeFile(path, '')
    await ctx.plugin(LlmRuntime)
    await ctx.plugin(Registry)
    await ctx.plugin(Gateway)
    await ctx.plugin(FileSettingsProvider, { path, watch: false })
    ctx.provide('credentials', {
      describe: async () => ({ configured: true, writable: true }),
      resolve: async (ref: string) => ({ value: `${ref}-secret`, source: 'test' }),
    } as never)
    apply(ctx, config)
    await vi.waitFor(() => { expect(ctx.llm.listProviders().some(provider => provider.id === 'dsh-clinepass')).toBe(true) })
    await run(ctx, path)
  } finally {
    await ctx.fiber.dispose()
    await rm(dir, { recursive: true, force: true })
  }
}

/** Hold the backup's real HTTP response until the competing action has committed. */
function holdBackupResponse(gateway: MockGateway) {
  const received = Promise.withResolvers<void>()
  const released = Promise.withResolvers<void>()
  const fetch = globalThis.fetch
  const spy = vi.spyOn(globalThis, 'fetch').mockImplementation(async (input, init) => {
    const response = await fetch(input, init)
    const url = input instanceof Request ? input.url : String(input)
    const headers = new Headers(init?.headers ?? (input instanceof Request ? input.headers : undefined))
    if (url.startsWith(gateway.url) && headers.get('authorization') === 'Bearer ACCOUNT_B-secret') {
      received.resolve()
      await released.promise
    }
    return response
  })
  return { received: received.promise, release: released.resolve, restore: () => spy.mockRestore() }
}

async function readUsage(ctx: Context, gateway: MockGateway) {
  const limits = [
    { type: 'five_hour', percentUsed: 10, resetsAt: '2026-09-21T00:00:00Z' },
    { type: 'weekly', percentUsed: 20, resetsAt: '2026-09-21T00:00:00Z' },
    { type: 'monthly', percentUsed: 30, resetsAt: '2026-09-21T00:00:00Z' },
  ]
  gateway.pushCompletions({ status: 200, body: JSON.stringify({ data: { limits } }) })
  return ctx.typertGateway.invoke({ namespace: 'clinePassUsage', method: 'read', args: {} })
}

it('polls the shipped catalog without describing account settings', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([CURATED_IDS.flash]) })
  await withFileSettings(configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }), async ctx => {
    const describe = vi.spyOn(ctx.settings, 'describe')
    const writes = vi.spyOn(ctx.settings, 'mutate')
    try {
      // Match the host's catalog construction, including cold discovery and warm polls.
      for (let poll = 0; poll < 3; poll++) {
        const models = await ctx.llm.listModels('dsh-clinepass')
        expect(models.map(model => model.id)).toEqual(curatedModelIds())
        for (const model of models) {
          expect(await ctx.llm.resolveModelInfo('dsh-clinepass', model.id)).toMatchObject({
            id: model.id, context: { contextWindow: 921_600 },
          })
        }
      }
      expect(describe).not.toHaveBeenCalled()
      expect(writes).not.toHaveBeenCalled()
    } finally {
      describe.mockRestore()
      writes.mockRestore()
    }
  })
})

it('makes the account a fallback settled on the profile current one', async () => {
  const gateway = await quotaThenText()
  const settings = stubSettings({ ns: 'clinepass', revision: 7, value: { apiKeyEnv: 'ACCOUNT_A' } })
  const ctx = await mount(settings, configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }))
  try {
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    await vi.waitFor(() => { expect(settings.mutate).toHaveBeenCalledTimes(1) })
    expect(settings.mutate).toHaveBeenCalledWith(
      'clinepass', [
        { op: 'set', path: ['accounts'], value: [accounts[1], accounts[0]] },
        { op: 'set', path: ['apiKeyEnv'], value: 'ACCOUNT_B' },
      ], 7,
    )
  } finally { await ctx.fiber.dispose() }
})

it('writes through the settings namespace a legacy Host serves', async () => {
  const gateway = await quotaThenText()
  const settings = stubSettings({ ns: 'llm-clinepass', revision: 4, value: { apiKeyEnv: 'ACCOUNT_A' } })
  const ctx = await mount(settings, configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }))
  try {
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    await vi.waitFor(() => { expect(settings.mutate).toHaveBeenCalledTimes(1) })
    expect(settings.mutate).toHaveBeenCalledWith(
      'llm-clinepass', [
        { op: 'set', path: ['accounts'], value: [accounts[1], accounts[0]] },
        { op: 'set', path: ['apiKeyEnv'], value: 'ACCOUNT_B' },
      ], 4,
    )
  } finally { await ctx.fiber.dispose() }
})

it('leaves a manual switch alone when it landed first', async () => {
  const gateway = await quotaThenText()
  // The stored preference already moved on: the fallback must not overwrite it.
  const settings = stubSettings({ ns: 'clinepass', revision: 9, value: { apiKeyEnv: 'ACCOUNT_C' } })
  const ctx = await mount(settings, configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }))
  try {
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    await new Promise(resolve => setTimeout(resolve, 20))
    expect(settings.mutate).not.toHaveBeenCalled()
  } finally { await ctx.fiber.dispose() }
})

it('reports a refused adoption without disturbing the request', async () => {
  const gateway = await quotaThenText()
  const mutate = vi.fn(async () => { throw new Error('settings provider is read-only') })
  const settings = stubSettings({ ns: 'clinepass', revision: 2, value: { apiKeyEnv: 'ACCOUNT_A' } }, mutate)
  const ctx = await mount(settings, configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }))
  try {
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    await vi.waitFor(() => { expect(mutate).toHaveBeenCalledTimes(1) })
  } finally { await ctx.fiber.dispose() }
})

it('keeps serving requests on a Host without a settings service', async () => {
  const gateway = await quotaThenText()
  const ctx = await mount(undefined, configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }))
  try {
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
  } finally { await ctx.fiber.dispose() }
})

it('never adopts when automatic fallback is off', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: 429, body: JSON.stringify({ error: { message: 'Monthly usage limit exceeded' } }) })
  const settings = stubSettings({ ns: 'clinepass', revision: 3, value: { apiKeyEnv: 'ACCOUNT_A' } })
  const ctx = await mount(settings, configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A' }))
  try {
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'error' } })
    await new Promise(resolve => setTimeout(resolve, 20))
    expect(settings.mutate).not.toHaveBeenCalled()
  } finally { await ctx.fiber.dispose() }
})

it('persists the successful third account first and starts the next request with it', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  const third = { id: 'c', name: 'Third', apiKeyEnv: 'ACCOUNT_C' }
  for (let attempt = 0; attempt < 2; attempt++) {
    gateway.pushCompletions({ status: 429, body: JSON.stringify({ error: { message: 'Monthly usage limit exceeded' } }) })
  }
  gateway.pushCompletions({ events: textEvents })
  await withFileSettings(configOf(gateway.url, { accounts: [...accounts, third], apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }), async (ctx, path) => {
    const writes = vi.spyOn(ctx.settings, 'mutate')
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    await vi.waitFor(() => {
      expect(ctx.settings.get('llm-clinepass')).toMatchObject({ accounts: [third, ...accounts], apiKeyEnv: 'ACCOUNT_C' })
    })
    expect(writes).toHaveBeenCalledTimes(1)
    expect(await readFile(path, 'utf8')).toContain('apiKeyEnv: ACCOUNT_C')
    gateway.pushCompletions({ events: textEvents })
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    expect(gateway.headers.filter(header => header.authorization).map(header => header.authorization))
      .toEqual(['Bearer ACCOUNT_A-secret', 'Bearer ACCOUNT_B-secret', 'Bearer ACCOUNT_C-secret', 'Bearer ACCOUNT_C-secret'])
  })
})

it('follows the second hop when the stored preference still names the account the request began with', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  const rejection = { status: 401, body: JSON.stringify({ error: { message: 'Invalid API key' } }) }
  const quota = { status: 429, body: JSON.stringify({ error: { message: 'Monthly usage limit exceeded' } }) }
  // Request 1: the preferred key is rejected (and remembered), the backup serves.
  gateway.pushCompletions(rejection)
  gateway.pushCompletions({ events: textEvents })
  // Request 2: the preferred is skipped for that rejection, the backup is over
  // quota, and the third account serves.
  gateway.pushCompletions(quota)
  gateway.pushCompletions({ events: textEvents })
  const three = [...accounts, { id: 'c', name: 'Third', apiKeyEnv: 'ACCOUNT_C' }]
  // The stored value never moves off the account both requests begin with — the
  // first adoption was refused — so the second hop is still this request's to
  // make. A guard that named the account the journey *left* instead would see
  // ACCOUNT_B and silently decline to write anything.
  const settings = stubSettings({ ns: 'clinepass', revision: 11, value: { apiKeyEnv: 'ACCOUNT_A' } })
  const ctx = await mount(settings, configOf(gateway.url, { accounts: three, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }))
  try {
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    await vi.waitFor(() => { expect(settings.mutate).toHaveBeenCalledTimes(2) })
    expect(settings.mutate).toHaveBeenNthCalledWith(
      2, 'clinepass', [
        { op: 'set', path: ['accounts'], value: [three[2], ...accounts] },
        { op: 'set', path: ['apiKeyEnv'], value: 'ACCOUNT_C' },
      ], 11,
    )
    // The second request never reached the remembered key: it went B then C.
    expect(gateway.headers.filter(header => header.authorization).map(header => header.authorization))
      .toEqual(['Bearer ACCOUNT_A-secret', 'Bearer ACCOUNT_B-secret', 'Bearer ACCOUNT_B-secret', 'Bearer ACCOUNT_C-secret'])
  } finally { await ctx.fiber.dispose() }
})

it('prefers the profile entry over a legacy row that coexists with it', async () => {
  const gateway = await quotaThenText()
  const settings = stubSettings([
    { ns: 'llm-clinepass', revision: 5, value: { apiKeyEnv: 'ACCOUNT_A' } },
    { ns: 'clinepass', revision: 6, value: { apiKeyEnv: 'ACCOUNT_A' } },
  ])
  const ctx = await mount(settings, configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }))
  try {
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    await vi.waitFor(() => { expect(settings.mutate).toHaveBeenCalledTimes(1) })
    // Only the profile entry is what the Web page and the pill read.
    expect(settings.mutate).toHaveBeenCalledWith(
      'clinepass', [
        { op: 'set', path: ['accounts'], value: [accounts[1], accounts[0]] },
        { op: 'set', path: ['apiKeyEnv'], value: 'ACCOUNT_B' },
      ], 6,
    )
  } finally { await ctx.fiber.dispose() }
})

it('lets a manual switch back to a rejected account serve, and keeps the fallback notice', async () => {
  const gateway = await mockGateway({ status: 200, body: listingBody([request().model]) })
  gateway.pushCompletions({ status: 401, body: JSON.stringify({ error: { message: 'Invalid API key' } }) })
  gateway.pushCompletions({ events: textEvents })
  await withFileSettings(configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }), async (ctx) => {
    // Request 1: the preferred key is rejected, the backup serves it and is adopted.
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    await vi.waitFor(() => {
      expect((ctx.settings.get('llm-clinepass') as { apiKeyEnv?: string } | undefined)?.apiKeyEnv).toBe('ACCOUNT_B')
    })
    // The adoption's own write must not retire the notice that reports it.
    const read = await readUsage(ctx, gateway)
    expect(read.lastSwitch).toMatchObject({ fromRef: 'ACCOUNT_A', toRef: 'ACCOUNT_B' })
    // The reader switches back: a stored selection outranks the remembered
    // rejection, so the next request must start from the chosen account again.
    await ctx.settings.mutate('llm-clinepass', [{ op: 'set', path: ['apiKeyEnv'], value: 'ACCOUNT_A' }])
    const before = gateway.bodies.length
    gateway.pushCompletions({ events: textEvents })
    expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
    expect(gateway.bodies).toHaveLength(before + 1)
    expect(gateway.headers.at(-1)?.authorization).toBe('Bearer ACCOUNT_A-secret')
  })
})

it.each(['removing the backup', 'disabling automatic fallback', 'switching away and back', 'updating the current credential', 'a newer successful request'] as const)(
  'ignores an old fallback after %s', async (change) => {
    const gateway = await quotaThenText()
    const three = [...accounts, { id: 'c', name: 'Third', apiKeyEnv: 'ACCOUNT_C' }]
    await withFileSettings(configOf(gateway.url, { accounts: three, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }), async (ctx, path) => {
      const gate = holdBackupResponse(gateway)
      const writes = vi.spyOn(ctx.settings, 'mutate')
      const pending = drain(ctx.llm.stream(request()))
      try {
        await gate.received
        if (change === 'removing the backup') {
          await ctx.settings.mutate('llm-clinepass', [{ op: 'set', path: ['accounts'], value: [three[0], three[2]] }])
        } else if (change === 'disabling automatic fallback') {
          await ctx.settings.mutate('llm-clinepass', [{ op: 'set', path: ['autoSwitch'], value: false }])
        } else if (change === 'switching away and back') {
          await ctx.settings.mutate('llm-clinepass', [{ op: 'set', path: ['apiKeyEnv'], value: 'ACCOUNT_C' }])
          await ctx.settings.mutate('llm-clinepass', [{ op: 'set', path: ['apiKeyEnv'], value: 'ACCOUNT_A' }])
        } else if (change === 'updating the current credential') {
          // Repairing the selected key changes no settings value or revision.
          // Its credential event must still retire the old fallback's decision.
          ctx.emit('credentials/reference-updated', 'ACCOUNT_A')
        } else {
          gateway.pushCompletions({ events: textEvents })
          expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
          expect(gateway.headers.at(-1)?.authorization).toBe('Bearer ACCOUNT_A-secret')
        }
        gate.release()
        expect((await pending).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
        // Adoption does not block output. Settle every observed settings write
        // before checking the persisted preference, without timing guesses.
        await Promise.all(writes.mock.results.map(result => result.value))
        const stored = ctx.settings.get('llm-clinepass') as ClinePassConfig
        expect(stored.apiKeyEnv).toBe('ACCOUNT_A')
        expect(await readFile(path, 'utf8')).not.toMatch(/^  apiKeyEnv: ACCOUNT_B$/m)
        if (change === 'removing the backup') {
          expect(accountsOf(stored).map(account => account.apiKeyEnv)).toEqual(['ACCOUNT_A', 'ACCOUNT_C'])
        }
        if (change === 'disabling automatic fallback') expect(stored.autoSwitch).toBe(false)
        expect((await readUsage(ctx, gateway)).lastSwitch).toBeUndefined()
      } finally {
        gate.release()
        await pending.catch(() => {})
        gate.restore()
        writes.mockRestore()
      }
    })
  },
)

it('keeps a manual selection made after preparation when that old call is dispatched later', async () => {
  const gateway = await quotaThenText()
  const three = [...accounts, { id: 'c', name: 'Third', apiKeyEnv: 'ACCOUNT_C' }]
  await withFileSettings(configOf(gateway.url, { accounts: three, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }), async (ctx, path) => {
    const options = request()
    const prepared = await ctx.llm.prepareCall({ provider: options.provider, model: options.model })
    await ctx.settings.mutate('llm-clinepass', [{ op: 'set', path: ['apiKeyEnv'], value: 'ACCOUNT_C' }])
    await ctx.settings.mutate('llm-clinepass', [{ op: 'set', path: ['apiKeyEnv'], value: 'ACCOUNT_A' }])
    const gate = holdBackupResponse(gateway)
    const writes = vi.spyOn(ctx.settings, 'mutate')
    const pending = drain(prepared.stream({ ...options, ...prepared.config }))
    try {
      await gate.received
      gate.release()
      expect((await pending).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
      await Promise.all(writes.mock.results.map(result => result.value))
      expect((ctx.settings.get('llm-clinepass') as ClinePassConfig).apiKeyEnv).toBe('ACCOUNT_A')
      expect(await readFile(path, 'utf8')).toMatch(/^  apiKeyEnv: ACCOUNT_A$/m)
      expect((await readUsage(ctx, gateway)).lastSwitch).toBeUndefined()
    } finally {
      gate.release()
      await pending.catch(() => {})
      gate.restore()
      writes.mockRestore()
    }
  })
})

it('clears a refused adoption before a later manual selection of the same account', async () => {
  const gateway = await quotaThenText()
  await withFileSettings(configOf(gateway.url, { accounts, apiKeyEnv: 'ACCOUNT_A', autoSwitch: true }), async (ctx) => {
    const writes = vi.spyOn(ctx.settings, 'mutate').mockRejectedValueOnce(new Error('settings write refused'))
    try {
      expect((await drain(ctx.llm.stream(request()))).at(-1)).toMatchObject({ reason: { kind: 'stop' } })
      expect(writes).toHaveBeenCalledTimes(1)
      expect((ctx.settings.get('llm-clinepass') as ClinePassConfig).apiKeyEnv).toBe('ACCOUNT_A')
      expect((await readUsage(ctx, gateway)).lastSwitch).toMatchObject({ fromRef: 'ACCOUNT_A', toRef: 'ACCOUNT_B' })
      await ctx.settings.mutate('llm-clinepass', [{ op: 'set', path: ['apiKeyEnv'], value: 'ACCOUNT_B' }])
      expect((await readUsage(ctx, gateway)).lastSwitch).toBeUndefined()
    } finally { writes.mockRestore() }
  })
})
