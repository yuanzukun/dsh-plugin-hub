/**
 * The ClinePass settings page's staged form and controller: what a draft
 * shows before it is written, which wire call a save reaches, how credential
 * state is probed and written outside the section, and what happens to drafts
 * the Host did not accept.
 */

import { describe, expect, it, vi, type Mock } from 'vitest'
import type { LlmDiscoveredModel, SettingsPathOpView } from '@deepseek-ai/dsh-api-remotes/client'
import type { AccountCommand } from '../src/accounts-contract.ts'
import { RemoteError, stubSettingsScope, acceptSettingsWrites } from './support/client.ts'
import {
  StagedForm,
  jsonField,
  numberField,
  textField,
  type FieldState,
  type FormShell,
} from '../src/client/staged-form.ts'
import {
  ClinePassSectionController,
  type ClinePassSettings,
} from '../src/client/section-controller.ts'

/** Accept document writes through the same atomic seam as a real Host. */
const acceptWrites = acceptSettingsWrites

function mutateSpy(host: ReturnType<typeof stubSettingsScope>): Mock<(ops: readonly SettingsPathOpView[], revision?: number) => Promise<void>> {
  return host.mutate as Mock<(ops: readonly SettingsPathOpView[], revision?: number) => Promise<void>>
}

/** The page plugin's context, scripted down to the namespaces it reaches. */
function ctxWith(namespaces: object) {
  return { remote: namespaces } as never
}

function credentialsApi(configured: boolean, ref = 'CLINE_API_KEY') {
  const describe = vi.fn(() => Promise.resolve({
    ok: true as const,
    value: { [ref]: { configured, writable: true } },
  }))
  const set = vi.fn((_ref: string, _key: string) => Promise.resolve({ ok: true as const, value: undefined }))
  const execute = vi.fn(async (command: AccountCommand) => {
    if (command.kind !== 'replace-key') throw new Error('Unexpected account command')
    await set(command.ref, command.key)
    return { ok: true as const, value: 'applied' as const }
  })
  return { ctx: ctxWith({ credentials: { describe }, clinePassAccounts: { execute } }), describe, set, execute }
}

/** A context whose credential reads answer, and whose model discovery is scripted. */
function pageCtx(discoverModels: Mock) {
  const describe = vi.fn(() => Promise.resolve({ ok: true as const, value: {} }))
  return ctxWith({ credentials: { describe, set: vi.fn() }, llm: { discoverModels } })
}

/** A successful discovery answer carrying the given listing. */
function discovered(models: readonly { id: string; name?: string }[]): {
  ok: true
  value: readonly LlmDiscoveredModel[]
} {
  return { ok: true, value: models }
}

const settled: FormShell = {
  available: true,
  writable: true,
  dirty: false,
  invalid: false,
  saving: false,
  failed: false,
}

function field(text: string, rest: Partial<FieldState> = {}): FieldState {
  return { text, overridden: false, invalid: false, ...rest }
}

const specs = [textField('baseURL'), numberField('refreshMinutes')]

describe('StagedForm', () => {
  it('shows the effective value and the override state without staged edits', () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const form = new StagedForm(host.scope as never, specs)
    host.publish({
      status: 'ready',
      writable: true,
      value: { baseURL: 'https://gateway.test/v1', refreshMinutes: 30 },
      user: { refreshMinutes: 30 },
    })

    expect(form.shell()).toEqual(settled)
    expect(form.field('baseURL')).toEqual(field('https://gateway.test/v1'))
    expect(form.field('refreshMinutes')).toEqual(field('30', { overridden: true }))
  })

  it('stages edits and previews override and invalid states before any write', () => {
    const host = stubSettingsScope<ClinePassSettings>()
    acceptWrites(host)
    const form = new StagedForm(host.scope as never, specs)
    host.publish({ status: 'ready', writable: true, value: { refreshMinutes: 60 }, user: {} })

    form.actions().edit('refreshMinutes', '45')
    expect(form.field('refreshMinutes')).toEqual(field('45', { overridden: true }))
    expect(form.shell().dirty).toBe(true)

    form.actions().edit('refreshMinutes', 'not-a-number')
    expect(form.field('refreshMinutes')).toEqual(field('not-a-number', { overridden: false, invalid: true }))
    expect(form.shell().invalid).toBe(true)

    form.actions().edit('refreshMinutes', '')
    // An empty number draft is a clear, not an invalid value.
    expect(form.field('refreshMinutes')).toEqual(field('', { overridden: false }))
    expect(form.shell().invalid).toBe(false)
  })

  it('skips saving a draft that equals the stored value, and refuses invalid plans', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    acceptWrites(host)
    const form = new StagedForm(host.scope as never, specs)
    host.publish({ status: 'ready', writable: true, value: { baseURL: 'https://gateway.test/v1' }, user: {} })
    const actions = form.actions()

    actions.edit('baseURL', 'https://gateway.test/v1')
    actions.save()
    await vi.waitFor(() => { expect(host.set).not.toHaveBeenCalled() })
    expect(form.shell().dirty).toBe(false)

    actions.edit('baseURL', '   ')
    actions.edit('refreshMinutes', 'nope')
    await form.save()
    expect(host.set).not.toHaveBeenCalled()
    expect(form.shell().dirty).toBe(true)
  })

  it('drops the override badge once a draft returns to the effective value', () => {
    const host = stubSettingsScope<ClinePassSettings>()
    acceptWrites(host)
    const form = new StagedForm(host.scope as never, specs)
    host.publish({ status: 'ready', writable: true, value: { refreshMinutes: 60 }, base: { refreshMinutes: 60 }, user: {} })
    const actions = form.actions()

    actions.edit('refreshMinutes', '59')
    expect(form.field('refreshMinutes')).toEqual(field('59', { overridden: true }))
    expect(form.shell().dirty).toBe(true)

    // The save plan skips a draft equal to the effective value, so the badge and
    // the Save button must agree: nothing is overridden and nothing is pending.
    actions.edit('refreshMinutes', '60')
    expect(form.field('refreshMinutes')).toEqual(field('60'))
    expect(form.shell().dirty).toBe(false)
  })

  it('keeps the override badge for a user-layer entry the draft leaves in place', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    acceptWrites(host)
    const form = new StagedForm(host.scope as never, specs)
    host.publish({
      status: 'ready', writable: true,
      value: { refreshMinutes: 60 }, base: { refreshMinutes: 60 }, user: { refreshMinutes: 60 },
    })

    form.actions().edit('refreshMinutes', '60')
    // The draft writes nothing, but the user layer keeps the entry the page can clear.
    expect(form.field('refreshMinutes')).toEqual(field('60', { overridden: true }))
    expect(form.shell().dirty).toBe(false)
    form.actions().resetField('refreshMinutes')
    await form.save()
    expect(host.mutate).toHaveBeenCalledWith([{ op: 'unset', path: ['refreshMinutes'] }], expect.any(Number))
  })

  it('writes staged edits on save, clears accepted drafts, and re-reads from the Host', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    acceptWrites(host)
    const form = new StagedForm(host.scope as never, specs)
    host.publish({ status: 'ready', writable: true, value: { refreshMinutes: 60 }, user: {} })

    form.actions().edit('baseURL', 'https://new.test/v1')
    form.actions().edit('refreshMinutes', '15')
    await form.save()

    expect(host.mutate).toHaveBeenCalledWith([
      { op: 'set', path: ['baseURL'], value: 'https://new.test/v1' },
      { op: 'set', path: ['refreshMinutes'], value: 15 },
    ], 0)
    expect(host.set).not.toHaveBeenCalled()
    expect(form.shell()).toEqual(settled)
  })

  it('keeps drafts and reports failure when the Host does not hold what was staged', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const form = new StagedForm(host.scope as never, specs)
    // The Host never publishes the write back: the read-back reports failure.
    mutateSpy(host).mockImplementation(() => Promise.resolve())
    host.publish({ status: 'ready', writable: true, value: {}, user: {} })

    form.actions().edit('baseURL', 'https://rejected.test/v1')
    await form.save()

    expect(form.shell()).toMatchObject({ dirty: true, failed: true })
    form.actions().discard()
    expect(form.shell()).toEqual(settled)
  })

  it('accepts the modern host verdict while its browser snapshot is still catching up', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    host.mutate.mockResolvedValue(true)
    const form = new StagedForm(host.scope as never, specs)
    host.publish({ status: 'ready', writable: true, value: { refreshMinutes: 60 }, user: {} })
    form.actions().edit('refreshMinutes', '15')
    await form.save()
    expect(form.shell()).toEqual(settled)
    expect(host.scope.getSnapshot().value?.refreshMinutes).toBe(60)
    host.publish({ value: { refreshMinutes: 15 }, user: { refreshMinutes: 15 } })
    expect(form.field('refreshMinutes').text).toBe('15')
  })

  it('does not start a second save while one is in flight and drops empty discards', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const form = new StagedForm(host.scope as never, specs)
    host.publish({ status: 'ready', writable: true, value: {}, user: {} })
    form.actions().discard()
    expect(form.shell()).toEqual(settled)

    let release!: () => void
    mutateSpy(host).mockImplementation(() => new Promise<void>((resolve) => { release = resolve }))
    form.actions().edit('baseURL', 'https://slow.test/v1')
    const first = form.save()
    form.actions().save()
    expect(host.mutate).toHaveBeenCalledTimes(1)
    release()
    await first
  })

  it('clears a stored field only when the user layer carries it', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    acceptWrites(host)
    const form = new StagedForm(host.scope as never, specs)
    host.publish({ status: 'ready', writable: true, value: { baseURL: 'https://x.test/v1' }, user: { baseURL: 'https://x.test/v1' } })

    form.actions().resetField('baseURL')
    await form.save()

    expect(host.mutate).toHaveBeenCalledWith([{ op: 'unset', path: ['baseURL'] }], expect.any(Number))
    expect(form.field('baseURL').overridden).toBe(false)

    // A second clear of an inherited field plans nothing.
    form.actions().resetField('baseURL')
    expect(form.shell().dirty).toBe(false)
  })

  it('previews a staged clear and plans a parse-clear write', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    acceptWrites(host)
    const form = new StagedForm(host.scope as never, specs)
    host.publish({
      status: 'ready',
      writable: true,
      value: { refreshMinutes: 60 },
      base: { refreshMinutes: 60 },
      user: { refreshMinutes: 60 },
    })
    const actions = form.actions()

    // A reset previews as not overridden: saving clears the user layer.
    actions.resetField('refreshMinutes')
    expect(form.field('refreshMinutes')).toEqual(field('60', { overridden: false }))

    await form.save()
    expect(host.mutate).toHaveBeenCalledWith([{ op: 'unset', path: ['refreshMinutes'] }], expect.any(Number))

    // A blank number draft parses to a clear, which plans the same write.
    actions.edit('refreshMinutes', '')
    await form.save()
    expect(host.mutate).toHaveBeenCalledTimes(2)
  })

  it('plans nothing for a secret staged blank, keeping the stored key', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const credentials = credentialsApi(true)
    const controller = new ClinePassSectionController(host.scope, credentials.ctx)
    host.publish({ status: 'ready', writable: true, value: {}, user: {} })
    const face = controller.inject()

    face.edit('apiKey', '   ')
    face.save()
    await vi.waitFor(() => { expect(face.hooks.clinePass.getSnapshot().saving).toBe(false) })

    expect(credentials.set).not.toHaveBeenCalled()
    // A blank secret plans nothing, so the form is clean without discarding.
    expect(face.hooks.clinePass.getSnapshot().dirty).toBe(false)
  })

  it('reports an unready namespace and refuses unknown fields loudly', () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const form = new StagedForm(host.scope as never, specs)

    expect(form.shell().available).toBe(false)
    expect(() => form.field('mystery')).toThrow(/no field mystery/)
  })
})

describe('jsonField', () => {
  const spec = jsonField('modelLimits')

  it('formats an absent value as empty text and an object as readable JSON', () => {
    expect(spec.format(undefined)).toBe('')
    expect(JSON.parse(spec.format({ 'mimo-v2.6-flash': { contextWindow: 262_144 } })))
      .toEqual({ 'mimo-v2.6-flash': { contextWindow: 262_144 } })
  })

  it('accepts an object draft, clears on empty, and blocks malformed JSON', () => {
    expect(spec.parse('{"a":{"maxTokens":32768}}'))
      .toEqual({ kind: 'set', value: { a: { maxTokens: 32768 } } })
    expect(spec.parse('   ')).toEqual({ kind: 'clear' })
    expect(spec.parse('{not json')).toBeUndefined()
  })

  it('stages a per-model map through the shared form', () => {
    const host = stubSettingsScope<ClinePassSettings>()
    acceptWrites(host)
    const form = new StagedForm(host.scope as never, [...specs, spec])
    host.publish({ status: 'ready', writable: true, value: {}, user: {} })

    form.actions().edit('modelLimits', '{"mimo-v2.6-flash":{"contextWindow":262144,"maxTokens":32768}}')

    expect(form.field('modelLimits').overridden).toBe(true)
    expect(form.field('modelLimits').invalid).toBe(false)

    form.actions().edit('modelLimits', '{broken')
    expect(form.field('modelLimits').invalid).toBe(true)
    expect(form.shell().invalid).toBe(true)
  })

  it('accepts a structured settings write when the Host returns a cloned value', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const form = new StagedForm(host.scope as never, [...specs, spec])
    const current = () => host.scope.getSnapshot()
    mutateSpy(host).mockImplementation(async (ops) => {
      const { path: [field], value } = ops[0] as Extract<SettingsPathOpView, { op: 'set' }>
      host.publish({
        value: { ...current().value as object, [field]: structuredClone(value) },
        user: { ...current().user as object, [field]: structuredClone(value) },
      })
    })
    host.publish({ status: 'ready', writable: true, value: {}, user: {} })

    form.actions().edit('modelLimits', '{"mimo-v2.6-flash":{"contextWindow":262144}}')
    await form.save()

    expect(form.shell()).toEqual(settled)
  })
})

describe('ClinePassSectionController', () => {
  const ready = (value: ClinePassSettings, user: Record<string, unknown> = {}) => ({
    status: 'ready' as const,
    writable: true,
    value,
    user,
  })

  it('stages and restores the usage display mode, including explicit auto over an inherited override', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    acceptWrites(host)
    host.publish({ ...ready({ usageDisplay: 'always' }), base: { usageDisplay: 'always' } })
    const controller = new ClinePassSectionController(host.scope, credentialsApi(false).ctx)
    const face = controller.inject()
    const state = () => face.hooks.clinePass.getSnapshot()
    expect(state().usageDisplay).toEqual(field('always'))
    face.edit('usageDisplay', 'auto')
    expect(state().dirty).toBe(true)
    expect(host.mutate).not.toHaveBeenCalled()
    face.discard()
    expect(state().usageDisplay.text).toBe('always')
    face.edit('usageDisplay', 'auto')
    face.save()
    await vi.waitFor(() => { expect(state()).toMatchObject({ dirty: false, saving: false }) })
    expect(host.scope.getSnapshot().value?.usageDisplay).toBe('auto')
    expect(state().usageDisplay).toEqual(field('auto', { overridden: true }))
    face.edit('usageDisplay', 'invalid')
    expect(state().invalid).toBe(true)
    face.save()
    expect(host.mutate).toHaveBeenCalledTimes(1)
    face.discard()
    face.resetField('usageDisplay')
    expect(state().usageDisplay).toEqual(field('always'))
    face.save()
    await vi.waitFor(() => { expect(state()).toMatchObject({ dirty: false, saving: false }) })
    expect(host.scope.getSnapshot().value?.usageDisplay).toBe('always')
    controller.dispose()
  })

  it('stages, discards, saves, validates, and resets usage display to its inherited mode', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    acceptWrites(host)
    host.publish(ready({}))
    const controller = new ClinePassSectionController(host.scope, credentialsApi(false).ctx)
    const face = controller.inject()
    const state = () => face.hooks.clinePass.getSnapshot()
    expect(state().usageDisplay).toEqual(field('auto'))
    face.edit('usageDisplay', 'always')
    expect(state().dirty).toBe(true)
    expect(host.set).not.toHaveBeenCalled()
    expect(host.scope.getSnapshot().value?.usageDisplay).toBeUndefined()
    face.discard()
    expect(state().usageDisplay.text).toBe('auto')
    face.edit('usageDisplay', 'always')
    face.save()
    await vi.waitFor(() => { expect(state()).toMatchObject({ dirty: false, saving: false }) })
    expect(host.mutate).toHaveBeenCalledWith([{ op: 'set', path: ['usageDisplay'], value: 'always' }], 0)
    expect(host.scope.getSnapshot().value?.usageDisplay).toBe('always')
    face.edit('usageDisplay', 'invalid')
    expect(state().invalid).toBe(true)
    face.save()
    expect(host.mutate).toHaveBeenCalledTimes(1)
    face.discard()
    host.publish({ base: { usageDisplay: 'off' } })
    face.resetField('usageDisplay')
    expect(state().usageDisplay).toEqual(field('off'))
    face.save()
    await vi.waitFor(() => { expect(state()).toMatchObject({ dirty: false, saving: false }) })
    expect(host.mutate).toHaveBeenCalledWith([{ op: 'unset', path: ['usageDisplay'] }], expect.any(Number))
    expect(host.scope.getSnapshot().value?.usageDisplay).toBe('off')
    controller.dispose()
  })

  it('reads the credential state for the reference the section names', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const credentials = credentialsApi(true, 'MY_CLINE_KEY')
    const controller = new ClinePassSectionController(host.scope, credentials.ctx)
    const state = () => controller.inject().hooks.clinePass.getSnapshot()
    await vi.waitFor(() => { expect(credentials.describe).toHaveBeenCalled() })

    host.publish(ready({ baseURL: 'https://gateway.test/v1', apiKeyEnv: 'MY_CLINE_KEY' }))
    await vi.waitFor(() => { expect(state().apiKeyConfigured).toBe(true) })

    expect(credentials.describe).toHaveBeenCalledWith(['MY_CLINE_KEY'])
    expect(state()).toMatchObject({
      baseURL: { text: 'https://gateway.test/v1', overridden: false },
      refreshMinutes: { text: '', overridden: false },
      apiKey: { text: '', overridden: false },
      apiKeyWritable: true,
    })
  })

  it('defaults the credential reference when the section names none', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const credentials = credentialsApi(false)
    new ClinePassSectionController(host.scope, credentials.ctx)
    host.publish(ready({}))

    await vi.waitFor(() => {
      expect(credentials.describe).toHaveBeenCalledWith(['CLINE_API_KEY'])
    })
  })

  it('resets the credential answer when the section starts naming another reference', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const credentials = credentialsApi(true, 'FIRST_REF')
    const controller = new ClinePassSectionController(host.scope, credentials.ctx)
    host.publish(ready({ apiKeyEnv: 'FIRST_REF' }))
    await vi.waitFor(() => { expect(controller.inject().hooks.clinePass.getSnapshot().apiKeyConfigured).toBe(true) })

    credentials.describe.mockImplementation(() => Promise.resolve({
      ok: true as const,
      value: { SECOND_REF: { configured: false, writable: true } },
    }))
    host.publish(ready({ apiKeyEnv: 'SECOND_REF' }))

    await vi.waitFor(() => {
      expect(controller.inject().hooks.clinePass.getSnapshot().apiKeyConfigured).toBe(false)
    })
    expect(credentials.describe).toHaveBeenCalledWith(['SECOND_REF'])
  })

  it('drops a describe response that failed or drifted to another reference', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const credentials = credentialsApi(true)
    const controller = new ClinePassSectionController(host.scope, credentials.ctx)
    host.publish(ready({}))
    await vi.waitFor(() => { expect(controller.inject().hooks.clinePass.getSnapshot().apiKeyConfigured).toBe(true) })
    const state = () => controller.inject().hooks.clinePass.getSnapshot()

    credentials.describe.mockImplementation(() => Promise.resolve({
      ok: false as const,
      error: new RemoteError('gateway/internal', 'describe failed', {}),
    } as never))
    let calls = credentials.describe.mock.calls.length
    host.publish(ready({}))
    await vi.waitFor(() => { expect(credentials.describe.mock.calls.length).toBeGreaterThan(calls) })
    expect(state().apiKeyConfigured).toBe(true)

    // A batch naming another reference carries no entry for the one in force;
    // the badge reports it unconfigured rather than keeping a stale claim.
    credentials.describe.mockImplementation(() => Promise.resolve({
      ok: true as const,
      value: { OTHER_REF: { configured: false, writable: false } },
    }))
    calls = credentials.describe.mock.calls.length
    host.publish(ready({}))
    await vi.waitFor(() => {
      expect(credentials.describe.mock.calls.length).toBeGreaterThan(calls)
      expect(state().apiKeyConfigured).toBe(false)
    })
  })

  it('refreshes the credential badge only for the reference it watches', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const credentials = credentialsApi(true)
    const controller = new ClinePassSectionController(host.scope, credentials.ctx)
    host.publish(ready({}))
    await vi.waitFor(() => { expect(credentials.describe).toHaveBeenCalled() })

    controller.refreshCredential('SOME_OTHER_REF')
    const calls = credentials.describe.mock.calls.length
    expect(credentials.describe.mock.calls.length).toBe(calls)

    controller.refreshCredential('CLINE_API_KEY')
    await vi.waitFor(() => { expect(credentials.describe.mock.calls.length).toBeGreaterThan(calls) })
  })

  it('writes the staged key through the host account command, never the settings section', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const credentials = credentialsApi(false)
    const controller = new ClinePassSectionController(host.scope, credentials.ctx)
    host.publish(ready({}))
    const face = controller.inject()

    face.edit('apiKey', ' clinepass-secret ')
    expect(face.hooks.clinePass.getSnapshot().dirty).toBe(true)
    expect(credentials.set).not.toHaveBeenCalled()

    credentials.describe.mockImplementation(() => Promise.resolve({
      ok: true as const,
      value: { CLINE_API_KEY: { configured: true, writable: true } },
    }))
    face.save()
    await vi.waitFor(() => { expect(credentials.set).toHaveBeenCalled() })

    expect(credentials.set).toHaveBeenCalledWith('CLINE_API_KEY', 'clinepass-secret')
    expect(credentials.execute).toHaveBeenCalledWith({ kind: 'replace-key', ref: 'CLINE_API_KEY', key: 'clinepass-secret' })
    expect(host.set).not.toHaveBeenCalled()
    await vi.waitFor(() => {
      expect(face.hooks.clinePass.getSnapshot()).toMatchObject({ dirty: false, apiKeyConfigured: true })
    })
  })

  it('reads the gateway listing for this adapter and previews its model names', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const discoverModels = vi.fn(() => Promise.resolve(discovered([
      { id: 'cline-pass/deepseek-v4.1-flash', name: 'DeepSeek V4.1 Flash' },
      { id: 'cline-pass/deepseek-v4-pro' },
      { id: 'kimi-k2' }, { id: 'glm-5' }, { id: 'qwen3-max' }, { id: 'grok-5' }, { id: 'gpt-6' },
    ])))
    const controller = new ClinePassSectionController(host.scope, pageCtx(discoverModels))
    host.publish(ready({}))
    const state = () => controller.inject().hooks.clinePass.getSnapshot()

    expect(state().models).toEqual({ status: 'idle' })
    controller.loadModels()
    expect(state().models).toEqual({ status: 'loading' })
    expect(discoverModels).toHaveBeenCalledWith('llm-clinepass', { provider: 'dsh-clinepass' })

    await vi.waitFor(() => { expect(state().models.status).toBe('ready') })
    // Every model is visible, including those beyond the former six-name preview.
    expect(state().models).toEqual({
      status: 'ready',
      stale: false,
      count: 7,
      preview: ['DeepSeek V4.1 Flash', 'cline-pass/deepseek-v4-pro', 'kimi-k2', 'glm-5', 'qwen3-max', 'grok-5', 'gpt-6'],
      entries: [
        { id: 'cline-pass/deepseek-v4.1-flash', name: 'DeepSeek V4.1 Flash' },
        { id: 'cline-pass/deepseek-v4-pro' },
        { id: 'kimi-k2' }, { id: 'glm-5' }, { id: 'qwen3-max' }, { id: 'grok-5' }, { id: 'gpt-6' },
      ],
    })
  })

  it('publishes model entries and the current per-model draft for the capacity editor', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const discoverModels = vi.fn(() => Promise.resolve(discovered([
      { id: 'mimo-v2.6-flash', name: 'Mimo V2.6 Flash', contextWindow: 262_144, maxTokens: 32_768 },
    ])))
    const controller = new ClinePassSectionController(host.scope, pageCtx(discoverModels))
    host.publish(ready({ modelLimits: { 'mimo-v2.6-flash': { contextWindow: 131_072 } } }, {
      modelLimits: { 'mimo-v2.6-flash': { contextWindow: 131_072 } },
    }))

    controller.loadModels()
    const state = () => controller.inject().hooks.clinePass.getSnapshot()
    await vi.waitFor(() => { expect(state().models.status).toBe('ready') })

    expect(state().models).toMatchObject({
      status: 'ready',
      count: 1,
      preview: ['Mimo V2.6 Flash'],
      entries: [{ id: 'mimo-v2.6-flash', name: 'Mimo V2.6 Flash', contextWindow: 262_144, maxTokens: 32_768 }],
    })
    expect(state().modelLimitDraft).toEqual({ 'mimo-v2.6-flash': { contextWindow: 131_072 } })
  })

  it('reports a refused listing with the Host diagnostic', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const discoverModels = vi.fn(() => Promise.resolve({
      ok: false as const,
      error: new RemoteError('llm/model-discovery-rejected', 'the live model listing is unreachable', {
        settingsNs: 'llm-clinepass',
      }),
    }))
    const controller = new ClinePassSectionController(host.scope, pageCtx(discoverModels))
    host.publish(ready({}))

    controller.loadModels()
    const state = () => controller.inject().hooks.clinePass.getSnapshot()
    await vi.waitFor(() => {
      expect(state().models).toEqual({ status: 'failed', message: 'the live model listing is unreachable' })
    })
  })

  it('reports a rejected listing read as a failure instead of loading forever', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    const discoverModels = vi.fn(() => Promise.reject(new Error('the gateway connection closed')))
    const controller = new ClinePassSectionController(host.scope, pageCtx(discoverModels))
    host.publish(ready({}))
    const state = () => controller.inject().hooks.clinePass.getSnapshot()

    controller.loadModels()
    expect(state().models).toEqual({ status: 'loading' })
    await vi.waitFor(() => {
      expect(state().models).toEqual({ status: 'failed', message: 'the gateway connection closed' })
    })
  })

  it('names a non-Error rejection in the failure it reports', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    // oxlint-disable-next-line typescript/prefer-promise-reject-errors -- the non-Error arm is the case under test.
    const discoverModels = vi.fn(() => Promise.reject('gateway offline'))
    const controller = new ClinePassSectionController(host.scope, pageCtx(discoverModels))
    host.publish(ready({}))

    controller.loadModels()
    await vi.waitFor(() => {
      expect(controller.inject().hooks.clinePass.getSnapshot().models)
        .toEqual({ status: 'failed', message: 'gateway offline' })
    })
  })

  it('drops a rejected listing answer a later read already replaced', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    let rejectFirst!: (reason: unknown) => void
    let settleSecond!: (answer: unknown) => void
    const discoverModels = vi.fn()
      .mockImplementationOnce(() => new Promise((_resolve, reject) => { rejectFirst = reject }))
      .mockImplementationOnce(() => new Promise((resolve) => { settleSecond = resolve }))
    const controller = new ClinePassSectionController(host.scope, pageCtx(discoverModels as never))
    host.publish(ready({}))
    const state = () => controller.inject().hooks.clinePass.getSnapshot()

    controller.loadModels()
    controller.loadModels()
    settleSecond(discovered([{ id: 'second' }]))
    await vi.waitFor(() => { expect(state().models).toEqual({ status: 'ready', stale: false, count: 1, preview: ['second'], entries: [{ id: 'second' }] }) })

    rejectFirst(new Error('the first read failed late'))
    await new Promise(resolve => setTimeout(resolve, 0))
    expect(state().models).toEqual({ status: 'ready', stale: false, count: 1, preview: ['second'], entries: [{ id: 'second' }] })
  })

  it('drops a listing answer a later read already replaced', async () => {
    const host = stubSettingsScope<ClinePassSettings>()
    let settleFirst!: (answer: unknown) => void
    let settleSecond!: (answer: unknown) => void
    const discoverModels = vi.fn()
      .mockImplementationOnce(() => new Promise((resolve) => { settleFirst = resolve }))
      .mockImplementationOnce(() => new Promise((resolve) => { settleSecond = resolve }))
    const controller = new ClinePassSectionController(host.scope, pageCtx(discoverModels as never))
    host.publish(ready({}))
    const state = () => controller.inject().hooks.clinePass.getSnapshot()

    controller.loadModels()
    controller.loadModels()
    settleSecond(discovered([{ id: 'second' }]))
    await vi.waitFor(() => { expect(state().models).toEqual({ status: 'ready', stale: false, count: 1, preview: ['second'], entries: [{ id: 'second' }] }) })

    settleFirst(discovered([{ id: 'first' }, { id: 'another' }]))
    await new Promise(resolve => setTimeout(resolve, 0))
    expect(state().models).toEqual({ status: 'ready', stale: false, count: 1, preview: ['second'], entries: [{ id: 'second' }] })
  })
})

it('submits all settings at one revision and leaves both drafts after a refused batch', async () => {
  const host = stubSettingsScope<ClinePassSettings>()
  host.publish({ status: 'ready', writable: true, revision: 7,
    value: { baseURL: 'https://old.test/v1', proxyURL: 'http://old.test:8080' },
    user: { baseURL: 'https://old.test/v1', proxyURL: 'http://old.test:8080' } })
  host.mutate.mockResolvedValue(false)
  const secret = vi.fn(async () => true)
  const form = new StagedForm(host.scope as never, [textField('baseURL'), textField('proxyURL')], [{ field: 'key', write: secret }])
  form.actions().edit('baseURL', 'https://new.test/v1')
  form.actions().edit('proxyURL', 'http://new.test:8080')
  form.actions().edit('key', 'draft-key')
  await form.save()
  expect(host.mutate).toHaveBeenCalledExactlyOnceWith([
    { op: 'set', path: ['baseURL'], value: 'https://new.test/v1' },
    { op: 'set', path: ['proxyURL'], value: 'http://new.test:8080' },
  ], 7)
  expect(host.set).not.toHaveBeenCalled()
  expect(secret).not.toHaveBeenCalled()
  expect(host.scope.getSnapshot().value).toEqual({ baseURL: 'https://old.test/v1', proxyURL: 'http://old.test:8080' })
  expect(form.field('baseURL').text).toBe('https://new.test/v1')
  expect(form.field('proxyURL').text).toBe('http://new.test:8080')
  expect(form.shell()).toMatchObject({ failed: true, dirty: true })
})

it('keeps only uncommitted drafts when a separate credential write fails', async () => {
  const host = stubSettingsScope<ClinePassSettings>()
  acceptWrites(host)
  host.publish({ status: 'ready', writable: true, value: {}, user: {} })
  const secret = vi.fn().mockResolvedValueOnce(false).mockResolvedValueOnce(true)
  const form = new StagedForm(host.scope as never, specs, [{ field: 'key', write: secret }])
  form.actions().edit('baseURL', 'https://new.test/v1')
  form.actions().edit('key', 'draft-key')
  await form.save()
  expect(form.shell()).toMatchObject({ failed: true, dirty: true })
  expect(form.field('key').text).toBe('draft-key')
  await form.save()
  expect(host.mutate).toHaveBeenCalledTimes(1)
  expect(secret).toHaveBeenCalledTimes(2)
  expect(form.shell()).toEqual(settled)
})

it('preserves a newer draft typed while the previous save is in flight', async () => {
  const host = stubSettingsScope<ClinePassSettings>()
  host.publish({ status: 'ready', writable: true, revision: 3, value: {}, user: {} })
  const release = Promise.withResolvers<void>()
  host.mutate.mockImplementation(async () => {
    await release.promise
    host.publish({ value: { baseURL: 'https://saved.test/v1' }, user: { baseURL: 'https://saved.test/v1' }, revision: 4 })
    return true
  })
  const form = new StagedForm(host.scope as never, specs)
  form.actions().edit('baseURL', 'https://saved.test/v1')
  const pending = form.save()
  form.actions().edit('baseURL', 'https://newer.test/v1')
  release.resolve()
  await pending
  expect(form.field('baseURL').text).toBe('https://newer.test/v1')
  expect(form.shell()).toMatchObject({ dirty: true, failed: false })
})
