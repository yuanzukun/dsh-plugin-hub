import { gzipSync } from 'node:zlib'
import { createServer, type RequestListener } from 'node:http'
import { once } from 'node:events'
import { setTimeout as delay } from 'node:timers/promises'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { diagnosticURL, fetchJsonResponse, readJsonResponse, transportFailure } from '../src/json-response.ts'

const cleanups: Array<() => Promise<unknown>> = []
afterEach(async () => { for (const cleanup of cleanups.splice(0).reverse()) await cleanup() })

async function localEndpoint(listener: RequestListener): Promise<string> {
  const server = createServer(listener)
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  cleanups.push(() => new Promise<void>((resolve, reject) => {
    server.closeAllConnections()
    server.close(error => error ? reject(error) : resolve())
  }))
  const address = server.address()
  if (!address || typeof address === 'string') throw new Error('missing server address')
  return `http://127.0.0.1:${address.port}/models`
}

describe('readJsonResponse', () => {
  it('accepts ordinary UTF-8 JSON, including a leading BOM', async () => {
    const document = { name: '模型', data: ['a', 'b'] }
    const body = Buffer.from(JSON.stringify(document))

    await expect(readJsonResponse(new Response(body), 1024)).resolves.toEqual(document)
    await expect(readJsonResponse(new Response(Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), body])), 1024))
      .resolves.toEqual(document)
  })

  it('allows the exact input byte limit and counts UTF-8 bytes', async () => {
    const document = { name: '模型' }
    const body = Buffer.from(JSON.stringify(document))

    await expect(readJsonResponse(new Response(body), body.byteLength)).resolves.toEqual(document)
    await expect(readJsonResponse(new Response(body), body.byteLength - 1))
      .rejects.toThrow(/exceeds.*byte limit/i)
  })

  it.each([
    { description: 'missing Content-Length', headers: undefined },
    { description: 'dishonest Content-Length', headers: { 'content-length': '1' } },
  ])('cancels an oversized stream early with $description', async ({ headers }) => {
    let reads = 0
    let cancelled = false
    const body = new ReadableStream<Uint8Array>({
      pull(controller) {
        reads += 1
        controller.enqueue(Buffer.from('0123456789'))
        if (reads === 3) controller.close()
      },
      cancel() { cancelled = true },
    }, { highWaterMark: 0 })

    const result = readJsonResponse(new Response(body, { headers }), 16)

    await expect(result).rejects.toBeInstanceOf(RangeError)
    await expect(result).rejects.toThrow(/exceeds.*byte limit/i)
    expect(cancelled).toBe(true)
    expect(reads).toBe(2)
  })

  it.each([
    { description: 'malformed JSON', body: Buffer.from('{"private-token": broken}') },
    { description: 'an HTML error page', body: Buffer.from('<html>upstream error</html>') },
    { description: 'unlabeled compressed bytes', body: gzipSync(Buffer.from('{"data":[]}')) },
  ])('reports $description without echoing the response body', async ({ body }) => {
    const error: unknown = await readJsonResponse(new Response(body), 1024).catch(error => error)
    expect(error).toBeInstanceOf(SyntaxError)
    expect((error as Error).message).toBe('Response is not valid JSON')
    expect((error as Error).cause).toBeInstanceOf(SyntaxError)
  })

  it('rejects an oversized body without waiting for stream cancellation', async () => {
    const cancelled = Promise.withResolvers<void>()
    const response = new Response(new ReadableStream({
      start(stream) { stream.enqueue(new TextEncoder().encode('{"ok":true}')) },
      cancel() { return cancelled.promise },
    }))
    const pending = readJsonResponse(response, 1).catch(error => error)
    try {
      expect(await Promise.race([pending, delay(200, 'still waiting')])).toBeInstanceOf(RangeError)
      expect(response.body!.locked).toBe(false)
    } finally { cancelled.resolve(); await pending }
  })
})

describe('fetchJsonResponse', () => {
  it('bounds a fetcher that ignores cancellation and cancels its late response', async () => {
    const headers = Promise.withResolvers<Response>()
    const started = Promise.withResolvers<void>()
    const cancel = vi.fn()
    const fetcher = vi.fn(() => { started.resolve(); return headers.promise })
    const controller = new AbortController()
    const reason = new DOMException('fixture deadline', 'TimeoutError')
    const pending = fetchJsonResponse('https://fixture.invalid/models', { signal: controller.signal }, 1024, 'identity', fetcher)
    const outcome = pending.catch(error => error)
    await started.promise
    controller.abort(reason)
    try {
      expect(await Promise.race([outcome, delay(200, 'still waiting')])).toBe(reason)
    } finally {
      let stream!: ReadableStreamDefaultController<Uint8Array>
      headers.resolve(new Response(new ReadableStream({
        start(controller) { stream = controller; controller.enqueue(new TextEncoder().encode('{"ok":true}')) }, cancel,
      })))
      await Promise.race([outcome, delay(50)])
      if (cancel.mock.calls.length === 0) stream.close()
      await outcome
    }
    await expect.poll(() => cancel.mock.calls.length).toBe(1)
    expect(fetcher).toHaveBeenCalledOnce()
  })

  it('bounds a stalled body even when stream cancellation never settles', async () => {
    const reading = Promise.withResolvers<void>()
    const cancelled = Promise.withResolvers<void>()
    let stream!: ReadableStreamDefaultController<Uint8Array>
    const cancel = vi.fn(() => cancelled.promise)
    const response = new Response(new ReadableStream<Uint8Array>({
      start(controller) { stream = controller; controller.enqueue(new TextEncoder().encode('{"ok":true}')) },
      pull() { reading.resolve() }, cancel,
    }, { highWaterMark: 0 }))
    const controller = new AbortController()
    const reason = new DOMException('fixture deadline', 'TimeoutError')
    const fetcher = vi.fn().mockResolvedValue(response)
    const pending = fetchJsonResponse('https://fixture.invalid/models', { signal: controller.signal }, 1024, 'identity', fetcher)
    const outcome = pending.catch(error => error)
    await reading.promise
    controller.abort(reason)
    try {
      expect(await Promise.race([outcome, delay(200, 'still waiting')])).toBe(reason)
      expect(cancel).toHaveBeenCalledOnce()
      expect(response.body!.locked).toBe(false)
      expect(fetcher).toHaveBeenCalledOnce()
    } finally {
      if (cancel.mock.calls.length === 0) stream.close()
      cancelled.resolve()
      await outcome
    }
  })

  it('does not wait for a failed HTTP response to finish cancellation', async () => {
    const cancelled = Promise.withResolvers<void>()
    const cancel = vi.fn(() => cancelled.promise)
    const response = new Response(new ReadableStream({ cancel }), { status: 503 })
    const fetcher = vi.fn().mockResolvedValue(response)
    const pending = fetchJsonResponse('https://fixture.invalid/models', {}, 1024, 'identity', fetcher)
    try {
      expect(await Promise.race([pending, delay(200, 'still waiting')])).toEqual({ response, body: undefined })
      expect(cancel).toHaveBeenCalledOnce()
      expect(fetcher).toHaveBeenCalledOnce()
    } finally { cancelled.resolve(); await pending }
  })

  it('bounds an error-body reader that ignores the request signal', async () => {
    const reading = Promise.withResolvers<void>()
    const body = Promise.withResolvers<unknown>()
    const response = new Response(new ReadableStream(), { status: 403 })
    const controller = new AbortController()
    const reason = new DOMException('fixture deadline', 'TimeoutError')
    const fetcher = vi.fn().mockResolvedValue(response)
    const pending = fetchJsonResponse('https://fixture.invalid/usage', { signal: controller.signal }, 1024, 'identity', fetcher,
      () => { reading.resolve(); return body.promise })
    const outcome = pending.catch(error => error)
    await reading.promise
    controller.abort(reason)
    try {
      expect(await Promise.race([outcome, delay(200, 'still waiting')])).toBe(reason)
      expect(fetcher).toHaveBeenCalledOnce()
    } finally { body.resolve(undefined); await outcome }
  })

  it('accepts gzip already decoded by Fetch without decompressing it twice', async () => {
    const document = { data: [{ id: 'compressed-model' }] }
    const endpoint = await localEndpoint((request, response) => {
      expect(request.headers['accept-encoding']).toBe('gzip')
      response.writeHead(200, { 'content-encoding': 'gzip', etag: '"compressed-version"' })
      response.end(gzipSync(Buffer.from(JSON.stringify(document))))
    })
    const result = await fetchJsonResponse(endpoint, { signal: AbortSignal.timeout(2000) }, 1024, 'gzip')
    expect(result.body).toEqual(document)
    expect(result.response.headers.get('etag')).toBe('"compressed-version"')
  })

  it.each([undefined, { 'content-encoding': 'gzip' }])('bounds recovered gzip output with headers %j', async (headers) => {
    const document = { data: 'x'.repeat(4096) }
    const plain = Buffer.from(JSON.stringify(document))
    const compressed = gzipSync(plain)
    expect(compressed.length).toBeLessThan(plain.length - 1)
    const fetch = vi.fn().mockImplementation(() => Promise.resolve(new Response(compressed, { headers })))
    vi.stubGlobal('fetch', fetch)
    expect((await fetchJsonResponse('https://fixture.invalid/metadata', {}, plain.length, 'gzip')).body).toEqual(document)
    await expect(fetchJsonResponse('https://fixture.invalid/metadata', {}, plain.length - 1, 'gzip'))
      .rejects.toBeInstanceOf(RangeError)
    expect(fetch).toHaveBeenCalledTimes(2)
  })

  it('bounds the raw gzip input before decompression', async () => {
    const compressed = gzipSync(Buffer.from('{"ok":true}'))
    const fetch = vi.fn().mockResolvedValue(new Response(compressed))
    vi.stubGlobal('fetch', fetch)
    await expect(fetchJsonResponse('https://fixture.invalid/metadata', {}, compressed.length - 1, 'gzip'))
      .rejects.toBeInstanceOf(RangeError)
    expect(fetch).toHaveBeenCalledOnce()
  })

  it.each([
    { description: 'truncated gzip', body: gzipSync(Buffer.from('{"private":"upstream text"}')).subarray(0, 12), message: 'Response is not valid gzip' },
    { description: 'gzip containing invalid JSON', body: gzipSync(Buffer.from('{"private":invalid}')), message: 'Response is not valid JSON' },
  ])('does not retry or expose $description', async ({ body, message }) => {
    const fetch = vi.fn().mockResolvedValue(new Response(body))
    vi.stubGlobal('fetch', fetch)
    await expect(fetchJsonResponse('https://fixture.invalid/metadata', {}, 1024, 'gzip'))
      .rejects.toMatchObject({ name: 'SyntaxError', message })
    expect(fetch).toHaveBeenCalledOnce()
  })

  it('cancels raw gzip recovery with the original request signal', async () => {
    const compressed = gzipSync(Buffer.from(JSON.stringify({ data: 'x'.repeat(8 * 1024 * 1024) })))
    const fetch = vi.fn().mockResolvedValue(new Response(compressed))
    vi.stubGlobal('fetch', fetch)
    const controller = new AbortController()
    const reason = new DOMException('fixture cancellation', 'AbortError')
    const pending = fetchJsonResponse('https://fixture.invalid/metadata', { signal: controller.signal }, 16 * 1024 * 1024, 'gzip')
    const result = expect(pending).rejects.toBe(reason)
    // gzip recovery is asynchronous, so a caller can cancel while it is decoding.
    setImmediate(() => controller.abort(reason))
    await result
    expect(fetch).toHaveBeenCalledOnce()
  })

  it('recovers a GET when the first connection closes before headers arrive', async () => {
    let requests = 0
    const endpoint = await localEndpoint((request, response) => {
      requests += 1
      expect(request.headers['accept-encoding']).toBe('identity')
      expect(request.headers.authorization).toBe('Bearer fixture-key')
      if (requests === 1) { response.destroy(); return }
      response.setHeader('content-type', 'application/json')
      response.setHeader('etag', '"fixture-version"')
      response.end('{"data":[{"id":"recovered"}]}')
    })
    const headers = new Headers({ authorization: 'Bearer fixture-key', 'accept-encoding': 'gzip' })
    const result = await fetchJsonResponse(endpoint, { method: 'GET', headers, signal: AbortSignal.timeout(2000) }, 1024)
    expect(result.body).toEqual({ data: [{ id: 'recovered' }] })
    expect(result.response.headers.get('etag')).toBe('"fixture-version"')
    expect(requests).toBe(2)
    expect(headers.get('accept-encoding')).toBe('gzip')
  })

  it('retries a connection lost during the response body, after headers have arrived', async () => {
    let requests = 0
    let receivedHeaders = 0
    const originalFetch = globalThis.fetch
    vi.stubGlobal('fetch', async (input: string | URL | Request, init?: RequestInit) => {
      const response = await originalFetch(input, init)
      receivedHeaders += 1
      return response
    })
    const endpoint = await localEndpoint((_request, response) => {
      requests += 1
      response.writeHead(200, { 'content-type': 'application/json' })
      if (requests === 1) {
        response.write('{"data":')
        setTimeout(() => response.destroy(), 20)
      } else response.end('{"data":[]}')
    })
    expect((await fetchJsonResponse(endpoint, { signal: AbortSignal.timeout(2000) }, 1024)).body).toEqual({ data: [] })
    expect(receivedHeaders).toBe(2)
    expect(requests).toBe(2)
  })

  it('stops after two attempts when the endpoint keeps disconnecting', async () => {
    let requests = 0
    const endpoint = await localEndpoint((_request, response) => { requests += 1; response.destroy() })
    await expect(fetchJsonResponse(endpoint, { signal: AbortSignal.timeout(2000) }, 1024)).rejects.toBeInstanceOf(Error)
    expect(requests).toBe(2)
  })

  it.each([304, 401, 503])('returns HTTP %i without retrying or parsing the error body', async (status) => {
    const cancel = vi.fn()
    const response = new Response(status === 304 ? null : new ReadableStream({
      start(controller) { controller.enqueue(new TextEncoder().encode('upstream private text')) },
      cancel,
    }), { status })
    const fetch = vi.fn().mockResolvedValue(response)
    vi.stubGlobal('fetch', fetch)
    expect(await fetchJsonResponse('https://fixture.invalid/models', {}, 1024)).toEqual({ response, body: undefined })
    expect(fetch).toHaveBeenCalledTimes(1)
    expect(cancel).toHaveBeenCalledTimes(status === 304 ? 0 : 1)
  })

  it.each(['throw', 'reject'])('keeps the HTTP status and cancels the body when an error reader fails by %s', async mode => {
    const cancel = vi.fn()
    const response = new Response(new ReadableStream({ cancel }), { status: 403 })
    const fetcher = vi.fn().mockResolvedValue(response)
    const failure = Object.assign(new Error('private diagnostic failure'), { code: 'ECONNRESET' })
    const readError = () => { if (mode === 'throw') throw failure; return Promise.reject(failure) }
    expect(await fetchJsonResponse('https://fixture.invalid/usage', {}, 1024, 'identity', fetcher, readError))
      .toEqual({ response, body: undefined })
    expect(fetcher).toHaveBeenCalledOnce()
    expect(cancel).toHaveBeenCalledOnce()
  })

  it.each([
    { body: '{"private":invalid}', maxBytes: 1024, error: SyntaxError },
    { body: '{"data":"oversized"}', maxBytes: 2, error: RangeError },
  ])('does not retry JSON parsing or response limits: $error.name', async ({ body, maxBytes, error }) => {
    const fetch = vi.fn().mockImplementation(() => Promise.resolve(new Response(body)))
    vi.stubGlobal('fetch', fetch)
    await expect(fetchJsonResponse('https://fixture.invalid/models', {}, maxBytes)).rejects.toBeInstanceOf(error)
    expect(fetch).toHaveBeenCalledTimes(1)
  })

  it.each(['ECONNRESET', 'EPIPE', 'UND_ERR_SOCKET', 'EAI_AGAIN'])('recovers the nested transient transport code %s', async (code) => {
    const cause = new Error('private upstream detail', { cause: Object.assign(new Error('private transport detail'), { code }) })
    const fetch = vi.fn().mockRejectedValueOnce(new TypeError('fetch failed', { cause })).mockResolvedValue(Response.json({ ok: true }))
    vi.stubGlobal('fetch', fetch)
    const signal = AbortSignal.timeout(2000)
    expect((await fetchJsonResponse('https://fixture.invalid/models', { signal }, 1024)).body).toEqual({ ok: true })
    expect(fetch).toHaveBeenCalledTimes(2)
    expect(fetch.mock.calls.every(([, options]) => options.signal === signal)).toBe(true)
  })

  it.each(['CERT_HAS_EXPIRED', 'DEPTH_ZERO_SELF_SIGNED_CERT', 'ENOTFOUND', 'ECONNREFUSED'])('does not retry %s', async (code) => {
    const error = new TypeError('fetch failed', { cause: Object.assign(new Error('private transport detail'), { code }) })
    const fetch = vi.fn().mockRejectedValue(error)
    vi.stubGlobal('fetch', fetch)
    await expect(fetchJsonResponse('https://fixture.invalid/models', {}, 1024)).rejects.toBe(error)
    expect(fetch).toHaveBeenCalledTimes(1)
  })

  it('does not follow more than five error objects in a cause chain', async () => {
    let error = Object.assign(new Error('socket closed'), { code: 'ECONNRESET' }) as Error
    for (let depth = 0; depth < 5; depth += 1) error = new Error('wrapped', { cause: error })
    const fetch = vi.fn().mockRejectedValue(error)
    vi.stubGlobal('fetch', fetch)
    await expect(fetchJsonResponse('https://fixture.invalid/models', {}, 1024)).rejects.toBe(error)
    expect(fetch).toHaveBeenCalledTimes(1)
  })

  it('cancels the backoff without starting a second request when the caller aborts', async () => {
    const controller = new AbortController()
    const fetch = vi.fn().mockRejectedValue(Object.assign(new Error('closed'), { code: 'ECONNRESET' }))
    vi.stubGlobal('fetch', fetch)
    const pending = fetchJsonResponse('https://fixture.invalid/models', { signal: controller.signal }, 1024)
    const result = expect(pending).rejects.toMatchObject({ name: 'AbortError' })
    await delay(20)
    controller.abort()
    await result
    await delay(170)
    expect(fetch).toHaveBeenCalledTimes(1)
  })

  it('uses the original deadline while reading the retried response body', async () => {
    let requests = 0
    const endpoint = await localEndpoint((_request, response) => {
      requests += 1
      if (requests === 1) { response.destroy(); return }
      response.writeHead(200, { 'content-type': 'application/json' })
      response.write('{"data":')
    })
    const signal = AbortSignal.timeout(500)
    const error: unknown = await fetchJsonResponse(endpoint, { signal }, 1024).catch(error => error)
    expect(signal.aborted).toBe(true)
    expect(error).toBe(signal.reason)
    expect(requests).toBe(2)
  })

  it('rejects methods other than GET before issuing any request', async () => {
    const fetch = vi.fn()
    vi.stubGlobal('fetch', fetch)
    await expect(fetchJsonResponse('https://fixture.invalid/models', { method: 'POST' }, 1024)).rejects.toThrow('must use GET')
    expect(fetch).not.toHaveBeenCalled()
  })
})

describe('safe transport diagnostics', () => {
  it('keeps nested error codes but never includes the original error message', () => {
    const error = new TypeError('private fetch detail', { cause: new Error('private wrapper', {
      cause: Object.assign(new Error('secret credential'), { code: 'ECONNRESET' }),
    }) })
    expect(transportFailure(error)).toBe('network error (ECONNRESET)')
    expect(transportFailure(new Error('secret credential'))).toBe('network request failed')
    expect(transportFailure(new DOMException('secret credential', 'TimeoutError'))).toBe('request timed out or was aborted')
  })

  it('strips credentials, query strings and fragments from diagnostic URLs', () => {
    expect(diagnosticURL('https://user:password@example.invalid/v1/models?key=secret#private'))
      .toBe('https://example.invalid/v1/models')
  })
})
