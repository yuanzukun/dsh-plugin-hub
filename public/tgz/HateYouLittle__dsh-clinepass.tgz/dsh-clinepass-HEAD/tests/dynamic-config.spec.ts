/**
 * Settings-backed configuration: the `llm-clinepass` section overrides the
 * cordis.yml entry field by field, a change reaches the next request without
 * a restart, and a refused write leaves the document untouched.
 */

import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import LlmRuntime from '@deepseek-ai/dsh-llm'
import Gateway from '@deepseek-ai/dsh-api-gateway'
import Registry from '@deepseek-ai/dsh-typert-registry'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import { LocalCredentialProvider } from '@deepseek-ai/dsh-credentials-local'
import FileSettingsProvider from '@deepseek-ai/dsh-settings-file'
import { apply } from '../src/index.ts'
import { closeMockGateways, CURATED_IDS, fullLiveListing, listingBody, mockGateway, textEvents } from './mock-gateway.ts'
import { configOf } from './config-of.ts'
import type { ClineModelCatalog } from '../src/models-contract.ts'
import { ACCOUNT_REF_PREFIX } from '../src/accounts.ts'
import { curatedModelIds } from '../src/clinepass-models.ts'

const NS = 'llm-clinepass'
const novelId = 'cline-pass/novel-model'

const cleanups: Array<() => Promise<void>> = []

afterEach(async () => {
  while (cleanups.length > 0) await cleanups.pop()!()
  await closeMockGateways()
  vi.unstubAllEnvs()
})

async function home(): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-clinepass-dynamic-'))
  cleanups.push(() => rm(dir, { recursive: true, force: true }))
  return dir
}

/** The managed credential document's current layout: a versioned refs map. */
function credentialsYaml(refs: Record<string, string>): string {
  const rows = Object.entries(refs).map(([ref, value]) => `  ${ref}: ${value}`).join('\n')
  return rows ? `version: 1\nrefs:\n${rows}\n` : 'version: 1\nrefs: {}\n'
}

interface BootOptions {
  settingsYaml: string
  credentials: Record<string, string>
  baseURL: string
}

/** The plugin as a mountable cordis definition: `apply`'s named exports do not ride the function value. */
function asPlugin(config?: unknown): { name: string; inject: string[]; apply: (ctx: Context) => void } {
  return {
    name: 'llm-clinepass-test',
    inject: ['llm'],
    apply: (ctx: Context) => {
      apply(ctx, config as never)
    },
  }
}

/** A whole composition: runtime, settings document, credential store, plugin. */
async function boot(options: BootOptions): Promise<Context> {
  const dir = await home()
  await writeFile(join(dir, 'settings.yaml'), options.settingsYaml)
  await writeFile(join(dir, '.credentials.yaml'), credentialsYaml(options.credentials), { mode: 0o600 })
  const ctx = new Context()
  await ctx.plugin(LlmRuntime)
  await ctx.plugin(FileSettingsProvider, { path: join(dir, 'settings.yaml'), watch: false })
  await ctx.plugin(LocalCredentialProvider, { path: join(dir, '.credentials.yaml'), watch: false })
  await ctx.plugin(asPlugin({ baseURL: options.baseURL }))
  return ctx
}

async function streamOnce(ctx: Context): Promise<void> {
  // Seam-backed registration settles asynchronously once the credential
  // provider answers; a request before that would race the route's arrival.
  await expect.poll(() => ctx.llm.listProviders(), { timeout: 10_000 })
    .toContainEqual({ id: 'dsh-clinepass', name: 'DSH ClinePass' })
  for await (const _chunk of ctx.llm.stream({
    provider: 'dsh-clinepass',
    model: 'cline-pass/deepseek-v4.1-flash',
    messages: [],
  })) { /* drain */ }
}

describe('settings-backed configuration', () => {
  it('executes account commands through the real RPC codec and durable stores', async () => {
    const ctx = await boot({ settingsYaml: JSON.stringify({ [NS]: { accounts: [] } }), credentials: {}, baseURL: 'https://gateway.test/v1' })
    cleanups.push(() => ctx.fiber.dispose())
    await ctx.plugin(Registry)
    await ctx.plugin(Gateway)
    const execute = (command: unknown) => ctx.typertGateway.invoke({ namespace: 'clinePassAccounts', method: 'execute', args: { command } })
    const id = 'a'.repeat(32), ref = ACCOUNT_REF_PREFIX + id.toUpperCase()
    const secondId = 'b'.repeat(32), secondRef = ACCOUNT_REF_PREFIX + secondId.toUpperCase()
    const value = () => ctx.settings.describe().find(row => row.ns === NS)!.value
    expect(await execute({ kind: 'add', id, name: 'Work', key: 'rpc-private-key' })).toBe('applied')
    expect(await execute({ kind: 'add', id, name: 'Work', key: 'rpc-private-key' })).toBe('applied')
    expect(await execute({ kind: 'add', id: secondId, name: 'Backup', key: 'rpc-second-key' })).toBe('applied')
    expect(await Promise.all([
      execute({ kind: 'rename', ref, name: 'Renamed' }), execute({ kind: 'rename', ref: secondRef, name: 'Secondary' }),
    ])).toEqual(['applied', 'applied'])
    expect(await execute({ kind: 'move', ref: secondRef, toIndex: 0 })).toBe('applied')
    expect(await execute({ kind: 'select', ref })).toBe('applied')
    expect(await execute({ kind: 'auto-switch', value: true })).toBe('applied')
    expect(value().accounts).toEqual([{ id, name: 'Renamed', apiKeyEnv: ref }, { id: secondId, name: 'Secondary', apiKeyEnv: secondRef }])
    expect(value().apiKeyEnv).toBe(ref)
    expect(value().accounts[0].apiKeyEnv).toBe(value().apiKeyEnv)
    expect(value().autoSwitch).toBe(true)
    expect(await execute({ kind: 'replace-key', ref, key: 'rpc-replacement-key' })).toBe('applied')
    expect((await ctx.credentials.resolve(credentialRef(ref)))?.value).toBe('rpc-replacement-key')
    expect(JSON.stringify(value())).not.toMatch(/rpc-.*key/)
    expect(await execute({ kind: 'remove', ref })).toBe('applied')
    expect(await ctx.credentials.resolve(credentialRef(ref))).toBeUndefined()
    expect(value().accounts).toHaveLength(1)
    expect(value().apiKeyEnv).toBe(secondRef)
    expect(value().accountOperations).toEqual([])
    await expect(execute({ kind: 'select', ref, extra: true })).rejects.toThrow()
  })

  it('restores an interrupted addition from real durable settings and credential stores', async () => {
    const account = { id: 'c'.repeat(32), name: 'Recovered', apiKeyEnv: ACCOUNT_REF_PREFIX + 'C'.repeat(32) }
    const ctx = await boot({ settingsYaml: JSON.stringify({ [NS]: { accounts: [], accountOperations: [
      { id: account.id, kind: 'add', account, select: true, previousRef: 'CLINE_API_KEY' },
    ] } }), credentials: { [account.apiKeyEnv]: 'recovery-fixture-secret' }, baseURL: 'https://gateway.test/v1' })
    cleanups.push(() => ctx.fiber.dispose())
    await expect.poll(() => ctx.settings.describe().find(row => row.ns === NS)?.value.accounts).toEqual([account])
    const value = ctx.settings.describe().find(row => row.ns === NS)!.value
    expect(value.accountOperations).toEqual([])
    expect(value.apiKeyEnv).toBe(account.apiKeyEnv)
    expect(JSON.stringify(value)).not.toContain('recovery-fixture-secret')
  })

  it('resumes an addition after a later credential event, without keeping its key in settings', async () => {
    const account = { id: 'd'.repeat(32), name: 'Recovered later', apiKeyEnv: ACCOUNT_REF_PREFIX + 'D'.repeat(32) }
    const ctx = await boot({ settingsYaml: JSON.stringify({ [NS]: { accounts: [], accountOperations: [
      { id: account.id, kind: 'add', account, select: true, previousRef: 'CLINE_API_KEY' },
    ] } }), credentials: {}, baseURL: 'https://gateway.test/v1' })
    cleanups.push(() => ctx.fiber.dispose())
    expect(ctx.settings.describe().find(row => row.ns === NS)!.value.accounts).toEqual([])
    await ctx.credentials.set(credentialRef(account.apiKeyEnv), 'recovery-fixture-secret')
    await expect.poll(() => ctx.settings.describe().find(row => row.ns === NS)?.value.accountOperations).toEqual([])
    expect(ctx.settings.describe().find(row => row.ns === NS)!.value.accounts).toEqual([account])
  })

  it('finishes a durable removal on restart using the managed credential provider', async () => {
    const account = { id: 'e'.repeat(32), name: 'Removed', apiKeyEnv: ACCOUNT_REF_PREFIX + 'E'.repeat(32) }
    const ctx = await boot({ settingsYaml: JSON.stringify({ [NS]: { accounts: [account], apiKeyEnv: account.apiKeyEnv,
      accountOperations: [{ id: 'f'.repeat(32), kind: 'remove', account }],
    } }), credentials: { [account.apiKeyEnv]: 'remove-fixture-secret' }, baseURL: 'https://gateway.test/v1' })
    cleanups.push(() => ctx.fiber.dispose())
    await expect.poll(() => ctx.settings.describe().find(row => row.ns === NS)?.value.accountOperations).toEqual([])
    expect(ctx.settings.describe().find(row => row.ns === NS)!.value.accounts).toEqual([])
    expect(await ctx.credentials.resolve(credentialRef(account.apiKeyEnv))).toBeUndefined()
  })
  it('persists valid proxies, rejects invalid addresses and supports explicit clearing', async () => {
    const ctx = await boot({ settingsYaml: '', credentials: {}, baseURL: 'https://api.cline.bot/api/v1' })
    const value = () => ctx.settings.describe().find(row => row.ns === NS)?.value.proxyURL
    expect(value()).toBe('')
    for (const proxyURL of ['http://localhost:7890', 'socks5://localhost:1080', '']) {
      await ctx.settings.update(NS, { proxyURL })
      expect(value()).toBe(proxyURL)
    }
    await expect(ctx.settings.update(NS, { proxyURL: 'socks4://localhost:1080' })).rejects.toThrow()
    expect(value()).toBe('')
  })
  it('defaults usage display to auto and persists valid display modes while refusing invalid ones', async () => {
    const ctx = await boot({ settingsYaml: '', credentials: {}, baseURL: 'https://gateway.test/v1' })
    const value = () => ctx.settings.describe().find(row => row.ns === NS)?.value.usageDisplay
    expect(value()).toBe('auto')
    for (const usageDisplay of ['always', 'off', 'auto']) {
      await ctx.settings.update(NS, { usageDisplay })
      expect(value()).toBe(usageDisplay)
    }
    await expect(ctx.settings.update(NS, { usageDisplay: 'invalid' })).rejects.toThrow()
    expect(value()).toBe('auto')
  })

  it('serves the cordis entry until the settings section supplies overrides', async () => {
    vi.stubEnv('CLINE_API_KEY', 'env-key')
    const gateway = await mockGateway({ status: 200, body: listingBody(fullLiveListing()) })
    gateway.pushCompletions({ events: textEvents })
    const ctx = await boot({ settingsYaml: '', credentials: {}, baseURL: gateway.url })

    await streamOnce(ctx)

    expect(gateway.paths).toEqual(['/models', '/chat/completions'])
    expect(gateway.headers[1]?.authorization).toBe('Bearer env-key')
  })

  it('reaches the next request with a new endpoint and key without a restart', async () => {
    vi.stubEnv('CLINE_API_KEY', 'env-key')
    const first = await mockGateway({ status: 200, body: listingBody(fullLiveListing()) })
    const second = await mockGateway({ status: 200, body: listingBody(fullLiveListing()) })
    first.pushCompletions({ events: textEvents })
    second.pushCompletions({ events: textEvents })
    const dir = await home()
    const settingsPath = join(dir, 'settings.yaml')
    await writeFile(settingsPath, '')
    await writeFile(join(dir, '.credentials.yaml'), credentialsYaml({ CUSTOM_CLINE_REF: 'stored-key' }), { mode: 0o600 })
    const ctx = new Context()
    await ctx.plugin(LlmRuntime)
    await ctx.plugin(FileSettingsProvider, { path: settingsPath, watch: false })
    await ctx.plugin(LocalCredentialProvider, { path: join(dir, '.credentials.yaml'), watch: false })
    await ctx.plugin(asPlugin({ baseURL: first.url }))

    await streamOnce(ctx)
    expect(first.paths).toHaveLength(2)
    expect(first.headers[1]?.authorization).toBe('Bearer env-key')

    await ctx.settings.update(NS, { baseURL: second.url, apiKeyEnv: 'CUSTOM_CLINE_REF' })

    await streamOnce(ctx)

    expect(second.paths).toEqual(['/models', '/chat/completions'])
    expect(second.headers[1]?.authorization).toBe('Bearer stored-key')
  })

  it('rebuilds the catalog when the refresh interval changes', async () => {
    const gateway = await mockGateway({ status: 200, body: listingBody(fullLiveListing()) })
    gateway.pushCompletions({ events: textEvents })
    gateway.pushCompletions({ events: textEvents })
    const ctx = await boot({
      settingsYaml: '',
      credentials: { CLINE_API_KEY: 'test-key' },
      baseURL: gateway.url,
    })

    await streamOnce(ctx)
    await ctx.settings.update(NS, { refreshMinutes: 30 })
    await streamOnce(ctx)

    // Two catalog fetches on two different catalog generations (the change
    // rebuilt the resolver), never a stale snapshot served twice.
    expect(gateway.paths.filter(path => path === '/models')).toHaveLength(2)
    expect(gateway.paths.filter(path => path === '/chat/completions')).toHaveLength(2)
  })

  it('applies and removes per-model capacities without a restart', async () => {
    const gateway = await mockGateway({ status: 200, body: listingBody(fullLiveListing()) })
    const ctx = await boot({
      settingsYaml: '',
      credentials: { CLINE_API_KEY: 'test-key' },
      baseURL: gateway.url,
    })
    await expect.poll(() => ctx.llm.listProviders(), { timeout: 10_000 })
      .toContainEqual({ id: 'dsh-clinepass', name: 'DSH ClinePass' })

    const advertised = (await ctx.llm.resolveModelInfo('dsh-clinepass', 'cline-pass/deepseek-v4.1-flash')).context?.contextWindow
    expect(advertised).toBeGreaterThan(0)

    await ctx.settings.update(NS, {
      modelLimits: { 'cline-pass/deepseek-v4.1-flash': { contextWindow: 123_456, maxTokens: 5_432 } },
    })
    expect((await ctx.llm.resolveModelInfo('dsh-clinepass', 'cline-pass/deepseek-v4.1-flash')).context?.contextWindow)
      .toBe(123_456)

    // `update` is merge-only, so use the documented replace path to remove the
    // user-layer field and let the catalog value re-inherit.
    await ctx.settings.replace(NS, {})
    expect((await ctx.llm.resolveModelInfo('dsh-clinepass', 'cline-pass/deepseek-v4.1-flash')).context?.contextWindow)
      .toBe(advertised)
  })

  it('drops the route when the credential goes away, and revives it on return', async () => {
    const gateway = await mockGateway({ status: 200, body: listingBody(fullLiveListing()) })
    gateway.pushCompletions({ events: textEvents })
    const ctx = await boot({
      settingsYaml: '',
      credentials: { CLINE_API_KEY: 'test-key' },
      baseURL: gateway.url,
    })
    await streamOnce(ctx)
    expect(gateway.paths.filter(path => path === '/chat/completions')).toHaveLength(1)

    // An event naming another reference leaves the route alone; removing the
    // key emits the reference event and the route drops, with no request
    // reaching the gateway while it is gone.
    await ctx.credentials.set(credentialRef('UNRELATED_REF'), 'other')
    await ctx.credentials.unset(credentialRef('CLINE_API_KEY'))
    await expect.poll(() => ctx.llm.listProviders(), { timeout: 10_000 }).toEqual([])
    expect(gateway.paths.filter(path => path === '/chat/completions')).toHaveLength(1)

    // Storing it again brings the route back without a restart.
    await ctx.credentials.set(credentialRef('CLINE_API_KEY'), 'test-key')
    await expect.poll(() => ctx.llm.listProviders(), { timeout: 10_000 })
      .toContainEqual({ id: 'dsh-clinepass', name: 'DSH ClinePass' })
    await streamOnce(ctx)
    expect(gateway.paths.filter(path => path === '/chat/completions')).toHaveLength(2)
  })

  it('keeps the route unregistered when the credential describe fails', async () => {
    const ctx = new Context()
    await ctx.plugin(LlmRuntime)
    ctx.provide('credentials', {
      describe: () => Promise.reject(new Error('describe exploded')),
      resolve: () => Promise.resolve({ value: 'k', source: 'test' }),
    } as never)
    apply(ctx, configOf('https://api.cline.bot/api/v1'))

    // The refusal is logged and the route simply stays unregistered.
    await new Promise(resolve => setTimeout(resolve, 50))
    expect(ctx.llm.listProviders()).toEqual([])
  })

  it('fails the in-flight request loudly when the key vanishes underneath the route', async () => {
    const gateway = await mockGateway({ status: 200, body: listingBody(fullLiveListing()) })
    gateway.pushCompletions({ events: textEvents })
    const ctx = new Context()
    await ctx.plugin(LlmRuntime)
    // Describe still sees a configured reference (the route stays registered),
    // but resolution finds nothing — the race a removed shadowing source leaves.
    ctx.provide('credentials', {
      describe: () => Promise.resolve({ configured: true, writable: true }),
      resolve: () => Promise.resolve(undefined),
    } as never)
    apply(ctx, configOf(gateway.url))
    await expect.poll(() => ctx.llm.listProviders(), { timeout: 10_000 })
      .toContainEqual({ id: 'dsh-clinepass', name: 'DSH ClinePass' })

    const chunks: Array<{ type: string; reason?: unknown }> = []
    for await (const chunk of ctx.llm.stream({
      provider: 'dsh-clinepass',
      model: 'cline-pass/deepseek-v4.1-flash',
      messages: [],
    })) chunks.push(chunk)

    expect(chunks.find(chunk => chunk.type === 'finish')).toMatchObject({
      reason: { kind: 'error', failure: { code: 'MISSING_CREDENTIAL' } },
    })
    // The catalog fetch precedes credential resolution; no request goes out.
    expect(gateway.paths).toEqual(['/models'])
  })

  it('updates legacy session pickers when a model is individually switched off and on', async () => {
    const gateway = await mockGateway({ status: 200, body: listingBody([CURATED_IDS.flash, CURATED_IDS.kimi]) })
    const ctx = await boot({ settingsYaml: '', credentials: { CLINE_API_KEY: 'test-key' }, baseURL: gateway.url })
    await expect.poll(() => ctx.llm.listProviders()).toContainEqual({ id: 'dsh-clinepass', name: 'DSH ClinePass' })
    const notify = vi.fn()
    ctx.on('llm/adapters-updated', notify)
    await ctx.settings.update(NS, { modelVisibility: { [CURATED_IDS.flash]: false } })
    expect(notify).toHaveBeenCalled()
    expect((await ctx.llm.listModels('dsh-clinepass')).map(m => m.id)).not.toContain(CURATED_IDS.flash)
    await ctx.settings.update(NS, { modelVisibility: { [CURATED_IDS.flash]: true } })
    expect((await ctx.llm.listModels('dsh-clinepass')).map(m => m.id)).toContain(CURATED_IDS.flash)
    expect(gateway.modelListings).toBe(1)
  })

  it('refreshes Settings and open pickers from one catalog snapshot, including failed refreshes', async () => {
    const gateway = await mockGateway({ status: 200, body: listingBody([CURATED_IDS.flash]) })
    const ctx = await boot({ settingsYaml: '', credentials: { CLINE_API_KEY: 'test-key' }, baseURL: gateway.url })
    cleanups.push(() => ctx.fiber.dispose())
    await ctx.plugin(Registry)
    await ctx.plugin(Gateway)
    await expect.poll(() => ctx.llm.listProviders()).toContainEqual({ id: 'dsh-clinepass', name: 'DSH ClinePass' })
    const pickerReads: Array<Promise<readonly { id: string }[]>> = []
    const notify = vi.fn(() => {
      if (ctx.llm.listProviders().some(provider => provider.id === 'dsh-clinepass')) {
        pickerReads.push(ctx.llm.listModels('dsh-clinepass'))
      }
    })
    ctx.on('llm/adapters-updated', notify)
    const read = async () => await ctx.typertGateway.invoke({
      namespace: 'clinePassModels', method: 'read', args: {},
    }) as ClineModelCatalog
    expect((await read()).models.map(model => model.id)).toEqual(curatedModelIds())
    expect((await Promise.all(pickerReads)).map(models => models.map(model => model.id))).toEqual([curatedModelIds()])
    expect(gateway.modelListings).toBe(1)

    // A refresh changes the advertisement diagnostic, never membership.
    gateway.setModelListing(200, listingBody([CURATED_IDS.flash, novelId]))
    const advertised = await read()
    expect(advertised.models.map(model => model.id)).toEqual([...curatedModelIds(), novelId])
    expect(advertised.models.find(model => model.id === novelId)?.configurationMissing).toBe(true)
    expect((await pickerReads.at(-1))?.map(model => model.id)).toEqual(curatedModelIds())
    expect(gateway.modelListings).toBe(2)

    gateway.setModelListing(503, {})
    const stale = await read()
    expect(stale.stale).toBe(true)
    expect(stale.models.map(model => model.id)).toEqual(curatedModelIds())
    expect(stale.error).toContain('HTTP 503')
    expect((await pickerReads.at(-1))?.map(model => model.id)).toEqual(curatedModelIds())
    expect(gateway.modelListings).toBe(3)

    await ctx.settings.update(NS, { modelVisibility: { [CURATED_IDS.flash]: false } })
    expect(await pickerReads.at(-1)).not.toContainEqual(expect.objectContaining({ id: CURATED_IDS.flash }))
    expect(gateway.modelListings).toBe(3)

    await ctx.settings.update(NS, { enabled: false })
    const notifications = notify.mock.calls.length
    await read()
    expect(notify).toHaveBeenCalledTimes(notifications)
  })

  it('persists individual model switches and notifies open legacy pickers without altering other models', async () => {
    const gateway = await mockGateway({ status: 200, body: listingBody(fullLiveListing()) })
    const ctx = await boot({ settingsYaml: '', credentials: { CLINE_API_KEY: 'test-key' }, baseURL: gateway.url })
    await expect.poll(() => ctx.llm.listProviders()).toContainEqual({ id: 'dsh-clinepass', name: 'DSH ClinePass' })
    const notify = vi.fn()
    ctx.on('llm/adapters-updated', notify)
    await ctx.settings.update(NS, { modelVisibility: { 'cline-pass/deepseek-v4.1-flash': false } })
    expect(notify).toHaveBeenCalled()
    const otherModels = (await ctx.llm.listModels('dsh-clinepass')).map(m => m.id)
    expect(otherModels).not.toContain('cline-pass/deepseek-v4.1-flash')
    expect(otherModels.length).toBeGreaterThan(0)
    expect(ctx.settings.describe().find(row => row.ns === NS)?.value.modelVisibility).toEqual({ 'cline-pass/deepseek-v4.1-flash': false })
    notify.mockClear()
    await ctx.settings.update(NS, { modelVisibility: { 'cline-pass/deepseek-v4.1-flash': true } })
    expect(notify).toHaveBeenCalled()
    const restoredModels = (await ctx.llm.listModels('dsh-clinepass')).map(m => m.id)
    expect(restoredModels).toContain('cline-pass/deepseek-v4.1-flash')
    expect(restoredModels.filter(id => id !== 'cline-pass/deepseek-v4.1-flash')).toEqual(otherModels)
  })

  it('withdraws the route and its models the moment the switch goes off, and serves again on', async () => {
    const gateway = await mockGateway({ status: 200, body: listingBody(fullLiveListing()) })
    gateway.pushCompletions({ events: textEvents })
    gateway.pushCompletions({ events: textEvents })
    const ctx = await boot({
      settingsYaml: '',
      credentials: { CLINE_API_KEY: 'test-key' },
      baseURL: gateway.url,
    })
    await streamOnce(ctx)
    expect((await ctx.llm.listModels('dsh-clinepass')).map(model => model.id)).toContain('cline-pass/deepseek-v4.1-flash')

    // The key stays configured throughout: only the switch decides.
    await ctx.settings.update(NS, { enabled: false })

    // Gone from the picker's source, not merely filtered at request time, and
    // nothing further reaches the gateway while it is off.
    await expect.poll(() => ctx.llm.listProviders(), { timeout: 10_000 }).toEqual([])
    // The route itself is gone, so even a direct catalog read cannot find it.
    await expect(ctx.llm.listModels('dsh-clinepass')).rejects.toThrow()
    expect(gateway.paths.filter(path => path === '/chat/completions')).toHaveLength(1)

    // The page that owns the switch keeps working while the route is gone.
    expect(ctx.settings.describe().find(view => view.ns === NS)?.value)
      .toMatchObject({ enabled: false })

    await ctx.settings.update(NS, { enabled: true })
    await expect.poll(() => ctx.llm.listProviders(), { timeout: 10_000 })
      .toContainEqual({ id: 'dsh-clinepass', name: 'DSH ClinePass' })
    await streamOnce(ctx)
    expect(gateway.paths.filter(path => path === '/chat/completions')).toHaveLength(2)
  })

  it('refuses a write whose baseURL is not usable, leaving the document untouched', async () => {
    const gateway = await mockGateway({ status: 200, body: listingBody(fullLiveListing()) })
    gateway.pushCompletions({ events: textEvents })
    const dir = await home()
    const settingsPath = join(dir, 'settings.yaml')
    await writeFile(settingsPath, '')
    await writeFile(join(dir, '.credentials.yaml'), credentialsYaml({ CLINE_API_KEY: 'test-key' }), { mode: 0o600 })
    const ctx = new Context()
    await ctx.plugin(LlmRuntime)
    await ctx.plugin(FileSettingsProvider, { path: settingsPath, watch: false })
    await ctx.plugin(LocalCredentialProvider, { path: join(dir, '.credentials.yaml'), watch: false })
    await ctx.plugin(asPlugin({ baseURL: gateway.url }))

    await expect(ctx.settings.update(NS, { baseURL: 'not-a-url' })).rejects.toThrow(/not a valid URL/)

    expect(await readFile(settingsPath, 'utf8')).toBe('')
    await streamOnce(ctx)
    expect(gateway.paths).toEqual(['/models', '/chat/completions'])
  })
})
