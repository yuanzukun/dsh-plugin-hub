# dsh-dream 使用说明

[返回简介](../README.md) · [更新记录](../CHANGELOG.md) · [验证记录](VALIDATION.md)

## 安装

```bash
dsh plugin --profile web add @stardustlc/dsh-dream
# 或从源码：
dsh plugin --profile web add github:STARDUSTLC666/dsh-dream
```

安装后重启 Web 服务即可。本插件收录于 [dsh-suite](https://github.com/STARDUSTLC666/dsh-suite) 全家桶——一条命令可装入 STARDUSTLC 全部 18 个插件。

## 卸载

```bash
dsh plugin --profile web remove @stardustlc/dsh-dream
```

卸载后重启 Web 服务。梦境日记默认保存在 `~/.dsh/.dsh-dream/dreams.jsonl`，卸载不会删除；如需彻底清理请手动删除该目录。

## 自动整理与回用（0.8.0+）

安装后正常完成任务即可，不需要记住「做梦」触发词。仅观察新产生的真人主会话事件：完成轮次出现明确偏好/纠正，或至少两次非 Dream 工具调用且有可见助手总结时，才会在预算内调用当前会话模型整理。它不扫描旧会话、子代理或失败轮次。

「设置 → 梦境日记 → 日记」提供自动整理、自动取回的默认开关、今日次数、最近原因和待审阅入口。展开「聊天设置与整理预算」，可针对已观察到的聊天分别控制「使用记忆」与「贡献记忆」；独立设置优先于全局默认。关闭贡献清理该聊天尚未整理的片段，已有经验仍保留。控制值保存在 `journalDir/automatic/state.json`，重启后继续保留。

0.9.0 起默认等待 60 秒安静时间，同项目、提供商和模型最多合并 4 轮进行一次整理。冷却和当日预算用完时保留轮次等待恢复，队列最多 32 轮、24 小时；容量不足先移除最早未被处理的轮次，过期片段清理并显示计数。新输入暂停辅助调用并保留未完成轮次。可以点「现在整理待处理轮次」跳过安静时间，但不能绕过主任务优先、冷却或每日预算。重启后会等待新的安静时间再继续，不扫描旧会话历史。

「经验」页按项目与主题筛选待核实记录。展开来源核对脱敏原话、适用条件及例外，再勾选无冲突候选进行批量采纳/驳回，最多 20 条；必须同项目、范围和主题，任一版本已变化会整体拒绝写入。冲突和待复核经验请逐条处理。

事实默认在最近审阅/核验 30 天后暂停回用；明确的 `reviewAfter` 也可指定期限。稳定偏好没有默认期限。到期显示「已到复核时间」，不会注入或用于规则预览；核对当前事实后重新采纳才续期。「最近取回」只记录提供参考的时间，使用反馈和反复检索都不延长有效期。

默认每天最多 4 次辅助调用、间隔 10 分钟、输入总长最多 12000 字符、输出最多 1200 token、30 秒超时，每次最多 3 条候选。输入仅包含脱敏后的有限可见消息；不包含隐藏推理、系统提示或工具参数/结果。该请求使用 DSH 当前模型和额度，可能产生费用；新输入、关闭整理或卸载会取消进行中的请求。尝试前扣预算，失败不返还，也不自动重试；宿主 adapter 的重试策略保持原样。

自动取回不额外调用模型，只把有独立来源、已采纳且与当前任务/项目/平台匹配的少量经验加入动态上下文，最多 3 条、3000 字符，保留适用条件和例外。候选、过期、冲突、拒绝经验不注入。依赖版本未知，因此版本限定经验留给显式 `dream_context`，请提供已确认的包名和版本。自动功能不写日记、不采纳经验，也不修改 AGENTS.md。

官方 0.2.0-rc.2 与 0.2.1-alpha.1 的会话事件、Agent Inbox 和 PromptContext 接口已验证。接口缺失的旧宿主显示不可用，工具与技能照常可用。

## 梦境日记面板（0.4.0+）

装好后，DSH 的「设置 → 梦境日记」提供日记、经验与写入记录。0.7.0 起可以直接审阅和反馈；写操作使用 DSH 0.2.0-rc.2 的认证 Connection 通道。headless 宿主没有设置页，工具与技能照常可用。

- **看什么**：顶部是梦境总数、心境方块序列（单条时不空，多条时自动换行）与教训榜；下面是卡片式时间线，按时间倒序，逐条显示时间、心境、反思正文与教训列表。反思正文默认展开，超过 4 行或 220 字时折叠为 4 行并给出「展开全文」。
- **教训榜**：按日记出现次数与最近时间排序，≥3 次标为“常见教训”；频率不代表正确性、重要度或桥接资格。技术经验必须另行提交来源、审阅，再预览写入规则。
- **搜索**：按关键词过滤，命中反思与教训，不区分大小写。心境分布与教训榜基于**全量日记**，时间线按搜索与条数上限（默认最近 50 场）展示。
- **筛选与更早的梦**：≥8 场时出现「筛选 ▾」（按心境、只看有教训的梦，作用于已加载窗口并在弹层注明）；加载满 50 场且总梦数更多时，页脚提供「显示更早的梦」，点击后一次拉满到 500 场（路由上限）。
- **日记读取**：GET /_dsh/dsh-dream/journal 仅回环地址可达；非 GET → 405，非本机 Host → 403。记梦、翻梦、忆梦仍通过 dream_save / dream_journal / dream_recall 完成。面板审阅只更新经验事件，预览本身不写文件。
- **数据文件**：面板读的就是梦境日记本身，默认 ~/.dsh/.dsh-dream/dreams.jsonl（$DSH_HOME/.dsh-dream/dreams.jsonl；配置了 journalDir 时以配置为准）。存储格式不变，仍是每行一条 JSON 的 JSONL，可直接删除或用 dream_journal 读取。
- **隐私**：只读路由会再次脱敏正文；已校验的内部经验、证据与备份编号保留以供操作。界面只访问本机同源路由，不上传第三方服务。“隐私模式”仅模糊显示，DOM 仍有文本；日志本身是明文。
- **还没有梦时**：自动候选在「经验」页待审阅；日记仍可让助手单独复盘生成。只有一场梦时按单条卡片展示，心境方块与教训榜都不留空、不画失真图表。
- **经验视图**：可用经验与待核实队列分开，已驳回历史按需查看。来源记录可展开查看核验信息；采纳、驳回、重新送审和标记待复核可以直接点击。处理冲突须选择对方经验和填写依据。每次操作检查版本，冲突时保留输入并提供刷新；对话命令入口仍可使用。
- **使用反馈**：展开“使用反馈”记录这次有用或不适用，并可填写场景。反馈不会自动改变审阅状态、证据或最后核验时间；最近 20 条明细可恢复，事件流保留历史。
- **规则变更与回滚**：带项目目录的可用经验提供“预览规则变更”，展示实际目标与新增/删除差异后才可应用。此预览按所选经验重建 Dream 管理块，保留块外内容；经验版本或文件哈希变化时拒绝应用。没有项目目录的经验须在对应项目对话中使用预览命令。写入记录展示备份与“回滚这次变更”；当前管理块仍匹配该次 apply 时才允许回滚。

## 工具一览

| 工具 | 作用 | 关键参数 |
| :-- | :-- | :-- |
| `dream_digest` | 入梦：回放最近会话（标题/轮数/用户原话/助手结论/工具足迹），自动跳过子代理，还原官方打包行流式文本 | `maxSessions` 可选；`mode`: full/brief |
| `dream_save` | 记梦：反思 + 1-5 条教训 + 心境，永久保存 | `reflection` 必填；`lessons`/`mood` 可选 |
| `dream_journal` | 翻梦：倒序列出历史梦境 | `limit` 可选 |
| `dream_recall` | 忆梦：关键词检索梦境 | `query` 必填 |
| `dream_bridge` | 渡梦：把已采纳、范围匹配的经验写入 AGENTS.md（`preview` 预览 / `apply` 应用 / `rollback` 回滚；省略模式只读预览） | `mode` 可选；`path` / `lessonIds` / `maxLessons` / `expectedSha256` / `previewId` / `projectId` |
| `dream_health` | 自检：会话目录/梦境计数/配置汇总 | 无 |
| `dream_learn` | 提交候选技术经验及证据（校验 / 脱敏 / 去重 / 按范围保存；无证据只能留在候选） | `kind`、`title`、`action`、`when` 必填；`evidence` 可选（缺省 `[]`） |
| `dream_context` | 任务前取回少量适用经验（只读；候选默认不注入） | `query` 必填；`projectId` / `workspaceRoot` / `limit` / `maxChars` / `packageName` / `packageVersion` / `platform` / `includeCandidates` 可选 |
| `dream_review` | 审阅与状态流转：建议人工采纳 / 驳回 / 标记过期 / 标记冲突 / 处理冲突 / 补充证据 / 重新送审 | `action`、`lessonId`、`expectedRevision` 必填 |

处理冲突时必须填写 resolution（prefer / drop / merge）、affectedIds 与 note；所有当事方一并校验并在同一事件中保存，校验失败不改任何经验。attach-evidence 核验并附加来源，reopen 把驳回经验重新置为候选。

### 示例

```text
dream_digest { maxSessions: 5, mode: 'brief' }
dream_save { reflection: "用户反复遇到输入法问题，偏好先自查再重启", lessons: ["先问是否重启过应用"], mood: "平静" }
dream_recall { query: "输入法" }
dream_bridge { mode: "preview", path: "AGENTS.md", maxLessons: 10 }
dream_context { query: "SMTP 取消投递", projectId: "mailer", packageName: "nodemailer", packageVersion: "9.0.5", platform: "windows" }
dream_learn { kind: "pitfall", title: "池化发送中 close() 不保证终止投递", action: "取消后验证当前连接确实关闭", when: "使用 Nodemailer 9.0.5 池化发送并处理 AbortSignal 时", evidence: [{ kind: "local-artifact", artifactPath: "test-results/smtp.txt", summary: "本机 SMTP 复现：取消后服务器仍收到正文", verification: "read" }] }
// 仅建议审阅；实际采纳请在「设置 → 梦境日记 → 经验」中确认。
dream_review { action: "accept", lessonId: "lesson-…", expectedRevision: 1 }
```

## 项目规则预览、写入与回滚

`dream_bridge` 现在有显式三模式：

- `preview`（只读）：返回真实 diff、参与经验与 skipped 原因，零写入；
- `apply`：必须带预览的 `expectedSha256`（新文件为 null），建议同时带 `previewId`，文件被并发修改时返回 `conflict` 且零写入；只替换 Dream 管理块（`<!-- dsh-dream:start/end -->`），保留块外文字、BOM 与换行风格，先持久化 pending 恢复记录再原子替换文件，最后记录 applied；
- `rollback`：用 backupId 定位记录，只在当前管理块仍等于该次 apply 结果时回滚，保留块外后来追加的人工内容。

0.11.0 起省略 `mode` 等同于 `preview`，不再从旧日记直接写入规则。只有 `usable`、`review.decision=accepted`、`review.actor=human`，且范围匹配当前项目或人工确认的全局经验可桥接。频次不作为准入条件；写入内容统一过 `mask.ts`。面板「写入记录」提供确认回滚。

模型调用 `dream_review accept` 或 `resolve-conflict` 仅返回 `requiresHumanReview: true`，不写入经验或增加版本。请在面板核对来源后确认；全局经验还需勾选「用于所有项目」。单条、批量及冲突处理均检查这个确认。旧的模型采纳、未知审阅者记录会显示为待人工审阅，并暂停自动上下文、默认检索、摘要和规则桥接。工具结果中的文字只计为出现过，不计独立支持。

## 做梦协议（随包技能）

插件附带 `dream-protocol` 技能，教 agent 何时做梦（开场/收尾/距上次做梦超一天）、做梦三步（入梦→解梦→记梦）与记梦纪律（只沉淀规律不复述流水账、密钥隐私不入梦、存疑要标注）。

## 经验记忆

梦境日记是主观感悟；真正要复用的技术经验走 `<journalDir>/knowledge/`：

- **候选 → 来源核验 → 审阅**：dream_learn 创建 candidate。会话来源需要 sessionId、recordSeq 与可匹配的 quote（省略时用 summary 匹配）；插件核对项目、角色、记录和文本并计算 sourceHash。user-correction 必须来自真实用户消息；local-artifact 需要 artifactPath，真实路径必须位于调用工作目录内。核验失败记 claimed 与 verificationReason，不计独立支持数。读到来源不等于用户采纳，工具审阅记录 actor:model。补充证据不会自动改变状态；所有审阅携带 expectedRevision，旧版本会拒绝。
- **取回有预算**：`dream_context` 默认最多返回 5 条、3000 字符（硬上限 20 条 / 20000 字符）；按排名整条装入，遇到第一条放不下就停止（`skipped: budget-stop`），`title / when / action / exceptions` 永不截断，绝不返回半条。候选与无独立证据的非 usable 条目默认不注入（`includeCandidates: false`，记 `candidate-hold` / `no-evidence`）；显式 `includeCandidates: true` 可在审阅候选时看到，且候选排在可用经验之后——未经审阅不得当作已证实结论。已驳回、已过期和冲突未解决的不注入；platform 可显式指定，未指定时从明确任务文字识别，否则采用宿主平台，平台不符记 platform-mismatch；`applicability.versions` 只在包名被识别（显式 `packageName` 或 query 中出现包名）时参与判定。
- **频率不是可靠性**：同一条证据重复提交是幂等的；不要在同一个会话里反复 `dream_save` / `dream_learn` 刷次数。同一个会话中重复出现的教训只算一次独立来源。
- **存储可恢复**：`events.jsonl` 是权威事件日志（追加写），`evidence.jsonl` 追加证据，`index.json` 是可丢弃重建的派生索引；重建索引不删除任何原文件。目录不存在时读取接口返回空结果，不会为了读而创建目录。
- **删除新数据**：直接删除 `<journalDir>/knowledge/` 即清空经验记忆；这不会影响 `dreams.jsonl` 里的旧日记，旧版本插件也仍能读取旧日记。

## 配置

在你自己的 profile 的 `cordis.patch.yml` 里覆盖本插件行（缺省时用默认值也能加载）：

```yaml
- id: dream
  name: '@stardustlc/dsh-dream'
  config:
    # sessionsRoot: ''        # 会话根目录（默认 ~/.dsh/sessions）
    # journalDir: ''          # 梦境日记目录（默认 ~/.dsh/.dsh-dream）
    maxSessions: 10           # dream_digest 最多回放会话数（1-50）
    maxCharsPerSession: 6000  # 每会话摘要字符上限（500-50000）
    # maxUserMessages: 5      # 每会话保留用户消息条数（1-20）
    # maskSecrets: true       # 梦原料隐私脱敏开关（默认开）
    autoCollect: true          # 自动整理候选；页面开关可覆盖
    autoRetrieve: true         # 自动取回已采纳经验；页面开关可覆盖
    autoMaxCallsPerDay: 4       # 辅助调用次数（1-20），跨宿主共享此日记目录预算
    autoCooldownMs: 600000     # 两次尝试的间隔（1000-3600000）
    autoIdleMs: 60000          # 安静时间（0-3600000）；0 仅建议隔离验证使用
    autoMinToolCalls: 2         # 非 Dream 工具次数门槛（1-50）；明确偏好/纠正可无需工具
    autoMaxInputChars: 12000   # 辅助请求 system + JSON 字符预算（1000-20000）
    autoMaxOutputTokens: 1200  # 输出预算（200-2000）
    autoTimeoutMs: 30000       # 请求超时（1000-60000）
```

## 隐私保护（默认开启）

梦原料入梦前自动脱敏：sk 密钥、GitHub/Groq/Slack 令牌、AWS 密钥、JWT、`password/token/api_key` 赋值、超长高熵串都会被打成 `[已脱敏·类型]`。M1 的经验 / 证据 / 错误 / 桥接写盘路径在 `maskSecrets` 开启时同样先过 `mask.ts`，面板只读路由返回的文本也会再做一次脱敏。不需要时可在配置里设 `maskSecrets: false`。

自动整理和自动取回始终脱敏，不受 `maskSecrets: false` 影响。脱敏不能保证识别所有个人信息；敏感项目可关闭自动整理或只关闭该聊天的贡献。自动状态保留预算、哈希化会话游标、开关、取回次数以及最多 24 小时的有限脱敏待处理片段；不会保存隐藏推理或工具正文。已核对的来源原话随经验作为明文证据保存。关闭贡献不删除已有经验。

## 权限与数据

- 只读访问会话目录（`~/.dsh/sessions`），不修改任何会话文件；
- 梦境日记以 JSONL 追加写入 `journalDir`；经验与证据追加写入 `journalDir/knowledge/`（events.jsonl / evidence.jsonl，index.json 可重建）；
- 自动整理通过 DSH 的 LLM adapter 请求当前模型服务；输入为脱敏后的可见消息，沿用当前凭据和额度。没有独立模型账户或第三方记忆服务；
- 会话内容可能包含敏感信息——做梦协议明确禁止把密钥/隐私写入梦境，但梦境日记本身是明文存储，请自行评估。

## 排错

- `dream_digest` 返回 0 个会话：先运行 `dream_health` 检查会话目录是否存在；确认 DSH 已产生过会话；
- 梦境写不进去：检查 `journalDir` 可写权限；
- 加载失败：查看 DSH 启动日志中带 `[dsh-dream]` 前缀的告警。
- 没有自动候选：查看顶部最近检查原因（闲聊、冷却、当日预算、未完成、没有模型等）。正常任务也可能没有值得保留的经验，模型可返回空列表。
- 自动状态损坏：功能保守停用并保留原文件；先备份 `journalDir/automatic/state.json` 再排查，不会自动覆盖。其他宿主正在写入时提示忙，请稍后重试开关。

## 开发

```bash
pnpm install
pnpm test       # 构建 + 离线测试（会话代际、多帧 zstd、流式记录、隐私脱敏、日记、桥接与注册生命周期）
```

## License

MIT（见 [LICENSE](../LICENSE)）
