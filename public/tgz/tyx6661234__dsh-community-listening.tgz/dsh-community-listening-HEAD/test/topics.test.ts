import { afterEach, describe, expect, it, vi } from "vitest";
import { clusterTopics } from "../src/mining/topics";

const article = (id: string, text: string, url = "") => ({ id, text, url });

describe("clusterTopics", () => {
  // KMeans 用 Math.random（k-means++ 初始化）→ 固定随机序列避免 flaky
  const seedRandom = () => {
    let seed = 7;
    vi.spyOn(Math, "random").mockImplementation(() => {
      seed = (seed * 1103515245 + 12345) % 2147483648;
      return seed / 2147483648;
    });
  };
  afterEach(() => {
    vi.restoreAllMocks();
  });

  const items = [
    article("a1", "字节后端校招面经：算法题为主，两轮技术面一轮 HR，问操作系统和网络。"),
    article("a2", "字节后端面试记录：手撕算法题，考察计算机网络与操作系统基础。"),
    article("a3", "腾讯校招后端面经：项目深挖，算法题偏简单，注重工程能力。"),
    article("a4", "腾讯后端面试：问项目、八股文与一道中等难度算法题。"),
    article("b1", "这家酒店位置很好，服务不错，早餐丰富，性价比高。"),
    article("b2", "酒店入住体验：位置便利、早餐丰富、服务态度好，值得推荐。"),
    article("b3", "酒店避雷：隔音差、前台冷漠、早餐难吃，不推荐。"),
    article("c1", "量子计算在金融风控领域的应用前景与挑战分析。"),
    article("c2", "量子计算与金融风控：技术挑战与落地路径研究。"),
  ];

  it("embedding 注入时用 embedding 方法聚类 + 情感聚合", async () => {
    seedRandom();
    // mock embedding：用字符 bigram 构造伪向量（同主题文本共享 bigram → 向量相近）
    const bags = items.map((it) => {
      const run = it.text.replace(/[^一-鿿]/g, "");
      const vec = new Array<number>(64).fill(0);
      for (let i = 0; i + 1 < run.length; i += 1) {
        const code = run.charCodeAt(i) + run.charCodeAt(i + 1);
        vec[code % 64] += 1;
      }
      return vec;
    });
    const result = await clusterTopics(items, undefined, {
      k: 3,
      embed: { vectors: bags, model: "mock", dim: 64 },
    });
    expect(result.method).toBe("embedding");
    expect(result.embeddingAvailable).toBe(true);
    expect(result.degraded).toBe(false);
    expect(result.topics.length).toBeGreaterThanOrEqual(3);
    // 主题按规模降序，每个主题 size ≥ 1，总额 = 输入数
    const totalSize = result.topics.reduce((s, t) => s + t.size, 0);
    expect(totalSize).toBe(items.length);
    for (const t of result.topics) {
      expect(t.label).toBeTruthy();
      expect(typeof t.representative).toBe("string");
      expect(["positive", "negative", "neutral"]).toContain(t.avgSentiment);
    }
    // b3（避雷）应落在负向主题或至少存在负向主题
    expect(result.topics.some((t) => t.avgSentiment === "negative" || t.avgScore < 0)).toBe(true);
  });

  it("无 embedding 时关键词回退聚类（degraded 标记，不阻断）", async () => {
    const result = await clusterTopics(items, undefined, { k: 3, embed: null });
    expect(result.method).toBe("keyword");
    expect(result.degraded).toBe(true);
    expect(result.topics.length).toBeGreaterThanOrEqual(3);
    const totalSize = result.topics.reduce((s, t) => s + t.size, 0);
    expect(totalSize).toBe(items.length);
    // 同类（字节/腾讯）应聚合在一起
    const byteTopics = result.topics.filter((t) => t.representative.includes("字节") || t.label.includes("面试"));
    expect(byteTopics.length).toBeGreaterThanOrEqual(1);
  });

  it("空输入不崩溃", async () => {
    const result = await clusterTopics([], undefined, { embed: null });
    expect(result.topics).toEqual([]);
    expect(result.total).toBe(0);
  });
});
