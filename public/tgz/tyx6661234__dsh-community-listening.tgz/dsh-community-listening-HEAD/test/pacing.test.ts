import { describe, expect, it } from "vitest";
import { mkdtempSync, rmSync, existsSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { PlatformPacer, platformForUrl, resolveStateFile } from "../src/pacing";

/** 用可控时钟构造 Pacer。 */
function pacerWithClock(start = 1_000_000) {
  let now = start;
  const clock = {
    now: () => now,
    advance: (ms: number) => {
      now += ms;
    },
  };
  const pacer = new PlatformPacer({ now: clock.now });
  return { pacer, clock };
}

describe("platformForUrl（host → platform 映射）", () => {
  it("知乎 / B 站 / 小红书映射到专有平台", () => {
    expect(platformForUrl("https://www.zhihu.com/question/123")).toBe("zhihu");
    expect(platformForUrl("https://zhihu.com/question/123")).toBe("zhihu");
    expect(platformForUrl("https://api.zhihu.com/api/v4/me")).toBe("zhihu");
    expect(platformForUrl("https://www.bilibili.com/video/BV1xx411c7mD")).toBe("bilibili");
    expect(platformForUrl("https://api.bilibili.com/x/web-interface/view")).toBe("bilibili");
    expect(platformForUrl("https://www.xiaohongshu.com/explore/123")).toBe("xiaohongshu");
  });

  it("未知 host 归 generic", () => {
    expect(platformForUrl("https://example.com/post")).toBe("generic");
    expect(platformForUrl("not a url")).toBe("generic");
  });
});

describe("PlatformPacer 冷却与指数退避", () => {
  it("风控事件触发冷却，登录墙不触发", () => {
    const { pacer, clock } = pacerWithClock();
    pacer.record("zhihu", "login_wall");
    expect(pacer.cooldownRemainingMs("zhihu")).toBe(0);

    pacer.record("zhihu", "captcha");
    expect(pacer.isCoolingDown("zhihu")).toBe(true);
    expect(pacer.cooldownRemainingMs("zhihu")).toBeGreaterThan(0);
    expect(pacer.cooldownRemainingMs("zhihu")).toBeLessThanOrEqual(60_000);

    clock.advance(120_000);
    expect(pacer.isCoolingDown("zhihu")).toBe(false);
  });

  it("soft 上报不累计 strike，可指定短冷却", () => {
    const { pacer, clock } = pacerWithClock();
    pacer.record("bilibili", "rate_limited", { soft: true, cooldownMs: 10_000 });
    expect(pacer.strikesOf("bilibili")).toBe(0);
    expect(pacer.cooldownRemainingMs("bilibili")).toBe(10_000);
    clock.advance(10_001);
    expect(pacer.isCoolingDown("bilibili")).toBe(false);
  });

  it("冷却结束超过阈值后历史 strike 自动衰减", () => {
    const { pacer, clock } = pacerWithClock();
    pacer.record("bilibili", "rate_limited"); // strikes=1, cooldown 30s
    clock.advance(30_000 + 600_000 + 1); // 冷却早已结束且超过 10 分钟衰减阈值
    pacer.record("bilibili", "rate_limited"); // 应回到基数，不再从高 strike 指数起跳
    expect(pacer.strikesOf("bilibili")).toBe(1);
    expect(pacer.cooldownRemainingMs("bilibili")).toBeLessThanOrEqual(30_000);
  });

  it("clearCooldown 清空冷却与 strike", () => {
    const { pacer } = pacerWithClock();
    pacer.record("bilibili", "rate_limited");
    expect(pacer.isCoolingDown("bilibili")).toBe(true);
    pacer.clearCooldown("bilibili");
    expect(pacer.isCoolingDown("bilibili")).toBe(false);
    expect(pacer.strikesOf("bilibili")).toBe(0);
  });

  it("runExclusive 同平台串行化（并发任务不重叠）", async () => {
    const pacer = new PlatformPacer();
    let active = 0;
    let maxActive = 0;
    const task = async () => {
      await pacer.runExclusive("bilibili", async () => {
        active += 1;
        maxActive = Math.max(maxActive, active);
        await new Promise((resolve) => setTimeout(resolve, 20));
        active -= 1;
      });
    };
    await Promise.all([task(), task(), task()]);
    expect(maxActive).toBe(1);
  });

  it("冷却期内重复上报共享 strike（不无限叠指数）", () => {
    const { pacer } = pacerWithClock();
    pacer.record("bilibili", "rate_limited"); // strikes=1, cooldown 30s
    const first = pacer.cooldownRemainingMs("bilibili");
    pacer.record("bilibili", "rate_limited"); // 冷却期内 → strikes 仍 1
    const second = pacer.cooldownRemainingMs("bilibili");
    expect(pacer.strikesOf("bilibili")).toBe(1);
    // 第二次上报只可能延长窗口，不会更短
    expect(second).toBeGreaterThanOrEqual(first);
  });

  it("冷却期外连续事件指数退避（base × 2^strikes，封顶）", () => {
    const { pacer, clock } = pacerWithClock();
    pacer.record("bilibili", "rate_limited");
    clock.advance(60_000); // 冷却结束（30s 基数）
    pacer.record("bilibili", "rate_limited"); // strikes=2 → 30*2=60s
    const d2 = pacer.cooldownRemainingMs("bilibili");
    expect(d2).toBeGreaterThanOrEqual(60_000);
    expect(d2).toBeLessThanOrEqual(61_000);
    clock.advance(120_000);
    pacer.record("bilibili", "rate_limited"); // strikes=3 → 30*4=120s
    const d3 = pacer.cooldownRemainingMs("bilibili");
    expect(d3).toBeGreaterThanOrEqual(120_000);
    expect(d3).toBeLessThanOrEqual(121_000);
  });

  it("reset 复位 strike（保留已生效冷却自然过期）", () => {
    const { pacer, clock } = pacerWithClock();
    pacer.record("zhihu", "captcha");
    pacer.reset("zhihu");
    expect(pacer.strikesOf("zhihu")).toBe(0);
    expect(pacer.isCoolingDown("zhihu")).toBe(true); // 已生效冷却不清除
    clock.advance(120_000);
    expect(pacer.isCoolingDown("zhihu")).toBe(false);
  });

  it("状态落盘与恢复（跨实例存活）", () => {
    const dir = mkdtempSync(join(tmpdir(), "dsh-pacing-"));
    const file = join(dir, "pacing.json");
    try {
      const a = new PlatformPacer({ stateFile: file, now: () => 1_000_000 });
      a.record("zhihu", "rate_limited");
      a.flush();

      const b = new PlatformPacer({ stateFile: file, now: () => 1_000_000 });
      expect(b.isCoolingDown("zhihu")).toBe(true);
      expect(b.strikesOf("zhihu")).toBe(1);
      expect(existsSync(file)).toBe(true);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("损坏状态文件被忽略（不抛错）", () => {
    const dir = mkdtempSync(join(tmpdir(), "dsh-pacing-"));
    const file = join(dir, "pacing.json");
    try {
      // 写入非法 JSON
      writeFileSync(file, "{not json", "utf8");
      const pacer = new PlatformPacer({ stateFile: file });
      expect(pacer.cooldownRemainingMs("zhihu")).toBe(0);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("waitForSlot 抖动 ±20% 边界（注入固定 random + 捕获 sleep）", async () => {
    const start = 1_000_000;
    const slept: number[] = [];
    const specs = { bilibili: { baseCooldownSeconds: 30, maxCooldownSeconds: 1800, minIntervalMs: 1000 } };
    const mk = (random: () => number, jitterRatio = 0.2) =>
      new PlatformPacer({
        now: () => start,
        specs,
        jitterRatio,
        random,
        sleep: async (ms) => { slept.push(ms); },
      });

    // random=0 → factor = 1 + (0×2−1)×0.2 = 0.8 → 1000×0.8 = 800
    const low = mk(() => 0);
    await low.waitForSlot("bilibili"); // 首次无等待
    await low.waitForSlot("bilibili"); // waitMs=1000 → 抖动 800
    expect(slept).toEqual([800]);

    // random=1 → factor = 1 + (1×2−1)×0.2 = 1.2 → 1200
    slept.length = 0;
    const high = mk(() => 1);
    await high.waitForSlot("bilibili");
    await high.waitForSlot("bilibili");
    expect(slept).toEqual([1200]);

    // random=0.5 → factor = 1 → 1000（中位不变）
    slept.length = 0;
    const mid = mk(() => 0.5);
    await mid.waitForSlot("bilibili");
    await mid.waitForSlot("bilibili");
    expect(slept).toEqual([1000]);
  });

  it("抖动下限截断到 0（jitterRatio 钳制到 1 时最低因子为 0）", async () => {
    const slept: number[] = [];
    const pacer = new PlatformPacer({
      now: () => 1_000_000,
      specs: { bilibili: { baseCooldownSeconds: 30, maxCooldownSeconds: 1800, minIntervalMs: 1000 } },
      jitterRatio: 2, // 构造器钳制到 1 → 因子区间 [0, 2]
      random: () => 0, // factor = 1 + (0×2−1)×1 = 0 → 等待 0
      sleep: async (ms) => { slept.push(ms); },
    });
    await pacer.waitForSlot("bilibili");
    await pacer.waitForSlot("bilibili");
    expect(slept).toEqual([0]);
  });

  it("jitterRatio=0 与旧行为逐毫秒一致（无抖动、无四舍五入）", async () => {
    const slept: number[] = [];
    const pacer = new PlatformPacer({
      now: () => 1_000_000,
      specs: { bilibili: { baseCooldownSeconds: 30, maxCooldownSeconds: 1800, minIntervalMs: 1500 } },
      jitterRatio: 0,
      random: () => 0.9999, // 即使 random 极端也完全不影响
      sleep: async (ms) => { slept.push(ms); },
    });
    await pacer.waitForSlot("bilibili");
    await pacer.waitForSlot("bilibili"); // waitMs = 1500
    expect(slept).toEqual([1500]);
  });
});

describe("resolveStateFile", () => {
  it("配置路径优先；留空用 baseDir/.pacing.json；两者皆空返回空串", () => {
    expect(resolveStateFile("", "/tmp/session")).toBe(join("/tmp/session", ".pacing.json"));
    expect(resolveStateFile("/abs/pacing.json", "/tmp/session")).toBe("/abs/pacing.json");
    expect(resolveStateFile("", "")).toBe("");
  });
});
