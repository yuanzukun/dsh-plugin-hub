import { describe, expect, it } from "vitest";
import { sanitizeLossless } from "../src/lossless";

describe("sanitizeLossless", () => {
  it("丢弃 undefined 属性（lossless JSON 拒绝 undefined 属性值）", () => {
    const cleaned = sanitizeLossless({ a: 1, b: undefined, c: { d: undefined, e: "x" } });
    expect(cleaned).toEqual({ a: 1, c: { e: "x" } });
    expect("b" in cleaned).toBe(false);
  });

  it("非有限数与 -0 归 0", () => {
    expect(sanitizeLossless(NaN)).toBe(0);
    expect(sanitizeLossless(Infinity)).toBe(0);
    expect(Object.is(sanitizeLossless(-0), 0)).toBe(true);
    expect(sanitizeLossless({ score: NaN, avg: 0.5 })).toEqual({ score: 0, avg: 0.5 });
  });

  it("稀疏数组补 null、数组内 undefined 保留为 null", () => {
    const arr: unknown[] = [1];
    arr[2] = undefined; // 稀疏 + undefined 元素
    const cleaned = sanitizeLossless(arr);
    expect(cleaned).toHaveLength(3);
    expect(cleaned[1]).toBeNull();
    expect(cleaned[2]).toBeNull();
  });

  it("原始值透传", () => {
    expect(sanitizeLossless("str")).toBe("str");
    expect(sanitizeLossless(true)).toBe(true);
    expect(sanitizeLossless(null)).toBeNull();
    expect(sanitizeLossless(42)).toBe(42);
    expect(sanitizeLossless(undefined)).toBeNull();
  });

  it("嵌套深度清洗", () => {
    const cleaned = sanitizeLossless({
      list: [{ trust: undefined, score: 1 }, { trust: "A", score: Infinity }],
    });
    expect(cleaned).toEqual({ list: [{ score: 1 }, { trust: "A", score: 0 }] });
  });
});
