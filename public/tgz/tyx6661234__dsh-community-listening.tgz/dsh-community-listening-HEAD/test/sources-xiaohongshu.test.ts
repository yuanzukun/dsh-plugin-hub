import { describe, expect, it } from "vitest";
import {
  buildXhsSearchCardsScript,
  buildXhsTokenMineScript,
  detectXhsRisk,
  extractXhsNoteId,
  parseXhsLoginState,
  parseXhsSearchCards,
} from "../src/sources/xiaohongshu";

describe("extractXhsNoteId", () => {
  it("识别三种笔记路径（explore / discovery/item / search_result）", () => {
    expect(extractXhsNoteId("https://www.xiaohongshu.com/explore/6a1983810000000035039295")).toBe(
      "6a1983810000000035039295",
    );
    expect(extractXhsNoteId("https://www.xiaohongshu.com/discovery/item/6a1983810000000035039295")).toBe(
      "6a1983810000000035039295",
    );
    expect(extractXhsNoteId("https://www.xiaohongshu.com/search_result/6a1983810000000035039295")).toBe(
      "6a1983810000000035039295",
    );
  });

  it("非小红书 / 非法 noteId 返回 null", () => {
    expect(extractXhsNoteId("https://www.xiaohongshu.com/search_result?keyword=abc")).toBeNull(); // 查询页不是笔记
    expect(extractXhsNoteId("https://example.com/explore/abc123")).toBeNull();
    expect(extractXhsNoteId("https://www.xiaohongshu.com/explore/short")).toBeNull();
    expect(extractXhsNoteId("not a url")).toBeNull();
  });
});

describe("detectXhsRisk（风控/登录墙检测）", () => {
  it("安全验证 + 稍后重试 → security_verification", () => {
    expect(detectXhsRisk("系统检测到异常访问，请完成安全验证，稍后再试")).toBe("security_verification");
    expect(detectXhsRisk("请稍后再试 security verification")).toBe("security_verification");
  });

  it("频繁操作 / 429 → frequent_operation", () => {
    expect(detectXhsRisk("操作过于频繁，请稍后重试")).toBe("frequent_operation");
    expect(detectXhsRisk("请勿频繁请求 429")).toBe("frequent_operation");
    expect(detectXhsRisk("Too Many Requests")).toBe("frequent_operation");
  });

  it("登录墙 → login_wall", () => {
    expect(detectXhsRisk("登录后查看搜索结果")).toBe("login_wall");
    expect(detectXhsRisk("登录即可查看Ta的笔记")).toBe("login_wall");
  });

  it("正常文本 → null", () => {
    expect(detectXhsRisk("机械键盘选购攻略 像素观测所 07-25 286")).toBeNull();
    expect(detectXhsRisk("")).toBeNull();
  });

  it("App 扫码墙文本不误判为风控（detectXhsRisk 返回 null，由上层专门处理）", () => {
    expect(detectXhsRisk("当前笔记暂时无法浏览 请打开小红书App扫码查看")).toBeNull();
  });
});

describe("parseXhsSearchCards", () => {
  it("解析卡片（含字段归一化）", () => {
    const parsed = parseXhsSearchCards({
      ok: true,
      items: [
        {
          noteId: "6a1983810000000035039295",
          url: "https://www.xiaohongshu.com/explore/6a1983810000000035039295",
          title: "新手第一把机械键盘",
          author: "像素观测所",
          likeCount: 286,
          commentCount: 12,
          collectCount: 30,
          xsecToken: "ABwLfv1gILs0RKG1NbTsY-XOAbce9ddIg3Ckhs02oCLTo=",
        },
        { noteId: "invalid", title: "x" }, // 非法 id 过滤
        null,
      ],
    });
    expect(parsed.ok).toBe(true);
    expect(parsed.items).toHaveLength(1);
    expect(parsed.items[0]).toEqual({
      noteId: "6a1983810000000035039295",
      url: "https://www.xiaohongshu.com/explore/6a1983810000000035039295",
      title: "新手第一把机械键盘",
      author: "像素观测所",
      likeCount: 286,
      commentCount: 12,
      collectCount: 30,
      xsecToken: "ABwLfv1gILs0RKG1NbTsY-XOAbce9ddIg3Ckhs02oCLTo=",
    });
  });

  it("错误负载 / 非对象", () => {
    expect(parseXhsSearchCards({ ok: false, error: "boom" }).ok).toBe(false);
    expect(parseXhsSearchCards(null).ok).toBe(false);
  });
});

describe("buildXhsSearchCardsScript", () => {
  it("选择器覆盖三种笔记链接 + 提取 xsec_token + 不依赖 INITIAL_STATE", () => {
    const script = buildXhsSearchCardsScript();
    expect(script).toContain('a[href*="/explore/"]');
    expect(script).toContain('a[href*="/discovery/item/"]');
    expect(script).toContain('a[href*="/search_result/"]');
    expect(script).toContain("xsec_token"); // 从链接 href 提取 token
    expect(script).not.toContain("noteDetailMap"); // 纯 DOM 读取
  });
});

describe("parseXhsLoginState", () => {
  it("解析真实会话信号（sessionUser 确认登录）", () => {
    expect(
      parseXhsLoginState({
        sessionUser: true,
        sessionUserId: "5f1c2d3e4b5a6c7d8e9f0a1b",
        hasProfileLink: true,
        hasPublishEntry: true,
        loginWallText: false,
        cookieNames: ["a1", "webId", "gid"],
        cookieHasWebSession: false,
        loggedIn: true,
      }),
    ).toEqual({
      sessionUser: true,
      sessionUserId: "5f1c2d3e4b5a6c7d8e9f0a1b",
      hasProfileLink: true,
      hasPublishEntry: true,
      loginWallText: false,
      cookieNames: ["a1", "webId", "gid"],
      cookieHasWebSession: false,
      loggedIn: true,
    });
  });

  it("弱 UI 信号不视为登录（cookieHasWebSession 恒 false）", () => {
    expect(
      parseXhsLoginState({
        sessionUser: false,
        sessionUserId: "",
        hasProfileLink: true,
        hasPublishEntry: true,
        loginWallText: false,
        cookieNames: ["a1"],
        cookieHasWebSession: false,
        loggedIn: false,
      }),
    ).toEqual({
      sessionUser: false,
      sessionUserId: "",
      hasProfileLink: true,
      hasPublishEntry: true,
      loginWallText: false,
      cookieNames: ["a1"],
      cookieHasWebSession: false,
      loggedIn: false,
    });
  });

  it("非对象回退未登录", () => {
    expect(parseXhsLoginState(null)).toEqual({
      sessionUser: false,
      sessionUserId: "",
      hasProfileLink: false,
      hasPublishEntry: false,
      loginWallText: false,
      cookieNames: [],
      cookieHasWebSession: false,
      loggedIn: false,
    });
  });
});

describe("buildXhsTokenMineScript", () => {
  it("同时支持 URL 字符串 token 与独立 xsecToken 字段（Pass A + Pass B）", () => {
    const script = buildXhsTokenMineScript();
    // Pass A：URL 字符串路径保留
    expect(script).toContain("xsec_token=");
    // Pass B：独立 xsecToken/xsec_token 字段 + 同层 noteId 关联
    expect(script).toContain("xsec_?token");
    expect(script).toContain("noteId");
    expect(script).toContain("noteCard");
  });
});
