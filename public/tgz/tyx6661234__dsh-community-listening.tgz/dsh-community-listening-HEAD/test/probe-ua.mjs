import { readFileSync } from "node:fs";

const env = {};
for (const line of readFileSync("D:/agentdev/insigtai/.env", "utf8").split(/\r?\n/)) {
  const m = line.trim().match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
  if (m) env[m[1]] = m[2].trim().replace(/^["']|["']$/g, "");
}

const BASE = env.OPENCODE_API_BASE_URL.replace(/\/+$/, "");
const KEY = env.OPENCODE_API_KEY;
const MODELS = env.OPENCODE_FREE_MODELS.split(",").map((s) => s.trim());

const call = async (ua, model) => {
  try {
    const headers = {
      "content-type": "application/json",
      authorization: "Bearer " + KEY,
    };
    if (ua) headers["user-agent"] = ua;
    const r = await fetch(BASE + "/chat/completions", {
      method: "POST",
      headers,
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: "回复：ok" }],
        temperature: 0,
        stream: false,
      }),
    });
    return r.status;
  } catch {
    return "ERR";
  }
};

const round = async (label, ua, count, rotate) => {
  const counts = {};
  for (let i = 0; i < count; i++) {
    const model = rotate ? MODELS[i % MODELS.length] : MODELS[0];
    const status = await call(ua, model);
    counts[status] = (counts[status] ?? 0) + 1;
    if (i < 3 || status !== 200) console.log(`${label} #${i} model=${model} -> ${status}`);
  }
  console.log(`${label} 汇总(${count} 次):`, JSON.stringify(counts));
  console.log("---");
};

console.log("实验 1：无 UA，单模型 x8");
await round("no-ua-single", null, 8, false);
console.log("实验 2：无 UA，7 模型轮转 x14");
await round("no-ua-rotate", null, 14, true);
console.log("实验 3：UA=opencode，单模型 x8");
await round("ua-opencode", "opencode", 8, false);
console.log("实验 4：UA=opencode，7 模型轮转 x14");
await round("ua-opencode-rotate", "opencode", 14, true);
