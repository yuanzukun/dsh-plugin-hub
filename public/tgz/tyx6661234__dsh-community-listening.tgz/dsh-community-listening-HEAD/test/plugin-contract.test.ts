import { existsSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { apply, resolvePluginConfig } from "../src/index";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const pkg = JSON.parse(readFileSync(resolve(root, "package.json"), "utf8")) as Record<string, any>;

describe("DSH plugin contract", () => {
  it("publishes a valid standard bundle manifest", () => {
    expect(pkg.name).toBe("dsh-community-listening");
    expect(pkg.private).not.toBe(true);
    expect(pkg.license).toBe("MIT");
    expect(pkg.engines.node).toBe(">=20");
    expect(pkg.dsh.bundle.patch).toBe("./cordis.patch.yml");
    expect(pkg.main).toBe("lib/index.mjs");
    expect(pkg.types).toBe("lib/index.d.mts");
    expect(existsSync(resolve(root, "LICENSE"))).toBe(true);
  });

  it("keeps the patch entry aligned with the package name", () => {
    const patch = readFileSync(resolve(root, "cordis.patch.yml"), "utf8");
    expect([...patch.matchAll(/^\s*- id:\s*([^\s#]+)\s*$/gm)].map((m) => m[1])).toEqual([pkg.name]);
    expect([...patch.matchAll(/^\s+name:\s*([^\s#]+)\s*$/gm)].map((m) => m[1])).toEqual([pkg.name]);
  });

  it("normalizes portable defaults and bounded limits", () => {
    const resolved = resolvePluginConfig({
      envPath: "  ",
      bskTimeoutMs: 999_999,
      maxCollectConcurrency: 99,
      zhihuMaxAnswers: -1,
      zhihuMaxAnswerComments: 101,
      bilibiliMaxComments: 0,
      bilibiliMaxReplyComments: 101,
    });
    expect(resolved.envPath).toBe("");
    expect(resolved.bskTimeoutMs).toBe(600_000);
    expect(resolved.maxCollectConcurrency).toBe(5);
    expect(resolved.zhihuMaxAnswers).toBe(1);
    expect(resolved.zhihuMaxAnswerComments).toBe(100);
    expect(resolved.bilibiliMaxComments).toBe(1);
    expect(resolved.bilibiliMaxReplyComments).toBe(100);
  });

  it("registers an awaitable generation disposer", async () => {
    let disposer: (() => Promise<void>) | undefined;
    const ctx = {
      get: () => undefined,
      tools: { register: () => undefined },
      effect: (factory: () => () => Promise<void>) => {
        disposer = factory();
      },
    } as any;

    apply(ctx, { bskPath: "dsh-community-listening-test-missing-bsk", autoLaunchChrome: false });
    expect(disposer).toBeTypeOf("function");
    await disposer?.();
  });
});
