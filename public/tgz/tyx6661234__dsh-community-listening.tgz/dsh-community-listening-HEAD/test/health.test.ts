import { describe, expect, it } from "vitest";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  CrawlerHealth,
  healthStateFile,
  MAX_RECORDS_PER_KEY,
  RECENT_COUNT,
} from "../src/health";
import { PlatformPacer } from "../src/pacing";

describe("healthStateFile", () => {
  it("与 pacing 文件同目录", () => {
    expect(healthStateFile("D:\\work\\.pacing.json")).toBe("D:\\work\\.crawler-health.json");
  });
  it("空路径不落盘", () => {
    expect(healthStateFile("")).toBe("");
  });
});

describe("CrawlerHealth.status", () => {
  it("无记录 + 无冷却 → unknown", () => {
    const health = new CrawlerHealth();
    const pacer = new PlatformPacer();
    const [entry] = health.status(pacer, "bilibili").filter((e) => e.action === "comments");
    expect(entry.status).toBe("unknown");
    expect(entry.preferredBackend).toBe("bilibili-api-direct");
  });

  it("成功 → healthy；降级成功 → degraded", () => {
    const health = new CrawlerHealth();
    const pacer = new PlatformPacer();
    health.record({ platform: "bilibili", action: "comments", backend: "bilibili-api-direct", outcome: "success" });
    let [entry] = health.status(pacer, "bilibili").filter((e) => e.action === "comments");
    expect(entry.status).toBe("healthy");
    expect(entry.lastOutcome).toBe("success");

    health.record({ platform: "bilibili", action: "comments", backend: "bilibili-browser-fetch", outcome: "success", degraded: true });
    [entry] = health.status(pacer, "bilibili").filter((e) => e.action === "comments");
    expect(entry.status).toBe("degraded");
    expect(entry.degraded).toBe(true);
  });

  it("登录墙 → blocked；pacer 冷却覆盖为 cooling", () => {
    const health = new CrawlerHealth();
    const pacer = new PlatformPacer();
    health.record({ platform: "xiaohongshu", action: "comments", backend: "xhs-state-mine", outcome: "login_wall" });
    let [entry] = health.status(pacer, "xiaohongshu").filter((e) => e.action === "comments");
    expect(entry.status).toBe("blocked");

    pacer.record("xiaohongshu", "rate_limited");
    [entry] = health.status(pacer, "xiaohongshu").filter((e) => e.action === "comments");
    expect(entry.status).toBe("cooling");
    expect(entry.cooldownRemainingMs).toBeGreaterThan(0);
  });

  it("落盘恢复（损坏容错）", () => {
    const dir = mkdtempSync(join(tmpdir(), "dsh-health-"));
    const file = join(dir, ".crawler-health.json");
    const health = new CrawlerHealth({ stateFile: file });
    health.record({ platform: "kuaishou", action: "comments", backend: "kuaishou-browser-fetch", outcome: "success" });
    health.flush();

    const restored = new CrawlerHealth({ stateFile: file });
    const record = restored.recordFor("kuaishou", "comments");
    expect(record?.backend).toBe("kuaishou-browser-fetch");
    expect(readFileSync(file, "utf8")).toContain("version");

    rmSync(dir, { recursive: true, force: true });
  });

  it("环形缓冲：写 25 条截断到 20（丢最旧）", () => {
    const health = new CrawlerHealth();
    for (let i = 0; i < 25; i += 1) {
      health.record({ platform: "bilibili", action: "comments", backend: `b-${i}`, outcome: i % 2 === 0 ? "success" : "empty" });
    }
    const history = health.historyFor("bilibili", "comments");
    expect(history).toHaveLength(MAX_RECORDS_PER_KEY); // 20
    expect(history[0].backend).toBe("b-5"); // 最旧的 b-0..b-4 被丢
    expect(history[history.length - 1].backend).toBe("b-24"); // 最新保留
    // 不同键互不影响
    expect(health.historyFor("bilibili", "search")).toHaveLength(0);
  });

  it("status 趋势字段：successRate/degradedRate/recent/samples", () => {
    const health = new CrawlerHealth();
    const pacer = new PlatformPacer();
    // 10 条：6 success（其中 2 degraded）+ 2 empty + 2 rate_limited
    for (let i = 0; i < 10; i += 1) {
      if (i < 6) {
        health.record({ platform: "zhihu", action: "comments", backend: "zhihu-api", outcome: "success", degraded: i < 2 });
      } else if (i < 8) {
        health.record({ platform: "zhihu", action: "comments", backend: "zhihu-api", outcome: "empty" });
      } else {
        health.record({ platform: "zhihu", action: "comments", backend: "zhihu-api", outcome: "rate_limited" });
      }
    }
    const [entry] = health.status(pacer, "zhihu").filter((e) => e.action === "comments");
    expect(entry.samples).toBe(10);
    expect(entry.successRate).toBe(8 / 10); // success+empty 占比
    expect(entry.degradedRate).toBe(2 / 10);
    expect(entry.recent).toHaveLength(RECENT_COUNT); // 最近 5 条
    expect(entry.recent[entry.recent.length - 1].outcome).toBe("rate_limited"); // 最后一条驱动状态
    expect(entry.status).toBe("cooling"); // 状态判定仍由最后一条驱动
    expect(entry.lastOutcome).toBe("rate_limited");
  });

  it("冷却覆盖逻辑不变（环形缓冲下 cooldown 仍覆盖为 cooling）", () => {
    const health = new CrawlerHealth();
    const pacer = new PlatformPacer();
    health.record({ platform: "weibo", action: "comments", backend: "weibo-api", outcome: "success" });
    let [entry] = health.status(pacer, "weibo").filter((e) => e.action === "comments");
    expect(entry.status).toBe("healthy");
    expect(entry.samples).toBe(1);

    pacer.record("weibo", "rate_limited");
    [entry] = health.status(pacer, "weibo").filter((e) => e.action === "comments");
    expect(entry.status).toBe("cooling");
    expect(entry.cooldownRemainingMs).toBeGreaterThan(0);
    // 冷却记录也进环形缓冲
    health.record({ platform: "weibo", action: "comments", backend: "weibo-api", outcome: "rate_limited" });
    expect(health.historyFor("weibo", "comments")).toHaveLength(2);
  });
});
