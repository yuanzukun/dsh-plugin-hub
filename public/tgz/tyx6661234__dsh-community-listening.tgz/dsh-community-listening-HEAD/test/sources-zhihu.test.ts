import { describe, expect, it } from "vitest";
import {
  buildZhihuCommentsScript,
  buildZhihuFeedsScript,
  extractZhihuQid,
  parseEvaluatePayload,
  toAnswerRaw,
  unwrapEvaluateValue,
} from "../src/sources/zhihu";

describe("extractZhihuQid", () => {
  it("提取 /question/{qid}", () => {
    expect(extractZhihuQid("https://www.zhihu.com/question/597272501")).toBe("597272501");
    expect(extractZhihuQid("https://zhihu.com/question/12345678/answer/87654321")).toBe("12345678");
    expect(extractZhihuQid("https://www.zhihu.com/question/12345678?sort=created")).toBe("12345678");
  });

  it("非知乎 / 非法 qid 返回 null", () => {
    expect(extractZhihuQid("https://www.zhihu.com/p/12345678")).toBeNull();
    expect(extractZhihuQid("https://example.com/question/123")).toBeNull();
    expect(extractZhihuQid("https://www.zhihu.com/question/abc")).toBeNull();
    expect(extractZhihuQid("not a url")).toBeNull();
  });
});

describe("buildZhihuFeedsScript / buildZhihuCommentsScript", () => {
  it("回答流脚本指向 /api/v4/questions/{qid}/feeds 且带 limit/offset", () => {
    const script = buildZhihuFeedsScript("597272501", 20, 20);
    expect(script).toContain("/api/v4/questions/597272501/feeds?limit=20&offset=20");
    expect(script).toContain('credentials: "include"');
    expect(script).toContain("document.title");
  });

  it("评论脚本指向 /api/v4/answers/{aid}/comments", () => {
    const script = buildZhihuCommentsScript("3100000001", 0, 20);
    expect(script).toContain("/api/v4/answers/3100000001/comments?limit=20&offset=0");
  });
});

describe("parseEvaluatePayload（防御性解析 bsk evaluate 返回）", () => {
  it("正常负载", () => {
    const p = parseEvaluatePayload({ ok: true, isEnd: true, pageTitle: "问题标题 - 知乎", items: [{ id: "1" }] });
    expect(p.ok).toBe(true);
    expect(p.isEnd).toBe(true);
    expect(p.pageTitle).toBe("问题标题 - 知乎");
    expect(p.items).toHaveLength(1);
  });

  it("错误负载（status / error）", () => {
    expect(parseEvaluatePayload({ ok: false, status: 401 })).toMatchObject({ ok: false, status: 401 });
    expect(parseEvaluatePayload({ ok: false, error: "boom" })).toMatchObject({ ok: false, error: "boom" });
  });

  it("非对象 / null 返回 ok:false", () => {
    expect(parseEvaluatePayload(null).ok).toBe(false);
    expect(parseEvaluatePayload("x").ok).toBe(false);
    expect(parseEvaluatePayload(undefined).ok).toBe(false);
  });
});

describe("unwrapEvaluateValue（兼容 bsk 输出包装）", () => {
  it("bsk 包装 {ok, tab_id, value} 时解包 value", () => {
    const v = { ok: true, items: [{ id: "1" }] };
    expect(unwrapEvaluateValue({ ok: true, tab_id: 123, value: v })).toEqual(v);
  });
  it("包一层 {result} 时解包", () => {
    expect(unwrapEvaluateValue({ result: { ok: true } })).toEqual({ ok: true });
  });
  it("对象本身（含业务字段）不解包", () => {
    const v = { ok: true, items: [] };
    expect(unwrapEvaluateValue(v)).toEqual(v);
  });
  it("非对象原样返回", () => {
    expect(unwrapEvaluateValue(42)).toBe(42);
    expect(unwrapEvaluateValue([1, 2])).toEqual([1, 2]);
  });
});

describe("toAnswerRaw（回答归一化，含大整数 id）", () => {
  it("feeds 条目归一化（target 包裹）", () => {
    const raw = toAnswerRaw({
      target: {
        id: 3098123456789012, // 大整数 → 字符串
        author: { name: "测试作者" },
        excerpt: "回答摘要内容",
        comment_count: 12,
        voteup_count: 345,
      },
    });
    expect(raw).toEqual({
      id: "3098123456789012",
      author: "测试作者",
      content: "回答摘要内容",
      commentCount: 12,
      voteup: 345,
    });
  });

  it("字段缺失给默认值；无 id 返回 null", () => {
    const raw = toAnswerRaw({ id: "5", content: "y" });
    expect(raw).toEqual({ id: "5", author: "", content: "y", commentCount: 0, voteup: 0 });
    expect(toAnswerRaw({ author: "x" })).toBeNull(); // 无 id
    expect(toAnswerRaw({})).toBeNull();
    expect(toAnswerRaw(null)).toBeNull();
  });
});
