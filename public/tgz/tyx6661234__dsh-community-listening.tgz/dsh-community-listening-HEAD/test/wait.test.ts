import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { pollExtract, pollPageReady } from "../src/sources/wait";

/**
 * 条件等待（poll-until-ready）单测：用假定时器验证轮询语义。
 * 立即就绪 1 次调用即返回 / 第 3 次才就绪 / 超时返回最后值 /
 * evalFn 抛错不中断轮询 / abort 立即退出。
 */
describe("pollExtract", () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  it("立即就绪：只调 1 次即返回", async () => {
    const fn = vi.fn(async () => "ready");
    const promise = pollExtract(fn, (v) => v === "ready", { intervalMs: 600, maxMs: 10_000 });
    await expect(promise).resolves.toBe("ready");
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it("第 3 次才就绪：轮询到 ready 提前返回", async () => {
    let calls = 0;
    const promise = pollExtract(
      async () => {
        calls += 1;
        return calls >= 3 ? "ready" : "not-yet";
      },
      (v) => v === "ready",
      { intervalMs: 600, maxMs: 10_000 },
    );
    await vi.advanceTimersByTimeAsync(2000);
    await expect(promise).resolves.toBe("ready");
    expect(calls).toBe(3);
  });

  it("超时返回最后一次结果（调用方沿用 empty/error 语义）", async () => {
    let calls = 0;
    const promise = pollExtract(
      async () => {
        calls += 1;
        return "still-not-ready";
      },
      () => false,
      { intervalMs: 600, maxMs: 1000 },
    );
    await vi.advanceTimersByTimeAsync(2000);
    await expect(promise).resolves.toBe("still-not-ready");
    // t=0 首采 + t=600 轮询 + t=1200 轮询（先采后查超时）→ 3 次后返回
    expect(calls).toBe(3);
  });

  it("evalFn 抛错视为未就绪，不中断轮询", async () => {
    let calls = 0;
    const promise = pollExtract(
      async () => {
        calls += 1;
        if (calls === 1) throw new Error("page not ready");
        return calls >= 3 ? "ok" : "not-yet";
      },
      (v) => v === "ok",
      { intervalMs: 600, maxMs: 10_000 },
    );
    await vi.advanceTimersByTimeAsync(2000);
    await expect(promise).resolves.toBe("ok");
    expect(calls).toBe(3);
  });

  it("abort 立即退出（不等超时）", async () => {
    const controller = new AbortController();
    const promise = pollExtract(
      async () => "not-yet",
      () => false,
      { intervalMs: 600, maxMs: 60_000, signal: controller.signal },
    );
    controller.abort();
    await expect(promise).resolves.toBe("not-yet");
  });

  it("从未拿到结果时 abort/超时返回 null", async () => {
    const controller = new AbortController();
    const promise = pollExtract(
      async () => {
        throw new Error("always throws");
      },
      () => false,
      { intervalMs: 600, maxMs: 10_000, signal: controller.signal },
    );
    controller.abort();
    await expect(promise).resolves.toBeNull();
  });
});

describe("pollPageReady", () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  it("readyState=complete 即返回；超时静默继续（无返回值）", async () => {
    let state: string = "loading";
    const promise = pollPageReady(async () => state, { intervalMs: 600, maxMs: 5000 });
    state = "complete";
    await vi.advanceTimersByTimeAsync(700); // t=600 下一次轮询命中 complete
    await expect(promise).resolves.toBeUndefined();

    // 超时路径：始终非 complete → 仍 resolve（undefined），不抛错
    const p2 = pollPageReady(async () => "loading", { intervalMs: 600, maxMs: 100 });
    await vi.advanceTimersByTimeAsync(700); // t=600 轮询后命中超时检查
    await expect(p2).resolves.toBeUndefined();
  });
});
