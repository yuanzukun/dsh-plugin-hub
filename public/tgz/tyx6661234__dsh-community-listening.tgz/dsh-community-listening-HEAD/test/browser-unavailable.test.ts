import { describe, expect, it } from "vitest";
import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import {
  BrowserSessionPool,
  BrowserUnavailableError,
  isBrowserUnavailable,
} from "../src/collect";
import type { BskRunResult, BskRunner } from "../src/runner";

/**
 * 断连自愈回归（Chrome 关闭 / bsk 守护进程重启后无浏览器接入）：
 * - 浏览器型采集工具不再 RPC 挂满 bskTimeoutMs（默认 120s），而是快速失败；
 * - 失败原因区分「浏览器基础设施」与「平台风控」——基础设施失败不计 strike。
 * 用注入 fake runner 模拟 bsk status / RPC，避免真实浏览器。
 */
function fakeRunner(opts: {
  initialBrowsers: unknown[];
  /** 浏览器 RPC（非 status/session start）的返回（默认成功空对象）。 */
  opResult?: Partial<BskRunResult>;
  /** RPC 之后浏览器列表变化（模拟「操作中 Chrome 关闭/守护进程重启」）。 */
  browsersAfter?: unknown[];
  /** status 直接抛错（模拟守护进程不可达）。 */
  statusThrows?: boolean;
}) {
  let browsers = opts.initialBrowsers;
  const calls: string[][] = [];
  const runner: BskRunner = {
    async run(args: string[], _options?: unknown): Promise<BskRunResult> {
      calls.push(args);
      if (args[0] === "status") {
        if (opts.statusThrows) throw new Error("bsk daemon unreachable");
        return { code: 0, stdout: JSON.stringify({ browsers }), stderr: "", timedOut: false, aborted: false };
      }
      if (args[0] === "session" && args[1] === "start") {
        return { code: 0, stdout: JSON.stringify({ session_id: "sess-1" }), stderr: "", timedOut: false, aborted: false };
      }
      if (opts.browsersAfter !== undefined) browsers = opts.browsersAfter;
      return { code: 0, stdout: "{}", stderr: "", timedOut: false, aborted: false, ...opts.opResult };
    },
    killAll() {},
  };
  return { runner, calls };
}

function poolWith(runner: BskRunner, maxConcurrency = 2): BrowserSessionPool {
  // autoLaunchChrome: false —— 测试只验证快速失败路径，不真实拉起 Chrome
  return new BrowserSessionPool("bsk", 120_000, maxConcurrency, { autoLaunchChrome: false, runner });
}

describe("BrowserUnavailableError / isBrowserUnavailable", () => {
  it("错误类与判定谓词", () => {
    const err = new BrowserUnavailableError("bsk 无浏览器接入", { timedOut: true });
    expect(err.name).toBe("BrowserUnavailableError");
    expect(err.timedOut).toBe(true);
    expect(isBrowserUnavailable(err)).toBe(true);
    expect(isBrowserUnavailable(new Error("普通错误"))).toBe(false);
    expect(isBrowserUnavailable(null)).toBe(false);
  });
});

describe("BrowserSessionPool 断连自愈", () => {
  it("无浏览器接入：acquire 快速抛 BrowserUnavailableError，浏览器 RPC 不被调用", async () => {
    const { runner, calls } = fakeRunner({ initialBrowsers: [] });
    const pool = poolWith(runner);
    await expect(pool.acquire({} as ToolRunContext)).rejects.toBeInstanceOf(BrowserUnavailableError);
    // 只调过 status 探针，没调任何浏览器 RPC（不挂 120s）
    expect(calls.every((c) => c[0] === "status")).toBe(true);
  });

  it("bsk 守护进程不可达 → 也归为 BrowserUnavailableError（快速失败）", async () => {
    const { runner } = fakeRunner({ initialBrowsers: [], statusThrows: true });
    const pool = poolWith(runner);
    await expect(pool.acquire({} as ToolRunContext)).rejects.toMatchObject({
      name: "BrowserUnavailableError",
    });
  });

  it("RPC 超时且浏览器已断连：转换 BrowserUnavailableError(timedOut=true)，槽位失效，下次快速失败", async () => {
    const { runner, calls } = fakeRunner({
      initialBrowsers: [{}], // 开始时浏览器连接正常
      opResult: { timedOut: true, stdout: "" }, // 操作中 RPC 超时
      browsersAfter: [], // 超时后重探：浏览器已断连（Chrome 关闭/守护进程重启）
    });
    const pool = poolWith(runner);
    const handle = await pool.acquire({} as ToolRunContext);
    await expect(
      handle.run({} as ToolRunContext, ["evaluate", "--session", "sess-1", "x"], "eval"),
    ).rejects.toMatchObject({ name: "BrowserUnavailableError", timedOut: true });
    // 浏览器 RPC 只执行一次（失败后不会重跑挂死）
    expect(calls.filter((c) => c[0] === "evaluate")).toHaveLength(1);
    // 槽位已全部失效：下一次 acquire 走快速失败路径（不等 120s）
    await expect(pool.acquire({} as ToolRunContext)).rejects.toBeInstanceOf(BrowserUnavailableError);
  });

  it("RPC 超时但浏览器仍连接：不转换（保持原超时错误，上层按平台风险处理）", async () => {
    const { runner } = fakeRunner({
      initialBrowsers: [{}],
      opResult: { timedOut: true, stdout: "" },
      // browsersAfter 不设置 → 浏览器保持连接
    });
    const pool = poolWith(runner);
    const handle = await pool.acquire({} as ToolRunContext);
    // BskError（parseBskJson 抛出的超时错误）——不是 BrowserUnavailableError
    await expect(
      handle.run({} as ToolRunContext, ["navigate", "--session", "sess-1", "https://x"], "nav"),
    ).rejects.toMatchObject({ name: "BskError", timedOut: true });
  });

  it("dispose 等待并停止所有已创建会话，且可重复调用", async () => {
    const { runner, calls } = fakeRunner({ initialBrowsers: [{}] });
    const pool = poolWith(runner);
    const handle = await pool.acquire({} as ToolRunContext);
    handle.release();

    await pool.dispose();
    await pool.dispose();

    expect(calls).toContainEqual(["session", "stop", "sess-1"]);
  });
});
