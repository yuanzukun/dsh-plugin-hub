/**
 * 真实网络/bsk 冒烟测试（默认跳过；设 SMOKE=1 后运行）：
 *   pnpm vitest run test/smoke.test.ts（需先 $env:SMOKE=1）
 * 覆盖：bsk 会话（start/navigate/observe/stop）、Chrome 自动探测与 BrowserSkill 扩展拷贝。
 */
import { describe, expect, it } from "vitest";
import { existsSync } from "node:fs";
import { detectChromePath, ensureExtensionCopied } from "../src/collect";

const ENABLED = process.env.SMOKE === "1";

describe.skipIf(!ENABLED)("smoke: chrome auto-launch", () => {
  it("detectChromePath 找到本机 Chrome/Edge", () => {
    const path = detectChromePath();
    expect(path).toBeTruthy();
    expect(existsSync(path as string)).toBe(true);
  });

  it("ensureExtensionCopied 拷贝 BrowserSkill 扩展到稳定目录", () => {
    const dest = ensureExtensionCopied();
    expect(dest).toBeTruthy();
    expect(existsSync(`${dest}/manifest.json`)).toBe(true);
  });
});

describe.skipIf(!ENABLED)("smoke: bsk", { timeout: 120_000 }, () => {
  it("会话生命周期（无浏览器连接时跳过）", async () => {
    const { createBskRunner, parseBskJson } = await import("../src/runner");
    const runner = createBskRunner("bsk");
    const status = parseBskJson(await runner.run(["status"], { timeoutMs: 10_000 }), "status") as {
      browsers?: unknown[];
    };
    expect(status).toBeTruthy();
    if (!Array.isArray(status.browsers) || status.browsers.length === 0) {
      // bsk 守护进程在跑但没有浏览器连接（需要浏览器侧 BrowserSkill 扩展/Agent Window）
      return; // 跳过（环境状态，非代码问题）
    }
    const start = parseBskJson(await runner.run(["session", "start"], { timeoutMs: 30_000 }), "session start") as {
      session_id?: string;
    };
    expect(start.session_id).toBeTruthy();
    const sid = start.session_id as string;
    try {
      await parseBskJson(await runner.run(["navigate", "--session", sid, "https://example.com"], { timeoutMs: 60_000 }), "navigate");
      const observe = parseBskJson(await runner.run(["observe", "--session", sid], { timeoutMs: 30_000 }), "observe");
      expect(observe).toBeTruthy();
    } finally {
      await runner.run(["session", "stop", sid], { timeoutMs: 30_000 }).catch(() => {});
    }
  });
});
