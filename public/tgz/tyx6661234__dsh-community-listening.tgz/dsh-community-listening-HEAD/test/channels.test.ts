import { describe, expect, it } from "vitest";
import {
  backendChainFor,
  CHANNELS,
  runChannelChain,
  type ChannelAttempt,
} from "../src/channels";

describe("backendChainFor", () => {
  it("B站评论：API 直连 → 浏览器同源 fetch", () => {
    const chain = backendChainFor("bilibili", "comments");
    expect(chain.map((c) => c.id)).toEqual(["bilibili-api-direct", "bilibili-browser-fetch"]);
  });

  it("快手搜索：state 挖掘 → DOM 兜底", () => {
    const chain = backendChainFor("kuaishou", "search");
    expect(chain.map((c) => c.id)).toEqual(["kuaishou-search-state", "kuaishou-search-dom"]);
  });

  it("未知平台回退通用浏览器通道", () => {
    const chain = backendChainFor("generic", "comments");
    expect(chain.map((c) => c.id)).toEqual(["generic-browser-dom"]);
  });

  it("通道注册表 id 唯一", () => {
    expect(new Set(CHANNELS.map((c) => c.id)).size).toBe(CHANNELS.length);
  });
});

describe("runChannelChain", () => {
  const success = (value: string): ChannelAttempt<string> => ({
    backend: { id: "b1", platform: "generic", action: "comments", kind: "dom-extract", label: "b1" },
    attempt: async () => ({ done: true, value }),
  });

  it("主通道直接成功：fallbacks 空、degraded=false", async () => {
    const out = await runChannelChain([success("ok")]);
    expect(out).toEqual({ result: "ok", backend: "b1", fallbacks: [], degraded: false });
  });

  it("主通道失败 → 第二通道成功：记录降级", async () => {
    const out = await runChannelChain([
      { ...success("never"), attempt: async () => ({ done: false, reason: "b1 down" }) },
      { ...success("fallback-ok"), backend: { id: "b2", platform: "generic", action: "comments", kind: "browser-fetch", label: "b2" } },
    ]);
    expect(out.result).toBe("fallback-ok");
    expect(out.backend).toBe("b2");
    expect(out.fallbacks).toEqual(["b1"]);
    expect(out.degraded).toBe(true);
  });

  it("全部失败抛错并包含通道链", async () => {
    await expect(
      runChannelChain([
        { ...success("x"), attempt: async () => ({ done: false, reason: "first" }) },
        { ...success("x"), backend: { id: "b2", platform: "generic", action: "comments", kind: "browser-fetch", label: "b2" }, attempt: async () => ({ done: false, reason: "second" }) },
      ]),
    ).rejects.toThrow(/b1 → b2/);
  });

  it("abort 立即终止", async () => {
    const controller = new AbortController();
    controller.abort();
    await expect(
      runChannelChain([success("x")], { signal: controller.signal }),
    ).rejects.toThrow(/被取消/);
  });
});
