import { describe, expect, it } from "vitest";
import { BrowserSessionPool } from "../src/collect";
import { PlatformPacer } from "../src/pacing";
import { collectKuaishouComments } from "../src/sources/kuaishou";

/**
 * 快手评论通道真实冒烟：需 bsk + 浏览器（快手页面自动带 cookie，评论 API 免签名）。
 * 默认跳过；`DSH_SMOKE=1 pnpm vitest run --pool=threads test/kuaishou-real.smoke.test.ts` 时执行。
 * 成功 / 明确的 rate_limited / empty 都算通道工作正常。
 */
describe.skipIf(process.env.DSH_SMOKE !== "1")("快手评论通道真实冒烟（bsk + 浏览器）", () => {
  it(
    "真实会话：视频页（分享链接）→ 评论 API",
    async () => {
      const pool = new BrowserSessionPool("bsk", 120_000, 1, { autoLaunchChrome: false });
      const pacer = new PlatformPacer();
      const exec = {
        signal: new AbortController().signal,
        agent: { session: { header: { cwd: process.cwd() } } },
      } as never;
      try {
        const url = process.env.KUAISHOU_URL || "https://www.kuaishou.com/short-video/3xb2p974yf35c2k";
        const outcome = await collectKuaishouComments({ pool, pacer }, exec, url, {
          maxComments: 50,
          maxRepliesPerComment: 3,
        });
        console.log(
          "SMOKE:",
          JSON.stringify({
            ok: outcome.ok,
            reason: outcome.reason,
            count: outcome.comments.length,
            withReplies: outcome.comments.filter((c) => c.replies.length > 0).length,
            first: outcome.comments[0]
              ? { author: outcome.comments[0].author, content: outcome.comments[0].content.slice(0, 60) }
              : null,
            error: outcome.error ?? "",
          }),
        );
        expect(outcome.ok || ["rate_limited", "empty"].includes(outcome.reason)).toBe(true);
        if (outcome.ok && outcome.comments.length > 0) {
          expect(outcome.comments[0].content.length).toBeGreaterThan(0);
        }
      } finally {
        await pool.dispose();
      }
    },
    180_000,
  );
});
