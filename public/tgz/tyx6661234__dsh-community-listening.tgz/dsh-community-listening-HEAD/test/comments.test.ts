import { describe, expect, it } from "vitest";
import { aggregateSentiment, denoiseComments, sentiment } from "../src/comments";

const c = (content: string) => ({ author: "u", content, replies: [] });

describe("denoiseComments", () => {
  it("剔除噪音短语/超短/重复", () => {
    const { kept, dropped } = denoiseComments([
      c("求拉"),
      c("好"),
      c("这家公司加班确实多，建议慎重"),
      c("这家公司加班确实多，建议慎重"),
      c("蹲一个后续"),
      c("真实面试两轮，算法题为主"),
    ]);
    expect(dropped).toBe(4);
    expect(kept).toHaveLength(2);
    expect(kept[0].content).toContain("加班确实多");
  });
});

describe("sentiment", () => {
  it("正/负/中分桶", () => {
    expect(sentiment("很不错，推荐，满意")).toBe("positive");
    expect(sentiment("太坑了，劝退，加班严重")).toBe("negative");
    expect(sentiment("普通的一天")).toBe("neutral");
  });
});

describe("aggregateSentiment", () => {
  it("统计分桶与差评 Top", () => {
    const buckets = aggregateSentiment([
      c("不错，推荐"),
      c("加班太狠，裁员风险"),
      c("还行吧"),
      c("很坑"),
    ]);
    expect(buckets.positive).toBe(1);
    expect(buckets.negative).toBe(2);
    expect(buckets.neutral).toBe(1);
    expect(buckets.topNegative).toHaveLength(2);
  });
});
