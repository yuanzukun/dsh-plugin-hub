import { describe, expect, it } from "vitest";
import { BrowserSessionPool } from "../src/collect";
import { PlatformPacer } from "../src/pacing";
import { collectDouyinComments, collectDouyinSearch, collectDouyinUserWorks } from "../src/sources/douyin";

/**
 * 抖音评论通道真实冒烟：需 bsk + 浏览器（抖音页面自动带 cookie，评论 API 免签名）。
 * 默认跳过；`DSH_SMOKE=1 pnpm vitest run --pool=threads test/douyin-real.smoke.test.ts` 时执行。
 * 成功 / 明确的 rate_limited / empty 都算通道工作正常。
 */
describe.skipIf(process.env.DSH_SMOKE !== "1")("抖音评论通道真实冒烟（bsk + 浏览器）", () => {
  it(
    "真实会话：视频页 → 评论 API（cursor 分页 + 子评论）",
    async () => {
      const pool = new BrowserSessionPool("bsk", 120_000, 1, { autoLaunchChrome: false });
      const pacer = new PlatformPacer();
      const exec = {
        signal: new AbortController().signal,
        agent: { session: { header: { cwd: process.cwd() } } },
      } as never;
      try {
        const awemeId = process.env.DOUYIN_AWEME_ID || "7643084980406983089";
        const outcome = await collectDouyinComments({ pool, pacer }, exec, awemeId, {
          maxComments: 60,
          maxRepliesPerComment: 3,
        });
        console.log(
          "SMOKE:",
          JSON.stringify({
            ok: outcome.ok,
            reason: outcome.reason,
            count: outcome.comments.length,
            withReplies: outcome.comments.filter((c) => c.replies.length > 0).length,
            first: outcome.comments[0]
              ? { author: outcome.comments[0].author, content: outcome.comments[0].content.slice(0, 60) }
              : null,
            error: outcome.error ?? "",
          }),
        );
        expect(outcome.ok || ["rate_limited", "empty"].includes(outcome.reason)).toBe(true);
        if (outcome.ok && outcome.comments.length > 0) {
          expect(outcome.comments[0].content.length).toBeGreaterThan(0);
        }
      } finally {
        await pool.dispose();
      }
    },
    180_000,
  );

  it(
    "真实会话：搜索页 → 搜索 API（免签名，结构化卡片）",
    async () => {
      const pool = new BrowserSessionPool("bsk", 120_000, 1, { autoLaunchChrome: false });
      const pacer = new PlatformPacer();
      const exec = {
        signal: new AbortController().signal,
        agent: { session: { header: { cwd: process.cwd() } } },
      } as never;
      try {
        const outcome = await collectDouyinSearch({ pool, pacer }, exec, process.env.DOUYIN_SEARCH_KEYWORD || "数据分析", {
          limit: 5,
        });
        console.log(
          "SMOKE:",
          JSON.stringify({
            ok: outcome.ok,
            reason: outcome.reason,
            backend: outcome.backend ?? "",
            count: outcome.cards.length,
            first: outcome.cards[0] ? { awemeId: outcome.cards[0].awemeId, title: outcome.cards[0].title.slice(0, 40) } : null,
            error: outcome.error ?? "",
          }),
        );
        expect(outcome.ok || ["rate_limited", "empty"].includes(outcome.reason)).toBe(true);
        if (outcome.ok && outcome.cards.length > 0) {
          expect(outcome.cards[0].awemeId).toMatch(/^\d{15,}$/);
        }
      } finally {
        await pool.dispose();
      }
    },
    180_000,
  );

  it(
    "真实会话：用户主页 → 用户作品 API（max_cursor 分页）",
    async () => {
      const pool = new BrowserSessionPool("bsk", 120_000, 1, { autoLaunchChrome: false });
      const pacer = new PlatformPacer();
      const exec = {
        signal: new AbortController().signal,
        agent: { session: { header: { cwd: process.cwd() } } },
      } as never;
      try {
        const secUid = process.env.DOUYIN_SEC_UID || "MS4wLjABAAAAJdtSPYx6iNkUyyI2PWLe3JXcfBaESLTVc0Vhyk8zE_4";
        const outcome = await collectDouyinUserWorks({ pool, pacer }, exec, `https://www.douyin.com/user/${secUid}`, {
          limit: 5,
        });
        console.log(
          "SMOKE:",
          JSON.stringify({
            ok: outcome.ok,
            reason: outcome.reason,
            count: outcome.cards.length,
            first: outcome.cards[0] ? { awemeId: outcome.cards[0].awemeId, title: outcome.cards[0].title.slice(0, 40) } : null,
            error: outcome.error ?? "",
          }),
        );
        expect(outcome.ok || ["rate_limited", "empty"].includes(outcome.reason)).toBe(true);
        if (outcome.ok && outcome.cards.length > 0) {
          expect(outcome.cards[0].awemeId).toMatch(/^\d{15,}$/);
        }
      } finally {
        await pool.dispose();
      }
    },
    180_000,
  );

});
