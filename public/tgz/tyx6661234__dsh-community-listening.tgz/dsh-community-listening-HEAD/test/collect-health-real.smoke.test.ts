import { describe, expect, it } from "vitest";
import { BrowserSessionPool, collectComments } from "../src/collect";
import { CrawlerHealth } from "../src/health";
import { PlatformPacer } from "../src/pacing";

/**
 * 通道链 + 健康记录真实冒烟：默认跳过；
 * `DSH_SMOKE=1 pnpm vitest run --pool=threads test/collect-health-real.smoke.test.ts` 时执行。
 * 只验证：成功路径返回 backend 元数据，并且 CrawlerHealth 有对应记录。
 */
describe.skipIf(process.env.DSH_SMOKE !== "1")("collectComments 通道链/健康记录真实冒烟", () => {
  it(
    "B 站视频：主通道或浏览器兜底成功后写入健康记录",
    async () => {
      const pool = new BrowserSessionPool("bsk", 120_000, 1, { autoLaunchChrome: false });
      const pacer = new PlatformPacer();
      const health = new CrawlerHealth();
      const exec = {
        signal: new AbortController().signal,
        agent: { session: { header: { cwd: process.cwd() } } },
      } as never;
      try {
        const result = await collectComments(
          {
            ctx: { get: () => undefined } as never,
            bskPath: "bsk",
            bskTimeoutMs: 120_000,
            cheap: undefined as never,
            pacer,
            health,
          },
          pool,
          {
            url: process.env.BILIBILI_SMOKE_URL || "https://www.bilibili.com/video/BV1DogW6mEiq",
            maxExpand: 2,
            exec,
          },
        );
        console.log(
          "SMOKE collectComments:",
          JSON.stringify({
            ok: !result.error,
            count: result.comments.length,
            backend: result.backend,
            fallbacks: result.fallbacks,
            degraded: result.degraded,
            strategy: result.strategy,
            error: result.error ?? "",
          }),
        );
        expect(result.backend).toBeTruthy();
        expect(result.error ?? "").toBe("");
        expect(result.comments.length).toBeGreaterThan(0);

        const record = health.recordFor("bilibili", "comments");
        expect(record).toBeTruthy();
        expect(record!.backend).toBe(result.backend);
      } finally {
        await pool.dispose();
      }
    },
    180_000,
  );
});
