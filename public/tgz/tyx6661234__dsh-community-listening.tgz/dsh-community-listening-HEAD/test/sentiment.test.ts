import { describe, expect, it } from "vitest";
import {
  aggregateSentiment,
  isAmbiguous,
  mineSentiment,
  scoreSentiment,
  type MinedItem,
} from "../src/mining/sentiment";

describe("scoreSentiment 词典+规则", () => {
  it("基本正/负/中", () => {
    expect(scoreSentiment("很不错，推荐，满意").polarity).toBe("positive");
    expect(scoreSentiment("太坑了，劝退，加班严重").polarity).toBe("negative");
    expect(scoreSentiment("普通的一天")).toBeTruthy();
    expect(scoreSentiment("普通的一天").polarity).toBe("neutral");
  });

  it("否定词翻转极性", () => {
    // 「不好」= 负；「不满意」= 负
    expect(scoreSentiment("这家店不好").polarity).toBe("negative");
    expect(scoreSentiment("体验不满意").polarity).toBe("negative");
    // 双否定口语「没毛病」→ 正
    expect(scoreSentiment("这家店没毛病").polarity).toBe("positive");
  });

  it("程度副词放大", () => {
    const mild = scoreSentiment("有点失望");
    const strong = scoreSentiment("非常失望");
    expect(mild.score).toBeGreaterThan(-1);
    expect(strong.score).toBeLessThan(mild.score);
    expect(mild.polarity).toBe("negative");
    expect(strong.polarity).toBe("negative");
  });

  it("转折后段主导", () => {
    // 「不错但是太贵」→ 负向主导
    expect(scoreSentiment("东西不错，但是太贵了").polarity).toBe("negative");
  });

  it("感叹号微调不翻转极性", () => {
    const plain = scoreSentiment("很差");
    const exclaim = scoreSentiment("很差！！！");
    expect(exclaim.score).toBeLessThan(plain.score);
  });
});

describe("isAmbiguous 低置信/反讽", () => {
  it("低分与反讽标记触发校准候选", () => {
    expect(isAmbiguous({ polarity: "neutral", score: 0.05, positiveHits: 0, negativeHits: 0 }, "还行吧")).toBe(true);
    expect(isAmbiguous({ polarity: "positive", score: 0.9, positiveHits: 2, negativeHits: 0 }, "呵呵，真棒")).toBe(true);
    expect(isAmbiguous({ polarity: "negative", score: -0.8, positiveHits: 0, negativeHits: 2 }, "太垃圾了")).toBe(false);
  });
});

describe("mineSentiment + aggregateSentiment", () => {
  it("无 LLM（cheap 不可用）时纯词典分桶", async () => {
    const items = [
      { id: "1", text: "不错，推荐" },
      { id: "2", text: "加班太狠，裁员风险" },
      { id: "3", text: "还行吧" },
      { id: "4", text: "很坑" },
    ];
    const { items: mined, aggregate } = await mineSentiment(items, undefined, { calibrate: true });
    expect(mined).toHaveLength(4);
    expect(aggregate.positive).toBe(1);
    expect(aggregate.negative).toBe(2);
    expect(aggregate.neutral).toBe(1);
    expect(aggregate.topNegative).toHaveLength(2);
    expect(aggregate.degraded).toBe(false);
    // 未配置通道时给出明确说明（不再是静默跳过）
    expect(aggregate.calibrationNote).toContain("未配置");
  });

  it("calibrate=false 时说明已关闭校准", async () => {
    const items = [{ id: "1", text: "还行吧" }];
    const { aggregate } = await mineSentiment(items, undefined, { calibrate: false });
    expect(aggregate.calibrationNote).toContain("已关闭");
  });

  it("aggregateSentiment 计算平均分与 Top 列表", () => {
    const mined: MinedItem[] = [
      { id: "a", text: "很差很差", polarity: "negative", score: -0.9 },
      { id: "b", text: "很好", polarity: "positive", score: 0.8 },
      { id: "c", text: "普通", polarity: "neutral", score: 0 },
    ];
    const agg = aggregateSentiment(mined);
    expect(agg.avgScore).toBeCloseTo(-0.03, 1);
    expect(agg.topNegative[0].text).toBe("很差很差");
    expect(agg.topPositive[0].text).toBe("很好");
  });

  it("Top 列表不含 undefined 值（lossless JSON 兼容；trust 缺省时不写字段）", () => {
    const mined: MinedItem[] = [
      { id: "a", text: "很差", polarity: "negative", score: -0.8 },
      { id: "b", text: "很好", polarity: "positive", score: 0.9, trust: "B" },
    ];
    const agg = aggregateSentiment(mined);
    const all = [...agg.topNegative, ...agg.topPositive];
    expect(all.length).toBeGreaterThan(0);
    for (const item of all) {
      for (const v of Object.values(item)) {
        expect(v).not.toBeUndefined();
      }
    }
    // trust 有值才写入
    expect("trust" in agg.topNegative[0]).toBe(false);
    expect(agg.topPositive[0].trust).toBe("B");
  });
});
