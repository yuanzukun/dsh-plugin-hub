import { describe, expect, it } from "vitest";
import {
  buildWeiboCommentsScript,
  buildWeiboSearchScript,
  extractWeiboMid,
  parseWeiboComments,
  parseWeiboSearch,
} from "../src/sources/weibo";

describe("extractWeiboMid", () => {
  it("识别 m.weibo.cn/detail/{mid}", () => {
    expect(extractWeiboMid("https://m.weibo.cn/detail/5331196709702293")).toBe("5331196709702293");
    expect(extractWeiboMid("https://m.weibo.cn/detail/5331196709702293?x=1")).toBe("5331196709702293");
  });

  it("非微博详情 / 非法返回 null", () => {
    expect(extractWeiboMid("https://example.com/detail/123")).toBeNull();
    expect(extractWeiboMid("https://m.weibo.cn/search?containerid=100103type%3D1")).toBeNull(); // 搜索页不是详情
    expect(extractWeiboMid("not a url")).toBeNull();
  });
});

describe("buildWeiboSearchScript / buildWeiboCommentsScript", () => {
  it("搜索脚本指向 container/getIndex + 关键词注入", () => {
    const script = buildWeiboSearchScript("大厂", 1);
    expect(script).toContain("/api/container/getIndex");
    expect(script).toContain("100103type%3D1%26q%3D");
    expect(script).toContain('credentials: "include"');
    expect(script).toContain("c.mblog"); // 从 cards 取 mblog
  });

  it("评论脚本指向 comments/hotflow + max_id 分页", () => {
    const s1 = buildWeiboCommentsScript("5331196709702293", 0);
    expect(s1).toContain("https://m.weibo.cn/comments/hotflow?id=5331196709702293&mid=5331196709702293&max_id_type=0");
    expect(s1).toContain("referer: \"https://m.weibo.cn/detail/5331196709702293\"");
    const s2 = buildWeiboCommentsScript("5331196709702293", 12345);
    expect(s2).toContain("&max_id=12345");
  });
});

describe("parseWeiboSearch", () => {
  it("归一化帖子（含字段）", () => {
    const parsed = parseWeiboSearch({
      ok: true,
      items: [
        {
          id: "5331196709702293",
          bid: "Nxxxxxxxx",
          url: "https://weibo.com/123/abc",
          author: "测试用户",
          text: "微博正文内容",
          createdAt: "2026-08-15",
          likeCount: 1411,
          commentCount: 25,
          repostCount: 3,
        },
        { id: "", text: "x" }, // 无 id 过滤
        null,
      ],
    });
    expect(parsed.ok).toBe(true);
    expect(parsed.items).toHaveLength(1);
    expect(parsed.items[0]).toEqual({
      id: "5331196709702293",
      bid: "Nxxxxxxxx",
      url: "https://weibo.com/123/abc",
      author: "测试用户",
      text: "微博正文内容",
      createdAt: "2026-08-15",
      likeCount: 1411,
      commentCount: 25,
      repostCount: 3,
    });
  });

  it("错误负载", () => {
    expect(parseWeiboSearch({ ok: false, apiOk: 0, msg: "432" }).ok).toBe(false);
    expect(parseWeiboSearch(null).ok).toBe(false);
  });
});

describe("parseWeiboComments", () => {
  it("归一化评论（含子评论）", () => {
    const parsed = parseWeiboComments({
      ok: true,
      items: [
        { author: "用户A", content: "第一条评论", replies: ["回复1", "回复2"] },
        { author: "用户B", content: "" }, // 空内容过滤
      ],
      hasMore: true,
      maxId: 999,
    });
    expect(parsed.ok).toBe(true);
    expect(parsed.items).toHaveLength(1);
    expect(parsed.items[0]).toEqual({ author: "用户A", content: "第一条评论", replies: ["回复1", "回复2"] });
    expect(parsed.hasMore).toBe(true);
    expect(parsed.maxId).toBe(999);
  });

  it("错误负载", () => {
    expect(parseWeiboComments({ ok: false, error: "boom" }).ok).toBe(false);
    expect(parseWeiboComments(null).items).toHaveLength(0);
  });
});
