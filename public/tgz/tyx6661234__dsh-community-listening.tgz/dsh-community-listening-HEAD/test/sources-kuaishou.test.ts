import { describe, expect, it } from "vitest";
import {
  buildKuaishouCommentsScript,
  buildKuaishouSearchExtractScript,
  buildKuaishouSearchUrl,
  extractPhotoId,
  parseKuaishouComments,
  parseKuaishouSearchCards,
} from "../src/sources/kuaishou";

describe("extractPhotoId", () => {
  it("识别 short-video/{id} 与 /f/{id}", () => {
    expect(extractPhotoId("https://www.kuaishou.com/short-video/3xb2p974yf35c2k")).toBe("3xb2p974yf35c2k");
    expect(extractPhotoId("https://www.kuaishou.com/short-video/3xb2p974yf35c2k?cc=share_copylink")).toBe("3xb2p974yf35c2k");
    expect(extractPhotoId("https://www.kuaishou.com/f/X-8dHF9SInRxs1WN")).toBe("X-8dHF9SInRxs1WN");
  });

  it("非快手 / 非法返回 null", () => {
    expect(extractPhotoId("https://example.com/short-video/abc")).toBeNull();
    expect(extractPhotoId("https://www.kuaishou.com/new-reco")).toBeNull();
    expect(extractPhotoId("not a url")).toBeNull();
  });
});

describe("buildKuaishouCommentsScript", () => {
  it("POST /rest/v/photo/comment/list + pcursor", () => {
    const s1 = buildKuaishouCommentsScript("3xb2p974yf35c2k", "");
    expect(s1).toContain("/rest/v/photo/comment/list");
    expect(s1).toContain('photoId: "3xb2p974yf35c2k"');
    expect(s1).toContain('pcursor: ""');
    const s2 = buildKuaishouCommentsScript("3xb2p974yf35c2k", "abc123");
    expect(s2).toContain('pcursor: "abc123"');
  });
});

describe("parseKuaishouComments", () => {
  it("归一化评论（author/content/likeCount/hasSubComments）", () => {
    const parsed = parseKuaishouComments({
      ok: true,
      items: [
        { commentId: "c1", author: "用户A", content: "第一条评论", likeCount: 10, hasSubComments: true },
        { commentId: "c2", content: "" }, // 空内容过滤
        null,
      ],
      pcursor: "abc",
      total: 5,
    });
    expect(parsed.ok).toBe(true);
    expect(parsed.items).toHaveLength(1);
    expect(parsed.items[0]).toEqual({ commentId: "c1", author: "用户A", content: "第一条评论", likeCount: 10, hasSubComments: true });
    expect(parsed.pcursor).toBe("abc");
    expect(parsed.total).toBe(5);
  });

  it("错误负载", () => {
    expect(parseKuaishouComments({ ok: false, result: 2 }).ok).toBe(false);
    expect(parseKuaishouComments({ ok: false, result: 50 }).result).toBe(50);
    expect(parseKuaishouComments(null).items).toHaveLength(0);
  });
});

describe("kuaishou search discovery", () => {
  it("搜索 URL 编码", () => {
    expect(buildKuaishouSearchUrl("应用统计就业")).toBe(
      "https://www.kuaishou.com/search/video?searchKey=%E5%BA%94%E7%94%A8%E7%BB%9F%E8%AE%A1%E5%B0%B1%E4%B8%9A",
    );
  });

  it("解析 INIT_STATE 脚本返回的卡片（photo.id → short-video URL）", () => {
    const cards = parseKuaishouSearchCards({
      ok: true,
      count: 2,
      cards: [
        { photoId: "3xdmvnamn74nggm", title: "家长你真NB", author: "研途", likeCount: 2965, viewCount: 311147 },
        { photoId: "", title: "空id应被过滤", author: "x", likeCount: 1, viewCount: 1 },
      ],
    });
    expect(cards).toHaveLength(1);
    expect(cards[0]).toEqual({
      photoId: "3xdmvnamn74nggm",
      url: "https://www.kuaishou.com/short-video/3xdmvnamn74nggm",
      title: "家长你真NB",
      author: "研途",
      likeCount: 2965,
      viewCount: 311147,
    });
  });

  it("提取脚本含 INIT_STATE 与 DOM clientCacheKey 兜底", () => {
    const script = buildKuaishouSearchExtractScript();
    expect(script).toContain("INIT_STATE");
    expect(script).toContain("clientCacheKey");
    expect(script).toContain("short-video/");
  });
});
