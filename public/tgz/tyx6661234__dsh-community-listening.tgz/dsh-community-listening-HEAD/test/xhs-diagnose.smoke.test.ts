import { describe, expect, it } from "vitest";
import { BrowserSessionPool } from "../src/collect";
import { PlatformPacer } from "../src/pacing";
import { collectXiaohongshuSearch } from "../src/sources/xiaohongshu";

/**
 * 小红书登录态 + token 命中率诊断冒烟（2026-08-15 复盘验证）：
 * 用新代码（sessionUser 真实信号 + Pass A/B 双路 token harvest）跑一轮真实搜索，
 * 输出完整诊断，用于区分：
 *   A. sessionUser=true 且 tokenHitRate 显著提升 → 旧版 harvest 漏挖（已修复）
 *   B. sessionUser=true 且 tokenHitRate 仍低 → 服务端对自动化请求指纹降权（换号无效，只能降频/错峰/换词）
 *   C. sessionUser=false 且 loginWallText=true → 自动化会话确未带登录态（需在 Agent Window 内登录）
 * 运行：DSH_SMOKE=1 pnpm vitest run --pool=threads test/xhs-diagnose.smoke.test.ts
 * 注意：会真实访问小红书搜索页一次（单次访问、不滚动不点击）；需 bsk daemon 与 Chrome（默认 profile）。
 */
describe.skipIf(process.env.DSH_SMOKE !== "1")("小红书登录态+token 诊断冒烟（新代码）", () => {
  it(
    "单轮单搜：输出 sessionUser / tokenHitRate / biasHint",
    async () => {
      const bskPath = process.env.BSK_PATH || "C:\\Users\\tyx\\.local\\bin\\bsk.exe";
      const pool = new BrowserSessionPool(bskPath, 120_000, 1, { autoLaunchChrome: true });
      const pacer = new PlatformPacer();
      const exec = {
        signal: new AbortController().signal,
        agent: { session: { header: { cwd: process.cwd() } } },
      } as never;
      try {
        const outcome = await collectXiaohongshuSearch(
          { pool, pacer },
          exec,
          process.env.XHS_KEYWORD || "机械键盘",
          { limit: 20 },
        );
        console.log(
          "XHS_DIAG:",
          JSON.stringify(
            {
              ok: outcome.ok,
              reason: outcome.reason,
              error: outcome.error ?? "",
              loginState: outcome.loginState ?? null,
              cardCount: outcome.cards.length,
              cardsWithToken: outcome.cardsWithToken,
              tokenHitRate: outcome.tokenHitRate,
              biasHint: outcome.biasHint ?? "",
              tokens: outcome.cards
                .filter((c) => c.xsecToken)
                .map((c) => ({ noteId: c.noteId, tokenLen: c.xsecToken!.length })),
            },
            null,
            2,
          ),
        );
        expect(outcome.ok || ["rate_limited", "login_wall"].includes(outcome.reason)).toBe(true);
      } finally {
        await pool.dispose();
      }
    },
    180_000,
  );
});
