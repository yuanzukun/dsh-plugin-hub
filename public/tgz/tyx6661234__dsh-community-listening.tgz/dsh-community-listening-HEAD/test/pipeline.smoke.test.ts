/**
 * v2 管道冒烟（默认跳过；SMOKE=1 运行）：
 *   采集落盘 → 评论情感（真实 cheap LLM 校准）→ 文章主题聚类（真实 bge-m3 embedding，
 *   失败自动回退关键词）→ 近似去重 → 报告导出。
 * 容错断言：通道不可用时验证结构 + degraded 标记，不依赖具体 API 成功。
 */
import { describe, expect, it } from "vitest";
import { existsSync, mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { appendEntries, corpusStats, loadEntries, makeEntry, saveReport } from "../src/corpus";
import { loadCheapLlm } from "../src/llm";
import { loadEmbeddingConfig, embedTexts } from "../src/mining/embed";
import { mineSentiment } from "../src/mining/sentiment";
import { dedupeSimilar } from "../src/mining/simhash";
import { clusterTopics } from "../src/mining/topics";

const ENABLED = process.env.SMOKE === "1";
const ENV_PATH = process.env.INSIGHT_ENV_PATH ?? "D:\\agentdev\\insigtai\\.env";

describe.skipIf(!ENABLED)("smoke: v2 管道", { timeout: 180_000 }, () => {
  it("采集落盘 → 情感/聚类/去重 → 报告导出全链路", async () => {
    const root = mkdtempSync(join(tmpdir(), "dsh-community-listening-pipeline-"));
    const topic = "烟测主题";

    const articles = [
      makeEntry({ topic, kind: "article", url: "https://a.com/1", text: "字节后端校招面经：算法题为主，两轮技术面一轮 HR，重点考察操作系统与网络。", strategy: "fetch", trust: "B" }),
      makeEntry({ topic, kind: "article", url: "https://a.com/2", text: "字节后端校招面经（转载）：算法题为主，两轮技术面一轮 HR，重点考察操作系统与网络。", strategy: "fetch", trust: "B" }),
      makeEntry({ topic, kind: "article", url: "https://b.com/3", text: "这家酒店位置很好，服务不错，早餐丰富，性价比高，值得推荐。", strategy: "browser", trust: "B" }),
      makeEntry({ topic, kind: "article", url: "https://b.com/4", text: "酒店避雷：隔音差、前台冷漠、早餐难吃，强烈不推荐。", strategy: "browser", trust: "C" }),
      makeEntry({ topic, kind: "article", url: "https://c.com/5", text: "量子计算在金融风控领域的应用前景与挑战分析报告。", strategy: "fetch", trust: "A" }),
      makeEntry({ topic, kind: "article", url: "https://c.com/6", text: "量子计算在金融风控领域的应用前景与挑战分析报告（转载自某媒体）。", strategy: "fetch", trust: "A" }),
    ];
    const comments = [
      makeEntry({ topic, kind: "comment", url: "https://a.com/1", text: "这家公司加班确实多，但福利不错", trust: "B" }),
      makeEntry({ topic, kind: "comment", url: "https://a.com/1", text: "面试体验很好，面试官很专业", trust: "B" }),
      makeEntry({ topic, kind: "comment", url: "https://b.com/3", text: "酒店隔音太差了，晚上很吵", trust: "C" }),
      makeEntry({ topic, kind: "comment", url: "https://b.com/3", text: "早餐丰富，位置便利，总体满意", trust: "B" }),
      makeEntry({ topic, kind: "comment", url: "https://b.com/4", text: "很坑，避雷，千万别订", trust: "C" }),
      makeEntry({ topic, kind: "comment", url: "https://c.com/5", text: "普通内容，没什么特别", trust: "B" }),
    ];
    const res = appendEntries(root, topic, [...articles, ...comments]);
    expect(res.saved).toBe(12);
    expect(loadEntries(root, topic)).toHaveLength(12);

    // ---- 评论情感（真实 cheap LLM 校准，容错） ----
    const cheap = loadCheapLlm(ENV_PATH);
    const sentiment = await mineSentiment(
      loadEntries(root, topic)
        .filter((e) => e.kind === "comment")
        .map((e) => ({ id: e.id, text: e.text, trust: e.trust })),
      cheap,
      { calibrate: true, maxCalibrate: 6 },
    );
    const { positive, negative, neutral, total } = sentiment.aggregate;
    expect(total).toBe(6);
    expect(positive + negative + neutral).toBe(6);
    expect(negative).toBeGreaterThanOrEqual(2);
    expect(sentiment.aggregate.topNegative.length).toBeGreaterThan(0);

    // ---- 文章主题聚类（真实 embedding；失败回退关键词） ----
    const embedCfg = loadEmbeddingConfig(ENV_PATH);
    const articleItems = loadEntries(root, topic)
      .filter((e) => e.kind === "article")
      .map((e) => ({ id: e.id, text: e.text, url: e.url, source: e.source }));
    let embed = null;
    if (embedCfg.apiKey) embed = await embedTexts(embedCfg, articleItems.map((i) => i.text), undefined);
    const topics = await clusterTopics(articleItems, cheap, { k: 3, embed });
    expect(topics.total).toBe(6);
    expect(topics.topics.length).toBeGreaterThanOrEqual(2);
    expect(topics.topics.reduce((s, t) => s + t.size, 0)).toBe(6);
    if (embedCfg.apiKey && embed) {
      expect(topics.method).toBe("embedding");
      expect(topics.embeddingAvailable).toBe(true);
    } else {
      expect(topics.method).toBe("keyword");
      expect(topics.degraded).toBe(true);
    }

    // ---- 近似去重 ----
    const dedupe = dedupeSimilar(articleItems);
    expect(dedupe.total).toBe(6);
    expect(dedupe.duplicateCount).toBeGreaterThanOrEqual(2); // 面经×2、量子×2 近似
    expect(dedupe.clusterCount).toBeLessThanOrEqual(5);

    // ---- 报告导出 + 覆盖保护 ----
    const report = `# 烟测报告\n\n- 评论 ${total} 条（正 ${positive}/负 ${negative}/中 ${neutral}）\n- 文章主题 ${topics.topics.length} 个\n- 去重后独立 ${dedupe.clusterCount} 簇\n`;
    const saved = saveReport(root, topic, report, false);
    expect(existsSync(saved.path)).toBe(true);
    expect(readFileSync(saved.path, "utf8")).toContain("烟测报告");
    expect(() => saveReport(root, topic, "again", false)).toThrow(/已存在/);

    const stats = corpusStats(root, topic);
    expect(stats.total).toBe(12);
    expect(stats.byKind).toEqual({ article: 6, comment: 6 });

    rmSync(root, { recursive: true, force: true });
  });
});
