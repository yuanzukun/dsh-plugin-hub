import { describe, expect, it } from "vitest";
import {
  buildTiebaCommentsScript,
  extractTiebaTid,
  parseTiebaComments,
} from "../src/sources/tieba";

describe("extractTiebaTid", () => {
  it("识别 /p/{tid}", () => {
    expect(extractTiebaTid("https://tieba.baidu.com/p/10885405530")).toBe("10885405530");
    expect(extractTiebaTid("https://tieba.baidu.com/p/10885405530?fr=frs")).toBe("10885405530");
    expect(extractTiebaTid("https://tieba.baidu.com/p/7216163538?share=9105")).toBe("7216163538");
  });

  it("非贴吧帖子 / 非法返回 null", () => {
    expect(extractTiebaTid("https://tieba.baidu.com/f?kw=%E7%A8%8B%E5%BA%8F%E5%91%98")).toBeNull();
    expect(extractTiebaTid("https://example.com/p/123")).toBeNull();
    expect(extractTiebaTid("not a url")).toBeNull();
  });
});

describe("buildTiebaCommentsScript", () => {
  it("DOM 提取 .pb-comment-item / name-info-link / pb-rich-text / lzl-wrapper", () => {
    const script = buildTiebaCommentsScript();
    expect(script).toContain("pb-comment-item");
    expect(script).toContain("name-info-link");
    expect(script).toContain("pb-rich-text");
    expect(script).toContain("lzl-wrapper");
  });
});

describe("parseTiebaComments", () => {
  it("归一化回复（author/content/replies）", () => {
    const parsed = parseTiebaComments({
      ok: true,
      items: [
        { author: "接小程序网页软件开发", content: "黑灰app?", replies: ["即时通讯", "可以做啊"] },
        { author: "x", content: "" }, // 空内容过滤
        null,
      ],
    });
    expect(parsed.ok).toBe(true);
    expect(parsed.items).toHaveLength(1);
    expect(parsed.items[0]).toEqual({
      author: "接小程序网页软件开发",
      content: "黑灰app?",
      replies: ["即时通讯", "可以做啊"],
    });
  });

  it("错误负载", () => {
    expect(parseTiebaComments({ ok: false, error: "boom" }).ok).toBe(false);
    expect(parseTiebaComments(null).items).toHaveLength(0);
  });
});
