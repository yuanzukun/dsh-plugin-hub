import { describe, expect, it } from "vitest";
import { BrowserSessionPool } from "../src/collect";
import { PlatformPacer } from "../src/pacing";
import { collectXiaohongshuSearch } from "../src/sources/xiaohongshu";

/**
 * 小红书搜索采集真实冒烟：需要 bsk daemon + 浏览器连接。
 * 默认跳过；`DSH_SMOKE=1 pnpm vitest run --pool=threads test/xiaohongshu-real.smoke.test.ts` 时执行。
 * 注意：小红书风控极严，频繁运行可能触发安全验证（返回 rate_limited 也算有效结果）。
 */
describe.skipIf(process.env.DSH_SMOKE !== "1")("小红书搜索采集真实冒烟（bsk + 浏览器）", () => {
  it(
    "真实会话：搜索「机械键盘」→ 卡片采集（或风控识别）",
    async () => {
      const pool = new BrowserSessionPool("bsk", 120_000, 1, { autoLaunchChrome: false });
      const pacer = new PlatformPacer();
      const exec = {
        signal: new AbortController().signal,
        agent: { session: { header: { cwd: process.cwd() } } },
      } as never;
      try {
        const outcome = await collectXiaohongshuSearch(
          { pool, pacer },
          exec,
          "机械键盘",
          { limit: 20 },
        );
        console.log(
          "SMOKE:",
          JSON.stringify({
            ok: outcome.ok,
            reason: outcome.reason,
            cardCount: outcome.cards.length,
            first: outcome.cards[0]
              ? { title: outcome.cards[0].title, author: outcome.cards[0].author, like: outcome.cards[0].likeCount }
              : null,
            error: outcome.error ?? "",
          }),
        );
        // 成功拿卡片 或 明确的风控/登录墙状态 都算通道工作正常
        expect(outcome.ok || ["rate_limited", "login_wall"].includes(outcome.reason)).toBe(true);
      } finally {
        await pool.dispose();
      }
    },
    120_000,
  );
});
