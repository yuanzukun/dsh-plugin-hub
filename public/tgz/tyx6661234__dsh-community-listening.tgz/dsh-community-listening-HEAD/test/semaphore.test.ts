import { describe, expect, it } from "vitest";
import { AbortableWaitQueue, Semaphore } from "../src/collect";

/**
 * Bug 4 回归：Semaphore / 会话池等待队列的取消延迟。
 * 旧实现等待者只在被 release/signal 唤醒后才检查 signal.aborted，且 abort 不移出队列：
 * 取消最多延迟到下一次释放，还可能造成一次空唤醒。AbortableWaitQueue 让 abort 立即
 * 出队并唤醒；被 release 唤醒后发现已 abort 的场景抛错但不清点数（许可留给下一个 acquire）。
 */
describe("AbortableWaitQueue", () => {
  it("abort 立即出队并唤醒（不等 signal）", async () => {
    const queue = new AbortableWaitQueue();
    const controller = new AbortController();
    const waited = queue.wait(controller.signal);
    expect(queue.size).toBe(1);
    controller.abort();
    await waited; // 立即 resolve，不需要 signal()
    expect(queue.size).toBe(0); // 已出队
  });

  it("signal 只唤醒存活等待者（已 abort 的不再被空唤醒）", async () => {
    const queue = new AbortableWaitQueue();
    const controller = new AbortController();
    const aborted = queue.wait(controller.signal);
    controller.abort();
    await aborted;
    expect(queue.size).toBe(0);

    // 后续 signal() 不抛错、不唤醒任何东西（无空唤醒）
    queue.signal();
    expect(queue.size).toBe(0);
  });

  it("已 abort 的 signal 直接 resolve", async () => {
    const controller = new AbortController();
    controller.abort();
    const queue = new AbortableWaitQueue();
    await queue.wait(controller.signal); // 不挂起
  });
});

describe("Semaphore（abort 语义）", () => {
  it("limit=1：A 持有、B abort 后 ~100ms 内立即 reject（不等 A 释放）", async () => {
    const sem = new Semaphore(1);
    await sem.acquire(); // A 持有

    const controller = new AbortController();
    const bPromise = sem.acquire(controller.signal);
    setTimeout(() => controller.abort(), 30);

    const t0 = Date.now();
    await expect(bPromise).rejects.toThrow("浏览器采集被取消");
    expect(Date.now() - t0).toBeLessThan(150);

    sem.release(); // A 释放（清理）
  });

  it("B abort 后 A release，C 立即 acquire 成功（无许可丢失、无空唤醒挂死）", async () => {
    const sem = new Semaphore(1);
    await sem.acquire(); // A 持有

    const bController = new AbortController();
    const bPromise = sem.acquire(bController.signal);
    const cPromise = sem.acquire(); // C 排队在 B 之后

    bController.abort();
    await expect(bPromise).rejects.toThrow("浏览器采集被取消");

    // A 释放 → 唤醒 C（B 已出队，不会空唤醒 B）
    sem.release();
    await cPromise; // C 立即拿到许可
    sem.release(); // 清理 C 的持有
  });

  it("传入已 abort 的 signal → 立即 reject", async () => {
    const sem = new Semaphore(1);
    await sem.acquire(); // 占满

    const controller = new AbortController();
    controller.abort();
    await expect(sem.acquire(controller.signal)).rejects.toThrow("浏览器采集被取消");
    sem.release();
  });
});
