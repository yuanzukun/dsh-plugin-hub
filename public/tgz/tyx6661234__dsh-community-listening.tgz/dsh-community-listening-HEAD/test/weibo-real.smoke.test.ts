import { describe, expect, it } from "vitest";
import { BrowserSessionPool } from "../src/collect";
import { PlatformPacer } from "../src/pacing";
import { collectWeiboComments, collectWeiboSearch } from "../src/sources/weibo";

/**
 * 微博通道真实冒烟：需 bsk + 浏览器（m.weibo.cn 页面自动带 cookie）。
 * 默认跳过；`DSH_SMOKE=1 pnpm vitest run --pool=threads test/weibo-real.smoke.test.ts` 时执行。
 * 成功 / 明确的 rate_limited 都算通道工作正常。
 */
describe.skipIf(process.env.DSH_SMOKE !== "1")("微博通道真实冒烟（bsk + 浏览器）", () => {
  it(
    "真实会话：搜索帖子 → 第一条有评论的帖子采评论",
    async () => {
      const pool = new BrowserSessionPool("bsk", 120_000, 1, { autoLaunchChrome: false });
      const pacer = new PlatformPacer();
      const exec = {
        signal: new AbortController().signal,
        agent: { session: { header: { cwd: process.cwd() } } },
      } as never;
      try {
        const search = await collectWeiboSearch({ pool, pacer }, exec, "大厂", { limit: 20 });
        console.log(
          "SMOKE search:",
          JSON.stringify({
            ok: search.ok,
            reason: search.reason,
            count: search.posts.length,
            first: search.posts[0]
              ? { author: search.posts[0].author, text: search.posts[0].text.slice(0, 50), comments: search.posts[0].commentCount }
              : null,
            error: search.error ?? "",
          }),
        );
        expect(search.ok || search.reason === "rate_limited").toBe(true);
        if (!search.ok) return;

        const target = search.posts.find((p) => p.commentCount > 0);
        if (!target) return; // 无评论帖子：搜索通道已验证，评论留空即可

        const comments = await collectWeiboComments({ pool, pacer }, exec, target.id, { maxComments: 50 });
        console.log(
          "SMOKE comments:",
          JSON.stringify({
            ok: comments.ok,
            reason: comments.reason,
            count: comments.comments.length,
            first: comments.comments[0]
              ? { author: comments.comments[0].author, content: comments.comments[0].content.slice(0, 60) }
              : null,
            error: comments.error ?? "",
          }),
        );
        expect(comments.ok || ["rate_limited", "empty"].includes(comments.reason)).toBe(true);
      } finally {
        await pool.dispose();
      }
    },
    180_000,
  );
});
