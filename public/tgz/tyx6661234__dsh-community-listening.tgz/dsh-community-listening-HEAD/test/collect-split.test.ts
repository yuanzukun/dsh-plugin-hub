import { describe, expect, it } from "vitest";
import { routeForCommentUrl } from "../src/collect";

describe("routeForCommentUrl（collect_comments 通道路由）", () => {
  it("知乎问题页 → zhihu", () => {
    expect(routeForCommentUrl("https://www.zhihu.com/question/597272501")).toBe("zhihu");
    expect(routeForCommentUrl("https://zhihu.com/question/12345678")).toBe("zhihu");
  });

  it("B 站视频页 → bilibili", () => {
    expect(routeForCommentUrl("https://www.bilibili.com/video/BV1GJ411x7h7")).toBe("bilibili");
    expect(routeForCommentUrl("https://bilibili.com/video/BV1xx411c7mD?p=3")).toBe("bilibili");
  });

  it("其他（小红书非笔记页/普通页）→ browser", () => {
    expect(routeForCommentUrl("https://www.xiaohongshu.com/explore/abc123")).toBe("browser");
    expect(routeForCommentUrl("https://example.com/post/1")).toBe("browser");
    expect(routeForCommentUrl("not a url")).toBe("browser");
  });

  it("知乎专栏 / B 站非视频页 / 小红书查询页不回落到专有通道", () => {
    expect(routeForCommentUrl("https://zhuanlan.zhihu.com/p/123456")).toBe("browser");
    expect(routeForCommentUrl("https://www.bilibili.com/read/cv123")).toBe("browser");
    expect(routeForCommentUrl("https://www.xiaohongshu.com/search_result?keyword=abc")).toBe("browser");
  });

  it("小红书笔记页 → xiaohongshu", () => {
    expect(routeForCommentUrl("https://www.xiaohongshu.com/explore/6a1983810000000035039295")).toBe("xiaohongshu");
    expect(routeForCommentUrl("https://www.xiaohongshu.com/discovery/item/6a1983810000000035039295")).toBe("xiaohongshu");
  });

  it("微博详情页 → weibo", () => {
    expect(routeForCommentUrl("https://m.weibo.cn/detail/5331196709702293")).toBe("weibo");
    expect(routeForCommentUrl("https://m.weibo.cn/detail/5331196709702293?x=1")).toBe("weibo");
  });

  it("抖音视频页 → douyin", () => {
    expect(routeForCommentUrl("https://www.douyin.com/video/7643084980406983089")).toBe("douyin");
    expect(routeForCommentUrl("https://www.douyin.com/?modal_id=7643084980406983089")).toBe("douyin");
    expect(routeForCommentUrl("https://v.douyin.com/iAbc123/")).toBe("douyin"); // 短链走抖音通道，导航后解析
  });

  it("快手视频页 → kuaishou", () => {
    expect(routeForCommentUrl("https://www.kuaishou.com/short-video/3xb2p974yf35c2k")).toBe("kuaishou");
    expect(routeForCommentUrl("https://www.kuaishou.com/f/X-8dHF9SInRxs1WN")).toBe("kuaishou");
  });

  it("牛客讨论帖 → nowcoder", () => {
    expect(routeForCommentUrl("https://www.nowcoder.com/discuss/917392486895452160")).toBe("nowcoder");
    expect(routeForCommentUrl("https://www.nowcoder.com/discuss/917392486895452160?x=1")).toBe("nowcoder");
  });

  it("百度贴吧帖子 → tieba", () => {
    expect(routeForCommentUrl("https://tieba.baidu.com/p/10885405530")).toBe("tieba");
    expect(routeForCommentUrl("https://tieba.baidu.com/p/10885405530?fr=frs")).toBe("tieba");
  });
});
