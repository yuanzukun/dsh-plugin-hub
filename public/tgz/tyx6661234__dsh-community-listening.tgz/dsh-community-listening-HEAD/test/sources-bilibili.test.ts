import { describe, expect, it, vi, beforeEach } from "vitest";

// mock net.ts 的 httpFetch（bilibili.ts 内部依赖），避免真实网络
vi.mock("../src/net", () => ({
  httpFetch: vi.fn(),
}));

import { httpFetch } from "../src/net";
import {
  buildBilibiliReplyMainScript,
  buildBilibiliSearchExtractScript,
  buildBilibiliSearchUrl,
  buildBilibiliViewScript,
  buildWbiMixinKey,
  collectBilibiliComments,
  extractBvid,
  extractWbiKeyComponent,
  parseBilibiliSearchCards,
  pyUrlencodeValue,
  signWbiParams,
  toReply,
} from "../src/sources/bilibili";
import { PlatformPacer } from "../src/pacing";
import { parseBiliEval } from "../src/collect";

const httpFetchMock = vi.mocked(httpFetch);

function fakeResponse(status: number, body: unknown): Response {
  return {
    status,
    ok: status >= 200 && status < 400,
    json: async () => body,
  } as unknown as Response;
}

/** 按 URL path 分发的路由表。 */
function routeResponses(routes: Record<string, unknown>) {
  httpFetchMock.mockImplementation(async (url: string | URL) => {
    const u = new URL(String(url));
    const key = u.pathname;
    if (key in routes) return fakeResponse(200, routes[key]);
    return fakeResponse(404, { code: -404, message: `no route for ${key}` });
  });
}

function makePacer() {
  // 覆盖 bilibili 最小请求间隔为 0，避免测试里产生真实 sleep
  return new PlatformPacer({
    specs: {
      bilibili: { baseCooldownSeconds: 30, maxCooldownSeconds: 1800, minIntervalMs: 0 },
    },
  });
}

const VIEW_OK = {
  code: 0,
  data: { aid: 419902692, title: "测试视频标题" },
};

const REPLY_PAGE1 = {
  code: 0,
  data: {
    replies: [
      {
        rpid: 9000000000000001,
        member: { uname: "用户A" },
        content: { message: "第一条评论" },
        like: 10,
      },
      {
        rpid: 9000000000000002,
        member: { uname: "用户B" },
        content: { message: "第二条评论" },
        like: 2,
      },
    ],
    cursor: { is_end: false, next: 1 },
  },
};

const REPLY_PAGE2 = {
  code: 0,
  data: {
    replies: [
      {
        rpid: 9000000000000003,
        member: { uname: "用户C" },
        content: { message: "第三条评论" },
        like: 0,
      },
    ],
    cursor: { is_end: true, next: 0 },
  },
};

const REPLY_SUB = {
  code: 0,
  data: {
    replies: [
      { rpid: 9000000000000011, member: { uname: "回复者" }, content: { message: "楼中楼回复" }, like: 1 },
    ],
  },
};

beforeEach(() => {
  httpFetchMock.mockReset();
});

describe("extractBvid", () => {
  it("提取 /video/{bvid}", () => {
    expect(extractBvid("https://www.bilibili.com/video/BV1GJ411x7h7")).toBe("BV1GJ411x7h7");
    expect(extractBvid("https://bilibili.com/video/BV1xx411c7mD?p=2")).toBe("BV1xx411c7mD");
  });

  it("非 B 站视频 / 非法返回 null", () => {
    expect(extractBvid("https://www.bilibili.com/read/cv123")).toBeNull();
    expect(extractBvid("https://example.com/video/BV123")).toBeNull();
    expect(extractBvid("not a url")).toBeNull();
  });
});

describe("toReply（评论归一化）", () => {
  it("正常评论", () => {
    expect(
      toReply({ rpid: 123, member: { uname: "作者" }, content: { message: "内容" }, like: 5 }),
    ).toEqual({ rpid: 123, uname: "作者", message: "内容", like: 5 });
  });

  it("缺 rpid / 空内容返回 null", () => {
    expect(toReply({ member: { uname: "x" }, content: { message: "内容" } })).toBeNull();
    expect(toReply({ rpid: 1, content: { message: "   " } })).toBeNull();
    expect(toReply(null)).toBeNull();
  });
});

describe("collectBilibiliComments（API 直连流程）", () => {
  it("成功流：view → 主评论分页 → 楼中楼", async () => {
    httpFetchMock.mockImplementation(async (url: string | URL) => {
      const u = new URL(String(url));
      if (u.pathname === "/x/web-interface/view") return fakeResponse(200, VIEW_OK);
      if (u.pathname === "/x/v2/reply/main") {
        return fakeResponse(200, u.searchParams.get("next") === "1" ? REPLY_PAGE2 : REPLY_PAGE1);
      }
      if (u.pathname === "/x/v2/reply/reply") return fakeResponse(200, REPLY_SUB);
      return fakeResponse(404, { code: -404, message: `no route for ${u.pathname}` });
    });

    const outcome = await collectBilibiliComments({ pacer: makePacer() }, "BV1GJ411x7h7", {
      maxComments: 100,
      maxRepliesPerComment: 20,
    });
    expect(outcome.ok).toBe(true);
    expect(outcome.reason).toBe("success");
    expect(outcome.title).toBe("测试视频标题");
    expect(outcome.comments).toHaveLength(3);
    expect(outcome.comments[0]).toEqual({ author: "用户A", content: "第一条评论", replies: ["楼中楼回复"] });
    expect(outcome.comments[2]).toEqual({ author: "用户C", content: "第三条评论", replies: ["楼中楼回复"] });
    // 断言请求序列：view → main(无 next) → main(next=1) → reply/reply
    const calls = httpFetchMock.mock.calls.map(([url]) => new URL(String(url)).pathname + new URL(String(url)).search);
    expect(calls[0]).toContain("/x/web-interface/view");
    expect(calls[1]).toContain("/x/v2/reply/main");
    expect(calls[2]).toContain("next=1");
    expect(calls.some((c) => c.includes("/x/v2/reply/reply"))).toBe(true);
  });

  it("view 接口 code!=0 → error", async () => {
    routeResponses({
      "/x/web-interface/view": { code: -400, message: "请求错误", data: null },
    });
    const outcome = await collectBilibiliComments({ pacer: makePacer() }, "BV1GJ411x7h7");
    expect(outcome.ok).toBe(false);
    expect(outcome.reason).toBe("error");
    expect(outcome.error).toContain("-400");
  });

  it("HTTP 412 → rate_limited 并触发平台冷却", async () => {
    httpFetchMock.mockImplementation(async () => fakeResponse(412, {}));
    const pacer = makePacer();
    const outcome = await collectBilibiliComments({ pacer }, "BV1GJ411x7h7");
    expect(outcome.ok).toBe(false);
    expect(outcome.reason).toBe("rate_limited");
    expect(pacer.isCoolingDown("bilibili")).toBe(true);
  });

  it("无评论 → empty", async () => {
    routeResponses({
      "/x/web-interface/view": VIEW_OK,
      "/x/v2/reply/main": { code: 0, data: { replies: [], cursor: { is_end: true } } },
    });
    const outcome = await collectBilibiliComments({ pacer: makePacer() }, "BV1GJ411x7h7");
    expect(outcome.ok).toBe(true);
    expect(outcome.reason).toBe("empty");
    expect(outcome.comments).toHaveLength(0);
  });

  it("50 条主评论 + maxReplyComments: 5 → 楼中楼接口只调 5 次、50 条全部返回", async () => {
    const makeReplies = (from: number, count: number) =>
      Array.from({ length: count }, (_, i) => ({
        rpid: 9_000_000_000 + from + i,
        member: { uname: `用户${from + i}` },
        content: { message: `评论${from + i}` },
        like: 0,
      }));
    httpFetchMock.mockImplementation(async (url: string | URL) => {
      const u = new URL(String(url));
      if (u.pathname === "/x/web-interface/view") return fakeResponse(200, VIEW_OK);
      if (u.pathname === "/x/v2/reply/main") {
        const next = u.searchParams.get("next");
        if (next === "1") {
          return fakeResponse(200, { code: 0, data: { replies: makeReplies(20, 20), cursor: { is_end: false, next: 2 } } });
        }
        if (next === "2") {
          return fakeResponse(200, { code: 0, data: { replies: makeReplies(40, 10), cursor: { is_end: true, next: 0 } } });
        }
        return fakeResponse(200, { code: 0, data: { replies: makeReplies(0, 20), cursor: { is_end: false, next: 1 } } });
      }
      if (u.pathname === "/x/v2/reply/reply") return fakeResponse(200, REPLY_SUB);
      return fakeResponse(404, { code: -404, message: `no route for ${u.pathname}` });
    });

    const outcome = await collectBilibiliComments({ pacer: makePacer() }, "BV1GJ411x7h7", {
      maxComments: 100,
      maxRepliesPerComment: 20,
      maxReplyComments: 5,
    });
    expect(outcome.ok).toBe(true);
    expect(outcome.comments).toHaveLength(50); // 全部主评论仍返回

    // 楼中楼接口只被调 5 次（Top-N），而非 50 次
    const replyCalls = httpFetchMock.mock.calls.filter(([url]) =>
      new URL(String(url)).pathname === "/x/v2/reply/reply",
    );
    expect(replyCalls).toHaveLength(5);

    // 前 5 条有楼中楼，其余主评论无 replies
    for (let i = 0; i < 5; i += 1) {
      expect(outcome.comments[i].replies.length).toBeGreaterThan(0);
    }
    for (let i = 5; i < 50; i += 1) {
      expect(outcome.comments[i].replies).toEqual([]);
    }
  });

  it("主接口异常 → WBI 变体自动重试成功", async () => {
    httpFetchMock.mockImplementation(async (url: string | URL) => {
      const u = new URL(String(url));
      if (u.pathname === "/x/web-interface/view") return fakeResponse(200, VIEW_OK);
      if (u.pathname === "/x/v2/reply/main") {
        return fakeResponse(200, { code: -403, message: "需要签名", data: null });
      }
      if (u.pathname === "/x/web-interface/nav") {
        return fakeResponse(200, {
          code: 0,
          data: {
            wbi_img: {
              img_url: "https://i0.hdslb.com/bfs/wbi/7cd084941338484aae1ad9425b84077c.png",
              sub_url: "https://i0.hdslb.com/bfs/wbi/4932caff0ff746eab6f01bf08b70ac45.png",
            },
          },
        });
      }
      if (u.pathname === "/x/v2/reply/wbi/main") {
        // 断言 WBI 签名参数存在
        expect(u.searchParams.get("w_rid")).toBeTruthy();
        expect(u.searchParams.get("wts")).toBeTruthy();
        return fakeResponse(200, { code: 0, data: { replies: [REPLY_PAGE1.data.replies[0]], cursor: { is_end: true } } });
      }
      return fakeResponse(404, { code: -404, message: `no route for ${u.pathname}` });
    });
    const outcome = await collectBilibiliComments({ pacer: makePacer() }, "BV1GJ411x7h7", {
      maxComments: 100,
      maxRepliesPerComment: 0,
    });
    expect(outcome.ok).toBe(true);
    expect(outcome.reason).toBe("success");
    expect(outcome.comments).toHaveLength(1);
    expect(outcome.comments[0].author).toBe("用户A");
  });
});

describe("WBI 签名（对齐 OpenBiliClaw bilibili/api.py）", () => {
  it("extractWbiKeyComponent 从 URL 提取 key", () => {
    expect(extractWbiKeyComponent("https://i0.hdslb.com/bfs/wbi/7cd084941338484aae1ad9425b84077c.png")).toBe(
      "7cd084941338484aae1ad9425b84077c",
    );
    expect(extractWbiKeyComponent("not a url")).toBe("");
  });

  it("buildWbiMixinKey 确定性（打乱表 + 截 32）", () => {
    const img = "7cd084941338484aae1ad9425b84077c";
    const sub = "4932caff0ff746eab6f01bf08b70ac45";
    const mixin = buildWbiMixinKey(img, sub);
    expect(mixin).toHaveLength(32);
    expect(buildWbiMixinKey(img, sub)).toBe(mixin); // 确定性
  });

  it("signWbiParams 输出 wts/w_rid 且格式正确", () => {
    const img = "7cd084941338484aae1ad9425b84077c";
    const sub = "4932caff0ff746eab6f01bf08b70ac45";
    const a = signWbiParams({ type: 1, oid: 419902692, mode: 3 }, img, sub);
    expect(a.w_rid).toMatch(/^[0-9a-f]{32}$/);
    expect(Number(a.wts)).toBeGreaterThan(1_600_000_000);
    expect(a.type).toBe("1"); // 原参数保留
    // 同一输入（固定 wts 注入）重复签名结果一致
    const fixed = signWbiParams({ type: 1, oid: 419902692, mode: 3, wts: "1700000000" }, img, sub);
    const fixed2 = signWbiParams({ type: 1, oid: 419902692, mode: 3, wts: "1700000000" }, img, sub);
    expect(fixed.w_rid).toBe(fixed2.w_rid);
  });

  it("pyUrlencodeValue 对齐 quote_plus(safe='') 语义", () => {
    expect(pyUrlencodeValue("abc XYZ")).toBe("abc+XYZ");
    expect(pyUrlencodeValue("a~b*c")).toBe("a%7Eb%2Ac"); // ~ 和 * 都编码
    expect(pyUrlencodeValue("中文")).toBe("%E4%B8%AD%E6%96%87");
    expect(pyUrlencodeValue("a-b_c.d")).toBe("a-b_c.d"); // 保留字符
  });
});

describe("浏览器同源兜底脚本", () => {
  it("buildBilibiliViewScript 指向 api 域绝对 URL", () => {
    const script = buildBilibiliViewScript("BV1GJ411x7h7");
    expect(script).toContain("https://api.bilibili.com/x/web-interface/view?bvid=BV1GJ411x7h7");
    expect(script).toContain('credentials: "include"');
  });

  it("buildBilibiliReplyMainScript 分页参数正确", () => {
    expect(buildBilibiliReplyMainScript(419902692, 3)).toContain("https://api.bilibili.com/x/v2/reply/main?type=1&oid=419902692&mode=3");
    expect(buildBilibiliReplyMainScript(419902692, 3, 7)).toContain("https://api.bilibili.com/x/v2/reply/main?type=1&oid=419902692&mode=3&next=7");
    expect(buildBilibiliReplyMainScript(419902692, 3)).not.toContain("next=");
  });

  it("parseBiliEval 解析 evaluate 返回（含 bsk 包装解包后的形状）", () => {
    expect(
      parseBiliEval({ ok: true, code: 0, aid: 419902692, title: "T", isEnd: true, next: 0, items: [{ rpid: 1, uname: "u", message: "m" }] }),
    ).toMatchObject({ ok: true, aid: 419902692, isEnd: true, items: [{ rpid: 1, uname: "u", message: "m" }] });
    expect(parseBiliEval({ ok: false, error: "boom" }).ok).toBe(false);
    expect(parseBiliEval(null).ok).toBe(false);
  });
});

describe("B 站搜索发现", () => {
  it("搜索 URL 编码", () => {
    expect(buildBilibiliSearchUrl("应用统计就业")).toBe(
      "https://search.bilibili.com/video?keyword=%E5%BA%94%E7%94%A8%E7%BB%9F%E8%AE%A1%E5%B0%B1%E4%B8%9A",
    );
  });

  it("解析搜索卡片（BV 号 → 视频 URL）", () => {
    const cards = parseBilibiliSearchCards({
      ok: true,
      count: 2,
      cards: [
        { bvid: "BV1x6NJ6LEr3", title: "2026年AI对数据分析行业的影响", author: "不知渭河", playText: "8098" },
        { bvid: "", title: "空BV号过滤", author: "x", playText: "1" },
      ],
    });
    expect(cards).toHaveLength(1);
    expect(cards[0]).toEqual({
      bvid: "BV1x6NJ6LEr3",
      url: "https://www.bilibili.com/video/BV1x6NJ6LEr3",
      title: "2026年AI对数据分析行业的影响",
      author: "不知渭河",
      playText: "8098",
    });
  });

  it("提取脚本扫描 /video/BV 链接", () => {
    const script = buildBilibiliSearchExtractScript();
    expect(script).toContain("/video/BV");
    expect(script).toContain(".bili-video-card");
  });
});
