import { describe, expect, it } from "vitest";
import { BrowserSessionPool } from "../src/collect";
import { PlatformPacer } from "../src/pacing";
import { collectNowcoderComments } from "../src/sources/nowcoder";

/**
 * 牛客评论通道真实冒烟：需 bsk + 浏览器（牛客讨论帖 SSR 渲染评论区）。
 * 默认跳过；`DSH_SMOKE=1 pnpm vitest run --pool=threads test/nowcoder-real.smoke.test.ts` 时执行。
 * 成功 / 明确的 rate_limited / empty 都算通道工作正常。
 */
describe.skipIf(process.env.DSH_SMOKE !== "1")("牛客评论通道真实冒烟（bsk + 浏览器）", () => {
  it(
    "真实会话：讨论帖 → DOM 提取评论",
    async () => {
      const pool = new BrowserSessionPool("bsk", 120_000, 1, { autoLaunchChrome: false });
      const pacer = new PlatformPacer();
      const exec = {
        signal: new AbortController().signal,
        agent: { session: { header: { cwd: process.cwd() } } },
      } as never;
      try {
        const url = process.env.NOWCODER_URL || "https://www.nowcoder.com/discuss/917392486895452160";
        const outcome = await collectNowcoderComments({ pool, pacer }, exec, url, { maxComments: 50 });
        console.log(
          "SMOKE:",
          JSON.stringify({
            ok: outcome.ok,
            reason: outcome.reason,
            title: (outcome.title || "").slice(0, 60),
            count: outcome.comments.length,
            first: outcome.comments[0]
              ? { author: outcome.comments[0].author, content: outcome.comments[0].content.slice(0, 60) }
              : null,
            error: outcome.error ?? "",
          }),
        );
        expect(outcome.ok || ["rate_limited", "empty"].includes(outcome.reason)).toBe(true);
        if (outcome.ok && outcome.comments.length > 0) {
          expect(outcome.comments[0].content.length).toBeGreaterThan(0);
        }
      } finally {
        await pool.dispose();
      }
    },
    120_000,
  );
});
