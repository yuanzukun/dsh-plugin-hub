import { describe, expect, it } from "vitest";
import {
  buildNowcoderCommentsScript,
  extractNowcoderPostId,
  parseNowcoderComments,
} from "../src/sources/nowcoder";

describe("extractNowcoderPostId", () => {
  it("识别 /discuss/{id}", () => {
    expect(extractNowcoderPostId("https://www.nowcoder.com/discuss/917392486895452160")).toBe("917392486895452160");
    expect(extractNowcoderPostId("https://www.nowcoder.com/discuss/917392486895452160?sourceSSR=home")).toBe("917392486895452160");
  });

  it("非牛客讨论帖 / 非法返回 null", () => {
    expect(extractNowcoderPostId("https://www.nowcoder.com/feed")).toBeNull();
    expect(extractNowcoderPostId("https://example.com/discuss/123")).toBeNull();
    expect(extractNowcoderPostId("not a url")).toBeNull();
  });
});

describe("buildNowcoderCommentsScript", () => {
  it("DOM 提取 .comment-box / content-user-info / comment-rich-text", () => {
    const script = buildNowcoderCommentsScript();
    expect(script).toContain("comment-box");
    expect(script).toContain("content-user-info");
    expect(script).toContain("comment-rich-text");
  });
});

describe("parseNowcoderComments", () => {
  it("归一化评论（author/content）", () => {
    const parsed = parseNowcoderComments({
      ok: true,
      items: [
        { author: "职场不咸鱼", content: "高手在民间👍" },
        { author: "x", content: "" }, // 空内容过滤
        null,
      ],
    });
    expect(parsed.ok).toBe(true);
    expect(parsed.items).toHaveLength(1);
    expect(parsed.items[0]).toEqual({ author: "职场不咸鱼", content: "高手在民间👍", replies: [] });
  });

  it("错误负载", () => {
    expect(parseNowcoderComments({ ok: false, error: "boom" }).ok).toBe(false);
    expect(parseNowcoderComments(null).items).toHaveLength(0);
  });
});
