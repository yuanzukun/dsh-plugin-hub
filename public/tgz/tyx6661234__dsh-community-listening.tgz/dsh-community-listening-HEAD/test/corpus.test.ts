import { describe, expect, it } from "vitest";
import { mkdtempSync, existsSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  appendEntries,
  corpusPath,
  corpusStats,
  entryDedupKey,
  invalidateDedupCache,
  loadEntries,
  makeEntry,
  saveReport,
  slugTopic,
  topicDir,
} from "../src/corpus";

function tempRoot(): string {
  return mkdtempSync(join(tmpdir(), "dsh-community-listening-corpus-"));
}

describe("corpus", () => {
  it("slugTopic 清洗非法字符", () => {
    expect(slugTopic("字节后端校招面经")).toBe("字节后端校招面经");
    expect(slugTopic("  a/b\\c:d*e?f\"g<h>i|j  ")).toBe("a-b-c-d-e-f-g-h-i-j");
    expect(slugTopic("   ")).toBe("default");
  });

  it("追加 + 去重（同 topic+url+内容）幂等", () => {
    const root = tempRoot();
    const entries = [
      makeEntry({ topic: "t", kind: "article", url: "https://a.com/x?utm_source=1", text: "第一篇文章内容" }),
      makeEntry({ topic: "t", kind: "article", url: "https://a.com/x", text: "第一篇文章内容" }), // 同内容同 URL（归一化后）→ 跳过
      makeEntry({ topic: "t", kind: "comment", url: "https://a.com/x", text: "很好的一条评论" }),
      makeEntry({ topic: "other", kind: "article", url: "https://a.com/x", text: "第一篇文章内容" }), // 不同 topic → 保留
    ];
    const first = appendEntries(root, "t", entries);
    expect(first.saved).toBe(3); // 第 2 条去重跳过
    expect(first.skipped).toBe(1);

    // 重跑同批 → 全部跳过
    const again = appendEntries(root, "t", entries.slice(0, 2));
    expect(again.saved).toBe(0);
    expect(again.skipped).toBe(2);

    const loaded = loadEntries(root, "t");
    expect(loaded).toHaveLength(2); // article + comment
    expect(loaded.filter((e) => e.kind === "article")).toHaveLength(1);

    rmSync(root, { recursive: true, force: true });
  });

  it("entryDedupKey 忽略 tracking 参数", () => {
    const a = entryDedupKey({ topic: "t", url: "https://a.com/x?utm_source=1", text: "内容" });
    const b = entryDedupKey({ topic: "t", url: "https://a.com/x", text: "内容" });
    expect(a).toBe(b);
  });

  it("corpusStats 计数 + 最新时间", () => {
    const root = tempRoot();
    appendEntries(root, "t", [
      makeEntry({ topic: "t", kind: "article", url: "https://a.com/1", text: "甲", trust: "A", strategy: "fetch" }),
      makeEntry({ topic: "t", kind: "article", url: "https://a.com/2", text: "乙", trust: "B", strategy: "browser" }),
      makeEntry({ topic: "t", kind: "comment", url: "https://a.com/3", text: "丙", trust: "C", strategy: "browser" }),
    ]);
    const stats = corpusStats(root, "t");
    expect(stats.total).toBe(3);
    expect(stats.byKind).toEqual({ article: 2, comment: 1 });
    expect(stats.byTrust).toEqual({ A: 1, B: 1, C: 1 });
    expect(stats.byStrategy).toEqual({ fetch: 1, browser: 2 });
    expect(stats.latestCollectedAt).toBeTruthy();
    rmSync(root, { recursive: true, force: true });
  });

  it("invalidateDedupCache 失效陈旧缓存（外部删改文件后重写不再错误跳过）", () => {
    const root = tempRoot();
    const entry = makeEntry({ topic: "t", kind: "article", url: "https://a.com/x", text: "内容" });

    const first = appendEntries(root, "t", [entry]);
    expect(first.saved).toBe(1);

    // 同进程缓存命中 → 重跑跳过（正常去重）
    const stale = appendEntries(root, "t", [entry]);
    expect(stale.saved).toBe(0);
    expect(stale.skipped).toBe(1);

    // 外部删除 corpus.jsonl（用户动过文件）
    rmSync(corpusPath(root, "t"), { force: true });

    // 未失效缓存 → 仍错误跳过（复现陈旧缓存 bug）
    const stale2 = appendEntries(root, "t", [entry]);
    expect(stale2.saved).toBe(0);

    // 失效后再写 → 正确保存
    invalidateDedupCache(root, "t");
    const fresh = appendEntries(root, "t", [entry]);
    expect(fresh.saved).toBe(1);
    expect(fresh.skipped).toBe(0);
    expect(loadEntries(root, "t")).toHaveLength(1);

    rmSync(root, { recursive: true, force: true });
  });

  it("saveReport 落盘 + 覆盖保护", () => {
    const root = tempRoot();
    const res = saveReport(root, "t", "# 报告\n正文", false);
    expect(existsSync(res.path)).toBe(true);
    expect(readFileSync(res.path, "utf8")).toContain("# 报告");
    expect(() => saveReport(root, "t", "again", false)).toThrow(/已存在/);
    saveReport(root, "t", "覆盖版", true);
    expect(readFileSync(res.path, "utf8")).toBe("覆盖版");
    expect(topicDir(root, "t")).toContain("insight-workspace");
    rmSync(root, { recursive: true, force: true });
  });
});
