import { describe, expect, it } from "vitest";
import {
  buildDouyinCommentsScript,
  buildDouyinDetailScript,
  buildDouyinSearchScript,
  buildDouyinSearchUrl,
  buildDouyinUserWorksScript,
  extractAwemeId,
  extractSecUid,
  isDouyinShortUrl,
  parseDouyinComments,
  parseDouyinDetail,
  parseDouyinSearchCards,
  parseDouyinSearchPage,
  parseDouyinUserWorks,
} from "../src/sources/douyin";

describe("extractAwemeId", () => {
  it("识别 /video/{id} 与 modal_id", () => {
    expect(extractAwemeId("https://www.douyin.com/video/7643084980406983089")).toBe("7643084980406983089");
    expect(extractAwemeId("https://www.douyin.com/video/7643084980406983089?previous_page=1")).toBe("7643084980406983089");
    expect(extractAwemeId("https://www.douyin.com/?modal_id=7643084980406983089")).toBe("7643084980406983089");
    expect(extractAwemeId("https://v.douyin.com/iAbc123/")).toBeNull(); // 短链无 id（需解析重定向）
  });

  it("非抖音 / 非法返回 null", () => {
    expect(extractAwemeId("https://example.com/video/123")).toBeNull();
    expect(extractAwemeId("https://www.douyin.com/search/美食")).toBeNull();
    expect(extractAwemeId("not a url")).toBeNull();
  });
});

describe("buildDouyinCommentsScript", () => {
  it("指向 comment/list + cursor 分页", () => {
    const s1 = buildDouyinCommentsScript("7643084980406983089", 0);
    expect(s1).toContain("/aweme/v1/web/comment/list/?aweme_id=7643084980406983089&cursor=0&count=20&item_type=0");
    const s2 = buildDouyinCommentsScript("7643084980406983089", 40);
    expect(s2).toContain("cursor=40");
  });
});

describe("parseDouyinComments", () => {
  it("归一化评论（cid/author/content/replyTotal）", () => {
    const parsed = parseDouyinComments({
      ok: true,
      items: [
        { cid: "7643308541067756337", author: "用户A", content: "第一条评论", replyTotal: 3 },
        { cid: "x", content: "" }, // 空内容过滤
        null,
      ],
      cursor: 20,
      hasMore: true,
      total: 2726,
    });
    expect(parsed.ok).toBe(true);
    expect(parsed.items).toHaveLength(1);
    expect(parsed.items[0]).toEqual({ cid: "7643308541067756337", author: "用户A", content: "第一条评论", replyTotal: 3 });
    expect(parsed.cursor).toBe(20);
    expect(parsed.hasMore).toBe(true);
    expect(parsed.total).toBe(2726);
  });

  it("错误负载", () => {
    expect(parseDouyinComments({ ok: false, error: "boom" }).ok).toBe(false);
    expect(parseDouyinComments(null).items).toHaveLength(0);
  });
});

describe("isDouyinShortUrl", () => {
  it("识别 v.douyin.com 短链", () => {
    expect(isDouyinShortUrl("https://v.douyin.com/iAbc123/")).toBe(true);
    expect(isDouyinShortUrl("https://www.douyin.com/video/7643084980406983089")).toBe(false);
    expect(isDouyinShortUrl("https://example.com/v.douyin.com")).toBe(false);
    expect(isDouyinShortUrl("not a url")).toBe(false);
  });
});

describe("buildDouyinSearchUrl", () => {
  it("编码关键词并指向综合搜索页", () => {
    expect(buildDouyinSearchUrl("数据分析")).toBe("https://www.douyin.com/search/%E6%95%B0%E6%8D%AE%E5%88%86%E6%9E%90?type=general");
  });
});

describe("buildDouyinSearchScript", () => {
  it("包含关键词/筛选/offset/分页参数", () => {
    const s0 = buildDouyinSearchScript("数据分析", 0);
    expect(s0).toContain("/aweme/v1/web/general/search/single/");
    expect(s0).toContain('"数据分析"');
    expect(s0).toContain("offset\", String(0)");
    expect(s0).toContain("sort_type");
    const s40 = buildDouyinSearchScript("数据分析", 40, { sortType: "1", publishTime: "7" });
    expect(s40).toContain("String(40)");
    expect(s40).toContain("publish_time");
  });
});

describe("parseDouyinSearchPage / parseDouyinSearchCards", () => {
  it("归一化搜索 API 卡片（含 aweme_info）", () => {
    const parsed = parseDouyinSearchPage({
      ok: true,
      items: [
        { awemeId: "7643308541067756337", url: "https://www.douyin.com/video/7643308541067756337", title: "标题", author: "作者", diggCount: 10, commentCount: 2, createTime: 123 },
        { awemeId: "bad", title: "非法 id" },
        null,
      ],
      hasMore: true,
      nextOffset: 25,
    });
    expect(parsed.ok).toBe(true);
    expect(parsed.cards).toHaveLength(1);
    expect(parsed.cards[0]).toEqual({ awemeId: "7643308541067756337", url: "https://www.douyin.com/video/7643308541067756337", title: "标题", author: "作者", diggCount: 10, commentCount: 2, createTime: 123 });
    expect(parsed.hasMore).toBe(true);
    expect(parsed.nextOffset).toBe(25);
  });

  it("parseDouyinSearchCards 只返回卡片数组", () => {
    expect(parseDouyinSearchCards({ ok: true, items: [{ awemeId: "7643308541067756337", title: "t" }] })).toHaveLength(1);
    expect(parseDouyinSearchCards(null)).toHaveLength(0);
  });
});

describe("buildDouyinDetailScript / parseDouyinDetail", () => {
  it("脚本指向 aweme/detail", () => {
    expect(buildDouyinDetailScript("7643308541067756337")).toContain("/aweme/v1/web/aweme/detail/?aweme_id=7643308541067756337");
  });

  it("归一化详情元数据", () => {
    const parsed = parseDouyinDetail({
      ok: true,
      title: "视频标题",
      author: "作者",
      secUid: "MS4wLjABAAAA",
      statistics: { diggCount: 10, commentCount: 2, collectCount: 1, shareCount: 0, admireCount: 0, playCount: 0 },
    });
    expect(parsed.ok).toBe(true);
    expect(parsed.title).toBe("视频标题");
    expect(parsed.author).toBe("作者");
    expect(parsed.statistics?.diggCount).toBe(10);
  });

  it("错误负载", () => {
    expect(parseDouyinDetail(null).ok).toBe(false);
    expect(parseDouyinDetail({ ok: false }).title).toBe("");
  });
});

describe("extractSecUid", () => {
  it("从 /user/{sec_uid} 提取", () => {
    expect(extractSecUid("https://www.douyin.com/user/MS4wLjABAAAAJdtSPYx6iNkUyyI2PWLe3JXcfBaESLTVc0Vhyk8zE_4?from_tab_name=main")).toBe("MS4wLjABAAAAJdtSPYx6iNkUyyI2PWLe3JXcfBaESLTVc0Vhyk8zE_4");
    expect(extractSecUid("https://www.douyin.com/video/7643308541067756337")).toBeNull();
    expect(extractSecUid("not a url")).toBeNull();
  });
});

describe("buildDouyinUserWorksScript / parseDouyinUserWorks", () => {
  it("脚本指向 aweme/post 并带 sec_user_id/cursor", () => {
    const s = buildDouyinUserWorksScript("MS4wLjABAAAA", 0);
    expect(s).toContain("/aweme/v1/web/aweme/post/");
    expect(s).toContain("MS4wLjABAAAA");
    expect(s).toContain("String(0)");
  });

  it("归一化用户作品列表", () => {
    const parsed = parseDouyinUserWorks({
      ok: true,
      items: [
        { awemeId: "7643308541067756337", url: "https://www.douyin.com/video/7643308541067756337", title: "作品", author: "作者", diggCount: 3, commentCount: 1, createTime: 456 },
      ],
      hasMore: true,
      maxCursor: 1782728878000,
    });
    expect(parsed.ok).toBe(true);
    expect(parsed.items).toHaveLength(1);
    expect(parsed.items[0].awemeId).toBe("7643308541067756337");
    expect(parsed.hasMore).toBe(true);
    expect(parsed.maxCursor).toBe(1782728878000);
  });

  it("错误负载", () => {
    expect(parseDouyinUserWorks(null).ok).toBe(false);
    expect(parseDouyinUserWorks({ ok: false, items: [] }).items).toHaveLength(0);
  });
});
