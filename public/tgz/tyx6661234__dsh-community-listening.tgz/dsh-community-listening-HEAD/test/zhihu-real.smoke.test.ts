import { describe, expect, it } from "vitest";
import { BrowserSessionPool } from "../src/collect";
import { PlatformPacer } from "../src/pacing";
import { collectZhihuAnswers } from "../src/sources/zhihu";

/**
 * 知乎通道真实冒烟：需要 bsk daemon + 浏览器连接 + 页面可访问知乎。
 * 默认跳过；`DSH_SMOKE=1 pnpm vitest run --pool=threads test/zhihu-real.smoke.test.ts` 时执行。
 */
describe.skipIf(process.env.DSH_SMOKE !== "1")("知乎通道真实冒烟（bsk + 浏览器）", () => {
  it(
    "真实会话采集回答 + 评论区",
    async () => {
      const pool = new BrowserSessionPool("bsk", 120_000, 1, { autoLaunchChrome: false });
      const pacer = new PlatformPacer();
      const exec = {
        signal: new AbortController().signal,
        agent: { session: { header: { cwd: process.cwd() } } },
      } as never;
      try {
        const outcome = await collectZhihuAnswers(
          { pool, pacer },
          exec,
          "597272501",
          { maxAnswers: 3, maxAnswerComments: 2, commentsPerAnswer: 20 },
        );
        console.log(
          "SMOKE:",
          JSON.stringify({
            ok: outcome.ok,
            reason: outcome.reason,
            title: outcome.title?.slice(0, 60),
            answerCount: outcome.answers.length,
            withReplies: outcome.answers.filter((a) => a.replies.length > 0).length,
            error: outcome.error ?? "",
          }),
        );
        expect(outcome.ok).toBe(true);
        expect(outcome.answers.length).toBeGreaterThan(0);
      } finally {
        await pool.dispose();
      }
    },
    120_000,
  );
});
