import { readFileSync } from "node:fs";

const env = {};
for (const line of readFileSync("D:/agentdev/insigtai/.env", "utf8").split(/\r?\n/)) {
  const m = line.trim().match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
  if (m) env[m[1]] = m[2].trim().replace(/^["']|["']$/g, "");
}

const chat = async (base, key, model, label) => {
  try {
    const r = await fetch(base.replace(/\/+$/, "") + "/chat/completions", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: "Bearer " + key },
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: "只回复两个字：正常" }],
        temperature: 0,
        stream: false,
      }),
    });
    const j = await r.json();
    const text = j.choices?.[0]?.message?.content ?? JSON.stringify(j).slice(0, 150);
    console.log(label + " [" + r.status + "] " + text.trim().slice(0, 60));
  } catch (e) {
    console.log(label + " ERR " + e.message.slice(0, 100));
  }
};

const freeModels = env.OPENCODE_FREE_MODELS.split(",").map((s) => s.trim());
console.log("free model pool:", freeModels.length, "first =", freeModels[0]);
await chat(env.OPENCODE_API_BASE_URL, env.OPENCODE_API_KEY, freeModels[0], "opencode-free-1");
await chat(env.OPENCODE_API_BASE_URL, env.OPENCODE_API_KEY, freeModels[1], "opencode-free-2");
const keys = env.OPENAI_API_KEYS.split(",").map((s) => s.trim());
console.log("sensenova keys:", keys.length);
await chat(env.LLM_BASE_URL, keys[0], env.LLM_MODEL_LITE, "sensenova-lite");
