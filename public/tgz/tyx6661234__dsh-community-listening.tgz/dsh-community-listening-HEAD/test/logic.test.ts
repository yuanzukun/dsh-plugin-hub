import { describe, expect, it } from "vitest";
import { normalizeUrl } from "../src/net";

describe("normalizeUrl", () => {
  it("去 tracking 参数与尾斜杠", () => {
    const out = normalizeUrl("https://M.zhihu.com/question/1/?utm_source=wechat&spm=1");
    expect(out).toBe("https://m.zhihu.com/question/1");
  });
});
