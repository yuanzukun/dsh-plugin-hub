import { describe, expect, it } from "vitest";
import {
  DEFAULT_DIRECT_HOST_SUFFIXES,
  isPrivateIpv4Host,
  setDirectHostSuffixes,
  shouldBypassProxy,
} from "../src/net";

describe("shouldBypassProxy（代理出口分级：国内社区平台直连）", () => {
  it("本地 / 内网直连", () => {
    expect(shouldBypassProxy("http://localhost:8080/x")).toBe(true);
    expect(shouldBypassProxy("http://127.0.0.1:7897")).toBe(true);
    expect(shouldBypassProxy("http://192.168.1.10/api")).toBe(true);
    expect(shouldBypassProxy("http://10.0.0.5/x")).toBe(true);
  });

  it("RFC1918 私有 IPv4 精确判断（172.16-31 段）", () => {
    // 172.16.0.0–172.31.255.255 是私有段 → 直连
    expect(shouldBypassProxy("http://172.16.0.1/x")).toBe(true);
    expect(shouldBypassProxy("http://172.31.255.1/x")).toBe(true);
    // 172.15 / 172.32 / 172.1 是公网段 → 不走直连（行为修正：旧版 startsWith("172.") 误判）
    expect(shouldBypassProxy("http://172.15.0.1/x")).toBe(false);
    expect(shouldBypassProxy("http://172.32.0.1/x")).toBe(false);
    expect(shouldBypassProxy("http://172.1.2.3/x")).toBe(false);
  });

  it("isPrivateIpv4Host 单元判断", () => {
    expect(isPrivateIpv4Host("10.1.2.3")).toBe(true);
    expect(isPrivateIpv4Host("192.168.0.1")).toBe(true);
    expect(isPrivateIpv4Host("172.16.0.1")).toBe(true);
    expect(isPrivateIpv4Host("172.31.255.255")).toBe(true);
    expect(isPrivateIpv4Host("172.15.0.1")).toBe(false);
    expect(isPrivateIpv4Host("172.32.0.1")).toBe(false);
    expect(isPrivateIpv4Host("172.1.2.3")).toBe(false);
    expect(isPrivateIpv4Host("8.8.8.8")).toBe(false);
    expect(isPrivateIpv4Host("localhost")).toBe(false);
    expect(isPrivateIpv4Host("999.1.1.1")).toBe(false); // 越界数字
    expect(isPrivateIpv4Host("172.16.0.999")).toBe(false);
    expect(isPrivateIpv4Host("not-an-ip")).toBe(false);
  });

  it("国内社区平台（默认直连后缀）直连", () => {
    expect(shouldBypassProxy("https://www.zhihu.com/question/1")).toBe(true);
    expect(shouldBypassProxy("https://api.zhihu.com/api/v4/me")).toBe(true);
    expect(shouldBypassProxy("https://api.bilibili.com/x/v2/reply/main")).toBe(true);
    expect(shouldBypassProxy("https://www.bilibili.com/video/BV1xx")).toBe(true);
    expect(shouldBypassProxy("https://www.xiaohongshu.com/explore/1")).toBe(true);
    expect(shouldBypassProxy("https://www.nowcoder.com/discuss/1")).toBe(true);
    expect(shouldBypassProxy("https://weibo.com/u/123")).toBe(true);
  });

  it("海外站点默认走代理（不直连）", () => {
    expect(shouldBypassProxy("https://news.ycombinator.com/item?id=1")).toBe(false);
    expect(shouldBypassProxy("https://github.com/whiteguo233/OpenBiliClaw")).toBe(false);
    expect(shouldBypassProxy("https://www.reddit.com/r/programming/")).toBe(false);
  });

  it("配置追加的后缀生效（setDirectHostSuffixes / 参数注入）", () => {
    setDirectHostSuffixes([".example.com"]);
    try {
      expect(shouldBypassProxy("https://blog.example.com/post")).toBe(true);
      expect(shouldBypassProxy("https://example.com/post")).toBe(true);
      expect(shouldBypassProxy("https://example.org/post")).toBe(false);
    } finally {
      setDirectHostSuffixes([]);
    }
    // 参数注入方式（不依赖模块级状态）
    expect(shouldBypassProxy("https://blog.example.com/post", [".example.com"])).toBe(true);
  });

  it("URL 解析失败 → 直连", () => {
    expect(shouldBypassProxy("not a url")).toBe(true);
    expect(shouldBypassProxy("")).toBe(true);
  });

  it("默认直连后缀包含核心社区平台", () => {
    expect(DEFAULT_DIRECT_HOST_SUFFIXES).toContain(".zhihu.com");
    expect(DEFAULT_DIRECT_HOST_SUFFIXES).toContain(".bilibili.com");
    expect(DEFAULT_DIRECT_HOST_SUFFIXES).toContain(".xiaohongshu.com");
    expect(DEFAULT_DIRECT_HOST_SUFFIXES).toContain(".nowcoder.com");
  });
});
