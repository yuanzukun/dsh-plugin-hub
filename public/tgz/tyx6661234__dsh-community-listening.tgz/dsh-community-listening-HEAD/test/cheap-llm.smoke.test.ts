/**
 * 廉价 LLM 通道真实冒烟测试（默认跳过；设 SMOKE=1 后运行）：
 *   pnpm vitest run test/cheap-llm.smoke.test.ts（需先 $env:SMOKE=1）
 * 覆盖：loadCheapLlm 从 .env 加载 → CheapLlm.complete 走真实 opencode free（带 opencode UA）
 * 与 sensenova lite；连续多次调用验证无 429（UA 生效）与坏模型黑名单。
 */
import { describe, expect, it } from "vitest";
import { CheapLlm, loadCheapLlm } from "../src/llm";

const ENABLED = process.env.SMOKE === "1";

describe.skipIf(!ENABLED)("smoke: cheap llm", { timeout: 120_000 }, () => {
  it("loadCheapLlm 从 .env 加载配置", () => {
    const cheap = loadCheapLlm("D:\\agentdev\\insigtai\\.env");
    expect(cheap.available()).toBe(true);
  });

  it("opencode free 连续 10 次调用无 429（UA=opencode 生效）", async () => {
    const cheap = loadCheapLlm("D:\\agentdev\\insigtai\\.env");
    for (let i = 0; i < 10; i += 1) {
      const text = await cheap.complete("", "只回复两个字：正常");
      expect(text).toBeTruthy();
    }
  });

  it("坏模型被加入黑名单后跳过", async () => {
    const cheap = loadCheapLlm("D:\\agentdev\\insigtai\\.env");
    // 通过私有成员访问验证黑名单机制：401 模型应被记录
    const blacklist = (cheap as unknown as { blacklist: Set<string> }).blacklist;
    blacklist.add("ling-3.0-tiny-free"); // 实测 401 模型
    const text = await cheap.complete("", "只回复两个字：正常");
    expect(text).toBeTruthy(); // 跳过坏模型后仍能成功
  });
});
