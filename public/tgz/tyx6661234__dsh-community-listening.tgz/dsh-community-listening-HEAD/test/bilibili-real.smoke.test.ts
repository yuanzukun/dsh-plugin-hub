import { describe, expect, it } from "vitest";
import { BrowserSessionPool, parseBiliEval } from "../src/collect";
import { unwrapEvaluateValue } from "../src/sources/zhihu";
import { buildBilibiliReplyMainScript, buildBilibiliViewScript } from "../src/sources/bilibili";

/**
 * B 站浏览器兜底真实冒烟：验证「后端 412 → 浏览器跨域 fetch」链路。
 * 默认跳过；`DSH_SMOKE=1 pnpm vitest run --pool=threads test/bilibili-real.smoke.test.ts` 时执行。
 */
describe.skipIf(process.env.DSH_SMOKE !== "1")("B 站浏览器兜底真实冒烟（bsk + 浏览器）", () => {
  it(
    "真实会话：navigate → view → reply 分页",
    async () => {
      const pool = new BrowserSessionPool("bsk", 120_000, 1, { autoLaunchChrome: false });
      const exec = {
        signal: new AbortController().signal,
        agent: { session: { header: { cwd: process.cwd() } } },
      } as never;
      let handle = null;
      try {
        handle = await pool.acquire(exec);
        const sid = handle.sessionId;
        await handle.run(
          exec,
          ["navigate", "--session", sid, "https://www.bilibili.com/video/BV1DogW6mEiq"],
          "bili navigate",
        );
        const viewPayload = parseBiliEval(
          unwrapEvaluateValue(
            await handle.run(exec, ["evaluate", "--session", sid, buildBilibiliViewScript("BV1DogW6mEiq")], "bili view"),
          ),
        );
        console.log("SMOKE view:", JSON.stringify({ ok: viewPayload.ok, aid: viewPayload.aid, title: viewPayload.title, error: viewPayload.error }));
        expect(viewPayload.ok).toBe(true);
        expect(viewPayload.aid).toBeGreaterThan(0);

        const replyPayload = parseBiliEval(
          unwrapEvaluateValue(
            await handle.run(exec, ["evaluate", "--session", sid, buildBilibiliReplyMainScript(viewPayload.aid!, 3)], "bili reply"),
          ),
        );
        console.log(
          "SMOKE reply:",
          JSON.stringify({
            ok: replyPayload.ok,
            count: replyPayload.items?.length,
            isEnd: replyPayload.isEnd,
            first: replyPayload.items?.[0]
              ? `${replyPayload.items[0].uname}: ${replyPayload.items[0].message.slice(0, 50)}`
              : "(none)",
            error: replyPayload.error,
          }),
        );
        expect(replyPayload.ok).toBe(true);
        expect((replyPayload.items ?? []).length).toBeGreaterThan(0);
      } finally {
        handle?.release();
        await pool.dispose();
      }
    },
    120_000,
  );
});
