import { describe, expect, it } from "vitest";
import { BrowserSessionPool } from "../src/collect";
import { PlatformPacer } from "../src/pacing";
import {
  buildXhsTokenMineScript,
  collectXiaohongshuNoteComments,
  parseXhsTokenMine,
} from "../src/sources/xiaohongshu";

/**
 * 小红书评论通道真实冒烟（生产路径：xsec_token 挖取 → 详情导航 → SSR 评论）。
 * 需 bsk + 浏览器 + 小红书已登录；首页推荐流需能加载（携带 xsec_token）。
 * 默认跳过；`DSH_SMOKE=1 pnpm vitest run --pool=threads test/xiaohongshu-comments-real.smoke.test.ts` 时执行。
 * 未登录/风控/无 token 均视为通道行为正确的明确状态。
 */
describe.skipIf(process.env.DSH_SMOKE !== "1")("小红书评论通道真实冒烟（xsec_token 路径）", () => {
  it(
    "真实会话：挖 token → 详情导航 → SSR 评论",
    async () => {
      const pool = new BrowserSessionPool("bsk", 120_000, 1, { autoLaunchChrome: false });
      const pacer = new PlatformPacer();
      const exec = {
        signal: new AbortController().signal,
        agent: { session: { header: { cwd: process.cwd() } } },
      } as never;
      try {
        // 1) 挖 token 表（首页推荐流；延迟加载 → 多等 + 重试）
        const handle = await pool.acquire(exec);
        let pairs: Array<{ noteId: string; xsecToken: string }> = [];
        try {
          await handle.run(
            exec,
            ["navigate", "--session", handle.sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", "https://www.xiaohongshu.com/explore"],
            "xhs mine navigate",
          );
          for (let attempt = 0; attempt < 3 && pairs.length === 0; attempt += 1) {
            await new Promise((r) => setTimeout(r, 6000));
            const mined = await handle.run(
              exec,
              ["evaluate", "--session", handle.sessionId, buildXhsTokenMineScript()],
              "xhs token mine",
            );
            const value = mined && typeof mined === "object" && !Array.isArray(mined)
              ? (mined as Record<string, unknown>).value ?? mined
              : mined;
            pairs = parseXhsTokenMine(value);
          }
        } finally {
          handle.release();
        }
        console.log("SMOKE tokens:", JSON.stringify({ count: pairs.length, first: pairs[0]?.noteId ?? "" }));

        if (pairs.length === 0) {
          // 首页推荐流未加载 token（风控/页面异常）——通道行为以明确状态为准
          const outcome = await collectXiaohongshuNoteComments({ pool, pacer }, exec, "6a6b1e220000000008010c93");
          console.log("SMOKE no-token fallback:", JSON.stringify({ ok: outcome.ok, reason: outcome.reason, error: outcome.error ?? "" }));
          expect(["error", "rate_limited", "login_wall"].includes(outcome.reason)).toBe(true);
          return;
        }

        // 2) 用挖到的 token 采集评论（传 token 路径）
        const { noteId, xsecToken } = pairs[0];
        const outcome = await collectXiaohongshuNoteComments({ pool, pacer }, exec, noteId, {
          maxComments: 50,
          xsecToken,
        });
        console.log(
          "SMOKE:",
          JSON.stringify({
            ok: outcome.ok,
            reason: outcome.reason,
            title: (outcome.title || "").slice(0, 50),
            count: outcome.comments.length,
            first: outcome.comments[0]
              ? { author: outcome.comments[0].author, content: outcome.comments[0].content.slice(0, 60) }
              : null,
            error: outcome.error ?? "",
          }),
        );
        // 成功拿评论 或 明确的 App 墙/风控/登录墙状态 都算通道工作正常
        const clearFailure = ["error", "rate_limited", "login_wall", "empty"].includes(outcome.reason);
        expect(outcome.ok || clearFailure).toBe(true);
        if (outcome.ok) {
          expect(outcome.comments.length).toBeGreaterThan(0);
        }
      } finally {
        await pool.dispose();
      }
    },
    180_000,
  );
});
