import { describe, expect, it } from "vitest";
import { dedupeSimilar, hammingDistance, simhashFingerprint, tokenJaccard, tokenize } from "../src/mining/simhash";

describe("simhash 近似去重", () => {
  it("相同文本指纹一致、海明距离 0", () => {
    const a = simhashFingerprint("字节后端校招面经：算法题为主，两轮技术面一轮 HR。");
    const b = simhashFingerprint("字节后端校招面经：算法题为主，两轮技术面一轮 HR。");
    expect(a).toBe(b);
    expect(hammingDistance(a, b)).toBe(0);
  });

  it("长文本微改后海明距离仍较小", () => {
    const base =
      "近年来人工智能技术发展迅速，大语言模型在文本生成、代码编写、翻译等多个领域展现出惊人的能力，" +
      "企业纷纷将其应用于实际业务场景，但同时也面临算力成本高、数据安全、幻觉等问题，需要谨慎评估风险。";
    const variant =
      "近年来人工智能技术发展迅速，大语言模型在文本生成、代码编写、翻译等多个领域展现出惊人能力，" +
      "各企业纷纷将其应用到实际业务场景，但同时也面临算力成本高、数据安全、幻觉等问题，需要谨慎评估风险。";
    const d = hammingDistance(simhashFingerprint(base), simhashFingerprint(variant));
    expect(d).toBeLessThanOrEqual(12);
  });

  it("近重复文本 bigram Jaccard 高；不同主题 Jaccard 低", () => {
    const a = "这家酒店位置很好，服务态度也不错，早餐丰富，性价比很高，推荐入住。";
    const b = "这家酒店位置很好，服务态度不错，早餐丰富，性价比高，值得推荐入住。";
    const c = "量子计算在金融风控领域的应用前景与挑战分析。";
    expect(tokenJaccard(a, b)).toBeGreaterThanOrEqual(0.45);
    expect(tokenJaccard(a, c)).toBeLessThan(0.3);
  });

  it("tokenize 输出拉丁词 + CJK bigram", () => {
    const tokens = tokenize("AI 算法题 offer 字节 面试");
    expect(tokens).toContain("ai");
    expect(tokens).toContain("算法");
    expect(tokens).toContain("法题");
    expect(tokens).toContain("offer");
  });

  it("dedupeSimilar 聚类 + 重复计数", () => {
    const items = [
      { id: "a", text: "这家酒店位置很好，服务态度也不错，早餐丰富，性价比很高，推荐入住。" },
      { id: "b", text: "这家酒店位置很好，服务态度不错，早餐丰富，性价比高，值得推荐入住。" },
      { id: "c", text: "量子计算在金融风控领域的应用前景与挑战分析报告。" },
      { id: "d", text: "量子计算金融风控应用前景与挑战分析（转载版）。" },
      { id: "e", text: "字节后端校招面经：算法题为主，两轮技术面一轮 HR。" },
    ];
    const result = dedupeSimilar(items);
    expect(result.total).toBe(5);
    // a/b 近似、c/d 近似 → 2 个非单例簇；重复数 = 2
    expect(result.duplicateCount).toBe(2);
    expect(result.clusters.length).toBe(2);
    const sizes = result.clusters.map((c) => c.size).sort((x, y) => y - x);
    expect(sizes[0]).toBe(2);
    // 独立计数 = 簇数（含单例）
    expect(result.clusterCount).toBe(3);
  });
});
