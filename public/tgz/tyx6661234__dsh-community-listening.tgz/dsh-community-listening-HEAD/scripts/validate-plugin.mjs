import { existsSync, mkdtempSync, readFileSync, rmSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join, resolve, sep } from "node:path";
import { spawnSync } from "node:child_process";
import { tmpdir } from "node:os";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const fail = (message) => {
  console.error(`plugin check failed: ${message}`);
  process.exitCode = 1;
};

const readJson = (path) => JSON.parse(readFileSync(resolve(root, path), "utf8"));
const pkg = readJson("package.json");

if (pkg.name !== "dsh-community-listening") fail(`package name must be dsh-community-listening, got ${String(pkg.name)}`);
if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/.test(String(pkg.version))) {
  fail(`version is not strict semver: ${String(pkg.version)}`);
}
if (pkg.private === true) fail("public package must not set private=true");
if (pkg.license !== "MIT") fail("license must be MIT");
if (pkg.engines?.node !== ">=20") fail("engines.node must be >=20");
if (pkg.dsh?.bundle?.patch !== "./cordis.patch.yml") fail("dsh.bundle.patch must be ./cordis.patch.yml");

for (const field of ["main", "types"]) {
  if (typeof pkg[field] !== "string" || !existsSync(resolve(root, pkg[field]))) {
    fail(`${field} target does not exist: ${String(pkg[field])}`);
  }
}
const exportRoot = pkg.exports?.["."];
for (const field of ["default", "types"]) {
  if (typeof exportRoot?.[field] !== "string" || !existsSync(resolve(root, exportRoot[field]))) {
    fail(`exports[.].${field} target does not exist: ${String(exportRoot?.[field])}`);
  }
}

for (const entry of pkg.files ?? []) {
  if (typeof entry !== "string" || entry.startsWith("!") || !existsSync(resolve(root, entry))) {
    fail(`files entry does not exist: ${String(entry)}`);
  }
}

for (const doc of ["README.md", "docs/community-crawl-stability.md", "docs/xhs-fingerprint-rotation.md"]) {
  const content = readFileSync(resolve(root, doc), "utf8");
  if (/[A-Z]:\\Users\\|D:\\agentdev\\|\/Users\//.test(content)) {
    fail(`${doc} contains a machine-local absolute path`);
  }
}

const patch = readFileSync(resolve(root, "cordis.patch.yml"), "utf8");
const ids = [...patch.matchAll(/^\s*- id:\s*([^\s#]+)\s*$/gm)].map((match) => match[1]);
const names = [...patch.matchAll(/^\s+name:\s*([^\s#]+)\s*$/gm)].map((match) => match[1]);
if (ids.length !== 1 || ids[0] !== pkg.name) fail("cordis.patch.yml must contain one insert entry matching package name");
if (names.length !== 1 || names[0] !== pkg.name) fail("cordis.patch.yml name must match package name");

const npmCommand = process.platform === "win32" ? process.env.ComSpec || "cmd.exe" : "npm";
const npmArgs = process.platform === "win32"
  ? ["/d", "/s", "/c", "npm.cmd pack --dry-run --json --ignore-scripts"]
  : ["pack", "--dry-run", "--json", "--ignore-scripts"];
const npmCache = mkdtempSync(join(tmpdir(), "dsh-community-listening-npm-cache-"));
const packed = spawnSync(npmCommand, npmArgs, {
  cwd: root,
  encoding: "utf8",
  env: { ...process.env, npm_config_cache: npmCache },
});
rmSync(npmCache, { recursive: true, force: true });
if (packed.status !== 0) {
  fail(`npm pack --dry-run failed: ${(packed.error?.message || packed.stderr || packed.stdout || "unknown error").trim()}`);
} else {
  try {
    const report = JSON.parse(packed.stdout);
    const files = new Set((report[0]?.files ?? []).map((entry) => String(entry.path).replaceAll("/", sep)));
    for (const required of ["package.json", "lib/index.mjs", "lib/index.d.mts", "cordis.patch.yml", "README.md", "LICENSE"]) {
      if (!files.has(required.replaceAll("/", sep))) fail(`packed archive is missing ${required}`);
    }
    for (const file of files) {
      const normalized = file.replaceAll("\\", "/");
      if (/^(?:insight-workspace|node_modules|\.git)(?:\/|$)/.test(normalized) || /(?:^|\/)(?:\.pacing\.json|\.crawler-health\.json|\.tmp[^/]*|tmp[^/]*)(?:\/|$)/.test(normalized)) {
        fail(`packed archive contains local state or temporary file: ${normalized}`);
      }
    }
  } catch (error) {
    fail(`could not parse npm pack report: ${error instanceof Error ? error.message : String(error)}`);
  }
}

if (process.exitCode !== 1) console.log("plugin check passed");
