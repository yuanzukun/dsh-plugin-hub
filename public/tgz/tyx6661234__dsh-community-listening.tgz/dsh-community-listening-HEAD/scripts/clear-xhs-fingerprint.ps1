﻿<#
.SYNOPSIS
  一键清除 Chrome/Edge 中小红书 (xiaohongshu.com) 的指纹 Cookie（a1 / webId / gid / abRequestId 等），
  轮换设备指纹，用于解除 XHS 对自动化请求的「导航挂起 / 低 token 命中」降权。

.DESCRIPTION
  背景（2026-08-15 实测）：小红书信任评分挂在 a1/webId 设备指纹 Cookie 上（跨重登保留）。
  仅重登 / 换号无效——web_session 重登只刷新登录态，不改变指纹评分。
  清除该站点 Cookie 后，页面会重新下发全新 a1/webId（全新指纹）。
  注意：web_session 也属于该站点 Cookie，会被一并清除 → 之后需要重新登录小红书。

.PARAMETER Browser
  chrome | edge（默认 chrome；与本机 bsk 自动拉起使用的浏览器保持一致）。
.PARAMETER ChromeProfile
  profile 目录名（默认 Default；如多 profile 用户请改成实际目录名）。
.PARAMETER Yes
  跳过交互确认；Chrome 正在运行时直接关闭它（会丢失当前打开的标签页）。
.PARAMETER DryRun
  只打印将要执行的动作，不实际删除（安全检查用）。

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\clear-xhs-fingerprint.ps1
.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\clear-xhs-fingerprint.ps1 -Browser edge -Yes
.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\clear-xhs-fingerprint.ps1 -DryRun

.NOTES
  依赖：本机 Python（用于只读/删除 SQLite 的 Cookie 库；Windows 自带 curl 不行）。
  风险：删除 Cookie 行前会先备份 Cookie DB；请勿在 Chrome 运行时手动复制该 DB。
#>
param(
  [ValidateSet("chrome", "edge")][string]$Browser = "chrome",
  [string]$ChromeProfile = "Default",
  [switch]$Yes,
  [switch]$DryRun
)

$ErrorActionPreference = "Stop"

function Find-Python {
  $cands = @(
    (Get-Command python -ErrorAction SilentlyContinue).Source,
    (Get-Command py -ErrorAction SilentlyContinue).Source,
    "$env:LOCALAPPDATA\Programs\Python\Python314\python.exe",
    "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
    "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
    "$env:USERPROFILE\anaconda3\python.exe",
    "$env:USERPROFILE\.anaconda\python.exe"
  ) | Where-Object { $_ -and (Test-Path $_) }
  return ($cands | Select-Object -First 1)
}

# ---------- 1. 定位浏览器 User Data / Cookie DB ----------
$userData = if ($Browser -eq "chrome") {
  Join-Path $env:LOCALAPPDATA "Google\Chrome\User Data"
} else {
  Join-Path $env:LOCALAPPDATA "Microsoft\Edge\User Data"
}
$profileDir = Join-Path $userData $ChromeProfile
if (-not (Test-Path $profileDir)) {
  Write-Host "[ERR] 未找到浏览器 profile: $profileDir" -ForegroundColor Red
  exit 1
}
# 新版 Chrome/Edge Cookie DB 在 profile\Network\Cookies；旧版在 profile\Cookies
$cookiesDb = Join-Path $profileDir "Network\Cookies"
if (-not (Test-Path $cookiesDb)) {
  $legacy = Join-Path $profileDir "Cookies"
  if (Test-Path $legacy) { $cookiesDb = $legacy }
  else {
    Write-Host "[ERR] 未找到 Cookie DB（$profileDir 下无 Network\Cookies 或 Cookies）" -ForegroundColor Red
    exit 1
  }
}
Write-Host "[OK] Cookie DB: $cookiesDb" -ForegroundColor Green

# ---------- 2. 确认 + 关闭浏览器（DB 被运行中的浏览器锁定） ----------
$running = Get-Process -Name $Browser -ErrorAction SilentlyContinue
if ($running) {
  Write-Host "[WARN] $Browser 正在运行（Cookie DB 被锁定，必须先关闭；会丢失当前打开的标签页）" -ForegroundColor Yellow
  if ($DryRun) {
    Write-Host "[DryRun] 将关闭 $Browser 进程"
  } else {
    if (-not $Yes) {
      $ans = Read-Host "输入 Y 确认关闭所有 $Browser 窗口并继续？(Y/N)"
      if ($ans -ne "Y") { Write-Host "已取消（可先手动保存/关闭浏览器再重跑本脚本）"; exit 2 }
    }
    Stop-Process -Name $Browser -Force -ErrorAction SilentlyContinue
    for ($i = 0; $i -lt 15 -and (Get-Process -Name $Browser -ErrorAction SilentlyContinue); $i++) {
      Start-Sleep -Seconds 1
    }
    if (Get-Process -Name $Browser -ErrorAction SilentlyContinue) {
      Write-Host "[ERR] $Browser 进程未退出，请手动结束后再运行" -ForegroundColor Red
      exit 3
    }
    Write-Host "[OK] $Browser 已关闭" -ForegroundColor Green
  }
} else {
  Write-Host "[OK] $Browser 未运行" -ForegroundColor Green
}

# ---------- 3. 备份 ----------
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = "$cookiesDb.bak-$stamp"
if ($DryRun) {
  Write-Host "[DryRun] 将备份到: $backup"
} else {
  Copy-Item $cookiesDb $backup -Force
  Write-Host "[OK] 已备份 Cookie DB: $backup" -ForegroundColor Green
}

# ---------- 4. Python 删除 xiaohongshu.com 指纹 Cookie ----------
$python = Find-Python
if (-not $python) {
  Write-Host "[ERR] 未找到 Python。请安装 Python 或改用文档里的手动方式（见 docs/xhs-fingerprint-rotation.md）" -ForegroundColor Red
  exit 4
}
$py = @'
import os, sqlite3, sys

db = sys.argv[1]
dry = len(sys.argv) > 2 and sys.argv[2] == "dry"
found = False
for suffix in ("", "-wal", "-shm"):
    p = db + suffix
    if not os.path.exists(p):
        continue
    if suffix:
        if dry:
            print(f"[DryRun] would remove sidecar {suffix}")
        else:
            os.remove(p)
            print(f"[OK] removed sidecar {suffix}")
        continue
    found = True
    if dry:
        print(f"[DryRun] would open {p} and delete xiaohongshu.com cookies")
        continue
    con = sqlite3.connect(p)
    try:
        cur = con.cursor()
        cur.execute("DELETE FROM cookies WHERE host_key LIKE '%xiaohongshu.com'")
        n = cur.rowcount
        con.commit()
        # WAL checkpoint 并截断，避免残留 WAL 把已删的行"复活"
        try:
            cur.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except Exception:
            pass
        print(f"[OK] deleted {n} xiaohongshu.com cookie rows")
    finally:
        con.close()
if not found:
    print("[WARN] cookie store file not found")
'@
$pyFile = Join-Path $env:TEMP "clear-xhs-fingerprint-helper.py"
Set-Content -Path $pyFile -Value $py -Encoding UTF8
try {
  # 注意：不要用 @arg 展开单个字符串参数——PowerShell 会把字符串按字符拆成多个参数。
  # 直接位置传参即可（DryRun 额外追加 "dry"）。
  if ($DryRun) {
    & $python $pyFile $cookiesDb "dry"
  } else {
    & $python $pyFile $cookiesDb
  }
  if ($LASTEXITCODE -ne 0) { throw "python 执行失败（exit=$LASTEXITCODE）" }
} finally {
  Remove-Item $pyFile -ErrorAction SilentlyContinue
}

# ---------- 5. 收尾提示 ----------
if ($DryRun) {
  Write-Host ""
  Write-Host "[DryRun] 以上为将执行的动作；未做任何修改。" -ForegroundColor Yellow
  exit 0
}
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "指纹 Cookie 已清除。接下来（重要）：" -ForegroundColor Cyan
Write-Host "  1) 重新打开 $Browser 访问 https://www.xiaohongshu.com/ ——页面会下发全新 a1/webId 指纹；" -ForegroundColor Cyan
Write-Host "  2) 先正常浏览（首页推荐流 → 搜一个词 → 打开一两篇笔记），让新指纹“暖机”，不要立刻跑插件；" -ForegroundColor Cyan
Write-Host "  3) 重新登录小红书（web_session 也被清除了）；" -ForegroundColor Cyan
Write-Host "  4) 等 30 分钟以上，再用 collect_xhs_search 做单轮单搜验证（插件小红书冷却基数已调至 15 分钟）。" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan



