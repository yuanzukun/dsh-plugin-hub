#!/usr/bin/env python3
"""Extract Bilibili cookies from the local Chrome/Edge profile and fill dsh-community-listening config.

Usage:
  python scripts/bilibili_cookie.py                # extract + update profile cordis.patch.yml
  python scripts/bilibili_cookie.py --login        # open temp Chrome window, wait for Bilibili login, then update
  python scripts/bilibili_cookie.py --dry-run      # only print which cookies were found (no values)
  python scripts/bilibili_cookie.py --status       # report whether bilibiliCookie is configured (no browser needed)
  python scripts/bilibili_cookie.py --check        # verify configured cookie against Bilibili nav API
  python scripts/bilibili_cookie.py --json         # print machine-readable output
"""

import argparse
import base64
import ctypes
import ctypes.wintypes
import json
import msvcrt
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


class DATA_BLOB(ctypes.Structure):
    _fields_ = [
        ("cbData", ctypes.wintypes.DWORD),
        ("pbData", ctypes.POINTER(ctypes.c_char)),
    ]


def dpapi_decrypt(blob: bytes) -> bytes:
    buf = ctypes.create_string_buffer(blob, len(blob))
    data_in = DATA_BLOB(len(blob), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    data_out = DATA_BLOB()
    if not ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(data_in), None, None, None, None, 0, ctypes.byref(data_out)
    ):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(data_out.pbData, data_out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(data_out.pbData)


def copy_file_with_share(src: Path, dst: Path) -> None:
    """Copy a file that another process (Chrome/Edge) may have open, using shared read/write/delete."""
    GENERIC_READ = 0x80000000
    FILE_SHARE_READ = 0x1
    FILE_SHARE_WRITE = 0x2
    FILE_SHARE_DELETE = 0x4
    OPEN_EXISTING = 3
    FILE_ATTRIBUTE_NORMAL = 0x80

    handle = ctypes.windll.kernel32.CreateFileW(
        str(src),
        GENERIC_READ,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        None,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        None,
    )
    if handle == -1 or handle is None:
        raise ctypes.WinError()
    try:
        fd = msvcrt.open_osfhandle(handle, os.O_RDONLY)
        with os.fdopen(fd, "rb") as srcf, open(dst, "wb") as dstf:
            shutil.copyfileobj(srcf, dstf)
    finally:
        ctypes.windll.kernel32.CloseHandle(handle)


def find_browser_profiles():
    local = os.environ.get("LOCALAPPDATA", "")
    candidates = []
    if local:
        for root in (
            Path(local) / "Google" / "Chrome" / "User Data",
            Path(local) / "Microsoft" / "Edge" / "User Data",
        ):
            local_state = root / "Local State"
            for profile in ("Default", "Profile 1", "Profile 2"):
                cookies = root / profile / "Network" / "Cookies"
                if local_state.exists() and cookies.exists():
                    candidates.append((root, local_state, cookies, profile))
    return candidates


def find_chrome_binary() -> str:
    candidates = [
        Path(os.environ.get("PROGRAMFILES", "")) / "Google" / "Chrome" / "Application" / "chrome.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Google" / "Chrome" / "Application" / "chrome.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Google" / "Chrome" / "Application" / "chrome.exe",
        Path(os.environ.get("PROGRAMFILES", "")) / "Microsoft" / "Edge" / "Application" / "msedge.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Microsoft" / "Edge" / "Application" / "msedge.exe",
    ]
    for p in candidates:
        if p.exists():
            return str(p)
    which = shutil.which("chrome") or shutil.which("msedge")
    if which:
        return which
    raise RuntimeError("Chrome/Edge not found")


def login_and_extract():
    """Launch a temporary Chrome profile, let the user log in to Bilibili, then read the unlocked cookie DB."""
    profile = Path(tempfile.mkdtemp(prefix="dsh-bili-login-"))
    chrome = find_chrome_binary()
    print("=" * 72)
    print("请在打开的浏览器窗口中登录 Bilibili。")
    print("登录完成后，直接关闭该浏览器窗口（不要关闭其他 Chrome 窗口）。")
    print("脚本会在浏览器退出后自动提取 SESSDATA 并写入 dsh-community-listening 配置。")
    print("=" * 72)
    proc = subprocess.Popen(
        [
            chrome,
            f"--user-data-dir={profile}",
            "--no-first-run",
            "--no-default-browser-check",
            "--new-window",
            "https://www.bilibili.com/",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    try:
        proc.wait()
    except KeyboardInterrupt:
        proc.kill()
        raise
    # Chrome may take a moment to release the cookie DB after exit
    cookies_db = profile / "Default" / "Network" / "Cookies"
    local_state = profile / "Local State"
    for _ in range(30):
        if cookies_db.exists() and local_state.exists():
            try:
                key = load_key(local_state)
                cookies = extract_cookies(cookies_db, key)
                if cookies:
                    return cookies, f"temp:{profile.name}"
            except Exception:
                pass
        time.sleep(1)
    raise RuntimeError("未能在临时 Chrome profile 中找到 Bilibili 登录 Cookie")


def load_key(local_state: Path) -> bytes:
    with local_state.open("r", encoding="utf-8") as f:
        data = json.load(f)
    enc = base64.b64decode(data["os_crypt"]["encrypted_key"])
    if not enc.startswith(b"DPAPI"):
        raise RuntimeError("unexpected encrypted_key prefix")
    return dpapi_decrypt(enc[5:])


def decrypt_cookie_value(value: bytes, key: bytes, meta_version: int = 0) -> str:
    if not value:
        return ""
    if value[:3] in (b"v10", b"v11"):
        try:
            payload = value[3:]
            nonce = payload[:12]
            tag = payload[-16:]
            ciphertext = payload[12:-16]
            plaintext = AESGCM(key).decrypt(nonce, ciphertext + tag, None)
            # Chrome 较新版本会在明文前附加 32 字节哈希前缀（meta version >= 24）
            if meta_version >= 24 and len(plaintext) >= 32:
                plaintext = plaintext[32:]
            return plaintext.decode("utf-8")
        except Exception:
            return ""
    try:
        return dpapi_decrypt(value).decode("utf-8")
    except Exception:
        return ""


def extract_cookies(cookies_db: Path, key: bytes):
    tmp = Path(tempfile.gettempdir()) / f"dsh-bili-cookies-{os.getpid()}.db"
    copy_file_with_share(cookies_db, tmp)
    meta_version = 0
    rows = []
    try:
        con = sqlite3.connect(str(tmp))
        try:
            try:
                row = con.execute("SELECT value FROM meta WHERE key = 'version'").fetchone()
                if row:
                    meta_version = int(row[0])
            except Exception:
                pass
            rows = con.execute(
                """
                SELECT host_key, name, path, encrypted_value
                FROM cookies
                WHERE host_key LIKE '%bilibili.com'
                ORDER BY host_key, name
                """
            ).fetchall()
        finally:
            con.close()
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass

    out = {}
    for host, name, _path, enc in rows:
        if name in out:
            continue
        value = decrypt_cookie_value(enc, key, meta_version)
        if value:
            out[name] = value
    return out


COOKIE_ORDER = [
    "SESSDATA",
    "bili_jct",
    "DedeUserID",
    "DedeUserID__ckMd5",
    "buvid3",
    "buvid4",
    "buvid_fp",
    "_uuid",
    "b_nut",
    "bili_ticket",
    "bili_ticket_expires",
    "CURRENT_FNVAL",
    "sid",
]


def build_cookie_string(cookies):
    parts = []
    for name in COOKIE_ORDER:
        if name in cookies:
            parts.append(f"{name}={cookies[name]}")
    # include any other bilibili cookies that are present
    for name, value in cookies.items():
        if name not in COOKIE_ORDER:
            parts.append(f"{name}={value}")
    return "; ".join(parts)


def update_patch_file(path: Path, cookie: str) -> bool:
    text = path.read_text(encoding="utf-8")
    quoted = json.dumps(cookie, ensure_ascii=False)
    marker = "bilibiliCookie:"
    if marker in text:
        lines = text.splitlines()
        out = []
        changed = False
        for line in lines:
            stripped = line.strip()
            if stripped.startswith(marker):
                indent = line[: len(line) - len(line.lstrip())]
                out.append(f"{indent}{marker} {quoted}")
                changed = True
            else:
                out.append(line)
        if changed:
            path.write_text("\n".join(out) + "\n", encoding="utf-8")
            return True

    anchor = "- id: dsh-community-listening\n  config:\n"
    idx = text.find(anchor)
    if idx < 0:
        return False
    insert_at = idx + len(anchor)
    text = text[:insert_at] + f"    {marker} {quoted}\n" + text[insert_at:]
    path.write_text(text, encoding="utf-8")
    return True


def profile_patch_paths():
    home = Path.home() / ".dsh" / "profiles"
    return [home / "desktop" / "cordis.patch.yml", home / "web" / "cordis.patch.yml"]


def read_configured_cookie():
    for path in profile_patch_paths():
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        m = re.search(r'^[ \t]*bilibiliCookie:[ \t]*("(?:\\.|[^"\\])*"|\'[^\']*\')', text, re.M)
        if not m:
            continue
        raw = m.group(1)
        try:
            if raw.startswith('"'):
                return json.loads(raw), str(path)
            return raw[1:-1].replace("''", "'"), str(path)
        except Exception:
            continue
    return None, None


def check_cookie(cookie):
    req = urllib.request.Request(
        "https://api.bilibili.com/x/web-interface/nav",
        headers={
            "Cookie": cookie,
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Referer": "https://www.bilibili.com/",
        },
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    return data.get("code"), data.get("data", {}).get("isLogin") if isinstance(data.get("data"), dict) else None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--login", action="store_true", help="open a temporary Chrome window and wait for Bilibili login")
    parser.add_argument("--profile", help="use an existing Chrome profile directory (e.g. a previous temp login profile)")
    parser.add_argument("--dry-run", action="store_true", help="do not write config, only report")
    parser.add_argument("--status", action="store_true", help="report whether bilibiliCookie is configured (no browser needed)")
    parser.add_argument("--check", action="store_true", help="verify configured cookie against Bilibili nav API")
    parser.add_argument("--json", action="store_true", help="machine readable output")
    args = parser.parse_args()

    if args.status:
        cookie, source = read_configured_cookie()
        print(json.dumps({
            "ok": True,
            "configured": cookie is not None,
            "source": source,
            "cookieLength": len(cookie) if cookie else 0,
        }, ensure_ascii=False))
        return 0 if cookie else 1

    if args.check:
        cookie, source = read_configured_cookie()
        if not cookie:
            print(json.dumps({"ok": False, "error": "bilibiliCookie 未配置", "source": source}, ensure_ascii=False))
            return 1
        try:
            code, is_login = check_cookie(cookie)
            print(json.dumps({
                "ok": code == 0 and is_login is True,
                "code": code,
                "isLogin": is_login,
                "source": source,
            }, ensure_ascii=False))
            return 0 if code == 0 and is_login is True else 1
        except Exception as e:
            print(json.dumps({"ok": False, "error": f"cookie 校验请求失败：{e}", "source": source}, ensure_ascii=False))
            return 1

    found_cookies = {}
    used_profile = None
    last_error = ""

    if args.profile:
        profile_dir = Path(args.profile)
        local_state = profile_dir / "Local State"
        cookies_db = profile_dir / "Default" / "Network" / "Cookies"
        try:
            key = load_key(local_state)
            found_cookies = extract_cookies(cookies_db, key)
            used_profile = str(profile_dir)
        except Exception as e:
            last_error = str(e)
    elif args.login:
        try:
            found_cookies, used_profile = login_and_extract()
        except Exception as e:
            last_error = str(e)
    else:
        profiles = find_browser_profiles()
        if not profiles:
            print(json.dumps({"ok": False, "error": "no Chrome/Edge cookie DB found"}, ensure_ascii=False))
            return 1

        for root, local_state, cookies_db, profile in profiles:
            try:
                key = load_key(local_state)
                cookies = extract_cookies(cookies_db, key)
                if cookies:
                    found_cookies = cookies
                    used_profile = f"{root.name}/{profile}"
                    break
            except Exception as e:
                last_error = str(e)

    if not found_cookies:
        print(json.dumps({
            "ok": False,
            "error": f"no bilibili cookies found: {last_error}",
            "hint": "Chrome/Edge 的 Cookie 数据库通常被浏览器进程锁定；请先关闭浏览器后重试，或使用 --login 打开临时窗口登录后自动采集",
        }, ensure_ascii=False))
        return 1

    cookie = build_cookie_string(found_cookies)
    names = sorted(found_cookies.keys())
    has_sessdata = "SESSDATA" in found_cookies

    if args.json or args.dry_run:
        print(json.dumps({
            "ok": True,
            "profile": used_profile,
            "hasSESSDATA": has_sessdata,
            "cookieNames": names,
            "cookieLength": len(cookie),
        }, ensure_ascii=False))
        if args.dry_run:
            return 0

    if not has_sessdata:
        print(json.dumps({
            "ok": False,
            "error": "SESSDATA is HttpOnly and could not be decrypted from the cookie DB",
            "profile": used_profile,
            "cookieNames": names,
        }, ensure_ascii=False))
        return 1

    targets = profile_patch_paths()
    updated = []
    for target in targets:
        if target.exists():
            if update_patch_file(target, cookie):
                updated.append(str(target))
            else:
                print(json.dumps({"ok": False, "error": f"cannot update {target}"}, ensure_ascii=False))
                return 1

    print(json.dumps({
        "ok": True,
        "profile": used_profile,
        "hasSESSDATA": True,
        "cookieNames": names,
        "updated": updated,
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
