# 小红书指纹轮换指南（重登无效时的正解）

> 结论先行（2026-08-15 实测）：小红书信任评分挂在 **设备指纹 Cookie（`a1` / `webId` / `gid` / `abRequestId`）** 上，`web_session` 登录态是另一个维度。指纹 Cookie **跨重登保留**（Chrome Cookie DB 时间戳：a1/webId 创建于 3 天前，重登只刷新了 web_session/id_token）。所以：
>
> - 重登 ❌ 无效；换号 ❌ 大概率同样无效（同一指纹）；
> - **清除 xiaohongshu.com 站点数据（轮换指纹）✅ 有效**；换浏览器 profile / IP 也有效。

## 一、什么症状说明需要清指纹

| 症状 | 说明 |
|---|---|
| 导航挂起 | `collect_xhs_search` 报「小红书导航超时（20s RPC 超时）」，重试仍挂；页面永不 commit，连 evaluate 都超时 |
| 反复 `rate_limited` | 冷却结束后单搜仍被拦，strikes 持续上涨 |
| 重登后 `tokenHitRate` 不变 | 登录态确认（sessionUser=true）但 token 命中率仍 ~15% |
| curl 直连正常、浏览器挂起 | 网络层通（curl 0.5s 内 301→200），只有带指纹的浏览器被挂 → 指纹问题实锤 |

## 二、方法 A：手动方式（最安全，推荐先试）

1. 打开 Chrome，访问任意小红书页面；
2. 点击地址栏左侧 🔒 图标 →「Cookie 和网站数据」→「管理 Cookie 和网站数据」；
   （或直接打开 `chrome://settings/content/all`，搜索 `xiaohongshu`）
3. 删除 `xiaohongshu.com`（含 `www`、`edith` 等子域）的全部条目；
4. 关闭所有小红书标签页，**完全退出 Chrome**（任务栏右键退出），再重新打开；
5. 访问 `https://www.xiaohongshu.com/` —— 页面会下发全新 `a1`/`webId`。

> Edge 用户：`edge://settings/content/all` 同理。可选补充：DevTools → Application → Local Storage → `https://www.xiaohongshu.com` → 清空（清除签名种子 `b1`/`b1b1`，更彻底）。

## 三、方法 B：一键脚本（推荐）

```powershell
# 从 dsh-community-listening 仓库目录执行（DryRun 先看会做什么，安全）
powershell -ExecutionPolicy Bypass -File scripts\clear-xhs-fingerprint.ps1 -DryRun

# 实际执行（Chrome 正在运行时会先确认关闭，也可加 -Yes 跳过确认）
powershell -ExecutionPolicy Bypass -File scripts\clear-xhs-fingerprint.ps1

# Edge 用户
powershell -ExecutionPolicy Bypass -File scripts\clear-xhs-fingerprint.ps1 -Browser edge -Yes
```

脚本做了什么：

1. 定位浏览器 Cookie 库（`%LOCALAPPDATA%\Google\Chrome\User Data\<profile>\Network\Cookies`，Edge 同理，兼容旧路径）；
2. 检查浏览器是否运行——运行中会先确认后关闭（DB 被锁，必须关）；
3. **备份** Cookie 库为 `Cookies.bak-<时间戳>`；
4. 用 Python 删除 `host_key LIKE '%xiaohongshu.com'` 的全部 Cookie（`a1`/`webId`/`gid`/`abRequestId`/`web_session`/`id_token` 等），并做 WAL checkpoint 截断，防止残留 WAL 把已删的行"复活"；
5. 输出后续步骤提示。

依赖：本机 Python 3.11 或更高版本。

## 四、清完指纹后必做（顺序很重要）

1. **重新打开 Chrome 访问小红书首页**——让服务端下发全新 `a1`/`webId`；
2. **暖机**：先正常浏览（首页推荐流 → 搜一个词 → 打开一两篇笔记），**不要立刻跑插件**；新指纹没有历史信任，直接自动化容易又被标；
3. **重新登录**（`web_session` 也被清了）；
4. **等待 ≥30 分钟**，再用 `collect_xhs_search` 做**单轮单搜**验证（插件侧小红书冷却基数已调至 15 分钟，strikes 退避会自动加长）；
5. 看新字段：`loginState.sessionUser=true` + `tokenHitRate` 是否显著上升；若导航仍挂，说明 IP 层面也被标（换 IP / 换 profile 再试）。

## 五、FAQ

- **Q：脚本会删掉我其他网站的登录态吗？**
  A：不会，只删 `host_key` 含 `xiaohongshu.com` 的 Cookie。
- **Q：多 Chrome profile 怎么办？**
  A：加 `-ChromeProfile Profile 1`（目录名）。注意插件 auto-launch 用的是 **Default** profile，指纹要清就清 Default。
- **Q：脚本说「Chrome 正在运行」但我不想关浏览器？**
  A：脚本要求浏览器完全退出（DB 锁定 + 防止 WAL 复活）。不想关就用手动方式 A。
- **Q：清了指纹还是被挂？**
  A：说明 IP/出口也被标记，或新指纹立即被自动化行为再次标记。换 IP（代理/热点）、换 profile，并严格执行「暖机 + 降频多轮」。
- **Q：能不能做成 GUI 里的插件工具？**
  A：可以，但需要在 browserskill 扩展/bsk CLI 暴露 CDP `Storage.clearDataForOrigin` 之类的能力；当前版本先以本脚本 + 手动方式兜底。

## 六、与插件配合的记忆点

- 旧版 `loginState.cookieHasWebSession` 恒为 false（HttpOnly），**不要**再据此判断登录；看 `sessionUser` / `loginWallText`。
- token 低命中且 `sessionUser=true` → 服务端指纹降权（清指纹/换 IP），不是账号问题。
- 插件 `PlatformPacer` 对小红书冷却基数已从 60s 调至 900s（15 分钟），避免过早重试加深标记。
