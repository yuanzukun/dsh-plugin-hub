# 社区内容爬取稳定性方案 —— 对照 OpenBiliClaw 的改造路线

> 范围：dsh-community-listening（插件根目录）的社区内容采集（知乎 / 小红书 / B 站 / 牛客 / 微博等）。
> 参考：https://github.com/whiteguo233/OpenBiliClaw（v0.3.205，MIT，2.2k stars，本地开源跨平台内容发现 Agent，且官方支持 DeepSeek Harness 插件，与本项目场景高度同构）。
> 日期：2026-08-15

---

## 0. TL;DR

dsh-community-listening 当前的采集链路是「undici fetch（仅浏览器 UA）→ bsk 浏览器（navigate + observe/snapshot）→ LLM 提取」。它不稳定不是单点故障，而是**结构性缺陷**：

1. **通道单一且无登录态**：fetch 无 TLS/JA3 指纹、无 stealth、无 cookie 持久化 → 知乎/B站/小红书直连 403 / 验证码；浏览器路径复用的是无登录态的会话（或用户默认 profile，但从不确认登录了哪些站）→ 登录墙。
2. **DOM/aria 提取脆弱**：评论「展开」靠 snapshot 文本找按钮，站点改版即失效；observe 整页文本再 LLM 提取，token 贵、内容漏（懒加载/虚拟滚动不触发）。
3. **无平台级风控意识**：并发 5 个浏览器会话同时打同一平台；失败即返回，没有指数退避、没有冷却窗口、没有熔断器；还继承了系统代理（Clash）出口，部分平台对代理出口 IP 风控更严。
4. **无官方 API / 逆向 API 通道**：B 站 WBI 签名 API、知乎官方 API、Bangumi/V2EX 匿名 API 这些「稳定、结构化、省浏览器」的通道一条都没有。

OpenBiliClaw 用一套**多通道降级链 + 平台级熔断/节流 + 浏览器扩展任务桥（登录态复用）+ 被动采集**的架构解决了同一类问题。下文先诊断现状，再拆解可借鉴机制，最后给三阶段落地路线（P0 低风险立即可做 / P1 核心改造 / P2 长期）。

**一句话结论**：优先做 P0+P1 —— ① 平台级冷却/退避/熔断（成本最低、收益最直接）；② 知乎/小红书评论采集从「DOM 展开」改为「登录态 cookie + 官方/逆向 API 分页拉取」（一劳永逸解决最常抱怨的不稳定）；③ B 站 WBI 签名 API 直连通道。浏览器扩展任务桥是 P2 重投入，视需求决定。

---

## 1. 现状诊断：为什么不稳定（对照源码）

### 1.1 网络层：`src/net.ts`

| 问题 | 证据 | 后果 |
|---|---|---|
| 无 TLS/JA3 指纹，仅浏览器 UA | `fetchPage()` 只设 `user-agent/accept/accept-language`（net.ts:192-199）；collect.ts:7 注释自认「v1 不做 TLS/JA3 指纹、stealth」 | 知乎/小红书/B站等大站对无指纹 TLS 握手直接 403/重定向到验证码，fetch 快路径大面积失效 |
| 无 cookie 持久化 | 每次 fetch 无 cookie jar；`fetchPage` 无状态 | 即使有登录态也无法复用；验证码/登录墙只能靠启发式兜底 |
| 继承系统代理 | `proxyDispatcherFor()` 走 WinINET 代理（net.ts:55-79） | 国内社区平台对代理出口 IP 风控更严（OpenBiliClaw 特意 `trust_env=False`，见 bilibili/api.py:300-306，注释明确「B站风险控代理出口 IP，会让已登录用户显示未登录」） |
| 无重试/退避 | `fetchPage` 单次 15s 超时，失败即抛 | 瞬时抖动直接导致整批失败 |

### 1.2 浏览器路径：`src/collect.ts`

| 问题 | 证据 | 后果 |
|---|---|---|
| 依赖 bsk 会话，无稳定登录态 | `BrowserSessionPool` 自动拉起 Chrome：默认 profile（登录态保留，但**不确认**登录了哪些站）或 `chromeProfileDir` 专属 profile（**全新、无登录态**）（collect.ts:240-283） | 小红书/知乎/B站详情页登录墙，`looksLikeLoginWall` 命中 → 返回 failed |
| 提取依赖 observe/snapshot 文本 | `browserPageText()`：navigate → 关弹窗 → observe/snapshot → 整页文本（collect.ts:457-502） | aria 树/页面结构一变就提取失败；懒加载内容不触发；每页几万字送 LLM，token 成本高 |
| 评论展开是 best-effort | `findExpandRefs()` 在 snapshot 文本里找「展开/加载更多/回复」按钮（collect.ts:400-413），`collectComments()` 最多 3 轮且「无新内容即停」（collect.ts:731-752） | 只拿到首屏几条评论；知乎回答列表、小红书楼中楼几乎拿不全 |
| 无平台级节流 | `Semaphore` 只管本批并发（上限 5），跨批次、跨工具无共享冷却 | 用户连续两次 collect 同一平台 = 双倍打请求；平台限流 → 验证码 → 体验更差 |
| 无失败重试/熔断 | 失败返回 `failed/captcha` 即止（collect.ts:631-636） | 没有「退避后重试」「换通道」的自动化，全靠用户手动换工具 |

### 1.3 通道拓扑

```
fetch（undici，无指纹） ──403/验证码──▶ 浏览器（bsk，无登录态/无节流） ──失败──▶ 返回 failed/captcha
```

没有任何第三通道（官方 API / 逆向签名 API / cookie 直连），也没有任何「平台冷却状态」横跨批次生效。

---

## 2. OpenBiliClaw 机制拆解：值得借鉴的部分

OpenBiliClaw 的架构（`src/openbiliclaw/sources/` + `extension/`）核心是一条**通道分级 + 稳定化层**：

### 2.1 通道分级（每平台多通道，按稳定性降级）

| 通道 | 平台 | 参考实现 | 核心思想 |
|---|---|---|---|
| **官方/逆向 API 直连** | B站（WBI 签名）、Bangumi（匿名 v0 API）、V2EX（匿名 API/Feed） | `src/openbiliclaw/bilibili/api.py`、`bangumi_client.py`、`v2ex_client.py` | 无浏览器、结构化、省 LLM；B 站 API 是主通道，插件搜索页只作降级兜底 |
| **浏览器扩展任务桥**（登录态复用） | 小红书、抖音、知乎、Reddit、X | `xhs_tasks.py` + `extension/src/background/xhs-task-dispatcher.ts` + `extension/src/content/xhs/*` | 后端下发任务（next-task 领取）→ 扩展在**用户已登录的真实浏览器**执行 → task-result 回传。**后端不代登录、不爬用户看不到的内容** |
| **CLI 工具 + cookie 重放** | Reddit（rdt-cli）、X（twitter-cli） | `reddit_tasks.py`、`twitter_adapter.py` | 服务端只读 cookie 重放，比浏览器 DOM 稳定 |
| **通用 Web** | 任意网页 | `web_adapter.py`（Playwright/agent-browser + LLM 抽取） | 没有专属通道的兜底 |

**关键点**：每个平台都有「优先稳定通道」+「降级通道」。B 站 API 被限流时激活扩展 DOM 搜索兜底（`_activate_search_dom_fallback`，api.py:335-347），而不是直接失败。

### 2.2 稳定化层（解决「不稳定」的机制本体）

1. **平台级熔断器（指数退避，持久化）**
   - `XhsTaskQueue.record_rate_limit()`（xhs_tasks.py:610-758）：平台冷却 `base_cooldown * 2^strikes`（cap 30 次方，最长 `XHS_RATE_LIMIT_MAX_COOLDOWN_SECONDS`），状态存 SQLite **跨后端重启、跨 MV3 service-worker 重启存活**；同一冷却期内的重复上报只共享一次 strike、只能延长不能缩短安全窗口。
   - B 站搜索冷却分级退避：`_activate_search_cooldown()`（api.py:349-368），base 180s × level（1-3），cap 1800s；`v_voucher` 连续失败 ≥3 次才触发全路径冷却（单关键词瞬时失败不殃及整轮）。

2. **任务领取门（原子、防重、防卡死）**
   - `next_pending()`（xhs_tasks.py:760+，zhihu_tasks.py:479-515）：`BEGIN IMMEDIATE` 原子领取 → 标记 `in_progress` + `claimed_at`（防止多扩展实例/重启重复执行）→ **15 分钟 stale 回收**（崩溃的扩展不会永久卡死队列）→ 领取间隔 + jitter。
   - 每日预算：`_budgeted_count_today()`（zhihu_tasks.py:460-477），知乎任务按 type 限每日量。
   - 扩展侧 dispatcher mutex：`dispatcher-mutex.ts`（6 分钟 stale），防 service-worker 并发。

3. **被动采集哲学（小红书风控最关键的一条）**
   - `extension/src/content/xhs/passive.ts:5-7`：「The collector never scrolls — it only reacts to the user's own scrolling. Auto-scroll bots are a textbook xhs risk-control signal」。
   - 即：不自动滚动、不自动翻页、不模拟人类操作；只在用户自然浏览时采集视口内的 URL + 卡片元数据。

4. **MAIN-world 响应桥（结构化数据，替代 DOM/aria）**
   - `extension/src/content/xhs/search-response-buffer.ts` + `search-response-replay`：搜索任务在真实页面触发后，**直接捕获页面网络响应（结构化 JSON）** 并回传，而不是观察 DOM/aria 树。抖音同理（`dy/dom-extractor.ts` + MAIN-world 被动 fetch tap）。
   - 知乎/小红书楼中楼、评论、回答列表全部走 API 响应，天然稳定、免 LLM。

5. **扩展任务桥协议（后端 ↔ 扩展）**
   - 后端 `POST /api/sources/<slug>/next-task` → 扩展领取 → 执行 → `POST /api/sources/<slug>/task-result`（task_result_protocol.py：staged 终态 + 幂等 merge，丢失响应可恢复）。
   - 扩展侧定时轮询（45s）+ 任务超时分级（搜索 30s / bootstrap 滚动型最长 360s）。

6. **安全取数 + 风控纪律**
   - 后端不代登录；登录态只在用户浏览器里；任务 tab 只读 GET（Linux.do）；微博心跳只回传登录布尔。
   - 小红书任务「关闭或限流时不开新 tab」（README 架构图）；XHS 风控冷却时后端不派新任务。

7. **统一归一化协议**
   - `SourceAdapter`（protocol.py）：所有平台实现 `fetch(recipe) -> list[DiscoveredContent]`，强制 `content_id/content_url/source_platform`；小红书 adapter 是 no-op，数据从扩展经 API 进统一候选池。上层流水线（候选池 → 评估 → 多样性）与平台无关。

---

## 3. 落地路线（针对 dsh-community-listening）

### P0 —— 低风险加固（1~2 天，立竿见影）

**P0-1 平台级冷却/退避/熔断（收益最高，先做）**

- 新增 `platformPacing` 模块（内存 + JSON 落盘到会话目录，或直接复用语料根 `.pacing.json`）：
  - 平台键：`zhihu` / `xiaohongshu` / `bilibili` / `weibo` / `nowcoder` / `generic`（按 host 映射）。
  - 事件：`captcha` / `403` / `rate_limited` / `login_wall` → 触发平台冷却，`base * 2^strikes`（如 60s 起步，cap 30min），跨工具、跨批次生效。
  - 冷却期内对该平台的浏览器采集自动降级为「只 fetch / 直接跳过并说明」。
- 在 `collect.ts` 的 `collectFetchFast` / `collectBrowserPath` / `collectComments` 的失败分支上报事件；`batchCollect` 阶段 2 前检查冷却。
- 给 `fetchPage` 加重试（单次瞬时失败，指数退避 2 次）与**平台感知的最小请求间隔**（同一平台串行化，参考 `_respect_rate_limit()`，api.py:316-322）。

**P0-2 代理出口策略（平台分级）**

- `proxyDispatcherFor()` 改为**国内社区平台直连**（zhihu/xiaohongshu/bilibili/nowcoder/weibo 等走本机直连，不走 Clash），海外站才走代理——对齐 OpenBiliClaw `trust_env=False` 的教训。可配置开关（`config.bypassProxyHosts`）。

**P0-3 登录态复用（先做最简单的）**

- 浏览器路径默认**优先使用用户默认 Chrome profile**（当前 `chromeProfileDir` 为空时已经是，但需在工具返回里**明确告知当前登录了哪些站**，让用户在 GUI 里确认/登录一次）。
- 增加 `config.requireLoggedIn: string[]`：对指定的平台，`collectBrowserPath` 命中登录墙时返回**可执行建议**（「请在浏览器里登录 xxx 后重试」），而不是笼统 failed。

### P1 —— 核心改造（3~5 天，解决最常抱怨的不稳定）

**P1-1 知乎：官方 API 直连（替代 DOM 展开）**

- 知乎回答/评论走官方 API：`GET https://www.zhihu.com/api/v4/questions/{qid}/answers?include=...&offset=&limit=`（需登录 cookie + `x-zse-96` 签名，实现见公开的 zse-96 算法）。
- 落点：`collectComments` 对 `zhihu.com/question/*` 分流到「API 分页拉取（offset 翻页到 max_expand 对应的量）」→ 稳定拿到全部回答，替代 snapshot 找按钮。需先 `chromeProfileDir` 或默认 profile 里登录知乎一次，把 cookie 导出/持久化给后端（或做成 P1-4 的响应桥）。
- 风险：zse-96 签名可能随版本变化，需留「API 失败 → 回退 DOM 展开」降级。

**P1-2 小红书：API/响应桥采集（替代 DOM 观察）**

- 方式 A（后端直连，简单）：小红书笔记详情 `GET https://www.xiaohongshu.com/api/sns/web/v1/feed?source_note_id=` + 搜索 `.../web/v1/search/notes?keyword=`（需要 `a1`/`web_session` cookie + `x-s`/`x-t` 签名；签名实现有公开复刻）。
- 方式 B（响应桥，稳定）：在 bsk 会话里注入 content script，捕获页面 fetch/XHR 响应（对齐 `search-response-buffer.ts`），从网络层拿结构化 JSON。
- 建议先做 A（不依赖注入框架），失败回退 B/浏览器。

**P1-3 B 站：WBI 签名 API 直连通道**

- 新增 `bilibiliApi` 模块：`_get_wbi_keys()`（nav 接口拿 img/sub key，5 分钟 TTL）+ `_sign_wbi_params()`（mixin key + wts + md5）。**算法是公开且可复刻的**（bilibili/api.py:494-553，MIT 可直接参考）。
- 用途：搜索 / 视频详情 / 评论分页，替代「浏览器打开 B 站页面」。
- 带上登录 cookie（SESSDATA/bili_jct）后还能读用户收藏/关注（若需要）；不登录也可匿名搜索。

**P1-4 通用「响应桥」能力（一次性投入，惠及知乎/小红书/牛客）**

- 在 `BrowserSessionPool` 之上加一层「页面网络捕获」：bsk 会话 navigate 后，注入脚本监听 `performance.getEntriesByType('resource')` / 挂钩 XHR，把匹配平台 API 的响应体取回。
- 这样评论/列表类采集从「观察 DOM」变成「读结构化响应」，站点改版不再打挂采集。

### P2 —— 长期（按需求决定投入）

**P2-1 自有 MV3 浏览器扩展（任务桥）**

- 做 dsh-community-listening 自己的 Chrome/Edge 扩展：用户安装一次、登录各站，采集任务通过 `next-task / task-result` 协议下发到用户真实浏览器执行；后端零代登录、零代滚动。直接复用 OpenBiliClaw 的扩展思路与协议设计（MIT，可参考 `extension/src/` 与 `xhs_tasks.py`）。
- 收益：彻底解决登录墙 + 风控（真实用户环境、被动采集）；成本：一个扩展仓库 + 协议维护。
- **替代方案**：直接用 OpenBiliClaw 现成的 `dsh-openbiliclaw` 插件（官方 DeepSeek Harness 客户端插件）——如果你们的诉求主要是「内容发现」，装它的插件即可，不必自研；如果诉求是「把社区内容送进 dsh-community-listening 的语料管线做分析」，则自研扩展或调它的本地 API 喂语料。

**P2-2 官方匿名 API 优先**

- Bangumi / V2EX / 微博公开发现：OpenBiliClaw 有现成 client（`bangumi_client.py` / `v2ex_client.py` / `weibo.py`，MIT），可直接借鉴移植为 dsh-community-listening 的采集通道（这几类源适合「公开社区内容」，且完全不用浏览器）。

**P2-3 统一候选池 + 去重 + 评估流水线**

- 多通道候选进统一池，canonical URL 去重（当前已有 `normalizeUrl`，可升级为平台规则化：知乎 `zhuanlan` 与 `question` 归一、小红书 `xsec_token` 保留等）。
- 评估/打分与平台解耦（对齐 `SourceAdapter` 协议思想），让新增平台只是「加一个 adapter」。

---

## 4. 优先级矩阵

| 项 | 收益 | 成本 | 风险 | 建议 |
|---|---|---|---|---|
| P0-1 平台冷却/退避/熔断 | ★★★★★（直接消除「越采越被封」） | 低（0.5~1 天） | 低 | **本周做** |
| P0-2 代理出口分级 | ★★★★（知乎/B站直连成功率立升） | 极低（半小时） | 低 | **本周做** |
| P0-3 登录态复用 + 提示 | ★★★（减少登录墙挫败） | 低 | 低 | 本周做 |
| P1-1 知乎 API 直连 | ★★★★★（评论区最大痛点） | 中（1~2 天，含签名） | 中（签名随版本变，需降级） | 下周做 |
| P1-2 小红书 API/响应桥 | ★★★★★ | 中高 | 中高（签名/风控严） | 与 P1-4 合并评估 |
| P1-3 B 站 WBI 通道 | ★★★★ | 中（算法现成） | 低（匿名也可用） | 下周做 |
| P1-4 响应桥能力 | ★★★★（一劳永逸） | 中 | 中 | 与 P1-1/2 合并 |
| P2-1 自有扩展 | ★★★★★ | 高（重投入） | 中 | 先评估「装现成 dsh-openbiliclaw」 |
| P2-2 官方 API 源 | ★★★ | 低 | 低 | 顺手做 |
| P2-3 候选池/评估 | ★★★ | 中 | 低 | 按产品方向定 |

**建议路径**：本周 P0 全部 → 下周 P1-1（知乎）+ P1-3（B站）→ P1-2/1-4 视小红书需求优先级 → 季度评估 P2-1 是自研还是直接用现成插件。

---

## 5. 风险与边界（务必知悉）

1. **逆向签名（zse-96 / x-s / WBI）的合规与维护风险**：签名算法属逆向工程，可能随平台风控更新而失效；务必「API 失败自动降级浏览器」，不要把 API 通道做成唯一通道。WBI（B 站）相对稳定且广泛公开，风险最低。
2. **账号风控**：所有带登录态的采集都作用于真实账号。OpenBiliClaw 的纪律必须照搬：被动采集（不自动滚动）、平台冷却（限流即停）、不并发多会话打同一平台（当前 batch_collect 并发 5 就偏激进，建议按平台降并发）。
3. **cookie 安全**：登录态 cookie 是敏感凭据，落盘前需确认权限（当前工作区已 workspace-write）；不要回传/外发。
4. **不要在测试环境用真实账号高频打 API**：先用匿名/低敏查询验证通道，再上登录态。
5. **OpenBiliClaw 是 MIT**，源码可参考/移植，但**注意区分「借鉴机制」与「搬运代码」**：其 Python 后端需翻译为 dsh-community-listening 的 TS/Cordis 架构；扩展协议可以直接借鉴设计，代码逐行移植成本不低。

---

## 6. 附：OpenBiliClaw 关键文件索引（对照查阅）

| 机制 | 文件 |
|---|---|
| B 站 WBI 签名 / 速率控制 / 冷却退避 | `src/openbiliclaw/bilibili/api.py`（重点 316-390、494-553） |
| 小红书任务队列（熔断器 / 领取门 / stale 回收） | `src/openbiliclaw/sources/xhs_tasks.py`（610-758、760-863） |
| 知乎任务队列（每日预算 / 领取门） | `src/openbiliclaw/sources/zhihu_tasks.py`（460-515） |
| 任务结果协议（staged 终态 / 幂等 merge） | `src/openbiliclaw/sources/task_result_protocol.py` |
| 被动采集哲学（不滚动） | `extension/src/content/xhs/passive.ts`（1-11 行注释） |
| MAIN-world 响应桥 | `extension/src/content/xhs/search-response-buffer.ts`、`extension/src/content/dy/dom-extractor.ts` |
| 扩展任务调度（轮询 / 超时分级 / mutex） | `extension/src/background/xhs-task-dispatcher.ts`、`extension/src/background/dispatcher-mutex.ts` |
| 统一适配协议 | `src/openbiliclaw/sources/protocol.py` |
| 官方匿名 API 客户端 | `src/openbiliclaw/sources/bangumi_client.py`、`v2ex_client.py`、`weibo.py` |
| 通用 Web 适配（浏览器 + LLM 抽取） | `src/openbiliclaw/sources/web_adapter.py`、`llm_extractor.py` |
| 架构总览 | `docs/architecture.md`、`docs/spec.md` |

---

## 7. 实施记录（2026-08-15：知乎 + B 站稳定评论爬取）

按本方案 P0-P1 范围已落地第一轮实现，全部单元测试通过（90 passed / 11 skipped，`vitest --pool=threads`）、`tsc --noEmit` 与 `pnpm build` 全绿。

### 已交付

| 模块 | 文件 | 说明 |
|---|---|---|
| 平台节流/冷却/退避 | `src/pacing.ts`（新） | 指数退避 `base×2^strikes`（zhihu 60s / bilibili 30s / xiaohongshu 60s 起步，cap 30min）；冷却期内共享 strike 只延长窗口；`login_wall` 不冷却；同平台最小间隔串行化；状态可选落盘 JSON（跨进程存活）、原子写、损坏容错 |
| 知乎 API 通道 | `src/sources/zhihu.ts`（新） | bsk 会话内同源 fetch `/api/v4/questions/{qid}/feeds` + `/api/v4/answers/{aid}/comments`，`credentials: include`，**免 zse-96 逆向**；大整数 id 字符串化；失败分 unavailable / login_wall / error 三类；evaluate 超时单轮重试 |
| B 站 API 通道 | `src/sources/bilibili.ts`（新） | 后端直连 `/x/web-interface/view`（bvid→aid）+ `/x/v2/reply/main`（游标分页）+ `/x/v2/reply/reply`（楼中楼），**无签名、零浏览器依赖**；412/-412 → rate_limited + 平台冷却；可选登录 Cookie（`bilibiliCookie` 配置，敏感仅本机） |
| 评论入口分流 | `src/collect.ts` | `collect_comments` 按 URL 路由：知乎问题页 → API 通道（bsk 不可用/异常降级浏览器），B 站视频页 → API 通道（错误降级浏览器），其余原路径；平台冷却中直接跳过并说明；返回 `strategy`（zhihu-api / bilibili-api / browser） |
| 类型/工具/配置 | `src/types.ts`、`src/tools.ts`、`src/index.ts` | `CommentMineResult.strategy`；工具描述与输出 schema 更新；新配置 `zhihuMaxAnswers`（50）/`zhihuMaxAnswerComments`（10）/`bilibiliMaxComments`（100）/`pacingStateFile`/`bilibiliCookie`，全部带默认向后兼容 |
| 测试 | `test/pacing.test.ts`、`test/sources-zhihu.test.ts`、`test/sources-bilibili.test.ts`、`test/collect-split.test.ts`（新） | 退避计算/strike 共享/落盘恢复/host 映射；URL 解析/脚本生成/负载解析/归一化（含大整数 id、target 解包）；B 站全流程 mock（view→分页→楼中楼、412 冷却、空评论）；通道路由 |

### 环境实测发现（重要）

1. **本机 B 站匿名 API 直连被 412 拦截（HTTP 412 + code -412）**：主页 200 + 拿到 buvid3 后 view 接口仍 412 → 是**出口 IP 风控**（OpenBiliClaw 文档原话：代理/机房出口 IP 会被 B 站风控），不是签名或 cookie 问题。冒烟恰好验证了通道的失败路径（-412 → bilibili 平台冷却 30s 起步，正确进入退避）。带登录 Cookie（`bilibiliCookie` 配置 SESSDATA）可显著提高可用性；匿名请求在非风控出口（住宅 IP）下可用。
2. **bsk evaluate 输出形状**：`bsk evaluate --json` 实际返回 `{ ok, tab_id, value }`（value 为表达式结果）——`unwrapEvaluateValue` 已按此形状兼容（另保留 `{result}` 兜底）。
3. **vitest 默认 forks 池在本沙箱 EPERM**（child_process fork 的 named-pipe 限制）：`package.json` 的 `test` 脚本已固定 `--pool=threads`。

### 后续追加交付（重启后完成）

| 项 | 文件 | 说明 |
|---|---|---|
| P0-2 代理出口分级 | `src/net.ts`、`src/index.ts`、`test/net-proxy.test.ts`（新） | 国内社区平台（知乎 / B站 / 小红书 / 牛客 / 微博 / 抖音）默认**直连不走系统代理**（避免代理出口 IP 被平台风控，对齐 OpenBiliClaw `trust_env=False` 教训）；海外站默认走系统代理；新配置 `bypassProxyHosts` 追加直连后缀；`shouldBypassProxy` 纯函数可测 |
| **B 站浏览器同源兜底**（第 1 点建议的自动版） | `src/sources/bilibili.ts`、`src/collect.ts`、`test/bilibili-real.smoke.test.ts`（新） | 后端 API 直连被 412（出口 IP 风控）时，自动降级到 bsk 会话内**跨域 fetch** `api.bilibili.com`（浏览器真实指纹可绕过后端 412；`credentials: include` 复用浏览器登录态）；navigate → view（aid）→ reply/main 游标分页；浏览器兜底不拉楼中楼（控制 evaluate 轮数） |
| **WBI 签名移植**（第 2 点） | `src/sources/bilibili.ts` | `extractWbiKeyComponent` / `buildWbiMixinKey`（打乱表）/ `signWbiParams`（Python `quote_plus(safe='')` 编码语义 + wts + md5）/ `WbiKeyStore`（5min TTL）；主接口 `/x/v2/reply/main` 异常（如未来要求签名）时自动重试 `/x/v2/reply/wbi/main` |
| 真实冒烟测试 | `test/zhihu-real.smoke.test.ts`、`test/bilibili-real.smoke.test.ts`（新，默认跳过） | 真实 bsk 会话跑采集链路；`DSH_SMOKE=1 pnpm vitest run --pool=threads test/*-real.smoke.test.ts` 时执行 |
| 知乎评论 author 宽松兜底 | `src/sources/zhihu.ts` | 评论接口匿名/部分场景 author 为空对象或缺失，提取改为 `it.author.name ?? it.author` 兜底 |

### 知乎通道真实冒烟结果（2026-08-15，真实 bsk 会话）

- 问题页 `zhihu.com/question/597272501`（「全职儿女」）：feeds API 同源 fetch 返回 **200**，3 条真实回答（作者/内容/赞同数/评论数齐全）；评论 API 返回 **200**，单回答 20 条评论内容完整。
- `collectZhihuAnswers` 集成验证：`ok: true, reason: "success"`，3 条回答 + 2 条带评论区，12.3s（含页面加载），全程无 snapshot/DOM 展开。
- **结论：知乎通道（bsk 同源 fetch，免 zse-96 逆向）在生产路径上可用。** 未登录时会走 `login_wall` 明确提示（已在单元测试与降级逻辑覆盖）。

### B 站通道真实连通验证（第 3 点，2026-08-15）

1. **后端 Node fetch 直连 → 412 确认是「客户端特征风控」而非纯 IP 风控**：同一出口、同一时刻，Node undici fetch 返回 HTTP 412 + code -412；**浏览器内跨域 fetch `api.bilibili.com` 返回 200**（热门接口 / view / reply/main 全部正常，20 条真实评论 + 游标分页）。
2. **浏览器兜底通道成立**：`buildBilibiliViewScript` / `buildBilibiliReplyMainScript`（跨域绝对 URL + `credentials: include`）在真实会话跑通（`test/bilibili-real.smoke.test.ts`：view ok + reply 20 条 + isEnd false）。
3. **www 域相对路径不可用**（`/x/web-interface/view` 404）——脚本必须用 `https://api.bilibili.com/...` 绝对 URL（已据此实现）。
4. 因此 `bilibiliCookie` 配置不再必需：浏览器兜底自动复用浏览器环境；该配置保留作为后端直连通道的登录态增强（非风控网络 / 需要登录态接口时）。

### 待办（后续迭代）

- WBI 搜索通道（`/x/web-interface/wbi/search/type` 等搜索场景）——当前评论已够；搜索需求出现时复用已移植的 `signWbiParams`。
- 牛客评论 API 通道——下一轮按同样「API 优先 + 浏览器同源兜底 + 冷却」模式接入。

---

## 8. 小红书社区爬取稳定化（2026-08-15）

### 实测结论（真实 bsk 会话）

1. **无登录态（无 web_session cookie）**：搜索页首屏卡片（标题/作者/日期/互动数/noteId）可从已渲染 DOM 稳定读取；**笔记详情与评论需登录态 + xsec_token，匿名拿不到**。
2. **风控极严且是「挂起式」拦截**：高频/连续访问后，导航到小红书域会直接**挂起 30s+ 超时**（RPC timeout），或重定向到 `安全验证 404`。这与 OpenBiliClaw 文档的警告一致（自动滚动、高频刷新都是风控信号）。
3. **bsk network 只给请求 URL 不给响应体** → 网络捕获方案不可用；`__INITIAL_STATE__` 被 Vue 响应式包装（部分数据拿不到）→ 走「已渲染 DOM」路线。

### 已交付

| 模块 | 文件 | 说明 |
|---|---|---|
| 小红书通道 | `src/sources/xiaohongshu.ts`（新） | ① `collectXiaohongshuSearch`：搜索页卡片采集（标题/作者/noteId/赞·评论·收藏数），单次访问不滚动不点击（被动纪律）；② `collectXiaohongshuNoteComments`：详情页评论（需登录，读 `__INITIAL_STATE__` SSR 评论，未登录返回明确提示）；③ `detectXhsRisk`：风控/登录墙检测（对齐 OpenBiliClaw `risk-control.ts` 文案：安全验证/频繁操作→触发冷却，登录墙→仅提示）；④ **导航超时识别为风控挂起 → 自动进入平台冷却**（不再空转） |
| 评论分流 | `src/collect.ts` | `routeForCommentUrl` 新增小红书笔记 URL（`/explore/{id}` `/discovery/item/{id}` `/search_result/{id}`）；`collect_comments` 小红书分支 → 评论通道，`strategy: "xiaohongshu-api"` |
| 新工具 | `src/tools.ts` | **`collect_xhs_search`**：关键词 → 搜索卡片（含自动落盘 corpus kind=article）；冷却中直接跳过；`isConcurrencySafe: false`（低频纪律） |
| 测试 | `test/sources-xiaohongshu.test.ts`、`test/collect-split.test.ts`、`test/xiaohongshu-real.smoke.test.ts`（新） | URL 解析（三种路径）/风控检测（4 类文案）/卡片解析/通道路由；真实冒烟（DSH_SMOKE=1） |

### 真实验证结果

- **成功路径**（探索阶段）：单次访问搜索页「机械键盘」→ 20 条笔记链接 + 卡片文本（标题/作者/日期/赞数）完整可读。
- **风控路径**（冒烟测试 `test/xiaohongshu-real.smoke.test.ts`）：连续访问后导航挂起 → 通道正确返回 `rate_limited` 并触发 `xiaohongshu` 平台冷却（20s×2 快速失败，不再浪费请求）——**失败安全行为端到端验证通过**。
- 当前浏览器/IP 处于小红书风控冷却中：成功采集的复验需等待风控解除（平台冷却窗口过后）或在已登录小红的浏览器会话中执行。

### 复验结果（用户登录小红书后，2026-08-15）

1. **搜索卡片通道真实跑通（修复后）**：`collect_xhs_search` 单次访问「机械键盘」→ `reason: success`，**20 张卡片**（标题/作者/noteId/链接完整）。修复了一个关键 bug：`evalOn` 未解包 bsk evaluate 的 `{ok, tab_id, value}` 包装，导致 `parseXhsSearchCards` 恒收到空 `items`（表现为此前冒烟误报 empty）。
2. **登录态检测修复**：`web_session` 是 **HttpOnly cookie**，`document.cookie` 读不到 → 原检测误判未登录。改用**页面 UI 信号**（已登录侧边栏「发布」入口 + `/user/profile/{id}` 链接 + cookie 三信号）。
3. **重大平台限制发现：小红书 web 端笔记详情无 token = App 扫码墙**（error_code=300031，「当前笔记暂时无法浏览，请打开小红书App扫码查看」）。多篇不同笔记确认，**无论是否登录**均被墙。
4. **🎉 评论通道完整闭环（xsec_token 是钥匙，白嫖页面自带签名）**——GitHub 调研（MediaCrawler / xiaohongshu-cli / XHS-Downloader / OpenCLI）确认 `xsec_token` 是绕过 App 墙的关键，且**首页推荐流/搜索页已水合 state 的笔记 URL 自带 token**：
   - 已实现 `collectXiaohongshuNoteComments` 生产路径：无 token 时**自动访问首页挖 (noteId, xsec_token) 对**（`buildXhsTokenMineScript` 从 `__INITIAL_STATE__`/Pinia store harvest，正则兼容 URL 字符串与独立字段，延迟加载重试）→ 带 token 导航详情页 → **页面自带 x-s 签名请求**（无需逆向签名！）→ 读 `__INITIAL_STATE__` SSR 评论。
   - URL 自带 `?xsec_token=`（App 分享链接）时直接使用。
   - 真实冒烟 `test/xiaohongshu-comments-real.smoke.test.ts`：挖到 3 对 token → 详情页加载成功（App 墙消失）→ **10 条真实评论**（含标题/正文）。
   - 明确剩余限制：token 有时效（过期回到扫码墙会提示重新挖）；评论为 SSR 首屏（不自动滚动加载更多，被动纪律）；后端直连评论 API 仍需 x-s 签名（未实现，当前走浏览器路径）。

### 使用与边界（更新）

- `collect_xhs_search`：**小红书搜索卡片通道**（匿名可用、低频、命中风控自动冷却）——真实复验 20 张卡片。
- `collect_comments`（小红书笔记 URL）：**评论通道可用**——URL 带 `xsec_token`（分享链接）直接用；不带则自动从首页推荐流挖 token；返回 `strategy: "xiaohongshu-api"`。App 墙（token 过期）返回明确提示；未登录返回 login_wall。
- 登录态检测已修复（UI 信号）；评论获取依赖登录 + token（页面请求带 HttpOnly cookie）。

### 待办（小红书）

- ~~可选：`collect_xhs_search` 顺带从搜索页 state 挖 token~~ ✅ **已落地（见下）**
- 可选：评论分页（SSR 首屏 10-20 条；如需更多需触发页面加载更多——被动纪律权衡）。
- 可选：后端直连评论 API（移植 x-s 签名）——当前浏览器路径已够，签名维护成本高，暂不做。

### collect_xhs_search 顺带挖 token（2026-08-15 追加）

- `XhsSearchCard` 新增 `xsecToken`；`buildXhsSearchCardsScript` **直接从卡片链接 href 提取 `xsec_token`**（登录态下搜索页卡片链接自带 token——用户手动打开的搜索页实测 **57/57 链接带 token**），state 挖取（`buildXhsTokenMineScript`）保留为 best-effort 兜底（双保险，挖不到不影响卡片返回）。
- 工具 schema/描述更新：`collect_xhs_search` 返回的卡片带 `xsecToken`，可直接对笔记 URL 调 `collect_comments` 采评论（完整链路：搜索 → 卡片+token → 评论）。
- 验证：用户手动打开搜索页（`search_result_ai`）→ `bsk tab borrow` 借入 → DOM 链接 57 个全部带 token、state 挖到 3 对 → 与首页 token 详情评论链路（10 条 SSR 评论）衔接闭合。
- 边界：token 有时效（过期回 App 扫码墙会提示重新挖）；自动化 navigate 在风控窗口会挂起（通道正确进入冷却；用户手动打开页面 + `tab borrow` 可绕过）。

---

## 9. 微博帖子和评论爬虫（2026-08-15，参考 MediaCrawler）

### 实测结论（真实 bsk 会话）

- **后端匿名直连 `m.weibo.cn` API 返回 432 反爬**（MediaCrawler 注释确认的已知问题）；**浏览器页面内 fetch（自动带 cookie）返回 ok:1**——与 B 站/小红书同构的浏览器路径。
- 端点（对齐 MediaCrawler `media_platform/weibo/client.py` 与 OpenBiliClaw `weibo_client.py`）：
  - 搜索：`GET /api/container/getIndex?containerid=100103type=1&q={keyword}&page={n}` → `data.cards[].mblog`（id/mid、`user.screen_name`、`text`(HTML)、`comments_count` 等）
  - 评论：`GET https://m.weibo.cn/comments/hotflow?id={mid}&mid={mid}[&max_id={n}]&max_id_type=0`（Referer 详情页）→ `data.data[]`（含子评论 `comments`），`max_id` 游标分页
  - 热榜 `weibo.com/ajax/side/hotSearch` 后端直连 403（需登录态），未纳入。
- 文本字段用 `text`（HTML）而非 `text_raw`（搜索 API 无 text_raw）——脚本内剥标签转纯文本。

### 已交付

| 模块 | 文件 | 说明 |
|---|---|---|
| 微博通道 | `src/sources/weibo.ts`（新） | ① `collectWeiboSearch`：navigate 搜索页 → 页面内 fetch 搜索 API → 帖子列表（作者/正文/互动数/mid 链接）；② `collectWeiboComments`：navigate 详情页 → 页面内 fetch `hotflow`（max_id 游标分页，含子评论）；③ 风控识别：432/apiOk=0/导航超时 → `weibo` 平台冷却（30s 起指数退避）；④ 导航重试 |
| 评论分流 | `src/collect.ts` | `routeForCommentUrl` 新增微博详情（`m.weibo.cn/detail/{id}`）；`collect_comments` 微博分支 → 评论通道，`strategy: "weibo-api"` |
| 新工具 | `src/tools.ts` | **`collect_weibo_search`**：关键词 → 微博帖子（含自动落盘 corpus kind=article）；冷却中直接跳过 |
| 平台注册 | `src/pacing.ts`、`src/net.ts` | `weibo` 平台规格（30s 起/1800s cap/800ms 间隔）+ host 映射（m.weibo.cn/weibo.com/api.weibo.com）；代理直连后缀已含微博域 |
| 测试 | `test/sources-weibo.test.ts`、`test/collect-split.test.ts`、`test/weibo-real.smoke.test.ts`（新） | URL 解析/脚本生成/帖子与评论归一化/通道路由；真实冒烟（DSH_SMOKE=1） |
| flaky 修复 | `test/topics.test.ts` | 预存在的 KMeans 随机性导致「负面主题」断言偶发失败 → 测试内固定 `Math.random` 种子（6 次连续全绿） |

### 真实冒烟结果（`test/weibo-real.smoke.test.ts`）

- 搜索「大厂」→ `ok: success`，**9 条帖子**（首条 25 评论）。
- 第一条有评论的帖子 → `collectWeiboComments` → `ok: success`，**20 条真实评论**（含作者/内容，首条 155 赞）。
- 结论：**微博帖子和评论通道生产可用**（浏览器路径 + 页面内 fetch，匿名可读）。

### 使用与边界

- `collect_weibo_search`：微博帖子搜索（匿名、低频）；返回 `m.weibo.cn/detail/{id}` 链接可直接调 `collect_comments`。
- `collect_comments`（`m.weibo.cn/detail/*`）：评论采集（hotflow 分页 + 子评论）。
- 边界：微博风控相对宽松（浏览器路径 + 低频即可）；432 偶发（页面内 fetch 自动带 cookie 基本不触发）；热榜需登录态未纳入。

### 待办（微博）

- 可选：`weibo.com/{uid}/{bid}` URL 的 bid → mid 解码（当前支持 `m.weibo.cn/detail/{id}`）。
- 可选：热榜（需登录态，参考 OpenBiliClaw `weibo.com/ajax/side/hotSearch`）。

---

## 10. 抖音评论爬虫（2026-08-15，参考 MediaCrawler）

### 实测结论（真实 bsk 会话）

- **抖音 web 端评论 API 在页面内 fetch（自动带 cookie）无需 a_bogus/X-Bogus 签名**：
  `GET /aweme/v1/web/comment/list/?aweme_id={id}&cursor={cursor}&count=20&item_type=0` → `{status_code:0, comments[], cursor, has_more, total}`（游标分页；实测某视频 total 2726 条）。
- 子评论：`/aweme/v1/web/comment/list/reply/?comment_id={cid}&cursor=&count=&item_type=0&item_id={aweme_id}`（对齐 MediaCrawler；本会话 evaluate 偶发失败，fail-soft 保留待复验）。
- **搜索/详情/用户作品 API 同样页面内 fetch 免签名**（2026-08 复测，推翻旧注释「搜索 API 免签名返回空」）：
  - `GET /aweme/v1/web/general/search/single/` → `data[].aweme_info`（aweme_id/desc/author/statistics/create_time），`has_more` + `offset` 分页（实测 25 条/页）；
  - `GET /aweme/v1/web/aweme/detail/` → `aweme_detail{desc,statistics,author}`；
  - `GET /aweme/v1/web/aweme/post/?sec_user_id=...&max_cursor=0&count=18` → `aweme_list`（20 条/页）+ `has_more` + `max_cursor`。
- **搜索页 DOM 兜底**：卡片容器 `id="waterfall_item_{aweme_id}"` + `.search-result-card` 文本（时长/播放/标题/作者），API 空时可用。
- 抖音 PC 首页卡片点击不触发路由跳转（React 交互层特殊）→ 不依赖点击；`extractAwemeId` 支持 `/video/{id}` 与 `modal_id` 参数；`v.douyin.com` 短链已接入（navigate 后从最终 URL 解析）。

### 已交付

| 模块 | 文件 | 说明 |
|---|---|---|
| 抖音通道 | `src/sources/douyin.ts`（新） | ① `collectDouyinComments`：navigate 视频页 → 页面内 fetch 评论 API（cursor 分页 + 前 N 条评论子评论 fail-soft + 详情 API 补标题/作者/互动数）；② `collectDouyinTrending`：首页 SSR HTML 挖推荐视频（id + 链接，详情补标题）；③ `collectDouyinSearch`：搜索页 API 优先 + DOM 兜底（`sort_type`/`publish_time` 筛选、offset 分页）；④ `collectDouyinUserWorks`：用户主页 API `max_cursor` 分页；⑤ 风控识别：status_code!=0 / fetch 失败 / 导航超时 → `douyin` 平台冷却 |
| 评论分流 | `src/collect.ts` | `routeForCommentUrl` 新增抖音视频（`douyin.com/video/{id}`、`modal_id`、`v.douyin.com` 短链）；`collect_comments` 抖音分支 → 评论通道，`strategy: "douyin-api"`，透传 `author` |
| 搜索/用户工具 | `src/tools.ts`、`src/channels.ts` | 注册 `collect_douyin_search`、`collect_douyin_user`；通道 `douyin-search-api` / `douyin-search-dom` / `douyin-user-api`（action: search） |
| 平台注册 | `src/pacing.ts` | `douyin` 平台规格（30s 起/1800s cap/800ms 间隔）+ host 映射（douyin.com/www/v.douyin.com） |
| 测试 | `test/sources-douyin.test.ts`、`test/collect-split.test.ts`、`test/douyin-real.smoke.test.ts`（新） | URL 解析/搜索/详情/用户作品解析/通道路由；真实冒烟（DSH_SMOKE=1） |

### 真实冒烟结果（`test/douyin-real.smoke.test.ts`）

- 视频 `7643084980406983089`（「盛夏的果实」音乐视频，18.3 万赞）→ `ok: success`，**60 条真实评论**（cursor 分页；首条「为什么叫盛夏的果实…」）。
- 评论列表含回复（reply_comment_total 96/3/5），子评论 API 端点已按 MediaCrawler 对齐（本会话 evaluate 偶发失败，fail-soft 不影响主评论）。

### 使用与边界

- `collect_comments`（`douyin.com/video/*`、带 `modal_id` 的 URL、`v.douyin.com` 短链）：抖音视频评论采集（浏览器路径、免签名、匿名可读，返回视频标题/作者）。
- `collect_douyin_search(keyword, topic?, limit?, sort_type?, publish_time?)`：关键词搜索发现（搜索页 API 优先，DOM 兜底；结构化卡片 + 落盘）。
- `collect_douyin_user(userUrl, topic?, limit?)`：博主作品发现（用户主页 API，`max_cursor` 分页）。
- 边界：X-Bogus/a_bogus 纯算签名仍不做（浏览器路径已覆盖评论/搜索/详情/用户作品，无需签名）；子评论真实环境复验待后续。

### 待办（抖音）

- ~~`v.douyin.com` 短链 → aweme_id 解析~~（已接入：navigate 后读最终 URL）。
- 子评论通道真实环境复验（端点已对齐，评估时 evaluate 偶发失败）。
- 可选：X-Bogus 签名移植（OpenBiliClaw `douyin_signature.py` 134 行，Apache-2.0）解锁后端直连——当前浏览器路径已覆盖，仅在浏览器池吞吐成为瓶颈时评估。

---

## 11. 快手评论爬虫（2026-08-15，参考 MediaCrawler）

### 实测结论（真实 bsk 会话）

- **快手评论 API 无签名，页面内 fetch（自动带 cookie）直接可用**（对齐 MediaCrawler `kuaishou/client.py` 的 REST V2）：
  `POST /rest/v/photo/comment/list` body=`{photoId, pcursor}` → `{result:1, rootCommentsV2[], pcursorV2, commentCountV2}`（`pcursorV2` ""→下一页，`"no_more"` 结束）。
- 子评论：`POST /rest/v/photo/comment/sublist` body=`{photoId, pcursor, rootCommentId}` → `subCommentsV2`。
- 评论字段（实测）：`content` / `author_name`（非 userName）/ `comment_id` / `likeCount` / `hasSubComments`。
- 分享链接 `/f/{id}` navigate 后自动重定向到 `/short-video/{photoId}`，视频页完整渲染（含评论）。
- 快手 PC 首页/搜索页内容为客户端渲染（SSR 无视频数据）→ 发现通道不做，聚焦评论（用户给视频 URL）。
- 错误：`result:2` 服务端限流、`result:50` 拒绝（签名）→ `kuaishou` 平台冷却。

### 已交付

| 模块 | 文件 | 说明 |
|---|---|---|
| 快手通道 | `src/sources/kuaishou.ts`（新） | `collectKuaishouComments`：navigate 视频页（`short-video/{id}` 或 `/f/` 分享链接，navigate 后从当前 URL 挖 photoId）→ 页面内 fetch 评论 API（`pcursorV2` 分页 + 前 N 条评论子评论 fail-soft）→ 风控识别（result!=1/导航超时 → 冷却） |
| 评论分流 | `src/collect.ts` | `routeForCommentUrl` 新增快手（`short-video/{id}`、`/f/{id}`）；`collect_comments` 快手分支 → 评论通道，`strategy: "kuaishou-api"` |
| 平台注册 | `src/pacing.ts` | `kuaishou` 平台规格（30s 起/1800s cap/800ms 间隔）+ host 映射（kuaishou.com/www/v） |
| 测试 | `test/sources-kuaishou.test.ts`、`test/collect-split.test.ts`、`test/kuaishou-real.smoke.test.ts`（新） | URL 解析（含 `/f/` 连字符 id）/脚本生成/评论归一化/通道路由；真实冒烟（DSH_SMOKE=1） |

### 真实冒烟结果（`test/kuaishou-real.smoke.test.ts`）

- 视频 `short-video/3xb2p974yf35c2k`（「跨越海峡的告白」台湾女孩视频）→ `ok: success`，**4 条真实评论**（首条「晓九：我的家乡，我的祖国[玫瑰]」，total 5），5s 完成。
- 字段修正：`author_name`/`comment_id`（首次冒烟 author 为空 → 实测字段名修正后「晓九」）。

### 使用与边界

- `collect_comments`（`kuaishou.com/short-video/*` 或 `/f/` 分享链接）：快手视频评论采集（浏览器路径、免签名、匿名可读）。
- 边界：快手 PC 首页/搜索内容客户端渲染（发现通道未做，用户提供视频 URL）；子评论真实环境复验待后续。

### 待办（快手）

- 子评论通道真实环境复验（端点已对齐 MediaCrawler）。
- 可选：`__NS_hxfalcon` 签名（MediaCrawler 用 Playwright 生成）解锁搜索/作品列表——当前评论已够。

---

## 12. 牛客评论爬虫（2026-08-15）

### 实测结论（真实 bsk 会话）

- `nowcoder.com/discuss/{postId}` 讨论帖页 **SSR 完整渲染**（标题/作者/浏览数/评论区）。
- 评论区 DOM：每条评论为 `section.comment-box`——作者 `header[class*='content-user-info']`（文本首 token）、内容 `div[class*='comment-rich-text']`（实测：「职场不咸鱼：高手在民间👍」）。
- `__INITIAL_STATE__` 不含评论区数据（评论由组件渲染）→ 走 **DOM 提取**（SSR 首屏评论，不滚动）。
- 牛客风控相对宽松（国内社区）；导航超时/页面异常 → `nowcoder` 平台冷却。

### 已交付

| 模块 | 文件 | 说明 |
|---|---|---|
| 牛客通道 | `src/sources/nowcoder.ts`（新） | `collectNowcoderComments`：navigate 讨论帖 → DOM 提取 `.comment-box`（作者/内容）→ 标题取自 `document.title`；导航重试 + 风控冷却 |
| 评论分流 | `src/collect.ts` | `routeForCommentUrl` 新增牛客（`nowcoder.com/discuss/{id}`）；`collect_comments` 牛客分支 → 评论通道，`strategy: "nowcoder-api"` |
| 平台注册 | `src/pacing.ts` | `nowcoder` 平台规格（30s 起/1800s cap/800ms 间隔）+ host 映射（nowcoder.com/www） |
| 测试 | `test/sources-nowcoder.test.ts`、`test/collect-split.test.ts`、`test/nowcoder-real.smoke.test.ts`（新） | URL 解析/脚本生成/评论归一化/通道路由；真实冒烟（DSH_SMOKE=1） |

### 真实冒烟结果（`test/nowcoder-real.smoke.test.ts`）

- 讨论帖 `discuss/917392486895452160`（「面试官：你如何证明你没用AI作弊」）→ `ok: success`，**14 条真实评论**（首条「职场不咸鱼：高手在民间👍」，页面显示全部评论(10)+楼中楼），6s 完成。

### 使用与边界

- `collect_comments`（`nowcoder.com/discuss/*`）：牛客讨论帖评论采集（浏览器路径、DOM 提取、匿名可读）。
- 边界：首屏渲染评论（不滚动加载更多，被动纪律）；楼中楼（comment-box 内嵌套回复）暂未展开（可扩展）。

### 待办（牛客）

- 楼中楼回复展开（comment-box 内嵌套回复结构已见，后续按需）。

---

## 13. 百度贴吧评论爬虫（2026-08-15）

### 实测结论（真实 bsk 会话）

- `tieba.baidu.com/p/{tid}` 帖子页回复在 DOM 渲染（客户端渲染，无 PageData/SSR JSON）。
- 回复项 DOM（新版）：`div.pb-comment-item`——作者 `a.name-info-link`（文本首 token）、内容 `div.pb-rich-text`（纯内容）、楼中楼 `.lzl-wrapper .pb-rich-text`。
- 楼中楼 API：`/p/totalComment?tid={tid}&pn={n}` 页面内 fetch 返回 JSON（`errno:0`，免签名，实测成功）——DOM 已含首屏楼中楼，API 可扩展分页。
- 后端直连贴吧 403（反爬）→ 浏览器路径（DOM 提取，与牛客同构）。

### 已交付

| 模块 | 文件 | 说明 |
|---|---|---|
| 贴吧通道 | `src/sources/tieba.ts`（新） | `collectTiebaComments`：navigate 帖子 → DOM 提取 `.pb-comment-item`（作者 `.name-info-link` + 内容 `.pb-rich-text` + 楼中楼 `.lzl-wrapper .pb-rich-text`）→ 标题取 `document.title`；导航重试 + 风控冷却 |
| 评论分流 | `src/collect.ts` | `routeForCommentUrl` 新增贴吧（`tieba.baidu.com/p/{tid}`）；`collect_comments` 贴吧分支 → 回复通道，`strategy: "tieba-api"` |
| 平台注册 | `src/pacing.ts`、`src/net.ts` | `tieba` 平台规格（30s 起/1800s cap/800ms 间隔）+ host 映射；代理直连后缀 `.tieba.baidu.com` |
| 测试 | `test/sources-tieba.test.ts`、`test/collect-split.test.ts`、`test/tieba-real.smoke.test.ts`（新） | URL 解析/脚本生成/回复归一化/通道路由；真实冒烟（DSH_SMOKE=1） |

### 真实冒烟结果（`test/tieba-real.smoke.test.ts`）

- 帖子 `p/10885405530`（程序员吧「有会复刻app的吗，一比一的那种」）→ `ok: success`，**13 条真实回复 + 7 条带楼中楼**（首条「接小程序网页软件开发：黑灰app?」），5s 完成。

### 使用与边界

- `collect_comments`（`tieba.baidu.com/p/*`）：贴吧帖子回复采集（浏览器路径、DOM 提取、匿名可读，含楼中楼）。
- 边界：首屏渲染回复（不翻页，被动纪律；`?pn=N` 分页可后续支持）；楼中楼首屏已含（totalComment API 可补全分页）。

### 待办（贴吧）

- 可选：楼层分页（`?pn=N` 遍历多页回复）与 totalComment 楼中楼补全。

---

## 14. 搜索发现通道补齐 + 浏览器工具缺口（2026-08-15 追加）

### 背景问题

- 快手搜索页是 SPA：卡片是 `<button>`（无 href），复制链接按钮不写系统剪贴板，地址栏复制被页面 JS 拦截，搜索引擎不收录 `short-video` 链接 → **拿不到视频 URL，评论通道再通也是 0 条**。
- B 站需要一个「按关键词批量发现视频源」的通道：后端搜索 API 在风控出口 412，浏览器兜底已有，但缺搜索发现。
- 浏览器工具没有「读取当前 URL」能力；`browser_navigate` 只返回目标 URL，短链重定向后的真实 URL 是盲区。
- bsk daemon 重启 / Agent Window 被手动关闭后会话失效，`session not registered` 会连环失败。
- `browser_session_start` 的 `--no-focus` 参数在 bsk 0.1.x CLI 上不被接受 → 带 noFocus 的启动直接失败。

### 解决方案

| 模块 | 文件 | 说明 |
|---|---|---|
| 快手搜索发现 | `src/sources/kuaishou.ts`、`src/tools.ts` | **`collect_kuaishou_search`**：导航搜索页 → 页面内读 `window.INIT_STATE` 里 `search.feed` 水合数据（`feeds[].photo.id` = photoId、`author.name`、`photo.caption/likeCount/viewCount`）→ 返回 `short-video/{photoId}` 链接；DOM 封面图 `clientCacheKey=<photoId>` 兜底。实测「应用统计就业」首屏 20 条。 |
| 快手风控识别修正 | `src/sources/kuaishou.ts` | `parseKuaishouComments` 现在透传 `result` 字段；`result:2`（限流）/`result:50`（签名拒绝）不再被误判为「无评论」，而是正确触发 `kuaishou` 平台冷却。 |
| B 站搜索发现 | `src/sources/bilibili.ts`、`src/tools.ts` | **`collect_bilibili_search`**：导航 `search.bilibili.com/video?keyword=…` → DOM 提取 `/video/BV` 链接（h3[title] 标题、卡片文本 UP 主）。实测「应用统计就业」38 条。返回的 URL 可直接 `collect_comments`。 |
| 当前 URL / evaluate 工具 | `dsh-plugin-browserskill/src/tools.ts` | **`browser_evaluate`**（页面内 JS 表达式，返回 JSON 值）与 **`browser_get_url`**（读 `location.href` + `document.title`，解决重定向/SPA 跳转后的 URL 盲区）。 |
| 无浏览器自动拉起 | `dsh-plugin-browserskill/src/launcher.ts`、`src/index.ts` | `browser_session_start` 前检查 bsk 连接；无浏览器时自动拉起本机 Chrome 默认 profile（窗口移到屏幕外，不抢焦点）并轮询等待扩展连接。配置：`autoLaunchChrome`（默认 true）/`chromePath`。 |
| 会话失效自愈 | `dsh-plugin-browserskill/src/tools.ts`、`dsh-community-listening/src/collect.ts` | `session not registered` 时自动从 registry / session pool 槽位移除失效会话，下一次启动即可重建，不再连环失败。 |
| session start 兼容 | `dsh-plugin-browserskill/src/tools.ts` | 不再向 bsk 0.1.x CLI 传 `--no-focus`（参数仍保留但忽略）。 |
| 配置回退 | `dsh-community-listening/src/index.ts` | `BILIBILI_COOKIE` / `DSH_INSIGHT_CORPUS_DIR` / `DSH_INSIGHT_PACING_STATE` 环境变量回退。 |

### 真实复验

- 快手闭环：搜索页提取 photoId `3xdmvnamn74nggm` → `collectKuaishouComments` 真实冒烟 **50 条评论**（视频 total 195）。
- B 站浏览器兜底真实冒烟：navigate → view（aid）→ reply/main 20 条，游标分页 isEnd=false。
- `ensureBrowserConnected`（built lib）在 bsk 无浏览器连接时成功自动拉起 Chrome 并连上扩展。

---

## 15. 人工接管 + 多后端 fallback / doctor（2026-08-15 追加）

### 已交付

| 模块 | 文件 | 说明 |
|---|---|---|
| 人工接管工具 | `dsh-plugin-browserskill/src/help.ts`、`tools.ts` | **`browser_request_help`**：封装 `bsk request-help`，支持 prompt/title/targets/timeout/completion_criteria；`BSK_REQUEST_HELP=off` 时立即返回 `outcome: disabled`；continued/completed 后提示重新 snapshot/observe |
| 通道注册表 | `dsh-community-listening/src/channels.ts` | 每平台/动作声明后端优先级（如 B站评论 `api-direct → browser-fetch`、快手搜索 `state-mine → dom-extract`）；`runChannelChain` 依次降级并返回 `backend/fallbacks/degraded` |
| 健康记录 | `dsh-community-listening/src/health.ts` | 每次评论/搜索采集写入最近结果（原子落盘 `.crawler-health.json`，与 `.pacing.json` 同目录）；与 PlatformPacer 合并计算 `healthy / degraded / cooling / blocked / unknown` |
| doctor 工具 | `dsh-community-listening/src/tools.ts` | **`crawler_status(platform?)`**：只读查询各平台主/兜底通道、最近 backend/outcome、degraded、冷却剩余与 strikes |
| 结果元数据 | `src/types.ts`、`collect.ts`、各搜索工具 | 评论结果与搜索工具返回新增 `backend / fallbacks / degraded` |
| Skill 元数据 | 两插件 `agent-skill.json` | 触发词、能力清单、边界说明（P1-b，仅本地元数据，未发布） |

### 真实复验

- `collect-health-real.smoke.test.ts`（DSH_SMOKE=1）：B 站视频主通道 412 → 自动降级 `bilibili-browser-fetch`，返回 `fallbacks:["bilibili-api-direct"], degraded:true`，96 条评论，且 `CrawlerHealth` 记录与返回一致。
- `browser_request_help`：`BSK_REQUEST_HELP=off` 下 `bsk request-help` 返回 `{"outcome":"disabled","note":"request-help disabled by BSK_REQUEST_HELP=off (unattended mode)"}`，不挂起。
- 单测：dsh-community-listening 171 passed；dsh-plugin-browserskill 8 passed。

---

## 16. 小红书平台限制专项复盘（2026-08-15）

### 实测结论

- 匿名/弱登录态下 `collect_xhs_search` 的 xsec_token 命中率低至 **3/20（15%）**，无 token 的笔记无法进入评论采集。
- 3 篇带 token 笔记仅采到 **19 条评论**，作者/互动数缺失；二次搜索立即 `rate_limited`（导航挂起 + session 失效表象），冷却窗口数十分钟级，显著长于其他平台。
- 结论：小红书 19 条是匿名弱信任会话下的合规上限；补量必须走「登录态 + 降频多轮 + 人工过卡」。

### 已落地改进

| 文件 | 改进 |
|---|---|
| `src/sources/xiaohongshu.ts` | `collect_xhs_search` 增加登录态检测（`loginState`）、`cardsWithToken`、`tokenHitRate`、`biasHint` 采样偏倚提示 |
| `src/collect.ts` | 小红书评论失败路径提示升级：登录墙 → 建议 `browser_request_help`；限流 → 建议冷却结束后降频多轮；App 扫码墙 → 建议重新搜索取 token |
| `src/tools.ts` | `collect_xhs_search` output schema 暴露上述诊断字段 |
| `README.md` / `agent-skill.json` | 小红书三道闸门（xsec_token / 登录态 / 行为风控）与合规补量路径文档化 |

### 合规改进路径（后续执行）

1. **A 登录态增强**：在已登录小红书的真实 Chrome 会话中执行搜索与评论采集（auto-launch 默认复用本机登录态）；
2. **B 降频多轮**：每轮仅 1 次搜索，冷却完全结束后再下一轮，错峰多天；
3. **C 人工过卡**：验证码/登录墙时 `browser_request_help` 人工完成；
4. **D 移动端入口**：仅预留，默认不启用（仍需登录态 + 低频）。

---

## 17. 重登无效复盘：cookieHasWebSession 是假信号（2026-08-15）

### 现象

用户手动退出→重登（手机号/验证码）成功后，`collect_xhs_search` 的 `cookieHasWebSession` 仍为 `false`，`tokenHitRate` 仍 15%（3/20）。据此曾推断「小红书双轨评分：页面会话与自动化请求分开打分，换号无效」。

### 判定：结论不成立，测量信号是坏的

| 证据 | 说明 |
|---|---|
| `web_session` 是 HttpOnly | `document.cookie` 永远读不到 → 旧 `cookieHasWebSession` **恒为 false**，无法作为「请求上下文未带登录态」的证据 |
| Chrome Default profile Cookie DB 实查 | `.xiaohongshu.com` 下确有 `web_session`（重登写入，2026-08-15，有效期 1 年）+ `id_token`/`a1`/`webId`/`gid` → 登录真实落在插件使用的默认 profile |
| bsk Agent Window 是同 profile 普通标签页 | 扩展 `chrome.windows.create({type:"normal"})`、`chrome.tabs.create`，非 incognito → 自动化请求确实携带 `web_session` |
| `hasProfileLink`/`hasPublishEntry` 是弱信号 | 搜索结果作者卡片 `/user/profile/` 链接与导航「发布」按钮在匿名页面同样存在 → 「页面层登录真实有效」不成立 |

### 真实可能原因（需 1 轮带诊断的搜索验证区分）

1. **服务端按请求指纹降权**：请求上下文带合法 `web_session`，但 SSR/API 对该指纹仍只下发部分 `xsec_token`（与「双轨」直觉方向一致，但机制不同——不是 cookie 缺失，是信任评分）；
2. **harvest 漏挖**：token 以独立 `xsecToken` 字段存储（SSR/搜索 API 的 `{noteId, xsecToken, noteCard}` 结构），旧版只采 URL 字符串 → 已修复为 Pass A（URL）+ Pass B（独立字段）双路采集，并增加一次 pinia 水合重试；
3. **匿名壳页面**：页面实际为匿名受限视图（无 `__INITIAL_STATE__.user`），与登录态无关。

### 终局确认（2026-08-15 实测，指纹机制实锤）

- **网络层正常**：curl 直连 xiaohongshu.com 0.5s 内 301→200；浏览器（bsk）连 example.com 秒开、evaluate 正常 → 挂起与网络/浏览器环境无关。
- **指纹 cookie 时间戳实锤**（Chrome 默认 profile Cookie DB）：
  | Cookie | 创建 | 含义 |
  |---|---|---|
  | `a1` / `webId` / `gid` / `abRequestId` | **08-12 07:59**（3 天前） | 设备指纹，**重登不重置** |
  | `web_session` / `id_token` | 08-15 06:28（重登当天） | 登录态，重登只刷新了它 |
- **结论**：小红书信任评分挂在 `a1`/`webId` 设备指纹上，`web_session` 登录态是另一维度。连续自动化访问把 08-12 的指纹打上低信任标记后，导航直接挂起（20s RPC 超时、页面永不 commit、evaluate 也超时），与登录态无关 → **重登无效、换号同样无效**；有效手段是**清除 xiaohongshu.com 站点数据（轮换 a1/webId 指纹）**或换浏览器 profile / IP，再配合降频。
- **插件侧联动修复**：`PlatformPacer` 小红书冷却基数 60s → **900s**（实测窗口为数十分钟级，60s 重试只会加深标记）；导航超时/风控拦截的错误文案补充指纹轮换指引。

### 已落地改进

| 文件 | 改进 |
|---|---|
| `src/sources/xiaohongshu.ts` | 登录态检测改为真实信号：`sessionUser`（`__INITIAL_STATE__.user` 水合用户）+ `loginWallText`（登录墙文案）+ `cookieNames`；`cookieHasWebSession` 降级为恒 false 兼容字段并注释勿用；`biasHint` 区分「已确认登录低命中=指纹降权」与「未确认登录=先验证登录落在插件会话」 |
| `src/sources/xiaohongshu.ts` | `buildXhsTokenMineScript` 双路 harvest（URL 字符串 + 独立 `xsecToken` 字段同层/父层/noteCard 关联）；搜索流程 token 挖掘增至 3 次尝试（等 pinia 水合）；卡片脚本补 `data-xsec-token` 属性兜底 |
| `src/sources/xiaohongshu.ts` | 导航超时 / 风控拦截错误文案补充：反复挂起时仅重登/换号无效，需清除站点 Cookie 轮换 a1/webId 指纹或换 profile/IP |
| `src/pacing.ts` | `xiaohongshu` 冷却基数 60s → 900s（匹配实测数十分钟级窗口，避免过早重试加深标记） |
| `src/tools.ts` | `collect_xhs_search` loginState schema 暴露 `sessionUser/sessionUserId/loginWallText/cookieNames` |
| 评论路径 | `collectXiaohongshuNoteComments` 登录判定同步去掉 `document.cookie.includes("web_session")` 假信号 |
| 新增 | `test/xhs-diagnose.smoke.test.ts`（DSH_SMOKE=1 门控，输出 sessionUser/tokenHitRate/biasHint 完整诊断） |

### 验证建议

冷却结束后做 1 轮单搜：若 `loginState.sessionUser=true` 而 `tokenHitRate` 仍 <50% → 判定为服务端指纹降权（换号无效，只能降频+错峰+换关键词）；若 `sessionUser=false` 且页面为匿名壳 → 回到「登录未落在插件会话」路径（在 Agent Window 内登录后再试）。若导航持续挂起 → 先清除 xiaohongshu.com 站点数据轮换指纹再试。
