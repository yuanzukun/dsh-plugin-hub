/**
 * 语料存储层（v2：采集文本落盘 + 分流分析 + 报告导出）。
 *
 * 设计（用户确认）：
 * - 语料保存在「新开会话的工作目录」：`<会话cwd>/insight-workspace/<topic>/`
 * - 采集自动落盘（collect_*_search / collect_comments 带 topic 时）
 * - 追加式 corpus.jsonl（同 topic+url+内容哈希 去重，重跑幂等）
 * - analysis.json：最近一次分析结果快照；report.md：最终报告
 *
 * 会话工作目录解析（运行时探查确认）：
 *   exec.agent.session.header.cwd  →  agents.currentInitiator().session.header.cwd  →  process.cwd()
 * 注意：sandboxPolicy.workspaceRoot 是部署根目录，不是会话工作目录，不可用。
 */

import { createHash, randomUUID } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import type { Context } from "@deepseek-ai/cordis";
import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import { normalizeUrl } from "./net";

export type CorpusKind = "article" | "page" | "comment" | "rss";

/** 一条语料条目（纯 JSON，可序列化）。 */
export interface CorpusEntry {
  id: string;
  topic: string;
  kind: CorpusKind;
  url: string;
  title: string;
  source: string;
  /** A/B/C 可信分级（采集时携带）。 */
  trust?: string;
  /** fetch / browser / rss。 */
  strategy?: string;
  text: string;
  collectedAt: string;
}

export interface CorpusStats {
  topic: string;
  root: string;
  path: string;
  total: number;
  byKind: Record<string, number>;
  byTrust: Record<string, number>;
  byStrategy: Record<string, number>;
  latestCollectedAt: string;
}

const WORKSPACE_DIR = "insight-workspace";
const MAX_ARTICLE_CHARS = 6_000;
const MAX_COMMENT_CHARS = 500;

/** topic → 安全目录名（去非法字符）。 */
export function slugTopic(topic: string): string {
  const slug = topic
    .trim()
    .replace(/[\\/:*?"<>|\s]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
  return slug || "default";
}

/** 从 ToolRunContext 取会话工作目录（探查确认：exec.agent.session.header.cwd）。 */
export function sessionCwdFromExec(exec?: ToolRunContext): string | undefined {
  try {
    const agent = exec?.agent as { session?: { header?: { cwd?: string } } } | undefined;
    const cwd = agent?.session?.header?.cwd;
    if (typeof cwd === "string" && cwd) return cwd;
  } catch {
    // ignore
  }
  return undefined;
}

/** 从 Host ctx 取当前会话工作目录（无 exec 时的回退）。 */
export function sessionCwdFromCtx(ctx: Context): string | undefined {
  try {
    const agents = ctx.get("agents") as
      | { currentInitiator?(): { session?: { header?: { cwd?: string } } } }
      | undefined;
    const cwd = agents?.currentInitiator?.().session?.header?.cwd;
    if (typeof cwd === "string" && cwd) return cwd;
  } catch {
    // ignore
  }
  return undefined;
}

/**
 * 语料根目录解析（优先级）：
 * 1. Config corpusDir（绝对路径覆盖）
 * 2. 会话工作目录（exec.agent.session.header.cwd / agents.currentInitiator）
 * 3. process.cwd()
 */
export function resolveCorpusRoot(ctx: Context, configured: string, exec?: ToolRunContext): string {
  if (configured && configured.trim()) return configured.trim();
  const session = sessionCwdFromExec(exec) ?? sessionCwdFromCtx(ctx);
  if (session) return session;
  try {
    const cwd = process.cwd();
    if (cwd) return cwd;
  } catch {
    // ignore
  }
  return "";
}

/** 主题目录：<root>/insight-workspace/<topic>/ */
export function topicDir(root: string, topic: string): string {
  return join(root, WORKSPACE_DIR, slugTopic(topic));
}

export function corpusPath(root: string, topic: string): string {
  return join(topicDir(root, topic), "corpus.jsonl");
}

export function analysisPath(root: string, topic: string): string {
  return join(topicDir(root, topic), "analysis.json");
}

export function reportPath(root: string, topic: string): string {
  return join(topicDir(root, topic), "report.md");
}

/** 条目内容指纹（去重用）：URL 归一化 + 前 200 字哈希。 */
export function entryDedupKey(entry: Pick<CorpusEntry, "topic" | "url" | "text">): string {
  const hash = createHash("sha1").update((entry.text ?? "").slice(0, 200)).digest("hex").slice(0, 12);
  return `${entry.topic}\u0000${normalizeUrl(entry.url || "")}\u0000${hash}`;
}

export interface AppendResult {
  saved: number;
  skipped: number;
  path: string;
}

/** 已存在的去重键集合（进程内缓存，避免每次全量读文件）。 */
const dedupCache = new Map<string, Set<string>>();

/**
 * 失效某个 topic 的去重缓存（按 corpusPath 删缓存键）。
 * 用户外部删除/编辑 corpus.jsonl 后必须调用，否则同进程内再采集会因陈旧缓存
 * 错误跳过本应保存的条目。手动 save_corpus 入口（用户可能动过文件）调用；
 * 自动落盘路径保留缓存换性能。
 */
export function invalidateDedupCache(root: string, topic: string): void {
  dedupCache.delete(corpusPath(root, topic));
}

function ensureDir(dir: string): void {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
}

/**
 * 追加语料条目（追加式 JSONL；同 topic+url+内容指纹 跳过）。
 * 返回 {saved, skipped, path}。
 */
export function appendEntries(root: string, topic: string, entries: CorpusEntry[]): AppendResult {
  const dir = topicDir(root, topic);
  ensureDir(dir);
  const path = corpusPath(root, topic);
  const fileKey = path;
  if (!dedupCache.has(fileKey)) {
    const seen = new Set<string>();
    if (existsSync(path)) {
      for (const line of readFileSync(path, "utf8").split(/\r?\n/)) {
        if (!line.trim()) continue;
        try {
          const parsed = JSON.parse(line) as Partial<CorpusEntry>;
          if (parsed && typeof parsed.topic === "string" && typeof parsed.url === "string") {
            seen.add(entryDedupKey({ topic: parsed.topic, url: parsed.url, text: String(parsed.text ?? "") }));
          }
        } catch {
          // 坏行跳过
        }
      }
    }
    dedupCache.set(fileKey, seen);
  }
  const seen = dedupCache.get(fileKey)!;
  const lines: string[] = [];
  let skipped = 0;
  for (const raw of entries) {
    const entry: CorpusEntry = {
      id: raw.id || `${raw.kind ?? "item"}-${randomUUID().slice(0, 8)}`,
      topic: raw.topic || topic,
      kind: raw.kind ?? "article",
      url: raw.url ?? "",
      title: raw.title ?? "",
      source: raw.source ?? "",
      text: (raw.text ?? "").slice(0, raw.kind === "comment" ? MAX_COMMENT_CHARS : MAX_ARTICLE_CHARS),
      collectedAt: raw.collectedAt || new Date().toISOString(),
    };
    if (raw.trust !== undefined) entry.trust = raw.trust;
    if (raw.strategy !== undefined) entry.strategy = raw.strategy;
    const key = entryDedupKey(entry);
    if (seen.has(key)) {
      skipped += 1;
      continue;
    }
    seen.add(key);
    lines.push(JSON.stringify(entry));
  }
  if (lines.length > 0) {
    writeFileSync(path, lines.join("\n") + "\n", { encoding: "utf8", flag: "a" });
  }
  return { saved: lines.length, skipped, path };
}

/** 读取某主题语料（可按 kind 过滤；按采集时间升序）。 */
export function loadEntries(root: string, topic: string, kind?: CorpusKind): CorpusEntry[] {
  const path = corpusPath(root, topic);
  if (!existsSync(path)) return [];
  const out: CorpusEntry[] = [];
  for (const line of readFileSync(path, "utf8").split(/\r?\n/)) {
    if (!line.trim()) continue;
    try {
      const parsed = JSON.parse(line) as CorpusEntry;
      if (!parsed || parsed.topic !== topic) continue;
      if (kind && parsed.kind !== kind) continue;
      out.push(parsed);
    } catch {
      // 坏行跳过
    }
  }
  return out;
}

/** 语料统计（报告「证据数」引用）。 */
export function corpusStats(root: string, topic: string): CorpusStats {
  const entries = loadEntries(root, topic);
  const byKind: Record<string, number> = {};
  const byTrust: Record<string, number> = {};
  const byStrategy: Record<string, number> = {};
  let latest = "";
  for (const e of entries) {
    byKind[e.kind] = (byKind[e.kind] ?? 0) + 1;
    if (e.trust) byTrust[e.trust] = (byTrust[e.trust] ?? 0) + 1;
    if (e.strategy) byStrategy[e.strategy] = (byStrategy[e.strategy] ?? 0) + 1;
    if (e.collectedAt > latest) latest = e.collectedAt;
  }
  return {
    topic,
    root,
    path: corpusPath(root, topic),
    total: entries.length,
    byKind,
    byTrust,
    byStrategy,
    latestCollectedAt: latest,
  };
}

/** 写最终报告 markdown（默认覆盖需显式 overwrite）。 */
export function saveReport(
  root: string,
  topic: string,
  markdown: string,
  overwrite = false,
): { path: string; chars: number; overwritten: boolean } {
  const dir = topicDir(root, topic);
  ensureDir(dir);
  const path = reportPath(root, topic);
  if (existsSync(path) && !overwrite) {
    throw new Error(`报告已存在（${path}），如需覆盖请传 overwrite:true`);
  }
  writeFileSync(path, markdown, { encoding: "utf8" });
  return { path, chars: markdown.length, overwritten: existsSync(path) };
}

/** 写最近一次分析结果快照（analysis.json，覆盖式）。 */
export function saveAnalysis(root: string, topic: string, tool: string, summary: unknown): void {
  const dir = topicDir(root, topic);
  ensureDir(dir);
  const path = analysisPath(root, topic);
  const payload = {
    updatedAt: new Date().toISOString(),
    tool,
    summary,
  };
  writeFileSync(path, JSON.stringify(payload, null, 2), { encoding: "utf8" });
}

/** 便捷：构造一条语料条目。 */
export function makeEntry(input: {
  topic: string;
  kind: CorpusKind;
  url: string;
  title?: string;
  source?: string;
  trust?: string;
  strategy?: string;
  text: string;
}): CorpusEntry {
  const entry: CorpusEntry = {
    id: `${input.kind}-${randomUUID().slice(0, 8)}`,
    topic: input.topic,
    kind: input.kind,
    url: input.url ?? "",
    title: input.title ?? "",
    source: input.source ?? "",
    text: input.text,
    collectedAt: new Date().toISOString(),
  };
  if (input.trust) entry.trust = input.trust;
  if (input.strategy) entry.strategy = input.strategy;
  return entry;
}

/** 主题目录创建（供工具返回 path 用）。 */
export function ensureTopicDir(root: string, topic: string): string {
  const dir = topicDir(root, topic);
  ensureDir(dir);
  return dir;
}

/** 目录名工具（供导出工具拼接）。 */
export function dirnameOf(path: string): string {
  return dirname(path);
}
