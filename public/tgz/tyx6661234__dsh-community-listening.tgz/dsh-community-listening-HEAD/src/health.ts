/**
 * 平台通道健康记录（Agent-Reach `doctor` 思路）：
 * - 每次通道成功 / 降级 / 失败都记录最近状态
 * - 与 PlatformPacer 合并计算平台健康度
 * - 原子落盘到 pacing 状态同目录（损坏容错，失败仅降级为内存态）
 */

import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { backendChainFor, type PlatformKey } from "./channels";
import type { PlatformPacer } from "./pacing";

export type HealthOutcome =
  | "success"
  | "empty"
  | "fallback"
  | "error"
  | "login_wall"
  | "rate_limited"
  | "captcha";

export type CrawlerStatus = "healthy" | "degraded" | "cooling" | "blocked" | "unknown";

export interface HealthRecord {
  platform: PlatformKey;
  action: "comments" | "search";
  at: string;
  backend: string;
  outcome: HealthOutcome;
  degraded: boolean;
  error?: string;
}

export interface CrawlerStatusEntry {
  platform: PlatformKey;
  action: "comments" | "search";
  status: CrawlerStatus;
  preferredBackend: string;
  lastBackend: string;
  lastOutcome: HealthOutcome | "";
  degraded: boolean;
  cooldownRemainingMs: number;
  strikes: number;
  lastAt: string;
  lastError: string;
  hint: string;
  /** 历史条数（环形缓冲，每键最近 20 条）。 */
  samples: number;
  /** (success+empty) 占比（0-1；无记录为 0）。 */
  successRate: number;
  /** degraded 占比（0-1；无记录为 0）。 */
  degradedRate: number;
  /** 最近 5 条 {at, backend, outcome}（按时间升序）。 */
  recent: Array<{ at: string; backend: string; outcome: HealthOutcome }>;
}

interface HealthSnapshot {
  version: 1;
  records: HealthRecord[];
}

export interface CrawlerHealthOptions {
  stateFile?: string;
  now?: () => number;
  silent?: boolean;
}

/** 每「平台+动作」保留的最近记录数（环形缓冲，超出丢最旧）。 */
export const MAX_RECORDS_PER_KEY = 20;
/** status() 的 recent 最近条数。 */
export const RECENT_COUNT = 5;

/** 与 pacing 文件同目录的健康文件路径（空 pacing → 不落盘）。 */
export function healthStateFile(pacingStateFile: string): string {
  if (!pacingStateFile.trim()) return "";
  return join(dirname(pacingStateFile), ".crawler-health.json");
}

export class CrawlerHealth {
  private readonly stateFile: string;
  private readonly nowFn: () => number;
  private readonly silent: boolean;
  private records: HealthRecord[] = [];
  private disposed = false;

  constructor(options: CrawlerHealthOptions = {}) {
    this.stateFile = options.stateFile ?? "";
    this.nowFn = options.now ?? (() => Date.now());
    this.silent = options.silent ?? true;
    if (this.stateFile) this.load();
  }

  private static keyOf(platform: PlatformKey, action: "comments" | "search"): string {
    return `${platform}\u0000${action}`;
  }

  record(input: {
    platform: PlatformKey;
    action: "comments" | "search";
    backend: string;
    outcome: HealthOutcome;
    degraded?: boolean;
    error?: string;
  }): void {
    const record: HealthRecord = {
      platform: input.platform,
      action: input.action,
      at: new Date(this.nowFn()).toISOString(),
      backend: input.backend,
      outcome: input.outcome,
      degraded: input.degraded ?? false,
    };
    if (input.error) record.error = input.error.slice(0, 300);
    // 同「平台+动作」追加（环形缓冲，每键保留最近 20 条）——支持「越采越被封」趋势查询
    const key = CrawlerHealth.keyOf(input.platform, input.action);
    const history = this.records.filter((r) => CrawlerHealth.keyOf(r.platform, r.action) === key);
    history.push(record);
    if (history.length > MAX_RECORDS_PER_KEY) history.splice(0, history.length - MAX_RECORDS_PER_KEY);
    this.records = [...this.records.filter((r) => CrawlerHealth.keyOf(r.platform, r.action) !== key), ...history];
    this.persist();
  }

  /** 某「平台+动作」最近一条记录（无则 undefined）。 */
  recordFor(platform: PlatformKey, action: "comments" | "search"): HealthRecord | undefined {
    const key = CrawlerHealth.keyOf(platform, action);
    for (let i = this.records.length - 1; i >= 0; i -= 1) {
      if (CrawlerHealth.keyOf(this.records[i].platform, this.records[i].action) === key) {
        return this.records[i];
      }
    }
    return undefined;
  }

  /** 某「平台+动作」的完整历史（按时间升序；仅内存态，供测试/诊断）。 */
  historyFor(platform: PlatformKey, action: "comments" | "search"): HealthRecord[] {
    const key = CrawlerHealth.keyOf(platform, action);
    return this.records.filter((r) => CrawlerHealth.keyOf(r.platform, r.action) === key);
  }

  /** 与 PlatformPacer 合并，给出每个平台/动作的健康视图。 */
  status(
    pacer: PlatformPacer,
    filter?: PlatformKey,
  ): CrawlerStatusEntry[] {
    const platforms: PlatformKey[] = filter
      ? [filter]
      : ["bilibili", "zhihu", "xiaohongshu", "weibo", "douyin", "kuaishou", "nowcoder", "tieba"];
    const actions: Array<"comments" | "search"> = ["comments", "search"];
    const out: CrawlerStatusEntry[] = [];
    for (const platform of platforms) {
      for (const action of actions) {
        const chain = backendChainFor(platform, action);
        if (chain.length === 0) continue;
        const preferred = chain[0];
        const key = CrawlerHealth.keyOf(platform, action);
        const history = this.records.filter((r) => CrawlerHealth.keyOf(r.platform, r.action) === key);
        const record = history[history.length - 1];
        const cooldownRemainingMs = pacer.cooldownRemainingMs(platform);
        const strikes = pacer.strikesOf(platform);

        // 趋势字段（环形缓冲统计）
        const samples = history.length;
        const successLike = history.filter((r) => r.outcome === "success" || r.outcome === "empty").length;
        const degradedLike = history.filter((r) => r.degraded).length;
        const successRate = samples > 0 ? successLike / samples : 0;
        const degradedRate = samples > 0 ? degradedLike / samples : 0;
        const recent = history.slice(-RECENT_COUNT).map((r) => ({
          at: r.at,
          backend: r.backend,
          outcome: r.outcome,
        }));

        let status: CrawlerStatus = "unknown";
        let hint = "尚无采集记录";
        if (record) {
          switch (record.outcome) {
            case "success":
              status = record.degraded ? "degraded" : "healthy";
              hint = record.degraded
                ? `主通道不可用，已降级到 ${record.backend}`
                : `主通道 ${record.backend} 正常`;
              break;
            case "empty":
              status = record.degraded ? "degraded" : "healthy";
              hint = "通道可用，但目标无评论/结果为空";
              break;
            case "fallback":
              status = "degraded";
              hint = `正在降级重试（最近：${record.backend}）`;
              break;
            case "login_wall":
            case "captcha":
              status = "blocked";
              hint = record.outcome === "login_wall"
                ? "登录墙：需要用户登录后重试"
                : "命中验证码：人工接管或等待冷却";
              break;
            case "rate_limited":
              status = "cooling";
              hint = "接口限流/导航挂起";
              break;
            case "error":
              status = "degraded";
              hint = `最近失败：${record.error ?? "未知错误"}`;
              break;
          }
        }
        if (cooldownRemainingMs > 0) {
          status = "cooling";
          hint = `平台风控冷却中（剩 ${Math.ceil(cooldownRemainingMs / 1000)}s）：${hint}`;
        }
        out.push({
          platform,
          action,
          status,
          preferredBackend: preferred.id,
          lastBackend: record?.backend ?? "",
          lastOutcome: record?.outcome ?? "",
          degraded: record?.degraded ?? false,
          cooldownRemainingMs,
          strikes,
          lastAt: record?.at ?? "",
          lastError: record?.error ?? "",
          hint,
          samples,
          successRate,
          degradedRate,
          recent,
        });
      }
    }
    return out;
  }

  flush(): void {
    this.persist();
  }

  dispose(): void {
    this.disposed = true;
    this.flush();
  }

  private persist(): void {
    if (!this.stateFile || this.disposed) return;
    try {
      const snapshot: HealthSnapshot = { version: 1, records: this.records };
      const tmp = `${this.stateFile}.tmp`;
      const dir = dirname(this.stateFile);
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      writeFileSync(tmp, JSON.stringify(snapshot), "utf8");
      renameSync(tmp, this.stateFile);
    } catch (error) {
      if (!this.silent) {
        console.warn(
          `[dsh-community-listening] crawler-health 落盘失败：${error instanceof Error ? error.message : String(error)}`,
        );
      }
    }
  }

  private load(): void {
    try {
      if (!existsSync(this.stateFile)) return;
      const raw = readFileSync(this.stateFile, "utf8");
      const parsed = JSON.parse(raw) as HealthSnapshot;
      if (parsed?.version !== 1 || !Array.isArray(parsed.records)) return;
      const loaded = parsed.records
        .filter((r) => r && typeof r === "object" && r.platform && r.action && r.backend)
        .map((r) => ({
          platform: r.platform,
          action: r.action,
          at: String(r.at ?? ""),
          backend: String(r.backend),
          outcome: r.outcome,
          degraded: r.degraded === true,
          error: typeof r.error === "string" ? r.error : undefined,
        }));
      // 文件可能被手工塞满：按「平台+动作」截断到最近 MAX_RECORDS_PER_KEY 条
      const byKey = new Map<string, HealthRecord[]>();
      for (const r of loaded) {
        const key = CrawlerHealth.keyOf(r.platform, r.action);
        const list = byKey.get(key) ?? [];
        list.push(r);
        byKey.set(key, list);
      }
      this.records = [];
      for (const list of byKey.values()) {
        this.records.push(...list.slice(-MAX_RECORDS_PER_KEY));
      }
    } catch {
      // 损坏文件忽略（下次写覆盖）
    }
  }
}
