/**
 * 向量化客户端（主题聚类 M4 的 embedding 来源）。
 *
 * 通道：SiliconFlow OpenAI 兼容 /embeddings（BAAI/bge-m3，1024 维）。
 * 配置来源：Config 覆盖 → process.env → Insight AI 的 .env
 *  （SILICONFLOW_API_KEY / SILICONFLOW_BASE_URL / EMBEDDING_MODEL）。
 * 走代理感知 httpFetch；失败返回 null（调用方回退关键词聚类）。
 */

import { readFileSync } from "node:fs";
import { parseEnvText } from "../llm";
import { httpFetch } from "../net";

export interface EmbeddingConfig {
  apiKey: string;
  baseUrl: string;
  model: string;
}

export function loadEmbeddingConfig(
  envPath?: string,
  overrides: { apiKey?: string; baseUrl?: string; model?: string } = {},
): EmbeddingConfig {
  const env: Record<string, string> = {};
  for (const key of ["SILICONFLOW_API_KEY", "SILICONFLOW_BASE_URL", "EMBEDDING_MODEL"]) {
    const v = process.env[key];
    if (v) env[key] = v;
  }
  if (envPath) {
    try {
      const fileEnv = parseEnvText(readFileSync(envPath, "utf8"));
      for (const key of ["SILICONFLOW_API_KEY", "SILICONFLOW_BASE_URL", "EMBEDDING_MODEL"]) {
        if (env[key] === undefined && fileEnv[key] !== undefined) env[key] = fileEnv[key];
      }
    } catch {
      // .env 不可读 → 仅用 process.env
    }
  }
  return {
    apiKey: overrides.apiKey || env.SILICONFLOW_API_KEY || "",
    baseUrl: overrides.baseUrl || env.SILICONFLOW_BASE_URL || "https://api.siliconflow.cn/v1",
    model: overrides.model || env.EMBEDDING_MODEL || "BAAI/bge-m3",
  };
}

export interface EmbedResult {
  vectors: number[][];
  model: string;
  dim: number;
}

const MAX_BATCH = 32;
const EMBED_TIMEOUT_MS = 30_000;

/** 批量向量化；失败返回 null。 */
export async function embedTexts(
  cfg: EmbeddingConfig,
  texts: string[],
  signal?: AbortSignal,
): Promise<EmbedResult | null> {
  if (!cfg.apiKey || texts.length === 0) return null;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), EMBED_TIMEOUT_MS);
  const onOuter = () => controller.abort();
  signal?.addEventListener("abort", onOuter, { once: true });
  try {
    const vectors: number[][] = [];
    for (let from = 0; from < texts.length; from += MAX_BATCH) {
      const batch = texts.slice(from, from + MAX_BATCH);
      const resp = await httpFetch(`${cfg.baseUrl.replace(/\/+$/, "")}/embeddings`, {
        method: "POST",
        signal: controller.signal,
        headers: {
          "content-type": "application/json",
          authorization: `Bearer ${cfg.apiKey}`,
        },
        body: JSON.stringify({ model: cfg.model, input: batch }),
      });
      if (!resp.ok) return null;
      const data = (await resp.json()) as { data?: Array<{ embedding?: number[] }> };
      const batchVectors = (data.data ?? []).map((d) => d.embedding ?? []);
      if (batchVectors.length !== batch.length || batchVectors.some((v) => v.length === 0)) {
        return null;
      }
      vectors.push(...batchVectors);
    }
    if (vectors.length !== texts.length) return null;
    return { vectors, model: cfg.model, dim: vectors[0]?.length ?? 0 };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onOuter);
  }
}
