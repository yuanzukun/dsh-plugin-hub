/**
 * 情感分析引擎（M2：词典+规则快路径 + 可选 LLM 校准）。
 *
 * 参考：大连理工情感词汇本体库分类体系（7 大类：乐/好/怒/哀/惧/恶/惊）
 * —— 自建精简词表（按 DUTIR 大类归类，后续可扩展细粒度情绪输出）。
 *
 * 规则：
 * - 否定词（不/没/无/别/莫/非…）紧邻情感词（≤2 字）→ 极性翻转
 * - 程度副词（很/非常/太/有点…）→ 权重放大/缩小
 * - 转折连词（但是/然而/不过/却…）→ 转折后段主导（前段 ×0.35）
 * - 感叹号叠加微调
 * - 得分归一化 [-1, 1]；|score| < 0.15 判 neutral
 * - 低置信样本（可选）走廉价 LLM few-shot 校准（≤ maxCalibrate 条）
 *
 * 纯函数可单测；LLM 校准失败不阻断（degraded 标记）。
 */

import type { CheapLlm } from "../llm";
import { extractJsonArray, extractJsonObject } from "../llm";

// ---------------------------------------------------------------------------
// 词典（按 DUTIR 7 大类归类；乐/好 = 正向；怒/哀/惧/恶/惊 = 负向）
// ---------------------------------------------------------------------------

/** 正向词（乐/好类：快乐、安心、尊敬、赞扬、相信、喜爱、祝愿）。 */
export const POSITIVE_WORDS: string[] = [
  // 乐
  "开心", "高兴", "快乐", "愉悦", "满意", "满足", "舒心", "舒服", "愉快", "欣喜", "欢喜",
  // 好 · 赞扬
  "不错", "好评", "推荐", "给力", "赞", "优秀", "出色", "杰出", "很棒", "很好", "极好", "完美",
  "靠谱", "良心", "良心价", "厚道", "实在", "专业", "高效", "快速", "及时", "耐心", "贴心",
  "负责", "敬业", "用心", "周到", "细致", "可靠", "稳定", "顺畅", "顺利", "成功", "通过",
  "offer", "录用", "上岸", "升值", "加薪", "涨薪", "福利好", "待遇好", "前景好", "值得",
  "划算", "实惠", "超值", "物美价廉", "性价比高", "惊艳", "惊喜", "创新", "前沿", "领先",
  "安全", "放心", "省心", "方便", "便捷", "简单", "好用", "流畅", "清晰", "丰富", "全面",
  "扎实", "严谨", "规范", "透明", "公平", "公正", "真诚", "热情", "友善", "温暖", "亲切",
  "舒适", "整洁", "干净", "卫生", "健康", "环保", "智能", "先进", "高端", "大气",
  "认可", "支持", "欢迎", "感谢", "欣赏", "敬佩", "信赖", "信任", "放心用", "闭眼入",
  "好", "好评如潮", "赞不绝口", "无可挑剔",
];

/** 负向词（怒/哀/惧/恶/惊类）。 */
export const NEGATIVE_WORDS: string[] = [
  // 怒
  "愤怒", "气愤", "恼火", "火大", "生气", "不满", "气愤填膺",
  // 哀
  "失望", "遗憾", "难过", "伤心", "悲伤", "痛苦", "心碎", "心累", "无奈", "绝望", "灰心", "沮丧",
  "后悔", "可惜", "惋惜", "心酸", "委屈", "寒心", "心寒",
  // 惧
  "害怕", "担心", "恐惧", "焦虑", "紧张", "不安", "担忧", "慌张", "胆战心惊", "后怕",
  // 恶
  "差", "差评", "糟糕", "垃圾", "烂", "坑", "坑人", "坑钱", "大坑", "雷", "避雷", "劝退",
  "恶心", "反感", "讨厌", "厌恶", "嫌弃", "敷衍", "冷漠", "傲慢", "态度差", "恶劣", "粗暴",
  "欺骗", "虚假", "诈骗", "骗局", "陷阱", "套路", "忽悠", "画饼", "洗脑", "压榨", "剥削",
  "加班", "996", "内卷", "PUA", "背刺", "裁员", "优化", "淘汰", "辞退", "劝退", "降薪",
  "扣钱", "克扣", "拖欠", "延迟", "拖延", "缓慢", "慢", "卡顿", "崩溃", "死机", "宕机",
  "不稳定", "故障", "出错", "报错", "失败", "拒绝", "驳回", "否定", "难", "困难", "艰难",
  "麻烦", "繁琐", "复杂", "混乱", "脏乱", "脏", "乱", "吵", "噪音", "拥挤", "排队",
  "贵", "太贵", "不值", "浪费", "吃亏", "亏", "赔钱", "受骗", "被骗", "投诉", "维权",
  "后悔", "买亏了", "翻车", "踩雷", "避坑", "别买", "别去", "别来", "不要去", "不要买",
  "黑", "黑心", "无良", "不良", "劣质", "假冒", "山寨", "缩水", "偷工减料", "缺斤少两",
  "有毒", "致癌", "危险", "隐患", "出问题", "有问题", "坏", "坏了", "失灵", "失效",
  "毛病", "毛病多",
];

/** 否定词（紧邻情感词前、无分隔符的上下文串以之结尾时翻转极性）。 */
export const NEGATION_WORDS: string[] = [
  "不", "没", "无", "未", "甭", "毫不", "绝非", "并非", "从不", "再也不", "压根不",
  "根本不", "完全没有", "一点不", "不太", "不怎么", "没有", "没什么",
];

/** 程度副词 → 权重（对紧邻情感词生效）。 */
export const DEGREE_ADVERBS: Record<string, number> = {
  "很": 1.6, "挺": 1.3, "比较": 0.8, "有点": 0.5, "有些": 0.5, "稍微": 0.4, "略": 0.4,
  "非常": 2.0, "特别": 1.9, "太": 2.0, "极其": 2.2, "十分": 1.9, "超级": 1.9, "相当": 1.6,
  "格外": 1.9, "极为": 2.2, "真": 1.4, "真的": 1.5, "确实": 1.5, "简直": 1.8,
};

/** 转折连词：后段主导（前段权重 ×0.35）。 */
export const TURN_WORDS: string[] = ["但是", "但", "然而", "不过", "可是", "可是说", "却", "反倒", "反而"];

/** 反讽/隐式表达标记（命中即触发 LLM 校准候选）。 */
export const IRONY_MARKERS: string[] = ["呵呵", "哈哈", "好棒棒", "真是谢谢", "可太", "真好笑", "笑死", "离谱", "绝了"];

export type Polarity = "positive" | "negative" | "neutral";

export interface ScoreResult {
  polarity: Polarity;
  /** 连续得分 [-1, 1]。 */
  score: number;
  /** 命中正向词次数。 */
  positiveHits: number;
  /** 命中负向词次数。 */
  negativeHits: number;
}

/** 取情感词前、无分隔符的紧邻上下文串（最多 max 字；否定/程度词都从该串后缀匹配）。 */
function contextRun(text: string, idx: number, max = 4): string {
  const delim = /[\s，。！？、；：,.!?;:()（）「」『』""''~～…·—]/;
  let start = idx;
  while (start > 0 && idx - start < max && !delim.test(text[start - 1])) start -= 1;
  return text.slice(start, idx);
}

/** 上下文串的最长后缀命中词（否定/程度词都按后缀匹配，避免「非常」里的「非」、「特别」里的「别」误判）。 */
function suffixInRun(run: string, words: string[]): string | null {
  let best: string | null = null;
  for (const w of words) {
    if (run.endsWith(w) && (best === null || w.length > best.length)) best = w;
  }
  return best;
}

/** 单条文本情感打分（词典+规则）。 */
export function scoreSentiment(text: string): ScoreResult {
  const content = (text ?? "").trim();
  if (!content) return { polarity: "neutral", score: 0, positiveHits: 0, negativeHits: 0 };

  // 转折切分：找最后一个转折词，前段权重压低
  let preWeight = 1;
  let lastTurn = -1;
  for (const w of TURN_WORDS) {
    const idx = content.lastIndexOf(w);
    if (idx > lastTurn) lastTurn = idx;
  }
  if (lastTurn >= 0) preWeight = 0.35;

  let weightedPos = 0;
  let weightedNeg = 0;

  const addHit = (word: string, isPositive: boolean) => {
    const idx = content.indexOf(word);
    if (idx === -1) return;
    const run = contextRun(content, idx, 4);
    let weight = 1;
    if (lastTurn >= 0 && idx < lastTurn) weight *= preWeight;
    const degree = suffixInRun(run, Object.keys(DEGREE_ADVERBS));
    if (degree) weight *= DEGREE_ADVERBS[degree];
    const negated = suffixInRun(run, NEGATION_WORDS);
    // 否定优先：被否定的词计入相反情感桶（「不好」=负；「没毛病」=正）
    if (negated) {
      if (isPositive) weightedNeg += weight;
      else weightedPos += weight;
    } else if (isPositive) {
      weightedPos += weight;
    } else {
      weightedNeg += weight;
    }
  };

  for (const w of POSITIVE_WORDS) addHit(w, true);
  for (const w of NEGATIVE_WORDS) addHit(w, false);

  // 感叹号微调
  const exclaim = (content.match(/[!！]/g) ?? []).length;
  let delta = weightedPos - weightedNeg;
  if (delta > 0) delta += Math.min(exclaim * 0.05, 0.3);
  if (delta < 0) delta -= Math.min(exclaim * 0.05, 0.3);

  const score = Math.max(-1, Math.min(1, delta / 5));
  let polarity: Polarity = "neutral";
  if (weightedPos > weightedNeg) polarity = "positive";
  else if (weightedNeg > weightedPos) polarity = "negative";
  return { polarity, score, positiveHits: Math.round(weightedPos), negativeHits: Math.round(weightedNeg) };
}

/** 判定是否低置信（|score| 低或含反讽标记）——LLM 校准候选。 */
export function isAmbiguous(result: ScoreResult, text: string): boolean {
  if (Math.abs(result.score) < 0.2) return true;
  return IRONY_MARKERS.some((m) => text.includes(m));
}

export interface MinedItem {
  id: string;
  text: string;
  polarity: Polarity;
  score: number;
  trust?: string;
  url?: string;
}

export interface SentimentAggregate {
  positive: number;
  negative: number;
  neutral: number;
  total: number;
  /** 平均得分 [-1,1]。 */
  avgScore: number;
  topNegative: Array<{ text: string; score: number; trust?: string }>;
  topPositive: Array<{ text: string; score: number; trust?: string }>;
  /** 校准是否成功应用（false = 纯词典/规则结果）。 */
  degraded: boolean;
  /** 校准通道状态说明（degraded 时给出原因，便于排查）。 */
  calibrationNote?: string;
}

const CALIBRATE_SCHEMA: Record<string, unknown> = {
  type: "object",
  properties: {
    items: {
      type: "array",
      properties: {},
    },
  },
};

/**
 * 廉价 LLM 校准：对低置信样本批量 few-shot 三分类。
 * 成功返回 Map<原文本, polarity>；失败返回 null（调用方沿用词典结果）。
 */
export async function calibrateViaLlm(
  cheap: CheapLlm | undefined,
  texts: Array<{ text: string; index: number }>,
): Promise<Map<number, Polarity> | null> {
  if (texts.length === 0 || !cheap || !cheap.available()) return null;
  const system =
    "你是中文情感分类助手。只输出 JSON 数组，不要输出其他内容。" +
    "对每条文本判断情感极性：positive（正面）/ negative（负面）/ neutral（中性）。" +
    "注意反讽（如「呵呵，真棒」实际为负面）与隐式表达。";
  const lines = texts
    .map((t) => `${t.index}. ${t.text.replace(/\n/g, " ").slice(0, 200)}`)
    .join("\n");
  const prompt = `请对以下文本逐条分类，输出 JSON 数组，元素为 {"index": 序号, "polarity": "positive|negative|neutral"}：\n${lines}`;
  // 裸数组优先（cheapLlmJson 只能提取单个对象，会解析失败）；兼容 {"items": [...]} 包裹
  const raw = await cheap.complete(
    `${system}\n必须只输出 JSON 数组，不要输出任何其他内容。`,
    prompt,
  );
  if (raw === null) return null;
  let list: unknown[] | null = extractJsonArray(raw);
  if (list === null) {
    const wrapped = extractJsonObject(raw);
    const items = wrapped && typeof wrapped === "object" ? (wrapped as Record<string, unknown>).items : undefined;
    list = Array.isArray(items) ? items : null;
  }
  if (!list) return null;
  const map = new Map<number, Polarity>();
  for (const item of list) {
    if (item && typeof item === "object") {
      const obj = item as Record<string, unknown>;
      const index = Number(obj.index);
      const polarity = String(obj.polarity ?? "").toLowerCase();
      if (Number.isInteger(index) && (polarity === "positive" || polarity === "negative" || polarity === "neutral")) {
        map.set(index, polarity as Polarity);
      }
    }
  }
  return map.size > 0 ? map : null;
}

export interface MineSentimentOptions {
  /** 是否启用 LLM 校准（默认 true）。 */
  calibrate?: boolean;
  /** 校准样本上限（默认 10）。 */
  maxCalibrate?: number;
}

/** 批量情感分析：词典快路径 → 可选 LLM 校准 → 聚合。 */
export async function mineSentiment(
  items: Array<{ id: string; text: string; trust?: string; url?: string }>,
  cheap: CheapLlm | undefined,
  options: MineSentimentOptions = {},
): Promise<{ items: MinedItem[]; aggregate: SentimentAggregate }> {
  const calibrate = options.calibrate ?? true;
  const maxCalibrate = Math.max(0, Math.min(options.maxCalibrate ?? 10, 50));
  const results: MinedItem[] = items.map((item) => {
    const r = scoreSentiment(item.text);
    return { id: item.id, text: item.text, polarity: r.polarity, score: r.score, trust: item.trust, url: item.url };
  });

  let degraded = false;
  let calibrationNote = "";
  if (!calibrate) {
    calibrationNote = "已关闭 LLM 校准（calibrate=false），结果为词典/规则判定";
  } else if (!cheap?.available()) {
    calibrationNote = "廉价 LLM 通道未配置（check .env: OPENCODE_API_KEY / OPENAI_API_KEYS），未校准，结果为词典/规则判定";
  } else {
    const ambiguous: Array<{ text: string; index: number }> = [];
    for (let i = 0; i < results.length; i += 1) {
      if (isAmbiguous({ polarity: results[i].polarity, score: results[i].score, positiveHits: 0, negativeHits: 0 }, results[i].text)) {
        ambiguous.push({ text: results[i].text, index: i });
      }
      if (ambiguous.length >= maxCalibrate) break;
    }
    if (ambiguous.length > 0) {
      try {
        const calib = await calibrateViaLlm(cheap, ambiguous);
        if (calib) {
          let applied = 0;
          for (const [index, polarity] of calib) {
            if (results[index]) {
              results[index].polarity = polarity;
              applied += 1;
            }
          }
          calibrationNote = `已用 LLM 校准 ${applied}/${ambiguous.length} 条低置信样本`;
        } else {
          degraded = true;
          calibrationNote = "校准通道调用失败（限流/额度用尽或输出解析失败），沿用词典/规则结果";
        }
      } catch (error) {
        degraded = true;
        calibrationNote = `校准异常：${error instanceof Error ? error.message : String(error)}`;
      }
    }
  }

  const aggregate = aggregateSentiment(results);
  return { items: results, aggregate: { ...aggregate, degraded, calibrationNote } };
}

/** 聚合：分桶 + 平均分 + Top 正负向证据（trust 有值才写入，避免 undefined 破坏 lossless JSON）。 */
export function aggregateSentiment(items: MinedItem[]): SentimentAggregate {
  const buckets = { positive: 0, negative: 0, neutral: 0 };
  let sum = 0;
  const negativeList: Array<{ text: string; score: number; trust?: string }> = [];
  const positiveList: Array<{ text: string; score: number; trust?: string }> = [];
  for (const item of items) {
    buckets[item.polarity] += 1;
    sum += item.score;
    if (item.polarity === "negative") negativeList.push({ text: item.text, score: item.score, ...(item.trust ? { trust: item.trust } : {}) });
    if (item.polarity === "positive") positiveList.push({ text: item.text, score: item.score, ...(item.trust ? { trust: item.trust } : {}) });
  }
  negativeList.sort((a, b) => a.score - b.score);
  positiveList.sort((a, b) => b.score - a.score);
  return {
    ...buckets,
    total: items.length,
    avgScore: items.length > 0 ? Math.round((sum / items.length) * 100) / 100 : 0,
    topNegative: negativeList.slice(0, 5).map((n) => ({ text: n.text.slice(0, 120), score: n.score, ...(n.trust ? { trust: n.trust } : {}) })),
    topPositive: positiveList.slice(0, 5).map((p) => ({ text: p.text.slice(0, 120), score: p.score, ...(p.trust ? { trust: p.trust } : {}) })),
    degraded: false,
  };
}
