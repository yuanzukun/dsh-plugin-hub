/**
 * SimHash 近似去重（M3：Google 网页去重标准做法）。
 *
 * - 分词：拉丁词 + CJK 连续字符二元组（bigram，降噪）
 * - 指纹：64 位（两个 32 位 FNV-1a 哈希拼接），token 按词频加权投票
 * - 相似判定：海明距离 ≤ threshold（中文推荐 4-6，默认 4）
 * - 聚类：并查集；输出簇（代表 + 成员）
 *
 * 纯 JS 实现，零外部依赖；O(n²) 距离计算对几百条语料足够。
 */

const HASH_SEED_A = 0x811c9dc5;
const HASH_SEED_B = 0x01000193;
const PRIME = 0x01000193;

/** FNV-1a 32 位哈希。 */
function fnv1a(str: string, seed: number): number {
  let hash = seed >>> 0;
  for (let i = 0; i < str.length; i += 1) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, PRIME) >>> 0;
  }
  return hash >>> 0;
}

/** 文本 → token 列表（拉丁词 + CJK bigram）。 */
export function tokenize(text: string): string[] {
  const tokens: string[] = [];
  const normalized = (text ?? "").toLowerCase();
  // 拉丁字母/数字词
  for (const m of normalized.matchAll(/[a-z0-9][a-z0-9._-]*/g)) {
    const w = m[0];
    if (w.length >= 2) tokens.push(w);
  }
  // CJK 连续段 → bigram
  const cjkRuns = normalized.match(/[\u4e00-\u9fff]+/g) ?? [];
  for (const run of cjkRuns) {
    if (run.length >= 2) {
      for (let i = 0; i + 1 < run.length; i += 1) {
        tokens.push(run.slice(i, i + 2));
      }
    } else {
      tokens.push(run);
    }
  }
  return tokens;
}

/** 64 位 SimHash 指纹（BigInt）。 */
export function simhashFingerprint(text: string): bigint {
  const tokens = tokenize(text);
  if (tokens.length === 0) return 0n;
  const freq = new Map<string, number>();
  for (const t of tokens) freq.set(t, (freq.get(t) ?? 0) + 1);

  const votes = new Int32Array(64);
  for (const [token, count] of freq) {
    const w = Math.sqrt(count);
    const hA = fnv1a(token, HASH_SEED_A);
    const hB = fnv1a(token + "\u0001", HASH_SEED_B);
    // 64 位：前 32 位来自 hA，后 32 位来自 hB
    for (let bit = 0; bit < 32; bit += 1) {
      if (hA & (1 << bit)) votes[bit] += w;
      else votes[bit] -= w;
      if (hB & (1 << bit)) votes[32 + bit] += w;
      else votes[32 + bit] -= w;
    }
  }
  let fp = 0n;
  for (let bit = 0; bit < 64; bit += 1) {
    if (votes[bit] >= 0) fp |= 1n << BigInt(bit);
  }
  return fp;
}

/** 海明距离（两个 64 位指纹）。 */
export function hammingDistance(a: bigint, b: bigint): number {
  let x = a ^ b;
  let count = 0;
  while (x !== 0n) {
    x &= x - 1n;
    count += 1;
  }
  return count;
}

export interface SimilarCluster {
  /** 簇内成员 id（输入 items 的 id）。 */
  members: string[];
  size: number;
  /** 代表文本（最长成员）。 */
  representative: string;
  /** 去重后的独立计数（= 簇数，供报告「真实证据数」）。 */
  sources: string[];
}

export interface DedupeResult {
  /** 输入总数。 */
  total: number;
  /** 近似重复条数（被合并进簇的非代表成员）。 */
  duplicateCount: number;
  /** 独立簇数（含单例）。 */
  clusterCount: number;
  /** 非单例簇（近似重复组）。 */
  clusters: SimilarCluster[];
  /** 参与比对的 url 集（簇内去重后）。 */
  urls: string[];
}

export interface DedupeOptions {
  /** 海明距离阈值（默认 6；中文短文本对插入敏感，配合 Jaccard 联合判定）。 */
  threshold?: number;
  /** token 集合 Jaccard 相似度阈值（默认 0.45；海明或 Jaccard 任一达标即判相似）。 */
  jaccardThreshold?: number;
}

/** token 集合 Jaccard 相似度。 */
export function tokenJaccard(a: string, b: string): number {
  const setA = new Set(tokenize(a));
  const setB = new Set(tokenize(b));
  if (setA.size === 0 || setB.size === 0) return 0;
  let inter = 0;
  for (const x of setA) if (setB.has(x)) inter += 1;
  const union = setA.size + setB.size - inter;
  return union === 0 ? 0 : inter / union;
}

/** 近似去重：指纹海明距离 + bigram Jaccard 联合判相似 → 并查集聚类。 */
export function dedupeSimilar(
  items: Array<{ id: string; text: string; url?: string }>,
  options: DedupeOptions = {},
): DedupeResult {
  const threshold = Math.max(1, Math.min(options.threshold ?? 6, 12));
  const jaccardThreshold = Math.max(0.1, Math.min(options.jaccardThreshold ?? 0.45, 1));
  const n = items.length;
  const fingerprints = items.map((item) => simhashFingerprint(item.text ?? ""));
  const bags = items.map((item) => new Set(tokenize(item.text ?? "")));

  // 并查集
  const parent = Array.from({ length: n }, (_, i) => i);
  const find = (x: number): number => {
    while (parent[x] !== x) {
      parent[x] = parent[parent[x]];
      x = parent[x];
    }
    return x;
  };
  const union = (a: number, b: number) => {
    const ra = find(a);
    const rb = find(b);
    if (ra !== rb) parent[ra] = rb;
  };

  for (let i = 0; i < n; i += 1) {
    for (let j = i + 1; j < n; j += 1) {
      const simByHash = hammingDistance(fingerprints[i], fingerprints[j]) <= threshold;
      const simByJaccard = tokenJaccard(items[i].text ?? "", items[j].text ?? "") >= jaccardThreshold;
      if (simByHash || simByJaccard) {
        union(i, j);
      }
    }
  }

  const groups = new Map<number, number[]>();
  for (let i = 0; i < n; i += 1) {
    const root = find(i);
    const list = groups.get(root);
    if (list) list.push(i);
    else groups.set(root, [i]);
  }

  const clusters: SimilarCluster[] = [];
  let duplicateCount = 0;
  for (const members of groups.values()) {
    if (members.length <= 1) continue;
    const ordered = members.sort((a, b) => (items[b].text ?? "").length - (items[a].text ?? "").length);
    const representative = items[ordered[0]].text;
    const urls = ordered.map((i) => items[i].url ?? "").filter(Boolean);
    clusters.push({
      members: ordered.map((i) => items[i].id),
      size: ordered.length,
      representative: representative.slice(0, 200),
      sources: Array.from(new Set(urls)),
    });
    duplicateCount += ordered.length - 1;
  }
  clusters.sort((a, b) => b.size - a.size);

  return {
    total: n,
    duplicateCount,
    clusterCount: groups.size,
    clusters,
    urls: Array.from(new Set(items.map((i) => i.url ?? "").filter(Boolean))),
  };
}
