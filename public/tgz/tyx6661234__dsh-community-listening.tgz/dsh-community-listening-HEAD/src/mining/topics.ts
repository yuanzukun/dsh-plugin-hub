/**
 * 主题聚类（M4：文章分支）。
 *
 * 主路径：bge-m3 embedding（SiliconFlow）→ 本地 KMeans（余弦距离）→ cheap LLM 命名。
 * 回退路径：无 embedding 时用 CJK bigram 关键词 Jaccard 贪心聚类（degraded 标记，不阻断）。
 * 每簇输出：标签 / 规模 / 代表文本 / 来源 / 平均情感（复用词典情感快路径）。
 */

import type { CheapLlm } from "../llm";
import { cheapLlmJson } from "../llm";
import { aggregateSentiment, scoreSentiment, type MinedItem } from "./sentiment";
import type { EmbedResult } from "./embed";

export interface TopicItem {
  id: string;
  text: string;
  url?: string;
  source?: string;
}

export interface TopicCluster {
  label: string;
  note: string;
  size: number;
  representative: string;
  sources: string[];
  /** 簇平均情感极性（词典快路径）。 */
  avgSentiment: "positive" | "negative" | "neutral";
  avgScore: number;
}

export interface ClusterTopicsResult {
  total: number;
  method: "embedding" | "keyword";
  degraded: boolean;
  embeddingAvailable: boolean;
  topics: TopicCluster[];
}

// ---------------------------------------------------------------------------
// KMeans（余弦距离；k-means++ 初始化，多次重启取最优）
// ---------------------------------------------------------------------------

function cosine(a: number[], b: number[]): number {
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < a.length; i += 1) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

function kmeans(vectors: number[][], k: number, maxIter = 60, restarts = 3): { assignments: number[]; inertia: number } {
  const n = vectors.length;
  const dim = vectors[0]?.length ?? 0;
  let best: { assignments: number[]; inertia: number } | null = null;

  for (let restart = 0; restart < restarts; restart += 1) {
    // k-means++ 初始化
    const centroids: number[][] = [];
    const firstIdx = (restart * 7919 + 17) % n;
    centroids.push(vectors[firstIdx].slice());
    while (centroids.length < k) {
      const dists: number[] = [];
      let sum = 0;
      for (let i = 0; i < n; i += 1) {
        let bestSim = -Infinity;
        for (const c of centroids) {
          const sim = cosine(vectors[i], c);
          if (sim > bestSim) bestSim = sim;
        }
        const d = 1 - bestSim;
        dists.push(d);
        sum += d;
      }
      let r = Math.random() * sum;
      let pick = n - 1;
      for (let i = 0; i < n; i += 1) {
        r -= dists[i];
        if (r <= 0) {
          pick = i;
          break;
        }
      }
      centroids.push(vectors[pick].slice());
    }

    const assignments = new Array<number>(n).fill(0);
    for (let iter = 0; iter < maxIter; iter += 1) {
      let changed = false;
      for (let i = 0; i < n; i += 1) {
        let bestSim = -Infinity;
        let bestIdx = 0;
        for (let c = 0; c < centroids.length; c += 1) {
          const sim = cosine(vectors[i], centroids[c]);
          if (sim > bestSim) {
            bestSim = sim;
            bestIdx = c;
          }
        }
        if (assignments[i] !== bestIdx) {
          assignments[i] = bestIdx;
          changed = true;
        }
      }
      if (!changed) break;
      // 重算质心
      const sums = Array.from({ length: k }, () => new Array<number>(dim).fill(0));
      const counts = new Array<number>(k).fill(0);
      for (let i = 0; i < n; i += 1) {
        const c = assignments[i];
        counts[c] += 1;
        for (let d = 0; d < dim; d += 1) sums[c][d] += vectors[i][d];
      }
      for (let c = 0; c < k; c += 1) {
        if (counts[c] > 0) {
          for (let d = 0; d < dim; d += 1) centroids[c][d] = sums[c][d] / counts[c];
        }
      }
    }

    let inertia = 0;
    for (let i = 0; i < n; i += 1) {
      inertia += 1 - cosine(vectors[i], centroids[assignments[i]]);
    }
    if (best === null || inertia < best.inertia) {
      best = { assignments, inertia };
    }
  }
  return best!;
}

// ---------------------------------------------------------------------------
// 关键词回退聚类（无 embedding 时；CJK bigram 集合 Jaccard 贪心）
// ---------------------------------------------------------------------------

function keywordBag(text: string): Set<string> {
  const bag = new Set<string>();
  const runs = (text ?? "").toLowerCase().match(/[\u4e00-\u9fff]+/g) ?? [];
  for (const run of runs) {
    if (run.length >= 2) {
      for (let i = 0; i + 1 < run.length; i += 1) bag.add(run.slice(i, i + 2));
    } else {
      bag.add(run);
    }
  }
  return bag;
}

function jaccard(a: Set<string>, b: Set<string>): number {
  if (a.size === 0 || b.size === 0) return 0;
  let inter = 0;
  for (const x of a) if (b.has(x)) inter += 1;
  const union = a.size + b.size - inter;
  return union === 0 ? 0 : inter / union;
}

/** 贪心聚类：每条归入平均相似度最高的簇（≥ minSim），否则新建。 */
function keywordClusters(items: TopicItem[], minSim = 0.22): number[][] {
  const bags = items.map((i) => keywordBag(i.text));
  const clusters: number[][] = [];
  for (let i = 0; i < items.length; i += 1) {
    let bestIdx = -1;
    let bestSim = 0;
    for (let c = 0; c < clusters.length; c += 1) {
      const members = clusters[c];
      let sum = 0;
      for (const m of members) sum += jaccard(bags[i], bags[m]);
      const avg = sum / members.length;
      if (avg > bestSim) {
        bestSim = avg;
        bestIdx = c;
      }
    }
    if (bestIdx >= 0 && bestSim >= minSim) clusters[bestIdx].push(i);
    else clusters.push([i]);
  }
  return clusters;
}

// ---------------------------------------------------------------------------
// 主题命名
// ---------------------------------------------------------------------------

const LABEL_SCHEMA: Record<string, unknown> = {
  type: "object",
  properties: {
    topics: {
      type: "array",
      properties: {},
    },
  },
};

/** cheap LLM 为每个簇命名（≤10 字标签 + 一句话说明）；失败回退关键词标签。 */
async function nameClusters(
  cheap: CheapLlm | undefined,
  clusters: Array<{ representative: string; samples: string[] }>,
): Promise<Array<{ label: string; note: string }>> {
  if (clusters.length === 0 || !cheap || !cheap.available()) return clusters.map(() => ({ label: "", note: "" }));
  const system =
    "你是主题命名助手。为每组文本生成简洁中文主题标签（≤10 字）与一句话说明。只输出 JSON 数组，不要输出其他内容。";
  const blocks = clusters
    .map((c, i) => {
      const samples = c.samples.slice(0, 3).map((s) => s.replace(/\n/g, " ").slice(0, 120)).join(" | ");
      return `${i + 1}. 代表文本：${c.representative.replace(/\n/g, " ").slice(0, 150)}\n   其他样本：${samples}`;
    })
    .join("\n\n");
  const prompt = `请为以下 ${clusters.length} 组文本各生成一个主题标签。输出 JSON 数组，元素为 {"index": 序号, "label": "≤10字标签", "note": "一句话说明"}：\n\n${blocks}`;
  const parsed = await cheapLlmJson(cheap, system, prompt, { type: "object", properties: { topics: { type: "array" } } });
  const list = Array.isArray(parsed?.topics) ? (parsed.topics as unknown[]) : null;
  if (!list) return clusters.map(() => ({ label: "", note: "" }));
  const out = new Array<{ label: string; note: string }>(clusters.length).fill({ label: "", note: "" });
  for (const item of list) {
    if (item && typeof item === "object") {
      const obj = item as Record<string, unknown>;
      const index = Number(obj.index);
      if (Number.isInteger(index) && index >= 1 && index <= clusters.length) {
        out[index - 1] = {
          label: String(obj.label ?? "").trim().slice(0, 12),
          note: String(obj.note ?? "").trim().slice(0, 60),
        };
      }
    }
  }
  return out;
}

/** 簇关键词标签（命名失败回退）：bigram 词频 top-3 拼接。 */
function keywordLabel(items: TopicItem[], members: number[]): string {
  const freq = new Map<string, number>();
  for (const m of members) {
    for (const token of keywordBag(items[m].text)) {
      freq.set(token, (freq.get(token) ?? 0) + 1);
    }
  }
  const sorted = Array.from(freq.entries())
    .filter(([, c]) => c >= 2)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([t]) => t);
  return sorted.length > 0 ? sorted.join("、") : `主题${members[0] + 1}`;
}

export interface ClusterTopicsOptions {
  k?: number;
  /** embedding 结果（外部注入，便于测试/失败处理）。 */
  embed?: EmbedResult | null;
}

/** 主题聚类主入口。 */
export async function clusterTopics(
  items: TopicItem[],
  cheap: CheapLlm | undefined,
  options: ClusterTopicsOptions = {},
): Promise<ClusterTopicsResult> {
  const n = items.length;
  const texts = items.map((i) => (i.text ?? "").slice(0, 2000));
  const k = Math.max(2, Math.min(options.k ?? Math.max(2, Math.ceil(n / 5)), 12));

  let assignments: number[] | null = null;
  let method: "embedding" | "keyword" = "keyword";
  let degraded = false;
  let embeddingAvailable = false;

  if (options.embed && options.embed.vectors.length === n) {
    embeddingAvailable = true;
    const result = kmeans(options.embed.vectors, Math.min(k, n));
    assignments = result.assignments;
    method = "embedding";
  } else if (options.embed === undefined) {
    // 未注入（调用方已尝试并失败）→ 关键词回退
    degraded = true;
  }

  if (assignments === null) {
    // 关键词回退聚类
    const groups = keywordClusters(items);
    assignments = new Array<number>(n).fill(0);
    groups.forEach((members, ci) => {
      for (const m of members) assignments![m] = ci;
    });
    degraded = true;
  }

  const clusterCount = assignments.length > 0 ? Math.max(...assignments) + 1 : 0;
  const membersByCluster: number[][] = Array.from({ length: clusterCount }, () => []);
  for (let i = 0; i < n; i += 1) membersByCluster[assignments[i]].push(i);
  // 剔除空簇，按规模降序
  const nonEmpty = membersByCluster.filter((m) => m.length > 0).sort((a, b) => b.length - a.length);

  const named = await nameClusters(
    cheap,
    nonEmpty.map((members) => {
      const sorted = [...members].sort((a, b) => items[b].text.length - items[a].text.length);
      return {
        representative: items[sorted[0]].text,
        samples: sorted.slice(0, 5).map((i) => items[i].text),
      };
    }),
  );

  const topics: TopicCluster[] = nonEmpty.map((members, ci) => {
    const sorted = [...members].sort((a, b) => items[b].text.length - items[a].text.length);
    const representative = items[sorted[0]].text;
    const sources = Array.from(new Set(sorted.map((i) => items[i].url ?? items[i].source ?? "").filter(Boolean)));
    const mined: MinedItem[] = members.map((i) => {
      const r = scoreSentiment(items[i].text);
      return { id: items[i].id, text: items[i].text, polarity: r.polarity, score: r.score };
    });
    const agg = aggregateSentiment(mined);
    const label = named[ci]?.label || keywordLabel(items, members);
    const note = named[ci]?.note || "";
    return {
      label,
      note,
      size: members.length,
      representative: representative.slice(0, 300),
      sources,
      avgSentiment: agg.positive > agg.negative ? "positive" : agg.negative > agg.positive ? "negative" : "neutral",
      avgScore: agg.avgScore,
    };
  });

  return { total: n, method, degraded, embeddingAvailable, topics };
}
