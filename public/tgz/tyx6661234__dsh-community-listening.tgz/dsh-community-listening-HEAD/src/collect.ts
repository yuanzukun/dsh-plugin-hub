/**
 * 采集编排（对齐 comment_service）：
 * - collectComments：平台 API 通道优先，其余与降级走 bsk 浏览器展开评论（best-effort）
 *   → LLM 提取评论 → 降噪 → 情感分桶
 *
 * 简化边界（v1 不做）：TLS/JA3 指纹、stealth、登录态 Chrome 复用、judge 防编造
 * （以 suspect 启发式代替）。bsk 不可用时浏览器路径返回可读降级信息。
 */

import type { Context } from "@deepseek-ai/cordis";
import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import { spawn } from "node:child_process";
import { cpSync, existsSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { createBskRunner, parseBskJson, type BskRunner } from "./runner";
import { backendChainFor, runChannelChain, type BackendSpec, type ChannelAttempt, type ChannelAttemptOutcome, type PlatformKey } from "./channels";
import { CrawlerHealth, type HealthOutcome } from "./health";
import { looksLikeCaptcha } from "./net";
import { cheapLlmJson, llmJson, type CheapLlm, type LlmDeps } from "./llm";
import { aggregateSentiment, denoiseComments } from "./comments";
import { appendEntries, makeEntry, resolveCorpusRoot } from "./corpus";
import { PlatformPacer, platformForUrl } from "./pacing";
import { collectZhihuAnswers, extractZhihuQid, unwrapEvaluateValue } from "./sources/zhihu";
import {
  buildBilibiliReplyMainScript,
  buildBilibiliViewScript,
  collectBilibiliComments,
  extractBvid,
} from "./sources/bilibili";
import { collectXiaohongshuNoteComments, extractXhsNoteId, extractXhsToken } from "./sources/xiaohongshu";
import { collectWeiboComments, collectWeiboSearch, extractWeiboMid } from "./sources/weibo";
import { collectDouyinComments, extractAwemeId, isDouyinShortUrl } from "./sources/douyin";
import { collectKuaishouComments, extractPhotoId } from "./sources/kuaishou";
import { collectNowcoderComments, extractNowcoderPostId } from "./sources/nowcoder";
import { collectTiebaComments, extractTiebaTid } from "./sources/tieba";
import type { CommentEntry, CommentMineResult } from "./types";

export interface CollectDeps {
  ctx: Context;
  bskPath: string;
  bskTimeoutMs: number;
  /** 廉价 LLM 通道（脏活优先；不可用时回退主模型路由）。 */
  cheap: CheapLlm;
  /** 语料根目录覆盖（Config corpusDir；留空用会话工作目录）。 */
  corpusDir?: string;
  /** 平台节流/冷却（风控指数退避；跨批次/跨会话生效）。 */
  pacer: PlatformPacer;
  /** 通道健康记录（crawler_status 读取 + 采集链路写入）。 */
  health: CrawlerHealth;
  /** 知乎回答采集上限（默认 50）。 */
  zhihuMaxAnswers?: number;
  /** 知乎对前 N 条回答取评论区（默认 10）。 */
  zhihuMaxAnswerComments?: number;
  /** B 站评论采集上限（默认 100）。 */
  bilibiliMaxComments?: number;
  /** B 站只对前 N 条主评论抓楼中楼（默认 20；mode=3 主评论按热度序，等效 Top-N）。 */
  bilibiliMaxReplyComments?: number;
  /** 可选 B 站登录 Cookie（Config bilibiliCookie；敏感，仅本机使用）。 */
  bilibiliCookie?: string;
}

const MAX_PAGE_CHARS = 60_000;

export const COMMENTS_SCHEMA: Record<string, unknown> = {
  type: "object",
  properties: {
    title: { type: "string" },
    comments: { type: "array" },
  },
};

/** 结构化提取：廉价通道（opencode free → sensenova lite）优先，失败回退主模型路由。 */
async function extractViaLlm(
  deps: CollectDeps,
  llmDeps: LlmDeps,
  system: string,
  prompt: string,
  schema: Record<string, unknown>,
): Promise<Record<string, unknown> | null> {
  return (
    (await cheapLlmJson(deps.cheap, system, prompt, schema)) ??
    (await llmJson(llmDeps, system, prompt, schema))
  );
}

// ---------------------------------------------------------------------------
// 浏览器会话池：N 个 bsk 会话（每个 = 一个 Agent Window 标签页），并发采集互不串台。
// 会话懒启动、复用；busy 标记保证同一会话同时只被一个任务占用。
//
// 断连自愈（Chrome 关闭 / bsk 守护进程重启后无浏览器接入）：
// - 每个浏览器 RPC 前先做短超时状态探针（TTL 3s），无浏览器 → 快速失败并尝试自动拉起，
//   不再让 RPC 挂满 bskTimeoutMs（默认 120s）；
// - RPC 失败后强制重探：浏览器已断连 → 抛 BrowserUnavailableError（基础设施错误），
//   上层据此不记平台 strike（避免把「Chrome 关了」误判成平台风控）。
// ---------------------------------------------------------------------------

/**
 * 浏览器/bsk 基础设施不可用（Chrome 关闭、扩展断连、守护进程重启后无浏览器接入）。
 * 与平台风控无关：调用方应快速失败并提示「重启 Chrome」，不得计入 pacer strike。
 */
export class BrowserUnavailableError extends Error {
  /** 底层 RPC 是否超时（true 时本错误由 RPC 超时转换而来）。 */
  readonly timedOut: boolean;

  constructor(message: string, options: { timedOut?: boolean } = {}) {
    super(message);
    this.name = "BrowserUnavailableError";
    this.timedOut = options.timedOut ?? false;
  }
}

/** 判断失败是否属于浏览器基础设施问题（不计平台 strike）。 */
export function isBrowserUnavailable(error: unknown): boolean {
  return error instanceof BrowserUnavailableError;
}

interface SessionSlot {
  sessionId: string | null;
  busy: boolean;
}

/** 一次浏览器任务持有的会话句柄。 */
export interface SessionHandle {
  sessionId: string;
  /** 在该会话上执行一条 bsk 命令（parseBskJson）。 */
  run(exec: ToolRunContext, args: string[], label: string): Promise<unknown>;
  /** 任务完成：释放会话供复用。 */
  release(): void;
  /** 会话失效（死亡/被停）：清空 sessionId 并释放，下次 acquire 重建。 */
  invalidate(): void;
}

/**
 * 可中止等待队列：等待者注册 abort listener —— abort 立即出队并唤醒（不等下一次
 * release/signal），调用方随后照常抛「浏览器采集被取消」；signal() 只唤醒存活等待者
 * （已 abort 出队的不会被空唤醒）。解决「取消延迟到下一次释放」与「空唤醒挂死」。
 */
export class AbortableWaitQueue {
  private waiters: Array<{ resolve: () => void; cleanup: () => void }> = [];

  /** 入队等待；signal abort 时立即出队并 resolve。已 abort 的 signal 直接 resolve。 */
  wait(signal?: AbortSignal): Promise<void> {
    if (signal?.aborted) return Promise.resolve();
    return new Promise<void>((resolve) => {
      let entry!: { resolve: () => void; cleanup: () => void };
      const cleanup = () => {
        const idx = this.waiters.indexOf(entry);
        if (idx >= 0) this.waiters.splice(idx, 1);
        signal?.removeEventListener("abort", onAbort);
      };
      const onAbort = () => {
        cleanup();
        resolve();
      };
      entry = { resolve, cleanup };
      this.waiters.push(entry);
      signal?.addEventListener("abort", onAbort, { once: true });
    });
  }

  /** 唤醒队首存活等待者（无等待者时静默）。 */
  signal(): void {
    const next = this.waiters.shift();
    if (!next) return;
    next.cleanup();
    next.resolve();
  }

  /** 当前排队等待者数量（测试/诊断用）。 */
  get size(): number {
    return this.waiters.length;
  }
}

/** 简易信号量（限浏览器并发）。 */
export class Semaphore {
  private count: number;
  private waiters = new AbortableWaitQueue();

  constructor(limit: number) {
    this.count = Math.max(1, limit);
  }

  async acquire(signal?: AbortSignal): Promise<void> {
    for (;;) {
      if (this.count > 0) {
        this.count -= 1;
        return;
      }
      await this.waiters.wait(signal);
      // abort 立即被唤醒；被 release 唤醒后发现已 abort 也在此抛错——
      // 不清点数（release 已 +1），许可留给下一个 acquire（语义正确）。
      if (signal?.aborted) throw new Error("浏览器采集被取消");
    }
  }

  release(): void {
    this.count += 1;
    this.waiters.signal();
  }
}

export class BrowserSessionPool {
  private runner: BskRunner;
  private readonly timeoutMs: number;
  private readonly maxConcurrency: number;
  private slots: SessionSlot[] = [];
  private waiters = new AbortableWaitQueue();
  private readonly autoLaunchChrome: boolean;
  private readonly chromePath: string | undefined;
  private readonly chromeProfileDir: string | undefined;
  /** 上次自动拉起 Chrome 的时间戳（冷却期内不重复拉起）。 */
  private launchedAtMs = 0;
  /** 浏览器接入状态探针缓存（TTL 3s，避免每个 RPC 都 spawn 一次 bsk status）。 */
  private statusCache: { at: number; connected: boolean; detail: string } | null = null;
  private static readonly STATUS_TTL_MS = 3000;

  constructor(
    bskPath: string,
    timeoutMs: number,
    maxConcurrency: number,
    options: {
      autoLaunchChrome?: boolean;
      chromePath?: string;
      chromeProfileDir?: string;
      /** 可注入 runner，供宿主生命周期管理与测试替身复用。 */
      runner?: BskRunner;
    } = {},
  ) {
    this.runner = options.runner ?? createBskRunner(bskPath);
    this.timeoutMs = timeoutMs;
    this.maxConcurrency = Math.max(1, maxConcurrency);
    this.autoLaunchChrome = options.autoLaunchChrome ?? true;
    this.chromePath = options.chromePath;
    this.chromeProfileDir = options.chromeProfileDir;
  }

  get runnerRef(): BskRunner {
    return this.runner;
  }

  /** 获取一个空闲会话句柄；池满时排队等待。 */
  async acquire(exec: ToolRunContext): Promise<SessionHandle> {
    const slot = await this.takeSlot(exec);
    try {
      const sessionId = await this.ensureSession(slot, exec);
      let currentSessionId = sessionId;
      const renew = (newId: string) => {
        currentSessionId = newId;
        slot.sessionId = newId;
      };
      return {
        get sessionId() {
          return currentSessionId;
        },
        run: (e, args, label) => this.runSession(currentSessionId, e, args, label, renew),
        release: () => {
          slot.busy = false;
          this.signal();
        },
        invalidate: () => {
          slot.sessionId = null;
          slot.busy = false;
          this.signal();
        },
      };
    } catch (error) {
      slot.busy = false;
      this.signal();
      throw error;
    }
  }

  private async takeSlot(exec: ToolRunContext): Promise<SessionSlot> {
    for (;;) {
      const free = this.slots.find((s) => !s.busy);
      if (free) {
        free.busy = true;
        return free;
      }
      if (this.slots.length < this.maxConcurrency) {
        const slot: SessionSlot = { sessionId: null, busy: true };
        this.slots.push(slot);
        return slot;
      }
      await this.waiters.wait(exec.signal);
      if (exec.signal?.aborted) throw new Error("浏览器采集被取消");
    }
  }

  private signal(): void {
    this.waiters.signal();
  }

  private async ensureSession(slot: SessionSlot, exec: ToolRunContext): Promise<string> {
    if (slot.sessionId) return slot.sessionId;
    await this.ensureBrowserConnected(exec);
    slot.sessionId = await this.startSession(exec);
    return slot.sessionId;
  }

  /**
   * 快速失败预检：bsk 必须有浏览器接入；无浏览器时尝试自动拉起，仍失败抛
   * BrowserUnavailableError（上层不计平台 strike）。短超时 + 短 TTL 缓存，
   * 避免 Chrome 关闭 / 守护进程重启后浏览器 RPC 挂满 bskTimeoutMs。
   */
  private async ensureBrowserConnected(exec: ToolRunContext): Promise<void> {
    const probe = await this.probeBrowser(exec);
    if (probe.connected) return;
    if (this.autoLaunchChrome) {
      const launched = await this.launchChromeOnce(exec);
      if (launched) {
        const again = await this.probeBrowser(exec, true);
        if (again.connected) return;
      }
    }
    throw new BrowserUnavailableError(
      `bsk 无浏览器接入（${probe.detail}）：Chrome 可能已关闭或扩展断连。` +
      (this.autoLaunchChrome ? "已尝试自动拉起 Chrome 未成功。" : "autoLaunchChrome 已关闭。") +
      "请手动重启 Chrome（打开一个窗口让 BrowserSkill 扩展连上 bsk）后重试；本次未触发平台冷却。",
    );
  }

  /** 浏览器接入探针：bsk status 短超时（5s）+ 3s TTL 缓存；force 绕过缓存。 */
  private async probeBrowser(
    exec: ToolRunContext,
    force = false,
  ): Promise<{ connected: boolean; detail: string }> {
    const now = Date.now();
    if (!force && this.statusCache && now - this.statusCache.at < BrowserSessionPool.STATUS_TTL_MS) {
      return this.statusCache;
    }
    let connected = false;
    let detail = "bsk 无浏览器接入";
    try {
      const status = await this.runner.run(["status"], { signal: exec.signal, timeoutMs: 5000 });
      const parsed = JSON.parse(status.stdout) as { browsers?: unknown[] };
      connected = Array.isArray(parsed.browsers) && parsed.browsers.length > 0;
      detail = connected ? "" : "bsk 守护进程无浏览器接入（Chrome 已关闭或扩展断连）";
    } catch (error) {
      const raw = error instanceof Error ? error.message : String(error);
      detail = `bsk 守护进程不可达（${raw.slice(0, 120)}）`;
    }
    this.statusCache = { at: now, connected, detail };
    return this.statusCache;
  }

  /** 失效浏览器接入缓存（RPC 失败后强制下次重探）。 */
  private invalidateBrowserCache(): void {
    this.statusCache = null;
  }

  /** 清空全部槽位 sessionId（守护进程重启/浏览器断连后，下次 acquire 重建会话）。 */
  private invalidateAllSessions(): void {
    for (const slot of this.slots) slot.sessionId = null;
  }

  /** 自动拉起本机 Chrome（默认 profile 自带 BrowserSkill 扩展 → 自动连上 bsk daemon）。 */
  private async launchChromeOnce(exec: ToolRunContext): Promise<boolean> {
    const now = Date.now();
    if (now - this.launchedAtMs < 60_000) return false; // 60s 冷却，避免重复拉起
    this.launchedAtMs = now;

    const chrome = this.chromePath || detectChromePath();
    if (!chrome || !existsSync(chrome)) {
      console.warn(`[dsh-community-listening] 未找到 Chrome（${chrome ?? "auto-detect failed"}），无法自动拉起`);
      return false;
    }

    const args: string[] = [];
    if (this.chromeProfileDir) {
      // 专属 profile：拷贝 BrowserSkill 扩展并 --load-extension 加载
      args.push(`--user-data-dir=${this.chromeProfileDir}`, "--no-first-run", "--no-default-browser-check");
      const extDir = ensureExtensionCopied();
      if (extDir) args.push(`--load-extension=${extDir}`);
    } else {
      // 默认 profile：直接启动（扩展已安装，登录态保留）；窗口移到屏幕外避免抢焦点
      args.push("--no-default-browser-check", "--no-first-run", "--window-position=-32000,-32000", "--new-window", "about:blank");
    }

    try {
      const child = spawn(chrome, args, { detached: true, stdio: "ignore" });
      child.unref();
      console.log(`[dsh-community-listening] 已自动拉起 Chrome（${chrome}${args.join(" ") ? ` ${args.join(" ")}` : ""}），等待扩展连接…`);
    } catch (error) {
      console.warn(`[dsh-community-listening] 拉起 Chrome 失败：${error instanceof Error ? error.message : String(error)}`);
      return false;
    }

    // 轮询 bsk browsers 连接（最长 25s，每 1s 一次）
    for (let i = 0; i < 25; i += 1) {
      await sleep(1000);
      if (exec.signal?.aborted) return false;
      try {
        const status = await this.runner.run(["status"], { signal: exec.signal, timeoutMs: 3000 });
        const parsed = JSON.parse(status.stdout) as { browsers?: unknown[] };
        if (Array.isArray(parsed.browsers) && parsed.browsers.length > 0) return true;
      } catch {
        // 继续轮询
      }
    }
    console.warn("[dsh-community-listening] 自动拉起 Chrome 后 25s 内未检测到浏览器连接");
    return false;
  }

  /** 用 8s 短超时探测 session start；无浏览器/异常快速失败。 */
  private async startSession(exec: ToolRunContext): Promise<string> {
    try {
      const reply = await this.runner.run(["session", "start"], {
        signal: exec.signal,
        timeoutMs: 8000,
      });
      if (reply.timedOut) {
        throw new Error(
          "bsk 无浏览器连接（session start 超时）。浏览器采集当前不可用，请检查 Chrome/bsk 状态后重试。",
        );
      }
      let parsed: { session_id?: string };
      try {
        parsed = JSON.parse(reply.stdout) as { session_id?: string };
      } catch {
        throw new Error(
          `bsk session start 无有效输出（code=${reply.code} stdoutLen=${reply.stdout.length} ` +
          `stderr=${reply.stderr.slice(0, 150)}）。浏览器采集当前不可用，请检查 bsk/Chrome 状态后重试。`,
        );
      }
      if (!parsed?.session_id) {
        throw new Error(`bsk 未返回 session_id（stdout=${reply.stdout.slice(0, 120)}）`);
      }
      return parsed.session_id;
    } catch (error) {
      const raw = error instanceof Error ? error.message : String(error);
      if (/无浏览器连接|无有效输出|未返回 session_id/.test(raw)) throw error;
      throw new Error(
        `bsk CLI 不可用（${raw}）。浏览器采集降级：请先安装 BrowserSkill 或改用 fetch 快路径。`,
      );
    }
  }

  private async runSession(
    sessionId: string,
    exec: ToolRunContext,
    args: string[],
    label: string,
    onRenew?: (newSessionId: string) => void,
  ): Promise<unknown> {
    // 预检：无浏览器接入直接快速失败（不把 RPC 挂满 bskTimeoutMs）
    await this.ensureBrowserConnected(exec);

    const result = await this.runner.run(args, {
      signal: exec.signal,
      timeoutMs: this.timeoutMs,
    });

    // RPC 失败（超时/非零退出）后强制重探浏览器接入：
    // 若浏览器已断连（Chrome 关闭 / 守护进程重启后无浏览器）→ 基础设施错误，
    // 清空全部槽位让下次重建会话，抛 BrowserUnavailableError（上层不计平台 strike）。
    if (result.timedOut || result.code !== 0) {
      const probe = await this.probeBrowser(exec, true);
      if (!probe.connected) {
        this.invalidateBrowserCache();
        this.invalidateAllSessions();
        throw new BrowserUnavailableError(
          `浏览器已断连（${probe.detail}）：Chrome 可能被关闭或 bsk 守护进程重启后无浏览器接入。` +
          "请手动重启 Chrome（让 BrowserSkill 扩展重新连上 bsk）后重试；本次未触发平台冷却。",
          { timedOut: result.timedOut },
        );
      }
    }

    // bsk daemon 重启 / Agent Window 被手动关闭后，会话会失效：
    // 自动清空槽位，并尝试在同一次调用内重建会话 + 重试当前命令，
    // 避免上层每个工具都要自己处理 “session not registered”。
    if (result.code !== 0) {
      const raw = `${result.stdout}\n${result.stderr}`;
      const staleRe = /session not registered|session.*stopped|already stopped/i;
      if (staleRe.test(raw)) {
        const slot = this.slots.find((s) => s.sessionId === sessionId);
        if (slot) slot.sessionId = null;
        if (slot && onRenew && !exec.signal?.aborted) {
          try {
            const fresh = await this.startSession(exec);
            slot.sessionId = fresh;
            onRenew(fresh);
            const retry = await this.runner.run(args, {
              signal: exec.signal,
              timeoutMs: this.timeoutMs,
            });
            if (retry.timedOut || retry.code !== 0) {
              const retryRaw = `${retry.stdout}\n${retry.stderr}`;
              if (staleRe.test(retryRaw) && slot.sessionId === fresh) slot.sessionId = null;
              return parseBskJson(retry, `${label} retry`);
            }
            return parseBskJson(retry, `${label} retry`);
          } catch (error) {
            // 重建会话/重试失败：透传；上层仍可按基础设施错误处理
            throw error;
          }
        }
      }
    }
    return parseBskJson(result, label);
  }

  /** 插件卸载时停止全部会话（best-effort）。 */
  async dispose(): Promise<void> {
    const ids = this.slots.map((s) => s.sessionId).filter((v): v is string => v !== null);
    await Promise.all(
      ids.map((id) => this.runner.run(["session", "stop", id], { timeoutMs: 15_000 }).catch(() => {})),
    );
    this.slots = [];
    this.runner.killAll();
  }
}

/** 延时（毫秒）。 */
function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** BrowserSkill 扩展 ID（bsk doctor 提供的官方 Chrome Web Store ID）。 */
const BROWSER_SKILL_EXT_ID = "hhcmgoofomhgciiibhipgmgkgnoenaoi";

/** 常见 Chrome/Edge 可执行文件路径（自动探测）。 */
const CHROME_CANDIDATES = [
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
  "%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
];

/** 探测本机 Chrome/Edge 路径；找不到返回 null。 */
export function detectChromePath(): string | null {
  for (const candidate of CHROME_CANDIDATES) {
    const resolved = candidate.startsWith("%LOCALAPPDATA%")
      ? join(process.env.LOCALAPPDATA ?? "", candidate.slice("%LOCALAPPDATA%\\".length))
      : candidate;
    if (existsSync(resolved)) return resolved;
  }
  return null;
}

/** 把用户默认 Chrome profile 里的 BrowserSkill 扩展拷贝到稳定目录（供 --load-extension）。 */
export function ensureExtensionCopied(): string | null {
  try {
    const userData = process.env.LOCALAPPDATA ?? "";
    const candidates = [
      join(userData, "Google", "Chrome", "User Data", "Default", "Extensions", BROWSER_SKILL_EXT_ID),
      join(userData, "Microsoft", "Edge", "User Data", "Default", "Extensions", BROWSER_SKILL_EXT_ID),
    ];
    for (const root of candidates) {
      if (!existsSync(root)) continue;
      const versions = readdirSync(root);
      if (versions.length === 0) continue;
      const src = join(root, versions[0]);
      if (!existsSync(join(src, "manifest.json"))) continue;
      const dest = join(userData, "dsh-community-listening", "browser-skill-ext");
      cpSync(src, dest, { recursive: true, force: true });
      return dest;
    }
  } catch {
    // 拷贝失败 → 返回 null（不阻断）
  }
  return null;
}

// ---------------------------------------------------------------------------
// 浏览器页面文本（弹窗关闭 + 陈旧会话恢复）
// ---------------------------------------------------------------------------

/** 从 bsk snapshot 文本中找「展开/加载更多」按钮的 @eN refs（best-effort）。 */
export function findExpandRefs(snapshotText: string, limit = 3): string[] {
  const refs: string[] = [];
  for (const line of snapshotText.split("\n")) {
    if (/展开|加载更多|更多回复|查看回复|回复/.test(line)) {
      const m = line.match(/@e(\d+)/);
      if (m) {
        const ref = `@e${m[1]}`;
        if (!refs.includes(ref)) refs.push(ref);
        if (refs.length >= limit) break;
      }
    }
  }
  return refs;
}

/** 从 snapshot 文本中找「关闭弹窗/遮罩」按钮的 @eN refs（登录弹窗等，best-effort）。 */
export function findCloseRefs(snapshotText: string, limit = 2): string[] {
  const refs: string[] = [];
  for (const line of snapshotText.split("\n")) {
    const m = line.match(/@e(\d+)/);
    if (!m) continue;
    if (/Close|关闭|\b×\b|✕/.test(line) && !/注册登录|登录|手机号|验证码/.test(line)) {
      const ref = `@e${m[1]}`;
      if (!refs.includes(ref)) refs.push(ref);
      if (refs.length >= limit) break;
    }
  }
  return refs;
}

/** 登录墙/弹窗启发式（命中说明页面内容被登录引导遮挡）。 */
export function looksLikeLoginWall(text: string): boolean {
  const hay = text.slice(0, 4000);
  return /注册登录|扫码登录|请先登录|立即登录|登录后查看|登录或完成注册|未注册手机验证后自动登录|登录\s+即可/.test(hay);
}

/** 从 observe/snapshot 输出里提取页面文本（容忍多种输出形状）。 */
export function pageTextFromObservation(value: unknown): string {
  if (typeof value === "string") return value;
  if (Array.isArray(value)) {
    return value
      .map((v) => (typeof v === "string" ? v : JSON.stringify(v)))
      .join("\n")
      .slice(0, MAX_PAGE_CHARS);
  }
  if (value && typeof value === "object") {
    const v = value as Record<string, unknown>;
    const candidates = ["text", "content", "summary", "observation", "markdown"];
    for (const key of candidates) {
      if (typeof v[key] === "string") return (v[key] as string).slice(0, MAX_PAGE_CHARS);
    }
    return JSON.stringify(value).slice(0, MAX_PAGE_CHARS);
  }
  return String(value ?? "").slice(0, MAX_PAGE_CHARS);
}

/** 浏览器路径：navigate → 关闭弹窗（best-effort）→ observe（必要时 snapshot）→ 页面文本。陈旧会话自动重建。 */
async function browserPageText(
  deps: CollectDeps,
  pool: BrowserSessionPool,
  exec: ToolRunContext,
  url: string,
): Promise<string> {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const handle = await pool.acquire(exec);
    try {
      const sessionId = handle.sessionId;
      await handle.run(exec, ["navigate", "--session", sessionId, url], "navigate");
      // best-effort：关掉登录/推广弹窗遮罩
      try {
        const snap = await handle.run(exec, ["snapshot", "--session", sessionId], "snapshot");
        const closeRefs = findCloseRefs(pageTextFromObservation(snap));
        for (const ref of closeRefs.slice(0, 2)) {
          try {
            await handle.run(exec, ["click", "--session", sessionId, ref], "click close");
          } catch {
            // 单个按钮失败不阻断
          }
        }
      } catch {
        // snapshot 失败不阻断
      }
      try {
        const observe = await handle.run(exec, ["observe", "--session", sessionId], "observe");
        return pageTextFromObservation(observe);
      } catch {
        const snapshot = await handle.run(exec, ["snapshot", "--session", sessionId], "snapshot");
        return pageTextFromObservation(snapshot);
      }
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      const stale = /session not registered|already stopped|session.*stopped/i.test(msg);
      if (stale && attempt === 0) {
        handle.invalidate();
        continue;
      }
      throw error;
    } finally {
      handle.release();
    }
  }
  throw new Error("browserPageText 重试耗尽");
}

// ---------------------------------------------------------------------------
// 评论落盘辅助
// ---------------------------------------------------------------------------

/** 从 URL 提取域名（source 字段）。 */
function safeHost(url: string): string {
  try {
    return new URL(url).hostname;
  } catch {
    return "";
  }
}

// ---------------------------------------------------------------------------
// 评论区挖掘
// ---------------------------------------------------------------------------

export interface CollectCommentsOptions {
  url: string;
  maxExpand: number;
  exec: ToolRunContext;
  /** 提供后每条降噪后评论自动落盘（kind=comment）。 */
  topic?: string;
}

/** 评论区挖掘（浏览器兜底路径）：浏览器展开 → 页面文本 → LLM 提取评论 → 降噪 → 情感分桶。 */
async function collectCommentsBrowser(
  deps: CollectDeps,
  pool: BrowserSessionPool,
  options: CollectCommentsOptions,
): Promise<CommentMineResult> {
  const { url, maxExpand } = options;
  const llmDeps: LlmDeps = { ctx: deps.ctx, signal: options.exec.signal };
  let handle: SessionHandle | null = null;

  try {
    handle = await pool.acquire(options.exec);
    const sessionId = handle.sessionId;
    const run = (args: string[], label: string) => handle!.run(options.exec, args, label);

    let text = await browserPageText(deps, pool, options.exec, url);

    // 展开「加载更多/展开回复」（best-effort，最多 maxExpand 轮；同一会话内进行）
    for (let round = 0; round < Math.min(maxExpand, 3); round += 1) {
      let snapshotText = "";
      try {
        const snapshot = await run(["snapshot", "--session", sessionId], "snapshot");
        snapshotText = pageTextFromObservation(snapshot);
      } catch {
        break;
      }
      const refs = findExpandRefs(snapshotText);
      if (refs.length === 0) break;
      for (const ref of refs) {
        try {
          await run(["click", "--session", sessionId, ref], "click");
        } catch {
          // 单个按钮失败不阻断
        }
      }
      const next = await browserPageText(deps, pool, options.exec, url);
      if (next.length <= text.length + 100) break; // 无新内容
      text = next;
    }

    if (looksLikeLoginWall(text)) {
      return { url, title: "", comments: [], sentiment: { positive: 0, negative: 0, neutral: 0 }, dropped: 0, error: "页面为登录墙（评论需登录后查看），可用已登录的浏览器手动展开或改用其他源" };
    }
    if (looksLikeCaptcha("", text)) {
      return { url, title: "", comments: [], sentiment: { positive: 0, negative: 0, neutral: 0 }, dropped: 0, error: "页面命中验证码/登录墙" };
    }

    const isZhihuQuestion = /zhihu\.com\/question\//i.test(url);
    const extractionSystem = isZhihuQuestion
      ? "你是知乎回答情报提炼助手。只使用页面中出现的信息；作者未知填空字符串；若无回答返回空数组。"
      : "你是评论区情报提炼助手。只使用页面中出现的信息；作者未知填空字符串；若无评论返回空数组。";
    const extractionPrompt = isZhihuQuestion
      ? `从以下页面文本中提取该问题的全部回答（按赞同数优先，含作者与内容；嵌套回复并入作者回答）。\n\n【页面文本】\n${text.slice(0, MAX_PAGE_CHARS)}`
      : `从以下页面文本中提取全部评论（含作者与嵌套回复）。\n\n【页面文本】\n${text.slice(0, MAX_PAGE_CHARS)}`;

    const extracted = await extractViaLlm(
      deps,
      llmDeps,
      extractionSystem,
      extractionPrompt,
      COMMENTS_SCHEMA,
    );
    const rawComments: Array<{ author?: string; content?: string; replies?: unknown[] }> =
      (extracted?.comments as Array<{ author?: string; content?: string; replies?: unknown[] }>) ?? [];

    /** 回复条目 → 可读字符串（LLM 可能返回对象，提取 content/text 字段；空内容回退作者名）。 */
    const replyText = (r: unknown): string => {
      if (typeof r === "string") return r;
      if (r && typeof r === "object") {
        const obj = r as Record<string, unknown>;
        const v = obj.content || obj.text || obj.message || obj.author;
        return typeof v === "string" && v ? v : JSON.stringify(obj);
      }
      return String(r ?? "");
    };

    const normalized = rawComments.map((c) => ({
      author: c.author ?? "",
      content: c.content ?? "",
      replies: Array.isArray(c.replies) ? c.replies.map(replyText).filter(Boolean) : [],
    }));
    const { kept, dropped } = denoiseComments(normalized);

    // 空结果明确状态（避免静默空返回误导）：页面加载成功但无评论/回答
    if (kept.length === 0 && text.trim().length > 20) {
      return {
        url,
        title: typeof extracted?.title === "string" ? extracted.title : "",
        comments: [],
        sentiment: { positive: 0, negative: 0, neutral: 0 },
        dropped,
        empty: true,
        hint: isZhihuQuestion
          ? "未提取到回答（知乎问题页结构可能不支持或回答区未加载）；可改用 collect_*_search 发现可采 URL，或 save_corpus 补录正文"
          : "未提取到评论（页面可能无评论区或结构不支持）；可改用 collect_*_search 发现可采 URL，或 save_corpus 补录内容",
      };
    }

    const buckets = aggregateSentiment(kept);

    // 自动落盘：每条降噪后评论 → corpus（kind=comment；去重幂等）
    if (options.topic) {
      try {
        const root = resolveCorpusRoot(deps.ctx, deps.corpusDir ?? "", options.exec);
        if (root) {
          appendEntries(
            root,
            options.topic,
            kept.map((c) =>
              makeEntry({
                topic: options.topic!,
                kind: "comment",
                url,
                title: typeof extracted?.title === "string" ? extracted.title : "",
                source: safeHost(url),
                strategy: "browser",
                text: c.content,
              }),
            ),
          );
        }
      } catch {
        // 落盘失败不阻断评论采集
      }
    }

    return {
      url,
      title: typeof extracted?.title === "string" ? extracted.title : "",
      comments: kept,
      sentiment: {
        positive: buckets.positive,
        negative: buckets.negative,
        neutral: buckets.neutral,
      },
      dropped,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const hint = /ENOENT|not found/i.test(message)
      ? "bsk CLI 不可用，评论挖掘降级：请先安装 BrowserSkill"
      : message;
    return {
      url,
      title: "",
      comments: [],
      sentiment: { positive: 0, negative: 0, neutral: 0 },
      dropped: 0,
      error: hint.slice(0, 300),
    };
  } finally {
    handle?.release();
  }
}

// ---------------------------------------------------------------------------
// 评论区挖掘：入口分流（知乎 / B 站 API 通道优先，其余与降级走浏览器兜底）
// ---------------------------------------------------------------------------

/** 评论采集通道路由（纯函数，可单测）。 */
export type CommentRoute =
  | "zhihu"
  | "bilibili"
  | "xiaohongshu"
  | "weibo"
  | "douyin"
  | "kuaishou"
  | "nowcoder"
  | "tieba"
  | "browser";

export function routeForCommentUrl(url: string): CommentRoute {
  if (extractZhihuQid(url)) return "zhihu";
  if (extractBvid(url)) return "bilibili";
  if (extractXhsNoteId(url)) return "xiaohongshu";
  if (extractWeiboMid(url)) return "weibo";
  if (extractAwemeId(url) || isDouyinShortUrl(url)) return "douyin";
  if (extractPhotoId(url)) return "kuaishou";
  if (extractNowcoderPostId(url)) return "nowcoder";
  if (extractTiebaTid(url)) return "tieba";
  return "browser";
}

/** API 通道落盘（kind=comment，strategy 标记通道；去重幂等）。 */
function saveCommentEntries(
  deps: CollectDeps,
  exec: ToolRunContext,
  topic: string | undefined,
  url: string,
  title: string,
  entries: CommentEntry[],
  strategy: "zhihu-api" | "bilibili-api" | "xiaohongshu-api" | "weibo-api" | "douyin-api" | "kuaishou-api" | "nowcoder-api" | "tieba-api",
): void {
  if (!topic || entries.length === 0) return;
  try {
    const root = resolveCorpusRoot(deps.ctx, deps.corpusDir ?? "", exec);
    if (!root) return;
    appendEntries(
      root,
      topic,
      entries.map((c) =>
        makeEntry({
          topic,
          kind: "comment",
          url,
          title,
          source: safeHost(url),
          strategy,
          text: c.content,
        }),
      ),
    );
  } catch {
    // 落盘失败不阻断
  }
}

/** 知乎问题页 → API 通道；返回 null 表示需降级浏览器路径。 */
async function collectZhihuViaApi(
  deps: CollectDeps,
  pool: BrowserSessionPool,
  options: CollectCommentsOptions,
  qid: string,
): Promise<CommentMineResult | null> {
  try {
    const outcome = await collectZhihuAnswers(
      { pool, pacer: deps.pacer },
      options.exec,
      qid,
      {
        maxAnswers: deps.zhihuMaxAnswers ?? 50,
        maxAnswerComments: deps.zhihuMaxAnswerComments ?? 10,
      },
    );
    if (!outcome.ok) {
      if (outcome.reason === "unavailable") return null; // bsk 不可用 → 浏览器路径
      if (outcome.reason === "login_wall") {
        // 登录墙：先交给浏览器 DOM 兜底（公开问题页仍可能从 DOM 提取回答）
        return null;
      }
      return null; // 其他错误 → 浏览器路径兜底
    }
    const { kept, dropped } = denoiseComments(outcome.answers);
    if (kept.length === 0) {
      // API 返回空/结构异常：交给浏览器 DOM 兜底再试一次，避免直接放弃
      return null;
    }
    const buckets = aggregateSentiment(kept);
    saveCommentEntries(deps, options.exec, options.topic, options.url, outcome.title, kept, "zhihu-api");
    return {
      url: options.url,
      title: outcome.title,
      comments: kept,
      sentiment: {
        positive: buckets.positive,
        negative: buckets.negative,
        neutral: buckets.neutral,
      },
      dropped,
      strategy: "zhihu-api",
    };
  } catch {
    return null; // 意外错误 → 浏览器路径兜底
  }
}

/** 解析浏览器同源 fetch 的 evaluate 返回（{ok, code, aid, isEnd, next, items, title, error}）。 */
export function parseBiliEval(value: unknown): {
  ok: boolean;
  code?: number;
  aid?: number;
  title?: string;
  isEnd?: boolean;
  next?: number;
  items?: Array<{ rpid: number; uname: string; message: string }>;
  error?: string;
} {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    return {
      ok: v.ok === true,
      code: typeof v.code === "number" ? v.code : undefined,
      aid: typeof v.aid === "number" ? v.aid : undefined,
      title: typeof v.title === "string" ? v.title : undefined,
      isEnd: v.isEnd === true,
      next: typeof v.next === "number" ? v.next : undefined,
      items: Array.isArray(v.items) ? v.items : [],
      error: typeof v.error === "string" ? v.error : undefined,
    };
  }
  return { ok: false, error: "evaluate 返回非对象" };
}

/**
 * B 站浏览器同源兜底：后端 API 直连被 412（出口 IP 风控）时，
 * 在 bsk 会话页面内同源 fetch（复用浏览器登录态 cookie），绕过 IP 级拦截。
 * 返回 null 表示浏览器兜底不可用（无会话 / 页面内也失败）。
 */
async function collectBilibiliViaBrowser(
  deps: CollectDeps,
  pool: BrowserSessionPool,
  options: CollectCommentsOptions,
  bvid: string,
  maxComments: number,
): Promise<CommentMineResult | null> {
  let handle: SessionHandle | null = null;
  try {
    handle = await pool.acquire(options.exec);
    const sessionId = handle.sessionId;
    const run = (args: string[], label: string) => handle!.run(options.exec, args, label);

    // 导航到视频页，确保同源域（www.bilibili.com）
    await run(
      ["navigate", "--session", sessionId, `https://www.bilibili.com/video/${bvid}`],
      "bili navigate",
    );

    // 1) view → aid（同源相对路径）
    const viewPayload = parseBiliEval(
      unwrapEvaluateValue(await run(["evaluate", "--session", sessionId, buildBilibiliViewScript(bvid)], "bili view")),
    );
    if (!viewPayload.ok || !viewPayload.aid) return null;

    // 2) 主评论分页（每页 20，同源相对路径）
    const mainReplies: Array<{ rpid: number; uname: string; message: string }> = [];
    let next = 0;
    for (let page = 0; page < 20 && mainReplies.length < maxComments; page += 1) {
      if (options.exec.signal?.aborted) break;
      const script = buildBilibiliReplyMainScript(viewPayload.aid, 3, page > 0 ? next : undefined);
      const payload = parseBiliEval(
        unwrapEvaluateValue(await run(["evaluate", "--session", sessionId, script], "bili reply")),
      );
      if (!payload.ok) break;
      for (const item of payload.items ?? []) {
        mainReplies.push(item);
        if (mainReplies.length >= maxComments) break;
      }
      if (payload.isEnd || (payload.items ?? []).length === 0 || !payload.next) break;
      next = payload.next;
    }

    if (mainReplies.length === 0) return null; // 浏览器路径也拿不到 → 交给上层

    // 浏览器同源兜底成功 = 后端 412 已绕过，清空平台冷却（下次仍先试后端直连）
    deps.pacer.clearCooldown("bilibili");

    const comments: CommentEntry[] = mainReplies.map((r) => ({
      author: r.uname,
      content: r.message,
      replies: [], // 浏览器兜底不拉楼中楼（控制 evaluate 轮数）
    }));
    const { kept, dropped } = denoiseComments(comments);
    if (kept.length === 0) {
      return {
        url: options.url,
        title: viewPayload.title ?? "",
        comments: [],
        sentiment: { positive: 0, negative: 0, neutral: 0 },
        dropped,
        empty: true,
        strategy: "bilibili-api",
        hint: "未提取到评论（该视频可能无评论或评论不可见）",
      };
    }
    const buckets = aggregateSentiment(kept);
    saveCommentEntries(deps, options.exec, options.topic, options.url, viewPayload.title ?? "", kept, "bilibili-api");
    return {
      url: options.url,
      title: viewPayload.title ?? "",
      comments: kept,
      sentiment: { positive: buckets.positive, negative: buckets.negative, neutral: buckets.neutral },
      dropped,
      strategy: "bilibili-api",
    };
  } catch {
    return null; // 浏览器兜底不可用
  } finally {
    handle?.release();
  }
}

/** B 站视频页 → API 通道（后端直连；412 时浏览器同源兜底）；返回 null 表示需降级浏览器路径。 */
async function collectBilibiliViaApi(
  deps: CollectDeps,
  pool: BrowserSessionPool,
  options: CollectCommentsOptions,
  bvid: string,
): Promise<CommentMineResult | null> {
  const emptySentiment = { positive: 0, negative: 0, neutral: 0 };
  try {
    const outcome = await collectBilibiliComments(
      {
        pacer: deps.pacer,
        signal: options.exec.signal,
        ...(deps.bilibiliCookie ? { cookie: deps.bilibiliCookie } : {}),
      },
      bvid,
      {
        maxComments: deps.bilibiliMaxComments ?? 100,
        maxReplyComments: deps.bilibiliMaxReplyComments ?? 20,
      },
    );
    if (!outcome.ok) {
      if (outcome.reason === "rate_limited") {
        // 出口 IP 被风控 → 浏览器同源兜底（复用登录态 cookie）
        const browser = await collectBilibiliViaBrowser(deps, pool, options, bvid, deps.bilibiliMaxComments ?? 100);
        if (browser) {
          browser.backend = "bilibili-browser-fetch";
          browser.fallbacks = ["bilibili-api-direct"];
          browser.degraded = true;
          return browser;
        }
        return {
          url: options.url,
          title: outcome.title,
          comments: [],
          sentiment: emptySentiment,
          dropped: 0,
          error: `${outcome.error}（已尝试浏览器同源兜底，仍不可用；可在配置 bilibiliCookie 后重试）`,
          strategy: "bilibili-api",
          backend: "bilibili-api-direct",
          fallbacks: ["bilibili-browser-fetch"],
          degraded: true,
        };
      }
      if (outcome.reason === "login_wall") {
        return {
          url: options.url,
          title: outcome.title,
          comments: [],
          sentiment: emptySentiment,
          dropped: 0,
          error: outcome.error,
          strategy: "bilibili-api",
          backend: "bilibili-api-direct",
        };
      }
      if (outcome.reason === "empty") {
        return {
          url: options.url,
          title: outcome.title,
          comments: [],
          sentiment: emptySentiment,
          dropped: 0,
          empty: true,
          hint: outcome.error,
          strategy: "bilibili-api",
          backend: "bilibili-api-direct",
        };
      }
      return null; // error → 浏览器路径兜底
    }
    const { kept, dropped } = denoiseComments(outcome.comments);
    if (kept.length === 0) {
      return {
        url: options.url,
        title: outcome.title,
        comments: [],
        sentiment: emptySentiment,
        dropped,
        empty: true,
        strategy: "bilibili-api",
        backend: "bilibili-api-direct",
        hint: "未提取到评论（该视频可能无评论或评论不可见）",
      };
    }
    const buckets = aggregateSentiment(kept);
    saveCommentEntries(deps, options.exec, options.topic, options.url, outcome.title, kept, "bilibili-api");
    return {
      url: options.url,
      title: outcome.title,
      comments: kept,
      sentiment: {
        positive: buckets.positive,
        negative: buckets.negative,
        neutral: buckets.neutral,
      },
      dropped,
      strategy: "bilibili-api",
      backend: "bilibili-api-direct",
      fallbacks: [],
      degraded: false,
    };
  } catch {
    return null; // 意外错误 → 浏览器路径兜底
  }
}

/** 小红书笔记页 → 评论通道（需登录态；未登录/风控返回明确状态）。 */
async function collectXhsViaApi(
  deps: CollectDeps,
  pool: BrowserSessionPool,
  options: CollectCommentsOptions,
  noteId: string,
): Promise<CommentMineResult | null> {
  const emptySentiment = { positive: 0, negative: 0, neutral: 0 };
  try {
    const outcome = await collectXiaohongshuNoteComments(
      { pool, pacer: deps.pacer },
      options.exec,
      noteId,
      {
        maxComments: deps.bilibiliMaxComments ?? 100,
        ...(extractXhsToken(options.url) ? { xsecToken: extractXhsToken(options.url) } : {}),
      },
    );
    if (!outcome.ok) {
      if (outcome.reason === "login_wall") {
        return {
          url: options.url,
          title: outcome.title,
          comments: [],
          sentiment: emptySentiment,
          dropped: 0,
          error: `${outcome.error}；可调用 browser_request_help 请用户在 Agent Window 完成小红书登录后重试`,
          strategy: "xiaohongshu-api",
          backend: "xhs-state-mine",
        };
      }
      if (outcome.reason === "rate_limited") {
        return {
          url: options.url,
          title: outcome.title,
          comments: [],
          sentiment: emptySentiment,
          dropped: 0,
          error: `${outcome.error}；小红书冷却窗口显著长于其他平台，建议冷却完全结束后降频多轮（每轮仅 1 次访问）`,
          strategy: "xiaohongshu-api",
          backend: "xhs-state-mine",
        };
      }
      // 平台限制（App 扫码墙）：降级浏览器路径同样被墙，直接返回准确提示
      if (outcome.error && /App 扫码墙|无法在网页获取/.test(outcome.error)) {
        return {
          url: options.url,
          title: outcome.title,
          comments: [],
          sentiment: emptySentiment,
          dropped: 0,
          error: `${outcome.error}；请先 collect_xhs_search 获取带 xsec_token 的卡片（登录态下 token 命中率更高）`,
          strategy: "xiaohongshu-api",
          backend: "xhs-state-mine",
        };
      }
      return null; // error → 浏览器路径兜底
    }
    const { kept, dropped } = denoiseComments(outcome.comments);
    if (kept.length === 0) {
      return {
        url: options.url,
        title: outcome.title,
        comments: [],
        sentiment: emptySentiment,
        dropped,
        empty: true,
        strategy: "xiaohongshu-api",
        backend: "xhs-state-mine",
        hint: outcome.error ?? "未提取到评论（小红书评论可能需登录或滚动加载）",
      };
    }
    const buckets = aggregateSentiment(kept);
    saveCommentEntries(deps, options.exec, options.topic, options.url, outcome.title, kept, "xiaohongshu-api");
    return {
      url: options.url,
      title: outcome.title,
      comments: kept,
      sentiment: {
        positive: buckets.positive,
        negative: buckets.negative,
        neutral: buckets.neutral,
      },
      dropped,
      strategy: "xiaohongshu-api",
      backend: "xhs-state-mine",
      fallbacks: [],
      degraded: false,
    };
  } catch {
    return null; // 意外错误 → 浏览器路径兜底
  }
}

/** 微博详情页 → 评论通道（浏览器路径：页面内 fetch hotflow）。 */
async function collectWeiboViaApi(
  deps: CollectDeps,
  pool: BrowserSessionPool,
  options: CollectCommentsOptions,
  mid: string,
): Promise<CommentMineResult | null> {
  const emptySentiment = { positive: 0, negative: 0, neutral: 0 };
  try {
    const outcome = await collectWeiboComments(
      { pool, pacer: deps.pacer },
      options.exec,
      mid,
      { maxComments: deps.bilibiliMaxComments ?? 100 },
    );
    if (!outcome.ok) {
      if (outcome.reason === "rate_limited" || outcome.reason === "login_wall") {
        return {
          url: options.url,
          title: outcome.title,
          comments: [],
          sentiment: emptySentiment,
          dropped: 0,
          error: outcome.error,
          strategy: "weibo-api",
        };
      }
      return null; // error → 浏览器路径兜底
    }
    const { kept, dropped } = denoiseComments(outcome.comments);
    if (kept.length === 0) {
      return {
        url: options.url,
        title: outcome.title,
        comments: [],
        sentiment: emptySentiment,
        dropped,
        empty: true,
        strategy: "weibo-api",
        hint: outcome.error ?? "未提取到评论（该微博可能无评论）",
      };
    }
    const buckets = aggregateSentiment(kept);
    saveCommentEntries(deps, options.exec, options.topic, options.url, outcome.title, kept, "weibo-api");
    return {
      url: options.url,
      title: outcome.title,
      comments: kept,
      sentiment: {
        positive: buckets.positive,
        negative: buckets.negative,
        neutral: buckets.neutral,
      },
      dropped,
      strategy: "weibo-api",
    };
  } catch {
    return null; // 意外错误 → 浏览器路径兜底
  }
}

/** 抖音视频页 → 评论通道（浏览器路径：页面内 fetch 免签名；支持 v.douyin.com 短链）。 */
async function collectDouyinViaApi(
  deps: CollectDeps,
  pool: BrowserSessionPool,
  options: CollectCommentsOptions,
): Promise<CommentMineResult | null> {
  const emptySentiment = { positive: 0, negative: 0, neutral: 0 };
  try {
    const outcome = await collectDouyinComments(
      { pool, pacer: deps.pacer },
      options.exec,
      options.url,
      { maxComments: deps.bilibiliMaxComments ?? 100 },
    );
    if (!outcome.ok) {
      if (outcome.reason === "rate_limited" || outcome.reason === "login_wall") {
        return {
          url: options.url,
          title: outcome.title,
          author: outcome.author,
          comments: [],
          sentiment: emptySentiment,
          dropped: 0,
          error: outcome.error,
          strategy: "douyin-api",
        };
      }
      return null; // error → 浏览器路径兜底
    }
    const { kept, dropped } = denoiseComments(outcome.comments);
    if (kept.length === 0) {
      return {
        url: options.url,
        title: outcome.title,
        author: outcome.author,
        comments: [],
        sentiment: emptySentiment,
        dropped,
        empty: true,
        strategy: "douyin-api",
        hint: outcome.error ?? "未提取到评论（该视频可能无评论）",
      };
    }
    const buckets = aggregateSentiment(kept);
    saveCommentEntries(deps, options.exec, options.topic, options.url, outcome.title, kept, "douyin-api");
    return {
      url: options.url,
      title: outcome.title,
      author: outcome.author,
      comments: kept,
      sentiment: {
        positive: buckets.positive,
        negative: buckets.negative,
        neutral: buckets.neutral,
      },
      dropped,
      strategy: "douyin-api",
    };
  } catch {
    return null; // 意外错误 → 浏览器路径兜底
  }
}

/** 快手视频页 → 评论通道（浏览器路径：页面内 fetch 免签名，支持 /f/ 分享链接）。 */
async function collectKuaishouViaApi(
  deps: CollectDeps,
  pool: BrowserSessionPool,
  options: CollectCommentsOptions,
): Promise<CommentMineResult | null> {
  const emptySentiment = { positive: 0, negative: 0, neutral: 0 };
  try {
    const outcome = await collectKuaishouComments(
      { pool, pacer: deps.pacer },
      options.exec,
      options.url,
      { maxComments: deps.bilibiliMaxComments ?? 100 },
    );
    if (!outcome.ok) {
      if (outcome.reason === "rate_limited" || outcome.reason === "login_wall") {
        return {
          url: options.url,
          title: outcome.title,
          comments: [],
          sentiment: emptySentiment,
          dropped: 0,
          error: outcome.error,
          strategy: "kuaishou-api",
        };
      }
      return null; // error → 浏览器路径兜底
    }
    const { kept, dropped } = denoiseComments(outcome.comments);
    if (kept.length === 0) {
      return {
        url: options.url,
        title: outcome.title,
        comments: [],
        sentiment: emptySentiment,
        dropped,
        empty: true,
        strategy: "kuaishou-api",
        hint: outcome.error ?? "未提取到评论（该视频可能无评论）",
      };
    }
    const buckets = aggregateSentiment(kept);
    saveCommentEntries(deps, options.exec, options.topic, options.url, outcome.title, kept, "kuaishou-api");
    return {
      url: options.url,
      title: outcome.title,
      comments: kept,
      sentiment: {
        positive: buckets.positive,
        negative: buckets.negative,
        neutral: buckets.neutral,
      },
      dropped,
      strategy: "kuaishou-api",
    };
  } catch {
    return null; // 意外错误 → 浏览器路径兜底
  }
}

/** 牛客讨论帖 → 评论通道（浏览器路径：DOM 提取 SSR 首屏评论）。 */
async function collectNowcoderViaApi(
  deps: CollectDeps,
  pool: BrowserSessionPool,
  options: CollectCommentsOptions,
): Promise<CommentMineResult | null> {
  const emptySentiment = { positive: 0, negative: 0, neutral: 0 };
  try {
    const outcome = await collectNowcoderComments(
      { pool, pacer: deps.pacer },
      options.exec,
      options.url,
      { maxComments: deps.bilibiliMaxComments ?? 100 },
    );
    if (!outcome.ok) {
      if (outcome.reason === "rate_limited" || outcome.reason === "login_wall") {
        return {
          url: options.url,
          title: outcome.title,
          comments: [],
          sentiment: emptySentiment,
          dropped: 0,
          error: outcome.error,
          strategy: "nowcoder-api",
        };
      }
      return null; // error → 浏览器路径兜底
    }
    const { kept, dropped } = denoiseComments(outcome.comments);
    if (kept.length === 0) {
      return {
        url: options.url,
        title: outcome.title,
        comments: [],
        sentiment: emptySentiment,
        dropped,
        empty: true,
        strategy: "nowcoder-api",
        hint: outcome.error ?? "未提取到评论（讨论帖可能无评论）",
      };
    }
    const buckets = aggregateSentiment(kept);
    saveCommentEntries(deps, options.exec, options.topic, options.url, outcome.title, kept, "nowcoder-api");
    return {
      url: options.url,
      title: outcome.title,
      comments: kept,
      sentiment: {
        positive: buckets.positive,
        negative: buckets.negative,
        neutral: buckets.neutral,
      },
      dropped,
      strategy: "nowcoder-api",
    };
  } catch {
    return null; // 意外错误 → 浏览器路径兜底
  }
}

/** 贴吧帖子 → 回复通道（浏览器路径：DOM 提取）。 */
async function collectTiebaViaApi(
  deps: CollectDeps,
  pool: BrowserSessionPool,
  options: CollectCommentsOptions,
): Promise<CommentMineResult | null> {
  const emptySentiment = { positive: 0, negative: 0, neutral: 0 };
  try {
    const outcome = await collectTiebaComments(
      { pool, pacer: deps.pacer },
      options.exec,
      options.url,
      { maxComments: deps.bilibiliMaxComments ?? 100 },
    );
    if (!outcome.ok) {
      if (outcome.reason === "rate_limited" || outcome.reason === "login_wall") {
        return {
          url: options.url,
          title: outcome.title,
          comments: [],
          sentiment: emptySentiment,
          dropped: 0,
          error: outcome.error,
          strategy: "tieba-api",
        };
      }
      return null; // error → 浏览器路径兜底
    }
    const { kept, dropped } = denoiseComments(outcome.comments);
    if (kept.length === 0) {
      return {
        url: options.url,
        title: outcome.title,
        comments: [],
        sentiment: emptySentiment,
        dropped,
        empty: true,
        strategy: "tieba-api",
        hint: outcome.error ?? "未提取到回复（帖子可能无回复）",
      };
    }
    const buckets = aggregateSentiment(kept);
    saveCommentEntries(deps, options.exec, options.topic, options.url, outcome.title, kept, "tieba-api");
    return {
      url: options.url,
      title: outcome.title,
      comments: kept,
      sentiment: {
        positive: buckets.positive,
        negative: buckets.negative,
        neutral: buckets.neutral,
      },
      dropped,
      strategy: "tieba-api",
    };
  } catch {
    return null; // 意外错误 → 浏览器路径兜底
  }
}

/**
 * 评论区挖掘入口：知乎 / B 站 / 小红书 / 微博 / 抖音 / 快手 / 牛客 / 贴吧 优先走 API 通道（稳定、结构化），
 * 其余与降级路径走浏览器兜底；平台冷却中直接跳过（避免加深风控）。
 * 通道链通过 channels.ts 显式声明，成功/降级/失败全部写入 CrawlerHealth（crawler_status 可查）。
 */
export async function collectComments(
  deps: CollectDeps,
  pool: BrowserSessionPool,
  options: CollectCommentsOptions,
): Promise<CommentMineResult> {
  const { url } = options;
  const platform = platformForUrl(url) as PlatformKey;
  // 同平台串行：评论/搜索/API 直连共用一把锁，避免并发触发平台风控
  return deps.pacer.runExclusive(platform, async () => {
  const emptySentiment = { positive: 0, negative: 0, neutral: 0 };
  const route = routeForCommentUrl(url);

  // 平台冷却中：跳过（不发请求）
  const cooldownMs = deps.pacer.cooldownRemainingMs(platform);
  if (cooldownMs > 0) {
    const result: CommentMineResult = {
      url,
      title: "",
      comments: [],
      sentiment: emptySentiment,
      dropped: 0,
      error: `平台 ${platform} 处于风控冷却期（剩 ${Math.ceil(cooldownMs / 1000)}s），本次跳过；可稍后重试或换其他源`,
    };
    deps.health.record({
      platform,
      action: "comments",
      backend: "skipped-cooldown",
      outcome: "rate_limited",
      error: result.error,
    });
    return result;
  }

  const chain = backendChainFor(platform, "comments");
  const primaryBackend: BackendSpec = chain[0] ?? {
    id: "generic-browser-dom",
    platform: "generic",
    action: "comments",
    kind: "dom-extract",
    label: "通用浏览器展开评论",
  };
  const fallbackBackend: BackendSpec = chain[1] ?? primaryBackend;

  /** 平台 API 通道（null = 该通道未产生最终结果，交给下一后端）。 */
  const tryPrimary = async (): Promise<ChannelAttemptOutcome<CommentMineResult>> => {
    let handled: CommentMineResult | null = null;
    if (route === "zhihu") {
      const qid = extractZhihuQid(url);
      handled = qid ? await collectZhihuViaApi(deps, pool, options, qid) : null;
    } else if (route === "bilibili") {
      const bvid = extractBvid(url);
      handled = bvid ? await collectBilibiliViaApi(deps, pool, options, bvid) : null;
    } else if (route === "xiaohongshu") {
      const noteId = extractXhsNoteId(url);
      handled = noteId ? await collectXhsViaApi(deps, pool, options, noteId) : null;
    } else if (route === "weibo") {
      const mid = extractWeiboMid(url);
      handled = mid ? await collectWeiboViaApi(deps, pool, options, mid) : null;
    } else if (route === "douyin") {
      handled = await collectDouyinViaApi(deps, pool, options);
    } else if (route === "kuaishou") {
      handled = await collectKuaishouViaApi(deps, pool, options);
    } else if (route === "nowcoder") {
      handled = await collectNowcoderViaApi(deps, pool, options);
    } else if (route === "tieba") {
      handled = await collectTiebaViaApi(deps, pool, options);
    }

    if (!handled) return { done: false, reason: `${primaryBackend.label} 未产生最终结果` };
    handled.backend ??= primaryBackend.id;
    handled.fallbacks ??= [];
    handled.degraded ??= false;
    return { done: true, value: handled };
  };

  /** 浏览器 DOM 兜底（bsk 会话内展开评论）。 */
  const tryBrowserFallback = async (): Promise<ChannelAttemptOutcome<CommentMineResult>> => {
    const value = await collectCommentsBrowser(deps, pool, options);
    value.backend ??= fallbackBackend.id;
    value.fallbacks ??= [];
    if (fallbackBackend.id !== primaryBackend.id) {
      value.fallbacks = [primaryBackend.id, ...value.fallbacks.filter((f) => f !== primaryBackend.id)];
      value.degraded = true;
    }
    return { done: true, value };
  };

  const attempts: ChannelAttempt<CommentMineResult>[] =
    route === "browser"
      ? [{ backend: primaryBackend, attempt: tryBrowserFallback }]
      : [
          { backend: primaryBackend, attempt: tryPrimary },
          ...(fallbackBackend.id !== primaryBackend.id
            ? [{ backend: fallbackBackend, attempt: tryBrowserFallback }]
            : []),
        ];

  try {
    const chainResult = await runChannelChain(attempts, { signal: options.exec.signal, gapMs: 300 });
    const result = chainResult.result;
    result.backend ??= chainResult.backend;
    result.fallbacks ??= chainResult.fallbacks;
    result.degraded ??= chainResult.degraded;

    deps.health.record({
      platform,
      action: "comments",
      backend: result.backend,
      outcome: classifyCommentOutcome(result),
      degraded: result.degraded === true,
      error: result.error,
    });
    return result;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const result: CommentMineResult = {
      url,
      title: "",
      comments: [],
      sentiment: emptySentiment,
      dropped: 0,
      error: message.slice(0, 300),
    };
    deps.health.record({
      platform,
      action: "comments",
      backend: chain.map((c) => c.id).join("→"),
      outcome: "error",
      degraded: true,
      error: message.slice(0, 300),
    });
    return result;
  }
  });
}

/** 评论结果 → 健康 outcome（写 crawler-health 用）。 */
export function classifyCommentOutcome(result: CommentMineResult): HealthOutcome {
  const error = result.error ?? "";
  if (/登录|login|扫码/.test(error)) return "login_wall";
  if (/验证码|captcha/.test(error)) return "captcha";
  if (/冷却|限流|rate.?limit|风控|挂起|412|429/.test(error)) return "rate_limited";
  if (error) return "error";
  if (result.comments.length === 0) return "empty";
  return "success";
}
