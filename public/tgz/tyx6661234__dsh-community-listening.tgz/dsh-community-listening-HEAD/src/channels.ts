/**
 * 平台采集通道注册表 + 通道链执行器（Agent-Reach 风格的多后端 fallback）。
 *
 * 每个平台/动作显式声明后端优先级（主通道 → 浏览器同源 fetch → DOM/state 挖掘），
 * 失败自动降级并在 CrawlerHealth 中记录 degraded 状态。
 */

export type PlatformKey =
  | "zhihu"
  | "bilibili"
  | "xiaohongshu"
  | "weibo"
  | "douyin"
  | "kuaishou"
  | "nowcoder"
  | "tieba"
  | "generic";

export type ChannelAction = "comments" | "search";
export type BackendKind = "api-direct" | "browser-fetch" | "dom-extract" | "state-mine";

export interface BackendSpec {
  id: string;
  platform: PlatformKey;
  action: ChannelAction;
  kind: BackendKind;
  label: string;
}

export const CHANNELS: readonly BackendSpec[] = [
  // B 站
  { id: "bilibili-api-direct", platform: "bilibili", action: "comments", kind: "api-direct", label: "B站 API 直连（WBI）" },
  { id: "bilibili-browser-fetch", platform: "bilibili", action: "comments", kind: "browser-fetch", label: "B站 浏览器同源 fetch 兜底" },
  { id: "bilibili-search-dom", platform: "bilibili", action: "search", kind: "dom-extract", label: "B站 搜索页 SSR 链接提取" },
  // 知乎
  { id: "zhihu-browser-fetch", platform: "zhihu", action: "comments", kind: "browser-fetch", label: "知乎 同源 fetch API" },
  { id: "zhihu-browser-dom", platform: "zhihu", action: "comments", kind: "dom-extract", label: "知乎 页面 DOM 提取" },
  // 小红书
  { id: "xhs-state-mine", platform: "xiaohongshu", action: "comments", kind: "state-mine", label: "小红书 __INITIAL_STATE__ 挖掘" },
  { id: "xhs-browser-dom", platform: "xiaohongshu", action: "comments", kind: "dom-extract", label: "小红书 页面 DOM 提取" },
  { id: "xhs-search-token-mine", platform: "xiaohongshu", action: "comments", kind: "state-mine", label: "小红书 搜索页 token 挖掘" },
  { id: "xhs-search-dom", platform: "xiaohongshu", action: "search", kind: "dom-extract", label: "小红书 搜索卡片 DOM 提取" },
  // 微博
  { id: "weibo-browser-fetch", platform: "weibo", action: "comments", kind: "browser-fetch", label: "微博 页面内 fetch hotflow" },
  { id: "weibo-browser-dom", platform: "weibo", action: "comments", kind: "dom-extract", label: "微博 页面 DOM 提取" },
  { id: "weibo-search-browser-fetch", platform: "weibo", action: "search", kind: "browser-fetch", label: "微博 搜索 API 页面内 fetch" },
  // 抖音
  { id: "douyin-browser-fetch", platform: "douyin", action: "comments", kind: "browser-fetch", label: "抖音 页面内 fetch 评论 API" },
  { id: "douyin-browser-dom", platform: "douyin", action: "comments", kind: "dom-extract", label: "抖音 页面 DOM 提取" },
  { id: "douyin-search-api", platform: "douyin", action: "search", kind: "browser-fetch", label: "抖音 搜索 API 页面内 fetch" },
  { id: "douyin-search-dom", platform: "douyin", action: "search", kind: "dom-extract", label: "抖音 搜索卡片 DOM 提取" },
  { id: "douyin-user-api", platform: "douyin", action: "search", kind: "browser-fetch", label: "抖音 用户作品 API 页面内 fetch" },
  // 快手
  { id: "kuaishou-browser-fetch", platform: "kuaishou", action: "comments", kind: "browser-fetch", label: "快手 页面内 fetch 评论 API" },
  { id: "kuaishou-browser-dom", platform: "kuaishou", action: "comments", kind: "dom-extract", label: "快手 页面 DOM 提取" },
  { id: "kuaishou-search-state", platform: "kuaishou", action: "search", kind: "state-mine", label: "快手 search.feed state 挖掘" },
  { id: "kuaishou-search-dom", platform: "kuaishou", action: "search", kind: "dom-extract", label: "快手 搜索卡片 DOM 提取" },
  // 牛客 / 贴吧
  { id: "nowcoder-browser-dom", platform: "nowcoder", action: "comments", kind: "dom-extract", label: "牛客 SSR DOM 提取" },
  { id: "tieba-browser-dom", platform: "tieba", action: "comments", kind: "dom-extract", label: "贴吧 DOM 提取" },
  // 通用浏览器兜底
  { id: "generic-browser-dom", platform: "generic", action: "comments", kind: "dom-extract", label: "通用浏览器展开评论" },
];

const byPlatformAction = new Map<string, BackendSpec[]>();
for (const spec of CHANNELS) {
  const key = `${spec.platform}\u0000${spec.action}`;
  const list = byPlatformAction.get(key) ?? [];
  list.push(spec);
  byPlatformAction.set(key, list);
}

/** 某平台/动作的通道优先级（声明式）。 */
export function backendChainFor(platform: PlatformKey, action: ChannelAction): BackendSpec[] {
  const exact = byPlatformAction.get(`${platform}\u0000${action}`) ?? [];
  if (exact.length > 0) return [...exact];
  if (action === "comments") {
    return byPlatformAction.get(`generic\u0000comments`) ?? [];
  }
  return [];
}

export function backendSpec(id: string): BackendSpec | null {
  return CHANNELS.find((c) => c.id === id) ?? null;
}

// ---------------------------------------------------------------------------
// 通道链执行
// ---------------------------------------------------------------------------

/** 单通道尝试结果：done=true 视为该平台调用已得到最终语义（含 login_wall/rate_limited/empty）。 */
export type ChannelAttemptOutcome<T> =
  | { done: true; value: T }
  | { done: false; reason?: string };

export interface ChannelAttempt<T> {
  backend: BackendSpec;
  attempt: () => Promise<ChannelAttemptOutcome<T>>;
}

export interface ChannelChainResult<T> {
  result: T;
  backend: string;
  fallbacks: string[];
  degraded: boolean;
}

export interface ChannelRunOptions {
  signal?: AbortSignal;
  /** 失败通道之间的小间隔（默认 300ms，避免立刻重试同一页面）。 */
  gapMs?: number;
}

/**
 * 依次执行通道链；首个 done=true 的结果生效。
 * 全链失败时抛错（带已尝试的通道清单），由上层保持原有失败语义。
 */
export async function runChannelChain<T>(
  attempts: ChannelAttempt<T>[],
  options: ChannelRunOptions = {},
): Promise<ChannelChainResult<T>> {
  const tried: string[] = [];
  let lastReason = "";
  for (const item of attempts) {
    if (options.signal?.aborted) {
      throw new Error(`通道链被取消（已尝试：${tried.join(" → ") || "无"}）`);
    }
    tried.push(item.backend.id);
    let outcome: ChannelAttemptOutcome<T>;
    try {
      outcome = await item.attempt();
    } catch (error) {
      lastReason = error instanceof Error ? error.message : String(error);
      continue;
    }
    if (outcome.done) {
      return {
        result: outcome.value,
        backend: item.backend.id,
        fallbacks: tried.slice(0, -1),
        degraded: tried.length > 1,
      };
    }
    lastReason = outcome.reason ?? "通道未提供结果";
    if (options.gapMs !== undefined && options.gapMs > 0) {
      await new Promise((resolve) => setTimeout(resolve, options.gapMs));
    }
  }
  throw new Error(`所有通道均失败（${tried.join(" → ") || "无可用通道"}）：${lastReason}`);
}
