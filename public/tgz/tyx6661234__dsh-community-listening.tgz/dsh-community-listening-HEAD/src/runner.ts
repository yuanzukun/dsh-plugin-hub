/**
 * bsk CLI 进程 runner（改编自 dsh-plugin-browserskill/src/runner.ts）。
 * 每个浏览器操作 = 一次 `bsk <cmd> --json` 调用；支持取消信号、超时熔断、
 * 插件卸载时 kill 全部在途子进程。
 */

import { type ChildProcess, spawn } from "node:child_process";

export interface BskErrorBody {
  code?: string;
  message?: string;
  hint?: string;
  exit_code?: number;
  data?: unknown;
}

export class BskError extends Error {
  readonly code?: string;
  readonly hint?: string;
  readonly exitCode?: number | null;
  readonly timedOut: boolean;

  constructor(
    message: string,
    options: { code?: string; hint?: string; exitCode?: number | null; timedOut?: boolean } = {},
  ) {
    super(message);
    this.name = "BskError";
    this.code = options.code;
    this.hint = options.hint;
    this.exitCode = options.exitCode;
    this.timedOut = options.timedOut ?? false;
  }
}

export interface BskRunResult {
  code: number | null;
  stdout: string;
  stderr: string;
  timedOut: boolean;
  aborted: boolean;
}

export interface BskRunOptions {
  signal?: AbortSignal;
  timeoutMs?: number;
}

export type SpawnImpl = (command: string, args: string[]) => ChildProcess;

export interface BskRunner {
  run(args: string[], options?: BskRunOptions): Promise<BskRunResult>;
  killAll(): void;
}

const KILL_GRACE_MS = 2000;

export function createBskRunner(bskPath: string, spawnImpl: SpawnImpl = spawn): BskRunner {
  const live = new Set<ChildProcess>();

  function killChild(child: ChildProcess): void {
    if (!child.pid || child.exitCode !== null || child.signalCode !== null) return;
    try {
      child.kill("SIGTERM");
    } catch {
      return;
    }
    const force = setTimeout(() => {
      if (child.pid && child.exitCode === null && child.signalCode === null) {
        try {
          child.kill("SIGKILL");
        } catch {
          // The process may have exited between the state check and kill.
        }
      }
    }, KILL_GRACE_MS);
    force.unref();
  }

  return {
    run(args, options = {}) {
      return new Promise<BskRunResult>((resolve, reject) => {
        let child: ChildProcess;
        try {
          child = spawnImpl(bskPath, [...args, "--json"]);
        } catch (error) {
          reject(error);
          return;
        }
        live.add(child);

        let stdout = "";
        let stderr = "";
        let timedOut = false;
        let aborted = false;
        child.stdout?.on("data", (chunk: Buffer | string) => {
          stdout += chunk;
        });
        child.stderr?.on("data", (chunk: Buffer | string) => {
          stderr += chunk;
        });

        const timeoutMs = options.timeoutMs;
        const timer =
          timeoutMs !== undefined && timeoutMs > 0
            ? setTimeout(() => {
                timedOut = true;
                killChild(child);
              }, timeoutMs)
            : undefined;
        timer?.unref();

        const onAbort = () => {
          aborted = true;
          killChild(child);
        };
        if (options.signal?.aborted) {
          onAbort();
        } else {
          options.signal?.addEventListener("abort", onAbort, { once: true });
        }

        const settle = () => {
          if (timer !== undefined) clearTimeout(timer);
          options.signal?.removeEventListener("abort", onAbort);
          live.delete(child);
        };

        child.on("error", (error) => {
          settle();
          reject(error);
        });
        child.on("close", (code) => {
          settle();
          resolve({ code, stdout, stderr, timedOut, aborted });
        });
      });
    },
    killAll() {
      for (const child of live) killChild(child);
    },
  };
}

export function isCommandNotFound(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    "code" in error &&
    (error as { code?: unknown }).code === "ENOENT"
  );
}

export function bskInstallMessage(bskPath: string): string {
  return (
    `bsk CLI（"${bskPath}"）未找到。浏览器采集需要 BrowserSkill——` +
    `请安装 https://github.com/Tencent/BrowserSkill 后重试；` +
    `在 bsk 可用前，采集工具将仅使用 fetch 快路径（对反爬站点可能失败）。`
  );
}

export function parseBskJson(result: BskRunResult, commandLabel: string): unknown {
  if (result.timedOut) {
    throw new BskError(`bsk ${commandLabel} timed out`, { timedOut: true });
  }
  const body = result.stdout.trim();
  if (result.code !== 0) {
    let parsed: BskErrorBody | undefined;
    try {
      parsed = JSON.parse(body) as BskErrorBody;
    } catch {
      parsed = undefined;
    }
    const message =
      parsed?.message ?? (result.stderr.trim() || body || `bsk ${commandLabel} failed`);
    const withHint = parsed?.hint !== undefined ? `${message} (hint: ${parsed.hint})` : message;
    throw new BskError(`bsk ${commandLabel} failed: ${withHint}`, {
      code: parsed?.code,
      hint: parsed?.hint,
      exitCode: result.code,
    });
  }
  try {
    return JSON.parse(body);
  } catch {
    throw new BskError(
      `bsk ${commandLabel} did not produce JSON output: ${body.slice(0, 200) || "(empty)"}`,
      { exitCode: result.code },
    );
  }
}
