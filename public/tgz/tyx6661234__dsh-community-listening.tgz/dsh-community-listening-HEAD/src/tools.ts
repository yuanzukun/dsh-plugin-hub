/**
 * 模型可见工具注册（dsh-community-listening）：
 * collect_comments / collect_*_search / crawler_status / save_corpus /
 * corpus_stats / corpus_read / mine_sentiment / dedupe_similar /
 * cluster_topics / export_report
 */

import type { Context } from "@deepseek-ai/cordis";
import { defineTool } from "@deepseek-ai/dsh-tools";
import type { JsonValue, ToolRunContext } from "@deepseek-ai/dsh-tools";
import type { ContentBlock } from "@deepseek-ai/dsh-llm";
import type { CheapLlm } from "./llm";
import { BrowserSessionPool, collectComments } from "./collect";
import { PlatformPacer } from "./pacing";
import { CrawlerHealth } from "./health";
import { collectXiaohongshuSearch } from "./sources/xiaohongshu";
import { collectWeiboSearch } from "./sources/weibo";
import { collectKuaishouSearch } from "./sources/kuaishou";
import { collectBilibiliSearch } from "./sources/bilibili";
import { collectDouyinSearch, collectDouyinUserWorks } from "./sources/douyin";
import {
  appendEntries,
  corpusPath,
  corpusStats as corpusStatsOf,
  invalidateDedupCache,
  loadEntries,
  makeEntry,
  resolveCorpusRoot,
  saveAnalysis,
  saveReport,
} from "./corpus";
import { sanitizeLossless } from "./lossless";
import { mineSentiment, type MinedItem } from "./mining/sentiment";
import { dedupeSimilar, type SimilarCluster } from "./mining/simhash";
import { clusterTopics, type TopicItem } from "./mining/topics";
import { embedTexts, loadEmbeddingConfig } from "./mining/embed";

export interface ToolDeps {
  ctx: Context;
  bskPath: string;
  bskTimeoutMs: number;
  /** 浏览器会话池（多会话并发采集）。 */
  pool: BrowserSessionPool;
  /** 廉价 LLM 通道（脏活优先；不可用时回退主模型路由）。 */
  cheap: CheapLlm;
  /** .env 文件路径（廉价通道 + embedding 配置来源）。 */
  envPath: string;
  /** 语料根目录覆盖（Config corpusDir；留空用会话工作目录）。 */
  corpusDir: string;
  /** 平台节流/冷却（风控指数退避；跨批次/跨会话生效）。 */
  pacer: PlatformPacer;
  /** 通道健康记录（crawler_status 读取 + 采集链路写入）。 */
  health: CrawlerHealth;
  /** 知乎回答采集上限（Config zhihuMaxAnswers）。 */
  zhihuMaxAnswers: number;
  /** 知乎对前 N 条回答取评论区（Config zhihuMaxAnswerComments）。 */
  zhihuMaxAnswerComments: number;
  /** B 站评论采集上限（Config bilibiliMaxComments）。 */
  bilibiliMaxComments: number;
  /** B 站只对前 N 条主评论抓楼中楼（Config bilibiliMaxReplyComments）。 */
  bilibiliMaxReplyComments: number;
  /** 可选 B 站登录 Cookie（Config bilibiliCookie；敏感，仅本机使用）。 */
  bilibiliCookie: string;
  /** embedding 通道覆盖（Config siliconflow*；留空读 envPath/.env）。 */
  embedOverrides: { apiKey?: string; baseUrl?: string; model?: string };
}

/** 通用 render：把结构化结果 JSON 化展示给模型与 UI。 */
function renderText(_args: unknown, value: JsonValue): ContentBlock[] {
  return [{ type: "text", text: JSON.stringify(value, null, 2) }];
}

export function registerTools(deps: ToolDeps): void {
  const { ctx, pool } = deps;

  // ---------- collect_comments ----------
  ctx.tools.register(
    defineTool({
      name: "collect_comments",
      description:
        "挖掘一个网页的评论区：知乎问题页（zhihu.com/question/*）、B 站视频页（bilibili.com/video/*）、微博详情页（m.weibo.cn/detail/*）、抖音视频页（douyin.com/video/*）、快手视频页（kuaishou.com/short-video/* 或 /f/ 分享链接）、牛客讨论帖（nowcoder.com/discuss/*）、百度贴吧帖子（tieba.baidu.com/p/*）走 API 通道（浏览器会话内同源/跨域 fetch 或 DOM 提取，结构化）；小红书笔记页走浏览器评论通道（需登录+token）；其余页面用浏览器展开「加载更多/展开回复」（best-effort），提取评论（含回复），降噪并按情感分桶。提供 topic 时降噪后评论自动落盘（kind=comment），返回 savedTo。登录墙/验证码返回 error/captcha；页面加载成功但无评论返回 empty:true。",
      parameters: {
        url: { type: "string", required: true, description: "评论页 URL。" },
        max_expand: {
          type: "integer",
          description: "最多展开轮数（默认 2，上限 3）。",
        },
        topic: {
          type: "string",
          description: "语料主题：提供后每条降噪后评论自动落盘到 <语料根>/insight-workspace/<topic>/corpus.jsonl（kind=comment）。",
        },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            url: { type: "string", required: true },
            title: { type: "string" },
            dropped: { type: "integer" },
            savedTo: { type: "string" },
            empty: { type: "boolean" },
            hint: { type: "string" },
            strategy: {
              type: "string",
              enum: ["zhihu-api", "bilibili-api", "xiaohongshu-api", "weibo-api", "douyin-api", "kuaishou-api", "nowcoder-api", "tieba-api", "browser"],
              description: "实际采用通道：zhihu-api / bilibili-api / xiaohongshu-api / weibo-api / douyin-api / kuaishou-api / nowcoder-api / tieba-api / browser（浏览器兜底）。",
            },
            backend: {
              type: "string",
              description: "实际后端 id（如 bilibili-browser-fetch），配合 crawler_status 查看健康状态。",
            },
            fallbacks: {
              type: "array",
              items: { type: "string" },
              description: "本次尝试过的降级后端列表（空 = 主通道直接成功）。",
            },
            degraded: {
              type: "boolean",
              description: "是否经过降级（主通道失败后由兜底通道成功）。",
            },
            sentiment: {
              type: "object",
              additionalProperties: false,
              properties: {
                positive: { type: "integer" },
                negative: { type: "integer" },
                neutral: { type: "integer" },
              },
            },
            comments: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: {
                  author: { type: "string" },
                  content: { type: "string" },
                  replies: { type: "array", items: { type: "string" } },
                },
              },
            },
            error: { type: "string" },
          },
        },
        render: renderText,
      },
      async execute(args: { url: string; max_expand?: number; topic?: string }, exec: ToolRunContext) {
        const result = await collectComments(deps, pool, {
          url: args.url,
          maxExpand: Math.min(args.max_expand ?? 2, 3),
          topic: args.topic,
          exec,
        });
        let savedTo = "";
        if (args.topic) {
          try {
            savedTo = corpusPath(rootOf(exec), args.topic);
          } catch {
            savedTo = "";
          }
        }
        return sanitizeLossless({ ...result, savedTo });
      },
    }),
  );

  // ---------- crawler_status ----------
  ctx.tools.register(
    defineTool({
      name: "crawler_status",
      description:
        "查看各平台采集通道健康状态（Agent-Reach doctor 思路）：主通道/兜底通道、最近结果、是否降级、风控冷却剩余时间，以及历史趋势（samples/successRate/degradedRate/recent，识别「越采越被封」）。纯只读，不发任何平台请求。适合在连续采集前决定下一个平台，或在冷却后确认是否恢复。",
      parameters: {
        platform: {
          type: "string",
          description:
            "可选平台过滤：bilibili / zhihu / xiaohongshu / weibo / douyin / kuaishou / nowcoder / tieba。省略返回全部。",
        },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            platforms: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: {
                  platform: { type: "string", required: true },
                  action: { type: "string", required: true, enum: ["comments", "search"] },
                  status: {
                    type: "string",
                    required: true,
                    enum: ["healthy", "degraded", "cooling", "blocked", "unknown"],
                  },
                  preferredBackend: { type: "string", required: true },
                  lastBackend: { type: "string" },
                  lastOutcome: { type: "string" },
                  degraded: { type: "boolean", required: true },
                  cooldownRemainingMs: { type: "integer", required: true },
                  strikes: { type: "integer", required: true },
                  lastAt: { type: "string" },
                  lastError: { type: "string" },
                  hint: { type: "string" },
                  samples: { type: "integer", description: "历史条数（环形缓冲，每键最近 20 条）。" },
                  successRate: { type: "number", description: "(success+empty) 占比（0-1；趋势信号，越低越可能被风控）。" },
                  degradedRate: { type: "number", description: "degraded 占比（0-1；趋势信号，越高越依赖兜底）。" },
                  recent: {
                    type: "array",
                    description: "最近 5 条 {at, backend, outcome}（按时间升序）。",
                    items: {
                      type: "object",
                      additionalProperties: false,
                      properties: {
                        at: { type: "string" },
                        backend: { type: "string" },
                        outcome: { type: "string" },
                      },
                    },
                  },
                },
              },
            },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => true,
      async execute(args: { platform?: string }) {
        const filter = args.platform?.trim() || undefined;
        const platforms = deps.health.status(
          deps.pacer,
          filter as
            | "bilibili"
            | "zhihu"
            | "xiaohongshu"
            | "weibo"
            | "douyin"
            | "kuaishou"
            | "nowcoder"
            | "tieba"
            | undefined,
        );
        return { platforms: sanitizeLossless({ platforms }).platforms };
      },
    }),
  );

  // ---------- collect_xhs_search ----------
  ctx.tools.register(
    defineTool({
      name: "collect_xhs_search",
      description:
        "小红书搜索结果卡片采集（搜索页首屏，单次访问）：navigate 搜索页 → 读已渲染卡片（标题/作者/noteId/点赞·评论·收藏数），并顺带从页面 state 挖取每张卡片的 xsec_token（best-effort，命中后可直接对该笔记 URL 调 collect_comments 采评论）。匿名可用但需低频——小红书对高频/自动化访问风控严格（命中风控自动进入平台冷却，需稍后重试）；单次访问不滚动不点击，符合被动采集纪律。适合社区内容发现（如「XX 值得买吗」「面经」）。",
      parameters: {
        keyword: { type: "string", required: true, description: "搜索关键词（如「机械键盘」「字节面经」）。" },
        topic: {
          type: "string",
          description: "语料主题：提供后每张卡片自动落盘到 <语料根>/insight-workspace/<topic>/corpus.jsonl（kind=article）。",
        },
        limit: { type: "integer", description: "最多返回卡片数（默认 20，首屏）。" },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            keyword: { type: "string", required: true },
            status: {
              type: "string",
              required: true,
              enum: ["ready", "failed", "rate_limited", "login_wall", "empty"],
            },
            savedTo: { type: "string" },
            backend: { type: "string", description: "实际后端 id（crawler_status 可查）。" },
            loginState: {
              type: "object",
              additionalProperties: false,
              properties: {
                loggedIn: { type: "boolean", description: "综合判定：仅 SSR 水合用户（sessionUser）确认时为 true。" },
                sessionUser: { type: "boolean", description: "真实会话信号：__INITIAL_STATE__ 嵌入登录用户（web_session 为 HttpOnly，document.cookie 永远读不到）。" },
                sessionUserId: { type: "string" },
                cookieHasWebSession: { type: "boolean", description: "恒为 false（HttpOnly 不可读），请勿据此判断登录。" },
                hasProfileLink: { type: "boolean", description: "弱信号：/user/profile/ 链接（搜索结果作者卡片匿名也有）。" },
                hasPublishEntry: { type: "boolean", description: "弱信号：导航「发布」入口（匿名页面同样显示）。" },
                loginWallText: { type: "boolean", description: "页面含「登录后查看…」登录墙文案（明确未登录/降权）。" },
                cookieNames: { type: "array", items: { type: "string" }, description: "document.cookie 可见的 xiaohongshu 相关 cookie 名（不含 HttpOnly）。" },
              },
              description: "本次会话登录态检测（登录态直接影响 xsec_token 命中率；UI 弱信号 ≠ 请求上下文已登录）。",
            },
            cardsWithToken: { type: "integer", description: "返回卡片中带 xsec_token 的数量。" },
            tokenHitRate: { type: "number", description: "token 命中率（cardsWithToken / cards.length）。" },
            biasHint: {
              type: "string",
              description: "token 覆盖率低时的采样偏倚提示（区分：已确认登录态低命中=服务端指纹降权；未确认登录=需确认登录落在插件自动化会话）。",
            },
            cards: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: {
                  noteId: { type: "string" },
                  url: { type: "string" },
                  title: { type: "string" },
                  author: { type: "string" },
                  likeCount: { type: "integer" },
                  commentCount: { type: "integer" },
                  collectCount: { type: "integer" },
                  xsecToken: { type: "string", description: "笔记访问凭证（可传给 collect_comments 采评论；可能为空）" },
                },
              },
            },
            error: { type: "string" },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => false, // 小红书低频纪律：同平台不并发
      async execute(args: { keyword: string; topic?: string; limit?: number }, exec: ToolRunContext) {
        if (!args.keyword?.trim()) throw new Error("keyword 不能为空");
        // 平台冷却检查（小红书风控纪律：冷却中直接跳过）
        const cooldownMs = deps.pacer.cooldownRemainingMs("xiaohongshu");
        if (cooldownMs > 0) {
          deps.health.record({
            platform: "xiaohongshu",
            action: "search",
            backend: "xhs-search-dom",
            outcome: "rate_limited",
            error: `冷却中（剩 ${Math.ceil(cooldownMs / 1000)}s）`,
          });
          return {
            keyword: args.keyword,
            status: "rate_limited" as const,
            cards: [],
            backend: "xhs-search-dom",
            cardsWithToken: 0,
            tokenHitRate: 0,
            error: `小红书处于风控冷却期（剩 ${Math.ceil(cooldownMs / 1000)}s），请稍后重试`,
          };
        }
        const outcome = await collectXiaohongshuSearch(
          { pool, pacer: deps.pacer },
          exec,
          args.keyword,
          { limit: args.limit ?? 20 },
        );
        if (!outcome.ok) {
          const status =
            outcome.reason === "rate_limited"
              ? ("rate_limited" as const)
              : outcome.reason === "login_wall"
                ? ("login_wall" as const)
                : ("failed" as const);
          deps.health.record({
            platform: "xiaohongshu",
            action: "search",
            backend: "xhs-search-dom",
            outcome: status === "rate_limited" ? "rate_limited" : status === "login_wall" ? "login_wall" : "error",
            error: outcome.error,
          });
          return {
            keyword: args.keyword,
            status,
            cards: [],
            backend: "xhs-search-dom",
            cardsWithToken: outcome.cardsWithToken,
            tokenHitRate: outcome.tokenHitRate,
            error: outcome.error,
          };
        }
        deps.health.record({
          platform: "xiaohongshu",
          action: "search",
          backend: "xhs-search-dom",
          outcome: outcome.cards.length > 0 ? "success" : "empty",
        });
        // 自动落盘：每张卡片 → corpus（kind=article）
        let savedTo = "";
        if (args.topic && outcome.cards.length > 0) {
          try {
            const root = resolveCorpusRoot(ctx, deps.corpusDir, exec);
            if (root) {
              appendEntries(
                root,
                args.topic,
                outcome.cards.map((c) =>
                  makeEntry({
                    topic: args.topic!,
                    kind: "article",
                    url: c.url,
                    title: c.title,
                    source: "xiaohongshu.com",
                    strategy: "browser",
                    text: `【小红书】${c.title}\n作者：${c.author}\n赞 ${c.likeCount} · 评论 ${c.commentCount} · 收藏 ${c.collectCount}\n${c.url}`,
                  }),
                ),
              );
              savedTo = corpusPath(root, args.topic);
            }
          } catch {
            // 落盘失败不阻断
          }
        }
        if (outcome.cards.length === 0) {
          return {
            keyword: args.keyword,
            status: "empty" as const,
            cards: [],
            backend: "xhs-search-dom",
            cardsWithToken: 0,
            tokenHitRate: 0,
            error: outcome.error,
          };
        }
        return {
          keyword: args.keyword,
          status: "ready" as const,
          savedTo,
          backend: "xhs-search-dom",
          ...(outcome.loginState ? { loginState: outcome.loginState } : {}),
          cardsWithToken: outcome.cardsWithToken,
          tokenHitRate: outcome.tokenHitRate,
          ...(outcome.biasHint ? { biasHint: outcome.biasHint } : {}),
          cards: outcome.cards,
        };
      },
    }),
  );

  // ---------- collect_weibo_search ----------
  ctx.tools.register(
    defineTool({
      name: "collect_weibo_search",
      description:
        "微博帖子搜索（浏览器路径，单次访问）：navigate m.weibo.cn 搜索页 → 页面内 fetch 微博 API（自动带 cookie，匿名可用）→ 帖子列表（作者/正文/点赞·评论·转发数/mid 链接）。对返回的 m.weibo.cn/detail/{mid} 链接可直接调 collect_comments 采评论。命中反爬（432）自动进入平台冷却。",
      parameters: {
        keyword: { type: "string", required: true, description: "搜索关键词（如「大厂裁员」「新能源」）。" },
        topic: {
          type: "string",
          description: "语料主题：提供后每条帖子自动落盘到 <语料根>/insight-workspace/<topic>/corpus.jsonl（kind=article）。",
        },
        limit: { type: "integer", description: "最多返回帖子数（默认 20）。" },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            keyword: { type: "string", required: true },
            status: {
              type: "string",
              required: true,
              enum: ["ready", "failed", "rate_limited", "login_wall", "empty"],
            },
            savedTo: { type: "string" },
            backend: { type: "string", description: "实际后端 id（crawler_status 可查）。" },
            posts: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: {
                  id: { type: "string" },
                  url: { type: "string" },
                  author: { type: "string" },
                  text: { type: "string" },
                  createdAt: { type: "string" },
                  likeCount: { type: "integer" },
                  commentCount: { type: "integer" },
                  repostCount: { type: "integer" },
                },
              },
            },
            error: { type: "string" },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => false, // 微博低频纪律
      async execute(args: { keyword: string; topic?: string; limit?: number }, exec: ToolRunContext) {
        if (!args.keyword?.trim()) throw new Error("keyword 不能为空");
        const cooldownMs = deps.pacer.cooldownRemainingMs("weibo");
        if (cooldownMs > 0) {
          deps.health.record({
            platform: "weibo",
            action: "search",
            backend: "weibo-search-browser-fetch",
            outcome: "rate_limited",
            error: `冷却中（剩 ${Math.ceil(cooldownMs / 1000)}s）`,
          });
          return {
            keyword: args.keyword,
            status: "rate_limited" as const,
            posts: [],
            backend: "weibo-search-browser-fetch",
            error: `微博处于风控冷却期（剩 ${Math.ceil(cooldownMs / 1000)}s），请稍后重试`,
          };
        }
        const outcome = await collectWeiboSearch(
          { pool, pacer: deps.pacer },
          exec,
          args.keyword,
          { limit: args.limit ?? 20 },
        );
        if (!outcome.ok) {
          const status =
            outcome.reason === "rate_limited"
              ? ("rate_limited" as const)
              : outcome.reason === "login_wall"
                ? ("login_wall" as const)
                : ("failed" as const);
          deps.health.record({
            platform: "weibo",
            action: "search",
            backend: "weibo-search-browser-fetch",
            outcome: status === "rate_limited" ? "rate_limited" : status === "login_wall" ? "login_wall" : "error",
            error: outcome.error,
          });
          return { keyword: args.keyword, status, posts: [], backend: "weibo-search-browser-fetch", error: outcome.error };
        }
        deps.health.record({
          platform: "weibo",
          action: "search",
          backend: "weibo-search-browser-fetch",
          outcome: outcome.posts.length > 0 ? "success" : "empty",
        });
        let savedTo = "";
        if (args.topic && outcome.posts.length > 0) {
          try {
            const root = resolveCorpusRoot(ctx, deps.corpusDir, exec);
            if (root) {
              appendEntries(
                root,
                args.topic,
                outcome.posts.map((p) =>
                  makeEntry({
                    topic: args.topic!,
                    kind: "article",
                    url: p.url,
                    title: p.text.slice(0, 80),
                    source: "weibo.com",
                    strategy: "browser",
                    text: `【微博】${p.author}：${p.text}\n赞 ${p.likeCount} · 评论 ${p.commentCount} · 转发 ${p.repostCount}\n${p.url}`,
                  }),
                ),
              );
              savedTo = corpusPath(root, args.topic);
            }
          } catch {
            // 落盘失败不阻断
          }
        }
        if (outcome.posts.length === 0) {
          return { keyword: args.keyword, status: "empty" as const, posts: [], backend: "weibo-search-browser-fetch", error: outcome.error };
        }
        return { keyword: args.keyword, status: "ready" as const, savedTo, backend: "weibo-search-browser-fetch", posts: outcome.posts };
      },
    }),
  );

  // ---------- collect_bilibili_search ----------
  ctx.tools.register(
    defineTool({
      name: "collect_bilibili_search",
      description:
        "B 站视频搜索卡片采集（浏览器路径，单次访问）：navigate search.bilibili.com/video?keyword=… → 读 SSR 渲染的 /video/BV 链接（标题/UP 主/播放量文案）。对返回的 bilibili.com/video/{bvid} 链接可直接调 collect_comments 采评论（bilibili-api 通道，412 时自动浏览器同源兜底）。命中风控自动进入平台冷却；单次访问不滚动不点击。适合批量准备评论视频源。",
      parameters: {
        keyword: { type: "string", required: true, description: "搜索关键词（如「应用统计就业」「数据分析」）。" },
        topic: {
          type: "string",
          description: "语料主题：提供后每张卡片自动落盘到 <语料根>/insight-workspace/<topic>/corpus.jsonl（kind=article）。",
        },
        limit: { type: "integer", description: "最多返回卡片数（默认 20）。" },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            keyword: { type: "string", required: true },
            status: {
              type: "string",
              required: true,
              enum: ["ready", "failed", "rate_limited", "empty"],
            },
            savedTo: { type: "string" },
            backend: { type: "string", description: "实际后端 id（crawler_status 可查）。" },
            cards: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: {
                  bvid: { type: "string" },
                  url: { type: "string" },
                  title: { type: "string" },
                  author: { type: "string" },
                  playText: { type: "string" },
                },
              },
            },
            error: { type: "string" },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => false, // B 站低频纪律：同平台不并发
      async execute(args: { keyword: string; topic?: string; limit?: number }, exec: ToolRunContext) {
        if (!args.keyword?.trim()) throw new Error("keyword 不能为空");
        const cooldownMs = deps.pacer.cooldownRemainingMs("bilibili");
        if (cooldownMs > 0) {
          deps.health.record({
            platform: "bilibili",
            action: "search",
            backend: "bilibili-search-dom",
            outcome: "rate_limited",
            error: `冷却中（剩 ${Math.ceil(cooldownMs / 1000)}s）`,
          });
          return {
            keyword: args.keyword,
            status: "rate_limited" as const,
            cards: [],
            backend: "bilibili-search-dom",
            error: `B 站处于风控冷却期（剩 ${Math.ceil(cooldownMs / 1000)}s），请稍后重试`,
          };
        }
        const outcome = await collectBilibiliSearch(
          { pool, pacer: deps.pacer },
          exec,
          args.keyword,
          { limit: args.limit ?? 20 },
        );
        if (!outcome.ok) {
          deps.health.record({
            platform: "bilibili",
            action: "search",
            backend: "bilibili-search-dom",
            outcome: outcome.reason === "rate_limited" ? "rate_limited" : "error",
            error: outcome.error,
          });
          return {
            keyword: args.keyword,
            status: outcome.reason === "rate_limited" ? ("rate_limited" as const) : ("failed" as const),
            cards: [],
            backend: "bilibili-search-dom",
            error: outcome.error,
          };
        }
        deps.health.record({
          platform: "bilibili",
          action: "search",
          backend: "bilibili-search-dom",
          outcome: outcome.cards.length > 0 ? "success" : "empty",
        });
        let savedTo = "";
        if (args.topic && outcome.cards.length > 0) {
          try {
            const root = resolveCorpusRoot(ctx, deps.corpusDir, exec);
            if (root) {
              appendEntries(
                root,
                args.topic,
                outcome.cards.map((c) =>
                  makeEntry({
                    topic: args.topic!,
                    kind: "article",
                    url: c.url,
                    title: c.title,
                    source: "bilibili.com",
                    strategy: "browser",
                    text: `【B站】${c.title}\nUP：${c.author}\n播放 ${c.playText}\n${c.url}`,
                  }),
                ),
              );
              savedTo = corpusPath(root, args.topic);
            }
          } catch {
            // 落盘失败不阻断
          }
        }
        if (outcome.cards.length === 0) {
          return { keyword: args.keyword, status: "empty" as const, cards: [], backend: "bilibili-search-dom", error: outcome.error };
        }
        return { keyword: args.keyword, status: "ready" as const, savedTo, backend: "bilibili-search-dom", cards: outcome.cards };
      },
    }),
  );

  // ---------- collect_kuaishou_search ----------
  ctx.tools.register(
    defineTool({
      name: "collect_kuaishou_search",
      description:
        "快手视频搜索结果采集（单次访问）：navigate 搜索页 → 页面内读 window.INIT_STATE 的 search.feed 水合数据（卡片本身是 button 无 href，但 state 中有 photo.id）→ 返回 photoId + short-video 链接（标题/作者/点赞/播放）。命中风控自动进入平台冷却；单次访问不滚动不点击，符合被动采集纪律。返回的 kuaishou.com/short-video/{photoId} 链接可直接调 collect_comments 采评论（kuaishou-api 通道）。",
      parameters: {
        keyword: { type: "string", required: true, description: "搜索关键词（如「应用统计就业」「数据分析」）。" },
        topic: {
          type: "string",
          description: "语料主题：提供后每张卡片自动落盘到 <语料根>/insight-workspace/<topic>/corpus.jsonl（kind=article）。",
        },
        limit: { type: "integer", description: "最多返回卡片数（默认 20，首屏）。" },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            keyword: { type: "string", required: true },
            status: {
              type: "string",
              required: true,
              enum: ["ready", "failed", "rate_limited", "login_wall", "empty"],
            },
            savedTo: { type: "string" },
            backend: { type: "string", description: "实际后端 id（crawler_status 可查）。" },
            cards: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: {
                  photoId: { type: "string" },
                  url: { type: "string" },
                  title: { type: "string" },
                  author: { type: "string" },
                  likeCount: { type: "integer" },
                  viewCount: { type: "integer" },
                },
              },
            },
            error: { type: "string" },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => false, // 快手低频纪律：同平台不并发
      async execute(args: { keyword: string; topic?: string; limit?: number }, exec: ToolRunContext) {
        if (!args.keyword?.trim()) throw new Error("keyword 不能为空");
        const cooldownMs = deps.pacer.cooldownRemainingMs("kuaishou");
        if (cooldownMs > 0) {
          deps.health.record({
            platform: "kuaishou",
            action: "search",
            backend: "kuaishou-search-state",
            outcome: "rate_limited",
            error: `冷却中（剩 ${Math.ceil(cooldownMs / 1000)}s）`,
          });
          return {
            keyword: args.keyword,
            status: "rate_limited" as const,
            cards: [],
            backend: "kuaishou-search-state",
            error: `快手处于风控冷却期（剩 ${Math.ceil(cooldownMs / 1000)}s），请稍后重试`,
          };
        }
        const outcome = await collectKuaishouSearch(
          { pool, pacer: deps.pacer },
          exec,
          args.keyword,
          { limit: args.limit ?? 20 },
        );
        if (!outcome.ok) {
          const status =
            outcome.reason === "rate_limited"
              ? ("rate_limited" as const)
              : ("failed" as const);
          deps.health.record({
            platform: "kuaishou",
            action: "search",
            backend: "kuaishou-search-state",
            outcome: outcome.reason === "rate_limited" ? "rate_limited" : "error",
            error: outcome.error,
          });
          return { keyword: args.keyword, status, cards: [], backend: "kuaishou-search-state", error: outcome.error };
        }
        deps.health.record({
          platform: "kuaishou",
          action: "search",
          backend: "kuaishou-search-state",
          outcome: outcome.cards.length > 0 ? "success" : "empty",
        });
        let savedTo = "";
        if (args.topic && outcome.cards.length > 0) {
          try {
            const root = resolveCorpusRoot(ctx, deps.corpusDir, exec);
            if (root) {
              appendEntries(
                root,
                args.topic,
                outcome.cards.map((c) =>
                  makeEntry({
                    topic: args.topic!,
                    kind: "article",
                    url: c.url,
                    title: c.title,
                    source: "kuaishou.com",
                    strategy: "browser",
                    text: `【快手】${c.title}\n作者：${c.author}\n赞 ${c.likeCount} · 播放 ${c.viewCount}\n${c.url}`,
                  }),
                ),
              );
              savedTo = corpusPath(root, args.topic);
            }
          } catch {
            // 落盘失败不阻断
          }
        }
        if (outcome.cards.length === 0) {
          return { keyword: args.keyword, status: "empty" as const, cards: [], backend: "kuaishou-search-state", error: outcome.error };
        }
        return { keyword: args.keyword, status: "ready" as const, savedTo, backend: "kuaishou-search-state", cards: outcome.cards };
      },
    }),
  );

  // ---------- collect_douyin_search ----------
  ctx.tools.register(
    defineTool({
      name: "collect_douyin_search",
      description:
        "抖音视频搜索结果采集（浏览器路径，单次访问）：navigate 搜索页 → 页面内 fetch 搜索 API（免 a_bogus；API 空时自动 DOM 卡片兜底）→ 返回 aweme_id + 视频链接（标题/作者/点赞·评论数）。命中风控自动进入平台冷却；单次访问不滚动不点击，符合被动采集纪律。返回的 douyin.com/video/{aweme_id} 链接可直接调 collect_comments 采评论。",
      parameters: {
        keyword: { type: "string", required: true, description: "搜索关键词（如「数据分析」「应用统计就业」）。" },
        topic: {
          type: "string",
          description: "语料主题：提供后每张卡片自动落盘到 <语料根>/insight-workspace/<topic>/corpus.jsonl（kind=article）。",
        },
        limit: { type: "integer", description: "最多返回卡片数（默认 20，API 每页 25，可翻页）。" },
        sort_type: {
          type: "string",
          description: "排序：0 综合（默认）、1 最多点赞、2 最新发布。",
        },
        publish_time: {
          type: "string",
          description: "发布时间：0 不限（默认）、1 一天内、7 一周内、180 半年内。",
        },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            keyword: { type: "string", required: true },
            status: {
              type: "string",
              required: true,
              enum: ["ready", "failed", "rate_limited", "empty"],
            },
            savedTo: { type: "string" },
            backend: { type: "string", description: "实际后端 id（douyin-search-api / douyin-search-dom，crawler_status 可查）。" },
            cards: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: {
                  awemeId: { type: "string" },
                  url: { type: "string" },
                  title: { type: "string" },
                  author: { type: "string" },
                  diggCount: { type: "integer" },
                  commentCount: { type: "integer" },
                  createTime: { type: "integer" },
                },
              },
            },
            error: { type: "string" },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => false, // 抖音低频纪律：同平台不并发
      async execute(args: { keyword: string; topic?: string; limit?: number; sort_type?: string; publish_time?: string }, exec: ToolRunContext) {
        if (!args.keyword?.trim()) throw new Error("keyword 不能为空");
        const cooldownMs = deps.pacer.cooldownRemainingMs("douyin");
        if (cooldownMs > 0) {
          deps.health.record({
            platform: "douyin",
            action: "search",
            backend: "douyin-search-api",
            outcome: "rate_limited",
            error: `冷却中（剩 ${Math.ceil(cooldownMs / 1000)}s）`,
          });
          return {
            keyword: args.keyword,
            status: "rate_limited" as const,
            cards: [],
            backend: "douyin-search-api",
            error: `抖音处于风控冷却期（剩 ${Math.ceil(cooldownMs / 1000)}s），请稍后重试`,
          };
        }
        const outcome = await collectDouyinSearch(
          { pool, pacer: deps.pacer },
          exec,
          args.keyword,
          { limit: args.limit ?? 20, sortType: args.sort_type, publishTime: args.publish_time },
        );
        const backend = outcome.backend ?? "douyin-search-api";
        if (!outcome.ok) {
          const status =
            outcome.reason === "rate_limited"
              ? ("rate_limited" as const)
              : ("failed" as const);
          deps.health.record({
            platform: "douyin",
            action: "search",
            backend,
            outcome: outcome.reason === "rate_limited" ? "rate_limited" : "error",
            error: outcome.error,
          });
          return { keyword: args.keyword, status, cards: [], backend, error: outcome.error };
        }
        deps.health.record({
          platform: "douyin",
          action: "search",
          backend,
          outcome: outcome.cards.length > 0 ? "success" : "empty",
        });
        let savedTo = "";
        if (args.topic && outcome.cards.length > 0) {
          try {
            const root = resolveCorpusRoot(ctx, deps.corpusDir, exec);
            if (root) {
              appendEntries(
                root,
                args.topic,
                outcome.cards.map((c) =>
                  makeEntry({
                    topic: args.topic!,
                    kind: "article",
                    url: c.url,
                    title: c.title,
                    source: "douyin.com",
                    strategy: "browser",
                    text: `【抖音】${c.title}\n作者：${c.author}\n点赞 ${c.diggCount} · 评论 ${c.commentCount}\n${c.url}`,
                  }),
                ),
              );
              savedTo = corpusPath(root, args.topic);
            }
          } catch {
            // 落盘失败不阻断
          }
        }
        if (outcome.cards.length === 0) {
          return { keyword: args.keyword, status: "empty" as const, cards: [], backend, error: outcome.error };
        }
        return { keyword: args.keyword, status: "ready" as const, savedTo, backend, cards: outcome.cards };
      },
    }),
  );

  // ---------- collect_douyin_user ----------
  ctx.tools.register(
    defineTool({
      name: "collect_douyin_user",
      description:
        "抖音用户作品发现（浏览器路径，单次访问）：navigate 用户主页 /user/{sec_uid} → 页面内 fetch 用户作品 API（免 a_bogus）→ 返回该博主最近作品列表（aweme_id/链接/标题/作者/点赞·评论）。命中风控自动进入平台冷却；单次访问不滚动不点击。返回的视频链接可直接调 collect_comments 采评论。",
      parameters: {
        userUrl: { type: "string", required: true, description: "抖音用户主页 URL（须含 /user/{sec_uid}，如 https://www.douyin.com/user/MS4wLjABAAAA...）。" },
        topic: {
          type: "string",
          description: "语料主题：提供后每张作品卡片自动落盘到 <语料根>/insight-workspace/<topic>/corpus.jsonl（kind=article）。",
        },
        limit: { type: "integer", description: "最多返回作品数（默认 20，每页 18，可翻页）。" },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            userUrl: { type: "string", required: true },
            status: {
              type: "string",
              required: true,
              enum: ["ready", "failed", "rate_limited", "empty"],
            },
            savedTo: { type: "string" },
            backend: { type: "string", description: "实际后端 id（douyin-user-api，crawler_status 可查）。" },
            cards: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: {
                  awemeId: { type: "string" },
                  url: { type: "string" },
                  title: { type: "string" },
                  author: { type: "string" },
                  diggCount: { type: "integer" },
                  commentCount: { type: "integer" },
                  createTime: { type: "integer" },
                },
              },
            },
            error: { type: "string" },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => false, // 抖音低频纪律：同平台不并发
      async execute(args: { userUrl: string; topic?: string; limit?: number }, exec: ToolRunContext) {
        if (!args.userUrl?.trim()) throw new Error("userUrl 不能为空");
        const cooldownMs = deps.pacer.cooldownRemainingMs("douyin");
        if (cooldownMs > 0) {
          deps.health.record({
            platform: "douyin",
            action: "search",
            backend: "douyin-user-api",
            outcome: "rate_limited",
            error: `冷却中（剩 ${Math.ceil(cooldownMs / 1000)}s）`,
          });
          return {
            userUrl: args.userUrl,
            status: "rate_limited" as const,
            cards: [],
            backend: "douyin-user-api",
            error: `抖音处于风控冷却期（剩 ${Math.ceil(cooldownMs / 1000)}s），请稍后重试`,
          };
        }
        const outcome = await collectDouyinUserWorks(
          { pool, pacer: deps.pacer },
          exec,
          args.userUrl,
          { limit: args.limit ?? 20 },
        );
        const backend = "douyin-user-api";
        if (!outcome.ok) {
          const status =
            outcome.reason === "rate_limited"
              ? ("rate_limited" as const)
              : ("failed" as const);
          deps.health.record({
            platform: "douyin",
            action: "search",
            backend,
            outcome: outcome.reason === "rate_limited" ? "rate_limited" : "error",
            error: outcome.error,
          });
          return { userUrl: args.userUrl, status, cards: [], backend, error: outcome.error };
        }
        deps.health.record({
          platform: "douyin",
          action: "search",
          backend,
          outcome: outcome.cards.length > 0 ? "success" : "empty",
        });
        let savedTo = "";
        if (args.topic && outcome.cards.length > 0) {
          try {
            const root = resolveCorpusRoot(ctx, deps.corpusDir, exec);
            if (root) {
              appendEntries(
                root,
                args.topic,
                outcome.cards.map((c) =>
                  makeEntry({
                    topic: args.topic!,
                    kind: "article",
                    url: c.url,
                    title: c.title,
                    source: "douyin.com",
                    strategy: "browser",
                    text: `【抖音】${c.title}\n作者：${c.author}\n点赞 ${c.diggCount} · 评论 ${c.commentCount}\n${c.url}`,
                  }),
                ),
              );
              savedTo = corpusPath(root, args.topic);
            }
          } catch {
            // 落盘失败不阻断
          }
        }
        if (outcome.cards.length === 0) {
          return { userUrl: args.userUrl, status: "empty" as const, cards: [], backend, error: outcome.error };
        }
        return { userUrl: args.userUrl, status: "ready" as const, savedTo, backend, cards: outcome.cards };
      },
    }),
  );


  // -------------------------------------------------------------------------
  // v2 挖掘工具：语料落盘 / 分流分析（评论情感 · 文章主题聚类） / 报告导出
  // -------------------------------------------------------------------------

  /** 语料根目录（Config corpusDir → 会话工作目录 → process.cwd()）。 */
  function rootOf(exec: ToolRunContext): string {
    const root = resolveCorpusRoot(ctx, deps.corpusDir, exec);
    if (!root) throw new Error("无法确定语料根目录（会话工作目录不可用且未配置 corpusDir）");
    return root;
  }

  // ---------- save_corpus ----------
  ctx.tools.register(
    defineTool({
      name: "save_corpus",
      description:
        "手动保存文本到语料库（追加式，同 topic+url+内容去重）：`<语料根>/insight-workspace/<topic>/corpus.jsonl`。采集工具（collect_*_search/collect_comments）带 topic 时已自动落盘，本工具用于补充保存片段/摘录。",
      parameters: {
        topic: { type: "string", required: true, description: "语料主题（决定目录名）。" },
        items: {
          type: "array",
          required: true,
          description: "待保存条目（text 必填）。",
          items: {
            type: "object",
            additionalProperties: false,
            properties: {
              text: { type: "string", required: true, description: "文本内容。" },
              url: { type: "string", description: "来源 URL。" },
              title: { type: "string", description: "标题。" },
              source: { type: "string", description: "来源域名。" },
              trust: { type: "string", description: "A/B/C 可信分级。" },
            },
          },
        },
        kind: {
          type: "string",
          enum: ["article", "page", "comment", "rss"],
          description: "条目类型（默认 article）。",
        },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            topic: { type: "string", required: true },
            root: { type: "string", required: true },
            path: { type: "string", required: true },
            saved: { type: "integer", required: true },
            skipped: { type: "integer", required: true },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => true,
      async execute(
        args: {
          topic: string;
          items: Array<{ text: string; url?: string; title?: string; source?: string; trust?: string }>;
          kind?: string;
        },
        exec: ToolRunContext,
      ) {
        if (!args.topic?.trim()) throw new Error("topic 不能为空");
        if (!args.items?.length) throw new Error("items 不能为空");
        const root = rootOf(exec);
        const kind = (["article", "page", "comment", "rss"].includes(args.kind ?? "")
          ? args.kind
          : "article") as "article" | "page" | "comment" | "rss";
        const entries = args.items.map((it) =>
          makeEntry({
            topic: args.topic,
            kind,
            url: it.url ?? "",
            title: it.title ?? "",
            source: it.source ?? "",
            trust: it.trust,
            text: it.text,
          }),
        );
        // 手动保存是「用户可能动过文件」的边界：先失效去重缓存，避免陈旧缓存
        // 跳过本应保存的条目（用户外部删除/编辑 corpus.jsonl 后同进程内重写）。
        invalidateDedupCache(root, args.topic);
        const res = appendEntries(root, args.topic, entries);
        return { topic: args.topic, root, path: res.path, saved: res.saved, skipped: res.skipped };
      },
    }),
  );

  // ---------- corpus_stats ----------
  ctx.tools.register(
    defineTool({
      name: "corpus_stats",
      description:
        "语料统计：按类型/可信级/策略计数 + 最新采集时间。报告「证据数」章节用（如「共 N 条素材，A 级 M 条」）。",
      parameters: {
        topic: { type: "string", required: true, description: "语料主题。" },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            topic: { type: "string", required: true },
            root: { type: "string", required: true },
            path: { type: "string", required: true },
            total: { type: "integer", required: true },
            byKind: { type: "object", additionalProperties: true, required: true },
            byTrust: { type: "object", additionalProperties: true, required: true },
            byStrategy: { type: "object", additionalProperties: true, required: true },
            latestCollectedAt: { type: "string", required: true },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => true,
      async execute(args: { topic: string }, exec: ToolRunContext) {
        if (!args.topic?.trim()) throw new Error("topic 不能为空");
        const root = rootOf(exec);
        return corpusStatsOf(root, args.topic);
      },
    }),
  );

  // ---------- corpus_read ----------
  ctx.tools.register(
    defineTool({
      name: "corpus_read",
      description:
        "读取已落盘语料条目（按 topic/kind 过滤，分页；text 截断到 2000 字）。供报告引用原文/交叉核验/二次分析。",
      parameters: {
        topic: { type: "string", required: true, description: "语料主题。" },
        kind: { type: "string", enum: ["article", "page", "comment", "rss"], description: "按类型过滤。" },
        limit: { type: "integer", description: "返回条数上限（默认 200，上限 500）。" },
        offset: { type: "integer", description: "跳过条数（默认 0）。" },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            topic: { type: "string", required: true },
            root: { type: "string", required: true },
            total: { type: "integer", required: true },
            returned: { type: "integer", required: true },
            entries: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: {
                  id: { type: "string" },
                  kind: { type: "string" },
                  url: { type: "string" },
                  title: { type: "string" },
                  source: { type: "string" },
                  trust: { type: "string" },
                  strategy: { type: "string" },
                  collectedAt: { type: "string" },
                  text: { type: "string" },
                },
              },
            },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => true,
      async execute(
        args: { topic: string; kind?: string; limit?: number; offset?: number },
        exec: ToolRunContext,
      ) {
        if (!args.topic?.trim()) throw new Error("topic 不能为空");
        const root = rootOf(exec);
        const kind = args.kind as "article" | "page" | "comment" | "rss" | undefined;
        const entries = loadEntries(root, args.topic).filter((e) => (kind ? e.kind === kind : true));
        const limit = Math.max(1, Math.min(args.limit ?? 200, 500));
        const offset = Math.max(0, args.offset ?? 0);
        const page = entries.slice(offset, offset + limit);
        return {
          topic: args.topic,
          root,
          total: entries.length,
          returned: page.length,
          entries: page.map((e) => ({
            id: e.id,
            kind: e.kind,
            url: e.url,
            title: e.title,
            source: e.source,
            trust: e.trust ?? "",
            strategy: e.strategy ?? "",
            collectedAt: e.collectedAt,
            text: e.text.slice(0, 2000),
          })),
        };
      },
    }),
  );

  // ---------- mine_sentiment ----------
  ctx.tools.register(
    defineTool({
      name: "mine_sentiment",
      description:
        "情感分析（评论分支）：词典+否定/程度/转折规则快路径 + 廉价 LLM 校准低置信样本。输入给 topic（自动读语料 kind=comment）或 items；输出分桶/平均分/Top 正负向证据。",
      parameters: {
        topic: { type: "string", description: "语料主题（自动读 kind=comment 条目；与 items 二选一）。" },
        items: {
          type: "array",
          description: "直接分析的文本列表（与 topic 二选一）。",
          items: {
            type: "object",
            additionalProperties: false,
            properties: {
              text: { type: "string", required: true, description: "评论文本。" },
              url: { type: "string" },
              trust: { type: "string" },
            },
          },
        },
        calibrate: { type: "boolean", description: "是否启用 LLM 校准（默认 true）。" },
        max_calibrate: { type: "integer", description: "校准样本上限（默认 10，上限 50）。" },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            mode: { type: "string", required: true, enum: ["corpus", "items"] },
            source: { type: "string", required: true },
            total: { type: "integer", required: true },
            buckets: {
              type: "object",
              additionalProperties: false,
              properties: {
                positive: { type: "integer" },
                negative: { type: "integer" },
                neutral: { type: "integer" },
                total: { type: "integer" },
              },
            },
            avgScore: { type: "number" },
            topNegative: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: { text: { type: "string" }, score: { type: "number" }, trust: { type: "string" } },
              },
            },
            topPositive: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: { text: { type: "string" }, score: { type: "number" }, trust: { type: "string" } },
              },
            },
            degraded: { type: "boolean" },
            calibrationNote: { type: "string" },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => true,
      async execute(
        args: {
          topic?: string;
          items?: Array<{ text: string; url?: string; trust?: string }>;
          calibrate?: boolean;
          max_calibrate?: number;
        },
        exec: ToolRunContext,
      ) {
        const root = rootOf(exec);
        let mode: "corpus" | "items" = "items";
        let sourceName = "items";
        let list: Array<{ id: string; text: string; trust?: string; url?: string }> = [];
        if (args.topic?.trim()) {
          mode = "corpus";
          sourceName = args.topic;
          const entries = loadEntries(root, args.topic).filter((e) => e.kind === "comment");
          list = entries.map((e) => ({ id: e.id, text: e.text, trust: e.trust, url: e.url }));
        } else if (args.items?.length) {
          list = args.items.map((it, i) => ({ id: `#${i}`, text: it.text, trust: it.trust, url: it.url }));
        } else {
          throw new Error("需要提供 topic（读语料评论）或 items（直接分析）");
        }
        const { aggregate } = await mineSentiment(list, deps.cheap, {
          calibrate: args.calibrate ?? true,
          maxCalibrate: args.max_calibrate ?? 10,
        });
        if (mode === "corpus") {
          try {
            saveAnalysis(root, args.topic!, "mine_sentiment", {
              buckets: {
                positive: aggregate.positive,
                negative: aggregate.negative,
                neutral: aggregate.neutral,
                total: aggregate.total,
              },
              avgScore: aggregate.avgScore,
              degraded: aggregate.degraded,
            });
          } catch {
            // 快照失败不阻断
          }
        }
        return sanitizeLossless({
          mode,
          source: sourceName,
          total: aggregate.total,
          buckets: {
            positive: aggregate.positive,
            negative: aggregate.negative,
            neutral: aggregate.neutral,
            total: aggregate.total,
          },
          avgScore: aggregate.avgScore,
          topNegative: aggregate.topNegative,
          topPositive: aggregate.topPositive,
          degraded: aggregate.degraded,
          calibrationNote: aggregate.calibrationNote,
        });
      },
    }),
  );

  // ---------- dedupe_similar ----------
  ctx.tools.register(
    defineTool({
      name: "dedupe_similar",
      description:
        "跨源近似去重（SimHash 指纹 + 海明距离）：识别多源转载/重复文本，输出相似簇与真实独立计数。文章分支前置步骤——去重后的计数才是报告的真实证据数。",
      parameters: {
        topic: { type: "string", description: "语料主题（读全部条目；与 items 二选一）。" },
        items: {
          type: "array",
          description: "直接分析的文本列表（与 topic 二选一）。",
          items: {
            type: "object",
            additionalProperties: false,
            properties: {
              text: { type: "string", required: true, description: "文本。" },
              url: { type: "string" },
              id: { type: "string", description: "自定义 id（默认 #下标）。" },
            },
          },
        },
        threshold: { type: "integer", description: "海明距离阈值（默认 4；中文推荐 4-6，越小越严）。" },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            mode: { type: "string", required: true, enum: ["corpus", "items"] },
            source: { type: "string", required: true },
            total: { type: "integer", required: true },
            duplicateCount: { type: "integer", required: true },
            clusterCount: { type: "integer", required: true },
            clusters: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: {
                  size: { type: "integer" },
                  representative: { type: "string" },
                  members: { type: "array", items: { type: "string" } },
                  sources: { type: "array", items: { type: "string" } },
                },
              },
            },
            urls: { type: "array", items: { type: "string" } },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => true,
      async execute(
        args: {
          topic?: string;
          items?: Array<{ text: string; url?: string; id?: string }>;
          threshold?: number;
        },
        exec: ToolRunContext,
      ) {
        const root = rootOf(exec);
        let mode: "corpus" | "items" = "items";
        let sourceName = "items";
        let list: Array<{ id: string; text: string; url?: string }> = [];
        if (args.topic?.trim()) {
          mode = "corpus";
          sourceName = args.topic;
          const entries = loadEntries(root, args.topic);
          list = entries.map((e) => ({ id: e.id, text: e.text, url: e.url }));
        } else if (args.items?.length) {
          list = args.items.map((it, i) => ({ id: it.id ?? `#${i}`, text: it.text, url: it.url }));
        } else {
          throw new Error("需要提供 topic（读语料）或 items（直接分析）");
        }
        const result = dedupeSimilar(list, { threshold: args.threshold ?? 4 });
        if (mode === "corpus") {
          try {
            saveAnalysis(root, args.topic!, "dedupe_similar", {
              total: result.total,
              duplicateCount: result.duplicateCount,
              clusterCount: result.clusterCount,
            });
          } catch {
            // 快照失败不阻断
          }
        }
        return sanitizeLossless({
          mode,
          source: sourceName,
          total: result.total,
          duplicateCount: result.duplicateCount,
          clusterCount: result.clusterCount,
          clusters: result.clusters,
          urls: result.urls,
        });
      },
    }),
  );

  // ---------- cluster_topics ----------
  ctx.tools.register(
    defineTool({
      name: "cluster_topics",
      description:
        "主题聚类（文章分支）：SiliconFlow bge-m3 embedding → KMeans → 廉价 LLM 命名主题；embedding 不可用自动回退关键词聚类（degraded 标记）。输出主题清单（标签/规模/代表文本/来源/平均情感）。",
      parameters: {
        topic: { type: "string", description: "语料主题（读 kind=article/page 条目；与 items 二选一）。" },
        items: {
          type: "array",
          description: "直接分析的文本列表（与 topic 二选一）。",
          items: {
            type: "object",
            additionalProperties: false,
            properties: {
              text: { type: "string", required: true, description: "文章文本。" },
              url: { type: "string" },
              source: { type: "string" },
            },
          },
        },
        k: { type: "integer", description: "主题数（默认 min(8, n/5)，2-12）。" },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            mode: { type: "string", required: true, enum: ["corpus", "items"] },
            source: { type: "string", required: true },
            total: { type: "integer", required: true },
            method: { type: "string", required: true, enum: ["embedding", "keyword"] },
            degraded: { type: "boolean", required: true },
            embeddingAvailable: { type: "boolean", required: true },
            note: { type: "string" },
            topics: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                properties: {
                  label: { type: "string" },
                  note: { type: "string" },
                  size: { type: "integer" },
                  representative: { type: "string" },
                  sources: { type: "array", items: { type: "string" } },
                  avgSentiment: { type: "string", enum: ["positive", "negative", "neutral"] },
                  avgScore: { type: "number" },
                },
              },
            },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => true,
      async execute(
        args: {
          topic?: string;
          items?: Array<{ text: string; url?: string; source?: string }>;
          k?: number;
        },
        exec: ToolRunContext,
      ) {
        const root = rootOf(exec);
        let mode: "corpus" | "items" = "items";
        let sourceName = "items";
        let list: TopicItem[] = [];
        if (args.topic?.trim()) {
          mode = "corpus";
          sourceName = args.topic;
          const entries = loadEntries(root, args.topic).filter(
            (e) => e.kind === "article" || e.kind === "page",
          );
          list = entries.map((e) => ({ id: e.id, text: e.text, url: e.url, source: e.source }));
        } else if (args.items?.length) {
          list = args.items.map((it, i) => ({ id: `#${i}`, text: it.text, url: it.url, source: it.source }));
        } else {
          throw new Error("需要提供 topic（读语料文章）或 items（直接分析）");
        }
        // 空语料明确提示（区别于 embedding 服务故障）
        if (list.length === 0) {
          return {
            mode,
            source: sourceName,
            total: 0,
            method: "keyword" as const,
            degraded: false,
            embeddingAvailable: false,
            note: "语料中无 article/page 条目：请先 collect_*_search(topic=...) 采集，或 save_corpus(kind=article) 补录文章文本",
            topics: [],
          };
        }
        const embedCfg = loadEmbeddingConfig(deps.envPath, deps.embedOverrides);
        let embed = null;
        if (embedCfg.apiKey) {
          embed = await embedTexts(embedCfg, list.map((i) => i.text.slice(0, 2000)), exec.signal);
        }
        const result = await clusterTopics(list, deps.cheap, { k: args.k, embed });
        if (mode === "corpus") {
          try {
            saveAnalysis(root, args.topic!, "cluster_topics", {
              method: result.method,
              degraded: result.degraded,
              topics: result.topics.map((t) => ({ label: t.label, size: t.size, avgSentiment: t.avgSentiment })),
            });
          } catch {
            // 快照失败不阻断
          }
        }
        return sanitizeLossless({
          mode,
          source: sourceName,
          total: result.total,
          method: result.method,
          degraded: result.degraded,
          embeddingAvailable: result.embeddingAvailable,
          topics: result.topics,
        });
      },
    }),
  );

  // ---------- export_report ----------
  ctx.tools.register(
    defineTool({
      name: "export_report",
      description:
        "把最终详细报告（markdown）导出到语料目录 `<语料根>/insight-workspace/<topic>/report.md` 并返回路径；聊天同步展示。重复导出需 overwrite:true。",
      parameters: {
        topic: { type: "string", required: true, description: "语料主题（目录名）。" },
        report: { type: "string", required: true, description: "完整 markdown 报告正文。" },
        overwrite: { type: "boolean", description: "已存在时是否覆盖（默认 false）。" },
      },
      output: {
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            topic: { type: "string", required: true },
            root: { type: "string", required: true },
            path: { type: "string", required: true },
            chars: { type: "integer", required: true },
            ok: { type: "boolean", required: true },
          },
        },
        render: renderText,
      },
      isConcurrencySafe: () => true,
      async execute(
        args: { topic: string; report: string; overwrite?: boolean },
        exec: ToolRunContext,
      ) {
        if (!args.topic?.trim()) throw new Error("topic 不能为空");
        if (!args.report?.trim()) throw new Error("report 不能为空");
        const root = rootOf(exec);
        try {
          const res = saveReport(root, args.topic, args.report, args.overwrite ?? false);
          return { topic: args.topic, root, path: res.path, chars: res.chars, ok: true };
        } catch (error) {
          throw new Error(
            `${error instanceof Error ? error.message : String(error)}（可传 overwrite:true 覆盖）`,
          );
        }
      },
    }),
  );
}
