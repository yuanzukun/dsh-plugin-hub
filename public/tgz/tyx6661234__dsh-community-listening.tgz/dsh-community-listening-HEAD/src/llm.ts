/**
 * LLM 调用封装：通过 ctx.llm.stream 做一次短调用。
 *
 * 设计要点（简化版）：
 * - provider/model 从 agentDefaultModel.currentSelection() 解析（未配置则降级返回 null，
 *   调用方走模板/规则兜底——对齐 Insight AI best-effort 哲学）
 * - 流式收集 text 块；finish 时 reason 为 error/aborted 则抛错
 * - llmJson：要求模型只输出 JSON，做解析 + 类型校验，失败可重试一次
 */

import type { Context } from "@deepseek-ai/cordis";
import { createUserMessage } from "@deepseek-ai/dsh-llm/message";
import type { StreamChunk } from "@deepseek-ai/dsh-llm/types";
import { readFileSync } from "node:fs";
import { httpFetch } from "./net";

export interface LlmDeps {
  ctx: Context;
  signal?: AbortSignal;
  /** 覆盖默认 provider/model（主要用于单测）。 */
  provider?: string;
  model?: string;
}

interface Selection {
  provider: string;
  model: string;
}

function resolveSelection(ctx: Context): Selection | null {
  const svc = ctx.get("agentDefaultModel") as
    | { currentSelection(): unknown }
    | undefined;
  try {
    const sel = svc?.currentSelection() as Selection | undefined;
    if (sel && typeof sel.provider === "string" && typeof sel.model === "string") {
      return { provider: sel.provider, model: sel.model };
    }
  } catch {
    // ignore
  }
  return null;
}

function userMessage(text: string) {
  return createUserMessage({ content: [{ type: "text", text }], source: { kind: "user" } });
}

/** 收集一次 llm.stream 的可见文本；异常/取消抛 LlmCallError。 */
export class LlmCallError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "LlmCallError";
  }
}

async function collectText(
  stream: AsyncIterable<StreamChunk>,
  signal?: AbortSignal,
): Promise<string> {
  let out = "";
  for await (const chunk of stream) {
    if (signal?.aborted) throw new LlmCallError("LLM 调用被取消");
    if (chunk.type === "text-delta") {
      out += chunk.text;
    } else if (chunk.type === "finish") {
      if (chunk.reason && typeof chunk.reason === "object" && "kind" in chunk.reason) {
        const kind = (chunk.reason as { kind?: string }).kind;
        if (kind === "error" || kind === "aborted") {
          const failure = (chunk.reason as { failure?: unknown }).failure;
          const detail =
            failure && typeof failure === "object" && "message" in failure
              ? String((failure as { message: unknown }).message)
              : String(kind);
          throw new LlmCallError(`LLM 调用失败: ${detail}`);
        }
      }
    }
  }
  return out.trim();
}

/** 完成一次纯文本生成；LLM 不可用时返回 null（调用方兜底）。 */
export async function llmText(deps: LlmDeps, system: string, prompt: string): Promise<string | null> {
  const llm = deps.ctx.get("llm") as
    | { stream(options: { provider: string; model: string; messages: unknown[]; system?: string; temperature?: number }): AsyncIterable<StreamChunk> }
    | undefined;
  if (!llm) return null;
  const selection = deps.provider && deps.model
    ? { provider: deps.provider, model: deps.model }
    : resolveSelection(deps.ctx);
  if (!selection) return null;
  try {
    const stream = llm.stream({
      provider: selection.provider,
      model: selection.model,
      messages: [userMessage(prompt)],
      system,
      temperature: 0,
    });
    return await collectText(stream, deps.signal);
  } catch (error) {
    if (error instanceof LlmCallError) throw error;
    return null;
  }
}

/** 提取一段文本里的 JSON 对象（容忍 ```json 围栏与前后杂讯）。 */
export function extractJsonObject(text: string): unknown {
  let candidate = text.trim();
  const fence = candidate.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence) candidate = fence[1].trim();
  const start = candidate.indexOf("{");
  const end = candidate.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  try {
    return JSON.parse(candidate.slice(start, end + 1));
  } catch {
    return null;
  }
}

/** 提取一段文本里的 JSON 数组（容忍 ```json 围栏与前后杂讯；整体截取 [..] 解析）。 */
export function extractJsonArray(text: string): unknown[] | null {
  let candidate = text.trim();
  const fence = candidate.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence) candidate = fence[1].trim();
  const start = candidate.indexOf("[");
  const end = candidate.lastIndexOf("]");
  if (start === -1 || end === -1 || end <= start) return null;
  try {
    const parsed = JSON.parse(candidate.slice(start, end + 1));
    return Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

/** 简单 JSON Schema（type=object + properties）类型校验。 */
export function validateJsonObject(value: unknown, schema: Record<string, unknown>): boolean {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
  const properties = (schema.properties ?? {}) as Record<string, { type?: string }>;
  for (const [key, prop] of Object.entries(properties)) {
    if (prop?.type === undefined) continue;
    if (key in value) {
      const v = (value as Record<string, unknown>)[key];
      const ok =
        prop.type === "string" ? typeof v === "string"
        : prop.type === "integer" || prop.type === "number" ? typeof v === "number"
        : prop.type === "boolean" ? typeof v === "boolean"
        : prop.type === "array" ? Array.isArray(v)
        : prop.type === "object" ? typeof v === "object" && v !== null && !Array.isArray(v)
        : true;
      if (!ok) return false;
    }
  }
  return true;
}

/**
 * 按 JSON Schema 做一次结构化生成：返回解析并校验通过的纯对象；
 * 失败（LLM 不可用 / 解析失败）返回 null；重试一次后仍失败返回 null。
 */
export async function llmJson(
  deps: LlmDeps,
  system: string,
  prompt: string,
  schema: Record<string, unknown>,
): Promise<Record<string, unknown> | null> {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const text = await llmText(
      deps,
      `${system}\n必须只输出一个 JSON 对象，不要输出任何其他内容。`,
      prompt,
    );
    if (text === null) return null;
    const parsed = extractJsonObject(text);
    if (parsed !== null && validateJsonObject(parsed, schema)) {
      return parsed as Record<string, unknown>;
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// 免费/廉价 LLM 通道（脏活专用）：
// 优先 opencode free（多模型轮转，约 2 亿 token/天），失败切 sensenova lite
// （LLM_MODEL_LITE，多 key 轮转）；两者都不可用返回 null，调用方回退主模型路由。
// 配置来源：插件 config（envPath）→ process.env → Insight AI 的 .env 文件。
// ---------------------------------------------------------------------------

/** 解析逗号分隔或 JSON 数组的列表字段（如 OPENCODE_FREE_MODELS / OPENAI_API_KEYS）。 */
export function parseList(raw: string | undefined): string[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (Array.isArray(parsed)) return parsed.map(String).filter(Boolean);
  } catch {
    // 非 JSON → 逗号分隔
  }
  return raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

export interface CheapLlmConfig {
  /** opencode free 通道 */
  freeBaseUrl?: string;
  freeApiKey?: string;
  freeModels: string[];
  /** opencode free 通道的 User-Agent（实测缺省会触发 429 限流，须伪装成 opencode 客户端）。 */
  freeUserAgent?: string;
  /** sensenova lite 通道 */
  liteBaseUrl?: string;
  liteKeys: string[];
  liteModel?: string;
}

/** 免费/廉价 LLM 通道：多模型/多 key 轮转 + 坏模型黑名单 + 双通道级联。 */
export class CheapLlm {
  /** 会话内不可用的模型（401/403/404：模型配置/权限问题，跳过以省配额）。 */
  private readonly blacklist = new Set<string>();

  constructor(
    private readonly cfg: CheapLlmConfig,
    private readonly timeoutMs = 30_000,
  ) {}

  available(): boolean {
    return (
      (!!this.cfg.freeApiKey && this.cfg.freeModels.length > 0) ||
      (this.cfg.liteKeys.length > 0 && !!this.cfg.liteModel)
    );
  }

  /** 完成一次生成：opencode free → sensenova lite；全部失败返回 null。 */
  async complete(system: string, prompt: string): Promise<string | null> {
    // 1) opencode free（免费，多模型轮转；跳过黑名单模型）
    if (this.cfg.freeApiKey && this.cfg.freeBaseUrl && this.cfg.freeModels.length > 0) {
      const usable = this.cfg.freeModels.filter((m) => !this.blacklist.has(m));
      for (const model of usable) {
        const text = await this.chat(
          this.cfg.freeBaseUrl,
          this.cfg.freeApiKey,
          model,
          system,
          prompt,
          this.cfg.freeUserAgent,
        );
        if (text !== null) return text;
      }
    }
    // 2) sensenova lite（多 key 轮转）
    if (this.cfg.liteBaseUrl && this.cfg.liteModel && this.cfg.liteKeys.length > 0) {
      let idx = 0;
      for (let i = 0; i < this.cfg.liteKeys.length; i += 1) {
        const key = this.cfg.liteKeys[idx % this.cfg.liteKeys.length];
        idx += 1;
        const text = await this.chat(this.cfg.liteBaseUrl, key, this.cfg.liteModel, system, prompt);
        if (text !== null) return text;
      }
    }
    return null;
  }

  /**
   * 单次 OpenAI 兼容 chat 调用；非 2xx/异常返回 null（换通道/模型重试）。
   * - 401/403/404：模型不可用（权限/不存在）→ 加入黑名单
   * - 429：限流 → 不黑名单，换下一个模型/通道
   * - 503：服务临时不可用 → 不黑名单，换下一个（可能恢复）
   */
  private async chat(
    baseUrl: string,
    apiKey: string,
    model: string,
    system: string,
    prompt: string,
    userAgent?: string,
  ): Promise<string | null> {
    try {
      const headers: Record<string, string> = {
        "content-type": "application/json",
        authorization: `Bearer ${apiKey}`,
      };
      if (userAgent) headers["user-agent"] = userAgent;
      const resp = await httpFetch(`${baseUrl.replace(/\/+$/, "")}/chat/completions`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: system },
            { role: "user", content: prompt },
          ],
          temperature: 0,
          stream: false,
        }),
      });
      if (!resp.ok) {
        // 401/403/404 = 模型权限/不存在（永久性）→ 黑名单跳过；429/5xx = 限流/临时 → 换下一个
        if (resp.status === 401 || resp.status === 403 || resp.status === 404) {
          this.blacklist.add(model);
        }
        return null;
      }
      const data = (await resp.json()) as { choices?: Array<{ message?: { content?: string } }> };
      const text = data.choices?.[0]?.message?.content;
      return text && text.trim() ? text.trim() : null;
    } catch {
      return null;
    }
  }
}

/** 解析 .env 文本为 key-value（跳过注释；去引号）。 */
export function parseEnvText(content: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const m = trimmed.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (m) out[m[1]] = m[2].trim().replace(/^["']|["']$/g, "");
  }
  return out;
}

const ENV_KEYS = [
  "OPENCODE_API_BASE_URL",
  "OPENCODE_API_KEY",
  "OPENCODE_FREE_MODELS",
  "LLM_BASE_URL",
  "OPENAI_API_KEYS",
  "LLM_MODEL_LITE",
] as const;

/**
 * 加载廉价通道配置：process.env 优先，缺字段用 .env 文件补充（如 Insight AI 的 .env）。
 * envPath 为空则仅读 process.env。
 */
export function loadCheapLlm(envPath?: string): CheapLlm {
  const env: Record<string, string> = {};
  for (const key of ENV_KEYS) {
    const v = process.env[key];
    if (v) env[key] = v;
  }
  if (envPath) {
    try {
      const fileEnv = parseEnvText(readFileSync(envPath, "utf8"));
      for (const key of ENV_KEYS) {
        if (env[key] === undefined && fileEnv[key] !== undefined) env[key] = fileEnv[key];
      }
    } catch {
      // .env 不可读 → 仅用 process.env
    }
  }
  return new CheapLlm({
    freeBaseUrl: env.OPENCODE_API_BASE_URL || "https://opencode.ai/zen/v1",
    freeApiKey: env.OPENCODE_API_KEY,
    freeModels: parseList(env.OPENCODE_FREE_MODELS),
    // 实测：opencode free 缺省 UA 会触发 429 限流，必须伪装成 opencode 客户端
    freeUserAgent: "opencode",
    liteBaseUrl: env.LLM_BASE_URL,
    liteKeys: parseList(env.OPENAI_API_KEYS),
    liteModel: env.LLM_MODEL_LITE,
  });
}

/**
 * 廉价通道结构化生成：返回解析并校验通过的纯对象；通道不可用/失败返回 null
 * （调用方回退主模型路由）。
 */
export async function cheapLlmJson(
  cheap: CheapLlm | undefined,
  system: string,
  prompt: string,
  schema: Record<string, unknown>,
): Promise<Record<string, unknown> | null> {
  if (!cheap || !cheap.available()) return null;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const text = await cheap.complete(
      `${system}\n必须只输出一个 JSON 对象，不要输出任何其他内容。`,
      prompt,
    );
    if (text === null) return null;
    const parsed = extractJsonObject(text);
    if (parsed !== null && validateJsonObject(parsed, schema)) {
      return parsed as Record<string, unknown>;
    }
  }
  return null;
}
