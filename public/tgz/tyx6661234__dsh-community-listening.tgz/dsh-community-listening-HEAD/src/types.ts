/**
 * 共享类型定义（dsh-community-listening）。
 * 工具返回给模型的都是纯 JSON 值；这里只声明最小形状。
 */

export interface CommentEntry {
  author: string;
  content: string;
  replies: string[];
}

export interface CommentMineResult {
  url: string;
  title: string;
  /** 内容作者/UP 主（平台 API 通道提供时；浏览器兜底可能为空）。 */
  author?: string;
  comments: CommentEntry[];
  /** 情感分桶（词典启发式）：positive/negative/neutral 计数。 */
  sentiment: Record<"positive" | "negative" | "neutral", number>;
  /** 被降噪剔除的评论条数。 */
  dropped: number;
  /** 页面加载成功但未提取到任何评论/回答（区别于 captcha/登录墙失败）。 */
  empty?: boolean;
  hint?: string;
  error?: string;
  /** 实际采用通道：zhihu-api / bilibili-api / xiaohongshu-api / weibo-api / douyin-api / kuaishou-api / nowcoder-api / tieba-api / browser（浏览器兜底）。 */
  strategy?:
    | "zhihu-api"
    | "bilibili-api"
    | "xiaohongshu-api"
    | "weibo-api"
    | "douyin-api"
    | "kuaishou-api"
    | "nowcoder-api"
    | "tieba-api"
    | "browser";
  /** 实际后端 id（如 bilibili-browser-fetch）。 */
  backend?: string;
  /** 本次尝试过的降级后端列表。 */
  fallbacks?: string[];
  /** 是否经过降级（主通道失败后由兜底通道成功）。 */
  degraded?: boolean;
}
