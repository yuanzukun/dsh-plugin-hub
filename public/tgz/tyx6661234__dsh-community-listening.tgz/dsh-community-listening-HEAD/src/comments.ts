/**
 * 评论降噪与情感聚合（简化版，移植 comment_service.py + trust_service.py 词表）。
 * 纯函数，可单测。
 */

import { createHash } from "node:crypto";
import type { CommentEntry } from "./types";

const NOISE_PHRASES = [
  "求拉", "打卡", "同问", "蹲一个", "蹲", "私我", "已私", "插眼",
];

const POSITIVE_WORDS = ["不错", "好评", "推荐", "满意", "给力", "赞", "舒服", "顺利", "offer", "通过"];
const NEGATIVE_WORDS = [
  "差", "坑", "雷", "劝退", "失望", "加班", "压榨", "裁员", "延迟", "拒绝", "难",
  "恶心", "套路", "黑", "避雷", "后悔", "扣钱",
];

/** 过滤无信息量评论（求拉/打卡/同问/空/超短）并按内容去重；返回 (kept, dropped)。 */
export function denoiseComments(comments: CommentEntry[]): { kept: CommentEntry[]; dropped: number } {
  const seen = new Set<string>();
  const kept: CommentEntry[] = [];
  let dropped = 0;
  for (const comment of comments) {
    const content = (comment.content ?? "").trim();
    if (!content || content.length < 4) {
      dropped += 1;
      continue;
    }
    const lowered = content.toLowerCase();
    if (NOISE_PHRASES.some((p) => lowered.includes(p))) {
      dropped += 1;
      continue;
    }
    const digest = createHash("md5").update(content).digest("hex");
    if (seen.has(digest)) {
      dropped += 1;
      continue;
    }
    seen.add(digest);
    kept.push({ ...comment, content });
  }
  return { kept, dropped };
}

/** 情感分桶：positive / negative / neutral（词典启发式）。 */
export function sentiment(text: string): "positive" | "negative" | "neutral" {
  const neg = NEGATIVE_WORDS.filter((w) => text.includes(w)).length;
  const pos = POSITIVE_WORDS.filter((w) => text.includes(w)).length;
  if (neg > pos) return "negative";
  if (pos > neg) return "positive";
  return "neutral";
}

export interface SentimentBuckets {
  positive: number;
  negative: number;
  neutral: number;
  total: number;
  topNegative: Array<{ content: string }>;
}

/** 口碑维度聚合：{positive, negative, neutral, total, top_negative[]}。 */
export function aggregateSentiment(comments: CommentEntry[]): SentimentBuckets {
  const buckets = { positive: 0, negative: 0, neutral: 0 };
  const negativeList: Array<{ content: string }> = [];
  for (const comment of comments) {
    const s = sentiment(comment.content ?? "");
    buckets[s] += 1;
    if (s === "negative") negativeList.push({ content: (comment.content ?? "").slice(0, 80) });
  }
  return {
    ...buckets,
    total: comments.length,
    topNegative: negativeList.slice(0, 5),
  };
}
