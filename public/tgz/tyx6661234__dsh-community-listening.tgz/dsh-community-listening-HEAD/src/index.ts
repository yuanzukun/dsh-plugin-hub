/**
 * dsh-community-listening —— 社交评论挖掘与分析工具集（JS 原生）插件。
 *
 * 提供模型可见工具：collect_comments / collect_*_search / crawler_status /
 * save_corpus / corpus_stats / corpus_read / mine_sentiment / dedupe_similar /
 * cluster_topics / export_report。
 *
 * 复用 DSH 现有基础设施：bsk CLI（浏览器采集）、ctx.llm（结构化提取/评论提炼）、
 * 廉价 LLM 通道与 SiliconFlow embedding。不依赖 Python / Insight AI 服务运行。
 */

import type { Context } from "@deepseek-ai/cordis";
import Schema from "@deepseek-ai/schemastery";
import { BrowserSessionPool } from "./collect";
import { sessionCwdFromCtx } from "./corpus";
import { CrawlerHealth, healthStateFile } from "./health";
import { CheapLlm, loadCheapLlm } from "./llm";
import { PlatformPacer, resolveStateFile } from "./pacing";
import { setDirectHostSuffixes } from "./net";
import { createBskRunner, isCommandNotFound, bskInstallMessage } from "./runner";
import { registerTools } from "./tools";

export const name = "dsh-community-listening";
export const inject = ["tools"];

/** 运行时配置（Schemastery；cordis.patch.yml 的 config 覆盖）。 */
export const Config = Schema.object({
  bskPath: Schema.string()
    .default("bsk")
    .description("bsk CLI 路径（默认从 PATH 解析）。"),
  bskTimeoutMs: Schema.number()
    .default(120_000)
    .description("单次 bsk 命令超时（毫秒）。"),
  maxCollectConcurrency: Schema.number()
    .default(3)
    .description("浏览器路径并发上限（多开 Agent Window 标签页；上限 5，评论/搜索采集共用）。"),
  envPath: Schema.string()
    .default("")
    .description(
      "廉价 LLM 通道的 .env 文件路径（opencode free / sensenova lite 配置来源；留空仅用 process.env）。",
    ),
  autoLaunchChrome: Schema.boolean()
    .default(true)
    .description("无浏览器连接时自动拉起本机 Chrome（带 BrowserSkill 扩展），无需手动打开。"),
  chromePath: Schema.string()
    .default("")
    .description("Chrome/Edge 可执行文件路径；留空自动探测常见安装路径。"),
  chromeProfileDir: Schema.string()
    .default("")
    .description(
      "自动拉起时使用的 Chrome profile 目录（留空用默认 profile，保留登录态）；指定专属目录时自动拷贝 BrowserSkill 扩展加载。",
    ),
  corpusDir: Schema.string()
    .default("")
    .description(
      "语料根目录（绝对路径覆盖；留空用「新开会话的工作目录」下 insight-workspace/<topic>/）。",
    ),
  siliconflowKey: Schema.string()
    .default("")
    .description("SiliconFlow API Key（embedding 通道；留空读 envPath/.env 的 SILICONFLOW_API_KEY）。"),
  siliconflowBaseUrl: Schema.string()
    .default("")
    .description("SiliconFlow Base URL（留空默认 https://api.siliconflow.cn/v1）。"),
  embeddingModel: Schema.string()
    .default("")
    .description("Embedding 模型（留空默认 BAAI/bge-m3）。"),
  zhihuMaxAnswers: Schema.number()
    .default(50)
    .description("collect_comments 知乎问题页最多采集的回答条数（API 通道）。"),
  zhihuMaxAnswerComments: Schema.number()
    .default(10)
    .description("collect_comments 知乎通道对前 N 条回答取评论区。"),
  bilibiliMaxComments: Schema.number()
    .default(100)
    .description("collect_comments B 站视频页最多采集的评论条数（主评论 + 楼中楼合计）。"),
  bilibiliMaxReplyComments: Schema.number()
    .default(20)
    .description("collect_comments B 站只对前 N 条主评论抓楼中楼（mode=3 主评论按热度序，等效 Top-N；控制子请求数）。"),
  pacingStateFile: Schema.string()
    .default("")
    .description(
      "平台风控冷却状态落盘路径（留空用会话工作目录 .pacing.json；空会话则仅内存）。",
    ),
  bilibiliCookie: Schema.string()
    .default("")
    .description(
      "可选 B 站登录 Cookie（如 SESSDATA=...; bili_jct=...）。匿名 API 请求在部分网络出口会被 B 站 412 风控；带登录态可显著提高评论采集可用性。敏感凭据仅在本机使用，不落盘、不外发。",
    ),
  bypassProxyHosts: Schema.array(Schema.string())
    .default([])
    .description(
      "追加直连（不走系统代理）的域名后缀列表，如 [\".example.com\"]。默认国内社区平台（知乎 / B站 / 小红书 / 牛客 / 微博 / 抖音）已直连；其余走系统代理（海外站）。",
    ),
});

export interface PluginConfig {
  bskPath: string;
  bskTimeoutMs: number;
  maxCollectConcurrency: number;
  envPath: string;
  autoLaunchChrome: boolean;
  chromePath: string;
  chromeProfileDir: string;
  corpusDir: string;
  siliconflowKey: string;
  siliconflowBaseUrl: string;
  embeddingModel: string;
  zhihuMaxAnswers: number;
  zhihuMaxAnswerComments: number;
  bilibiliMaxComments: number;
  bilibiliMaxReplyComments: number;
  pacingStateFile: string;
  bilibiliCookie: string;
  bypassProxyHosts: string[];
}

/** 配置优先，其次读同名环境变量（与 sn-search-social-cn 的约定一致）。 */
function envOr(configValue: string | undefined, envName: string): string {
  if (configValue !== undefined && configValue !== "") return configValue;
  return process.env[envName] ?? "";
}

function boundedInt(value: number | undefined, fallback: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(value as number)));
}

/** Normalize config values before creating generation-scoped resources. */
export function resolvePluginConfig(config: Partial<PluginConfig> = {}): PluginConfig {
  return {
    bskPath: config.bskPath?.trim() || "bsk",
    bskTimeoutMs: boundedInt(config.bskTimeoutMs, 120_000, 1_000, 600_000),
    maxCollectConcurrency: boundedInt(config.maxCollectConcurrency, 3, 1, 5),
    envPath: config.envPath?.trim() ?? "",
    autoLaunchChrome: config.autoLaunchChrome ?? true,
    chromePath: config.chromePath?.trim() ?? "",
    chromeProfileDir: config.chromeProfileDir?.trim() ?? "",
    corpusDir: envOr(config.corpusDir, "DSH_INSIGHT_CORPUS_DIR"),
    siliconflowKey: config.siliconflowKey?.trim() ?? "",
    siliconflowBaseUrl: config.siliconflowBaseUrl?.trim() ?? "",
    embeddingModel: config.embeddingModel?.trim() ?? "",
    zhihuMaxAnswers: boundedInt(config.zhihuMaxAnswers, 50, 1, 200),
    zhihuMaxAnswerComments: boundedInt(config.zhihuMaxAnswerComments, 10, 0, 100),
    bilibiliMaxComments: boundedInt(config.bilibiliMaxComments, 100, 1, 500),
    bilibiliMaxReplyComments: boundedInt(config.bilibiliMaxReplyComments, 20, 0, 100),
    pacingStateFile: envOr(config.pacingStateFile, "DSH_INSIGHT_PACING_STATE"),
    bilibiliCookie: envOr(config.bilibiliCookie, "BILIBILI_COOKIE"),
    bypassProxyHosts: config.bypassProxyHosts ?? [],
  };
}

export function apply(ctx: Context, config: Partial<PluginConfig> = {}): void {
  const resolved = resolvePluginConfig(config);

  // 代理出口分级：国内社区平台直连（避免代理出口 IP 被平台风控；海外站走系统代理）
  setDirectHostSuffixes(resolved.bypassProxyHosts);

  // 平台节流/冷却（风控指数退避；状态落盘到会话工作目录，跨进程重启存活）
  const pacingFile = resolveStateFile(resolved.pacingStateFile, sessionCwdFromCtx(ctx));
  const pacer = new PlatformPacer({ stateFile: pacingFile });

  // 通道健康记录（Agent-Reach doctor 思路；与 pacing 状态同目录落盘）
  const health = new CrawlerHealth({ stateFile: healthStateFile(pacingFile) });

  // 浏览器会话池（多开 Agent Window，并发采集互不串台；无浏览器自动拉起 Chrome）
  const bskRunner = createBskRunner(resolved.bskPath);
  const pool = new BrowserSessionPool(
    resolved.bskPath,
    resolved.bskTimeoutMs,
    resolved.maxCollectConcurrency,
    {
      autoLaunchChrome: resolved.autoLaunchChrome,
      chromePath: resolved.chromePath || undefined,
      chromeProfileDir: resolved.chromeProfileDir || undefined,
      runner: bskRunner,
    },
  );
  // 廉价 LLM 通道（脏活专用）：opencode free → sensenova lite → 兜底主模型路由
  const cheap = loadCheapLlm(resolved.envPath);
  if (cheap.available()) {
    console.log(`[${name}] 廉价 LLM 通道可用（opencode free ${cheap.available() ? "已配置" : "无"}）`);
  } else {
    console.warn(`[${name}] 廉价 LLM 通道不可用（将回退主模型路由）`);
  }

  // ---- 工具注册 ----
  registerTools({
    ctx,
    bskPath: resolved.bskPath,
    bskTimeoutMs: resolved.bskTimeoutMs,
    pool,
    cheap,
    envPath: resolved.envPath,
    corpusDir: resolved.corpusDir,
    pacer,
    health,
    zhihuMaxAnswers: resolved.zhihuMaxAnswers,
    zhihuMaxAnswerComments: resolved.zhihuMaxAnswerComments,
    bilibiliMaxComments: resolved.bilibiliMaxComments,
    bilibiliMaxReplyComments: resolved.bilibiliMaxReplyComments,
    bilibiliCookie: resolved.bilibiliCookie,
    embedOverrides: {
      apiKey: resolved.siliconflowKey || undefined,
      baseUrl: resolved.siliconflowBaseUrl || undefined,
      model: resolved.embeddingModel || undefined,
    },
  });

  // ---- bsk 探针（非阻塞）：缺失时提前告警，浏览器采集工具不可用 ----
  bskRunner
    .run(["status"], { timeoutMs: 10_000 })
    .then(
      () => {},
      (error: unknown) => {
        const detail = error instanceof Error ? error.message : String(error);
        if (isCommandNotFound(error)) {
          console.warn(`[${name}] ${bskInstallMessage(resolved.bskPath)}（${detail}）`);
        } else {
          console.warn(`[${name}] bsk 探针失败：${detail}`);
        }
      },
    );

  // ---- 卸载清理：停止会话池全部会话 + 杀掉在途子进程 + 落盘节流状态 ----
  ctx.effect(() => {
    return async () => {
      await pool.dispose();
      pacer.dispose();
      health.dispose();
    };
  }, "dsh-community-listening resources");
}
