/**
 * 条件等待（poll-until-ready）：用页面内 evaluate 探针替代「睡满固定时长 → 提取一次
 * → 失败再重试」。evaluate 是页面内本地调用，不产生额外网络足迹，不增加风控暴露。
 *
 * 语义：
 * - 立即首采（页面可能已就绪）；
 * - 未就绪每 intervalMs 再采，ready(result) 为真提前返回；
 * - 超时返回最后一次结果（调用方沿用现有 empty/error 语义）；
 * - evalFn 抛错视为未就绪，继续轮询；
 * - signal abort 立即退出（返回最后一次结果或 null）。
 */

export interface PollExtractOptions {
  /** 轮询间隔（毫秒，默认 600）。 */
  intervalMs?: number;
  /** 最大等待预算（毫秒）。预算取原最坏耗时，不缩短上限。 */
  maxMs: number;
  /** 中止信号：abort 立即退出。 */
  signal?: AbortSignal;
}

/**
 * 轮询执行 evalFn 直到 ready(result) 为真、超时或 signal abort。
 * 返回最后一次结果；一次都没拿到返回 null。
 */
export async function pollExtract<T>(
  evalFn: () => Promise<T>,
  ready: (result: T) => boolean,
  options: PollExtractOptions,
): Promise<T | null> {
  const { intervalMs = 600, maxMs, signal } = options;
  const deadline = Date.now() + maxMs;
  let last: T | null = null;
  for (;;) {
    if (signal?.aborted) return last;
    try {
      last = await evalFn();
      if (ready(last)) return last;
    } catch {
      // evalFn 抛错视为未就绪，继续轮询
    }
    if (Date.now() >= deadline) return last;
    await delay(intervalMs, signal); // abort 会中断睡眠，立即进入下一轮检查
  }
}

/** 等待页面 readyState === "complete"（导航后固定睡眠的替代；超时静默继续）。 */
export async function pollPageReady(
  probe: () => Promise<unknown>,
  options: PollExtractOptions,
): Promise<void> {
  await pollExtract(probe, (value) => value === "complete", options);
}

/** abort 可中断的延时：signal abort 时立即 resolve，让轮询循环立刻重查中止状态。 */
function delay(ms: number, signal?: AbortSignal): Promise<void> {
  if (signal?.aborted) return Promise.resolve(); // 已 abort：立即放行（不再注册监听）
  return new Promise((resolve) => {
    const onAbort = () => {
      clearTimeout(timer);
      resolve();
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}
