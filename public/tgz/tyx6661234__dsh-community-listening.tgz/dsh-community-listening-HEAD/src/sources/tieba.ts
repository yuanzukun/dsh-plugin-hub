/**
 * 百度贴吧采集通道（帖子回复/评论），浏览器路径（已验证）：
 *
 * 实测（2026-08，真实 bsk 会话）：
 * - tieba.baidu.com/p/{tid} 帖子页回复在 DOM 渲染（客户端渲染，SSR/PageData 不可用）。
 * - 回复项 DOM（新版）：`div.pb-comment-item`：
 *   - 作者：`a.name-info-link`（文本首 token，实测「接小程序网页软件开发」）
 *   - 内容：`div.pb-rich-text`（纯内容，实测「黑灰app?」）
 *   - 楼中楼：`.lzl-wrapper .pb-rich-text`（实测「即时通讯」「回复 帮大家启航 :可以做啊」）
 * - 楼中楼 API：`/p/totalComment?tid={tid}&pn={n}` 页面内 fetch 返回 JSON（errno:0，免签名）——
 *   用于补充楼中楼分页（当前 DOM 提取已含首屏楼中楼）。
 * - 后端直连贴吧 403（反爬）→ 浏览器路径。
 */

import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import { isBrowserUnavailable, type BrowserSessionPool, type SessionHandle } from "../collect";
import type { PlatformPacer } from "../pacing";
import type { CommentEntry } from "../types";
import { unwrapEvaluateValue } from "./zhihu";
import { pollPageReady } from "./wait";

export type TiebaOutcomeReason = "success" | "empty" | "login_wall" | "rate_limited" | "error";

export interface TiebaDeps {
  pool: BrowserSessionPool;
  pacer: PlatformPacer;
  /** 页面渲染等待（毫秒，默认 4000）。 */
  renderWaitMs?: number;
}

/** 从 URL 提取贴吧帖子 tid（/p/{tid}）。 */
export function extractTiebaTid(url: string): string | null {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host !== "tieba.baidu.com" && host !== "baidu.com") return null;
    const m = parsed.pathname.match(/^\/p\/(\d+)/);
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

/** 页面内提取帖子回复脚本（DOM：.pb-comment-item）。 */
export function buildTiebaCommentsScript(): string {
  return `(async () => {
  try {
    const out = [];
    const seen = new Set();
    const items = document.querySelectorAll(".pb-comment-item");
    for (const item of items) {
      const authorEl = item.querySelector(".name-info-link");
      const contentEl = item.querySelector(".pb-rich-text");
      const content = contentEl ? contentEl.innerText.replace(/\\s+/g, " ").trim() : "";
      if (!content || seen.has(content)) continue;
      seen.add(content);
      const author = authorEl ? authorEl.innerText.replace(/\\s+/g, " ").trim().split(/\\s+/)[0] : "";
      const replies = [];
      item.querySelectorAll(".lzl-wrapper .pb-rich-text").forEach((el) => {
        const t = el.innerText.replace(/\\s+/g, " ").trim();
        if (t && replies.length < 20) replies.push(String(t).slice(0, 20000));
      });
      out.push({
        author: String(author).slice(0, 40),
        content: String(content).slice(0, 20000),
        replies,
      });
    }
    return { ok: true, count: out.length, items: out };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 解析回复返回。 */
export function parseTiebaComments(value: unknown): { ok: boolean; items: CommentEntry[]; error?: string } {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const items = Array.isArray(v.items) ? v.items : [];
    return {
      ok: v.ok === true,
      items: items
        .map((it) => {
          if (!it || typeof it !== "object") return null;
          const c = it as Record<string, unknown>;
          const content = String(c.content ?? "").trim();
          if (!content) return null;
          return {
            author: String(c.author ?? ""),
            content,
            replies: Array.isArray(c.replies) ? c.replies.map((r) => String(r)).filter(Boolean) : [],
          };
        })
        .filter((c): c is CommentEntry => c !== null),
      error: typeof v.error === "string" ? v.error : undefined,
    };
  }
  return { ok: false, items: [] };
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function evalOn(
  handle: SessionHandle,
  exec: ToolRunContext,
  sessionId: string,
  script: string,
  label: string,
): Promise<unknown> {
  const raw = await handle.run(exec, ["evaluate", "--session", sessionId, script], label);
  return unwrapEvaluateValue(raw);
}

/**
 * 贴吧帖子回复采集（浏览器路径，DOM 提取）。
 */
export async function collectTiebaComments(
  deps: TiebaDeps,
  exec: ToolRunContext,
  url: string,
  opts: { maxComments?: number } = {},
): Promise<{ ok: boolean; reason: TiebaOutcomeReason; title: string; comments: CommentEntry[]; error?: string }> {
  const maxComments = Math.max(1, opts.maxComments ?? 100);
  const renderWait = deps.renderWaitMs ?? 4000;
  let handle: SessionHandle | null = null;
  try {
    handle = await deps.pool.acquire(exec);
    const sessionId = handle.sessionId;
    const run = (args: string[], label: string) => handle!.run(exec, args, label);

    let navError = "";
    try {
      await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", url], "tieba navigate");
    } catch (error) {
      if (isBrowserUnavailable(error)) throw error;
      navError = error instanceof Error ? error.message : String(error);
      await sleep(2000);
      try {
        await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", url], "tieba navigate retry");
      } catch (error2) {
        if (isBrowserUnavailable(error2)) throw error2;
        deps.pacer.record("tieba", "rate_limited", { reason: `navigate timeout: ${navError.slice(0, 120)}` });
        return { ok: false, reason: "rate_limited", title: "", comments: [], error: "贴吧导航超时（可能被风控挂起）：已进入平台冷却，稍后重试" };
      }
    }
    // 条件等待：页面 readyState=complete 即开始（页面内本地探针；预算 = 原 renderWait）
    await pollPageReady(
      async () => evalOn(handle!, exec, sessionId, `(async () => document.readyState)()`, "tieba ready"),
      { intervalMs: 600, maxMs: renderWait, signal: exec.signal },
    );

    const meta = await evalOn(handle, exec, sessionId, `(async () => ({ title: document.title.slice(0, 120) }))()`, "tieba title");
    const title = meta && typeof meta === "object" && !Array.isArray(meta)
      ? String((meta as Record<string, unknown>).title ?? "")
      : "";

    const raw = await evalOn(handle, exec, sessionId, buildTiebaCommentsScript(), "tieba comments");
    const parsed = parseTiebaComments(raw);
    if (!parsed.ok) {
      return { ok: false, reason: "error", title, comments: [], error: parsed.error ? `回复提取失败：${parsed.error}` : "回复提取失败" };
    }
    const comments = parsed.items.slice(0, maxComments);
    if (comments.length === 0) {
      return { ok: true, reason: "empty", title, comments: [], error: "帖子暂无回复或回复区未渲染" };
    }
    deps.pacer.reset("tieba");
    return { ok: true, reason: "success", title, comments };
  } catch (error) {
    return {
      ok: false,
      reason: "error",
      title: "",
      comments: [],
      error: `贴吧回复采集失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
    };
  } finally {
    handle?.release();
  }
}
