/**
 * 小红书采集通道（搜索卡片 + 笔记评论）。
 *
 * 实测约束（2026-08，真实 bsk 会话验证）：
 * - 未登录（无 web_session）时：搜索页首屏卡片（标题/作者/日期/互动数/noteId）可从
 *   DOM 稳定读取；笔记详情/评论需登录态 + xsec_token，匿名拿不到。
 * - 小红书对自动化访问风控极严：高频刷新/连续访问会重定向到安全验证 404。
 *   纪律（对齐 OpenBiliClaw 被动哲学）：单次访问不滚动、不点击、不刷新；
 *   命中风控立即触发平台冷却（指数退避）；登录墙只提示不冷却。
 * - bsk network 只给请求 URL 不给响应体 → 不依赖网络捕获；读已渲染 DOM 与页面 state。
 *
 * 端到端通道：
 * - 搜索卡片：navigate /search_result?keyword= → 读 DOM 卡片（标题/作者/noteId/互动数）
 * - 笔记评论：navigate /explore/{noteId} → 需登录；读 __INITIAL_STATE__ 评论（SSR）
 */

import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import { isBrowserUnavailable, type BrowserSessionPool, type SessionHandle } from "../collect";
import type { PlatformPacer } from "../pacing";
import type { CommentEntry } from "../types";
import { unwrapEvaluateValue } from "./zhihu";
import { pollExtract } from "./wait";

export type XhsOutcomeReason =
  | "success"
  | "empty"
  | "login_wall"
  | "rate_limited"
  | "error";

export interface XhsSearchCard {
  noteId: string;
  url: string;
  title: string;
  author: string;
  likeCount: number;
  commentCount: number;
  collectCount: number;
  /** 挖取到的 xsec_token（可传给 collect_comments 采评论；best-effort 可能为空）。 */
  xsecToken?: string;
}

export interface XhsDeps {
  pool: BrowserSessionPool;
  pacer: PlatformPacer;
  /** 页面渲染等待（毫秒，默认 4000）。 */
  renderWaitMs?: number;
}

export interface XhsSearchOptions {
  /** 最多返回多少张卡片（默认 20，首屏）。 */
  limit?: number;
}

export interface XhsLoginState {
  /** SSR/水合状态里嵌入了登录用户信息（真实会话信号；web_session 为 HttpOnly，document.cookie 永远读不到）。 */
  sessionUser: boolean;
  /** 会话用户 ID（sessionUser=true 时非空）。 */
  sessionUserId: string;
  /** 弱信号：页面存在 /user/profile/ 链接（搜索结果作者卡片同样会带，匿名也常见）。 */
  hasProfileLink: boolean;
  /** 弱信号：导航栏「发布」入口（匿名页面同样显示）。 */
  hasPublishEntry: boolean;
  /** 明确未登录：页面含「登录后查看…」等登录墙文案。 */
  loginWallText: boolean;
  /** document.cookie 能读到的 xiaohongshu.com 相关 cookie 名（不含 HttpOnly 的 web_session）。 */
  cookieNames: string[];
  /** 兼容保留：web_session 是 HttpOnly，document.cookie 永远读不到 → 恒为 false，请勿再据此判断登录。 */
  cookieHasWebSession: false;
  /** 综合登录判定：仅 sessionUser 确认时为 true（UI 弱信号不足以证明请求上下文携带登录态）。 */
  loggedIn: boolean;
}

export interface XhsSearchOutcome {
  ok: boolean;
  reason: XhsOutcomeReason;
  keyword: string;
  cards: XhsSearchCard[];
  /** 本次会话登录态检测结果（UI 信号 + cookie 启发式）。 */
  loginState?: XhsLoginState;
  /** 返回卡片中带 xsec_token 的数量（决定可采评论的笔记数）。 */
  cardsWithToken: number;
  /** token 命中率 = cardsWithToken / cards.length（0 表示没有卡片）。 */
  tokenHitRate: number;
  /** token 覆盖率低时的采样偏倚提示。 */
  biasHint?: string;
  error?: string;
}

/** 从 URL 提取小红书笔记 id（/explore/{id}、/discovery/item/{id}、/search_result/{id}）。 */
export function extractXhsNoteId(url: string): string | null {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host !== "xiaohongshu.com" && host !== "www.xiaohongshu.com") return null;
    const m = parsed.pathname.match(
      /\/(?:explore|discovery\/item|search_result)\/([0-9a-f]{24})/i,
    );
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

/** 从 URL 提取 xsec_token（笔记详情访问凭证，带 token 才能绕过 App 扫码墙）。 */
export function extractXhsToken(url: string): string {
  try {
    return new URL(url).searchParams.get("xsec_token") ?? "";
  } catch {
    return "";
  }
}

/**
 * 页面内挖 (noteId, xsec_token) 对：从 __INITIAL_STATE__ 与 Pinia store 里 harvest。
 * 两路采集（2026-08-15 强化，此前只采 URL 字符串导致漏掉独立 xsecToken 字段）：
 *   Pass A：URL 字符串（/explore/{id}?xsec_token=.. / /search_result/{id}?xsec_token=..）——原有路径；
 *   Pass B：独立 `xsecToken`/`xsec_token` 字段 + 同层/父层/noteCard 里的 noteId——SSR 与搜索 API
 *           返回的笔记对象多为 `{ noteId, xsecToken, noteCard: {...} }` 结构，token 不在 URL 里。
 */
export function buildXhsTokenMineScript(): string {
  return `(async () => {
  const found = { pairs: [] };
  const seen = new Set();
  const noteRe = /(?:explore|discovery\\/item|search_result)\\/([0-9a-f]{24})/i;
  const tokRe = /^xsec_?token$/i;
  const isId = (s) => typeof s === "string" && /^[0-9a-f]{24}$/i.test(s);
  const idFromUrl = (s) => { if (typeof s !== "string") return ""; const m = s.match(noteRe); return m ? m[1] : ""; };
  const addPair = (noteId, token) => {
    if (isId(noteId) && typeof token === "string" && token && !seen.has(noteId)) {
      seen.add(noteId);
      found.pairs.push({ noteId, xsecToken: token });
    }
  };
  const tryPick = (o) => {
    if (!o || typeof o !== "object") return "";
    for (const k of ["noteId", "note_id", "id", "url"]) {
      const val = o[k];
      if (k === "url") { const id = idFromUrl(val); if (id) return id; }
      else if (isId(val)) return val;
    }
    return "";
  };
  const findNoteId = (obj, parent, depth) => {
    let id = tryPick(obj) || tryPick(parent);
    // 深层结构（如 note.xsecToken + note.noteCard.noteId）：限 depth 浅扫 noteCard/card 分支
    if (!id && depth < 3 && obj && typeof obj === "object") {
      for (const [k, v] of Object.entries(obj)) {
        if (k === "noteCard" || k === "card" || /^note/i.test(k)) {
          id = tryPick(v);
          if (id) break;
        }
      }
    }
    return id;
  };
  const harvest = (obj, depth, parent) => {
    if (!obj || typeof obj !== "object" || depth > 12) return;
    for (const [k, v] of Object.entries(obj)) {
      if (tokRe.test(k) && typeof v === "string") {
        const noteId = findNoteId(obj, parent, depth);
        if (noteId) addPair(noteId, v);
      } else if (typeof v === "string") {
        const m = v.match(/(?:explore|discovery\\/item|search_result)\\/([0-9a-f]{24})[^"'&]*xsec_token=([^&"']+)/);
        if (m) addPair(m[1], decodeURIComponent(m[2]));
      } else if (typeof v === "object" && v !== null) {
        harvest(v, depth + 1, obj);
      }
    }
  };
  if (window.__INITIAL_STATE__) harvest(window.__INITIAL_STATE__, 0, null);
  for (const key of ["__PINIA__", "__pinia__", "$pinia", "pinia"]) {
    if (window[key]) harvest(window[key], 0, null);
  }
  return { ok: true, count: found.pairs.length, pairs: found.pairs.slice(0, 30) };
})()`;
}

/** 解析 token 挖掘结果。 */
export function parseXhsTokenMine(value: unknown): Array<{ noteId: string; xsecToken: string }> {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const pairs = Array.isArray(v.pairs) ? v.pairs : [];
    return pairs
      .map((p) => {
        if (!p || typeof p !== "object") return null;
        const it = p as Record<string, unknown>;
        const noteId = String(it.noteId ?? "");
        const xsecToken = String(it.xsecToken ?? "");
        if (!/^[0-9a-f]{24}$/i.test(noteId) || !xsecToken) return null;
        return { noteId, xsecToken };
      })
      .filter((p): p is { noteId: string; xsecToken: string } => p !== null);
  }
  return [];
}

/**
 * 风控 / 登录墙检测（对齐 OpenBiliClaw extension/src/content/xhs/risk-control.ts 文案）。
 * 返回：login_wall（登录墙，不冷却）/ security_verification / frequent_operation（触发冷却）。
 */
export type XhsRisk = "security_verification" | "frequent_operation" | "login_wall";

export function detectXhsRisk(text: string): XhsRisk | null {
  const hay = text.replace(/\s+/g, " ").trim().slice(0, 50_000);
  if (/登录后查看搜索结果|登录即可查看\s*(?:Ta\s*的)?笔记/i.test(hay)) return "login_wall";
  if (
    /安全验证|人机验证|异常访问|security verification/i.test(hay) &&
    /稍后(?:再试|重试)|请稍后|try again later|retry later/i.test(hay)
  ) {
    return "security_verification";
  }
  if (
    /请(?:勿|不要)频繁(?:操作|访问|请求)|(?:操作|请求|访问)(?:过于|太)?频繁|too many requests|\b429\b|risk control/i.test(
      hay,
    )
  ) {
    return "frequent_operation";
  }
  return null;
}

/**
 * 登录态检测脚本。
 *
 * 重要修正（2026-08-15 复盘）：`web_session` 是 HttpOnly cookie，`document.cookie` 永远读不到它——
 * 旧版 `cookieHasWebSession` 信号恒为 false，曾被误读为「自动化请求上下文未带登录态 / 双轨评分」。
 * 真实信号改用：
 *   1. `__INITIAL_STATE__` 水合状态里嵌入的登录用户（userId）——由服务端按请求上下文（含 web_session）渲染；
 *   2. 登录墙文案（「登录后查看…」）——明确未登录/降权；
 *   3. 弱 UI 信号（作者卡片 profile 链接、导航「发布」入口）仅作旁证，不能证明登录。
 */
export function buildXhsLoginStateScript(): string {
  return `(async () => {
  const c = document.cookie;
  const cookieNames = c.split(";").map((s) => s.split("=")[0].trim()).filter(Boolean);
  const bodyText = (document.body.innerText || "").slice(0, 3000);
  const hasProfileLink = !!document.querySelector('a[href*="/user/profile/"]');
  const hasPublishEntry = /发布/.test(bodyText) && /我/.test(bodyText);
  const loginWallText = /登录后查看|登录即可查看|请先登录|登录或注册|扫码登录/.test(bodyText);
  let sessionUser = false;
  let sessionUserId = "";
  try {
    const s = window.__INITIAL_STATE__;
    const pick = (u) => {
      if (!u || typeof u !== "object") return "";
      return String(u.userId || u.user_id || u.id || "");
    };
    if (s && typeof s === "object") {
      const user = s.user || s.currentUser || s.userInfo || null;
      const info = user && typeof user === "object" ? user.userInfo || user : null;
      const id = pick(info) || pick(user);
      if (typeof id === "string" && id.length >= 4) {
        sessionUser = true;
        sessionUserId = id;
      }
    }
  } catch { /* 解析失败不阻断 */ }
  return {
    sessionUser,
    sessionUserId,
    hasProfileLink,
    hasPublishEntry,
    loginWallText,
    cookieNames: cookieNames.slice(0, 60),
    cookieHasWebSession: false,
    loggedIn: sessionUser,
  };
})()`;
}

/** 解析登录态检测脚本返回。 */
export function parseXhsLoginState(value: unknown): XhsLoginState {
  const empty: XhsLoginState = {
    sessionUser: false,
    sessionUserId: "",
    hasProfileLink: false,
    hasPublishEntry: false,
    loginWallText: false,
    cookieNames: [],
    cookieHasWebSession: false,
    loggedIn: false,
  };
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const sessionUser = v.sessionUser === true;
    return {
      sessionUser,
      sessionUserId: typeof v.sessionUserId === "string" ? v.sessionUserId : "",
      hasProfileLink: v.hasProfileLink === true,
      hasPublishEntry: v.hasPublishEntry === true,
      loginWallText: v.loginWallText === true,
      cookieNames: Array.isArray(v.cookieNames) ? v.cookieNames.map(String).slice(0, 60) : [],
      cookieHasWebSession: false,
      loggedIn: sessionUser,
    };
  }
  return empty;
}

/** 页面内读搜索卡片脚本（单次遍历，不滚动不点击；链接自带 xsec_token 时直接提取）。 */
export function buildXhsSearchCardsScript(): string {
  return `(async () => {
  try {
    const pickCount = (text, units) => {
      for (const unit of units) {
        const m = text.match(new RegExp("(\\\\d+(?:\\\\.\\\\d+)?)\\\\s*" + unit, "i"));
        if (m) return Number(m[1]);
      }
      return 0;
    };
    const anchors = Array.from(document.querySelectorAll('a[href*="/explore/"], a[href*="/discovery/item/"], a[href*="/search_result/"]'));
    const seen = new Set();
    const out = [];
    for (const a of anchors) {
      const href = a.getAttribute("href") || "";
      let u;
      try { u = new URL(href, location.href); } catch { continue; }
      const seg = (u.pathname.split("/").filter(Boolean).pop() || "");
      if (!/^[0-9a-f]{24}$/i.test(seg)) continue;
      if (seen.has(seg)) continue;
      seen.add(seg);
      const tokenM = href.match(/[?&]xsec_token=([^&]+)/);
      let xsecToken = tokenM ? decodeURIComponent(tokenM[1]) : "";
      const container = a.closest(".note-item, section, [class*='note'], [class*='card']") || a;
      // 兜底：卡片/链接上的 data-xsec-token 属性（部分渲染版本 token 不在 href 里）
      if (!xsecToken) {
        const attr = (el) => (el ? el.getAttribute("data-xsec-token") || el.getAttribute("data-xsec_token") || "" : "");
        xsecToken = attr(container) || attr(a) || "";
      }
      const titleEl = container.querySelector(".title, .note-title, [class*='title'] span, [class*='title']");
      const authorEl = container.querySelector(".author-wrapper .name, .author .name, .user-name, [class*='author'] .name, .nickname");
      const title = (titleEl ? titleEl.textContent : "") || a.title || "";
      const author = authorEl ? authorEl.textContent : "";
      const text = (container.innerText || "").replace(/\\s+/g, " ").trim();
      out.push({
        noteId: seg,
        url: u.origin + u.pathname,
        title: String(title).trim().slice(0, 120),
        author: String(author).trim().slice(0, 40),
        likeCount: pickCount(text, ["赞", "点赞", "like"]),
        commentCount: pickCount(text, ["评论", "comment"]),
        collectCount: pickCount(text, ["收藏", "collect"]),
        ...(xsecToken ? { xsecToken } : {}),
      });
    }
    return { ok: true, count: out.length, items: out };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 解析 evaluate 返回的卡片负载。 */
export function parseXhsSearchCards(value: unknown): {
  ok: boolean;
  items: XhsSearchCard[];
  error?: string;
} {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const items = Array.isArray(v.items) ? v.items : [];
    return {
      ok: v.ok === true,
      items: items
        .map((it) => {
          if (!it || typeof it !== "object") return null;
          const c = it as Record<string, unknown>;
          const noteId = String(c.noteId ?? "");
          if (!/^[0-9a-f]{24}$/i.test(noteId)) return null;
          return {
            noteId,
            url: String(c.url ?? ""),
            title: String(c.title ?? ""),
            author: String(c.author ?? ""),
            likeCount: Number(c.likeCount) || 0,
            commentCount: Number(c.commentCount) || 0,
            collectCount: Number(c.collectCount) || 0,
            ...(typeof c.xsecToken === "string" && c.xsecToken ? { xsecToken: c.xsecToken } : {}),
          };
        })
        .filter((c): c is XhsSearchCard => c !== null),
      error: typeof v.error === "string" ? v.error : undefined,
    };
  }
  return { ok: false, items: [], error: "evaluate 返回非对象" };
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function evalOn(
  handle: SessionHandle,
  exec: ToolRunContext,
  sessionId: string,
  script: string,
  label: string,
): Promise<unknown> {
  const raw = await handle.run(exec, ["evaluate", "--session", sessionId, script], label);
  return unwrapEvaluateValue(raw); // bsk evaluate 包装 {ok, tab_id, value} → 取 value
}

/**
 * 小红书搜索卡片采集（匿名可用；单次访问，命中风控即冷却）。
 */
export async function collectXiaohongshuSearch(
  deps: XhsDeps,
  exec: ToolRunContext,
  keyword: string,
  opts: XhsSearchOptions = {},
): Promise<XhsSearchOutcome> {
  return deps.pacer.runExclusive("xiaohongshu", async () => {
  const limit = Math.max(1, opts.limit ?? 20);
  const renderWait = deps.renderWaitMs ?? 4000;
  const noTokenDiag = () => ({ cardsWithToken: 0, tokenHitRate: 0 });
  let handle: SessionHandle | null = null;
  try {
    try {
      handle = await deps.pool.acquire(exec);
    } catch (error) {
      return {
        ok: false,
        reason: "error",
        keyword,
        cards: [],
        ...noTokenDiag(),
        error: `浏览器会话不可用：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
      };
    }
    const sessionId = handle.sessionId;
    const run = (args: string[], label: string) => handle!.run(exec, args, label);

    const q = encodeURIComponent(keyword.trim());
    // domcontentloaded 即读 DOM（小红书 load 事件慢/被风控时易超时）；失败重试一次。
    // 小红书对自动化访问的典型表现就是导航挂起/超时 → 视为风控信号触发冷却。
    const navUrl = `https://www.xiaohongshu.com/search_result?keyword=${q}`;
    let navError = "";
    try {
      await run(
        ["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", navUrl],
        "xhs search navigate",
      );
    } catch (error) {
      if (isBrowserUnavailable(error)) {
        return {
          ok: false,
          reason: "error",
          keyword,
          cards: [],
          ...noTokenDiag(),
          error: `浏览器不可用：${error instanceof Error ? error.message : String(error)}`,
        };
      }
      navError = error instanceof Error ? error.message : String(error);
      await sleep(2000);
      try {
        await run(
          ["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", navUrl],
          "xhs search navigate retry",
        );
      } catch (error2) {
        if (isBrowserUnavailable(error2)) {
          return {
            ok: false,
            reason: "error",
            keyword,
            cards: [],
            ...noTokenDiag(),
            error: `浏览器不可用：${error2 instanceof Error ? error2.message : String(error2)}`,
          };
        }
        // 导航连续失败：小红书风控挂起 → 平台冷却（浏览器基础设施失败不在此列）
        deps.pacer.record("xiaohongshu", "rate_limited", { reason: `navigate timeout: ${navError.slice(0, 120)}` });
        return {
          ok: false,
          reason: "rate_limited",
          keyword,
          cards: [],
          ...noTokenDiag(),
          error: `小红书导航超时（${navError.slice(0, 160)}），疑似风控挂起：已进入平台冷却，稍后重试。若页面实际显示验证码/登录，可改用 browser_request_help 人工过卡。若反复导航挂起，仅重登/换号无效——信任评分挂在 a1/webId 设备指纹上，需清除 xiaohongshu.com 站点 Cookie（轮换指纹）或换浏览器 profile / IP`,
        };
      }
    }
    // 条件等待：搜索卡片就绪即开始（预算 = renderWait + 2000 ≥ 原固定等待）；
    // 风控/登录墙页面拿不到卡片 → 轮询超时后由下方 risk 检测兜底
    const cardsParsed = await pollExtract(
      async () =>
        parseXhsSearchCards(
          await evalOn(handle!, exec, sessionId, buildXhsSearchCardsScript(), "xhs cards"),
        ),
      (p) => p.items.length > 0,
      { intervalMs: 600, maxMs: renderWait + 2000, signal: exec.signal },
    );

    // 风控/登录墙检测（页面文本）
    const pageText = await evalOn(
      handle,
      exec,
      sessionId,
      `(async () => ({ text: (document.body.innerText || "").slice(0, 60000) }))()`,
      "xhs page text",
    );
    const text =
      pageText && typeof pageText === "object" && !Array.isArray(pageText)
        ? String((pageText as Record<string, unknown>).text ?? "")
        : "";
    const risk = detectXhsRisk(text);
    if (risk === "security_verification" || risk === "frequent_operation") {
      deps.pacer.record("xiaohongshu", "rate_limited", { reason: risk });
      return {
        ok: false,
        reason: "rate_limited",
        keyword,
        cards: [],
        ...noTokenDiag(),
        error: `小红书风控拦截（${risk}）：已进入平台冷却，稍后重试；冷却结束后建议降频多轮（每轮 1 次搜索）。若反复被拦，仅重登/换号无效——需清除 xiaohongshu.com 站点 Cookie（轮换 a1/webId 设备指纹）或换 IP / 浏览器 profile`,
      };
    }
    if (risk === "login_wall") {
      return {
        ok: false,
        reason: "login_wall",
        keyword,
        cards: [],
        ...noTokenDiag(),
        error: "小红书要求登录后查看搜索结果（请在浏览器登录小红书后重试，或调用 browser_request_help 请用户完成登录）",
      };
    }

    // 登录态检测（token 命中率的前置因子；纯只读，无额外网络请求）
    let loginState: XhsLoginState | undefined;
    try {
      const rawLogin = await evalOn(handle, exec, sessionId, buildXhsLoginStateScript(), "xhs login state");
      loginState = parseXhsLoginState(rawLogin);
    } catch {
      // 登录态检测失败不阻断
    }

    const parsed = cardsParsed ?? { ok: false, items: [], error: undefined };
    if (!parsed.ok) {
      return {
        ok: false,
        reason: "error",
        keyword,
        cards: [],
        ...noTokenDiag(),
        error: parsed.error ? `卡片解析失败：${parsed.error}` : "卡片解析失败",
      };
    }
    if (parsed.items.length === 0) {
      return {
        ok: true,
        reason: "empty",
        keyword,
        cards: [],
        ...noTokenDiag(),
        error: "搜索页未渲染笔记卡片（可能被风控或关键词无结果）",
      };
    }

    // 顺带挖 xsec_token（best-effort）：搜索页 state 里带 token 的笔记 URL / 独立 xsecToken 字段
    // → 填充卡片，让搜索结果卡片可直接采评论。挖不到不影响卡片返回。
    const cards = parsed.items.slice(0, limit);
    try {
      // 条件等待：SPA 搜索请求首屏后异步完成（pinia 水合），轮询直到挖到 token
      // （预算 = renderWait × 2，等价原两轮重试上限）
      const pairs = (await pollExtract(
        async () =>
          parseXhsTokenMine(
            await evalOn(handle!, exec, sessionId, buildXhsTokenMineScript(), "xhs token mine"),
          ),
        (p) => p.length > 0,
        { intervalMs: 600, maxMs: renderWait * 2, signal: exec.signal },
      )) ?? [];
      if (pairs.length > 0) {
        const tokenByNoteId = new Map(pairs.map((p) => [p.noteId, p.xsecToken]));
        for (const card of cards) {
          const token = tokenByNoteId.get(card.noteId);
          if (token) card.xsecToken = token;
        }
      }
    } catch {
      // 挖 token 失败不阻断卡片返回
    }

    const cardsWithToken = cards.filter((c) => c.xsecToken).length;
    const tokenHitRate = cards.length > 0 ? cardsWithToken / cards.length : 0;
    const login = loginState?.loggedIn === true;
    const wall = loginState?.loginWallText === true;
    const weakOnly =
      loginState !== undefined &&
      !loginState.sessionUser &&
      (loginState.hasProfileLink || loginState.hasPublishEntry);
    const biasHint =
      cardsWithToken === 0
        ? login
          ? "本次返回卡片均无 xsec_token，无法进入评论采集；已确认登录态仍无 token，说明服务端对该请求指纹降权，建议冷却后换关键词或错峰再试"
          : `本次返回卡片均无 xsec_token，无法进入评论采集。${wall ? "页面出现登录墙文案（登录后查看）" : weakOnly ? "页面仅有弱 UI 信号（作者卡片链接/发布按钮，匿名页面同样存在），未确认登录" : "未确认登录"}——web_session 是 HttpOnly 无法从页面读取，请确认登录发生在插件自动化会话（Agent Window）对应的 Chrome 默认 profile，然后重试`
        : tokenHitRate < 0.5
          ? `仅 ${cardsWithToken}/${cards.length} 张卡片带 xsec_token（命中率 ${Math.round(tokenHitRate * 100)}%），可采评论样本存在选择偏倚。${login ? "已确认登录态仍低命中 → 服务端对该请求指纹降权（非账号问题），换关键词/错峰再试" : wall ? "页面为登录墙态" : weakOnly ? "登录态未确认（弱 UI 信号不足为凭，匿名同样显示作者链接与发布按钮）" : "登录态未确认"}；确认登录在插件自动化会话后命中率通常显著提高`
          : undefined;

    deps.pacer.reset("xiaohongshu");
    return {
      ok: true,
      reason: "success",
      keyword,
      cards,
      ...(loginState ? { loginState } : {}),
      cardsWithToken,
      tokenHitRate,
      ...(biasHint ? { biasHint } : {}),
    };
  } catch (error) {
    return {
      ok: false,
      reason: "error",
      keyword,
      cards: [],
      ...noTokenDiag(),
      error: `小红书采集失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
    };
  } finally {
    handle?.release();
  }
  });
}

/** 页面内读小红书评论 state（__INITIAL_STATE__.note.noteDetailMap）。 */
export function buildXhsCommentsStateScript(): string {
  return `(async () => {
    const s = window.__INITIAL_STATE__;
    const map = (s && s.note && s.note.noteDetailMap) || {};
    const keys = Object.keys(map).filter((k) => k && k !== "undefined");
    const out = [];
    let title = "";
    let hasMore = false;
    for (const k of keys) {
      const d = map[k] || {};
      const note = d.note || {};
      if (!title) title = String(note.title || "");
      if (d.comments && d.comments.hasMore === true) hasMore = true;
      const list = (d.comments && Array.isArray(d.comments.list)) ? d.comments.list : [];
      for (const c of list.slice(0, 200)) {
        if (!c || typeof c !== "object") continue;
        const content = typeof c.content === "string" ? c.content : "";
        if (!content) continue;
        const nick = c.user && typeof c.user === "object" ? c.user.nickname : "";
        out.push({ author: String(nick || ""), content });
      }
    }
    return { title, hasMore, count: out.length, items: out };
  })()`;
}

/** 解析小红书评论 state 返回。 */
export function parseXhsCommentsState(value: unknown): {
  title: string;
  hasMore: boolean;
  items: Array<{ author: string; content: string }>;
} {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const items = Array.isArray(v.items) ? (v.items as Array<Record<string, unknown>>) : [];
    return {
      title: typeof v.title === "string" ? v.title : "",
      hasMore: v.hasMore === true,
      items: items
        .map((c) => ({ author: String(c.author ?? ""), content: String(c.content ?? "") }))
        .filter((c) => c.content.trim().length > 0),
    };
  }
  return { title: "", hasMore: false, items: [] };
}

/** 页面内尝试展开/加载更多评论：点击“加载更多/展开/点击评论”等按钮，并滚动到底部。 */
export function buildXhsExpandCommentsScript(): string {
  return `(async () => {
    const clicked = [];
    const els = Array.from(document.querySelectorAll("span, div, button, section"));
    for (const el of els) {
      const t = (el.innerText || el.textContent || "").trim();
      if (!t || t.length > 30) continue;
      if (/^(加载更多|查看更多评论|展开|点击评论|查看全部评论)/.test(t)) {
        try {
          el.scrollIntoView({ block: "center" });
          el.click();
          clicked.push(t.slice(0, 30));
          if (clicked.length >= 3) break;
        } catch {}
      }
    }
    window.scrollTo(0, document.body.scrollHeight);
    return { ok: true, clicked };
  })()`;
}

/**
 * 小红书笔记评论采集（生产路径，已验证）：
 * 1. xsec_token 是绕过 App 扫码墙（300031）的钥匙——从首页/搜索页 state 挖取，或从 URL 直接提供。
 * 2. 带 token 导航详情页 → 页面自带 x-s 签名请求 → 读 __INITIAL_STATE__ 评论（SSR 首屏）。
 * 3. 首屏评论不足/有 hasMore 时自动滚动 + 点击加载更多，尽量补足评论样本。
 * 未登录时返回 login_wall；无 token 时返回提示（先访问首页挖 token 或提供带 token 的笔记 URL）。
 */
export async function collectXiaohongshuNoteComments(
  deps: XhsDeps,
  exec: ToolRunContext,
  noteId: string,
  opts: { maxComments?: number; xsecToken?: string } = {},
): Promise<{ ok: boolean; reason: XhsOutcomeReason; title: string; comments: CommentEntry[]; error?: string }> {
  const maxComments = Math.max(1, opts.maxComments ?? 100);
  const renderWait = deps.renderWaitMs ?? 4000;
  let handle: SessionHandle | null = null;
  try {
    handle = await deps.pool.acquire(exec);
    const sessionId = handle.sessionId;
    const run = (args: string[], label: string) => handle!.run(exec, args, label);

    // 1) 确定 xsec_token：URL 提供 → 直接用；否则访问首页挖 token 表
    let token = opts.xsecToken ?? "";
    if (!token) {
      try {
        await run(
          ["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", "https://www.xiaohongshu.com/explore"],
          "xhs token mine navigate",
        );
      } catch (error) {
        if (isBrowserUnavailable(error)) {
          return { ok: false, reason: "error", title: "", comments: [], error: `浏览器不可用：${error instanceof Error ? error.message : String(error)}` };
        }
        // 首页导航失败（风控挂起）→ 冷却（浏览器基础设施失败不在此列）
        deps.pacer.record("xiaohongshu", "rate_limited", { reason: "token mine navigate timeout" });
        return { ok: false, reason: "rate_limited", title: "", comments: [], error: "小红书导航超时（风控挂起）：已进入平台冷却，稍后重试" };
      }
      // 条件等待：推荐流可能延迟加载，轮询挖 token 直到命中（预算 = renderWait × 2，
      // 等价原「等一轮 + 再挖一轮」的上限）
      const pairs = (await pollExtract(
        async () =>
          parseXhsTokenMine(
            await evalOn(handle!, exec, sessionId, buildXhsTokenMineScript(), "xhs token mine"),
          ),
        (p) => p.length > 0,
        { intervalMs: 600, maxMs: renderWait * 2, signal: exec.signal },
      )) ?? [];
      const match = pairs.find((p) => p.noteId === noteId);
      if (match) {
        token = match.xsecToken;
      } else {
        return {
          ok: false,
          reason: "error",
          title: "",
          comments: [],
          error: `未在首页推荐流中找到该笔记（${noteId}）的 xsec_token：请先访问小红书首页/搜索页让推荐流加载，或直接提供带 ?xsec_token= 的笔记 URL（收藏/分享链接）`,
        };
      }
    }

    // 2) 带 token 导航详情页（页面自带签名请求，绕过 App 扫码墙）
    const navUrl = `https://www.xiaohongshu.com/explore/${noteId}?xsec_token=${encodeURIComponent(token)}&xsec_source=pc_feed`;
    try {
      await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", navUrl], "xhs note navigate");
    } catch {
      await sleep(2000);
      await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", navUrl], "xhs note navigate retry");
    }
    // 条件等待：noteDetailMap 非空 或 出现登录墙文案 即就绪（预算 = 原 renderWait）
    await pollExtract(
      async () => {
        const raw = await evalOn(handle!, exec, sessionId, `(async () => {
          const s = window.__INITIAL_STATE__;
          const map = (s && s.note && s.note.noteDetailMap) || {};
          const keys = Object.keys(map).filter((k) => k && k !== "undefined");
          const wall = /登录后查看|登录即可查看|请先登录|扫码查看/.test((document.body.innerText || "").slice(0, 40000));
          return { hasNote: keys.length > 0, wall };
        })()`, "xhs note ready probe");
        const v = raw && typeof raw === "object" && !Array.isArray(raw)
          ? (raw as Record<string, unknown>)
          : {};
        return v;
      },
      (p) => p.hasNote === true || p.wall === true,
      { intervalMs: 600, maxMs: renderWait, signal: exec.signal },
    );

    // 登录 + 风控检测（web_session 是 HttpOnly，document.cookie 读不到 → 用 SSR 水合用户 + UI 信号）
    const state = await evalOn(handle, exec, sessionId, `(async () => {
      const text = (document.body.innerText || "").slice(0, 40000);
      const hasProfileLink = !!document.querySelector('a[href*="/user/profile/"]');
      let sessionUser = false;
      try {
        const s = window.__INITIAL_STATE__;
        const u = s && typeof s === "object" ? (s.user || s.currentUser || s.userInfo || null) : null;
        const info = u && typeof u === "object" ? (u.userInfo || u) : null;
        const id = info && typeof info === "object" ? (info.userId || info.user_id || info.id || "") : "";
        sessionUser = typeof id === "string" && id.length >= 4;
      } catch {}
      const wall = /登录后查看|登录即可查看|请先登录/.test(text);
      return {
        text,
        sessionUser,
        loggedIn: sessionUser || (hasProfileLink && !wall),
        url: location.href.slice(0, 150),
      };
    })()`, "xhs note state");
    const st = state && typeof state === "object" && !Array.isArray(state)
      ? (state as Record<string, unknown>)
      : {};
    const text = String(st.text ?? "");
    const loggedIn = st.loggedIn === true;
    const risk = detectXhsRisk(text);
    if (risk === "security_verification" || risk === "frequent_operation") {
      deps.pacer.record("xiaohongshu", "rate_limited", { reason: risk });
      return { ok: false, reason: "rate_limited", title: "", comments: [], error: `小红书风控拦截（${risk}）` };
    }
    // App 扫码墙（token 失效/过期时会回到 300031）
    if (/当前笔记暂时无法浏览|请打开小红书App扫码查看|扫码查看/i.test(text)) {
      return {
        ok: false,
        reason: "error",
        title: "",
        comments: [],
        error: "小红书笔记详情仍被 App 扫码墙拦截（xsec_token 可能已过期）：请重新访问小红书首页生成新 token 后重试",
      };
    }
    if (!loggedIn) {
      return {
        ok: false,
        reason: "login_wall",
        title: "",
        comments: [],
        error: "小红书笔记详情/评论需登录（请在浏览器登录小红书后重试；未登录可用 collect_xhs_search 采集搜索卡片）",
      };
    }

    // 3) 读 __INITIAL_STATE__ 评论（SSR 首屏；页面自带签名）
    const cs = parseXhsCommentsState(
      await evalOn(handle, exec, sessionId, buildXhsCommentsStateScript(), "xhs comments state"),
    );
    let title = cs.title;
    let comments: CommentEntry[] = cs.items
      .slice(0, maxComments)
      .map((c) => ({ author: c.author, content: c.content, replies: [] }));
    let hasMore = cs.hasMore;

    // 4) 首屏评论不足时自动滚动 + 点击“加载更多/展开/点击评论”，补足评论样本
    if (comments.length < maxComments && (hasMore || comments.length === 0)) {
      for (let round = 0; round < 3 && comments.length < maxComments; round += 1) {
        try {
          await evalOn(handle, exec, sessionId, buildXhsExpandCommentsScript(), "xhs expand comments");
          await sleep(1200);
          const next = parseXhsCommentsState(
            await evalOn(handle, exec, sessionId, buildXhsCommentsStateScript(), "xhs comments state after expand"),
          );
          if (next.title) title = next.title;
          hasMore = next.hasMore;
          const seen = new Set(comments.map((c) => `${c.author}\u0000${c.content}`));
          for (const it of next.items) {
            const key = `${it.author}\u0000${it.content}`;
            if (seen.has(key)) continue;
            seen.add(key);
            comments.push({ author: it.author, content: it.content, replies: [] });
            if (comments.length >= maxComments) break;
          }
        } catch {
          // 单轮展开失败不阻断；已拿到的评论继续返回
        }
        if (comments.length > 0 && !hasMore) break;
      }
    }
    comments = comments.slice(0, maxComments);

    if (comments.length === 0) {
      return {
        ok: true,
        reason: "empty",
        title,
        comments: [],
        error: "笔记无评论或评论未加载（已尝试自动滚动/展开，仍无评论）",
      };
    }
    deps.pacer.reset("xiaohongshu");
    return { ok: true, reason: "success", title, comments };
  } catch (error) {
    return {
      ok: false,
      reason: "error",
      title: "",
      comments: [],
      error: `小红书评论采集失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
    };
  } finally {
    handle?.release();
  }
}
