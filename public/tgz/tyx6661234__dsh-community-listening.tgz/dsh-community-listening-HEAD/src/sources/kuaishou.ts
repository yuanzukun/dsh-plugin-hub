/**
 * 快手采集通道（视频评论），浏览器路径（已验证）：
 *
 * 实测（2026-08，真实 bsk 会话）：
 * - 分享链接 /f/{id} navigate 后重定向到 /short-video/{photoId}，视频页完整渲染（含评论）。
 * - 评论 API（无签名）：POST /rest/v/photo/comment/list  body={photoId, pcursor}
 *   → { result:1, rootCommentsV2[], pcursorV2, commentCountV2 }（pcursorV2 ""→下一页，"no_more" 结束）
 * - 子评论：POST /rest/v/photo/comment/sublist  body={photoId, pcursor, rootCommentId}
 *   → subCommentsV2（对齐 MediaCrawler kuaishou/client.py）
 * - 错误：result:2 服务端限流、result:50 拒绝（需签名）→ 触发 kuaishou 平台冷却。
 *
 * 与微博/抖音同构：navigate 视频页（自动带 cookie）→ 页面内 fetch 评论 API。
 */

import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import { isBrowserUnavailable, type BrowserSessionPool, type SessionHandle } from "../collect";
import type { PlatformPacer } from "../pacing";
import type { CommentEntry } from "../types";
import { unwrapEvaluateValue } from "./zhihu";
import { pollExtract, pollPageReady } from "./wait";

export type KuaishouOutcomeReason = "success" | "empty" | "login_wall" | "rate_limited" | "error";

export interface KuaishouDeps {
  pool: BrowserSessionPool;
  pacer: PlatformPacer;
  /** 页面渲染等待（毫秒，默认 4000）。 */
  renderWaitMs?: number;
}

/** 从 URL 提取快手视频 photoId（/short-video/{id}、/f/{id}）。 */
export function extractPhotoId(url: string): string | null {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host !== "kuaishou.com" && host !== "www.kuaishou.com" && host !== "v.kuaishou.com") return null;
    const m = parsed.pathname.match(/^\/(?:short-video|f)\/([A-Za-z0-9-]+)/);
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// 搜索页卡片发现（2026-08-15 实测）：
// - 搜索页为 SPA，卡片是 <button>（无 href），复制链接/点击跳转均不可靠。
// - 但页面水合后的 window.INIT_STATE 包含 search.feed 响应：
//   对任意 { feeds: [...] } 值，feeds[].photo.id 即 photoId，author.name 即作者，
//   photo.caption / likeCount / viewCount 可直接读 —— 无需逆向签名、无需点击。
// - DOM 兜底：封面图 URL 的 clientCacheKey=<photoId>（与 photo.id 一致）。
// ---------------------------------------------------------------------------

export interface KuaishouSearchCard {
  photoId: string;
  url: string;
  title: string;
  author: string;
  likeCount: number;
  viewCount: number;
}

export type KuaishouSearchOutcomeReason = "success" | "empty" | "rate_limited" | "error";

export interface KuaishouSearchOutcome {
  ok: boolean;
  reason: KuaishouSearchOutcomeReason;
  cards: KuaishouSearchCard[];
  error?: string;
}

/** 构造快手视频搜索页 URL（结果页走 search.feed，首屏约 20 条）。 */
export function buildKuaishouSearchUrl(keyword: string): string {
  return `https://www.kuaishou.com/search/video?searchKey=${encodeURIComponent(keyword)}`;
}

/** 页面内提取搜索卡片：INIT_STATE.search.feed 优先，DOM clientCacheKey 兜底。 */
export function buildKuaishouSearchExtractScript(): string {
  return `(async () => {
  const cards = [];
  const seen = new Set();
  const push = (photoId, title, author, likeCount, viewCount) => {
    const id = String(photoId || "").trim();
    if (!id || seen.has(id)) return;
    seen.add(id);
    cards.push({
      photoId: id,
      url: "https://www.kuaishou.com/short-video/" + id,
      title: String(title || "").slice(0, 500),
      author: String(author || "").slice(0, 120),
      likeCount: Number(likeCount) || 0,
      viewCount: Number(viewCount) || 0,
    });
  };
  try {
    const state = window.INIT_STATE || {};
    for (const value of Object.values(state)) {
      const feeds = value && typeof value === "object" && Array.isArray(value.feeds) ? value.feeds : [];
      for (const f of feeds) {
        if (!f || typeof f !== "object") continue;
        const p = f.photo && typeof f.photo === "object" ? f.photo : {};
        const a = f.author && typeof f.author === "object" ? f.author : {};
        push(p.id, p.caption, a.name, p.likeCount, p.viewCount);
      }
    }
  } catch (e) {}
  if (cards.length === 0) {
    document.querySelectorAll(".card-container").forEach((el) => {
      const img = el.querySelector("img");
      const src = img && (img.currentSrc || img.src) ? (img.currentSrc || img.src) : "";
      const m = src.match(/clientCacheKey=([A-Za-z0-9_-]+)/);
      if (!m) return;
      const title = (el.querySelector(".caption") || el.querySelector("[class*=caption]") || {}).innerText || "";
      const author = (el.querySelector(".name") || {}).innerText || "";
      const like = (el.querySelector("[class*=like]") || {}).innerText || "";
      const likeNum = Number(String(like).replace(/[^0-9.]/g, "")) || 0;
      push(m[1], title, author, likeNum, 0);
    });
  }
  return { ok: true, url: location.href, title: document.title, count: cards.length, cards };
})()`;
}

/** 防御性解析搜索提取脚本返回。 */
export function parseKuaishouSearchCards(value: unknown): KuaishouSearchCard[] {
  let cards: unknown[] = [];
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    cards = Array.isArray(v.cards) ? v.cards : [];
  }
  const out: KuaishouSearchCard[] = [];
  for (const raw of cards) {
    if (!raw || typeof raw !== "object") continue;
    const c = raw as Record<string, unknown>;
    const photoId = String(c.photoId ?? "").trim();
    if (!photoId) continue;
    out.push({
      photoId,
      url: String(c.url ?? `https://www.kuaishou.com/short-video/${photoId}`),
      title: String(c.title ?? ""),
      author: String(c.author ?? ""),
      likeCount: Number(c.likeCount) || 0,
      viewCount: Number(c.viewCount) || 0,
    });
  }
  return out;
}

/** 评论 API 页面内 fetch 脚本（POST，无签名）。 */
export function buildKuaishouCommentsScript(photoId: string, pcursor: string): string {
  const pc = JSON.stringify(pcursor ?? "");
  return `(async () => {
  try {
    const res = await fetch("/rest/v/photo/comment/list", {
      method: "POST",
      credentials: "include",
      headers: { "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify({ photoId: ${JSON.stringify(photoId)}, pcursor: ${pc} }),
    });
    if (!res.ok) return { ok: false, status: res.status };
    const j = await res.json();
    if (j.result !== 1) return { ok: false, result: j.result };
    const list = Array.isArray(j.rootCommentsV2) ? j.rootCommentsV2 : [];
    const out = [];
    for (const c of list) {
      if (!c || typeof c !== "object") continue;
      const content = typeof c.content === "string" ? c.content : "";
      if (!content) continue;
      out.push({
        commentId: String(c.comment_id ?? c.commentId ?? ""),
        author: String(c.author_name ?? c.userName ?? c.user_name ?? ""),
        content: String(content).slice(0, 20000),
        likeCount: Number(c.likeCount) || 0,
        hasSubComments: c.hasSubComments === true,
      });
    }
    return {
      ok: true,
      count: out.length,
      items: out,
      pcursor: String(j.pcursorV2 ?? ""),
      total: Number(j.commentCountV2) || 0,
    };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 子评论 API 页面内 fetch 脚本（fail-soft）。 */
export function buildKuaishouSubCommentsScript(photoId: string, rootCommentId: string, pcursor: string): string {
  return `(async () => {
  try {
    const res = await fetch("/rest/v/photo/comment/sublist", {
      method: "POST",
      credentials: "include",
      headers: { "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify({ photoId: ${JSON.stringify(photoId)}, pcursor: ${JSON.stringify(pcursor)}, rootCommentId: ${JSON.stringify(rootCommentId)} }),
    });
    if (!res.ok) return { ok: false, status: res.status };
    const j = await res.json();
    if (j.result !== 1) return { ok: false, result: j.result };
    const list = Array.isArray(j.subCommentsV2) ? j.subCommentsV2 : [];
    const out = [];
    for (const c of list) {
      const content = c && typeof c.content === "string" ? c.content : "";
      if (content) out.push(String(content).slice(0, 20000));
    }
    return { ok: true, items: out };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 解析评论返回。 */
export function parseKuaishouComments(value: unknown): {
  ok: boolean;
  items: Array<{ commentId: string; author: string; content: string; likeCount: number; hasSubComments: boolean }>;
  pcursor: string;
  total: number;
  result?: number;
  error?: string;
} {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const items = Array.isArray(v.items) ? v.items : [];
    return {
      ok: v.ok === true,
      result: typeof v.result === "number" ? v.result : undefined,
      items: items
        .map((it) => {
          if (!it || typeof it !== "object") return null;
          const c = it as Record<string, unknown>;
          const content = String(c.content ?? "").trim();
          if (!content) return null;
          return {
            commentId: String(c.commentId ?? ""),
            author: String(c.author ?? ""),
            content,
            likeCount: Number(c.likeCount) || 0,
            hasSubComments: c.hasSubComments === true,
          };
        })
        .filter((c): c is { commentId: string; author: string; content: string; likeCount: number; hasSubComments: boolean } => c !== null),
      pcursor: String(v.pcursor ?? ""),
      total: Number(v.total) || 0,
      error: typeof v.error === "string" ? v.error : undefined,
    };
  }
  return { ok: false, items: [], pcursor: "", total: 0 };
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function evalOn(
  handle: SessionHandle,
  exec: ToolRunContext,
  sessionId: string,
  script: string,
  label: string,
): Promise<unknown> {
  const raw = await handle.run(exec, ["evaluate", "--session", sessionId, script], label);
  return unwrapEvaluateValue(raw);
}

/** 导航到快手页（带重试与风控识别）。浏览器基础设施失败（Chrome 关闭/bsk 断连）直接上抛，不计 strike。 */
async function navigateKuaishou(
  handle: SessionHandle,
  exec: ToolRunContext,
  sessionId: string,
  url: string,
  deps: KuaishouDeps,
  label: string,
): Promise<"ok" | "rate_limited"> {
  const run = (args: string[], l: string) => handle.run(exec, args, l);
  try {
    await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", url], label);
    return "ok";
  } catch (error) {
    if (isBrowserUnavailable(error)) throw error;
    await sleep(2000);
    try {
      await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", url], `${label} retry`);
      return "ok";
    } catch (error2) {
      if (isBrowserUnavailable(error2)) throw error2;
      deps.pacer.record("kuaishou", "rate_limited", { reason: `${label} timeout` });
      return "rate_limited";
    }
  }
}

/**
 * 快手视频搜索卡片采集（单次访问、不滚动不点击，被动采集纪律）。
 * 导航搜索页 → 页面内读 window.INIT_STATE 的 search.feed（卡片是 button 无 href，
 * 但 state 里有 photo.id）→ DOM clientCacheKey 兜底。返回 photoId + short-video URL，
 * 可直接对每个 URL 调 collect_comments（kuaishou-api 通道）采评论。
 */
export async function collectKuaishouSearch(
  deps: KuaishouDeps,
  exec: ToolRunContext,
  keyword: string,
  opts: { limit?: number; renderWaitMs?: number } = {},
): Promise<KuaishouSearchOutcome> {
  return deps.pacer.runExclusive("kuaishou", async () => {
  const limit = Math.max(1, opts.limit ?? 20);
  const renderWait = deps.renderWaitMs ?? opts.renderWaitMs ?? 4000;
  let handle: SessionHandle | null = null;
  try {
    handle = await deps.pool.acquire(exec);
    const sessionId = handle.sessionId;

    const navResult = await navigateKuaishou(
      handle,
      exec,
      sessionId,
      buildKuaishouSearchUrl(keyword),
      deps,
      "kuaishou search navigate",
    );
    if (navResult === "rate_limited") {
      return { ok: false, reason: "rate_limited", cards: [], error: "快手搜索页导航超时（可能被风控挂起）：已进入平台冷却，稍后重试" };
    }
    // 条件等待：SPA 首屏水合可能滞后，轮询提取直到卡片就绪（预算 ≥ 原 renderWait + 重试上限）
    const cards = (await pollExtract(
      async () =>
        parseKuaishouSearchCards(
          await evalOn(handle!, exec, sessionId, buildKuaishouSearchExtractScript(), "kuaishou search extract"),
        ),
      (c) => c.length > 0,
      { intervalMs: 600, maxMs: renderWait + 4000, signal: exec.signal },
    )) ?? [];

    if (cards.length === 0) {
      return { ok: true, reason: "empty", cards: [], error: "快手搜索页未提取到视频卡片（结果为空或页面结构变化）" };
    }
    deps.pacer.reset("kuaishou");
    return { ok: true, reason: "success", cards: cards.slice(0, limit) };
  } catch (error) {
    return {
      ok: false,
      reason: "error",
      cards: [],
      error: `快手搜索采集失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
    };
  } finally {
    handle?.release();
  }
  });
}

/**
 * 快手视频评论采集（浏览器路径，页面内 fetch 免签名）。
 * 支持 /f/{id} 分享链接（navigate 后从当前 URL 挖 photoId）与 /short-video/{id}。
 */
export async function collectKuaishouComments(
  deps: KuaishouDeps,
  exec: ToolRunContext,
  url: string,
  opts: { maxComments?: number; maxRepliesPerComment?: number } = {},
): Promise<{ ok: boolean; reason: KuaishouOutcomeReason; title: string; comments: CommentEntry[]; error?: string }> {
  const maxComments = Math.max(1, opts.maxComments ?? 100);
  const maxReplies = Math.max(0, opts.maxRepliesPerComment ?? 5);
  const renderWait = deps.renderWaitMs ?? 4000;
  let handle: SessionHandle | null = null;
  try {
    handle = await deps.pool.acquire(exec);
    const sessionId = handle.sessionId;
    const run = (args: string[], label: string) => handle!.run(exec, args, label);

    const navResult = await navigateKuaishou(handle, exec, sessionId, url, deps, "kuaishou video navigate");
    if (navResult === "rate_limited") {
      return { ok: false, reason: "rate_limited", title: "", comments: [], error: "快手导航超时（可能被风控挂起）：已进入平台冷却，稍后重试" };
    }
    // 条件等待：页面 readyState=complete 即开始（页面内本地探针；预算 = 原 renderWait）
    await pollPageReady(
      async () => evalOn(handle!, exec, sessionId, `(async () => document.readyState)()`, "kuaishou ready"),
      { intervalMs: 600, maxMs: renderWait, signal: exec.signal },
    );

    // 从当前 URL 挖 photoId（支持 /f/ 重定向）
    const photoId = await evalOn(handle, exec, sessionId, `(async () => {
      const m = location.href.match(/\\/short-video\\/([A-Za-z0-9]+)/);
      return { photoId: m ? m[1] : "", url: location.href.slice(0, 140), title: (document.body.innerText || "").slice(0, 200) };
    })()`, "kuaishou photoId");
    const pid = photoId && typeof photoId === "object" && !Array.isArray(photoId)
      ? String((photoId as Record<string, unknown>).photoId ?? "")
      : "";
    if (!pid) {
      return { ok: false, reason: "error", title: "", comments: [], error: "未能从快手页面解析视频 id（页面可能未加载或非视频页）" };
    }

    // 主评论分页（pcursorV2）
    const rawComments: Array<{ commentId: string; author: string; content: string; likeCount: number; hasSubComments: boolean }> = [];
    let pcursor = "";
    let pages = 0;
    while (rawComments.length < maxComments && pages < 50) {
      if (exec.signal?.aborted) break;
      await deps.pacer.waitForSlot("kuaishou");
      const raw = await evalOn(handle, exec, sessionId, buildKuaishouCommentsScript(pid, pcursor), "kuaishou comments");
      const parsed = parseKuaishouComments(raw);
      if (!parsed.ok) {
        // result:2 服务端限流、result:50 拒绝（需签名）→ 按风控冷却处理
        if (parsed.result === 2 || parsed.result === 50 || parsed.error || /Failed to fetch/i.test(parsed.error ?? "")) {
          deps.pacer.record("kuaishou", "rate_limited", { reason: `comments result=${parsed.result ?? parsed.error ?? "failed"}` });
          return {
            ok: false,
            reason: "rate_limited",
            title: "",
            comments: rawComments.slice(0, maxComments).map((c) => ({ author: c.author, content: c.content, replies: [] })),
            error: parsed.result === 2 ? "快手评论接口服务端限流（result:2）：已进入平台冷却" : parsed.result === 50 ? "快手评论接口签名校验失败（result:50）：已进入平台冷却" : "快手评论接口被拦截：已进入平台冷却",
          };
        }
        break;
      }
      rawComments.push(...parsed.items);
      if (parsed.items.length === 0) break;
      pcursor = parsed.pcursor;
      if (!pcursor || pcursor === "no_more") break;
      pages += 1;
      await sleep(300);
    }

    if (rawComments.length === 0) {
      return { ok: true, reason: "empty", title: "", comments: [], error: "该视频暂无评论或评论接口未返回数据" };
    }

    // 子评论（前 maxReplies 条有回复的评论，fail-soft）
    const comments: CommentEntry[] = [];
    let replyBudget = maxReplies;
    for (const c of rawComments) {
      const entry: CommentEntry = { author: c.author, content: c.content, replies: [] };
      if (replyBudget > 0 && c.hasSubComments && c.commentId) {
        try {
          const raw = await evalOn(handle, exec, sessionId, buildKuaishouSubCommentsScript(pid, c.commentId, ""), "kuaishou sub comments");
          const parsed = parseKuaishouComments(raw);
          if (parsed.ok) entry.replies = parsed.items.map((r) => r.content).slice(0, 10);
        } catch {
          // 子评论失败不阻断
        }
        replyBudget -= 1;
        await sleep(200);
      }
      comments.push(entry);
      if (comments.length >= maxComments) break;
    }

    deps.pacer.reset("kuaishou");
    return { ok: true, reason: "success", title: "", comments: comments.slice(0, maxComments) };
  } catch (error) {
    return {
      ok: false,
      reason: "error",
      title: "",
      comments: [],
      error: `快手评论采集失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
    };
  } finally {
    handle?.release();
  }
}
