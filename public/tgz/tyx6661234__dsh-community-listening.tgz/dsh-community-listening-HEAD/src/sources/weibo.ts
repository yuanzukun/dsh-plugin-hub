/**
 * 微博采集通道（帖子搜索 + 评论），浏览器路径（已验证）：
 *
 * 实测（2026-08，真实 bsk 会话）：
 * - 后端匿名直连 m.weibo.cn API 返回 432 反爬；浏览器页面内 fetch（自动带 cookie）返回 ok:1。
 * - 搜索：GET /api/container/getIndex?containerid=100103type=1&q={keyword}&page={n}
 *   → data.cards[].mblog（id/mid、user.screen_name、text(HTML)、comments_count 等）
 * - 评论：GET https://m.weibo.cn/comments/hotflow?id={mid}&mid={mid}[&max_id={n}]&max_id_type=0
 *   （Referer: https://m.weibo.cn/detail/{mid}）→ data.data[]（含子评论），max_id 游标分页
 * - 热榜：weibo.com/ajax/side/hotSearch 后端直连 403（需登录态），未纳入。
 *
 * 与 B 站同构：navigate m.weibo.cn 域页面（自动带 cookie）→ 页面内 fetch API（结构化 JSON）。
 */

import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import { isBrowserUnavailable, type BrowserSessionPool, type SessionHandle } from "../collect";
import type { PlatformPacer } from "../pacing";
import type { CommentEntry } from "../types";
import { unwrapEvaluateValue } from "./zhihu";
import { pollPageReady } from "./wait";

export type WeiboOutcomeReason = "success" | "empty" | "login_wall" | "rate_limited" | "error";

export interface WeiboDeps {
  pool: BrowserSessionPool;
  pacer: PlatformPacer;
  /** 页面渲染等待（毫秒，默认 4000）。 */
  renderWaitMs?: number;
}

export interface WeiboPost {
  id: string;
  bid: string;
  url: string;
  author: string;
  text: string;
  createdAt: string;
  likeCount: number;
  commentCount: number;
  repostCount: number;
}

export interface WeiboSearchOutcome {
  ok: boolean;
  reason: WeiboOutcomeReason;
  keyword: string;
  posts: WeiboPost[];
  error?: string;
}

/** 从 URL 提取微博帖子 id（mid）：m.weibo.cn/detail/{mid}。 */
export function extractWeiboMid(url: string): string | null {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host !== "m.weibo.cn" && host !== "weibo.com" && host !== "www.weibo.com") return null;
    const m = parsed.pathname.match(/^\/detail\/(\d+)/);
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

/** 搜索 API 页面内 fetch 脚本（页面上下文自动带 cookie，绕过 432）。 */
export function buildWeiboSearchScript(keyword: string, page: number): string {
  const q = encodeURIComponent(keyword.trim());
  return `(async () => {
  try {
    const stripHtml = (html) => String(html || "")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, '"')
      .replace(/\\s+/g, " ").trim();
    const res = await fetch("/api/container/getIndex?containerid=100103type%3D1%26q%3D${q}&page=${page}", {
      credentials: "include",
      headers: { accept: "application/json, text/plain, */*" },
    });
    if (!res.ok) return { ok: false, status: res.status };
    const j = await res.json();
    if (j.ok !== 1) return { ok: false, apiOk: j.ok, msg: String(j.msg || "") };
    const cards = (j.data && Array.isArray(j.data.cards)) ? j.data.cards : [];
    const out = [];
    for (const c of cards) {
      const m = c && c.mblog;
      if (!m || typeof m !== "object") continue;
      const id = String(m.id || m.mid || "");
      if (!id) continue;
      const bid = String(m.bid || "");
      const author = (m.user && m.user.screen_name) || "";
      const text = stripHtml(m.text || m.text_raw || "");
      if (!text) continue;
      out.push({
        id,
        bid,
        url: bid && m.user && m.user.id ? "https://weibo.com/" + m.user.id + "/" + bid : "https://m.weibo.cn/detail/" + id,
        author: String(author),
        text: String(text).slice(0, 20000),
        createdAt: String(m.created_at || ""),
        likeCount: Number(m.attitudes_count) || 0,
        commentCount: Number(m.comments_count) || 0,
        repostCount: Number(m.reposts_count) || 0,
      });
    }
    return { ok: true, count: out.length, items: out };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 评论 API 页面内 fetch 脚本（hotflow，max_id 游标分页）。 */
export function buildWeiboCommentsScript(mid: string, maxId: number): string {
  const params = `id=${mid}&mid=${mid}${maxId > 0 ? `&max_id=${maxId}` : ""}&max_id_type=0`;
  return `(async () => {
  try {
    const stripHtml = (html) => String(html || "")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, '"')
      .replace(/\\s+/g, " ").trim();
    const res = await fetch("https://m.weibo.cn/comments/hotflow?${params}", {
      credentials: "include",
      headers: { accept: "application/json, text/plain, */*", referer: "https://m.weibo.cn/detail/${mid}" },
    });
    if (!res.ok) return { ok: false, status: res.status };
    const j = await res.json();
    if (j.ok !== 1) return { ok: false, apiOk: j.ok, msg: String(j.msg || "") };
    const list = (j.data && Array.isArray(j.data.data)) ? j.data.data : [];
    const out = [];
    for (const cm of list) {
      if (!cm || typeof cm !== "object") continue;
      const text = stripHtml(cm.text);
      if (!text) continue;
      const sub = Array.isArray(cm.comments)
        ? cm.comments.map((s) => stripHtml(s && s.text)).filter(Boolean)
        : [];
      out.push({ author: String((cm.user && cm.user.screen_name) || ""), content: text.slice(0, 20000), replies: sub.slice(0, 20) });
    }
    return {
      ok: true,
      count: out.length,
      items: out,
      hasMore: j.data.has_more === true,
      maxId: Number(j.data.max_id) || 0,
      maxIdType: Number(j.data.max_id_type) || 0,
    };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 解析搜索返回（防御性）。 */
export function parseWeiboSearch(value: unknown): { ok: boolean; items: WeiboPost[]; apiOk?: number; error?: string } {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const items = Array.isArray(v.items) ? v.items : [];
    return {
      ok: v.ok === true,
      items: items
        .map((it) => {
          if (!it || typeof it !== "object") return null;
          const p = it as Record<string, unknown>;
          const id = String(p.id ?? "");
          if (!id) return null;
          return {
            id,
            bid: String(p.bid ?? ""),
            url: String(p.url ?? ""),
            author: String(p.author ?? ""),
            text: String(p.text ?? ""),
            createdAt: String(p.createdAt ?? ""),
            likeCount: Number(p.likeCount) || 0,
            commentCount: Number(p.commentCount) || 0,
            repostCount: Number(p.repostCount) || 0,
          };
        })
        .filter((p): p is WeiboPost => p !== null),
      apiOk: typeof v.apiOk === "number" ? v.apiOk : undefined,
      error: typeof v.error === "string" ? v.error : typeof v.msg === "string" ? v.msg : undefined,
    };
  }
  return { ok: false, items: [] };
}

/** 解析评论返回（防御性）。 */
export function parseWeiboComments(value: unknown): {
  ok: boolean;
  items: CommentEntry[];
  hasMore: boolean;
  maxId: number;
  error?: string;
} {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const items = Array.isArray(v.items) ? v.items : [];
    return {
      ok: v.ok === true,
      items: items
        .map((it) => {
          if (!it || typeof it !== "object") return null;
          const c = it as Record<string, unknown>;
          const content = String(c.content ?? "").trim();
          if (!content) return null;
          return {
            author: String(c.author ?? ""),
            content,
            replies: Array.isArray(c.replies) ? c.replies.map((r) => String(r)).filter(Boolean) : [],
          };
        })
        .filter((c): c is CommentEntry => c !== null),
      hasMore: v.hasMore === true,
      maxId: Number(v.maxId) || 0,
      error: typeof v.error === "string" ? v.error : typeof v.msg === "string" ? v.msg : undefined,
    };
  }
  return { ok: false, items: [], hasMore: false, maxId: 0 };
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function evalOn(
  handle: SessionHandle,
  exec: ToolRunContext,
  sessionId: string,
  script: string,
  label: string,
): Promise<unknown> {
  const raw = await handle.run(exec, ["evaluate", "--session", sessionId, script], label);
  return unwrapEvaluateValue(raw);
}

/** 导航到 m.weibo.cn 域（页面自动带 cookie），带重试与风控识别。浏览器基础设施失败直接上抛，不计 strike。 */
async function navigateWeibo(
  handle: SessionHandle,
  exec: ToolRunContext,
  sessionId: string,
  url: string,
  deps: WeiboDeps,
  label: string,
): Promise<"ok" | "rate_limited"> {
  const run = (args: string[], l: string) => handle.run(exec, args, l);
  try {
    await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", url], label);
    return "ok";
  } catch (error) {
    if (isBrowserUnavailable(error)) throw error;
    await sleep(2000);
    try {
      await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", url], `${label} retry`);
      return "ok";
    } catch (error2) {
      if (isBrowserUnavailable(error2)) throw error2;
      deps.pacer.record("weibo", "rate_limited", { reason: `${label} timeout` });
      return "rate_limited";
    }
  }
}

/**
 * 微博帖子搜索（浏览器路径）：navigate 搜索页 → 页面内 fetch 搜索 API（自动带 cookie）。
 * 匿名可用（游客 cookie 由页面自动生成）；命中风控/432 触发 weibo 冷却。
 */
export async function collectWeiboSearch(
  deps: WeiboDeps,
  exec: ToolRunContext,
  keyword: string,
  opts: { limit?: number; page?: number } = {},
): Promise<WeiboSearchOutcome> {
  return deps.pacer.runExclusive("weibo", async () => {
  const limit = Math.max(1, opts.limit ?? 20);
  const page = Math.max(1, opts.page ?? 1);
  const renderWait = deps.renderWaitMs ?? 4000;
  let handle: SessionHandle | null = null;
  try {
    try {
      handle = await deps.pool.acquire(exec);
    } catch (error) {
      return {
        ok: false,
        reason: "error",
        keyword,
        posts: [],
        error: `浏览器会话不可用：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
      };
    }
    const sessionId = handle.sessionId;
    const run = (args: string[], label: string) => handle!.run(exec, args, label);

    const q = encodeURIComponent(keyword.trim());
    const navResult = await navigateWeibo(
      handle,
      exec,
      sessionId,
      `https://m.weibo.cn/search?containerid=100103type%3D1%26q%3D${q}`,
      deps,
      "weibo search navigate",
    );
    if (navResult === "rate_limited") {
      return { ok: false, reason: "rate_limited", keyword, posts: [], error: "微博导航超时（可能被风控挂起）：已进入平台冷却，稍后重试" };
    }
    await sleep(renderWait);

    const raw = await evalOn(handle, exec, sessionId, buildWeiboSearchScript(keyword, page), "weibo search");
    const parsed = parseWeiboSearch(raw);
    if (!parsed.ok) {
      if (parsed.apiOk !== undefined || /432|ok":0/.test(parsed.error ?? "")) {
        deps.pacer.record("weibo", "rate_limited", { reason: `search apiOk=${parsed.apiOk}: ${(parsed.error ?? "").slice(0, 80)}` });
        return { ok: false, reason: "rate_limited", keyword, posts: [], error: `微博搜索接口被拦截（${parsed.error ?? "未知错误"}）：已进入平台冷却` };
      }
      return { ok: false, reason: "error", keyword, posts: [], error: parsed.error ? `微博搜索失败：${parsed.error}` : "微博搜索失败" };
    }
    if (parsed.items.length === 0) {
      return { ok: true, reason: "empty", keyword, posts: [], error: "未搜索到微博（关键词无结果或页面未加载）" };
    }
    deps.pacer.reset("weibo");
    return { ok: true, reason: "success", keyword, posts: parsed.items.slice(0, limit) };
  } catch (error) {
    return {
      ok: false,
      reason: "error",
      keyword,
      posts: [],
      error: `微博采集失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
    };
  } finally {
    handle?.release();
  }
  });
}

/**
 * 微博评论采集（浏览器路径）：navigate 详情页 → 页面内 fetch hotflow（max_id 分页）。
 */
export async function collectWeiboComments(
  deps: WeiboDeps,
  exec: ToolRunContext,
  mid: string,
  opts: { maxComments?: number } = {},
): Promise<{ ok: boolean; reason: WeiboOutcomeReason; title: string; comments: CommentEntry[]; error?: string }> {
  const maxComments = Math.max(1, opts.maxComments ?? 100);
  const renderWait = deps.renderWaitMs ?? 4000;
  let handle: SessionHandle | null = null;
  try {
    handle = await deps.pool.acquire(exec);
    const sessionId = handle.sessionId;
    const run = (args: string[], label: string) => handle!.run(exec, args, label);

    const navResult = await navigateWeibo(
      handle,
      exec,
      sessionId,
      `https://m.weibo.cn/detail/${mid}`,
      deps,
      "weibo detail navigate",
    );
    if (navResult === "rate_limited") {
      return { ok: false, reason: "rate_limited", title: "", comments: [], error: "微博导航超时（可能被风控挂起）：已进入平台冷却，稍后重试" };
    }
    // 条件等待：页面 readyState=complete 即开始（页面内本地探针；预算 = 原 renderWait）
    await pollPageReady(
      async () => evalOn(handle!, exec, sessionId, `(async () => document.readyState)()`, "weibo ready"),
      { intervalMs: 600, maxMs: renderWait, signal: exec.signal },
    );

    // 评论分页（max_id 游标）
    const all: CommentEntry[] = [];
    let maxId = 0;
    let hasMore = true;
    let pages = 0;
    while (hasMore && all.length < maxComments && pages < 20) {
      if (exec.signal?.aborted) break;
      await deps.pacer.waitForSlot("weibo");
      const raw = await evalOn(handle, exec, sessionId, buildWeiboCommentsScript(mid, maxId), "weibo comments");
      const parsed = parseWeiboComments(raw);
      if (!parsed.ok) {
        if (parsed.error && /432|ok":0/.test(parsed.error)) {
          deps.pacer.record("weibo", "rate_limited", { reason: `comments apiOk: ${parsed.error.slice(0, 80)}` });
          return { ok: false, reason: "rate_limited", title: "", comments: all, error: "微博评论接口被拦截：已进入平台冷却" };
        }
        break; // 单页失败：保留已收集
      }
      all.push(...parsed.items);
      if (parsed.items.length === 0) break;
      maxId = parsed.maxId;
      hasMore = parsed.hasMore && parsed.maxId > 0;
      pages += 1;
      await sleep(300);
    }

    if (all.length === 0) {
      return { ok: true, reason: "empty", title: "", comments: [], error: "该微博暂无评论或评论接口未返回数据" };
    }
    deps.pacer.reset("weibo");
    return { ok: true, reason: "success", title: "", comments: all.slice(0, maxComments) };
  } catch (error) {
    return {
      ok: false,
      reason: "error",
      title: "",
      comments: [],
      error: `微博评论采集失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
    };
  } finally {
    handle?.release();
  }
}
