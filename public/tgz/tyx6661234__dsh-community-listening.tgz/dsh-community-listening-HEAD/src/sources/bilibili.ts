/**
 * B 站 API 直连通道（视频评论）：后端无签名直连，结构化 JSON，零浏览器依赖。
 *
 * 端点：
 * - GET /x/web-interface/view?bvid=            bvid → aid + title
 * - GET /x/v2/reply/main?type=1&oid={aid}&mode=3&next={n}   主评论（cursor 游标分页）
 * - GET /x/v2/reply/reply?type=1&oid={aid}&root={rid}&ps=&pn=  楼中楼
 * - GET /x/v2/reply/wbi/main（WBI 签名变体，主接口异常时自动重试）
 *
 * 匿名可读；412 / 429 / -412 触发 bilibili 平台冷却（指数退避）。
 * 出口 IP 被风控（412）时，上层可降级到浏览器同源 fetch 兜底（见 collect.ts）。
 */

import { createHash } from "node:crypto";
import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import { isBrowserUnavailable, type BrowserSessionPool, type SessionHandle } from "../collect";
import { httpFetch } from "../net";
import type { PlatformPacer } from "../pacing";
import type { CommentEntry } from "../types";
import { pollExtract } from "./wait";

export type BilibiliOutcomeReason =
  | "success"
  | "empty"
  | "login_wall"
  | "rate_limited"
  | "error";

export interface BilibiliOptions {
  /** 主评论 + 楼中楼合计上限（默认 100）。 */
  maxComments?: number;
  /** 每条主评论最多取多少条楼中楼（默认 20，即 1 页）。 */
  maxRepliesPerComment?: number;
  /**
   * 只对前 N 条主评论抓楼中楼（默认 20）。mode=3 主评论本身按热度序，
   * 即等效 Top-N——避免对 100 条主评论各打 1 次楼中楼请求（单视频最坏 121 次）。
   * 其余主评论仍正常返回（无 replies）。
   */
  maxReplyComments?: number;
}

export interface BilibiliDeps {
  pacer: PlatformPacer;
  signal?: AbortSignal;
  /** 请求超时（毫秒，默认 15000）。 */
  timeoutMs?: number;
  /**
   * 可选登录 Cookie（如 SESSDATA=...; bili_jct=...）。
   * 匿名请求在部分网络出口（机房/代理 IP）会被 B 站 412 风控；带登录态可显著提高可用性。
   * 敏感凭据：仅在用户主动配置时使用，不落盘、不外发。
   */
  cookie?: string;
}

export interface BilibiliCollectOutcome {
  ok: boolean;
  reason: BilibiliOutcomeReason;
  title: string;
  comments: CommentEntry[];
  error?: string;
}

const MAIN_PAGE = 20;
const TIMEOUT_MS = 15_000;
const API_ORIGIN = "https://api.bilibili.com";

// ---------------------------------------------------------------------------
// WBI 请求签名（对齐 OpenBiliClaw bilibili/api.py:494-553）
// B 站部分接口（如 /x/v2/reply/wbi/main）要求 WBI 签名：从 nav 接口取 img/sub
// key，按打乱表构造 mixin key，参数排序 + wts 时间戳 + md5(query+mixin) → w_rid。
// ---------------------------------------------------------------------------

const WBI_MIXIN_KEY_ENC_TAB: readonly number[] = [
  46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
  27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
  37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
  22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52,
];

const WBI_KEY_TTL_MS = 300_000; // 5 分钟刷新（B 站轮换 key）

/** 从 wbi_img / wbi_sub URL 提取 key 段（路径最后一段去扩展名）。 */
export function extractWbiKeyComponent(url: string): string {
  try {
    const path = new URL(url).pathname;
    const seg = path.split("/").filter(Boolean).pop() ?? "";
    return seg.split(".")[0];
  } catch {
    return "";
  }
}

/** 构造 mixin key：img+sub 拼接，按打乱表取 64 位，截前 32。 */
export function buildWbiMixinKey(imgKey: string, subKey: string): string {
  const merged = imgKey + subKey;
  let out = "";
  for (const i of WBI_MIXIN_KEY_ENC_TAB) out += merged[i] ?? "";
  return out.slice(0, 32);
}

/** Python urllib.parse.quote_plus(safe='') 语义的百分号编码（B 站 WBI 用）。 */
export function pyUrlencodeValue(value: string): string {
  let out = "";
  for (const ch of value) {
    const code = ch.codePointAt(0) ?? 0;
    if (
      (code >= 0x41 && code <= 0x5a) || // A-Z
      (code >= 0x61 && code <= 0x7a) || // a-z
      (code >= 0x30 && code <= 0x39) || // 0-9
      ch === "-" || ch === "_" || ch === "."
    ) {
      out += ch;
    } else if (ch === " ") {
      out += "+";
    } else {
      for (const byte of new TextEncoder().encode(ch)) {
        out += `%${byte.toString(16).toUpperCase().padStart(2, "0")}`;
      }
    }
  }
  return out;
}

/** WBI 签名：wts + 排序 + 特殊字符清洗 + md5(query+mixin) → w_rid（确定性，可测）。 */
export function signWbiParams(
  params: Record<string, string | number>,
  imgKey: string,
  subKey: string,
): Record<string, string> {
  const mixinKey = buildWbiMixinKey(imgKey, subKey);
  const wts = Math.floor(Date.now() / 1000);
  const sanitized: Record<string, string> = {};
  for (const [key, value] of Object.entries({ ...params, wts: String(wts) })) {
    sanitized[key] = String(value).replace(/[!'()*]/g, "");
  }
  const ordered: Record<string, string> = {};
  for (const key of Object.keys(sanitized).sort()) ordered[key] = sanitized[key];
  const query = Object.entries(ordered)
    .map(([key, value]) => `${pyUrlencodeValue(key)}=${pyUrlencodeValue(value)}`)
    .join("&");
  ordered.w_rid = createHash("md5").update(query + mixinKey).digest("hex");
  return ordered;
}

/** WBI key 缓存（TTL 5 分钟；失败返回 null，不抛）。 */
class WbiKeyStore {
  private imgKey = "";
  private subKey = "";
  private fetchedAt = 0;

  async getKeys(deps: BilibiliDeps): Promise<{ imgKey: string; subKey: string } | null> {
    if (this.imgKey && Date.now() - this.fetchedAt < WBI_KEY_TTL_MS) {
      return { imgKey: this.imgKey, subKey: this.subKey };
    }
    try {
      const nav = await bilibiliJson(deps, "/x/web-interface/nav", {});
      const wbiImg = nav.data?.wbi_img;
      const imgKey = extractWbiKeyComponent(
        String(wbiImg && typeof wbiImg === "object" ? (wbiImg as Record<string, unknown>).img_url ?? "" : ""),
      );
      const subKey = extractWbiKeyComponent(
        String(wbiImg && typeof wbiImg === "object" ? (wbiImg as Record<string, unknown>).sub_url ?? "" : ""),
      );
      if (!imgKey || !subKey) return null;
      this.imgKey = imgKey;
      this.subKey = subKey;
      this.fetchedAt = Date.now();
      return { imgKey, subKey };
    } catch {
      return null;
    }
  }
}

const wbiKeyStore = new WbiKeyStore();

/** 从 URL 提取 bvid（仅 bilibili.com 域，/video/{bvid}）。 */
export function extractBvid(url: string): string | null {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host !== "bilibili.com" && host !== "www.bilibili.com") return null;
    const m = parsed.pathname.match(/^\/video\/([A-Za-z0-9]+)/);
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

interface BiliJsonResult {
  code: number;
  data: Record<string, unknown> | null;
  message: string;
}

export interface BiliJsonOptions {
  /** 启用 WBI 签名（path 为 /x/v2/reply/wbi/main 等 wbi 变体时使用）。 */
  wbi?: boolean;
}

/** GET 一个 B 站 API，返回 {code, data, message}。抛错 = 网络/HTTP 异常。 */
export async function bilibiliJson(
  deps: BilibiliDeps,
  path: string,
  params: Record<string, string | number>,
  options: BiliJsonOptions = {},
): Promise<BiliJsonResult> {
  await deps.pacer.waitForSlot("bilibili");
  const url = new URL(`${API_ORIGIN}${path}`);
  let finalParams: Record<string, string> = {};
  if (options.wbi) {
    const keys = await wbiKeyStore.getKeys(deps);
    if (!keys) return { code: -400, data: null, message: "WBI key 获取失败" };
    finalParams = signWbiParams(params, keys.imgKey, keys.subKey);
  } else {
    for (const [key, value] of Object.entries(params)) finalParams[key] = String(value);
  }
  for (const [key, value] of Object.entries(finalParams)) {
    url.searchParams.set(key, value);
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), deps.timeoutMs ?? TIMEOUT_MS);
  const onOuter = () => controller.abort();
  deps.signal?.addEventListener("abort", onOuter, { once: true });
  try {
    const resp = await httpFetch(url.toString(), {
      redirect: "follow",
      signal: controller.signal,
      headers: {
        "user-agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
          "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "referer": "https://www.bilibili.com/",
        "accept": "application/json, text/plain, */*",
        "accept-language": "zh-CN,zh;q=0.9",
        ...(deps.cookie ? { "cookie": deps.cookie } : {}),
      },
    });
    if (resp.status === 412) {
      // 412 常见于匿名出口 IP / 缺 Cookie，不是真实限流：只设短冷却、不累计 strike，
      // 让上层立即走浏览器同源兜底（复用登录态）而不是把 B 站锁死 30 分钟。
      deps.pacer.record("bilibili", "rate_limited", {
        reason: "HTTP 412（匿名 IP 风控 / 缺 Cookie，浏览器兜底可绕过）",
        soft: true,
        cooldownMs: 10_000,
      });
      return { code: -412, data: null, message: "HTTP 412 请求被拦截" };
    }
    if (resp.status === 429) {
      deps.pacer.record("bilibili", "rate_limited", { reason: "HTTP 429 限流" });
      return { code: -429, data: null, message: "HTTP 429 限流" };
    }
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const payload = (await resp.json()) as {
      code?: unknown;
      message?: unknown;
      data?: unknown;
    };
    return {
      code: Number(payload.code) || 0,
      data: payload.data && typeof payload.data === "object" ? (payload.data as Record<string, unknown>) : null,
      message: typeof payload.message === "string" ? payload.message : "",
    };
  } finally {
    clearTimeout(timer);
    deps.signal?.removeEventListener("abort", onOuter);
  }
}

interface BiliReply {
  rpid: number;
  uname: string;
  message: string;
  like: number;
}

/** 归一化单条评论（防御字段缺失；rpid 转 number）。 */
export function toReply(raw: unknown): BiliReply | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  const member = r.member && typeof r.member === "object" ? (r.member as Record<string, unknown>) : {};
  const content = r.content && typeof r.content === "object" ? (r.content as Record<string, unknown>) : {};
  const uname = String(member.uname ?? "");
  const message = String(content.message ?? "").trim();
  const rpid = Number(r.rpid) || 0;
  if (!rpid || !message) return null;
  return { rpid, uname, message, like: Number(r.like) || 0 };
}

/**
 * B 站视频评论采集（主评论 + 楼中楼，游标分页）。
 * 网络/HTTP 异常与未知 code 抛错（上层降级原路径）；-412/412/429 返回 rate_limited。
 */
export async function collectBilibiliComments(
  deps: BilibiliDeps,
  bvid: string,
  opts: BilibiliOptions = {},
): Promise<BilibiliCollectOutcome> {
  const maxComments = Math.max(1, opts.maxComments ?? 100);
  const maxReplies = Math.max(0, opts.maxRepliesPerComment ?? 20);
  const maxReplyComments = Math.max(0, opts.maxReplyComments ?? 20);

  // 1) bvid → aid + title
  let view: BiliJsonResult;
  try {
    view = await bilibiliJson(deps, "/x/web-interface/view", { bvid });
  } catch (error) {
    return {
      ok: false,
      reason: "error",
      title: "",
      comments: [],
      error: `view 接口请求失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
    };
  }
  if (view.code === -412) {
    deps.pacer.record("bilibili", "rate_limited", {
      reason: "view -412（匿名 IP 风控 / 缺 Cookie，浏览器兜底可绕过）",
      soft: true,
      cooldownMs: 10_000,
    });
    return { ok: false, reason: "rate_limited", title: "", comments: [], error: view.message || "请求被拦截" };
  }
  if (view.code !== 0 || !view.data) {
    return {
      ok: false,
      reason: view.code === -101 ? "login_wall" : "error",
      title: "",
      comments: [],
      error: view.message ? `view 接口失败（code ${view.code}）：${view.message}` : `view 接口失败（code ${view.code}）`,
    };
  }
  const aid = Number(view.data.aid) || 0;
  const title = String(view.data.title ?? "");
  if (!aid) return { ok: false, reason: "error", title: "", comments: [], error: "view 未返回有效 aid" };

  // 2) 主评论分页（cursor.next 游标）
  const mainReplies: BiliReply[] = [];
  let next = 0;
  for (let page = 0; page < 20 && mainReplies.length < maxComments; page += 1) {
    if (deps.signal?.aborted) break;
    const params: Record<string, string | number> = { type: 1, oid: aid, mode: 3 };
    if (page > 0) params.next = next;
    let reply: BiliJsonResult;
    try {
      reply = await bilibiliJson(deps, "/x/v2/reply/main", params);
    } catch (error) {
      return {
        ok: false,
        reason: "error",
        title,
        comments: mainReplies.map((r) => ({ author: r.uname, content: r.message, replies: [] })),
        error: `评论接口请求失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
      };
    }
    if (reply.code === -412) {
      deps.pacer.record("bilibili", "rate_limited", {
        reason: "reply -412（匿名 IP 风控 / 缺 Cookie，浏览器兜底可绕过）",
        soft: true,
        cooldownMs: 10_000,
      });
      return { ok: false, reason: "rate_limited", title, comments: [], error: reply.message || "评论请求被拦截" };
    }
    if (reply.code === -101) {
      return { ok: false, reason: "login_wall", title, comments: [], error: "B 站会话失效（评论公开可读，但当前返回 -101）" };
    }
    // 主评论数据：主接口正常取主接口；异常（如未来要求 WBI 签名）→ wbi 变体重试一次
    let mainData: Record<string, unknown> | null = null;
    if (reply.code === 0 && reply.data) {
      mainData = reply.data;
    } else if (reply.code !== -412 && reply.code !== -101) {
      const wbiReply = await bilibiliJson(deps, "/x/v2/reply/wbi/main", params, { wbi: true });
      if (wbiReply.code === 0 && wbiReply.data) mainData = wbiReply.data;
    }
    if (!mainData) {
      return {
        ok: false,
        reason: "error",
        title,
        comments: [],
        error: reply.message
          ? `评论接口失败（code ${reply.code}）：${reply.message}`
          : `评论接口失败（code ${reply.code}）`,
      };
    }
    const replies = Array.isArray(mainData.replies) ? mainData.replies : [];
    for (const raw of replies) {
      const r = toReply(raw);
      if (r) mainReplies.push(r);
      if (mainReplies.length >= maxComments) break;
    }
    const cursor = mainData.cursor && typeof mainData.cursor === "object"
      ? (mainData.cursor as Record<string, unknown>)
      : {};
    const isEnd = cursor.is_end === true;
    const nextVal = Number(cursor.next) || 0;
    if (isEnd || replies.length === 0 || nextVal === 0) break;
    next = nextVal;
  }

  if (mainReplies.length === 0) {
    return { ok: true, reason: "empty", title, comments: [], error: "该视频暂无评论或评论不可见" };
  }

  // 3) 楼中楼（只对前 maxReplyComments 条主评论抓；每条最多 1 页；总量受 maxComments 约束）
  const comments: CommentEntry[] = [];
  let total = 0;
  let replyFetched = 0;
  for (const main of mainReplies) {
    if (deps.signal?.aborted) break;
    const entry: CommentEntry = { author: main.uname, content: main.message, replies: [] };
    if (total < maxComments && maxReplies > 0 && replyFetched < maxReplyComments) {
      replyFetched += 1;
      let sub: BiliJsonResult;
      try {
        sub = await bilibiliJson(deps, "/x/v2/reply/reply", {
          type: 1,
          oid: aid,
          root: String(main.rpid),
          ps: 20,
          pn: 1,
        });
      } catch {
        sub = { code: -1, data: null, message: "楼中楼请求失败" };
      }
      if (sub.code === 0 && sub.data) {
        const subReplies = Array.isArray(sub.data.replies) ? sub.data.replies : [];
        const picked: string[] = [];
        for (const raw of subReplies) {
          const r = toReply(raw);
          if (r) picked.push(r.message);
          if (picked.length >= maxReplies || total + picked.length >= maxComments) break;
        }
        entry.replies = picked;
        total += picked.length;
      }
    }
    comments.push(entry);
    if (total >= maxComments && comments.length >= maxComments) break;
  }

  deps.pacer.clearCooldown("bilibili");
  return { ok: true, reason: "success", title, comments };
}

// ---------------------------------------------------------------------------
// 浏览器同源 fetch 兜底（页面内执行，复用浏览器登录态；后端 412 时由 collect.ts 调用）
// ---------------------------------------------------------------------------

/** 页面内主评论 fetch 脚本（跨域绝对 URL；浏览器真实指纹可绕过后端 412 风控）。 */
export function buildBilibiliReplyMainScript(aid: number, mode: number, next?: number): string {
  const params = `type=1&oid=${aid}&mode=${mode}${next != null ? `&next=${next}` : ""}`;
  return `(async () => {
  try {
    const res = await fetch("https://api.bilibili.com/x/v2/reply/main?${params}", { credentials: "include" });
    if (!res.ok) return { ok: false, status: res.status };
    const json = await res.json();
    const d = json.data && typeof json.data === "object" ? json.data : {};
    const rawReplies = Array.isArray(d.replies) ? d.replies : [];
    const out = [];
    for (const it of rawReplies) {
      if (!it || typeof it !== "object") continue;
      const member = it.member && typeof it.member === "object" ? it.member : {};
      const content = it.content && typeof it.content === "object" ? it.content : {};
      const msg = typeof content.message === "string" ? content.message : "";
      if (!msg) continue;
      out.push({ rpid: Number(it.rpid) || 0, uname: String(member.uname || ""), message: msg, like: Number(it.like) || 0 });
    }
    const cursor = d.cursor && typeof d.cursor === "object" ? d.cursor : {};
    return { ok: true, code: Number(json.code) || 0, isEnd: cursor.is_end === true, next: Number(cursor.next) || 0, items: out };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 页面内视频信息 fetch 脚本（bvid → aid + title，跨域绝对 URL）。 */
export function buildBilibiliViewScript(bvid: string): string {
  return `(async () => {
  try {
    const res = await fetch("https://api.bilibili.com/x/web-interface/view?bvid=${encodeURIComponent(bvid)}", { credentials: "include" });
    if (!res.ok) return { ok: false, status: res.status };
    const json = await res.json();
    const d = json.data && typeof json.data === "object" ? json.data : {};
    return { ok: true, code: Number(json.code) || 0, aid: Number(d.aid) || 0, title: String(d.title || "") };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

// ---------------------------------------------------------------------------
// 搜索页视频发现（浏览器 DOM 提取；不需要 WBI 签名、后端直连也不受 412 影响）
// 实测：search.bilibili.com/video?keyword=… SSR 渲染出 38 个 /video/BV 链接，
// 每张 .bili-video-card 内 h3[title] 是标题、卡片文本次行是 UP 主。
// ---------------------------------------------------------------------------

export interface BilibiliSearchCard {
  bvid: string;
  url: string;
  title: string;
  author: string;
  playText: string;
}

export type BilibiliSearchOutcomeReason = "success" | "empty" | "rate_limited" | "error";

export interface BilibiliSearchOutcome {
  ok: boolean;
  reason: BilibiliSearchOutcomeReason;
  cards: BilibiliSearchCard[];
  error?: string;
}

/** B 站视频搜索页 URL。 */
export function buildBilibiliSearchUrl(keyword: string): string {
  return `https://search.bilibili.com/video?keyword=${encodeURIComponent(keyword)}`;
}

/** 页面内提取视频搜索卡片（去重 BV 号；h3[title] 优先，卡片文本兜底）。 */
export function buildBilibiliSearchExtractScript(): string {
  return `(async () => {
  const cards = [];
  const seen = new Set();
  document.querySelectorAll("a").forEach((a) => {
    const href = a.getAttribute("href") || "";
    if (!href.includes("/video/BV")) return;
    const m = href.match(/BV[A-Za-z0-9]+/);
    if (!m || seen.has(m[0])) return;
    seen.add(m[0]);
    const card = a.closest(".bili-video-card") || a.parentElement;
    const h3 = card && card.querySelector("h3[title]");
    const text = card ? (card.innerText || "").trim() : "";
    const lines = text.split("\\n").map((s) => s.trim()).filter(Boolean);
    const title = (h3 && h3.getAttribute("title")) || (a.getAttribute("title")) || lines[1] || "";
    let author = "";
    const titleIdx = lines.findIndex((s) => s === title);
    if (titleIdx >= 0 && lines.length > titleIdx + 1) author = lines[titleIdx + 1];
    cards.push({
      bvid: m[0],
      url: "https://www.bilibili.com/video/" + m[0],
      title: String(title || "").slice(0, 300),
      author: String(author || "").slice(0, 120),
      playText: String(lines[0] || "").slice(0, 40),
    });
  });
  return { ok: true, url: location.href, count: cards.length, cards };
})()`;
}

/** 防御性解析搜索卡片脚本返回。 */
export function parseBilibiliSearchCards(value: unknown): BilibiliSearchCard[] {
  let cards: unknown[] = [];
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    cards = Array.isArray(v.cards) ? v.cards : [];
  }
  const out: BilibiliSearchCard[] = [];
  for (const raw of cards) {
    if (!raw || typeof raw !== "object") continue;
    const c = raw as Record<string, unknown>;
    const bvid = String(c.bvid ?? "").trim();
    if (!bvid) continue;
    out.push({
      bvid,
      url: String(c.url ?? `https://www.bilibili.com/video/${bvid}`),
      title: String(c.title ?? ""),
      author: String(c.author ?? ""),
      playText: String(c.playText ?? ""),
    });
  }
  return out;
}

function bilibiliSleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * B 站视频搜索卡片采集（浏览器路径、单次访问、不滚动不点击）。
 * 返回的 video URL 可直接交给 collect_comments（bilibili-api 通道）采评论。
 */
export async function collectBilibiliSearch(
  deps: { pool: BrowserSessionPool; pacer: PlatformPacer },
  exec: ToolRunContext,
  keyword: string,
  opts: { limit?: number; renderWaitMs?: number } = {},
): Promise<BilibiliSearchOutcome> {
  return deps.pacer.runExclusive("bilibili", async () => {
  const limit = Math.max(1, opts.limit ?? 20);
  const renderWait = opts.renderWaitMs ?? 3500;
  let handle: SessionHandle | null = null;
  try {
    handle = await deps.pool.acquire(exec);
    const sessionId = handle.sessionId;
    const run = (args: string[], label: string) => handle!.run(exec, args, label);
    const url = buildBilibiliSearchUrl(keyword);

    let navOk = false;
    for (let attempt = 0; attempt < 2 && !navOk; attempt += 1) {
      try {
        await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "25s", url], "bilibili search navigate");
        navOk = true;
      } catch (error) {
        if (isBrowserUnavailable(error)) throw error; // 浏览器基础设施失败：快速上抛，不计 strike
        await bilibiliSleep(1500);
      }
    }
    if (!navOk) {
      deps.pacer.record("bilibili", "rate_limited", { reason: "bilibili search navigate timeout" });
      return { ok: false, reason: "rate_limited", cards: [], error: "B 站搜索页导航超时（可能被风控挂起）：已进入平台冷却，稍后重试" };
    }
    // 条件等待：首屏 SPA 水合可能滞后，轮询提取直到卡片就绪（预算 ≥ 原 renderWait + 重试上限）
    const cards = (await pollExtract(
      async () => {
        const raw = await run(["evaluate", "--session", sessionId, buildBilibiliSearchExtractScript()], "bilibili search extract");
        const value = raw && typeof raw === "object" && !Array.isArray(raw) && "value" in raw
          ? (raw as Record<string, unknown>).value
          : raw;
        return parseBilibiliSearchCards(value);
      },
      (c) => c.length > 0,
      { intervalMs: 600, maxMs: renderWait + 4000, signal: exec.signal },
    )) ?? [];

    if (cards.length === 0) {
      return { ok: true, reason: "empty", cards: [], error: "B 站搜索页未提取到视频卡片（结果为空或页面结构变化）" };
    }
    deps.pacer.clearCooldown("bilibili");
    return { ok: true, reason: "success", cards: cards.slice(0, limit) };
  } catch (error) {
    return {
      ok: false,
      reason: "error",
      cards: [],
      error: `B 站搜索采集失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
    };
  } finally {
    handle?.release();
  }
  });
}
