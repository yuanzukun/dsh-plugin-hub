/**
 * 抖音采集通道（视频评论 + 推荐视频发现），浏览器路径（已验证）：
 *
 * 实测（2026-08，真实 bsk 会话）：
 * - 抖音 web 端评论 API 在**页面内 fetch（自动带 cookie）无需 a_bogus/X-Bogus 签名**：
 *   GET /aweme/v1/web/comment/list/?aweme_id={id}&cursor={cursor}&count=20&item_type=0
 *   → { status_code:0, comments:[], cursor, has_more, total }（游标分页；实测 2726 条 total）
 * - 子评论：GET /aweme/v1/web/comment/list/reply/?comment_id={cid}&cursor=&count=&item_type=0&item_id={aweme_id}
 * - 搜索/详情/用户作品 API 在页面内 fetch（自动带 cookie）同样免 a_bogus 签名：
 *   GET /aweme/v1/web/general/search/single/ → data[].aweme_info（实测 25 条）
 *   GET /aweme/v1/web/aweme/detail/ → aweme_detail{desc,statistics,author}
 *   GET /aweme/v1/web/aweme/post/ → aweme_list{max_cursor,has_more}（实测 20 条/页）
 * - 搜索页 DOM 兜底：卡片容器 id="waterfall_item_{aweme_id}" + .search-result-card 文本。
 * - 抖音 PC 首页卡片点击不触发路由跳转（React 交互层特殊）→ 不依赖点击。
 *
 * 与微博/B站同构：navigate 视频页 → 页面内 fetch 评论 API（结构化 JSON）。
 */

import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import { isBrowserUnavailable, type BrowserSessionPool, type SessionHandle } from "../collect";
import type { PlatformPacer } from "../pacing";
import type { CommentEntry } from "../types";
import { unwrapEvaluateValue } from "./zhihu";
import { pollExtract, pollPageReady } from "./wait";

export type DouyinOutcomeReason = "success" | "empty" | "login_wall" | "rate_limited" | "error";

export interface DouyinDeps {
  pool: BrowserSessionPool;
  pacer: PlatformPacer;
  /** 页面渲染等待（毫秒，默认 4000）。 */
  renderWaitMs?: number;
}

export interface DouyinVideo {
  awemeId: string;
  url: string;
  title: string;
}

export interface DouyinStatistics {
  admireCount: number;
  collectCount: number;
  commentCount: number;
  diggCount: number;
  playCount: number;
  shareCount: number;
}

export interface DouyinSearchCard {
  awemeId: string;
  url: string;
  title: string;
  author: string;
  diggCount: number;
  commentCount: number;
  createTime: number;
}

export type DouyinSearchOutcomeReason = "success" | "empty" | "rate_limited" | "error";

export interface DouyinSearchOutcome {
  ok: boolean;
  reason: DouyinSearchOutcomeReason;
  cards: DouyinSearchCard[];
  backend?: "douyin-search-api" | "douyin-search-dom";
  error?: string;
}

export interface DouyinUserCard {
  awemeId: string;
  url: string;
  title: string;
  author: string;
  diggCount: number;
  commentCount: number;
  createTime: number;
}

export interface DouyinUserWorksOutcome {
  ok: boolean;
  reason: DouyinSearchOutcomeReason;
  cards: DouyinUserCard[];
  secUid?: string;
  error?: string;
}

/** 从 URL 提取抖音视频 aweme_id（/video/{id}、modal_id 参数）。 */
export function extractAwemeId(url: string): string | null {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host !== "douyin.com" && host !== "www.douyin.com" && host !== "v.douyin.com") return null;
    const m = parsed.pathname.match(/^\/video\/(\d{15,})/);
    if (m) return m[1];
    const modal = parsed.searchParams.get("modal_id");
    if (modal && /^\d{15,}$/.test(modal)) return modal;
    return null;
  } catch {
    return null;
  }
}

/** 是否为抖音短链（v.douyin.com，需重定向后从最终 URL 解析 aweme_id）。 */
export function isDouyinShortUrl(url: string): boolean {
  try {
    return new URL(url).hostname.toLowerCase() === "v.douyin.com";
  } catch {
    return false;
  }
}

/** 评论 API 页面内 fetch 脚本（cursor 游标分页）。 */
export function buildDouyinCommentsScript(awemeId: string, cursor: number): string {
  return `(async () => {
  try {
    const stripHtml = (html) => String(html || "")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, '"')
      .replace(/\\s+/g, " ").trim();
    const url = "/aweme/v1/web/comment/list/?aweme_id=${awemeId}&cursor=${cursor}&count=20&item_type=0";
    const res = await fetch(url, {
      credentials: "include",
      headers: { accept: "application/json, text/plain, */*", referer: "https://www.douyin.com/video/${awemeId}" },
    });
    if (!res.ok) return { ok: false, status: res.status };
    const j = await res.json();
    if (j.status_code !== 0) return { ok: false, statusCode: j.status_code };
    const list = Array.isArray(j.comments) ? j.comments : [];
    const out = [];
    for (const c of list) {
      if (!c || typeof c !== "object") continue;
      const text = stripHtml(c.text);
      if (!text) continue;
      out.push({
        cid: String(c.cid || ""),
        author: String((c.user && c.user.nickname) || ""),
        content: text.slice(0, 20000),
        replyTotal: Number(c.reply_comment_total) || 0,
      });
    }
    return { ok: true, count: out.length, items: out, cursor: Number(j.cursor) || 0, hasMore: j.has_more === 1, total: Number(j.total) || 0 };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 子评论 API 页面内 fetch 脚本（fail-soft）。 */
export function buildDouyinReplyScript(awemeId: string, commentId: string, cursor: number): string {
  return `(async () => {
  try {
    const stripHtml = (html) => String(html || "")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, '"')
      .replace(/\\s+/g, " ").trim();
    const url = "/aweme/v1/web/comment/list/reply/?comment_id=${commentId}&cursor=${cursor}&count=20&item_type=0&item_id=${awemeId}";
    const res = await fetch(url, {
      credentials: "include",
      headers: { accept: "application/json, text/plain, */*", referer: "https://www.douyin.com/video/${awemeId}" },
    });
    if (!res.ok) return { ok: false, status: res.status };
    const j = await res.json();
    if (j.status_code !== 0) return { ok: false, statusCode: j.status_code };
    const list = Array.isArray(j.comments) ? j.comments : [];
    const out = [];
    for (const c of list) {
      const text = stripHtml(c && c.text);
      if (text) out.push(text.slice(0, 20000));
    }
    return { ok: true, items: out };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 首页推荐视频发现脚本（SSR HTML 挖 videoRefs + 页面文本标题）。 */
export function buildDouyinTrendingScript(): string {
  return `(async () => {
  const html = document.documentElement.outerHTML;
  const seen = new Set();
  const out = [];
  const vre = /video\\/(\\d{15,})/g;
  let m;
  while ((m = vre.exec(html))) {
    const id = m[1];
    if (seen.has(id)) continue;
    seen.add(id);
    out.push({ awemeId: id, url: "https://www.douyin.com/video/" + id, title: "" });
    if (out.length >= 20) break;
  }
  // 标题尽力：页面文本里与视频时长相邻的文本（简单顺序采样）
  const bodyText = (document.body.innerText || "").replace(/\\s+/g, " ").trim();
  return { ok: true, count: out.length, items: out, bodySample: bodyText.slice(0, 300) };
})()`;
}

/** 解析评论返回。 */
export function parseDouyinComments(value: unknown): {
  ok: boolean;
  items: Array<{ cid: string; author: string; content: string; replyTotal: number }>;
  cursor: number;
  hasMore: boolean;
  total: number;
  error?: string;
} {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const items = Array.isArray(v.items) ? v.items : [];
    return {
      ok: v.ok === true,
      items: items
        .map((it) => {
          if (!it || typeof it !== "object") return null;
          const c = it as Record<string, unknown>;
          const content = String(c.content ?? "").trim();
          if (!content) return null;
          return {
            cid: String(c.cid ?? ""),
            author: String(c.author ?? ""),
            content,
            replyTotal: Number(c.replyTotal) || 0,
          };
        })
        .filter((c): c is { cid: string; author: string; content: string; replyTotal: number } => c !== null),
      cursor: Number(v.cursor) || 0,
      hasMore: v.hasMore === true,
      total: Number(v.total) || 0,
      error: typeof v.error === "string" ? v.error : undefined,
    };
  }
  return { ok: false, items: [], cursor: 0, hasMore: false, total: 0 };
}

// ---------------------------------------------------------------------------
// 搜索 / 详情 / 用户作品（2026-08 实测：页面内 fetch 免 a_bogus 签名）
// ---------------------------------------------------------------------------

/** 构造抖音综合搜索 URL（单次访问，不滚动不点击）。 */
export function buildDouyinSearchUrl(keyword: string): string {
  return `https://www.douyin.com/search/${encodeURIComponent(keyword)}?type=general`;
}

/** 搜索 API 页面内 fetch 脚本（结构化；offset 分页，参数对齐 cv-cat/DouYin_Spider）。 */
export function buildDouyinSearchScript(
  keyword: string,
  offset: number,
  filters: { sortType?: string; publishTime?: string; filterDuration?: string; searchRange?: string; contentType?: string } = {},
  count = 25,
): string {
  const filterJson = JSON.stringify({
    sort_type: filters.sortType ?? "0",
    publish_time: filters.publishTime ?? "0",
    filter_duration: filters.filterDuration ?? "",
    search_range: filters.searchRange ?? "0",
    content_type: filters.contentType ?? "0",
  });
  const referer = `https://www.douyin.com/search/${encodeURIComponent(keyword)}?type=general`;
  return `(async () => {
  try {
    const stripHtml = (html) => String(html || "")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, '"')
      .replace(/\\s+/g, " ").trim();
    const params = new URLSearchParams();
    params.set("device_platform", "webapp");
    params.set("aid", "6383");
    params.set("channel", "channel_pc_web");
    params.set("search_channel", "aweme_general");
    params.set("enable_history", "1");
    params.set("filter_selected", ${JSON.stringify(filterJson)});
    params.set("keyword", ${JSON.stringify(keyword)});
    params.set("search_source", "tab_search");
    params.set("query_correct_type", "1");
    params.set("is_filter_search", "1");
    params.set("from_group_id", "");
    params.set("offset", String(${offset}));
    params.set("count", String(${count}));
    params.set("need_filter_settings", ${offset === 0 ? '"1"' : '"0"'});
    params.set("list_type", "single");
    params.set("update_version_code", "170400");
    params.set("pc_client_type", "1");
    params.set("version_code", "190600");
    params.set("version_name", "19.6.0");
    params.set("cookie_enabled", "true");
    params.set("platform", "PC");
    const res = await fetch("/aweme/v1/web/general/search/single/?" + params.toString(), {
      credentials: "include",
      headers: { accept: "application/json, text/plain, */*", referer: ${JSON.stringify(referer)} },
    });
    if (!res.ok) return { ok: false, status: res.status };
    const j = await res.json();
    if (j.status_code !== 0) return { ok: false, statusCode: j.status_code };
    const data = Array.isArray(j.data) ? j.data : [];
    const items = [];
    for (const d of data) {
      const w = d && typeof d === "object" && d.aweme_info && typeof d.aweme_info === "object" ? d.aweme_info : null;
      if (!w) continue;
      const awemeId = String(w.aweme_id || "");
      if (!/^\\d{15,}$/.test(awemeId)) continue;
      const author = w.author && typeof w.author === "object" ? String(w.author.nickname || "") : "";
      const stat = w.statistics && typeof w.statistics === "object" ? w.statistics : {};
      items.push({
        awemeId,
        url: "https://www.douyin.com/video/" + awemeId,
        title: stripHtml(w.desc).slice(0, 500),
        author: author.slice(0, 120),
        diggCount: Number(stat.digg_count) || 0,
        commentCount: Number(stat.comment_count) || 0,
        createTime: Number(w.create_time) || 0,
      });
    }
    return { ok: true, count: items.length, items, hasMore: j.has_more === 1, nextOffset: ${offset} + data.length };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 搜索页 DOM 兜底脚本：卡片 id=waterfall_item_{aweme_id} + .search-result-card 文本。 */
export function buildDouyinSearchDomScript(): string {
  return `(async () => {
  const cards = [];
  const seen = new Set();
  const parseNum = (s) => {
    const t = String(s || "").replace(/[^0-9.万w]/gi, "");
    if (!t) return 0;
    if (/万|w/i.test(t)) return Math.round(parseFloat(t) * 10000);
    return Math.round(parseFloat(t) || 0);
  };
  document.querySelectorAll("[id^=\\"waterfall_item_\\"]").forEach((el) => {
    const m = (el.id || "").match(/waterfall_item_(\\d{15,})/);
    if (!m || seen.has(m[1])) return;
    seen.add(m[1]);
    const card = el.querySelector(".search-result-card") || el;
    const text = (card.innerText || "").replace(/\\s+/g, " ").trim();
    if (!text) return;
    const playM = text.match(/^\\d{1,2}:\\d{2}\\s+([\\d.]+[万w]?)/i);
    const authorM = text.match(/@([^\\s·]+)/);
    const title = text
      .replace(/^\\d{1,2}:\\d{2}\\s+([\\d.]+[万w]?\\s*)?/, "")
      .replace(/@[^\\s·]+.*$/, "")
      .trim()
      .slice(0, 500);
    cards.push({
      awemeId: m[1],
      url: "https://www.douyin.com/video/" + m[1],
      title,
      author: authorM ? authorM[1].trim().slice(0, 120) : "",
      diggCount: parseNum(playM ? playM[1] : ""),
      commentCount: 0,
      createTime: 0,
    });
  });
  return { ok: true, count: cards.length, items: cards };
})()`;
}

/** 解析搜索 API 一页（含 hasMore/nextOffset 供分页）。 */
export function parseDouyinSearchPage(value: unknown): {
  ok: boolean;
  cards: DouyinSearchCard[];
  hasMore: boolean;
  nextOffset: number;
  error?: string;
} {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return { ok: false, cards: [], hasMore: false, nextOffset: 0 };
  }
  const v = value as Record<string, unknown>;
  const items = Array.isArray(v.items) ? v.items : [];
  const cards: DouyinSearchCard[] = [];
  for (const raw of items) {
    if (!raw || typeof raw !== "object") continue;
    const c = raw as Record<string, unknown>;
    const awemeId = String(c.awemeId ?? "").trim();
    if (!/^\d{15,}$/.test(awemeId)) continue;
    cards.push({
      awemeId,
      url: String(c.url ?? `https://www.douyin.com/video/${awemeId}`),
      title: String(c.title ?? ""),
      author: String(c.author ?? ""),
      diggCount: Number(c.diggCount) || 0,
      commentCount: Number(c.commentCount) || 0,
      createTime: Number(c.createTime) || 0,
    });
  }
  return {
    ok: v.ok === true,
    cards,
    hasMore: v.hasMore === true,
    nextOffset: Number(v.nextOffset) || 0,
    error: typeof v.error === "string" ? v.error : undefined,
  };
}

/** 防御性解析搜索卡片数组（DOM 兜底/通用入口）。 */
export function parseDouyinSearchCards(value: unknown): DouyinSearchCard[] {
  return parseDouyinSearchPage(value).cards;
}

/** 作品详情 API 页面内 fetch 脚本（标题/作者/互动数）。 */
export function buildDouyinDetailScript(awemeId: string): string {
  return `(async () => {
  try {
    const stripHtml = (html) => String(html || "")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, '"')
      .replace(/\\s+/g, " ").trim();
    const url = "/aweme/v1/web/aweme/detail/?aweme_id=${awemeId}&device_platform=webapp&aid=6383&channel=channel_pc_web&pc_client_type=1&version_code=170400&version_name=17.4.0&cookie_enabled=true&platform=PC";
    const res = await fetch(url, {
      credentials: "include",
      headers: { accept: "application/json, text/plain, */*", referer: "https://www.douyin.com/video/${awemeId}" },
    });
    if (!res.ok) return { ok: false, status: res.status };
    const j = await res.json();
    if (j.status_code !== 0) return { ok: false, statusCode: j.status_code };
    const d = j.aweme_detail || {};
    const stat = d.statistics || {};
    return {
      ok: true,
      awemeId: String(d.aweme_id || ""),
      title: stripHtml(d.desc).slice(0, 500),
      author: d.author && typeof d.author === "object" ? String(d.author.nickname || "") : "",
      secUid: d.author && typeof d.author === "object" ? String(d.author.sec_uid || "") : "",
      statistics: {
        admireCount: Number(stat.admire_count) || 0,
        collectCount: Number(stat.collect_count) || 0,
        commentCount: Number(stat.comment_count) || 0,
        diggCount: Number(stat.digg_count) || 0,
        playCount: Number(stat.play_count) || 0,
        shareCount: Number(stat.share_count) || 0,
      },
    };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 解析详情 API 返回。 */
export function parseDouyinDetail(value: unknown): {
  ok: boolean;
  title: string;
  author: string;
  secUid: string;
  statistics?: DouyinStatistics;
  error?: string;
} {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const stat = v.statistics && typeof v.statistics === "object" ? (v.statistics as Record<string, unknown>) : {};
    return {
      ok: v.ok === true,
      title: String(v.title ?? ""),
      author: String(v.author ?? ""),
      secUid: String(v.secUid ?? ""),
      statistics: {
        admireCount: Number(stat.admireCount) || 0,
        collectCount: Number(stat.collectCount) || 0,
        commentCount: Number(stat.commentCount) || 0,
        diggCount: Number(stat.diggCount) || 0,
        playCount: Number(stat.playCount) || 0,
        shareCount: Number(stat.shareCount) || 0,
      },
      error: typeof v.error === "string" ? v.error : undefined,
    };
  }
  return { ok: false, title: "", author: "", secUid: "" };
}

/** 从用户主页 URL 提取 sec_uid（/user/{sec_uid} 形式）。 */
export function extractSecUid(userUrl: string): string | null {
  try {
    const parsed = new URL(userUrl);
    const m = parsed.pathname.match(/^\/user\/([^/?]+)/);
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

/** 用户作品 API 页面内 fetch 脚本（max_cursor 游标分页）。 */
export function buildDouyinUserWorksScript(secUid: string, cursor: number): string {
  return `(async () => {
  try {
    const stripHtml = (html) => String(html || "")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, '"')
      .replace(/\\s+/g, " ").trim();
    const params = new URLSearchParams();
    params.set("device_platform", "webapp");
    params.set("aid", "6383");
    params.set("channel", "channel_pc_web");
    params.set("sec_user_id", ${JSON.stringify(secUid)});
    params.set("max_cursor", String(${cursor}));
    params.set("locate_query", "false");
    params.set("count", "18");
    params.set("publish_video_strategy_type", "2");
    params.set("update_version_code", "170400");
    params.set("pc_client_type", "1");
    params.set("version_code", "170400");
    params.set("version_name", "17.4.0");
    params.set("cookie_enabled", "true");
    params.set("platform", "PC");
    const res = await fetch("/aweme/v1/web/aweme/post/?" + params.toString(), {
      credentials: "include",
      headers: { accept: "application/json, text/plain, */*", referer: "https://www.douyin.com/user/" + encodeURIComponent(${JSON.stringify(secUid)}) },
    });
    if (!res.ok) return { ok: false, status: res.status };
    const j = await res.json();
    if (j.status_code !== 0) return { ok: false, statusCode: j.status_code };
    const list = Array.isArray(j.aweme_list) ? j.aweme_list : [];
    const items = [];
    for (const w of list) {
      if (!w || typeof w !== "object") continue;
      const awemeId = String(w.aweme_id || "");
      if (!/^\\d{15,}$/.test(awemeId)) continue;
      const stat = w.statistics && typeof w.statistics === "object" ? w.statistics : {};
      const author = w.author && typeof w.author === "object" ? String(w.author.nickname || "") : "";
      items.push({
        awemeId,
        url: "https://www.douyin.com/video/" + awemeId,
        title: stripHtml(w.desc).slice(0, 500),
        author: author.slice(0, 120),
        diggCount: Number(stat.digg_count) || 0,
        commentCount: Number(stat.comment_count) || 0,
        createTime: Number(w.create_time) || 0,
      });
    }
    return { ok: true, count: items.length, items, hasMore: j.has_more === 1, maxCursor: Number(j.max_cursor) || 0 };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 解析用户作品 API 返回。 */
export function parseDouyinUserWorks(value: unknown): {
  ok: boolean;
  items: DouyinUserCard[];
  hasMore: boolean;
  maxCursor: number;
  error?: string;
} {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const items = Array.isArray(v.items) ? v.items : [];
    const cards: DouyinUserCard[] = [];
    for (const raw of items) {
      if (!raw || typeof raw !== "object") continue;
      const c = raw as Record<string, unknown>;
      const awemeId = String(c.awemeId ?? "").trim();
      if (!/^\d{15,}$/.test(awemeId)) continue;
      cards.push({
        awemeId,
        url: String(c.url ?? `https://www.douyin.com/video/${awemeId}`),
        title: String(c.title ?? ""),
        author: String(c.author ?? ""),
        diggCount: Number(c.diggCount) || 0,
        commentCount: Number(c.commentCount) || 0,
        createTime: Number(c.createTime) || 0,
      });
    }
    return {
      ok: v.ok === true,
      items: cards,
      hasMore: v.hasMore === true,
      maxCursor: Number(v.maxCursor) || 0,
      error: typeof v.error === "string" ? v.error : undefined,
    };
  }
  return { ok: false, items: [], hasMore: false, maxCursor: 0 };
}


function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function evalOn(
  handle: SessionHandle,
  exec: ToolRunContext,
  sessionId: string,
  script: string,
  label: string,
): Promise<unknown> {
  const raw = await handle.run(exec, ["evaluate", "--session", sessionId, script], label);
  return unwrapEvaluateValue(raw);
}

/** 导航到抖音页（带重试与风控识别）。浏览器基础设施失败（Chrome 关闭/bsk 断连）直接上抛，不计 strike。 */
async function navigateDouyin(
  handle: SessionHandle,
  exec: ToolRunContext,
  sessionId: string,
  url: string,
  deps: DouyinDeps,
  label: string,
): Promise<"ok" | "rate_limited"> {
  const run = (args: string[], l: string) => handle.run(exec, args, l);
  try {
    await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", url], label);
    return "ok";
  } catch (error) {
    if (isBrowserUnavailable(error)) throw error;
    await sleep(2000);
    try {
      await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", url], `${label} retry`);
      return "ok";
    } catch (error2) {
      if (isBrowserUnavailable(error2)) throw error2;
      deps.pacer.record("douyin", "rate_limited", { reason: `${label} timeout` });
      return "rate_limited";
    }
  }
}

/**
 * 抖音视频评论采集（浏览器路径，页面内 fetch 免签名）。
 * 支持 /video/{id}、modal_id 与 v.douyin.com 短链（navigate 后从最终 URL 解析 aweme_id）。
 * 主评论 cursor 分页 + 前 N 条评论的子评论（fail-soft）+ 视频元数据（fail-soft）。
 */
export async function collectDouyinComments(
  deps: DouyinDeps,
  exec: ToolRunContext,
  awemeIdOrUrl: string,
  opts: { maxComments?: number; maxRepliesPerComment?: number } = {},
): Promise<{
  ok: boolean;
  reason: DouyinOutcomeReason;
  title: string;
  author?: string;
  statistics?: DouyinStatistics;
  comments: CommentEntry[];
  error?: string;
}> {
  const maxComments = Math.max(1, opts.maxComments ?? 100);
  const maxReplies = Math.max(0, opts.maxRepliesPerComment ?? 5);
  const renderWait = deps.renderWaitMs ?? 4000;
  const initialAwemeId = extractAwemeId(awemeIdOrUrl);
  const navUrl = initialAwemeId
    ? `https://www.douyin.com/video/${initialAwemeId}`
    : awemeIdOrUrl; // v.douyin.com 短链：直接导航，等重定向后解析
  let handle: SessionHandle | null = null;
  try {
    handle = await deps.pool.acquire(exec);
    const sessionId = handle.sessionId;
    const run = (args: string[], label: string) => handle!.run(exec, args, label);

    const navResult = await navigateDouyin(handle, exec, sessionId, navUrl, deps, "douyin video navigate");
    if (navResult === "rate_limited") {
      return { ok: false, reason: "rate_limited", title: "", comments: [], error: "抖音导航超时（可能被风控挂起）：已进入平台冷却，稍后重试" };
    }
    // 条件等待：页面 readyState=complete 即开始（页面内本地探针；预算 = 原 renderWait）。
    // 消除「页面未就绪时 fetch 失败被误判 rate_limited 触发冷却」的隐患。
    await pollPageReady(
      async () => evalOn(handle!, exec, sessionId, `(async () => document.readyState)()`, "douyin ready"),
      { intervalMs: 600, maxMs: renderWait, signal: exec.signal },
    );

    // 短链/重定向后从最终 URL 解析 aweme_id（照抄快手 /f/ 分享链接模式）。
    let awemeId = initialAwemeId ?? "";
    if (!awemeId) {
      const locRaw = await evalOn(
        handle,
        exec,
        sessionId,
        `(async () => ({ href: location.href.slice(0, 300) }))()`,
        "douyin resolve short url",
      );
      const finalUrl = locRaw && typeof locRaw === "object" && !Array.isArray(locRaw)
        ? String((locRaw as Record<string, unknown>).href ?? "")
        : "";
      awemeId = extractAwemeId(finalUrl) ?? "";
      if (!awemeId) {
        return { ok: false, reason: "error", title: "", comments: [], error: "无法从抖音短链重定向后的 URL 解析视频 ID" };
      }
    }

    // 视频元数据（fail-soft：详情失败不阻断评论）。
    let title = "";
    let author = "";
    let statistics: DouyinStatistics | undefined;
    try {
      const detailRaw = await evalOn(handle, exec, sessionId, buildDouyinDetailScript(awemeId), "douyin detail");
      const detail = parseDouyinDetail(detailRaw);
      if (detail.ok) {
        title = detail.title;
        author = detail.author;
        statistics = detail.statistics;
      }
    } catch {
      // fail-soft
    }

    // 主评论分页（cursor 游标）
    const rawComments: Array<{ cid: string; author: string; content: string; replyTotal: number }> = [];
    let cursor = 0;
    let pages = 0;
    while (rawComments.length < maxComments && pages < 50) {
      if (exec.signal?.aborted) break;
      await deps.pacer.waitForSlot("douyin");
      const raw = await evalOn(handle, exec, sessionId, buildDouyinCommentsScript(awemeId, cursor), "douyin comments");
      const parsed = parseDouyinComments(raw);
      if (!parsed.ok) {
        if (parsed.error && /Failed to fetch|NetworkError/i.test(parsed.error)) {
          deps.pacer.record("douyin", "rate_limited", { reason: "comments fetch failed" });
          return { ok: false, reason: "rate_limited", title, author, statistics, comments: rawComments.slice(0, maxComments).map((c) => ({ author: c.author, content: c.content, replies: [] })), error: "抖音评论接口请求失败：已进入平台冷却" };
        }
        break; // 单页失败：保留已收集
      }
      rawComments.push(...parsed.items);
      if (parsed.items.length === 0 || !parsed.hasMore) break;
      cursor = parsed.cursor;
      pages += 1;
      await sleep(300);
    }

    if (rawComments.length === 0) {
      return { ok: true, reason: "empty", title, author, statistics, comments: [], error: "该视频暂无评论或评论接口未返回数据" };
    }

    // 子评论（前 maxReplies 条有回复的评论，fail-soft）
    const comments: CommentEntry[] = [];
    let replyBudget = maxReplies;
    for (const c of rawComments) {
      const entry: CommentEntry = { author: c.author, content: c.content, replies: [] };
      if (replyBudget > 0 && c.replyTotal > 0) {
        try {
          const raw = await evalOn(handle, exec, sessionId, buildDouyinReplyScript(awemeId, c.cid, 0), "douyin replies");
          const parsed = parseDouyinComments(raw);
          if (parsed.ok) entry.replies = parsed.items.map((r) => r.content).slice(0, 10);
        } catch {
          // 子评论失败不阻断
        }
        replyBudget -= 1;
        await sleep(200);
      }
      comments.push(entry);
      if (comments.length >= maxComments) break;
    }

    deps.pacer.reset("douyin");
    return { ok: true, reason: "success", title, author, statistics, comments: comments.slice(0, maxComments) };
  } catch (error) {
    return {
      ok: false,
      reason: "error",
      title: "",
      comments: [],
      error: `抖音评论采集失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
    };
  } finally {
    handle?.release();
  }
}

/**
 * 抖音推荐视频发现（首页 SSR HTML 挖 videoRefs；标题用详情 API best-effort 补全）。
 */
export async function collectDouyinTrending(
  deps: DouyinDeps,
  exec: ToolRunContext,
  opts: { limit?: number } = {},
): Promise<{ ok: boolean; reason: DouyinOutcomeReason; videos: DouyinVideo[]; error?: string }> {
  const limit = Math.max(1, opts.limit ?? 20);
  const renderWait = deps.renderWaitMs ?? 4000;
  let handle: SessionHandle | null = null;
  try {
    handle = await deps.pool.acquire(exec);
    const sessionId = handle.sessionId;
    const navResult = await navigateDouyin(handle, exec, sessionId, "https://www.douyin.com/", deps, "douyin home navigate");
    if (navResult === "rate_limited") {
      return { ok: false, reason: "rate_limited", videos: [], error: "抖音导航超时（可能被风控挂起）：已进入平台冷却" };
    }
    await sleep(renderWait);
    const raw = await evalOn(handle, exec, sessionId, buildDouyinTrendingScript(), "douyin trending");
    const value = raw && typeof raw === "object" && !Array.isArray(raw) ? (raw as Record<string, unknown>) : {};
    const items = Array.isArray(value.items) ? value.items : [];
    const videos: DouyinVideo[] = items
      .map((it) => {
        if (!it || typeof it !== "object") return null;
        const v = it as Record<string, unknown>;
        const awemeId = String(v.awemeId ?? "");
        if (!/^\d{15,}$/.test(awemeId)) return null;
        return { awemeId, url: `https://www.douyin.com/video/${awemeId}`, title: String(v.title ?? "") };
      })
      .filter((v): v is DouyinVideo => v !== null)
      .slice(0, limit);
    if (videos.length === 0) {
      return { ok: true, reason: "empty", videos: [], error: "首页未发现推荐视频（可能被风控或页面未渲染）" };
    }
    // 详情补标题（预算：前 5 条，fail-soft）
    for (const v of videos.slice(0, 5)) {
      try {
        await deps.pacer.waitForSlot("douyin");
        const detailRaw = await evalOn(handle, exec, sessionId, buildDouyinDetailScript(v.awemeId), "douyin trending detail");
        const detail = parseDouyinDetail(detailRaw);
        if (detail.ok && detail.title) v.title = detail.title;
      } catch {
        // fail-soft
      }
    }
    deps.pacer.reset("douyin");
    return { ok: true, reason: "success", videos };
  } catch (error) {
    return { ok: false, reason: "error", videos: [], error: `抖音发现失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300) };
  } finally {
    handle?.release();
  }
}

/**
 * 抖音关键词搜索发现（浏览器路径，单次访问）：搜索页 → 页面内 fetch 搜索 API（免签名），
 * API 空时 DOM 兜底（waterfall_item_{id} 卡片）；支持 sort_type/publish_time 筛选。
 */
export async function collectDouyinSearch(
  deps: DouyinDeps,
  exec: ToolRunContext,
  keyword: string,
  opts: { limit?: number; renderWaitMs?: number; sortType?: string; publishTime?: string } = {},
): Promise<DouyinSearchOutcome> {
  return deps.pacer.runExclusive("douyin", async () => {
    const limit = Math.max(1, opts.limit ?? 20);
    const renderWait = deps.renderWaitMs ?? opts.renderWaitMs ?? 4000;
    let handle: SessionHandle | null = null;
    try {
      handle = await deps.pool.acquire(exec);
      const sessionId = handle.sessionId;
      const navResult = await navigateDouyin(
        handle,
        exec,
        sessionId,
        buildDouyinSearchUrl(keyword),
        deps,
        "douyin search navigate",
      );
      if (navResult === "rate_limited") {
        return { ok: false, reason: "rate_limited", cards: [], error: "抖音搜索导航超时（可能被风控挂起）：已进入平台冷却，稍后重试" };
      }
      const filters = { sortType: opts.sortType, publishTime: opts.publishTime };
      const first = (await pollExtract(
        async () => {
          const apiRaw = await evalOn(handle!, exec, sessionId, buildDouyinSearchScript(keyword, 0, filters), "douyin search api");
          const apiPage = parseDouyinSearchPage(apiRaw);
          if (apiPage.ok && apiPage.cards.length > 0) return { ...apiPage, source: "api" as const };
          const domRaw = await evalOn(handle!, exec, sessionId, buildDouyinSearchDomScript(), "douyin search dom");
          const domCards = parseDouyinSearchCards(domRaw);
          return { ok: true, cards: domCards, hasMore: false, nextOffset: 0, source: "dom" as const };
        },
        (page) => page.cards.length > 0,
        { intervalMs: 600, maxMs: renderWait + 4000, signal: exec.signal },
      )) ?? { ok: true, cards: [], hasMore: false, nextOffset: 0, source: "dom" as const };

      const backend = first.source === "api" ? "douyin-search-api" : "douyin-search-dom";
      const cards = [...first.cards];
      let hasMore = first.hasMore;
      let nextOffset = first.nextOffset;
      let pages = 0;
      while (cards.length < limit && hasMore && pages < 5) {
        if (exec.signal?.aborted) break;
        await deps.pacer.waitForSlot("douyin");
        const raw = await evalOn(handle, exec, sessionId, buildDouyinSearchScript(keyword, nextOffset, filters), "douyin search page");
        const page = parseDouyinSearchPage(raw);
        if (!page.ok || page.cards.length === 0) break;
        cards.push(...page.cards);
        hasMore = page.hasMore;
        nextOffset = page.nextOffset;
        pages += 1;
        await sleep(300);
      }

      if (cards.length === 0) {
        return { ok: true, reason: "empty", cards: [], backend, error: "抖音搜索页未提取到视频卡片（结果为空或页面结构变化）" };
      }
      deps.pacer.reset("douyin");
      return { ok: true, reason: "success", cards: cards.slice(0, limit), backend };
    } catch (error) {
      return {
        ok: false,
        reason: "error",
        cards: [],
        error: `抖音搜索采集失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
      };
    } finally {
      handle?.release();
    }
  });
}

/**
 * 抖音用户作品发现（浏览器路径，单次访问）：/user/{sec_uid} 页面内 fetch aweme/post，
 * max_cursor 游标分页返回作品列表。
 */
export async function collectDouyinUserWorks(
  deps: DouyinDeps,
  exec: ToolRunContext,
  userUrl: string,
  opts: { limit?: number; renderWaitMs?: number } = {},
): Promise<DouyinUserWorksOutcome> {
  const secUid = extractSecUid(userUrl);
  if (!secUid) {
    return { ok: false, reason: "error", cards: [], error: "无法从 URL 提取抖音用户 sec_uid（需要 /user/{sec_uid} 形式）" };
  }
  return deps.pacer.runExclusive("douyin", async () => {
    const limit = Math.max(1, opts.limit ?? 20);
    const renderWait = deps.renderWaitMs ?? opts.renderWaitMs ?? 4000;
    let handle: SessionHandle | null = null;
    try {
      handle = await deps.pool.acquire(exec);
      const sessionId = handle.sessionId;
      const navResult = await navigateDouyin(
        handle,
        exec,
        sessionId,
        `https://www.douyin.com/user/${secUid}`,
        deps,
        "douyin user navigate",
      );
      if (navResult === "rate_limited") {
        return { ok: false, reason: "rate_limited", cards: [], secUid, error: "抖音用户页导航超时（可能被风控挂起）：已进入平台冷却，稍后重试" };
      }
      await pollPageReady(
        async () => evalOn(handle!, exec, sessionId, `(async () => document.readyState)()`, "douyin user ready"),
        { intervalMs: 600, maxMs: renderWait, signal: exec.signal },
      );

      const cards: DouyinUserCard[] = [];
      let cursor = 0;
      let pages = 0;
      while (cards.length < limit && pages < 5) {
        if (exec.signal?.aborted) break;
        await deps.pacer.waitForSlot("douyin");
        const raw = await evalOn(handle, exec, sessionId, buildDouyinUserWorksScript(secUid, cursor), "douyin user works");
        const parsed = parseDouyinUserWorks(raw);
        if (!parsed.ok) {
          if (parsed.error && /Failed to fetch|NetworkError/i.test(parsed.error)) {
            deps.pacer.record("douyin", "rate_limited", { reason: "user works fetch failed" });
            return { ok: false, reason: "rate_limited", cards: cards.slice(0, limit), secUid, error: "抖音用户作品接口请求失败：已进入平台冷却" };
          }
          break;
        }
        cards.push(...parsed.items);
        if (!parsed.hasMore || parsed.items.length === 0) break;
        cursor = parsed.maxCursor;
        pages += 1;
        await sleep(300);
      }
      if (cards.length === 0) {
        return { ok: true, reason: "empty", cards: [], secUid, error: "未获取到该用户作品（可能为空或接口未返回数据）" };
      }
      deps.pacer.reset("douyin");
      return { ok: true, reason: "success", cards: cards.slice(0, limit), secUid };
    } catch (error) {
      return {
        ok: false,
        reason: "error",
        cards: [],
        secUid,
        error: `抖音用户作品采集失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
      };
    } finally {
      handle?.release();
    }
  });
}
