/**
 * 知乎 API 通道（回答 + 评论）：在 bsk 会话页面上下文内同源 fetch 知乎官方 API。
 *
 * 为什么在浏览器里 fetch 而不是后端直连？
 * - 知乎 web 端 API 需要 x-zse-96 签名，该签名无法稳定逆向（平台持续更换算法）。
 * - 在真实浏览器会话中 `fetch('/api/v4/...', { credentials: 'include' })` 复用
 *   登录态与同源环境，是 OpenBiliClaw 生产验证过的路径（extension/src/content/zhihu/task-executor.ts）。
 * - 后端零代登录：cookie 不出浏览器、不落盘。
 *
 * 端点：
 * - GET /api/v4/questions/{qid}/feeds?limit=&offset=         回答流（含 comment_count）
 * - GET /api/v4/answers/{aid}/comments?limit=&offset=        回答评论区
 *
 * 依赖 bsk CLI 的 `evaluate --session <id> <expr>`（页面内执行 JS，awaitPromise，
 * return-by-value 返回 JSON）。
 */

import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import type { BrowserSessionPool, SessionHandle } from "../collect";
import type { PlatformPacer } from "../pacing";
import type { CommentEntry } from "../types";

export type ZhihuOutcomeReason = "success" | "unavailable" | "login_wall" | "error";

export interface ZhihuOptions {
  /** 最多取多少条回答（默认 50）。 */
  maxAnswers?: number;
  /** 对前 N 条回答取评论区（默认 10）。 */
  maxAnswerComments?: number;
  /** 每条回答最多取多少条评论（默认 20）。 */
  commentsPerAnswer?: number;
}

export interface ZhihuDeps {
  pool: BrowserSessionPool;
  pacer: PlatformPacer;
  /** 每轮 evaluate 的等待间隔（毫秒，默认 300）。 */
  pageIntervalMs?: number;
}

export interface ZhihuCollectOutcome {
  ok: boolean;
  reason: ZhihuOutcomeReason;
  /** 页面标题（第一轮 evaluate 顺带返回）。 */
  title: string;
  /** 归一化回答 + 评论区。 */
  answers: CommentEntry[];
  error?: string;
}

const FEEDS_PAGE = 20;
const COMMENTS_PAGE = 20;
const EVALUATE_TIMEOUT_HINT = /timed out|Timeout/i;

/** 从 URL 提取知乎问题 id（仅 zhihu.com 域，/question/{qid}）。 */
export function extractZhihuQid(url: string): string | null {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host !== "zhihu.com" && !host.endsWith(".zhihu.com")) return null;
    const m = parsed.pathname.match(/^\/question\/(\d+)/);
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

/** 回答流页面内 fetch 脚本（async IIFE，返回可 JSON 序列化的最小对象）。 */
export function buildZhihuFeedsScript(qid: string, offset: number, limit: number): string {
  const q = encodeURIComponent(qid);
  const url = `/api/v4/questions/${q}/feeds?limit=${limit}&offset=${offset}`;
  return `(async () => {
  try {
    const res = await fetch(${JSON.stringify(url)}, { credentials: "include" });
    if (!res.ok) return { ok: false, status: res.status };
    const json = await res.json();
    const items = Array.isArray(json.data) ? json.data : [];
    const out = [];
    for (const it of items) {
      if (!it || typeof it !== "object") continue;
      const t = it.target && typeof it.target === "object" ? it.target : it;
      const author = (t.author && typeof t.author === "object" ? t.author.name : "") || "";
      const excerpt = typeof t.excerpt === "string" ? t.excerpt : (typeof t.content === "string" ? t.content : "");
      const cc = Number(t.comment_count != null ? t.comment_count : (t.commentCount != null ? t.commentCount : 0));
      const vu = Number(t.voteup_count != null ? t.voteup_count : (t.voteupCount != null ? t.voteupCount : 0));
      out.push({
        id: String(t.id != null ? t.id : (it.id != null ? it.id : "")),
        author: String(author),
        content: String(excerpt).slice(0, 20000),
        commentCount: Number.isFinite(cc) ? cc : 0,
        voteup: Number.isFinite(vu) ? vu : 0,
      });
    }
    return { ok: true, isEnd: json.paging && json.paging.is_end === true, pageTitle: typeof document !== "undefined" ? document.title : "", items: out };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 回答评论区页面内 fetch 脚本。 */
export function buildZhihuCommentsScript(answerId: string, offset: number, limit: number): string {
  const a = encodeURIComponent(answerId);
  const url = `/api/v4/answers/${a}/comments?limit=${limit}&offset=${offset}`;
  return `(async () => {
  try {
    const res = await fetch(${JSON.stringify(url)}, { credentials: "include" });
    if (!res.ok) return { ok: false, status: res.status };
    const json = await res.json();
    const items = Array.isArray(json.data) ? json.data : [];
    const out = [];
    for (const it of items) {
      if (!it || typeof it !== "object") continue;
      const authorRaw = it.author && typeof it.author === "object" ? it.author.name : it.author;
      const author = typeof authorRaw === "string" ? authorRaw : "";
      const content = typeof it.content === "string" ? it.content : "";
      if (!content) continue;
      out.push({ author: String(author), content });
    }
    return { ok: true, isEnd: json.paging && json.paging.is_end === true, items: out };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 归一化 bsk evaluate 的返回（兼容 CLI 包装 {ok, tab_id, value} 与通用 {result}）。 */
export function unwrapEvaluateValue(parsed: unknown): unknown {
  if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
    const p = parsed as Record<string, unknown>;
    // bsk evaluate --json 实际形状：{ ok: true, tab_id: ..., value: <表达式结果> }
    if ("value" in p && "ok" in p && typeof p.ok === "boolean") return p.value;
    if ("result" in p && Object.keys(p).length <= 2) return p.result;
  }
  return parsed;
}

interface EvaluatePayload {
  ok: boolean;
  status?: number;
  isEnd?: boolean;
  error?: string;
  pageTitle?: string;
  items?: unknown[];
}

/** 防御性解析 evaluate 返回的 {ok, items, ...}。 */
export function parseEvaluatePayload(value: unknown): EvaluatePayload {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    return {
      ok: v.ok === true,
      status: typeof v.status === "number" ? v.status : undefined,
      isEnd: v.isEnd === true,
      error: typeof v.error === "string" ? v.error : undefined,
      pageTitle: typeof v.pageTitle === "string" ? v.pageTitle : undefined,
      items: Array.isArray(v.items) ? v.items : [],
    };
  }
  return { ok: false, error: "evaluate 返回非对象" };
}

interface ZhihuAnswerRaw {
  id: string;
  author: string;
  content: string;
  commentCount: number;
  voteup: number;
}

/**
 * 归一化单条回答（防御字段缺失；兼容 target 包裹结构；大整数 id 转字符串）。
 * 无 id 返回 null。
 */
export function toAnswerRaw(item: unknown): ZhihuAnswerRaw | null {
  if (!item || typeof item !== "object") return null;
  const it = item as Record<string, unknown>;
  // feeds 条目可能为 { target: {...} } 包裹；页面脚本已解包，这里双保险
  const t =
    it.target && typeof it.target === "object" ? (it.target as Record<string, unknown>) : it;
  const id = String(t.id ?? "");
  if (!id) return null;
  const authorObj = t.author && typeof t.author === "object" ? (t.author as Record<string, unknown>) : null;
  const author = String(authorObj ? authorObj.name ?? "" : (t.author ?? ""));
  const content = String(typeof t.excerpt === "string" ? t.excerpt : (typeof t.content === "string" ? t.content : ""));
  return {
    id,
    author,
    content,
    commentCount: Number(t.comment_count ?? t.commentCount) || 0,
    voteup: Number(t.voteup_count ?? t.voteupCount) || 0,
  };
}

/** 一轮页面内 fetch（evaluate）。超时/网络错误最多重试一次。 */
async function evaluateFetch(
  deps: ZhihuDeps,
  exec: ToolRunContext,
  handle: SessionHandle,
  sessionId: string,
  script: string,
): Promise<EvaluatePayload> {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const raw = await handle.run(
        exec,
        ["evaluate", "--session", sessionId, script],
        "zhihu fetch",
      );
      const value = unwrapEvaluateValue(raw);
      const payload = parseEvaluatePayload(value);
      // 页面内网络错误（fetch 抛异常）→ 重试一次
      if (!payload.ok && !payload.status && payload.error && attempt === 0) {
        await sleep(deps.pageIntervalMs ?? 300);
        continue;
      }
      return payload;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (EVALUATE_TIMEOUT_HINT.test(message) && attempt === 0) {
        await sleep(deps.pageIntervalMs ?? 300);
        continue;
      }
      return { ok: false, error: message.slice(0, 300) };
    }
  }
  return { ok: false, error: "evaluate 重试耗尽" };
}

/**
 * 知乎回答 + 评论区采集（bsk 会话内同源 fetch）。
 * 失败分三类：unavailable（bsk/浏览器不可用）/ login_wall（未登录或登录墙）/
 * error（其他，可降级原路径）。
 */
export async function collectZhihuAnswers(
  deps: ZhihuDeps,
  exec: ToolRunContext,
  qid: string,
  opts: ZhihuOptions = {},
): Promise<ZhihuCollectOutcome> {
  const maxAnswers = Math.max(1, opts.maxAnswers ?? 50);
  const maxAnswerComments = Math.max(0, opts.maxAnswerComments ?? 10);
  const commentsPerAnswer = Math.max(0, opts.commentsPerAnswer ?? COMMENTS_PAGE);
  const interval = deps.pageIntervalMs ?? 300;

  let handle: SessionHandle | null = null;
  try {
    try {
      handle = await deps.pool.acquire(exec);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return {
        ok: false,
        reason: "unavailable",
        title: "",
        answers: [],
        error: message.slice(0, 300),
      };
    }
    const sessionId = handle.sessionId;
    const run = (args: string[], label: string) => handle!.run(exec, args, label);

    // 导航到问题页，确保页面域为 zhihu.com（同源 fetch 前提）；失败则不可用
    try {
      await run(["navigate", "--session", sessionId, `https://www.zhihu.com/question/${qid}`], "zhihu navigate");
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return { ok: false, reason: "error", title: "", answers: [], error: `导航失败：${message.slice(0, 200)}` };
    }

    // 分页拉取回答流
    const rawAnswers: ZhihuAnswerRaw[] = [];
    let title = "";
    let loginWall = false;
    for (let offset = 0; offset < maxAnswers; offset += FEEDS_PAGE) {
      if (exec.signal?.aborted) break;
      await deps.pacer.waitForSlot("zhihu");
      const payload = await evaluateFetch(deps, exec, handle, sessionId, buildZhihuFeedsScript(qid, offset, FEEDS_PAGE));
      if (payload.ok) {
        if (payload.pageTitle && !title) title = payload.pageTitle.replace(/\s*[-_|]\s*知乎\s*$/, "").trim();
        for (const item of payload.items ?? []) {
          const raw = toAnswerRaw(item);
          if (raw) rawAnswers.push(raw);
          if (rawAnswers.length >= maxAnswers) break;
        }
        if (payload.isEnd || (payload.items ?? []).length === 0 || rawAnswers.length >= maxAnswers) break;
      } else if (payload.status === 401 || payload.status === 403) {
        loginWall = true;
        break;
      } else {
        // 单轮失败：整体降级（保守，避免半成品）
        return {
          ok: false,
          reason: "error",
          title,
          answers: [],
          error: payload.error ? `回答流获取失败：${payload.error}` : "回答流获取失败（未知错误）",
        };
      }
      await sleep(interval);
    }

    if (loginWall) {
      return {
        ok: false,
        reason: "login_wall",
        title,
        answers: [],
        error: "知乎页面未登录或触发登录墙（请在浏览器中登录知乎后重试）",
      };
    }

    // 对前 N 条有评论的回答取评论区
    const comments = new Map<string, string[]>();
    let commentBudget = maxAnswerComments;
    for (const answer of rawAnswers) {
      if (commentBudget <= 0) break;
      if (answer.commentCount <= 0) continue;
      if (exec.signal?.aborted) break;
      const list: string[] = [];
      for (let offset = 0; offset < commentsPerAnswer; offset += COMMENTS_PAGE) {
        await deps.pacer.waitForSlot("zhihu");
        const payload = await evaluateFetch(deps, exec, handle, sessionId, buildZhihuCommentsScript(answer.id, offset, COMMENTS_PAGE));
        if (!payload.ok) {
          if (payload.status === 401 || payload.status === 403) {
            loginWall = true;
            break;
          }
          break; // 单回答评论区失败：跳过该回答，不阻断整体
        }
        for (const item of payload.items ?? []) {
          if (item && typeof item === "object") {
            const it = item as Record<string, unknown>;
            const text = String(it.content ?? "").trim();
            if (text) list.push(text);
          }
        }
        if (payload.isEnd || (payload.items ?? []).length === 0) break;
        await sleep(interval);
      }
      comments.set(answer.id, list);
      commentBudget -= 1;
      if (loginWall) break;
    }

    if (loginWall) {
      return {
        ok: false,
        reason: "login_wall",
        title,
        answers: [],
        error: "知乎页面未登录或触发登录墙（请在浏览器中登录知乎后重试）",
      };
    }

    const answers: CommentEntry[] = rawAnswers.map((a) => ({
      author: a.author,
      content: a.content,
      replies: comments.get(a.id) ?? [],
    }));
    deps.pacer.reset("zhihu");
    return { ok: true, reason: "success", title, answers };
  } finally {
    handle?.release();
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
