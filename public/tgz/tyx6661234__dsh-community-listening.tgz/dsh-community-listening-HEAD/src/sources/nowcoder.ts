/**
 * 牛客采集通道（讨论帖评论），浏览器路径（已验证）：
 *
 * 实测（2026-08，真实 bsk 会话）：
 * - nowcoder.com/discuss/{postId} 讨论帖页 SSR 渲染完整（标题/作者/浏览数/评论区）。
 * - 评论区 DOM：每条评论为 `section.comment-box`：
 *   - 作者：`header[class*='content-user-info']`（文本首 token）
 *   - 内容：`div[class*='comment-rich-text']`
 *   - 楼中楼：comment-box 内嵌套回复（可扩展）
 * - SSR state（__INITIAL_STATE__）不含评论区数据（评论由组件渲染）→ 走 DOM 提取。
 * - 牛客风控相对宽松（国内社区）；导航超时/页面异常 → nowcoder 平台冷却（复用 generic 规格）。
 */

import type { ToolRunContext } from "@deepseek-ai/dsh-tools";
import { isBrowserUnavailable, type BrowserSessionPool, type SessionHandle } from "../collect";
import type { PlatformPacer } from "../pacing";
import type { CommentEntry } from "../types";
import { unwrapEvaluateValue } from "./zhihu";
import { pollPageReady } from "./wait";

export type NowcoderOutcomeReason = "success" | "empty" | "login_wall" | "rate_limited" | "error";

export interface NowcoderDeps {
  pool: BrowserSessionPool;
  pacer: PlatformPacer;
  /** 页面渲染等待（毫秒，默认 4000）。 */
  renderWaitMs?: number;
}

/** 从 URL 提取牛客讨论帖 id（/discuss/{id}）。 */
export function extractNowcoderPostId(url: string): string | null {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host !== "nowcoder.com" && host !== "www.nowcoder.com") return null;
    const m = parsed.pathname.match(/^\/discuss\/(\d+)/);
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

/** 页面内提取讨论帖评论区脚本（DOM，.comment-box）。 */
export function buildNowcoderCommentsScript(): string {
  return `(async () => {
  try {
    const out = [];
    const boxes = document.querySelectorAll("section.comment-box, [class*='comment-box']");
    for (const box of boxes) {
      const authorEl = box.querySelector("header[class*='content-user-info'], [class*='content-user-info']");
      const contentEl = box.querySelector("div[class*='comment-rich-text'], [class*='comment-rich-text']");
      const author = authorEl ? (authorEl.innerText || "").replace(/\\s+/g, " ").trim() : "";
      const content = contentEl ? (contentEl.innerText || "").replace(/\\s+/g, " ").trim() : "";
      if (!content) continue;
      out.push({
        author: String(author).split(/\\s+/)[0] || "",
        content: String(content).slice(0, 20000),
      });
    }
    return { ok: true, count: out.length, items: out };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
})()`;
}

/** 解析评论返回。 */
export function parseNowcoderComments(value: unknown): {
  ok: boolean;
  items: CommentEntry[];
  error?: string;
} {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const v = value as Record<string, unknown>;
    const items = Array.isArray(v.items) ? v.items : [];
    return {
      ok: v.ok === true,
      items: items
        .map((it) => {
          if (!it || typeof it !== "object") return null;
          const c = it as Record<string, unknown>;
          const content = String(c.content ?? "").trim();
          if (!content) return null;
          return { author: String(c.author ?? ""), content, replies: [] as string[] };
        })
        .filter((c): c is CommentEntry => c !== null),
      error: typeof v.error === "string" ? v.error : undefined,
    };
  }
  return { ok: false, items: [] };
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function evalOn(
  handle: SessionHandle,
  exec: ToolRunContext,
  sessionId: string,
  script: string,
  label: string,
): Promise<unknown> {
  const raw = await handle.run(exec, ["evaluate", "--session", sessionId, script], label);
  return unwrapEvaluateValue(raw);
}

/**
 * 牛客讨论帖评论采集（浏览器路径，DOM 提取 SSR 首屏评论）。
 */
export async function collectNowcoderComments(
  deps: NowcoderDeps,
  exec: ToolRunContext,
  url: string,
  opts: { maxComments?: number } = {},
): Promise<{ ok: boolean; reason: NowcoderOutcomeReason; title: string; comments: CommentEntry[]; error?: string }> {
  const maxComments = Math.max(1, opts.maxComments ?? 100);
  const renderWait = deps.renderWaitMs ?? 4000;
  let handle: SessionHandle | null = null;
  try {
    handle = await deps.pool.acquire(exec);
    const sessionId = handle.sessionId;
    const run = (args: string[], label: string) => handle!.run(exec, args, label);

    // navigate 讨论帖（带重试）；浏览器基础设施失败（Chrome 关闭/bsk 断连）直接上抛，不计 strike
    let navError = "";
    try {
      await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", url], "nowcoder navigate");
    } catch (error) {
      if (isBrowserUnavailable(error)) throw error;
      navError = error instanceof Error ? error.message : String(error);
      await sleep(2000);
      try {
        await run(["navigate", "--session", sessionId, "--wait-until", "domcontentloaded", "--timeout", "20s", url], "nowcoder navigate retry");
      } catch (error2) {
        if (isBrowserUnavailable(error2)) throw error2;
        deps.pacer.record("nowcoder", "rate_limited", { reason: `navigate timeout: ${navError.slice(0, 120)}` });
        return { ok: false, reason: "rate_limited", title: "", comments: [], error: "牛客导航超时（可能被风控挂起）：已进入平台冷却，稍后重试" };
      }
    }
    // 条件等待：页面 readyState=complete 即开始（页面内本地探针；预算 = 原 renderWait）
    await pollPageReady(
      async () => evalOn(handle!, exec, sessionId, `(async () => document.readyState)()`, "nowcoder ready"),
      { intervalMs: 600, maxMs: renderWait, signal: exec.signal },
    );

    // 页面标题（帖子标题）
    const meta = await evalOn(handle, exec, sessionId, `(async () => ({ title: document.title.slice(0, 120) }))()`, "nowcoder title");
    const title = meta && typeof meta === "object" && !Array.isArray(meta)
      ? String((meta as Record<string, unknown>).title ?? "")
      : "";

    // 提取评论（DOM）
    const raw = await evalOn(handle, exec, sessionId, buildNowcoderCommentsScript(), "nowcoder comments");
    const parsed = parseNowcoderComments(raw);
    if (!parsed.ok) {
      return { ok: false, reason: "error", title, comments: [], error: parsed.error ? `评论提取失败：${parsed.error}` : "评论提取失败" };
    }
    const comments = parsed.items.slice(0, maxComments);
    if (comments.length === 0) {
      return { ok: true, reason: "empty", title, comments: [], error: "讨论帖暂无评论或评论区未渲染" };
    }
    deps.pacer.reset("nowcoder");
    return { ok: true, reason: "success", title, comments };
  } catch (error) {
    return {
      ok: false,
      reason: "error",
      title: "",
      comments: [],
      error: `牛客评论采集失败：${error instanceof Error ? error.message : String(error)}`.slice(0, 300),
    };
  } finally {
    handle?.release();
  }
}
