/**
 * 平台级节流 / 冷却 / 指数退避（对齐 OpenBiliClaw 的 rate-limit circuit breaker
 * 与 B 站 search cooldown：base × 2^strikes，cap 上限，冷却窗口只延长不缩短）。
 *
 * 解决「越采越被封」：社区平台（知乎 / 小红书 / B 站等）对高频、并发、代理出口
 * 的请求做风控。本模块提供：
 * - 平台映射（URL host → platform 键）
 * - 事件上报 record()：验证码 / 限流 / 403 触发指数退避冷却；登录墙不触发
 * - 冷却查询 isCoolingDown() / cooldownRemainingMs()
 * - 同平台请求最小间隔串行化 waitForSlot()
 * - 状态可选落盘 JSON（跨进程重启存活），原子写
 *
 * 纯逻辑可单测（now / 落盘路径可注入）。
 */

import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";

export type PacingKind = "captcha" | "rate_limited" | "http_403" | "login_wall";

/** 触发冷却的事件（登录墙不算风控，不冷却）。 */
export const COOLDOWN_KINDS: ReadonlySet<PacingKind> = new Set([
  "captcha",
  "rate_limited",
  "http_403",
]);

/** 冷却结束超过该时长后，历史 strike 自动衰减归零（避免旧状态把平台长期锁死）。 */
const STRIKE_DECAY_MS = 10 * 60_000;

export interface PlatformSpec {
  /** 冷却起始基数（秒）。 */
  baseCooldownSeconds: number;
  /** 冷却上限（秒）。 */
  maxCooldownSeconds: number;
  /** 同平台请求最小间隔（毫秒），API 直连通道串行化用。 */
  minIntervalMs: number;
}

/** 默认平台规格（可整体覆盖）。 */
export const DEFAULT_PLATFORM_SPECS: Record<string, PlatformSpec> = {
  zhihu: { baseCooldownSeconds: 60, maxCooldownSeconds: 1800, minIntervalMs: 1500 },
  bilibili: { baseCooldownSeconds: 30, maxCooldownSeconds: 1800, minIntervalMs: 800 },
  // 小红书实测冷却窗口为数十分钟级（导航挂起后 60s 就重试只会加深服务端标记）；
  // 基数 900s（15 分钟），退避后更快逼近真实窗口。
  xiaohongshu: { baseCooldownSeconds: 900, maxCooldownSeconds: 1800, minIntervalMs: 2000 },
  weibo: { baseCooldownSeconds: 30, maxCooldownSeconds: 1800, minIntervalMs: 800 },
  douyin: { baseCooldownSeconds: 30, maxCooldownSeconds: 1800, minIntervalMs: 800 },
  kuaishou: { baseCooldownSeconds: 30, maxCooldownSeconds: 1800, minIntervalMs: 800 },
  nowcoder: { baseCooldownSeconds: 30, maxCooldownSeconds: 1800, minIntervalMs: 800 },
  tieba: { baseCooldownSeconds: 30, maxCooldownSeconds: 1800, minIntervalMs: 800 },
  generic: { baseCooldownSeconds: 60, maxCooldownSeconds: 1800, minIntervalMs: 1000 },
};

/** 常见社区 host → platform 键。 */
const PLATFORM_HOSTS: Record<string, string> = {
  "www.zhihu.com": "zhihu",
  "zhihu.com": "zhihu",
  "api.zhihu.com": "zhihu",
  "www.bilibili.com": "bilibili",
  "bilibili.com": "bilibili",
  "api.bilibili.com": "bilibili",
  "www.xiaohongshu.com": "xiaohongshu",
  "xiaohongshu.com": "xiaohongshu",
  "m.weibo.cn": "weibo",
  "weibo.com": "weibo",
  "www.weibo.com": "weibo",
  "api.weibo.com": "weibo",
  "www.douyin.com": "douyin",
  "douyin.com": "douyin",
  "v.douyin.com": "douyin",
  "www.kuaishou.com": "kuaishou",
  "kuaishou.com": "kuaishou",
  "v.kuaishou.com": "kuaishou",
  "www.nowcoder.com": "nowcoder",
  "nowcoder.com": "nowcoder",
  "tieba.baidu.com": "tieba",
};

/** URL host → platform 键（未知 host 归 generic）。 */
export function platformForUrl(url: string): string {
  try {
    const host = new URL(url).hostname.toLowerCase();
    return PLATFORM_HOSTS[host] ?? "generic";
  } catch {
    return "generic";
  }
}

interface PlatformState {
  /** 冷却截止（epoch ms）。 */
  cooldownUntil: number;
  /** 连续风控 strike 数（决定退避指数）。 */
  strikes: number;
  /** 上次请求时刻（epoch ms），最小间隔串行化用。 */
  lastRequestAt: number;
  /** 最近一次冷却原因。 */
  reason: string;
}

interface PacingSnapshot {
  version: 1;
  state: Record<string, PlatformState>;
}

export interface PlatformPacerOptions {
  /** 状态落盘路径（留空仅内存）。 */
  stateFile?: string;
  /** 平台规格覆盖。 */
  specs?: Record<string, PlatformSpec>;
  /** 时钟注入（测试用）。 */
  now?: () => number;
  /** 落盘失败静默（默认 true）。 */
  silent?: boolean;
  /** 最小间隔抖动比例（0-1；默认 0.2，即 ±20%；0 = 完全等间隔，保持旧行为）。 */
  jitterRatio?: number;
  /** 随机数注入（测试用；默认 Math.random）。 */
  random?: () => number;
  /** 睡眠注入（测试用；默认 setTimeout）。 */
  sleep?: (ms: number) => Promise<void>;
}

export class PlatformPacer {
  private readonly specs: Record<string, PlatformSpec>;
  private readonly stateFile: string;
  private readonly nowFn: () => number;
  private readonly silent: boolean;
  private readonly jitterRatio: number;
  private readonly randomFn: () => number;
  private readonly sleepFn: (ms: number) => Promise<void>;
  private state: Record<string, PlatformState> = {};
  /** 同平台串行锁队列（跨并发调用：评论/搜索/API 直连共用同一 pacer 实例时生效）。 */
  private exclusive = new Map<string, Promise<void>>();
  private disposed = false;

  constructor(options: PlatformPacerOptions = {}) {
    this.specs = { ...DEFAULT_PLATFORM_SPECS, ...(options.specs ?? {}) };
    this.stateFile = options.stateFile ?? "";
    this.nowFn = options.now ?? (() => Date.now());
    this.silent = options.silent ?? true;
    this.jitterRatio = Math.max(0, Math.min(1, options.jitterRatio ?? 0.2));
    this.randomFn = options.random ?? Math.random;
    this.sleepFn = options.sleep ?? sleep;
    if (this.stateFile) this.load();
  }

  private now(): number {
    return this.nowFn();
  }

  private spec(platform: string): PlatformSpec {
    return this.specs[platform] ?? this.specs.generic;
  }

  private ensure(platform: string): PlatformState {
    let st = this.state[platform];
    if (!st) {
      st = { cooldownUntil: 0, strikes: 0, lastRequestAt: 0, reason: "" };
      this.state[platform] = st;
    }
    return st;
  }

  /** 历史 strike 衰减：冷却已结束超过阈值后归零，避免旧的高 strike 让下一次小风控直接指数爆炸。 */
  private decayStrikes(st: PlatformState): number {
    if (st.strikes <= 0) return 0;
    const now = this.now();
    if (now >= st.cooldownUntil + STRIKE_DECAY_MS) return 0;
    return st.strikes;
  }

  /** 上报一次平台事件；风控类事件触发指数退避冷却，登录墙仅记录。 */
  record(
    platform: string,
    kind: PacingKind,
    opts: { reason?: string; soft?: boolean; cooldownMs?: number } = {},
  ): void {
    const st = this.ensure(platform);
    if (!COOLDOWN_KINDS.has(kind)) {
      // login_wall 等：记录原因但不冷却（不是风控）
      if (opts.reason) st.reason = opts.reason;
      return;
    }
    const spec = this.spec(platform);
    const now = this.now();
    // soft 事件（如 B 站 412：多为匿名 IP/缺 Cookie，浏览器兜底可绕过）：
    // 只设一个短冷却窗口，不累计 strike，避免指数退避把平台锁死。
    if (opts.soft) {
      const durationMs = Math.max(
        0,
        Math.min(
          spec.maxCooldownSeconds * 1000,
          opts.cooldownMs ?? Math.min(10_000, spec.baseCooldownSeconds * 1000),
        ),
      );
      st.cooldownUntil = Math.max(now + durationMs, st.cooldownUntil);
      st.reason = opts.reason ?? kind;
      this.persist();
      return;
    }
    // 冷却期内重复上报共享 strike（只能延长窗口，不能无限叠指数）；
    // 冷却结束后超过阈值的历史 strike 先衰减，避免旧状态把平台长期锁死。
    const effectiveStrikes = now < st.cooldownUntil ? st.strikes : this.decayStrikes(st);
    const strikes = now < st.cooldownUntil ? Math.max(1, st.strikes) : effectiveStrikes + 1;
    const exponent = Math.max(0, Math.min(30, strikes - 1));
    const durationMs = Math.min(
      spec.maxCooldownSeconds * 1000,
      spec.baseCooldownSeconds * 1000 * 2 ** exponent,
    );
    st.strikes = strikes;
    st.cooldownUntil = Math.max(now + durationMs, st.cooldownUntil);
    st.reason = opts.reason ?? kind;
    this.persist();
  }

  /** 通道成功时复位 strike（保留已生效的冷却窗口自然过期）。 */
  reset(platform: string): void {
    const st = this.ensure(platform);
    st.strikes = 0;
    if (this.now() >= st.cooldownUntil) st.reason = "";
    this.persist();
  }

  /** 通道成功且确认可用时清空冷却（如 B 站 412 被浏览器兜底绕过）。 */
  clearCooldown(platform: string): void {
    const st = this.ensure(platform);
    st.cooldownUntil = 0;
    st.strikes = 0;
    st.reason = "";
    this.persist();
  }

  /** 距冷却结束的剩余毫秒（0 = 不在冷却）。 */
  cooldownRemainingMs(platform: string): number {
    const st = this.state[platform];
    if (!st) return 0;
    return Math.max(0, st.cooldownUntil - this.now());
  }

  isCoolingDown(platform: string): boolean {
    return this.cooldownRemainingMs(platform) > 0;
  }

  strikesOf(platform: string): number {
    return this.state[platform]?.strikes ?? 0;
  }

  /**
   * 等待同平台最小请求间隔（用于 API 直连通道串行化）。
   * 实际等待 = waitMs × (1 + (random×2−1) × jitterRatio)，下限 0——
   * 打散等间隔节拍器特征；jitterRatio=0 时与旧行为逐毫秒一致。
   */
  async waitForSlot(platform: string): Promise<void> {
    const st = this.ensure(platform);
    const spec = this.spec(platform);
    const now = this.now();
    const waitMs = Math.max(0, st.lastRequestAt + spec.minIntervalMs - now);
    if (waitMs > 0) {
      const jittered = this.jitteredWaitMs(waitMs);
      await this.sleepFn(jittered);
    }
    st.lastRequestAt = this.now();
  }

  /**
   * 同平台互斥执行：把整段采集（评论/搜索/API 直连）放进队列，避免同一平台
   * 的并发请求同时打到平台（后台子代理并行时尤其容易触发风控）。
   * 与 waitForSlot 不同，这里是真正串行化整段任务，而不是只做间隔等待。
   */
  async runExclusive<T>(platform: string, task: () => Promise<T>): Promise<T> {
    const prev = this.exclusive.get(platform) ?? Promise.resolve();
    let release!: () => void;
    const gate = new Promise<void>((resolve) => {
      release = resolve;
    });
    const tail = prev.then(() => gate);
    this.exclusive.set(platform, tail);
    await prev.catch(() => {});
    try {
      return await task();
    } finally {
      release();
      if (this.exclusive.get(platform) === tail) this.exclusive.delete(platform);
    }
  }

  /** 抖动计算（纯函数，可测）：±jitterRatio 均匀区间，下限 0。 */
  private jitteredWaitMs(waitMs: number): number {
    if (this.jitterRatio <= 0) return waitMs;
    const factor = 1 + (this.randomFn() * 2 - 1) * this.jitterRatio;
    return Math.max(0, waitMs * factor);
  }

  /** 立即落盘（卸载前调用）。 */
  flush(): void {
    this.persist();
  }

  /** 停止自动落盘（插件卸载）。 */
  dispose(): void {
    this.disposed = true;
    this.flush();
  }

  private persist(): void {
    if (!this.stateFile || this.disposed) return;
    try {
      const snapshot: PacingSnapshot = { version: 1, state: this.state };
      const tmp = `${this.stateFile}.tmp`;
      const dir = dirname(this.stateFile);
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      writeFileSync(tmp, JSON.stringify(snapshot), "utf8");
      renameSync(tmp, this.stateFile);
    } catch (error) {
      if (!this.silent) {
        console.warn(
          `[dsh-community-listening] pacing 状态落盘失败：${error instanceof Error ? error.message : String(error)}`,
        );
      }
    }
  }

  private load(): void {
    try {
      if (!existsSync(this.stateFile)) return;
      const raw = readFileSync(this.stateFile, "utf8");
      const parsed = JSON.parse(raw) as PacingSnapshot;
      if (parsed?.version !== 1 || typeof parsed.state !== "object") return;
      for (const [platform, st] of Object.entries(parsed.state)) {
        if (!st || typeof st !== "object") continue;
        const loaded: PlatformState = {
          cooldownUntil: Number(st.cooldownUntil) || 0,
          strikes: Math.max(0, Number(st.strikes) || 0),
          lastRequestAt: Number(st.lastRequestAt) || 0,
          reason: String(st.reason ?? ""),
        };
        loaded.strikes = this.decayStrikes(loaded);
        if (loaded.strikes === 0 && this.now() >= loaded.cooldownUntil) loaded.reason = "";
        this.state[platform] = loaded;
      }
    } catch {
      // 损坏文件忽略（下次写覆盖）
    }
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** 解析配置态文件路径（相对路径基于 baseDir）。 */
export function resolveStateFile(configured: string, baseDir: string | undefined): string {
  if (configured && configured.trim()) return configured.trim();
  if (baseDir && baseDir.trim()) return join(baseDir, ".pacing.json");
  return "";
}
