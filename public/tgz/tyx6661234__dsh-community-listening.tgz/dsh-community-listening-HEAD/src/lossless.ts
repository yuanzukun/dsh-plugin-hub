/**
 * Lossless JSON sanitize：DSH 工具输出校验要求「无损 JSON」——
 * 对象属性值不得为 undefined、数值必须有限且非 -0（见 @deepseek-ai/dsh-session walkJsonValue）。
 * 本模块在工具返回前清洗：丢 undefined 属性、非有限数归 0、稀疏数组补 null。
 * 泛型签名保持返回类型与输入一致（TS 推断不破坏）。
 */

export function sanitizeLossless<T>(value: T): T {
  if (value === null) return value;
  const t = typeof value;
  if (t === "string" || t === "boolean") return value;
  if (t === "number") {
    return (Number.isFinite(value) && !Object.is(value, -0) ? value : 0) as T;
  }
  if (t === "undefined" || t === "function" || t === "symbol" || t === "bigint") {
    return null as T;
  }
  if (Array.isArray(value)) {
    const out: unknown[] = [];
    for (let i = 0; i < value.length; i += 1) {
      out.push(i in value ? sanitizeLossless((value as unknown[])[i]) : null);
    }
    return out as T;
  }
  if (t === "object") {
    const out: Record<string, unknown> = {};
    for (const key of Object.keys(value as Record<string, unknown>)) {
      const v = (value as Record<string, unknown>)[key];
      if (v === undefined) continue; // 丢弃 undefined 属性（lossless JSON 拒绝）
      out[key] = sanitizeLossless(v);
    }
    return out as T;
  }
  return null as T;
}
