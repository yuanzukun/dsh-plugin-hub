/**
 * 网络层（简化版）：代理感知 fetch、URL 归一化、验证码启发式。
 * 供廉价 LLM、SiliconFlow embedding、B 站 API 直连与平台采集链路使用。
 */

import { execFileSync } from "node:child_process";
import { ProxyAgent } from "undici";

// ---------------------------------------------------------------------------
// 代理支持：本机可能配置了系统代理（WinINET，如 Clash 127.0.0.1:7897）。
// Node 直连不走系统代理，导致部分站点（如 HN）直连超时 —— 探测注册表并用
// undici ProxyAgent 路由 fetch。
//
// 出口策略（对齐 OpenBiliClaw trust_env=False 的教训）：国内社区平台
// （知乎 / B 站 / 小红书 / 牛客 / 微博 / 抖音）走本机直连 —— 这些平台会风控
// 代理出口 IP（表现为已登录用户显示未登录 / 412 / 验证码）；海外站点默认走
// 系统代理。`setDirectHostSuffixes()` 可由配置追加直连后缀。
// ---------------------------------------------------------------------------

/** 默认直连域名后缀（国内社区平台，避免代理出口 IP 被风控）。 */
export const DEFAULT_DIRECT_HOST_SUFFIXES: readonly string[] = [
  ".zhihu.com",
  ".bilibili.com",
  ".bilibili.tv",
  ".xiaohongshu.com",
  ".xhscdn.com",
  ".nowcoder.com",
  ".weibo.com",
  ".weibo.cn",
  ".douyin.com",
  ".iesdouyin.com",
  ".tieba.baidu.com",
];

let extraDirectSuffixes: string[] = [];

/** 追加直连域名后缀（Config bypassProxyHosts；插件 apply 时调用）。 */
export function setDirectHostSuffixes(suffixes: string[]): void {
  extraDirectSuffixes = (suffixes ?? [])
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

/**
 * RFC1918 私有 IPv4 精确判断：10.0.0.0/8、172.16.0.0–172.31.255.255（172.16-31.x）、
 * 192.168.0.0/16。注意 172.0-15/32-255 是公网段，不能用 startsWith("172.") 一刀切。
 */
export function isPrivateIpv4Host(host: string): boolean {
  const m = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m) return false;
  const a = Number(m[1]);
  const b = Number(m[2]);
  const c = Number(m[3]);
  const d = Number(m[4]);
  if (a > 255 || b > 255 || c > 255 || d > 255) return false;
  if (a === 10) return true;
  if (a === 192 && b === 168) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  return false;
}

/** 判断是否应直连（不走代理）：本地/内网，或命中直连域名后缀（配置态 + 参数注入）。 */
export function shouldBypassProxy(url: string, extraSuffixes: string[] = []): boolean {
  try {
    const host = new URL(url).hostname.toLowerCase();
    if (
      host === "localhost" || host === "127.0.0.1" || host === "[::1]" || host === "::1" ||
      isPrivateIpv4Host(host)
    ) {
      return true; // 本地/内网直连
    }
    const suffixes = [...DEFAULT_DIRECT_HOST_SUFFIXES, ...extraDirectSuffixes, ...extraSuffixes];
    for (const suffix of suffixes) {
      const bare = suffix.startsWith(".") ? suffix.slice(1) : suffix;
      if (host === bare || host.endsWith(`.${bare}`)) return true;
    }
  } catch {
    return true; // URL 解析失败 → 直连
  }
  return false;
}

let proxyAgent: ProxyAgent | null | undefined; // undefined = 未解析

function readRegistryValue(key: string, name: string): string | null {
  try {
    const out = execFileSync("reg", ["query", key, "/v", name], {
      encoding: "utf8",
      windowsHide: true,
      timeout: 3000,
    });
    const lines = out.split(/\r?\n/).filter((l) => l.includes(name));
    if (lines.length === 0) return null;
    const m = lines[0].match(/\s+REG_\w+\s+(.+)$/);
    return m ? m[1].trim() : null;
  } catch {
    return null;
  }
}

/** 探测 Windows 系统代理（HKCU Internet Settings），返回 http://host:port 或 null。 */
function resolveSystemProxy(): string | null {
  const key = "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings";
  const enabled = readRegistryValue(key, "ProxyEnable");
  if (!enabled || !/0x1/i.test(enabled)) return null;
  const server = readRegistryValue(key, "ProxyServer");
  if (!server) return null;
  return server.includes("://") ? server : `http://${server}`;
}

function proxyDispatcherFor(url: string, extraSuffixes: string[] = []): ProxyAgent | undefined {
  if (proxyAgent === undefined) {
    const envProxy = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
    const proxy = envProxy || resolveSystemProxy();
    try {
      proxyAgent = proxy ? new ProxyAgent(proxy) : null;
    } catch {
      proxyAgent = null;
    }
    if (proxyAgent) console.log(`[dsh-community-listening] 使用系统代理 ${proxy}`);
  }
  if (!proxyAgent) return undefined;
  if (shouldBypassProxy(url, extraSuffixes)) return undefined; // 国内社区平台直连
  return proxyAgent;
}

/** 代理感知的 fetch。 */
export async function httpFetch(url: string, init: RequestInit = {}): Promise<Response> {
  const dispatcher = proxyDispatcherFor(url, extraDirectSuffixes);
  return fetch(url, dispatcher ? { ...init, dispatcher } : init);
}

/** 常见 tracking 参数（归一化时剔除，避免同一页产生多个 URL 指纹）。 */
const TRACKING_PARAMS = new Set([
  "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
  "fbclid", "gclid", "mc_cid", "mc_eid", "igshid", "spm", "from", "share_token",
]);

/** URL 归一化：去尾斜杠 + 去 tracking 参数（供去重与入库指纹）。 */
export function normalizeUrl(raw: string): string {
  try {
    const url = new URL(raw.trim());
    if (!["http:", "https:"].includes(url.protocol)) return raw.trim();
    for (const key of Array.from(url.searchParams.keys())) {
      if (TRACKING_PARAMS.has(key.toLowerCase())) url.searchParams.delete(key);
    }
    url.hostname = url.hostname.toLowerCase();
    let path = url.pathname;
    if (path.length > 1 && path.endsWith("/")) path = path.slice(0, -1);
    url.pathname = path;
    url.hash = "";
    return url.toString();
  } catch {
    return raw.trim();
  }
}

/** 疑似验证码/登录墙页面的启发式（简化版，对齐 captcha_guard）。 */
export function looksLikeCaptcha(title: string, text: string): boolean {
  const hay = `${title} ${text}`.slice(0, 3000);
  return /(验证码|captcha|安全验证|滑动验证|访问过于频繁|人机验证|登录后继续|请先登录)/i.test(hay);
}

