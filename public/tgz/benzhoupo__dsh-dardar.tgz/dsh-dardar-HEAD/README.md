# dsh-dardar

在 DSH Web GUI 的对话框（composer）中，**模型选择框左侧**显示灰色小字 `当前模型IQ：xxx`（纯整数，四舍五入）—— 当前会话所选 DeepSeek V4 Pro / V4 Flash（codexradar dsh harness）的 IQ 值。

## 功能

- 只对 DeepSeek **V4 Pro / V4 Flash**（GUI 模型 id：`deepseek-v4-pro` / `deepseek-v4-flash`）显示；选择其他模型时徽标隐藏。
- **自动检测**当前模型与思考程度（`reasoningEffort`：`off` / `high` / `max`），**每一次切换模型或档位都会立即重新请求**（切换瞬间清掉旧值、显示 `…`，新值返回后更新）。
- 每 **5 分钟**自动刷新一次（`lib/client.js` 中 `REFRESH_MS` 可调）。
- 首次加载中显示 `当前模型IQ：…`；该模型×档位在榜上无数据或请求失败显示 `当前模型IQ：—`（定时刷新失败时保留上一次成功值）。

## 数据来源

- IQ 来自 codexradar 众测榜的公开只读接口（dsh harness 行）：
  `GET https://api.codexradar.com/api/v1/intelligence-efficiency?benchmark=deep-swe`
  `points[].iq` 即页面展示值（加权通过率 × 150，最近 3 个滚动窗口）。
- 模型映射：`deepseek-v4-pro → dsh-deepseek-v4-pro`、`deepseek-v4-flash → dsh-deepseek-v4-flash`，思考程度直通。
- 该站点对浏览器 CORS 仅放行自身域名（`https://deng.codexradar.com`），浏览器端无法直接跨域请求，因此插件在 DSH 服务端注册了一个同源代理路由（host 半每次请求都回源上游，仅合并并发中的请求；上游 Cloudflare 自身 `max-age=30` 兜底），浏览器半只做同源请求。

## 安装

从 GitHub 安装：

```bash
dsh plugin --profile web add github:benzhoupo/dsh-dardar
```

本地开发时也可以直接安装本地目录（以 link 方式安装，改动即时可见，无需重新 add）：

```bash
dsh plugin --profile web add /path/to/dsh-dardar
```

安装后**重启 `dsh web`**（新增 loader 行与浏览器 boot 图需要重启才生效），刷新浏览器页面（必要时硬刷新 Ctrl+Shift+R）。

## 卸载

```bash
dsh plugin --profile web remove dsh-dardar
# 重启 dsh web
```

## 结构

| 文件 | 作用 |
|---|---|
| `cordis.patch.yml` | bundle patch：向 web profile 插入 `dsh-dardar` loader 行 |
| `lib/index.js` | host 半：注册 `GET /dsh-dardar/iq?model=<id>&effort=<档位>` 代理路由 |
| `lib/client.js` | 浏览器半：`conversation.input.right` slot 条目（模型选择框左侧的 IQ 徽标） |

## 开发

- 无构建步骤：浏览器半是手写的 `window.__ModuleLoader__.load` 包装（与官方 client 包同款格式）。
- 修改任意文件后需要**重启 `dsh web`** 才会生效。
- 测试 host 路由：

```bash
curl -s "http://127.0.0.1:3080/dsh-dardar/iq?model=dsh-deepseek-v4-flash&effort=max"
# -> {"iq":100}（数值随众测滚动更新；无该档位行时为 {"iq":null}）
```

## 排障

- 看不到徽标：确认当前会话模型是 V4 Pro / V4 Flash 且已选档位；检查浏览器控制台有无 `dsh-dardar` 相关报错。
- 显示 `—`：该模型×档位在榜上暂无数据（如 `dsh-deepseek-v4-pro@off` 当前无行），或上游请求失败。
- 服务日志出现 client-modules 组合错误：检查 `dsh plugin` 安装是否成功（`~/.dsh/profiles/web/package.json` 的 `dsh.profile.bundles` 应包含 `dsh-dardar`）。

## 许可

[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)（Creative Commons Attribution 4.0 International），详见 [LICENSE](./LICENSE)。
