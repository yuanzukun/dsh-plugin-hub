/**
 * Integration test for dsh-dardar's browser half against the REAL SlotCore:
 * declaration chain -> plugin apply -> slot registration -> per-session inject
 * face -> SSR render of the badge (label, hidden branches).
 *
 * Run: node test/register.test.mjs
 */
import { SlotCore } from "/home/benzhoupo/.dsh/profiles/node_modules/@deepseek-ai/dsh-client-ui-slots/lib/index.js";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import { renderToString } from "/home/benzhoupo/.dsh/profiles/node_modules/react-dom/server.js";

const require = createRequire(import.meta.url);
const base = "/home/benzhoupo/.dsh/profiles/node_modules";
const req = (spec) => {
	if (spec === "react") return require(base + "/react");
	if (spec === "react/jsx-runtime") return require(base + "/react/jsx-runtime");
	throw new Error("unexpected require: " + spec);
};

// 1. load the browser half through the same wrapper the kernel uses
let handoff = null;
globalThis.window = { __ModuleLoader__: { load: (h) => { handoff = h; } } };
const src = readFileSync(fileURLToPath(new URL("../lib/client.js", import.meta.url)), "utf8");
new Function("require", src)(req);
if (handoff === null) throw new Error("load() was not called");
const mod = handoff.factory(req);
if (typeof mod.apply !== "function" || !Array.isArray(mod.inject)) throw new Error("bad module shape");

// 2. real SlotCore with the declaration chain ui-conversation/layout build
const core = new SlotCore();
const noop = () => null;
core.register({ name: "root", children: { conversation: { kind: "single", scope: "session-maybe" } } }, noop);
core.register({ name: "conversation", children: { "conversation.composer.bar": { kind: "single", scope: "session-maybe" } } }, noop);
core.register({ name: "conversation.composer.bar", children: { "conversation.input.right": { kind: "list", scope: "session" } } }, noop);

// 3. mock scope: slots service mirroring SlotRegistry.inject/register semantics
const slots = {
	inject(key, callback) {
		let stopped = false;
		let dispose = () => {};
		const stop = () => { if (stopped) return; stopped = true; dispose(); };
		const reconcile = () => {
			if (stopped) return;
			if (core.specDynamic(key) === void 0) return;
			dispose();
			dispose = callback();
		};
		const unsub = core.subscribeDeclaration(key, reconcile);
		dispose = () => { unsub(); };
		reconcile();
		return stop;
	},
	register(options, component) {
		return core.register(options, component);
	}
};
let snapshot = { current: null };
const fakeStore = {
	getSnapshot: () => snapshot,
	subscribe: () => () => {}
};
const modelDirectories = {
	directoryFor(sessionId) {
		if (sessionId !== "session-1") throw new Error("unknown session " + sessionId);
		return { store: fakeStore, load: async () => {} };
	}
};
const sessions = { subagentAddress: (id) => id === "session-sub" ? "sub" : void 0 };
const ctx = {
	inject(names, cb) { cb({ slots, modelDirectories, sessions }); },
	effect(fn) { const r = fn(); return typeof r === "function" ? r : () => {}; }
};

// 4. apply the plugin and assert the list entry registered (the missing-id bug
//    used to throw here: "list slot conversation.input.right requires options.id")
mod.apply(ctx);
const entries = core.entriesOfSlot("conversation.input.right");
if (entries.length !== 1) throw new Error(`expected 1 entry, got ${entries.length}`);
if (entries[0].options.id !== "dsh-dardar") throw new Error("entry id mismatch: " + entries[0].options.id);
console.log("OK: list entry registered with id", entries[0].options.id);

// 5. per-session inject face
const face = entries[0].inject("session-1");
if (face.store === null || typeof face.load !== "function") throw new Error("bad inject face");
console.log("OK: session inject face provides store + load");

// 6. SSR render: V4 Flash @ max -> badge shows the label (IQ needs the browser
//    fetch, so SSR yields the placeholder "—")
snapshot = { current: { provider: "deepseek-official", model: "deepseek-v4-flash", reasoningEffort: "max" } };
const html = renderToString(require(base + "/react").createElement(entries[0].component, { ...face, load: () => {} }));
if (!html.includes("当前模型IQ：")) throw new Error("badge label missing in SSR html: " + html);
console.log("OK: SSR html:", html);

// 7. non-V4 model -> nothing rendered
snapshot = { current: { provider: "x", model: "gpt-5.6-sol", reasoningEffort: "max" } };
const html2 = renderToString(require(base + "/react").createElement(entries[0].component, { ...face, load: () => {} }));
if (html2 !== "") throw new Error("non-V4 model should render nothing: " + html2);
console.log("OK: non-V4 model renders nothing");

// 8. subagent session -> inject face yields null store (badge renders nothing)
const face3 = entries[0].inject("session-sub");
if (face3.store !== null) throw new Error("subagent session should yield null store");
console.log("OK: subagent session yields null store (badge hidden)");

console.log("\nALL TESTS PASSED");
