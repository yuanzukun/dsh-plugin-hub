/** 登录页：账号密码 / 三方扫码（按平台连接器配置显隐）/ 票据免登（?ticket= 一次性参数）。 */
import { api, session, entryTicketSession, CONNECTION_NAME, IS_LOCAL_HOST } from '../api.js'
import { resolveLanding, LANDING_PREF_KEY } from '../landing.js'
import { resolvePanels } from '../connections.js'
import { consumeNextSources, exitWithNext } from '../next-redirect.js'
import { icon } from '../icons.js'
import { h, $, esc, toast } from '../ui.js'
import rqI18n from '../i18n.js'

export function renderLogin(app) {
  app.innerHTML = `
    <div class="login-page">
      <div class="login-hero">
        <div class="login-hero-inner">
          <div style="display:flex;align-items:center;gap:14px">
            <img class="brand-mark brand-logo" src="ybk-mark.png" alt="元冰可" style="width:46px;height:46px;border-radius:12px">
            <div style="font-size:19px;font-weight:600;letter-spacing:2px">元冰可 · 企业AI资源管理平台</div>
          </div>
          <h1>让团队一起用 AI<br>把每一份资源都管起来</h1>
          <p>组织账号、MCP 服务、Skill 市场、Agent 本体、AI 应用——五类资源一套身份、一套权限、一套审计。一个工作台，撑起企业的全部 AI 资产。</p>

          <div class="login-hero-grid">
            <div class="login-hero-card">
              <div class="login-hero-card-ic">${icon('puzzle')}</div>
              <div class="login-hero-card-title">一切皆插件</div>
              <div class="login-hero-card-desc">基于 DeepSeek Harness 插件架构，九大业务域即插即用，按团队需要随用随上。</div>
            </div>
            <div class="login-hero-card">
              <div class="login-hero-card-ic">${icon('shieldCheck')}</div>
              <div class="login-hero-card-title">注册即治理</div>
              <div class="login-hero-card-desc">双轨身份 + RBAC + 令牌网关，从接入到调用全链路留痕，企业合规一次到位。</div>
            </div>
            <div class="login-hero-card">
              <div class="login-hero-card-ic">${icon('gitBranch')}</div>
              <div class="login-hero-card-title">依赖可穿透</div>
              <div class="login-hero-card-desc">应用 → Agent → MCP/Skill 拓扑一图可视，谁依赖谁、影响多大，先知再改。</div>
            </div>
            <div class="login-hero-card">
              <div class="login-hero-card-ic">${icon('zap')}</div>
              <div class="login-hero-card-title">开箱即协作</div>
              <div class="login-hero-card-desc">一份资源全员共享，权限随角色流转，团队从第一天就在同一套资产上工作。</div>
            </div>
          </div>

          <div class="login-hero-strip">
            <div class="login-hero-stat"><span class="num">9</span><span class="lab">业务域即插即用</span></div>
            <div class="login-hero-stat"><span class="num">5</span><span class="lab">类资源统一纳管</span></div>
            <div class="login-hero-stat"><span class="num">1</span><span class="lab">套身份与审计</span></div>
          </div>
        </div>
        <div class="login-hero-footer">© 2026 元冰可 · 基于 DeepSeek Harness 构建</div>
      </div>
      <div class="login-panel">
        <h2 id="login-title">登录控制台</h2>
        <div class="sub" id="login-sub">使用钉钉扫码或平台账号登录</div>
        <div id="login-bootstrap-hint" class="muted-box mb-14" style="display:none;gap:8px;border-color:#fcd34d;background:#fffbeb">
          ${icon('info', 15)}
          <span class="fs-12">首次部署提示：平台管理员 <b>admin</b> 的初始口令在服务器 <b>data/admin-initial-password.txt</b> 文件中。登录后请<b>立即修改口令并删除该文件</b>（操作指引见 docs/deploy-enterprise.md 部署清单）。</span>
        </div>
        <div class="segmented" style="margin-bottom:24px" id="login-tabs">
          <span class="segmented-item" data-tab="dingtalk">钉钉扫码</span>
          <span class="segmented-item active" data-tab="password">账号密码</span>
        </div>

        <form class="login-form" id="login-form-password">
          <div class="form-item">
            <label class="form-label">用户名</label>
            <input class="input input-lg" id="login-username" placeholder="请输入用户名" autocomplete="username">
          </div>
          <div class="form-item">
            <label class="form-label">密码</label>
            <input class="input input-lg" id="login-password" type="password" placeholder="请输入密码" autocomplete="current-password">
          </div>
          <button class="btn btn-primary btn-lg btn-block" id="login-submit" type="submit">登 录</button>
        </form>

        <form class="login-form" id="login-form-dingtalk" style="display:none">
          <div id="ding-step-authorize">
            <div id="ding-oauth-list">
              <button class="btn btn-primary btn-lg btn-block" id="ding-oauth-go" type="button">使用钉钉扫码 / 点击头像登录</button>
            </div>
            <div class="form-hint" style="margin:8px 0 4px">整页跳转钉钉授权：已登录钉钉点击头像即可完成，未登录则出二维码扫码；组织归属只需在钉钉「选择你加入的组织」页选定一次。授权过的浏览器会自动回跳。</div>
            <details style="margin-top:12px">
              <summary class="form-hint" style="cursor:pointer">手动输入授权码（演示/mock 备用）</summary>
              <div style="text-align:center;padding:10px 0 6px">
                <div style="width:180px;height:180px;margin:0 auto;border-radius:16px;background:
                  radial-gradient(120px 120px at 30% 25%, #e0e7ff, transparent),
                  radial-gradient(120px 120px at 75% 80%, #ede9fe, transparent), #f8f9fb;
                  border:1px solid var(--border);display:grid;place-items:center;position:relative">
                  <div style="color:var(--brand-500)">${icon('fingerprint', 64)}</div>
                  <div style="position:absolute;bottom:12px;font-size:12px;color:var(--text-3)">使用钉钉扫码授权登录</div>
                </div>
              </div>
              <div class="form-item" style="margin-top:16px">
                <label class="form-label">钉钉授权码</label>
                <input class="input input-lg" id="login-ding-code" placeholder="请输入钉钉扫码授权码">
                <div class="form-hint">走完整 OAuth2 链路：authorize 签发 state → code 换令牌 → unionId 归一化。code 5 分钟内仅可消费一次。</div>
              </div>
              <button class="btn btn-primary btn-lg btn-block" id="login-ding-submit" type="submit">免密登录</button>
            </details>
          </div>
          <div id="ding-step-pending" style="display:none">
            <div class="muted-box mb-14" style="display:flex;gap:8px;border-color:var(--brand-200);background:var(--brand-50)">
              ${icon('info', 15)}<span>首次使用该钉钉身份（<b id="ding-pending-name"></b>）。按「一人一号」原则，请绑定已有平台账号，或注册新账号。</span>
            </div>
            <div class="tabs" style="margin-bottom:16px">
              <div class="tab active" data-ptab="bind">绑定已有账号</div>
              <div class="tab" data-ptab="register">注册新账号</div>
            </div>
            <div id="ding-bind-panel">
              <div class="form-item"><label class="form-label">平台用户名</label><input class="input input-lg" id="ding-bind-username" placeholder="如 dev"></div>
              <div class="form-item"><label class="form-label">密码</label><input class="input input-lg" id="ding-bind-password" type="password" placeholder="平台账号密码"></div>
              <button class="btn btn-primary btn-lg btn-block" id="ding-bind-submit">验证并绑定</button>
            </div>
            <div id="ding-register-panel" style="display:none">
              <div class="form-hint" style="margin-bottom:12px">将以三方身份自动注册平台账号（默认进入首个组织），并建立身份链接。</div>
              <button class="btn btn-primary btn-lg btn-block" id="ding-register-submit">注册并登录</button>
            </div>
            <button class="btn btn-ghost btn-block mt-8" id="ding-pending-back">返回重试</button>
          </div>
        </form>

        <div class="form-hint" style="margin-top:18px;display:flex;gap:6px;align-items:center">
          ${icon('server', 13)}
          <span>宿主服务：${esc(CONNECTION_NAME)}${IS_LOCAL_HOST ? '' : '（远程）'}</span>
          <a id="login-conn-link" style="color:var(--brand-500);cursor:pointer">更换</a>
        </div>
        <div style="margin-top:14px;text-align:center">
          <a href="#/home" style="color:var(--text-3);font-size:var(--fs-12-5)">← 返回产品首页</a>
        </div>
      </div>
    </div>`

  // 登录前换宿主（docs/frontend-host-switching.md）：#/connections 无会话可用（独立形态渲染）
  $('#login-conn-link').onclick = () => { location.hash = '#/connections' }

  // 首启部署提示（M2）：初始口令文件仍在服务器时展示「上线三步走」横幅；公开端点只回一个布尔
  void api.get('/api/platform/bootstrap').then((data) => {
    if (data?.initialPasswordPending) $('#login-bootstrap-hint').style.display = 'flex'
  }).catch(() => { /* 端点不可达不阻塞登录 */ })

  const tabPassword = $('#login-form-password')
  const tabDing = $('#login-form-dingtalk')

  // 登录回跳（docs/entry-switching.md）：?next= 显式目的地 > sessionStorage 暂存（api.js 401 打断处，
  // 键 heng_ops_next）。读取即消费：参数与暂存只生效一次；同源仅绝对路径（sanitizeNext），
  // 跨源仅回环/私网 http(s)（sanitizeCrossOriginNext，G1），防 open redirect / 票据外泄。
  // 钉钉整页授权离开本页前，跨源目的地暂存 sessionStorage（heng_ops_next_cross），由本页回装
  // 或 SSO 回调脚本消费。
  // next 解析/白名单/出口已提升为共享模块（next-redirect.js，F 清单 P 节）——app.js 已登录态
  // 启动链同规则消费；一次读取 + URL 清参后置由共享面保证（L 节教训不再重演）。
  const { sameOrigin: nextDestination, crossOrigin: crossNextDestination } = consumeNextSources()

  // 登录成功的统一出口：有回跳目的地整页跳转；无目的地时按落地分诊（与 app.js boot 同规则，
  // docs/entry-switching.md）——纯业务身份直达部门面板，其余进控制台工作台
  const finishLogin = async (welcomeName) => {
    toast(rqI18n.t('欢迎回来，{name}', { name: welcomeName }))
    // 跨源：签一次性自助票（TTL ≤120s）随 fragment 回跳，签票失败仍回跳（dsh 侧走
    // 「我已完成扫码」回导校验诚实降级）；同源：直接跳转——规则在 next-redirect.js 共享面
    if (await exitWithNext({ sameOrigin: nextDestination, crossOrigin: crossNextDestination, api })) return
    if (resolveLanding(session.user) === 'panel') {
      try { localStorage.setItem(LANDING_PREF_KEY, 'panel') } catch { /* 忽略 */ }
      // 面板入口以「宿主 × 部门」登记为准（#/panels）：有登记直达首个已登记面板，
      // 没登记停在登记页引导（与 app.js 启动分诊同规则）。
      // 挂载前缀取页面自身路径，不用 api.js 的 BASE——BASE 在远程宿主连接下是完整
      // 远端地址（http://host:port/rq），当成本机前缀会把「本机登记」拼成坏 URL。
      const mountBase = new URL('.', document.baseURI).pathname.replace(/\/$/, '')
      const registered = resolvePanels(localStorage, mountBase).find((panel) => panel.available)
      if (registered) { location.assign(registered.url); return }
      location.hash = '#/panels'
      window.dispatchEvent(new Event('hashchange'))
      return
    }
    location.hash = '#/dashboard'
    window.dispatchEvent(new Event('hashchange'))
  }

  // 票据免登：?ticket= 一次性参数（门户/钉钉入口复用平台领票模式）。
  // 读取后立即清除 URL 参数（票据不常驻地址栏），兑换成功直达工作台；失败清参数后走常规登录。
  {
    const urlTicket = new URLSearchParams(location.search).get('ticket')
    if (urlTicket) {
      history.replaceState(null, '', location.pathname + location.hash)
      entryTicketSession(urlTicket).then((user) => {
        finishLogin(user.displayName)
      }).catch((error) => {
        toast(rqI18n.t('免登失败：{msg}，请常规登录', { msg: error.message }), 'error')
      })
    }
  }

  // 上次使用的接入主体（多主体部署时保持入口视觉一致；身份归属最终以钉钉组织选择为准）
  const LAST_SSO_CONFIG_KEY = 'heng_ops_last_sso_config'
  let preferredConfigId = ''
  try { preferredConfigId = localStorage.getItem(LAST_SSO_CONFIG_KEY) ?? '' } catch { /* 忽略 */ }
  // 三方登录入口按平台配置显隐：未启用任何登录连接器时仅展示账号密码
  // 钉钉扫码为平台默认登录方式：连接器可用即默认选中（用户已手动切换则不覆盖）
  let loginTabTouched = false
  const switchLoginTab = (name) => {
    app.querySelectorAll('#login-tabs .segmented-item').forEach((item) => item.classList.toggle('active', item.dataset.tab === name))
    const isPassword = name === 'password'
    tabPassword.style.display = isPassword ? '' : 'none'
    tabDing.style.display = isPassword ? 'none' : ''
  }
  // 发起整页跳转授权：单一主入口，不再要求在平台侧预选企业主体
  // blocked=授权页侧应用级拒绝（钉钉 900103「应用不存在」）：跳到该地址只会看到错误页，
  // 这里直接就地给出「去开发者后台开哪一项」的指引，并切回账号密码兜底，不让登录彻底走死。
  const dingBlockedNotice = (message) => {
    // 幂等：重复点击「扫码」不应把同一条提示堆叠多份
    const previous = $('#ding-blocked-notice')
    if (previous) previous.remove()
    $('#ding-step-authorize').insertAdjacentHTML('afterbegin', `
      <div class="muted-box mb-14" id="ding-blocked-notice" style="display:flex;gap:8px;border-color:#fcd34d;background:#fffbeb">
        ${icon('alert', 15)}
        <span class="fs-12">钉钉扫码登录未就绪${message ? `：${esc(message)}` : ''}。<br>
        请管理员在<b>钉钉开发者后台 → 该企业内部应用 → 登录与分享</b>中补充回调域名 <code class="mono">${esc(location.host)}</code>，
        并确认 <b>AppKey</b> 与「登录应用」一致；配好后刷新本页即可扫码。当前可先用<b>账号密码</b>登录。</span>
      </div>`)
  }
  const startDingOauth = async (btn, configId) => {
    btn.classList.add('btn-loading')
    try {
      const auth = await api.post('/api/auth/sso/authorize', { provider: 'dingtalk', scene: 'web_qr', ...(configId ? { configId } : {}) })
      if (auth.blocked) {
        dingBlockedNotice(auth.blocked.message)
        // 用户手动切回账号密码：置 touched，避免 providers 回来后再把 tab 拨回扫码
        loginTabTouched = true
        switchLoginTab('password')
        toast(rqI18n.t('钉钉扫码登录未就绪，已切换到账号密码登录'), 'error')
        return
      }
      if (!auth.authorizeUrl) throw new Error('身份源未返回授权地址（可能为 mock 模式），请改用手动输入授权码')
      try { localStorage.setItem(LAST_SSO_CONFIG_KEY, configId ?? '') } catch { /* 忽略 */ }
      // 跨源自举回跳（G1）：整页跳转会离开本页，跨源目的地暂存给 SSO 回调脚本消费
      if (crossNextDestination) {
        try { sessionStorage.setItem('heng_ops_next_cross', crossNextDestination) } catch { /* 忽略 */ }
      }
      // 必须整页跳转：弹窗/iframe 会被第三方 Cookie 策略拦截导致授权失败
      window.location.href = auth.authorizeUrl
    } catch (error) {
      toast(error.message, 'error')
      btn.classList.remove('btn-loading')
    }
  }
  // 登录入口渲染：一个主按钮直达钉钉授权页；其余已接入主体降级为次要链接，不作为必选步骤
  const renderDingtalkEntry = (providers) => {
    if (!providers.some((item) => (item.configId ?? '') === preferredConfigId)) {
      preferredConfigId = providers[0]?.configId ?? ''
    }
    const others = providers.filter((item) => (item.configId ?? '') !== preferredConfigId)
    const holder = $('#ding-oauth-list')
    holder.innerHTML = `
      <button class="btn btn-primary btn-lg btn-block" id="ding-oauth-go" type="button">使用钉钉扫码 / 点击头像登录</button>
      ${others.length ? `<div class="form-hint" style="margin-top:8px;text-align:center">其他已接入主体：${others.map((item, index) => `
        <a class="fs-12" style="color:var(--brand-500);cursor:pointer;margin-left:${index ? 8 : 0}px" data-config-id="${esc(item.configId ?? '')}">${esc(item.name || item.corpId || '未命名主体')}</a>`).join('')}</div>` : ''}`
    $('#ding-oauth-go').onclick = (e) => void startDingOauth(e.currentTarget, preferredConfigId || undefined)
    holder.querySelectorAll('[data-config-id]').forEach((el) => {
      el.onclick = () => void startDingOauth($('#ding-oauth-go'), el.dataset.configId || undefined)
    })
  }
  // 三方登录入口按平台配置显隐 → 见上方 switchLoginTab/loginTabTouched 声明
  void api.get('/api/auth/providers').then((data) => {
    const dingtalkProviders = (data?.providers ?? []).filter((item) => item.provider === 'dingtalk')
    if (!dingtalkProviders.length) {
      $('#login-tabs').style.display = 'none'
      $('#login-sub').textContent = '使用平台账号登录'
      return
    }
    if (!loginTabTouched) switchLoginTab('dingtalk')
    renderDingtalkEntry(dingtalkProviders)
  }).catch(() => { /* 查询失败时保持默认展示 */ })
  app.querySelectorAll('#login-tabs .segmented-item').forEach((el) => {
    el.onclick = () => {
      loginTabTouched = true
      switchLoginTab(el.dataset.tab)
    }
  })

  const doLogin = async (payload, path) => {
    const btn = $(path === '/api/auth/login' ? '#login-submit' : '#login-ding-submit')
    btn.classList.add('btn-loading')
    try {
      const result = await api.post(path, payload)
      session.save(result.token, result.user)
      if (result.refreshToken) session.saveRefresh(result.refreshToken)
      finishLogin(result.user.displayName)
    } catch (error) {
      toast(error.message, 'error')
    } finally {
      btn.classList.remove('btn-loading')
    }
  }

  tabPassword.onsubmit = (e) => {
    e.preventDefault()
    void doLogin({ username: $('#login-username').value.trim(), password: $('#login-password').value }, '/api/auth/login')
  }
  $('#ding-oauth-go').onclick = (e) => void startDingOauth(e.currentTarget)

  let dingTicket = ''
  // 承接扫码回跳：callback 页把「首次使用三方身份」的待绑定票据暂存 localStorage
  try {
    const pendingRaw = localStorage.getItem('heng_ops_sso_pending')
    if (pendingRaw) {
      localStorage.removeItem('heng_ops_sso_pending')
      const pending = JSON.parse(pendingRaw)
      dingTicket = pending.pendingTicket ?? ''
      if (dingTicket) {
        document.querySelector('#login-tabs .segmented-item[data-tab="dingtalk"]')?.click()
        $('#ding-pending-name').textContent = pending.profileName ?? ''
        $('#ding-step-authorize').style.display = 'none'
        $('#ding-step-pending').style.display = ''
      }
    }
  } catch { /* 票据损坏则忽略，走常规登录 */ }

  tabDing.onsubmit = async (e) => {
    e.preventDefault()
    const btn = $('#login-ding-submit')
    btn.classList.add('btn-loading')
    try {
      const code = $('#login-ding-code').value.trim()
      if (!code) return toast(rqI18n.t('请输入钉钉授权码（演示环境为工号，如 DD0002）'), 'error')
      const auth = await api.post('/api/auth/sso/authorize', { provider: 'dingtalk', scene: 'web_qr' })
      const result = await api.post('/api/auth/sso', { provider: 'dingtalk', code, state: auth.state })
      if (result.kind === 'pending') {
        dingTicket = result.pendingTicket
        $('#ding-pending-name').textContent = result.profileName
        $('#ding-step-authorize').style.display = 'none'
        $('#ding-step-pending').style.display = ''
        return
      }
      finishSsoLogin(result)
    } catch (error) {
      toast(error.message, 'error')
    } finally {
      btn.classList.remove('btn-loading')
    }
  }

  const finishSsoLogin = (result) => {
    session.save(result.token, result.user)
    if (result.refreshToken) session.saveRefresh(result.refreshToken)
    // 承接回跳：从 OIDC 授权页发起的钉钉登录（含回调转本页完成首绑/注册的分支），
    // 登录后按暂存的授权请求（与授权请求同为 5 分钟有效）回授权页继续 consent，而非进控制台
    let resume = null
    try {
      resume = JSON.parse(localStorage.getItem('heng_ops_sso_oidc_req') ?? 'null')
      localStorage.removeItem('heng_ops_sso_oidc_req')
    } catch { /* 票据损坏则忽略，走常规入口 */ }
    if (resume && typeof resume.req === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(resume.req) && Date.now() - (resume.ts ?? 0) < 300_000) {
      location.hash = `#/oauth/authorize?req=${resume.req}`
      return
    }
    finishLogin(result.user.displayName)
  }

  app.querySelectorAll('#login-form-dingtalk .tab[data-ptab]').forEach((el) => {
    el.onclick = () => {
      app.querySelectorAll('#login-form-dingtalk .tab[data-ptab]').forEach((t) => t.classList.remove('active'))
      el.classList.add('active')
      $('#ding-bind-panel').style.display = el.dataset.ptab === 'bind' ? '' : 'none'
      $('#ding-register-panel').style.display = el.dataset.ptab === 'register' ? '' : 'none'
    }
  })
  $('#ding-bind-submit').onclick = async () => {
    const btn = $('#ding-bind-submit')
    btn.classList.add('btn-loading')
    try {
      const result = await api.post('/api/auth/sso/bind', {
        pendingTicket: dingTicket,
        username: $('#ding-bind-username').value.trim(),
        password: $('#ding-bind-password').value,
      })
      finishSsoLogin(result)
    } catch (error) { toast(error.message, 'error') } finally { btn.classList.remove('btn-loading') }
  }
  $('#ding-register-submit').onclick = async () => {
    const btn = $('#ding-register-submit')
    btn.classList.add('btn-loading')
    try {
      const result = await api.post('/api/auth/sso/register', { pendingTicket: dingTicket })
      finishSsoLogin(result)
    } catch (error) { toast(error.message, 'error') } finally { btn.classList.remove('btn-loading') }
  }
  $('#ding-pending-back').onclick = () => {
    $('#ding-step-pending').style.display = 'none'
    $('#ding-step-authorize').style.display = ''
  }
}
