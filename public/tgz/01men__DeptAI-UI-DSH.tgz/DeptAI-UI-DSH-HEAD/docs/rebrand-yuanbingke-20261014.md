# 品牌与仓库更名决策记录（2026-10-14）

> 状态：**已执行**（本文件为决策凭据）
> 决策范围：`custom/dsh-rq`（本仓库全量）｜ 产权归属：**杭州元冰可科技有限公司**
>
> 口径说明：更名前的旧品牌名与旧仓库名**不在本文件复述**（按「全仓不出现旧称」的硬要求），
> 需要核对旧值时以 git 历史为准——更名前最后一个提交为 `a7f35a4`。

## 一、决策事实

| 项 | 更名后 |
|---|---|
| 品牌中文名 | **元冰可** |
| 品牌英文名 | **Yuanbingke**（小写标识 `yuanbingke`） |
| 宿主平台仓库 | **`01men/ybkkasi`** |
| 品牌位图 | **`ybk-mark.png`**（采用上游现行官方标，替换原 R 字标位图） |
| 版权主体 | **杭州元冰可科技有限公司**（Hangzhou Yuanbingke Technology Co., Ltd.） |

命名与措辞以上游 `01men/ybkkasi` 现行口径为准（上游 commit `894137b` 已完成同批切换），
本仓库据此收敛，不自行发明变体。英文单语面（`llms.txt`）沿用上游写法 `Yuanbingke (ybkkasi)`。

## 二、执行规则（可复核）

1. 仓库全路径统一为 `01men/ybkkasi`（覆盖 `.git` 与 `github:` 简写两种形式）
2. 引用顺序敏感：先替换组合名与派生主体名，再替换裸品牌名，避免产生「元冰可 AIOS」类残片
3. 品牌位图改名先于标识符替换，保证 HTML/JS 引用同步改写
4. 更名后清理一次「品牌名 + 空格 + 中文字」的删词残片
5. 外部技能名不臆造重命名：统一为 `hermes asset-push`（去品牌化写法，与上游一致）

## 三、边界与例外

- **历史冻结文档**：`docs/` 下的测试报告、巡检日志、交接清单等「当时发生了什么」的记录，
  其正文事实叙述随本批统一更新品牌称谓；**但上游侧对应的历史冻结文档保持原记录不篡改**
  （上游 commit `894137b` 明示口径），本仓库不回头追改上游历史。
- **协议层不改写**：事件名、权限点、错误原因码、API 信封字段、环境变量名、浏览器存储键、
  npm 包 scope（`@ybkk/*`、`@dsh-ops/*`）均属装配契约，**不在本次更名范围**——改之即装机不变量破裂。
  其中 `@ybkk/gate-01` 为已实发布包名，更名需另起发版决策。
- **`.git` 内部**：历史提交、reflog 与对象库不可变，必然保留旧值；本批只保证**工作树与后续提交**
  在品牌面上无旧称。

## 四、验证要求

更名属「随附包 src 变更」，触发 fresh-install 装机不变量，推送交付前必须：

```bash
node packages/plugin-rq-card/build.mjs   # 浏览器半 build-id 指纹
npm run build:dist                       # 6 随附包 dist 指纹（本次 build-id e5921e9691177d27）
npm run selftest && npm run lint:manifests
```

本次实测结果：`selftest 1322/1322 绿`、`lint:manifests 105/105 绿`、装机模拟段（三链一致 /
bundle 与 dist 新鲜度 / files 闭包）全绿。

残留自查：工作树对旧品牌名、旧英文名、旧仓库名、旧位图名、旧小写标识**零命中**
（模式表见 `scripts/hooks/pre-push` 与提交 `a7f35a4` 的历史值；`.git/` 与 `node_modules/` 除外）。

## 五、遗留待办（本次未动，需单独决策）

1. **npm 包名与 scope**：`@ybkk/gate-01` 已实发布 1.2.1，`@ybkk/*` scope 为装机装配契约。
   更名需另起发版决策（新包名发布 + 旧包 deprecate，非纯文案改动）。
2. **Mac 部署机路径**（`docs/deploy-mac-form-b.md`）：文内工作区路径与 launchd Label 已按新品牌
   同步改写（`~/yuanbingke-ops`、`ai.yuanbingke.dsh`）。**若该 Mac 上已按旧路径部署，迁移需同步
   改 launchd plist 的 Label/路径与 overlay 的 `<PROJECT_ROOT>`，并把数据目录一起搬移**——
   改名不自动迁移现有部署。
3. **对外已发布链接**：产品页测试环境 `http://mdzx.fun:8801/product.html` 等外部入口，
   需按新文案重新部署（`scripts/deploy-product-page.py` 可直接推送）。

## 六、推送通道备注

本次推送本项目主仓时，HTTPS 通道的 credential manager 无人值守即挂起（交互式弹窗）；
改用 SSH 通道（`git@github.com:01men/RQ-DSH.git`，密钥 `~/.ssh/ybkk_github_global_ed25519`）成功。
后续无人值守推送建议直接用 SSH 形式，勿依赖 HTTPS 交互式凭据。