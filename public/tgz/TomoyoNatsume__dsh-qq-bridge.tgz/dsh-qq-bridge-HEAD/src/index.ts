/**
 * 对外导出。
 */
export { OnebotClient, WsTransport } from './onebot/client.js'
export type { Transport } from './onebot/client.js'
export type { OnebotMessageEvent, OnebotMessageType } from './onebot/types.js'
export { TencentOfficialBotClient, toBridgeMessageEvent } from './official/client.js'
export type { TencentOfficialBotOptions } from './official/client.js'
export { MessageRouter } from './router.js'
export type { Handler, HandlerContext } from './router.js'
export { AccessGate } from './security.js'
export type { AccessOptions } from './security.js'
export { AgentRpcHandler } from './handlers/agent.js'
export type { AgentExecutor } from './handlers/agent.js'
export { DshAgentExecutor, extractLastAssistantText, hashKey } from './handlers/dsh-executor.js'
export type { DshRenderedAgent } from './handlers/dsh-executor.js'
export { DIR_COMMAND, DirectoryHandler, resolveUserPath } from './handlers/directory.js'
export type { DirectorySwitcher } from './handlers/directory.js'
export {
  BridgeControlHandler,
  HELP_COMMAND,
  MODEL_COMMAND,
  MODELS_COMMAND,
  ModelControlHandler,
  NEW_SESSION_COMMAND,
  PERMISSION_COMMAND,
  PERMISSIONS_COMMAND,
  REASONING_EFFORT_COMMAND,
  installBridgeModelSelection,
  resolveConfiguredModels,
} from './handlers/model-control.js'
export type {
  BridgeModelInfo,
  BridgeModelSelection,
  BridgeModelSelectionRef,
  ModelSelectionController,
  PermissionController,
  SessionLifecycleController,
} from './handlers/model-control.js'
export {
  QQ_CONTROL_BLOCK_TAG,
  QqControlDispatcher,
  createNewSessionControlHandler,
  createSetCwdControlHandler,
  createSetModelControlHandler,
  createSetPermissionControlHandler,
  createSetReasoningEffortControlHandler,
  parseQqControlBlocks,
} from './handlers/control.js'
export type {
  ParsedQqControls,
  QqControlAction,
  QqControlActionHandler,
  QqControlContext,
} from './handlers/control.js'
export {
  InMemoryCustomMemoryStore,
  LazyCustomMemoryStore,
  StorageDomainCustomMemoryStore,
  createSaveMemoControlHandler,
  customMemoryDomainSpec,
  customMemoryMemoSchema,
  customMemoryTimerSchema,
} from './handlers/custom-memory.js'
export type {
  CustomMemoryMemoRecord,
  CustomMemoryRecordStatus,
  CustomMemoryStore,
  CustomMemoryTarget,
  CustomMemoryTimerRecord,
  DshKvTable,
  DshStorageDomain,
  DshStorageDomainRuntime,
} from './handlers/custom-memory.js'
export {
  InMemoryTaskScheduler,
  createScheduleTaskControlHandler,
} from './handlers/scheduler.js'
export type {
  InMemoryTaskSchedulerOptions,
  ScheduledTask,
  ScheduledTaskController,
  ScheduledTaskReceipt,
  ScheduledTaskTarget,
} from './handlers/scheduler.js'
export { ShellHandler } from './handlers/shell.js'
export { NapcatSelfLogInput, parseNapcatSelfLogLine } from './inputs/napcat-log.js'
export { DshWebActivityGate, trackedWebSessionId } from './web-activity.js'
export type { AgentRunGate } from './web-activity.js'
export { DshQqBridgeConfig } from './config.js'
export type * from './config.js'
export { buildConnectGuidance } from './plugin.js'
export {
  agentReplyNotificationsEnabled,
  buildOfficialConnectGuidance,
  createAgentReplyNotifier,
  findSessionTitle,
  registerAgentReplyNotifier,
} from './plugin.js'
// 包入口默认导出即为 Cordis 插件本体:让 Loader `unwrapExports` 能取到 default。
export { default } from './plugin.js'
