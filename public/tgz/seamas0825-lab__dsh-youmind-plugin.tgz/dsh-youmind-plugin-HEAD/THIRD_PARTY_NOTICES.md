# Third-party notices

The bundled `youmind` skill was adapted from the public
[`YouMind-OpenLab/skills`](https://github.com/YouMind-OpenLab/skills) repository,
which declares the MIT License in its README.

Source revision reviewed during adaptation:
`b39547059a173ad436bfba805d4220afd6d2a410`.

The implementation calls the public YouMind OpenAPI contract documented by the
YouMind Skills repository and `@youmind-ai/cli` package. YouMind names and marks
remain the property of their respective owners.
