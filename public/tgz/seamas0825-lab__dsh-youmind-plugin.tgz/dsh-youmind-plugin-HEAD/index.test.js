import assert from 'node:assert/strict'
import test from 'node:test'

import { inject, testing } from './index.js'

test('declares the DSH credentials service dependency', () => {
  assert.deepEqual(inject, ['skills', 'tools', 'credentials'])
})

test('resolves the YouMind API key through DSH credentials', async () => {
  const refs = []
  const credentials = {
    async resolve(ref) {
      refs.push(ref)
      return { value: '  sk-ym-test  ', source: 'file' }
    },
  }

  assert.equal(await testing.apiKey(credentials), 'sk-ym-test')
  assert.deepEqual(refs, ['YOUMIND_API_KEY'])
})

test('re-resolves credentials on every operation', async () => {
  let value = 'first'
  const credentials = { resolve: async () => ({ value, source: 'file' }) }

  assert.equal(await testing.apiKey(credentials), 'first')
  value = 'second'
  assert.equal(await testing.apiKey(credentials), 'second')
})

test('reports an actionable error when the credential is absent', async () => {
  const credentials = { resolve: async () => undefined }

  await assert.rejects(
    testing.apiKey(credentials),
    /YOUMIND_API_KEY.*DSH 凭据存储/,
  )
})
