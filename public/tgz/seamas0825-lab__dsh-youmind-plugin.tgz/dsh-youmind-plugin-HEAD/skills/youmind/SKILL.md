---
name: youmind
description: Work with the user's YouMind workspace and OpenAPI: discover APIs, search saved knowledge, search the web, inspect boards and files, and perform clearly authorized YouMind actions.
user-invocable: true
disable-model-invocation: false
metadata:
  source: YouMind-OpenLab/skills
  adapted-for: DeepSeek Harness
---

# YouMind

YouMind is an AI creative workspace for collecting webpages, PDFs, videos, podcasts, notes, and generated assets, then searching, organizing, writing, and publishing from that material.

Use this skill when the request is clearly connected to the user's YouMind workspace, boards, groups, files, picks, chats, skills, saved knowledge, or YouMind OpenAPI.

## Authentication

Authenticated tools resolve `YOUMIND_API_KEY` through the DeepSeek Harness credentials service on every call. Never request that the user paste an API key into chat or include it in tool arguments. If the key is missing, direct the user to https://youmind.com/settings/api-keys and ask them to store it under `YOUMIND_API_KEY` in `$DSH_HOME/.credentials.yaml` with owner-only permissions. Credential updates take effect without restarting Harness.

## Tool workflow

For a YouMind API operation whose exact name or parameters are not already known:

1. Call `youmind_search_api` with a short keyword.
2. Call `youmind_api_info` for the chosen operation.
3. Call `youmind_call_api` with JSON parameters matching the inspected contract.
4. Reuse returned IDs for follow-up calls; expose internal IDs only when useful to the user.

Use `youmind_find` for semantic search over the user's saved library or one board. Use `youmind_web_search` for public internet search.

Common API areas include boards, files, groups, picks, chats, skills, document creation, URL capture, publishing, trash, and restore. Discover the current operation names instead of relying on memory.

## Side effects

Before moving, trashing, restoring, publishing, installing, or performing a paid action, ensure the user's intent clearly covers the exact target and action. Report success only after the tool call succeeds. Never claim that content was saved, published, installed, moved, or deleted after a failed request.

Long-running generation and processing can take tens of seconds. Keep the user informed and use available background-job facilities when appropriate.
