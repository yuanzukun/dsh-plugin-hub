import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'

const DEFAULT_ENDPOINT = 'https://youmind.com'
const API_KEY_REF = 'YOUMIND_API_KEY'
// DeepSeek Harness reserves rank 600 for bundled skill providers.
const BUNDLED_SKILL_RANK = 600
const PROVIDER_NAME = 'youmind-bundled'
const SKILL_BODY_URL = new URL('./skills/youmind/SKILL.md', import.meta.url)
const SKILL_RESOURCE_BASE = {
  kind: 'directory',
  path: fileURLToPath(new URL('./skills/youmind/', import.meta.url)),
}
const INVOCATION = { modelInvocable: true, userInvocable: true }
const SKILL_DESCRIPTION = 'Work with the user\'s YouMind workspace and OpenAPI: discover APIs, search saved knowledge, search the web, inspect boards and files, and perform clearly authorized YouMind actions.'
const SKILL_CANDIDATE = {
  name: 'youmind',
  description: SKILL_DESCRIPTION,
  invocation: INVOCATION,
  provider: PROVIDER_NAME,
  source: 'bundled',
  resourceBase: SKILL_RESOURCE_BASE,
  rank: BUNDLED_SKILL_RANK,
  locator: SKILL_BODY_URL,
}

export const name = 'youmind'
export const inject = ['skills', 'tools', 'credentials']

function endpoint() {
  return (process.env.YOUMIND_ENDPOINT || DEFAULT_ENDPOINT).replace(/\/+$/, '')
}

async function apiKey(credentials) {
  const resolved = await credentials.resolve(API_KEY_REF)
  const value = resolved?.value?.trim()
  if (!value) {
    throw new Error(
      'YouMind API Key 未配置。请在 https://youmind.com/settings/api-keys 创建密钥，'
      + `然后将 ${API_KEY_REF} 保存到 DSH 凭据存储；不要把密钥发到聊天中。`,
    )
  }
  return value
}

function assertApiName(value) {
  if (!/^\w+$/.test(value)) {
    throw new Error(`无效的 YouMind API 名称：${JSON.stringify(value)}。名称只能包含字母、数字和下划线。`)
  }
}

function renderJson(_args, value) {
  return [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }]
}

function compileSchema(spec) {
  if (spec.type === 'json') return {}
  const { required: _required, ...schema } = spec
  if (schema.items) schema.items = compileSchema(schema.items)
  return schema
}

function valueMatchesType(value, type) {
  if (type === 'array') return Array.isArray(value)
  if (type === 'object') return value !== null && typeof value === 'object' && !Array.isArray(value)
  if (type === 'number') return typeof value === 'number' && Number.isFinite(value)
  return typeof value === type
}

function validateToolArgs(parameters, args) {
  if (args === null || typeof args !== 'object' || Array.isArray(args)) return ['arguments must be an object']
  const violations = []
  for (const [key, spec] of Object.entries(parameters)) {
    const value = args[key]
    if (value === undefined) {
      if (spec.required) violations.push(`${key} is required`)
      continue
    }
    if (spec.type !== 'json' && !valueMatchesType(value, spec.type)) {
      violations.push(`${key} must be ${spec.type}`)
      continue
    }
    if (spec.enum && !spec.enum.includes(value)) violations.push(`${key} is not an allowed value`)
    if (spec.type === 'array' && spec.items?.type && value.some(item => !valueMatchesType(item, spec.items.type))) {
      violations.push(`${key} contains an invalid item`)
    }
  }
  return violations
}

// A dependency-free subset of dsh's defineTool helper. Keeping the bundle
// self-contained also makes local `dsh plugin add ./...` links resolvable.
function defineTool(options) {
  const properties = {}
  const required = []
  for (const [key, spec] of Object.entries(options.parameters)) {
    properties[key] = compileSchema(spec)
    if (spec.required) required.push(key)
  }
  return {
    name: options.name,
    description: options.description,
    parameters: {
      type: 'object',
      properties,
      ...(required.length ? { required } : {}),
    },
    output: {
      schema: compileSchema(options.output.schema),
      render: options.output.render,
    },
    async execute(args, exec) {
      const violations = validateToolArgs(options.parameters, args)
      if (violations.length) throw new Error(`YouMind 工具参数无效：${violations.join('；')}`)
      return options.execute(args, exec)
    },
  }
}

function parseResponseBody(text) {
  if (!text) return null
  try {
    return JSON.parse(text)
  } catch {
    return text
  }
}

function describeHttpError(status, payload) {
  const detail = typeof payload === 'string'
    ? payload
    : payload && typeof payload === 'object'
      ? payload.message || payload.code || JSON.stringify(payload)
      : ''
  const suffix = detail ? ` 详情：${detail}` : ''

  if (status === 401) {
    return `YouMind API Key 无效或已经过期。请前往 https://youmind.com/settings/api-keys 重新创建。${suffix}`
  }
  if (status === 402) {
    return 'YouMind 免费额度或功能配额已用完。升级 Pro 或 Max 后可继续使用：'
      + `https://youmind.com/pricing?utm_source=dsh-youmind-plugin${suffix}`
  }
  if (status === 429) return `YouMind 请求过于频繁，请稍后再试。${suffix}`
  if (status >= 500) return `YouMind 服务暂时异常，请稍后再试。${suffix}`
  return `YouMind API 请求失败（HTTP ${status}）。${suffix}`
}

async function request(credentials, path, { method = 'GET', body, authenticated = false, signal } = {}) {
  const headers = { Accept: 'application/json' }
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  if (authenticated) {
    headers['x-api-key'] = await apiKey(credentials)
    headers['x-use-camel-case'] = 'true'
  }

  const response = await fetch(`${endpoint()}${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
    signal,
  })
  const payload = parseResponseBody(await response.text())
  if (!response.ok) throw new Error(describeHttpError(response.status, payload))
  return payload
}

async function searchApi(credentials, query, signal) {
  const url = new URL('/api/openapi/search', endpoint())
  if (query) url.searchParams.set('query', query)
  return request(credentials, `${url.pathname}${url.search}`, { signal })
}

async function readApi(credentials, apiName, signal) {
  assertApiName(apiName)
  return request(credentials, `/api/openapi/read/${encodeURIComponent(apiName)}`, { signal })
}

async function callApi(credentials, apiName, params, signal) {
  assertApiName(apiName)
  return request(credentials, `/openapi/v1/${encodeURIComponent(apiName)}`, {
    method: 'POST',
    authenticated: true,
    body: params ?? {},
    signal,
  })
}

function registerSkill(ctx) {
  const provider = {
    name: PROVIDER_NAME,
    list: () => Promise.resolve([SKILL_CANDIDATE]),
    async get() {
      return {
        name: SKILL_CANDIDATE.name,
        description: SKILL_CANDIDATE.description,
        invocation: SKILL_CANDIDATE.invocation,
        provider: SKILL_CANDIDATE.provider,
        source: SKILL_CANDIDATE.source,
        resourceBase: SKILL_RESOURCE_BASE,
        content: await readFile(SKILL_BODY_URL, 'utf8'),
      }
    },
  }
  ctx.skills.registerProvider(() => provider)
}

function registerTools(ctx) {
  ctx.tools.register(defineTool({
    name: 'youmind_search_api',
    description: 'Search YouMind OpenAPI operations by keyword. Use this before guessing an API name.',
    parameters: {
      query: { type: 'string', description: 'Optional keyword such as board, file, chat, skill, or publish.' },
    },
    output: { schema: { type: 'json' }, render: renderJson },
    execute: (args, exec) => searchApi(ctx.credentials, args.query, exec.signal),
  }))

  ctx.tools.register(defineTool({
    name: 'youmind_api_info',
    description: 'Inspect the request contract for one YouMind OpenAPI operation. Use before calling an unfamiliar API.',
    parameters: {
      apiName: { type: 'string', required: true, description: 'Exact API operation name returned by youmind_search_api.' },
    },
    output: { schema: { type: 'json' }, render: renderJson },
    execute: (args, exec) => readApi(ctx.credentials, args.apiName, exec.signal),
  }))

  ctx.tools.register(defineTool({
    name: 'youmind_call_api',
    description: 'Call a YouMind OpenAPI operation. Discover and inspect the operation first. For move, trash, restore, publish, install, paid, or other mutating actions, call only when the user has clearly authorized that exact action.',
    parameters: {
      apiName: { type: 'string', required: true, description: 'Exact YouMind OpenAPI operation name.' },
      params: { type: 'object', additionalProperties: true, description: 'Request body matching youmind_api_info.' },
    },
    output: { schema: { type: 'json' }, render: renderJson },
    execute: (args, exec) => callApi(ctx.credentials, args.apiName, args.params ?? {}, exec.signal),
  }))

  ctx.tools.register(defineTool({
    name: 'youmind_find',
    description: 'Search the user\'s saved YouMind library or a specific board for relevant knowledge.',
    parameters: {
      query: { type: 'string', required: true, description: 'Semantic search query.' },
      scope: { type: 'string', enum: ['library', 'board'], description: 'Search all saved knowledge or one board. Defaults to library.' },
      boardId: { type: 'string', description: 'Required when scope is board.' },
      topK: { type: 'number', description: 'Maximum number of results.' },
    },
    output: { schema: { type: 'json' }, render: renderJson },
    async execute(args, exec) {
      const scope = args.scope ?? 'library'
      if (scope === 'board' && !args.boardId) throw new Error('scope 为 board 时必须提供 boardId。')
      return request(ctx.credentials, '/openapi/v1/search', {
        method: 'POST',
        authenticated: true,
        body: {
          query: args.query,
          scope,
          ...(args.boardId ? { boardId: args.boardId } : {}),
          ...(args.topK !== undefined ? { topK: args.topK } : {}),
        },
        signal: exec.signal,
      })
    },
  }))

  ctx.tools.register(defineTool({
    name: 'youmind_web_search',
    description: 'Search the public web through YouMind, with category, freshness, and domain filters.',
    parameters: {
      query: { type: 'string', required: true, description: 'Web search query.' },
      category: { type: 'string', enum: ['general', 'image', 'video', 'news', 'tweet', 'finance', 'scholar'], description: 'Search category.' },
      freshness: { type: 'string', enum: ['day', 'week', 'month', 'year'], description: 'Optional recency filter.' },
      includeDomains: { type: 'array', items: { type: 'string' }, description: 'Only include these domains.' },
      excludeDomains: { type: 'array', items: { type: 'string' }, description: 'Exclude these domains.' },
    },
    output: { schema: { type: 'json' }, render: renderJson },
    execute: (args, exec) => request(ctx.credentials, '/openapi/v1/webSearch', {
      method: 'POST',
      authenticated: true,
      body: {
        query: args.query,
        ...(args.category ? { category: args.category } : {}),
        ...(args.freshness ? { freshness: args.freshness } : {}),
        ...(args.includeDomains?.length ? { includeDomains: args.includeDomains } : {}),
        ...(args.excludeDomains?.length ? { excludeDomains: args.excludeDomains } : {}),
      },
      signal: exec.signal,
    }),
  }))
}

export function apply(ctx) {
  registerSkill(ctx)
  registerTools(ctx)
}

export const testing = {
  apiKey,
  assertApiName,
  describeHttpError,
  parseResponseBody,
}
