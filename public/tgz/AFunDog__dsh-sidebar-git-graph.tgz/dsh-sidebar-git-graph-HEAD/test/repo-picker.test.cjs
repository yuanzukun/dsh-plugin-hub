/**
 * 仓库选择器（客户端半身）测试：下拉项文案与"按工作区记住选择"这两件事。
 *
 * 单独测的理由：这两处都是**看代码觉得显然、用起来才发现错**的地方。
 *   - 后缀只截末两段：嵌套仓库的 `vendor/@scope/zz-inner` 与同名的 `zz-inner` 得能分开，
 *     而工作区**之外**的仓库相对路径是 `..\..`，直接显示等于没显示；
 *   - 记忆必须按工作区分键：两个工作区里各有一个 `backend` 是常态，串了就莫名其妙。
 *
 * 跑法：node test/repo-picker.test.cjs
 */
const assert = require('node:assert')
const { loadInternals } = require('./helpers/load-client.cjs')

/** 桩 localStorage：够用、可数、可断言。 */
function fakeStorage() {
  const map = new Map()
  return {
    map,
    getItem(key) { return map.has(key) ? map.get(key) : null },
    setItem(key, value) { map.set(key, String(value)) },
    removeItem(key) { map.delete(key) },
  }
}

async function main() {
  const storage = fakeStorage()
  const internals = loadInternals({ localStorage: storage })
  const { repoSuffix, repoOptionLabel, repoPicker, readSavedRepo, saveRepo, constants } = internals

  // ── 下拉项后缀 ───────────────────────────────────────────────────────────
  assert.strictEqual(repoSuffix({ root: 'D:\\ws', rel: '', outside: false }), '工作区根')
  assert.strictEqual(
    repoSuffix({ root: 'D:\\ws\\vendor\\@scope\\zz-inner', rel: 'vendor\\@scope\\zz-inner', outside: false }),
    '@scope/zz-inner',
    '嵌套仓库要带上它的上一层，才能和同名的仓库区分开',
  )
  assert.strictEqual(
    repoSuffix({ root: 'D:\\ws\\pkg', rel: 'pkg', outside: false }),
    'pkg',
    '只有一段时就是它自己',
  )
  assert.strictEqual(
    repoSuffix({ root: 'D:\\GitRepository\\dsh-config', rel: '..\\..', outside: true }),
    '…/GitRepository/dsh-config',
    '工作区之外的仓库要看绝对路径的末两段，相对路径的 `..\\..` 没法读',
  )
  assert.strictEqual(
    repoSuffix({ root: '/home/me/proj', rel: '../proj', outside: true }),
    '…/me/proj',
    '走 POSIX 分隔符也一样',
  )

  // ── 下拉项的整行文案 ─────────────────────────────────────────────────────
  // 关联工作树（kind: 'worktree'）显示**分支**而不是路径：同一个仓库的各个工作树常常
  // 就在同一个父目录下、名字只差一个后缀 —— 路径的区分度很低，而分支几乎必然不同。
  assert.strictEqual(
    repoOptionLabel({ root: 'D:\\ws', rel: '', outside: false, name: 'ws', kind: 'repo' }),
    'ws · 工作区根',
    '普通仓库（含嵌套仓库）维持原样',
  )
  assert.strictEqual(
    repoOptionLabel({ root: 'D:\\a\\proj', rel: '..\\..', outside: true, name: 'proj', kind: 'worktree', branch: 'feat/x', main: false }),
    'proj · feat/x',
    '关联工作树要显示它自己的分支 —— 那才是人在这个下拉里要找的东西',
  )
  assert.strictEqual(
    repoOptionLabel({ root: 'D:\\a\\proj', rel: '', outside: false, name: 'proj', kind: 'worktree', branch: 'main', main: true }),
    'proj · main（主工作树）',
    '主工作树要标出来，否则"哪个是主工作区"只能靠猜',
  )
  assert.strictEqual(
    repoOptionLabel({ root: 'D:\\a\\det', rel: '..\\det', outside: true, name: 'det', kind: 'worktree', branch: null, detached: true, head: 'abcdef1234567890', main: false }),
    'det · 分离头 abcdef12',
    '分离头的工作树没有分支名：用短 sha 顶替，比印一遍与名字重复的路径有用',
  )
  assert.strictEqual(
    repoOptionLabel({ root: 'D:\\a\\det', rel: '..\\det', outside: true, name: 'det', kind: 'worktree', branch: null, detached: true, head: null, main: false }),
    'det · …/a/det',
    '连 sha 都拿不到时才退回路径后缀',
  )
  assert.strictEqual(
    repoOptionLabel({ root: 'D:\\a\\lk', rel: '..\\lk', outside: true, name: 'lk', kind: 'worktree', branch: 'b/z', locked: true, main: false }),
    'lk · b/z（已锁定）',
    '被 lock 的工作树内容可读，标记出来免得被当成坏了',
  )
  // 旧宿主不带 kind（前后端版本错位）：必须退回老文案，不能显示成空或崩。
  assert.strictEqual(
    repoOptionLabel({ root: 'D:\\ws', rel: '', outside: false, name: 'ws' }),
    'ws · 工作区根',
    'kind 缺席时要退回老行为（宿主半与浏览器半会先后升级）',
  )

  // ── 按工作区记忆 ─────────────────────────────────────────────────────────
  assert.strictEqual(readSavedRepo('D:/ws'), undefined, '没记过就是 undefined')
  saveRepo('D:/ws', 'D:/ws/vendor/@scope/zz-inner')
  assert.strictEqual(readSavedRepo('D:/ws'), 'D:/ws/vendor/@scope/zz-inner')
  assert.strictEqual(readSavedRepo('D:/other'), undefined, '别的作区不该读到同一个选择')
  saveRepo('D:/other', 'D:/other/backend')
  assert.strictEqual(readSavedRepo('D:/ws'), 'D:/ws/vendor/@scope/zz-inner', '两个工作区互不覆盖')
  assert.strictEqual(readSavedRepo('D:/other'), 'D:/other/backend')
  assert.strictEqual(storage.map.size, 2, '一个工作区一条记录')

  // 空值不该写进去（免得把好好的记忆擦成空串）。
  saveRepo('D:/ws', '')
  assert.strictEqual(readSavedRepo('D:/ws'), 'D:/ws/vendor/@scope/zz-inner')
  saveRepo('', 'D:/ws')
  assert.strictEqual(readSavedRepo('D:/ws'), 'D:/ws/vendor/@scope/zz-inner')
  assert.strictEqual(readSavedRepo(undefined), undefined)
  assert.strictEqual(readSavedRepo(null), undefined)

  // 存储不可用（无痕模式等）不该炸：不许抛错，只是不记。
  const hostile = loadInternals({
    localStorage: {
      getItem() { throw new Error('storage disabled') },
      setItem() { throw new Error('storage disabled') },
    },
  })
  assert.strictEqual(hostile.readSavedRepo('D:/ws'), undefined)
  hostile.saveRepo('D:/ws', 'D:/ws/a')

  // ── 控件元素树 ───────────────────────────────────────────────────────────
  // 记录式的 h：把 createElement 的入参原样留下，就能断言"造出来的是什么"。
  const record = (type, props, ...children) => ({
    type,
    props: props === null || props === undefined ? {} : props,
    children: children.flat(),
  })

  const one = repoPicker(record, { repos: [{ root: 'D:/ws', rel: '', outside: false, name: 'ws' }], currentRoot: 'D:/ws', title: 'ws', onPick() {} })
  assert.strictEqual(one.type, 'span', '只有一个仓库时不该出现下拉框')
  assert.strictEqual(one.props.className, 'zgg-repo')
  assert.strictEqual(one.children[0], 'ws')

  const two = repoPicker(record, {
    repos: [
      { root: 'D:/ws', rel: '', outside: false, name: 'ws' },
      { root: 'D:/ws/vendor/@scope/zz-inner', rel: 'vendor\\@scope\\zz-inner', outside: false, name: 'zz-inner' },
    ],
    currentRoot: 'D:/ws/vendor/@scope/zz-inner',
    title: 'ws',
    onPick() {},
  })
  assert.strictEqual(two.type, 'select')
  assert.ok(two.props.className.includes('zgg-repo-select'), '要挂上自己的类名才有的样式')
  assert.strictEqual(two.props.value, 'D:/ws/vendor/@scope/zz-inner', '当前项必须选中，否则下拉显示的和画出来的不是一个仓库')
  assert.strictEqual(two.props['aria-label'], '切换仓库')
  assert.strictEqual(two.children.length, 2)
  assert.deepStrictEqual(
    two.children.map((option) => ({ type: option.type, value: option.props.value, title: option.props.title, text: option.children[0] })),
    [
      { type: 'option', value: 'D:/ws', title: 'D:/ws', text: 'ws · 工作区根' },
      { type: 'option', value: 'D:/ws/vendor/@scope/zz-inner', title: 'D:/ws/vendor/@scope/zz-inner', text: 'zz-inner · @scope/zz-inner' },
    ],
    'option 的 value 必须是仓库**根**：写名字或相对路径的话，选完宿主机认不出来',
  )

  // 选中回调拿到的就是仓库根。
  const picked = []
  const interactive = repoPicker(record, {
    repos: [{ root: 'a', rel: '', outside: false, name: 'a' }, { root: 'b', rel: 'b', outside: false, name: 'b' }],
    currentRoot: 'a',
    title: 'a',
    onPick: (root) => picked.push(root),
  })
  interactive.props.onChange({ target: { value: 'b' } })
  assert.deepStrictEqual(picked, ['b'])

  // 空列表（还没加载出来）走纯文本分支，不该崩。
  const none = repoPicker(record, { repos: [], currentRoot: undefined, title: 'Git 图谱', onPick() {} })
  assert.strictEqual(none.type, 'span')
  assert.strictEqual(none.children[0], 'Git 图谱')

  // ── 两半身的默认值必须一致 ───────────────────────────────────────────────
  const { DEFAULT_DEPTH } = await import('../lib/repos.js')
  assert.strictEqual(
    constants.DEFAULT_SCAN_DEPTH,
    DEFAULT_DEPTH,
    '浏览器半身与宿主半身的默认扫描层数必须一致，否则「没设置过」的两个人看到的清单不一样',
  )

  // ── 会话 worktree 联动的提示文案（2026-10-01）─────────────────────────────
  //
  // 这两条都是"不说就会让人误会"的话：
  //   - 跟随标签换了仓库 → 用户会奇怪"我没选这个啊"；
  //   - 有标签但用不了 → **最糟的失败模式**：用户以为标签生效了，
  //     实际画的是完全不同的仓库。必须说清是哪一种失败。
  {
    const { tagNotice, tagNoticeCopy, isNewHost } = internals

    // 没跟随：不出声。
    // ⚠️ 用 `.kind` 比较而不是 `deepStrictEqual(…, {kind:'none'})`：这个对象是**跨模块
    // 边界**回来的（客户端 bundle 里的字面量），原型不同，deepStrictEqual 会判不等。
    assert.strictEqual(tagNotice(undefined).kind, 'none')
    assert.strictEqual(tagNotice(null).kind, 'none')
    assert.strictEqual(tagNotice({ requested: null, source: 'cwd' }).kind, 'none')
    assert.strictEqual(tagNoticeCopy({ kind: 'none' }, 'repo'), '')

    // 跟随了：说清跟的是哪个路径，并告诉用户怎么改回固定。
    const followed = tagNotice({ tagApplied: true, tagged: 'D:/ws/vendor/kit', tagReason: null })
    assert.strictEqual(followed.kind, 'followed')
    assert.strictEqual(followed.tagged, 'D:/ws/vendor/kit')
    const followedCopy = tagNoticeCopy(followed, 'repo')
    assert.ok(followedCopy.includes('D:/ws/vendor/kit'), `要说清跟的是哪个：${followedCopy}`)
    assert.ok(followedCopy.includes('下拉'), '要告诉用户怎么改回固定画一个仓库')

    // 跟随了但 tagged 是空串（旧宿主 / 脏数据）→ 不出声，而不是说一句没有主语的废话。
    assert.strictEqual(tagNotice({ tagApplied: true, tagged: '' }).kind, 'none')

    // 被拒：三种原因各有各的说法，且都要提到"已改画"。
    for (const [reason, needle] of [['missing', '不在'], ['not-root', '不是仓库根'], ['fenced', '可访问']]) {
      const rejected = tagNotice({ tagApplied: false, tagged: 'D:/gone', tagReason: reason })
      assert.strictEqual(rejected.kind, 'rejected')
      assert.strictEqual(rejected.reason, reason)
      const copy = tagNoticeCopy(rejected, 'repo')
      assert.ok(copy.includes(needle), `${reason} 的说法要准确：${copy}`)
      assert.ok(copy.includes('已改画'), `${reason} 必须说明改画了哪个：${copy}`)
      assert.ok(copy.includes('D:/gone'), `${reason} 要说清标签指的是哪里：${copy}`)
    }
    // 不认识的原因也要说人话（不能漏出 `undefined`）。
    const unknown = tagNoticeCopy(tagNotice({ tagApplied: false, tagged: '', tagReason: 'weird' }), 'repo')
    assert.ok(unknown.includes('用不了'), unknown)
    assert.ok(!unknown.includes('undefined'), unknown)

    // 形状标记：schema >= 2 就算新宿主。
    assert.strictEqual(isNewHost({ schema: 2 }), true)
    assert.strictEqual(isNewHost({ schema: 3 }), true, 'schema 向后兼容地递增，>= 2 都算新宿主')
    assert.strictEqual(isNewHost({ schema: 99 }), true, '将来再加字段不该把新宿主误判成旧宿主')
    assert.strictEqual(isNewHost({ schema: 1 }), false, 'schema 1（更早的预览版）没有本插件要的字段')
    assert.strictEqual(isNewHost({}), false, '旧宿主没有这个字段')
    assert.strictEqual(isNewHost({ schema: '2' }), false, '字符串不算（宿主给的是数字）')
    assert.strictEqual(isNewHost(null), false)
    assert.strictEqual(isNewHost('x'), false)
    // ⚠️ 这个判据**必须真的被页面用到**，否则「新前端 + 旧宿主」时跟随标签会静默不生效，
    // 而页面看起来一切正常（2026-10-01 首版实现就是定义了却没调用）。
    const bundle = require('node:fs').readFileSync(require('node:path').join(__dirname, '..', 'lib', 'client.js'), 'utf8')
    assert.ok(/if \(value !== undefined && !isNewHost\(value\)\)/.test(bundle),
      'isNewHost 必须在 notices 里被真正调用（不能只是导出给人看）')
  }

  // ── 工作目录被删之后的提示文案（2026-10-17）──────────────────────────────
  //
  // 现场：会话/标签页手里攥着一个**已经删掉的关联工作树**，宿主改用还活着的候选继续画。
  // 换地方是对的，不吭声就不对了——用户上次明明站在那个工作树里，页面却自己换了仓库。
  {
    const { staleWorkspaceNotice } = internals

    // 没换地方：不出声。
    // ⚠️ 与上面同理，用 `.kind` 而不是 deepStrictEqual：对象是跨模块边界回来的。
    assert.strictEqual(staleWorkspaceNotice(undefined).kind, 'none')
    assert.strictEqual(staleWorkspaceNotice(null).kind, 'none')
    assert.strictEqual(staleWorkspaceNotice({}).kind, 'none')
    assert.strictEqual(staleWorkspaceNotice({ cwd: 'D:/ws', source: 'session', stale: null }).kind, 'none')
    assert.strictEqual(staleWorkspaceNotice({ cwd: 'D:/ws', stale: {} }).kind, 'none', '脏数据（没有 path）不该硬凑一句话')

    // 换了：两头都要说清——少了哪一个都读不懂。
    const notice = staleWorkspaceNotice({ cwd: 'D:/ws', source: 'session', stale: { path: 'D:/ws/.worktree/gone', source: 'claimed' } })
    assert.strictEqual(notice.kind, 'stale')
    assert.ok(notice.copy.includes('D:/ws/.worktree/gone'), `要说清原来那个是哪里：${notice.copy}`)
    assert.ok(notice.copy.includes('D:/ws'), `要说清这次画的是哪里：${notice.copy}`)
    assert.ok(!notice.copy.includes('undefined'), notice.copy)

    // ⚠️ 与 isNewHost 同一条教训：判据必须**真的被 notices 用到**。定义了却不调用，
    // 表现是"宿主明明换了地方、页面一声不吭"，而页面看起来一切正常。
    const bundle = require('node:fs').readFileSync(require('node:path').join(__dirname, '..', 'lib', 'client.js'), 'utf8')
    assert.ok(/staleWorkspaceNotice\(value\.workspace\)/.test(bundle),
      'staleWorkspaceNotice 必须在 notices 里被真正调用（不能只是导出给人看）')
  }

  console.log('repo-picker.test.cjs: OK')
}

main().catch((error) => {
  console.error(error)
  process.exit(1)
})
