# Changelog

All notable changes to this plugin are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- **Click a commit to see which files it touched — and open any of them.** The expanded commit detail
  now lists the changed files (status letter, the original name for renames, per-file `+/−` counts),
  and each row expands its patch **in place**, reusing the Changes area's rendering. Two new host
  methods back it (`commit`, `commitDiff`); both are fenced exactly like the existing ones and remain
  strictly read-only.
  - **A merge commit is compared against its first parent**, and the heading says so. Without
    `--first-parent`, `git show --name-status` answers **nothing** for a merge — git defaults to a
    combined diff, and a clean merge changes nothing relative to *all* parents. Measured: a clean
    merge produced **empty output**, while a conflict-resolved one produced the two-letter `MM`
    status. Both belong to the "silent wrong answer" family this project keeps getting bitten by.
  - The sha must sit **before** `--` (after it everything is a pathspec, so the sha matches no path:
    empty output, no error), and a rename's patch needs **both** paths (`-M` cannot recognise the
    rename otherwise and the output degrades to "whole file added" — measured: 1 added line → 3).
  - A binary file says "binary file, no line-by-line diff" when expanded instead of showing an empty
    diff; an empty commit says so; a capped list says "N in total, first M listed".
  - A host that predates these methods answers `bad-method`, and the page tells you to restart DSH
    rather than looking broken.
  - Tests: `test/commit-files.test.cjs` (parsers and argv, driven by byte-exact real git output),
    `test/route.test.cjs` (real repositories: a merge's file list must be non-empty, a rename given
    both paths must add exactly one line), `test/commit-files-view.test.cjs` (the copy for the
    merge/empty/truncated/old-host cases, the click callback, and a bundle check that the section is
    actually rendered into the detail block).

- **The page now says when its picture of the remote is behind.** The graph is drawn from the
  **local** repository and this plugin never touches the network — that is the read-only promise.
  A merge that just happened *on the remote* is therefore invisible until someone runs
  `git fetch`, which is exactly how a user came to suspect the graph was broken after an agent
  reported merging a branch into `develop`. The page now explains itself instead of leaving that
  ambiguity, from two independent pieces of evidence:
  - **how long ago the repository last fetched** — the load-bearing one. In the reported case the
    local branch and its **stale** remote-tracking ref pointed at the *same* commit, so a
    behind-count was `0`; only fetch age could reveal it. The host stats `FETCH_HEAD` in the
    working tree's own git dir **and** the common one and takes the newer, because a linked
    working tree has its own file (measured: 11:10 vs 10:36 on one machine) and you may well fetch
    in the main working tree and read the graph in a linked one.
  - **which local branches are behind their upstream** — known locally, no network needed.
  - Threshold is 6 hours. A repository that has **never** fetched is reported as having no remote
    rather than as stale — those are different facts.
  - `%(upstream:track)` is now parsed, including the `[gone]` case (the upstream ref was deleted),
    which is *not* the same as "no upstream configured".
  - `test/freshness.test.cjs` builds a real repository and a real bare remote, makes a real
    `git fetch`, then moves the timestamps with `utimes` — so the awkward parts (two `FETCH_HEAD`
    files in a linked working tree, a repository that never fetched) are tested against real git
    rather than a pure function's idea of it.
- Payloads now carry `schema: 3`.

### Changed

- **The commit detail now expands directly under the commit you clicked**, instead of at the bottom of
  the list. It used to be rendered after the whole virtualized list, so whichever row you clicked you
  had to scroll all the way down to see what it touched. The list's vertical mapping is now
  parameterised (`listOffsets`: `yAt` / `rowAt`) so the rows below shift down and the lane lines
  **stretch** across the inserted block — one source of geometry, so the graph can never drift out of
  step with the rows. The block measures its own height (`useLayoutEffect`, before paint, so the
  "panel still overlapping the next rows" frame is never shown), caps it at 60% of the viewport with
  its own scrolling, and scrolls the view just once per expansion so the block is revealed.
  - ⚠️ Both directions of the mapping had to change together: rows and lane geometry use `yAt`, while
    the virtual window derives row numbers from `scrollTop` via `rowAt`. Fixing only the forward
    direction misplaces the window by `gap / ROW_H` rows once you scroll past the block (the list
    goes blank, or the same rows are rendered twice). `test/lane-layout.test.cjs` pins `rowAt` as the
    inverse of `yAt`.
  - The block needs a positive `z-index`: the lane SVG is `z-index: 1` and this block is a positioned
    sibling — without it the lane lines are painted on top of the panel.

- **`isNewHost` is now `schema >= 2` instead of `schema === 2`.** Adding a field used to make the
  browser half classify a *newer* host as old and tell the user to restart — the opposite of the
  intent. A specific field's presence is judged by that field, never by the schema number.

### Fixed

- **A lane no longer breaks at a row boundary.** When a commit's second (or later) parent was
  **already** being waited for on another lane, that lane was omitted from the row's through-lines,
  so the connector that had arrived from the row above simply stopped — one whole row of the lane
  went missing. The curve was drawn, so the row did not look empty; it looked like the line had
  been erased underneath it. Measured on this machine: **40 broken seams across 8 repositories**
  (3109 seams scanned). The smallest shape is only **two rows**: a merge `M` whose parents are
  `[A, C]` (so `C` goes in flight on a second lane), followed by `A` whose parents are `[B, C]`
  (so `C` is *already* in flight when `A` names it as a non-first parent).
  - The distinction that was missing: a branch curve's **destination** lane is either opened by
    this very row (nothing above it — no through-line, correct) or was already waiting for that
    parent (a line arrives from above **and** continues below — the through-line is mandatory).
    Treating both alike is what erased the line.
  - Regression test: `test/graph-continuity.test.cjs` — asserts the seam invariant on a verbatim
    reproduction of the reported shape, on seven hand-written shapes, and on 300 seeded random
    DAGs; it fails on the pre-fix code.
- **Hovering a row no longer erases the graph on that row.** The SVG is the sizer's first child
  while every row is an absolutely-positioned, opaque box later in DOM order, so a row's
  background — from `:hover` **or** from `[data-selected="true"]` — painted over the entire lane
  column. `pointer-events: none` was already set and does not help: it governs hit-testing, not
  paint order. The SVG is now raised to `z-index: 1`. Measured on the lane column: **23 of the 24
  pixels inside the hovered row** were row-background before, **0 of 24** after, while the graph
  keeps its ink and rows still select when you click the graph column.
  - `test/graph-continuity.test.cjs` pins the stylesheet contract (SVG has a positive `z-index`,
    still `pointer-events: none`; `.zgg-sizer` is positioned; `.zgg-row` carries no positive
    `z-index`).

- **A deleted working tree no longer blanks the whole page.** The browser sends the working
  directory it was handed, and the host accepted a path that merely *lies inside* a registered
  workspace — a containment test. Deleting a linked working tree changes neither fact:
  `canonical()` falls back to `resolve()` when `realpath` fails, so the path still canonicalises,
  and it is still inside the workspace. The host then hit its "does this directory exist" guard —
  which ran **before** the repository ladder — and answered `工作目录不存在: …` while the session's
  own working directory sat right there, alive, one candidate away. The five-step fallback the page
  advertises never got a turn.
  - Fixed in two places: a browser-supplied path now has to **exist** to outrank a live host
    candidate, and the chosen candidate being gone is no longer fatal — the host walks the
    remaining candidates (session → persisted workspace table → registry → newest session
    directory) and uses the first one that exists.
  - The skipped path is **reported, not swallowed**: `workspace.stale` carries `{ path, source }`
    and the page says which directory is gone and where it drew instead — the same rule the
    worktree label already followed (`tagReason`). Silently drawing somewhere else is the worst
    failure mode here.
  - Only when **every** candidate is gone does it still fail, and the error keeps naming the exact
    directory — that specificity is why the guard existed in the first place.
  - Regression tests: `test/route.test.cjs` (a dead path *inside* the workspace plus a live session
    cwd must still draw and must report the skip; a live claimed path keeps winning; all-dead still
    fails naming the path; no-candidates still names the path) and `test/repo-picker.test.cjs` (the
    notice's copy, plus a bundle check that the notice is actually called — `isNewHost` was once
    defined and never invoked).
- Payloads now carry `schema: 4` (adds `workspace.stale`).

## [0.5.0] - 2026-10-01

### Added

- **The page can follow the session's worktree label.** When `@zeng/dsh-session-worktree` is
  installed and enabled, the graph opens on the working tree that session is labelled with,
  instead of always the repository the working directory happens to be in. "Is it enabled" needs
  no detection code: the label is published as a host service (`ctx.get('sessionWorktree')`),
  which cordis returns as `undefined` when the plugin is absent or disabled — including when it
  is switched off later, since the service disappears with its fiber.
  - Repository priority is now **your click > session worktree label > last remembered >
    repository of the working directory > first scanned repository**.
  - ⚠️ The last-remembered repository had to be **demoted from a request to a hint**. It used to
    be sent as `repo`, which always won — so once you had picked anything from the dropdown, the
    label could never apply. It is now sent as `repoHint`.
  - The page **says which of these it followed**, and says so louder when it could not: a label
    pointing outside what the page may read is reported with its reason rather than silently
    swapped for a different repository.
  - The label is fenced exactly like your own click (the directory must exist, be a repository
    root, and be related to the workspace or be a working tree of the workspace's repository).
    Another plugin's data is not more trustworthy than the browser's.
- Payloads now carry `schema: 2`.

## [0.4.0] - 2026-09-30

### Added

- **Every working tree of the repository, including the linked ones outside the workspace.** A
  repository can have more than one working tree (`git worktree add`), each with its own branch
  and its own uncommitted changes. They can live **anywhere** — measured on this machine, the
  main working tree and its linked one are *sibling* directories, and the linked one's `.git` is
  a one-line **file** pointing back at `.git/worktrees/<name>`. Filesystem scanning can never
  find them, so the page now asks git itself (`git worktree list --porcelain -z`) and lists them
  next to the main working tree, each labelled with **its own branch**.
  - The picker's label for a working tree is its branch, not its path: two working trees of one
    repository typically sit in the same parent directory with names that differ by a suffix —
    the paths barely distinguish them, while the branches always do. The main working tree,
    detached heads (shown as `detached <short sha>`), and locked working trees are marked.
  - A workspace that *is* a linked working tree now also offers the main one — before this
    release the picker held exactly one entry and the main working tree was unreachable.
  - Stale entries (`prunable`: the directory is gone) and bare repositories are never listed; a
    notice says how many were skipped, so "I have 5 working trees but the page shows 4" is never
    a silent discrepancy.
- **`lib/worktrees.js`** — argv construction and parsing as pure functions, importable and
  testable outside DSH, like `lib/git-read.js` and `lib/changes.js`.

### Fixed

- **Naming a working tree of the same repository was refused, and the page blamed the wrong
  thing.** The fence only allowed the workspace itself, something inside it, or something
  enclosing it — but a linked working tree is none of those (it is a sibling). The request was
  silently rejected, the page fell back to the main working tree and said *"the repository you
  picked is gone"* about a repository that was perfectly fine. The fence now also accepts the
  working trees **git itself lists for that repository** (see Security), and the notice says what
  actually happened: `missing`, `prunable`, `not-root` or `out of the allowed range`.
- **The repository picker vanished whenever the commit-graph request failed.** The list was only
  read from the `graph` payload, although `changes` carries the same list. It now uses whichever
  arrived.
- **The "scan incomplete" notice could point the wrong way.** It always said to *lower* the
  repository scan depth — but when the depth cap is what truncated the list, lowering it makes
  the list shorter, not complete. The host had been reporting `reposTruncatedBy`
  (`repos`/`dirs`/`time`) all along and the client ignored it; the notice is now derived from it.

### Security

- The fence was widened by exactly one rule: a client-supplied repository path is accepted if it
  appears in `git worktree list` for **the repository the workspace is in**. The list is asked of
  a host-chosen anchor, never of the path being requested — asking the requested path would let it
  vouch for itself (an earlier draft did exactly that and `test/route.test.cjs`'s "a repository
  outside the workspace must be refused" caught it). The existing gates are unchanged: the path
  must exist, `rev-parse --show-toplevel` must confirm it is itself a repository root, and it must
  match the listed path after normalization. `prunable` and `bare` entries are excluded from both
  the list and the allow-set.
- `lib/worktrees.js` can only ever build `worktree list`; `add`/`remove`/`prune`/`lock`/`move`
  fail the read-only invariant test.

### Tests

- `test/worktrees.test.cjs` — byte-level parsing of real `-z` output (spaces in paths, detached,
  locked, prunable, bare, non-ASCII), the read-only invariant, and an end-to-end run against six
  real working-tree shapes in a throwaway repository: the outside working tree is accepted and
  drawn with its own branch, an unrelated repository is still refused, the reverse direction
  (workspace *is* a linked working tree → the main one is offered and switchable), per-working-tree
  state isolation (a file created in one is invisible to the other), and the single-working-tree
  repository behaving exactly as before. Verified to have teeth by mutation: dropping the
  working-tree allowance, dropping the `prunable` filter, dropping the `kind`/`branch` fields, and
  collapsing the rejection reasons each turn it red.
- `test/repo-picker.test.cjs` — the picker label for branch / main / detached / locked working
  trees, and the old behaviour when an older host sends no `kind` (version skew is normal here).

## [0.3.0] - 2026-09-30

### Added

- **A "Changes" area above the graph** (VS Code style). Two foldable sections — *Changes* and
  *Staged Changes*, plus *Merge Changes* when a merge is in progress — with a status letter per
  row (`M`/`A`/`D`/`R`/`C`/`U`), the added/deleted line counts from `git diff --numstat`, and
  click-to-expand inline diffs. Section fold state is remembered.
  - A file changed on both sides (`MM`) appears in **both** sections — that is what the two
    sections mean.
  - Untracked files show no `+/−` counts: `git diff --no-index` takes two paths, so counts would
    cost one process per file. The section header counts only what it can count, and says so
    rather than printing a `0` that would read as "no changes".
  - A nested independent repository appears as one directory row, marked as not clickable with
    the reason shown — `git` does not descend into it, so it has no diff to show.
  - New read-only route methods `changes` and `diff` on the existing
    `POST /dsh-sidebar-git-graph/api`, dispatched by the `method` field of the request envelope
    (which the client had always sent and the host had always ignored). `graph` is unchanged and
    a request with no `method` still means `graph`, so older clients keep working.
  - `lib/changes.js` — argv construction and output parsing as pure functions, importable and
    testable outside DSH.

### Security

- Paths arriving from the browser are fenced twice: `--literal-pathspecs` disables git's pathspec
  magic (without it a path like `:(top)*` turns "read one file" into "read the whole tree"), and
  `isRepoRelativePath` rejects absolute paths, drive letters, `..`, backslashes, a leading `-` or
  `:`, and NUL/newline characters before any git process is spawned.
- Patch output is capped at 512 KiB and diff commands carry `--no-color --no-ext-diff
  --no-textconv`, so a repository's own config cannot make `git diff` execute a command.

### Fixed

- **Every line of a CRLF file was reported as changed.** The sanitized git environment set
  `GIT_CONFIG_NOSYSTEM=1` to keep a repository's own configuration out of the commands. That also
  dropped the *system* config — and Git for Windows ships `core.autocrlf=true` there. In a
  repository whose index holds LF and whose working tree holds CRLF, every line then differs:
  `docs/README.md` went from `+1 −0` to `+88 −87`, and a one-line addition was drawn as a
  whole-file rewrite. Four neighbouring files happened to be stored with CRLF in the index and
  looked correct, so "most rows are right" made it easy to miss. Found by comparing the page's
  numbers against `git diff --numstat` on the same working tree.
  - The fix is to set **neither** `GIT_CONFIG_NOSYSTEM` nor `GIT_CONFIG_SYSTEM`: git then finds
    its own system config, exactly as the user's own `git` does. Pointing `GIT_CONFIG_SYSTEM` at
    an empty string reproduces the same bug (measured), so "redirect it instead" is not a safe
    variant.
  - Repository-level `filter.*` and `diff.*.textconv` are still removed from the command line,
    since those make git execute external programs while reading a repository.
- **A stale host would have been reported as "no uncommitted changes".** Version skew is real
  here: the browser half is re-read on every page load (its `rev` comes from file mtime), while
  the host half only picks up changes on a restart. An older host ignores the request's `method`
  and answers `changes` with *commit-graph* data — `ok: true`, no error, no `sections`. A
  normalize-missing-fields-to-empty-arrays approach then produced three empty sections and the
  page printed **"✓ no uncommitted changes"** for a client that had never asked about the working
  tree at all. A confident false statement is worse than a blank page. The client now checks that
  the response actually looks like the payload it asked for and, when it does not, says so and
  points at the fix (restart `dsh web`). Found on a real machine, in exactly this skew.
- **A conflicted file showed an empty diff.** Unmerged paths make `git diff` emit a *combined*
  diff (`@@@` hunks with two-character prefixes) that a unified-diff reader cannot parse, so the
  parser silently returned zero lines — an empty answer with no error attached. Conflicts now
  compare against `HEAD` (a normal unified diff, showing the file exactly as it is on disk,
  conflict markers and all), and the parser recognises a combined diff and says so rather than
  reporting "no changes".
- The request envelope's `method` field is now honored. An unknown method returns an explicit
  error instead of silently running the commit log, which used to be indistinguishable from
  "my change had no effect".
- **Four crashes that blanked the whole page** when the host returned an unexpected shape
  (`repo: null`, `sections: null`, a missing `totals`, a non-array section). The graph half had
  these too, from before this release. A throw inside the page component takes the commit graph
  down with it, so the risky reads are now normalized up front. Found by
  `test/render-smoke.test.cjs`, which renders the real component against deliberately malformed
  responses.

### Tests

- `test/changes.test.cjs` — parsing of real `git status --porcelain=v2 -z` /
  `git diff --numstat -z` bytes (including the 11-field `u` unmerged record, which is **not**
  shaped like `1`/`2`, and paths containing spaces), plus end-to-end runs against temporary
  repositories: every status letter, `--no-index`'s exit code 1 meaning success, renames needing
  both paths, binary files, empty repositories, the row cap, and the route dispatch.
- A **read-only invariant** test: every argv builder is asserted to produce only
  `status`/`diff`. Adding a staging feature later will fail this test rather than quietly
  contradicting the README.
- `test/changes-view.test.cjs` — the browser half's path shortening (scope packages keep two
  segments), row copy, absent-count handling, non-text diff states, and section fold persistence.
- `test/render-smoke.test.cjs` — renders the real page component against malformed host responses.
  A throw in that component blanks the page *including the commit graph*, and the other tests only
  covered pure functions, so this failure mode was invisible to them. It found four real crashes
  on its first run; the graph half had been carrying three of them since before this release.
- `test/end-to-end-render.test.cjs` — **crosses the two halves**: real repositories, the real host
  handlers, and the real render path, asserting the text on the page against what is actually in
  the working tree. Every other test stopped at the seam between the halves and used a payload
  shape its author had imagined; the stale-host bug lived exactly in that seam. Verified to have
  teeth by mutation: dropping conflict rows, breaking the `untracked` flag, and discarding rename
  origins each make it fail.

## [0.2.0] - 2026-09-29

### Added

- **Repository picker**: a workspace that holds more than one repository now gets a picker in the
  page header, listing every repository found inside the workspace (and the repository enclosing
  it, when the workspace is only a subdirectory of one). The choice is remembered per workspace.
  - `lib/repos.js` discovers repository roots by scanning downwards, with four gates (depth,
    directory count, repository count, elapsed time) so a request can never turn into a full-disk
    walk. Hitting a gate is reported in the page instead of being hidden.
  - Directories that never hold repositories of interest (`node_modules`, `target`, `.venv`, build
    output, …) are not descended into, but each is still `stat`'d once — a repository that happens
    to be named `build` is still listed.
  - A browser-supplied repository path is fenced to *the workspace, something inside it, or
    something enclosing it*, and then re-checked with `rev-parse` that it really is a repository
    root. Anything else is refused and the page falls back to the automatic choice, saying so.
  - New setting **Repository scan depth** (0–8, default 5; `0` disables the scan).
- `scripts/test.mjs` — `npm test` runs `node --check` over every `lib/` file and then every
  `test/*.test.cjs`, discovered automatically so a new test file cannot be forgotten in CI.
- Tests: repository discovery (`test/repos.test.cjs`), the theme-token guard
  (`test/style-tokens.test.cjs`) and the picker's element tree (`test/repo-picker.test.cjs`).

### Fixed

- **The current-branch chip was invisible in both themes.** It used
  `var(--dsw-alias-label-inverse, inherit)` — a token that does not exist — so its text inherited
  the theme's body colour while its background was `--dsw-alias-brand-primary`. In each theme
  those two resolve to the *same* value (`#f9fafb` in dark, `#0f1115` in light): 1.00:1 contrast,
  i.e. white on white in dark mode. It now uses `--dsw-alias-label-primary-foreground`, the token
  DSH pairs with `button-primary-fill` (= `brand-primary`): 18.9:1 and 18.1:1.
- Two more token typos that were silently falling back: `--dsw-alias-state-warning-primary` →
  `--dsw-alias-state-warn-primary`, `--dsw-alias-state-danger-primary` →
  `--dsw-alias-state-error-primary` (three lane colours were affected), and
  `--dsw-font-mono` → `--dsw-font-markdown-code-font-family`.
- The repository-count cap could overshoot badly: it was only checked at the top of the scan loop,
  so one concurrent batch of 32 directories could blow past it (130 repositories discovered in one
  pass instead of stopping at 100). The cap is now enforced on every push.

## [0.1.0] - 2026-09-28

First public release. Extracted from a private multi-machine DSH configuration repository,
where it had been running against DSH `0.1.7-rc.2` and `dsh-better-sidebar` 0.21.1.

### Added

- Right-sidebar page **Git graph**: a read-only commit graph over the session's workspace.
  - Lane layout in a single pass over `--topo-order` history; bezier connectors for branch
    forks and merges; merge commits drawn with a larger dot; the HEAD lane emphasized.
  - Ref chips per commit (local branch / remote branch / tag), with the current branch inverted.
  - Header with repository name, current branch, `↑ahead ↓behind` and dirty-file count.
  - Commit search that highlights matches and steps through them without re-laying-out the graph.
  - Click a row for full sha, author, email, absolute time, parents and participating refs.
  - Virtualized rows (the visible window is what gets rendered); nothing is requested while the
    page is not the visible tab.
- Host half with a read-only `POST /dsh-sidebar-git-graph/api` route:
  - `rev-parse`, `status --porcelain=v1 -b`, `for-each-ref`, and a `--topo-order --parents` log.
  - Sanitized child environment, 10 s per-command timeout, 48 MiB output cap, argument arrays only.
  - Same-origin trust fence plus a workspace allow-list (a client-supplied `cwd` is only honored
    when the host can back it).
  - Explicit error codes (`no-git`, `not-a-repo`, `no-workspace`, `git-failed`, `forbidden`)
    instead of thrown errors, so the page can always say something useful.
- Two registration routes, chosen automatically:
  - `ctx.betterSidebar.registerTab` when dsh-better-sidebar is present (page in the `+` menu and
    a card with an on/off switch in *Settings → Side cards*, plus a per-plugin commit-window
    setting). Activated through `ctx.inject`, never a static `inject`.
  - DSH's own `ctx.sidebarRightTabs` + `sidebar.right.pane.tab` slot when it is not.
- Three zero-dependency test files: parsers, lane layout (driven through a `vm`-loaded bundle),
  and an end-to-end route test against a throwaway repository under the system temp directory.

[Unreleased]: https://github.com/AFunDog/dsh-sidebar-git-graph/compare/v0.3.0...HEAD
[0.3.0]: https://github.com/AFunDog/dsh-sidebar-git-graph/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/AFunDog/dsh-sidebar-git-graph/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/AFunDog/dsh-sidebar-git-graph/releases/tag/v0.1.0
