#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
index_distilled_lunao.py — 把《素问入式运气论奥》（宋·刘温舒）蒸馏稿索引进项目 RAG。

作用：
  1. 将 rag-knowledge-base/distilled/suwen-rushi-yunqi-lunao/ 下的蒸馏 skill
     抽取为结构化检索资产 asset38_suwen_rushi_yunqi_lunao.json（统一入口）。
  2. 在 rag-knowledge-base/index.json 注册该资产 entry（category=distilled_study）。
  3. 打印下一步：需手动在 scripts/rag_search.py 的 ASSET_FILES 字典 + _default_asset_keys()
     白名单加 asset38 映射（脚本不改动源码）。

设计说明：
  - 与 asset34（王旭高《运气证治歌诀》·歌诀层）、asset35（医宗金鉴《运气要诀》·推算框架广度层）、
    asset36（三因《运气诸方》·方源层）、asset37（类经图翼·象数基础层）并列：
    本书 = 「专论·机制纵深层」——运气学史上第一本独立运气专著（承《素问》七篇、王冰注、《玄珠密语》之绪），
    独有纵深在：卷上「纳音／六化／五行本义／日刻／标本」之象数纵深，
    与卷下「胜复·五郁·六病·六脉·治法·五行胜复论（亢害承制机制化）」之病机→治法桥梁。
    五书互补，非替代。
  - 每条 entry 均带 disclaimer（禁止据以开方/诊断），与蒸馏 skill 三件套一致。
  - entry 的 summary 显式收录关键古文与术语，保证关键词检索（如「亢害承制」「五郁」「胜复」
    「必先岁气无伐天和」「纳音」「六化」）可命中融合。

用法（从仓库根执行）：
  python scripts/index_distilled_lunao.py
"""
import json
import os
import sys

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAG_DIR = os.path.join(REPO_ROOT, "rag-knowledge-base")
DISTILL_SLUG = "suwen_rushi_yunqi_lunao"
ASSET_ID = "asset38_suwen_rushi_yunqi_lunao"
ASSET_FILE = f"{ASSET_ID}.json"

DISCLAIMER = "⚠️ 仅供中医运气学文献研读与学术框架整理，禁止据此自行诊断、开方或用药；临床须咨询执业中医师。"

# ---------------------------------------------------------------------------
# 内嵌抽取事实（源自蒸馏稿 chapters，已逐字校核宋本底本 _source_yunqi_lunao.md）
# ---------------------------------------------------------------------------
# 总论 / 源流定位
ZONGLUN = {
    "本书定位": "《素问入式运气论奥》（宋·刘温舒，1099）运气学史上第一本独立运气专著（承《素问》运气七篇、王冰次注、《玄珠密语》之绪而专论之），定位为「专论·机制纵深层」：独有纵深在卷上象数（纳音/六化/五行本义/日刻/标本）与卷下机制（胜复·五郁·六病·六脉·治法·五行胜复论·亢害承制机制化）。",
    "五书互补": "三因《运气诸方》(方源层/asset36) / 王旭高《运气证治歌诀》(歌诀层/asset34) / 医宗金鉴《运气要诀》(推算框架广度层/asset35) / 类经图翼·运气(象数基础层/asset37) / 刘温舒《素问入式运气论奥》(专论·机制纵深层/asset38)；五者互补非替代。",
    "活法锚点": "刘温舒卷下结语「安得圆机之士，而与之共论五行哉！」反对胶柱，主张圆机活法；并明言「又或当岁有病，而非岁气者，亦须原其所感形证脉候……免拘于气运，粗见补写之误与不误也」——与 asset37「不可胶柱」同声相应，是本链「活法」红线。",
    "源流": "宋·刘温舒撰，三卷三十论（另附《五行胜复论》），入《正统道藏》太玄部，今见《钦定四库全书》本；使运气从散见经文提升为可操作知识模型，宋以后运气学普及与临床化实赖此书。",
    "序要旨": "「且以其问气运，最为补泻之要……括上古运气之秘文，撮斯书阴阳之精论……使览者经目，顿知妙道，几过半矣。讵敢沽誉，且畏医药之差误遗人，夭殃绝人长命尔。」",
}

# 卷上·象数·哲学地基（UNIQUE 纵深）
XIANGSHU = {
    "五行生死顺逆第一": "木主于东应春（触也冒也阳气触动冒地而生）；火主于南应夏（化也毁也）；金主于西应秋（禁也阴气禁止万物而敛）；水主于北应冬（润也阴气濡润任养万物）；土主中央兼位西南应长夏（吐也含吐万物为万物家）。其相克者子皆能为母复仇：木克土土之子金反克木，木之子火反克金，金之子水反克火，火之子土反克水，水之子木反克土。顺则相生逆则相克。",
    "论十干第二": "东方甲乙木、南方丙丁火、西方庚辛金、北方壬癸水、中央戊己土；甲丙戊庚壬为阳，乙丁己辛癸为阴，五行各一阴一阳故有十日。",
    "论十二支第三": "子北至阴寒水一阳肇生；丑寅卯辰巳午未申酉戌亥依次；子寅午申为阳，卯巳酉亥为阴，土居四维王在四季之末（辰戌阳，丑未阴）。",
    "论纳音第四(独家纵深)": "同类娶妻隔八生子乃纳音法：甲阳干子阳辰上下皆阳则亢，娶乙丑为妻（干辰皆阴）；隔八生子除上下两位而言（非第八）。纳音之所以金先者五行中唯金声铸器音声彰。阳生于子所以下生，阴生于午所以上生（天气下降地气上升）。",
    "论六化第五(六气之化)": "六气化者寒暑燥湿风火：木之化风主春；君火之化热主春末夏初行暄淑之令不行炎暑应君之德；相火之化暑主夏；金之化清与燥主秋；水之化寒主冬；土之化湿与雨主长夏。",
    "论四时气候第六": "五日谓之候，三候谓之气，六气谓之时，四时谓之岁；三气成一节（立春春分立夏夏至立秋秋分立冬冬至八节），三八二十四气分主四时。春秋言分（昼夜分五十刻阴阳中分，分则气异），冬夏言至（夏至日长不过六十刻阳极，冬至日短不过四十刻阴极，至则气同）。",
    "论交六气时日第七": "十二月中气大寒日交木之初气→二月中气春分交君火二气→四月中气小满交相火三气→六月中气大暑交土四气→八月中气秋分交金五气→十月中气小雪交水六气；每气各主六十日八十七刻半，总三百六十五日二十五刻共周一岁。",
    "论六气标本第九": "少阳之上火气治之中见厥阴；阳明之上燥气治之中见太阴；太阳之上寒气治之中见少阴；厥阴之上风气治之中见少阳；少阴之上热气治之中见太阳；太阴之上湿气治之中见阳明。所谓本也，本之下中之见也，见之下气之标也，标本不同气应异象。气有从本者（少阳太阴从本）、有从标本者（少阴太阳从本从标）、有不从标本者（阳明厥阴从乎中）。",
    "论五行生成数第十(与asset37同源互证)": "河图数天一生水地六成之……天五生土地十成之；太过者其数成不及者其数生土常以生。既并入 asset37 类经图翼，本书此论视为同源互证。",
}

# 卷中·五运（与 asset35/37 互补，本书为专论基底）
WUYUN = {
    "论五天之气第十一(五天五运下临化运)": "丹天火气经牛女壁奎下临戊癸→火运；黅天土气经心尾角轸下临甲己→土运；素天金气经亢氐昴毕下临乙庚→金运；玄天水气经张翼娄胃下临丙辛→水运；苍天木气经危室柳鬼下临丁壬→木运。戌为天门巳为地户。",
    "论五音建运第十二": "土曰宫金曰商木曰角火曰征水曰羽；阳年曰太阴年曰少。角触也（丁壬）、征止也（戊癸）、商强也（乙庚）、羽舒也（丙辛）、宫中也（甲己）。五运从十干起甲为土，土生金乙次之金生水丙次之五行相生而转。",
    "论月建第十三": "甲己岁正月建丙寅、乙庚岁建戊寅、丙辛岁建庚寅、丁壬岁建壬寅、戊癸岁建甲寅；阴年不及岁大寒日交初气其日时建干与年干合者曰干德符当为平气。",
    "论纪运第二十二(五运三纪命名·独家)": "木：大角发生(太过)/少角委和(不及)/正角敷和(平气)；火：大征赫曦/少征伏明/正征升明；土：大宫敦阜/少宫卑监/正宫备化；金：太商坚成/少商从革/正商审平；水：大羽流衍/少羽涸流/正羽静顺(顺静)。平气之岁不可预纪当依法推。",
    "论岁中五运第二十三(与asset37同)": "每运各主七十三日零五刻，总五运之数三百六十五日二十五刻共成一岁；当年大运通主一岁，主运自初正而生以大过不及随之。",
}

# 卷中·六气（与 asset35/37 互补）
LIUQI = {
    "论天地六气第十四(正化对化之绪)": "少阴司子午、太阴司丑未、少阳司寅申、阳明司卯酉、太阳司辰戌、厥阴司己亥；厥阴风木主春、少阴君火主春末夏初、少阳相火主夏、太阴湿土主长夏、阳明燥金主秋、太阳寒水主冬。",
    "论主气第十五": "厥阴木为初气→君火二气→相火三气→土四气→金五气→水六气；六位旋相主气以成一岁，天之六气每岁转居其上以行天令。",
    "论客气第十六(正化对化所以然·独家推理)": "厥阴木生亥故正化亥对化巳；少阴君火尊位正得离位故正午对子；太阴土寄坤位西南故正未对丑；少阳相火卑于君火火生寅故正寅对申；阳明金酉西方属金故正酉对卯；太阳水伏土中六戊天门戌六己地户辰故正戌对辰。司天三之气主上半年，在泉六气主下半年；岁半已前天气主之岁半已后地气主之。",
    "论天符第十七/岁会第十八/同天符同岁会第十九": "天符（中运同司天）十二年；太乙天符（运气岁支三者俱会）四年（戊午乙酉己丑己未）；岁会（中运同岁支）八年（四正子午卯酉+辰戌丑未）；同天符六年（阳年）、同岁会六年（阴年）。六十年分言二十六年合言二十七年。天符为执法（病速危）、岁会为行令（病徐持）、太乙天符为贵人（病暴死）。",
    "论南北政第二十(与asset37推理不同·本书独说)": "甲己土运为南政（土以成数贯金木水火位居中央君尊南面行令），余四运面北受令。南政寸南尺北少阴司天两寸不应在泉两尺不应；北政寸北尺南少阴司天两尺不应在泉两寸不应。尺寸反者死阴阳交者死。",
}

# 亢害承制 / 胜复 / 五郁（机制纵深核心）
CHENGZHI_YUFA = {
    "亢害承制(源自素问·六微旨·本书机制化)": "亢则害，承乃制，制则生化，外列盛衰，害则败乱，生化大病。亢者过极而不退，承犹随也以下奉上有防之之义，制克胜之也；有所制则六气不至于亢而为平。",
    "论胜复第二十五(胜复机制·核心)": "大过先天时化不胜者受邪，不及后天时化胜己者来克被克之后待时而复（子为母复仇）。木运少角岁金清化来胜则子火为复反热化胜金；火运少征岁水寒化来胜则子土为复反湿化胜水；土运少宫岁木风化来胜则子金为复反清化胜木；金运少商岁火热化来胜则子水为复反寒化胜火；水运少羽岁土湿化来胜则子木为复反风化胜土。初气终三气天气主之胜之常，四气尽终气地气主之复之常。",
    "五郁治法(承素问·六元正纪·本书专论)": "木郁达之，火郁发之，土郁夺之，金郁泄之，水郁折之。",
    "五行胜复论(本书独家附录·亢害承制闭环)": "木胜则金复以救土而名木不荣；火胜则水复以救金而冰雹乃零；土胜则木复以救水而倮虫不育；金胜则火复以救木而流水不冰；水胜则土复以救火而黅谷不登。故曰五运之气犹权衡也，高者抑之下者举之化者应之胜者复之，气之平也。",
    "论九宫分野第二十六(灾宫·独家)": "少角灾三宫（震天冲）、少征灾九宫（离天英）、少宫灾五宫（中天宫寄二宫坤）、少商灾七宫（兑天柱）、少羽灾一宫（坎天蓬）；皆以运气不及之方言之。",
    "论六十年客气第二十七(亢极则反/中见)": "六气极则过亢灾害生，气极则反所乘之气居下以乘之（相火之下水气承之）；又有中见之气从之（少阳之上火气治之中见厥阴）；阳极则阴生阴极则阳生斯五行相济之妙用。",
}

# 六病 / 六脉 / 治法（病机→治法桥梁）
BINGJI_ZHILIAO = {
    "论六病第二十八(六气为病·独家临床)": "厥阴所至为裹急筋缓缩急支痛软戾胁痛呕泄；少阴所至为疡胗身热恶寒战栗惊惑悲笑谵妄衄饥血汗；太阴所至为积饮痞鬲中满霍乱吐下身重胕肿；少阳所至为嚏呕疮疡喉痹耳鸣呕涌溢食不下惊躁瞀昧目不明暴注瞤瘛恶病暴死；阳明所至为咳嚏浮虚鼽揭尻阴股膝髀喘腑足病；太阳所至为屈伸不利腰痛寝汗痉流泄禁止。圣人论资取化源补不足泻有余食岁谷以安其气食间谷以去其邪。冬伤于寒春必病温，春伤于风夏必飧泄，夏伤于暑秋必痎疟，秋伤于湿冬必咳嗽。",
    "论六脉第二十九(六气之脉·独家)": "厥阴之至其脉弦，少阴之至其脉钩，太阴之至其脉沉，少阳之至其脉大而浮，阳明之至其脉短而涩，太阳之至其脉大而长。至而和则平，至而甚则病，至而反则病，至而不至者病，未至而至者病，阴阳易者危。必先岁气无伐天和；粗工不识呼为寒热攻寒令热脉不变而热疾已生制热令寒脉如故而寒疾又起。",
    "论治法第三十(纂至真要·治法纲领)": "高者抑之下者举之化者应之胜者复之；寒者热之热者寒之微者逆之甚者从之坚者削之客者除之劳者温之结者散之留者攻之燥者濡之急者缓之散者收之损者益之逸者行之惊者平之；必先岁气无伐天和，资取化源补不足泻有余。",
}

# 诸图图解（图论，与 asset37 图翼对照）
TU = {
    "五运六气枢要之图": "卷首总纲图，统摄五运六气枢要。",
    "六十年纪运图": "一岁一岁纪运之图，太角少角等三十年阳、三十年阴之纪。",
    "十干起运诀": "甲己化土乙庚金丙辛化水丁壬木戊癸火之起运口诀图。",
    "十二支司天诀": "子午少阴至巳亥厥阴十二支司天定位口诀图。",
    "太少气运相临之图(卷下)": "太过不及气运相临同化之图（木齐金化、木兼金同化等）。",
    "手足经图(卷下)": "五脏六腑手足三阴三阳经络配属图（少阴主心肾、太阴主脾肺、厥阴主肝心包）。",
    "六十年客气旁通图(卷下)": "六十年客气旁通列于主位之下，示客气所在大法（温冻寒暑蒙暝明晦风雨霜雪电雹雷霆不同之化）。",
}


def build_entries():
    return [
        {
            "entry_id": "lunao_zonglun",
            "rag_key": "lunao_zonglun",
            "category": "lunao_zonglun",
            "name": "总论与源流定位（专论·机制纵深层）",
            "summary": "；".join(f"{k}：{v}" for k, v in ZONGLUN.items()),
            "mapping": [{"item": k, "value": v} for k, v in ZONGLUN.items()],
            "source_quote": "distilled/suwen-rushi-yunqi-lunao/chapters/ch01-zonglun.md ; chapters/ch08-shiyong-zhinan.md ; _source_yunqi_lunao.md 一·定位",
            "disclaimer": DISCLAIMER,
        },
        {
            "entry_id": "lunao_xiangshu",
            "rag_key": "lunao_xiangshu",
            "category": "lunao_xiangshu",
            "name": "象数基础层（卷上：五行本义/十干/十二支/纳音/六化/四时气候/日刻/标本/生成数）",
            "summary": "卷上·象数·哲学地基（逐字照宋本，本书独有纵深：纳音/六化/五行本义/日刻/标本）：" + "；".join(f"{k}：{v}" for k, v in XIANGSHU.items()),
            "mapping": [{"item": k, "value": v} for k, v in XIANGSHU.items()],
            "source_quote": "distilled/suwen-rushi-yunqi-lunao/chapters/ch02-xiangshu-jichu.md ; _source_yunqi_lunao.md 二·卷上",
            "disclaimer": DISCLAIMER,
        },
        {
            "entry_id": "lunao_wuyun",
            "rag_key": "lunao_wuyun",
            "category": "lunao_wuyun",
            "name": "五运（卷中：五天五运/五音建运/月建/纪运三纪/岁中五运）",
            "summary": "卷中·五运（逐字照宋本，本书为专论基底）：" + "；".join(f"{k}：{v}" for k, v in WUYUN.items()),
            "mapping": [{"item": k, "value": v} for k, v in WUYUN.items()],
            "source_quote": "distilled/suwen-rushi-yunqi-lunao/chapters/ch03-wuyun.md ; _source_yunqi_lunao.md 三·卷中·五运",
            "disclaimer": DISCLAIMER,
        },
        {
            "entry_id": "lunao_liuqi",
            "rag_key": "lunao_liuqi",
            "category": "lunao_liuqi",
            "name": "六气（卷中：天地六气/主气/客气/天符/岁会/同天符同岁会/南北政）",
            "summary": "卷中·六气（逐字照宋本，正化对化所以然为本书独家推理）：" + "；".join(f"{k}：{v}" for k, v in LIUQI.items()),
            "mapping": [{"item": k, "value": v} for k, v in LIUQI.items()],
            "source_quote": "distilled/suwen-rushi-yunqi-lunao/chapters/ch04-liuqi.md ; _source_yunqi_lunao.md 三·卷中·六气",
            "disclaimer": DISCLAIMER,
        },
        {
            "entry_id": "lunao_chengzhi_yufa",
            "rag_key": "lunao_chengzhi_yufa",
            "category": "lunao_chengzhi_yufa",
            "name": "亢害承制·胜复·五郁（机制纵深核心）",
            "summary": "亢害承制/胜复/五郁/五行胜复论/九宫分野/六十年客气（逐字照宋本，本书独有纵深——气化失衡→自稳→病机机制化）：" + "；".join(f"{k}：{v}" for k, v in CHENGZHI_YUFA.items()),
            "mapping": [{"item": k, "value": v} for k, v in CHENGZHI_YUFA.items()],
            "source_quote": "distilled/suwen-rushi-yunqi-lunao/chapters/ch05-chengzhi-shengfu.md ; _source_yunqi_lunao.md 四·卷下·机制",
            "disclaimer": DISCLAIMER,
        },
        {
            "entry_id": "lunao_bingji_zhiliao",
            "rag_key": "lunao_bingji_zhiliao",
            "category": "lunao_bingji_zhiliao",
            "name": "六病·六脉·治法（病机→治法桥梁）",
            "summary": "论六病（六气为病）/论六脉（六气之脉）/论治法（资取化源·无伐天和）（逐字照宋本，本书独有纵深——把运气格局接到临床辨证）：" + "；".join(f"{k}：{v}" for k, v in BINGJI_ZHILIAO.items()),
            "mapping": [{"item": k, "value": v} for k, v in BINGJI_ZHILIAO.items()],
            "source_quote": "distilled/suwen-rushi-yunqi-lunao/chapters/ch06-bingji-zhiliao.md ; _source_yunqi_lunao.md 四·卷下·病机治法",
            "disclaimer": DISCLAIMER,
        },
        {
            "entry_id": "lunao_tu",
            "rag_key": "lunao_tu",
            "category": "lunao_tu",
            "name": "诸图图解（枢要图/纪运图/起运诀/司天诀/太少相临图/手足经图/客气旁通图）",
            "summary": "本书图解体系（图论，与 asset37 类经图翼对照）：" + "；".join(f"{k}：{v}" for k, v in TU.items()),
            "mapping": [{"item": k, "value": v} for k, v in TU.items()],
            "source_quote": "distilled/suwen-rushi-yunqi-lunao/chapters/ch02-xiangshu-jichu.md (§11 诸图图解) ; _source_yunqi_lunao.md 四·诸图",
            "disclaimer": DISCLAIMER,
        },
    ]


def write_asset():
    asset = {
        "asset_id": ASSET_ID,
        "asset_name": "素问入式运气论奥（宋·刘温舒）蒸馏研读框架",
        "asset_description": (
            "从宋·刘温舒《素问入式运气论奥》（成书1099，入《正统道藏》太玄部，公有领域）"
            "经 book-to-skill 风格蒸馏出的运气「专论·机制纵深层」框架："
            "运气学史上第一本独立运气专著（承《素问》七篇、王冰注、《玄珠密语》之绪），"
            "独有纵深在卷上象数（纳音／六化／五行本义／日刻／标本）与卷下机制"
            "（胜复·五郁·六病·六脉·治法·五行胜复论＝亢害承制机制化），"
            "把运气格局接到临床病机→治法。与三因《运气诸方》(asset36·方源)、"
            "王旭高《运气证治歌诀》(asset34·歌诀)、医宗金鉴《运气要诀》(asset35·推算框架广度)、"
            "类经图翼·运气(asset37·象数基础) 五书互补，非替代。"
        ),
        "data_source": "宋·刘温舒《素问入式运气论奥》三卷（公有领域，正统道藏/四库全书本）",
        "entries": build_entries(),
        "disclaimer": DISCLAIMER,
    }
    out = os.path.join(RAG_DIR, ASSET_FILE)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(asset, f, ensure_ascii=False, indent=2)
    return out


def register_index():
    idx_path = os.path.join(RAG_DIR, "index.json")
    with open(idx_path, encoding="utf-8") as f:
        index = json.load(f)
    index["entries"] = [e for e in index["entries"] if e.get("asset_id") != ASSET_ID]
    index["entries"].append({
        "entry_id": f"rag_index_{ASSET_ID}",
        "entry_type": "asset_index",
        "title": "素问入式运气论奥（宋·刘温舒）蒸馏框架",
        "file": ASSET_FILE,
        "asset_id": ASSET_ID,
        "asset_name": "素问入式运气论奥（宋·刘温舒）蒸馏研读框架",
        "asset_category": "distilled_study",
        "description": "从《素问入式运气论奥》蒸馏出的运气「专论·机制纵深层」框架：第一本独立运气专著，独有纵深在卷上象数（纳音/六化/五行本义/日刻/标本）与卷下机制（胜复·五郁·六病·六脉·治法·五行胜复论·亢害承制机制化）。与三因(asset36·方源)/王旭高(asset34·歌诀)/医宗金鉴(asset35·推算框架广度)/类经图翼(asset37·象数基础)五书互补。",
        "total_entries": len(build_entries()),
        "lookup_fields": ["rag_key"],
        "example_keys": ["lunao_zonglun", "lunao_xiangshu", "lunao_wuyun", "lunao_liuqi", "lunao_chengzhi_yufa", "lunao_bingji_zhiliao", "lunao_tu"],
        "rag_key": ASSET_ID,
    })
    index["total_entries"] = index.get("total_entries", 0) + 1
    with open(idx_path, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2)
    return idx_path


def main():
    try:
        asset_out = write_asset()
        idx_out = register_index()
    except Exception as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        return 1
    print(f"[OK] 生成资产: {asset_out}")
    print(f"[OK] 注册索引: {idx_out} (total_assets={json.load(open(idx_out, encoding='utf-8')).get('total_entries')})")
    print("[NEXT] 还需手动在 scripts/rag_search.py 做两处改动：")
    print("  1) ASSET_FILES 字典加（接在 asset37 之后）：")
    print(f'     "asset38": "{ASSET_FILE}",')
    print(f'     "asset38_suwen_rushi_yunqi_lunao": "{ASSET_FILE}",')
    print(f'     "suwen_rushi_yunqi_lunao": "{ASSET_FILE}",')
    print(f'     "yunqi_lunao": "{ASSET_FILE}",')
    print(f'     "lunao": "{ASSET_FILE}",')
    print(f'     "lunao_lunao": "{ASSET_FILE}",')
    print("  2) _default_asset_keys() 白名单元组加：")
    print('     "asset38",')
    print("然后即可：python scripts/rag_search.py --key lunao_zonglun")
    return 0


if __name__ == "__main__":
    sys.exit(main())
