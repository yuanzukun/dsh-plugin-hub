/**
 * Contract test against one built DeepSeek Harness source checkout.
 *
 * Set `DSH_SOURCE_ROOT` to the checkout and optionally
 * `DSH_EXPECTED_VERSION` to pin release evidence to one exact version.
 *
 * @module
 */

import assert from 'node:assert/strict'
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { describe, it } from 'node:test'
import { assertMcpClientPlugin } from '../src/harness-module.js'

const sourceRoot = process.env.DSH_SOURCE_ROOT
assert.ok(sourceRoot, 'DSH_SOURCE_ROOT must point to a built DeepSeek Harness checkout')

const rootManifest = JSON.parse(readFileSync(join(sourceRoot, 'package.json'), 'utf8'))
const mcpRoot = join(sourceRoot, 'packages', 'mcp', 'mcp-client')
const mcpManifest = JSON.parse(readFileSync(join(mcpRoot, 'package.json'), 'utf8'))
const mcpEntry = join(mcpRoot, 'lib', 'index.js')

describe(`DSH ${String(rootManifest.version)} host contract`, () => {
  it('is the requested harness build', () => {
    assert.equal(rootManifest.name, '@deepseek-ai/dsh-root')
    if (process.env.DSH_EXPECTED_VERSION !== undefined) {
      assert.equal(rootManifest.version, process.env.DSH_EXPECTED_VERSION)
    }
    assert.equal(mcpManifest.version, rootManifest.version)
  })

  it('publishes a built mcp-client namespace this bundle can mount', async () => {
    assert.equal(existsSync(mcpEntry), true, `missing built host entry: ${mcpEntry}`)
    const namespace = await import(pathToFileURL(mcpEntry).href)
    assert.equal(assertMcpClientPlugin(namespace), namespace)
    assert.equal(typeof namespace.Config, 'function')
  })

  it('lets the official client own rc.2 image admission and projection', () => {
    if (rootManifest.version !== '0.1.1-rc.2') return
    assert.ok(Object.hasOwn(mcpManifest.peerDependencies, '@deepseek-ai/dsh-attachment'))
    assert.ok(Object.hasOwn(mcpManifest.peerDependencies, '@deepseek-ai/dsh-llm'))
  })
})
