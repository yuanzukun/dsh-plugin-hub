/**
 * Resolving harness packages from an out-of-tree plugin.
 *
 * `dsh plugin --profile <name> add <path>` installs a local directory with
 * pnpm's `link:` protocol, which symlinks it. Node resolves a symlinked
 * package's own imports from its REAL directory, so the plugin's development
 * checkout — not the profile — becomes the resolution anchor, and the harness
 * peer it imports is nowhere on that path. A packed or published install has
 * no such problem because the package really lives inside the profile.
 *
 * Both install forms must work, so resolution falls back to the two anchors
 * the harness itself maintains: `$DSH_HOME/profiles/node_modules` (the flat
 * fallback `healProfilesModuleFallback` keeps pointing at the running
 * installation, one symlink per package in the dsh app's dependency closure)
 * and the running `dsh` entry script.
 *
 * @module
 */

import { createRequire } from 'node:module'
import { homedir } from 'node:os'
import { join, posix, win32 } from 'node:path'
import { pathToFileURL } from 'node:url'

/**
 * The harness home, restated rather than imported so this package keeps no
 * runtime dependency — resolving one is precisely what this module is for.
 * The rule is `resolveDshHome` in `@deepseek-ai/dsh-home-paths`, which owns it.
 *
 * @param {Record<string, string | undefined>} env - Environment to read `DSH_HOME` from.
 * @returns {string} the absolute harness home.
 */
export function harnessHome(env, platform = process.platform) {
  const configured = env.DSH_HOME
  const paths = platform === 'win32' ? win32 : posix
  const selected = configured !== undefined && configured.trim() !== '' ? configured : paths.join(homedir(), '.dsh')
  return paths.resolve(selected)
}

/**
 * Resolution anchors tried after a plain bare import fails, in order of how
 * authoritative they are about which installation is running.
 *
 * @param {Record<string, string | undefined>} env - Environment, for the harness home.
 * @param {readonly string[]} argv - Process argv, whose entry script names the running dsh.
 * @returns {readonly string[]} anchor file paths for `createRequire`.
 */
export function fallbackAnchors(env, argv) {
  /** @type {string[]} */
  const anchors = []
  // Node's parent walk from `<home>/profiles/anchor.js` includes
  // `<home>/profiles/node_modules`, which is the directory the launcher heals
  // on every boot to point at this installation's packages.
  anchors.push(join(harnessHome(env), 'profiles', 'plugin-resolution-anchor.js'))
  const entry = argv[1]
  if (entry !== undefined && entry !== '') anchors.push(entry)
  return anchors
}

/**
 * Validate the namespace-plugin surface consumed by this bundle.
 *
 * The package is loaded dynamically from the running harness rather than
 * linked at development time, so TypeScript cannot prove this boundary. A
 * future DSH package layout change must fail here with the missing contract,
 * before Cordis receives an opaque module namespace and reports a less useful
 * loader failure.
 *
 * @param {Record<string, unknown>} plugin - Imported `@deepseek-ai/dsh-mcp-client` namespace.
 * @returns {Record<string, unknown>} the compatible namespace unchanged.
 * @throws {Error} when the running harness does not expose the namespace plugin this bundle mounts.
 */
export function assertMcpClientPlugin(plugin) {
  const missing = []
  if (plugin.name !== 'mcp-client') missing.push('name="mcp-client"')
  if (typeof plugin.apply !== 'function') missing.push('a named apply() function')
  if (!Array.isArray(plugin.inject) || !plugin.inject.includes('tools')) missing.push('inject containing "tools"')
  if (missing.length > 0) {
    throw new Error(
      'dsh-wolfram: incompatible @deepseek-ai/dsh-mcp-client from the running DSH installation; '
      + `expected ${missing.join(', ')}. This bundle is tested with DSH 0.1.0-rc.5 and 0.1.1-rc.2.`,
    )
  }
  return plugin
}

/**
 * Import one harness package by name.
 *
 * @param {string} specifier - The harness package to import.
 * @param {object} [options] - Resolution inputs, injectable for tests.
 * @param {Record<string, string | undefined>} [options.env] - Environment, for the harness home.
 * @param {readonly string[]} [options.argv] - Process argv, for the running-dsh anchor.
 * @param {(url: string) => Promise<unknown>} [options.load] - Module loader.
 * @returns {Promise<Record<string, unknown>>} the package's module namespace.
 * @throws {Error} when no anchor resolves it, naming the anchors tried.
 */
export async function importHarnessPackage(specifier, options = {}) {
  const env = options.env ?? process.env
  const argv = options.argv ?? process.argv
  const load = options.load ?? (url => import(url))
  try {
    return /** @type {Record<string, unknown>} */ (await load(specifier))
  } catch (error) {
    // Only absence justifies a fallback: a package that was found and then
    // failed to evaluate must surface its own error, not a resolution story.
    if (/** @type {NodeJS.ErrnoException} */ (error).code !== 'ERR_MODULE_NOT_FOUND') throw error
  }
  const anchors = fallbackAnchors(env, argv)
  for (const anchor of anchors) {
    /** @type {string} */
    let resolved
    try {
      // `require.resolve` honors the package's `exports` map, so the fallback
      // enters through the same entry point a bare import would have used.
      resolved = createRequire(anchor).resolve(specifier)
    } catch {
      continue
    }
    return /** @type {Record<string, unknown>} */ (await load(pathToFileURL(resolved).href))
  }
  throw new Error(
    `dsh-wolfram: cannot resolve ${specifier} from this plugin, `
    + `${anchors.map(anchor => JSON.stringify(anchor)).join(', ')}, or the harness installation. `
    + 'Install this plugin into a dsh profile (dsh plugin --profile <name> add <spec>) so the harness packages '
    + 'resolve, and check that $DSH_HOME points at the harness home the running dsh uses.',
  )
}
