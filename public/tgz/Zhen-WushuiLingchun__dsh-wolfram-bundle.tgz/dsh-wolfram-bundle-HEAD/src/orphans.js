/**
 * Orphan records: the one case the supervisor cannot handle itself.
 *
 * A supervisor killed with `SIGKILL` (or, on Windows, `TerminateProcess`) runs
 * no JavaScript, so its Wolfram child survives. The supervisor therefore
 * records its child before piping any bytes and deletes the record once the
 * child's exit is observed; the integration plugin sweeps leftover records on
 * activation and on disposal.
 *
 * Reclamation is deliberately timid. A record is acted on only when its
 * supervisor is gone, its child is still alive, AND the live process still
 * proves it is that child: same image name, a command line naming both the
 * executable this plugin launched and the AgentTools server entry point, and a
 * creation time inside the recorded spawn window. Anything less deletes the
 * record and leaves the process running.
 *
 * @module
 */

import { mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { posix, win32, join } from 'node:path'
import { randomUUID } from 'node:crypto'
import { AGENT_TOOLS_START_EXPRESSION } from './discovery.js'
import { isProcessAlive, readProcessIdentity, terminateProcessTree } from './process-tree.js'

/** Directory name under the harness home holding live-supervisor records. */
export const RECORD_DIRECTORY_NAME = '.dsh-wolfram'

/**
 * How far after the recorded spawn instant a matching process may have been
 * created. Generous enough for a slow kernel launch, far short of the interval
 * in which a pid could be reused by an unrelated Wolfram process.
 */
const CREATION_WINDOW_AFTER_MS = 120_000

/** How far before the recorded spawn instant a match is still credible (clock skew only). */
const CREATION_WINDOW_BEFORE_MS = 10_000

/** Records older than this with no live supervisor are deleted even if unverifiable. */
const RECORD_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000

/** One supervised Wolfram child, as written to disk. */
/**
 * @typedef {object} SupervisorRecord
 * @property {number} version Record format version.
 * @property {number} supervisorPid Pid of the supervisor that owns the child.
 * @property {number} childPid Pid of the spawned Wolfram process.
 * @property {string} command Executable the supervisor spawned.
 * @property {number} spawnedAtMs Epoch milliseconds at spawn.
 */

/** Current record format; a record with another version is deleted, not guessed at. */
const RECORD_VERSION = 1

/**
 * Write one record and return its path. Failure is reported to the caller
 * rather than thrown: losing the orphan-reclaim safety net must not stop a
 * working MCP connection from starting.
 *
 * @param {string} directory - Record directory.
 * @param {Omit<SupervisorRecord, 'version'>} record - The child to record.
 * @returns {string | undefined} the record path, or `undefined` when it could not be written.
 */
export function writeRecord(directory, record) {
  try {
    mkdirSync(directory, { recursive: true, mode: 0o700 })
    const path = join(directory, `${randomUUID()}.json`)
    writeFileSync(path, JSON.stringify({ version: RECORD_VERSION, ...record }), { encoding: 'utf8', mode: 0o600 })
    return path
  } catch {
    // An unwritable state directory only costs the hard-kill safety net; the
    // supervisor's own shutdown path is unaffected.
    return undefined
  }
}

/**
 * Delete one record, tolerating a record that is already gone.
 * @param {string | undefined} path - Record path, or `undefined` for a no-op.
 * @returns {void}
 */
export function deleteRecord(path) {
  if (path === undefined) return
  try {
    rmSync(path, { force: true })
  } catch {
    // A leftover record is harmless: the next sweep re-evaluates it and finds
    // a dead child, then deletes it.
  }
}

/**
 * Whether a live process is credibly the child a record describes.
 *
 * @param {SupervisorRecord} record - The recorded child.
 * @param {import('./process-tree.js').ProcessIdentity} identity - Identity read back from the OS.
 * @returns {boolean} whether every identity check passes.
 */
export function identityMatchesRecord(record, identity) {
  if (identity.pid !== record.childPid) return false
  const expectedNames = new Set([
    posix.basename(record.command).toLowerCase(),
    win32.basename(record.command).toLowerCase(),
  ])
  const observedName = identity.name === '' ? '' : posix.basename(identity.name).toLowerCase()
  if (observedName !== '' && !expectedNames.has(observedName)) return false
  const commandLine = identity.commandLine
  if (!commandLine.includes(record.command)) return false
  if (!commandLine.includes(AGENT_TOOLS_START_EXPRESSION.slice(0, AGENT_TOOLS_START_EXPRESSION.indexOf('[')))) return false
  if (!commandLine.includes('StartMCPServer')) return false
  const createdAtMs = identity.createdAtMs
  // Creation time is what rules out pid reuse; a platform that cannot report
  // it (POSIX `ps`) keeps the weaker command-line-only evidence.
  if (createdAtMs === undefined) return true
  return createdAtMs >= record.spawnedAtMs - CREATION_WINDOW_BEFORE_MS
    && createdAtMs <= record.spawnedAtMs + CREATION_WINDOW_AFTER_MS
}

/** What one sweep did, for the activation and disposal log lines. */
/**
 * @typedef {object} ReclaimSummary
 * @property {number} inspected Records read.
 * @property {number} live Records whose supervisor is still running (left untouched).
 * @property {number} reclaimed Verified orphan trees terminated.
 * @property {number} stale Records deleted without touching any process.
 * @property {string[]} notes One line per non-trivial decision, for the log.
 */

/**
 * Sweep the record directory.
 *
 * @param {object} options - Sweep inputs.
 * @param {string} options.directory - Record directory.
 * @param {number} [options.nowMs] - Current time, injectable for tests.
 * @param {(pid: number) => boolean} [options.alive] - Liveness probe.
 * @param {(pid: number) => import('./process-tree.js').ProcessIdentity | undefined} [options.identify] - Identity reader.
 * @param {(pid: number) => import('./process-tree.js').TerminationOutcome} [options.terminate] - Tree terminator.
 * @returns {ReclaimSummary} what the sweep decided.
 */
export function reclaimOrphans(options) {
  const alive = options.alive ?? isProcessAlive
  const identify = options.identify ?? (pid => readProcessIdentity(pid))
  const terminate = options.terminate ?? (pid => terminateProcessTree(pid))
  const nowMs = options.nowMs ?? Date.now()
  /** @type {ReclaimSummary} */
  const summary = { inspected: 0, live: 0, reclaimed: 0, stale: 0, notes: [] }
  /** @type {string[]} */
  let entries
  try {
    entries = readdirSync(options.directory).filter(entry => entry.endsWith('.json'))
  } catch {
    // No directory means no supervisor has ever recorded a child here.
    return summary
  }
  for (const entry of entries) {
    const path = join(options.directory, entry)
    summary.inspected += 1
    /** @type {SupervisorRecord | undefined} */
    let record
    try {
      const parsed = /** @type {SupervisorRecord} */ (JSON.parse(readFileSync(path, 'utf8')))
      record = parsed.version === RECORD_VERSION && Number.isInteger(parsed.childPid) ? parsed : undefined
    } catch {
      // Unreadable or truncated: it names no process this sweep may act on.
      record = undefined
    }
    if (record === undefined) {
      summary.stale += 1
      deleteRecord(path)
      summary.notes.push(`${entry}: unreadable record, deleted (no process touched)`)
      continue
    }
    if (alive(record.supervisorPid)) {
      summary.live += 1
      continue
    }
    if (!alive(record.childPid)) {
      summary.stale += 1
      deleteRecord(path)
      continue
    }
    const identity = identify(record.childPid)
    if (identity === undefined || !identityMatchesRecord(record, identity)) {
      summary.stale += 1
      deleteRecord(path)
      summary.notes.push(
        `${entry}: pid ${String(record.childPid)} is alive but did not prove it is the recorded Wolfram child — `
        + 'record deleted, process left running',
      )
      continue
    }
    const outcome = terminate(record.childPid)
    summary.reclaimed += 1
    deleteRecord(path)
    summary.notes.push(
      `${entry}: reclaimed orphaned Wolfram process tree ${String(record.childPid)} `
      + `(supervisor ${String(record.supervisorPid)} is gone) — ${outcome.detail}`,
    )
  }
  // A record whose supervisor and child are both unresolvable ages out rather
  // than accumulating forever in the harness home.
  for (const entry of entries) {
    const path = join(options.directory, entry)
    try {
      const parsed = /** @type {SupervisorRecord} */ (JSON.parse(readFileSync(path, 'utf8')))
      if (nowMs - parsed.spawnedAtMs > RECORD_MAX_AGE_MS) deleteRecord(path)
    } catch {
      // Already handled above; a record that vanished between the two passes
      // needs nothing further.
    }
  }
  return summary
}
