/**
 * DeepSeek Harness integration for the official Wolfram/AgentTools MCP server.
 *
 * This plugin owns the three things that sit between the harness's generic MCP
 * client and Wolfram's own server, and nothing else: finding the Wolfram
 * kernel, running it behind a supervisor that terminates only its own process
 * tree, and reclaiming a tree a hard-killed supervisor could not clean up.
 *
 * The MCP protocol work is `@deepseek-ai/dsh-mcp-client`'s, mounted here as a
 * child plugin with the resolved configuration. Permission policy is a
 * separate plugin (`dsh-wolfram/policy`) so a deployment can replace or
 * disable it by row id without losing the connection.
 *
 * Namespace plugin (named exports, no default export). Disposal disconnects
 * the MCP server, unregisters its tools, and runs a final orphan sweep; HMR
 * therefore hot-swaps without leaving a Wolfram process behind.
 *
 * @module dsh-wolfram
 */

import process from 'node:process'
import { buildMcpClientConfig, resolveWolframSpec } from './config.js'
import { assertMcpClientPlugin, importHarnessPackage } from './harness-module.js'
import { reclaimOrphans } from './orphans.js'

export { buildMcpClientConfig, resolveWolframSpec } from './config.js'
export { AGENT_TOOLS_ARGS, resolveWolframCommand } from './discovery.js'
export { reclaimOrphans } from './orphans.js'

/** Cordis plugin name used by loader diagnostics. */
export const name = 'wolfram'

/**
 * Services required before this plugin activates. The tool registry is the
 * service the mounted MCP client registers into; waiting for it here means the
 * child never mounts into a tree that cannot hold its tools.
 */
export const inject = ['tools']

/**
 * Run one orphan sweep and report it. Failures are contained: reclamation is a
 * safety net, and losing it must not stop the connection from starting or the
 * plugin from unloading.
 *
 * @param {import('../types/harness.js').HarnessContext} ctx - Plugin context, for logging.
 * @param {import('./config.js').WolframSpec} spec - The resolved row.
 * @param {string} phase - Which lifecycle point is sweeping, for the log.
 * @returns {void}
 */
function sweep(ctx, spec, phase) {
  if (!spec.reclaimOrphans) return
  try {
    const summary = reclaimOrphans({ directory: spec.recordDirectory })
    for (const note of summary.notes) ctx.logger.warn(`wolfram: ${note}`)
    if (summary.reclaimed > 0) {
      ctx.logger.warn(`wolfram: ${phase} sweep reclaimed ${String(summary.reclaimed)} orphaned Wolfram process tree(s)`)
    }
  } catch (error) {
    ctx.logger.warn(`wolfram: ${phase} orphan sweep failed: ${String(error)}`)
  }
}

/**
 * Resolve the kernel, mount the MCP client behind the supervisor, and block
 * activation until the server's tools are registered.
 *
 * This entry stays explicitly `async`: Cordis treats a prototype-bearing
 * ordinary function as a constructor, whose returned promise would not be
 * startup work.
 *
 * @param {import('../types/harness.js').HarnessContext} ctx - Plugin context.
 * @param {Record<string, unknown>} [config] - The `wolfram` row's config.
 * @returns {Promise<void>} startup readiness after the MCP connection and tool discovery settle.
 */
export async function apply(ctx, config) {
  // Fail loud at load: an invalid field or an undiscoverable kernel rejects
  // THIS instance before any effect registers.
  const spec = resolveWolframSpec(config ?? {}, { platform: process.platform, env: process.env })
  ctx.logger.info(
    `wolfram: kernel ${spec.kernel.command} (via ${spec.kernel.source}), `
    + `server ${spec.mcpServerName}, tools under mcp__${spec.serverName}__*`,
  )

  // Before starting a new server, reclaim anything a previously hard-killed
  // supervisor left running — a restart is exactly when such a tree exists.
  sweep(ctx, spec, 'startup')

  // Imported here rather than statically: a `link:`-installed plugin resolves
  // its imports from its development checkout, so the harness peer needs the
  // launcher-maintained anchors this helper knows about.
  const mcpClient = assertMcpClientPlugin(await importHarnessPackage('@deepseek-ai/dsh-mcp-client'))
  const fiber = ctx.plugin(mcpClient, buildMcpClientConfig(spec, process.execPath))

  // Explicit teardown ordering: disposing the child first guarantees the MCP
  // client has closed the supervisor and released its tools before the final
  // sweep looks for records, so the sweep observes the settled state rather
  // than racing it.
  ctx.effect(() => () => fiber.dispose().then(() => { sweep(ctx, spec, 'shutdown') }), 'wolfram.connection')

  await fiber
}
