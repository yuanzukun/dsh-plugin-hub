/**
 * Permission policy for the Wolfram MCP tool surface.
 *
 * A native harness `tools/pre-execute` listener, not a second authorization
 * system: it classifies a pending Wolfram call and returns the harness's own
 * `ask` decision, which the tool registry resolves through `ctx.approval`.
 * There is no rule store and no remembered grant — one approval covers one
 * call, exactly as the harness approval seam defines it.
 *
 * The policy only ever makes a call MORE restricted. It delegates down the
 * chain first and upgrades an `allow` to `ask`, so another policy's `deny` or
 * `ask` survives unchanged and no listener registered after this one is
 * skipped.
 *
 * Namespace plugin (named exports, no default export). Disposal removes the
 * listener with the rest of the plugin's effects.
 *
 * @module dsh-wolfram/policy
 */

import { classifyToolCall, resolveClassification } from './classify.js'

export { classifyToolCall, resolveClassification, DEFAULT_ASK_TOOLS, DEFAULT_DELEGATE_TOOLS } from './classify.js'

/** Cordis plugin name used by loader diagnostics. */
export const name = 'wolfram-permission'

/** The registry whose pre-execute waterfall this policy joins. */
export const inject = ['tools']

/**
 * Register the policy listener.
 *
 * @param {import('../types/harness.js').HarnessContext} ctx - Plugin context.
 * @param {Record<string, unknown>} [config] - The `wolfram-permission` row's config.
 * @returns {void}
 * @throws {Error} when the classification table is contradictory or `serverName` is unusable.
 */
export function apply(ctx, config) {
  const table = resolveClassification({
    serverName: /** @type {string} */ ((config ?? {}).serverName ?? 'wolfram'),
    ask: /** @type {Record<string, string> | undefined} */ ((config ?? {}).ask),
    delegate: /** @type {string[] | undefined} */ ((config ?? {}).delegate),
    additionalAsk: /** @type {Record<string, string> | undefined} */ ((config ?? {}).additionalAsk),
    unknown: /** @type {'ask' | 'deny' | undefined} */ ((config ?? {}).unknown),
  })
  ctx.logger.info(
    `wolfram-permission: ${String(table.ask.size)} tool(s) require approval, `
    + `${String(table.delegate.size)} read-only tool(s) delegated, `
    + `unlisted ${table.prefix}* tools default to ${table.unknown}`,
  )

  ctx.on('tools/pre-execute', async (exec, next) => {
    const verdict = classifyToolCall(exec.name, table)
    if (verdict.decision === 'delegate') return next()
    const reason = /** @type {string} */ (verdict.reason)
    // A denial is terminal and cannot be weakened downstream, so it short-circuits.
    if (verdict.decision === 'deny') return { kind: 'deny', reason }
    const downstream = await next()
    // Upgrade only what the rest of the chain left permitted; a downstream
    // `deny` or `ask` already meets or exceeds this policy's requirement.
    return downstream.kind === 'allow' ? { kind: 'ask', reason } : downstream
  })
}
