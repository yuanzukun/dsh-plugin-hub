/**
 * Wolfram kernel discovery.
 *
 * Resolves the executable the official Wolfram/AgentTools MCP server is
 * started from. The executable's location inside an installation follows the
 * paclet's own `getWolframCommand` (`Kernel/MCPServerObject.wl`), so a kernel
 * found here is started exactly the way `InstallMCPServer` would start it.
 *
 * Nothing about one machine is baked in: every candidate is either supplied by
 * configuration, read from the platform's own installation registry, or found
 * under a documented platform install root.
 *
 * @module
 */

import { spawnSync } from 'node:child_process'
import { readdirSync, statSync } from 'node:fs'
import { posix, win32 } from 'node:path'

/**
 * Executable path components relative to a Wolfram installation directory, per
 * platform. Mirrors the paclet's `getWolframCommand`; an unlisted platform has
 * no defined layout and fails loud rather than guessing.
 * @type {Readonly<Record<string, readonly string[]>>}
 */
const RELATIVE_EXECUTABLE = Object.freeze({
  win32: ['wolfram.exe'],
  darwin: ['MacOS', 'wolfram'],
  linux: ['Executables', 'wolfram'],
})

/**
 * Path helpers for the TARGET platform rather than the host's.
 *
 * In production the two are the same, but taking the platform from the host
 * facts keeps this module a pure function of its inputs, so every layout can
 * be exercised from any machine.
 *
 * @param {string} platform - Platform id from the host facts.
 * @returns {{ join: (...parts: string[]) => string, dirname: (path: string) => string,
 *   basename: (path: string) => string, delimiter: string }} the platform's path helpers.
 */
function pathsFor(platform) {
  return platform === 'win32' ? win32 : posix
}

/**
 * Product directory names Wolfram ships under a platform install root, newest
 * naming first. Wolfram renamed the desktop product from `Mathematica` to
 * `Wolfram` in 14.1, and the free kernel is `Wolfram Engine`.
 * @type {readonly string[]}
 */
const PRODUCT_DIRECTORY_NAMES = Object.freeze([
  'Wolfram',
  'Mathematica',
  'Wolfram Desktop',
  'Wolfram Engine',
  'WolframEngine',
])

/** Where the MCP server expression lives; the paclet's own default argv. */
export const AGENT_TOOLS_START_EXPRESSION = 'PacletSymbol["Wolfram/AgentTools","Wolfram`AgentTools`StartMCPServer"][]'

/**
 * The argv the official paclet writes into every client configuration. The
 * `-run` expression is ONE argv element: the single quotes in the published
 * command line are shell syntax, and this plugin spawns without a shell.
 * @type {readonly string[]}
 */
export const AGENT_TOOLS_ARGS = Object.freeze(['-run', AGENT_TOOLS_START_EXPRESSION, '-noinit', '-noprompt'])

/** One resolved kernel command and where it came from. */
/**
 * @typedef {object} KernelResolution
 * @property {string} command Absolute path of the Wolfram executable.
 * @property {string} source Which resolution step produced it, for diagnostics.
 * @property {string} [installationDirectory] The installation the executable belongs to, when known.
 */

/** Host facts the resolver reads, injectable so the logic is testable off-platform. */
/**
 * @typedef {object} HostFacts
 * @property {string} platform `process.platform`.
 * @property {Record<string, string | undefined>} env The environment to read overrides from.
 * @property {(path: string) => boolean} [isFile] Existence probe, defaulting to a real stat.
 * @property {(path: string) => readonly string[]} [readDirectory] Directory listing, defaulting to a real read.
 * @property {(command: string, args: readonly string[], timeoutMs: number) => string | undefined} [runCapture]
 *   Runs a helper process and returns trimmed stdout, or `undefined` when it fails.
 */

/**
 * Default file probe: a path that exists and is a regular file.
 * @param {string} path - Candidate path.
 * @returns {boolean} whether it is a readable regular file.
 */
function defaultIsFile(path) {
  try {
    return statSync(path).isFile()
  } catch {
    // Absence and permission failures are both "not a usable candidate"; the
    // caller continues to the next candidate either way.
    return false
  }
}

/**
 * Default directory listing that reports an unreadable directory as empty.
 * @param {string} path - Directory to list.
 * @returns {readonly string[]} entry names, or an empty list.
 */
function defaultReadDirectory(path) {
  try {
    return readdirSync(path)
  } catch {
    // A missing or unreadable install root simply contributes no candidates.
    return []
  }
}

/**
 * Default helper-process runner used by registry and wolframscript probes.
 * @param {string} command - Executable to run.
 * @param {readonly string[]} args - Arguments passed without shell interpolation.
 * @param {number} timeoutMs - Hard timeout for the probe.
 * @returns {string | undefined} trimmed stdout, or `undefined` when the probe failed.
 */
function defaultRunCapture(command, args, timeoutMs) {
  const result = spawnSync(command, [...args], {
    encoding: 'utf8',
    timeout: timeoutMs,
    windowsHide: true,
    shell: false,
  })
  if (result.error !== undefined || result.status !== 0 || typeof result.stdout !== 'string') return undefined
  return result.stdout.trim()
}

/**
 * Compare two dotted version strings numerically, newest first.
 * Non-numeric segments sort below numeric ones so a stray directory never
 * outranks a real version.
 * @param {string} left - First version.
 * @param {string} right - Second version.
 * @returns {number} negative when `left` is newer.
 */
export function compareVersionsDescending(left, right) {
  const l = left.split('.')
  const r = right.split('.')
  for (let index = 0; index < Math.max(l.length, r.length); index += 1) {
    const a = Number.parseInt(l[index] ?? '', 10)
    const b = Number.parseInt(r[index] ?? '', 10)
    const aOk = Number.isFinite(a)
    const bOk = Number.isFinite(b)
    if (!aOk && !bOk) continue
    if (!aOk) return 1
    if (!bOk) return -1
    if (a !== b) return b - a
  }
  return 0
}

/**
 * Parse `reg query <key> /s /v <name>` output into key path to value.
 *
 * The format is a blank-line-separated block per key: the key path on its own
 * line, then indented `<name>    <TYPE>    <data>` rows. Value data may contain
 * spaces, so the split takes the first two whitespace-separated fields only.
 *
 * @param {string} output - Raw `reg.exe` stdout.
 * @returns {Map<string, string>} registry key path to the value's data.
 */
export function parseRegQuery(output) {
  /** @type {Map<string, string>} */
  const values = new Map()
  let key = ''
  for (const raw of output.split(/\r?\n/)) {
    if (raw.trim() === '') continue
    if (!/^\s/.test(raw)) {
      key = raw.trim()
      continue
    }
    const match = /^\s+(\S+)\s+REG_\w+\s+(.*)$/.exec(raw)
    const data = match?.[2]
    if (data === undefined || key === '') continue
    values.set(key, data.trim())
  }
  return values
}

/**
 * Windows installations known to the system registry, newest product version
 * first. Wolfram allows installing to any drive, so the registry is the only
 * discovery source that finds a non-default location.
 *
 * @param {HostFacts} host - Host facts, for the capture hook.
 * @returns {readonly string[]} candidate installation directories.
 */
function registryInstallations(host) {
  const run = host.runCapture ?? defaultRunCapture
  const key = 'HKLM\\SOFTWARE\\Wolfram Research\\Installations'
  const executables = parseRegQuery(run('reg', ['query', key, '/s', '/v', 'ExecutablePath'], 10_000) ?? '')
  if (executables.size === 0) return []
  const versions = parseRegQuery(run('reg', ['query', key, '/s', '/v', 'ProductVersion'], 10_000) ?? '')
  return [...executables]
    .map(([registryKey, executable]) => ({
      directory: win32.dirname(executable),
      version: versions.get(registryKey) ?? '0',
    }))
    .sort((left, right) => compareVersionsDescending(left.version, right.version))
    .map(entry => entry.directory)
}

/**
 * Installation directories under one platform install root: every
 * `<root>/<product>/<version>` directory, newest version first.
 * @param {HostFacts} host - Host facts, for the directory hook.
 * @param {string} root - Install root to scan.
 * @returns {readonly string[]} candidate installation directories.
 */
function versionedInstallations(host, root) {
  const readDirectory = host.readDirectory ?? defaultReadDirectory
  const { join } = pathsFor(host.platform)
  /** @type {{ directory: string; version: string }[]} */
  const found = []
  for (const product of PRODUCT_DIRECTORY_NAMES) {
    const productDirectory = join(root, product)
    for (const version of readDirectory(productDirectory)) {
      found.push({ directory: join(productDirectory, version), version })
    }
  }
  return found
    .sort((left, right) => compareVersionsDescending(left.version, right.version))
    .map(entry => entry.directory)
}

/**
 * Platform install roots scanned after the registry.
 * @param {HostFacts} host - Host facts, for environment-derived roots.
 * @returns {readonly string[]} install roots, most likely first.
 */
function installRoots(host) {
  const { join } = pathsFor(host.platform)
  switch (host.platform) {
    case 'win32': {
      const roots = [host.env.ProgramFiles, host.env['ProgramFiles(x86)'], 'C:\\Program Files']
      return [...new Set(roots.filter(root => typeof root === 'string' && root !== ''))]
        .map(root => join(/** @type {string} */(root), 'Wolfram Research'))
    }
    case 'darwin': {
      const home = host.env.HOME ?? ''
      return home === '' ? ['/Applications'] : ['/Applications', join(home, 'Applications')]
    }
    case 'linux':
      return ['/usr/local/Wolfram', '/opt/Wolfram', '/usr/local']
    default:
      return []
  }
}

/**
 * macOS keeps each product in an app bundle rather than a versioned tree.
 * @param {HostFacts} host - Host facts.
 * @returns {readonly string[]} candidate installation directories.
 */
function macApplicationBundles(host) {
  const { join } = pathsFor(host.platform)
  /** @type {string[]} */
  const candidates = []
  for (const root of installRoots(host)) {
    for (const product of PRODUCT_DIRECTORY_NAMES) {
      candidates.push(join(root, `${product}.app`, 'Contents'))
    }
  }
  return candidates
}

/**
 * Ask `wolframscript` where its kernel lives. Last resort: it starts a kernel,
 * so it costs seconds, but it is the one probe that works for an installation
 * neither the registry nor the standard roots know about.
 * @param {HostFacts} host - Host facts.
 * @param {number} timeoutMs - Hard timeout for the probe.
 * @returns {string | undefined} the installation directory, or `undefined`.
 */
function wolframscriptInstallation(host, timeoutMs) {
  const run = host.runCapture ?? defaultRunCapture
  const output = run('wolframscript', ['-code', '$InstallationDirectory'], timeoutMs)
  if (output === undefined) return undefined
  // The kernel prints the string with its quotes; a failed evaluation prints
  // `$Failed` or a message instead, which no existence check will accept.
  const unquoted = /^"(.*)"$/s.exec(output.trim())
  return unquoted === null ? output.trim() : unquoted[1]
}

/**
 * Executables named `wolfram` on PATH, for a Linux install that is only
 * reachable through a package-manager symlink.
 * @param {HostFacts} host - Host facts.
 * @returns {readonly string[]} candidate executable paths.
 */
function pathExecutables(host) {
  const relative = RELATIVE_EXECUTABLE[host.platform]
  if (relative === undefined) return []
  const { join, delimiter } = pathsFor(host.platform)
  const base = relative.at(-1) ?? ''
  return (host.env.PATH ?? '').split(delimiter).filter(entry => entry !== '').map(entry => join(entry, base))
}

/**
 * Resolve the Wolfram executable for this host.
 *
 * Explicit configuration wins, then the explicit environment override, then
 * platform discovery. Every branch records a `source` so a surprising kernel
 * choice is visible in the log instead of having to be inferred.
 *
 * @param {object} options - Resolution inputs.
 * @param {string} [options.command] - Explicit executable path; used verbatim.
 * @param {string} [options.installationDirectory] - Explicit installation directory.
 * @param {boolean} [options.probeWolframScript] - Allow the `wolframscript` probe (default true).
 * @param {number} [options.probeTimeoutMs] - Timeout for the `wolframscript` probe (default 30000).
 * @param {HostFacts} host - Host facts.
 * @returns {KernelResolution} the resolved command.
 * @throws {Error} when nothing resolves, naming every location tried and how to override.
 */
export function resolveWolframCommand(options, host) {
  const isFile = host.isFile ?? defaultIsFile
  const relative = RELATIVE_EXECUTABLE[host.platform]
  const { join } = pathsFor(host.platform)
  const relativeDisplay = relative === undefined ? '' : join(...relative)
  /** @type {string[]} */
  const tried = []

  /**
   * Accept an installation directory when it holds the platform's executable.
   * @param {string} directory - Installation directory to test.
   * @param {string} source - Diagnostic label for the resolution step.
   * @returns {KernelResolution | undefined} the resolution, when it holds up.
   */
  const fromInstallation = (directory, source) => {
    if (relative === undefined || directory === '') return undefined
    const command = join(directory, ...relative)
    tried.push(command)
    return isFile(command) ? { command, source, installationDirectory: directory } : undefined
  }

  if (options.command !== undefined && options.command !== '') {
    // An explicit path is used verbatim: a deployment that points at a wrapper
    // or a non-standard layout must not be second-guessed, and a wrong path
    // fails at spawn with the operating system's own diagnostic.
    return { command: options.command, source: 'config.command' }
  }
  const envCommand = host.env.DSH_WOLFRAM_COMMAND
  if (envCommand !== undefined && envCommand !== '') {
    return { command: envCommand, source: 'env.DSH_WOLFRAM_COMMAND' }
  }
  if (relative === undefined) {
    throw new Error(
      `dsh-wolfram: no known Wolfram layout for platform ${JSON.stringify(host.platform)} — `
      + 'set config.command (or DSH_WOLFRAM_COMMAND) to the Wolfram executable path',
    )
  }
  if (options.installationDirectory !== undefined && options.installationDirectory !== '') {
    const resolved = fromInstallation(options.installationDirectory, 'config.installationDirectory')
    if (resolved !== undefined) return resolved
    throw new Error(
      `dsh-wolfram: config.installationDirectory ${JSON.stringify(options.installationDirectory)} holds no ${relativeDisplay}`,
    )
  }
  const envDirectory = host.env.WOLFRAM_INSTALLATION_DIRECTORY
  if (envDirectory !== undefined && envDirectory !== '') {
    const resolved = fromInstallation(envDirectory, 'env.WOLFRAM_INSTALLATION_DIRECTORY')
    if (resolved !== undefined) return resolved
    throw new Error(
      `dsh-wolfram: WOLFRAM_INSTALLATION_DIRECTORY ${JSON.stringify(envDirectory)} holds no ${relativeDisplay}`,
    )
  }
  if (host.platform === 'win32') {
    for (const directory of registryInstallations(host)) {
      const resolved = fromInstallation(directory, 'windows-registry')
      if (resolved !== undefined) return resolved
    }
  }
  const roots = host.platform === 'darwin' ? macApplicationBundles(host) : []
  for (const directory of roots) {
    const resolved = fromInstallation(directory, 'platform-install-root')
    if (resolved !== undefined) return resolved
  }
  if (host.platform !== 'darwin') {
    for (const root of installRoots(host)) {
      for (const directory of versionedInstallations(host, root)) {
        const resolved = fromInstallation(directory, 'platform-install-root')
        if (resolved !== undefined) return resolved
      }
    }
  }
  for (const command of pathExecutables(host)) {
    tried.push(command)
    if (isFile(command)) return { command, source: 'PATH' }
  }
  if (options.probeWolframScript !== false) {
    const directory = wolframscriptInstallation(host, options.probeTimeoutMs ?? 30_000)
    if (directory !== undefined) {
      const resolved = fromInstallation(directory, 'wolframscript')
      if (resolved !== undefined) return resolved
    }
    tried.push('wolframscript -code $InstallationDirectory')
  }
  throw new Error(
    'dsh-wolfram: no Wolfram kernel found. Tried:\n'
    + tried.map(entry => `  - ${entry}`).join('\n')
    + '\nSet the `command` (or `installationDirectory`) config field on the `wolfram` row, '
    + 'or the DSH_WOLFRAM_COMMAND environment variable, to the Wolfram executable.',
  )
}
