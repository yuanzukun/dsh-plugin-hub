/**
 * Supervisor entry point: the executable the harness's MCP client spawns in
 * place of `wolfram`.
 *
 * Its only job is to turn the process into the {@link runSupervisor} contract —
 * parse argv, wire the real streams, and settle the exit code without
 * truncating protocol output that is still in flight.
 *
 * @module
 */

import process from 'node:process'
import { installProcessTriggers, parseSupervisorArgs, runSupervisor } from './supervisor.js'

/** How long to wait for the process to drain on its own before forcing the exit. */
const DRAIN_TIMEOUT_MS = 2_000

/**
 * Run the supervisor for this process.
 * @param {NodeJS.Process} proc - The host process.
 * @returns {void}
 */
export function main(proc) {
  /** @type {import('./supervisor.js').SupervisorSpec} */
  let spec
  try {
    spec = parseSupervisorArgs(proc.argv.slice(2))
  } catch (error) {
    proc.stderr.write(`${String(error instanceof Error ? error.message : error)}\n`)
    proc.exitCode = 64
    return
  }
  const handle = runSupervisor(spec, {
    stdin: proc.stdin,
    stdout: proc.stdout,
    stderr: proc.stderr,
    exit: code => {
      // Setting the code and letting the loop drain is what keeps the last
      // protocol bytes from being truncated by an immediate `exit()`; the
      // unreferenced timer only fires if some handle outlives the shutdown.
      proc.exitCode = code
      setTimeout(() => { proc.exit(code) }, DRAIN_TIMEOUT_MS).unref()
    },
  })
  installProcessTriggers(handle, proc)
}

main(process)
