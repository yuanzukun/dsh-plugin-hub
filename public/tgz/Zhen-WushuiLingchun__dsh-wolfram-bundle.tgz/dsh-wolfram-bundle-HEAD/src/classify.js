/**
 * Risk classification for the Wolfram MCP tool surface.
 *
 * The official Wolfram/AgentTools server advertises only a `title` annotation
 * on `tools/list` — there is no `readOnlyHint` or `destructiveHint` to route
 * on — so classification is by raw tool name, and every name this table does
 * not know falls through to the fail-safe decision.
 *
 * @module
 */

/**
 * What the permission policy does with one call.
 * `delegate` leaves the decision to the rest of the pre-execute chain.
 */
/** @typedef {'ask' | 'deny' | 'delegate'} WolframDecision */

/**
 * Tools that must not run before a human approves them, with the reason the
 * approval prompt shows. Covers every tool of the `WolframLanguage` server
 * plus the higher-risk tools of the other built-in AgentTools servers, so
 * pointing `mcpServerName` at `Wolfram` or `WolframPacletDevelopment` stays
 * classified rather than falling to the fail-safe branch.
 * @type {Readonly<Record<string, string>>}
 */
export const DEFAULT_ASK_TOOLS = Object.freeze({
  WolframLanguageEvaluator: 'evaluates arbitrary Wolfram Language code in an unsandboxed kernel (it can write files, start processes, and reach the network)',
  TestReport: 'runs Wolfram Language test files, which execute arbitrary code in a fresh kernel',
  WriteNotebook: 'writes a Wolfram notebook file to an arbitrary path',
  ReadNotebook: 'reads a file from an arbitrary path',
  CodeInspector: 'reads source files, recursively for a directory target',
  WolframAlpha: 'sends the query to the Wolfram|Alpha service',
  CreateSymbolDoc: 'writes paclet documentation notebooks',
  EditSymbolDoc: 'rewrites paclet documentation notebooks',
  EditSymbolDocExamples: 'rewrites paclet documentation notebooks',
  CheckPaclet: 'runs a paclet build check, which evaluates paclet code',
  BuildPaclet: 'builds a paclet, which evaluates paclet code and writes artifacts',
  SubmitPaclet: 'submits a paclet to the Wolfram Paclet Repository',
})

/**
 * Read-only metadata tools: documentation semantic search and in-kernel symbol
 * definitions. They observe, never mutate, so this plugin hands the decision
 * to whatever policy comes after it instead of claiming it.
 * @type {readonly string[]}
 */
export const DEFAULT_DELEGATE_TOOLS = Object.freeze([
  'WolframLanguageContext',
  'WolframAlphaContext',
  'SymbolDefinition',
])

/** A resolved classification table, ready for repeated lookup. */
/**
 * @typedef {object} ResolvedClassification
 * @property {string} prefix Public-name prefix owned by this server (`mcp__<serverName>__`).
 * @property {ReadonlyMap<string, string>} ask Raw tool name to approval reason.
 * @property {ReadonlySet<string>} delegate Raw tool names handed to the rest of the chain.
 * @property {'ask' | 'deny'} unknown Decision for a Wolfram tool absent from both lists.
 */

/** One classification verdict. */
/**
 * @typedef {object} Verdict
 * @property {WolframDecision} decision What the policy should do.
 * @property {string} [rawName] The MCP tool name, when the call belongs to this server.
 * @property {string} [reason] Human-readable justification, present for `ask` and `deny`.
 */

/** Delegation is the answer for every call this plugin does not own. */
const DELEGATE = Object.freeze(/** @type {Verdict} */ ({ decision: 'delegate' }))

/**
 * Build the lookup table once, rejecting a contradictory configuration at load
 * rather than resolving it silently at call time.
 *
 * @param {object} options - Raw configuration.
 * @param {string} options.serverName - The mcp-client `serverName` this policy guards.
 * @param {Record<string, string>} [options.ask] - Raw tool name to approval reason, replacing the defaults.
 * @param {readonly string[]} [options.delegate] - Raw tool names handed to the rest of the chain, replacing the defaults.
 * @param {Record<string, string>} [options.additionalAsk] - Extra ask entries merged over the effective table.
 * @param {'ask' | 'deny'} [options.unknown] - Decision for an unlisted Wolfram tool (default `ask`).
 * @returns {ResolvedClassification} the frozen table.
 * @throws {Error} when `serverName` is unusable, or one tool appears in both lists.
 */
export function resolveClassification(options) {
  const serverName = options.serverName
  if (typeof serverName !== 'string' || !/^[A-Za-z0-9_-]{1,32}$/.test(serverName)) {
    throw new Error(`dsh-wolfram/policy: serverName must match [A-Za-z0-9_-]{1,32}, got ${JSON.stringify(serverName)}`)
  }
  const unknown = options.unknown ?? 'ask'
  if (unknown !== 'ask' && unknown !== 'deny') {
    throw new Error(`dsh-wolfram/policy: unknown must be "ask" or "deny", got ${JSON.stringify(unknown)}`)
  }
  const ask = new Map(Object.entries({ ...options.ask ?? DEFAULT_ASK_TOOLS, ...options.additionalAsk }))
  const delegate = new Set(options.delegate ?? DEFAULT_DELEGATE_TOOLS)
  for (const name of delegate) {
    if (ask.has(name)) {
      throw new Error(`dsh-wolfram/policy: tool ${JSON.stringify(name)} is listed as both ask and delegate — pick one`)
    }
  }
  return Object.freeze({ prefix: `mcp__${serverName}__`, ask, delegate, unknown })
}

/**
 * Classify one pending tool call by its model-facing public name.
 *
 * mcp-client publishes `mcp__<serverName>__<rawName>`, normalizing and hashing
 * the name when it would break the function-name contract. A normalized name
 * keeps the prefix but no longer yields a known raw name, so it lands on the
 * fail-safe branch instead of silently losing its classification.
 *
 * @param {string} publicName - The registered tool name from the pending execution.
 * @param {ResolvedClassification} table - The table from {@link resolveClassification}.
 * @returns {Verdict} the decision, with a reason whenever it is not `delegate`.
 */
export function classifyToolCall(publicName, table) {
  if (!publicName.startsWith(table.prefix)) return DELEGATE
  const rawName = publicName.slice(table.prefix.length)
  if (table.delegate.has(rawName)) return DELEGATE
  const reason = table.ask.get(rawName)
  if (reason !== undefined) return { decision: 'ask', rawName, reason: `Wolfram ${rawName} ${reason}.` }
  return {
    decision: table.unknown,
    rawName,
    reason: `Wolfram ${rawName || '(unnamed)'} is not in this deployment's Wolfram tool classification, so its side effects are unknown.`,
  }
}
