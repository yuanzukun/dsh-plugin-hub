/**
 * Process-tree liveness and termination for exactly one owned process.
 *
 * Every function here takes a pid the caller spawned and recorded. There is no
 * lookup by image name, command-line pattern, or user — a pre-existing
 * Mathematica front end, notebook kernel, or another client's AgentTools
 * server can never be reached from this module.
 *
 * Windows terminates the tree through `taskkill /PID <pid> /T /F`, matching
 * the harness's own local subprocess provider. POSIX signals the process group
 * the supervisor created with `detached: true`, falling back to the direct
 * child when no group exists.
 *
 * @module
 */

import { spawnSync } from 'node:child_process'
import { readFileSync, readlinkSync } from 'node:fs'
import { basename } from 'node:path'

/**
 * Whether a pid currently names a live process this user may signal.
 *
 * `kill(pid, 0)` performs the permission and existence check without
 * delivering a signal. `EPERM` means the pid exists but belongs to someone
 * else, which still counts as alive — and, for a reclaim decision, as
 * something this plugin must not touch.
 *
 * @param {number} pid - Process id to probe.
 * @returns {boolean} whether the process exists.
 */
export function isProcessAlive(pid) {
  if (!Number.isInteger(pid) || pid <= 0) return false
  try {
    process.kill(pid, 0)
    return true
  } catch (error) {
    return /** @type {NodeJS.ErrnoException} */ (error).code === 'EPERM'
  }
}

/** Outcome of one termination attempt. */
/**
 * @typedef {object} TerminationOutcome
 * @property {boolean} attempted Whether a termination call was issued at all.
 * @property {boolean} ok Whether the platform reported success (or the target was already gone).
 * @property {string} detail Human-readable result for the log.
 */

/**
 * Terminate the process tree rooted at one owned pid.
 *
 * Callers must hold the spawned child handle (or have verified the pid's
 * identity) before calling: this function trusts the pid completely.
 *
 * @param {number} pid - Root of the tree to terminate.
 * @param {object} [options] - Platform overrides for testing.
 * @param {string} [options.platform] - Platform id, defaulting to `process.platform`.
 * @param {typeof spawnSync} [options.runSync] - Synchronous runner for `taskkill`.
 * @returns {TerminationOutcome} what happened.
 */
export function terminateProcessTree(pid, options = {}) {
  if (!Number.isInteger(pid) || pid <= 0) {
    return { attempted: false, ok: false, detail: `refusing to terminate invalid pid ${String(pid)}` }
  }
  const platform = options.platform ?? process.platform
  if (platform === 'win32') {
    const run = options.runSync ?? spawnSync
    const result = run('taskkill', ['/PID', String(pid), '/T', '/F'], { windowsHide: true, encoding: 'utf8' })
    if (result.error !== undefined) {
      return { attempted: true, ok: false, detail: `taskkill failed to start: ${String(result.error)}` }
    }
    // 128 is taskkill's "process not found": the tree is already gone, which
    // is the state this call exists to reach.
    const ok = result.status === 0 || result.status === 128
    return { attempted: true, ok, detail: `taskkill /T /F exited ${String(result.status)}` }
  }
  // POSIX: the supervisor spawns detached, so the child leads its own process
  // group whose id equals its pid. Signalling the negated pid reaches every
  // descendant that has not left the group.
  try {
    process.kill(-pid, 'SIGKILL')
    return { attempted: true, ok: true, detail: `SIGKILL to process group ${String(pid)}` }
  } catch (error) {
    const code = /** @type {NodeJS.ErrnoException} */ (error).code
    if (code === 'ESRCH') return { attempted: true, ok: true, detail: 'process group already gone' }
    try {
      process.kill(pid, 'SIGKILL')
      return { attempted: true, ok: true, detail: `SIGKILL to pid ${String(pid)} (no process group)` }
    } catch (fallbackError) {
      const fallbackCode = /** @type {NodeJS.ErrnoException} */ (fallbackError).code
      if (fallbackCode === 'ESRCH') return { attempted: true, ok: true, detail: 'process already gone' }
      return { attempted: true, ok: false, detail: `kill failed: ${String(fallbackError)}` }
    }
  }
}

/** Identity facts read back from the operating system for one pid. */
/**
 * @typedef {object} ProcessIdentity
 * @property {number} pid The queried pid.
 * @property {string} name Executable image name.
 * @property {string} commandLine Full command line, empty when the platform hides it.
 * @property {number} [createdAtMs] Process creation time in epoch milliseconds, when available.
 */

/**
 * Read one live process's identity, for verifying a recorded pid before
 * terminating it. Returns `undefined` when the process is gone or the platform
 * query fails — both mean "do not terminate".
 *
 * @param {number} pid - Process id to inspect.
 * @param {object} [options] - Platform overrides for testing.
 * @param {string} [options.platform] - Platform id, defaulting to `process.platform`.
 * @param {typeof spawnSync} [options.runSync] - Synchronous runner for the platform query.
 * @param {number} [options.timeoutMs] - Query timeout (default 15000).
 * @returns {ProcessIdentity | undefined} the identity, or `undefined`.
 */
export function readProcessIdentity(pid, options = {}) {
  if (!Number.isInteger(pid) || pid <= 0) return undefined
  const platform = options.platform ?? process.platform
  const run = options.runSync ?? spawnSync
  const timeout = options.timeoutMs ?? 15_000
  if (platform === 'win32') {
    // CIM is the only Windows source that reports creation time together with
    // the command line; both are needed to rule out pid reuse.
    const script
      = `$p = Get-CimInstance Win32_Process -Filter 'ProcessId=${String(pid)}' -ErrorAction SilentlyContinue; `
      + 'if ($null -eq $p) { exit 3 }; '
      + '[Console]::Out.Write((ConvertTo-Json -Compress -InputObject @{ '
      + 'pid = [int]$p.ProcessId; name = [string]$p.Name; commandLine = [string]$p.CommandLine; '
      + 'createdAtMs = [long]($p.CreationDate.ToUniversalTime() - [datetime]"1970-01-01").TotalMilliseconds }))'
    const result = run('powershell', ['-NoProfile', '-NonInteractive', '-Command', script], {
      encoding: 'utf8', timeout, windowsHide: true,
    })
    if (result.error !== undefined || result.status !== 0 || typeof result.stdout !== 'string') return undefined
    try {
      const parsed = /** @type {ProcessIdentity} */ (JSON.parse(result.stdout))
      return typeof parsed.pid === 'number' ? parsed : undefined
    } catch {
      // A truncated or non-JSON reply is unusable identity evidence, and the
      // caller must treat missing evidence as "leave the process alone".
      return undefined
    }
  }
  try {
    const commandLine = readFileSync(`/proc/${String(pid)}/cmdline`).toString('utf8').split('\0').filter(Boolean).join(' ')
    if (commandLine === '') return undefined
    let name = ''
    try { name = basename(readlinkSync(`/proc/${String(pid)}/exe`)) } catch { name = commandLine.split(/\s+/)[0] ?? '' }
    const stat = readFileSync(`/proc/${String(pid)}/stat`, 'utf8')
    const close = stat.lastIndexOf(')')
    const fields = close === -1 ? [] : stat.slice(close + 2).trim().split(/\s+/)
    const startTicks = Number.parseInt(fields[19] ?? '', 10)
    const bootLine = readFileSync('/proc/stat', 'utf8').split('\n').find(line => line.startsWith('btime '))
    const bootSeconds = Number.parseInt(bootLine?.split(/\s+/)[1] ?? '', 10)
    const hzResult = run('getconf', ['CLK_TCK'], { encoding: 'utf8', timeout })
    const ticksPerSecond = Number.parseInt(String(hzResult.stdout ?? '').trim(), 10)
    const createdAtMs = Number.isFinite(startTicks) && Number.isFinite(bootSeconds) && Number.isFinite(ticksPerSecond)
      && ticksPerSecond > 0
      ? Math.round((bootSeconds + startTicks / ticksPerSecond) * 1000)
      : undefined
    return { pid, name, commandLine, ...createdAtMs === undefined ? {} : { createdAtMs } }
  } catch {
    return undefined
  }
}
