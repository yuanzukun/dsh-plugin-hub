/**
 * The one explicit resolve step from the `wolfram` row's raw config to the
 * spec the plugin runs.
 *
 * Every default lives here rather than being applied where a value is read, and
 * every field is judged at load: a misconfigured row fails the plugin instance
 * with an actionable message instead of surfacing as a puzzling runtime error.
 *
 * @module
 */

import { posix, win32 } from 'node:path'
import { fileURLToPath } from 'node:url'
import { AGENT_TOOLS_ARGS, resolveWolframCommand } from './discovery.js'
import { harnessHome } from './harness-module.js'
import { RECORD_DIRECTORY_NAME } from './orphans.js'
import { DEFAULT_GRACE_MS, MAX_GRACE_MS } from './supervisor.js'

/**
 * Per-tool-call timeout for the Wolfram server.
 *
 * The evaluator tool's own default `TimeConstraint` is 60 s, which is exactly
 * the mcp-client default wire timeout; matching them would make a
 * budget-exhausting evaluation race its own transport. This leaves headroom so
 * the kernel's answer — including its timeout message — reaches the model.
 */
const DEFAULT_TOOL_CALL_TIMEOUT_MS = 120_000

/** Non-secret variables required for WSL to invoke a Windows executable. */
export const WSL_INTEROP_ENV_ALLOWLIST = Object.freeze([
  'WSL_INTEROP',
  'WSLENV',
  'LANG',
  'LC_ALL',
  'TERM',
])

/** Absolute path of the supervisor entry inside this package. */
const SUPERVISOR_ENTRY = fileURLToPath(new URL('./supervisor-main.js', import.meta.url))

/** A resolved `wolfram` row. */
/**
 * @typedef {object} WolframSpec
 * @property {string} serverName mcp-client namespace; tools appear as `mcp__<serverName>__<rawName>`.
 * @property {string} mcpServerName Which built-in AgentTools server to start (`MCP_SERVER_NAME`).
 * @property {import('./discovery.js').KernelResolution} kernel The resolved Wolfram executable.
 * @property {readonly string[]} kernelArgs Arguments passed to the Wolfram executable.
 * @property {number} graceMs Supervisor shutdown grace period.
 * @property {string} recordDirectory Where the supervisor records its child.
 * @property {boolean} reclaimOrphans Whether to sweep leftover records on activation and disposal.
 * @property {Record<string, string>} env Extra environment for the Wolfram process.
 * @property {string} cwd Working directory for the Wolfram process, empty for the harness's own.
 * @property {number} toolCallTimeoutMs Per-tool-call wire timeout.
 * @property {boolean} failOnStartupError Whether a failed first connection fails plugin activation.
 * @property {string} platform Platform under which the harness runs.
 * @property {unknown} [reconnect] mcp-client reconnect policy, passed through unchanged.
 */

/**
 * Reject a config value that is present but of the wrong type. Absence is
 * always allowed; every field has a default.
 * @param {unknown} value - The raw value.
 * @param {string} field - Field name for the message.
 * @param {'string' | 'number' | 'boolean'} type - Expected primitive type.
 * @returns {void}
 * @throws {Error} when the value is present and not of `type`.
 */
function assertOptional(value, field, type) {
  if (value !== undefined && typeof value !== type) {
    throw new Error(`dsh-wolfram: config.${field} must be a ${type}, got ${JSON.stringify(value)}`)
  }
}

/**
 * Resolve the `wolfram` row.
 *
 * @param {Record<string, unknown>} config - The raw row config.
 * @param {import('./discovery.js').HostFacts} host - Host facts for kernel discovery.
 * @returns {WolframSpec} the resolved spec.
 * @throws {Error} when a field is invalid or no Wolfram kernel can be found.
 */
export function resolveWolframSpec(config, host) {
  const serverName = /** @type {string} */ (config.serverName ?? 'wolfram')
  if (typeof serverName !== 'string' || !/^[A-Za-z0-9_-]{1,32}$/.test(serverName)) {
    throw new Error(`dsh-wolfram: config.serverName must match [A-Za-z0-9_-]{1,32}, got ${JSON.stringify(serverName)}`)
  }
  const mcpServerName = /** @type {string} */ (config.mcpServerName ?? 'WolframLanguage')
  if (typeof mcpServerName !== 'string' || mcpServerName === '') {
    throw new Error(`dsh-wolfram: config.mcpServerName must be a non-empty string, got ${JSON.stringify(mcpServerName)}`)
  }
  assertOptional(config.command, 'command', 'string')
  assertOptional(config.installationDirectory, 'installationDirectory', 'string')
  assertOptional(config.cwd, 'cwd', 'string')
  assertOptional(config.recordDirectory, 'recordDirectory', 'string')
  assertOptional(config.reclaimOrphans, 'reclaimOrphans', 'boolean')
  assertOptional(config.probeWolframScript, 'probeWolframScript', 'boolean')
  assertOptional(config.probeTimeoutMs, 'probeTimeoutMs', 'number')
  assertOptional(config.failOnStartupError, 'failOnStartupError', 'boolean')
  assertOptional(config.toolCallTimeoutMs, 'toolCallTimeoutMs', 'number')
  assertOptional(config.forwardWslInteropEnv, 'forwardWslInteropEnv', 'boolean')

  const graceMs = /** @type {number} */ (config.graceMs ?? DEFAULT_GRACE_MS)
  if (!Number.isInteger(graceMs) || graceMs < 1 || graceMs > MAX_GRACE_MS) {
    throw new Error(
      `dsh-wolfram: config.graceMs must be an integer in 1..${String(MAX_GRACE_MS)}, got ${JSON.stringify(graceMs)}; `
      + 'the MCP SDK force-terminates the supervisor 2000ms after closing its stdin, so a longer grace would skip '
      + 'process-tree cleanup entirely',
    )
  }
  const toolCallTimeoutMs = /** @type {number} */ (config.toolCallTimeoutMs ?? DEFAULT_TOOL_CALL_TIMEOUT_MS)
  if (!Number.isFinite(toolCallTimeoutMs) || toolCallTimeoutMs <= 0) {
    throw new Error(`dsh-wolfram: config.toolCallTimeoutMs must be a positive number, got ${JSON.stringify(toolCallTimeoutMs)}`)
  }
  const rawArgs = config.args
  if (rawArgs !== undefined && (!Array.isArray(rawArgs) || rawArgs.some(arg => typeof arg !== 'string'))) {
    throw new Error('dsh-wolfram: config.args must be an array of strings')
  }
  const rawEnv = config.env
  if (rawEnv !== undefined && (typeof rawEnv !== 'object' || rawEnv === null || Array.isArray(rawEnv)
    || Object.values(rawEnv).some(value => typeof value !== 'string'))) {
    throw new Error('dsh-wolfram: config.env must be a map of string values')
  }

  const kernel = resolveWolframCommand({
    command: /** @type {string | undefined} */ (config.command),
    installationDirectory: /** @type {string | undefined} */ (config.installationDirectory),
    probeWolframScript: /** @type {boolean | undefined} */ (config.probeWolframScript),
    probeTimeoutMs: /** @type {number | undefined} */ (config.probeTimeoutMs),
  }, host)

  const inheritedInteropEnv = host.platform === 'linux' && config.forwardWslInteropEnv !== false
    ? Object.fromEntries(WSL_INTEROP_ENV_ALLOWLIST
      .filter(name => typeof host.env[name] === 'string' && host.env[name] !== '')
      .map(name => [name, /** @type {string} */ (host.env[name])]))
    : {}
  const pathApi = host.platform === 'win32' ? win32 : posix

  return {
    serverName,
    mcpServerName,
    kernel,
    kernelArgs: /** @type {readonly string[]} */ (rawArgs ?? AGENT_TOOLS_ARGS),
    graceMs,
    recordDirectory: /** @type {string} */ (config.recordDirectory)
      || pathApi.join(harnessHome(host.env, /** @type {NodeJS.Platform} */ (host.platform)), RECORD_DIRECTORY_NAME),
    reclaimOrphans: /** @type {boolean} */ (config.reclaimOrphans ?? true),
    env: { ...inheritedInteropEnv, .../** @type {Record<string, string>} */ (rawEnv ?? {}) },
    cwd: /** @type {string} */ (config.cwd ?? ''),
    toolCallTimeoutMs,
    failOnStartupError: /** @type {boolean} */ (config.failOnStartupError ?? false),
    platform: host.platform,
    ...config.reconnect === undefined ? {} : { reconnect: config.reconnect },
  }
}

/**
 * Build the `@deepseek-ai/dsh-mcp-client` config that runs the resolved kernel
 * behind this package's supervisor.
 *
 * The command is the harness's own Node binary rather than a shim, so the
 * supervisor runs on the same runtime as the harness and needs nothing on
 * `PATH`; the supervisor entry resolves from this module's own URL, so the
 * package works from wherever pnpm installed it.
 *
 * @param {WolframSpec} spec - The resolved row.
 * @param {string} nodeExecutable - Absolute path of the Node binary to run the supervisor with.
 * @returns {Record<string, unknown>} the mcp-client stdio config.
 */
export function buildMcpClientConfig(spec, nodeExecutable) {
  const windowsInterop = spec.platform === 'linux' && /\.exe$/i.test(spec.kernel.command)
  const wslEnvParts = String(spec.env.WSLENV ?? '').split(':').filter(Boolean)
  if (windowsInterop && !wslEnvParts.includes('MCP_SERVER_NAME/w')) wslEnvParts.push('MCP_SERVER_NAME/w')
  return {
    transport: 'stdio',
    serverName: spec.serverName,
    command: nodeExecutable,
    args: [
      SUPERVISOR_ENTRY,
      '--command', spec.kernel.command,
      ...spec.kernelArgs.flatMap(arg => ['--arg', arg]),
      '--grace-ms', String(spec.graceMs),
      ...spec.reclaimOrphans ? ['--record-dir', spec.recordDirectory] : [],
      ...spec.cwd === '' ? [] : ['--cwd', spec.cwd],
    ],
    env: {
      MCP_SERVER_NAME: spec.mcpServerName,
      ...spec.env,
      ...windowsInterop ? { WSLENV: wslEnvParts.join(':') } : {},
    },
    cwd: spec.cwd,
    toolCallTimeoutMs: spec.toolCallTimeoutMs,
    failOnStartupError: spec.failOnStartupError,
    ...spec.reconnect === undefined ? {} : { reconnect: spec.reconnect },
  }
}
