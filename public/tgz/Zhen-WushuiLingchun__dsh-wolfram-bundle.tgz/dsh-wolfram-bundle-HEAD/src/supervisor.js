/**
 * Transparent stdio supervisor for one Wolfram MCP server process.
 *
 * The harness's MCP client spawns this instead of `wolfram` directly. It
 * forwards bytes in both directions without inspecting them, and it owns the
 * one thing the MCP SDK cannot do on Windows: terminating the whole process
 * tree of the child it started, and only that child.
 *
 * Shutdown order is always the same — close the child's stdin (AgentTools
 * treats stdin EOF as a shutdown signal and exits 0), wait out the grace
 * period, then terminate the recorded pid's tree. The grace period is capped
 * below the MCP SDK's 2000 ms `SIGTERM` deadline so the tree-termination step
 * actually runs instead of being cut short by a `TerminateProcess` that no
 * JavaScript survives.
 *
 * Termination targets a pid only while this supervisor still holds the
 * un-reaped child handle. Once the child's exit is observed the pid is
 * released and never signalled again, so a pid the operating system has since
 * reused cannot be hit.
 *
 * @module
 */

import { spawn } from 'node:child_process'
import { deleteRecord, writeRecord } from './orphans.js'
import { terminateProcessTree } from './process-tree.js'

/**
 * Upper bound for the shutdown grace period.
 *
 * `StdioClientTransport.close()` in `@modelcontextprotocol/sdk` waits 2000 ms
 * after ending stdin before sending `SIGTERM`, which on Windows terminates
 * this supervisor without running any handler. A grace period at or above that
 * deadline would mean the tree-termination step never executes.
 */
export const MAX_GRACE_MS = 1_800

/** Default grace period: long enough for an idle kernel's clean exit, well inside {@link MAX_GRACE_MS}. */
export const DEFAULT_GRACE_MS = 1_000

/** How long to wait after tree termination before giving up and exiting anyway. */
const HARD_TIMEOUT_MS = 3_000

/**
 * How long to wait after the child's exit for its stdio to close. A surviving
 * descendant can inherit the pipe and delay `close` indefinitely; the exit code
 * is already known by then, so the wait is bounded.
 */
const STDIO_CLOSE_TIMEOUT_MS = 500

/** Prefix on every supervisor diagnostic; stdout stays reserved for the protocol. */
const LOG_PREFIX = '[dsh-wolfram-supervisor]'

/** One parsed supervisor invocation. */
/**
 * @typedef {object} SupervisorSpec
 * @property {string} command Executable to supervise.
 * @property {readonly string[]} args Arguments passed verbatim.
 * @property {string} [cwd] Working directory for the child.
 * @property {number} graceMs Milliseconds between closing the child's stdin and terminating its tree.
 * @property {string} [recordDir] Directory for the orphan record; omitted disables recording.
 */

/**
 * Parse the supervisor's own command line.
 *
 * Flags are explicit and repeatable rather than a packed JSON blob so a running
 * supervisor is readable in a process list.
 *
 * @param {readonly string[]} argv - Arguments after the script path.
 * @returns {SupervisorSpec} the parsed invocation.
 * @throws {Error} on an unknown flag, a missing value, or an out-of-range grace period.
 */
export function parseSupervisorArgs(argv) {
  /** @type {string | undefined} */
  let command
  /** @type {string[]} */
  const args = []
  /** @type {string | undefined} */
  let cwd
  /** @type {string | undefined} */
  let recordDir
  let graceMs = DEFAULT_GRACE_MS
  for (let index = 0; index < argv.length; index += 1) {
    const flag = argv[index]
    const value = argv[index + 1]
    const takeValue = () => {
      if (value === undefined) throw new Error(`${LOG_PREFIX} ${flag} needs a value`)
      index += 1
      return value
    }
    switch (flag) {
      case '--command': command = takeValue(); break
      case '--arg': args.push(takeValue()); break
      case '--cwd': cwd = takeValue(); break
      case '--record-dir': recordDir = takeValue(); break
      case '--grace-ms': {
        const raw = takeValue()
        graceMs = Number.parseInt(raw, 10)
        if (!Number.isInteger(graceMs) || graceMs < 1 || graceMs > MAX_GRACE_MS) {
          throw new Error(
            `${LOG_PREFIX} --grace-ms must be an integer in 1..${String(MAX_GRACE_MS)}, got ${JSON.stringify(raw)}; `
            + 'the MCP SDK force-terminates this process 2000ms after closing stdin, so a longer grace would '
            + 'skip process-tree cleanup entirely',
          )
        }
        break
      }
      default:
        throw new Error(`${LOG_PREFIX} unknown argument ${JSON.stringify(flag)}`)
    }
  }
  if (command === undefined || command === '') throw new Error(`${LOG_PREFIX} --command is required`)
  return { command, args, graceMs, ...cwd === undefined ? {} : { cwd }, ...recordDir === undefined ? {} : { recordDir } }
}

/**
 * Streams and hooks the supervisor uses, injectable for tests.
 * @typedef {object} SupervisorIo
 * @property {NodeJS.ReadableStream} stdin Byte source from the MCP client.
 * @property {NodeJS.WritableStream} stdout Byte sink to the MCP client; protocol bytes only.
 * @property {NodeJS.WritableStream} stderr Diagnostic sink.
 * @property {(code: number) => void} exit Settles the supervisor with an exit code.
 * @property {typeof spawn} [spawnChild] Child spawner.
 * @property {string} [platform] Platform id, defaulting to `process.platform`.
 */

/** A running supervisor, as seen by process-level triggers. */
/**
 * @typedef {object} SupervisorHandle
 * @property {number | undefined} liveChildPid The supervised pid while this supervisor still owns it; `undefined` once it exits.
 * @property {(reason: string) => void} beginShutdown Starts the one shutdown sequence.
 */

/**
 * Run one supervised child until it exits.
 *
 * @param {SupervisorSpec} spec - The parsed invocation.
 * @param {SupervisorIo} io - Streams and hooks.
 * @returns {SupervisorHandle} the running supervisor.
 */
export function runSupervisor(spec, io) {
  const platform = io.platform ?? process.platform
  const spawnChild = io.spawnChild ?? spawn
  /** @param {string} message - Diagnostic line, written to stderr only. */
  const log = message => { io.stderr.write(`${LOG_PREFIX} ${message}\n`) }

  const child = spawnChild(spec.command, [...spec.args], {
    ...spec.cwd === undefined ? {} : { cwd: spec.cwd },
    stdio: ['pipe', 'pipe', 'pipe'],
    windowsHide: true,
    // POSIX: give the child its own process group so one signal reaches every
    // descendant. Windows has no process groups here; the tree is terminated
    // by pid through taskkill instead.
    detached: platform !== 'win32',
    shell: false,
  })

  /** @type {string | undefined} */
  let recordPath
  if (spec.recordDir !== undefined && child.pid !== undefined) {
    recordPath = writeRecord(spec.recordDir, {
      supervisorPid: process.pid,
      childPid: child.pid,
      command: spec.command,
      spawnedAtMs: Date.now(),
    })
  }

  /** The pid this supervisor may still signal; cleared the moment the child's exit is observed. */
  let ownedPid = child.pid
  let shuttingDown = false
  let finished = false
  /** @type {NodeJS.Timeout | undefined} */
  let graceTimer
  /** @type {NodeJS.Timeout | undefined} */
  let hardTimer
  /** @type {NodeJS.Timeout | undefined} */
  let closeTimer

  const clearTimers = () => {
    for (const timer of [graceTimer, hardTimer, closeTimer]) {
      if (timer !== undefined) clearTimeout(timer)
    }
    graceTimer = undefined
    hardTimer = undefined
    closeTimer = undefined
  }

  /**
   * Settle the supervisor once, releasing every handle that would otherwise
   * hold the process open.
   * @param {number} code - Exit code reported to the MCP client.
   */
  const finish = code => {
    if (finished) return
    finished = true
    clearTimers()
    deleteRecord(recordPath)
    recordPath = undefined
    // The client's pipe would keep the event loop alive after the child is
    // gone; releasing it lets the process exit on its own.
    const stdin = /** @type {{ destroy?: () => void }} */ (/** @type {unknown} */ (io.stdin))
    if (typeof stdin.destroy === 'function') stdin.destroy()
    // Descendants may have inherited one of the child's pipe descriptors.  A
    // bounded supervisor must not keep waiting for such a descriptor after
    // the owned child has exited or the hard cleanup path has fired.
    child.stdin?.destroy()
    child.stdout?.unpipe(io.stdout)
    child.stderr?.unpipe(io.stderr)
    child.stdout?.destroy()
    child.stderr?.destroy()
    io.exit(code)
  }

  /**
   * Terminate the owned child's tree — never anything else — and arm the
   * last-resort exit.
   */
  const terminateTree = () => {
    const pid = ownedPid
    if (pid === undefined) return
    log(`grace period elapsed; terminating process tree of pid ${String(pid)}`)
    const outcome = terminateProcessTree(pid, { platform })
    log(`process-tree termination: ${outcome.detail}`)
    hardTimer = setTimeout(() => {
      if (ownedPid === undefined) return
      log(`child ${String(pid)} did not exit after process-tree termination; exiting anyway`)
      finish(1)
    }, HARD_TIMEOUT_MS)
    hardTimer.unref()
  }

  /**
   * Start the one shutdown sequence. Repeat calls are ignored so racing
   * triggers (stdin EOF and a signal) cannot restart the grace timer.
   * @param {string} reason - What triggered the shutdown, for the log.
   */
  const beginShutdown = reason => {
    if (shuttingDown) return
    shuttingDown = true
    log(`shutting down (${reason})`)
    if (ownedPid === undefined) {
      finish(0)
      return
    }
    try {
      child.stdin?.end()
    } catch {
      // A child that already closed its stdin needs no further request; the
      // grace timer still covers the case where it does not exit.
    }
    graceTimer = setTimeout(terminateTree, spec.graceMs)
  }

  child.on('error', error => {
    log(`failed to start ${spec.command}: ${String(error)}`)
    ownedPid = undefined
    finish(127)
  })

  child.on('exit', (code, signal) => {
    // Releasing the pid here is what makes every later termination path safe:
    // from this point the operating system may reuse the number.
    ownedPid = undefined
    clearTimers()
    if (signal !== null) log(`child exited on signal ${signal}`)
    // 128 + signal is the shell convention; what matters is that a signalled
    // death is not reported as success.
    const exitCode = code ?? (signal === null ? 1 : 128)
    // `close` proves the child's stdio is drained, but a surviving descendant
    // holding the pipe can delay it, so the wait is bounded.
    closeTimer = setTimeout(() => { finish(exitCode) }, STDIO_CLOSE_TIMEOUT_MS)
    child.once('close', () => { finish(exitCode) })
  })

  // Byte passthrough. `end: false` in both directions keeps stream lifetime
  // under this module's control: closing the child's stdin is the shutdown
  // trigger, and the client's stdout must stay open until the child's output
  // has been flushed.
  io.stdin.pipe(/** @type {NodeJS.WritableStream} */ (child.stdin), { end: false })
  child.stdout?.pipe(io.stdout, { end: false })
  child.stderr?.pipe(io.stderr, { end: false })

  io.stdin.on('end', () => { beginShutdown('client closed stdin') })
  io.stdin.on('error', error => { beginShutdown(`client stdin error: ${String(error)}`) })
  child.stdin?.on('error', error => {
    // The child's stdin closes first on a normal exit; only report it when it
    // happens while the connection is supposed to be live.
    if (!shuttingDown && ownedPid !== undefined) log(`child stdin error: ${String(error)}`)
  })
  io.stdout.on('error', error => { beginShutdown(`client stdout error: ${String(error)}`) })

  return {
    get liveChildPid() { return ownedPid },
    beginShutdown,
  }
}

/**
 * Install process-level shutdown triggers around a running supervisor.
 *
 * The `exit` listener is the last-resort synchronous sweep: it runs on any
 * JavaScript-observable exit, including an uncaught exception, and terminates
 * the still-owned tree without creating a promise or timer. It cannot cover
 * `SIGKILL` or Windows `TerminateProcess`, which is what the orphan records
 * exist for.
 *
 * @param {SupervisorHandle} handle - The running supervisor.
 * @param {NodeJS.Process} proc - Process to install on.
 * @param {string} [platform] - Platform id, defaulting to the process's own.
 * @returns {void}
 */
export function installProcessTriggers(handle, proc, platform) {
  for (const signal of /** @type {const} */ (['SIGINT', 'SIGTERM', 'SIGHUP', 'SIGBREAK'])) {
    try {
      proc.on(signal, () => { handle.beginShutdown(`received ${signal}`) })
    } catch {
      // Windows has no SIGHUP and POSIX has no SIGBREAK; an unavailable name
      // simply contributes no trigger.
    }
  }
  proc.on('uncaughtException', error => {
    proc.stderr.write(`${LOG_PREFIX} uncaught exception: ${String(error)}\n`)
    handle.beginShutdown('uncaught exception')
  })
  proc.on('unhandledRejection', reason => {
    proc.stderr.write(`${LOG_PREFIX} unhandled rejection: ${String(reason)}\n`)
    handle.beginShutdown('unhandled rejection')
  })
  proc.on('exit', () => {
    const pid = handle.liveChildPid
    if (pid === undefined) return
    terminateProcessTree(pid, { platform: platform ?? proc.platform })
  })
}
