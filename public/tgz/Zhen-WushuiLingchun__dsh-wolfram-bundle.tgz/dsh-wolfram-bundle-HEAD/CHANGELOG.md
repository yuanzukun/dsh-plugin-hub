# Changelog

## 0.2.1

- certify the bundle against official DSH 0.1.1-rc.2 at commit `b150a551b8` while retaining 0.1.0-rc.5 compatibility;
- validate the dynamically imported `@deepseek-ai/dsh-mcp-client` namespace before mounting it;
- add a reusable `DSH_SOURCE_ROOT` host-contract test for built DSH checkouts;
- keep rc.2 image admission and durable rich-result projection in the official MCP client rather than duplicating it here;
- verify a packed install, composed profile, real Web boot, HTTP response, and owned-process teardown in an isolated `DSH_HOME`.

## 0.2.0

- make DSH home, record paths and fixtures platform-native on Windows and POSIX;
- derive POSIX process identity and creation time from `/proc`;
- isolate POSIX fixture process groups and make supervisor teardown naturally quiescent;
- preserve Windows behavior while recognizing Windows and POSIX command basenames;
- forward a minimal non-secret WSL interop allowlist and mark `MCP_SERVER_NAME/w`;
- pin every development dependency exactly and publish the offline tarball/integrity inventory;
- add WSL tests for paths, credential exclusion, process identity, cleanup and real AgentTools lifecycle;
- disclose that the changes were produced with GPT/Codex assistance and reviewed through repository tests.
