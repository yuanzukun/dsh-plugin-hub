/**
 * Orphan reclamation against a real Wolfram process.
 *
 * Two facts are established here.
 *
 * First, the observed shutdown behavior of this machine's AgentTools server:
 * force-terminating ONLY the supervisor (no tree, so no JavaScript runs)
 * closes the kernel's stdin, and the kernel exits on its own within about a
 * second — even while an evaluation is in flight. Real orphans are therefore
 * rare, which is why reclamation is a safety net rather than the primary
 * mechanism.
 *
 * Second, that the safety net works against a real process. Because the
 * supervisor path self-heals, the orphan here is constructed directly: a real
 * Wolfram MCP server is started with its stdin held open by this test, and a
 * record is written naming a supervisor pid that is already gone. Everything
 * the sweep then does — the liveness probe, the CIM identity read, the command
 * line and creation-time checks, the process-tree termination — runs for real.
 *
 * Skips itself when no Wolfram kernel can be discovered.
 *
 * @module
 */

import assert from 'node:assert/strict'
import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, readdirSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { after, describe, it } from 'node:test'
import { fileURLToPath } from 'node:url'
import { AGENT_TOOLS_ARGS, resolveWolframCommand } from '../src/discovery.js'
import { reclaimOrphans, writeRecord } from '../src/orphans.js'
import { isProcessAlive, readProcessIdentity, terminateProcessTree } from '../src/process-tree.js'

const SUPERVISOR = fileURLToPath(new URL('../src/supervisor-main.js', import.meta.url))

/** @type {import('../src/discovery.js').KernelResolution | undefined} */
let kernel
try {
  kernel = resolveWolframCommand({}, { platform: process.platform, env: process.env })
} catch {
  // No installation on this machine: both suites skip with a reason.
  kernel = undefined
}

const skip = kernel === undefined
  ? 'no Wolfram kernel found on this machine'
  : process.platform === 'win32' ? false : 'the single-process force-kill these cases need is Windows-specific'

/** @type {string[]} */
const createdDirs = []
/** @type {number[]} */
const createdPids = []

after(() => {
  // Only pids this suite itself started are ever touched.
  for (const pid of createdPids) {
    if (isProcessAlive(pid)) terminateProcessTree(pid)
  }
  for (const dir of createdDirs) rmSync(dir, { recursive: true, force: true })
})

/**
 * Wait until a predicate holds or the budget expires.
 * @param {() => boolean} predicate - Condition to wait for.
 * @param {number} [timeoutMs] - Budget.
 * @returns {Promise<boolean>} whether the predicate held in time.
 */
async function waitFor(predicate, timeoutMs = 30_000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (predicate()) return true
    await new Promise(resolve => setTimeout(resolve, 200))
  }
  return predicate()
}

/**
 * Every Wolfram-family pid currently running, for the collateral-damage check.
 * Nothing is ever terminated from this list.
 * @returns {Set<number>} the live pids.
 */
function wolframPids() {
  const script = 'Get-CimInstance Win32_Process | Where-Object { $_.Name -match \'wolfram|Mathematica\' } | '
    + 'ForEach-Object { $_.ProcessId }'
  const result = spawnSync('powershell', ['-NoProfile', '-NonInteractive', '-Command', script], {
    encoding: 'utf8', windowsHide: true, timeout: 60_000,
  })
  return new Set((result.stdout ?? '').split(/\r?\n/).filter(line => /^\d+$/.test(line.trim()))
    .map(line => Number.parseInt(line.trim(), 10)))
}

/**
 * A pid that is certainly not running, standing in for a supervisor that was
 * force-terminated. Scans downward from a high number rather than inventing
 * one, so the record never names a live process.
 * @returns {number} a dead pid.
 */
function deadPid() {
  for (let candidate = 999_000; candidate > 900_000; candidate -= 4) {
    if (!isProcessAlive(candidate)) return candidate
  }
  throw new Error('could not find an unused pid')
}

describe('a hard-killed supervisor leaves no running kernel', { skip }, () => {
  it('closes the kernel\'s stdin, which AgentTools treats as a shutdown signal', async () => {
    const resolved = /** @type {import('../src/discovery.js').KernelResolution} */ (kernel)
    const recordDir = mkdtempSync(join(tmpdir(), 'dsh-wolfram-orphan-'))
    createdDirs.push(recordDir)

    const supervisor = spawn(process.execPath, [
      SUPERVISOR,
      '--command', resolved.command,
      ...AGENT_TOOLS_ARGS.flatMap(arg => ['--arg', arg]),
      '--grace-ms', '1000',
      '--record-dir', recordDir,
    ], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true, env: { ...process.env, MCP_SERVER_NAME: 'WolframLanguage' } })
    const supervisorPid = /** @type {number} */ (supervisor.pid)
    createdPids.push(supervisorPid)

    assert.equal(await waitFor(() => readdirSync(recordDir).length === 1, 20_000), true, 'no record was written')
    const record = JSON.parse(readFileSync(join(recordDir, /** @type {string} */ (readdirSync(recordDir)[0])), 'utf8'))
    const childPid = /** @type {number} */ (record.childPid)
    createdPids.push(childPid)
    assert.equal(record.supervisorPid, supervisorPid)
    assert.equal(await waitFor(() => isProcessAlive(childPid), 30_000), true, 'the Wolfram child never appeared')

    // No /T: the child is not part of the terminated tree, and the supervisor
    // runs no cleanup code at all.
    assert.equal(spawnSync('taskkill', ['/PID', String(supervisorPid), '/F'], { encoding: 'utf8', windowsHide: true }).status, 0)
    assert.equal(await waitFor(() => !isProcessAlive(supervisorPid), 15_000), true, 'the supervisor survived the kill')
    assert.equal(await waitFor(() => !isProcessAlive(childPid), 20_000), true,
      'the kernel outlived its hard-killed supervisor; reclamation is the only thing that would clean it up')
  })
})

describe('reclaiming a real orphaned Wolfram tree', { skip }, () => {
  it('terminates exactly the recorded child and leaves every other Wolfram process running', async () => {
    const resolved = /** @type {import('../src/discovery.js').KernelResolution} */ (kernel)
    const recordDir = mkdtempSync(join(tmpdir(), 'dsh-wolfram-reclaim-'))
    createdDirs.push(recordDir)
    const baseline = wolframPids()

    // The orphan, built directly: a real AgentTools server whose stdin this
    // test holds open, so nothing else can shut it down first.
    const spawnedAtMs = Date.now()
    const orphan = spawn(resolved.command, [...AGENT_TOOLS_ARGS], {
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
      env: { ...process.env, MCP_SERVER_NAME: 'WolframLanguage' },
    })
    const orphanPid = /** @type {number} */ (orphan.pid)
    createdPids.push(orphanPid)
    assert.equal(await waitFor(() => isProcessAlive(orphanPid), 30_000), true)

    // Everything the sweep checks is read back from the live process.
    const identity = readProcessIdentity(orphanPid)
    assert.ok(identity !== undefined, 'the orphan must be identifiable')
    assert.match(identity.commandLine, /StartMCPServer/)
    process.stderr.write(`[live] orphan ${String(orphanPid)}: ${identity.name} created ${String(identity.createdAtMs)}\n`)

    writeRecord(recordDir, { supervisorPid: deadPid(), childPid: orphanPid, command: resolved.command, spawnedAtMs })
    assert.equal(readdirSync(recordDir).length, 1)

    const summary = reclaimOrphans({ directory: recordDir })
    process.stderr.write(`[live] reclaim: ${JSON.stringify(summary)}\n`)
    assert.equal(summary.reclaimed, 1, `expected one reclaim, got ${JSON.stringify(summary)}`)
    assert.equal(await waitFor(() => !isProcessAlive(orphanPid), 20_000), true, 'the orphan survived reclamation')
    assert.equal(readdirSync(recordDir).length, 0, 'the record must be removed after reclamation')

    const survivors = wolframPids()
    const lost = [...baseline].filter(pid => !survivors.has(pid))
    assert.deepEqual(lost, [], `reclamation terminated pre-existing Wolfram process(es): ${lost.join(', ')}`)
  })

  it('refuses to terminate a real Wolfram process whose record does not match it', async () => {
    const resolved = /** @type {import('../src/discovery.js').KernelResolution} */ (kernel)
    const recordDir = mkdtempSync(join(tmpdir(), 'dsh-wolfram-mismatch-'))
    createdDirs.push(recordDir)

    const bystander = spawn(resolved.command, [...AGENT_TOOLS_ARGS], {
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
      env: { ...process.env, MCP_SERVER_NAME: 'WolframLanguage' },
    })
    const bystanderPid = /** @type {number} */ (bystander.pid)
    createdPids.push(bystanderPid)
    assert.equal(await waitFor(() => isProcessAlive(bystanderPid), 30_000), true)

    // Same pid, same executable, same command line — but recorded hours ago,
    // which is exactly the shape of a pid the system has since reused.
    writeRecord(recordDir, {
      supervisorPid: deadPid(),
      childPid: bystanderPid,
      command: resolved.command,
      spawnedAtMs: Date.now() - 6 * 60 * 60 * 1000,
    })

    const summary = reclaimOrphans({ directory: recordDir })
    assert.equal(summary.reclaimed, 0, JSON.stringify(summary))
    assert.match(summary.notes.join('\n'), /did not prove it is the recorded Wolfram child/)
    assert.equal(isProcessAlive(bystanderPid), true, 'an unverified Wolfram process must be left running')

    bystander.stdin?.end()
    await waitFor(() => !isProcessAlive(bystanderPid), 20_000)
    if (isProcessAlive(bystanderPid)) terminateProcessTree(bystanderPid)
  })
})
