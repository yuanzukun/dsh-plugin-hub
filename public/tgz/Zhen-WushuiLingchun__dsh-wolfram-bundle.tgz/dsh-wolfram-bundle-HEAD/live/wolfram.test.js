/**
 * Real Wolfram verification: a full MCP handshake through this package's
 * supervisor against the machine's actual `Wolfram/AgentTools` server.
 *
 * The suite records a process baseline before it starts, so its closing
 * assertion can be stated exactly: every Wolfram process this run created is
 * gone, and every Wolfram process that already existed is untouched.
 *
 * Skips itself when no Wolfram kernel can be discovered, so it stays runnable
 * on a machine without an installation.
 *
 * @module
 */

import assert from 'node:assert/strict'
import { spawn, spawnSync } from 'node:child_process'
import { existsSync, mkdtempSync, readdirSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { after, before, describe, it } from 'node:test'
import { fileURLToPath } from 'node:url'
import { AGENT_TOOLS_ARGS, resolveWolframCommand } from '../src/discovery.js'
import { isProcessAlive, terminateProcessTree } from '../src/process-tree.js'

const SUPERVISOR = fileURLToPath(new URL('../src/supervisor-main.js', import.meta.url))
const MCP_SERVER_NAME = 'WolframLanguage'

/** The seven tools the built-in `WolframLanguage` server publishes. */
const EXPECTED_TOOLS = [
  'CodeInspector',
  'ReadNotebook',
  'SymbolDefinition',
  'TestReport',
  'WolframLanguageContext',
  'WolframLanguageEvaluator',
  'WriteNotebook',
]

/** @type {import('../src/discovery.js').KernelResolution | undefined} */
let kernel
try {
  kernel = resolveWolframCommand({}, { platform: process.platform, env: process.env })
} catch {
  // No installation on this machine: every case below skips with a reason.
  kernel = undefined
}

/**
 * Every Wolfram-family process currently running, as pid to command line.
 * Reads the process table directly rather than matching on names for any
 * purpose other than reporting: nothing here is ever terminated by name.
 * @returns {Map<number, string>} pid to command line.
 */
function wolframProcessSnapshot() {
  const windowsInterop = process.platform === 'linux'
    && process.env.WSL_INTEROP !== undefined
    && kernel !== undefined
    && /\.exe$/i.test(kernel.command)
  if (windowsInterop) {
    // WSL's `ps` only sees the short-lived interop relay, not every Windows
    // Wolfram process that the relay could affect.  Query the host process
    // table so the preservation assertion covers pre-existing notebook/MCP
    // kernels on the Windows side as well.
    const script = '$OutputEncoding = [Console]::OutputEncoding = [Text.UTF8Encoding]::new(); '
      + 'Get-CimInstance Win32_Process | Where-Object { $_.Name -match \'^(wolfram|WolframKernel|MathKernel)(\\.exe)?$\' } | '
      + 'ForEach-Object { "$($_.ProcessId)`t$($_.Name)`t$($_.CommandLine)" }'
    const powershell = process.env.DSH_WOLFRAM_HOST_POWERSHELL
      ?? ['/mnt/c/Program Files/PowerShell/7/pwsh.exe', '/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe']
        .find(candidate => existsSync(candidate))
    assert.notEqual(powershell, undefined, 'WSL host PowerShell was not found for process-preservation evidence')
    const result = spawnSync(/** @type {string} */ (powershell), ['-NoProfile', '-NonInteractive', '-Command', script], {
      encoding: 'utf8', windowsHide: true, timeout: 60_000,
    })
    /** @type {Map<number, string>} */
    const found = new Map()
    assert.equal(result.status, 0, `host Wolfram process snapshot failed: ${String(result.stderr ?? result.error ?? '')}`)
    for (const line of (result.stdout ?? '').split(/\r?\n/)) {
      const [pid, ...rest] = line.split('\t')
      if (pid !== undefined && /^\d+$/.test(pid)) found.set(Number.parseInt(pid, 10), rest.join('\t'))
    }
    return found
  }
  if (process.platform !== 'win32') {
    // Match the executable name, never an arbitrary command-line substring.
    // The latter incorrectly counts this test runner, its shell, and timeout
    // wrappers merely because their argv contains the repository path
    // `dsh-wolfram`.  WSL exposes an interop-launched Windows kernel with a
    // `wolfram.exe` comm value, while native Linux installations use
    // WolframKernel/MathKernel.
    const result = spawnSync('ps', ['-eo', 'pid=,comm=,args='], { encoding: 'utf8' })
    /** @type {Map<number, string>} */
    const found = new Map()
    for (const line of (result.stdout ?? '').split('\n')) {
      const match = /^\s*(\d+)\s+(\S+)\s+(.*)$/.exec(line)
      if (match !== null && /^(?:wolfram|wolframkernel|mathkernel)(?:\.exe)?$/i.test(/** @type {string} */ (match[2]))) {
        found.set(Number.parseInt(/** @type {string} */ (match[1]), 10), /** @type {string} */ (match[3]))
      }
    }
    return found
  }
  const script = 'Get-CimInstance Win32_Process | Where-Object { $_.Name -match \'wolfram|Mathematica\' } | '
    + 'ForEach-Object { "$($_.ProcessId)`t$($_.Name)`t$($_.CommandLine)" }'
  const result = spawnSync('powershell', ['-NoProfile', '-NonInteractive', '-Command', script], {
    encoding: 'utf8', windowsHide: true, timeout: 60_000,
  })
  /** @type {Map<number, string>} */
  const found = new Map()
  for (const line of (result.stdout ?? '').split(/\r?\n/)) {
    const [pid, ...rest] = line.split('\t')
    if (pid !== undefined && /^\d+$/.test(pid)) found.set(Number.parseInt(pid, 10), rest.join('\t'))
  }
  return found
}

/** A live JSON-RPC conversation with the server, through the supervisor. */
/**
 * @typedef {object} Session
 * @property {import('node:child_process').ChildProcess} proc The supervisor process.
 * @property {(method: string, params?: unknown) => Promise<Record<string, unknown>>} request Sends one request and awaits its response.
 * @property {(method: string, params?: unknown) => void} notify Sends one notification.
 * @property {() => string} stderr Diagnostics seen so far.
 * @property {Promise<number>} exited Settles with the supervisor's exit code.
 * @property {string} recordDir The supervisor's record directory.
 */

/**
 * Open a supervised MCP session over the real Wolfram kernel.
 * @param {import('../src/discovery.js').KernelResolution} resolved - The discovered kernel.
 * @returns {Session} the live session.
 */
function openSession(resolved) {
  const recordDir = mkdtempSync(join(tmpdir(), 'dsh-wolfram-live-'))
  const windowsInterop = process.platform === 'linux' && /\.exe$/i.test(resolved.command)
  const wslEnvParts = String(process.env.WSLENV ?? '').split(':').filter(Boolean)
  if (windowsInterop && !wslEnvParts.includes('MCP_SERVER_NAME/w')) wslEnvParts.push('MCP_SERVER_NAME/w')
  const proc = spawn(process.execPath, [
    SUPERVISOR,
    '--command', resolved.command,
    ...AGENT_TOOLS_ARGS.flatMap(arg => ['--arg', arg]),
    '--grace-ms', '1000',
    '--record-dir', recordDir,
  ], {
    stdio: ['pipe', 'pipe', 'pipe'],
    windowsHide: true,
    env: {
      ...process.env,
      MCP_SERVER_NAME,
      ...windowsInterop ? { WSLENV: wslEnvParts.join(':') } : {},
    },
  })

  let nextId = 1
  let buffer = ''
  let stderrText = ''
  /** @type {Map<number, { resolve: (value: Record<string, unknown>) => void; reject: (reason: Error) => void }>} */
  const pending = new Map()

  proc.stdout.setEncoding('utf8')
  proc.stdout.on('data', chunk => {
    buffer += chunk
    let newline = buffer.indexOf('\n')
    while (newline !== -1) {
      const line = buffer.slice(0, newline).trim()
      buffer = buffer.slice(newline + 1)
      newline = buffer.indexOf('\n')
      if (line === '') continue
      /** @type {Record<string, unknown>} */
      let message
      try {
        message = JSON.parse(line)
      } catch {
        // A non-JSON line on stdout would be a transparency failure; surface
        // it against the waiting request rather than silently dropping it.
        for (const waiter of pending.values()) waiter.reject(new Error(`non-JSON line on stdout: ${line}`))
        pending.clear()
        continue
      }
      const id = /** @type {number | undefined} */ (message.id)
      if (id === undefined) continue
      const waiter = pending.get(id)
      if (waiter !== undefined) {
        pending.delete(id)
        waiter.resolve(message)
      }
    }
  })
  proc.stderr.setEncoding('utf8')
  proc.stderr.on('data', chunk => { stderrText += chunk })

  const exited = /** @type {Promise<number>} */ (new Promise(resolve => {
    proc.once('exit', code => {
      for (const waiter of pending.values()) waiter.reject(new Error('supervisor exited while a request was pending'))
      pending.clear()
      resolve(code ?? -1)
    })
  }))

  /** @type {(method: string, params?: unknown) => void} */
  const notify = (method, params) => {
    proc.stdin?.write(`${JSON.stringify({ jsonrpc: '2.0', method, ...params === undefined ? {} : { params } })}\n`)
  }

  return {
    proc,
    notify,
    stderr: () => stderrText,
    exited,
    recordDir,
    request: (method, params) => {
      const id = nextId
      nextId += 1
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          pending.delete(id)
          reject(new Error(`${method} timed out after 180s; stderr:\n${stderrText}`))
        }, 180_000)
        pending.set(id, {
          resolve: message => { clearTimeout(timer); resolve(message) },
          reject: reason => { clearTimeout(timer); reject(reason) },
        })
        proc.stdin?.write(`${JSON.stringify({ jsonrpc: '2.0', id, method, ...params === undefined ? {} : { params } })}\n`)
      })
    },
  }
}

/**
 * Wait until a predicate holds or the budget expires.
 * @param {() => boolean} predicate - Condition to wait for.
 * @param {number} [timeoutMs] - Budget.
 * @returns {Promise<boolean>} whether the predicate held in time.
 */
async function waitFor(predicate, timeoutMs = 30_000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (predicate()) return true
    await new Promise(resolve => setTimeout(resolve, 200))
  }
  return predicate()
}

/** Wolfram processes that existed before this run; none of them may be disturbed. */
/** @type {Map<number, string>} */
let baseline = new Map()
/** @type {Session | undefined} */
let session
/** @type {Record<string, unknown> | undefined} */
let initializeResult
/** @type {{ name: string }[]} */
let tools = []
/** @type {Record<string, unknown> | undefined} */
let evaluation

before(async () => {
  if (kernel === undefined) return
  baseline = wolframProcessSnapshot()
  process.stderr.write(`[live] baseline: ${String(baseline.size)} Wolfram process(es) already running\n`)
  process.stderr.write(`[live] kernel: ${kernel.command} (via ${kernel.source})\n`)

  session = openSession(kernel)
  const initialize = await session.request('initialize', {
    protocolVersion: '2025-06-18',
    capabilities: {},
    clientInfo: { name: 'dsh-wolfram-live-test', version: '0.1.0' },
  })
  initializeResult = /** @type {Record<string, unknown>} */ (initialize.result)
  session.notify('notifications/initialized')

  const listed = await session.request('tools/list')
  tools = /** @type {{ name: string }[]} */ (
    /** @type {Record<string, unknown>} */ (listed.result).tools
  )

  // A pure arithmetic evaluation: no file, process, or network side effect.
  const called = await session.request('tools/call', {
    name: 'WolframLanguageEvaluator',
    arguments: { code: 'Total[Range[100]]' },
  })
  evaluation = /** @type {Record<string, unknown>} */ (called.result)
})

after(() => {
  // Only ever this suite's own supervisor and its recorded tree.
  if (session !== undefined) {
    const pid = session.proc.pid
    if (pid !== undefined && isProcessAlive(pid)) terminateProcessTree(pid)
    rmSync(session.recordDir, { recursive: true, force: true })
  }
})

describe('real Wolfram MCP server', { skip: kernel === undefined ? 'no Wolfram kernel found on this machine' : false }, () => {
  it('completes the initialize handshake', () => {
    assert.ok(initializeResult !== undefined, 'initialize returned no result')
    assert.equal(typeof initializeResult.protocolVersion, 'string')
    const serverInfo = /** @type {{ name?: string; version?: string }} */ (initializeResult.serverInfo)
    assert.equal(typeof serverInfo.name, 'string')
    process.stderr.write(`[live] server: ${String(serverInfo.name)} ${String(serverInfo.version)}\n`)
  })

  it('lists exactly the WolframLanguage server tool set', () => {
    const names = tools.map(tool => tool.name).sort()
    assert.deepEqual(names, EXPECTED_TOOLS)
  })

  it('returns the right answer for a side-effect-free evaluation', () => {
    assert.ok(evaluation !== undefined, 'tools/call returned no result')
    assert.notEqual(evaluation.isError, true, JSON.stringify(evaluation))
    const rendered = JSON.stringify(evaluation)
    // Total[Range[100]] is 5050; anything else means the kernel did not run it.
    assert.match(rendered, /5050/, rendered.slice(0, 500))
  })

  it('carried every byte through the supervisor without protocol corruption', () => {
    // A framing or encoding fault would have surfaced as a parse failure in
    // the reader; reaching a correct evaluation proves the round trip.
    assert.ok(tools.length > 0)
    assert.doesNotMatch(/** @type {Session} */ (session).stderr(), /non-JSON line on stdout/)
  })
})

describe('shutdown leaves no trace', { skip: kernel === undefined ? 'no Wolfram kernel found on this machine' : false }, () => {
  it('exits cleanly when the client closes stdin', async () => {
    const live = /** @type {Session} */ (session)
    live.proc.stdin?.end()
    const code = await live.exited
    assert.equal(code, 0, `supervisor exited ${String(code)}; stderr:\n${live.stderr()}`)
  })

  it('removes its own record', async () => {
    const live = /** @type {Session} */ (session)
    assert.equal(await waitFor(() => readdirSync(live.recordDir).length === 0, 10_000), true)
  })

  it('leaves no Wolfram process this run started', async () => {
    assert.equal(await waitFor(() => {
      const now = wolframProcessSnapshot()
      return [...now.keys()].every(pid => baseline.has(pid))
    }, 30_000), true, 'a Wolfram process created by this run is still running')
  })

  it('leaves every pre-existing Wolfram process untouched', () => {
    const now = wolframProcessSnapshot()
    /** @type {number[]} */
    const missing = []
    for (const pid of baseline.keys()) {
      if (!now.has(pid)) missing.push(pid)
    }
    assert.deepEqual(missing, [], `this run terminated pre-existing Wolfram process(es): ${missing.join(', ')}`)
  })
})
