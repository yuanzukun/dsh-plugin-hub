/**
 * A process that stays alive until it is terminated.
 *
 * Used as a grandchild in process-tree tests and as the unrelated control
 * process that must survive every termination the tests perform.
 *
 * @module
 */

process.stdout.write(`sleeper ${String(process.pid)} ready\n`)
// A long, referenced timer is the only thing holding the loop open, so the
// process exits promptly once it is terminated.
setTimeout(() => { process.exit(0) }, 10 * 60 * 1000)
