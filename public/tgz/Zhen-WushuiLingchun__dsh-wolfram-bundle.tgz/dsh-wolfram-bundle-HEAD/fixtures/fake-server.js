/**
 * A stand-in for the Wolfram MCP server, exercising the supervisor's stdio and
 * lifecycle contracts without needing a Wolfram installation.
 *
 * Modes:
 * - `echo` (default): writes every received byte straight back to stdout and
 *   exits on stdin EOF, the way AgentTools' read loop does.
 * - `wedged`: reads nothing and never exits, standing in for a kernel busy
 *   inside a long evaluation when the client disconnects.
 * - `tree`: spawns grandchildren, reports their pids on stderr, then behaves
 *   like `wedged`.
 *
 * `--exit-code <n>` sets the code reported on a clean stdin-EOF shutdown.
 *
 * @module
 */

import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const argv = process.argv.slice(2)

/**
 * Read one `--flag value` pair.
 * @param {string} flag - Flag name.
 * @param {string} fallback - Value when the flag is absent.
 * @returns {string} the flag's value.
 */
function option(flag, fallback) {
  const index = argv.indexOf(flag)
  return index === -1 ? fallback : argv[index + 1] ?? fallback
}

const mode = option('--mode', 'echo')
const exitCode = Number.parseInt(option('--exit-code', '0'), 10)
const grandchildCount = Number.parseInt(option('--grandchildren', '2'), 10)

if (mode === 'tree') {
  const sleeper = fileURLToPath(new URL('./sleeper.js', import.meta.url))
  for (let index = 0; index < grandchildCount; index += 1) {
    const child = spawn(process.execPath, [sleeper], { stdio: ['ignore', 'ignore', 'ignore'], windowsHide: true })
    process.stderr.write(`grandchild ${String(child.pid)}\n`)
  }
}

if (mode === 'echo') {
  process.stdin.pipe(process.stdout)
  process.stdin.on('end', () => { process.exit(exitCode) })
} else {
  // Wedged: stdin is never read, so EOF is never observed and only a
  // process-tree termination can end this process.
  setTimeout(() => { process.exit(0) }, 10 * 60 * 1000)
}

process.stderr.write(`fake-server ${String(process.pid)} mode=${mode} ready\n`)
