/**
 * Permission classification: every tool of the WolframLanguage server, the
 * fail-safe branch for anything unlisted, and the configuration errors that
 * must be rejected at load.
 *
 * @module
 */

import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import {
  classifyToolCall,
  DEFAULT_ASK_TOOLS,
  DEFAULT_DELEGATE_TOOLS,
  resolveClassification,
} from '../src/classify.js'

/** The seven tools the built-in `WolframLanguage` server publishes. */
const WOLFRAM_LANGUAGE_SERVER_TOOLS = [
  'WolframLanguageContext',
  'WolframLanguageEvaluator',
  'ReadNotebook',
  'WriteNotebook',
  'SymbolDefinition',
  'CodeInspector',
  'TestReport',
]

const table = resolveClassification({ serverName: 'wolfram' })

describe('classification of the WolframLanguage server surface', () => {
  it('classifies every published tool without falling back', () => {
    for (const raw of WOLFRAM_LANGUAGE_SERVER_TOOLS) {
      const verdict = classifyToolCall(`mcp__wolfram__${raw}`, table)
      const known = Object.hasOwn(DEFAULT_ASK_TOOLS, raw) || DEFAULT_DELEGATE_TOOLS.includes(raw)
      assert.equal(known, true, `${raw} is unclassified`)
      assert.ok(['ask', 'delegate'].includes(verdict.decision))
    }
  })

  it('requires approval for the side-effecting tools', () => {
    for (const raw of ['WolframLanguageEvaluator', 'TestReport', 'WriteNotebook', 'ReadNotebook', 'CodeInspector']) {
      const verdict = classifyToolCall(`mcp__wolfram__${raw}`, table)
      assert.equal(verdict.decision, 'ask', `${raw} must ask`)
      assert.equal(verdict.rawName, raw)
      assert.match(/** @type {string} */ (verdict.reason), new RegExp(`^Wolfram ${raw} `))
    }
  })

  it('delegates the read-only metadata tools to the rest of the chain', () => {
    for (const raw of ['WolframLanguageContext', 'SymbolDefinition']) {
      assert.deepEqual(classifyToolCall(`mcp__wolfram__${raw}`, table), { decision: 'delegate' })
    }
  })
})

describe('fail-safe behavior', () => {
  it('asks for a Wolfram tool the table has never seen', () => {
    const verdict = classifyToolCall('mcp__wolfram__SomeFuturePacletTool', table)
    assert.equal(verdict.decision, 'ask')
    assert.equal(verdict.rawName, 'SomeFuturePacletTool')
    assert.match(/** @type {string} */ (verdict.reason), /not in this deployment's Wolfram tool classification/)
  })

  it('asks when name normalization made the raw name unrecognizable', () => {
    // mcp-client appends a hash when it must normalize a public name; the
    // classification must not silently downgrade such a tool.
    const verdict = classifyToolCall('mcp__wolfram__WolframLanguageEvalua_a1b2c3d4e5f6', table)
    assert.equal(verdict.decision, 'ask')
  })

  it('asks for a bare prefix with no raw name', () => {
    assert.equal(classifyToolCall('mcp__wolfram__', table).decision, 'ask')
  })

  it('can be configured to deny unlisted tools instead', () => {
    const denying = resolveClassification({ serverName: 'wolfram', unknown: 'deny' })
    assert.equal(classifyToolCall('mcp__wolfram__Unlisted', denying).decision, 'deny')
    // Known classifications are unaffected by the unknown-tool policy.
    assert.equal(classifyToolCall('mcp__wolfram__SymbolDefinition', denying).decision, 'delegate')
  })
})

describe('namespace ownership', () => {
  it('never claims a tool outside its own server namespace', () => {
    for (const name of [
      'bash',
      'read_file',
      'mcp__github__create_issue',
      'mcp__wolfram2__WolframLanguageEvaluator',
      'wolfram__WolframLanguageEvaluator',
    ]) {
      assert.deepEqual(classifyToolCall(name, table), { decision: 'delegate' }, name)
    }
  })

  it('follows a configured serverName', () => {
    const other = resolveClassification({ serverName: 'wl' })
    assert.equal(classifyToolCall('mcp__wl__WolframLanguageEvaluator', other).decision, 'ask')
    assert.equal(classifyToolCall('mcp__wolfram__WolframLanguageEvaluator', other).decision, 'delegate')
  })
})

describe('configuration validation', () => {
  it('rejects a tool listed as both ask and delegate', () => {
    assert.throws(
      () => resolveClassification({ serverName: 'wolfram', delegate: ['WolframLanguageEvaluator'] }),
      /listed as both ask and delegate/,
    )
  })

  it('rejects an unusable serverName', () => {
    for (const serverName of ['', 'has space', 'a'.repeat(33), 'dots.not.allowed']) {
      assert.throws(() => resolveClassification({ serverName }), /serverName must match/)
    }
  })

  it('rejects an unknown-tool decision outside the vocabulary', () => {
    assert.throws(
      () => resolveClassification({ serverName: 'wolfram', unknown: /** @type {'ask'} */ ('allow') }),
      /must be "ask" or "deny"/,
    )
  })

  it('merges additionalAsk over the defaults without dropping them', () => {
    const extended = resolveClassification({ serverName: 'wolfram', additionalAsk: { NewTool: 'does something new' } })
    assert.equal(classifyToolCall('mcp__wolfram__NewTool', extended).decision, 'ask')
    assert.equal(classifyToolCall('mcp__wolfram__WolframLanguageEvaluator', extended).decision, 'ask')
    assert.equal(classifyToolCall('mcp__wolfram__SymbolDefinition', extended).decision, 'delegate')
  })

  it('lets a deployment replace the ask table wholesale', () => {
    const replaced = resolveClassification({ serverName: 'wolfram', ask: { OnlyThis: 'reason' }, delegate: [] })
    assert.equal(classifyToolCall('mcp__wolfram__OnlyThis', replaced).decision, 'ask')
    // A tool dropped from the table is unlisted, not allowed: it still asks.
    assert.equal(classifyToolCall('mcp__wolfram__SymbolDefinition', replaced).decision, 'ask')
  })
})
