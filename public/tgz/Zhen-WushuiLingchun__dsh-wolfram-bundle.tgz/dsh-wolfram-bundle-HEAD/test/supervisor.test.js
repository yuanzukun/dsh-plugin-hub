/**
 * The stdio supervisor, driven as a real subprocess.
 *
 * Covers the two contracts a JSON-RPC transport depends on — byte-exact
 * passthrough and a stdout stream that carries nothing but protocol bytes —
 * and the lifecycle contracts that keep Wolfram processes from leaking:
 * shutdown on EOF, forced tree termination for a wedged child, and exit-code
 * propagation.
 *
 * @module
 */

import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { mkdtempSync, readdirSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { after, describe, it } from 'node:test'
import { fileURLToPath } from 'node:url'
import { isProcessAlive, terminateProcessTree } from '../src/process-tree.js'
import { DEFAULT_GRACE_MS, MAX_GRACE_MS, parseSupervisorArgs } from '../src/supervisor.js'

const SUPERVISOR = fileURLToPath(new URL('../src/supervisor-main.js', import.meta.url))
const FAKE_SERVER = fileURLToPath(new URL('../fixtures/fake-server.js', import.meta.url))
const SLEEPER = fileURLToPath(new URL('../fixtures/sleeper.js', import.meta.url))

/** Everything this suite created, cleaned up even when an assertion fails. */
/** @type {Set<number>} */
const createdPids = new Set()
/** @type {Set<import('node:child_process').ChildProcess>} */
const createdProcesses = new Set()
/** @type {string[]} */
const createdDirs = []

after(() => {
  for (const pid of createdPids) {
    if (isProcessAlive(pid)) terminateProcessTree(pid)
  }
  for (const child of createdProcesses) {
    child.stdin?.destroy()
    child.stdout?.destroy()
    child.stderr?.destroy()
    child.removeAllListeners()
    child.unref()
  }
  for (const dir of createdDirs) rmSync(dir, { recursive: true, force: true })
})

/** A running supervisor under test. */
/**
 * @typedef {object} Harness
 * @property {import('node:child_process').ChildProcess} proc The supervisor process.
 * @property {NodeJS.WritableStream} stdin The supervisor's stdin, i.e. what an MCP client would write to.
 * @property {() => string} stdout Everything the supervisor wrote to stdout so far.
 * @property {() => string} stderr Everything the supervisor wrote to stderr so far.
 * @property {Promise<number>} exited Settles with the supervisor's exit code.
 * @property {Promise<number>} serverPid Settles with the fake server's own pid.
 * @property {string} [recordDir] The record directory, when one was requested.
 */

/**
 * Start the supervisor over the fake server.
 * @param {object} options - Harness options.
 * @param {readonly string[]} [options.serverArgs] - Arguments for the fake server.
 * @param {number} [options.graceMs] - Supervisor grace period.
 * @param {boolean} [options.record] - Whether to give the supervisor a record directory.
 * @returns {Harness} the running supervisor.
 */
function startSupervisor(options = {}) {
  const recordDir = options.record === true ? mkdtempSync(join(tmpdir(), 'dsh-wolfram-test-')) : undefined
  if (recordDir !== undefined) createdDirs.push(recordDir)
  const proc = spawn(process.execPath, [
    SUPERVISOR,
    '--command', process.execPath,
    '--arg', FAKE_SERVER,
    ...(options.serverArgs ?? []).flatMap(arg => ['--arg', arg]),
    '--grace-ms', String(options.graceMs ?? DEFAULT_GRACE_MS),
    ...recordDir === undefined ? [] : ['--record-dir', recordDir],
  ], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true })
  createdProcesses.add(proc)
  if (proc.pid !== undefined) createdPids.add(proc.pid)

  /** @type {Buffer[]} */
  const outChunks = []
  let errText = ''
  proc.stdout.on('data', chunk => outChunks.push(chunk))
  proc.stderr.setEncoding('utf8')
  /** @type {(pid: number) => void} */
  let resolveServerPid = () => {}
  const serverPid = /** @type {Promise<number>} */ (new Promise(resolve => { resolveServerPid = resolve }))
  proc.stderr.on('data', chunk => {
    errText += chunk
    const match = /fake-server (\d+) /.exec(errText)
    if (match !== null) {
      const pid = Number.parseInt(/** @type {string} */ (match[1]), 10)
      createdPids.add(pid)
      resolveServerPid(pid)
    }
  })
  const exited = /** @type {Promise<number>} */ (new Promise(resolve => {
    proc.once('exit', code => resolve(code ?? -1))
  }))
  return {
    proc,
    stdin: /** @type {NodeJS.WritableStream} */ (proc.stdin),
    stdout: () => Buffer.concat(outChunks).toString('utf8'),
    stderr: () => errText,
    exited,
    serverPid,
    ...recordDir === undefined ? {} : { recordDir },
  }
}

/**
 * Wait until a predicate holds or the budget expires.
 * @param {() => boolean} predicate - Condition to wait for.
 * @param {number} [timeoutMs] - Budget.
 * @returns {Promise<boolean>} whether the predicate held in time.
 */
async function waitFor(predicate, timeoutMs = 15_000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (predicate()) return true
    await new Promise(resolve => setTimeout(resolve, 50))
  }
  return predicate()
}

describe('argument parsing', () => {
  it('collects repeated --arg values in order', () => {
    const spec = parseSupervisorArgs(['--command', 'wolfram', '--arg', '-run', '--arg', 'Expr[]', '--arg', '-noinit'])
    assert.equal(spec.command, 'wolfram')
    assert.deepEqual([...spec.args], ['-run', 'Expr[]', '-noinit'])
    assert.equal(spec.graceMs, DEFAULT_GRACE_MS)
  })

  it('requires a command', () => {
    assert.throws(() => parseSupervisorArgs(['--grace-ms', '100']), /--command is required/)
  })

  it('rejects an unknown flag rather than ignoring it', () => {
    assert.throws(() => parseSupervisorArgs(['--command', 'x', '--nope']), /unknown argument "--nope"/)
  })

  it('rejects a grace period that would outlive the SDK force-kill deadline', () => {
    assert.throws(
      () => parseSupervisorArgs(['--command', 'x', '--grace-ms', String(MAX_GRACE_MS + 1)]),
      /skip process-tree cleanup entirely/,
    )
    assert.throws(() => parseSupervisorArgs(['--command', 'x', '--grace-ms', '0']), /must be an integer in 1\.\./)
  })
})

describe('stdio transparency', () => {
  it('forwards bytes unchanged in both directions', async () => {
    const harness = startSupervisor()
    await harness.serverPid
    // A payload that would break any line-oriented or text-normalizing relay:
    // embedded CR, LF, a lone CR, NUL, and multi-byte UTF-8.
    const payload = [
      '{"jsonrpc":"2.0","id":1,"method":"initialize"}\n',
      '{"jsonrpc":"2.0","id":2,"method":"tools/list"}\r\n',
    'partial-without-newline\rmid-cr\0nulé中文',
      '\n',
      `${'x'.repeat(200_000)}\n`,
    ].join('')
    harness.stdin.write(payload)
    assert.equal(await waitFor(() => harness.stdout().length >= payload.length), true, 'echo did not arrive')
    assert.equal(harness.stdout(), payload, 'stdout must be byte-identical to what was sent')
    harness.stdin.end()
    await harness.exited
  })

  it('keeps every diagnostic off stdout', async () => {
    const harness = startSupervisor()
    await harness.serverPid
    harness.stdin.end()
    await harness.exited
    assert.equal(harness.stdout(), '', 'stdout must carry protocol bytes only')
    assert.match(harness.stderr(), /\[dsh-wolfram-supervisor\] shutting down \(client closed stdin\)/)
    assert.match(harness.stderr(), /fake-server \d+ mode=echo ready/, 'child stderr must reach the client')
  })
})

describe('lifecycle', () => {
  it('shuts the child down cleanly when the client closes stdin', async () => {
    const harness = startSupervisor()
    const serverPid = await harness.serverPid
    harness.stdin.end()
    assert.equal(await harness.exited, 0)
    assert.equal(await waitFor(() => !isProcessAlive(serverPid)), true, 'the server must exit on stdin EOF')
    // The clean path never needs the forced termination step.
    assert.doesNotMatch(harness.stderr(), /terminating process tree/)
  })

  it('propagates the child\'s exit code', async () => {
    const harness = startSupervisor({ serverArgs: ['--exit-code', '3'] })
    await harness.serverPid
    harness.stdin.end()
    assert.equal(await harness.exited, 3)
  })

  it('reports a child that could not be started', async () => {
    const proc = spawn(process.execPath, [SUPERVISOR, '--command', 'definitely-not-an-executable-4f2a'], {
      stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true,
    })
    createdProcesses.add(proc)
    if (proc.pid !== undefined) createdPids.add(proc.pid)
    let stderr = ''
    proc.stderr.setEncoding('utf8')
    proc.stderr.on('data', chunk => { stderr += chunk })
    const code = await new Promise(resolve => proc.once('exit', resolved => resolve(resolved)))
    assert.equal(code, 127)
    assert.match(stderr, /failed to start definitely-not-an-executable-4f2a/)
  })

  it('rejects its own bad arguments before spawning anything', async () => {
    const proc = spawn(process.execPath, [SUPERVISOR, '--grace-ms', '5'], {
      stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true,
    })
    createdProcesses.add(proc)
    if (proc.pid !== undefined) createdPids.add(proc.pid)
    const code = await new Promise(resolve => proc.once('exit', resolved => resolve(resolved)))
    assert.equal(code, 64)
  })
})

describe('forced termination of a wedged child', () => {
  it('terminates the tree after the grace period and leaves other processes alone', async () => {
    const control = spawn(process.execPath, [SLEEPER], { stdio: 'ignore', windowsHide: true })
    createdProcesses.add(control)
    if (control.pid !== undefined) createdPids.add(control.pid)
    const harness = startSupervisor({ serverArgs: ['--mode', 'tree', '--grandchildren', '2'], graceMs: 300 })
    const serverPid = await harness.serverPid
    assert.equal(await waitFor(() => /grandchild \d+/.test(harness.stderr())), true)
    const grandchildren = [...harness.stderr().matchAll(/grandchild (\d+)/g)]
      .map(match => Number.parseInt(/** @type {string} */ (match[1]), 10))
    for (const pid of grandchildren) createdPids.add(pid)
    assert.equal(grandchildren.length, 2)

    harness.stdin.end()
    await harness.exited
    assert.match(harness.stderr(), new RegExp(`terminating process tree of pid ${String(serverPid)}`))
    for (const pid of [serverPid, ...grandchildren]) {
      assert.equal(await waitFor(() => !isProcessAlive(pid)), true, `pid ${String(pid)} survived`)
    }
    assert.equal(isProcessAlive(/** @type {number} */ (control.pid)), true, 'an unrelated process must survive')
    terminateProcessTree(/** @type {number} */ (control.pid))
  })

  it('finishes forced cleanup well inside the SDK\'s 2000ms force-kill deadline', async () => {
    const harness = startSupervisor({ serverArgs: ['--mode', 'wedged'], graceMs: DEFAULT_GRACE_MS })
    const serverPid = await harness.serverPid
    const started = Date.now()
    harness.stdin.end()
    await harness.exited
    const elapsed = Date.now() - started
    assert.equal(await waitFor(() => !isProcessAlive(serverPid)), true)
    // The SDK sends SIGTERM 2000ms after ending stdin; cleanup that finishes
    // later would simply never run.
    assert.ok(elapsed < 2_000, `forced cleanup took ${String(elapsed)}ms, which the SDK would have cut short`)
  })
})

describe('orphan records', () => {
  it('records the supervised child and removes the record on a clean exit', async () => {
    const harness = startSupervisor({ record: true })
    const recordDir = /** @type {string} */ (harness.recordDir)
    await harness.serverPid
    assert.equal(await waitFor(() => readdirSync(recordDir).length === 1, 5_000), true, 'no record was written')
    harness.stdin.end()
    await harness.exited
    assert.equal(await waitFor(() => readdirSync(recordDir).length === 0, 5_000), true, 'the record outlived the child')
  })

  it('removes the record after a forced termination too', async () => {
    const harness = startSupervisor({ serverArgs: ['--mode', 'wedged'], graceMs: 300, record: true })
    const recordDir = /** @type {string} */ (harness.recordDir)
    await harness.serverPid
    await waitFor(() => readdirSync(recordDir).length === 1, 5_000)
    harness.stdin.end()
    await harness.exited
    assert.equal(await waitFor(() => readdirSync(recordDir).length === 0, 5_000), true)
  })
})
