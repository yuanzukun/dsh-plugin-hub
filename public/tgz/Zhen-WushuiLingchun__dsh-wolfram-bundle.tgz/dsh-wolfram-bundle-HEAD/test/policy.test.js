/**
 * The policy plugin's pre-execute behavior, driven through a stand-in for the
 * harness waterfall: the decision it returns, and the guarantee that it only
 * ever tightens what the rest of the chain decided.
 *
 * @module
 */

import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { apply } from '../src/policy.js'

/**
 * A minimal stand-in for the Cordis context surface the policy uses.
 * @param {Record<string, unknown>} [config] - Row config passed to `apply`.
 * @returns {{ call: (name: string, downstream: import('../types/harness.js').PreToolDecision) =>
 *   Promise<import('../types/harness.js').PreToolDecision>, delegated: string[], logs: string[] }}
 *   a harness for invoking the registered listener.
 */
function mountPolicy(config) {
  /** @type {((exec: { name: string }, next: () => Promise<import('../types/harness.js').PreToolDecision>) => Promise<import('../types/harness.js').PreToolDecision>) | undefined} */
  let listener
  /** @type {string[]} */
  const delegated = []
  /** @type {string[]} */
  const logs = []
  const ctx = /** @type {import('../types/harness.js').HarnessContext} */ (/** @type {unknown} */ ({
    logger: {
      info: (/** @type {string} */ message) => logs.push(message),
      warn: (/** @type {string} */ message) => logs.push(message),
      error: (/** @type {string} */ message) => logs.push(message),
    },
    effect: () => {},
    plugin: () => { throw new Error('the policy plugin mounts no children') },
    on: (/** @type {string} */ event, /** @type {typeof listener} */ registered) => {
      assert.equal(event, 'tools/pre-execute')
      listener = registered
      return () => {}
    },
  }))
  apply(ctx, config)
  assert.ok(listener !== undefined, 'apply must register a tools/pre-execute listener')
  const registered = listener
  return {
    delegated,
    logs,
    call: async (name, downstream) => registered({ name }, async () => {
      delegated.push(name)
      return downstream
    }),
  }
}

describe('policy decisions', () => {
  it('upgrades an allowed high-risk Wolfram call to ask', async () => {
    const policy = mountPolicy()
    const decision = await policy.call('mcp__wolfram__WolframLanguageEvaluator', { kind: 'allow' })
    assert.equal(decision.kind, 'ask')
    assert.match(/** @type {string} */ (decision.reason), /unsandboxed kernel/)
  })

  it('delegates read-only metadata calls unchanged', async () => {
    const policy = mountPolicy()
    assert.deepEqual(await policy.call('mcp__wolfram__SymbolDefinition', { kind: 'allow' }), { kind: 'allow' })
    assert.deepEqual(policy.delegated, ['mcp__wolfram__SymbolDefinition'])
  })

  it('leaves foreign tools entirely to the rest of the chain', async () => {
    const policy = mountPolicy()
    assert.deepEqual(await policy.call('bash', { kind: 'allow' }), { kind: 'allow' })
    assert.deepEqual(policy.delegated, ['bash'])
  })
})

describe('the policy only ever tightens', () => {
  it('runs the rest of the chain before upgrading to ask', async () => {
    const policy = mountPolicy()
    await policy.call('mcp__wolfram__TestReport', { kind: 'allow' })
    assert.deepEqual(policy.delegated, ['mcp__wolfram__TestReport'], 'downstream listeners must still run')
  })

  it('preserves a downstream denial instead of relaxing it to ask', async () => {
    const policy = mountPolicy()
    const decision = await policy.call('mcp__wolfram__WriteNotebook', { kind: 'deny', reason: 'sandbox policy' })
    assert.deepEqual(decision, { kind: 'deny', reason: 'sandbox policy' })
  })

  it('preserves a downstream ask with its own reason', async () => {
    const policy = mountPolicy()
    const decision = await policy.call('mcp__wolfram__ReadNotebook', { kind: 'ask', reason: 'hook policy' })
    assert.deepEqual(decision, { kind: 'ask', reason: 'hook policy' })
  })

  it('short-circuits a denial without consulting the rest of the chain', async () => {
    const policy = mountPolicy({ unknown: 'deny' })
    const decision = await policy.call('mcp__wolfram__Unlisted', { kind: 'allow' })
    assert.equal(decision.kind, 'deny')
    assert.deepEqual(policy.delegated, [], 'a denial is terminal and needs no delegation')
  })
})

describe('plugin load', () => {
  it('reports the effective table so a deployment can verify it', () => {
    const policy = mountPolicy()
    assert.match(policy.logs.join('\n'), /require approval/)
    assert.match(policy.logs.join('\n'), /unlisted mcp__wolfram__\* tools default to ask/)
  })

  it('rejects a contradictory table at load rather than at call time', () => {
    assert.throws(() => mountPolicy({ delegate: ['WolframLanguageEvaluator'] }), /listed as both ask and delegate/)
  })
})
