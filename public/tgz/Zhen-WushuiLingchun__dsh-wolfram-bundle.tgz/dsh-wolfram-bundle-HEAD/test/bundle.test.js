/**
 * The distributed artifact: the bundle manifest the dsh profile launcher
 * reads, the patch layer it composes, and the package contents `npm pack`
 * would ship.
 *
 * @module
 */

import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { describe, it } from 'node:test'
import { fileURLToPath } from 'node:url'
import { parse } from 'yaml'

const root = fileURLToPath(new URL('../', import.meta.url))
const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
const patch = parse(readFileSync(new URL('../cordis.patch.yml', import.meta.url), 'utf8'))

describe('the bundle manifest', () => {
  it('declares the dsh.bundle patch the profile launcher looks for', () => {
    // `loadProfile` fails loud on a listed bundle without this declaration.
    assert.equal(manifest.dsh?.bundle?.patch, './cordis.patch.yml')
    assert.equal(existsSync(new URL('../cordis.patch.yml', import.meta.url)), true)
  })

  it('exports both plugin entry points and the patch file', () => {
    assert.equal(manifest.exports['.'], './src/index.js')
    assert.equal(manifest.exports['./policy'], './src/policy.js')
    assert.equal(manifest.exports['./cordis.patch.yml'], './cordis.patch.yml')
    // The launcher reads the manifest of a resolved bundle directly.
    assert.equal(manifest.exports['./package.json'], './package.json')
  })

  it('takes no runtime dependencies, so nothing has to build on install', () => {
    assert.equal(manifest.dependencies, undefined)
    assert.equal(manifest.scripts.prepare, undefined, 'a prepare script would be blocked by pnpm >= 10 on install')
    assert.equal(manifest.type, 'module')
  })

  it('declares the harness packages it imports as peers', () => {
    assert.ok(Object.hasOwn(manifest.peerDependencies, '@deepseek-ai/dsh-mcp-client'))
    assert.ok(Object.hasOwn(manifest.peerDependencies, '@deepseek-ai/cordis'))
  })

  it('marks host-provided peers optional so profile installs do not emit false missing-peer warnings', () => {
    for (const packageName of [
      '@deepseek-ai/cordis',
      '@deepseek-ai/dsh-mcp-client',
      '@deepseek-ai/dsh-tools',
    ]) {
      assert.equal(manifest.peerDependenciesMeta[packageName].optional, true)
    }
  })
})

describe('the patch layer', () => {
  it('is a single insert of the two rows, as a patch list', () => {
    assert.ok(Array.isArray(patch), 'a patch file is a top-level YAML array')
    assert.equal(patch.length, 1)
    const rows = patch[0].insert
    assert.deepEqual(rows.map((/** @type {{ id: string }} */ row) => row.id), ['wolfram', 'wolfram-permission'])
  })

  it('mounts this package\'s own plugins by their exported specifiers', () => {
    const rows = patch[0].insert
    assert.equal(rows[0].name, 'dsh-wolfram')
    assert.equal(rows[1].name, 'dsh-wolfram/policy')
  })

  it('gives both rows the same serverName, since that is how the policy finds its tools', () => {
    const rows = patch[0].insert
    assert.equal(rows[0].config.serverName, rows[1].config.serverName)
  })

  it('composes to rows the resolvers accept', async () => {
    const { resolveClassification } = await import('../src/classify.js')
    const { resolveWolframSpec } = await import('../src/config.js')
    const [connection, policy] = patch[0].insert
    // The shipped defaults must be valid configuration, not just documentation.
    const spec = resolveWolframSpec({ ...connection.config, command: 'X:\\wolfram.exe' }, {
      platform: 'win32',
      env: { DSH_HOME: 'D:\\home' },
      isFile: () => true,
    })
    assert.equal(spec.mcpServerName, 'WolframLanguage')
    const table = resolveClassification({ serverName: policy.config.serverName, unknown: policy.config.unknown })
    assert.equal(table.prefix, `mcp__${connection.config.serverName}__`)
  })

  it('keeps the grace period inside the SDK force-kill deadline', () => {
    assert.ok(patch[0].insert[0].config.graceMs < 2_000)
  })
})

describe('package contents', () => {
  const npmCandidates = [
    process.env.npm_execpath,
    join(dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js'),
    join(dirname(dirname(process.execPath)), 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js'),
  ].filter(candidate => typeof candidate === 'string' && candidate !== '')
  const npmCli = npmCandidates.find(candidate => existsSync(/** @type {string} */ (candidate)))
  assert.ok(npmCli !== undefined, `npm-cli.js not found in ${npmCandidates.join(', ')}`)
  const packed = JSON.parse(execFileSync(process.execPath, [npmCli, 'pack', '--dry-run', '--json'], {
    cwd: root, encoding: 'utf8',
  }))
  /** @type {string[]} */
  const files = packed[0].files.map((/** @type {{ path: string }} */ file) => file.path)

  it('ships everything the harness loads at runtime', () => {
    for (const required of [
      'package.json',
      'cordis.patch.yml',
      'src/index.js',
      'src/policy.js',
      'src/config.js',
      'src/classify.js',
      'src/discovery.js',
      'src/orphans.js',
      'src/process-tree.js',
      'src/supervisor.js',
      'src/supervisor-main.js',
      'bin/dsh-wolfram-supervisor.js',
      'README.md',
      'LICENSE',
    ]) {
      assert.ok(files.includes(required), `${required} is missing from the package`)
    }
  })

  it('ships no test, fixture, or development files', () => {
    for (const file of files) {
      assert.doesNotMatch(file, /^(test|fixtures|live|compat)\//, `${file} should not be published`)
      assert.doesNotMatch(file, /^(tsconfig\.json|\.npmrc)$/, `${file} should not be published`)
      assert.doesNotMatch(file, /node_modules/, `${file} should not be published`)
    }
  })

  it('ships the design document a reviewer needs', () => {
    assert.ok(files.includes('docs/design.md'))
    assert.ok(files.includes('docs/offline-dependencies.json'))
    assert.ok(files.includes('CHANGELOG.md'))
  })
})
