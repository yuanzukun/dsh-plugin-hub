/**
 * Orphan reclamation.
 *
 * Every case here is about restraint: the sweep may terminate a process only
 * when its supervisor is gone AND the live process proves it is the recorded
 * child. The cases that must NOT terminate anything are the point of the
 * suite.
 *
 * @module
 */

import assert from 'node:assert/strict'
import { mkdtempSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, beforeEach, describe, it } from 'node:test'
import { identityMatchesRecord, reclaimOrphans, writeRecord } from '../src/orphans.js'

const WOLFRAM = 'D:\\mathematica\\Mathematica 15.0\\wolfram.exe'
const COMMAND_LINE = `"${WOLFRAM}" -run PacletSymbol["Wolfram/AgentTools","Wolfram\`AgentTools\`StartMCPServer"][] -noinit -noprompt`

/** @type {string} */
let directory

beforeEach(() => { directory = mkdtempSync(join(tmpdir(), 'dsh-wolfram-orphans-')) })
afterEach(() => { rmSync(directory, { recursive: true, force: true }) })

/**
 * Write one record with the given fields.
 * @param {Partial<import('../src/orphans.js').SupervisorRecord>} [overrides] - Field overrides.
 * @returns {import('../src/orphans.js').SupervisorRecord} the record as written.
 */
function record(overrides = {}) {
  const value = {
    supervisorPid: 4242,
    childPid: 5252,
    command: WOLFRAM,
    spawnedAtMs: Date.now(),
    ...overrides,
  }
  writeRecord(directory, value)
  return { version: 1, ...value }
}

/**
 * Build a sweep whose platform interactions are all recorded rather than real.
 * @param {object} world - The fake world.
 * @param {readonly number[]} world.alive - Pids that are running.
 * @param {Record<number, import('../src/process-tree.js').ProcessIdentity>} [world.identities] - Identity readback.
 * @returns {{ run: () => import('../src/orphans.js').ReclaimSummary, terminated: number[] }} the sweep and its effects.
 */
function sweep(world) {
  /** @type {number[]} */
  const terminated = []
  return {
    terminated,
    run: () => reclaimOrphans({
      directory,
      alive: pid => world.alive.includes(pid),
      identify: pid => world.identities?.[pid],
      terminate: pid => {
        terminated.push(pid)
        return { attempted: true, ok: true, detail: 'terminated (test)' }
      },
    }),
  }
}

/** A live process that matches the standard record. */
const matchingIdentity = {
  pid: 5252,
  name: 'wolfram.exe',
  commandLine: COMMAND_LINE,
  createdAtMs: Date.now(),
}

describe('records the sweep must not act on', () => {
  it('leaves a record whose supervisor is still running completely alone', () => {
    record()
    const { run, terminated } = sweep({ alive: [4242, 5252], identities: { 5252: matchingIdentity } })
    const summary = run()
    assert.deepEqual(terminated, [])
    assert.equal(summary.live, 1)
    assert.equal(summary.reclaimed, 0)
    assert.equal(readdirSync(directory).length, 1, 'a live connection\'s record must survive')
  })

  it('never terminates a live process whose identity cannot be read', () => {
    record()
    const { run, terminated } = sweep({ alive: [5252] })
    const summary = run()
    assert.deepEqual(terminated, [], 'missing evidence must mean no termination')
    assert.equal(summary.reclaimed, 0)
    assert.equal(summary.stale, 1)
    assert.match(summary.notes.join('\n'), /did not prove it is the recorded Wolfram child/)
    assert.equal(readdirSync(directory).length, 0)
  })

  it('never terminates a reused pid running something else', () => {
    record()
    const { run, terminated } = sweep({
      alive: [5252],
      identities: { 5252: { pid: 5252, name: 'node.exe', commandLine: 'node server.js', createdAtMs: Date.now() } },
    })
    run()
    assert.deepEqual(terminated, [])
  })

  it('never terminates another client\'s AgentTools server that reused the pid', () => {
    // Same executable, same command line — only the creation time separates a
    // pid reused hours later from the child this record actually describes.
    record({ spawnedAtMs: Date.now() - 6 * 60 * 60 * 1000 })
    const { run, terminated } = sweep({
      alive: [5252],
      identities: { 5252: { ...matchingIdentity, createdAtMs: Date.now() } },
    })
    run()
    assert.deepEqual(terminated, [], 'a much later creation time rules the process out')
  })

  it('deletes an unreadable record without touching any process', () => {
    writeFileSync(join(directory, 'broken.json'), '{ not json')
    const { run, terminated } = sweep({ alive: [] })
    const summary = run()
    assert.deepEqual(terminated, [])
    assert.equal(summary.stale, 1)
    assert.equal(readdirSync(directory).length, 0)
  })

  it('deletes a record written by a future format version', () => {
    writeFileSync(join(directory, 'future.json'), JSON.stringify({ version: 99, childPid: 5252, supervisorPid: 1 }))
    const { run, terminated } = sweep({ alive: [5252] })
    run()
    assert.deepEqual(terminated, [])
    assert.equal(readdirSync(directory).length, 0)
  })

  it('does nothing at all when no record directory exists', () => {
    const summary = reclaimOrphans({ directory: join(directory, 'absent') })
    assert.deepEqual(summary, { inspected: 0, live: 0, reclaimed: 0, stale: 0, notes: [] })
  })
})

describe('records the sweep does act on', () => {
  it('reclaims a verified orphan whose supervisor is gone', () => {
    record()
    const { run, terminated } = sweep({ alive: [5252], identities: { 5252: matchingIdentity } })
    const summary = run()
    assert.deepEqual(terminated, [5252])
    assert.equal(summary.reclaimed, 1)
    assert.equal(readdirSync(directory).length, 0)
    assert.match(summary.notes.join('\n'), /reclaimed orphaned Wolfram process tree 5252/)
  })

  it('drops a record whose child already exited without terminating anything', () => {
    record()
    const { run, terminated } = sweep({ alive: [] })
    const summary = run()
    assert.deepEqual(terminated, [])
    assert.equal(summary.stale, 1)
    assert.equal(readdirSync(directory).length, 0)
  })
})

describe('identity verification', () => {
  const base = { version: 1, supervisorPid: 1, childPid: 5252, command: WOLFRAM, spawnedAtMs: Date.now() }

  it('accepts the exact child the supervisor started', () => {
    assert.equal(identityMatchesRecord(base, matchingIdentity), true)
  })

  it('rejects a different pid, image, or command line', () => {
    assert.equal(identityMatchesRecord(base, { ...matchingIdentity, pid: 9999 }), false)
    assert.equal(identityMatchesRecord(base, { ...matchingIdentity, name: 'WolframKernel.exe' }), false)
    assert.equal(identityMatchesRecord(base, { ...matchingIdentity, commandLine: `"${WOLFRAM}" -noinit` }), false)
    assert.equal(
      identityMatchesRecord(base, { ...matchingIdentity, commandLine: COMMAND_LINE.replace(WOLFRAM, 'C:\\other\\wolfram.exe') }),
      false,
    )
  })

  it('rejects a process created outside the recorded spawn window', () => {
    assert.equal(identityMatchesRecord(base, { ...matchingIdentity, createdAtMs: Date.now() - 3_600_000 }), false)
    assert.equal(identityMatchesRecord(base, { ...matchingIdentity, createdAtMs: Date.now() + 3_600_000 }), false)
  })

  it('accepts a slow kernel launch inside the window', () => {
    assert.equal(identityMatchesRecord(base, { ...matchingIdentity, createdAtMs: base.spawnedAtMs + 30_000 }), true)
  })

  it('keeps command-line evidence when the platform reports no creation time', () => {
    const { createdAtMs, ...noTime } = matchingIdentity
    assert.equal(typeof createdAtMs, 'number')
    assert.equal(identityMatchesRecord(base, noTime), true)
  })
})
