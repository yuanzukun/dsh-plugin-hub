/**
 * Compatibility checks at the dynamically imported DSH plugin boundary.
 *
 * @module
 */

import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { assertMcpClientPlugin } from '../src/harness-module.js'

const compatible = Object.freeze({
  name: 'mcp-client',
  inject: ['tools'],
  apply() {},
  Config() {},
})

describe('the running DSH mcp-client boundary', () => {
  it('accepts the namespace surface published by rc.5 and rc.2', () => {
    assert.equal(assertMcpClientPlugin(compatible), compatible)
  })

  /** @type {Array<[string, Record<string, unknown>]>} */
  const incompatible = [
    ['plugin name', { ...compatible, name: 'renamed-client' }],
    ['named apply export', { ...compatible, apply: undefined }],
    ['tools injection', { ...compatible, inject: [] }],
  ]
  for (const [label, plugin] of incompatible) {
    it(`fails at load when the host loses the ${label}`, () => {
      assert.throws(
        () => assertMcpClientPlugin(plugin),
        /incompatible @deepseek-ai\/dsh-mcp-client.*tested with DSH 0\.1\.0-rc\.5 and 0\.1\.1-rc\.2/,
      )
    })
  }
})
