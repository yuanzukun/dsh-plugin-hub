/**
 * Kernel discovery: the override precedence, the platform layouts, registry
 * parsing, and the diagnostic a failed discovery must produce.
 *
 * Every case injects its own host facts, so the suite asserts the same
 * behavior on every platform and never depends on this machine's install.
 *
 * @module
 */

import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import {
  AGENT_TOOLS_ARGS,
  compareVersionsDescending,
  parseRegQuery,
  resolveWolframCommand,
} from '../src/discovery.js'

/**
 * Build injectable host facts from a set of files that exist.
 * @param {object} options - Fake host description.
 * @param {string} options.platform - Platform id.
 * @param {readonly string[]} [options.files] - Paths that resolve as regular files.
 * @param {Record<string, string | undefined>} [options.env] - Environment.
 * @param {Record<string, readonly string[]>} [options.directories] - Directory listings.
 * @param {Record<string, string>} [options.captures] - `command argv.join(' ')` to stdout.
 * @returns {import('../src/discovery.js').HostFacts} the host facts.
 */
function host(options) {
  const files = new Set(options.files ?? [])
  return {
    platform: options.platform,
    env: options.env ?? {},
    isFile: path => files.has(path),
    readDirectory: path => options.directories?.[path] ?? [],
    runCapture: (command, args) => options.captures?.[[command, ...args].join(' ')],
  }
}

describe('the launch contract copied from the paclet', () => {
  it('passes the AgentTools start expression as one argument', () => {
    assert.deepEqual([...AGENT_TOOLS_ARGS], [
      '-run',
      'PacletSymbol["Wolfram/AgentTools","Wolfram`AgentTools`StartMCPServer"][]',
      '-noinit',
      '-noprompt',
    ])
    // The published command line quotes the expression for a shell; spawning
    // without a shell means the quotes must not be part of the argument.
    assert.equal(AGENT_TOOLS_ARGS[1]?.startsWith("'"), false)
  })
})

describe('override precedence', () => {
  it('uses an explicit command verbatim, without probing anything', () => {
    const resolved = resolveWolframCommand({ command: 'X:\\custom\\wolfram.exe' }, host({
      platform: 'win32',
      env: { DSH_WOLFRAM_COMMAND: 'X:\\ignored.exe' },
    }))
    assert.deepEqual(resolved, { command: 'X:\\custom\\wolfram.exe', source: 'config.command' })
  })

  it('falls back to the environment override before any discovery', () => {
    const resolved = resolveWolframCommand({}, host({
      platform: 'win32',
      env: { DSH_WOLFRAM_COMMAND: 'X:\\env\\wolfram.exe', WOLFRAM_INSTALLATION_DIRECTORY: 'X:\\other' },
    }))
    assert.deepEqual(resolved, { command: 'X:\\env\\wolfram.exe', source: 'env.DSH_WOLFRAM_COMMAND' })
  })

  it('resolves an explicit installation directory to the platform executable', () => {
    const resolved = resolveWolframCommand({ installationDirectory: 'D:\\mma\\15.0' }, host({
      platform: 'win32',
      files: ['D:\\mma\\15.0\\wolfram.exe'],
    }))
    assert.equal(resolved.command, 'D:\\mma\\15.0\\wolfram.exe')
    assert.equal(resolved.source, 'config.installationDirectory')
    assert.equal(resolved.installationDirectory, 'D:\\mma\\15.0')
  })

  it('rejects an explicit installation directory that holds no kernel', () => {
    assert.throws(
      () => resolveWolframCommand({ installationDirectory: 'D:\\empty' }, host({ platform: 'win32' })),
      /config\.installationDirectory .* holds no wolfram\.exe/,
    )
  })
})

describe('platform layouts', () => {
  it('uses the paclet layout on each supported platform, with that platform\'s separators', () => {
    const cases = [
      { platform: 'win32', root: 'D:\\mma', expected: 'D:\\mma\\wolfram.exe' },
      { platform: 'darwin', root: '/Applications/Wolfram.app/Contents', expected: '/Applications/Wolfram.app/Contents/MacOS/wolfram' },
      { platform: 'linux', root: '/usr/local/Wolfram/Wolfram/15.0', expected: '/usr/local/Wolfram/Wolfram/15.0/Executables/wolfram' },
    ]
    for (const { platform, root, expected } of cases) {
      const resolved = resolveWolframCommand({ installationDirectory: root }, host({ platform, files: [expected] }))
      assert.equal(resolved.command, expected, platform)
    }
  })

  it('has no layout for an unsupported platform and says how to override', () => {
    assert.throws(
      () => resolveWolframCommand({}, host({ platform: 'sunos' })),
      /no known Wolfram layout for platform "sunos".*DSH_WOLFRAM_COMMAND/s,
    )
  })
})

describe('windows registry discovery', () => {
  const registryOutput = [
    '',
    'HKEY_LOCAL_MACHINE\\SOFTWARE\\Wolfram Research\\Installations\\13811032',
    '    ExecutablePath    REG_SZ    D:\\mathematica\\Mathematica 15.0\\WolframNB.exe',
    '',
    'HKEY_LOCAL_MACHINE\\SOFTWARE\\Wolfram Research\\Installations\\12000000',
    '    ExecutablePath    REG_SZ    C:\\Program Files\\Wolfram Research\\Mathematica\\14.1\\WolframNB.exe',
    '',
    'End of search: 2 match(es) found.',
  ].join('\r\n')
  const versionOutput = [
    '',
    'HKEY_LOCAL_MACHINE\\SOFTWARE\\Wolfram Research\\Installations\\13811032',
    '    ProductVersion    REG_SZ    15.0.1',
    '',
    'HKEY_LOCAL_MACHINE\\SOFTWARE\\Wolfram Research\\Installations\\12000000',
    '    ProductVersion    REG_SZ    14.1.0',
    '',
  ].join('\r\n')

  it('parses key blocks including values that contain spaces', () => {
    const parsed = parseRegQuery(registryOutput)
    assert.equal(parsed.size, 2)
    assert.equal(
      parsed.get('HKEY_LOCAL_MACHINE\\SOFTWARE\\Wolfram Research\\Installations\\13811032'),
      'D:\\mathematica\\Mathematica 15.0\\WolframNB.exe',
    )
  })

  it('finds an installation on a non-default drive and prefers the newest', () => {
    const captures = {
      'reg query HKLM\\SOFTWARE\\Wolfram Research\\Installations /s /v ExecutablePath': registryOutput,
      'reg query HKLM\\SOFTWARE\\Wolfram Research\\Installations /s /v ProductVersion': versionOutput,
    }
    const resolved = resolveWolframCommand({}, host({
      platform: 'win32',
      captures,
      files: [
        'D:\\mathematica\\Mathematica 15.0\\wolfram.exe',
        'C:\\Program Files\\Wolfram Research\\Mathematica\\14.1\\wolfram.exe',
      ],
    }))
    assert.equal(resolved.command, 'D:\\mathematica\\Mathematica 15.0\\wolfram.exe')
    assert.equal(resolved.source, 'windows-registry')
  })

  it('skips a registry entry whose directory holds no kernel', () => {
    // The WolframScript installation registers an ExecutablePath too; its
    // directory has no wolfram.exe, so it must not be selected.
    const scriptOnly = [
      'HKEY_LOCAL_MACHINE\\SOFTWARE\\Wolfram Research\\Installations\\A-WIN64-WolframScript',
      '    ExecutablePath    REG_SZ    C:\\Program Files\\Wolfram Research\\WolframScript\\wolframscript.exe',
    ].join('\r\n')
    assert.throws(() => resolveWolframCommand({ probeWolframScript: false }, host({
      platform: 'win32',
      captures: { 'reg query HKLM\\SOFTWARE\\Wolfram Research\\Installations /s /v ExecutablePath': scriptOnly },
    })), /no Wolfram kernel found/)
  })
})

describe('install-root discovery', () => {
  it('finds the newest versioned installation under Program Files', () => {
    const root = 'C:\\Program Files\\Wolfram Research\\Wolfram'
    const resolved = resolveWolframCommand({}, host({
      platform: 'win32',
      env: { ProgramFiles: 'C:\\Program Files' },
      directories: { [root]: ['14.2', '15.0', 'notes.txt'] },
      files: [`${root}\\15.0\\wolfram.exe`, `${root}\\14.2\\wolfram.exe`],
    }))
    assert.equal(resolved.command, `${root}\\15.0\\wolfram.exe`)
    assert.equal(resolved.source, 'platform-install-root')
  })

  it('finds a macOS application bundle', () => {
    const resolved = resolveWolframCommand({}, host({
      platform: 'darwin',
      files: ['/Applications/Mathematica.app/Contents/MacOS/wolfram'],
    }))
    assert.equal(resolved.command, '/Applications/Mathematica.app/Contents/MacOS/wolfram')
  })

  it('accepts a Linux kernel found on PATH', () => {
    const resolved = resolveWolframCommand({}, host({
      platform: 'linux',
      env: { PATH: '/usr/bin:/usr/local/bin' },
      files: ['/usr/local/bin/wolfram'],
    }))
    assert.equal(resolved.command, '/usr/local/bin/wolfram')
    assert.equal(resolved.source, 'PATH')
  })
})

describe('the wolframscript probe', () => {
  it('is the last resort and strips the kernel\'s quoting', () => {
    const resolved = resolveWolframCommand({}, host({
      platform: 'linux',
      captures: { 'wolframscript -code $InstallationDirectory': '"/opt/custom/Wolfram"' },
      files: ['/opt/custom/Wolfram/Executables/wolfram'],
    }))
    assert.equal(resolved.command, '/opt/custom/Wolfram/Executables/wolfram')
    assert.equal(resolved.source, 'wolframscript')
  })

  it('can be turned off for a deployment that must not pay for it', () => {
    assert.throws(() => resolveWolframCommand({ probeWolframScript: false }, host({
      platform: 'linux',
      captures: { 'wolframscript -code $InstallationDirectory': '"/opt/custom/Wolfram"' },
      files: ['/opt/custom/Wolfram/Executables/wolfram'],
    })), /no Wolfram kernel found/)
  })
})

describe('discovery failure', () => {
  it('lists what was tried and how to override', () => {
    assert.throws(() => resolveWolframCommand({}, host({
      platform: 'win32',
      env: { ProgramFiles: 'C:\\Program Files' },
    })), error => {
      const message = /** @type {Error} */ (error).message
      assert.match(message, /no Wolfram kernel found\. Tried:/)
      assert.match(message, /wolframscript -code \$InstallationDirectory/)
      assert.match(message, /DSH_WOLFRAM_COMMAND/)
      return true
    })
  })
})

describe('version ordering', () => {
  it('sorts newest first and pushes unparseable names last', () => {
    const sorted = ['14.1', '15.0.1', 'beta', '9.0', '15.0'].sort(compareVersionsDescending)
    assert.deepEqual(sorted, ['15.0.1', '15.0', '14.1', '9.0', 'beta'])
  })
})
