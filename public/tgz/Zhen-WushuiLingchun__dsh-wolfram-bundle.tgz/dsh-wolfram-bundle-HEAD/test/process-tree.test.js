/**
 * Process-tree termination against real processes.
 *
 * The load-bearing assertion is not that the tree dies — it is that an
 * unrelated control process, spawned from the same executable at the same
 * time, is still running afterwards. That is the property protecting a user's
 * own Mathematica session and other clients' AgentTools servers.
 *
 * @module
 */

import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { after, describe, it } from 'node:test'
import { fileURLToPath } from 'node:url'
import { isProcessAlive, readProcessIdentity, terminateProcessTree } from '../src/process-tree.js'

const FAKE_SERVER = fileURLToPath(new URL('../fixtures/fake-server.js', import.meta.url))
const SLEEPER = fileURLToPath(new URL('../fixtures/sleeper.js', import.meta.url))

/** Every pid this suite created, so a failed assertion cannot leak a process. */
/** @type {Set<number>} */
const created = new Set()

/**
 * Spawn a fixture and remember its pid.
 * @param {string} script - Fixture path.
 * @param {readonly string[]} args - Fixture arguments.
 * @returns {import('node:child_process').ChildProcess} the spawned process.
 */
function spawnFixture(script, args = []) {
  const child = spawn(process.execPath, [script, ...args], {
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
    detached: process.platform !== 'win32',
  })
  if (child.pid !== undefined) created.add(child.pid)
  return child
}

/**
 * Wait until a predicate holds or the budget expires.
 * @param {() => boolean} predicate - Condition to wait for.
 * @param {number} timeoutMs - Budget.
 * @returns {Promise<boolean>} whether the predicate held in time.
 */
async function waitFor(predicate, timeoutMs = 10_000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (predicate()) return true
    await new Promise(resolve => setTimeout(resolve, 50))
  }
  return predicate()
}

/**
 * Read the grandchild pids the `tree` fixture reports on stderr.
 * @param {import('node:child_process').ChildProcess} child - The fixture process.
 * @param {number} count - How many grandchildren to wait for.
 * @returns {Promise<number[]>} the reported pids.
 */
function readGrandchildPids(child, count) {
  return new Promise((resolve, reject) => {
    /** @type {number[]} */
    const pids = []
    let buffer = ''
    const timer = setTimeout(() => reject(new Error(`only saw ${String(pids.length)} of ${String(count)} grandchildren`)), 15_000)
    child.stderr?.setEncoding('utf8')
    child.stderr?.on('data', chunk => {
      buffer += chunk
      for (const match of buffer.matchAll(/grandchild (\d+)/g)) {
        const pid = Number.parseInt(/** @type {string} */ (match[1]), 10)
        if (!pids.includes(pid)) {
          pids.push(pid)
          created.add(pid)
        }
      }
      if (pids.length >= count) {
        clearTimeout(timer)
        resolve(pids)
      }
    })
  })
}

after(() => {
  // Belt and braces: only pids this suite itself created are ever touched.
  for (const pid of created) {
    if (isProcessAlive(pid)) terminateProcessTree(pid)
  }
})

describe('liveness probing', () => {
  it('reports a running process alive and a reaped one dead', async () => {
    const child = spawnFixture(SLEEPER)
    assert.equal(isProcessAlive(/** @type {number} */ (child.pid)), true)
    const exited = new Promise(resolve => child.once('exit', resolve))
    terminateProcessTree(/** @type {number} */ (child.pid))
    await exited
    assert.equal(await waitFor(() => !isProcessAlive(/** @type {number} */ (child.pid))), true)
  })

  it('refuses obviously invalid pids instead of guessing', () => {
    for (const pid of [0, -1, 1.5, Number.NaN]) {
      assert.equal(isProcessAlive(pid), false)
      assert.deepEqual(terminateProcessTree(pid).attempted, false)
    }
  })
})

describe('whole-tree termination', () => {
  it('kills the direct child and its grandchildren, and nothing else', async () => {
    const control = spawnFixture(SLEEPER)
    const tree = spawnFixture(FAKE_SERVER, ['--mode', 'tree', '--grandchildren', '2'])
    const grandchildren = await readGrandchildPids(tree, 2)
    assert.equal(grandchildren.length, 2)
    const treePid = /** @type {number} */ (tree.pid)
    const controlPid = /** @type {number} */ (control.pid)
    assert.notEqual(treePid, controlPid)
    for (const pid of [treePid, ...grandchildren]) {
      assert.equal(isProcessAlive(pid), true, `pid ${String(pid)} should be running before termination`)
    }

    const outcome = terminateProcessTree(treePid)
    assert.equal(outcome.attempted, true)
    assert.equal(outcome.ok, true, outcome.detail)

    for (const pid of [treePid, ...grandchildren]) {
      assert.equal(await waitFor(() => !isProcessAlive(pid)), true, `pid ${String(pid)} survived tree termination`)
    }
    assert.equal(isProcessAlive(controlPid), true, 'the unrelated control process must survive')

    const controlExit = new Promise(resolve => control.once('exit', resolve))
    terminateProcessTree(controlPid)
    await controlExit
  })

  it('treats an already-gone tree as success rather than an error', async () => {
    const child = spawnFixture(SLEEPER)
    const pid = /** @type {number} */ (child.pid)
    const exited = new Promise(resolve => child.once('exit', resolve))
    terminateProcessTree(pid)
    await exited
    await waitFor(() => !isProcessAlive(pid))
    const outcome = terminateProcessTree(pid)
    assert.equal(outcome.ok, true, outcome.detail)
  })
})

describe('identity readback', () => {
  it('reports the image name and command line of a live process', async () => {
    const child = spawnFixture(SLEEPER)
    const pid = /** @type {number} */ (child.pid)
    const identity = readProcessIdentity(pid)
    assert.ok(identity !== undefined, 'a live process must be identifiable')
    assert.equal(identity.pid, pid)
    assert.match(identity.name, /^node(\.exe)?$/i)
    assert.match(identity.commandLine, /sleeper\.js/)
    assert.equal(typeof identity.createdAtMs, 'number')
    // Both CIM and /proc start time must be recent enough to distinguish this
    // process from a pid the operating system reused long ago.
    assert.ok(Math.abs(Date.now() - /** @type {number} */ (identity.createdAtMs)) < 120_000)
    const exited = new Promise(resolve => child.once('exit', resolve))
    terminateProcessTree(pid)
    await exited
  })

  it('reports nothing for a pid that is not running', async () => {
    const child = spawnFixture(SLEEPER)
    const pid = /** @type {number} */ (child.pid)
    const exited = new Promise(resolve => child.once('exit', resolve))
    terminateProcessTree(pid)
    await exited
    await waitFor(() => !isProcessAlive(pid))
    assert.equal(readProcessIdentity(pid), undefined)
  })
})
