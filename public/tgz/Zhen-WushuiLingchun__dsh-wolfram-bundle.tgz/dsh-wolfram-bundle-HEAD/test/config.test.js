/**
 * Row-config resolution and the mcp-client configuration built from it.
 *
 * The load-bearing assertions are that misconfiguration fails at load with an
 * actionable message, and that the supervisor command line the harness spawns
 * carries the paclet's launch contract intact.
 *
 * @module
 */

import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { buildMcpClientConfig, resolveWolframSpec } from '../src/config.js'
import { AGENT_TOOLS_ARGS } from '../src/discovery.js'
import { MAX_GRACE_MS } from '../src/supervisor.js'

const WOLFRAM = 'D:\\mma\\15.0\\wolfram.exe'

/** Host facts with one discoverable kernel and a controlled harness home. */
const host = {
  platform: 'win32',
  env: { DSH_HOME: 'D:\\home', ProgramFiles: 'C:\\Program Files' },
  isFile: (/** @type {string} */ path) => path === WOLFRAM,
  readDirectory: () => [],
  runCapture: () => undefined,
}

describe('defaults', () => {
  it('resolves a bare row to the WolframLanguage server under the wolfram namespace', () => {
    const spec = resolveWolframSpec({ command: WOLFRAM }, host)
    assert.equal(spec.serverName, 'wolfram')
    assert.equal(spec.mcpServerName, 'WolframLanguage')
    assert.equal(spec.kernel.command, WOLFRAM)
    assert.deepEqual([...spec.kernelArgs], [...AGENT_TOOLS_ARGS])
    assert.equal(spec.reclaimOrphans, true)
    assert.equal(spec.graceMs, 1_000)
    // The evaluator's own 60s TimeConstraint must not race the wire timeout.
    assert.ok(spec.toolCallTimeoutMs > 60_000)
  })

  it('puts the record directory under the harness home', () => {
    const spec = resolveWolframSpec({ command: WOLFRAM }, host)
    assert.equal(spec.recordDirectory, 'D:\\home\\.dsh-wolfram')
  })

  it('accepts an explicit record directory', () => {
    const spec = resolveWolframSpec({ command: WOLFRAM, recordDirectory: 'E:\\state' }, host)
    assert.equal(spec.recordDirectory, 'E:\\state')
  })

  it('builds a native POSIX state path in WSL', () => {
    const posixHost = {
      platform: 'linux',
      env: { DSH_HOME: '/home/hydro/.dsh', WSL_INTEROP: '/run/WSL/1_interop', LANG: 'C.UTF-8' },
      isFile: () => true,
      readDirectory: () => [],
      runCapture: () => undefined,
    }
    const spec = resolveWolframSpec({ command: '/mnt/d/mma/15.0/wolfram.exe' }, posixHost)
    assert.equal(spec.recordDirectory, '/home/hydro/.dsh/.dsh-wolfram')
    assert.deepEqual(spec.env, { WSL_INTEROP: '/run/WSL/1_interop', LANG: 'C.UTF-8' })
  })

  it('never forwards credential-shaped environment variables into WSL interop', () => {
    const posixHost = {
      platform: 'linux',
      env: {
        DSH_HOME: '/tmp/dsh',
        WSL_INTEROP: '/run/WSL/2_interop',
        WSLENV: 'SAFE/u',
        DEEPSEEK_API_KEY: 'must-not-forward',
      },
      isFile: () => true,
      readDirectory: () => [],
      runCapture: () => undefined,
    }
    const spec = resolveWolframSpec({ command: '/mnt/d/mma/15.0/wolfram.exe' }, posixHost)
    assert.deepEqual(spec.env, { WSL_INTEROP: '/run/WSL/2_interop', WSLENV: 'SAFE/u' })
    assert.equal(Object.hasOwn(spec.env, 'DEEPSEEK_API_KEY'), false)
    assert.equal('/tmp/dsh/.dsh-wolfram', spec.recordDirectory)
  })
})

describe('validation', () => {
  it('rejects a serverName mcp-client would refuse', () => {
    assert.throws(() => resolveWolframSpec({ command: WOLFRAM, serverName: 'not valid' }, host), /serverName must match/)
  })

  it('rejects an empty mcpServerName', () => {
    assert.throws(() => resolveWolframSpec({ command: WOLFRAM, mcpServerName: '' }, host), /mcpServerName must be a non-empty string/)
  })

  it('rejects a grace period the SDK would cut short, explaining why', () => {
    assert.throws(
      () => resolveWolframSpec({ command: WOLFRAM, graceMs: MAX_GRACE_MS + 1 }, host),
      /skip process-tree cleanup entirely/,
    )
    assert.throws(() => resolveWolframSpec({ command: WOLFRAM, graceMs: 0 }, host), /must be an integer in 1\.\./)
  })

  it('rejects wrongly typed fields instead of coercing them', () => {
    assert.throws(() => resolveWolframSpec({ command: 42 }, host), /config\.command must be a string/)
    assert.throws(() => resolveWolframSpec({ command: WOLFRAM, reclaimOrphans: 'yes' }, host), /must be a boolean/)
    assert.throws(() => resolveWolframSpec({ command: WOLFRAM, args: 'not-a-list' }, host), /config\.args must be an array of strings/)
    assert.throws(() => resolveWolframSpec({ command: WOLFRAM, args: [1] }, host), /config\.args must be an array of strings/)
    assert.throws(() => resolveWolframSpec({ command: WOLFRAM, env: { A: 1 } }, host), /config\.env must be a map of string values/)
    assert.throws(() => resolveWolframSpec({ command: WOLFRAM, toolCallTimeoutMs: -1 }, host), /must be a positive number/)
  })

  it('propagates a discovery failure rather than starting a broken connection', () => {
    assert.throws(
      () => resolveWolframSpec({ probeWolframScript: false }, { ...host, isFile: () => false }),
      /no Wolfram kernel found/,
    )
  })
})

describe('the mcp-client configuration', () => {
  const spec = resolveWolframSpec({ command: WOLFRAM, recordDirectory: 'E:\\state' }, host)
  const config = buildMcpClientConfig(spec, 'C:\\node\\node.exe')

  it('runs the supervisor on the harness\'s own Node binary', () => {
    assert.equal(config.transport, 'stdio')
    assert.equal(config.command, 'C:\\node\\node.exe')
    const args = /** @type {string[]} */ (config.args)
    assert.match(/** @type {string} */ (args[0]), /supervisor-main\.js$/)
  })

  it('passes the paclet launch contract through as separate arguments', () => {
    const args = /** @type {string[]} */ (config.args)
    assert.equal(args[args.indexOf('--command') + 1], WOLFRAM)
    const passed = args.flatMap((arg, index) => arg === '--arg' ? [/** @type {string} */ (args[index + 1])] : [])
    assert.deepEqual(passed, [...AGENT_TOOLS_ARGS])
    // The `-run` expression must survive as ONE argument, quotes and all.
    assert.equal(passed[1], 'PacletSymbol["Wolfram/AgentTools","Wolfram`AgentTools`StartMCPServer"][]')
  })

  it('selects the server through MCP_SERVER_NAME, as the paclet does', () => {
    assert.deepEqual(config.env, { MCP_SERVER_NAME: 'WolframLanguage' })
  })

  it('lets extra env merge over the server selection without dropping it', () => {
    const withEnv = buildMcpClientConfig(
      resolveWolframSpec({ command: WOLFRAM, env: { WOLFRAM_USERBASE: 'D:\\base' } }, host),
      'node',
    )
    assert.deepEqual(withEnv.env, { MCP_SERVER_NAME: 'WolframLanguage', WOLFRAM_USERBASE: 'D:\\base' })
  })

  it('passes the record directory only while reclamation is on', () => {
    assert.ok(/** @type {string[]} */ (config.args).includes('--record-dir'))
    const off = buildMcpClientConfig(resolveWolframSpec({ command: WOLFRAM, reclaimOrphans: false }, host), 'node')
    assert.equal(/** @type {string[]} */ (off.args).includes('--record-dir'), false)
  })

  it('forwards the reconnect policy untouched for mcp-client to validate', () => {
    const withReconnect = buildMcpClientConfig(
      resolveWolframSpec({ command: WOLFRAM, reconnect: { maxAttempts: 3 } }, host),
      'node',
    )
    assert.deepEqual(withReconnect.reconnect, { maxAttempts: 3 })
    assert.equal(Object.hasOwn(config, 'reconnect'), false, 'an unset policy must stay unset, not be invented')
  })

  it('marks MCP_SERVER_NAME for WSL-to-Windows interop', () => {
    const spec = resolveWolframSpec({ command: '/mnt/d/mma/15.0/wolfram.exe' }, {
      platform: 'linux',
      env: { DSH_HOME: '/tmp/dsh', WSL_INTEROP: '/run/WSL/3_interop', WSLENV: 'SAFE/u' },
      isFile: () => true,
      readDirectory: () => [],
      runCapture: () => undefined,
    })
    const built = buildMcpClientConfig(spec, '/opt/node/bin/node')
    assert.equal(/** @type {Record<string, string>} */ (built.env).WSLENV, 'SAFE/u:MCP_SERVER_NAME/w')
  })
})
