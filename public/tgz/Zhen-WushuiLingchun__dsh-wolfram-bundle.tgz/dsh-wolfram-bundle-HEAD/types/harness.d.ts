/**
 * The structural subset of the DeepSeek Harness interfaces this plugin
 * consumes.
 *
 * This package has no build step and no dependency on the harness type
 * packages, so the surface it actually relies on is declared here and checked
 * by `npm run typecheck`. It is deliberately narrow: adding a member here means
 * this plugin took on a new dependency on harness internals, which should be a
 * visible change in review.
 *
 * Authority for these contracts stays in the harness itself —
 * `@deepseek-ai/cordis` (`Context`, `ctx.effect`, `ctx.plugin`),
 * `@deepseek-ai/dsh-tools` (`tools/pre-execute`, `PreToolDecision`), and
 * `@deepseek-ai/dsh-mcp-client` (its `Config`).
 */

/** The pending tool call a `tools/pre-execute` listener sees. */
export interface ToolExecution {
  /** Model-facing tool name, i.e. `mcp__<serverName>__<rawName>` for MCP tools. */
  readonly name: string
}

/** The pre-dispatch decision vocabulary of the harness tool pipeline. */
export type PreToolDecision =
  | { kind: 'allow' }
  | { kind: 'deny'; reason: string }
  | { kind: 'ask'; reason?: string }

/**
 * A mounted plugin instance; disposal unwinds everything it registered, and
 * awaiting it settles once the plugin finished loading. The `then` callback
 * receives the fiber itself, typed `unknown` here because this plugin only
 * awaits readiness and never reads the resolved value.
 */
export interface Fiber {
  dispose(): Promise<void>
  then<T>(onFulfilled: (fiber: unknown) => T): PromiseLike<T>
}

/** The Cordis context surface this plugin uses. */
export interface HarnessContext {
  readonly logger: {
    info(message: string): void
    warn(message: string): void
    error(message: string): void
  }
  /** Register a reversible registration; the returned callback unwinds it. */
  effect(callback: () => (() => void | Promise<void>), label?: string): void
  /** Register an event listener as an effect. */
  on(
    event: 'tools/pre-execute',
    listener: (exec: ToolExecution, next: () => Promise<PreToolDecision>) => Promise<PreToolDecision>,
  ): () => void
  /** Mount a child plugin under this context. */
  plugin(plugin: unknown, config?: unknown): Fiber
}
