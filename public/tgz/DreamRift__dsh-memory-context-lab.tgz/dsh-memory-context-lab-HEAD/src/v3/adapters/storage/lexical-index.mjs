/**
 * v3 词法索引（adapters/storage，M2 第三批）——可删除、可重建的派生物。
 *
 * 权威事实源只有记录正文（P9：索引是派生物）；本模块只做：
 * - buildLexicalIndex：从 {id, text} 清单建倒排（term → {id: tf}），
 *   词元化复用 domain/retrieval 的 tokenizeQuery（CJK 单字+双字，同一把尺子）；
 * - searchLexical：词元覆盖计数打分 + rankResults 确定性排序（domain 消费者）；
 * - 读写经 writeFileAtomic / JSON；索引文件损坏 → ESTORE_CORRUPT，
 *   调用方走 rebuildLexicalIndex 从记录重建（派生物不许挡权威数据）。
 */
import { readFile } from 'node:fs/promises'
import path from 'node:path'

import { v3Error, V3ContractViolation } from '../../contracts/errors.mjs'
import { rankResults, tokenizeQuery } from '../../domain/retrieval/query.mjs'
import { writeFileAtomic } from './session-store.mjs'
import { fileStampOf } from './file-stamp.mjs'
// P3 清理（2026-11-01）：删掉三处死导入——createHash 从未使用（哈希在本模块无消费者），
// buildChunkIndex/writeChunkIndex 由 session-store-port 在**同一次重建**里落盘，
// 这里再导入一份只会留下「两份重建入口」的假象。

const INDEX_FILE = 'lexical-index.json'

/**
 * 从记录清单构建索引。entries: Array<{id: string, text: string}>
 * @returns {{ terms: Object<string, Object<string, number>>, indexedCount: number }}
 */
export function buildLexicalIndex(entries, { sourceCount, forgottenCount } = {}) {
  if (!Array.isArray(entries)) {
    throw new V3ContractViolation('v3 index: entries 必须是数组')
  }
  // 倒排表必须是**无原型对象**（H-13）：普通 {} 上 terms['constructor'] 命中的是
  // Object.prototype.constructor（继承属性），于是 terms[term][id] = … 会把记录 ID 写进
  // 全局 Object 构造函数（原型污染），且该词元在 JSON 序列化时被丢弃（检索永久 OOV）。
  const terms = Object.create(null)
  const docLengths = Object.create(null)
  let totalTokens = 0
  for (const entry of entries) {
    if (entry === null || typeof entry !== 'object' || typeof entry.id !== 'string' || typeof entry.text !== 'string') {
      throw new V3ContractViolation('v3 index: 条目必须是 {id, text}')
    }
    // docLength 只在这里算一次（beta.7 F 组：同一个量只算一次）——BM25 的文档长度单一真源
    const tokens = tokenizeQuery(entry.text)
    docLengths[entry.id] = tokens.length
    totalTokens += tokens.length
    for (const term of tokens) {
      if (terms[term] === undefined) terms[term] = Object.create(null)
      terms[term][entry.id] = (terms[term][entry.id] ?? 0) + 1
    }
  }
  return {
    terms,
    docLengths,
    avgDocLength: entries.length === 0 ? 0 : totalTokens / entries.length,
    indexedCount: entries.length,
    // 上游规模（已提交记录数，含未进索引的 metadata-only 与已遗忘记录）：
    // 新鲜度只跟这个量比——indexedCount 是「可检索文档数」，两者口径不同，
    // 拿 indexedCount 跟已提交数比会让「有 metadata-only / 有遗忘」的库永久 stale
    // （H-03：每次检索都全量重建，O(N) 读盘）。
    sourceCount: Number.isInteger(sourceCount) && sourceCount >= 0 ? sourceCount : entries.length,
    // 建索引时的已遗忘集规模（H-41）：遗忘不改变 sourceCount，只靠它判不出「遗忘后索引没重建」。
    forgottenCount: Number.isInteger(forgottenCount) && forgottenCount >= 0 ? forgottenCount : 0,
  }
}

/**
 * 词法检索：每个词元命中记 tf，得分 = 命中词元的 tf 之和（未命中词元不计分，
 * 也不做 OOV 披露——那是 M4 BM25 合并通道的职责）。
 * @returns {Array<{id, score}>} 经 rankResults 排序的前 limit 条
 */
export function searchLexical(index, query, { limit = 10 } = {}) {
  if (index === null || typeof index !== 'object' || typeof index.terms !== 'object') {
    throw new V3ContractViolation('v3 index: index 必须是 buildLexicalIndex 产物')
  }
  if (!Number.isInteger(limit) || limit < 1) {
    throw new V3ContractViolation('v3 index: limit 必须是 ≥1 整数')
  }
  const terms = tokenizeQuery(query)
  if (terms.length === 0) return [] // 空查询不造通配（fail-closed）
  const scores = new Map()
  for (const term of terms) {
    const postings = index.terms[term]
    if (postings === undefined) continue
    for (const [id, tf] of Object.entries(postings)) {
      scores.set(id, (scores.get(id) ?? 0) + tf)
    }
  }
  return rankResults([...scores].map(([id, score]) => ({ id, score }))).slice(0, limit)
}

/**
 * M-04（0.15.4，P1）**增量索引**：把新增/移除的记录并入已有索引，不做全量重扫。
 *
 * ## 缺陷
 *
 * 旧实现只有 `rebuildLexicalIndex`（读**全部**记录 → 重建 → 写整份索引）。每步摄入
 * 1–3 条记录也会触发一次：实测 3,044 ms / 26 MB 写、稳定循环约 4.5 s 一次、
 * 约 340 MB/分钟写入、67% 占主线程。计划 §5.4 明文要求「pre-step 只读已就绪索引…
 * 不做全库重建」、§9.3 要求「索引后台换代…不在 pre-step 全量重建」。
 *
 * ## 为什么可以增量（正确性前提）
 *
 * 记录**提交后不可变**（`submitTransaction` 冲突即拒、无原地改写），本会话内一旦
 * 提交就只有两种情况改变可检索集合：**新增**可检索记录、**遗忘**已有记录。
 * 因此「旧索引 + 新增 doc + 移除 doc」与「全量重扫」在语义上等价——前提是
 * `sourceCount` / `forgottenCount` 两个基线要跟着更新（否则新鲜度判据会说谎）。
 *
 * ## 边界（失败即退回全量）
 *
 * 增量要求旧索引**可信**：索引缺失、损坏、或基线与实际不符（期间有别的写者）时
 * 一律返回 `{ applied: false }`，由调用方退回 `rebuildLexicalIndex`。宁可多扫一次，
 * 也不让索引悄悄偏离真源。
 *
 * @param {object} store 存储端口（需 directory / listRecordIds / readRecord）
 * @param {{added?: Array<{id,text}>, removed?: string[], textOfRecord?: Function}} plan
 * @returns {Promise<{applied: boolean, index?: object, reason?: string}>}
 */
export async function updateLexicalIndexIncremental(store, plan = {}) {
  const added = Array.isArray(plan.added) ? plan.added : []
  const removed = Array.isArray(plan.removed) ? plan.removed : []
  if (added.length === 0 && removed.length === 0) return { applied: false, reason: 'no-change' }

  let index
  try {
    index = await readLexicalIndex(store)
  } catch (error) {
    return { applied: false, reason: 'index-unreadable' }
  }
  if (index === null || typeof index !== 'object' || typeof index.terms !== 'object') {
    return { applied: false, reason: 'index-absent' }
  }
  // 基线复核：旧索引必须对应**新增之前**的库。
  //
  // 时序是「记录先提交，索引后追」——调用本原语时新增记录已经在库里了。因此旧索引
  // 的 sourceCount 应当等于「当前库记录数 − 本次新增数」（移除方向则相反）。
  // 写成「等于当前库」是错的：那样永远不符，增量永远退回全量（等于没修）。
  const ids = await store.listRecordIds()
  const expectedBaseline = ids.length - added.length + removed.length
  if (!Number.isInteger(index.sourceCount) || index.sourceCount !== expectedBaseline) {
    return { applied: false, reason: 'baseline-drift' }
  }
  // 新增记录必须真的在库里（防止调用方传错 ID 造出幽灵文档）。
  const idSet = new Set(ids)
  for (const entry of added) {
    if (entry === null || typeof entry !== 'object' || typeof entry.id !== 'string') {
      return { applied: false, reason: 'bad-entry' }
    }
    if (!idSet.has(entry.id) && !removed.includes(entry.id)) {
      return { applied: false, reason: 'unknown-record' }
    }
  }
  const forgottenCount = typeof store.listForgotten === 'function' ? store.listForgotten().length : 0
  if ((Number.isInteger(index.forgottenCount) ? index.forgottenCount : 0) !== forgottenCount) {
    return { applied: false, reason: 'forgotten-drift' }
  }

  // 无原型对象：与 buildLexicalIndex 同一条编码纪律（H-13 原型污染）。
  const terms = Object.create(null)
  for (const term of Object.keys(index.terms)) {
    const row = index.terms[term]
    const copy = Object.create(null)
    for (const id of Object.keys(row ?? {})) copy[id] = row[id]
    terms[term] = copy
  }
  const docLengths = Object.create(null)
  for (const id of Object.keys(index.docLengths ?? {})) docLengths[id] = index.docLengths[id]

  /** 从倒排表里彻底摘掉一篇文档（不能只把 tf 清零，否则该词元会留下空行）。 */
  const dropDoc = (id) => {
    for (const term of Object.keys(terms)) {
      if (terms[term][id] !== undefined) {
        delete terms[term][id]
        if (Object.keys(terms[term]).length === 0) delete terms[term]
      }
    }
    delete docLengths[id]
  }

  for (const id of removed) dropDoc(id)
  for (const entry of added) {
    if (entry === null || typeof entry !== 'object' || typeof entry.id !== 'string' || typeof entry.text !== 'string') {
      return { applied: false, reason: 'bad-entry' }
    }
    dropDoc(entry.id) // 幂等：同 ID 重复并入不产生双份 tf
    const tokens = tokenizeQuery(entry.text)
    docLengths[entry.id] = tokens.length
    for (const term of tokens) {
      if (terms[term] === undefined) terms[term] = Object.create(null)
      terms[term][entry.id] = (terms[term][entry.id] ?? 0) + 1
    }
  }

  const docIds = Object.keys(docLengths)
  let totalTokens = 0
  for (const id of docIds) totalTokens += docLengths[id]
  return {
    applied: true,
    index: {
      terms,
      docLengths,
      avgDocLength: docIds.length === 0 ? 0 : totalTokens / docIds.length,
      indexedCount: docIds.length,
      // 增量后基线必须跟着走：否则下一次新鲜度判定会一直判 stale（永久全量重建）。
      // 直接取**当前库真实记录数**，而不是 `旧值 + 增 − 删` 的算术：后者在调用方
      // 多传/漏传一条 ID 时会算出与真实库不符的基线，反而制造永久 stale。
      sourceCount: ids.length,
      forgottenCount: added.length > 0 || removed.length > 0
        ? (typeof store.listForgotten === 'function' ? store.listForgotten().length : forgottenCount)
        : forgottenCount,
    },
  }
}

/** 持久化索引（派生物缓存）。 */
export async function writeLexicalIndex(store, index) {
  await writeFileAtomic(path.join(store.directory, INDEX_FILE), JSON.stringify(index) + '\n')
}

/** 读取索引；缺失返回 null（可重建），损坏抛 ESTORE_CORRUPT（不静默重建掩盖）。 */
/** 索引文件戳（词法索引路径；判据与 chunk 索引共用 fileStampOf）。 */
export async function indexStampOf(store) {
  return fileStampOf(path.join(store.directory, INDEX_FILE))
}

export async function readLexicalIndex(store) {
  let text
  try {
    text = await readFile(path.join(store.directory, INDEX_FILE), 'utf8')
  } catch (error) {
    if (error?.code === 'ENOENT') return null
    throw error
  }
  let parsed
  try {
    parsed = JSON.parse(text)
  } catch {
    parsed = null
  }
  const shapeOk = parsed !== null && typeof parsed === 'object' && typeof parsed.terms === 'object' && parsed.terms !== null && typeof parsed.docLengths === 'object' && parsed.docLengths !== null && Number.isFinite(parsed.avgDocLength) && Number.isInteger(parsed.indexedCount)
  if (!shapeOk) {
    throw v3Error('ESTORE_CORRUPT', 'lexical-index.json 损坏（派生物：删除后重建即可，不掩盖）')
  }
  // JSON.parse 产出的对象带 Object.prototype，旧索引文件里还可能已经带着被污染的
  // 继承属性（H-13）。读入后一律换成无原型表：查询 'constructor' 必须落 OOV，不能命中原型。
  const terms = Object.create(null)
  for (const [term, postings] of Object.entries(parsed.terms)) {
    if (postings === null || typeof postings !== 'object') continue
    const own = Object.create(null)
    for (const [id, tf] of Object.entries(postings)) {
      if (typeof tf === 'number' && Number.isFinite(tf)) own[id] = tf
    }
    terms[term] = own
  }
  const docLengths = Object.create(null)
  for (const [id, length] of Object.entries(parsed.docLengths)) {
    if (typeof length === 'number' && Number.isFinite(length)) docLengths[id] = length
  }
  return { ...parsed, terms, docLengths }
}

/**
 * 从存储的已提交记录重建索引并持久化。
 * @param {object} store openV3SessionStore 句柄
 * @param {Function} textOfRecord 从记录取正文的投影（默认 payload.text）
 */
export async function rebuildLexicalIndex(store, textOfRecord) {
  const pick = textOfRecord ?? ((record) => record?.payload?.text ?? '')
  const ids = await store.listRecordIds()
  const entries = []
  for (const id of ids) {
    const record = await store.readRecord(id)
    entries.push({ id, text: pick(record) })
  }
  // sourceCount 用未过滤的已提交数（entries 可能已由 textOfRecord 过滤掉不可检索项）
  const forgottenCount = typeof store.listForgotten === 'function' ? store.listForgotten().length : 0
  const index = buildLexicalIndex(entries, { sourceCount: ids.length, forgottenCount })
  await writeLexicalIndex(store, index)
  return index
}

/**
 * 索引新鲜度：**上游规模**（sourceCount）与已提交记录数不一致 → stale（须重建后再检索）。
 * 口径必须与 rebuildIndex 的输入一致：indexedCount 是可检索文档数（已扣除 metadata-only
 * 与已遗忘），拿它跟已提交数比会永久 stale（H-03）。旧索引无 sourceCount → 按 indexedCount
 * 比较，重建一次后自愈。
 *
 * 遗忘也必须算进新鲜度（H-41）：旧判据只看「已提交记录数」，而**遗忘不改变这个数**
 * （遗忘是「不可见」，不是「从未摄入」——见 session-store-port 的 sourceEventIds 注释）。
 * 于是「遗忘已提交、索引重建没跑」（崩溃 / 进程被杀 / IO 失败 / 另一个句柄先重建）
 * 的状态下索引**不会**被判 stale，检索面永久保留已遗忘记录，recall 还会把它回注出去
 * （实测：遗忘 1 条后 health 报 indexStale=false，search 仍返回它，recall 注入 hits=2）。
 * 现在把遗忘集的**规模**一并纳入基线：只多读一次 listForgotten，成本与文件大小无关。
 */
export async function isIndexStale(store, index) {
  if (index === null) return true
  const ids = await store.listRecordIds()
  const baseline = Number.isInteger(index.sourceCount) ? index.sourceCount : index.indexedCount
  // T-09（0.15.4）：新鲜度判定必须**总是**读遗忘集，不能因为前面的基线相等就跳过。
  //
  // 缺陷：旧实现在 `baseline !== ids.length` 时提前 `return true`，也就跳过了下面的
  // `listForgotten()`。于是「health 会不会抛错」取决于**索引是否刚好新鲜**——
  // 库坏了而索引恰好匹配时静默返回 stale=true，库好的时候反而因为读遗忘账本抛错。
  // 同一个健康面，抛不抛由无关变量决定，调用方根本无法据以判断。
  //
  // 现在：先把遗忘集读出来（读失败就如实抛，判据一致），再按两个条件判 stale。
  const forgottenCount = typeof store.listForgotten === 'function' ? store.listForgotten().length : 0
  if (baseline !== ids.length) return true
  // 已遗忘集规模变了 → 索引里可能还留着已遗忘正文，必须重建
  const indexForgotten = Number.isInteger(index.forgottenCount) ? index.forgottenCount : 0
  return forgottenCount !== indexForgotten
}
