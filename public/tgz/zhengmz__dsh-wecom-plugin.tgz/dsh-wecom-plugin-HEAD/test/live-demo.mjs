// Live end-to-end feasibility demo.
//
// Boots a real, isolated DeepSeek Harness instance (profile `wecom-plugin`,
// DSH_HOME=.dsh-demo-home) with the dsh-wecom-plugin plugin enabled and pointed
// at a local mock WeCom gateway. A real LLM (configured in the demo home's
// settings.yaml) answers, and the reply is captured on the mock gateway side.
//
// Run:  node test/live-demo.mjs
//
// This proves the full path: WeCom message → plugin bridge → real DSH agent →
// real LLM → reply → WeCom — without needing real WeCom credentials.

import { spawn } from 'node:child_process';
import { readFileSync, existsSync } from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { MockWeComServer } from './mock-wecom.js';

// Resolve `ws` through the workspace (plugin node_modules symlink) or DSH_HOME.
const require = createRequire(import.meta.url);
const ws = require('ws');

// Isolated demo home: env override, else <workspace root>/.dsh-demo-home.
const here = path.dirname(fileURLToPath(import.meta.url));
const WORKSPACE_ROOT = path.resolve(here, '..', '..');
const DEMO_HOME = process.env.DSH_DEMO_HOME || path.join(WORKSPACE_ROOT, '.dsh-demo-home');
const MOCK_PORT = 4180;
const BOT_ID = 'demo-bot';
const SECRET = 'demo-secret';

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Optional secrets: load KEY=VALUE lines from .dsh-demo-home/.env so the key
// never has to pass through this session's logs. Example:
//   <你的LLM_API_KEY环境变量名>=...
function loadDotEnv() {
  const path = `${DEMO_HOME}/.env`;
  if (!existsSync(path)) return {};
  const env = {};
  for (const line of readFileSync(path, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (m) env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
  return env;
}

async function waitFor(predicate, { timeoutMs, stepMs = 250, label }) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const value = predicate();
    if (value) return value;
    await delay(stepMs);
  }
  throw new Error(`timeout waiting for: ${label}`);
}

const server = await MockWeComServer.start({ port: MOCK_PORT, botId: BOT_ID, secret: SECRET, wsModule: ws });
console.log(`[live] mock WeCom gateway on ws://127.0.0.1:${MOCK_PORT}`);

const child = spawn('dsh', [
  '--profile', 'wecom-plugin',
  '--patch', path.join(DEMO_HOME, 'profiles', 'wecom-plugin', 'cordis.patch.mock.yml')
], {
  cwd: WORKSPACE_ROOT,
  env: { ...process.env, ...loadDotEnv(), DSH_HOME: DEMO_HOME },
  stdio: ['ignore', 'pipe', 'pipe']
});
child.stdout.on('data', (d) => process.stdout.write(`[dsh] ${d}`));
child.stderr.on('data', (d) => process.stderr.write(`[dsh:err] ${d}`));

let exitCode;
child.on('exit', (code) => {
  exitCode = code;
  console.log(`[live] dsh child exited with code ${code}`);
});

try {
  console.log('[live] waiting for the plugin to connect to the mock gateway...');
  await waitFor(() => [...server.state.values()].some((s) => s.authed), {
    timeoutMs: 90_000,
    label: 'plugin authenticated to mock gateway'
  });
  console.log('[live] ✅ plugin connected & authenticated');

  const prompt = '请用一两句话简单介绍一下你自己，并说明你现在通过什么通道在和我对话。';
  console.log(`[live] pushing user message: ${prompt}`);
  server.pushMessage({ chatid: 'live-chat', userid: 'tester', text: prompt });

  console.log('[live] waiting for the real agent reply (LLM may take a while)...');
  const start = Date.now();
  const replyFrame = await waitFor(() => {
    const frames = server.outbound.filter(
      (f) =>
        f.cmd === 'aibot_respond_msg' &&
        f.headers?.req_id?.startsWith('cb-') &&
        f.body?.msgtype === 'stream' &&
        f.body?.stream?.finish === true &&
        typeof f.body?.stream?.content === 'string' &&
        f.body?.stream?.content.trim() !== ''
    );
    return frames.length > 0 ? frames[frames.length - 1] : undefined;
  }, { timeoutMs: 240_000, label: 'agent reply on the gateway' });
  const elapsed = ((Date.now() - start) / 1000).toFixed(1);

  console.log(`\n${'='.repeat(64)}`);
  console.log(`[live] ✅ REAL AGENT REPLY after ${elapsed}s:`);
  console.log('----------------');
  console.log(replyFrame.body?.stream?.content ?? '(no content)');
  console.log('================');
  console.log('[live] END-TO-END FEASIBILITY VERIFIED: WeCom(mock) → plugin → DSH agent → LLM → reply');
} finally {
  console.log('[live] cleaning up...');
  child.kill('SIGTERM');
  await delay(1500);
  if (exitCode === undefined) child.kill('SIGKILL');
  await server.close();
  console.log('[live] done.');
}
