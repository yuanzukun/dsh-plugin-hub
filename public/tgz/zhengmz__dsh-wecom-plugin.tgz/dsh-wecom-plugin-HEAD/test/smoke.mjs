// Self-contained feasibility smoke test (no DSH runtime, no LLM, no network).
//
// Proves the two halves of the bridge:
//   1. WeCom aibot WebSocket protocol round trip (client ↔ mock gateway),
//      aligned with the official @wecom/aibot-node-sdk wire behavior:
//      no-cmd acks, stream replies, heartbeat acks, event callbacks,
//      stream-expiry fallback (846608).
//   2. Bridge logic: inbound → agent session → assistant text → outbound reply.
//
// The "agent" is a stub that echoes; in production it is a real DSH agent
// driven through ctx.agents (see README for the live end-to-end run).

import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import { MockWeComServer } from './mock-wecom.js';
import { WeComAibotClient, StreamExpiredError } from '../src/aibot-client.js';
import { Bridge, splitText } from '../src/bridge.js';

// Resolve the `ws` module from the DSH installation (no npm install needed).
const require = createRequire(import.meta.url);
const ws = require('ws');

const BOT_ID = 'demo-bot';
const SECRET = 'demo-secret';

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// ---------------------------------------------------------------- stubs

/** A fake DSH agent that echoes the user text back after a short delay. */
class EchoAgent {
  constructor(sessionId, ctx, meta) {
    this.session = { id: sessionId };
    this.ctx = ctx;
    this.meta = meta || {};
    this.cwd = meta?.cwd || '';
    this.received = [];
  }

  followup(message) {
    this.received.push(message);
  }

  async whenIdle() {
    await delay(30);
    const last = this.received[this.received.length - 1];
    const text = last?.content?.[0]?.text ?? '(empty)';
    this.ctx._emit('session/event', this.session, {
      type: 'assistant/message',
      data: { message: { content: [{ type: 'text', text: `Echo: ${text}` }] } }
    });
    this.ctx._emit('session/event', this.session, {
      type: 'turn/end',
      data: { reason: { kind: 'complete' } }
    });
  }
}

function makeStubCtx() {
  const listeners = new Map();
  const agents = new Map(); // sessionId -> EchoAgent
  const registeredTools = [];
  const ctx = {
    registeredTools,
    services: {
      agentDefaultModel: {
        currentSelection: () => ({ provider: 'default-provider', model: 'default-model' })
      },
      loader: {},
      sessions: { flush: async () => {} },
      attachments: {
        saveImages: async (images) =>
          images.map((img, i) => ({
            attachmentId: `mock-att-${i}`,
            mediaType: img.mediaType,
            bytes: img.data.length,
            width: 1,
            height: 1,
            name: img.name
          })),
        readImage: async (ref) => ({ ref, data: new Uint8Array([0xff, 0xd8, 0xff, 0xe0]) })
      },
      agents: {
        create: async ({ sessionId, meta }) => {
          const agent = new EchoAgent(sessionId, ctx, meta);
          agents.set(sessionId, agent);
          // Mirror production: agents.create publishes agent/created, which the
          // bridge uses to register wecom_send_image into the agent scope.
          ctx._emit('agent/created', { agent });
          return { agent, dispose: async () => agents.delete(sessionId) };
        }
      }
    },
    tools: {
      register(tool) {
        registeredTools.push(tool);
      }
    },
    get(name) {
      return this.services[name];
    },
    on(event, cb) {
      if (!listeners.has(event)) listeners.set(event, []);
      listeners.get(event).push(cb);
      return () => {
        const arr = listeners.get(event) || [];
        const i = arr.indexOf(cb);
        if (i >= 0) arr.splice(i, 1);
      };
    },
    _emit(event, ...args) {
      let result;
      for (const cb of listeners.get(event) || []) result = cb(...args);
      return result;
    },
    logger: console
  };
  return ctx;
}

function makeConfig(overrides = {}) {
  return {
    botId: BOT_ID,
    secret: SECRET,
    websocketUrl: '', // set after the mock starts
    allowedUserIds: [],
    workspaces: {},
    stateFile: path.join(os.tmpdir(), `dsh-wecom-smoke-${process.pid}.json`),
    pluginVersion: '0.1.0',
    subscribeExtra: {},
    welcomeText: '',
    syncUserPrefix: '📱 你在 Web GUI 发送：',
    logFile: path.join(os.tmpdir(), `dsh-wecom-smoke-${process.pid}.log`),
    reconnectAfterKick: true,
    kickReconnectDelayMs: 1500,
    sendRetryMs: 8000,
    approval: {
      enabled: true,
      timeoutMs: 30000,
      approveWords: ['同意', '批准', '允许', 'yes', 'approve', 'allow'],
      rejectWords: ['拒绝', '不同意', '不允许', '不批准', 'no', 'reject', 'deny']
    },
    agent: {
      preset: '',
      cwd: '',
      provider: '',
      model: '',
      reasoningEffort: '',
      maxMessageLength: 4000,
      idleTimeoutMs: 0,
      sessionScope: 'chat',
      groupMention: 'none',
      botName: ''
    },
    ...overrides
  };
}

// ------------------------------------------------------------------ test

let passed = 0;
function ok(name) {
  passed += 1;
  console.log(`  ✔ ${name}`);
}

/** Find respond frames carrying a final (finish=true) stream with content. */
function finalStreamFrames(server, predicate) {
  return server.outbound.filter(
    (f) =>
      f.cmd === 'aibot_respond_msg' &&
      f.body?.msgtype === 'stream' &&
      f.body?.stream?.finish === true &&
      (predicate ? predicate(f.body.stream.content) : true)
  );
}

const server = await MockWeComServer.start({ botId: BOT_ID, secret: SECRET, wsModule: ws });

try {
  const url = `ws://127.0.0.1:${server.port}`;

  // ---- 1. protocol round trip: client ↔ mock gateway --------------------
  console.log('\n[1] aibot protocol round trip (client ↔ mock WeCom gateway)');
  let received = null;
  const events = [];
  const client = new WeComAibotClient({
    botId: BOT_ID,
    secret: SECRET,
    websocketUrl: url,
    pluginVersion: '0.1.0',
    onMessage: (input) => {
      received = input;
    },
    onEvent: (event) => events.push(event),
    logger: console,
    WebSocketImpl: ws,
    // Anti-kick suppression is the explicit opt-out; the default reconnects.
    reconnectAfterKick: false
  });
  await client.start();
  await delay(100); // let subscribe settle
  assert.equal(server.state.size, 1, 'client should hold one connection');

  server.pushMessage({ chatid: 'chat-1', userid: 'user-1', text: '你好' });
  await delay(100);
  assert.ok(received, 'client should receive the pushed message');
  assert.equal(received.chatId, 'chat-1');
  assert.equal(received.userId, 'user-1');
  assert.equal(received.text, '你好');
  ok('subscribe + inbound message round trip');

  // client reply reaches the gateway as a STREAM frame (official format)
  await received.reply('pong');
  await delay(100);
  const respond = server.outbound.find((f) => f.cmd === 'aibot_respond_msg');
  assert.ok(respond, 'gateway should see one respond frame');
  assert.equal(respond.body.msgtype, 'stream', 'reply body must be a stream');
  assert.equal(respond.body.stream.finish, true, 'single-shot reply finishes');
  assert.equal(respond.body.stream.content, 'pong');
  ok('outbound stream reply (aibot_respond_msg/stream) reaches the gateway');

  // quote fallback: message with only a quote becomes the quote text
  received = null;
  server.pushMessage({
    chatid: 'chat-1',
    userid: 'user-1',
    text: '',
    quote: { msgtype: 'text', text: { content: '被引用的话' } }
  });
  await delay(100);
  assert.ok(received, 'quote-only message should still be delivered');
  assert.equal(received.text, '被引用的话', 'quote text becomes the message body');
  ok('quote-only message falls back to the quoted text');

  // ---- 2. auth failure is rejected --------------------------------------
  const bad = new WeComAibotClient({
    botId: BOT_ID,
    secret: 'wrong-secret',
    websocketUrl: url,
    onMessage: () => {},
    logger: { log() {}, error() {} },
    WebSocketImpl: ws
  });
  await bad.start();
  await delay(150);
  const authed = [...server.state.values()].filter((s) => s.authed).length;
  assert.equal(authed, 1, 'only the valid-credential client is authed');
  bad.stop();
  ok('invalid credentials are rejected by the gateway');

  // ---- 3. event callbacks ------------------------------------------------
  console.log('\n[1b] event callbacks (enter_check_update / disconnected_event)');
  // enter_check_update → version reply
  server.pushEvent({ eventtype: 'enter_check_update' });
  await delay(100);
  const versionReply = server.outbound.find((f) => f.cmd === 'ww_ai_robot_enter_event');
  assert.ok(versionReply, 'client answers the version probe');
  assert.equal(versionReply.body.version, '0.1.0');
  ok('enter_check_update answered with ww_ai_robot_enter_event {version}');

  // other events are surfaced
  server.pushEvent({ eventtype: 'enter_chat' });
  await delay(100);
  assert.ok(events.some((e) => e.type === 'enter_chat'), 'enter_chat surfaced via onEvent');
  ok('non-version events surfaced via onEvent');

  // disconnected_event → kicked, no auto-reconnect
  server.pushEvent({ eventtype: 'disconnected_event' });
  await delay(200);
  assert.equal(client.kicked, true, 'client marks itself as kicked');
  assert.equal(client.running, true, 'client stays stopped after kick (no auto-reconnect)');
  ok('disconnected_event suppresses auto-reconnect (anti mutual-kick)');

  client.stop();

  // ---- 3b. reconnect after kick (default reconnectAfterKick=true) ---------
  console.log('\n[1c] reconnect after kick (disconnected_event → grace → re-subscribe)');
  server.outbound.length = 0;
  const kickClient = new WeComAibotClient({
    botId: BOT_ID,
    secret: SECRET,
    websocketUrl: url,
    pluginVersion: '0.1.0',
    onMessage: () => {},
    onEvent: () => {},
    logger: console,
    WebSocketImpl: ws,
    reconnectAfterKick: true,
    kickReconnectDelayMs: 1200
  });
  await kickClient.start();
  await delay(100);
  const subsBefore = server.subscribes.length;
  server.pushEvent({ eventtype: 'disconnected_event' });
  kickClient.ws.close(); // gateway drops the connection after the event
  await delay(200);
  assert.equal(kickClient.consecutiveKicks, 1, 'a reconnect attempt is scheduled after the kick');
  // After the grace delay the client re-subscribes (the "duplicate" is gone).
  await delay(1600);
  assert.equal(kickClient.kicked, false, 'kicked flag resets on reconnect');
  assert.equal(kickClient.consecutiveKicks, 0, 'consecutive-kick counter resets on success');
  assert.equal(server.subscribes.length, subsBefore + 1, 'a fresh subscribe re-establishes the bot');
  ok('kicked connection reconnects after the grace delay (no permanent outage)');
  kickClient.stop();
  server.outbound.length = 0;

  // ---- 4. bridge: message → agent session → reply -----------------------
  console.log('\n[2] bridge logic (inbound → DSH agent session → outbound reply)');
  const ctx = makeStubCtx();
  const cfg = makeConfig({ websocketUrl: url });
  const bridge = new Bridge(
    ctx,
    cfg,
    {
      WebSocketImpl: ws,
      SessionId: (id) => id,
      createUserMessage: ({ content, source }) => ({ content, source })
    }
  );
  await bridge.start();
  await delay(100);

  server.pushMessage({ chatid: 'chat-A', userid: 'alice', text: 'hello' });
  await delay(250);
  const helloFrames = finalStreamFrames(server, (c) => /^Echo: hello$/.test(c));
  assert.ok(helloFrames.length >= 1, 'final stream reply with the echo text');
  // thinking placeholder came before the final
  const thinking = server.outbound.find(
    (f) => f.cmd === 'aibot_respond_msg' && f.body?.msgtype === 'stream' && f.body?.stream?.finish === false
  );
  assert.ok(thinking, 'thinking placeholder (finish=false) sent first');
  assert.equal(bridge.chats.size, 1, 'one chat session created');
  ok('inbound → agent session → thinking + final stream reply → gateway');

  // multi-turn keeps the same session
  const before = [...bridge.chats.values()][0].agent.session.id;
  server.pushMessage({ chatid: 'chat-A', userid: 'alice', text: 'again' });
  await delay(250);
  const after = [...bridge.chats.values()][0].agent.session.id;
  assert.equal(after, before, 'second turn reuses the same agent session');
  ok('multi-turn reuses one persistent agent session');

  // dedup: same msgid pushed twice → only one turn (thinking + final = 2 frames)
  const nBefore = server.outbound.length;
  const frame = server.pushMessage({ chatid: 'chat-A', userid: 'alice', text: 'dup' });
  server.broadcast(frame); // replay the exact same frame (same msgid)
  await delay(250);
  assert.equal(server.outbound.length, nBefore + 2, 'dedup should collapse the replayed frame');
  ok('duplicate msgid is deduplicated');

  // allowlist: a second bridge with an explicit allowlist blocks others
  const ctx2 = makeStubCtx();
  const cfg2 = makeConfig({ websocketUrl: url, allowedUserIds: ['alice'] });
  const bridge2 = new Bridge(
    ctx2,
    cfg2,
    {
      WebSocketImpl: ws,
      SessionId: (id) => id,
      createUserMessage: ({ content, source }) => ({ content, source })
    }
  );
  await bridge2.start();
  await delay(100);
  server.pushMessage({ chatid: 'chat-B', userid: 'mallory', text: 'hi' });
  await delay(250);
  const denies = finalStreamFrames(server, (c) => /没有权限/.test(c));
  assert.ok(denies.length >= 1, 'blocked user sees the permission denial');
  assert.equal(bridge2.chats.size, 0, 'no session is created for blocked users');
  ok('allowlist blocks unauthorized users');

  await bridge.stop();
  await bridge2.stop();
  server.outbound.length = 0;

  // ---- 5. in-chat approval answering -------------------------------------
  console.log('\n[2b] in-chat approval answering (approval/request → WeCom → reply)');
  const ctxApr = makeStubCtx();
  const cfgApr = makeConfig({ websocketUrl: url });
  const bridgeApr = new Bridge(ctxApr, cfgApr, { WebSocketImpl: ws, SessionId: (id) => id, createUserMessage: ({ content, source }) => ({ content, source }) });
  await bridgeApr.start();
  await delay(100);

  // Register a WeCom-owned session so the bridge claims the request.
  bridgeApr.sessionChat.set('wecom-sess-1', 'chat-APR');

  let approvalOutcome;
  const approvalPromise = ctxApr._emit('approval/request', {
    agent: { session: { id: 'wecom-sess-1' } },
    toolName: 'bash',
    reason: '需要升级沙箱权限来执行命令'
  }, () => {
    throw new Error('approval was delegated (next called)');
  }).then((outcome) => {
    approvalOutcome = outcome;
  });
  await delay(200);

  // The prompt should have been sent proactively to the chat.
  const promptFrame = server.outbound.find(
    (f) => f.cmd === 'aibot_send_msg' && /需要你的授权/.test(f.body?.markdown?.content ?? '')
  );
  assert.ok(promptFrame, 'approval prompt is sent to WeCom');
  const codeMatch = /同意 ([0-9A-F]{4})/.exec(promptFrame.body.markdown.content);
  assert.ok(codeMatch, 'prompt carries a one-time code');
  const code = codeMatch[1];
  ok('approval request forwarded to WeCom with a one-time code');

  // A reply WITHOUT the code keeps waiting (hint, not consumed as answer).
  server.pushMessage({ chatid: 'chat-APR', userid: 'alice', text: '同意' });
  await delay(150);
  const hint = server.outbound.find(
    (f) => f.cmd === 'aibot_respond_msg' && f.body?.msgtype === 'stream' && f.body?.stream?.finish === true && /请回复「同意/.test(f.body.stream.content)
  );
  assert.ok(hint, 'a code-less reply gets a hint and stays pending');
  assert.equal(bridgeApr.pendingApprovals.size, 1, 'approval still pending after a code-less reply');
  ok('code-less reply is hinted, not treated as an answer');

  // The correct reply resolves the approval.
  server.pushMessage({ chatid: 'chat-APR', userid: 'alice', text: `同意 ${code}` });
  await delay(150);
  await approvalPromise;
  assert.equal(approvalOutcome, 'allowed-once', 'approval resolves to allowed-once');
  assert.equal(bridgeApr.pendingApprovals.size, 0, 'no pending approval remains');
  ok('approve reply resolves the request to allowed-once');

  // A different session (GUI-owned) is delegated via next().
  server.outbound.length = 0;
  let nextCalled = false;
  const delegated = ctxApr._emit('approval/request', {
    agent: { session: { id: 'gui-sess-1' } },
    toolName: 'fs',
    reason: 'GUI 会话的请求'
  }, async () => {
    nextCalled = true;
    return 'unavailable';
  });
  assert.equal(await delegated, 'unavailable', 'delegated outcome comes from the fallback');
  assert.equal(nextCalled, true, 'GUI-owned request is delegated via next()');
  const guiPrompt = server.outbound.find((f) => f.cmd === 'aibot_send_msg' && /需要你的授权/.test(f.body?.markdown?.content ?? ''));
  assert.equal(guiPrompt, undefined, 'no approval prompt is sent for GUI-owned agents');
  ok('GUI-owned approval requests are delegated (next)');

  await bridgeApr.stop();
  server.outbound.length = 0;

  // ---- 5b. wecom_send_image tool (native send over the bridge connection) -
  console.log('\n[2c] wecom_send_image tool (native image send, no second connection)');
  const ctxT = makeStubCtx();
  const cfgT = makeConfig({ websocketUrl: url });
  const bridgeT = new Bridge(ctxT, cfgT, { WebSocketImpl: ws, SessionId: (id) => id, createUserMessage: ({ content, source }) => ({ content, source }) });
  await bridgeT.start();
  await delay(100);
  // Scoped registration: the tool is registered into the agent's own scope when
  // the WeCom-linked agent is published (agent/created), not at bridge start —
  // drive one inbound message to create the chat/agent first.
  server.pushMessage({ chatid: 'chat-TOOL', userid: 'alice', text: 'tool test' });
  await delay(250);
  const toolSessionId = [...bridgeT.chats.values()][0].agent.session.id;
  const sendImg = ctxT.registeredTools.find((t) => t.name === 'wecom_send_image');
  assert.ok(sendImg, 'wecom_send_image tool is registered (per WeCom agent)');

  const fs = await import('node:fs');
  const pngPath = path.join(os.tmpdir(), `wecom-send-${process.pid}.png`);
  fs.writeFileSync(pngPath, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00]));
  server.outbound.length = 0;
  const toolResult = await sendImg.execute(
    { path: pngPath },
    { agent: { session: { id: toolSessionId } }, signal: new AbortController().signal }
  );
  assert.ok(/已发送图片/.test(String(toolResult)), 'tool returns a success summary');
  const uploads = server.outbound.filter((f) => f.cmd?.startsWith('aibot_upload_media_'));
  assert.equal(uploads.length, 3, 'three-step upload (init/chunk/finish) performed');
  const mediaSendT = server.outbound.find((f) => f.cmd === 'aibot_send_msg' && f.body?.msgtype === 'image' && f.body?.image?.media_id);
  assert.ok(mediaSendT, 'image is sent as WeCom media');
  ok('wecom_send_image uploads + sends the file over the bridge connection');

  // a non-image file is refused
  const txtPath = path.join(os.tmpdir(), `wecom-send-${process.pid}.txt`);
  fs.writeFileSync(txtPath, 'not an image');
  await assert.rejects(
    sendImg.execute({ path: txtPath }, { agent: { session: { id: toolSessionId } }, signal: new AbortController().signal }),
    /does not look like/
  );
  ok('wecom_send_image refuses non-image files');

  // an un-routed (GUI) session is refused
  await assert.rejects(
    sendImg.execute({ path: pngPath }, { agent: { session: { id: 'gui-sess-tool' } }, signal: new AbortController().signal }),
    /only works in a WeCom-owned session/
  );
  ok('wecom_send_image refuses non-WeCom sessions');

  await bridgeT.stop();
  server.outbound.length = 0;

  // ---- 6. stream expiry fallback (errcode 846608) ------------------------
  console.log('\n[3] stream-expiry fallback (errcode 846608 → aibot_send_msg)');
  server.replyErrcode = 846608;
  const ctx3 = makeStubCtx();
  const cfg3 = makeConfig({ websocketUrl: url });
  const bridge3 = new Bridge(
    ctx3,
    cfg3,
    {
      WebSocketImpl: ws,
      SessionId: (id) => id,
      createUserMessage: ({ content, source }) => ({ content, source })
    }
  );
  await bridge3.start();
  await delay(100);
  server.pushMessage({ chatid: 'chat-C', userid: 'carol', text: 'expire-me' });
  await delay(250);
  const proactive = server.outbound.find(
    (f) => f.cmd === 'aibot_send_msg' && /^Echo: expire-me$/.test(f.body?.markdown?.content ?? '')
  );
  assert.ok(proactive, 'expired stream falls back to a proactive markdown send');
  ok(`stream expired (846608) → degraded to aibot_send_msg`);
  server.replyErrcode = 0;
  await bridge3.stop();
  server.outbound.length = 0;

  // ---- 6. workspace switching (/cd) -------------------------------------
  console.log('\n[4] workspace switching (/cd)');
  const tmpWs = await import('node:fs').then((fs) => fs.mkdtempSync('/tmp/wecom-ws-'));
  const ctx4 = makeStubCtx();
  const cfg4 = makeConfig({ websocketUrl: url, workspaces: { tmp: tmpWs } });
  const bridge4 = new Bridge(
    ctx4,
    cfg4,
    {
      WebSocketImpl: ws,
      SessionId: (id) => id,
      createUserMessage: ({ content, source }) => ({ content, source })
    }
  );
  await bridge4.start();
  await delay(100);

  // default cwd = agent.cwd (empty → process.cwd)
  server.pushMessage({ chatid: 'chat-D', userid: 'dave', text: 'hi' });
  await delay(250);
  let chat = bridge4.chats.get('wecom:chat-D');
  assert.equal(chat.cwd, process.cwd(), 'default workspace is process.cwd()');
  ok('default workspace = agent.cwd');

  // /cd via alias
  server.pushMessage({ chatid: 'chat-D', userid: 'dave', text: `/cd tmp` });
  await delay(250);
  chat = bridge4.chats.get('wecom:chat-D');
  assert.equal(chat.cwd, tmpWs, 'alias switches to the mapped directory');
  const cdAliasReply = finalStreamFrames(server, (c) => /已切换到工作目录/.test(c));
  assert.ok(cdAliasReply.length >= 1, 'confirm message after /cd');
  ok('/cd <alias> switches workspace');

  // raw absolute path is REJECTED by default (cdAllowPaths=false) — security
  server.pushMessage({ chatid: 'chat-D', userid: 'dave', text: `/cd ${tmpWs}` });
  await delay(250);
  chat = bridge4.chats.get('wecom:chat-D');
  assert.equal(chat.cwd, tmpWs, 'raw path leaves the workspace unchanged by default');
  const denyReply = finalStreamFrames(server, (c) => /未配置的工作区/.test(c));
  assert.ok(denyReply.length >= 1, 'raw path is refused without cdAllowPaths');
  ok('/cd <raw path> is refused by default (security)');

  // /cd to a nonexistent alias is rejected and keeps the old workspace
  server.pushMessage({ chatid: 'chat-D', userid: 'dave', text: '/cd no-such-alias' });
  await delay(250);
  chat = bridge4.chats.get('wecom:chat-D');
  assert.equal(chat.cwd, tmpWs, 'bad alias keeps the previous workspace');
  const badReply = finalStreamFrames(server, (c) => /未配置的工作区/.test(c));
  assert.ok(badReply.length >= 1, 'error message for a bad alias');
  ok('/cd to an unknown workspace is rejected');

  // with cdAllowPaths:true the raw absolute path is honoured again
  const ctx4b = makeStubCtx();
  const cfg4b = makeConfig({ websocketUrl: url, agent: { cdAllowPaths: true }, workspaces: { tmp: tmpWs } });
  const bridge4b = new Bridge(ctx4b, cfg4b, { WebSocketImpl: ws, SessionId: (id) => id, createUserMessage: ({ content, source }) => ({ content, source }) });
  await bridge4b.start();
  await delay(100);
  server.pushMessage({ chatid: 'chat-D', userid: 'dave', text: `/cd ${tmpWs}` });
  await delay(250);
  assert.equal(bridge4b.chats.get('wecom:chat-D').cwd, tmpWs, 'cdAllowPaths=true allows raw paths');
  ok('/cd <raw path> works when cdAllowPaths=true');
  await bridge4b.stop();

  await bridge4.stop();
  server.outbound.length = 0;

  // ---- 6. reload survival: same chat reuses the same session ------------
  console.log('\n[5] reload survival (deterministic session id + state file)');
  const stateFile = path.join(os.tmpdir(), `dsh-wecom-reload-${process.pid}.json`);
  const cfgA = makeConfig({ websocketUrl: url, stateFile });
  const bridgeA = new Bridge(makeStubCtx(), cfgA, { WebSocketImpl: ws, SessionId: (id) => id, createUserMessage: ({ content, source }) => ({ content, source }) });
  await bridgeA.start();
  await delay(100);
  server.pushMessage({ chatid: 'chat-E', userid: 'erin', text: 'first' });
  await delay(250);
  const sidA = bridgeA.chats.get('wecom:chat-E').agent.session.id;
  ok(`session created: ${sidA.slice(0, 18)}…`);

  // simulate a plugin reload: stop the bridge, start a fresh one (same state file)
  await bridgeA.stop();
  server.outbound.length = 0;
  const bridgeB = new Bridge(makeStubCtx(), cfgA, { WebSocketImpl: ws, SessionId: (id) => id, createUserMessage: ({ content, source }) => ({ content, source }) });
  await bridgeB.start();
  await delay(100);
  server.pushMessage({ chatid: 'chat-E', userid: 'erin', text: 'second' });
  await delay(250);
  const sidB = bridgeB.chats.get('wecom:chat-E').agent.session.id;
  assert.equal(sidB, sidA, 'same chat after reload reuses the same session id');
  ok('after reload the same chat reuses the same session (no duplicate)');
  await bridgeB.stop();
  server.outbound.length = 0;

  // ---- 6b. /reset starts a genuinely NEW session -------------------------
  console.log('\n[5b] /reset clears context (new session id, empty log)');
  const ctxR = makeStubCtx();
  const cfgR = makeConfig({ websocketUrl: url });
  const bridgeR = new Bridge(ctxR, cfgR, { WebSocketImpl: ws, SessionId: (id) => id, createUserMessage: ({ content, source }) => ({ content, source }) });
  await bridgeR.start();
  await delay(100);
  server.pushMessage({ chatid: 'chat-R', userid: 'ryan', text: 'hello' });
  await delay(250);
  const sidBefore = bridgeR.chats.get('wecom:chat-R').agent.session.id;
  server.pushMessage({ chatid: 'chat-R', userid: 'ryan', text: '/reset' });
  await delay(250);
  server.pushMessage({ chatid: 'chat-R', userid: 'ryan', text: 'fresh' });
  await delay(250);
  const sidAfter = bridgeR.chats.get('wecom:chat-R').agent.session.id;
  assert.notEqual(sidAfter, sidBefore, '/reset yields a different session id');
  const resetReply = finalStreamFrames(server, (c) => /已清空上下文/.test(c));
  assert.ok(resetReply.length >= 1, '/reset confirms the reset');
  ok('/reset starts a genuinely new session (epoch bump)');
  await bridgeR.stop();
  server.outbound.length = 0;

  // ---- 7. GUI → WeCom sync ---------------------------------------------
  console.log('\n[6] GUI → WeCom sync (user messages in a wecom session)');
  const ctx5 = makeStubCtx();
  const cfg5 = makeConfig({ websocketUrl: url });
  const bridge5 = new Bridge(ctx5, cfg5, { WebSocketImpl: ws, SessionId: (id) => id, createUserMessage: ({ content, source }) => ({ content, source }) });
  await bridge5.start();
  await delay(100);
  // create the chat via a WeCom message so the session is registered
  server.pushMessage({ chatid: 'chat-F', userid: 'frank', text: 'hello' });
  await delay(250);
  const chat5 = bridge5.chats.get('wecom:chat-F');
  const sess5 = chat5.agent.session;

  // GUI-originated user message → forwarded to WeCom (aibot_send_msg)
  // The GUI stamps its user messages with rpcId; that is the discriminator.
  const nBefore5 = server.outbound.length;
  ctx5._emit('session/event', sess5, {
    type: 'user/message',
    data: { content: [{ type: 'text', text: '我在 GUI 里追加的消息' }], source: { kind: 'user', rpcId: 'rpc-gui-1' } }
  });
  await delay(150);
  const guiMsg = server.outbound.slice(nBefore5).find((f) => f.cmd === 'aibot_send_msg' && /GUI 里追加的消息/.test(f.body?.markdown?.content ?? ''));
  assert.ok(guiMsg, 'GUI user message is forwarded to WeCom');
  assert.match(guiMsg.body.markdown.content, /📱 你在 Web GUI 发送：/, 'echo is labeled as the user’s own GUI input');
  ok('GUI user message → aibot_send_msg (labeled) → WeCom');

  // assistant output of that GUI turn → only the FINAL conclusion is forwarded
  ctx5._emit('session/event', sess5, {
    type: 'assistant/message',
    data: { message: { content: [{ type: 'text', text: '中间步骤一：我先查一下…' }] } }
  });
  ctx5._emit('session/event', sess5, {
    type: 'assistant/message',
    data: { message: { content: [{ type: 'text', text: '中间步骤二：搜索结果不理想…' }] } }
  });
  // final message: a clean conclusion (the scoped section shapes the model; structurally we relay only the last message text)
  ctx5._emit('session/event', sess5, {
    type: 'assistant/message',
    data: {
      message: {
        content: [
          { type: 'text', text: '## 最终结论\n这是 GUI 触发的最终结论，含表格与来源。' }
        ]
      }
    }
  });
  ctx5._emit('session/event', sess5, { type: 'turn/end', data: { reason: { kind: 'complete' } } });
  await delay(150);
  const guiReply = server.outbound.slice(nBefore5).find((f) => f.cmd === 'aibot_send_msg' && /最终结论/.test(f.body?.markdown?.content ?? ''));
  assert.ok(guiReply, 'assistant reply of a GUI turn is forwarded to WeCom');
  assert.equal(guiReply.body.markdown.content, '## 最终结论\n这是 GUI 触发的最终结论，含表格与来源。', 'the last assistant message text is forwarded as-is');
  const midStep = server.outbound.slice(nBefore5).some((f) => f.cmd === 'aibot_send_msg' && /中间步骤/.test(f.body?.markdown?.content ?? ''));
  assert.equal(midStep, false, 'intermediate step narration is NOT forwarded (only the conclusion)');
  ok('GUI-originated turn → only the last message text → WeCom');

  // bridge-relayed messages (kind 'user', NO rpcId — not GUI input) are NOT echoed
  const nBefore6 = server.outbound.length;
  ctx5._emit('session/event', sess5, {
    type: 'user/message',
    data: { content: [{ type: 'text', text: '不应转发' }], source: { kind: 'user' } }
  });
  await delay(150);
  assert.equal(server.outbound.length, nBefore6, 'bridge-relayed messages are not echoed to WeCom');
  ok('bridge-relayed messages are not echoed back');

  await bridge5.stop();
  server.outbound.length = 0;

  // ---- 8. session isolation scope (chat-user) ---------------------------
  console.log('\n[7] session isolation (sessionScope=chat-user)');
  const ctx6 = makeStubCtx();
  const cfg6 = makeConfig({ websocketUrl: url, agent: { sessionScope: 'chat-user' } });
  const bridge6 = new Bridge(ctx6, cfg6, { WebSocketImpl: ws, SessionId: (id) => id, createUserMessage: ({ content, source }) => ({ content, source }) });
  await bridge6.start();
  await delay(100);

  // two different members in the same group chat → isolated sessions
  server.pushMessage({ chatid: 'group-1', userid: 'alice', text: 'hi' });
  await delay(250);
  server.pushMessage({ chatid: 'group-1', userid: 'bob', text: 'hello' });
  await delay(250);
  assert.equal(bridge6.chats.size, 2, 'two members in one group get two sessions');
  const sidAlice = bridge6.chats.get('wecom:group-1:alice').agent.session.id;
  const sidBob = bridge6.chats.get('wecom:group-1:bob').agent.session.id;
  assert.notEqual(sidAlice, sidBob, 'alice and bob have different sessions');
  ok('group members are isolated (one session per chat+user)');

  // the same member continues the same session
  server.pushMessage({ chatid: 'group-1', userid: 'alice', text: 'again' });
  await delay(250);
  const sidAlice2 = bridge6.chats.get('wecom:group-1:alice').agent.session.id;
  assert.equal(sidAlice2, sidAlice, 'same member reuses the same session');
  ok('same member reuses their session');

  // DMs: chatId == userid, still isolated per user
  server.pushMessage({ chatid: 'user-alice', userid: 'alice', text: 'dm1' });
  await delay(250);
  server.pushMessage({ chatid: 'user-carol', userid: 'carol', text: 'dm2' });
  await delay(250);
  assert.equal(bridge6.chats.size, 4, 'DMs and group member sessions all isolated');
  ok('DMs isolated per user');

  await bridge6.stop();
  server.outbound.length = 0;

  // ---- 9. group mention gating ------------------------------------------
  console.log('\n[8] group mention gating (groupMention)');
  const ctx7 = makeStubCtx();
  const cfg7 = makeConfig({ websocketUrl: url, agent: { sessionScope: 'chat-user', groupMention: 'at', botName: 'DSH助手' } });
  const bridge7 = new Bridge(ctx7, cfg7, { WebSocketImpl: ws, SessionId: (id) => id, createUserMessage: ({ content, source }) => ({ content, source }) });
  await bridge7.start();
  await delay(100);

  // group message WITHOUT mention → ignored (no session, no reply)
  server.pushMessage({ chatid: 'grp-1', userid: 'alice', text: '有人吗', chattype: 'group' });
  await delay(250);
  assert.equal(bridge7.chats.size, 0, 'non-mentioned group message is ignored');
  ok('group message without @mention is ignored');

  // group message WITH mention → responded, mention stripped from agent input
  server.pushMessage({ chatid: 'grp-1', userid: 'alice', text: '@DSH助手 查一下天气', chattype: 'group' });
  await delay(250);
  assert.equal(bridge7.chats.size, 1, 'mentioned group message creates a session');
  const agentText7 = bridge7.chats.get('wecom:grp-1:alice').agent.received[0]?.content?.[0]?.text;
  assert.equal(agentText7, '查一下天气', '@mention is stripped before reaching the agent');
  const reply7 = finalStreamFrames(server, (c) => /^Echo: 查一下天气$/.test(c));
  assert.ok(reply7.length >= 1, 'mentioned message is answered');
  ok('@mention triggers a reply and the mention is stripped');

  // DM unaffected by the gate
  server.pushMessage({ chatid: 'dm-alice', userid: 'alice', text: '私聊不用@', chattype: 'single' });
  await delay(250);
  assert.equal(bridge7.chats.size, 2, 'DMs bypass the group mention gate');
  ok('DMs are not gated');

  await bridge7.stop();
  server.outbound.length = 0;

  // at-or-quote: quoting a message also triggers
  const ctx8 = makeStubCtx();
  const cfg8 = makeConfig({ websocketUrl: url, agent: { sessionScope: 'chat-user', groupMention: 'at-or-quote', botName: 'DSH助手' } });
  const bridge8 = new Bridge(ctx8, cfg8, { WebSocketImpl: ws, SessionId: (id) => id, createUserMessage: ({ content, source }) => ({ content, source }) });
  await bridge8.start();
  await delay(100);
  server.pushMessage({ chatid: 'grp-2', userid: 'bob', text: '具体说说', chattype: 'group', quote: { msgtype: 'text', text: { content: '机器人之前的话' } } });
  await delay(250);
  assert.equal(bridge8.chats.size, 1, 'quote triggers in at-or-quote mode');
  ok('at-or-quote: quoting a message triggers a reply');
  await bridge8.stop();
  server.outbound.length = 0;

  // ---- 10. media: inbound image → agent vision --------------------------
  console.log('\n[9] media support (inbound image → vision, outbound → send)');
  const aesKey = Buffer.from(Array.from({ length: 32 }, (_, i) => i)).toString('base64');
  const jpeg = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46]);
  const mediaRef = server.addMedia(jpeg, aesKey);

  const ctx9 = makeStubCtx();
  const cfg9 = makeConfig({ websocketUrl: url });
  const bridge9 = new Bridge(ctx9, cfg9, { WebSocketImpl: ws, SessionId: (id) => id, createUserMessage: ({ content, source }) => ({ content, source }) });
  await bridge9.start();
  await delay(100);
  // a pure image message (WeCom image msgtype carries no text)
  server.pushMessage({ chatid: 'chat-M', userid: 'mina', text: '', media: [{ kind: 'image', url: mediaRef.url, aesKey: mediaRef.aesKey }] });
  await delay(350);
  const chat9 = bridge9.chats.get('wecom:chat-M');
  const content9 = chat9.agent.received[0]?.content || [];
  const imgBlock9 = content9.find((b) => b.type === 'image');
  assert.ok(imgBlock9, 'agent receives an image content block (vision)');
  assert.ok(imgBlock9.attachment?.attachmentId, 'image block carries an admitted attachment ref');
  ok('inbound image is downloaded, decrypted and admitted as a vision block');

  // a text+image mixed message keeps both
  server.pushMessage({ chatid: 'chat-M', userid: 'mina', text: '看图说话', media: [{ kind: 'image', url: mediaRef.url, aesKey: mediaRef.aesKey }] });
  await delay(350);
  const contentM = chat9.agent.received[1]?.content || [];
  assert.ok(contentM.some((b) => b.type === 'image'), 'mixed message keeps the image block');
  assert.ok(contentM.some((b) => b.type === 'text' && b.text === '看图说话'), 'mixed message keeps the text');
  ok('text+image message delivers both vision and text');

  // outbound: agent-produced image block → upload (init/chunk/finish) + send
  const nBefore9 = server.outbound.length;
  ctx9._emit('session/event', chat9.agent.session, {
    type: 'user/message',
    data: { content: [{ type: 'text', text: 'GUI 触发' }], source: { kind: 'user', rpcId: 'rpc-gui-2' } }
  });
  ctx9._emit('session/event', chat9.agent.session, {
    type: 'assistant/message',
    data: {
      message: {
        content: [
          { type: 'image', attachment: { attachmentId: 'mock-att-out', mediaType: 'image/jpeg', bytes: 4, width: 1, height: 1 } },
          { type: 'text', text: '这是生成的图片' }
        ]
      }
    }
  });
  ctx9._emit('session/event', chat9.agent.session, { type: 'turn/end', data: { reason: { kind: 'complete' } } });
  await delay(400);
  const uploadCmds = server.outbound.slice(nBefore9).filter((f) => f.cmd?.startsWith('aibot_upload_media_'));
  assert.equal(uploadCmds.length, 3, 'three-step upload (init/chunk/finish) performed');
  const mediaSend = server.outbound.slice(nBefore9).find((f) => f.cmd === 'aibot_send_msg' && f.body?.msgtype === 'image' && f.body?.image?.media_id);
  assert.ok(mediaSend, 'agent-produced image is sent as WeCom media');
  ok('outbound image: upload(init/chunk/finish) → sendMediaMessage');

  // GUI-attached image in a WeCom session → synced to WeCom as media too
  const nBefore10 = server.outbound.length;
  ctx9._emit('session/event', chat9.agent.session, {
    type: 'user/message',
    data: {
      content: [
        { type: 'image', attachment: { attachmentId: 'mock-gui-img', mediaType: 'image/jpeg', bytes: 4, width: 1, height: 1 } },
        { type: 'text', text: '这是我在 GUI 发的图' }
      ],
      source: { kind: 'user', rpcId: 'rpc-gui-3' }
    }
  });
  await delay(400);
  const guiUploads = server.outbound.slice(nBefore10).filter((f) => f.cmd?.startsWith('aibot_upload_media_'));
  assert.equal(guiUploads.length, 3, 'GUI-attached image uploads (init/chunk/finish)');
  const guiMediaSend = server.outbound.slice(nBefore10).find((f) => f.cmd === 'aibot_send_msg' && f.body?.msgtype === 'image');
  assert.ok(guiMediaSend, 'GUI-attached image is sent to WeCom');
  const guiTextEcho = server.outbound.slice(nBefore10).find((f) => f.cmd === 'aibot_send_msg' && /我在 GUI 发的图/.test(f.body?.markdown?.content ?? ''));
  assert.ok(guiTextEcho, 'GUI text still echoes with the label');
  ok('GUI-attached image + text sync to WeCom as media + labeled text');

  await bridge9.stop();
  server.outbound.length = 0;

  // ---- 11. long replies are split into chunks ----------------------------
  console.log('\n[10] long-reply chunking (splitText)');
  const long = 'word '.repeat(500).trim(); // 2500 chars
  const chunks = splitText(long, 1000);
  assert.ok(chunks.length > 1, 'long text is split');
  assert.ok(chunks.every((c) => c.length <= 1000), 'every chunk within limit');
  ok(`splitText: ${long.length} chars → ${chunks.length} chunks (max 1000)`);

  console.log(`\n✅ smoke test passed (${passed} assertions)`);
} finally {
  await server.close();
}
