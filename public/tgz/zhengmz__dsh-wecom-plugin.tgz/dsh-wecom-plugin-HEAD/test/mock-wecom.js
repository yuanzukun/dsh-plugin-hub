// Mock WeCom aibot gateway for local feasibility testing.
//
// Emulates the wire protocol of wss://openws.work.weixin.qq.com well enough to
// prove the client's connect → subscribe → message → stream-reply → ack round
// trip without real WeCom credentials. Acks carry NO cmd field, exactly like
// the real gateway (frames are matched by req_id prefix / pending set).
// Also emulates media: an HTTP endpoint serving AES-encrypted files and the
// three-step upload protocol. Not used in production.

import { randomUUID, createCipheriv } from 'node:crypto';
import http from 'node:http';
import { Buffer } from 'node:buffer';

function shortId() {
  return randomUUID().replace(/-/g, '');
}

/** AES-256-CBC encrypt like the real gateway (key=base64, IV=key[0..16]). */
function encryptMedia(plain, aesKey) {
  const key = Buffer.from(aesKey, 'base64');
  const iv = key.subarray(0, 16);
  const pad = 32 - (plain.length % 32);
  const padded = Buffer.concat([plain, Buffer.alloc(pad, pad)]);
  const cipher = createCipheriv('aes-256-cbc', key, iv);
  cipher.setAutoPadding(false);
  return Buffer.concat([cipher.update(padded), cipher.final()]);
}

export class MockWeComServer {
  /**
   * @param {object} opts
   * @param {number} [opts.port]  0 = random free port (server.port after start)
   * @param {string} opts.botId   accepted bot_id
   * @param {string} opts.secret  accepted secret
   * @param {object} opts.wsModule  the `ws` module (WebSocketServer, WebSocket)
   * @param {object} [opts.logger]
   */
  static async start({ port = 0, botId = 'mock-bot', secret = 'mock-secret', wsModule, logger = console }) {
    const { WebSocketServer } = wsModule;
    const server = new MockWeComServer({ botId, secret, logger });
    server.wss = new WebSocketServer({ port });
    await new Promise((resolve) => server.wss.once('listening', resolve));
    server.port = server.wss.address().port;

    // HTTP media server (downloads).
    server.httpServer = http.createServer((req, res) => server.handleHttp(req, res));
    await new Promise((resolve) => server.httpServer.listen(0, '127.0.0.1', resolve));
    server.httpPort = server.httpServer.address().port;
    server.mediaStore = new Map(); // id -> { buffer (encrypted), }

    server.wss.on('connection', (socket) => server.handleConnection(socket));
    return server;
  }

  constructor({ botId, secret, logger }) {
    this.botId = botId;
    this.secret = secret;
    this.logger = logger;
    this.wss = undefined;
    this.port = 0;
    this.httpServer = undefined;
    this.httpPort = 0;
    this.mediaStore = new Map();
    this.sockets = new Set();
    /** Outbound frames received from clients (respond/send), for assertions. */
    this.outbound = [];
    /** Subscribe requests received (with credentials), for assertions. */
    this.subscribes = [];
    /** Per-socket authed flag. */
    this.state = new Map();
    /** Simulated reply errcode for aibot_respond_msg acks (0 = ok). */
    this.replyErrcode = 0;
    /** Simulated reply errmsg. */
    this.replyErrmsg = 'ok';
    /** Simulated send errcode for aibot_send_msg acks. */
    this.sendErrcode = 0;
  }

  handleConnection(socket) {
    this.sockets.add(socket);
    this.state.set(socket, { authed: false });
    socket.on('close', () => {
      this.sockets.delete(socket);
      this.state.delete(socket);
    });
    socket.on('error', () => {});
    socket.on('message', (data) => this.handleFrame(socket, data));
  }

  handleFrame(socket, data) {
    let payload;
    try {
      payload = JSON.parse(data.toString());
    } catch {
      return;
    }
    const cmd = String(payload.cmd || '');
    const reqId = String(payload.headers?.req_id || '');

    if (cmd === 'aibot_subscribe') {
      const body = payload.body || {};
      const ok = body.bot_id === this.botId && body.secret === this.secret;
      this.state.set(socket, { authed: ok, botId: body.bot_id });
      this.subscribes.push({ ok, reqId, body });
      // No-cmd ack, exactly like the real gateway.
      socket.send(
        JSON.stringify(
          ok
            ? { headers: { req_id: reqId }, errcode: 0, errmsg: 'ok' }
            : { headers: { req_id: reqId }, errcode: 40012, errmsg: 'invalid bot_id or secret' }
        )
      );
      return;
    }

    if (cmd === 'ping') {
      socket.send(JSON.stringify({ headers: { req_id: reqId }, errcode: 0 }));
      return;
    }

    // aibot_respond_msg / aibot_send_msg → record, then ack.
    this.outbound.push(payload);
    if (cmd === 'aibot_respond_msg') {
      socket.send(
        JSON.stringify({ headers: { req_id: reqId }, errcode: this.replyErrcode, errmsg: this.replyErrmsg })
      );
    } else if (cmd === 'aibot_send_msg') {
      socket.send(
        JSON.stringify({ headers: { req_id: reqId }, errcode: this.sendErrcode, errmsg: 'ok' })
      );
    } else if (cmd === 'aibot_upload_media_init') {
      const uploadId = `up-${shortId()}`;
      this.uploads = this.uploads || new Map();
      this.uploads.set(uploadId, { body: payload.body, chunks: [] });
      socket.send(JSON.stringify({ headers: { req_id: reqId }, errcode: 0, body: { upload_id: uploadId } }));
    } else if (cmd === 'aibot_upload_media_chunk') {
      const up = this.uploads?.get(payload.body?.upload_id);
      if (up) up.chunks[payload.body.chunk_index] = payload.body.base64_data;
      socket.send(JSON.stringify({ headers: { req_id: reqId }, errcode: 0, body: {} }));
    } else if (cmd === 'aibot_upload_media_finish') {
      const up = this.uploads?.get(payload.body?.upload_id);
      const mediaId = up ? `media-${shortId()}` : undefined;
      if (up) this.uploadResults = this.uploadResults || [];
      this.uploadResults?.push(up);
      socket.send(
        JSON.stringify({ headers: { req_id: reqId }, errcode: 0, body: { media_id: mediaId, type: up?.body?.type ?? 'file', created_at: new Date().toISOString() } })
      );
    }
    // ww_ai_robot_enter_event and other client commands: record only.
  }

  /** Serve /media/<id> (encrypted bytes) over HTTP, like the real gateway. */
  handleHttp(req, res) {
    const match = /^\/media\/([A-Za-z0-9_-]+)$/.exec(req.url || '');
    if (!match) {
      res.writeHead(404);
      res.end('not found');
      return;
    }
    const item = this.mediaStore.get(match[1]);
    if (!item) {
      res.writeHead(404);
      res.end('not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': 'application/octet-stream' });
    res.end(item.buffer);
  }

  /**
   * Register a plain file for media download, served AES-encrypted like WeCom.
   * @returns {{ url: string, aesKey: string, id: string }}
   */
  addMedia(plainBuffer, aesKey) {
    const id = shortId();
    this.mediaStore.set(id, { buffer: encryptMedia(Buffer.from(plainBuffer), aesKey) });
    return { id, aesKey, url: `http://127.0.0.1:${this.httpPort}/media/${id}` };
  }

  /**
   * Simulate an inbound user message arriving from WeCom.
   * @param {object} input - { chatid, userid, text, quote?, msgtype?, chattype?, media? }
   *   media: array of { kind, url, aesKey, name? } to attach as image/file/video fields.
   */
  pushMessage({ chatid = 'mock-chat', userid = 'mock-user', text = 'hello', quote, msgtype = 'text', chattype = 'single', media = [] }) {
    const body = {
      msgid: `msg-${shortId()}`,
      chatid,
      from: { userid },
      chattype
    };
    const mediaBody = (m) =>
      m.kind === 'image'
        ? { url: m.url, ...(m.aesKey ? { aeskey: m.aesKey } : {}) }
        : m.kind === 'file'
          ? { url: m.url, ...(m.aesKey ? { aeskey: m.aesKey } : {}), ...(m.name ? { filename: m.name } : {}) }
          : { url: m.url, ...(m.aesKey ? { aeskey: m.aesKey } : {}) };
    const hasText = text !== undefined && text !== '';
    if (media.length > 0 && hasText) {
      // realistic 图文混排 (mixed): text + media items
      body.msgtype = 'mixed';
      body.mixed = {
        msg_item: [
          { msgtype: 'text', text: { content: text } },
          ...media.map((m) => ({ msgtype: m.kind, [m.kind]: mediaBody(m) }))
        ]
      };
    } else if (media.length > 0) {
      const first = media[0];
      body.msgtype = first.kind;
      body[first.kind] = mediaBody(first);
      for (const m of media.slice(1)) body[`${m.kind}_extra_${shortId()}`] = mediaBody(m);
    } else {
      body.msgtype = msgtype;
      body.text = { content: text };
    }
    if (quote) body.quote = quote;
    const frame = { cmd: 'aibot_msg_callback', headers: { req_id: `cb-${shortId()}` }, body };
    this.broadcast(frame);
    return frame;
  }

  /** Push an inbound event callback (aibot_event_callback). */
  pushEvent({ eventtype, ...extra }) {
    const frame = {
      cmd: 'aibot_event_callback',
      headers: { req_id: `ev-${shortId()}` },
      body: {
        msgid: `evmsg-${shortId()}`,
        msgtype: 'event',
        event: { eventtype },
        ...extra
      }
    };
    this.broadcast(frame);
    return frame;
  }

  /** Send a frame to every authed client. */
  broadcast(payload) {
    const raw = JSON.stringify(payload);
    for (const socket of this.sockets) {
      if (this.state.get(socket)?.authed) socket.send(raw);
    }
  }

  async close() {
    for (const socket of this.sockets) {
      try {
        socket.terminate();
      } catch {
        /* containment */
      }
    }
    this.sockets.clear();
    await new Promise((resolve) => this.wss?.close(resolve));
    this.wss = undefined;
    if (this.httpServer) {
      await new Promise((resolve) => this.httpServer.close(resolve));
      this.httpServer = undefined;
    }
  }
}
