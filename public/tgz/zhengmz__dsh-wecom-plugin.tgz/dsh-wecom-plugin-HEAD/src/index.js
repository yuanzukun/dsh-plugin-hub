// dsh-wecom-plugin: minimal feasibility demo plugin.
//
// Bridges WeCom Smart Robot (企业微信智能机器人, aibot WebSocket) to a local
// DeepSeek Harness agent. Enable from the profile patch with bot credentials:
//
//   - id: dsh-wecom-plugin
//     disabled: false
//     config:
//       botId: '...'
//       secret: '...'
//       allowedUserIds: []
//       agent: { preset: standard, cwd: /path/to/workspace }

import z from '@deepseek-ai/schemastery';
import { Bridge } from './bridge.js';

/** Stable Cordis plugin name (row id in the bundle patch). */
export const name = 'dsh-wecom-plugin';

/** Core services the bridge needs before it can drive turns. */
export const inject = ['agentDefaultModel', 'agents', 'sessions', 'loader', 'sessionQuery', 'tools'];

/** Configuration schema (validated by the Cordis loader). */
export const Config = z.object({
  /** Master switch: when false the whole gateway stays dormant. */
  enabled: z.boolean().default(true),

  /** WeCom Smart Robot bot ID (企业微信智能机器人 ID). */
  botId: z.string().default(''),
  /** WeCom Smart Robot secret (企业微信智能机器人密钥). */
  secret: z.string().role('secret').default(''),
  /** WebSocket gateway URL (override only for local mock testing). */
  websocketUrl: z.string().default('wss://openws.work.weixin.qq.com'),
  /** WeCom userids allowed to talk to the bot; empty = everyone. */
  allowedUserIds: z.array(z.string()).default([]),
  /** Workspace aliases for `/cd <name>` (alias -> path). */
  workspaces: z.dict(z.string()).default({}),
  /** Version reported on the gateway's enter_check_update probe. */
  pluginVersion: z.string().default('0.1.0'),
  /** Extra subscribe body fields (e.g. scene, plug_version) merged verbatim. */
  subscribeExtra: z.dict(z.any()).default({}),
  /** Welcome text sent on enter_chat events; empty = none. */
  welcomeText: z.string().default(''),
  /** Routing-state file (chatId → sessionId). Default: $DSH_HOME/dsh-wecom-plugin-state.json */
  stateFile: z.string().default(''),
  /** Diagnostics log file (the DSH journal does not capture plugin logs). */
  logFile: z.string().default(''),
  /**
   * How long a final reply keeps retrying when the bot connection is down
   * (e.g. just kicked), before giving up. The auto-reconnect typically lands
   * within `kickReconnectDelayMs`, so this must be comfortably larger.
   */
  sendRetryMs: z.number().min(1000).default(30_000),
  /**
   * Reconnect after the gateway kicks this connection (a newer connection
   * with the same botId took over). An agent's one-shot send script opens a
   * second connection and kicks the persistent one; without this the bot
   * silently goes offline and every later send fails. A genuinely persistent
   * second instance is detected via the consecutive-kick cap.
   */
  reconnectAfterKick: z.boolean().default(true),
  /** Grace delay before reconnecting after a kick. */
  kickReconnectDelayMs: z.number().min(1000).default(10_000),
  /**
   * Prefix prepended when mirroring a GUI-typed user message to WeCom.
   * The aibot protocol can only send AS the bot, so this labels the echo so it
   * reads as the user's own input rather than the bot speaking. Empty = no label.
   */
  syncUserPrefix: z.string().default('📱 你在 Web GUI 发送：'),

  /**
   * In-chat approval answering: DSH permission questions for WeCom-owned
   * agents (e.g. sandbox escalation) are forwarded into the chat and answered
   * there, so no Web-backend visit is needed. Each prompt carries a one-time
   * code the asker must echo, guarding against accidental approvals in busy
   * groups.
   */
  approval: z
    .object({
      /** Master switch for in-chat approval answering. */
      enabled: z.boolean().default(true),
      /** ms to wait for an answer before the request fails closed. */
      timeoutMs: z.number().min(1).default(60_000),
      /** Reply substrings treated as approve (case-insensitive, code required). */
      approveWords: z.array(z.string()).default(['同意', '批准', '允许', 'yes', 'approve', 'allow']),
      /** Reply substrings treated as reject (case-insensitive, checked first). */
      rejectWords: z.array(z.string()).default(['拒绝', '不同意', '不允许', '不批准', 'no', 'reject', 'deny'])
    })
    .default({}),

  agent: z
    .object({
      /** Agent preset to mount (defaults to the profile default). */
      preset: z.string().default(''),
      /** Working directory for agent sessions (defaults to the dsh process cwd). */
      cwd: z.string().default(''),
      /** Override provider/model; empty = use the deployment default selection. */
      provider: z.string().default(''),
      model: z.string().default(''),
      /**
       * Reasoning effort for WeCom-owned agents. Empty = follow the deployment
       * default selection (settings → agent-default-model.reasoningEffort, same
       * as GUI sessions); otherwise one of the model's declared levels.
       */
      reasoningEffort: z.string().default(''),
      /** Maximum chars per outbound message; longer replies are split. Min 1. */
      maxMessageLength: z.number().min(1).default(4000),
      /** Idle ms before a chat's agent is disposed. 0 = never. */
      idleTimeoutMs: z.number().default(30 * 60 * 1000),
      /**
       * Allow `/cd <path>` to accept arbitrary filesystem paths. When false
       * (default), `/cd` only accepts configured `workspaces` aliases, so an
       * IM user cannot pivot the agent onto host directories outside the admin's
       * intent. Enable only if you trust every allowed user.
       */
      cdAllowPaths: z.boolean().default(false),
      /**
       * Register a scoped system-prompt section on WeCom-owned agents asking
       * the model to keep analysis in `reasoning` and emit only the conclusion
       * as visible text (so IM relays carry the answer, not the working process).
       */
      conciseOutput: z.boolean().default(true),
      /**
       * Session isolation scope:
       * - `chat`      — one session per chat (default; group members share one)
       * - `chat-user` — one session per (chat, sender userid) — group members isolated
       * - `per-channel-peer` — OpenClaw `session.dmScope` alias of `chat-user`
       * - `user`      — one session per sender userid across all chats
       */
      sessionScope: z
        .union([z.const('chat'), z.const('chat-user'), z.const('per-channel-peer'), z.const('user')])
        .default('chat'),
      /**
       * Group mention policy:
       * - `none`       — respond to every group message (current default)
       * - `at`         — respond only when the bot is @mentioned (text contains botName)
       * - `at-or-quote`— respond when @mentioned OR the message quotes/replies to a message
       * Slash commands always bypass the gate (like OpenClaw's control-command bypass).
       */
      groupMention: z
        .union([z.const('none'), z.const('at'), z.const('at-or-quote')])
        .default('none'),
      /** Bot display name for @mention detection (e.g. "你的机器人名"). */
      botName: z.string().default('')
    })
    .default({})
});

/** Mount the WeCom gateway: start the bridge, own its lifecycle. */
export function apply(ctx, config) {
  if (!config.enabled) return;
  const bridge = new Bridge(ctx, config);
  bridge.start().catch((error) => {
    console.error('[dsh-wecom-plugin] start failed: ' + (error instanceof Error ? error.message : String(error)));
    ctx.logger?.warn?.(
      `dsh-wecom-plugin: failed to start: ${error instanceof Error ? error.message : String(error)}`
    );
  });
  return () => {
    bridge.stop();
  };
}
