// WeCom Smart Robot (企业微信智能机器人) WebSocket client.
//
// Protocol (public, as documented by WeCom's official aibot gateway and SDK
// @wecom/aibot-node-sdk — audited against the official WeCom OpenClaw plugin):
//   - Persistent WebSocket to wss://openws.work.weixin.qq.com
//   - Authenticate with `aibot_subscribe` (bot_id + secret [+ scene/plug_version])
//   - Inbound user messages: `aibot_msg_callback` (legacy alias `aibot_callback`)
//   - Inbound events: `aibot_event_callback` (disconnected_event, enter_check_update…)
//   - Passive reply: `aibot_respond_msg` with a STREAM body
//       { msgtype:'stream', stream:{ id, finish, content } }  (thinking → finish)
//   - Proactive send: `aibot_send_msg` with { chatid, msgtype:'markdown', … }
//   - Heartbeat `ping`; server acks carry NO cmd and are matched by req_id
//   - Stream expiry errcode 846608 → caller falls back to aibot_send_msg
//
// Clean-room implementation of that wire protocol; no public endpoint or AES
// callback needed — it is a long-lived client connection.

import { randomUUID, createHash, createDecipheriv } from 'node:crypto';
import { Buffer } from 'node:buffer';

export const DEFAULT_WS_URL = 'wss://openws.work.weixin.qq.com';

const CMD_SUBSCRIBE = 'aibot_subscribe';
const CMD_MSG_CALLBACK = 'aibot_msg_callback';
const CMD_LEGACY_CALLBACK = 'aibot_callback';
const CMD_EVENT_CALLBACK = 'aibot_event_callback';
const CMD_RESPOND = 'aibot_respond_msg';
const CMD_SEND = 'aibot_send_msg';
const CMD_PING = 'ping';
const CMD_ENTER_EVENT_REPLY = 'ww_ai_robot_enter_event';
const CMD_UPLOAD_INIT = 'aibot_upload_media_init';
const CMD_UPLOAD_CHUNK = 'aibot_upload_media_chunk';
const CMD_UPLOAD_FINISH = 'aibot_upload_media_finish';

/** Max bytes per outbound file by media type (official limits). */
export const MEDIA_MAX_BYTES = {
  image: 10 * 1024 * 1024,
  video: 10 * 1024 * 1024,
  voice: 2 * 1024 * 1024,
  file: 20 * 1024 * 1024
};

export const STREAM_EXPIRED_ERRCODE = 846608;

const CONNECT_TIMEOUT_MS = 20_000;
const HEARTBEAT_MS = 30_000;
const MAX_MISSED_PONG = 3;
const MAX_AUTH_FAILURES = 5;
const MAX_CONSECUTIVE_KICKS = 3;
const REPLY_TIMEOUT_MS = 15_000;
const BACKOFF_SECONDS = [1, 2, 4, 8, 16, 30];
const DEDUP_CAP = 1000;

function shortId() {
  return randomUUID().replace(/-/g, '');
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Raised when the gateway reports a stream reply has expired (errcode 846608). */
export class StreamExpiredError extends Error {
  constructor(message) {
    super(message ?? `Stream message update expired (errcode=${STREAM_EXPIRED_ERRCODE})`);
    this.name = 'StreamExpiredError';
    this.errcode = STREAM_EXPIRED_ERRCODE;
  }
}

/**
 * Minimal WeCom aibot WebSocket client (official-protocol aligned).
 *
 * @param {object} opts
 * @param {string} opts.botId       企业微信智能机器人 bot_id
 * @param {string} opts.secret      企业微信智能机器人 secret
 * @param {string} [opts.websocketUrl]   gateway URL (default official)
 * @param {Function} opts.onMessage  (input) => void
 *   input = { chatId, userId, text, quote, hasMedia, reply(content) }
 * @param {Function} [opts.onEvent]  (event) => void
 *   event = { type, reqId, frame }  (enter_chat / template_card_event / …)
 * @param {string} [opts.pluginVersion]  reported on enter_check_update
 * @param {object} [opts.subscribeExtra] extra auth body fields (scene, plug_version…)
 * @param {object} [opts.logger]
 * @param {import('ws')} [opts.WebSocketImpl]
 */
export class WeComAibotClient {
  constructor(opts) {
    const { botId, secret, websocketUrl, onMessage, onEvent, pluginVersion, subscribeExtra, logger, WebSocketImpl, reconnectAfterKick, kickReconnectDelayMs } = opts;
    if (typeof onMessage !== 'function') throw new TypeError('onMessage is required');
    this.botId = String(botId || '');
    this.secret = String(secret || '');
    this.wsUrl = String(websocketUrl || DEFAULT_WS_URL);
    this.onMessage = onMessage;
    this.onEvent = typeof onEvent === 'function' ? onEvent : () => {};
    this.pluginVersion = pluginVersion ?? '';
    this.subscribeExtra = subscribeExtra ?? {};
    this.logger = logger || console;
    this.WebSocketImpl = WebSocketImpl; // lazily resolved from 'ws' if omitted
    // After a `disconnected_event` (a newer connection took over) the client
    // reconnects after a grace delay instead of staying dead forever. A real
    // second instance would kick us again, so consecutive kicks are capped —
    // give up only when a genuinely persistent duplicate keeps winning.
    this.reconnectAfterKick = reconnectAfterKick !== false;
    this.kickReconnectDelayMs = Math.max(1000, Number(kickReconnectDelayMs) || 10_000);
    this.consecutiveKicks = 0;
    this.running = false;
    this.ws = undefined;
    this.closedPromise = undefined;
    this.heartbeatTimer = undefined;
    this.deviceId = shortId();
    this.dedup = new Set();
    this.lastReqId = new Map(); // chatId -> latest inbound req_id
    this.pendingReplies = new Map(); // req_id -> { resolve, reject, timer }
    this.missedPong = 0;
    this.authFailures = 0;
    this.kicked = false;
    this._resolveClosed = undefined;
    this._connectPromise = undefined;
  }

  async start() {
    if (!this.botId || !this.secret) {
      throw new Error('dsh-wecom-plugin: botId and secret are required');
    }
    this.running = true;
    this.kicked = false;
    this.connectLoop().catch((error) => {
      this.logger.error?.(`[wecom] connect loop failed: ${error instanceof Error ? error.message : String(error)}`);
    });
  }

  stop() {
    this.running = false;
    this.clearHeartbeat();
    if (this.ws !== undefined) {
      try {
        this.ws.terminate();
      } catch {
        /* containment */
      }
      this.ws = undefined;
    }
    this.rejectAllReplies(new Error('client stopped'));
    this.dedup.clear();
    this.lastReqId.clear();
  }

  // ------------------------------------------------------------ connect

  async connectLoop() {
    let backoffIdx = 0;
    while (this.running) {
      try {
        await this.openAndSubscribe();
        backoffIdx = 0;
        this.authFailures = 0;
        await this.untilClosed();
      } catch (error) {
        if (!this.running) return;
        this.logger.error?.(`[wecom] connect error: ${error instanceof Error ? error.message : String(error)}`);
      }
      if (!this.running) return;
      // After a kick (a newer connection took over), reconnect after a grace
      // delay so a transient duplicate (e.g. an agent's one-shot script) does
      // not leave the persistent bot dead. Consecutive kicks are capped so a
      // genuinely persistent second instance cannot make us fight forever.
      if (this.kicked) {
        if (!this.reconnectAfterKick) {
          this.logger.error?.('[wecom] kicked by server (disconnected_event); auto-reconnect suppressed.');
          return;
        }
        this.consecutiveKicks += 1;
        if (this.consecutiveKicks > MAX_CONSECUTIVE_KICKS) {
          this.logger.error?.(
            `[wecom] kicked ${MAX_CONSECUTIVE_KICKS} times in a row — a persistent duplicate instance is likely connected. Giving up; restart the service to resume.`
          );
          return;
        }
        this.kicked = false;
        const delay = this.kickReconnectDelayMs / 1000;
        this.logger.error?.(
          `[wecom] kicked by server; reconnecting in ${delay}s (attempt ${this.consecutiveKicks}/${MAX_CONSECUTIVE_KICKS})`
        );
        await sleep(this.kickReconnectDelayMs);
        continue;
      }
      if (this.authFailures >= MAX_AUTH_FAILURES) {
        this.logger.error?.(`[wecom] auth failed ${MAX_AUTH_FAILURES} times; giving up. Check botId/secret.`);
        return;
      }
      const delay = BACKOFF_SECONDS[Math.min(backoffIdx, BACKOFF_SECONDS.length - 1)];
      backoffIdx += 1;
      this.logger.error?.(`[wecom] reconnecting in ${delay}s`);
      await sleep(delay * 1000);
    }
  }

  async openAndSubscribe() {
    const WsCtor = this.WebSocketImpl || (await import('ws')).default;
    const ws = new WsCtor(this.wsUrl);
    this.ws = ws;
    this.closedPromise = new Promise((resolve) => {
      this._resolveClosed = resolve;
      ws.on('close', () => resolve());
      ws.on('error', () => resolve());
    });

    await new Promise((resolve, reject) => {
      ws.once('open', () => resolve());
      ws.once('error', (err) => reject(err instanceof Error ? err : new Error(String(err))));
    });

    // Authenticate and wait for the correlated ack (no-cmd frame, req_id match).
    const reqId = `subscribe-${shortId()}`;
    const ack = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        ws.off('message', onFrame);
        reject(new Error('subscribe acknowledgement timed out'));
      }, CONNECT_TIMEOUT_MS);
      const onFrame = (data) => {
        let payload;
        try {
          payload = JSON.parse(data.toString());
        } catch {
          return;
        }
        if (payload?.cmd === CMD_PING) return;
        if (payload?.headers?.req_id === reqId) {
          clearTimeout(timer);
          ws.off('message', onFrame);
          resolve(payload);
        }
      };
      ws.on('message', onFrame);
      ws.send(
        JSON.stringify({
          cmd: CMD_SUBSCRIBE,
          headers: { req_id: reqId },
          body: {
            bot_id: this.botId,
            secret: this.secret,
            device_id: this.deviceId,
            ...this.subscribeExtra
          }
        })
      );
    });

    const errcode = ack?.errcode ?? ack?.body?.errcode ?? 0;
    if (errcode !== 0) {
      this.authFailures += 1;
      const errmsg = ack?.errmsg || ack?.body?.errmsg || 'authentication failed';
      throw new Error(`WeCom auth failed: ${errmsg} (errcode=${errcode})`);
    }
    this.authFailures = 0;
    this.consecutiveKicks = 0;
    this.logger.log?.(`[wecom] authenticated OK, connected to ${this.wsUrl}`);

    ws.on('message', (data) => this.handleFrame(data));
    this.startHeartbeat();
  }

  untilClosed() {
    return this.closedPromise;
  }

  // ------------------------------------------------------------ frames

  handleFrame(data) {
    let payload;
    try {
      payload = JSON.parse(data.toString());
    } catch {
      return;
    }
    if (typeof payload !== 'object' || payload === null) return;
    const cmd = String(payload.cmd || '');
    const reqId = String(payload.headers?.req_id || '');

    // Command frames
    if (cmd === CMD_MSG_CALLBACK || cmd === CMD_LEGACY_CALLBACK) {
      this.onInboundMessage(payload);
      return;
    }
    if (cmd === CMD_EVENT_CALLBACK) {
      this.onInboundEvent(payload);
      return;
    }
    if (cmd === CMD_PING) {
      // Server-side ping: ignore (we only send pings as our heartbeat).
      return;
    }

    // Ack frames carry no cmd; dispatch by req_id prefix (official SDK behavior).
    if (reqId.startsWith('subscribe-')) {
      // Auth ack (handled during openAndSubscribe); a late/duplicate ack is ignored.
      return;
    }
    if (reqId.startsWith('ping-')) {
      if (payload.errcode === undefined || payload.errcode === 0) {
        this.missedPong = 0;
      }
      return;
    }
    const pending = this.pendingReplies.get(reqId);
    if (pending !== undefined) {
      this.settleReply(pending, payload);
    }
  }

  // ------------------------------------------------------------ inbound

  onInboundMessage(payload) {
    const body = payload.body;
    if (typeof body !== 'object' || body === null) return;

    const msgid = String(body.msgid || payload.headers?.req_id || shortId());
    if (this.dedup.has(msgid)) return;
    this.dedup.add(msgid);
    if (this.dedup.size > DEDUP_CAP) {
      const entries = [...this.dedup];
      for (const id of entries.slice(0, Math.floor(DEDUP_CAP / 2))) this.dedup.delete(id);
    }

    const sender = typeof body.from === 'object' && body.from !== null ? body.from : {};
    const userId = String(sender.userid || '').trim();
    const chatId = String(body.chatid || userId).trim();
    if (!chatId) return;

    const replyReqId = String(payload.headers?.req_id || '').trim();
    if (replyReqId) this.lastReqId.set(chatId, replyReqId);

    const { text: rawText, quote, hasMedia, media } = extractMessage(body);
    // Official behavior: an empty message that only quotes becomes the quote text.
    const text = rawText || quote || '';
    if (!text && !hasMedia) return;

    this.onMessage({
      chatId,
      userId,
      text,
      quote,
      hasMedia,
      media: media || [],
      chatType: String(body.chattype || 'single').toLowerCase(),
      reply: (content) => this.replyToChat(chatId, content, replyReqId)
    });
  }

  onInboundEvent(payload) {
    const body = payload.body;
    if (typeof body !== 'object' || body === null) return;
    const eventType = String(body.event?.eventtype || '');

    if (eventType === 'disconnected_event') {
      // A new connection took over: stop heartbeat, clear pending, do not
      // auto-reconnect (would cause a mutual-kick loop with the duplicate).
      this.logger.error?.('[wecom] disconnected_event: kicked by a newer connection.');
      this.kicked = true;
      this.clearHeartbeat();
      this.rejectAllReplies(new Error('kicked by server (disconnected_event)'));
      if (this.ws !== undefined) {
        try {
          this.ws.removeAllListeners();
          this.ws.terminate();
        } catch {
          /* containment */
        }
        this.ws = undefined;
      }
      if (this._resolveClosed) this._resolveClosed();
      return;
    }

    if (eventType === 'enter_check_update' && this.pluginVersion) {
      // Version check: answer so the gateway does not consider us unhealthy.
      const reqId = String(payload.headers?.req_id || '');
      try {
        this.ws?.send(
          JSON.stringify({
            cmd: CMD_ENTER_EVENT_REPLY,
            headers: { req_id: reqId },
            body: { version: this.pluginVersion }
          })
        );
      } catch {
        /* containment */
      }
      return;
    }

    // Surface the rest to the bridge (enter_chat, template_card_event, …).
    this.onEvent({
      type: eventType,
      reqId: String(payload.headers?.req_id || ''),
      frame: payload
    });
  }

  // ------------------------------------------------------------ outbound

  startHeartbeat() {
    this.clearHeartbeat();
    this.heartbeatTimer = setInterval(() => this.sendHeartbeat(), HEARTBEAT_MS);
    this.heartbeatTimer.unref?.();
  }

  clearHeartbeat() {
    if (this.heartbeatTimer !== undefined) clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = undefined;
  }

  sendHeartbeat() {
    if (this.ws === undefined || this.ws.readyState !== this.ws.OPEN) return;
    // Check missed pongs BEFORE the next ping (official SDK behavior).
    if (this.missedPong >= MAX_MISSED_PONG) {
      this.logger.error?.(`[wecom] no heartbeat ack for ${this.missedPong} pings; connection considered dead`);
      this.clearHeartbeat();
      try {
        this.ws.terminate();
      } catch {
        /* containment */
      }
      return;
    }
    this.missedPong += 1;
    try {
      this.ws.send(JSON.stringify({ cmd: CMD_PING, headers: { req_id: `ping-${shortId()}` } }));
    } catch {
      /* containment */
    }
  }

  /**
   * Passive reply with the official STREAM body. Send thinking (finish=false)
   * then final (finish=true) with the SAME streamId. Awaits the gateway ack.
   * @returns {Promise<string>} streamId
   * @throws {StreamExpiredError} when the gateway reports errcode 846608
   */
  async sendStreamReply(chatId, streamId, content, finish = true) {
    const reqId = this.lastReqId.get(chatId) || '';
    if (!reqId) {
      // No usable req_id (e.g. event-originated): fall back to proactive send.
      await this.sendMessage(chatId, content);
      return streamId;
    }
    const body = {
      msgtype: 'stream',
      stream: { id: streamId, finish, content: String(content) }
    };
    const ack = await this.sendWithAck(CMD_RESPOND, reqId, body);
    if (ack.errcode === STREAM_EXPIRED_ERRCODE) {
      throw new StreamExpiredError(ack.errmsg || 'stream expired');
    }
    if (ack.errcode !== 0) {
      throw new Error(`WeCom respond failed: ${ack.errmsg || ack.errcode} (errcode=${ack.errcode})`);
    }
    return streamId;
  }

  /** Proactive markdown send to a chat (aibot_send_msg). */
  async sendMessage(chatId, content) {
    const reqId = `send-${shortId()}`;
    const ack = await this.sendWithAck(CMD_SEND, reqId, {
      chatid: chatId,
      msgtype: 'markdown',
      markdown: { content: String(content) }
    });
    if (ack.errcode !== 0) {
      throw new Error(`WeCom send failed: ${ack.errmsg || ack.errcode} (errcode=${ack.errcode})`);
    }
    return reqId;
  }

  /** Send a frame and await its no-cmd ack (matched by req_id). */
  sendWithAck(cmd, reqId, body) {
    if (this.ws === undefined || this.ws.readyState !== this.ws.OPEN) {
      return Promise.reject(new Error('WebSocket not connected'));
    }
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingReplies.delete(reqId);
        reject(new Error(`reply ack timed out (cmd=${cmd}, reqId=${reqId})`));
      }, REPLY_TIMEOUT_MS);
      this.pendingReplies.set(reqId, { resolve, reject, timer });
      try {
        this.ws.send(JSON.stringify({ cmd, headers: { req_id: reqId }, body }));
      } catch (error) {
        clearTimeout(timer);
        this.pendingReplies.delete(reqId);
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
  }

  settleReply(pending, ack) {
    clearTimeout(pending.timer);
    this.pendingReplies.delete(ack.headers?.req_id);
    pending.resolve(ack);
  }

  rejectAllReplies(error) {
    for (const [, pending] of this.pendingReplies) {
      clearTimeout(pending.timer);
      pending.reject(error);
    }
    this.pendingReplies.clear();
  }

  /** Convenience: reply to a chat with a full stream lifecycle (thinking → final). */
  async replyToChat(chatId, content, reqId) {
    if (reqId) this.lastReqId.set(chatId, reqId);
    const streamId = `stream-${shortId()}`;
    try {
      await this.sendStreamReply(chatId, streamId, content, true);
      return streamId;
    } catch (error) {
      if (error instanceof StreamExpiredError) {
        this.logger.warn?.('[wecom] stream expired; falling back to proactive send');
        await this.sendMessage(chatId, content);
        return streamId;
      }
      throw error;
    }
  }

  // --------------------------------------------------------------- media

  /**
   * Download a WeCom media file (5-minute signed URL) and AES-256-CBC decrypt it.
   * Algorithm matches the official SDK: key = base64(aeskey), IV = key[0..16],
   * auto padding off, manual PKCS#7 unpad on a 32-byte block.
   * @returns {Promise<{buffer: Buffer, name?: string}>}
   */
  async downloadMedia(url, aesKey) {
    const response = await fetch(url, { signal: AbortSignal.timeout(60_000) });
    if (!response.ok) throw new Error(`media download failed: HTTP ${response.status}`);
    const encrypted = Buffer.from(await response.arrayBuffer());
    let buffer = encrypted;
    if (aesKey) {
      const key = Buffer.from(aesKey, 'base64');
      const iv = key.subarray(0, 16);
      const decipher = createDecipheriv('aes-256-cbc', key, iv);
      decipher.setAutoPadding(false);
      const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
      const padLen = decrypted[decrypted.length - 1];
      if (padLen < 1 || padLen > 32 || padLen > decrypted.length) {
        throw new Error('invalid media PKCS#7 padding');
      }
      buffer = decrypted.subarray(0, decrypted.length - padLen);
    }
    let name;
    try {
      const parsed = new URL(url);
      const base = parsed.pathname.split('/').pop();
      if (base && !base.includes('.')) name = decodeURIComponent(base);
    } catch {
      /* containment */
    }
    return { buffer, name };
  }

  /**
   * Upload a file buffer as temporary WeCom media via the three-step chunked
   * protocol (init → chunk×N → finish). Returns the media_id.
   */
  async uploadMedia(fileBuffer, { type, filename }) {
    if (!this.ws || this.ws.readyState !== this.ws.OPEN) throw new Error('WebSocket not connected');
    const CHUNK_SIZE = 512 * 1024;
    const totalSize = fileBuffer.length;
    const totalChunks = Math.ceil(totalSize / CHUNK_SIZE);
    if (totalChunks > 100) throw new Error(`media too large (${totalChunks} chunks > 100)`);
    const max = MEDIA_MAX_BYTES[type] ?? MEDIA_MAX_BYTES.file;
    if (totalSize > max) throw new Error(`media exceeds ${max} bytes for type "${type}"`);
    const md5 = createHash('md5').update(fileBuffer).digest('hex');

    // init
    const initReq = `up-init-${shortId()}`;
    const initAck = await this.sendWithAck(CMD_UPLOAD_INIT, initReq, {
      type,
      filename,
      total_size: totalSize,
      total_chunks: totalChunks,
      md5
    });
    const uploadId = initAck.body?.upload_id;
    if (!uploadId) throw new Error(`upload init failed: ${JSON.stringify(initAck)}`);

    // chunks (sequential for simplicity; official SDK uses 2-4 concurrency)
    for (let i = 0; i < totalChunks; i++) {
      const start = i * CHUNK_SIZE;
      const end = Math.min(start + CHUNK_SIZE, totalSize);
      const base64Data = fileBuffer.subarray(start, end).toString('base64');
      const chunkReq = `up-chunk-${shortId()}`;
      const chunkAck = await this.sendWithAck(CMD_UPLOAD_CHUNK, chunkReq, {
        upload_id: uploadId,
        chunk_index: i,
        base64_data: base64Data
      });
      if (chunkAck.errcode !== 0) {
        throw new Error(`upload chunk ${i} failed: ${chunkAck.errmsg || chunkAck.errcode}`);
      }
    }

    // finish
    const finishReq = `up-finish-${shortId()}`;
    const finishAck = await this.sendWithAck(CMD_UPLOAD_FINISH, finishReq, { upload_id: uploadId });
    const mediaId = finishAck.body?.media_id;
    if (!mediaId) throw new Error(`upload finish failed: ${JSON.stringify(finishAck)}`);
    return mediaId;
  }

  /** Proactive media send to a chat (aibot_send_msg). */
  async sendMediaMessage(chatId, mediaType, mediaId, extra = {}) {
    const reqId = `send-${shortId()}`;
    const body = { chatid: chatId, msgtype: mediaType, [mediaType]: { media_id: mediaId, ...extra } };
    const ack = await this.sendWithAck(CMD_SEND, reqId, body);
    if (ack.errcode !== 0) {
      throw new Error(`WeCom media send failed: ${ack.errmsg || ack.errcode} (errcode=${ack.errcode})`);
    }
    return reqId;
  }

  /** Passive media reply correlated to an inbound frame (aibot_respond_msg). */
  async replyMedia(chatId, mediaType, mediaId, extra = {}) {
    const reqId = this.lastReqId.get(chatId);
    if (!reqId) return this.sendMediaMessage(chatId, mediaType, mediaId, extra);
    const body = { msgtype: mediaType, [mediaType]: { media_id: mediaId, ...extra } };
    const ack = await this.sendWithAck(CMD_RESPOND, reqId, body);
    if (ack.errcode !== 0) {
      throw new Error(`WeCom media reply failed: ${ack.errmsg || ack.errcode} (errcode=${ack.errcode})`);
    }
    return reqId;
  }
}

/**
 * Extract text / quote / media-presence from a WeCom message body.
 * Mirrors the official plugin's message-parser text coverage.
 */
export function extractMessage(body) {
  const textParts = [];
  let quote = '';
  let hasMedia = false;
  const media = [];
  const addMedia = (kind, item) => {
    if (!item || typeof item !== 'object') return;
    const url = String(item.url || '').trim();
    if (!url) return;
    hasMedia = true;
    media.push({
      kind,
      url,
      aesKey: item.aeskey ? String(item.aeskey) : undefined,
      name: item.filename ? String(item.filename) : undefined
    });
  };
  const msgtype = String(body.msgtype || '').toLowerCase();

  if (msgtype === 'mixed') {
    const items = body.mixed?.msg_item;
    if (Array.isArray(items)) {
      for (const item of items) {
        if (typeof item !== 'object' || item === null) continue;
        const t = String(item.msgtype || '').toLowerCase();
        if (t === 'text') {
          const content = String(item.text?.content || '').trim();
          if (content) textParts.push(content);
        } else if (t === 'image') {
          addMedia('image', item.image);
        }
      }
    }
  } else {
    if (msgtype === 'text') {
      const content = String(body.text?.content || '').trim();
      if (content) textParts.push(content);
    }
    if (msgtype === 'voice') {
      const voice = String(body.voice?.content || '').trim();
      if (voice) textParts.push(voice);
    }
    if (msgtype === 'appmsg') {
      const title = String(body.appmsg?.title || '').trim();
      if (title) textParts.push(title);
    }
    addMedia('image', body.image);
    addMedia('file', body.file);
    addMedia('video', body.video);
  }

  // Quote (引用消息): text/voice quote becomes fallback text; media quote counts.
  const q = body.quote;
  if (q && typeof q === 'object') {
    const qt = String(q.msgtype || '').toLowerCase();
    if (qt === 'text') {
      quote = String(q.text?.content || '').trim();
    } else if (qt === 'voice') {
      quote = String(q.voice?.content || '').trim();
    }
    addMedia('image', q.image);
    addMedia('file', q.file);
    addMedia('video', q.video);
  }

  return {
    text: textParts.filter(Boolean).join('\n').trim(),
    quote,
    hasMedia,
    media
  };
}
