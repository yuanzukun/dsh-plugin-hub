window.__ModuleLoader__.load({
	id: "dsh-session-task-tags",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });

		// Only baseline modules: `react` and `react-dom` are part of the frozen
		// platform module table every dynamic bundle resolves against. Harness
		// Client packages are deliberately NOT required here — their internals
		// change without notice and a throwing import would blank the slot entry.
		const React = require("react");
		const { createPortal } = require("react-dom");
		const h = React.createElement;

		/** Locale namespace and the HTTP route prefix owned by the Host half. */
		const NS = "session-task-tags";
		const API = "/session-task-tags/api";

		const DAY_MS = 24 * 60 * 60 * 1000;
		const KIND_LONG = "long";
		const KIND_SHORT = "short";

		// ── locale dictionaries ───────────────────────────────────────────────
		const zh = {
			chipLong: "长期任务",
			chipShort: "短期任务",
			chipMeta: "{days}天 · 剩{left}天",
			chipArchived: "已归档",
			menuTaskType: "任务类型",
			menuArchiveWindow: "自动归档时间",
			menuArchiveMode: "归档方式",
			menuManual: "手动归档",
			menuManualHint: "手动归档：不会自动归档",
			menuArchiveHint: "到期后自动归档",
			menuArchiveOff: "自动归档已关闭",
			menuDeadlineLeft: "预计归档：{date}（剩 {left} 天）",
			menuAgent: "Agent 模式：{name}",
			days: "{n} 天",
			agentModeNone: "默认模式",
			markLong: "长期",
			markShort: "短期",
			saveFailed: "保存失败",
		};
		const en = {
			chipLong: "Long-term",
			chipShort: "Short-term",
			chipMeta: "{days}d · {left}d left",
			chipArchived: "Archived",
			menuTaskType: "Task type",
			menuArchiveWindow: "Auto-archive window",
			menuArchiveMode: "Archive mode",
			menuManual: "Manual",
			menuManualHint: "Manual: never archived automatically",
			menuArchiveHint: "Archived automatically when the window elapses",
			menuArchiveOff: "Auto-archive is disabled",
			menuDeadlineLeft: "Archives on {date} ({left}d left)",
			menuAgent: "Agent mode: {name}",
			days: "{n} days",
			agentModeNone: "Default mode",
			markLong: "Long",
			markShort: "Short",
			saveFailed: "Save failed",
		};

		/** Window fallback used until the Host reports its configured sets. */
		const SHORT_OPTIONS_FALLBACK = [1, 5, 7, 15, 30];

		// ── shared store ──────────────────────────────────────────────────────
		// One module-level snapshot every seat subscribes to, so the composer
		// selector and every sidebar row agree without re-reading the Host.
		function createStore() {
			const listeners = new Set();
			let state = {
				phase: "loading",
				records: {},
				config: {
					shortArchiveOptions: [1, 5, 7, 15, 30],
					longArchiveOptions: [15, 25, 35, 45, 55, 65, 75, 85],
					defaultShortArchiveAfterDays: 7,
					autoArchiveEnabled: true,
				},
				error: null,
			};
			return {
				get: () => state,
				subscribe: (listener) => {
					listeners.add(listener);
					return () => {
						listeners.delete(listener);
					};
				},
				set: (patch) => {
					state = Object.assign({}, state, patch);
					for (const listener of Array.from(listeners)) {
						try {
							listener();
						} catch {
							/* one seat must not break the others */
						}
					}
				},
			};
		}
		const store = createStore();

		/** One in-flight read at a time; concurrent seats share it. */
		let inflight = null;

		/**
		 * Read the whole tag table from the Host.
		 * @returns a promise settling when the snapshot is published.
		 */
		function refresh() {
			if (inflight !== null) return inflight;
			inflight = (async () => {
				try {
					const response = await fetch(`${API}/list`, {
						method: "POST",
						headers: { "content-type": "application/json" },
						body: "{}",
					});
					const body = await response.json().catch(() => null);
					if (!response.ok || body === null || body.ok !== true) {
						throw new Error((body && body.error && body.error.message) || `HTTP ${response.status}`);
					}
					store.set({ phase: "ready", records: body.value.records, config: body.value.config, error: null });
				} catch (error) {
					store.set({ phase: "error", error: error instanceof Error ? error.message : String(error) });
				} finally {
					inflight = null;
				}
			})();
			return inflight;
		}

		/**
		 * Write one Session's task tag.
		 * @param sessionId - Session identity.
		 * @param kind - `long` or `short`.
		 * @param archiveAfterDays - short-term window in days.
		 * @returns a promise resolving on acceptance.
		 */
		async function writeTag(sessionId, kind, archiveAfterDays) {
			const response = await fetch(`${API}/set`, {
				method: "POST",
				headers: { "content-type": "application/json" },
				body: JSON.stringify({ sessionId, kind, archiveAfterDays }),
			});
			const body = await response.json().catch(() => null);
			if (!response.ok || body === null || body.ok !== true) {
				throw new Error((body && body.error && body.error.message) || `HTTP ${response.status}`);
			}
			const current = store.get();
			const records = Object.assign({}, current.records);
			records[sessionId] = body.value.record;
			store.set({ phase: "ready", records, error: null });
		}

		/** Subscribe one component to the shared snapshot. */
		function useStore() {
			return React.useSyncExternalStore(store.subscribe, store.get, store.get);
		}

		/** The default record shape used before the Host answers. */
		const EMPTY_RECORD = {
			kind: KIND_LONG,
			archiveAfterDays: null,
			agentPresetId: null,
			agentPresetName: null,
			archiveAt: null,
			archivedAt: null,
			autoArchived: false,
		};

		/**
		 * Read one Session's record, defaulting to a long-term task.
		 * @param snapshot - the shared snapshot.
		 * @param sessionId - Session identity.
		 * @returns the record.
		 */
		function recordOf(snapshot, sessionId) {
			const found = snapshot.records[sessionId];
			return found === undefined ? EMPTY_RECORD : found;
		}

		/** Format an instant as a locale-neutral calendar date. */
		function formatDate(ms) {
			const date = new Date(ms);
			const pad = (value) => String(value).padStart(2, "0");
			return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
		}

		/** Whole days left before an instant, floored at zero. */
		function daysLeft(ms) {
			return Math.max(0, Math.ceil((ms - Date.now()) / DAY_MS));
		}

		/**
		 * Normalize a stored window: a positive whole day count, or null for
		 * MANUAL archiving.
		 * @param value - the record's `archiveAfterDays`.
		 * @returns the day count, or null.
		 */
		function positiveDays(value) {
			const n = typeof value === "number" ? value : Number(value);
			return Number.isFinite(n) && n > 0 ? Math.floor(n) : null;
		}

		/**
		 * Pick the first non-empty day list among the candidates.
		 * @param candidates - day lists, most specific first.
		 * @returns the chosen list.
		 */
		function firstNonEmpty(candidates) {
			for (const candidate of candidates) {
				if (Array.isArray(candidate) && candidate.length > 0) return candidate;
			}
			return candidates[candidates.length - 1];
		}

		// ── icons ─────────────────────────────────────────────────────────────
		function IconChevronDown() {
			return h(
				"svg",
				{ width: 12, height: 12, viewBox: "0 0 12 12", "aria-hidden": "true", focusable: "false" },
				h("path", {
					d: "M2.5 4.5 6 8l3.5-3.5",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: 1.2,
					strokeLinecap: "round",
					strokeLinejoin: "round",
				}),
			);
		}

		function IconCheck() {
			return h(
				"svg",
				{ width: 14, height: 14, viewBox: "0 0 14 14", "aria-hidden": "true", focusable: "false" },
				h("path", {
					d: "M3 7.5 5.8 10.2 11 4.6",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: 1.4,
					strokeLinecap: "round",
					strokeLinejoin: "round",
				}),
			);
		}

		function IconTaskLong() {
			return h(
				"svg",
				{ width: 16, height: 16, viewBox: "0 0 16 16", "aria-hidden": "true", focusable: "false" },
				h("path", {
					d: "M3 4.5A1.5 1.5 0 0 1 4.5 3h7A1.5 1.5 0 0 1 13 4.5v8A1.5 1.5 0 0 1 11.5 14h-7A1.5 1.5 0 0 1 3 12.5v-8Z",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: 1.2,
				}),
				h("path", { d: "M5.5 7h5M5.5 9.8h3", stroke: "currentColor", strokeWidth: 1.2, strokeLinecap: "round" }),
			);
		}

		function IconTaskShort() {
			return h(
				"svg",
				{ width: 16, height: 16, viewBox: "0 0 16 16", "aria-hidden": "true", focusable: "false" },
				h("circle", { cx: 8, cy: 8, r: 5.4, fill: "none", stroke: "currentColor", strokeWidth: 1.2 }),
				h("path", {
					d: "M8 5.2V8l1.9 1.2",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: 1.2,
					strokeLinecap: "round",
					strokeLinejoin: "round",
				}),
			);
		}

		// ── styles ────────────────────────────────────────────────────────────
		// Copied from the host's own primitives with this plugin's own class
		// prefix; only `--dsw-*` theme tokens are referenced, so a renamed token
		// degrades appearance without breaking rendering. Injected once from
		// `apply` and removed by the same effect.
		//
		// The two rows this chip can sit in use different chip scales in the
		// shipped UI, so the chip carries one class per row and matches that
		// row's neighbour exactly:
		//   header  `AgentPresetLabel`  12px / 22px / label-tertiary / tsp fill
		//   hero    `AgentPresetSeat`   13px / 28px / label-primary
		const CSS = `
.stt-dock{position:relative;font-family:inherit}
.stt-dock--lifted{height:0;margin-bottom:calc(-1 * var(--dsh-composer-stack-gap, 6px))}
.stt-dock--inline{display:flex;align-items:center;gap:2px;padding:0 16px 0 20px}
.stt-chipAnchor{display:inline-flex;min-width:0}
.stt-chip{display:inline-flex;align-items:center;gap:4px;min-width:0;border:none;background:transparent;white-space:nowrap;cursor:pointer;font-family:inherit;overflow:hidden;text-overflow:ellipsis}
.stt-chip--header{max-width:180px;height:22px;padding:0 4px 0 2px;border-radius:var(--dsw-radius-xs);background:var(--dsw-alias-fill-tsp-secondary);color:var(--dsw-alias-label-tertiary);font-size:12px;font-weight:400;line-height:22px}
.stt-chip--hero{max-width:min(100%,240px);min-height:28px;padding:0 8px;border-radius:var(--dsw-radius-sm);color:var(--dsw-alias-label-primary);font-size:13px;font-weight:500;line-height:20px}
.stt-chip:not(:disabled):hover,.stt-chip[aria-expanded=true]{background:var(--dsw-alias-interactive-bg-hover)}
.stt-chip:disabled{cursor:default;color:var(--dsw-alias-label-quaternary)}
.stt-chipIcon{display:inline-flex;flex:none;align-items:center;justify-content:center;opacity:.7}
.stt-chip--header .stt-chipIcon{width:14px;height:14px}
.stt-chip--hero .stt-chipIcon{width:16px;height:16px;opacity:1}
.stt-chipLabel{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.stt-chevron{display:inline-flex;flex:none;color:var(--dsw-alias-label-caption)}
.stt-menu{position:fixed;z-index:1100;box-sizing:border-box;min-width:190px;max-width:320px;padding:4px;display:flex;flex-direction:column;border-radius:var(--dsw-radius-lg);border:.5px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-overlay);box-shadow:0 10px 30px rgba(0,0,0,.18);font-family:inherit}
.stt-menuLabel{padding:6px 8px;font-size:11px;line-height:15px;color:var(--dsw-alias-label-tertiary)}
.stt-menuItem{display:flex;align-items:center;gap:6px;width:100%;min-height:34px;padding:6px 8px;border:none;border-radius:var(--dsw-radius-md);background:transparent;color:var(--dsw-alias-label-primary);font-size:13px;line-height:20px;text-align:left;cursor:pointer;font-family:inherit}
.stt-menuItem:hover:not(:disabled),.stt-menuItem:focus-visible:not(:disabled){background:var(--dsw-alias-interactive-bg-hover);outline:none}
.stt-menuItem:disabled{opacity:.4;cursor:not-allowed}
.stt-check{display:inline-flex;flex:none;color:var(--dsw-alias-label-primary)}
.stt-separator{height:.5px;margin:3px 2px;background:var(--dsw-alias-border-l2)}
.stt-menuFoot{padding:6px 8px;font-size:11px;line-height:15px;color:var(--dsw-alias-label-tertiary)}
.stt-mark{display:inline-flex;align-items:center;justify-content:center;font-size:9px;line-height:12px;letter-spacing:-.5px;white-space:nowrap;opacity:.5;color:var(--dsw-alias-label-tertiary)}
`;

		// ── anchored dropdown ─────────────────────────────────────────────────
		const MENU_MARGIN = 12;

		/**
		 * One anchored dropdown card. Portaled to the document body so no
		 * ancestor's overflow or transform can clip it, matching how the host's
		 * own menus behave. Closes on Escape, on an outside pointer press, and on
		 * window resize or scroll.
		 * @param props.anchor - the trigger element the card is positioned against.
		 * @param props.children - menu rows.
		 * @param props.onClose - close request.
		 */
		function AnchoredMenu({ anchor, children, onClose }) {
			const [style, setStyle] = React.useState(null);
			const ref = React.useRef(null);

			React.useLayoutEffect(() => {
				const node = ref.current;
				if (node === null || anchor === null) return undefined;
				const place = () => {
					const rect = anchor.getBoundingClientRect();
					const width = node.offsetWidth || 200;
					const height = node.offsetHeight || 200;
					const left = Math.max(MENU_MARGIN, Math.min(rect.left, window.innerWidth - width - MENU_MARGIN));
					const below = window.innerHeight - rect.bottom - MENU_MARGIN;
					const openUp = below < height && rect.top > below;
					setStyle({
						left: `${left}px`,
						top: openUp ? "auto" : `${rect.bottom + 4}px`,
						bottom: openUp ? `${window.innerHeight - rect.top + 4}px` : "auto",
						maxHeight: `${Math.max(160, (openUp ? rect.top : window.innerHeight - rect.bottom) - 16)}px`,
					});
				};
				place();
				window.addEventListener("resize", place);
				window.addEventListener("scroll", place, true);
				return () => {
					window.removeEventListener("resize", place);
					window.removeEventListener("scroll", place, true);
				};
			}, [anchor]);

			React.useEffect(() => {
				const onPointerDown = (event) => {
					const node = ref.current;
					if (node !== null && event.target instanceof Node && node.contains(event.target)) return;
					if (anchor !== null && event.target instanceof Node && anchor.contains(event.target)) return;
					onClose();
				};
				const onKeyDown = (event) => {
					if (event.key === "Escape") {
						event.stopPropagation();
						onClose();
					}
				};
				document.addEventListener("pointerdown", onPointerDown, true);
				document.addEventListener("keydown", onKeyDown, true);
				return () => {
					document.removeEventListener("pointerdown", onPointerDown, true);
					document.removeEventListener("keydown", onKeyDown, true);
				};
			}, [anchor, onClose]);

			React.useEffect(() => {
				const node = ref.current;
				if (node === null) return;
				const first = node.querySelector('[role="menuitemradio"]');
				if (first instanceof HTMLElement) first.focus();
			}, []);

			const onKeyDownInMenu = (event) => {
				if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
				const node = ref.current;
				if (node === null) return;
				const items = Array.from(node.querySelectorAll('[role="menuitemradio"]:not(:disabled)'));
				if (items.length === 0) return;
				event.preventDefault();
				const index = items.indexOf(document.activeElement);
				const step = event.key === "ArrowDown" ? 1 : -1;
				const next = index < 0 ? (step > 0 ? 0 : items.length - 1) : (index + step + items.length) % items.length;
				items[next].focus();
			};

			if (typeof document === "undefined") return null;
			return createPortal(
				h(
					"div",
					{
						ref,
						className: "stt-menu",
						role: "menu",
						style: style === null ? { left: "-9999px", top: "0px" } : style,
						onKeyDown: onKeyDownInMenu,
					},
					children,
				),
				document.body,
			);
		}

		/**
		 * One selectable row of the dropdown.
		 * @param props.selected - whether this row carries the current value.
		 * @param props.onSelect - activation.
		 * @param props.children - label text.
		 */
		function MenuItem({ selected, onSelect, children }) {
			return h(
				"button",
				{
					type: "button",
					role: "menuitemradio",
					"aria-checked": selected === true,
					className: "stt-menuItem",
					onClick: onSelect,
				},
				h("span", { className: "stt-check" }, selected === true ? h(IconCheck, null) : h("span", { style: { width: 14, height: 14, display: "inline-block" } })),
				h("span", { className: "stt-menuItemLabel" }, children),
			);
		}

		// ── the selector chip ─────────────────────────────────────────────────
		/**
		 * Lift a dock entry into the chip row directly above it.
		 *
		 * The blank-session Hero row (`heroWorkspaceRow`) exposes no third-party
		 * seat: its two holes are `single` slots already owned by the workspace
		 * picker and the agent-preset chip, so a plugin cannot become a flex item
		 * of that row. Instead the entry measures the row above it once and pins
		 * its chip just past that row's last chip, using the measured gap so the
		 * spacing matches the row's own `gap`. When no such row exists — or its
		 * geometry is not a single chip line — the chip stays in normal flow.
		 *
		 * @param dockRef - ref on the dock entry root.
		 * @param active - whether this entry should ride up at all.
		 * @returns `{ left, lift }` while riding, `{ inline: true }` for the safe
		 * in-flow fallback, or null when the chip must not render here at all.
		 */
		function useHeroRowRide(dockRef, active) {
			const [ride, setRide] = React.useState(null);
			React.useLayoutEffect(() => {
				const dock = dockRef.current;
				if (dock === null || !active) {
					setRide((current) => (current === null ? current : null));
					return undefined;
				}
				// The Session header's action outlet exists only while its chrome is
				// visible. When it is absent we are unambiguously in the blank-session
				// layout, so an in-flow chip cannot duplicate the header one.
				const headerAbsent = () => document.querySelector('[data-slot="conversation.session.header.actions"]') === null;
				const toFallback = () => {
					if (headerAbsent()) setRide((current) => (current !== null && current.inline === true ? current : { inline: true }));
					else setRide((current) => (current === null ? current : null));
				};
				const rowOf = () => {
					const candidates = [];
					if (dock.previousElementSibling !== null) candidates.push(dock.previousElementSibling);
					const parent = dock.parentElement;
					if (parent !== null && parent.previousElementSibling !== null) candidates.push(parent.previousElementSibling);
					for (const candidate of candidates) {
						if (candidate.children.length >= 2 && candidate.querySelector("button") !== null) return candidate;
					}
					return null;
				};
				const measure = () => {
					const row = rowOf();
					const dockRect = dock.getBoundingClientRect();
					if (row === null) {
						toFallback();
						return;
					}
					const rowRect = row.getBoundingClientRect();
					// Every slot outlet is a `display:contents` anchor whose own rect is
					// empty, so the row's trailing edge is the rightmost VISIBLE
					// descendant, never `lastElementChild` (which is that anchor).
					let right = rowRect.left;
					for (const el of Array.from(row.querySelectorAll("*"))) {
						const r = el.getBoundingClientRect();
						if (r.width > 0 && r.height > 0 && r.right > right) right = r.right;
					}
					const hasControl = row.querySelector("button") !== null;
					// Only a single chip line qualifies: a real control, a chip-row
					// height, and visible content. Anything else keeps the chip out of
					// the row rather than guessing a position.
					if (rowRect.height < 16 || rowRect.height > 64 || right <= rowRect.left || !hasControl) {
						toFallback();
						return;
					}
					const rawLeft = right - dockRect.left + 2;
					const rawLift = dockRect.top - rowRect.bottom;
					// Never place the chip on a non-finite offset: a bad measurement must
					// degrade to the in-flow fallback, not to an invalid style.
					if (!Number.isFinite(rawLeft) || !Number.isFinite(rawLift)) {
						toFallback();
						return;
					}
					const left = Math.max(0, rawLeft);
					const lift = Math.max(0, rawLift);
					setRide((current) => (current !== null && current.left === left && current.lift === lift ? current : { left, lift }));
				};
				measure();
				window.addEventListener("resize", measure);
				// The row is a full-width flex line, so its own box does not change when
				// a chip appears inside it (the agent-preset chip mounts only after its
				// roster loads) — a ResizeObserver on the row alone would keep a stale
				// offset. A MutationObserver re-measures whenever the row's content
				// changes, which is what actually moves its trailing edge.
				let observer = null;
				if (typeof ResizeObserver !== "undefined") {
					observer = new ResizeObserver(measure);
					observer.observe(dock);
					const row = rowOf();
					if (row !== null) observer.observe(row);
				}
				let mutations = null;
				if (typeof MutationObserver !== "undefined") {
					const row = rowOf();
					if (row !== null) {
						mutations = new MutationObserver(measure);
						mutations.observe(row, { childList: true, subtree: true, attributes: true });
					}
				}
				return () => {
					window.removeEventListener("resize", measure);
					if (observer !== null) observer.disconnect();
					if (mutations !== null) mutations.disconnect();
				};
			}, [dockRef, active]);
			return ride;
		}

		/**
		 * The task-tag selector: one chip that opens the tag / window menu.
		 *
		 * Two registrations share it. In the conversation phase it is an ordinary
		 * flex item of the Session header's action row (`headerActions`, gap 8px),
		 * so it sits beside the agent-preset chip with the row's own spacing. In
		 * the blank-session Hero it rides up into the workspace/preset chip row
		 * through {@link useHeroRowRide}.
		 *
		 * @param props.sessionId - the open Session.
		 * @param props.t - the locale seat bound to this plugin's namespace.
		 * @param props.variant - `dock` (composer dock) or `header`.
		 * @param props.useSession - standard Session snapshot selector.
		 */
		function TaskTagSelector({ sessionId, t, variant, useSession }) {
			const snapshot = useStore();
			const heroPhase = useSession((session) => session !== undefined && session.blank === true);
			const [open, setOpen] = React.useState(false);
			const [failure, setFailure] = React.useState(null);
			const dockRef = React.useRef(null);
			const buttonRef = React.useRef(null);
			const riding = variant === "dock";
			const ride = useHeroRowRide(dockRef, riding && heroPhase);

			React.useEffect(() => {
				if (snapshot.phase === "loading") void refresh();
			}, [snapshot.phase]);

			if (riding && !heroPhase) return null;

			const record = recordOf(snapshot, sessionId);
			const isShort = record.kind === KIND_SHORT;
			const archived = record.archivedAt !== null && record.archivedAt !== undefined;
			const config = snapshot.config;
			// Offer exactly what the Host supports. The long-window set is absent on
			// a Host generation that predates it, and then a long-term task is
			// manual-only — which is also what that Host enforces.
			const shortOptions = firstNonEmpty([config.shortArchiveOptions, config.archiveOptions, SHORT_OPTIONS_FALLBACK]);
			const longOptions = Array.isArray(config.longArchiveOptions) ? config.longArchiveOptions : [];
			const shortDefaultCandidate = config.defaultShortArchiveAfterDays ?? config.defaultArchiveAfterDays;
			const shortDefault = shortOptions.includes(shortDefaultCandidate) ? shortDefaultCandidate : shortOptions[0];
			// `archiveAfterDays === null` is MANUAL: the long-term default, and the
			// only state the sweep never touches.
			const windowDays = positiveDays(record.archiveAfterDays);
			const label = isShort ? t("chipShort") : t("chipLong");
			// The set window and the live countdown ride in the chip's own text, at
			// the same colour and type scale as the label so the chip keeps matching
			// the neighbouring chips.
			let meta = null;
			if (archived) meta = t("chipArchived");
			else if (windowDays !== null && record.archiveAt !== null && record.archiveAt !== undefined) {
				meta = t("chipMeta", { days: windowDays, left: daysLeft(record.archiveAt) });
			}
			const chipText = meta === null ? label : `${label} ${meta}`;
			const chipClass = variant === "header" ? "stt-chip stt-chip--header" : "stt-chip stt-chip--hero";

			const apply = (kind, days) => {
				setOpen(false);
				setFailure(null);
				writeTag(sessionId, kind, days).catch((error) => {
					setFailure(error instanceof Error ? error.message : String(error));
				});
			};

			const rows = [
				h("div", { className: "stt-menuLabel", key: "task-label" }, t("menuTaskType")),
				h(
					MenuItem,
					{ key: "long", selected: !isShort, onSelect: () => apply(KIND_LONG, windowDays === null ? undefined : windowDays) },
					t("chipLong"),
				),
				h(
					MenuItem,
					{ key: "short", selected: isShort, onSelect: () => apply(KIND_SHORT, isShort && windowDays !== null ? windowDays : shortDefault) },
					t("chipShort"),
				),
			];

			// Long-term: manual by default, plus the longer auto windows.
			if (!isShort) {
				rows.push(h("div", { className: "stt-separator", key: "sep-mode" }));
				rows.push(h("div", { className: "stt-menuLabel", key: "mode-label" }, t("menuArchiveMode")));
				rows.push(
					h(
						MenuItem,
						{ key: "manual", selected: windowDays === null, onSelect: () => apply(KIND_LONG, undefined) },
						t("menuManual"),
					),
				);
				for (const days of longOptions) {
					rows.push(
						h(
							MenuItem,
							{ key: `days-${days}`, selected: windowDays === days, onSelect: () => apply(KIND_LONG, days) },
							t("days", { n: days }),
						),
					);
				}
			}

			if (isShort) {
				rows.push(h("div", { className: "stt-separator", key: "sep" }));
				rows.push(h("div", { className: "stt-menuLabel", key: "window-label" }, t("menuArchiveWindow")));
				for (const days of shortOptions) {
					rows.push(
						h(
							MenuItem,
							{ key: `days-${days}`, selected: windowDays === days, onSelect: () => apply(KIND_SHORT, days) },
							t("days", { n: days }),
						),
					);
				}
			}

			rows.push(
				h(
					"div",
					{ className: "stt-menuFoot", key: "deadline" },
					archived
						? t("chipArchived")
						: windowDays === null
							? t("menuManualHint")
							: config.autoArchiveEnabled === false
								? t("menuArchiveOff")
								: record.archiveAt !== null && record.archiveAt !== undefined
									? t("menuDeadlineLeft", { date: formatDate(record.archiveAt), left: daysLeft(record.archiveAt) })
									: t("menuArchiveHint"),
				),
			);

			rows.push(
				h(
					"div",
					{ className: "stt-menuFoot", key: "agent" },
					t("menuAgent", { name: record.agentPresetName || record.agentPresetId || t("agentModeNone") }),
				),
			);

			const chip = h(
				"button",
				{
					ref: buttonRef,
					type: "button",
					className: chipClass,
					"aria-haspopup": "menu",
					"aria-expanded": open,
					"aria-label": chipText,
					title: failure === null ? chipText : `${chipText} — ${t("saveFailed")}`,
					onClick: () => setOpen((value) => !value),
				},
				h("span", { className: "stt-chipIcon" }, isShort ? h(IconTaskShort, null) : h(IconTaskLong, null)),
				h("span", { className: "stt-chipLabel" }, chipText),
				h("span", { className: "stt-chevron" }, h(IconChevronDown, null)),
			);

			const menu = open ? h(AnchoredMenu, { anchor: buttonRef.current, onClose: () => setOpen(false) }, rows) : null;

			if (!riding) {
				return h("div", { className: "stt-chipAnchor" }, chip, menu);
			}

			// The dock entry exists only to carry the chip into the blank-session
			// chip row. It always renders an anchor so that row can be measured.
			// While riding, the chip is pinned just past the row's last chip; if the
			// row cannot be identified it falls back to a plain in-flow line, and it
			// renders nothing at all when the Session header is the surface showing
			// the chip (a second one here would be a duplicate).
			const inline = ride !== null && ride.inline === true;
			const lifted = ride !== null && ride.inline !== true;
			return h(
				"div",
				{
					className: inline ? "stt-dock stt-dock--inline" : "stt-dock stt-dock--lifted",
					ref: dockRef,
					style: lifted ? { marginBottom: `${-ride.lift}px` } : undefined,
				},
				ride === null
					? null
					: h(
						"div",
						{
							className: "stt-chipAnchor",
							style: lifted
								? { position: "absolute", left: `${ride.left}px`, bottom: `calc(100% + ${ride.lift}px)` }
								: undefined,
						},
						chip,
						menu,
					),
			);
		}

		/**
		 * The compact 50%-translucent mark in the Session row's leading cell.
		 * @param props.sessionId - the row's Session.
		 * @param props.t - the locale seat.
		 */
		function SessionTagMark({ sessionId, t }) {
			const snapshot = useStore();
			React.useEffect(() => {
				if (snapshot.phase === "loading") void refresh();
			}, [snapshot.phase]);
			const record = recordOf(snapshot, sessionId);
			const isShort = record.kind === KIND_SHORT;
			return h("span", { className: "stt-mark" }, isShort ? t("markShort") : t("markLong"));
		}

		// ── plugin ────────────────────────────────────────────────────────────
		/** Client services this half waits for before mounting. */
		const inject = ["slots", "locale"];

		/**
		 * Mount the browser half.
		 * @param ctx - Client plugin context.
		 */
		function apply(ctx) {
			ctx.effect(() => ctx.locale.register(NS, { zh, en }), "dsh-session-task-tags: dictionaries");

			ctx.effect(() => {
				const tag = document.createElement("style");
				tag.dataset.plugin = "dsh-session-task-tags";
				tag.textContent = CSS;
				document.head.appendChild(tag);
				return () => {
					tag.remove();
				};
			}, "dsh-session-task-tags: styles");

			// Keep the snapshot warm so a sidebar mark is never the first reader,
			// and refresh it periodically so countdowns stay truthful.
			ctx.effect(() => {
				void refresh();
				const timer = setInterval(() => {
					void refresh();
				}, 60 * 1000);
				const onVisible = () => {
					if (document.visibilityState === "visible") void refresh();
				};
				document.addEventListener("visibilitychange", onVisible);
				return () => {
					clearInterval(timer);
					document.removeEventListener("visibilitychange", onVisible);
				};
			}, "dsh-session-task-tags: snapshot refresh");

			// Conversation phase: the Session header's action row, right after the
			// agent-preset chip (orders -30/-20/-10/20) and before the job list.
			// The row's own flex gap supplies the spacing.
			ctx.slots.inject("conversation.session.header.actions", () =>
				ctx.slots.register(
					{
						name: "conversation.session.header.actions",
						id: "session-task-tag",
						order: 0,
						locale: NS,
						inject: () => ({ variant: "header" }),
					},
					TaskTagSelector,
				),
			);

			// New-Session phase: the composer dock, riding up into the workspace /
			// agent-preset chip row. The header action row is not rendered while
			// the Hero chrome is hidden, so the two never show at once.
			ctx.slots.inject("conversation.input.dock", () =>
				ctx.slots.register(
					{
						name: "conversation.input.dock",
						id: "session-task-tag",
						order: -10,
						locale: NS,
						inject: () => ({ variant: "dock" }),
					},
					TaskTagSelector,
				),
			);

			ctx.slots.inject("sidebar.session.row.leading", () =>
				ctx.slots.register(
					{
						name: "sidebar.session.row.leading",
						id: "session-task-tag",
						order: 20,
						locale: NS,
					},
					SessionTagMark,
				),
			);
		}

		exports.apply = apply;
		exports.inject = inject;
		return module.exports;
	},
});
