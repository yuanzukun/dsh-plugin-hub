/**
 * dsh-session-task-tags — Host half.
 *
 * Owns one durable record per Session: its task tag (long-term / short-term),
 * the short-term auto-archive window, and the agent preset the Session was
 * created with. A periodic sweep archives short-term Sessions whose window
 * has elapsed through the workspace registry, and the browser half reads and
 * writes the same records over one HTTP route.
 *
 * Why an HTTP route instead of a `@Remote` namespace: the Typert Remote client
 * surface is generated at build time (`ctx.remote.$mount()` consumes generated
 * descriptors), and this plugin ships hand-written plain JavaScript with no
 * build step. `ctx.webServer.register` is the documented Host route registry
 * and the same shape a shipped plugin uses for its own browser API.
 *
 * The Host half imports nothing but Node builtins on purpose: a profile's
 * `node_modules` also holds an older copy of every `@deepseek-ai` package, so
 * importing one would load a second, version-mismatched module generation.
 *
 * @module dsh-session-task-tags
 */
import { mkdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'

/** Cordis plugin name (also the Loader row id). */
export const name = 'dsh-session-task-tags'

/** Services required before mounting: the route table and the archive writer. */
export const inject = ['webServer', 'workspaceRegistry']

/** Route prefix owned by this plugin; no other plugin may claim it. */
const API_PREFIX = '/session-task-tags/api'

/** Tag values. `long` is the default for every Session. */
const KIND_LONG = 'long'
const KIND_SHORT = 'short'

/** Record schema version; a stored file with another version is discarded. */
const STATE_VERSION = 1

/** Body cap for the JSON route (records are tiny; this only bounds abuse). */
const MAX_BODY_BYTES = 64 * 1024

const DAY_MS = 24 * 60 * 60 * 1000

/** Short-term windows, in days. */
const DEFAULT_SHORT_OPTIONS = [1, 5, 7, 15, 30]
/** Long-term windows, in days: 15 up to 90 in steps of 10. */
const DEFAULT_LONG_OPTIONS = [15, 25, 35, 45, 55, 65, 75, 85]
/** Default short-term window, in days. */
const DEFAULT_SHORT_DAYS = 7

/**
 * Resolve the harness home the way `@deepseek-ai/dsh-home-paths` does:
 * an explicit configured path, then `$DSH_HOME`, then `~/.dsh`.
 * @param config - plugin config that may carry an explicit `home`.
 * @returns the absolute harness home.
 */
function resolveHome(config) {
  const configured = typeof config?.home === 'string' ? config.home.trim() : ''
  if (configured !== '') return configured
  const env = typeof process.env.DSH_HOME === 'string' ? process.env.DSH_HOME.trim() : ''
  if (env !== '') return env
  return join(homedir(), '.dsh')
}

/**
 * Normalize one positive integer config value.
 * @param value - candidate.
 * @param fallback - value used when the candidate is absent or invalid.
 * @returns the normalized integer.
 */
function positiveInt(value, fallback) {
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : fallback
}

/**
 * Normalize the selectable auto-archive windows: positive whole days,
 * de-duplicated and ascending.
 * @param value - candidate array from config.
 * @param fallback - array used when the candidate is absent or empty.
 * @returns the normalized day list.
 */
function dayOptions(value, fallback) {
  const source = Array.isArray(value) ? value : fallback
  const days = []
  for (const entry of source) {
    const n = positiveInt(entry, 0)
    if (n > 0 && !days.includes(n)) days.push(n)
  }
  if (days.length === 0) days.push(...fallback)
  days.sort((a, b) => a - b)
  return days
}

/**
 * Resolve the effective plugin config once at activation.
 *
 * Both task kinds can auto-archive: a short-term task always carries a small
 * window, while a long-term task is MANUAL by default and may opt into one of
 * the longer windows.
 *
 * @param config - the Loader row's raw config object.
 * @returns the resolved configuration.
 */
function resolveConfig(config) {
  const shortOptions = dayOptions(config?.shortArchiveOptions, DEFAULT_SHORT_OPTIONS)
  const longOptions = dayOptions(config?.longArchiveOptions, DEFAULT_LONG_OPTIONS)
  const requestedShort = positiveInt(config?.defaultShortArchiveAfterDays, 0)
  const shortDefault = shortOptions.includes(requestedShort)
    ? requestedShort
    : shortOptions.includes(DEFAULT_SHORT_DAYS)
      ? DEFAULT_SHORT_DAYS
      : shortOptions[0]
  return {
    home: resolveHome(config),
    shortArchiveOptions: shortOptions,
    longArchiveOptions: longOptions,
    defaultShortArchiveAfterDays: shortDefault,
    sweepIntervalMinutes: positiveInt(config?.sweepIntervalMinutes, 5),
    autoArchiveEnabled: config?.autoArchiveEnabled !== false,
  }
}

// ── request trust fence ────────────────────────────────────────────────────
// Behaviorally identical to the /api gateway's fence in
// @deepseek-ai/dsh-client-connection (src/api-request-trust.ts): a Host-header
// loopback authority passes, cross-site browser markers refuse. This is a
// DNS-rebinding / cross-site defense, not authentication; the server itself
// binds loopback by default.

/**
 * Whether a normalized hostname names the local loopback authority.
 * @param hostname - URL hostname.
 * @returns true for localhost, [::1], and 127.0.0.0/8.
 */
function isLoopbackHostname(hostname) {
  if (hostname === 'localhost' || hostname === '[::1]') return true
  const parts = hostname.split('.')
  return (
    parts.length === 4 &&
    parts[0] === '127' &&
    parts.every((part) => /^\d{1,3}$/.test(part) && Number(part) <= 255)
  )
}

/**
 * Decide whether one request may reach this plugin's routes.
 * @param req - node HTTP request.
 * @returns true when the Host header is ours and browser markers are same-origin.
 */
function isTrustedRequest(req) {
  const rawHost = req.headers.host
  if (typeof rawHost !== 'string' || rawHost === '') return false
  let hostUrl
  try {
    hostUrl = new URL(`http://${rawHost}`)
  } catch {
    return false
  }
  if (!isLoopbackHostname(hostUrl.hostname)) return false
  if (req.headers['sec-fetch-site'] === 'cross-site') return false
  const origin = req.headers.origin
  if (typeof origin !== 'string') return true
  try {
    return new URL(origin).hostname === hostUrl.hostname
  } catch {
    return false
  }
}

/**
 * Write one JSON envelope.
 * @param res - node HTTP response.
 * @param status - HTTP status.
 * @param body - JSON-serializable body.
 */
function writeJson(res, status, body) {
  const text = JSON.stringify(body)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'content-length': Buffer.byteLength(text),
  })
  res.end(text)
}

/**
 * Answer one failed call with the stable wire envelope the browser reads.
 * @param res - node HTTP response.
 * @param status - HTTP status.
 * @param code - stable failure code.
 * @param message - human-readable reason.
 */
function writeError(res, status, code, message) {
  writeJson(res, status, { ok: false, error: { code, message } })
}

/**
 * Read and parse a JSON request body with a hard size cap.
 * @param req - node HTTP request.
 * @returns the parsed body, or undefined when absent/oversized/unparsable.
 */
function readJsonBody(req) {
  return new Promise((resolve) => {
    const chunks = []
    let size = 0
    let settled = false
    const finish = (value) => {
      if (settled) return
      settled = true
      resolve(value)
    }
    req.on('data', (chunk) => {
      size += chunk.length
      if (size > MAX_BODY_BYTES) {
        finish(undefined)
        req.destroy()
        return
      }
      chunks.push(chunk)
    })
    req.on('error', () => finish(undefined))
    req.on('end', () => {
      if (chunks.length === 0) {
        finish({})
        return
      }
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'))
        finish(parsed !== null && typeof parsed === 'object' ? parsed : undefined)
      } catch {
        finish(undefined)
      }
    })
  })
}

/**
 * Mount the plugin.
 * @param ctx - Host plugin context.
 * @param config - the Loader row's config.
 */
export function apply(ctx, config) {
  const settings = resolveConfig(config)
  const stateDir = join(settings.home, 'plugin-data', 'dsh-session-task-tags')
  const statePath = join(stateDir, 'state.json')

  /** sessionId -> record. Plain JSON so the file stays inspectable. */
  let records = {}
  /** Lazily resolved agent-preset id -> display name. */
  let presetNames = undefined
  /** One write at a time: the state file is rewritten whole. */
  let writeChain = Promise.resolve()

  /**
   * Load the durable file once; a missing, malformed, or stale-version file
   * starts empty rather than failing activation. A byte-order mark is stripped
   * first: `JSON.parse` rejects one, and a hand-edited file that carries it must
   * not silently discard every stored tag.
   */
  function load() {
    try {
      const parsed = JSON.parse(readFileSync(statePath, 'utf8').replace(/^\uFEFF/, ''))
      if (parsed?.version === STATE_VERSION && parsed.records !== null && typeof parsed.records === 'object') {
        records = parsed.records
      }
    } catch {
      records = {}
    }
  }

  /** Persist the whole state atomically (temp file in the same directory). */
  function persist() {
    writeChain = writeChain.then(async () => {
      const temp = `${statePath}.${process.pid}.tmp`
      try {
        mkdirSync(dirname(statePath), { recursive: true })
        writeFileSync(temp, JSON.stringify({ version: STATE_VERSION, records }, null, 2), 'utf8')
        renameSync(temp, statePath)
      } catch (error) {
        try {
          unlinkSync(temp)
        } catch {
          /* the temp file may not exist */
        }
        ctx.logger?.warn?.(`${name}: state write failed`)
        ctx.logger?.warn?.(error)
      }
    })
    return writeChain
  }

  /**
   * Read one Session's record, creating the default record on first touch: a
   * long-term task with MANUAL archiving (`archiveAfterDays: null`). The
   * default is never persisted on read alone.
   * @param sessionId - Session identity.
   * @param persistDefault - whether a freshly created record must be written.
   * @returns the record.
   */
  function ensureRecord(sessionId, persistDefault) {
    const existing = records[sessionId]
    if (existing !== undefined && typeof existing === 'object') return existing
    const now = Date.now()
    const record = {
      kind: KIND_LONG,
      archiveAfterDays: null,
      agentPresetId: null,
      agentPresetName: null,
      taggedAt: now,
      lastActivityAt: now,
      archivedAt: null,
      autoArchived: false,
    }
    records[sessionId] = record
    if (persistDefault) void persist()
    return record
  }

  /**
   * Resolve an agent preset's display name through the optional registry. A
   * preset that ships no name resolves to the empty string when it is the
   * default one, so the browser falls back to its own "default mode" copy
   * instead of showing a raw id.
   * @param presetId - preset identity from `agent-preset/selected`.
   * @returns the display name, or undefined when the registry cannot answer.
   */
  async function presetName(presetId) {
    const registry = ctx.get('agentPresets')
    if (registry === undefined) return undefined
    if (presetNames === undefined) {
      try {
        const list = await registry.list()
        presetNames = new Map(list.map((entry) => [entry.id, entry.name ?? (entry.isDefault === true ? '' : entry.id)]))
      } catch {
        presetNames = new Map()
      }
    }
    return presetNames.get(presetId)
  }

  /**
   * Record the agent preset a Session committed, which is the Session's
   * "agent mode" tag. Re-resolving on every agent creation lets a name that
   * was unavailable earlier heal itself.
   * @param sessionId - Session identity.
   * @param presetId - committed preset id.
   */
  function rememberPreset(sessionId, presetId) {
    if (typeof sessionId !== 'string' || sessionId === '' || typeof presetId !== 'string' || presetId === '') return
    const record = ensureRecord(sessionId, false)
    if (record.agentPresetId !== presetId) {
      record.agentPresetId = presetId
      void persist()
    }
    void presetName(presetId).then((label) => {
      if (records[sessionId] !== record) return
      const next = typeof label === 'string' && label !== '' ? label : null
      if (record.agentPresetName === next) return
      record.agentPresetName = next
      void persist()
    })
  }

  /** The moment an auto-archive window counts from: the later of tagging and activity. */
  function windowStart(record) {
    const tagged = typeof record.taggedAt === 'number' ? record.taggedAt : 0
    const active = typeof record.lastActivityAt === 'number' ? record.lastActivityAt : 0
    return Math.max(tagged, active)
  }

  /**
   * The instant a Session is due for archiving, or null when it has no window.
   * A record without a window is MANUAL — the long-term default — and is never
   * archived by the sweep.
   * @param record - one Session record.
   * @returns epoch milliseconds, or null.
   */
  function archiveDeadline(record) {
    if (record.archivedAt !== null) return null
    const days = positiveInt(record.archiveAfterDays, 0)
    if (days <= 0) return null
    return windowStart(record) + days * DAY_MS
  }

  /** Archive every Session whose auto-archive window elapsed. */
  async function sweep() {
    if (!settings.autoArchiveEnabled) return
    const now = Date.now()
    let changed = false
    for (const [sessionId, record] of Object.entries(records)) {
      const deadline = archiveDeadline(record)
      if (deadline === null || now < deadline) continue
      try {
        // stopActivity skips the activity waterfall and stops whatever still
        // runs for the Session; the durable archive set gates every wake.
        await ctx.workspaceRegistry.archiveSession(sessionId, { stopActivity: true })
        record.archivedAt = now
        record.autoArchived = true
        changed = true
        ctx.logger?.info?.(`${name}: auto-archived session ${sessionId} after ${record.archiveAfterDays} days`)
      } catch (error) {
        // A Session that no longer exists (or a refused stop) stays recorded;
        // the next sweep retries and the failure stays out of the timer.
        ctx.logger?.warn?.(`${name}: auto-archive refused for session ${sessionId}`)
        ctx.logger?.warn?.(error)
      }
    }
    if (changed) await persist()
  }

  load()

  // ── Host events ──────────────────────────────────────────────────────────
  ctx.effect(
    () =>
      ctx.on('session/created', (session) => {
        const id = session?.id
        if (typeof id !== 'string' || id === '') return
        ensureRecord(id, true)
      }),
    `${name}: session/created`,
  )

  ctx.effect(
    () =>
      ctx.on('agent-preset/selected', (sessionId, agentPreset) => {
        rememberPreset(sessionId, agentPreset)
      }),
    `${name}: agent-preset/selected`,
  )

  ctx.effect(
    () =>
      ctx.on('agent/created', (payload) => {
        const agent = payload?.agent
        const id = agent?.id
        if (typeof id !== 'string' || id === '') return
        ensureRecord(id, true)
        const registry = ctx.get('agentPresets')
        if (registry === undefined) return
        try {
          const preset = registry.composedPreset(agent.ctx)
          if (typeof preset === 'string' && preset !== '') rememberPreset(id, preset)
        } catch {
          /* a Session without a composed preset keeps its current tag */
        }
      }),
    `${name}: agent/created`,
  )

  ctx.effect(
    () =>
      ctx.on('api-session/activity', (sessionId, updatedAt) => {
        if (typeof sessionId !== 'string' || sessionId === '') return
        const record = ensureRecord(sessionId, true)
        if (typeof updatedAt === 'number' && updatedAt > (record.lastActivityAt ?? 0)) {
          record.lastActivityAt = updatedAt
          void persist()
        }
      }),
    `${name}: api-session/activity`,
  )

  // ── Periodic sweep ───────────────────────────────────────────────────────
  ctx.effect(() => {
    const intervalMs = settings.sweepIntervalMinutes * 60 * 1000
    const timer = setInterval(() => {
      void sweep()
    }, intervalMs)
    timer.unref?.()
    // One early pass so a restart does not wait a whole interval.
    const kick = setTimeout(() => {
      void sweep()
    }, 5000)
    kick.unref?.()
    return () => {
      clearInterval(timer)
      clearTimeout(kick)
    }
  }, `${name}: auto-archive sweep`)

  // ── Browser API ──────────────────────────────────────────────────────────
  /**
   * Project the wire view of the whole tag table.
   * @returns the list payload.
   */
  function listPayload() {
    const now = Date.now()
    const wire = {}
    for (const [sessionId, record] of Object.entries(records)) {
      const days = positiveInt(record.archiveAfterDays, 0)
      wire[sessionId] = {
        kind: record.kind === KIND_SHORT ? KIND_SHORT : KIND_LONG,
        // null means MANUAL: no window, so the sweep never touches it.
        archiveAfterDays: days > 0 ? days : null,
        agentPresetId: record.agentPresetId ?? null,
        agentPresetName: record.agentPresetName ?? null,
        taggedAt: typeof record.taggedAt === 'number' ? record.taggedAt : null,
        lastActivityAt: typeof record.lastActivityAt === 'number' ? record.lastActivityAt : null,
        archiveAt: archiveDeadline(record),
        archivedAt: typeof record.archivedAt === 'number' ? record.archivedAt : null,
        autoArchived: record.autoArchived === true,
      }
    }
    return {
      records: wire,
      config: {
        shortArchiveOptions: settings.shortArchiveOptions,
        longArchiveOptions: settings.longArchiveOptions,
        defaultShortArchiveAfterDays: settings.defaultShortArchiveAfterDays,
        autoArchiveEnabled: settings.autoArchiveEnabled,
        sweepIntervalMinutes: settings.sweepIntervalMinutes,
      },
      now,
    }
  }

  /**
   * Apply one tag write.
   *
   * A short-term task always carries a window (an unknown value falls back to
   * the configured default). A long-term task is manual unless the requested
   * value is one of the configured long windows.
   *
   * @param body - `{ sessionId, kind, archiveAfterDays? }`.
   * @returns the updated wire record.
   */
  async function setTag(body) {
    const sessionId = typeof body?.sessionId === 'string' ? body.sessionId : ''
    if (sessionId === '') throw new Error('sessionId is required')
    const kind = body?.kind === KIND_SHORT ? KIND_SHORT : body?.kind === KIND_LONG ? KIND_LONG : undefined
    if (kind === undefined) throw new Error('kind must be "long" or "short"')
    const record = ensureRecord(sessionId, false)
    const requested = positiveInt(body?.archiveAfterDays, 0)
    record.kind = kind
    record.archiveAfterDays = kind === KIND_SHORT
      ? settings.shortArchiveOptions.includes(requested)
        ? requested
        : settings.defaultShortArchiveAfterDays
      : settings.longArchiveOptions.includes(requested)
        ? requested
        : null
    record.archivedAt = null
    record.autoArchived = false
    record.taggedAt = Date.now()
    if (typeof record.lastActivityAt !== 'number') record.lastActivityAt = record.taggedAt
    await persist()
    return listPayload().records[sessionId]
  }

  ctx.effect(
    () =>
      ctx.webServer.register({
        kind: 'prefix',
        path: API_PREFIX,
        handler: async (req, res) => {
          if (!isTrustedRequest(req)) {
            writeError(res, 403, 'forbidden', 'forbidden')
            return
          }
          const pathname = new URL(req.url ?? '/', 'http://dsh.internal').pathname
          const method = pathname.startsWith(`${API_PREFIX}/`) ? pathname.slice(API_PREFIX.length + 1) : ''
          if (method === 'list' && (req.method === 'GET' || req.method === 'POST')) {
            writeJson(res, 200, { ok: true, value: listPayload() })
            return
          }
          if (method === 'set' && req.method === 'POST') {
            const body = await readJsonBody(req)
            if (body === undefined) {
              writeError(res, 400, 'bad-body', 'request body is not a JSON object')
              return
            }
            try {
              writeJson(res, 200, { ok: true, value: { record: await setTag(body) } })
            } catch (error) {
              writeError(res, 400, 'invalid-request', error instanceof Error ? error.message : String(error))
            }
            return
          }
          writeError(res, 404, 'not-found', `unknown session-task-tags method "${method}"`)
        },
      }),
    `${name}: ${API_PREFIX} routes`,
  )

  ctx.logger?.info?.(`${name}: mounted (state: ${statePath})`)
}
