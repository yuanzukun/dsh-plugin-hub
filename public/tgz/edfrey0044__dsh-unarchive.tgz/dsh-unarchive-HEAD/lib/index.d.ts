/**
 * Type declarations for dsh-unarchive. The implementation is plain ESM with
 * no build step; these declarations describe the exported plugin contract for
 * TypeScript consumers and editors.
 */

import type { Context } from '@deepseek-ai/cordis'

/** Cordis plugin name used by Loader diagnostics. */
export const name: string

/** Services required at load: the command and tool registries plus the workspace registry. */
export const inject: readonly string[]

/**
 * Register the `/unarchive` command and the `unarchive_session` tool.
 * @param ctx - context carrying the command and tool registries.
 */
export function apply(ctx: Context): void
