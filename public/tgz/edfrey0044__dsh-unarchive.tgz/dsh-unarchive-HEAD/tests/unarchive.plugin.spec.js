/**
 * Stub-based unit tests for the dsh-unarchive plugin. The command and tool
 * registries are fakes; the workspace registry is a behavior stub. No DSH
 * boot happens here — the end-to-end shape (real storage-domain +
 * workspaceRegistry) lives in the repository's verification spec described
 * in the README.
 */

import { describe, expect, it, vi } from 'vitest'

vi.mock('@deepseek-ai/dsh-tools', () => ({
  defineTool: definition => definition,
}))

import { apply, inject, name } from '../lib/index.js'

/** A workspace registry stub that records unarchive calls and mutates the set. */
function makeRegistry(overrides = {}) {
  const registry = {
    archivedSessionIds: [],
    unarchiveSession: vi.fn(async function unarchiveSession(id) {
      registry.archivedSessionIds = registry.archivedSessionIds.filter(candidate => candidate !== id)
    }),
    ...overrides,
  }
  return registry
}

/** A fake storage-domain facility exposing a workspace domain global, for the self-contained fallback. */
function makeStorageDomain(initialIds) {
  const state = { initialized: true, workspaceIds: [], archivedSessionIds: [...initialIds] }
  const domain = {
    global: {
      get: () => state,
      set: async next => { Object.assign(state, next) },
    },
  }
  return {
    get: name => (name === 'workspace' ? domain : undefined),
  }
}

/** Boot the plugin against fakes and capture the registered definitions. */
function bootFake(registry, services = {}) {
  const commands = []
  const tools = []
  const ctx = {
    workspaceRegistry: registry,
    get: name => services[name],
    // Run the registration generator once; collect yielded disposers.
    effect: (generator) => {
      const iterator = generator()
      const disposers = []
      let step = iterator.next()
      while (!step.done) {
        disposers.push(step.value)
        step = iterator.next()
      }
      return () => disposers.reverse().forEach(dispose => dispose?.())
    },
    commands: {
      register: definition => {
        commands.push(definition)
        return () => {}
      },
    },
    tools: {
      register: definition => {
        tools.push(definition)
        return () => {}
      },
    },
  }
  apply(ctx)
  return { commands, tools, ctx }
}

describe('dsh-unarchive plugin registration', () => {
  it('exports a Loader-compatible namespace plugin', () => {
    expect(name).toBe('dsh-unarchive')
    expect(inject).toEqual(['commands', 'tools', 'workspaceRegistry'])
  })

  it('registers exactly one command and one tool', () => {
    const { commands, tools } = bootFake(makeRegistry())
    expect(commands.map(command => command.name)).toEqual(['unarchive'])
    expect(commands[0].description.length).toBeGreaterThan(0)
    expect(commands[0].input).toEqual({ hint: '<sessionId>' })
    expect(tools.map(tool => tool.name)).toEqual(['unarchive_session'])
    expect(tools[0].parameters.sessionId).toBeDefined()
  })
})

describe('/unarchive command', () => {
  it('lists archived sessions when no argument is given', async () => {
    const registry = makeRegistry({ archivedSessionIds: ['s-one', 's-two'] })
    const { commands } = bootFake(registry)
    const result = await commands[0].handler({ rawInput: '  ' })
    expect(result).toEqual({
      kind: 'success',
      text: 'Archived sessions:\n- s-one\n- s-two',
    })
    expect(registry.unarchiveSession).not.toHaveBeenCalled()
  })

  it('reports an empty set without calling the registry', async () => {
    const registry = makeRegistry()
    const { commands } = bootFake(registry)
    const result = await commands[0].handler({ rawInput: '' })
    expect(result).toEqual({ kind: 'success', text: 'No archived sessions.' })
    expect(registry.unarchiveSession).not.toHaveBeenCalled()
  })

  it('shows best-effort titles from the projection cache when available', async () => {
    const registry = makeRegistry({ archivedSessionIds: ['s-one'] })
    const services = {
      sessionProjectionCache: {
        cachedSnapshot: header => (header.id === 's-one' ? { values: { title: '张雪峰谈报考' } } : undefined),
      },
      sessionPersistence: {
        list: async () => [{ id: 's-one', createdAt: 100, cwd: '/work' }],
      },
    }
    const { commands } = bootFake(registry, services)
    const result = await commands[0].handler({ rawInput: '' })
    expect(result.text).toBe('Archived sessions:\n- s-one  (张雪峰谈报考)')
  })

  it('falls back to the bare id when titles are unavailable', async () => {
    const registry = makeRegistry({ archivedSessionIds: ['s-one'] })
    const services = {
      sessionProjectionCache: { cachedSnapshot: () => undefined },
      sessionPersistence: { list: async () => [] },
    }
    const { commands } = bootFake(registry, services)
    const result = await commands[0].handler({ rawInput: '' })
    expect(result.text).toBe('Archived sessions:\n- s-one')
  })

  it('restores an archived session id', async () => {
    const registry = makeRegistry({ archivedSessionIds: ['s-gone', 's-kept'] })
    const { commands } = bootFake(registry)
    const result = await commands[0].handler({ rawInput: ' s-gone ' })
    expect(registry.unarchiveSession).toHaveBeenCalledWith('s-gone')
    expect(result.kind).toBe('success')
    expect(result.text).toMatch(/s-gone restored/)
  })

  it('treats an id outside the set as a no-op and does not write', async () => {
    const registry = makeRegistry()
    const { commands } = bootFake(registry)
    const result = await commands[0].handler({ rawInput: 's-unknown' })
    expect(result).toEqual({
      kind: 'success',
      text: 'Session s-unknown is not archived; nothing changed.',
    })
    expect(registry.unarchiveSession).not.toHaveBeenCalled()
  })

  it('falls back to a direct workspace-domain write when unarchiveSession is absent', async () => {
    const registry = makeRegistry({ unarchiveSession: undefined })
    const storageDomain = makeStorageDomain(['s-gone', 's-kept'])
    const { commands } = bootFake(registry, { storageDomain })
    const result = await commands[0].handler({ rawInput: 's-gone' })
    expect(result.kind).toBe('success')
    expect(result.text).toMatch(/s-gone restored/)
    expect(result.text).toMatch(/self-contained mode/)
    expect(storageDomain.get('workspace').global.get().archivedSessionIds).toEqual(['s-kept'])
  })

  it('lists the archive set from the domain in self-contained mode', async () => {
    const registry = makeRegistry({ unarchiveSession: undefined })
    const storageDomain = makeStorageDomain(['s-one'])
    const { commands } = bootFake(registry, { storageDomain })
    const result = await commands[0].handler({ rawInput: '' })
    expect(result.text).toBe('Archived sessions:\n- s-one')
  })

  it('errors when the workspace domain is unavailable in self-contained mode', async () => {
    const registry = makeRegistry({ unarchiveSession: undefined })
    const { commands } = bootFake(registry)
    const result = await commands[0].handler({ rawInput: 's-gone' })
    expect(result.kind).toBe('error')
    expect(result.text).toMatch(/workspace domain is unavailable/)
  })

  it('renders a registry write failure as an error outcome', async () => {
    const registry = makeRegistry({
      archivedSessionIds: ['s-gone'],
      unarchiveSession: vi.fn(async () => { throw new Error('backend down') }),
    })
    const { commands } = bootFake(registry)
    const result = await commands[0].handler({ rawInput: 's-gone' })
    expect(result.kind).toBe('error')
    expect(result.text).toMatch(/Unarchive failed: Error: backend down/)
  })
})

describe('unarchive_session tool', () => {
  it('lists archived sessions when sessionId is omitted', async () => {
    const registry = makeRegistry({ archivedSessionIds: ['s-one'] })
    const { tools } = bootFake(registry)
    const text = await tools[0].execute({})
    expect(text).toBe('Archived sessions:\n- s-one')
    expect(registry.unarchiveSession).not.toHaveBeenCalled()
  })

  it('restores the session id passed as an argument', async () => {
    const registry = makeRegistry({ archivedSessionIds: ['s-gone'] })
    const { tools } = bootFake(registry)
    const text = await tools[0].execute({ sessionId: 's-gone' })
    expect(registry.unarchiveSession).toHaveBeenCalledWith('s-gone')
    expect(text).toMatch(/s-gone restored/)
  })

  it('falls back to a direct domain write when sessionId is passed', async () => {
    const registry = makeRegistry({ unarchiveSession: undefined })
    const storageDomain = makeStorageDomain(['s-gone'])
    const { tools } = bootFake(registry, { storageDomain })
    const text = await tools[0].execute({ sessionId: 's-gone' })
    expect(text).toMatch(/s-gone restored/)
    expect(text).toMatch(/self-contained mode/)
    expect(storageDomain.get('workspace').global.get().archivedSessionIds).toEqual([])
  })
})
