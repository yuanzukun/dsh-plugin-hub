"""Configuration loading — environment variables only, nothing sensitive ever
touches a config file that could land in git.

Feishu app credentials and ``DEEPSEEK_API_KEY`` are read straight from the
process environment. An optional YAML file (``DSH_FEISHU_BRIDGE_CONFIG``,
see examples/config.example.yaml) can supply the non-secret allowlists and
model knobs, but env vars always win when both are set.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


class ConfigError(ValueError):
    """Raised for incomplete/inconsistent configuration — a hard boot
    failure, never a silent partial start."""


def _split_csv(value: str | None) -> list[str]:
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


_TRUE_VALUES = frozenset({"1", "true", "yes", "on"})


def _parse_bool(value: str) -> bool:
    return value.strip().lower() in _TRUE_VALUES


def _coerce_bool(value: Any, default: bool) -> bool:
    """A YAML mapping value for a boolean field, coerced the same way env
    vars are. A bare ``true``/``false`` YAML scalar already parses to a
    native bool via ``yaml.safe_load`` — pass it through. A *quoted* string
    (``approval_mode: "false"``) does not, and Python's own ``bool("false")``
    is True — the exact footgun this exists to close, since getting this
    wrong silently turns approval mode ON rather than off (Snape review)."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return _parse_bool(value)
    return default


@dataclass(slots=True)
class Settings:
    # Feishu
    feishu_app_id: str | None = None
    feishu_app_secret: str | None = None
    feishu_transport: str = "ws"
    feishu_verification_token: str | None = None
    feishu_encrypt_key: str | None = None
    feishu_domain: str = "https://open.feishu.cn"
    feishu_allowed_open_ids: list[str] = field(default_factory=list)
    feishu_allowed_chat_ids: list[str] = field(default_factory=list)

    # One-time pairing code onboarding (README "Getting your open_id",
    # pairing.py). On by default — a fresh deploy should be onboardable
    # without ever reading a log or restarting the process.
    feishu_pairing_enabled: bool = True
    feishu_pairing_ttl_seconds: float = 900.0
    feishu_pairing_max_attempts: int = 5
    feishu_pairing_code_length: int = 8
    feishu_pairing_state_path: str = "data/feishu_paired_open_ids.json"

    # dsh
    deepseek_api_key: str | None = None
    deepseek_base_url: str | None = None
    dsh_provider: str = "deepseek-official"
    dsh_model: str = "deepseek-v4-flash"
    dsh_max_tokens: int | None = None
    dsh_cordis: str | None = None
    dsh_session_root: str | None = None
    dsh_workspace: str | None = None

    # Remote tool approval (docs/architecture.md "Remote tool approval") —
    # off by default, existing deployments unaffected.
    dsh_approval_mode: bool = False
    dsh_approval_timeout_seconds: float = 60.0

    # HTTP server (webhook transport + health check)
    host: str = "0.0.0.0"
    port: int = 8788


def load_settings(config_path: str | Path | None = None) -> Settings:
    """Load settings from an optional YAML file, then apply env-var
    overrides on top. ``config_path`` defaults to the
    ``DSH_FEISHU_BRIDGE_CONFIG`` env var; no file is required — a
    fully-env-var deployment (Docker, systemd) works with no file at all.
    """
    settings = Settings()

    path = config_path or os.environ.get("DSH_FEISHU_BRIDGE_CONFIG")
    if path:
        data = _load_yaml(Path(path))
        _apply_yaml(settings, data)

    _apply_env(settings)
    _validate(settings)
    return settings


def _validate(settings: Settings) -> None:
    if settings.feishu_pairing_enabled:
        # A code shorter than 8 chars from a 32-symbol alphabet (see
        # pairing.py) is small enough that MAX_ATTEMPTS-bounded guessing
        # stops being the only realistic risk — refuse to boot rather than
        # silently run a weaker gate than the one the README documents.
        if settings.feishu_pairing_code_length < 8:
            raise ConfigError(
                "FEISHU_PAIRING_CODE_LENGTH must be at least 8 "
                f"(got {settings.feishu_pairing_code_length})."
            )
        if settings.feishu_pairing_max_attempts < 1:
            raise ConfigError(
                "FEISHU_PAIRING_MAX_ATTEMPTS must be at least 1 "
                f"(got {settings.feishu_pairing_max_attempts})."
            )
        if settings.feishu_pairing_ttl_seconds <= 0:
            raise ConfigError(
                "FEISHU_PAIRING_TTL_SECONDS must be positive "
                f"(got {settings.feishu_pairing_ttl_seconds})."
            )

    if settings.dsh_approval_mode and settings.dsh_cordis:
        # Approval mode ships its own composition (bundled cordis.yml, see
        # approval_runtime/) that a caller-supplied one would silently
        # replace, composing none of the approval plugins — a tool call
        # would then hang until ApprovalService's own no-answerer default
        # ('unavailable'), discovered live rather than at boot. Fail loud
        # instead: either drop dsh_cordis (use the bundled composition), or
        # compose approval_runtime's two plugins into the custom one — see
        # README "Remote tool approval".
        raise ConfigError(
            "DSH_APPROVAL_MODE is set together with a custom DSH_CORDIS — "
            "approval mode ships its own runtime composition; see README "
            "'Remote tool approval' for how to combine the two."
        )


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise ConfigError(f"Config file not found: {path}")
    with path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    if not isinstance(data, dict):
        raise ConfigError(f"Config file {path} must contain a YAML mapping")
    return data


def _apply_yaml(settings: Settings, data: dict[str, Any]) -> None:
    feishu = data.get("feishu") or {}
    settings.feishu_transport = feishu.get("transport", settings.feishu_transport)
    settings.feishu_domain = feishu.get("domain", settings.feishu_domain)
    settings.feishu_allowed_open_ids = list(
        feishu.get("allowed_open_ids", settings.feishu_allowed_open_ids)
    )
    settings.feishu_allowed_chat_ids = list(
        feishu.get("allowed_chat_ids", settings.feishu_allowed_chat_ids)
    )

    pairing = feishu.get("pairing") or {}
    settings.feishu_pairing_enabled = _coerce_bool(
        pairing.get("enabled", settings.feishu_pairing_enabled), settings.feishu_pairing_enabled
    )
    settings.feishu_pairing_ttl_seconds = float(
        pairing.get("ttl_seconds", settings.feishu_pairing_ttl_seconds)
    )
    settings.feishu_pairing_max_attempts = int(
        pairing.get("max_attempts", settings.feishu_pairing_max_attempts)
    )
    settings.feishu_pairing_code_length = int(
        pairing.get("code_length", settings.feishu_pairing_code_length)
    )
    settings.feishu_pairing_state_path = pairing.get(
        "state_path", settings.feishu_pairing_state_path
    )

    dsh = data.get("dsh") or {}
    settings.dsh_provider = dsh.get("provider", settings.dsh_provider)
    settings.dsh_model = dsh.get("model", settings.dsh_model)
    settings.dsh_max_tokens = dsh.get("max_tokens", settings.dsh_max_tokens)
    settings.dsh_cordis = dsh.get("cordis", settings.dsh_cordis)
    settings.dsh_session_root = dsh.get("session_root", settings.dsh_session_root)
    settings.dsh_workspace = dsh.get("workspace", settings.dsh_workspace)
    settings.dsh_approval_mode = _coerce_bool(
        dsh.get("approval_mode", settings.dsh_approval_mode), settings.dsh_approval_mode
    )
    settings.dsh_approval_timeout_seconds = float(
        dsh.get("approval_timeout_seconds", settings.dsh_approval_timeout_seconds)
    )

    server = data.get("server") or {}
    settings.host = server.get("host", settings.host)
    settings.port = server.get("port", settings.port)


def _apply_env(settings: Settings) -> None:
    env = os.environ
    settings.feishu_app_id = env.get("FEISHU_APP_ID", settings.feishu_app_id)
    settings.feishu_app_secret = env.get("FEISHU_APP_SECRET", settings.feishu_app_secret)
    settings.feishu_transport = env.get("FEISHU_TRANSPORT", settings.feishu_transport)
    settings.feishu_verification_token = env.get(
        "FEISHU_VERIFICATION_TOKEN", settings.feishu_verification_token
    )
    settings.feishu_encrypt_key = env.get("FEISHU_ENCRYPT_KEY", settings.feishu_encrypt_key)
    settings.feishu_domain = env.get("FEISHU_DOMAIN", settings.feishu_domain)
    if "FEISHU_ALLOWED_OPEN_IDS" in env:
        settings.feishu_allowed_open_ids = _split_csv(env["FEISHU_ALLOWED_OPEN_IDS"])
    if "FEISHU_ALLOWED_CHAT_IDS" in env:
        settings.feishu_allowed_chat_ids = _split_csv(env["FEISHU_ALLOWED_CHAT_IDS"])

    if "FEISHU_PAIRING" in env:
        settings.feishu_pairing_enabled = _parse_bool(env["FEISHU_PAIRING"])
    if "FEISHU_PAIRING_TTL_SECONDS" in env:
        settings.feishu_pairing_ttl_seconds = float(env["FEISHU_PAIRING_TTL_SECONDS"])
    if "FEISHU_PAIRING_MAX_ATTEMPTS" in env:
        settings.feishu_pairing_max_attempts = int(env["FEISHU_PAIRING_MAX_ATTEMPTS"])
    if "FEISHU_PAIRING_CODE_LENGTH" in env:
        settings.feishu_pairing_code_length = int(env["FEISHU_PAIRING_CODE_LENGTH"])
    settings.feishu_pairing_state_path = env.get(
        "FEISHU_PAIRING_STATE_PATH", settings.feishu_pairing_state_path
    )

    settings.deepseek_api_key = env.get("DEEPSEEK_API_KEY", settings.deepseek_api_key)
    # `or` on purpose, not `.get(key, default)`: an env referencing an
    # unconfigured secret (e.g. GitHub Actions `${{ secrets.X }}` for a secret
    # that was never created) sets the var to "" rather than omitting it. An
    # empty base_url breaks the dsh runtime's request construction outright —
    # reproduced locally against CI run 31948093525 — so "set but empty" must
    # be treated the same as "unset", not as an explicit override.
    settings.deepseek_base_url = env.get("DEEPSEEK_BASE_URL") or settings.deepseek_base_url
    settings.dsh_provider = env.get("DSH_PROVIDER", settings.dsh_provider)
    settings.dsh_model = env.get("DSH_MODEL", settings.dsh_model)
    if "DSH_MAX_TOKENS" in env:
        settings.dsh_max_tokens = int(env["DSH_MAX_TOKENS"])
    settings.dsh_cordis = env.get("DSH_CORDIS", settings.dsh_cordis)
    settings.dsh_session_root = env.get("DSH_SESSION_ROOT", settings.dsh_session_root)
    settings.dsh_workspace = env.get("DSH_WORKSPACE", settings.dsh_workspace)
    if "DSH_APPROVAL_MODE" in env:
        settings.dsh_approval_mode = _parse_bool(env["DSH_APPROVAL_MODE"])
    if "DSH_APPROVAL_TIMEOUT_SECONDS" in env:
        settings.dsh_approval_timeout_seconds = float(env["DSH_APPROVAL_TIMEOUT_SECONDS"])

    settings.host = env.get("DSH_FEISHU_BRIDGE_HOST", settings.host)
    if "DSH_FEISHU_BRIDGE_PORT" in env:
        settings.port = int(env["DSH_FEISHU_BRIDGE_PORT"])
