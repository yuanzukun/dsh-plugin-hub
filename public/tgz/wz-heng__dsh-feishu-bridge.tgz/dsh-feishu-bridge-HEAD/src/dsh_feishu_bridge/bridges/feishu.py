from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import queue
import secrets
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import urlsplit

from lark_channel import FeishuChannel, SecurityConfig, TransportConfig
from lark_channel.core.utils import AESCipher
import lark_channel.ws.client as _lark_ws_client

from ..pairing import (
    DEFAULT_CODE_LENGTH,
    DEFAULT_MAX_ATTEMPTS,
    DEFAULT_TTL_SECONDS,
    OUTCOME_INVALID,
    OUTCOME_OK,
    PairingGate,
)
from .base import Bridge
from .manager import BridgeManager

if TYPE_CHECKING:  # pragma: no cover - typing only
    from lark_channel.channel.types import CardActionEvent, InboundMessage

logger = logging.getLogger(__name__)

# Char budget per outbound card. Feishu's real limit is on the SERIALIZED card
# (~30KB), not a character count: multibyte text and JSON escaping both eat
# into it — a single CJK char can cost 6 bytes once \uXXXX-escaped. 3500 chars
# stays comfortably under 30KB even in that worst case, so we never build a
# card the API will reject.
MAX_CARD_CHARS = 3500

# Tool input / result previews are truncated before they ever reach a card.
MAX_PREVIEW_CHARS = 3000

# Cap on live card nonces held in memory. Each approval / session-list button
# mints one; consuming or evicting bounds the map. FIFO eviction of the oldest
# only ever drops a nonce for a card old enough that a late click is already
# stale — the one-time-use guarantee for *recent* cards is untouched.
MAX_LIVE_NONCES = 2000

# Feishu webhook signature headers (event subscription v2, encrypt-key mode):
# X-Lark-Signature = sha256(timestamp + nonce + encrypt_key + raw_body).
_WEBHOOK_TIMESTAMP_HEADER = "x-lark-request-timestamp"
_WEBHOOK_NONCE_HEADER = "x-lark-request-nonce"
_WEBHOOK_SIGNATURE_HEADER = "x-lark-signature"

# The SDK's OWN (now-redundant, but still exercised) internal signature check
# does a CASE-SENSITIVE header lookup for these same three headers, keyed by
# its exact mixed-case constant names — while ASGI frameworks (Starlette /
# FastAPI, see app.py's `dict(request.headers)`) hand us headers already
# normalized to all-lowercase. This mismatch was invisible while encrypt_key
# was optional (an unset key made the SDK's `_verify_sign` a no-op regardless
# of headers), but now that encrypt_key is mandatory for webhook transport
# the SDK's check DOES run — and every legitimate, correctly-signed request
# would 500 inside it without restoring canonical casing first (see
# _with_canonical_signature_header_case / handle_webhook).
_SDK_SIGNATURE_HEADER_CASE = {
    _WEBHOOK_TIMESTAMP_HEADER: "X-Lark-Request-Timestamp",
    _WEBHOOK_NONCE_HEADER: "X-Lark-Request-Nonce",
    _WEBHOOK_SIGNATURE_HEADER: "X-Lark-Signature",
}

# How far a request's timestamp may drift from wall-clock "now" and still be
# accepted. Matches the source bridge's own webhook convention.
WEBHOOK_TIMESTAMP_WINDOW_SECONDS = 300

# Cap on tracked (timestamp, nonce) replay keys, mirroring MAX_LIVE_NONCES'
# FIFO-eviction posture: normal traffic never gets near this (entries older
# than the window are pruned on every request), it only bounds a burst of
# otherwise-validly-signed requests within one window.
MAX_WEBHOOK_NONCES = 10_000

_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})


def _is_loopback(domain: str) -> bool:
    """True when `domain` points at loopback — the test fake-server case."""
    host = (urlsplit(domain).hostname or "").lower()
    return host in _LOOPBACK_HOSTS


# The single event loop this process owns on behalf of the lark-channel ws
# client. Minted lazily on the first ws start and then REUSED for the whole
# process lifetime — never rebound once a client is live on it (see
# _isolate_lark_ws_loop for why "once live, never replace" is a hard rule).
_isolated_ws_loop: asyncio.AbstractEventLoop | None = None


def _isolate_lark_ws_loop() -> asyncio.AbstractEventLoop:
    """Point the lark-channel ws client at a loop we own and that uvicorn
    never runs — and, once a client is live on that loop, NEVER take it away.

    Why this exists
    ---------------
    ``lark_channel/ws/client.py`` binds a MODULE-LEVEL ``loop =
    asyncio.get_event_loop()`` at import time and uses THAT global everywhere,
    ignoring the per-instance ``self._loop``: ``WSClient.start()`` drives the
    socket with ``loop.run_until_complete(...)`` and the running client keeps
    reading it to schedule inbound work (``loop.create_task``);
    ``FeishuChannel._stop_private_ws_client`` reads the same global to
    disconnect. If this bridge is constructed while an app event loop is
    already running (the normal FastAPI-lifespan case), that import-time
    ``get_event_loop()`` captures the running server loop. In ws mode the SDK
    then runs the blocking ``WSClient.start()`` on a worker thread, which
    calls ``run_until_complete()`` on the server's own loop from that thread
    and STOPS it — ``RuntimeError: Event loop stopped before Future
    completed``, taking the whole process down at boot.

    The invariant: once live, never replace
    ---------------------------------------
    Because that global is read for the ENTIRE life of a ws client — not just
    at start — a live client and its loop are inseparable. Rebinding the
    global out from under a running client sends its freshly-received inbound
    to a loop nobody drives and its stop/disconnect to the wrong loop,
    stranding the old ``WSClient.start()`` thread forever in ``_select()``: a
    zombie. So a RUNNING loop must NEVER be swapped out.

    We therefore mint ONE loop the first time ws starts, remember it in
    ``_isolated_ws_loop``, install it as the SDK global, and from then on
    always hand back that same loop. It is replaced only when we own none yet
    or ours is CLOSED — never merely because it ``is_running()`` (the old bug:
    "running" was read as "replaceable", but running = a live client is using
    it = the one thing you must not steal). A normal stop→start reuses it (the
    SDK stops but never closes it); a second ``start()`` while the client is
    still live also reuses it, so the lone live client keeps its loop. This
    mirrors the SDK's one-global-loop model exactly: it supports a single ws
    client per process, and this bridge process registers exactly one Feishu
    bridge, so one owned loop is all there is to own.
    """
    global _isolated_ws_loop
    loop = _isolated_ws_loop
    if loop is None or loop.is_closed():
        loop = asyncio.new_event_loop()
        _isolated_ws_loop = loop
    # Re-assert ourselves as the SDK global. Idempotent when it already points
    # here (the running-client case: same object, no-op); corrective on a first
    # start, where the global is still the app loop captured at import.
    _lark_ws_client.loop = loop
    return loop


class FeishuConfigError(ValueError):
    """Raised when Feishu bridge config is incomplete/inconsistent — surfaces
    as a hard boot failure rather than a silent disable."""


def build_feishu_bridge(
    manager: BridgeManager, settings: Any
) -> "FeishuBridge | None":
    """Construct a FeishuBridge from settings, or return None when the bridge
    is simply not configured (neither credential set).

    Fail-loud, not fail-silent:
    - exactly one of app_id / app_secret set → FeishuConfigError (boot fails);
    - webhook transport without a verification token → FeishuConfigError, so a
      webhook route is never registered bare (fail-closed);
    - webhook transport without an encrypt key → FeishuConfigError. A
      verification token alone cannot authenticate the request's origin (it
      is a static value carried in the body, not a per-request signature);
      the encrypt key is what `FeishuBridge.handle_webhook` uses to verify
      `X-Lark-Signature` itself, at this bridge's own boundary, before a
      request is trusted (fail-closed).
    """
    app_id = settings.feishu_app_id
    app_secret = settings.feishu_app_secret
    if not app_id and not app_secret:
        return None
    if bool(app_id) != bool(app_secret):
        raise FeishuConfigError(
            "Feishu bridge needs BOTH feishu_app_id and feishu_app_secret; "
            "exactly one is set. Configure both, or neither to disable."
        )

    transport = settings.feishu_transport
    if transport not in ("ws", "webhook"):
        raise FeishuConfigError(
            f"feishu_transport must be 'ws' or 'webhook', got {transport!r}."
        )
    if transport == "webhook" and not settings.feishu_verification_token:
        raise FeishuConfigError(
            "Feishu webhook transport requires feishu_verification_token — "
            "without it the webhook route is not registered (fail-closed)."
        )
    if transport == "webhook" and not settings.feishu_encrypt_key:
        raise FeishuConfigError(
            "Feishu webhook transport requires feishu_encrypt_key — without "
            "it inbound requests cannot be signature-verified (fail-closed)."
        )

    return FeishuBridge(
        manager,
        app_id=app_id,
        app_secret=app_secret,
        transport=transport,
        verification_token=settings.feishu_verification_token,
        encrypt_key=settings.feishu_encrypt_key,
        domain=settings.feishu_domain,
        allowed_open_ids=settings.feishu_allowed_open_ids or None,
        allowed_chat_ids=settings.feishu_allowed_chat_ids or None,
        pairing_enabled=settings.feishu_pairing_enabled,
        pairing_ttl_seconds=settings.feishu_pairing_ttl_seconds,
        pairing_max_attempts=settings.feishu_pairing_max_attempts,
        pairing_code_length=settings.feishu_pairing_code_length,
        pairing_state_path=settings.feishu_pairing_state_path,
    )


class FeishuBridge(Bridge):
    """Feishu (Lark) bot integration over the official ``lark-channel-sdk``.

    Transport is the platform's own event-delivery choice, mirrored as
    config: ``ws`` (long connection — no public URL needed) or ``webhook``.
    Both feed one inbound path; the webhook HTTP route is mounted by
    ``app.py`` only in webhook mode (and only with a verification token).
    Outbound resilience — retry, jittered backoff, Retry-After, business-code
    classification, token refresh — is owned by the SDK by design; this
    bridge configures those knobs and surfaces failures, it does not
    reimplement them.
    """

    name = "feishu"

    def __init__(
        self,
        manager: BridgeManager,
        *,
        app_id: str,
        app_secret: str,
        transport: str = "ws",
        verification_token: str | None = None,
        encrypt_key: str | None = None,
        domain: str = "https://open.feishu.cn",
        allowed_open_ids: list[str] | None = None,
        allowed_chat_ids: list[str] | None = None,
        pairing_enabled: bool = False,
        pairing_ttl_seconds: float = DEFAULT_TTL_SECONDS,
        pairing_max_attempts: int = DEFAULT_MAX_ATTEMPTS,
        pairing_code_length: int = DEFAULT_CODE_LENGTH,
        pairing_state_path: str | Path = "data/feishu_paired_open_ids.json",
    ) -> None:
        super().__init__(manager)
        self.transport = transport
        self._app_id = app_id
        self._app_secret = app_secret
        # Our OWN copies, used by _verify_webhook_request and the
        # URL-verification handshake responder — never delegated to the SDK
        # (see handle_webhook / build_feishu_bridge).
        self._encrypt_key = encrypt_key
        self._verification_token = verification_token
        self._domain = domain.rstrip("/")
        # Fail-closed allowlists: an empty/None open_id set means the
        # `_authorized` gate rejects EVERY sender and operator — there is no
        # implicit allow-all. A None chat set means "no group restriction".
        # A plain (mutable) set, not frozenset: a successful `/pair` adds to
        # it live (see _handle_pair_command) — no restart needed.
        self.allowed_open_ids: set[str] = set(allowed_open_ids or ())
        self.allowed_chat_ids: frozenset[str] | None = (
            frozenset(allowed_chat_ids) if allowed_chat_ids else None
        )

        # One-time pairing code onboarding (pairing.py) — off entirely when
        # disabled, so `_on_message` falls straight through to the unchanged
        # silent-reject behavior for every sender, `/pair` included.
        self._pairing: PairingGate | None = None
        if pairing_enabled:
            self._pairing = PairingGate(
                state_path=Path(pairing_state_path),
                ttl_seconds=pairing_ttl_seconds,
                max_attempts=pairing_max_attempts,
                code_length=pairing_code_length,
            )
            # Union at load time only (README "Getting your open_id"): the
            # persisted set is never written back merged with the env list,
            # so removing an id from FEISHU_ALLOWED_OPEN_IDS and restarting
            # still revokes it even though pairing state persists across
            # restarts on its own.
            self.allowed_open_ids |= self._pairing.paired_open_ids

        # Loopback (test fake server) must not have its outbound POSTs
        # hijacked by an ambient http_proxy (e.g. a system-wide proxy on a
        # dev machine). Real domains keep None (honor env proxy).
        trust_env_proxy = False if _is_loopback(domain) else None

        self._channel = FeishuChannel(
            app_id=app_id,
            app_secret=app_secret,
            domain=domain,
            verification_token=verification_token,
            encrypt_key=encrypt_key,
            transport=TransportConfig(kind=transport, trust_env_proxy=trust_env_proxy),
            # SDK default is "compat"; strict turns on the full signature /
            # timestamp / anti-replay posture a production bot needs.
            security=SecurityConfig(mode="strict"),
        )
        self._channel.on("message", self._on_message)
        self._channel.on("cardAction", self._on_card_action)

        # nonce -> {"kind", ...identity fields} for one-time card consumption.
        # Insertion-ordered dict; FIFO-evicted at cap.
        self._nonces: dict[str, dict[str, str]] = {}

        # "timestamp:nonce" -> monotonic expiry (when the SIGNED timestamp
        # itself ages out of the validity window — see
        # _consume_webhook_nonce), for webhook replay rejection. Pruned of
        # expired entries on every request, FIFO-evicted at cap as a
        # defensive floor.
        self._webhook_nonces: dict[str, float] = {}

        # The app's main event loop, captured in start(). The SDK delivers
        # inbound events on its OWN loop in ws mode (a background thread), but
        # SessionManager's turn scheduling (asyncio.create_task) needs a loop
        # that's actually running — this app's main loop. We marshal manager
        # calls back onto it (see _run_on_main). Webhook mode has no such
        # split: our own route handler calls into the SDK on the main loop
        # already, so _run_on_main's fast path (await inline) applies there.
        self._main_loop: asyncio.AbstractEventLoop | None = None
        self._tick_stop = False  # set True in stop() to end _keepalive_tick
        self._tick_future: Any = None  # concurrent.futures.Future once scheduled

        # Outbound goes through OUR OWN REST calls, NOT the SDK's channel.send,
        # and runs on a DEDICATED worker thread: the event loop only
        # `queue.put`s a request (instant) and the worker sends serially with
        # a BLOCKING `requests` call. This keeps the loop free even if a send
        # stalls, and matches the SDK's own retry/backoff posture at our layer
        # instead of depending on channel.send internals we don't control.
        self._token: str | None = None
        self._token_exp: float = 0.0  # monotonic seconds
        self._token_lock = threading.Lock()  # guards token; held by the worker
        self._loopback = _is_loopback(domain)
        # Per-request timeouts (connect, read). Tight so a stuck send can't
        # wedge the outbound queue for long; the loop is unaffected either way.
        self._timeout: tuple[float, float] = (5.0, 15.0)
        self._out_q: "queue.Queue[tuple | None]" = queue.Queue(maxsize=1000)
        self._worker: threading.Thread | None = None
        # Set in stop() to end the worker even when the queue is full (a plain
        # blocking `put(None)` sentinel could otherwise wedge shutdown).
        self._worker_stop = threading.Event()
        # How long stop()/start() wait off-loop for the worker thread to exit
        # before giving up (stop) or failing loud (start). An attribute so
        # lifecycle tests can shrink it and drive a real join-timeout quickly.
        self._worker_join_timeout: float = 5.0

    # --- lifecycle -----------------------------------------------------------

    @property
    def healthy(self) -> bool:
        # Webhook mode has no live socket to be "unready"; it's healthy once
        # constructed. WS mode reports the SDK's readiness flag.
        if self.transport == "webhook":
            return True
        return bool(self._channel.is_ready)

    async def start(self) -> None:
        # Capture the main loop while we're on it — SDK event handlers run on a
        # different (background) loop in ws mode and must hop back here.
        self._main_loop = asyncio.get_running_loop()
        # WS transport only: keep the SDK's module-level ws loop off THIS loop.
        # It may have captured our (running) loop at import time; letting the
        # SDK drive run_until_complete on it from a worker thread stops the
        # app loop and crashes boot. Install our owned, isolated loop first —
        # reused across restarts and never stolen from a live client.
        if self.transport == "ws":
            _isolate_lark_ws_loop()
        # Bring the outbound worker up FIRST, then the SDK channel + keepalive
        # tick. The only thing that can fail here is a stuck lingering worker
        # (_ensure_worker raises); doing it before channel/tick means such a
        # failure happens with NOTHING half-started to roll back.
        await self._ensure_worker()
        # From here on the worker is already live, so any failure bringing up
        # the channel/tick must roll it back — else a failed start leaves a
        # healthy outbound worker spinning against a dead channel. Tear down
        # via stop() (best-effort; the ORIGINAL error still propagates).
        try:
            # Webhook mode returns ready without dialing; WS returns once
            # connected.
            await self._channel.start_background()
            # Keep the SDK's background loop iterating (see _keepalive_tick)
            # so cross-thread inbound scheduling stays prompt. Save the
            # future so stop() can cancel/await it, and never stack a second
            # tick on a re-start.
            self._tick_stop = False
            if self._tick_future is None or self._tick_future.done():
                self._tick_future = self._channel.schedule(self._keepalive_tick())
        except Exception:
            try:
                await self.stop()
            except Exception:
                logger.exception(
                    "Feishu bridge rollback after failed start also failed"
                )
            raise
        self._announce_pairing_code()
        logger.info("Feishu bridge started (transport=%s)", self.transport)

    def _announce_pairing_code(self) -> None:
        """Print the live pairing code to console stdout — ONLY here, ONLY
        stdout, never through `logger` (see pairing.py module docstring for
        why: this is meant to be the code's one and only appearance
        anywhere). A no-op when pairing is off or the round is already
        consumed/locked/expired (a hot restart-within-process, e.g. tests or
        a supervised reload, shouldn't advertise a dead code)."""
        if self._pairing is None or not self._pairing.active:
            return
        print(
            f"\n[dsh-feishu-bridge] Pairing code: {self._pairing.code}\n"
            f"Send '/pair {self._pairing.code}' to the bot in a PRIVATE chat "
            "to get on the allowlist. Valid for "
            f"{int(self._pairing.ttl_seconds)}s or {self._pairing.max_attempts} "
            "wrong tries, whichever comes first.\n",
            flush=True,
        )

    async def _ensure_worker(self) -> None:
        """Bring the dedicated outbound worker (see __init__) to a known-live
        state, cleanly and idempotently.

        - A healthy running worker (alive, not being stopped) → no-op, so a
          re-start doesn't stack a second worker or drop in-flight sends.
        - A lingering worker from a stop() whose join timed out (alive AND the
          stop-flag set) is still draining a slow in-flight send and WILL exit
          once it returns. Wait it out off-loop; if it truly refuses to die,
          raise rather than run two workers on one queue.
        - Otherwise (no worker, or the old one has exited): discard any stale
          queue state so the fresh worker doesn't immediately read a stale
          sentinel and die; then clear the flag and spawn.
        """
        worker = self._worker
        if worker is not None and worker.is_alive() and not self._worker_stop.is_set():
            return  # already running and healthy
        if worker is not None and worker.is_alive() and self._worker_stop.is_set():
            await asyncio.to_thread(worker.join, self._worker_join_timeout)
            if worker.is_alive():
                raise RuntimeError(
                    "Feishu outbound worker did not exit after stop(); refusing "
                    "to start a second worker on the same queue"
                )
        self._drain_queue()
        self._worker_stop.clear()
        self._worker = threading.Thread(
            target=self._outbound_worker, name="feishu-outbound", daemon=True
        )
        self._worker.start()

    def _drain_queue(self) -> None:
        """Discard every pending outbound item, INCLUDING any stale sentinel.

        Fire-and-forget outbound is intentionally NOT replayed across a
        stop/start lifecycle: a shutdown-era card update for a since-gone
        session must not resurrect on the next boot, and a leftover ``None``
        sentinel must not kill a freshly-spawned worker."""
        while True:
            try:
                self._out_q.get_nowait()
            except queue.Empty:
                return

    async def _keepalive_tick(self) -> None:
        """Keep the SDK's background event loop iterating on a short timer.

        The SDK delivers INBOUND events on a loop in a background thread
        (ws mode), fed cross-thread. A tiny periodic sleep forces the loop to
        iterate ~every 50ms off its own timer, draining queued cross-thread
        work promptly instead of sitting on a stale select() timeout. Cheap;
        ends on ``stop()``. (Outbound doesn't rely on this — it runs on its
        own worker thread.)
        """
        while not self._tick_stop:
            await asyncio.sleep(0.05)

    async def _run_on_main(self, coro, *, wait: bool = True):
        """Run `coro` on the main app loop, from whatever loop we're on.

        SDK inbound handlers run on the SDK's background loop in ws mode;
        SessionManager's turn scheduling needs a loop that's actually
        running, so we hop there via run_coroutine_threadsafe.

        ``wait=True`` awaits the result (card actions need it). ``wait=False``
        is FIRE-AND-FORGET: it returns immediately after scheduling. That is
        essential for an agent turn — the SDK serializes a chat's outbound
        behind the *inbound* handler that produced it, so if ``_on_message``
        blocked on the whole turn, the turn's own reply to that chat would
        deadlock. Errors from a detached coro are logged, not lost.

        Unit tests (and the already-on-main case, e.g. webhook mode) have no
        cross-thread hop to make, so we just await inline.
        """
        loop = self._main_loop
        if loop is None or loop is asyncio.get_running_loop():
            return await coro
        fut = asyncio.run_coroutine_threadsafe(coro, loop)
        if wait:
            return await asyncio.wrap_future(fut)
        fut.add_done_callback(self._log_detached_error)
        return None

    @staticmethod
    def _log_detached_error(fut) -> None:
        try:
            exc = fut.exception()
        except Exception:  # cancelled
            return
        if exc is not None:
            logger.error("Feishu: detached inbound handler failed: %r", exc)

    # --- outbound REST (dedicated worker thread; loop only enqueues) ---------

    # Business codes meaning the tenant_access_token is invalid/expired — clear
    # the cache and retry once.
    _TOKEN_INVALID_CODES = frozenset({99991663, 99991661, 99991664, 99991665})
    # Codes worth backing off and retrying (rate limit / transient).
    _RETRY_CODES = frozenset({99991400, 230020, 230098, 11232})
    _MAX_ATTEMPTS = 3

    def _enqueue(self, method: str, path: str, body: dict[str, Any]) -> None:
        """Hand one REST call to the outbound worker. Non-blocking; never waits
        on the network from the event loop."""
        try:
            self._out_q.put_nowait((method, path, body))
        except queue.Full:
            logger.error("Feishu: outbound queue full, dropping %s %s", method, path)

    def _outbound_worker(self) -> None:
        """Serial outbound sender, on its own thread. Polls the queue with a
        short timeout so a `stop()` flag ends the thread promptly even when
        the queue is full (a plain blocking `get` could never see the
        sentinel then and would wedge shutdown)."""
        while not self._worker_stop.is_set():
            try:
                item = self._out_q.get(timeout=0.5)
            except queue.Empty:
                continue
            if item is None:  # sentinel from stop()
                return
            method, path, body = item
            try:
                self._api_sync(method, path, body)
            except Exception:
                logger.exception("Feishu: outbound worker failed on %s %s", method, path)

    def _get_token_sync(self, *, force: bool = False) -> str | None:
        """Cached tenant_access_token; fetch on miss/expiry. Runs on the worker
        thread (blocking). Feishu signals token errors as HTTP 200 + a business
        ``code``."""
        with self._token_lock:
            if not force and self._token and time.monotonic() < self._token_exp:
                return self._token
            try:
                data = self._sync_request(
                    "POST",
                    f"{self._domain}/open-apis/auth/v3/tenant_access_token/internal",
                    {"app_id": self._app_id, "app_secret": self._app_secret}, {},
                )
            except Exception:
                logger.exception("Feishu: token fetch failed")
                return None
            if data.get("code") != 0 or not data.get("tenant_access_token"):
                logger.error("Feishu: token fetch error: %s", data)
                return None
            self._token = data["tenant_access_token"]
            self._token_exp = time.monotonic() + max(60, int(data.get("expire", 7200)) - 300)
            return self._token

    def _sync_request(self, method: str, url: str, body: dict, headers: dict) -> dict:
        """One blocking Feishu REST call via ``requests`` (worker thread only).

        Loopback (test fake server) uses a ``trust_env=False`` session so NO
        ambient proxy — including ``ALL_PROXY`` (which requests would
        otherwise merge to an ``all`` entry that a ``{"http": None}``
        override doesn't cover) — can swallow the localhost POST. Real
        domains honor env.
        """
        import requests
        if self._loopback:
            with requests.Session() as s:
                s.trust_env = False
                r = s.request(method, url, json=body, headers=headers, timeout=self._timeout)
        else:
            r = requests.request(method, url, json=body, headers=headers, timeout=self._timeout)
        return r.json()

    def _api_sync(
        self, method: str, path: str, body: dict[str, Any]
    ) -> dict[str, Any] | None:
        """One Feishu REST call with token-refresh-on-invalid + code-based
        backoff, on the worker thread. Total wall-clock is bounded by the
        per-request (connect, read) timeout × a few attempts plus short
        sleeps — and, being off the event loop, it never freezes the server."""
        for attempt in range(self._MAX_ATTEMPTS):
            token = self._get_token_sync(force=attempt > 0 and self._token is None)
            if token is None:
                return None
            try:
                data = self._sync_request(
                    method, f"{self._domain}{path}", body,
                    {"Authorization": f"Bearer {token}"},
                )
            except Exception:
                logger.exception("Feishu: %s %s raised", method, path)
                if attempt < self._MAX_ATTEMPTS - 1:
                    time.sleep(0.4 * (attempt + 1) + secrets.randbelow(200) / 1000)
                    continue
                return None
            code = data.get("code", 0)
            if code == 0:
                return data
            if code in self._TOKEN_INVALID_CODES and attempt < self._MAX_ATTEMPTS - 1:
                self._token = None  # force refresh next iteration
                continue
            if code in self._RETRY_CODES and attempt < self._MAX_ATTEMPTS - 1:
                time.sleep(0.4 * (attempt + 1) + secrets.randbelow(200) / 1000)
                continue
            logger.error("Feishu: %s %s failed code=%s msg=%s", method, path, code, data.get("msg"))
            return None
        return None

    async def stop(self) -> None:
        # Tear the outbound worker down first, then the tick + SDK channel.
        worker = self._worker
        if worker is not None and worker.is_alive():
            # Flag first so the worker's timed `get` exits even on a full queue.
            self._worker_stop.set()
            # Drop every pending fire-and-forget send (not replayed across a
            # lifecycle), then drop a best-effort sentinel to wake an idle
            # worker at once. Never block the event loop: the put is
            # non-blocking and the join runs off-loop.
            self._drain_queue()
            try:
                self._out_q.put_nowait(None)  # sentinel: exit promptly if idle
            except queue.Full:
                pass
            await asyncio.to_thread(worker.join, self._worker_join_timeout)
        # Only drop the reference once the worker has actually exited — else a
        # later start() would spawn a SECOND worker racing this one. If the join
        # timed out, the reference is kept and start() reaps it (or fails loud).
        if worker is None or not worker.is_alive():
            self._worker = None
        self._tick_stop = True
        if self._tick_future is not None:
            self._tick_future.cancel()
            self._tick_future = None
        await self._channel.stop_background()

    async def handle_webhook(
        self, headers: dict[str, str], body: bytes
    ) -> tuple[int, bytes]:
        """Framework-agnostic webhook entry — the mounted FastAPI route hands
        raw headers+body here.

        Signature / timestamp / replay verification happens HERE, at this
        bridge's OWN boundary, before anything is handed to the SDK. We do
        not rely on ``lark_channel`` for this: its signature check silently
        no-ops when ``encrypt_key`` is unset (impossible here — see
        ``build_feishu_bridge``, which now requires it for webhook
        transport), and even when the key is set, the SDK never checks
        timestamp freshness or nonce reuse at all — a captured valid request
        replays cleanly forever. A request that fails any of these checks is
        rejected before it ever reaches ``_channel.handle_webhook_request``
        (and therefore before it can reach ``manager.handle_incoming``).

        Only a request that PASSES is handed to the SDK dispatcher, which
        then does its own decrypt / challenge / routing to our registered
        handlers — that part is unaffected.

        ONE deliberate exception: Feishu's URL-verification handshake — the
        "save request URL" step in the console, fired the moment you
        configure or change the webhook URL — is never signed, because at
        that point no subscription is confirmed yet for there to be anything
        to sign. Gating it like a normal event would permanently block
        first-time webhook setup.

        This bridge answers that handshake itself (see
        _respond_to_url_verification) rather than forwarding it to the SDK.
        Forwarding it would be safe for a PLAINTEXT handshake (the SDK's own
        dispatcher checks verification_token before it ever looks at request
        type, and its url_verification branch returns before
        `_verify_sign`/`_dispatch` are reachable), but NOT for an
        ENCRYPTED-but-unsigned handshake — the realistic case now that
        encrypt_key is mandatory: the SDK's own strict-mode
        `_preverify_encrypted_request` blocks any encrypted payload lacking
        signature headers before the url_verification branch is ever
        reached, so a real deployment's first webhook save would 500.
        Answering it ourselves — decrypt (if needed) with our own
        encrypt_key, check verification_token, echo the challenge —
        sidesteps that SDK behavior entirely and works identically for both
        the legacy flat body and the v2/p2-schema body Feishu also uses for
        this handshake.
        """
        payload = self._decode_url_verification_challenge(body)
        if payload is not None:
            return self._respond_to_url_verification(payload)
        ok, reason = self._verify_webhook_request(headers, body)
        if not ok:
            logger.warning("Feishu: webhook request rejected (%s)", reason)
            return 401, b'{"code":401,"msg":"unauthorized"}'
        return await self._channel.handle_webhook_request(
            self._with_canonical_signature_header_case(headers), body
        )

    def _decode_url_verification_challenge(self, body: bytes) -> dict[str, Any] | None:
        """The decrypted/parsed JSON payload if `body` is Feishu's
        URL-verification handshake, else None.

        Recognizes both shapes the SDK's own `_parse_context` treats as
        `url_verification` — the legacy flat body (`{"type":
        "url_verification", ...}`) and the v2/p2-schema body (`{"schema":
        "2.0", "header": {"event_type": "url_verification", ...}, ...}`) —
        across plaintext or AES-encrypted (using our own encrypt_key, the
        SDK's own `AESCipher`). Best-effort: any parse/decrypt failure or
        unrecognized shape returns None, which just routes the request
        through the normal signed-event gate instead (fails closed, never
        open)."""
        try:
            payload = json.loads(body)
        except (TypeError, ValueError):
            return None
        if not isinstance(payload, dict):
            return None
        encrypted = payload.get("encrypt")
        if encrypted:
            if not self._encrypt_key:
                return None
            try:
                payload = json.loads(AESCipher(self._encrypt_key).decrypt_str(encrypted))
            except Exception:
                return None
            if not isinstance(payload, dict):
                return None
        event_type = payload.get("type")
        header = payload.get("header")
        if not event_type and isinstance(header, dict):
            event_type = header.get("event_type")
            # v2/p2-schema carries verification_token at header.token, not
            # top-level — normalize so _respond_to_url_verification only
            # ever has to look in one place (mirrors the SDK's own
            # `context.token = context.header.token` for this schema).
            if "token" not in payload and "token" in header:
                payload["token"] = header["token"]
        if event_type != "url_verification":
            return None
        return payload

    def _respond_to_url_verification(self, payload: dict[str, Any]) -> tuple[int, bytes]:
        """Answer a decoded URL-verification handshake ourselves: check
        verification_token (the same, pre-existing, mandatory-for-webhook
        check the SDK would otherwise perform — an attacker who doesn't know
        it gets nothing from this path either), then echo the challenge
        Feishu sent, matching what `EventDispatcherHandler.do` would return
        for this request type."""
        token = payload.get("token")
        if self._verification_token and not (
            isinstance(token, str) and hmac.compare_digest(self._verification_token, token)
        ):
            logger.warning(
                "Feishu: webhook request rejected (invalid verification_token on url_verification)"
            )
            return 401, b'{"code":401,"msg":"unauthorized"}'
        challenge = payload.get("challenge")
        if not isinstance(challenge, str):
            logger.warning("Feishu: webhook request rejected (url_verification missing challenge)")
            return 401, b'{"code":401,"msg":"unauthorized"}'
        return 200, json.dumps({"challenge": challenge}).encode("utf-8")

    @staticmethod
    def _with_canonical_signature_header_case(headers: dict[str, str]) -> dict[str, str]:
        """Re-add the three signature headers under the exact mixed-case
        names the SDK's own (redundant) internal check looks them up by —
        see _SDK_SIGNATURE_HEADER_CASE for why this is necessary."""
        lowered = {k.lower(): v for k, v in headers.items()}
        out = dict(headers)
        for lower_name, canonical_name in _SDK_SIGNATURE_HEADER_CASE.items():
            if lower_name in lowered:
                out[canonical_name] = lowered[lower_name]
        return out

    def _verify_webhook_request(
        self, headers: dict[str, str], body: bytes
    ) -> tuple[bool, str]:
        """Fail-closed signature + timestamp + replay check.

        Returns ``(True, "")`` on success or ``(False, reason)`` on the first
        check that fails — headers missing, signature mismatch, timestamp
        outside the window, or a (timestamp, nonce) pair already seen.
        """
        lowered = {k.lower(): v for k, v in headers.items()}
        timestamp = lowered.get(_WEBHOOK_TIMESTAMP_HEADER)
        nonce = lowered.get(_WEBHOOK_NONCE_HEADER)
        signature = lowered.get(_WEBHOOK_SIGNATURE_HEADER)
        if not timestamp or not nonce or not signature:
            return False, "signature headers missing"

        expected = hashlib.sha256(
            (timestamp + nonce + self._encrypt_key).encode("utf-8") + body
        ).hexdigest()
        if not hmac.compare_digest(expected, signature):
            return False, "signature invalid"

        try:
            ts = int(timestamp)
        except ValueError:
            return False, "timestamp malformed"
        now_wall = time.time()
        # Strictly `<` (not `<=`), not just for the window's own sake: a
        # diff exactly at WEBHOOK_TIMESTAMP_WINDOW_SECONDS would give the
        # nonce-cache entry below a TTL of exactly 0 — evicted as "expired"
        # the instant the very next request is checked, defeating replay
        # rejection for a request sitting right on the boundary. Rejecting
        # the boundary itself guarantees every accepted request's cache
        # entry gets strictly positive headroom.
        if abs(now_wall - ts) >= WEBHOOK_TIMESTAMP_WINDOW_SECONDS:
            return False, "timestamp outside window"

        # Only a request that already passed signature + timestamp consumes a
        # replay-cache slot — an attacker without the encrypt key can't burn
        # through it with forged (timestamp, nonce) pairs.
        if not self._consume_webhook_nonce(f"{timestamp}:{nonce}", ts, now_wall):
            return False, "nonce replay"

        return True, ""

    def _consume_webhook_nonce(self, key: str, ts: int, now_wall: float) -> bool:
        """True (and records it) the first time `key` is seen while its
        SIGNED timestamp is still inside the validity window; False on a
        repeat — the replay-rejection gate.

        The cache entry's TTL tracks how much longer `ts` itself stays valid
        (``ts + WEBHOOK_TIMESTAMP_WINDOW_SECONDS - now``), NOT a flat window
        from receipt time. A flat receipt-time TTL and the timestamp check's
        own ±window overlap asymmetrically: a request signed up to
        ``WEBHOOK_TIMESTAMP_WINDOW_SECONDS`` in the future keeps passing the
        timestamp check for up to ``2 * WEBHOOK_TIMESTAMP_WINDOW_SECONDS``
        after receipt, so a receipt-time TTL of just one window would forget
        the nonce while the timestamp check would still accept a replay.
        Tying the TTL to the signed timestamp's own expiry closes that gap:
        the nonce is remembered for exactly as long as a replay could still
        pass the timestamp check, never more, never less.
        """
        now_mono = time.monotonic()
        expired = [k for k, expiry in self._webhook_nonces.items() if expiry <= now_mono]
        for k in expired:
            self._webhook_nonces.pop(k, None)

        if key in self._webhook_nonces:
            return False
        ttl = max(0.0, (ts + WEBHOOK_TIMESTAMP_WINDOW_SECONDS) - now_wall)
        if len(self._webhook_nonces) >= MAX_WEBHOOK_NONCES:
            oldest = next(iter(self._webhook_nonces))
            self._webhook_nonces.pop(oldest, None)
        self._webhook_nonces[key] = now_mono + ttl
        return True

    # --- authorization -------------------------------------------------------

    def _authorized(self, open_id: str | None) -> bool:
        """Fail-closed sender/operator gate: only explicitly-allowlisted
        open_ids pass; an empty allowlist rejects everyone."""
        return bool(open_id) and open_id in self.allowed_open_ids

    # --- inbound -------------------------------------------------------------

    async def _on_message(self, msg: "InboundMessage") -> None:
        chat_id = msg.chat_id
        sender = msg.sender_id
        chat_type = msg.chat_type
        # body_text strips the bot's own @-mention (groups); fall back to the
        # full content for p2p where there's no mention to strip.
        text = (msg.body_text or msg.content_text or "").strip()

        # `/pair` is the one command reachable WITHOUT already being on the
        # allowlist — that's its entire purpose (see pairing.py). It's
        # UNIFORMLY not entertained in a group chat, for anyone: a code must
        # never be typeable somewhere a third party could read it, so this
        # returns silently rather than letting an already-allowlisted
        # sender's /pair fall through to the manager's normal command
        # dispatch (which would otherwise reply "Unknown command: /pair").
        # In a private chat this check runs before `_authorized` on purpose
        # so a stranger can actually use it. Every other message from a
        # stranger still falls through unchanged to the silent reject below.
        command_token = text.split(maxsplit=1)[0].lower() if text else ""
        if self._pairing is not None and command_token == "/pair":
            if chat_type == "group":
                return
            await self._handle_pair_command(chat_id, sender, text)
            return

        if not self._authorized(sender):
            # Log the open_id so the operator can discover their own id if
            # pairing is disabled (the bot stays silent to an unauthorized
            # tenant member — no presence leak, no spam). See README
            # "Getting your open_id" — /pair is the primary path, this log
            # line is the documented fallback.
            logger.warning(
                "Feishu: rejecting message from unauthorized open_id=%s (chat=%s)",
                sender,
                chat_id,
            )
            return

        if chat_type == "group":
            # Groups: only act on messages that @-mention the bot, and honor an
            # optional chat allowlist alongside the operator check.
            if not msg.mentioned_bot:
                return
            if self.allowed_chat_ids is not None and chat_id not in self.allowed_chat_ids:
                logger.warning("Feishu: group chat %s not in allowlist", chat_id)
                return

        # Topic/thread messages are explicitly unsupported in v1: sharing one
        # sticky session across threads would silently cross wires.
        if msg.conversation.thread_id:
            await self._send_plain(
                chat_id,
                "Topic/thread replies aren't supported yet — message me in the "
                "main chat instead.",
            )
            return

        # Text (and rich-text 'post', which renders to markdown) only.
        if msg.raw_content_type not in ("", "text", "post"):
            await self._send_plain(
                chat_id,
                "I can only read text messages right now (no voice / image / "
                "file).",
            )
            return

        if not text:
            await self._send_plain(chat_id, "Send me a message and I'll get to work.")
            return

        # Fire-and-forget on the main loop: this runs a dsh turn (a blocking
        # SDK call on a worker thread) and can take a while. Blocking
        # _on_message on it would wedge the chat's outbound behind its own
        # inbound (see _run_on_main).
        await self._run_on_main(
            self.manager.handle_incoming(self.name, chat_id, text, self),
            wait=False,
        )

    async def _handle_pair_command(
        self, chat_id: str, sender: str | None, text: str
    ) -> None:
        """`/pair <code>` — see pairing.py. Reachable from an UNauthorized
        sender by design (`_on_message` routes here before `_authorized`);
        every reply below is worded to give a stranger nothing beyond
        "try again or give up", never a hint about *why* a code failed."""
        assert self._pairing is not None
        if not sender:
            return
        if sender in self.allowed_open_ids:
            await self._send_plain(
                chat_id, "You're already on the allowlist — no need to /pair."
            )
            return

        parts = text.split(maxsplit=1)
        code = parts[1].strip().upper() if len(parts) > 1 else ""
        if not code:
            await self._send_plain(
                chat_id,
                "Usage: /pair <code> — the code is printed on the bridge's "
                "console at startup.",
            )
            return

        outcome = await self._pairing.try_pair(sender, code)
        if outcome == OUTCOME_OK:
            self.allowed_open_ids.add(sender)
            logger.info(
                "Feishu: open_id=%s paired via /pair — added to allowlist", sender
            )
            await self._send_plain(
                chat_id, "Paired! You're on the allowlist now — send me a message any time."
            )
        elif outcome == OUTCOME_INVALID:
            await self._send_plain(chat_id, "Invalid pairing code.")
        else:  # "expired" / "locked" / "consumed" — the round is over either way
            await self._send_plain(
                chat_id,
                "Pairing isn't available right now — ask the operator to "
                "restart the bridge for a new code.",
            )

    # --- card actions (approval / session switch) ----------------------------

    async def _on_card_action(self, event: "CardActionEvent") -> None:
        """Handle an approve / deny / switch button tap.

        Must return fast — Feishu expects the callback answered within ~3s and
        will not retry a failure. So we do only in-memory work inline
        (authorize, consume nonce, settle the approval future / repoint the
        sticky session) and push the cosmetic card update + any confirmation
        onto a background task.
        """
        operator = getattr(event.operator, "open_id", "") or ""
        chat_id = event.chat_id
        value = event.action.value if event.action else None
        if not isinstance(value, dict):
            return

        if not self._authorized(operator):
            logger.warning(
                "Feishu: rejecting card action from unauthorized operator=%s", operator
            )
            return

        # Validate the click against the nonce's stored record BEFORE consuming
        # (the card's `value` is attacker-controllable; only the nonce record
        # — minted when WE built the card — is trusted). We dispatch by the
        # RECORD's kind and require EVERY identity field of the click to match
        # what we bound to that nonce; execution then uses the RECORD's fields.
        # Any mismatch — a forged action, a tampered session/tool, a switch
        # nonce replayed as approve — is rejected WITHOUT consuming the nonce,
        # so a later legitimate click still works.
        nonce = value.get("nonce")
        record = self._nonces.get(nonce) if isinstance(nonce, str) else None
        if record is None:
            # Missing / already-consumed nonce → a stale or duplicate tap. This
            # is the one-time-use guarantee: a second click is inert.
            logger.info("Feishu: ignoring stale/duplicate card action (chat=%s)", chat_id)
            return

        kind = record.get("kind")
        if kind == "approval":
            # Allow and Deny have SEPARATE nonces, each bound to its action; the
            # click's action, session, and tool must all match the record.
            # dsh v1 has no tool-approval flow (dsh_adapter.py module
            # docstring), so a session backend never actually emits an
            # approval-request event and this nonce kind is never minted in
            # practice — kept for interface parity and exercised directly by
            # tests. BridgeManager.handle_tool_decision always returns False.
            if (
                value.get("action") != record.get("action")
                or value.get("session_id") != record.get("session_id")
                or value.get("tool_use_id") != record.get("tool_use_id")
            ):
                logger.warning(
                    "Feishu: approval action/identity mismatch (chat=%s) — rejected", chat_id
                )
                return
            self._consume_nonce(nonce)
            approve = record.get("action") == "approve"
            applied = await self._run_on_main(
                self.manager.handle_tool_decision(
                    self.name, chat_id, record["session_id"], record["tool_use_id"], approve
                )
            )
            note = ("Approved." if approve else "Denied.") if applied else "No longer pending."
            self._settle_card(event.message_id, note)
        elif kind == "switch":
            # Both the action AND the session must match the record. Checking
            # only session_id would let a switch nonce be replayed with an
            # `approve`/`deny` value (session_id kept correct) — it would still
            # consume the nonce and fire a switch, a cross-action replay.
            if (
                value.get("action") != "switch"
                or value.get("session_id") != record.get("session_id")
            ):
                logger.warning(
                    "Feishu: switch action/session mismatch (chat=%s) — rejected", chat_id
                )
                return
            self._consume_nonce(nonce)
            result = await self._run_on_main(
                self.manager.switch_session(self.name, chat_id, record["session_id"])
            )
            self._settle_card(event.message_id, "Switched.")
            await self._send_plain(chat_id, result)
        else:
            # Unknown nonce kind — reject WITHOUT consuming.
            logger.warning(
                "Feishu: unknown nonce kind %r (chat=%s) — rejected", kind, chat_id
            )
            return

    def _settle_card(self, message_id: str, note: str) -> None:
        """Grey out a card after its button is acted on — a REST PATCH queued
        *after* the fast callback ack."""
        self._enqueue(
            "PATCH",
            f"/open-apis/im/v1/messages/{message_id}",
            {"content": json.dumps(self._note_card(note), ensure_ascii=False)},
        )

    # --- nonce lifecycle -----------------------------------------------------

    def _mint_nonce(self, kind: str, **fields: str) -> str:
        nonce = secrets.token_urlsafe(9)
        if len(self._nonces) >= MAX_LIVE_NONCES:
            # Drop the oldest — a card old enough that a click is already stale.
            oldest = next(iter(self._nonces))
            self._nonces.pop(oldest, None)
        self._nonces[nonce] = {"kind": kind, **fields}
        return nonce

    def _consume_nonce(self, nonce: str | None) -> dict[str, str] | None:
        if not nonce:
            return None
        return self._nonces.pop(nonce, None)

    # --- outbound send methods ----------------------------------------------

    async def _send(self, chat_id: str, message: dict[str, Any]) -> None:
        """Queue one message to a chat for the outbound worker.

        ``message`` is ``{"card": <card json>}`` or ``{"text": <str>}``. Cards go
        as ``msg_type="interactive"``, plain status lines as ``msg_type="text"``.
        ``content`` is the Feishu-required JSON *string*. Async only to match the
        base ``Bridge`` send interface — enqueue itself is instant/non-blocking.
        """
        if "card" in message:
            body = {"receive_id": chat_id, "msg_type": "interactive",
                    "content": json.dumps(message["card"], ensure_ascii=False)}
        else:
            body = {"receive_id": chat_id, "msg_type": "text",
                    "content": json.dumps({"text": message.get("text", "")}, ensure_ascii=False)}
        self._enqueue("POST", "/open-apis/im/v1/messages?receive_id_type=chat_id", body)

    async def _send_card_md(self, chat_id: str, markdown: str) -> None:
        for chunk in self._split_chars(markdown, MAX_CARD_CHARS):
            await self._send(chat_id, {"card": self._md_card(chunk)})

    async def _send_plain(self, chat_id: str, text: str) -> None:
        for chunk in self._split_chars(text, MAX_CARD_CHARS):
            await self._send(chat_id, {"text": chunk})

    async def send_text(self, chat_id: str, text: str) -> None:
        # Replies + command output render as interactive cards (lark_md),
        # which is the only way to get markdown in Feishu.
        await self._send_card_md(chat_id, text)

    async def send_tool_use(
        self, chat_id: str, tool_name: str, tool_input: dict[str, Any]
    ) -> None:
        preview = ""
        if isinstance(tool_input, dict):
            if "command" in tool_input:
                preview = f": `{str(tool_input['command'])[:80]}`"
            elif "file_path" in tool_input:
                preview = f": `{tool_input['file_path']}`"
        await self._send_card_md(chat_id, f"**{tool_name}**{preview}")

    async def send_tool_result(self, chat_id: str, output: str, is_error: bool) -> None:
        prefix = "Error" if is_error else "Result"
        truncated = output[:MAX_PREVIEW_CHARS]
        if len(output) > MAX_PREVIEW_CHARS:
            truncated += "\n…"
        await self._send_card_md(chat_id, f"**{prefix}:**\n```\n{truncated}\n```")

    async def send_tool_approval_request(
        self,
        chat_id: str,
        session_id: str,
        tool_use_id: str,
        tool_name: str,
        tool_input: dict[str, Any],
    ) -> None:
        input_str = json.dumps(tool_input, indent=2, ensure_ascii=False)
        if len(input_str) > MAX_PREVIEW_CHARS:
            input_str = input_str[:MAX_PREVIEW_CHARS] + "\n…"
        # Allow and Deny each get their OWN nonce, bound to that exact action
        # PLUS full identity (session + tool). The nonce record — not the
        # attacker-controllable card `value` — is the source of truth, and a
        # nonce fires only the action it was minted for: a `deny` value can't
        # replay the `approve` nonce, and neither can be re-pointed at another
        # session/tool.
        allow_nonce = self._mint_nonce(
            "approval", action="approve", session_id=session_id, tool_use_id=tool_use_id
        )
        deny_nonce = self._mint_nonce(
            "approval", action="deny", session_id=session_id, tool_use_id=tool_use_id
        )
        card = {
            "config": {"wide_screen_mode": True},
            "elements": [
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": f"**{tool_name}** wants to run:\n```\n{input_str}\n```",
                    },
                },
                {
                    "tag": "action",
                    "actions": [
                        self._button("Allow", "primary", {
                            "action": "approve", "session_id": session_id,
                            "tool_use_id": tool_use_id, "nonce": allow_nonce,
                        }),
                        self._button("Deny", "danger", {
                            "action": "deny", "session_id": session_id,
                            "tool_use_id": tool_use_id, "nonce": deny_nonce,
                        }),
                    ],
                },
            ],
        }
        await self._send(chat_id, {"card": card})

    async def send_session_list(
        self,
        chat_id: str,
        sessions: list[dict[str, Any]],
        note: str | None = None,
    ) -> None:
        buttons = []
        for s in sessions:
            check = " ✓" if s.get("current") else ""
            label = f"{s['name']} [{s['status']}]{check}"
            if len(label) > 60:
                label = label[:57] + "…"
            nonce = self._mint_nonce("switch", session_id=s["id"])
            buttons.append(
                self._button(
                    label, "default", {"action": "switch", "session_id": s["id"], "nonce": nonce}
                )
            )
        content = "Tap a session to switch:"
        if note:
            content += f"\n{note}"
        card = {
            "config": {"wide_screen_mode": True},
            "elements": [
                {"tag": "div", "text": {"tag": "lark_md", "content": content}},
                {"tag": "action", "actions": buttons},
            ],
        }
        await self._send(chat_id, {"card": card})

    async def send_status(self, chat_id: str, status: str) -> None:
        # "running"/"idle" are noise to a phone user; surface only meaningful
        # status lines as plain text.
        if status in ("running", "idle", "waiting_approval", ""):
            return
        await self._send_plain(chat_id, status)

    async def send_result(self, chat_id: str, cost: float | None, is_error: bool) -> None:
        cost_str = f" (${cost:.4f})" if cost is not None else ""
        label = "Error" if is_error else "Done"
        await self._send_plain(chat_id, f"{label}{cost_str}")

    async def send_error(self, chat_id: str, message: str) -> None:
        await self._send_plain(chat_id, f"Error: {message}")

    # --- card helpers --------------------------------------------------------

    @staticmethod
    def _md_card(content: str) -> dict[str, Any]:
        return {
            "config": {"wide_screen_mode": True},
            "elements": [{"tag": "div", "text": {"tag": "lark_md", "content": content}}],
        }

    @staticmethod
    def _note_card(note: str) -> dict[str, Any]:
        """A buttonless card used to replace an acted-on card (greys it out)."""
        return {
            "config": {"wide_screen_mode": True},
            "elements": [{"tag": "div", "text": {"tag": "lark_md", "content": note}}],
        }

    @staticmethod
    def _button(text: str, style: str, value: dict[str, Any]) -> dict[str, Any]:
        return {
            "tag": "button",
            "text": {"tag": "plain_text", "content": text},
            "type": style,
            "value": value,
        }

    @staticmethod
    def _split_chars(text: str, max_len: int) -> list[str]:
        if len(text) <= max_len:
            return [text]
        chunks: list[str] = []
        while text:
            if len(text) <= max_len:
                chunks.append(text)
                break
            split_at = text.rfind("\n", 0, max_len)
            if split_at == -1 or split_at < max_len // 2:
                split_at = max_len
            chunks.append(text[:split_at])
            text = text[split_at:].lstrip("\n")
        return chunks
