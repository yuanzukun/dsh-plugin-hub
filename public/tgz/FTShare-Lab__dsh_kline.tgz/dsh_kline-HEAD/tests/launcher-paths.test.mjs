import { test } from 'node:test'
import assert from 'node:assert/strict'
import { join } from 'node:path'

import {
  defaultRuntimeDirectory,
  defaultStateDirectory,
  backgroundBootstrapSpawnOptions,
  pythonCandidates,
  pythonEnvironment,
  pythonPathForVenv,
  desktopPythonCandidates,
  venvBaseCandidates,
  pythonProbeOutcome,
  settingsCredentialEnvironment,
  settingsCredentialFile,
} from '../scripts/run-dsh-kline.mjs'

test('Python diagnostics distinguish missing, old, broken and Store redirectors', () => {
  const candidate = { command: 'python', args: [] }
  assert.equal(pythonProbeOutcome(candidate, { error: { code: 'ENOENT' } }).code, 'PYTHON_NOT_FOUND')
  assert.equal(pythonProbeOutcome(candidate, { status: 0, stdout: '3.10\n' }).code, 'PYTHON_VERSION_TOO_OLD')
  assert.equal(pythonProbeOutcome(candidate, { status: 1 }).code, 'PYTHON_EXECUTION_FAILED')
  const alias = 'C:\\Users\\test\\AppData\\Local\\Microsoft\\WindowsApps\\python.exe'
  assert.equal(pythonProbeOutcome(candidate, { status: 9009 }, 'win32', alias).code, 'PYTHON_STORE_ALIAS')
  assert.equal(pythonProbeOutcome(candidate, { status: 0, stdout: '3.12\n' }, 'win32', alias).code, 'PYTHON_READY')
})

test('Desktop and pyvenv base interpreters support Windows spaces and Unicode', () => {
  const executable = 'C:\\Users\\测试 User\\DeepSeek Harness\\DeepSeek Harness.exe'
  assert.equal(desktopPythonCandidates(executable, 'win32')[0].command,
    'C:\\Users\\测试 User\\DeepSeek Harness\\resources\\runtime\\primary-runtime\\dependencies\\python\\python.exe')
  assert.deepEqual(venvBaseCandidates('home = D:\\Python 环境\r\nversion = 3.12.0\r\n', 'win32'),
    [{ command: 'D:\\Python 环境\\python.exe', args: [] }])
  assert.deepEqual(venvBaseCandidates('home = relative\n', 'win32'), [])
  assert.ok(pythonCandidates({ LOCALAPPDATA: 'C:\\Users\\测试 User\\AppData\\Local' }, 'win32')
    .some(candidate => candidate.command.endsWith('Programs\\Python\\Python313\\python.exe')))
  assert.deepEqual(desktopPythonCandidates('/Applications/DSH.app/Contents/MacOS/DSH', 'darwin'), [])
})

test('Windows uses native venv and LOCALAPPDATA paths', () => {
  const env = { LOCALAPPDATA: 'C:\\Users\\测试 User\\AppData\\Local' }
  assert.equal(
    pythonPathForVenv('C:\\Users\\测试 User\\runtime', 'win32'),
    'C:\\Users\\测试 User\\runtime\\Scripts\\python.exe',
  )
  assert.equal(
    defaultStateDirectory(env, 'win32', 'C:\\Users\\测试 User'),
    'C:\\Users\\测试 User\\AppData\\Local\\dsh_kline',
  )
  assert.equal(
    defaultRuntimeDirectory(env, 'win32', 'C:\\Users\\测试 User'),
    'C:\\Users\\测试 User\\AppData\\Local\\dsh_kline\\runtime',
  )
})

test('Windows Python Launcher candidates are version bounded and ordered', () => {
  assert.deepEqual(pythonCandidates({}, 'win32').slice(0, 3), [
    { command: 'py', args: ['-3.13'] },
    { command: 'py', args: ['-3.12'] },
    { command: 'py', args: ['-3.11'] },
  ])
  assert.deepEqual(pythonCandidates({ DSH_KLINE_PYTHON: 'D:\\Python\\python.exe' }, 'win32'), [
    { command: 'D:\\Python\\python.exe', args: [] },
  ])
})

test('POSIX and explicit runtime paths remain deterministic', () => {
  const candidates = pythonCandidates({}, 'darwin').map(candidate => candidate.command)
  assert.ok(candidates.indexOf('/opt/homebrew/bin/python3.13') < candidates.indexOf('python3'))
  assert.ok(candidates.indexOf('python3.13') < candidates.indexOf('python3'))
  assert.equal(pythonPathForVenv('/tmp/venv', 'linux'), '/tmp/venv/bin/python')
  assert.equal(
    defaultStateDirectory({ XDG_CACHE_HOME: '/tmp/cache root' }, 'linux', '/home/user'),
    '/tmp/cache root/dsh_kline',
  )
  assert.equal(
    defaultRuntimeDirectory({ DSH_KLINE_RUNTIME_DIR: '/tmp/custom runtime' }, 'linux', '/home/user'),
    '/tmp/custom runtime',
  )
})

test('Python subprocesses use deterministic UTF-8 and noninteractive pip output', () => {
  assert.deepEqual(pythonEnvironment({ KEEP_ME: 'yes', PYTHONUTF8: '0' }), {
    KEEP_ME: 'yes',
    PYTHONUTF8: '1',
    PYTHONIOENCODING: 'utf-8',
    PIP_PROGRESS_BAR: 'off',
    PIP_DISABLE_PIP_VERSION_CHECK: '1',
    PIP_NO_INPUT: '1',
  })
})

test('deferred bootstrap is detached on every host, including Windows', () => {
  assert.equal(backgroundBootstrapSpawnOptions('win32', {}).detached, true)
  assert.equal(backgroundBootstrapSpawnOptions('win32', {}).windowsHide, true)
  assert.equal(backgroundBootstrapSpawnOptions('linux', {}).detached, true)
})

test('the settings credential file is keyed to the owning DSH host', () => {
  assert.equal(settingsCredentialFile('/tmp/runtime', 42), join('/tmp/runtime', 'credentials', 'ftshare-42.json'))
  assert.deepEqual(settingsCredentialEnvironment('/tmp/runtime', { DSH_KLINE_HOST_PID: '42' }),
    { DSH_KLINE_SETTINGS_KEY_FILE: join('/tmp/runtime', 'credentials', 'ftshare-42.json') })
})

test('a server launched without a DSH host keeps its previous credential resolution', () => {
  for (const env of [{}, { DSH_KLINE_HOST_PID: '' }, { DSH_KLINE_HOST_PID: '   ' }, { DSH_KLINE_HOST_PID: 'host' }]) {
    assert.deepEqual(settingsCredentialEnvironment('/tmp/runtime', env), {})
  }
})
