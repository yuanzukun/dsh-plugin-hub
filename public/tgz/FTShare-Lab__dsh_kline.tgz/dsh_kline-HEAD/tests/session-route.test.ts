import { after, test } from 'node:test'
import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { randomBytes } from 'node:crypto'
import { mkdir, mkdtemp, rm, writeFile, unlink } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const testRuntime = await mkdtemp(join(tmpdir(), 'dsh-kline-session-test-'))
process.env.DSH_KLINE_RUNTIME_DIR = testRuntime
process.env.DSH_KLINE_CACHE_DIR = join(testRuntime, 'cache')
const { apply, runtimeDirectory } = await import('../src/index.ts')
after(async () => { await rm(testRuntime, { recursive: true, force: true }) })

test('each Harness uses only its own live MCP locator, never a sibling or stale service', async () => {
  const directory = join(testRuntime, 'services')
  await mkdir(directory, {recursive:true})
  const owned = join(directory, `${process.pid}.json`)
  const sibling = join(directory, `${process.pid + 10000000}.json`)
  const calls: string[] = []
  const upstream = createServer((request, response) => {
    assert.equal(request.headers['x-dsh-kline-token'], 'a'.repeat(32))
    calls.push(request.url ?? '')
    response.setHeader('Content-Type', 'application/json')
    response.end(JSON.stringify({ok:true, source:'owned-service'}))
  })
  await new Promise<void>(resolve => upstream.listen(0, '127.0.0.1', resolve))
  let handler: any
  apply({effect: callback => {callback()}, webServer:{register: route => {handler = route.handler; return () => {}}}})
  const server = createServer((request, response) => {void handler(request, response)})
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  const endpoint = `http://127.0.0.1:${(server.address() as any).port}/dsh-kline/api/tools/data_source_status`
  const pulseEndpoint = `http://127.0.0.1:${(server.address() as any).port}/dsh-kline/api/tools/fetch_market_pulse`
  const intelligenceEndpoint = `http://127.0.0.1:${(server.address() as any).port}/dsh-kline/api/tools/fetch_security_intelligence`
  const watchlistGetEndpoint = `http://127.0.0.1:${(server.address() as any).port}/dsh-kline/api/tools/watchlist_get`
  const watchlistSaveEndpoint = `http://127.0.0.1:${(server.address() as any).port}/dsh-kline/api/tools/watchlist_save`
  const document = {ok:true, process_id:process.pid, host_process_id:process.pid, session:'',
    service_url:`http://127.0.0.1:${(upstream.address() as any).port}`, service_token:'a'.repeat(32), published_at:Math.floor(Date.now()/1000)}
  const request = async () => (await fetch(endpoint, {method:'POST', body:'{}'})).json()
  try {
    await writeFile(sibling, JSON.stringify({...document, host_process_id:process.pid + 10000000}), {mode:0o600,flag:'wx'})
    assert.equal((await request()).error, 'chart_session_unavailable')
    await writeFile(owned, JSON.stringify(document), {mode:0o600,flag:'wx'})
    assert.equal((await request()).source, 'owned-service')
    // A test profile publishing/stopping must not replace the main locator.
    await writeFile(sibling, JSON.stringify({...document, process_id:-1}))
    assert.equal((await request()).source, 'owned-service')
    // Misaddressed and dead owner records must fail closed, not borrow another profile.
    await writeFile(owned, JSON.stringify({...document, host_process_id:process.pid + 1}))
    const failed = await request()
    assert.equal(failed.error, 'chart_session_unavailable')
    assert.match(failed.message, /当前 DSH/)
    assert.equal(failed.service_token, undefined)
    await writeFile(owned, JSON.stringify({...document, process_id:-1}))
    assert.equal((await request()).error, 'chart_session_unavailable')
    // MCP restart on the same host replaces only that host's locator.
    await writeFile(owned, JSON.stringify(document))
    assert.equal((await request()).source, 'owned-service')
    assert.equal((await (await fetch(pulseEndpoint, {method:'POST', body:'{}'})).json()).source, 'owned-service')
    assert.equal((await (await fetch(intelligenceEndpoint, {method:'POST', body:'{}'})).json()).source, 'owned-service')
    assert.equal((await (await fetch(watchlistGetEndpoint, {method:'POST', body:'{}'})).json()).source, 'owned-service')
    assert.equal((await (await fetch(watchlistSaveEndpoint, {method:'POST', body:'{}'})).json()).source, 'owned-service')
    assert.equal(calls.length, 7)
  } finally {
    await Promise.all([owned,sibling].map(path => unlink(path).catch(() => {})))
    for (const instance of [server,upstream]) {
      instance.closeAllConnections()
      await new Promise<void>(resolve => instance.close(() => resolve()))
    }
  }
})

test('chart routes require an explicit token and never expose service credentials', async () => {
  let handler: any
  apply({ effect: callback => { callback() }, webServer: { register: route => { handler = route.handler; return () => {} } } })
  const server = createServer((request, response) => { void handler(request, response) })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  const origin = `http://127.0.0.1:${(server.address() as any).port}`
  const tokenA = randomBytes(24).toString('base64url'), tokenB = randomBytes(24).toString('base64url')
  const directory = join(testRuntime, 'sessions')
  await mkdir(directory, {recursive: true})
  const paths = [tokenA, tokenB].map(token => join(directory, `${token}.json`))
  try {
    for (const [index, path] of paths.entries()) {
      await writeFile(path, JSON.stringify({ok: true, session: [tokenA, tokenB][index],
        symbol: ['A', 'B'][index], service_token: 'private-secret', process_id: -1,
        payload: {symbol: ['A', 'B'][index]}}), {mode: 0o600, flag: 'wx'})
    }
    assert.equal((await (await fetch(`${origin}/dsh-kline/data`)).json()).error, 'chart_session_required')
    assert.equal((await (await fetch(`${origin}/dsh-kline/data?session=..%2Fchart-session`)).json()).error, 'chart_session_required')
    const missing = await (await fetch(`${origin}/dsh-kline/data?session=${randomBytes(24).toString('base64url')}`)).json()
    assert.match(missing.message, /快照已不可用/)
    // Saved payloads are available after their original process has exited.
    assert.equal((await (await fetch(`${origin}/dsh-kline/data?session=${tokenA}`)).json()).payload.symbol, 'A')
    assert.equal((await (await fetch(`${origin}/dsh-kline/data?session=${tokenB}`)).json()).payload.symbol, 'B')
    const publicSession = await (await fetch(`${origin}/dsh-kline/session?session=${tokenA}`)).json()
    assert.equal(publicSession.symbol, 'A')
    assert.equal(publicSession.service_token, undefined)
    assert.equal(publicSession.payload, undefined)
    assert.equal((await fetch(`${origin}/dsh-kline/data?session=${tokenA}`, {method: 'POST'})).status, 405)
  } finally {
    await Promise.all(paths.map(path => unlink(path)))
    server.closeAllConnections()
    await new Promise<void>(resolve => server.close(() => resolve()))
  }
})

test('browser context route registers public host runtime context and rejects cross-origin reports', async () => {
  let handler:any, provider:any
  apply({effect: callback=>{callback()},webServer:{register: route=>{handler=route.handler;return()=>{}}},
    inject: (_deps, callback)=>callback({effect:callback=>{callback()},webServer:{register:()=>()=>{}},
      systemPrompt:{context: input=>{provider=input;return()=>{}}}})})
  const server=createServer((request,response)=>{void handler(request,response)})
  await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve))
  const origin=`http://127.0.0.1:${(server.address() as any).port}`
  const view=randomBytes(24).toString('base64url')
  const body={conversation_id:'context-conversation',view_id:view,sequence:1,captured_at_ms:Date.now(),active:true,
    state:{state:'ready',symbol:'TEST.X',name:'测试',interval:'day',range_key:'custom',active_page:'chart',
      candles:[{time:1,open:31,high:33,low:30,close:32,volume:1}],visible_range:{available:true,index_from:0,index_to_exclusive:1},drawings:[]}}
  try {
    assert.equal(provider.name,'dsh-kline:current-view')
    assert.equal((await fetch(origin+'/dsh-kline/context',{method:'POST',headers:{'Content-Type':'application/json',Origin:'http://other-origin.test'},body:JSON.stringify(body)})).status,403)
    const missingState=await fetch(origin+'/dsh-kline/context',{method:'POST',headers:{'Content-Type':'application/json',Origin:origin},body:JSON.stringify({...body,state:null})})
    assert.equal(missingState.status,409)
    assert.equal((await missingState.json()).error,'context_state_required')
    const result=await (await fetch(origin+'/dsh-kline/context',{method:'POST',headers:{'Content-Type':'application/json',Origin:origin},body:JSON.stringify({...body,sequence:2})})).json()
    assert.equal(result.ok,true); assert.match(result.context_ref,/^[A-Za-z0-9_-]{32}$/)
    const agent={session:{id:'context-conversation'}}
    assert.ok(provider.text({agent,scope:agent}).includes(result.context_ref))
    const other={session:{id:'other'}}
    assert.ok(!provider.text({agent:other,scope:other}).includes(result.context_ref))
    assert.equal((await fetch(origin+'/dsh-kline/context')).status,405)
    const closed={...body,sequence:3,active:false,state:null}
    assert.equal((await (await fetch(origin+'/dsh-kline/context',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(closed)})).json()).ok,true)
    assert.match(provider.text({agent,scope:agent}),/unavailable/)
  } finally {
    server.closeAllConnections(); await new Promise<void>(resolve=>server.close(()=>resolve()))
  }
})


test('health probes the actual backend identity and unknown paths never masquerade as health', async () => {
  let handler: any
  apply({effect:callback=>callback(),webServer:{register:route=>{handler=route.handler;return()=>{}}}})
  const server=createServer((request,response)=>{void handler(request,response)})
  const backend=createServer((_request,response)=>{
    response.setHeader('Content-Type','application/json')
    response.end(JSON.stringify({ok:true,service:'dsh_kline_chart',process_id:process.pid,
      host_process_id:process.pid,instance_id:identity}))
  })
  let identity='current-instance'
  await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve))
  await new Promise<void>(resolve=>backend.listen(0,'127.0.0.1',resolve))
  const origin=`http://127.0.0.1:${(server.address() as any).port}`
  const manifest=join(testRuntime,'services',`${process.pid}.json`)
  const health=async()=>{const response=await fetch(origin+'/dsh-kline/healthz');return {status:response.status,body:await response.json()}}
  try {
    assert.equal((await fetch(origin+'/dsh-kline/nope')).status,404)
    let result=await health()
    assert.equal(result.status,503)
    assert.equal(result.body.reason,'service_locator_missing')
    assert.equal((await (await fetch(origin+'/dsh-kline/session')).json()).error,'chart_session_required')
    await mkdir(join(testRuntime,'services'),{recursive:true})
    const locator={ok:true,host_process_id:process.pid,process_id:process.pid,session:'',
      service_url:`http://127.0.0.1:${(backend.address() as any).port}`,service_token:'private-token-'.repeat(4),
      published_at:Math.floor(Date.now()/1000),instance_id:identity}
    await writeFile(manifest,JSON.stringify(locator))
    result=await health()
    assert.equal(result.status,200)
    assert.equal(result.body.ok,true)
    assert.equal(result.body.service_token,undefined)
    assert.equal(JSON.stringify(result.body).includes(locator.service_token),false)
    identity='different-process-on-same-port'
    assert.equal((await health()).body.reason,'backend_identity_mismatch')
    await writeFile(manifest,'{broken-json')
    assert.equal((await health()).body.reason,'service_locator_invalid')
    await writeFile(manifest,JSON.stringify({...locator,host_process_id:process.pid+1}))
    assert.equal((await health()).body.reason,'service_host_mismatch')
    await writeFile(manifest,JSON.stringify(locator))
    backend.closeAllConnections()
    await new Promise<void>(resolve=>backend.close(()=>resolve()))
    result=await health()
    assert.equal(result.status,503)
    assert.equal(result.body.reason,'backend_unreachable','live PID alone cannot prove health')
    assert.equal((await fetch(origin+'/dsh-kline/nope')).status,404)
  } finally {
    await unlink(manifest).catch(()=>{})
    for(const instance of [server,backend]){
      instance.closeAllConnections()
      if(instance.listening)await new Promise<void>(resolve=>instance.close(()=>resolve()))
    }
  }
})


test('sidebar resolves a custom cache directory exactly like the Python launcher', () => {
  const cache=join(testRuntime,'custom-cache')
  assert.equal(runtimeDirectory({DSH_KLINE_CACHE_DIR:cache}),join(cache,'runtime'))
  const runtime=join(testRuntime,'explicit-runtime')
  assert.equal(runtimeDirectory({DSH_KLINE_CACHE_DIR:cache,DSH_KLINE_RUNTIME_DIR:runtime}),runtime)
})
