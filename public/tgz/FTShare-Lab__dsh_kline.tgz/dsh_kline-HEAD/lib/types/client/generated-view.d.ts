export declare const PACKAGE_VERSION = "0.6.7";
export declare function mountKlineView(root: any, payload: any, dependencies?: {}): () => void;
