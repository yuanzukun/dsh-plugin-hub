import { readFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { ChartServiceUnavailable, readServiceLocator, probeChartService, unavailableService, type ServiceLocator } from './chart-service-status.ts'
import { ChartContextBroker } from './chart-context.ts'
import { ChartApplications } from './chart-applications.ts'
import { startFtshareSettingsBridge, type FtshareSettingsService } from './ftshare-settings-bridge.ts'

export const name = 'dsh-kline-sidebar'
export const inject = ['webServer']

const RUNTIME_DIR = runtimeDirectory()
const RUNTIME_FILE = join(RUNTIME_DIR, 'services', `${process.pid}.json`)
const STATE_DIR = stateDirectory()
const SESSION_DIR = join(RUNTIME_DIR, 'sessions')
const VENDOR_FILE = fileURLToPath(new URL('../view/vendor/klinecharts.min.js', import.meta.url))
const LOGO_FILE = fileURLToPath(new URL('../view/ft-logo.jpg', import.meta.url))
const MAX_PROXY_BYTES = 8 * 1024 * 1024
const CHART_ACTIONS = new Set([
  'analyze_kline',
  'analyze_key_levels',
  'calc_range',
  'calculate_chart_indicators',
  'fetch_candles',
  'fetch_comparison_candles',
  'fetch_security_workspace',
  'fetch_market_pulse',
  'fetch_market_board_detail',
  'fetch_security_intelligence',
  'watchlist_get',
  'watchlist_save',
  'market_ticker',
  'search_symbols',
  'symbol_directory',
  'data_source_status',
  'configure_ftshare',
  'test_ftshare_connection',
  'workbench_run_ta',
  'workbench_run_chart_function',
  'workbench_prepare_edit',
  'workbench_apply_edit',
  'workbench_edit_status',
])

interface WebServerContext {
  effect(callback: () => () => void, label: string): void
  inject?(deps: string[], callback: (ctx: WebServerContext) => void): unknown
  systemPrompt?: { context(input: {name: string; order: number; text: (context: any) => string}): () => void }
  ftshareSettings?: FtshareSettingsService
  webServer: {
    register(route: {
      kind: 'prefix'
      path: string
      handler: (request: IncomingMessage, response: ServerResponse) => void | Promise<void>
    }): () => void
  }
}

export function apply(ctx: WebServerContext): void {
  const contexts = new ChartContextBroker(join(RUNTIME_DIR, 'views', String(process.pid)),()=>Date.now(),RUNTIME_DIR)
  ctx.effect(() => ctx.webServer.register({
    kind: 'prefix',
    path: '/dsh-kline',
    handler: (request, response) => serveRuntimeSession(request, response, contexts),
  }), 'dsh-kline: chart session route')
  ctx.inject?.(['systemPrompt'], scoped => {
    if (typeof scoped.systemPrompt?.context !== 'function') return
    scoped.effect(() => scoped.systemPrompt!.context({name: 'dsh-kline:current-view', order: 350,
      text: context => contexts.prompt(context)}), 'dsh-kline: current chart context')
  })
  ctx.inject?.(['ftshareSettings'], scoped => {
    if (!scoped.ftshareSettings?.apiKey) return
    const bridge = startFtshareSettingsBridge({settings: scoped.ftshareSettings, runtimeDirectory: RUNTIME_DIR})
    scoped.effect(() => () => { void bridge.dispose() }, 'dsh-kline: FTShare settings credential bridge')
  })
}

async function serveRuntimeSession(request: IncomingMessage, response: ServerResponse, contexts: ChartContextBroker): Promise<void> {
  const url = new URL(request.url ?? '/', 'http://localhost')
  const pathname = url.pathname
  try {
    if (pathname === '/dsh-kline/healthz') {
      if (request.method !== 'GET' && request.method !== 'HEAD') {
        sendJson(response, 405, {ok:false,error:'method_not_allowed'}); return
      }
      const version = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8')).version
      const diagnostics = {version, host_process_id:process.pid, locator_path:RUNTIME_FILE,
        log_path:join(STATE_DIR, 'logs', `backend-${process.pid}.log`)}
      try {
        const locator = await readServiceLocator(RUNTIME_FILE, process.pid)
        await probeChartService(locator)
        sendJson(response, 200, {ok:true, ...diagnostics, process_id:locator.process_id,
          service_url:locator.service_url}, request.method === 'HEAD')
      } catch (error) {
        let reason = error instanceof ChartServiceUnavailable ? error.reason : 'service_locator_invalid'
        if (reason === 'service_locator_missing') {
          try {
            const status = JSON.parse(await readFile(join(STATE_DIR, 'logs', `backend-${process.pid}.json`), 'utf8'))
            if (status.host_process_id === process.pid && Number.isSafeInteger(status.launcher_process_id)) {
              process.kill(status.launcher_process_id, 0)
              if (status.phase === 'preparing') reason = 'runtime_preparing'
              else if (status.phase === 'recovering') reason = 'runtime_recovering'
            }
          } catch { /* A missing or stale diagnostic cannot prove readiness. */ }
        }
        sendJson(response, 503, {...unavailableService(reason), ...diagnostics}, request.method === 'HEAD')
      }
      return
    }
    if (pathname === '/dsh-kline/recovery' && request.method === 'GET') {
      try {
        const recovery = await new ChartApplications(RUNTIME_DIR).recover(url.searchParams.get('conversation') ?? '')
        sendJson(response, 200, recovery)
      } catch { sendJson(response, 200, {ok:false,error:'confirmed_chart_recovery_unavailable'}) }
      return
    }
    if (pathname === '/dsh-kline/context') {
      if (request.method !== 'POST') { sendJson(response, 405, {ok:false,error:'method_not_allowed'}); return }
      if (request.headers['content-type']?.split(';')[0] !== 'application/json'
        || request.headers.origin && new URL(request.headers.origin).host !== request.headers.host) {
        sendJson(response, 403, {ok:false,error:'invalid_context_origin'}); return
      }
      try {
        const result = await contexts.publish(JSON.parse((await readRequestBody(request)).toString('utf8')))
        sendJson(response, 200, result)
      } catch (error) {
        if (error instanceof Error && error.message === 'context_state_required') {
          sendJson(response, 409, {ok:false,error:'context_state_required'})
        } else {
          sendJson(response, 400, {ok:false,error:'context_publication_rejected'})
        }
      }
      return
    }
    // Static browser assets must remain available before the first chart session exists.
    if (pathname === '/dsh-kline/vendor/klinecharts.min.js' && (request.method === 'GET' || request.method === 'HEAD')) {
      const body = await readFile(VENDOR_FILE)
      sendBytes(response, 200, body, 'text/javascript; charset=utf-8', request.method === 'HEAD')
      return
    }
    if (pathname === '/dsh-kline/logo.jpg' && (request.method === 'GET' || request.method === 'HEAD')) {
      const body = await readFile(LOGO_FILE)
      sendBytes(response, 200, body, 'image/jpeg', request.method === 'HEAD')
      return
    }
    // Never infer a chart from the global latest publication. The browser
    // obtains this opaque reference from the owning conversation's result.
    if (pathname === '/dsh-kline/session' || pathname === '/dsh-kline/data') {
      if (request.method !== 'GET' && request.method !== 'HEAD') {
        sendJson(response, 405, { ok: false, error: 'method_not_allowed' })
        return
      }
      const token = url.searchParams.get('session') ?? ''
      if (!/^[A-Za-z0-9_-]{32}$/.test(token)) {
        sendJson(response, 200, { ok: false, error: 'chart_session_required' })
        return
      }
      const saved = JSON.parse(await readFile(join(SESSION_DIR, `${token}.json`), 'utf8')) as ServiceLocator & { payload: unknown }
      if (saved.session !== token || saved.ok !== true) throw new Error('invalid_chart_snapshot')
      if (pathname === '/dsh-kline/data') {
        sendJson(response, 200, { ok: true, session: token, payload: saved.payload }, request.method === 'HEAD')
      } else {
        sendJson(response, 200, { ok: true, session: token, symbol: saved.symbol, name: saved.name, published_at: saved.published_at }, request.method === 'HEAD')
      }
      return
    }
    // Unknown paths have a stable routing result, independent of backend state.
    if (!pathname.startsWith('/dsh-kline/api/tools/')) {
      sendJson(response, 404, {ok:false,error:'not_found'}, request.method === 'HEAD'); return
    }
    const session = await readLiveSession()
    if (pathname.startsWith('/dsh-kline/api/tools/') && request.method === 'POST') {
      const action = pathname.slice('/dsh-kline/api/tools/'.length).replaceAll('/', '')
      if (!CHART_ACTIONS.has(action)) {
        sendJson(response, 404, { ok: false, error: 'unsupported_chart_action' })
        return
      }
      if (action.startsWith('workbench_') && (
        request.headers['content-type']?.split(';')[0] !== 'application/json'
        || request.headers.origin && new URL(request.headers.origin).host !== request.headers.host
        || request.headers['sec-fetch-site'] && !['same-origin', 'none'].includes(String(request.headers['sec-fetch-site']))
      )) {
        sendJson(response, 403, { ok: false, error: 'invalid_workbench_origin' })
        return
      }
      const body = await readRequestBody(request)
      await proxyJson(response, `${serviceOrigin(session)}/api/tools/${encodeURIComponent(action)}`, {
        method: 'POST',
        headers: { ...chartServiceHeaders(session), 'Content-Type': 'application/json' },
        body: body.toString('utf8'),
      })
      return
    }
    if (pathname.startsWith('/dsh-kline/api/tools/')) {
      response.writeHead(405, { Allow: 'POST' })
      response.end()
      return
    }
    sendJson(response, 404, { ok: false, error: 'not_found' })
  } catch (error) {
    if (error instanceof ChartServiceUnavailable) {
      sendJson(response, 200, unavailableService(error.reason), request.method === 'HEAD'); return
    }
    const code = error instanceof Error && 'code' in error ? String(error.code) : ''
    sendJson(
      response,
      code === 'ENOENT' ? 200 : 500,
      code === 'ENOENT'
        ? (pathname === '/dsh-kline/data' || pathname === '/dsh-kline/session'
          ? { ok: false, error: 'chart_session_unavailable', message: '这张图表的快照已不可用，请在当前对话重新分析该标的。' }
          : unavailableService())
        : { ok: false, error: 'chart_session_manifest_failed' },
      request.method === 'HEAD',
    )
  }
}

export function runtimeDirectory(env: NodeJS.ProcessEnv = process.env): string {
  const explicit = String(env.DSH_KLINE_RUNTIME_DIR || '').trim()
  if (explicit) return resolve(explicit)
  return join(stateDirectory(env), 'runtime')
}

function stateDirectory(env: NodeJS.ProcessEnv = process.env): string {
  const explicit = String(env.DSH_KLINE_CACHE_DIR || '').trim()
  if (explicit) return resolve(explicit)
  if (process.platform === 'win32') {
    const local = String(env.LOCALAPPDATA || env.APPDATA || '').trim()
    return join(local || join(homedir(), 'AppData', 'Local'), 'dsh_kline')
  }
  const cache = String(env.XDG_CACHE_HOME || '').trim()
  return join(cache || join(homedir(), '.cache'), 'dsh_kline')
}

function chartServiceHeaders(session: ServiceLocator): Record<string, string> {
  return { 'X-DSH-Kline-Token': session.service_token }
}

async function readLiveSession(): Promise<ServiceLocator> {
  return readServiceLocator(RUNTIME_FILE, process.pid)
}

function serviceOrigin(session: ServiceLocator): string {
  return new URL(session.service_url).origin
}

async function proxyJson(response: ServerResponse, url: string, init: RequestInit): Promise<void> {
  let upstream: Response
  try { upstream = await fetch(url, {...init, signal:AbortSignal.timeout(120000)}) }
  catch (error) { throw new ChartServiceUnavailable(error instanceof Error && error.name === 'TimeoutError' ? 'backend_timeout' : 'backend_unreachable') }
  const body = Buffer.from(await upstream.arrayBuffer())
  if (body.length > MAX_PROXY_BYTES) {
    sendJson(response, 502, { ok: false, error: 'chart_response_too_large' })
    return
  }
  sendBytes(response, upstream.status, body, 'application/json; charset=utf-8')
}

async function readRequestBody(request: IncomingMessage): Promise<Buffer> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of request) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    size += buffer.length
    if (size > MAX_PROXY_BYTES) throw new Error('request_too_large')
    chunks.push(buffer)
  }
  return Buffer.concat(chunks)
}

function sendJson(response: ServerResponse, status: number, value: unknown, head = false): void {
  const body = Buffer.from(JSON.stringify(value))
  sendBytes(response, status, body, 'application/json; charset=utf-8', head)
}

function sendBytes(response: ServerResponse, status: number, body: Buffer, contentType: string, head = false): void {
  response.writeHead(status, {
    'Content-Type': contentType,
    'Content-Length': String(body.length),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  })
  response.end(head ? undefined : body)
}
