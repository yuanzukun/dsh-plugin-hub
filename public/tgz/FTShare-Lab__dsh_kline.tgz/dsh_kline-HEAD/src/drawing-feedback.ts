/** Object-API observations, not pixel verification or a trading conclusion. */
import { drawingInventory } from './chart-observation.ts'
import { fibonacciOverlayPoints } from './fibonacci.ts'
import { polylineOverlayPoints } from './labeled-polyline.ts'
import { chartAnnotationText } from './chart-annotations.ts'

export const FEEDBACK_KINDS=['horizontal_line','trend_line','channel','rectangle','fibonacci_retracement','labeled_polyline','text_annotation','number_annotation','icon_annotation','series_line','price_band','price_sticks','price_pattern','nine_count']
export const FEEDBACK_STATUSES=['created','hidden','removed','failed','unknown']
export const FEEDBACK_REASONS=['overlay_registered','period_mismatch','anchors_not_loaded','outside_time_viewport',
  'invalid_geometry','overlay_missing','overlay_mismatch','overlay_api_unavailable','overlay_lookup_failed','snapshot_outside_loaded_history',
  'overlay_removed','overlay_still_present','context_not_ready','application_rolled_back','rollback_unknown','creation_failed',
  'indicator_registered','indicator_removed','indicator_missing','indicator_still_present','indicator_api_unavailable']
const PHASES=['current','applied','rolled_back','rollback_unknown']
const STATUS_REASONS:any={created:['overlay_registered','outside_time_viewport','indicator_registered'],hidden:['period_mismatch','anchors_not_loaded','snapshot_outside_loaded_history'],
  removed:['overlay_removed','indicator_removed'],failed:['invalid_geometry','overlay_missing','overlay_mismatch','overlay_still_present','creation_failed','indicator_missing','indicator_still_present'],
  unknown:['overlay_api_unavailable','overlay_lookup_failed','overlay_mismatch','context_not_ready','application_rolled_back','rollback_unknown','indicator_api_unavailable']}
function empty(status:string) {return {schema_version:1,report_status:status,evidence_scope:'chart_object_api',render_verified:false,pixel_verified:false,items:[]}}
function timeRangeOverlap(points:any[], first:number|undefined, last:number|undefined):boolean|null {
  if(!first || !last || !points.length)return null
  const times=points.map(point=>point.timestamp/1000)
  return Math.max(...times)>=first && Math.min(...times)<=last
}
export function sanitizeDrawingFeedback(raw:any, allowed:any[]):any {
  if(raw==null)return empty('not_reported')
  if(['not_reported','invalid'].includes(raw.report_status))return empty(raw.report_status)
  try {
    if(raw.schema_version!==1 || !PHASES.includes(raw.phase) || !Array.isArray(raw.items) || raw.items.length>360)throw Error('invalid_report')
    const objects=new Map(allowed.map(d=>[d.id,d.kind])), seen=new Set<string>()
    const items=raw.items.map((item:any)=>{
      if(typeof item.id!=='string' || !item.id || item.id.length>256 || objects.get(item.id)!==item.kind || seen.has(item.id)
        || !FEEDBACK_KINDS.includes(item.kind) || !FEEDBACK_STATUSES.includes(item.status) || !FEEDBACK_REASONS.includes(item.reason)
        || !STATUS_REASONS[item.status].includes(item.reason)
        || !['unknown','outside_time_viewport','not_applicable'].includes(item.visibility)
        || (item.time_range_overlap!=null && typeof item.time_range_overlap!=='boolean'))throw Error('invalid_item')
      if((item.reason==='outside_time_viewport')!==(item.visibility==='outside_time_viewport'))throw Error('invalid_visibility')
      seen.add(item.id)
      return {id:item.id,kind:item.kind,status:item.status,reason:item.reason,visibility:item.visibility,
        outside_loaded_price_envelope:item.outside_loaded_price_envelope===true,
        time_range_overlap:typeof item.time_range_overlap==='boolean' ? item.time_range_overlap : null}
    })
    if(seen.size!==objects.size)throw Error('incomplete_report')
    const evidence_scope=['chart_object_api','indicator_registry','mixed_chart_api_and_indicator_registry'].includes(raw.evidence_scope)
      ? raw.evidence_scope : 'chart_object_api'
    return {...empty('reported'),phase:raw.phase,evidence_scope,items}
  } catch {return empty('invalid')}
}

function expectedOverlay(command:any, rows:any[], interval:string, times:Set<number>):any {
  const types:any={DRAW_HORIZONTAL_LINE:['ftvHorizontalLine','agentHorizontalLines'],DRAW_AGENT_TREND_LINE:['ftvTrendLine','agentTrendLines'],
    DRAW_AGENT_CHANNEL:['ftvAgentChannel','agentChannels'],DRAW_AGENT_RECTANGLE:['ftvAgentRectangle','agentRectangles'],
    DRAW_AGENT_FIBONACCI:['ftvAgentFibonacci','agentFibonacci'],DRAW_AGENT_POLYLINE:['ftvAgentPolyline','agentPolylines'],
    DRAW_AGENT_ANNOTATION:['ftvAgentAnnotation','agentAnnotations']}
  const point=(p:any)=>({timestamp:Number(p?.time)*1000,value:Number(p?.price)})
  const type=command.type
  if(['DRAW_AGENT_CHANNEL','DRAW_AGENT_RECTANGLE','DRAW_AGENT_FIBONACCI','DRAW_AGENT_POLYLINE','DRAW_AGENT_ANNOTATION'].includes(type) && command.interval!==interval)return {skip:'period_mismatch'}
  let points:any[], sourceTimes:number[]=[]
  if(type==='DRAW_HORIZONTAL_LINE') points=[{timestamp:rows.at(-1)?.time*1000,value:Number(command.price)}]
  else if(type==='DRAW_AGENT_ANNOTATION') {
    try {const clean={...command};points=[{timestamp:clean.time*1000,value:clean.price}];sourceTimes=[clean.time];chartAnnotationText(clean)}
    catch{return {failure:'invalid_geometry'}}
  }
  else if(type==='DRAW_AGENT_POLYLINE') {
    try {points=polylineOverlayPoints(command);sourceTimes=command.points.map((p:any)=>p.time)}catch{return {failure:'invalid_geometry'}}
  } else if(type==='DRAW_AGENT_FIBONACCI') {
    sourceTimes=[command.from?.time,command.to?.time]
    try {points=fibonacciOverlayPoints(command)}catch{return {failure:'invalid_geometry'}}
  } else if(type==='DRAW_AGENT_RECTANGLE') {
    sourceTimes=[command.start_time,command.end_time]
    points=[{timestamp:command.start_time*1000,value:command.upper_price},{timestamp:command.end_time*1000,value:command.lower_price}]
    if(!(command.start_time<command.end_time && command.lower_price>0 && command.lower_price<command.upper_price))return {failure:'invalid_geometry'}
  } else {
    sourceTimes=[command.from?.time,command.to?.time,...(type==='DRAW_AGENT_CHANNEL' ? [command.parallel?.time] : [])]
    if(!(command.from?.time<command.to?.time))return {failure:'invalid_geometry'}
    points=type==='DRAW_AGENT_CHANNEL' ? [command.upper?.from,command.upper?.to,command.lower?.from,command.lower?.to].map(point)
      : [command.from,command.to].map(point)
    if(type==='DRAW_AGENT_CHANNEL' && (command.geometry_basis!=='candle_index_linear_price'
      || !command.parallel || command.parallel.time<command.from.time || command.parallel.time>command.to.time))return {failure:'invalid_geometry'}
  }
  if(points.some(p=>!Number.isFinite(p.timestamp) || !Number.isFinite(p.value) || p.value<=0))return {failure:'invalid_geometry'}
  if(sourceTimes.some(time=>!times.has(time)))return {skip:'anchors_not_loaded'}
  return {name:types[type][0],group:types[type][1],points}
}

export function collectDrawingFeedback(payload:any, context:any, chart:any, previous:any[]=[], phase='current'):any {
  const commands=payload?.chartCommands ?? [], inventory=drawingInventory(payload ?? {})
  const after=new Set(inventory.map(d=>d.id)), before=drawingInventory({chartCommands:previous,interval:payload?.interval})
  const deleted=before.filter(d=>!after.has(d.id)), rows=context?.candles ?? []
  const times=new Set<number>(rows.map((r:any)=>r.time))
  const ready=context?.state==='ready' && rows.length>0
  let canRead=false
  try {canRead=typeof chart?.getOverlayById==='function'}catch {}
  const lookup=(id:string)=>{try{return {value:chart.getOverlayById(id)}}catch{return {error:true}}}
  const viewport=context?.visible_range
  const first=viewport?.available && rows[viewport.index_from]?.time
  const last=viewport?.available && viewport.index_to_exclusive>viewport.index_from && rows[viewport.index_to_exclusive-1]?.time
  const low=rows.length ? Math.min(...rows.map((r:any)=>r.low)) : NaN, high=rows.length ? Math.max(...rows.map((r:any)=>r.high)) : NaN
  const items=inventory.map((drawing:any)=>{
    const cmd=commands.find((c:any)=>c.id===drawing.id), item:any={id:drawing.id,kind:drawing.kind,status:'unknown',
      reason:'context_not_ready',visibility:'unknown',outside_loaded_price_envelope:false,time_range_overlap:null}
    if(!ready)return item
    if(phase==='rolled_back' || phase==='rollback_unknown') {
      item.reason=phase==='rolled_back' ? 'application_rolled_back' : 'rollback_unknown';return item
    }
    if(['price_pattern','nine_count'].includes(drawing.kind)) {
      if(cmd.interval!==(context.ui_interval || context.interval)) {
        item.status='hidden';item.reason='period_mismatch';item.visibility='not_applicable';return item
      }
      const loaded= drawing.kind==='nine_count' ? (cmd.marks ?? []).every((m:any)=>times.has(m.time))
        : (cmd.pattern?.anchors ?? []).every((a:any)=>times.has(a.time))
          && (cmd.pattern?.type!=='platform' || (times.has(cmd.pattern?.box?.start_time) && times.has(cmd.pattern?.box?.end_time)))
      if(!loaded) {item.status='hidden';item.reason='snapshot_outside_loaded_history';item.visibility='not_applicable';return item}
      const registry=chart?.__dshPatternGroupRegistry
      if(!(registry instanceof Map)) {item.reason='overlay_api_unavailable';return item}
      item.status=registry.get(drawing.id)===cmd.geometry_hash ? 'created' : 'failed'
      item.reason=item.status==='created' ? 'overlay_registered' : 'overlay_missing'
      return item
    }
    if(['series_line','price_band','price_sticks'].includes(drawing.kind)) {
      if(cmd.interval!==(context.ui_interval || context.interval)) {
        item.status='hidden';item.reason='period_mismatch';item.visibility='not_applicable';return item
      }
      const registry=drawing.kind==='series_line' ? chart?.__dshSeriesLineRegistry
        : drawing.kind==='price_band' ? chart?.__dshPriceBandRegistry : chart?.__dshPriceSticksRegistry
      if(!(registry instanceof Map)) {item.reason='indicator_api_unavailable';return item}
      item.status=registry.get(drawing.id)===(drawing.kind==='series_line' ? cmd.series_hash
        : drawing.kind==='price_band' ? cmd.band_hash : cmd.sticks_hash) ? 'created' : 'failed'
      item.reason=item.status==='created' ? 'indicator_registered' : 'indicator_missing'
      return item
    }
    const expected=expectedOverlay(cmd,rows,context.ui_interval || context.interval,times)
    const prices=expected.points?.map((p:any)=>p.value) ?? []
    item.outside_loaded_price_envelope=prices.some((p:number)=>p<low || p>high)
    if(!canRead) {item.reason='overlay_api_unavailable';return item}
    const observed=lookup(drawing.id)
    if(observed.error){item.reason='overlay_lookup_failed';return item}
    if(expected.skip) {
      item.status=observed.value ? 'unknown' : 'hidden';item.reason=observed.value ? 'overlay_mismatch' : expected.skip
      item.visibility='not_applicable';return item
    }
    if(expected.failure) {item.status='failed';item.reason=expected.failure;return item}
    item.time_range_overlap=drawing.kind==='horizontal_line' ? (first && last ? true : null)
      : timeRangeOverlap(expected.points,first,last)
    if(!observed.value){item.status='failed';item.reason='overlay_missing';return item}
    const overlay=observed.value
    let same=false
    try {
      const actual=overlay.points
      same=overlay.id===drawing.id && overlay.name===expected.name && overlay.groupId===expected.group && Array.isArray(actual)
        && actual.length===expected.points.length && actual.every((p:any,i:number)=>p.timestamp===expected.points[i].timestamp
          && Number.isFinite(p.value) && Math.abs(p.value-expected.points[i].value)<=Math.max(1,Math.abs(p.value))*1e-10)
        && overlay.extendData?.label===(cmd.label || '') && overlay.extendData?.colorName===(cmd.color || 'info')
        && (drawing.kind!=='channel' || overlay.extendData?.showMidline===(cmd.show_midline!==false))
        && (drawing.kind!=='rectangle' || overlay.extendData?.showFill===(cmd.show_fill!==false))
        && (drawing.kind!=='fibonacci_retracement' || JSON.stringify(overlay.extendData?.levels)===JSON.stringify(cmd.levels))
        && (drawing.kind!=='labeled_polyline' || JSON.stringify(overlay.extendData?.pointLabels)===JSON.stringify(cmd.points.map((p:any)=>p.label)))
        && (!['text_annotation','number_annotation','icon_annotation'].includes(drawing.kind)
          || overlay.extendData?.annotationKind===cmd.kind && (cmd.kind==='icon_annotation'
            ? overlay.extendData?.annotationIcon===cmd.icon : overlay.extendData?.text===chartAnnotationText(cmd)))
    } catch {item.reason='overlay_lookup_failed';return item}
    item.status=same ? 'created' : 'failed';item.reason=same ? 'overlay_registered' : 'overlay_mismatch'
    if(same && item.time_range_overlap===false){item.visibility='outside_time_viewport';item.reason='outside_time_viewport'}
    return item
  })
  for(const drawing of deleted) {
    if(phase==='rolled_back' || phase==='rollback_unknown') {
      items.push({id:drawing.id,kind:drawing.kind,status:'unknown',reason:phase==='rolled_back' ? 'application_rolled_back' : 'rollback_unknown',
        visibility:'not_applicable',outside_loaded_price_envelope:false});continue
    }
    if(!ready) {
      items.push({id:drawing.id,kind:drawing.kind,status:'unknown',reason:'context_not_ready',
        visibility:'not_applicable',outside_loaded_price_envelope:false});continue
    }
    if(['price_pattern','nine_count'].includes(drawing.kind)) {
      const registry=chart?.__dshPatternGroupRegistry
      items.push({id:drawing.id,kind:drawing.kind,status:!(registry instanceof Map)?'unknown':registry.has(drawing.id)?'failed':'removed',
        reason:!(registry instanceof Map)?'overlay_api_unavailable':registry.has(drawing.id)?'overlay_still_present':'overlay_removed',
        visibility:'not_applicable',outside_loaded_price_envelope:false});continue
    }
    if(['series_line','price_band','price_sticks'].includes(drawing.kind)) {
      const registry=drawing.kind==='series_line' ? chart?.__dshSeriesLineRegistry
        : drawing.kind==='price_band' ? chart?.__dshPriceBandRegistry : chart?.__dshPriceSticksRegistry
      items.push({id:drawing.id,kind:drawing.kind,status:!(registry instanceof Map) ? 'unknown' : registry.has(drawing.id) ? 'failed' : 'removed',
        reason:!(registry instanceof Map) ? 'indicator_api_unavailable' : registry.has(drawing.id) ? 'indicator_still_present' : 'indicator_removed',
        visibility:'not_applicable',outside_loaded_price_envelope:false});continue
    }
    const observed=canRead ? lookup(drawing.id) : {error:true}
    items.push({id:drawing.id,kind:drawing.kind,status:observed.error ? 'unknown' : observed.value ? 'failed' : 'removed',
      reason:observed.error ? (canRead ? 'overlay_lookup_failed' : 'overlay_api_unavailable') : observed.value ? 'overlay_still_present' : 'overlay_removed',visibility:'not_applicable',
      outside_loaded_price_envelope:false})
  }
  const hasSeries=items.some((item:any)=>['series_line','price_band','price_sticks'].includes(item.kind)),hasOverlay=items.some((item:any)=>!['series_line','price_band','price_sticks'].includes(item.kind))
  return {schema_version:1,phase,evidence_scope:hasSeries ? hasOverlay ? 'mixed_chart_api_and_indicator_registry' : 'indicator_registry' : 'chart_object_api',
    render_verified:false,pixel_verified:false,items}
}
