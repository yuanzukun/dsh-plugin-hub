import type { BetterSidebarService } from 'dsh-better-sidebar'
import { KLINE_TAB_ID } from './sidebar-integration.ts'

export const defaultTabKey = (sessionId: string) => `dsh-kline:default-tab:v1:${sessionId}`

// Once per conversation, add an entry without expanding the panel or taking
// the user's active tab. A persisted receipt also respects later manual close.
export function installDefaultKlineTabs(service: BetterSidebarService, storage?: Pick<Storage, 'getItem' | 'setItem'>): () => void {
  if (!service.features?.includes('stateSubscription') || typeof service.getSnapshot !== 'function'
    || typeof service.subscribeState !== 'function' || typeof service.activateTab !== 'function'
    || typeof service.isTabEnabled !== 'function') return () => {}
  let stopped = false, pending = false
  const handled = new Set<string>()
  try { storage ??= globalThis.localStorage } catch { /* In-memory fallback for blocked storage. */ }
  const schedule = () => {
    if (stopped || pending) return
    pending = true
    queueMicrotask(() => {
      pending = false
      if (stopped) return
      try {
        const {sessionId, state} = service.getSnapshot()
        if (!sessionId || !state || handled.has(sessionId) || !service.isTabEnabled(KLINE_TAB_ID)) return
        const key = defaultTabKey(sessionId)
        try { if (storage?.getItem(key) === '1') {handled.add(sessionId); return} } catch {}
        // Better Sidebar 0.19 delegates the right sidebar to DSH itself.
        // Plugin tabs now live only in the bottom workbench, so do not read
        // the old private `splits` / `floats` layout fields here.
        const nodes: unknown[] = [state.bottomSplits]
        const seen = new Set<object>()
        let exists = false, previous: string | undefined
        while (nodes.length) {
          const value = nodes.pop()
          if (!value || typeof value !== 'object' || seen.has(value)) continue
          seen.add(value)
          const node = value as Record<string, any>
          if (node.kind === 'split' && Array.isArray(node.children)) nodes.push(...node.children)
          if (!Array.isArray(node.tabs)) continue
          exists ||= node.tabs.some((tab: any) => tab?.type === KLINE_TAB_ID)
          if (node.id === state.activePane && node.tabs.some((tab: any) => tab?.id === node.active)) previous = node.active
        }
        // Mark before notifying the host to avoid re-entrant duplicate opens.
        handled.add(sessionId)
        if (!exists) {
          service.openTab({type:KLINE_TAB_ID}, {sessionId})
          // Public openTab activates the inserted tab. Restore the prior tab
          // synchronously, before React paints, without touching panel geometry.
          if (previous && service.getSnapshot().sessionId === sessionId) service.activateTab(previous, {sessionId})
        }
        try { storage?.setItem(key, '1') } catch {}
      } catch { /* Optional default entry must not block chart/plugin startup. */ }
    })
  }
  let unsubscribe: (() => void) | undefined
  try { unsubscribe = service.subscribeState(schedule) } catch {}
  schedule()
  return () => { stopped = true; try {unsubscribe?.()} catch {} }
}
