// The host's session store is the identity authority. Never inspect DOM titles
// or scan another conversation for a chart reference.
export interface ChartReference { session: string; order: number; recovery?: boolean; recoverySourceSessions?: string[] }
export interface Observable<T> {
  getSnapshot(): T
  subscribe(listener: () => void): () => void
}
export interface ConversationSnapshot { nodes?: readonly any[] }
export interface SessionEventWindow { entries: readonly { type: string; event: any }[] }
export interface SessionListSnapshot {
  // DSH 0.1.x exposes the selected conversation directly.
  current?: string
  // DSH 0.2.x keeps the catalog separate from selection. The main view's
  // retention identifies its active Session without inspecting the DOM.
  byId?: Record<string, { retainedBy?: { mainView?: number } }>
}
export interface Sessions {
  list: Observable<SessionListSnapshot>
  binding(id: string): {
    session: Observable<ConversationSnapshot>
    eventSource?: Observable<SessionEventWindow>
  } | undefined
}

/** Resolve one active conversation across the two public DSH session shapes. */
export function currentConversationId(snapshot: SessionListSnapshot): string | undefined {
  if (typeof snapshot.current === 'string' && snapshot.current.length > 0) return snapshot.current
  const active = Object.entries(snapshot.byId ?? {})
    .filter(([, row]) => typeof row?.retainedBy?.mainView === 'number' && row.retainedBy.mainView > 0)
    .map(([id]) => id)
  // More than one main-view holder is ambiguous: never guess an owner.
  return active.length === 1 ? active[0] : undefined
}

// Harness 0.1.2 moved rendered nodes out of SessionSnapshot. Consume the
// owning session's public event window, independent of Chat/Trajectory UI.
// Match results to invocation starts so a slow old call cannot steal the chart.
export function latestChartFromEvents(entries: SessionEventWindow['entries']): ChartReference | undefined {
  const calls = new Map<string, { name: string; time: number }>()
  const nodes: any[] = []
  for (const entry of entries) {
    if (entry.type !== 'event') continue
    const event = entry.event
    const data = event?.data
    if (event?.type === 'tool/call' && typeof data?.callId === 'string') {
      calls.set(data.callId, { name: data.name, time: event.time })
    } else if (event?.type === 'tool/code-dispatch-start' && typeof data?.subCallId === 'string') {
      calls.set(data.subCallId, { name: data.name, time: event.time })
    }
  }
  for (const entry of entries) {
    if (entry.type !== 'event') continue
    const event = entry.event
    const data = event?.data
    if (event?.type === 'tool/result') {
      for (const block of data?.message?.content ?? []) {
        if (block?.type !== 'tool-result') continue
        const call = calls.get(block.toolCallId)
        if (!call) continue // Never guess a truncated call's identity.
        nodes.push({ kind: 'tool-result', call, callTime: call.time, content: block.content, isError: block.isError || !!data.error })
      }
    } else if (event?.type === 'tool/code-dispatch') {
      const call = calls.get(data?.subCallId)
      if (!call || call.name !== data.name) continue
      nodes.push({ kind: 'tool-result', call, callTime: call.time, content: data.content, isError: data.isError })
    }
  }
  return latestChart(nodes)
}

export function latestChart(nodes: readonly any[]): ChartReference | undefined {
  let latest: ChartReference | undefined
  const visit = (node: any) => {
    for (const child of node.subCalls ?? []) visit(child)
    if (node.kind !== 'tool-result' || node.isError) return
    if (!/^mcp__dsh[_-]kline__(?:analyze_kline(?:_rows)?|(?:create|update|delete)_(?:(?:horizontal|trend)_line|channel|rectangle))(?:_[a-f0-9]+)?$/.test(node.call?.name ?? '')) return
    const serialized = JSON.stringify(node.content ?? [])
    const match = serialized.match(/chart_session(?:\\?"\s*:\s*\\?"|=)([A-Za-z0-9_-]{32})/)
    if (!match) return
    const order = Number(node.callTime ?? node.time ?? node.seq ?? 0)
    if (!latest || order >= latest.order) latest = { session: match[1], order }
  }
  for (const node of nodes) visit(node)
  return latest
}

export function chartStorageKey(conversationId: string): string {
  return `dsh-kline:conversation:${encodeURIComponent(conversationId)}`
}
