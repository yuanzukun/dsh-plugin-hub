import { useCallback, useContext, useEffect, useState, useSyncExternalStore } from 'react'
import type { BetterSidebarService, TabComponentProps } from 'dsh-better-sidebar'
import { currentConversationId, type Sessions } from './conversation'
import { useChartReference } from './chart-session-resolver'
import { liveChartFor } from './chart-handoff'
import { NativeKlineApp, StandaloneKlineApp, standaloneWorkspaceScope } from './KlineContent'
import { InterfaceContext, readAutoOpen } from './mode-preferences'
import { KLINE_TAB_ID, klineTabTitle, migrateKlineTabTitle } from './sidebar-integration'
import { installDefaultKlineTabs } from './default-tab'

/** The chart itself, shared by every host tab: Better Sidebar and the native one. */
export function KlineTabContent({ sessions, conversationId, visible = true }: { sessions: Sessions; conversationId?: string; visible?: boolean }) {
  // Better Sidebar preserves a tab and its previous scope on the host's
  // New Session screen. Never promote an already-present chart from that
  // scope: accept a live result or its same-conversation tab handoff, never
  // browser-cached history. New conversations still start on the Market page.
  const [liveReference, setLiveReference] = useState<ReturnType<typeof useChartReference>>(() => liveChartFor(sessions, conversationId))
  const onNewChart = useCallback((reference: NonNullable<ReturnType<typeof useChartReference>>) => {
    setLiveReference(reference)
  }, [])
  const reference = useChartReference(sessions, conversationId, onNewChart)
  const selectedReference = liveReference ?? (reference?.recovery ? reference : undefined)
  const onIdentity = useCallback(() => {}, [])
  return selectedReference
    ? <NativeKlineApp key={selectedReference.session} session={{ ok: true, ...selectedReference, published_at: selectedReference.order }} conversationId={conversationId ?? ''} ownerConversationId={conversationId} visible={visible} onIdentity={onIdentity} />
    : <StandaloneKlineApp conversationId={standaloneWorkspaceScope(conversationId)} ownerConversationId={conversationId} visible={visible} onIdentity={onIdentity} />
}
function AutoOpen({ service, sessions, conversationId }: { service: BetterSidebarService; sessions: Sessions; conversationId: string }) {
  const onNewChart = useCallback((reference: { session: string }) => {
    if (readAutoOpen()) service.openTab({ type: KLINE_TAB_ID }, { sessionId: conversationId })
  }, [service, conversationId])
  useChartReference(sessions, conversationId, onNewChart)
  return null
}
function KlineTabFrame({service, sessions, scope, tab, visible}: TabComponentProps & {service: BetterSidebarService; sessions: Sessions}) {
  const interfaceState = useContext(InterfaceContext)
  const sidebar = useSyncExternalStore(
    listener => service.subscribeState(listener),
    () => service.getSnapshot(),
  )
  // A single-instance Better Sidebar tab retains its last scope during the
  // host's "New Session" screen.  The public sidebar snapshot deliberately
  // has no active session there, so it is the authoritative signal: start the
  // Market launcher until a real conversation becomes active.
  const conversationId = sidebar.sessionId === scope.sessionId ? scope.sessionId : undefined
  useEffect(() => migrateKlineTabTitle(service, tab, scope.sessionId), [service, tab.id, tab.title, scope.sessionId])
  return (
    <div data-dsh-kline-tab="" style={{width:'100%', height:'100%', minHeight:0, overflow:'hidden'}}>
      {visible && interfaceState.mode === 'better-sidebar'
        ? <KlineTabContent key={conversationId ?? 'launcher'} conversationId={conversationId} sessions={sessions} />
        : visible && <div role="status" style={{padding:16}}>当前使用经典 K 线侧栏；如需在此处打开图表，请在经典侧栏右上角「UI」切换为原生 Tab。</div>}
    </div>
  )
}
export function BetterSidebarBridge({ service, sessions }: { service: BetterSidebarService; sessions: Sessions }) {
  const interfaceState = useContext(InterfaceContext)
  const list = useSyncExternalStore(listener => sessions.list.subscribe(listener), () => sessions.list.getSnapshot())
  const activeConversation = currentConversationId(list)
  const isNativeTabMode = interfaceState.mode === 'better-sidebar'
  useEffect(() => {
    const dispose = service.registerTab({
      id: KLINE_TAB_ID,
      title: klineTabTitle(),
      order: 120,
      single: true,
      component: (props: TabComponentProps) => (
        <InterfaceContext.Provider value={interfaceState}>
          <KlineTabFrame {...props} service={service} sessions={sessions} />
        </InterfaceContext.Provider>
      ),
    })
    // The tab is always registered so Classic mode retains a discoverable
    // native entry. Only the explicitly chosen native-tab mode may insert or
    // auto-open it for the user.
    const stopDefaults = isNativeTabMode ? installDefaultKlineTabs(service) : () => {}
    return () => { stopDefaults(); dispose() }
  }, [service, sessions, interfaceState, isNativeTabMode])
  return isNativeTabMode && activeConversation
    ? <AutoOpen key={activeConversation} service={service} sessions={sessions} conversationId={activeConversation} />
    : null
}
