import { useContext, useEffect, useRef, useState } from 'react'
import { mountKlineView } from './generated-view'
import { InterfaceContext } from './mode-preferences'
import { onboardingKind, acknowledgeOnboarding } from './ui-onboarding'
import { klineHostDataset, sameSymbol, type KlineEmbedApi, type KlineHostProps } from './embed'

export interface ChartSession {
  ok: true
  session: string
  symbol?: string
  name?: string
  published_at: number
  recovery?: boolean
}

export interface ChartIdentity {
  symbol?: string
  name?: string
}

// The chart view can load data itself through the loopback tool proxy.  It
// therefore does not need an AI-produced chart session to present its search
// workspace; only AI-produced snapshots need the opaque session reference.
const STANDALONE_CHART_PAYLOAD = {
  ok: true,
  workspace_mode: 'launcher',
  // A new conversation starts at the Market page. Keep a dormant default
  // instrument so an explicit click on the empty Chart page has something
  // useful to open; launcher initialization itself must not load it.
  default_symbol: '000001.XSHG',
  default_name: '上证指数',
  symbol: '',
  name: '',
  interval: 'day',
  range_key: 'ytd',
  chartCommands: [],
}

export function standaloneChartSession(conversationId?: string): string {
  return `standalone:${conversationId ?? 'global'}`
}

export function standaloneWorkspaceScope(conversationId?: string): string {
  return `direct:${conversationId ?? 'global'}`
}

export function isSymbolLikeName(value: string | undefined, symbol: string | undefined): boolean {
  const text = String(value ?? '').trim()
  const normalizedSymbol = String(symbol ?? '').trim().toUpperCase()
  if (!text) return true
  if (normalizedSymbol && text.toUpperCase() === normalizedSymbol) return true
  const bareSymbol = normalizedSymbol.split('.', 1)[0]
  return text.toUpperCase() === bareSymbol
}


declare global {
  interface Window {
    klinecharts?: any
    __dshKlineVendorPromise?: Promise<any>
    __dshKlineVwapRegistered?: boolean
  }
}

export function NativeKlineApp({ session, conversationId, ownerConversationId, visible = true, onIdentity }: { session: ChartSession; conversationId: string; ownerConversationId?: string; visible?: boolean; onIdentity: (symbol?: string, name?: string) => void }) {
  const host = useRef<HTMLDivElement>(null)
  const visibility = useRef(visible); visibility.current = visible
  const contextNotice = useRef<() => void>(() => {})
  useEffect(() => contextNotice.current(), [visible])
  const interfaceMode = { ...useContext(InterfaceContext), onboardingKind, acknowledgeOnboarding }
  const [error, setError] = useState('')

  useEffect(() => {
    let active = true
    const controller = new AbortController()
    let dispose: (() => void) | undefined
    Promise.all([
      fetch(session.recovery ? `/dsh-kline/recovery?conversation=${encodeURIComponent(ownerConversationId ?? '')}`
        : `/dsh-kline/data?session=${encodeURIComponent(session.session)}`, { cache: 'no-store', signal: controller.signal }).then(response => response.json()),
      loadKlinecharts(),
    ]).then(([result, klinecharts]) => {
      if (!active || !host.current) return
      if (!result?.ok || !result?.payload) throw new Error(result?.message || '图表会话不可用')
      if(session.recovery && (result.session!==session.session || result.conversation_id!==ownerConversationId)) throw new Error('图表恢复来源已变化，请重新打开当前对话。')
      const root = host.current.shadowRoot || host.current.attachShadow({ mode: 'open' })
      dispose = mountKlineView(root, result.payload, { klinecharts, conversationId, ownerConversationId, isVisible: () => visibility.current,
        onContextPublisher: (publisher: {notify: () => void}) => { contextNotice.current = publisher.notify }, chartSession: session.session, onIdentity, interfaceMode })
    }).catch(reason => active && setError(String(reason?.message || reason)))
    return () => {
      active = false
      controller.abort()
      dispose?.()
    }
  }, [session.session, conversationId])

  return (
    <div className="dsh-kline-native-host" style={{ width: '100%', height: '100%', overflow: 'hidden' }} ref={host}>
      {error && <div className="dsh-kline-error" role="alert">{error}</div>}
    </div>
  )
}

// Host-facing contract lives in ./embed so tests can check the no-host defaults
// without loading React or the generated view.
export type { KlineChrome, KlineHostProps, KlineEmbedApi } from './embed'

export function StandaloneKlineApp({ conversationId, ownerConversationId, visible = true, onIdentity, embedded = false, chrome = 'full', theme, symbol, name }: {
  conversationId: string
  ownerConversationId?: string
  visible?: boolean
  onIdentity: (symbol?: string, name?: string) => void
} & KlineHostProps) {
  const host = useRef<HTMLDivElement>(null)
  const visibility = useRef(visible); visibility.current = visible
  const contextNotice = useRef<() => void>(() => {})
  // The theme is read once at mount (the runtime needs it before first paint);
  // later changes go through the bridge, so they never remount the view.
  const themeAtMount = useRef(theme)
  useEffect(() => contextNotice.current(), [visible])
  const interfaceMode = { ...useContext(InterfaceContext), onboardingKind, acknowledgeOnboarding }
  const [error, setError] = useState('')
  const [ready, setReady] = useState(false)
  const bridge = useRef<KlineEmbedApi | null>(null)

  useEffect(() => {
    let active = true
    let dispose: (() => void) | undefined
    setReady(false)
    bridge.current = null
    loadKlinecharts().then(klinecharts => {
      if (!active || !host.current) return
      const root = host.current.shadowRoot || host.current.attachShadow({ mode: 'open' })
      dispose = mountKlineView(root, STANDALONE_CHART_PAYLOAD, {
        klinecharts,
        conversationId,
        ownerConversationId,
        isVisible: () => visibility.current,
        onContextPublisher: (publisher: {notify: () => void}) => { contextNotice.current = publisher.notify },
        chartSession: standaloneChartSession(conversationId),
        onIdentity,
        interfaceMode,
        embedded,
        theme: themeAtMount.current,
        onReady: (api: KlineEmbedApi) => { bridge.current = api; setReady(true) },
      })
    }).catch(reason => active && setError(String(reason?.message || reason)))
    return () => {
      active = false
      dispose?.()
    }
  }, [conversationId, onIdentity, embedded])

  // Follow an external selection once the view is live. A symbol the chart
  // already shows is skipped: the panel publishes its own selection back, and
  // that round trip through the host bus must not reopen the same instrument.
  useEffect(() => {
    if (!ready || symbol === undefined || symbol === '') return
    if (sameSymbol(bridge.current?.currentSymbol(), symbol)) return
    void bridge.current?.openSymbol(symbol, name).catch(() => {})
  }, [ready, symbol, name])

  // A host palette pins the chart theme; a change repaints without a remount.
  // No theme means "follow the host document", which is the old behaviour.
  useEffect(() => {
    if (!ready) return
    bridge.current?.setTheme(theme ?? 'host')
  }, [ready, theme])

  return (
    <div
      className="dsh-kline-native-host"
      {...klineHostDataset({ embedded, chrome })}
      style={{ width: '100%', height: '100%', overflow: 'hidden' }}
      ref={host}
    >
      {error && <div className="dsh-kline-error" role="alert">{error}</div>}
    </div>
  )
}

function loadKlinecharts(): Promise<any> {
  const loaded = () => typeof window.klinecharts?.init === 'function' ? window.klinecharts : undefined
  if (loaded()) return Promise.resolve(loaded())
  if (window.__dshKlineVendorPromise) return window.__dshKlineVendorPromise
  window.__dshKlineVendorPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script')
    script.src = '/dsh-kline/vendor/klinecharts.min.js'
    script.async = true
    script.dataset.dshKlineVendor = 'true'
    script.onload = () => loaded() ? resolve(loaded()) : reject(new Error('KLineCharts 已下载但没有正确初始化'))
    script.onerror = () => reject(new Error('KLineCharts 加载失败'))
    document.head.appendChild(script)
  }).catch(error => {
    window.__dshKlineVendorPromise = undefined
    document.querySelector('script[data-dsh-kline-vendor="true"]')?.remove()
    throw error
  })
  return window.__dshKlineVendorPromise
}
