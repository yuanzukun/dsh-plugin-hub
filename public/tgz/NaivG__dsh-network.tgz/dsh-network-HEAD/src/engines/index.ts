/**
 * dsh-network search engine registry — barrel + default registration.
 *
 * Usage:
 *
 *   import { defaultRegistry, registerDefaultEngines } from './engines/index.ts'
 *   registerDefaultEngines(defaultRegistry)
 *   const engines = defaultRegistry.resolve(['bing', 'duckduckgo'])
 *
 * Adding a new engine:
 *   1. Create `src/engines/<name>.ts` exporting a class implementing
 *      `SearchEngine`. Keep parsers pure (no I/O) so the engines stay
 *      unit-testable without network.
 *   2. Add `export * from './<name>.ts'` below.
 *   3. Add `new <Name>SearchEngine()` to `registerDefaultEngines`.
 *
 * Engines registered first become the chain head — keep the most
 * reliable one (Bing) at the top.
 */

export * from './types.ts'
export * from './header-profiles.ts'
export { BingSearchEngine } from './bing.ts'
export { DuckDuckGoSearchEngine } from './duckduckgo.ts'
export { BaiduSearchEngine } from './baidu.ts'
export {
  So360SearchEngine,
  SO360_ENGINE_ID,
  SO360_ORIGIN,
  SO360_ENDPOINT,
  SO360_BLOCKED_MARKER,
  buildSo360Url,
  countSo360RichCards,
  parseSo360Results,
} from './so360.ts'
export { GitHubSearchEngine, routeGithubIndexes } from './github.ts'
export { SearxngSearchEngine, SEARXNG_DEFAULT_ENDPOINT, SEARXNG_ENV, buildSearxngUrl, normalizeSearxngEndpoint } from './searxng.ts'
export { BraveSearchEngine, BRAVE_ENDPOINT, BRAVE_API_KEY_ENV, BRAVE_AUTH_HEADER, buildBraveUrl } from './brave.ts'
export {
  MojeekFreeSearchEngine,
  MOJEEK_FREE_ENGINE_ID,
  MOJEEK_FREE_ORIGIN,
  MOJEEK_FREE_ENDPOINT,
  MOJEEK_FREE_CHALLENGE_URL,
  MOJEEK_FREE_VERIFY_URL,
  MOJEEK_FREE_AUTH_HEADER,
  MOJEEK_FREE_COOKIE_ENV,
  MOJEEK_FREE_CHALLENGE_MARKER,
  MOJEEK_FREE_RESULTS_PER_PAGE,
  buildMojeekUrl,
  parseMojeekResults,
} from './mojeek-free.ts'
export {
  MojeekSearchEngine,
  MOJEEK_ENGINE_ID,
  MOJEEK_ENDPOINT,
  MOJEEK_API_KEY_ENV,
  buildMojeekApiUrl,
  parseMojeekApiResults,
} from './mojeek.ts'
export {
  TavilySearchEngine,
  TAVILY_ENGINE_ID,
  TAVILY_ENDPOINT,
  TAVILY_API_KEY_ENV,
  TAVILY_AUTH_HEADER,
  TAVILY_KEYLESS_HEADER,
  buildTavilyRequest,
  parseTavilyResults,
} from './tavily.ts'
// web_sitemap is the curated portal catalog used by the LLM to pick
// authoritative sources. It lives outside the engine registry (it is
// pure data, not a search backend) so we only re-export it from here
// for discoverability — engines themselves do not depend on it.
export * as WebSitemap from '../sitemap.js'

import { SearchEngineRegistry, type SearchEngine } from './types.ts'
import { BingSearchEngine } from './bing.ts'
import { DuckDuckGoSearchEngine } from './duckduckgo.ts'
import { BaiduSearchEngine } from './baidu.ts'
import { So360SearchEngine } from './so360.ts'
import { GitHubSearchEngine } from './github.ts'
import { SearxngSearchEngine } from './searxng.ts'
import { BraveSearchEngine } from './brave.ts'
import { MojeekFreeSearchEngine } from './mojeek-free.ts'
import { MojeekSearchEngine } from './mojeek.ts'
import { TavilySearchEngine } from './tavily.ts'

/** The process-wide registry. Call `registerDefaultEngines` at startup. */
export const defaultRegistry = new SearchEngineRegistry()

/**
 * Register Bing, DuckDuckGo, Baidu, 360搜索, GitHub, SearXNG, Brave,
 * Mojeek (free), Mojeek (official Search API) and Tavily as the search chain.
 *
 * The chain runs engines in registration order, so the most reliable (Bing)
 * goes first. Registration order is NOT the default chain — that is
 * `DEFAULT_SEARCH_ENGINES` in config.ts, which stops at Baidu.
 *
 * The two Mojeek engines are registered LAST on purpose: their credentials
 * are different (a cookie for `mojeek-free`, an API key for `mojeek`), but
 * they share a host and so should sit at the chain tail for the same reason
 * a fresh install must not touch mojeek.com unless explicitly added.
 *
 * Tavily sits at the very tail: every query is billed and the keyless tier
 * is rate-limited, so a fresh install must not hit api.tavily.com at all.
 *
 * Override the chain via `DSH_NETWORK_SEARCH_ENGINES` or the settings UI.
 */
export function registerDefaultEngines(registry: SearchEngineRegistry = defaultRegistry): readonly SearchEngine[] {
  const engines: SearchEngine[] = [
    new BingSearchEngine(),
    new DuckDuckGoSearchEngine(),
    new BaiduSearchEngine(),
    new So360SearchEngine(),
    new GitHubSearchEngine(),
    new SearxngSearchEngine(),
    new BraveSearchEngine(),
    new MojeekFreeSearchEngine(),
    new MojeekSearchEngine(),
    new TavilySearchEngine(),
  ]
  for (const e of engines) registry.register(e)
  return engines
}
