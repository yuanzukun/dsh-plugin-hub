# Project Overview (for AI Agent)

## Goal

Ship the `dsh-network` DeepSeek Harness plugin: it replaces the official
`tool-web` (`web_search` / `web_fetch`) and adds a free, keyless
`http_request` tool. The host keeps ONE persistent `dsh-network server`
child alive for its lifetime; every tool call is an HTTP round-trip to that
loopback server. The CLI does the network I/O and **server-side caches** any
body bigger than ~20 KB, so large results page through `cacheId` instead of
being truncated (handbook #717 — child-process stdout chunking is the
symptom, the server-side cache is the fix). `web_config` reads/patches the
same live config the browser UI edits, gated by a user-controlled safety
toggle the model can neither read nor set.

Everything user-facing (install, config fields, engine catalog, CLI
reference, code layout) lives in [`docs/`](docs/README.md). This file holds
only what you need to **change the code without breaking it**.

## Architecture

- **Hand-written host plugin** (`dsh/index.js`, plain ESM, no build). The
  entry owns only the contract exports (`name` / `inject`) and `apply()`; the
  rest is split by concern into `dsh/schemas.js`, `cli-runner.js`,
  `evidence.js`, `providers.js`, `tools.js`, `routes.js`,
  `config-summary.js`. It must stay hand-written — vite's lib mode silently
  replaces `node:*` with browser externals.
- **Loopback server-client** (`dsh/serverClient.js`). Exactly one persistent
  `node dist/cli.cjs server` child, spoken to over `127.0.0.1:<port>`; the
  server announces its port on stdout as `{"type":"ready","port":N}`.
  `ensure()` spawns it (eagerly from `apply()`), and if the child dies the
  next `invoke()` respawns it; `dispose()` POSTs `/shutdown`, then
  SIGTERM → SIGKILL after 1 s.
- **Server-side cache + routes** (`src/cache.ts`, `src/server.ts`):
  `POST /invoke` (one job + per-call env snapshot), `GET /content` (paging),
  `GET /health`, `POST /shutdown`. The cache dedups by
  `(fetch|format|url)` / `(http|method|url)`, evicts LRU at 48 entries /
  16 MB / 5-minute TTL, and degrades any body over the inline cap
  (20 000 chars) to a preview + `cacheId` + `contentLength` + `cacheSlice`.
- **Eager start + lifetime binding.** `apply()` calls `client.ensure()` so the
  first tool call doesn't pay the ~2 s cold start, and registers
  `ctx.effect(() => () => client.dispose())`. If dsh itself crashes, the
  server's stdin pipe closes and `stdinWatch` (`process.stdin.on('end'|'error')`)
  exits it.
- **Per-call env snapshot.** `configToEnv(config)` carries the host's LIVE
  config (engine order, timeouts, allowlist, GitHub token, SearXNG endpoint,
  engine keys, engine options, and the `web_download` workspace root) on every
  `/invoke`, so UI edits land on the next tool call with no server restart.
- **Vite SSR build for the CLI** (`dist/cli.cjs`, `vite.cli.config.ts`) so
  `node:*` imports stay Node-side. `src/server.ts` is dynamically imported by
  `src/cli.ts`, so it lands in a hashed chunk (`dist/server-*.cjs`) that the
  single-shot CLI never loads.
- **Undici + pinned dispatcher** for SSRF: every redirect hop is validated
  (URL parse → allowlist → DNS → private/reserved IP rejection) and pinned to
  one IP for the socket. No shelling out to `curl.exe` / `nslookup.exe`. The
  dispatcher pins the TLS **cipher list** to Firefox's — not the TLS
  **version**; see the invariant below.
- **Documents via officeparser** (`src/document.ts`). `client.ts` recognises a
  fixed MIME allowlist (PDF, OOXML, ODF, EPUB) and returns raw bytes, which
  `fetch.ts` pipes through `officeparser`'s `ast.to('md')`. Loaded via
  `await import` so tesseract.js stays out of the cold-start bundle. OCR is
  intentionally off.
- **Binary bytes exist, but only through `mode: 'bytes'`** (`src/download.ts`,
  web_download). `isBinaryContentType` still refuses them on every text path —
  a base64 blob would blow the inline cap and tell the model nothing. The ONE
  exception is `runClientFetch({ mode: 'bytes' })`: raw bytes for any content
  type, no charset decode, no `maxChars` clip, and `truncated` always `false`
  because `readBodyWithLimit` THROWS past `maxBytes` rather than returning a
  short read. It is a MODE on the existing transport, not a second fetch path,
  and that is the entire safety argument — the download inherits
  `assertSafeRemoteTarget` + the pinned dispatcher, so a file write gets the
  allowlist, the private-IP rejection and the same-domain redirect lock. A
  downloader with its own socket would be the one unfenced path in the plugin.
  Never grow one.
- **HTML → Markdown stays hand-written** (`src/html.ts`): real web pages need
  a nav/footer/cookie-banner pre-filter that officeparser's HTML input does
  not provide. officeparser is for binary documents, where that noise profile
  does not exist.
- **Feeds claim themselves by ROOT ELEMENT** (`src/feed.ts`, hand-written, no
  XML dependency). A `<rss>` / `<feed>` / `<rdf:RDF>` root renders as a feed;
  everything else — a `sitemap.xml`, an OPML export, a JS app shell — falls
  through to `htmlToMarkdown` untouched, so `renderFeed` returning `null` is
  the load-bearing part, not an error path. **The scanner must stay tolerant**:
  an unescaped `&`, an unclosed `<link>` and `dc:` / `content:` / `itunes:`
  namespaces are all normal in the wild, and a hard parse failure on a
  model-facing fetch is worse than two missing fields.
  - **Two caps, each reported in the output when it bites**: 8 000 chars per
    item body (clipped on a block boundary, never mid-sentence) and a 500-item
    render ceiling. There is deliberately NO whole-feed budget in server mode:
    the server already downloaded every byte, so the full render goes to the
    result cache — a dropped tail would cost a second GET against an origin
    that serves a DIFFERENT feed on the next request. `previewCutAt` — the end
    of the last complete item block under the inline cap — makes the preview a
    whole number of entries. `pickPreviewLen`
    applies that boundary with the same 40% anti-waste floor the body clipper
    uses, and it rides along on the cached body so a warm hit on the same URL
    previews identically. The single-shot CLI passes `maxTotalChars` and keeps
    the 20 000-char whole-feed budget, because there the body has to cross a
    stdout pipe with no cache behind it. `format: 'raw'` bypasses the
    renderer entirely.
  - The scanner keeps element content as an ORDERED list of text / CDATA /
    element parts, and splits a close tag's qualified name the same way the
    open tag's was. Comparing `</dc:date>` against a node whose `name` is
    `date` never matches, so the element keeps nesting and every sibling
    after it — including the next item — disappears into its text.
- **Version-locked CLI**: `serverClient.js` resolves `dist/cli.cjs` relative
  to the plugin's own URL; `DSH_NETWORK_CLI` overrides it for tests.
- **Cordis patch toppling** (`cordis.patch.yml`): pins both `web` seam
  providers to dsh-network and disables `tool-web`, so tool names never
  collide (the tools registry refuses duplicates).
- **Single responsibility**: this package owns live web (search + fetch +
  http + document parsing).

## Invariants — change these carefully

### The package name IS the browser plugin id

The package is published as **`@naivg/dsh-network`**. 

The dsh client module system keys the browser bundle by the installed manifest's `name`
field, verbatim and scope included (`@deepseek-ai/dsh-client-modules`
`exactPackageSpecifier` → `nearestPackage` → `graphRow(packageName, …)`). So
`@naivg/dsh-network` is load-bearing in exactly four places, and they must move
together:

1. `package.json` `"name"`.
2. `cordis.patch.yml` — the insert row's **`name:`** is the module specifier
   (the row's `id:` is a free-form loader alias, the same split
   `@deepseek-ai/dsh-web-app`'s own patch uses, so `id: dsh-network` stays).
3. Every `window.__ModuleLoader__.load({ id })` — the entry in
   `dsh/client.js` and each `dsh/client.<name>.js` chunk — plus the
   `require('@naivg/dsh-network')` those chunks re-bind the shared surface
   through. A chunk's registered module id is `<id>/<chunk>`, so a stale entry
   `id` makes `require.async('./client.*.js')` miss the table.
4. `dsh/index.js` `export const name`, kept equal to the package name.

Everything else deliberately keeps the SHORT name — the locale namespace, the
`settings.section` / `tool.call.toolview` slot ids, the `searchProvider` /
`fetchProvider` ids, the `/dsh-network/*` loopback routes, `~/.dsh/dsh-network.json`,
the `DSH_NETWORK_*` env vars, the `dsh-network` CLI binary, the `dshn-` CSS
prefix and the sidebar panel id. They are free-form strings, and renaming them
would break users' configs and open routes for no gain.

### Entity decoding is ONE helper, at the CLI boundary

`src/html-extract.ts` `decodeEntities` / `cleanHtmlText`, re-exported to the
engines as `cleanText`. Source markup is entity-encoded (a Bing date is
literally `Aug 19, 2026&nbsp;&#0183;&#32;DeepSeek`) and nothing downstream
can rescue a raw reference — the renderer prints `&nbsp;` as six characters
and the model reads it as content and reproduces it in its reply. Stripping
and decoding are therefore ONE step, and every text extraction (engine
titles/snippets, link labels, the visible-text pass, `htmlToMarkdown`'s final
pass) goes through the same table. The rules that are load-bearing:

- **One pass, or the escaped text re-enters as markup.** Each reference is
  resolved exactly once against the ORIGINAL string, so `&amp;lt;` yields
  `&lt;` and never a `<`. `htmlToMarkdown` decodes once at the very END,
  after `stripTags`, for that same reason.
- **In a feed, CDATA is literal and character data is not** (`src/feed.ts`).
  A `<![CDATA[…]]>` payload hands its `&amp;` to `htmlToMarkdown` raw and
  lets the ONE final pass decode it; escaped character data is
  `decodeEntities`-ed first and then converted. Decoding both, or neither,
  is what turns a feed summary into `&amp;`-laden noise or a literal `<p>`.
- **The whitespace pass runs even with no `&` in the string.** A fast path
  guarding on `includes('&')` silently skips U+00A0 normalization whenever
  the space is a raw character rather than an entity. The guard belongs on
  the reference pass only.
- **Unicode whitespace becomes a space, invisible characters are deleted**
  (`\u00a0` / `\u2000-\u200a` / `\u3000` → `' '`;
  `\u200b\u200c\u200d\u2060\ufeff\u00ad` → `''`), so `**&nbsp;a**` still
  renders bold and a zero-width space cannot hide inside a keyword.
  U+200E / U+200F are deliberately KEPT — they carry bidi intent, and
  dropping them flips reading order in the rendered card.
- **Unknown references stay visible** instead of being blanked, and numeric
  references outside the scalar range (surrogates, > U+10FFFF, `&#0;`) emit
  nothing rather than a lone surrogate that would break the UTF-8 encode.
- The table is a hand-curated ~130 lowercase names, NOT the full HTML5 set
  (2231 — the tail is math/emoji codepoints that never appear in result
  markup). Lookup lowercases first, so `&NBSP;` still decodes.
- The host half deliberately does NOT decode (`dsh/evidence.js` is a pure
  pass-through): a second decode would corrupt a snippet whose content IS an
  entity example. Mind this boundary when adding a format.
- `extractVisibleTextFromHtml` reads `<title>` BEFORE it drops `<head>`.

### Keyed engines and the credential chain

An engine declares `auth = { header, scheme, apiKeyEnv }` (Brave:
`X-Subscription-Token`; GitHub's Bearer token folds into the same map). The
CLI — never the engine — holds the secret: it resolves
`DSH_NETWORK_SEARCH_ENGINE_API_KEYS[engineId]` (a JSON map `configToEnv()`
packs into every `/invoke`), falls back to the engine's single-engine
`apiKeyEnv`, then to the legacy `DSH_NETWORK_GITHUB_TOKEN`, and injects the
header. Engines only ever see `hasApiKey`. With no key the CLI sends NO
request at all: it synthesizes a 401 body so "no credential" and "rejected
credential" classify on one code path.

The chain has FOUR hops, and they are only correct together:

```
browser dialog → commitEngineDialog (PUT patch)
              → applyCardSettings (fills config.searchEngineApiKeys)
              → configToEnv (packs the map onto /invoke)
              → CLI resolves the credential and injects the header
```

- **`hasApiKey` is a VIEW of the key map, never a stored claim.** Both
  `summarize()` and `applyCardSettings` derive it from
  `searchEngineApiKeys[id]`, so a drifted `true` heals on the next save.
  `summarize()` also unions the key map into its iteration, so an engine
  holding a key but no `searchEngineConfigs` entry (row config, hand-written
  `config.yaml`) stays visible — the real order of operations is "paste the
  key, THEN add the engine to the chain".
- **The key is write-only**: `stripApiKeys` removes it from the draft once the
  save lands, so later debounced saves never re-send a plaintext copy. The
  browser only ever reads back `hasApiKey`.
- **`tests/engine-config-wiring.spec.ts`** pins the env-var NAMES on both
  sides — a rename on one side alone degrades silently to "unset".
  **`tests/client-chunks.spec.ts`** drives the real dialog (react-dom/server
  drops handlers, so it uses a recording `createElement` spy to reproduce
  typing and saving). Those two specs are what hold the four hops together.

### Mojeek: the credential is a cookie, and the PoW lives OUTSIDE the search path

The engine id is **`mojeek-free`**, never `mojeek`: Mojeek also sells an
official **Search API** (`api.mojeek.com`, billed, real API key), and the bare
product name next to a settings field labelled "API Key" is exactly how a user
ends up hunting for a subscription this plugin never uses. The suffix names
what the engine is — the free, cookie-gated web SERP. The same reasoning names
`src/engines/mojeek-free.ts`, `MojeekFreeSearchEngine` and the `MOJEEK_FREE_*`
constants; only `buildMojeekUrl` / `parseMojeekResults` keep the bare product
name, because they parse Mojeek's SERP whoever reaches it.

Mojeek's HTML SERP sits behind an Altcha proof-of-work, and the engine's
`auth` is `Cookie` with `DSH_NETWORK_MOJEEK_COOKIE` — the solved `chllg`
cookie is just another entry in the key map. Two paths solve the Altcha:

  - **Auto (persistent server only).** A `MojeekSession`
    (`src/mojeek-session.ts`) is created once at server start and threaded
    onto every `RunContext`. The first `mojeek-free` search after a fresh
    install (~1-2 s Altcha solve) seeds it; later searches just reuse the
    cached cookie. A `200` + challenge page also re-solves inside the same
    call, so the user never sees a stale-cookie warning. Single-shot CLI gets
    no session — it must run `mojeek-login` and export the cookie as
    `DSH_NETWORK_MOJEEK_COOKIE`. The user's stated trade-off is "first request
    slow by 1-2 s, otherwise invisible".

**The host never asks the user for that cookie**, so the settings dialog must
NOT offer a key field for this engine: `ENGINE_HAS_API_KEY['mojeek-free']` is
`false` (`dsh/client.settings.js`). A password box labelled "API Key" for an
engine that has no key read as a missing paid subscription, and its row badge
showed a permanent red "missing" that meant nothing. Declaring `auth` on the
engine is still correct — it is how the CLI knows to inject `Cookie:` and to
synthesize a 401 when a standalone run has none — but the DIALOG gate is a
separate, deliberately-closed switch. A cookie that reaches the key map
another way (hand-written config) still works and still self-heals.

The solve itself is `mojeekLogin()` (`src/mojeek-login.ts`), separate
from the search path. Both halves of that split are load-bearing:

- **Three requests per search would walk into the second gate.** The Altcha
  wall is only the first: a burst of ~6 cookie-authenticated queries gets the
  egress IP answered with `403 automated queries` for minutes (measured), and
  a paced 1 query / 8 s stream passes. The cached cookie makes a search ONE
  GET; solving inline would make it three and spend the budget faster.
- **The solver must use async PBKDF2.** The measured challenge is cheap
  (~200–300 counters, ~1–2 s), but `pbkdf2Sync` in the host's long-lived
  server would freeze `/health`, `/content` paging and every other tool call
  for the duration. `mojeek-login.ts` fans counters across four libuv
  workers instead.
- **A 200 is not a success.** A stale/revoked cookie returns the JS challenge
  page with **HTTP 200**, which parses to zero hits and reads as a genuine
  empty answer. `MOJEEK_FREE_CHALLENGE_MARKER` is checked before the parser in
  both `runSearch` (where the session invalidates and re-solves) and
  `parseMany` (where the standalone path surfaces the warning). The 403
  wall gets its own wording (the fix is patience, not a retry). The engine
  itself never retries on its own.
- **Registered LAST, never in the default chain.** Same rule as Brave, for one
  more reason: a fresh install must not touch mojeek.com at all.

### Pin the TLS CIPHERS, never the TLS VERSION

`pinnedDispatcherLike` (`src/client.ts`) sets `minVersion: 'TLSv1.2'` plus
`ciphers: FIREFOX_TLS12_CIPHERS` (Firefox's own preference order, the list
curl-impersonate's `firefox` profile uses).

- **The fingerprint is the cipher list, not the version.** The benefit is available
  on TLS 1.2 too, through the list.
- **The list must stay a SUPERSET of what mainstream servers offer.** An
  over-tight list fails closed with `ERR_SSL_NO_CIPHER_MATCH`, which reads as
  a network outage rather than a config error. The DHE suites are not
  preferred by Firefox but are kept deliberately, so an RSA-only edge still
  finds a shared suite.

When adding an engine, check its edge can actually complete the handshake the
dispatcher offers.

### 360: a 200 can be a CAPTCHA wall, and only the user can clear it

The engine id is **`so360`**, not `360` / `so-com`: 360's web SERP is the only
360 product this plugin touches (no API, no billed key), so the id names the
search engine by its product number the way `baidu` / `bing` name theirs.
`src/engines/so360.ts`, `So360SearchEngine`, `SO360_*` constants,
`buildSo360Url` / `parseSo360Results`; the display name is `360搜索`, since the
bare product number reads as nothing to an English reader.

360 needs **no credential and no proof-of-work** — the first request from a
cold address returns a full SERP. It DOES have an IP rate limit, and the way
it is enforced is the load-bearing part, the wall is HTTP 200 with a ~6-9 KB
 `访问异常页面` body. Nothing here can re-solve it, and nothing should retry.

### Per-engine options must reach the engine in SERVER mode too

`DSH_NETWORK_ENGINE_OPTIONS` arrives two different ways: from `process.env` in
a one-shot CLI run, and as a per-`/invoke` JSON body in the persistent server.
`readEngineEnvOptions()` can only see the first — so an engine reading its own
fields off `process.env` silently ignored every option typed into the settings
dialog whenever the search came through dsh. `buildRequestOptions()`
(`src/cli.ts`) is the fix: it spreads the engine's slice of
`config.engineOptions` into the TOP level of the `buildRequests` options bag,
where engines actually look (`buildBraveUrl` reads `opts.country`,
`buildMojeekUrl` reads `opts.s`, `buildSo360Url` reads `opts.pn`), and keeps the
nested `engineOptions` key for engines that prefer it. The spread comes FIRST so
the caller's own keys win — a free-form `perPage=…` line in the textarea must not
outrank the result cap.

### The browser half must not forget the new engine

Adding an engine is never just `src/engines/<id>.ts`. The catalog lives in
five more places, and a miss is silent (the dialog simply never offers the
engine, or renders an empty label): `dsh/client.js` `ENGINES` +
`ENGINE_LABELS` + both locale hints, `dsh/client.settings.js`
`ENGINE_DEFAULT_ENDPOINTS` + `ENGINE_HAS_API_KEY` + `ENGINE_HINTS`,
`dsh/schemas.js`'s chain description, `src/config.ts` `SEARCH_ENGINE_IDS`,
and `tests/network.spec.ts`'s registry-order assertion.

### Per-engine options

`DSH_NETWORK_ENGINE_OPTIONS` carries the settings dialog's free-form
`key=value` textarea as `{ engineId: { … } }`; an engine reads its own slice
with `readEngineEnvOptions(id)` (pure, never throws) and validates every
field itself before it reaches a URL, so a typo cannot burn a billed call on
a 422. That reader only sees `process.env`, so in server mode the SAME fields
also arrive spread into the top level of the `buildRequests` options bag (see
the section above) — an engine that reads only one of the two spellings works
in one mode and silently ignores the dialog in the other.

`buildBraveUrl` is the reference: unknown keys and out-of-vocabulary
values are dropped, `count` comes from the call cap (`perPage`, clamped to
Brave's 20) with `max` as the standalone fallback, and `extra_snippets=true`
is always on so `page_age` / extra excerpts reach `published_at` and the
snippet. Brave's `plausiblePublishedAt` accepts only an ISO-8601 timestamp
whose year lands in [1990, next year] — upstream returns epoch-seconds read
as ms, and a wrong date in the evidence is worse than no date.

### `web_download` is the ONE write, and it is fenced four ways

The other five tools read a response. This one writes attacker-influenced
bytes to a path the user can see and click, so every rule around it is a
security rule, and the reasons are load-bearing:

- **`downloadTool` defaults to `false` — the only field here that does.**
  Every sibling defaults on because registering a reader costs nothing. It is
  gated at REGISTRATION time (`apply()` skips it), which is stronger than the
  others' call-time check: an unregistered tool is absent from the model's tool
  list rather than throwing when used.
- **The model can neither read nor write that flag.** `summarizeForModel()`
  strips it (like `allowConfigEdit`) and `WEB_CONFIG_PATCH_SCHEMA` omits it, so
  `web_config.set` cannot reach it through `pickConfigPatch()`. A model that
  could enable its own file-write tool would make the opt-in meaningless.
- **The destination root is host-resolved, never model-influenced.**
  `defaultConfig()` resolves `workspaceDir` once from the host process
  (`DSH_NETWORK_WORKSPACE_DIR` or `process.cwd()`), `configToEnv()` ships it as
  `DSH_NETWORK_WORKSPACE_DIR`, and the model picks `dest` between two FIXED
  roots. An absent value means "workspace unavailable" and the call FAILS —
  the CLI must never fall back to the server child's own cwd, which is wherever
  dsh happened to be launched.
- **`dest` is an enum, not `workspace: bool`.** A bare boolean gets misread and
  `workspace: true` in a transcript says nothing about WHICH workspace. The
  enum also carries the default (`tmp`), which a boolean cannot.

Then four fences inside `src/download.ts`, each covering a way the layer above
it can lie:

1. **Type from the BYTES.** Precedence is magic bytes → `Content-Type` →
   filename, and every rung below the first exists only because the one above
   can lie. `sniffExtension` must recognize markup POSITIVELY (`html`/`json`/
   `xml`): returning `null` for an HTML anti-bot page hands the decision back to
   the lying `Content-Type`, which is the exact failure the sniffer exists to
   prevent. A disagreement is reported in `warnings`, never silently applied.
2. **Containment.** `sanitizeFileName` neutralizes separators, control
   characters, leading `..`, Windows device names and trailing dots/spaces;
   `resolveInsideRoot` re-checks the RESOLVED path with `path.relative` (a
   string prefix test misses `…/downloads-evil`). The second check is the one
   that matters — it has to hold even if the sanitizer is ever weakened.
3. **Executables are refused.** The denylist is checked against the sniffed
   name AND the declared one: `setup.exe` is refused whether or not its bytes
   look like an executable. A file in the workspace is one `pwsh -File` away
   from running, and this plugin has no business granting that to a web page.
4. **No truncation, ever.** `readBodyWithLimit` THROWS past `maxBytes`, so the
   write is all-or-nothing, and it lands via `.part` → `rename` so a reader
   never sees a partial file. Non-clobbering names (`a.png` → `a-1.png`)
   because the workspace destination is where a deliverable lives.

**It is deliberately NOT in the result cache.** The cache stores strings keyed
by `fetch|format|url`; a warm hit could only rewrite the file or hand back a
stale copy. `runOnce` passes no cache to `runDownload`, and the reason is in
its header comment — do not "fix" that by threading the cache through.

### `web_search` is NOT cached

Only fetch/http bodies are, so two identical searches in one turn bill the
engine twice. Known and accepted: a search cache needs an explicit
invalidation story, and a stale hit list is its own defect. Revisit only if a
billed engine joins the DEFAULT chain.

### `dsh-network doctor` cannot prove an engine is reachable

`doctor` resolves config and reports credential state without contacting
anything (it is safe offline and safe for a billed engine). That makes it blind
to everything a search engine can get wrong on the wire — a TLS handshake the
dispatcher refuses, a CAPTCHA wall, an HTML shape the parser missed. The only
real check is a live `search --engine <id>`, which costs the host's budget on a
billed engine. See the TLS invariant above: `baidu` reported healthy in `doctor`
while being 100% unreachable.

### Browser half: chunks

`dsh/client.js` is the browser entry; surfaces load from `client.<name>.js`
chunks via the loader's OFFICIAL `require.async` protocol:
`client.settings.js` ("网络" section + legacy card), `client.toolviews.js`
(block renderers + `tool.call.toolview` rows), `client.searchpanel.js`
(sidebar panel). The entry owns the shared surface (engine constants,
`DICTS`, `fetchConfig` / `putConfig` / `fetchHealth`, `labelText`, `STYLES`).

A chunk must be SELF-CONTAINED: seed words (`react`) and the entry via
`require('@naivg/dsh-network')` only — never another chunk — and it registers
with `window.__ModuleLoader__.load({ id, chunk, factory })`, where `id` is the
package name verbatim. **A chunk has no view
of the entry's file scope**, so every shared symbol (`ENGINES`,
`ENGINE_LABELS`, …) must be re-bound from the `require('@naivg/dsh-network')`
object
by name. A leftover free variable is not a syntax error, load error or
warning: the chunk registers, materializes and exports happily, then throws
`ReferenceError` inside React's render and takes the whole section down.
`tests/client-chunks.spec.ts` guards this statically (TypeScript `checkJs`
unresolved names) and dynamically.

Per-plugin revisions derive from the ENTRY file's mtime/ctime/size: after
editing a chunk, touch `dsh/client.js` (or reinstall) to bump the rev,
otherwise browsers keep the immutable-cached old copy.

### Search answer contract

`dsh/providers.js` `makeSearchProvider`. dsh's own `tool-web` wraps each
query's `content` in a `### <query>` heading and pools ALL sources into one
list capped at `searchMaxResults`, round-robin — so a provider returning
only a summary renders empty headings above a truncated list. The provider
therefore renders **each query's full hit list** into `content`, making every
`###` section self-contained; `sources` still carries the complete set for
any other consumer. Whitespace is part of the contract
(`tests/search-source-format.spec.ts` pins it): each hit is TWO lines —
`N. [title](url)` closed by a GFM hard break (two trailing spaces; a bare
`\n` renders as a space) with the snippet/date indented four spaces on the
next — and sections join on blank lines so a trailing `Uncertain:` note can
never lazy-continue the last list item.

### Toolview rows

- `tool.call.toolview` is a KEYED slot: one cell per tool name, only the
  **lowest-priority** live entry renders, and re-registering a key at an
  already-taken priority **throws**. dsh claims `web_search` at priority 0,
  so the plugin claims `-900` for every row; the registration is try/caught so
  an upstream change can't take down the browser half. `http_request`,
  `web_fetch`, `web_sitemap`, `web_config` and `web_download` have NO native
  cell at all (this package replaces dsh's `tool-web`), so their rows render
  unconditionally.
  Styling is composed to read like a first-party dsh card under `dshn-` class
  names, because the upstream hashed classes are internal to the dsh bundle.
- Read arguments via `argsOf`: a settled dsh block carries them ONLY as the
  raw JSON string `block.call.argsRaw` (there is no pre-parsed `call.args`),
  with a literal `call.args` fallback for hosts/tests. The `web_config` row
  needs them early: it labels the row 读取配置 / 修改配置 while the call is still
  STREAMING (the meta only arrives once it settles).
- A settled block is detected by `kind === 'tool-result'` / `isError === true`
  (dsh's canonical check), with meta presence as a fallback — never by hit
  count, and never by meta alone: a THROWN call lands no meta at all.
- Every answer/body string goes through the host's `ui.MarkdownText`,
  detected with `isRenderable(value)` — NEVER `typeof value === 'function'`.
  dsh exports it through `React.memo`, so the shipped value is a memo object
  and a function-only test silently falls through to the raw-text `<pre>`
  fallback. `isRenderable` accepts functions, memo / forwardRef / lazy tags
  and `render`-carrying objects; it rejects null, plain objects and the
  strings of the degraded `{ Input: 'input' }` host surface. `MarkdownText`
  also needs its `labels` seats, which the entry supplies per locale. A body
  whose persisted `format` is `raw` is NOT markdown and stays monospace.
- A row can only show what the host persisted: `presentationMeta` carries the
  `web_fetch` page as `contentPreview` plus `format`, `links` and the cache
  descriptor, and `http_request`'s body as `bodyPreview` plus `headers`. Both
  previews go through `previewText` (one clip, one trailing `…` marker — the
  row reads that marker to tell a truncated preview from a complete body).
  Any paging hint quotes the ABSOLUTE next offset
  (`cacheSlice.offset + shown`), never the slice-local length.
- `web_config`'s row is the wide one: the meta carries the WHOLE config
  (`config`, straight from `summarizeForModel()` — so `allowConfigEdit` and
  every secret are absent by construction, and must stay absent) plus
  `changes`, the field names a LANDED `set` forwarded. Two rules:
  **only `status: 'ok' && action: 'set'` gets `changes`** (the gate and
  `applyCardSettings` rejections touch nothing, and listing them would draw
  edits that never happened), and the value shown per change comes from the
  POST-write `config`, so a clamp reads as a clamp. Patching is filtered by
  `pickConfigPatch()` (schemas.js), the ONE whitelist `execute()` also writes
  through.
- **A nested `undefined` in a meta is a REJECTED tool call.** The harness
  checks `JSON.parse(JSON.stringify(meta))` deep-equal to the original, and
  `compactPresentation()` only scrubs the TOP level — while `summarize()`
  emits `endpoint: undefined` for an engine with no endpoint override. The
  `web_config` snapshot therefore goes through `jsonSafeMeta()`
  (evidence.js). Add a deep sanity check, not a top-level one, when a meta
  grows a nested object.

### Sidebar search panel

`client.searchpanel.js` + `registerSearchRoute`, on the same two-registration
protocol the built-in (order 0) and schedules (order 10) panels use: an icon
in the root-scoped `sidebar.panellist` list slot `{ id: 'dsh-network-search',
order: 20, label }`, plus the page component in the layout's root-scoped KEYED
`main` slot under the SAME key (`layout.selectPanel(id)` validates them
against each other). The page POSTs `{ query, count, engine }` to
`/dsh-network/search`, which runs the SAME `runCli(['search', …])` path as
the `web_search` tool. The panel mounts only after a `/dsh-network/config`
probe proves the host is present AND `webSearchTool !== false`; state
survives unmounts in a module-level cache.

### Config, routes and persistence

- The `/dsh-network/config` and `/dsh-network/search` routes sit behind
  `isTrustedRequest` — the same loopback + `sec-fetch-site: same-origin` +
  Origin == Host fence dsh's own `/api` uses. `/dsh-network/search` is also
  gated by the LIVE `config.webSearchTool`, so one switch disables both the
  model-facing tool and the user-facing panel without a reload.
- The browser half reads/writes the live `config` object `apply()` owns. There
  is deliberately NO `dsh-network` settings namespace — the runtime reads the
  cordis row config + in-memory edits, so a `settings.yaml` section would
  silently do nothing.
- Durability comes from `dsh/persist.js`, not the settings document: every
  successful save atomically snapshots to `~/.dsh/dsh-network.json`
  (`DSH_NETWORK_CONFIG_FILE` overrides) and `apply()` reloads it at boot. The
  snapshot wins over the cordis row config (the seed for a fresh install);
  delete the file to reset. `enabled` is never persisted — the row config is
  the only kill-switch. Secrets ride in the file; a corrupted one is ignored
  with a warning.
- `web_config`'s `set` is gated by the user-controlled `allowConfigEdit`
  toggle in **网络 → 安全** (off by default), which is hidden from the model
  on both `get` and `set` so a botched batched patch can never lock the model
  out of its own write path.

## CLI

```bash
dsh-network search  -q "typescript 5.9 release notes"
dsh-network fetch   -u "https://example.com/docs"      --cache-id <id> --offset 4000 --limit 4000
dsh-network         -X GET https://api.example.com/v1/users
dsh-network download -u "https://example.com/logo.png" --dest tmp   # web_download
dsh-network web_sitemap --query "github" --domain github.com
dsh-network doctor                                     # no network
dsh-network mojeek-login                               # Altcha PoW → chllg cookie (2 requests)
dsh-network server   [--port <n>]                     # long-lived mode the host spawns
```

`fetch` / `-X` store any body over the inline cap on the server and return a
`cacheId` + `contentLength` + preview; re-invoke with `--cache-id` (plus
optional `--offset` / `--limit`) to page without re-issuing the request —
`url` and `cacheId` are mutually exclusive. `web_search` / `web_sitemap` don't
page; their lists are bounded by `--max-results` (default 10, cap 20).
`download` neither pages nor caches — it returns a `path`. Full reference in
[docs/cli.md](docs/cli.md).

## Verification

| Command | Runs |
|---|---|
| `pnpm test` | vitest unit suite, no external network, ~7 s |
| `pnpm run test:server` | loopback server smoke (degrade → page → `/health` → `/shutdown`) |
| `pnpm run test:persist` | durable store + `/dsh-network/search` route contract |
| `pnpm run test:download` | built-CLI download smoke (workspace root, executables, byte cap, SSRF fence) |
| `pnpm run test:schema` | tool schemas pass `dsh-tools.assertSupportedJsonSchema` (skips cleanly without dsh) |
| `pnpm run test:all` | all of the above |

Notes worth carrying:

- The entity block (`decodeEntities`, `cleanHtmlText`, per-engine parser
  decode, `htmlToMarkdown` decode) is the fence around the `&nbsp;`-in-a-card
  class of defect; the end-to-end case asserts no `&…;` reference survives ANY
  of the three scraped engines.
- `tests/client-chunks.spec.ts` and `tests/engine-config-wiring.spec.ts` are
  the credential-chain guards — run them whenever you touch the engine dialog,
  `summarize()`, `applyCardSettings` or `configToEnv`.
- `tests/schema-check.mjs` matches line breaks as `\r?\n` on purpose: with
  `core.autocrlf=true` the tree is CRLF and a bare `\n` matches ZERO blocks on
  Windows, silently turning the guard into a no-op. Don't "simplify" it.
- `dist/` is gitignored, so a git install can only build via the `prepare`
  hook — `dsh plugin add github:NaivG/dsh-network` reports success and every
  later tool call dies with `dsh-network CLI bundle is missing` without it.
  pnpm 12 also needs a **spec-qualified** `allowBuilds` key. The npm route
  needs neither: `prepack` bakes `dist/` into the published tarball. See
  [docs/development.md](docs/development.md#publishing-and-the-prepare--prepack-hooks).
- Real end-to-end runs cost public-engine budget — ask before bulk. Brave is
  BILLED PER QUERY (its free tier is gone), sits last in the registry and is
  absent from the default chain; `doctor`'s `apiKeys=[brave=no key]` checks it
  for free, as does probing the endpoint without a credential (422,
  `header.x-subscription-token: Field required`).

## Layout

`dsh/` host half (hand-written ESM) · `dsh/client*.js` browser half ·
`src/` CLI (vite SSR → `dist/cli.cjs`) · `tests/` vitest specs + plain-node
smokes. Per-file roles, the engine catalog and the config field reference are
in [docs/development.md](docs/development.md),
[docs/architecture.md](docs/architecture.md),
[docs/search-engines.md](docs/search-engines.md) and
[docs/configuration.md](docs/configuration.md).