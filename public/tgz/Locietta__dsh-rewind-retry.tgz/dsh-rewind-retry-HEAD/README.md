# dsh-rewind-retry

A [DeepSeek Harness (DSH)](https://github.com/deepseek-ai/deepseek-harness) plugin that adds **Retry**, **Edit prompt**, and **Continue** actions to finished turns in the Web / Desktop chat UI.

DSH has no built-in way to edit your last message or retry a turn that failed (for example, one halted by a network error). This plugin adds those actions.

## Actions

| Action | Where | What it does |
|---|---|---|
| ↺ **Retry** | every finished turn you started with a prompt | Forks the session right before that prompt and sends the same prompt again in the fork. |
| ✎ **Edit** | same | Forks at the same point and puts the old prompt into the fork's composer so you can change it before sending. |
| ⏭ **Continue** | latest turn only, when it failed or produced no reply | Sends "Continue from where you left off." in the **same** session, keeping all work already done. |

Turns that ended with a reply get the actions as icons in the existing copy / branch row (revealed on hover, like the built-in icons). Turns that ended without a reply, such as failed or stopped turns, get a visible row of labelled buttons, because DSH shows no action row for them.

## How it works

DSH's session log is append-only, so a "rewind" is a **fork**: the plugin calls the Host's `session.fork` with an exact `atSeq` boundary and opens the new session. The original session is kept as a branch. Rewinding only affects the conversation; files changed on disk stay changed.

Choosing the boundary (`planRewind` in [`client.js`](client.js)):

- **Idle prompt.** The cut goes just before the inbox insertion of the prompt, so settings you changed between turns (permission mode, model, …) are kept.
- **Prompt queued while the previous turn was running.** The cut goes at the end of the previous turn, plus its standalone trailing events (the same rule the Host uses for its default fork). Queued prompts inherited by the fork are then removed from its inbox, so an old queued prompt can't run ahead of the retried one.
- If the relevant history isn't loaded in the chat yet, older pages are loaded on demand.

## Limitations

- **Attachments aren't carried over.** Retry resends text only. If the original prompt had images or files, Retry stages the text in the composer (like Edit) and shows a note to attach them again.
- **Where the actions appear.** They sit at the end of each turn, because DSH offers no extension slot on the user-message bubble.
- **Which turns are rewindable.** Only turns started by your own prompt. Turns started by goal rounds, schedules, or subagent notices get no Retry or Edit.
- **Tested version.** Only tested against DSH `0.1.7-rc.1`. The plugin reads some Client internals (the chat snapshot and the session event window) defensively, but a future DSH release may still need updates.

## Install

DSH's plugin manager installs bundles straight from GitHub; no npm package is needed. Ask the DSH agent:

> Install the plugin bundle `github:Locietta/dsh-rewind-retry#v0.1.0`.

The agent calls its `plugin_manager` tool (`install_bundle` with that spec as target). The plugin activates without restarting DSH. Refresh the page if the buttons don't show up.

- **Pick a version:** see [Releases](https://github.com/Locietta/dsh-rewind-retry/releases) and change the `#v0.1.0` suffix to the tag you want.
- **Update:** remove the bundle and install the new tag, for example by asking the agent to "reinstall `github:Locietta/dsh-rewind-retry#<new tag>`".
- **Turn off or remove:** go to **Settings → Plugins** and find `@local/dsh-rewind-retry`.

## Development

The plugin is plain JavaScript and needs no build step:

| File | Role |
|---|---|
| [`client.js`](client.js) | Browser half: slot registrations, UI, and the pure planning logic. |
| [`index.js`](index.js) | Host half. Empty, because the plugin uses only existing Host Remotes (`session.fork`, `session.prompt`, `session.updateQueue`). |
| [`cordis.patch.yml`](cordis.patch.yml) | Bundle patch that inserts the plugin row. |
| [`locale/`](locale) | Display title and description shown in the Plugin Manager. |

The repo uses [pnpm](https://pnpm.io) (pinned through `packageManager` in `package.json`).

```sh
pnpm install      # no runtime dependencies yet; creates the local environment
pnpm test         # unit tests for the fork-boundary planner (node:test)
pnpm run check    # syntax check + tests

# Check the planner against your own session logs (read-only; needs Node >= 22.15 for zstd):
node scripts/check-session-logs.cjs ~/.dsh/sessions/<workspace>/session-<id>/session.v4.jsonl.zstd
```

To try local changes, install your working copy instead of the GitHub tag: use `install_bundle` with the absolute path of the clone. DSH then links to the directory, so after editing `client.js` you only need to refresh the page. If the old code keeps running, disable and re-enable the plugin, or restart DSH.

To release, push a `vX.Y.Z` tag that matches `version` in `package.json`, and create a GitHub release for it.

Slots used: `conversation.chat.assistant-actions`, `conversation.chat.turnTail`, `conversation.input.dock`.

## License

[MIT](LICENSE)
