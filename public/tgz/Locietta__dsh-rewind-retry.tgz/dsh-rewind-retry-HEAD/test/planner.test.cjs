// Unit tests for the rewind planner over hand-written event logs.
// Run: npm test
const test = require('node:test');
const assert = require('node:assert/strict');
const { loadPlanner } = require('./load-planner.cjs');

const { planRewind } = loadPlanner();

const prompt = (id, text, extra = []) => ({
  content: [{ type: 'text', text }, ...extra],
  source: { kind: 'user' },
  role: 'user',
  id,
});
const splice = (seq, target, fields) => ({ type: 'agent/inbox/spliced', seq, data: { target, start: 0, ...fields } });

// Turn 1 is sent while idle; turn 2's prompt is queued while turn 1 is still running.
const queuedLog = [
  { type: 'model/selection', seq: 0, data: {} },
  splice(1, 'next-turn', { inserted: [prompt('m1', 'first')] }),
  { type: 'turn/start', seq: 2, data: { turn: 1 } },
  splice(3, 'next-turn', { removedCount: 1, inserted: [] }),
  { type: 'step/start', seq: 4, data: { turn: 1, step: 1 } },
  { type: 'user/message', seq: 5, surfaceOp: 'append', data: prompt('m1', 'first') },
  splice(6, 'next-turn', { inserted: [prompt('m2', 'second')] }),
  { type: 'step/end', seq: 7, data: { turn: 1, step: 1 } },
  { type: 'turn/end', seq: 8, data: { turn: 1, reason: { kind: 'completed' } } },
  { type: 'turn/start', seq: 9, data: { turn: 2 } },
  splice(10, 'next-turn', { removedCount: 1, inserted: [] }),
  { type: 'step/start', seq: 11, data: { turn: 2, step: 1 } },
  { type: 'user/message', seq: 12, surfaceOp: 'append', data: prompt('m2', 'second') },
  { type: 'step/end', seq: 13, data: { turn: 2, step: 1 } },
  { type: 'turn/end', seq: 14, data: { turn: 2, reason: { kind: 'error' } } },
];

test('idle prompt: cut right before its inbox insertion', () => {
  const plan = planRewind(queuedLog, 1, false);
  assert.equal(plan.ok, true);
  assert.equal(plan.boundary, 0);
  assert.equal(plan.text, 'first');
  assert.deepEqual(plan.removeIds, []);
});

test('queued prompt: cut at the previous turn end and drop the inherited queue item', () => {
  const plan = planRewind(queuedLog, 2, false);
  assert.equal(plan.ok, true);
  assert.equal(plan.boundary, 8);
  assert.equal(plan.text, 'second');
  assert.deepEqual(plan.removeIds, ['m2']);
});

test('prompt insertion outside the loaded window asks for older history', () => {
  const plan = planRewind(queuedLog.slice(8), 2, true);
  assert.equal(plan.ok, false);
  assert.equal(plan.needOlder, true);
});

test('unloaded turn asks for older history only when more exists', () => {
  assert.equal(planRewind(queuedLog.slice(9), 1, true).needOlder, true);
  assert.equal(planRewind(queuedLog.slice(9), 1, false).needOlder, false);
});

test('attachments are counted and excluded from the resent text', () => {
  const content = prompt('m1', 'look', [{ type: 'image', ref: {} }]);
  const log = [
    { type: 'model/selection', seq: 0, data: {} },
    splice(1, 'next-turn', { inserted: [content] }),
    { type: 'turn/start', seq: 2, data: { turn: 1 } },
    { type: 'user/message', seq: 3, surfaceOp: 'append', data: content },
    { type: 'turn/end', seq: 4, data: { turn: 1, reason: { kind: 'completed' } } },
  ];
  const plan = planRewind(log, 1, false);
  assert.equal(plan.ok, true);
  assert.equal(plan.text, 'look');
  assert.equal(plan.attachments, 1);
});

test('turns not started by a user prompt are not rewindable', () => {
  const log = [
    { type: 'model/selection', seq: 0, data: {} },
    { type: 'turn/start', seq: 1, data: { turn: 1 } },
    { type: 'user/message', seq: 2, surfaceOp: 'append', data: { ...prompt('n1', 'notice'), source: { kind: 'plugin', plugin: 'x' } } },
    { type: 'turn/end', seq: 3, data: { turn: 1, reason: { kind: 'completed' } } },
  ];
  const plan = planRewind(log, 1, false);
  assert.equal(plan.ok, false);
  assert.equal(plan.code, 'no-user-prompt');
});
