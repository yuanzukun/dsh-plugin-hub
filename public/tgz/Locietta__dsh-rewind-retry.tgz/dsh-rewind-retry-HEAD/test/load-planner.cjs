// Load client.js outside the browser and return its pure planning helpers.
const path = require('path');

function loadPlanner() {
  let definition;
  const previous = globalThis.window;
  globalThis.window = { __ModuleLoader__: { load(def) { definition = def; } } };
  try {
    require(path.join(__dirname, '..', 'client.js'));
  } finally {
    globalThis.window = previous;
  }
  if (!definition) throw new Error('client.js did not register a module');
  const plugin = definition.factory((name) => {
    if (name === 'react') return {};
    throw new Error(`unexpected require: ${name}`);
  });
  return plugin.__test;
}

module.exports = { loadPlanner };
