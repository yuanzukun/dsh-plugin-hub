// Check the rewind planner against real DSH session logs (read-only).
// Usage: node scripts/check-session-logs.cjs <session.vN.jsonl.zstd> [...more]
// Session logs live under ~/.dsh/sessions/<workspace>/session-<id>/.
// Reading .zstd logs needs a Node.js version with zlib.zstdDecompressSync (22.15+).
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { loadPlanner } = require('../test/load-planner.cjs');

const { planRewind, durableEvents } = loadPlanner();

function readLog(file) {
  const raw = fs.readFileSync(file);
  const text = file.endsWith('.zstd') ? zlib.zstdDecompressSync(raw).toString() : raw.toString();
  return text.split('\n').filter(Boolean).map((l) => JSON.parse(l)).filter((e) => typeof e.seq === 'number');
}

let failures = 0;
for (const file of process.argv.slice(2)) {
  const events = readLog(file);
  const window = durableEvents({ entries: events.map((event) => ({ type: 'durable', event })) });
  const turns = window.filter((e) => e.type === 'turn/start').map((e) => e.data.turn);
  console.log(`\n# ${path.basename(path.dirname(file))} (${events.length} events, ${turns.length} turns)`);
  for (const turn of turns) {
    const plan = planRewind(window, turn, false);
    if (!plan.ok) { console.log(`turn ${turn}: skip (${plan.code})`); continue; }
    const cut = window.find((e) => e.seq === plan.boundary);
    const next = window.find((e) => e.seq === plan.boundary + 1);
    // Invariants: boundary exists, precedes turn start, the prompt is not delivered in the prefix,
    // and every next-turn item still pending at the cut is scheduled for removal.
    const problems = [];
    if (!cut) problems.push('boundary event missing');
    if (plan.boundary >= plan.turnStartSeq) problems.push('boundary not before turn/start');
    const prefix = window.filter((e) => e.seq <= plan.boundary);
    if (prefix.some((e) => e.type === 'user/message' && e.surfaceOp === 'append' && e.seq === plan.promptSeq)) problems.push('prompt inside prefix');
    const open = prefix.filter((e) => e.type === 'turn/start').length - prefix.filter((e) => e.type === 'turn/end').length;
    if (open !== 0) problems.push(`prefix leaves ${open} open turn(s)`);
    // exact inbox fold of next-turn at the boundary
    let q = [];
    for (const e of prefix) {
      if (e.type === 'agent/inbox/spliced' && e.data.target === 'next-turn') {
        q.splice(e.data.start ?? 0, e.data.removedCount ?? 0, ...(e.data.inserted ?? []).map((i) => i.id));
      }
    }
    const missing = q.filter((id) => !plan.removeIds.includes(id));
    if (missing.length) problems.push(`pending not removed: ${missing.join(',')}`);
    if (problems.length) failures++;
    console.log(`turn ${turn}: cut@${plan.boundary} (${cut && cut.type}) next=${next && next.type} turnStart=${plan.turnStartSeq} remove=[${plan.removeIds.length}] pendingAtCut=${q.length} text="${plan.text.slice(0, 40).replace(/\n/g, ' ')}" att=${plan.attachments}${problems.length ? '  !! ' + problems.join('; ') : ''}`);
  }
}
console.log(failures ? `\n${failures} FAILURE(S)` : '\nall invariants hold');
process.exitCode = failures ? 1 : 0;
