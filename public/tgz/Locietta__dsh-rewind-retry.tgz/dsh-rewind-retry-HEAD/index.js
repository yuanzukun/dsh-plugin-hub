/**
 * Host half of @local/dsh-rewind-retry.
 *
 * Everything this plugin does goes through existing Host Remotes
 * (session.fork, session.prompt, session.updateQueue), so the Host half has
 * nothing to register. The session log stays append-only: a rewind is a fork
 * at an exact event boundary, never an in-place truncation.
 */
export function apply() {}
