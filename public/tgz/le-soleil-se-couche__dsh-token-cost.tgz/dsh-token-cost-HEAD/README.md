# dsh-token-cost

版本 `0.5.0` 使用官方 DSH `0.2.1-rc.3` SDK、Cordis `4.0.5`、Schemastery `3.18.5`。macOS Desktop 的原生更新会在安装前自动检查费用插件依赖的接口；版本号和无关实现变化可自动通过，关键接口变化或检查失败则保留当前版本。通信适配基于 [kslz 提交的 PR #13](https://github.com/le-soleil-se-couche/dsh-token-cost/pull/13)，并保留主分支的计费时间修复。

费用 API 通过经过认证、仅限 owner 的 Connection Fetch 注册表提供；桌面端使用宿主传输，Web 端保留反向代理挂载路径。会话详情使用 `/api/dsh-token-cost/session?id=...`，支持特殊字符 ID。自定义价格加载完成后才回答请求，避免启动时把已有价格误当作空配置。

<p align="center">
  <img src="docs/banner.png" alt="dsh-token-cost" width="100%">
</p>

<p align="center">
  <a href="README.en.md">English</a> · <strong>中文</strong>
</p>

DeepSeek Harness（DSH）Web GUI 的 Token 用量 / 缓存命中 / 费用统计插件：单对话与整体汇总，内置 DeepSeek 官方计价方案（含 V4.1 Flash 降价与 V4 Pro 路由，东八区峰谷），也可为自己调用的其他模型填写单价。

2026-10-25 更新：v0.5.0 新增 macOS 原生更新前的自动兼容检查，覆盖版本号、源码排版和无关功能变动；不兼容或无法完成检查时拦截安装。运行依赖随插件打包，配置页显示保护状态。当天的 v0.4.1 修复 DSH 升级到 `0.2.1-rc.3` 后费用插件因精确 RC 版本限制而停止加载的问题。宿主与 DSH peer 兼容范围统一为 `>=0.2.1-rc.2 <0.3.0-0`，开发 SDK 固定到 `0.2.1-rc.3`；新增官方兼容检查回归测试，并补充本地安装依赖、锁文件和实际链接保持一致的要求。

2026-10-08 更新：v0.3.0 适配 DeepSeek Harness `0.2.0-rc.2`。费用直接挂载到官方输入框底部插槽，修复新版界面不显示费用的问题；与相邻速度、缓存指标保持相同字体、字号和颜色，仅用虚线下划线提示可点击查看明细。同步新版设置接口（配置保存后即时生效）、session format v4 读取和 ledger v6 缓存重建。已在 macOS 桌面端核验费用显示、明细打开和会话切换。

2026-08-17更新：支持为自己调用的其他模型填写单价；点「添加模型」即写入本地价格文件，刷新后仍在，历史费用立刻按新单价重算。

2026-08-25 更新：计量内核升级为 attempt-aware fold，补齐失败调用后 retry、`compaction/summary.usage` 与 fork `seedLength` 边界；账本 schema 升至 v2，旧缓存会从权威 session logs 自动重折叠。

2026-08-28 更新：retry 边界与官方 `llm/retry-started` 对齐，补充官方 session id 目录编码兼容，并刷新与 `0.1.2-alpha.1` 的差异说明。账本 schema 升至 v3，已有 v2 缓存会自动重折叠。

2026-09-05 更新：本版本使用官方 npm `0.1.2-rc.1` SDK，直接消费官方设置与插件卡片类型；同时增加 session format v2 读取，账本 schema 为 v4；并修复 Windows 路径下账本目录创建、显式 `flat: false` 自定义价格持久化，以及已有统计行费用标记的刷新。宿主 SDK 与日志协议分别验证：v2 synthetic fixture 通过不代表 `0.1.3-alpha.1` 宿主运行已验收。

2026-09-11 更新：同步官方调价——新增方案 C（V4.1 Flash，2026-09-10 12:00 起）与方案 D（V4 Pro 自 2026-09-14 12:00 起按 Flash 价计费）；旧模型名 `deepseek-v4-flash` / `deepseek-v4-flash-vision-exp` 自方案 C 起按 Flash 价计费，并补齐 vision-exp 在方案 B 的单价。另补入 2026-08-23 起的周末闲时历史方案，保留调价前后的各段价格。历史记录在自动模式下按生效时间切换。

## 功能

- **单对话视图**：对话页面输入框底部通过官方 `conversation.composer.dock` 插槽显示本会话消耗费用，与速度、缓存指标并列，点击即可打开按请求的明细弹窗（时间 / 模型 / 缓存未命中 / 缓存命中 / 输出 / 费用，最新在上）。

<p align="center">
  <img src="docs/screenshots/conversation-bottom.png" alt="对话底部状态行费用展示" width="90%">
</p>

<p align="center">
  <img src="docs/screenshots/cost-detail.png" alt="费用明细弹窗" width="80%">
</p>

- **整体汇总**（设置中的「Token 费用统计」标签页）：时间筛选（今天 / 昨天 / 最近 7 天 / 最近 30 天 / 本月 / 上月 / 自定义，最多 30 天）+ 费用 / 输入 / 输出 / 缓存命中率统计卡，按模型、会话、日期分组。
- **计价状态**：高峰时段按东八区显示（09:00–12:00、14:00–18:00），判定也按东八区时钟；2026-08-23 起峰时仅限工作日，周末整天按闲时，界面会标注「仅工作日」。
- **自定义模型价格**：配置页可从账本发现未定价模型，或手动添加尚未调用的模型；按每百万 tokens 填写缓存未命中 / 缓存命中 / 输出。点「添加模型」即写入本地价格文件，刷新后仍在，历史记录立刻按新单价重算。缓存命中可不填（按 0 计）。第三方模型按平价，不受 DeepSeek 峰谷影响。

2026-09-14 更新：增加官方 session format v3 读取，账本 schema 升至 v5。v2/v3 共用已经核验的用量字段、retry 和继承边界；未知未来版本继续告警并跳过。

## 数据来源

插件读取 DSH 的持久会话 generation：当前 v4 为 `$DSH_HOME/sessions/<project-key>/<encoded-session-id>/session.v4.jsonl`（或 `.zstd`），并兼容 v3 的 `session.v3.jsonl(.zstd)`、v2 的 `session.v2.jsonl(.zstd)`、v1 的 `session.v1.jsonl(.zstd)` 与 v0 的 `session.jsonl(.zstd)`。同一会话迁移后可能保留多代不可变文件；插件只选择数字版本最高的 canonical generation 一次，不重复结算迁移副本。若最高代高于已支持的 v4，插件明确告警并跳过该会话，不回退读取旧代。

v0/v1 的顶层 `assistant/chunk` / `assistant/message` 与 v2/v3/v4 的 `assistant/message.data.usage`（缺失时取 `data.stream` 最后一个 usage）/ `assistant/attempt.data.stream` 都折叠为按 attempt 的计费记录。v2/v3/v4 stream 支持官方 packed text、reasoning、tool-call run 语法；usage 仍来自其中的 raw `chunk` record。计费时间取最后一个 usage chunk 的 `time`，缺失或无效时回退到外层结算事件时间，以此选择价格与日期。同一次 attempt 内后值替换前值，只有 `llm/retry-started` 打开同一 turn/step 的下一计费槽；`compaction/summary.usage` 独立计入。fork 的 v0/v1 使用 `seedLength`，v2/v3/v4 使用最后一个 `session/end-seed { inherited: true }` 的 cut，聚合时排除继承前缀。紧凑账本（`$DSH_HOME/storages/dsh-token-cost/ledger.json`）只重解析变化的权威 generation；ledger v7 会使旧时间口径缓存失效。自定义单价存在同目录的 `custom-prices.json`；显式 `flat: false` 会原样持久化。zstd 解压使用 fzstd（纯 JS 零依赖）。

Token 字段遵循 Harness 约定：`inputTokens` = 缓存未命中部分，`cacheReadTokens` = 缓存命中部分（两者不相交，相加即计费输入）。

统计边界仍由上游日志决定：标题生成、Web Search、被中断调用、失败摘要或其他客户端若没有写出 usage，插件不会虚构 token 或费用。可公开复核的 synthetic fixture 与手算结果位于 `tests/fixtures/usage-accounting/`。

### 支持版本与日志协议边界

编译与自动测试依赖固定为官方 npm `0.2.1-rc.3`。`engines.dsh` 与 DSH peers 的加载范围为 `>=0.2.1-rc.2 <1.0.0-0`，使插件无需为每一个 `0.3.x` 等版本重新发布精确版本声明；加载范围不代表所有未来版本都已验收。macOS 原生更新另有安装前检查：读取官方已下载 ZIP，核对校验值和费用相关代码、日志版本、插件加载器及原生更新协议；已覆盖的变化自动放行，无法识别或关键实现变化则返回安装错误，当前应用继续运行。检查只读候选代码，不执行候选代码、不修改官方应用、不改计价规则和历史数据。

当前预案自动处理纯版本号变化、注释/空白/引号排版变化，以及检查范围外的新增功能。关键费用逻辑或接口实现发生变化时，需要先补充适配与验证。已验证当前 `0.2.1-rc.3` 官方包，并用合成 `0.3.0` 场景验证放行/拒绝；真实未来版本仍须通过实际候选包检查。

保护范围为已启用费用插件的 macOS Desktop「检查更新 → 下载 → 安装」。在费用插件配置页可查看「宿主升级保护」状态；出现“此宿主的更新入口暂不受保护”时不应把该入口当作已受保护。手动替换应用、其他更新器、停用/卸载费用插件、Web 和其他操作系统不经过此门禁。检查超时会先拦截安装，稍后重试可复用已完成的检查结果。

v2 日志读取依据 DSH `0.1.3-alpha.1` 的固定源码快照 [`d347e70390`](https://github.com/deepseek-ai/deepseek-harness/commit/d347e703908d0406b7a7ef80e3a0e594d86b2215)：session format v2 将每次 Assistant settlement 写为携带嵌入 stream 的 `assistant/message` 或 `assistant/attempt`，当前 generation 使用 `session.v2.jsonl(.zstd)`；迁移留下的 v0/v1 文件不是额外调用。`0.1.3-alpha.1` 宿主的完整安装与运行尚未验收；其版本不在本包声明的 peer 支持范围中。

v3 口径核验固定在官方 `dsh-v0.1.5-rc.2`（[`fb2c4b9`](https://github.com/deepseek-ai/deepseek-harness/commit/fb2c4b9e698e30edb738bca4cf0618587db7d203)）：[v3 codec](https://github.com/deepseek-ai/deepseek-harness/blob/fb2c4b9e698e30edb738bca4cf0618587db7d203/packages/session/session-format-v2-to-v3/src/codec.ts) 复用 v2 编解码，迁移保留 embedded stream 与 token 数值，新增系统消息及重映射后的最后 inherited cut 不产生额外费用。`tests/fixtures/session-v3-accounting.jsonl` 及其 zstd 副本是最小合成计量样例，覆盖两次继承标记、系统消息替换、重试、重复 usage 表示和压缩摘要：手算 3 条计费记录，input 43、output 16、cache-read 56、cache-write 9、reasoning 12。它不代表完整 Session 校验器验收、`0.1.5-rc.2` 宿主兼容性或官方账单对账；这是 v3 读取器当时的验证边界；当前 SDK 基线见本节开头。

本插件继续单独结算官方已经写入日志的 `compaction/summary.usage`，并在跨 session 汇总中排除 fork 继承前缀。这不代表插件能替代官方账单，也不扩大上游没有记录 usage 的遥测边界。`compaction/end` 等没有官方 usage schema 的字段仍不换算为费用；仓库测试只使用 synthetic fixture，不发布真实 session log。

## 安装

宿主加载范围：DSH `>=0.2.1-rc.2 <1.0.0-0`，当前 SDK 验证版本为 `0.2.1-rc.3`；本地构建要求 Node.js `>=22.22.1`、pnpm `9.15.9`。旧版 DSH 请使用对应的旧插件版本。

从本仓库源码构建安装包：

```sh
pnpm install --ignore-scripts --frozen-lockfile
pnpm pack
```

`pnpm pack` 会执行本包的 `prepare` 构建步骤，生成 `deepseek-ai-dsh-token-cost-0.5.0.tgz`。官方 Desktop 在「插件 → 添加插件」中选择该本地安装包，然后在运行中的会话和后台任务结束后，正常退出并重新打开应用。Desktop profile 由应用管理，不使用 Web CLI 命令修改它。

Web profile 使用：

```sh
dsh plugin --profile web add /absolute/path/deepseek-ai-dsh-token-cost-0.5.0.tgz
```

重启 `dsh web` 后，输入框下方显示会话费用，点击可查看明细；设置中的「Token 费用统计」提供整体汇总。历史日志在首次查询时回填。

已有安装应更新同一个包，避免同时加载两个副本。本版本保留包名、设置命名空间、账本目录及自定义价格文件。使用本地 `link:` 安装时，profile 的 `package.json`、`pnpm-lock.yaml` 与实际插件链接必须指向同一份构建；只替换 `node_modules` 会在下一次安装其他插件时被旧依赖声明还原。

升级后入口缺失时，先在「插件」中打开本包，核对版本与异常原因。若出现 `engines.dsh 0.2.1-rc.2` 的精确版本要求，仍在加载 `0.4.0` 的旧构建，应更新到 `0.5.0` 并按应用提示重载。此类兼容检查会在插件执行前拒绝加载；无需删除账本、自定义价格或会话数据。

统计费用是按日志和配置单价计算的估算值，不替代服务商账单。自动测试覆盖真实 SDK 的 Desktop carrier、HTTP 认证、非 owner 拒绝、价格持久化、特殊字符会话 ID、卸载重载，以及新增 usage 的汇总和刷新；测试使用合成记录，不发布真实会话日志。

## 内置计价方案

| 方案 | 生效时间（北京时间） | 说明 |
|---|---|---|
| A `flat-2026-08` | 2026-08-17 00:00 之前 | 平价：V4 Flash 未命中/命中/输出 = 1 / 0.02 / 2 元；V4 Pro = 3 / 0.025 / 6 元 |
| B `peak-offpeak-2026-08-17` | 2026-08-17 00:00 起 | 峰谷定价（每日）：V4 Flash 高峰 3 / 0.1 / 9 元；V4 Pro 高峰 9 / 0.3 / 27 元 |
| B2 `peak-offpeak-weekdays-2026-08-23` | 2026-08-23 00:00 起 | 沿用 B 的单价，峰时仅工作日；周末整天按闲时 |
| C `v4.1-flash-2026-09-10` | 2026-09-10 12:00 起 | V4.1 Flash 降价：高峰 2 / 0.04 / 8 元；峰时仅工作日；旧名 `deepseek-v4-flash` 系列按 Flash 价计费 |
| D `v4-pro-to-flash-2026-09-14` | 2026-09-14 12:00 起 | `deepseek-v4-pro` 路由到 V4.1 Flash，按 Flash 价计费（至 V4.1 Pro 上线） |

价格为「缓存未命中 / 缓存命中 / 输出」，单位元/百万 tokens；闲时为高峰的一半。方案 B2 起高峰时段仅周一至周五（东八区 09:00–12:00、14:00–18:00）。B2 是自动模式使用的历史过渡方案，现有手动 A/B/C/D 选择保持原义。

周末规则的历史生效日依据当时提交的 [PR #2](https://github.com/le-soleil-se-couche/dsh-token-cost/pull/2)；[当前官方价格页](https://api-docs.deepseek.com/quick_start/pricing/)确认周一至周五的峰时规则，但未保留该历史生效日期。

## 配置项

| 键 | 类型 | 默认 | 说明 |
|---|---|---|---|
| `enabled` | boolean | `true` | 总开关（状态行费用显示 + 汇总卡片） |
| `currency` | `'cny'` \| `'usd'` | `'cny'` | 显示币种 |
| `priceMode` | `'auto'` \| `'scheme-a'` \| `'scheme-b'` \| `'scheme-c'` \| `'scheme-d'` | `'auto'` | 自动按记录时间切换，也可强制某一方案 |
| `customPrices` | string (JSON) | `''` | 兼容旧设置项；现用配置页表单，落盘到 `storages/dsh-token-cost/custom-prices.json` |

以上均可在卡片的「配置」页编辑；「重新扫描会话日志」按钮强制全量重解析。

## 开发

```sh
pnpm install --frozen-lockfile
pnpm typecheck
pnpm test
pnpm build
pnpm pack
```

开发基线为 Node.js `24.21.0` 和 pnpm `9.15.9`。Git 安装的 `prepare` 会同时生成 JavaScript 与声明文件。源码 checkout 保留 `src/`、`build/`、测试和锁文件；安装包只携带 `lib/`、bundle patch 与双语说明。宿主入口为 `lib/index.js`，浏览器入口为 `lib/client.js`（`window.__ModuleLoader__.load` factory），声明入口为 `lib/types/index.d.ts` 与 `lib/types/client/index.d.ts`。打包前可通过 `npm pack --dry-run --ignore-scripts` 检查清单。

本地构建后可用 `dsh plugin --profile web add link:/absolute/path/to/dsh-token-cost` 安装到指定 profile。安装和重启会修改该 profile，请选择自己的开发 profile。

架构说明见 DESIGN.md。

---

*[English version](README.en.md)*
