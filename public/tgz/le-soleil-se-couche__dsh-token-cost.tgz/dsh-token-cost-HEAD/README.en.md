# dsh-token-cost

Version `0.5.3` uses the official DSH `0.2.1-rc.3` SDK, Cordis `4.0.5`, and Schemastery `3.18.5`. Native macOS Desktop updates now check the fee interfaces before installation: version-only and unrelated changes can proceed automatically, while changed critical interfaces or failed checks retain the current application. The transport adaptation builds on [kslz's PR #13](https://github.com/le-soleil-se-couche/dsh-token-cost/pull/13) and retains the usage timestamp fixes from the main branch.

2026-10-30 update: v0.5.3 fixes blocked official `0.2.1-rc.5` updates. Only recognized loader build-commit metadata is normalized; implementation changes remain checked. In Electron, local `original-fs` access checks physical ASAR identity and reads the archive, while extraction uses a neutral temporary filename to avoid virtual-archive interception. Full slot, syntax, checksum and file-identity checks remain active; global `process.noAsar` is unchanged. Verified in the real Electron runtime and through the official rc.3 to rc.5 native update.

2026-10-26 update: v0.5.1 fixes two upgrade-check gaps: the complete slot renderer module is checked, including private registration methods and their dependencies; syntax trees preserve JavaScript automatic semicolon insertion semantics in critical blocks. Regression tests cover real SDK registration implementations and behavior-changing line breaks. Renderer implementation changes are conservatively blocked until reviewed and adapted.

2026-10-25 update: v0.5.0 adds automatic compatibility checks before native macOS installation, including version-only, formatting, and unrelated feature changes. Incompatible or uninspectable candidates are blocked. Runtime dependencies are bundled and the settings page reports protection status. Earlier the same day, v0.4.1 fixes the fee plugin being rejected after upgrading DSH to `0.2.1-rc.3`. Host and DSH peer compatibility now share `>=0.2.1-rc.2 <0.3.0-0`, with the development SDK pinned to `0.2.1-rc.3`. Official compatibility regression tests cover the supported range and its boundaries; local installation guidance now requires the dependency declaration, lockfile, and installed link to stay aligned.

Routes use the authenticated, owner-only Connection Fetch registry. Desktop uses its supplied carrier; Web keeps relative URLs for reverse-proxy mounts. Session details use `/api/dsh-token-cost/session?id=...` with encoded IDs. Requests wait for persisted custom prices to load before responding.

<p align="center">
  <strong>English</strong> · <a href="README.md">中文</a>
</p>

Token usage, cache hits and cost statistics for DeepSeek Harness (DSH) Web GUI — per conversation and in aggregate. Built-in DeepSeek official schemes (including the V4.1 Flash price cut and the V4 Pro rerouting, UTC+8 peak/off-peak), plus a form to price any other model you call.

2026-10-08 update: v0.3.0 adapts to DeepSeek Harness `0.2.0-rc.2`. Session cost now renders through the official composer dock instead of locating the old editor/stats DOM. Its font family, size and color match the adjacent metrics; a dotted underline indicates the detail action. The update also adopts the current settings API with live configuration edits, reads session format v4, and rebuilds stale caches with ledger v6. Cost display, detail opening and session switching were verified in the macOS desktop app.

2026-08-17 update: you can enter unit prices for other models you call. **Add model** writes a local price file immediately (survives refresh) and history recalculates.

2026-08-25 update: the accounting core now uses an attempt-aware fold covering retries after failed calls, `compaction/summary.usage`, and fork `seedLength` boundaries. Ledger schema v2 automatically refolds stale cached totals from the authoritative session logs.

2026-08-28 update: retry boundaries now follow the official `llm/retry-started` event, official session-id directory encoding is supported, and the comparison with `0.1.2-alpha.1` is current. Ledger schema v3 automatically refolds existing v2 caches.

2026-09-05 update: this release uses the official npm `0.1.2-rc.1` SDK and its native settings and plugin-card types. It also reads session format v2, with ledger schema v4; fixes ledger-directory creation on Windows paths; preserves an explicit `flat: false` custom price through the settings form and local file; and refreshes an existing stats-line cost marker when new cost data arrives. Host SDK compatibility and log protocol support are verified separately: passing v2 synthetic fixtures does not establish runtime acceptance on a `0.1.3-alpha.1` host.

2026-09-11 update: official price changes are in. Scheme C covers the V4.1 Flash cut effective 2026-09-10 12:00 Beijing, and scheme D bills `deepseek-v4-pro` at the Flash rate from 2026-09-14 12:00 Beijing. The retired `deepseek-v4-flash` / `deepseek-v4-flash-vision-exp` names bill at the Flash rate from scheme C, and vision-exp now has a rate in scheme B. A historical transition also applies weekend off-peak billing from 2026-08-23 while preserving each period's prices. Auto mode selects the scheme by record time.

## What it gives you

- **Per-conversation view**: the session's total cost renders in the official `conversation.composer.dock` slot below the input, alongside speed and cache metrics; clicking it opens the per-request detail modal (time / model / cache miss / cache hit / output / cost, newest first).

<p align="center">
  <img src="docs/screenshots/conversation-bottom.png" alt="Cost in the conversation stats line" width="90%">
</p>

<p align="center">
  <img src="docs/screenshots/cost-detail.png" alt="Cost detail modal" width="80%">
</p>

- **Overall summary** (the Token Cost tab in Settings): time-filtered totals with today / yesterday / last 7 days / last 30 days / this month / last month / custom (up to 30 days), grouped by model, session and day.
- **Pricing status**: peak windows shown and billed in UTC+8 (09:00–12:00, 14:00–18:00). From 2026-08-23, peak windows apply to workdays only (weekends are fully off-peak), which the UI labels as "Workdays only".
- **Custom model prices**: Settings discovers unpriced models from the ledger, or you can add a model that has not been called yet. Enter per-1M cache-miss / cache-hit / output rates; **Add model** writes the local price file immediately (survives refresh) and history recalculates. Cache-hit may be left blank (billed as 0). Third-party models stay flat (DeepSeek peak/off-peak does not apply).

2026-09-14 update: session format v3 is supported and the ledger schema is v5. V2/v3 share the audited usage, retry and inheritance grammar; unknown future generations still warn and skip.

## Data source

The plugin reads DSH's durable session generations. Current v4 is `$DSH_HOME/sessions/<project-key>/<encoded-session-id>/session.v4.jsonl` (or `.zstd`); v3 `session.v3.jsonl(.zstd)`, v2 `session.v2.jsonl(.zstd)`, v1 `session.v1.jsonl(.zstd)` and v0 `session.jsonl(.zstd)` remain supported. Migration can retain several immutable generations for one session, so the plugin selects the highest canonical numeric generation exactly once and never settles migrated copies twice. If that highest generation is newer than supported v4, it warns and skips the session instead of falling back to stale bytes.

For v0/v1, top-level `assistant/chunk` and `assistant/message` carry usage. For v2/v3/v4, `assistant/message.data.usage` wins, otherwise the last usage in `data.stream` is used; `assistant/attempt.data.stream` preserves failed or retried settlements. The v2/v3/v4 reader accepts the official packed text/reasoning/tool-call run grammar while usage remains a raw `chunk` record inside that stream. Billing uses the last usage chunk's `time` to choose the price and day, falling back to the outer settlement time when that timestamp is missing or invalid. Values replace within one attempt; only `llm/retry-started` opens the next billing slot for the same turn/step. `compaction/summary.usage` remains an independent call. Fork exclusion uses v0/v1 `seedLength` or the last v2/v3/v4 `session/end-seed { inherited: true }` cut. The compact ledger (`$DSH_HOME/storages/dsh-token-cost/ledger.json`) only re-parses changed authoritative generations; ledger v7 invalidates the older timestamp semantics. Custom prices live beside it in `custom-prices.json`, including an explicit `flat: false`. zstd decoding uses [fzstd](https://github.com/101arrowz/fzstd) (pure JS, zero deps).

Token fields follow the harness convention: `inputTokens` = cache-miss prompt tokens, `cacheReadTokens` = cache-hit prompt tokens (disjoint; together they are the billed input).

The upstream log remains the telemetry boundary: title generation, Web Search, interrupted calls, failed summaries, or other clients cannot be priced when they do not emit usage. The public synthetic fixture and its hand-computed expectations live in `tests/fixtures/usage-accounting/`.

### Supported SDK and log protocol boundary

Build and automated test dependencies are pinned to official npm `0.2.1-rc.3`. The manifest admission range is `>=0.2.1-rc.2 <1.0.0-0`, so later `0.3.x` versions do not require a new exact-version declaration. Admission is not a claim that every future host has been validated. Native macOS updates also inspect the downloaded official ZIP before installation: checksum, fee implementations, session format, plugin loader, and native update protocol must match a recognized plan. Recognized changes proceed automatically; unknown or changed critical implementations return an installation error while the current app keeps running. Inspection does not execute candidate code, modify the official app, or change pricing and historical data.

The current plan handles version-only changes, comments/whitespace/quote formatting, and new functionality outside the inspected interfaces. Changed fee implementations require an adapter review and validation. The official `0.2.1-rc.3` package and synthetic `0.3.0` acceptance/rejection cases have been checked; actual future releases must pass their own package inspection.

Protection covers native macOS Desktop Check for updates > Download > Install while the fee plugin is enabled. Its settings page reports Host update protection; an unavailable status means the entry is not protected. Manual application replacement, other updaters, disabling/uninstalling this plugin, Web, and other operating systems bypass this gate. A timeout blocks installation first; retrying can reuse the completed check.

The v2 reader follows the pinned DSH `0.1.3-alpha.1` source snapshot [`d347e70390`](https://github.com/deepseek-ai/deepseek-harness/commit/d347e703908d0406b7a7ef80e3a0e594d86b2215). Session format v2 persists each Assistant settlement as an `assistant/message` or `assistant/attempt` with an embedded stream, and its current generation is `session.v2.jsonl(.zstd)`; retained v0/v1 migration sources are not additional calls. Full installation and runtime acceptance on a `0.1.3-alpha.1` host remain incomplete; that host version is outside this package's declared peer range.

V3 accounting was checked against official `dsh-v0.1.5-rc.2` ([`fb2c4b9`](https://github.com/deepseek-ai/deepseek-harness/commit/fb2c4b9e698e30edb738bca4cf0618587db7d203)). Its [codec](https://github.com/deepseek-ai/deepseek-harness/blob/fb2c4b9e698e30edb738bca4cf0618587db7d203/packages/session/session-format-v2-to-v3/src/codec.ts) reuses v2 encoding/decoding; migration preserves embedded streams and token counts. Inserted system messages and remapped inherited cuts add no billable calls. The minimal synthetic accounting fixture `tests/fixtures/session-v3-accounting.jsonl` and its zstd copy cover repeated inherited markers, system replacements, retries, duplicate usage representations and compaction: 3 records, input 43, output 16, cache-read 56, cache-write 9, reasoning 12. This is not full Session validation, host acceptance on `0.1.5-rc.2`, or provider-bill reconciliation; That describes the original v3 reader validation; the current SDK baseline is stated above.

The plugin continues to settle official `compaction/summary.usage` independently and excludes inherited fork prefixes from cross-session totals. It is not a substitute for a provider bill and cannot recover usage upstream never logged. Fields such as `compaction/end` still are not priced without an official usage schema. Repository tests use synthetic fixtures only; no real session log is published.

## Installation

Admits DSH `>=0.2.1-rc.2 <1.0.0-0`, with current SDK validation on `0.2.1-rc.3`; source builds require Node.js `>=22.22.1` and pnpm `9.15.9`. Use the corresponding older plugin release for older DSH versions.

Build an archive from this repository:

```sh
pnpm install --ignore-scripts --frozen-lockfile
pnpm pack
```

`pnpm pack` runs this package's `prepare` build and produces `deepseek-ai-dsh-token-cost-0.5.3.tgz`. In official Desktop, select the local archive under Plugins > Add plugin. Once active conversations and background jobs finish, quit and reopen the app. The application manages its Desktop profile; do not use the Web CLI to modify it.

For Web:

```sh
dsh plugin --profile web add /absolute/path/deepseek-ai-dsh-token-cost-0.5.3.tgz
```

Restart `dsh web`. Session costs appear below the composer; click for details. The Token Cost settings tab provides aggregate statistics. Historical logs are backfilled on first query.

Update the existing package rather than loading two copies. Package identity, settings namespace, ledger location and custom prices are preserved. With local `link:` installs, the profile's `package.json`, `pnpm-lock.yaml`, and installed plugin link must point to the same build; replacing only `node_modules` lets the next package operation restore the old dependency.

If the entry disappears after an upgrade, open this package under Plugins and check its version and error. An exact `engines.dsh 0.2.1-rc.2` requirement identifies the old `0.4.0` build; update to `0.5.3` and reload as directed by the application. This compatibility check rejects the package before executing it. Keep the ledger, custom prices, and session data.

Estimates use recorded usage and configured rates; they are not provider invoices. Automated coverage includes the real SDK Desktop carrier, HTTP authentication, non-owner rejection, price persistence, escaped session IDs, unload/reload, and refreshed totals after new usage. Tests use synthetic records and publish no real session logs.

## Built-in schemes

| Scheme | Effective (Beijing time) | Notes |
|---|---|---|
| A `flat-2026-08` | before 2026-08-17 00:00 | Flat: V4 Flash miss/hit/output = 1 / 0.02 / 2 CNY; V4 Pro = 3 / 0.025 / 6 CNY |
| B `peak-offpeak-2026-08-17` | from 2026-08-17 00:00 | Peak/off-peak every day: V4 Flash peak 3 / 0.1 / 9 CNY; V4 Pro peak 9 / 0.3 / 27 CNY |
| B2 `peak-offpeak-weekdays-2026-08-23` | from 2026-08-23 00:00 | Same rates as B, with peak windows on workdays only and all weekend hours off-peak |
| C `v4.1-flash-2026-09-10` | from 2026-09-10 12:00 | V4.1 Flash cut: peak 2 / 0.04 / 8 CNY; peak windows workdays only; retired `deepseek-v4-flash` names bill at the Flash rate |
| D `v4-pro-to-flash-2026-09-14` | from 2026-09-14 12:00 | `deepseek-v4-pro` is routed to V4.1 Flash and billed at the Flash rate (until V4.1 Pro ships) |

Rates are cache-miss / cache-hit / output CNY per 1M tokens at peak; off-peak bills half. From scheme B2 the peak window is Monday–Friday only (09:00–12:00, 14:00–18:00 UTC+8). B2 is a historical transition used by auto mode; the existing manual A/B/C/D selections retain their meaning.

The historical weekend-policy start date follows the contemporaneous [PR #2](https://github.com/le-soleil-se-couche/dsh-token-cost/pull/2). The [current official pricing page](https://api-docs.deepseek.com/quick_start/pricing/) confirms Monday–Friday peak hours but does not retain that historical effective date.

## Configuration

| Key | Type | Default | Meaning |
|---|---|---|---|
| `enabled` | boolean | `true` | Master switch (stats-line cost + summary card) |
| `currency` | `'cny'` \| `'usd'` | `'cny'` | Display currency |
| `priceMode` | `'auto'` \| `'scheme-a'` \| `'scheme-b'` \| `'scheme-c'` \| `'scheme-d'` | `'auto'` | Auto switches by record time, or force one scheme |
| `customPrices` | string (JSON) | `''` | Legacy settings field; the form now persists to `storages/dsh-token-cost/custom-prices.json` |

All editable from the card's Settings tab; a "Rescan session logs" action forces a full re-parse.

## Development

```sh
pnpm install --frozen-lockfile
pnpm typecheck
pnpm test
pnpm build
pnpm pack
```

The development baseline is Node.js `24.21.0` and pnpm `9.15.9`. Git installation runs `prepare` to build both JavaScript and declarations. The source checkout includes `src/`, `build/`, tests, and the lockfile; the install archive contains `lib/`, the bundle patch, and both READMEs. Entries are `lib/index.js` for the host and `lib/client.js` for the browser (`window.__ModuleLoader__.load` factory), with declarations at `lib/types/index.d.ts` and `lib/types/client/index.d.ts`. Use `npm pack --dry-run --ignore-scripts` to inspect the package file list after building.

After a local build, install with `dsh plugin --profile web add link:/absolute/path/to/dsh-token-cost`. Installation and restart modify that profile, so select your own development profile.

See DESIGN.md for the architecture.

---

*[中文版本](README.md)*
