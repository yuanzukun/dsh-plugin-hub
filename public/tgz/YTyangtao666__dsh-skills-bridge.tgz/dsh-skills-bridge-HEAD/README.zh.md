# dsh-skills-bridge（技能桥）

**把你的 Claude Code 技能带进 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) —— 零迁移，一个插件搞定。**

[![dsh-plugin](https://img.shields.io/badge/topic-dsh--plugin-c9a96e)](https://github.com/topics/dsh-plugin)
[![License: MIT](https://img.shields.io/badge/License-MIT-8ca8d9.svg)](LICENSE)

![实测：Claude Code 技能经 claude-bridge 在 DeepSeek Harness 中被调用](assets/hero-verification.png)

*真实会话（dsh v0.1.0-rc.8）：agent 列出技能目录 —— `pdf-report` 来自 `claude-bridge`（本插件），保留原始 `~/.claude/skills/` 路径；`using-superpowers` 则来自原生文件系统 provider。*

如果你维护着 `~/.claude/skills/` 目录，你其实已经拥有一座技能库。本插件把它作为一等公民 `SkillProvider` 挂载进 DeepSeek Harness —— 每个 `SKILL.md` 都会被发现、frontmatter 自动转换成 DSH 格式，模型可以像调用原生技能一样调用它们。

```text
~/.claude/skills/pdf-report/SKILL.md     ─┐
~/.claude/skills/tiktok-bio-scraper/...   ├─►  dsh-skills-bridge  ─►  ctx.skills  ─►  agent
~/.agents/skills/using-superpowers/       ─┘        (provider: claude-bridge)
```

## 为什么做这个

DeepSeek Harness 的技能系统（`ctx.skills`）设计优雅，但生态只有一周历史。Claude Code 的技能生态庞大——数百个社区技能，每个重度用户都有自己的 `~/.claude/skills`。这座桥让 DSH 第一天就继承整个库。

## 处理了什么

| Claude Code frontmatter | 映射到 | 说明 |
|---|---|---|
| `name`、`description` | 同名同义 | 必填字段，语义一致 |
| `when_to_use` / `when-to-use` | `whenToUse` | 给模型的路由提示 |
| `disable-model-invocation` | `invocation.modelInvocable: false` | 仅用户可调用的技能 |
| `user-invocable` | `invocation.userInvocable` | 命令面板可见性 |
| `allowed-tools`、`license`、自定义键 | 保留进 `metadata` | 绝不丢弃 |

- **冲突策略** —— 桥接技能注册 rank `250`：项目级 DSH 技能（100/200）重名时仍优先；用户级默认（400/500）让位于桥。
- **热更新** —— 可选文件监听器，编辑技能后目录自动失效刷新。
- **零依赖** —— 纯 `node:fs`，无任何 npm 运行时依赖。

## 安装

```sh
dsh plugin --profile web add dsh-skills-bridge
```

完成 —— bundle 的 patch 层自动注册。重启 profile 后，`~/.claude/skills` 与 `~/.agents/skills` 的技能即出现在目录中（来源：`claude-bridge`）。

## 配置

在你的 profile `cordis.patch.yml` 里覆盖：

```yaml
- id: skills-bridge
  name: dsh-skills-bridge
  config:
    skillDirs: []              # 额外扫描目录（默认目录之外）
    includeDefaultRoots: true  # ~/.claude/skills + ~/.agents/skills
    watch: true                # 文件变更热更新
    providerName: claude-bridge
```

## 验证

对 agent 说：*"列出技能目录里所有技能名和 provider 来源"*。来自 Claude Code 的技能会显示 `claude-bridge` provider 和原始 `~/.claude/skills/...` 路径。

## 限制

- 仅支持扁平 frontmatter（真实世界 SKILL.md 所用的子集）；深层嵌套 YAML 会被警告并跳过，与原生 provider 行为一致。
- 技能正文原样透传——正文里的工具引用（如 Claude Code 的 `Read`/`Bash`）由模型自行适配，DSH 有自己的等价工具。
- 监听器基于 `fs.watch`；网络文件系统上请设 `watch: false`。

## 许可

MIT
