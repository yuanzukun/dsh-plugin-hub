/**
 * dsh-skills-bridge — bring Claude Code skills into DeepSeek Harness.
 *
 * Registers a SkillProvider on `ctx.skills` that scans Claude Code skills
 * directories (each `<root>/<skill-name>/SKILL.md`), normalizes the
 * frontmatter differences between Claude Code and DSH skill formats, and
 * exposes every valid skill as a first-class DSH skill.
 *
 * Differences handled:
 *   - `when_to_use` (CC)        -> `whenToUse` (DSH)
 *   - `allowed-tools` (CC)      -> kept in `metadata` (no DSH equivalent)
 *   - `disable-model-invocation`-> mapped to invocation policy
 *   - `user-invocable`          -> mapped to invocation policy
 *   - `license`, `metadata`     -> kept in `metadata`
 *
 * Conflict policy: skills keep rank `SKILLS_BRIDGE_RANK` (250) so that
 * project-local DSH skills (rank 100/200) win on name collisions, while
 * bridge skills override user-level defaults (rank 400/500).
 */
import { access, readdir, readFile, stat, watch } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { homedir } from 'node:os'

export const name = 'skills-bridge'

export const inject = ['skills']

/** Rank between project (100/200) and user (400/500) roots. */
const SKILLS_BRIDGE_RANK = 250

/** Default Claude Code skills roots, in priority order. */
function defaultRoots() {
  const home = homedir()
  return [
    { path: join(home, '.claude', 'skills'), label: 'claude-user' },
    { path: join(home, '.agents', 'skills'), label: 'agents-user' },
  ]
}

async function pathExists(p) {
  try {
    await access(p)
    return true
  } catch {
    return false
  }
}

async function isDirectory(p) {
  try {
    return (await stat(p)).isDirectory()
  } catch {
    return false
  }
}

/* ------------------------------------------------------------------ */
/* Frontmatter parsing                                                 */
/* ------------------------------------------------------------------ */

function parseFrontmatter(raw) {
  const match = /^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/.exec(raw)
  if (!match) return undefined
  const body = raw.slice(match[0].length)
  return { data: parseSimpleYaml(match[1]), content: body }
}

/**
 * Minimal YAML subset parser for SKILL.md frontmatter (flat key: value
 * plus single-line arrays and quoted strings). Claude Code skill files in
 * the wild stay within this subset; anything unparseable is surfaced as an
 * error so the caller can warn and skip the file, exactly like the native
 * filesystem provider does.
 */
function parseSimpleYaml(text) {
  const data = {}
  let errors = 0
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith('#')) continue
    const idx = line.indexOf(':')
    if (idx <= 0) { errors++; continue }
    const key = line.slice(0, idx).trim()
    let value = line.slice(idx + 1).trim()
    if (value === '') {
      data[key] = true
      continue
    }
    // strip quotes
    if ((value.startsWith('"') && value.endsWith('"') && value.length >= 2) ||
        (value.startsWith("'") && value.endsWith("'") && value.length >= 2)) {
      value = value.slice(1, -1)
    }
    // single-line array
    if (value.startsWith('[') && value.endsWith(']')) {
      const inner = value.slice(1, -1).trim()
      data[key] = inner === '' ? [] : inner.split(',').map((s) => {
        let t = s.trim()
        if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'"))) {
          t = t.slice(1, -1)
        }
        return t
      })
      continue
    }
    // booleans
    if (value === 'true') { data[key] = true; continue }
    if (value === 'false') { data[key] = false; continue }
    // numbers stay strings — skill frontmatter fields we consume are strings
    data[key] = value
  }
  if (errors > 0 && Object.keys(data).length === 0) {
    throw new Error('frontmatter is not parseable as flat YAML')
  }
  return data
}

function stringField(data, key) {
  const value = data[key]
  return typeof value === 'string' && value.length > 0 ? value : undefined
}

function booleanField(data, key) {
  const value = data[key]
  return typeof value === 'boolean' ? value : undefined
}

const DSH_KNOWN_KEYS = new Set([
  'name', 'description', 'whenToUse', 'when-to-use', 'whenToUse',
  'disable-model-invocation', 'user-invocable',
])

/** Keys we accept from the Claude Code side. */
const CC_ALIASES = {
  'when_to_use': 'whenToUse',
  'when-to-use': 'whenToUse',
  'allowed-tools': 'allowed-tools',
  'allowed_tools': 'allowed-tools',
}

function isSkillName(name) {
  return /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(name)
}

/* ------------------------------------------------------------------ */
/* Provider                                                            */
/* ------------------------------------------------------------------ */

class SkillsBridgeProvider {
  constructor(ctx, control, config) {
    this.ctx = ctx
    this.control = control
    this.config = config
    this.name = config.providerName || 'claude-bridge'
    this.roots = this.resolveRoots()
  }

  resolveRoots() {
    const roots = []
    const configured = this.config.skillDirs || []
    for (const dir of configured) {
      roots.push({ path: resolve(dir), label: 'custom' })
    }
    if (this.config.includeDefaultRoots !== false) {
      for (const r of defaultRoots()) roots.push(r)
    }
    // de-dup by resolved path
    const seen = new Set()
    return roots.filter((r) => {
      if (seen.has(r.path)) return false
      seen.add(r.path)
      return true
    })
  }

  async list(options) {
    const candidates = []
    let incomplete = false
    for (const root of this.roots) {
      if (!(await pathExists(root.path))) continue
      if (!(await isDirectory(root.path))) continue
      let entries
      try {
        entries = await readdir(root.path, { withFileTypes: true })
      } catch (error) {
        incomplete = true
        this.ctx.logger.warn(
          `[skills-bridge] failed to read ${root.path}: ${error?.message ?? error}`,
        )
        continue
      }
      if (options?.signal?.aborted) return []
      for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
        if (!entry.isDirectory()) continue
        if (entry.name === '.system' || entry.name.startsWith('.')) continue
        const skillPath = join(entry.parentPath ?? root.path, entry.name, 'SKILL.md')
        const parsed = await this.loadSkillFile(skillPath)
        if (!parsed) continue
        candidates.push(this.toCandidate(parsed, skillPath))
      }
    }
    if (incomplete) {
      return { candidates, incomplete: true }
    }
    return candidates
  }

  async get(candidate, options) {
    if (candidate.provider !== this.name) return undefined
    const locator = candidate.locator
    if (!locator || typeof locator !== 'object' || typeof locator.path !== 'string') {
      return undefined
    }
    const parsed = await this.loadSkillFile(locator.path)
    if (!parsed) return undefined
    return {
      ...this.toSummary(parsed, locator.path),
      content: parsed.content,
      path: locator.path,
    }
  }

  async loadSkillFile(path) {
    let raw
    try {
      raw = await readFile(path, 'utf-8')
    } catch {
      return undefined
    }
    let parsed
    try {
      parsed = parseFrontmatter(raw)
    } catch (error) {
      this.ctx.logger.warn(
        `[skills-bridge] skill ${path} ignored: invalid frontmatter: ${error?.message ?? error}`,
      )
      return undefined
    }
    if (!parsed) return undefined

    // Normalize Claude Code aliases into the DSH shape.
    const data = { ...parsed.data }
    for (const [from, to] of Object.entries(CC_ALIASES)) {
      if (data[from] !== undefined && data[to] === undefined) {
        data[to] = data[from]
      }
    }

    const name = stringField(data, 'name') ?? basename(dirname(path))
    const description = stringField(data, 'description')
    if (!description) {
      this.ctx.logger.warn(`[skills-bridge] skill ${path} ignored: missing description`)
      return undefined
    }
    if (!isSkillName(name)) {
      this.ctx.logger.warn(`[skills-bridge] skill ${path} ignored: invalid name "${name}"`)
      return undefined
    }

    const whenToUse = stringField(data, 'whenToUse')
    const disableModel = booleanField(data, 'disable-model-invocation') ?? false
    const userInvocable = booleanField(data, 'user-invocable') ?? true

    // Preserve non-DSH frontmatter keys (allowed-tools, license, etc.)
    const metadata = {}
    for (const [key, value] of Object.entries(parsed.data)) {
      if (!DSH_KNOWN_KEYS.has(key) && !CC_ALIASES[key] && key !== 'name' && key !== 'description') {
        metadata[key] = value
      }
    }

    return {
      name,
      description,
      ...(whenToUse !== undefined ? { whenToUse } : {}),
      invocation: {
        modelInvocable: !disableModel,
        userInvocable,
      },
      metadata: Object.keys(metadata).length > 0 ? metadata : undefined,
      content: parsed.content,
      path,
    }
  }

  toSummary(parsed, path) {
    return {
      name: parsed.name,
      description: parsed.description,
      ...(parsed.whenToUse !== undefined ? { whenToUse: parsed.whenToUse } : {}),
      invocation: parsed.invocation,
      source: 'custom',
      provider: this.name,
      resourceBase: { kind: 'directory', path: dirname(path) },
      ...(parsed.metadata !== undefined ? { metadata: parsed.metadata } : {}),
    }
  }

  toCandidate(parsed, path) {
    return {
      ...this.toSummary(parsed, path),
      rank: SKILLS_BRIDGE_RANK,
      locator: { path },
    }
  }
}

function dirname(p) {
  const idx = p.lastIndexOf('/')
  return idx <= 0 ? '/' : p.slice(0, idx)
}

function basename(p) {
  const idx = p.lastIndexOf('/')
  return idx < 0 ? p : p.slice(idx + 1)
}

/* ------------------------------------------------------------------ */
/* Plugin entry                                                        */
/* ------------------------------------------------------------------ */

export function apply(ctx, config = {}) {
  let provider
  ctx.skills.registerProvider((control) => {
    provider = new SkillsBridgeProvider(ctx, control, config)
    return provider
  })

  // Optional file watching for hot-reload of the skill roots.
  if (config.watch !== false) {
    ctx.effect(() => {
      let disposed = false
      const timers = new Set()
      const controllers = []

      const scheduleInvalidate = () => {
        const timer = setTimeout(() => {
          timers.delete(timer)
          provider?.control?.invalidate?.()
        }, 300)
        timers.add(timer)
      }

      ;(async () => {
        for (const root of provider.roots) {
          if (disposed || !(await pathExists(root.path))) continue
          try {
            const controller = new AbortController()
            controllers.push(controller)
            const watcher = watch(root.path, { recursive: true, signal: controller.signal })
            for await (const _event of watcher) {
              if (disposed) break
              scheduleInvalidate()
            }
          } catch {
            // root vanished or watching unsupported — fine.
          }
        }
      })()

      return () => {
        disposed = true
        for (const t of timers) clearTimeout(t)
        for (const c of controllers) c.abort()
      }
    }, 'skills-bridge watcher')
  }

  ctx.logger.info('[skills-bridge] Claude Code skills bridge loaded')
}
