# dsh-skills-bridge — Launch Kit
发布与推广操作清单（技术侧已全部完成）

## 状态
- ✅ 代码完成 + 端到端验证（dsh v0.1.0-rc.8，agent 真实调用桥接技能）
- ✅ GitHub 已上线：https://github.com/YTyangtao666/dsh-skills-bridge
- ✅ Hero 实测截图已嵌入双语 README（GitHub raw 验证可访问）
- ✅ 6 个 topics（含官方生态入口 dsh-plugin）
- ✅ npm 包名 dsh-skills-bridge 可用（npm view 返回 404 = 无人占用）

## 你需要做的（10 分钟）

### 1. npm 登录 + 发布（一次性）
```sh
npm login          # 浏览器里完成一次认证
cd ~/Desktop/dsh-skills-bridge
npm publish        # 包名可用，直接发
```

### 2. 投放渠道（按 ROI 排序）

**A. DSH 官方 Discord（最高优先级，官方在主动导流插件生态）**
频道：#plugins 或 #showcase
文案：
> dsh-skills-bridge — bring your entire ~/.claude/skills library into DSH as a native SkillProvider. Frontmatter auto-normalized (when_to_use→whenToUse etc.), rank-250 conflict policy, hot-reload, zero deps. One command install: `dsh plugin --profile web add dsh-skills-bridge`. Verified on rc.8 — screenshot in README shows the agent invoking a bridged skill with its claude-bridge source.
> https://github.com/YTyangtao666/dsh-skills-bridge

**B. 两个插件目录站（自动收录 GitHub topics 的，检查即可）**
- https://dshplugin.app
- https://dshplugin.online
如有 Submit 表单就填 repo URL。

**C. Hacker News（Show HN，周二-周四上午美东发最佳）**
标题：Show HN: DSH-Skills-Bridge – Use your Claude Code skills in DeepSeek Harness
正文：
> DeepSeek Harness shipped last week with an elegant plugin system but a young skill ecosystem. This plugin mounts ~/.claude/skills as a native SkillProvider: SKILL.md files are discovered, CC frontmatter is normalized to the DSH schema, and the model invokes them like native skills. Rank 250 conflict policy keeps project skills winning; optional fs watcher hot-reloads. Zero runtime deps. Verified end-to-end on v0.1.0-rc.8 (screenshot in README).

**D. Reddit**
- r/deepseek（发 hero 截图 + 一段话 + repo 链接）
- r/ClaudeAI（角度：你的 skills 投资现在可迁移到 DSH）

**E. V2EX / 即刻 / X（中文圈）**
> DeepSeek Harness 开源一周，写了个插件把 Claude Code 的技能目录直接桥接进去。dsh plugin add 一条命令，~/.claude/skills 全部变成 DSH 一等技能。https://github.com/YTyangtao666/dsh-skills-bridge

### 3. 观察与跟进
- 发布后 48h 是 GitHub trending 窗口，盯 star 曲线
- rc.9 发布时跑一次验证（skill API 若变更及时修）
- 有人开 issue 当天回复（早期回复速度 = 社区信任）

## 增长飞轮（第二周起）
- 若 star 破 100：加 GIF 动图（终端 cat SKILL.md → DSH 调用，10s 对比录屏）
- 若出现用户要 Claude Code 反向桥（DSH skills → CC）：作为 v0.2 路线图
- 组合拳：第二个插件 dsh-cost-insight（token 成本面板）立项，README 互链
