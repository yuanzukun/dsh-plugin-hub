/**
 * Host registration for the theme-colorizer plugin.
 *
 * There is no host-side work: the color theme is persisted in the browser
 * (`localStorage`) rather than the DSH user-settings document. The Host API
 * gateway only exposes settings namespaces on a curated allowlist
 * (`WEB_SETTINGS_NAMESPACES` in the apiproxy); plugin-owned exposure is
 * deferred harness work, and a write to an unlisted namespace is refused with
 * `settings-not-exposed`. Keeping persistence client-side makes the plugin
 * fully self-contained.
 */
import type { Context } from '@deepseek-ai/cordis';
/**
 * Mount the host half. The row still needs a loadable entry so the browser
 * plugin graph is served; all behavior lives in the client half.
 * @param ctx - Host context (unused).
 */
export declare function apply(_ctx: Context): void;
//# sourceMappingURL=index.d.ts.map