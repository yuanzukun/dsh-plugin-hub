/**
 * Color theme settings: constants and type guard shared by the client halves.
 *
 * Persistence is client-side (`localStorage`), not the DSH user-settings
 * document: the Host API gateway only serves settings namespaces on an
 * explicit allowlist (`WEB_SETTINGS_NAMESPACES` in the apiproxy), and
 * plugin-owned exposure is deferred harness work — a write to an unlisted
 * namespace is refused with `settings-not-exposed`. localStorage keeps the
 * plugin fully self-contained and the choice survives page refreshes.
 */
/** Available color theme ids. */
export declare const COLOR_THEME_IDS: readonly ["ocean-blue", "forest-green", "sunset-orange", "royal-purple", "monochrome"];
/** One color theme id. */
export type ColorThemeId = typeof COLOR_THEME_IDS[number];
/** Default color theme when nothing is stored. */
export declare const DEFAULT_COLOR_THEME: ColorThemeId;
/** The localStorage key holding the selected color theme id. */
export declare const COLOR_THEME_STORAGE_KEY = "dsh-theme-colorizer:theme";
/** Durable color-theme section shape (informational; not stored via the settings seam). */
export interface ColorThemeSettings {
    /** Selected color theme id. */
    theme: ColorThemeId;
}
/**
 * Narrow one storage or registry value to a known color theme id.
 * @param value - value read from storage or crossing a boundary.
 * @returns whether the value is a built-in color theme id.
 */
export declare function isColorThemeId(value: unknown): value is ColorThemeId;
//# sourceMappingURL=theme-color-settings.d.ts.map