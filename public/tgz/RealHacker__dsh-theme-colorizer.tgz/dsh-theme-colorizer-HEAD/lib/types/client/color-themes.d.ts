/**
 * Color theme definitions: each theme provides `--dsw-alias-*` token overrides
 * for both light and dark palettes. Tokens are applied via
 * `ctx.theme.overrideTokens()` so the user's light/dark/system preference
 * still controls the base palette.
 */
import type { ThemeTokenOverrides } from '@deepseek-ai/dsh-client-ui-theme/client';
import type { ColorThemeId } from '../theme-color-settings.ts';
/** One color theme: a human-readable label plus the token overrides. */
export interface ColorTheme {
    /** Stable id matching the settings namespace values. */
    id: ColorThemeId;
    /** Alias-token overrides, one per-mode pair per token. */
    tokens: ThemeTokenOverrides;
}
/**
 * All color themes registered by this plugin.
 * Each theme overrides the primary `--dsw-alias-*` semantic tokens.
 * Tokens use the same variable names the built-in base stylesheets consume,
 * so the presenter applies them with zero additional wiring.
 */
export declare const COLOR_THEMES: readonly ColorTheme[];
//# sourceMappingURL=color-themes.d.ts.map