import type { PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { ColorThemeId } from '../theme-color-settings.ts';
import type { createThemeColorizerStore } from './settings-store.ts';
/** Injected business face: the color-theme write. */
export interface ThemeColorRowInjected {
    /** Switch the color theme. */
    setColorTheme: (id: ColorThemeId) => void;
}
/** Full component props: runtime share + store share + locale seat + injected face. */
export type ThemeColorRowComponentProps = PropsRuntime<'settings.general.item'> & PropsStore<ReturnType<typeof createThemeColorizerStore>> & PropsLocale<'settings.theme-colorizer'> & ThemeColorRowInjected;
/**
 * Render the Color Theme row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function ThemeColorRow({ t, useStore, setColorTheme }: ThemeColorRowComponentProps): import("react").JSX.Element;
//# sourceMappingURL=ThemeColorRow.d.ts.map