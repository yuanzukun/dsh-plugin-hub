/**
 * Theme Colorizer row slot store: a mirror of the currently selected color
 * theme. The plugin's apply-world change listener is the only writer; the row
 * component reads via props.useStore.
 */
import { type EngineStoreHandle } from '@deepseek-ai/dsh-client-runtime/client';
import { type ColorThemeId } from '../theme-color-settings.ts';
/** Store state: the active color theme id. */
export interface ThemeColorizerState {
    /** Currently selected color theme id. */
    activeTheme: ColorThemeId;
}
/** Declared action shape giving the exported factory a stable return type. */
type ThemeColorizerActions = {
    sync: (draft: ThemeColorizerState, activeTheme: ColorThemeId) => void;
};
/**
 * Declares the Theme Colorizer row state and write surface.
 * @returns the store handle.
 */
export declare function createThemeColorizerStore(): EngineStoreHandle<ThemeColorizerState, ThemeColorizerActions>;
export {};
//# sourceMappingURL=settings-store.d.ts.map