import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type ThemeColorizerKey } from './locales.ts';
export type { ThemeColorRowComponentProps, ThemeColorRowInjected } from './ThemeColorRow.tsx';
export type { ColorTheme } from './color-themes.ts';
export type { ColorThemeId, ColorThemeSettings } from '../theme-color-settings.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Color Theme settings row's copy. */
        'settings.theme-colorizer': ThemeColorizerKey;
    }
}
/** Required services. `theme` is injected so `ctx.theme` is guaranteed by apply time. */
export declare const inject: string[];
/**
 * Client plugin body: read the stored color theme, apply it as an override
 * layer, and register the feature-owned Color Theme preference row into the
 * General section's item slot.
 * @param ctx - client cordis context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map