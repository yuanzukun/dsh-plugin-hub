/** `settings.theme-colorizer` namespace dictionaries (the Color Theme row's copy). */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'color-theme.title': string;
    'color-theme.ocean-blue': string;
    'color-theme.forest-green': string;
    'color-theme.sunset-orange': string;
    'color-theme.royal-purple': string;
    'color-theme.monochrome': string;
};
/** The settings.theme-colorizer namespace key union. */
export type ThemeColorizerKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'color-theme.title': string;
    'color-theme.ocean-blue': string;
    'color-theme.forest-green': string;
    'color-theme.sunset-orange': string;
    'color-theme.royal-purple': string;
    'color-theme.monochrome': string;
};
//# sourceMappingURL=locales.d.ts.map