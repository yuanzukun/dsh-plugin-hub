/**
 * tsdown config for the theme-colorizer client plugin bundle.
 * Uses the shared clientBundle preset from the dsh repo.
 *
 * When placed inside the deepseek-harness repo as a packages/client/* package,
 * this preset emits both the node-half lib and the browser client bundle.
 * The import path assumes the plugin lives at packages/client/dsh-theme-colorizer/.
 */
import { clientBundle } from '../tsdown.client.ts'

export default clientBundle(
  'dsh-theme-colorizer',
  ['lib/types/index.js', 'lib/types/invariant.js'],
)