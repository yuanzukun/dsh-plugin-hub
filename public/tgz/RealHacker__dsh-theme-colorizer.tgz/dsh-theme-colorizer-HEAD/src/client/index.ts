/**
 * Browser half of the theme-colorizer plugin. Provides:
 * 1. A `ctx.theme.overrideTokens()` layer that applies the selected color
 *    theme's `--dsw-alias-*` overrides on top of the active base palette.
 * 2. A settings General section row for the user to pick a color theme.
 *
 * Persistence is browser-local (`localStorage`), not the DSH user-settings
 * document: the Host API gateway only exposes settings namespaces on a
 * curated allowlist, so a plugin-owned namespace cannot be written through the
 * wire (`settings-not-exposed`). localStorage keeps the plugin self-contained
 * and the choice survives page refreshes; a `storage` listener keeps other
 * tabs in sync.
 *
 * The color theme is independent of the light/dark/system preference: the user
 * picks a base palette through the built-in Appearance row, and a color theme
 * through this row. Both layers compose through the theme service's override
 * stacking.
 */
import type { BoundActions } from '@deepseek-ai/dsh-client-ui-slots'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: the ctx.theme Context merge so we can read the theme service.
import type {} from '@deepseek-ai/dsh-client-ui-theme/client'
// Type-only: pulls the locale plugin's Context merge (ctx.locale).
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type { ThemeColorRowInjected } from './ThemeColorRow.tsx'
import { ThemeColorRow } from './ThemeColorRow.tsx'
import { createThemeColorizerStore } from './settings-store.ts'
import { COLOR_THEMES } from './color-themes.ts'
import { en, zh, type ThemeColorizerKey } from './locales.ts'
import {
  COLOR_THEME_STORAGE_KEY, DEFAULT_COLOR_THEME, isColorThemeId,
  type ColorThemeId,
} from '../theme-color-settings.ts'

export type { ThemeColorRowComponentProps, ThemeColorRowInjected } from './ThemeColorRow.tsx'
export type { ColorTheme } from './color-themes.ts'
export type { ColorThemeId, ColorThemeSettings } from '../theme-color-settings.ts'

/** Namespace owning this feature's settings-row copy. */
const SETTINGS_NS = 'settings.theme-colorizer'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The Color Theme settings row's copy. */
    'settings.theme-colorizer': ThemeColorizerKey
  }
}

/** Required services. `theme` is injected so `ctx.theme` is guaranteed by apply time. */
export const inject = ['slots', 'locale', 'theme']

/**
 * Client plugin body: read the stored color theme, apply it as an override
 * layer, and register the feature-owned Color Theme preference row into the
 * General section's item slot.
 * @param ctx - client cordis context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(SETTINGS_NS, { zh, en }), 'theme-colorizer: settings row dictionaries')

  // Keep the active override layer handle so we can swap it on theme change.
  let overrideDisposer: (() => void) | undefined

  /** Apply the token overrides for one color theme id. */
  function applyTheme(id: ColorThemeId): void {
    overrideDisposer?.()
    const theme = COLOR_THEMES.find(t => t.id === id)
    if (theme) {
      overrideDisposer = ctx.theme.overrideTokens('dsh-theme-colorizer', theme.tokens)
    }
  }

  /** Read the stored color theme id, falling back to the default. */
  function readStored(): ColorThemeId {
    try {
      const raw = localStorage.getItem(COLOR_THEME_STORAGE_KEY)
      if (raw !== null && isColorThemeId(raw)) return raw
    } catch {
      // Storage unavailable (private mode, sandboxed iframe) — keep the default.
    }
    return DEFAULT_COLOR_THEME
  }

  /** Persist one color theme id; failures are non-fatal. */
  function persist(id: ColorThemeId): void {
    try {
      localStorage.setItem(COLOR_THEME_STORAGE_KEY, id)
    } catch {
      // Storage unavailable — the theme still applies for this session.
    }
  }

  // Read the stored preference and apply it (synchronous — no first-paint race).
  let currentTheme: ColorThemeId = readStored()
  applyTheme(currentTheme)

  // Register the General settings row.
  const store = createThemeColorizerStore()
  let bound: BoundActions<typeof store> | undefined
  const injected = (actions: BoundActions<typeof store>): ThemeColorRowInjected => {
    bound = actions
    bound.sync(currentTheme)
    return {
      setColorTheme: (id: ColorThemeId) => {
        currentTheme = id
        applyTheme(id)
        bound?.sync(id)
        persist(id)
      },
    }
  }
  ctx.slots.inject('settings.general.item', () => ctx.slots.register({
    name: 'settings.general.item',
    id: 'theme-colorizer',
    order: 20,
    store,
    locale: SETTINGS_NS,
    inject: injected,
  }, ThemeColorRow))

  // Keep other tabs in sync: the storage event fires only in tabs that did
  // not write the value.
  ctx.effect(() => {
    const onStorage = (event: StorageEvent): void => {
      if (event.key !== COLOR_THEME_STORAGE_KEY) return
      const next = readStored()
      currentTheme = next
      applyTheme(next)
      bound?.sync(next)
    }
    window.addEventListener('storage', onStorage)
    return () => { window.removeEventListener('storage', onStorage) }
  }, 'theme-colorizer: cross-tab storage listener')
}