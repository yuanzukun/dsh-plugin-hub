/** `settings.theme-colorizer` namespace dictionaries (the Color Theme row's copy). */

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh = {
  'color-theme.title': '配色主题',
  'color-theme.ocean-blue': '深海蓝',
  'color-theme.forest-green': '森林绿',
  'color-theme.sunset-orange': '日落橙',
  'color-theme.royal-purple': '皇家紫',
  'color-theme.monochrome': '极简灰',
} satisfies Record<string, string>

/** The settings.theme-colorizer namespace key union. */
export type ThemeColorizerKey = keyof typeof zh

/** English dictionary, checked complete against the zh key set. */
export const en = {
  'color-theme.title': 'Color Theme',
  'color-theme.ocean-blue': 'Ocean Blue',
  'color-theme.forest-green': 'Forest Green',
  'color-theme.sunset-orange': 'Sunset Orange',
  'color-theme.royal-purple': 'Royal Purple',
  'color-theme.monochrome': 'Monochrome',
} satisfies Record<ThemeColorizerKey, string>