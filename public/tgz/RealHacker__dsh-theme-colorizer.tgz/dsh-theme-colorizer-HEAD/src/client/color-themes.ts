/**
 * Color theme definitions: each theme provides `--dsw-alias-*` token overrides
 * for both light and dark palettes. Tokens are applied via
 * `ctx.theme.overrideTokens()` so the user's light/dark/system preference
 * still controls the base palette.
 */

import type { ThemeTokenOverrides } from '@deepseek-ai/dsh-client-ui-theme/client'
import type { ColorThemeId } from '../theme-color-settings.ts'

/** One color theme: a human-readable label plus the token overrides. */
export interface ColorTheme {
  /** Stable id matching the settings namespace values. */
  id: ColorThemeId
  /** Alias-token overrides, one per-mode pair per token. */
  tokens: ThemeTokenOverrides
}

/**
 * All color themes registered by this plugin.
 * Each theme overrides the primary `--dsw-alias-*` semantic tokens.
 * Tokens use the same variable names the built-in base stylesheets consume,
 * so the presenter applies them with zero additional wiring.
 */
export const COLOR_THEMES: readonly ColorTheme[] = [
  {
    id: 'ocean-blue',
    tokens: {
      '--dsw-alias-brand-primary':         { light: '#1a6fb5', dark: '#4da6e8' },
      '--dsw-alias-bg-base':               { light: '#f0f5fa', dark: '#0d1b2a' },
      '--dsw-alias-bg-layer-1':            { light: '#e3edf5', dark: '#132a42' },
      '--dsw-alias-bg-layer-2':            { light: '#d6e4f0', dark: '#1a3658' },
      '--dsw-alias-bg-overlay':            { light: '#ffffff', dark: '#1b2838' },
      '--dsw-alias-border-l1':             { light: '#c4d8e8', dark: '#1e3a5f' },
      '--dsw-alias-border-l2':             { light: '#a8c4db', dark: '#2a4a6f' },
      '--dsw-alias-label-primary':         { light: '#0f2b45', dark: '#dce8f2' },
      '--dsw-alias-label-secondary':       { light: '#4a6d8c', dark: '#8aaccc' },
      '--dsw-alias-state-error-primary':   { light: '#c0392b', dark: '#e74c3c' },
      '--dsw-alias-state-success-primary': { light: '#27ae60', dark: '#2ecc71' },
      '--dsw-alias-state-warn-primary':    { light: '#d4a017', dark: '#f1c40f' },
      '--dsw-specific-sidebar-fill':       { light: '#dce8f2', dark: '#0f1f33' },
    },
  },
  {
    id: 'forest-green',
    tokens: {
      '--dsw-alias-brand-primary':         { light: '#2d7d46', dark: '#4caf6e' },
      '--dsw-alias-bg-base':               { light: '#f2f7f0', dark: '#0f1a10' },
      '--dsw-alias-bg-layer-1':            { light: '#e5f0e2', dark: '#162616' },
      '--dsw-alias-bg-layer-2':            { light: '#d8e8d4', dark: '#1e331e' },
      '--dsw-alias-bg-overlay':            { light: '#ffffff', dark: '#1a2818' },
      '--dsw-alias-border-l1':             { light: '#c4dcc0', dark: '#234528' },
      '--dsw-alias-border-l2':             { light: '#a8cfa4', dark: '#2f5a34' },
      '--dsw-alias-label-primary':         { light: '#1a3018', dark: '#dce8da' },
      '--dsw-alias-label-secondary':       { light: '#4a6e40', dark: '#8cb880' },
      '--dsw-alias-state-error-primary':   { light: '#c0392b', dark: '#e74c3c' },
      '--dsw-alias-state-success-primary': { light: '#27ae60', dark: '#2ecc71' },
      '--dsw-alias-state-warn-primary':    { light: '#d4a017', dark: '#f1c40f' },
      '--dsw-specific-sidebar-fill':       { light: '#dce8d6', dark: '#0f1a12' },
    },
  },
  {
    id: 'sunset-orange',
    tokens: {
      '--dsw-alias-brand-primary':         { light: '#d4742c', dark: '#f0a050' },
      '--dsw-alias-bg-base':               { light: '#fdf6f0', dark: '#1f140c' },
      '--dsw-alias-bg-layer-1':            { light: '#fae9dc', dark: '#2a1a10' },
      '--dsw-alias-bg-layer-2':            { light: '#f5dcc8', dark: '#362214' },
      '--dsw-alias-bg-overlay':            { light: '#ffffff', dark: '#281c14' },
      '--dsw-alias-border-l1':             { light: '#e8c8a8', dark: '#3e2a1a' },
      '--dsw-alias-border-l2':             { light: '#dbb48c', dark: '#503622' },
      '--dsw-alias-label-primary':         { light: '#3d2010', dark: '#f0e0d0' },
      '--dsw-alias-label-secondary':       { light: '#8c5e3c', dark: '#c8a080' },
      '--dsw-alias-state-error-primary':   { light: '#c0392b', dark: '#e74c3c' },
      '--dsw-alias-state-success-primary': { light: '#27ae60', dark: '#2ecc71' },
      '--dsw-alias-state-warn-primary':    { light: '#d4a017', dark: '#f1c40f' },
      '--dsw-specific-sidebar-fill':       { light: '#f5e4d4', dark: '#1a1008' },
    },
  },
  {
    id: 'royal-purple',
    tokens: {
      '--dsw-alias-brand-primary':         { light: '#6b3fa0', dark: '#9b6fd4' },
      '--dsw-alias-bg-base':               { light: '#f6f2fa', dark: '#15101f' },
      '--dsw-alias-bg-layer-1':            { light: '#ede3f5', dark: '#1e162d' },
      '--dsw-alias-bg-layer-2':            { light: '#e0d4f0', dark: '#281e3a' },
      '--dsw-alias-bg-overlay':            { light: '#ffffff', dark: '#1f1828' },
      '--dsw-alias-border-l1':             { light: '#d0c0e4', dark: '#2e2445' },
      '--dsw-alias-border-l2':             { light: '#bca8d8', dark: '#3e3058' },
      '--dsw-alias-label-primary':         { light: '#1f1030', dark: '#e0d4f0' },
      '--dsw-alias-label-secondary':       { light: '#6a4c8c', dark: '#b098c8' },
      '--dsw-alias-state-error-primary':   { light: '#c0392b', dark: '#e74c3c' },
      '--dsw-alias-state-success-primary': { light: '#27ae60', dark: '#2ecc71' },
      '--dsw-alias-state-warn-primary':    { light: '#d4a017', dark: '#f1c40f' },
      '--dsw-specific-sidebar-fill':       { light: '#e8dcef', dark: '#100c18' },
    },
  },
  {
    id: 'monochrome',
    tokens: {
      '--dsw-alias-brand-primary':         { light: '#3a3a3a', dark: '#a0a0a0' },
      '--dsw-alias-bg-base':               { light: '#f5f5f5', dark: '#121212' },
      '--dsw-alias-bg-layer-1':            { light: '#ebebeb', dark: '#1a1a1a' },
      '--dsw-alias-bg-layer-2':            { light: '#e0e0e0', dark: '#242424' },
      '--dsw-alias-bg-overlay':            { light: '#ffffff', dark: '#1e1e1e' },
      '--dsw-alias-border-l1':             { light: '#d0d0d0', dark: '#2a2a2a' },
      '--dsw-alias-border-l2':             { light: '#b8b8b8', dark: '#383838' },
      '--dsw-alias-label-primary':         { light: '#1a1a1a', dark: '#e8e8e8' },
      '--dsw-alias-label-secondary':       { light: '#5c5c5c', dark: '#aaaaaa' },
      '--dsw-alias-state-error-primary':   { light: '#c0392b', dark: '#e74c3c' },
      '--dsw-alias-state-success-primary': { light: '#27ae60', dark: '#2ecc71' },
      '--dsw-alias-state-warn-primary':    { light: '#d4a017', dark: '#f1c40f' },
      '--dsw-specific-sidebar-fill':       { light: '#e8e8e8', dark: '#0e0e0e' },
    },
  },
]