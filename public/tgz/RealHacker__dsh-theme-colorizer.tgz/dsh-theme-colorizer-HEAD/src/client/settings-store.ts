/**
 * Theme Colorizer row slot store: a mirror of the currently selected color
 * theme. The plugin's apply-world change listener is the only writer; the row
 * component reads via props.useStore.
 */
import { defineStore, type EngineStoreHandle } from '@deepseek-ai/dsh-client-runtime/client'
import { DEFAULT_COLOR_THEME, type ColorThemeId } from '../theme-color-settings.ts'

/** Store state: the active color theme id. */
export interface ThemeColorizerState {
  /** Currently selected color theme id. */
  activeTheme: ColorThemeId
}

/** Declared action shape giving the exported factory a stable return type. */
type ThemeColorizerActions = {
  sync: (draft: ThemeColorizerState, activeTheme: ColorThemeId) => void
}

/**
 * Declares the Theme Colorizer row state and write surface.
 * @returns the store handle.
 */
export function createThemeColorizerStore(): EngineStoreHandle<ThemeColorizerState, ThemeColorizerActions> {
  return defineStore({
    init: (): ThemeColorizerState => ({ activeTheme: DEFAULT_COLOR_THEME }),
    actions: {
      sync: (d, activeTheme: ColorThemeId) => {
        d.activeTheme = activeTheme
      },
    },
  })
}