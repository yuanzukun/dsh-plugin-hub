/**
 * Color Theme row registered into the General section item slot: a title plus
 * a row of color-theme swatches. Registered by this plugin — the color-theme
 * feature owns its own settings surface.
 */
import clsx from 'clsx'
import type { PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type { ColorThemeId } from '../theme-color-settings.ts'
import { COLOR_THEMES } from './color-themes.ts'
import type { ThemeColorizerKey } from './locales.ts'
import type { createThemeColorizerStore } from './settings-store.ts'
import css from './ThemeColorRow.module.css'

/** Injected business face: the color-theme write. */
export interface ThemeColorRowInjected {
  /** Switch the color theme. */
  setColorTheme: (id: ColorThemeId) => void
}

/** Full component props: runtime share + store share + locale seat + injected face. */
export type ThemeColorRowComponentProps =
  PropsRuntime<'settings.general.item'>
  & PropsStore<ReturnType<typeof createThemeColorizerStore>>
  & PropsLocale<'settings.theme-colorizer'>
  & ThemeColorRowInjected

/** Swatch display order and label keys. */
const SWATCHES: readonly { id: ColorThemeId; labelKey: ThemeColorizerKey; cssVar: string }[] = COLOR_THEMES.map(theme => ({
  id: theme.id,
  labelKey: `color-theme.${theme.id}` as ThemeColorizerKey,
  // Derive a representative swatch color from the brand-primary light token.
  cssVar: theme.tokens['--dsw-alias-brand-primary']?.light ?? '#4D6BFE',
}))

/**
 * Render the Color Theme row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export function ThemeColorRow({ t, useStore, setColorTheme }: ThemeColorRowComponentProps) {
  const activeTheme = useStore(s => s.activeTheme)
  return (
    <div className={css.group}>
      <div className={css.title}>{t('color-theme.title')}</div>
      <div className={css.swatchRow}>
        {SWATCHES.map(({ id, labelKey, cssVar }) => (
          <button
            key={id}
            type="button"
            className={clsx(css.swatch, activeTheme === id && css.selected)}
            aria-pressed={activeTheme === id}
            title={t(labelKey)}
            onClick={() => { setColorTheme(id) }}
          >
            <span className={css.swatchColor} style={{ backgroundColor: cssVar }} />
            <span className={css.swatchLabel}>{t(labelKey)}</span>
          </button>
        ))}
      </div>
    </div>
  )
}