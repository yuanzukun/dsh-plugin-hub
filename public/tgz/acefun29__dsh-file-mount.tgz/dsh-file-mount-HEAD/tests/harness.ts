/**
 * Integration harness: the real agent loop with the real `read` tool over a
 * local filesystem, a scripted mock LLM adapter, and the file-mount plugin —
 * the same composition the interception contract tests use (see
 * packages/core/agent-loop/tests/interception.spec.ts in the harness repo).
 */
import { Context } from '@deepseek-ai/cordis'
import type { GenerateOptions, LlmModelReasoningInfo, LlmResolvedModelInfo, MessageSource, StreamChunk } from '@deepseek-ai/dsh-llm'
import { ToolCallId, LlmAdapter, LlmRuntime } from '@deepseek-ai/dsh-llm'
import SessionStore from '@deepseek-ai/dsh-session'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import AgentRegistry from '@deepseek-ai/dsh-agent'
import type { Agent } from '@deepseek-ai/dsh-agent'
import AgentLoop from '@deepseek-ai/dsh-agent-loop'
import { SessionProjectionRegistry } from '@deepseek-ai/dsh-session-projection'
import LocalFileSystem from '@deepseek-ai/dsh-fs-local'
import * as toolFs from '@deepseek-ai/dsh-tool-fs'
import { apply as fileMountApply, type Config } from '../src/index.ts'

export interface HarnessOptions {
  /** Filesystem base directory for the read tool. */
  cwd: string
  /** Plugin kill switch (defaults to enabled). */
  enabled?: boolean
  /** Extra plugin config (e.g. minSavedTokens). */
  config?: Config
  /** Runs after the tooling plugins but BEFORE the file-mount plugin, so a
   * listener registered here is inner relative to the plugin's own
   * post-execute handler (next() inside the plugin reaches it first). */
  injectListener?: (ctx: Context) => void
}

/** Scripted adapter: each model call consumes the next script entry. */
export class MockAdapter extends LlmAdapter {
  private readonly script: (StreamChunk[] | ((options: GenerateOptions) => StreamChunk[]))[]
  private readonly reasoning: LlmModelReasoningInfo | undefined

  constructor(
    script: (StreamChunk[] | ((options: GenerateOptions) => StreamChunk[]))[],
    reasoning?: LlmModelReasoningInfo,
  ) {
    super()
    this.script = script
    this.reasoning = reasoning
  }

  override resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo> {
    return Promise.resolve({
      provider,
      id: model,
      name: model,
      ...this.reasoning === undefined ? {} : { reasoning: this.reasoning },
    })
  }

  async * stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    const entry = this.script.shift()
    if (!entry) throw new Error('MockAdapter: script exhausted')
    const chunks = typeof entry === 'function' ? entry(options) : entry
    for (const chunk of chunks) {
      if (options.signal?.aborted) throw new Error('aborted')
      yield chunk
    }
  }
}

export function textResponse(text: string): StreamChunk[] {
  return [
    { type: 'block-start', index: 0, blockType: 'text' },
    ...Array.from(text, (char): StreamChunk => ({ type: 'text-delta', index: 0, text: char })),
    { type: 'block-end', index: 0, block: { type: 'text', text } },
    { type: 'usage', usage: { inputTokens: 10, outputTokens: text.length } },
    { type: 'finish', reason: { kind: 'stop' } },
  ]
}

export function toolCallResponse(rawCallId: string, name: string, args: object, usageInputTokens = 10, cacheReadTokens?: number): StreamChunk[] {
  const callId = ToolCallId(rawCallId)
  const argumentsJson = JSON.stringify(args)
  return [
    { type: 'block-start', index: 0, blockType: 'tool-call' },
    { type: 'tool-call-delta', index: 0, id: callId, name, argumentsDelta: argumentsJson.slice(0, 5) },
    { type: 'tool-call-delta', index: 0, id: callId, argumentsDelta: argumentsJson.slice(5) },
    { type: 'block-end', index: 0, block: { type: 'tool-call', id: callId, name, arguments: argumentsJson } },
    {
      type: 'usage',
      usage: {
        inputTokens: usageInputTokens,
        outputTokens: 5,
        ...cacheReadTokens !== undefined ? { cacheReadTokens } : {},
      },
    },
    { type: 'finish', reason: { kind: 'tool-calls' } },
  ]
}

/** Boot the composed harness and register the mock adapter. */
export async function harness(adapter: MockAdapter, options: HarnessOptions): Promise<Context> {
  const ctx = new Context()
  await ctx.plugin(LlmRuntime)
  await ctx.plugin(SessionStore)
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(SessionProjectionRegistry)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(AgentRegistry)
  await ctx.plugin(AgentLoop, { agents: [] })
  await ctx.plugin(LocalFileSystem, { cwd: options.cwd })
  await ctx.plugin(toolFs, {})
  // Tests that must see or alter what the plugin's own post-execute handler
  // observes (shape drift) register their listener BEFORE the plugin, so it
  // sits inner in the waterfall — next() inside the plugin runs it.
  options.injectListener?.(ctx)
  await ctx.plugin(fileMountApply, { enabled: options.enabled ?? true, ...options.config })
  ctx.llm.registerAdapter(['mock'], adapter)
  return ctx
}

/** Wait until the agent settles back to idle after a followup. */
export function waitForIdle(ctx: Context, agent: { readonly id: unknown }): Promise<void> {
  return new Promise((resolve) => {
    const dispose = ctx.on('agent/status', ({ agent: subject, status }) => {
      if (subject === agent && status === 'idle') {
        dispose()
        resolve()
      }
    })
  })
}

/**
 * The tool/result text for one call id. DSH 0.1.7 stores the call id on the
 * tool message and the text blocks directly in its content; DSH 0.1.6 wraps
 * them in one `tool-result` block carrying the call id.
 */
export function toolResultText(agent: Agent, callId: string): string | undefined {
  for (const event of agent.session.snapshotEvents()) {
    if (event.type !== 'tool/result') continue
    const message = event.data.message as unknown as { toolCallId?: string; content: readonly Record<string, unknown>[] }
    const first = message.content[0]
    const wrapped = first?.['type'] === 'tool-result' && first['toolCallId'] === callId
    if (message.toolCallId !== callId && !wrapped) continue
    const blocks = (wrapped ? first['content'] : message.content) as readonly Record<string, unknown>[]
    return blocks.map((item) => item['type'] === 'text' ? item['text'] as string : '').join('')
  }
  return undefined
}

/** Source of a compaction checkpoint as DSH 0.1.7 writes it. */
export const COMPACT_CHECKPOINT_SOURCE = { kind: 'compact-checkpoint', compactionId: 'test-compaction' } as unknown as MessageSource
