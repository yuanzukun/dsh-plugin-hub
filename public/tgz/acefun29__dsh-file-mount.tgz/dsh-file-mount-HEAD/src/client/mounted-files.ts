/**
 * Client-side fold of the mount ledger: one entry per mounted file, upserted
 * from the plugin-injected context messages in conversation-node order. The
 * host's structured message source is the durable carrier, so this fold works
 * live and on resumed history alike. Validation and the merge rule come from
 * mount-source.ts — the SAME rule the host replays with (plan item 20).
 *
 * The browser conversation is a PAGINATED history window (tail page first,
 * older pages only on scroll), so `snapshot.nodes` shrinks at the head as the
 * session grows. {@link MountFold} therefore persists its per-session state
 * across snapshot revisions: a mount message that scrolls out of the loaded
 * window keeps its file on the dashboard, and re-delivered messages are
 * folded exactly once (no double token counts). `foldMounts` remains as the
 * stateless one-shot fold for tests and one-off consumers.
 *
 * Freshness (attention-decay plan): assistant nodes expose per-request usage,
 * so the fold also derives the current context length — the FULL prompt
 * (uncached input + cacheRead + cacheWrite; DSH counts are disjoint) — and
 * each segment's `born` position then maps to a display level (fresh/ok/warn/
 * expired/unknown) via pressure × depth against the host-stamped threshold.
 */
import type { ConversationNode } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { LedgerSegment } from '../types.ts'
import {
  applyMountState,
  calculateFreshnessScore,
  DEFAULT_FRESHNESS_CONFIG,
  parseMountSource,
  type FreshnessOptions,
  type MountDelta,
  type MountState,
} from '../mount-source.ts'
/** One mounted file as the view presents it. */
export interface MountedFileView {
  /** Normalized absolute path (ledger identity). */
  path: string
  /** Short (8-char) content hash for the identity column. */
  hash: string
  /** Line count of the file at hash time. */
  totalLines: number
  /** Mounted ranges, normalized ascending, with freshness metadata. */
  ranges: LedgerSegment[]
  /** How the ledger changed last. */
  mountKind: 'new' | 'increment' | 'remount' | 'dedup'
  /** Cumulative tokens kept out of the context for this path. */
  savedTokens: number
  /** Cumulative tokens the plugin's own notes cost for this path. */
  spentTokens: number
  /** Source message seq (stable ordering). */
  seq: number
  /** Current context length (latest request input tokens), for freshness. */
  contextL?: number
  /** Freshness expiry threshold for display (the plugin's default; the host
   * no longer writes its configured value into the message source). */
  freshnessThreshold: number
}

/** Display levels for one segment's freshness. */
export type FreshnessLevel = 'fresh' | 'ok' | 'warn' | 'expired' | 'unknown'

/**
 * Freshness level from pressure × depth: short prompts stay fresh; deep
 * content only decays near the window cap. Pinned segments score as fresh.
 */
export function freshnessLevel(
  born: number | undefined,
  contextL: number | undefined,
  threshold: number = DEFAULT_FRESHNESS_CONFIG.threshold,
  tokens?: number,
  options?: FreshnessOptions,
): FreshnessLevel {
  if (born === undefined || contextL === undefined || contextL < 1) return 'unknown'
  if (born >= contextL) return 'fresh'
  const score = calculateFreshnessScore(born, contextL, tokens, options)
  if (score < threshold) return 'expired'
  if (score < threshold + 0.15) return 'warn'
  if (score < 0.85) return 'ok'
  return 'fresh'
}

/**
 * File-level freshness: expired beats warn beats ok; unknown is its own
 * gray state and must not collapse to green fresh.
 */
export function worstFreshness(levels: readonly FreshnessLevel[]): FreshnessLevel {
  if (levels.includes('expired')) return 'expired'
  if (levels.includes('warn')) return 'warn'
  if (levels.includes('ok')) return 'ok'
  if (levels.includes('unknown') || levels.length === 0) return 'unknown'
  return 'fresh'
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

/** Stable empty node list: a fresh array per selector call would loop useSyncExternalStore. */
export const EMPTY_NODES: readonly ConversationNode[] = Object.freeze([])

/**
 * The assembled conversation nodes for the dashboard fold, read out of a
 * snapshot the shell hands a selector. DSH 0.1.5 split the old single
 * snapshot: `useSession` carries session state (queue/lifecycle) and the
 * generic node list now hangs off the Conversation snapshot's registered Chat
 * target (`views.get('chat').legacy.nodes`); older builds exposed it directly
 * as a top-level `nodes` field. Duck-typed in one place so either layout
 * works and a missing one degrades to the empty state instead of crashing.
 * @param snapshot - the snapshot handed to a `useSession`/`useConversation` selector.
 * @returns the node list, or a stable empty array when the layout is unknown.
 */
export function conversationNodes(snapshot: unknown): readonly ConversationNode[] {
  if (!isRecord(snapshot)) return EMPTY_NODES
  const top = snapshot['nodes']
  if (Array.isArray(top)) return top as readonly ConversationNode[]
  const views = snapshot['views']
  if (!isRecord(views)) return EMPTY_NODES
  const get = views['get']
  if (typeof get !== 'function') return EMPTY_NODES
  const chat = (get as (target: string) => unknown).call(views, 'chat')
  if (!isRecord(chat)) return EMPTY_NODES
  const legacy = chat['legacy']
  if (!isRecord(legacy)) return EMPTY_NODES
  const nodes = legacy['nodes']
  return Array.isArray(nodes) ? nodes as readonly ConversationNode[] : EMPTY_NODES
}

/**
 * Full prompt length of an assistant node's usage, or undefined when absent.
 * DSH's TokenUsage counts are DISJOINT: `inputTokens` is the uncached input
 * only, with the cached prefix reported separately as cacheReadTokens /
 * cacheWriteTokens — the real context length is the sum of all three.
 */
function contextLengthOf(node: ConversationNode): number | undefined {
  if (node.kind !== 'assistant') return undefined
  const usage = (node as unknown as Record<string, unknown>)['usage']
  if (!isRecord(usage)) return undefined
  const parts = [usage['inputTokens'], usage['cacheReadTokens'], usage['cacheWriteTokens']]
    .filter((v): v is number => typeof v === 'number' && Number.isFinite(v) && v >= 0)
  if (parts.length === 0) return undefined
  return parts.reduce((total, part) => total + part, 0)
}

/** One stored mount message for a path, kept for ordered re-derivation. */
interface StoredMount {
  seq: number
  kind: 'new' | 'increment' | 'remount' | 'dedup'
  delta: MountDelta
}

/**
 * Stateful fold that survives the client's paginated history window. Per
 * session it keeps every validated mount message per path and re-derives the
 * entry in seq order on each fold, so (a) messages that scroll out of the
 * loaded window keep their file visible, (b) re-delivered messages fold
 * exactly once, and (c) older messages arriving later (page-up) cannot
 * overwrite newer state. A sessionId change resets the accumulated state.
 */
export class MountFold {
  private sessionId: string | undefined
  private readonly paths = new Map<string, StoredMount[]>()
  private readonly folded = new Set<number>()
  /**
   * Fold one snapshot revision (ascending seq) into the persistent state.
   * @param sessionId - owning conversation; a change resets the fold.
   * @param nodes - the currently loaded conversation nodes (windowed).
   * @returns the mounted-file views (sorted by last message seq).
   */
  fold(sessionId: string, nodes: readonly ConversationNode[]): MountedFileView[] {
    if (this.sessionId !== sessionId) {
      this.sessionId = sessionId
      this.paths.clear()
      this.folded.clear()
    }
    let contextL: number | undefined
    for (const node of nodes) {
      const tokens = contextLengthOf(node)
      if (tokens !== undefined) contextL = tokens
      if (node.kind !== 'context') continue
      const parsed = parseMountSource(node.source)
      if (parsed === undefined) continue
      if (this.folded.has(node.seq)) continue
      this.folded.add(node.seq)
      const list = this.paths.get(parsed.path) ?? []
      list.push({ seq: node.seq, kind: parsed.mountKind, delta: parsed.delta })
      list.sort((a, b) => a.seq - b.seq)
      this.paths.set(parsed.path, list)
    }
    const views: MountedFileView[] = []
    for (const [path, messages] of this.paths) {
      let state: MountState | undefined
      for (const message of messages) state = applyMountState(state, message.delta)
      if (state === undefined) continue
      const last = messages[messages.length - 1]!
      views.push({
        path,
        mountKind: last.kind,
        seq: last.seq,
        hash: state.hash,
        totalLines: state.totalLines,
        ranges: state.segments,
        savedTokens: state.savedTokens,
        spentTokens: state.spentTokens,
        freshnessThreshold: DEFAULT_FRESHNESS_CONFIG.threshold,
      })
    }
    views.sort((a, b) => a.seq - b.seq)
    // Every view shows the CURRENT freshness, so stamp the final context
    // length (the last assistant usage in the snapshot) on all entries.
    if (contextL !== undefined) {
      for (const view of views) view.contextL = contextL
    }
    return views
  }
}

/**
 * One-shot fold of a node list (stateless). The live dashboard should use
 * {@link MountFold}, which persists across the paginated history window.
 * Foreign or malformed nodes are skipped; a hash change replaces the entry
 * wholesale (the old mount is stale), same-hash messages union their ranges.
 */

export function foldMounts(nodes: readonly ConversationNode[]): MountedFileView[] {
  return new MountFold().fold('', nodes)
}