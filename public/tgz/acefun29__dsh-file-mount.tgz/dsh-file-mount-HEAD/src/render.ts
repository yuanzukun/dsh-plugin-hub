/**
 * Deterministic model-facing rendering (ported from piwpi's render.ts). The
 * same ledger state renders byte-identically, which keeps the provider prompt
 * prefix cache stable across requests. All text is model-facing English,
 * matching the harness's own tool-output convention (UI strings are localized
 * separately in the client half).
 *
 * Formats:
 *   head    [file-mount: <path> hash:<h8> mounted:L20-80]
 *           path is relative to the workspace cwd (posix slashes)
 *   dedup   head + note (zero content re-added)
 *   block   head + per-segment "--- Ls-e ---" headers + "N: " prefixed lines
 */
import { normalize } from './ranges.ts'
import type { Segment } from './types.ts'

export function formatRange(start: number, end: number): string {
  return start === end ? `L${start}` : `L${start}-${end}`
}

/**
 * Shared marker head: identity + short hash + a compact mounted summary.
 * `path` is the model-facing path (workspace-relative when the host can
 * resolve a cwd). A few ranges are listed outright; many ranges collapse
 * to a line/range count so the note never grows with the number of mounted
 * ranges (item 12).
 */
export function markerHead(path: string, hash: string, mounted: Segment[]): string {
  const normalized = normalize(mounted)
  let summary: string
  if (normalized.length === 0) {
    summary = 'none'
  } else if (normalized.length <= 3) {
    summary = normalized.map((s) => formatRange(s.start, s.end)).join(', ')
  } else {
    const lineCount = normalized.reduce((n, s) => n + (s.end - s.start + 1), 0)
    summary = `${lineCount} lines in ${normalized.length} ranges`
  }
  return `[file-mount: ${path} hash:${hash.slice(0, 8)} mounted:${summary}]`
}

/** Full-coverage read: the window adds nothing new. */
export function renderDedupMarker(path: string, hash: string, mounted: Segment[]): string {
  return `${markerHead(path, hash, mounted)} - already mounted, not re-added. If this content is not in the conversation above, call file_mount_forget then read the file again.`
}

/** Line counts a diff produced (added/removed/unchanged), for the remount note. */
export interface RemountStats {
  added: number
  removed: number
  unchanged: number
}

/** Hash change: the previous mount is stale and the window remounts. With diff
 * stats, report the change shape; otherwise the generic remount note. */
export function renderRemountMarker(path: string, hash: string, mounted: Segment[], stats?: RemountStats): string {
  const head = markerHead(path, hash, mounted)
  if (stats === undefined) return `${head} - file changed since last mount, remounting`
  return `${head} - file changed: +${stats.added}/-${stats.removed} lines (~${stats.unchanged} unchanged) since last mount`
}

/** Options for {@link renderMountBlock}. */
export interface MountBlockOptions {
  /** Mounted identity (path as shown to the model). */
  path: string
  /** Current full-file hash. */
  hash: string
  /** Ledger state AFTER this mount lands. */
  mounted: Segment[]
  /** 1-based line number of `lines[0]` in the file. */
  windowStart: number
  /** The read tool's returned window body, in order. */
  lines: string[]
  /** Ranges of `lines` that are NOT yet in the context (normalized, in-window). */
  missing: Segment[]
}

/** Render the new-content block: marker head + one header/body pair per missing range.
 * Each body line is prefixed with `N: ` to match native read output. */
export function renderMountBlock(opts: MountBlockOptions): string {
  const out = [markerHead(opts.path, opts.hash, opts.mounted)]
  for (const seg of normalize(opts.missing)) {
    out.push(`--- ${formatRange(seg.start, seg.end)} ---`)
    for (let lineNo = seg.start; lineNo <= seg.end; lineNo++) {
      const text = opts.lines[lineNo - opts.windowStart] ?? ''
      out.push(`${lineNo}: ${text}`)
    }
  }
  return out.join('\n')
}
