---
name: dsh-web-service
description: 通过 RESTful API 管理 DeepSeek Harness (DSH)：工作区、会话、模型设置与 SSE 流式对话。当需要用 HTTP 接口操作 DSH（三方系统集成、OpenAI 兼容调用、自动化脚本）时使用。
whenToUse: 用户要求通过 HTTP/REST API 调用 DSH、集成三方系统、使用 OpenAI 兼容协议对话、或自动化管理工作区与会话时使用。
---

# DSH Web Service API（dsh-web-service）

本机 DSH 已由插件 `dsh-web-service` 暴露为 Web Service。所有能力通过 HTTP 访问，第三方系统、脚本或任何 OpenAI SDK 均可直接调用。

## 服务地址

插件提供**独立固定端口服务**（首次安装自动分配，从 31800 起找空闲端口），Base URL 以设置页
「API 服务」卡片显示的地址为准；也可从 `GET <Base>/system/status` 的 `data.standalonePort`
取得端口。DSH 主 webserver 端口每次启动都会变化，**不要写死**。

| 访问路径 | Base URL |
|---|---|
| 本机（独立服务运行中） | `http://127.0.0.1:<standalonePort>/api/v1` |
| 同局域网（监听范围 0.0.0.0 时） | `http://<本机局域网 IP>:<standalonePort>/api/v1` |
| 经内网穿透 / 反向代理 | `http://<代理 host>:<对外端口>/api/v1`（代理指向独立固定端口，路径不变） |

下文示例用 `$BASE` 表示 Base URL，执行前先设置：

```bash
BASE=http://127.0.0.1:<standalonePort>/api/v1   # 端口以设置页「API 服务」显示为准
```

- **交互式文档**：`<Base>/docs`
- **OpenAPI 规范**：`<Base>/openapi.json`
- **鉴权**：若部署时配置了 `apiKey`，请求需带 `Authorization: Bearer <key>` 或 `X-API-Key: <key>` 头；未配置则免鉴权。
- **CORS**：默认开启。
- **离线判断**：经代理 / 隧道访问前先探一次 `system/status`；连不上就直接报告，不要循环重试。
- **节点身份判定**：`GET <Base>/ping` 返回 DSH 所在机器的 IP/MAC 指纹；natpass 等隧道把远端 DSH 映射成 `127.0.0.1:port` 时，用它判定该「127.0.0.1 节点」是不是本机（见下节）。

快速自检：

```bash
curl -s http://127.0.0.1:<standalonePort>/api/v1/system/status   # 本机
curl -s http://<代理 host>:<对外端口>/api/v1/system/status        # 经代理
```

### 机器指纹判定（127.0.0.1 节点是否本机）

natpass 等隧道会把远端 DSH 映射成本机 `127.0.0.1:port`，单看地址无法区分「本地 DSH」与「隧道进来的远端 DSH」。`GET /ping` 返回机器指纹，比对即可判定：

```bash
curl -s $BASE/ping
# data: { hostname, platform, arch, ips[], macs[], interfaces[], hint }
```

- **比对 MAC（首选）**：`data.macs` 与本机网卡 MAC（`ip link` / `ifconfig`）求交集，命中即本机 DSH；IP 在 NAT/多网卡下不稳定，仅作辅助。主机名 `hostname` 可作快速旁证。
- `data.macs` 已过滤全零 MAC 的虚拟网卡（utun 等）；`interfaces[]` 保留全量明细（含回环）供排查。
- 鉴权与普通数据面接口一致（节点未配 `apiKey` 则免鉴权）。

## 统一响应约定

除 `/chat/completions` 外，所有接口返回：

```json
{ "ok": true, "data": { ... }, "timestamp": 1788421880661 }
{ "ok": false, "error": "错误信息", "timestamp": ... }
```

HTTP 状态码：`200` 成功、`201` 创建成功、`400` 参数错误、`401` 鉴权失败、`404` 资源不存在、`500` 内部错误、`503` 依赖服务未挂载。

## 1. 工作区管理

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/workspaces` | 列出全部工作区 |
| GET | `/workspaces/:id` | 工作区详情 |
| POST | `/workspaces` | 添加工作区，body `{"path": "本地目录", "title": "标题"}`；目录必须已存在 |
| PUT | `/workspaces/:id` | 重命名，body `{"title": "新标题"}` |
| DELETE | `/workspaces/:id` | 删除绑定（保留文件与会话） |
| GET | `/workspaces/:id/sessions` | 该工作区下的会话 |

示例：

```bash
# 添加工作区（目录须已存在，否则先 mkdir）
mkdir -p /tmp/my-project
curl -s -X POST $BASE/workspaces \
  -H "Content-Type: application/json" \
  -d '{"path": "/tmp/my-project", "title": "我的项目"}'
```

## 2. 会话管理

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/sessions` | 会话列表；`?search=关键词` 搜索、`?workspaceId=` 按工作区过滤 |
| GET | `/sessions/:id` | 会话详情（状态、模型、所属工作区、cwd、事件数） |
| POST | `/sessions` | 创建会话，body 可选 `{"workspaceId", "cwd", "title", "provider", "model", "reasoningEffort"}` |
| PUT | `/sessions/:id` | 修改标题和/或模型，body `{"title"?, "provider"?, "model"?, "reasoningEffort"?}` |
| DELETE | `/sessions/:id` | 删除/归档会话并释放 Agent |
| GET | `/sessions/:id/history` | 历史消息分页；`?maxMessages=50`、`?beforeSeq=` |
| POST | `/sessions/:id/cancel` | 中止当前轮次 |
| POST | `/sessions/:id/files` | **上传文件到该会话工作区**：`multipart/form-data`（多文件，字段名任意带 filename 即保存）或原始字节流 + `?filename=`/`X-Filename` 头；同名自动 `-1/-2` 去重永不覆盖；返回 `files[].path` 绝对路径 |
| GET | `/sessions/:id/files` | **列出工作区目录**：`?path=相对子目录` 逐层浏览；返回 `entries[]`（name/type dir\|file\|link/size/mtime/path，目录在前），`entry.path` 可继续用于浏览或下载 |
| GET | `/sessions/:id/files/download` | **下载工作区文件**：`?path=相对路径`；`?inline=1` 内联预览（MIME 按扩展名）；禁止 `../` 越界 |

典型流程：创建 → （上传文件）→ 对话 → 查历史 → 归档。

上传示例：

```bash
# multipart 多文件
curl -X POST $BASE/sessions/$SID/files \
  -F "files=@./报告.pdf" -F "files=@./data.csv"
# 原始字节流 + 文件名
curl -X POST "$BASE/sessions/$SID/files?filename=dump.bin" \
  -H "Content-Type: application/octet-stream" --data-binary @./dump.bin
```

上传后把返回的 `path` 写进对话，会话中的 AI 即可用文件工具（fs/shell）直接读取。上限默认 2GB（配置 `maxUploadBytes`）；**大文件（>64MB）建议走分片断点续传**，避免服务端整包缓冲：`POST /sessions/:id/files/resumable?name=&size=` 拿 `uploadId` → `PUT /sessions/:id/files/resumable/:uploadId?offset=<已传字节>` 顺序追加分片（建议 4MB/片，409 时按返回的 `received` 对账）→ `POST /sessions/:id/files/resumable/:uploadId/complete` 落盘，返回与整包上传完全一致的 `files` 形状。

```bash
SID=$(curl -s -X POST $BASE/sessions \
  -H "Content-Type: application/json" \
  -d '{"title": "测试", "cwd": "/tmp/my-project"}' | python3 -c "import json,sys;print(json.load(sys.stdin)['data']['sessionId'])")
```

`GET /sessions/:id/history` 返回 `messages[]`（`role`: user/assistant，`content`，`seq`，`time`）及 `totalMessages`、`totalEvents`、`hasMore`。

## 3. 模型管理

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/models` | 全部模型目录：`provider`、`id`、`name`、`reasoning.efforts`、`routeOnly`、`isDefault` |
| GET | `/models/default` | 当前全局默认模型 `{provider, model, reasoningEffort?}` |
| PUT | `/models/default` | 修改全局默认，body `{"provider", "model", "reasoningEffort"?}`；对新会话生效 |
| GET | `/providers` | 提供商清单，每个含其 `models[]` |

模型条目分两类：
- **目录型**：来自 `modelCatalog.groups`，有名称与 reasoning 档位；
- **路由型**（`routeOnly: true`）：无模型目录但可直接路由。

**选模型前先 `GET /models` 拿合法的 `provider` + `model` 组合**。非法组合会被拒绝：`no adapter registered for provider ...`。

`PUT /models/default` 与设置命名空间 `agent-default-model` 写同一存储，两者互通。

## 4. 流式与同步对话

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/sessions/:id/prompt-stream` | **SSE 流式**：body `{"prompt", "mode"?: "normal"\|"steer"}` |
| GET | `/sessions/:id/events` | SSE 订阅该会话全部底层事件 |
| POST | `/sessions/:id/prompt` | 同步阻塞直到本轮完成，返回 `{content, reasoning?, toolCalls[]}` |

### SSE 事件类型（prompt-stream）

| event | data | 含义 |
|---|---|---|
| `connected` | `{sessionId}` | 连接建立 |
| `delta` | `{delta, seq}` | 文本增量 |
| `reasoning` | `{delta, seq}` | 思考过程增量 |
| `tool_call` | `{id?, name, arguments}` | 模型发起工具调用 |
| `tool_result` | `{id?, name, result}` | 工具执行结果 |
| `turn_end` | `{reason}` | 本轮结束 |
| `done` | `[DONE]` | 流终止信号 |
| `error` | `{message}` | 出错 |

```bash
curl -N -X POST $BASE/sessions/$SID/prompt-stream \
  -H "Content-Type: application/json" \
  -d '{"prompt": "介绍一下你自己"}'
```

`GET /sessions/:id/events` 透传 Harness 原生事件（`turn/start`、`user/message`、`assistant/chunk`（含 `text-delta`/`reasoning-delta` 分片）、`assistant/message`、`tool/call`、`turn/end` 等），按 `seq` 递增。

## 5. OpenAI 兼容接口

`POST /chat/completions`，兼容标准 OpenAI 客户端与 SDK：

```bash
# 非流式
curl -s -X POST $BASE/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "PONG测试"}]}'

# 流式（SSE chunks，以 data: [DONE] 结束）
curl -N -X POST $BASE/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "你好"}], "stream": true}'
```

- 可传 `sessionId` 延续指定会话；不传则自动创建新会话。
- 可传 `model`，格式 `"provider/model"`（如 `"zai-coding-cn/glm-5.3"`）会为该会话切换模型。
- 响应中带 `sessionId`，可用于后续多轮。

OpenAI Python SDK 用法：

```python
from openai import OpenAI
client = OpenAI(base_url="$BASE", api_key="none")
r = client.chat.completions.create(model="none", messages=[{"role": "user", "content": "你好"}])
print(r.choices[0].message.content)
```

## 6. 设置接口

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/settings` | 全部设置命名空间（redacted 值 + schema） |
| PATCH | `/settings/:namespace` | 合并写入指定命名空间，body 为 JSON patch |

常用命名空间：`agent-default-model`、`locale`、`ui-theme`、`permission` 等。

## 排错速查

| 现象 | 处理 |
|---|---|
| 连接拒绝 | 独立 API 服务已停止或端口不对：先看设置页「API 服务」状态，或查 `system/status` |
| 经代理超时/拒绝 | 代理或隧道离线：报告用户，不要循环重试 |
| 401 | 配置了 `apiKey`；请求带 `Authorization: Bearer <key>` |
| 模型选择报 no adapter | `provider/model` 非法；先 `GET /models` 校验 |
| 新会话模型不对 | 全局默认被改过；查 `GET /models/default`，或创建时显式传 `provider/model` |
| 流式空回复 | 会话刚创建需 Agent 就绪；改用 `POST /sessions/:id/prompt` 同步等待，或先 `GET /events` 确认事件在流动 |
| 首帧迟迟不来 | 模型排队/长思考，首个增量实测可达 5~8 分钟：先 `GET /sessions/:id` 看状态再决定，勿急于判死重发 |
| 连续 401/403 | API key 失效或已轮换：**停止循环重试**，刷新 key 配置后再试一次，仍失败如实报告 |
| prompt 被拒 `agent-busy` | 会话正在跑；先 `POST /sessions/:id/cancel` 或改 `mode: "steer"` 追加 |

## 调用策略

- 一切以**实测 curl**为准；不要凭记忆猜测端点或字段。
- 批量操作前先查列表拿到真实 id（workspace/session id 均为 UUID）。
- 长任务用 `prompt-stream` 或 `events` 监听，避免同步阻塞超时。
- 三方集成优先走 `/chat/completions`（标准协议、免协调会话生命周期）。

## 自动化调用守则（定时任务 / 子智能体 / 脚本必读）

- **禁止交互等待**：无人值守上下文不得调用 `ask_user_question` 等等待人工答复的工具。参数不全（如收件群/收件人无法解析）时取保守默认执行，并在产出中显式说明假设；有人值守的会话才允许提问。
- **首帧慢 ≠ 失败**：大 prompt + 模型排队时首个增量可达 5~8 分钟，SSE 静默先查 `GET /sessions/:id` 会话状态；10 分钟内不要判定失败重发——重复 prompt 会把整轮任务重跑一遍。
- **401 即停**：同一接口连续 2 次 401/403 即停止重试；先刷新 API key / 凭证来源再重试一次，仍失败如实报告，不要拿旧凭证反复敲接口。
- **禁止自派发**：任务指令里提到的 `@某智能体` /「远程 DSH」若经核对就是当前节点或当前会话，直接本地执行；核对方法：`GET /ping` 返回的 `hostname`/`macs` 与本机一致即当前节点（比 baseUrl 可靠，natpass 场景 `127.0.0.1` 地址一律先判定）。不要再经本 API 新建会话把任务派回自己，白绕一跳且易嵌套死循环。
