import { defineConfig } from 'tsdown'

/** Self-contained ESM bundle. Harness packages stay external and resolve from the dsh profile. */
export default defineConfig({
  entry: ['src/index.ts'],
  outDir: 'lib',
  format: ['esm'],
  platform: 'node',
  target: 'node22',
  dts: false,
  clean: true,
  fixedExtension: false,
  deps: { neverBundle: [/^@deepseek-ai\//] },
})
