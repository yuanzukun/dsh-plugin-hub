import assert from 'node:assert/strict'
import { describe, it } from 'node:test'

import { parseOfficeStdout } from './run.ts'

describe('parseOfficeStdout', () => {
  it('parses a compact envelope', () => {
    const env = parseOfficeStdout('{"ok":true,"op":"schema","result":{"ops":[]}}\n')
    assert.equal(env.ok, true)
    assert.equal(env.op, 'schema')
  })

  it('parses pretty JSON', () => {
    const env = parseOfficeStdout('{\n  "ok": false,\n  "code": "not_found",\n  "error": "x",\n  "suggestion": "y"\n}\n')
    assert.equal(env.ok, false)
    assert.equal(env.code, 'not_found')
    assert.equal(env.suggestion, 'y')
  })

  it('rejects non-envelope JSON', () => {
    assert.throws(() => parseOfficeStdout('{"hello":1}'), /envelope/)
  })
})
