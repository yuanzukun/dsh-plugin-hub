/**
 * Model-facing copy for the plugin. Kept free of @deepseek-ai/* imports so
 * unit tests can run from this tree without the Harness package graph.
 */

/** After `tools:code-only` (order 99); same band as official per-tool guidance. */
export const OFFICE_PROMPT_ORDER = 105

export const OFFICE_PROMPT = [
  'Office documents (.pptx/.docx/.xlsx/.pdf): call office_schema, then office_write / office_edit / office_read.',
  'PTC / code mode: only run_code is callable directly. Reach those tools from inside the program, e.g. await tools.office_schema({ target: "write", format: "pptx" }) then await tools.office_write({ format: "pptx", path, workspace, input }).',
  'Do not emit a native skill, office_*, pwsh, or bash call for Office document work, and do not spawn zagens-office.exe to write or edit files.',
  'If office_* reports the binary is missing: download and install it yourself (do not ask the user, do not fetch install.md). Windows x64 only; otherwise stop. Fetch https://zagens.com/download/office-latest.json. Use Node fetch — not pwsh Invoke-WebRequest — to write url and gui_url into (process.env.USERPROFILE || os.homedir()) + "/.zagens-pro/bin" as zagens-office.exe and zagens-office-gui.exe (mkdir first). If the manifest url 404s, use https://zagens.com/download/zagens-office.exe and zagens-office-gui.exe. Verify sha256 and gui_sha256; do not run a mismatch. Then retry office_schema. After the binary exists, only office_* via run_code.',
  'Do not write python-pptx / pptxgenjs / openpyxl scripts when these tools are available.',
  'Always pass workspace as the session working directory and path as an absolute file under that workspace. A bare filename is resolved against the tool process cwd, not the session folder.',
  'Native office_* calls: pass a JSON object of the tool fields at the top level (format, input, path, workspace). Do not stringify the whole payload. Do not wrap in { arguments: ... }. The error `"arguments" must be an object` means the root payload was a string or array — not that you should add an arguments key.',
  'office_write: the entire document JSON goes in input. Example: await tools.office_write({ format: "xlsx", path, workspace, input: { layout: "grid", sheets: [{ name: "Sheet1", grid: { cells: [{ at: [0, 0], text: "标题" }] } }] } }). Do not put layout, sheets, or slides beside input — that fails with missing required property "input".',
  'office_edit accepts only path, op, workspace, and input. Put every op field inside input. Example: await tools.office_edit({ path, op: "upsert_slide", workspace, input: { target: "/slide[1]", slide: { title: "封面" } } }). Do not put target or slide beside input.',
  'XLSX forms: input.layout must be "grid" (or format xlsx-table). Cell styles (fill, font_size, font_color, number_format) come from office_schema target=write format=xlsx — do not invent keys. Forgetting layout yields table_rows_missing. office_read xlsx modes are table|grid|fields|fillmap (no stats); docx/pptx use outline|text|stats. Result fields follow the mode.',
  'Formal or polished PPTX: skeleton office_write (slide titles only; set include_end: false unless a thank-you page is wanted) then one office_edit upsert_slide per page.',
  'One slide uses one layout family: free-canvas elements[] OR the engine stack (title plus optional bullets/chart/table). Do not mix elements with chart, table, or bullets on the same slide — they overlap.',
  'ok=false or a ToolCallError that embeds an envelope: fix using code, error, and suggestion; do not blindly replay. missing "input" means nest the document JSON under input. After fills, one preflight; fix real overlaps; do not chase approx=true boundary warnings.',
].join(' ')

export const OFFICE_SKILL_CONTENT = [
  'The office_schema, office_write, office_edit, and office_read tools are already registered.',
  'Do not bash or pwsh the zagens-office CLI for document work, and do not emit a native skill tool call.',
  'Missing binary: download CLI+GUI yourself into (USERPROFILE || os.homedir())/.zagens-pro/bin from https://zagens.com/download/office-latest.json (mirror: https://zagens.com/download/zagens-office.exe); verify sha256; retry office_*. Do not ask the user to install or fetch install.md.',
  'PTC / code mode: only run_code is callable at the top level. Call tools as await tools.office_schema({ target: "write", format: "pptx" }) and await tools.office_write({ format: "pptx", path, workspace, input }).',
  'Native office_* calls: top-level fields only — never { arguments: ... } and never a stringified payload. path must be absolute under workspace (the session working directory). office_write: entire document JSON in input (layout/sheets/slides never beside input). office_edit: only path/op/workspace/input; upsert_slide body is input: { target: "/slide[1]", slide: { title: "封面" } }.',
  'XLSX forms: input.layout="grid"; styles from office_schema write xlsx. office_read xlsx has no stats mode.',
  'Formal or polished PPTX: skeleton office_write (slide titles only) then one office_edit upsert_slide per page. Do not mix elements[] with chart/table/bullets on one slide.',
  'ok=false: follow code, error, and suggestion; missing "input" means nest the JSON under input.',
].join(' ')

/**
 * Runtime skill that shadows the filesystem `zagens-office` integrate copy.
 * `modelInvocable: false` keeps it out of skill-catalog so PTC does not try a
 * native `skill` call. `/zagens-office` still injects this body.
 */
export const OFFICE_SKILL = {
  name: 'zagens-office',
  description:
    'Office documents via the registered office_schema / office_write / office_edit / office_read tools.',
  source: 'runtime' as const,
  invocation: { modelInvocable: false, userInvocable: true } as const,
  content: OFFICE_SKILL_CONTENT,
}
