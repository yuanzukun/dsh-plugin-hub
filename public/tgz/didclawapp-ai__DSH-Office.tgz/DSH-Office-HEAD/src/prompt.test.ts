import assert from 'node:assert/strict'
import { describe, it } from 'node:test'

import { OFFICE_PROMPT, OFFICE_SKILL, OFFICE_SKILL_CONTENT } from './prompt.ts'

describe('PTC / skill-catalog copy', () => {
  it('routes Office work through run_code and forbids native skill/shell', () => {
    assert.match(OFFICE_PROMPT, /only run_code is callable directly/)
    assert.match(OFFICE_PROMPT, /await tools\.office_schema/)
    assert.match(OFFICE_PROMPT, /await tools\.office_write/)
    assert.match(OFFICE_PROMPT, /Do not emit a native skill/)
    assert.match(OFFICE_PROMPT, /do not spawn zagens-office\.exe to write or edit/)
    assert.match(OFFICE_PROMPT, /download and install it yourself/)
    assert.match(OFFICE_PROMPT, /do not fetch install\.md/)
    assert.match(OFFICE_PROMPT, /office-latest\.json/)
    assert.match(OFFICE_PROMPT, /absolute file under that workspace/)
    assert.match(OFFICE_PROMPT, /Do not wrap in \{ arguments: \.\.\. \}/)
    assert.match(OFFICE_PROMPT, /the entire document JSON goes in input/)
    assert.match(OFFICE_PROMPT, /input\.layout must be "grid"/)
    assert.match(OFFICE_PROMPT, /xlsx modes are table\|grid\|fields\|fillmap \(no stats\)/)
    assert.match(OFFICE_PROMPT, /input: \{ target: "\/slide\[1\]"/)
    assert.match(OFFICE_PROMPT, /Do not mix elements with chart/)
  })

  it('keeps the runtime skill out of the model catalog', () => {
    assert.equal(OFFICE_SKILL.name, 'zagens-office')
    assert.equal(OFFICE_SKILL.invocation.modelInvocable, false)
    assert.equal(OFFICE_SKILL.invocation.userInvocable, true)
    assert.match(OFFICE_SKILL_CONTENT, /only run_code is callable/)
    assert.match(OFFICE_SKILL_CONTENT, /do not emit a native skill tool call/)
    assert.match(OFFICE_SKILL_CONTENT, /download CLI\+GUI yourself/)
    assert.match(OFFICE_SKILL_CONTENT, /path must be absolute/)
    assert.match(OFFICE_SKILL_CONTENT, /never \{ arguments: \.\.\. \}/)
    assert.match(OFFICE_SKILL_CONTENT, /entire document JSON in input/)
    assert.match(OFFICE_SKILL_CONTENT, /input\.layout="grid"/)
    assert.match(OFFICE_SKILL_CONTENT, /Do not mix elements\[\] with chart/)
  })
})
