import assert from 'node:assert/strict'
import { describe, it } from 'node:test'

import { officeArgsErrorHint, unwrapOfficeArgs } from './args.ts'

describe('unwrapOfficeArgs', () => {
  it('leaves a normal office_write object alone', () => {
    const args = { format: 'xlsx', input: { layout: 'grid' }, path: 'a.xlsx' }
    assert.equal(unwrapOfficeArgs(args), args)
  })

  it('unwraps a lone arguments object', () => {
    const inner = { format: 'xlsx', input: { layout: 'grid' }, path: 'a.xlsx', workspace: 'E:/w' }
    assert.deepEqual(unwrapOfficeArgs({ arguments: inner }), inner)
  })

  it('parses a stringified object', () => {
    const inner = { format: 'xlsx', input: { layout: 'grid' } }
    assert.deepEqual(unwrapOfficeArgs(JSON.stringify(inner)), inner)
  })

  it('parses a stringified arguments wrapper', () => {
    const inner = { target: 'write', format: 'xlsx' }
    assert.deepEqual(unwrapOfficeArgs(JSON.stringify({ arguments: inner })), inner)
  })

  it('does not steal arguments when format is already top-level', () => {
    const args = { format: 'xlsx', input: {}, arguments: { format: 'docx' } }
    assert.equal(unwrapOfficeArgs(args), args)
  })
})

describe('officeArgsErrorHint', () => {
  it('rewrites the root-path diagnostic', () => {
    const hint = officeArgsErrorHint(
      'office_write',
      '{"format":"xlsx","input":{}}',
      'invalid arguments: "arguments" must be an object',
    )
    assert.match(hint ?? '', /not \{ arguments: \.\.\. \}/)
    assert.match(hint ?? '', /office_write/)
  })

  it('leaves unrelated errors alone', () => {
    assert.equal(officeArgsErrorHint('office_write', '{}', 'zagens-office binary not found'), undefined)
  })
})
