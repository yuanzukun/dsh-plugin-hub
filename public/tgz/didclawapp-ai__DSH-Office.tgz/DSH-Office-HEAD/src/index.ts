import type { Context } from '@deepseek-ai/cordis'
import Schema from '@deepseek-ai/schemastery'
// Declaration merge only: makes ctx.systemPrompt visible (same as in-tree dsh tools).
import type {} from '@deepseek-ai/dsh-system-prompt'

import { officeBinArgv0, resolveOfficeBin } from './bin.ts'
import { OFFICE_PROMPT, OFFICE_PROMPT_ORDER } from './prompt.ts'
import { registerOfficeSkill } from './skill.ts'
import { registerOfficeTools } from './tools.ts'

export const name = 'zagens-office'
export const inject = ['tools', 'systemPrompt', 'skills', 'agents']

export interface Config {
  /** Absolute path to zagens-office(.exe). Empty = env / ~/.zagens-pro/bin / PATH. */
  bin: string
  /** Per-call subprocess timeout in milliseconds. */
  timeoutMs: number
}

export const Config: Schema<Config> = Schema.object({
  bin: Schema.string().default(''),
  timeoutMs: Schema.number().default(180_000),
})

export function apply(ctx: Context, config: Config) {
  const resolved = resolveOfficeBin(config.bin || undefined)
  const argv0 = officeBinArgv0(config.bin || undefined)
  console.log(
    resolved
      ? `[zagens-office] plugin loaded; bin=${resolved}`
      : `[zagens-office] plugin loaded; bin not on disk yet, will try PATH (${argv0})`,
  )

  ctx.systemPrompt.section({
    name: 'zagens-office',
    order: OFFICE_PROMPT_ORDER,
    text: OFFICE_PROMPT,
  })

  registerOfficeSkill(ctx)
  registerOfficeTools(ctx, config)
}
