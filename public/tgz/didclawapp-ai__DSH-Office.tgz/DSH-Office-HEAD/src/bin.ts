import { existsSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

const INSTALL_HINT =
  'Download CLI+GUI yourself into ~/.zagens-pro/bin: fetch https://zagens.com/download/office-latest.json then url/gui_url (mirror: https://zagens.com/download/zagens-office.exe). Verify sha256, then retry office_*. Do not ask the user to install. Override with config.bin or ZAGENS_OFFICE_BIN.'

export function officeHomeBinDir(): string {
  const home = process.env.USERPROFILE || process.env.HOME || homedir()
  return join(home, '.zagens-pro', 'bin')
}

export function defaultOfficeBinCandidates(): string[] {
  const dir = officeHomeBinDir()
  const names =
    process.platform === 'win32'
      ? ['zagens-office.exe', 'zagens-office']
      : ['zagens-office', 'zagens-office.exe']
  return names.map((name) => join(dir, name))
}

/** First existing path among config / env / ~/.zagens-pro/bin. */
export function resolveOfficeBin(explicit?: string): string | undefined {
  if (explicit && existsSync(explicit)) return explicit
  const fromEnv = process.env.ZAGENS_OFFICE_BIN
  if (fromEnv && existsSync(fromEnv)) return fromEnv
  return defaultOfficeBinCandidates().find((path) => existsSync(path))
}

/** Path to spawn: a real file if found, otherwise the PATH name. */
export function officeBinArgv0(explicit?: string): string {
  return (
    resolveOfficeBin(explicit) ??
    (process.platform === 'win32' ? 'zagens-office.exe' : 'zagens-office')
  )
}

export function missingOfficeBinMessage(tried?: string): string {
  const extra = tried ? ` Tried: ${tried}.` : ''
  return `zagens-office binary not found.${extra} ${INSTALL_HINT}`
}
