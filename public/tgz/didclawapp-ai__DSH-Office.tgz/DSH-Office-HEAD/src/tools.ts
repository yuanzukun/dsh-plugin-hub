import type { Context } from '@deepseek-ai/cordis'
import { defineTool, type ToolDefinition } from '@deepseek-ai/dsh-tools'

import { officeArgsErrorHint, unwrapOfficeArgs } from './args.ts'
import { officeBinArgv0 } from './bin.ts'
import { renderEnvelope, runOffice } from './run.ts'
import type { Config } from './index.ts'

function errorText(result: { content: readonly { type: string; text?: string }[] }): string {
  return result.content
    .map((block) => (block.type === 'text' && typeof block.text === 'string' ? block.text : ''))
    .join('\n')
}

/** Unwrap stringified / `{ arguments }` payloads before defineTool validation. */
function withOfficeArgUnwrap(tool: ToolDefinition, example: string): ToolDefinition {
  const execute = tool.execute.bind(tool)
  const finalize = tool.finalizeContent?.bind(tool)
  return {
    ...tool,
    execute(args, exec) {
      return execute(unwrapOfficeArgs(args), exec)
    },
    finalizeContent(exec, result) {
      if (result.isError) {
        const hint = officeArgsErrorHint(tool.name, example, errorText(result))
        if (hint !== undefined) return [{ type: 'text', text: `Error: ${hint}` }]
      }
      return finalize?.(exec, result)
    },
  }
}

function asJson(value: unknown): unknown {
  if (typeof value === 'string') {
    const trimmed = value.trim()
    if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
      return JSON.parse(trimmed)
    }
  }
  return value
}

export function registerOfficeTools(ctx: Context, config: Config): void {
  const bin = officeBinArgv0(config.bin)
  const timeoutMs = config.timeoutMs

  ctx.tools.register(withOfficeArgUnwrap(defineTool({
    name: 'office_schema',
    description:
      'Fetch the zagens-office JSON contract. Call before the first write/edit. target=write needs format (pptx|xlsx|docx|pdf).',
    timeoutMs,
    parameters: {
      target: {
        type: 'string',
        enum: ['edit', 'write', 'transform', 'merge'],
        required: true,
        description: 'Which contract to print.',
      },
      format: {
        type: 'string',
        enum: ['pptx', 'xlsx', 'docx', 'pdf'],
        description: 'Filter for schema write only.',
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value) => [{ type: 'text', text: renderEnvelope(value) }],
    },
    async execute(args, exec) {
      const argv = ['schema', args.target]
      if (args.target === 'write' && args.format) argv.push(args.format)
      return runOffice({ bin, args: argv, timeoutMs, signal: exec.signal })
    },
  }), '{"target":"write","format":"xlsx"}'))

  ctx.tools.register(withOfficeArgUnwrap(defineTool({
    name: 'office_write',
    description:
      'Create a .pptx/.xlsx/.docx/.pdf via zagens-office. Top-level fields: format, input, path, workspace — do not wrap in arguments and do not stringify the call. The entire document JSON goes in input (not beside it). Always pass workspace (session cwd) and an absolute path. XLSX forms: input.layout="grid". Formal/polished PPTX: skeleton write (titles only) then office_edit upsert_slide per page — do not stuff heavy slides[] into one write.',
    timeoutMs,
    parameters: {
      format: {
        type: 'string',
        enum: ['pptx', 'xlsx', 'xlsx-table', 'docx', 'pdf'],
        required: true,
        description: 'Output format (xlsx-table forces layout=table).',
      },
      input: {
        type: 'json',
        required: true,
        description:
          'Entire write JSON only. Must be this field — not top-level layout/sheets/slides. Prefer office_schema first. XLSX grid: { layout: "grid", sheets: [{ name, grid: { cells: [{ at: [0, 0], text }] } }] }. Cell styles (fill, font_size, font_color, number_format) are in schema write xlsx.',
      },
      path: {
        type: 'string',
        description:
          'Absolute output path under workspace. A bare filename is written next to the tool process cwd, not the session folder. Optional for write xlsx --validate-only.',
      },
      workspace: {
        type: 'string',
        description: 'Session working directory. Required whenever path is relative or the file must land in the user workspace.',
      },
      validate_only: {
        type: 'boolean',
        description: 'xlsx / xlsx-table: preflight without writing path.',
      },
      preview: {
        type: 'string',
        enum: ['stats', 'svg'],
        description: 'docx/pptx: attach a one-shot preview after write.',
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value) => [{ type: 'text', text: renderEnvelope(value) }],
    },
    presentCall(args) {
      return {
        card: 'generic',
        title: `office_write ${args.format}`,
        kind: 'edit',
        ...(args.path ? { locations: [{ path: args.path }] } : {}),
      }
    },
    async execute(args, exec) {
      const argv = ['write', args.format]
      if (args.path) argv.push('--path', args.path)
      if (args.workspace) argv.push('--workspace', args.workspace)
      if (args.validate_only) argv.push('--validate-only')
      if (args.preview) argv.push('--preview', args.preview)
      return runOffice({
        bin,
        args: argv,
        input: asJson(args.input),
        timeoutMs,
        signal: exec.signal,
      })
    },
  }), '{"format":"xlsx","path":"E:/ws/out.xlsx","workspace":"E:/ws","input":{"layout":"grid","sheets":[{"name":"Sheet1","grid":{"cells":[{"at":[0,0],"text":"标题"}]}}]}}'))

  ctx.tools.register(withOfficeArgUnwrap(defineTool({
    name: 'office_edit',
    description:
      'Structured edit on an existing Office file (set_text, upsert_slide, fill, batch, preflight, …). Only path, op, workspace, and input are tool arguments — every op field goes inside input. Example upsert_slide: input: { target: "/slide[1]", slide: { title: "封面" } }. Multi-step: op=batch with atomic true. ok=false → follow code/error/suggestion; do not blindly replay.',
    timeoutMs,
    parameters: {
      path: {
        type: 'string',
        required: true,
        description: 'Absolute existing document path (mutated in place for write ops). Always pass workspace.',
      },
      op: {
        type: 'string',
        required: true,
        description: 'Op name from office_schema target=edit (e.g. upsert_slide, batch, preflight).',
      },
      input: {
        type: 'json',
        description:
          'Op JSON body only. upsert_slide: { target: "/slide[1]", slide: { title: "封面" } }. add_textbox: put x_emu/y_emu (or x_pct) inside this object. Use {} when the op has no fields. Do not pass target or slide beside input.',
      },
      workspace: {
        type: 'string',
        description: 'Session working directory. Required for relative path and image sandboxing.',
      },
      dry_run: {
        type: 'boolean',
        description: 'Do not save the file (batch/fill).',
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value) => [{ type: 'text', text: renderEnvelope(value) }],
    },
    presentCall(args) {
      return {
        card: 'generic',
        title: `office_edit ${args.op}`,
        kind: 'edit',
        locations: [{ path: args.path }],
      }
    },
    async execute(args, exec) {
      const argv = ['edit', '--path', args.path, '--op', args.op]
      if (args.workspace) argv.push('--workspace', args.workspace)
      if (args.dry_run) argv.push('--dry-run')
      return runOffice({
        bin,
        args: argv,
        input: args.input !== undefined ? asJson(args.input) : {},
        timeoutMs,
        signal: exec.signal,
      })
    },
  }), '{"path":"E:/ws/deck.pptx","op":"upsert_slide","workspace":"E:/ws","input":{"target":"/slide[1]","slide":{"title":"封面"}}}'))

  ctx.tools.register(withOfficeArgUnwrap(defineTool({
    name: 'office_read',
    description:
      'Read an existing Office file before editing. Result fields follow the mode. docx/pptx: outline|text|stats. xlsx: table|grid|fields|fillmap (no stats).',
    timeoutMs,
    parameters: {
      format: {
        type: 'string',
        enum: ['xlsx', 'docx', 'pptx'],
        required: true,
        description: 'File kind. PDF read is not in the CLI.',
      },
      path: {
        type: 'string',
        required: true,
        description: 'Absolute document path. Always pass workspace.',
      },
      mode: {
        type: 'string',
        enum: ['outline', 'text', 'stats', 'table', 'grid', 'fields', 'fillmap'],
        description: 'Read mode. Defaults: outline (docx/pptx), table (xlsx).',
      },
      sheet: {
        type: 'string',
        description: 'xlsx table/grid: sheet name.',
      },
      workspace: {
        type: 'string',
        description: 'xlsx fields: workspace for template aliases.',
      },
      limit: {
        type: 'integer',
        description: 'xlsx table/grid: max rows (CLI default 500).',
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args, value) => [{ type: 'text', text: renderEnvelope(value) }],
    },
    presentCall(args) {
      return {
        card: 'generic',
        title: `office_read ${args.format}`,
        kind: 'read',
        locations: [{ path: args.path }],
      }
    },
    async execute(args, exec) {
      const argv = ['read', args.format, '--path', args.path]
      if (args.mode) argv.push('--mode', args.mode)
      if (args.sheet) argv.push('--sheet', args.sheet)
      if (args.workspace) argv.push('--workspace', args.workspace)
      if (args.limit !== undefined) argv.push('--limit', String(args.limit))
      return runOffice({ bin, args: argv, timeoutMs, signal: exec.signal })
    },
  }), '{"format":"xlsx","path":"E:/ws/out.xlsx","workspace":"E:/ws","mode":"grid"}'))
}
