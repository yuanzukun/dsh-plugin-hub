import { execFile } from 'node:child_process'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { promisify } from 'node:util'

import { missingOfficeBinMessage } from './bin.ts'

const execFileAsync = promisify(execFile)

export type OfficeEnvelope = {
  engine?: string
  ok: boolean
  op?: string
  result?: unknown
  code?: string
  error?: string
  suggestion?: string
  [key: string]: unknown
}

export type RunOfficeOptions = {
  bin: string
  args: string[]
  input?: unknown
  timeoutMs: number
  signal?: AbortSignal
}

type ExecFileError = Error & {
  code?: string | number
  stdout?: string
  stderr?: string
}

function isExecFileError(error: unknown): error is ExecFileError {
  return error instanceof Error
}

export function parseOfficeStdout(stdout: string): OfficeEnvelope {
  const text = stdout.trim()
  if (!text) {
    throw new Error('zagens-office produced empty stdout (expected a JSON envelope).')
  }
  let parsed: unknown
  try {
    parsed = JSON.parse(text)
  } catch {
    const line = text.split(/\r?\n/).find((row) => row.trim().startsWith('{'))
    if (!line) {
      throw new Error(`zagens-office stdout is not JSON: ${text.slice(0, 400)}`)
    }
    parsed = JSON.parse(line)
  }
  if (typeof parsed !== 'object' || parsed === null || typeof (parsed as OfficeEnvelope).ok !== 'boolean') {
    throw new Error('zagens-office stdout is not an envelope (missing boolean ok).')
  }
  return parsed as OfficeEnvelope
}

export function renderEnvelope(value: unknown): string {
  return JSON.stringify(value, null, 2)
}

/**
 * Spawn zagens-office. Non-zero exit is not a throw when stdout is a valid
 * envelope (`ok:false` is a domain result for the model to self-heal).
 */
export async function runOffice(options: RunOfficeOptions): Promise<OfficeEnvelope> {
  const { bin, args, input, timeoutMs, signal } = options
  let inputFile: string | undefined
  let tempDir: string | undefined
  const argv = [...args]

  try {
    if (input !== undefined) {
      tempDir = await mkdtemp(join(tmpdir(), 'dsh-zagens-office-'))
      inputFile = join(tempDir, 'input.json')
      await writeFile(inputFile, JSON.stringify(input), 'utf8')
      argv.push('--input-file', inputFile)
    }

    try {
      const { stdout } = await execFileAsync(bin, argv, {
        encoding: 'utf8',
        windowsHide: true,
        timeout: timeoutMs,
        maxBuffer: 20 * 1024 * 1024,
        signal,
      })
      return parseOfficeStdout(stdout)
    } catch (error) {
      if (isExecFileError(error) && error.code === 'ENOENT') {
        throw new Error(missingOfficeBinMessage(bin))
      }
      if (isExecFileError(error) && typeof error.stdout === 'string' && error.stdout.trim()) {
        try {
          return parseOfficeStdout(error.stdout)
        } catch {
          // fall through
        }
      }
      const stderr = isExecFileError(error) ? error.stderr ?? '' : ''
      const stdout = isExecFileError(error) ? error.stdout ?? '' : ''
      const detail = [error instanceof Error ? error.message : String(error), stderr, stdout]
        .filter(Boolean)
        .join('\n')
        .slice(0, 1200)
      throw new Error(`zagens-office failed: ${detail}`)
    }
  } finally {
    if (tempDir) {
      await rm(tempDir, { recursive: true, force: true }).catch(() => undefined)
    }
  }
}
