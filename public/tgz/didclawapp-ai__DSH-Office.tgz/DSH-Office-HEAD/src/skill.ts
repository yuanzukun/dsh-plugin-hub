import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
// Declaration merge: ctx.agents, agent/created, ctx.skills.
import type {} from '@deepseek-ai/dsh-agent'
import type {} from '@deepseek-ai/dsh-skill'

import { OFFICE_SKILL } from './prompt.ts'

/**
 * Hide filesystem `zagens-office` from the model catalog.
 *
 * Host `ctx.skills.register()` files into the **global** layer. Web/PTC remount
 * `skill-filesystem` on the **preset** layer, and the nearest layer wins a
 * duplicate name outright, so a global shadow never hides `~/.agents/skills`.
 * Read the registry with `agent.ctx.get('skills')`. Scope fibers do not
 * declare `inject`, so the `ctx.skills` property proxy refuses the access.
 * `get` still returns a caller-bound service, so `register()` files into
 * the agent layer (child of the preset) and wins.
 */
function attachOfficeSkill(agent: Agent): void {
  const skills = agent.ctx.get('skills')
  if (skills === undefined) {
    console.warn('[zagens-office] skip catalog hide: skills is not available on this agent')
    return
  }
  skills.register({ ...OFFICE_SKILL })
}

export function registerOfficeSkill(ctx: Context): void {
  console.log('[zagens-office] will hide filesystem zagens-office from the model catalog on each agent')
  for (const agent of ctx.agents.list()) attachOfficeSkill(agent)
  ctx.on('agent/created', ({ agent }) => attachOfficeSkill(agent))
}
