/**
 * Model-facing office_* calls often arrive as a JSON string or
 * `{ arguments: { ...fields } }` because the validator labels the root
 * payload "arguments". Unwrap before schema checks.
 */

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

const DIRECT_KEYS = ['format', 'input', 'path', 'workspace', 'target', 'op', 'mode'] as const

/**
 * Peel a stringified JSON payload or a lone `arguments` wrapper.
 * @param args - raw tool payload from the model or Code Mode binding.
 * @returns the innermost object that looks like office_* fields, or `args`.
 */
export function unwrapOfficeArgs(args: unknown): unknown {
  let current = args
  for (let i = 0; i < 3; i++) {
    if (typeof current === 'string') {
      const trimmed = current.trim()
      if (!(trimmed.startsWith('{') || trimmed.startsWith('['))) break
      try {
        current = JSON.parse(trimmed) as unknown
      } catch {
        break
      }
      continue
    }
    if (!isRecord(current) || current.arguments === undefined) break
    const hasDirect = DIRECT_KEYS.some((key) => current[key] !== undefined)
    if (hasDirect) break
    current = current.arguments
  }
  return current
}

const ARGS_SHAPE_ERROR =
  /"arguments" must be an object|missing required property "(?:format|input|path|target|op)"/

/**
 * Replace the harness root-path diagnostic when the model wrapped or
 * stringified the payload. `undefined` leaves the original error text.
 * @param toolName - office_* name for the hint.
 * @param example - a valid top-level JSON object for that tool.
 * @param message - current error text shown to the model.
 * @returns replacement error text, or `undefined`.
 */
export function officeArgsErrorHint(toolName: string, example: string, message: string): string | undefined {
  if (!ARGS_SHAPE_ERROR.test(message)) return undefined
  return (
    `${toolName} needs a JSON object of its fields at the top level, not a string and not { arguments: ... }. `
    + `Example: ${example}`
  )
}
