import type { Context } from '@deepseek-ai/cordis';
export declare const name = "dsh-project-wiki";
export declare const inject: string[];
export interface Config {
    readonly directory?: string;
    readonly maxPages?: number;
}
export declare const Config: any;
export declare function needsHumanApproval(exec: {
    readonly name: string;
    readonly signal: AbortSignal;
}, mounted: boolean): boolean;
export declare function humanApprovalReason(toolName: string): string;
/** Mount the workspace Wiki authority, root-Agent tools, and Web RPC. */
export declare function apply(ctx: Context, rawConfig: Config): void;
