import type { WikiService } from './service.ts';
interface RpcContext {
    readonly connection: {
        readonly rpc: {
            handle(channel: string, handler: (endpoint: string, payload: unknown, signal: AbortSignal) => Promise<unknown>, options: {
                readonly authority: 'loopback' | 'trusted-host';
            }): () => Promise<void>;
        };
    };
}
/** Loopback-only Web API. Every request is rebound to its live Session workspace. */
export declare function registerWikiRpc(ctx: RpcContext, service: WikiService): () => Promise<void>;
export {};
