import type { WikiService } from './service.ts';
interface ToolAgent {
    readonly id: string;
    readonly ctx: {
        readonly tools: {
            register(definition: unknown): () => void;
        };
    };
}
/** Install read tools and approval-gated proposal tools into one exact root Agent. */
export declare function registerWikiTools(service: WikiService, agent: ToolAgent): () => void;
export {};
