export type WikiPageStatus = 'current' | 'stale';
export type WikiActorKind = 'agent' | 'web';
export interface WikiActor {
    readonly kind: WikiActorKind;
    readonly sessionId: string;
}
export interface WikiSource {
    readonly path: string;
    readonly sha256: string;
}
export interface WikiPage {
    readonly id: string;
    readonly revision: number;
    readonly slug: string;
    readonly title: string;
    readonly summary: string;
    readonly tags: readonly string[];
    readonly body: string;
    readonly links: readonly string[];
    readonly sources: readonly WikiSource[];
    readonly staleSources: readonly string[];
    readonly status: WikiPageStatus;
    readonly createdAt: string;
    readonly updatedAt: string;
    readonly createdBy: WikiActor;
    readonly updatedBy: WikiActor;
}
export interface WikiPageInput {
    readonly id?: string;
    readonly title: string;
    readonly summary?: string;
    readonly tags?: readonly string[];
    readonly body: string;
    readonly sourcePaths?: readonly string[];
}
export interface WikiProposal {
    readonly id: string;
    readonly title: string;
    readonly summary: string;
    readonly tags: readonly string[];
    readonly body: string;
    readonly sourcePaths: readonly string[];
    readonly createdAt: string;
    readonly createdBy: WikiActor;
}
export interface WikiSearchHit {
    readonly id: string;
    readonly slug: string;
    readonly title: string;
    readonly summary: string;
    readonly tags: readonly string[];
    readonly status: WikiPageStatus;
    readonly updatedAt: string;
    readonly snippet: string;
}
export interface WikiStaleResult {
    readonly pageId: string;
    readonly title: string;
    readonly status: WikiPageStatus;
    readonly staleSources: readonly string[];
}
export interface WikiWorkspaceScope {
    readonly sessionId: string;
    readonly workspaceId: string;
    readonly workspaceName: string;
    readonly workspacePath: string;
    readonly actorKind: WikiActorKind;
}
