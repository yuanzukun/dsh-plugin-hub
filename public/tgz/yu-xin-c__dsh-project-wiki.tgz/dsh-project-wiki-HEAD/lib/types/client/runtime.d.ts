import type { ClientRpc } from './contracts.js';
import type { SaveWikiPageInput, WikiPageSummaryView, WikiPageView, WikiSearchHitView, WikiSnapshot } from './protocol.js';
export interface WikiClientState {
    readonly phase: 'idle' | 'loading' | 'ready' | 'error';
    readonly snapshot: WikiSnapshot | undefined;
    readonly selectedPage: WikiPageView | undefined;
    readonly backlinks: readonly WikiPageSummaryView[];
    readonly searchHits: readonly WikiSearchHitView[] | undefined;
    readonly searching: boolean;
    readonly error: string | undefined;
    readonly refreshedAt: number | undefined;
}
export interface WikiStateSource {
    getSnapshot(): WikiClientState;
    subscribe(listener: () => void): () => void;
}
export interface WikiRuntime {
    readonly source: WikiStateSource;
    refresh(): Promise<void>;
    openPage(pageId: string): Promise<void>;
    search(query: string): Promise<void>;
    savePage(input: SaveWikiPageInput): Promise<void>;
    deletePage(pageId: string): Promise<void>;
    approveProposal(proposalId: string): Promise<void>;
    rejectProposal(proposalId: string): Promise<void>;
    scanStale(): Promise<void>;
}
/** Session-scoped observable used by the native conversation view slot. */
export declare function createWikiRuntime(rpc: ClientRpc, sessionId: string): WikiRuntime;
