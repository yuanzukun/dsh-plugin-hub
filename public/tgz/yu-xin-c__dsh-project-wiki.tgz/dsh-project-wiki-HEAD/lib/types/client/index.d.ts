import type { ClientContext } from './contracts.js';
export declare const name = "dsh-project-wiki-client";
export declare const inject: string[];
/** Register a native, session-scoped Wiki view in DSH Web. */
export declare function apply(ctx: ClientContext): void;
