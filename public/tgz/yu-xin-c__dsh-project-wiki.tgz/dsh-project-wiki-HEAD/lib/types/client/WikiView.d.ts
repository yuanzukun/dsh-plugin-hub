import type { WikiViewProps } from './contracts.js';
/** Workspace Wiki: search, review, edit, source audit, and proposal approval. */
export declare function WikiView({ t, useWikiState, refresh, openPage, search, savePage, deletePage, approveProposal, rejectProposal, scanStale, }: WikiViewProps): JSX.Element;
