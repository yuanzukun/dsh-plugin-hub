import type { WikiPageSummaryView, WikiStatus } from './protocol.js';
export type WikiGraphNodeStatus = WikiStatus | 'missing';
export interface WikiGraphNode {
    readonly id: string;
    readonly pageId: string | undefined;
    readonly title: string;
    readonly summary: string;
    readonly status: WikiGraphNodeStatus;
    readonly degree: number;
}
export interface WikiGraphLink {
    readonly id: string;
    readonly source: string;
    readonly target: string;
}
export interface WikiGraphData {
    readonly nodes: readonly WikiGraphNode[];
    readonly links: readonly WikiGraphLink[];
    readonly unresolvedCount: number;
}
/** Build a stable directed graph from accepted pages and their Wiki links. */
export declare function buildWikiGraph(pages: readonly WikiPageSummaryView[]): WikiGraphData;
