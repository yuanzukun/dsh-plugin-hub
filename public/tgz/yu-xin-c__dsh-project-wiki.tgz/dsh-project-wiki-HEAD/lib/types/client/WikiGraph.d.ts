import type { Translate } from './contracts.js';
import type { WikiGraphData } from './graph.js';
export declare function WikiGraph({ graph, selectedPageId, t, onOpen }: {
    readonly graph: WikiGraphData;
    readonly selectedPageId: string | undefined;
    readonly t: Translate;
    readonly onOpen: (pageId: string) => void;
}): JSX.Element;
