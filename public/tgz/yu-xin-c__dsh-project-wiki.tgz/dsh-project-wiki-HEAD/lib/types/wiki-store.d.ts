import type { WikiActor, WikiPage, WikiPageInput, WikiProposal, WikiSearchHit, WikiStaleResult } from './types.ts';
interface WikiStoreOptions {
    readonly directory?: string;
    readonly maxPages?: number;
}
declare function slugify(title: string): string;
declare function extractLinks(body: string): string[];
declare function deriveSummary(body: string): string;
declare function serializePage(page: WikiPage): string;
declare function parsePage(source: string, filename: string): WikiPage;
export declare class WikiStore {
    readonly workspacePath: string;
    readonly root: string;
    readonly pagesDirectory: string;
    readonly proposalsDirectory: string;
    readonly indexPath: string;
    readonly maxPages: number;
    constructor(workspacePath: string, options?: WikiStoreOptions);
    ensureLayout(): Promise<void>;
    listPages(): Promise<WikiPage[]>;
    readPage(idOrSlug: string): Promise<WikiPage>;
    savePage(input: WikiPageInput, actorValue: WikiActor): Promise<WikiPage>;
    deletePage(id: string): Promise<void>;
    search(query: string, limit?: number): Promise<WikiSearchHit[]>;
    listProposals(): Promise<WikiProposal[]>;
    createProposal(input: Omit<WikiPageInput, 'id'>, actorValue: WikiActor): Promise<WikiProposal>;
    applyProposal(id: string, actorValue: WikiActor): Promise<WikiPage>;
    rejectProposal(id: string): Promise<void>;
    backlinks(idOrSlug: string): Promise<WikiPage[]>;
    scanStale(persist?: boolean): Promise<WikiStaleResult[]>;
    private validateSourcePaths;
    private fingerprintSources;
    private hashFile;
    private atomicWrite;
    private rebuildIndex;
}
export declare const wikiInternals: {
    deriveSummary: typeof deriveSummary;
    extractLinks: typeof extractLinks;
    parsePage: typeof parsePage;
    serializePage: typeof serializePage;
    slugify: typeof slugify;
};
export {};
