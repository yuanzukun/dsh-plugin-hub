import type { WikiActor, WikiPage, WikiPageInput, WikiProposal, WikiSearchHit, WikiStaleResult } from './types.ts';
interface ServiceContext {
    readonly agents: {
        get(id: string): {
            readonly session: {
                readonly header: {
                    readonly cwd?: string;
                };
            };
        } | undefined;
    };
    readonly workspaceRegistry: {
        resolveByPath(cwd: string): Promise<{
            readonly id: unknown;
            readonly title: string;
            readonly path: string;
        } | undefined>;
    };
}
export interface WikiScope {
    readonly sessionId: string;
    readonly actorKind: 'agent' | 'web';
}
export interface WikiServiceOptions {
    readonly directory: string;
    readonly maxPages: number;
}
export interface WikiPageSummary {
    readonly id: string;
    readonly revision: number;
    readonly slug: string;
    readonly title: string;
    readonly summary: string;
    readonly tags: readonly string[];
    readonly links: readonly string[];
    readonly sourceCount: number;
    readonly staleSources: readonly string[];
    readonly status: 'current' | 'stale';
    readonly updatedAt: string;
    readonly updatedBy: WikiActor;
}
export interface WikiSnapshot {
    readonly scope: {
        readonly workspaceId: string;
        readonly workspaceName: string;
        readonly cwd: string;
        readonly wikiDirectory: string;
    };
    readonly pages: readonly WikiPageSummary[];
    readonly proposals: readonly WikiProposal[];
    readonly generatedAt: string;
}
/** Workspace authority shared by the Web RPC and root-Agent tools. */
export declare class WikiService {
    private readonly ctx;
    private readonly options;
    private readonly stores;
    constructor(ctx: ServiceContext, options: WikiServiceOptions);
    snapshot(scope: WikiScope, signal?: AbortSignal): Promise<WikiSnapshot>;
    read(scope: WikiScope, id: string, signal?: AbortSignal): Promise<WikiPage>;
    search(scope: WikiScope, query: string, limit: number, signal?: AbortSignal): Promise<WikiSearchHit[]>;
    save(scope: WikiScope, input: WikiPageInput, signal?: AbortSignal): Promise<WikiPage>;
    delete(scope: WikiScope, id: string, signal?: AbortSignal): Promise<void>;
    propose(scope: WikiScope, input: Omit<WikiPageInput, 'id'>, signal?: AbortSignal): Promise<WikiProposal>;
    applyProposal(scope: WikiScope, id: string, signal?: AbortSignal): Promise<WikiPage>;
    rejectProposal(scope: WikiScope, id: string, signal?: AbortSignal): Promise<void>;
    backlinks(scope: WikiScope, id: string, signal?: AbortSignal): Promise<WikiPageSummary[]>;
    scanStale(scope: WikiScope, persist: boolean, signal?: AbortSignal): Promise<WikiStaleResult[]>;
    private resolve;
}
export {};
