import assert from 'node:assert/strict'
import test from 'node:test'
import { buildWikiGraph } from '../src/client/graph.ts'
import type { WikiPageSummaryView } from '../src/client/protocol.ts'

function page(id: string, title: string, slug: string, links: readonly string[]): WikiPageSummaryView {
  return {
    id,
    revision: 1,
    slug,
    title,
    summary: `${title} summary`,
    tags: [],
    links,
    sourceCount: 0,
    staleSources: [],
    status: 'current',
    updatedAt: '2026-08-15T00:00:00.000Z',
    updatedBy: { kind: 'web', sessionId: 'session-test' },
  }
}

test('builds page relations and exposes unresolved Wiki links', () => {
  const graph = buildWikiGraph([
    page('a', 'Architecture', 'architecture', ['API Contract', 'missing-page', 'missing-page']),
    page('b', 'API Contract', 'api-contract', ['architecture']),
  ])

  assert.deepEqual(graph.links.map(link => [link.source, link.target]), [
    ['a', 'b'],
    ['a', 'missing:missing-page'],
    ['b', 'a'],
  ])
  assert.equal(graph.unresolvedCount, 1)
  assert.equal(graph.nodes.find(node => node.id === 'a')?.degree, 3)
  assert.equal(graph.nodes.find(node => node.id === 'missing:missing-page')?.status, 'missing')
})

test('accepts snapshots produced by a pre-graph host bundle', () => {
  const { links: _links, ...legacyPage } = page('legacy', 'Legacy page', 'legacy-page', [])
  const graph = buildWikiGraph([legacyPage as WikiPageSummaryView])

  assert.equal(graph.nodes.length, 1)
  assert.equal(graph.links.length, 0)
})
