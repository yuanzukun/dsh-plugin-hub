import assert from 'node:assert/strict'
import { mkdtemp, readFile, rm, symlink, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import test from 'node:test'
import { WikiStore } from '../src/wiki-store.ts'

const actor = { kind: 'web' as const, sessionId: 'session-test' }

async function fixture(run: (root: string, store: WikiStore) => Promise<void>): Promise<void> {
  const root = await mkdtemp(path.join(os.tmpdir(), 'dsh-project-wiki-'))
  try {
    await run(root, new WikiStore(root))
  } finally {
    await rm(root, { recursive: true, force: true })
  }
}

test('persists auditable Markdown and searches the rebuildable FTS index', async () => {
  await fixture(async (root, store) => {
    await writeFile(path.join(root, 'architecture.ts'), 'export const boundary = "workspace"\n')
    const page = await store.savePage({
      title: 'Workspace boundary',
      summary: 'How project data remains scoped.',
      tags: ['Architecture', 'Safety'],
      body: 'The service resolves the live session before every operation.',
      sourcePaths: ['architecture.ts'],
    }, actor)

    const markdown = await readFile(path.join(root, '.dsh/wiki/pages/workspace-boundary.md'), 'utf8')
    assert.match(markdown, /^---\nid: wiki_/)
    assert.match(markdown, /sha256:/)
    assert.match(markdown, /The service resolves the live session/)
    assert.doesNotMatch(markdown, /&a\d|\*a\d/)

    const hits = await store.search('live session', 10)
    assert.equal(hits[0]?.id, page.id)
    assert.equal(hits[0]?.status, 'current')
  })
})

test('detects changed source files without overwriting the accepted fingerprint', async () => {
  await fixture(async (root, store) => {
    const source = path.join(root, 'decision.md')
    await writeFile(source, 'v1\n')
    const page = await store.savePage({
      title: 'Decision record',
      body: 'Keep this decision linked to its source.',
      sourcePaths: ['decision.md'],
    }, actor)
    const originalHash = page.sources[0]?.sha256

    await writeFile(source, 'v2\n')
    const inspected = await store.scanStale(false)
    assert.deepEqual(inspected[0]?.staleSources, ['decision.md'])
    assert.equal((await store.readPage(page.id)).status, 'current')

    await store.scanStale(true)
    const persisted = await store.readPage(page.id)
    assert.equal(persisted.status, 'stale')
    assert.equal(persisted.sources[0]?.sha256, originalHash)
  })
})

test('keeps agent proposals separate until approval and calculates backlinks', async () => {
  await fixture(async (_root, store) => {
    const target = await store.savePage({
      title: 'API contract',
      body: 'The stable API boundary.',
    }, actor)
    const proposal = await store.createProposal({
      title: 'Client behavior',
      body: 'The client depends on [[api-contract]].',
      tags: ['client'],
    }, { kind: 'agent', sessionId: 'agent-session' })

    assert.equal((await store.listPages()).length, 1)
    assert.equal((await store.listProposals()).length, 1)
    const accepted = await store.applyProposal(proposal.id, actor)
    assert.equal(accepted.createdBy.kind, 'web')
    assert.equal((await store.listProposals()).length, 0)
    assert.deepEqual((await store.backlinks(target.id)).map(page => page.id), [accepted.id])
  })
})

test('rejects source paths outside the workspace', async () => {
  await fixture(async (_root, store) => {
    await assert.rejects(
      store.savePage({ title: 'Unsafe', body: 'No.', sourcePaths: ['../outside.txt'] }, actor),
      /leaves the workspace/,
    )
  })
})

test('rejects source symlinks that leave the workspace', { skip: process.platform === 'win32' }, async () => {
  const outside = await mkdtemp(path.join(os.tmpdir(), 'dsh-project-wiki-outside-'))
  try {
    await fixture(async (root, store) => {
      const externalSource = path.join(outside, 'external.txt')
      await writeFile(externalSource, 'outside\n')
      await symlink(externalSource, path.join(root, 'linked.txt'))

      await assert.rejects(
        store.savePage({ title: 'Unsafe link', body: 'No.', sourcePaths: ['linked.txt'] }, actor),
        /leaves the workspace through a symbolic link/,
      )
    })
  } finally {
    await rm(outside, { recursive: true, force: true })
  }
})

test('rejects a wiki directory symlink that leaves the workspace', { skip: process.platform === 'win32' }, async () => {
  const outside = await mkdtemp(path.join(os.tmpdir(), 'dsh-project-wiki-root-outside-'))
  try {
    await fixture(async (root, store) => {
      await symlink(outside, path.join(root, '.dsh'))
      await assert.rejects(
        store.listPages(),
        /Wiki directory leaves the workspace through a symbolic link/,
      )
    })
  } finally {
    await rm(outside, { recursive: true, force: true })
  }
})
