import assert from 'node:assert/strict'
import test from 'node:test'
import { registerWikiRpc } from '../src/rpc.ts'
import type { WikiService } from '../src/service.ts'

test('returns the DSH-required bad-request details shape', async () => {
  let handler: ((endpoint: string, payload: unknown, signal: AbortSignal) => Promise<any>) | undefined
  const ctx = {
    connection: {
      rpc: {
        handle(_channel: string, value: typeof handler) {
          handler = value
          return async () => undefined
        },
      },
    },
  }
  const service = {
    async read() { throw new Error("Unknown wiki page 'missing'") },
  } as unknown as WikiService
  registerWikiRpc(ctx, service)

  const result = await handler?.('read', { sessionId: 'session-test', pageId: 'missing' }, new AbortController().signal)
  assert.deepEqual(result, {
    ok: false,
    error: {
      code: 'bad-request',
      message: "Unknown wiki page 'missing'",
      details: { issues: [] },
    },
  })
})
