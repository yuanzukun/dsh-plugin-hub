import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

test('declares both the installable Cordis patch and Web client entry', async () => {
  const manifest = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8')) as Record<string, any>
  assert.equal(manifest.name, '@dsh-external/dsh-project-wiki')
  assert.equal(manifest.dsh.bundle.patch, './cordis.patch.yml')
  assert.equal(manifest.dsh.client.platform, 'web')
  assert.equal(manifest.exports['./client'].default, './lib/client.js')
})

test('reserves the live DSH composer area inside the Wiki view', async () => {
  const view = await readFile(new URL('../src/client/WikiView.tsx', import.meta.url), 'utf8')
  const styles = await readFile(new URL('../src/client/styles.ts', import.meta.url), 'utf8')

  assert.match(view, /data-conversation-composer-overlay=""/)
  assert.match(styles, /height:calc\(100% - var\(--dsh-composer-height,152px\)\)/)
})
