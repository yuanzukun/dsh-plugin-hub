import { defineTool, type JsonValue, type ToolRunContext } from '@deepseek-ai/dsh-tools'
import type { WikiService } from './service.ts'

interface ToolAgent {
  readonly id: string
  readonly ctx: { readonly tools: { register(definition: unknown): () => void } }
}

interface PageIdArgs { readonly id: string }
interface SearchArgs { readonly query: string; readonly limit?: number }
interface ProposeArgs {
  readonly title: string
  readonly summary?: string
  readonly tags?: string[]
  readonly body: string
  readonly source_paths?: string[]
}

function json(value: unknown): JsonValue {
  return JSON.parse(JSON.stringify(value)) as JsonValue
}

function render(_args: unknown, value: JsonValue): { type: 'text'; text: string }[] {
  return [{ type: 'text', text: JSON.stringify(value) }]
}

const JSON_OUTPUT = { schema: { type: 'json' }, render } as const

function present(title: string, kind: 'read' | 'other', rawInput?: unknown) {
  return { card: 'generic' as const, title, kind, ...(rawInput === undefined ? {} : { rawInput }) }
}

function failure(error: unknown, signal: AbortSignal): JsonValue {
  return json({
    ok: false,
    code: signal.aborted ? 'cancelled' : 'wiki_error',
    message: error instanceof Error ? error.message : String(error),
  })
}

/** Install read tools and approval-gated proposal tools into one exact root Agent. */
export function registerWikiTools(service: WikiService, agent: ToolAgent): () => void {
  const scope = { sessionId: agent.id, actorKind: 'agent' as const }
  const disposers: Array<() => void> = []
  const register = (definition: unknown): void => { disposers.push(agent.ctx.tools.register(definition)) }
  try {
    register(defineTool({
      name: 'wiki_search',
      description: 'Search the auditable project Wiki for this exact workspace. Results are backed by Markdown pages and a rebuildable local FTS index.',
      parameters: {
        query: { type: 'string', required: true },
        limit: { type: 'integer', description: 'Maximum results, clamped to 1-50.' },
      },
      output: JSON_OUTPUT,
      async execute(args: SearchArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          const limit = Math.max(1, Math.min(args.limit ?? 12, 50))
          return json({ ok: true, hits: await service.search(scope, args.query, limit, exec.signal) })
        } catch (error) { return failure(error, exec.signal) }
      },
      presentCall: (args: SearchArgs) => present('Search project Wiki', 'read', args.query),
    }))

    register(defineTool({
      name: 'wiki_read',
      description: 'Read one project Wiki page by id or slug, including source fingerprints, links, revision, and staleness.',
      parameters: { id: { type: 'string', required: true } },
      output: JSON_OUTPUT,
      async execute(args: PageIdArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try { return json({ ok: true, page: await service.read(scope, args.id, exec.signal) }) }
        catch (error) { return failure(error, exec.signal) }
      },
      presentCall: (args: PageIdArgs) => present('Read Wiki page', 'read', args.id),
    }))

    register(defineTool({
      name: 'wiki_backlinks',
      description: 'List Wiki pages that link to the selected page with [[page-slug]] or [[Page title]].',
      parameters: { id: { type: 'string', required: true } },
      output: JSON_OUTPUT,
      async execute(args: PageIdArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try { return json({ ok: true, pages: await service.backlinks(scope, args.id, exec.signal) }) }
        catch (error) { return failure(error, exec.signal) }
      },
      presentCall: (args: PageIdArgs) => present('Read Wiki backlinks', 'read', args.id),
    }))

    register(defineTool({
      name: 'wiki_check_stale',
      description: 'Compare Wiki source fingerprints with current workspace files without modifying the Wiki.',
      parameters: {},
      output: JSON_OUTPUT,
      async execute(_args: Record<string, never>, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try { return json({ ok: true, pages: await service.scanStale(scope, false, exec.signal) }) }
        catch (error) { return failure(error, exec.signal) }
      },
      presentCall: () => present('Check Wiki sources', 'read'),
    }))

    register(defineTool({
      name: 'wiki_propose',
      description: 'Create a reviewable project Wiki proposal. This does not change an accepted page; a human can approve it in the Wiki tab or with wiki_apply_proposal.',
      parameters: {
        title: { type: 'string', required: true },
        summary: { type: 'string' },
        tags: { type: 'array', items: { type: 'string' } },
        body: { type: 'string', required: true, description: 'Markdown body. Link accepted pages as [[page-slug]].' },
        source_paths: { type: 'array', items: { type: 'string' }, description: 'Workspace-relative files supporting the claim.' },
      },
      output: JSON_OUTPUT,
      async execute(args: ProposeArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try {
          const proposal = await service.propose(scope, {
            title: args.title,
            ...(args.summary === undefined ? {} : { summary: args.summary }),
            ...(args.tags === undefined ? {} : { tags: args.tags }),
            body: args.body,
            ...(args.source_paths === undefined ? {} : { sourcePaths: args.source_paths }),
          }, exec.signal)
          return json({ ok: true, proposal })
        } catch (error) { return failure(error, exec.signal) }
      },
      presentCall: (args: ProposeArgs) => present('Propose Wiki memory', 'other', args.title),
    }))

    register(defineTool({
      name: 'wiki_apply_proposal',
      description: 'Approve one existing Wiki proposal and persist it as an auditable Markdown page with fresh source fingerprints.',
      parameters: { id: { type: 'string', required: true } },
      output: JSON_OUTPUT,
      async execute(args: PageIdArgs, exec: ToolRunContext) {
        if (exec.agent !== agent || exec.signal.aborted) return json({ ok: false, code: 'cancelled' })
        try { return json({ ok: true, page: await service.applyProposal(scope, args.id, exec.signal) }) }
        catch (error) { return failure(error, exec.signal) }
      },
      presentCall: (args: PageIdArgs) => present('Approve Wiki proposal', 'other', args.id),
    }))
  } catch (error) {
    for (const dispose of disposers.reverse()) dispose()
    throw error
  }
  return () => { for (const dispose of disposers.reverse()) dispose() }
}
