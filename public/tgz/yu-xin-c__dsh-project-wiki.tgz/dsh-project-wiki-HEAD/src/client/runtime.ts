import type { ClientRpc } from './contracts.js'
import type {
  SaveWikiPageInput,
  WikiPageSummaryView,
  WikiPageView,
  WikiSearchHitView,
  WikiSnapshot,
} from './protocol.js'
import { unwrapRpcResult } from './protocol.js'

const CHANNEL = '/dsh-project-wiki'

export interface WikiClientState {
  readonly phase: 'idle' | 'loading' | 'ready' | 'error'
  readonly snapshot: WikiSnapshot | undefined
  readonly selectedPage: WikiPageView | undefined
  readonly backlinks: readonly WikiPageSummaryView[]
  readonly searchHits: readonly WikiSearchHitView[] | undefined
  readonly searching: boolean
  readonly error: string | undefined
  readonly refreshedAt: number | undefined
}

export interface WikiStateSource {
  getSnapshot(): WikiClientState
  subscribe(listener: () => void): () => void
}

export interface WikiRuntime {
  readonly source: WikiStateSource
  refresh(): Promise<void>
  openPage(pageId: string): Promise<void>
  search(query: string): Promise<void>
  savePage(input: SaveWikiPageInput): Promise<void>
  deletePage(pageId: string): Promise<void>
  approveProposal(proposalId: string): Promise<void>
  rejectProposal(proposalId: string): Promise<void>
  scanStale(): Promise<void>
}

/** Session-scoped observable used by the native conversation view slot. */
export function createWikiRuntime(rpc: ClientRpc, sessionId: string): WikiRuntime {
  let state: WikiClientState = {
    phase: 'idle',
    snapshot: undefined,
    selectedPage: undefined,
    backlinks: [],
    searchHits: undefined,
    searching: false,
    error: undefined,
    refreshedAt: undefined,
  }
  let refreshPromise: Promise<void> | undefined
  let pageSequence = 0
  let searchSequence = 0
  const listeners = new Set<() => void>()
  const publish = (next: WikiClientState): void => {
    state = next
    for (const listener of [...listeners]) listener()
  }
  const source: WikiStateSource = {
    getSnapshot: () => state,
    subscribe: (listener) => {
      listeners.add(listener)
      return () => { listeners.delete(listener) }
    },
  }

  const refresh = async (): Promise<void> => {
    if (refreshPromise !== undefined) return refreshPromise
    publish({ ...state, phase: 'loading', error: undefined })
    refreshPromise = (async () => {
      try {
        const response = await rpc.call(CHANNEL, 'snapshot', { sessionId })
        const snapshot = unwrapRpcResult<WikiSnapshot>(response)
        const selectedStillExists = state.selectedPage !== undefined
          && snapshot.pages.some(page => page.id === state.selectedPage?.id)
        publish({
          ...state,
          phase: 'ready',
          snapshot,
          selectedPage: selectedStillExists ? state.selectedPage : undefined,
          backlinks: selectedStillExists ? state.backlinks : [],
          error: undefined,
          refreshedAt: Date.now(),
        })
      } catch (error) {
        publish({
          ...state,
          phase: 'error',
          error: error instanceof Error ? error.message : String(error),
        })
        throw error
      } finally {
        refreshPromise = undefined
      }
    })()
    return refreshPromise
  }

  const openPage = async (pageId: string): Promise<void> => {
    const sequence = ++pageSequence
    try {
      const [pageResponse, backlinksResponse] = await Promise.all([
        rpc.call(CHANNEL, 'read', { sessionId, pageId }),
        rpc.call(CHANNEL, 'backlinks', { sessionId, pageId }),
      ])
      if (sequence !== pageSequence) return
      publish({
        ...state,
        selectedPage: unwrapRpcResult<WikiPageView>(pageResponse),
        backlinks: unwrapRpcResult<readonly WikiPageSummaryView[]>(backlinksResponse),
        error: undefined,
      })
    } catch (error) {
      if (sequence !== pageSequence) return
      publish({ ...state, error: error instanceof Error ? error.message : String(error) })
      throw error
    }
  }

  const search = async (query: string): Promise<void> => {
    const sequence = ++searchSequence
    if (query.trim() === '') {
      publish({ ...state, searchHits: undefined, searching: false })
      return
    }
    publish({ ...state, searching: true })
    try {
      const response = await rpc.call(CHANNEL, 'search', { sessionId, query, limit: 50 })
      if (sequence !== searchSequence) return
      publish({
        ...state,
        searchHits: unwrapRpcResult<readonly WikiSearchHitView[]>(response),
        searching: false,
        error: undefined,
      })
    } catch (error) {
      if (sequence !== searchSequence) return
      publish({ ...state, searching: false, error: error instanceof Error ? error.message : String(error) })
      throw error
    }
  }

  const mutate = async <Value>(endpoint: string, payload: Record<string, unknown>): Promise<Value> => {
    const response = await rpc.call(CHANNEL, endpoint, { sessionId, ...payload })
    return unwrapRpcResult<Value>(response)
  }

  const savePage = async (input: SaveWikiPageInput): Promise<void> => {
    const page = await mutate<WikiPageView>('save', { input })
    await refresh()
    await openPage(page.id)
  }

  const deletePage = async (pageId: string): Promise<void> => {
    await mutate('delete', { pageId })
    if (state.selectedPage?.id === pageId) {
      pageSequence += 1
      publish({ ...state, selectedPage: undefined, backlinks: [] })
    }
    await refresh()
  }

  const approveProposal = async (proposalId: string): Promise<void> => {
    const page = await mutate<WikiPageView>('apply-proposal', { proposalId })
    await refresh()
    await openPage(page.id)
  }

  const rejectProposal = async (proposalId: string): Promise<void> => {
    await mutate('reject-proposal', { proposalId })
    await refresh()
  }

  const scanStale = async (): Promise<void> => {
    await mutate('scan-stale', {})
    await refresh()
    if (state.selectedPage !== undefined) await openPage(state.selectedPage.id)
  }

  return { source, refresh, openPage, search, savePage, deletePage, approveProposal, rejectProposal, scanStale }
}
