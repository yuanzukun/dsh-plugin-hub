import type { ComponentType } from 'react'
import type { WikiLocaleKey } from './locales.js'
import type { WikiClientState, WikiRuntime } from './runtime.js'

export type Translate = (key: WikiLocaleKey, params?: Record<string, unknown>) => string

export interface SelectorHook<T> {
  <Selected>(selector: (value: T) => Selected): Selected
}

export interface WikiViewProps {
  readonly sessionId: string
  readonly t: Translate
  readonly useWikiState: SelectorHook<WikiClientState>
  readonly refresh: WikiRuntime['refresh']
  readonly openPage: WikiRuntime['openPage']
  readonly search: WikiRuntime['search']
  readonly savePage: WikiRuntime['savePage']
  readonly deletePage: WikiRuntime['deletePage']
  readonly approveProposal: WikiRuntime['approveProposal']
  readonly rejectProposal: WikiRuntime['rejectProposal']
  readonly scanStale: WikiRuntime['scanStale']
}

export interface ClientRpc {
  call(channel: string, endpoint: string, payload: unknown, signal?: AbortSignal): Promise<unknown>
}

export interface ClientContext {
  effect(factory: () => void | (() => void), label?: string): void
  connection: { readonly rpc: ClientRpc }
  locale: {
    register(
      namespace: string,
      dictionaries: { readonly zh: Record<string, string>; readonly en: Record<string, string> },
    ): () => void
    bind(namespace: string): Translate
  }
  slots: {
    inject(name: 'conversation.view', register: () => void | (() => void)): void
    register(
      options: {
        readonly name: 'conversation.view'
        readonly id: string
        readonly order: number
        readonly locale: string
        readonly label: () => string
        readonly inject: (sessionId: string) => {
          readonly hooks: { readonly wikiState: WikiRuntime['source'] }
          readonly refresh: WikiRuntime['refresh']
          readonly openPage: WikiRuntime['openPage']
          readonly search: WikiRuntime['search']
          readonly savePage: WikiRuntime['savePage']
          readonly deletePage: WikiRuntime['deletePage']
          readonly approveProposal: WikiRuntime['approveProposal']
          readonly rejectProposal: WikiRuntime['rejectProposal']
          readonly scanStale: WikiRuntime['scanStale']
        }
      },
      component: ComponentType<WikiViewProps>,
    ): () => void
  }
}
