import { WikiView } from './WikiView.js'
import type { ClientContext } from './contracts.js'
import { en, NS, zh } from './locales.js'
import { createWikiRuntime } from './runtime.js'
import { installStyles } from './styles.js'

export const name = 'dsh-project-wiki-client'
export const inject = ['slots', 'locale', 'connection', 'sessions']

/** Register a native, session-scoped Wiki view in DSH Web. */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => installStyles(), 'dsh-project-wiki: styles')
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-project-wiki: locale')
  const t = ctx.locale.bind(NS)
  const runtimes = new Map<string, ReturnType<typeof createWikiRuntime>>()
  ctx.effect(() => () => { runtimes.clear() }, 'dsh-project-wiki: session runtimes')
  ctx.slots.inject('conversation.view', () => ctx.slots.register({
    name: 'conversation.view',
    id: 'project-wiki',
    order: 35,
    locale: NS,
    label: () => t('tab'),
    inject: (sessionId) => {
      let runtime = runtimes.get(sessionId)
      if (runtime === undefined) {
        runtime = createWikiRuntime(ctx.connection.rpc, sessionId)
        runtimes.set(sessionId, runtime)
      }
      return {
        hooks: { wikiState: runtime.source },
        refresh: runtime.refresh,
        openPage: runtime.openPage,
        search: runtime.search,
        savePage: runtime.savePage,
        deletePage: runtime.deletePage,
        approveProposal: runtime.approveProposal,
        rejectProposal: runtime.rejectProposal,
        scanStale: runtime.scanStale,
      }
    },
  }, WikiView))
}
