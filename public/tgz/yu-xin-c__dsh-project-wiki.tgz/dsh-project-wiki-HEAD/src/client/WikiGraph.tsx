import { Maximize2, Network, ZoomIn, ZoomOut } from 'lucide-react'
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import ForceGraph2D, {
  type ForceGraphMethods,
  type GraphData,
  type LinkObject,
  type NodeObject,
} from 'react-force-graph-2d'
import type { Translate } from './contracts.js'
import type { WikiGraphData, WikiGraphLink, WikiGraphNode } from './graph.js'

interface GraphSize {
  readonly width: number
  readonly height: number
}

interface GraphPalette {
  readonly background: string
  readonly label: string
  readonly current: string
  readonly stale: string
  readonly missing: string
  readonly selected: string
}

const FALLBACK_PALETTE: GraphPalette = {
  background: '#ffffff',
  label: '#243047',
  current: '#2f9d68',
  stale: '#c47a14',
  missing: '#8792a5',
  selected: '#4f7fe8',
}

function shortLabel(value: string): string {
  return value.length > 30 ? `${value.slice(0, 29)}…` : value
}

function nodeColor(node: WikiGraphNode, palette: GraphPalette): string {
  if (node.status === 'stale') return palette.stale
  if (node.status === 'missing') return palette.missing
  return palette.current
}

export function WikiGraph({ graph, selectedPageId, t, onOpen }: {
  readonly graph: WikiGraphData
  readonly selectedPageId: string | undefined
  readonly t: Translate
  readonly onOpen: (pageId: string) => void
}): JSX.Element {
  const containerRef = useRef<HTMLDivElement>(null)
  const graphRef = useRef<ForceGraphMethods<NodeObject<WikiGraphNode>, LinkObject<WikiGraphNode, WikiGraphLink>>>()
  const fittedRef = useRef(false)
  const [size, setSize] = useState<GraphSize>({ width: 720, height: 560 })
  const [palette, setPalette] = useState<GraphPalette>(FALLBACK_PALETTE)
  const forceData = useMemo<GraphData<WikiGraphNode, WikiGraphLink>>(() => ({
    nodes: graph.nodes.map(node => ({ ...node })),
    links: graph.links.map(link => ({ ...link })),
  }), [graph])

  useEffect(() => { fittedRef.current = false }, [forceData])

  useLayoutEffect(() => {
    const element = containerRef.current
    if (element === null) return
    const update = (): void => {
      const bounds = element.getBoundingClientRect()
      setSize({
        width: Math.max(320, Math.floor(bounds.width)),
        height: Math.max(320, Math.floor(bounds.height)),
      })
      const styles = window.getComputedStyle(element)
      setPalette({
        ...FALLBACK_PALETTE,
        background: styles.backgroundColor === 'rgba(0, 0, 0, 0)'
          ? FALLBACK_PALETTE.background
          : styles.backgroundColor,
        label: styles.color || FALLBACK_PALETTE.label,
      })
    }
    update()
    const observer = new ResizeObserver(update)
    observer.observe(element)
    return () => { observer.disconnect() }
  }, [])

  const zoom = (factor: number): void => {
    const api = graphRef.current
    if (api === undefined) return
    api.zoom(Math.max(0.45, Math.min(api.zoom() * factor, 7)), 180)
  }

  const fit = (): void => {
    graphRef.current?.zoomToFit(280, size.width < 480 ? 42 : 88)
  }

  const paintNode = (rawNode: NodeObject<WikiGraphNode>, context: CanvasRenderingContext2D, globalScale: number): void => {
    const node = rawNode as NodeObject<WikiGraphNode>
    if (node.x === undefined || node.y === undefined) return
    const radius = (6 + Math.min(node.degree, 6) * 0.55) / globalScale
    const selected = node.pageId !== undefined && node.pageId === selectedPageId
    context.save()
    context.beginPath()
    context.arc(node.x, node.y, radius, 0, Math.PI * 2)
    if (node.status === 'missing') {
      context.setLineDash([2.5 / globalScale, 2.5 / globalScale])
      context.lineWidth = 1.5 / globalScale
      context.strokeStyle = palette.missing
      context.stroke()
    } else {
      context.fillStyle = nodeColor(node, palette)
      context.fill()
    }
    if (selected) {
      context.beginPath()
      context.arc(node.x, node.y, radius + (3.5 / globalScale), 0, Math.PI * 2)
      context.lineWidth = 2 / globalScale
      context.strokeStyle = palette.selected
      context.stroke()
    }

    const fontSize = 11 / globalScale
    const offset = radius + (5 / globalScale)
    const label = shortLabel(node.title)
    context.font = `600 ${fontSize}px system-ui, sans-serif`
    const labelWidth = context.measureText(label).width
    const screen = graphRef.current?.graph2ScreenCoords(node.x, node.y)
    const placeLabelLeft = screen !== undefined
      && screen.x + ((offset + labelWidth) * globalScale) > size.width - 12
    const labelX = placeLabelLeft ? node.x - offset - labelWidth : node.x + offset
    context.globalAlpha = 0.88
    context.fillStyle = palette.background
    context.fillRect(labelX - (2 / globalScale), node.y - fontSize * 0.72, labelWidth + (4 / globalScale), fontSize * 1.25)
    context.globalAlpha = 1
    context.fillStyle = palette.label
    context.textBaseline = 'middle'
    context.fillText(label, labelX, node.y)
    context.restore()
  }

  if (graph.nodes.length === 0) {
    return <div className="dsh-wiki-empty"><Network /><h2>{t('graphEmpty')}</h2></div>
  }

  return (
    <section className="dsh-wiki-graph-view">
      <header className="dsh-wiki-graph-head">
        <div><Network /><h2>{t('graph')}</h2><span>{graph.nodes.length} {t('graphNodes')} · {graph.links.length} {t('graphEdges')}</span></div>
        <div className="dsh-wiki-graph-controls">
          <button className="dsh-wiki-icon-button" type="button" title={t('zoomOut')} aria-label={t('zoomOut')} onClick={() => zoom(0.8)}><ZoomOut /></button>
          <button className="dsh-wiki-icon-button" type="button" title={t('zoomIn')} aria-label={t('zoomIn')} onClick={() => zoom(1.25)}><ZoomIn /></button>
          <button className="dsh-wiki-icon-button" type="button" title={t('fitGraph')} aria-label={t('fitGraph')} onClick={fit}><Maximize2 /></button>
        </div>
      </header>
      <div className="dsh-wiki-graph-canvas" ref={containerRef}>
        <ForceGraph2D<WikiGraphNode, WikiGraphLink>
          ref={graphRef}
          graphData={forceData}
          width={size.width}
          height={size.height}
          backgroundColor={palette.background}
          nodeId="id"
          nodeVal={node => 1.2 + Math.min(node.degree, 6) * 0.3}
          nodeColor={node => nodeColor(node, palette)}
          nodeCanvasObjectMode={() => 'replace'}
          nodeCanvasObject={paintNode}
          linkColor={() => 'rgba(112, 126, 148, 0.48)'}
          linkWidth={1.2}
          linkDirectionalArrowLength={4}
          linkDirectionalArrowRelPos={0.82}
          linkDirectionalArrowColor={() => 'rgba(112, 126, 148, 0.72)'}
          cooldownTicks={90}
          d3AlphaDecay={0.035}
          d3VelocityDecay={0.28}
          minZoom={0.35}
          maxZoom={7}
          enableNodeDrag
          enablePanInteraction
          enableZoomInteraction
          showPointerCursor={object => (object as Partial<WikiGraphNode>).pageId !== undefined}
          onNodeClick={node => { if (node.pageId !== undefined) onOpen(node.pageId) }}
          onEngineStop={() => {
            if (fittedRef.current) return
            fittedRef.current = true
            fit()
          }}
        />
      </div>
    </section>
  )
}
