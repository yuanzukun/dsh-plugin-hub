import type { WikiPageSummaryView, WikiStatus } from './protocol.js'

export type WikiGraphNodeStatus = WikiStatus | 'missing'

export interface WikiGraphNode {
  readonly id: string
  readonly pageId: string | undefined
  readonly title: string
  readonly summary: string
  readonly status: WikiGraphNodeStatus
  readonly degree: number
}

export interface WikiGraphLink {
  readonly id: string
  readonly source: string
  readonly target: string
}

export interface WikiGraphData {
  readonly nodes: readonly WikiGraphNode[]
  readonly links: readonly WikiGraphLink[]
  readonly unresolvedCount: number
}

function alias(value: string): string {
  return value.normalize('NFKC').trim().toLowerCase()
}

/** Build a stable directed graph from accepted pages and their Wiki links. */
export function buildWikiGraph(pages: readonly WikiPageSummaryView[]): WikiGraphData {
  const aliases = new Map<string, string>()
  const nodes = new Map<string, Omit<WikiGraphNode, 'degree'>>()
  for (const page of pages) {
    nodes.set(page.id, {
      id: page.id,
      pageId: page.id,
      title: page.title,
      summary: page.summary,
      status: page.status,
    })
    aliases.set(alias(page.slug), page.id)
    aliases.set(alias(page.title), page.id)
  }

  const links = new Map<string, WikiGraphLink>()
  let unresolvedCount = 0
  for (const page of pages) {
    for (const rawTarget of page.links ?? []) {
      const normalized = alias(rawTarget)
      if (normalized === '') continue
      let target = aliases.get(normalized)
      if (target === undefined) {
        target = `missing:${normalized}`
        if (!nodes.has(target)) {
          nodes.set(target, {
            id: target,
            pageId: undefined,
            title: rawTarget,
            summary: '',
            status: 'missing',
          })
          unresolvedCount += 1
        }
      }
      const id = `${page.id}->${target}`
      links.set(id, { id, source: page.id, target })
    }
  }

  const degree = new Map<string, number>()
  for (const link of links.values()) {
    degree.set(link.source, (degree.get(link.source) ?? 0) + 1)
    degree.set(link.target, (degree.get(link.target) ?? 0) + 1)
  }

  return {
    nodes: [...nodes.values()].map(node => ({ ...node, degree: degree.get(node.id) ?? 0 })),
    links: [...links.values()],
    unresolvedCount,
  }
}
