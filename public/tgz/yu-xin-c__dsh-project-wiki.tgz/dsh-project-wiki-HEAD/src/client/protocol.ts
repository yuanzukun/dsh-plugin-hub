export type WikiStatus = 'current' | 'stale'
export type WikiActorKind = 'agent' | 'web'

export interface WikiActorView {
  readonly kind: WikiActorKind
  readonly sessionId: string
}

export interface WikiSourceView {
  readonly path: string
  readonly sha256: string
}

export interface WikiPageSummaryView {
  readonly id: string
  readonly revision: number
  readonly slug: string
  readonly title: string
  readonly summary: string
  readonly tags: readonly string[]
  readonly links: readonly string[]
  readonly sourceCount: number
  readonly staleSources: readonly string[]
  readonly status: WikiStatus
  readonly updatedAt: string
  readonly updatedBy: WikiActorView
}

export interface WikiPageView {
  readonly id: string
  readonly revision: number
  readonly slug: string
  readonly title: string
  readonly summary: string
  readonly tags: readonly string[]
  readonly body: string
  readonly links: readonly string[]
  readonly sources: readonly WikiSourceView[]
  readonly staleSources: readonly string[]
  readonly status: WikiStatus
  readonly createdAt: string
  readonly updatedAt: string
  readonly createdBy: WikiActorView
  readonly updatedBy: WikiActorView
}

export interface WikiProposalView {
  readonly id: string
  readonly title: string
  readonly summary: string
  readonly tags: readonly string[]
  readonly body: string
  readonly sourcePaths: readonly string[]
  readonly createdAt: string
  readonly createdBy: WikiActorView
}

export interface WikiSearchHitView {
  readonly id: string
  readonly slug: string
  readonly title: string
  readonly summary: string
  readonly tags: readonly string[]
  readonly status: WikiStatus
  readonly updatedAt: string
  readonly snippet: string
}

export interface WikiSnapshot {
  readonly scope: {
    readonly workspaceId: string
    readonly workspaceName: string
    readonly cwd: string
    readonly wikiDirectory: string
  }
  readonly pages: readonly WikiPageSummaryView[]
  readonly proposals: readonly WikiProposalView[]
  readonly generatedAt: string
}

export interface SaveWikiPageInput {
  readonly id?: string
  readonly title: string
  readonly summary?: string
  readonly tags?: readonly string[]
  readonly body: string
  readonly sourcePaths?: readonly string[]
}

export interface RpcSuccess<Value> { readonly ok: true; readonly value: Value }
export interface RpcFailure {
  readonly ok: false
  readonly error: { readonly code: string; readonly message: string; readonly details?: unknown }
}

export function unwrapRpcResult<Value>(value: unknown): Value {
  if (typeof value !== 'object' || value === null) throw new Error('Wiki RPC returned an invalid response.')
  const result = value as RpcSuccess<Value> | RpcFailure
  if (result.ok) return result.value
  throw new Error(result.error?.message ?? 'Wiki RPC request failed.')
}
