import {
  AlertTriangle,
  BookOpenText,
  Check,
  Clock3,
  FileCode2,
  FileText,
  GitBranch,
  Inbox,
  Link2,
  LoaderCircle,
  Network,
  Pencil,
  Plus,
  RefreshCw,
  Save,
  ScanSearch,
  Search,
  Trash2,
  X,
} from 'lucide-react'
import { useEffect, useLayoutEffect, useMemo, useRef, useState, type FormEvent } from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { buildWikiGraph } from './graph.js'
import type { Translate, WikiViewProps } from './contracts.js'
import type {
  SaveWikiPageInput,
  WikiActorView,
  WikiPageSummaryView,
  WikiPageView,
  WikiProposalView,
  WikiStatus,
} from './protocol.js'
import { WikiGraph } from './WikiGraph.js'

const POLL_INTERVAL_MS = 30_000

interface EditorState {
  readonly id: string | undefined
  readonly title: string
  readonly summary: string
  readonly tags: string
  readonly sources: string
  readonly body: string
}

function formatDate(value: string): string {
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat(undefined, {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date)
}

function actorLabel(t: Translate, actor: WikiActorView): string {
  return t(actor.kind === 'agent' ? 'byAgent' : 'byWeb')
}

function editorFromPage(page?: WikiPageView): EditorState {
  return {
    id: page?.id,
    title: page?.title ?? '',
    summary: page?.summary ?? '',
    tags: page?.tags.join(', ') ?? '',
    sources: page?.sources.map(source => source.path).join('\n') ?? '',
    body: page?.body ?? '',
  }
}

function StatusBadge({ status, t }: { readonly status: WikiStatus; readonly t: Translate }): JSX.Element {
  return (
    <span className={`dsh-wiki-status dsh-wiki-status--${status}`}>
      {status === 'stale' ? <AlertTriangle /> : <Check />}
      {t(status === 'stale' ? 'staleStatus' : 'currentStatus')}
    </span>
  )
}

function TagList({ tags }: { readonly tags: readonly string[] }): JSX.Element | null {
  if (tags.length === 0) return null
  return <div className="dsh-wiki-tags">{tags.map(tag => <span key={tag}>{tag}</span>)}</div>
}

function PageListItem({ page, active, onOpen }: {
  readonly page: WikiPageSummaryView
  readonly active: boolean
  readonly onOpen: () => void
}): JSX.Element {
  return (
    <button
      className={`dsh-wiki-list-item${active ? ' is-active' : ''}`}
      type="button"
      onClick={onOpen}
    >
      <span className={`dsh-wiki-list-status is-${page.status}`} />
      <span className="dsh-wiki-list-copy">
        <strong>{page.title}</strong>
        <small>{page.summary}</small>
        <span className="dsh-wiki-list-meta">
          <time dateTime={page.updatedAt}>{formatDate(page.updatedAt)}</time>
          {page.tags.slice(0, 2).map(tag => <em key={tag}>{tag}</em>)}
        </span>
      </span>
    </button>
  )
}

function ProposalListItem({ proposal, active, onOpen }: {
  readonly proposal: WikiProposalView
  readonly active: boolean
  readonly onOpen: () => void
}): JSX.Element {
  return (
    <button className={`dsh-wiki-list-item${active ? ' is-active' : ''}`} type="button" onClick={onOpen}>
      <span className="dsh-wiki-list-icon"><Inbox /></span>
      <span className="dsh-wiki-list-copy">
        <strong>{proposal.title}</strong>
        <small>{proposal.summary}</small>
        <span className="dsh-wiki-list-meta">
          <time dateTime={proposal.createdAt}>{formatDate(proposal.createdAt)}</time>
          <em>{proposal.createdBy.kind}</em>
        </span>
      </span>
    </button>
  )
}

function WikiEditor({ editor, t, busy, error, onChange, onCancel, onSave }: {
  readonly editor: EditorState
  readonly t: Translate
  readonly busy: boolean
  readonly error: string | undefined
  readonly onChange: (next: EditorState) => void
  readonly onCancel: () => void
  readonly onSave: (input: SaveWikiPageInput) => void
}): JSX.Element {
  const update = (key: keyof EditorState, value: string): void => { onChange({ ...editor, [key]: value }) }
  const submit = (event: FormEvent): void => {
    event.preventDefault()
    const tags = editor.tags.split(',').map(value => value.trim()).filter(Boolean)
    const sourcePaths = editor.sources.split(/\r?\n/).map(value => value.trim()).filter(Boolean)
    onSave({
      ...(editor.id === undefined ? {} : { id: editor.id }),
      title: editor.title,
      summary: editor.summary,
      tags,
      body: editor.body,
      sourcePaths,
    })
  }
  return (
    <form className="dsh-wiki-editor" onSubmit={submit}>
      <div className="dsh-wiki-editor-head">
        <div>
          <FileText />
          <h2>{editor.id === undefined ? t('create') : t('edit')}</h2>
        </div>
        <button className="dsh-wiki-icon-button" type="button" title={t('cancel')} aria-label={t('cancel')} onClick={onCancel} disabled={busy}><X /></button>
      </div>
      <div className="dsh-wiki-form-grid">
        <label className="dsh-wiki-field">
          <span>{t('titleField')}</span>
          <input value={editor.title} maxLength={160} placeholder={t('titlePlaceholder')} onChange={event => update('title', event.currentTarget.value)} />
        </label>
        <label className="dsh-wiki-field">
          <span>{t('tagsField')}</span>
          <input value={editor.tags} placeholder={t('tagsPlaceholder')} onChange={event => update('tags', event.currentTarget.value)} />
        </label>
        <label className="dsh-wiki-field dsh-wiki-field--wide">
          <span>{t('summaryField')}</span>
          <input value={editor.summary} maxLength={300} placeholder={t('summaryPlaceholder')} onChange={event => update('summary', event.currentTarget.value)} />
        </label>
        <label className="dsh-wiki-field dsh-wiki-field--wide">
          <span>{t('sourcesField')}</span>
          <textarea className="is-sources" value={editor.sources} rows={3} placeholder={t('sourcesPlaceholder')} onChange={event => update('sources', event.currentTarget.value)} />
        </label>
        <label className="dsh-wiki-field dsh-wiki-field--wide">
          <span>{t('bodyField')}</span>
          <textarea className="is-body" value={editor.body} rows={18} placeholder={t('bodyPlaceholder')} onChange={event => update('body', event.currentTarget.value)} />
        </label>
      </div>
      <div className="dsh-wiki-editor-footer">
        <span role="alert">{error}</span>
        <button className="dsh-wiki-button" type="button" onClick={onCancel} disabled={busy}>{t('cancel')}</button>
        <button className="dsh-wiki-button dsh-wiki-button--primary" type="submit" disabled={busy}>
          {busy ? <LoaderCircle className="is-spin" /> : <Save />}
          {busy ? t('saving') : t('save')}
        </button>
      </div>
    </form>
  )
}

function MarkdownBody({ body }: { readonly body: string }): JSX.Element {
  return (
    <div className="dsh-wiki-markdown">
      <ReactMarkdown remarkPlugins={[remarkGfm]}>{body}</ReactMarkdown>
    </div>
  )
}

function PageDetail({ page, backlinks, t, busy, confirmDelete, onEdit, onDelete, onConfirmDelete, onOpen }: {
  readonly page: WikiPageView
  readonly backlinks: readonly WikiPageSummaryView[]
  readonly t: Translate
  readonly busy: boolean
  readonly confirmDelete: boolean
  readonly onEdit: () => void
  readonly onDelete: () => void
  readonly onConfirmDelete: (value: boolean) => void
  readonly onOpen: (id: string) => void
}): JSX.Element {
  return (
    <article className="dsh-wiki-page">
      <header className="dsh-wiki-page-head">
        <div className="dsh-wiki-page-title">
          <div className="dsh-wiki-page-icon"><BookOpenText /></div>
          <div>
            <div className="dsh-wiki-title-line"><h2>{page.title}</h2><StatusBadge status={page.status} t={t} /></div>
            <p>{page.summary}</p>
            <TagList tags={page.tags} />
          </div>
        </div>
        <div className="dsh-wiki-page-actions">
          <button className="dsh-wiki-icon-button" type="button" title={t('edit')} aria-label={t('edit')} onClick={onEdit}><Pencil /></button>
          <button className="dsh-wiki-icon-button is-danger" type="button" title={t('delete')} aria-label={t('delete')} onClick={() => onConfirmDelete(true)}><Trash2 /></button>
        </div>
      </header>

      {confirmDelete && (
        <div className="dsh-wiki-delete-confirm">
          <span><AlertTriangle />{t('confirm')}</span>
          <div>
            <button className="dsh-wiki-button" type="button" onClick={() => onConfirmDelete(false)} disabled={busy}>{t('cancel')}</button>
            <button className="dsh-wiki-button dsh-wiki-button--danger" type="button" onClick={onDelete} disabled={busy}>
              {busy ? <LoaderCircle className="is-spin" /> : <Trash2 />}{busy ? t('deleting') : t('confirm')}
            </button>
          </div>
        </div>
      )}

      {page.status === 'stale' && (
        <div className="dsh-wiki-stale-callout">
          <AlertTriangle />
          <div><strong>{t('staleStatus')}</strong><span>{t('sourceChanged')} {page.staleSources.join(', ')}</span></div>
        </div>
      )}

      <dl className="dsh-wiki-metadata">
        <div><dt><GitBranch />{t('revision')}</dt><dd>v{page.revision}</dd></div>
        <div><dt><Clock3 />{t('updated')}</dt><dd>{formatDate(page.updatedAt)} · {actorLabel(t, page.updatedBy)}</dd></div>
        <div><dt><Clock3 />{t('created')}</dt><dd>{formatDate(page.createdAt)} · {actorLabel(t, page.createdBy)}</dd></div>
      </dl>

      <section className="dsh-wiki-resource-section">
        <h3><FileCode2 />{t('sources')}</h3>
        {page.sources.length === 0 ? <p className="dsh-wiki-muted">{t('noSources')}</p> : (
          <div className="dsh-wiki-source-list">
            {page.sources.map(source => (
              <div className={page.staleSources.includes(source.path) ? 'is-stale' : ''} key={source.path}>
                <code>{source.path}</code><span>{source.sha256.slice(0, 12)}</span>
              </div>
            ))}
          </div>
        )}
      </section>

      <MarkdownBody body={page.body} />

      <section className="dsh-wiki-resource-section dsh-wiki-backlinks">
        <h3><Link2 />{t('backlinks')}</h3>
        {backlinks.length === 0 ? <p className="dsh-wiki-muted">{t('noBacklinks')}</p> : (
          <div>{backlinks.map(item => (
            <button key={item.id} type="button" onClick={() => onOpen(item.id)}><BookOpenText />{item.title}</button>
          ))}</div>
        )}
      </section>
    </article>
  )
}

function ProposalDetail({ proposal, t, busy, onApprove, onReject }: {
  readonly proposal: WikiProposalView
  readonly t: Translate
  readonly busy: 'approve' | 'reject' | undefined
  readonly onApprove: () => void
  readonly onReject: () => void
}): JSX.Element {
  return (
    <article className="dsh-wiki-page dsh-wiki-proposal">
      <header className="dsh-wiki-page-head">
        <div className="dsh-wiki-page-title">
          <div className="dsh-wiki-page-icon is-proposal"><Inbox /></div>
          <div>
            <span className="dsh-wiki-proposal-label">{t('proposal')}</span>
            <h2>{proposal.title}</h2>
            <p>{proposal.summary}</p>
            <TagList tags={proposal.tags} />
          </div>
        </div>
      </header>
      <dl className="dsh-wiki-metadata">
        <div><dt><Clock3 />{t('created')}</dt><dd>{formatDate(proposal.createdAt)} · {actorLabel(t, proposal.createdBy)}</dd></div>
        <div><dt><FileCode2 />{t('sources')}</dt><dd>{proposal.sourcePaths.length}</dd></div>
      </dl>
      {proposal.sourcePaths.length > 0 && (
        <section className="dsh-wiki-resource-section">
          <h3><FileCode2 />{t('sources')}</h3>
          <div className="dsh-wiki-source-list">{proposal.sourcePaths.map(source => <div key={source}><code>{source}</code></div>)}</div>
        </section>
      )}
      <MarkdownBody body={proposal.body} />
      <footer className="dsh-wiki-proposal-actions">
        <button className="dsh-wiki-button" type="button" onClick={onReject} disabled={busy !== undefined}>
          {busy === 'reject' ? <LoaderCircle className="is-spin" /> : <X />}{busy === 'reject' ? t('rejecting') : t('reject')}
        </button>
        <button className="dsh-wiki-button dsh-wiki-button--primary" type="button" onClick={onApprove} disabled={busy !== undefined}>
          {busy === 'approve' ? <LoaderCircle className="is-spin" /> : <Check />}{busy === 'approve' ? t('approving') : t('approve')}
        </button>
      </footer>
    </article>
  )
}

/** Workspace Wiki: search, review, edit, source audit, and proposal approval. */
export function WikiView({
  t, useWikiState, refresh, openPage, search, savePage, deletePage, approveProposal, rejectProposal, scanStale,
}: WikiViewProps): JSX.Element {
  const state = useWikiState(value => value)
  const [section, setSection] = useState<'pages' | 'graph' | 'proposals'>('pages')
  const [query, setQuery] = useState('')
  const [editor, setEditor] = useState<EditorState>()
  const [selectedProposalId, setSelectedProposalId] = useState<string>()
  const [openingId, setOpeningId] = useState<string>()
  const [busy, setBusy] = useState<string>()
  const [actionError, setActionError] = useState<string>()
  const [confirmDelete, setConfirmDelete] = useState(false)
  const shellRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    void refresh().catch(() => undefined)
    const timer = window.setInterval(() => { void refresh().catch(() => undefined) }, POLL_INTERVAL_MS)
    return () => { window.clearInterval(timer) }
  }, [refresh])

  useEffect(() => {
    const timer = window.setTimeout(() => { void search(query).catch(() => undefined) }, 240)
    return () => { window.clearTimeout(timer) }
  }, [query, search])

  const snapshot = state.snapshot
  const pages = snapshot?.pages ?? []
  const proposals = snapshot?.proposals ?? []
  const graph = useMemo(() => buildWikiGraph(pages), [pages])
  const pageById = useMemo(() => new Map(pages.map(page => [page.id, page])), [pages])
  const visiblePages = state.searchHits === undefined
    ? pages
    : state.searchHits.flatMap(hit => {
        const page = pageById.get(hit.id)
        return page === undefined ? [] : [page]
      })
  const selectedProposal = proposals.find(item => item.id === selectedProposalId) ?? proposals[0]
  const currentCount = pages.filter(page => page.status === 'current').length
  const staleCount = pages.length - currentCount
  const sectionSelection = section === 'pages'
    ? state.selectedPage?.id ?? ''
    : section === 'proposals' ? selectedProposal?.id ?? '' : 'graph'
  const scrollKey = editor === undefined
    ? `${section}:${sectionSelection}`
    : `editor:${editor.id ?? 'new'}`

  useLayoutEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      let element: HTMLElement | null = shellRef.current
      while (element !== null) {
        const overflowY = window.getComputedStyle(element).overflowY
        if ((overflowY === 'auto' || overflowY === 'scroll') && element.scrollHeight > element.clientHeight) {
          element.scrollTop = 0
          return
        }
        element = element.parentElement
      }
    })
    return () => { window.cancelAnimationFrame(frame) }
  }, [scrollKey])

  useEffect(() => {
    if (section !== 'pages' || editor !== undefined || state.selectedPage !== undefined || openingId !== undefined) return
    const first = visiblePages[0]
    if (first === undefined) return
    setOpeningId(first.id)
    void openPage(first.id).catch(() => undefined).finally(() => { setOpeningId(undefined) })
  }, [editor, openingId, openPage, section, state.selectedPage, visiblePages])

  const perform = async (key: string, action: () => Promise<void>): Promise<void> => {
    setBusy(key)
    setActionError(undefined)
    try { await action() }
    catch (error) { setActionError(error instanceof Error ? error.message : t('actionError')) }
    finally { setBusy(undefined) }
  }

  const handleOpen = (id: string): void => {
    setSection('pages')
    setEditor(undefined)
    setConfirmDelete(false)
    setOpeningId(id)
    void openPage(id).catch(() => undefined).finally(() => { setOpeningId(undefined) })
  }
  const handleSave = (input: SaveWikiPageInput): void => {
    if (input.title.trim() === '' || input.body.trim() === '') {
      setActionError(t('required'))
      return
    }
    void perform('save', async () => {
      await savePage(input)
      setQuery('')
      setEditor(undefined)
    })
  }
  const handleDelete = (): void => {
    const id = state.selectedPage?.id
    if (id === undefined) return
    void perform('delete', async () => {
      await deletePage(id)
      setConfirmDelete(false)
    })
  }
  const handleApprove = (id: string): void => {
    void perform('approve', async () => {
      await approveProposal(id)
      setQuery('')
      setSelectedProposalId(undefined)
      setSection('pages')
    })
  }
  const handleReject = (id: string): void => {
    void perform('reject', async () => {
      await rejectProposal(id)
      setSelectedProposalId(undefined)
    })
  }

  if (state.phase === 'loading' && snapshot === undefined) {
    return <div className="dsh-wiki-centered"><LoaderCircle className="is-spin" /><h2>{t('loading')}</h2></div>
  }
  if (state.phase === 'error' && snapshot === undefined) {
    return (
      <div className="dsh-wiki-centered is-error">
        <AlertTriangle /><h2>{t('loadError')}</h2><p>{state.error}</p>
        <button className="dsh-wiki-button" type="button" onClick={() => { void refresh().catch(() => undefined) }}>{t('retry')}</button>
      </div>
    )
  }

  return (
    <div className="dsh-wiki-shell" data-conversation-composer-overlay="" ref={shellRef}>
      <header className="dsh-wiki-topbar">
        <div className="dsh-wiki-brand"><span><BookOpenText /></span><div><h1>{t('title')}</h1><p>{snapshot?.scope.workspaceName}</p></div></div>
        <div className="dsh-wiki-toolbar">
          <button className="dsh-wiki-icon-button" type="button" title={t('refresh')} aria-label={t('refresh')} onClick={() => { setActionError(undefined); void refresh().catch(() => undefined) }} disabled={state.phase === 'loading'}><RefreshCw className={state.phase === 'loading' ? 'is-spin' : ''} /></button>
          <button className="dsh-wiki-button" type="button" onClick={() => { void perform('scan', scanStale) }} disabled={busy !== undefined}><ScanSearch />{busy === 'scan' ? t('scanning') : t('scan')}</button>
          <button className="dsh-wiki-button dsh-wiki-button--primary" type="button" onClick={() => { setSection('pages'); setEditor(editorFromPage()); setActionError(undefined) }}><Plus />{t('create')}</button>
        </div>
      </header>

      <div className="dsh-wiki-scope">
        <span><strong>{t('workspace')}</strong><code>{snapshot?.scope.cwd}</code></span>
        <span><strong>{t('wikiPath')}</strong><code>{snapshot?.scope.wikiDirectory}</code></span>
      </div>

      <div className="dsh-wiki-stats">
        <div><span>{t('total')}</span><strong>{pages.length}</strong></div>
        <div className="is-current"><span>{t('current')}</span><strong>{currentCount}</strong></div>
        <div className={staleCount > 0 ? 'is-stale' : ''}><span>{t('stale')}</span><strong>{staleCount}</strong></div>
        <div className={proposals.length > 0 ? 'is-pending' : ''}><span>{t('pending')}</span><strong>{proposals.length}</strong></div>
      </div>

      {(actionError ?? state.error) !== undefined && <div className="dsh-wiki-error" role="alert"><AlertTriangle />{actionError ?? state.error}</div>}

      <div className="dsh-wiki-workspace">
        <aside className="dsh-wiki-sidebar">
          <div className="dsh-wiki-segmented">
            <button type="button" className={section === 'pages' ? 'is-active' : ''} onClick={() => setSection('pages')}><FileText />{t('pages')}<span>{pages.length}</span></button>
            <button type="button" className={section === 'graph' ? 'is-active' : ''} onClick={() => { setSection('graph'); setEditor(undefined) }}><Network />{t('graph')}<span>{graph.links.length}</span></button>
            <button type="button" className={section === 'proposals' ? 'is-active' : ''} onClick={() => setSection('proposals')}><Inbox />{t('proposals')}<span>{proposals.length}</span></button>
          </div>
          {section === 'pages' && (
            <label className="dsh-wiki-search">
              {state.searching ? <LoaderCircle className="is-spin" /> : <Search />}
              <input aria-label={t('search')} value={query} placeholder={t('search')} onChange={event => setQuery(event.currentTarget.value)} />
              {query !== '' && <button type="button" title={t('cancel')} aria-label={t('cancel')} onClick={() => setQuery('')}><X /></button>}
            </label>
          )}
          <div className="dsh-wiki-list">
            {section === 'pages' && visiblePages.map(page => (
              <PageListItem key={page.id} page={page} active={state.selectedPage?.id === page.id} onOpen={() => handleOpen(page.id)} />
            ))}
            {section === 'pages' && visiblePages.length === 0 && <div className="dsh-wiki-list-empty">{query === '' ? t('emptyTitle') : t('noResults')}</div>}
            {section === 'proposals' && proposals.map(proposal => (
              <ProposalListItem key={proposal.id} proposal={proposal} active={selectedProposal?.id === proposal.id} onOpen={() => setSelectedProposalId(proposal.id)} />
            ))}
            {section === 'proposals' && proposals.length === 0 && <div className="dsh-wiki-list-empty">{t('emptyProposal')}</div>}
            {section === 'graph' && (
              <div className="dsh-wiki-graph-summary">
                <dl>
                  <div><dt>{t('graphNodes')}</dt><dd>{graph.nodes.length}</dd></div>
                  <div><dt>{t('graphEdges')}</dt><dd>{graph.links.length}</dd></div>
                  <div><dt>{t('graphUnresolved')}</dt><dd>{graph.unresolvedCount}</dd></div>
                </dl>
                <div className="dsh-wiki-graph-legend">
                  <span className="is-current">{t('current')}</span>
                  <span className="is-stale">{t('stale')}</span>
                  <span className="is-missing">{t('graphUnresolved')}</span>
                </div>
              </div>
            )}
          </div>
        </aside>

        <main className="dsh-wiki-main">
          {editor !== undefined ? (
            <WikiEditor editor={editor} t={t} busy={busy === 'save'} error={actionError} onChange={setEditor} onCancel={() => { setEditor(undefined); setActionError(undefined) }} onSave={handleSave} />
          ) : section === 'graph' ? (
            <WikiGraph graph={graph} selectedPageId={state.selectedPage?.id} t={t} onOpen={handleOpen} />
          ) : section === 'proposals' ? (
            selectedProposal === undefined
              ? <div className="dsh-wiki-empty"><Inbox /><h2>{t('emptyProposal')}</h2></div>
              : <ProposalDetail proposal={selectedProposal} t={t} busy={busy === 'approve' ? 'approve' : busy === 'reject' ? 'reject' : undefined} onApprove={() => handleApprove(selectedProposal.id)} onReject={() => handleReject(selectedProposal.id)} />
          ) : state.selectedPage === undefined ? (
            <div className="dsh-wiki-empty"><BookOpenText /><h2>{pages.length === 0 ? t('emptyTitle') : t('emptySelection')}</h2>{pages.length === 0 && <button className="dsh-wiki-button dsh-wiki-button--primary" type="button" onClick={() => setEditor(editorFromPage())}><Plus />{t('create')}</button>}</div>
          ) : (
            <PageDetail page={state.selectedPage} backlinks={state.backlinks} t={t} busy={busy === 'delete'} confirmDelete={confirmDelete} onEdit={() => setEditor(editorFromPage(state.selectedPage))} onDelete={handleDelete} onConfirmDelete={setConfirmDelete} onOpen={handleOpen} />
          )}
        </main>
      </div>
    </div>
  )
}
