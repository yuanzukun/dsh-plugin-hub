import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-connection'
import z from '@deepseek-ai/schemastery'
import { registerWikiRpc } from './rpc.ts'
import { WikiService } from './service.ts'
import { registerWikiTools } from './tools.ts'

export const name = 'dsh-project-wiki'
export const inject = ['agents', 'workspaceRegistry', 'tools', 'connection']

export interface Config {
  readonly directory?: string
  readonly maxPages?: number
}

export const Config = z.object({
  directory: z.string().default('.dsh/wiki'),
  maxPages: z.number().step(1).min(1).max(10_000).default(1000),
})

const MUTATING_TOOLS = new Set(['wiki_propose', 'wiki_apply_proposal'])

export function needsHumanApproval(exec: { readonly name: string; readonly signal: AbortSignal }, mounted: boolean): boolean {
  return mounted && !exec.signal.aborted && MUTATING_TOOLS.has(exec.name)
}

export function humanApprovalReason(toolName: string): string {
  return toolName === 'wiki_apply_proposal'
    ? 'This accepts a proposal into the durable project Wiki. Review its claims and cited source files first.'
    : 'This writes a durable Wiki proposal into the project workspace. Review the proposed claim and source files.'
}

/** Mount the workspace Wiki authority, root-Agent tools, and Web RPC. */
export function apply(ctx: Context, rawConfig: Config): void {
  const config = rawConfig as Required<Config>
  ctx.effect(() => {
    const service = new WikiService(ctx, config)
    const mounted = new Map<object, () => void | Promise<void>>()
    let alive = true

    const mount = (agent: any): void => {
      if (!alive || mounted.has(agent) || !ctx.agents.roots().includes(agent)) return
      const dispose = agent.ctx.effect(
        () => registerWikiTools(service, agent),
        'dsh-project-wiki: agent tools',
      )
      mounted.set(agent, dispose)
    }
    for (const agent of ctx.agents.roots()) mount(agent)
    const stopCreated = ctx.on('agent/created', ({ agent }: any) => { mount(agent) })
    const stopDisposed = ctx.on('agent/disposed', ({ agent }: any) => { mounted.delete(agent) })
    const stopApproval = ctx.on('tools/pre-execute', async (exec: any, next: () => Promise<any>) => {
      const downstream = await next()
      if (downstream.kind !== 'allow' || !needsHumanApproval(exec, mounted.has(exec.agent))) return downstream
      return { kind: 'ask' as const, reason: humanApprovalReason(exec.name) }
    })
    const removeRpc = registerWikiRpc(ctx, service)

    return async () => {
      alive = false
      for (const stop of [stopCreated, stopDisposed, stopApproval]) {
        try { stop() } catch (error) {
          ctx.logger.warn(`dsh-project-wiki: lifecycle cleanup failed: ${String(error)}`)
        }
      }
      const results = await Promise.allSettled([
        removeRpc(),
        ...[...mounted.values()].reverse().map(dispose => Promise.resolve().then(dispose)),
      ])
      for (const result of results) {
        if (result.status === 'rejected') {
          ctx.logger.warn(`dsh-project-wiki: contribution cleanup failed: ${String(result.reason)}`)
        }
      }
      mounted.clear()
    }
  }, 'dsh-project-wiki: host service')
}
