import { SessionId } from '@deepseek-ai/dsh-session'
import type {
  WikiActor,
  WikiPage,
  WikiPageInput,
  WikiProposal,
  WikiSearchHit,
  WikiStaleResult,
  WikiWorkspaceScope,
} from './types.ts'
import { WikiStore } from './wiki-store.ts'

interface ServiceContext {
  readonly agents: {
    get(id: string): {
      readonly session: { readonly header: { readonly cwd?: string } }
    } | undefined
  }
  readonly workspaceRegistry: {
    resolveByPath(cwd: string): Promise<{
      readonly id: unknown
      readonly title: string
      readonly path: string
    } | undefined>
  }
}

export interface WikiScope {
  readonly sessionId: string
  readonly actorKind: 'agent' | 'web'
}

export interface WikiServiceOptions {
  readonly directory: string
  readonly maxPages: number
}

export interface WikiPageSummary {
  readonly id: string
  readonly revision: number
  readonly slug: string
  readonly title: string
  readonly summary: string
  readonly tags: readonly string[]
  readonly links: readonly string[]
  readonly sourceCount: number
  readonly staleSources: readonly string[]
  readonly status: 'current' | 'stale'
  readonly updatedAt: string
  readonly updatedBy: WikiActor
}

export interface WikiSnapshot {
  readonly scope: {
    readonly workspaceId: string
    readonly workspaceName: string
    readonly cwd: string
    readonly wikiDirectory: string
  }
  readonly pages: readonly WikiPageSummary[]
  readonly proposals: readonly WikiProposal[]
  readonly generatedAt: string
}

function throwIfCancelled(signal?: AbortSignal): void {
  if (signal?.aborted === true) throw new Error('The wiki request was cancelled.')
}

function actorOf(scope: WikiScope): WikiActor {
  return { kind: scope.actorKind, sessionId: scope.sessionId }
}

function summaryOf(page: WikiPage): WikiPageSummary {
  return {
    id: page.id,
    revision: page.revision,
    slug: page.slug,
    title: page.title,
    summary: page.summary,
    tags: page.tags,
    links: page.links,
    sourceCount: page.sources.length,
    staleSources: page.staleSources,
    status: page.status,
    updatedAt: page.updatedAt,
    updatedBy: page.updatedBy,
  }
}

/** Workspace authority shared by the Web RPC and root-Agent tools. */
export class WikiService {
  private readonly stores = new Map<string, WikiStore>()

  constructor(
    private readonly ctx: ServiceContext,
    private readonly options: WikiServiceOptions,
  ) {}

  async snapshot(scope: WikiScope, signal?: AbortSignal): Promise<WikiSnapshot> {
    const resolved = await this.resolve(scope, signal)
    const [pages, proposals, stale] = await Promise.all([
      resolved.store.listPages(),
      resolved.store.listProposals(),
      resolved.store.scanStale(false),
    ])
    throwIfCancelled(signal)
    const staleById = new Map(stale.map(item => [item.pageId, item]))
    return {
      scope: {
        workspaceId: resolved.scope.workspaceId,
        workspaceName: resolved.scope.workspaceName,
        cwd: resolved.scope.workspacePath,
        wikiDirectory: resolved.store.root,
      },
      pages: pages.map((page) => {
        const state = staleById.get(page.id)
        return summaryOf(state === undefined ? page : {
          ...page,
          status: state.status,
          staleSources: state.staleSources,
        })
      }),
      proposals,
      generatedAt: new Date().toISOString(),
    }
  }

  async read(scope: WikiScope, id: string, signal?: AbortSignal): Promise<WikiPage> {
    const resolved = await this.resolve(scope, signal)
    const [page, stale] = await Promise.all([
      resolved.store.readPage(id),
      resolved.store.scanStale(false),
    ])
    throwIfCancelled(signal)
    const state = stale.find(item => item.pageId === page.id)
    return state === undefined ? page : { ...page, status: state.status, staleSources: state.staleSources }
  }

  async search(scope: WikiScope, query: string, limit: number, signal?: AbortSignal): Promise<WikiSearchHit[]> {
    const resolved = await this.resolve(scope, signal)
    const hits = await resolved.store.search(query, limit)
    throwIfCancelled(signal)
    return hits
  }

  async save(scope: WikiScope, input: WikiPageInput, signal?: AbortSignal): Promise<WikiPage> {
    const resolved = await this.resolve(scope, signal)
    const page = await resolved.store.savePage(input, actorOf(scope))
    throwIfCancelled(signal)
    return page
  }

  async delete(scope: WikiScope, id: string, signal?: AbortSignal): Promise<void> {
    const resolved = await this.resolve(scope, signal)
    await resolved.store.deletePage(id)
    throwIfCancelled(signal)
  }

  async propose(scope: WikiScope, input: Omit<WikiPageInput, 'id'>, signal?: AbortSignal): Promise<WikiProposal> {
    const resolved = await this.resolve(scope, signal)
    const proposal = await resolved.store.createProposal(input, actorOf(scope))
    throwIfCancelled(signal)
    return proposal
  }

  async applyProposal(scope: WikiScope, id: string, signal?: AbortSignal): Promise<WikiPage> {
    const resolved = await this.resolve(scope, signal)
    const page = await resolved.store.applyProposal(id, actorOf(scope))
    throwIfCancelled(signal)
    return page
  }

  async rejectProposal(scope: WikiScope, id: string, signal?: AbortSignal): Promise<void> {
    const resolved = await this.resolve(scope, signal)
    await resolved.store.rejectProposal(id)
    throwIfCancelled(signal)
  }

  async backlinks(scope: WikiScope, id: string, signal?: AbortSignal): Promise<WikiPageSummary[]> {
    const resolved = await this.resolve(scope, signal)
    const pages = await resolved.store.backlinks(id)
    throwIfCancelled(signal)
    return pages.map(summaryOf)
  }

  async scanStale(scope: WikiScope, persist: boolean, signal?: AbortSignal): Promise<WikiStaleResult[]> {
    const resolved = await this.resolve(scope, signal)
    const result = await resolved.store.scanStale(persist)
    throwIfCancelled(signal)
    return result
  }

  private async resolve(scope: WikiScope, signal?: AbortSignal): Promise<{
    readonly scope: WikiWorkspaceScope
    readonly store: WikiStore
  }> {
    throwIfCancelled(signal)
    const agent = this.ctx.agents.get(SessionId(scope.sessionId))
    if (agent === undefined) throw new Error('The wiki UI/tool requires a live source session.')
    const cwd = agent.session.header.cwd
    if (cwd === undefined) throw new Error('The source session has no workspace directory.')
    const workspace = await this.ctx.workspaceRegistry.resolveByPath(cwd)
    if (workspace === undefined) throw new Error('The source session directory is not registered as a DSH workspace.')
    if (this.ctx.agents.get(SessionId(scope.sessionId)) !== agent) {
      throw new Error('The wiki UI/tool requires a live source session.')
    }
    const workspacePath = workspace.path
    let store = this.stores.get(workspacePath)
    if (store === undefined) {
      store = new WikiStore(workspacePath, this.options)
      this.stores.set(workspacePath, store)
    }
    return {
      scope: {
        sessionId: scope.sessionId,
        workspaceId: String(workspace.id),
        workspaceName: workspace.title,
        workspacePath,
        actorKind: scope.actorKind,
      },
      store,
    }
  }
}
