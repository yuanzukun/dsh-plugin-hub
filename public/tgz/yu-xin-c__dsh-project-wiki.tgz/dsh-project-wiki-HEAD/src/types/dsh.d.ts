declare module '@deepseek-ai/cordis' {
  export interface Context {
    readonly agents: any
    readonly workspaceRegistry: any
    readonly tools: any
    readonly connection: any
    readonly logger: { warn(message: string): void }
    effect<T>(factory: () => T | Promise<T>, label?: string): T
    on(name: string, listener: (...args: any[]) => any): () => void
  }
}

declare module '@deepseek-ai/schemastery' {
  const z: any
  export default z
}

declare module '@deepseek-ai/dsh-client-connection' {}

declare module '@deepseek-ai/dsh-session' {
  export type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue }
  export type SessionId = string & { readonly __sessionId: unique symbol }
  export function SessionId(value: string): SessionId
}

declare module '@deepseek-ai/dsh-tools' {
  import type { JsonValue } from '@deepseek-ai/dsh-session'
  export type { JsonValue } from '@deepseek-ai/dsh-session'
  export interface ToolRunContext {
    readonly signal: AbortSignal
    readonly agent?: unknown
  }
  export function defineTool(definition: any): any
}
