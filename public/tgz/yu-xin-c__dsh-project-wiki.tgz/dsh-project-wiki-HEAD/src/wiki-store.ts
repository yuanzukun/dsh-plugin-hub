import { createHash, randomUUID } from 'node:crypto'
import { DatabaseSync } from 'node:sqlite'
import { mkdir, readFile, readdir, realpath, rename, rm, stat, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { parse, stringify } from 'yaml'
import type {
  WikiActor,
  WikiPage,
  WikiPageInput,
  WikiProposal,
  WikiSearchHit,
  WikiSource,
  WikiStaleResult,
} from './types.ts'

interface WikiStoreOptions {
  readonly directory?: string
  readonly maxPages?: number
}

interface PageFrontmatter {
  readonly id: string
  readonly revision: number
  readonly slug: string
  readonly title: string
  readonly summary: string
  readonly tags: readonly string[]
  readonly sources: readonly WikiSource[]
  readonly staleSources: readonly string[]
  readonly status: 'current' | 'stale'
  readonly createdAt: string
  readonly updatedAt: string
  readonly createdBy: WikiActor
  readonly updatedBy: WikiActor
}

const FRONTMATTER = /^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n)?([\s\S]*)$/
const MAX_SOURCE_BYTES = 20 * 1024 * 1024

function asRecord(value: unknown, label: string): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error(`${label} must be an object`)
  }
  return value as Record<string, unknown>
}

function requiredString(value: unknown, label: string): string {
  if (typeof value !== 'string' || value.trim() === '') throw new Error(`${label} must be a non-empty string`)
  return value
}

function stringArray(value: unknown, label: string): string[] {
  if (!Array.isArray(value) || value.some(item => typeof item !== 'string')) {
    throw new Error(`${label} must be a string array`)
  }
  return value.map(String)
}

function actor(value: unknown, label: string): WikiActor {
  const record = asRecord(value, label)
  const kind = requiredString(record.kind, `${label}.kind`)
  if (kind !== 'agent' && kind !== 'web') throw new Error(`${label}.kind must be agent or web`)
  return { kind, sessionId: requiredString(record.sessionId, `${label}.sessionId`) }
}

function sources(value: unknown): WikiSource[] {
  if (!Array.isArray(value)) throw new Error('sources must be an array')
  return value.map((item, index) => {
    const record = asRecord(item, `sources[${index}]`)
    return {
      path: requiredString(record.path, `sources[${index}].path`),
      sha256: requiredString(record.sha256, `sources[${index}].sha256`),
    }
  })
}

function normalizeTags(tags: readonly string[] | undefined): string[] {
  const values = (tags ?? [])
    .map(tag => tag.trim().toLowerCase())
    .filter(Boolean)
    .map(tag => tag.slice(0, 40))
  return [...new Set(values)].slice(0, 12)
}

function slugify(title: string): string {
  const slug = title
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[^\p{Letter}\p{Number}]+/gu, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80)
  return slug || `page-${randomUUID().slice(0, 8)}`
}

function extractLinks(body: string): string[] {
  const links = [...body.matchAll(/\[\[([^\]]+)\]\]/g)]
    .map(match => match[1]?.trim().toLowerCase() ?? '')
    .filter(Boolean)
  return [...new Set(links)]
}

function deriveSummary(body: string): string {
  return body
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/[#>*_`\[\]()!-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 220)
}

function isInside(parent: string, child: string): boolean {
  const relative = path.relative(parent, child)
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative))
}

async function nearestExistingRealPath(candidate: string): Promise<string> {
  let current = candidate
  for (;;) {
    try {
      return await realpath(current)
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error
      const parent = path.dirname(current)
      if (parent === current) throw error
      current = parent
    }
  }
}

function serializePage(page: WikiPage): string {
  const metadata: PageFrontmatter = {
    id: page.id,
    revision: page.revision,
    slug: page.slug,
    title: page.title,
    summary: page.summary,
    tags: page.tags,
    sources: page.sources,
    staleSources: page.staleSources,
    status: page.status,
    createdAt: page.createdAt,
    updatedAt: page.updatedAt,
    createdBy: page.createdBy,
    updatedBy: page.updatedBy,
  }
  return `---\n${stringify(metadata, { lineWidth: 0, aliasDuplicateObjects: false }).trimEnd()}\n---\n\n${page.body.trim()}\n`
}

function parsePage(source: string, filename: string): WikiPage {
  const match = FRONTMATTER.exec(source)
  if (match === null) throw new Error(`Wiki page ${filename} has invalid frontmatter`)
  const raw = asRecord(parse(match[1] ?? ''), `${filename} frontmatter`)
  const status = requiredString(raw.status, `${filename}.status`)
  if (status !== 'current' && status !== 'stale') throw new Error(`${filename}.status must be current or stale`)
  const revision = Number(raw.revision)
  if (!Number.isSafeInteger(revision) || revision < 1) throw new Error(`${filename}.revision must be a positive integer`)
  const body = (match[2] ?? '').trim()
  return {
    id: requiredString(raw.id, `${filename}.id`),
    revision,
    slug: requiredString(raw.slug, `${filename}.slug`),
    title: requiredString(raw.title, `${filename}.title`),
    summary: typeof raw.summary === 'string' ? raw.summary : '',
    tags: stringArray(raw.tags ?? [], `${filename}.tags`),
    body,
    links: extractLinks(body),
    sources: sources(raw.sources ?? []),
    staleSources: stringArray(raw.staleSources ?? [], `${filename}.staleSources`),
    status,
    createdAt: requiredString(raw.createdAt, `${filename}.createdAt`),
    updatedAt: requiredString(raw.updatedAt, `${filename}.updatedAt`),
    createdBy: actor(raw.createdBy, `${filename}.createdBy`),
    updatedBy: actor(raw.updatedBy, `${filename}.updatedBy`),
  }
}

function proposalFromJson(value: unknown, filename: string): WikiProposal {
  const raw = asRecord(value, filename)
  return {
    id: requiredString(raw.id, `${filename}.id`),
    title: requiredString(raw.title, `${filename}.title`),
    summary: typeof raw.summary === 'string' ? raw.summary : '',
    tags: stringArray(raw.tags ?? [], `${filename}.tags`),
    body: requiredString(raw.body, `${filename}.body`),
    sourcePaths: stringArray(raw.sourcePaths ?? [], `${filename}.sourcePaths`),
    createdAt: requiredString(raw.createdAt, `${filename}.createdAt`),
    createdBy: actor(raw.createdBy, `${filename}.createdBy`),
  }
}

function ftsQuery(query: string): string {
  return query
    .normalize('NFKC')
    .match(/[\p{Letter}\p{Number}_-]+/gu)
    ?.map(token => `"${token.replaceAll('"', '""')}"`)
    .join(' AND ') ?? ''
}

function lexicalHits(pages: readonly WikiPage[], query: string, limit: number): WikiSearchHit[] {
  const terms = query.toLowerCase().split(/\s+/).filter(Boolean)
  return pages
    .map((page) => {
      const haystack = `${page.title} ${page.summary} ${page.tags.join(' ')} ${page.body}`.toLowerCase()
      const score = terms.reduce((total, term) => total + (haystack.includes(term) ? 1 : 0), 0)
      return { page, score }
    })
    .filter(item => terms.length === 0 || item.score > 0)
    .sort((left, right) => right.score - left.score || right.page.updatedAt.localeCompare(left.page.updatedAt))
    .slice(0, limit)
    .map(({ page }) => ({
      id: page.id,
      slug: page.slug,
      title: page.title,
      summary: page.summary,
      tags: page.tags,
      status: page.status,
      updatedAt: page.updatedAt,
      snippet: page.summary || deriveSummary(page.body),
    }))
}

export class WikiStore {
  readonly workspacePath: string
  readonly root: string
  readonly pagesDirectory: string
  readonly proposalsDirectory: string
  readonly indexPath: string
  readonly maxPages: number

  constructor(workspacePath: string, options: WikiStoreOptions = {}) {
    this.workspacePath = path.resolve(workspacePath)
    const directory = options.directory ?? '.dsh/wiki'
    if (path.isAbsolute(directory)) throw new Error('Wiki directory must be relative to the workspace')
    this.root = path.resolve(this.workspacePath, directory)
    if (!isInside(this.workspacePath, this.root)) throw new Error('Wiki directory must stay inside the workspace')
    this.pagesDirectory = path.join(this.root, 'pages')
    this.proposalsDirectory = path.join(this.root, 'proposals')
    this.indexPath = path.join(this.root, '.index.sqlite')
    this.maxPages = Math.max(1, Math.min(options.maxPages ?? 1000, 10_000))
  }

  async ensureLayout(): Promise<void> {
    const workspaceRealPath = await realpath(this.workspacePath)
    const ancestorRealPath = await nearestExistingRealPath(this.root)
    if (!isInside(workspaceRealPath, ancestorRealPath)) {
      throw new Error('Wiki directory leaves the workspace through a symbolic link')
    }
    await mkdir(this.root, { recursive: true })
    const wikiRealPath = await realpath(this.root)
    if (!isInside(workspaceRealPath, wikiRealPath)) {
      throw new Error('Wiki directory leaves the workspace through a symbolic link')
    }
    await Promise.all([
      mkdir(this.pagesDirectory, { recursive: true }),
      mkdir(this.proposalsDirectory, { recursive: true }),
    ])
  }

  async listPages(): Promise<WikiPage[]> {
    await this.ensureLayout()
    const names = (await readdir(this.pagesDirectory)).filter(name => name.endsWith('.md')).sort()
    const pages = await Promise.all(names.map(async name => parsePage(
      await readFile(path.join(this.pagesDirectory, name), 'utf8'),
      name,
    )))
    return pages.sort((left, right) => right.updatedAt.localeCompare(left.updatedAt))
  }

  async readPage(idOrSlug: string): Promise<WikiPage> {
    const page = (await this.listPages()).find(item => item.id === idOrSlug || item.slug === idOrSlug)
    if (page === undefined) throw new Error(`Unknown wiki page '${idOrSlug}'`)
    return page
  }

  async savePage(input: WikiPageInput, actorValue: WikiActor): Promise<WikiPage> {
    const title = input.title.trim().slice(0, 160)
    const body = input.body.trim()
    if (title === '') throw new Error('title must be a non-empty string')
    if (body === '') throw new Error('body must be a non-empty string')
    const pages = await this.listPages()
    const existing = input.id === undefined ? undefined : pages.find(page => page.id === input.id)
    if (input.id !== undefined && existing === undefined) throw new Error(`Unknown wiki page '${input.id}'`)
    if (existing === undefined && pages.length >= this.maxPages) throw new Error(`Wiki page limit (${this.maxPages}) reached`)

    const requestedSlug = existing?.slug ?? slugify(title)
    let slug = requestedSlug
    for (let suffix = 2; pages.some(page => page.slug === slug && page.id !== existing?.id); suffix += 1) {
      slug = `${requestedSlug.slice(0, 72)}-${suffix}`
    }
    const sourcePaths = input.sourcePaths === undefined
      ? existing?.sources.map(source => source.path) ?? []
      : input.sourcePaths
    const pageSources = await this.fingerprintSources(sourcePaths)
    const now = new Date().toISOString()
    const page: WikiPage = {
      id: existing?.id ?? `wiki_${randomUUID()}`,
      revision: (existing?.revision ?? 0) + 1,
      slug,
      title,
      summary: (input.summary?.trim() || deriveSummary(body)).slice(0, 300),
      tags: normalizeTags(input.tags),
      body,
      links: extractLinks(body),
      sources: pageSources,
      staleSources: [],
      status: 'current',
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
      createdBy: existing?.createdBy ?? actorValue,
      updatedBy: actorValue,
    }
    const nextPath = path.join(this.pagesDirectory, `${page.slug}.md`)
    await this.atomicWrite(nextPath, serializePage(page))
    if (existing !== undefined && existing.slug !== page.slug) {
      await rm(path.join(this.pagesDirectory, `${existing.slug}.md`), { force: true })
    }
    await this.rebuildIndex(await this.listPages())
    return page
  }

  async deletePage(id: string): Promise<void> {
    const page = await this.readPage(id)
    await rm(path.join(this.pagesDirectory, `${page.slug}.md`))
    await this.rebuildIndex(await this.listPages())
  }

  async search(query: string, limit = 20): Promise<WikiSearchHit[]> {
    const pages = await this.listPages()
    const boundedLimit = Math.max(1, Math.min(limit, 100))
    if (query.trim() === '') return lexicalHits(pages, '', boundedLimit)
    const match = ftsQuery(query)
    if (match === '') return []
    try {
      await this.rebuildIndex(pages)
      const db = new DatabaseSync(this.indexPath)
      try {
        const rows = db.prepare(`
          SELECT id, snippet(wiki_fts, 5, '', '', ' ... ', 22) AS snippet
          FROM wiki_fts
          WHERE wiki_fts MATCH ?
          ORDER BY bm25(wiki_fts, 0, 0, 10, 6, 3, 1)
          LIMIT ?
        `).all(match, boundedLimit) as Array<{ id: string; snippet: string }>
        const byId = new Map(pages.map(page => [page.id, page]))
        return rows.flatMap((row) => {
          const page = byId.get(row.id)
          return page === undefined ? [] : [{
            id: page.id,
            slug: page.slug,
            title: page.title,
            summary: page.summary,
            tags: page.tags,
            status: page.status,
            updatedAt: page.updatedAt,
            snippet: row.snippet || page.summary,
          }]
        })
      } finally {
        db.close()
      }
    } catch {
      return lexicalHits(pages, query, boundedLimit)
    }
  }

  async listProposals(): Promise<WikiProposal[]> {
    await this.ensureLayout()
    const names = (await readdir(this.proposalsDirectory)).filter(name => name.endsWith('.json')).sort()
    const proposals = await Promise.all(names.map(async name => proposalFromJson(
      JSON.parse(await readFile(path.join(this.proposalsDirectory, name), 'utf8')) as unknown,
      name,
    )))
    return proposals.sort((left, right) => right.createdAt.localeCompare(left.createdAt))
  }

  async createProposal(input: Omit<WikiPageInput, 'id'>, actorValue: WikiActor): Promise<WikiProposal> {
    const title = input.title.trim().slice(0, 160)
    const body = input.body.trim()
    if (title === '') throw new Error('title must be a non-empty string')
    if (body === '') throw new Error('body must be a non-empty string')
    const sourcePaths = await this.validateSourcePaths(input.sourcePaths ?? [])
    const proposal: WikiProposal = {
      id: `proposal_${randomUUID()}`,
      title,
      summary: (input.summary?.trim() || deriveSummary(body)).slice(0, 300),
      tags: normalizeTags(input.tags),
      body,
      sourcePaths,
      createdAt: new Date().toISOString(),
      createdBy: actorValue,
    }
    await this.ensureLayout()
    await this.atomicWrite(
      path.join(this.proposalsDirectory, `${proposal.id}.json`),
      `${JSON.stringify(proposal, null, 2)}\n`,
    )
    return proposal
  }

  async applyProposal(id: string, actorValue: WikiActor): Promise<WikiPage> {
    const proposal = (await this.listProposals()).find(item => item.id === id)
    if (proposal === undefined) throw new Error(`Unknown wiki proposal '${id}'`)
    const page = await this.savePage({
      title: proposal.title,
      summary: proposal.summary,
      tags: proposal.tags,
      body: proposal.body,
      sourcePaths: proposal.sourcePaths,
    }, actorValue)
    await this.rejectProposal(id)
    return page
  }

  async rejectProposal(id: string): Promise<void> {
    const proposal = (await this.listProposals()).find(item => item.id === id)
    if (proposal === undefined) throw new Error(`Unknown wiki proposal '${id}'`)
    await rm(path.join(this.proposalsDirectory, `${proposal.id}.json`))
  }

  async backlinks(idOrSlug: string): Promise<WikiPage[]> {
    const target = await this.readPage(idOrSlug)
    const aliases = new Set([target.slug.toLowerCase(), target.title.toLowerCase()])
    return (await this.listPages()).filter(page => page.id !== target.id && page.links.some(link => aliases.has(link)))
  }

  async scanStale(persist = false): Promise<WikiStaleResult[]> {
    const pages = await this.listPages()
    const results: WikiStaleResult[] = []
    for (const page of pages) {
      const staleSources: string[] = []
      for (const source of page.sources) {
        try {
          const [validated] = await this.validateSourcePaths([source.path])
          if (validated === undefined) throw new Error('Source path is empty')
          const current = await this.hashFile(path.join(this.workspacePath, validated))
          if (current !== source.sha256) staleSources.push(source.path)
        } catch {
          staleSources.push(source.path)
        }
      }
      const status = staleSources.length === 0 ? 'current' : 'stale'
      results.push({ pageId: page.id, title: page.title, status, staleSources })
      if (persist && (status !== page.status || staleSources.join('\0') !== page.staleSources.join('\0'))) {
        const updated: WikiPage = { ...page, status, staleSources }
        await this.atomicWrite(path.join(this.pagesDirectory, `${page.slug}.md`), serializePage(updated))
      }
    }
    if (persist) await this.rebuildIndex(await this.listPages())
    return results
  }

  private async validateSourcePaths(paths: readonly string[]): Promise<string[]> {
    await this.ensureLayout()
    const [workspaceRealPath, wikiRealPath] = await Promise.all([
      realpath(this.workspacePath),
      realpath(this.root),
    ])
    const normalized: string[] = []
    for (const sourcePath of paths) {
      const value = sourcePath.trim()
      if (value === '') continue
      if (path.isAbsolute(value)) throw new Error(`Source path '${value}' must be workspace-relative`)
      const absolute = path.resolve(this.workspacePath, value)
      if (!isInside(this.workspacePath, absolute)) throw new Error(`Source path '${value}' leaves the workspace`)
      if (isInside(this.root, absolute)) throw new Error(`Source path '${value}' cannot point into the wiki directory`)
      const targetRealPath = await realpath(absolute)
      if (!isInside(workspaceRealPath, targetRealPath)) {
        throw new Error(`Source path '${value}' leaves the workspace through a symbolic link`)
      }
      if (isInside(wikiRealPath, targetRealPath)) {
        throw new Error(`Source path '${value}' cannot point into the wiki directory`)
      }
      const metadata = await stat(absolute)
      if (!metadata.isFile()) throw new Error(`Source path '${value}' must point to a file`)
      if (metadata.size > MAX_SOURCE_BYTES) throw new Error(`Source path '${value}' exceeds 20 MiB`)
      normalized.push(path.relative(this.workspacePath, absolute).split(path.sep).join('/'))
    }
    return [...new Set(normalized)].slice(0, 40)
  }

  private async fingerprintSources(paths: readonly string[]): Promise<WikiSource[]> {
    const normalized = await this.validateSourcePaths(paths)
    return Promise.all(normalized.map(async sourcePath => ({
      path: sourcePath,
      sha256: await this.hashFile(path.join(this.workspacePath, sourcePath)),
    })))
  }

  private async hashFile(filename: string): Promise<string> {
    return createHash('sha256').update(await readFile(filename)).digest('hex')
  }

  private async atomicWrite(filename: string, contents: string): Promise<void> {
    await mkdir(path.dirname(filename), { recursive: true })
    const temporary = `${filename}.${process.pid}.${randomUUID()}.tmp`
    await writeFile(temporary, contents, { encoding: 'utf8', mode: 0o600 })
    await rename(temporary, filename)
  }

  private async rebuildIndex(pages: readonly WikiPage[]): Promise<void> {
    await this.ensureLayout()
    const db = new DatabaseSync(this.indexPath)
    try {
      db.exec(`
        CREATE VIRTUAL TABLE IF NOT EXISTS wiki_fts USING fts5(
          id UNINDEXED,
          slug UNINDEXED,
          title,
          summary,
          tags,
          body,
          tokenize = 'unicode61'
        );
        DELETE FROM wiki_fts;
      `)
      const insert = db.prepare('INSERT INTO wiki_fts (id, slug, title, summary, tags, body) VALUES (?, ?, ?, ?, ?, ?)')
      for (const page of pages) {
        insert.run(page.id, page.slug, page.title, page.summary, page.tags.join(' '), page.body)
      }
    } finally {
      db.close()
    }
  }
}

export const wikiInternals = { deriveSummary, extractLinks, parsePage, serializePage, slugify }
