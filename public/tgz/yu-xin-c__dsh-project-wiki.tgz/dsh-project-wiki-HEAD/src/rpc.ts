import type { WikiService } from './service.ts'
import type { WikiPageInput } from './types.ts'

interface RpcContext {
  readonly connection: {
    readonly rpc: {
      handle(
        channel: string,
        handler: (endpoint: string, payload: unknown, signal: AbortSignal) => Promise<unknown>,
        options: { readonly authority: 'loopback' | 'trusted-host' },
      ): () => Promise<void>
    }
  }
}

function record(value: unknown, label: string): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error(`${label} must be an object`)
  }
  return value as Record<string, unknown>
}

function string(value: unknown, label: string): string {
  if (typeof value !== 'string' || value.trim() === '') throw new Error(`${label} must be a non-empty string`)
  return value
}

function optionalString(value: unknown, label: string): string | undefined {
  if (value === undefined) return undefined
  if (typeof value !== 'string') throw new Error(`${label} must be a string`)
  return value
}

function strings(value: unknown, label: string): string[] | undefined {
  if (value === undefined) return undefined
  if (!Array.isArray(value) || value.some(item => typeof item !== 'string')) {
    throw new Error(`${label} must be a string array`)
  }
  return value.map(String)
}

function number(value: unknown, label: string, fallback: number): number {
  if (value === undefined) return fallback
  if (typeof value !== 'number' || !Number.isSafeInteger(value)) throw new Error(`${label} must be an integer`)
  return value
}

function scope(payload: Record<string, unknown>) {
  return { sessionId: string(payload.sessionId, 'sessionId'), actorKind: 'web' as const }
}

function pageInput(value: unknown): WikiPageInput {
  const raw = record(value, 'input')
  return {
    ...(raw.id === undefined ? {} : { id: string(raw.id, 'input.id') }),
    title: string(raw.title, 'input.title'),
    ...(raw.summary === undefined ? {} : { summary: optionalString(raw.summary, 'input.summary') ?? '' }),
    ...(raw.tags === undefined ? {} : { tags: strings(raw.tags, 'input.tags') ?? [] }),
    body: string(raw.body, 'input.body'),
    ...(raw.sourcePaths === undefined ? {} : { sourcePaths: strings(raw.sourcePaths, 'input.sourcePaths') ?? [] }),
  }
}

function errorResult(error: unknown, aborted: boolean) {
  const message = aborted ? 'The wiki request was cancelled.' : error instanceof Error ? error.message : String(error)
  const badRequest = /must|required|Unknown wiki|workspace|source|page limit|cancelled/.test(message)
  return {
    ok: false as const,
    error: {
      code: badRequest ? 'bad-request' : 'internal',
      message,
      details: badRequest ? { issues: [] } : {},
    },
  }
}

/** Loopback-only Web API. Every request is rebound to its live Session workspace. */
export function registerWikiRpc(ctx: RpcContext, service: WikiService): () => Promise<void> {
  return ctx.connection.rpc.handle('/dsh-project-wiki', async (endpoint, rawPayload, signal) => {
    try {
      if (signal.aborted) throw new Error('The wiki request was cancelled.')
      const payload = record(rawPayload, 'payload')
      switch (endpoint) {
        case 'snapshot':
          return { ok: true, value: await service.snapshot(scope(payload), signal) }
        case 'read':
          return { ok: true, value: await service.read(scope(payload), string(payload.pageId, 'pageId'), signal) }
        case 'search':
          return {
            ok: true,
            value: await service.search(
              scope(payload),
              typeof payload.query === 'string' ? payload.query : '',
              number(payload.limit, 'limit', 30),
              signal,
            ),
          }
        case 'save':
          return { ok: true, value: await service.save(scope(payload), pageInput(payload.input), signal) }
        case 'delete':
          await service.delete(scope(payload), string(payload.pageId, 'pageId'), signal)
          return { ok: true, value: { deleted: true } }
        case 'propose': {
          const input = pageInput(payload.input)
          const { id: _ignoredId, ...proposalInput } = input
          return { ok: true, value: await service.propose(scope(payload), proposalInput, signal) }
        }
        case 'apply-proposal':
          return { ok: true, value: await service.applyProposal(scope(payload), string(payload.proposalId, 'proposalId'), signal) }
        case 'reject-proposal':
          await service.rejectProposal(scope(payload), string(payload.proposalId, 'proposalId'), signal)
          return { ok: true, value: { rejected: true } }
        case 'backlinks':
          return { ok: true, value: await service.backlinks(scope(payload), string(payload.pageId, 'pageId'), signal) }
        case 'scan-stale':
          return { ok: true, value: await service.scanStale(scope(payload), true, signal) }
        default:
          throw new Error(`Unknown wiki endpoint '${endpoint}'`)
      }
    } catch (error) {
      return errorResult(error, signal.aborted)
    }
  }, { authority: 'loopback' })
}
