# Third-Party Notices

- DSH agent-preset base compositions are derived from
  <https://github.com/deepseek-ai/deepseek-harness> (MIT), commit
  `47f943859bef60e4160492346772ded9b24f765a`.
- `js-yaml` 4.x (<https://github.com/nodeca/js-yaml>, MIT) is used by the plugin-side composition validator/editor; generated preset runtime engines do not import it.
- The anchoring approach is informed by:
  - <https://github.com/xiaobright/dsh-anchored-standard> (MIT)
  - <https://github.com/yjh051108/dsh-routing-suite> (MIT, preset submodule
    `dsh-router-standard`)

`mv-superds` itself is an independent implementation, except
`custom-bash.mjs`, which is adapted from `dsh-anchored-standard`
(MIT) for Windows Git Bash support.
