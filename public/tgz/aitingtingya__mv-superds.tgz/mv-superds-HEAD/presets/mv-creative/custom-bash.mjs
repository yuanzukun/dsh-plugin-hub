/**
 * custom-bash — a Windows-capable `bash` tool that registers under the SAME
 * name (`bash`) as the official persistent bash, with a Minimal-compatible
 * description, but executes through `ctx.subprocess.spawn` instead of a PTY.
 *
 * WHY: DeepSeek's first-request trajectory anchor keys on the tool SCHEMA
 * matching the RL training distribution (issue #11: persistent
 * bash + str_replace_editor anchored 5/5 at maxTokens=256000, pwsh/read
 * 8/8 standard-like). The official persistent bash uses a PTY, and DSH's PTY
 * backend is linux/darwin-only — `subprocess-local` throws "terminal
 * inspection is unsupported on platform win32". A custom tool that presents
 * the same name and a Minimal-like description but spawns Git Bash through
 * the ordinary (cross-platform) subprocess seam keeps the schema anchor
 * without the PTY dependency.
 *
 * Executable resolution is deliberately not a fixed path. Candidates are
 * collected in this order:
 *   1. `MV_SUPERDS_GIT_BASH` (primary; a bash executable, a Git root, or its
 *      `bin` directory)
 *   2. `GIT_BASH_PATH` (compatibility alias)
 *   3. the row's `config.bashPath` (string or array of strings)
 *   4. platform defaults (Windows: common Git for Windows install roots,
 *      then `bash` on PATH; other platforms: `bash` on PATH)
 * Directory values are expanded to `bin/bash.exe`, `bin/bash`, `bash.exe`,
 * and `bash` under that root. A missing explicit path is skipped so a later
 * candidate can still win; when nothing resolves, the tool fails with every
 * candidate it tried.
 *
 * Semantics mirror the official bash tool: `bash -c <command>` in a fresh
 * process, bounded output, non-zero exit reported not thrown. No sandbox
 * confinement on Windows (the sandbox backend is linux-only); the tool
 * description says so. The bootstrap catalog pairs this with
 * `str_replace_editor` (Minimal's two tools).
 */
import { existsSync } from 'node:fs'
import { basename, join } from 'node:path'

/** Cordis plugin name used by loader diagnostics. */
export const name = 'custom-bash'

/** The subprocess and tools services must exist before this tool can register. */
export const inject = ['subprocess', 'tools']

export const GIT_BASH_ENV = 'MV_SUPERDS_GIT_BASH'
export const GIT_BASH_ENV_COMPAT = 'GIT_BASH_PATH'

const DEFAULT_TIMEOUT_MS = 120000
const DEFAULT_MAX_OUTPUT_BYTES = 64000

/** Tool parameter schema for the model-facing command. */
const commandSchema = {
  type: 'object',
  properties: {
    command: {
      type: 'string',
      description: 'The bash command to execute (`bash -c` string domain).',
    },
    workdir: {
      type: 'string',
      description: 'Optional working directory; defaults to the session cwd.',
    },
  },
  required: ['command'],
  additionalProperties: false,
}

function isBare(value) {
  return !value.includes('/') && !value.includes('\\')
}

function executableLike(value) {
  const base = basename(value).toLowerCase()
  return base === 'bash' || base === 'bash.exe'
}

/**
 * Expand one configured candidate into concrete executable paths. Bare
 * commands (`bash`) pass through for PATH lookup; a directory is expanded to
 * the common Git for Windows layouts under it.
 */
export function expandBashCandidate(value) {
  if (isBare(value)) return [value]
  if (executableLike(value)) return [value]
  return [
    join(value, 'bin', 'bash.exe'),
    join(value, 'bin', 'bash'),
    join(value, 'bash.exe'),
    join(value, 'bash'),
  ]
}

/** Common Git for Windows install roots, followed by the PATH fallback. */
export function defaultBashCandidates(env = {}, platform = process.platform) {
  const candidates = []
  if (platform === 'win32') {
    for (const root of [env.ProgramFiles, env['ProgramFiles(x86)'], env.LOCALAPPDATA ? join(env.LOCALAPPDATA, 'Programs') : undefined]) {
      if (typeof root !== 'string' || root.length === 0) continue
      candidates.push(join(root, 'Git', 'bin', 'bash.exe'))
    }
  }
  candidates.push('bash')
  return candidates
}

/**
 * The complete candidate list for one registered tool, in priority order:
 * primary env → compatibility env → row config → platform defaults.
 */
export function collectBashCandidates(config, env = {}, platform = process.platform) {
  const rows = []
  const configured = config?.bashPath
  for (const value of [env[GIT_BASH_ENV], env[GIT_BASH_ENV_COMPAT], ...(Array.isArray(configured) ? configured : [configured])]) {
    if (typeof value !== 'string' || value.trim() === '') continue
    rows.push(value.trim())
  }
  const candidates = []
  for (const row of [...rows, ...defaultBashCandidates(env, platform)]) {
    for (const candidate of expandBashCandidate(row)) {
      if (!candidates.includes(candidate)) candidates.push(candidate)
    }
  }
  return candidates
}

/** Pick the first candidate that exists; bare `bash`/`bash.exe` defer to PATH resolution. */
export function pickBashPath(candidates, exists = (candidate) => {
  if (isBare(candidate)) return true
  return existsSync(candidate)
}) {
  for (const candidate of candidates) {
    if (exists(candidate)) return candidate
  }
  return undefined
}

/** Register the model-facing `bash` tool. */
export function apply(ctx, config) {
  const timeoutMs = Number.isSafeInteger(config?.timeoutMs) && config.timeoutMs > 0 ? config.timeoutMs : DEFAULT_TIMEOUT_MS
  const maxOutputBytes = Number.isSafeInteger(config?.maxOutputBytes) && config.maxOutputBytes > 0 ? config.maxOutputBytes : DEFAULT_MAX_OUTPUT_BYTES

  ctx.tools.register({
    name: 'bash',
    description: [
      'Run commands in a bash shell (Git Bash on Windows)',
      '* When invoking this tool, the contents of the "command" parameter does NOT need to be XML-escaped.',
      "* You don't have access to the internet via this tool.",
      '* You do have access to a mirror of common linux and python packages via apt and pip.',
      '* State does NOT persist across command calls: each call runs in a fresh shell.',
      "* To inspect a particular line range of a file, e.g. lines 10-25, try 'sed -n 10,25p /path/to/the/file'.",
      '* Please avoid commands that may produce a very large amount of output.',
      '* NOTE: runs without OS sandbox confinement on Windows (no landlock); treat output as untrusted.',
    ].join('\n'),
    parameters: commandSchema,
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          text: { type: 'string' },
        },
        required: ['text'],
      },
      render: (_args, value) => [{ type: 'text', text: value.text }],
    },
    async execute(args, exec) {
      const candidates = collectBashCandidates(config, process.env, process.platform)
      const bashPath = pickBashPath(candidates)
      if (bashPath === undefined) {
        throw new Error(
          `${name}: no Git Bash executable found — set ${GIT_BASH_ENV} (or ${GIT_BASH_ENV_COMPAT}) to your bash.exe / Git root, install Git for Windows, or add bash to PATH. Tried: ${candidates.join(', ')}`,
        )
      }
      const shell = await ctx.subprocess.resolveExecutable(bashPath, undefined, exec?.signal)
      const workdir = typeof args.workdir === 'string' && args.workdir.length > 0
        ? args.workdir
        : exec?.agent?.session?.header?.cwd
      const signal = exec?.signal
      const handle = ctx.subprocess.spawn({
        argv: [shell, '-c', args.command],
        ...workdir !== undefined ? { cwd: workdir } : {},
        stdio: {
          stdin: 'ignore',
          stdout: { maxBytes: maxOutputBytes },
          stderr: { maxBytes: maxOutputBytes },
        },
        ...signal !== undefined ? { signal } : {},
        graceMs: 3000,
      })
      let outcome
      try {
        outcome = await handle.done
      } catch (error) {
        // A spawn-level failure (bad executable, EPERM) surfaces as a throw,
        // which the runtime turns into an isError result.
        throw new Error(`bash spawn failed: ${String(error)}`)
      }
      let stdout = ''
      let stderr = ''
      try {
        stdout = handle.collected.stdout.readFrom(0).text
        stderr = handle.collected.stderr.readFrom(0).text
      } catch {
        // Collected readers may be unavailable on some backends; tolerate.
      }
      const text = [stdout, stderr].filter((part) => part.length > 0).join('\n')
      const tail = text.length > 0 ? text : `exit code: ${outcome.exitCode} (no output)`
      if (outcome.exitCode !== 0) {
        // Non-zero exit is a reported failure, not a throw: the model sees the
        // command output plus the exit code.
        throw new Error(tail)
      }
      return { text: tail }
    },
  })
}
