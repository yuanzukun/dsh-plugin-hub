# mv-superds

一个刻意保持极简的 DSH prompt-activation / trajectory-anchor 插件。

安装后自动提供：

- `mv-标准模式`
- `mv-PTC模式`
- `mv-创造模式`
- `/mv-superds` 持久化 trajectory-mode 命令

Pro / Flash 各自独立选择 `Weak / Normal / Force`，默认均为 `Normal`。

## Weak / Normal / Force

| Mode | 首轮官方内置工具 | 外挂 / 第三方工具 | 生命周期 |
| --- | --- | --- | --- |
| Weak | `bash + str_replace_editor` | **首轮真实可调用**；schema 只放 transient context | epoch |
| Normal | `bash + str_replace_editor` | 首轮不暴露 | epoch |
| Force | `bash + str_replace_editor` | 首轮不暴露 | DSH turn |

所有模式在首个 durable `tool/call` 后都恢复完整工具目录。

### Weak 的关键语义

Weak 不是“只让模型知道未来有外挂工具”。

Weak 首轮中，外挂 / 第三方工具：

- 真实保留在当前 callable tool schema；
- 模型可以直接调用；
- `name / description / parameters` 以 detached 副本放进 transient user/plugin context；
- 不把这些工具的能力目录、位置或说明塞进 system prompt；
- transient context 不进入 durable transcript / compaction summary；
- 外挂工具自己的 durable `tool/call` 也会触发 promotion。

因此 Weak 的目的就是：**system prompt 保持极干净，同时保留外挂工具首轮可用性。**

## `/mv-superds`

```text
/mv-superds
├─ status
├─ pro
│  ├─ weak
│  ├─ normal
│  └─ force
└─ flash
   ├─ weak
   ├─ normal
   └─ force
```

裸 `/mv-superds` 与 `/mv-superds status` 都查看当前 Pro / Flash 状态；`status` 是显式兜底。命令执行前会等待当前插件的 preset materialization 完成，并在执行时再解析可选 UI feedback，因此刚启动 DSH 立即查询也不会抢在安装之前。

不带 `--preset` 时，mode 修改会作用于当前 `$DSH_HOME/.agent-presets` 下全部带 `.mv-superds-version` 标记的 mv-superds managed presets。`--preset` 是手动输入的高级定向参数，不进入可视 picker：

```text
/mv-superds pro weak --preset mv-standard
/mv-superds status --preset mv-standard
```

preset ID 会在 command/state 两层校验，只允许小写字母、数字和连字符，不能通过路径片段越出 `.agent-presets`。

命令只改目标模型的 `mode:`，不会覆盖已有自定义 guidance。

配置直接持久化到：

```text
$DSH_HOME/.agent-presets/<preset-id>/agent.cordis.yml
```

新会话生效；当前已经挂载的会话继续使用挂载时的配置。

旧 `/mv-superds-force` 不再注册为可见命令。旧 `force:` / `opener:` 配置仍能读取并自动迁移：

```text
enabled=false -> normal
enabled=true  -> force
text          -> guidance
```

## 配置模型

生成预设使用：

```yaml
models:
  default:
    mode: normal
    guidance: >-
      When reasoning about the current task, you MUST begin with "We need ..." or "Let's ...", never "Let me ...". Then think deeply before you produce.
  deepseek-v4-pro:
    mode: normal
    guidance: ""
  deepseek-v4-flash:
    mode: normal
    guidance: ""
```

`guidance: ""` 表示继承 `default.guidance`。持久化层兼容单行 guidance 以及 YAML `>` / `|` block scalar；真正改写该字段时只规范化该字段，不把整份 composition 交给 YAML dumper 重排。

匹配顺序：

```text
provider/model > model > default
```

安装器升级时保留：

- 已选择的 Weak / Normal / Force；
- per-model 自定义 guidance；
- genuinely custom default guidance；
- legacy Force / opener 的用户选择。

## 纯净边界

mv-superds 只负责：

- first-request bootstrap；
- near-field guidance；
- Weak transient external-tool context；
- 首锚工具面；
- epoch / turn activation lifetime；
- durable tool-call promotion。

它不负责 cognition protocol、agent behavior framework、任务路由、工作流编排，也不对任何具体 Skill 或其它插件做特殊兼容逻辑。

`suppressSources` 只是通用 profile-driven filter。

## 安装器配置

插件 row 可选：

```yaml
installPresets: true
presetIds:
  - mv-standard
force: false
```

这里的 `force: true` **只表示安装器强制覆盖无版本标记的手动 preset 目录**，与 trajectory `Force` mode 无关。

## 部署到 DSH

本包通过 `dsh.bundle.patch` 声明自己的 loader row，因此可直接安装到目标 profile：

```bash
# 在仓库根目录构建
npm run build:plugin

# 安装到 web profile（路径换成你的绝对路径）
dsh plugin --profile web add file:/绝对路径/mv-superds-开发/plugin
```

安装后重启 DSH web 进程（或按 DSH 的插件重载方式刷新）。`dsh plugin add` 会自动把 `mv-superds` loader row 合并进 profile，不要同时在 profile 的手工 `cordis.patch.yml` 中重复添加 `mv-superds`，避免 id 冲突。

## Windows

Windows 首锚继续使用 Git Bash fallback，工具名仍为 `bash`。可以通过：

```text
MV_SUPERDS_GIT_BASH
```

指定 Git Bash 路径。

设计上不会拿 PowerShell 冒充首锚 bash。
