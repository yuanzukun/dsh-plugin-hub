/**
 * SessionBridge: routes WeChat messages to DSH sessions and back.
 *
 * Command surface (`/` prefix; anything else goes to the bound session as a
 * prompt):
 *   /help            指令帮助
 *   /sessions        列出会话（编号 + 标题 + 状态）
 *   /use <n|id>      切换当前窗口绑定的会话
 *   /bind            查看当前绑定
 *   /status          当前会话运行状态
 *   /log [n]         最近 n 条 assistant 输出（内存环形缓冲）
 *   /approve /reject 响应待审批请求
 *   /stop            中断当前会话（TODO: 依赖 agent 中断 API，见下）
 *   /new <prompt>    新建会话（TODO: 依赖会话创建 API，见下）
 */
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { randomUUID } from 'node:crypto'
import { existsSync, readFileSync } from 'node:fs'
import { statSync, writeFileSync, mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { basename, resolve, sep } from 'node:path'
import { homedir } from 'node:os'
import { join } from 'node:path'
import type { InboundMessage } from './channel'
import type { AuthStore } from './auth'

/** Structural channel contract: every channel (and the manager) satisfies it. */
export interface BridgeChannel {
  say(windowKey: string, text: string, opts?: { bulk?: boolean }): Promise<void>
  /** Card-capable channel for this window (feishu), or null. */
  cardsFor?(windowKey: string): any | null
}

const LOG_RING_SIZE = 50
/** Max chars /log will emit in one go (≈8 WeChat messages after chunking). */
const LOG_TOTAL_CAP = 12_000
/** /log output longer than this is sent as a .txt file (file-capable channels). */
const LONG_OUTPUT_FILE_THRESHOLD = 4_000

interface SessionEntry {
  id: string
  title: string
  live: boolean
  agent?: any
  /** Workspace folder name, for disambiguating duplicate titles. */
  cwdName?: string
  /** 4-char collision code (only displayed when title+workspace collide). */
  code?: string
}

interface PendingApproval {
  id: string
  req: any
  resolve: (outcome: 'allowed-once' | 'rejected' | undefined) => void
  sessionId: string | undefined
  windows: string[]
  cardData: { approvalId: string; sessionTitle: string; toolName: string; reason: string; timeoutMin: number }
  timer: NodeJS.Timeout
}

export class SessionBridge {
  /** sessionId → recent assistant text snippets (ring buffer). */
  private logRings = new Map<string, string[]>()
  /** Latest turn status per session: running | idle. */
  private turnStatus = new Map<string, string>()
  /** Approvals currently waiting on an IM decision. */
  private pendingApprovals = new Map<string, PendingApproval>() // windowKey → approval
  /** The same approvals keyed by approval id (card-button callbacks carry ids). */
  private pendingById = new Map<string, PendingApproval>()
  /** windowKey → pending danger-full-access confirmation (60s TTL). */
  private pendingPolicy = new Map<string, { mode: string; at: number }>()
  /** sessionId|windowKey → streaming progress card (feishu). */
  private progressCards = new Map<string, { messageId: string; prompt: string; sessionTitle: string }>()
  /** Last active root agent, mirrors dsh-cron's delivery heuristic. */
  private lastActiveRoot: any = null
  /** Last listing shown by /sessions, so /use <编号> maps to the same order. */
  private lastList: Array<SessionEntry> = []

  constructor(
    private ctx: any,
    private config: any,
    private channel: BridgeChannel,
    private auth: AuthStore,
    private logger: { info: (m: string) => void; warn: (m: string) => void },
  ) {}

  /**
   * Human-readable session name: the folded `session/title` event via the
   * sessionTitle service (auto-generated after the first turn), falling back
   * to a direct scan of `session/title` events, then the first user message,
   * and finally the raw id.
   */
  private titleOf(session: any): string {
    try {
      const svc = this.ctx.sessionTitle ?? this.ctx.get?.('sessionTitle')
      const snap = svc?.get?.(session)
      if (snap?.title) return snap.title
    } catch {
      /* service absent or session not live — fall through */
    }
    try {
      let title: string | null = null
      let firstUser: string | null = null
      for (const event of session?.events ?? []) {
        if (event?.type === 'session/title' && event?.data?.title) {
          title = event.data.title // 保留最后一次折叠出的标题
        } else if (!firstUser && event?.type === 'user/message') {
          const text = messageText(event.data?.message ?? event.data)
          if (text) firstUser = text
        }
      }
      if (title) return title
      if (firstUser) return firstUser.slice(0, 30) + (firstUser.length > 30 ? '…' : '')
    } catch {
      /* events not enumerable — fall through */
    }
    return session?.id ?? '未命名会话'
  }

  /** sessionQuery 服务（已在 inject 声明；防御性获取兜底 headless profile）。 */
  private query(): any {
    try {
      return this.ctx.sessionQuery ?? this.ctx.get?.('sessionQuery') ?? null
    } catch {
      return null
    }
  }

  /** 诊断：上一次冷会话读取的状态（无服务/异常/记录数）。 */
  private coldDiag = '未执行'

  /**
   * Seed model options for resume, mirroring the API proxy: sessions that
   * already logged a model selection keep it; this fills the blank that
   * otherwise breaks the persona assembly (prompt variable "{{model}}").
   */
  private seedAgentOptions(): { provider: string; model: string } | undefined {
    try {
      const svc = this.ctx.agentDefaultModel ?? this.ctx.get?.('agentDefaultModel')
      const sel = svc?.currentSelection?.()
      if (sel?.provider && sel?.model) return { provider: sel.provider, model: sel.model }
    } catch {
      /* service absent — resume without options */
    }
    return undefined
  }

  /** GUI 的归档集合（storages/workspace.json），归档会话与 GUI 保持一致地隐藏。 */
  private archivedIds(): Set<string> {
    try {
      const dshHome = process.env.DSH_HOME ?? join(homedir(), '.dsh')
      const raw = JSON.parse(readFileSync(join(dshHome, 'storages', 'workspace.json'), 'utf8'))
      return new Set(raw?.global?.archivedSessionIds ?? [])
    } catch {
      return new Set()
    }
  }

  /**
   * 全量顶层会话：live roots 在前（可交互），其后是持久化里的冷会话。
   * 结果缓存到 lastList，供 /use <编号> 按同一顺序取。
   */
  /**
   * GUI 侧边栏同口径的会话目录：优先走 apiProxy.sessions.list（与 GUI 完全
   * 同源），过滤 origin=subagent / 归档 / 空白会话，排序按工作区注册表。
   * apiProxy 不可用（headless）时回退 live+cold 的 legacy 路径。
   */
  private async allSessions(includeChildren = false): Promise<Array<SessionEntry>> {
    const api = this.apiProxy()
    if (api?.sessions?.list) {
      try {
        return await this.allSessionsViaApi(api, includeChildren)
      } catch (error: any) {
        this.coldDiag = `apiProxy 目录异常: ${error?.message ?? error}`
      }
    }
    return this.allSessionsLegacy(includeChildren)
  }

  /** sessionId → 注册表显示序（workspaceIds 顺序 × sessionIds 顺序）。 */
  private registryRank(): Map<string, number> {
    const rank = new Map<string, number>()
    try {
      const dshHome = process.env.DSH_HOME ?? join(homedir(), '.dsh')
      const raw = JSON.parse(readFileSync(join(dshHome, 'storages', 'workspace.json'), 'utf8'))
      const workspaces = raw?.tables?.workspaces ?? {}
      const order: string[] = raw?.global?.workspaceIds ?? Object.keys(workspaces)
      let n = 0
      for (const wid of order) {
        for (const sid of workspaces[wid]?.sessionIds ?? []) rank.set(sid, n++)
      }
    } catch {
      /* registry unreadable — everything unranked */
    }
    return rank
  }

  /** The GUI-identical catalog: same source, same filters, same ordering. */
  private async allSessionsViaApi(api: any, includeChildren: boolean): Promise<Array<SessionEntry>> {
    const value = await api.sessions.list({})
    const items: any[] = Array.isArray(value) ? value : (value?.items ?? [])
    const archived = this.archivedIds()
    const bound = this.auth.boundSessionIds()
    const rank = this.registryRank()
    const UNRANKED = Number.MAX_SAFE_INTEGER
    // GUI 过滤口径（dsh-client-ui-workspace sessionVisible）：
    //   origin !== 'subagent' && !archived && (!blank || 是当前会话)
    const filtered = items.filter((it) => {
      const id = it?.sessionId
      if (!id) return false
      if (!includeChildren && it.origin === 'subagent') return false
      if (archived.has(id)) return false
      if (it.blank && !bound.has(id) && !this.liveAgentOf(id)) return false
      return true
    })
    filtered.sort((a, b) => {
      const ra = rank.get(a.sessionId) ?? UNRANKED
      const rb = rank.get(b.sessionId) ?? UNRANKED
      if (ra !== rb) return ra - rb
      return (b.updatedAt ?? 0) - (a.updatedAt ?? 0)
    })
    const q = this.query()
    const out: Array<SessionEntry> = []
    let titleFails = 0
    await Promise.all(filtered.map(async (it) => {
      const id = it.sessionId
      const liveAgent = this.liveAgentOf(id)
      let title: string | null = null
      try {
        const t = await q?.readTitle?.(id)
        title = typeof t === 'string' ? t : (t?.title ?? null)
      } catch (e: any) {
        titleFails++
        if (titleFails === 1) this.coldDiag += `；readTitle 异常: ${e?.message ?? e}`
      }
      out.push({
        id,
        title: title ?? (liveAgent ? this.titleOf(liveAgent.session) : null) ?? '未命名会话',
        live: Boolean(liveAgent),
        agent: liveAgent ?? undefined,
        cwdName: cwdBasename(it.cwd ?? liveAgent?.session?.header?.cwd),
        code: shortCode(id),
      })
    }))
    this.coldDiag = `目录 ${items.length} 条；显示 ${filtered.length} 条（GUI 同口径）`
    this.lastList = out
    return out
  }

  private async allSessionsLegacy(includeChildren = false): Promise<Array<SessionEntry>> {
    const out: Array<SessionEntry> = []
    const seen = new Set<string>()
    const q = this.query()
    let records: any[] = []
    if (!q?.listSessions) {
      this.coldDiag = 'sessionQuery 服务不可用'
    } else {
      try {
        records = await q.listSessions()
        this.coldDiag = `冷记录 ${records.length} 条`
      } catch (e: any) {
        records = []
        this.coldDiag = `listSessions 异常: ${e?.message ?? e}`
      }
    }

    // 可见池：所有活会话 + 未归档的持久化会话。
    // 子会话（fork/subagent）仅当其父会话也在池中时才隐藏——
    // 父级已被归档的"孤儿"子会话照常显示（它就是这个分支的代表）。
    const archived = this.archivedIds()
    const poolIds = new Set<string>()
    const live: Array<{ agent: any; s: any }> = []
    for (const agent of this.roots()) {
      const s = agent?.session
      if (!s?.id || seen.has(s.id)) continue
      seen.add(s.id)
      poolIds.add(s.id)
      live.push({ agent, s })
    }
    for (const r of records) {
      const h = r?.header ?? r
      if (h?.id && !archived.has(h.id)) poolIds.add(h.id)
    }
    const childHidden = (header: any) =>
      !includeChildren && header?.parentSession && poolIds.has(header.parentSession)

    for (const { agent, s } of live) {
      if (childHidden(s.header)) continue
      out.push({
        id: s.id,
        title: this.titleOf(s),
        live: true,
        agent,
        cwdName: cwdBasename(s.header?.cwd),
        code: shortCode(s.id),
      })
    }
    if (q?.listSessions) {
      // 与 GUI 口径一致：唯一过滤条件是"未归档"（continuable 子会话 GUI 也显示，不排除）
      // SessionRecord 结构: { header: { id, cwd, parentSession? }, live, persisted }
      // 子会话（subagent/workflow/goal 续跑产生的 parentSession 非空记录）
      // 默认隐藏——它们不是用户创建的"会话"，全列出会淹没列表。
      const cold = records.filter((r) => {
        const h = r?.header ?? r
        if (!h?.id || seen.has(h.id) || archived.has(h.id)) return false
        if (childHidden(h)) return false
        return true
      })
      let titleFails = 0
      await Promise.all(cold.map(async (r) => {
        const h = r.header ?? r
        let title: string | null = null
        try {
          const t = await q.readTitle?.(h.id)
          title = typeof t === 'string' ? t : (t?.title ?? null)
        } catch (e: any) {
          titleFails++
          if (titleFails === 1) this.coldDiag += `；readTitle 异常: ${e?.message ?? e}`
        }
        const cwdName = typeof h.cwd === 'string' ? (h.cwd.split('/').filter(Boolean).pop() ?? '') : ''
        // 活会话但非 root（如 continuable 子会话）：同样可直接绑定，无需 resume
        const liveAgent = this.liveAgentOf(h.id)
        out.push({
          id: h.id,
          title: title ?? (liveAgent ? this.titleOf(liveAgent.session) : null) ?? '未命名会话',
          live: Boolean(liveAgent),
          agent: liveAgent ?? undefined,
          cwdName: cwdName || cwdBasename(liveAgent?.session?.header?.cwd),
          code: shortCode(h.id),
        })
      }))
      this.coldDiag += `；进入列表 ${cold.length} 条`
    }
    this.lastList = out
    return out
  }

  start(): void {
    this.ctx.on('agent/created', ({ agent }: any) => {
      if (this.ctx.agents.roots().includes(agent)) this.lastActiveRoot = agent
    })
    this.ctx.on('agent/status', ({ agent }: any) => {
      if (agent && this.ctx.agents.roots().includes(agent)) this.lastActiveRoot = agent
    })

    // Mirror the session event stream for /log, /status, and completion push.
    this.ctx.on('session/event', (session: any, event: any) => {
      try {
        this.onSessionEvent(session, event)
      } catch (error: any) {
        this.logger.warn(`dsh-chatops: session/event handling failed: ${error?.message ?? error}`)
      }
    })

    // Approval answerer: joins the approval/request waterfall. We only claim
    // requests whose session is bound to a WeChat window; everything else
    // falls through to the GUI answerer untouched.
    // TODO(verify): cordis waterfall pass-through semantics — returning
    // `undefined` must leave the chain to other answerers. Verify against
    // @deepseek-ai/dsh-user-approval decide() before relying on it.
    this.ctx.on('approval/request', (req: any) => this.onApprovalRequest(req))
  }

  // ---------------------------------------------------------------- events --

  private onSessionEvent(session: any, event: any): void {
    const sessionId: string | undefined = session?.id
    if (!sessionId) return
    const data = event?.data ?? {}

    if (event.type === 'assistant/message') {
      const text = messageText(data.message)
      if (text) {
        const ring = this.logRings.get(sessionId) ?? []
        ring.push(text)
        if (ring.length > LOG_RING_SIZE) ring.shift()
        this.logRings.set(sessionId, ring)
      }
      return
    }
    if (event.type === 'turn/start') {
      this.turnStatus.set(sessionId, 'running')
      return
    }
    if (event.type === 'turn/end') {
      // Only push turns we actually OBSERVED running (via turn/start or our
      // own prompt delivery). A turn/end replayed at host restart — an
      // interrupted turn from before the plugin loaded — has no matching
      // start and no output, and pushing it is pure noise
      // ("任务结束(error)：(无文本输出)").
      const wasRunning = this.turnStatus.get(sessionId) === 'running'
      this.turnStatus.set(sessionId, 'idle')
      if (!wasRunning) return
      if (this.config.push?.onSessionComplete !== false) {
        const kind = data.reason?.kind ?? 'unknown'
        const ring = this.logRings.get(sessionId) ?? []
        const last = ring[ring.length - 1]
        const excerpt = last ? last.slice(0, 300) : '(无文本输出)'
        for (const windowKey of this.auth.windowsForSession(sessionId)) {
          // A streaming progress card (feishu) is patched to its final state
          // instead of sending a separate completion text.
          const cardKey = `${sessionId}|${windowKey}`
          const progress = this.progressCards.get(cardKey)
          if (progress) {
            this.progressCards.delete(cardKey)
            const cards = this.channel.cardsFor?.(windowKey)
            if (cards?.completeProgressCard) {
              void cards.completeProgressCard(progress.messageId, progress.sessionTitle, progress.prompt, kind, last ?? '(无文本输出)')
              continue
            }
          }
          const icon = kind === 'completed' ? '✅' : '⚠️'
          void this.channel.say(
            windowKey,
            `${icon} [${this.titleOf(session)}] 任务${kind === 'completed' ? '完成' : `结束(${kind})`}：\n${excerpt}\n\n回复 /log 1 查看完整输出`,
          )
        }
      }
    }
  }

  private async onApprovalRequest(req: any): Promise<'allowed-once' | 'rejected' | undefined> {
    if (this.config.push?.onApproval === false) return undefined
    const session = req.agent?.session
    const sessionId: string | undefined = session?.id
    if (!sessionId) return undefined
    const windows = this.auth.windowsForSession(sessionId)
    if (windows.length === 0) return undefined // not a WeChat-managed session

    const timeoutMs = Math.max(10, this.config.push?.approvalTimeoutSec ?? 300) * 1000
    const approvalId = `appr-${randomUUID().slice(0, 8)}`
    const cardData = {
      approvalId,
      sessionTitle: this.titleOf(session),
      toolName: req.toolName ?? 'unknown',
      reason: String(req.reason ?? '').slice(0, 300),
      timeoutMin: Math.round(timeoutMs / 60000),
    }
    const decision = new Promise<'allowed-once' | 'rejected' | undefined>((resolve) => {
      const timer = setTimeout(() => {
        const pending = this.pendingById.get(approvalId)
        if (pending) this.dropApproval(pending)
        resolve(undefined) // fall through to GUI answerer on timeout
      }, timeoutMs)
      const pending: PendingApproval = { id: approvalId, req, resolve, sessionId, windows, cardData, timer }
      for (const w of windows) this.pendingApprovals.set(w, pending)
      this.pendingById.set(approvalId, pending)
    })

    this.auth.audit('approval/asked', {
      sessionId,
      toolName: req.toolName,
      reason: String(req.reason ?? '').slice(0, 200),
    })
    for (const windowKey of windows) {
      // Card-capable channels (feishu) get an interactive button card;
      // everyone else gets the /approve text fallback.
      const cards = this.channel.cardsFor?.(windowKey)
      if (cards) {
        void cards.sendApprovalCard(windowKey, cardData)
      } else {
        void this.channel.say(
          windowKey,
          `⚠️ [${cardData.sessionTitle}] 审批请求\n` +
            `工具: ${cardData.toolName}\n` +
            `原因: ${cardData.reason}\n\n` +
            `回复 /approve 批准，/reject 拒绝（${cardData.timeoutMin} 分钟内有效，超时转 GUI 处理）`,
        )
      }
    }
    return decision
  }

  private dropApproval(pending: PendingApproval): void {
    clearTimeout(pending.timer)
    for (const [key, value] of this.pendingApprovals) if (value === pending) this.pendingApprovals.delete(key)
    this.pendingById.delete(pending.id)
  }

  /**
   * Card-button decision (feishu card.action.trigger). Returns the terminal
   * card to swap into the message, or null when the approval is unknown or
   * the operator is not trusted.
   */
  async decideApprovalById(
    approvalId: string,
    outcome: 'allowed-once' | 'rejected',
    operatorId: string,
  ): Promise<object | null> {
    const pending = this.pendingById.get(approvalId)
    if (!pending) return null
    if (!this.auth.isAllowed(`fsu:${operatorId}`, 'contact')) {
      this.auth.audit('approval/denied-operator', { approvalId, operatorId })
      return null
    }
    this.dropApproval(pending)
    this.auth.audit('approval/decided', {
      sessionId: pending.sessionId,
      toolName: pending.req?.toolName,
      outcome,
      operator: operatorId,
      via: 'card',
    })
    pending.resolve(outcome)
    const { approvalResultCard } = await import('./feishu/cards')
    return approvalResultCard(pending.cardData, outcome, operatorId)
  }

  // -------------------------------------------------------------- messages --

  async handleInbound(msg: InboundMessage): Promise<void> {
    if (!this.auth.isAllowed(msg.windowKey, msg.kind)) {
      this.auth.audit('ignored/message', { windowKey: msg.windowKey, kind: msg.kind, talkerId: msg.talkerId })
      return
    }
    if (msg.kind === 'room' && !this.auth.isRoomTalkerAllowed(msg.talkerId)) {
      this.auth.audit('ignored/room-talker', { windowKey: msg.windowKey, talkerId: msg.talkerId })
      return
    }

    const text = msg.text
    this.auth.audit('command/inbound', { windowKey: msg.windowKey, text: text.slice(0, 200) })

    if (text.startsWith('/')) {
      const reply = await this.runCommand(msg, text)
      // /log dumps are bulk traffic: they must not stall interactive replies
      // behind the anti-flood throttle (and vice versa). Long dumps go out as
      // a .txt FILE when the channel supports it — no message flooding.
      const cmd = text.split(/\s+/)[0]
      if (cmd === '/log' && reply && reply.length > LONG_OUTPUT_FILE_THRESHOLD
          && this.config.push?.longOutputAsFile !== false) {
        const channel: any = (this.channel as any).channelFor?.(msg.windowKey) ?? null
        if (typeof channel?.sendFile === 'function') {
          const dir = mkdtempSync(join(tmpdir(), 'dsh-chatops-'))
          const file = join(dir, `session-log-${Date.now()}.txt`)
          writeFileSync(file, reply)
          await channel.sendFile(msg.windowKey, file, '📄 输出较长，已转为文件发送')
          return
        }
      }
      if (reply) await this.channel.say(msg.windowKey, reply, { bulk: cmd === '/log' })
      return
    }
    await this.forwardPrompt(msg, text)
  }

  private async runCommand(msg: InboundMessage, text: string): Promise<string> {
    const [cmd, ...rest] = text.split(/\s+/)
    const arg = rest.join(' ').trim()
    switch (cmd) {
      case '/help':
        return HELP_TEXT
      case '/sessions':
        return await this.listSessions(arg === 'debug', arg === 'all' || arg === 'debug')
      case '/use':
        return await this.useSession(msg.windowKey, arg)
      case '/bind':
        return this.showBinding(msg.windowKey)
      case '/status':
        return this.showStatus(msg.windowKey)
      case '/log':
        return this.showLog(msg.windowKey, Number.parseInt(arg, 10) || 3)
      case '/send':
        return await this.sendFileCommand(msg.windowKey, arg)
      case '/approve':
        return this.decideApproval(msg.windowKey, 'allowed-once')
      case '/reject':
        return this.decideApproval(msg.windowKey, 'rejected')
      case '/stop':
        return await this.stopSession(msg.windowKey)
      case '/new':
        return await this.newSession(msg.windowKey, arg)
      case '/policy':
        return this.policyCommand(msg.windowKey, arg)
      default:
        return `未知指令 ${cmd}，回复 /help 查看可用指令。`
    }
  }

  // ------------------------------------------------------------- commands ---

  private roots(): any[] {
    try {
      return this.ctx.agents.roots()
    } catch {
      return []
    }
  }

  /** 按 sessionId 找活 agent——覆盖非 root 的活会话（continuable 子会话 resume 后不是 root）。 */
  private liveAgentOf(sessionId: string): any {
    try {
      return this.ctx.agents.get?.(sessionId) ?? null
    } catch {
      return null
    }
  }

  private async listSessions(debug = false, includeChildren = false): Promise<string> {
    const all = await this.allSessions(includeChildren)
    if (all.length === 0) return '当前没有任何会话。请先在 DSH GUI 中创建一个会话。'
    // Ambiguity pass: same title + same workspace still colliding gets a #code suffix.
    const groups = new Map<string, number>()
    for (const s of all) {
      const key = `${s.title}|${s.cwdName ?? ''}`
      groups.set(key, (groups.get(key) ?? 0) + 1)
    }
    const lines = all.map((s, i) => {
      const status = s.live
        ? this.turnStatus.get(s.id) === 'running' ? '🔄' : '💤'
        : '📦'
      const title = s.title.length > 20 ? s.title.slice(0, 20) + '…' : s.title
      const collides = (groups.get(`${s.title}|${s.cwdName ?? ''}`) ?? 0) > 1
      const tag = collides ? ` #${s.code}` : ''
      const head = s.cwdName ? `${s.cwdName} - ` : ''
      return `${i + 1}. ${head}${title} ${status}${tag}`
    })
    const tail = debug ? `\n\n[诊断] ${this.coldDiag}` : ''
    return `📋 会话列表（${all.length} 个）：\n${lines.join('\n')}${tail}\n\n回复 /use <序号> 切换（📦会自动唤醒）`
  }

  private async useSession(windowKey: string, arg: string): Promise<string> {
    if (!arg) return await this.listSessions()
    const list = this.lastList.length > 0 ? this.lastList : await this.allSessions()
    let entry: SessionEntry | null = null
    const index = Number.parseInt(arg, 10)
    if (Number.isFinite(index) && index >= 1 && index <= list.length) {
      entry = list[index - 1]
    } else {
      const code = arg.replace(/^#/, '')
      entry = list.find((s) => s.id === arg || s.id.startsWith(arg) || s.code === code.toLowerCase()) ?? null
      if (!entry) {
        // 兜底：直接 id 绑定时也允许子会话（默认列表过滤了它们，但显式给 id 说明是刻意的）
        entry = (await this.allSessions(true)).find((s) => s.id === arg || s.id.startsWith(arg)) ?? null
      }
    }
    if (!entry) return `找不到会话 "${arg}"。回复 /sessions 查看列表。`
    // 活会话（含非 root 的 continuable 子会话）直接绑定；真冷会话才 resume
    const liveAgent = entry.agent ?? this.liveAgentOf(entry.id)
    if (!liveAgent) {
      try {
        const handle = await this.ctx.agents.resume({ resumeSessionId: entry.id, agentOptions: this.seedAgentOptions() })
        entry.agent = handle?.agent ?? handle
        entry.live = true
      } catch (error: any) {
        const msg = String(error?.message ?? error)
        if (msg.includes('while it is live')) {
          // 竞态：查询与绑定之间会话被别人打开了——直接重查并绑定
          const again = this.liveAgentOf(entry.id)
          if (again) {
            this.auth.setBinding(windowKey, entry.id)
            return `✅ 已绑定会话：${entry.title}\n直接发消息即作为 prompt 发送。`
          }
        }
        return `⚠️ 会话「${entry.title}」尚未加载，自动唤醒失败：${msg}\n请先在 GUI 中打开它，再 /use 绑定。`
      }
    }
    this.auth.setBinding(windowKey, entry.id)
    return `✅ 已绑定会话：${entry.title}\n直接发消息即作为 prompt 发送。`
  }

  private showBinding(windowKey: string): string {
    const binding = this.auth.getBinding(windowKey)
    if (!binding?.sessionId) return '当前窗口未绑定会话。回复 /sessions 查看列表，/use <编号> 绑定。'
    const agent = this.liveAgentOf(binding.sessionId)
    return `当前绑定：${agent ? this.titleOf(agent.session) : binding.sessionId}${agent ? '' : '（会话已关闭，请重新 /use）'}`
  }

  private showStatus(windowKey: string): string {
    const sessionId = this.auth.getBinding(windowKey)?.sessionId
    if (!sessionId) return '未绑定会话。回复 /sessions + /use <编号> 先绑定。'
    const agent = this.liveAgentOf(sessionId)
    const running = this.turnStatus.get(sessionId) === 'running'
    const lines: string[] = []
    lines.push(`📊 会话：${agent ? this.titleOf(agent.session) : sessionId}`)
    lines.push(`状态：${running ? '🔄 运行中' : '💤 空闲'}`)
    if (agent?.options?.model) {
      lines.push(`模型：${agent.options.provider ? agent.options.provider + ' / ' : ''}${agent.options.model}`)
    }
    if (agent?.session) {
      try {
        const mode = this.ctx.sandboxPolicy?.resolve?.({ session: agent.session })?.mode
        const labels: Record<string, string> = {
          'read-only': '只读', 'workspace-write': '工作区写', 'danger-full-access': '完全开放',
        }
        if (mode) lines.push(`写入安全线：${labels[mode] ?? mode}（/policy 切换）`)
      } catch { /* optional */ }
      try {
        const approval = this.ctx.approval?.effectivePolicy?.(agent.session)
        if (approval) lines.push(`审批策略：${approval}`)
      } catch { /* optional */ }
      const cwd = agent.session.header?.cwd
      if (cwd) lines.push(`工作区：${cwd}`)
    } else {
      lines.push('（会话未加载，发消息会自动唤醒）')
    }
    return lines.join('\n')
  }

  private showLog(windowKey: string, count: number): string {
    const sessionId = this.auth.getBinding(windowKey)?.sessionId
    if (!sessionId) return '未绑定会话。回复 /sessions + /use <编号> 先绑定。'
    const ring = this.logRings.get(sessionId) ?? []
    if (ring.length === 0) return '暂无输出记录（缓冲区仅保留插件加载后的新输出）。'
    const items = ring.slice(-Math.min(count, 10))
    // Full text per item — the channel chunks it into multiple messages.
    // A total guard keeps one huge turn from flooding the chat.
    let body = items.map((t, i) => `--- ${i + 1}/${items.length} ---\n${t}`).join('\n')
    if (body.length > LOG_TOTAL_CAP) {
      body = body.slice(-LOG_TOTAL_CAP)
      body = `（内容过长，仅显示最近 ${LOG_TOTAL_CAP} 字符，完整内容请在 GUI 查看）\n…${body}`
    }
    return `📄 最近 ${items.length} 条输出（完整）：\n${body}`
  }

  private decideApproval(windowKey: string, outcome: 'allowed-once' | 'rejected'): string {
    const pending = this.pendingApprovals.get(windowKey)
    if (!pending) return '当前没有等待审批的请求。'
    this.dropApproval(pending)
    this.auth.audit('approval/decided', {
      sessionId: pending.sessionId,
      toolName: pending.req?.toolName,
      outcome,
      windowKey,
    })
    pending.resolve(outcome)
    return outcome === 'allowed-once' ? '✅ 已批准，继续执行。' : '❌ 已拒绝。'
  }

  /** apiProxy domains (sessions.cancel/create). Absent in headless profiles. */
  private apiProxy(): any {
    try {
      return this.ctx.apiProxy ?? this.ctx.get?.('apiProxy') ?? null
    } catch {
      return null
    }
  }

  /** /stop: cancel the bound session's running turn (same path as the GUI stop button). */
  private async stopSession(windowKey: string): Promise<string> {
    const sessionId = this.auth.getBinding(windowKey)?.sessionId
    if (!sessionId) return '未绑定会话。回复 /sessions + /use <编号> 先绑定。'
    if (this.turnStatus.get(sessionId) !== 'running') return '💤 当前会话没有在执行的任务。'
    const api = this.apiProxy()
    if (!api?.sessions?.cancel) return '⏳ 当前环境不支持终止（apiProxy 不可用）。'
    try {
      await api.sessions.cancel({ sessionId })
      this.turnStatus.set(sessionId, 'idle')
      this.auth.audit('session/cancel', { sessionId, windowKey })
      return '🛑 已终止当前任务。'
    } catch (error: any) {
      return `终止失败：${error?.message ?? error}`
    }
  }

  /**
   * /policy [0|1|2]: read/switch the session's write-safety line.
   * 0=read-only 1=workspace-write 2=danger-full-access (needs YES confirm).
   * Writes the `sandbox/mode` session event — the same fold the GUI uses.
   */
  private policyCommand(windowKey: string, arg: string): string {
    const sessionId = this.auth.getBinding(windowKey)?.sessionId
    if (!sessionId) return '未绑定会话。回复 /sessions + /use <编号> 先绑定。'
    const agent = this.liveAgentOf(sessionId)
    if (!agent?.session) return '会话未加载，无法读写安全线。请 /use 重新绑定（📦会话会自动唤醒）。'

    const MODE_LABELS: Record<string, string> = {
      'read-only': '只读', 'workspace-write': '工作区写', 'danger-full-access': '完全开放',
    }
    const MODES = ['read-only', 'workspace-write', 'danger-full-access']
    let current = 'read-only'
    try {
      current = this.ctx.sandboxPolicy?.resolve?.({ session: agent.session })?.mode ?? current
    } catch { /* fall back */ }

    const pending = this.pendingPolicy.get(windowKey)
    if (pending && Date.now() - pending.at < 60_000) {
      if (arg === 'YES') {
        this.pendingPolicy.delete(windowKey)
        return this.applyPolicy(agent.session, pending.mode, windowKey)
      }
      this.pendingPolicy.delete(windowKey)
    }

    if (!arg) {
      const idx = MODES.indexOf(current)
      return `🔒 当前安全线：${MODE_LABELS[current] ?? current}（${idx}）\n回复 /policy 0|1|2 切换：\n0=只读  1=工作区写  2=完全开放（危险）`
    }
    const mode = MODES[Number(arg)]
    if (!mode) return '用法：/policy 0|1|2（0=只读 1=工作区写 2=完全开放）'
    if (mode === current) return `已是${MODE_LABELS[mode]}模式，无需切换。`
    if (mode === 'danger-full-access') {
      this.pendingPolicy.set(windowKey, { mode, at: Date.now() })
      return '⚠️ 完全开放将允许任意文件读写，回复 YES 确认（60 秒内有效）。'
    }
    return this.applyPolicy(agent.session, mode, windowKey)
  }

  private applyPolicy(session: any, mode: string, windowKey: string): string {
    const labels: Record<string, string> = {
      'read-only': '只读', 'workspace-write': '工作区写', 'danger-full-access': '完全开放',
    }
    try {
      // Identical to dsh-sandbox-policy's setSandboxMode(): append the fold event.
      session.append('sandbox/mode', { mode })
      this.auth.audit('policy/set', { sessionId: session.id, mode, windowKey })
      return `✅ 已切换：${labels[mode] ?? mode}`
    } catch (error: any) {
      return `切换失败：${error?.message ?? error}`
    }
  }

  /**
   * /new [prompt]: create a session in the current workspace (bound session's
   * cwd, else the most recently active root's), bind this window to it, and
   * optionally deliver the prompt immediately.
   */
  private async newSession(windowKey: string, prompt: string): Promise<string> {
    const api = this.apiProxy()
    if (!api?.sessions?.create) return '⏳ 当前环境不支持创建会话（apiProxy 不可用）。'
    const boundId = this.auth.getBinding(windowKey)?.sessionId
    const cwd =
      (boundId ? this.liveAgentOf(boundId)?.session?.header?.cwd : null) ??
      this.lastActiveRoot?.session?.header?.cwd ??
      this.roots()[this.roots().length - 1]?.session?.header?.cwd
    if (!cwd) return '无法确定工作区（先 /use 绑定一个会话，或在 GUI 打开一个会话）。'
    let created: any
    try {
      created = await api.sessions.create({ cwd })
    } catch (error: any) {
      return `创建失败：${error?.message ?? error}`
    }
    const newId = created?.sessionId
    if (!newId) return '创建失败：未返回会话 id。'
    this.auth.setBinding(windowKey, newId)
    this.auth.audit('session/create', { windowKey, sessionId: newId, cwd, hadPrompt: Boolean(prompt) })

    if (!prompt) return `✅ 已在当前工作区创建并绑定新会话（${shortId(newId)}）。直接发消息即开始。`

    // Deliver the initial prompt: the agent may register a beat after create.
    let agent: any = null
    for (let i = 0; i < 6 && !agent; i++) {
      agent = this.liveAgentOf(newId)
      if (!agent) await new Promise((r) => setTimeout(r, 400))
    }
    if (!agent) return `✅ 新会话已创建并绑定（${shortId(newId)}），但 prompt 投递失败：agent 尚未就绪，请直接再发一遍内容。`
    try {
      const message = createUserMessage({
        content: [{ type: 'text', text: prompt }],
        source: { kind: 'plugin', plugin: 'dsh-chatops' },
      })
      agent.followup(message)
      this.turnStatus.set(newId, 'running')
      return `✅ 新会话已创建并绑定（${shortId(newId)}），prompt 已投递，完成后通知你。`
    } catch (error: any) {
      return `✅ 新会话已创建并绑定（${shortId(newId)}），但 prompt 投递失败：${error?.message ?? error}`
    }
  }

  // ----------------------------------------------------------- file send ---

  /** /send <path>: push a workspace file to the bound IM window. */
  private async sendFileCommand(windowKey: string, arg: string): Promise<string> {
    if (!arg) return '用法：/send <工作区内文件路径>（如 /send reports/weekly.md）'
    const sessionId = this.auth.getBinding(windowKey)?.sessionId
    if (!sessionId) return '未绑定会话。回复 /sessions + /use <编号> 先绑定。'
    const resolved = this.resolveWorkspaceFile(sessionId, arg)
    if ('error' in resolved) return resolved.error
    const ok = await this.sendFileToWindow(windowKey, resolved.path, `📎 ${basename(resolved.path)}`)
    return ok
      ? `📤 文件「${basename(resolved.path)}」发送中…`
      : '当前通道不支持文件发送（微信 ilink / 飞书支持；wechaty 通道暂不支持）。'
  }

  /**
   * Tool entry: the model calls im_send_file inside a session; the file goes
   * to every IM window bound to THAT session (never to a stranger's window).
   */
  async sendFileForSession(sessionId: string, relPath: string, caption?: string): Promise<string> {
    const resolved = this.resolveWorkspaceFile(sessionId, relPath)
    if ('error' in resolved) {
      this.auth.audit('file/send-failed', { sessionId, relPath, reason: resolved.error })
      return `发送失败：${resolved.error}`
    }
    const windows = this.auth.windowsForSession(sessionId)
    if (windows.length === 0) {
      this.auth.audit('file/send-failed', { sessionId, relPath, reason: 'no-bound-window' })
      return '发送失败：该会话没有绑定任何 IM 窗口（在微信/飞书里 /use 绑定后再试）。'
    }
    let sent = 0
    let lastError: string | null = null
    for (const windowKey of windows) {
      try {
        if (await this.sendFileToWindow(windowKey, resolved.path, caption ?? `📎 ${basename(resolved.path)}`)) sent++
        else lastError = '通道不支持文件发送'
      } catch (error: any) {
        lastError = error?.message ?? String(error)
      }
    }
    if (sent === 0 && lastError) {
      this.auth.audit('file/send-failed', { sessionId, relPath, reason: lastError })
      return `发送失败：${lastError}`
    }
    this.auth.audit('file/send', {
      sessionId,
      path: resolved.path,
      windows,
      sent,
    })
    return sent > 0
      ? `文件「${basename(resolved.path)}」已发送到 ${sent} 个 IM 窗口。`
      : '发送失败：绑定的通道不支持文件发送。'
  }

  /** Resolve relPath inside the session workspace; refuse escapes. */
  private resolveWorkspaceFile(sessionId: string, relPath: string): { path: string } | { error: string } {
    const agent = this.liveAgentOf(sessionId)
    const cwd = agent?.session?.header?.cwd
    if (!cwd) return { error: '会话未加载，无法确定工作区。请 /use 重新绑定（📦会话会自动唤醒）。' }
    const abs = resolve(cwd, relPath)
    if (abs !== cwd && !abs.startsWith(cwd + sep)) {
      this.auth.audit('file/escape-blocked', { sessionId, relPath })
      return { error: '只允许发送当前会话工作区内的文件。' }
    }
    if (!existsSync(abs)) return { error: `文件不存在：${relPath}` }
    try {
      if (!statSync(abs).isFile()) return { error: `不是文件：${relPath}` }
    } catch {
      return { error: `无法读取：${relPath}` }
    }
    return { path: abs }
  }

  /** Send via the channel owning this window, when it supports file send. */
  private async sendFileToWindow(windowKey: string, path: string, caption?: string): Promise<boolean> {
    const channel: any = (this.channel as any).channelFor?.(windowKey) ?? null
    if (typeof channel?.sendFile !== 'function') return false
    await channel.sendFile(windowKey, path, caption)
    return true
  }

  // --------------------------------------------------------------- prompt ---

  private async forwardPrompt(msg: InboundMessage, text: string): Promise<void> {
    const windowKey = msg.windowKey
    const sessionId = this.auth.getBinding(windowKey)?.sessionId
    let agent = sessionId ? this.liveAgentOf(sessionId) : null

    // 绑定的是冷会话（未加载）：先尝试从持久化日志唤醒。
    // 有绑定时绝不兜底投递到其他会话、绝不改绑定——失败就如实告知。
    if (sessionId && !agent) {
      try {
        await this.ctx.agents.resume({ resumeSessionId: sessionId, agentOptions: this.seedAgentOptions() })
        agent = this.liveAgentOf(sessionId)
      } catch (error: any) {
        const reason = error?.message ?? String(error)
        this.auth.audit('session/wake-failed', { sessionId, windowKey, reason })
        this.logger.warn(`dsh-chatops: resume ${sessionId} failed: ${reason}`)
        await this.channel.say(
          windowKey,
          `⚠️ 会话暂时无法唤醒（${reason}），消息未发送。请稍后再试，或 /use 重新绑定。`,
        )
        return
      }
      if (!agent) {
        this.auth.audit('session/wake-failed', { sessionId, windowKey, reason: 'resume 返回但 agent 未就绪' })
        await this.channel.say(windowKey, '⚠️ 会话唤醒超时，消息未发送。请再发一次。')
        return
      }
    }

    // Fallback（仅限从未绑定过的窗口）：deliver to the most recently active
    // root (same heuristic as dsh-cron) and bind, so the first message
    // "just works".
    if (!agent) {
      agent = this.lastActiveRoot && this.roots().includes(this.lastActiveRoot)
        ? this.lastActiveRoot
        : this.roots()[this.roots().length - 1]
      if (!agent) {
        await this.channel.say(windowKey, '当前没有打开的会话。请先在 DSH GUI 中打开一个会话。')
        return
      }
      this.auth.setBinding(windowKey, agent.session.id)
      await this.channel.say(windowKey, `🔗 已自动绑定到最近活跃的会话：${this.titleOf(agent.session)}`)
    }

    try {
      const message = createUserMessage({
        content: [{ type: 'text', text }],
        source: { kind: 'plugin', plugin: 'dsh-chatops' },
      })
      // Queues an ordinary turn and wakes the driver; a busy agent queues the
      // turn behind the current one, so WeChat prompts never overlap.
      agent.followup(message)
      this.turnStatus.set(agent.session.id, 'running')
      const cards = this.channel.cardsFor?.(windowKey)
      if (cards?.sendProgressCard) {
        const sessionTitle = this.titleOf(agent.session)
        const messageId = await cards.sendProgressCard(windowKey, sessionTitle, text)
        if (messageId) {
          this.progressCards.set(`${agent.session.id}|${windowKey}`, { messageId, prompt: text, sessionTitle })
        } else {
          await this.channel.say(windowKey, `🚀 已发送给 [${sessionTitle}]，完成后通知你。`)
        }
      } else {
        await this.channel.say(windowKey, `🚀 已发送给 [${this.titleOf(agent.session)}]，完成后通知你。`)
      }
    } catch (error: any) {
      this.logger.warn(`dsh-chatops: followup failed: ${error?.message ?? error}`)
      await this.channel.say(windowKey, `❌ 发送失败：${error?.message ?? error}`)
    }
  }
}

export const HELP_TEXT = `🤖 dsh-chatops 指令：
/sessions — 会话列表（/sessions all 含子会话）
/use <编号> — 绑定会话
/bind — 查看当前绑定
/status — 会话运行状态
/log [n] — 最近 n 条完整输出
/approve /reject — 审批
/stop — 终止当前任务
/policy — 查看/切换写入安全线
/new [提示词] — 当前工作区建新会话
/send <路径> — 回传工作区文件
直接发送其他文字 = 作为 prompt 发给绑定会话`

// ------------------------------------------------------------------ helpers --

/** 4-char disambiguation code from a session id (strips the "session-" prefix). */
function shortCode(id: unknown): string {
  const text = typeof id === 'string' ? id.replace(/^session-/, '') : ''
  return text.slice(0, 4).toLowerCase()
}

/** Last path segment of a cwd, for disambiguating duplicate titles. */
function cwdBasename(cwd: unknown): string | undefined {
  if (typeof cwd !== 'string' || !cwd) return undefined
  return cwd.split('/').filter(Boolean).pop() ?? undefined
}

function shortId(id: unknown): string {
  const text = typeof id === 'string' ? id : '?'
  return text.length > 24 ? text.slice(0, 24) + '…' : text
}

function messageText(message: any): string {
  if (!message) return ''
  if (typeof message === 'string') return message
  const content = message.content
  if (typeof content === 'string') return content
  if (Array.isArray(content)) {
    return content
      .filter((p: any) => p?.type === 'text' && typeof p.text === 'string')
      .map((p: any) => p.text)
      .join('\n')
  }
  return ''
}

