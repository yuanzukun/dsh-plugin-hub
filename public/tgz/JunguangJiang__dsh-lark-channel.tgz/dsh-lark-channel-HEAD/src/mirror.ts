/**
 * Session mirroring: the `/lark` host command binds one DSH GUI session to a
 * Feishu receive id. The session's traffic — user messages and the assistant's
 * final reply per turn, plus tool-call lines when verbose — is forwarded to
 * that target as markdown, and ordinary messages arriving at the target are
 * injected into the bound session as the next user turn.
 *
 * Pure state plus injected persistence here, mirroring the workspace and model
 * stores: the bridge supplies the settings-section writer and the transport,
 * and tests substitute fakes.
 * @module dsh-lark-channel/mirror
 */

import { randomUUID } from 'node:crypto'
import type { HostSessionEvent } from './host.ts'
import {
  assistantText,
  isAssistantMessageEvent,
  isCommandDoneEvent,
  isCommandRunEvent,
  isToolCallEvent,
  isTurnEndEvent,
  isTurnStartEvent,
  isUserMessageEvent,
  turnErrorDetail,
} from './host.ts'

/** The host-side command name, typed `/lark` in the DSH GUI. */
export const LARK_COMMAND = 'lark'

/** One-line usage summary shown with parse errors. */
export const MIRROR_HELP = '用法：`/lark` 开启（目标取配置 mirrorTarget）；`/lark to <chatId|open_id>` 指定目标并开启；`/lark off` 关闭；`/lark status` 查看状态；`/lark verbose on|off` 过程消息开关。'

/** Long mirror payloads split into chunks of roughly this many characters. */
export const MIRROR_CHUNK_MAX = 4000

/** Id prefix stamped on messages the mirror injected, so they are never echoed back to the chat they came from. */
const MIRROR_MESSAGE_PREFIX = 'lark-mirror-'

/** Entry value marking "explicitly unbound": a deep-merged patch cannot delete a key. */
export const MIRROR_UNBOUND = ''

/**
 * A compiled trigger-phrase table: keys are lowercased phrases, values are
 * the slash-command lines they map to. Compiled once from config at bridge
 * init; matching is O(n) over entries, which is fine for the small tables
 * deployments will configure.
 */
export interface TriggerPhraseTable {
  /** Lowercased phrase → command line (including leading `/`). */
  readonly entries: ReadonlyMap<string, string>
}

/**
 * Compile one config `triggerPhrases` record into a lookup table.
 * @param raw - the config record; empty or undefined produces an empty table.
 * @returns the compiled table.
 */
export function compileTriggerPhrases(raw: Record<string, string> | undefined): TriggerPhraseTable {
  const entries = new Map<string, string>()
  if (raw !== undefined) {
    for (const [phrase, command] of Object.entries(raw)) {
      const key = phrase.trim().toLowerCase()
      if (key !== '' && command.trim() !== '') entries.set(key, command.trim())
    }
  }
  return { entries }
}

/**
 * Match one inbound message against the trigger-phrase table. The match is
 * exact equality after trimming and lowercasing — not substring, not prefix —
 * so a phrase "开始处理" matches "开始处理" and " 开始处理 " but not "请开始处理".
 * @param text - the message text, exactly as received.
 * @param table - the compiled trigger-phrase table.
 * @returns the mapped command line, or undefined when no phrase matches.
 */
export function matchTriggerPhrase(text: string, table: TriggerPhraseTable): string | undefined {
  if (table.entries.size === 0) return undefined
  return table.entries.get(text.trim().toLowerCase())
}

/** What one parsed `/lark` line asks for. */
export type MirrorAction =
  | { readonly kind: 'on'; readonly target?: string | undefined; readonly topic?: string | undefined }
  | { readonly kind: 'to'; readonly target: string; readonly topic?: string | undefined }
  | { readonly kind: 'off' }
  | { readonly kind: 'status' }
  | { readonly kind: 'verbose'; readonly value: boolean }
  | { readonly kind: 'error'; readonly reason: string }

/**
 * Parse the input after `/lark`.
 * @param rawInput - exact text following the command name.
 * @returns the action; an unparsable line is an error naming the problem.
 */
export function parseMirrorInput(rawInput: string): MirrorAction {
  const tokens = rawInput.trim().split(/\s+/).filter(token => token !== '')
  if (tokens.length === 0) return { kind: 'on' }
  const head = tokens[0]!
  switch (head) {
    case 'on':
      if (tokens.length === 1) return { kind: 'on' }
      if (tokens.length === 2 && tokens[1] !== 'to') return { kind: 'on', target: tokens[1] }
      if (tokens.length === 3 && tokens[1] === 'to') return { kind: 'on', target: tokens[2] }
      return { kind: 'error', reason: '`on` 接受：`on`、`on <目标>`、`on to <目标>`。' }
    case 'to': {
      if (tokens.length === 2) return { kind: 'to', target: tokens[1]! }
      // /lark to <target> topic <name...>
      if (tokens.length >= 4 && tokens[2] === 'topic') {
        return { kind: 'to', target: tokens[1]!, topic: tokens.slice(3).join(' ') }
      }
      return { kind: 'error', reason: '`to` 接受：`to <目标>` 或 `to <目标> topic <话题名>`。' }
    }
    case 'off':
      if (tokens.length !== 1) return { kind: 'error', reason: '`off` 不接受参数。' }
      return { kind: 'off' }
    case 'status':
      if (tokens.length !== 1) return { kind: 'error', reason: '`status` 不接受参数。' }
      return { kind: 'status' }
    case 'verbose': {
      if (tokens.length !== 2 || (tokens[1] !== 'on' && tokens[1] !== 'off')) {
        return { kind: 'error', reason: '`verbose` 接受：`verbose on` 或 `verbose off`。' }
      }
      return { kind: 'verbose', value: tokens[1] === 'on' }
    }
    default:
      return { kind: 'error', reason: `未知子命令 \`${head}\`。` }
  }
}

/**
 * Split one markdown payload into chunks within `max` characters, preferring
 * line boundaries so a chunk never cuts inside a short line.
 * @param text - the payload to split.
 * @param max - the soft per-chunk limit; clamped to at least 1.
 * @returns the chunks; an empty payload yields none.
 */
export function splitMarkdown(text: string, max: number = MIRROR_CHUNK_MAX): string[] {
  const limit = Math.max(1, Math.floor(max))
  const lines = text.replace(/\r\n?/g, '\n').split('\n')
  // All-whitespace/empty text produces no chunks.
  if (lines.every(line => line === '')) return []
  const chunks: string[] = []
  let current = ''
  const flush = (): void => {
    if (current !== '') {
      chunks.push(current)
      current = ''
    }
  }
  for (const line of lines) {
    // One overlong line hard-splits: a chunk boundary mid-line is better than
    // losing the text, and no shorter line ever needs it.
    if (line.length > limit) {
      flush()
      for (let offset = 0; offset < line.length; offset += limit) {
        chunks.push(line.slice(offset, offset + limit))
      }
      continue
    }
    if (current === '') {
      current = line
    } else if (current.length + 1 + line.length <= limit) {
      current += `\n${line}`
    } else {
      flush()
      current = line
    }
  }
  flush()
  return chunks
}

/** Mint the id stamped on a message the mirror injected into a GUI session. */
export function mirrorMessageId(): string {
  return `${MIRROR_MESSAGE_PREFIX}${randomUUID()}`
}

/**
 * Whether a `user/message` event carries a mirror-injected message.
 * @param id - the event's message id, when present.
 * @returns whether the forwarder must skip it.
 */
export function isMirrorInjectedId(id: string | undefined): boolean {
  return id !== undefined && id.startsWith(MIRROR_MESSAGE_PREFIX)
}

/** The receive-id kind one mirror target uses, from its platform prefix. */
export type MirrorTargetKind = 'user' | 'chat' | 'other'

/**
 * Classify one mirror target the way the transport's own routing does.
 * @param target - the target receive id.
 * @returns its kind.
 */
export function mirrorTargetKind(target: string): MirrorTargetKind {
  if (target.startsWith('ou_')) return 'user'
  if (target.startsWith('oc_')) return 'chat'
  return 'other'
}

/** The human label for one target's kind, shown in command reports. */
export function mirrorTargetKindLabel(target: string): string {
  switch (mirrorTargetKind(target)) {
    case 'user':
      return '用户 open_id'
    case 'chat':
      return '会话 chat_id'
    case 'other':
      return '其他 receive_id'
  }
}

/** Join the text blocks of one user-role message, empty when it carries none. */
export function mirrorUserText(
  content: readonly { readonly type: string; readonly text?: string }[] | undefined,
): string {
  return (content ?? [])
    .filter(block => block.type === 'text' && typeof block.text === 'string' && block.text !== '')
    .map(block => block.text)
    .join('')
}

/** Render one mirrored user message as markdown. */
export function userMarkdown(text: string): string {
  return `👤 **用户**：\n\n${text}`
}

/** Render one mirrored assistant reply as markdown. */
export function assistantMarkdown(text: string): string {
  return `🤖 **DSH 助手**：\n\n${text}`
}

/**
 * Render one tool invocation as a one-line activity notice. Model-influenced
 * arguments are untrusted: newlines and backticks collapse so they cannot
 * restructure the markdown, and the rest is bounded.
 * @param name - the tool's name.
 * @param argumentsJson - raw arguments JSON exactly as the model produced it.
 * @returns one bounded markdown line.
 */
export function toolCallMarkdown(name: string, argumentsJson: string): string {
  const brief = argumentsJson.replace(/[\s`]+/g, ' ').trim()
  const shown = brief.length <= 240 ? brief : `${brief.slice(0, 239)}…`
  return shown === '' ? `🔧 \`${name}\`` : `🔧 \`${name}\` ${shown}`
}

/** A thread anchor for routing messages into a specific topic. */
export interface ThreadAnchor {
  readonly messageId: string
  readonly threadId: string
}

/** One live mirror binding. */
export interface MirrorBinding {
  readonly sessionId: string
  readonly target: string
  /** Whether tool-call lines forward with the rest. */
  readonly verbose: boolean
  /** When set, outbound mirror messages route into this topic thread. */
  readonly threadAnchor?: ThreadAnchor | undefined
}

/** Construction options for {@link MirrorBindings}. */
export interface MirrorBindingsOptions {
  /** Persisted sessionId → target entries; {@link MIRROR_UNBOUND} marks unbound. */
  readonly entries?: Record<string, string> | undefined
  /** Deep-merge one patch into the plugin's settings section; false = not composed. */
  readonly persist?: ((patch: { sessionMirrors: Record<string, string> }) => Promise<boolean>) | undefined
  /** Operator console line. */
  readonly report?: ((line: string) => void) | undefined
}

/** What one bind concluded. */
export interface MirrorBindResult {
  /** The target now bound, trimmed. */
  readonly target: string
  /** The session this binding displaced, when one target had two sessions. */
  readonly displacedSession?: string | undefined
  /** Whether the change survives a restart. */
  readonly durable: boolean
  /** False when the session was already bound to this exact target. */
  readonly changed: boolean
}

/** What one unbind concluded; a removed binding names the target it held. */
export type MirrorUnbindResult =
  | { readonly removed: false; readonly durable: boolean }
  | { readonly removed: true; readonly target: string; readonly durable: boolean }

/** What one verbose flip concluded. */
export interface MirrorVerboseResult {
  /** Whether the value actually changed. */
  readonly changed: boolean
  /** Whether the session is bound; flipping an unbound session is a no-op. */
  readonly bound: boolean
}

/**
 * Parse one persisted mirror entry (backward compatible).
 * Format: plain `target` or `target|messageId|threadId` (pipe-separated).
 * @param entry - raw persisted value.
 * @returns parsed target and optional thread anchor, or undefined for empty/unbound.
 */
export function parseMirrorEntry(entry: string): { target: string; threadAnchor?: ThreadAnchor } | undefined {
  const trimmed = entry.trim()
  if (trimmed === '') return undefined
  const parts = trimmed.split('|')
  const target = parts[0]!
  if (parts.length >= 3 && parts[1] !== '' && parts[2] !== '') {
    return { target, threadAnchor: { messageId: parts[1]!, threadId: parts[2]! } }
  }
  return { target }
}

/**
 * Serialize one mirror binding for persistence.
 * @param target - the receive id.
 * @param threadAnchor - optional thread anchor.
 * @returns the serialized entry string.
 */
export function serializeMirrorEntry(target: string, threadAnchor?: ThreadAnchor): string {
  if (threadAnchor === undefined) return target
  return `${target}|${threadAnchor.messageId}|${threadAnchor.threadId}`
}

// ── Composite key helpers for byTarget ──

/**
 * Build the byTarget composite key for one binding.
 * With a thread anchor: `target#threadId`; without: bare `target`.
 */
function compositeKey(target: string, threadAnchor: ThreadAnchor | undefined): string {
  return threadAnchor !== undefined ? `${target}#${threadAnchor.threadId}` : target
}

/**
 * The session-mirror binding table. Supports multiple sessions per group chat
 * when each anchors a different topic thread: the byTarget map uses composite
 * keys (`target#threadId`) for anchored bindings and bare target keys for
 * unanchored ones. Persistence goes through the settings section with the same
 * empty-marker convention as the workspace and epoch maps.
 */
export class MirrorBindings {
  /** sessionId → its target, verbose flag, and optional thread anchor. */
  private readonly bound = new Map<string, { target: string; verbose: boolean; threadAnchor?: ThreadAnchor }>()
  /** Composite key → sessionId; kept injective per composite key by bind/unbind. */
  private readonly byTarget = new Map<string, string>()
  private readonly persist: (patch: { sessionMirrors: Record<string, string> }) => Promise<boolean>
  private readonly report: (line: string) => void
  private durableFlag = true
  private warnedNotDurable = false

  constructor(options: MirrorBindingsOptions = {}) {
    this.persist = options.persist ?? (async () => false)
    this.report = options.report ?? (() => {})
    for (const [sessionId, entry] of Object.entries(options.entries ?? {})) {
      const parsed = parseMirrorEntry(entry)
      if (parsed === undefined) continue
      const key = compositeKey(parsed.target, parsed.threadAnchor)
      const displaced = this.byTarget.get(key)
      if (displaced !== undefined) this.bound.delete(displaced)
      this.bound.set(sessionId, { target: parsed.target, verbose: false, threadAnchor: parsed.threadAnchor })
      this.byTarget.set(key, sessionId)
    }
  }

  /** Whether the latest change was written through the settings service. */
  get durable(): boolean {
    return this.durableFlag
  }

  /** The target one session mirrors to, when bound. */
  targetOf(sessionId: string): string | undefined {
    return this.bound.get(sessionId)?.target
  }

  /** Whether one session's tool-call lines forward. */
  verboseOf(sessionId: string): boolean {
    return this.bound.get(sessionId)?.verbose === true
  }

  /** Whether one session has a live binding. */
  isBound(sessionId: string): boolean {
    return this.bound.has(sessionId)
  }

  /** The full binding for one session, when bound. */
  bindingFor(sessionId: string): MirrorBinding | undefined {
    const entry = this.bound.get(sessionId)
    if (entry === undefined) return undefined
    return { sessionId, target: entry.target, verbose: entry.verbose, threadAnchor: entry.threadAnchor }
  }

  /** Every live binding, in insertion order. */
  list(): readonly MirrorBinding[] {
    return [...this.bound.entries()].map(([sessionId, entry]) => ({
      sessionId,
      target: entry.target,
      verbose: entry.verbose,
      threadAnchor: entry.threadAnchor,
    }))
  }

  /**
   * The session one target drives, when any is bound to it.
   * Accepts both bare target and composite key for backward compatibility.
   */
  sessionFor(target: string): string | undefined {
    return this.byTarget.get(target.trim())
  }

  /**
   * Reverse dispatch for one inbound message. Checks composite keys first,
   * then rootId-based anchor matching (with self-healing), then bare key,
   * then p2p sender fallback.
   * @param chatId - the message's chat id.
   * @param p2pSenderId - the sender, consulted only when chatType is p2p.
   * @param chatType - the message's chat type; sender fallback only applies for 'p2p'.
   * @param threadId - the message's thread id, for topic-level discrimination.
   * @param rootId - the root message id of the topic thread (from NormalizedMessage.rootId).
   * @returns the bound session id, or undefined when the chat is not a mirror.
   */
  reverseLookup(chatId: string, p2pSenderId?: string, chatType?: string, threadId?: string, rootId?: string): string | undefined {
    // 1. Try composite key: chatId#threadId
    if (threadId !== undefined) {
      const compositeHit = this.byTarget.get(`${chatId}#${threadId}`)
      if (compositeHit !== undefined) return compositeHit
    }
    // 2. rootId match: scan bindings for this chatId whose anchor.messageId === rootId.
    //    This handles the case where the persisted threadId is the root message id (om_…)
    //    but the real threadId differs. On hit, self-heal: update threadAnchor.threadId
    //    to the real threadId and migrate the composite key + persist.
    if (rootId !== undefined && threadId !== undefined) {
      for (const [sessionId, entry] of this.bound) {
        if (entry.target !== chatId) continue
        if (entry.threadAnchor === undefined) continue
        if (entry.threadAnchor.messageId === rootId) {
          // Self-heal: update threadId to the real one
          if (entry.threadAnchor.threadId !== threadId) {
            const oldKey = compositeKey(entry.target, entry.threadAnchor)
            this.byTarget.delete(oldKey)
            entry.threadAnchor = { messageId: entry.threadAnchor.messageId, threadId }
            const newKey = compositeKey(entry.target, entry.threadAnchor)
            this.byTarget.set(newKey, sessionId)
            // Persist the corrected anchor (fire-and-forget)
            void this.persist({ sessionMirrors: { [sessionId]: serializeMirrorEntry(entry.target, entry.threadAnchor) } }).catch(() => {})
          }
          return sessionId
        }
      }
    }
    // 3. Try bare chatId key (unanchored binding matches any thread)
    const bareHit = this.byTarget.get(chatId)
    if (bareHit !== undefined) {
      const entry = this.bound.get(bareHit)
      if (entry?.threadAnchor !== undefined && threadId !== entry.threadAnchor.threadId) {
        return undefined
      }
      return bareHit
    }
    // 4. p2p sender fallback
    if (chatType === 'p2p' && p2pSenderId !== undefined) {
      if (threadId !== undefined) {
        const compositeP2p = this.byTarget.get(`${p2pSenderId}#${threadId}`)
        if (compositeP2p !== undefined) return compositeP2p
      }
      const bareP2p = this.byTarget.get(p2pSenderId)
      if (bareP2p !== undefined) return bareP2p
    }
    return undefined
  }

  /**
   * Bind one session to a target, displacing the target's previous session
   * only when it occupies the same composite key (same group + same thread).
   * @param sessionId - the GUI session to mirror.
   * @param target - the receive id (chat id or open id) to mirror to.
   * @param threadAnchor - optional thread anchor for topic-level mirroring.
   * @returns what changed, and whether it persisted.
   */
  async bind(sessionId: string, target: string, threadAnchor?: ThreadAnchor): Promise<MirrorBindResult> {
    const trimmed = target.trim()
    const previous = this.bound.get(sessionId)
    if (previous !== undefined && previous.target === trimmed && !threadAnchor) {
      return { target: trimmed, durable: this.durableFlag, changed: false }
    }
    const key = compositeKey(trimmed, threadAnchor)
    let displacedSession: string | undefined
    const owner = this.byTarget.get(key)
    if (owner !== undefined && owner !== sessionId) {
      displacedSession = owner
      this.bound.delete(owner)
    }
    if (previous !== undefined) {
      // Remove old composite key
      const oldKey = compositeKey(previous.target, previous.threadAnchor)
      this.byTarget.delete(oldKey)
    }
    this.bound.set(sessionId, { target: trimmed, verbose: previous?.verbose === true, threadAnchor })
    this.byTarget.set(key, sessionId)
    const patch: Record<string, string> = { [sessionId]: serializeMirrorEntry(trimmed, threadAnchor) }
    if (displacedSession !== undefined) patch[displacedSession] = MIRROR_UNBOUND
    const durable = await this.persist({ sessionMirrors: patch }).catch((error: unknown) => {
      this.report(`lark-channel: persisting the mirror binding failed: ${String(error)}`)
      return false
    })
    this.durableFlag = durable
    if (!durable && !this.warnedNotDurable) {
      this.warnedNotDurable = true
      this.report('lark-channel: mirror bindings are in-memory only (no settings service); they reset on restart')
    }
    return {
      target: trimmed,
      ...displacedSession === undefined ? {} : { displacedSession },
      durable,
      changed: true,
    }
  }

  /**
   * Remove one session's binding. The entry is overwritten with the unbound
   * marker rather than deleted, because the settings writer deep-merges.
   * @param sessionId - the session to unbind.
   * @returns whether anything was bound, and whether the change persisted.
   */
  async unbind(sessionId: string): Promise<MirrorUnbindResult> {
    const previous = this.bound.get(sessionId)
    if (previous === undefined) return { removed: false, durable: this.durableFlag }
    this.bound.delete(sessionId)
    const key = compositeKey(previous.target, previous.threadAnchor)
    this.byTarget.delete(key)
    const durable = await this.persist({ sessionMirrors: { [sessionId]: MIRROR_UNBOUND } }).catch((error: unknown) => {
      this.report(`lark-channel: persisting the mirror unbind failed: ${String(error)}`)
      return false
    })
    this.durableFlag = durable
    return { removed: true, target: previous.target, durable }
  }

  /**
   * Flip one binding's verbose flag. Not persisted: a presentation preference.
   * @param sessionId - the bound session.
   * @param on - whether tool-call lines forward.
   * @returns whether the value changed, and whether the session is bound.
   */
  setVerbose(sessionId: string, on: boolean): MirrorVerboseResult {
    const entry = this.bound.get(sessionId)
    if (entry === undefined) return { changed: false, bound: false }
    const changed = entry.verbose !== on
    entry.verbose = on
    return { changed, bound: true }
  }

  /**
   * Set or clear the thread anchor on an existing binding.
   * @param sessionId - the bound session.
   * @param anchor - the thread anchor to set, or undefined to clear.
   * @returns whether the session is bound (false = no-op).
   */
  async setThreadAnchor(sessionId: string, anchor: ThreadAnchor | undefined): Promise<boolean> {
    const entry = this.bound.get(sessionId)
    if (entry === undefined) return false
    // Remove old composite key
    const oldKey = compositeKey(entry.target, entry.threadAnchor)
    this.byTarget.delete(oldKey)
    // Update anchor
    entry.threadAnchor = anchor
    // Insert new composite key
    const newKey = compositeKey(entry.target, anchor)
    this.byTarget.set(newKey, sessionId)
    await this.persist({ sessionMirrors: { [sessionId]: serializeMirrorEntry(entry.target, anchor) } }).catch((error: unknown) => {
      this.report(`lark-channel: persisting the thread anchor failed: ${String(error)}`)
    })
    return true
  }
}

// ── Card rendering helpers ──

/** Max characters for user prompt text in a card before truncation. */
const PROMPT_CARD_TEXT_MAX = 2000

/**
 * Build a Feishu interactive card v2 for a mirrored user prompt.
 * @param turnNo - the turn number (1-based).
 * @param text - the user's prompt text.
 * @returns a card object suitable for `send(target, { card })`.
 */
export function mirrorPromptCard(turnNo: number, text: string): object {
  const shown = text.length <= PROMPT_CARD_TEXT_MAX ? text : text.slice(0, PROMPT_CARD_TEXT_MAX) + '…'
  return {
    schema: '2.0',
    header: {
      title: { tag: 'plain_text', content: `🙋 提问 · 第 ${turnNo} 轮` },
      template: 'blue',
    },
    body: {
      elements: [{ tag: 'markdown', content: shown }],
    },
  }
}

/**
 * Build a Feishu interactive card v2 for a mirror error.
 * @param detail - the error detail text.
 * @returns a card object suitable for `send(target, { card })`.
 */
export function mirrorErrorCard(detail: string): object {
  return {
    schema: '2.0',
    header: {
      title: { tag: 'plain_text', content: '⚠️ 本轮出错' },
      template: 'red',
    },
    body: {
      elements: [{ tag: 'markdown', content: detail || '未知错误' }],
    },
  }
}

/**
 * Build a Feishu interactive card v2 for the session root anchor.
 * @param sessionId - the GUI session id.
 * @param cwd - the session's working directory.
 * @param groupName - the group chat name.
 * @param title - optional session title for the topic heading.
 * @returns a card object suitable for `send(target, { card })`.
 */
export function mirrorRootCard(sessionId: string, cwd: string, groupName: string, title?: string): object {
  const heading = title ? '🔗 ' + title : '🔗 DSH · ' + sessionId.slice(0, 8)
  return {
    schema: '2.0',
    header: {
      title: { tag: 'plain_text', content: heading },
      template: 'turquoise',
    },
    body: {
      elements: [{
        tag: 'markdown',
        content: [
          `**会话 ID**：${sessionId}`,
          `**工作区**：${cwd}`,
          `**群聊**：${groupName}`,
          '',
          '此话题下的消息会驱动该 GUI 会话，会话的对话将转发到此处。',
        ].join('\n'),
      }],
    },
  }
}

/**
 * Build a Feishu interactive card v2 summarizing historical user prompts.
 * @param items - the prompt lines (already truncated/numbered by the caller).
 * @param total - total number of user prompts in the session.
 * @returns a card object suitable for `send(target, { card })`.
 */
export function mirrorHistoryCard(items: string[], total: number): object {
  const header = total > items.length
    ? `（共 ${total} 条，显示最近 ${items.length} 条）`
    : ''
  const body = [header, ...items].filter(line => line !== '').join('\n')
  return {
    schema: '2.0',
    header: {
      title: { tag: 'plain_text', content: '📜 历史提问' },
      template: 'indigo',
    },
    body: {
      elements: [{ tag: 'markdown', content: body }],
    },
  }
}

/**
 * Build a Feishu interactive card v2 for an assistant reply chunk.
 * No header (minimal); body is a single markdown element for rich rendering.
 * @param text - the markdown content (one chunk).
 * @returns a card object suitable for `send(target, { card })`.
 */
export function mirrorReplyCard(text: string): object {
  return {
    schema: '2.0',
    body: {
      elements: [{ tag: 'markdown', content: text }],
    },
  }
}

/**
 * Build a Feishu interactive card v2 showing an ask_user_question call.
 * The mirror cannot intercept the GUI session's question tool, so the card
 * is informational with a note to answer in the GUI.
 * @param questions - parsed question objects from the tool arguments.
 * @returns a card object suitable for `send(target, { card })`.
 */
export function mirrorAskCard(questions: readonly { question: string; options?: readonly { label: string }[] }[]): object {
  const lines: string[] = []
  for (const q of questions) {
    lines.push('**' + q.question + '**')
    if (q.options !== undefined && q.options.length > 0) {
      for (const opt of q.options) lines.push('- ' + opt.label)
    }
    lines.push('')
  }
  lines.push('---')
  lines.push('*👉 请回 GUI 作答*')
  return {
    schema: '2.0',
    header: {
      title: { tag: 'plain_text', content: '❓ Agent 提问' },
      template: 'orange',
    },
    body: {
      elements: [{ tag: 'markdown', content: lines.join('\n') }],
    },
  }
}

/**
 * Render a command invocation start as a one-line activity notice.
 * @param name - the slash command name (without leading `/`).
 * @param args - the raw input following the command name, when recorded.
 * @returns one bounded markdown line.
 */
export function commandRunMarkdown(name: string, args: string | undefined): string {
  if (args === undefined || args.trim() === '') return `⚡ \`/${name}\``
  const brief = args.replace(/[\s`]+/g, ' ').trim()
  const shown = brief.length <= 240 ? brief : `${brief.slice(0, 239)}…`
  return `⚡ \`/${name}\` ${shown}`
}

/**
 * Render a command invocation result as a one-line activity notice.
 * @param name - the slash command name (paired from the run event).
 * @param kind - whether the command succeeded or failed.
 * @param text - the handler's result text, when any.
 * @returns one bounded markdown line.
 */
export function commandDoneMarkdown(name: string, kind: 'success' | 'error', text: string | undefined): string {
  const icon = kind === 'error' ? '❌' : '✅'
  if (text === undefined || text.trim() === '') return `${icon} \`/${name}\` ${kind}`
  const brief = text.replace(/[\s`]+/g, ' ').trim()
  const shown = brief.length <= 240 ? brief : `${brief.slice(0, 239)}…`
  return `${icon} \`/${name}\` ${shown}`
}

/** Send options for thread-routed mirror messages. */
export interface MirrorSendOptions {
  readonly replyTo?: string
  readonly replyInThread?: boolean
}

/** The input type the forwarder sends: either markdown or a card. */
export type MirrorSendInput = { markdown: string } | { card: object }

/** The outbound half of the transport, as the forwarder uses it. */
export interface MirrorForwardPort {
  send(target: string, input: MirrorSendInput, opts?: MirrorSendOptions): Promise<void>
}

/** Construction options for {@link MirrorForwarder}. */
export interface MirrorForwarderOptions {
  /** Where rendered chunks go. */
  readonly port: MirrorForwardPort
  /** Reads the live binding for one session id, or undefined. */
  readonly binding: (sessionId: string) => MirrorBinding | undefined
  /** Chunk limit for {@link splitMarkdown}; defaults to {@link MIRROR_CHUNK_MAX}. */
  readonly chunkMax?: number | undefined
  /** Receives a failed send; the chain itself continues. */
  readonly onError?: ((error: unknown) => void) | undefined
}

/** Build MirrorSendOptions from an optional thread anchor. */
function threadOpts(anchor: ThreadAnchor | undefined): MirrorSendOptions | undefined {
  if (anchor === undefined) return undefined
  return { replyTo: anchor.messageId, replyInThread: true }
}

/**
 * Renders one mirrored session's events into cards and markdown. User prompts
 * become cards with turn numbers; assistant final replies are plain markdown
 * (split into chunks); errors become error cards; tool calls (verbose) stay
 * as markdown lines. Sends are serialized so chunks never arrive out of order.
 */
export class MirrorForwarder {
  private readonly port: MirrorForwardPort
  private readonly binding: (sessionId: string) => MirrorBinding | undefined
  private readonly chunkMax: number
  private readonly onError: (error: unknown) => void
  /** Last assistant text per session's live turn; flushed at turn/end. */
  private readonly pending = new Map<string, string>()
  /** Per-session turn counter (incremented on turn/start). */
  private readonly turnCount = new Map<string, number>()
  /** Command name by commandId, for pairing run → done events. */
  private readonly commandNames = new Map<string, string>()
  /** Serialized outbound chain; one failing send must not stop the rest. */
  private chain: Promise<void> = Promise.resolve()

  constructor(options: MirrorForwarderOptions) {
    this.port = options.port
    this.binding = options.binding
    this.chunkMax = options.chunkMax ?? MIRROR_CHUNK_MAX
    this.onError = options.onError ?? (() => {})
  }

  /** The current turn number for a session (0 when no turn has started). */
  turnOf(sessionId: string): number {
    return this.turnCount.get(sessionId) ?? 0
  }

  /**
   * Handle one session event of a possibly-mirrored session.
   * @param sessionId - the session the event belongs to.
   * @param event - the appended event, exactly as recorded.
   */
  handle(sessionId: string, event: HostSessionEvent): void {
    const binding = this.binding(sessionId)
    if (binding === undefined) return
    const opts = threadOpts(binding.threadAnchor)
    if (isTurnStartEvent(event)) {
      this.pending.set(sessionId, '')
      this.turnCount.set(sessionId, (this.turnCount.get(sessionId) ?? 0) + 1)
    } else if (isUserMessageEvent(event)) {
      // Only direct human prompts mirror; synthetic injections (file-change
      // notices, goal rounds) stay in the GUI. The stamped id keeps an
      // injected Lark message from being echoed back to the chat it came from.
      if (event.data.source !== undefined && event.data.source.kind !== 'user') return
      if (isMirrorInjectedId(event.data.id)) return
      const text = mirrorUserText(event.data.content)
      if (text !== '') {
        const turnNo = this.turnCount.get(sessionId) ?? 1
        this.sendInput(binding.target, { card: mirrorPromptCard(turnNo, text) }, opts)
      }
    } else if (isAssistantMessageEvent(event)) {
      // Each step commits one message; the last before turn/end is the final
      // reply, which is what a mirror reader wants rather than every step.
      const text = assistantText(event.data)
      if (text !== '') this.pending.set(sessionId, text)
    } else if (isToolCallEvent(event)) {
      // ask_user_question calls always render as an informational card
      if (event.data.name === 'ask_user_question') {
        try {
          const parsed = JSON.parse(event.data.arguments) as { questions?: readonly { question: string; options?: readonly { label: string }[] }[] }
          if (parsed.questions !== undefined && parsed.questions.length > 0) {
            this.sendInput(binding.target, { card: mirrorAskCard(parsed.questions) }, opts)
          }
        } catch { /* malformed JSON: skip */ }
        return
      }
      if (!binding.verbose) return
      this.sendMarkdown(binding.target, toolCallMarkdown(event.data.name, event.data.arguments), opts)
    } else if (isCommandRunEvent(event)) {
      if (!binding.verbose) return
      this.commandNames.set(event.data.commandId, event.data.name)
      this.sendMarkdown(binding.target, commandRunMarkdown(event.data.name, event.data.args), opts)
    } else if (isCommandDoneEvent(event)) {
      if (!binding.verbose) return
      const name = this.commandNames.get(event.data.commandId) ?? 'unknown'
      this.commandNames.delete(event.data.commandId)
      this.sendMarkdown(binding.target, commandDoneMarkdown(name, event.data.kind, event.data.text), opts)
    } else if (isTurnEndEvent(event)) {
      const final = this.pending.get(sessionId)
      this.pending.delete(sessionId)
      if (final !== undefined && final !== '') {
        this.sendReplyCards(binding.target, final, opts)
      } else {
        const detail = turnErrorDetail(event.data)
        if (detail !== '') this.sendInput(binding.target, { card: mirrorErrorCard(detail) }, opts)
      }
    }
  }

  /** Await every send queued so far; tests read the fake port after this. */
  flush(): Promise<void> {
    return this.chain
  }

  /** Send a card or single markdown input (no chunking). */
  private sendInput(target: string, input: MirrorSendInput, opts?: MirrorSendOptions): void {
    this.chain = this.chain
      .then(() => this.port.send(target, input, opts))
      .catch((error: unknown) => { this.onError(error) })
  }

  /** Send markdown, splitting into chunks per chunkMax. */
  private sendMarkdown(target: string, markdown: string, opts?: MirrorSendOptions): void {
    for (const chunk of splitMarkdown(markdown, this.chunkMax)) {
      this.chain = this.chain
        .then(() => this.port.send(target, { markdown: chunk }, opts))
        .catch((error: unknown) => { this.onError(error) })
    }
  }

  /** Send assistant reply as card(s), splitting into chunks per chunkMax. */
  private sendReplyCards(target: string, text: string, opts?: MirrorSendOptions): void {
    for (const chunk of splitMarkdown(text, this.chunkMax)) {
      this.chain = this.chain
        .then(() => this.port.send(target, { card: mirrorReplyCard(chunk) }, opts))
        .catch((error: unknown) => { this.onError(error) })
    }
  }
}
