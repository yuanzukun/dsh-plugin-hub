/**
 * Mirror-side question answering: subscribes to the host's SSE mux stream,
 * watches for question/requested frames targeting mirrored sessions, renders
 * interactive Feishu cards with action buttons, and POSTs the answer back
 * through /api/respond when a button is clicked.
 * @module dsh-lark-channel/mirror-questions
 */

import type { MirrorBindings, MirrorSendOptions, ThreadAnchor } from './mirror.ts'

/** Card action prefix identifying mirror-question button clicks and dropdown picks. */
export const MIRROR_QUESTION_ACTION = 'dsh-lark-channel/mirror-question'

/**
 * Options up to this count render as one button each; beyond it a single
 * `select_static` dropdown carries them all. Buttons answer in one tap, but
 * each button is a standalone card element and Feishu rejects cards whose
 * element count exceeds its per-card limits (ErrCode 11310), which a
 * many-option question (e.g. a model picker) would trip.
 */
export const MAX_OPTION_BUTTONS = 6

/** Feishu's `select_static` option-count ceiling; beyond it the card degrades to a GUI pointer. */
export const SELECT_OPTION_LIMIT = 100

/**
 * Payload carried by each mirror question control. A button carries its
 * `label`; a `select_static` dropdown shares one payload across options, so
 * `label` is absent and the picked option index arrives as the card action's
 * `option` field instead.
 */
export interface MirrorQuestionActionValue {
  readonly kind: typeof MIRROR_QUESTION_ACTION
  readonly actionId: string
  readonly questionId: string
  readonly label?: string
}

/**
 * Narrow one card action value to a mirror-question button click or dropdown pick.
 * @param value - raw action.value from a CardActionEvent.
 * @returns the typed payload, or undefined for unrelated actions.
 */
export function mirrorQuestionActionValue(value: unknown): MirrorQuestionActionValue | undefined {
  if (typeof value !== 'object' || value === null) return undefined
  const record = value as Record<string, unknown>
  if (record.kind !== MIRROR_QUESTION_ACTION) return undefined
  if (typeof record.actionId !== 'string') return undefined
  if (typeof record.questionId !== 'string') return undefined
  if (record.label !== undefined && typeof record.label !== 'string') return undefined
  return record as unknown as MirrorQuestionActionValue
}

/** One question from the host SSE frame. */
export interface MirrorQuestion {
  readonly id: string
  readonly question: string
  readonly header?: string
  readonly options?: readonly { readonly label: string; readonly description?: string }[]
  readonly multiSelect?: boolean
  /** Supporting detail rendered with the question (e.g. plan markdown). */
  readonly detail?: string
  /** Presentation intent; a UI that recognises the tag presents accordingly. */
  readonly intent?: { readonly kind: string; readonly approve: string }
}

/** Pending question record, tracked between card send and button click. */
interface PendingMirrorQuestion {
  readonly rpcId: string
  readonly sessionId: string
  readonly questions: readonly MirrorQuestion[]
}

/** Max characters for the plan detail summary in a plan-review card. */
const PLAN_DETAIL_SUMMARY_MAX = 800

/**
 * Extract the first few meaningful lines from a plan markdown as a summary.
 * @param detail - the full plan markdown.
 * @returns a truncated summary, or the full text when short enough.
 */
function planDetailSummary(detail: string): string {
  if (detail.length <= PLAN_DETAIL_SUMMARY_MAX) return detail
  return detail.slice(0, PLAN_DETAIL_SUMMARY_MAX) + '…'
}

/**
 * Extract http(s) URLs from text and return them as clickable markdown links.
 * @param text - the text to scan.
 * @returns markdown links, one per URL found.
 */
function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/[^\s)>\]]+/g
  const urls = [...new Set(text.match(urlRegex) ?? [])]
  return urls.map(url => `[${url}](${url})`)
}

/**
 * Build a Feishu interactive card v2 for a plan-review question.
 * Shows the plan heading, a summary of the detail, any URLs as clickable
 * links, and Approve / Keep Planning buttons.
 * @param question - the plan-review question with intent and detail.
 * @param actionId - correlation id linking controls back to the pending entry.
 * @returns the card object.
 */
export function mirrorPlanReviewCard(question: MirrorQuestion, actionId: string): object {
  const heading = question.header || '📋 计划待确认'
  const elements: object[] = []

  // Show the question text
  elements.push({ tag: 'markdown', content: question.question })

  // Show a summary of the plan detail
  if (question.detail !== undefined && question.detail !== '') {
    const summary = planDetailSummary(question.detail)
    elements.push({ tag: 'markdown', content: summary })

    // Extract and show clickable URLs from the detail
    const urls = extractUrls(question.detail)
    if (urls.length > 0) {
      elements.push({ tag: 'markdown', content: '**链接**：\n' + urls.join('\n') })
    }
  }

  elements.push({ tag: 'hr' })

  // Buttons: Approve and Keep Planning
  const approveLabel = question.intent?.approve ?? 'Approve'
  if (question.options !== undefined && question.options.length > 0) {
    for (const opt of question.options) {
      const isPrimary = opt.label === approveLabel
      elements.push({
        tag: 'button',
        text: { tag: 'plain_text', content: opt.label },
        type: isPrimary ? 'primary_filled' : 'default',
        width: 'default',
        behaviors: [{ type: 'callback', value: {
          kind: MIRROR_QUESTION_ACTION,
          actionId,
          questionId: question.id,
          label: opt.label,
        } satisfies MirrorQuestionActionValue }],
      })
    }
  }

  // GUI fallback note
  elements.push({ tag: 'markdown', content: '*👉 也可回 GUI 处理*' })

  return {
    schema: '2.0',
    header: {
      title: { tag: 'plain_text', content: '📋 ' + heading },
      template: 'violet',
    },
    body: { elements },
  }
}

/**
 * Build an interactive Feishu card v2 for a mirror question.
 * Single-select questions get one button per option up to
 * {@link MAX_OPTION_BUTTONS}, then one `select_static` dropdown up to
 * {@link SELECT_OPTION_LIMIT}, then an informational GUI pointer; multi-select
 * always degrades to informational (buttons cannot natively support multiple
 * selections).
 * @param questions - the host's question list.
 * @param actionId - correlation id linking controls back to the pending entry.
 * @returns the card object.
 */
export function mirrorQuestionCard(questions: readonly MirrorQuestion[], actionId: string): object {
  const elements: object[] = []
  let needsGui = false
  for (const q of questions) {
    if (q.header) {
      elements.push({ tag: 'markdown', content: '**' + q.header + '**' })
    }
    elements.push({ tag: 'markdown', content: q.question })
    if (q.multiSelect) {
      needsGui = true
      elements.push({ tag: 'markdown', content: '*多选题，请回 GUI 作答*' })
    } else if (q.options !== undefined && q.options.length > 0) {
      if (q.options.length <= MAX_OPTION_BUTTONS) {
        for (const opt of q.options) {
          elements.push({
            tag: 'button',
            text: { tag: 'plain_text', content: opt.label },
            type: 'primary_filled',
            width: 'default',
            behaviors: [{ type: 'callback', value: {
              kind: MIRROR_QUESTION_ACTION,
              actionId,
              questionId: q.id,
              label: opt.label,
            } satisfies MirrorQuestionActionValue }],
          })
        }
      } else if (q.options.length <= SELECT_OPTION_LIMIT) {
        elements.push({
          tag: 'select_static',
          placeholder: { tag: 'plain_text', content: `选择一项（共 ${q.options.length} 个选项）` },
          width: 'fill',
          options: q.options.map((opt, index) => ({
            text: { tag: 'plain_text', content: opt.label },
            value: String(index),
          })),
          behaviors: [{ type: 'callback', value: {
            kind: MIRROR_QUESTION_ACTION,
            actionId,
            questionId: q.id,
          } satisfies MirrorQuestionActionValue }],
        })
      } else {
        needsGui = true
        elements.push({ tag: 'markdown', content: `*选项过多（${q.options.length} 个），请回 GUI 作答*` })
      }
    }
  }
  if (needsGui) {
    elements.push({ tag: 'markdown', content: '---\n*👉 请回 GUI 作答*' })
  }
  return {
    schema: '2.0',
    header: {
      title: { tag: 'plain_text', content: '❓ Agent 提问' },
      template: 'green',
    },
    body: { elements },
  }
}

/**
 * Resolve a `select_static` pick back to its option label.
 * @param question - the question the pick answers.
 * @param option - the card action's `option` field: the option index this
 *   bridge assigned as the dropdown option's value.
 * @returns the picked label, or undefined when the index does not resolve.
 */
function optionLabel(question: MirrorQuestion, option: string | undefined): string | undefined {
  if (option === undefined || question.options === undefined) return undefined
  if (!/^\d+$/.test(option)) return undefined
  return question.options[Number(option)]?.label
}

/**
 * Build the settled (answered) version of a mirror question card.
 * @param selectedLabel - what the user chose.
 * @returns the card to replace the original with.
 */
export function settledMirrorQuestionCard(selectedLabel: string): object {
  return {
    schema: '2.0',
    header: {
      title: { tag: 'plain_text', content: '✅ 已回答' },
      template: 'green',
    },
    body: {
      elements: [{ tag: 'markdown', content: '选择：**' + selectedLabel + '**' }],
    },
  }
}

/** Port surface for the question bridge's outbound sends. */
export interface MirrorQuestionPort {
  send(target: string, input: { card: object }, opts?: MirrorSendOptions): Promise<{ messageId: string }>
  updateCard(messageId: string, card: object): Promise<void>
}

/** Options for {@link MirrorQuestionBridge}. */
export interface MirrorQuestionBridgeOptions {
  readonly port: MirrorQuestionPort
  readonly mirrors: MirrorBindings
  readonly notify: (line: string) => void
  /** Override the host URL (for testing). Defaults to http://127.0.0.1:3080. */
  readonly hostUrl?: string
}

/**
 * Bridges the host's SSE question events to interactive Feishu cards.
 * Subscribes to /api/events.mux, watches for question/requested targeting
 * mirrored sessions, sends interactive cards, and answers via /api/respond.
 */
export class MirrorQuestionBridge {
  private readonly port: MirrorQuestionPort
  private readonly mirrors: MirrorBindings
  private readonly notify: (line: string) => void
  private readonly hostUrl: string
  private readonly pending = new Map<string, PendingMirrorQuestion & { messageId?: string }>()
  private socket: WebSocket | null = null
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null
  private connected = false

  constructor(options: MirrorQuestionBridgeOptions) {
    this.port = options.port
    this.mirrors = options.mirrors
    this.notify = options.notify
    this.hostUrl = options.hostUrl ?? 'http://127.0.0.1:3080'
  }

  /** Whether the WebSocket connection is active. */
  get isConnected(): boolean {
    return this.connected
  }

  /** Start listening to the host WebSocket stream. */
  connect(): void {
    if (this.connected) return
    this.connected = true
    this.openSocket()
  }

  /** Stop listening and clean up. */
  disconnect(): void {
    this.connected = false
    if (this.reconnectTimer !== null) {
      clearTimeout(this.reconnectTimer)
      this.reconnectTimer = null
    }
    if (this.socket !== null) {
      this.socket.close()
      this.socket = null
    }
    this.pending.clear()
  }

  /**
   * Handle a card action that may be a mirror-question button click or
   * dropdown pick.
   * @param value - the parsed MirrorQuestionActionValue.
   * @param option - the card action's `option` field: for a `select_static`
   *   pick, the chosen option's value (the option index this bridge assigned);
   *   undefined for button clicks.
   * @returns the card response (toast + updated card), or undefined if not ours.
   */
  async handleAction(
    value: MirrorQuestionActionValue,
    option?: string,
  ): Promise<{ toast: object; card?: object } | undefined> {
    const entry = this.pending.get(value.actionId)
    if (entry === undefined) return { toast: { type: 'info', content: '问题已过期' } }
    // Find the question being answered
    const question = entry.questions.find(q => q.id === value.questionId)
    if (question === undefined) return { toast: { type: 'error', content: '问题 ID 不匹配' } }
    const label = value.label ?? optionLabel(question, option)
    if (label === undefined) return { toast: { type: 'error', content: '选项无法识别' } }
    // Build the answer payload
    const answerPayload = {
      type: 'client-response' as const,
      rpcId: entry.rpcId,
      result: {
        ok: true,
        value: {
          sessionId: entry.sessionId,
          answer: {
            answers: [{ id: value.questionId, selected: [label] }],
          },
        },
      },
    }
    // POST to /api/respond
    try {
      const response = await fetch(this.hostUrl + '/api/respond', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(answerPayload),
      })
      if (!response.ok) {
        this.notify('lark-channel: mirror-question respond failed: HTTP ' + response.status)
      }
    } catch (error) {
      this.notify('lark-channel: mirror-question respond failed: ' + String(error))
    }
    // Update the card to settled state
    const settledCard = settledMirrorQuestionCard(label)
    if (entry.messageId !== undefined) {
      void this.port.updateCard(entry.messageId, settledCard).catch(() => {})
    }
    this.pending.delete(value.actionId)
    return {
      toast: { type: 'success', content: '已回答' },
      card: { type: 'raw', data: settledCard },
    }
  }

  /** Internal: open one WebSocket connection with auto-reconnect on close/error. */
  private openSocket(): void {
    const wsUrl = this.hostUrl.replace(/^http/, 'ws') + '/api/events.mux'
    const socket = new WebSocket(wsUrl)
    this.socket = socket

    socket.addEventListener('message', (event) => {
      this.handleFrame(String(event.data))
    })

    socket.addEventListener('close', () => {
      if (!this.connected) return
      this.notify('lark-channel: mirror-question WebSocket closed, reconnecting in 5s')
      this.scheduleReconnect()
    })

    socket.addEventListener('error', () => {
      // error is always followed by close; avoid double-reconnect
      if (socket.readyState === WebSocket.CLOSED) return
      socket.close()
    })
  }

  /** Internal: schedule a reconnect after a delay. */
  private scheduleReconnect(): void {
    if (!this.connected) return
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null
      if (this.connected) this.openSocket()
    }, 5000)
  }

  /** Internal: process one WebSocket message (JSON string). */
  private handleFrame(data: string): void {
    try {
      const msg = JSON.parse(data) as {
        rpcId?: string
        payload?: { type?: string; sessionId?: string; questions?: MirrorQuestion[] }
      }
      if (msg.payload?.type === 'question/requested' && msg.rpcId && msg.payload.sessionId) {
        this.handleQuestionRequested(msg.rpcId, msg.payload.sessionId, msg.payload.questions ?? [])
      }
    } catch { /* malformed JSON: skip */ }
  }

  /** Internal: a question arrived for a possibly-mirrored session. */
  private handleQuestionRequested(rpcId: string, sessionId: string, questions: readonly MirrorQuestion[]): void {
    if (!this.mirrors.isBound(sessionId)) return
    if (questions.length === 0) return
    const binding = this.mirrors.bindingFor(sessionId)
    if (binding === undefined) return
    const actionId = Math.random().toString(36).slice(2) + Date.now().toString(36)
    // Plan-review questions get a specialized card; all others use the generic card.
    const isPlanReview = questions.length === 1
      && questions[0]!.intent?.kind === 'plan-review'
    const card = isPlanReview
      ? mirrorPlanReviewCard(questions[0]!, actionId)
      : mirrorQuestionCard(questions, actionId)
    const opts = binding.threadAnchor !== undefined
      ? { replyTo: binding.threadAnchor.messageId, replyInThread: true }
      : undefined
    const entry: PendingMirrorQuestion & { messageId?: string } = { rpcId, sessionId, questions }
    this.pending.set(actionId, entry)
    void this.port.send(binding.target, { card }, opts).then(result => {
      entry.messageId = result.messageId
    }).catch((error: unknown) => {
      this.notify('lark-channel: mirror-question card send failed: ' + String(error))
      this.pending.delete(actionId)
    })
  }
}
