/**
 * Inbound group-message serving: which messages may reach an agent.
 *
 * The transport's own `requireMention` filter is lifted while
 * `mentionFreeFollowUp` is on, so the whole mention decision lives here in
 * the bridge, where the conversation's session bindings are visible. The
 * decision itself is pure — the binding test is injected — so tests drive it
 * without an agent or a Lark connection.
 * @module dsh-lark-channel/mention
 */

import type { NormalizedMessage } from '@larksuite/channel'

/** The deployed mention policy; the bridge fills these from resolved configuration. */
export interface MentionPolicy {
  /** In group chats, only messages that @ the bot are served. */
  readonly requireMention: boolean
  /**
   * Also serve an unmentioned message when it sits inside a topic thread whose
   * conversation already has a bound session. Off keeps mention-only groups.
   */
  readonly mentionFreeFollowUp: boolean
}

/** The policy plus the one live-state look the decision needs, injected. */
export interface MentionState extends MentionPolicy {
  /**
   * Whether one conversation key currently has a bound session. The bridge
   * reads {@link ConversationSessions}' opened map: a topic with a session
   * opened this process qualifies; a topic nobody has spoken to (or spoken to
   * only before a restart) does not, so its first message still needs the @.
   * @param key - the conversation key, from `conversationKey(scope, msg)`.
   * @returns true when a session is bound for the key.
   */
  readonly bound: (key: string) => boolean
}

/**
 * Decide whether one inbound message may reach its conversation's agent.
 *
 * Direct messages always may — they never need the @. Group messages need to
 * name the bot (`mentionedBot` set by the transport's normalizer) unless the
 * deployment exempts follow-ups in a bound topic thread: then an unmentioned
 * message with a `threadId` whose conversation key has a bound session is
 * served too. Everything else is refused: a group-level message, a message in
 * a topic nobody has opened, and an @-all mention — which the transport's
 * `requireMention` policy also refused, since @-all does not set
 * `mentionedBot`. Bot-sent messages take the same gate; their hop budget is
 * judged downstream, exactly as before.
 * @param msg - the normalized inbound chat message.
 * @param key - the message's conversation key, from `conversationKey`.
 * @param state - the deployed policy and the binding test.
 * @returns true when the message may drive the conversation's agent.
 */
export function shouldServe(msg: NormalizedMessage, key: string, state: MentionState): boolean {
  if (msg.chatType === 'p2p') return true
  // @-all names everyone and no one: the transport refuses it under the same
  // policy (its mention-all block stays on even while requireMention is
  // lifted), so it must not slip in through the follow-up exemption either.
  if (msg.mentionAll) return false
  if (!state.requireMention) return true
  if (msg.mentionedBot) return true
  return state.mentionFreeFollowUp && msg.threadId !== undefined && state.bound(key)
}
