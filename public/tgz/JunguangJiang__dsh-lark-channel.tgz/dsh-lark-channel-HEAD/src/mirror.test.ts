/**
 * Tests for the session-mirror state machine and renderer: subcommand
 * parsing, chunking, the binding table (displacement included), and the
 * forwarder's event handling against a minimal fake port. The Feishu SDK
 * is never mocked; the bridge's own wiring is exercised through these seams.
 */
import { describe, expect, it } from 'vitest'
import type { HostSessionEvent } from './host.ts'
import {
  isMirrorInjectedId,
  LARK_COMMAND,
  MIRROR_UNBOUND,
  MirrorBindings,
  MirrorForwarder,
  mirrorAskCard,
  mirrorErrorCard,
  mirrorHistoryCard,
  mirrorMessageId,
  mirrorPromptCard,
  mirrorReplyCard,
  mirrorRootCard,
  mirrorTargetKind,
  mirrorTargetKindLabel,
  parseMirrorInput,
  splitMarkdown,
  toolCallMarkdown,
  commandRunMarkdown,
  commandDoneMarkdown,
  compileTriggerPhrases,
  matchTriggerPhrase,
  userMarkdown,
  assistantMarkdown,
} from './mirror.ts'
import type { MirrorSendInput } from './mirror.ts'

/** One event-shaped value for the forwarder; the guards narrow by type alone. */
const ev = (type: string, data: unknown): HostSessionEvent => ({ type, data })

/** A user/message event as the host session store publishes it. */
const userEvent = (id: string, text: string, source = 'user'): HostSessionEvent =>
  ev('user/message', { id, role: 'user', content: [{ type: 'text', text }], source: { kind: source } })

/** A committed assistant message event for one step. */
const assistantEvent = (text: string): HostSessionEvent =>
  ev('assistant/message', { turn: 1, message: { content: [{ type: 'text', text }] } })

/** A tool-call event with the model's raw arguments JSON. */
const toolEvent = (name: string, argumentsJson: string): HostSessionEvent =>
  ev('tool/call', { turn: 1, callId: 'c1', name, arguments: argumentsJson })

describe('parseMirrorInput', () => {
  it('空输入与 on 都开启', () => {
    expect(parseMirrorInput('')).toEqual({ kind: 'on' })
    expect(parseMirrorInput('   ')).toEqual({ kind: 'on' })
    expect(parseMirrorInput('on')).toEqual({ kind: 'on' })
  })

  it('on 可携带目标', () => {
    expect(parseMirrorInput('on oc_abc')).toEqual({ kind: 'on', target: 'oc_abc' })
    expect(parseMirrorInput('on to ou_xyz')).toEqual({ kind: 'on', target: 'ou_xyz' })
    expect(parseMirrorInput('on to')).toEqual({ kind: 'error', reason: expect.any(String) })
    expect(parseMirrorInput('on a b c')).toEqual({ kind: 'error', reason: expect.any(String) })
  })

  it('to 指定目标并校验参数个数', () => {
    expect(parseMirrorInput('to oc_abc')).toEqual({ kind: 'to', target: 'oc_abc' })
    expect(parseMirrorInput('to')).toEqual({ kind: 'error', reason: expect.any(String) })
    expect(parseMirrorInput('to oc_a ou_b')).toEqual({ kind: 'error', reason: expect.any(String) })
  })

  it('off 与 status 不接受参数', () => {
    expect(parseMirrorInput('off')).toEqual({ kind: 'off' })
    expect(parseMirrorInput('off now')).toEqual({ kind: 'error', reason: expect.any(String) })
    expect(parseMirrorInput('status')).toEqual({ kind: 'status' })
    expect(parseMirrorInput('status all')).toEqual({ kind: 'error', reason: expect.any(String) })
  })

  it('verbose on|off', () => {
    expect(parseMirrorInput('verbose on')).toEqual({ kind: 'verbose', value: true })
    expect(parseMirrorInput('verbose off')).toEqual({ kind: 'verbose', value: false })
    expect(parseMirrorInput('verbose')).toEqual({ kind: 'error', reason: expect.any(String) })
    expect(parseMirrorInput('verbose yes')).toEqual({ kind: 'error', reason: expect.any(String) })
  })

  it('未知子命令是错误', () => {
    expect(parseMirrorInput('bogus')).toEqual({ kind: 'error', reason: expect.stringContaining('bogus') })
  })
})

describe('splitMarkdown', () => {
  it('空文本没有分段', () => {
    expect(splitMarkdown('')).toEqual([])
    expect(splitMarkdown('\n\n')).toEqual([])
  })

  it('短文本单段', () => {
    expect(splitMarkdown('hello', 10)).toEqual(['hello'])
  })

  it('按行打包到上限', () => {
    expect(splitMarkdown('aaaa\nbbbb\ncccccc', 10)).toEqual(['aaaa\nbbbb', 'cccccc'])
  })

  it('超长单行硬切且不丢字符', () => {
    const line = 'x'.repeat(45)
    const chunks = splitMarkdown(line, 10)
    expect(chunks).toHaveLength(5)
    for (const chunk of chunks) expect(chunk.length).toBeLessThanOrEqual(10)
    expect(chunks.join('')).toBe(line)
  })

  it('行边界切分后可按换行还原', () => {
    const text = ['alpha', 'beta', 'gamma', 'delta'].join('\n')
    const chunks = splitMarkdown(text, 16)
    expect(chunks.join('\n')).toBe(text)
  })

  it('上限小于 1 时收敛为 1 而不是死循环', () => {
    expect(splitMarkdown('abc', 0)).toEqual(['a', 'b', 'c'])
  })
})

describe('mirrorMessageId / isMirrorInjectedId', () => {
  it('打标与识别', () => {
    const id = mirrorMessageId()
    expect(id.startsWith('lark-mirror-')).toBe(true)
    expect(isMirrorInjectedId(id)).toBe(true)
    expect(isMirrorInjectedId('some-other-id')).toBe(false)
    expect(isMirrorInjectedId(undefined)).toBe(false)
    expect(mirrorMessageId()).not.toBe(id)
  })
})

describe('mirrorTargetKind', () => {
  it('按平台前缀分类', () => {
    expect(mirrorTargetKind('ou_1')).toBe('user')
    expect(mirrorTargetKind('oc_1')).toBe('chat')
    expect(mirrorTargetKind('on_1')).toBe('other')
    expect(mirrorTargetKindLabel('ou_1')).toContain('open_id')
    expect(mirrorTargetKindLabel('oc_1')).toContain('chat_id')
  })
})

describe('toolCallMarkdown', () => {
  it('空参数只留工具名', () => {
    expect(toolCallMarkdown('bash', '')).toBe('🔧 `bash`')
  })
  it('换行与反引号折叠为一行', () => {
    const line = toolCallMarkdown('bash', '{"cmd": "ls\n-a"}')
    expect(line).not.toContain('\n')
    expect(line).toContain('bash')
    expect(line).toContain('ls -a')
  })
  it('超长参数有界', () => {
    const line = toolCallMarkdown('bash', JSON.stringify({ blob: 'x'.repeat(500) }))
    expect(line.length).toBeLessThanOrEqual('🔧 `bash` '.length + 240)
  })
})

describe('MirrorBindings', () => {
  const persistPatch = (patches: object[]) => async (patch: object): Promise<boolean> => {
    patches.push(patch)
    return true
  }

  it('bind 建立正向与反查', async () => {
    const patches: object[] = []
    const mirrors = new MirrorBindings({ persist: persistPatch(patches) })
    const result = await mirrors.bind('s1', 'oc_a')
    expect(result).toEqual({ target: 'oc_a', durable: true, changed: true })
    expect(mirrors.targetOf('s1')).toBe('oc_a')
    expect(mirrors.isBound('s1')).toBe(true)
    expect(mirrors.bindingFor('s1')).toEqual({ sessionId: 's1', target: 'oc_a', verbose: false })
    expect(mirrors.sessionFor('oc_a')).toBe('s1')
    expect(mirrors.reverseLookup('oc_a')).toBe('s1')
    expect(mirrors.reverseLookup('other')).toBeUndefined()
    expect(patches).toEqual([{ sessionMirrors: { s1: 'oc_a' } }])
  })

  it('同一会话换目标后旧反查失效', async () => {
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_a')
    await mirrors.bind('s1', 'oc_b')
    expect(mirrors.sessionFor('oc_a')).toBeUndefined()
    expect(mirrors.sessionFor('oc_b')).toBe('s1')
    expect(mirrors.targetOf('s1')).toBe('oc_b')
  })

  it('重复绑定同一目标不算变更且不再持久化', async () => {
    const patches: object[] = []
    const mirrors = new MirrorBindings({ persist: persistPatch(patches) })
    await mirrors.bind('s1', ' oc_a ')
    const again = await mirrors.bind('s1', 'oc_a')
    expect(again).toEqual({ target: 'oc_a', durable: true, changed: false })
    expect(patches).toHaveLength(1)
  })

  it('新绑定顶掉旧会话，双方持久化为目标与空标记', async () => {
    const patches: object[] = []
    const mirrors = new MirrorBindings({ persist: persistPatch(patches) })
    await mirrors.bind('s1', 'oc_a')
    const displaced = await mirrors.bind('s2', 'oc_a')
    expect(displaced).toEqual({ target: 'oc_a', displacedSession: 's1', durable: true, changed: true })
    expect(mirrors.isBound('s1')).toBe(false)
    expect(mirrors.sessionFor('oc_a')).toBe('s2')
    expect(patches.at(-1)).toEqual({ sessionMirrors: { s2: 'oc_a', s1: MIRROR_UNBOUND } })
  })

  it('unbind 写空标记并清反查', async () => {
    const patches: object[] = []
    const mirrors = new MirrorBindings({ persist: persistPatch(patches) })
    await mirrors.bind('s1', 'oc_a')
    const closed = await mirrors.unbind('s1')
    expect(closed).toEqual({ removed: true, target: 'oc_a', durable: true })
    expect(mirrors.isBound('s1')).toBe(false)
    expect(mirrors.sessionFor('oc_a')).toBeUndefined()
    expect(patches.at(-1)).toEqual({ sessionMirrors: { s1: MIRROR_UNBOUND } })
    expect((await mirrors.unbind('s1')).removed).toBe(false)
  })

  it('恢复时跳过空标记，重复目标后者胜出', () => {
    const mirrors = new MirrorBindings({ entries: { s1: 'oc_a', s2: '', s3: 'oc_a' } })
    expect(mirrors.isBound('s1')).toBe(false)
    expect(mirrors.isBound('s2')).toBe(false)
    expect(mirrors.sessionFor('oc_a')).toBe('s3')
    expect(mirrors.list()).toHaveLength(1)
  })

  it('p2p 发件人回退：ou_ 目标的入站落在 p2p 会话里', async () => {
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'ou_xyz')
    expect(mirrors.reverseLookup('oc_p2p_chat', 'ou_xyz', 'p2p')).toBe('s1')
    expect(mirrors.reverseLookup('oc_p2p_chat', 'someone_else', 'p2p')).toBeUndefined()
    expect(mirrors.reverseLookup('oc_a', 'ou_xyz', 'group')).toBeUndefined()
  })

  it('persist 失败时报告且 durable 为假，只警告一次', async () => {
    const reports: string[] = []
    const mirrors = new MirrorBindings({ persist: async () => false, report: line => reports.push(line) })
    expect((await mirrors.bind('s1', 'oc_a')).durable).toBe(false)
    expect(mirrors.durable).toBe(false)
    await mirrors.bind('s1', 'oc_b')
    expect(reports.filter(line => line.includes('in-memory only'))).toHaveLength(1)
  })

  it('persist 抛错被吞并报告', async () => {
    const reports: string[] = []
    const mirrors = new MirrorBindings({
      persist: async () => { throw new Error('boom') },
      report: line => reports.push(line),
    })
    expect((await mirrors.bind('s1', 'oc_a')).durable).toBe(false)
    expect(reports.some(line => line.includes('boom'))).toBe(true)
  })

  it('verbose 翻转要求已绑定', async () => {
    const mirrors = new MirrorBindings()
    expect(mirrors.setVerbose('s1', true)).toEqual({ changed: false, bound: false })
    await mirrors.bind('s1', 'oc_a')
    expect(mirrors.setVerbose('s1', true)).toEqual({ changed: true, bound: true })
    expect(mirrors.verboseOf('s1')).toBe(true)
    expect(mirrors.setVerbose('s1', true)).toEqual({ changed: false, bound: true })
    expect(mirrors.setVerbose('s1', false)).toEqual({ changed: true, bound: true })
    expect(mirrors.verboseOf('s1')).toBe(false)
  })

  // ── Composite key tests (同群多 session) ──

  it('同群不同话题的两个 session 互不顶替', async () => {
    const mirrors = new MirrorBindings()
    const anchor1 = { messageId: 'm1', threadId: 't1' }
    const anchor2 = { messageId: 'm2', threadId: 't2' }
    await mirrors.bind('s1', 'oc_g', anchor1)
    await mirrors.bind('s2', 'oc_g', anchor2)
    // Both bound
    expect(mirrors.isBound('s1')).toBe(true)
    expect(mirrors.isBound('s2')).toBe(true)
    // Correct sessions for each composite key
    expect(mirrors.sessionFor('oc_g#t1')).toBe('s1')
    expect(mirrors.sessionFor('oc_g#t2')).toBe('s2')
  })

  it('同群同话题会顶替', async () => {
    const mirrors = new MirrorBindings()
    const anchor = { messageId: 'm1', threadId: 't1' }
    await mirrors.bind('s1', 'oc_g', anchor)
    const result = await mirrors.bind('s2', 'oc_g', anchor)
    expect(result.displacedSession).toBe('s1')
    expect(mirrors.isBound('s1')).toBe(false)
    expect(mirrors.isBound('s2')).toBe(true)
  })

  it('reverseLookup 按 threadId 命中各自 session', async () => {
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_g', { messageId: 'm1', threadId: 't1' })
    await mirrors.bind('s2', 'oc_g', { messageId: 'm2', threadId: 't2' })
    expect(mirrors.reverseLookup('oc_g', undefined, 'group', 't1')).toBe('s1')
    expect(mirrors.reverseLookup('oc_g', undefined, 'group', 't2')).toBe('s2')
    // Unknown thread doesn't match either anchored binding
    expect(mirrors.reverseLookup('oc_g', undefined, 'group', 't3')).toBeUndefined()
  })

  it('裸键（无 anchor）绑定不受 threadId 过滤', async () => {
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_g')  // no anchor
    // Matches any thread in oc_g
    expect(mirrors.reverseLookup('oc_g', undefined, 'group', 't_any')).toBe('s1')
    expect(mirrors.reverseLookup('oc_g', undefined, 'group', undefined)).toBe('s1')
  })

  it('setThreadAnchor 切换 composite key', async () => {
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_g', { messageId: 'm1', threadId: 't1' })
    expect(mirrors.sessionFor('oc_g#t1')).toBe('s1')
    await mirrors.setThreadAnchor('s1', { messageId: 'm2', threadId: 't2' })
    expect(mirrors.sessionFor('oc_g#t1')).toBeUndefined()
    expect(mirrors.sessionFor('oc_g#t2')).toBe('s1')
  })

  it('unbind 清理 composite key', async () => {
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_g', { messageId: 'm1', threadId: 't1' })
    await mirrors.unbind('s1')
    expect(mirrors.sessionFor('oc_g#t1')).toBeUndefined()
  })
})

describe('MirrorForwarder', () => {
  interface Sent { target: string; input: MirrorSendInput }
  const fakePort = (sent: Sent[], failOn?: (input: MirrorSendInput) => boolean) => ({
    send: async (target: string, input: MirrorSendInput): Promise<void> => {
      if (failOn?.(input)) throw new Error('send failed')
      sent.push({ target, input })
    },
  })

  const forwarder = async (sent: Sent[], verbose = false, opts: object = {}) => {
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_a')
    mirrors.setVerbose('s1', verbose)
    return new MirrorForwarder({
      port: fakePort(sent),
      binding: sessionId => mirrors.bindingFor(sessionId),
      ...opts,
    })
  }

  it('用户消息产出 card 输入', async () => {
    const sent: Sent[] = []
    const f = await forwarder(sent)
    f.handle('s1', ev('turn/start', { turn: 1 }))
    f.handle('s1', userEvent('m1', 'hello'))
    await f.flush()
    expect(sent).toHaveLength(1)
    expect(sent[0]!.target).toBe('oc_a')
    expect('card' in sent[0]!.input).toBe(true)
    const card = (sent[0]!.input as { card: object }).card as { header?: { title?: { content?: string } } }
    expect(card.header?.title?.content).toContain('第 1 轮')
  })

  it('未绑定会话的事件被忽略', async () => {
    const sent: Sent[] = []
    const f = await forwarder(sent)
    f.handle('s9', userEvent('m1', 'hello'))
    f.handle('s9', assistantEvent('answer'))
    await f.flush()
    expect(sent).toEqual([])
  })

  it('镜像注入的消息不回显（回环防护）', async () => {
    const sent: Sent[] = []
    const f = await forwarder(sent)
    f.handle('s1', ev('turn/start', { turn: 1 }))
    f.handle('s1', userEvent('lark-mirror-1', '从飞书来的'))
    await f.flush()
    expect(sent).toEqual([])
  })

  it('非人类来源的 user/message 不镜像', async () => {
    const sent: Sent[] = []
    const f = await forwarder(sent)
    f.handle('s1', ev('turn/start', { turn: 1 }))
    f.handle('s1', userEvent('m1', 'injected', 'inject'))
    f.handle('s1', userEvent('m2', 'human', 'user'))
    await f.flush()
    expect(sent).toHaveLength(1)
    expect('card' in sent[0]!.input).toBe(true)
  })

  it('助手回复产出 card 输入且长文分块', async () => {
    const sent: Sent[] = []
    const f = await forwarder(sent, false, { chunkMax: 40 })
    const final = 'x'.repeat(95)
    f.handle('s1', ev('turn/start', { turn: 1 }))
    f.handle('s1', assistantEvent(final))
    f.handle('s1', ev('turn/end', { turn: 1, reason: { kind: 'success' } }))
    await f.flush()
    expect(sent.length).toBeGreaterThan(1)
    for (const entry of sent) {
      expect('card' in entry.input).toBe(true)
    }
    const joined = sent.map(entry => {
      const card = (entry.input as { card: object }).card as { body: { elements: { content: string }[] } }
      return card.body.elements[0]!.content
    }).join('')
    expect(joined).toContain(final)
  })

  it('只发 turn/end 前的最后一条 assistant 消息', async () => {
    const sent: Sent[] = []
    const f = await forwarder(sent)
    f.handle('s1', ev('turn/start', { turn: 1 }))
    f.handle('s1', assistantEvent('中间步骤'))
    f.handle('s1', assistantEvent('最终回复'))
    f.handle('s1', ev('turn/end', { turn: 1, reason: { kind: 'success' } }))
    await f.flush()
    expect(sent).toHaveLength(1)
    expect('card' in sent[0]!.input).toBe(true)
    const card = (sent[0]!.input as { card: object }).card as { body: { elements: { content: string }[] } }
    expect(card.body.elements[0]!.content).toContain('最终回复')
  })

  it('错误轮产出 card 输入', async () => {
    const sent: Sent[] = []
    const f = await forwarder(sent)
    f.handle('s1', ev('turn/start', { turn: 1 }))
    f.handle('s1', ev('turn/end', { turn: 1, reason: { kind: 'error', error: { code: 'x', message: 'boom' } } }))
    await f.flush()
    expect(sent).toHaveLength(1)
    expect('card' in sent[0]!.input).toBe(true)
    const card = (sent[0]!.input as { card: object }).card as { header?: { template?: string } }
    expect(card.header?.template).toBe('red')
  })

  it('工具调用只在 verbose 时转发，且为 markdown', async () => {
    const quiet: Sent[] = []
    const f = await forwarder(quiet, false)
    f.handle('s1', toolEvent('bash', '{"cmd":"ls"}'))
    await f.flush()
    expect(quiet).toEqual([])

    const loud: Sent[] = []
    const g = await forwarder(loud, true)
    g.handle('s1', toolEvent('bash', '{"cmd":"ls\n-a"}'))
    await g.flush()
    expect(loud).toHaveLength(1)
    expect('markdown' in loud[0]!.input).toBe(true)
    expect((loud[0]!.input as { markdown: string }).markdown).toContain('bash')
  })

  it('轮次计数递增', async () => {
    const sent: Sent[] = []
    const f = await forwarder(sent)
    expect(f.turnOf('s1')).toBe(0)
    f.handle('s1', ev('turn/start', { turn: 1 }))
    expect(f.turnOf('s1')).toBe(1)
    f.handle('s1', ev('turn/end', { turn: 1, reason: { kind: 'success' } }))
    f.handle('s1', ev('turn/start', { turn: 2 }))
    expect(f.turnOf('s1')).toBe(2)
    f.handle('s1', userEvent('m2', 'second'))
    await f.flush()
    // The card should say 第 2 轮
    const last = sent[sent.length - 1]!
    expect('card' in last.input).toBe(true)
    const card = (last.input as { card: object }).card as { header?: { title?: { content?: string } } }
    expect(card.header?.title?.content).toContain('第 2 轮')
  })

  it('一次发送失败不阻断后续发送', async () => {
    const sent: Sent[] = []
    const errors: unknown[] = []
    const port = {
      send: async (target: string, input: MirrorSendInput): Promise<void> => {
        if ('markdown' in input && input.markdown.includes('boom')) throw new Error('send failed')
        if ('card' in input) {
          const card = input.card as { body?: { elements?: { content?: string }[] } }
          if (card.body?.elements?.some(e => e.content?.includes('boom'))) throw new Error('send failed')
        }
        sent.push({ target, input })
      },
    }
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_a')
    const f = new MirrorForwarder({ port, binding: sessionId => mirrors.bindingFor(sessionId), onError: error => errors.push(error) })
    f.handle('s1', ev('turn/start', { turn: 1 }))
    f.handle('s1', userEvent('m1', 'boom'))
    f.handle('s1', userEvent('m2', 'after'))
    await f.flush()
    expect(errors).toHaveLength(1)
    expect(sent.length).toBe(1)
  })
})

describe('mirror card helpers', () => {
  it('mirrorPromptCard 有正确结构', () => {
    const card = mirrorPromptCard(3, 'hello world') as {
      schema: string
      header: { title: { content: string }; template: string }
      body: { elements: { tag: string; content: string }[] }
    }
    expect(card.schema).toBe('2.0')
    expect(card.header.template).toBe('blue')
    expect(card.header.title.content).toContain('第 3 轮')
    expect(card.body.elements[0]!.tag).toBe('markdown')
    expect(card.body.elements[0]!.content).toBe('hello world')
  })

  it('mirrorPromptCard 超长文本截断', () => {
    const longText = 'x'.repeat(3000)
    const card = mirrorPromptCard(1, longText) as {
      body: { elements: { content: string }[] }
    }
    expect(card.body.elements[0]!.content.length).toBeLessThanOrEqual(2001) // 2000 + ellipsis
    expect(card.body.elements[0]!.content.endsWith('…')).toBe(true)
  })

  it('mirrorErrorCard 有红色 header', () => {
    const card = mirrorErrorCard('something went wrong') as {
      schema: string
      header: { template: string; title: { content: string } }
      body: { elements: { content: string }[] }
    }
    expect(card.schema).toBe('2.0')
    expect(card.header.template).toBe('red')
    expect(card.header.title.content).toContain('出错')
    expect(card.body.elements[0]!.content).toBe('something went wrong')
  })

  it('mirrorRootCard 无 title 时用 sessionId 前缀', () => {
    const card = mirrorRootCard('sess-12345678-abcd', '/home/user/project', 'project') as {
      schema: string
      header: { template: string; title: { content: string } }
      body: { elements: { content: string }[] }
    }
    expect(card.schema).toBe('2.0')
    expect(card.header.template).toBe('turquoise')
    expect(card.header.title.content).toBe('🔗 DSH · sess-123')
    const content = card.body.elements[0]!.content
    expect(content).toContain('sess-12345678-abcd')
    expect(content).toContain('/home/user/project')
    expect(content).toContain('project')
  })

  it('mirrorRootCard 有 title 时显示 title', () => {
    const card = mirrorRootCard('sess-1', '/home/user/project', 'project', '讨论如何接入飞书') as {
      header: { title: { content: string } }
    }
    expect(card.header.title.content).toBe('🔗 讨论如何接入飞书')
  })
})

describe('reverseLookup rootId self-healing', () => {
  it('om_ 锚 + 真实 threadId 首次命中靠 rootId', async () => {
    const patches: object[] = []
    const mirrors = new MirrorBindings({ persist: async (patch) => { patches.push(patch); return true } })
    // Bind with anchor where threadId = messageId (auto-flow case)
    await mirrors.bind('s1', 'oc_g', { messageId: 'om_root', threadId: 'om_root' })
    // Message arrives with real threadId but rootId matches anchor.messageId
    const hit = mirrors.reverseLookup('oc_g', undefined, 'group', 't_real', 'om_root')
    expect(hit).toBe('s1')
  })

  it('自愈后复合键更新，第二次直接命中', async () => {
    const patches: object[] = []
    const mirrors = new MirrorBindings({ persist: async (patch) => { patches.push(patch); return true } })
    await mirrors.bind('s1', 'oc_g', { messageId: 'om_root', threadId: 'om_root' })
    // First call: self-heals
    mirrors.reverseLookup('oc_g', undefined, 'group', 't_real', 'om_root')
    // Second call: direct composite key hit (no rootId scan needed)
    const hit = mirrors.reverseLookup('oc_g', undefined, 'group', 't_real')
    expect(hit).toBe('s1')
    // Old composite key is gone
    expect(mirrors.sessionFor('oc_g#om_root')).toBeUndefined()
    expect(mirrors.sessionFor('oc_g#t_real')).toBe('s1')
  })

  it('自愈触发持久化', async () => {
    const patches: object[] = []
    const mirrors = new MirrorBindings({ persist: async (patch) => { patches.push(patch); return true } })
    await mirrors.bind('s1', 'oc_g', { messageId: 'om_root', threadId: 'om_root' })
    patches.length = 0 // clear bind patch
    mirrors.reverseLookup('oc_g', undefined, 'group', 't_real', 'om_root')
    // Give the fire-and-forget persist a tick
    await new Promise(resolve => setTimeout(resolve, 10))
    expect(patches.length).toBe(1)
    expect(patches[0]).toEqual({ sessionMirrors: { s1: 'oc_g|om_root|t_real' } })
  })
})

describe('mirrorHistoryCard', () => {
  it('列出 items 和总数', () => {
    const card = mirrorHistoryCard(['1. hello', '2. world'], 2) as {
      schema: string
      header: { template: string; title: { content: string } }
      body: { elements: { content: string }[] }
    }
    expect(card.schema).toBe('2.0')
    expect(card.header.template).toBe('indigo')
    expect(card.header.title.content).toContain('历史')
    expect(card.body.elements[0]!.content).toContain('hello')
    expect(card.body.elements[0]!.content).toContain('world')
  })

  it('总数超出时显示提示', () => {
    const items = Array.from({ length: 20 }, (_, i) => `${i + 1}. item`)
    const card = mirrorHistoryCard(items, 50) as {
      body: { elements: { content: string }[] }
    }
    expect(card.body.elements[0]!.content).toContain('共 50 条')
    expect(card.body.elements[0]!.content).toContain('显示最近 20 条')
  })
})

describe('mirrorReplyCard', () => {
  it('无 header、body 有 markdown', () => {
    const card = mirrorReplyCard('hello **world**') as {
      schema: string
      header?: unknown
      body: { elements: { tag: string; content: string }[] }
    }
    expect(card.schema).toBe('2.0')
    expect(card.header).toBeUndefined()
    expect(card.body.elements[0]!.tag).toBe('markdown')
    expect(card.body.elements[0]!.content).toBe('hello **world**')
  })
})

describe('mirrorAskCard', () => {
  it('渲染问题和选项', () => {
    const card = mirrorAskCard([
      { question: '选择颜色', options: [{ label: '红' }, { label: '蓝' }] },
    ]) as {
      schema: string
      header: { template: string; title: { content: string } }
      body: { elements: { content: string }[] }
    }
    expect(card.schema).toBe('2.0')
    expect(card.header.template).toBe('orange')
    expect(card.header.title.content).toContain('提问')
    const content = card.body.elements[0]!.content
    expect(content).toContain('选择颜色')
    expect(content).toContain('红')
    expect(content).toContain('蓝')
    expect(content).toContain('GUI')
  })
})

describe('MirrorForwarder reply cards', () => {
  interface Sent { target: string; input: MirrorSendInput }
  const fakePort = (sent: Sent[]) => ({
    send: async (target: string, input: MirrorSendInput): Promise<void> => {
      sent.push({ target, input })
    },
  })

  it('助手回复产出 reply card', async () => {
    const sent: Sent[] = []
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_a')
    const f = new MirrorForwarder({
      port: fakePort(sent),
      binding: sessionId => mirrors.bindingFor(sessionId),
    })
    f.handle('s1', ev('turn/start', { turn: 1 }))
    f.handle('s1', ev('assistant/message', { turn: 1, message: { content: [{ type: 'text', text: 'hello' }] } }))
    f.handle('s1', ev('turn/end', { turn: 1, reason: { kind: 'success' } }))
    await f.flush()
    expect(sent).toHaveLength(1)
    expect('card' in sent[0]!.input).toBe(true)
    const card = (sent[0]!.input as { card: object }).card as { body: { elements: { content: string }[] } }
    expect(card.body.elements[0]!.content).toBe('hello')
  })

  it('长助手回复分块为多张 card', async () => {
    const sent: Sent[] = []
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_a')
    const f = new MirrorForwarder({
      port: fakePort(sent),
      binding: sessionId => mirrors.bindingFor(sessionId),
      chunkMax: 40,
    })
    const final = 'x'.repeat(95)
    f.handle('s1', ev('turn/start', { turn: 1 }))
    f.handle('s1', ev('assistant/message', { turn: 1, message: { content: [{ type: 'text', text: final }] } }))
    f.handle('s1', ev('turn/end', { turn: 1, reason: { kind: 'success' } }))
    await f.flush()
    expect(sent.length).toBeGreaterThan(1)
    for (const entry of sent) {
      expect('card' in entry.input).toBe(true)
    }
  })

  it('ask_user_question 工具调用渲染为 ask card（不受 verbose 控制）', async () => {
    const sent: Sent[] = []
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_a')
    const f = new MirrorForwarder({
      port: fakePort(sent),
      binding: sessionId => mirrors.bindingFor(sessionId),
    })
    const args = JSON.stringify({ questions: [{ id: 'q1', question: 'Continue?', options: [{ label: 'Yes' }] }] })
    f.handle('s1', ev('tool/call', { turn: 1, callId: 'c1', name: 'ask_user_question', arguments: args }))
    await f.flush()
    expect(sent).toHaveLength(1)
    expect('card' in sent[0]!.input).toBe(true)
    const card = (sent[0]!.input as { card: object }).card as { header?: { template?: string }; body: { elements: { content: string }[] } }
    expect(card.header?.template).toBe('orange')
    expect(card.body.elements[0]!.content).toContain('Continue?')
    expect(card.body.elements[0]!.content).toContain('Yes')
  })
})

describe('常量', () => {
  it('命令名稳定', () => {
    expect(LARK_COMMAND).toBe('lark')
  })
})

describe('commandRunMarkdown', () => {
  it('无参数只留命令名', () => {
    expect(commandRunMarkdown('status', undefined)).toBe('⚡ `/status`')
    expect(commandRunMarkdown('status', '')).toBe('⚡ `/status`')
    expect(commandRunMarkdown('status', '   ')).toBe('⚡ `/status`')
  })
  it('有参数跟在命令后面', () => {
    const line = commandRunMarkdown('cd', ' /home/user/project')
    expect(line).toContain('/cd')
    expect(line).toContain('/home/user/project')
  })
  it('超长参数有界', () => {
    const line = commandRunMarkdown('cd', 'x'.repeat(500))
    expect(line.length).toBeLessThanOrEqual('⚡ `/cd` '.length + 240)
  })
})

describe('commandDoneMarkdown', () => {
  it('成功时显示 ✅', () => {
    expect(commandDoneMarkdown('cd', 'success', undefined)).toBe('✅ `/cd` success')
  })
  it('失败时显示 ❌', () => {
    expect(commandDoneMarkdown('cd', 'error', '目录不存在')).toContain('❌')
    expect(commandDoneMarkdown('cd', 'error', '目录不存在')).toContain('目录不存在')
  })
  it('有结果文本时显示', () => {
    const line = commandDoneMarkdown('status', 'success', '会话已绑定')
    expect(line).toContain('✅')
    expect(line).toContain('会话已绑定')
  })
  it('超长结果文本有界', () => {
    const line = commandDoneMarkdown('cd', 'success', 'x'.repeat(500))
    expect(line.length).toBeLessThanOrEqual('✅ `/cd` '.length + 240)
  })
})

describe('MirrorForwarder command events', () => {
  interface Sent { target: string; input: MirrorSendInput }
  const fakePort = (sent: Sent[]) => ({
    send: async (target: string, input: MirrorSendInput): Promise<void> => {
      sent.push({ target, input })
    },
  })

  it('命令事件在 verbose 模式下转发', async () => {
    const sent: Sent[] = []
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_a')
    mirrors.setVerbose('s1', true)
    const f = new MirrorForwarder({
      port: fakePort(sent),
      binding: sessionId => mirrors.bindingFor(sessionId),
    })
    f.handle('s1', ev('command/run', { commandId: 'cmd-1', name: 'cd', args: ' /project' }))
    f.handle('s1', ev('command/done', { commandId: 'cmd-1', kind: 'success', text: '已切换' }))
    await f.flush()
    expect(sent).toHaveLength(2)
    expect('markdown' in sent[0]!.input).toBe(true)
    expect((sent[0]!.input as { markdown: string }).markdown).toContain('/cd')
    expect((sent[0]!.input as { markdown: string }).markdown).toContain('/project')
    expect('markdown' in sent[1]!.input).toBe(true)
    expect((sent[1]!.input as { markdown: string }).markdown).toContain('已切换')
  })

  it('命令事件在非 verbose 模式下不转发', async () => {
    const sent: Sent[] = []
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_a')
    const f = new MirrorForwarder({
      port: fakePort(sent),
      binding: sessionId => mirrors.bindingFor(sessionId),
    })
    f.handle('s1', ev('command/run', { commandId: 'cmd-1', name: 'status' }))
    f.handle('s1', ev('command/done', { commandId: 'cmd-1', kind: 'success', text: 'ok' }))
    await f.flush()
    expect(sent).toEqual([])
  })

  it('command/done 从 run 中获取命令名', async () => {
    const sent: Sent[] = []
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_a')
    mirrors.setVerbose('s1', true)
    const f = new MirrorForwarder({
      port: fakePort(sent),
      binding: sessionId => mirrors.bindingFor(sessionId),
    })
    f.handle('s1', ev('command/run', { commandId: 'cmd-x', name: 'model' }))
    f.handle('s1', ev('command/done', { commandId: 'cmd-x', kind: 'error', text: '参数错误' }))
    await f.flush()
    expect(sent).toHaveLength(2)
    expect((sent[1]!.input as { markdown: string }).markdown).toContain('/model')
    expect((sent[1]!.input as { markdown: string }).markdown).toContain('参数错误')
  })
})

describe('compileTriggerPhrases', () => {
  it('undefined 或空对象产出空表', () => {
    expect(compileTriggerPhrases(undefined).entries.size).toBe(0)
    expect(compileTriggerPhrases({}).entries.size).toBe(0)
  })

  it('正常编译为小写键', () => {
    const table = compileTriggerPhrases({ '开始处理': '/lark-watch process', 'Go': '/run go' })
    expect(table.entries.size).toBe(2)
    expect(table.entries.get('开始处理')).toBe('/lark-watch process')
    expect(table.entries.get('go')).toBe('/run go')
  })

  it('跳过空键和空值', () => {
    const table = compileTriggerPhrases({ '': '/cmd', 'a': '', ' ': '/ ', '  b  ': '/ok' })
    expect(table.entries.size).toBe(1)
    expect(table.entries.get('b')).toBe('/ok')
  })

  it('值两端空白被修剪', () => {
    const table = compileTriggerPhrases({ 'x': '  /run foo  ' })
    expect(table.entries.get('x')).toBe('/run foo')
  })
})

describe('matchTriggerPhrase', () => {
  const table = compileTriggerPhrases({
    '开始处理': '/lark-watch process',
    'deploy': '/deploy prod',
  })

  it('精确匹配（忽略大小写和两端空白）', () => {
    expect(matchTriggerPhrase('开始处理', table)).toBe('/lark-watch process')
    expect(matchTriggerPhrase('  开始处理  ', table)).toBe('/lark-watch process')
    expect(matchTriggerPhrase('Deploy', table)).toBe('/deploy prod')
    expect(matchTriggerPhrase('DEPLOY', table)).toBe('/deploy prod')
  })

  it('不命中时返回 undefined', () => {
    expect(matchTriggerPhrase('请开始处理', table)).toBeUndefined()
    expect(matchTriggerPhrase('开始处理吧', table)).toBeUndefined()
    expect(matchTriggerPhrase('deploy now', table)).toBeUndefined()
    expect(matchTriggerPhrase('', table)).toBeUndefined()
  })

  it('空表永远不命中', () => {
    const empty = compileTriggerPhrases({})
    expect(matchTriggerPhrase('开始处理', empty)).toBeUndefined()
    expect(matchTriggerPhrase('anything', empty)).toBeUndefined()
  })
})
