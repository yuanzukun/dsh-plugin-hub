import { describe, expect, it } from 'vitest'
import type { NormalizedMessage } from '@larksuite/channel'
import { shouldServe } from './mention.ts'
import type { MentionState } from './mention.ts'

/** A minimal inbound message; every field the decision can read is named per case. */
function message(overrides: Partial<NormalizedMessage> = {}): NormalizedMessage {
  return {
    messageId: 'om_1',
    chatId: 'oc_room',
    chatType: 'group',
    senderId: 'ou_user',
    content: '继续说',
    rawContentType: 'text',
    resources: [],
    mentions: [],
    mentionAll: false,
    mentionedBot: false,
    createTime: 0,
    ...overrides,
  }
}

/** A state where only the listed keys are bound, so every case states its binding explicitly. */
function state(overrides: Partial<MentionState> = {}, bound: string[] = []): MentionState {
  const boundSet = new Set(bound)
  return {
    requireMention: true,
    mentionFreeFollowUp: false,
    bound: key => boundSet.has(key),
    ...overrides,
  }
}

describe('shouldServe', () => {
  it('serves a direct message without any mention', () => {
    expect(shouldServe(message({ chatType: 'p2p', chatId: 'ou_user' }), 'ou_user', state())).toBe(true)
  })

  it('refuses a group message that does not mention the bot', () => {
    expect(shouldServe(message(), 'oc_room', state())).toBe(false)
  })

  it('serves a group message that mentions the bot', () => {
    expect(shouldServe(message({ mentionedBot: true }), 'oc_room', state())).toBe(true)
  })

  it('refuses an @-all group message, as the transport did', () => {
    expect(shouldServe(message({ mentionAll: true }), 'oc_room', state())).toBe(false)
    // The exemption must not open @-all, even in a bound topic thread.
    expect(shouldServe(message({ mentionAll: true, threadId: 'omt_1' }), 'oc_room:omt_1', state({ mentionFreeFollowUp: true }, ['oc_room:omt_1']))).toBe(false)
  })

  it('serves an unmentioned message in a bound topic thread when follow-ups are exempted', () => {
    const key = 'oc_room:omt_1'
    expect(shouldServe(message({ threadId: 'omt_1' }), key, state({ mentionFreeFollowUp: true }, [key]))).toBe(true)
  })

  it('still requires the @ in a bound topic thread when follow-ups are off', () => {
    const key = 'oc_room:omt_1'
    expect(shouldServe(message({ threadId: 'omt_1' }), key, state({}, [key]))).toBe(false)
  })

  it('refuses an unmentioned message in a topic thread nobody has opened', () => {
    const key = 'oc_room:omt_2'
    expect(shouldServe(message({ threadId: 'omt_2' }), key, state({ mentionFreeFollowUp: true }, ['oc_room:omt_1']))).toBe(false)
  })

  it('refuses an unmentioned group-level message even when the chat is bound', () => {
    // No threadId: this is the group feed, not a topic follow-up.
    expect(shouldServe(message(), 'oc_room', state({ mentionFreeFollowUp: true }, ['oc_room']))).toBe(false)
  })

  it('admits a bot-sent unmentioned message in a bound topic thread, leaving the hop budget to its own judgment', () => {
    const key = 'oc_room:omt_1'
    expect(shouldServe(message({ threadId: 'omt_1', senderIsBot: true }), key, state({ mentionFreeFollowUp: true }, [key]))).toBe(true)
    // An unmentioned bot message outside any bound topic is refused by the same gate.
    expect(shouldServe(message({ senderIsBot: true }), 'oc_room', state())).toBe(false)
  })

  it('serves everything group when requireMention is off', () => {
    const open = state({ requireMention: false })
    expect(shouldServe(message(), 'oc_room', open)).toBe(true)
    expect(shouldServe(message({ threadId: 'omt_9' }), 'oc_room:omt_9', open)).toBe(true)
  })
})
