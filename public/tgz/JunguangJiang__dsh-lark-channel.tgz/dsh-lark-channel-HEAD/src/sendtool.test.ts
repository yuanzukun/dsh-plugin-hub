/**
 * Tests for agent-initiated Lark sends: target resolution, argument
 * normalization, the model-facing failure path, and the configuration
 * defaults that keep existing deployments unchanged.
 */

import { describe, expect, test } from 'vitest'
import type { SendInput, SendOptions, SendResult } from '@larksuite/channel'
import { resolveConfig } from './config.ts'
import { planSendMessage, shadowSendTool } from './sendtool.ts'
import type { SendSession, SendToolHandler } from './sendtool.ts'

/** One recorded send, as a minimal fake outbound port would see it. */
interface RecordedSend {
  readonly to: string
  readonly input: SendInput
  readonly opts?: SendOptions | undefined
}

/** A minimal fake outbound port: records sends, and can be told to fail them. */
function fakePort(options: { readonly fail?: boolean } = {}) {
  const sends: RecordedSend[] = []
  return {
    sends,
    async send(to: string, input: SendInput, opts?: SendOptions): Promise<SendResult> {
      if (options.fail === true) throw new Error('send rejected')
      sends.push({ to, input, opts })
      return { messageId: `om_${sends.length}` }
    },
  }
}

/** The bridge-shaped handler a test tool is registered with. */
function handlerFor(
  port: ReturnType<typeof fakePort>,
  session: SendSession,
  allowCrossChatSend = false,
): SendToolHandler {
  return {
    allowCrossChatSend,
    sessionOf: (sessionId) => sessionId === 'session-1' ? session : undefined,
    send: async (plan) => {
      try {
        return { messageId: (await port.send(plan.to, plan.input, plan.opts)).messageId }
      } catch (error) {
        return { error: `lark_send_message failed: ${error instanceof Error ? error.message : String(error)}` }
      }
    },
  }
}

/** The execution context the host hands a tool; only the session id is read. */
const exec = { agent: { session: { id: 'session-1' } } }

describe('planSendMessage target resolution', () => {
  test('degrades to a main-channel send when the session has no reply anchor', () => {
    const planned = planSendMessage({ text: 'hi' }, { chatId: 'oc_1' }, false)
    expect(planned).toEqual({
      to: 'oc_1',
      input: { text: 'hi' },
      // No reply target: a plain create, which the platform posts to the
      // chat's main channel.
      opts: { resolveMentionsInText: true },
    })
  })

  test('rejoins the current topic thread by default, as a reply to its anchor', () => {
    const planned = planSendMessage(
      { text: 'hi' },
      { chatId: 'oc_1', replyAnchor: { messageId: 'om_reply', threadId: 'om_t' } },
      false,
    )
    expect(planned).toEqual({
      to: 'oc_1',
      input: { text: 'hi' },
      // replyTo is what the platform needs to route into the thread;
      // replyInThread alone is ignored on a plain create.
      opts: { resolveMentionsInText: true, replyTo: 'om_reply', replyInThread: true },
    })
  })

  test('uses the named target when cross-chat sends are allowed', () => {
    const planned = planSendMessage(
      { markdown: 'hi', target: 'oc_2' },
      { chatId: 'oc_1', replyAnchor: { messageId: 'om_reply', threadId: 'om_t' } },
      true,
    )
    expect(planned).toEqual({
      to: 'oc_2',
      input: { markdown: 'hi' },
      // No reply options: a named target is a fresh conversation, not a reply.
      opts: { resolveMentionsInText: true },
    })
  })

  test('trims the named target before using it', () => {
    const planned = planSendMessage({ text: 'hi', target: '  ou_9  ' }, { chatId: 'oc_1' }, true)
    expect(planned).toMatchObject({ to: 'ou_9' })
  })

  test('refuses a named target when cross-chat sends are disabled', () => {
    const planned = planSendMessage({ text: 'hi', target: 'oc_2' }, { chatId: 'oc_1' }, false)
    expect(planned).toEqual({
      error: expect.stringContaining('allowCrossChatSend'),
    })
    expect(planned).toMatchObject({ error: expect.stringContaining('oc_2') })
  })
})

describe('planSendMessage argument validation', () => {
  test('rejects a call whose text and markdown are both missing', () => {
    expect(planSendMessage({}, { chatId: 'oc_1' }, false)).toEqual({
      error: expect.stringContaining('text'),
    })
  })

  test('rejects a call whose text and markdown are both empty', () => {
    const planned = planSendMessage({ text: '', markdown: '   ' }, { chatId: 'oc_1' }, false)
    expect(planned).toEqual({ error: expect.stringContaining('non-empty') })
  })

  test('treats non-string bodies as absent', () => {
    const planned = planSendMessage({ text: 42, markdown: null }, { chatId: 'oc_1' }, false)
    expect(planned).toEqual({ error: expect.stringContaining('non-empty') })
  })

  test('accepts text alone', () => {
    expect(planSendMessage({ text: 'hi' }, { chatId: 'oc_1' }, false)).toMatchObject({
      to: 'oc_1',
      input: { text: 'hi' },
    })
  })

  test('accepts markdown alone', () => {
    expect(planSendMessage({ markdown: '**hi**' }, { chatId: 'oc_1' }, false)).toMatchObject({
      input: { markdown: '**hi**' },
    })
  })

  test('prefers markdown when both bodies are given', () => {
    expect(planSendMessage({ text: 'hi', markdown: '**hi**' }, { chatId: 'oc_1' }, false))
      .toMatchObject({ input: { markdown: '**hi**' } })
  })
})

describe('shadowSendTool execution', () => {
  test('sends to the session chat by default and returns the message id', async () => {
    const port = fakePort()
    const tool = shadowSendTool(handlerFor(port, { chatId: 'oc_1' }))
    const result = await tool.execute({ text: 'progress: done' }, exec)
    expect(result).toEqual({ messageId: 'om_1' })
    expect(port.sends).toEqual([{
      to: 'oc_1',
      input: { text: 'progress: done' },
      opts: { resolveMentionsInText: true },
    }])
  })

  test('replies to the anchor so the send stays in the thread', async () => {
    const port = fakePort()
    const session: SendSession = {
      chatId: 'oc_1',
      replyAnchor: { messageId: 'om_reply', threadId: 'om_t' },
    }
    const tool = shadowSendTool(handlerFor(port, session))
    await tool.execute({ markdown: 'done' }, exec)
    expect(port.sends[0]).toMatchObject({
      to: 'oc_1',
      opts: { replyTo: 'om_reply', replyInThread: true },
    })
  })

  test('does not send when the default-locked call names a target', async () => {
    const port = fakePort()
    const tool = shadowSendTool(handlerFor(port, { chatId: 'oc_1' }))
    const result = await tool.execute({ text: 'hi', target: 'oc_2' }, exec)
    expect(result).toMatchObject({ error: expect.stringContaining('allowCrossChatSend') })
    expect(port.sends).toEqual([])
  })

  test('delivers to the named target when cross-chat sends are allowed', async () => {
    const port = fakePort()
    const tool = shadowSendTool(handlerFor(port, { chatId: 'oc_1' }, true))
    const result = await tool.execute({ text: 'hi', target: 'oc_2' }, exec)
    expect(result).toEqual({ messageId: 'om_1' })
    expect(port.sends[0]).toMatchObject({ to: 'oc_2' })
  })

  test('returns the failure reason to the model instead of throwing', async () => {
    const port = fakePort({ fail: true })
    const tool = shadowSendTool(handlerFor(port, { chatId: 'oc_1' }))
    const result = await tool.execute({ text: 'hi' }, exec)
    expect(result).toEqual({ error: 'lark_send_message failed: send rejected' })
  })

  test('reports a session the bridge has no conversation for', async () => {
    const port = fakePort()
    const tool = shadowSendTool(handlerFor(port, { chatId: 'oc_1' }))
    const result = await tool.execute({ text: 'hi' }, { agent: { session: { id: 'session-9' } } })
    expect(result).toMatchObject({ error: expect.stringContaining('no conversation') })
    expect(port.sends).toEqual([])
  })
})

describe('configuration defaults', () => {
  test('enableSendTool defaults on and allowCrossChatSend defaults off', () => {
    const resolved = resolveConfig({})
    expect(resolved.enableSendTool).toBe(true)
    expect(resolved.allowCrossChatSend).toBe(false)
  })

  test('explicit configuration survives resolution', () => {
    const resolved = resolveConfig({ enableSendTool: false, allowCrossChatSend: true })
    expect(resolved.enableSendTool).toBe(false)
    expect(resolved.allowCrossChatSend).toBe(true)
  })
})
