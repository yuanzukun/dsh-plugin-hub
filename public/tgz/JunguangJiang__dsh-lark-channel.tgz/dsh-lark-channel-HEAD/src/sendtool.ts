/**
 * Agent-initiated outbound messages. The host's turn loop returns a chat
 * agent's output at the end of a turn, which is not how an agent reports
 * progress mid-run or follows up after the exchange moved on. This tool lets
 * the model send a message itself, through the same outbound port the bridge
 * renders answers with.
 *
 * Every registration is agent-scoped, so the tool carries the conversation
 * that agent answers in: without an explicit target a send lands in that
 * chat, inside the topic thread when the current exchange is in one. Naming
 * another destination is a deployment decision ({@link Config.allowCrossChatSend}).
 * @module dsh-lark-channel/sendtool
 */

import type { SendInput, SendOptions } from '@larksuite/channel'

/** The tool's registered name. */
export const SEND_TOOL = 'lark_send_message'

/** The model-supplied arguments, read loosely: values are normalized rather than schema-rejected. */
export interface SendMessageArgs {
  /** Plain-text body; ignored when {@link SendMessageArgs.markdown} is also given. */
  readonly text?: string | undefined
  /** Markdown body; preferred over {@link SendMessageArgs.text} when both are given. */
  readonly markdown?: string | undefined
  /** Chat id or user open id; honored only when the deployment allows cross-chat sends. */
  readonly target?: string | undefined
}

/** Where the calling agent's conversation lives. */
export interface SendSession {
  /** The chat the session answers in. */
  readonly chatId: string
  /**
   * The message inside a topic thread that the current exchange answers,
   * when it is in one. A default-target send replies to it — the platform
   * only routes a send into a thread as a reply to a message in it.
   */
  readonly replyAnchor?: { readonly messageId: string; readonly threadId: string } | undefined
}

/** One validated send: its destination and the message to deliver. */
export interface PlannedSend {
  /** The recipient the port sends to. */
  readonly to: string
  readonly input: SendInput
  readonly opts?: SendOptions | undefined
}

/** A refused or malformed call, returned to the model instead of thrown. */
export interface SendFailure {
  readonly error: string
}

/**
 * Normalize one call into the message to send, or a reason not to.
 *
 * Arguments arrive as raw model JSON, so they are normalized rather than
 * schema-rejected: a missing or non-string body counts as absent, and the
 * call fails only when no body remains or a target is named while cross-chat
 * sends are off.
 * @param args - raw tool arguments.
 * @param session - the calling agent's conversation.
 * @param allowCrossChatSend - whether a target beyond the session's own chat is allowed.
 * @returns the planned send, or the failure to return to the model.
 */
export function planSendMessage(
  args: unknown,
  session: SendSession,
  allowCrossChatSend: boolean,
): PlannedSend | SendFailure {
  const record = typeof args === 'object' && args !== null ? args as Record<string, unknown> : {}
  const rawText = typeof record.text === 'string' ? record.text : undefined
  const rawMarkdown = typeof record.markdown === 'string' ? record.markdown : undefined
  const text = rawText !== undefined && rawText.trim() !== '' ? rawText : undefined
  const markdown = rawMarkdown !== undefined && rawMarkdown.trim() !== '' ? rawMarkdown : undefined
  if (text === undefined && markdown === undefined) {
    return { error: 'lark_send_message needs a non-empty "text" or "markdown" body.' }
  }
  const target = typeof record.target === 'string' && record.target.trim() !== ''
    ? record.target.trim()
    : undefined
  if (target !== undefined && !allowCrossChatSend) {
    return {
      error: `sending to "${target}" is not allowed: cross-chat sends are disabled by configuration (allowCrossChatSend is off).`,
    }
  }
  const anchor = target === undefined ? session.replyAnchor : undefined
  return {
    to: target ?? session.chatId,
    input: markdown === undefined ? { text: text ?? '' } : { markdown },
    opts: {
      // Mentions resolve against the destination chat's roster, exactly as
      // rendered assistant output does; unknown names stay plain text.
      resolveMentionsInText: true,
      // The default destination rejoins the exchange it is part of: the send
      // is a REPLY to the message being answered, which is what the platform
      // needs — `replyInThread` alone is ignored on a plain create — to keep
      // the message inside that message's topic thread.
      ...anchor === undefined ? {} : { replyTo: anchor.messageId, replyInThread: true },
    },
  }
}

/** What the bridge supplies when the tool is enabled. */
export interface SendToolHandler {
  /** Whether a call may name a destination beyond the session's own chat. */
  readonly allowCrossChatSend: boolean
  /**
   * The conversation one agent session answers in.
   * @param sessionId - the calling agent's session id, from its execution context.
   * @returns the conversation, or undefined when the session has none.
   */
  sessionOf(sessionId: string | undefined): SendSession | undefined
  /**
   * Deliver one planned send.
   * @param plan - the validated destination and body.
   * @returns the platform message id, or the failure to return to the model.
   */
  send(plan: PlannedSend): Promise<{ messageId: string } | { error: string }>
}

/**
 * The agent-scoped tool definition, declared structurally like every other
 * host contract here so the package keeps building against its published
 * dependencies alone: the JSON Schema is written in its compiled form, which
 * is what the host registry validates at registration.
 *
 * A call that cannot be honored is answered with `{ error }` rather than a
 * rejection — the reason is model-facing, so the model can recover, where a
 * thrown failure would surface as a bare turn error with no context.
 * @param handler - the bridge-side wiring: session resolution and delivery.
 * @returns the definition to register in one agent's scope.
 */
export function shadowSendTool(handler: SendToolHandler): object {
  return {
    name: SEND_TOOL,
    description:
      'Send a Lark message as the bot. By default the message goes to this conversation: '
      + 'the chat the user is talking in, and inside the topic thread when the exchange is in '
      + 'one. Use it to proactively report progress, confirm an action, or follow up without '
      + 'waiting for the user to speak. Give exactly one body — "text" for plain text or '
      + '"markdown" for rich text (markdown wins when both are given). "target" overrides the '
      + 'destination with a chat id or a user open id, which only works when the deployment '
      + 'enables cross-chat sends.',
    parameters: {
      type: 'object',
      // No required properties at the schema level: the "at least one body"
      // rule cannot be expressed as a per-property requirement, so execute
      // enforces it and reports the reason the model can act on.
      anyOf: [{ required: ['text'] }, { required: ['markdown'] }],
      properties: {
        text: { type: 'string', description: 'Plain-text body; ignored when markdown is also given.' },
        markdown: { type: 'string', description: 'Markdown body; preferred over text when both are given.' },
        target: {
          type: 'string',
          description: 'Optional chat id or user open id to send to instead of this conversation; '
            + 'requires the deployment to allow cross-chat sends.',
        },
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          messageId: { type: 'string', description: 'Platform id of the sent message.' },
          error: { type: 'string', description: 'Why the message was not sent.' },
        },
      },
      render: (_args: unknown, value: unknown) => [{ type: 'text', text: JSON.stringify(value) }],
    },
    async execute(args: unknown, exec: unknown): Promise<{ messageId: string } | { error: string }> {
      const sessionId = (exec as { agent?: { session?: { id?: string } } }).agent?.session?.id
      const session = handler.sessionOf(sessionId)
      if (session === undefined) {
        return {
          error: 'lark_send_message has no conversation to send from: this agent is not bound to a chat.',
        }
      }
      const planned = planSendMessage(args, session, handler.allowCrossChatSend)
      if ('error' in planned) return planned
      return await handler.send(planned)
    },
  }
}
