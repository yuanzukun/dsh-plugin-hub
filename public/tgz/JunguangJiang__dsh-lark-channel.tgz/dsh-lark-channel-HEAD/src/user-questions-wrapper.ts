/**
 * Wrapper Provider for `ctx.userQuestions`: intercepts `ask()` calls and routes
 * Lark-bound sessions to interactive Feishu cards, while delegating all other
 * sessions to the original Web BFF provider.
 *
 * Strategy: after the Loader settles (when the Web BFF provider is already
 * registered on `ctx.userQuestions`), this wrapper reads the live `provider`
 * field, replaces it with a routing implementation, and restores the original
 * on disposal. The field is a regular JS class property (not a `#private`
 * field), so runtime access is safe.
 *
 * @module dsh-lark-channel/user-questions-wrapper
 */

import type { Context } from '@deepseek-ai/cordis'
import type { AskedQuestion, QuestionAnswer } from './questions.ts'

/**
 * The shape of `ctx.userQuestions` at runtime: the service instance exposes a
 * `provider` property and an `ask` method. Typed loosely to avoid importing
 * the host package (this plugin builds against two packages only).
 */
interface UserQuestionsService {
  provider: UserQuestionProvider | undefined
  ask(request: AskUserQuestionRequest): Promise<AskUserQuestionAnswer>
}

/** Minimal provider interface matching the host's UserQuestionProvider. */
interface UserQuestionProvider {
  ask(request: AskUserQuestionRequest): Promise<AskUserQuestionAnswer>
}

/** Minimal request interface matching AskUserQuestionRequest. */
interface AskUserQuestionRequest {
  questions: AskUserQuestionItem[]
  agent?: { id: string; session?: { id: string } }
  signal?: AbortSignal
}

/** One question item from the request. */
interface AskUserQuestionItem {
  id: string
  question: string
  header?: string
  options?: Array<{ label: string; description?: string }>
  multi_select?: boolean
  multiSelect?: boolean
  detail?: string
  intent?: { kind: string; approve: string }
}

/** Answer structure. */
interface AskUserQuestionAnswer {
  answers: Array<{ id: string; selected: string[]; custom?: string }>
}

/** Options for installing the wrapper. */
export interface WrapperOptions {
  /**
   * Resolve the chat binding for a session id.
   * Returns the chatId when the session belongs to a Lark conversation.
   */
  resolveBinding: (sessionId: string) => string | undefined
  /**
   * Ask questions via Lark interactive cards (sequential, one at a time).
   * Reuses the existing `askQuestions` function from the bridge.
   */
  askViaLark: (questions: readonly AskedQuestion[], sessionId: string | undefined) => Promise<QuestionAnswer[]>
  /** Operator console line. */
  notify: (line: string) => void
}

/**
 * Install the wrapper provider on `ctx.userQuestions`. The wrapper routes
 * Lark-bound sessions to card-based Q&A and delegates everything else to the
 * original provider (the Web BFF).
 *
 * @param ctx - The plugin's scoped Cordis context.
 * @param options - Binding resolution and Lark Q&A ports.
 * @returns A disposer that restores the original provider.
 */
export function installUserQuestionsWrapper(ctx: Context, options: WrapperOptions): () => void {
  const service = ctx.get('userQuestions') as UserQuestionsService | undefined
  if (service === undefined) {
    options.notify('lark-channel: userQuestions service not found; skipping wrapper installation')
    return () => {}
  }
  const original = service.provider
  if (original === undefined) {
    options.notify('lark-channel: no userQuestions provider found to wrap; skipping wrapper installation')
    return () => {}
  }

  const wrapper: UserQuestionProvider = {
    async ask(request: AskUserQuestionRequest): Promise<AskUserQuestionAnswer> {
      // Determine the session id from the request's agent.
      const sessionId = request.agent?.session?.id ?? request.agent?.id
      const chatId = sessionId === undefined ? undefined : options.resolveBinding(sessionId)

      if (chatId !== undefined && sessionId !== undefined) {
        // This session is bound to a Lark conversation — route to cards.
        const questions: AskedQuestion[] = request.questions.map(q => ({
          id: q.id,
          question: q.question,
          ...typeof q.header === 'string' ? { header: q.header } : {},
          ...Array.isArray(q.options) && q.options.length > 0
            ? { options: q.options.map(o => ({ label: o.label, ...typeof o.description === 'string' ? { description: o.description } : {} })) }
            : {},
          ...(q.multi_select === true || q.multiSelect === true) ? { multiSelect: true } : {},
        }))
        const answers = await options.askViaLark(questions, sessionId)
        return { answers }
      }

      // Not a Lark session — delegate to the original Web BFF provider.
      return original.ask(request)
    },
  }

  // Monkey-patch the provider field.
  service.provider = wrapper
  options.notify('lark-channel: userQuestions wrapper provider installed')

  // Return disposer that restores the original.
  return () => {
    // Only restore if we are still the installed wrapper (avoid stomping a
    // later replacement).
    if (service.provider === wrapper) {
      service.provider = original
      options.notify('lark-channel: userQuestions wrapper provider restored')
    }
  }
}
