/**
 * Tests for the mirror-question bridge: card structure, action parsing,
 * and the bridge's card-send + respond flow against fake ports.
 */
import { describe, expect, it, vi } from 'vitest'
import {
  MAX_OPTION_BUTTONS,
  MIRROR_QUESTION_ACTION,
  MirrorQuestionBridge,
  mirrorQuestionActionValue,
  mirrorQuestionCard,
  mirrorPlanReviewCard,
  SELECT_OPTION_LIMIT,
  settledMirrorQuestionCard,
} from './mirror-questions.ts'
import type { MirrorQuestion } from './mirror-questions.ts'
import { MirrorBindings } from './mirror.ts'

describe('mirrorQuestionActionValue', () => {
  it('parses a valid mirror-question action', () => {
    const value = {
      kind: MIRROR_QUESTION_ACTION,
      actionId: 'abc123',
      questionId: 'q1',
      label: 'Yes',
    }
    expect(mirrorQuestionActionValue(value)).toEqual(value)
  })

  it('parses a dropdown action value without a label', () => {
    const value = {
      kind: MIRROR_QUESTION_ACTION,
      actionId: 'abc123',
      questionId: 'q1',
    }
    expect(mirrorQuestionActionValue(value)).toEqual(value)
  })

  it('returns undefined for unrelated actions', () => {
    expect(mirrorQuestionActionValue(null)).toBeUndefined()
    expect(mirrorQuestionActionValue({ kind: 'other' })).toBeUndefined()
    expect(mirrorQuestionActionValue({ kind: MIRROR_QUESTION_ACTION })).toBeUndefined()
    expect(mirrorQuestionActionValue({
      kind: MIRROR_QUESTION_ACTION, actionId: 'a', questionId: 'q', label: 42,
    })).toBeUndefined()
  })
})

describe('mirrorQuestionCard', () => {
  it('single-select question has buttons with correct values', () => {
    const questions: MirrorQuestion[] = [
      { id: 'q1', question: 'Pick one', options: [{ label: 'A' }, { label: 'B' }] },
    ]
    const card = mirrorQuestionCard(questions, 'act1') as {
      schema: string
      header: { template: string; title: { content: string } }
      body: { elements: object[] }
    }
    expect(card.schema).toBe('2.0')
    expect(card.header.template).toBe('green')
    expect(card.header.title.content).toContain('提问')
    // Should have button elements (V2: no action wrapper)
    const buttons = card.body.elements.filter((el: any) => el.tag === 'button') as {
      tag: string
      text: { content: string }
      type: string
      behaviors: { type: string; value: object }[]
    }[]
    expect(buttons).toHaveLength(2)
    expect(buttons[0]!.text.content).toBe('A')
    expect(buttons[0]!.type).toBe('primary_filled')
    expect(buttons[0]!.behaviors[0]!.value).toEqual({
      kind: MIRROR_QUESTION_ACTION,
      actionId: 'act1',
      questionId: 'q1',
      label: 'A',
    })
  })

  it('multi-select question degrades to informational', () => {
    const questions: MirrorQuestion[] = [
      { id: 'q1', question: 'Pick many', multiSelect: true, options: [{ label: 'X' }] },
    ]
    const card = mirrorQuestionCard(questions, 'act2') as {
      body: { elements: { tag: string; content?: string }[] }
    }
    // Should NOT have button elements for multi-select
    const buttons = card.body.elements.filter((el: any) => el.tag === 'button')
    expect(buttons).toHaveLength(0)
    // Should have the degradation note
    const markdowns = card.body.elements
      .filter((el: any) => el.tag === 'markdown')
      .map((el: any) => el.content)
      .join('\n')
    expect(markdowns).toContain('GUI')
  })

  it('many options render as one select_static dropdown instead of buttons', () => {
    const options = Array.from({ length: MAX_OPTION_BUTTONS + 1 }, (_, i) => ({ label: `model-${i}` }))
    const questions: MirrorQuestion[] = [{ id: 'q1', question: 'Pick a model', options }]
    const card = mirrorQuestionCard(questions, 'act-select') as {
      body: { elements: any[] }
    }
    expect(card.body.elements.filter(el => el.tag === 'button')).toHaveLength(0)
    const selects = card.body.elements.filter(el => el.tag === 'select_static')
    expect(selects).toHaveLength(1)
    const select = selects[0]!
    expect(select.options).toHaveLength(MAX_OPTION_BUTTONS + 1)
    expect(select.options[0]).toEqual({ text: { tag: 'plain_text', content: 'model-0' }, value: '0' })
    expect(select.options.at(-1)!.value).toBe(String(MAX_OPTION_BUTTONS))
    expect(select.behaviors[0]!.value).toEqual({
      kind: MIRROR_QUESTION_ACTION,
      actionId: 'act-select',
      questionId: 'q1',
    })
  })

  it('options beyond the select_static ceiling degrade to informational', () => {
    const options = Array.from({ length: SELECT_OPTION_LIMIT + 1 }, (_, i) => ({ label: `m${i}` }))
    const questions: MirrorQuestion[] = [{ id: 'q1', question: 'Pick', options }]
    const card = mirrorQuestionCard(questions, 'act-over') as {
      body: { elements: any[] }
    }
    expect(card.body.elements.filter(el => el.tag === 'button')).toHaveLength(0)
    expect(card.body.elements.filter(el => el.tag === 'select_static')).toHaveLength(0)
    const markdowns = card.body.elements
      .filter(el => el.tag === 'markdown')
      .map(el => el.content)
      .join('\n')
    expect(markdowns).toContain('GUI')
  })

  it('question with header shows header as bold', () => {
    const questions: MirrorQuestion[] = [
      { id: 'q1', question: 'Details?', header: 'Confirm' },
    ]
    const card = mirrorQuestionCard(questions, 'act3') as {
      body: { elements: { tag: string; content?: string }[] }
    }
    const markdowns = card.body.elements
      .filter((el: any) => el.tag === 'markdown')
      .map((el: any) => el.content)
    expect(markdowns.some(m => m.includes('**Confirm**'))).toBe(true)
  })
})

describe('settledMirrorQuestionCard', () => {
  it('shows selected label', () => {
    const card = settledMirrorQuestionCard('Option A') as {
      header: { title: { content: string }; template: string }
      body: { elements: { content: string }[] }
    }
    expect(card.header.title.content).toContain('已回答')
    expect(card.header.template).toBe('green')
    expect(card.body.elements[0]!.content).toContain('Option A')
  })
})

describe('MirrorQuestionBridge', () => {
  it('handleAction posts answer and returns settled card', async () => {
    const sent: { target: string; input: object }[] = []
    const updated: { messageId: string; card: object }[] = []
    const fakeFetch = vi.fn().mockResolvedValue({ ok: true, json: async () => ({ accepted: true }) })
    // @ts-expect-error -- mock global fetch
    globalThis.fetch = fakeFetch

    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_chat', { messageId: 'root', threadId: 't1' })

    const bridge = new MirrorQuestionBridge({
      port: {
        send: async (target, input, opts) => { sent.push({ target, input }); return { messageId: 'msg1' } },
        updateCard: async (messageId, card) => { updated.push({ messageId, card }) },
      },
      mirrors,
      notify: () => {},
      hostUrl: 'http://test:3080',
    })

    // Simulate a question arriving (directly call the internal handler via a trick:
    // we'll use handleAction with a pre-seeded pending entry)
    // Seed it by accessing internal state through a card send simulation
    const questions: MirrorQuestion[] = [{ id: 'q1', question: 'Continue?', options: [{ label: 'Yes' }, { label: 'No' }] }]
    // @ts-expect-error -- access private for testing
    bridge.handleQuestionRequested('rpc-123', 's1', questions)

    // Wait for the send to complete
    await new Promise(resolve => setTimeout(resolve, 10))

    // Should have sent a card
    expect(sent).toHaveLength(1)
    expect(sent[0]!.target).toBe('oc_chat')

    // Find the actionId from the sent card (V2: buttons are direct elements with behaviors)
    const cardBody = (sent[0]!.input as { card: any }).card.body
    const buttonEl = cardBody.elements.find((el: any) => el.tag === 'button')
    const actionId = buttonEl.behaviors[0].value.actionId

    // Simulate button click
    const result = await bridge.handleAction({
      kind: MIRROR_QUESTION_ACTION as typeof MIRROR_QUESTION_ACTION,
      actionId,
      questionId: 'q1',
      label: 'Yes',
    })

    expect(result).toBeDefined()
    expect(result!.toast).toEqual({ type: 'success', content: '已回答' })

    // Should have called fetch to POST the answer
    expect(fakeFetch).toHaveBeenCalledWith(
      'http://test:3080/api/respond',
      expect.objectContaining({
        method: 'POST',
        body: expect.stringContaining('rpc-123'),
      }),
    )
    const postedBody = JSON.parse(fakeFetch.mock.calls[0][1].body)
    expect(postedBody.type).toBe('client-response')
    expect(postedBody.rpcId).toBe('rpc-123')
    expect(postedBody.result.value.answer.answers[0]).toEqual({ id: 'q1', selected: ['Yes'] })
  })

  it('handleAction resolves a dropdown pick by option index', async () => {
    const fakeFetch = vi.fn().mockResolvedValue({ ok: true, json: async () => ({ accepted: true }) })
    // @ts-expect-error -- mock global fetch
    globalThis.fetch = fakeFetch

    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_chat', { messageId: 'root', threadId: 't1' })
    const bridge = new MirrorQuestionBridge({
      port: { send: async () => ({ messageId: 'msg1' }), updateCard: async () => {} },
      mirrors,
      notify: () => {},
      hostUrl: 'http://test:3080',
    })
    const options = Array.from({ length: MAX_OPTION_BUTTONS + 4 }, (_, i) => ({ label: `model-${i}` }))
    const questions: MirrorQuestion[] = [{ id: 'q1', question: 'Pick a model', options }]
    // @ts-expect-error -- access private for testing
    bridge.handleQuestionRequested('rpc-select', 's1', questions)
    await new Promise(resolve => setTimeout(resolve, 10))
    // @ts-expect-error -- access private for testing
    const actionId = [...bridge.pending.keys()][0] as string

    const result = await bridge.handleAction(
      { kind: MIRROR_QUESTION_ACTION, actionId, questionId: 'q1' },
      '3',
    )
    expect(result!.toast).toEqual({ type: 'success', content: '已回答' })
    const postedBody = JSON.parse(fakeFetch.mock.calls[0][1].body)
    expect(postedBody.result.value.answer.answers[0]).toEqual({ id: 'q1', selected: ['model-3'] })
  })

  it('handleAction rejects an unresolvable dropdown pick without settling', async () => {
    const fakeFetch = vi.fn()
    // @ts-expect-error -- mock global fetch
    globalThis.fetch = fakeFetch

    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_chat', { messageId: 'root', threadId: 't1' })
    const bridge = new MirrorQuestionBridge({
      port: { send: async () => ({ messageId: 'msg1' }), updateCard: async () => {} },
      mirrors,
      notify: () => {},
      hostUrl: 'http://test:3080',
    })
    const questions: MirrorQuestion[] = [
      { id: 'q1', question: 'Pick', options: Array.from({ length: 9 }, (_, i) => ({ label: `m${i}` })) },
    ]
    // @ts-expect-error -- access private for testing
    bridge.handleQuestionRequested('rpc-bad', 's1', questions)
    await new Promise(resolve => setTimeout(resolve, 10))
    // @ts-expect-error -- access private for testing
    const actionId = [...bridge.pending.keys()][0] as string

    for (const option of [undefined, '99', 'x']) {
      const result = await bridge.handleAction(
        { kind: MIRROR_QUESTION_ACTION, actionId, questionId: 'q1' },
        option,
      )
      expect(result!.toast).toEqual({ type: 'error', content: '选项无法识别' })
    }
    expect(fakeFetch).not.toHaveBeenCalled()
    // The question stays pending: a bad pick must not consume it.
    const ok = await bridge.handleAction(
      { kind: MIRROR_QUESTION_ACTION, actionId, questionId: 'q1' },
      '1',
    )
    expect(ok!.toast).toEqual({ type: 'success', content: '已回答' })
  })

  it('handleAction returns expired toast for unknown actionId', async () => {
    const mirrors = new MirrorBindings()
    const bridge = new MirrorQuestionBridge({
      port: { send: async () => ({ messageId: 'x' }), updateCard: async () => {} },
      mirrors,
      notify: () => {},
    })
    const result = await bridge.handleAction({
      kind: MIRROR_QUESTION_ACTION as typeof MIRROR_QUESTION_ACTION,
      actionId: 'unknown',
      questionId: 'q1',
      label: 'X',
    })
    expect(result!.toast).toEqual({ type: 'info', content: '问题已过期' })
  })

  it('ignores questions for unbound sessions', () => {
    const sent: object[] = []
    const mirrors = new MirrorBindings()
    const bridge = new MirrorQuestionBridge({
      port: { send: async (t, i) => { sent.push(i); return { messageId: 'x' } }, updateCard: async () => {} },
      mirrors,
      notify: () => {},
    })
    // @ts-expect-error -- access private
    bridge.handleQuestionRequested('rpc-1', 'unbound-session', [{ id: 'q', question: 'X' }])
    expect(sent).toHaveLength(0)
  })
})

describe('mirrorPlanReviewCard', () => {
  it('renders plan-review card with heading and buttons', () => {
    const question: MirrorQuestion = {
      id: 'plan-review',
      header: '实施方案',
      question: '上面这份计划可以开始执行吗？',
      detail: '# 实施方案\n\n1. 第一步\n2. 第二步\n3. 第三步',
      intent: { kind: 'plan-review', approve: '批准，开始执行' },
      options: [
        { label: '批准，开始执行', description: '离开规划模式' },
        { label: '继续规划', description: '留在规划模式' },
      ],
    }
    const card = mirrorPlanReviewCard(question, 'act-plan') as {
      schema: string
      header: { title: { content: string }; template: string }
      body: { elements: any[] }
    }
    expect(card.schema).toBe('2.0')
    expect(card.header.template).toBe('violet')
    expect(card.header.title.content).toContain('实施方案')
    // Should have buttons
    const buttons = card.body.elements.filter((el: any) => el.tag === 'button')
    expect(buttons).toHaveLength(2)
    expect(buttons[0]!.text.content).toBe('批准，开始执行')
    expect(buttons[0]!.type).toBe('primary_filled')
    expect(buttons[1]!.text.content).toBe('继续规划')
    expect(buttons[1]!.type).toBe('default')
    // Should have detail summary
    const markdowns = card.body.elements.filter((el: any) => el.tag === 'markdown')
    const allContent = markdowns.map((el: any) => el.content).join('\n')
    expect(allContent).toContain('第一步')
    // Should have GUI fallback note
    expect(allContent).toContain('GUI')
  })

  it('extracts URLs from plan detail', () => {
    const question: MirrorQuestion = {
      id: 'plan-review',
      header: '方案',
      question: '确认吗？',
      detail: '参考 https://example.com/doc 和 https://other.com/page',
      intent: { kind: 'plan-review', approve: 'Approve' },
      options: [{ label: 'Approve' }, { label: 'Keep planning' }],
    }
    const card = mirrorPlanReviewCard(question, 'act-url') as {
      body: { elements: any[] }
    }
    const markdowns = card.body.elements.filter((el: any) => el.tag === 'markdown')
    const allContent = markdowns.map((el: any) => el.content).join('\n')
    expect(allContent).toContain('https://example.com/doc')
    expect(allContent).toContain('https://other.com/page')
    expect(allContent).toContain('链接')
  })

  it('truncates long plan detail', () => {
    const question: MirrorQuestion = {
      id: 'plan-review',
      question: '确认吗？',
      detail: 'x'.repeat(2000),
      intent: { kind: 'plan-review', approve: 'Yes' },
      options: [{ label: 'Yes' }],
    }
    const card = mirrorPlanReviewCard(question, 'act-long') as {
      body: { elements: any[] }
    }
    const markdowns = card.body.elements.filter((el: any) => el.tag === 'markdown')
    const allContent = markdowns.map((el: any) => el.content).join('\n')
    expect(allContent).toContain('…')
    // Should not contain the full 2000 chars
    expect(allContent.length).toBeLessThan(2000)
  })
})

describe('MirrorQuestionBridge plan-review routing', () => {
  it('sends a plan-review card for plan-review intent', async () => {
    const sent: { target: string; input: object }[] = []
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_chat')

    const bridge = new MirrorQuestionBridge({
      port: {
        send: async (target, input) => { sent.push({ target, input }); return { messageId: 'msg1' } },
        updateCard: async () => {},
      },
      mirrors,
      notify: () => {},
    })

    const questions: MirrorQuestion[] = [{
      id: 'plan-review',
      header: '实施方案',
      question: '确认吗？',
      detail: '# 方案\n1. 步骤一',
      intent: { kind: 'plan-review', approve: '批准' },
      options: [{ label: '批准' }, { label: '继续规划' }],
    }]
    // @ts-expect-error -- access private
    bridge.handleQuestionRequested('rpc-plan', 's1', questions)
    await new Promise(resolve => setTimeout(resolve, 10))

    expect(sent).toHaveLength(1)
    const card = (sent[0]!.input as { card: any }).card
    // Should be a plan-review card (violet template) not a generic question card (green template)
    expect(card.header.template).toBe('violet')
    expect(card.header.title.content).toContain('实施方案')
  })

  it('sends a generic card for non-plan-review questions', async () => {
    const sent: { target: string; input: object }[] = []
    const mirrors = new MirrorBindings()
    await mirrors.bind('s1', 'oc_chat')

    const bridge = new MirrorQuestionBridge({
      port: {
        send: async (target, input) => { sent.push({ target, input }); return { messageId: 'msg1' } },
        updateCard: async () => {},
      },
      mirrors,
      notify: () => {},
    })

    const questions: MirrorQuestion[] = [{
      id: 'q1',
      header: '选择模型',
      question: '用哪个模型？',
      options: [{ label: 'A' }, { label: 'B' }],
    }]
    // @ts-expect-error -- access private
    bridge.handleQuestionRequested('rpc-generic', 's1', questions)
    await new Promise(resolve => setTimeout(resolve, 10))

    expect(sent).toHaveLength(1)
    const card = (sent[0]!.input as { card: any }).card
    expect(card.header.template).toBe('green')
  })
})
