/**
 * Tests for the workspaceScope feature: session key and workspace key can differ.
 */
import { describe, it, expect } from 'vitest'
import { ChatWorkspaces } from './workspace.ts'

describe('ChatWorkspaces dual-key', () => {
  const makeStore = (entries: Record<string, string> = {}) => new ChatWorkspaces({
    defaultPath: '/default',
    entries,
    probe: (path) => ({ canonical: path }),
  })

  it('single key (backward compat): sessionIdFor(k) === sessionIdFor(k, k)', () => {
    const store = makeStore({ topic1: '/project-a' })
    expect(store.sessionIdFor('topic1')).toBe(store.sessionIdFor('topic1', 'topic1'))
    expect(store.sessionIdFor('topic2')).toBe(store.sessionIdFor('topic2', 'topic2'))
  })

  it('dual key: same sessionKey, different workspaceKey → different session ids', () => {
    const store = makeStore({ groupA: '/project-a', groupB: '/project-b' })
    const id1 = store.sessionIdFor('topic1', 'groupA')
    const id2 = store.sessionIdFor('topic1', 'groupB')
    expect(id1).not.toBe(id2)
  })

  it('dual key: different sessionKey, same workspaceKey → different session ids (different topic)', () => {
    const store = makeStore({ group: '/project-a' })
    const id1 = store.sessionIdFor('topic1', 'group')
    const id2 = store.sessionIdFor('topic2', 'group')
    expect(id1).not.toBe(id2)
  })

  it('dual key: same sessionKey + workspaceKey → same session id (stable)', () => {
    const store = makeStore({ group: '/project-a' })
    expect(store.sessionIdFor('topic1', 'group')).toBe(store.sessionIdFor('topic1', 'group'))
  })

  it('pathFor uses workspaceKey, not sessionKey', () => {
    const store = makeStore({ group: '/project-a' })
    // pathFor takes one key (the workspace key)
    expect(store.pathFor('group')).toBe('/project-a')
    expect(store.pathFor('topic1')).toBe('/default') // topic1 not in entries
  })

  it('isDefault uses workspaceKey', () => {
    const store = makeStore({ group: '/project-a' })
    expect(store.isDefault('group')).toBe(false)
    expect(store.isDefault('unknown-topic')).toBe(true)
  })

  it('workspaceKey default → session id same as default workspace', () => {
    const store = makeStore()
    // No entries, so both topic-key and group-key resolve to default path
    // sessionIdFor(topic, group) with default path should equal sessionIdFor(topic) 
    expect(store.sessionIdFor('topic1', 'group')).toBe(store.sessionIdFor('topic1'))
  })
})
