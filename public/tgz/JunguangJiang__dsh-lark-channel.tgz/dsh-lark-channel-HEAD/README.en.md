# dsh-lark · DeepSeek Harness plugin for Feishu / Lark

[![npm](https://img.shields.io/npm/v/dsh-lark-channel)](https://www.npmjs.com/package/dsh-lark-channel) [![CI](https://github.com/omdsh-dev/dsh-lark/actions/workflows/ci.yml/badge.svg)](https://github.com/omdsh-dev/dsh-lark/actions/workflows/ci.yml) [![license](https://img.shields.io/badge/license-BSD--3--Clause-blue)](LICENSE)

English | [简体中文](README.md)

**Put the DeepSeek Harness you already run into Feishu/Lark.**

Hand your agent work from the chat, watch it run, switch workspace and model as you go. Questions, plan reviews, and tool approvals come back to the same conversation, so nothing sends you to a terminal. When it helps, put several agents in one group and let them work together.

## Quickstart

```sh
npm i -g dsh-lark-channel
dsh-lark-channel start
```

A QR code appears in the terminal. Scan it in Feishu to create the app, then DM the bot or @-mention it in a group.

Prefer to install nothing? Run it through npx instead — every later command then carries the same prefix:

```sh
npx dsh-lark-channel@latest start
```

If DeepSeek Harness itself is not installed yet:

```sh
npm i -g @deepseek-ai/dsh
```

No public server, no callback URL.

## Why bother

- **Nothing to sit and watch.** Start the work from Feishu and check on it whenever.
- **More than a chatbot.** It switches real workspaces and models, and runs the commands and tools your Harness already has.
- **The decisions stay yours.** Model questions, plan reviews, and tool approvals land in the chat; a button or a sentence answers them.
- **Contexts stay apart.** Each chat, topic, and workspace keeps its own session.
- **Agents can work together.** One command adds another bot; in a group they hand the turn over by @-mentioning each other, with a hop limit that stops an endless exchange.

## A first run

Look around:

```text
/status
/ws
/cd my-project
/model
```

Then give it something to do:

```text
Find out why this project fails to build. Plan it first, and check with me before changing anything.
```

The work shows up in Feishu as it happens, and anything needing you arrives as a question, a plan, or an approval card. This channel's own wording renders in each reader's Feishu language.

## What it does

| Capability | What you get |
|---|---|
| Durable sessions | Survive a restart; the next message continues where you were, and `/new` starts over in place |
| Workspaces | `/ws` lists, `/cd` switches; returning to one resumes the work you left there |
| Model switching | `/model` opens a picker; the session and its context carry over, and the default is one press away |
| Native run view | Reasoning, tool calls, and results as a thinking process, with the answer sent on its own |
| Cards that ask | Single or multiple choice, or type an answer; approve a plan or send feedback; allow or refuse a tool call |
| Live status | `/status` shows workspace, model, and session — plus context occupancy and token totals where the host meters them — and refreshes in place |
| Session scope | One agent per chat, per topic thread, or per person in a shared chat |
| Several agents | Each bot keeps its own settings, credential, and sessions, and two of them can talk in one group |
| Global question routing | Wraps the `ctx.userQuestions` provider so Lark-bound sessions get card prompts; others pass through to the Web BFF |
| Slash commands | Host commands (`/plan`, `/compact`, `/permission`, …) run straight through the DSH command runtime |
| Session mirroring | A GUI session bound via `/lark` forwards user messages, assistant replies, plan reviews, command events, and question cards to Feishu in real time |

## Commands

| Command | What it does |
|---|---|
| `/status` | Show and refresh workspace, model, and session; context and tokens where available |
| `/ws` | List the workspaces this channel can reach |
| `/cd <name or path>` | Switch this conversation's workspace |
| `/model` | Open the model picker |
| `/model use <provider/model>` | Switch without opening a card |
| `/model reset` | Back to the deployment default |
| `/new` | Start a fresh session in place; workspace and model stay |
| `/stop` | Stop the running task |
| `/help` | Everything this chat accepts, host commands included |

## Running it

On macOS and systemd Linux the bot runs as a user service, so closing the terminal leaves it up:

```sh
dsh-lark-channel status
dsh-lark-channel logs -f
dsh-lark-channel restart
dsh-lark-channel stop
```

Started through npx, those same commands carry the `npx dsh-lark-channel@latest` prefix — the tool prints whichever form you are using, so what you read is what you can paste.

To upgrade:

```sh
dsh-lark-channel upgrade
```

That installs the newest CLI and restarts the bot on it. Through npx there is nothing to upgrade — `npx dsh-lark-channel@latest start` already runs the newest — and either way `start` and `status` mention a newer release when one exists.

When the connection drops, the channel rebuilds its WebSocket under a quota and a backoff, so a live process is never a silently dead bot.

### More agents

Give a second Feishu app its own agent:

```sh
dsh-lark-channel add reviewer
```

It writes the new row, restarts, and shows that bot's QR code. Once scanned it has its own settings, app secret, and sessions — nothing shared with the first.

Put both in one group and they hand the turn over by mentioning each other: one finishes a change and @s the reviewer, who can @ back for another pass. Six consecutive bot turns by default, and anyone speaking refills that. To take one out:

```sh
dsh-lark-channel remove reviewer
```

Its credential and settings stay, so adding the same name back reaches the same bot.

To run Feishu inside the profile `dsh web` already uses:

```sh
dsh plugin --profile web add dsh-lark-channel@latest
dsh web
```

<details>
<summary>Permissions and advanced options</summary>

- The app's visibility scope decides who can reach the bot at all; `senderAllowlist`, `groupAllowlist`, and `approvers` narrow it further.
- `workspaceRoots` fences the directories a chat may switch into.
- `sessionScope` is `chat`, `chat-thread`, or `chat-sender`.
- `instance` names an extra bot row; the first stays unnamed, which keeps its settings and sessions exactly where they are.
- `botPeers` restricts which bots are answered; `botHops` bounds consecutive bot turns (six).
- Groups only answer @-mentions by default (`requireMention`); with `mentionFreeFollowUp` on, follow-ups inside a topic thread whose session is already bound no longer need the @.
- A card that changes state is bound to the chat it was sent to: forwarded elsewhere, it governs nothing.
- Where the deployment composes a credentials service, the scanned app secret is stored there; one written into settings by an older version moves on the next boot.
- Image input is off by default: turn on `attachImages` only for a model you know accepts images.
- Configuration is read at startup; changing it needs a restart.

</details>

## Architecture: UserQuestions Wrapper Provider

The plugin installs a Wrapper Provider on the `ctx.userQuestions` service after bridge initialization:

1. **Timing**: external bundle plugins load after `@deepseek-ai/dsh-host-apiproxy` (the Web BFF), which registers the sole Provider during `ApiProxyService` construction. The plugin cannot "race" ahead to claim the slot.
2. **Strategy**: after the bridge installs, it replaces `service.provider` (a regular JS property, not a `#private` field) with a routing layer:
   - The request's `agent.session.id` is found in the `bySession` Map → session is bound to a Lark conversation → send interactive cards via `ChatQuestions` and wait.
   - Not found → delegate to the original Web BFF Provider (`original.ask(request)`).
3. **Teardown**: the original Provider is restored when the fiber disposes, leaving no side effects.

Effect: any `ctx.userQuestions.ask()` call — including mirror sessions and future code paths — is automatically routed to Lark cards for bound sessions without per-agent shadow-tool configuration. Existing per-agent tool shadowing remains as a fast path within the same session.

## Resource Boundary with plan-board / lark-watch

This plugin and `plan-board` (`/lark-watch` command) share the same Feishu app. Resource ownership:

| Resource | Owner | Notes |
|---|---|---|
| Event long connection (WebSocket) | **dsh-lark-channel (exclusive)** | Feishu allows one long connection per app; this plugin establishes and maintains it in `port.connect()`. External plugins must not open a second one — the platform would disconnect the first. |
| IM messaging | dsh-lark-channel | All chat messages are received through this plugin's long connection and sent via its `port.send()`. `plan-board`'s document collaboration results return through the host command channel. |
| Document comment read/write | plan-board | `/lark-watch` reads and writes document comments through the Feishu OpenAPI, independent of the long connection. |
| App API quota | Shared | API calls from both plugins count toward the same app's rate limits. |

In practice: users run `/lark-watch process` in the GUI, or say a trigger phrase (e.g. "开始处理" → `/lark-watch process`) in a mirror chat. Trigger phrases are configured via `triggerPhrases`.

## Requirements

- Node.js `^22.19.0 || >=24`
- DeepSeek Harness `0.1.0-rc.6` or newer
- A Feishu or Lark tenant

A native thinking process needs Feishu PC 7.70 / mobile 7.74 or newer; older clients can use `output: 'stream'`.

## Development

```sh
pnpm install
pnpm test
pnpm build
```

## License

[BSD-3-Clause](LICENSE)

An unofficial community plugin, not affiliated with, authorized by, or endorsed by DeepSeek, Feishu, or Lark.
