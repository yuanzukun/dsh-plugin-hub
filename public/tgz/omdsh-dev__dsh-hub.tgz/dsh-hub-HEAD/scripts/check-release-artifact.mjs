#!/usr/bin/env node

import { execFileSync } from 'node:child_process'
import { readFileSync } from 'node:fs'

const manifest = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
if (!manifest.keywords?.includes('dsh-plugin')) {
  throw new Error('package discovery keyword dsh-plugin is missing')
}

const output = execFileSync('npm', ['pack', '--dry-run', '--ignore-scripts', '--json'], {
  encoding: 'utf8',
  env: { ...process.env, NPM_TOKEN: process.env.NPM_TOKEN ?? 'release-check-placeholder' },
})
const result = JSON.parse(output)[0]
if (!result || !Array.isArray(result.files)) throw new Error('npm pack did not return a file manifest')

const forbidden = [
  /^package\/\.npmrc$/,
  /^package\/\.env(?:\.|$)/,
  /^package\/package-lock\.json$/,
  /(?:^|\/)node_modules(?:\/|$)/,
  /\.tgz$/,
]
const leaked = result.files.map((entry) => `package/${entry.path}`).filter((file) => forbidden.some((rule) => rule.test(file)))
if (leaked.length > 0) throw new Error(`forbidden release files: ${leaked.join(', ')}`)

console.log(`release artifact verified: ${result.files.length} files, ${result.size} bytes`)
