#!/usr/bin/env node

import { createHash } from 'node:crypto'
import { readFile, rename, writeFile } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

import { assertAgentEcosystemRegistry, parseAgentEcosystem } from '../dist/agent-ecosystem.mjs'
import { assertRecipesRegistry, parseRecipes } from '../dist/recipes.mjs'
import { parseRegistry, REGISTRY_ORIGINS } from '../dist/registry.mjs'

const sourceDirectory = process.argv[2]
if (sourceDirectory === undefined) {
  throw new Error('usage: npm run workshop:vendor -- /path/to/dsh-hub-workshop')
}

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const source = resolve(sourceDirectory)
const registry = parseRegistry(JSON.parse(await readFile(join(source, 'registry-v1.json'), 'utf8')), { allowUnsigned: true })
if (registry.signature !== null) throw new Error('the vendored Registry must be the reproducible unsigned Workshop artifact')
if (JSON.stringify(registry.origins) !== JSON.stringify(REGISTRY_ORIGINS)) {
  throw new Error('Workshop Registry origins do not match the Hub consumer contract')
}
const recipes = assertRecipesRegistry(
  parseRecipes(JSON.parse(await readFile(join(source, 'recipes-v1.json'), 'utf8'))),
  registry,
)
const ecosystem = assertAgentEcosystemRegistry(
  parseAgentEcosystem(JSON.parse(await readFile(join(source, 'agent-ecosystem-v1.json'), 'utf8'))),
  registry,
)

const content = (value) => `${JSON.stringify(value, null, 2)}\n`
const digest = (value) => `sha256:${createHash('sha256').update(value).digest('hex')}`
const documents = {
  'registry-v1.json': { schema: registry.schema, content: content(registry) },
  'recipes-v1.json': { schema: recipes.schema, content: content(recipes) },
  'agent-ecosystem-v1.json': { schema: ecosystem.schema, content: content(ecosystem) },
}
const lock = {
  schema: 'omdsh-hub-workshop-snapshot-lock/v1',
  authority: 'read-only-derived-snapshot',
  producer: {
    product: 'DSH Hub Workshop',
    repository: 'https://github.com/omdsh-dev/dsh-hub-workshop',
  },
  registry: {
    schema: registry.schema,
    snapshotId: registry.snapshotId,
    revision: registry.revision,
  },
  feeds: Object.fromEntries(Object.entries(documents).map(([path, value]) => [path, {
    schema: value.schema,
    digest: digest(value.content),
  }])),
}

const dist = join(root, 'dist')
const pending = []
for (const [path, value] of Object.entries(documents)) {
  const target = join(dist, path)
  const temporary = `${target}.${process.pid}.tmp`
  await writeFile(temporary, value.content, { mode: 0o644 })
  pending.push([temporary, target])
}
const lockTarget = join(dist, 'workshop-snapshot-lock.json')
const lockTemporary = `${lockTarget}.${process.pid}.tmp`
await writeFile(lockTemporary, content(lock), { mode: 0o644 })
for (const [temporary, target] of pending) await rename(temporary, target)
await rename(lockTemporary, lockTarget)

console.log(`vendored one locked Workshop snapshot: ${registry.snapshotId}`)
