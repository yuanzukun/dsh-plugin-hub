#!/usr/bin/env node

import { createHash } from 'node:crypto'
import { readFile, stat } from 'node:fs/promises'

import { parseRegistry, REGISTRY_ORIGINS } from '../dist/registry.mjs'
import { assertRecipesRegistry, parseRecipes } from '../dist/recipes.mjs'
import { assertAgentEcosystemRegistry, parseAgentEcosystem } from '../dist/agent-ecosystem.mjs'

const file = new URL('../dist/registry-v1.json', import.meta.url)
const document = parseRegistry(JSON.parse(await readFile(file, 'utf8')), { allowUnsigned: true })
if (document.signature !== null) throw new Error('bundled Registry must remain unsigned and reproducible')
if (JSON.stringify(document.origins) !== JSON.stringify(REGISTRY_ORIGINS)) {
  throw new Error('bundled Registry origins do not match the Runtime contract')
}
console.log(`bundled Registry accepted: ${document.entries.length} entries, ${(await stat(file)).size} bytes, ${document.snapshotId}`)

const recipesFile = new URL('../dist/recipes-v1.json', import.meta.url)
const recipes = assertRecipesRegistry(
  parseRecipes(JSON.parse(await readFile(recipesFile, 'utf8'))),
  document,
)
console.log(`bundled Recipes accepted: ${recipes.recipes.length} entries, ${(await stat(recipesFile)).size} bytes, ${recipes.registry.snapshotId}`)

const ecosystemFile = new URL('../dist/agent-ecosystem-v1.json', import.meta.url)
const ecosystem = assertAgentEcosystemRegistry(
  parseAgentEcosystem(JSON.parse(await readFile(ecosystemFile, 'utf8'))),
  document,
)
console.log(`bundled Agent ecosystem accepted: ${ecosystem.projects.length} projects, ${(await stat(ecosystemFile)).size} bytes, ${ecosystem.registry.snapshotId}`)

const lock = JSON.parse(await readFile(new URL('../dist/workshop-snapshot-lock.json', import.meta.url), 'utf8'))
if (lock?.schema !== 'omdsh-hub-workshop-snapshot-lock/v1'
  || lock?.authority !== 'read-only-derived-snapshot'
  || lock?.producer?.product !== 'DSH Hub Workshop'
  || lock?.producer?.repository !== 'https://github.com/omdsh-dev/dsh-hub-workshop'
  || lock?.registry?.schema !== document.schema
  || lock?.registry?.snapshotId !== document.snapshotId
  || lock?.registry?.revision !== document.revision) {
  throw new Error('bundled Workshop snapshot lock has invalid provenance')
}
const expectedFeeds = {
  'registry-v1.json': document.schema,
  'recipes-v1.json': recipes.schema,
  'agent-ecosystem-v1.json': ecosystem.schema,
}
if (Object.keys(lock.feeds ?? {}).sort().join(',') !== Object.keys(expectedFeeds).sort().join(',')) {
  throw new Error('bundled Workshop snapshot lock has an unexpected feed set')
}
for (const [path, schema] of Object.entries(expectedFeeds)) {
  const bytes = await readFile(new URL(`../dist/${path}`, import.meta.url))
  const digest = `sha256:${createHash('sha256').update(bytes).digest('hex')}`
  if (lock.feeds[path]?.schema !== schema || lock.feeds[path]?.digest !== digest) {
    throw new Error(`bundled Workshop snapshot lock does not match ${path}`)
  }
}
console.log('bundled Workshop snapshot provenance and digests accepted')
