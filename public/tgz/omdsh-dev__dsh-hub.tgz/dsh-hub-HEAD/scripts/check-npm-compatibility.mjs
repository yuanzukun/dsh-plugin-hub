#!/usr/bin/env node

import { readFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)

const matrix = Object.freeze({
  '@deepseek-ai/cordis': '4.0.1-rc.4',
  '@deepseek-ai/dsh-client-locale': '0.0.1-rc.5',
  '@deepseek-ai/dsh-client-runtime': '0.0.1-rc.5',
  '@deepseek-ai/dsh-client-ui-settings': '0.0.1-rc.5',
  '@deepseek-ai/dsh-client-ui-slots': '0.0.1-rc.5',
  '@deepseek-ai/dsh-host-webserver': '0.0.1-rc.5',
})

async function installedPackage(name) {
  const packageFile = require.resolve(`${name}/package.json`)
  const manifest = JSON.parse(await readFile(packageFile, 'utf8'))
  const expected = matrix[name]
  if (manifest.version !== expected) {
    throw new Error(`${name}: expected ${expected}, resolved ${manifest.version}`)
  }
  return { directory: dirname(packageFile), manifest }
}

async function assertFile(packageInfo, relative, patterns) {
  const file = join(packageInfo.directory, relative)
  const content = await readFile(file, 'utf8')
  for (const pattern of patterns) {
    if (!pattern.test(content)) throw new Error(`${file}: missing ${pattern}`)
  }
}

const packages = Object.fromEntries(await Promise.all(Object.keys(matrix).map(async (name) => [
  name,
  await installedPackage(name),
])))

await assertFile(packages['@deepseek-ai/cordis'], 'lib/types/fiber.d.ts', [
  /ACTIVE\s*=\s*2/,
  /await\(\):\s*Promise<this>/,
])
await assertFile(packages['@deepseek-ai/cordis'], 'lib/types/registry.d.ts', [
  /inject\(deps:\s*Inject/,
  /entries\(\):\s*MapIterator/,
])
await assertFile(packages['@deepseek-ai/dsh-host-webserver'], 'lib/types/index.d.ts', [
  /interface Context\s*{[^}]*webServer:\s*WebServer/s,
  /register\(route:\s*WebRoute\):\s*\(\)\s*=>\s*void/,
])
await assertFile(packages['@deepseek-ai/dsh-client-runtime'], 'lib/types/client/index.d.ts', [
  /interface Context\s*{[^}]*slots:/s,
])
await assertFile(packages['@deepseek-ai/dsh-client-runtime'], 'lib/types/client/slots.d.ts', [
  /inject\(key:[^\n]+callback:[^\n]+\):\s*\(\)\s*=>\s*void/,
])
await assertFile(packages['@deepseek-ai/dsh-client-ui-settings'], 'lib/types/client/contract/slots.d.ts', [
  /['"]settings\.section['"]:/,
])
await assertFile(packages['@deepseek-ai/dsh-client-locale'], 'lib/types/client/index.d.ts', [
  /register\(ns:\s*string,\s*locale:\s*string,\s*dict:\s*LocaleDict\)/,
  /bind\(ns:\s*string\):\s*Translate/,
])

const absentRuntimePackages = [
  '@deepseek-ai/dsh-repository-plugin',
  '@deepseek-ai/dsh-tool-browser',
]
for (const name of absentRuntimePackages) {
  try {
    require.resolve(`${name}/package.json`)
    throw new Error(`${name}: unexpectedly installed; review the guided-only release boundary`)
  } catch (error) {
    if (error?.code !== 'MODULE_NOT_FOUND') throw error
  }
}

console.log(`npm compatibility matrix verified: ${Object.keys(matrix).length} exact packages`)
