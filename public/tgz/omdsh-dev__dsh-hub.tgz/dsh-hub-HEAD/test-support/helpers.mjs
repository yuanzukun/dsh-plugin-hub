import { mkdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'

export const OFFICIAL_REPOSITORY_CONFIG_DUMP = `
- id: root
  name: cordis:root
  config:
    - id: repository-plugins
      name: '@deepseek-ai/dsh-repository-plugin'
`

export function successfulOfficialResult(args, overrides = {}) {
  return {
    code: 0,
    signal: null,
    stdout: args.includes('--dump-default-config') ? OFFICIAL_REPOSITORY_CONFIG_DUMP : '',
    stderr: '',
    ...overrides,
  }
}

export async function createProfile(home, name = 'web', options = {}) {
  const directory = join(home, 'profiles', name)
  await mkdir(directory, { recursive: true })
  const manifest = {
    name: `profile-${name}`,
    private: true,
    dependencies: { ...(options.dependencies ?? {}) },
    dsh: { profile: { bundles: [...(options.bundles ?? ['@deepseek-ai/dsh-base'])] } },
  }
  await writeFile(join(directory, 'package.json'), `${JSON.stringify(manifest, null, 2)}\n`)
  await writeFile(join(directory, 'pnpm-lock.yaml'), "lockfileVersion: '9.0'\n")
  await writeFile(join(directory, 'cordis.patch.yml'), '[]\n')
  return directory
}
