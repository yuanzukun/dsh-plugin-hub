import { writeFile } from 'node:fs/promises'
import { join } from 'node:path'

import { registrySnapshotId } from '../dist/registry.mjs'

const generatedAt = '2026-08-13T00:00:00.000Z'
const ref = '1'.repeat(40)

function entry(id, mode) {
  const source = {
    repository: `https://github.com/example/${id}`,
    ref,
    path: null,
  }
  const compatibility = { declared: 'npm-next fixture' }
  const install = mode === 'profile-bundle'
    ? { mode, adapter: 'official-profile/v1', packageName: `@example/${id}`, spec: '1.0.0' }
    : { mode, adapter: 'official-repository/v1', spec: `github:example/${id}#${ref}&path:/plugins/example/.dsh-plugin` }
  const releaseId = `${id}@1.0.0`
  return {
    id,
    displayName: id,
    description: 'A deterministic public test fixture.',
    kind: 'extension',
    tags: ['fixture'],
    author: { name: 'Example', url: 'https://example.com/' },
    version: '1.0.0',
    license: 'MIT',
    source,
    compatibility,
    risk: {
      level: 'unknown',
      facts: {
        sourcePinned: true,
        vulnerabilityScan: 'unknown',
        permissions: 'unknown',
        nativeCode: 'unknown',
        installScripts: 'unknown',
      },
    },
    listing: { state: 'reviewed', catalogStatus: 'verified', trustedPublisher: 'unknown' },
    maintenance: { state: 'active', notice: null, successor: null },
    install,
    latestRelease: releaseId,
    releases: [{
      id: releaseId,
      version: '1.0.0',
      ref,
      updatedAt: generatedAt,
      channel: 'beta',
      source,
      compatibility,
      install,
    }],
    links: {
      atlas: `https://example.invalid/catalog/${id}`,
      repository: `https://github.com/example/${id}/tree/${ref}`,
    },
  }
}

export async function createRegistryFixture(directory) {
  const document = {
    schema: 'omdsh-registry/v1',
    revision: Date.parse(generatedAt),
    generatedAt,
    origins: ['https://primary.example/registry.json', 'https://fallback.example/registry.json'],
    entries: [
      entry('example-bundle', 'profile-bundle'),
      entry('example-repository', 'repository-plugin'),
    ],
    collections: [],
    snapshotId: '',
    signature: null,
  }
  document.snapshotId = registrySnapshotId(document)
  const filename = join(directory, 'registry.json')
  await writeFile(filename, `${JSON.stringify(document, null, 2)}\n`)
  return { document, filename }
}
