# Security / 安全

## 中文

请不要通过公开 Issue 披露漏洞、Token、Registry 私钥或可识别用户的数据；请使用仓库的安全报告渠道或直接联系维护者。

报告请包含受影响的固定 commit、复现条件、实际权限边界，以及问题发生在 generation/Registry 管理层还是第三方扩展的外部副作用中。OMDSH 可以恢复 Profile 制品和选择状态，但不承诺撤销插件已经执行的文件、数据库或远端 API 写入。

## English

Do not disclose vulnerabilities, tokens, Registry private keys, or identifiable user data in a public Issue. Use the repository's security-reporting channel or contact the maintainers directly.

Include the affected pinned commit, reproduction conditions, effective privilege boundary, and whether the issue belongs to generation/Registry management or to external side effects already performed by an extension. OMDSH restores Profile artifacts and selection state; it cannot promise reversal of file, database, or remote API writes made by plugin code.
