# Contributing / 贡献

## 中文

本项目只补足官方 Harness 尚未提供的社区事务与市场能力。变更不得引入第二套 Loader、第二份 Bundle 启用状态、常驻 daemon，或复制上游实现源码。

提交前运行：

```sh
npm ci --ignore-scripts
npm run validate
npm run pack:check
```

`@deepseek-ai` 开发包需要 registry 只读权限。真实的短期令牌只能放在进程环境与
本机 npm 配置中；不要向仓库加入 `.npmrc`、凭据、下载的包归档或 npm 日志。

上游相关假设必须收敛到版本化 adapter，并附聚焦测试。Registry 变更必须通过 Atlas 生成，再使用 `npm run registry:vendor -- <file>` 固定；不要手改摘要、签名或安装 intent。中英文文档和界面文案必须配对更新。

## English

This project adds community transaction and marketplace capabilities around the official Harness. Changes must not introduce a second Loader, a second source of Bundle enabled state, a resident daemon, or copied host implementation code.

Before submitting, run:

```sh
npm ci --ignore-scripts
npm run validate
npm run pack:check
```

The `@deepseek-ai` development packages require read access. Keep the concrete
short-lived token in the process environment and local npm configuration; do
not add `.npmrc`, credentials, downloaded package archives, or npm logs to the
repository.

Keep upstream-dependent assumptions inside a versioned adapter with focused tests. Generate Registry changes in Atlas and pin them with `npm run registry:vendor -- <file>`; never hand-edit digests, signatures, or install intents. Update Chinese and English documentation and UI copy together.
