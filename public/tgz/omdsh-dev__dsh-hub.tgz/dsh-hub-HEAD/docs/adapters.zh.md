# Harness Adapter

## `official-v2`

`dist/adapters/official-v2.*` 隔离面向 Host 的契约；本候选使用 npm `next` 的
`@deepseek-ai/cordis@4.0.1-rc.4` 与
`@deepseek-ai/dsh-host-webserver@0.0.1-rc.5` 校验，只记录 OMDSH Hub 使用的接入面：

- Profile Bundle：`dsh.profile.bundles`
- Bundle patch：`dsh.bundle.patch`
- Client manifest：`dsh.client`
- Client platform：`web`
- 设置 slot：`settings.section`
- Host 路由服务：`webServer`
- Cordis fiber ACTIVE 状态：`2`

Adapter 通过 `ctx.inject(['webServer'])` 注册管理路由，并只在 Cordis registry settle 且所有已启用 fiber 都为 ACTIVE 后确认运行时就绪。Repository Plugin 探测保持失败关闭：本次校验时 npm 尚无对应包，缺少配置行时只能走引导式集成。

本发布候选不包含旧版契约 adapter 和已弃用的 Client manifest 别名。

## Repository 配置

`repository-config-v1` 只对官方 Repository Plugin 行执行窄、类型化的修改。它不会执行 YAML tag 或嵌入代码；找不到预期结构时会失败关闭。
