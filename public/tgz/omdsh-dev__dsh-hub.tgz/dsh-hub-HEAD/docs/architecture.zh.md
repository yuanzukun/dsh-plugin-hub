# 架构

OMDSH Hub 分为四层：

1. 预构建 Client 提供“扩展”设置页。
2. 仅限 loopback 的管理 API 把界面操作转换为类型化 manager 操作。
3. Manager 把变更暂存到物理 Profile generation，并把包操作委托给官方 `dsh` 命令。
4. Registry、Recipe 和 Ecosystem client 提供严格解析的发现元数据。

选中的 generation 通过原子操作切换。Launcher boot token 把就绪确认绑定到一个 candidate，状态中只保存 token 摘要。`official-v2` adapter 等待官方 Loader，并在所有已启用 Cordis fiber 都为 ACTIVE 后确认 candidate。

Registry 数据使用原子 last-good 缓存。内置离线数据始终可用；远程数据只接受已配置 origin，并且必须通过已配置 Ed25519 公钥验签。

OMDSH Hub 不实现第二套 Loader，不导入 Host 内部模块，也不执行目录提供的命令。执行时会从类型化 Registry 重新解析包意图。
