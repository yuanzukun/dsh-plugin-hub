# Harness adapters

## `official-v2`

`dist/adapters/official-v2.*` isolates the host-facing contract checked against the npm `next`
packages `@deepseek-ai/cordis@4.0.1-rc.4` and
`@deepseek-ai/dsh-host-webserver@0.0.1-rc.5`. It records only the integration surface used by OMDSH Hub:

- Profile bundles: `dsh.profile.bundles`
- Bundle patch: `dsh.bundle.patch`
- Client manifest: `dsh.client`
- Client platform: `web`
- Settings slot: `settings.section`
- Host route service: `webServer`
- Active Cordis fiber state: `2`

The adapter registers the management route through `ctx.inject(['webServer'])` and confirms runtime
readiness only after the Cordis registry has settled with every enabled fiber active. Repository
Plugin probing remains fail-closed: the corresponding package was absent from npm during this
check, so an absent row produces guided integration only.

Adapters for legacy contracts and deprecated client manifest aliases are intentionally not part of this release candidate.

## Repository configuration

`repository-config-v1` performs narrow, typed edits to the official Repository Plugin row. It never evaluates YAML tags or embedded code and fails closed when the expected structure is unavailable.
