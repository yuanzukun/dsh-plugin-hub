import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { runInNewContext } from 'node:vm'

test('Git-installable package is private and has no lifecycle scripts or runtime dependencies', async () => {
  const manifest = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'))
  assert.equal(manifest.private, true)
  assert.equal(manifest.name, '@omdsh/dsh-hub')
  assert.equal(manifest.bin, undefined)
  assert.equal(manifest.peerDependencies['@omdsh/runtime'], '0.0.1-private.0')
  assert.equal(manifest.dsh.bundle.patch, './cordis.patch.yml')
  assert.equal(manifest.exports['./client'].default, './dist/client.js')
  assert.equal(manifest.exports['./client'].types, './dist/client.d.ts')
  assert.equal(manifest.exports['./registry'].default, './dist/registry.mjs')
  assert.equal(manifest.exports['./recipes'].default, './dist/recipes.mjs')
  assert.equal(manifest.exports['./recipes'].types, './dist/recipes.d.ts')
  assert.equal(manifest.exports['./agent-ecosystem'].default, './dist/agent-ecosystem.mjs')
  assert.equal(manifest.exports['./agent-ecosystem'].types, './dist/agent-ecosystem.d.ts')
  assert.equal(manifest.exports['./agent-tools'].default, './dist/agent-tools.mjs')
  assert.equal(manifest.exports['./agent-tools'].types, './dist/agent-tools.d.ts')
  assert.equal(manifest.exports['./management'].default, './dist/management.mjs')
  assert.equal(manifest.exports['./management'].types, './dist/management.d.ts')
  assert.equal(manifest.exports['./workshop-bridge'].default, './dist/workshop-bridge.mjs')
  assert.equal(manifest.exports['./workshop-bridge'].types, './dist/workshop-bridge.d.ts')
  for (const runtimeExport of ['./manager', './profile', './policy', './recover', './launcher', './storage', './adapters/official-v2', './adapters/repository-config-v1']) {
    assert.equal(manifest.exports[runtimeExport], undefined)
  }
  assert.equal(manifest.dsh.client.platform, 'web')
  assert.deepEqual(manifest.dsh.client.inject, [
    '@deepseek-ai/dsh-client-runtime',
    '@deepseek-ai/dsh-client-ui-settings',
    '@deepseek-ai/dsh-client-locale',
  ])
  assert.equal(manifest.dependencies, undefined)
  assert.equal(manifest.scripts['workshop:vendor'], 'node scripts/vendor-workshop-snapshot.mjs')
  assert.equal(manifest.scripts['catalog:build'], undefined)
  for (const name of ['preinstall', 'install', 'postinstall', 'prepare']) {
    assert.equal(manifest.scripts[name], undefined)
  }
})

test('client adapter is a prebuilt slot bundle with paired Chinese and English dictionaries', async () => {
  const source = await readFile(new URL('../dist/client.js', import.meta.url), 'utf8')
  assert.match(source, /__ModuleLoader__\.load/)
  assert.match(source, /slots\.inject\('settings\.section'/)
  assert.match(source, /const zh = \{/)
  assert.match(source, /const en = \{/)
  assert.match(source, /function MarketSection/)
  assert.match(source, /function CollectionsSection/)
  assert.match(source, /function RecipeSection/)
  assert.match(source, /function collectionText/)
  assert.match(source, /function UpdatesSection/)
  assert.match(source, /function HistorySection/)
  assert.match(source, /inventory\.available/)
  assert.match(source, /delegatedManaged/)
  assert.match(source, /function backendLabel\(adapter, t\)/)
  assert.match(source, /key: item\.identity/)
  assert.match(source, /item\.entry\?\.displayName \|\| item\.packageName \|\| item\.identity/)
  assert.match(source, /canToggle && h\(Button/)
  assert.match(source, /backendOfficialRepository/)
  assert.match(source, /trustedRepositoryCode: '受信任宿主代码 · 无沙箱'/)
  assert.match(source, /trustedRepositoryCode: 'Trusted host code · no sandbox'/)
  assert.match(source, /confirmTrustedRepositoryInstall/)
  assert.match(source, /recipeTrustedWarning/)
  assert.match(source, /subscribe: '使用 OMDSH 安装'/)
  assert.match(source, /viewAtlas: '查看接入说明'/)
  assert.match(source, /function integrationRequirement\(entry, t\)/)
  assert.match(source, /requirementOfficialCommand: '需要官方命令'/)
  assert.match(source, /requirementOfficialRepository: '使用官方 Repository Plugin'/)
  assert.match(source, /requirementOriginalManager: '需要原管理器'/)
  assert.match(source, /requirementSourceIntegration: '需要源码接入'/)
  assert.match(source, /run\('install-market', \{ id: item\.id, releaseId/)
  assert.match(source, /run\('install-collection', \{ id: collection\.id/)
  assert.match(source, /run\('plan-recipe', \{ id: recipe\.id/)
  assert.match(source, /run\('apply-recipe', \{ id: plan\.recipeId, registrySnapshotId: plan\.registrySnapshotId \}\)/)
  assert.match(source, /run\('export-recipe'\)/)
  assert.doesNotMatch(source, /<iframe|h\(['"]iframe['"]/)
  assert.doesNotMatch(source, /from ['"]@deepseek-ai\/|require\(['"]@deepseek-ai\//)
  let definition
  runInNewContext(source, { window: { __ModuleLoader__: { load(value) { definition = value } } } })
  const plugin = definition.factory(name => name === 'react'
    ? {
        createElement() {},
        useCallback() {},
        useEffect() {},
        useMemo() {},
        useState() {},
      }
    : undefined)
  let dictionaries
  plugin.apply({
    effect(effect) { effect() },
    locale: {
      register(_namespace, value) { dictionaries = value },
      bind() { return key => key },
    },
    slots: { inject() {} },
  })
  assert.deepEqual(Object.keys(dictionaries.zh), Object.keys(dictionaries.en))
  assert.deepEqual(Object.keys(plugin).sort(), ['apply', 'inject'])
})
