import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { buildExtensionInventory, describeRegistryEntryManagement } from '../dist/management.mjs'

function entry(id, mode = 'guided') {
  return {
    id,
    displayName: id,
    listing: { state: 'reviewed', trustedPublisher: 'unknown' },
    risk: { level: 'low' },
    install: mode === 'profile-bundle'
      ? { mode, adapter: 'official-profile/v1', packageName: `@example/${id}`, spec: '1.0.0' }
      : mode === 'repository-plugin'
        ? { mode, adapter: 'official-repository/v1', spec: `github:example/${id}#${'1'.repeat(40)}&path:/plugins/${id}/.dsh-plugin` }
        : { mode, method: 'manual' },
  }
}

test('inventory separates installed Profile facts from discoverable Registry entries', () => {
  const managed = entry('managed', 'profile-bundle')
  const available = entry('available', 'profile-bundle')
  const guided = entry('guided')
  const inventory = buildExtensionInventory({
    name: 'web',
    installed: { '@example/managed': '1.0.0', '@local/custom': '2.0.0' },
    enabled: ['@example/managed'],
  }, { entries: [managed, available, guided] })

  assert.equal(inventory.schema, 'omdsh.extension-inventory/v1')
  assert.deepEqual(inventory.installed.map(item => item.packageName), ['@example/managed', '@local/custom'])
  assert.equal(inventory.installed[0].entry.id, 'managed')
  assert.equal(inventory.installed[0].management.level, 'transactional')
  assert.equal(inventory.installed[0].management.capabilities.update, true)
  assert.equal(inventory.installed[1].entry, null)
  assert.equal(inventory.installed[1].management.level, 'profile-managed')
  assert.deepEqual(inventory.available.map(item => item.entry.id), ['available', 'guided'])
  assert.equal(inventory.available[0].management.capabilities.install, true)
  assert.equal(inventory.available[1].management.level, 'guided')
  assert.equal(inventory.available[1].management.capabilities.guide, true)
})

test('unapproved and security-gated entries remain visible without an install capability', () => {
  const pending = entry('pending', 'profile-bundle')
  pending.listing.state = 'review-required'
  const high = entry('high', 'profile-bundle')
  high.listing.state = 'auto-listed'
  high.risk.level = 'high'

  assert.equal(describeRegistryEntryManagement(pending).gate, 'approval')
  assert.equal(describeRegistryEntryManagement(high).gate, 'security')
  assert.equal(describeRegistryEntryManagement(pending).capabilities.install, false)
  assert.equal(describeRegistryEntryManagement(high).level, 'blocked')

  const installed = buildExtensionInventory({
    name: 'web', installed: { '@example/high': '1.0.0' }, enabled: ['@example/high'],
  }, { entries: [high] }).installed[0]
  assert.equal(installed.management.capabilities.enable, false)
  assert.equal(installed.management.capabilities.disable, true)
  assert.equal(installed.management.capabilities.uninstall, true)
  assert.equal(installed.management.rollback, 'generation')
})

test('only the official Repository Plugin contract is delegated; legacy managers stay guided', () => {
  const repository = describeRegistryEntryManagement(entry('repository-plugin', 'repository-plugin'))
  assert.equal(repository.level, 'delegated')
  assert.equal(repository.adapter, 'official-repository/v1')
  assert.equal(repository.capabilities.install, true)
  assert.equal(repository.rollback, 'generation')
  assert.equal(repository.securityNotice, 'trusted-repository-code')

  const unreviewedRepository = entry('unreviewed-repository', 'repository-plugin')
  unreviewedRepository.listing.state = 'auto-listed'
  const gated = describeRegistryEntryManagement(unreviewedRepository)
  assert.equal(gated.gate, 'security')
  assert.equal(gated.capabilities.install, false)
  assert.equal(gated.securityNotice, 'trusted-repository-code')
  for (const method of ['marisa', 'plugin-registry']) {
    const managed = entry(method)
    managed.install.method = method
    const description = describeRegistryEntryManagement(managed)
    assert.equal(description.level, 'guided')
    assert.equal(description.capabilities.install, false)
    assert.equal(description.capabilities.guide, true)
  }
})

test('Repository Plugin falls back to guided when the official host row is absent', () => {
  const repository = describeRegistryEntryManagement(
    entry('repository-plugin', 'repository-plugin'),
    { repositoryPlugin: { state: 'unavailable' } },
  )
  assert.equal(repository.level, 'guided')
  assert.equal(repository.gate, 'host-capability')
  assert.equal(repository.capabilities.install, false)
  assert.equal(repository.capabilities.guide, true)
})

test('Repository Plugin state is projected from the selected Profile without a receipt database', () => {
  const repository = entry('repository-plugin', 'repository-plugin')
  const inventory = buildExtensionInventory({ name: 'web', installed: {}, enabled: [] }, { entries: [repository] }, [repository.install.spec])
  assert.equal(inventory.installed.length, 1)
  assert.equal(inventory.installed[0].identity, 'repository:repository-plugin')
  assert.equal(inventory.installed[0].packageName, null)
  assert.equal(inventory.installed[0].management.capabilities.uninstall, true)
  assert.equal(inventory.installed[0].management.securityNotice, 'trusted-repository-code')
  assert.equal(inventory.available.length, 0)
})

test('bundled Registry keeps the Atlas management split without executable recipes', async () => {
  const registry = JSON.parse(await readFile(new URL('../dist/registry-v1.json', import.meta.url), 'utf8'))
  const counts = Object.groupBy(
    registry.entries.map(item => describeRegistryEntryManagement(item).level),
    value => value,
  )
  const installModes = Object.groupBy(registry.entries, item => item.install.mode)
  const transactional = counts.transactional?.length ?? 0
  const delegated = counts.delegated?.length ?? 0
  const guided = counts.guided?.length ?? 0
  assert.equal(transactional, installModes['profile-bundle']?.length ?? 0)
  assert.equal(delegated, installModes['repository-plugin']?.length ?? 0)
  assert.equal(guided, registry.entries.length - transactional - delegated)
  assert.equal(JSON.stringify(registry).includes('"command"'), false)
})
