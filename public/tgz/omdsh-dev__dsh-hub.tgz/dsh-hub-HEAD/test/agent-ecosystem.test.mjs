import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import {
  AgentEcosystemClient,
  assertAgentEcosystemRegistry,
  ecosystemCompatibility,
  ecosystemDependencies,
  inspectEcosystemProject,
  parseAgentEcosystem,
  preflightComposition,
  recommendCompositions,
  searchEcosystem,
} from '../dist/agent-ecosystem.mjs'
import { parseRegistry } from '../dist/registry.mjs'

const readJson = path => readFile(new URL(path, import.meta.url), 'utf8').then(JSON.parse)

test('bundled Agent ecosystem is strict, Registry-bound, and execution-free', async () => {
  const [raw, registryRaw] = await Promise.all([
    readJson('../dist/agent-ecosystem-v1.json'),
    readJson('../dist/registry-v1.json'),
  ])
  const document = parseAgentEcosystem(raw)
  const registry = parseRegistry(registryRaw, { allowUnsigned: true })
  assert.equal(assertAgentEcosystemRegistry(document, registry), document)
  assert.equal(document.projects.length, registry.entries.length)
  assert.equal(document.policy.installAuthority, 'omdsh-registry/v1')
  assert.equal(document.policy.repair, 'preview-only')
  assert.throws(() => parseAgentEcosystem({ ...structuredClone(raw), command: 'curl attacker' }), /unexpected fields|forbidden field/)
  const poisoned = { ...structuredClone(raw), spec: 'latest' }
  assert.throws(() => parseAgentEcosystem(poisoned), /forbidden field/)
  assert.throws(() => assertAgentEcosystemRegistry(document, { ...registry, snapshotId: `sha256:${'0'.repeat(64)}` }), /does not match/)
})

test('the locked Workshop ecosystem returns no invented project facts', async () => {
  const document = parseAgentEcosystem(await readJson('../dist/agent-ecosystem-v1.json'))
  const search = searchEcosystem(document, '__not_a_real_project_query__')
  assert.equal(search.count, 0)
  assert.deepEqual(search.projects, [])
  assert.throws(() => inspectEcosystemProject(document, 'example'), /Project not found/)
  assert.throws(() => ecosystemCompatibility(document, 'example'), /Project not found/)
  assert.throws(() => ecosystemDependencies(document, 'example'), /Project not found/)
})

test('the locked Workshop ecosystem does not invent recommendations or repairs', async () => {
  const document = parseAgentEcosystem(await readJson('../dist/agent-ecosystem-v1.json'))
  const recommendation = recommendCompositions(document, 'example capability')
  assert.equal(recommendation.basis, 'declared-use-cases-only')
  assert.equal(recommendation.unknown, true)
  assert.deepEqual(recommendation.recommendations, [])
  assert.throws(() => preflightComposition(document, 'example'), /Composition not found/)
})

test('AgentEcosystemClient rejects stale remote facts before caching them', async () => {
  const [raw, registryRaw] = await Promise.all([
    readJson('../dist/agent-ecosystem-v1.json'),
    readJson('../dist/registry-v1.json'),
  ])
  const registry = { home: '/tmp/unused', current: async () => ({ document: parseRegistry(registryRaw, { allowUnsigned: true }) }) }
  const client = new AgentEcosystemClient({ registry, bundledFile: new URL('../dist/agent-ecosystem-v1.json', import.meta.url), cacheFile: '/tmp/omdsh-agent-ecosystem-test-does-not-exist.json', fetch: async () => new Response(JSON.stringify({ ...raw, registry: { ...raw.registry, snapshotId: `sha256:${'0'.repeat(64)}` } })) })
  await assert.rejects(client.sync(), /does not match/)
})
