import test from 'node:test'
import assert from 'node:assert/strict'
import {
  inspectOfficialCapabilitiesDumpOfficialV2,
  installRuntimeReadyOfficialV2,
  loaderTreeIsActiveOfficialV2,
  OFFICIAL_V2_CONTRACT,
  registerManagementRouteOfficialV2,
} from '../dist/adapters/official-v2.mjs'

function waitForTimerTurn() {
  return new Promise(resolve => setTimeout(resolve, 10))
}

test('official-v2 records the npm-next host contract', () => {
  assert.deepEqual(OFFICIAL_V2_CONTRACT, {
    family: 'official-v2',
    profileBundles: 'dsh.profile.bundles',
    bundlePatch: 'dsh.bundle.patch',
    clientManifests: ['dsh.client'],
    clientPlatform: 'web',
    settingsSlot: 'settings.section',
    webService: 'webServer',
    loaderActiveState: 2,
    repositoryPluginRow: 'repository-plugins',
    repositoryPluginPackage: '@deepseek-ai/dsh-repository-plugin',
  })
  assert.equal(Object.isFrozen(OFFICIAL_V2_CONTRACT.clientManifests), true)
})

test('official-v2 detects only an exact official Repository Plugin row', () => {
  const available = inspectOfficialCapabilitiesDumpOfficialV2(`
- id: root
  name: cordis:root
  config:
    - id: repository-plugins
      name: '@deepseek-ai/dsh-repository-plugin'
    - id: other
      name: '@example/other'
`, 'web')
  assert.equal(available.repositoryPlugin.state, 'available')
  assert.equal(available.repositoryPlugin.integration, 'patch-existing-row')

  const unavailable = inspectOfficialCapabilitiesDumpOfficialV2(`
# repository-plugins and @deepseek-ai/dsh-repository-plugin in comments do not count
- id: root
  name: cordis:root
`, 'web')
  assert.equal(unavailable.repositoryPlugin.state, 'unavailable')
  assert.equal(unavailable.repositoryPlugin.integration, 'guided')
})

test('official-v2 waits a timer turn for its own Fiber, then confirms an active Loader tree', async () => {
  const calls = []
  const ownFiber = { state: 1 }
  let awaitCalls = 0
  const loader = {
    entries: () => [
      { disabled: false, fiber: ownFiber },
      { disabled: false, fiber: { state: 2 } },
      { disabled: true },
    ],
    await: async () => { awaitCalls += 1 },
  }
  const ctx = {
    // Cordis getTraceable() can create a distinct Proxy for the same service
    // on every read; readiness must check availability, not object identity.
    get: key => key === 'loader' ? new Proxy(loader, {}) : undefined,
    effect: effect => effect(),
    logger: { warn: error => { throw error } },
  }
  const manager = { runtimeReady: async options => { calls.push(options) } }
  const installed = installRuntimeReadyOfficialV2(ctx, manager, {
    OMDSH_LOGICAL_PROFILE: 'web',
    OMDSH_GENERATION: 'omdsh-web-good',
    OMDSH_BOOT_TOKEN: 'secret',
  })
  assert.equal(installed, true)
  assert.equal(awaitCalls, 0)
  assert.deepEqual(calls, [])
  ownFiber.state = 2
  await waitForTimerTurn()
  assert.equal(awaitCalls, 1)
  assert.deepEqual(calls, [{ logicalProfile: 'web', generation: 'omdsh-web-good', token: 'secret' }])
})

test('official-v2 fails closed for a pending or failed Loader tree', async () => {
  const calls = []
  const loader = {
    entries: () => [{ disabled: false, fiber: { state: 3 } }],
    await: async () => {},
  }
  const ctx = { get: () => loader, effect: effect => effect(), logger: { warn() {} } }
  installRuntimeReadyOfficialV2(ctx, { runtimeReady: async value => { calls.push(value) } }, {
    OMDSH_LOGICAL_PROFILE: 'web', OMDSH_GENERATION: 'bad', OMDSH_BOOT_TOKEN: 'secret',
  })
  await waitForTimerTurn()
  assert.equal(loaderTreeIsActiveOfficialV2(loader), false)
  assert.deepEqual(calls, [])
})

test('official-v2 cancels a pending readiness check when the plugin is disposed', async () => {
  const calls = []
  let dispose
  const loader = { entries: () => [], await: async () => {} }
  const ctx = {
    get: () => loader,
    effect: effect => { dispose = effect() },
    logger: { warn() {} },
  }
  installRuntimeReadyOfficialV2(ctx, { runtimeReady: async value => { calls.push(value) } }, {
    OMDSH_LOGICAL_PROFILE: 'web', OMDSH_GENERATION: 'disposed', OMDSH_BOOT_TOKEN: 'secret',
  })
  dispose()
  await waitForTimerTurn()
  assert.deepEqual(calls, [])
})

test('official-v2 registers the management route through inject, effect, and webServer', () => {
  const route = { kind: 'exact', path: '/omdsh/extensions/v1', handler() {} }
  const registered = []
  const effects = []
  const ctx = {
    inject(names, callback) {
      assert.deepEqual(names, ['webServer'])
      callback({
        effect(effect, label) {
          effects.push(label)
          return effect()
        },
        webServer: { register(value) { registered.push(value); return () => {} } },
      })
    },
  }
  assert.equal(registerManagementRouteOfficialV2(ctx, route), true)
  assert.deepEqual(registered, [route])
  assert.deepEqual(effects, ['omdsh-hub: official-v2 management API'])
})

test('official-v2 stays dormant outside a launcher boot attempt', () => {
  assert.equal(installRuntimeReadyOfficialV2({}, {}, {}), false)
})
