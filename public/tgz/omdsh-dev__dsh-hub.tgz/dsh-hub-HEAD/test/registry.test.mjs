import assert from 'node:assert/strict'
import { generateKeyPairSync, sign } from 'node:crypto'
import { mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'
import {
  RegistryClient, canonicalJson, parseRegistry, registryPayload, registrySnapshotId,
} from '../dist/registry.mjs'

const keys = generateKeyPairSync('ed25519')
const publicKey = keys.publicKey.export({ type: 'spki', format: 'pem' })

function entry(id = 'demo', mode = 'guided') {
  return {
    id,
    displayName: 'Demo extension',
    description: 'A deterministic Registry test fixture.',
    kind: 'extension',
    tags: ['fixture'],
    author: { name: 'OMDSH', url: 'https://omdsh.dev/' },
    version: '1.0.0',
    license: 'MIT',
    source: {
      repository: 'https://github.com/example/demo',
      ref: '1'.repeat(40),
      path: '/packages/demo',
    },
    compatibility: { declared: 'npm-next fixture' },
    risk: {
      level: 'unknown',
      facts: { sourcePinned: true, vulnerabilityScan: 'unknown', permissions: 'unknown', nativeCode: 'unknown', installScripts: 'unknown' },
    },
    listing: { state: 'reviewed', catalogStatus: 'verified', trustedPublisher: 'unknown' },
    maintenance: { state: 'active', notice: null, successor: null },
    install: mode === 'guided'
      ? { mode: 'guided', method: 'manual' }
      : mode === 'repository-plugin'
        ? { mode, adapter: 'official-repository/v1', spec: `github:example/demo#${'1'.repeat(40)}&path:/packages/demo/.dsh-plugin` }
        : { mode: 'profile-bundle', adapter: 'official-profile/v1', packageName: '@example/demo', spec: '1.0.0' },
    links: {
      atlas: `https://example.invalid/catalog/${id}`,
      repository: `https://github.com/example/demo/tree/${'1'.repeat(40)}/packages/demo`,
    },
  }
}

function registry(iso, options = {}) {
  const document = {
    schema: 'omdsh-registry/v1',
    revision: Date.parse(iso),
    generatedAt: iso,
    origins: ['https://primary.invalid/registry-v1.json', 'https://fallback.invalid/registry-v1.json'],
    entries: options.entries ?? [entry()],
    snapshotId: '',
    signature: null,
  }
  document.snapshotId = registrySnapshotId(document)
  if (options.signed === true) {
    document.signature = {
      algorithm: 'Ed25519',
      keyId: 'test-key',
      value: sign(null, Buffer.from(canonicalJson(registryPayload(document))), keys.privateKey).toString('base64'),
    }
  }
  return document
}

async function fixture(options = {}) {
  const directory = await mkdtemp(join(tmpdir(), 'omdsh-registry-'))
  const bundledFile = join(directory, 'bundled.json')
  const cacheFile = join(directory, 'cache.json')
  await writeFile(bundledFile, JSON.stringify(options.bundled ?? registry('2026-08-01T00:00:00.000Z')))
  return { directory, bundledFile, cacheFile }
}

function response(document, status = 200) {
  return { ok: status >= 200 && status < 300, status, async text() { return JSON.stringify(document) } }
}

test('unsigned snapshots are accepted only as explicitly bundled input', () => {
  const document = registry('2026-08-01T00:00:00.000Z')
  assert.equal(parseRegistry(document, { allowUnsigned: true }).entries.length, 1)
  assert.throws(() => parseRegistry(document), /must be signed/)
})

test('the locked public Workshop snapshot is bundled and safely empty offline', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-registry-bundled-'))
  const client = new RegistryClient({ home })
  const all = await client.view()
  const search = await client.view('代码考古')
  const bundled = JSON.parse(await readFile(new URL('../dist/registry-v1.json', import.meta.url), 'utf8'))
  assert.equal(all.snapshot.source, 'bundled')
  assert.equal(all.snapshot.snapshotId, bundled.snapshotId)
  assert.equal(all.entries.length, bundled.entries.length)
  assert.equal(all.entries.length, 0)
  assert.deepEqual(search.entries, [])
  await assert.rejects(client.resolveAction('code-archaeologist'), /not found/i)
})

test('signed Registry verification rejects content changes', () => {
  const document = registry('2026-08-02T00:00:00.000Z', { signed: true })
  assert.equal(parseRegistry(document, { trustedKeys: { 'test-key': publicKey } }).revision, document.revision)
  document.entries[0].description = 'tampered'
  assert.throws(() => parseRegistry(document, { trustedKeys: { 'test-key': publicKey } }), /digest does not match/)
})

test('network and 5xx failures use fallback and persist a signed last-good feed', async () => {
  const files = await fixture()
  const next = registry('2026-08-02T00:00:00.000Z', { signed: true })
  const calls = []
  const client = new RegistryClient({
    ...files,
    origins: ['https://primary.invalid/registry-v1.json', 'https://fallback.invalid/registry-v1.json'],
    trustedKeys: { 'test-key': publicKey },
    fetch: async url => {
      calls.push(url)
      if (calls.length === 1) throw new Error('offline')
      return response(next)
    },
  })
  const synced = await client.sync()
  assert.equal(synced.source, 'remote')
  assert.equal(synced.document.snapshotId, next.snapshotId)
  assert.equal(JSON.parse(await readFile(files.cacheFile, 'utf8')).snapshotId, next.snapshotId)
  assert.equal(calls.length, 2)
})

test('auth and signature failures never try the fallback origin', async () => {
  for (const kind of ['auth', 'signature']) {
    const files = await fixture()
    const calls = []
    const invalid = registry('2026-08-02T00:00:00.000Z', { signed: true })
    invalid.signature.value = Buffer.alloc(64).toString('base64')
    const client = new RegistryClient({
      ...files,
      origins: ['https://primary.invalid/registry-v1.json', 'https://fallback.invalid/registry-v1.json'],
      trustedKeys: { 'test-key': publicKey },
      fetch: async url => {
        calls.push(url)
        return kind === 'auth' ? response({}, 401) : response(invalid)
      },
    })
    await assert.rejects(client.sync(), kind === 'auth' ? /without fallback/ : /signature is invalid/)
    assert.equal(calls.length, 1)
  }
})

test('automatic downgrade is refused without trying fallback', async () => {
  const files = await fixture({ bundled: registry('2026-08-03T00:00:00.000Z') })
  const previous = registry('2026-08-02T00:00:00.000Z', { signed: true })
  let calls = 0
  const client = new RegistryClient({
    ...files,
    origins: ['https://primary.invalid/registry-v1.json', 'https://fallback.invalid/registry-v1.json'],
    trustedKeys: { 'test-key': publicKey },
    fetch: async () => { calls += 1; return response(previous) },
  })
  await assert.rejects(client.sync(), /downgrade refused/)
  assert.equal(calls, 1)
})

test('only an explicit profile-bundle entry resolves an install intent', async () => {
  const files = await fixture({
    bundled: registry('2026-08-01T00:00:00.000Z', {
      entries: [entry('guided'), entry('installable', 'profile-bundle')],
    }),
  })
  const client = new RegistryClient(files)
  assert.deepEqual(await client.resolveInstall('installable'), {
    id: 'installable', releaseId: null, packageName: '@example/demo', spec: '1.0.0',
  })
  await assert.rejects(client.resolveInstall('guided'), /not a Profile Bundle/)
})

test('a Repository Plugin resolves to a typed official adapter intent', async () => {
  const files = await fixture({
    bundled: registry('2026-08-01T00:00:00.000Z', { entries: [entry('repository', 'repository-plugin')] }),
  })
  const client = new RegistryClient(files)
  const action = await client.resolveAction('repository')
  assert.equal(action.install.mode, 'repository-plugin')
  assert.equal(action.install.adapter, 'official-repository/v1')
  assert.match(action.install.spec, /#[0-9a-f]{40}&path:\/packages\/demo\/\.dsh-plugin$/)
})

test('an auto-listed Repository Plugin requires review because it executes trusted host code', async () => {
  const repository = entry('repository', 'repository-plugin')
  repository.listing.state = 'auto-listed'
  repository.risk.level = 'low'
  const files = await fixture({
    bundled: registry('2026-08-01T00:00:00.000Z', { entries: [repository] }),
  })
  await assert.rejects(new RegistryClient(files).resolveAction('repository'), /requires security review/)
})

test('review-required and blocked entries cannot resolve an install intent', async () => {
  const pending = entry('pending', 'profile-bundle')
  pending.listing.state = 'review-required'
  const blocked = entry('blocked', 'profile-bundle')
  blocked.listing.state = 'blocked'
  const files = await fixture({
    bundled: registry('2026-08-01T00:00:00.000Z', { entries: [blocked, pending] }),
  })
  const client = new RegistryClient(files)
  await assert.rejects(client.resolveInstall('pending'), /not approved/)
  await assert.rejects(client.resolveInstall('blocked'), /not approved/)
})

test('critical, unreviewed high-risk, and requested-trust entries stay gated', async () => {
  const critical = entry('critical', 'profile-bundle')
  critical.risk.level = 'critical'
  const high = entry('high', 'profile-bundle')
  high.risk.level = 'high'
  high.listing.state = 'auto-listed'
  const trust = entry('trust', 'profile-bundle')
  trust.listing.trustedPublisher = 'requested'
  const files = await fixture({
    bundled: registry('2026-08-01T00:00:00.000Z', { entries: [critical, high, trust] }),
  })
  const client = new RegistryClient(files)
  for (const id of ['critical', 'high', 'trust']) {
    await assert.rejects(client.resolveInstall(id), /requires security review/)
  }
})
