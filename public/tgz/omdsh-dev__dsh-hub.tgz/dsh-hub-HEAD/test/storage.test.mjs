import test from 'node:test'
import assert from 'node:assert/strict'
import { access, mkdtemp, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { discardPending, extensionStatus, prepareCandidate } from '../dist/generations.mjs'
import { profileDirectory } from '../dist/paths.mjs'
import { cleanupFailedGenerations, generationStorage } from '../dist/storage.mjs'
import { createProfile } from '../test-support/helpers.mjs'

async function pathExists(filename) {
  try {
    await access(filename)
    return true
  } catch {
    return false
  }
}

test('storage reports generation bytes without following external symlinks', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-storage-'))
  await createProfile(home)
  const candidate = await prepareCandidate(home, 'web', { name: 'omdsh-web-storage' })
  await writeFile(join(profileDirectory(home, candidate.id), 'payload.bin'), Buffer.alloc(8192))
  const storage = await generationStorage(home)
  assert.equal(storage.totals.generations, 1)
  assert.ok(storage.totals.apparentBytes >= 8192)
  assert.ok(storage.totals.allocatedBytes > 0)
  assert.equal(storage.generations[0].protected, true)
})

test('failed generation cleanup is dry-run by default and retains the newest requested count', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-cleanup-'))
  await createProfile(home)
  const names = ['omdsh-web-old', 'omdsh-web-middle', 'omdsh-web-new']
  for (let index = 0; index < names.length; index += 1) {
    await prepareCandidate(home, 'web', {
      name: names[index], now: new Date(`2026-08-0${index + 1}T00:00:00.000Z`),
    })
    await discardPending(home, 'web', 'test failure')
  }
  const preview = await cleanupFailedGenerations(home, 'web', { keepFailed: 1 })
  assert.equal(preview.applied, false)
  assert.deepEqual(preview.generations, ['omdsh-web-middle', 'omdsh-web-old'])
  assert.equal(await pathExists(profileDirectory(home, 'omdsh-web-old')), true)

  const applied = await cleanupFailedGenerations(home, 'web', { keepFailed: 1, apply: true })
  assert.equal(applied.applied, true)
  assert.deepEqual(applied.generations, preview.generations)
  assert.equal(await pathExists(profileDirectory(home, 'omdsh-web-old')), false)
  assert.deepEqual((await extensionStatus(home)).failed, ['omdsh-web-new'])
})
