import test from 'node:test'
import assert from 'node:assert/strict'
import { evaluateMarketFacts } from '../dist/policy.mjs'

test('low-risk facts are auto-listed without category or human approval', () => {
  const decision = evaluateMarketFacts({ level: 'L0' })
  assert.equal(decision.listing, 'auto-listed')
  assert.equal(decision.manualReview, false)
  assert.equal(decision.activation, 'hot-eligible')
  assert.equal('category' in decision, false)
})

test('high-risk facts require review and scripts remain blocked by default', () => {
  const decision = evaluateMarketFacts({
    level: 'L3',
    installScripts: true,
    nativeCode: true,
    vulnerabilities: { high: 1 },
  })
  assert.equal(decision.listing, 'review-required')
  assert.equal(decision.activation, 'restart-required')
  assert.equal(decision.installScripts, 'blocked-by-default')
  assert.deepEqual(decision.reasons, ['high-vulnerability', 'install-scripts', 'native-code'])
  assert.equal(decision.recovery.externalSideEffects, 'not-guaranteed')
})

test('critical vulnerability blocks automatic listing', () => {
  assert.equal(evaluateMarketFacts({ vulnerabilities: { critical: 1 } }).listing, 'blocked')
})

