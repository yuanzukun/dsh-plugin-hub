import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { ExtensionManager } from '../dist/manager.mjs'
import {
  RepositoryConfigAdapter, parseRepositorySpec, readRepositorySpecs, writeRepositorySpecs,
} from '../dist/adapters/repository-config-v1.mjs'
import { createProfile, successfulOfficialResult } from '../test-support/helpers.mjs'

const ref = '1'.repeat(40)
const spec = `github:example/plugins#${ref}&path:/plugins/demo/.dsh-plugin`
const intent = {
  id: 'demo',
  releaseId: 'demo@1.0.0',
  mode: 'repository-plugin',
  adapter: 'official-repository/v1',
  spec,
}

test('Repository Plugin specs are strict, immutable, and stored in an isolated Profile block', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-repository-config-'))
  await createProfile(home)
  assert.deepEqual(parseRepositorySpec(spec), {
    repo: 'github:example/plugins', ref, path: '/plugins/demo/.dsh-plugin',
  })
  await writeRepositorySpecs(home, 'web', [spec])
  assert.deepEqual(await readRepositorySpecs(home, 'web'), [spec])
  const patch = await readFile(join(home, 'profiles', 'web', 'cordis.patch.yml'), 'utf8')
  assert.match(patch, /# >>> omdsh repository-plugin/)
  assert.match(patch, /@deepseek-ai\/dsh-repository-plugin/)
  assert.throws(() => parseRepositorySpec('github:example/plugins#main'), /invalid Repository Plugin spec/)
  assert.throws(() => parseRepositorySpec(`github:example/plugins#${ref}&path:/plugins/demo`), /invalid Repository Plugin path/)
})

test('Repository Plugin install is staged in a candidate and recovery selects the untouched previous Profile', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-repository-generation-'))
  await createProfile(home)
  const runner = async (_command, args) => successfulOfficialResult(args)
  const manager = new ExtensionManager({ home, runner })
  const adapter = new RepositoryConfigAdapter({ manager })
  const staged = await adapter.install(intent)
  assert.equal(staged.current, 'web')
  assert.ok(staged.pending)
  assert.deepEqual(await readRepositorySpecs(home, 'web'), [])
  assert.deepEqual(await readRepositorySpecs(home, staged.pending), [spec])
  await manager.activate()
  assert.deepEqual(await readRepositorySpecs(home, await manager.resolve()), [spec])
  const recovered = await manager.recover()
  assert.equal(recovered.to, 'web')
  assert.deepEqual(await readRepositorySpecs(home, await manager.resolve()), [])
})

test('Repository Plugin validation failure discards the candidate and preserves current configuration', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-repository-failure-'))
  await createProfile(home)
  const manager = new ExtensionManager({
    home,
    runner: async (_command, args) => args.includes('--dump-default-config')
      ? successfulOfficialResult(args)
      : successfulOfficialResult(args, { code: 1, stderr: 'invalid repository config' }),
  })
  const adapter = new RepositoryConfigAdapter({ manager })
  await assert.rejects(adapter.install(intent), /invalid repository config/)
  const status = await manager.status()
  assert.equal(status.current, 'web')
  assert.equal(status.pending, null)
  assert.equal(status.failed.length, 1)
  assert.deepEqual(await readRepositorySpecs(home, 'web'), [])
})

test('Repository Plugin install fails closed before creating a candidate when the official row is absent', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-repository-unavailable-'))
  await createProfile(home)
  const manager = new ExtensionManager({
    home,
    runner: async () => ({ code: 0, signal: null, stdout: '[]\n', stderr: '' }),
  })
  const adapter = new RepositoryConfigAdapter({ manager })
  await assert.rejects(adapter.install(intent), /official Repository Plugin is unavailable/)
  const status = await manager.status()
  assert.equal(status.pending, null)
  assert.deepEqual(status.failed, [])
})

test('Repository Plugin adapter refuses to overwrite an unmanaged official row', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-repository-conflict-'))
  const directory = await createProfile(home)
  await writeFile(join(directory, 'cordis.patch.yml'), "- id: repository-plugins\n  name: '@deepseek-ai/dsh-repository-plugin'\n")
  await assert.rejects(writeRepositorySpecs(home, 'web', [spec]), /already configured outside/)
})
