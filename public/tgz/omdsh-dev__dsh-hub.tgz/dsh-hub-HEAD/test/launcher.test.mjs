import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  activatePending, beginLaunch, confirmRuntimeReady, extensionStatus, markCandidateReady, prepareCandidate,
} from '../dist/generations.mjs'
import { launchDsh, selectProfileArguments } from '../dist/launcher.mjs'
import { createProfile } from '../test-support/helpers.mjs'

async function activatedCandidate(prefix) {
  const home = await mkdtemp(join(tmpdir(), prefix))
  await createProfile(home)
  const candidate = await prepareCandidate(home, 'web')
  await markCandidateReady(home)
  await activatePending(home)
  return { home, candidate }
}

test('launcher rewrites only the logical Profile argument', () => {
  assert.deepEqual(selectProfileArguments(['serve'], 'web', 'omdsh-web-1'), [
    '--profile', 'omdsh-web-1', 'serve',
  ])
  assert.deepEqual(selectProfileArguments(['--profile=web', 'serve'], 'web', 'omdsh-web-1'), [
    '--profile', 'omdsh-web-1', 'serve',
  ])
  assert.throws(
    () => selectProfileArguments(['--profile', 'other'], 'web', 'omdsh-web-1'),
    /conflicts/,
  )
})

test('exit before runtime-ready recovers and retries previous Profile once', async () => {
  const { home, candidate } = await activatedCandidate('omdsh-launch-fail-')
  const calls = []
  const result = await launchDsh({
    home,
    profile: 'web',
    args: ['serve'],
    runner: async (_command, args, options) => {
      calls.push({ args, env: options.env })
      return { code: calls.length === 1 ? 17 : 0, signal: null }
    },
  })
  assert.deepEqual(calls.map(call => call.args.slice(0, 2)), [
    ['--profile', candidate.id],
    ['--profile', 'web'],
  ])
  assert.equal(calls[0].env.OMDSH_GENERATION, candidate.id)
  assert.equal(typeof calls[0].env.OMDSH_BOOT_TOKEN, 'string')
  assert.equal(calls[1].env.OMDSH_BOOT_TOKEN, undefined)
  assert.equal(result.code, 0)
  assert.equal(result.attempts.length, 2)
  const status = await extensionStatus(home)
  assert.equal(status.current, 'web')
  assert.ok(status.failed.includes(candidate.id))
})

test('runtime-ready token confirms the selected generation without recovery', async () => {
  const { home, candidate } = await activatedCandidate('omdsh-launch-ready-')
  const result = await launchDsh({
    home,
    runner: async (_command, _args, options) => {
      await confirmRuntimeReady(home, {
        logicalProfile: options.env.OMDSH_LOGICAL_PROFILE,
        generation: options.env.OMDSH_GENERATION,
        token: options.env.OMDSH_BOOT_TOKEN,
      })
      return { code: 0, signal: null }
    },
  })
  assert.equal(result.recovered, null)
  const status = await extensionStatus(home)
  assert.equal(status.current, candidate.id)
  assert.equal(status.bootAttempt, null)
})

test('runtime-ready timeout stops a stuck candidate, recovers, and retries previous once', async () => {
  const { home, candidate } = await activatedCandidate('omdsh-launch-timeout-')
  let calls = 0
  const result = await launchDsh({
    home,
    readyTimeoutMs: 25,
    readyPollIntervalMs: 5,
    runner: async (_command, _args, options) => {
      calls += 1
      if (calls > 1) return { code: 0, signal: null }
      return new Promise(resolve => options.signal.addEventListener('abort', () => {
        resolve({ code: 143, signal: 'SIGTERM' })
      }, { once: true }))
    },
  })
  assert.equal(calls, 2)
  assert.equal(result.code, 0)
  assert.equal(result.attempts[0].readyTimeout, true)
  assert.equal(result.attempts[1].readyTimeout, false)
  assert.equal(result.recovered.from, candidate.id)
  assert.equal(result.recovered.to, 'web')
  const status = await extensionStatus(home)
  assert.equal(status.current, 'web')
  assert.ok(status.failed.includes(candidate.id))
})

test('an operator interrupt recovers selection without relaunching a process', async () => {
  const { home } = await activatedCandidate('omdsh-launch-interrupt-')
  let calls = 0
  const result = await launchDsh({
    home,
    runner: async () => {
      calls += 1
      return { code: 130, signal: 'SIGINT' }
    },
  })
  assert.equal(calls, 1)
  assert.equal(result.code, 130)
  assert.notEqual(result.recovered, null)
  assert.equal((await extensionStatus(home)).current, 'web')
})

test('runtime-ready rejects a stale or forged token', async () => {
  const { home, candidate } = await activatedCandidate('omdsh-launch-token-')
  await beginLaunch(home)
  assert.equal('tokenHash' in (await extensionStatus(home)).bootAttempt, false)
  await assert.rejects(confirmRuntimeReady(home, {
    logicalProfile: 'web', generation: candidate.id, token: 'forged',
  }), /invalid runtime-ready token/)
})
