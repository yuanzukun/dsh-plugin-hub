import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { ExtensionManager } from '../dist/manager.mjs'
import { readGeneration, readProfile } from '../dist/profile.mjs'
import { createProfile } from '../test-support/helpers.mjs'

function successfulRunner(home, calls) {
  return async (_command, args) => {
    calls.push(args)
    if (args[0] === 'plugin' && args[3] === 'add') {
      const profile = args[2]
      const filename = join(home, 'profiles', profile, 'package.json')
      const manifest = JSON.parse(await readFile(filename, 'utf8'))
      manifest.dependencies['plugin-two'] = args[4]
      manifest.dsh.profile.bundles.push('plugin-two')
      await writeFile(filename, `${JSON.stringify(manifest, null, 2)}\n`)
    }
    return { code: 0, signal: null, stdout: '', stderr: '' }
  }
}

test('install runs only in candidate, blocks scripts and preserves disabled intent', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-manager-'))
  await createProfile(home)
  const calls = []
  const manager = new ExtensionManager({ home, runner: successfulRunner(home, calls) })
  const status = await manager.stageInstall({
    profile: 'web',
    packageName: 'plugin-two',
    spec: 'git+https://example.invalid/plugin-two.git#0123456789abcdef0123456789abcdef01234567',
    enable: false,
  })
  assert.equal(status.current, 'web')
  assert.notEqual(status.pending, null)
  assert.ok(calls[0].includes('--ignore-scripts'))
  const candidate = await readProfile(home, status.pending)
  assert.equal(candidate.installed['plugin-two'].startsWith('git+https://'), true)
  assert.equal(candidate.enabled.includes('plugin-two'), false)
  assert.equal((await readProfile(home, 'web')).installed['plugin-two'], undefined)
})

test('validation failure marks candidate failed and leaves current unchanged', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-manager-fail-'))
  await createProfile(home)
  const calls = []
  const installRunner = successfulRunner(home, calls)
  const manager = new ExtensionManager({
    home,
    runner: async (command, args) => {
      if (args.includes('--dump-config')) return { code: 1, signal: null, stdout: '', stderr: 'broken bundle' }
      return installRunner(command, args)
    },
  })
  await assert.rejects(manager.stageInstall({
    packageName: 'plugin-two',
    spec: 'plugin-two@2.0.0',
    enable: true,
  }), /broken bundle/)
  const status = await manager.status()
  assert.equal(status.current, 'web')
  assert.equal(status.pending, null)
  assert.equal(status.failed.length, 1)
})

test('an exact Registry version is combined with its reviewed package name', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-manager-version-'))
  await createProfile(home)
  const calls = []
  const manager = new ExtensionManager({ home, runner: successfulRunner(home, calls) })
  await manager.stageInstall({ packageName: 'plugin-two', spec: '2.0.0' })
  assert.equal(calls[0][4], 'plugin-two@2.0.0')
})

test('market install resolves an approved immutable intent inside the manager', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-manager-market-'))
  await createProfile(home)
  const calls = []
  const registry = {
    async resolveInstall(id) {
      assert.equal(id, 'dsh-web-skins')
      return { packageName: 'plugin-two', spec: '2.0.0' }
    },
  }
  const manager = new ExtensionManager({ home, registry, runner: successfulRunner(home, calls) })
  const status = await manager.stageMarketInstall('dsh-web-skins', { profile: 'web', enable: true })
  assert.deepEqual(calls[0].slice(0, 5), [
    'plugin', '--profile', status.pending, 'add', 'plugin-two@2.0.0',
  ])
  assert.ok(calls[0].includes('--ignore-scripts'))
  assert.equal((await readProfile(home, status.pending)).enabled.includes('plugin-two'), true)
  assert.equal((await readGeneration(home, status.pending)).operations[0].entryId, 'dsh-web-skins')
})

test('market refresh preserves the enabled state when enable is omitted', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-manager-market-update-'))
  await createProfile(home, 'web', {
    dependencies: { 'plugin-two': '1.0.0' },
    bundles: ['@deepseek-ai/dsh-base', 'plugin-two'],
  })
  const registry = {
    async resolveInstall() { return { packageName: 'plugin-two', spec: '2.0.0' } },
  }
  const manager = new ExtensionManager({ home, registry, runner: successfulRunner(home, []) })
  const status = await manager.stageMarketInstall('dsh-web-skins')
  assert.equal((await readProfile(home, status.pending)).enabled.includes('plugin-two'), true)
})

test('a collection installs every intent in one candidate and validates only after the batch', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-manager-collection-'))
  await createProfile(home)
  const calls = []
  const registry = {
    async resolveCollection(id) {
      assert.equal(id, 'starter')
      return {
        id,
        intents: [
          { id: 'first', releaseId: 'first@1.0.0' },
          { id: 'second', releaseId: 'second@2.0.0' },
        ],
      }
    },
    async resolveInstall(id, releaseId) {
      return { id, releaseId, packageName: `plugin-${id}`, spec: id === 'first' ? '1.0.0' : '2.0.0' }
    },
  }
  const runner = async (_command, args) => {
    calls.push(args)
    if (args[0] === 'plugin' && args[3] === 'add') {
      const packageName = args[4].split('@')[0]
      const filename = join(home, 'profiles', args[2], 'package.json')
      const manifest = JSON.parse(await readFile(filename, 'utf8'))
      manifest.dependencies[packageName] = args[4]
      manifest.dsh.profile.bundles.push(packageName)
      await writeFile(filename, `${JSON.stringify(manifest, null, 2)}\n`)
    }
    return { code: 0, signal: null, stdout: '', stderr: '' }
  }
  const manager = new ExtensionManager({ home, registry, runner })
  const status = await manager.stageMarketCollection('starter')
  const candidate = await readProfile(home, status.pending)
  assert.deepEqual(Object.keys(candidate.installed).sort(), ['plugin-first', 'plugin-second'])
  assert.equal(calls.filter(args => args[3] === 'add').length, 2)
  assert.equal(calls.filter(args => args.includes('--dump-config')).length, 1)
  const operations = (await readGeneration(home, status.pending)).operations
  assert.deepEqual(operations.map(item => item.collectionId), ['starter', 'starter'])
  assert.ok(operations.every(item => item.scripts === 'blocked'))
})

test('a failed item discards the entire collection candidate and leaves current unchanged', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-manager-collection-fail-'))
  await createProfile(home)
  const registry = {
    async resolveInstall(id) { return { id, packageName: `plugin-${id}`, spec: '1.0.0', releaseId: `${id}@1.0.0` } },
  }
  const runner = async (_command, args) => {
    if (args[4]?.startsWith('plugin-second@')) return { code: 1, signal: null, stdout: '', stderr: 'second failed' }
    if (args[0] === 'plugin' && args[3] === 'add') {
      const packageName = args[4].split('@')[0]
      const filename = join(home, 'profiles', args[2], 'package.json')
      const manifest = JSON.parse(await readFile(filename, 'utf8'))
      manifest.dependencies[packageName] = args[4]
      await writeFile(filename, `${JSON.stringify(manifest, null, 2)}\n`)
    }
    return { code: 0, signal: null, stdout: '', stderr: '' }
  }
  const manager = new ExtensionManager({ home, registry, runner })
  await assert.rejects(manager.stageMarketBatch([{ id: 'first' }, { id: 'second' }], { collectionId: 'starter' }), /second failed/)
  const status = await manager.status()
  assert.equal(status.current, 'web')
  assert.equal(status.pending, null)
  assert.equal(status.failed.length, 1)
  assert.deepEqual((await readProfile(home, 'web')).installed, {})
})

test('candidate package reconciliation cannot re-enable a previously disabled Bundle', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-manager-enabled-source-'))
  await createProfile(home, 'web', {
    dependencies: { 'plugin-one': '1.0.0', 'plugin-disabled': '1.0.0' },
    bundles: ['@deepseek-ai/dsh-base', 'plugin-one'],
  })
  const calls = []
  const runner = async (_command, args) => {
    calls.push(args)
    if (args[0] === 'plugin') {
      const filename = join(home, 'profiles', args[2], 'package.json')
      const manifest = JSON.parse(await readFile(filename, 'utf8'))
      for (const packageName of Object.keys(manifest.dependencies)) {
        if (!manifest.dsh.profile.bundles.includes(packageName)) {
          manifest.dsh.profile.bundles.push(packageName)
        }
      }
      await writeFile(filename, `${JSON.stringify(manifest, null, 2)}\n`)
    }
    return { code: 0, signal: null, stdout: '', stderr: '' }
  }
  const manager = new ExtensionManager({ home, runner })
  const status = await manager.stageEnable('plugin-one', 'web', false)
  assert.deepEqual(calls[0].slice(0, 5), ['plugin', '--profile', status.pending, 'install', '--ignore-scripts'])
  assert.ok(calls[1].includes('--dump-config'))
  const candidate = await readProfile(home, status.pending)
  assert.deepEqual(candidate.enabled, ['@deepseek-ai/dsh-base'])
  assert.equal(candidate.enabled.includes('plugin-disabled'), false)
})

test('uninstall uses pnpm global config before remove for official forwarding', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-manager-uninstall-'))
  await createProfile(home, 'web', {
    dependencies: { 'plugin-two': '2.0.0' },
    bundles: ['@deepseek-ai/dsh-base', 'plugin-two'],
  })
  const calls = []
  const runner = async (_command, args) => {
    calls.push(args)
    if (args[0] === 'plugin') {
      const filename = join(home, 'profiles', args[2], 'package.json')
      const manifest = JSON.parse(await readFile(filename, 'utf8'))
      delete manifest.dependencies['plugin-two']
      manifest.dsh.profile.bundles = manifest.dsh.profile.bundles.filter(name => name !== 'plugin-two')
      await writeFile(filename, `${JSON.stringify(manifest, null, 2)}\n`)
    }
    return { code: 0, signal: null, stdout: '', stderr: '' }
  }
  const manager = new ExtensionManager({ home, runner })
  const status = await manager.stageUninstall('plugin-two')
  assert.deepEqual(calls[0], [
    'plugin', '--profile', status.pending, '--config.ignore-scripts=true', 'remove', 'plugin-two',
  ])
  assert.ok(calls[1].includes('--dump-config'))
  const candidate = await readProfile(home, status.pending)
  assert.equal(candidate.installed['plugin-two'], undefined)
  assert.equal(candidate.enabled.includes('plugin-two'), false)
  assert.equal((await readProfile(home, 'web')).installed['plugin-two'], '2.0.0')
})
