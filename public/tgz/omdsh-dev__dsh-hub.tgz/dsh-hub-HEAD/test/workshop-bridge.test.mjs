import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { ExtensionManager } from '../dist/manager.mjs'
import { RegistryClient } from '../dist/registry.mjs'
import { WorkshopBridge } from '../dist/workshop-bridge.mjs'
import { createProfile, successfulOfficialResult } from '../test-support/helpers.mjs'
import { readRepositorySpecs } from '../dist/adapters/repository-config-v1.mjs'
import { createRegistryFixture } from '../test-support/registry-fixture.mjs'

test('subscriptions and updates are derived from Profile dependencies without a receipt database', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-workshop-view-'))
  const { filename } = await createRegistryFixture(home)
  const registry = new RegistryClient({ home, bundledFile: filename })
  const bundle = await registry.resolveAction('example-bundle', 'example-bundle@1.0.0')
  await createProfile(home, 'web', {
    dependencies: { [bundle.install.packageName]: '0.9.0' },
    bundles: ['@deepseek-ai/dsh-base', bundle.install.packageName],
  })
  const manager = new ExtensionManager({ home, registry })
  const workshop = new WorkshopBridge({ manager, registry })
  const view = await workshop.view()
  assert.equal(view.schema, 'omdsh.workshop-view/v1')
  assert.equal(view.subscriptions.length, 1)
  assert.equal(view.subscriptions[0].entry.id, 'example-bundle')
  assert.equal(view.updates[0].id, 'example-bundle')
  assert.equal(view.collections.length, 0)
  assert.equal(Object.keys(workshop).sort().join(','), 'manager,registry')
})

test('a Workshop plan contains IDs and becomes stale when the Registry snapshot changes', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-workshop-plan-'))
  await createProfile(home)
  const { filename } = await createRegistryFixture(home)
  const registry = new RegistryClient({ home, bundledFile: filename })
  const manager = new ExtensionManager({ home, registry })
  const workshop = new WorkshopBridge({ manager, registry })
  const plan = await workshop.planInstall('example-bundle')
  assert.deepEqual(plan.items, [{ id: 'example-bundle', releaseId: 'example-bundle@1.0.0' }])
  assert.equal(Object.hasOwn(plan.items[0], 'spec'), false)
  assert.match(plan.registrySnapshotId, /^sha256:/)
  await assert.rejects(workshop.applyPlan({ ...plan, registrySnapshotId: `sha256:${'0'.repeat(64)}` }), /snapshot is stale/)
})

test('Workshop install routes an official Repository Plugin intent without requiring dshx', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-workshop-repository-'))
  await createProfile(home)
  const { filename } = await createRegistryFixture(home)
  const registry = new RegistryClient({ home, bundledFile: filename })
  const manager = new ExtensionManager({
    home,
    registry,
    runner: async (_command, args) => successfulOfficialResult(args),
  })
  const workshop = new WorkshopBridge({ manager, registry })
  const inspected = await workshop.inspect('example-repository')
  assert.equal(inspected.install.adapter, 'official-repository/v1')
  assert.equal(inspected.supported, true)
  const staged = await workshop.install('example-repository')
  assert.ok(staged.pending)
  assert.deepEqual(await readRepositorySpecs(home, staged.pending), [inspected.install.spec])
  assert.deepEqual(Object.keys(workshop).sort(), ['manager', 'registry'])
})

test('Workshop keeps Repository Plugins discoverable but guided when the host omits the official row', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-workshop-repository-guided-'))
  await createProfile(home)
  const { filename } = await createRegistryFixture(home)
  const registry = new RegistryClient({ home, bundledFile: filename })
  const manager = new ExtensionManager({
    home,
    registry,
    runner: async () => ({ code: 0, signal: null, stdout: '[]\n', stderr: '' }),
  })
  const workshop = new WorkshopBridge({ manager, registry })
  const inspected = await workshop.inspect('example-repository')
  assert.equal(inspected.supported, false)
  assert.equal(inspected.hostCapabilities.repositoryPlugin.state, 'unavailable')
  await assert.rejects(workshop.install('example-repository'), /official Repository Plugin is unavailable/)
  assert.equal((await manager.status()).pending, null)
})
