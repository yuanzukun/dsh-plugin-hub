import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import { parseAgentEcosystem } from '../dist/agent-ecosystem.mjs'
import { registerAgentEcosystemTools } from '../dist/agent-tools.mjs'

test('official ToolRegistry adapter registers seven read-only evidence tools', async () => {
  const document = parseAgentEcosystem(JSON.parse(await readFile(new URL('../dist/agent-ecosystem-v1.json', import.meta.url), 'utf8')))
  const definitions = new Map()
  const tools = {
    register(value) {
      definitions.set(value.name, value)
      return () => definitions.delete(value.name)
    },
  }
  const dispose = registerAgentEcosystemTools({ get: key => key === 'tools' ? tools : undefined }, { current: async () => ({ document }) })
  assert.equal(typeof dispose, 'function')
  assert.deepEqual([...definitions.keys()], ['hub_search', 'hub_inspect', 'hub_dependencies', 'hub_compatibility', 'hub_preflight', 'hub_recommend', 'hub_repair_preview'])
  assert.ok([...definitions.values()].every(item => item.output.schema.type === 'object'))
  assert.ok([...definitions.values()].every(item => !/install anything|automatically install/i.test(item.description) || item.name === 'hub_inspect'))

  const result = await definitions.get('hub_search').execute({ query: '__not_a_real_project_query__', limit: 3 }, {})
  assert.deepEqual(result.projects, [])
  await assert.rejects(definitions.get('hub_search').execute({ query: 'web', unexpected: true }, {}), /unexpected argument/)
  await assert.rejects(definitions.get('hub_repair_preview').execute({ compositionId: 'example' }, {}), /Composition not found/)
  const recommendations = await definitions.get('hub_recommend').execute({ task: 'example capability' }, {})
  assert.equal(recommendations.basis, 'declared-use-cases-only')
  assert.equal(recommendations.unknown, true)
  assert.deepEqual(recommendations.recommendations, [])
  dispose()
  assert.equal(definitions.size, 0)
})

test('Agent tools are optional when the official ToolRegistry is absent', () => {
  assert.equal(registerAgentEcosystemTools({ get: () => undefined }, {}), false)
})
