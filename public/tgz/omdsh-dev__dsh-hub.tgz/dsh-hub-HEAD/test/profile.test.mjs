import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  createCandidateProfile, readGeneration, readProfile, setBundleEnabled,
} from '../dist/profile.mjs'
import { createProfile } from '../test-support/helpers.mjs'

test('candidate copies official Profile documents without copying Harness or node_modules', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-profile-'))
  await createProfile(home, 'web', {
    dependencies: { 'plugin-one': '1.0.0' },
    bundles: ['@deepseek-ai/dsh-base', 'plugin-one'],
  })
  const candidate = await createCandidateProfile(home, {
    logicalProfile: 'web',
    sourceProfile: 'web',
    name: 'omdsh-web-test-one',
  })
  assert.equal(candidate.status, 'prepared')
  assert.equal((await readGeneration(home, candidate.id)).sourceProfile, 'web')
  const profile = await readProfile(home, candidate.id)
  assert.deepEqual(profile.installed, { 'plugin-one': '1.0.0' })
  assert.deepEqual(profile.enabled, ['@deepseek-ai/dsh-base', 'plugin-one'])
  assert.equal(await readFile(join(profile.directory, 'cordis.patch.yml'), 'utf8'), '[]\n')
})

test('enabled state is written only to the official dsh.profile.bundles field', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-enable-'))
  await createProfile(home, 'candidate', { dependencies: { 'plugin-one': '1.0.0' } })
  await setBundleEnabled(home, 'candidate', 'plugin-one', true)
  assert.deepEqual((await readProfile(home, 'candidate')).enabled, ['@deepseek-ai/dsh-base', 'plugin-one'])
  await setBundleEnabled(home, 'candidate', 'plugin-one', false)
  assert.deepEqual((await readProfile(home, 'candidate')).enabled, ['@deepseek-ai/dsh-base'])
})
