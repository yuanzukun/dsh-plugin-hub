import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  activatePending, confirmBoot, extensionStatus, markCandidateReady, prepareCandidate, recoverProfile,
} from '../dist/generations.mjs'
import { createProfile } from '../test-support/helpers.mjs'

test('generation moves through pending, booting and confirmed current', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-generation-'))
  await createProfile(home)
  const candidate = await prepareCandidate(home, 'web', { name: 'omdsh-web-good' })
  assert.equal((await extensionStatus(home)).pending, candidate.id)
  await markCandidateReady(home)
  assert.equal(await activatePending(home), candidate.id)
  const booting = await extensionStatus(home)
  assert.equal(booting.current, candidate.id)
  assert.equal(booting.previous, 'web')
  assert.equal(booting.bootAttempt.generation, candidate.id)
  await confirmBoot(home)
  assert.equal((await extensionStatus(home)).bootAttempt, null)
})

test('recover selects previous after an unconfirmed boot attempt', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-recover-'))
  await createProfile(home)
  const candidate = await prepareCandidate(home, 'web', { name: 'omdsh-web-bad' })
  await markCandidateReady(home)
  await activatePending(home)
  await assert.rejects(
    recoverProfile(home, 'web', { to: candidate.id }),
    /recovery target profile is marked failed/,
  )
  const recovered = await recoverProfile(home)
  assert.equal(recovered.from, candidate.id)
  assert.equal(recovered.to, 'web')
  const status = await extensionStatus(home)
  assert.equal(status.current, 'web')
  assert.equal(status.bootAttempt, null)
  assert.ok(status.failed.includes(candidate.id))
})
