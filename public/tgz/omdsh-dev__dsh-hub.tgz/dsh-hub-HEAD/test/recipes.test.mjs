import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { ExtensionManager } from '../dist/manager.mjs'
import { readGeneration, readProfile } from '../dist/profile.mjs'
import { RegistryClient } from '../dist/registry.mjs'
import { RecipeClient, assertRecipesRegistry, parseRecipes } from '../dist/recipes.mjs'
import { WorkshopBridge } from '../dist/workshop-bridge.mjs'
import { readRepositorySpecs, writeRepositorySpecs } from '../dist/adapters/repository-config-v1.mjs'
import { createProfile, successfulOfficialResult } from '../test-support/helpers.mjs'
import { createRegistryFixture } from '../test-support/registry-fixture.mjs'

async function fixture(home, filename) {
  const { filename: registryFile } = await createRegistryFixture(home)
  const registry = new RegistryClient({ home, bundledFile: registryFile })
  const selected = await registry.current()
  const bundle = await registry.resolveAction('example-bundle', 'example-bundle@1.0.0')
  const repository = await registry.resolveAction('example-repository', 'example-repository@1.0.0')
  const document = {
    schema: 'omdsh-workshop-recipes/v1',
    generatedAt: '2026-08-09T09:20:00.000Z',
    registry: {
      schema: selected.document.schema,
      snapshotId: selected.document.snapshotId,
      revision: selected.document.revision,
      origins: selected.document.origins,
    },
    recipes: [{
      id: 'interface-kit',
      kind: 'configuration',
      title: '界面配置',
      summary: '用于验证一个候选代际内的混合官方接入。',
      translations: { en: { title: 'Interface kit', summary: 'A mixed official-adapter fixture applied in one candidate.' } },
      useCases: [{ id: 'customize-interface', title: '定制界面', translations: { en: 'Customize the interface' } }],
      author: { name: 'example', url: 'https://github.com/example' },
      source: { repository: 'https://github.com/example/interface-kit', ref: '1'.repeat(40) },
      compatibility: { harness: 'official-v2', declared: 'npm-next fixture' },
      featured: false,
      items: [
        { projectId: bundle.id, releaseId: bundle.releaseId, enabled: false, management: 'transactional', availability: 'available' },
        { projectId: repository.id, releaseId: repository.releaseId, enabled: true, management: 'managed', availability: 'available' },
      ],
      apply: {
        mode: 'single-candidate', recoveryScope: 'profile-generation', externalEffects: 'not-covered',
        counts: { total: 2, managed: 2, guided: 0, blocked: 0 },
      },
    }],
  }
  await writeFile(filename, `${JSON.stringify(document, null, 2)}\n`)
  return { registry, document, bundle, repository }
}

test('Recipe feed is strict, Registry-bound, and contains no executable install data', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-recipes-parse-'))
  const filename = join(home, 'recipes.json')
  const { registry, document } = await fixture(home, filename)
  const parsed = parseRecipes(structuredClone(document))
  assert.equal(parsed.recipes[0].items[0].projectId, 'example-bundle')
  assert.deepEqual(parsed.recipes[0].useCases, [{ id: 'customize-interface', title: '定制界面', translations: { en: 'Customize the interface' } }])
  assert.equal(Object.hasOwn(parsed.recipes[0].items[0], 'spec'), false)
  assert.equal(Object.hasOwn(parsed.recipes[0], 'command'), false)
  const registryDocument = (await registry.current()).document
  assertRecipesRegistry(parsed, registryDocument)
  assert.throws(() => parseRecipes({ ...structuredClone(document), command: 'curl attacker' }), /unexpected fields/)
  const duplicateUseCase = structuredClone(document)
  duplicateUseCase.recipes[0].useCases.push(duplicateUseCase.recipes[0].useCases[0])
  assert.throws(() => parseRecipes(duplicateUseCase), /duplicate task intents/)
  const mismatched = parseRecipes({
    ...structuredClone(document),
    registry: { ...document.registry, snapshotId: `sha256:${'0'.repeat(64)}` },
  })
  assert.throws(() => assertRecipesRegistry(mismatched, registryDocument), /does not match/)
})

test('RecipeClient uses a pinned bundled feed and exposes only Registry-bound items', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-recipes-client-'))
  const filename = join(home, 'recipes.json')
  const { registry } = await fixture(home, filename)
  const recipes = new RecipeClient({ home, registry, bundledFile: filename })
  const view = await recipes.view()
  assert.equal(view.schema, 'omdsh.recipe-view/v1')
  assert.equal(view.snapshot.source, 'bundled')
  assert.equal(view.recipes.length, 1)
  const resolved = await recipes.resolve('interface-kit')
  assert.deepEqual(resolved.items.map(item => Object.keys(item).sort()), [
    ['enabled', 'id', 'releaseId'], ['enabled', 'id', 'releaseId'],
  ])
})

test('bundled public Recipe feed starts empty and remains Registry-bound', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-recipes-bootstrap-'))
  const registry = new RegistryClient({ home })
  const recipes = new RecipeClient({ home, registry })
  const view = await recipes.view()
  assert.equal(view.snapshot.source, 'bundled')
  assert.deepEqual(view.recipes, [])
  await assert.rejects(recipes.resolve('example'), /Recipe not found/)
})

test('explicit Recipe sync uses network fallback and persists only a Registry-bound feed', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-recipes-sync-'))
  const filename = join(home, 'recipes.json')
  const cacheFile = join(home, 'cache.json')
  const { registry, document } = await fixture(home, filename)
  const calls = []
  const recipes = new RecipeClient({
    home,
    registry,
    bundledFile: filename,
    cacheFile,
    origins: ['https://primary.example/recipes.json', 'https://fallback.example/recipes.json'],
    async fetch(url) {
      calls.push(url)
      if (url.includes('primary')) return new Response('', { status: 503 })
      return new Response(JSON.stringify(document), { status: 200 })
    },
  })
  const synced = await recipes.sync()
  assert.equal(synced.source, 'remote')
  assert.deepEqual(calls, ['https://primary.example/recipes.json', 'https://fallback.example/recipes.json'])
  assert.deepEqual(JSON.parse(await readFile(cacheFile, 'utf8')), document)

  const deniedCalls = []
  const denied = new RecipeClient({
    home,
    registry,
    bundledFile: filename,
    cacheFile: join(home, 'denied-cache.json'),
    origins: ['https://primary.example/recipes.json', 'https://fallback.example/recipes.json'],
    async fetch(url) {
      deniedCalls.push(url)
      return new Response('', { status: 403 })
    },
  })
  await assert.rejects(denied.sync(), /HTTP 403/)
  assert.deepEqual(deniedCalls, ['https://primary.example/recipes.json'])
})

test('Recipe sync refuses downgrade and timestamp collision without trying fallback', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-recipes-ordering-'))
  const filename = join(home, 'recipes.json')
  const { registry, document } = await fixture(home, filename)
  for (const [candidate, pattern] of [
    [{ ...structuredClone(document), generatedAt: '2026-08-08T09:20:00.000Z' }, /downgrade refused/],
    [{ ...structuredClone(document), recipes: [] }, /timestamp collision refused/],
  ]) {
    let calls = 0
    const recipes = new RecipeClient({
      home,
      registry,
      bundledFile: filename,
      origins: ['https://primary.example/recipes.json', 'https://fallback.example/recipes.json'],
      async fetch() {
        calls += 1
        return new Response(JSON.stringify(candidate), { status: 200 })
      },
    })
    await assert.rejects(recipes.sync(), pattern)
    assert.equal(calls, 1)
  }
})

test('a matching Recipe cache remains usable after the bundled Registry generation changes', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-recipes-cache-'))
  const cacheFile = join(home, 'cache.json')
  const bundledFile = join(home, 'bundled.json')
  const { registry, document } = await fixture(home, cacheFile)
  await writeFile(bundledFile, `${JSON.stringify({
    ...document,
    registry: { ...document.registry, snapshotId: `sha256:${'0'.repeat(64)}` },
  }, null, 2)}\n`)
  const recipes = new RecipeClient({ home, registry, bundledFile, cacheFile })
  const selected = await recipes.current()
  assert.equal(selected.source, 'cache')
  assert.match(selected.warning, /bundled Recipe feed ignored/)
})

test('a mixed Recipe previews and applies Profile Bundle plus Repository Plugin in one candidate', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-recipes-apply-'))
  await createProfile(home)
  const filename = join(home, 'recipes.json')
  const { registry, bundle, repository } = await fixture(home, filename)
  const calls = []
  const runner = async (_command, args) => {
    calls.push(args)
    if (args[0] === 'plugin' && args[3] === 'add') {
      const profile = args[2]
      const manifestFile = join(home, 'profiles', profile, 'package.json')
      const manifest = JSON.parse(await readFile(manifestFile, 'utf8'))
      manifest.dependencies[bundle.install.packageName] = bundle.install.spec
      await writeFile(manifestFile, `${JSON.stringify(manifest, null, 2)}\n`)
    }
    return successfulOfficialResult(args)
  }
  const manager = new ExtensionManager({ home, registry, runner })
  const recipes = new RecipeClient({ home, registry, bundledFile: filename })
  const workshop = new WorkshopBridge({ manager, registry, recipes })
  const plan = await workshop.planRecipe('interface-kit')
  assert.equal(plan.schema, 'omdsh.recipe-plan/v1')
  assert.equal(plan.changes, 2)
  assert.deepEqual(plan.preview.map(item => item.change), ['install', 'install'])
  assert.deepEqual(plan.preview.map(item => item.securityNotice), [null, 'trusted-repository-code'])
  assert.equal(Object.hasOwn(plan.items[0], 'spec'), false)
  await assert.rejects(workshop.applyRecipe('interface-kit', {
    expectedSnapshotId: `sha256:${'0'.repeat(64)}`,
  }), /preview is stale/)

  const status = await workshop.applyRecipe('interface-kit', { expectedSnapshotId: plan.registrySnapshotId })
  assert.ok(status.pending)
  assert.equal(calls.filter(args => args[0] === 'plugin' && args[3] === 'add').length, 1)
  assert.equal(calls.filter(args => args.includes('--dump-config')).length, 1)
  const candidate = await readProfile(home, status.pending)
  assert.equal(candidate.installed[bundle.install.packageName], bundle.install.spec)
  assert.equal(candidate.enabled.includes(bundle.install.packageName), false)
  assert.deepEqual(await readRepositorySpecs(home, status.pending), [repository.install.spec])
  const operations = (await readGeneration(home, status.pending)).operations
  assert.equal(operations.length, 2)
  assert.ok(operations.every(operation => operation.recipeId === 'interface-kit'))
})

test('a mixed Recipe validation failure discards every staged change and preserves current', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-recipes-failure-'))
  await createProfile(home)
  const filename = join(home, 'recipes.json')
  const { registry, bundle } = await fixture(home, filename)
  const runner = async (_command, args) => {
    if (args.includes('--dump-default-config')) return successfulOfficialResult(args)
    if (args.includes('--dump-config')) return { code: 1, signal: null, stdout: '', stderr: 'invalid mixed config' }
    if (args[0] === 'plugin' && args[3] === 'add') {
      const manifestFile = join(home, 'profiles', args[2], 'package.json')
      const manifest = JSON.parse(await readFile(manifestFile, 'utf8'))
      manifest.dependencies[bundle.install.packageName] = bundle.install.spec
      await writeFile(manifestFile, `${JSON.stringify(manifest, null, 2)}\n`)
    }
    return successfulOfficialResult(args)
  }
  const manager = new ExtensionManager({ home, registry, runner })
  const recipes = new RecipeClient({ home, registry, bundledFile: filename })
  const workshop = new WorkshopBridge({ manager, registry, recipes })
  await assert.rejects(workshop.applyRecipe('interface-kit'), /invalid mixed config/)
  const status = await manager.status()
  assert.equal(status.current, 'web')
  assert.equal(status.pending, null)
  assert.equal(status.failed.length, 1)
  assert.deepEqual((await readProfile(home, 'web')).installed, {})
  assert.deepEqual(await readRepositorySpecs(home, 'web'), [])
})

test('Recipe export contains no specs, commands, local paths, or secrets', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-recipes-export-'))
  const filename = join(home, 'recipes.json')
  const { registry, bundle, repository } = await fixture(home, filename)
  await createProfile(home, 'web', {
    dependencies: { [bundle.install.packageName]: bundle.install.spec },
    bundles: ['@deepseek-ai/dsh-base', bundle.install.packageName],
  })
  await writeRepositorySpecs(home, 'web', [repository.install.spec])
  const manager = new ExtensionManager({ home, registry })
  const recipes = new RecipeClient({ home, registry, bundledFile: filename })
  const draft = await new WorkshopBridge({ manager, registry, recipes }).exportRecipe()
  assert.equal(draft.schema, 'omdsh-workshop-recipe-draft/v1')
  assert.deepEqual(draft.items.map(item => item.projectId).sort(), ['example-bundle', 'example-repository'])
  const serialized = JSON.stringify(draft)
  assert.doesNotMatch(serialized, /git\+https:|github:|command|secret|\/profiles\//)
})
