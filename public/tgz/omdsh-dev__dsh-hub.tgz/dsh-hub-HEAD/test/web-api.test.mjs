import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { ExtensionManager } from '../dist/manager.mjs'
import {
  dispatchManagementAction, isTrustedManagementRequest, managementView,
} from '../dist/web-api.mjs'
import { createProfile } from '../test-support/helpers.mjs'

test('management endpoint accepts same-origin loopback and rejects cross-site or LAN authorities', () => {
  assert.equal(isTrustedManagementRequest({ headers: { host: '127.0.0.1:3000', origin: 'http://127.0.0.1:3000' } }), true)
  assert.equal(isTrustedManagementRequest({ headers: { host: 'localhost:3000', 'sec-fetch-site': 'same-origin' } }), true)
  assert.equal(isTrustedManagementRequest({ headers: { host: 'localhost:3000', 'sec-fetch-site': 'cross-site' } }), false)
  assert.equal(isTrustedManagementRequest({ headers: { host: '192.168.1.20:3000' } }), false)
  assert.equal(isTrustedManagementRequest({ headers: { host: 'attacker.example', origin: 'http://attacker.example' } }), false)
})

test('management view reads official Profile facts and stages writes in a candidate', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-web-api-'))
  await createProfile(home, 'web', {
    dependencies: { '@deepseek-ai/dsh-base': '1.0.0' },
    bundles: ['@deepseek-ai/dsh-base'],
  })
  const manager = new ExtensionManager({
    home,
    runner: async () => ({ code: 0, signal: null, stdout: '', stderr: '' }),
  })
  const initial = await managementView(manager)
  assert.equal(initial.schema, 'omdsh.management-view/v1')
  assert.equal(initial.currentProfile.enabled.includes('@deepseek-ai/dsh-base'), true)
  assert.equal(initial.inventory.current.installed[0].packageName, '@deepseek-ai/dsh-base')
  assert.equal(initial.inventory.current.installed[0].management.level, 'profile-managed')

  const result = await dispatchManagementAction(manager, {
    action: 'disable', profile: 'web', packageName: '@deepseek-ai/dsh-base',
  })
  assert.equal(result.view.status.current, 'web')
  assert.notEqual(result.view.status.pending, null)
  assert.equal(result.view.currentProfile.enabled.includes('@deepseek-ai/dsh-base'), true)
  assert.equal(result.view.pendingProfile.enabled.includes('@deepseek-ai/dsh-base'), false)
  assert.equal(result.view.inventory.pending.installed[0].enabled, false)
})

test('a broken Registry does not hide installed extensions or recovery controls', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-web-api-registry-fail-'))
  await createProfile(home, 'web', {
    dependencies: { '@deepseek-ai/dsh-base': '1.0.0' },
    bundles: ['@deepseek-ai/dsh-base'],
  })
  const manager = new ExtensionManager({ home })
  const view = await managementView(manager, 'web', {
    async view() { throw new Error('invalid signature') },
  })
  assert.equal(view.currentProfile.name, 'web')
  assert.deepEqual(view.market.entries, [])
  assert.match(view.market.error, /invalid signature/)
  assert.equal(view.inventory.current.installed.length, 1)
})

test('Web management never exposes package-manager script opt-in', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-web-api-scripts-'))
  await createProfile(home)
  const calls = []
  const manager = {
    home,
    async stageInstall(options) { calls.push(options); return {} },
    async status() { return { current: 'web', previous: null, pending: null, bootAttempt: null, failed: [], events: [] } },
    async storage() { return { totals: { generations: 0, apparentBytes: 0, allocatedBytes: 0 }, generations: [] } },
  }
  await dispatchManagementAction(manager, {
    action: 'install', packageName: 'plugin', spec: 'plugin@1', allowScripts: true,
  })
  assert.equal(calls[0].allowScripts, false)
})

test('market installation sends only the Registry id to the server-side manager', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-web-api-market-'))
  await createProfile(home)
  const calls = []
  const manager = {
    home,
    async stageMarketInstall(id, options) { calls.push({ id, options }); return {} },
    async status() { return { current: 'web', previous: null, pending: null, bootAttempt: null, failed: [], events: [] } },
    async storage() { return { totals: { generations: 0, apparentBytes: 0, allocatedBytes: 0 }, generations: [] } },
  }
  const registry = {
    async resolveInstall(id) {
      assert.equal(id, 'reviewed-extension')
      return { packageName: '@reviewed/extension', spec: '2.3.4' }
    },
    async view() { return { schema: 'omdsh.registry-view/v1', entries: [] } },
  }
  await dispatchManagementAction(manager, {
    action: 'install-market',
    id: 'reviewed-extension',
    packageName: '@attacker/substitution',
    spec: 'latest',
    allowScripts: true,
  }, registry)
  assert.deepEqual(calls[0], { id: 'reviewed-extension', options: { profile: 'web' } })
})

test('collection installation sends only a signed collection id to WorkshopBridge', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-web-api-collection-'))
  await createProfile(home)
  const calls = []
  const manager = {
    home,
    async status() { return { current: 'web', previous: null, pending: null, bootAttempt: null, failed: [], events: [] } },
    async storage() { return { totals: { generations: 0, apparentBytes: 0, allocatedBytes: 0 }, generations: [] } },
  }
  const workshop = {
    async installCollection(id, options) { calls.push({ id, options }); return {} },
    async view() { return { schema: 'omdsh.workshop-view/v1' } },
  }
  await dispatchManagementAction(manager, {
    action: 'install-collection',
    id: 'research-workbench',
    items: [{ packageName: '@attacker/replacement', spec: 'latest' }],
  }, {}, workshop)
  assert.deepEqual(calls, [{ id: 'research-workbench', options: { profile: 'web' } }])
})

test('Recipe preview and apply send only an id and Registry snapshot boundary', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-web-api-recipe-'))
  await createProfile(home)
  const calls = []
  const manager = {
    home,
    async status() { return { current: 'web', previous: null, pending: null, bootAttempt: null, failed: [], events: [] } },
    async storage() { return { totals: { generations: 0, apparentBytes: 0, allocatedBytes: 0 }, generations: [] } },
  }
  const workshop = {
    async planRecipe(id, options) {
      calls.push({ action: 'plan', id, options })
      return { schema: 'omdsh.recipe-plan/v1', recipeId: id }
    },
    async applyRecipe(id, options) {
      calls.push({ action: 'apply', id, options })
      return { pending: 'web--candidate' }
    },
    async view() { return { schema: 'omdsh.workshop-view/v1' } },
  }
  await dispatchManagementAction(manager, {
    action: 'plan-recipe', id: 'interface-kit', items: [{ spec: 'latest' }],
  }, {}, workshop)
  await dispatchManagementAction(manager, {
    action: 'apply-recipe', id: 'interface-kit', registrySnapshotId: `sha256:${'1'.repeat(64)}`,
    items: [{ id: 'attacker', spec: 'latest' }],
  }, {}, workshop)
  assert.deepEqual(calls, [
    { action: 'plan', id: 'interface-kit', options: { profile: 'web' } },
    {
      action: 'apply', id: 'interface-kit',
      options: { profile: 'web', expectedSnapshotId: `sha256:${'1'.repeat(64)}` },
    },
  ])
})

test('Recipe export is delegated to WorkshopBridge without accepting client content', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-web-api-recipe-export-'))
  await createProfile(home)
  const calls = []
  const manager = {
    home,
    async status() { return { current: 'web', previous: null, pending: null, bootAttempt: null, failed: [], events: [] } },
    async storage() { return { totals: { generations: 0, apparentBytes: 0, allocatedBytes: 0 }, generations: [] } },
  }
  const workshop = {
    async exportRecipe(profile) { calls.push(profile); return { schema: 'omdsh-workshop-recipe-draft/v1' } },
    async view() { return { schema: 'omdsh.workshop-view/v1' } },
  }
  const result = await dispatchManagementAction(manager, {
    action: 'export-recipe', profile: 'web', secret: 'do-not-copy',
  }, {}, workshop)
  assert.deepEqual(calls, ['web'])
  assert.equal(result.operation.schema, 'omdsh-workshop-recipe-draft/v1')
})
