import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { apply, name } from '../dist/index.mjs'
import { ExtensionManager } from '../dist/manager.mjs'
import { createProfile } from '../test-support/helpers.mjs'

test('Cordis entry consumes one Runtime manager without duplicating it', async () => {
  const home = await mkdtemp(join(tmpdir(), 'omdsh-bundle-'))
  await createProfile(home)
  const manager = new ExtensionManager({ home })
  const provided = new Map()
  const ctx = {
    get(key) {
      if (key === 'omdshExtensions') return manager
      return undefined
    },
    provide(key, value) { provided.set(key, value) },
  }
  apply(ctx)
  assert.equal(name, 'omdsh-hub')
  assert.equal(provided.has('omdshExtensions'), false)
  assert.ok(Array.isArray((await provided.get('omdshWorkshop').view()).collections))
  assert.equal(provided.has('extensions'), false)
})

test('Cordis entry refuses to duplicate the Runtime service', () => {
  assert.throws(() => apply({ get() { return undefined }, provide() {} }), /requires the omdshExtensions service/)
})
