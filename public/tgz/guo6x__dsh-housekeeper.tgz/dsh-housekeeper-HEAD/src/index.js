/**
 * dsh-housekeeper host plugin v0.2.
 *
 * Environment housekeeper for DeepSeek Harness:
 *  - toolchain probe → inventory table
 *  - honest scratch/cache scan (sizes, mtimes, truncation markers)
 *  - SAFE two-step cleanup (strict whitelist + realpath + expiring plan,
 *    loopback-only)
 *  - machine rules file ($DSH_HOME/AGENTS.md) view/edit WITH automatic
 *    .bak snapshot before every save and one-command restore
 *  - directory content preview (only for cleanable paths)
 *  - configurable scan roots (defaults per platform, env + config file)
 *  - agent tools housekeeper_report / housekeeper_plan / housekeeper_clean
 */
import { existsSync } from 'node:fs'
import { readdir, realpath, rm, stat, lstat, readFile, writeFile, rename, mkdir } from 'node:fs/promises'
import { execFileSync } from 'node:child_process'
import { join, resolve, sep, dirname, basename } from 'node:path'
import { homedir } from 'node:os'
import { randomUUID } from 'node:crypto'

export const name = 'dsh-housekeeper'
export const inject = ['webServer', 'tools']

const LOOPBACKS = new Set(['127.0.0.1', '::1', '::ffff:127.0.0.1'])
const MAX_RULES_BYTES = 65536
const MAX_WALK_FILES = 4000
const MAX_LIST_ENTRIES = 200
const MAX_CLEAN_PATHS = 10
const MAX_PREVIEW_ENTRIES = 24
const CLEANUP_PLAN_TTL_MS = 5 * 60 * 1000
const VERSION_TIMEOUT_MS = 10_000

function dshHome() {
  return process.env.DSH_HOME ?? join(homedir(), '.dsh')
}

export function configFilePath() {
  return join(dshHome(), 'housekeeper.json')
}

/** Per-platform default roots; env overrides both. */
export function defaultRoots() {
  const env = process.env
  if (process.platform === 'win32') {
    return {
      projects: env.DSH_HOUSEKEEPER_PROJECTS ?? 'D:\\github',
      cache: env.DSH_HOUSEKEEPER_CACHE ?? 'D:\\environment\\cache',
    }
  }
  return {
    projects: env.DSH_HOUSEKEEPER_PROJECTS ?? join(homedir(), 'projects'),
    cache: env.DSH_HOUSEKEEPER_CACHE ?? join(homedir(), '.cache', 'dsh'),
  }
}

export async function loadConfig() {
  const defaults = defaultRoots()
  let fromFile = {}
  try {
    const parsed = JSON.parse(await readFile(configFilePath(), 'utf8'))
    if (typeof parsed.projects === 'string' && parsed.projects.length > 0) fromFile.projects = parsed.projects
    if (typeof parsed.cache === 'string' && parsed.cache.length > 0) fromFile.cache = parsed.cache
  } catch {}
  return { projects: fromFile.projects ?? defaults.projects, cache: fromFile.cache ?? defaults.cache }
}

export async function saveConfig(next) {
  const current = await loadConfig()
  const config = {
    projects: typeof next?.projects === 'string' && next.projects.length > 0 ? next.projects : current.projects,
    cache: typeof next?.cache === 'string' && next.cache.length > 0 ? next.cache : current.cache,
  }
  await atomicWrite(configFilePath(), JSON.stringify(config, null, 2) + '\n')
  return config
}

/** Write beside the target then rename, so rules/config are never half-written. */
async function atomicWrite(path, content) {
  const directory = dirname(path)
  await mkdir(directory, { recursive: true })
  const temporary = join(directory, `.${basename(path)}.${process.pid}.${randomUUID()}.tmp`)
  try {
    await writeFile(temporary, content, 'utf8')
    await rename(temporary, path)
  } catch (error) {
    await rm(temporary, { force: true }).catch(() => {})
    throw error
  }
}

export const TOOL_CANDIDATES = [
  {
    name: 'node',
    display: 'Node.js',
    versionArg: ['--version'],
    candidates: [
      'D:\\environment\\node\\node-v22.23.2-win-x64\\node.exe',
      'C:\\Program Files\\nodejs\\node.exe',
      '/usr/bin/node',
      '/opt/homebrew/bin/node',
    ],
  },
  {
    name: 'pnpm',
    display: 'pnpm',
    versionArg: ['--version'],
    candidates: [
      'D:\\environment\\node\\node-v22.23.2-win-x64\\pnpm.CMD',
      'D:\\environment\\node\\node-v22.23.2-win-x64\\pnpm.cmd',
      'C:\\Program Files\\nodejs\\pnpm.cmd',
    ],
  },
  {
    name: 'git',
    display: 'Git',
    versionArg: ['--version'],
    candidates: [
      'D:\\environment\\Git\\cmd\\git.exe',
      'C:\\Program Files\\Git\\cmd\\git.exe',
      '/usr/bin/git',
    ],
  },
  {
    name: 'gh',
    display: 'GitHub CLI',
    versionArg: ['--version'],
    candidates: [
      'D:\\environment\\github-cli\\bin\\gh.exe',
      'C:\\Program Files\\GitHub CLI\\gh.exe',
      '/usr/bin/gh',
    ],
  },
  {
    name: 'ffmpeg',
    display: 'FFmpeg',
    versionArg: ['-version'],
    candidates: [
      'D:\\environment\\ffmpeg\\ffmpeg.exe',
      'C:\\ffmpeg\\bin\\ffmpeg.exe',
      '/usr/bin/ffmpeg',
    ],
  },
  {
    name: 'edge',
    display: 'Microsoft Edge',
    versionArg: ['--version'],
    candidates: [
      'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
      'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
      'D:\\environment\\edge\\msedge.exe',
      '/usr/bin/microsoft-edge',
    ],
  },
  {
    name: 'chrome',
    display: 'Google Chrome',
    versionArg: ['--version'],
    candidates: [
      'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
      'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
      'C:\\Users\\' + (process.env.USERNAME ?? '') + '\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe',
      '/usr/bin/google-chrome',
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    ],
  },
]

function findOnPath(command) {
  try {
    const where = process.platform === 'win32' ? 'where' : 'which'
    const out = execFileSync(where, [command], { stdio: ['ignore', 'pipe', 'ignore'], timeout: 4000, windowsHide: true })
    const lines = outputLines(out)
    // `where` may return both a PATHEXT-less shim and its real Windows
    // launcher (for example `pnpm` followed by `pnpm.CMD`). Prefer a known
    // executable/script extension so the version probe can launch it.
    const line = process.platform === 'win32'
      ? lines.find(candidate => /\.(?:exe|cmd|bat)$/i.test(candidate)) ?? lines[0]
      : lines[0]
    return line && line.length > 0 ? line : null
  } catch {
    return null
  }
}

function outputLines(value) {
  return value.toString('utf8').split(/\r?\n/).map(line => line.trim()).filter(Boolean)
}

function firstOutputLine(value) {
  return outputLines(value)[0] ?? null
}

function readWindowsFileVersion(path) {
  try {
    // Chromium's --version output is a localized "open in the existing
    // browser session" message on Windows, not the executable version. Read
    // the version resource instead so the inventory remains deterministic and
    // independent of the user's code page or running browser sessions.
    const literalPath = path.replaceAll("'", "''")
    const out = execFileSync('powershell.exe', [
      '-NoProfile',
      '-NonInteractive',
      '-Command',
      `(Get-Item -LiteralPath '${literalPath}').VersionInfo.ProductVersion`,
    ], { stdio: ['ignore', 'pipe', 'pipe'], timeout: VERSION_TIMEOUT_MS, windowsHide: true })
    const line = firstOutputLine(out)
    return line && line.length < 160 ? line : null
  } catch {
    return null
  }
}

function readVersion(path, versionArg, toolName) {
  if (process.platform === 'win32' && (toolName === 'edge' || toolName === 'chrome')) {
    return readWindowsFileVersion(path)
  }
  try {
    const out = execFileSync(path, versionArg, {
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: VERSION_TIMEOUT_MS,
      windowsHide: true,
      // Windows cannot execute .cmd/.bat files directly through spawnSync.
      // Use the native shell only for the known tool path discovered above.
      shell: process.platform === 'win32' && /\.(?:cmd|bat)$/i.test(path),
    })
    const line = firstOutputLine(out)
    return line && line.length < 160 ? line : null
  } catch {
    return null
  }
}

export function probeToolchain(options = {}) {
  const withVersions = options.withVersions ?? true
  return TOOL_CANDIDATES.map(tool => {
    let path = tool.candidates.find(candidate => existsSync(candidate))
    if (path === undefined) path = findOnPath(tool.name)
    const entry = { name: tool.name, display: tool.display, path, version: null }
    if (path !== null && withVersions) entry.version = readVersion(path, tool.versionArg, tool.name)
    return entry
  })
}

async function dirSize(root) {
  let bytes = 0
  let files = 0
  let truncated = false
  const pending = [root]
  while (pending.length > 0) {
    const dir = pending.pop()
    let entries
    try {
      entries = await readdir(dir, { withFileTypes: true })
    } catch {
      continue
    }
    for (const entry of entries) {
      if (files >= MAX_WALK_FILES) {
        truncated = true
        break
      }
      const full = join(dir, entry.name)
      if (entry.isDirectory()) {
        pending.push(full)
      } else {
        files++
        try {
          bytes += (await stat(full)).size
        } catch {}
      }
    }
    if (truncated) break
  }
  return { bytes, files, truncated }
}

export async function scanCaches(roots) {
  const items = []
  const isDirectory = async path => {
    try {
      const info = await lstat(path)
      return info.isDirectory() && !info.isSymbolicLink()
    } catch {
      return false
    }
  }
  const push = async (path, source) => {
    const size = await dirSize(path)
    let mtime = null
    try { mtime = (await stat(path)).mtimeMs } catch {}
    items.push({ path, source, bytes: size.bytes, files: size.files, truncated: size.truncated, mtime })
  }

  try {
    const repos = await readdir(roots.projects, { withFileTypes: true })
    for (const repo of repos) {
      if (!repo.isDirectory() || items.length >= MAX_LIST_ENTRIES) continue
      const tmp = join(roots.projects, repo.name, '.tmp')
      if (await isDirectory(tmp)) await push(tmp, 'project-tmp')
    }
  } catch {}

  try {
    const entries = await readdir(roots.cache, { withFileTypes: true })
    for (const entry of entries) {
      if (items.length >= MAX_LIST_ENTRIES) break
      if (!entry.isDirectory()) continue
      await push(join(roots.cache, entry.name), 'cache')
    }
  } catch {}

  items.sort((a, b) => b.bytes - a.bytes)
  return items
}

async function confinedUnder(path, root) {
  const real = await realpath(path).catch(() => null)
  const realRoot = await realpath(root).catch(() => null)
  if (real === null || realRoot === null) return false
  return real === realRoot || real.startsWith(realRoot + sep)
}

const escapeRe = string => string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
const sepRe = sep === '\\' ? '\\\\' : '/'

export async function isCleanable(path, roots) {
  const normalized = resolve(path)
  const projects = resolve(roots.projects)
  const cache = resolve(roots.cache)

  const projectTmpRoot = new RegExp(`^${escapeRe(projects)}${sepRe}[^\\\\/]+\\${sep === '\\' ? '\\' : ''}?\\.tmp$`, 'i')
  const projectTmp = new RegExp(`^${escapeRe(projects)}${sepRe}[^\\\\/]+\\${sep === '\\' ? '\\' : ''}?\\.tmp(?:${sepRe}|$)`, 'i')
  const cacheChild = new RegExp(`^${escapeRe(cache)}${sepRe}[^\\\\/]+$`, 'i')

  if (projectTmpRoot.test(normalized)) return confinedUnder(normalized, projects)
  if (projectTmp.test(normalized)) return confinedUnder(normalized, projects)
  if (cacheChild.test(normalized)) return confinedUnder(normalized, cache)
  return false
}

export async function cleanPaths(paths, roots) {
  const removed = []
  const rejected = []
  const list = Array.isArray(paths) ? paths.slice(0, MAX_CLEAN_PATHS) : []
  for (const path of list) {
    if (typeof path !== 'string' || path.length === 0) {
      rejected.push({ path: String(path), reason: 'invalid path' })
      continue
    }
    if (!await isCleanable(path, roots)) {
      rejected.push({ path, reason: 'not in the cleanup whitelist' })
      continue
    }
    try {
      await rm(path, { recursive: true, force: true })
      removed.push(path)
    } catch (error) {
      rejected.push({ path, reason: String(error.message ?? error) })
    }
  }
  return { removed, rejected }
}

/**
 * In-memory, single-use cleanup plans. A path is checked both while planning
 * and immediately before deletion, so an agent cannot turn a report into an
 * accidental direct delete call.
 */
export class CleanupPlanStore {
  constructor({ ttlMs = CLEANUP_PLAN_TTL_MS, now = () => Date.now() } = {}) {
    this.ttlMs = ttlMs
    this.now = now
    this.plans = new Map()
  }

  prune() {
    const now = this.now()
    for (const [token, plan] of this.plans) {
      if (plan.expiresAt <= now) this.plans.delete(token)
    }
  }

  async create(paths, roots) {
    this.prune()
    const approved = []
    const rejected = []
    const list = Array.isArray(paths) ? paths.slice(0, MAX_CLEAN_PATHS) : []
    for (const path of list) {
      if (typeof path !== 'string' || path.length === 0) {
        rejected.push({ path: String(path), reason: 'invalid path' })
      } else if (await isCleanable(path, roots)) {
        approved.push(path)
      } else {
        rejected.push({ path, reason: 'not in the cleanup whitelist' })
      }
    }
    if (approved.length === 0) return { ok: false, token: null, approved, rejected, expiresAt: null }

    const token = randomUUID()
    const expiresAt = this.now() + this.ttlMs
    this.plans.set(token, {
      paths: approved,
      roots: { projects: resolve(roots.projects), cache: resolve(roots.cache) },
      expiresAt,
    })
    return { ok: true, token, approved, rejected, expiresAt }
  }

  async execute(token, roots) {
    this.prune()
    if (typeof token !== 'string' || token.length === 0) {
      return { ok: false, error: 'cleanup plan token is required' }
    }
    const plan = this.plans.get(token)
    if (plan === undefined) {
      return { ok: false, error: 'cleanup plan is unknown, expired, or already used; create a new plan' }
    }
    // Consume before deleting, so a network retry cannot replay a destructive action.
    this.plans.delete(token)
    const rootsChanged = !samePath(plan.roots.projects, resolve(roots.projects)) || !samePath(plan.roots.cache, resolve(roots.cache))
    if (rootsChanged) {
      return { ok: false, error: 'cleanup roots changed since the plan was created; create a new plan' }
    }
    return { ok: true, ...(await cleanPaths(plan.paths, roots)) }
  }
}

function samePath(left, right) {
  return process.platform === 'win32' ? left.toLowerCase() === right.toLowerCase() : left === right
}

/** Preview the direct children of a cleanable directory. */
export async function previewPath(path, roots, limit = MAX_PREVIEW_ENTRIES) {
  if (!await isCleanable(path, roots)) {
    return { ok: false, error: 'preview only allowed for cleanable paths' }
  }
  let entries
  try {
    entries = await readdir(path, { withFileTypes: true })
  } catch (error) {
    return { ok: false, error: String(error.message ?? error) }
  }
  const children = []
  for (const entry of entries) {
    const full = join(path, entry.name)
    let size = 0
    let mtime = null
    try {
      const info = await lstat(full)
      if (info.isSymbolicLink()) continue
      mtime = info.mtimeMs
      if (info.isFile()) size = info.size
      else if (info.isDirectory()) size = (await dirSize(full)).bytes
    } catch {}
    children.push({ name: entry.name, dir: entry.isDirectory(), size, mtime })
  }
  children.sort((a, b) => (b.dir - a.dir) || (b.size - a.size))
  return { ok: true, path, entries: children.slice(0, limit), total: children.length }
}

export function rulesFilePath() {
  return join(dshHome(), 'AGENTS.md')
}

function backupPath() {
  return rulesFilePath() + '.bak'
}

async function readRulesFile(path) {
  try {
    return { content: await readFile(path, 'utf8'), mtime: (await stat(path)).mtimeMs }
  } catch {
    return { content: null, mtime: null }
  }
}

/** Save rules content; the previous state lands in AGENTS.md.bak first. */
export async function saveRules(content) {
  if (typeof content !== 'string' || content.length > MAX_RULES_BYTES) {
    throw new Error(`content must be a string up to ${MAX_RULES_BYTES} bytes`)
  }
  const path = rulesFilePath()
  const current = await readRulesFile(path)
  if (current.content !== null) await atomicWrite(backupPath(), current.content)
  await atomicWrite(path, content)
  return { path, backup: await readRulesFile(backupPath()) }
}

/** Restore the backup; the current state is kept as the new backup. */
export async function restoreRules() {
  const path = rulesFilePath()
  const backup = await readRulesFile(backupPath())
  if (backup.content === null) throw new Error('no backup available (never saved via the panel)')
  const current = await readRulesFile(path)
  if (current.content !== null) await atomicWrite(backupPath(), current.content)
  await atomicWrite(path, backup.content)
  return { path, backup: await readRulesFile(backupPath()) }
}

function sendJson(res, status, value) {
  const body = JSON.stringify(value)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
  res.end(body)
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0
    const chunks = []
    req.on('data', chunk => {
      size += chunk.length
      if (size > 131072) {
        reject(new Error('body too large'))
        req.destroy()
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
    req.on('error', reject)
  })
}

const textBlock = text => [{ type: 'text', text }]

export function apply(ctx) {
  const webServer = ctx.webServer
  const tools = ctx.tools
  const cleanupPlans = new CleanupPlanStore()

  ctx.effect(() => webServer.register({
    kind: 'prefix',
    path: '/housekeeper',
    handler: async (req, res) => {
      const remote = req.socket.remoteAddress ?? ''
      if (!LOOPBACKS.has(remote)) {
        sendJson(res, 403, { error: 'loopback only' })
        return
      }
      const url = new URL(req.url ?? '/', 'http://x')
      const suffix = url.pathname.slice('/housekeeper'.length) || '/'
      try {
        if (req.method === 'GET' && suffix === '/state') {
          const roots = await loadConfig()
          const [inventory, caches] = await Promise.all([probeToolchain(), scanCaches(roots)])
          sendJson(res, 200, { inventory, caches, roots })
        } else if (req.method === 'POST' && suffix === '/clean/plan') {
          const body = JSON.parse(await readBody(req) || '{}')
          if (!Array.isArray(body.paths)) {
            sendJson(res, 400, { error: 'paths must be an array' })
            return
          }
          sendJson(res, 200, await cleanupPlans.create(body.paths, await loadConfig()))
        } else if (req.method === 'POST' && suffix === '/clean') {
          const body = JSON.parse(await readBody(req) || '{}')
          if (typeof body.token !== 'string') {
            sendJson(res, 400, { error: 'cleanup plan token is required' })
            return
          }
          sendJson(res, 200, await cleanupPlans.execute(body.token, await loadConfig()))
        } else if (req.method === 'GET' && suffix === '/preview') {
          const path = url.searchParams.get('path')
          if (typeof path !== 'string' || path.length === 0) {
            sendJson(res, 400, { error: 'path query required' })
            return
          }
          sendJson(res, 200, await previewPath(path, await loadConfig()))
        } else if (req.method === 'GET' && suffix === '/rules') {
          const info = await readRulesFile(rulesFilePath())
          const backup = await readRulesFile(backupPath())
          sendJson(res, 200, {
            path: rulesFilePath(),
            content: info.content,
            mtime: info.mtime,
            backup: { exists: backup.content !== null, mtime: backup.mtime, bytes: backup.content?.length ?? 0 },
          })
        } else if (req.method === 'POST' && suffix === '/rules') {
          const body = JSON.parse(await readBody(req) || '{}')
          sendJson(res, 200, await saveRules(body.content))
        } else if (req.method === 'POST' && suffix === '/rules/restore') {
          sendJson(res, 200, await restoreRules())
        } else if (req.method === 'GET' && suffix === '/config') {
          sendJson(res, 200, await loadConfig())
        } else if (req.method === 'POST' && suffix === '/config') {
          const body = JSON.parse(await readBody(req) || '{}')
          sendJson(res, 200, await saveConfig(body))
        } else {
          sendJson(res, 404, { error: 'no such endpoint' })
        }
      } catch (error) {
        sendJson(res, 500, { error: String(error.message ?? error) })
      }
    },
  }), 'dsh-housekeeper: web routes')

  if (tools !== undefined) {
    const define = (nameValue, description, parameters, execute, render) => ({
      name: nameValue,
      description,
      parameters,
      timeoutMs: 30000,
      output: {
        schema: { type: 'object' },
        render(_args, value) {
          const blocks = render(value)
          return blocks.length > 0 ? blocks : textBlock(JSON.stringify(value))
        },
      },
      async execute(args, exec) {
        if (exec?.signal?.aborted) throw new Error('aborted')
        return execute(args)
      },
    })
    const obj = (properties, required = []) => ({ type: 'object', properties, required, additionalProperties: false })

    const defs = [
      define(
        'housekeeper_report',
        'Report this machine environment: detected toolchain (node/pnpm/git/gh/ffmpeg/browsers with versions) and agent scratch/cache directories with sizes and last-modified times. Use it to answer "what is installed" and "what is eating disk" questions.',
        obj({}),
        async () => {
          const roots = await loadConfig()
          const [inventory, caches] = await Promise.all([probeToolchain(), scanCaches(roots)])
          return { roots, inventory, caches }
        },
        value => textBlock(
          `toolchain: ${value.inventory.filter(tool => tool.path !== null).map(tool => `${tool.display} ${tool.version ?? ''}`.trim()).join(' | ')}\n`
          + `scan roots: projects=${value.roots.projects} cache=${value.roots.cache}\n`
          + `caches (${value.caches.length}):\n`
          + value.caches.map(item => `- ${item.path} ${Math.round(item.bytes / 1024)}KB ${item.files}${item.truncated ? '+' : ''} files${item.mtime ? ` (${new Date(item.mtime).toISOString().slice(0, 10)})` : ''}`).join('\n'),
        ),
      ),
      define(
        'housekeeper_plan',
        'Inspect requested scratch/cache directories through the cleanup whitelist and create a single-use cleanup plan. This does NOT delete anything. Review the approved paths, then pass the returned token to housekeeper_clean within five minutes.',
        obj({
          paths: {
            type: 'array',
            items: { type: 'string' },
            description: 'Absolute directory paths to inspect for cleanup (max 10 per call).',
          },
        }, ['paths']),
        async args => cleanupPlans.create(args.paths, await loadConfig()),
        value => textBlock(value.ok
          ? `cleanup plan ready (expires ${new Date(value.expiresAt).toISOString()}):\napproved ${value.approved.length}: ${value.approved.join(', ')}\nrejected ${value.rejected.length}: ${value.rejected.map(item => `${item.path} (${item.reason})`).join('; ') || 'none'}\ntoken: ${value.token}`
          : `no paths approved. rejected ${value.rejected.length}: ${value.rejected.map(item => `${item.path} (${item.reason})`).join('; ') || 'none'}`),
      ),
      define(
        'housekeeper_clean',
        'Execute a previously reviewed, single-use housekeeper_plan token. The token expires after five minutes and paths are checked against the whitelist again immediately before deletion.',
        obj({
          token: { type: 'string', description: 'The single-use token returned by housekeeper_plan.' },
        }, ['token']),
        async args => cleanupPlans.execute(args.token, await loadConfig()),
        value => textBlock(value.ok
          ? `removed ${value.removed.length}: ${value.removed.join(', ') || 'none'}\nrejected ${value.rejected.length}: ${value.rejected.map(item => `${item.path} (${item.reason})`).join('; ') || 'none'}`
          : `cleanup not executed: ${value.error}`),
      ),
    ]
    for (const def of defs) {
      ctx.effect(() => tools.register(def), 'dsh-housekeeper: tool ' + def.name)
    }
  }
}
