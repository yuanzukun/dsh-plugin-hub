/**
 * dsh-housekeeper client v0.2: 环境管家 settings tab.
 * Same-origin fetch to /housekeeper/* (no RPC bridge).
 */
import React, { useCallback, useEffect, useState } from 'react'

export const name = 'dsh-housekeeper'
export const inject = ['slots']

const sectionStyle = {
  background: 'rgba(255,255,255,0.05)',
  border: '1px solid rgba(255,255,255,0.12)',
  borderRadius: 10,
  padding: '12px 14px',
  marginBottom: 12,
}
const h3Style = { margin: '0 0 10px', fontSize: 14, fontWeight: 700 }
const tableStyle = { width: '100%', borderCollapse: 'collapse', fontSize: 12 }
const cellStyle = { padding: '4px 8px', borderBottom: '1px solid rgba(255,255,255,0.08)', textAlign: 'left' }
const monoStyle = { fontFamily: 'Consolas, monospace', fontSize: 11, opacity: 0.85 }
const btnStyle = {
  background: 'rgba(255,255,255,0.12)',
  color: 'inherit',
  border: '1px solid rgba(255,255,255,0.2)',
  borderRadius: 6,
  padding: '5px 12px',
  cursor: 'pointer',
  fontSize: 12,
}
const dangerBtnStyle = { ...btnStyle, background: 'rgba(220,80,70,0.25)', borderColor: 'rgba(220,80,70,0.5)' }
const staleStyle = { color: '#e0b060', fontWeight: 700 }

function fmtBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`
}

function fmtAge(mtime) {
  if (mtime === null || mtime === undefined) return '未知'
  const days = Math.floor((Date.now() - mtime) / 86400000)
  if (days < 1) return '今天'
  if (days === 1) return '1 天前'
  return `${days} 天前`
}

function useHousekeeperState() {
  const [state, setState] = useState(null)
  const [error, setError] = useState('')
  const refresh = useCallback(async () => {
    try {
      const res = await fetch('/housekeeper/state', { cache: 'no-store' })
      if (!res.ok) throw new Error(`http ${res.status}`)
      setState(await res.json())
      setError('')
    } catch (err) {
      setError(String(err.message ?? err))
    }
  }, [])
  useEffect(() => { refresh() }, [refresh])
  return { state, error, refresh }
}

function ToolchainTable({ inventory }) {
  if (!inventory?.length) return React.createElement('div', null, '暂无数据')
  return React.createElement('table', { style: tableStyle },
    React.createElement('tbody', null,
      inventory.map(tool => React.createElement('tr', { key: tool.name },
        React.createElement('td', { style: { ...cellStyle, width: 130 } }, tool.display),
        React.createElement('td', { style: cellStyle },
          tool.path
            ? React.createElement('span', { style: monoStyle }, tool.path)
            : React.createElement('span', { style: { opacity: 0.5 } }, '未找到')),
        React.createElement('td', { style: { ...cellStyle, width: 220 } },
          tool.version
            ? React.createElement('span', { style: monoStyle }, tool.version)
            : React.createElement('span', { style: { opacity: 0.4 } }, '—')),
      ))))
}

function PreviewRow({ path }) {
  const [preview, setPreview] = useState(null)
  const [error, setError] = useState('')
  useEffect(() => {
    let alive = true
    ;(async () => {
      try {
        const res = await fetch(`/housekeeper/preview?path=${encodeURIComponent(path)}`, { cache: 'no-store' })
        if (!res.ok) throw new Error(`http ${res.status}`)
        const data = await res.json()
        if (!alive) return
        if (data.ok) setPreview(data)
        else setError(data.error)
      } catch (err) {
        if (alive) setError(String(err.message ?? err))
      }
    })()
    return () => { alive = false }
  }, [path])
  if (error) return React.createElement('tr', null, React.createElement('td', { colSpan: 5, style: cellStyle }, `预览失败：${error}`))
  if (preview === null) return React.createElement('tr', null, React.createElement('td', { colSpan: 5, style: cellStyle }, '加载中…'))
  if (preview.entries.length === 0) return React.createElement('tr', null, React.createElement('td', { colSpan: 5, style: cellStyle }, '空目录'))
  return React.createElement(React.Fragment, null,
    preview.entries.map(entry => React.createElement('tr', { key: entry.name, style: { background: 'rgba(0,0,0,0.2)' } },
      React.createElement('td', { colSpan: 2, style: { ...cellStyle, paddingLeft: 28 } },
        React.createElement('span', { style: monoStyle }, `${entry.dir ? '📁' : '📄'} ${entry.name}`)),
      React.createElement('td', { style: cellStyle }, fmtBytes(entry.size)),
      React.createElement('td', { style: cellStyle }, entry.dir ? '—' : ''),
      React.createElement('td', { style: cellStyle }, fmtAge(entry.mtime)),
    )),
    preview.total > preview.entries.length
      ? React.createElement('tr', null, React.createElement('td', { colSpan: 5, style: { ...cellStyle, opacity: 0.6 } }, `…还有 ${preview.total - preview.entries.length} 项未列出`))
      : null,
  )
}

function CachePanel({ state, refresh }) {
  const [checked, setChecked] = useState(new Set())
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState(null)
  const [plan, setPlan] = useState(null)
  const [expanded, setExpanded] = useState(null)

  const toggle = path => {
    const next = new Set(checked)
    if (next.has(path)) next.delete(path)
    else next.add(path)
    setChecked(next)
    setPlan(null)
  }

  const runClean = async () => {
    const paths = [...checked]
    if (paths.length === 0) return
    setBusy(true)
    setResult(null)
    try {
      const isConfirming = plan !== null
      const res = await fetch(isConfirming ? '/housekeeper/clean' : '/housekeeper/clean/plan', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(isConfirming ? { token: plan.token } : { paths }),
      })
      if (!res.ok) throw new Error(`http ${res.status}`)
      const outcome = await res.json()
      if (!isConfirming) {
        if (outcome.ok && outcome.token) {
          setPlan(outcome)
          setResult({ message: `已生成一次性清理计划：${outcome.approved.length} 项，5 分钟内确认执行。` })
        } else {
          setResult({ error: `没有可清理的目录。${outcome.rejected?.map(item => item.reason).join('；') ?? ''}` })
        }
      } else {
        setPlan(null)
        setResult(outcome)
        setChecked(new Set())
        setExpanded(null)
        if (outcome.ok) await refresh()
      }
    } catch (err) {
      setResult({ error: String(err.message ?? err) })
    } finally {
      setBusy(false)
    }
  }

  const caches = state?.caches ?? []
  if (caches.length === 0) {
    return React.createElement('div', { style: { fontSize: 12, opacity: 0.6 } }, '没扫到可清理的缓存目录，很干净。')
  }
  const total = caches.reduce((sum, item) => sum + item.bytes, 0)

  return React.createElement('div', null,
    React.createElement('table', { style: tableStyle },
      React.createElement('tbody', null,
        caches.flatMap(item => {
          const rows = [React.createElement('tr', {
            key: item.path,
            style: { cursor: 'pointer' },
            onClick: () => setExpanded(expanded === item.path ? null : item.path),
          },
            React.createElement('td', { style: { ...cellStyle, width: 28 }, onClick: event => event.stopPropagation() },
              React.createElement('input', { type: 'checkbox', checked: checked.has(item.path), onChange: () => toggle(item.path) })),
            React.createElement('td', { style: cellStyle },
              React.createElement('span', { style: monoStyle }, item.path)),
            React.createElement('td', { style: { ...cellStyle, width: 90 } }, fmtBytes(item.bytes)),
            React.createElement('td', { style: { ...cellStyle, width: 90 } },
              item.truncated
                ? React.createElement('span', { style: staleStyle, title: '扫描到 4000 文件上限截断，实际大小更大' }, `${item.files}+ 文件*`)
                : `${item.files} 文件`),
            React.createElement('td', { style: { ...cellStyle, width: 90 } },
              item.mtime && (Date.now() - item.mtime) > 30 * 86400000
                ? React.createElement('span', { style: staleStyle, title: '30 天以上未改动' }, `⚠ ${fmtAge(item.mtime)}`)
                : fmtAge(item.mtime)),
          )]
          if (expanded === item.path) rows.push(React.createElement(PreviewRow, { key: item.path + ':preview', path: item.path }))
          return rows
        }))),
    React.createElement('div', { style: { marginTop: 10, display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' } },
      React.createElement('button', {
        style: dangerBtnStyle,
        disabled: busy || (plan === null && checked.size === 0),
        title: plan ? '执行已生成的一次性清理计划' : '先生成清理计划，不会立刻删除',
        onClick: runClean,
      }, plan ? `确认清理（${plan.approved.length} 项）` : `生成清理计划（${checked.size} 项 / ${fmtBytes(total)}）`),
      plan
        ? React.createElement('button', { style: btnStyle, disabled: busy, onClick: () => setPlan(null) }, '取消计划')
        : null,
      React.createElement('span', { style: { fontSize: 11, opacity: 0.6 } }, plan ? '计划为一次性 token，5 分钟后失效；确认后才会删除。' : '点行展开预览 · * 表示扫描截断 · ⚠ 长期未动'),
      result
        ? React.createElement('span', { style: { fontSize: 11, color: result.error ? '#e08a8a' : '#8ad08a' } },
            result.error ?? result.message ?? (result.ok === false ? result.error : `已删除 ${result.removed?.length ?? 0} 项，拒绝 ${result.rejected?.length ?? 0} 项`))
        : null,
    ),
  )
}

function RulesPanel() {
  const [data, setData] = useState(null)
  const [content, setContent] = useState(null)
  const [saving, setSaving] = useState(false)
  const [confirmRestore, setConfirmRestore] = useState(false)
  const [message, setMessage] = useState('')

  const load = useCallback(async () => {
    try {
      const res = await fetch('/housekeeper/rules', { cache: 'no-store' })
      if (!res.ok) throw new Error(`http ${res.status}`)
      const next = await res.json()
      setData(next)
      setContent(next.content ?? '')
      if (next.content === null) setMessage('规则文件还不存在，保存后将创建。')
    } catch (err) {
      setMessage(String(err.message ?? err))
    }
  }, [])
  useEffect(() => { load() }, [load])

  const save = async () => {
    setSaving(true)
    setMessage('')
    try {
      const res = await fetch('/housekeeper/rules', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ content }),
      })
      if (!res.ok) throw new Error(`http ${res.status}`)
      setMessage('已保存（旧版已自动备份），agent 会话实时生效。')
      setConfirmRestore(false)
      await load()
    } catch (err) {
      setMessage(String(err.message ?? err))
    } finally {
      setSaving(false)
    }
  }

  const restore = async () => {
    if (!confirmRestore) {
      setConfirmRestore(true)
      return
    }
    setSaving(true)
    setMessage('')
    try {
      const res = await fetch('/housekeeper/rules/restore', { method: 'POST' })
      if (!res.ok) throw new Error(`http ${res.status}`)
      setMessage('已恢复到上次保存前的版本（当前版本转存为备份）。')
      setConfirmRestore(false)
      await load()
    } catch (err) {
      setMessage(String(err.message ?? err))
    } finally {
      setSaving(false)
    }
  }

  return React.createElement('div', null,
    React.createElement('div', { style: { fontSize: 11, opacity: 0.65, marginBottom: 8, display: 'flex', gap: 12, flexWrap: 'wrap' } },
      React.createElement('span', { style: monoStyle }, data?.path ?? 'AGENTS.md'),
      data?.backup?.exists
        ? React.createElement('span', null, `备份：${new Date(data.backup.mtime).toLocaleString()}（${fmtBytes(data.backup.bytes)}）`)
        : React.createElement('span', { style: { opacity: 0.5 } }, '暂无备份'),
    ),
    React.createElement('textarea', {
      value: content ?? '',
      onChange: event => setContent(event.target.value),
      spellCheck: false,
      style: {
        width: '100%',
        minHeight: 260,
        boxSizing: 'border-box',
        background: 'rgba(0,0,0,0.25)',
        color: 'inherit',
        border: '1px solid rgba(255,255,255,0.15)',
        borderRadius: 8,
        padding: 10,
        fontFamily: 'Consolas, monospace',
        fontSize: 12,
        resize: 'vertical',
      },
    }),
    React.createElement('div', { style: { marginTop: 10, display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' } },
      React.createElement('button', { style: btnStyle, disabled: saving || content === null, onClick: save }, saving ? '保存中…' : '保存（自动备份）'),
      React.createElement('button', {
        style: btnStyle,
        disabled: saving || !data?.backup?.exists,
        title: '恢复上次保存前的版本',
        onClick: restore,
      }, confirmRestore ? '再点一次确认恢复' : '恢复备份'),
      message ? React.createElement('span', { style: { fontSize: 11, opacity: 0.7 } }, message) : null,
    ),
  )
}

function ConfigPanel({ state, refresh }) {
  const [projects, setProjects] = useState('')
  const [cache, setCache] = useState('')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    setProjects(state?.roots?.projects ?? '')
    setCache(state?.roots?.cache ?? '')
  }, [state])

  const save = async () => {
    setBusy(true)
    setMessage('')
    try {
      const res = await fetch('/housekeeper/config', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ projects, cache }),
      })
      if (!res.ok) throw new Error(`http ${res.status}`)
      setMessage('已保存，重新扫描生效。')
      await refresh()
    } catch (err) {
      setMessage(String(err.message ?? err))
    } finally {
      setBusy(false)
    }
  }

  const inputStyle = {
    width: '100%',
    boxSizing: 'border-box',
    background: 'rgba(0,0,0,0.25)',
    color: 'inherit',
    border: '1px solid rgba(255,255,255,0.15)',
    borderRadius: 6,
    padding: '6px 10px',
    fontFamily: 'Consolas, monospace',
    fontSize: 12,
    marginBottom: 8,
  }

  return React.createElement('div', null,
    React.createElement('label', { style: { fontSize: 11, opacity: 0.7 } }, '项目根目录（扫描 <仓库>\\ .tmp）'),
    React.createElement('input', { style: inputStyle, value: projects, onChange: event => setProjects(event.target.value), spellCheck: false }),
    React.createElement('label', { style: { fontSize: 11, opacity: 0.7 } }, '缓存根目录（扫描其直接子目录）'),
    React.createElement('input', { style: inputStyle, value: cache, onChange: event => setCache(event.target.value), spellCheck: false }),
    React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 10 } },
      React.createElement('button', { style: btnStyle, disabled: busy, onClick: save }, busy ? '保存中…' : '保存根目录'),
      message ? React.createElement('span', { style: { fontSize: 11, opacity: 0.7 } }, message) : null,
    ),
  )
}

function HousekeeperPanel() {
  const { state, error, refresh } = useHousekeeperState()
  if (error) return React.createElement('div', { style: { color: '#e08a8a' } }, `加载失败：${error}`)
  if (state === null) return React.createElement('div', { style: { fontSize: 12, opacity: 0.6 } }, '扫描中…')
  return React.createElement('div', { style: { padding: '4px 0' } },
    React.createElement('section', { style: sectionStyle },
      React.createElement('h3', { style: h3Style }, '工具链台账'),
      React.createElement(ToolchainTable, { inventory: state.inventory }),
    ),
    React.createElement('section', { style: sectionStyle },
      React.createElement('h3', { style: h3Style }, '缓存与临时目录'),
      React.createElement(CachePanel, { state, refresh }),
    ),
    React.createElement('section', { style: sectionStyle },
      React.createElement('h3', { style: h3Style }, '扫描根目录'),
      React.createElement(ConfigPanel, { state, refresh }),
    ),
    React.createElement('section', { style: sectionStyle },
      React.createElement('h3', { style: h3Style }, '机器规则（AGENTS.md）'),
      React.createElement(RulesPanel, null),
    ),
  )
}

export function apply(ctx) {
  const slots = ctx.slots
  if (slots === undefined) return
  slots.inject('settings.plugins.tab', () => slots.register(
    { name: 'settings.plugins.tab', id: 'housekeeper', order: 500, label: '环境管家' },
    () => React.createElement(HousekeeperPanel),
  ))
}
