/**
 * Live verification walkthrough: headless GUI instance → Settings → Plugins →
 * 环境管家 tab. Asserts on real DOM text, saves one screenshot.
 */
import { mkdirSync, writeFileSync, rmSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { Pilot } from '../../dsh-pilot/lib/index.js'

const OUT = join(dirname(fileURLToPath(import.meta.url)), '..', '.tmp')
rmSync(OUT, { recursive: true, force: true })
mkdirSync(OUT, { recursive: true })

const sleep = ms => new Promise(r => setTimeout(r, ms))
let failed = 0
const check = (label, condition, extra = '') => {
  const ok = Boolean(condition)
  if (!ok) failed++
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${extra ? ` — ${extra}` : ''}`)
}

const gui = new Pilot()
try {
  await gui.ensure()
  await gui.navigate('http://127.0.0.1:3080/')
  await sleep(7000)

  const probeButtons = await gui.evalJs(`Array.from(document.querySelectorAll('button,[role="tab"],[role="button"]'))
    .map(el => (el.getAttribute('title') || el.textContent || '').trim().slice(0, 30))
    .filter(t => t).slice(0, 60)`)
  console.log('clickable labels:', JSON.stringify(probeButtons.value))

  const clickByText = async (text, label) => {
    const res = await gui.evalJs(`(() => {
      const els = Array.from(document.querySelectorAll('button,[role="tab"],[role="button"]'))
      const el = els.find(e => (e.textContent || '').includes(${JSON.stringify(text)}) || (e.getAttribute('title') || '').includes(${JSON.stringify(text)}))
      if (!el) return { ok: false }
      el.click()
      return { ok: true, tag: el.tagName, text: (el.textContent || el.getAttribute('title') || '').trim().slice(0, 40) }
    })()`)
    if (!res.value?.ok) throw new Error(`could not click ${label}`)
    console.log('clicked:', label, JSON.stringify(res.value))
    await sleep(1500)
  }

  // 1. open settings (sidebar foot trigger)
  await clickByText('设置', 'settings trigger')
  await sleep(1500)

  // 2. find the Plugins section inside settings
  await clickByText('插件', 'plugins section')
  await sleep(1500)

  // 3. the 环境管家 tab
  const tabProbe = await gui.evalJs(`(() => {
    const tabs = Array.from(document.querySelectorAll('[role="tab"]'))
    return tabs.map(t => (t.textContent || '').trim().slice(0, 30)).filter(Boolean)
  })()`)
  console.log('tabs:', JSON.stringify(tabProbe.value))
  await clickByText('环境管家', 'housekeeper tab')
  await sleep(2500)

  // 4. assert panel content
  const text = await gui.evalJs(`document.body ? document.body.innerText.slice(0, 4000) : ''`)
  const body = text.value ?? ''
  check('panel shows 工具链台账', body.includes('工具链台账'))
  check('panel shows 缓存与临时目录', body.includes('缓存与临时目录'))
  check('panel shows AGENTS.md editor', body.includes('机器规则'))
  check('panel lists hone-cargo-target cache', body.includes('hone-cargo-target'))
  check('panel lists ffmpeg tool', body.includes('FFmpeg'))
  check('v0.2: 扫描根目录 section', body.includes('扫描根目录'))
  check('v0.2: restore button', body.includes('恢复备份'))
  check('v0.2: auto-backup label', body.includes('保存（自动备份）'))
  check('v0.2: truncation/age legend', body.includes('点行展开预览'))

  const shot = await gui.captureShot()
  writeFileSync(join(OUT, 'housekeeper-panel.png'), shot)
  console.log('screenshot:', join(OUT, 'housekeeper-panel.png'))
} catch (error) {
  failed++
  console.error('FATAL', error.message)
} finally {
  await gui.dispose()
}
console.log(`\n${failed === 0 ? 'ALL PASS' : `${failed} FAILURES`}`)
process.exit(failed === 0 ? 0 : 1)
