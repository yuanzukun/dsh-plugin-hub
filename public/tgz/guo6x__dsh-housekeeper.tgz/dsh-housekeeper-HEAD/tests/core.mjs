/**
 * dsh-housekeeper core smoke test: probe, scan (incl. truncation), whitelist,
 * clean cap, preview, rules backup/restore, config load/save — all against a
 * throwaway sandbox under .tmp. Child-process pipes are avoided: versions off.
 * Run: node tests/core.mjs
 */
import { mkdirSync, rmSync, writeFileSync, existsSync, readFileSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  probeToolchain, scanCaches, isCleanable, CleanupPlanStore, previewPath,
  saveRules, restoreRules, rulesFilePath, loadConfig, saveConfig, configFilePath,
} from '../lib/index.js'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const SB = join(ROOT, '.tmp', 'sandbox')
const CACHE = join(SB, 'cache-root')
const ROOTS = { projects: join(SB, 'projects'), cache: CACHE }
const FAKE_HOME = join(SB, 'dsh-home')

rmSync(SB, { recursive: true, force: true })
mkdirSync(join(ROOTS.projects, 'repo1', '.tmp', 'sub'), { recursive: true })
mkdirSync(join(ROOTS.projects, 'repo1', 'src'), { recursive: true })
mkdirSync(join(ROOTS.projects, 'repo2'), { recursive: true })
mkdirSync(join(CACHE, 'foo'), { recursive: true })
mkdirSync(FAKE_HOME, { recursive: true })
writeFileSync(join(ROOTS.projects, 'repo1', '.tmp', 'junk.txt'), 'x'.repeat(2048))
writeFileSync(join(ROOTS.projects, 'repo1', 'src', 'keep.txt'), 'important')
writeFileSync(join(CACHE, 'foo', 'junk.bin'), 'y'.repeat(4096))

let failed = 0
const check = (label, condition, extra = '') => {
  const ok = Boolean(condition)
  if (!ok) failed++
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${extra ? ` — ${extra}` : ''}`)
}

// ---- toolchain probe (structure only) ----
const inventory = probeToolchain({ withVersions: false })
check('probe: 7 tools listed', inventory.length === 7)
check('probe: entries shaped', inventory.every(tool => tool.name && 'path' in tool && 'version' in tool))
if (process.platform === 'win32') {
  const versionedInventory = probeToolchain()
  const pnpm = versionedInventory.find(tool => tool.name === 'pnpm')
  const edge = versionedInventory.find(tool => tool.name === 'edge')
  const chrome = versionedInventory.find(tool => tool.name === 'chrome')
  check('probe: Windows .CMD version is readable', !pnpm?.path || typeof pnpm.version === 'string', JSON.stringify({ path: pnpm?.path, version: pnpm?.version }))
  check('probe: Edge version comes from file metadata', !edge?.path || /^\d+(?:\.\d+)+$/.test(edge.version ?? ''))
  check('probe: Chrome version comes from file metadata', !chrome?.path || /^\d+(?:\.\d+)+$/.test(chrome.version ?? ''))
}

// ---- deletion whitelist ----
const tmp = join(ROOTS.projects, 'repo1', '.tmp')
check('cleanable: project .tmp', await isCleanable(tmp, ROOTS))
check('cleanable: inside project .tmp', await isCleanable(join(tmp, 'sub'), ROOTS))
check('NOT cleanable: .. escape', !await isCleanable(join(tmp, '..', 'src'), ROOTS))
check('NOT cleanable: src dir', !await isCleanable(join(ROOTS.projects, 'repo1', 'src'), ROOTS))
check('NOT cleanable: repo root', !await isCleanable(join(ROOTS.projects, 'repo1'), ROOTS))
check('NOT cleanable: projects root', !await isCleanable(ROOTS.projects, ROOTS))
check('cleanable: cache child', await isCleanable(join(CACHE, 'foo'), ROOTS))
check('NOT cleanable: cache root itself', !await isCleanable(CACHE, ROOTS))
check('NOT cleanable: outside everything', !await isCleanable('C:\\Windows\\Temp', ROOTS))
check('NOT cleanable: fake .tmp sibling', !await isCleanable(join(ROOTS.projects, 'repo1', 'src', '.tmp'), ROOTS))

// ---- scan + truncation marker ----
const many = join(CACHE, 'many')
mkdirSync(many, { recursive: true })
for (let i = 0; i < 4010; i++) writeFileSync(join(many, `f${i}`), 'x')
const caches = await scanCaches(ROOTS)
const manyItem = caches.find(item => item.path === many)
check('scan: truncation flagged at 4000+ files', manyItem?.truncated === true, JSON.stringify({ files: manyItem?.files, truncated: manyItem?.truncated }))
const fooItem = caches.find(item => item.path === join(CACHE, 'foo'))
check('scan: small dir not truncated', fooItem?.truncated === false && fooItem.files === 1)
check('scan: mtime present', caches.every(item => typeof item.mtime === 'number'))
check('scan: finds project .tmp', caches.some(item => item.path === tmp))
check('scan: sorted desc', caches.every((item, i) => i === 0 || caches[i - 1].bytes >= item.bytes))

// ---- preview ----
const preview = await previewPath(tmp, ROOTS)
check('preview: ok for cleanable path', preview.ok === true)
check('preview: lists junk.txt', preview.entries?.some(entry => entry.name === 'junk.txt'))
check('preview: sorted dirs first', preview.entries?.[0]?.dir === true || preview.entries?.[0]?.name === 'junk.txt')
const previewDenied = await previewPath(join(ROOTS.projects, 'repo1', 'src'), ROOTS)
check('preview: rejected for non-cleanable path', previewDenied.ok === false)

// ---- cleanup plan: inspect first, then single-use execution ----
const plans = new CleanupPlanStore()
const plan = await plans.create([
  tmp,
  join(CACHE, 'foo'),
  join(ROOTS.projects, 'repo1', 'src'),
  'C:\\Windows\\Temp',
  ...Array.from({ length: 20 }, (_, i) => join(CACHE, 'nope' + i)),
], ROOTS)
check('plan: approves 2 cleanable paths', plan.ok === true && plan.approved.length === 2, JSON.stringify(plan.approved))
check('plan: cap processes max 10 total', plan.approved.length + plan.rejected.length === 10, `${plan.approved.length} approved + ${plan.rejected.length} rejected`)
const outcome = await plans.execute(plan.token, ROOTS)
check('clean: removed 2', outcome.removed.length === 2, JSON.stringify(outcome.removed))
check('clean: keep.txt survives', existsSync(join(ROOTS.projects, 'repo1', 'src', 'keep.txt')))
const replay = await plans.execute(plan.token, ROOTS)
check('plan: token is single-use', replay.ok === false && /unknown|expired|already used/.test(replay.error), replay.error)
let clock = 1000
const expiringPlans = new CleanupPlanStore({ ttlMs: 10, now: () => clock })
const expiringPlan = await expiringPlans.create([many], ROOTS)
clock += 11
const expired = await expiringPlans.execute(expiringPlan.token, ROOTS)
check('plan: token expires', expired.ok === false && /unknown|expired/.test(expired.error), expired.error)
const rootsPlans = new CleanupPlanStore()
const rootsPlan = await rootsPlans.create([many], ROOTS)
const rootsChanged = await rootsPlans.execute(rootsPlan.token, { ...ROOTS, cache: join(SB, 'different-cache') })
check('plan: rejects changed roots', rootsChanged.ok === false && /roots changed/.test(rootsChanged.error), rootsChanged.error)

// ---- rules backup / restore (sandboxed DSH_HOME) ----
const prevHome = process.env.DSH_HOME
process.env.DSH_HOME = FAKE_HOME
try {
  await saveRules('# v1')
  await saveRules('# v2')
  const current = readFileSync(rulesFilePath(), 'utf8')
  const backup = readFileSync(rulesFilePath() + '.bak', 'utf8')
  check('rules: save writes current', current === '# v2')
  check('rules: backup holds previous', backup === '# v1')
  await restoreRules()
  check('rules: restore brings v1 back', readFileSync(rulesFilePath(), 'utf8') === '# v1')
  check('rules: restore keeps v2 as new backup', readFileSync(rulesFilePath() + '.bak', 'utf8') === '# v2')
  try {
    await saveRules(null)
    check('rules: rejects non-string', false)
  } catch {
    check('rules: rejects non-string', true)
  }
} finally {
  process.env.DSH_HOME = prevHome
}

// ---- config load / save (sandboxed DSH_HOME) ----
process.env.DSH_HOME = FAKE_HOME
try {
  const defaults = await loadConfig()
  check('config: defaults on empty file', typeof defaults.projects === 'string' && defaults.projects.length > 0)
  const saved = await saveConfig({ projects: 'Z:\\custom\\repos', cache: 'Z:\\custom\\cache' })
  check('config: save returns values', saved.projects === 'Z:\\custom\\repos' && saved.cache === 'Z:\\custom\\cache')
  const reloaded = await loadConfig()
  check('config: reload from file', reloaded.projects === 'Z:\\custom\\repos')
  check('config: file lives under DSH_HOME', configFilePath().startsWith(FAKE_HOME))
  const partial = await saveConfig({ projects: 'W:\\only' })
  check('config: partial save keeps cache', partial.cache === 'Z:\\custom\\cache')
} finally {
  process.env.DSH_HOME = prevHome
}

rmSync(SB, { recursive: true, force: true })
console.log(`\n${failed === 0 ? 'ALL PASS' : `${failed} FAILURES`}`)
process.exit(failed === 0 ? 0 : 1)
