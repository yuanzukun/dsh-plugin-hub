# dsh-housekeeper（环境管家）— DESIGN

管住 agent 的脏手：工具链台账、两阶段缓存清理、机器规则(AGENTS.md)查看编辑。
全在 DSH Web GUI 设置面板里完成，零运行时依赖，一条命令安装。

## 定位

- 仓库：github.com/guo6x/dsh-housekeeper · 包名 `dsh-housekeeper` · topic dsh-plugin
- 痛点：agent 乱装工具、乱放缓存，用户不知道磁盘上多了什么、怎么删
- 卖点：扫描→台账→勾选→生成清理计划→确认删除；机器规则随手改，实时生效

## 功能（v1）

1. **工具链台账**：探测 node/pnpm/git/gh/ffmpeg/Edge/Chrome 的位置与版本，表格展示
2. **缓存扫描**：扫 `D:\github\<repo>\.tmp\*` 与 `D:\environment\cache\*`，显示大小/修改时间
3. **两阶段清理**：勾选目录 → 生成计划 → 5 分钟内确认；安全边界（见下）
4. **机器规则**：读写 `$DSH_HOME/AGENTS.md`（textarea 编辑 + 保存，实时生效）

## 安全边界（核心）

- 路由仅回环（非 127.0.0.1/::1 一律 403）
- **清理白名单**：只允许删除满足以下全部条件的路径：
  - 位于 `D:\github\<直接子目录>\.tmp\` 之下，或 `D:\environment\cache\` 之下
  - 不越过根（规范化路径 + startsWith 校验，防 `..`）
  - 不命中保护名单（如当前项目自身、用户目录、系统目录）
- 删除用 rm -rf 前先 fs.realpath 确认仍在白名单根内（防符号链接逃逸）
- 计划 token 只保存在内存、5 分钟过期且单次使用；删除前再次校验路径和扫描根
- 规则文件读写只允许 `$DSH_HOME/AGENTS.md` 单文件，路径写死不可参数化
- 规则和配置都通过同目录临时文件 + rename 原子写入

## 架构（照搬 dsh-pilot 验证过的形态）

- 宿主 bundle：`inject: ['webServer', 'tools']`（GUI 与 agent 工具共用安全边界）
- 路由：`/housekeeper/state`、`/housekeeper/clean/plan`、`/housekeeper/clean`、`/housekeeper/rules`（GET/POST）
- 客户端：`settings.plugins.tab`（list 注册，与 plugin-hub 同形态），fetch 同源路由
- 构建：esbuild host ESM + client CJS ModuleLoader 包；`@deepseek-ai/*`、react 全 external

## 避坑清单（上一项目的血）

- [x] inject 声明硬依赖（webServer），不在 apply 里 ctx.get 后静默放弃
- [x] JSON 永不经过 PowerShell（BOM 事故）；版本号用 node 写
- [x] pickPort 类比：目录扫描/清理都要规范化路径防逃逸
- [x] 客户端包 esbuild 会转义非 ASCII（检查时按 \uXXXX 判断）
- [x] 重启纪律：未经用户明确同意不 kill dsh web（见 ~/.dsh/AGENTS.md）

## 产物结构

package.json(dsh.bundle + dsh.client platform:web inject:[]) · cordis.patch.yml(insert id: housekeeper) ·
dsh.plugin.json · build.mjs · src/index.js(host) · src/client/index.jsx · tests/core.mjs · README 双语 · LICENSE MIT

## 下一步

1. 多版本 AGENTS.md 历史与差异预览
2. 优先移入系统回收站/隔离区，进一步提高可恢复性
3. 工具链健康检查（版本过旧、PATH 不一致、命令不可执行）
