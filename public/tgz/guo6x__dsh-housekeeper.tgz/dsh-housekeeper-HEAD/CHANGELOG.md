# Changelog

All notable changes to dsh-housekeeper.

## [0.3.3] - 2026-08-26

### Fixed

- Read Windows `.cmd` tool versions through the native shell so pnpm is detected correctly.
- Read Edge and Chrome executable version metadata instead of localized `--version` session messages, avoiding code-page mojibake in the Web GUI.

## [0.3.2] - 2026-08-25

### Changed

- Make first-run acceptance explicit in both READMEs: install, restart, visible success signal, a non-destructive GUI/chat demo, and recovery steps.

## [0.3.1] - 2026-08-25

### Fixed

- Make GitHub installation the primary documented command while the npm package is unpublished.
- Verify the packed release contents in the standard test command and add a Windows CI workflow for the safety regression suite.

### Changed

- Add a bounded, review-first 60-second walkthrough for the GUI and agent-tool paths.

## [0.3.0] - 2026-08-25

### Changed

- Replaced direct cleanup calls with a two-step flow: `housekeeper_plan` reviews paths and returns an expiring, single-use token; `housekeeper_clean` executes only that token.
- The Web GUI now generates a plan before displaying a confirmation action.
- Re-check cleanup roots and the whitelist immediately before deletion; tokens cannot be replayed.
- Write the rules file and configuration atomically through a neighbouring temporary file and rename.
