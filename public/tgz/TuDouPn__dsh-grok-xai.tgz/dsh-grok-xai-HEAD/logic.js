/**
 * Pure xAI payload parsing and profile-row merging.
 * Host routes import these; tests cover them without a DSH process.
 */

/** Background usage cache. Explicit refresh bypasses it. */
export const OBSERVABILITY_TTL_MS = 5 * 60 * 1000

const THINKING_LEVELS = ['minimal', 'low', 'medium', 'high', 'xhigh', 'max']
const OUTPUT_LIMIT_FIELDS = ['max_completion_tokens', 'max_output_tokens', 'max_tokens']

/**
 * xAI prices are USD cents per 100 million tokens.
 * Dividing by 10_000 yields USD per 1 million tokens:
 * 12_500 cents / 100,000,000 tokens = $1.25 / 1,000,000 tokens.
 */
export const pricePerMillion = (value) => {
  const numeric = Number(value)
  return Number.isFinite(numeric) && numeric >= 0 ? numeric / 10000 : undefined
}

export const tokenNeedsRefresh = (expires, now, skewMs) =>
  !Number.isFinite(Number(expires)) || Number(expires) <= now + skewMs

export const tokenExpiresAt = (now, expiresIn) => {
  const seconds = typeof expiresIn === 'number' && expiresIn > 0 ? expiresIn : 3600
  return now + seconds * 1000 - 5 * 60 * 1000
}

export const isNonReasoningModel = (model) =>
  typeof model?.id === 'string' && model.id.includes('non-reasoning')

export const displayName = (id) => {
  const known = {
    'grok-4.3': 'Grok 4.3',
    'grok-4.5': 'Grok 4.5',
    'grok-4.6': 'Grok 4.6',
    'grok-4.7': 'Grok 4.7',
    'grok-4.20-0309-reasoning': 'Grok 4.20 (Reasoning)',
    'grok-4.20-0309-non-reasoning': 'Grok 4.20 (Non-reasoning)',
    'grok-4.20-multi-agent-0309': 'Grok 4.20 Multi-Agent',
    'grok-build-0.1': 'Grok Build 0.1',
  }
  if (known[id] !== undefined) return known[id]
  let rest = id
  if (rest.startsWith('grok-')) rest = rest.slice(5)
  rest = rest.replace(/-\d{4}(?=-|$)/g, '')
  rest = rest.replace(/-non-reasoning$/, ' (Non-reasoning)')
  rest = rest.replace(/-reasoning$/, ' (Reasoning)')
  rest = rest.replace(/-multi-agent$/, ' Multi-Agent')
  rest = rest.replace(/-/g, ' ')
  rest = rest.replace(/(^|\s)([a-z])/g, (_match, space, letter) => space + letter.toUpperCase())
  return ('Grok ' + rest).trim()
}

export const outputTokenLimit = (source) => {
  if (source === null || typeof source !== 'object') return undefined
  for (const field of OUTPUT_LIMIT_FIELDS) {
    const value = Number(source[field])
    if (Number.isInteger(value) && value > 0) return value
  }
  return undefined
}

export const inputModalities = (payload, fallback) => {
  const raw = payload?.input_modalities
  if (!Array.isArray(raw)) return fallback
  const modalities = raw.filter((value) => value === 'text' || value === 'image')
  return modalities.length > 0 ? modalities : fallback
}

export const parseBilling = (payload) => {
  const config = payload?.config
  if (config === null || typeof config !== 'object') throw new Error('billing payload has no config')
  const current = config.currentPeriod ?? config.current_period ?? {}
  const rawPercent = config.creditUsagePercent ?? config.credit_usage_percent
  let percent = 0
  if (rawPercent !== undefined && rawPercent !== null && Number.isFinite(Number(rawPercent))) {
    percent = Math.round(Math.max(0, Math.min(100, Number(rawPercent))))
  } else {
    const used = config.used !== null && typeof config.used === 'object' ? Number(config.used.val) : undefined
    const limit =
      config.monthlyLimit !== null && typeof config.monthlyLimit === 'object'
        ? Number(config.monthlyLimit.val)
        : undefined
    if (Number.isFinite(used) && Number.isFinite(limit) && limit > 0) {
      percent = Math.round(Math.max(0, Math.min(100, (used / limit) * 100)))
    }
  }
  const products = Array.isArray(config.productUsage)
    ? config.productUsage
        .map((item) => ({
          product: typeof item?.product === 'string' ? item.product : '',
          percent: Number.isFinite(Number(item?.usagePercent)) ? Math.round(Number(item.usagePercent)) : 0,
        }))
        .filter((item) => item.product.length > 0)
    : []
  const periodRaw = typeof current.type === 'string' ? current.type : ''
  const period = periodRaw.endsWith('WEEKLY') ? 'weekly' : periodRaw.endsWith('MONTHLY') ? 'monthly' : 'unknown'
  const resetRaw = current.end ?? config.billingPeriodEnd ?? config.billing_period_end
  let resetAt
  if (typeof resetRaw === 'string') {
    const parsed = Date.parse(resetRaw)
    if (Number.isFinite(parsed)) resetAt = new Date(parsed).toISOString()
  }
  const prepaidRaw = config.prepaidBalance ?? config.prepaid_balance
  const prepaidValue = prepaidRaw !== null && typeof prepaidRaw === 'object' ? Number(prepaidRaw.val) : undefined
  const prepaidBalance = prepaidValue !== undefined && Number.isFinite(prepaidValue) ? prepaidValue / 100 : undefined
  const planRaw = payload.subscription_tier ?? payload.subscriptionTier
  const plan = typeof planRaw === 'string' && planRaw.trim().length > 0 ? planRaw.trim() : 'SuperGrok'
  return { plan, percent, period, resetAt, products, prepaidBalance }
}

export const parseModels = (payload) => {
  const data = Array.isArray(payload?.data) ? payload.data : []
  return data
    .filter((model) => model !== null && typeof model === 'object' && typeof model.id === 'string')
    .filter((model) => Number.isFinite(Number(model.completion_text_token_price)))
    .filter((model) => !/imagine|image|video|embed|tts|whisper/i.test(model.id))
    .map((model) => ({
      id: model.id,
      name: displayName(model.id),
      contextWindow: Number.isFinite(Number(model.context_length)) ? Number(model.context_length) : undefined,
      input: Number(model.prompt_image_token_price) > 0 ? ['text', 'image'] : ['text'],
      pricing: {
        input: pricePerMillion(model.prompt_text_token_price),
        output: pricePerMillion(model.completion_text_token_price),
        cachedInput: pricePerMillion(model.cached_prompt_text_token_price),
        longContextInput: pricePerMillion(model.prompt_text_token_price_long_context),
        longContextOutput: pricePerMillion(model.completion_text_token_price_long_context),
        longContextThreshold: Number.isFinite(Number(model.long_context_threshold))
          ? Number(model.long_context_threshold)
          : undefined,
      },
      createdAt: Number.isFinite(Number(model.created)) ? Number(model.created) : undefined,
      outputLimit: outputTokenLimit(model),
    }))
}

export const parseSettings = (payload) => ({
  plan:
    typeof payload?.subscription_tier_display === 'string' && payload.subscription_tier_display.trim().length > 0
      ? payload.subscription_tier_display.trim()
      : undefined,
  defaultModel: typeof payload?.default_model === 'string' ? payload.default_model : undefined,
  features: {
    imageGeneration: payload?.image_gen_enabled === true,
    videoGeneration: payload?.video_gen_enabled === true,
    webFetch: payload?.web_fetch_enabled === true,
    memory: payload?.memory_enabled === true,
    voice: payload?.voice_mode_enabled === true,
  },
})

/** Fold one `/v1/models/{id}` payload onto a list row. A thrown fetch stays `detailStatus: 'failed'`. */
export const applyModelDetail = (model, payload) => {
  const capabilities = payload?.capabilities
  const efforts = Array.isArray(capabilities?.reasoning_effort)
    ? capabilities.reasoning_effort.filter((value) => typeof value === 'string')
    : []
  const defaultEffort =
    typeof capabilities?.default_reasoning_effort === 'string' ? capabilities.default_reasoning_effort : undefined
  return {
    ...model,
    detailStatus: 'ok',
    efforts,
    defaultEffort,
    input: inputModalities(payload, model.input),
    outputLimit: outputTokenLimit(payload) ?? model.outputLimit,
  }
}

/**
 * Profile `reasoningEfforts` for one model.
 *
 * `false` means non-reasoning. DSH treats that as `reasoning: false`, so it
 * must not be used for "reasons, but do not send an effort". That shape is
 * not representable: an empty map is invalid, and a map must offer a level
 * beyond `off`. Omitting the field keeps a catalog entry's reasoning instead
 * of turning a failed detail read into a non-reasoning model.
 *
 * @returns {false | Record<string, string> | undefined} undefined means omit the field.
 */
export const reasoningEffortsFor = (model) => {
  if (model?.detailStatus !== 'ok') return undefined
  const declared = Array.isArray(model.efforts) ? model.efforts : []
  const efforts = {}
  for (const value of declared) {
    if (value === 'none') efforts.off = 'none'
    else if (THINKING_LEVELS.includes(value)) efforts[value] = value
  }
  if (Object.keys(efforts).some((level) => level !== 'off')) return efforts
  // `none` alone, or an id that says non-reasoning, is the only safe `false`.
  // An empty list on a reasoning model is omitted so DSH does not treat it as
  // non-reasoning and a catalog entry can keep its own capability.
  if (isNonReasoningModel(model) || declared.includes('none')) return false
  return undefined
}

/**
 * Replace the live list without discarding user-owned fields DSH actually stores.
 * `maxTokens` and `compat` survive. A successful detail read owns `reasoningEfforts`;
 * a failed read keeps the previous value instead of writing `false`.
 */
export const mergeModelRows = (liveModels, previousModels) => {
  const previous = new Map(
    (Array.isArray(previousModels) ? previousModels : [])
      .filter((row) => row !== null && typeof row === 'object' && typeof row.id === 'string')
      .map((row) => [row.id, row]),
  )
  return liveModels.map((model) => {
    const prior = previous.get(model.id) ?? {}
    const efforts = reasoningEffortsFor(model)
    const row = {
      id: model.id,
      name: model.name,
    }
    if (Number.isInteger(prior.maxTokens) && prior.maxTokens > 0) row.maxTokens = prior.maxTokens
    if (prior.compat !== null && typeof prior.compat === 'object') row.compat = prior.compat
    if (model.contextWindow !== undefined) row.contextWindow = model.contextWindow
    if (model.input !== undefined) row.input = model.input
    if (model.outputLimit !== undefined) row.maxTokens = model.outputLimit
    if (model.detailStatus === 'failed') {
      if (prior.reasoningEfforts !== undefined) row.reasoningEfforts = prior.reasoningEfforts
    } else if (efforts !== undefined) {
      row.reasoningEfforts = efforts
    }
    return row
  })
}

/** Keep the last complete usage snapshot when a later read is only partial. */
export const withLastGood = (next, lastGood) => {
  if (next?.signedIn === false || lastGood === undefined || lastGood === null) return next
  const billingMissing = next.billing == null
  const modelsMissing = next.models == null
  if (!billingMissing && !modelsMissing) return next
  if (lastGood.billing == null && lastGood.models == null) return next
  return {
    ...next,
    billing: billingMissing ? lastGood.billing : next.billing,
    models: modelsMissing ? lastGood.models : next.models,
    plan: next.plan ?? lastGood.plan,
    defaultModel: next.defaultModel ?? lastGood.defaultModel,
    features: next.features ?? lastGood.features,
    stale: true,
  }
}
