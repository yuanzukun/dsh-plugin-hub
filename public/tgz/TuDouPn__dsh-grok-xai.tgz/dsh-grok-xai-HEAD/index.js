/**
 * Grok (xAI subscription) — Host half.
 *
 * The Harness already ships the hard parts: `dsh-llm-pi-ai` registers pi-ai's
 * xAI catalog provider and a device-code OAuth flow keyed by the
 * `llm-pi-ai/xai` credential record, and the model picker reads the resulting
 * route. What it does not ship is a browser surface that can start that flow,
 * because the generic authorization seam is not exposed over Typert Remote.
 *
 * This half closes that gap with same-origin JSON routes under `/grok-auth/`.
 * The Client half renders a card on Settings → Models and calls them with plain
 * `fetch`. The flow itself, the credential record, and its refresh remain owned
 * by `ctx.authorization`; this plugin never logs or returns a token.
 *
 * Beyond sign-in, the card reports two live observations:
 * - SuperGrok subscription usage from Grok's own billing payload
 *   (`cli-chat-proxy.grok.com/v1/billing?format=credits`), the same figure the
 *   Grok CLI shows.
 * - The model list from `api.x.ai/v1/models`, which can be written into the
 *   `llm-pi-ai` route so the picker follows the provider instead of the
 *   installed pi-ai catalog.
 */

import {
  OBSERVABILITY_TTL_MS,
  applyModelDetail,
  mergeModelRows,
  parseBilling,
  parseModels,
  parseSettings,
  tokenExpiresAt,
  tokenNeedsRefresh,
  withLastGood,
} from './logic.js'

const CREDENTIAL_KEY = 'llm-pi-ai/xai'
const PROVIDER_ID = 'xai'
const PI_AI_ENTRY_ID = 'llm-pi-ai'
const BILLING_URL = 'https://cli-chat-proxy.grok.com/v1/billing?format=credits'
const SETTINGS_URL = 'https://cli-chat-proxy.grok.com/v1/settings'
const MODELS_URL = 'https://api.x.ai/v1/models'
const TOKEN_URL = 'https://auth.x.ai/oauth2/token'
const CLIENT_ID = 'b1a00492-073a-47ea-816f-4c329264a828'
const REFRESH_SKEW_MS = 2 * 60 * 1000

export const inject = ['webServer', 'authorization', 'credentials']

class GrokAuthError extends Error {
  constructor(code, message) {
    super(message ?? code)
    this.name = 'GrokAuthError'
    this.code = code
  }
}

/** @param {any} ctx */
export function apply(ctx) {
  /** @type {undefined | {status: string, notices: any[], error: string | null, providerAddError: string | null, addingProvider: boolean, syncedModels?: number, controller: AbortController}} */
  let attempt
  /** @type {undefined | {at: number, data: any}} */
  let observabilityCache
  /** @type {undefined | any} */
  let lastGoodObservability

  const providerConfigured = () => {
    const editor = ctx.get('configEditor')
    if (editor === undefined) return false
    const entry = editor.entries().find((candidate) => candidate.options.id === PI_AI_ENTRY_ID)
    const providers = entry?.options?.config?.providers
    return providers !== null && typeof providers === 'object' && Object.hasOwn(providers, PROVIDER_ID)
  }

  const providerModelsConfigured = () => {
    const editor = ctx.get('configEditor')
    if (editor === undefined) return false
    const entry = editor.entries().find((candidate) => candidate.options.id === PI_AI_ENTRY_ID)
    const models = entry?.options?.config?.providers?.[PROVIDER_ID]?.models
    return Array.isArray(models) && models.length > 0
  }

  const readOauthPayload = async () => {
    const record = await ctx.credentials.readRecord(CREDENTIAL_KEY)
    if (record === undefined || record.kind !== 'grant') return undefined
    const payload = record.payload
    if (payload === null || typeof payload !== 'object' || payload.type !== 'oauth') return undefined
    return payload
  }

  const oauthPayloadOf = (record) => {
    const payload = record?.kind === 'grant' ? record.payload : undefined
    if (payload === null || typeof payload !== 'object' || payload.type !== 'oauth') return undefined
    return payload
  }

  /**
   * Return a usable access token. The refresh HTTP call runs inside
   * `modifyRecord`, which holds the credential-store lock across the await.
   * A second caller waits, then sees the token the first caller just wrote
   * and does not spend the refresh token again.
   */
  const accessToken = async () => {
    const initial = await readOauthPayload()
    if (initial === undefined) throw new GrokAuthError('SIGN_IN_REQUIRED', 'no xAI OAuth record')
    if (
      typeof initial.access === 'string' &&
      initial.access.length > 0 &&
      !tokenNeedsRefresh(initial.expires, Date.now(), REFRESH_SKEW_MS)
    ) {
      return initial.access
    }
    if (typeof initial.refresh !== 'string' || initial.refresh.length === 0) {
      throw new GrokAuthError('SIGN_IN_REQUIRED', 'no xAI refresh token')
    }
    const saved = await ctx.credentials.modifyRecord(CREDENTIAL_KEY, async (current) => {
      const payload = oauthPayloadOf(current)
      if (payload === undefined) throw new GrokAuthError('SIGN_IN_REQUIRED', 'no xAI OAuth record')
      if (
        typeof payload.access === 'string' &&
        payload.access.length > 0 &&
        !tokenNeedsRefresh(payload.expires, Date.now(), REFRESH_SKEW_MS)
      ) {
        return current
      }
      if (typeof payload.refresh !== 'string' || payload.refresh.length === 0) {
        throw new GrokAuthError('SIGN_IN_REQUIRED', 'no xAI refresh token')
      }
      const body = new URLSearchParams({
        grant_type: 'refresh_token',
        client_id: CLIENT_ID,
        refresh_token: payload.refresh,
      })
      const response = await fetch(TOKEN_URL, {
        method: 'POST',
        headers: { accept: 'application/json', 'content-type': 'application/x-www-form-urlencoded' },
        body,
        signal: AbortSignal.timeout(20_000),
      })
      if (!response.ok) {
        throw new GrokAuthError(
          response.status === 401 || response.status === 403 ? 'SIGN_IN_REQUIRED' : 'TOKEN_REFRESH_FAILED',
          `xAI token refresh HTTP ${response.status}`,
        )
      }
      const fresh = await response.json()
      if (typeof fresh.access_token !== 'string' || fresh.access_token.length === 0) {
        throw new GrokAuthError('TOKEN_REFRESH_FAILED', 'xAI token refresh returned no access token')
      }
      return {
        kind: 'grant',
        payload: {
          type: 'oauth',
          access: fresh.access_token,
          refresh: typeof fresh.refresh_token === 'string' ? fresh.refresh_token : payload.refresh,
          expires: tokenExpiresAt(Date.now(), fresh.expires_in),
        },
      }
    })
    const savedPayload = oauthPayloadOf(saved)
    if (typeof savedPayload?.access === 'string' && savedPayload.access.length > 0) return savedPayload.access
    throw new GrokAuthError('TOKEN_REFRESH_FAILED', 'xAI token refresh did not persist')
  }

  const requestJson = async (url, token, headers = {}) => {
    const response = await fetch(url, {
      headers: {
        authorization: `Bearer ${token}`,
        accept: 'application/json',
        ...headers,
      },
      signal: AbortSignal.timeout(20_000),
    })
    if (!response.ok) {
      if (response.status === 401 || response.status === 403) {
        throw new GrokAuthError('SIGN_IN_REQUIRED', `xAI HTTP ${response.status}`)
      }
      throw new Error(`xAI HTTP ${response.status}`)
    }
    return response.json()
  }

  /**
   * Read one model's declared capabilities. `/v1/models/{id}` is the authority
   * for reasoning efforts and, when xAI sends one, an output-token limit.
   * A failed read stays `detailStatus: 'failed'` so sync keeps the previous
   * reasoning field instead of marking a catalog model non-reasoning.
   */
  const fetchModelDetails = async (token, models) =>
    Promise.all(
      models.map(async (model) => {
        try {
          const payload = await requestJson(`${MODELS_URL}/${encodeURIComponent(model.id)}`, token)
          return applyModelDetail(model, payload)
        } catch (error) {
          ctx.logger.warn('grok-xai: could not read model detail for "%s"', model.id)
          ctx.logger.warn(error)
          return { ...model, detailStatus: 'failed' }
        }
      }),
    )

  const fetchBilling = async (token) =>
    parseBilling(
      await requestJson(BILLING_URL, token, {
        'x-xai-token-auth': 'xai-grok-cli',
        'x-grok-client-mode': 'cli',
        'x-grok-client-version': '1.0.4',
      }),
    )

  const fetchSettings = async (token) =>
    parseSettings(
      await requestJson(SETTINGS_URL, token, {
        'x-xai-token-auth': 'xai-grok-cli',
        'x-grok-client-mode': 'cli',
        'x-grok-client-version': '1.0.4',
      }),
    )

  const fetchModels = async (token) => parseModels(await requestJson(MODELS_URL, token))

  const errorCode = (error) => {
    if (error instanceof GrokAuthError) return error.code
    const message = error instanceof Error ? error.message : String(error)
    if (/HTTP 401|HTTP 403/.test(message)) return 'SIGN_IN_REQUIRED'
    return message
  }

  const configuredModels = () => {
    const editor = ctx.get('configEditor')
    if (editor === undefined) return []
    const entry = editor.entries().find((candidate) => candidate.options.id === PI_AI_ENTRY_ID)
    const models = entry?.options?.config?.providers?.[PROVIDER_ID]?.models
    return Array.isArray(models) ? models : []
  }

  const observability = async (force = false) => {
    if (!force && observabilityCache !== undefined && Date.now() - observabilityCache.at < OBSERVABILITY_TTL_MS) {
      return observabilityCache.data
    }
    let token
    try {
      token = await accessToken()
    } catch (error) {
      lastGoodObservability = undefined
      const data = {
        signedIn: false,
        plan: undefined,
        billing: null,
        models: null,
        features: undefined,
        error: errorCode(error),
        fetchedAt: Date.now(),
      }
      observabilityCache = { at: Date.now(), data }
      return data
    }
    const [billing, models, settings] = await Promise.allSettled([
      fetchBilling(token),
      fetchModels(token),
      fetchSettings(token),
    ])
    const failures = [billing, models].filter((result) => result.status === 'rejected')
    const settingsValue = settings.status === 'fulfilled' ? settings.value : undefined
    const configured = new Map(configuredModels().map((model) => [model.id, model]))
    const llm = ctx.get('llm')
    const liveModels =
      models.status === 'fulfilled'
        ? await Promise.all(
            models.value.map(async (model) => {
              const configuredRow = configured.get(model.id)
              const base = {
                ...model,
                reasoningEfforts: configuredRow?.reasoningEfforts,
                effortControl:
                  configuredRow === undefined
                    ? 'unsynced'
                    : configuredRow.reasoningEfforts === false
                      ? 'none'
                      : configuredRow.reasoningEfforts !== null && typeof configuredRow.reasoningEfforts === 'object'
                        ? 'declared'
                        : 'omitted',
              }
              if (llm === undefined) return base
              try {
                const info = await llm.resolveModelInfo(PROVIDER_ID, model.id)
                return { ...base, resolvedReasoning: info?.reasoning ?? null }
              } catch {
                return { ...base, resolvedReasoning: null }
              }
            }),
          )
        : null
    const billingValue = billing.status === 'fulfilled' ? billing.value : null
    if (billingValue !== null && settingsValue?.plan !== undefined) billingValue.plan = settingsValue.plan
    const data = {
      signedIn: true,
      plan: settingsValue?.plan,
      defaultModel: settingsValue?.defaultModel,
      features: settingsValue?.features,
      billing: billingValue,
      models: liveModels,
      error: failures.length === 0 ? null : errorCode(failures[0].reason),
      fetchedAt: Date.now(),
    }
    if (data.billing != null && data.models != null) lastGoodObservability = data
    const published = withLastGood(data, lastGoodObservability)
    observabilityCache = { at: Date.now(), data: published }
    return published
  }

  /**
   * Replace the live model list without discarding user-owned maxTokens/compat.
   * Unset fields still fall through to the installed catalog entry of the same id.
   */
  const syncModels = async (models) => {
    const editor = ctx.get('configEditor')
    if (editor === undefined) return { changed: false, reason: 'config-editor-unavailable' }
    const entry = editor.entries().find((candidate) => candidate.options.id === PI_AI_ENTRY_ID)
    if (entry === undefined) return { changed: false, reason: 'entry-unavailable' }
    let count = 0
    await editor.edit(entry, (current) => {
      const providers = { ...(current.providers ?? {}) }
      const existing = providers[PROVIDER_ID] ?? {}
      const rows = mergeModelRows(models, existing.models)
      count = rows.length
      providers[PROVIDER_ID] = {
        ...existing,
        displayName: existing.displayName ?? 'xAI (Grok)',
        models: rows,
      }
      return { ...current, providers }
    })
    observabilityCache = undefined
    return { changed: true, reason: 'synced', count }
  }

  const ensureProvider = async () => {
    const editor = ctx.get('configEditor')
    if (editor === undefined) return { changed: false, reason: 'config-editor-unavailable' }
    const entry = editor.entries().find((candidate) => candidate.options.id === PI_AI_ENTRY_ID)
    if (entry === undefined) return { changed: false, reason: 'entry-unavailable' }
    if (providerConfigured()) return { changed: false, reason: 'already-configured' }
    await editor.edit(entry, (current) => {
      const providers = { ...(current.providers ?? {}) }
      providers[PROVIDER_ID] = {
        ...(providers[PROVIDER_ID] ?? {}),
        displayName: providers[PROVIDER_ID]?.displayName ?? 'xAI (Grok)',
      }
      return { ...current, providers }
    })
    observabilityCache = undefined
    return { changed: true, reason: 'added' }
  }

  const snapshot = async () => {
    let configured = false
    try {
      const record = await ctx.credentials.describeRecord(CREDENTIAL_KEY)
      configured = record?.configured === true
    } catch (error) {
      ctx.logger.warn('grok-xai: failed to describe the xAI credential record')
      ctx.logger.warn(error)
    }
    let auth
    try {
      auth = ctx.authorization.describe(CREDENTIAL_KEY)
    } catch (error) {
      ctx.logger.warn('grok-xai: failed to describe the xAI authorization flow')
      ctx.logger.warn(error)
    }
    const current = attempt
    const oauthMethod = auth?.methods?.find((method) => method.id === 'oauth')
    return {
      configured,
      authAvailable: auth !== undefined,
      methodLabel: oauthMethod?.label ?? null,
      inFlight: auth?.inFlight === true,
      status: current?.status ?? 'idle',
      notices: current?.notices ?? [],
      error: current?.error ?? null,
      addingProvider: current?.addingProvider === true,
      syncedModels: current?.syncedModels,
      providerConfigured: providerConfigured(),
      providerModelsConfigured: providerModelsConfigured(),
      canAddProvider: ctx.get('configEditor') !== undefined,
      providerAddError: current?.providerAddError ?? null,
    }
  }

  const startAttempt = () => {
    if (attempt?.status === 'pending') return
    const next = {
      status: 'pending',
      notices: [],
      error: null,
      providerAddError: null,
      addingProvider: false,
      syncedModels: undefined,
      controller: new AbortController(),
    }
    attempt = next
    ctx.authorization
      .begin({
        key: CREDENTIAL_KEY,
        method: 'oauth',
        signal: next.controller.signal,
        interaction: {
          notify(notice) {
            next.notices.push({
              message: typeof notice?.message === 'string' ? notice.message : '',
              ...(typeof notice?.url === 'string' ? { url: notice.url } : {}),
              ...(typeof notice?.code === 'string' ? { code: notice.code } : {}),
            })
            if (next.notices.length > 20) next.notices.splice(0, next.notices.length - 20)
          },
          prompt() {
            return Promise.reject(new Error('The Grok device sign-in does not expect a manual prompt.'))
          },
        },
      })
      .then(async (outcome) => {
        if (outcome.status !== 'authorized') {
          next.status = outcome.status
          return
        }
        next.status = 'authorized'
        observabilityCache = undefined
        next.addingProvider = true
        try {
          const token = await accessToken()
          const models = await fetchModels(token)
          const detailed = await fetchModelDetails(token, models)
          const result = await syncModels(detailed)
          if (result.changed) next.syncedModels = result.count
          else if (result.reason !== 'already-configured') next.providerAddError = result.reason
        } catch (error) {
          next.providerAddError = errorCode(error)
          ctx.logger.warn('grok-xai: signed in but could not sync the live model list')
          ctx.logger.warn(error)
          try {
            const result = await ensureProvider()
            if (result.reason !== 'added' && result.reason !== 'already-configured') {
              next.providerAddError = result.reason
            }
          } catch (addError) {
            next.providerAddError = errorCode(addError)
            ctx.logger.warn('grok-xai: could not add the xAI provider profile')
            ctx.logger.warn(addError)
          }
        } finally {
          next.addingProvider = false
        }
      })
      .catch((error) => {
        next.status = 'failed'
        next.error = error instanceof Error ? error.message : String(error)
      })
  }

  const signOut = async () => {
    try {
      if (attempt?.status === 'pending') ctx.authorization.cancel(CREDENTIAL_KEY)
    } catch (error) {
      ctx.logger.warn('grok-xai: failed to cancel the sign-in before sign-out')
      ctx.logger.warn(error)
    }
    attempt = undefined
    observabilityCache = undefined
    lastGoodObservability = undefined
    try {
      await ctx.credentials.deleteRecord(CREDENTIAL_KEY)
    } catch (error) {
      ctx.logger.warn('grok-xai: failed to delete the xAI credential record')
      ctx.logger.warn(error)
    }
  }

  const originAllowed = (req) => {
    const origin = req.headers.origin
    if (typeof origin !== 'string' || origin.length === 0) return true
    const host = req.headers.host
    if (typeof host !== 'string' || host.length === 0) return false
    try {
      return new URL(origin).host === host
    } catch {
      return false
    }
  }

  const sendJson = (res, status, body) => {
    const payload = JSON.stringify(body)
    res.writeHead(status, {
      'content-type': 'application/json; charset=utf-8',
      'content-length': Buffer.byteLength(payload),
      'cache-control': 'no-store',
    })
    res.end(payload)
  }

  const route = (path, handler) => {
    const wrapped = async (req, res) => {
      try {
        if (!originAllowed(req)) {
          sendJson(res, 403, { ok: false, error: 'forbidden origin' })
          return
        }
        if ((req.method ?? 'GET').toUpperCase() !== handler.method) {
          sendJson(res, 405, { ok: false, error: 'method not allowed' })
          return
        }
        sendJson(res, 200, { ok: true, ...(await handler.run(req)) })
      } catch (error) {
        ctx.logger.warn('grok-xai: request handler failed')
        ctx.logger.warn(error)
        sendJson(res, 500, { ok: false, error: error instanceof Error ? error.message : String(error) })
      }
    }
    return ctx.webServer.register({ kind: 'exact', path, handler: wrapped })
  }

  ctx.effect(() => {
    const disposers = [
      route('/grok-auth/state', { method: 'GET', run: snapshot }),
      route('/grok-auth/sign-in', {
        method: 'POST',
        run: async () => {
          startAttempt()
          return snapshot()
        },
      }),
      route('/grok-auth/cancel', {
        method: 'POST',
        run: async () => {
          try {
            ctx.authorization.cancel(CREDENTIAL_KEY)
          } catch (error) {
            ctx.logger.warn('grok-xai: failed to cancel the xAI sign-in')
            ctx.logger.warn(error)
          }
          return snapshot()
        },
      }),
      route('/grok-auth/sign-out', {
        method: 'POST',
        run: async () => {
          await signOut()
          return snapshot()
        },
      }),
      route('/grok-auth/add-provider', {
        method: 'POST',
        run: async () => {
          let result
          try {
            result = await ensureProvider()
          } catch (error) {
            if (attempt !== undefined) attempt.providerAddError = errorCode(error)
          }
          const value = await snapshot()
          return { ...value, providerResult: result?.reason ?? 'error' }
        },
      }),
      route('/grok-auth/observability', {
        method: 'GET',
        run: async (req) => {
          const url = new URL(req.url ?? '/', 'http://x')
          const data = await observability(url.searchParams.get('refresh') === '1')
          return { ...(await snapshot()), observability: data }
        },
      }),
      route('/grok-auth/sync-models', {
        method: 'POST',
        run: async () => {
          let result
          try {
            const token = await accessToken()
            const models = await fetchModels(token)
            const detailed = await fetchModelDetails(token, models)
            result = await syncModels(detailed)
          } catch (error) {
            result = { changed: false, reason: errorCode(error) }
          }
          const data = await observability(true)
          const value = await snapshot()
          return { ...value, observability: data, syncResult: result }
        },
      }),
    ]
    return () => {
      for (const dispose of disposers) dispose()
      try {
        attempt?.controller.abort()
      } catch {
        /* already settled */
      }
    }
  }, 'grok-xai: host routes')
}
