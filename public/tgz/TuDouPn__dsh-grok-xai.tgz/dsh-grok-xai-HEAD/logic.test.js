import assert from 'node:assert/strict'
import test from 'node:test'
import {
  applyModelDetail,
  mergeModelRows,
  parseBilling,
  parseModels,
  parseSettings,
  pricePerMillion,
  reasoningEffortsFor,
  tokenExpiresAt,
  tokenNeedsRefresh,
  withLastGood,
} from './logic.js'

test('price conversion uses cents per 100 million tokens', () => {
  assert.equal(pricePerMillion(12500), 1.25)
  assert.equal(pricePerMillion(20000), 2)
  assert.equal(pricePerMillion(25000), 2.5)
  assert.equal(pricePerMillion(0), 0)
  assert.equal(pricePerMillion(-1), undefined)
  assert.equal(pricePerMillion('nope'), undefined)
})

test('billing accepts the credits payload and the snake_case fallback', () => {
  const weekly = parseBilling({
    subscription_tier: 'supergrok',
    config: {
      creditUsagePercent: 42.2,
      currentPeriod: { type: 'USAGE_PERIOD_WEEKLY', end: '2026-10-26T00:00:00Z' },
      productUsage: [
        { product: 'GrokChat', usagePercent: 10 },
        { product: '', usagePercent: 99 },
      ],
      prepaidBalance: { val: 250 },
    },
  })
  assert.equal(weekly.percent, 42)
  assert.equal(weekly.period, 'weekly')
  assert.equal(weekly.resetAt, '2026-10-26T00:00:00.000Z')
  assert.equal(weekly.prepaidBalance, 2.5)
  assert.deepEqual(weekly.products, [{ product: 'GrokChat', percent: 10 }])

  const monthly = parseBilling({
    config: {
      used: { val: 25 },
      monthlyLimit: { val: 100 },
      current_period: { type: 'MONTHLY' },
    },
  })
  assert.equal(monthly.percent, 25)
  assert.equal(monthly.period, 'monthly')
  assert.equal(monthly.plan, 'SuperGrok')
})

test('model list keeps priced chat models and drops media models', () => {
  const models = parseModels({
    data: [
      {
        id: 'grok-4.7',
        completion_text_token_price: 60000,
        prompt_text_token_price: 20000,
        cached_prompt_text_token_price: 5000,
        prompt_image_token_price: 20000,
        context_length: 500000,
        long_context_threshold: 200000,
        prompt_text_token_price_long_context: 40000,
        completion_text_token_price_long_context: 120000,
      },
      { id: 'grok-imagine-image', completion_text_token_price: 1 },
      { id: 'grok-no-price' },
    ],
  })
  assert.equal(models.length, 1)
  assert.equal(models[0].name, 'Grok 4.7')
  assert.equal(models[0].pricing.input, 2)
  assert.equal(models[0].pricing.output, 6)
  assert.equal(models[0].pricing.cachedInput, 0.5)
  assert.deepEqual(models[0].input, ['text', 'image'])
})

test('settings display name wins over the billing fallback', () => {
  const settings = parseSettings({
    subscription_tier_display: ' SuperGrok Plus ',
    default_model: 'grok-4.7',
    image_gen_enabled: true,
    voice_mode_enabled: false,
  })
  assert.equal(settings.plan, 'SuperGrok Plus')
  assert.equal(settings.defaultModel, 'grok-4.7')
  assert.equal(settings.features.imageGeneration, true)
  assert.equal(settings.features.voice, false)
  assert.equal(settings.features.memory, false)
})

test('reasoning efforts are written only when xAI declares a sendable level', () => {
  assert.deepEqual(
    reasoningEffortsFor({
      id: 'grok-4.3',
      detailStatus: 'ok',
      efforts: ['none', 'low', 'medium', 'high', 'xhigh'],
    }),
    { off: 'none', low: 'low', medium: 'medium', high: 'high', xhigh: 'xhigh' },
  )
  assert.equal(
    reasoningEffortsFor({ id: 'grok-4.20-0309-non-reasoning', detailStatus: 'ok', efforts: [] }),
    false,
  )
  assert.equal(reasoningEffortsFor({ id: 'grok-4.20-0309-reasoning', detailStatus: 'ok', efforts: [] }), undefined)
  assert.equal(reasoningEffortsFor({ id: 'grok-build-0.1', detailStatus: 'ok', efforts: [] }), undefined)
  assert.equal(reasoningEffortsFor({ id: 'grok-4.7', detailStatus: 'failed' }), undefined)
  assert.equal(
    reasoningEffortsFor({ id: 'grok-4.3', detailStatus: 'ok', efforts: ['none'] }),
    false,
  )
})

test('model sync keeps user maxTokens and does not disable reasoning after a failed detail read', () => {
  const rows = mergeModelRows(
    [
      applyModelDetail(
        { id: 'grok-4.7', name: 'Grok 4.7', contextWindow: 500000, input: ['text'] },
        {
          input_modalities: ['text', 'image'],
          capabilities: { reasoning_effort: ['low', 'high'], default_reasoning_effort: 'high' },
          max_completion_tokens: 64000,
        },
      ),
      { id: 'grok-4.5', name: 'Grok 4.5', detailStatus: 'failed', contextWindow: 500000, input: ['text'] },
      { id: 'grok-4.20-0309-non-reasoning', name: 'Grok 4.20 (Non-reasoning)', detailStatus: 'ok', efforts: [] },
    ],
    [
      { id: 'grok-4.7', maxTokens: 123, compat: { supportsTemperature: false }, reasoningEfforts: false },
      { id: 'grok-4.5', reasoningEfforts: { low: 'low', high: 'high' }, maxTokens: 8000 },
    ],
  )
  assert.equal(rows[0].maxTokens, 64000)
  assert.deepEqual(rows[0].compat, { supportsTemperature: false })
  assert.deepEqual(rows[0].input, ['text', 'image'])
  assert.deepEqual(rows[0].reasoningEfforts, { low: 'low', high: 'high' })
  assert.equal(rows[1].maxTokens, 8000)
  assert.deepEqual(rows[1].reasoningEfforts, { low: 'low', high: 'high' })
  assert.equal(rows[2].reasoningEfforts, false)
  assert.equal(rows[2].maxTokens, undefined)
})

test('a failed usage read keeps the last complete snapshot', () => {
  const last = { signedIn: true, billing: { percent: 10 }, models: [{ id: 'grok-4.7' }], plan: 'SuperGrok Plus' }
  const partial = withLastGood({ signedIn: true, billing: null, models: null, error: 'xAI HTTP 500' }, last)
  assert.equal(partial.stale, true)
  assert.equal(partial.billing.percent, 10)
  assert.equal(partial.models[0].id, 'grok-4.7')
  assert.equal(partial.plan, 'SuperGrok Plus')
  const signedOut = withLastGood({ signedIn: false, billing: null, models: null }, last)
  assert.equal(signedOut.stale, undefined)
  assert.equal(signedOut.billing, null)
})

test('refresh skew treats a missing expiry as due', () => {
  assert.equal(tokenNeedsRefresh(undefined, 1_000, 120_000), true)
  assert.equal(tokenNeedsRefresh(1_000 + 120_001, 1_000, 120_000), false)
  assert.equal(tokenExpiresAt(1_000, 3600), 1_000 + 3600 * 1000 - 5 * 60 * 1000)
  assert.equal(tokenExpiresAt(1_000, 0), 1_000 + 3600 * 1000 - 5 * 60 * 1000)
})
