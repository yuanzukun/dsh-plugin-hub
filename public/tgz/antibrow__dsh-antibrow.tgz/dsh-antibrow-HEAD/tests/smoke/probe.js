// Launches a real browser through the harness tool pipeline and asserts what
// the page reports about itself. `ctx.tools.execute()` is the same path a model
// call takes, minus the model, so this runs without model credentials.
import { CallId } from '@deepseek-ai/dsh-llm'

export const name = 'probe'
export const inject = ['tools']

const PROXY = process.env.ANTIBROW_TEST_PROXY ?? ''
const PROFILE = process.env.ANTIBROW_TEST_PROFILE ?? 'dsh-smoke'

export function apply(ctx) {
  let seq = 0
  const call = async (tool, args) => {
    const result = await ctx.tools.execute({
      callId: CallId(`probe-${++seq}`),
      name: `mcp__antibrow__${tool}`,
      arguments: args,
      signal: new AbortController().signal,
    })
    const text = result.content.map(b => (b.type === 'text' ? b.text : '')).join('')
    console.log(`\n[probe] ${tool} isError=${!!result.isError}\n${text.slice(0, 900)}`)
    if (result.isError) throw new Error(`${tool} failed`)
    return text
  }

  setTimeout(async () => {
    const failures = []
    let sessionId
    try {
      const tools = ctx.tools.schemas().map(s => s.name).filter(n => n.startsWith('mcp__antibrow__'))
      console.log(`[probe] bridged tools: ${tools.length}`)
      if (tools.length !== 16) failures.push(`expected 16 bridged tools, saw ${tools.length}`)

      const launched = await call('launch_browser', {
        profile: PROFILE,
        temporary: true,
        ...(PROXY ? { proxy: PROXY } : {}),
      })
      sessionId = JSON.parse(launched.match(/\{[\s\S]*\}/)[0]).sessionId

      await call('navigate', { sessionId, url: 'https://whoer.net/' })
      await new Promise(r => setTimeout(r, 12000))
      // Anchor on the label: the page header carries unrelated percentages.
      const whoer = JSON.parse(JSON.parse(await call('evaluate', {
        sessionId,
        script: `(() => {
          const m = document.body.innerText.match(/disguise:?\\s*(\\d+)\\s*%/i)
          return JSON.stringify({
            disguise: m ? Number(m[1]) : null,
            ua: navigator.userAgent,
            platform: navigator.platform,
            lang: navigator.language,
            tz: Intl.DateTimeFormat().resolvedOptions().timeZone,
          })
        })()`,
      })))
      if (!(whoer.disguise >= 90)) failures.push(`whoer disguise ${whoer.disguise}%`)
      if (!/Windows/.test(whoer.ua) || whoer.platform !== 'Win32') {
        failures.push(`ua and platform disagree: ${whoer.platform} / ${whoer.ua}`)
      }

      await call('navigate', { sessionId, url: 'https://abrahamjuliot.github.io/creepjs/' })
      await new Promise(r => setTimeout(r, 30000))
      const creep = JSON.parse(JSON.parse(await call('evaluate', {
        sessionId,
        script: `(() => {
          const t = document.body.innerText
          const hints = t.match(/platform hints:?[ \\t]*\\r?\\n[ \\t]*(.+)$/im)?.[1]?.trim() ?? ''
          return JSON.stringify({
            headless: t.match(/(\\d+)%\\s+headless:/i)?.[1] ?? null,
            stealth: t.match(/(\\d+)%\\s+stealth:/i)?.[1] ?? null,
            hints,
          })
        })()`,
      })))
      if (creep.headless !== '0' || creep.stealth !== '0') {
        failures.push(`creepjs headless=${creep.headless}% stealth=${creep.stealth}%`)
      }
      // A CJK or macOS UI font here means the host's own font list leaked.
      if (/YaHei|SimSun|PingFang|Hiragino|Malgun|Meiryo|MS Gothic/i.test(creep.hints)) {
        failures.push(`platform hints leak a host font: ${creep.hints}`)
      }

      await call('close_browser', { sessionId })
      sessionId = undefined
    } catch (err) {
      failures.push(err?.message ?? String(err))
    } finally {
      if (sessionId) await call('close_browser', { sessionId }).catch(() => {})
      if (failures.length) {
        console.error(`\n[probe] FAIL\n  - ${failures.join('\n  - ')}`)
      } else {
        console.log('\n[probe] PASS')
      }
      process.exit(failures.length ? 1 : 0)
    }
  }, 3000)
}
