# Smoke test

Launches a real browser through the harness tool pipeline and checks what the
page reports about itself. No model credentials: it calls `ctx.tools.execute()`
directly, which is the path a model call takes minus the model.

```sh
cd tests/smoke
npm install                                      # brings the harness packages
export ANTI_DETECT_BROWSER_KEY=<key>
export ANTIBROW_TEST_PROXY=<protocol://user:pass@host:port>   # optional
node node_modules/@deepseek-ai/cordis/bin.js
```

Passes when all 16 tools bridge, whoer.net reports 90% or better disguise, the
reported platform agrees with the user agent, creepjs sees neither a headless
nor a stealth signal, and its platform hints carry no font from the host.

Set `ANTIBROW_SDK_CLI=<checkout>/dist/cli.js` to test a working copy of the SDK
instead of the published package.

The browser is real and the proxy is real, so this is slow (about a minute) and
needs an API key with a free concurrency slot.
