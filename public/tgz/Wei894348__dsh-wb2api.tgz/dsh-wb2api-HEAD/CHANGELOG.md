# 变更记录

## 1.7.1（2026-10-31）· 出站请求头对齐官方原生客户端

**把「像官方客户端」从形状对齐到逐头对齐**（基线 = `_ref` 里从 `WorkBuddy.app` 包内
`applyGatewayHeaders` / `buildConversationHeaders` 实读出的头集合）。

- **chat 路径删掉官方从不发的声明**：`Origin` / `Referer`（原生客户端不跨域，一条发往
  `copilot.tencent.com` 却声称来自网页的 POST 是最硬的非客户端特征）、`Accept-Language`、
  `X-Machine-ID` / `X-Session-ID`（派生虚拟设备指纹）、`X-No-Authorization` /
  `X-No-User-Id` / `X-No-Enterprise-Id` / `X-No-Department-Info`（否定族只属于
  `/v2/auth/state` 匿名态）；`Accept` 归位单值 `application/json`。
- **chat 路径补齐归属族**：`X-Agent-Intent: craft`、`X-Agent-Type: main`、
  `X-Private-Data: true`（此前只有 `X-Agent-Purpose`），`X-Product` 由 `WorkBuddy`
  归位官方的 `SaaS`（产品身份由 `X-IDE-*` 声明）；企业与租户头成对出现。
- **补齐 `acp-connection-id`**：官方网关代理在**每个** chat 上都从会话账本取这条，
  缺失即明确的"非客户端"（`channel verification` 失败的命名点）。这里按会话稳定派生
  36 字符带横线 UUID（会话内恒定、会话间互异）。
- **`X-Root-Request-ID` 改条件发**：官方只在会话有根请求（fork / subagent）时才发，
  顶层会话一律不带；改为入站透传有才发（`ChatMeta.RootRequestID`）。
- **trace 三方言共享同一 id**：新增 `traceparent` + `b3` + `X-B3-ParentSpanId`，
  与 `X-B3-TraceId` / `X-B3-SpanId` / `X-Trace-ID` 全部同源（此前只有 B3 半个族）。
- **消息级 ID 改 UUIDv7**（`session.NewMessageID`）：官方生成器发 v7，前 48 bit 是
  毫秒时钟，按到达时间自然有序；随机 v4 形状在后台排出来是乱的。
- **refresh**：`X-Auth-Refresh-Source` 由 `plugin` 改为官方的 `workbuddy`（此前等于在
  refresh 请求里自报"插件"）；控制台端点恢复官方宽松 `Accept`。
- **三条出站路径归一**：Go 主 chat（`ChatHeaders`）、成长任务桌面 chat
  （`DesktopChatWithExpert`）、JS engine（`engine/wb_up`）此前各写一套 UA / 版本 /
  头族，现在共用同一形态与同一版本号 `5.5.6`；UA 产品段两服都回到 `WorkBuddy`
  （`WorkBuddy AI` 只出现在 product.json / 窗口标题 / 目录请求）。
- **回归闸门**：`internal/upstream/headers_official_test.go` 把那张头表变成断言
  （missing / extra / mismatch 三类都红）。
- **网关二进制重建**：`backend/bin/wb2a-server.exe`（新 SHA256 见 `backend/README.md`）。

## 1.7.0（2026-10-26）

**界面重做：仪表盘式设置面板 + 侧栏额度卡片 + 中栏面板**

- **浏览器半侧拆成两层**（`client/client.js` 由 `tools/build_client.mjs` 生成）：
  `client/vendor/ui-runtime.js` 负责界面（React 组件、`wbp-` 样式、槽位注册），
  `client/wbcompat-shim.js` 负责数据 —— 在 `window.fetch` 上认领运行时自己的六个路由，
  转发到宿主 `/dsh-wb2api/*`，accessToken 不进浏览器。
- **六个界面挂载点**：`main#wb2api-panel`（中栏仪表盘）、`sidebar.footer.action#wb2api-panel`
  （侧栏额度卡片）、`settings.section#wb2api`（设置页：账号 / 模型两页签，顶部并入网关与
  成长任务两组行）、`settings.models.provider-card@llm-wb2api`、
  `conversation.composer.dock#workbuddy-credit-badge`、`conversation.input.right#workbuddy-probe`。
- **CN / 国际两个变体**对应账号池的 `realm`：`cn` → WorkBuddy 卡片，`global` → WorkBuddy AI 卡片；
  积分包按套餐名合并，模型按 `cn:` / `global:` 前缀分流。
- **写动作**：启用/停用、删除、刷新积分、测试、扫码登录（begin/poll）、粘贴令牌或整份凭证 JSON、
  桌面端登录态接管，全部落到现有路由；侧栏额度样式与几个显示开关写
  `localStorage('wb2api.ui.prefs')`，下次读文档时回填。
- **签到**：宿主 `/dsh-wb2api/checkin-status` 给出每账号当天结果，界面上以账号行内的
  「今日已签到」胶囊呈现，不再单独成组。
- **验证**：`tools/wbcompat_smoke.mjs`（真宿主数据跑数据层）、`wbcompat_module_smoke.mjs`
  （假加载器加载产物，断言 `name / inject` 与六个注册点）、`wbcompat_render_smoke.mjs`
  （jsdom + 真 React 渲染六个表面）。

## 1.6.0（2026-10-26）

**新增：面板「重启网关」按钮（网关抽风时一键救活）**

- **`POST /dsh-wb2api/restart` + 状态行的「重启网关」按钮**（`lib/gw/restart.js`）。
  三步：graceful `stop()` → 端口不释放时按端口找出监听者、**验明镜像名属于网关**才强杀
  （Windows `netstat` + `tasklist` + `taskkill /T /F`；POSIX `lsof`/`ps`/`SIGKILL`）→
  重新拉起并复检。响应带回 `state / pid / health / killed / steps / tookMs`，面板拼成
  「网关已重启 · 可用账号 5/6 · 清掉 1 个僵死进程 · 用时 2.3 秒」。
- **为什么不是 `supervisor.restart()` 的薄封装**：僵死进程端口还在、`/healthz` 不答，
  重启会被「端口占用」卡成 `failed`；孤儿网关在 supervisor 眼里是 `external`，而
  `stop()` 按约定不杀别人的进程 —— 于是「重启」等于什么都没做。强杀有硬边界：
  只有镜像名在白名单里才动手，端口被 `node.exe` / `nginx` 之类占着一律报错交回人类。
- **握手点 `lib/gw/link.js`**：supervisor 活在子插件 `lib/gw/` 里、路由挂在父插件
  `lib/index.js`，两边用模块级单例接头 —— 路由表仍然只有一份，客户端 API 面不变。
- **修 `/healthz` 503 的误判**（`proc.js` + `lib/index.js` 的 `probeGateway`）：
  网关「活着但没有可用账号」时返回 `503 {healthy:0,total:0,service:"workbuddy2api"}`。
  旧实现把非 2xx 一律当成「端口被别的程序占用」，于是面板显示「网关未运行」、
  `/wb2api-restart` 报失败 —— 修错方向。现按 `service` 字段验明正身，判为
  「已启动 · 可用账号 0」，红点变黄提示，重启按钮也不再误报失败。
- **冒烟**：`tools/wb_restart_smoke.mjs`（一次性端口 + 临时工作目录，22 项：graceful 重启 /
  孤儿强杀 / 非网关进程必须一个都不杀 / HTTP 路由契约），全程不碰现场 7863；
  `tools/wb_client_smoke.mjs` 增加按钮与提示文案的渲染断言。

## 1.5.9（2026-10-21）

**修复：运行时外置 + 模型倍率展示回归**

- **运行时外置**：网关 exe 的真正运行位移到 `~/.dsh/wb2api/bin/`，插件目录里的
  bundled exe 降级为"安装源"。启动前自动哈希比对同步（旧运行副本改名腾位，零停机）。
  插件目录从此无进程锁 —— **修复"DSH 运行中所有插件更新报拒绝访问 / already-installed"**，
  wb2api 自己的更新也不再卡 pnpm。
- **模型下拉倍率与国别标签回归**：1.5.8 基线漏搬 `credits_mult` 字段与 1.5.6 的
  "国内版/国际版 + 倍率"展示名，下拉只剩裸名。已恢复三段式展示并端到端验证（48 模型）。

## 1.5.8（2026-10-16）

**修复：global（国际版）chat 全挂 + 网关二进制更新**

- **global chat 路径回切 `/console`**：上游在 `/v2/chat/completions` 新挂渠道校验，
  stream=true 确定性 403 code 11-128 "request illegal"（非 UA/指纹问题，同指纹打
  `/console` 即过）。`/console` 要求首条消息为 system，`ensureConsoleSystem` 兜底注入
  配套保留。副作用（已知取舍）：`/console` 挂腾讯云 WAF body 内容规则，命令执行类
  内容可能 403——属内容拦截不罚账号，与渠道拦截（会误封号）性质不同。
- **bundled 网关 `wb2a-server.exe` 更新**（agent 版，含上述路径修复）。
- sidecar 桥支持（`lib/gw/proc.js`）：`<运行目录>/sidecars.json` 清单拉起/回收桥进程；
  `runtime/anthropic_bridge.py` 加 NO_PROXY 回环豁免与 reasoning_effort 默认 low。
- README：安装方式恢复 dshmarket 市场入口。

## 1.5.7（2026-10-10）

**新增：EMPTY_RESPONSE 计数观测**

上游偶发「只吐思考就 `stop`」（无正文、无工具调用）时，插件照旧抛可重试的
`EMPTY_RESPONSE`（行为不变），同时往 `~/.dsh/wb2api/data/empty-response-stats.json`
追加一条元数据：时间 / 版本 / 模型 / finish_reason / 思考长度。不记任何正文，
封顶 50 条。用于判断这是偶发抖动还是某模型的高频病。

## 1.5.6（2026-10-10）

**新增：出站请求探针（定位「网关照常 200、模型却不认人格」这类静默故障）**

每次调用把请求骨架写到 `~/.dsh/wb2api/data/inflight.json`（辅助调用写
`inflight-<purpose>.json`），内容只有 `role` 序列、每条的消息类型/字符数/前 100 字，
以及入参里的 `system` 字段类型与长度、`tools` 条数、自报版本号 —— 不含完整正文。

判读方式：**入参 `messages[0].role === 'system'` 且字符数量级对得上人格长度**，
说明人格进到了适配器；再看 `outbound.messages` 的同名条目是否还在。两边对不上，
故障点就在「dsh → 适配器」之间，而不是模型或提示词。

默认开启，`WB2API_DUMP=0` 关闭；`WB2API_DUMP_DIR` 可改落盘目录。

同时修正探针自报版本号读错了相对路径（`lib/package.json` → 包根 `package.json`），
之前恒为 `unknown`。

## 1.5.5（2026-10-10）

**修复：带 `cn:` 前缀的模型名查不到目录 → 被判「不支持 reasoningEffort」→ 整轮请求被换模型**

1.5.4 改成 `strip-cn` 展示后引入一个回归，且只在「调用方传带前缀名字」时发作：
`ModelCatalog.find()` 只按展示 id 建索引，而 profile patch、手填配置、老配置片段里完全
可能写 `cn:deepseek-v4.1-flash`。查不到时 `GatewayChat.resolveModel()` 会返回一个
**不带 `reasoning` 字段**的兜底对象，`dsh-llm` 的 `resolveCallWithInfo()` 随即认定
「该模型不支持 reasoningEffort」并抛 `UNSUPPORTED_REASONING_EFFORT`，DSH 把整轮请求
换到别的模型 —— 表象是「系统提示 / 人格层莫名失效」，实际是模型被换掉了。

| 位置 | 改法 |
|---|---|
| `lib/gw/catalog.js` | `_load()` 新增 `byRealmBare`（`realm:bareId` 精确索引） |
| `lib/gw/catalog.js` | `find()` 首查未命中时按 realm 归一化再查一次：`cn:deepseek-v4.1-flash` → 同 realm 的 `deepseek-v4.1-flash`。按 realm 精确匹配，避免同名跨域时 `cn:xxx` 被 `global:xxx` 抢先 |
| `tools/wb_catalog_smoke.mjs` | 新增三条断言：带前缀入参命中 / 命中后可还原 wire id / 同名跨域不串味 + 未知名仍返回 `undefined` |

只影响「名字带前缀」的查询；裸名（展示名）路径与 `toWireModel()` 出方向不变。

### 同时修复：system 提示词被整段丢弃（人格不生效）

`serializeMessages()` 把 `role:'system'` 的历史消息按「system 由 `buildRequestBody` 统一
unshift」`continue` 掉了，而 `options.system` 通常是空的 —— 于是 dsh 渲染好的人格 / 指令
提示词（`createSystemMessage()` 放进 `role:'system'` 消息的那份）**根本没进请求**。
网关照常 200 回包，只是模型完全不认人格，最容易误判成"模型不行"或"提示词没写好"。

官方 adapter 的语义是「历史里的 system + options.system」两处合并，所以这里必须保留。

| 位置 | 改法 |
|---|---|
| `lib/gw/chat.js` | `serializeMessages()` 保留 `role:'system'` 消息（原位置、原文本） |
| `lib/gw/chat.js` | `buildRequestBody()` 的 `options.system` 做内容去重，避免与历史里的同段落重复发送 |
| `tools/wb_request_smoke.mjs` | 新增：7 条断言专盯 system 是否进请求 / 两处来源并存 / 去重 / 只有一处时不丢 / 裸名还原 wire id |

### 配套（本地重装链路）

| 位置 | 改法 |
|---|---|
| `sync.ps1` | v2：现场路径由已废弃的 `~/.dsh/plugins/<pkg>` 改为 `~/.dsh/profiles/<p>/node_modules/<pkg>`（覆盖 desktop / web / wbtest）；插件本体不再逐文件登记，改为按 `files` 白名单全量同步（补上旧版漏掉的 `lib/gw/*`）；排除运行时 `data/`；输出改 `Write-Output` 以便落盘 |
| `tools/reinstall_local.mjs` | 新增：从 tgz 解包产物逐文件覆盖现场 profile（hash 比对，保留运行时 `data/`），用于本地重装；用法 `node tools/reinstall_local.mjs <解包目录>` |
| 三个 profile 的 `package.json` | 依赖由 `github:Wei894348/dsh-wb2api`（会拉回未含修复的远端 HEAD）改为 `file:.../dsh-plugin-wb2api-ui-1.5.5.tgz`，避免重装即回退 |

## 1.5.4（2026-10-10）

**模型下拉去掉 `cn:` 前缀（展示剥离，出方向自动还原）**

模型选择器里每条都是 `cn:glm-5.0-turbo` / `cn:kimi-k2.7`，区域前缀把真正的模型名挤窄。
`ModelCatalog` 本来就带 `policy` 开关（`lib/gw/catalog.js` 里写好但没接线），这次接上
`strip-cn`，并补上出方向的还原。

| 位置 | 改法 |
|---|---|
| `lib/gw/index.js` | `new ModelCatalog({...})` 补 `policy: 'strip-cn'` |
| `lib/gw/chat.js` | `buildRequestBody` 新增 `modelEntry` 入参；发请求前用 `toWireModel()` 把展示裸名还原成 `cn:xxx`，目录查不到时原样透传 |
| `tools/wb_catalog_smoke.mjs` | 新增三条断言：strip-cn 剥前缀 / `global:` 保留 / `toWireModel` 还原 wire id |

为什么必须还原：网关的跨域粘性会话按完整 id 记账，裸名会被钉回 CN 集合，global 模型
会走错出口。剥前缀只影响 dsh 侧的展示。

## 1.5.3（2026-10-10）

**修复：模型目录一律 401（`WorkBuddy (workbuddy2api 网关) 加载失败：GET /v1/models 失败：HTTP 401`）**

根因：`ModelCatalog` 把 `options.apiKey` 当字符串直接拼进请求头，而 `lib/gw/index.js`
传进去的是**函数** `() => resolveApiKey(ctx, config)`（密钥要走凭据库，只能延迟解析）。
函数是 truthy，于是发出去的头成了 `Bearer () => resolveApiKey(ctx, config)` ——
网关按「密钥不对」回 401，而错误消息里只看得到 401，看不出密钥是谁。

| 位置 | 改法 |
|---|---|
| `lib/gw/catalog.js` | 新增 `_resolveApiKey()`：`apiKey` 支持字符串**或**函数（异步也行），请求前 `await` 出字符串；函数抛错/返回非字符串一律降级为「不带密钥」，不炸穿目录加载 |
| `lib/gw/catalog.js` | 构造函数 `options.apiKey \|\| ''` → `?? ''`（显式区分「没传」与「空串」），并补 JSDoc 说明两种形态 |
| `tools/wb_catalog_smoke.mjs` | 新增回归冒烟：函数形 / Promise 形 / 字符串形 / 空值 / 抛错 / 非字符串 六种入参，逐条断言**实际发出去的 `authorization` 头**；`--live` 可追加打一次真网关（只读 `/v1/models`） |

只影响模型目录拉取；chat 链路（`GatewayChat.requireApiKey()` 本来就 `await` 了）一直是好的。

## 1.5.2（2026-10-10）

**README 补「桌面端添加插件」安装方式**

| 位置 | 改法 |
|---|---|
| README / README.en「安装」 | 新增**方式一：桌面端 UI「添加插件」**（设置 → 插件 → 添加插件），压过原插件市场成为首选装法 |
| 同上 | 列出对话框接受的四种输入：GitHub 仓库地址 / `github:` 简写 / 本地目录绝对路径 / 压缩包路径，并标注 npm 包名一行当前不可用（本包未发 npm） |
| 同上 | 说明「安装源」下拉（默认安装源 / npm 官方源 / 中国大陆镜像源 / 自定义地址）只对 npm 输入生效，取不到包会自动切源重试 |
| 同上 | 补充安装脚本授权提示（pnpm 默认不跑）、「安装并重启」收尾，以及它是 `desktop` profile 的唯一装法 |
| README「卸载」 | 补桌面端 UI 卸载路径 |
| 装法编号 | 一~五：桌面 UI / 插件市场 / GitHub 直装 / 压缩包 / link |

## 1.5.1（2026-10-10）

**安装 / 卸载说明补全，仓库接入社区插件目录**

| 位置 | 改法 |
|---|---|
| README「安装」 | 拆成四种装法：插件市场（DSH Plugin Hub / dshmarket）、GitHub 直装、压缩包、link 开发态 |
| 同上 | 标注 `desktop`（Electron 独占）profile 不能用命令行装，只能走桌面端市场 UI |
| README 新增「卸载」 | `dsh plugin remove` 一条命令，并说明运行目录 `%USERPROFILE%\.dsh\wb2api\` 不归 `remove` 管 |
| 仓库元数据 | 加 `dsh-plugin` 等 topic 与 description —— `dsh-plugin` topic 是社区插件目录自动收录的入口 |

## 1.5.0（2026-10-10）

**对齐插件市场惯例：README 与代码布局重排**

参照社区插件（`dshmarket` 等）的 README 与目录组织，把对外观感与文件布局统一到市场常见形态。功能与对外契约不变。

**README**

| 位置 | 改法 |
|---|---|
| 头部 | 居中 logo + 包名标题 + `[English](…) \| 中文` 语言切换 + npm/license/node 徽章 + 一句话简介 + 面板截图 |
| 功能章 | 「能力总览」表格 → 「你会得到」加粗列表（市场常见写法），每条一句话说清用户拿到什么 |
| 新增章 | 「安全」——凭证不出本机 / 密钥不入仓库 / 二进制校验 / 补丁可读 / 单飞锁 |
| 目录结构 | 按新布局重画（`client/`、`locale/`、`assets/`、ASCII 化的 docs 文件名） |

`README.en.md` 同结构同章节；其 `lib/gw/` 清单修正为 13 个新模块（旧版列的还是 1.4.0 时期的 12 个文件名）。

**代码布局**

| 旧 | 新 | 说明 |
|---|---|---|
| `client.js`（仓库根） | `client/client.js` | 与市场插件一致，浏览器半侧收进 `client/`；`exports["./client"]`、`files`、`sync.ps1`、冒烟脚本默认路径同步 |
| `docs/插件面板说明.md` | `docs/PANEL.md` | 非 ASCII 文件名 → ASCII |
| `docs/逻辑总览.md` | `docs/ARCHITECTURE.md` | 同上 |
| — | `locale/{zh,en}.json` | 面板元信息（title / description），新增 `exports["./locale/*.json"]` |
| — | `assets/{logo.svg,demo.svg}` | README 用图，随包发布 |

`package.json` 随之更新：`exports["./client"]` → `./client/client.js`、新增 `./locale/*.json`、`files` 换成 `client` / `locale` / `assets`。装法不变，`dsh plugin add` 照旧。

## 1.4.4（2026-10-10）

**实测修复：网关托管此前根本没被挂载**

在真实 profile 里跑起来才暴露——面板正常、网关却始终不起。逐层定位到四个问题：

| 问题 | 现象 | 修法 |
|---|---|---|
| `@deepseek-ai/schemastery` 用了具名导入 | `SyntaxError: does not provide an export named 'Schema'` → 整个 `lib/gw/` 子插件挂载失败，面板照常、网关静默缺失 | 改回默认导入 `import Schema from ...` |
| `ctx.effect` 回调直接执行 dispose | `start()` 恒返回 `stopped`：网关刚建好就被标记销毁 | 改成返回清理函数 `ctx.effect(() => () => {…})` |
| 二进制定位漏了包内目录 | 装完插件却报「找不到网关程序」，逼用户去下载 | 新增 `bundledBinaryDir()`（按 `import.meta.url` 推导 `backend/bin`），排在下载缓存之前 |
| 启动失败无迹可循 | 找不到二进制时静默 `return`，日志空白 | 补 warn 日志 + `WB2API_DEBUG_LOG=1` 时把关键节点落盘到 `<运行目录>/data/gw-debug.log` |

顺带把 `backend/bin/wb2a-server.exe` 内嵌的 Go 包路径统一改为本仓库自己的命名（813 处等长字节替换，长度不变，改后起停与端到端请求均已复测）。

## 1.4.1（2026-10-09）

**后端逻辑重写（`lib/gw/` 全部换掉）**

按 1.4.0 的行为契约重新实现了一遍，模块划分与命名全部重来，不再沿用先前的文件组织：

| 新模块 | 职责 |
|---|---|
| `settings.js` | 配置归一化与默认值、provider settings namespace |
| `runtime.js` | 路径口径统一：运行目录 / 子进程 cwd / 凭证目录 / 网关 config 生成 |
| `proc.js` | 子进程托管：定位可执行文件 → 探活 → spawn → 崩溃指数退避重启 → 回收 |
| `chat.js` | LlmAdapter：消息序列化 + 发流 + SSE → StreamChunk |
| `stream.js` | SSE 帧解析与双超时（首帧 / 帧间） |
| `catalog.js` | `/v1/models` → dsh 模型目录（TTL 缓存、并发去重、失败保旧） |
| `binary.js` / `archive.js` | 二进制下载 + SHA256 校验 + 原子落盘；自带 ZIP 解压 |
| `credentials.js` | 账号开关（改 `auths/` 文件名后缀）与选择语法 |
| `authorize.js` | Node 版 OAuth 登录与凭证落盘 |
| `bootstrap.js` / `render.js` | `/wb2api-setup` 编排；状态与报告的纯函数渲染 |

对外契约不变：子插件名 `wb2api-gateway`、`inject` 三项、六条 `/wb2api-*` 命令、
LLM provider id 仍是 `workbuddy2api`。行为上保留的既有判据：启动前先探活复用外部网关、
工具结果展开为独立 `tool` 消息并丢弃孤儿、残缺工具参数判 `max-tokens` 而非 `tool-calls`、
只吐思考的空步判 `EMPTY_RESPONSE`、缓存命中 token 不计入 inputTokens、账号池空时显示
「账号池为空」而非「可用 0/0」。

## 1.4.0（2026-10-09）

**内置网关托管与模型 provider 注册（一体化）**

- 新增 `lib/gw/`（12 个 .js）：网关托管 + provider 注册实现 —— 定位可执行文件、探活、
  拉子进程、崩溃重启、随 dsh 退出回收，并把网关的模型目录注册成 dsh 的 LLM provider。
  - `proc.js` 子进程托管（定位可执行文件 → `/healthz` 探活 → spawn → 崩溃重启 → dispose 回收）
  - `chat.js` LlmAdapter（请求组装 + SSE → StreamChunk）、`catalog.js` 模型目录映射
  - `binary.js` 二进制下载 + SHA256 校验 + 运行目录准备、`credentials.js` 账号开关
  - `authorize.js` Node 版 OAuth 登录、`bootstrap.js` `/wb2api-setup` 编排、`stream.js` / `zip.js` / `settings.js` / `index.js`
- `lib/index.js` 把这份实现作为**子插件**挂载（`ctx.plugin(gatewayPlugin, config?.gateway ?? {})`），
  以下命令改由**本插件**注册：`/wb2api-setup`、`/wb2api-status`、`/wb2api-start`、
  `/wb2api-restart`、`/wb2api-login`、`/wb2api-account`。
- 子插件身份名改为 `wb2api-gateway`（`lib/gw/index.js` 的 `export const name`），
  但 **LLM provider 的 id 仍是 `workbuddy2api`**（`PROVIDER` 常量故意没改）——
  dsh 的 `agent-default-model.provider` 等设置引用它，改名会打断现有模型配置。

**内置网关二进制**

- 新增 `backend/bin/wb2a-server.exe`（Windows amd64，随包发布，
  SHA256 `505FA9747B64DD6C4C30CC966CE9A831811A18992510154C22072B454CFA4F74`），
  以及 `backend/build-gateway.ps1`（从网关 Go 源码 clone + `go build` 重建）与
  `backend/README.md`（校验值、重建方法）。
- `resolveBinary()` 候选目录新增**包内 `backend/bin/`**（`new URL('../../backend/bin', import.meta.url)` 解析），
  优先级高于 `~/.dsh/wb2api/bin`，所以 `npm pack` 出去装到哪都能找到自带二进制。
- 自动下载时的 Release 仓库指向本仓库：`lib/gw/binary.js` 的 `DEFAULT_RELEASE_REPO` 与
  `lib/gw/settings.js` 的 `binaryReleaseRepo` 都是 `Wei894348/dsh-wb2api`（自带二进制之后，下载只是兜底）。

**共存要求**

- 同一个 dsh profile 里**不能同时**挂两个注册同一 provider id（`workbuddy2api`）的插件 ——
  会撞成 `DUPLICATE_ADAPTER`，宿主起不来。移除其中一个后重启 dsh。

**打包**

- `package.json`：version `1.3.0` → `1.4.0`；`files` 增加 `"backend"`；
  新增 `peerDependencies`（`@deepseek-ai/cordis`、`@deepseek-ai/dsh-commands`、
  `@deepseek-ai/dsh-llm`、`@deepseek-ai/dsh-subprocess`、`@deepseek-ai/schemastery`，按 dsh 插件契约声明）；
  description 改为「一体化」（自托管网关 + 面板 + 任务引擎）。

## 1.3.0

**新增：成长任务自动化（18 个任务动作）接入面板**

- 面板账号区新增主色按钮「一键做任务」：点击后宿主后台 **确认待办 → 执行动作 → 达标自动领奖**，
  卡片内实时显示待办确认结果、执行日志尾巴与领奖汇总。
- 新增宿主路由：`GET /dsh-wb2api/tasks/status`、`POST /dsh-wb2api/tasks/run`。
- 包内自带任务引擎（`engine/`）：
  - `engine/wb_up/core.mjs` 三类客户端指纹（billing / desktop / web）与信封解析、连接重试
  - `engine/wb_up/events.mjs` 桌面事件链、web 上报、专家市场、真实 chat（SSE 取服务端 requestId）
  - `engine/wb_up/tasks.mjs` 任务清单 / 接受 / 领奖（含小程序口径 MP 变体）、夜猫子、连登
  - `engine/wb_up/actions.mjs` 18 个任务动作
  - `engine/wb_up/run.mjs` 编排层：扫描 → 账号内串行 / 账号间并发 → 两轮 → 自动领奖 + 单飞锁
  - `engine/wb_tasks.mjs` CLI：`list` / `scan` / `auto` / `credits`
- 引擎路径解析顺序：`WB_TASKS_ENGINE` → 包内 `engine/wb_up/run.mjs` → 开发机工作区路径（兼容旧装法）。

**打包**

- 仓库根即 npm 包根（`lib/` + `client.js` + `engine/` + `cordis.patch.yml`），可直接
  `dsh plugin --profile web add <tarball|目录>` 安装，无需构建步骤。

## 1.2.4

- 面板：网关状态 / 每账号剩余积分（可展开包明细）/ OAuth 授权登录 / 凭证导入 / 账号启停与删除。
- 宿主半侧：`/dsh-wb2api/*` 15 条路由；凭证只在本进程内流转，浏览器拿不到 token。
