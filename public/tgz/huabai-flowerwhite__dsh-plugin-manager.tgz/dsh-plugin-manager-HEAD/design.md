# dsh plugin manager — 第三方插件管理器 设计文档

> 本文档遵循 `dsh-plugin-design` 的工程化工作流：**分析先于修改、设计先于执行、可验证、可回滚**。
> 依据规范：`DeepSeek-Harness-Third-Party-Plugin-SDK-Specification.md`（DH-TP-SDK 1.2.1，对齐 Harness `0.2.1-rc.2`，§48 官方契约）、`deepseek-harness-product-technical-framework.md`。

## 1. 目标

在 DeepSeek Harness（dsh）Web UI 中增加一个**功能选项**（设置页入口），实现：

1. 点击后用户选择**第三方插件库文件夹**（工作区）。
2. 搜索该文件夹中**所有第三方插件**（识别 `dsh.plugin.yaml` / `package.json` / `cordis.patch.yml`）。
3. 对每个插件提供**关闭 / 启动**开关：启动 = 挂载并启用（`cordis.patch.yml` insert row 且不带 `disabled`）；关闭 = 禁用（该 row 加 `disabled: true`）。
4. 该功能本身作为**独立的第三方插件**交付：npm 包形态 + host composition 挂载，**重启 dsh 后默认启动**（无需每次手动加载）。

## 2. 需求分解

| # | 用户需求 | 本插件对应能力 |
|---|---|---|
| R1 | UI 增加一个功能选项 | Client 半体注册 `settings.section`（「第三方插件」设置页） |
| R2 | 点击后选择工作区（第三方插件库文件夹） | 设置页「选择文件夹」→ 调 `ctx.workspaces.pickDirectory()`（官方目录选择器），并支持手动输入路径 |
| R3 | 搜索该文件夹中所有第三方插件 | Host 半体 `scan` 路由：递归扫描、识别插件项目、跳过 node_modules/.git/dist 与 DSH 自身 |
| R4 | 选择关闭/启动第三方插件 | Host 半体 `toggle` 路由：修改 `$DSH_HOME/profiles/web/cordis.patch.yml`（insert row / `disabled: true`），并显示当前启用状态 |
| R5 | 启动 dsh 后默认启动 | 本插件挂到 host composition（`cordis.patch.yml` insert row），重启后自动加载 |

## 3. 用户流程

```text
启动 dsh（本插件自动加载）
   ↓
设置 → 「第三方插件」页面
   ↓
点击「选择插件库文件夹」→ 目录选择器选文件夹（或粘贴路径）
   ↓
点击「扫描」→ 列出该文件夹下所有第三方插件（名称 / 路径 / 状态）
   ↓
每个插件一行：状态徽标（已启用 / 已禁用 / 未挂载）+ 「启动 / 关闭」按钮
   ↓
点击后写入 cordis.patch.yml → 提示「重启 dsh 后生效」
```

## 4. 架构

```text
dsh-plugin-manager/                    # npm 包（name: dsh-plugin-manager）
├── package.json                       # exports["."]=host 入口, exports["./client"]=bundle, exports["./package.json"]
├── dsh.plugin.yaml                    # DH-TP-SDK manifest
├── cordis.patch.yml                   # 挂载参考（host composition insert row）
├── README.md
├── design.md                          # 本文档
├── lib/client.js                      # Client 半体：factory-form bundle（设置页）
└── src/
    ├── index.js                       # 入口 → host.js
    └── host.js                        # Host 半体：webServer 路由（scan / toggle / status / mounted）
```

挂载方式（与 dsh-plugin-design 相同）：

```text
E:\creat\DSH\open\dsh-plugin-manager   # 源码（open 工作区）
        │ junction
        ▼
$DSH_HOME/profiles/node_modules/dsh-plugin-manager
        │ 在 profiles/web/cordis.patch.yml 加 insert row
        ▼
重启 dsh → Host 半体（webServer 路由）+ Client 半体（设置页）全局加载
```

关键架构结论（来自 dsh-plugin-design 落地验证 + 本次重启实测修正）：

- **Host 半体**：ESM 模块，`export default { inject: [...], apply(ctx) {...} }`；运行在真实 Node 进程，可访问 `ctx.webServer`（inject）、`ctx.get('loader')`、`process.env.DSH_HOME`。
- **⚠️ `ctx.get('fs')` 在 host composition 全局 context 不可用**（实测修正）：`fs` 是 per-agent 服务（`SandboxedFileSystem` 注入 `sandboxPolicy` 且带 isolate realm 过滤），挂在 host composition 的插件 `ctx.get('fs')` 返回 undefined —— 这正是 dsh-plugin-design 的 Host 半体挂 host composition 后 `dshpd_*` 工具从未注册成功的根因。**Host 半体改用 `node:fs`（`import { readFileSync, writeFileSync, readdirSync } from 'node:fs'`）直接访问文件系统**（官方 `dsh-fs-local` 同样 `import 'node:fs'`）。
- **⚠️ `webServer` 必须用 `inject: ['webServer']` 硬依赖 + `ctx.webServer` 访问**（实测修正）：`webServer` 由 `webserver` entry 异步依赖驱动（`inject: [webStartup]` → `cmdlineArgs`），用 `ctx.get('webServer')` 会在 apply 时拿到 undefined（apply 先于 webServer 提供执行）。官方 `dsh-client-modules` 同样是 `static inject = ["webServer", "loader"]`。
- **Client 半体**：**必须 host composition**（`dsh-client-modules` 只扫描 host Loader entries，浏览器 boot 时按 `window.__DSH_BOOT__` 加载全局 UI），用 factory-form bundle（`window.__ModuleLoader__.load({ id, factory })`），`factory(require)` 内 `require('react')`，`exports.apply` / `exports.inject`，样式用内联 style（无 `styles` service）。
- **Client→Host 通信**：Client 用 `fetch('/dsh-plugin-manager/...')` 调 Host 的 `webServer.register` 路由（与 dsh-plugin-design 相同，不用动态插件的 `host.call`）。
- **Client 服务作用域**：`ctx.get('workspaces')`（目录选择器）须在 `apply(ctx)` 内获取并作为 props 传给 Panel 组件；不能在 Panel 内直接引用 `ctx`（Panel 闭包中无 `ctx`）。

## 5. Host 半体设计（src/host.js）

### 5.1 服务依赖

- `node:fs`（`readFileSync` / `writeFileSync` / `readdirSync`）：文件系统（扫描、读写 cordis.patch.yml）。**不用 `ctx.get('fs')`**（host 平面不可用）。
- `inject: ['webServer']` + `ctx.webServer`：注册 HTTP 路由（硬依赖，等 webServer 提供后 apply）。
- `ctx.get('loader')`：读取已挂载插件（`mounted`/`enabled` 状态）；不可用时回退为空。
- `process.env.DSH_HOME`：定位 profiles 目录（回退：在 `$DSH_HOME/profiles` 下查找含本插件 id 的 `cordis.patch.yml`）。

### 5.2 路由

| 路由 | 方法 | 入参 | 返回 |
|---|---|---|---|
| `/dsh-plugin-manager/scan` | POST | `{ root }` | `{ root, count, plugins: [{ path, name, hasManifest, hasPackageJson, hasCordisPatch, mounted, enabled, inComposition, disabledInPatch }] }` |
| `/dsh-plugin-manager/toggle` | POST | `{ pluginPath, enable }` | `{ ok, pluginPath, enabled, patchPath, note }` |
| `/dsh-plugin-manager/status` | GET | — | `{ patchPath, rows: [{ id, name, disabled }], ok }` |

### 5.3 扫描算法（复用 dsh-plugin-design 的 discover 启发式）

```text
walk(root, depth):
  listDir(target)
  跳过 SKIP_DIRS: node_modules/.git/dist/build/coverage/out/.dsh-plugin-design/.next/.turbo/target
  识别: dsh.plugin.yaml 或 package.json（排除 DSH 自身 npx 安装目录）→ 记为插件项目
  递归子目录（默认 maxDepth=5）
```

对每个插件项目计算：

- `mounted`：`ctx.get('loader').entries()` 中存在 `entry.options.name === 插件包名`（已挂载到当前进程）。
- `enabled`：`!entry.disabled`（Loader 原生 disabled 标记，含禁用祖先组）。
- `inComposition`：`cordis.patch.yml` 文本中含 `- id: <name>` 或 `name: '<name>'`。
- `disabledInPatch`：该 row 后紧跟 `disabled: true`。

> 说明：`loader` 是 host 平面服务（官方 `dsh-host-plugin-inventory` 同样 `inject: ['loader']` 读取），在 host composition 可用。

### 5.4 启停算法（toggle）

目标文件：`$DSH_HOME/profiles/web/cordis.patch.yml`（实际运行时用 `findPatchPath()` 定位含本插件 id 的 patch 文件）。

```text
关闭（enable=false）:
  若 row 已存在且无 disabled 标记 → 在该 row 下追加 "  disabled: true"
  若 row 不存在 → 追加 insert 块（同时提示需插件包在 node_modules 可解析）

启动（enable=true）:
  若 row 已存在且带 disabled 标记 → 移除该 disabled 行
  若 row 不存在 → 追加 insert 块:
      - insert:
          - id: <name>
            name: '<name>'
```

安全边界：

- 写前先备份 `cordis.patch.yml.bak`（可回滚）。
- 修改只针对**用户显式点击**的插件 row；不修改 Core row、不替换既有 row。
- 返回 `note: 'composition 在启动时加载，重启 dsh 后生效'`。

### 5.5 状态读取

`status` 路由解析 `cordis.patch.yml` 的 insert row 列表（id/name/disabled），供 Client 初始渲染与「刷新」使用。

## 6. Client 半体设计（lib/client.js）

### 6.1 入口

`settings.section` 注册（与 dsh-plugin-design 一致）：

```js
slots.inject('settings.section', () => slots.register(
  { name: 'settings.section', id: 'dsh-plugin-manager', order: 90, label: '第三方插件' },
  () => React.createElement(Panel, null)
))
```

### 6.2 界面元素

- 说明文案（功能简介 + 安全边界）。
- **插件库文件夹**：输入框 + 「选择文件夹」按钮（`ctx.workspaces.pickDirectory()`，返回绝对路径；失败则回退输入框）+ 「扫描」按钮。
- **插件列表**：每行显示名称 / 路径 / 状态徽标（已启用 / 已禁用 / 未挂载），右侧「启动 / 关闭」按钮（当前已启用时显示「关闭」，否则「启动」）。
- **刷新 / 状态**：顶部显示当前 patch 路径与已启用插件数。
- 错误与提示区：扫描失败、写失败、重启提示。

### 6.3 交互

```js
fetch('/dsh-plugin-manager/scan', { method:'POST', body: JSON.stringify({ root }) })
  → 渲染列表
fetch('/dsh-plugin-manager/toggle', { method:'POST', body: JSON.stringify({ pluginPath, enable }) })
  → 成功则刷新列表 + 显示「重启 dsh 后生效」
```

## 7. Manifest（dsh.plugin.yaml）

依据 DH-TP-SDK §5 模板，声明：

```yaml
plugin:
  id: com.example.dsh.plugin-manager
  name: dsh plugin manager
runtime.harness: 0.1.5-rc.1 ~ <0.3.0
runtime.node: 22 ~ <25
cordis.apiLevel: 1
permissions.filesystem:
  read: [profiles/**]        # 扫描插件库 + 读 cordis.patch.yml
  write: [profiles/web/cordis.patch.yml]   # 启停写入
network.outbound: false
subprocess.enabled: false
shell.enabled: false
lifecycle: unloadable/reversible
session: modelVisibleState=false, durableState=false
security.level: S2, sandboxRequired: true
```

> 说明：实际加载由 `dsh` 的 Cordis 运行时执行，manifest 是声明式合规文档；文件权限以会话沙箱策略为准。
>
> 版本对齐（0.2.x）：manifest 与 package.json 的 harness 兼容范围已对齐到 `>=0.1.5-rc.1 <0.3.0`，并补齐 0.2.x 官方契约（`engines.dsh`、`dsh.manifestVersion`、`icon`、`scripts.test`）；`capabilities.consumes` 已移除 `ctx.fs`（Host 半体实际用 `node:fs`，见 §11.2）。自 `0.1.0-rc.7` 起 Harness 另提供 `settings.plugin.item`（插件配置卡片）+ Host `installSettingsSection` + Client `ctx.settingsScope`；本插件设置页是功能性管理器（走 `settings.section`），暂不迁移，若未来要暴露可持久化配置（默认扫描根、安全等级）再迁移到 `settings.plugin.item`。

## 8. 安装与挂载（本机交付步骤 / 其他用户安装）

### 8.1 一键安装（推荐，跨平台）

仓库内置 `install.ps1`（Windows）与 `install.sh`（POSIX），自动完成 ①② 并提示重启：

```bash
# Windows
powershell -ExecutionPolicy Bypass -File install.ps1
# macOS / Linux
bash install.sh
# 覆盖 DSH home / profile（可选）
powershell -ExecutionPolicy Bypass -File install.ps1 -DshHome C:\Users\you\.dsh
DSH_HOME=/home/you/.dsh DSH_PROFILE=headless bash install.sh
```

脚本幂等（重复运行不产生重复 junction/symlink 或重复 insert row）且健壮（已实测验证）：
- `DSH_PROFILE` 环境变量支持安装到非 web profile（默认 `web`）。
- profile 目录不存在时报错退出并提示「先运行一次 dsh」。
- 链接目标变更时更新链接；目标是真实目录（非链接）时报错退出而非误删。

### 8.2 手动安装

1. 源码放置：`E:\creat\DSH\open\dsh-plugin-manager\`（本目录，open 工作区）。
2. Junction：`$DSH_HOME/profiles/node_modules/dsh-plugin-manager` → `E:\creat\DSH\open\dsh-plugin-manager`（与 dsh-plugin-design 相同做法）。
3. 挂载：在 `$DSH_HOME/profiles/web/cordis.patch.yml` 追加：

   ```yaml
   - insert:
       - id: dsh-plugin-manager
         name: 'dsh-plugin-manager'
   ```

4. 重启 dsh → Host 半体（webServer 路由）热生效，Client 半体（设置页）在 boot 时由 `dsh-client-modules` 扫描加载。

### 8.3 跨平台说明

- `dshHome()` 解析 `$DSH_HOME` 的优先级：`DSH_HOME` 环境变量 → Windows `USERPROFILE\.dsh` → POSIX `HOME/.dsh`。
- Host 半体路径处理全部基于 `node:path`（平台自适应），无 Windows 硬编码。
- Windows 用 junction，POSIX 用 symlink（`install.sh` 用 `ln -s`）。

## 9. 测试与验收

| 项 | 方法 |
|---|---|
| 扫描正确性 | 对 `E:\creat\DSH\rule` 扫描，应发现 `dsh-plugin-design`；对 `E:\creat\DSH\open` 扫描，应发现 `dsh-plugin-manager` |
| 状态判定 | `mounted` 与 `loader.entries()` 一致；`disabledInPatch` 与 patch 文本一致 |
| 关闭 | 点击「关闭」→ patch 中该 row 出现 `disabled: true`，`.bak` 备份生成 |
| 启动 | 点击「启动」→ disabled 行被移除（或 insert row 生成） |
| 回滚 | 用 `.bak` 可恢复 |
| 持久化 | 重启 dsh 后设置页仍在，「第三方插件」入口默认出现 |

## 10. 已知限制

1. 插件启停**重启 dsh 后生效**（composition 在启动时加载；本插件不改动运行中的 Loader）。
2. 「启动」未挂载插件时，要求该插件包已在 `profiles/node_modules` 可解析（junction 或安装），否则 Cordis 无法 import。
3. `pickDirectory()` 依赖官方目录选择器服务（browse/native）；不可用时回退手动输入路径。
4. manifest 为声明式合规文档；实际权限以运行时沙箱策略为准。
5. 任务状态（patch 内容）持久在文件中，无进程内状态丢失问题。

## 11. 落地经验与故障排查（三次重启迭代实录）

本插件从「能写出来」到「真的跑起来」经历了三次重启排查，以下是**在真实 dsh 上验证过的**结论。任何新写 host composition 第三方插件的人都可以直接复用这套经验，不必重复踩坑。

### 11.1 故障链：三次重启，三个不同的根因

| 迭代 | 重启后终端报错 | 根因 | 修复 |
|---|---|---|---|
| 第 1 次 | `fs service unavailable` | `ctx.get('fs')` 在 host composition 全局 context 返回 undefined（fs 是 per-agent 服务） | Host 半体改用 `node:fs` |
| 第 2 次 | `webServer unavailable` | `ctx.get('webServer')` 在 apply 时拿到 undefined（webServer 由 webserver entry 异步依赖驱动，apply 先于它执行） | 声明 `inject: ['webServer']` + 用 `ctx.webServer` |
| 第 3 次 | 无报错 | — | 扫描 / 选择文件夹 / 启停全部正常 |

> **重要推论**：dsh-plugin-design 的 Host 半体挂到 host composition 后，`dshpd_*` 工具其实**从未注册成功过**——`ctx.get('fs')` 一直返回 undefined。这解释了为什么模型侧的 `Tool.listTools` 里始终看不到 `dshpd_discover` 等工具。dsh-plugin-design 若要真正生效，同样需要按 11.2 改造。

### 11.2 host 平面插件的服务访问速查（实测）

| 服务 | 在 host composition 可用？ | 正确访问方式 |
|---|---|---|
| `webServer` | ✅ 可用 | **必须 `inject: ['webServer']` 硬依赖** + `ctx.webServer`。`webServer` 由 `webserver` entry 提供，该 entry `inject: [webStartup]` → `cmdlineArgs`，是异步依赖链；`ctx.get('webServer')` 在 apply 时会拿到 undefined。官方 `dsh-client-modules` 同样用 `static inject = ["webServer", "loader"]` |
| `loader` | ✅ 可用 | `ctx.get('loader')`（可选读取，防御性判空）。loader 是 host 平面根服务，由 cordis-plugin-loader 同步 provide，任何 entry apply 前必已存在；官方 `dsh-host-plugin-inventory` 也是 `inject: ['loader']` |
| `fs` | ❌ **不可用** | `ctx.get('fs')` 返回 undefined。`fs` 是 per-agent 服务（`SandboxedFileSystem` 注入 `sandboxPolicy`，且 `Service[symbols.filter]` 按 isolate realm 过滤，host 平面插件不在同一 realm）。**替代：直接用 `node:fs`**（`import { readFileSync, writeFileSync, readdirSync } from 'node:fs'`），官方 `dsh-fs-local` 自己也 import node:fs |
| `sandboxPolicy` | ⚠️ 视 realm | 与 `fs` 同源（per-agent），host 平面插件不要依赖 |

**为什么不能用 `ctx.get('fs')` 的深层机制**（来自 cordis 源码）：

- `FileSystem extends Service`，构造器 `super(ctx, 'fs')` → `ctx.reflect.provide('fs', self, check)`。
- `Service[symbols.filter](ctx)` 判定：`ctx[symbols.isolate][this.name] === this.ctx[symbols.isolate][this.name]`——只有请求方 ctx 与提供方 ctx 处于**同一 isolate realm** 才可见。
- `SandboxedFileSystem` 还 `static inject = ['sandboxPolicy']`，它的激活依赖 per-agent 的 sandbox policy，因此落在 agent realm，而非 host 平面。

### 11.3 Client 半体的约束（实测）

- **必须挂 host composition**：`dsh-client-modules` 只扫描 host Loader entries，浏览器 boot 时按 `window.__DSH_BOOT__` 加载全局 UI；agent preset 的 client 不会被加载。
- **必须用 factory-form bundle**：`window.__ModuleLoader__.load({ id, factory })`，`factory(require)` 内 `require('react')` 取 React，`exports.apply` / `exports.inject` 挂插件；没有 `styles` service，样式用内联 style。
- **`ctx` 作用域陷阱**：被渲染组件（如 `Panel`）内部**不能直接引用 `ctx`**（闭包中不存在，会 ReferenceError）。须在 `apply(ctx)` 内先取服务（如 `ctx.get('workspaces')`），再通过 props 传入组件。
- **Client→Host 通信**：用 `fetch('/dsh-plugin-manager/...')` 调 Host 的 `webServer.register` 路由（持久化插件没有动态插件的 `host.call`）。
- 目录选择：`ctx.workspaces.pickDirectory()` 返回绝对路径；不可用时回退手动输入路径。

### 11.4 诊断方法论（本次验证过的工具组合）

1. **重启后看终端 stdout**：Host 半体的 `console.error('[dsh-plugin-manager] ...')` 是第一个信号源——`fs service unavailable` / `webServer unavailable` 直接指向根因。
2. **`dsh --profile web --dump-config`**：确认 patch row 是否被正确 compose（`- id: dsh-plugin-manager` 是否出现在输出中）。
3. **独立 node 冒烟脚本**：用 fake ctx（`webServer.register` 捕获路由 + 真实 node:fs 或临时 DSH_HOME）直接 `await import()` host 模块并调用路由 handler，**不污染真实 patch**：
   - scan：对 open / rule 目录扫描，核对 `mounted/enabled/inComposition`。
   - toggle：用**临时 DSH_HOME 副本**跑禁用→启用，核对 `disabled: true` 插入位置与 `.bak` 备份、幂等。
   - status：核对 rows 列表。
4. **PowerShell 中文乱码是显示问题**：`Get-Content` 默认 GBK 读 UTF-8 文件会乱码；用 read 工具或 `-Encoding UTF8` 确认真实内容。`node --check` 前先确认编码，避免把乱码当语法错误。

### 11.5 本插件最终验证清单（已全部通过）

- [x] `host.js` / `index.js` ESM 语法（node import 解析）
- [x] `client.js` CJS 语法（node --check）
- [x] `dsh --profile web --dump-config` 两个插件 row 正确 compose
- [x] scan 端到端：open→dsh-plugin-manager、rule→dsh-plugin-design，状态字段全对
- [x] toggle 端到端（临时副本）：禁用插入 `disabled: true` 于 name 行后、`.bak` 生成；启用移除、patch 复原
- [x] status 端到端：patch 路径 + rows 正确
- [x] install.ps1 首跑创建 junction+patch、二跑幂等（insert row 计数 1）
- [x] 真实部署重启后无报错，设置页「第三方插件」扫描/选择文件夹/启停正常
