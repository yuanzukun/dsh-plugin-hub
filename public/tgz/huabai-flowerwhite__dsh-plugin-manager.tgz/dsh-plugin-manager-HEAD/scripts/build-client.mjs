#!/usr/bin/env node
// dsh-plugin-manager — client bundle builder (zero dependency)
//
// 把 src/client.js 的 factory 体包装成 DSH 的 factory-form bundle：
//   window.__ModuleLoader__.load({ id: '<package name>', factory: (require) => { ... } })
//
// 用法：
//   node scripts/build-client.mjs           写入 lib/client.js（CRLF）
//   node scripts/build-client.mjs --check   只比对不写；不一致时退出码 1
//
// 本文件是构建工具，不会被 DSH 加载执行。
// 失败路径只设置 exitCode 并提前返回，不立即终止进程，因此不构成宿主退出风险。

import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(dirname(fileURLToPath(import.meta.url)))
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))
const id = String(pkg.name || '')
const srcPath = join(root, 'src', 'client.js')
const outPath = join(root, 'lib', 'client.js')
const checkOnly = process.argv.includes('--check')

function fail(message) {
  console.error(message)
  process.exitCode = 1
}

function build() {
  if (!id) {
    fail('package.json has no "name"; cannot derive the client module id')
    return
  }
  if (!existsSync(srcPath)) {
    fail('missing source: src/client.js')
    return
  }

  const body = readFileSync(srcPath, 'utf8').replace(/\r\n/g, '\n').replace(/\s+$/, '')
  const lines = [
    '// dsh-plugin-manager — Client half (factory-form bundle)',
    '//',
    '// 由 scripts/build-client.mjs 从 src/client.js 生成；请勿直接编辑本文件。',
    '// 修改 client 的流程：编辑 src/client.js → npm run build:client（check:client 只校验）。',
    '',
    'window.__ModuleLoader__.load({',
    "  id: '" + id + "',",
    '  factory: (require) => {',
    body,
    '  },',
    '})',
    '',
  ]
  const output = lines.join('\n').replace(/\n/g, '\r\n')
  const normalize = (text) => text.replace(/\r\n/g, '\n').replace(/\s+$/, '')

  if (checkOnly) {
    if (!existsSync(outPath)) {
      fail('lib/client.js is missing; run npm run build:client')
      return
    }
    const current = readFileSync(outPath, 'utf8')
    if (normalize(current) !== normalize(output)) {
      fail('lib/client.js is out of date with src/client.js; run npm run build:client')
      return
    }
    console.log('lib/client.js is up to date with src/client.js')
    return
  }

  writeFileSync(outPath, output, 'utf8')
  console.log('wrote ' + outPath + ' (' + Buffer.byteLength(output, 'utf8') + ' bytes)')
}

build()
