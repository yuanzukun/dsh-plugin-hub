// dsh-plugin-manager — 清单与 bundle 契约冒烟测试（node --test）
//
// 校验官方 0.2.x 插件契约（package.json.dsh / engines.dsh / icon / client
// factory bundle）与本包的导出、bundle patch 形状。纯只读，不启动 dsh 运行时。

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, existsSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = dirname(dirname(fileURLToPath(import.meta.url)))
const pkgPath = join(root, 'package.json')
const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'))

test('package.json：基本清单', () => {
  assert.equal(pkg.name, 'dsh-plugin-manager')
  assert.match(pkg.version, /^\d+\.\d+\.\d+/)
})

test('package.json：0.2.x 官方契约字段', () => {
  assert.equal(pkg.dsh.manifestVersion, 1, 'dsh.manifestVersion 应为 1')
  assert.ok(pkg.engines.dsh, 'engines.dsh 必填')
  assert.match(pkg.engines.dsh, /<0\.3\.0/, 'engines.dsh 上限应 <0.3.0')
  assert.equal(pkg.dsh.bundle.patch, './cordis.patch.yml')
  assert.equal(pkg.dsh.client.platform, 'web')
})

test('package.json：三处导出齐全', () => {
  assert.equal(pkg.exports['.'], './src/index.js')
  assert.equal(pkg.exports['./client'], './lib/client.js')
  assert.equal(pkg.exports['./package.json'], './package.json')
})

test('icon 已声明且位于包目录内', () => {
  assert.ok(pkg.icon, 'package.json.icon 必填')
  assert.ok(existsSync(join(root, pkg.icon)), 'icon 文件应存在：' + pkg.icon)
})

test('client bundle 是 factory-form 且 id 等于包名', () => {
  const code = readFileSync(join(root, 'lib/client.js'), 'utf8')
  assert.ok(code.includes('__ModuleLoader__.load'), '必须是 factory-form bundle')
  assert.ok(
    code.includes("id: 'dsh-plugin-manager'") || code.includes('id: "dsh-plugin-manager"'),
    'client bundle id 应等于包名',
  )
})

test('bundle patch 只 insert，不替换 Core row', () => {
  const text = readFileSync(join(root, 'cordis.patch.yml'), 'utf8')
  assert.ok(text.includes('- insert:'), '应使用 insert')
  assert.ok(!/^\s*-\s*(replace|override):/m.test(text), '不应 replace/override Core row')
})
