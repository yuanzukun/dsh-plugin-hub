# dsh plugin design — design.md

> 依据官方 DSH 0.2.x 插件契约（ruleset 0.2.1-r2）生成的可执行修改设计。
> 这是施工图，不是安全证明；静态预检不执行目标插件代码。

## 1. Target Plugin

- Plugin name: dsh-plugin-manager
- Package version: 1.2.0
- Path: E:\creat\DSH\open\dsh-plugin-manager
- Roles: package, bundle, client
- Compatibility: engines.dsh = >=0.1.5-rc.1 <0.3.0（运行时 0.2.1-rc.3，satisfied=true）

## 2. Executive Summary

（待补充：目标插件做什么、当前架构、最大兼容/安全/生命周期风险，以及是否存在 Core modification / private API / global mutable state。）

## 3. Target Classification 与 Host/Client 必要性（M1-08）

- 类型：**client-ui**
- 结论：client-ui（Host: required, Client: required）
- 分发目标：本机修改与独立分发是两个结果；默认同时准备可分发包材料，但需通过干净环境验收后才可声明“可独立分发”。

| 半体 | 是否必要 | 运行位置 | 功能 | 保留/删除/外移 | 风险 |
|---|---|---|---|---|---|
| host | required | src/index.js | 应用 Cordis patch / 提供服务 | retain | Host 同进程模式：同步阻塞、OOM、process.exit 会影响整个 DSH 进程。 |
| client | required | ./lib/client.js | 渲染 UI 并读取 Host 路由 | retain-minimal | 运行在共享 renderer：异常会破坏页面；需有界数据、取消与清理。 |

保留理由：host — Loader 按包名导入 Host 入口；工具/服务/路由注册必须发生在 Host 半体。；client — 已经声明 dsh.client：Client 半体是现有功能的一部分，应保留并按需最小化。

> 必要入口保留不等于改造失败；无法在保留功能的同时删除全部半体时，应说明架构限制，而不是机械删除。

## 4. Official Contract Snapshot

- bundle declared: true（./cordis.patch.yml）
- client declared: true（platform=web, bundle=./lib/client.js）
- engines.dsh: >=0.1.5-rc.1 <0.3.0
- manifestVersion: 1
- Host 入口: src/index.js（present=true）
- 实际产物扫描：artifact 文件 1 个；扫描完整=true

## 5. Findings

- [INFO] PKG_PRIVATE — package.json 标记 private（package.json）
  - private 包不能发布到 npm；仅本地 link 安装时无影响。
- [MEDIUM] CLIENT_NO_BUILD_SCRIPT — client 有源码但没有可重复的构建脚本（package.json）
  - package.json 没有 build / prepare 等 client 构建命令；修改 src/client 后无法生成新的 lib/client.js，UI 会一直停留在旧版本。先补构建脚本（如 build:client），再写进 design。

## 6. Modification Plan

| ID | Reason | File | Before | After | Risk | Validation | Rollback |
|---|---|---|---|---|---|---|---|
| M001 | `CLIENT_NO_BUILD_SCRIPT`（MEDIUM）：client 只有手写产物 `lib/client.js`，没有可重复构建流程，无法证明产物来自源码 | 新建 `src/client.js` | 无（factory 体只存在于 `lib/client.js`） | 把 factory 体提取为真源 `src/client.js`（内容与当前产物逐字一致） | 低：内容由脚本从现产物提取，不改逻辑 | `node scripts/build-client.mjs --check` 与 `lib/client.js` 一致 | 删除新文件 |
| M002 | 同上：需要一个零依赖生成器把真源包装成 DSH 的 factory-form bundle | 新建 `scripts/build-client.mjs` | 无 | 读 `src/client.js` → 生成 `lib/client.js`（`window.__ModuleLoader__.load({ id, factory })`）；`--check` 只比对不写 | 低 | 生成结果与现有产物等价（factory 体逐字一致） | 删除新文件 |
| M003 | 同上：登记构建命令，供 `CLIENT_NO_BUILD_SCRIPT` 识别与人工复用 | `package.json` | `scripts` 仅 `test`；`files` 无 `scripts` | 增加 `"build:client": "node scripts/build-client.mjs"`、`"check:client": "node scripts/build-client.mjs --check"`；`files` 增加 `"scripts"` | 低 | `dshpd_analyze` 不再报 `CLIENT_NO_BUILD_SCRIPT`；client 分回升至 100 | `dshpd_rollback` |
| M004 | 文档：记录 client 构建契约，避免后人手改产物 | `design.md`（插件根） | 无构建说明 | 追加「Client 构建流程」小节 | 低 | 人工复核 | `dshpd_rollback` |

不改动 Host/Client 运行逻辑；`lib/client.js` 仅由生成器重新产出，factory 体与修改前逐字一致。

计划与授权流程：
1. `dshpd_plan` — 列出精确文件、目标根、design.md 哈希、操作集合与运行时指纹，得到 `planHash`。
2. `dshpd_approve` — 回传同一个 `planHash`，经官方 approval 通道（或已授予的 danger-full-access 预设）签发绑定凭证。
3. `dshpd_backup` — 逐字节快照全部计划文件；任何文件失败则不提交。
4. `dshpd_apply` / `dshpd_write` / `dshpd_migrate` — 使用 fs 版本守卫提交；冲突即拒绝。
5. `dshpd_verify` — 分层检查；缺证据不会显示通过。

## 7. Deployment Target

- 目标 profile 由调用方明确指定；本设计不默认任何 profile。
- 当前状态：installed=true / selected=true / enabled=true
- `desktop`：selected=true，enabled=true，packageResolvable=true（C:\Users\YYZ\.dsh\profiles\desktop\cordis.patch.yml）
- `web`：selected=true，enabled=true，packageResolvable=true（C:\Users\YYZ\.dsh\profiles\web\cordis.patch.yml）
- 部署只能通过官方 `pluginManager`（installBundle/removeBundle/setBundleEnabled）；没有该服务时只输出 dry-run，不写 profile 文件。

## 8. UI 方案 / UI 恢复

- 已有 Client 半体：按 CLIENT_BUNDLE / CLIENT_GRAPH / 健康回执逐层检查，不重新设计入口。

## 9. Independent Distribution（独立分发合同）

本设计默认同时准备可分发交付物；只有通过干净环境验收后才能声明“可独立分发”。

- 包内容：manifest、Host 入口、Client 入口/chunks、assets/worker/sidecar、运行依赖与 files 覆盖。
- 可移植性：不得包含作者绝对路径、临时 link、未声明依赖、私有 registry、开发服务器或维护插件状态。
- 干净环境：未安装 dsh-plugin-design、作者源码不可依赖时，用公开步骤安装同一个 `.tgz` 并验证冷启动/功能/重启/卸载。
- 交付物：完整源码、构建锁文件、预构建 `.tgz`、SHA-256、支持矩阵、安装/卸载说明、分发验收报告。
- 状态分开报告：本机修改结果、独立分发验收、发布准备、实际发布（本工具不上传）。

- 本项目的 Host/Client 保留理由必须写入分发报告（`hostClientNecessity`），不得只写 README 模板。

## 10. Verification

（typecheck / lint / unit / integration / lifecycle / session / concurrency / security / compatibility；无则 NOT_AVAILABLE。）
- 静态：`dshpd_analyze`（含实际产物与覆盖率）。
- 修改后：`dshpd_verify --intent local-modification`（快照完整性、CAS、阻断项、产物）。
- 部署/UI：`dshpd_verify --intent deployment`（Client graph 与健康回执；缺回执为 UNKNOWN）。
- 运行时风险（同步循环/退出/OOM）：只能在隔离运行器中验证；未运行则保持 NOT_RUN。

## 11. Approval

（用户确认后才执行修改。批准必须绑定 `planHash`、文件基线、操作集合、目标 profile 与调用身份；设计或文件变化后旧批准自动失效。）
