# dsh plugin design — design.md

> 依据 DH-TP-SDK 工程化第三方插件规范生成的可执行修改设计。
> 注意：Bronze/Silver/Gold、P0-P4、S0-S4 为本工程化规范等级，不是 DeepSeek 官方认证。

## 1. Target Plugin

- Plugin ID: com.example.dsh.plugin-manager
- Name: dsh-plugin-manager
- Path: E:\creat\DSH\open\dsh-plugin-manager

## 2. Executive Summary

`dsh plugin manager` 是一个已落地、已挂载到 host composition（web profile）的第三方插件管理器：Host 半体用 `node:fs` + `webServer` 注册 `/dsh-plugin-manager/{scan,toggle,status}` 三个 HTTP 路由，Client 半体在 `settings.section` 提供「第三方插件」设置页，通过 `fetch` 调 Host 路由实现「选文件夹 → 扫描 → 启停（写 cordis.patch.yml 的 disabled 标记）」。

当前插件已适配 dsh 且运行正常（无 Core modification、无 private API、无 global mutable state）。本次修改目标是**版本对齐**：DeepSeek Harness 已升级到 `@deepseek-ai/dsh@0.1.1-rc.2`，DH-TP-SDK 规范升级到 1.1.0，而本插件 manifest 仍声明 `harness.min: 0.1.0-rc.7`、package.json 仍声明 `harness: ">=0.1.0-rc.7"`。需要把 harness 兼容范围下限抬升到 `0.1.1-rc.2`，并顺带修正一处 manifest 合规偏差（`capabilities.consumes` 声明了 `ctx.fs`，但 Host 半体实际用 `node:fs`，并未消费 `ctx.fs`）。

无功能行为变更（路由、扫描、启停逻辑、UI 均不变），仅声明式元数据与文档对齐。

## 3. Current Architecture

- Plugin Entry：`src/index.js` → `src/host.js`（Host 半体，ESM，`export default { inject: ['webServer'], apply(ctx) {...} }`）
- Services：Host 用 `inject: ['webServer']` + `ctx.get('loader')`（可选）；文件系统用 `node:fs`（非 `ctx.fs`）。Client 用 `ctx.get('workspaces')` + `ctx.slots`。
- Tools：无（不注册模型工具；能力通过 HTTP 路由暴露）
- Events：无订阅、无 waterfall
- Session：`modelVisibleState: false`、`durableState: false`；状态全部落盘于 `cordis.patch.yml`
- Filesystem：`node:fs` 直接读写（扫描任意目录 + 读写 patch）；manifest 声明 read `profiles/**`、write `profiles/web/cordis.patch.yml(.bak)`
- Network：无出站（仅内部 `webServer.register` HTTP 路由）
- Subprocess：禁用
- Bundle：`cordis.patch.yml` 追加 insert row，不替换 Core row

## 4. Static Scan Summary

- Issues found: 1
- [MEDIUM] NO_TESTS — 未检测到 tests 目录
- overall: READY_TO_MODIFY（compatibility/security/lifecycle/session/tool/bundle/manifest 均为 100）

## 5. Modification Plan

| ID | Reason | File | Before | After |
|---|---|---|---|---|
| M001 | 版本对齐：版本号提升为 1.1.0（与参考实现一致，minor 兼容性更新） | dsh.plugin.yaml | `  version: 1.0.0` | `  version: 1.1.0` |
| M002 | 版本对齐：harness 下限抬升到当前已安装版本 | dsh.plugin.yaml | `    min: 0.1.0-rc.7` | `    min: 0.1.1-rc.2` |
| M003 | 合规修正：Host 半体实际用 `node:fs`，未消费 `ctx.fs`；移除该声明 | dsh.plugin.yaml | `    - ctx.fs\n    - ctx.webServer` | `    - ctx.webServer` |
| M004 | 版本对齐：npm 包版本号提升 | package.json | `  "version": "1.0.0",` | `  "version": "1.1.0",` |
| M005 | 版本对齐：harness 兼容范围上限补齐 `<0.2.0` | package.json | `      "harness": ">=0.1.0-rc.7"` | `      "harness": ">=0.1.1-rc.2 <0.2.0"` |
| M006 | 文档对齐：标注 DH-TP-SDK 1.1.0 与对齐的 Harness 版本 | design.md | `（DH-TP-SDK）、` | `（DH-TP-SDK 1.1.0，对齐 Harness \`0.1.1-rc.2\`）、` |
| M007 | 文档对齐：§7 manifest 模板 harness 版本 | design.md | `runtime.harness: 0.1.0-rc.7 ~ <0.2.0` | `runtime.harness: 0.1.1-rc.2 ~ <0.2.0` |
| M008 | 文档对齐：补充版本对齐与 settings 双入口说明 | design.md | §7 结尾 `> 说明：…` 后追加一段 | 新增「版本对齐（0.1.1-rc.2）」说明 |

风险：均为声明式元数据与文档改动，无运行时代码改动，风险极低。M003 仅移除未消费的能力声明，不影响运行。
验证：修改后 `dshpd_analyze` 复扫（manifest 仍 100）；`node --check` 无需（源码未动）；重启 dsh 后设置页「第三方插件」仍正常。
回滚：所有改动文件在 `dshpd_backup` 快照内，可 `dshpd_rollback` 一键恢复。

## 6. Verification

- 静态合规：`dshpd_analyze`（修改前后对比，manifest/security/lifecycle 维度）
- 语法：源码未改动，无需 `node --check`
- 运行时：重启 dsh 后「第三方插件」设置页扫描/启停正常（无代码变更，预期不变）
- 单元/集成/生命周期/会话/并发/安全/兼容：NOT_AVAILABLE（本插件当前无 tests 目录，本次为纯元数据/文档对齐，不改动运行时行为）

## 7. Approval

（用户确认后才执行修改；未确认前严禁修改目标插件源码）
