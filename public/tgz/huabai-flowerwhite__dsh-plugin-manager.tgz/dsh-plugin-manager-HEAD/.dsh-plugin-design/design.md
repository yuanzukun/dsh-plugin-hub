# dsh plugin design — design.md

> 依据官方 DSH 0.2.x 插件契约（ruleset 0.2.1）与 DH-TP-SDK 工程化规范生成的可执行修改设计。
> 生成工具：`dsh-plugin-design@1.3.1`（新增 client 服务目录检测）。Bronze/Silver/Gold、P0–P4、S0–S4 为本工程化等级，非 DeepSeek 官方认证。

## 1. Target Plugin

- Plugin name: `dsh-plugin-manager`
- Package version: `1.2.0`
- Path: `E:\creat\DSH\open\dsh-plugin-manager`
- Roles: package, bundle, client
- Compatibility: `engines.dsh = >=0.1.5-rc.1 <0.3.0`，运行时 `0.1.5-rc.1`，**satisfied = true**
- 部署目标：**desktop profile**，已挂载（row line 73）

## 2. Executive Summary

插件由 Host 半体（`src/host.js`：`inject: ['webServer']` + `node:fs`，`/dsh-plugin-manager/{scan,toggle,status}`）与 Client 半体（`lib/client.js`：factory-form lazy-CJS，`settings.section`）组成。无 Core modification / private API / global mutable state / outbound network / subprocess。

**本插件在 0.2.x 契约上已完全达标**，本轮为验证轮，无必须修改项。上一轮修复的 client 目录选择器服务名（`workspaces` → `uiWorkspace`）已被 1.3.1 的服务目录检测正确识别：

- `official.client.services = ["uiWorkspace"]`
- `official.client.legacyServices = []`（无已移除服务）
- `official.client.unknownServices = []`（无未知服务）
- 未触发 `CLIENT_WORKSPACES_PICKDIRECTORY` / `CLIENT_LEGACY_SERVICE` / `CLIENT_UNKNOWN_SERVICE`

## 3. Official Contract Snapshot

| 项 | 值 |
|---|---|
| bundle declared | true（`./cordis.patch.yml`） |
| client declared | true（`platform=web`，`exportKey=./client` → `./lib/client.js`） |
| engines.dsh | `>=0.1.5-rc.1 <0.3.0`（satisfied） |
| manifestVersion | 1 |
| client bundle | factoryForm=true、apply/inject=true、buildStale=false |
| client 服务 | `uiWorkspace`（`pickDirectory(): Promise<string \| null>`） |
| UI 座位 | `settings.section` |
| 运行时图 | `inGraph=true`，`rev=9951c2c6850a`，`graphRev=0c46bfd9aeb0` |
| 部署 | desktop mounted=true、web mounted=true、`needsDesktopMount=false` |

## 4. Findings

- [INFO] `PKG_PRIVATE` — `package.json` 标记 `private`。本地交付插件，**保留**（防止误发布）。
- 无 HIGH / MEDIUM / LOW / BLOCKER / CRITICAL。
- **工具误报（非插件缺陷）**：`official.client.uiSlots` 中出现 `"dsh."`。原因是 `KNOWN_UI_SLOTS` 含前缀 `'dsh.'`，而插件 UI 文案 `含 dsh.plugin.yaml …`（`lib/client.js:159`）被 `clientText.includes(slot)` 子串命中。不影响任何判定（`CLIENT_NO_UI_SLOT` 通过；真实座位 `settings.section` 已识别）。

## 5. Modification Plan

| ID | Reason | File | Before | After | Risk | Validation | Rollback |
|---|---|---|---|---|---|---|---|
| M004 | **时序缺陷（功能性）**：`uiWorkspace` 由 `dsh-client-ui-workspace` 提供，激活顺序不保证早于本插件；在 `apply` 阶段一次性 `ctx.get('uiWorkspace')` 会拿到 `undefined` 并被永久固化成 `null`，此后点击静默失效。参考实现（`dsh-plugin-design/src/client.js:443`）采用**点击时延迟获取**规避该时序 | lib/client.js | `apply` 内 `const uiWorkspace = ctx.get('uiWorkspace')`，结果作为 prop 传给 Panel | `apply` 内定义 `getWorkspace()` 延迟读取器，Panel 每次点击时调用 `getWorkspace()`；不可用时明确报错并回退手动输入 | 低：只改取值时机，服务名仍为 `uiWorkspace` | 刷新页面后点击「选择文件夹」应弹出系统目录选择框；`dshpd_verify` 12 项保持 PASS | `dshpd_rollback` |

其余为绿，无其他修改项：

| ID | 结论 |
|---|---|
| — | 契约、兼容性、bundle/client 形态、服务目录（`services=[uiWorkspace]`、`legacyServices=[]`、`unknownServices=[]`）、部署挂载、运行时图全部为绿 |
| — | `PKG_PRIVATE` 为 INFO 且属有意设计，不改 |
| — | `uiSlots` 的 `"dsh."` 是工具启发式误报，不为此迁就修改插件文案 |

## 6. Desktop Profile Deployment（桌面版必做）

- 桌面版读取 `C:\Users\YYZ\.dsh\profiles\desktop`；**web profile 的挂载对桌面版无效**。
- desktop patch：`profiles\desktop\cordis.patch.yml` → **mounted=true**（row line 73）
- web patch：`profiles\web\cordis.patch.yml` → mounted=true（row line 16）
- desktop 包解析：✅ `E:\creat\DSH\open\dsh-plugin-manager`
- `needsDesktopMount=false`，无需再挂载。

## 7. UI 恢复与验证（client 插件必做）

- Client 入口：`./lib/client.js`；座位：`settings.section`
- 当前：`inGraph=true`、`bundleExists=true`、`buildStale=false`、`applyPresent=true`、`injectPresent=true`
- 服务依赖：`uiWorkspace`（目录选择器），已是正确服务名；缺失时回退为手动输入路径。
- 验证入口：`dshpd_ui_check` → `runtime.inGraph=true` 且 `legacyServices=[]`。

## 8. Verification

- `dshpd_analyze`：1 INFO，`overall=READY_TO_MODIFY`；manifest / compatibility / client / testing 均 100。
- `dshpd_ui_check`：`inGraph=true`、`legacyServices=[]`、`unknownServices=[]`、`rootCause=null`。
- `node --test`：6/6 PASS。
- `dshpd_verify`：本轮改用上一轮备份基线 `795259f6-60b4-4dcf-ad13-ea5c06335131`（`lib/client.js`）复核，确认已应用版本仍一致。
- typecheck / lint：NOT_AVAILABLE；集成/生命周期/并发矩阵：NOT_AVAILABLE（启发式扫描，非权威认证）。

## 9. Approval

本轮无修改，**不需要 approve/backup/apply**；直接执行 `dshpd_verify` 复核既有基线即可。若未来出现 M 项，仍按：

```text
dshpd_approve → dshpd_backup → dshpd_apply/dshpd_migrate → dshpd_verify → dshpd_report
```

任一修改失败或 verify 不通过时，调用 `dshpd_rollback` 恢复备份文件。
