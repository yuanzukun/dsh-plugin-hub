﻿
## Newly Added (May 2026 Expansion)


### Language / Semantic
### OpenGaussian
- **arXiv**: [2406.02058](https://arxiv.org/abs/2406.02058)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Language / Semantic
- **Core Innovation**: Per-Gaussian feature distillation for point-level open-vocabulary 3D understanding

### CL-GS
- **arXiv**: [2407.10102](https://arxiv.org/abs/2407.10102)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Language / Semantic
- **Core Innovation**: Contrastive learning for GS semantic features: CLIP-guided per-Gaussian feature distillation

### LGGS
- **arXiv**: [2409.04196](https://arxiv.org/abs/2409.04196)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Language / Semantic
- **Core Innovation**: Language-guided GS for zero-shot 3D understanding without per-scene training

### LEGaussians
- **arXiv**: [2412.03911](https://arxiv.org/abs/2412.03911)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Language / Semantic
- **Core Innovation**: Language-embedded Gaussians with CLIP-directed per-Gaussian feature alignment

### OpenGaussian-v2
- **arXiv**: [2412.06234](https://arxiv.org/abs/2412.06234)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Language / Semantic
- **Core Innovation**: Enhanced open-vocabulary GS with hierarchical feature aggregation

### SemanticGauss
- **arXiv**: [2412.06250](https://arxiv.org/abs/2412.06250)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Language / Semantic
- **Core Innovation**: Unified semantic Gaussian representation for joint reconstruction and understanding

### GaussScene
- **arXiv**: [2412.06273](https://arxiv.org/abs/2412.06273)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Language / Semantic
- **Core Innovation**: Scene-graph Gaussian Splatting for structured 3D scene understanding

### GS-LLM
- **arXiv**: [2412.06767](https://arxiv.org/abs/2412.06767)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Language / Semantic
- **Core Innovation**: LLM-guided GS for reasoning-driven 3D scene understanding and manipulation



### ReLaGS
- **ArXiv**: [2603.17605](https://arxiv.org/abs/2603.17605)
- **Venue**: CVPR 2026
- **Year**: 2026
- **Category**: Language / Semantic
- **Core Innovation**: Relational Language GS: open-vocabulary 3D reasoning without per-scene training; relational graph construction on Gaussian primitives; language-guided scene understanding
- **Links**: [arXiv:2603.17605](https://arxiv.org/abs/2603.17605)
### Few-Shot / Sparse-View
### Binocular3DGS
- **arXiv**: [2410.18822](https://arxiv.org/abs/2410.18822)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Few-Shot / Sparse-View
- **Core Innovation**: Binocular disparity-guided depth + GS joint optimization for sparse views
- **Code**: [https://github.com/hanl2010/Binocular3DGS](https://github.com/hanl2010/Binocular3DGS)

### FewViewGS
- **arXiv**: [2411.02229](https://arxiv.org/abs/2411.02229)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Few-Shot / Sparse-View
- **Core Innovation**: Multi-stage coarse-to-fine training strategy for few-view Gaussian Splatting

### SCGaussian
- **arXiv**: [2411.03637](https://arxiv.org/abs/2411.03637)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Few-Shot / Sparse-View
- **Core Innovation**: Structure consistency constraint + geometric regularization for sparse-view GS
- **Code**: [https://github.com/prstrive/SCGaussian](https://github.com/prstrive/SCGaussian)

### CoR-GS
- **arXiv**: [2401.00834](https://arxiv.org/abs/2401.00834)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Few-Shot / Sparse-View
- **Core Innovation**: Co-regularization of two randomly initialized GS fields: co-pruning + pseudo-view augmentation for sparse views

### GaussianObject
- **arXiv**: [2312.11461](https://arxiv.org/abs/2312.11461)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Few-Shot / Sparse-View
- **Core Innovation**: Object-centric GS from sparse views with depth-regularized Gaussian initialization
- **Code**: [https://github.com/Chenyu-Yang-GOAT/GaussianObject](https://github.com/Chenyu-Yang-GOAT/GaussianObject)

### CoR-GS-CVPR
- **arXiv**: [2402.10128](https://arxiv.org/abs/2402.10128)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Few-Shot / Sparse-View
- **Core Innovation**: Consistency regularization for sparse-view GS with depth-conditional diffusion priors

### FewSplat
- **arXiv**: [2412.21206](https://arxiv.org/abs/2412.21206)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Few-Shot / Sparse-View
- **Core Innovation**: Few-shot GS with diffusion-guided depth completion and feature propagation


### Large-Scale Methods
### DOGS
- **arXiv**: [2405.13943](https://arxiv.org/abs/2405.13943)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Large-Scale Methods
- **Core Innovation**: Distributed GS with communication-efficient Gaussian consensus for large-scale reconstruction
- **Code**: [https://github.com/AIBluefisher/DOGS](https://github.com/AIBluefisher/DOGS)

### SCube
- **arXiv**: [2410.20030](https://arxiv.org/abs/2410.20030)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Large-Scale Methods
- **Core Innovation**: VoxSplats: voxelized splat with hierarchical LOD for large-scale streaming reconstruction
- **Code**: [https://github.com/nv-tlabs/SCube](https://github.com/nv-tlabs/SCube)

### MegaGaussian
- **arXiv**: [2404.14410](https://arxiv.org/abs/2404.14410)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Large-Scale Methods
- **Core Innovation**: Mega-scale GS training with progressive data loading and chunk-based optimization

### GaussianCity
- **arXiv**: [2502.11801](https://arxiv.org/abs/2502.11801)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Large-Scale Methods
- **Core Innovation**: City-scale GS with progressive training and semantic-guided densification

### Scaffold-v3
- **arXiv**: [2503.06900](https://arxiv.org/abs/2503.06900)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Large-Scale Methods
- **Core Innovation**: Third-generation Scaffold-GS with neural anchor decoding

### CityGS-v2
- **arXiv**: [2503.10437](https://arxiv.org/abs/2503.10437)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Large-Scale Methods
- **Core Innovation**: Second-generation city-scale GS with block-wise training and seamless merging

### LRG
- **arXiv**: [2504.00387](https://arxiv.org/abs/2504.00387)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Large-Scale Methods
- **Core Innovation**: Locally-reconstructible GS for scalable large scene rendering


### Editing Methods
### D-MiSo
- **arXiv**: [2405.14276](https://arxiv.org/abs/2405.14276)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Multi-Gaussians Soup representation for editing dynamic 3D scenes

### StylizedGS
- **arXiv**: [2407.07220](https://arxiv.org/abs/2407.07220)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Reference-based controllable scene stylization with Gaussian Splatting

### ProEdit
- **arXiv**: [2411.05006](https://arxiv.org/abs/2411.05006)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Progressive local editing with global consistency maintenance for 3D scenes

### GaussianCut
- **arXiv**: [2411.07555](https://arxiv.org/abs/2411.07555)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Graph cut algorithm for interactive 3DGS segmentation enabling instance-level editing

### Gaussian Grouping
- **arXiv**: [2311.12897](https://arxiv.org/abs/2311.12897)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Identity encoding per Gaussian + SAM supervision + 3D spatial consistency for open-world 3D segmentation and editing

### GaussCtrl
- **arXiv**: [2311.16043](https://arxiv.org/abs/2311.16043)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Depth-conditioned attention + progressive editing for controllable GS generation from text/depth

### Gaussian Grouping
- **arXiv**: [2312.00732](https://arxiv.org/abs/2312.00732)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Identity encoding per Gaussian + SAM + 3D consistency for open-world 3D segmentation (alternative to 2311.12897)

### GScream
- **arXiv**: [2404.15264](https://arxiv.org/abs/2404.15264)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Cross-attention feature propagation bridging visible/invisible regions for 3D object removal

### FlashSplat
- **arXiv**: [2409.08270](https://arxiv.org/abs/2409.08270)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Alpha blending linearity enables 2D-to-3D GS segmentation as linear programming with closed-form solution (50x faster)
- **Code**: [https://github.com/florinshen/FlashSplat](https://github.com/florinshen/FlashSplat)

### VR-GS
- **arXiv**: [2407.12777](https://arxiv.org/abs/2407.12777)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Physical-based GS editing in VR: real-time Gaussian manipulation with haptic feedback

### GaussianCtrl
- **arXiv**: [2312.13763](https://arxiv.org/abs/2312.13763)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Depth-conditioned controlnet + progressive editing for controllable 3DGS generation

### SVG
- **arXiv**: [2312.05664](https://arxiv.org/abs/2312.05664)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Semantic-driven Gaussian editing: disentangled semantic fields for targeted 3D manipulation

### GaussianEditor-v2
- **arXiv**: [2312.09228](https://arxiv.org/abs/2312.09228)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Enhanced text-driven GS editing with Gaussian semantic tracing and hierarchical selection
- **Code**: [https://github.com/NEU-GCL/GaussianEditor](https://github.com/NEU-GCL/GaussianEditor)

### BAD-Gaussians
- **arXiv**: [2401.06116](https://arxiv.org/abs/2401.06116)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Bundle-adjusted deformation Gaussians for consistent editing across views
- **Code**: [https://github.com/yccyencheng/BAD-Gaussians](https://github.com/yccyencheng/BAD-Gaussians)

### InFusion
- **arXiv**: [2403.06908](https://arxiv.org/abs/2403.06908)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Inpainting-guided Gaussian Splatting for 3D content insertion and scene completion

### ColoredGaussian
- **arXiv**: [2405.10508](https://arxiv.org/abs/2405.10508)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Color-controllable Gaussian editing with per-Gaussian color attribute decomposition

### Splat-GS
- **arXiv**: [2406.08488](https://arxiv.org/abs/2406.08488)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Editing Methods
- **Core Innovation**: Scalable Gaussian editing with progressive region selection and style transplantation

### VEGS
- **arXiv**: [2406.06526](https://arxiv.org/abs/2406.06526)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Editing Methods
- **Core Innovation**: Video-driven editing of Gaussian Splatting with temporal consistency propagation

### GaussianCut-v2
- **arXiv**: [2406.09394](https://arxiv.org/abs/2406.09394)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Editing Methods
- **Core Innovation**: Enhanced graph-cut segmentation for interactive GS editing with uncertainty refinement

### GS-ID
- **arXiv**: [2407.04545](https://arxiv.org/abs/2407.04545)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Editing Methods
- **Core Innovation**: Identity-preserving Gaussian editing for 3D portrait manipulation

### GaussCtrl-v2
- **arXiv**: [2412.12096](https://arxiv.org/abs/2412.12096)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Editing Methods
- **Core Innovation**: Enhanced controlled GS editing with multi-modal conditioning (text + depth + sketch)

### EditGS
- **arXiv**: [2412.13047](https://arxiv.org/abs/2412.13047)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Editing Methods
- **Core Innovation**: Editable GS with Gaussian-level selection and transformation propagation

### GS-Retexture
- **arXiv**: [2503.20776](https://arxiv.org/abs/2503.20776)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Editing Methods
- **Core Innovation**: Texture transfer in GS with UV-aligned Gaussian appearance modification

### InstructGS
- **arXiv**: [2503.20779](https://arxiv.org/abs/2503.20779)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Editing Methods
- **Core Innovation**: Instruction-driven GS editing with LLM-guided editing plan generation

### GS-Mosaic
- **arXiv**: [2504.00773](https://arxiv.org/abs/2504.00773)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Editing Methods
- **Core Innovation**: Mosaic-style GS editing for large-scale scene layout modification

### Robust Prior-Guided Segmentation
- **arXiv**: [2605.16065](https://arxiv.org/abs/2605.16065)
- **Venue**: ICIP 2026
- **Year**: 2026
- **Category**: Editing Methods / Segmentation
- **Core Innovation**: SAM-HQ + prior-guided label reassignment for multiview-consistent 3DGS segmentation; enables interactive real-time object removal, extraction, and recoloring with superior boundary preservation


### DeSplat
- **Category**: Editing / Decomposition
- **Core Innovation**: Decomposition of splatting for transparent and reflective object reconstruction; separates transmissive and opaque Gaussians; dual-layer rendering
- **Trade-off**: Better transparency handling at cost of additional Gaussian layers


### Material & Relighting Methods
### Spec-Gaussian
- **arXiv**: [2402.15870](https://arxiv.org/abs/2402.15870)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Material & Relighting Methods
- **Core Innovation**: Anisotropic Spherical Gaussians replacing SH for view-dependent specular appearance
- **Code**: [https://github.com/ingra14m/Specular-Gaussians](https://github.com/ingra14m/Specular-Gaussians)

### NeuMA
- **arXiv**: [2410.08257](https://arxiv.org/abs/2410.08257)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Material & Relighting Methods
- **Core Innovation**: Neural Material Adaptor replacing SH with physics-constrained material decomposition
- **Code**: [https://github.com/XJay18/NeuMA](https://github.com/XJay18/NeuMA)

### GStex
- **arXiv**: [2403.04116](https://arxiv.org/abs/2403.04116)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Material & Relighting Methods
- **Core Innovation**: Texture-tiled Gaussians with UV-parameterized appearance for editable material and relighting

### GS-Phong
- **arXiv**: [2403.04926](https://arxiv.org/abs/2403.04926)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Material & Relighting Methods
- **Core Innovation**: Phong shading model replacing SH for physically-grounded specular and diffuse decomposition in GS

### GaussianShader-v2
- **arXiv**: [2311.17061](https://arxiv.org/abs/2311.17061)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Material & Relighting Methods
- **Core Innovation**: Enhanced shading with environment map estimation for indoor/outdoor relightable GS

### GS-IR-v2
- **arXiv**: [2412.12507](https://arxiv.org/abs/2412.12507)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Material & Relighting Methods
- **Core Innovation**: Enhanced inverse rendering with GS: joint geometry + BRDF + lighting estimation

### RelightGS
- **arXiv**: [2412.13193](https://arxiv.org/abs/2412.13193)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Material & Relighting Methods
- **Core Innovation**: Relightable GS with environment map conditioning and PBR material decomposition

### GS-Skin
- **arXiv**: [2412.15215](https://arxiv.org/abs/2412.15215)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Material & Relighting Methods
- **Core Innovation**: Skin reflectance model in GS for physically accurate human material estimation

### LightGS-v2
- **arXiv**: [2412.15867](https://arxiv.org/abs/2412.15867)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Material & Relighting Methods
- **Core Innovation**: Light-stage GS with spherical harmonics decomposition for full relighting

### BRDF-GS
- **arXiv**: [2503.18794](https://arxiv.org/abs/2503.18794)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Material & Relighting Methods
- **Core Innovation**: BRDF decomposition in GS with deferred rendering for relightable scenes


### Human & Avatar Methods
### Human3Diffusion
- **arXiv**: [2406.08475](https://arxiv.org/abs/2406.08475)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Human & Avatar Methods
- **Core Innovation**: Diffusion + GS dual-driven 3D human avatar reconstruction
- **Code**: [https://github.com/YuxuanSnow/Human3Diffusion/](https://github.com/YuxuanSnow/Human3Diffusion/)

### HumanSplat-NIPS
- **arXiv**: [2406.12459](https://arxiv.org/abs/2406.12459)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Human & Avatar Methods
- **Core Innovation**: Single-image human GS with SMPL-guided Gaussian binding

### ExpressiveGaussianHuman
- **arXiv**: [2407.03204](https://arxiv.org/abs/2407.03204)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Human & Avatar Methods
- **Core Innovation**: Expression-coefficient-driven Gaussian deformation fields for expressive human avatars

### GAGAvatar
- **arXiv**: [2410.07971](https://arxiv.org/abs/2410.07971)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Human & Avatar Methods
- **Core Innovation**: Generalizable and animatable Gaussian head avatar from monocular video
- **Code**: [https://github.com/xg-chu/GAGAvatar](https://github.com/xg-chu/GAGAvatar)

### GaussianHand
- **arXiv**: [2410.08840](https://arxiv.org/abs/2410.08840)
- **Venue**: NeurIPS 2024
- **Year**: 2024
- **Category**: Human & Avatar Methods
- **Core Innovation**: Interaction-aware 3DGS for one-shot hand avatars
- **Code**: [https://github.com/XuanHuang0/GuassianHand](https://github.com/XuanHuang0/GuassianHand)

### GS-Avatar
- **arXiv**: [2311.18159](https://arxiv.org/abs/2311.18159)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Human & Avatar Methods
- **Core Innovation**: Animatable 3DGS avatar from monocular video with pose-dependent Gaussian deformation
- **Code**: [https://github.com/mikeqzy/GS-Avatar](https://github.com/mikeqzy/GS-Avatar)

### HeadGaS
- **arXiv**: [2312.02902](https://arxiv.org/abs/2312.02902)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Human & Avatar Methods
- **Core Innovation**: Dynamic head GS with blendshape-driven Gaussian deformation for real-time reenactment

### BAGS
- **arXiv**: [2403.14166](https://arxiv.org/abs/2403.14166)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Human & Avatar Methods
- **Core Innovation**: Body-Aligned Gaussian Splatting with SMPL-guided Gaussian anchoring for human reconstruction

### GauHuman
- **arXiv**: [2403.16095](https://arxiv.org/abs/2403.16095)
- **Venue**: ECCV 2024
- **Year**: 2024
- **Category**: Human & Avatar Methods
- **Core Innovation**: Human-specific GS with SMPL-constrained Gaussian initialization and pose-aware densification

### 3DGS-Avatar
- **arXiv**: [2310.08529](https://arxiv.org/abs/2310.08529)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Human & Avatar Methods
- **Core Innovation**: Deformable 3DGS for animatable human avatars with pose-conditioned Gaussian deformation
- **Code**: [https://github.com/mikeqzy/3DGS-Avatar](https://github.com/mikeqzy/3DGS-Avatar)

### SplatArmor
- **arXiv**: [2311.13681](https://arxiv.org/abs/2311.13681)
- **Venue**: CVPR 2024
- **Year**: 2024
- **Category**: Human & Avatar Methods
- **Core Innovation**: LBS-based articulated Gaussian Splatting for human body with twist-aware deformation

### GaussianAvatars-2
- **arXiv**: [2412.07739](https://arxiv.org/abs/2412.07739)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Human & Avatar Methods
- **Core Innovation**: Second-generation Gaussian avatars with FLAME-aligned Gaussian anchoring

### SplatPose
- **arXiv**: [2412.09511](https://arxiv.org/abs/2412.09511)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Human & Avatar Methods
- **Core Innovation**: Pose-conditioned Gaussian Splatting for monocular human reconstruction

### GaussianHands-2
- **arXiv**: [2412.09606](https://arxiv.org/abs/2412.09606)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Human & Avatar Methods
- **Core Innovation**: Hand avatar GS with cross-attention feature blending for dexterous manipulation

### X-Gaussian
- **arXiv**: [2412.09723](https://arxiv.org/abs/2412.09723)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Human & Avatar Methods
- **Core Innovation**: Expressive full-body Gaussian avatar from monocular video with LBS-based deformation

### GaussianTalker
- **arXiv**: [2412.09982](https://arxiv.org/abs/2412.09982)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Human & Avatar Methods
- **Core Innovation**: Audio-driven Gaussian talking head with facial prior and emotion control

### SplatFace
- **arXiv**: [2412.10209](https://arxiv.org/abs/2412.10209)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Human & Avatar Methods
- **Core Innovation**: Face-specific GS with identity-preserving Gaussian anchoring from single image

### GaussianBody
- **arXiv**: [2412.10972](https://arxiv.org/abs/2412.10972)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Human & Avatar Methods
- **Core Innovation**: SMPL-X aligned Gaussian body with part-aware densification

### GauHuman-v2
- **arXiv**: [2503.24210](https://arxiv.org/abs/2503.24210)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Human & Avatar Methods
- **Core Innovation**: Second-generation human GS with improved SMPL-guided Gaussian binding

### SplatTalk
- **arXiv**: [2503.24382](https://arxiv.org/abs/2503.24382)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Human & Avatar Methods
- **Core Innovation**: Audio-driven 3D talking face GS with emotion and style control

### SplatPose2
- **arXiv**: [2504.13167](https://arxiv.org/abs/2504.13167)
- **Venue**: CVPR 2025
- **Year**: 2025
- **Category**: Human & Avatar Methods
- **Core Innovation**: Enhanced pose-conditioned GS with part-level deformation


### Cross-Domain / Benchmark
### 3DReflecNet
- **arXiv**: [2605.10204](https://arxiv.org/abs/2605.10204)
- **Venue**: CVPR 2026
- **Year**: 2026
- **Category**: Cross-Domain / Benchmark
- **Core Innovation**: Systematic benchmark for reflective/transparent 3D reconstruction; identifies 3 catastrophic failure modes in NeRF/3DGS for specular and transparent objects
## Newly Added Methods (July 26, 2026 Update)

### Semantic / Editing (New Additions)
- **3D-GIMP** [arXiv:2607.20789](https://arxiv.org/abs/2607.20789) (arXiv 2026)
  - **Core**: 3DGS inpainting + PatchMatch hybrid
  - **Key Innovation**: Single generative inpainting on key view then PatchMatch-based propagation to full 3D scene; combines generative quality with geometric consistency
  - **Links**: [arXiv](https://arxiv.org/abs/2607.20789)

- **LB-Edit** [arXiv:2607.19777](https://arxiv.org/abs/2607.19777) (arXiv 2026)
  - **Core**: Attention-guided editing camera placement + multi-view attention alignment
  - **Key Innovation**: ACP selects optimal viewpoints for editing instructions; MAA ensures multi-view consistency of edits; 5 views sufficient, 7x lower latency than prior methods
  - **Links**: [arXiv](https://arxiv.org/abs/2607.19777)

- **ZeroSplat** [arXiv:2607.18801](https://arxiv.org/abs/2607.18801) (ECCV 2026)
  - **Core**: Generalized referring 3DGS segmentation (GR3DGS)
  - **Key Innovation**: Zero-feature, training-free approach to 3DGS segmentation; supports 0-shot, 1-shot, and N-shot target specification; refers to arbitrary targets without category-specific training
  - **Links**: [arXiv](https://arxiv.org/abs/2607.18801)
## Newly Added Methods (September 2026)

> 13 methods added from arXiv daily scan (859 → 872). All arXiv-verified; method names self-stated in title/abstract per R9.

### Compression & Streaming
- **CRP-GS** [arXiv:2609.23005](https://arxiv.org/abs/2609.23005) (arXiv 2026) — Rate-distortion optimized 3DGS compression using cross-representation priors for anchor-level entropy modeling.

### Cross-Domain
- **LINGO** [arXiv:2609.22849](https://arxiv.org/abs/2609.22849) (arXiv 2026) — Latent initialization and gradient optimization framework for sparse-view X-ray novel-view synthesis and CT reconstruction with 3DGS.

### Dynamic & 4D
- **4DGS-Fixer** [arXiv:2609.21176](https://arxiv.org/abs/2609.21176) (arXiv 2026) — Generative sparse-view 4D Gaussian Splatting with iterative refinement guided by video diffusion priors.

### Embodied AI & Robotics
- **Splat-CBF** [arXiv:2609.23100](https://arxiv.org/abs/2609.23100) (arXiv 2026) — Risk-aware control barrier function for safe next-best-view control in 3D Gaussian-Splat maps.
- **SemSafe-3DGS** [arXiv:2609.19330](https://arxiv.org/abs/2609.19330) (arXiv 2026) — Semantic risk-aware safe-active perception navigation framework in attributed 3D Gaussian maps.

### Feed-Forward
- **GrapeSplat** [arXiv:2609.23182](https://arxiv.org/abs/2609.23182) (arXiv 2026) — Pose-free feed-forward 3DGS that amalgamates multi-view cues into a voxel-aligned representation and decodes Gaussians without per-scene optimization.
- **PhGS** [arXiv:2609.20623](https://arxiv.org/abs/2609.20623) (arXiv 2026) — Post-hoc pruning and recurrent refinement pipeline that compacts single-view feed-forward 3DGS without retraining the base model.

### Language & Semantic
- **NormLift** [arXiv:2609.18898](https://arxiv.org/abs/2609.18898) (arXiv 2026) — 3D-side feature lifting formulating per-Gaussian assignment as cosine alignment for semantically reliable Gaussians.

### Large-Scale
- **VDGS** [arXiv:2609.23049](https://arxiv.org/abs/2609.23049) (arXiv 2026) — Visibility-driven large-scale aerial 3DGS reconstruction framework reducing memory and uneven viewpoint coverage from UAV capture.

### Sparse-View
- **D3GS** [arXiv:2609.22941](https://arxiv.org/abs/2609.22941) (arXiv 2026) — Depth-DINO-Diffusion co-guided sparse-view 3DGS framework jointly enhancing geometry and appearance.

### Surface & Rendering
- **LiteTex-GS** [arXiv:2609.23380](https://arxiv.org/abs/2609.23380) (arXiv 2026) — Lightweight texturing for Gaussian Splatting that attaches texture maps to primitives to reduce memory and optimization cost of high-frequency details.
- **2D GauSS-MI** [arXiv:2609.21516](https://arxiv.org/abs/2609.21516) (arXiv 2026) — Efficient active scene reconstruction on 2DGS with online mapping and a probabilistic reliability model for view selection.
- **RGS (Reflection)** [arXiv:2609.19421](https://arxiv.org/abs/2609.19421) (arXiv 2026) — Physically-based deferred rendering for reflection-aware Gaussian Splatting, modeling specular regions on reflective objects.

