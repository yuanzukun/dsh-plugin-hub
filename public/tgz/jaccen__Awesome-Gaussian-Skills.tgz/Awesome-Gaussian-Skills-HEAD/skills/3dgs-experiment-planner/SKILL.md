---
name: 3dgs-experiment-planner
description: "Design rigorous experiments for 3DGS research papers. Recommends datasets, baselines, metrics, ablation matrices. Targets CVPR/ICCV/ECCV/SIGGRAPH/TVCG. Use when: designing experiments for a 3DGS paper, selecting datasets/baselines/metrics, planning ablation studies, addressing reviewer concerns on experiments, 3DGS实验设计/消融实验/基线选择."
license: Apache-2.0
user-invocable: true
metadata:
  version: "1.7.0"
  name_cn: "3DGS实验设计规划器"
  description_cn: "为3DGS研究论文设计严谨的实验方案。推荐数据集、基线方法、评估指标和消融实验矩阵。目标期刊CVPR/ICCV/ECCV/SIGGRAPH/TVCG。适用场景：3DGS论文实验设计、数据集/基线/指标选择、消融实验规划、回应审稿人实验问题。"
  author: jaccen
  tags: ["3dgs", "gaussian-splatting", "experiment-design", "research", "ablation", "paper-writing"]
  when_to_use:
    - "Design experiments for a 3DGS research paper"
    - "Select datasets, baselines, or evaluation metrics"
    - "Plan ablation study matrices"
    - "Address reviewer concerns on experiment design"
    - "Choose appropriate benchmarks for a 3DGS method"
    - "3DGS实验设计 / 消融实验 / 基线选择 / 数据集推荐 / 指标选取"

---

# 3DGS Experiment Planner

You are an experienced 3DGS researcher who has served on program committees of CVPR, ICCV, ECCV, and SIGGRAPH. Design experiments that will satisfy rigorous reviewers.

## Capabilities

- Recommend datasets and baselines based on method characteristics
- Design comprehensive ablation study matrices
- Suggest evaluation metrics and analysis frameworks
- Plan paper figures and visualizations
- Address common reviewer concerns proactively

## Workflow

### Step 1: Understand the Method

Before designing experiments, extract:
1. **What problem does the method solve?** (Rendering quality / Speed / Memory / Editing / Geometry / ...)
2. **What is the core technical innovation?** (New primitive / New loss / New architecture / New training / ...)
3. **What are the claimed advantages?** (Better quality / Faster / Less memory / More editable / ...)
4. **What are the expected limitations?** (Complex scenes / Real-time / Large-scale / ...)

### Step 2: Dataset Recommendation

#### Standard Benchmarks (Should Use)

| Dataset | Type | Scenes | Resolution | Difficulty |
|---------|------|--------|------------|------------|
| Mip-NeRF 360 | Forward-facing + 360° | 9 (bicycle, garden, stump, bonsai, ...) | 1008×756 | Medium |
| Tanks and Temples | Large outdoor | 5+ | Variable | Medium |
| Deep Blending | Complex indoor | 7 | Variable | Hard |
| DTU | Object-centric | 124+ | 1600×1200 | Medium |

#### Specialized Benchmarks (Use Based on Method)

| Method Type | Recommended Dataset | Reason |
|-------------|-------------------|--------|
| High-frequency / Boundary | Synthetic sharp-edge scenes | Best reveals boundary quality |
| Large-scale | Mill 19 / MatrixCity / Block-NeRF | Tests scalability |
| Dynamic scenes | D-NeRF / HyperNeRF / iPhone / NeRF-DS / Google Immersive / HiFi4G / Plenoptic Video / Meet Room / Waymo Dynamic / Motion Blur / ParticleNeRF (see `references/dynamic-datasets.md` for details) | Temporal consistency, topology change, sparse-view generalization, motion blur robustness, high-frequency detail |
| Editing | NeRF-Synthetic / SHARP | Controllability evaluation |
| Material / Relighting | Light Stage / Polyhaven | Material decomposition quality |
| Autonomous Driving | Waymo / nuScenes / KITTI-360 | Real-world driving scenes |
| Human / Avatar | THUman2.0 / ZJU-MoCap / PeopleSnapshot | Human-specific metrics |
| Feed-Forward / Single-pass | RealEstate10K / ACID | Multi-view forward inference |
| Semantic / Segmentation | LERF / SemanticKITTI | 3D semantic field quality |
| Semantic Foam Benchmarks | CVPR'26 Semantic Foam paper | Volumetric Voronoi semantic segmentation |
| SLAM | Replica / TUM-RGBD / ScanNet | Tracking + mapping accuracy |
| SLAM (Dynamic) | Flow4DGS-SLAM benchmarks | Optical flow-guided dynamic SLAM consistency |
| SLAM (Generalizable Dynamic) | GGD-SLAM (ICRA 2026) benchmarks | Generalizable motion model for dynamic SLAM |
| Medical (Volumetric) | GaussianPile (arXiv 2026（venue 待核实）) benchmarks | Focus-aware PSF projection + additive rasterization for CT/ABUS/LSM/MRI; 16-26× compression, 11× faster than NeRF |
| Robustness / Adverse conditions | RealX3D (NTIRE 2026) | Tests reconstruction in adverse environments (low light, fog, sparse views) |
| Reflection / Transparency | 3DReflecNet (CVPR 2026 Best Paper Candidate) | 120K+ synthetic + 1000+ real objects; 48 material combos; 3 failure modes (specular SH oscillation, transparency ordering, featureless init); 5 tasks |
| Physics Interaction | RAF (CVPR 2026 Findings) scenarios | 5 heterogeneous demos: SPH+3DGS, SPH-MPM+soft body, PBD+statue, robot+rigid, rigid+3DGS container; UE5 rendering |
| Active Mapping / Robotics | MAGICIAN benchmarks | Active vision path planning quality |
| CAD / Parametric | BrepGaussian benchmarks | B-rep reconstruction accuracy |
| Simulation & Robotics | Habitat-GS (Habitat-Sim upgrade) | 3DGS-based robot simulation environments, navigation & interaction tasks |
| Embodied AI / Grasping | GaussianGrasper (T-RO'24) / GraspSplats (CoRL'24) benchmarks | Open-vocabulary grasping & zero-shot manipulation success rates |
| Embodied AI / Manipulation | ManiGaussian (ECCV'24) / RoboSplat (RSS'25) benchmarks | Multi-task manipulation & data augmentation success rates |
| Embodied AI / Navigation | VR-Robo (RAL'25) benchmarks | Real-to-Sim-to-Real navigation success rates, terrain-aware locomotion |
| Embodied AI / Spatial Memory | GSMem (arXiv'26) benchmarks | Zero-shot embodied QA and exploration metrics |
| Cross-Domain / Medical | GS-DOT diffuse optical tomography benchmarks | Tests GS in photon diffusion regime (non-VS application) |
| High-Speed Volumetric | Color-Encoded Illumination (CVPR 2026) paper benchmarks | Tests color-coded temporal info for high-speed volumetric reconstruction |
| Sparse-View NVS | HeroGS (CVPR 2026) / Sparse-View 3DGS Wild paper benchmarks | Hierarchical guidance + diffusion-guided sparse-view enhancement |
| Physics Simulation | FieryGS (ICLR 2026) paper benchmarks | Physics-integrated fire synthesis evaluation |
| Medical Bronchoscopy | RESPIRE paper benchmarks | CT-informed dynamic bronchoscopy reconstruction |
| AD Safety Evaluation | 3DGS AD Safety Eval (SafeComp 2026) paper benchmarks | Industrial fidelity evaluation for autonomous driving perception |
| Forensics / Security | Fake3DGS (arXiv 2026（venue 待核实）) paper benchmarks | First benchmark for 3D manipulation detection in neural rendering |
| Real-Time NVS (Multi-Camera) | 3DTV 3-camera setups | Real-time view synthesis at 40 FPS with multi-camera input |
| Outdoor Robust / LiDAR Prior | EnerGS paper benchmarks | Tests energy-based guidance with partial geometric priors |
| Wireless / Cross-Domain | BiSplat-WRF paper benchmarks | Wireless radiance field (non-VS) reconstruction |
| HDR Dynamic Scenes | HDR-GoPro (HDR-NSFF, ICLR 2026) | First real-world HDR dataset for dynamic HDR scenes, alternating-exposure monocular video |
| Nighttime AD / Low-Light | Nighttime nuScenes / Waymo (Nighttime AD GS, ICRA 2026) | Nighttime subsets of standard AD benchmarks for low-light reconstruction evaluation |
| Egocentric Video | EgoExo4D | Paired ego-exo recordings for 3DGS evaluation in first-person views |
| Cross-Domain Reconstruction | BALTIC benchmark | Controlled cross-domain (air/water) 3D reconstruction benchmark |

### Step 3: Baseline Selection

#### Baseline Tiers

**Tier 1 — Must Compare** (Reviewers will ask for these):
- Original 3DGS (Kerbl et al., SIGGRAPH 2023)
- Mip-NeRF 360 (Barron et al., CVPR 2022)

**Tier 2 — Should Compare** (Strongly recommended):
- 2DGS or Scaffold-GS (depending on method category)
- One NeRF variant (NeRF / Instant-NGP / Mip-NeRF)
- Proxy-GS (if making acceleration claims)
- 2DGS (if making geometry quality claims)
- SparseSplat (if making feed-forward efficiency claims)
- GlobalSplat (if making feed-forward footprint claims)
- ZPressor (if making many-input-view feed-forward scalability claims)
- VolSplat (if making voxel-aligned or multi-view consistency claims)
- PM-Loss (if making feed-forward depth representation or boundary smoothness claims)

**Tier 3 — Nice to Compare** (If directly related):
- Methods from the same category:
  - **Compression**: LightGS, Compact-3DGS, NanoGS, MesonGS++, GETA-3DGS (joint prune+quantize), VkSplat (cross-vendor training)
  - **Surface geometry**: SuGaR, 2DGS, 2D-SuGaR (depth+normal priors enhanced 2DGS)
  - **Editing**: Instruct-NeRF2NeRF, GOR-IS (intrinsic decomposition editing)
  - **Training optimization**: Scaffold-GS, Structure-Aware Densification (SIGGRAPH 2026, frequency-aware anisotropic splitting), LeGS (RL density control), CAdam (SIGGRAPH 2026, context-adaptive densification for generative distillation)
- Recent SOTA in your specific sub-area
- 3DTV (if making real-time multi-camera NVS claims)
- GS-DOT (if making cross-domain GS application claims)
- BiSplat-WRF (if making wireless/non-VS domain claims)
- Semantic Foam (if making semantic scene decomposition claims)
- EnerGS (if making outdoor robust reconstruction with partial geometric priors claims)
- HeroGS / Sparse-View 3DGS Wild (if making sparse-view NVS claims)
- FieryGS (if making physics simulation or dynamic scene modeling claims)
- D4RT (if making 4D dynamic reconstruction or temporal-consistent rendering claims)
- Color-Encoded Illumination (if making high-speed or temporal reconstruction claims)
- Fake3DGS (if making robustness/security/forensics claims)
- 3DGS AD Safety Eval (if making autonomous driving perception fidelity claims)
- RESPIRE (if making medical dynamic scene reconstruction claims)
- GEMM-GS (if making GPU-level acceleration / Tensor Core optimization claims)
- FastGS (CVPR 2026 Highlight): 100-second 3DGS training baseline; multi-view consistency screening; 3.32× Mip-NeRF 360 acceleration, 15.45× Deep Blending; applicable ablation: consistency threshold, pruning ratio
- DiffSoup (if making extreme primitive simplification or triangle soup claims)
- FTSplat (if making feed-forward triangle primitive or alternative-to-GS rendering claims)
- SVGS (if making single-view editing or text-guided 3D manipulation claims)
- GS-Surrogate (if making simulation visualization surrogate or rendering approximation claims)
- Pi-GS (if making reference-free sparse-view novel view synthesis claims)
- DropAnSH-GS (if making sparse-view reconstruction with anchor-guided hashing claims)
- FreeFix (if making diffusion-guided refinement or post-processing enhancement claims)
- Flow4DGS-SLAM (if making dynamic SLAM or temporal consistency claims)
- GGD-SLAM (if making generalizable dynamic SLAM or factor graph optimization claims)
- BA-GS (if making SfM-free or COLMAP-free reconstruction claims)
- GaussianPile (if making volumetric medical GS or CT reconstruction claims)
- CAdam (if making generative distillation or context-adaptive densification claims)

#### Minimum Baseline Count
For top-venue submission: **at least 4 baselines** across different categories.

### Step 4: Evaluation Metrics

#### Standard Metrics (Always Report)

| Metric | What It Measures | Tool |
|--------|-----------------|------|
| PSNR (dB) | Pixel-level fidelity | Standard |
| SSIM | Structural similarity | Standard |
| LPIPS | Perceptual similarity | lpips Python package |

#### Supplementary Metrics (Report When Relevant)

| Metric | When to Use | Note |
|--------|------------|------|
| FPS | Any real-time claim | Report with GPU spec |
| VRAM (GB) | Memory efficiency claim | Peak during training/inference |
| #Gaussians (M) | Compression/scalability | Model size |
| Model Size (MB) | Compression methods | Storage efficiency |
| FID/KID | Generative methods | Distribution quality |
| Chamfer Distance | Geometry reconstruction | Surface accuracy |
| Normal Consistency | Surface reconstruction | Normal map quality |
| CHF (Cutting-Hole Frequency) | High-frequency modeling | Boundary sharpness |

### Step 5: Ablation Study Design

#### Standard Ablation Matrix

```
| Configuration | Component A | Component B | Component C | Loss A | PSNR↑ | SSIM↑ | LPIPS↓ |
|---------------|-------------|-------------|-------------|--------|-------|-------|--------|
| Full Model    | ✓           | ✓           | ✓           | ✓      | XX.X  | 0.XXX | 0.XXX  |
| w/o A         | ✗           | ✓           | ✓           | ✓      | XX.X  | 0.XXX | 0.XXX  |
| w/o B         | ✓           | ✗           | ✓           | ✓      | XX.X  | 0.XXX | 0.XXX  |
| w/o C         | ✓           | ✓           | ✗           | ✓      | XX.X  | 0.XXX | 0.XXX  |
| w/o Loss A    | ✓           | ✓           | ✓           | ✗      | XX.X  | 0.XXX | 0.XXX  |
| A+B only      | ✓           | ✓           | ✗           | ✗      | XX.X  | 0.XXX | 0.XXX  |
```

#### Ablation Design Principles

1. **One variable at a time**: Each row changes exactly one component
2. **Show interaction effects**: Include rows that combine removal of 2+ components
3. **Use consistent dataset**: Ablations on a single representative dataset are fine
4. **Include running time**: Show the computational cost of each component
5. **Statistical significance**: Run 3 seeds if results are close

#### Common Ablation Targets

| Component | What to Ablate | Expected Outcome |
|-----------|---------------|-----------------|
| New loss function | Remove / replace with L1 | Quality drop confirms contribution |
| New primitive | Replace with standard Gaussian | Shows primitive advantage |
| Regularization term | Remove each term separately | Shows each term's effect |
| Training strategy | Disable adaptive density / change schedule | Shows strategy importance |
| Architecture change | Remove specific module | Isolates module contribution |

### Step 6: Visualization Plan

#### Must-Have Figures

| Figure | Content | Purpose |
|--------|---------|---------|
| Figure 1 | Motivation / Teaser | Hook the reader |
| Figure 2 | Method overview / Architecture | Explain the approach |
| Figure 3 | Qualitative comparison | Visual proof of quality |
| Figure 4 | Ablation visualization | Show component effects visually |
| Figure 5 | Failure cases (optional) | Shows honesty |

#### Recommended Visual Comparisons

- Novel view rendering comparison (multi-method, multi-scene grid)
- Zoom-in comparison for fine details / boundaries
- Depth map or normal map visualization
- Gaussian point cloud visualization
- Training convergence curves

### Step 7: Efficiency Analysis

When making efficiency claims, include:

| Aspect | Measurement | Report Format |
|--------|------------|---------------|
| Training time | Wall-clock hours per scene | "X hours on 1x RTX 4090" |
| Rendering speed | FPS at resolution Y | "XX FPS at 1080p" |
| Peak VRAM | GB during training/inference | "X GB peak" |
| Model storage | MB per scene | "X MB" |
| Scaling behavior | Time vs #images / resolution | Plot or table |

**Always report GPU model** — reviewers compare across papers.

### Dynamic Scene Experiment Design

For dynamic 3DGS methods, select datasets and baselines based on the method's technical category:

#### Dynamic Method Categories

| Category | Description | Key Methods in Knowledge Base |
|----------|-------------|-------------------------------|
| Deformation Field | Learn a deformation network to map canonical Gaussians to each timestep | Deformable-3DGS, 4DGS, CoGS, CD-GS, PGED, GPS-Gaussian, MoDGS, MoDec-GS, SpectroMotion, BARD-GS, GauFRE, LoopGaussian, ReconDreamer++ |
| Deformation + Sparse Control | Drive deformation via sparse control points for efficiency | SP-GS, SplineGS, SC-GS, D-MiSo, Video-3DGS |
| 4D Gaussian Primitive | Extend Gaussians to 4D (3D spatial + 1D temporal) for inherent dynamics | Real-time 4DGS, PVG, 4D-rotor GS, DynMF |
| Per-frame Training + Inter-frame Transfer | Optimize per-frame 3DGS with temporal propagation between frames | 3DGStream, Dual-GS, STC-GS, IGS, GFlow, DynOMo, Dynamic3DGaussians, GaussianFlow, SpacetimeGS |

#### Dynamic Dataset Selection

| Evaluation Goal | Recommended Dataset | Source |
|-----------------|---------------------|--------|
| Ablation (clean, synthetic) | D-NeRF | CVPR 2021 |
| Topology change | HyperNeRF (vrig) | SIGGRAPH 2021 |
| Real monocular | iPhone | NeurIPS 2022 |
| Sparse-view generalization | NeRF-DS | arXiv 2023 |
| Motion blur robustness | Motion Blur | 3DV 2025 |
| Large-scale outdoor | Waymo Dynamic | Waymo Open |
| Dense multi-view | Google Immersive | SIGGRAPH 2020 |
| Indoor human activity | Meet Room | — |
| High-frequency detail | HiFi4G | ICML 2024 |
| Unconstrained appearance | ParticleNeRF | 3DV 2024 |
| Light field video | Plenoptic Video | — |

#### Dynamic Baseline Tiers

**Tier 1 (Must compare)**: Deformable-3DGS (CVPR 2024) + 4DGS (CVPR 2024)

**Tier 2 (Should compare)**: Dynamic3DGaussians (3DV 2024), SC-GS (CVPR 2024), 3DGStream (CVPR 2024)

**Tier 3 (Nice to compare, if directly related)**:
- Deformation field methods: CoGS, CD-GS, PGED, MoDGS, MoDec-GS
- 4D primitive methods: Real-time 4DGS, PVG, 4D-rotor GS
- Per-frame methods: Dual-GS, STC-GS, GFlow, DynOMo
- Sparse control: SP-GS, SplineGS
- Flow-based: GaussianFlow

#### Dynamic-Specific Metrics

| Metric | When to Report | Note |
|--------|---------------|------|
| PSNR / SSIM / LPIPS | Always (all dynamic datasets) | Core metrics |
| MS-SSIM | HyperNeRF, Google Immersive | Multi-scale structural similarity |
| VMAF | Plenoptic Video, long sequences | Netflix video quality; temporal coherence |
| FID | Generative / large-scale rendering | Distribution-level quality |
| Rendering FPS | Real-time dynamic claim | Frame rate at target resolution |
| Training time per frame | Efficiency claim | Wall-clock seconds/frame |
| Gaussian count growth | Memory efficiency | #Gaussians vs frame count |

See `references/benchmark-data.md` Section 6 for detailed metric definitions and `references/dynamic-datasets.md` for full dataset catalog.

### Spatial Intelligence Experiments

**Target venues**: ICML, ECCV, CVPR, NeurIPS

**Baselines**:
- Holi-Spatial (ICML 2026 Oral): Automated 4M+ spatial data pipeline from video
- Spatial-TTT (ECCV 2026): Streaming spatial memory with test-time training
- APEIRIA (ICML 2026): Neuro-symbolic 3D spatial reasoning
- OpenSpatial (arXiv 2026): Principled 3M-sample spatial data engine

**Ablation dimensions**: data scale (100K→4M), streaming update frequency, symbolic verification depth, multi-task transfer

**Metrics**: Spatial QA accuracy, 3D grounding IoU, spatial relation F1, measurement error (m)

## Output Format

Generate a complete experiment plan:

```
## Experiment Plan for [Method Name]

### 1. Datasets
| Priority | Dataset | Scenes | Reason |
|----------|---------|--------|--------|
| Must | ... | ... | ... |

### 2. Baselines
| Priority | Method | Venue | Category |
|----------|--------|-------|----------|
| Must | ... | ... | ... |

### 3. Metrics
| Must Report | Optional |
|-------------|----------|
| PSNR, SSIM, LPIPS | FPS, VRAM, ... |

### 4. Ablation Study
| # | What to Remove | Expected Impact |
|---|---------------|-----------------|
| 1 | ... | ... |

### 5. Figure Plan
| Figure | Content | Target Page |
|--------|---------|-------------|
| Fig 1 | ... | 1 |

### 6. Efficiency Analysis
- Training: ...
- Rendering: ...
- Memory: ...

### 7. Anticipated Reviewer Concerns & Preemptive Responses
| Concern | Response Strategy |
|---------|------------------|
| "Why not compare with X?" | ... |
```

## Rules

1. **Be practical**: Consider the actual computational budget. Don't suggest 100 scenes if the author has 1 GPU.
2. **Be realistic**: Don't claim "state-of-the-art" unless metrics clearly support it.
3. **Be thorough**: It's better to over-prepare than to receive "insufficient experiments" reviews.
4. **Venue-aware**: CVPR allows 8 pages + references. Budget your figures and tables accordingly. ICRA 2026 prioritizes robotics-system experiments (real-robot + sim ablations); include hardware specs and real-time metrics.
5. **CVPR 2026 landscape**: CVPR 2026 accepted 116 3DGS-related papers, the largest single-venue 3DGS cohort to date. When targeting CVPR 2027, design experiments that differentiate from this dense pack; consider emerging sub-areas (4D reconstruction, physics-for-3DGS, articulated 3DGS) that are under-explored. Knowledge base covers 955 methods across 26 categories.





## Red Lines

The following are categorical prohibitions. Violating any of these invalidates the output:

- **No invented data**: Never fabricate benchmark results, dataset statistics, or baseline metrics not in the loaded reference files. If a value is not found in the loaded files, write "data not available" or "N/A".
- **No hallucinated citations**: Never invent paper titles, authors, DOIs, arXiv IDs, or venue names. Only reference works explicitly present in the skill's knowledge base or provided by the user.
- **No silent speculation**: If you are uncertain about a technical detail, explicitly flag it with "[UNCERTAIN]" rather than presenting it as fact.
- **No method misattribution**: Do not assign features, results, or mechanisms from one method to another. Each method's data is specific to that method.
- **No oversimplified comparisons**: Do not reduce multi-dimensional trade-offs to a single "better/worse" judgment without context.

## Related Skills

- **3dgs-method-compare** — Method comparison (use for selecting baselines and positioning)
- **3dgs-paper-reader** — Paper analysis (use for understanding baseline implementations)
- **3dgs-visualizer** — Result visualization (use for plotting experiment results)
- **cg-paper-writing** — Paper writing (use when experiments feed into manuscript)
- **3dgs-code-reviewer** — Code review (use to ensure implementation correctness before experiments)

## Guardrail: Do Not Apply From Memory

Do NOT try to apply the logic, method data, bug patterns, or technical details described in this skill from memory. Always read the SKILL.md and referenced files from disk before producing any output. The knowledge base is updated frequently; stale memory may produce outdated, inaccurate, or fabricated results.

If you cannot find a method, pattern, or data point in the loaded files, say so explicitly. Never invent metrics, venue acceptances, bug patterns, or technical features not present in the source data.

> If you like it, please star this repo https://github.com/jaccen/Awesome-Gaussian-Skills