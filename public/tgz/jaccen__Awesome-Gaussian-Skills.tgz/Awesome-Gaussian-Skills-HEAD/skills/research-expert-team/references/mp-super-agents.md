# Master Paper Studies — Super Agents & Agentic AI 方向

> **定位**：本文件是**案例证据库**——两篇标杆论文的全文深读解剖，为 `methodology-core.md` 中的可执行程序提供出处与佐证。方法论本体（选题引擎/论述骨架/实验模式/审稿预期）见 `methodology-core.md`，不在此重复；写多智能体/智能体系统方向的论文前，按需查阅本文追根溯源。
> **事实口径**：引用数为 Semantic Scholar 2026-10 检索值；方法事实取自 arXiv 全文（ar5iv 深读），每条均可回查。

| 论文 | 载体 | arXiv | 引用 | 角色定位 |
|---|---|---|---|---|
| ReAct: Synergizing Reasoning and Acting in Language Models | **ICLR 2023** | 2210.03629 | **12,540** | 极简范式论文的天花板（一个 idea 如何写出传世论文） |
| MetaGPT: Meta Programming for a Multi-Agent Collaborative Framework | **ICLR 2024 Oral** | 2308.00352 | 2,626 | 人类实践移植论文范式（SOP→多智能体） |
| Toolformer: Language Models Can Teach Themselves to Use Tools | **NeurIPS 2023** | 2302.04761 | 6,146 | 自监督数据自举范式（悖论开题+损失差过滤） |
| Generative Agents: Interactive Simulacra of Human Behavior | **UIST 2023** | 2304.03442 | 5,987 | 记忆架构论文 + 无 GT 人工评测协议（interview） |
| Voyager: An Open-Ended Embodied Agent with Large Language Models | **TMLR 2024** | 2305.16291 | 2,622 | 终身学习 agent 范式（技能库+自动课程+代码即行动） |

---

## 1. ReAct（ICLR 2023）——极简范式论文的天花板

### 1.1 选题解剖

- **组合缺口而非新任务**：不用发明新任务，而是发现两个**已被分别证明的能力**从未被组合——CoT 推理（Wei 2022，静态黑盒、幻觉、错误传播）与行动生成（SayCan/Inner Monologue，无抽象推理、无工作记忆）。组合缺口 = 两侧文献都已成熟 + 组合本身未被探索 = 风险最低、时效最高的选题。
- **认知科学锚点**：开篇引 inner speech / Vygotsky / Baddeley 工作记忆——用一个厨房做饭的日常例子（"盐没了→用酱油胡椒替代"）把"推理与行动交织"讲给任何人听。**人类类比既是动机也是命名来源**（ReAct = Reason + Act）。
- **一句话方法**：把动作空间扩展进语言空间 Â = A ∪ L——thought 是"不影响外部环境的动作"。数学量最小化、概念收益最大化，这是范式论文的标志性结构。
- **时机**：PaLM-540B 刚展现 in-context 能力、ALFWorld/WebShop 基准刚建立——方法、算力、基准三者同时就绪。

### 1.2 论述解剖

- **摘要公式**：能力分立现状（2 句）→ 交织机制（2 句）→ 双域实证 + 头条数字（"1-2 个上下文示例击败 10³⁻⁵ 训练样本的 IL/RL，+34% 成功率"）→ 附加收益（可解释、可信）。
- **四特征清单**：A Intuitive（设计 prompt 无需技巧）/ B General（跨 QA/游戏/网页）/ C Performant（1-6 示例即超基线）/ D Human-aligned（思想可编辑的人机闭环演示）——把"为什么这很重要"预先回答四遍。
- **Figure 1 即论文**：四种 prompting 方法（Standard/CoT/Act-only/ReAct）同题并排，失败模式肉眼可见。范式论文的说服力在图不在表。
- **诚实负结果 → 组合贡献**：prompting 下 ReAct 在 HotpotQA 略输 CoT（27.4 vs 29.4）——不藏，反而分析原因（结构约束降低灵活性）并转化为第二贡献（ReAct→CoT-SC / CoT-SC→ReAct 切换策略，两者互补取最优 35.1）。**负结果写好了是加分项**。
- **微调续章**：3,000 条自举轨迹微调 PaLM-8/62B 后 ReAct 反超全部 prompting 方法——证明轨迹数据比记忆事实更可泛化，把"prompting 技巧"升维成"训练数据范式"。

### 1.3 论文骨架（ICLR 范式论文结构模板）

| 章节 | 功能 | 写作要点 |
|---|---|---|
| Abstract | 能力分立→交织机制→双域数字→可解释收益 | 头条数字（+34%/1-2 shot）放末句 |
| §1 Introduction | 人类类比（inner speech）→两侧文献缺口→ReAct 一句话→四特征 ABCD | Figure 1 四方法并排即全部说服力 |
| §2 ReAct: Synergizing Reasoning + Acting | 形式化（Â = A ∪ L）→ thought 类型学 → 四特征 | 数学量最小化，概念收益最大化 |
| §3 Knowledge-Intensive Reasoning Tasks | HotpotQA/FEVER：设置→方法→基线→组合策略→微调 | §3.3 双段分析：ReAct vs CoT 逐项对比+失败分类表 |
| §4 Decision Making Tasks | ALFWorld/WebShop：基线（IL/RL/IM 风格消融）→头条数字 | ReAct-IM 消融专门驳最近邻 |
| §5 Related Work / §6 Conclusion | 两侧文献各自归位 | 结论同时列局限与出路 |
| Appendix | 全部 prompt+GPT-3 附加结果+伦理声明 | 匿名代码链接保复现 |

### 1.4 实验设计解剖

| 设计决策 | 具体做法 | 可迁移经验 |
|---|---|---|
| **双域互证** | 知识密集任务（HotpotQA/FEVER，证明 act-to-reason）+ 决策任务（ALFWorld/WebShop，证明 reason-to-act） | 论文主张是"协同"→必须在协同的两侧各自取证 |
| **受控消融的天才设计** | Standard/CoT/Act 全部从 ReAct 轨迹**删减**得到（删 thought 删 action 删 obs） | 同一轨迹的不同删减 = 完美受控变量，审稿人无法质疑不对等 |
| **失败模式分类学** | 人工标注 200 条轨迹：CoT 幻觉占失败 56% vs ReAct 0%；假阳性 14% vs 6% | 定量失败分析比成功率表更有说服力——给"为什么"编号 |
| 头条数字设计 | "1-2 shot 击败 10⁵ 专家轨迹训练的 BUTLER（71% vs 37%）" | 找到那个反常识的对比数字放进摘要 |
| 基线尊重 | BUTLER 用 beam search、ReAct 用 greedy 也注明 | 口径透明到报复复现者无话可说 |
| 附加演示 | 人机闭环：人工编辑 thought 纠正 agent 行为 | 每个附加卖点配一个 demo |

### 1.5 价值解剖（12,540 引的构成）

- **命名权**：ReAct 成为智能体循环的标准名——每个框架文档都要教 ReAct 模式；
- **零门槛可复现**：方法 = prompt 格式，任何人 10 分钟上手；
- **接口标准化**：thought-action-observation 三元组成为 agent 框架的原子操作；
- 被引的不再是论文结论，而是论文定义的**词汇本身**——范式论文的终极形态。

### 1.6 可迁移打法

1. 找"两个各自成熟、组合空白"的能力对，组合缺口风险最低；
2. 方法压缩到一句话/一个公式；命名要好念好拼；
3. 摘要末尾放一个反常识头条数字；
4. 主张什么就双域/多域取证什么；
5. 用"同一轨迹删减"构造完美受控消融；
6. 做失败模式分类表（人工标注 + 百分比）；
7. 负结果不藏，转化为组合策略贡献；
8. 附加卖点（可解释/可控）各配一个 demo。

---

## 2. MetaGPT（ICLR 2024 Oral）——把人类实践移植进智能体框架

### 2.1 选题解剖

- **从失败现象出发**：不立抽象框架，先引用现有多智能体的具体病灶——"级联幻觉"（cascading hallucinations from naively chaining LLMs）+ 闲聊空转（原文直接引用角色扮演对话 "Hi, hello and how are you? / Great! Have you had lunch?"）。**用一个可复现的尴尬例子定义问题**，比十句 abstract 更锋利。
- **跨界移植**：答案不在 ML 文献里，而在软件工程管理文献里——SOP（标准作业程序）、Agile Manifesto、Peopleware、Belbin 团队角色理论。把成熟人类实践编码进 prompt 序列 = "Meta Programming"。
- **学术包装**：为"meta-programming"一词挂上 Schmidhuber meta-learning 谱系（"programming to program" vs "learning to learn"），用学术血统对冲"这只是调 prompt"的质疑——**工程味重的想法需要理论谱系包装**。
- **时机**：AutoGPT/CAMEL/ChatDev 群雄混战期（2023），"结构化"是稀缺叙事。

### 2.2 论述解剖

**三贡献（框架论文模板）**：
1. 框架本身（角色定义+消息共享，灵活可扩展的平台）；
2. **SOP 移植**（角色专长+结构化通信+流水线工作流抑制无效协作）+ 可执行反馈机制（运行时调试执行，MBPP +5.4%）；
3. HumanEval/MBPP 双 SoTA（85.9% / 87.7% Pass@1）。

**三大设计叙事**（每个都有类比）：
- **流水线分工**：模拟软件公司五角色（PM→架构师→项目经理→工程师→QA），"assembly line paradigm"；
- **结构化通信**：反对自由对话，交付物必须是文档和图（PRD、接口设计、流程图）——电话游戏类比说明自然语言传话会失真；对比 ChatDev："agents communicate through documents and diagrams rather than dialogue"；
- **发布-订阅消息池**：全局共享消息池 + 按角色订阅，解决一对一通信拓扑爆炸 + 信息过载。

**写作技法**：
- Figure 1 双栏对照：真实软件公司 SOP ↔ MetaGPT 角色流水线——隐喻贯穿全文（结论里再次呼应"模拟公司 vs 模拟小镇 vs Minecraft 沙盒"）；
- 每个机制段都以"观察到的问题→人类怎么做→我们怎么编码"三段式展开；
- 作者贡献附录：14 人团队逐一分工——大团队论文的信誉管理；
- Outlook 独立附录（前瞻讨论），Oral 论文的标配。

### 2.3 论文骨架（ICLR Oral 框架论文结构模板）

| 章节 | 功能 | 写作要点 |
|---|---|---|
| Abstract | 级联幻觉病灶→SOP 编码→流水线→SoTA 数字 | 病灶一句话+方法一句话+硬数字 |
| §1 Introduction | 病灶引用（闲聊对话原句）→人类 SOP→MetaGPT→三贡献 | 隐喻（软件公司）从 Figure 1 起贯穿 |
| §2 Related Work | 自动编程 / 多智能体框架两组 | 每组结尾留缺口句 |
| §3 MetaGPT Framework | 3.1 SOP 角色专长 / 3.2 通信协议（结构化接口+发布订阅）/ 3.3 可执行反馈 | 每机制三段式：问题→人类怎么做→如何编码 |
| §4 Experiments | 双基准 SoTA→自建 SoftwareDev→能力矩阵→角色/反馈双消融 | 多维评价（成本/生产率/人工修正） |
| §5 Conclusion + Appendix | 展望附录+作者贡献附录 | 大团队信誉管理 |

### 2.4 实验设计解剖

| 设计决策 | 具体做法 | 可迁移经验 |
|---|---|---|
| 双公开基准 SoTA | HumanEval 85.9%、MBPP 87.7%（配 GPT-4） | 框架论文需要至少一个"硬数字"锚点 |
| **自建任务级基准** | SoftwareDev：70 个代表性开发任务（小游戏/图像处理/可视化），现有基准测不了整项目开发 | 基准缺口→自建；自建基准成为后续工作的评测标准 |
| **多维评价体系** | 可执行性（1-4 分级）、成本（时间/token/美元）、代码统计、生产率（token/行）、人工修正次数 | "准确性之外"的成本-质量-生产率矩阵是框架论文的差异化实验设计 |
| 能力矩阵表 | vs AutoGPT/LangChain/AgentVerse/ChatDev 逐项 ✓/✗（PRD 生成、接口生成、预编译执行等 8 项） | 功能对比表直接可视化定位 |
| 角色消融 | 逐角色递增（1→4 个角色），可执行性与修正成本同步改善 | 机制消融要能对应到论文声称的每个机制 |
| 反馈消融 | +4.2%/+5.4% Pass@1，人工修正成本 2.25→0.83 | 机制收益要给绝对数字 |
| 诚实成本 | MetaGPT 总 token 更多（31k vs 19k）但 token/行更低（124 vs 249） | 成本劣势换个口径变优势——诚报告+巧口径 |

### 2.5 价值解剖（2,626 引的构成）

- **产业级开源**：DeepWisdom 公司化运营，MetaGPT 成为多智能体框架的事实选项之一；
- "SOP→prompt 序列"的方法论被 AgentVerse/ChatDev 后继者普遍吸收；
- 与 ReAct 的关系是**继承显式化**：明确写"all agents adhere to the ReAct-style behavior"——站在 12K 引巨人的肩膀上并被其引用链带动。

### 2.6 可迁移打法

1. 先用一个可复现的尴尬例子（原句引用）定义问题，再给方案；
2. 答案可以不在 ML 文献里——管理学/认知科学/软件工程的成熟实践都是候选库；
3. 工程味重的想法挂理论谱系（meta-programming ↔ meta-learning）；
4. 隐喻贯穿全文（公司/流水线/电话游戏），Figure 1 做隐喻的可视化；
5. 至少一个公开基准硬数字 + 一个自建任务级基准；
6. 多维评价（成本/生产率/人工修正）与能力矩阵表；
7. 每个机制配消融+绝对数字；
8. 大团队必写作者贡献附录。

---

## 3. Toolformer（NeurIPS 2023）——自监督数据自举范式怎么写

### 3.1 选题解剖

- **悖论开题**：LM 规模化后解决新任务能力惊人，**但基础功能（算术、事实查询、时间感知）反不如小模型**——"especially at scale, they paradoxically struggle with basic functionality"。用悖论代替缺口句：两件事同为真，本身就是最强的问题陈述。
- **双 desiderata 框架**：现有工具学习两族各判刑——大量人工标注（Komeili/Thoppilan）或任务特定 few-shot（Gao/Parisi）。由此立两条设计诉求：①自监督无人工标注——配一句洞察："**人觉得有用的和模型觉得有用的可能不同**"（把“去人工”从成本论并并并成方法优越性论）；②不损失通用性——模型自己决定何时/如何/用哪个工具。
- **数据自举血统**：方法接在 Schick&Schütze 自举训练谱系上（用 LM 生成数据集再自训练）——工程味重的方法挂理论谱系。

### 3.2 论述解剖

- **自举管线即方法**（三步）：采样候选 API 调用（按 <API> token 概率选位置）→ 执行 → **按加权损失差过滤** Li⁻−Li⁺≥τf（"提供调用+结果能否降低未来 token 的损失" vs min(不调用, 调用无结果)）——过滤准则本身就是论文贡献，不是工程细节；权重 w_t=max(0,1−0.2t) 保证调用靠近有用位置。
- **四档基线设计**：GPT-J / GPT-J+CC（同数据无调用微调）/ **Toolformer (disabled)**（禁用调用）/ Toolformer——disabled 档证明"API 调用数据本身也提升了数学能力"（14.8 vs 9.6），把潜在的混浊变量变成额外发现。
- **Table 10 定性样本表**：按过滤分数排序的有用/无用调用实例——准则有效性的直接可视化证据。
- 五个工具（QA/搜索/计算器/日历/翻译）每个给一行 API 输入输出示例——方法的"零门槛感"由表描画。

### 3.3 实验设计解剖

| 设计决策 | 具体做法 | 可迁移经验 |
|---|---|---|
| **反常识头条对比** | 6.7B GPT-J 基座打赢 GPT-3 175B（T-REx 53.5 vs 39.8；三数学基准全胜） | "小模型+工具赢大模型"是效率型论文最传播的对比 |
| **诚实负结果+归因** | TriviaQA 落后 GPT-3，归因于搜索器太简单+**不能交互**（改写查询/浏览多条），并转为 future work | 输了不藏：机制归因+修复路径 |
| **评测卫生** | LAMA 改造（mask 必须在末尾）；宽松判分（前 5 词/第一个数字）；**LAMA 上禁用 WikiSearch、QA 任务禁用 QA 工具防不公平** | 零样本评测的公平性条款必须显式写 |
| **工具使用归因逐任务报告** | T-REx 98.1% 用 QA；TempLAMA calendar 只用 0.2%——并解释为什么（one-call 限制挡住"先查日历再问 QA"的正确策略） | 每个能力主张配“它实际被用了多少次”的归因表 |
| 规模定律实验 | GPT-2（124M/355M/775M/1.6B）→GPT-J：工具使用能力 ~775M 才涌现 | 能力论文补涌现阈值实验，防止“小模型也能做”质疑 |
| 限制节具体化 | 不能链式调用、不能交互式、对措辞敏感、样本效率低（百万文档→几千样本）、决策不计成本 | 限制写到具体机制而非泛泛而谈 |

### 3.4 可迁移打法

1. 悖论开题（两件同为真的事实）比缺口句更锋利；
2. 数据自举：采样→执行→可计算的过滤准则（损失差）→自训练——把数据生产变成方法贡献；
3. 多档基线中加一个 disabled 档，把混浊变量变成发现；
4. “人觉得有用≠模型觉得有用”式的洞察句提升方法立意；
5. 评测公平性条款（禁用某工具防漏题）显式写；
6. 工具使用归因逐任务报告（用了几次、为什么没用）；
7. 规模定律补涌现阈值。

---

## 4. Generative Agents（UIST 2023）——记忆架构与无 GT 人工评测怎么写

### 4.1 选题解剖

- **40 年议程重开**（M3 变体）：believable agents 曾是 HCI/Game AI 的 north star（Oz 项目、Bates 1994、SOAR/ICARUS 认知架构），因“人工编写行为不可持续”被“够用论”搁置——相关工作用一整节重写 40 年史，把 LLM 定位为“重新点火”的材料，而不是新发明。
- **技术缺口具体到机制**：LLM 只能单时间点模拟（social simulacra）；一阶 prompt 无法承载长期一致性——**context window 装不下全部经历**。由此立三组件：memory stream（自然语言全记录）+ 检索三因子 + reflection（递归合成高层推论）+ planning。
- **每个因子都带实现**：recency 指数衰减 0.995 / importance 让 LM 打 1-10 分（完整 prompt 全公开）/ relevance embedding 余弦——机制论文的“可操作密度”。

### 4.2 论述解剖

- **涌现叙事作为 teaser**：情人节派对案例——单种子（Isabella 想办派对）→自主传播邀请→Maria 邀暗恋对象 Klaus→5 人准时到场。“尽管存在大量潜在失败点（可能忘邀请、可能记不住、可能不来）——**它们成功了**”。用“链式成功”证明架构的端到端能力。
- **错误分类学**：检索失败 / 记忆 embellishment（编造细节）/ 从 LM 继承的过度正式语气——三类失败模式成为后续 agent 记忆工作的标准分析框架。
- **措辞卫生**：脚注声明“agents engaging in actions 是可读性简写，**不暗示真实能动性**”（如 Disney 动画）——HCI 论文的严谨性加分。
- 伦理段独立成节：parasocial 风险、deepfake/定向说服（建议日志）、“补充而非替代人类”——HCI venue 的硬要求提前写。

### 4.3 实验设计解剖

| 设计决策 | 具体做法 | 可迁移经验 |
|---|---|---|
| **interview 评测协议** | 用自然语言"采访" agent，测 5 能力：stay in character/remember/plan/react/reflect——新任务无 GT 时的可量化人工评测 | 无 GT 任务的自建协议：把能力拆成可提问的维度，请人类评分 |
| **双评估互补** | controlled（隔离测个体）+ end-to-end（两天游戏时间测稳定性与涌现） | 单独测组件 + 合起来测系统，两层都要 |
| **消融到组件因果** | 限制 memory/reflection/planning 访问的多个变体逐一对比 | 架构论文每个组件都要因果证据 |
| prompt 全公开 | importance 打分、反思、规划的完整 prompt 在附录 | prompt 即方法——不公开无法复现 |
| demo+开源+视频 | Smallville 在线演示 + GitHub | 可交互 demo 是 HCI/系统论文的引用加速器 |

### 4.4 可迁移打法

1. 老议程重开：写一节史前史把前人工作重新组织，把自己定位为接力棒而非发明者；
2. 被搁置议程的“够用论”逐句引用后驳斥；
3. 无 GT 评测自建 interview 协议（能力拆维+人类评分）；
4. 涌现叙事用“单种子→链式成功”的案例作 teaser；
5. 检索/评分/反思每个机制给完整实现（含 prompt）；
6. 措辞卫生（不暗示真实能动性）+伦理段提前写；
7. 错误分类学成为后续工作的分析框架。

---

## 5. Voyager（TMLR）——终身学习 agent 与技能库怎么写

### 5.1 选题解剖

- **对新范式点名判刑**：现有 LLM agent（ReAct/Reflexion/AutoGPT）"**not lifelong learners**"——不能渐进获取、更新、积累、迁移知识。不笼统说“缺终身学习”，而是对每个最近邻给出它缺的具体件：AutoGPT 缺技能库/自验证/自动课程。**缺口分解到机制零件级**。
- **行动空间论证**：为什么用代码而不用低层命令——"程序天然表示时间上扩展的组合动作"；且无需梯度微调（GPT-4 黑盒查询）——两条都 preempt 了“为什么不用 RL/为什么不用微调”的必问。
- **时机**：GPT-4 刚发布且代码能力跃升；Minecraft 无预定义目标=开放世界试金石（环境选择本身就是论证）。

### 5.2 论述解剖

- **三组件各配一张图+完整 prompt**：automatic curriculum（GPT-4 按状态+进度+自问自答提议任务，定位为"in-context novelty search"——挂 Open-endedness 文献谱系）；skill library（可执行代码+embedding 描述索引，"组合复利+抗遗忘"）；iterative prompting（环境反馈/执行错误/自验证三类反馈循环，每类配失败-修复实例图）。
- **评测卫生两段式**：①明确不与像素级方法（VPT/DreamerV3）"apple-to-apple"比——因为用 Mineflayer 高层 API，改为附录系统级对比表；②基线本为 NLP 设计，需 reinterpret 并**给同等信息**（环境反馈+执行错误+自验证都给 AutoGPT/Reflexion）——不公平比较的指控被预先拆掉。

### 5.3 实验设计解剖

| 设计决策 | 具体做法 | 可迁移经验 |
|---|---|---|
| **头条数字三连** | 3.3× 独特物品、2.3× 移动距离、15.3× 科技树解锁（唯一解锁钻石级） | 头条数字选“不同维度的倍数”而非单一指标 |
| **消融带百分比结论** | 换随机课程掉 93%；去 self-verification 掉 73%；GPT-4→3.5 掉 5.7× 物品 | 消融结论量化到百分比，比“显著下降”有说服力 |
| **跨方法组件证据** | AutoGPT + 我们的 skill library 也提升——"plug-and-play 资产" | 把组件交给竞争方法也能提升 = 组件价值的独立证据 |
| 零样本泛化 | 新世界+清库存测未见任务；skill library 迁移后从 0 解题 | 终身学习主张必须配“新环境迁移”实验 |
| 限制节带案例 | Cost（GPT-4 贵 15×）/ Inaccuracies（自验证误判蜘蛛丝）/ Hallucinations（要求合成不存在的“铜剑”、把 cobblestone 当燃料） | 限制写到具体失败案例，可信度不减反增 |
| 人类反馈扩展讨论 | human as critic / human as curriculum 两模式 | 多模态缺失用“人类代位”实验补救并写进正文 |

### 5.4 可迁移打法

1. 对新范式点名判刑时，缺口分解到机制零件级（缺哪个库、哪个验证器、哪个课程）；
2. 行动空间选择（代码 vs 命令）要有机理论证；
3. 消融结论量化到百分比；
4. 组件交给竞争方法也能提升=组件价值的独立证据；
5. “不 apple-to-apple”的对比主动声明+换系统级对比表；基线 reinterpret 时给同等信息；
6. 限制节写具体失败案例（不存在的物品名、错误燃料）。

---

## 6. 方向综述：超级智能体方向投稿打法清单

**选题**：五条已验证路线——(a) ReAct：两个各自成熟的能力对，组合空白（当下候选：记忆检索×多智能体、世界模型×agent 规划、技能库自演化）；(b) MetaGPT：从人类成熟实践移植（SRT 组织学、合同/审计/仲裁机制、DevOps 流程），先引用具体病灶再给药；(c) Toolformer：悖论开题+数据自举（采样→执行→损失差过滤→自训练）；(d) Generative Agents：老议程重开（40 年 believable agents 史）+记忆架构机制化；(e) Voyager：对新范式点名判刑到零件级（缺哪个库/验证器/课程）+终身学习主张。
**论述**：范式论文→一句话方法+好名字+反常识头条数字；框架论文→三段式机制叙事+贯穿隐喻+理论谱系；机制论文→每个因子给完整实现（含 prompt）；明确声明与 ReAct/Reflexion 的继承关系。
**实验**：主张协同就在协同两侧各自取证；同一轨迹删减式完美受控消融；失败模式分类表（人工标注+百分比）；公开基准硬数字 + 自建任务级基准；成本-质量-生产率多维矩阵；能力对照表；无 GT 任务自建 interview 协议；工具使用归因逐任务报告；组件交给竞争方法验证 plug-and-play 价值；"不 apple-to-apple"的对比主动声明并换系统级表。
**基线**：库内可对标 Octopus v2（端侧）、E-Ledger（安全 harness）、SwarmWorld（去中心化）、SPLATIFY（代码合成）、COLMAR/GRAND-SLAM（3D 空间智能体）——见 SKILL.md §2.2；评测基准从 GISAgentBench/WorldBench/MeMoREval/SkillScriptBench 中选与主张匹配者（super-agent SKILL.md §3 的匹配原则：不要用单智能体指标评多智能体系统）。
**价值**：冲"命名权"（循环/机制/接口成为标准词汇）或"框架事实标准"（产业级开源）；与 3D 结合的差异化叙事：空间任务是最能暴露闲聊式协作失败的场景（信息传递 vs 信息使用 vs 验证故障的三分诊断）。
**红线**：诚实报告成本劣势并换口径呈现；负结果转化为组合贡献；多智能体论文必须做多智能体维度的评价（协调开销、通信 token、故障传播率），只报最终任务成功率必被审稿人打回。

---

*深读来源：ar5iv 全文（2026-10 检索）。引用数：Semantic Scholar batch API 2026-10-14/15 核实（Toolformer/Generative Agents/Voyager 为 2026-10-15 核实值）。本文档由 research-expert-team 维护；补充新标杆论文时保持六维解剖结构（Toolformer/GA/Voyager 为精简五维：选题/论述/实验/打法，价值并入打法）。*
