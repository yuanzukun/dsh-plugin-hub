# Changelog

本文件记录 Orca DSH Launcher 的所有版本变更，遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 风格。
版本号规则：语义化版本（主.次.补丁），详见 [CONTRIBUTING.md](CONTRIBUTING.md)。

## [Unreleased]

## [v2.1.2] - 2026-08-30

### Fixed
- **DSH 构建失败自动清理并重建**：构建失败时自动先 `pnpm clean`（清理上游删包残留的未追踪旧产物，避免 `MISSING_EXPORT`）再 `pnpm run build`，成功才放行。
- **启动 DSH 放宽 corepack 校验**：启动进程设 `COREPACK_ENABLE_STRICT=0`，避免 `packageManager` 固定 pnpm 版本的签名校验网络超时导致 `Refusing to run`、启动/构建被卡死。

## [v2.1.1] - 2026-08-23

### Fixed
- **计价徽标按官方新规调整**：自 2026-08-23 起，周六/周日全天为低谷价，工作日峰谷时段（09:00-12:00、14:00-18:00 为高峰）与价格不变；提示卡新增周末说明，模型名对齐官方 `V4-Pro` / `V4-Flash`。

## [v2.1.0] - 2026-08-22

### Added
- **一键更新 DSH 支持预览更新内容**：点「更新 DSH…」时先做一次只读 `git fetch`，把即将拉取的提交（`HEAD..上游` 的 oneline）逐条列进确认框，用户看清「这次更新会带来什么」再决定是否继续；本地已是最新时直接提示、不再空跑 `git pull`，获取预览失败时降级提示但仍可继续。对应新增 `Orca.Core.DshServer.PreviewUpdate` 与 `UpdatePreview` 类型。

### Changed
- **视觉精修 + 呼吸感（控制台 / 安装向导）**：
  - 统一圆角（按钮与卡片 6→8）、所有内容卡片加细描边（主题自适应）；
  - 概览 / 安装状态卡改用「图标徽章」（圆角方块色块 + 强调色对勾），侧边栏当前页加强调色左侧指示条，状态徽章与标题栏加分隔/描边；
  - **呼吸感**：页面标题下方强调色短横线、主/次/危险按钮悬停「上浮」阴影、卡片悬停微高亮；
  - **浅色主题**：安装向导改为跟随用户主题（不再强制深色）、日志/安装日志等文本框改为主题自适应、目录选择框随主题变色，浅色下同样精致。

### Fixed
- **`/orca 重启`（及安装/启动流程）在带空格的 DSH 目录上失败**：`ProcessRunner.StartHiddenCmd` 原先用 `ArgumentList` 传命令字符串，.NET 会按 C 运行时规则把命令里的 `"` 转义成 `\"`，而 `cmd.exe` 不认 `\"` 转义，导致 `cd /d "D:\deepseek harness"` 被拆成 `cd /d D:\deepseek`、cd 静默失败、服务器在错误目录无法启动。改为用 `Arguments` 单字符串原样传给 `cmd.exe`（与旧版 PowerShell 的拼接行为一致），`Run` 方法对 `cmd.exe` 同样特判。已实测 `/orca 重启` 完整链路：关旧 → 等端口释放 → 正确目录拉起新服务器 → 端口恢复。

### Removed
- **v1.x 的 PowerShell / VBScript 实现（`legacy/`）从仓库移除**：避免 GitHub 语言统计把 PowerShell 计入项目占比；旧文件保留在本地磁盘与 git 历史中，可随时回退（`git show`）。

## [v2.0.0] - 2026-08-21

> **底层技术栈重写**：桌面端从 PowerShell 5.1 + VBScript 全面迁移到 **C# / .NET 8（WPF + WinForms）**，编译为原生 exe。**功能一个不少**，行为逐项对齐 v1.7.0。

### Changed
- **技术栈**：`orca-common.ps1` / `orca-install.ps1` / `dsh-tray.ps1` / `dsh-console.ps1` / `orca-setup.ps1` / `start-*.vbs` 共约 4400 行 PowerShell 全部重写为 C# 解决方案 `src/`：
  - `Orca.Core`（公共逻辑库）：配置读写、使用统计、日志轮转、端口归属判断、服务器启停、DSH 构建检查、更新检查、快捷方式、`cordis.patch.yml` 登记、安装逻辑、主题与强调色、自定义对话框。
  - `Orca.App`（`orca.exe`，一个程序四种模式）：`--console` 图形控制台（WPF，6 页）、`--tray` 系统托盘（WinForms NotifyIcon）、`--setup` 一键安装向导（WPF，6 步）、`--start-server` 静默启动服务器。
  - `Orca.Cli`（`orca-cli.exe`）：`/orca` 全部子命令 + `install-plugin` / `uninstall-plugin` / `quick-check` / `selftest`。
- **`plugin.js` 变成薄壳**（约 200 行）：只做「注册 `/orca` 命令 → 转发给 `orca-cli.exe` → 返回 `{kind,text}`」，另加启动时后台更新检查与按配置拉起托盘。插件侧不再调用 `powershell.exe` / `netstat` / `taskkill`，也不再维护第二套逻辑。
- **不再需要 VBScript 启动器**：`orca.exe` 是 `WinExe`（无控制台窗口），快捷方式直接带参数，`start-tray.vbs` / `start-console.vbs` / `start-dsh-server.vbs` 全部退役。
- **开发脚本改为 `.cmd` + MSBuild**：`build.cmd` / `test.cmd` / `install.cmd` / `uninstall.cmd` / `publish.cmd` 取代 `scripts/*.ps1`；打包由 `src/Orca.Package.proj`（MSBuild）完成，不再依赖 ps2exe。
- **分发形态升级**：`dist\orca-setup.exe` 改为 **.NET 自包含单文件**（内嵌插件包 zip 作为嵌入资源），全新电脑无需预装 .NET 即可双击安装。
- **备份位置统一**：安装/卸载/升级前的自动备份统一放 `~/.dsh/orca-backup/`（旧版放在仓库 `backup/`），从发布包安装时也一定可写。

### Added
- **`/orca 安装`（`setup`）子命令**：直接从聊天窗口打开一键安装向导。
- **`orca-cli.exe selftest`**：9 项内建自检（版本号 / 配置往返 / 端口探测 / 统计原子写 / 图标资源 / 快捷方式创建删除 / 登记文件读写 / 日志 / 环境探测），`test.cmd` 一键跑完。
- **`orca-cli.exe quick-check`**：输出状态 JSON（含版本、运行时、端口状态、安装状态、构建产物、更新检查结果），便于脚本与监控接入。
- **状态里新增托盘信息**：`/orca 状态` 与「诊断」现在会显示托盘是否在运行、构建产物是否齐全、桌面端版本与 .NET 运行时版本。
- **`NuGet.config`**：仓库级 NuGet 源声明，避免受机器全局配置影响（只有打自包含安装器时需要联网）。

### Fixed
- **状态刷新不再卡界面**：端口归属判断由 `Get-CimInstance Win32_Process`（每次 50~200ms）改为直接读目标进程 PEB（微秒级），并且检查更新 / 启停 / 安装等耗时操作全部移到后台线程。
- **`/orca 关闭`、`/orca 重启` 更可靠**：`orca-cli.exe` 是 DSH 服务器的子进程，直接 `taskkill /T` 会把自己一起杀掉导致回复丢失；现在改为派发一条"脱钩"的后台命令串（等待 → 关闭 → 重新启动），命令回复稳定送达。
- **快捷方式图标不再指向编译目录**：托盘/服务器自启快捷方式的图标改用目标 exe 旁边的 `dsh-tray.ico`。
- **升级自动清理旧资产**：安装时若发现 v1.x 的 `orca\*.ps1`，先整目录备份到 `~/.dsh/orca-backup/legacy-powershell-*` 再删除，避免新旧两套并存。
- **彻底摆脱脚本编码坑**：不再有「`.ps1` 必须 UTF-8 带 BOM」「PS 5.1 按 GBK 读 JSON 乱码」这类问题；配置文件读写统一走 `Utf8Files`（UTF-8 无 BOM）。

### Compatibility
- **配置与数据完全兼容**：`~/.dsh/orca-dsh-launcher.json`、`orca-stats.json`、`orca-dsh-server.log`、`update-check-state.json`、`orca-dsh-last-build.json` 沿用同名文件与字段，升级不丢数据；配置里用户手动添加的字段保存时原样保留。
- **单实例与联动信号沿用 v1.x 名称**（`Local\DSH-Tray-Single`、`Local\Orca-Console-Show/Close`、`Local\Orca-Tray-Close`），新旧版本混装也不会开出两个托盘，并可互相优雅关闭。
- **`legacy/`**：v1.7.0 的全部 PowerShell / VBS 实现原样保留，仅作历史参照。

### Requirements
- 编译需要 .NET 8 SDK；日常运行需要 .NET 8 Desktop Runtime（`orca-setup.exe` 自包含，无需另装）。

## [v1.7.0] - 2026-08-20

### Added
- **DSH 聊天界面计费徽标**（客户端插件）：在 DSH 网页聊天会话顶部显示 `🔴 高峰 / 🟢 空闲` 计费状态，按北京时间在浏览器端实时计算，无需服务器往返。视觉完全使用 DSH 官方设计令牌（`--dsw-alias-*`），自动适配深/浅主题：徽标为圆角胶囊样式，悬停弹出官方风格深色提示卡——显示当前状态、北京时间、切换倒计时，以及 **V4 Pro / V4 Flash 双模型**的高峰/空闲参考价。
- **DSH 自动构建（源码更新保护）**：DSH 是源码 checkout，`git pull` 更新后缺构建产物会导致启动失败。现在启动（`/orca` 命令 / 托盘 / 控制台 / 开机自启）与「更新 DSH」两条路径都会先做构建检查——HEAD 变化或 6 个关键构建产物缺失时自动 `pnpm run build`（隐藏窗口、10 分钟超时、日志进 `orca-dsh-build.log`），构建成功才启动；失败明确报错且不启动。连续启动且无变化时跳过构建快速启动（缓存于 `orca-dsh-last-build.json`）。

### Changed
- **托盘/控制台合并**：
  - 控制台右上角关闭按钮改为**选项菜单**：「最小化到托盘」「退出程序」（默认退出，回车即直接关闭）；菜单为单色样式，随深/浅主题自适应。
  - 最小化到托盘后，托盘「打开管理界面」/桌面图标可随时恢复显示（不再弹"已经打开"）。
  - 托盘菜单「打开控制台…」改名「打开管理界面」；「退出托盘」改名「退出程序」，退出时联动关闭控制台。
  - 修复控制台关闭后进程残留、界面再也打不开的 bug（退出时强制结束进程）。
  - 概览页托盘卡片新增「启动托盘」按钮（托盘未运行时一键拉起）。
- **移除控制台内计费卡片**：计费时段功能只保留在 DSH 聊天界面，Orca 控制台不再显示计费卡片/图标/提醒设置，界面更简洁。

### Fixed
- **更新完成弹窗过高无法关闭**：`git pull` 输出过长时弹窗被撑得比屏幕还高、按钮顶出屏幕。现在弹窗限制最大高度、消息区可滚动，超长输出自动截断为最后 60 行。
- **退出面板显示 bug**：关闭按钮选项改为窗口内嵌面板（替代弹出菜单），修复文字被遮挡与彩色重影。
- **设置页底部按钮被遮挡**：设置/概览页内容包进滚动容器，窗口高度增大，「保存设置」始终可达。

## [v1.6.0] - 2026-08-16

### Added
- **一键安装引导器 `orca-setup.ps1`**：面向全新电脑（没装过 DSH）的图形安装向导——环境检测（Node/Git/pnpm，缺什么给指引）→ 网络检测（GitHub 连通性分档提示，网络差不硬来）→ 自选安装文件夹 → 自动 `git clone` 最新版 DSH → `pnpm install` + `pnpm run build` 装依赖（实时日志）→ 自动安装本插件并创建桌面图标。
- **控制台「安装」页**：图形控制台新增「安装」导航页——DSH 完整版安装状态卡 +「一键安装完整版」「启动官方 Web 版（`npx @deepseek-ai/dsh web`）」「打开 DSH 官网」三个入口，安装过程实时日志。
- **未安装引导**：未安装 DSH 时，概览/服务器状态卡显示「未安装」，启动/打开按钮明确提示并跳转「安装」页，不再静默失败（插件 `/orca` 命令同步提示）。
- **EXE 打包**：`scripts/build-exe.ps1` 用 ps2exe 把引导器打成单文件 `dist\orca-setup.exe`（内嵌插件包，虎鲸图标，无控制台窗口），发布到 GitHub Releases 供小白直接下载双击。
- **payload 链路测试**：`test/payload-test.ps1` 验证插件文件"打包→注入→解压"链路，全量测试扩为 7 项。
- **仓库开源化整理**：新增 `.gitignore`、`LICENSE`（MIT），README 全面重写为面向程序员的开发者文档（清除内部术语）。

### Changed
- **安装核心逻辑抽为公共库 `orca\orca-install.ps1`**：环境/网络检测、git clone、pnpm install+build、npx web 启动、插件安装，独立向导与控制台共用一份。
- **修复源码安装流程**：补上官方流程缺失的 `pnpm run build` 步骤（`pnpm install` → `pnpm run build` → `pnpm dsh web`）。
- **编码规范加固**：托盘/控制台/打包脚本读取 `package.json` 改为 .NET 显式 UTF-8（修复潜在 GBK 乱码）。
- 全量测试 `test-all.ps1` 由 5 项扩为 7 项（新增引导器自检、payload 链路测试）。
- README 移除了版本历史章节，统一指向 `CHANGELOG.md`。

## [v1.5.0] - 2026-08-16

### Added
- **聊天命令增强**：新增 `/orca 重启`、`/orca 日志`、`/orca 端口`、`/orca 配置`、`/orca 诊断`。
- **设置即时同步**：`/orca` 每次执行重新读取配置，控制台改设置后无需重启 DSH。
- **打开自动启动**：`/orca 打开` 在服务器未运行时自动启动并等待就绪，与文档一致。
- **端口占用保护**：启动/关闭/重启时识别占用者，非 DSH 进程不会误杀并明确提示。
- **每日自动检查更新**：DSH 运行期间每天自动检查一次，只记录不自动更新。
- **启动失败原因提示**：DSH 目录不存在、端口被占等场景给出具体错误信息。

### Fixed
- 测试脚本不再永久修改用户配置，测试前后自动备份/恢复。
- 控制台“更新 DSH”确认框使用当前配置的 DSH 目录，不再写死默认路径。

## [v1.4.0] - 2026-08-16

### Added
- **一键更新 DSH**：概览页新增「更新 DSH…」按钮，确认后执行 `git pull`（官方仓库），更新成功提示重启、失败明确提示"当前版本不受影响"。
- **日志自动轮转**：服务器日志超过 2MB 自动备份为 `.1` 再开新日志，防止无限增长塞满硬盘。
- **一键测试脚本** `scripts/test-all.ps1`：语法检查 → 插件加载 → 状态自检 → 托盘自检 → 真实 Cordis 加载，5 项一键跑完。
- **托盘菜单增强**：显示当前版本（`Orca vX.Y.Z`，从 package.json 动态读取）+「日志位置…」菜单（气泡显示日志文件路径）。
- **使用统计**：记录启动次数 / 服务器启动次数 / 累计运行时长（`~/.dsh/orca-stats.json`），控制台「关于」页展示。
- **版本号单一来源**：控制台/托盘版本号改为从 `package.json` 动态读取，改版本号只需改一处。

### Fixed
- **使用统计数据被误删**：测试清理不再删除 `orca-stats.json`（用户数据），统计保存改为原子写入（临时文件+替换）防写坏。
- **导航点击卡顿**：端口探测改为高速 TCP 探测（~1ms）、5 个页面加渲染缓存（BitmapCache）、定时刷新防重入、日志读取改 .NET 快速读取、刷新频率降为 4 秒。

## [v1.3.0] - 2026-08-16

### Added
- **日志页**：控制台新增「日志」导航页，实时查看 DSH 运行日志（存于 `~/.dsh/orca-dsh-server.log`，自动刷新 / 手动刷新 / 清空）。
- **一键重启**：服务器页新增「重启服务器」按钮（关闭+启动一步到位）。
- **更新详情**：发现新版本时，概览卡片显示官方最近提交标题（GitHub API 拉取，失败静默降级）。
- **开机自启 DSH**：设置页新增开关，登录 Windows 后自动启动 DSH 服务器（新增 `start-dsh-server.ps1/vbs`）。
- **主题切换**：深色/浅色主题（设置页单选，保存立即生效，配置新增 `theme` 字段）。
- **端口占用检测**：区分"DSH 运行中 / 端口被其他程序占用（显示占用者）/ 空闲"，启动前拦截提示。

## [v1.2.0] - 2026-08-16

### Changed
- **控制台界面大改版**：升级为 WPF 导航式管理界面（仿 Codex++ 风格）：左侧导航（概览/服务器/设置/关于）+ 健康检查式状态卡片 + 深黑底/青绿强调/白底主按钮。
- **图标定型**：圆角白底虎鲸（多尺寸 16~256px），新增 `orca-icon.ico` 桌面专用副本绕开 Windows 图标缓存。

## [v1.1.0] - 2026-08-15

### Added
- **桌面控制台**：新增 `dsh-console.ps1` 独立管理窗口（状态总览 / 操作按钮 / 设置保存），DSH 没启动也能打开。
- **公共逻辑库** `orca-common.ps1`：托盘/控制台共用逻辑（配置、服务器、更新检查、窗口辅助），消除重复代码。
- **打开界面合并启动**：点「打开 DSH 界面」未运行自动先启动，就绪后自动开浏览器，不干等。
- 托盘菜单加「打开控制台…」；`/orca` 加 `控制台` 子命令。
- 安装脚本创建桌面图标；卸载脚本清理。

## [v1.0.1] - 2026-08-15

### Fixed
- **Cordis 依赖注入崩溃**：插件改为对象插件形式并声明 `inject: ['commands']`，解决重启 DSH 时 `cannot get property "commands" without inject` 崩溃。

## [v1.0.0] - 2026-08-15

### Added
- 合并 `dsh-update-checker` 插件与 Orca 托盘为 `orca-dsh-launcher` 单插件。
- 新增 `/orca` 命令（状态/检查/启动/关闭/打开/托盘）。
- 共享配置 `~/.dsh/orca-dsh-launcher.json`，消除硬编码与双份更新检查逻辑。
- 安装脚本自动迁移旧插件。

### Changed
- 托盘随插件打包，消除"运行版 vs 存档版"双副本问题。

## [v0.1.0] - 2026-08

旧项目 `dsh-update-checker` 初始交付（更新检查插件 + Orca 托盘，两个独立组件）。
