"use strict"
// dsh-plugin-guard 单测：mock ctx + 真实裁决逻辑
const path = require("path")
const fs = require("fs")
const os = require("os")

const tmpBase = fs.mkdtempSync(path.join(os.tmpdir(), "guard-test-"))
const auditPath = path.join(tmpBase, "guard-audit.jsonl")

// mock dsh ctx
function makeCtx(cfg) {
  const handlers = {}
  return {
    baseDir: tmpBase,
    config: cfg ? { dshGuard: cfg } : undefined,
    on(ev, fn) { handlers[ev] = fn },
    _handlers: handlers,
    _fire(ev, exec, next) { return handlers[ev](exec, next) },
  }
}

const mod = require(path.join(__dirname, "index.js"))
let pass = 0, fail = 0
function check(name, cond, detail) {
  if (cond) { pass++; console.log("  ✅", name) }
  else { fail++; console.log("  ❌", name, "|", detail || "") }
}

async function run() {
  // ---- 用例1: 恶意插件(声明只读却删文件) -> deny
  {
    const ctx = makeCtx({ allowedTools: ["read_file"] })
    mod.apply(ctx)
    const exec = { name: "fs_unlink", arguments: { path: "important.txt" } }
    const d = await ctx._fire("tools/pre-execute", exec, async () => ({ kind: "allow" }))
    check("恶意 fs.unlink -> deny", d.kind === "deny", JSON.stringify(d))
  }
  // ---- 用例2: rm -rf -> deny
  {
    const ctx = makeCtx({})
    mod.apply(ctx)
    const exec = { name: "bash", arguments: { command: "rm -rf /tmp/x" } }
    const d = await ctx._fire("tools/pre-execute", exec, async () => ({ kind: "allow" }))
    check("rm -rf -> deny", d.kind === "deny", JSON.stringify(d))
  }
  // ---- 用例3: .env 读取 -> deny
  {
    const ctx = makeCtx({})
    mod.apply(ctx)
    const exec = { name: "read_file", arguments: { path: "D:/forge/.env" } }
    const d = await ctx._fire("tools/pre-execute", exec, async () => ({ kind: "allow" }))
    check(".env 读取 -> deny", d.kind === "deny", JSON.stringify(d))
  }
  // ---- 用例4: 白名单内正常操作 -> allow + next 被调用
  {
    const ctx = makeCtx({ allowedTools: ["read_file", "python"] })
    mod.apply(ctx)
    let nextCalled = false
    const exec = { name: "read_file", arguments: { path: "workspace/a.txt" } }
    const d = await ctx._fire("tools/pre-execute", exec, async () => { nextCalled = true; return { kind: "allow" } })
    check("白名单内 -> allow", d.kind === "allow" && nextCalled, JSON.stringify(d))
  }
  // ---- 用例5: 未声明工具 -> ask（走 ApprovalService）
  {
    const ctx = makeCtx({})
    mod.apply(ctx)
    const exec = { name: "http_get", arguments: { url: "https://example.com" } }
    const d = await ctx._fire("tools/pre-execute", exec, async () => ({ kind: "allow" }))
    check("未声明 -> ask", d.kind === "ask" && /未在/.test(d.reason || ""), JSON.stringify(d))
  }
  // ---- 用例6: 审计 JSONL 落盘
  {
    const ctx = makeCtx({})
    mod.apply(ctx)
    await ctx._fire("tools/pre-execute", { name: "bash", arguments: { command: "rm -rf /x" } }, async () => ({ kind: "allow" }))
    const lines = fs.readFileSync(auditPath, "utf-8").trim().split("\n")
    check("审计 JSONL 落盘", lines.some(l => l.includes('"decision":"deny"')), lines[lines.length-1] || "空")
  }
  // ---- 用例7: fork bomb -> deny
  {
    const ctx = makeCtx({})
    mod.apply(ctx)
    const exec = { name: "python", arguments: { code: ":(){ :|:& };:" } }
    const d = await ctx._fire("tools/pre-execute", exec, async () => ({ kind: "allow" }))
    check("fork bomb -> deny", d.kind === "deny", JSON.stringify(d))
  }
  console.log(`\n结果: ${pass} 通过 / ${fail} 失败`)
  process.exit(fail > 0 ? 1 : 0)
}

run().catch(e => { console.error("测试异常:", e); process.exit(1) })
