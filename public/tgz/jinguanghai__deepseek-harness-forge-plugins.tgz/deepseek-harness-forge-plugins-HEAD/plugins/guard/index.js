"use strict"
/**
 * dsh-plugin-guard — 插件运行时权限护栏（反向安全层）
 *
 * 官方只给插件"锁门"(安装时审批 define/run 分离)，装上之后在 host 里全权限运行。
 * 本插件补"锁房间"：在 tools/pre-execute 瀑布钩子里做三档裁决：
 *   L2 黑名单(危险模式) -> deny(fail-closed) + 审计
 *   L0 白名单(声明内)   -> allow 放行，零摩擦
 *   L1 灰名单(未声明)   -> ask 走官方 ApprovalService 人工批准 + 审计
 * 零改官方源码，纯标准钩子。
 */
import fs from "node:fs"
import path from "node:path"

const name = "dsh-plugin-guard"
const inject = ["tools"]

const Config = {
  // 默认策略：未声明工具走人工批准(ask)，可关
  askUnlisted: true,
  // 白名单：声明允许的工具名
  allowedTools: [],
  // 危险模式黑名单（fail-closed 直接拒）
  dangerPatterns: [
    { re: /\brm\s+-rf\b/i, reason: "rm -rf 递归删除" },
    { re: /\bfs[_.]unlink(?:Sync)?\b/i, reason: "删除文件(fs.unlink)" },
    { re: /\b(?:unlink|rmtree|remove_file|delete_file|file_delete)\b/i, reason: "删除类操作" },
    { re: /\bshutil\.rmtree\s*\(/i, reason: "Python 递归删除(shutil.rmtree)" },
    { re: /\.env\b/, reason: "访问 .env 密钥文件" },
    { re: /Authorization\s*[:=]\s*["']?Bearer/i, reason: "密钥外发(Bearer token)" },
    { re: /sk-[A-Za-z0-9]{16,}/, reason: "API key 形态外发" },
    { re: /:\s*\(\s*\)\s*\{/i, reason: "fork bomb(bash)" },
    { re: /:\s*\(\s*\)\s*=>/i, reason: "fork bomb(js)" },
    { re: /child_process\.(?:exec|spawn)(?:Sync)?\s*\(/i, reason: "shell 执行(child_process)" },
    { re: /base64[^\n]{0,40}(?:-d|--decode|\.decode)/i, reason: "base64 解码执行(混淆)" },
    { re: /\beval\s*\(/i, reason: "eval 动态执行" },
  ],
}

function apply(ctx, config) {
  const cfg = Object.assign({}, Config, config && config.dshGuard)
  const auditPath = path.join(process.cwd(), "guard-audit.jsonl")

  function audit(entry) {
    try {
      fs.appendFileSync(auditPath, JSON.stringify({ ts: new Date().toISOString(), ...entry }) + "\n")
    } catch (e) { /* 审计失败不阻断执行 */ }
  }

  function judge(exec) {
    const toolName = String(exec.name || "")
    let blob = toolName
    try { blob += " " + JSON.stringify(exec.arguments || {}) } catch (e) { /* ignore */ }

    // L2 黑名单：fail-closed 直接拒
    for (const p of cfg.dangerPatterns) {
      if (p.re.test(blob)) return { kind: "deny", reason: p.reason }
    }
    // L0 白名单：声明内放行
    if (Array.isArray(cfg.allowedTools) && cfg.allowedTools.includes(toolName)) {
      return { kind: "allow" }
    }
    // L1 灰名单：未声明 -> 人工批准
    if (cfg.askUnlisted) return { kind: "ask", reason: "工具 " + toolName + " 未在 dshGuard 白名单声明" }
    return { kind: "allow" }
  }

  ctx.on("tools/pre-execute", async (exec, next) => {
    let d
    try {
      d = judge(exec)
    } catch (e) {
      d = { kind: "allow" } // 裁决器自身异常不阻断（fail-open 于自身）
    }
    audit({ tool: String(exec.name || ""), decision: d.kind, reason: d.reason || "" })
    if (d.kind === "allow") return next()
    return d
  })
}

export { name, inject, apply }
export default { name, inject, apply }
