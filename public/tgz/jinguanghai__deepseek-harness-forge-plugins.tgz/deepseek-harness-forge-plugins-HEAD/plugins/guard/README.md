# dsh-plugin-guard

Plugin runtime permission guardrail for DeepSeek Harness — the missing "second lock" for plugins.

## Why

Official Harness secures plugins at **install time** (define/run separation + human approval).
But once installed, a plugin runs in the **host process** with full permission:
`ctx.subprocess.spawn`, fs read/write, network — **no runtime guardrail at all**.
This matters more now that LLMs can author plugins themselves (cordis create mode):
a statistical model writing host-level code with no runtime check is the deepest hole
in the architecture (deeper than `run_code`, which at least lives in a sandbox).

## What

Three-tier adjudication on the official `tools/pre-execute` waterfall hook —
zero modification of official source:

| Tier | Condition | Decision |
|---|---|---|
| **L2 blacklist** | dangerous patterns: rm -rf, fs.unlink / rmtree, .env, Bearer tokens, sk- keys, fork bomb, child_process exec, base64-decode-exec, eval | deny (fail-closed) + audit |
| **L0 whitelist** | tool declared in dshGuard.allowedTools | allow (zero friction) |
| **L1 grey** | unlisted tool | ask -> official ApprovalService (human approval) + audit |

Every adjudication is appended to guard-audit.jsonl (who / when / what / decision / reason).

## Usage

```jsonc
// plugin package.json — declare what your plugin may do
{ "dshGuard": { "allowedTools": ["read_file", "python"] } }
```

Plugins without a declaration keep official default behavior (no regression).

## Design philosophy

Three-layer security for three audiences:

- general users -> sandbox (official, already there)
- developers -> runtime permission model (this plugin fills the official gap)
- power users -> their own guardrails on danger-full-access

This plugin *adds* security to an official permission mode; it does not bypass anything.

## Tests

node test-guard.js -> 7/7 pass
