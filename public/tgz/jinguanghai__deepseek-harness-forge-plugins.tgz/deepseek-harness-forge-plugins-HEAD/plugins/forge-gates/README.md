# forge-gates — 铸剑炉工具集 + 全权限桥

将铸剑炉（forge）的确定性工具能力搬进 dsh，供模型在对话中直接调用。

## 工具清单（9 个）

| 工具 | 类型 | 说明 |
|---|---|---|
| forge_math | v1 | SymPy 数学计算与验证（simplify/solve/equals/evaluate/factor/integrate/diff） |
| forge_logic | v1 | Z3 逻辑判定与 SAT 求解（sat/prove/equivalence） |
| forge_regex | v1 | 正则验证（整串匹配 fullmatch） |
| forge_eprover | v1 | 一阶逻辑命题定理证明（内建 DPLL） |
| forge_system | v1 | 状态机模型检查器（BFS，invariant/reachability） |
| forge_repair | v1 | 代码静态修复建议（模式匹配 + 启发式） |
| **forge_run** | **v2 新增** | **通用代码执行：python/go/node/deno/rust/tcc，写临时文件→解释器运行→回传 rc/stdout/stderr，超时硬杀 + 输出截断** |
| **forge_fs** | **v2 新增** | **文件系统：read/write/list，限 workspace 内，越界拒绝** |
| **forge_net** | **v2 新增** | **HTTP 请求：GET/POST，返回 status + body + headers** |

## v2 设计（全权限桥）

dsh 模型运行在沙箱内（run_code 无网络、文件围栏、仅 JS），而插件代码运行在 **host 进程**——沙箱约束不到插件。通过插件注册工具，给 dsh 开一条"权限虫洞"：

```
dsh 模型 → forge_run(code, lang) → 写临时文件 → spawn 解释器/编译器 → 回传结果
         → forge_fs(action, path) → workspace 内读写列目录
         → forge_net(url, ...)    → HTTP 请求（补网络权限）
```

### 安全模型
- **forge_fs**：路径解析后必须落在 workspace（FORGE_HOME 或 cwd）内，越界直接拒绝
- **forge_run**：超时默认 60s（上限 120s）硬杀；stdout 截断 2MB / stderr 200KB；rust/tcc 编译失败即停
- **审批**：工具调用受 dsh approvalPolicy 约束（默认 ask），每次调用需人批准

### 环境要求
- python/go/rustc 在 PATH；deno 默认 `D:/forge/deno/deno.exe`、tcc 默认 `D:/forge/tcc/tcc/tcc.exe`（可用 DENO_BIN/TCC_BIN 覆盖）
- v1 的 6 个 gate 工具需 `FORGE_GATE_BIN` 指向 gate 二进制目录（发布包 `bin/windows`），开发环境回退本机路径

## 测试

`node test-bridge.mjs` — mock dsh ctx 的回归测试（真实执行）：17 用例覆盖语言执行/错误路径/超时/文件越界/HTTP。
