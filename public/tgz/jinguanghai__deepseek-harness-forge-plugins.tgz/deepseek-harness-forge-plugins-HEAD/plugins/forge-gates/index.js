// forge-gates v2 — 铸剑炉（forge）的 gate 工具集 + 全权限桥（forge-bridge）。
// v1: 数学/逻辑/正则/定理证明/模型检查/修复 6 工具（复用 forge-tools gate 二进制，零重写）。
// v2 新增: forge_run(通用代码执行) / forge_fs(workspace 文件读写) / forge_net(HTTP 请求)。
//   设计: dsh 模型在沙箱内, 插件在 host 侧 — 通过插件给 dsh 开"权限虫洞"。
//   安全: forge_fs 限 workspace 内; forge_run 超时硬杀+输出截断; 审批闸门由 dsh approvalPolicy 管。
// 路径动态解析: FORGE_GATE_BIN 环境变量 → 发布包 bin/windows → 本机回退（开发环境）。
// 零外部依赖: 仅 node:fs/os/path 内建模块; tools 经 ctx.tools.register 注册。
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

export const name = 'forge-gates'
export const inject = ['tools', 'subprocess']

export function apply(ctx) {
  const hereDir = (() => {
    try {
      let u = import.meta.url.replace(/^file:\/\//, '').replace(/^[\\/]+/, '')
      return u.replace(/[\\/][^\\/]*$/, '')
    } catch { return '' }
  })()
  const toolsDir = process.env.FORGE_GATE_BIN || (hereDir.length > 2 ? hereDir + '\\bin\\windows' : '')
  const baseDir = process.env.FORGE_HOME || process.cwd()

  const renderText = (_args, value) => [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }]

  async function runGate(gate, arg, exec) {
    const handle = ctx.subprocess.spawn({
      argv: [toolsDir + '\\' + gate + '_gate.exe', arg],
      cwd: baseDir,
      env: { PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' },
      stdio: {
        stdin: 'ignore',
        stdout: { maxBytes: 2 * 1024 * 1024 },
        stderr: { maxBytes: 200 * 1024 },
      },
      graceMs: 5000,
      signal: exec.signal,
    })
    const outcome = await handle.done
    const so = handle.collected.stdout ? handle.collected.stdout.readFrom(0) : { text: '' }
    const se = handle.collected.stderr ? handle.collected.stderr.readFrom(0) : { text: '' }
    const stdout = (so.text || '').trim()
    let parsed = null
    try { parsed = JSON.parse(stdout) } catch {
      const lb = stdout.lastIndexOf('{')
      const rb = stdout.lastIndexOf('}')
      if (lb >= 0 && rb > lb) {
        try { parsed = JSON.parse(stdout.slice(lb, rb + 1)) } catch { parsed = null }
      }
    }
    return { exitCode: outcome.exitCode, parsed, stdout, stderr: (se.text || '').trim() }
  }

  function registerTool(spec) {
    ctx.tools.register({
      name: spec.name,
      description: spec.description,
      parameters: { type: 'object', properties: spec.properties, required: spec.required || [] },
      timeoutMs: spec.timeoutMs,
      output: { schema: { type: 'object' }, render: renderText },
      async execute(args, exec) {
        const r = await runGate(spec.gate, spec.toArg(args), exec)
        const result = r.parsed || {
          error: 'gate 输出非 JSON',
          stdout: r.stdout.slice(0, 400),
          stderr: r.stderr.slice(0, 400),
        }
        return { gate: spec.gate, exit_code: r.exitCode, ok: r.parsed ? r.parsed.ok !== false : r.exitCode === 0, result }
      },
    })
  }

  registerTool({
    gate: 'math',
    name: 'forge_math',
    description: '用 SymPy 执行数学计算与验证（动作: simplify/solve/equals/evaluate/factor/integrate/diff）。涉及算术、数值、等式推导、公式化简时必须调用它实际计算，禁止直接输出结果。',
    timeoutMs: 30000,
    properties: {
      expr: { type: 'string', description: '数学表达式，如 3*(x+1)-3*x' },
      action: { type: 'string', description: 'simplify(默认) | solve | equals | evaluate | factor | integrate | diff' },
      expected: { type: 'string', description: 'equals 模式下的对侧表达式' },
    },
    required: ['expr'],
    toArg: (a) => JSON.stringify({ expr: a.expr, action: a.action || 'simplify', expected: a.expected || '' }),
  })

  registerTool({
    gate: 'logic',
    name: 'forge_logic',
    description: 'Z3 逻辑判定与 SAT 求解。类型: sat(默认, 表达式可满足性) | prove(给定 claim 与约束 s 证明) | equivalence(给定 a b 判等价)。逻辑判断/条件推理/真伪验证用它。⚠️严禁在 code 内 print 输出到 stdout（会污染 JSON 协议）；如需检查中间值请写注释说明，不要 print。',
    timeoutMs: 30000,
    properties: {
      type: { type: 'string', description: 'sat(默认) | prove | equivalence' },
      code: { type: 'string', description: '逻辑表达式或 Z3 Python 代码；比较运算符需加括号，如 (x > 0) & (x < 10)' },
    },
    required: ['code'],
    toArg: (a) => JSON.stringify({ type: a.type || 'sat', code: a.code }),
  })

  registerTool({
    gate: 'regex',
    name: 'forge_regex',
    description: '验证正则表达式（整串完全匹配语义 fullmatch）。positive 每个字符串必须被 pattern 整串匹配，negative 每个必须整串不匹配。flags 可用 i/m/s。',
    timeoutMs: 15000,
    properties: {
      pattern: { type: 'string', description: '正则表达式' },
      positive: { type: 'array', items: { type: 'string' }, description: '必须匹配的字符串列表' },
      negative: { type: 'array', items: { type: 'string' }, description: '必须不匹配的字符串列表' },
      flags: { type: 'string', description: '可选: i/m/s' },
    },
    required: ['pattern'],
    toArg: (a) => JSON.stringify({ type: 'match', pattern: a.pattern, positive: a.positive || [], negative: a.negative || [], flags: a.flags || '' }),
  })

  // 四期 I: eprover/system/repair 已从铸剑炉裁剪 (冗余/降级), 不再注册为 DSH 工具

  // ================= v2.1: forge_knowledge — SPARQL 知识查询 =================
  registerTool({
    gate: 'knowledge',
    name: 'forge_knowledge',
    description: 'SPARQL 知识库查询（Wikidata/DBpedia）: 输入合法 SPARQL 查询字符串，返回结构化结果。知识/概念查询用它。⚠️只接受 SPARQL 语法，自然语言会被拒(bad_request)。外部端点延迟高(秒级~17s)，默认超时 30s。',
    timeoutMs: 45000,
    properties: {
      query: { type: 'string', description: '合法 SPARQL 查询，如 SELECT ?s WHERE { ?s ?p ?o } LIMIT 5' },
      endpoint: { type: 'string', description: '可选: wikidata(默认) | dbpedia' },
      timeout: { type: 'number', description: '可选超时秒数，默认 30' },
    },
    required: ['query'],
    toArg: (a) => JSON.stringify({ type: 'query', query: a.query, endpoint: a.endpoint || 'auto', timeout: a.timeout || 30 }),
  })

  // ================= v2.2: forge_chain — 多 gate 编排 =================
  registerTool({
    gate: 'chain',
    name: 'forge_chain',
    description: '多 gate 顺序编排: 输入 stages 数组(每步 {gate, input, if_verdict?})与 stop_on 策略，按条件链式执行多个推理步骤，返回每步结果。减少多次往返。gate 可选: math|logic|regex|knowledge|chain。',
    timeoutMs: 60000,
    properties: {
      stages: { type: 'array', items: { type: 'object' }, description: '[{gate: "math|logic|regex|knowledge", input: {...}, if_verdict: "theorem|unsat|counter_sat"(可选)}]' },
      stop_on: { type: 'string', description: 'error(默认) | first_success | never' },
    },
    required: ['stages'],
    toArg: (a) => JSON.stringify({ stages: a.stages, stop_on: a.stop_on || 'error' }),
  })

  // ================= v2: forge_run — 通用代码执行 =================
  const LANG_EXT = { python: '.py', go: '.go', node: '.mjs' }

  function buildArgv(lang, srcFile, tmpDir) {
    if (lang === 'python') return { argv: ['python', srcFile], outExe: null }
    if (lang === 'go') return { argv: ['go', 'run', srcFile], outExe: null }
    if (lang === 'node') return { argv: ['node', srcFile], outExe: null }
    return null
  }

  async function spawnOnce(argv, cwd, timeoutMs, exec) {
    const handle = ctx.subprocess.spawn({
      argv,
      cwd,
      env: { PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1', GO111MODULE: 'off' },
      stdio: {
        stdin: 'ignore',
        stdout: { maxBytes: 2 * 1024 * 1024 },
        stderr: { maxBytes: 200 * 1024 },
      },
      graceMs: timeoutMs,
      signal: exec.signal,
    })
    const outcome = await handle.done
    const so = handle.collected.stdout ? handle.collected.stdout.readFrom(0) : { text: '' }
    const se = handle.collected.stderr ? handle.collected.stderr.readFrom(0) : { text: '' }
    return { exitCode: outcome.exitCode, stdout: (so.text || ''), stderr: (se.text || '') }
  }

  ctx.tools.register({
    name: 'forge_run',
    description: '通用代码执行（全权限桥）: 写临时文件 → 调解释器/编译器运行 → 回传 rc/stdout/stderr。lang: python(默认)|go|node|deno|rust|tcc。涉及实际计算、数据处理、脚本任务必须用它。输出截断 2MB/200KB。',
    parameters: {
      type: 'object',
      properties: {
        code: { type: 'string', description: '要执行的源代码' },
        lang: { type: 'string', description: 'python(默认) | go | node' },
        timeout_ms: { type: 'number', description: '超时毫秒，默认 60000，上限 120000' },
      },
      required: ['code'],
    },
    timeoutMs: 120000,
    output: { schema: { type: 'object' }, render: renderText },
    async execute(args, exec) {
      const code = String(args.code || '')
      const lang = String(args.lang || 'python').toLowerCase()
      if (!code.trim()) return { ok: false, error: 'code 为空' }
      if (!LANG_EXT[lang]) return { ok: false, error: '未知语言: ' + lang + '（支持: ' + Object.keys(LANG_EXT).join('/') + '）' }
      const timeoutMs = Math.min(Math.max(Number(args.timeout_ms) || 60000, 1000), 120000)
      const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-run-'))
      const srcFile = path.join(tmpDir, 'main' + LANG_EXT[lang])
      try {
        fs.writeFileSync(srcFile, code, 'utf-8')
        const plan = buildArgv(lang, srcFile, tmpDir)
        if (!plan) return { ok: false, error: '语言不支持: ' + lang }
        let stdout = '', stderr = '', exitCode = 0
        {
          const r = await spawnOnce(plan.argv, tmpDir, timeoutMs, exec)
          exitCode = r.exitCode; stdout = r.stdout; stderr = r.stderr
        }
        return {
          ok: exitCode === 0,
          lang,
          exit_code: exitCode,
          stdout: stdout.slice(0, 2 * 1024 * 1024),
          stderr: stderr.slice(0, 200 * 1024),
          truncated: stdout.length > 2 * 1024 * 1024 || stderr.length > 200 * 1024,
        }
      } catch (e) {
        return { ok: false, lang, error: String(e && e.message || e) }
      } finally {
        try { fs.rmSync(tmpDir, { recursive: true, force: true }) } catch {}
      }
    },
  })

  // ================= v2: forge_fs — workspace 文件工具 =================
  ctx.tools.register({
    name: 'forge_fs',
    description: '文件系统工具（限 workspace 内，越界拒绝）: action=read 读文本(截断2MB) | write 写文本 | list 列目录。path 为相对 workspace 的路径。',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', description: 'read | write | list' },
        path: { type: 'string', description: '相对 workspace 的路径（可用 ./ 或子目录）' },
        content: { type: 'string', description: 'write 模式的内容' },
      },
      required: ['action', 'path'],
    },
    timeoutMs: 15000,
    output: { schema: { type: 'object' }, render: renderText },
    async execute(args) {
      const action = String(args.action || '')
      const rel = String(args.path || '')
      if (!action || !rel) return { ok: false, error: 'action 与 path 必填' }
      const root = path.resolve(baseDir)
      const target = path.resolve(root, rel)
      if (target !== root && !target.startsWith(root + path.sep)) {
        return { ok: false, error: '路径越界（仅允许 workspace 内）: ' + rel }
      }
      try {
        if (action === 'read') {
          if (!fs.existsSync(target)) return { ok: false, error: '文件不存在: ' + rel }
          if (fs.statSync(target).isDirectory()) return { ok: false, error: '是目录不是文件: ' + rel }
          const data = fs.readFileSync(target, 'utf-8')
          return { ok: true, action, path: rel, content: data.slice(0, 2 * 1024 * 1024), truncated: data.length > 2 * 1024 * 1024 }
        }
        if (action === 'write') {
          fs.mkdirSync(path.dirname(target), { recursive: true })
          fs.writeFileSync(target, String(args.content ?? ''), 'utf-8')
          return { ok: true, action, path: rel, bytes: fs.statSync(target).size }
        }
        if (action === 'list') {
          if (!fs.existsSync(target)) return { ok: false, error: '路径不存在: ' + rel }
          const items = fs.readdirSync(target, { withFileTypes: true }).map(d => ({ name: d.name, type: d.isDirectory() ? 'dir' : 'file' }))
          return { ok: true, action, path: rel, count: items.length, items }
        }
        return { ok: false, error: '未知 action: ' + action }
      } catch (e) {
        return { ok: false, error: String(e && e.message || e) }
      }
    },
  })

  // ================= v2: forge_net — HTTP 请求工具 =================
  ctx.tools.register({
    name: 'forge_net',
    description: 'HTTP 请求工具: GET/POST。返回 status + body(截断1MB) + 响应头。url 必填。超时默认 15s。',
    parameters: {
      type: 'object',
      properties: {
        url: { type: 'string', description: '完整 URL' },
        method: { type: 'string', description: 'GET(默认) | POST' },
        headers: { type: 'object', description: '请求头对象，如 {"Content-Type":"application/json"}' },
        body: { type: 'string', description: 'POST body' },
        timeout_ms: { type: 'number', description: '超时毫秒，默认 15000' },
      },
      required: ['url'],
    },
    timeoutMs: 30000,
    output: { schema: { type: 'object' }, render: renderText },
    async execute(args) {
      const ctrl = new AbortController()
      const t = setTimeout(() => ctrl.abort(), Math.min(Number(args.timeout_ms) || 15000, 60000))
      try {
        const resp = await fetch(String(args.url), {
          method: String(args.method || 'GET').toUpperCase(),
          headers: args.headers || {},
          body: args.body !== undefined ? String(args.body) : undefined,
          signal: ctrl.signal,
        })
        const text = await resp.text()
        const headers = {}
        resp.headers.forEach((v, k) => { headers[k] = v })
        return { ok: resp.ok, status: resp.status, statusText: resp.statusText, headers, body: text.slice(0, 1024 * 1024), truncated: text.length > 1024 * 1024 }
      } catch (e) {
        const msg = String(e && e.message || e)
        return { ok: false, error: msg.includes('abort') ? '超时' : msg }
      } finally { clearTimeout(t) }
    },
  })
}
