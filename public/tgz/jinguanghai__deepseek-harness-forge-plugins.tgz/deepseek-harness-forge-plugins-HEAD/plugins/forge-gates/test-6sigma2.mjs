import { pathToFileURL } from 'node:url'
import { spawn } from 'node:child_process'

const registered = []
function mockSpawn(opts) {
  const child = spawn(opts.argv[0], opts.argv.slice(1), {
    cwd: opts.cwd, env: { ...process.env, ...(opts.env || {}) },
    stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true,
  })
  let stdout = '', stderr = ''
  child.stdout.on('data', d => { stdout += d })
  child.stderr.on('data', d => { stderr += d })
  let settled = false
  const done = new Promise((resolve) => {
    const to = setTimeout(() => {
      if (!settled) { settled = true; try { child.kill('SIGKILL') } catch {}; resolve({ exitCode: -9, timedOut: true }) }
    }, opts.graceMs || 60000)
    child.on('close', (code) => { if (!settled) { settled = true; clearTimeout(to); resolve({ exitCode: code }) } })
    child.on('error', (e) => { if (!settled) { settled = true; clearTimeout(to); resolve({ exitCode: -1, error: e.message }) } })
  })
  return { done, collected: { stdout: { readFrom: () => ({ text: stdout }) }, stderr: { readFrom: () => ({ text: stderr }) } } }
}
const ctx = { tools: { register: (spec) => registered.push(spec) }, subprocess: { spawn: mockSpawn } }

const mod = await import(pathToFileURL('D:/forge_release/dsh-forge-plugins/plugins/forge-gates/index.js').href)
mod.apply(ctx)
const byName = Object.fromEntries(registered.map(s => [s.name, s]))
console.log('注册工具 (' + registered.length + '):', registered.map(s => s.name).join(', '))

async function runTool(name, args) {
  const spec = byName[name]
  if (!spec) return { __missing: name }
  return await spec.execute(args, { signal: undefined })
}

let pass = 0, fail = 0
function check(label, cond, detail) {
  if (cond) { pass++; console.log('  ✅', label) }
  else { fail++; console.log('  ❌', label, '|', JSON.stringify(detail).slice(0, 400)) }
}

// 新工具: forge_knowledge（SPARQL 语法错误测试，验证接口接通）
console.log('=== forge_knowledge ===')
let r = await runTool('forge_knowledge', { query: 'hello natural language' })
check('knowledge: 自然语言 → bad_request', r.ok === true && (r.result.error || '').includes('bad_request'), r)
r = await runTool('forge_knowledge', { query: 'SELECT ?s WHERE { ?s ?p ?o } LIMIT 1', timeout: 10 })
check('knowledge: 合法 SPARQL → ok 字段存在', r.ok === true, r)

// 新工具: forge_chain（编排两个 math 步骤）
console.log('=== forge_chain ===')
r = await runTool('forge_chain', { stages: [
  { gate: 'math', input: { expr: '3*7', action: 'evaluate' } },
  { gate: 'math', input: { expr: '21+1', action: 'evaluate' } },
]})
check('chain: 两阶段 math → ok', r.ok === true && r.result.stages && r.result.stages.length === 2, r)
if (r.result && r.result.stages) console.log('  阶段输出:', r.result.stages.map(s => s.ok ? s.output : 'FAIL').join(' | '))

// 原有工具不回归
console.log('=== 回归: forge_math / forge_run ===')
r = await runTool('forge_math', { expr: '2+2', action: 'evaluate' })
check('math: 2+2 → ok', r.ok === true, r)
r = await runTool('forge_run', { code: 'print("hi-42")' })
check('run: python → ok', r.ok === true && (r.stdout || '').includes('hi-42'), r)
r = await runTool('forge_run', { code: 'fn main(){}', lang: 'rust' })
check('run: rust 诚实拒绝', r.ok === false && (r.error || '').includes('未知语言'), r)

console.log(`\n结果: ${pass} 通过, ${fail} 失败`)
process.exit(fail > 0 ? 1 : 0)
