import { pathToFileURL } from 'node:url'
import { spawn } from 'node:child_process'

// ---- mock dsh ctx ----
const registered = []
function mockSpawn(opts) {
  const child = spawn(opts.argv[0], opts.argv.slice(1), {
    cwd: opts.cwd,
    env: { ...process.env, ...(opts.env || {}) },
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  })
  let stdout = '', stderr = ''
  child.stdout.on('data', d => { stdout += d })
  child.stderr.on('data', d => { stderr += d })
  let settled = false
  const done = new Promise((resolve) => {
    const to = setTimeout(() => {
      if (!settled) { settled = true; try { child.kill('SIGKILL') } catch {}; resolve({ exitCode: -9, timedOut: true }) }
    }, opts.graceMs || 60000)
    child.on('close', (code) => { if (!settled) { settled = true; clearTimeout(to); resolve({ exitCode: code }) } })
    child.on('error', (e) => { if (!settled) { settled = true; clearTimeout(to); resolve({ exitCode: -1, error: e.message }) } })
  })
  return {
    done,
    collected: {
      stdout: { readFrom: () => ({ text: stdout }) },
      stderr: { readFrom: () => ({ text: stderr }) },
    },
  }
}

const ctx = {
  tools: { register: (spec) => registered.push(spec) },
  subprocess: { spawn: mockSpawn },
}

// ---- 加载插件 ----
const mod = await import(pathToFileURL('D:/forge_release/dsh-forge-plugins/plugins/forge-gates/index.js').href)
mod.apply(ctx)

const byName = Object.fromEntries(registered.map(s => [s.name, s]))
console.log('注册工具 (' + registered.length + '):', registered.map(s => s.name).join(', '))

async function runTool(name, args) {
  const spec = byName[name]
  if (!spec) return { __missing: name }
  return await spec.execute(args, { signal: undefined })
}

let pass = 0, fail = 0
function check(label, cond, detail) {
  if (cond) { pass++; console.log('  ✅', label) }
  else { fail++; console.log('  ❌', label, '|', JSON.stringify(detail).slice(0, 400)) }
}

console.log('\n=== forge_run ===')
let r = await runTool('forge_run', { code: 'print(1+1)' })
check('python: print(1+1) → ok', r.ok === true, r)
check('python: stdout 含 2', (r.stdout || '').includes('2'), r)

r = await runTool('forge_run', { code: 'package main\nfunc main() { undefinedFunc() }', lang: 'go' })
check('go: 编译错误 → ok=false', r.ok === false, r)
check('go: stderr 含 undefined', (r.stderr || '').includes('undefined'), r)

r = await runTool('forge_run', { code: 'console.log("node-ok")', lang: 'node' })
check('node: console.log → ok', r.ok === true && (r.stdout || '').includes('node-ok'), r)

r = await runTool('forge_run', { code: 'fn main() { println!("rust-ok"); }', lang: 'rust' })
check('rust: 编译+运行 → ok', r.ok === true && (r.stdout || '').includes('rust-ok'), r)

r = await runTool('forge_run', { code: '#include <stdio.h>\nint main(){ printf("tcc-ok\\n"); return 0; }', lang: 'tcc' })
check('tcc: 编译+运行 → ok', r.ok === true && (r.stdout || '').includes('tcc-ok'), r)

r = await runTool('forge_run', { code: 'console.log("hi")', lang: 'cobol' })
check('未知语言 → ok=false', r.ok === false && (r.error || '').includes('未知语言'), r)

r = await runTool('forge_run', { code: 'while True: pass', timeout_ms: 1000 })
check('死循环超时(1s) → 被硬杀', r.ok === false, r)
check('死循环超时 exit_code 非0', r.exit_code !== 0, r)

console.log('\n=== forge_fs ===')
r = await runTool('forge_fs', { action: 'write', path: 'bridge_test.txt', content: '桥测试内容-42' })
check('write: 成功', r.ok === true && r.bytes > 0, r)
r = await runTool('forge_fs', { action: 'read', path: 'bridge_test.txt' })
check('read: 内容一致', r.ok === true && (r.content || '').includes('桥测试内容-42'), r)
r = await runTool('forge_fs', { action: 'list', path: '.' })
check('list: 目录可列', r.ok === true && r.count > 0, r)
r = await runTool('forge_fs', { action: 'read', path: '../../Windows/system32/drivers/etc/hosts' })
check('越界路径 → 拒绝', r.ok === false && (r.error || '').includes('越界'), r)

console.log('\n=== forge_net ===')
// 本地起一个 HTTP 服务做真实测试
import { createServer } from 'node:http'
const srv = createServer((req, res) => {
  res.setHeader('content-type', 'application/json')
  res.end(JSON.stringify({ echo: req.url, method: req.method }))
})
await new Promise(res => srv.listen(18765, '127.0.0.1', res))
r = await runTool('forge_net', { url: 'http://127.0.0.1:18765/api?x=1', method: 'GET' })
check('GET 本地服务 → 200', r.ok === true && r.status === 200, r)
check('GET body 含 echo', (r.body || '').includes('/api?x=1'), r)
r = await runTool('forge_net', { url: 'http://127.0.0.1:18765/post', method: 'POST', body: 'hello', headers: { 'Content-Type': 'text/plain' } })
check('POST → 200 + method=POST', r.ok === true && (r.body || '').includes('POST'), r)
srv.close()

console.log('\n=== 汇总 ===')
console.log(`通过 ${pass} / 失败 ${fail}`)
process.exit(fail === 0 ? 0 : 1)
