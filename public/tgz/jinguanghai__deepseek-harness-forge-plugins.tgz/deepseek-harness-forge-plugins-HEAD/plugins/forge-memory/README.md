# forge-memory

BM25 experience recall for DeepSeek Harness — the 铸剑炉 (Forge) memory
discipline as a plugin: keep the context short, pull in only what is relevant.

| Tool | Purpose |
|---|---|
| `memory_recall` | BM25-ranked recall of past key findings (top-K, fresh-window aware) |
| `memory_save` | Atomic save of a key finding (tmp + rename, keeps `.bak`) |
| `memory_fold` | Fold a long section into a short index entry |
| `memory_fold_deep` | Deep-read a folded section back to full content |

Data lives in `memory.json` / `.forge-temp/memory_current.json` /
`data/memory_current.json` — bring your own memory file (empty templates in
`data/`). No npm dependencies.
