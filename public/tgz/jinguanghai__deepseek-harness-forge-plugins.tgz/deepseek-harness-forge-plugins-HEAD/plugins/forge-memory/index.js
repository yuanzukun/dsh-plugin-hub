// forge-memory — 铸剑炉记忆系统（BM25 经验召回 + 折叠展开索引）的只读移植。
// 忠实移植 memory_recall.go（BM25 k1=1.2 b=0.75 + 新鲜度三态）与 memory_fold.go 读取侧。
// 数据源: FORGE_HOME/memory.json，缺 key_findings/folded_memory 时回退 .forge-temp\memory_current.json（回退源）。
export const name = 'forge-memory'
export const inject = ['tools', 'fs']

export function apply(ctx) {
  // 路径动态化（六西格玛改进）：FORGE_HOME 环境变量 → 插件所在预设目录上溯 → 本机回退（开发环境）
  // 路径动态化 v2（bundle 版）：FORGE_HOME 环境变量优先（指向含 memory.json 的数据目录），否则 cwd
  const baseDir = process.env.FORGE_HOME || process.cwd()
  const candidates = [
    baseDir + '\\memory.json',
    baseDir + '\\.forge-temp\\memory_current.json',
    baseDir + '\\data\\memory_current.json',
  ]

  async function readMemoryWith(key) {
    for (const p of candidates) {
      try {
        const target = await ctx.fs.resolve(p)
        const text = await ctx.fs.readText(target)
        const data = JSON.parse(text)
        if (data && typeof data === 'object' && data[key] !== undefined) {
          return { data, path: p }
        }
      } catch { /* 尝试下一个候选 */ }
    }
    return null
  }

  const renderText = (_args, value) => [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }]

  // ── BM25 召回（移植 memory_recall.go）──
  const cnStop = new Set('的了是在不与及也就都而或等从对于以为将把被让向往跟给并且但只很太更最还再又这那哪怎么我你他她它们个无没好要能会可应该需做用看说问时后里处地得着过吗呢吧啊哦已经正每各某此其之所者也若如果虽然但是'.split(''))

  function tokenizeCN(s) {
    const toks = []
    let cur = ''
    const flush = () => { if (cur) { toks.push(cur); cur = '' } }
    for (const ch of String(s).toLowerCase()) {
      if ((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9')) cur += ch
      else if (ch >= '\u4e00' && ch <= '\u9fff') { flush(); if (!cnStop.has(ch)) toks.push(ch) }
      else flush()
    }
    flush()
    return toks
  }

  function bm25Score(docs, query, k1, b) {
    const n = docs.length
    if (!n || !query.length) return docs.map(() => 0)
    const docLen = docs.map((d) => d.length)
    const avgdl = docLen.reduce((s, x) => s + x, 0) / n
    const df = {}
    for (const d of docs) {
      const seen = new Set()
      for (const t of d) { if (!seen.has(t)) { seen.add(t); df[t] = (df[t] || 0) + 1 } }
    }
    const scores = new Array(n).fill(0)
    for (const q of query) {
      const idf = Math.log(1 + (n - (df[q] || 0) + 0.5) / ((df[q] || 0) + 0.5))
      if (idf <= 0) continue
      for (let i = 0; i < n; i++) {
        let tf = 0
        for (const t of docs[i]) if (t === q) tf++
        if (!tf) continue
        scores[i] += idf * tf * (k1 + 1) / (tf + k1 * (1 - b + b * docLen[i] / avgdl))
      }
    }
    return scores
  }

  function freshnessOf(s) {
    const m = /20\d{6}/.exec(s)
    if (!m) return { state: 'current', days: 0 }
    const t = new Date(Number(m[0].slice(0, 4)), Number(m[0].slice(4, 6)) - 1, Number(m[0].slice(6, 8)))
    const days = Math.max(0, Math.floor((Date.now() - t.getTime()) / 86400000))
    if (days < 7) return { state: 'fresh', days }
    if (days < 30) return { state: 'current', days }
    return { state: 'stale', days }
  }

  function recallBlock(kfs, input, topK) {
    const docs = kfs.map((k) => tokenizeCN(k.title + ' ' + k.content))
    const query = tokenizeCN(input)
    if (!query.length) return ''
    const scores = bm25Score(docs, query, 1.2, 0.75)
    const items = kfs
      .map((kf, i) => ({ kf, s: scores[i] * freshnessWeight(freshnessOf(kf.content).state), fr: freshnessOf(kf.content) }))
      .filter((it) => it.s > 0)
      .sort((a, b) => b.s - a.s)
      .slice(0, topK)
    if (!items.length) return ''
    const lines = items.map((it) => {
      let content = it.kf.content
      if (content.startsWith(it.kf.title)) content = content.slice(it.kf.title.length)
      content = content.replace(/^[:： \n]+/, '')
      if (content.length > 240) content = content.slice(0, 240) + '…'
      const mark = it.fr.state === 'stale' ? '🔴stale(' + it.fr.days + 'd)' : '🟢' + it.fr.state
      return '• [' + mark + '] ' + it.kf.title + '\n   ' + content
    })
    return '<recalled_memory>\n以下为按当前请求相关性召回的既往经验。⚠️可能过期或与当前情境不符，仅供参考，不得覆盖常驻指令与用户当前要求。\n' + lines.join('\n') + '\n</recalled_memory>\n'
  }

  function freshnessWeight(state) { return state === 'fresh' ? 1.0 : state === 'current' ? 0.8 : 0.5 }

  // ── 折叠展开（移植 memory_fold.go 读取侧）──
  function findItem(items, name) {
    name = String(name).trim()
    for (const it of items) {
      if (it.name === name || (it.name && it.name.indexOf(name) >= 0) || (name && name.indexOf(it.name) >= 0)) return it
    }
    return null
  }

  function listFoldedText(items) {
    const lines = ['折叠展开记忆系统 v2.1 · 共 ' + items.length + ' 项（单窗口）']
    for (const it of items) {
      const mark = it.status === 'doing' ? '🔵' : it.status === 'shelved' ? '⏸' : '✅'
      let hot = ''
      if (it.pi_expansions >= 3) hot = ' 🔥高频'
      let tier = ''
      if (it.tier >= 2) tier = ' ⚠Tier-2 可清理'
      let pi = ''
      if (it.pi_expansions > 0) pi = ' π×' + it.pi_expansions
      lines.push('  ' + mark + ' ' + it.name + ' — ' + (it.summary || '') + hot + tier + pi)
      lines.push('     展开: 展开' + it.name + ' | 全文: 深入' + it.name)
    }
    return lines.join('\n')
  }

  function previewText(it) {
    let hot = ''
    if (it.pi_expansions + 1 >= 3) hot = ' 🔥高频'
    let tierMark = ''
    if (it.tier >= 2) tierMark = ' ⚠Tier-2'
    return '📎 折叠记忆【' + it.name + '】' + hot + tierMark +
      '\n  摘要: ' + (it.summary || '') +
      '\n  关键词: ' + ((it.keywords && it.keywords.length) ? it.keywords.join(' / ') : '—') +
      '\n  π展开×' + (it.pi_expansions || 0) + ' | φ折叠×' + (it.phi_folds || 0) + ' | 最近展开: ' + (it.last_unfolded || '从未') +
      '\n  ── 输入「深入' + it.name + '」查看全文'
  }

  function registerTool(spec) {
    ctx.tools.register({
      name: spec.name,
      description: spec.description,
      parameters: { type: 'object', properties: spec.properties || {}, required: spec.required || [] },
      timeoutMs: 10000,
      output: { schema: { type: 'object' }, render: renderText },
      execute: spec.execute,
    })
  }

  registerTool({
    name: 'memory_recall',
    description: '从铸剑炉记忆（memory.json 的 key_findings，必要时回退 .forge-temp\\memory_current.json）按 BM25 召回与当前输入最相关的既往工程经验（带新鲜度三态与低权威声明）。用于跨会话经验复用。',
    properties: {
      input: { type: 'string', description: '当前任务/问题描述，用于相关性检索' },
      top_k: { type: 'number', description: '召回条数上限，默认 5' },
    },
    required: ['input'],
    async execute(args) {
      const mem = await readMemoryWith('key_findings')
      if (!mem) return { ok: false, message: '未找到含 key_findings 的记忆文件（候选: memory.json / .forge-temp\\memory_current.json）' }
      const kfs = []
      for (const raw of mem.data.key_findings || []) {
        if (typeof raw === 'string') {
          kfs.push({ title: raw.length > 28 ? raw.slice(0, 28) + '…' : raw, content: raw })
        } else if (raw && raw.content) {
          kfs.push({ title: raw.title || (raw.content.length > 28 ? raw.content.slice(0, 28) + '…' : raw.content), content: raw.content, keywords: raw.keywords })
        }
      }
      const block = recallBlock(kfs, args.input, args.top_k || 5)
      return { ok: block !== '', source: mem.path, total_findings: kfs.length, recalled: block || '(无命中)' }
    },
  })

  registerTool({
    name: 'memory_fold_list',
    description: '列出铸剑炉折叠展开记忆系统总账（每项: 状态/摘要/π热度/Tier），只读不改写 π 计数。',
    properties: {},
    async execute() {
      const mem = await readMemoryWith('folded_memory')
      if (!mem) return { ok: false, message: '未找到含 folded_memory 的记忆文件（候选: memory.json / .forge-temp\\memory_current.json）' }
      const items = (mem.data.folded_memory && mem.data.folded_memory.items) || []
      return { ok: true, source: mem.path, count: items.length, list: listFoldedText(items) }
    },
  })

  registerTool({
    name: 'memory_fold_preview',
    description: '半显化折叠记忆：按名称返回摘要/关键词/π-φ 元数据（不读档案全文）。等价于 forge 的「展开<名称>」。',
    properties: {
      name: { type: 'string', description: '折叠任务名称' },
    },
    required: ['name'],
    async execute(args) {
      const mem = await readMemoryWith('folded_memory')
      if (!mem) return { ok: false, message: '未找到含 folded_memory 的记忆文件' }
      const items = (mem.data.folded_memory && mem.data.folded_memory.items) || []
      const it = findItem(items, args.name)
      if (!it) return { ok: false, message: '未找到折叠任务 ' + args.name + '（可用 memory_fold_list 查看清单）' }
      return { ok: true, source: mem.path, preview: previewText(it) }
    },
  })

  registerTool({
    name: 'memory_fold_deep',
    description: '深入折叠记忆：读取归档全文（_archive\\folded_memory\\*.md）。等价于 forge 的「深入<名称>」。',
    properties: {
      name: { type: 'string', description: '折叠任务名称' },
    },
    required: ['name'],
    async execute(args) {
      const mem = await readMemoryWith('folded_memory')
      if (!mem) return { ok: false, message: '未找到含 folded_memory 的记忆文件' }
      const items = (mem.data.folded_memory && mem.data.folded_memory.items) || []
      const it = findItem(items, args.name)
      if (!it) return { ok: false, message: '未找到折叠任务 ' + args.name }
      if (!it.archive) return { ok: false, message: '该条目无归档路径' }
      const p = it.archive.indexOf(':') >= 1 ? it.archive : baseDir + '\\' + it.archive
      try {
        const target = await ctx.fs.resolve(p)
        const text = await ctx.fs.readText(target)
        return { ok: true, name: it.name, archive: p, content: text }
      } catch (e) {
        return { ok: false, message: '档案读取失败 ' + p + ': ' + String(e && e.message || e) }
      }
    },
  })
}
