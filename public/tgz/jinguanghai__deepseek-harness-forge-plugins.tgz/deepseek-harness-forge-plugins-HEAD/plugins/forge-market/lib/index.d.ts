/**
 * dsh-forge-market — forge 死市场插件
 *
 * 哲学：插件多是好事，多而有法。本插件是"死的货架 + 死的开单器"：
 *  - 数据全死：catalog/plugins.json（随包发布，离线清单）
 *  - 动作全走官方通道：只生成安装提案，安装由官方 dsh plugin CLI 执行
 *  - 判定全死：vetter 三级分档（A 纯死 / B 裸通道死壳 / C 真活拒收）
 *  - 三公理为准入母法：注意力税（一）/ 证据实测（二）/ 噪音纪律（三）
 *
 * @module dsh-forge-market
 * @license MIT
 */
/** Cordis 插件上下文最小接口。 */
export interface ContextLike {
    tools: {
        register(def: unknown): void;
    };
    logger?: {
        info(msg: string): void;
    };
}
export declare const inject: string[];
export declare function apply(ctx: ContextLike): void;
//# sourceMappingURL=index.d.ts.map