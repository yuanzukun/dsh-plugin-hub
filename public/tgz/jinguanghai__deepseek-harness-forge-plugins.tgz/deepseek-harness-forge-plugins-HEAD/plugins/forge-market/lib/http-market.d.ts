/** 启动本地市场服务（幂等：已监听则跳过）。 */
export declare function startMarketServer(): any;
//# sourceMappingURL=http-market.d.ts.map