// 铸剑炉专柜建档：扫描自家插件，vetter + 铸剑炉专属检查，写入 catalog 的 forgeMeta
import { readFileSync, readdirSync, writeFileSync, statSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
import { vet, summarize, listCodeFiles } from '../vetter/vetter.mjs'

const FORGE_PLUGINS = 'D:/forge_release/dsh-forge-plugins/plugins'
const CATALOG = new URL('./plugins.json', import.meta.url)

// 铸剑炉专属检查（规则化）
function forgeMetaOf(dir, name) {
  const meta = { evidence: 'warn', memory: 'warn', permission: 'warn', antiSycophancy: 'warn' }
  // 收集代码文本
  let code = ''
  try {
    for (const f of listCodeFiles(dir)) {
      try { code += readFileSync(f, 'utf-8') } catch {}
    }
  } catch {}
  // 文档文本
  let docs = ''
  for (const f of ['README.md', 'README.zh.md']) {
    try { docs += readFileSync(join(dir, f), 'utf-8') } catch {}
  }
  // 1. 证据铁律：代码/文档含证据机制
  if (/evidence|audit|审计|证据|claimPatterns/.test(code + docs)) meta.evidence = 'pass'
  // 2. 记忆纪律：含记忆管理
  if (/memory|记忆|recall|anchor|锚/.test(code + docs)) meta.memory = 'pass'
  // 3. 权限声明：package.json forge.permission 或文档权限段
  try {
    const pkg = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf-8'))
    if (pkg.forge?.permission) meta.permission = pkg.forge.permission
    else if (/L0|L1|L2|L3|权限|permission/.test(docs)) meta.permission = 'declared'
  } catch {}
  // 4. 反讨好：文档含反讨好声明
  if (/反讨好|sycophancy|讨好|奉承/.test(docs)) meta.antiSycophancy = 'pass'
  return meta
}

const catalog = JSON.parse(readFileSync(CATALOG, 'utf-8'))
const entries = []
let scanErr = 0

for (const d of readdirSync(FORGE_PLUGINS)) {
  const dir = join(FORGE_PLUGINS, d)
  if (!statSync(dir).isDirectory()) continue
  const pkgFile = join(dir, 'package.json')
  if (!existsSync(pkgFile)) continue
  let pkg = {}
  try { pkg = JSON.parse(readFileSync(pkgFile, 'utf-8')) } catch {}
  const name = pkg.name ?? 'dsh-' + d
  let report = null
  try { report = summarize(vet(dir)) } catch { scanErr++; continue }

  const entry = {
    id: name,
    category: d.includes('guard') ? 'guard' : d.includes('tcm') ? 'tool' : d.includes('memory') ? 'service' : d.includes('market') ? 'market' : 'tool',
    version: pkg.version ?? '0.1.0',
    source: 'github:jinguanghai/deepseek-harness-forge-plugins#' + d,
    sha512: (() => { try { const h = createHash('sha512'); for (const f of listCodeFiles(dir).sort()) { try { h.update(f.replace(/\\\\/g, '/')); h.update('\u0000'); h.update(readFileSync(f, 'utf-8')) } catch {} } return h.digest('hex') } catch { return null } })(),
    vetter: {
      verdict: report.verdict, filesScanned: report.files, sourceBytes: report.sourceBytes,
      attentionOK: report.attentionOK, hasReadme: report.hasReadme,
      liveCount: report.liveCount, bareCount: report.bareCount, supplyCount: report.supplyCount,
      exemptCount: report.exemptCount, rules: report.rules,
    },
    axioms: {
      attention: report.attentionOK ? 'pass' : 'fail',
      evidence: report.liveCount === 0 ? 'pass' : 'fail',
      noise: report.hasReadme && report.files <= 60 ? 'pass' : 'warn',
    },
    admitted: report.verdict === 'A',
    status: report.verdict === 'A' ? 'admitted' : report.verdict === 'B' ? 'review' : 'rejected',
    added: '2026-08-21',
    forge: {
      family: '铸剑炉',
      meta: forgeMetaOf(dir, name),
    },
  }
  entries.push(entry)
  console.log((entry.admitted ? 'OK' : '  ') + ' ' + entry.id + ' ' + report.verdict + ' evidence=' + entry.forge.meta.evidence + ' memory=' + entry.forge.meta.memory + ' perm=' + entry.forge.meta.permission)
}

// 合并：forge 条目覆盖/加入 catalog（按 id 更新，forge 条目置顶）
const oldPlugins = (catalog.plugins ?? []).filter(p => !entries.some(e => e.id === p.id))
catalog.plugins = [...entries, ...oldPlugins]
catalog.schemaVersion = '0.4.0'
catalog.note = 'forge 死市场：铸剑炉专柜（forgeMeta 专属判定）+ 官方货架。'
writeFileSync(CATALOG, JSON.stringify(catalog, null, 2), 'utf-8')
console.log('铸剑炉专柜: ' + entries.length + ' 个 / 清单总数: ' + catalog.plugins.length)
