// 建档工具：对样本插件跑 vetter + 算 sha512，汇总生成 catalog/plugins.json
// 放 catalog/ 目录：开发期工具，不参与插件目录扫描
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { vet, summarize, listCodeFiles } from '../vetter/vetter.mjs'

const SAMPLES = [
  { id: 'dsh-evidence-first', path: 'D:/forge_release/dsh-forge-plugins/plugins/evidence-first', category: 'guard',    version: '0.2.1', source: 'github:jinguanghai/deepseek-harness-forge-plugins#plugins/evidence-first' },
  { id: 'dsh-forge-gates',    path: 'D:/forge_release/dsh-forge-plugins/plugins/forge-gates',    category: 'tool',     version: '0.1.0', source: 'github:jinguanghai/deepseek-harness-forge-plugins#plugins/forge-gates' },
  { id: 'dsh-forge-memory',   path: 'D:/forge_release/dsh-forge-plugins/plugins/forge-memory',   category: 'service',  version: '0.1.0', source: 'github:jinguanghai/deepseek-harness-forge-plugins#plugins/forge-memory' },
  { id: 'dsh-forge-tcm',      path: 'D:/forge_release/dsh-forge-plugins/plugins/forge-tcm',      category: 'tool',     version: '0.1.0', source: 'github:jinguanghai/deepseek-harness-forge-plugins#plugins/forge-tcm' },
  { id: 'dsh-guard',          path: 'D:/forge_release/dsh-forge-plugins/plugins/guard',          category: 'guard',    version: '0.1.0', source: 'github:jinguanghai/deepseek-harness-forge-plugins#plugins/guard' },
  { id: 'dsh-tool-fs',        path: 'D:/deepseek-harness-src/packages/fs/tool-fs',               category: 'tool',     version: 'rc.8',  source: 'github:deepseek-ai/deepseek-harness#packages/fs/tool-fs' },
  { id: 'dsh-guard-timeout',  path: 'D:/deepseek-harness-src/packages/guard/timeout-policy',      category: 'guard',    version: 'rc.8',  source: 'github:deepseek-ai/deepseek-harness#packages/guard/timeout-policy' },
  { id: 'dsh-plugin-inventory', path: 'D:/deepseek-harness-src/packages/host/plugin-inventory',   category: 'service',  version: 'rc.8',  source: 'github:deepseek-ai/deepseek-harness#packages/host/plugin-inventory' },
  { id: 'dsh-tool-skill',     path: 'D:/deepseek-harness-src/packages/skill/tool-skill',          category: 'tool',     version: 'rc.8',  source: 'github:deepseek-ai/deepseek-harness#packages/skill/tool-skill' },
  { id: 'dsh-market(反面样本)', path: 'D:/forge_release/dsh-forge-plugins/plugins/forge-market/tests/fixtures/dsh-market-src', category: 'market', version: 'main', source: 'github:dsh-market/dsh-market#src（片段）' },
]

function dirHash(root) {
  let files
  try { files = listCodeFiles(root) } catch { return null }
  files.sort()
  const h = createHash('sha512')
  for (const f of files) {
    const rel = f.replace(/\\/g, '/')
    let content
    try { content = readFileSync(f, 'utf-8') } catch { continue }
    h.update(rel)
    h.update('\u0000')
    h.update(content)
  }
  return h.digest('hex')
}

const entries = []
for (const s of SAMPLES) {
  let report = null, err = null
  try { report = summarize(vet(s.path)) } catch (e) { err = e.message }
  entries.push({
    id: s.id,
    category: s.category,
    version: s.version,
    source: s.source,
    sha512: err ? null : dirHash(s.path),
    vetter: report ? {
      verdict: report.verdict,
      filesScanned: report.files,
      sourceBytes: report.sourceBytes,
      attentionOK: report.attentionOK,
      hasReadme: report.hasReadme,
      liveCount: report.liveCount,
      bareCount: report.bareCount,
      supplyCount: report.supplyCount,
      rules: report.rules,
    } : { error: err },
    axioms: report ? {
      attention: report.attentionOK ? 'pass' : 'fail（超预算）',
      evidence: report.liveCount === 0 ? 'pass' : 'fail（含真活结构）',
      noise: report.hasReadme && report.files <= 60 ? 'pass' : 'warn',
    } : { error: err },
    // A 档才上架；B 档记录待复核（改造走 ctx 服务后可复议）
    admitted: report ? (report.verdict === 'A') : false,
    status: report ? (report.verdict === 'A' ? 'admitted' : report.verdict === 'B' ? 'review' : 'rejected') : 'error',
    added: '2026-08-21',
  })
}

const catalog = {
  schemaVersion: '0.2.0',
  updated: '2026-08-21',
  note: 'forge 死市场首批建档。admitted=true 才可上架；review=裸通道死壳待改造；rejected=真活拒收。',
  plugins: entries,
}
writeFileSync(new URL('./plugins.json', import.meta.url), JSON.stringify(catalog, null, 2), 'utf-8')

for (const e of entries) {
  const v = e.vetter
  const tag = e.status === 'admitted' ? '✅收' : e.status === 'review' ? '🟡候' : '❌拒'
  console.log(`${tag} ${e.id.padEnd(24)} ${(v.verdict ?? 'ERR').padEnd(3)} live=${v.liveCount} bare=${v.bareCount} supply=${v.supplyCount} bytes=${v.sourceBytes}`)
}
console.log(`\n入库 ${entries.filter(e => e.admitted).length} / 待复核 ${entries.filter(e => e.status === 'review').length} / 拒收 ${entries.filter(e => e.status === 'rejected').length} → catalog/plugins.json`)
