// 批量建档：扫描 DSH 官方全部 @deepseek-ai/dsh-* 插件包，vetter 判定后合并进 catalog/plugins.json
import { readFileSync, readdirSync, writeFileSync, statSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
import { vet, summarize, listCodeFiles } from '../vetter/vetter.mjs'

const PACKAGES = 'D:/deepseek-harness-src/packages'
const CATALOG = new URL('./plugins.json', import.meta.url)

// 1. 收集官方插件包（含 package.json 且 name 以 @deepseek-ai/dsh- 开头）
function collectPackages(root) {
  const out = []
  const walk = (dir) => {
    let entries
    try { entries = readdirSync(dir) } catch { return }
    for (const name of entries) {
      if (name === 'node_modules' || name === 'lib' || name === 'tests') continue
      const p = join(dir, name)
      let st
      try { st = statSync(p) } catch { continue }
      if (st.isDirectory()) {
        const pkg = join(p, 'package.json')
        if (existsSync(pkg)) {
          try {
            const j = JSON.parse(readFileSync(pkg, 'utf-8'))
            if (typeof j.name === 'string' && j.name.startsWith('@deepseek-ai/dsh-')) {
              out.push({ name: j.name, dir: p, version: j.version ?? 'rc.8' })
              continue
            }
          } catch {}
        }
        walk(p)
      }
    }
  }
  walk(root)
  return out
}

// 2. 品类推断
function categoryOf(name) {
  if (name.includes('ui-')) return 'ui'
  if (name.includes('tool-')) return 'tool'
  if (name.includes('guard')) return 'guard'
  if (name.includes('skill')) return 'skill'
  if (name.includes('client-')) return 'client'
  if (name.includes('bundle')) return 'bundle'
  return 'service'
}

// 3. 目录 sha512（同 build-catalog）
function dirHash(root) {
  let files
  try { files = listCodeFiles(root) } catch { return null }
  files.sort()
  const h = createHash('sha512')
  for (const f of files) {
    let content
    try { content = readFileSync(f, 'utf-8') } catch { continue }
    h.update(f.replace(/\\/g, '/'))
    h.update('\u0000')
    h.update(content)
  }
  return h.digest('hex')
}

// 4. 跑判定
const pkgs = collectPackages(PACKAGES)
const entries = []
let a = 0, b = 0, c = 0, err = 0
for (const p of pkgs) {
  let report = null, errMsg = null
  try { report = summarize(vet(p.dir)) } catch (e) { errMsg = String(e?.message ?? e) }
  if (report) {
    if (report.verdict === 'A') a++
    else if (report.verdict === 'B') b++
    else c++
    entries.push({
      id: p.name,
      category: categoryOf(p.name),
      version: p.version,
      source: 'github:deepseek-ai/deepseek-harness#' + p.dir.replace(/\\/g, '/').replace('D:/deepseek-harness-src/', ''),
      sha512: dirHash(p.dir),
      vetter: {
        verdict: report.verdict, filesScanned: report.files, sourceBytes: report.sourceBytes,
        attentionOK: report.attentionOK, hasReadme: report.hasReadme,
        liveCount: report.liveCount, bareCount: report.bareCount, supplyCount: report.supplyCount,
        exemptCount: report.exemptCount, rules: report.rules,
      },
      axioms: {
        attention: report.attentionOK ? 'pass' : 'fail',
        evidence: report.liveCount === 0 ? 'pass' : 'fail',
        noise: report.hasReadme && report.files <= 60 ? 'pass' : 'warn',
      },
      admitted: report.verdict === 'A',
      status: report.verdict === 'A' ? 'admitted' : report.verdict === 'B' ? 'review' : 'rejected',
      added: '2026-08-21',
    })
  } else {
    err++
  }
}

// 5. 合并原清单（保留已有条目，批量条目放后面；去重按 id）
let existing = []
try {
  const old = JSON.parse(readFileSync(CATALOG, 'utf-8'))
  existing = old.plugins ?? []
} catch {}

const merged = [...existing]
const seen = new Set(existing.map(e => e.id))
for (const e of entries) {
  if (!seen.has(e.id)) { merged.push(e); seen.add(e.id) }
}

const catalog = {
  schemaVersion: '0.3.0',
  updated: '2026-08-21',
  note: 'forge 死市场：官方 226 包批量建档 + 原有条目。admitted=收录 / review=待复核 / rejected=拒收。',
  plugins: merged,
}
writeFileSync(CATALOG, JSON.stringify(catalog, null, 2), 'utf-8')

console.log(JSON.stringify({ 官方包: pkgs.length, A档: a, B档: b, C档: c, 判定失败: err, 清单总数: merged.length }, null, 1))
