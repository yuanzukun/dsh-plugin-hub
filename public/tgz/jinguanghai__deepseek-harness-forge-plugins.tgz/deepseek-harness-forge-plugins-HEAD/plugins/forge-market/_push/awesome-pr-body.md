### Add dsh-forge-market — dead-shell plugin market for DeepSeek Harness

**Category:** Plugin Markets & Managers

**Repo:** https://github.com/jinguanghai/deepseek-harness-forge-plugins/tree/main/plugins/forge-market
**npm:** dsh-forge-market

**What it is:** A plugin market that only admits *dead-shell* plugins. Three-axiom admission
(attention is scarce / claims need execution evidence / uncurated content is noise), a
self-hosting vetter with three verdict tiers (A pure-dead / B bare-channel / C live), an
offline versioned catalog, and proposals only — no network fetching, no self-update, no
runtime config writes, no sandbox bypass. Verified locally in DSH (ef-test profile): 5
tools (market_list/inspect/vet/propose/audit) exercised by a live agent.

**Why it matters:** Many plugins is good — but a market that fetches, self-updates and
rewrites config is a live supply chain. This market treats itself as a dead fence: the
manager obeys the same rules it enforces.

Suggested line:

```markdown
- [dsh-forge-market](https://github.com/jinguanghai/deepseek-harness-forge-plugins/tree/main/plugins/forge-market) — 死市场：三公理准入 + 死壳判定（A/B/C 分档），离线清单，只出提案不执行安装。The dead-shell plugin market: three-axiom admission, vetter tiers, offline catalog, proposals only.
```
