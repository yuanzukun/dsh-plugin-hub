import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join, extname, relative } from 'node:path'

const rulesPath = new URL('./rules.json', import.meta.url)
const RULES = JSON.parse(readFileSync(rulesPath, 'utf-8'))
export const L1_LIVE = RULES.L1_live.map(r => [new RegExp(r.pattern), r.rule])
export const L1_BARE = RULES.L1_bare.map(r => [new RegExp(r.pattern), r.rule])
export const L1_SUPPLY = RULES.L1_supply.map(r => [new RegExp(r.pattern), r.rule])

const CODE_EXTS = new Set(['.ts', '.tsx', '.js', '.mjs', '.cjs', '.jsx'])
const SKIP_DIRS = new Set(['node_modules', '.git', 'lib', 'dist', 'tests', 'test', 'coverage', '.forge', '.dsh-build', 'fixtures', 'catalog'])

function isTestFile(name) {
  return /^test[-_.]|\\.test\\./.test(name)
}

export function scanText(src, rules) {
  const hits = []
  for (const [re, rule] of rules) {
    const m = re.exec(src)
    if (m) hits.push({ rule, context: src.slice(Math.max(0, m.index - 22), m.index + 40).replace(/\n/g, ' ') })
  }
  return hits
}

export function listCodeFiles(root) {
  const out = []
  const walk = (dir) => {
    for (const name of readdirSync(dir)) {
      if (SKIP_DIRS.has(name) || isTestFile(name)) continue
      const p = join(dir, name)
      const st = statSync(p)
      if (st.isDirectory()) walk(p)
      else if (CODE_EXTS.has(extname(name))) out.push(p)
    }
  }
  if (statSync(root).isDirectory()) walk(root)
  else out.push(root)
  return out
}

export function vet(root) {
  const files = listCodeFiles(root)
  const report = {
    target: root,
    filesScanned: files.length,
    live: [],
    bare: [],
    supply: [],
    exempt: [],
    verdict: 'A',
  }
  for (const f of files) {
    let src
    try { src = readFileSync(f, 'utf-8') } catch { continue }
    const rel = relative(root, f)
    // C 级：真活结构（动态执行/裸进程/命令执行）——直接拒
    for (const h of scanText(src, L1_LIVE)) {
      report.live.push({ file: rel, ...h })
      report.verdict = 'C'
    }
    // B 级：裸通道死壳（确定性动作但绕过 ctx 服务）
    // 自身数据目录写豁免（通用规则）：写插件自身 data/ 账本 ≠ 绕过围栏改本体。
    // 静态近似（文件含自身数据模式），命中记入 exempt 可审计；L3 沙箱实测兜底。
    const ownDataPattern = /['"](?:data|logs?)[\\/\\]|audit\.jsonl/
    for (const h of scanText(src, L1_BARE)) {
      if (ownDataPattern.test(src)) {
        report.exempt.push({ file: rel, ...h, note: 'own-data-write (self data dir)' })
        continue
      }
      report.bare.push({ file: rel, ...h })
      if (report.verdict !== 'C') report.verdict = 'B'
    }
    // B 级：供应链/远程模式
    for (const h of scanText(src, L1_SUPPLY)) {
      report.supply.push({ file: rel, ...h })
      if (report.verdict !== 'C') report.verdict = 'B'
    }
  }
  let bytes = 0
  for (const f of files) { try { bytes += statSync(f).size } catch {} }
  report.sourceBytes = bytes
  report.attentionOK = bytes <= RULES.A1.maxSourceBytes
  if (!report.attentionOK && report.verdict === 'A') report.verdict = 'B'
  report.hasReadme = hasReadme(root)
  if (!report.hasReadme && report.verdict === 'A') report.verdict = 'B'
  return report
}

function hasReadme(root) {
  try { return readdirSync(root).some(n => /^README/i.test(n)) } catch { return false }
}

export function summarize(report) {
  const rules = new Set()
  for (const h of [...report.live, ...report.bare, ...report.supply]) rules.add(h.rule)
  for (const h of report.exempt) rules.add(h.rule + '(own-data豁免)')
  return {
    target: report.target,
    files: report.filesScanned,
    sourceBytes: report.sourceBytes,
    attentionOK: report.attentionOK,
    hasReadme: report.hasReadme,
    liveCount: report.live.length,
    bareCount: report.bare.length,
    supplyCount: report.supply.length,
    exemptCount: report.exempt.length,
    verdict: report.verdict,
    rules: [...rules],
  }
}