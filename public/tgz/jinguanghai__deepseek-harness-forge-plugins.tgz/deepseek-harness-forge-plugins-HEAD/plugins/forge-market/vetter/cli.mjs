import { vet, summarize } from './vetter.mjs'
const targets = process.argv.slice(2)
if (!targets.length) { console.error('usage: node cli.mjs <dir-or-file>...'); process.exit(2) }
for (const t of targets) {
  try { console.log(JSON.stringify(summarize(vet(t)), null, 1)) }
  catch (e) { console.log(JSON.stringify({ target: t, error: e.message })) }
}
