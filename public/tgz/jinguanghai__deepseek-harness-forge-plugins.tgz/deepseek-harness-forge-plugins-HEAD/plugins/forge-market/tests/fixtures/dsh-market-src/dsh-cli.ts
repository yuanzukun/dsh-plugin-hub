// 片段重建（会话取证：真实 dsh-market src/dsh-cli.ts 前段）
/** Process layer: re-invoking the dsh CLI that launched this host, spawning
 * `dsh plugin` commands with timeouts and live progress, and provisioning
 * pnpm. This is the only module that starts child processes.
 * Installs run through node:child_process, not ctx.shell: the shell service is
 * the agent's sandboxed executor and denies writes to the profile directory. */
import { spawn } from 'node:child_process'
// pnpm 安装脚本: https://get.pnpm.io/install.ps1
