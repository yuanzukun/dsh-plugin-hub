// 片段重建（会话取证：真实 dsh-market src/updates.ts 前段）
/** Update detection: per-plugin comparison of what the profile has against
 * the source of truth — git HEAD for github installs, the npm latest
 * dist-tag for registry installs — with a TTL cache. */
const latest = await fetchJson(`https://registry.npmjs.org/${encodeURIComponent(name)}`)
