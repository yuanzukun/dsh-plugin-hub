// 片段重建（会话取证：真实 dsh-market src/install.ts 前段）
/** Install orchestration: collection-repo retargeting, post-install
 * validation that keeps broken pieces from bricking the next boot, and
 * update staleness detection. Every function takes the plugin runner as a
 * parameter so tests can substitute a recording fake. */
export const RELEASE_AGE_OVERRIDE = '--config.minimumReleaseAge=0'
export const FETCH_TIMEOUT_OVERRIDE = '--config.fetchTimeout=600000'
/** pnpm-major drift, release-age lockfile lock, per-request fetch timeout */
export async function withHoistRecovery(run) {
  // retries pnpm commands with recovery from three known pnpm traps
}
