// 片段重建（会话取证：真实 dsh-market src/patch.ts 前段）
/** Patch-layer plugin toggles — hot disable/enable through the profile's
 * user patch layer (cordis.patch.yml), the mechanism ported from
 * Noob-stupid/dsh-plugin-hub's plugin console. */
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
// writes serialized; host infrastructure rows protected
