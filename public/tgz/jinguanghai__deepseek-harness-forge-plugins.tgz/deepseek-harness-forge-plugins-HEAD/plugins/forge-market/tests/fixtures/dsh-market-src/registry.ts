// 片段重建（会话取证：真实 dsh-market src/registry.ts 前段）
/** Registry access: the curated list from awesome-dsh-plugin.com, fetched
 * fresh on every request. */
export const REGISTRY_URL = 'https://awesome-dsh-plugin.com/plugins.json'
