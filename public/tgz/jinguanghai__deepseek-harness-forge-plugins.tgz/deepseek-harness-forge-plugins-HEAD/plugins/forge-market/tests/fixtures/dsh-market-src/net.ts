// 片段重建（会话取证：真实 dsh-market src/net.ts 片段）
export async function marketFetch(url, init) {
  if (proxy == null) return await fetch(url, init)
}
