# dsh-forge-market

**A dead-shell plugin market for DeepSeek Harness.** 只收死程序插件的 DSH 插件市场。

The DSH philosophy is *everything is a plugin* — many plugins is good. But "many" without
discipline is noise. This plugin is a **dead marketplace**: a shelf of vetted plugins and a
proposal generator, nothing more. No remote fetching, no self-update, no runtime config
rewrites, no sandbox bypass. Data ships with the package; actions go through the official
`dsh plugin` CLI; the only live decision-maker is the human operator.

## Why

LLMs have scarce attention (Axiom 1 of the forge): every resident tool schema taxes the
context, every extra tool raises selection entropy. A plugin market that installs anything,
pulls fresh catalogs from the network, and updates itself is a *live supply chain* — the
antithesis of a dead fence. This plugin treats the market itself as a fence that must be dead:
**the manager obeys the same rules it enforces.**

## Three axioms of admission

1. **Attention is scarce** — resident tool definitions must stay under budget (A1).
2. **LLMs are statistical — claims must be verified by execution** — every capability needs
   sandbox-measured evidence, not README promises (A2).
3. **Uncurated memory is noise** — no redundant tools, no filler, documented purpose only (A3).

## Verdict tiers (vetter)

| Tier | Meaning | Admission |
|---|---|---|
| **A** | Pure dead shell (zero live structures, zero bare-channel access) | admitted |
| **B** | Bare-channel shell (deterministic actions that bypass `ctx` services) | review — refactor to ctx services, then re-vet |
| **C** | Live (process modules, eval, dynamic import, command execution) | rejected |

Rules are data-driven in `vetter/rules.json` (9 bare + 2 supply + attention budget).
The vetter is **self-hosting**: it must pass its own checks (regression T6).

## Tools

| Tool | What it does |
|---|---|
| `market_list` | List catalog entries (filter by status/category). Read-only. |
| `market_inspect` | Full health report for one plugin (verdict, hits, axioms, sha512). Read-only. |
| `market_vet` | Run the dead-shell judgement on a local path. Read-only. |
| `market_propose` | Generate an install proposal (pinned version + sha512 + source) for admitted plugins only. Does NOT install. |
| `market_audit` | Read the append-only audit trail of market operations. Read-only. |

## Install

```bash
dsh plugin add dsh-forge-market
```

Or link locally (in your profile package.json):

```json
"dsh-forge-market": "link:D:/path/to/plugins/forge-market"
```

## Catalog

`catalog/plugins.json` ships with the package (offline, versioned). Each entry carries
category, pinned version, sha512, the vetter report, and the three-axiom check. Rebuild it:

```bash
node catalog/build-catalog.mjs
```

## Design rules (what this plugin refuses to do)

- No network fetching (catalog is offline; updates ship with the package)
- No self-update (version follows the host upgrade flow)
- No runtime writes to `cordis.patch.yml` (enable/disable goes through official channels)
- No sandbox bypass (no bare `child_process`/fetch — only `ctx` services)
- No resident injection (tool definitions appear on demand)

## Self-hosting

The vetter scans itself in regression T6 and must stay A-tier. The catalog builder
(`catalog/`) is a dev-time tool, excluded from the plugin scan. Rules live in JSON
(data, not code) so the judge does not trip over its own rulebook.

## License

MIT
