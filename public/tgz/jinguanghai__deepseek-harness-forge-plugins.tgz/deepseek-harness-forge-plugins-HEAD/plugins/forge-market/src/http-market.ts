/**
 * 本地回环市场界面服务（127.0.0.1:18766）。
 * 零额外依赖：node:http 起本地服务，自带 HTML 界面 + JSON API。
 * 只读接口（catalog/vet/propose 均不执行安装）；绑定 127.0.0.1 不暴露外网。
 * 图形界面的最优解：绕开 Typert remote 协议深水区，浏览器直接打开即是市场。
 */
import { createServer } from 'node:http'
import { readFileSync } from 'node:fs'

const PORT = 18766
const HOST = '127.0.0.1'

/** 从模块路径定位插件根目录的 data/catalog（lib/ 的上一级）。 */
function rootDir(): string {
  return new URL('../', import.meta.url).pathname
}

function loadCatalog(): any {
  try {
    return JSON.parse(readFileSync(new URL('../catalog/plugins.json', import.meta.url), 'utf-8'))
  } catch {
    return { note: 'catalog 缺失', plugins: [] }
  }
}

/** HTML 界面（自包含：中文，内嵌 CSS/JS，无外部资源）。 */
/** HTML 界面（铸剑炉版：专柜置顶 + 专属徽章 + 官方货架）。 */
function marketHtml(catalog: any): string {
  const all = catalog.plugins ?? []
  const forge = all.filter((p: any) => p.forge?.family === '铸剑炉')
  const others = all.filter((p: any) => p.forge?.family !== '铸剑炉')

  const card = (p: any, forgeStyle: boolean): string => {
    const v = p.vetter ?? {}
    const statusText = p.status === 'admitted' ? '已收录' : p.status === 'review' ? '待复核' : '已拒收'
    const statusColor = p.status === 'admitted' ? '#2e7d32' : p.status === 'review' ? '#b26a00' : '#c62828'
    const verdictText = v.verdict === 'A' ? '纯死' : v.verdict === 'B' ? '裸通道' : v.verdict === 'C' ? '真活' : '—'
    const axioms = p.axioms ?? {}
    const fm = p.forge?.meta ?? {}
    const forgeBadges = forgeStyle ? `<div class="fbadges">证据铁律 <b>${fm.evidence ?? '—'}</b> · 记忆纪律 <b>${fm.memory ?? '—'}</b> · 权限 <b>${fm.permission ?? '—'}</b> · 反讨好 <b>${fm.antiSycophancy ?? '—'}</b></div>` : ''
    return `<div class="card${forgeStyle ? ' forge-card' : ''}" data-id="${p.id}">
      <div class="row">
        <span class="id">${p.id}</span>
        ${forgeStyle ? '<span class="forge-tag">铸剑炉</span>' : ''}
        <span class="chip">${p.category}</span>
        <span class="chip verdict v${v.verdict}">${verdictText}</span>
        <span class="chip status" style="color:${statusColor}">${statusText}</span>
        <span class="ver">v${p.version}</span>
      </div>
      <div class="meta">live=${v.liveCount ?? 0} · bare=${v.bareCount ?? 0} · supply=${v.supplyCount ?? 0} · ${v.sourceBytes ?? 0}B · sha512 ${p.sha512 ? p.sha512.slice(0,12)+'…' : '—'}</div>
      <div class="axioms">三公理：注意力 <b>${axioms.attention ?? '—'}</b> · 证据 <b>${axioms.evidence ?? '—'}</b> · 噪音 <b>${axioms.noise ?? '—'}</b></div>
      ${forgeBadges}
      <div class="actions"><button onclick="propose('\${p.id}')">生成安装提案</button> <span id="prop-\${p.id}"></span></div>
    </div>`
  }

  const forgeRows = forge.map((p: any) => card(p, true)).join('')
  const otherRows = others.map((p: any) => card(p, false)).join('')

  return `<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<title>铸剑炉 · 插件市场</title>
<style>
  body{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;margin:0;background:#14161f;color:#e8e6e3}
  header{padding:24px 30px;background:linear-gradient(135deg,#1a1a2e 0%,#2d1b2e 60%,#3d2a1a 100%);border-bottom:2px solid #c9a86a}
  header h1{margin:0;font-size:22px;color:#e8c87a;letter-spacing:2px}
  header h1 span{color:#fff}
  header p{margin:8px 0 0;font-size:13px;color:#9aa0b5}
  .wrap{padding:20px 30px;max-width:1100px;margin:0 auto}
  .section-title{font-size:16px;color:#e8c87a;margin:24px 0 12px;padding-left:10px;border-left:4px solid #c9a86a;letter-spacing:1px}
  .card{background:#1e2230;border-radius:10px;padding:16px 18px;margin-bottom:12px;border:1px solid #2c3145}
  .forge-card{border:1px solid #c9a86a;background:linear-gradient(180deg,#242138 0%,#1e2230 100%)}
  .row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
  .id{font-weight:700;font-size:15px}
  .forge-tag{font-size:11px;padding:2px 8px;border-radius:10px;background:#c9a86a;color:#14161f;font-weight:700}
  .chip{font-size:11px;padding:2px 8px;border-radius:10px;background:#2c3145;color:#aab}
  .chip.vA{background:#1d3a2a;color:#5fd38a}.chip.vB{background:#3a2d1a;color:#e0b45f}.chip.vC{background:#3a1d1d;color:#e07a7a}
  .status{font-weight:600}
  .ver{font-size:12px;color:#888}
  .meta{font-size:12px;color:#8a90a8;margin-top:8px;font-family:ui-monospace,Consolas,monospace}
  .axioms{font-size:12px;color:#b8b6b0;margin-top:6px}
  .fbadges{font-size:12px;color:#c9a86a;margin-top:6px}
  .actions{margin-top:10px}
  button{background:#c9a86a;color:#14161f;border:none;padding:6px 14px;border-radius:6px;cursor:pointer;font-size:13px;font-weight:600}
  button:hover{background:#e0c080}
  .vet-box{margin-top:24px;padding:16px 18px;background:#1e2230;border-radius:10px;border:1px solid #2c3145}
  .vet-box h3{color:#e8c87a;margin:0 0 10px}
  .vet-box input{width:70%;padding:8px 10px;border:1px solid #3a3f55;background:#14161f;color:#e8e6e3;border-radius:6px;font-size:13px;font-family:ui-monospace,Consolas,monospace}
  .vet-box pre{background:#14161f;padding:12px;border-radius:8px;font-size:12px;overflow:auto;max-height:320px;white-space:pre-wrap;color:#8fe0a0}
  .stats{font-size:13px;color:#9aa0b5;margin:8px 0}
</style></head><body>
<header><h1>铸剑炉 <span>· 插件市场</span></h1>
<p>只收死程序插件：三公理准入（注意力稀缺 / 声称需执行证据 / 噪音纪律）+ 判定器三级分档（A 纯死 / B 裸通道 / C 真活）。铸剑炉专柜按自家规矩审核（证据铁律 / 记忆纪律 / 权限声明 / 反讨好）。市场自身不联网、不自更新、只出提案不安装。</p></header>
<div class="wrap">
  <div class="stats" id="stats"></div>
  <div class="section-title">铸剑炉专柜</div>
  <div id="forge-cards">${forgeRows || '<p style="color:#e07a7a">专柜为空</p>'}</div>
  <div class="section-title">官方货架</div>
  <div id="cards">${otherRows || '<p style="color:#e07a7a">货架为空</p>'}</div>
  <div class="vet-box"><h3>死壳判定（market_vet）</h3>
    <input id="vetpath" placeholder="输入插件目录路径，如 D:/path/to/plugin" />
    <button onclick="runVet()">判定</button>
    <pre id="vetout">判定结果将显示在这里…</pre>
  </div>
</div>
<script>
const api = (u) => fetch(u).then(r => r.json())
function loadCatalog() {
  api('/api/catalog').then(c => {
    const all = c.plugins || []
    const f = all.filter(p => p.forge && p.forge.family === '铸剑炉')
    const o = all.filter(p => !(p.forge && p.forge.family === '铸剑炉'))
    document.getElementById('stats').textContent = '共 ' + all.length + ' 个插件：铸剑炉专柜 ' + f.length + ' · 官方货架 ' + o.length + '（清单 ' + (c.schemaVersion||'') + '，更新 ' + (c.updated||'') + '）'
  })
}
function propose(id) {
  api('/api/propose?id=' + encodeURIComponent(id)).then(p => {
    const el = document.getElementById('prop-' + id)
    el.textContent = p.installCommand ? '提案：' + p.installCommand + '（sha512 见上方）' : ('未准入：' + (p.error || JSON.stringify(p)))
  })
}
function runVet() {
  const p = document.getElementById('vetpath').value.trim()
  if (!p) return
  document.getElementById('vetout').textContent = '判定中…'
  api('/api/vet?path=' + encodeURIComponent(p)).then(v => {
    document.getElementById('vetout').textContent = JSON.stringify(v, null, 2)
  })
}
loadCatalog()
</script></body></html>`
}

function json(res: any, data: any, status = 200): void {
  const body = JSON.stringify(data)
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' })
  res.end(body)
}

/** 启动本地市场服务（幂等：已监听则跳过）。 */
export function startMarketServer(): any {
  const server = createServer((req: any, res: any) => {
    const url = new URL(req.url ?? '/', `http://${HOST}:${PORT}`)
    try {
      if (url.pathname === '/') {
        const html = marketHtml(loadCatalog())
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' })
        res.end(html)
        return
      }
      if (url.pathname === '/api/catalog') {
        json(res, loadCatalog())
        return
      }
      if (url.pathname === '/api/vet') {
        const path = url.searchParams.get('path') ?? ''
        const mod = '../vetter/vetter.mjs'
        import(mod).then((v: any) => {
          try {
            json(res, v.summarize(v.vet(path)))
          } catch (e: any) {
            json(res, { error: String(e?.message ?? e) }, 400)
          }
        }).catch((e: any) => json(res, { error: String(e?.message ?? e) }, 500))
        return
      }
      if (url.pathname === '/api/propose') {
        const id = url.searchParams.get('id') ?? ''
        const cat = loadCatalog()
        const found = (cat.plugins ?? []).find((p: any) => p.id === id)
        if (!found) { json(res, { error: 'not found', id }, 404); return }
        if (found.status !== 'admitted') { json(res, { error: '插件未准入（A 档才可安装）', id, status: found.status }, 403); return }
        json(res, {
          id: found.id, version: found.version, sha512: found.sha512, source: found.source,
          installCommand: `dsh plugin add ${found.id}@${found.version}`,
        })
        return
      }
      json(res, { error: 'not found' }, 404)
    } catch (e: any) {
      json(res, { error: String(e?.message ?? e) }, 500)
    }
  })
  server.listen(PORT, HOST)
  return server
}