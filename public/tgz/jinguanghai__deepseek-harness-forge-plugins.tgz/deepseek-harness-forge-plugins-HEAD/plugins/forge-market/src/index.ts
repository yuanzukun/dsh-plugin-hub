/**
 * dsh-forge-market — forge 死市场插件
 *
 * 哲学：插件多是好事，多而有法。本插件是"死的货架 + 死的开单器"：
 *  - 数据全死：catalog/plugins.json（随包发布，离线清单）
 *  - 动作全走官方通道：只生成安装提案，安装由官方 dsh plugin CLI 执行
 *  - 判定全死：vetter 三级分档（A 纯死 / B 裸通道死壳 / C 真活拒收）
 *  - 三公理为准入母法：注意力税（一）/ 证据实测（二）/ 噪音纪律（三）
 *
 * @module dsh-forge-market
 * @license MIT
 */

import { readFileSync, appendFileSync, existsSync, mkdirSync } from 'node:fs'
import { startMarketServer } from './http-market.ts'

/** Cordis 插件上下文最小接口。 */
export interface ContextLike {
  tools: { register(def: unknown): void }
  logger?: { info(msg: string): void }
}

/** 工具定义的宽松类型（与官方工具注册形态对齐）。 */
interface ToolDefinitionLike {
  name: string
  description: string
  parameters: { type: string; properties: Record<string, unknown>; required?: string[] }
  timeoutMs?: number
  output: {
    schema: unknown
    render: (args: unknown, value: unknown) => { type: string; text: string }[]
  }
  execute: (args: Record<string, unknown>) => Promise<unknown>
}

function require_http_market(): any {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    return { startMarketServer: (globalThis as any).__forge_market_http?.startMarketServer }
  } catch { return {} }
}
export const inject = ['tools']

/** 插件数据目录（相对本模块：lib/ 的上一级）。 */
function pluginRoot(): URL {
  return new URL('../', import.meta.url)
}
function dataFile(rel: string): URL {
  return new URL(rel, pluginRoot())
}

/** 读取清单（死数据：随包发布）。 */
function readCatalog() {
  const p = dataFile('catalog/plugins.json')
  try {
    return JSON.parse(readFileSync(p, 'utf-8'))
  } catch {
    return { schemaVersion: '0', updated: '', note: 'catalog 缺失', plugins: [] }
  }
}

/** 审计追加（唯一写操作：只追加本地 data/audit.jsonl，JSON Lines）。
 * 写前确保 data/ 目录存在；审计失败不阻断主功能（公理二：主功能优先）。 */
function audit(action: string, detail: Record<string, unknown>) {
  const entry = { t: new Date().toISOString(), action, ...detail }
  try {
    mkdirSync(new URL('data/', pluginRoot()), { recursive: true })
    const p = dataFile('data/audit.jsonl')
    appendFileSync(p, JSON.stringify(entry) + '\n', 'utf-8')
  } catch {
    // 审计不可写时不阻断
  }
  return entry
}

/** 动态加载 vetter（ESM 模块，保留 .mjs；变量路径避免静态类型解析）。 */
async function loadVetter(): Promise<any> {
  const mod = '../vetter/vetter.mjs'
  return await import(mod)
}

/** 工具输出渲染：JSON → 文本块。 */
function textBlock(text: string) {
  return [{ type: 'text' as const, text }]
}

export function apply(ctx: ContextLike) {
  // 本地图形市场界面服务（127.0.0.1:18766，幂等启动）
  try {
    startMarketServer()
    ctx.logger?.info('[forge-market] market UI on http://127.0.0.1:18766')
  } catch (e: any) {
    ctx.logger?.info('[forge-market] market UI start failed: ' + String(e?.message ?? e))
  }
  const tools: ToolDefinitionLike[] = [
    {
      name: 'market_list',
      description: '列出死市场清单中的插件（forge 三公理准入）。可过滤 status（admitted/review/rejected）与 category（tool/guard/service/skill/adapter/theme）。只读。',
      parameters: {
        type: 'object',
        properties: {
          status: { type: 'string', description: '过滤状态，默认全部' },
          category: { type: 'string', description: '过滤品类，默认全部' },
        },
      },
      output: {
        schema: { type: 'array', items: { type: 'object' } },
        render: (_a, v) => textBlock(JSON.stringify(v, null, 2)),
      },
      execute: async (args) => {
        const cat = readCatalog()
        let rows = cat.plugins ?? []
        const status = String(args.status ?? '').toLowerCase()
        const category = String(args.category ?? '').toLowerCase()
        if (status) rows = rows.filter((p: any) => (p.status ?? '').toLowerCase() === status)
        if (category) rows = rows.filter((p: any) => (p.category ?? '').toLowerCase() === category)
        audit('market_list', { status, category, count: rows.length })
        return rows.map((p: any) => ({
          id: p.id, category: p.category, version: p.version, status: p.status,
          verdict: p.vetter?.verdict, live: p.vetter?.liveCount, bare: p.vetter?.bareCount,
          supply: p.vetter?.supplyCount, sourceBytes: p.vetter?.sourceBytes,
        }))
      },
    },
    {
      name: 'market_inspect',
      description: '查看清单中单个插件的完整体检表（判定命中明细/三公理/sha512）。只读。',
      parameters: {
        type: 'object',
        properties: { id: { type: 'string', description: '插件 id' } },
        required: ['id'],
      },
      output: { schema: { type: 'object' }, render: (_a, v) => textBlock(JSON.stringify(v, null, 2)) },
      execute: async (args) => {
        const cat = readCatalog()
        const found = (cat.plugins ?? []).find((p: any) => p.id === args.id)
        audit('market_inspect', { id: args.id, found: !!found })
        if (!found) return { error: 'not found', id: args.id }
        return found
      },
    },
    {
      name: 'market_vet',
      description: '对指定目录/文件跑死壳判定（vetter 三级分档：A 纯死 / B 裸通道死壳 / C 真活）。只读。',
      parameters: {
        type: 'object',
        properties: { path: { type: 'string', description: '要判定的本地插件目录' } },
        required: ['path'],
      },
      output: { schema: { type: 'object' }, render: (_a, v) => textBlock(JSON.stringify(v, null, 2)) },
      execute: async (args) => {
        const p = String(args.path ?? '')
        if (!p) return { error: 'path required' }
        const v = await loadVetter()
        try {
          const report = v.summarize(v.vet(p))
          audit('market_vet', { path: p, verdict: report.verdict })
          return report
        } catch (e: any) {
          audit('market_vet', { path: p, error: String(e?.message ?? e) })
          return { error: String(e?.message ?? e), path: p }
        }
      },
    },
    {
      name: 'market_propose',
      description: '为清单中已准入（A 档）的插件生成安装提案：固定版本 + sha512 + 来源 + 官方安装命令。安装由官方 dsh plugin CLI 执行，本工具不执行安装。',
      parameters: {
        type: 'object',
        properties: { id: { type: 'string', description: '插件 id' } },
        required: ['id'],
      },
      output: { schema: { type: 'object' }, render: (_a, v) => textBlock(JSON.stringify(v, null, 2)) },
      execute: async (args) => {
        const cat = readCatalog()
        const found = (cat.plugins ?? []).find((p: any) => p.id === args.id)
        if (!found) return { error: 'not found', id: args.id }
        if (found.status !== 'admitted' && found.verdict !== 'A') {
          return { error: '插件未准入（A 档才可安装）', id: args.id, status: found.status, verdict: found.vetter?.verdict }
        }
        const proposal = {
          id: found.id, version: found.version, sha512: found.sha512, source: found.source,
          installCommand: `dsh plugin add ${found.id}@${found.version}`,
          note: '安装前请核对 sha512 与来源。安装走官方 CLI，本市场不执行安装。',
        }
        audit('market_propose', { id: found.id, version: found.version })
        return proposal
      },
    },
    {
      name: 'market_audit',
      description: '查看本市场插件的审计日志（market_* 操作轨迹，只追加）。只读。',
      parameters: {
        type: 'object',
        properties: { limit: { type: 'number', description: '返回最近 N 条，默认 20' } },
      },
      output: { schema: { type: 'array' }, render: (_a, v) => textBlock(JSON.stringify(v, null, 2)) },
      execute: async (args) => {
        const p = dataFile('data/audit.jsonl')
        if (!existsSync(p)) return []
        const lines = readFileSync(p, 'utf-8').trim().split('\n').filter(Boolean)
        const limit = Math.max(1, Math.min(200, Number(args.limit ?? 20)))
        return lines.slice(-limit).map((l: string) => { try { return JSON.parse(l) } catch { return { raw: l } } })
      },
    },
  ]
  for (const t of tools) ctx.tools.register(t)
  ctx.logger?.info('[forge-market] 5 tools registered (list/inspect/vet/propose/audit)')
}

