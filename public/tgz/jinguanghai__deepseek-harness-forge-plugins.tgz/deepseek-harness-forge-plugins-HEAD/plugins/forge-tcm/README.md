# forge-tcm

Traditional Chinese Medicine toolkit for DeepSeek Harness: pattern diagnosis
and herb-pair retrieval across an ancient-formula corpus.

| Tool | Purpose |
|---|---|
| `tcm_diagnose` | TCM pattern diagnosis (text/vector → trigram + strategy) |
| `tcm_herb_pair` | Herb-pair co-occurrence retrieval (附子+干姜 → ranked formulas) |

Herb-pair retrieval requires `formula_db.json` — a private ancient-formula
corpus that is **NOT distributed with this repo** (家传古籍数据). Provide your
own and point `FORGE_DATA` at it. No npm dependencies.
