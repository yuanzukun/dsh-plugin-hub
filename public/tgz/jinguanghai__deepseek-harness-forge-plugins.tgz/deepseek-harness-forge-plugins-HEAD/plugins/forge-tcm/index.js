// forge-tcm — 铸剑炉（forge）tcm_gate 工具（八极八势·六势态诊断 + 古籍药对检索）。
// 复用 tcm_gate.exe（药对检索直读古籍方剂库 formula_db.json）。
// 路径动态解析：FORGE_GATE_BIN 环境变量 → 发布包 bin/windows → 本机回退（开发环境）。
// 数据红线：formula_db.json 为私有古籍数据，不在本仓库内，请按 README 自行准备。
export const name = 'forge-tcm'
export const inject = ['tools', 'subprocess']

export function apply(ctx) {
  // 路径动态化（六西格玛改进）：环境变量优先 → 发布包 bin/windows → 本机回退（开发环境）
  // 路径动态化 v2（bundle 版）：模块目录（包根）下自含 bin\windows；环境变量可覆盖
  const hereDir = (() => {
    try {
      let u = import.meta.url.replace(/^file:\/\//, '').replace(/^[\\/]+/, '')
      return u.replace(/[\\/][^\\/]*$/, '') // 去掉 index.js → 包根
    } catch { return '' }
  })()
  const toolsDir = process.env.FORGE_GATE_BIN || (hereDir.length > 2 ? hereDir + '\\bin\\windows' : '')
  const gateExe = toolsDir + '\\tcm_gate.exe'
  const baseDir = process.env.FORGE_HOME || process.cwd()

  const renderText = (_args, value) => [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }]

  async function runTcm(jsonArg, exec) {
    const handle = ctx.subprocess.spawn({
      argv: [gateExe, jsonArg],
      cwd: baseDir,
      env: { PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' },
      stdio: {
        stdin: 'ignore',
        stdout: { maxBytes: 2 * 1024 * 1024 },
        stderr: { maxBytes: 200 * 1024 },
      },
      graceMs: 5000,
      signal: exec.signal,
    })
    const outcome = await handle.done
    const so = handle.collected.stdout ? handle.collected.stdout.readFrom(0) : { text: '' }
    const se = handle.collected.stderr ? handle.collected.stderr.readFrom(0) : { text: '' }
    const stdout = (so.text || '').trim()
    let parsed = null
    try { parsed = JSON.parse(stdout) } catch { /* 保持 null */ }
    return { exitCode: outcome.exitCode, parsed, stdout, stderr: (se.text || '').trim() }
  }

  function registerTool(spec) {
    ctx.tools.register({
      name: spec.name,
      description: spec.description,
      parameters: { type: 'object', properties: spec.properties, required: spec.required || [] },
      timeoutMs: 20000,
      output: { schema: { type: 'object' }, render: renderText },
      async execute(args, exec) {
        const r = await runTcm(spec.toArg(args), exec)
        const result = r.parsed || {
          error: 'tcm_gate 输出非 JSON',
          stdout: r.stdout.slice(0, 400),
          stderr: r.stderr.slice(0, 400),
        }
        return { gate: 'tcm', exit_code: r.exitCode, ok: r.parsed ? r.parsed.ok !== false : r.exitCode === 0, result }
      },
    })
  }

  registerTool({
    name: 'tcm_diagnose',
    description: '中医认知诊断（八极八势·六势态）：把文本描述（自动近义词规范化）或显式 8 维向量 [阳,阴,表,里,寒,热,虚,实] 映射为卦象、八势战略排序、六势态阶段与建议。用于系统/项目/身体状态的态势诊断。若文本无明显状态词，请尽量给出显式 vector 以获得精准诊断。',
    properties: {
      text: { type: 'string', description: '自然语言状态描述（与 vector 二选一）' },
      vector: { type: 'array', items: { type: 'number' }, description: '显式 8 维向量，每维 0-10' },
      domain: { type: 'string', description: '可选领域提示，如 company/city/body/system' },
    },
    toArg: (a) => {
      // 近义词规范化（六西格玛改进，双保险）：把 gate 词表外的高频状态词映射到词表词，
      // 避免自由文本零命中退化为"平和"。显式 vector 优先。
      const raw = a.text || ''
      // 仅映射 gate 词表未覆盖的高频词（词表已扩充，勿重复映射以免语义偏移）
      const normMap = [
        ['效率低', '疲软'], ['推进慢', '迟缓'], ['推进缓慢', '迟缓'],
        ['士气不振', '低迷'], ['混乱', '郁结'], ['人心涣散', '低迷'],
      ]
      let text = raw
      for (const [from, to] of normMap) text = text.split(from).join(to)
      return JSON.stringify({ type: 'diagnose', text: text, vector: a.vector || [], domain: a.domain || '' })
    },
  })

  registerTool({
    name: 'tcm_herb_pair',
    description: '药对检索：在古籍方剂库（formula_db.json, 2887 条）中检索同时含两味药的方剂，返回方名/出处/组成/功效/等级。如 附子+干姜、桃仁+红花。',
    properties: {
      herb1: { type: 'string', description: '第一味药（支持别名，如 白芍/芍药）' },
      herb2: { type: 'string', description: '第二味药' },
    },
    required: ['herb1', 'herb2'],
    toArg: (a) => JSON.stringify({ type: 'herb_pair', herb1: a.herb1, herb2: a.herb2 }),
  })
}
