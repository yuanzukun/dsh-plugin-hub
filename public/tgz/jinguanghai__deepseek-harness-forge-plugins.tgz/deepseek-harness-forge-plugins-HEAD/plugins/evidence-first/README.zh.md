# dsh-evidence-first

**DeepSeek Harness 证据铁律插件。** 声称完成必须有实际执行证据。

## 为什么需要它

LLM 是统计机器：会幻觉、会张冠李戴，最危险的是——**没有实际执行任何工具，却声称"完成了"**。工具架构能结构性防住"幻工具"和"幻调用"（schema 校验、封闭注册表），但没有任何架构能防住第四种幻觉：**模型说"完成"但背后没有证据**。

本插件在**会话层**补上这个洞：

1. 逐轮记录工具执行证据（`tool/result` 事件）
2. 扫描 assistant 消息中的完成类声明（完成/成功/修复/搞定/通过…）
3. 无附近工具执行的声明 → 下一轮 `pre-step` 注入可见警告，逼模型补证据或撤回
4. `evidence_audit` 工具：给把关者完整的审计报告

## 安装

```bash
# 通过 cordis.patch.yml / bundle
- id: evidence-first
  src: link:./plugins/evidence-first
```

或把 `lib/index.js` 复制进你的插件目录并注册。

## 配置

| 字段 | 类型 | 默认 | 含义 |
|---|---|---|---|
| `claimPatterns` | `string[]` | 中文完成类短语 | 完成类声明的正则源串 |
| `evidenceWindowTurns` | `number` | `1` | 回溯多少个 turn 算"附近有证据" |
| `injectWarnings` | `boolean` | `true` | 是否在下一轮注入可见警告 |
| `registerAuditTool` | `boolean` | `true` | 是否注册 `evidence_audit` 工具 |
| `maxEvidenceEntries` | `number` | `200` | 每会话证据条数上限（内存护栏） |

配置是 **fail-loud** 的：非法值在加载时抛异常，绝不静默回退。

## 工作原理

- `session/event` — 观察 `turn/start`、`tool/result`、`assistant/message`
- `agent/pre-step` — 把待发警告注入下一轮模型请求
- `ctx.tools.register` — 注册 `evidence_audit` 审计工具
- 注入消息携带 `source: { kind: 'plugin', plugin: 'evidence-first', form: 'notice', summary: '证据铁律警告' }` —— `{kind:'plugin'}` 标签是承重的：未标记的上下文会被渲染成用户 prompt。

## 设计要点

- **宁可误报，不可漏报。** 警告是廉价的；无人核实的"完成"是昂贵的。声明是"标记给人看"，不是自动拒绝。
- **零运行时依赖。** 插件运行时不 import 任何 `@deepseek-ai/*`——独立编译，任何 dsh 环境都能加载。
- **证据窗口默认 1 个 turn**（同 turn 或上一 turn）。长工具链可调 `evidenceWindowTurns`。

## 许可证

MIT

## ✅ 官方规范合规

DeepSeek Harness [CONTRIBUTING.zh.md](https://github.com/deepseek-ai/deepseek-harness/blob/main/CONTRIBUTING.zh.md)
明确说明**无法接受外部 PR**，并引导社区**创建并分享插件**（仓库加 `dsh-plugin` 话题）。
本插件正是走这条路——它是**即插即用的 Cordis 插件**，与官方插件同规范构建：

| 官方规范 | 本插件 |
|---|---|
| 命名导出 `{ name, Config, inject, apply }` | ✅ 同模式（`apply` 为主；`inject` 把证据契约注入模型 prompt） |
| `Config` fail-loud 校验（issues 数组 + `apply` 中 throw） | ✅ 非法值 → issues；语义错误 → 响亮失败 |
| 经 `cordis.patch.yml` bundle 装配 | ✅ 单层 insert patch |
| 零官方源码修改 | ✅ 纯事件钩子（`turn/start`、`assistant/message`、`tool/result`、`pre-step`）+ 一个注册工具（`evidence_audit`） |
| `package.json` 按官方标准 | ✅ `exports`/`types`/`files`/`peerDependencies`（`@deepseek-ai/cordis`、`dsh-agent`、`dsh-tools`） |
| i18n README（`README.i18n.yaml`） | ✅ 中英双语 |
| 零 npm 运行时依赖 | ✅ 仅 `@deepseek-ai/schemastery`（Config 校验，同官方） |

**验证**（当然也是证据先于声称）：5 个单元测试（无证据声明注入警告 / 真实执行不误报 / 工具注册 / fail-loud Config / source 标签完整性）——**5/5 通过**；另做 headless 端到端：模型真实调用 shell 工具后声称完成 → **无误报**、无 inject 报错。

分享：仓库 `jinguanghai/deepseek-harness-forge-plugins`（已加 `dsh-plugin` 话题）。
