/**
 * dsh-evidence-first — 证据铁律（Evidence First）
 *
 * 哲学：LLM 是统计拟合，会幻觉、会撒谎、会写错。架构能防"幻工具/幻调用"，
 * 但防不住第四种幻觉——"工具真执行了（或根本没执行），模型却声称完成"。
 * 本插件在会话层建立"声称 ↔ 证据"的强制对应：
 *   1. 记录每个 turn 的工具执行证据（tool/result 事件）
 *   2. 扫描 assistant 消息中的完成类声明（完成/成功/修复/搞定/通过...）
 *   3. 无证据的声明 → 下一轮 pre-step 注入可见警告，逼模型补证据或撤回
 *   4. evidence_audit 工具：完整审计报告（供把关者核查）
 *
 * 与官方插件同一套模式：Config（fail-loud 校验）、
 * session/event 观察 + agent/pre-step 注入、source 带 {kind:'plugin'} 标签。
 * 运行时唯一依赖 @deepseek-ai/schemastery（官方标准 Config schema，提供 cordis 需要的 ~standard 校验）。
 *
 * @module dsh-evidence-first
 * @license MIT
 */

/* ── 官方标准 Config：schemastery z.object（提供 cordis 需要的 ~standard 校验接口） ── */
import z from '@deepseek-ai/schemastery'

/* ── 本地宽松类型声明（与 dsh 官方类型结构对齐，运行时零其他依赖） ── */

/** Cordis 插件上下文的最小接口（官方完整类型见 @deepseek-ai/cordis）。 */
export interface ContextLike {
  on(event: string, listener: (...args: any[]) => void): void
  tools: { register(def: unknown): void }
  logger?: { info(msg: string): void }
}

/** 消息内容块（text 类型即可见文本）。 */
interface ContentBlock { type: string; text?: string }

/** pre-step 钩子的返回决策：进入（带消息）或拒绝。 */
type PreStepDecision =
  | { kind: 'enter'; messages: UserMessageLike[] }
  | { kind: 'reject' }

/** 用户消息的最小子集。 */
interface UserMessageLike {
  id: string
  role: 'user'
  content: ContentBlock[]
  source: unknown
}

/** 会话事件的宽松类型（官方为 discriminated union，这里取所需字段）。 */
interface SessionEventLike {
  type: string
  data?: {
    turn?: number
    message?: { content?: ContentBlock[] }
    name?: string
    toolCallId?: string
    isError?: boolean
  }
}

/** 工具定义的宽松类型。 */
interface ToolDefinitionLike {
  name: string
  description: string
  parameters: { type: string; properties: Record<string, unknown> }
  timeoutMs?: number
  output: {
    schema: unknown
    render: (args: unknown, value: unknown) => ContentBlock[]
  }
  execute: (args: unknown, exec: { agent?: { session: SessionLike } }) => Promise<unknown>
}

interface SessionLike {
  header?: { id?: string }
  events: SessionEventLike[]
}

/* ── 插件本体 ── */

export const name = 'evidence-first'

/** 依赖声明（官方最小形态必备）：本插件使用 tools 服务（注册 evidence_audit 工具）。 */
export const inject = ['tools']

/**
 * 插件配置。与官方插件同一模式：手写 interface（可选字段）+ schemastery schema 标注，
 * cordis 在加载期用 Config['~standard'].validate 校验（fail-loud，非法配置抛 ValidationError）；
 * 语义级检查（claimPatterns 非空）在 apply 内抛错——双段校验，与 repeat-tool-reminder 完全一致。
 */
export interface Config {
  /** 完成类声明词（正则源串，默认中文保守集）。宁可多报让人判断，不可漏报。 */
  claimPatterns?: string[]
  /** 证据窗口（turn 数）：声称所在 turn 及其前 N-1 个 turn 内有工具执行即视为"有证据"。默认 1。 */
  evidenceWindowTurns?: number
  /** 是否在下一轮请求中注入可见警告。默认 true。 */
  injectWarnings?: boolean
  /** 是否注册 evidence_audit 审计工具。默认 true。 */
  registerAuditTool?: boolean
  /** 每会话最多记录的证据条数（防内存膨胀）。默认 200。 */
  maxEvidenceEntries?: number
}

/** 配置 schema（官方标准 schemastery；default 为"宁可多报让人判断"的中文保守集）。 */
export const Config: z<Config> = z.object({
  claimPatterns: z.array(z.string()).default([
    '(?:已|已经)?完成(?:了|好)?',
    '(?:已|已经)?成功(?:了|地)?',
    '(?:已|已经)?修复(?:好|了)?',
    '(?:已|已经)?搞定(?:了)?',
    '(?:已|已经)?实现(?:了)?',
    '(?:已|已经)?部署(?:了)?',
    '(?:已|已经)?上线(?:了)?',
    '(?:测试|编译|验证|构建|全部|验收).{0,4}通过',
    '(?:已|已经)?解决(?:了)?',
    '(?:写|做|改|修)(?:好|完)(?:了)?',
    '完工(?:了)?',
  ]),
  evidenceWindowTurns: z.number().min(1).max(20).default(1),
  injectWarnings: z.boolean().default(true),
  registerAuditTool: z.boolean().default(true),
  maxEvidenceEntries: z.number().min(10).default(200),
})

/** 注入消息的 source 标签——{kind:'plugin'} 是 load-bearing：未标记会渲染成用户 prompt。 */
function pluginSource(plugin: string): unknown {
  return { kind: 'plugin', plugin, form: 'notice', summary: '证据铁律警告' }
}

/** 构造一条用户角色消息（与官方 createUserMessage 同构：id + role + content + source）。 */
function createUserMessage(text: string, source: unknown): UserMessageLike {
  return {
    id: `ef-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    role: 'user',
    content: [{ type: 'text', text }],
    source,
  }
}

interface EvidenceEntry { turn: number; name: string; ok: boolean }
interface ClaimEntry { turn: number; claim: string; snippet: string }

interface SessionState {
  turn: number
  evidence: EvidenceEntry[]
  warned: Set<string>
  pending: ClaimEntry[]
}

function extractText(content: unknown): string {
  if (!Array.isArray(content)) return ''
  let text = ''
  for (const p of content) {
    const b = p as ContentBlock
    if (b && b.type === 'text' && typeof b.text === 'string') text += b.text
  }
  return text
}

function toolNameOf(event: SessionEventLike): { name: string; ok: boolean } {
  const d = event.data ?? {}
  let name = d.name || 'tool'
  let ok = true
  if (d.message && Array.isArray(d.message.content)) {
    for (const b of d.message.content) {
      if (b && b.type === 'tool-result') {
        if (d.toolCallId) name = d.toolCallId
        ok = !d.isError
      }
    }
  }
  return { name, ok }
}

export function apply(ctx: ContextLike, rawConfig?: unknown): void {
  // cordis 已用 Config['~standard'].validate 校验类型并填充默认值；语义级检查在此 fail-loud（与官方双段校验一致）
  const config = (rawConfig ?? {}) as Config
  if (!config.claimPatterns || config.claimPatterns.length === 0) {
    throw new Error('[evidence-first] Config.claimPatterns 不能为空（宁可多报不可漏报）')
  }
  const claimRegexes = (config.claimPatterns ?? []).map((p: string) => new RegExp(p))
  const windowTurns = config.evidenceWindowTurns!
  const maxEntries = config.maxEvidenceEntries!
  const states = new Map<string, SessionState>()

  const stateOf = (session: SessionLike): SessionState => {
    const id = String(session?.header?.id ?? 'default')
    let st = states.get(id)
    if (!st) {
      st = { turn: 0, evidence: [], warned: new Set(), pending: [] }
      states.set(id, st)
    }
    return st
  }

  // ── 1. 会话事件：记录证据、扫描声明 ──
  ctx.on('session/event', (session: SessionLike, event: SessionEventLike) => {
    const st = stateOf(session)
    if (event.type === 'turn/start') {
      st.turn = event.data?.turn ?? 0
      return
    }
    if (event.type === 'tool/result') {
      const { name, ok } = toolNameOf(event)
      const turn = event.data?.turn ?? st.turn
      st.evidence.push({ turn, name, ok })
      if (st.evidence.length > maxEntries) st.evidence.splice(0, st.evidence.length - maxEntries)
      return
    }
    if (event.type === 'assistant/message') {
      const text = extractText(event.data?.message?.content)
      if (!text) return
      const turn = event.data?.turn ?? st.turn
      for (const re of claimRegexes) {
        const m = re.exec(text)
        if (m) {
          const has = st.evidence.some(e => turn - e.turn >= 0 && turn - e.turn < windowTurns)
          if (!has) {
            const key = `${turn}:${m[0]}`
            if (!st.warned.has(key)) {
              st.warned.add(key)
              st.pending.push({ turn, claim: m[0], snippet: text.slice(0, 120) })
            }
          }
          break
        }
      }
    }
  })

  // ── 2. pre-step：把待发警告注入下一轮请求（模型可见，促其补证据/撤回） ──
  ctx.on('agent/pre-step', async (
    { agent, messages }: { agent: { session: SessionLike }; messages: UserMessageLike[] },
    next: () => Promise<PreStepDecision>,
  ): Promise<PreStepDecision> => {
    const decision = await next()
    if (!config.injectWarnings) return decision
    const st = stateOf(agent.session)
    if (st.pending.length === 0) return decision
    const pending = st.pending.splice(0)
    const warn = '⚠️ 证据铁律：'
      + pending.map(c => `你声称"${c.claim}"（第${c.turn}轮）`).join('、')
      + `，但最近的对话中没有工具执行记录。请补充实际执行证据（运行输出/编译结果/测试结果/文件清单），或撤回该声明。`
    const msg = createUserMessage(warn, pluginSource(name))
    if (decision.kind === 'reject') return decision
    const idx = decision.messages.findLastIndex(m => messages.includes(m))
    const entered = [...decision.messages]
    entered.splice(idx + 1, 0, msg)
    return { kind: 'enter', messages: entered }
  })

  // ── 3. evidence_audit：完整审计（人把关时主动调用） ──
  if (config.registerAuditTool) {
    const auditTool: ToolDefinitionLike = {
      name: 'evidence_audit',
      description: '证据铁律审计：扫描当前会话全部事件，输出"完成/成功/修复/通过"类声明与工具执行证据的对照表，无证据的声明标 ⚠️。供把关者核查模型是否"声称完成但未实际执行"。',
      parameters: { type: 'object', properties: {} },
      timeoutMs: 15000,
      output: {
        schema: { type: 'object' },
        render: (_args: unknown, value: unknown): ContentBlock[] => [{
          type: 'text',
          text: typeof value === 'string' ? value : JSON.stringify(value, null, 2),
        }],
      },
      async execute(_args: unknown, exec: { agent?: { session: SessionLike } }) {
        const agent = exec.agent
        if (!agent) return { ok: false, error: '无法获取当前 agent（该工具需在 agent 会话内调用）' }
        const events = agent.session.events
        const turnTools = new Map<number, { name: string; ok: boolean }[]>()
        const claims: { turn: number; claim: string; hasEvidence: boolean; snippet: string }[] = []
        let turn = 0
        for (const e of events) {
          if (e.type === 'turn/start') { turn = e.data?.turn ?? 0; continue }
          if (e.type === 'tool/result') {
            const { name: tname, ok } = toolNameOf(e)
            if (!turnTools.has(turn)) turnTools.set(turn, [])
            turnTools.get(turn)!.push({ name: tname, ok })
            continue
          }
          if (e.type === 'assistant/message') {
            const text = extractText(e.data?.message?.content)
            if (!text) continue
            const t = e.data?.turn ?? turn
            for (const re of claimRegexes) {
              const m = re.exec(text)
              if (m) {
                const has = (turnTools.get(t)?.length ?? 0) > 0 || (turnTools.get(t - 1)?.length ?? 0) > 0
                claims.push({ turn: t, claim: m[0], hasEvidence: has, snippet: text.slice(0, 100) })
                break
              }
            }
          }
        }
        const flagged = claims.filter(c => !c.hasEvidence)
        return {
          ok: true,
          summary: {
            toolExecutions: [...turnTools.values()].reduce((a, v) => a + v.length, 0),
            claims: claims.length,
            flaggedClaims: flagged.length,
          },
          flagged: flagged.map(c => `第${c.turn}轮 "${c.claim}": ${c.snippet}...`),
          claimDetail: claims.slice(-20),
          recentTools: [...turnTools.entries()].slice(-5)
            .map(([t, arr]) => ({ turn: t, tools: arr.map(x => x.name + (x.ok ? '' : '(失败)')) })),
        }
      },
    }
    ctx.tools.register(auditTool)
  }

  ctx.logger?.info('[evidence-first] 证据铁律已启用：无工具证据的"完成/成功/修复"声明将被警告')
}

export default { name, Config, inject, apply }
