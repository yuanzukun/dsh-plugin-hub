// 零依赖回归测试：直接加载 lib/index.js 模拟事件流验证核心逻辑
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const mod = require('../lib/index.js')
const plugin = mod.default ?? mod

/** 最小 Context 模拟（on + tools.register + logger） */
function makeCtx() {
  const listeners = {}
  const tools = { registered: [], register(d) { this.registered.push(d) } }
  return {
    on(ev, fn) { (listeners[ev] ||= []).push(fn) },
    tools,
    listeners,
    emit(ev, ...args) { for (const fn of listeners[ev] || []) fn(...args) },
    logger: { info() {} },
  }
}

/** 模拟 cordis 的配置解析：schemastery validate 填充默认值；issues 即抛（fail-loud） */
function resolveConfig(raw) {
  const r = plugin.Config['~standard'].validate(raw ?? {})
  if (r.issues) throw new Error(r.issues.map(i => i.message).join('; '))
  return r.value
}

/** 事件构造 */
const turnStart = (turn) => ({ type: 'turn/start', data: { turn } })
const toolResult = (turn, name, ok = true) => ({ type: 'tool/result', data: { turn, name, isError: !ok } })
const assistantMsg = (turn, text) => ({ type: 'assistant/message', data: { turn, message: { content: [{ type: 'text', text }] } } })
const session = () => ({ header: { id: 's' }, events: [] })

test('无工具证据的"完成"声明 → pre-step 注入警告', async () => {
  const ctx = makeCtx()
  plugin.apply(ctx, resolveConfig({}))
  ctx.emit('session/event', session(), turnStart(1))
  ctx.emit('session/event', session(), assistantMsg(1, '任务完成'))

  let injected = null
  const decision = { kind: 'enter', messages: [{ id: 'u1', role: 'user', content: [{ type: 'text', text: '继续' }], source: { kind: 'user' } }] }
  const next = async () => decision
  const handler = ctx.listeners['agent/pre-step'][0]
  const out = await handler({ agent: { session: session() }, messages: decision.messages }, next)
  assert.equal(out.kind, 'enter')
  const warned = out.messages.filter(m => m.source?.kind === 'plugin' && m.source?.plugin === 'evidence-first')
  assert.equal(warned.length, 1, '应注入 1 条警告')
  assert.match(warned[0].content[0].text, /证据铁律|完成/)
})

test('有工具执行后的"完成"声明 → 不注入警告（防误报）', async () => {
  const ctx = makeCtx()
  plugin.apply(ctx, resolveConfig({}))
  ctx.emit('session/event', session(), turnStart(1))
  ctx.emit('session/event', session(), toolResult(1, 'pwsh', true))
  ctx.emit('session/event', session(), assistantMsg(1, '已经完成修复'))

  const decision = { kind: 'enter', messages: [{ id: 'u1', role: 'user', content: [{ type: 'text', text: '继续' }], source: { kind: 'user' } }] }
  const next = async () => decision
  const handler = ctx.listeners['agent/pre-step'][0]
  const out = await handler({ agent: { session: session() }, messages: decision.messages }, next)
  const warned = out.messages.filter(m => m.source?.kind === 'plugin')
  assert.equal(warned.length, 0, '有证据不应警告')
})

test('evidence_audit 工具已注册', () => {
  const ctx = makeCtx()
  plugin.apply(ctx, resolveConfig({}))
  assert.ok(ctx.tools.registered.some(d => d.name === 'evidence_audit'), 'evidence_audit 应注册')
})

test('Config fail-loud：非法值产生 issues，语义检查在 apply', () => {
  const v = plugin.Config['~standard'].validate
  assert.ok(v({ evidenceWindowTurns: 0 }).issues, '越界值应报 issues')
  assert.ok(v({ injectWarnings: 'yes' }).issues, '类型错应报 issues')
  assert.ok(!v({}).issues, '空配置合法')
  assert.equal(v({}).value.evidenceWindowTurns, 1, '默认值填充')
  assert.equal(v({}).value.claimPatterns.length, 11, '默认声明词集')
  assert.ok(!v({ claimPatterns: [] }).issues, '空数组 schema 合法（语义检查在 apply）')
  assert.throws(() => plugin.apply(makeCtx(), resolveConfig({ claimPatterns: [] })), 'apply 语义检查 fail-loud')
})

test('source 标签：{kind:"plugin"} 承重（不渲染成用户 prompt）', () => {
  const ctx = makeCtx()
  plugin.apply(ctx, resolveConfig({}))
  ctx.emit('session/event', session(), turnStart(1))
  ctx.emit('session/event', session(), assistantMsg(1, '搞定'))
  const decision = { kind: 'enter', messages: [{ id: 'u1', role: 'user', content: [{ type: 'text', text: 'x' }], source: { kind: 'user' } }] }
  const next = async () => decision
  return ctx.listeners['agent/pre-step'][0]({ agent: { session: session() }, messages: decision.messages }, next)
    .then(out => {
      const warned = out.messages.filter(m => m.source?.kind === 'plugin')
      assert.equal(warned.length, 1)
      assert.equal(warned[0].source.plugin, 'evidence-first')
      assert.equal(warned[0].source.form, 'notice')
    })
})
