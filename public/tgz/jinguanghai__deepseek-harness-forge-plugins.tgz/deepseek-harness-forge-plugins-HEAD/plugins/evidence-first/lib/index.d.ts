/**
 * dsh-evidence-first — 证据铁律（Evidence First）
 *
 * 哲学：LLM 是统计拟合，会幻觉、会撒谎、会写错。架构能防"幻工具/幻调用"，
 * 但防不住第四种幻觉——"工具真执行了（或根本没执行），模型却声称完成"。
 * 本插件在会话层建立"声称 ↔ 证据"的强制对应：
 *   1. 记录每个 turn 的工具执行证据（tool/result 事件）
 *   2. 扫描 assistant 消息中的完成类声明（完成/成功/修复/搞定/通过...）
 *   3. 无证据的声明 → 下一轮 pre-step 注入可见警告，逼模型补证据或撤回
 *   4. evidence_audit 工具：完整审计报告（供把关者核查）
 *
 * 与官方插件同一套模式：Config（fail-loud 校验）、
 * session/event 观察 + agent/pre-step 注入、source 带 {kind:'plugin'} 标签。
 * 运行时唯一依赖 @deepseek-ai/schemastery（官方标准 Config schema，提供 cordis 需要的 ~standard 校验）。
 *
 * @module dsh-evidence-first
 * @license MIT
 */
import z from '@deepseek-ai/schemastery';
/** Cordis 插件上下文的最小接口（官方完整类型见 @deepseek-ai/cordis）。 */
export interface ContextLike {
    on(event: string, listener: (...args: any[]) => void): void;
    tools: {
        register(def: unknown): void;
    };
    logger?: {
        info(msg: string): void;
    };
}
export declare const name = "evidence-first";
/** 依赖声明（官方最小形态必备）：本插件使用 tools 服务（注册 evidence_audit 工具）。 */
export declare const inject: string[];
/**
 * 插件配置。与官方插件同一模式：手写 interface（可选字段）+ schemastery schema 标注，
 * cordis 在加载期用 Config['~standard'].validate 校验（fail-loud，非法配置抛 ValidationError）；
 * 语义级检查（claimPatterns 非空）在 apply 内抛错——双段校验，与 repeat-tool-reminder 完全一致。
 */
export interface Config {
    /** 完成类声明词（正则源串，默认中文保守集）。宁可多报让人判断，不可漏报。 */
    claimPatterns?: string[];
    /** 证据窗口（turn 数）：声称所在 turn 及其前 N-1 个 turn 内有工具执行即视为"有证据"。默认 1。 */
    evidenceWindowTurns?: number;
    /** 是否在下一轮请求中注入可见警告。默认 true。 */
    injectWarnings?: boolean;
    /** 是否注册 evidence_audit 审计工具。默认 true。 */
    registerAuditTool?: boolean;
    /** 每会话最多记录的证据条数（防内存膨胀）。默认 200。 */
    maxEvidenceEntries?: number;
}
/** 配置 schema（官方标准 schemastery；default 为"宁可多报让人判断"的中文保守集）。 */
export declare const Config: z<Config>;
export declare function apply(ctx: ContextLike, rawConfig?: unknown): void;
declare const _default: {
    name: string;
    Config: z<Config>;
    inject: string[];
    apply: typeof apply;
};
export default _default;
//# sourceMappingURL=index.d.ts.map