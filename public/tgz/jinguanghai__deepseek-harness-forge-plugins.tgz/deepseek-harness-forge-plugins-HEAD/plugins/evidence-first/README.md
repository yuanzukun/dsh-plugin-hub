# dsh-evidence-first

**Evidence-first guard plugin for DeepSeek Harness.** 证据铁律：声称完成必须有实际执行证据。

## Why

LLMs are statistical machines: they can hallucinate, misattribute, and — most
dangerously — *claim completion without actually executing anything*. Tool
architectures can structurally prevent *phantom tools* and *phantom calls*
(schema validation, closed registries), but no architecture can prevent the
fourth kind of hallucination: **a model that says "done" with no evidence
behind it**.

This plugin closes that gap at the **session layer**:

1. Records every tool execution (`tool/result` events) per turn.
2. Scans assistant messages for completion claims (完成/成功/修复/搞定/通过…).
3. A claim with no nearby tool execution → the next `pre-step` injects a
   visible warning, forcing the model to either supply evidence or retract.
4. `evidence_audit` tool: full audit report for the human gatekeeper.

## Install

```bash
# via cordis.patch.yml / bundle
- id: evidence-first
  src: link:./plugins/evidence-first
```

Or copy `lib/index.js` into your plugin directory and register it.

## Config

| Field | Type | Default | Meaning |
|---|---|---|---|
| `claimPatterns` | `string[]` | Chinese completion phrases | Regex sources for completion claims |
| `evidenceWindowTurns` | `number` | `1` | How many turns back counts as "nearby evidence" |
| `injectWarnings` | `boolean` | `true` | Inject visible warnings on the next pre-step |
| `registerAuditTool` | `boolean` | `true` | Register the `evidence_audit` tool |
| `maxEvidenceEntries` | `number` | `200` | Per-session evidence cap (memory guard) |

Config is **fail-loud**: invalid values throw at load time, never silently fall back.

## How it works

- `session/event` — observe `turn/start`, `tool/result`, `assistant/message`
- `agent/pre-step` — inject the pending warning into the next model request
- `ctx.tools.register` — `evidence_audit` audit tool
- Injected messages carry `source: { kind: 'plugin', plugin: 'evidence-first', form: 'notice', summary: '证据铁律警告' }` — the `{kind:'plugin'}` tag is load-bearing: untagged context would render as a user prompt.

## Design notes

- **Prefers false positives over false negatives.** A warning is cheap; a
  silent unverified "done" is expensive. Claims are *flag-for-human*, not
  auto-rejected.
- **Zero runtime dependencies.** The plugin imports nothing from
  `@deepseek-ai/*` at runtime — it compiles standalone and loads in any dsh
  environment.
- **Evidence window defaults to 1 turn** (same turn or the previous turn).
  Adjust via `evidenceWindowTurns` for longer tool chains.

## License

MIT

## ✅ Official convention compliance (官方规范合规)

DeepSeek Harness [CONTRIBUTING.zh.md](https://github.com/deepseek-ai/deepseek-harness/blob/main/CONTRIBUTING.zh.md)
states that the project **cannot accept external PRs**, and directs the community
to **create and share plugins** (tag repos with `dsh-plugin`). This plugin follows
that path — it is a **drop-in Cordis plugin**, built to the same conventions as
first-party plugins:

| Official convention | This plugin |
|---|---|
| Named exports `{ name, Config, inject, apply }` | ✅ same pattern (`apply` is default; `inject` injects the evidence contract into the model prompt) |
| `Config` with fail-loud validation (issues array + `throw` in `apply`) | ✅ invalid patterns → `issues`; semantic errors → loud failure |
| Assembly via `cordis.patch.yml` bundle | ✅ one-layer insert patch |
| Zero modification of official source | ✅ pure event hooks (`turn/start`, `assistant/message`, `tool/result`, `pre-step`) + one registered tool (`evidence_audit`) |
| `package.json` per first-party standard | ✅ `exports`/`types`/`files`/`peerDependencies` (`@deepseek-ai/cordis`, `dsh-agent`, `dsh-tools`) |
| i18n README (`README.i18n.yaml`) | ✅ en/zh |
| Zero npm runtime deps | ✅ except `@deepseek-ai/schemastery` (Config validation, same as first-party) |

**Verification** (evidence first, of course): 5 unit tests (warning injection on
evidence-less claims, no false-positive with real tool execution, tool
registration, fail-loud Config, source-tag integrity) — **5/5 pass**; plus an
end-to-end headless run where the model actually executed a shell tool and
claimed completion → **no false warning**, no inject errors.

Share: repo `jinguanghai/deepseek-harness-forge-plugins` (tagged `dsh-plugin`).
