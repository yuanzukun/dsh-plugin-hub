# Contributing / 贡献指南

Thanks for helping grow the Forge plugin family! / 感谢参与！

## Scope / 范围

This repo hosts **DeepSeek Harness (dsh) plugins** built on the Forge discipline:
every tool is a deterministic, verifiable compute gate — the LLM proposes, the
program proves. / 本仓库托管基于铸剑炉纪律的 dsh 插件：每个工具都是确定性的、可验证的计算门——LLM 提议，程序验证。

## Adding a plugin / 新增插件

1. Create `plugins/<your-plugin>/` with:
   - `package.json` declaring `dsh.bundle` (e.g. `{ "bundle": { "patch": "./cordis.patch.yml" } }`)
   - `cordis.patch.yml` registering your bundle id
   - real, working code (no placeholders, no README-only plugins)
2. Ship **deterministic tools**: prefer compiled gates / sandboxed executors over
   free-form LLM text generation. Evidence over claims — every tool returns a
   machine-verifiable result. / 坚持确定性工具：优先编译门/沙箱执行器，反对自由文本生成。证据先于声称。
3. Document each tool with a one-line description in both `en` and `zh`.
4. Update the root `README.md` plugin table (and `README.zh.md` if present).
5. Run the checks: `cd plugins/<your-plugin> && npm run build && npm test`.

## Code discipline / 代码纪律

- **No bare `fs`** — all file access goes through `ctx.fs` (host-plane discipline).
- **Zero npm deps** for the runtime path unless strictly required (the gates are
  single-file Go programs, stdlib only).
- New implementation replaces the old one in the same commit — no dead code,
  no reserved-but-unused interfaces. / 新实现必须同步删旧版，不留死代码。
- Static scanning is not enough — build and run tests before claiming done.

## Release / 发布

- Windows prebuilt `.exe` gates ship via GitHub Releases, not the repo tree.
- Bump the plugin version in `package.json` when behavior changes.

## License / 许可

[MIT](LICENSE) © jinguanghai
