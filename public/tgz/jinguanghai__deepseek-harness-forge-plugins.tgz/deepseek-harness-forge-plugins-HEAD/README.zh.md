# ⚒️ 铸剑炉插件集 · Forge Plugins for DeepSeek Harness

> **一切皆插件 (Everything is a Plugin)。** — 把**铸剑炉 (Forge)** 的兵器库带进 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)。

[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Tools](https://img.shields.io/badge/工具-12个-green.svg)](#-插件与工具)
[![Plugins](https://img.shields.io/badge/插件-3个-green.svg)](#-插件与工具)
[![Dependencies](https://img.shields.io/badge/依赖-0-brightgreen.svg)](#)
[![dsh](https://img.shields.io/badge/DeepSeek%20Harness-就绪-purple.svg)](https://github.com/deepseek-ai/deepseek-harness)
[![OS](https://img.shields.io/badge/Windows%20%7C%20Linux%20%7C%20macOS-lightgrey.svg)](#-从源码编译-gate)

**12 个生产级工具 · 3 个插件 · 零 npm 依赖 · 纯 Cordis** —— 给 DeepSeek Harness 智能体装上**真正的计算大脑**：符号数学、形式逻辑、定理证明、正则验证、状态机检测、代码修复、中医诊断、经验记忆召回。

---

## ✨ 为什么选铸剑炉插件？

| | |
|---|---|
| 🧮 **真计算** | 符号数学与逻辑**永不幻觉** —— 每个工具调用编译后的 gate 二进制，返回**已验证**结果 |
| 🧠 **形式推理** | TPTP 一阶逻辑定理证明（EPROVER）+ 状态机模型检测，不只是文字生成 |
| 🀄 **中医能力** | 独有的**八极八势**卦象诊断 + 古籍方剂药对检索 —— **DeepSeek Harness 生态唯一的中医插件** |
| 🪶 **零依赖** | 纯 Cordis 插件，无 npm install、无框架启动代码，**放进去就能用** |
| 🔒 **沙箱化** | 文件访问全部走 `ctx.fs`（宿主平面纪律），无裸 `fs` 调用 |
| 🎁 **开箱即用** | Windows 预编译 exe 已挂在 [Releases](https://github.com/jinguanghai/deepseek-harness-forge-plugins/releases/tag/v0.1.0)，Linux/macOS 一条命令自编译 |

---

## 🔌 插件与工具

| 插件 | 工具 | 功能 | 实测示例 |
|---|---|---|---|
| **forge-gates** | `forge_math` | 符号化简 / 求值 | `3*(x+1)-3*x` → **`3`** |
| | `forge_logic` | 形式证明 / 等价判定 | `x>0 and x<10 -> x>0` → **proved** |
| | `forge_regex` | 整串匹配正则验证 | `[A-Z]\d{3}` vs `B456` → **pass** |
| | `forge_eprover` | TPTP 一阶逻辑定理证明 | CNF 公理 → **theorem / counter-sat** |
| | `forge_system` | 状态机模型检测（死锁/不变量） | 6 状态 → **passed** |
| | `forge_repair` | 代码缺陷修复建议 | 裸 `except:` → **`except Exception:`** |
| **forge-tcm** | `tcm_diagnose` | 八极八势中医态势诊断 | 文本/向量 → 卦象+六势态+战略 |
| | `tcm_herb_pair` | 药对同现方剂检索 | 附子+干姜 → 916 首方剂 |
| **forge-memory** | `memory_recall` | BM25 经验召回 | 查询 → 排序片段 |
| | `memory_fold_list` | 折叠记忆索引（π/φ） | 列出折叠区段 |
| | `memory_fold_preview` | 预览折叠区段 | 内容预览 |
| | `memory_fold_deep` | 深度读取折叠区段 | 全文 |

**12 个工具 · 3 个插件 · MIT · 支持 dsh ≥ 0.1.0-rc.5**

---

## 🚀 快速开始

```bash
# 1. 把仓库放到任意位置，例如：
#    ~/.dsh/.agent-presets/forge-plus/   (仓库根即预设目录)

# 2. 在预设里注册插件（见 examples/agent.cordis.yml.snippet）

# 3. 启动 DeepSeek Harness：
npx @deepseek-ai/dsh web
```

`agent.cordis.yml` 片段：

```yaml
# 放在你的预设目录内
plugins:
  - path: ./plugins/forge-gates
  - path: ./plugins/forge-tcm
  - path: ./plugins/forge-memory
```

然后直接对智能体说：

> *"化简 3*(x+1)-3*x"* → `3` ✅
> *"证明 x>0 且 x<10 推出 x>0"* → `proved` ✅
> *"用正则 [A-Z]\d{3} 验证 B456 和 order B456 ok"* → pass/fail ✅
> *"附子 配 干姜 有哪些方剂?"* → 从你的古籍库返回排序方剂 ✅

---

## 🔧 环境变量

| 变量 | 默认值 | 用途 |
|---|---|---|
| `FORGE_GATE_BIN` | `<repo>/bin/windows` | gate 二进制目录（Linux/macOS 请用 `src/go` 自行编译） |
| `FORGE_HOME` | `process.cwd()` | 记忆数据目录（`memory.json` / `.forge-temp/memory_current.json` / `data/memory_current.json`） |
| `FORGE_DATA` | cwd / `data/` | 中医方剂库目录（须含 `formula_db.json`） |

## 🔨 从源码编译 gate（Linux / macOS / Windows）

```bash
cd src/go
for g in math logic regex eprover system repair tcm; do
  go build -o ${g}_gate${EXT} ${g}_gate.go
done   # Windows: set EXT=.exe
```

> 💡 Windows 用户：预编译 exe 已挂在 [v0.1.0 Release](https://github.com/jinguanghai/deepseek-harness-forge-plugins/releases/tag/v0.1.0)，无需编译。

---

## 🏗️ 架构

```
DeepSeek Harness (dsh) 智能体
        │  inject: ['tools']
        ▼
   ┌─ forge-plus 预设 ──────────────────┐
   │ forge-gates ── forge-memory ── forge-tcm │
   │        └──────┐         └────────┐      │
   │       子进程               │      │
   │               ▼                 ▼      │
   │     ┌─ gate 二进制 ────┐  ┌─ 数据 ──────┐│
   │     │ math / logic /   │  │ memory.json││
   │     │ regex / eprover /│  │ formula_db ││
   │     │ system / repair  │  │ (自备)     ││
   │     │ tcm              │  └────────────┘│
   │     └──────────────────┘                │
   └─────────────────────────────────────────┘
Gate 协议：工具调用 gate 二进制，每个二进制向 stdout 输出一个 JSON 对象。
```

---

## 📊 数据说明

- **forge-tcm** 药对检索需要 **`formula_db.json`** —— 私有古籍方剂库（家传古籍数据），**不随本仓库分发**。请自行准备，并用 `FORGE_DATA` 指向其目录。
- **forge-memory** 读取 `memory.json` / `.forge-temp/memory_current.json` / `data/memory_current.json` —— 记忆文件自备（`data/` 中有空模板）。
- gate 本身是纯逻辑（不内嵌任何私有数据）。

---

## 🎯 项目渊源

铸剑炉 (Forge) 是一个通用数字智能体：多语言编译沙箱 + **18 门 Gate**（Python / Go / Node / Rust / EPROVER / TCM / …），LLM 大脑驱动代码身体，自我进化架构。本仓库是它的 **dsh 原生插件家族** —— 同样的 Gate、同样的纪律，现在 *一切皆插件*。

- 主项目：[github.com/jinguanghai/forge](https://github.com/jinguanghai/forge)
- DeepSeek Harness：[deepseek-ai/deepseek-harness](https://github.com/deepseek-ai/deepseek-harness)

## 📜 License

[MIT](LICENSE) © jinguanghai

## 安装方式

三个插件均为 **Cordis bundle** 格式，可装入任意 dsh 配置：

```bash
# 1 dsh CLI（本地目录 / 离线包）
dsh plugin add ./plugins/forge-gates
# 2 pnpm（npm registry / 本地 tgz）
pnpm add dsh-forge-gates
# 3 手动：把插件目录符号链接进 profile 的 node_modules，
#    并在 package.json 的 dsh.profile.bundles 中登记
```

Windows 预编译 `.exe` 已随 bundle 分发（`bin/windows/`）。
最新离线包：https://github.com/jinguanghai/deepseek-harness-forge-plugins/releases/latest

> Linux/macOS：用 `src/go/` 一条命令编译 7 个 gate，见 [BUILDING](BUILDING.md)。

## 证据铁律插件 (evidence-first)

| 插件 | 工具 | 作用 |
|---|---|---|
| **evidence-first** | `evidence_audit` | 证据审计：模型声称"完成/成功/修复"但无工具执行证据时自动警告 |

安装：`dsh plugin add ./plugins/evidence-first`（或本地 tarball）。
