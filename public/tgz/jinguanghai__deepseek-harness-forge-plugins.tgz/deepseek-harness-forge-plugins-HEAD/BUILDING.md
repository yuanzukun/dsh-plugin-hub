# Building the gate binaries

All gates are single-file Go programs (stdlib only, zero deps).

```bash
cd src/go
for f in math_gate logic_gate regex_gate eprover_gate system_gate repair_gate tcm_gate; do
  go build -o ../../bin/linux/$f.exe  # or bin/macos/...
done
```

Place the binaries in a directory and point the plugins at it via the
`FORGE_GATE_BIN` environment variable (defaults to `<plugin>/bin/windows`).

Requirements: Go 1.21+ (`go version`).

## Building & testing evidence-first

The `evidence-first` plugin is TypeScript. Build and test it in isolation:

```bash
cd plugins/evidence-first
npm run build      # tsc → lib/index.js (+ .d.ts)
npm test           # deterministic unit tests (no dsh instance needed)
```

It has **zero runtime npm deps** — the built `lib/` ships in the bundle.
