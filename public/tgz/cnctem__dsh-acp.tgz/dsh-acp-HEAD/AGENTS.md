# AGENTS.md

dsh-acp: an ACP (Agent Client Protocol) JSON-RPC stdio server for DeepSeek Harness (`dsh`), shipped as a **dsh profile bundle** (Cordis plugin) that rides over `dsh-base`. Authored in strict TypeScript under `src/`; committed ESM, declarations, and source maps are generated into `lib/`.

## Commands

- Install deps: `pnpm install`
- Typecheck: `pnpm run typecheck`
- Verify: `pnpm test` — builds then runs the hermetic in-process protocol smoke. It does NOT touch the model stack or `$DSH_HOME`; prints `SMOKE TEST PASSED`/`FAILED (n)`.
- Profile verification: `pnpm run test:profile` — installs the local bundle into a temporary `DSH_HOME` and drives the real `dsh --profile acp` process, including all four presets.
- Release verification: `pnpm run verify` — typecheck, smoke test, and fail if committed `lib/` is stale.
- Real smoke: `printf '%s\n' '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":1,"clientCapabilities":{}}}' | dsh --profile acp` (needs `dsh` 0.2.0-rc.2 installed locally).
- Composition check: `dsh --profile acp --dump-config | grep -A4 'acp-editor'` after `dsh plugin --profile acp add ./dsh-acp`.

## Hard rules

- **Never write to stdout** (`console.log`, `process.stdout.write`) in `src/` — stdout carries ACP frames only. Diagnostics go through `ctx.logger` (stderr).
- Do not move `@deepseek-ai/cordis`, `dsh-agent-default-model`, `dsh-user-approval` from `peerDependencies` to `dependencies`: the host dsh install provides them.
- `@agentclientprotocol/sdk` is pinned to exact `1.4.0`; elicitation uses stable `createElicitation`.

## Architecture (non-obvious)

- `src/index.ts` is the public Cordis plugin entry (`name='acp'`, `inject`, `apply(ctx, config)`). `session.ts` owns per-Agent lifecycle and editor projections; `content.ts`, `mcp.ts`, `model-control.ts`, `updates.ts`, and `elicitation.ts` own their protocol seams. `lib/index.js` is generated and remains the runtime entry.
- `cordis.patch.yml` is the deployment composition: it disables model-facing host rows, disables the shipped `acp`/`acp-app-startup`, mounts host-plane Cordis runners, then mounts unique `acp-editor-startup` and `acp-editor` rows. This keeps `dsh --profile acp` and existing Zed config working without duplicate stdio servers.
- `presets/*.patch.yml` declare `standard`, `ptc`, `minimal`, and `cordis` with `@deepseek-ai/dsh-agent-preset`. Agent tools/persona come from `agentPresets.mount(agentCtx, presetId)` in the factory `setup`, not an in-plugin tool list.
- Agent preset is a process-level deploy value (`DSH_ACP_PRESET` env → `config.preset`), never a session selector. The bundle now supplies the host-plane `cordis-host-runner` / `tool-cordis/host` rows required by creation mode.
- Config env keys read by the patch: `DSH_ACP_PROVIDER`, `DSH_ACP_MODEL`, `DSH_ACP_PRESET`.

## Client quirks (verified the hard way)

- Zed ignores `models`/`modes` whenever `configOptions` is present — every user-visible selector must go into `configOptions`.
- Use stable `sessionUpdate: 'plan'` (flat `entries`), not UNSTABLE `plan_update` — Zed silently drops the latter.
- Defer `available_commands_update` with `setTimeout(0)` so it lands after the `session/new`/`load` response — Zed ignores notifications for unknown sessionIds.
- Smoke test must skip notification frames when awaiting a response (read frames until `id` matches): `usage_update`/`available_commands_update` can precede it.
- Client-forwarded `mcpServers` are validated and mounted into the Agent scope. stdio commands must be absolute; HTTP is Streamable HTTP (http/https), not SSE.

## Docs

Behavior/mapping ground truth lives in `docs/technical.md` (event→ACP mapping tables, elicitation form schema, usage ring, plan fold/replay). Docs are maintained in EN (README) + ZH (`docs/README.zh.md`, `docs/technical.md`) — keep both in sync when changing user-visible behavior, and update the smoke test alongside protocol changes.
