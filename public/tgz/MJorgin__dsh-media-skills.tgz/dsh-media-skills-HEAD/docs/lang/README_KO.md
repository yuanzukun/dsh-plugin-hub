<div align="center">

<img src="../social-preview.png" alt="dsh-media-skills — DeepSeek Harness를 위한 무료 이미지 읽기 및 생성 스킬" width="100%">

<br>

# 🎨 dsh-media-skills

### *채팅창에 이미지를 바로 붙여넣기 —— 무료 비전 모델과 이미지 읽기·생성 스킬*

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](../../LICENSE)
[![Python 3.9+](https://img.shields.io/badge/Python-3.9%2B-blue.svg)](https://python.org)
[![DeepSeek Harness](https://img.shields.io/badge/DeepSeek%20Harness-Skill-4D6BFE)](https://github.com/topics/dsh-plugin)

<br>

[DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)에 「눈」과 「붓」을 ——
무료 스킬 2개, 무료 비전 모델 1개, 텍스트 전용 세션에서의 이미지 붙여넣기까지. 키 하드코딩 없음.

[기능](#-기능) · [빠른 시작](#-빠른-시작) · [사용법](#-사용법) · [비전 설정 가이드](../SETUP_VISION.md)

[**English**](../../README.md) · [**简体中文**](README_ZH.md) · [**繁體中文**](README_ZH_TW.md) · [**日本語**](README_JA.md) · [**한국어**](README_KO.md) · [**Español**](README_ES.md) · [**Deutsch**](README_DE.md) · [**Português**](README_PT.md) · [**Русский**](README_RU.md)

</div>

---

## ✨ 기능

| 기능 | 설명 | 모델 | 비용 |
|---|---|---|---|
| 🖼️ 이미지 붙여넣기 자동 읽기 | **텍스트 전용 세션**(예: deepseek-v4-pro)의 입력창에 「이미지 추가」 버튼(이미지 아이콘)이 생기고, 붙여넣은 이미지는 비전 모델이 자동으로 텍스트 설명으로 변환해 현재 모델에 전달(**v0.1.1부터는 DeepSeek-V4-Flash-Vision-Exp가 기본**) | v0.1.1: DeepSeek-Vision-Exp · rc.7/8: Zhipu GLM-4V-Flash | GLM 무료·DeepSeek 잔액 과금(v0.1.1 기본) |
| 🧠 비전 모델 라우트 | ≤ v0.1.1에서는 설치 후 모델 선택기에 **자동으로** 「智譜 GLM-4V-Flash（視覚）」이 등록됩니다(**v0.1.6**: **설정 → 모델**에서 한 번 직접 추가). 새 세션에서 이미지에 대해 바로 대화 가능 | Zhipu GLM-4V-Flash | 무료 |
| 👁️ `vision-review` | 이미지·스크린샷 분석/인식/설명, UI 시각 버그(겹침·넘침·어긋남) 탐지, 워터마크/로고 감지, 이미지 텍스트화. 엔진 체인: GLM-4V-Flash → DeepSeek-V4-Flash-Vision-Exp(에이전트와 동일 키·선택 유료) → SenseNova / SiliconFlow / Gemini | GLM-4V-Flash＋DeepSeek-Vision-Exp＋SenseNova＋Gemini | 무료(DeepSeek 선택 유료) |
| 🎨 `media-tools` | 이미지·일러스트·아바타·배경·배너 생성 | SenseNova U1 Fast → SiliconFlow Kolors | 무료, 워터마크 없음 |

> ⚠️ 정직한 안내: 「이미지 붙여넣기 자동 읽기」는 DeepSeek Harness **본체** 기능입니다 — **v0.1.6 / v0.1.1**은 기본 제공, rc.7 / rc.8은 동봉된 코어 패치(`api-proxy` 이미지 수용 로직)가 필요합니다. 이 번들이 제공하는 것은 **읽기/생성 스킬**(≤ v0.1.1에서는 모델 라우트 포함)입니다. 비전 모델은 어떤 DSH 빌드에서도 동작합니다.

## ⚡ 빠른 시작

1. 번들 설치:

   ```sh
   dsh plugin --profile <name> add dsh-media-skills
   ```

2. **키**:
   - **v0.1.6**: 설치에는 키 불필요 — 두 스킬이 런타임에 등록됩니다. 스킬용 키(`GLM_API_KEY`, `SILICONFLOW_API_KEY`, 선택 `GEMINI_API_KEY`)는 `~/.dsh/secrets/media-tools.env`에 넣으세요([키](#-키) 참조). 네이티브 모델 라우트는 **설정 → 모델**에서 직접 구성합니다.
   - **v0.1.1-rc.1부터는 추가 키 불필요** — 붙여넣기 읽기와 비전 라우트가 에이전트의 기존 `DEEPSEEK_API_KEY`로 동작합니다. 무료 엔진을 쓰려면(또는 rc.7/rc.8): 먼저 무료로 키 발급 — [open.bigmodel.cn](https://open.bigmodel.cn)에 가입/로그인 → 「API Keys」(glm-4v-flash 무료). 생성도 쓸 거면 [siliconflow.cn](https://siliconflow.cn)에서도 발급(Kolors 무료). 그다음 Zhipu 키 설정 — Web GUI(**설정 → 모델**) 또는 자격증명 파일:

   ```sh
   # ~/.dsh/.credentials.yaml (chmod 600)
   GLM_API_KEY: <내 Zhipu 키>
   ```

3. `dsh web`을 **완전히 재시작**하고 `Cmd+Shift+R`로 강력 새로고침.

4. 확인: 스킬 목록에 **`vision-review`**와 **`media-tools`**가 나타나야 합니다(v0.1.6의 비전 라우트는 **설정 → 모델**에서 직접 추가; ≤ v0.1.1에서는 모델 선택기에 **「智譜 GLM-4V-Flash（視覚）」**이 보입니다). 본체가 붙여넣기 읽기를 지원하면 입력창 왼쪽 아래에 **🖼️「이미지 추가」 버튼**이 보입니다. 아무 세션에 이미지를 붙여넣으면 텍스트 설명으로 도착합니다.

전체 절차·동작 원리·문제 해결: **[../SETUP_VISION.md](../SETUP_VISION.md)**

## 🔑 키

키는 **이 저장소에 절대 저장되지 않습니다**. 스킬 스크립트는 다음 순서로 읽습니다: 환경 변수 → `~/.dsh/secrets/media-tools.env` → `~/.codex/secrets/media-tools.env`(레거시 폴백). 비전 모델 라우트는 DSH 자격증명 저장소에서 `GLM_API_KEY`를 읽습니다 (≤ v0.1.1; v0.1.6에서는 **설정 → 모델**에서 직접 설정합니다).

키 발급처: v0.1.1+는 에이전트의 기존 DEEPSEEK_API_KEY 그대로 사용(추가 발급 불필요). 무료 엔진: Zhipu [open.bigmodel.cn](https://open.bigmodel.cn) → API Keys(glm-4v-flash); SiliconFlow [siliconflow.cn](https://siliconflow.cn) → API Keys(Kolors).

```sh
# ~/.dsh/secrets/media-tools.env (chmod 600, 줄마다 KEY=value)
GLM_API_KEY=...
SILICONFLOW_API_KEY=...
```

## 🖼️ 创作 패널 (데스크톱 0.2.1+)

<img src="../screenshots/panel-generate.png" alt="创作 패널: 왼쪽 입력과 모델/비율/크기, 오른쪽 결과 카드" width="100%">

데스크톱 0.2.1부터 플러그인이 자체 페이지를 등록할 수 있습니다. 이 번들에는 사이드바의 **创作** 페이지가 들어 있습니다:

- **生成**: 프롬프트를 입력하고(⌘⏎ 로도 생성) 모델·비율·1K–4K 크기를 고릅니다. 모델은 "제공자 × 모델"마다 한 줄, 비율은 10가지(스마트 / 1:1 / 9:16 / 16:9 / 3:4 / 4:3 / 2:3 / 3:2 / 9:21 / 21:9)입니다. 모델 상한을 넘는 크기는 조용히 무시되지 않고 회색으로 표시됩니다. 결과는 번호·모델·크기·프롬프트·동작이 담긴 카드 한 장으로 돌아옵니다.
- **作品**: 이 워크스페이스에서 만든 이미지를 콘택트 시트로 봅니다. 타일을 클릭하면 상세 카드가 열리고 설정 재사용, 프롬프트 복사, 원본 열기, 삭제(파일까지 삭제)를 할 수 있습니다. 이미지를 클릭하면 확대되고 `Esc` 로 닫습니다.
- **生图 Key**: 제공자별로 키를 붙여넣습니다. 키는 `~/.dsh/secrets/media-tools.env`(권한 600)에 기록되며 **업로드되지 않고** 생성 외에는 쓰이지 않습니다. 저장된 키는 `••••abcd` 로 표시되고 눈 아이콘으로 잠시 확인할 수 있습니다.
- **키가 하나도 없을 때**: **Flux (免 Key)** 를 고르면 바로 됩니다. Pollinations는 가입도 키도 필요 없습니다(같은 IP에서 45초에 1장, 최대 768×768, 모서리에 작은 로고).

데스크톱 앱 사이드바 **Plugins** → 오른쪽 위 **Add plugin** → 패키지 이름 `dsh-media-skills` 입력 → **Install**. 설치 후 앱을 한 번 재시작하세요(플러그인은 시작할 때 로드됩니다). 터미널에서도 설치할 수 있습니다:

```sh
dsh plugin --profile desktop add dsh-media-skills
```

<img src="../screenshots/panel-works.png" alt="作品: 왼쪽 콘택트 시트, 오른쪽 상세 카드" width="100%">

## 🚀 사용법

이미지를 읽는 세 가지 방법:

| 방법 | 사용법 | 적합한 상황 |
|---|---|---|
| **A. 직접 붙여넣기(권장)** | 아무 세션에서 이미지 버튼 / 드래그 / 붙여넣기 후 전송 | 일상적인 이미지 질문 — 파일 저장·모델 전환 불필요 |
| **B. 비전 모델 세션** | 새 대화에서 「智譜 GLM-4V-Flash（視覚）」을 선택하고 이미지를 붙여넣어 대화 | 이미지 중심의 다중 턴 대화, 네이티브 `read_image` |
| **C. 파일 + 스킬** | 이미지를 작업공간에 두고 "vision-review로 이 이미지를 읽어줘"라고 말하기 | 일괄 검토, 스크립트화된 작업 |

설명 언어는 메시지 언어를 자동으로 따릅니다(중국어 메시지→중국어 설명, 영어 메시지→영어 설명, 텍스트 없음→중국어).

그냥 이렇게 말하세요:

- 「이 이미지 좀 봐줘 / 이 스크린샷에 시각 버그 있는지 확인해줘」→ `vision-review`
- 「〜한 이미지 생성해줘」→ `media-tools`

## 🗺️ 구성

```
dsh-media-skills/
├── package.json           # dsh.bundle 매니페스트
├── cordis.patch.yml       # 플러그인 레이어
├── index.js               # DSH v0.1.6 프로바이더 라이프사이클로 두 스킬 등록
├── skills/
│   ├── vision-review/     # 이미지 읽기
│   └── media-tools/       # 이미지 생성
├── docs/
│   ├── SETUP_VISION.md    # 비전 설정 가이드(중국어)
│   ├── SETUP_VISION_EN.md # detailed setup guide (English)
│   └── lang/              # 각 언어 README
├── scripts/make-banner.py # docs/social-preview.png 재생성
└── docs/social-preview.png
```

## 🤝 DSH 플러그인 생태계에 참여하세요

DeepSeek Harness 개발자 프리뷰는 Harness 개발자 대상 테스트 단계이며, 핵심 플러그인과 기본 API는 계속 발전합니다. 오픈소스·개방적·재사용 가능·조합 가능한 인프라 위에서 전 세계 개발자들과 함께 지능의 한계를 탐험하길 기대합니다.

- [dsh-plugin 토픽](https://github.com/topics/dsh-plugin)
- [빠른 시작](https://deepseek-harness.github.io/deepseek-harness/guide/quickstart)
- [DeepSeek Harness 저장소](https://github.com/deepseek-ai/deepseek-harness)

> 이 저장소에 [`dsh-plugin`](https://github.com/topics/dsh-plugin) 토픽을 달아 다른 사람들이 찾을 수 있게 하세요.

## 📄 License

[MIT](../../LICENSE)
