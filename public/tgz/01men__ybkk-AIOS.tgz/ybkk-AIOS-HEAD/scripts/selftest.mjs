/**
 * 功能自测：启动隔离实例（独立端口 + 独立数据目录），对全链路做端到端断言。
 * 覆盖：认证/RBAC、IAM 生命周期与三方同步、令牌吊销联动、MCP 部署灰度与网关鉴权限流、
 *       Skill 流水线（扫描/两级审批/上架/安装/弃用告警）、Agent/App 生命周期 L4 审批、
 *       on-behalf-of、审计四类日志、告警、成本、工具桥。
 * 用法：npm run selftest
 */
import { spawn } from 'node:child_process'
// NAS 数据权限纯函数引擎（dev-plan-nas-authz O8：引擎直接单测，不经服务层）
import {
  MATRIX_DEFAULT, buildOrgIndex, check as engineCheck, deriveRole, findVacantLeaderOrgs, nearestLeaderOrg,
} from '../packages/plugin-nas/src/authz/engine.ts'
import { readFileSync as __readFileSyncSeed } from 'node:fs'
const NAS_AUTHZ_SEED = JSON.parse(__readFileSyncSeed(new URL('../packages/plugin-nas/seed/nas-authz-rules.json', import.meta.url), 'utf8'))
import { createServer, request as httpRequest } from 'node:http'
import { createHash } from 'node:crypto'
import { rm, mkdir } from 'node:fs/promises'
import { existsSync, readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
// 进程内插件树（dsh 宿主挂载分节：伪造 webServer 模拟 dsh 前缀分发，不经子进程）
import { Context } from '@deepseek-ai/cordis'
import * as platformCore from '../packages/platform-core/src/index.ts'
import * as resourceCore from '../packages/plugin-resource-core/src/index.ts'
import * as iam from '../packages/plugin-iam/src/index.ts'
import * as authn from '../packages/plugin-authn/src/index.ts'
import * as usage from '../packages/plugin-usage/src/index.ts'
import * as audit from '../packages/plugin-audit/src/index.ts'
import * as market from '../packages/plugin-market/src/index.ts'
import * as agent from '../packages/plugin-agent/src/index.ts'
import * as app from '../packages/plugin-app/src/index.ts'
import * as connector from '../packages/plugin-connector/src/index.ts'
import * as mcp from '../packages/plugin-mcp/src/index.ts'
import * as nas from '../packages/plugin-nas/src/index.ts'
import * as skillhub from '../packages/plugin-skillhub/src/index.ts'
import * as modelgw from '../packages/plugin-modelgw/src/index.ts'
import * as connect from '../packages/plugin-connect/src/index.ts'
import * as update from '../packages/plugin-update/src/index.ts'
import * as portal from '../packages/plugin-portal/src/index.ts'
import * as consolePlugin from '../packages/plugin-console/src/index.ts'
import * as panelCore from '../packages/plugin-panel-core/src/index.ts'
import * as dingtalkBridge from '../packages/plugin-dingtalk-bridge/src/index.ts'
import * as dshBridge from '../packages/plugin-dsh-bridge/src/index.ts'

const readBody = (req) => new Promise((resolve) => {
  const chunks = []
  req.on('data', (c) => chunks.push(c))
  req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
})

const PORT = 7311
const BASE = `http://127.0.0.1:${PORT}`
const DATA_DIR = join(process.cwd(), 'data-selftest')

// 收尾阶段（stub close / 实例 SIGKILL 后）undici keep-alive 连接可能出现迟到的 rejection：
// 记录但不让测试进程崩掉（崩了会吞掉汇总输出，2026-09-16 M2 实证）
process.on('unhandledRejection', (reason) => {
  console.error(`\x1b[33m[selftest] 未处理的 rejection（已忽略，不阻断汇总）:\x1b[0m ${String(reason?.cause ?? reason).slice(0, 200)}`)
})

const results = []
let currentSection = ''
function section(name) {
  currentSection = name
  console.log(`\n\x1b[36m━━ ${name} ━━\x1b[0m`)
}
function check(name, condition, detail = '') {
  const pass = Boolean(condition)
  results.push({ section: currentSection, name, pass })
  console.log(`  ${pass ? '\x1b[32m✔' : '\x1b[31m✘'} ${name}\x1b[0m${pass ? '' : `  ← ${detail}`}`)
  return pass
}
async function api(method, path, { token, body } = {}) {
  const headers = { 'content-type': 'application/json' }
  if (token) headers.authorization = `Bearer ${token}`
  const response = await fetch(`${BASE}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) })
  let payload = null
  try { payload = await response.json() } catch { /* ignore */ }
  return { status: response.status, ok: payload?.ok ?? false, data: payload?.data, error: payload?.error }
}

/** 原始 HTTP 请求（OIDC 协议端点：302 Location / WWW-Authenticate / form 编码等需要原始面）。 */
const rawReq = (method, path, { headers = {}, body } = {}) => new Promise((resolve, reject) => {
  const req = httpRequest({ host: '127.0.0.1', port: PORT, method, path, headers }, (res) => {
    const chunks = []
    res.on('data', (chunk) => chunks.push(chunk))
    res.on('end', () => resolve({ status: res.statusCode ?? 0, headers: res.headers, body: Buffer.concat(chunks).toString('utf8') }))
  })
  req.on('error', reject)
  if (body !== undefined) req.write(body)
  req.end()
})
const jsonBody = (raw) => { try { return JSON.parse(raw.body) } catch { return {} } }

/** OIDC 授权流平台端点为原始 JSON 契约（无 {ok,data} 包裹），直连读取。 */
const authReqInfo = async (reqId) => {
  const raw = await rawReq('GET', `/api/authn/oidc/auth-requests/${encodeURIComponent(reqId)}`)
  return { status: raw.status, info: jsonBody(raw) }
}
const authorizeConfirm = async (token, reqId, consent) => {
  const raw = await rawReq('POST', '/api/authn/oidc/authorize', {
    headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
    body: JSON.stringify({ reqId, ...(consent !== undefined ? { consent } : {}) }),
  })
  return { status: raw.status, result: jsonBody(raw) }
}

// ---------------------------------------------------------------- stub 上游仓库（平台更新检查用）
// 进程内真实 HTTP stub：raw package.json（版本 9.9.9）+ compare API（落后 2 个提交）。
// 更新插件经 DSH_UPDATE_RAW_BASE / DSH_UPDATE_API_BASE 指向本 stub，自测不依赖外网。
const GH_PORT = 7361
const ghStub = createServer((req, res) => {
  const url = req.url ?? ''
  if (url.endsWith('/package.json')) {
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(JSON.stringify({ name: 'dsh-enterprise-ops', version: '9.9.9' }))
    return
  }
  if (url.includes('/compare/')) {
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(JSON.stringify({
      behind_by: 2,
      commits: [
        { sha: 'f1111111111111111111111111111111111111111', commit: { message: 'feat: 上游演示提交一', author: { name: '上游作者', date: '2026-08-24T02:00:00Z' } } },
        { sha: 'a2222222222222222222222222222222222222222', commit: { message: 'fix: 上游演示提交二', author: { name: '上游作者', date: '2026-08-24T03:00:00Z' } } },
      ],
    }))
    return
  }
  res.writeHead(404, { 'content-type': 'application/json' })
  res.end('{}')
})
await new Promise((resolve) => ghStub.listen(GH_PORT, '127.0.0.1', resolve))

// ---------------------------------------------------------------- stub NAS 文件网关
// 进程内真实 HTTP stub，复刻 synology-filestation-mcp 契约：
// POST /mcp（initialize / notifications/initialized / tools/list / tools/call），
// 强制校验 Authorization: Bearer 与 X-NAS-IP 设备路由头；fs_upload 按真实网关语义
// 在「网关进程侧」读取 local_file（同机/共享卷契约——本进程可直接读平台 staging 目录）。
const NAS_GW_PORT = 7362
const NAS_GW_TOKEN = 'gw-selftest-token-9f8e7d6c'
const NAS_GW_IP = '192.168.0.196'
const nasGwCalls = []
const nasGwUploads = []
const nasGwStub = createServer(async (req, res) => {
  const json = (status, payload, headers = {}) => {
    res.writeHead(status, { 'content-type': 'application/json', ...headers })
    res.end(JSON.stringify(payload))
  }
  if (req.method !== 'POST' || req.url !== '/mcp') return json(404, { error: 'not found' })
  if (req.headers.authorization !== `Bearer ${NAS_GW_TOKEN}`) return json(401, { jsonrpc: '2.0', id: null, error: { code: -32001, message: '网关鉴权失败' } })
  if (req.headers['x-nas-ip'] !== NAS_GW_IP) return json(400, { jsonrpc: '2.0', id: null, error: { code: -32002, message: '未知 NAS 设备（X-NAS-IP）' } })
  let message = null
  try { message = JSON.parse(await readBody(req)) } catch { return json(400, { jsonrpc: '2.0', id: null, error: { code: -32700, message: 'parse error' } }) }
  const sessionHeaders = { 'mcp-session-id': 'stub-session-selftest' }
  // 通知类消息（无 id）：确认即止
  if (message.id === undefined || message.id === null) { res.writeHead(202, sessionHeaders); res.end(); return }
  const reply = (result) => json(200, { jsonrpc: '2.0', id: message.id, result }, sessionHeaders)
  const replyError = (code, text) => json(200, { jsonrpc: '2.0', id: message.id, error: { code, message: text } }, sessionHeaders)
  if (message.method === 'initialize') {
    return reply({ protocolVersion: '2025-03-26', capabilities: { tools: {} }, serverInfo: { name: 'synology-filestation-stub', version: '1.0.0' } })
  }
  if (message.method === 'tools/list') {
    const names = ['fs_list_shares', 'fs_list', 'fs_get_info', 'fs_search', 'fs_create_folder', 'fs_rename', 'fs_delete', 'fs_upload', 'fs_download', 'fs_task_status']
    return reply({ tools: names.map((name) => ({ name, description: `stub ${name}`, inputSchema: { type: 'object' } })) })
  }
  if (message.method === 'tools/call') {
    const name = String(message.params?.name ?? '')
    const args = message.params?.arguments ?? {}
    nasGwCalls.push({ name, args, onBehalf: req.headers['x-on-behalf-user'] ?? null })
    const text = (value) => reply({ content: [{ type: 'text', text: JSON.stringify(value) }] })
    // 对齐真实 synology-filestation 网关契约（folder_path/path 为字符串/数组；create_folder 用 folder_path+name 一一对应数组；download 用 path 数组 + local_dir）
    if (name === 'fs_list_shares') return text({ shares: [{ name: 'homes', path: '/homes', isdir: true }, { name: 'skillhub', path: '/skillhub', isdir: true }] })
    if (name === 'fs_list') return text({ files: [{ name: 'readme.txt', isdir: false, size: 128 }, { name: 'reports', isdir: true }], total: 2, offset: 0 })
    if (name === 'fs_get_info') {
      const reqPaths = Array.isArray(args.path) ? args.path : [args.path].filter(Boolean)
      return text({ files: reqPaths.map((p) => ({ path: p, name: String(p).split('/').pop(), size: 128, isdir: false })) })
    }
    if (name === 'fs_search') return text({ files: [{ path: `/found/${args.pattern}` }], taskid: 'tsk_1' })
    if (name === 'fs_create_folder') {
      const folders = Array.isArray(args.folder_path) ? args.folder_path : [args.folder_path].filter(Boolean)
      const names = Array.isArray(args.name) ? args.name : [args.name].filter(Boolean)
      return text({ folders: folders.map((folder, i) => ({ path: `${folder}/${names[i] ?? 'new'}`, name: names[i] })) })
    }
    if (name === 'fs_rename') {
      const reqPaths = Array.isArray(args.path) ? args.path : [args.path].filter(Boolean)
      const names = Array.isArray(args.name) ? args.name : [args.name].filter(Boolean)
      return text({ files: reqPaths.map((p, i) => ({ path: `${String(p).split('/').slice(0, -1).join('/')}/${names[i] ?? 'renamed'}`, name: names[i] })) })
    }
    if (name === 'fs_copy_move') return text({ success: true, paths: args.path, dest_folder_path: args.dest_folder_path, moved: !!args.remove_src })
    if (name === 'fs_delete') {
      const reqPaths = Array.isArray(args.path) ? args.path : [args.path].filter(Boolean)
      return text({ success: true, deleted: reqPaths })
    }
    if (name === 'fs_download') {
      const reqPaths = Array.isArray(args.path) ? args.path : [args.path].filter(Boolean)
      const destDir = String(args.local_dir ?? '/tmp')
      const fsPromises = await import('node:fs/promises')
      await fsPromises.mkdir(destDir, { recursive: true })
      const payload = Buffer.from('selftest-download-bytes', 'utf8')
      const written = []
      for (const p of reqPaths) {
        const filename = String(p).split('/').filter(Boolean).pop() ?? 'file.bin'
        const target = `${destDir}/${filename}`
        await fsPromises.writeFile(target, payload)
        written.push({ saved_to: target, bytes: payload.length })
      }
      return text(written[0] ?? { saved_to: destDir, bytes: 0 })
    }
    if (name === 'fs_task_status') return text({ taskid: args.taskid, finished: true })
    if (name === 'fs_upload') {
      // 对齐真实 synology-filestation-mcp 契约：dest_path（目标目录，必填 string）+ local_file（必填 string），
      // 上传文件名取 basename(local_file)；缺必填参数按真实网关回 -32602（zod 校验失败）
      if (typeof args.dest_path !== 'string' || typeof args.local_file !== 'string') {
        return replyError(-32602, 'Input validation error: Invalid arguments for tool fs_upload: Invalid input: expected string, received undefined at dest_path')
      }
      try {
        const buffer = await import('node:fs/promises').then((fs) => fs.readFile(String(args.local_file)))
        const filename = String(args.local_file).split(/[\\/]/).pop()
        nasGwUploads.push({ destPath: args.dest_path, filename, sizeBytes: buffer.length, magic: buffer.subarray(0, 2).toString('latin1'), content: buffer })
        return text({ uploaded: `${args.dest_path}/${filename}`, bytes: buffer.length })
      } catch (error) {
        return reply({ content: [{ type: 'text', text: `fs_upload 网关侧读不到 local_file：${error instanceof Error ? error.message : error}` }], isError: true })
      }
    }
    return replyError(-32601, `未知工具：${name}`)
  }
  return replyError(-32601, `方法不存在：${message.method}`)
})
await new Promise((resolve) => nasGwStub.listen(NAS_GW_PORT, '127.0.0.1', resolve))

// ---------------------------------------------------------------- stub open-connector 数据面网关（v1.4.0 契约）
// 进程内真实 HTTP stub：统一信封 {success,data,meta}/{success:false,errorCode}、
// 强制管理 Bearer、oct_ 令牌策略校验（T-11/T-29）、PUT 四数组严格校验（T-12）、
// token 值仅创建时返回一次、oauth_client_config_required 分支（T-06）、cursor 分页 runs + 注入伪造 run（T-23）。
const OC_STUB_PORT = 7363
const OC_BASE = `http://127.0.0.1:${OC_STUB_PORT}`
const OC_TOKEN = 'oc-selftest-admin-token'
const ocCalls = []          // POST /v1/actions/:id 调用记录 {actionId,bearerOk,alias,idempotencyKey,input}
const ocPuts = []           // PUT /api/runtime-tokens/:id 记录（四数组断言用）
const ocDeletes = []        // DELETE /api/runtime-tokens/:id
let ocMirrorFailOnce = false   // OPT-P1-05：下一次 PUT runtime-token 返回 500（镜像失败注入）
let ocDriftOnMint = null       // OPT-P1-05：下一次 POST runtime-token 先并发收紧权限组再延迟应答（快照漂移注入）
const ocMintedValues = []   // 每次铸造返回的 oct_ 一次性值（T-24 全文扫描名单）
const ocLedgerTokens = new Map()  // id → {policy,name}
const ocTokenByValue = new Map()
const ocConnections = new Map() // service → Map(connectionName → summary)
const ocIdemCache = new Map()   // Idempotency-Key → 完整响应体（24h 重放窗口的 stub 等价物，T-22）
const ocClientsConfigured = new Set()   // 已存 OAuth client 配置的 service
const ocRuns = []           // 伪造/真实 run 日志（runtimeTokenId 维度对账）
const ocCtl = {
  failNextExec: false,        // OPT-P3-01：下一次 /v1/actions 执行回 500（网关 5xx 故障注入）
  connNotAllowedOnce: null,   // 下一次该 tokenValue 执行回 403 connection_not_allowed 后自动清除
  alwaysDenyToken: null,      // 该 tokenValue 执行恒 403 connection_not_allowed（自动恢复重试仍失败路径）
  auditPersistedNext: false,  // 下一次成功执行 meta.auditPersisted=false
  actions: null,              // 当前目录 action 集（null=默认；测试可删改模拟下架）
  overlapDupInRuns: false,    // 分页重叠窗口：第二页重复首条（T-23 去重）
}

const ocActionsDefault = [
  { id: 'hackernews.get_top_stories', name: 'get_top_stories', service: 'hackernews', description: '获取热帖', requiredScopes: [], providerPermissions: [], inputSchema: { type: 'object', properties: { limit: { type: 'number' } } } },
  { id: 'hackernews.fetch_item', name: 'fetch_item', service: 'hackernews', description: '拉取条目', requiredScopes: ['public:read'], inputSchema: { type: 'object' } },
  { id: 'hackernews.submit_post', name: 'submit_post', service: 'hackernews', description: '提交帖子', requiredScopes: ['write:posts'], inputSchema: { type: 'object', properties: { title: { type: 'string' }, url: { type: 'string' } } } },
  { id: 'github.list_issues', name: 'list_issues', service: 'github', description: '列 issue', requiredScopes: ['repo:read'], inputSchema: { type: 'object' } },
  { id: 'github.create_issue', name: 'create_issue', service: 'github', description: '建 issue', requiredScopes: ['repo:write'], inputSchema: { type: 'object', properties: { title: { type: 'string' } } } },
  { id: 'github.delete_webhook', name: 'delete_webhook', service: 'github', description: '删除 webhook', requiredScopes: ['webhook:admin'], inputSchema: { type: 'object' } },
  { id: 'hackernews.do_the_thing', name: 'do_the_thing', service: 'hackernews', description: '无 scope 无名可判定的动作', requiredScopes: [], inputSchema: { type: 'object' } },
]
const ocProvidersDefault = [
  { service: 'hackernews', name: 'Hacker News', description: 'no_auth 示例', auth: [{ type: 'no_auth' }] },
  { service: 'github', name: 'GitHub', description: 'OAuth+API Key 示例', auth: [{ type: 'oauth' }, { type: 'api_key' }] },
  // resource 正则拒绝纳管的反例（T-03）
  { service: 'weird service!', name: 'Weird', description: '非法 service 标识', auth: [] },
]

let ocSeq = 10
const ocEnvelope = (res, status, payload) => {
  res.writeHead(status, { 'content-type': 'application/json' })
  res.end(JSON.stringify(payload))
}
const ocAdmin = (req) => req.headers.authorization === `Bearer ${OC_TOKEN}`
const ocPolicyFits = (tokenPolicy, actionId) => {
  const allowed = tokenPolicy.allowedActions ?? []
  return allowed.includes('*') || allowed.includes(actionId)
    || allowed.some((p) => typeof p === 'string' && p.endsWith('.*') && actionId.startsWith(p.slice(0, -2)))
}

const ocStub = createServer(async (req, res) => {
  const url = new URL(req.url ?? '/', OC_BASE)
  const path = url.pathname
  const bodyText = await readBody(req)
  let body = {}
  try { body = bodyText ? JSON.parse(bodyText) : {} } catch { /* ignore */ }
  // 健康探测与数据面执行（oct_）公开于管理门禁之外；/api/* 一律 admin Bearer
  const bearerValue = String(req.headers.authorization ?? '').replace(/^Bearer\s+/i, '')
  const isKnownOct = ocTokenByValue.has(bearerValue)
  if (req.method === 'GET' && path === '/v1/health') {
    return ocEnvelope(res, 200, { success: true, data: { ok: true, runtime: 'oomol-connect' } })
  }
  const isDataPlaneExec = /^\/v1\/actions\/[^/]+$/.test(path) && req.method === 'POST'
  if (!path.startsWith('/oauth/callback') && !isDataPlaneExec && !ocAdmin(req)) {
    return ocEnvelope(res, 401, { success: false, errorCode: 'unauthorized', message: '管理接口需要 Bearer 口令' })
  }
  void isKnownOct

  // -- 目录 ---------------------------------------------------------------
  if (req.method === 'GET' && path === '/v1/providers') {
    return ocEnvelope(res, 200, { success: true, data: ocProvidersDefault })
  }
  if (req.method === 'GET' && path === '/v1/actions') {
    return ocEnvelope(res, 200, { success: true, data: (ocCtl.actions ?? ocActionsDefault), ...(url.searchParams.get('service') ? {} : {}) })
  }
  const actionDetailMatch = path.match(/^\/v1\/actions\/([^/]+)$/)
  if (req.method === 'GET' && actionDetailMatch) {
    const found = (ocCtl.actions ?? ocActionsDefault).find((item) => item.id === decodeURIComponent(actionDetailMatch[1]))
    if (!found) return ocEnvelope(res, 404, { success: false, errorCode: 'unknown_action' })
    return ocEnvelope(res, 200, { success: true, data: found })
  }
  const guideMatch = path.match(/^\/api\/actions\/([^/]+)\/agent\.md$/)
  if (req.method === 'GET' && guideMatch) {
    res.writeHead(200, { 'content-type': 'text/markdown; charset=utf-8' })
    res.end(`## 连接指南（stub agent.md）\n\n为 ${decodeURIComponent(guideMatch[1])} 配置连接：先注册 OAuth App / 准备 API Key。\n`)
    return
  }

  // -- 连接 ---------------------------------------------------------------
  if (req.method === 'GET' && path === '/api/connections') {
    const all = [...ocConnections.values()].flatMap((m) => [...m.values()])
    return ocEnvelope(res, 200, { success: true, data: all })
  }
  const connectionMatch = path.match(/^\/api\/connections\/([^/]+)$/)
  if (req.method === 'PUT' && connectionMatch) {
    const service = decodeURIComponent(connectionMatch[1])
    if (!ocConnections.has(service)) ocConnections.set(service, new Map())
    const summary = {
      id: `oc-con-${++ocSeq}`,
      service,
      connectionName: String(body.connectionName ?? ''),
      authType: body.authType === 'custom_credential' ? 'custom_credential' : 'api_key',
      configured: true,
      virtual: false,
      default: Boolean(body.default),
      profile: { ...Object.fromEntries(Object.entries(body.values ?? {}).map(([k, v]) => [k, typeof v === 'string' ? `${String(v).slice(0, 4)}***` : v])) },
    }
    ocConnections.get(service).set(summary.connectionName, summary)
    return ocEnvelope(res, 200, { success: true, data: summary }) // 成功状态码上游未载——按默认 200 断言信封
  }
  if (req.method === 'DELETE' && connectionMatch) {
    const service = decodeURIComponent(connectionMatch[1])
    const removed = ocConnections.get(service)?.delete(String(body.connectionName ?? ''))
    return removed
      ? ocEnvelope(res, 200, { success: true, data: { deleted: true } })
      : ocEnvelope(res, 404, { success: false, errorCode: 'unknown_connection', message: `连接不存在：${service}/${body.connectionName}` })
  }

  // -- OAuth ----------------------------------------------------------------
  if (req.method === 'POST' && path === '/api/oauth/authorizations') {
    const service = String(body.service ?? '')
    if (!ocClientsConfigured.has(service)) {
      return ocEnvelope(res, 400, { success: false, errorCode: 'oauth_client_config_required', message: `${service} 未存 client 配置` })
    }
    const state = `st-${++ocSeq}`
    pendingOauth.set(state, { service, connectionName: String(body.connectionName ?? '') })
    return ocEnvelope(res, 200, { success: true, data: { authorizationUrl: `${OC_BASE}/oauth/authorize?state=${state}`, state } })
  }
  if (req.method === 'GET' && path === '/oauth/callback') {
    const state = url.searchParams.get('state') ?? ''
    const entry = pendingOauth.get(state)
    if (!entry) {
      res.writeHead(400, { 'content-type': 'text/html; charset=utf-8' }); res.end('<html>bad state</html>'); return
    }
    pendingOauth.delete(state)
    if (!ocConnections.has(entry.service)) ocConnections.set(entry.service, new Map())
    ocConnections.get(entry.service).set(entry.connectionName, {
      id: `oc-con-${++ocSeq}`, service: entry.service, connectionName: entry.connectionName,
      authType: 'oauth', configured: true, virtual: false, default: false,
      profile: { login: 'dsh-selftest' },
    })
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
    res.end('<html><body>授权完成（stub 回调页）</body></html>')
    return
  }

  // -- 运行时令牌 -------------------------------------------------------------
  if (req.method === 'POST' && path === '/api/runtime-tokens') {
    if (ocDriftOnMint) {
      const hook = ocDriftOnMint
      ocDriftOnMint = null
      // 并发收紧权限组（确定性快照漂移注入）+ 延迟应答，保证外层镜像最后落账（ledger 滞后于当前策略）
      await api('PATCH', `/api/connector/perm-groups/${hook.permGroupId}`, { token: hook.token, body: hook.body })
      await new Promise((resolve) => setTimeout(resolve, hook.delayMs ?? 150))
    }
    const requiredArrays = ['allowedActions', 'blockedActions', 'allowedProxies', 'allowedConnections']
    for (const key of requiredArrays) {
      if (!Array.isArray(body[key])) return ocEnvelope(res, 400, { success: false, errorCode: 'invalid_policy_arrays', message: `${key} 必须是数组（四数组全发契约）` })
    }
    const id = `tok-${++ocSeq}`
    const value = `oct_selftest_${++ocSeq}_${Math.random().toString(36).slice(2, 8)}`
    ocLedgerTokens.set(id, { policy: { allowedActions: body.allowedActions, blockedActions: body.blockedActions, allowedProxies: body.allowedProxies, allowedConnections: body.allowedConnections }, name: String(body.name ?? '') })
    ocTokenByValue.set(value, id)
    ocMintedValues.push(value)
    return ocEnvelope(res, 200, { success: true, data: { id, name: body.name, token: value, createdAt: new Date().toISOString(), policy: ocLedgerTokens.get(id).policy } })
  }
  if (req.method === 'GET' && path === '/api/runtime-tokens') {
    return ocEnvelope(res, 200, { success: true, data: [...ocLedgerTokens.entries()].map(([id, rec]) => ({ id, name: rec.name, createdAt: new Date().toISOString(), policy: rec.policy })) })
  }
  const tokenMatch = path.match(/^\/api\/runtime-tokens\/([^/]+)$/)
  if (req.method === 'PUT' && tokenMatch) {
    const id = decodeURIComponent(tokenMatch[1])
    if (ocMirrorFailOnce) {
      ocMirrorFailOnce = false
      return ocEnvelope(res, 500, { success: false, errorCode: 'injected_mirror_failure', message: 'OPT-P1-05 注入：镜像 PUT 失败一次' })
    }
    if (!ocLedgerTokens.has(id)) return ocEnvelope(res, 404, { success: false, errorCode: 'unknown_token' })
    for (const key of ['allowedActions', 'blockedActions', 'allowedProxies', 'allowedConnections']) {
      if (!Array.isArray(body[key])) return ocEnvelope(res, 400, { success: false, errorCode: 'invalid_policy_arrays', message: `${key} 缺失或非数组（PUT 四数组全发契约）` })
    }
    ocLedgerTokens.get(id).policy = { allowedActions: body.allowedActions, blockedActions: body.blockedActions, allowedProxies: body.allowedProxies, allowedConnections: body.allowedConnections }
    ocPuts.push({ id, policy: ocLedgerTokens.get(id).policy })
    return ocEnvelope(res, 200, { success: true, data: { id, policy: ocLedgerTokens.get(id).policy } })
  }
  if (req.method === 'DELETE' && tokenMatch) {
    const id = decodeURIComponent(tokenMatch[1])
    ocDeletes.push(id)
    ocLedgerTokens.delete(id)
    return ocEnvelope(res, 200, { success: true, data: { deleted: true } })
  }

  // -- 数据面执行 --------------------------------------------------------------
  const execMatch = path.match(/^\/v1\/actions\/([^/]+)$/)
  if (req.method === 'POST' && execMatch) {
    const bearer = String(req.headers.authorization ?? '').replace(/^Bearer\s+/i, '')
    const tokenId = ocTokenByValue.get(bearer)
    const actionId = decodeURIComponent(execMatch[1])
    ocCalls.push({
      actionId, bearerOk: Boolean(tokenId),
      alias: req.headers['x-oo-connector-alias'] ?? null,
      idempotencyKey: req.headers['idempotency-key'] ?? null,
      input: body.input ?? {},
    })
    if (!tokenId) return ocEnvelope(res, 401, { success: false, errorCode: 'unauthorized', message: '缺少合法 oct_ 运行时令牌' })
    // 数据面独立强制（T-29）与策略镜像一致性（T-11）：令牌 policy 与请求 action 不符即 403，
    // 越权在凭证加载前拒绝——即使调用方完全绕开平台侧权限组也一样。
    const record = ocLedgerTokens.get(tokenId)
    if (!record || !ocPolicyFits(record.policy, actionId)) {
      return ocEnvelope(res, 403, { success: false, errorCode: 'forbidden_action', message: `action ${actionId} 不在该运行时令牌 allowedActions 内` })
    }
    const allowedConnections = record.policy.allowedConnections ?? []
    if (allowedConnections.length > 0) {
      const alias = req.headers['x-oo-connector-alias']
      const boundSummary = [...ocConnections.values()].flatMap((m) => [...m.values()])
        .find((s) => s.id === allowedConnections[0] || s.connectionName === alias)
      if (!boundSummary) return ocEnvelope(res, 403, { success: false, errorCode: 'connection_not_allowed', message: `连接未获令牌授权：${alias ?? '(default)'}` })
    }
    // 哨兵 '*ANY*' 匹配任意合法 oct_（测试注入用），否则按精确值匹配
    const denyOnceMatch = ocCtl.connNotAllowedOnce !== null && (ocCtl.connNotAllowedOnce === '*ANY*' || ocCtl.connNotAllowedOnce === bearer)
    if (denyOnceMatch) {
      ocCtl.connNotAllowedOnce = null
      return ocEnvelope(res, 403, { success: false, errorCode: 'connection_not_allowed' })
    }
    const denyAlwaysMatch = ocCtl.alwaysDenyToken !== null && (ocCtl.alwaysDenyToken === '*ANY*' || ocCtl.alwaysDenyToken === bearer)
    if (denyAlwaysMatch) {
      return ocEnvelope(res, 403, { success: false, errorCode: 'connection_not_allowed' })
    }
    if (ocCtl.failNextExec) {
      ocCtl.failNextExec = false
      return ocEnvelope(res, 500, { success: false, errorCode: 'injected_gateway_error', message: 'OPT-P3-01 注入：网关 5xx' })
    }
    const executionId = `exec-${++ocSeq}`
    ocRuns.push({ id: executionId, service: actionId.split('.')[0], actionId, ok: true, runtimeTokenId: tokenId, caller: 'http', startedAt: new Date().toISOString(), latencyMs: 12 })
    const successPayload = {
      success: true,
      data: { echo: body.input ?? {}, viaAlias: req.headers['x-oo-connector-alias'] ?? null, replayKey: req.headers['idempotency-key'] ?? null },
      meta: { executionId, actionId, auditPersisted: !ocCtl.auditPersistedNext },
    }
    // T-22：同 Idempotency-Key 在重放窗口内返回原响应（含原 executionId），不产生重复 run
    if (req.headers['idempotency-key']) {
      const key = String(req.headers['idempotency-key'])
      const cached = ocIdemCache.get(key)
      if (cached) return ocEnvelope(res, 200, cached)
      ocIdemCache.set(key, successPayload)
      // 注入的伪造 run 会在下一个调用带同键时被消费为空（避免污染去重断言）
    }
    return ocEnvelope(res, 200, successPayload)
  }

  // -- runs 对账视图（cursor 分页 + 重叠窗口 + 伪造注入） ----------------------------------
  if (req.method === 'GET' && path === '/api/runs') {
    let items = [...ocRuns]
    const fakeCount = Number(url.searchParams.get('injectFakeBypass') ?? 0)
    for (let i = 0; i < fakeCount; i++) {
      items.push({ id: `fake-bypass-${Date.now()}-${i}`, service: 'github', actionId: 'github.list_issues', ok: true, runtimeTokenId: [...ocLedgerTokens.keys()][0] ?? 'tok-foreign', caller: 'direct-sidecar', startedAt: new Date(Date.now() + i * 1000).toISOString() })
    }
    items.sort((a, b) => a.startedAt.localeCompare(b.startedAt))
    const cursorRaw = url.searchParams.get('cursor')
    let offset = 0
    if (cursorRaw) {
      try { offset = Number(JSON.parse(decodeURIComponent(cursorRaw)).i ?? 0) } catch { offset = 0 }
    }
    const limit = Math.max(1, Number(url.searchParams.get('limit') ?? 100))
    let page = items.slice(offset, offset + limit)
    const nextOffset = offset + limit
    // T-23 重叠窗口：第二页首条重复第一页末条（cursor 分页去重由平台侧负责）
    if (offset > 0 && nextOffset < items.length && ocCtl.overlapDupInRuns && page.length > 0) {
      page = [items[offset - 1], ...page]
    }
    const payload = { items: page }
    if (nextOffset < items.length) {
      payload.nextCursor = encodeURIComponent(JSON.stringify({ startedAt: page[page.length - 1].startedAt, i: nextOffset }))
    }
    return ocEnvelope(res, 200, { success: true, data: payload })
  }

  // -- MCP 桥接端点（POST /mcp，与平台同形态；供 M0 importServices 探测） ----------------------
  if (req.method === 'POST' && path === '/mcp') {
    let msg = {}
    try { msg = JSON.parse(bodyText) } catch { /* ignore */ }
    const jsonrpc = { jsonrpc: '2.0', id: msg.id }
    if (msg.method === 'initialize') {
      return ocEnvelope(res, 200, { ...jsonrpc, result: { protocolVersion: '2025-03-26', capabilities: {}, serverInfo: { name: 'open-connector-stub', version: '1.4.0' } } })
    }
    // M0 数据面鉴权（对齐集成指南 v0.2 §五）：Bearer 为管理口令（bootstrap 形态）或合法 oct_
    const mcpBearer = String(req.headers.authorization ?? '').replace(/^Bearer\s+/i, '')
    if (!ocAdmin(req) && !ocTokenByValue.has(mcpBearer)) {
      return ocEnvelope(res, 401, { ...jsonrpc, error: { code: -32001, message: '/mcp 数据面需 Bearer 管理口令或合法 oct_ 运行时令牌' } })
    }
    if (msg.method === 'tools/list') {
      const legacyNames = ['hackernews_get_top_stories', 'hackernews_fetch_item', 'hackernews_submit_post', 'github_list_issues', 'github_create_issue']
      const tools = [
        // 上游文档未细载项：真实 /mcp 以 execute_action(actionId,input) 为准（cto-doc-agent 核对结论）
        { name: 'execute_action', description: 'execute an open-connector action', inputSchema: { type: 'object', properties: { actionId: { type: 'string' }, input: { type: 'object' } }, required: ['actionId'] } },
        ...legacyNames.map((name) => ({ name, description: `stub ${name}（legacy 别名形态）`, inputSchema: { type: 'object' } })),
      ]
      return ocEnvelope(res, 200, { ...jsonrpc, result: { tools } })
    }
    if (msg.method === 'tools/call') {
      const toolName = String(msg.params?.name ?? '')
      const argsIn = msg.params?.arguments ?? {}
      if (toolName === 'execute_action') {
        const executionId = `exec-mcp-${++ocSeq}`
        ocCalls.push({ actionId: String(argsIn.actionId ?? ''), bearerOk: true, alias: null, idempotencyKey: null, input: argsIn.input ?? {} })
        ocRuns.push({ id: executionId, service: String(argsIn.actionId ?? '').split('.')[0], ok: true, startedAt: new Date().toISOString(), latencyMs: 9 })
        return ocEnvelope(res, 200, { ...jsonrpc, result: { content: [{ type: 'text', text: JSON.stringify({ bridgeEcho: argsIn, runId: executionId }) }] } })
      }
      ocCalls.push({ actionId: toolName.replace(/_([a-z])/g, '.$1'), bearerOk: true, alias: null, idempotencyKey: null, input: argsIn })
      const executionId = `exec-mcp-${++ocSeq}`
      ocRuns.push({ id: executionId, service: 'hackernews', ok: true, startedAt: new Date().toISOString(), latencyMs: 9 })
      return ocEnvelope(res, 200, { ...jsonrpc, result: { content: [{ type: 'text', text: JSON.stringify({ bridgeEcho: argsIn, runId: executionId }) }] } })
    }
    return ocEnvelope(res, 200, { ...jsonrpc, error: { code: -32601, message: `方法不存在：${msg.method}` } })
  }

  return ocEnvelope(res, 404, { success: false, errorCode: 'not_found', message: path })
})
const pendingOauth = new Map()
await new Promise((resolve) => ocStub.listen(OC_STUB_PORT, '127.0.0.1', resolve))

// ---------------- 启动隔离实例
console.log('\x1b[90m» 启动隔离测试实例…\x1b[0m')
await rm(DATA_DIR, { recursive: true, force: true })
await mkdir(DATA_DIR, { recursive: true })
const proc = spawn(process.execPath, ['src/main.ts', '--port', String(PORT), '--data', DATA_DIR], {
  stdio: ['ignore', 'pipe', 'pipe'],
  // DEMO_SEED：自测基于完整演示种子（隔离实例，不触碰生产 data/）
  // DSH_UPDATE_*：更新检查指向本进程 stub 上游；关闭启动自动首查保证断言确定性
  env: {
    ...process.env,
    DEMO_SEED: '1',
    // 连接器纳管：强制 env 由自测进程下发（fail-closed 门禁的绿路前提）；
    // 桥接 stub 地址 + 演示种子开关（网关/连接/权限组模板）
    OOMOL_CONNECT_ENCRYPTION_KEY: 'selftest-encryption-key-not-a-secret',
    OOMOL_CONNECT_ADMIN_TOKEN: OC_TOKEN,
    OOMOL_CONNECT_STUB_URL: OC_BASE,
    OOMOL_CONNECT_DEMO_SEED: '1',
    DSH_UPDATE_RAW_BASE: `http://127.0.0.1:${GH_PORT}`,
    DSH_UPDATE_API_BASE: `http://127.0.0.1:${GH_PORT}`,
    DSH_UPDATE_AUTO_CHECK: 'off',
    // OIDC 授权请求 TTL 压到 2 秒：过期路径可在自测内确定性验证（正常流程毫秒级完成不受影响）
    OIDC_AUTHREQ_TTL_SECONDS: '2',
    // 门户 downloadUrl 生成基址指向自测实例：门户技能包下载断言可直连验证
    PORTAL_PUBLIC_BASE: `http://127.0.0.1:${PORT}`,
  },
})
const serverLogChunks = []
proc.stdout.on('data', (chunk) => serverLogChunks.push(chunk))
proc.stderr.on('data', (chunk) => { serverLogChunks.push(chunk); process.stderr.write(`\x1b[90m[server] ${chunk}\x1b[0m`) })

let booted = false
for (let i = 0; i < 40; i++) {
  await new Promise((resolve) => setTimeout(resolve, 500))
  try {
    const probe = await fetch(`${BASE}/api/health`)
    if (probe.ok) { booted = true; break }
  } catch { /* retry */ }
}
if (!booted) {
  console.error('\x1b[31m实例启动失败\x1b[0m')
  proc.kill('SIGKILL')
  process.exit(1)
}
// 轮询等待种子数据就绪（工具注册 + Agent 上线 + 调用记录）
let seeded = false
for (let i = 0; i < 60; i++) {
  await new Promise((resolve) => setTimeout(resolve, 500))
  try {
    const probe = await api('POST', '/api/auth/login', { body: { username: 'admin', password: 'Ybk@2026' } })
    if (!probe.ok) continue
    const info = await api('GET', '/api/platform/info', { token: probe.data.token })
    const overview = await api('GET', '/api/overview', { token: probe.data.token })
    if (info.data?.tools?.length >= 37 && overview.data?.agents?.online >= 5 && overview.data?.mcp?.totalCalls > 100) {
      seeded = true
      break
    }
  } catch { /* retry */ }
}
if (!seeded) console.log('[33m! 种子数据就绪超时，部分断言可能失败[0m')

try {
  // ================================================================ 基础与认证
  section('平台健康与登录')
  const health = await api('GET', '/api/health')
  check('健康检查', health.ok)

  const noAuth = await api('GET', '/api/overview')
  check('无令牌访问被拒绝（401）', noAuth.status === 401)

  const badLogin = await api('POST', '/api/auth/login', { body: { username: 'admin', password: 'wrong' } })
  check('错误密码被拒绝', badLogin.status === 401)

  const adminLogin = await api('POST', '/api/auth/login', { body: { username: 'admin', password: 'Ybk@2026' } })
  check('管理员登录成功', adminLogin.ok && adminLogin.data.token.startsWith('dst1.'))
  const admin = adminLogin.data.token
  check('登录返回权限点（含 *）', adminLogin.data.user.permissions.includes('*'))

  // 三方登录完整链路（IdentityProviderAdapter：authorize → state → code → normalize）
  const authorize = await api('POST', '/api/auth/sso/authorize', { body: { provider: 'dingtalk', scene: 'web_qr' } })
  check('SSO 发起授权（签发 state）', authorize.ok && authorize.data.state.length >= 32)
  check('SSO 授权地址不带 prompt=consent（已授权用户可静默通过，缩短回跳链路）',
    typeof authorize.data.authorizeUrl === 'string' && authorize.data.authorizeUrl.includes('login.dingtalk.com/oauth2/auth')
    && !authorize.data.authorizeUrl.includes('prompt=consent') && authorize.data.authorizeUrl.includes('scope=openid'))
  const sso = await api('POST', '/api/auth/sso', { body: { provider: 'dingtalk', code: 'DD0002', state: authorize.data.state } })
  check('钉钉免密登录（身份链接命中）', sso.ok && sso.data.kind === 'hit' && sso.data.user.username === 'linxm')
  check('登录返回 refresh token（7d 轮转链）', typeof sso.data.refreshToken === 'string' && sso.data.refreshToken.startsWith('dstr_'))

  // 攻击演练 1：state 重放拒绝
  const stateReplay = await api('POST', '/api/auth/sso', { body: { provider: 'dingtalk', code: 'DD0002', state: authorize.data.state } })
  check('state 重放被拒绝（防 CSRF）', stateReplay.status === 401)

  // 攻击演练 2：伪造 state 拒绝
  const stateForged = await api('POST', '/api/auth/sso', { body: { provider: 'dingtalk', code: 'DD0002', state: 'forged-state-000' } })
  check('伪造 state 被拒绝', stateForged.status === 401)

  // 攻击演练 3：code 重放拒绝（5 分钟窗口内单次消费）
  const authorize2 = await api('POST', '/api/auth/sso/authorize', { body: { provider: 'dingtalk', scene: 'web_qr' } })
  await api('POST', '/api/auth/sso', { body: { provider: 'dingtalk', code: 'DD0004', state: authorize2.data.state } }).catch(() => null)
  const codeReplayAuth = await api('POST', '/api/auth/sso/authorize', { body: { provider: 'dingtalk', scene: 'web_qr' } })
  const codeReplay = await api('POST', '/api/auth/sso', { body: { provider: 'dingtalk', code: 'DD0004', state: codeReplayAuth.data.state } })
  check('code 重放被拒绝（单次消费）', codeReplay.status === 401)

  // 未命中 → 待绑定票据 → 绑定已有账号
  const authorize3 = await api('POST', '/api/auth/sso/authorize', { body: { provider: 'dingtalk', scene: 'h5' } })
  const pending = await api('POST', '/api/auth/sso', { body: { provider: 'dingtalk', code: 'DD0003', state: authorize3.data.state } })
  check('未命中身份签发待绑定票据', pending.ok && pending.data.kind === 'pending' && pending.data.profileName === '周既白')
  const bindWrong = await api('POST', '/api/auth/sso/bind', { body: { pendingTicket: pending.data.pendingTicket, username: 'dev', password: 'wrong' } })
  check('绑定校验密码（错误拒绝）', bindWrong.status === 401)
  const bindOk = await api('POST', '/api/auth/sso/bind', { body: { pendingTicket: pending.data.pendingTicket, username: 'dev', password: 'Ybk@2026' } })
  check('绑定已有账号并登录', bindOk.ok && bindOk.data.user.username === 'dev')

  // 唯一约束：已绑定的三方身份（dd_u003→dev）再绑定他人 → 引擎级拒绝
  const opsUser = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('韩若飞'), { token: admin })).data.users[0]
  const dupBind = await api('POST', `/api/iam/users/${opsUser.id}/bindings`, {
    token: admin,
    body: { provider: 'dingtalk', unionId: 'dd_u003', displayName: '周既白', verifyCode: '123456' },
  })
  check('一人一号：身份绑定第二个账号被拒（引擎唯一约束）', !dupBind.ok && JSON.stringify(dupBind.error).includes('唯一约束'))

  // 未命中 → 注册新账号分支
  const authorize5 = await api('POST', '/api/auth/sso/authorize', { body: { provider: 'dingtalk', scene: 'web_qr' } })
  const pending3 = await api('POST', '/api/auth/sso', { body: { provider: 'dingtalk', code: 'DD0006', state: authorize5.data.state } })
  const register = await api('POST', '/api/auth/sso/register', { body: { pendingTicket: pending3.data.pendingTicket } })
  check('三方身份注册新账号并登录', register.ok && register.data.user.username === 'dingtalk_dd_u006')

  const devLogin = await api('POST', '/api/auth/login', { body: { username: 'dev', password: 'Ybk@2026' } })
  check('开发者登录', devLogin.ok)
  let dev = devLogin.data.token

  // ================================================================ RBAC
  section('RBAC 权限模型')
  const devForbidden = await api('POST', '/api/iam/orgs', { token: dev, body: { name: '越权组织' } })
  check('开发者创建组织被拒（403）', devForbidden.status === 403)

  const auditorLogin = await api('POST', '/api/auth/login', { body: { username: 'audit', password: 'Ybk@2026' } })
  const auditor = auditorLogin.data.token
  const auditorWrite = await api('POST', '/api/iam/users', { token: auditor, body: { username: 'x', displayName: 'x', orgId: 'y' } })
  check('审计员写操作被拒', auditorWrite.status === 403)
  const auditorRead = await api('GET', '/api/audit/logs', { token: auditor })
  check('审计员读日志放行', auditorRead.ok)

  // ================================================================ 工作台
  section('工作台聚合')
  const overview = await api('GET', '/api/overview', { token: admin })
  check('总览数据完整', overview.ok
    && overview.data.iam.users >= 10
    && overview.data.mcp.totalCalls > 0
    && overview.data.agents.online >= 5
    && overview.data.apps.online >= 3
    && overview.data.skills.published >= 6)

  // ================================================================ IAM
  section('组织账号（IAM）')
  const newOrg = await api('POST', '/api/iam/orgs', { token: admin, body: { name: '自测事业部' } })
  check('创建组织', newOrg.ok && newOrg.data.id.startsWith('org_'))

  const dupUser = await api('POST', '/api/iam/users', { token: admin, body: { username: 'admin', displayName: '重复', orgId: newOrg.data.id } })
  check('重复用户名被拒', !dupUser.ok)

  const newUser = await api('POST', '/api/iam/users', { token: admin, body: { username: 'selftester', displayName: '测试账号', orgId: newOrg.data.id, title: '测试工程师' } })
  check('创建账号（默认激活）', newUser.ok && newUser.data.status === 'active')
  check('创建账号返回一次性随机初始口令', newUser.ok && typeof newUser.data.initialPassword === 'string' && newUser.data.initialPassword.length >= 16)
  const testerInitialPassword = newUser.data.initialPassword

  // 口令二次修改（传达过程中改为指定口令）
  const pwUser = await api('POST', '/api/iam/users', { token: admin, body: { username: 'pwtest01', displayName: '口令修改测试', orgId: newOrg.data.id } })
  const pwShort = await api('POST', `/api/iam/users/${pwUser.data.id}/reset-password`, { token: admin, body: { password: 'short' } })
  check('指定口令过短被拒（护栏）', !pwShort.ok)
  const pwSet = await api('POST', `/api/iam/users/${pwUser.data.id}/reset-password`, { token: admin, body: { password: 'SelfTest@2026' } })
  check('二次修改为指定口令', pwSet.ok && pwSet.data.initialPassword === 'SelfTest@2026')
  const pwOldLogin = await api('POST', '/api/auth/login', { body: { username: 'pwtest01', password: pwUser.data.initialPassword } })
  check('修改后原口令立即失效', pwOldLogin.status === 401)
  const pwNewLogin = await api('POST', '/api/auth/login', { body: { username: 'pwtest01', password: 'SelfTest@2026' } })
  check('指定口令可登录', pwNewLogin.ok)

  const roleList = await api('GET', '/api/iam/roles', { token: admin })
  const devRole = roleList.data.roles.find((role) => role.code === 'developer')
  const assign = await api('PATCH', `/api/iam/users/${newUser.data.id}`, { token: admin, body: { roleIds: [devRole.id] } })
  check('分配角色', assign.ok && assign.data.roleIds.length === 1)
  check('开发者角色默认含 agent.write（与 app.write 对称，注册/提报更新闭环）', devRole.permissions.includes('agent.write'))

  // 第二审批人账号（与发起人不同账号）：供异人审批/复核类断言使用（同人审批放开后非必需，保留覆盖双人路径）
  const superRole = roleList.data.roles.find((role) => role.code === 'super_admin')
  const approverCreate = await api('POST', '/api/iam/users', { token: admin, body: { username: 'approver02', displayName: '第二审批人', orgId: newOrg.data.id, password: 'Ybk@2026', roleIds: [superRole.id] } })
  check('第二审批人账号就绪', approverCreate.ok && approverCreate.data.roleIds.length === 1)
  const approverLogin = await api('POST', '/api/auth/login', { body: { username: 'approver02', password: 'Ybk@2026' } })
  check('第二审批人可登录', approverLogin.ok && typeof approverLogin.data.token === 'string')
  const approver = approverLogin.data.token

  const importResult = await api('POST', '/api/iam/users/import', { token: admin, body: { items: [
    { username: 'batch01', displayName: '批量一号', orgId: newOrg.data.id },
    { username: 'batch02', displayName: '批量二号', orgId: newOrg.data.id },
  ] } })
  check('批量导入', importResult.ok && importResult.data.created.length === 2)

  const tree = await api('GET', '/api/iam/orgs/tree', { token: admin })
  check('组织树包含新组织', tree.ok && JSON.stringify(tree.data).includes('自测事业部'))

  // 组织改名 / 层级调整（PATCH /api/iam/orgs/:id）
  const siblingOrg = await api('POST', '/api/iam/orgs', { token: admin, body: { name: '自测兄弟部门' } })
  check('创建同级组织（改名冲突靶子）', siblingOrg.ok)
  const renameOrg = await api('PATCH', `/api/iam/orgs/${newOrg.data.id}`, { token: admin, body: { name: '自测事业部（更名）' } })
  check('组织重命名', renameOrg.ok && renameOrg.data.name === '自测事业部（更名）')
  const renameEmpty = await api('PATCH', `/api/iam/orgs/${newOrg.data.id}`, { token: admin, body: { name: '   ' } })
  check('空白名称重命名被拒', !renameEmpty.ok)
  const renameDup = await api('PATCH', `/api/iam/orgs/${newOrg.data.id}`, { token: admin, body: { name: '自测兄弟部门' } })
  check('同级重名重命名被拒', !renameDup.ok)
  const moveOrg = await api('PATCH', `/api/iam/orgs/${newOrg.data.id}`, { token: admin, body: { parentId: siblingOrg.data.id } })
  check('调整上级组织', moveOrg.ok && moveOrg.data.parentId === siblingOrg.data.id)
  const moveSelf = await api('PATCH', `/api/iam/orgs/${newOrg.data.id}`, { token: admin, body: { parentId: newOrg.data.id } })
  check('移动到自身被拒（环检测）', !moveSelf.ok)
  const moveChild = await api('PATCH', `/api/iam/orgs/${siblingOrg.data.id}`, { token: admin, body: { parentId: newOrg.data.id } })
  check('移动到子孙被拒（环检测）', !moveChild.ok)

  // 组织级联一键删除（2026-08）：任意层级可整棵子树删除，直属账号自动上移到上级组织
  const cascadeOrgA = await api('POST', '/api/iam/orgs', { token: admin, body: { name: '自测级联母部门', parentId: siblingOrg.data.id } })
  const cascadeOrgB = await api('POST', '/api/iam/orgs', { token: admin, body: { name: '自测级联子部门', parentId: cascadeOrgA.data.id } })
  const cascadeUser = await api('POST', '/api/iam/users', { token: admin, body: { username: 'cascadeu01', displayName: '级联上移测试', orgId: cascadeOrgB.data.id } })
  check('级联删除靶子就绪（母/子组织 + 直属账号）', cascadeOrgA.ok && cascadeOrgB.ok && cascadeUser.ok)
  const delNonCascade = await api('DELETE', `/api/iam/orgs/${cascadeOrgA.data.id}`, { token: admin })
  check('存在子组织时普通删除被拒并指路', !delNonCascade.ok && JSON.stringify(delNonCascade.error).includes('一键删除'))
  const delCascade = await api('DELETE', `/api/iam/orgs/${cascadeOrgA.data.id}`, { token: admin, body: { cascade: true } })
  check('级联一键删除整棵子树（组织数/上移账号数）', delCascade.ok && delCascade.data.removedOrgs === 2 && delCascade.data.movedUsers === 1, JSON.stringify(delCascade.data))
  const treeAfterCascade = await api('GET', '/api/iam/orgs/tree', { token: admin })
  const treeTextAfterCascade = JSON.stringify(treeAfterCascade.data)
  check('级联后子树全部消失、上级组织仍在', treeAfterCascade.ok && !treeTextAfterCascade.includes('自测级联子部门') && !treeTextAfterCascade.includes('自测级联母部门') && treeTextAfterCascade.includes('自测兄弟部门'))
  const usersAfterCascade = await api('GET', `/api/iam/users?orgId=${siblingOrg.data.id}`, { token: admin })
  check('直属账号自动上移到上级组织', usersAfterCascade.ok && usersAfterCascade.data.users.some((u) => u.username === 'cascadeu01' && u.orgId === siblingOrg.data.id))
  const scratchOrg = await api('POST', '/api/iam/orgs', { token: admin, body: { name: '自测空部门' } })
  const delEmptyOrg = await api('DELETE', `/api/iam/orgs/${scratchOrg.data.id}`, { token: admin })
  check('空组织普通删除仍可用（非级联路径回归）', delEmptyOrg.ok && delEmptyOrg.data.removedOrgs === 1)

  const groupCreate = await api('POST', '/api/iam/groups', { token: admin, body: { name: '自测静态组', type: 'static', memberIds: [newUser.data.id] } })
  check('创建静态用户组', groupCreate.ok)

  // 三方同步 + 冲突
  const sync = await api('POST', '/api/iam/connectors/dingtalk/sync', { token: admin })
  check('钉钉全量同步执行', sync.ok && sync.data.created >= 0)
  const conflicts = await api('GET', '/api/iam/conflicts', { token: admin })
  if (conflicts.data.conflicts.length > 0) {
    const resolved = await api('POST', `/api/iam/conflicts/${conflicts.data.conflicts[0].id}/resolve`, { token: admin, body: { keep: 'third_party' } })
    check('同步冲突处理（以三方为准）', resolved.ok && resolved.data.status === 'resolved')
  } else {
    check('同步冲突队列（无冲突时跳过）', true)
  }

  // 冻结联动：令牌吊销
  section('账号冻结 → 令牌联动吊销')
  const testerLogin = await api('POST', '/api/auth/login', { body: { username: 'selftester', password: testerInitialPassword } })
  check('新账号可登录（随机初始口令）', testerLogin.ok)
  const testerToken = testerLogin.data.token
  const testerMe = await api('GET', '/api/auth/me', { token: testerToken })
  check('新账号令牌可用', testerMe.ok)
  const freezeNoReason = await api('POST', `/api/iam/users/${newUser.data.id}/freeze`, { token: admin, body: {} })
  check('冻结缺少原因被拒（护栏）', !freezeNoReason.ok)
  const freeze = await api('POST', `/api/iam/users/${newUser.data.id}/freeze`, { token: admin, body: { reason: '自测：验证联动吊销' } })
  check('冻结成功', freeze.ok && freeze.data.status === 'frozen')
  const revokedCheck = await api('GET', '/api/auth/me', { token: testerToken })
  check('冻结后令牌立即失效（401）', revokedCheck.status === 401)
  const frozenLogin = await api('POST', '/api/auth/login', { body: { username: 'selftester', password: testerInitialPassword } })
  check('冻结账号无法登录', frozenLogin.status === 401)

  // ================================================================ refresh 轮转链
  section('refresh token 轮转、宽限自愈与重放防护（H3/T-08：多标签页互踩自愈）')
  const rl = await api('POST', '/api/auth/login', { body: { username: 'ops', password: 'Ybk@2026' } })
  check('登录返回令牌对', rl.ok && rl.data.refreshToken)
  const rotated = await api('POST', '/api/auth/refresh', { body: { refreshToken: rl.data.refreshToken } })
  check('refresh 轮转签发新对', rotated.ok && rotated.data.refreshToken !== rl.data.refreshToken)
  const newMe = await api('GET', '/api/auth/me', { token: rotated.data.token })
  check('轮转后新 access 可用', newMe.ok)
  // 宽限窗口：轮转后 30s 内旧 token 再兑换不判重放，签发同链兄弟对（标签 B 401 自愈）
  const graceSibling = await api('POST', '/api/auth/refresh', { body: { refreshToken: rl.data.refreshToken } })
  check('refresh 宽限：轮转后 30s 内旧 token 再兑换成功（多标签自愈，H3/T-08）',
    graceSibling.ok && graceSibling.data.refreshToken !== rotated.data.refreshToken, JSON.stringify(graceSibling.error))
  const graceMe = await api('GET', '/api/auth/me', { token: graceSibling.data.token })
  check('refresh 宽限：宽限签发的兄弟对立即可用', graceMe.ok)
  const rotatedStillOk = await api('GET', '/api/auth/me', { token: rotated.data.token })
  check('refresh 宽限：宽限兑换不吊销原链（兄弟对共存）', rotatedStillOk.ok)
  // 上限兜底：同一旧 token 宽限兑换至 10 次封顶，超限仅拒绝该次请求、不吊销整链
  let capRejected = false
  for (let i = 0; i < 12 && !capRejected; i++) {
    const attempt = await api('POST', '/api/auth/refresh', { body: { refreshToken: rl.data.refreshToken } })
    if (!attempt.ok) capRejected = attempt.status === 401
  }
  check('refresh 宽限：超过兑换上限仅拒绝该次请求（宽限 10 次封顶）', capRejected)
  const capNotRevoked = await api('GET', '/api/auth/me', { token: rotated.data.token })
  check('refresh 宽限：超限拒绝不连带吊销整链', capNotRevoked.ok)

  // ================================================================ Authn
  section('统一认证（机器身份 / 令牌）')
  const cred = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'selftest-ci', refType: 'external', scopes: ['mcp.invoke'] } })
  check('签发机器凭证（secret 一次性返回）', cred.ok && cred.data.clientSecret.startsWith('cs_'))

  // 可绑定资源聚合 + 选择已注册主体自动关联（refType/refId 回填）
  const bindable = await api('GET', '/api/authn/bindable-resources', { token: admin })
  check('可绑定资源聚合（Agent / AI 应用清单）', bindable.ok && Array.isArray(bindable.data.agents) && bindable.data.agents.length > 0 && Array.isArray(bindable.data.apps))
  const agentEntry = bindable.data.agents[0]
  const credBind = await api('POST', '/api/authn/principals', { token: admin, body: { name: `agent:${agentEntry.name}`, refType: 'agent', refId: agentEntry.id, scopes: ['agent.read'] } })
  const principalList = await api('GET', '/api/authn/principals', { token: admin })
  const boundPrincipal = principalList.data.principals.find((p) => p.id === credBind.data.principalId)
  check('选择已注册主体签发 → 凭据自动关联资源', credBind.ok && boundPrincipal?.refType === 'agent' && boundPrincipal?.refId === agentEntry.id)

  const ccBad = await api('POST', '/api/auth/client-credentials', { body: { clientId: cred.data.clientId, clientSecret: 'wrong' } })
  check('错误 client_secret 被拒', ccBad.status === 401)

  const cc = await api('POST', '/api/auth/client-credentials', { body: { clientId: cred.data.clientId, clientSecret: cred.data.clientSecret } })
  check('Client Credentials 登录', cc.ok && cc.data.token.startsWith('dst1.'))
  const machine = cc.data.token

  const machineForbidden = await api('POST', '/api/iam/orgs', { token: machine, body: { name: '机器越权' } })
  check('机器身份越权被拒（scope 限制）', machineForbidden.status === 403)

  const issueToken = await api('POST', '/api/authn/tokens', { token: admin, body: { principalId: cc.data.principal.id, ttlHours: 1, reason: '自测签发' } })
  check('管理端签发令牌', issueToken.ok)
  const revoke = await api('DELETE', `/api/authn/tokens/${issueToken.data.jti}`, { token: admin, body: { reason: '自测吊销' } })
  check('吊销令牌', revoke.ok && revoke.data.revokedAt)
  const revokedUse = await api('GET', '/api/auth/me', { token: issueToken.data.token })
  check('吊销后令牌失效', revokedUse.status === 401)

  // 机器凭证治理：scopes 编辑（联动吊销）/ 密钥轮换 / 列表 hash 脱敏
  const govCred = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'gov-machine', refType: 'external', scopes: ['agent.read'] } })
  const govCc1 = await api('POST', '/api/auth/client-credentials', { body: { clientId: govCred.data.clientId, clientSecret: govCred.data.clientSecret } })
  check('治理夹具：签发 agent.read 机器凭证并换牌', govCc1.ok)

  const scopesPatch = await api('PATCH', `/api/authn/principals/${govCred.data.principalId}`, { token: admin, body: { scopes: ['agent.read', 'usage.write'] } })
  check('调整权限范围 200', scopesPatch.ok && scopesPatch.data.scopes.join(',') === 'agent.read,usage.write')
  const oldTokenAfterPatch = await api('GET', '/api/agents', { token: govCc1.data.token })
  check('调整 scopes 后旧令牌联动吊销（收权即时生效）', oldTokenAfterPatch.status === 401)
  const govCc2 = await api('POST', '/api/auth/client-credentials', { body: { clientId: govCred.data.clientId, clientSecret: govCred.data.clientSecret } })
  check('重新换牌按新范围签发', govCc2.ok && govCc2.data.principal.scopes.join(',') === 'agent.read,usage.write')

  const scopesTypo = await api('PATCH', `/api/authn/principals/${govCred.data.principalId}`, { token: admin, body: { scopes: ['usage.wrtie'] } })
  check('拼错权限点被拒（权限目录校验）', !scopesTypo.ok && JSON.stringify(scopesTypo.error).includes('非法权限点'))
  const scopesStarMix = await api('PATCH', `/api/authn/principals/${govCred.data.principalId}`, { token: admin, body: { scopes: ['*', 'agent.read'] } })
  check("'*' 与其他权限点混用被拒", !scopesStarMix.ok)
  const createTypo = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'typo-machine', refType: 'external', scopes: ['usage.wrtie'] } })
  check('创建凭证即校验权限点（入口防拼错）', !createTypo.ok && JSON.stringify(createTypo.error).includes('非法权限点'))

  // 机器角色：凭证引用组织角色（共用 iam:roles），权限随角色编辑实时同步，无需换牌
  const mrole = await api('POST', '/api/iam/roles', { token: admin, body: { name: '机器角色自测', code: 'mrole_selftest', description: 'selftest', permissions: ['agent.read'] } })
  check('创建机器角色（组织角色目录）', mrole.ok && !!mrole.data.id)
  const roleCred = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'role-machine', refType: 'external', roleIds: [mrole.data.id], scopes: [] } })
  check('签发仅角色授权的机器凭证（scopes 可空）', roleCred.ok)
  const roleCc = await api('POST', '/api/auth/client-credentials', { body: { clientId: roleCred.data.clientId, clientSecret: roleCred.data.clientSecret } })
  check('换牌 scope 解析自角色权限点', roleCc.ok && [...roleCc.data.principal.scopes].sort().join(',') === 'agent.read')
  const roleMachine = roleCc.data.token
  const roleAllowed = await api('GET', '/api/agents', { token: roleMachine })
  check('角色授权机器可调用角色权限范围内的接口', roleAllowed.ok)
  const mroleShrink = await api('PATCH', `/api/iam/roles/${mrole.data.id}`, { token: admin, body: { permissions: ['skill.read'] } })
  const roleAfterShrink = await api('GET', '/api/agents', { token: roleMachine })
  check('角色收权后存量令牌实时降级（无需换牌）', mroleShrink.ok && roleAfterShrink.status === 403)
  const roleCc2 = await api('POST', '/api/auth/client-credentials', { body: { clientId: roleCred.data.clientId, clientSecret: roleCred.data.clientSecret } })
  check('重新换牌按新角色范围签发', roleCc2.ok && [...roleCc2.data.principal.scopes].sort().join(',') === 'skill.read')
  const roleCredPlus = await api('PATCH', `/api/authn/principals/${roleCred.data.principalId}`, { token: admin, body: { roleIds: [mrole.data.id], scopes: ['usage.write'] } })
  const principalAfterPlus = (await api('GET', '/api/authn/principals', { token: admin })).data.principals.find((p) => p.id === roleCred.data.principalId)
  check('角色 + 附加权限点并集生效（列表含角色名与解析后权限）', roleCredPlus.ok && principalAfterPlus.roleNames.includes('机器角色自测') && principalAfterPlus.resolvedScopes.includes('skill.read') && principalAfterPlus.resolvedScopes.includes('usage.write'))
  const emptyAuthz = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'empty-machine', refType: 'external', scopes: [] } })
  check('无角色且无权限点的凭证被拒', !emptyAuthz.ok)
  const ghostRole = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'ghost-machine', refType: 'external', roleIds: ['pri_nonexist'], scopes: ['agent.read'] } })
  check('引用不存在的角色被拒', !ghostRole.ok && JSON.stringify(ghostRole.error).includes('机器角色不存在'))

  const rotateCred = await api('POST', `/api/authn/principals/${govCred.data.principalId}/rotate-secret`, { token: admin })
  check('轮换 clientSecret（clientId 不变 + note 提示 + 无 hash 外发）', rotateCred.ok && rotateCred.data.clientId === govCred.data.clientId && !!rotateCred.data.note && !JSON.stringify(rotateCred.data).includes('Hash'))
  const oldSecretAfterRotate = await api('POST', '/api/auth/client-credentials', { body: { clientId: govCred.data.clientId, clientSecret: govCred.data.clientSecret } })
  check('旧 secret 换牌立即 401', oldSecretAfterRotate.status === 401)
  const newSecretLogin = await api('POST', '/api/auth/client-credentials', { body: { clientId: rotateCred.data.clientId, clientSecret: rotateCred.data.clientSecret } })
  check('新 secret 换牌 200', newSecretLogin.ok)

  const principalsList = await api('GET', '/api/authn/principals', { token: admin })
  check('身份列表不再外发 clientSecretHash', principalsList.ok && !JSON.stringify(principalsList.data).includes('clientSecretHash'))

  // ================================================================ 第 1 步：受众与插件命名空间
  section('第 1 步：令牌受众（aud）与插件命名空间收敛')
  const audPrincipal = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'reporting-svc', refType: 'external', scopes: ['audit.read'] } })
  const audToken = await api('POST', '/api/authn/tokens', { token: admin, body: { principalId: audPrincipal.data.principalId, audience: 'reporting', ttlHours: 1, reason: '受限受众令牌' } })
  check('签发带受众（aud）的令牌', audToken.ok)

  const audOk = await api('POST', '/api/authn/verify-audience', { token: admin, body: { token: audToken.data.token, audience: 'reporting' } })
  check('受众匹配 → 校验通过', audOk.data.valid === true)
  const audMismatch = await api('POST', '/api/authn/verify-audience', { token: admin, body: { token: audToken.data.token, audience: 'market' } })
  check('受众不匹配 → 拒绝', audMismatch.data.valid === false && String(audMismatch.data.reason).includes('受众'))

  const noAudToken = await api('POST', '/api/authn/tokens', { token: admin, body: { principalId: audPrincipal.data.principalId, ttlHours: 1 } })
  const noAudCheck = await api('POST', '/api/authn/verify-audience', { token: admin, body: { token: noAudToken.data.token, audience: 'reporting' } })
  check('无受众令牌访问受众服务被拒', noAudCheck.data.valid === false)

  const pluginScopeOk = await api('POST', '/api/authn/tokens', { token: admin, body: { principalId: audPrincipal.data.principalId, audience: 'plugin:com.demo.kb', scopes: ['plugin:com.demo.kb:read'], ttlHours: 1 } })
  check('插件令牌命名空间内 scope 放行', pluginScopeOk.ok)
  const pluginScopeBad = await api('POST', '/api/authn/tokens', { token: admin, body: { principalId: audPrincipal.data.principalId, audience: 'plugin:com.demo.kb', scopes: ['mcp.invoke'], ttlHours: 1 } })
  check('插件令牌跨命名空间 scope 被拒（唯一收敛面）', !pluginScopeBad.ok && JSON.stringify(pluginScopeBad.error).includes('越界'))

  // ================================================================ 第 2 步：租户最小集 + usage 管道
  section('第 2 步：多租户最小集与 usage 计量管道')
  const tenants = await api('GET', '/api/iam/tenants', { token: admin })
  check('默认租户兜底（存量数据落 t_default）', tenants.ok && tenants.data.tenants.some((t) => t.id === 't_default'))
  const newTenant = await api('POST', '/api/iam/tenants', { token: admin, body: { name: '磁姆科技', plan: 'enterprise' } })
  check('创建租户', newTenant.ok && newTenant.data.id.startsWith('t_'))
  const tenantOrg = await api('POST', '/api/iam/orgs', { token: admin, body: { name: '磁姆中国区', tenantId: newTenant.data.id } })
  check('组织挂载租户', tenantOrg.ok && tenantOrg.data.tenantId === newTenant.data.id)

  const meterInput = { org: tenantOrg.data.id, subject: 'user:' + adminLogin.data.user.id, principal: `org:${tenantOrg.data.id}`, resource: 'mcp:real-backend', meters: [{ key: 'tokens', value: 5000, unit: 'token' }], idempotency_key: 'test-usage-001' }
  const meterA = await api('POST', '/api/usage/record', { token: admin, body: meterInput })
  check('计量事件登记（零价快照 charge=0 + 租户解析）', meterA.ok && meterA.data.pricing.charge_cents === 0 && meterA.data.pricing.rate?.pattern === 'mcp:*' && meterA.data.tenant_id === newTenant.data.id && meterA.data.schema_version === 1)
  const meterDup = await api('POST', '/api/usage/record', { token: admin, body: meterInput })
  check('幂等键重复投递不重复计量', meterDup.ok && meterDup.data.event_id === meterA.data.event_id)
  const meterTotals = await api('GET', '/api/usage/totals?principal=' + encodeURIComponent(`org:${tenantOrg.data.id}`), { token: admin })
  check('租户隔离的计量总额（只计一次）', meterTotals.ok && meterTotals.data.count === 1 && meterTotals.data.charge_cents === 0)
  const meterConflict = await api('POST', '/api/usage/record', { token: admin, body: { ...meterInput, meters: [{ key: 'tokens', value: 999, unit: 'token' }] } })
  check('同幂等键不同内容被拒（防篡改）', !meterConflict.ok && JSON.stringify(meterConflict.error).includes('冲突'))
  const badResource = await api('POST', '/api/usage/record', { token: admin, body: { ...meterInput, idempotency_key: 'test-usage-002', resource: 'not-a-resource' } })
  check('schema v1 校验（resource 格式拒绝）', !badResource.ok)
  const noPrice = await api('POST', '/api/usage/record', { token: admin, body: { ...meterInput, idempotency_key: 'test-usage-003', resource: 'model:no-such-model' } })
  check('无计价规则拒绝登记（不免费放行）', !noPrice.ok && JSON.stringify(noPrice.error).includes('计价'))

  // 计量键硬校验：事件必含价格簿 meter_key（缺失 400 且错误信息携带期望键；不再静默 0 计费）
  const wrongMeterKey = await api('POST', '/api/usage/record', { token: admin, body: { ...meterInput, idempotency_key: 'test-usage-wrong-key-1', meters: [{ key: 'calls', value: 1, unit: '次' }] } })
  check('计量键与价格簿不符被拒（mcp:* 须 tokens，错误可自纠）', !wrongMeterKey.ok && JSON.stringify(wrongMeterKey.error).includes('计量键不匹配') && JSON.stringify(wrongMeterKey.error).includes('tokens'))
  const rightKeyAgain = await api('POST', '/api/usage/record', { token: admin, body: { ...meterInput, idempotency_key: 'test-usage-right-key-1', meters: [{ key: 'tokens', value: 1000, unit: 'token' }] } })
  check('计量键匹配路径计价恒等（1000 tokens 零价快照 charge=0）', rightKeyAgain.ok && rightKeyAgain.data.pricing.charge_cents === 0)

  const reconcile1 = await api('POST', '/api/usage/reconcile', { token: admin })
  check('三方对账：usage 口径 = audit 投影（全量比对）', reconcile1.ok
    && reconcile1.data.reconciliation.mismatch === false
    && reconcile1.data.reconciliation.projections.some((p) => p.consumer === 'audit' && p.count === reconcile1.data.reconciliation.usage.count && p.charge_cents === reconcile1.data.reconciliation.usage.charge_cents))
  check('运行时对账检出未声明能力（M5 漂移）', reconcile1.data.drift.drift.length >= 1)
  const grant = await api('PUT', '/api/usage/capability-grants', { token: admin, body: { principal: `org:${tenantOrg.data.id}`, capabilities: ['mcp:*'] } })
  const reconcile2 = await api('POST', '/api/usage/reconcile', { token: admin })
  const tenantStillDrift = reconcile2.data.drift.drift.find((d) => d.principal === `org:${tenantOrg.data.id}`)
  check('授权后该主体能力漂移消除', grant.ok && tenantStillDrift === undefined)
  const driftAlerts = await api('GET', '/api/audit/alerts', { token: admin })
  check('能力漂移已入告警中心', driftAlerts.ok && JSON.stringify(driftAlerts.data.alerts).includes('能力漂移'))

  // ================================================================ 第 3 步：契约五面 / 事件源校验 / L0 市场
  section('usage 值域扩展（WP-03/D1：app:<id> 与 kb:<orgId>）')
  {
    const appMeter = await api('POST', '/api/usage/record', { token: admin, body: {
      org: tenantOrg.data.id, subject: 'user:' + adminLogin.data.user.id, principal: `org:${tenantOrg.data.id}`,
      resource: 'app:app-selftest-01', meters: [{ key: 'calls', value: 1, unit: 'call' }], idempotency_key: 'test-usage-app-001',
    } })
    check('app:<id> 事件入管道（默认零费率规则播种，charge=0）', appMeter.ok && appMeter.data.pricing.charge_cents === 0, JSON.stringify(appMeter.error))
    check('零费率事件自动标非计费（rate.nonbillable=true，D2 统一零价快照）', appMeter.ok && appMeter.data.pricing.rate?.nonbillable === true)
    const kbMeter = await api('POST', '/api/usage/record', { token: admin, body: {
      org: tenantOrg.data.id, subject: 'user:' + adminLogin.data.user.id, principal: `org:${tenantOrg.data.id}`,
      resource: `kb:${tenantOrg.data.id}`, meters: [{ key: 'calls', value: 3, unit: 'call' }], idempotency_key: 'test-usage-kb-001',
    } })
    check('kb:<orgId> 事件入管道（值域 additive，命中 kb:* 零费率）', kbMeter.ok && kbMeter.data.pricing.charge_cents === 0 && kbMeter.data.pricing.rate?.pattern === 'kb:*', JSON.stringify(kbMeter.error))
    const kbWrongMeter = await api('POST', '/api/usage/record', { token: admin, body: {
      org: tenantOrg.data.id, subject: 'user:' + adminLogin.data.user.id, principal: `org:${tenantOrg.data.id}`,
      resource: `kb:${tenantOrg.data.id}`, meters: [{ key: 'tokens', value: 5, unit: 'token' }], idempotency_key: 'test-usage-kb-002',
    } })
    check('kb:* 计量键仍受价格簿硬校验（须 calls，不静默 0 计费）', !kbWrongMeter.ok && JSON.stringify(kbWrongMeter.error).includes('计量键不匹配'))
  }
  section('零价快照构造（WP-03/D2：nonbillableUsage 便捷入口）')
  {
    const constructed = usage.nonbillableUsage({
      org: tenantOrg.data.id, subject: 'user:' + adminLogin.data.user.id, principal: `org:${tenantOrg.data.id}`,
      resource: `kb:${tenantOrg.data.id}`, idempotency_key: 'test-usage-nbu-001',
    })
    check('nonbillableUsage 便捷构造（calls 计量 + nonbillable 标记）',
      Array.isArray(constructed.meters) && constructed.meters[0]?.key === 'calls' && constructed.nonbillable === true, JSON.stringify(constructed))
    const recorded = await api('POST', '/api/usage/record', { token: admin, body: constructed })
    check('便捷构造事件直入 record（零价入账 + 标记在快照）', recorded.ok && recorded.data.pricing.charge_cents === 0 && recorded.data.pricing.rate?.nonbillable === true, JSON.stringify(recorded.error))
    const nonbillableOnPaid = await api('POST', '/api/usage/record', { token: admin, body: {
      org: tenantOrg.data.id, subject: 'user:' + adminLogin.data.user.id, principal: `org:${tenantOrg.data.id}`,
      resource: 'mcp:real-backend', meters: [{ key: 'tokens', value: 100, unit: 'token' }], idempotency_key: 'test-usage-nb-001', nonbillable: true,
    } })
    check('nonbillable 标记配非零费率规则被拒（防计费口径漂移）', !nonbillableOnPaid.ok && JSON.stringify(nonbillableOnPaid.error).includes('非计费'))
    const orgTotals = await api('GET', '/api/usage/totals?principal=' + encodeURIComponent(`org:${tenantOrg.data.id}`), { token: admin })
    check('零价快照不污染总额（charge 恒 0）', orgTotals.ok && orgTotals.data.charge_cents === 0, JSON.stringify(orgTotals.data))
  }
  section('FinOps 成本穿透（M2 CFO 视图：org×model 交叉 + 环比 + Top 主体）')
  {
    // FinOps 金额口径数据源：model:* 挂内部成本参考费率（10 分/千 tokens）——
    // 默认价格簿无 model 规则（record 硬校验拒收），故全库 model 域事件 = 本节构造的 4 条，断言可精确
    const priceUpsert = await api('PUT', '/api/usage/price-book', { token: admin, body: { pattern: 'model:*', meter_key: 'tokens', list_cents_per_unit: 0, cost_cents_per_unit: 10, units_per_step: 1000, tax_rate: 0, currency: 'CNY', rate_version: 'selftest-finops' } })
    check('价格簿登记 model:*（内部成本 10 分/千 tokens）', priceUpsert.ok, JSON.stringify(priceUpsert.error))
    const finOrg2 = await api('POST', '/api/iam/orgs', { token: admin, body: { name: 'FinOps 探针部' } })
    check('FinOps 第二部门建组织（矩阵第二行）', finOrg2.ok && finOrg2.data.id, JSON.stringify(finOrg2.error))
    const now = Date.now()
    const at = (minutesAgo) => new Date(now - minutesAgo * 60_000).toISOString()
    const finMonth = new Date(now).toISOString().slice(0, 7)
    const probeSubject = 'user:finops-probe-a'
    const recordModel = (resource, tokens, minutesAgo, idem, extra = {}) => api('POST', '/api/usage/record', { token: admin, body: {
      org: tenantOrg.data.id, subject: probeSubject, principal: `org:${tenantOrg.data.id}`,
      resource: `model:${resource}`, meters: [{ key: 'tokens', value: tokens, unit: 'token' }],
      idempotency_key: `finops-${idem}`, occurred_at: at(minutesAgo), ...extra,
    } })
    // 空转判定矩阵（窗口 30 分钟，时间单位=分钟前）：evIdle@60 无后续动作=空转；evFollow@20 在
    // [20, -10] 内有 evAct2@10=非空转；evTrace@55 超窗但同 trace_id 有 evTraceAct@1=非空转；
    // evIdle2@10（agent 主体、另一部门）无动作=空转。model 域总成本 170 分、空转 70 分（41.2%）
    const evIdle = await recordModel('selftest-a', 5000, 60, 'idle-001')
    check('空转样本入账（model a / 5000 tokens → 50 分）', evIdle.ok && evIdle.data.pricing.cost_cents === 50, JSON.stringify(evIdle.error ?? evIdle.data.pricing))
    const evTrace = await recordModel('selftest-b', 6000, 55, 'trace-001', { trace_id: 'finops-trace-1' })
    const evFollow = await recordModel('selftest-a', 4000, 20, 'follow-001')
    const evAct1 = await api('POST', '/api/usage/record', { token: admin, body: { org: tenantOrg.data.id, subject: probeSubject, principal: `org:${tenantOrg.data.id}`, resource: 'mcp:real-backend', meters: [{ key: 'tokens', value: 1000, unit: 'token' }], idempotency_key: 'finops-act-001', occurred_at: at(28) } })
    const evAct2 = await api('POST', '/api/usage/record', { token: admin, body: { org: tenantOrg.data.id, subject: probeSubject, principal: `org:${tenantOrg.data.id}`, resource: 'mcp:real-backend', meters: [{ key: 'tokens', value: 1000, unit: 'token' }], idempotency_key: 'finops-act-002', occurred_at: at(10) } })
    const evTraceAct = await api('POST', '/api/usage/record', { token: admin, body: { org: tenantOrg.data.id, subject: probeSubject, principal: `org:${tenantOrg.data.id}`, resource: 'skill:finops-skill-1', meters: [{ key: 'calls', value: 1, unit: 'call' }], idempotency_key: 'finops-trace-act-001', occurred_at: at(1), trace_id: 'finops-trace-1' } })
    const evIdle2 = await api('POST', '/api/usage/record', { token: admin, body: { org: finOrg2.data.id, subject: 'agent:finops-probe-b', principal: `org:${finOrg2.data.id}`, resource: 'model:selftest-b', meters: [{ key: 'tokens', value: 2000, unit: 'token' }], idempotency_key: 'finops-idle-002', occurred_at: at(10) } })
    check('空转判定场景全部入账（4 model + 3 动作）', evFollow.ok && evAct1.ok && evAct2.ok && evTrace.ok && evTraceAct.ok && evIdle2.ok, JSON.stringify([evFollow.error, evAct1.error, evAct2.error, evTrace.error, evTraceAct.error, evIdle2.error].filter(Boolean)))

    const finOverview = await api('GET', `/api/finops/overview?month=${finMonth}`, { token: admin })
    check('FinOps overview 一次取全（penetration + idle）', finOverview.ok && Boolean(finOverview.data.penetration) && Boolean(finOverview.data.idle), JSON.stringify(finOverview.error))
    const pen = finOverview.data?.penetration
    check('穿透 totals 金额口径（全资源成本 ≥ model 域 170 分）', pen && pen.totals.cost_cents >= 170, JSON.stringify(pen?.totals))
    // demo seed 带 28 天历史（可能跨上月）：环比断言用自洽验证（delta 与 cost/prev 复算一致），不假设基数为 0
    check('穿透环比口径（delta_pct 与 cost/prev 复算自洽，prev=0 且 cur>0 时为 null）', pen && (() => {
      const { cost_cents, prev_cost_cents, delta_pct } = pen.totals
      const expected = prev_cost_cents === 0 ? (cost_cents === 0 ? 0 : null) : Math.round(((cost_cents - prev_cost_cents) / prev_cost_cents) * 1000) / 10
      return delta_pct === expected
    })(), JSON.stringify(pen?.totals))
    check('部门维度含两个探针组织（byOrg 按成本降序）', pen && pen.byOrg.some((r) => r.dimension === tenantOrg.data.id) && pen.byOrg.some((r) => r.dimension === finOrg2.data.id), JSON.stringify(pen?.byOrg?.map((r) => r.dimension)))
    check('模型维度精确两条（selftest-a 90 分 / selftest-b 80 分）', pen && JSON.stringify(pen.byModel.map((r) => `${r.dimension}:${r.cost_cents}`)) === JSON.stringify(['selftest-a:90', 'selftest-b:80']), JSON.stringify(pen?.byModel))
    check('org×model 矩阵行列齐备（Top orgs/models + 「其他」行列）', pen && pen.matrix.orgs.length >= 2 && pen.matrix.models.length >= 2 && pen.matrix.cells.length === pen.matrix.orgs.length + 1 && pen.matrix.cells[0].length === pen.matrix.models.length + 1, JSON.stringify(pen?.matrix))
    check('矩阵总计守恒（全格之和 = model 域成本合计 170 分）', pen && (() => {
      const sumCells = pen.matrix.cells.flat().reduce((s, v) => s + v, 0)
      return sumCells === pen.byModel.reduce((s, r) => s + r.cost_cents, 0)
    })(), JSON.stringify(pen?.matrix?.cells))
    check('Top 消耗主体（探针主体在列）', pen && pen.topSubjects.some((r) => r.subject === probeSubject), JSON.stringify(pen?.topSubjects))
    const idle1 = finOverview.data?.idle
    check('空转判定：恰好 2 条疑似空转（无后续动作的 model 调用）', idle1 && idle1.idle.events === 2, JSON.stringify(idle1))
    check('空转成本精确（50+20=70 分，占 model 域 41.2%）', idle1 && idle1.idle.cost_cents === 70 && idle1.idle.share_pct === 41.2, JSON.stringify(idle1?.idle))
    check('空转分模型拆分（selftest-a/b 各 1 条）', idle1 && idle1.byModel.length === 2 && idle1.byModel.every((r) => r.idle_events === 1), JSON.stringify(idle1?.byModel))
    check('空转分部门拆分（两部门各 1 条）', idle1 && idle1.byOrg.length === 2 && idle1.byOrg.every((r) => r.idle_events === 1), JSON.stringify(idle1?.byOrg))
    check('空转样本可复核（samples 含两条 + 时间/主体/模型齐备）', idle1 && idle1.samples.length === 2 && idle1.samples.every((s) => s.occurred_at && s.subject && s.resource), JSON.stringify(idle1?.samples))
    const idleTight = await api('GET', `/api/finops/idle?month=${finMonth}&window=5`, { token: admin })
    check('空转窗口参数生效（窗口收窄 5 分钟 → evFollow 亦成疑似，空转数上升）', idleTight.ok && idleTight.data.idleWindowMinutes === 5 && idleTight.data.idle.events >= 3, JSON.stringify({ w: idleTight.data?.idleWindowMinutes, idle: idleTight.data?.idle }))
    const finDeniedProbe = await api('POST', '/api/iam/users', { token: admin, body: { username: 'finops_probe', displayName: 'FinOps 权限探针', orgId: tenantOrg.data.id, roleIds: [(await api('GET', '/api/iam/roles', { token: admin })).data.roles.find((r) => r.code === 'member').id] } })
    const finProbeToken = (await api('POST', '/api/auth/login', { body: { username: 'finops_probe', password: finDeniedProbe.data?.initialPassword ?? 'Ybk@2026' } })).data?.token
    const finDenied = await api('GET', '/api/finops/overview', { token: finProbeToken })
    check('无 usage.read 访问 CFO 视图被拒（403）', finDenied.status === 403, String(finDenied.status))
    const finCsv = await rawReq('GET', `/api/finops/report/monthly?month=${finMonth}&format=csv`, { headers: { authorization: `Bearer ${admin}` } })
    check('FinOps CSV 导出（text/csv + BOM + 穿透/空转区块表头）', finCsv.status === 200 && (finCsv.headers['content-type'] ?? '').includes('text/csv') && finCsv.body.startsWith('\ufeff') && finCsv.body.includes('部门穿透') && finCsv.body.includes('空转检测'), JSON.stringify({ status: finCsv.status, head: finCsv.body.slice(0, 80) }))
    const finBadMonth = await api('GET', '/api/finops/overview?month=2026-13', { token: admin })
    check('非法月份参数被拒（400）', finBadMonth.status === 400, String(finBadMonth.status))
  }
  section('首启 bootstrap 状态（M2 部署产品化：上线三步走数据源）')
  {
    const bootAnon = await rawReq('GET', '/api/platform/bootstrap', { headers: {} })
    const bootAnonBody = jsonBody(bootAnon)
    check('bootstrap 公开端点可达（登录页提示数据源，匿名可读）', bootAnon.status === 200 && typeof bootAnonBody.data?.initialPasswordPending === 'boolean', JSON.stringify({ status: bootAnon.status, body: bootAnonBody }))
    check('演示种子无初始口令待接管（DEMO 口令显式指定不落盘）', bootAnonBody.data?.initialPasswordPending === false, JSON.stringify(bootAnonBody))
    const bootDetailAnon = await rawReq('GET', '/api/platform/bootstrap/detail', { headers: {} })
    check('bootstrap detail 强制鉴权（匿名 401）', bootDetailAnon.status === 401, String(bootDetailAnon.status))
    const bootDetail = await api('GET', '/api/platform/bootstrap/detail', { token: admin })
    check('bootstrap detail 全量（demo 模式 + 根组织 + seededAt）', bootDetail.ok && bootDetail.data.initialized === true && bootDetail.data.mode === 'demo' && bootDetail.data.orgName === '元冰可集团' && Boolean(bootDetail.data.seededAt) && bootDetail.data.initialPasswordPending === false, JSON.stringify(bootDetail.data))
  }
  section('T2 远程接入降级审计接线（connect.degraded 落审计链）')
  {
    // 行为面（emit→审计落库）由 connect 客户端形态真实触发，隔离实例为 host 形态；
    // 此处以接线完整性断言护航（双侧源码在位：emit 点 + audit 订阅点）
    const auditSrc = readFileSync(join(process.cwd(), 'packages', 'plugin-audit', 'src', 'index.ts'), 'utf8')
    const connectSrc = readFileSync(join(process.cwd(), 'packages', 'plugin-connect', 'src', 'client.ts'), 'utf8')
    const connectIdx = readFileSync(join(process.cwd(), 'packages', 'plugin-connect', 'src', 'index.ts'), 'utf8')
    check('audit 已订阅 connect.degraded（T2 收口：降级显式留痕，不再只到总线为止）', auditSrc.includes("platformBus.on('connect.degraded'"))
    check('connect 降级事件源在位（扩展点缺失 + 转发失败两条 fail-closed 路径均发事件）',
      connectSrc.includes("emit('connect.degraded'") && connectIdx.includes("emit('connect.degraded'"))
  }
  section('T6 billing 残留防复发（集成面零 precheckCents）')
  {
    const dshctl = readFileSync(join(process.cwd(), 'cli', 'dshctl.mjs'), 'utf8')
    const connDoc = readFileSync(join(process.cwd(), 'docs', 'connector-integration.md'), 'utf8')
    const connTools = readFileSync(join(process.cwd(), 'packages', 'plugin-connector', 'src', 'tools.ts'), 'utf8')
    check('dshctl 用法文案无 precheckCents 残留（T6）', !dshctl.includes('precheckCents'))
    check('connector 集成文档无 precheckCents 示例（T6）', !connDoc.includes('precheckCents'))
    check('connector 工具描述无计费预检/precheckCents 残留（T6，防误导集成方）', !connTools.includes('计费预检') && !connTools.includes('precheckCents'))
  }
  section('behavior 事件管道（WP-03/D3：采集 / 鉴权 / 幂等）')
  {
    const anon = await api('POST', '/api/behavior/events', { body: { type: 'card.exposed' } })
    check('behavior 采集：未认证 401（write-only 门禁 fail-closed）', anon.status === 401, String(anon.status))
    const evt = await api('POST', '/api/behavior/events', { token: dev, body: { type: 'card.exposed', platform: 'rd', payload: { cardRef: 'c-001' }, idempotency_key: 'test-behavior-001' } })
    check('behavior 采集：登录用户上报成功（主体强制取认证身份）',
      evt.ok && evt.data.event?.idempotency_key === 'test-behavior-001' && evt.data.duplicated === false
      && String(evt.data.event?.subject ?? '').startsWith('user:') && evt.data.event?.schema === 'behavior.recorded',
      JSON.stringify(evt.error ?? evt.data))
    const evtDup = await api('POST', '/api/behavior/events', { token: dev, body: { type: 'card.exposed', platform: 'rd', payload: { cardRef: 'c-001' }, idempotency_key: 'test-behavior-001' } })
    check('behavior 采集：幂等重放返回既有事件 + duplicated 标记', evtDup.ok && evtDup.data.duplicated === true && evtDup.data.event?.event_id === evt.data.event?.event_id)
    const evtConflict = await api('POST', '/api/behavior/events', { token: dev, body: { type: 'card.clicked', idempotency_key: 'test-behavior-001' } })
    check('behavior 采集：同幂等键不同内容被拒', !evtConflict.ok)
    const evtBadType = await api('POST', '/api/behavior/events', { token: dev, body: { type: 'BAD TYPE' } })
    check('behavior 采集：type 点分小写键校验', !evtBadType.ok)
    const evtOversize = await api('POST', '/api/behavior/events', { token: dev, body: { type: 'card.exposed', payload: { blob: 'x'.repeat(5000) } } })
    check('behavior 采集：payload 超 4KB 被拒', !evtOversize.ok && JSON.stringify(evtOversize.error).includes('超限'))
    const devRead = await api('GET', '/api/behavior/events', { token: dev })
    check('behavior 只读：无 audit.read 被拒 403', devRead.status === 403, String(devRead.status))
    const adminRead = await api('GET', '/api/behavior/events?type=card.exposed', { token: admin })
    check('behavior 只读：audit.read 可查且幂等不双计（total=1）', adminRead.ok && adminRead.data.total === 1, JSON.stringify(adminRead.data))
  }
  section('五平台主题（WP-05/B3：仅 data-platform 属性差，定版色值在位）')
  {
    const themeCss = readFileSync(join(process.cwd(), 'packages', 'plugin-console', 'public', 'css', 'base.css'), 'utf8')
    check('主题：五平台仅 data-platform 属性差（五块覆盖 + 定版色值在位，无 Tailwind 引入）',
      [['strategy', '#3B4CC0'], ['marketing', '#E8590C'], ['manufacturing', '#0C8599'], ['rd', '#7048E8'], ['quality', '#2F9E44']]
        .every(([platform, hex]) => themeCss.includes(`data-platform="${platform}"`) && themeCss.includes(hex))
        && !themeCss.toLowerCase().includes('tailwind'),
      'base.css 平台主题块缺失或色值漂移')
  }
  section('rbac endpoint matrix（WP-04/A1：普通成员直调管理端点 100% 被拒，矩阵驱动）')
  {
    const matrix = await api('GET', '/api/platform/route-matrix', { token: admin })
    check('矩阵：服务端路由×权限矩阵可查询（端点覆盖面充足）',
      matrix.ok && matrix.data.guarded.length >= 100 && matrix.data.public.length >= 5,
      `guarded=${matrix.data?.guarded?.length} public=${matrix.data?.public?.length}`)
    // 普通成员：member 角色仅 console.login + skill.read + agent.read + app.read
    const roles = (await api('GET', '/api/iam/roles', { token: admin })).data.roles
    const memberRole = roles.find((role) => role.code === 'member')
    const memberInit = await api('POST', '/api/iam/users', { token: admin, body: { username: 'matrix_member', displayName: '矩阵探针', orgId: tenantOrg.data.id, roleIds: [memberRole.id] } })
    const memberInitPassword = memberInit.data?.initialPassword ?? 'Ybk@2026'
    const memberLogin = await api('POST', '/api/auth/login', { body: { username: 'matrix_member', password: memberInitPassword } })
    check('矩阵：普通成员账号就绪', memberLogin.ok, JSON.stringify(memberLogin.error))
    const member = memberLogin.data.token
    const memberPerms = memberLogin.data.user.permissions
    const denied = matrix.data.guarded.filter((route) => !route.permission.split(',').some((point) => memberPerms.includes(point)))
    let rejectedCount = 0
    const leaked = []
    for (const route of denied) {
      const probePath = route.path.replace(/:[a-zA-Z]+/g, 'selftest-probe')
      try {
        const probe = await api(route.method, probePath, { token: member, ...(route.method === 'GET' ? {} : { body: {} }) })
        if (probe.status === 403) rejectedCount++
        else leaked.push(`${route.method} ${route.path}(${route.permission}) → ${probe.status}`)
      } catch (error) {
        leaked.push(`${route.method} ${route.path} → 异常 ${error.message}`)
      }
    }
    check(`矩阵：${denied.length} 个越权探针 100% 被拒 403（端点清单变动即红）`,
      denied.length >= 50 && leaked.length === 0,
      leaked.length ? `泄漏端点：${leaked.slice(0, 5).join('；')}` : `denied=${denied.length} rejected=${rejectedCount}`)
    const expectedPublic = ['/api/auth/login', '/api/auth/refresh', '/api/health', '/api/authn/entry-tickets/redeem', '/api/auth/entry-ticket-session']
    check('矩阵：公开白名单零意外扩张（变动须经评审后同步本清单）',
      expectedPublic.every((path) => matrix.data.public.includes(path)),
      JSON.stringify(matrix.data.public))
    // H5（T-01 教训）：端点全量可枚举 + 公开自校验端点匿名探针 fail-closed——
    // /api/panel/stream 类自注册端点不再可能逃出断言网（注册期缺声明即抛错兜底）
    check('矩阵：/api/* 全量声明且三分类全覆盖（H5：register 缺声明注册期即抛）',
      matrix.data.counts.declaredApi === matrix.data.counts.guarded + matrix.data.counts.public + matrix.data.counts.authenticated
      && matrix.data.counts.undeclaredApi === 0,
      JSON.stringify(matrix.data.counts))
    const selfValidated = matrix.data.publicEntries.filter((entry) => entry.selfValidated)
    const anonLeaked = []
    for (const route of selfValidated) {
      const probePath = route.path.replace(/:[a-zA-Z]+/g, 'selftest-probe')
      try {
        const probe = await api(route.method, probePath, route.method === 'GET' ? {} : { body: {} })
        if (probe.status === 200 || probe.status === 500) anonLeaked.push(`${route.method} ${route.path} → ${probe.status}`)
      } catch (error) {
        anonLeaked.push(`${route.method} ${route.path} → 异常 ${error.message}`)
      }
    }
    check(`矩阵：${selfValidated.length} 个公开自校验端点匿名探针 100% fail-closed（H5）`,
      selfValidated.length >= 4 && anonLeaked.length === 0, anonLeaked.length ? anonLeaked.slice(0, 5).join('；') : '全部 401/403/400/404')
    const bareFetch = []
    const walkJs = (dir) => readdirSync(dir, { withFileTypes: true }).flatMap((entry) =>
      entry.isDirectory() ? walkJs(join(dir, entry.name)) : [join(dir, entry.name)])
    for (const file of walkJs(join(process.cwd(), 'packages', 'plugin-console', 'public'))) {
      if (!file.endsWith('.js')) continue
      if (file.replaceAll('\\', '/').endsWith('/js/api.js')) continue
      if (file.replaceAll('\\', '/').endsWith('/js/pages/oauth.js')) continue // 协议页豁免（注释在案）
      if (file.replaceAll('\\', '/').endsWith('/js/realtime.js')) continue // SSE/轮询运输层模块（api.js 同级豁免，注释在案）
      const text = readFileSync(file, 'utf8')
      if (/fetch\(|XMLHttpRequest|EventSource/.test(text)) bareFetch.push(file.split(/[\\/]/).pop())
    }
    check('走查不变量：console 前端除 api.js（与协议页豁免）外零裸 fetch/XHR/SSE',
      bareFetch.length === 0, JSON.stringify(bareFetch))
  }
  section('usage 最近调用（WP-04/A3：工作台自见 ≤5）')
  {
    const devUserId = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('dev'), { token: admin })).data.users.find((user) => user.username === 'dev').id
    await api('POST', '/api/usage/record', { token: admin, body: {
      org: tenantOrg.data.id, subject: `user:${devUserId}`, principal: `org:${tenantOrg.data.id}`,
      resource: 'mcp:real-backend', meters: [{ key: 'tokens', value: 1200, unit: 'token' }], idempotency_key: 'test-usage-recent-001',
    } })
    const recent = await api('GET', '/api/usage/recent?limit=5', { token: dev })
    check('最近调用：登录人自身计量事件自见（≤5 条，含展示名与计量明细）',
      recent.ok && recent.data.items.length >= 1 && recent.data.items.length <= 5
      && recent.data.items[0].resource === 'mcp:real-backend' && Boolean(recent.data.items[0].name) && Array.isArray(recent.data.items[0].meters),
      JSON.stringify(recent.error ?? recent.data))
    const recentAnon = await api('GET', '/api/usage/recent')
    check('最近调用：未认证被拒（401，服务端强制不靠菜单隐藏）', recentAnon.status === 401)
  }
  section('feedback 回传（WP-07/D1：👍👎 落零价快照 + 归因 + 幂等不重复计数）')
  {
    const fb = await api('POST', '/api/usage/feedback', { token: dev, body: { resource: 'agent:dev-coder', messageId: 'msg-drill-1', score: 'up', note: '很准' } })
    check('feedback：👍 落库为非计费零价快照（charge=0 + nonbillable）',
      fb.ok && fb.data.charge_cents === 0 && fb.data.nonbillable === true, JSON.stringify(fb.error ?? fb.data))
    const fbReplay = await api('POST', '/api/usage/feedback', { token: dev, body: { resource: 'agent:dev-coder', messageId: 'msg-drill-1', score: 'up' } })
    check('feedback：同键重放幂等（同一 event_id，不重复计数）', fbReplay.ok && fbReplay.data.event_id === fb.data.event_id)
    const devUserId = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('dev'), { token: admin })).data.users.find((user) => user.username === 'dev').id
    const fbOnBehalf = await rawReq('POST', '/api/usage/feedback', {
      headers: { 'content-type': 'application/json', authorization: `Bearer ${admin}`, 'x-on-behalf-user': devUserId },
      body: JSON.stringify({ resource: 'agent:dev-coder', messageId: 'msg-drill-2', score: 'down' }),
    })
    check('feedback：X-On-Behalf-User 归因到人（Agent 代用户回传）', fbOnBehalf.status === 200, String(fbOnBehalf.status))
    const agentEvents = await api('GET', '/api/usage/events?resource=' + encodeURIComponent('agent:dev-coder') + '&limit=50', { token: admin })
    const subjects = new Set(agentEvents.data.items.map((event) => event.subject))
    check('feedback：事件主体归因正确（dev 本人 + OBO 归因均在列）', subjects.has(`user:${devUserId}`), JSON.stringify([...subjects]))
    const fbBad = await api('POST', '/api/usage/feedback', { token: dev, body: { resource: 'agent:dev-coder', score: 'meh' } })
    check('feedback：非法评分被拒 400', fbBad.status === 400, String(fbBad.status))
  }
  section('错误文案映射完整性（WP-06/C3：枚举全部对外原因码，漏配即红）')
  {
    const errors = await import(new URL('../packages/plugin-console/public/js/errors.js', import.meta.url).href)
    const REQUIRED = ['nas-authz-deny', 'breaker-open', 'quota-exhausted', 'pdp-unreachable', 'degraded', 'binding-invalid', 'invoke-error']
    const missing = REQUIRED.filter((code) => !errors.ERROR_CODES.includes(code))
    check('文案：定版六条原因码 + 会话侧兜底码全部在册', missing.length === 0, `缺失：${missing.join(', ')}`)
    const blank = REQUIRED.filter((code) => {
      const copy = errors.errorCopy(code)
      return !copy.title || !copy.message || (copy.action ? !copy.action.label || !copy.action.href : false)
    })
    check('文案：每条原因码均有标题/正文/行动按钮（无空文案）', blank.length === 0, `空配：${blank.join(', ')}`)
    const bindingDetail = errors.errorCopy('binding-invalid', 'account_inactive')
    check('文案：绑定失效细分原因出可读补充（冻结/离职联动语义）',
      bindingDetail.message.includes('账号状态'), JSON.stringify(bindingDetail.message))
    const fallback = errors.errorCopy('no-such-code-xyz')
    check('文案：未知原因码回落通用兜底（永不裸奔技术错误）', fallback.title.includes('无法完成') || fallback.title.length > 0)
    check('文案：绑定细分原因码在册（no_cookie/expired/account_inactive）',
      ['no_cookie', 'expired', 'account_inactive'].every((reason) => errors.BINDING_REASONS.includes(reason)))
  }
  section('四态状态源映射（WP-06/C2：rq-card 纯函数，状态输入 → UI 态输出）')
  {
    const stateMod = await import(new URL('../packages/plugin-rq-card/src/client/state.ts', import.meta.url).href)
    const derive = stateMod.deriveExecutionState
    check('四态：调用中（invoke 发起中 → calling，骨架可取消）', derive({ invokePhase: 'calling', hasResult: false, resultIsError: false }).state === 'calling')
    check('四态：执行中（healthy + 无结果 → executing）', derive({ invokePhase: 'idle', hasResult: false, resultIsError: false, healthStatus: 'healthy' }).state === 'executing')
    check('四态：执行中 degraded 附「有点慢」（degraded:true 附加信息）', (() => {
      const result = derive({ invokePhase: 'idle', hasResult: false, resultIsError: false, healthStatus: 'degraded' })
      return result.state === 'executing' && result.degraded === true
    })())
    check('四态：已完成（调用返回 + 非 error → done，呈现 👍/👎）', derive({ invokePhase: 'idle', hasResult: true, resultIsError: false }).state === 'done')
    check('四态：异常阻断优先级（authzDenied > quotaExceeded > pdpUnreachable > breakerOpen > down）',
      derive({ invokePhase: 'idle', hasResult: true, resultIsError: false, authzDenied: true, quotaExceeded: true, breakerOpen: true, healthStatus: 'down' }).reason === 'nas-authz-deny'
      && derive({ invokePhase: 'idle', hasResult: false, resultIsError: false, quotaExceeded: true, breakerOpen: true, healthStatus: 'down' }).reason === 'quota-exhausted'
      && derive({ invokePhase: 'idle', hasResult: false, resultIsError: false, breakerOpen: true, healthStatus: 'down' }).reason === 'breaker-open'
      && derive({ invokePhase: 'idle', hasResult: false, resultIsError: false, healthStatus: 'down' }).reason === 'down')
    check('四态：阻断 fail-safe 优先于完成态（历史结果不误导当前可用性）',
      derive({ invokePhase: 'idle', hasResult: true, resultIsError: false, breakerOpen: true }).state === 'blocked')
    check('四态：工具报错兜底第七码 invoke-error（errors.js 文案在册）',
      derive({ invokePhase: 'idle', hasResult: true, resultIsError: true }).reason === 'invoke-error')
    check('四态：空闲基态（无结果无调用无健康 → idle）', derive({ invokePhase: 'idle', hasResult: false, resultIsError: false }).state === 'idle')
    // 随包自证单测（测试随包走，不欠账）
    const stateTest = spawn(process.execPath, ['packages/plugin-rq-card/src/client/state.test.mjs'], { stdio: 'pipe' })
    await new Promise((resolve) => stateTest.on('close', resolve))
    check('四态：rq-card 随包单测全绿（node --test）', stateTest.exitCode === 0, `exit=${stateTest.exitCode}`)
  }

  // ================================================================ 交接 F 清单 M 节：scenegraph 校验器口径对齐原文
  section('场景图谱校验器（F 清单 M 节：8 类价值标签 / tags 可空 / links 可选，既有包零改动兼容）')
  {
    const sg = await import(new URL('../packages/platform-core/src/scenegraph.ts', import.meta.url).href)
    const baseScene = (overrides = {}) => ({
      code: 'TST01-A-1-1', name: '测试场景', type: '主场景', s: 3, tags: ['降本'], pain: '痛点',
      tools: ['t'], models: ['m'], data: ['d'], talent: ['p'], ...overrides,
    })
    const packOf = (scene, extra = {}) => ({
      code: 'TST01', name: '测试行业', icon: '🧪', version: 'v1', chains: '测试链',
      activities: { mfg: [scene] }, ...extra,
    })
    const errorsOf = (pack) => sg.validateScenegraph(pack, 'm节自测')
    check('M：原文口径标签 增收/安全/环保 入白名单（8 类=原文 7 类+节能兼容保留）',
      errorsOf(packOf(baseScene({ tags: ['增收', '安全', '环保'] }))).length === 0
      && errorsOf(packOf(baseScene({ tags: ['节能'] }))).length === 0
      && sg.SCENE_TAGS.length === 8, JSON.stringify(sg.SCENE_TAGS))
    check('M：词表外标签仍被拒', errorsOf(packOf(baseScene({ tags: ['虚构标签'] }))).some((line) => line.includes('tags 非法')))
    check('M：tags 空数组放行（原文未标注场景如实装载，不造假标签）',
      errorsOf(packOf(baseScene({ tags: [] }))).length === 0)
    check('M：tags 缺位（非数组）仍被拒', errorsOf(packOf(baseScene({ tags: undefined }))).some((line) => line.includes('tags 非法')))
    check('M：links 可选字段零校验负担（带环节链的包零错误，既有包无需改动）',
      errorsOf(packOf(baseScene(), { links: [{ key: 'A', name: '铁前' }, { key: 'B', name: '炼铁' }] })).length === 0)
  }

  // ================================================================ 第 3 步：契约五面 / 事件源校验 / L0 市场

  // ================================================================ 第 3 步：契约五面 / 事件源校验 / L0 市场
  section('第 3 步：契约五面 / 事件源校验 / 代理 ctx / L0 市场')

  const sandbox = await api('POST', '/api/market/sandbox-check', { token: admin, body: {} })
  const sb = sandbox.data?.results ?? {}
  check('代理 ctx：自有命名空间事件放行', sb.emitOwnNamespace === 'ok')
  check('代理 ctx：平台事件被拦（前缀强制）', sb.emitPlatformViaProxy === 'blocked')
  check('总线：plugin 来源直发保留命名空间被拦', sb.directEmitReserved === 'blocked')
  check('总线：plugin 命名空间无来源被拦', sb.pluginEventWithoutSource === 'blocked')
  check('代理 ctx：未授权服务访问被拦（能力裁剪）', sb.serviceWithoutCapability === 'blocked')
  check('代理 ctx：授权能力内服务放行', sb.serviceWithCapability === 'ok')

  const { generateKeyPairSync, createHash, sign: edSign } = await import('node:crypto')
  const devKeys = generateKeyPairSync('ed25519')
  const devPub = devKeys.publicKey.export({ format: 'der', type: 'spki' }).toString('base64')
  const devReg = await api('POST', '/api/market/developers/register', { body: { username: 'acme-dev', displayName: '磁姆开发者', email: 'dev@acme.com', password: 'Acme@20260', publicKey: devPub, company: '磁姆科技', payoutAccount: '待登记（资金通道依赖清单）' } })
  check('开发者注册（Ed25519 发布者公钥）', devReg.ok && devReg.data.developer.username === 'acme-dev')
  const devPortalLogin = await api('POST', '/api/market/developers/login', { body: { username: 'acme-dev', password: 'Acme@20260' } })
  check('开发者登录（独立身份域）', devPortalLogin.ok && devPortalLogin.data.token.startsWith('dst1.'))
  const devToken2 = devPortalLogin.data.token
  const devBadLogin = await api('POST', '/api/market/developers/login', { body: { username: 'acme-dev', password: 'wrong-pass' } })
  check('开发者密码错误被拒', devBadLogin.status === 401)

  const pluginYaml = (opts = {}) => [
    `id: ${opts.id ?? 'com.acme.hello'}`,
    'version: 1.0.0',
    `publisher: ${opts.publisher ?? 'acme-dev'}`,
    'depends:',
    '  - dsh-plugin-platform-core: ^1.0',
    'capabilities_request:',
    '  - knowledgebase.read',
    `sandbox: ${opts.sandbox ?? 'L0'}`,
    'content:',
    '  prompts:',
    '    - name: hello',
    '      description: Hello World 提示词包',
    '      template: |',
    `        ${opts.template ?? '你是磁姆助手。请复述用户请求并给出结构化回答。'}`,
    '',
  ].join('\n')
  const buildFiles = (opts = {}) => ({
    'plugin.yaml': pluginYaml(opts),
    'manifest/permissions.yaml': 'requested:\n  - knowledgebase.read\n',
    'manifest/api.yaml': 'routes: []\n',
    'manifest/events.yaml': 'subscribes: []\nemits: []\n',
    'manifest/billing.yaml': 'model: free\nusage:\n  - key: prompts.used\n    unit: 次\n    price: 0\n',
  })
  const fpOf = (files) => createHash('sha256').update(Object.keys(files).sort().map((k) => `${k}\n${files[k] ?? ''}`).join('\n---\n')).digest('hex')
  const signed = (files) => edSign(null, Buffer.from(fpOf(files)), devKeys.privateKey).toString('base64')

  const files = buildFiles()
  const submitOk = await api('POST', '/api/market/submit', { token: devToken2, body: { files, signature: signed(files) } })
  check('契约五面提交（Ed25519 验签通过）', submitOk.ok && submitOk.data.status === 'pending_approval')

  const l1Files = buildFiles({ sandbox: 'L1' })
  const submitL1 = await api('POST', '/api/market/submit', { token: devToken2, body: { files: l1Files, signature: signed(l1Files) } })
  check('市场门禁：L1 有码插件被拒（第 10 步交付前仅受理 L0）', !submitL1.ok && JSON.stringify(submitL1.error).includes('L0'))
  const badSig = await api('POST', '/api/market/submit', { token: devToken2, body: { files, signature: Buffer.from('not-a-signature').toString('base64') } })
  check('签名验签失败被拒', !badSig.ok && JSON.stringify(badSig.error).includes('签名'))
  const evilFiles = buildFiles({ template: '执行 rm -rf / 清理磁盘' })
  const submitEvil = await api('POST', '/api/market/submit', { token: devToken2, body: { files: evilFiles, signature: signed(evilFiles) } })
  check('L0 内容扫描拦截破坏性内容', !submitEvil.ok && JSON.stringify(submitEvil.error).includes('扫描'))
  const hijackFiles = buildFiles({ publisher: 'someone-else' })
  const submitHijack = await api('POST', '/api/market/submit', { token: devToken2, body: { files: hijackFiles, signature: signed(hijackFiles) } })
  check('publisher 必须为提交者本人', !submitHijack.ok && JSON.stringify(submitHijack.error).includes('publisher'))

  const approvePlugin = await api('POST', `/api/market/submissions/${submitOk.data.id}/approve`, { token: admin, body: { opinion: '符合上架条件' } })
  check('审批上架', approvePlugin.ok && approvePlugin.data.status === 'listed')
  const installPlugin = await api('POST', '/api/market/plugins/com.acme.hello/install', { token: admin, body: { orgId: tenantOrg.data.id, tenantId: newTenant.data.id, approvedCapabilities: ['knowledgebase.read'] } })
  check('安装（权限确认 + 能力固化）', installPlugin.ok && installPlugin.data.status === 'running')
  const capExceed = await api('POST', '/api/market/plugins/com.acme.hello/install', { token: admin, body: { orgId: newOrg.data.id, approvedCapabilities: ['model-gateway.invoke'] } })
  check('越权能力安装被拒（approved ⊆ requested）', !capExceed.ok && JSON.stringify(capExceed.error).includes('请求清单'))
  const permExceed = await api('POST', '/api/market/plugins/com.acme.hello/install', { token: admin, body: { orgId: newOrg.data.id, approvedCapabilities: ['knowledgebase.read'], approvedPermissions: ['usage.admin'] } })
  check('越权权限安装被拒（QA E-02：approvedPermissions ⊆ requested）', !permExceed.ok && /申请清单/.test(permExceed.error?.message ?? ''), JSON.stringify(permExceed.error ?? {}))
  const permOkInstall = await api('POST', '/api/market/plugins/com.acme.hello/install', { token: admin, body: { orgId: newOrg.data.id, approvedCapabilities: ['knowledgebase.read'], approvedPermissions: ['knowledgebase.read'] } })
  check('权限范围内安装通过（QA E-02 正向）', permOkInstall.ok && permOkInstall.data.status === 'running', JSON.stringify(permOkInstall.error ?? {}))

  const prompts = await api('GET', '/api/market/prompts?orgId=' + tenantOrg.data.id, { token: admin })
  check('L0 运行时：提示词包可取用', prompts.ok && prompts.data.prompts.length >= 1 && prompts.data.prompts[0].template.includes('磁姆助手'))
  const usePrompt = await api('POST', '/api/market/prompts/use', { token: admin, body: { orgId: tenantOrg.data.id, pluginId: 'com.acme.hello', promptName: 'hello' } })
  check('L0 计量：提示词取用产生 usage 事件（L3）', usePrompt.ok)
  const pluginUsage = await api('GET', '/api/usage/events?principal=' + encodeURIComponent('plugin:com.acme.hello'), { token: admin })
  check('插件计量入账（meter key 来自 billing.yaml 声明，金额零价快照）', pluginUsage.ok && pluginUsage.data.total >= 1 && pluginUsage.data.items[0].pricing.charge_cents === 0 && pluginUsage.data.items[0].pricing.rate?.nonbillable === true && pluginUsage.data.items[0].tenant_id === newTenant.data.id)

  // app 复合验收（F5 修正：以覆盖面而非复杂度为由）
  const seededApps = (await api('GET', '/api/apps', { token: admin })).data.apps
  const anyApp = seededApps[0]
  const compoundAppDetail = await api('GET', `/api/apps/${anyApp.id}`, { token: admin })
  const chainTotals = await api('GET', '/api/usage/totals', { token: admin })
  check('app 复合验收：拓扑 + 成本穿透 + 计量管道三链齐备', compoundAppDetail.ok && compoundAppDetail.data.topology.children.length >= 1 && compoundAppDetail.data.cost.length >= 1 && chainTotals.ok && chainTotals.data.count >= 2, JSON.stringify({ app: compoundAppDetail.ok ? { topo: compoundAppDetail.data.topology.children.length, cost: compoundAppDetail.data.cost.length } : compoundAppDetail, totals: chainTotals }))

  // 应用指标主动上报（接入方 → 宿主的推送通道：REST / 工具 / CLI 同一契约）
  const reportDate = new Date(Date.now() - 5 * 86_400_000).toISOString().slice(0, 10)
  const sessionsBefore = (await api('GET', `/api/apps/${anyApp.id}`, { token: admin })).data.metrics.sessions
  const appReport = await api('POST', `/api/apps/${anyApp.id}/metrics-report`, { token: admin, body: { dau: 777, sessions: 1234, avgDepth: 3.5, retention7: 0.42 } })
  check('应用指标上报端点写入成功（DAU/留存即生效）', appReport.ok && appReport.data.dau >= 777 && appReport.data.retention7 === 0.42)
  const appReportBackfill = await api('POST', `/api/apps/${anyApp.id}/metrics-report`, { token: admin, body: { date: reportDate, dau: 100, sessions: 200 } })
  check('应用指标可指定日期补录历史（同日已有记录则会话累加）', appReportBackfill.ok && appReportBackfill.data.sessions === sessionsBefore + 1234 + 200 && appReportBackfill.data.series.some((row) => row.date === reportDate))
  const appReportBadDate = await api('POST', `/api/apps/${anyApp.id}/metrics-report`, { token: admin, body: { date: '2026/07/01', dau: 1 } })
  check('应用指标日期格式非法被拒（400）', appReportBadDate.status === 400)
  const appReportGhost = await api('POST', '/api/apps/app_ghost/metrics-report', { token: admin, body: { dau: 1 } })
  check('不存在应用上报被拒（400）', appReportGhost.status === 400)
  const appReportDenied = await api('POST', `/api/apps/${anyApp.id}/metrics-report`, { token: auditor, body: { dau: 1 } })
  check('无 app.write 上报应用指标被拒（403）', appReportDenied.status === 403)
  const appReportTool = await api('POST', '/api/tools/execute', { token: admin, body: { name: 'app_metrics_report', args: { appId: anyApp.id, dau: 888 } } })
  check('工具 app_metrics_report 上报（同日 DAU 取最大）', appReportTool.ok && appReportTool.data.isError === false && appReportTool.data.value.reported === true && appReportTool.data.value.metrics.dau === 888)
  const appReportPv = await api('POST', `/api/apps/${anyApp.id}/metrics-report`, { token: admin, body: { pv: 500, uv: 260, dau: 800 } })
  check('PV/UV 口径上报（首日写入）', appReportPv.ok && appReportPv.data.pv === 500 && appReportPv.data.uv === 260 && appReportPv.data.dau === 888)
  const appReportPv2 = await api('POST', `/api/apps/${anyApp.id}/metrics-report`, { token: admin, body: { pv: 120, uv: 300 } })
  check('PV 同日累加 / UV 同日取最大（DAU 800 不覆盖 888）', appReportPv2.ok && appReportPv2.data.pv === 620 && appReportPv2.data.uv === 300 && appReportPv2.data.dau === 888)

  // 平台侧指标自动折算（指标口径补全）：浏览器 beacon → PV/UV；entry-ticket 兑换 / OIDC 发码 → DAU
  section('平台侧指标自动折算（beacon PV/UV + SSO 到访 DAU）')
  const autoAppCreate = await api('POST', '/api/apps', { token: admin, body: { name: '指标自动折算验收', attrs: { description: 'beacon PV/UV 与 SSO DAU 自动折算验收', appType: 'web', riskLevel: 'low', dataClass: 'internal' } } })
  check('折算验收应用创建', autoAppCreate.ok && Boolean(autoAppCreate.data?.app?.id), JSON.stringify(autoAppCreate.error))
  const autoAppId = autoAppCreate.data.app.id
  const autoMetrics = async () => (await api('GET', `/api/apps/${autoAppId}`, { token: admin })).data.metrics
  const vidA = 'selftest-vid-aaaa-0903'
  const vidB = 'selftest-vid-bbbb-0903'
  const beaconGif = await rawReq('GET', `/api/apps/beacon?app=${autoAppId}&vid=${vidA}`)
  check('beacon GET 免鉴权：200 + 1x1 GIF + no-store', beaconGif.status === 200 && beaconGif.headers['content-type'].includes('image/gif') && String(beaconGif.headers['cache-control']).includes('no-store') && beaconGif.body.startsWith('GIF8'), JSON.stringify({ status: beaconGif.status, ct: beaconGif.headers['content-type'] }))
  await rawReq('GET', `/api/apps/beacon?app=${autoAppId}&vid=${vidA}`)
  await rawReq('GET', `/api/apps/beacon?app=${autoAppId}&vid=${vidB}`)
  await rawReq('POST', '/api/apps/beacon', { headers: { 'content-type': 'application/json' }, body: JSON.stringify({ app: autoAppId, vid: vidA }) })
  const beaconMetrics = await autoMetrics()
  check('beacon PV 逐次累加 / UV 按 vid 去重（4 次上报 → pv=4 uv=2 dau=0）', beaconMetrics.pv === 4 && beaconMetrics.uv === 2 && beaconMetrics.dau === 0, JSON.stringify(beaconMetrics))
  const ghostBeacon = await rawReq('GET', '/api/apps/beacon?app=app_ghost&vid=selftest-vid-cccc-0903')
  check('未知应用 beacon 恒 200 GIF（不泄露应用存在性）', ghostBeacon.status === 200 && ghostBeacon.body === beaconGif.body && ghostBeacon.headers['content-type'] === beaconGif.headers['content-type'])
  const autoTicket = await api('POST', `/api/apps/${autoAppId}/entry-ticket`, { token: admin, body: {} })
  const autoRedeem = await rawReq('POST', '/api/authn/entry-tickets/redeem', { headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ticket: autoTicket.data.ticket }) })
  check('entry-ticket 兑换 200（公开端点）', autoRedeem.status === 200)
  const afterTicket = await autoMetrics()
  check('entry-ticket 兑换自动折算 DAU（admin 新访客 → dau=1 uv=3）', afterTicket.dau === 1 && afterTicket.uv === 3 && afterTicket.pv === 4, JSON.stringify(afterTicket))
  const autoSso = await api('POST', `/api/apps/${autoAppId}/sso-client`, { token: admin, body: { redirectUris: ['https://auto-check.example/cb'], consentRequired: false } })
  check('折算验收应用自助签发 SSO 客户端', autoSso.ok && autoSso.data.clientId.startsWith('oc-'), JSON.stringify(autoSso.error))
  const autoVerifier = 'selftest-auto-pkce-verifier-43-chars-aaaaaaaaaa'
  const autoFirst = await rawReq('GET', `/oauth/authorize?${new URLSearchParams({ response_type: 'code', client_id: autoSso.data.clientId, redirect_uri: 'https://auto-check.example/cb', state: 'st-auto', scope: 'openid profile', code_challenge: createHash('sha256').update(autoVerifier).digest('base64url'), code_challenge_method: 'S256' }).toString()}`)
  const autoReqId = new URLSearchParams(String(autoFirst.headers.location).split('?')[1] ?? '').get('req')
  const autoApprove = await authorizeConfirm(auditor, autoReqId, true)
  check('OIDC 授权确认发码（auditor human）', autoApprove.status === 200 && String(autoApprove.result.location).includes('code='), JSON.stringify(autoApprove.result))
  const afterOidc = await autoMetrics()
  check('OIDC 发码自动折算 DAU（auditor 新访客 → dau=2 uv=4）', afterOidc.dau === 2 && afterOidc.uv === 4, JSON.stringify(afterOidc))

  // dshctl plugin init 脚手架（真实生成文件）
  const { execFile } = await import('node:child_process')
  const scaffoldDir = join(DATA_DIR, 'scaffold-plugin')
  await new Promise((resolve) => execFile(process.execPath, ['cli/dshctl.mjs', 'plugin', 'init', '--id=com.selftest.scaffold', `--dir=${scaffoldDir}`], { cwd: process.cwd() }, (error) => { void error; resolve() }))
  const { existsSync: existsFile, readFileSync: scaffoldRead } = await import('node:fs')
  const SCAFFOLD_FILES = ['plugin.yaml', 'manifest/permissions.yaml', 'manifest/api.yaml', 'manifest/events.yaml', 'manifest/billing.yaml']
  check('dshctl plugin init 脚手架五面生成', SCAFFOLD_FILES.every((f) => existsFile(join(scaffoldDir, f))))
  const scaffoldYaml = existsFile(join(scaffoldDir, 'plugin.yaml')) ? scaffoldRead(join(scaffoldDir, 'plugin.yaml'), 'utf8') : ''
  check('脚手架默认 L0 + Hello World + 发布者密钥对', scaffoldYaml.includes('sandbox: L0') && scaffoldYaml.includes('hello') && existsFile(join(scaffoldDir, 'publisher-private-key.pem')))

  // ================================================================ 第 5 步：模型接入网关（M0-3 用量透明计量）
  section('第 5 步：模型接入网关（真实转发 / 零价快照计量 / 内部成本参考）')

  // OpenAI 兼容真实 stub
  const modelStub = createServer(async (req, res) => {
    if (req.url.endsWith('/chat/completions')) {
      await readBody(req)
      res.writeHead(200, { 'content-type': 'application/json' })
      res.end(JSON.stringify({
        choices: [{ message: { role: 'assistant', content: '你好，这是来自真实模型 stub 的回答。' } }],
        usage: { prompt_tokens: 120, completion_tokens: 1500 },
      }))
      return
    }
    res.writeHead(404).end('{}')
  })
  await new Promise((resolve) => modelStub.listen(0, '127.0.0.1', resolve))
  const modelPort = modelStub.address().port

  const noEndpointModel = await api('POST', '/api/modelgw/models', { token: admin, body: { slug: 'ghost-model', endpoint: '' } })
  const ghostInvoke = await api('POST', '/api/modelgw/invoke', { token: admin, body: { model: 'ghost-model', messages: [{ role: 'user', content: 'hi' }], orgId: tenantOrg.data.id } })
  check('未配置 endpoint 的模型拒绝调用（不生成假 completion）', noEndpointModel.ok && !ghostInvoke.ok && JSON.stringify(ghostInvoke.error).includes('endpoint'))

  const modelReg = await api('POST', '/api/modelgw/models', { token: admin, body: { slug: 'ds-stub', displayName: 'DeepSeek（stub 验证）', provider: 'deepseek', endpoint: `http://127.0.0.1:${modelPort}/v1`, apiKey: 'stub-key', costCentsPerKTokens: 5 } })
  check('模型目录登记（价格簿自动登记：零价 + 内部成本参考）', modelReg.ok)

  const modelInvoke = await api('POST', '/api/modelgw/invoke', { token: admin, body: { model: 'ds-stub', messages: [{ role: 'user', content: '真实链路测试' }], orgId: tenantOrg.data.id } })
  check('模型调用真实往返 + 实测 tokens 计量', modelInvoke.ok && modelInvoke.data.content.includes('真实模型') && modelInvoke.data.inputTokens === 120 && modelInvoke.data.outputTokens === 1500)
  check('内部成本参考折算（1500 tokens × 5分/千 = 8 分；charge 恒 0）', modelInvoke.ok && modelInvoke.data.costCents === 8, JSON.stringify(modelInvoke))

  const modelUsageEvents = await api('GET', '/api/usage/events?resource=model:ds-stub', { token: admin })
  check('模型计量事件含 input/output meters + 租户维度', modelUsageEvents.ok && modelUsageEvents.data.total >= 1 && modelUsageEvents.data.items[0].meters.length === 2 && modelUsageEvents.data.items[0].tenant_id === newTenant.data.id)

  // M0-3 口径：模型网关事件为零价快照（charge=0），无余额/预算闸
  const modelGwEvent = await api('GET', '/api/usage/events?resource=model:ds-stub', { token: admin })
  check('模型网关事件零价快照（charge=0 / cost=8）', modelGwEvent.ok && modelGwEvent.data.items[0].pricing.charge_cents === 0 && modelGwEvent.data.items[0].pricing.cost_cents === 8, JSON.stringify(modelGwEvent.data?.items?.[0]?.pricing))
  const billingRechargeGone = await api('POST', '/api/billing/recharge', { token: admin, body: {} })
  check('充值端点已随 M0-2 下线（404）', billingRechargeGone.status === 404)
  modelStub.close()

  // ================================================================ 第 6 步：OIDC Provider（浏览器授权流 / 协议合规）
  section('第 6 步：OIDC Provider（浏览器授权流 / RS256 / 协议合规）')
  const discovery = await rawReq('GET', '/.well-known/openid-configuration')
  const disco = jsonBody(discovery)
  check('OIDC 发现文档暴露（jwks_uri / 端点 / RS256）', discovery.status === 200 && disco.jwks_uri.includes('/.well-known/jwks.json') && disco.id_token_signing_alg_values_supported.includes('RS256'))
  check('发现文档协议面（email scope / Basic+Post 双认证 / refresh+revoke+end_session）',
    disco.scopes_supported.includes('email')
    && disco.token_endpoint_auth_methods_supported.includes('client_secret_basic')
    && disco.token_endpoint_auth_methods_supported.includes('client_secret_post')
    && disco.grant_types_supported.includes('refresh_token')
    && Boolean(disco.revocation_endpoint) && Boolean(disco.end_session_endpoint))
  const jwks = jsonBody(await rawReq('GET', '/.well-known/jwks.json'))
  check('JWKS 数组化公钥（kid/kty/n）', Array.isArray(jwks.keys) && jwks.keys[0].kty === 'RSA' && jwks.keys[0].kid.length === 16 && Boolean(jwks.keys[0].n))

  const oidcClient = await api('POST', '/api/authn/oidc/clients', { token: admin, body: { name: '外部 CRM 应用', redirectUris: ['https://crm.partner.example/cb'], consentRequired: false } })
  check('登记 OIDC 客户端（secret 一次性返回）', oidcClient.ok && oidcClient.data.clientId.startsWith('oc-') && oidcClient.data.clientSecret.startsWith('ocs'))
  const OC = oidcClient.data

  // -- CORS：纯前端（public + PKCE）客户端跨域直调协议端点（允许来源 = 已登记 redirect_uri origin）--
  const corsHit = await rawReq('GET', '/.well-known/openid-configuration', { headers: { origin: 'https://crm.partner.example' } })
  check('discovery 携带 CORS 放行头（origin 命中已登记 redirect_uri）', corsHit.headers['access-control-allow-origin'] === 'https://crm.partner.example' && String(corsHit.headers.vary).includes('Origin'))
  const corsPreflight = await rawReq('OPTIONS', '/oauth/token', { headers: { origin: 'https://crm.partner.example', 'access-control-request-method': 'POST' } })
  check('OPTIONS 预检 → 204 + allow-methods/headers/max-age', corsPreflight.status === 204 && corsPreflight.headers['access-control-allow-origin'] === 'https://crm.partner.example' && String(corsPreflight.headers['access-control-allow-headers']).includes('authorization') && String(corsPreflight.headers['access-control-allow-headers']).includes('content-type'))
  const corsMiss = await rawReq('GET', '/.well-known/openid-configuration', { headers: { origin: 'https://evil.example' } })
  check('未登记来源不发放 allow-origin（仅 vary）', corsMiss.headers['access-control-allow-origin'] === undefined && String(corsMiss.headers.vary).includes('Origin'))
  const corsErrPath = await rawReq('POST', '/oauth/token', { headers: { 'content-type': 'application/x-www-form-urlencoded', origin: 'https://crm.partner.example' }, body: 'grant_type=authorization_code&code=forged' })
  check('错误响应（invalid_client）同样携带放行头（浏览器可读错误体）', corsErrPath.status === 401 && jsonBody(corsErrPath).error === 'invalid_client' && corsErrPath.headers['access-control-allow-origin'] === 'https://crm.partner.example')

  // -- 第一跳校验：任一失败 → 302 平台错误页（绝不携带外部 redirect_uri，防开放重定向）--
  const pkceVerifier = 'selftest-pkce-verifier-43-chars-aaaaaaaaaaaaaa'
  const pkceChallenge = createHash('sha256').update(pkceVerifier).digest('base64url')
  const authorizeQuery = (over = {}) => new URLSearchParams({
    response_type: 'code', client_id: OC.clientId, redirect_uri: 'https://crm.partner.example/cb',
    state: 'st-selftest', scope: 'openid profile email', code_challenge: pkceChallenge, code_challenge_method: 'S256', ...over,
  }).toString()
  const reqIdOf = (raw) => new URLSearchParams(String(raw.headers.location).split('?')[1] ?? '').get('req')

  const badClient = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ client_id: 'oc-forged' })}`)
  check('无效 client_id → 302 平台错误页（Location 不含外部域）', badClient.status === 302 && String(badClient.headers.location).startsWith('/#/oauth/error') && !String(badClient.headers.location).includes('crm.partner.example'))
  const badRedirect = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ redirect_uri: 'https://evil.example/cb' })}`)
  check('redirect_uri 不在白名单 → 平台错误页', badRedirect.status === 302 && String(badRedirect.headers.location).startsWith('/#/oauth/error'))
  const badScope = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ scope: 'openid profile reporting:admin' })}`)
  check('白名单外 scope → invalid_scope 错误页', badScope.status === 302 && decodeURIComponent(String(badScope.headers.location)).includes('invalid_scope'))
  const noPkce = await rawReq('GET', `/oauth/authorize?${new URLSearchParams({ response_type: 'code', client_id: OC.clientId, redirect_uri: 'https://crm.partner.example/cb', state: 'st', scope: 'openid' }).toString()}`)
  check('缺少 PKCE → 错误页（强制 S256）', noPkce.status === 302 && String(noPkce.headers.location).startsWith('/#/oauth/error') && decodeURIComponent(String(noPkce.headers.location)).includes('PKCE'))
  const badResponseType = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ response_type: 'token' })}`)
  check('response_type=token → unsupported_response_type 错误页', badResponseType.status === 302 && decodeURIComponent(String(badResponseType.headers.location)).includes('unsupported_response_type'))

  // -- 合法第一跳：302 平台授权页 + 公开查询不泄露 redirect_uri --
  const goodFirst = await rawReq('GET', `/oauth/authorize?${authorizeQuery()}`)
  check('合法授权请求 → 302 平台授权页（/#/oauth/authorize?req=）', goodFirst.status === 302 && String(goodFirst.headers.location).startsWith('/#/oauth/authorize?req='))
  const reqId = reqIdOf(goodFirst)
  const reqInfo = await authReqInfo(reqId)
  check('授权请求公开查询（客户端名/scope，不泄露 redirect_uri）', reqInfo.status === 200 && reqInfo.info.clientName === '外部 CRM 应用' && reqInfo.info.scope.includes('openid') && !JSON.stringify(reqInfo.info).includes('redirect_uri'))

  // -- 授权确认：机器 403 / human 通过 / 重放、伪造、过期 400 --
  const machineAuthorize = await api('POST', '/api/authn/oidc/authorize', { token: machine, body: { reqId } })
  check('机器身份确认授权被拒（human-only）', machineAuthorize.status === 403)
  const authApprove = await authorizeConfirm(admin, reqId, true)
  check('用户确认授权 → 回跳地址（code/state 原样透传 + iss 防 mix-up）', authApprove.status === 200 && authApprove.result.location.includes('code=') && authApprove.result.location.includes('state=st-selftest') && authApprove.result.location.includes('iss='))
  const replayReq = await authorizeConfirm(admin, reqId, true)
  check('授权请求重放被拒（单次消费）', replayReq.status === 400)
  const forgedReq = await authorizeConfirm(admin, 'forged-req-id')
  check('伪造 reqId 被拒', forgedReq.status === 400)
  const expFirst = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'st-expired' })}`)
  const expReqId = reqIdOf(expFirst)
  await new Promise((resolve) => setTimeout(resolve, 2500))
  const expApprove = await authorizeConfirm(admin, expReqId, true)
  check('过期授权请求被拒（TTL 语义）', expApprove.status === 400)

  // -- consent 门禁：未同意 400 / 显式拒绝 access_denied 回跳 / 同意放行 --
  const consentClient = await api('POST', '/api/authn/oidc/clients', { token: admin, body: { name: '需同意的外部门户', redirectUris: ['https://portal.partner.example/cb'], consentRequired: true } })
  check('登记需显式同意的客户端', consentClient.ok)
  const ccFirst = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ client_id: consentClient.data.clientId, redirect_uri: 'https://portal.partner.example/cb', state: 'st-consent' })}`)
  const ccReqId = reqIdOf(ccFirst)
  const ccInfo = await authReqInfo(ccReqId)
  check('consentRequired 状态公开回显', ccInfo.status === 200 && ccInfo.info.consentRequired === true)
  const ccNo = await authorizeConfirm(admin, ccReqId, undefined)
  check('未表达同意 → 400', ccNo.status === 400)
  const ccDeny = await authorizeConfirm(admin, ccReqId, false)
  check('显式拒绝 → access_denied 回跳（拒绝事件留痕）', ccDeny.status === 200 && ccDeny.result.location.includes('error=access_denied'))
  const ccFirst2 = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ client_id: consentClient.data.clientId, redirect_uri: 'https://portal.partner.example/cb', state: 'st-consent2' })}`)
  const ccOk = await authorizeConfirm(admin, reqIdOf(ccFirst2), true)
  check('勾选同意后放行（签发 code）', ccOk.status === 200 && ccOk.result.location.includes('code='))

  // -- 换牌：Basic/Post 双认证 × form/JSON 双编码、PKCE 正误、code 重放、错误码状态码 --
  const basicAuth = Buffer.from(`${OC.clientId}:${OC.clientSecret}`).toString('base64')
  const tokenForm = (extra = {}) => new URLSearchParams({
    grant_type: 'authorization_code', client_id: OC.clientId, client_secret: OC.clientSecret,
    redirect_uri: 'https://crm.partner.example/cb', code_verifier: pkceVerifier, ...extra,
  }).toString()
  const code1 = new URL(authApprove.result.location).searchParams.get('code')
  const tPost = await rawReq('POST', '/oauth/token', { headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: tokenForm({ code: code1 }) })
  const ts1 = jsonBody(tPost)
  check('code 换令牌（client_secret_post + form 编码）', tPost.status === 200 && ts1.access_token?.split('.').length === 3 && ts1.token_type === 'Bearer')
  check('响应契约（scope 字段 + confidential 客户端附带 refresh_token）', ts1.scope === 'openid profile email' && ts1.refresh_token?.startsWith('otr_'))
  const oidcCodeReplay = await rawReq('POST', '/oauth/token', { headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: tokenForm({ code: code1 }) })
  check('授权码重放被拒（单次消费 → 400 invalid_grant）', oidcCodeReplay.status === 400 && jsonBody(oidcCodeReplay).error === 'invalid_grant')

  const first2 = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'st-basic' })}`)
  const approve2 = await authorizeConfirm(admin, reqIdOf(first2), true)
  const oidcCode2 = new URL(approve2.result.location).searchParams.get('code')
  const tBasic = await rawReq('POST', '/oauth/token', {
    headers: { 'content-type': 'application/x-www-form-urlencoded', authorization: `Basic ${basicAuth}` },
    body: new URLSearchParams({ grant_type: 'authorization_code', code: oidcCode2, redirect_uri: 'https://crm.partner.example/cb', code_verifier: pkceVerifier }).toString(),
  })
  check('code 换令牌（client_secret_basic + Basic 头认证）', tBasic.status === 200 && jsonBody(tBasic).access_token?.split('.').length === 3)
  const first3 = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'st-json' })}`)
  const approve3 = await authorizeConfirm(admin, reqIdOf(first3), true)
  const tJson = await rawReq('POST', '/oauth/token', {
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ grant_type: 'authorization_code', code: new URL(approve3.result.location).searchParams.get('code'), client_id: OC.clientId, client_secret: OC.clientSecret, redirect_uri: 'https://crm.partner.example/cb', code_verifier: pkceVerifier }),
  })
  check('code 换令牌（JSON 编码 + Post 认证）', tJson.status === 200 && jsonBody(tJson).access_token?.split('.').length === 3)

  const first4 = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'st-badverifier' })}`)
  const approve4 = await authorizeConfirm(admin, reqIdOf(first4), true)
  const tBadVerifier = await rawReq('POST', '/oauth/token', {
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: tokenForm({ code: new URL(approve4.result.location).searchParams.get('code'), code_verifier: 'wrong-verifier-wrong-verifier-wrong-verifier-wrong' }),
  })
  check('PKCE verifier 错误 → 400 invalid_grant', tBadVerifier.status === 400 && jsonBody(tBadVerifier).error === 'invalid_grant')
  const first5 = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'st-noverifier' })}`)
  const approve5 = await authorizeConfirm(admin, reqIdOf(first5), true)
  const tNoVerifier = await rawReq('POST', '/oauth/token', {
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'authorization_code', client_id: OC.clientId, client_secret: OC.clientSecret, code: new URL(approve5.result.location).searchParams.get('code') }).toString(),
  })
  check('PKCE 缺少 code_verifier → 400', tNoVerifier.status === 400 && JSON.stringify(tNoVerifier.body).includes('code_verifier'))
  const tBadSecret = await rawReq('POST', '/oauth/token', {
    headers: { 'content-type': 'application/x-www-form-urlencoded', authorization: `Basic ${Buffer.from(`${OC.clientId}:wrong-secret`).toString('base64')}` },
    body: new URLSearchParams({ grant_type: 'authorization_code', code: 'whatever' }).toString(),
  })
  check('client_secret 错误 → 401 + WWW-Authenticate: Basic', tBadSecret.status === 401 && jsonBody(tBadSecret).error === 'invalid_client' && String(tBadSecret.headers['www-authenticate'] ?? '').includes('Basic'))

  // -- token 类型区分 + JWKS 本地验签 + userinfo --
  const [jwtH, jwtP, jwtS] = ts1.access_token.split('.')
  const jwtClaims = JSON.parse(Buffer.from(jwtP, 'base64url').toString('utf8'))
  const jwtHeader = JSON.parse(Buffer.from(jwtH, 'base64url').toString('utf8'))
  const idClaims = JSON.parse(Buffer.from(ts1.id_token.split('.')[1], 'base64url').toString('utf8'))
  check('token 类型打标（access/id 区分 + kid 头）', jwtClaims.token_use === 'access' && idClaims.token_use === 'id' && jwtHeader.kid === jwks.keys[0].kid && jwtClaims.aud === OC.clientId && idClaims.nonce === undefined)
  const { createPublicKey: cpk, verify: rsVerify } = await import('node:crypto')
  const jwkKey = cpk({ key: { kty: jwks.keys[0].kty, n: jwks.keys[0].n, e: jwks.keys[0].e }, format: 'jwk' })
  check('外部应用以 JWKS 公钥本地验签通过', rsVerify('RSA-SHA256', Buffer.from(`${jwtH}.${jwtP}`), jwkKey, Buffer.from(jwtS, 'base64url')) === true && jwtClaims.iss.includes('127.0.0.1'))

  const userInfo = await rawReq('GET', '/oauth/userinfo', { headers: { authorization: `Bearer ${ts1.access_token}` } })
  const ui = jsonBody(userInfo)
  check('userinfo 返回 NormalizedProfile（org/角色/租户）', userInfo.status === 200 && ui.sub === adminLogin.data.user.id && ui.org !== null && Array.isArray(ui.roles) && ui.roles.includes('super_admin'))
  const idAsAccess = await rawReq('GET', '/oauth/userinfo', { headers: { authorization: `Bearer ${ts1.id_token}` } })
  check('id_token 调 userinfo 被拒（token_use 收敛）', idAsAccess.status === 401)
  const noBearer = await rawReq('GET', '/oauth/userinfo')
  check('userinfo 无凭证 → 401 + WWW-Authenticate: Bearer', noBearer.status === 401 && String(noBearer.headers['www-authenticate'] ?? '').includes('Bearer'))

  // -- SPA 静态页（授权页/错误页由前端路由承载）--
  const spaIndex = await rawReq('GET', '/')
  check('SPA 静态页可达（#/oauth/* 前端路由承载）', spaIndex.status === 200 && spaIndex.body.includes('id="app"'))

  // -- openid-client 冒烟（标准 SDK 一行 discovery 驱动：authorize → token → userinfo）--
  const oc = await import('openid-client')
  const ocConfig = await oc.discovery(new URL(BASE), OC.clientId, undefined, new oc.ClientSecretBasic(OC.clientSecret), { execute: [oc.allowInsecureRequests] })
  const ocVerifier = oc.randomPKCECodeVerifier()
  const ocChallenge = await oc.calculatePKCECodeChallenge(ocVerifier)
  const ocState = oc.randomState()
  const ocNonce = oc.randomNonce()
  const ocRedirectTo = oc.buildAuthorizationUrl(ocConfig, {
    redirect_uri: 'https://crm.partner.example/cb', scope: 'openid profile email',
    state: ocState, nonce: ocNonce, code_challenge: ocChallenge, code_challenge_method: 'S256',
  })
  const ocFirst = await rawReq('GET', ocRedirectTo.pathname + ocRedirectTo.search)
  check('openid-client：授权地址 302 平台授权页', ocFirst.status === 302 && String(ocFirst.headers.location).startsWith('/#/oauth/authorize?req='))
  const ocApprove = await authorizeConfirm(admin, reqIdOf(ocFirst), true)
  const ocTokens = await oc.authorizationCodeGrant(ocConfig, new URL(ocApprove.result.location), { pkceCodeVerifier: ocVerifier, expectedState: ocState, expectedNonce: ocNonce })
  check('openid-client：授权码换令牌（Basic 认证 + PKCE + id_token 验签全过）', typeof ocTokens.access_token === 'string' && typeof ocTokens.id_token === 'string')
  const ocUser = await oc.fetchUserInfo(ocConfig, ocTokens.access_token, ocTokens.claims().sub)
  check('openid-client：userinfo 取回身份（一行 SDK 式接入闭环）', ocUser.sub === adminLogin.data.user.id && ocUser.org !== null && ocUser.roles.includes('super_admin'))

  // 冻结联动：OIDC 令牌即时失效（无需等过期）
  const frozenAuth = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'st-frozen' })}`)
  const frozenApprove = await authorizeConfirm(dev, reqIdOf(frozenAuth), true)
  const frozenTokens = jsonBody(await rawReq('POST', '/oauth/token', {
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: tokenForm({ code: new URL(frozenApprove.result.location).searchParams.get('code') }),
  }))
  const devUserFull = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('陈默'), { token: admin })).data.users[0]
  await api('POST', `/api/iam/users/${devUserFull.id}/freeze`, { token: admin, body: { reason: '第 6 步：验证 OIDC 离职/冻结联动' } })
  const frozenInfo = await rawReq('GET', '/oauth/userinfo', { headers: { authorization: `Bearer ${frozenTokens.access_token}` } })
  check('账号冻结 → OIDC 令牌即时失效（卖点闭环）', frozenInfo.status === 401)
  // 解冻并重登：后续 MCP/Skill 段仍需 dev 令牌（冻结已即时吊销旧令牌）
  await api('POST', `/api/iam/users/${devUserFull.id}/unfreeze`, { token: admin })
  const devRelogin = await api('POST', '/api/auth/login', { body: { username: 'dev', password: 'Ybk@2026' } })
  dev = devRelogin.data.token

  // ================================================================ 第 7 步：L0 市场 beta（自营供给 + 零价计量）
  section('第 7 步：L0 市场 beta（自营供给 / 零价计量 / 卸载联动）')
  const marketList = await api('GET', '/api/market/plugins', { token: admin })
  check('自营首批供给上架（3 个标杆 L0）', marketList.ok && marketList.data.plugins.filter((p) => p.pluginId.startsWith('com.platform.')).length === 3, JSON.stringify(marketList).slice(0, 400))
  const officialInstall = await api('POST', '/api/market/plugins/com.platform.contract-review/install', { token: admin, body: { orgId: newOrg.data.id, approvedCapabilities: ['knowledgebase.read'] } })
  check('安装自营插件', officialInstall.ok && officialInstall.data.status === 'running')
  const meteringView = (await api('GET', '/api/market/plugins', { token: admin })).data.plugins.find((p) => p.pluginId === 'com.platform.contract-review')
  check('市场计量口径（仅 meter key/单位，零价无金额）', Boolean(meteringView) && meteringView.metering?.usageKey === 'contract.docs' && meteringView.billing === undefined)
  const subsGone = await api('GET', '/api/market/subscriptions', { token: admin })
  check('订阅代收端点已随 M0-2 下线（404）', subsGone.status === 404)
  const officialPrompts = await api('GET', '/api/market/prompts?orgId=' + newOrg.data.id, { token: admin })
  check('自营插件提示词包可取用', officialPrompts.ok && JSON.stringify(officialPrompts.data.prompts).includes('合同审查'))

  const uninstall = await api('POST', '/api/market/plugins/com.acme.hello/uninstall', { token: admin, body: { orgId: tenantOrg.data.id } })
  check('卸载联动（运行态回收）', uninstall.ok && uninstall.data.status === 'uninstalled')
  const promptsAfterUninstall = await api('GET', '/api/market/prompts?orgId=' + tenantOrg.data.id, { token: admin })
  check('卸载后提示词包不再提供', promptsAfterUninstall.ok && !JSON.stringify(promptsAfterUninstall.data.prompts).includes('磁姆助手'))

  // ================================================================ MCP
  section('MCP 部署服务')
  const svcCreate = await api('POST', '/api/mcp/services', { token: admin, body: { name: '自测检索服务', slug: 'selftest-search', orgId: newOrg.data.id, description: '自测用（演示传输层）', transport: 'http', mode: 'hosted', exec: 'demo' } })
  check('注册 MCP 服务（草稿）', svcCreate.ok && svcCreate.data.status === 'draft')
  const svcId = svcCreate.data.id

  const invokeDraft = await api('POST', '/api/mcp/invoke', { token: admin, body: { serviceId: svcId, tool: 'selftest-search_search' } })
  check('草稿服务拒绝调用', !invokeDraft.ok || invokeDraft.data.status === 'denied')

  const verify = await api('POST', `/api/mcp/services/${svcId}/verify`, { token: admin })
  check('测试环境验证', verify.ok && verify.data.status === 'verifying')

  const dryRun = await api('POST', `/api/mcp/services/${svcId}/deploy`, { token: admin, body: { dryRun: true } })
  check('部署 dry-run 影响面预览', dryRun.ok && dryRun.data.dryRun === true)

  const deployGray = await api('POST', `/api/mcp/services/${svcId}/deploy`, { token: admin, body: { grayPercent: 20, version: '0.1.0', changelog: '灰度首发' } })
  check('灰度发布（20%）', deployGray.ok && deployGray.data.status === 'gray' && deployGray.data.grayPercent === 20)

  const deployFull = await api('POST', `/api/mcp/services/${svcId}/deploy`, { token: admin, body: { grayPercent: 100, version: '0.2.0', changelog: '全量' } })
  check('全量发布', deployFull.ok && deployFull.data.status === 'online')

  const rollback = await api('POST', `/api/mcp/services/${svcId}/rollback`, { token: admin, body: { targetVersion: '0.1.0' } })
  check('版本回滚（版本不可变保留）', rollback.ok && rollback.data.currentVersion === '0.1.0')

  // 网关鉴权：未授权主体
  const invokeDenied = await api('POST', '/api/mcp/invoke', { token: dev, body: { serviceId: svcId, tool: 'selftest-search_search', args: { query: 'hi' } } })
  check('未授权主体被网关拒绝', invokeDenied.ok && invokeDenied.data.status === 'denied', JSON.stringify(invokeDenied).slice(0, 300))

  // 权限组授权后放行
  const pg = await api('POST', '/api/mcp/perm-groups', { token: admin, body: {
    name: '自测权限组', policies: { [svcId]: { allowedTools: '*', constraints: { readOnly: true } } },
    subjects: [{ type: 'user_group', id: groupCreate.data.id }],
  } })
  check('创建 MCP 权限组', pg.ok)

  const devUser = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('陈默'), { token: admin })).data.users[0]
  await api('PATCH', '/api/iam/groups/' + groupCreate.data.id, { token: admin, body: { memberIds: [devUser.id] } })
  const invokeOk = await api('POST', '/api/mcp/invoke', { token: dev, body: { serviceId: svcId, tool: 'selftest-search_search', args: { query: '自测' } } })
  check('授权后调用成功（只读工具放行）', invokeOk.ok && invokeOk.data.ok === true, JSON.stringify(invokeOk).slice(0, 300))

  const writeTool = (await api('GET', '/api/mcp/services', { token: admin })).data.services.find((s) => s.id === svcId).tools.find((t) => t.riskLevel !== 'read')
  if (writeTool) {
    const invokeWrite = await api('POST', '/api/mcp/invoke', { token: dev, body: { serviceId: svcId, tool: writeTool.name } })
    check('只读约束拦截写工具', invokeWrite.data?.status === 'denied' && String(invokeWrite.data.error).includes('只读'), JSON.stringify(invokeWrite).slice(0, 300))
  }

  // 回归：Agent 机器凭证身份解析（权限组 subject type=agent 必须能命中）
  const agentMcp = await api('POST', '/api/agents', { token: admin, body: { name: '自测MCP机器人', attrs: { description: 'MCP 鉴权回归', model: 'deepseek-chat', riskLevel: 'low', avatar: '🤖' } } })
  check('注册 Agent（MCP 鉴权回归用）', agentMcp.ok && agentMcp.data.credential?.clientId)
  const agentMcpId = agentMcp.data.agent.id
  const agentCc = await api('POST', '/api/auth/client-credentials', { body: { clientId: agentMcp.data.credential.clientId, clientSecret: agentMcp.data.credential.clientSecret } })
  check('Agent 机器凭证换令牌', agentCc.ok && agentCc.data.token)
  const agentToken = agentCc.data.token

  const agentInvokeDenied = await api('POST', '/api/mcp/invoke', { token: agentToken, body: { serviceId: svcId, tool: 'selftest-search_search', args: { query: '未授权' } } })
  check('未授权 Agent 被网关拒绝', agentInvokeDenied.ok && agentInvokeDenied.data.status === 'denied', JSON.stringify(agentInvokeDenied).slice(0, 300))

  const pgAgent = await api('POST', '/api/mcp/perm-groups', { token: admin, body: {
    name: '自测Agent权限组', policies: { [svcId]: { allowedTools: '*', constraints: { readOnly: true } } },
    subjects: [{ type: 'agent', id: agentMcpId }],
  } })
  check('创建 Agent 主体权限组', pgAgent.ok)

  const agentInvokeOk = await api('POST', '/api/mcp/invoke', { token: agentToken, body: { serviceId: svcId, tool: 'selftest-search_search', args: { query: '自测' } } })
  check('Agent 主体命中权限组放行', agentInvokeOk.ok && agentInvokeOk.data.ok === true, JSON.stringify(agentInvokeOk).slice(0, 300))

  const agentMcpCall = await rawReq('POST', '/mcp', {
    headers: { 'content-type': 'application/json', authorization: `Bearer ${agentToken}` },
    body: JSON.stringify({ jsonrpc: '2.0', id: 90, method: 'tools/call', params: { name: 'mcp_invoke', arguments: { serviceId: svcId, tool: 'selftest-search_search', args: { query: '自测' } } } }),
  })
  const agentMcpText = jsonBody(agentMcpCall).result?.content?.[0]?.text ?? ''
  const agentMcpInvoke = (() => { try { return JSON.parse(agentMcpText) } catch { return {} } })()
  check('Agent 机器令牌经 /mcp mcp_invoke 放行', agentMcpCall.status === 200 && agentMcpInvoke.status === 'ok', agentMcpText.slice(0, 300))

  const metrics = await api('GET', `/api/mcp/services/${svcId}/metrics`, { token: admin })
  check('调用监控指标（调用方/工具/序列）', metrics.ok && metrics.data.calls >= 1 && metrics.data.toolStats.length > 0 && metrics.data.series.length === 60)

  const healthProbe = await api('POST', `/api/mcp/services/${svcId}/health`, { token: admin })
  check('健康探测', healthProbe.ok && ['healthy', 'degraded'].includes(healthProbe.data.status))

  // ================================================================ 第 0 步：执行层/连接器真实化
  section('第 0 步：真实传输层与真实连接器')
  // -- MCP 真实 stub（JSON-RPC over HTTP） ---------------------------------
  const mcpStub = createServer(async (req, res) => {
    const raw = await readBody(req)
    let msg = {}
    try { msg = JSON.parse(raw) } catch { /* ignore */ }
    if (msg.method === 'initialize') {
      res.writeHead(200, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ jsonrpc: '2.0', id: msg.id, result: { protocolVersion: '2025-03-26', capabilities: {} } }))
      return
    }
    if (msg.method === 'tools/call') {
      if (msg.params?.name === 'boom') {
        res.writeHead(200, { 'content-type': 'application/json' })
        res.end(JSON.stringify({ jsonrpc: '2.0', id: msg.id, result: { isError: true, content: '故意失败' } }))
        return
      }
      res.writeHead(200, { 'content-type': 'application/json' })
      res.end(JSON.stringify({
        jsonrpc: '2.0', id: msg.id,
        result: { content: [{ type: 'text', text: `real-echo:${msg.params?.name}` }], usage: { totalTokens: 4321 } },
      }))
      return
    }
    res.writeHead(404).end('{}')
  })
  await new Promise((resolve) => mcpStub.listen(0, '127.0.0.1', resolve))
  const mcpPort = mcpStub.address().port

  const realSvc = await api('POST', '/api/mcp/services', { token: admin, body: { name: '真实后端服务', slug: 'real-backend', orgId: newOrg.data.id, endpoint: `http://127.0.0.1:${mcpPort}/mcp`, transport: 'http', mode: 'external', exec: 'real', tools: [
    { name: 'real_query', description: '真实查询', inputSchema: { type: 'object' }, riskLevel: 'read' },
    { name: 'boom', description: '总是失败', inputSchema: { type: 'object' }, riskLevel: 'read' },
  ] } })
  check('注册 real 服务（默认真实传输）', realSvc.ok && realSvc.data.exec === 'real')
  const realId = realSvc.data.id
  await api('POST', '/api/mcp/perm-groups', { token: admin, body: {
    name: 'real 全放行', policies: { [realId]: { allowedTools: '*', constraints: {} } },
    subjects: [{ type: 'user', id: adminLogin.data.user.id, name: 'admin' }],
  } })
  const realVerify = await api('POST', `/api/mcp/services/${realId}/verify`, { token: admin })
  check('real 服务测试验证（真实 initialize 探测）', realVerify.ok && realVerify.data.health.status === 'healthy')
  await api('POST', `/api/mcp/services/${realId}/deploy`, { token: admin, body: { version: '1.0.0', changelog: '真实首发' } })

  const realInvoke = await api('POST', '/api/mcp/invoke', { token: admin, body: { serviceId: realId, tool: 'real_query', args: { q: '真实链路' } } })
  check('real 调用真实往返（stub 内容透传）', realInvoke.ok && JSON.stringify(realInvoke.data.result).includes('real-echo:real_query'))

  const boomInvoke = await api('POST', '/api/mcp/invoke', { token: admin, body: { serviceId: realId, tool: 'boom', args: {} } })
  check('real 错误路径（isError → status error）', boomInvoke.data.status === 'error')
  const realCalls = (await api('GET', `/api/mcp/calls?serviceId=${realId}`, { token: admin })).data.items
  const okRealCall = realCalls.find((c) => c.tool === 'real_query')
  const boomRealCall = realCalls.find((c) => c.tool === 'boom')
  check('real 计量来自响应 usage（tokens=4321，非伪造）', okRealCall && okRealCall.tokens === 4321 && okRealCall.exec === 'real')
  check('real 失败调用同样标记 exec=real', boomRealCall && boomRealCall.exec === 'real' && boomRealCall.ok === false)

  const mcpUsage = await api('GET', '/api/usage/events?resource=mcp:real-backend', { token: admin })
  check('MCP real 调用自动进入计量管道（含失败调用）', mcpUsage.ok && mcpUsage.data.total >= 2
    && mcpUsage.data.items.every((e) => typeof e.tenant_id === 'string' && e.tenant_id.length > 0 && e.principal.startsWith('org:')), JSON.stringify((mcpUsage.data?.items ?? []).map((e) => ({ t: e.tenant_id, p: e.principal, r: e.resource }))))

  const deadSvc = await api('POST', '/api/mcp/services', { token: admin, body: { name: '不可达服务', slug: 'dead-backend', orgId: newOrg.data.id, endpoint: 'http://127.0.0.1:1/mcp', mode: 'external', exec: 'real', tools: [{ name: 'x', description: 'x', inputSchema: { type: 'object' }, riskLevel: 'read' }] } })
  const deadVerify = await api('POST', `/api/mcp/services/${deadSvc.data.id}/verify`, { token: admin })
  check('real 验证不可达 endpoint 被拒（不再恒可达）', !deadVerify.ok)

  // ================================================================ MCP 配置导入（mcpServers JSON）
  section('MCP 配置导入（mcpServers JSON 一键接入）')
  // streamable HTTP + SSE 响应帧 + 会话头的 mock 服务（复刻 teambition 形态）
  const mcpSseStub = createServer(async (req, res) => {
    const raw = await readBody(req)
    let msg = {}
    try { msg = JSON.parse(raw) } catch { /* ignore */ }
    const sseReply = (payload, extra = {}) => {
      res.writeHead(200, { 'content-type': 'text/event-stream', ...extra })
      res.end(`data: ${JSON.stringify(payload)}\n\n`)
    }
    const noSession = { jsonrpc: '2.0', id: msg.id, error: { code: -32600, message: 'Server not initialized: session required' } }
    if (msg.method === 'initialize') {
      return sseReply({ jsonrpc: '2.0', id: msg.id, result: { protocolVersion: '2025-03-26', capabilities: { tools: {} }, serverInfo: { name: 'tb-like', version: '1.0' } } }, { 'mcp-session-id': 'sess-stub-1' })
    }
    if (msg.method === 'notifications/initialized') { res.writeHead(202); return res.end() }
    if (msg.method === 'tools/list') {
      if (req.headers['mcp-session-id'] !== 'sess-stub-1') return sseReply(noSession)
      return sseReply({ jsonrpc: '2.0', id: msg.id, result: { tools: [
        { name: 'tb_query_task', description: '查询任务', inputSchema: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] } },
        { name: 'tb_create_task', description: '创建任务', inputSchema: { type: 'object', properties: { title: { type: 'string' } } } },
      ] } })
    }
    if (msg.method === 'tools/call') {
      if (req.headers['mcp-session-id'] !== 'sess-stub-1') return sseReply(noSession)
      const auth = req.headers.authorization ? `|auth:${req.headers.authorization}` : ''
      return sseReply({ jsonrpc: '2.0', id: msg.id, result: { content: [{ type: 'text', text: `sse-echo:${msg.params?.name}${auth}` }], usage: { totalTokens: 88 } } })
    }
    res.writeHead(404).end('{}')
  })
  await new Promise((resolve) => mcpSseStub.listen(0, '127.0.0.1', resolve))
  const ssePort = mcpSseStub.address().port

  // 1. 标准形态导入（用户实际粘贴的配置样式）
  const tbConfig = JSON.stringify({ mcpServers: { 'teambition-mcp': { type: 'streamableHttp', url: `http://127.0.0.1:${ssePort}/api/mcp?userToken=u-demo` } } })
  const imp = await api('POST', '/api/mcp/import', { token: admin, body: { config: tbConfig } })
  check('mcpServers JSON 一键导入', imp.ok && imp.data.imported === 1 && imp.data.results[0].ok, JSON.stringify(imp).slice(0, 300))
  const impR = imp.data.results[0]
  check('工具自动发现（initialize→tools/list，SSE 帧解析）', impR.tools === 2 && impR.reachable === true)
  check('导入即验证并上线（autoDeploy）', impR.status === 'online')
  const tbService = (await api('GET', '/api/mcp/services', { token: admin })).data.services.find((s) => s.id === impR.serviceId)
  check('发现的工具含完整 inputSchema', tbService.tools.length === 2 && tbService.tools[0].inputSchema?.required?.[0] === 'id')

  // 2. 全链路调用（SSE + 会话头 + 权限组）
  await api('POST', '/api/mcp/perm-groups', { token: admin, body: {
    name: 'teambition 全放行', policies: { [impR.serviceId]: { allowedTools: '*', constraints: {} } },
    subjects: [{ type: 'user', id: adminLogin.data.user.id, name: 'admin' }],
  } })
  const tbInvoke = await api('POST', '/api/mcp/invoke', { token: admin, body: { serviceId: impR.serviceId, tool: 'tb_query_task', args: { id: 't-1' } } })
  check('导入服务真实调用（SSE 响应 + 会话复用）', tbInvoke.ok && tbInvoke.data.ok === true && JSON.stringify(tbInvoke.data.result).includes('sse-echo:tb_query_task'), JSON.stringify(tbInvoke).slice(0, 300))

  // 3. headers 透传（Authorization）
  const authConfig = JSON.stringify({ mcpServers: { 'authed-mcp': { type: 'http', url: `http://127.0.0.1:${ssePort}/api/mcp`, headers: { Authorization: 'Bearer tk-123' } } } })
  const impAuth = await api('POST', '/api/mcp/import', { token: admin, body: { config: authConfig } })
  await api('POST', '/api/mcp/perm-groups', { token: admin, body: {
    name: 'authed 全放行', policies: { [impAuth.data.results[0].serviceId]: { allowedTools: '*', constraints: {} } },
    subjects: [{ type: 'user', id: adminLogin.data.user.id, name: 'admin' }],
  } })
  const authInvoke = await api('POST', '/api/mcp/invoke', { token: admin, body: { serviceId: impAuth.data.results[0].serviceId, tool: 'tb_query_task', args: {} } })
  check('导入的认证头透传到远端（Authorization）', authInvoke.ok && authInvoke.data.ok === true && JSON.stringify(authInvoke.data.result).includes('auth:Bearer tk-123'), JSON.stringify(authInvoke).slice(0, 300))
  const whoamiInvoke = await api('POST', '/api/mcp/invoke', { token: admin, body: { serviceId: impAuth.data.results[0].serviceId, tool: 'whoami', args: {} } })
  check('清单外工具被网关拒绝（导入不越权）', whoamiInvoke.data?.status === 'denied', JSON.stringify(whoamiInvoke).slice(0, 200))
  const authSvc = (await api('GET', '/api/mcp/services', { token: admin })).data.services.find((s) => s.id === impAuth.data.results[0].serviceId)
  check('认证头列表回显脱敏', authSvc?.headers?.Authorization && !String(authSvc.headers.Authorization).includes('tk-123'), JSON.stringify(authSvc?.headers))

  // 4. stdio/command 本地形态不支持
  const impStdio = await api('POST', '/api/mcp/import', { token: admin, body: { config: JSON.stringify({ mcpServers: { 'local-tools': { command: 'npx', args: ['-y', 'some-mcp'] } } }) } })
  check('stdio/command 形态标记不可导入', impStdio.ok && impStdio.data.results[0].ok === false && /stdio/.test(impStdio.data.results[0].error))

  // 5. 非法 JSON
  const impBad = await api('POST', '/api/mcp/import', { token: admin, body: { config: '{oops' } })
  check('非法 JSON 报错（400）', !impBad.ok && impBad.status === 400 && /JSON/.test(impBad.error?.message ?? ''))

  // 6. 重复导入（slug 冲突）
  const impDup = await api('POST', '/api/mcp/import', { token: admin, body: { config: tbConfig } })
  check('重复导入同名列出冲突', impDup.ok && impDup.data.results[0].ok === false && /已存在/.test(impDup.data.results[0].error))

  // 7. 权限控制
  const impDenied = await api('POST', '/api/mcp/import', { token: dev, body: { config: tbConfig } })
  check('无 mcp.service.write 权限导入被拒（403）', impDenied.status === 403)

  // 8. 远端不可达：导入成功但保留草稿
  const impDead = await api('POST', '/api/mcp/import', { token: admin, body: { config: JSON.stringify({ mcpServers: { 'dead-remote': { type: 'http', url: 'http://127.0.0.1:1/mcp' } } }) } })
  check('远端不可达：导入保留草稿并回传原因', impDead.data.results[0].ok === true && impDead.data.results[0].reachable === false && impDead.data.results[0].status === 'draft' && /发现失败/.test(impDead.data.results[0].error ?? ''), JSON.stringify(impDead).slice(0, 300))
  const deadImported = (await api('GET', '/api/mcp/services', { token: admin })).data.services.find((s) => s.id === impDead.data.results[0].serviceId)
  check('不可达服务不落伪工具清单', deadImported.tools.length === 0)

  // 9. 在线外部服务同步工具
  const syncRes = await api('POST', `/api/mcp/services/${impR.serviceId}/sync-tools`, { token: admin })
  check('在线外部服务可同步工具清单', syncRes.ok && syncRes.data.tools.length === 2)

  // -- 钉钉真实 stub（复刻 OpenAPI 形状） ---------------------------------
  const ddUsers = {
    dd_u002: { unionId: 'dd_u002', userId: 'u002', name: '林小满', email: 'linxm@yuanbingke.com' },
    dd_u020: { unionId: 'dd_u020', userId: 'u020', name: '真实连接用户', jobNumber: 'DD0020', title: '真实目录工程师', email: 'real@yuanbingke.com', active: true },
  }
  const ddStub = createServer(async (req, res) => {
    const url = new URL(req.url, 'http://stub')
    const raw = await readBody(req)
    const jsonReply = (code, payload) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(payload)) }
    if (url.pathname === '/v1.0/oauth2/accessToken') {
      const body = JSON.parse(raw || '{}')
      if (body.appKey === 'stub-key' && body.appSecret === 'stub-secret') return jsonReply(200, { accessToken: 'corp-token-stub', expireIn: 7200 })
      return jsonReply(400, { code: 'invalid.credentials' })
    }
    if (url.pathname === '/v1.0/oauth2/userAccessToken') {
      const body = JSON.parse(raw || '{}')
      if (typeof body.code === 'string' && body.code.startsWith('STUB-')) return jsonReply(200, { accessToken: `ut-${body.code}`, expireIn: 7200, corpId: 'ding-real' })
      return jsonReply(400, { code: 'invalid.code' })
    }
    if (url.pathname === '/v1.0/contact/users/me') {
      const token = req.headers['x-acs-dingtalk-access-token']
      if (token !== 'ut-STUB-OK') return jsonReply(401, { code: 'invalid.token' })
      return jsonReply(200, { ...ddUsers.dd_u002, corpId: 'ding-real' })
    }
    if (url.pathname === '/topapi/v2/department/listsubid') {
      if (url.searchParams.get('access_token') !== 'corp-token-stub') return jsonReply(200, { errcode: 40014, errmsg: 'invalid access_token' })
      const body = JSON.parse(raw || '{}')
      if (body.dept_id === 1) return jsonReply(200, { errcode: 0, errmsg: 'ok', result: { dept_id_list: [500] } })
      return jsonReply(200, { errcode: 0, errmsg: 'ok', result: { dept_id_list: [] } })
    }
    if (url.pathname === '/topapi/v2/department/get') {
      if (url.searchParams.get('access_token') !== 'corp-token-stub') return jsonReply(200, { errcode: 40014, errmsg: 'invalid access_token' })
      const body = JSON.parse(raw || '{}')
      return jsonReply(200, { errcode: 0, errmsg: 'ok', result: { dept_id: body.dept_id, name: body.dept_id === 1 ? '真实企业根' : '真实连接器部门' } })
    }
    if (url.pathname === '/topapi/v2/user/list') {
      if (url.searchParams.get('access_token') !== 'corp-token-stub') return jsonReply(200, { errcode: 40014, errmsg: 'invalid access_token' })
      const body = JSON.parse(raw || '{}')
      if (body.dept_id !== 500) return jsonReply(200, { errcode: 0, errmsg: 'ok', result: { list: [], has_more: false } })
      return jsonReply(200, { errcode: 0, errmsg: 'ok', result: { list: [{ unionid: 'dd_u020', userid: 'u020', name: '真实连接用户', job_number: 'DD0020', title: '真实目录工程师', email: 'real@yuanbingke.com', active: true }], has_more: false } })
    }
    res.writeHead(404).end('{}')
  })
  await new Promise((resolve) => ddStub.listen(0, '127.0.0.1', resolve))
  const ddPort = ddStub.address().port

  const putConnector = await api('PUT', '/api/iam/connectors/dingtalk', { token: admin, body: { corpId: 'ding-real', appKey: 'stub-key', appSecret: 'stub-secret', mode: 'real', apiBase: `http://127.0.0.1:${ddPort}`, oapiBase: `http://127.0.0.1:${ddPort}`, enabled: true, conflictStrategy: 'manual' } })
  check('连接器切换真实模式', putConnector.ok && putConnector.data.mode === 'real')
  const connTest = await api('POST', '/api/iam/connectors/dingtalk/test', { token: admin })
  check('真实连接器健康检查（mock:false）', connTest.ok && connTest.data.ok === true && connTest.data.mock === false)

  const realAuth = await api('POST', '/api/auth/sso/authorize', { body: { provider: 'dingtalk', scene: 'web_qr' } })
  const realSso = await api('POST', '/api/auth/sso', { body: { provider: 'dingtalk', code: 'STUB-OK', state: realAuth.data.state } })
  check('真实 OpenAPI 登录链路（token→userinfo→命中）', realSso.ok && realSso.data.kind === 'hit' && realSso.data.user.username === 'linxm')

  const realSync = await api('POST', '/api/iam/connectors/dingtalk/sync', { token: admin })
  check('真实目录同步（OpenAPI 分页拉取）', realSync.ok && realSync.data.created >= 1)
  const syncedUser = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('真实连接用户'), { token: admin })).data.users[0]
  check('真实同步新建账号落库', Boolean(syncedUser) && syncedUser.status === 'active')

  // 降级回归：切回 mock 后显式标注
  const mockBack = await api('PUT', '/api/iam/connectors/dingtalk', { token: admin, body: { corpId: 'ding-yuanbingke', appKey: 'demo-app-key', appSecret: 'demo-secret-do-not-use', mode: 'mock', enabled: true } })
  check('切回降级模式（显式标注 mock）', mockBack.ok && mockBack.data.mode === 'mock')

  // 事务存储落位（计量/资金类数据库文件创建）
  const { existsSync } = await import('node:fs')
  check('SQLite 事务存储已就位（txnstore.db）', existsSync(join(DATA_DIR, 'txnstore.db')))

  // -- 多主体接入（同 provider 多实例连接器） --------------------------------
  // 兼容语义：:param 先按实例 id 解析、失败按 provider 取第一条；旧路由 'dingtalk' 零改动可用。
  section('多主体接入（同 provider 多实例连接器：创建/唯一约束/隔离同步/删除）')
  const createSecond = await api('POST', '/api/iam/connectors', { token: admin, body: { provider: 'dingtalk', name: '第二主体', corpId: 'ding-second', appKey: 'demo-key-2', appSecret: 'demo-secret-2', mode: 'mock', enabled: true, conflictStrategy: 'manual' } })
  check('创建第二主体连接器（POST /api/iam/connectors）', createSecond.ok && Boolean(createSecond.data?.id), JSON.stringify(createSecond).slice(0, 300))
  const listAfterCreate = await api('GET', '/api/iam/connectors', { token: admin })
  check('连接器列表出现 2 条配置', listAfterCreate.ok && listAfterCreate.data.configs.length === 2, JSON.stringify(listAfterCreate.data).slice(0, 200))
  const dupCorp = await api('POST', '/api/iam/connectors', { token: admin, body: { provider: 'dingtalk', name: '重复主体', corpId: 'ding-second', appKey: 'demo-key-2', appSecret: 'demo-secret-2', mode: 'mock', enabled: true, conflictStrategy: 'manual' } })
  check('同 provider+corpId 重复创建被拒（provider|corpId 唯一约束）', !dupCorp.ok, JSON.stringify(dupCorp).slice(0, 200))
  const id2 = createSecond.data?.id
  const syncSecond = await api('POST', `/api/iam/connectors/${id2}/sync`, { token: admin })
  check('按实例 id 同步第二主体', syncSecond.ok && /同步完成/.test(syncSecond.data?.message ?? ''), JSON.stringify(syncSecond).slice(0, 300))
  const syncFirstAgain = await api('POST', '/api/iam/connectors/dingtalk/sync', { token: admin })
  check('第一主体旧路由（按 provider 解析）同步互不影响', syncFirstAgain.ok && /同步完成/.test(syncFirstAgain.data?.message ?? ''), JSON.stringify(syncFirstAgain).slice(0, 300))
  const orgsAfterMulti = (await api('GET', '/api/iam/orgs', { token: admin })).data
  const mockRootCount = orgsAfterMulti.filter((org) => org.name === '元冰可集团').length
  check('两家主体部门并存（两家根部门均落库）', mockRootCount >= 2, `元冰可集团根数=${mockRootCount}`)
  const delSecond = await api('DELETE', `/api/iam/connectors/${id2}`, { token: admin })
  check('删除第二主体连接器（DELETE /api/iam/connectors/:id）', delSecond.ok && delSecond.data?.deleted === true, JSON.stringify(delSecond).slice(0, 200))
  const listAfterDelete = await api('GET', '/api/iam/connectors', { token: admin })
  check('删除后列表回到 1 条', listAfterDelete.ok && listAfterDelete.data.configs.length === 1, JSON.stringify(listAfterDelete.data).slice(0, 200))
  const testDeleted = await api('POST', `/api/iam/connectors/${id2}/test`, { token: admin })
  check('已删除实例不可再测试', !testDeleted.ok, JSON.stringify(testDeleted).slice(0, 200))
  const authProviders = await api('GET', '/api/auth/providers')
  check('三方登录入口带 configId/name（多主体可区分）', authProviders.ok && authProviders.data.providers.length >= 1
    && authProviders.data.providers.every((p) => p.configId && p.name), JSON.stringify(authProviders.data).slice(0, 300))

  section('连接器自动同步与全员名册（组织数据通道）')
  // 自动同步：intervalMinutes 到期巡检（定时器每分钟跑同一 runDueAutoSyncs，此处以手动触发口等价验证）
  const autoSyncConn = await api('POST', '/api/iam/connectors', { token: admin, body: { provider: 'dingtalk', name: '自动同步主体', corpId: 'ding-autosync', appKey: 'demo-key-auto', appSecret: 'demo-secret-auto', mode: 'mock', enabled: true, intervalMinutes: 5, conflictStrategy: 'manual' } })
  check('创建自动同步主体（intervalMinutes=5，从未同步=到期）', autoSyncConn.ok && Boolean(autoSyncConn.data?.id), JSON.stringify(autoSyncConn).slice(0, 200))
  const manualOnlyConn = await api('POST', '/api/iam/connectors', { token: admin, body: { provider: 'dingtalk', name: '仅手动主体', corpId: 'ding-manualonly', appKey: 'demo-key-manual', appSecret: 'demo-secret-manual', mode: 'mock', enabled: true, intervalMinutes: 0, conflictStrategy: 'manual' } })
  check('创建仅手动主体（intervalMinutes=0）', manualOnlyConn.ok && Boolean(manualOnlyConn.data?.id), JSON.stringify(manualOnlyConn).slice(0, 200))
  const autoRun1 = await api('POST', '/api/iam/connectors/auto-sync', { token: admin })
  check('到期巡检：从未同步的连接器被补同步', autoRun1.ok && autoRun1.data.processed >= 1
    && autoRun1.data.results.some((item) => item.configId === autoSyncConn.data?.id && item.ok), JSON.stringify(autoRun1.data).slice(0, 300))
  check('到期巡检：0=仅手动的连接器不被处理', autoRun1.ok && !autoRun1.data.results.some((item) => item.configId === manualOnlyConn.data?.id), JSON.stringify(autoRun1.data).slice(0, 300))
  const autoRun2 = await api('POST', '/api/iam/connectors/auto-sync', { token: admin })
  check('到期巡检：刚同步过的连接器不重复处理', autoRun2.ok && autoRun2.data.processed === 0, JSON.stringify(autoRun2.data).slice(0, 200))
  const delAutoSync = await api('DELETE', `/api/iam/connectors/${autoSyncConn.data?.id}`, { token: admin })
  check('清理自动同步主体', delAutoSync.ok)
  const delManualOnly = await api('DELETE', `/api/iam/connectors/${manualOnlyConn.data?.id}`, { token: admin })
  check('清理仅手动主体', delManualOnly.ok)

  // 全员名册：iam.roster.read（org_admin 经 iam.* 通配自带；接入应用经机器凭证 scope 授权）
  const rosterAdmin = await api('GET', '/api/iam/roster', { token: admin })
  check('管理员拉取全员名册（users+orgs）', rosterAdmin.ok && Array.isArray(rosterAdmin.data.users) && Array.isArray(rosterAdmin.data.orgs), JSON.stringify(rosterAdmin.data).slice(0, 200))
  const rosterSyncedUser = rosterAdmin.ok ? rosterAdmin.data.users.find((u) => u.jobNumber === 'DD0001') : undefined
  check('名册含同步账号（工号/组织名/稳定关联键 id）', Boolean(rosterSyncedUser) && Boolean(rosterSyncedUser.orgName) && Boolean(rosterSyncedUser.id))
  check('名册组织含部门负责人（钉钉 dept_manager 同步链）', rosterAdmin.ok && rosterAdmin.data.orgs.some((org) => Array.isArray(org.leaderUserIds) && org.leaderUserIds.length > 0))
  const rosterText = rosterAdmin.ok ? JSON.stringify(rosterAdmin.data) : ''
  check('名册 PII 最小化（无口令字段/无手机号）', rosterText !== '' && !rosterText.includes('passwordHash') && !rosterText.includes('"phone"'))
  const rosterNoAuth = await api('GET', '/api/iam/roster')
  check('未认证拉取名册 401', rosterNoAuth.status === 401)
  const rosterDeniedCred = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'roster-denied', refType: 'app', scopes: ['agent.read'] } })
  const rosterDeniedCc = await api('POST', '/api/auth/client-credentials', { body: { clientId: rosterDeniedCred.data.clientId, clientSecret: rosterDeniedCred.data.clientSecret } })
  const rosterDenied = await api('GET', '/api/iam/roster', { token: rosterDeniedCc.data?.token })
  check('无 iam.roster.read 的机器凭证 403', rosterDenied.status === 403)
  const rosterCred = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'hr-app-roster', refType: 'app', scopes: ['iam.roster.read'] } })
  check('签发名册读取机器凭证（应用接入组织数据通道）', rosterCred.ok && Boolean(rosterCred.data.clientId), JSON.stringify(rosterCred.data).slice(0, 200))
  const rosterCc = await api('POST', '/api/auth/client-credentials', { body: { clientId: rosterCred.data.clientId, clientSecret: rosterCred.data.clientSecret } })
  const rosterMachine = await api('GET', '/api/iam/roster', { token: rosterCc.data?.token })
  check('机器凭证（iam.roster.read）拉取名册 200（与管理员同视图）', rosterMachine.ok && rosterMachine.data.users.length === (rosterAdmin.data?.users?.length ?? -1))
  const rosterAudit = await api('GET', '/api/audit/logs?type=invoke&q=roster', { token: admin })
  check('名册拉取留痕（invoke 审计含 machine actor）', rosterAudit.ok && JSON.stringify(rosterAudit.data).includes('iam.roster.pull'))

  // 应用组织架构同步（org-sync：默认凭证自助复用平台组织模块，2026-09-15）
  section('应用组织架构同步（org-sync：绑定凭证自助拉平台组织树，version 轮询）')
  const orgSyncApp = await api('POST', '/api/apps', { token: admin, body: { name: '组织同步验收应用', attrs: { description: 'org-sync 组织模块复用验收', appType: 'web', riskLevel: 'low', dataClass: 'internal' } } })
  check('注册组织同步验收应用（自动带默认机器凭证）', orgSyncApp.ok && Boolean(orgSyncApp.data?.credential?.clientId), JSON.stringify(orgSyncApp.error))
  const orgSyncAppId = orgSyncApp.data.app.id
  const orgSyncCc = await api('POST', '/api/auth/client-credentials', { body: { clientId: orgSyncApp.data.credential.clientId, clientSecret: orgSyncApp.data.credential.clientSecret } })
  const orgSync1 = await api('GET', `/api/apps/${orgSyncAppId}/org-sync`, { token: orgSyncCc.data?.token })
  check('应用默认凭证自助拉取组织快照 200（orgs+users+version）',
    orgSync1.ok && Array.isArray(orgSync1.data.orgs) && Array.isArray(orgSync1.data.users) && /^[0-9a-f]{16}$/.test(orgSync1.data.version ?? ''), JSON.stringify(orgSync1.error ?? orgSync1.data).slice(0, 200))
  const orgSyncText = orgSync1.ok ? JSON.stringify(orgSync1.data) : ''
  check('org-sync PII 最小化（无 email/phone/口令/三方绑定）',
    orgSyncText !== '' && !orgSyncText.includes('"email"') && !orgSyncText.includes('"phone"') && !orgSyncText.includes('passwordHash') && !orgSyncText.includes('"bindings"'))
  check('org-sync 含部门负责人字段与成员组织归属（组织模块复用要素）',
    orgSync1.ok && orgSync1.data.orgs.some((org) => Array.isArray(org.leaderUserIds)) && orgSync1.data.users.length > 0 && orgSync1.data.users.every((user) => Boolean(user.orgId)))
  const orgSync2 = await api('GET', `/api/apps/${orgSyncAppId}/org-sync`, { token: orgSyncCc.data?.token })
  check('version 内容哈希幂等（同内容再拉 version 不变）', orgSync2.ok && orgSync2.data.version === orgSync1.data.version)
  const orgSyncUnchanged = await api('GET', `/api/apps/${orgSyncAppId}/org-sync?ifNoneMatch=${orgSync1.data.version}`, { token: orgSyncCc.data?.token })
  check('ifNoneMatch 命中返回 unchanged（零载荷轮询）', orgSyncUnchanged.ok && orgSyncUnchanged.data.unchanged === true && orgSyncUnchanged.data.orgs === undefined)
  const orgSyncOrgCreate = await api('POST', '/api/iam/orgs', { token: admin, body: { name: '同步验收临时部门' } })
  check('平台新增组织成功（构造变更源）', orgSyncOrgCreate.ok, JSON.stringify(orgSyncOrgCreate.error))
  const orgSync3 = await api('GET', `/api/apps/${orgSyncAppId}/org-sync`, { token: orgSyncCc.data?.token })
  check('组织变更后 version 变化且新组织入快照',
    orgSync3.ok && orgSync3.data.version !== orgSync1.data.version && orgSync3.data.orgs.some((org) => org.name === '同步验收临时部门'))
  const orgSyncStale = await api('GET', `/api/apps/${orgSyncAppId}/org-sync?ifNoneMatch=${orgSync1.data.version}`, { token: orgSyncCc.data?.token })
  check('过期 ifNoneMatch 不命中（回落全量快照）', orgSyncStale.ok && orgSyncStale.data.unchanged === false && Array.isArray(orgSyncStale.data.orgs))
  const orgSyncNoAuth = await api('GET', `/api/apps/${orgSyncAppId}/org-sync`)
  check('未认证拉取组织快照 401', orgSyncNoAuth.status === 401)
  const orgSyncDenied = await api('GET', `/api/apps/${orgSyncAppId}/org-sync`, { token: rosterDeniedCc.data?.token })
  check('无 app.read 的他应用凭证 403', orgSyncDenied.status === 403)
  const orgSyncAudit = await api('GET', '/api/audit/logs?type=invoke&q=org-sync', { token: admin })
  check('org-sync 拉取留痕（invoke 审计 app.org-sync.pull）', orgSyncAudit.ok && JSON.stringify(orgSyncAudit.data).includes('app.org-sync.pull'))
  const orgSyncOrgDelete = await api('DELETE', `/api/iam/orgs/${orgSyncOrgCreate.data.id}`, { token: admin, body: {} })
  check('验收临时组织清理成功', orgSyncOrgDelete.ok, JSON.stringify(orgSyncOrgDelete.error))

  mcpStub.close()
  ddStub.close()

  // ================================================================ M0-2：钱包/分账功能面下线回归
  section('M0-2 钱包/分账下线回归（全端点 404 / 权限点移除）')
  const idemOwner = (await api('GET', '/api/iam/orgs', { token: admin })).data[0]
  const billingWalletGone = await api('GET', '/api/billing/wallets/org/selftest-nonexistent', { token: admin })
  check('钱包查询端点已下线（404）', billingWalletGone.status === 404)
  const billingSettleGone = await api('POST', '/api/billing/settle', { token: admin, body: { period: '2026-09' } })
  check('账期结转端点已下线（404）', billingSettleGone.status === 404)
  const billingLedgerGone = await api('GET', '/api/billing/ledger', { token: admin })
  check('分账分录端点已下线（404）', billingLedgerGone.status === 404)
  const iamPoints = (await api('GET', '/api/iam/permissions', { token: admin })).data
  const allPoints = JSON.stringify(iamPoints)
  check('billing.* 权限点已从矩阵移除', !allPoints.includes('billing.read') && !allPoints.includes('billing.write') && !allPoints.includes('billing.admin'), allPoints.slice(0, 120))

  // ================================================================ 评审缺陷修复回归（replay 不双计 / 死信）
  section('评审缺陷修复回归（replay 不双计 / 死信端点可用）')
  const reconcileBeforeReplay = await api('POST', '/api/usage/reconcile', { token: admin })
  const replayAll = await api('POST', '/api/usage/replay', { token: admin, body: { from: new Date(Date.now() - 40 * 86_400_000).toISOString() } })
  const reconcileAfterReplay = await api('POST', '/api/usage/reconcile', { token: admin })
  check('replay 重放不双计（消费水位幂等，投影/口径一致）', replayAll.ok && replayAll.data.replayed > 0
    && reconcileBeforeReplay.data.reconciliation.mismatch === false
    && reconcileAfterReplay.data.reconciliation.mismatch === false
    && JSON.stringify(reconcileAfterReplay.data.reconciliation.projections) === JSON.stringify(reconcileBeforeReplay.data.reconciliation.projections))

  const dlRetry = await api('POST', '/api/usage/dead-letters/retry', { token: admin })
  check('死信重投端点可用（真实执行重试）', dlRetry.ok && typeof dlRetry.data.retried === 'number')

  // ================================================================ 认证加固回归（轮换宽限 / 暴力破解锁定 / OIDC 收敛）
  section('认证加固回归（密钥轮换宽限期 / 暴力破解锁定 / OIDC scope+PKCE）')
  const preRotate = await api('POST', '/api/auth/login', { body: { username: 'admin', password: 'Ybk@2026' } })
  const rotate = await api('POST', '/api/authn/rotate-secret', { token: admin })
  const oldTokenAlive = await api('GET', '/api/auth/me', { token: preRotate.data.token })
  check('密钥轮换宽限期：存量令牌不掉线（24h 验签兼容）', rotate.ok && rotate.data.graceHours === 24 && oldTokenAlive.ok)

  const postRotateLogin = await api('POST', '/api/auth/login', { body: { username: 'admin', password: 'Ybk@2026' } })
  const postRotateMe = await api('GET', '/api/auth/me', { token: postRotateLogin.data.token })
  check('轮换后新签发令牌可用（新密钥签名）', postRotateLogin.ok && postRotateMe.ok)

  const brute = await api('POST', '/api/iam/users', { token: admin, body: { username: 'brutetest', displayName: '暴力破解测试', orgId: idemOwner.id, title: '测试' } })
  for (let i = 0; i < 5; i++) {
    await api('POST', '/api/auth/login', { body: { username: 'brutetest', password: 'wrong-password' } })
  }
  const bruteLocked = await api('POST', '/api/auth/login', { body: { username: 'brutetest', password: brute.data.initialPassword } })
  check('连续失败 5 次后锁定（正确口令也暂拒 + 告警）', brute.ok && bruteLocked.status === 401 && JSON.stringify(bruteLocked.error).includes('锁定'))

  const lockAlerts = await api('GET', '/api/audit/alerts', { token: admin })
  check('锁定触发已入告警中心（暴力破解可观测）', lockAlerts.ok && JSON.stringify(lockAlerts.data.alerts).includes('登录失败锁定'))

  // OIDC scope 白名单 / PKCE 强制 / Basic+Post 双认证的回归断言已并入第 6 步（浏览器授权流重写）

  // ================================================================ 资产运营（企业 AI 资产台账 / 健康巡检 / 成本报表）
  section('资产运营（统一台账 / 健康巡检 / 成本报表）')
  const assetsInv = await api('GET', '/api/assets/inventory', { token: admin })
  check('资产台账（五类资产统一盘点）', assetsInv.ok && assetsInv.data.total > 0
    && ['mcp', 'agent', 'app', 'skill', 'model'].every((t) => assetsInv.data.items.some((i) => i.type === t)))
  const assetsReport = await api('GET', '/api/assets/report?days=30', { token: admin })
  check('资产成本报表（Top 资产 / 主体分摊 / 日趋势）', assetsReport.ok && assetsReport.data.topResources.length > 0
    && assetsReport.data.byPrincipal.length > 0 && assetsReport.data.byDay.length > 0
    && assetsReport.data.totals.count > 0)
  const assetsHealth = await api('POST', '/api/assets/healthcheck', { token: admin })
  check('资产健康巡检（批量探活并留审计）', assetsHealth.ok && assetsHealth.data.checked > 0 && Array.isArray(assetsHealth.data.items))
  const assetsTyped = await api('GET', '/api/assets/inventory?type=mcp&days=7', { token: admin })
  check('台账筛选（类型 + 窗口）', assetsTyped.ok && assetsTyped.data.items.every((i) => i.type === 'mcp'))

  const benefit = await api('GET', '/api/assets/benefit?days=30', { token: admin })
  check('成本穿透（零价快照口径：内部成本逐行恒等，无收入/毛利）', benefit.ok && benefit.data.rows.length >= 1
    && benefit.data.totals.cost_cents === benefit.data.rows.reduce((s, r) => s + r.cost_cents, 0)
    && benefit.data.rows.every((row) => row.margin_cents === undefined && row.charge_cents === undefined))

  // ================================================================ Skill 市场
  section('Skill 市场流水线')
  const malicious = await api('POST', '/api/skills', { token: dev, body: { name: '恶意清理脚本', content: '# 清理\n```sh\nrm -rf / --no-preserve-root\n```\n调用了 sk-1234567890abcdef1234567890', category: '通用', version: '1.0.0' } })
  check('静态扫描拦截恶意提交（自动驳回）', malicious.ok && malicious.data.status === 'rejected')

  const submit = await api('POST', '/api/skills', { token: dev, body: { name: '自测报告助手', summary: '生成自测报告', content: '# 自测报告助手\n\n## 何时使用\n每日自测后生成报告。\n\n## 步骤\n1. 汇总断言结果\n2. 生成 Markdown 报告', category: '办公提效', version: '1.0.0' } })
  check('正常提交进入待审批', submit.ok && submit.data.status === 'pending_approval')
  const skillId = submit.data.id

  const approveDomain = await api('POST', `/api/skills/${skillId}/approve`, { token: admin, body: { decision: 'approve', level: 'domain', opinion: '业务适用' } })
  check('领域审批通过', approveDomain.ok)

  const publish = await api('POST', `/api/skills/${skillId}/publish`, { token: admin, body: {} })
  check('版本化上架', publish.ok && publish.data.status === 'published')

  const agentsList = (await api('GET', '/api/agents', { token: admin })).data.agents
  const targetAgent = agentsList.find((a) => a.slug === 'dev-coder')
  const install = await api('POST', `/api/skills/${skillId}/install`, { token: dev, body: { agentId: targetAgent.id } })
  check('安装到 Agent（依赖登记）', install.ok && install.data.stats.installs >= 1)

  const agentDetail = await api('GET', `/api/agents/${targetAgent.id}`, { token: admin })
  check('Agent 关联 Skill 自动回填', agentDetail.ok && (agentDetail.data.attrs.skills ?? []).includes('自测报告助手'))

  const download = await api('POST', `/api/skills/${skillId}/download`, { token: dev, body: {} })
  check('下载留痕（返回 SKILL.md）', download.ok && download.data.content.includes('自测报告助手'))

  // 计量管道（观测补齐）：skill 下载/安装进 usage 事件（skill:<ID>，默认零费率）
  const skillUsage = await api('GET', '/api/usage/events?resource=' + encodeURIComponent(`skill:${skillId}`), { token: admin })
  check('Skill 下载/安装进计量管道（skill:<ID> 资源，零费率）', skillUsage.ok && skillUsage.data.total >= 2 && (skillUsage.data.items[0].pricing?.charge_cents ?? -1) === 0)
  const skillMeters = skillUsage.data.items.flatMap((event) => event.meters.map((meter) => meter.key))
  check('skill 事件 meters 含价格簿计价键 calls（硬校验下内部管道存活）', skillMeters.includes('calls') && skillMeters.includes('downloads') && skillMeters.includes('installs'))
  const skillExternalMeter = await api('POST', '/api/usage/record', { token: admin, body: { org: tenantOrg.data.id, subject: `agent:${targetAgent.id}`, principal: `org:${tenantOrg.data.id}`, resource: `skill:${skillId}`, meters: [{ key: 'calls', value: 1, unit: '次' }], idempotency_key: 'test-usage-skill-external-1' } })
  check('外部 usage record 可上报 skill:<ID> 资源（默认价格簿放行）', skillExternalMeter.ok)
  const heat = await api('GET', '/api/skills/usage-heatmap?days=30', { token: admin })
  const heatRow = (heat.data?.skills ?? []).find((s) => s.id === skillId)
  check('技能热力图（skill × 日使用矩阵，含安装/下载/外部上报）', heat.ok && heatRow?.total >= 2 && Array.isArray(heatRow?.cells) && heatRow.cells.length === 30 && (heat.data.maxCell ?? 0) >= 1)

  // —— 已上架 Skill 信息编辑与资源包重传（作者本人/管理员可操作，非作者开发者拒绝） ——
  const otherDevLogin = await api('POST', '/api/auth/login', { body: { username: 'linxm', password: 'Ybk@2026' } })
  const otherDev = otherDevLogin.data?.token
  const editDenied = await api('PATCH', `/api/skills/${skillId}`, { token: otherDev, body: { summary: '越权改简介' } })
  check('非作者且无管理权的开发者编辑被拒（403）', editDenied.status === 403)
  const repkgDenied = await api('PUT', `/api/skills/${skillId}/package`, { token: otherDev, body: { packageBase64: Buffer.from('PK\x03\x04evil', 'latin1').toString('base64') } })
  check('非作者重传资源包被拒（403）', repkgDenied.status === 403)

  const editByAuthor = await api('PATCH', `/api/skills/${skillId}`, { token: dev, body: { summary: '生成自测报告（已更新）', tags: ['自测', '报告'], description: '更新后的详细描述', applicableModels: ['deepseek-chat', 'deepseek-reasoner'], visibility: 'all', authorName: '陈默（示范作者）' } })
  check('作者编辑市场信息（slug 与版本不变，不重走审批）', editByAuthor.ok && editByAuthor.data.summary === '生成自测报告（已更新）' && editByAuthor.data.tags.join(',') === '自测,报告' && editByAuthor.data.status === 'published')
  check('作者名称可改（仅展示署名，authorId 归属不变）', editByAuthor.ok && editByAuthor.data.authorName === '陈默（示范作者）' && editByAuthor.data.authorId === devLogin.data.user.id)
  const editEmptyAuthor = await api('PATCH', `/api/skills/${skillId}`, { token: dev, body: { authorName: '  ' } })
  check('编辑校验：作者名称不可为空白', !editEmptyAuthor.ok)
  const editByAdmin = await api('PATCH', `/api/skills/${skillId}`, { token: admin, body: { category: '研发效能' } })
  check('管理员（skill.publish）可编辑任意 Skill 信息', editByAdmin.ok && editByAdmin.data.category === '研发效能')
  const editEmptyName = await api('PATCH', `/api/skills/${skillId}`, { token: dev, body: { name: '   ' } })
  check('编辑校验：名称不可为空白', !editEmptyName.ok)

  const skillZipBase64 = Buffer.from('PK\x03\x04skill-package-v2-content', 'latin1').toString('base64')
  const repkgBadZip = await api('PUT', `/api/skills/${skillId}/package`, { token: dev, body: { packageBase64: Buffer.from('definitely-not-a-zip', 'latin1').toString('base64') } })
  check('资源包校验：非 ZIP 内容被拒（PK 魔数）', !repkgBadZip.ok)
  const repkg = await api('PUT', `/api/skills/${skillId}/package`, { token: dev, body: { packageBase64: skillZipBase64 } })
  check('作者重传资源包（原地替换，版本号不变）', repkg.ok && repkg.data.skill.currentVersion === '1.0.0' && repkg.data.skill.status === 'published' && repkg.data.package?.sizeBytes === Buffer.from('PK\x03\x04skill-package-v2-content', 'latin1').length)
  const repkgDetail = await api('GET', `/api/skills/${skillId}`, { token: admin })
  const repkgVersion = repkgDetail.data?.versions?.find((v) => v.status === 'published')
  check('资源包替换落库（已发布版本 packageBase64/登记同步更新）', repkgDetail.ok && repkgVersion?.packageBase64 === skillZipBase64 && !!repkgVersion?.package?.uploadedAt)

  const deprecateNoReason = await api('POST', `/api/skills/${skillId}/deprecate`, { token: admin, body: {} })
  check('弃用未填原因被拒（护栏，下架分析口径依赖）', !deprecateNoReason.ok)

  const deprecate = await api('POST', `/api/skills/${skillId}/deprecate`, { token: admin, body: { reason: '自测弃用' } })
  check('弃用并触发存量引用告警', deprecate.ok && deprecate.data.skill.status === 'deprecated' && deprecate.data.referencingAgents.length >= 1)
  check('弃用原因落库持久化（详情与下架分析可见）', deprecate.ok && deprecate.data.skill.deprecatedReason === '自测弃用' && !!deprecate.data.skill.deprecatedAt)

  const alerts = await api('GET', '/api/audit/alerts', { token: admin })
  check('存量引用告警已入告警中心', alerts.ok && JSON.stringify(alerts.data.alerts).includes('自测报告助手'))

  const rate = await api('POST', `/api/skills/${skillId}/rate`, { token: dev, body: { stars: 5 } })
  check('评分', rate.ok && rate.data.stats.rating === 5)

  // ================================================================ Agent 生命周期（L4 审批）
  section('Agent 本体生命周期')
  const opsLogin = await api('POST', '/api/auth/login', { body: { username: 'ops', password: 'Ybk@2026' } })
  check('资源管理员登录', opsLogin.ok)
  const ops = opsLogin.data.token
  const agentCreate = await api('POST', '/api/agents', { token: ops, body: { name: '自测机器人', attrs: { description: '自测用机器人', model: 'deepseek-chat', riskLevel: 'low', avatar: '🧪' } } })
  check('注册 Agent（并颁发机器凭证）', agentCreate.ok && agentCreate.data.credential.clientId)
  const selfAgent = agentCreate.data.agent

  // 凭证默认 usage.write（Agent 自推计量能力）+ 机器身份读台账入审计（agent.verify）
  const selfAgentCc = await api('POST', '/api/auth/client-credentials', { body: { clientId: agentCreate.data.credential.clientId, clientSecret: agentCreate.data.credential.clientSecret } })
  check('新注册 Agent 凭证默认含 usage.write', selfAgentCc.ok && selfAgentCc.data.principal.scopes.includes('usage.write'))
  check('新注册 Agent 凭证默认含 agent.write（自主提报更新）', selfAgentCc.ok && selfAgentCc.data.principal.scopes.includes('agent.write'))
  check('新注册 Agent 凭证默认含 modelgw.invoke（模型网关调用）', selfAgentCc.ok && selfAgentCc.data.principal.scopes.includes('modelgw.invoke'))
  const agentSelfUpdate = await api('PATCH', `/api/agents/${selfAgent.id}`, { token: selfAgentCc.data.token, body: { attrs: { description: '自测用机器人（资料已由 Agent 凭自身凭证提报更新）' } } })
  check('Agent 凭自身凭证提报更新资料 200（agent.write 生效）', agentSelfUpdate.ok && String(agentSelfUpdate.data.attrs['description']).includes('凭自身凭证提报更新'), JSON.stringify(agentSelfUpdate.error))

  const agentVerifyLogs = () => api('GET', '/api/audit/logs?type=auth&resourceType=agent&limit=200', { token: admin })
  const verifyBefore = (await agentVerifyLogs()).data.items.filter((log) => log.action === 'agent.verify').length
  await api('GET', '/api/agents', { token: admin })
  const verifyAfterHuman = (await agentVerifyLogs()).data.items.filter((log) => log.action === 'agent.verify').length
  check('人类读台账不产生 agent.verify（噪音控制）', verifyAfterHuman === verifyBefore)

  const machineAgentsList = await api('GET', '/api/agents', { token: selfAgentCc.data.token })
  check('机器令牌读台账 200（接入验证「发一句话」）', machineAgentsList.ok)
  const verifyLogs = (await agentVerifyLogs()).data.items
  check('机器身份读台账入审计（agent.verify 留痕）', verifyLogs.some((log) => log.action === 'agent.verify' && log.actorId === selfAgentCc.data.principal.id))

  // 运营数据提报（Agent 接入义务，与 AI 应用 metrics-report 同级，2026-08）
  const agentReport1 = await api('POST', `/api/agents/${selfAgent.id}/metrics-report`, { token: selfAgentCc.data.token, body: { dau: 3, sessions: 5, userIds: ['u001', 'u002'] } })
  check('Agent 凭自身凭证提报运营数据 200（agent.write 生效，首提即"发一句话"）', agentReport1.ok && agentReport1.data.sessions === 5 && agentReport1.data.dau === 3, JSON.stringify(agentReport1.error))
  const agentReport2 = await api('POST', `/api/agents/${selfAgent.id}/metrics-report`, { token: selfAgentCc.data.token, body: { dau: 2, sessions: 1, userIds: ['u002', 'u003'] } })
  check('Agent 提报语义：同日 dau 取最大、会话累加、用户哈希去重并集', agentReport2.ok && agentReport2.data.dau === 3 && agentReport2.data.sessions === 6 && agentReport2.data.uniqueUsers === 3, JSON.stringify(agentReport2.error ?? agentReport2.data))
  const agentReportBad = await api('POST', `/api/agents/${selfAgent.id}/metrics-report`, { token: selfAgentCc.data.token, body: { dau: -1 } })
  check('Agent 提报校验：负数 dau 被拒', !agentReportBad.ok)
  const agentReportBadDate = await api('POST', `/api/agents/${selfAgent.id}/metrics-report`, { token: selfAgentCc.data.token, body: { dau: 1, date: '2026/08/01' } })
  check('Agent 提报校验：非法 date 被拒', !agentReportBadDate.ok)
  const agentReportGhost = await api('POST', '/api/agents/agt_ghost/metrics-report', { token: selfAgentCc.data.token, body: { dau: 1 } })
  check('Agent 提报校验：不存在的 Agent 被拒', !agentReportGhost.ok)
  const agentReportTool = await api('POST', '/api/tools/execute', { token: admin, body: { name: 'agent_metrics_report', args: { agentId: selfAgent.id, dau: 4, sessions: 2 } } })
  check('工具 agent_metrics_report 上报（同日 dau 取最大）', agentReportTool.ok && agentReportTool.data.isError === false && agentReportTool.data.value.reported === true && agentReportTool.data.value.metrics.dau === 4)
  const agentEntryUrl = await api('PATCH', `/api/agents/${selfAgent.id}`, { token: selfAgentCc.data.token, body: { attrs: { entryUrl: 'https://bot.example.com/chat' } } })
  check('Agent 自主提报交互界面地址（entryUrl 白名单生效）', agentEntryUrl.ok && agentEntryUrl.data.attrs['entryUrl'] === 'https://bot.example.com/chat', JSON.stringify(agentEntryUrl.error))

  const agentSelfMeter = await api('POST', '/api/usage/record', { token: selfAgentCc.data.token, body: { org: tenantOrg.data.id, subject: `agent:${selfAgent.id}`, principal: `org:${tenantOrg.data.id}`, resource: 'mcp:real-backend', meters: [{ key: 'tokens', value: 100, unit: 'token' }], idempotency_key: 'test-usage-agent-self-1' } })
  check('Agent 机器令牌自推计量 200（usage.write 生效，零价快照）', agentSelfMeter.ok && agentSelfMeter.data.pricing.charge_cents === 0)

  // Agent 接入提示词（与 app 同构：rotate 轮换机器凭证携带完整凭证；首行含关键词「提示词」供 connector 触发）
  const agentPrompt = await api('POST', `/api/agents/${selfAgent.id}/onboarding-prompt`, { token: selfAgentCc.data.token, body: { rotate: true } })
  check('Agent 接入提示词：凭自身凭证 rotate 生成（含新 secret 与关键词「提示词」）',
    agentPrompt.ok && agentPrompt.data.rotated === true && agentPrompt.data.prompt.includes('提示词')
    && Boolean(agentPrompt.data.credential.clientSecret) && agentPrompt.data.prompt.includes(agentPrompt.data.credential.clientSecret),
    JSON.stringify(agentPrompt.error))
  const agentPromptCc = await api('POST', '/api/auth/client-credentials', { body: { clientId: agentPrompt.data.credential.clientId, clientSecret: agentPrompt.data.credential.clientSecret } })
  check('Agent 接入提示词：轮换后新 secret 可换牌', agentPromptCc.ok && Boolean(agentPromptCc.data?.token), JSON.stringify(agentPromptCc.error))
  // 用换牌后的新令牌复核 agent.write 仍生效（自提报更新资料）
  const agentPromptSelfPatch = await api('PATCH', `/api/agents/${selfAgent.id}`, { token: agentPromptCc.data.token, body: { attrs: { description: '自测用机器人（提示词轮换后仍可自更新）' } } })
  check('Agent 接入提示词：轮换后凭新令牌 PATCH 资料 200', agentPromptSelfPatch.ok, JSON.stringify(agentPromptSelfPatch.error))
  // 轮换已吊销旧令牌：就地刷新 selfAgentCc 的令牌，保证本段后续用例继续持有有效凭证
  selfAgentCc.data.token = agentPromptCc.data.token

  // 调用统计口径补全（2026-08）：usage.recorded 回灌 + 防双计
  const agentMetricsAfterSelfMeter = await api('GET', `/api/agents/${selfAgent.id}`, { token: admin })
  check('防双计①：自推 mcp:* 计量不回灌调用台账（MCP 口径归 McpInvoked，宁缺勿重）',
    agentMetricsAfterSelfMeter.ok && agentMetricsAfterSelfMeter.data.metrics.calls === 0 && (agentMetricsAfterSelfMeter.data.metrics.gwCalls ?? 0) === 0,
    JSON.stringify(agentMetricsAfterSelfMeter.data?.metrics))

  // 模型网关回灌闭环：Agent 凭自身凭证调用模型网关 → usage.recorded(subject=agent:<id>) 回灌调用台账
  const agentModelStub = createServer(async (req, res) => {
    if (req.url.endsWith('/chat/completions')) {
      await readBody(req)
      res.writeHead(200, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ choices: [{ message: { role: 'assistant', content: 'agent 模型网关回灌 stub' } }], usage: { prompt_tokens: 120, completion_tokens: 1500 } }))
      return
    }
    res.writeHead(404).end('{}')
  })
  await new Promise((resolve) => agentModelStub.listen(0, '127.0.0.1', resolve))
  const agentModelPort = agentModelStub.address().port
  const agentModelReg = await api('POST', '/api/modelgw/models', { token: admin, body: { slug: 'ds-stub-agent', displayName: 'Agent 回灌验证', provider: 'deepseek', endpoint: `http://127.0.0.1:${agentModelPort}/v1`, apiKey: 'stub-key', costCentsPerKTokens: 0 } })
  check('Agent 验证模型目录登记', agentModelReg.ok)
  const agentGwInvoke = await api('POST', '/api/modelgw/invoke', { token: selfAgentCc.data.token, body: { model: 'ds-stub-agent', messages: [{ role: 'user', content: 'hi' }], orgId: tenantOrg.data.id } })
  check('Agent 凭自身凭证调用模型网关 200（modelgw.invoke 生效）', agentGwInvoke.ok && agentGwInvoke.data.outputTokens === 1500, JSON.stringify(agentGwInvoke.error ?? agentGwInvoke.data))
  const agentGwEvent = await api('GET', '/api/usage/events?resource=model:ds-stub-agent', { token: admin })
  check('网关计量事件主体为 agent:<id>（回灌依据）', agentGwEvent.ok && agentGwEvent.data.items[0]?.subject === `agent:${selfAgent.id}`, JSON.stringify(agentGwEvent.data?.items?.[0]?.subject))
  const agentMetricsAfterGw = await api('GET', `/api/agents/${selfAgent.id}`, { token: admin })
  check('模型网关调用回灌 Agent 台账（calls=1 / tokens=1620 / gwCalls=1）',
    agentMetricsAfterGw.ok && agentMetricsAfterGw.data.metrics.calls === 1 && agentMetricsAfterGw.data.metrics.tokens === 1620 && agentMetricsAfterGw.data.metrics.gwCalls === 1,
    JSON.stringify(agentMetricsAfterGw.data?.metrics))
  agentModelStub.close()

  // ================================================================ M0-3 用量透明月报（J4 契约）
  section('M0 用量透明月报（J4：部门/Agent/Skill tokens 三维聚合 + CSV 自助导出）')
  const j4Month = new Date().toISOString().slice(0, 7)
  const j4Report = await api('GET', `/api/usage/report/monthly?month=${j4Month}`, { token: admin })
  check('J4 月报聚合可用（当月 totals 事件数 > 0）', j4Report.ok && j4Report.data.month === j4Month && j4Report.data.totals.events > 0, JSON.stringify(j4Report).slice(0, 200))
  check('J4 部门维度（org 归口聚合，tokens 汇总）', j4Report.ok && j4Report.data.byOrg.some((r) => r.dimension === tenantOrg.data.id && r.tokens > 0), JSON.stringify(j4Report.data?.byOrg))
  check('J4 Agent 维度（subject=agent:* 聚合）', j4Report.ok && j4Report.data.byAgent.some((r) => r.dimension === `agent:${selfAgent.id}` && r.tokens > 0), JSON.stringify(j4Report.data?.byAgent))
  check('J4 Skill 维度（resource=skill:* 聚合）', j4Report.ok && j4Report.data.bySkill.length >= 1)
  check('J4 零价快照口径（totals charge 恒 0）', j4Report.ok && j4Report.data.totals.charge_cents === 0)
  const j4Csv = await rawReq('GET', `/api/usage/report/monthly?month=${j4Month}&format=csv`, { headers: { authorization: `Bearer ${admin}` } })
  check('J4 CSV 自助导出（text/csv + BOM + 表头）', j4Csv.status === 200 && (j4Csv.headers['content-type'] ?? '').includes('text/csv') && j4Csv.body.startsWith('\ufeff') && j4Csv.body.includes('维度,维度值,事件数,tokens'), JSON.stringify({ status: j4Csv.status, ct: j4Csv.headers['content-type'], head: j4Csv.body.slice(0, 80) }))

  const j4OrgTokenSum = j4Report.data.byOrg.reduce((sum, row) => sum + row.tokens, 0)
  check('J4 三维自洽（QA B-01：totals.tokens = ΣbyOrg.tokens，修复前差 176 倍）',
    j4OrgTokenSum === j4Report.data.totals.tokens && j4Report.data.totals.tokens > 0,
    JSON.stringify({ totals: j4Report.data.totals.tokens, orgSum: j4OrgTokenSum }))

  const onlineTooEarly = await api('POST', `/api/agents/${selfAgent.id}/transition`, { token: ops, body: { action: 'online' } })
  check('缺治理属性不可上线（校验）', !onlineTooEarly.ok)

  await api('PATCH', `/api/agents/${selfAgent.id}`, { token: ops, body: { attrs: { systemPromptVersion: 'v1', dataClass: 'internal', trialGroups: ['灰度试点组'] } } })
  const trial = await api('POST', `/api/agents/${selfAgent.id}/transition`, { token: admin, body: { action: 'submit_trial' } })
  check('进入试运行', trial.ok && trial.data.status === 'trial')

  const obo = await api('POST', `/api/agents/${targetAgent.id}/obo-token`, { token: admin })
  check('on-behalf-of 令牌（act 链）', obo.ok && obo.data.actChain.length >= 1 && obo.data.actChain[0].type === 'human')

  const bind = await api('POST', `/api/agents/${selfAgent.id}/bindings`, { token: admin, body: { userId: devUser.id } })
  check('绑定用户（授权留痕）', bind.ok)

  // 平台授权直达（entry-ticket，2026-08）：签发授权边界 → 兑换身份 → 一次性/防伪造
  const auditorUserId = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('楚天阔'), { token: admin })).data.users[0].id
  const entryMachineDenied = await api('POST', `/api/agents/${selfAgent.id}/entry-ticket`, { token: selfAgentCc.data.token, body: {} })
  check('直达票据：机器身份签发被拒（human-only）', entryMachineDenied.status === 403, JSON.stringify(entryMachineDenied))
  const entryUnbound = await api('POST', `/api/agents/${selfAgent.id}/entry-ticket`, { token: auditor, body: {} })
  check('直达票据：未授权用户被拒 403（owner/绑定用户/管理员之外，使用即授权留痕）', entryUnbound.status === 403, JSON.stringify(entryUnbound))
  const bindAuditor = await api('POST', `/api/agents/${selfAgent.id}/bindings`, { token: admin, body: { userId: auditorUserId } })
  check('直达票据：绑定审计员（构造纯绑定用户路径）', bindAuditor.ok)
  const entryBound = await api('POST', `/api/agents/${selfAgent.id}/entry-ticket`, { token: auditor, body: {} })
  check('直达票据：绑定用户签发 200（一次性票据 + TTL）', entryBound.ok && entryBound.data.ticket.startsWith('etk_') && entryBound.data.ttlSeconds >= 30, JSON.stringify(entryBound.error))
  const redeemOk = await rawReq('POST', '/api/authn/entry-tickets/redeem', {
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ ticket: entryBound.data.ticket }),
  })
  const redeemBody = jsonBody(redeemOk)
  check('直达票据：公开端点兑换平台身份（sub/roles/tenant + refType/refId）',
    redeemOk.status === 200 && redeemBody.data?.refType === 'agent' && redeemBody.data?.refId === selfAgent.id
    && redeemBody.data?.identity?.sub === auditorUserId && Array.isArray(redeemBody.data?.identity?.roles) && Boolean(redeemBody.data?.identity?.tenant),
    JSON.stringify(redeemBody))
  const redeemReplay = await rawReq('POST', '/api/authn/entry-tickets/redeem', {
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ ticket: entryBound.data.ticket }),
  })
  check('直达票据：重放兑换被拒（一次性消费）', redeemReplay.status === 400, `${redeemReplay.status} ${redeemReplay.body.slice(0, 120)}`)
  check('直达票据：兑换响应放行跨域（任意 entryUrl 前端可读取，ACAO=*）', redeemReplay.headers['access-control-allow-origin'] === '*', JSON.stringify(redeemReplay.headers))
  const redeemPreflight = await rawReq('OPTIONS', '/api/authn/entry-tickets/redeem', {
    headers: { origin: 'http://192.168.0.7:6060', 'access-control-request-method': 'POST', 'access-control-request-headers': 'content-type' },
  })
  check('直达票据：OPTIONS 预检 204 + ACAO（跨域浏览器流程可通）',
    redeemPreflight.status === 204 && redeemPreflight.headers['access-control-allow-origin'] === '*' && String(redeemPreflight.headers['access-control-allow-headers'] ?? '').includes('content-type'),
    `${redeemPreflight.status} ${JSON.stringify(redeemPreflight.headers)}`)
  const redeemForged = await rawReq('POST', '/api/authn/entry-tickets/redeem', {
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ ticket: 'etk_forged_0000000000000000000000000000000000000000' }),
  })
  check('直达票据：伪造票据被拒', redeemForged.status === 400)

  // L4 上线（2026-09-15 同人审批放开）：提交人与审批人允许同一账号——发起人自审直接通过并自动执行
  // （原 QA A-05 自审自批拦截已按业务决策取消；approver 账号保留，供其余双人流程断言使用）
  const onlineRequest = await api('POST', `/api/agents/${selfAgent.id}/transition`, { token: admin, body: { action: 'online', note: '自测上线' } })
  check('上线生成 L4 审批单', onlineRequest.ok && onlineRequest.data.approval.status === 'pending')

  const selfApprove = await api('POST', `/api/approvals/${onlineRequest.data.approval.id}/decide`, { token: admin, body: { decision: 'approve', opinion: '自审通过（同人审批放开）', confirmed: true } })
  check('发起人自审通过并自动执行上线（同人审批放开）', selfApprove.ok && selfApprove.data.status === 'executed', JSON.stringify(selfApprove.error ?? {}).slice(0, 160))
  const agentAfter = await api('GET', `/api/agents/${selfAgent.id}`, { token: admin })
  check('Agent 状态已上线', agentAfter.data.status === 'online')

  // L4 下线：凭证吊销联动
  const credBefore = agentAfter.data.credential
  const offlineRequest = await api('POST', `/api/agents/${selfAgent.id}/transition`, { token: ops, body: { action: 'offline', note: '自测下线' } })
  check('下线生成 L4 审批单', offlineRequest.ok)
  await api('POST', `/api/approvals/${offlineRequest.data.approval.id}/decide`, { token: admin, body: { decision: 'approve', opinion: '同意下线', confirmed: true } })
  const agentOffline = await api('GET', `/api/agents/${selfAgent.id}`, { token: admin })
  check('下线后状态与凭证联动禁用', agentOffline.data.status === 'offline' && agentOffline.data.credential.status === 'disabled')
  void credBefore

  // ================================================================ AI 应用资料字段（头像 URL / 开发者 / 描述）
  section('AI 应用资料字段（头像 URL / 开发者下拉 / 描述）')
  const devOptions = await api('GET', '/api/apps/developer-options', { token: ops })
  check('developer-options：资源管理员（app.* → app.write）可拉取在编用户瘦字段', devOptions.ok && Array.isArray(devOptions.data.options) && devOptions.data.options.length > 0 && devOptions.data.options[0].username !== undefined, JSON.stringify(devOptions.error))
  const devOption = devOptions.data?.options?.find((u) => u.username === 'dev')
  check('developer-options：包含演示开发者账号（dev / 陈默）', Boolean(devOption && devOption.name === '陈默'))
  const appAvatarCreate = await api('POST', '/api/apps', { token: ops, body: { name: '资料字段自测应用', attrs: { description: '头像 / 开发者 / 描述字段验证', appType: 'web', icon: 'https://example.com/avatar.png', riskLevel: 'low', dataClass: 'internal', developerId: devOption.id } } })
  check('注册应用：icon 接受图片 URL（头像）', appAvatarCreate.ok && appAvatarCreate.data.app.attrs['icon'] === 'https://example.com/avatar.png', JSON.stringify(appAvatarCreate.error))
  check('注册应用：developerId 校验存在并回填 developerName（displayName 为准）', appAvatarCreate.ok && appAvatarCreate.data.app.attrs['developerId'] === devOption.id && appAvatarCreate.data.app.attrs['developerName'] === '陈默', JSON.stringify(appAvatarCreate.data?.app?.attrs))
  const appAvatarBad = await api('POST', '/api/apps', { token: ops, body: { name: '非法开发者自测应用', attrs: { description: 'developerId 校验', appType: 'web', riskLevel: 'low', dataClass: 'internal', developerId: 'usr_ghost' } } })
  check('注册应用：developerId 不存在被拒 400', !appAvatarBad.ok && String(appAvatarBad.error?.message ?? '').includes('开发者不存在'), JSON.stringify(appAvatarBad.error))
  const appAvatarPatch = await api('PATCH', `/api/apps/${appAvatarCreate.data.app.id}`, { token: ops, body: { attrs: { icon: '🧩', developerId: '' } } })
  check('更新应用：icon 可改；developerId 空串清除开发者', appAvatarPatch.ok && appAvatarPatch.data.attrs['icon'] === '🧩' && appAvatarPatch.data.attrs['developerName'] === '' && appAvatarPatch.data.attrs['developerId'] === '', JSON.stringify(appAvatarPatch.error ?? appAvatarPatch.data?.attrs))
  const appAvatarNameOnly = await api('PATCH', `/api/apps/${appAvatarCreate.data.app.id}`, { token: ops, body: { attrs: { developerName: '外部协作开发者' } } })
  check('更新应用：developerName 支持自由文本快照（外部开发者场景）', appAvatarNameOnly.ok && appAvatarNameOnly.data.attrs['developerName'] === '外部协作开发者', JSON.stringify(appAvatarNameOnly.error))

  // 接入提示词（注册同款模板平台侧生成；rotate 轮换机器凭证携带完整凭证；外部推送方按关键词「提示词」触发）
  const promptRotated = await api('POST', `/api/apps/${appAvatarCreate.data.app.id}/onboarding-prompt`, { token: ops, body: { rotate: true } })
  check('接入提示词：rotate 生成完整提示词（含新 clientSecret 与关键词「提示词」）',
    promptRotated.ok && promptRotated.data.rotated === true && promptRotated.data.prompt.includes('提示词')
    && Boolean(promptRotated.data.credential.clientSecret) && promptRotated.data.prompt.includes(promptRotated.data.credential.clientSecret),
    JSON.stringify(promptRotated.error))
  const promptCc = await api('POST', '/api/auth/client-credentials', { body: { clientId: promptRotated.data.credential.clientId, clientSecret: promptRotated.data.credential.clientSecret } })
  check('接入提示词：轮换后的新 secret 可正常换牌（旧值已吊销）', promptCc.ok && Boolean(promptCc.data?.token), JSON.stringify(promptCc.error))
  const promptPlain = await api('POST', `/api/apps/${appAvatarCreate.data.app.id}/onboarding-prompt`, { token: ops, body: {} })
  check('接入提示词：不轮换生成（含 client_id 与占位说明，不含 secret 明文）',
    promptPlain.ok && promptPlain.data.rotated === false && promptPlain.data.prompt.includes(promptPlain.data.credential.clientId)
    && promptPlain.data.prompt.includes('重新生成密钥') && !promptPlain.data.prompt.includes('client_secret：cs_'),
    JSON.stringify(promptPlain.error))

  // MCP 服务注册：orgId 缺省回落根组织（外部推送方机器凭证无需 iam.org.read，与 /api/mcp/import 同口径）
  const devOpts = await api('GET', '/api/apps/developer-options', { token: ops })
  check('开发者选项：响应含钉钉 unionIds 绑定（表格人员字段解析用）',
    devOpts.ok && Array.isArray(devOpts.data.options) && devOpts.data.options.every((o) => Array.isArray(o.unionIds)),
    JSON.stringify(devOpts.error))

  const mcpNoOrg = await api('POST', '/api/mcp/services', { token: ops, body: { name: 'orgId缺省自测MCP', description: 'orgId 缺省回落根组织验证', endpoint: 'https://mcp.example.com/mcp', transport: 'http', mode: 'external' } })
  check('MCP 注册：orgId 缺省回落根组织', mcpNoOrg.ok && Boolean(mcpNoOrg.data?.orgId), JSON.stringify(mcpNoOrg.error))
  // 清理：下线（viaApproval=false 免 L4 审批，自测资产）→ 删除
  const mcpNoOrgOffline = await api('POST', `/api/mcp/services/${mcpNoOrg.data?.id}/offline`, { token: ops, body: { reason: '自测清理', viaApproval: false } })
  check('MCP 注册：自测服务下线（viaApproval=false 直下）', mcpNoOrgOffline.ok, JSON.stringify(mcpNoOrgOffline.error))
  const mcpNoOrgCleanup = await api('DELETE', `/api/mcp/services/${mcpNoOrg.data?.id}`, { token: ops })
  check('MCP 注册：自测服务清理', mcpNoOrgCleanup.ok, JSON.stringify(mcpNoOrgCleanup.error))

  // ================================================================ AI 应用 ↔ SSO 打通（MVP 闭环）
  section('console ticket redeem（WP-02：票据免登控制台，零二次登录）')
  {
    const issue = await api('POST', `/api/agents/${selfAgent.id}/entry-ticket`, { token: admin, body: {} })
    check('免登：领票（复用既有签发端点，一次性 etk_ 票据）', issue.ok && issue.data.ticket.startsWith('etk_'), JSON.stringify(issue.error))
    const redeemSession = await rawReq('POST', '/api/auth/entry-ticket-session', {
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ ticket: issue.data.ticket }),
    })
    const sessionBody = jsonBody(redeemSession)
    check('免登：票据兑换成功建立控制台会话（dst1 令牌 + refresh + 用户档案）',
      redeemSession.status === 200 && typeof sessionBody.data?.token === 'string' && sessionBody.data.token.startsWith('dst1.')
      && Boolean(sessionBody.data?.refreshToken) && Boolean(sessionBody.data?.user?.id),
      `${redeemSession.status} ${JSON.stringify(sessionBody).slice(0, 200)}`)
    const freeOverview = await api('GET', '/api/overview', { token: sessionBody.data.token })
    check('免登：兑换所得会话可直接调用工作台聚合（打开即工作台）', freeOverview.ok, JSON.stringify(freeOverview.error))
    const sessionReplay = await rawReq('POST', '/api/auth/entry-ticket-session', {
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ ticket: issue.data.ticket }),
    })
    check('免登：重放票据被拒（一次性消费防重放）', sessionReplay.status === 400, String(sessionReplay.status))
    const sessionForged = await api('POST', '/api/auth/entry-ticket-session', { body: { ticket: 'etk_forged_0000000000000000000000000000000000000000' } })
    check('免登：伪造票据被拒', sessionForged.status === 400)
    await new Promise((resolve) => setTimeout(resolve, 300))
    const serverLog = serverLogChunks.join('')
    check('免登：票据本体零进服务端日志（stdout/stderr 全量扫描）', Boolean(issue.data.ticket) && !serverLog.includes(issue.data.ticket), '票据本体出现在服务端日志')
    const auditSession = await api('GET', '/api/audit/logs?q=' + encodeURIComponent('entry.ticket.session'), { token: admin })
    check('免登：兑换入审计（*.entry.ticket.session 可检索，且审计不含票据本体）',
      auditSession.ok && (auditSession.data.items ?? []).some((log) => log.action === 'agent.entry.ticket.session' && !JSON.stringify(log).includes(issue.data.ticket)),
      JSON.stringify(auditSession.error ?? auditSession.data?.total))
  }
  section('自助入场票据与跨源回跳（G1：self 票种 / TTL ≤120s / 一次性 / 审计闭环）')
  {
    const selfAnon = await api('POST', '/api/auth/entry-tickets/self', { body: {} })
    check('自助票：未认证被拒（401，机器主体不可自助签发）', selfAnon.status === 401)
    const selfIssued = await api('POST', '/api/auth/entry-tickets/self', { token: dev, body: {} })
    check('自助票：登录人类可自助签发（etk_ 票据，TTL 硬上限 120s 覆盖 env 调高）',
      selfIssued.ok && selfIssued.data.ticket.startsWith('etk_') && selfIssued.data.ttlSeconds <= 120, JSON.stringify(selfIssued.error ?? selfIssued.data))
    const selfRedeem = await rawReq('POST', '/api/auth/entry-ticket-session', {
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ ticket: selfIssued.data.ticket }),
    })
    const selfSession = jsonBody(selfRedeem)
    check('自助票：兑换建立控制台会话（跨源回跳后复用既有公开兑换端点，零新增公开面）',
      selfRedeem.status === 200 && typeof selfSession.data?.token === 'string' && selfSession.data.token.startsWith('dst1.'),
      `${selfRedeem.status} ${JSON.stringify(selfSession).slice(0, 160)}`)
    const selfReplay = await rawReq('POST', '/api/auth/entry-ticket-session', {
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ ticket: selfIssued.data.ticket }),
    })
    check('自助票：重放被拒（一次性/防重放语义与 agent/app 票一致）', selfReplay.status === 400, String(selfReplay.status))
    const selfAudit = await api('GET', '/api/audit/logs?q=' + encodeURIComponent('self.entry.ticket'), { token: admin })
    check('自助票：签发与兑换均入审计（self.entry.ticket.* 可检索，票据本体不落审计）',
      selfAudit.ok && (selfAudit.data.items ?? []).some((log) => log.action === 'self.entry.ticket.issue')
      && (selfAudit.data.items ?? []).some((log) => log.action === 'self.entry.ticket.session')
      && !JSON.stringify(selfAudit.data.items).includes(selfIssued.data.ticket),
      JSON.stringify(selfAudit.error ?? selfAudit.data?.items?.map((item) => item.action)))
  }
  section('Agent ↔ SSO 打通（OIDC-agent 关联，dev-plan-agent-host-unification M2）')
  const oidcAgentCreate = await api('POST', '/api/agents', { token: ops, body: { name: 'SSO 自测机器人', attrs: { description: 'OIDC-agent 关联自测', model: 'deepseek-chat', riskLevel: 'low', avatar: '🔑' } } })
  check('注册 SSO 自测 Agent（owner=资源管理员）', oidcAgentCreate.ok, JSON.stringify(oidcAgentCreate.error))
  const oidcAgentId = oidcAgentCreate.data.agent.id
  await api('PATCH', `/api/agents/${oidcAgentId}`, { token: ops, body: { attrs: { systemPromptVersion: 'v1', dataClass: 'internal' } } })
  const oidcGateNone = await api('POST', `/api/agents/${oidcAgentId}/transition`, { token: ops, body: { action: 'online' } })
  check('Agent 上线门禁：无 OIDC 客户端且无 entryUrl 被拒并指路', !oidcGateNone.ok && JSON.stringify(oidcGateNone.error).includes('身份纳管'), JSON.stringify(oidcGateNone.error))
  const oidcIssue = await api('POST', `/api/agents/${oidcAgentId}/sso-client`, { token: ops, body: { redirectUris: ['http://127.0.0.1:3080/auth/oidc/callback'] } })
  check('Agent SSO 签发 200（owner 自助，refType=agent，secret 一次性返回）',
    oidcIssue.ok && oidcIssue.data.clientId?.startsWith('oc-') && Boolean(oidcIssue.data.clientSecret), JSON.stringify(oidcIssue.error))
  const oidcIssueDup = await api('POST', `/api/agents/${oidcAgentId}/sso-client`, { token: ops, body: { redirectUris: ['http://127.0.0.1:3080/auth/oidc/callback'] } })
  check('重复签发被拒（先禁用后重签）', !oidcIssueDup.ok)
  const oidcAgentCc = await api('POST', '/api/auth/client-credentials', { body: { clientId: oidcAgentCreate.data.credential.clientId, clientSecret: oidcAgentCreate.data.credential.clientSecret } })
  // 机器环回自助（APP_SSO_MACHINE_LOOPBACK 默认开）：绑定凭证 + 环回回调 → 自助轮换/改回调放行
  const oidcMachineRotate = await api('POST', `/api/agents/${oidcAgentId}/sso-client/rotate`, { token: oidcAgentCc.data.token, body: {} })
  check('机器身份轮换环回回调客户端 200（绑定凭证环回自助）', oidcMachineRotate.ok && Boolean(oidcMachineRotate.data.clientSecret), JSON.stringify(oidcMachineRotate))
  const oidcMachinePatchLoop = await api('PATCH', `/api/agents/${oidcAgentId}/sso-client`, { token: oidcAgentCc.data.token, body: { redirectUris: ['http://localhost:3080/auth/oidc/callback'] } })
  check('机器身份自助改回调（环回→环回）200', oidcMachinePatchLoop.ok && oidcMachinePatchLoop.data.redirectUris.includes('http://localhost:3080/auth/oidc/callback'), JSON.stringify(oidcMachinePatchLoop))
  const oidcOwnerPinPublic = await api('PATCH', `/api/agents/${oidcAgentId}/sso-client`, { token: ops, body: { redirectUris: ['https://sso-agent.example.com/cb'] } })
  check('owner 把 Agent 回调改为公网 https 200', oidcOwnerPinPublic.ok, JSON.stringify(oidcOwnerPinPublic.error))
  const oidcMachineRotatePub = await api('POST', `/api/agents/${oidcAgentId}/sso-client/rotate`, { token: oidcAgentCc.data.token, body: {} })
  check('机器身份轮换非环回回调客户端被拒 403（环回限定）', oidcMachineRotatePub.status === 403, JSON.stringify(oidcMachineRotatePub))
  const oidcOwnerPinBack = await api('PATCH', `/api/agents/${oidcAgentId}/sso-client`, { token: ops, body: { redirectUris: ['http://127.0.0.1:3080/auth/oidc/callback'] } })
  check('owner 恢复 Agent 环回回调 200', oidcOwnerPinBack.ok, JSON.stringify(oidcOwnerPinBack.error))
  const oidcBadUri = await api('POST', `/api/agents/${oidcAgentId}/sso-client`, { token: ops, body: { redirectUris: [] } })
  check('签发校验：redirectUris 为空被拒（客户端已存在先拒）', !oidcBadUri.ok)
  const oidcAgentDetail = await api('GET', `/api/agents/${oidcAgentId}`, { token: admin })
  check('Agent 详情含 SSO 配置块（discovery / refAgentName / 门禁模式）',
    oidcAgentDetail.ok && oidcAgentDetail.data.sso?.clientId && oidcAgentDetail.data.sso?.discovery?.authorization_endpoint
    && oidcAgentDetail.data.sso?.refAgentName === 'SSO 自测机器人' && oidcAgentDetail.data.ssoEnforceMode === '1',
    JSON.stringify(oidcAgentDetail.data?.sso))
  const oidcGatePass = await api('POST', `/api/agents/${oidcAgentId}/transition`, { token: ops, body: { action: 'online' } })
  check('上线门禁（点1）：已签发客户端后放行并快照 clientId', oidcGatePass.ok && oidcGatePass.data.approval?.payload?.ssoClientId, JSON.stringify(oidcGatePass.error))
  const oidcDisable = await api('POST', `/api/agents/${oidcAgentId}/sso-client/disable`, { token: admin, body: { reason: '执行期复核测试' } })
  check('管理员禁用客户端 200', oidcDisable.ok)
  const oidcApproveFail = await api('POST', `/api/approvals/${oidcGatePass.data.approval.id}/decide`, { token: approver, body: { decision: 'approve', opinion: '复核应失败', confirmed: true } })
  const oidcAfterFail = await api('GET', `/api/agents/${oidcAgentId}`, { token: admin })
  check('上线门禁（点2）：审批期间禁用 → 执行期复核失败留痕',
    oidcApproveFail.ok && oidcApproveFail.data.status === 'failed' && String(oidcApproveFail.data.execution?.error ?? '').includes('身份纳管'), JSON.stringify(oidcApproveFail.data))
  check('复核失败状态未上线', oidcAfterFail.data.status !== 'online')
  const oidcEnable = await api('POST', `/api/agents/${oidcAgentId}/sso-client/enable`, { token: ops, body: {} })
  check('owner 重新启用客户端 200', oidcEnable.ok && oidcEnable.data.status === 'active')
  const oidcGatePass2 = await api('POST', `/api/agents/${oidcAgentId}/transition`, { token: ops, body: { action: 'online' } })
  const oidcApproveOk = await api('POST', `/api/approvals/${oidcGatePass2.data.approval.id}/decide`, { token: approver, body: { decision: 'approve', opinion: '复核通过', confirmed: true } })
  const oidcAfterOnline = await api('GET', `/api/agents/${oidcAgentId}`, { token: admin })
  check('重新发起上线 → 审批执行成功（状态 online）', oidcApproveOk.ok && oidcApproveOk.data.status === 'executed' && oidcAfterOnline.data.status === 'online', JSON.stringify(oidcApproveFail.data))
  const oidcRotate = await api('POST', `/api/agents/${oidcAgentId}/sso-client/rotate`, { token: ops, body: {} })
  check('owner 轮换 secret 200（旧值立即失效）', oidcRotate.ok && Boolean(oidcRotate.data.clientSecret))
  const oidcOfflineReq = await api('POST', `/api/agents/${oidcAgentId}/transition`, { token: ops, body: { action: 'offline', note: '联动测试' } })
  const oidcOfflineOk = await api('POST', `/api/approvals/${oidcOfflineReq.data.approval.id}/decide`, { token: approver, body: { decision: 'approve', opinion: '下线', confirmed: true } })
  const oidcAfterOffline = await api('GET', `/api/agents/${oidcAgentId}`, { token: admin })
  check('Agent 下线联动：关联 OIDC 客户端自动禁用（refresh 链一并吊销）',
    oidcOfflineOk.ok && oidcAfterOffline.data.status === 'offline' && oidcAfterOffline.data.sso?.status === 'disabled', JSON.stringify(oidcAfterOffline.data?.sso))

  // ================================================================ AI 应用 ↔ SSO 打通（MVP 闭环）

  // ================================================================ AI 应用 ↔ SSO 打通（MVP 闭环）
  section('AI 应用 ↔ SSO 打通（注册 → 签发 → 门禁双点 → 跳转登录）')
  const ssoAppCreate = await api('POST', '/api/apps', { token: ops, body: { name: 'SSO 自测应用', attrs: { description: 'MVP 闭环：注册 → 签发 → 门禁 → 浏览器授权流', appType: 'web', icon: '🔐', url: 'https://sso-app.example.com', riskLevel: 'low', dataClass: 'internal', agentIds: [targetAgent.id] }, agentIds: [targetAgent.id] } })
  check('注册应用（编排在线 Agent，owner=资源管理员）', ssoAppCreate.ok && ssoAppCreate.data.credential.clientId)
  const ssoAppId = ssoAppCreate.data.app.id

  // 应用凭证默认 app.write/app.read（指标提报与自主更新闭环，2026-08）
  const ssoAppCc = await api('POST', '/api/auth/client-credentials', { body: { clientId: ssoAppCreate.data.credential.clientId, clientSecret: ssoAppCreate.data.credential.clientSecret } })
  check('新注册应用凭证默认含 app.write/app.read（提报与自更新）', ssoAppCc.ok && ssoAppCc.data.principal.scopes.includes('app.write') && ssoAppCc.data.principal.scopes.includes('app.read'))
  const ssoAppFirstReport = await api('POST', `/api/apps/${ssoAppId}/metrics-report`, { token: ssoAppCc.data.token, body: { dau: 1, sessions: 1, avgDepth: 1, retention7: 0 } })
  check('应用凭自身凭证提报指标 200（app.write 生效，"发一句话"）', ssoAppFirstReport.ok)

  // 平台授权直达：应用入场票据（与 Agent 同一服务，refType=app）
  const appTicketMachine = await api('POST', `/api/apps/${ssoAppId}/entry-ticket`, { token: ssoAppCc.data.token, body: {} })
  check('应用直达票据：机器身份签发被拒（human-only）', appTicketMachine.status === 403)
  const appTicket = await api('POST', `/api/apps/${ssoAppId}/entry-ticket`, { token: admin, body: {} })
  check('应用直达票据：登录用户签发 200', appTicket.ok && appTicket.data.ticket.startsWith('etk_'), JSON.stringify(appTicket.error))
  const appRedeem = await rawReq('POST', '/api/authn/entry-tickets/redeem', {
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ ticket: appTicket.data.ticket }),
  })
  const appRedeemBody = jsonBody(appRedeem)
  check('应用直达票据：兑换返回 refType=app + 平台身份', appRedeem.status === 200 && appRedeemBody.data?.refType === 'app' && appRedeemBody.data?.refId === ssoAppId && Boolean(appRedeemBody.data?.identity?.sub), JSON.stringify(appRedeemBody))

  // 门禁点 1（早反馈）：未签发 SSO 客户端 → 发起上线被拒
  const gateBlocked = await api('POST', `/api/apps/${ssoAppId}/transition`, { token: ops, body: { action: 'online' } })
  check('上线门禁（点1）：未签发 SSO 客户端被拒并指路', !gateBlocked.ok && JSON.stringify(gateBlocked.error).includes('SSO'))

  // owner-based 授权：非 owner 开发者 / 机器身份一律 403
  const devSso = await api('POST', `/api/apps/${ssoAppId}/sso-client`, { token: dev, body: { redirectUris: ['https://evil.example/cb'] } })
  check('非 owner 开发者签发被拒（developer 有 app.write 但非 owner）', devSso.status === 403)
  const machineCredAppWrite = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'sso-gate-machine', refType: 'external', scopes: ['app.write'] } })
  const machineAppWriteLogin = await api('POST', '/api/auth/client-credentials', { body: { clientId: machineCredAppWrite.data.clientId, clientSecret: machineCredAppWrite.data.clientSecret } })
  const machineSso = await api('POST', `/api/apps/${ssoAppId}/sso-client`, { token: machineAppWriteLogin.data.token, body: { redirectUris: ['https://evil.example/cb'] } })
  check('机器身份签发被拒（非环回回调须 human owner/管理员）', machineSso.status === 403)
  const machineSsoLoopExternal = await api('POST', `/api/apps/${ssoAppId}/sso-client`, { token: machineAppWriteLogin.data.token, body: { redirectUris: ['http://127.0.0.1:9999/cb'] } })
  check('未绑定机器身份签发环回回调仍被拒 403（须应用自身凭证/登记 owner）', machineSsoLoopExternal.status === 403, JSON.stringify(machineSsoLoopExternal))

  // 机器环回自助正例：应用自身凭证自助签发/改配/轮换（环回回调，owner 无需到控制台代办）
  const selfAppCreate = await api('POST', '/api/apps', { token: ops, body: { name: '环回自助签发应用', attrs: { description: '机器凭证环回自助签发回归', appType: 'web', icon: '🧪', url: 'http://127.0.0.1:5000', riskLevel: 'low', dataClass: 'internal' } } })
  check('注册环回自助签发用应用（自动带机器凭证）', selfAppCreate.ok && selfAppCreate.data.credential.clientId, JSON.stringify(selfAppCreate.error))
  const selfAppCc = await api('POST', '/api/auth/client-credentials', { body: { clientId: selfAppCreate.data.credential.clientId, clientSecret: selfAppCreate.data.credential.clientSecret } })
  const selfAppIssue = await api('POST', `/api/apps/${selfAppCreate.data.app.id}/sso-client`, { token: selfAppCc.data.token, body: { redirectUris: ['http://127.0.0.1:5000/oauth/cb', 'http://0.0.0.0:5000/cb'] } })
  check('应用自身凭证自助签发环回 SSO 客户端 200（127.0.0.1 / 0.0.0.0 放行）', selfAppIssue.ok && selfAppIssue.data.clientId?.startsWith('oc-') && Boolean(selfAppIssue.data.clientSecret), JSON.stringify(selfAppIssue.error))
  const selfAppMachinePatch = await api('PATCH', `/api/apps/${selfAppCreate.data.app.id}/sso-client`, { token: selfAppCc.data.token, body: { redirectUris: ['http://localhost:5000/oauth/cb'] } })
  check('应用自身凭证自助改回调（环回→环回）200', selfAppMachinePatch.ok, JSON.stringify(selfAppMachinePatch.error))
  const selfAppMachineNonLoop = await api('PATCH', `/api/apps/${selfAppCreate.data.app.id}/sso-client`, { token: selfAppCc.data.token, body: { redirectUris: ['https://evil.example/cb'] } })
  check('应用自身凭证改回调为非环回被拒 403', selfAppMachineNonLoop.status === 403, JSON.stringify(selfAppMachineNonLoop))
  const selfAppMachineRotate = await api('POST', `/api/apps/${selfAppCreate.data.app.id}/sso-client/rotate`, { token: selfAppCc.data.token, body: {} })
  check('应用自身凭证轮换环回客户端 secret 200', selfAppMachineRotate.ok && Boolean(selfAppMachineRotate.data.clientSecret), JSON.stringify(selfAppMachineRotate.error))
  const selfAppMachineDisable = await api('POST', `/api/apps/${selfAppCreate.data.app.id}/sso-client/disable`, { token: selfAppCc.data.token, body: { reason: '自助降险（机器恒可禁用）' } })
  check('应用自身凭证禁用客户端 200（disable 纯降险恒放行）', selfAppMachineDisable.ok && selfAppMachineDisable.data.status === 'disabled', JSON.stringify(selfAppMachineDisable))
  const selfAppMachineEnable = await api('POST', `/api/apps/${selfAppCreate.data.app.id}/sso-client/enable`, { token: selfAppCc.data.token, body: {} })
  check('应用自身凭证重新启用环回客户端 200', selfAppMachineEnable.ok && selfAppMachineEnable.data.status === 'active', JSON.stringify(selfAppMachineEnable.error))

  // owner 签发（secret 仅一次）+ 回跳地址护栏
  const issueSso = await api('POST', `/api/apps/${ssoAppId}/sso-client`, { token: ops, body: { redirectUris: ['https://sso-app.example.com/cb'], clientType: 'confidential', consentRequired: false } })
  check('owner 签发 SSO 客户端（secret 一次性返回）', issueSso.ok && issueSso.data.clientId.startsWith('oc-') && issueSso.data.clientSecret.startsWith('ocs'))
  const badUri = await api('PATCH', `/api/apps/${ssoAppId}/sso-client`, { token: ops, body: { redirectUris: ['http://insecure.example/cb'] } })
  check('回跳地址护栏（http 公网域名仍被拒）', !badUri.ok)
  const lanUri = await api('PATCH', `/api/apps/${ssoAppId}/sso-client`, { token: ops, body: { redirectUris: ['http://192.168.0.7:8080', 'http://10.1.2.3/cb', 'http://172.16.5.4/cb', 'http://localhost:3000/cb', 'https://sso-app.example.com/cb'] } })
  check('回跳地址护栏（http 内网 IP / localhost 放行）', lanUri.ok && lanUri.data.redirectUris.includes('http://192.168.0.7:8080'))
  const restoreUri = await api('PATCH', `/api/apps/${ssoAppId}/sso-client`, { token: ops, body: { redirectUris: ['https://sso-app.example.com/cb'] } })
  check('回跳地址恢复 https（后续授权流沿用）', restoreUri.ok)
  const ssoDetail = await api('GET', `/api/apps/${ssoAppId}`, { token: ops })
  check('应用详情返回 sso 块（无 secret 泄露）', ssoDetail.ok && ssoDetail.data.sso?.clientId === issueSso.data.clientId && !JSON.stringify(ssoDetail.data.sso).includes('Secret'))

  // 门禁点 2（兜底）：审批挂单期间禁用客户端 → 审批通过但执行失败留痕
  const onlineReq1 = await api('POST', `/api/apps/${ssoAppId}/transition`, { token: ops, body: { action: 'online' } })
  check('签发后发起上线（审批单快照 ssoClientId）', onlineReq1.ok && onlineReq1.data.approval.payload.ssoClientId === issueSso.data.clientId)
  await api('POST', `/api/apps/${ssoAppId}/sso-client/disable`, { token: ops, body: { reason: '审批期间禁用（执行期复核演练）' } })
  const approveFail = await api('POST', `/api/approvals/${onlineReq1.data.approval.id}/decide`, { token: approver, body: { decision: 'approve', opinion: '应触发执行期复核失败', confirmed: true } })
  const appAfterFail = await api('GET', `/api/apps/${ssoAppId}`, { token: ops })
  check('门禁点2：审批期间禁用 → 上线执行失败留痕', approveFail.ok && approveFail.data.status === 'failed' && String(approveFail.data.execution?.error ?? '').includes('复核') && appAfterFail.data.status !== 'online')

  // 重新启用 → 再次审批 → 上线成功
  await api('POST', `/api/apps/${ssoAppId}/sso-client/enable`, { token: ops })
  const onlineReq2 = await api('POST', `/api/apps/${ssoAppId}/transition`, { token: ops, body: { action: 'online' } })
  await api('POST', `/api/approvals/${onlineReq2.data.approval.id}/decide`, { token: approver, body: { decision: 'approve', opinion: '同意发布', confirmed: true } })
  const appOnlineDetail = await api('GET', `/api/apps/${ssoAppId}`, { token: admin })
  check('复核通过后上线成功', appOnlineDetail.data.status === 'online')
  check('应用拓扑穿透（app→agent→skill）', appOnlineDetail.ok && appOnlineDetail.data.topology.children.length >= 1)
  check('应用成本穿透归集', appOnlineDetail.ok && appOnlineDetail.data.cost.length >= 1)

  // 完整浏览器流（应用客户端）：第一跳 → 用户确认 → 换牌 → userinfo
  const appAuthorizeQuery = new URLSearchParams({
    response_type: 'code', client_id: issueSso.data.clientId, redirect_uri: 'https://sso-app.example.com/cb',
    state: 'st-app-mvp', scope: 'openid profile', code_challenge: pkceChallenge, code_challenge_method: 'S256',
  }).toString()
  const appFirst = await rawReq('GET', `/oauth/authorize?${appAuthorizeQuery}`)
  check('应用客户端授权第一跳 → 平台授权页', appFirst.status === 302 && String(appFirst.headers.location).startsWith('/#/oauth/authorize?req='))
  const appApprove = await authorizeConfirm(ops, reqIdOf(appFirst), true)
  const appTokens = jsonBody(await rawReq('POST', '/oauth/token', {
    headers: { 'content-type': 'application/x-www-form-urlencoded', authorization: `Basic ${Buffer.from(`${issueSso.data.clientId}:${issueSso.data.clientSecret}`).toString('base64')}` },
    body: new URLSearchParams({ grant_type: 'authorization_code', code: new URL(appApprove.result.location).searchParams.get('code'), redirect_uri: 'https://sso-app.example.com/cb', code_verifier: pkceVerifier }).toString(),
  }))
  const appUserInfo = jsonBody(await rawReq('GET', '/oauth/userinfo', { headers: { authorization: `Bearer ${appTokens.access_token}` } }))
  check('应用完整浏览器流（authorize → consent → token → userinfo）', appTokens.access_token?.split('.').length === 3 && appUserInfo.sub === opsLogin.data.user.id && appUserInfo.org !== null)

  // 钉钉身份驱动同一条授权流（授权页登录面板「钉钉扫码」入口对应的端点链）：
  // providers 探测入口显隐 → sso 免密登录换平台会话 → 该会话完成 consent → 换牌 → userinfo 身份一致
  const dingProviders = await api('GET', '/api/auth/providers')
  check('授权页可探测钉钉登录入口（providers 公开回显）', dingProviders.ok && dingProviders.data.providers.some((p) => p.provider === 'dingtalk'))
  const dingAuth = await api('POST', '/api/auth/sso/authorize', { body: { provider: 'dingtalk', scene: 'web_qr' } })
  const dingSso = await api('POST', '/api/auth/sso', { body: { provider: 'dingtalk', code: 'DD0002', state: dingAuth.data.state } })
  check('钉钉身份在授权页登录（sso hit 签发平台会话令牌）', dingSso.ok && dingSso.data.kind === 'hit' && Boolean(dingSso.data.token))
  const dingFirst = await rawReq('GET', `/oauth/authorize?${new URLSearchParams({
    response_type: 'code', client_id: issueSso.data.clientId, redirect_uri: 'https://sso-app.example.com/cb',
    state: 'st-app-ding', scope: 'openid profile', code_challenge: pkceChallenge, code_challenge_method: 'S256',
  }).toString()}`)
  const dingApprove = await authorizeConfirm(dingSso.data.token, reqIdOf(dingFirst), true)
  const dingTokens = jsonBody(await rawReq('POST', '/oauth/token', {
    headers: { 'content-type': 'application/x-www-form-urlencoded', authorization: `Basic ${Buffer.from(`${issueSso.data.clientId}:${issueSso.data.clientSecret}`).toString('base64')}` },
    body: new URLSearchParams({ grant_type: 'authorization_code', code: new URL(dingApprove.result.location).searchParams.get('code'), redirect_uri: 'https://sso-app.example.com/cb', code_verifier: pkceVerifier }).toString(),
  }))
  const dingUserInfo = jsonBody(await rawReq('GET', '/oauth/userinfo', { headers: { authorization: `Bearer ${dingTokens.access_token}` } }))
  check('钉钉身份完整浏览器流（sso 登录 → consent → token → userinfo 身份一致）',
    dingFirst.status === 302 && dingApprove.status === 200 && dingTokens.access_token?.split('.').length === 3
    && dingUserInfo.sub === dingSso.data.user.id && dingUserInfo.preferred_username === dingSso.data.user.username)

  // 平台侧自动折算回归（真实链路汇点）：ticket 兑换（admin）+ OIDC 发码（ops、钉钉用户）→ 应用 DAU/UV 自动落账
  const mvpMetrics = (await api('GET', `/api/apps/${ssoAppId}`, { token: admin })).data.metrics
  check('SSO 到访自动折算（ticket admin + 发码 ops/钉钉 → dau=3 uv=3，同用户重复授权去重）', mvpMetrics.dau === 3 && mvpMetrics.uv === 3, JSON.stringify(mvpMetrics))

  // app.updated 联动：应用改名 → 客户端名称同步
  await api('PATCH', `/api/apps/${ssoAppId}`, { token: ops, body: { name: 'SSO 自测应用 v2' } })
  const clientsAfterRename = await api('GET', '/api/authn/oidc/clients', { token: admin })
  const renamedClient = clientsAfterRename.data.clients.find((c) => c.clientId === issueSso.data.clientId)
  check('应用改名 → OIDC 客户端名称同步（app.updated 联动）', renamedClient?.name === 'SSO 自测应用 v2' && renamedClient.refAppName === 'SSO 自测应用 v2')

  // 轮换：旧 secret 立即失效
  const rotatedApp = await api('POST', `/api/apps/${ssoAppId}/sso-client/rotate`, { token: ops })
  check('owner 轮换 secret（新值一次性返回）', rotatedApp.ok && rotatedApp.data.clientSecret.startsWith('ocs') && rotatedApp.data.clientSecret !== issueSso.data.clientSecret)
  const rotFirst = await rawReq('GET', `/oauth/authorize?${new URLSearchParams({ ...Object.fromEntries(new URLSearchParams(appAuthorizeQuery)), state: 'st-rotate' }).toString()}`)
  const rotApprove = await authorizeConfirm(ops, reqIdOf(rotFirst), true)
  const rotCode = new URL(rotApprove.result.location).searchParams.get('code')
  const oldSecretCall = await rawReq('POST', '/oauth/token', {
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'authorization_code', client_id: issueSso.data.clientId, client_secret: issueSso.data.clientSecret, code: rotCode, redirect_uri: 'https://sso-app.example.com/cb', code_verifier: pkceVerifier }).toString(),
  })
  check('轮换后旧 secret 被拒（401）', oldSecretCall.status === 401)
  const rotFirst2 = await rawReq('GET', `/oauth/authorize?${new URLSearchParams({ ...Object.fromEntries(new URLSearchParams(appAuthorizeQuery)), state: 'st-rotate2' }).toString()}`)
  const rotApprove2 = await authorizeConfirm(ops, reqIdOf(rotFirst2), true)
  const newSecretCall = await rawReq('POST', '/oauth/token', {
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'authorization_code', client_id: issueSso.data.clientId, client_secret: rotatedApp.data.clientSecret, code: new URL(rotApprove2.result.location).searchParams.get('code'), redirect_uri: 'https://sso-app.example.com/cb', code_verifier: pkceVerifier }).toString(),
  })
  check('新 secret 换牌成功', newSecretCall.status === 200)

  // 生命周期联动：下架 → 客户端禁用；恢复上线 → 客户端启用；归档 → 客户端禁用（终态）
  const offlineReq1 = await api('POST', `/api/apps/${ssoAppId}/transition`, { token: ops, body: { action: 'offline', note: '联动演练：下架' } })
  await api('POST', `/api/approvals/${offlineReq1.data.approval.id}/decide`, { token: approver, body: { decision: 'approve', opinion: '同意下架', confirmed: true } })
  const afterOffline = await api('GET', `/api/apps/${ssoAppId}`, { token: ops })
  check('应用下架 → SSO 客户端联动禁用（app.offlined）', afterOffline.data.status === 'offline' && afterOffline.data.sso?.status === 'disabled')
  // 重新上线：下架联动禁用了客户端 → 门禁要求先重新启用（控制台 SSO tab 有警示与入口）
  const reonlineBlocked = await api('POST', `/api/apps/${ssoAppId}/transition`, { token: ops, body: { action: 'online' } })
  check('客户端禁用期间重新上线被门禁拦截', !reonlineBlocked.ok && JSON.stringify(reonlineBlocked.error).includes('SSO'))
  await api('POST', `/api/apps/${ssoAppId}/sso-client/enable`, { token: ops })
  await api('POST', `/api/apps/${ssoAppId}/transition`, { token: ops, body: { action: 'retrial' } })
  const onlineReq3 = await api('POST', `/api/apps/${ssoAppId}/transition`, { token: ops, body: { action: 'online' } })
  await api('POST', `/api/approvals/${onlineReq3.data.approval.id}/decide`, { token: approver, body: { decision: 'approve', opinion: '再次上线', confirmed: true } })
  const afterReline = await api('GET', `/api/apps/${ssoAppId}`, { token: ops })
  check('应用恢复上线 → 客户端联动启用（app.onlined）', afterReline.data.status === 'online' && afterReline.data.sso?.status === 'active')
  const offlineReq2 = await api('POST', `/api/apps/${ssoAppId}/transition`, { token: ops, body: { action: 'offline', note: '归档前下架' } })
  await api('POST', `/api/approvals/${offlineReq2.data.approval.id}/decide`, { token: approver, body: { decision: 'approve', opinion: '同意', confirmed: true } })
  await api('POST', `/api/apps/${ssoAppId}/transition`, { token: ops, body: { action: 'archive' } })
  const afterArchive = await api('GET', `/api/apps/${ssoAppId}`, { token: ops })
  check('应用归档 → 客户端联动禁用（app.archived 终态）', afterArchive.data.status === 'archived' && afterArchive.data.sso?.status === 'disabled')

  // ================================================================ OIDC 会话补全 + 安全闭环（P3）
  section('OIDC 会话补全（refresh 轮转 / end_session / revoke / 密钥轮换）')
  const ocList = await api('GET', '/api/authn/oidc/clients', { token: admin })
  const ocRecord = ocList.data.clients.find((c) => c.clientId === OC.clientId)
  check('OIDC 客户端全局列表（含关联应用与 discovery 元数据）', ocList.ok && Boolean(ocRecord) && ocRecord.discovery.token_endpoint.includes('/oauth/token') && ocList.data.clients.some((c) => c.refAppName === 'SSO 自测应用 v2'))
  await api('PATCH', `/api/authn/oidc/clients/${ocRecord.id}`, { token: admin, body: { postLogoutUris: ['https://crm.partner.example/logged-out'] } })

  // openid-client 联测扩充：refresh 轮转 → 旧值重放整链吊销
  const p3Auth1 = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'p3-refresh' })}`)
  const p3Approve1 = await authorizeConfirm(admin, reqIdOf(p3Auth1), true)
  const p3Tokens1 = await oc.authorizationCodeGrant(ocConfig, new URL(p3Approve1.result.location), { pkceCodeVerifier: pkceVerifier, expectedState: 'p3-refresh' })
  const p3Refreshed = await oc.refreshTokenGrant(ocConfig, p3Tokens1.refresh_token)
  check('openid-client：refresh_token 轮转新令牌对', typeof p3Refreshed.access_token === 'string' && p3Refreshed.refresh_token !== p3Tokens1.refresh_token)
  let replayThrew = ''
  try { await oc.refreshTokenGrant(ocConfig, p3Tokens1.refresh_token) } catch (error) { replayThrew = String(error?.error ?? error?.message ?? error) }
  check('旧 refresh 重放被拒', replayThrew !== '')
  let chainDead = ''
  try { await oc.refreshTokenGrant(ocConfig, p3Refreshed.refresh_token) } catch (error) { chainDead = String(error?.error ?? error?.message ?? error) }
  check('重放触发整链吊销（轮转后的新 refresh 一并失效）', chainDead !== '')

  // scope 只允许收窄
  const p3Auth2 = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'p3-scope', scope: 'openid' })}`)
  const p3Approve2 = await authorizeConfirm(admin, reqIdOf(p3Auth2), true)
  const p3Tokens2 = await oc.authorizationCodeGrant(ocConfig, new URL(p3Approve2.result.location), { pkceCodeVerifier: pkceVerifier, expectedState: 'p3-scope' })
  const widen = await rawReq('POST', '/oauth/token', {
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'refresh_token', client_id: OC.clientId, client_secret: OC.clientSecret, refresh_token: p3Tokens2.refresh_token, scope: 'openid profile email' }).toString(),
  })
  check('refresh 扩大 scope 被拒（只允许收窄）', widen.status === 400 && jsonBody(widen).error === 'invalid_scope')

  // 冻结 → refresh 换发即时失效（安全必需：不等过期）
  const freezeUser = await api('POST', '/api/iam/users', { token: admin, body: { username: 'ssofreeze01', displayName: 'OIDC 冻结联动', orgId: newOrg.data.id } })
  const freezeLogin = await api('POST', '/api/auth/login', { body: { username: 'ssofreeze01', password: freezeUser.data.initialPassword } })
  const fzAuth = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'p3-frozen' })}`)
  const fzApprove = await authorizeConfirm(freezeLogin.data.token, reqIdOf(fzAuth), true)
  const fzTokens = await oc.authorizationCodeGrant(ocConfig, new URL(fzApprove.result.location), { pkceCodeVerifier: pkceVerifier, expectedState: 'p3-frozen' })
  await api('POST', `/api/iam/users/${freezeUser.data.id}/freeze`, { token: admin, body: { reason: 'refresh 联动吊销验证' } })
  let frozenRefresh = ''
  try { await oc.refreshTokenGrant(ocConfig, fzTokens.refresh_token) } catch (error) { frozenRefresh = String(error?.error ?? error?.message ?? error) }
  check('账号冻结 → refresh 换发被拒（实时校验用户状态）', frozenRefresh !== '')

  // end_session：合法/非法回跳 + refresh 链吊销
  const esAuth = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'p3-endsession' })}`)
  const esApprove = await authorizeConfirm(admin, reqIdOf(esAuth), true)
  const esTokens = await oc.authorizationCodeGrant(ocConfig, new URL(esApprove.result.location), { pkceCodeVerifier: pkceVerifier, expectedState: 'p3-endsession' })
  const esUrl = oc.buildEndSessionUrl(ocConfig, { id_token_hint: esTokens.id_token, post_logout_redirect_uri: 'https://crm.partner.example/logged-out', state: 'logout-st' })
  const esOk = await rawReq('GET', esUrl.pathname + esUrl.search)
  check('end_session 合法回跳 → 302 平台登出中转页', esOk.status === 302 && String(esOk.headers.location).startsWith('/#/oauth/logout') && String(esOk.headers.location).includes('logged-out'))
  let esChainDead = ''
  try { await oc.refreshTokenGrant(ocConfig, esTokens.refresh_token) } catch (error) { esChainDead = String(error?.error ?? error?.message ?? error) }
  check('end_session 同时吊销 refresh 链（登出后不能静默续期）', esChainDead !== '')
  const esBad = await rawReq('GET', `/oauth/end_session?${new URLSearchParams({ id_token_hint: esTokens.id_token, post_logout_redirect_uri: 'https://evil.example/x' }).toString()}`)
  check('end_session 非法回跳 → 平台错误页（不开放重定向）', esBad.status === 302 && String(esBad.headers.location).startsWith('/#/oauth/error'))
  // 登出回退：RP 未显式携带 post_logout_redirect_uri（如纯前端门户只传 id_token_hint）
  const esBare = await rawReq('GET', `/oauth/end_session?${new URLSearchParams({ id_token_hint: esTokens.id_token }).toString()}`)
  check('end_session 未带回跳参数 → 按唯一登记登出地址回跳（门户登出场景兜底）',
    esBare.status === 302 && String(esBare.headers.location).startsWith('/#/oauth/logout') && String(esBare.headers.location).includes('logged-out'))
  await api('PATCH', `/api/authn/oidc/clients/${ocRecord.id}`, { token: admin, body: { postLogoutUris: ['https://crm.partner.example/logged-out', 'https://crm.partner.example/other'] } })
  const esAmbiguous = await rawReq('GET', `/oauth/end_session?${new URLSearchParams({ id_token_hint: esTokens.id_token }).toString()}`)
  const esAmbiguousLoc = String(esAmbiguous.headers.location)
  check('end_session 未带参数且登记多个登出地址 → 不猜测回跳，停留平台登出页',
    esAmbiguous.status === 302 && esAmbiguousLoc.startsWith('/#/oauth/logout') && !esAmbiguousLoc.includes('post_logout_redirect_uri'))
  await api('PATCH', `/api/authn/oidc/clients/${ocRecord.id}`, { token: admin, body: { postLogoutUris: ['https://crm.partner.example/logged-out'] } })

  // revoke（RFC 7009）：access jti 黑名单 + refresh 链
  const rvAuth = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'p3-revoke' })}`)
  const rvApprove = await authorizeConfirm(admin, reqIdOf(rvAuth), true)
  const rvTokens = await oc.authorizationCodeGrant(ocConfig, new URL(rvApprove.result.location), { pkceCodeVerifier: pkceVerifier, expectedState: 'p3-revoke' })
  await oc.tokenRevocation(ocConfig, rvTokens.access_token)
  const revokedInfo = await rawReq('GET', '/oauth/userinfo', { headers: { authorization: `Bearer ${rvTokens.access_token}` } })
  check('revoke access token → userinfo 即时 401', revokedInfo.status === 401)
  await oc.tokenRevocation(ocConfig, rvTokens.refresh_token)
  let revokedRefresh = ''
  try { await oc.refreshTokenGrant(ocConfig, rvTokens.refresh_token) } catch (error) { revokedRefresh = String(error?.error ?? error?.message ?? error) }
  check('revoke refresh token → 换发被拒', revokedRefresh !== '')

  // JWKS 密钥轮换：旧 token 宽限内验签通过、新 token kid 切换、JWKS 双 key
  const krAuth = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'p3-rotate' })}`)
  const krApprove = await authorizeConfirm(admin, reqIdOf(krAuth), true)
  const krTokensOld = await oc.authorizationCodeGrant(ocConfig, new URL(krApprove.result.location), { pkceCodeVerifier: pkceVerifier, expectedState: 'p3-rotate' })
  const keysRotated = await api('POST', '/api/authn/oidc/keys/rotate', { token: admin })
  const oldKid = JSON.parse(Buffer.from(krTokensOld.access_token.split('.')[0], 'base64url').toString('utf8')).kid
  check('密钥轮换执行（新 kid + 24h 宽限）', keysRotated.ok && keysRotated.data.kid !== oldKid && keysRotated.data.graceHours === 24)
  const graceInfo = await rawReq('GET', '/oauth/userinfo', { headers: { authorization: `Bearer ${krTokensOld.access_token}` } })
  check('轮换后旧 token 宽限内仍可验签（在途不掉线）', graceInfo.status === 200)
  const krAuth2 = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ state: 'p3-rotate2' })}`)
  const krApprove2 = await authorizeConfirm(admin, reqIdOf(krAuth2), true)
  const krTokensNew = await oc.authorizationCodeGrant(ocConfig, new URL(krApprove2.result.location), { pkceCodeVerifier: pkceVerifier, expectedState: 'p3-rotate2' })
  const newKid = JSON.parse(Buffer.from(krTokensNew.access_token.split('.')[0], 'base64url').toString('utf8')).kid
  check('新令牌切换到新 kid 签名', newKid === keysRotated.data.kid && newKid !== oldKid)
  const jwksAfterRotate = jsonBody(await rawReq('GET', '/.well-known/jwks.json'))
  check('JWKS 宽限期公布双公钥（旧 key 保留验签）', jwksAfterRotate.keys.length === 2 && jwksAfterRotate.keys.some((k) => k.kid === oldKid) && jwksAfterRotate.keys.some((k) => k.kid === newKid))

  // public 客户端（D-a 决策）：免 secret + 强制 PKCE + 不签发 refresh（纯前端 SPA 形态）
  const publicClient = await api('POST', '/api/authn/oidc/clients', { token: admin, body: { name: '纯前端 SPA（public）', redirectUris: ['http://localhost:5173/cb'], clientType: 'public' } })
  check('登记 public 客户端（无 secret 返回）', publicClient.ok && !publicClient.data.clientSecret && publicClient.data.note.includes('public'))
  const pubAuth = await rawReq('GET', `/oauth/authorize?${authorizeQuery({ client_id: publicClient.data.clientId, redirect_uri: 'http://localhost:5173/cb', state: 'p3-public' })}`)
  const pubApprove = await authorizeConfirm(admin, reqIdOf(pubAuth), true)
  const pubTokens = jsonBody(await rawReq('POST', '/oauth/token', {
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'authorization_code', client_id: publicClient.data.clientId, code: new URL(pubApprove.result.location).searchParams.get('code'), redirect_uri: 'http://localhost:5173/cb', code_verifier: pkceVerifier }).toString(),
  }))
  check('public 客户端免 secret 换牌成功且不签发 refresh', pubTokens.access_token?.split('.').length === 3 && pubTokens.refresh_token === undefined)

  // 授权事件审计留痕（按 resourceType 过滤：断言只关心两类事件是否落账，不随全量日志体量漂移）
  const oidcAudit = await api('GET', '/api/audit/logs?resourceType=oidc_client&limit=50', { token: admin })
  check('授权事件审计留痕（granted / denied）', oidcAudit.ok && oidcAudit.data.items.some((log) => log.action === 'oidc.authorize.granted') && oidcAudit.data.items.some((log) => log.action === 'oidc.authorize.denied'))

  // ================================================================ 审计
  section('审计与告警与成本')
  const logsAll = await api('GET', '/api/audit/logs?limit=200', { token: admin })
  const types = new Set(logsAll.data.items.map((log) => log.type))
  check('四类审计日志齐全', ['auth', 'authz', 'invoke', 'change'].every((type) => types.has(type)))
  check('越权拒绝已留痕（authz denied）', logsAll.data.items.some((log) => log.type === 'authz' && log.result === 'denied'))

  const logsFilter = await api('GET', '/api/audit/logs?type=invoke&result=ok&limit=5', { token: admin })
  check('审计筛选（类型+结果）', logsFilter.ok && logsFilter.data.items.every((log) => log.type === 'invoke'))

  const costApp = await api('GET', '/api/audit/cost?groupBy=app', { token: admin })
  check('成本按应用穿透', costApp.ok && costApp.data.rows.length >= 1)
  const costOrg = await api('GET', '/api/audit/cost?groupBy=org', { token: admin })
  check('成本按组织穿透', costOrg.ok && costOrg.data.rows.length >= 1)

  const ruleCreate = await api('POST', '/api/audit/alert-rules', { token: admin, body: { name: '自测规则', metric: 'permission_denied', threshold: 2, severity: 'critical' } })
  check('创建告警规则', ruleCreate.ok)

  // 告警已读体系：单条已读 → 一键全部已读 → 未读清零（403 探测放最后，避免中途触发新告警干扰计数）
  const alertsBefore = await api('GET', '/api/audit/alerts', { token: admin })
  const unreadBefore = alertsBefore.data.alerts.filter((a) => !a.read)
  check('告警中心存在未读告警（前置）', alertsBefore.ok && unreadBefore.length >= 1)
  const oneRead = await api('POST', `/api/audit/alerts/${unreadBefore[0].id}/read`, { token: admin })
  check('单条告警标记已读', oneRead.ok && oneRead.data.read === true)
  const readAll = await api('POST', '/api/audit/alerts/read-all', { token: admin })
  const alertsAfter = await api('GET', '/api/audit/alerts?unread=1', { token: admin })
  check('一键全部已读（返回条数 = 剩余未读，且未读清零）', readAll.ok && readAll.data.read === unreadBefore.length - 1 && alertsAfter.data.alerts.length === 0)
  const readAllAgain = await api('POST', '/api/audit/alerts/read-all', { token: admin })
  check('重复一键已读幂等（返回 0）', readAllAgain.ok && readAllAgain.data.read === 0)
  const toolReadAll = await api('POST', '/api/tools/execute', { token: admin, body: { name: 'audit_alerts_read_all', args: {} } })
  check('工具桥一键已读（audit_alerts_read_all）', toolReadAll.ok && toolReadAll.data.isError === false)
  const readAllDenied = await api('POST', '/api/audit/alerts/read-all', { token: dev })
  check('无 audit.read 权限不可一键已读（403）', readAllDenied.status === 403)

  // ================================================================ 工具桥（dsh 工具契约）
  section('工具桥（模型可用工具）')
  const toolList = await api('GET', '/api/platform/info', { token: admin })
  check('工具目录 ≥ 37 个', toolList.data.tools.length >= 37)
  const toolExec = await api('POST', '/api/tools/execute', { token: admin, body: { name: 'iam_org_tree', args: {} } })
  check('工具执行（iam_org_tree）', toolExec.ok && toolExec.data.isError === false && JSON.stringify(toolExec.data.value).includes('元冰可集团'))
  const toolAgentList = await api('POST', '/api/tools/execute', { token: admin, body: { name: 'agent_list', args: { status: 'online' } } })
  check('工具执行（agent_list 过滤）', toolAgentList.ok && toolAgentList.data.value.total >= 5)

  // ================================================================ 平台自更新（版本检查 / 权限 / dry-run / 审计联动）
  section('平台自更新（plugin-update）')
  check('更新工具已注册（update_status 等）', toolList.data.tools.some((t) => t.name === 'update_status' && t.permission === 'platform.update.read'))

  const updStatus0 = await api('GET', '/api/update/status', { token: admin })
  check('更新状态可读（版本取自根 package.json=1.1.0）', updStatus0.ok && updStatus0.data.currentVersion === '1.1.0')
  check('安装形态识别为 source（git 检出）', updStatus0.data.installMode === 'source')
  check('环境变量关闭自动检查生效（DSH_UPDATE_AUTO_CHECK=off）', updStatus0.data.autoCheck === false)
  check('未检查时无最新版本快照', updStatus0.data.latest === null)

  const updAnon = await api('GET', '/api/update/status')
  check('匿名访问更新状态被拒（401）', updAnon.status === 401)

  const updCheck1 = await api('POST', '/api/update/check', { token: admin })
  check('手动检查成功（stub 上游）', updCheck1.ok && updCheck1.data.latest?.version === '9.9.9')
  check('发现新版本（1.1.0 → 9.9.9）', updCheck1.data.hasUpdate === true && updCheck1.data.updateKind === 'version')
  check('提交对比生效（落后 2 个提交）', updCheck1.data.behindBy === 2 && updCheck1.data.recentCommits.length === 2 && updCheck1.data.recentCommits[0].sha === 'a222222')

  const updCheck2 = await api('POST', '/api/update/check', { token: admin })
  check('手动检查 60 秒冷却（429）', updCheck2.status === 429)

  const updEvents = await api('GET', '/api/platform/info', { token: admin })
  check('已广播 platform.update.available 事件', updEvents.data.events.some((e) => e.name === 'platform.update.available'))
  const updAudit = await api('GET', '/api/audit/logs?q=platform.update.available&limit=10', { token: admin })
  check('audit 联动留痕（platform.update.available）', (updAudit.data?.items ?? []).some((l) => l.action === 'platform.update.available'))

  const hrForUpdate = await api('POST', '/api/auth/login', { body: { username: 'hr', password: 'Ybk@2026' } })
  const hrToken2 = hrForUpdate.data?.token
  const updApplyDenied = await api('POST', '/api/update/apply', { token: hrToken2, body: { reason: '越权尝试' } })
  check('无权限用户执行升级被拒（403）', updApplyDenied.status === 403)

  const updDry = await api('POST', '/api/update/apply', { token: admin, body: { dryRun: true } })
  check('dry-run 预演返回步骤且不执行任何变更', updDry.ok && updDry.data.dryRun === true && Array.isArray(updDry.data.steps) && updDry.data.steps.length === 3)
  check('dry-run 附带待拉取提交清单', Array.isArray(updDry.data.incomingCommits) && updDry.data.incomingCommits.length === 2)

  const updApplyNoReason = await api('POST', '/api/update/apply', { token: admin, body: {} })
  check('正式升级缺少原因被拒（400）', updApplyNoReason.status === 400)
  // OPT-P2-03：pin 强制 + 回滚面（均在触碰 git 前即拒绝，测试零副作用、零外网依赖）
  const updNoPin = await api('POST', '/api/update/apply', { token: admin, body: { reason: '未带 pin 的裸拉尝试' } })
  const updNoPinMsg = String(updNoPin.error?.message ?? JSON.stringify(updNoPin.error ?? updNoPin.data ?? {}))
  check('P2-03 正式升级缺 pin 被拒（禁止裸拉最新）', updNoPin.status === 400 && /pin/i.test(updNoPinMsg), updNoPinMsg.slice(0, 160))
  const updRollbackNoSnap = await api('POST', '/api/update/rollback', { token: admin, body: { reason: '无快照回滚演练' } })
  const updRollbackMsg = String(updRollbackNoSnap.error?.message ?? JSON.stringify(updRollbackNoSnap.error ?? updRollbackNoSnap.data ?? {}))
  check('P2-03 无可回滚快照被拒（本进程未执行过 apply）', updRollbackNoSnap.status === 400 && /快照/.test(updRollbackMsg), updRollbackMsg.slice(0, 160))
  const updDryPin = await api('POST', '/api/update/apply', { token: admin, body: { dryRun: true } })
  check('P2-03 dryRun 透出 pin/签名策略口径', updDryPin.ok && updDryPin.data.requireSignedCommits === false && String(updDryPin.data.pin).includes('pin'), JSON.stringify(updDryPin.data ?? {}).slice(0, 220))

  const updDismiss = await api('POST', '/api/update/settings', { token: admin, body: { dismissedVersion: '9.9.9' } })
  check('忽略指定版本（横幅静默）', updDismiss.ok && updDismiss.data.dismissed === true)
  const updRestore = await api('POST', '/api/update/settings', { token: admin, body: { dismissedVersion: null } })
  check('恢复更新提醒', updRestore.ok && updRestore.data.dismissed === false)
  const updAutoOn = await api('POST', '/api/update/settings', { token: admin, body: { autoCheck: true, intervalHours: 24 } })
  check('开启自动检查（每 24h）', updAutoOn.ok && updAutoOn.data.autoCheck === true && updAutoOn.data.intervalHours === 24)

  const updTool = await api('POST', '/api/tools/execute', { token: admin, body: { name: 'update_status', args: {} } })
  check('Agent 工具 update_status 可用', updTool.ok && updTool.data.isError === false && updTool.data.value.currentVersion === '1.1.0')
  const updToolApply = await api('POST', '/api/tools/execute', { token: hrToken2, body: { name: 'update_apply', args: { reason: '越权尝试' } } })
  check('工具级权限拦截 update_apply（403）', updToolApply.status === 403)

  // T5（M2）：发布清单签名验签——CLI 工具 e2e + 平台侧 verifyReleaseManifest 进程内最小装配 + settings 防呆
  section('T5 发布清单验签（供应链校验：Ed25519 复用平台签名基建）')
  {
    const t5Keys = platformCore.generateEd25519KeyPair()
    const badKeyReg = await api('POST', '/api/update/settings', { token: admin, body: { releasePublicKey: 'not-a-valid-key' } })
    check('T5 公钥登记格式校验（非法内容登记即拒 400，不拖到升级时才炸）', badKeyReg.status === 400, JSON.stringify(badKeyReg.error))
    const forceNoKey = await api('POST', '/api/update/settings', { token: admin, body: { requireSignedManifests: true } })
    check('T5 未登记公钥开启强制验签被拒（防呆：开启即拒绝一切升级）', forceNoKey.status === 400, JSON.stringify(forceNoKey.error))
    const keyReg = await api('POST', '/api/update/settings', { token: admin, body: { releasePublicKey: t5Keys.publicKeyBase64 } })
    check('T5 公钥登记成功（status.releaseKeyConfigured=true）', keyReg.ok && keyReg.data.releaseKeyConfigured === true, JSON.stringify(keyReg.error ?? keyReg.data))
    const forceOn = await api('POST', '/api/update/settings', { token: admin, body: { requireSignedManifests: true } })
    check('T5 公钥在场后可开启强制验签（再关闭回落告警放行口径）', forceOn.ok && forceOn.data.requireSignedManifests === true, JSON.stringify(forceOn.error))
    const forceOff = await api('POST', '/api/update/settings', { token: admin, body: { requireSignedManifests: false } })
    check('T5 强制验签可关闭（默认告警放行，显式增强非静默降级）', forceOff.ok && forceOff.data.requireSignedManifests === false)

    // 进程内最小装配（startHttp=false + 独立 dataDir）：直连 verifyReleaseManifest 验证判定路径。
    // 每个 UpdateService 独立 Context（cordis 同一 ctx 二次 provide 同名服务即抛错）
    let t5Seq = 0
    const mkT5Service = async (options = {}, publicKey) => {
      const c = new Context()
      await c.plugin(platformCore, { dataDir: join(DATA_DIR, `t5-verify-${++t5Seq}`), startHttp: false })
      update.ensureUpdateState(c, { autoCheck: false, intervalHours: 0 })
      if (publicKey !== undefined) update.updateStateCollection(c).update('singleton', { releasePublicKey: publicKey })
      return new update.UpdateService(c, { autoCheck: false, ...options })
    }
    const unset = await (await mkT5Service()).verifyReleaseManifest('a'.repeat(40))
    check('T5 未登记公钥：checked=false 显式报未启用（不算失败，不静默）', unset.checked === false && /未登记/.test(unset.note), JSON.stringify(unset))
    // 本地 stub rawBase：返回正确签名清单；另以篡改 commit / 伪造公钥覆盖失败路径
    const goodCommit = 'b'.repeat(40)
    const mkStub = (payload) => createServer((req, res) => { res.setHeader('content-type', 'application/json'); res.end(JSON.stringify(payload)) })
    const signed = (commit, pem) => platformCore.signEd25519(pem, commit)
    const stubGood = mkStub({ algorithm: 'ed25519', version: '9.9.9', commit: goodCommit, signedAt: new Date().toISOString(), signature: signed(goodCommit, t5Keys.privateKeyPem) })
    await new Promise((resolve) => stubGood.listen(0, '127.0.0.1', resolve))
    const goodBase = `http://127.0.0.1:${stubGood.address().port}`
    const svcGood = await mkT5Service({ rawBase: goodBase, apiBase: goodBase }, t5Keys.publicKeyBase64)
    const good = await svcGood.verifyReleaseManifest(goodCommit)
    check('T5 正确签名清单验签通过（verified=true）', good.checked === true && good.verified === true, JSON.stringify(good))
    const wrongTarget = await svcGood.verifyReleaseManifest('c'.repeat(40))
    check('T5 清单 commit 与升级目标不一致判失败（verified=false）', wrongTarget.checked === true && wrongTarget.verified === false && /不一致/.test(wrongTarget.note), JSON.stringify(wrongTarget))
    const t5ForgedKeys = platformCore.generateEd25519KeyPair()
    const svcForged = await mkT5Service({ rawBase: goodBase, apiBase: goodBase }, t5ForgedKeys.publicKeyBase64)
    const forged = await svcForged.verifyReleaseManifest(goodCommit)
    check('T5 伪造清单验签失败（签名与登记公钥不匹配）', forged.checked === true && forged.verified === false, JSON.stringify(forged))
    stubGood.close()
    // CLI 工具 e2e：生成密钥 → 生成清单 → 校验通过 → 篡改 commit 校验失败
    const { execFileSync } = await import('node:child_process')
    const { mkdtempSync } = await import('node:fs')
    const { tmpdir } = await import('node:os')
    const t5tmp = mkdtempSync(join(tmpdir(), 't5cli-'))
    const keyPath = join(t5tmp, 'relkey.pem')
    const genOut = execFileSync(process.execPath, ['scripts/release-manifest.mjs', '--generate-key', '--key-file', keyPath], { cwd: process.cwd(), encoding: 'utf8' })
    const pubFromGen = /MCow[A-Za-z0-9+/=]+/.exec(genOut)?.[0] ?? ''
    const manifestPath = join(t5tmp, 'release-manifest.json')
    const t5Commit = 'd'.repeat(40)
    execFileSync(process.execPath, ['scripts/release-manifest.mjs', '--key-file', keyPath, '--out', manifestPath, '--commit', t5Commit], { cwd: process.cwd(), encoding: 'utf8' })
    const checkOk = execFileSync(process.execPath, ['scripts/release-manifest.mjs', '--check', '--out', manifestPath, '--pubkey', pubFromGen, '--commit', t5Commit], { cwd: process.cwd(), encoding: 'utf8' })
    check('T5 CLI 发布工具 e2e（生成密钥 → 签清单 → 校验通过）', /校验通过/.test(String(checkOk)) && pubFromGen.length > 20, genOut.slice(0, 120))
    let tamperFailed = false
    try {
      execFileSync(process.execPath, ['scripts/release-manifest.mjs', '--check', '--out', manifestPath, '--pubkey', pubFromGen, '--commit', 'e'.repeat(40)], { cwd: process.cwd(), encoding: 'utf8' })
    } catch { tamperFailed = true }
    check('T5 CLI 篡改检测（commit 不一致校验拒绝，exit≠0）', tamperFailed)
  }

  // ================================================================ 远程 dsh 接入（接入码 → 机器凭证 → 工具代理）
  section('远程 dsh 接入（plugin-connect）')
  check('接入管理工具已注册（connect_code_create 等）', toolList.data.tools.some((t) => t.name === 'connect_code_create' && t.permission === 'connect.manage'))

  // 管理端权限边界：无 connect.manage 的角色被拒
  const opsCodes = await api('GET', '/api/connect/codes', { token: ops })
  check('无 connect.manage 权限创建/查看接入码被拒（403）', opsCodes.status === 403)

  // 创建接入码（operator 模板）—— 接入码仅创建响应中出现一次
  const codeCreated = await api('POST', '/api/connect/codes', { token: admin, body: { template: 'operator', ttlMinutes: 10, remark: 'selftest' } })
  check('创建接入码（operator，一次性展示）', codeCreated.ok && codeCreated.data.code.startsWith('enr_') && codeCreated.data.ttlMinutes === 10)
  const codesListed = await api('GET', '/api/connect/codes', { token: admin })
  check('接入码列表只含掩码不含明文', codesListed.ok && !JSON.stringify(codesListed.data).includes(codeCreated.data.code) && codesListed.data.codes.some((c) => c.codeMask && c.status === 'active'))

  // 伪造/错误接入码被拒（401）
  const badEnroll = await api('POST', '/api/connect/enroll', { body: { enrollmentCode: 'enr_forged'.padEnd(40, 'x'), clientName: 'attacker' } })
  check('伪造接入码 enroll 被拒', badEnroll.status === 401)

  // 真实 enroll：换机器凭证
  const enroll = await api('POST', '/api/connect/enroll', { body: { enrollmentCode: codeCreated.data.code, clientName: 'selftest-remote-dsh', meta: { hostname: 'selftest-pc', platform: 'test' } } })
  check('接入码换机器凭证成功', enroll.ok && enroll.data.clientId.startsWith('mc-') && enroll.data.clientSecret.startsWith('cs_') && enroll.data.template === 'operator')

  // 一次性消费：重放被拒
  const enrollReplay = await api('POST', '/api/connect/enroll', { body: { enrollmentCode: codeCreated.data.code, clientName: 'replay' } })
  check('接入码一次性消费（重放被拒）', enrollReplay.status === 401)

  // 机器凭证 → 机器令牌 → REST 读权限
  const ccLogin = await api('POST', '/api/auth/client-credentials', { body: { clientId: enroll.data.clientId, clientSecret: enroll.data.clientSecret } })
  check('机器凭证换取机器令牌', ccLogin.ok && ccLogin.data.token.startsWith('dst1.'))
  const machineToken = ccLogin.data.token
  const machineOverview = await api('GET', '/api/overview', { token: machineToken })
  check('机器令牌可读平台概览（operator 含读权限）', machineOverview.ok)
  const machineOrgCreate = await api('POST', '/api/iam/orgs', { token: machineToken, body: { name: '越权组织' } })
  check('operator 模板无 iam.org.write（越权被拒 403）', machineOrgCreate.status === 403)

  // 机器令牌走工具桥（远程工具代理的同一条宿主路径）
  const machineTool = await api('POST', '/api/tools/execute', { token: machineToken, body: { name: 'agent_list', args: {} } })
  check('机器令牌经工具桥执行 agent_list', machineTool.ok && machineTool.data.isError === false && machineTool.data.value.total >= 5)

  // 客户端心跳主动推送（宿主侧接入资产存活监测）
  const hb = await api('POST', '/api/connect/heartbeat', { token: machineToken, body: { tools: 42, version: 'v22.14.0', uptimeSec: 600 } })
  check('接入客户端心跳上报成功', hb.ok && hb.data.clientId === enroll.data.clientId)
  const hbAdmin = await api('POST', '/api/connect/heartbeat', { token: admin, body: {} })
  check('非接入客户端身份心跳被拒（404）', hbAdmin.status === 404)
  const hbAnon = await api('POST', '/api/connect/heartbeat', { body: {} })
  check('心跳端点强制 Bearer 鉴权（401）', hbAnon.status === 401)

  // 客户端登记与最近使用
  const clientsListed = await api('GET', '/api/connect/clients', { token: admin })
  const enrolled = clientsListed.data.clients.find((c) => c.clientId === enroll.data.clientId)
  check('已接入客户端登记（模板/主机名/最近使用）', clientsListed.ok && enrolled && enrolled.template === 'operator' && enrolled.hostname === 'selftest-pc' && enrolled.lastUsedAt !== '')
  check('宿主侧可见客户端心跳与元信息', enrolled.lastHeartbeatAt !== '' && enrolled.heartbeat?.tools === 42 && enrolled.heartbeat?.uptimeSec === 600)

  // 禁用客户端 → 令牌即时失效（principal disabled 联动）
  const disableClient = await api('POST', `/api/connect/clients/${enroll.data.clientId}/disable`, { token: admin, body: { reason: 'selftest 验证吊销联动' } })
  check('禁用接入客户端（原因必填留痕）', disableClient.ok && disableClient.data.status === 'disabled')
  const ccAfterDisable = await api('POST', '/api/auth/client-credentials', { body: { clientId: enroll.data.clientId, clientSecret: enroll.data.clientSecret } })
  const machineAfterDisable = await api('GET', '/api/overview', { token: machineToken })
  check('禁用后凭证换牌被拒、旧机器令牌即时失效', ccAfterDisable.status === 401 && machineAfterDisable.status === 401)

  // 作废未使用接入码
  const code2 = await api('POST', '/api/connect/codes', { token: admin, body: { template: 'readonly', ttlMinutes: 5 } })
  const revokeCode = await api('DELETE', `/api/connect/codes/${code2.data.id}`, { token: admin })
  const enrollRevoked = await api('POST', '/api/connect/enroll', { body: { enrollmentCode: code2.data.code, clientName: 'late' } })
  check('作废未使用接入码后 enroll 被拒', revokeCode.ok && enrollRevoked.status === 401)

  // 工具级 connect 管理工具（宿主侧 dsh Agent 用自然语言管理接入）
  const toolCodeCreate = await api('POST', '/api/tools/execute', { token: admin, body: { name: 'connect_code_create', args: { template: 'readonly', ttlMinutes: 5 } } })
  check('工具 connect_code_create 签发接入码', toolCodeCreate.ok && toolCodeCreate.data.isError === false && toolCodeCreate.data.value.code.startsWith('enr_'))

  // ================================================================ NAS 资产（FS 文件存储）
  section('NAS 数据权限引擎（纯函数单测 engine.ts，dev-plan-nas-authz §四）')
  {
    const eo = [
      { id: 'eo1', name: '智造平台', parentId: null, leaderUserIds: ['e_p', 'e_p2'] },
      { id: 'eo2', name: '生产部', parentId: 'eo1', leaderUserIds: ['e_d'] },
      { id: 'eo3', name: '总装12线', parentId: 'eo2', leaderUserIds: ['e_t'] },
      { id: 'eo4', name: '质检线', parentId: 'eo2', leaderUserIds: [] },
      { id: 'eo5', name: '品质部', parentId: 'eo1', leaderUserIds: ['e_x', 'e_y'] },
      { id: 'eo6', name: '外贸平台', parentId: null, leaderUserIds: [] },
      { id: 'eo7', name: '外贸一部', parentId: 'eo6', leaderUserIds: [] },
    ]
    const idx = buildOrgIndex(eo)
    const nas1 = { id: 'en1', rootPath: '/', orgRoot: '智造平台' }
    const now = '2026-08-29T00:00:00Z'
    const baseRules = { version: 1, exceptions: [], cGroups: ['eg_c'], externalReadPaths: [{ nasId: 'en1', path: '/外部白名单' }], observeOnly: true, degradeAllToReadonly: false }
    const u = (id, orgId, extra = {}) => ({ id, displayName: id, orgId, ...extra })
    const run = (user, paths, op, opt = {}) => engineCheck(
      { userId: user.id, nasId: opt.nasId ?? 'en1', paths, op, now, ...(opt.override !== undefined ? { override: opt.override } : {}) },
      { orgIndex: idx, user, nas: opt.nas ?? nas1, rules: opt.rules ?? baseRules, cGroupHits: opt.cGroupHits ?? [], ...(opt.ownedPaths ? { ownedPaths: opt.ownedPaths } : {}) },
    )
    const inScope = '/智造平台/生产部/总装12线/a.txt'

    // 角色推导
    check('推导：平台负责人 → P', deriveRole(u('e_p', 'eo1'), idx).role === 'P')
    check('推导：部门负责人 → D', deriveRole(u('e_d', 'eo2'), idx).role === 'D')
    check('推导：班组负责人 → T', deriveRole(u('e_t', 'eo3'), idx).role === 'T')
    check('推导：班组成员 → M', deriveRole(u('e_m', 'eo3'), idx).role === 'M')
    check('多负责人 co-leader：双负责人均得 P 且 reasons 标注',
      deriveRole(u('e_p2', 'eo1'), idx).role === 'P'
      && run(u('e_p2', 'eo1'), [inScope], 'read').reasons.some((r) => r.includes('co-leader')))
    check('挂根组织非负责人 → 全 deny', run(u('e_root', 'eo1'), ['/智造平台/x'], 'read').decision === 'deny'
      && run(u('e_root', 'eo1'), ['/智造平台/x'], 'read').reasons.some((r) => r.includes('root-no-role')))
    check('挂根组织 + 管理员显式 allow 例外 → 例外救援放行（平台服务账号存储区授权），例外路径外/未授权 op 仍 deny',
      (() => {
        const rules = { ...baseRules, observeOnly: false, exceptions: [{ id: 'exc_rescue', effect: 'allow', nasId: 'en1', path: '/智造平台/服务区', ops: ['read', 'write'], userIds: ['e_root'], note: '平台服务账号存储区' }] }
        return run(u('e_root', 'eo1'), ['/智造平台/服务区/pkg.zip'], 'write', { rules }).decision === 'allow'
          && run(u('e_root', 'eo1'), ['/智造平台/服务区/pkg.zip'], 'read', { rules }).decision === 'allow'
          && run(u('e_root', 'eo1'), ['/智造平台/服务区/pkg.zip'], 'delete', { rules }).decision === 'deny'
          && run(u('e_root', 'eo1'), ['/智造平台/其他/pkg.zip'], 'write', { rules }).decision === 'deny'
      })())
    check('未落班组（部门根非负责人）→ 只读', run(u('e_d2', 'eo2'), ['/智造平台/生产部/x'], 'read').decision === 'allow'
      && run(u('e_d2', 'eo2'), ['/智造平台/生产部/x'], 'write').decision === 'deny')
    check('兼任：主归属正常写 + 兼任子树仅只读',
      run(u('e_m2', 'eo4', { primaryOrgId: 'eo3' }), [inScope], 'write').decision === 'allow'
      && run(u('e_m2', 'eo4', { primaryOrgId: 'eo3' }), ['/智造平台/生产部/质检线/a.txt'], 'write').decision === 'deny'
      && run(u('e_m2', 'eo4', { primaryOrgId: 'eo3' }), ['/智造平台/生产部/质检线/a.txt'], 'read').decision === 'allow')
    check('作用域锚对齐：部门负责人主部门挂在下属班组，作用域提升到所领导部门（角色与作用域一致）',
      run(u('e_d', 'eo3'), ['/智造平台/生产部/生产计划.xlsx'], 'write').decision === 'allow'
      && run(u('e_d', 'eo3'), ['/智造平台/生产部/生产计划.xlsx'], 'write').scope.includes('/智造平台/生产部')
      && deriveRole(u('e_d', 'eo3'), idx).role === 'D',
      JSON.stringify(run(u('e_d', 'eo3'), ['/智造平台/生产部/生产计划.xlsx'], 'write').scope))
    check('跨分支领导（一人多角色）：主归属矩阵不抬档，所领导部门子树按该部门角色全权限生效',
      deriveRole(u('e_x', 'eo3'), idx).role === 'M'
      && deriveRole(u('e_x', 'eo3'), idx).leaderOfElsewhere.map((led) => led.orgId).includes('eo5')
      && run(u('e_x', 'eo3'), ['/智造平台/品质部/检验标准.xlsx'], 'write').decision === 'allow'
      && run(u('e_x', 'eo3'), ['/智造平台/品质部/旧标准.xlsx'], 'delete').decision === 'allow'
      && run(u('e_x', 'eo3'), ['/智造平台/品质部/管理.xlsx'], 'admin').decision === 'deny'
      && run(u('e_x', 'eo3'), [inScope], 'modify').decision === 'deny',
      JSON.stringify(run(u('e_x', 'eo3'), ['/智造平台/品质部/检验标准.xlsx'], 'write')))
    check('跨分支领导救回作用域：主部门不在锚点链（原 no-scope 早退）不吞所领导部门权限',
      run(u('e_y', 'eo7'), ['/智造平台/品质部/检验标准.xlsx'], 'write').decision === 'allow'
      && run(u('e_y', 'eo7'), ['/外贸平台/合同.xlsx'], 'read').decision === 'deny',
      JSON.stringify(run(u('e_y', 'eo7'), ['/智造平台/品质部/检验标准.xlsx'], 'write')))
    check('根目录只读列举（B 语义）：作用域内用户列根放行、写根仍拒、越界子路径不变、无作用域用户列根仍拒',
      run(u('e_m', 'eo3'), ['/'], 'read').decision === 'allow'
      && run(u('e_m', 'eo3'), ['/'], 'read').reasons.some((r) => r.includes('root-listing'))
      && run(u('e_m', 'eo3'), ['/'], 'write').decision === 'deny'
      && run(u('e_m', 'eo3'), ['/外部目录/x.txt'], 'read').decision === 'deny'
      && run(u('e_z', 'eo7'), ['/'], 'read').decision === 'deny'
      && run(u('e_y', 'eo7'), ['/'], 'read').decision === 'allow',
      JSON.stringify({ mRootRead: run(u('e_m', 'eo3'), ['/'], 'read').decision, mRootWrite: run(u('e_m', 'eo3'), ['/'], 'write').decision, yRootRead: run(u('e_y', 'eo7'), ['/'], 'read').decision, zRootRead: run(u('e_z', 'eo7'), ['/'], 'read').decision }))
    check('作用域祖先链只读列举（2026-09-17 拍板）：深层子树成员可逐级下钻到自己的目录，兄弟子树/越界仍拒、写祖先仍拒',
      run(u('e_m', 'eo3'), ['/智造平台'], 'read').decision === 'allow'
      && run(u('e_m', 'eo3'), ['/智造平台/生产部'], 'read').reasons.some((r) => r.includes('ancestor-listing'))
      && run(u('e_m', 'eo3'), ['/智造平台/生产部'], 'write').decision === 'deny'
      && run(u('e_m', 'eo3'), ['/智造平台/品质部'], 'read').decision === 'deny'
      && run(u('e_m', 'eo3'), ['/智造平台/生产部/质检线'], 'read').decision === 'deny'
      && run(u('e_m', 'eo3'), ['/智造平台/生产部/总装12线'], 'read').decision === 'allow',
      JSON.stringify({ dept: run(u('e_m', 'eo3'), ['/智造平台/生产部'], 'read').decision, sibling: run(u('e_m', 'eo3'), ['/智造平台/品质部'], 'read').decision }))
    check('负责人悬空检测：质检线在列', findVacantLeaderOrgs(idx, { withUserOrgIds: new Set(['eo3', 'eo4']) }).some((o) => o.id === 'eo4'))

    // 判定序：显式 deny > 显式 allow > 角色矩阵 > 默认 deny
    const rulesEx = {
      ...baseRules,
      exceptions: [
        { id: 'ex_deny', effect: 'deny', nasId: 'en1', path: '/智造平台/生产部/*', ops: ['read'] },
        { id: 'ex_allow', effect: 'allow', nasId: 'en1', path: '/智造平台/生产部/总装12线', ops: ['read'] },
      ],
    }
    const exDeny = run(u('e_m', 'eo3'), ['/智造平台/生产部/总装12线/a.txt'], 'read', { rules: rulesEx })
    check('判定序：显式 deny 压过显式 allow', exDeny.decision === 'deny' && exDeny.ruleId === 'ex_deny')
    const readonlyOps = ['write', 'modify', 'delete', 'share', 'admin']
    check('readonly 语义（未落班组只读态）：写类全拒/读下载放行',
      readonlyOps.every((op) => run(u('e_d2', 'eo2'), ['/智造平台/生产部/x'], op).decision === 'deny')
      && run(u('e_d2', 'eo2'), ['/智造平台/生产部/x'], 'read').decision === 'allow'
      && run(u('e_d2', 'eo2'), ['/智造平台/生产部/x'], 'download').decision === 'allow')
    check('M 矩阵：写文件放行/改结构删除分享管理拒绝',
      run(u('e_m', 'eo3'), [inScope], 'write').decision === 'allow'
      && ['modify', 'delete', 'share', 'admin'].every((op) => run(u('e_m', 'eo3'), [inScope], op).decision === 'deny'))
    check('文件所有权（2026-09-17 新增）：上传者对自有文档全权（M 可删/改自己的文件），admin 不随所有权，精确路径外不命中',
      run(u('e_m', 'eo3'), [inScope], 'delete', { ownedPaths: [inScope] }).decision === 'allow'
      && run(u('e_m', 'eo3'), [inScope], 'delete', { ownedPaths: [inScope] }).reasons.some((r) => r.includes('owner.allow'))
      && run(u('e_m', 'eo3'), [inScope], 'modify', { ownedPaths: [inScope] }).decision === 'allow'
      && run(u('e_m', 'eo3'), [inScope], 'share', { ownedPaths: [inScope] }).decision === 'allow'
      && run(u('e_m', 'eo3'), [inScope], 'admin', { ownedPaths: [inScope] }).decision === 'deny'
      && run(u('e_m', 'eo3'), [inScope], 'delete', { ownedPaths: ['/智造平台/生产部/质检线/别人的.txt'] }).decision === 'deny'
      && run(u('e_m', 'eo3'), [inScope + '/子路径.txt'], 'delete', { ownedPaths: [inScope] }).decision === 'deny')
    check('文件所有权：显式 deny 仍压过所有权（判定序②不变）',
      (() => {
        const rules = { ...baseRules, observeOnly: false, exceptions: [{ id: 'ex_owner_deny', effect: 'deny', nasId: 'en1', path: '/智造平台/生产部/总装12线/*', ops: ['delete'], note: '治理封禁' }] }
        return run(u('e_m', 'eo3'), [inScope], 'delete', { rules, ownedPaths: [inScope] }).decision === 'deny'
          && run(u('e_m', 'eo3'), [inScope], 'delete', { rules, ownedPaths: [inScope] }).ruleId === 'ex_owner_deny'
      })())
    check('文件所有权：全量降级只读（G3）仍会压过所有权写类放行',
      run(u('e_m', 'eo3'), [inScope], 'delete', { rules: { ...baseRules, observeOnly: false, degradeAllToReadonly: true }, ownedPaths: [inScope] }).decision === 'deny')
    check('矩阵一致性：内置矩阵 M 行与判定一致',
      Object.entries(MATRIX_DEFAULT.M).every(([op, allow]) => (run(u('e_m', 'eo3'), [inScope], op).decision === 'allow') === allow))

    // 例外过期 / C 叠加
    const rulesExp = {
      ...baseRules,
      exceptions: [{ id: 'ex_tmp', effect: 'allow', nasId: 'en1', path: '/智造平台/生产部/质检线/外部/*', ops: ['read'], expiresAt: '2026-08-01T00:00:00Z' }],
    }
    check('例外 expiresAt 过期即失效（回落矩阵后越界 deny）',
      run(u('e_m', 'eo3'), ['/智造平台/生产部/质检线/外部/a'], 'read', { rules: rulesExp }).decision === 'deny')
    const rulesExp2 = { ...rulesExp, exceptions: [{ ...rulesExp.exceptions[0], expiresAt: '2026-09-01T00:00:00Z' }] }
    check('例外未过期即生效',
      run(u('e_m', 'eo3'), ['/智造平台/生产部/质检线/外部/a'], 'read', { rules: rulesExp2 }).decision === 'allow')
    check('C 叠加：跨域只读放行、写拒绝',
      run(u('e_m', 'eo3'), ['/智造平台/生产部/质检线/外部/b'], 'read', { cGroupHits: ['eg_c'] }).decision === 'allow'
      && run(u('e_m', 'eo3'), ['/智造平台/生产部/质检线/外部/b'], 'write', { cGroupHits: ['eg_c'] }).decision === 'deny')
    const rulesCWrite = { ...baseRules, exceptions: [{ id: 'ex_cw', effect: 'allow', nasId: 'en1', path: '/智造平台/生产部/质检线/外部/b', ops: ['write'] }] }
    check('C 白名单目录写需显式 allow',
      run(u('e_m', 'eo3'), ['/智造平台/生产部/质检线/外部/b'], 'write', { rules: rulesCWrite, cGroupHits: ['eg_c'] }).decision === 'allow')

    // 边界 / 多 NAS / 映射表优先
    check('边界：路径超出组织子树 deny', run(u('e_m', 'eo3'), ['/智造平台/其他/x'], 'read').decision === 'deny')
    check('多 NAS：B 平台 NAS 对 A 平台成员 deny（orgRoot 不在链上）',
      run(u('e_m', 'eo3'), ['/x'], 'read', { nasId: 'en2', nas: { id: 'en2', rootPath: '/', orgRoot: '市场部' } }).decision === 'deny')
    const overriddenNas = { id: 'en1', rootPath: '/', orgRoot: '智造平台', orgPathOverrides: { eo3: '/总装A' } }
    check('orgPathOverrides 优先于名字推导',
      run(u('e_m', 'eo3'), ['/总装A/x'], 'read', { nas: overriddenNas }).decision === 'allow'
      && run(u('e_m', 'eo3'), ['/智造平台/生产部/总装12线/x'], 'read', { nas: overriddenNas }).decision === 'deny')
    const renamedIdx = buildOrgIndex(eo.map((o) => (o.id === 'eo3' ? { ...o, name: '总装十二线' } : o)))
    const renamedRun = engineCheck(
      { userId: 'e_m', nasId: 'en1', paths: ['/总装A/x'], op: 'read', now },
      { orgIndex: renamedIdx, user: u('e_m', 'eo3'), nas: overriddenNas, rules: baseRules, cGroupHits: [] },
    )
    check('组织改名作用域不漂移（映射表按 orgId 命中）', renamedRun.decision === 'allow' && renamedRun.scope[0] === '/总装A')
    check('override 破窗放行（并留痕标记）',
      run(u('e_m', 'eo3'), ['/任意/x'], 'delete', { override: true }).decision === 'allow'
      && run(u('e_m', 'eo3'), ['/任意/x'], 'delete', { override: true }).override === true)
    const degradeRules = { ...baseRules, degradeAllToReadonly: true }
    check('degradeAllToReadonly：allow 视作 readonly',
      run(u('e_d', 'eo2'), ['/智造平台/生产部/x'], 'write', { rules: degradeRules }).decision === 'deny')
    check('observeOnly 标注透传', run(u('e_m', 'eo3'), [inScope], 'read').observeOnly === true)
    check('审批人路由：沿链向上最近负责人（班组自身有负责人即命中；悬空则跳到上级）',
      nearestLeaderOrg(idx, 'eo3')?.orgId === 'eo3' && nearestLeaderOrg(idx, 'eo4')?.orgId === 'eo2'
      && nearestLeaderOrg(idx, 'eo1')?.orgId === 'eo1')

    check('外部账号白名单只读',
      run(u('e_ext', 'eo3', { accountType: 'external' }), ['/外部白名单/a'], 'read').decision === 'allow'
      && run(u('e_ext', 'eo3', { accountType: 'external' }), ['/外部白名单/a'], 'write').decision === 'deny'
      && run(u('e_ext', 'eo3', { accountType: 'external' }), ['/其他/a'], 'read').decision === 'deny')
    check('可疑标记账号 deny 转人工', run(u('e_bad', 'eo3', { accountType: 'suspended-review' }), [inScope], 'read').decision === 'deny')
  }

  section('NAS 资产纳管（plugin-nas + 文件网关 stub）')

  // 网关 stub 自身契约：错误 Bearer 被拒（证明平台调用确实携带网关令牌）
  const gwBadToken = await fetch(`http://127.0.0.1:${NAS_GW_PORT}/mcp`, {
    method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer wrong-token' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'initialize' }),
  })
  check('网关 stub 校验 Bearer（错误令牌 401）', gwBadToken.status === 401)

  // 用户测试配置（synology-filestation 形态）一键导入 → 创建 + 探活 + 上线 + 工具发现
  const mcpServersConfig = JSON.stringify({
    mcpServers: {
      'synology-filestation': {
        url: `http://127.0.0.1:${NAS_GW_PORT}/mcp`,
        headers: { Authorization: `Bearer ${NAS_GW_TOKEN}`, 'X-NAS-IP': NAS_GW_IP },
      },
    },
  })
  const nasImport = await api('POST', '/api/nas/import', { token: admin, body: { config: mcpServersConfig, name: '自测群晖 NAS' } })
  const nasImportResult = nasImport.data?.results?.[0] ?? {}
  check('mcpServers JSON 一键导入（探活 → 上线 → 工具发现）',
    nasImport.ok && nasImport.data.imported === 1 && nasImportResult.reachable === true && nasImportResult.status === 'online' && nasImportResult.tools === 10,
    JSON.stringify(nasImport.error ?? nasImportResult))
  const nasId = nasImportResult.nasId

  const nasDetail = await api('GET', `/api/nas/${nasId}`, { token: admin })
  check('详情含健康与网关工具面', nasDetail.ok && nasDetail.data.health.status === 'healthy' && nasDetail.data.gatewayTools.length === 10)
  check('访问令牌回显脱敏（原文不落响应）', nasDetail.ok && !JSON.stringify(nasDetail.data).includes(NAS_GW_TOKEN) && String(nasDetail.data.attrs.accessToken).endsWith('…'))

  const nasHealth = await api('POST', `/api/nas/${nasId}/health`, { token: admin })
  check('手动探活（initialize 握手测延迟）', nasHealth.ok && nasHealth.data.status === 'healthy' && nasHealth.data.latencyMs >= 0)

  // 文件全链（全部经网关 tools/call）
  const nasShares = await api('GET', `/api/nas/${nasId}/fs`, { token: admin })
  check('列出共享文件夹（fs_list_shares）', nasShares.ok && JSON.stringify(nasShares.data).includes('skillhub'))
  const nasFiles = await api('GET', `/api/nas/${nasId}/fs?path=/skillhub`, { token: admin })
  check('列目录（fs_list）', nasFiles.ok && JSON.stringify(nasFiles.data).includes('readme.txt'))
  const nasMkdir = await api('POST', `/api/nas/${nasId}/fs/mkdir`, { token: admin, body: { path: '/skillhub/selftest' } })
  check('创建目录（fs_create_folder：folder_path+name 数组一一对应）',
    nasMkdir.ok && nasGwCalls.some((c) => c.name === 'fs_create_folder' && Array.isArray(c.args.folder_path) && c.args.folder_path[0] === '/skillhub' && Array.isArray(c.args.name) && c.args.name[0] === 'selftest'))
  const nasUpload = await api('POST', `/api/nas/${nasId}/fs/upload`, {
    token: admin,
    body: { contentBase64: Buffer.from('PK\x03\x04selftest-file', 'latin1').toString('base64'), destPath: '/skillhub/selftest/a.zip' },
  })
  check('上传文件（平台 staging → 网关 fs_upload 侧读盘）', nasUpload.ok && nasGwUploads.some((u) => u.destPath === '/skillhub/selftest' && u.filename === 'a.zip' && u.magic === 'PK'))
  const adminUserId = adminLogin.data.user?.id
  const ownList = await api('GET', `/api/nas/authz/ownership?nasId=${nasId}&path=${encodeURIComponent('/skillhub/selftest/a.zip')}`, { token: admin })
  // 所有权探针用户：挂三级组织链（depth 3 → M 角色，无特殊账号态），隔离于演示种子组织
  const ownRootOrg = await api('POST', '/api/iam/orgs', { token: admin, body: { name: '所有权测试事业部' } })
  const ownMidOrg = await api('POST', '/api/iam/orgs', { token: admin, body: { name: '所有权测试部门', parentId: ownRootOrg.data.id } })
  const ownLeafOrg = await api('POST', '/api/iam/orgs', { token: admin, body: { name: '所有权测试班组', parentId: ownMidOrg.data.id } })
  const ownUserCreate = await api('POST', '/api/iam/users', { token: admin, body: { username: 'ownertest', displayName: '所有权测试员', orgId: ownLeafOrg.data.id, password: 'Ybk@2026' } })
  const memberUid = ownUserCreate.ok ? ownUserCreate.data.id : register.data.user.id
  const ownProbe = await api('POST', '/api/nas/authz/ownership/record', { token: admin, body: { nasId, userId: memberUid, tool: 'fs_upload', args: { dest_path: '/skillhub/selftest', local_file: '/tmp/stage/成员上传.bin' } } })
  check('文件所有权登记（服务层）：上传成功即登记上传者 + 网关上报可登记成员', ownList.ok && ownList.data.items.length === 1 && ownList.data.items[0].userId === adminUserId && ownList.data.items[0].source === 'upload'
    && ownProbe.ok && !ownProbe.data.ignored,
    JSON.stringify({ list: ownList.error ?? ownList.data, probe: ownProbe.error ?? ownProbe.data }))
  const ownDelCheck = await api('POST', '/api/nas/authz/check', { token: admin, body: { nasId, userId: memberUid, paths: ['/skillhub/selftest/成员上传.bin'], op: 'delete' } })
  check('文件所有权判定（服务层）：上传者删除自有文档放行（owner.allow，优先于作用域/矩阵）',
    ownDelCheck.ok && ownDelCheck.data.decision === 'allow' && ownDelCheck.data.reasons.some((r) => r.includes('owner.allow')),
    JSON.stringify(ownDelCheck.error ?? ownDelCheck.data?.reasons))
  const ownOtherDel = await api('POST', '/api/nas/authz/check', { token: admin, body: { nasId, userId: memberUid, paths: ['/skillhub/selftest/a.zip'], op: 'delete' } })
  check('文件所有权不外溢：非本人上传的文件所有权判定不命中（admin 上传的文件对成员仍按矩阵/作用域）',
    ownOtherDel.ok && ownOtherDel.data.reasons.every((r) => !r.includes('owner.allow')),
    JSON.stringify(ownOtherDel.error ?? ownOtherDel.data?.reasons))
  const nasSearch = await api('POST', `/api/nas/${nasId}/fs/search`, { token: admin, body: { pattern: 'report', path: '/skillhub' } })
  check('检索文件（fs_search：folder_path 字符串）', nasSearch.ok && JSON.stringify(nasSearch.data).includes('report'))
  const nasDelete = await api('POST', `/api/nas/${nasId}/fs/delete`, { token: admin, body: { paths: ['/skillhub/selftest/a.zip'] } })
  check('删除文件（fs_delete：path 数组）', nasDelete.ok && nasGwCalls.some((c) => c.name === 'fs_delete' && Array.isArray(c.args.path) && c.args.path[0] === '/skillhub/selftest/a.zip'))
  const ownListAfterDel = await api('GET', `/api/nas/authz/ownership?nasId=${nasId}&path=${encodeURIComponent('/skillhub/selftest/a.zip')}`, { token: admin })
  check('文件所有权随删除移除（生命周期维护）', ownListAfterDel.ok && ownListAfterDel.data.items.length === 0,
    JSON.stringify(ownListAfterDel.error ?? ownListAfterDel.data))

  // 真实网关契约：fs_list 用 folder_path 字符串
  const nasFilesCheck = nasGwCalls.find((c) => c.name === 'fs_list' && c.args.folder_path === '/skillhub')
  check('列目录（fs_list：folder_path 字符串）', !!nasFilesCheck)

  // 重命名（fs_rename：path + name 数组一一对应）
  const nasRename = await api('POST', `/api/nas/${nasId}/fs/rename`, { token: admin, body: { path: '/skillhub/selftest/a.zip', newName: 'b.zip' } })
  check('重命名（fs_rename：path+name 数组一一对应）',
    nasRename.ok && nasGwCalls.some((c) => c.name === 'fs_rename' && Array.isArray(c.args.path) && c.args.path[0] === '/skillhub/selftest/a.zip' && Array.isArray(c.args.name) && c.args.name[0] === 'b.zip'))

  // 批量上传 upload-many（保留目录结构 + base64 集合 → 多次 fs_upload）
  const manyItems = [
    { relativePath: 'docs/readme.md', contentBase64: Buffer.from('# 批量上传 README', 'utf8').toString('base64') },
    { relativePath: 'src/index.js', contentBase64: Buffer.from("console.log('selftest')", 'utf8').toString('base64') },
    { relativePath: 'src/utils.js', contentBase64: Buffer.from('export const ok = true', 'utf8').toString('base64') },
  ]
  const beforeMany = nasGwUploads.length
  const nasUploadMany = await api('POST', `/api/nas/${nasId}/fs/upload-many`, { token: admin, body: { files: manyItems, destDir: '/skillhub/batch' } })
  check('批量上传（保留目录结构：docs/、src/ 等）',
    nasUploadMany.ok && nasUploadMany.data.uploaded.length === 3 && nasUploadMany.data.failed.length === 0
      && nasGwUploads.slice(beforeMany).map((u) => u.filename).join(',') === 'readme.md,index.js,utils.js'
      && nasGwUploads.slice(beforeMany).map((u) => u.destPath).join(',') === '/skillhub/batch/docs,/skillhub/batch/src,/skillhub/batch/src')

  // 流式下载（GET /api/nas/:id/fs/file）：先 POST /fs/download 触发网关落盘，再 GET 拿到 bytes
  const nasDownloadTrigger = await api('POST', `/api/nas/${nasId}/fs/download`, { token: admin, body: { path: '/skillhub/selftest/a.zip' } })
  check('触发下载落盘（POST /fs/download → 网关 fs_download 真实落盘）',
    nasDownloadTrigger.ok && typeof nasDownloadTrigger.data.localFile === 'string' && nasDownloadTrigger.data.bytes > 0)
  const fileResp = await fetch(`http://127.0.0.1:${PORT}/api/nas/${nasId}/fs/file?path=${encodeURIComponent('/skillhub/selftest/a.zip')}`, {
    headers: { authorization: `Bearer ${admin}` },
  })
  const fileBytes = fileResp.ok ? Buffer.from(await fileResp.arrayBuffer()) : Buffer.alloc(0)
  check('浏览器真实下载（GET /fs/file 200 + bytes 一致 + content-disposition attachment）',
    fileResp.ok && fileBytes.toString('utf8') === 'selftest-download-bytes' && /attachment;\s*filename\*=UTF-8''a\.zip/.test(fileResp.headers.get('content-disposition') ?? ''))
  const inlineResp = await fetch(`http://127.0.0.1:${PORT}/api/nas/${nasId}/fs/file?path=${encodeURIComponent('/skillhub/selftest/a.zip')}&inline=1`, {
    headers: { authorization: `Bearer ${admin}` },
  })
  check('inline=1 预览模式（content-disposition: inline）',
    inlineResp.ok && /inline;\s*filename\*=UTF-8''a\.zip/.test(inlineResp.headers.get('content-disposition') ?? ''))
  const noAuthDownload = await fetch(`http://127.0.0.1:${PORT}/api/nas/${nasId}/fs/file?path=${encodeURIComponent('/skillhub/selftest/a.zip')}`)
  check('stream 下载无 token 且无票据 401', noAuthDownload.status === 401)
  // 一次性下载票据：签发 → 免 Bearer 原生 GET → 二次消费被拒
  const ticketResp = await api('POST', `/api/nas/${nasId}/fs/download-ticket`, { token: admin, body: { path: '/skillhub/selftest/a.zip' } })
  check('签发一次性下载票据', ticketResp.ok && String(ticketResp.data.ticket).startsWith('nastk_'))
  const ticketFile = await fetch(`http://127.0.0.1:${PORT}/api/nas/${nasId}/fs/file?path=${encodeURIComponent('/skillhub/selftest/a.zip')}&ticket=${encodeURIComponent(ticketResp.data.ticket)}`)
  const ticketBytes = ticketFile.ok ? Buffer.from(await ticketFile.arrayBuffer()) : Buffer.alloc(0)
  check('票据直取文件（无 Bearer，字节一致）', ticketFile.ok && ticketBytes.toString('utf8') === 'selftest-download-bytes',
    JSON.stringify({ status: ticketFile.status, type: ticketFile.headers.get('content-type'), len: ticketBytes.length }))
  const ticketReplay = await fetch(`http://127.0.0.1:${PORT}/api/nas/${nasId}/fs/file?path=${encodeURIComponent('/skillhub/selftest/a.zip')}&ticket=${encodeURIComponent(ticketResp.data.ticket)}`)
  check('票据一次性（重放 401）', ticketReplay.status === 401)
  const badTicket = await fetch(`http://127.0.0.1:${PORT}/api/nas/${nasId}/fs/file?path=${encodeURIComponent('/skillhub/selftest/a.zip')}&ticket=nastk_bogus`)
  check('未知票据 401', badTicket.status === 401)
  // 分享链接票据（mode=link，前端「复制下载链接」场景）：TTL 内可重复消费
  const linkTicketResp = await api('POST', `/api/nas/${nasId}/fs/download-ticket`, { token: admin, body: { path: '/skillhub/selftest/a.zip', mode: 'link' } })
  check('签发分享链接票据（mode=link，TTL 600s）', linkTicketResp.ok && linkTicketResp.data.expiresInSec === 600)
  const linkFile1 = await fetch(`http://127.0.0.1:${PORT}/api/nas/${nasId}/fs/file?path=${encodeURIComponent('/skillhub/selftest/a.zip')}&ticket=${encodeURIComponent(linkTicketResp.data.ticket)}`)
  const linkFile2 = await fetch(`http://127.0.0.1:${PORT}/api/nas/${nasId}/fs/file?path=${encodeURIComponent('/skillhub/selftest/a.zip')}&ticket=${encodeURIComponent(linkTicketResp.data.ticket)}`)
  check('链接票据 TTL 内可重复消费', linkFile1.ok && linkFile2.ok)
  const nasAudit = await api('GET', `/api/audit/logs?resourceId=${nasId}&limit=20`, { token: admin })
  check('写类文件操作审计留痕', (nasAudit.data?.items ?? []).some((l) => l.action === 'nas.fs.mkdir') && (nasAudit.data?.items ?? []).some((l) => l.action === 'nas.fs.upload'))

  // 计量管道（观测补齐）：全部文件操作进 usage 事件（nas:<ID>，calls 全量、upload 额外 bytes）
  const nasUsage = await api('GET', '/api/usage/events?resource=' + encodeURIComponent(`nas:${nasId}`), { token: admin })
  const nasBytes = (nasUsage.data?.items ?? []).flatMap((event) => event.meters ?? []).find((meter) => meter.key === 'bytes')
  check('NAS 文件操作进计量管道（calls 全量 + upload bytes）', nasUsage.ok && nasUsage.data.total >= 6 && !!nasBytes && nasBytes.value > 0)

  // RBAC：无角色 403 / developer 只读
  const memberLogin = await api('POST', '/api/auth/login', { body: { username: 'yqz', password: 'Ybk@2026' } })
  const member = memberLogin.data?.token
  const memberNas = await api('GET', '/api/nas', { token: member })
  const noReadPerm = await fetch(`http://127.0.0.1:${PORT}/api/nas/${nasId}/fs/file?path=${encodeURIComponent('/skillhub/selftest/a.zip')}`, { headers: { authorization: `Bearer ${member}` } })
  check('stream 下载无 nas.read 403', noReadPerm.status === 403)
  check('无 nas.read 角色访问被拒（403）', memberNas.status === 403)
  const devNasRead = await api('GET', '/api/nas', { token: dev })
  check('developer 只读放行（nas.read）', devNasRead.ok)
  const devNasWrite = await api('POST', `/api/nas/${nasId}/fs/mkdir`, { token: dev, body: { path: '/skillhub/deny' } })
  check('developer 写操作被拒（缺 nas.write，403）', devNasWrite.status === 403)

  // 二次编辑（PATCH）：属性合并更新；未携带的接入属性保持原值
  const nasPatch = await api('PATCH', `/api/nas/${nasId}`, { token: admin, body: { attrs: { description: '自测：二次编辑后的描述', vendor: 'Synology DS925+' } } })
  check('二次编辑（PATCH 属性合并更新）', nasPatch.ok && nasPatch.data.attrs.description === '自测：二次编辑后的描述' && nasPatch.data.attrs.vendor === 'Synology DS925+', JSON.stringify(nasPatch.error))
  const nasAfterPatch = await api('GET', `/api/nas/${nasId}`, { token: admin })
  check('编辑未携带的接入属性保持原值（网关地址/令牌未丢）', nasAfterPatch.ok && nasAfterPatch.data.attrs.gatewayUrl === `http://127.0.0.1:${NAS_GW_PORT}/mcp`)
  const nasPatchFs = await api('GET', `/api/nas/${nasId}/fs`, { token: admin })
  check('编辑后网关客户端缓存已作废（fs 调用仍通）', nasPatchFs.ok && JSON.stringify(nasPatchFs.data).includes('skillhub'))
  const devNasPatch = await api('PATCH', `/api/nas/${nasId}`, { token: dev, body: { attrs: { description: 'x' } } })
  check('developer 编辑被拒（缺 nas.write，403）', devNasPatch.status === 403)

  // 删除（DELETE）：草稿（从未上线，无法走到归档）可直接删；在线/已下线需先归档
  const nas2 = await api('POST', '/api/nas', { token: admin, body: { name: '自测待删 NAS', attrs: { description: '删除生命周期自测', gatewayUrl: `http://127.0.0.1:${NAS_GW_PORT}/mcp`, accessToken: NAS_GW_TOKEN, nasIp: NAS_GW_IP } } })
  check('登记第二台 NAS（草稿）', nas2.ok && nas2.data.status === 'draft', JSON.stringify(nas2.error))
  const nas2Id = nas2.data?.id
  const devNasDelete = await api('DELETE', `/api/nas/${nas2Id}`, { token: dev })
  check('developer 删除被拒（缺 nas.write，403）', devNasDelete.status === 403)
  const delDraft = await api('DELETE', `/api/nas/${nas2Id}`, { token: admin })
  check('草稿资产可直接删除', delDraft.ok && delDraft.data.deleted === true, JSON.stringify(delDraft.error))
  const nas2Gone = await api('GET', `/api/nas/${nas2Id}`, { token: admin })
  check('删除后详情不再可查', nas2Gone.status === 400 && !nas2Gone.ok)

  const nas3 = await api('POST', '/api/nas', { token: admin, body: { name: '自测归档删除 NAS', attrs: { description: '归档删除链路自测', gatewayUrl: `http://127.0.0.1:${NAS_GW_PORT}/mcp`, accessToken: NAS_GW_TOKEN, nasIp: NAS_GW_IP } } })
  const nas3Id = nas3.data?.id
  await api('POST', `/api/nas/${nas3Id}/transition`, { token: admin, body: { action: 'online' } })
  const delOnline = await api('DELETE', `/api/nas/${nas3Id}`, { token: admin })
  check('在线资产删除被拒（需先下线/归档）', delOnline.status === 400 && !delOnline.ok)
  await api('POST', `/api/nas/${nas3Id}/transition`, { token: admin, body: { action: 'offline', note: '自测删除链路' } })
  const delOffline = await api('DELETE', `/api/nas/${nas3Id}`, { token: admin })
  check('已下线资产删除仍被拒（需先归档）', delOffline.status === 400 && !delOffline.ok)
  const nas3Archive = await api('POST', `/api/nas/${nas3Id}/transition`, { token: admin, body: { action: 'archive' } })
  check('归档为终态', nas3Archive.ok && nas3Archive.data.status === 'archived', JSON.stringify(nas3Archive.error))
  const nas3Delete = await api('DELETE', `/api/nas/${nas3Id}`, { token: admin })
  check('归档后删除成功（含健康/工具缓存清理）', nas3Delete.ok && nas3Delete.data.deleted === true, JSON.stringify(nas3Delete.error))

  // ================================================================ NAS 数据权限 API
  section('NAS 数据权限 API（check/scope/rules/例外/审批闭环，dev-plan-nas-authz §2.3-§2.7）')
  // 夹具：NAS 配 orgRoot + 组织负责人（P=admin / D=ops / T=heqw / M=linxm）
  const nasRootPatch = await api('PATCH', `/api/nas/${nasId}`, { token: admin, body: { attrs: { orgRoot: '元冰可集团' } } })
  check('NAS 配置接入组织锚点（orgRoot=元冰可集团）', nasRootPatch.ok)

  const orgAll = (await api('GET', '/api/iam/orgs', { token: admin })).data ?? []
  const orgByName = (name) => orgAll.find((org) => org.name === name)?.id
  const orgRootId = orgByName('元冰可集团')
  const orgTechId = orgByName('技术中心')
  const orgAiId = orgByName('AI 平台部')
  const orgProdId = orgByName('产品运营部')
  const orgFeId = orgByName('前端部')
  check('组织夹具就绪（根/技术中心/AI 平台部/产品运营部/前端部）', Boolean(orgRootId && orgTechId && orgAiId && orgProdId && orgFeId))

  const userAll = (await api('GET', '/api/iam/users', { token: admin })).data?.users ?? []
  const userByName = (username) => userAll.find((user) => user.username === username)?.id
  const adminUid = userByName('admin')
  const opsUid = userByName('ops')
  const heqwUid = userByName('heqw')
  const linxmUid = userByName('linxm')
  const devUid = userByName('dev')
  const yqzUid = userByName('yqz')
  const auditUid = userByName('audit')
  const suyqUid = userByName('suyq')
  check('用户夹具就绪', Boolean(adminUid && opsUid && heqwUid && linxmUid && yqzUid && auditUid && suyqUid))

  await api('PATCH', `/api/iam/orgs/${orgRootId}`, { token: admin, body: { leaderUserIds: [adminUid] } })
  await api('PATCH', `/api/iam/orgs/${orgTechId}`, { token: admin, body: { leaderUserIds: [opsUid] } })
  await api('PATCH', `/api/iam/orgs/${orgFeId}`, { token: admin, body: { leaderUserIds: [heqwUid] } })

  const authzCheck = (userId, paths, op, extra = {}) => api('POST', '/api/nas/authz/check', {
    token: admin,
    body: { nasId: extra.nasId ?? nasId, userId, paths, op, ...(extra.override !== undefined ? { override: extra.override } : {}), ...(extra.headerUser ? {} : {}) },
    ...(extra.headerUser ? {} : {}),
  })

  // —— 35 格矩阵（4 主角色 × 7 操作；C 叠加另测）——
  const roleScope = {
    P: { uid: adminUid, path: '/元冰可集团/技术中心/AI 平台部/季度报告.docx' },
    D: { uid: opsUid, path: '/元冰可集团/技术中心/AI 平台部/季度报告.docx' },
    T: { uid: heqwUid, path: '/元冰可集团/技术中心/前端部/页面原型.png' },
    M: { uid: devUid, path: '/元冰可集团/技术中心/AI 平台部/季度报告.docx' },
  }
  const EXPECTED = {
    P: { read: 1, download: 1, write: 1, modify: 1, delete: 1, share: 1, admin: 1 },
    D: { read: 1, download: 1, write: 1, modify: 1, delete: 1, share: 1, admin: 0 },
    T: { read: 1, download: 1, write: 1, modify: 1, delete: 0, share: 0, admin: 0 },
    M: { read: 1, download: 1, write: 1, modify: 0, delete: 0, share: 0, admin: 0 },
  }
  let matrixOk = true
  let matrixDetail = ''
  for (const [role, cfg] of Object.entries(roleScope)) {
    for (const op of ['read', 'download', 'write', 'modify', 'delete', 'share', 'admin']) {
      const resp = await authzCheck(cfg.uid, [cfg.path], op)
      const got = resp.data?.decision === 'allow' ? 1 : 0
      if (!resp.ok || got !== EXPECTED[role][op] || !Array.isArray(resp.data?.reasons) || resp.data.reasons.length === 0 || resp.data?.role !== role) {
        matrixOk = false
        matrixDetail = `${role}×${op} 期望 ${EXPECTED[role][op]} 实得 ${got}（${JSON.stringify(resp.data?.reasons ?? resp.error)}）`
      }
    }
  }
  check('附件矩阵 35 格（P/D/T/M × 7 操作）判定一致且每格含 reasons', matrixOk, matrixDetail)

  // scope 与 check 一致
  const scopeM = await api('GET', `/api/nas/authz/scope?nasId=${nasId}&userId=${devUid}`, { token: admin })
  const checkM = await authzCheck(devUid, ['/元冰可集团/技术中心/AI 平台部/a.txt'], 'read')
  check('scope 返回角色/作用域并与 check 一致',
    scopeM.ok && scopeM.data.role === 'M' && JSON.stringify(scopeM.data.scope) === JSON.stringify(checkM.data.scope)
    && scopeM.data.matrix?.M?.read === true,
    JSON.stringify({ scope: scopeM.data?.scope, role: scopeM.data?.role, checkScope: checkM.data?.scope }))

  // 钉钉 userId 反查等价（linxm ↔ dd_u002，identityLinks 事实源）
  const byPlatform = await authzCheck(linxmUid, ['/元冰可集团/技术中心/AI 平台部/a.txt'], 'read')
  const byDingtalk = await authzCheck('dd_u002', ['/元冰可集团/技术中心/AI 平台部/a.txt'], 'read')
  check('钉钉 userId 反查与平台 userId 等价（identityLinks）',
    byDingtalk.ok && byPlatform.ok
    && byDingtalk.data.decision === byPlatform.data.decision && byDingtalk.data.role === byPlatform.data.role
    && JSON.stringify(byDingtalk.data.scope) === JSON.stringify(byPlatform.data.scope)
    && byDingtalk.data.userName === '林小满',
    JSON.stringify({ byPlatform: byPlatform.data, byDingtalk: byDingtalk.data }))

  // userid 口径反查（hermes X-On-Behalf-User 与 dept_manager_userid_list 的口径）：unionId+userid 双链并存
  const byStaffId = await authzCheck('staff_002', ['/元冰可集团/技术中心/AI 平台部/a.txt'], 'read')
  check('钉钉 userid 口径反查与平台 userId 等价（双身份链：unionId 供登录、userid 供运营反查）',
    byStaffId.ok && byStaffId.data.userName === '林小满'
    && JSON.stringify(byStaffId.data.scope) === JSON.stringify(byPlatform.data.scope),
    JSON.stringify(byStaffId.data))

  // —— 签名分享链接（2026-09-21「NAS 下载链接签名化」：docs-20260921 设计清单断言面）——
  // 档位/策略/永久显式（决策②③）+ 独立长期密钥（决策①）+ 取流三关（签名→吊销→权限复核）。
  // 旧链路（mode=once 一次性 / mode=link 600s）断言在上方文件全链段，行为不变即不回归。
  const slPath = '/元冰可集团/技术中心/AI 平台部/分享目标.bin' // mock 网关对任意路径落盘固定字节
  const slReq = (link) => fetch(link.startsWith('http') ? link : `http://127.0.0.1:${PORT}${link}`)

  const slDefault = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: admin, body: { path: slPath } })
  check('share-link 默认档 24 小时（决策②：不传 ttlSec/permanent → 86400 且绝不产生永久链接）',
    slDefault.ok && slDefault.data.expiresInSec === 86400 && slDefault.data.permanent === false && !!slDefault.data.expiresAt,
    JSON.stringify(slDefault.error ?? slDefault.data))

  const sl1h = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: admin, body: { path: slPath, ttlSec: 3600 } })
  const sl7d = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: admin, body: { path: slPath, ttlSec: 604800 } })
  const sl30d = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: admin, body: { path: slPath, ttlSec: 2592000 } })
  check('显式档位 1h/7d/30d 签发', sl1h.ok && sl1h.data.expiresInSec === 3600 && sl7d.ok && sl7d.data.expiresInSec === 604800 && sl30d.ok && sl30d.data.expiresInSec === 2592000,
    JSON.stringify({ sl1h: sl1h.error, sl7d: sl7d.error, sl30d: sl30d.error }))

  const slOver = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: admin, body: { path: slPath, ttlSec: 9999999 } })
  check('TTL 超策略上限 400 TTL_EXCEEDS_POLICY（明确拒绝，不回落到上限）', slOver.status === 400 && slOver.error?.code === 'TTL_EXCEEDS_POLICY',
    JSON.stringify(slOver.error))

  const slPermOff = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: admin, body: { path: slPath, permanent: true } })
  check('永久档策略默认关（决策③：allowPermanent=false 时持 nas.authz.write 也 403，策略开关优先于权限点）',
    slPermOff.status === 403 && slPermOff.error?.code === 'PERMANENT_DISABLED_BY_POLICY', JSON.stringify(slPermOff.error))

  const slConflict = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: admin, body: { path: slPath, permanent: true, ttlSec: 3600 } })
  check('permanent 与 ttlSec 互斥（400，语义歧义不猜测）', slConflict.status === 400 && slConflict.error?.code === 'PERMANENT_TTL_CONFLICT',
    JSON.stringify(slConflict.error))

  // 有效取流（免 Bearer）+ 使用计数/清单面（含 keyId 留痕）
  const slUse1 = await slReq(sl1h.data.url)
  const slUse2 = await slReq(sl1h.data.url)
  const slUseBytes = slUse1.ok ? Buffer.from(await slUse1.arrayBuffer()).toString('utf8') : ''
  const slList = await api('GET', `/api/nas/${nasId}/fs/share-links`, { token: admin })
  check('签名链接取流（免 Bearer 直下 bytes）+ 使用计数/清单可见（keyId 留痕）',
    slUse1.ok && slUse2.ok && slUseBytes === 'selftest-download-bytes'
      && (slList.data?.items ?? []).some((item) => item.id === sl1h.data.jti && item.useCount === 2 && !!item.keyId),
    JSON.stringify({ s1: slUse1.status, s2: slUse2.status, list: slList.error ?? slList.data?.items?.length }))

  // 签名关：篡改 path/exp（含过去时刻）/sub/jti 任一字段 → 401
  const tamper = (mutate) => {
    const u = new URL(sl1h.data.url)
    mutate(u.searchParams)
    return u.toString()
  }
  const tPath = await slReq(tamper((p) => p.set('path', '/元冰可集团/技术中心/前端部/别的.bin')))
  const tExpPast = await slReq(tamper((p) => p.set('exp', '1000000')))
  const tSub = await slReq(tamper((p) => p.set('sub', 'user_forge')))
  const tJti = await slReq(tamper((p) => p.set('jti', 'nsl_forge')))
  check('签名关：篡改 path/exp/sub/jti 任一字段 401', tPath.status === 401 && tExpPast.status === 401 && tSub.status === 401 && tJti.status === 401,
    JSON.stringify({ tPath: tPath.status, tExp: tExpPast.status, tSub: tSub.status, tJti: tJti.status }))

  // 签发员夹具：持 nas.read/nas.write 而无 nas.authz.write（永久越权断言 + 复核身份）
  const slRole = await api('POST', '/api/iam/roles', { token: admin, body: { name: '分享链接签发自测', code: 'sharelink_selftest', description: 'selftest share-link', permissions: ['nas.read', 'nas.write'] } })
  const slUserCreate = await api('POST', '/api/iam/users', { token: admin, body: { username: 'sharelink_issuer', displayName: '链接签发员', orgId: orgAiId, password: 'Ybk@2026', roleIds: slRole.ok ? [slRole.data.id] : [] } })
  const slIssuerLogin = await api('POST', '/api/auth/login', { body: { username: 'sharelink_issuer', password: 'Ybk@2026' } })
  const slIssuer = slIssuerLogin.data?.token
  const slIssuerUid = slUserCreate.data?.id
  check('签发员夹具就绪（nas.write 持有、无 nas.authz.write，挂 元冰可集团 组织链）', slRole.ok && slUserCreate.ok && !!slIssuer, JSON.stringify({ role: slRole.error, user: slUserCreate.error, login: slIssuerLogin.error }))

  // 策略面：开启永久档（决策③第二步前置；put 走 AuthzRules 乐观锁）
  const polOn = await api('PUT', '/api/nas/authz/share-link-policy', { token: admin, body: { allowPermanent: true } })
  check('策略面开启 allowPermanent（PUT share-link-policy）', polOn.ok && polOn.data.allowPermanent === true, JSON.stringify(polOn.error ?? polOn.data))

  const slPermNoAuthz = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: slIssuer, body: { path: slPath, permanent: true } })
  check('永久越权 403 PERMANENT_REQUIRES_AUTHZ_WRITE（策略已开但无 nas.authz.write）',
    slPermNoAuthz.status === 403 && slPermNoAuthz.error?.code === 'PERMANENT_REQUIRES_AUTHZ_WRITE', JSON.stringify(slPermNoAuthz.error))

  const slPerm = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: admin, body: { path: slPath, permanent: true } })
  check('永久链接签发（策略开启后）：exp=0 + expiresAt=null + 档位标注「永久」',
    slPerm.ok && slPerm.data.permanent === true && slPerm.data.expiresAt === null && slPerm.data.url.includes('exp=0') && slPerm.data.ttlLabel === '永久',
    JSON.stringify(slPerm.error ?? slPerm.data))

  // 机器身份签发拒绝（明确错误，不静默降级）
  const slMachRole = await api('POST', '/api/iam/roles', { token: admin, body: { name: '分享链接机器自测', code: 'sharelink_machine_selftest', description: 'selftest', permissions: ['nas.read', 'nas.write'] } })
  const slMachCred = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'sharelink-machine', refType: 'external', roleIds: slMachRole.ok ? [slMachRole.data.id] : [], scopes: [] } })
  const slMachLogin = await api('POST', '/api/auth/client-credentials', { body: { clientId: slMachCred.data?.clientId, clientSecret: slMachCred.data?.clientSecret } })
  const slMachIssue = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: slMachLogin.data?.token, body: { path: slPath, ttlSec: 3600 } })
  check('机器身份签发拒绝（403 MACHINE_ISSUANCE_UNSUPPORTED，收紧而非放宽）',
    slMachIssue.status === 403 && slMachIssue.error?.code === 'MACHINE_ISSUANCE_UNSUPPORTED', JSON.stringify(slMachIssue.error))

  // 决策①：独立长期密钥与令牌密钥隔离——轮换令牌签名密钥后，未过期 share-link 仍可取流
  const rotateAuthn = await api('POST', '/api/authn/rotate-secret', { token: admin })
  const slAfterRotate = await slReq(slDefault.data.url)
  check('独立密钥隔离（决策①）：轮换令牌签名密钥后 share-link 仍可取流',
    rotateAuthn.ok && slAfterRotate.ok, JSON.stringify({ rotate: rotateAuthn.error, stream: slAfterRotate.status }))

  // 长期密钥显式轮换（决策① (a) 永久退役集合）：旧链接凭退役密钥仍可取流，新签发 keyId 更替
  const slPreRotate = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: admin, body: { path: slPath, ttlSec: 3600 } })
  const slRotate = await api('POST', '/api/nas/authz/share-link-secret/rotate', { token: admin, body: { note: 'selftest 轮换' } })
  const slPreStream = await slReq(slPreRotate.data.url)
  const slPostRotate = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: admin, body: { path: slPath, ttlSec: 3600 } })
  const slKeyList = await api('GET', `/api/nas/${nasId}/fs/share-links`, { token: admin })
  const slKeyOf = (jti) => (slKeyList.data?.items ?? []).find((item) => item.id === jti)?.keyId
  check('长期密钥轮换（决策① (a)）：旧链接凭退役密钥仍可取流，新签发 keyId 更替',
    slRotate.ok && slPreStream.ok && slPostRotate.ok && !!slKeyOf(slPreRotate.data.jti) && slKeyOf(slPreRotate.data.jti) !== slKeyOf(slPostRotate.data.jti),
    JSON.stringify({ rotate: slRotate.error, stream: slPreStream.status, keyA: slKeyOf(slPreRotate.data?.jti), keyB: slKeyOf(slPostRotate.data?.jti) }))

  // 吊销即时生效 + 重复吊销幂等
  const slRevokeTarget = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: admin, body: { path: slPath, ttlSec: 3600 } })
  const slRevokePre = await slReq(slRevokeTarget.data.url)
  const slRevoke = await api('POST', `/api/nas/${nasId}/fs/share-links/${slRevokeTarget.data.jti}/revoke`, { token: admin, body: { reason: 'selftest 吊销' } })
  const slRevokePost = await slReq(slRevokeTarget.data.url)
  const slRevokeAgain = await api('POST', `/api/nas/${nasId}/fs/share-links/${slRevokeTarget.data.jti}/revoke`, { token: admin, body: {} })
  check('吊销即时生效（吊销前 200 → 吊销后 401）且重复吊销幂等 200',
    slRevokePre.ok && slRevoke.ok && slRevokePost.status === 401 && slRevokeAgain.ok && slRevokeAgain.data.alreadyRevoked === true,
    JSON.stringify({ pre: slRevokePre.status, post: slRevokePost.status, revoke: slRevoke.error, again: slRevokeAgain.error ?? slRevokeAgain.data }))

  // 批量吊销（按签发者）：「某人离职 → 一次性吊销其全部链接」场景
  const slBatch1 = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: slIssuer, body: { path: slPath, ttlSec: 3600 } })
  const slBatch2 = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: slIssuer, body: { path: slPath, ttlSec: 3600 } })
  const slBatch = await api('POST', `/api/nas/${nasId}/fs/share-links/revoke`, { token: admin, body: { userId: slIssuerUid, reason: 'selftest 离职场景' } })
  const slBatch1Post = await slReq(slBatch1.data.url)
  const slBatch2Post = await slReq(slBatch2.data.url)
  check('批量吊销（按签发者，离职场景）：两条链接一并失效',
    slBatch1.ok && slBatch2.ok && slBatch.ok && slBatch.data.revoked >= 2 && slBatch1Post.status === 401 && slBatch2Post.status === 401,
    JSON.stringify({ revoked: slBatch.data?.revoked, e1: slBatch1Post.status, e2: slBatch2Post.status, err: slBatch.error }))

  // 权限复核关（核心增量）：签发者数据权限回收（显式 deny 例外命中）后，原链接取流 403 且产生判定留痕
  const slRecheck = await api('POST', `/api/nas/${nasId}/fs/share-link`, { token: slIssuer, body: { path: slPath, ttlSec: 3600 } })
  const slRecheckPre = await slReq(slRecheck.data.url)
  const slDenyExc = await api('POST', '/api/nas/authz/exceptions', { token: admin, body: { effect: 'deny', nasId, path: slPath, ops: ['download'], userIds: [slIssuerUid], note: 'selftest 复核关：签发者数据权限回收' } })
  const slRecheckPost = await slReq(slRecheck.data.url)
  const slDecisionTrail = await api('GET', `/api/nas/authz/decisions?userId=${slIssuerUid}&op=download&limit=10`, { token: admin })
  check('权限复核（核心增量）：签发者数据权限回收后原链接 403 且产生 nas.authz.decision 留痕',
    slRecheck.ok && slRecheckPre.ok && slDenyExc.ok && slRecheckPost.status === 403
      && (slDecisionTrail.data?.items ?? []).some((item) => item.decision === 'deny' && item.op === 'download' && item.caller === 'nas.share-link'),
    JSON.stringify({ pre: slRecheckPre.status, post: slRecheckPost.status, exc: slDenyExc.error, trail: slDecisionTrail.error ?? slDecisionTrail.data?.items?.[0] }))
  // 残留说明：deny 例外按 merge-only 语义无法经 API 移除；其作用域锁死在
  // slIssuerUid × slPath × download，与后续任何夹具/断言无交集，留在规则里无害。

  // 收尾：永久链接可吊销 + 策略回关 allowPermanent=false（决策③ A1 起步姿态）
  const slPermRevoke = await api('POST', `/api/nas/${nasId}/fs/share-links/${slPerm.data.jti}/revoke`, { token: admin, body: { reason: 'selftest 收尾：永久档清场' } })
  const slPermPost = await slReq(slPerm.data.url)
  const polOff = await api('PUT', '/api/nas/authz/share-link-policy', { token: admin, body: { allowPermanent: false } })
  check('永久链接可吊销（吊销后 401）+ 策略回关 allowPermanent=false（决策③ A1 起步姿态）',
    slPermRevoke.ok && slPermPost.status === 401 && polOff.ok && polOff.data.allowPermanent === false,
    JSON.stringify({ post: slPermPost.status, revoke: slPermRevoke.error, pol: polOff.error }))

  // 负责人映射走 userid 口径（钉钉 dept_manager_userid_list 是 userid，经 userid 链反查平台 userId）
  const orgsForLeaders = (await api('GET', '/api/iam/orgs', { token: admin })).data
  check('部门负责人随同步映射（managerRemoteIds userid 口径 → identityLinks 反查）',
    orgsForLeaders.some((org) => org.name === 'AI 平台部' && (org.leaderUserIds ?? []).includes(linxmUid)),
    JSON.stringify(orgsForLeaders.filter((org) => org.name === 'AI 平台部').map((org) => ({ leaders: org.leaderUserIds }))))

  // 一人多部门兼任（同步落库）：primaryOrgId=主归属锚，orgId=挂靠；引擎兼任子树只读，双身份权限不冲突
  const zhmlCandidates = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('周明澜'), { token: admin })).data.users
    .filter((user) => user.primaryOrgId && user.orgId && user.primaryOrgId !== user.orgId)
  const zhmlHit = { rec: undefined, secWrite: undefined }
  for (const cand of zhmlCandidates) {
    const primaryWrite = await authzCheck(cand.id, ['/元冰可集团/技术中心/前端部/主归属.txt'], 'write')
    const secRead = await authzCheck(cand.id, ['/元冰可集团/技术中心/后端部/兼任目录.txt'], 'read')
    const secWrite = await authzCheck(cand.id, ['/元冰可集团/技术中心/后端部/兼任目录.txt'], 'write')
    if (primaryWrite.data?.decision === 'allow' && secRead.data?.decision === 'allow' && secWrite.data?.decision === 'deny') {
      Object.assign(zhmlHit, { rec: cand, secWrite })
      break
    }
  }
  check('多部门成员兼任落库（primaryOrgId=主部门，orgId=挂靠部门）', Boolean(zhmlHit.rec),
    JSON.stringify(zhmlCandidates.map((user) => ({ primaryOrgId: user.primaryOrgId, orgId: user.orgId }))))
  check('兼任权限不冲突：主归属可写、兼任子树只读（secondary-readonly）',
    Boolean(zhmlHit.rec) && zhmlHit.secWrite.data.reasons.some((r) => r.includes('secondary-readonly')),
    JSON.stringify(zhmlHit.secWrite.data))

  // 权限点：无角色 403 / 无 nas.authz.read 403
  const authzMemberLogin = await api('POST', '/api/auth/login', { body: { username: 'yqz', password: 'Ybk@2026' } })
  const authzMemberToken = authzMemberLogin.data?.token
  const noPermCheck = await api('POST', '/api/nas/authz/check', { token: authzMemberToken, body: { nasId, userId: yqzUid, paths: ['/x'], op: 'read' } })
  const noPermRules = await api('GET', '/api/nas/authz/rules', { token: authzMemberToken })
  check('无 nas.authz.check 权限 403；无 nas.authz.read 403', noPermCheck.status === 403 && noPermRules.status === 403)

  // 特殊账号：未落班组只读 / 挂根 deny / 外部白名单 / 可疑标记 / 兼任
  const yqzRead = await authzCheck(yqzUid, ['/元冰可集团/产品运营部/计划.xlsx'], 'read')
  const yqzWrite = await authzCheck(yqzUid, ['/元冰可集团/产品运营部/计划.xlsx'], 'write')
  check('未落班组（部门根非负责人）→ 只读', yqzRead.data?.decision === 'allow' && yqzWrite.data?.decision === 'deny')
  const auditCheck = await authzCheck(auditUid, ['/元冰可集团/任何/x'], 'read')
  check('挂根组织非负责人 → deny 全部', auditCheck.data?.decision === 'deny' && auditCheck.data.reasons.some((r) => r.includes('root-no-role')))

  const extUser = await api('POST', '/api/iam/users', { token: admin, body: { username: 'extguest', displayName: '外部顾问', orgId: orgAiId, password: 'Ybk@2026' } })
  const extUid = extUser.data?.id
  await api('PATCH', `/api/iam/users/${extUid}`, { token: admin, body: { accountType: 'external' } })
  const rulesBeforeExt = await api('GET', '/api/nas/authz/rules', { token: admin })
  const extPut = await api('PUT', '/api/nas/authz/rules', {
    token: admin,
    body: { ifVersion: rulesBeforeExt.data.version, externalReadPaths: [{ nasId, path: '/元冰可集团/技术中心/AI 平台部/公共' }] },
  })
  check('外部账号白名单只读（白名单内 read 放行/write 拒绝、白名单外 deny）',
    extPut.ok
    && (await authzCheck(extUid, ['/元冰可集团/技术中心/AI 平台部/公共/手册.pdf'], 'read')).data?.decision === 'allow'
    && (await authzCheck(extUid, ['/元冰可集团/技术中心/AI 平台部/公共/手册.pdf'], 'write')).data?.decision === 'deny'
    && (await authzCheck(extUid, ['/元冰可集团/技术中心/AI 平台部/私密.pdf'], 'read')).data?.decision === 'deny')

  await api('PATCH', `/api/iam/users/${heqwUid}`, { token: admin, body: { accountType: 'suspended-review' } })
  const suspended = await authzCheck(heqwUid, ['/元冰可集团/技术中心/前端部/x'], 'read')
  await api('PATCH', `/api/iam/users/${heqwUid}`, { token: admin, body: { accountType: 'internal' } })
  check('可疑标记账号 deny + 转人工留痕', suspended.data?.decision === 'deny' && suspended.data.reasons.some((r) => r.includes('suspended-review')))

  // 兼任：suyq 主归属 AI 平台部（M），挂靠后端部 → 后端部子树只读
  await api('PATCH', `/api/iam/users/${suyqUid}`, { token: admin, body: { primaryOrgId: orgAiId } })
  const secWrite = await authzCheck(suyqUid, ['/元冰可集团/技术中心/后端部/接口.md'], 'write')
  const secRead = await authzCheck(suyqUid, ['/元冰可集团/技术中心/后端部/接口.md'], 'read')
  const priWrite = await authzCheck(suyqUid, ['/元冰可集团/技术中心/AI 平台部/模型.md'], 'write')
  check('兼任账号：主归属正常写 + 兼任子树仅只读',
    priWrite.data?.decision === 'allow' && secRead.data?.decision === 'allow' && secWrite.data?.decision === 'deny')
  await api('PATCH', `/api/iam/users/${suyqUid}`, { token: admin, body: { primaryOrgId: '' } })

  // —— rules 乐观锁 + 种子导入幂等 ——
  const conflict = await api('PUT', '/api/nas/authz/rules', { token: admin, body: { ifVersion: 999, observeOnly: false } })
  check('rules PUT ifVersion 乐观锁冲突 409', conflict.status === 409 && conflict.error?.code === 'VERSION_CONFLICT')
  const rulesNow1 = await api('GET', '/api/nas/authz/rules', { token: admin })
  const cGroupPut = await api('PUT', '/api/nas/authz/rules', { token: admin, body: { ifVersion: rulesNow1.data.version, cGroups: ['AI 平台部全员'] } })
  check('rules PUT 携正确 ifVersion 成功且 version 递增', cGroupPut.ok && cGroupPut.data.version === rulesNow1.data.version + 1)

  const importOnce = await api('POST', '/api/nas/authz/rules/import', { token: admin, body: NAS_AUTHZ_SEED })
  const importTwice = await api('POST', '/api/nas/authz/rules/import', { token: admin, body: NAS_AUTHZ_SEED })
  check('种子导入：首次变更（cGroups 清空为未解析组）+ 再次导入幂等',
    importOnce.ok && importOnce.data.changed === true && importOnce.data.unresolvedGroups.includes('跨域协作者')
    && importTwice.ok && importTwice.data.changed === false && importTwice.data.version === importOnce.data.version,
    JSON.stringify({ once: importOnce.data, twice: importTwice.data, err: importOnce.error }))

  // 恢复 C 组并断言组标记回写
  const rulesNow2 = await api('GET', '/api/nas/authz/rules', { token: admin })
  await api('PUT', '/api/nas/authz/rules', { token: admin, body: { ifVersion: rulesNow2.data.version, cGroups: ['AI 平台部全员'] } })
  const aiGroups = (await api('GET', '/api/iam/groups', { token: admin })).data?.groups ?? []
  const aiGroupMarked = aiGroups.find((group) => group.name === 'AI 平台部全员')
  check('C 关联动态组标记回写（authzRoleC）', aiGroupMarked?.authzRoleC === true,
    JSON.stringify({ groups: aiGroups.map((group) => ({ name: group.name, c: group.authzRoleC })) }))

  // C 叠加（动态组）：跨域只读
  const cRead = await authzCheck(linxmUid, ['/元冰可集团/产品运营部/大盘.xlsx'], 'read')
  const cWrite = await authzCheck(linxmUid, ['/元冰可集团/产品运营部/大盘.xlsx'], 'write')
  check('C 叠加：跨域 read 放行/write 拒绝', cRead.data?.decision === 'allow' && cWrite.data?.decision === 'deny' && cRead.data.cTag === true,
    JSON.stringify({ read: cRead.data, write: cWrite.data }))

  // override 破窗（须 nas.authz.write；admin 具备）+ 留痕
  const overrideCheck = await api('POST', '/api/nas/authz/check', { token: admin, body: { nasId, userId: linxmUid, paths: ['/故障处置/任意'], op: 'delete', override: true } })
  const decisionsOverride = (await api('GET', '/api/nas/authz/decisions?userId=' + linxmUid + '&limit=50', { token: admin })).data?.items ?? []
  check('override 破窗放行并强制留痕',
    overrideCheck.data?.decision === 'allow' && overrideCheck.data.override === true
    && decisionsOverride.some((record) => record.override === true && record.highRisk === true))

  // X-On-Behalf-User：平台 userId → 绑钉钉身份后透传三方 userId（网关 stub 已记录该头）
  const headerBefore = nasGwCalls.find((call) => call.onBehalf === adminUid)
  await api('POST', `/api/iam/users/${adminUid}/bindings`, { token: admin, body: { provider: 'dingtalk', unionId: 'dd_admin_x', displayName: '沈亦澜' } })
  await api('GET', `/api/nas/${nasId}/fs?path=/`, { token: admin })
  const lastCall = nasGwCalls[nasGwCalls.length - 1]
  check('X-On-Behalf-User 头透传（平台 userId → 钉钉身份优先；身份零进工具参数）',
    Boolean(headerBefore) && lastCall.onBehalf === 'dd_admin_x' && !('actorId' in (lastCall.args ?? {})) && !('actorName' in (lastCall.args ?? {})))

  // fail-closed 告警：observeOnly=false 后高频 deny 触发告警规则
  const alertRule = await api('POST', '/api/audit/alert-rules', { token: admin, body: { name: 'NAS 数据权限高频拒绝', metric: 'nas_authz_denied', threshold: 5, windowMinutes: 10, severity: 'warning' } })
  const rulesNow3 = await api('GET', '/api/nas/authz/rules', { token: admin })
  await api('PUT', '/api/nas/authz/rules', { token: admin, body: { ifVersion: rulesNow3.data.version, observeOnly: false } })
  for (let i = 0; i < 12; i++) {
    await authzCheck(linxmUid, ['/元冰可集团/市场部/超出作用域.txt'], 'write')
  }
  const denyAlerts = (await api('GET', '/api/audit/alerts', { token: admin })).data?.alerts ?? []
  check('enforce（observeOnly=false）高频 deny → nas_authz_denied 告警触发',
    alertRule.ok && denyAlerts.some((alert) => alert.title.includes('NAS 数据权限高频拒绝')),
    JSON.stringify({ ruleOk: alertRule.ok, titles: denyAlerts.slice(0, 5).map((alert) => alert.title) }))
  const rulesNow4 = await api('GET', '/api/nas/authz/rules', { token: admin })
  await api('PUT', '/api/nas/authz/rules', { token: admin, body: { ifVersion: rulesNow4.data.version, observeOnly: true } })
  const decisionsDeny = (await api('GET', `/api/nas/authz/decisions?decision=deny&nasId=${nasId}&limit=10`, { token: admin })).data
  check('deny 判定留痕可查询（decisions 集合）', decisionsDeny.total >= 12)

  // —— share 审批闭环（T/M share 默认 deny → 申请 → 审批人自动路由 → 通过 → 例外生效 → 到期自动拒绝）——
  const shareDeny = await authzCheck(linxmUid, ['/元冰可集团/技术中心/AI 平台部/季度报告.docx'], 'share')
  check('M share 默认 deny（提示走审批）', shareDeny.data?.decision === 'deny' && shareDeny.data.reasons.some((r) => r.includes('审批')))
  const shareReq = await api('POST', '/api/nas/authz/exceptions', {
    token: admin,
    body: { status: 'pending', nasId, userId: linxmUid, path: '/元冰可集团/技术中心/AI 平台部/季度报告.docx', reason: '客户演示需要' },
  })
  check('share 申请 → 审批人自动路由（沿组织链向上最近负责人：AI 平台部自身的连接器同步负责人）',
    shareReq.ok && shareReq.data.kind === 'approval' && shareReq.data.approverSuggestion?.orgName === 'AI 平台部'
    && Array.isArray(shareReq.data.approverSuggestion?.leaderUserIds) && shareReq.data.approverSuggestion.leaderUserIds.includes(linxmUid)
    && shareReq.data.escalated === false,
    JSON.stringify(shareReq.data))
  const shareApprove = await api('POST', `/api/approvals/${shareReq.data.approvalId}/decide`, { token: admin, body: { decision: 'approve', opinion: '同意', confirmed: true } })
  const shareAllow = await authzCheck(linxmUid, ['/元冰可集团/技术中心/AI 平台部/季度报告.docx'], 'share')
  check('审批通过 → share 例外自动写入并放行（7 天有效期留痕）', shareApprove.ok && shareAllow.data?.decision === 'allow' && Boolean(shareAllow.data.ruleId))
  const rulesNow5 = await api('GET', '/api/nas/authz/rules', { token: admin })
  const expiredExceptions = rulesNow5.data.exceptions.map((exception) => (
    exception.id === shareAllow.data.ruleId ? { ...exception, expiresAt: '2026-08-01T00:00:00Z' } : exception))
  await api('PUT', '/api/nas/authz/rules', { token: admin, body: { ifVersion: rulesNow5.data.version, exceptions: expiredExceptions } })
  const shareExpired = await authzCheck(linxmUid, ['/元冰可集团/技术中心/AI 平台部/季度报告.docx'], 'share')
  check('share 例外到期自动拒绝（回落矩阵 deny）', shareExpired.data?.decision === 'deny')

  // —— 负责人悬空 / 组织目录对账 ——
  const vacantOrg = await api('POST', '/api/iam/orgs', { token: admin, body: { name: '应急小组（无负责人）', parentId: orgRootId } })
  await api('POST', '/api/iam/users', { token: admin, body: { username: 'vacantm', displayName: '悬空样本', orgId: vacantOrg.data.id, password: 'Ybk@2026' } })
  const vacancy = await api('POST', '/api/nas/authz/leader-vacancy-scan', { token: admin })
  const vacancyAlerts = (await api('GET', '/api/audit/alerts', { token: admin })).data?.alerts ?? []
  check('负责人悬空扫描：新悬空组织被发现 + leaderVacant 告警',
    vacancy.ok && (vacancy.data.vacant ?? []).some((org) => org.orgName === '应急小组（无负责人）')
    && vacancyAlerts.some((alert) => alert.title.includes('负责人悬空')),
    JSON.stringify({ vacant: vacancy.data?.vacant?.map((org) => org.orgName) }))

  // —— 负责人手动绑定（手动锁定优先于连接器同步，leaderVacant 处置入口）——
  const mstUid = userAll.find((user) => user.jobNumber === 'DD0008')?.id // 孟疏桐：mock 目录市场部负责人的同步口径
  check('负责人手动绑定夹具就绪（市场部同步负责人 DD0008）', Boolean(mstUid))
  await api('PATCH', `/api/iam/orgs/${vacantOrg.data.id}`, { token: admin, body: { leaderUserIds: [mstUid] } })
  const pinnedSample = (await api('GET', '/api/iam/orgs', { token: admin })).data.find((org) => org.id === vacantOrg.data.id)
  const vacancyPinned = await api('POST', '/api/nas/authz/leader-vacancy-scan', { token: admin })
  check('负责人手动绑定：落库 + leaderSource=manual + 悬空扫描不再命中',
    pinnedSample?.leaderSource === 'manual' && JSON.stringify(pinnedSample?.leaderUserIds) === JSON.stringify([mstUid])
    && !(vacancyPinned.data?.vacant ?? []).some((org) => org.orgId === vacantOrg.data.id),
    JSON.stringify({ leaders: pinnedSample?.leaderUserIds, source: pinnedSample?.leaderSource }))

  const mktId = orgByName('市场部')
  await api('PATCH', `/api/iam/orgs/${mktId}`, { token: admin, body: { leaderUserIds: [linxmUid] } })
  const resyncGuard = await api('POST', '/api/iam/connectors/dingtalk/sync', { token: admin })
  const mktAfterSync = (await api('GET', '/api/iam/orgs', { token: admin })).data.find((org) => org.id === mktId)
  check('手动锁定不被连接器同步覆盖（同步跳过 manual 组织并在消息计数）',
    resyncGuard.ok && String(resyncGuard.data?.message ?? '').includes('手动锁定')
    && mktAfterSync?.leaderSource === 'manual' && JSON.stringify(mktAfterSync?.leaderUserIds) === JSON.stringify([linxmUid]),
    JSON.stringify({ msg: resyncGuard.data?.message, mkt: mktAfterSync?.leaderUserIds, src: mktAfterSync?.leaderSource }))

  await api('PATCH', `/api/iam/orgs/${mktId}`, { token: admin, body: { leaderUserIds: [] } })
  const mktCleared = (await api('GET', '/api/iam/orgs', { token: admin })).data.find((org) => org.id === mktId)
  check('清空负责人恢复跟随同步（leaderSource 回 sync）',
    mktCleared?.leaderSource === 'sync' && (mktCleared?.leaderUserIds ?? []).length === 0,
    JSON.stringify({ src: mktCleared?.leaderSource }))
  const resyncRestore = await api('POST', '/api/iam/connectors/dingtalk/sync', { token: admin })
  const mktRestored = (await api('GET', '/api/iam/orgs', { token: admin })).data.find((org) => org.id === mktId)
  check('恢复跟随同步后负责人由同步回填（孟疏桐 DD0008）',
    resyncRestore.ok && JSON.stringify(mktRestored?.leaderUserIds) === JSON.stringify([mstUid]),
    JSON.stringify({ mkt: mktRestored?.leaderUserIds, err: resyncRestore.error }))
  await api('PATCH', `/api/iam/orgs/${vacantOrg.data.id}`, { token: admin, body: { leaderUserIds: [] } })

  const reconcile = await api('POST', '/api/nas/authz/reconcile', { token: admin })
  const reconcileReport = reconcile.data?.report ?? []
  const reconcileFindings = reconcileReport.flatMap((row) => row.findings ?? [])
  const reconcileAlerts = (await api('GET', '/api/audit/alerts', { token: admin })).data?.alerts ?? []
  check('组织↔目录对账：目录无组织 + 组织无目录 双向发现并告警',
    reconcile.ok && reconcileFindings.some((f) => f.kind === 'dir-without-org' && f.name === 'homes')
    && reconcileFindings.some((f) => f.kind === 'org-without-dir' && f.name === '市场部')
    && reconcileAlerts.some((alert) => alert.title.includes('组织目录对账')),
    JSON.stringify({ report: reconcileReport, titles: reconcileAlerts.slice(0, 5).map((alert) => alert.title), err: reconcile.error }))

  // —— 多 NAS：B 平台 NAS deny ——
  const authzNas2Reg = await api('POST', '/api/nas', { token: admin, body: { name: '财务 NAS（数据权限对账）', attrs: { description: '多 NAS 作用域隔离自测', gatewayUrl: `http://127.0.0.1:${NAS_GW_PORT}/mcp`, accessToken: NAS_GW_TOKEN, nasIp: NAS_GW_IP, rootPath: '/', orgRoot: '市场部' } } })
  const authzNas2Id = authzNas2Reg.data?.id
  const crossNas = await authzCheck(linxmUid, ['/任何/x'], 'read', { nasId: authzNas2Id })
  check('多 NAS：A 平台成员对 B 平台 NAS deny（orgRoot 不在其组织链）',
    authzNas2Reg.ok && crossNas.data?.decision === 'deny' && crossNas.data.reasons.some((r) => r.includes('nas.no-scope')))

  // —— 组织改名演练：orgPathOverrides 映射表优先，作用域不漂移 ——
  await api('PATCH', `/api/nas/${nasId}`, { token: admin, body: { attrs: { orgPathOverrides: JSON.stringify({ [orgAiId]: '/研发' }) } } })
  const overrideScope1 = await authzCheck(linxmUid, ['/研发/模型卡.md'], 'read')
  await api('PATCH', `/api/iam/orgs/${orgAiId}`, { token: admin, body: { name: '创新部门' } })
  const overrideScope2 = await api('GET', `/api/nas/authz/scope?nasId=${nasId}&userId=${linxmUid}`, { token: admin })
  check('组织改名演练：映射表命中 → 改名前后作用域均为 /研发（不漂移）',
    overrideScope1.data?.decision === 'allow' && JSON.stringify(overrideScope2.data.scope) === JSON.stringify(['/研发']))
  await api('PATCH', `/api/iam/orgs/${orgAiId}`, { token: admin, body: { name: 'AI 平台部' } })
  await api('PATCH', `/api/nas/${nasId}`, { token: admin, body: { attrs: { orgPathOverrides: '' } } })

  // —— C 组漂移告警（R5）——
  await api('POST', '/api/iam/groups/refresh-snapshots', { token: admin })
  const driftUser = await api('POST', '/api/iam/users', { token: admin, body: { username: 'driftu', displayName: '漂移样本', orgId: orgFeId, password: 'Ybk@2026' } })
  await api('PATCH', `/api/iam/users/${driftUser.data.id}`, { token: admin, body: { orgId: orgAiId } })
  const driftRefresh = await api('POST', '/api/iam/groups/refresh-snapshots', { token: admin })
  const authzDriftAlerts = (await api('GET', '/api/audit/alerts', { token: admin })).data?.alerts ?? []
  check('C 组重算漂移 → cGroupDrift 告警（C 关联组任何漂移都告警）',
    driftRefresh.ok && (driftRefresh.data.drifts ?? []).some((drift) => drift.groupName === 'AI 平台部全员' && drift.alerted)
    && authzDriftAlerts.some((alert) => alert.title.includes('成员漂移')),
    JSON.stringify({ drifts: driftRefresh.data?.drifts, titles: authzDriftAlerts.slice(0, 5).map((alert) => alert.title) }))

  // deny 留痕保留策略：普通 deny 记录带 highRisk=false（高危 delete/share/admin 永久保留）
  const shareDecisionRows = (await api('GET', `/api/nas/authz/decisions?decision=allow&nasId=${nasId}&limit=50`, { token: admin })).data?.items ?? []
  check('高危 op（share）留痕 highRisk 标记（永久保留策略依据）', shareDecisionRows.some((record) => record.op === 'share' && record.highRisk === true))

  // ================================================================ Skill 包 NAS 存储
  section('Skill 包 NAS 存储（上架自动打包上传）')
  const storageDeny = await api('PUT', '/api/skill-storage', { token: dev, body: { mode: 'nas', nasId, basePath: '/skillhub' } })
  check('无 skill.storage.write 配置存储被拒（403）', storageDeny.status === 403)
  const storageSet = await api('PUT', '/api/skill-storage', { token: admin, body: { mode: 'nas', nasId, basePath: '/skillhub' } })
  check('配置包存储后端为已纳管 NAS 资产', storageSet.ok && storageSet.data.mode === 'nas' && storageSet.data.nasId === nasId && storageSet.data.basePath === '/skillhub')

  // ① 提交自带 zip：上架时原样上传 NAS
  const zipBuffer = Buffer.concat([Buffer.from('PK\x03\x04', 'latin1'), Buffer.from('selftest-skill-zip-payload')])
  const pkgSubmit = await api('POST', '/api/skills', { token: admin, body: { name: '自测打包技能', content: '# 自测打包技能\n\n## 何时使用\n验证 skill.zip 随提交上传 NAS 的全链路。\n\n## 步骤\n提交即携带包内容。', category: '通用', version: '1.0.0', packageBase64: zipBuffer.toString('base64') } })
  check('提交可携带 skill.zip（hasPackage）', pkgSubmit.ok && pkgSubmit.data.hasPackage === true, JSON.stringify(pkgSubmit.error))
  const pkgSkillId = pkgSubmit.data?.id
  const badZip = await api('POST', '/api/skills', { token: admin, body: { name: '坏包技能', content: '# x', category: '通用', packageBase64: Buffer.from('not-a-zip').toString('base64') } })
  check('非 ZIP 内容（缺 PK 魔数）提交被拒', !badZip.ok)
  await api('POST', `/api/skills/${pkgSkillId}/approve`, { token: admin, body: { level: 'domain', decision: 'approve', opinion: 'selftest' } })
  const uploadsBefore = nasGwUploads.length
  const pkgPublish = await api('POST', `/api/skills/${pkgSkillId}/publish`, { token: admin, body: {} })
  const pkgUploaded = nasGwUploads[nasGwUploads.length - 1]
  check('上架自动上传 NAS（fs_upload 收到包）', pkgPublish.ok && nasGwUploads.length === uploadsBefore + 1, JSON.stringify(pkgPublish.error))
  check('上传产物即提交的 zip（字节级一致）', pkgUploaded?.magic === 'PK' && pkgUploaded.sizeBytes === zipBuffer.length && pkgUploaded.content.equals(zipBuffer))
  check('上传路径契约 <basePath>/<slug>/<slug>-<version>.zip', typeof pkgUploaded?.destPath === 'string' && pkgUploaded.destPath.startsWith('/skillhub/') && typeof pkgUploaded?.filename === 'string' && pkgUploaded.filename.endsWith('-1.0.0.zip') && pkgUploaded.filename === `${pkgUploaded.destPath.split('/').pop()}-1.0.0.zip`)
  const pkgSkill = await api('GET', `/api/skills/${pkgSkillId}`, { token: admin })
  const pkgVersion = pkgSkill.data?.versions?.find((v) => v.version === '1.0.0')
  check('版本记录回写 package 元数据（storage=nas）', pkgVersion?.package?.storage === 'nas' && pkgVersion.package.nasId === nasId && pkgVersion.package.sizeBytes === zipBuffer.length)
  const pkgDownload = await rawReq('GET', `/api/skills/${pkgSkillId}/package?version=1.0.0`, { headers: { authorization: `Bearer ${admin}` } })
  check('包下载端点返回 zip（PK 头）', pkgDownload.status === 200 && pkgDownload.body.startsWith('PK'))

  // ② 无 zip 提交：上架时由 SKILL.md 现场打包（platform-core zip.ts，零依赖）
  const autoSubmit = await api('POST', '/api/skills', { token: admin, body: { name: '自测自动打包', content: '# 自测自动打包\n\n## 何时使用\n验证无 zip 提交时由 SKILL.md 现场打包上传 NAS。\n\n## 步骤\n提交 → 审批 → 上架。', category: '通用', version: '0.1.0' } })
  await api('POST', `/api/skills/${autoSubmit.data.id}/approve`, { token: admin, body: { level: 'domain', decision: 'approve', opinion: 'selftest' } })
  const autoPublish = await api('POST', `/api/skills/${autoSubmit.data.id}/publish`, { token: admin, body: {} })
  const autoUploaded = nasGwUploads[nasGwUploads.length - 1]
  check('无 zip 时由 SKILL.md 现场打包上传', autoPublish.ok && autoUploaded?.magic === 'PK' && autoUploaded.sizeBytes > 100 && autoUploaded.filename.endsWith('-0.1.0.zip'), JSON.stringify(autoPublish.error))
  check('现场打包产物含 SKILL.md 条目', autoUploaded?.content.toString('latin1').includes('SKILL.md'))

  // ③ fail-closed：存储后端 NAS 非 online → 上架中止且版本不落 published
  const draftNas = await api('POST', '/api/nas', { token: admin, body: { name: '未上线 NAS', attrs: { description: 'fail-closed 验证', gatewayUrl: `http://127.0.0.1:${NAS_GW_PORT}/mcp`, accessToken: NAS_GW_TOKEN, nasIp: NAS_GW_IP, dataClass: 'internal' } } })
  await api('PUT', '/api/skill-storage', { token: admin, body: { mode: 'nas', nasId: draftNas.data.id, basePath: '/skillhub' } })
  const fcSubmit = await api('POST', '/api/skills', { token: admin, body: { name: '自测中止技能', content: '# 自测中止技能\n\n## 何时使用\n验证存储后端 NAS 未上线时上架 fail-closed。\n\n## 步骤\n提交 → 审批 → 上架应中止。', category: '通用', version: '1.0.0' } })
  await api('POST', `/api/skills/${fcSubmit.data.id}/approve`, { token: admin, body: { level: 'domain', decision: 'approve', opinion: 'selftest' } })
  const fcPublish = await api('POST', `/api/skills/${fcSubmit.data.id}/publish`, { token: admin, body: {} })
  check('存储后端 NAS 未上线 → 上架 fail-closed', !fcPublish.ok && JSON.stringify(fcPublish.error).includes('fail-closed'), JSON.stringify(fcPublish.error))
  const fcSkill = await api('GET', `/api/skills/${fcSubmit.data.id}`, { token: admin })
  check('fail-closed 后版本未标记 published', fcSkill.ok && fcSkill.data.versions.every((v) => v.status !== 'published'))
  await api('PUT', '/api/skill-storage', { token: admin, body: { mode: 'local' } })
  const storageBack = await api('GET', '/api/skill-storage', { token: admin })
  check('存储后端可切回 local', storageBack.ok && storageBack.data.config.mode === 'local')

  // ================================================================ 台账与巡检（NAS 接入）
  section('资产台账与巡检（NAS 接入）')
  const inventory = await api('GET', '/api/assets/inventory', { token: admin })
  check('台账包含 nas 资产类型', inventory.ok && inventory.data.items.some((item) => item.type === 'nas') && (inventory.data.summary.byType.nas?.total ?? 0) >= 2)
  const healthcheck = await api('POST', '/api/assets/healthcheck', { token: admin, body: {} })
  check('一键巡检覆盖在线 NAS（initialize 探活 healthy）', healthcheck.ok && healthcheck.data.items.some((item) => item.type === 'nas' && item.status === 'healthy'))

  // 下架分析：弃用/下线原因聚合（审计 change 日志 + Skill 落库原因 + Agent/应用生命周期留痕）
  const retire = await api('GET', '/api/assets/retire-reasons?days=90', { token: admin })
  const retireReasons = retire.data?.reasons ?? []
  check('下架分析（原因聚合，Skill 弃用原因可检索）', retire.ok && retire.data.total >= 2
    && retireReasons.some((row) => row.reason === '自测弃用' && (row.byType.skill ?? 0) >= 1)
    && retireReasons.every((row) => row.reason && row.count >= 1))

  // ================================================================ 平台即 MCP Server（POST /mcp）
  section('平台即 MCP Server（POST /mcp）')
  const mcpAnon = await rawReq('POST', '/mcp', { headers: { 'content-type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'initialize', params: {} }) })
  check('无 Bearer 令牌 401', mcpAnon.status === 401)
  const mcpGet = await rawReq('GET', '/mcp', { headers: { authorization: `Bearer ${admin}` } })
  check('GET SSE 长流不支持（405，纯 JSON 形态合法）', mcpGet.status === 405)
  const mcpInit = await rawReq('POST', '/mcp', {
    headers: { 'content-type': 'application/json', authorization: `Bearer ${admin}` },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2025-03-26', capabilities: {}, clientInfo: { name: 'selftest', version: '1.0' } } }),
  })
  check('initialize 返回 serverInfo/capabilities + 会话头', mcpInit.status === 200 && jsonBody(mcpInit).result?.serverInfo?.name === 'dsh-ops-platform' && typeof mcpInit.headers['mcp-session-id'] === 'string')
  const mcpNotify = await rawReq('POST', '/mcp', {
    headers: { 'content-type': 'application/json', authorization: `Bearer ${admin}` },
    body: JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }),
  })
  check('通知类消息 202 确认', mcpNotify.status === 202)
  const mcpTools = await rawReq('POST', '/mcp', {
    headers: { 'content-type': 'application/json', authorization: `Bearer ${admin}` },
    body: JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'tools/list', params: {} }),
  })
  const mcpToolList = jsonBody(mcpTools).result?.tools ?? []
  check('tools/list 暴露全部运维工具（40+，含 nas_*）', mcpToolList.length >= 40 && mcpToolList.some((t) => t.name === 'nas_fs_upload'), `tools=${mcpToolList.length}`)
  const mcpCall = await rawReq('POST', '/mcp', {
    headers: { 'content-type': 'application/json', authorization: `Bearer ${admin}` },
    body: JSON.stringify({ jsonrpc: '2.0', id: 3, method: 'tools/call', params: { name: 'nas_list', arguments: {} } }),
  })
  const mcpCallResult = jsonBody(mcpCall).result
  check('tools/call 执行成功（content blocks）', mcpCall.status === 200 && mcpCallResult?.isError === false && Array.isArray(mcpCallResult?.content), JSON.stringify(jsonBody(mcpCall)).slice(0, 200))
  const mcpDeny = await rawReq('POST', '/mcp', {
    headers: { 'content-type': 'application/json', authorization: `Bearer ${dev}` },
    body: JSON.stringify({ jsonrpc: '2.0', id: 4, method: 'tools/call', params: { name: 'nas_fs_mkdir', arguments: { nasId, path: '/skillhub/x' } } }),
  })
  const mcpDenyResult = jsonBody(mcpDeny).result
  check('工具级权限点拦截（dev 缺 nas.write → isError）', mcpDeny.status === 200 && mcpDenyResult?.isError === true && JSON.stringify(mcpDenyResult).includes('nas.write'))
  const mcpUnknown = await rawReq('POST', '/mcp', {
    headers: { 'content-type': 'application/json', authorization: `Bearer ${admin}` },
    body: JSON.stringify({ jsonrpc: '2.0', id: 5, method: 'resources/list', params: {} }),
  })
  check('未知方法 -32601', jsonBody(mcpUnknown).error?.code === -32601)

  // ================================================================ 连接器纳管（open-connector 融合）
  section('连接器纳管（open-connector 融合）')
  const waitFor = async (fn, ms = 5000) => {
    const end = Date.now() + ms
    let value
    while (Date.now() < end) {
      value = fn()
      if (value) return value
      await new Promise((resolve) => setTimeout(resolve, 100))
    }
    return fn()
  }

  // -- 网关配置与强制 env fail-closed（T-02 预演探针路径） ----------------------
  const envProbeEnc = await api('GET', `/api/connector/gateway?assumeEnv=${encodeURIComponent(JSON.stringify({ OOMOL_CONNECT_ADMIN_TOKEN: true, OOMOL_CONNECT_ENCRYPTION_KEY: false }))}`, { token: admin })
  check('T-02 缺 OOMOL_CONNECT_ENCRYPTION_KEY → fail-closed 文案', !envProbeEnc.data?.available && String(envProbeEnc.data?.reason ?? '').includes('OOMOL_CONNECT_ENCRYPTION_KEY'), JSON.stringify(envProbeEnc).slice(0, 200))
  const envProbeToken = await api('GET', `/api/connector/gateway?assumeEnv=${encodeURIComponent(JSON.stringify({ OOMOL_CONNECT_ADMIN_TOKEN: false }))}`, { token: admin })
  check('T-02 管理口令未解析 → fail-closed 文案', !envProbeToken.data?.available && String(envProbeToken.data?.reason ?? '').includes('管理口令未解析'), JSON.stringify(envProbeToken).slice(0, 200))

  const gwSet = await api('PUT', '/api/connector/gateway', { token: admin, body: { baseUrl: OC_BASE, adminToken: 'env:OOMOL_CONNECT_ADMIN_TOKEN', autoCatalogSyncMinutes: 0 } })
  check('网关配置（baseUrl + adminToken env: 间接引用）', gwSet.ok && gwSet.data.baseUrl === OC_BASE, JSON.stringify(gwSet).slice(0, 200))
  const gwHealth = await api('POST', '/api/connector/gateway/health', { token: admin })
  check('探活契约（ok/runtime/latencyMs）', gwHealth.ok && gwHealth.data.ok === true && typeof gwHealth.data.latencyMs === 'number')
  const gwState = await api('GET', '/api/connector/gateway', { token: admin })
  check('网关状态可用（healthy + envChecks 双 true）', gwState.ok && gwState.data.available === true && gwState.data.status === 'healthy' && gwState.data.envChecks.OOMOL_CONNECT_ENCRYPTION_KEY === true)

  // -- 目录同步（T-03） --------------------------------------------------------
  const catSync1 = await api('POST', '/api/connector/catalog/sync', { token: admin })
  const catSync1Data = catSync1.data ?? {}
  check('目录同步 providers/actions 计数与 added 清单', catSync1.ok && catSync1Data.providers === 2 && catSync1Data.actions === 7 && catSync1Data.added.length === 7, JSON.stringify(catSync1).slice(0, 300))
  check('非法 service 标识被拒纳管（resource 正则）', (catSync1Data.skippedServices ?? []).some((item) => item.service === 'weird service!'), JSON.stringify(catSync1Data.skippedServices))
  const catalogView = (await api('GET', '/api/connector/catalog', { token: admin })).data
  const riskOf = Object.fromEntries((catalogView.actions ?? []).map((action) => [action.id, action.riskLevel]))
  check('riskLevel 映射（读/写/管理 + 默认 admin 兜底）',
    riskOf['hackernews.get_top_stories'] === 'read' && riskOf['github.create_issue'] === 'write'
    && riskOf['github.delete_webhook'] === 'admin' && riskOf['hackernews.do_the_thing'] === 'admin', JSON.stringify(riskOf))
  const guideRaw = await rawReq('GET', '/api/connector/catalog/actions/hackernews.get_top_stories/guide', { headers: { authorization: `Bearer ${admin}` } })
  check('连接向导 agent.md 代理展示（文本）', guideRaw.status === 200 && guideRaw.body.includes('连接指南'))

  // -- 组织 / 用户（org 隔离锚点） ----------------------------------------------
  const connOrg = (await api('POST', '/api/iam/orgs', { token: admin, body: { name: '连接器测试部' } })).data.id
  const connOrgB = (await api('POST', '/api/iam/orgs', { token: admin, body: { name: '连接器隔离部' } })).data.id
  const devUserSearch = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('陈默'), { token: admin })).data.users[0]
  const connDevLogin = await api('POST', '/api/auth/login', { body: { username: 'dev', password: 'Ybk@2026' } })
  const connAuditLogin = await api('POST', '/api/auth/login', { body: { username: 'audit', password: 'Ybk@2026' } })
  check('测试主体就绪（dev 令牌 / audit 令牌）', Boolean(devUserSearch?.id) && Boolean(connDevLogin.data?.token) && Boolean(connAuditLogin.data?.token))

  // -- 连接管理（T-05/T-06/T-07） -----------------------------------------------
  const apiKeyCreate = await api('POST', '/api/connector/connections/api-key', { token: admin, body: { orgId: connOrg, provider: 'github', aliasSuffix: 'main-pat', values: { apiKey: 'ghp_selftestSecret123' } } })
  check('API Key 表单直达 sidecar（返回 active 引用）', apiKeyCreate.ok && apiKeyCreate.data.reference?.status === 'active' && String(apiKeyCreate.data.reference.ocConnectionId ?? '').startsWith('oc-con-'), JSON.stringify(apiKeyCreate).slice(0, 220))
  const patRef = apiKeyCreate.data.reference

  const oauthMissClient = await api('POST', '/api/connector/connections/oauth', { token: admin, body: { orgId: connOrg, provider: 'github', aliasSuffix: 'oauth-bot' } })
  check('T-06 未存 client 配置 → oauth_client_config_required 透传+自备 App 指引',
    oauthMissClient.ok === false && oauthMissClient.error?.code === 'OAUTH_CLIENT_CONFIG_REQUIRED' && /OAuth App|自备/.test(oauthMissClient.error?.message ?? ''), JSON.stringify(oauthMissClient).slice(0, 240))
  ocClientsConfigured.add('github')
  const oauthStart = await api('POST', '/api/connector/connections/oauth', { token: admin, body: { orgId: connOrg, provider: 'github', aliasSuffix: 'oauth-bot' } })
  check('T-01 OAuth 发起信封 {authorizationUrl,state}', oauthStart.ok && Boolean(oauthStart.data.authorizationUrl) && Boolean(oauthStart.data.state), JSON.stringify(oauthStart).slice(0, 220))
  const callbackHtml = await fetch(`${OC_BASE}/oauth/callback?state=${oauthStart.data.state}&code=fake-code`).then((r) => r.text())
  check('sidecar 回调完成页受理', callbackHtml.includes('授权完成'))
  const oauthConfirm = await api('GET', `/api/connector/connections/oauth/${oauthStart.data.state}/status`, { token: admin })
  check('T-05 回调后状态轮询：引用转 active 且平台不落凭证原文', oauthConfirm.ok && oauthConfirm.data.status === 'active' && oauthConfirm.data.authType === 'oauth', JSON.stringify(oauthConfirm).slice(0, 260))

  // 别名前缀组织校验（T-20 后半）：跨 org 引用别名在权限组校验层拒绝在下方断言。

  // -- 权限组 + oct_ 台账初始镜像（T-11） ----------------------------------------
  const grpAdmin = (await api('POST', '/api/iam/groups', { token: admin, body: { name: '连接器组-A', type: 'static', memberIds: [adminLogin.data.user.id] } })).data
  const grpDev = (await api('POST', '/api/iam/groups', { token: admin, body: { name: '连接器组-B(dev)', type: 'static', memberIds: [devUserSearch.id] } })).data
  check('测试用户组建好', Boolean(grpAdmin?.id) && Boolean(grpDev?.id))

  const crossOrgGroup = await api('POST', '/api/connector/perm-groups', { token: admin, body: {
    name: '非法跨 org 组', orgId: connOrgB,
    policies: { github: { allowedActions: ['github.list_issues'], riskCap: 'read', connections: [`org:${connOrg}:main-pat`] } },
    subjects: [{ type: 'user_group', id: grpAdmin.id }],
  } })
  check('T-20 引用非本组织前缀别名的权限组被拒', crossOrgGroup.ok === false, JSON.stringify(crossOrgGroup).slice(0, 220))

  const pgRead = (await api('POST', '/api/connector/perm-groups', { token: admin, body: {
    name: 'dev 只读组', orgId: connOrg,
    policies: {
      hackernews: { allowedActions: ['hackernews.get_top_stories'], riskCap: 'read', constraints: { readOnly: true } },
      github: { allowedActions: ['*'], riskCap: 'read', connections: [`org:${connOrg}:main-pat`], constraints: { readOnly: true } },
    },
    subjects: [{ type: 'user_group', id: grpDev.id }],
  } })).data
  const pgFull = (await api('POST', '/api/connector/perm-groups', { token: admin, body: {
    name: 'admin 全量组', orgId: connOrg,
    policies: { hackernews: { allowedActions: '*', riskCap: 'admin' }, github: { allowedActions: '*', riskCap: 'admin' }, },
    subjects: [{ type: 'user_group', id: grpAdmin.id }],
  } })).data
  const pgTmp = (await api('POST', '/api/connector/perm-groups', { token: admin, body: {
    name: 'dev 高危通道组', orgId: connOrg,
    policies: { hackernews: { allowedActions: ['hackernews.do_the_thing'], riskCap: 'admin' } },
    subjects: [{ type: 'user_group', id: grpDev.id }],
  } })).data
  check('三个权限组建好（含显式清单/通配/admin 通道）', Boolean(pgRead?.id) && Boolean(pgFull?.id) && Boolean(pgTmp?.id), JSON.stringify({ pgRead, pgFull, pgTmp }).slice(0, 240))

  await waitFor(() => [...ocLedgerTokens.values()].length >= 3)
  const ocReadTokens = [...ocLedgerTokens.entries()].filter(([, rec]) => rec.policy.allowedConnections.length > 0)
  check('T-11 只读组令牌策略镜像逐字段一致',
    ocReadTokens.some(([, rec]) =>
      rec.policy.allowedActions[0] === '*' || JSON.stringify([...rec.policy.allowedActions].sort()) === JSON.stringify(['github.list_issues', 'hackernews.get_top_stories'])
      && rec.policy.allowedProxies.length === 0 && rec.policy.blockedActions.length === 0
      && rec.policy.allowedConnections.join(',') === patRef.ocConnectionId), JSON.stringify(ocReadTokens.map(([, r]) => r.policy)))
  const fullLedgerTokens = [...ocLedgerTokens.entries()].filter(([, rec]) => rec.policy.allowedActions[0] === '*')
  check('T-11 通配组令牌镜像（allowedActions=[\'*\']，无绑定连接则空数组全发）', fullLedgerTokens.length >= 1 && Array.isArray(fullLedgerTokens[0][1].policy.allowedConnections))
  const impactPreview = await api('POST', `/api/connector/perm-groups/${pgRead.id}/impact`, { token: admin })
  check('变更影响面预览（N 令牌/M 连接）', impactPreview.ok && impactPreview.data.tokens >= 1 && impactPreview.data.connections >= 1, JSON.stringify(impactPreview).slice(0, 160))

  // -- 授权链执行（T-08/T-09/T-10 + 三端 dry-run） -------------------------------
  const memberDenied = await api('POST', '/api/connector/execute', { token: connAuditLogin.data.token, body: { actionId: 'hackernews.get_top_stories', input: {} } })
  check('T-08 无 connector.invoke 权限点 → 403 + authz.denied 事件', memberDenied.ok === false && memberDenied.error?.code === 'FORBIDDEN' && memberDenied.status === 403, JSON.stringify(memberDenied).slice(0, 200))

  const devDryRun = await api('POST', '/api/connector/execute', { token: connDevLogin.data.token, body: { actionId: 'hackernews.get_top_stories', input: { limit: 5 }, dryRun: true } })
  check('dry-run 影响面预览（五步链通过、只读约束可见、不真实调用）', devDryRun.ok && devDryRun.data?.status === 'dry_run' && devDryRun.data.preview.riskLevel === 'read' && typeof devDryRun.data.preview.permGroup === 'string' && devDryRun.data.preview.readOnlyConstraint === true, JSON.stringify(devDryRun).slice(0, 300))

  const devOkRun = await api('POST', '/api/connector/execute', { token: connDevLogin.data.token, body: { actionId: 'hackernews.get_top_stories', input: { limit: 5 } } })
  check('授权放行成功调用（runId=executionId + 计量回执）', devOkRun.ok && devOkRun.data?.ok === true && /^exec-/.test(String(devOkRun.data.runId)) && devOkRun.data.metered === true, JSON.stringify(devOkRun).slice(0, 280))
  const devOkUsage = await api('GET', `/api/usage/events?limit=50`, { token: admin })
  check('T-14 usage.record 口径（resource/meters/trace_id/idempotency_key）',
    devOkUsage.ok && devOkUsage.data.items.some((event) =>
      event.resource === 'connector:hackernews' && event.trace_id === devOkRun.data.runId
      && event.idempotency_key === `connector:${devOkRun.data.runId}` && event.meters.some((m) => m.key === 'calls')), JSON.stringify(devOkUsage.data?.items?.slice(0, 2)).slice(0, 240))
  const priceBook = (await api('GET', '/api/usage/price-book', { token: admin })).data
  check('价格簿 connector:* 零费率条目存在（缺规则会被 record 拒绝的反向保障）',
    priceBook.entries.some((entry) => entry.pattern === 'connector:*' && entry.list_cents_per_unit === 0), JSON.stringify(priceBook.entries?.filter((e) => e.pattern.startsWith('connector')) ?? []).slice(0, 160))

  const devWriteDenied = await api('POST', '/api/connector/execute', { token: connDevLogin.data.token, body: { actionId: 'github.create_issue', input: { title: 'x' } } })
  check('T-09 write 级超出 readOnly/riskCap=read → 平台侧拒绝', devWriteDenied.ok && devWriteDenied.data?.status === 'denied' && /(riskCap|只读)/.test(String(devWriteDenied.data.error)), JSON.stringify(devWriteDenied).slice(0, 240))

  const isoLogin = await api('POST', '/api/auth/login', { body: { username: 'suyq', password: 'Ybk@2026' } })
  const isoGroup = (await api('POST', '/api/iam/groups', { token: admin, body: { name: '连接器组-单点', type: 'static', memberIds: [(await api('GET', '/api/iam/users?q=' + encodeURIComponent('苏砚秋'), { token: admin })).data.users[0].id] } })).data
  const pgIso = (await api('POST', '/api/connector/perm-groups', { token: admin, body: {
    name: '单点清单组（pattern-miss 回归）', orgId: connOrg,
    policies: { hackernews: { allowedActions: ['hackernews.get_top_stories'], riskCap: 'read' } },
    subjects: [{ type: 'user_group', id: isoGroup.id }],
  } })).data
  const devPatternMiss = await api('POST', '/api/connector/execute', { token: isoLogin.data.token, body: { actionId: 'hackernews.fetch_item', input: {} } })
  check('T-10 pattern 未命中 → 平台侧拒绝', devPatternMiss.ok && devPatternMiss.data?.status === 'denied' && /允许模式/.test(String(devPatternMiss.data.error)), JSON.stringify(devPatternMiss).slice(0, 260))

  // -- T-15 审计 actChain + runId 反查 -----------------------------------------
  const devAuditTrail = await api('GET', `/api/audit/logs?q=${encodeURIComponent(String(devOkRun.data.runId))}&type=invoke`, { token: admin })
  check('T-15 invoke 日志含 runId（run= 前缀反查命中）',
    devAuditTrail.ok && devAuditTrail.data.items.some((log) => log.resourceType === 'connector_action' && String(log.detail).includes(`run=${devOkRun.data.runId}`)), JSON.stringify(devAuditTrail.data?.items?.slice(0, 2)).slice(0, 240))

  // -- T-22 写类幂等键 + 同键重放不重复计量 ---------------------------------------
  const directAdminMintRes = await fetch(`${OC_BASE}/api/runtime-tokens`, {
    method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${OC_TOKEN}` },
    body: JSON.stringify({ name: 'selftest-direct', allowedActions: ['*'], blockedActions: [], allowedProxies: [], allowedConnections: [] }),
  }).then((r) => r.json())
  const directOct = directAdminMintRes.data.token
  ocMintedValues.push(directOct)
  const replayKey = 'ikey-selftest-0001'
  const directExec = () => fetch(`${OC_BASE}/v1/actions/hackernews.submit_post`, {
    method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${directOct}`, 'idempotency-key': replayKey },
    body: JSON.stringify({ input: { title: '自测幂等帖' } }),
  }).then((r) => r.json())
  const firstReplay = await directExec()
  const secondReplay = await directExec()
  check('T-22 同键重放返回原 executionId（24h 窗口语义）', firstReplay.meta.executionId === secondReplay.meta.executionId, `${firstReplay.meta.executionId} vs ${secondReplay.meta.executionId}`)
  const runsForExec = ocRuns.filter((run) => run.id === firstReplay.meta.executionId)
  check('T-22 重放不产生重复 run（stub 侧单条）', runsForExec.length === 1, String(runsForExec.length))

  // -- 高危审批门禁（T-17） ------------------------------------------------------
  const adminCallResp = await api('POST', '/api/connector/execute', { token: connDevLogin.data.token, body: { actionId: 'hackernews.do_the_thing', input: { work: 1 } } })
  const approvalFlow = adminCallResp.data ?? {}
  check('admin 级 action → 审批单生成且不执行', approvalFlow.status === 'approval_required' && Boolean(approvalFlow.approvalId), JSON.stringify(adminCallResp).slice(0, 260))
  const dupApproval = await api('POST', '/api/connector/execute', { token: connDevLogin.data.token, body: { actionId: 'hackernews.do_the_thing', input: { work: 1 } } })
  check('同图 pending 审批单复用（不重复开单）', dupApproval.data?.approvalId === approvalFlow.approvalId, JSON.stringify(dupApproval).slice(0, 180))
  const beforeCalls = ocCalls.filter((call) => call.actionId === 'hackernews.do_the_thing').length
  const decide = await api('POST', `/api/approvals/${approvalFlow.approvalId}/decide`, { token: admin, body: { decision: 'approve', opinion: '自测批准', confirmed: true } })
  check('审批通过后 executor 同步完成调用（L4 闭环）', decide.ok && String(decide.data.execution?.result ?? '').includes('runId'), JSON.stringify(decide.data?.execution ?? {}).slice(0, 240))
  const afterCalls = ocCalls.filter((call) => call.actionId === 'hackernews.do_the_thing').length
  check('executor 真实下发一次数据面调用', afterCalls === beforeCalls + 1, `before=${beforeCalls} after=${afterCalls}`)

  // -- OPT-P1-02 冒充面封死（能力令牌替代旧布尔旁路） ---------------------------------
  const smuggleResp = await api('POST', '/api/tools/execute', { token: connDevLogin.data.token, body: { name: 'connector_execute', args: { actionId: 'hackernews.do_the_thing', input: { work: 1 }, viaApprovalExecutor: true, approvalCapability: { token: 'forged-by-attacker', actionId: 'hackernews.do_the_thing', callerId: 'attacker', expiresAt: Date.now() + 60_000 } } } })
  const smuggleValue = smuggleResp.data?.value ?? smuggleResp.data ?? {}
  check('P1-02 工具桥走私旧布尔/伪造能力令牌 → 仍强制开单（fail-closed）', smuggleValue?.status === 'approval_required' && Boolean(smuggleValue.approvalId), JSON.stringify(smuggleValue ?? {}).slice(0, 240))
  let booleanBypassHits = 0
  const scanBypass = (dir) => { for (const entry of readdirSync(dir, { withFileTypes: true })) { const filePath = join(dir, entry.name); if (entry.isDirectory()) { if (entry.name !== 'node_modules') scanBypass(filePath) } else if (filePath.endsWith('.ts') && readFileSync(filePath, 'utf8').includes('viaApprovalExecutor')) booleanBypassHits++ } }
  scanBypass('packages'); scanBypass('src')
  check('P1-02 旧布尔旁路全仓 0 命中（能力令牌替代，验收 grep 口径）', booleanBypassHits === 0, `hits=${booleanBypassHits}`)

  // -- connector.connect 两段式审批门禁（T-18，凭证不入审批负载） -------------------
  const gatedConnectReq = await api('POST', '/api/connector/connections/api-key', { token: admin, body: { orgId: connOrg, provider: 'github', aliasSuffix: 'gated-pat', values: { apiKey: 'client-supersecret-oauth-xyz' }, requireApproval: true } })
  check('T-18 requireApproval → 仅生成审批单（凭证不落任何集合）', gatedConnectReq.data?.approvalRequired === true && Boolean(gatedConnectReq.data.approvalId), JSON.stringify(gatedConnectReq).slice(0, 200))
  await api('POST', `/api/approvals/${gatedConnectReq.data.approvalId}/decide`, { token: approver, body: { decision: 'approve', confirmed: true } })
  const gatedFinalize = await api('POST', '/api/connector/connections/api-key', { token: admin, body: { orgId: connOrg, provider: 'github', aliasSuffix: 'gated-pat', values: { apiKey: 'client-supersecret-oauth-xyz' }, approvalId: gatedConnectReq.data.approvalId } })
  check('审批通过后携 approvalId 完成实际创建', gatedFinalize.ok && gatedFinalize.data.reference?.status === 'active', JSON.stringify(gatedFinalize).slice(0, 220))

  // -- T-12 权限组变更 PUT 四数组全发 + 组删 DELETE 令牌 ----------------------------
  const putsBeforeChange = ocPuts.length
  const patchedRead = await api('PATCH', `/api/connector/perm-groups/${pgRead.id}`, { token: admin, body: {
    policies: {
      hackernews: { allowedActions: ['hackernews.get_top_stories', 'hackernews.fetch_item'], riskCap: 'read', constraints: { readOnly: true } },
      github: { allowedActions: ['*'], riskCap: 'read', connections: [`org:${connOrg}:main-pat`], constraints: { readOnly: true } },
    },
  } })
  check('权限组策略更新成功', patchedRead.ok)
  const mirrorPutAfterPatch = await waitFor(() => ocPuts.slice(putsBeforeChange)[0], 4000)
  check('T-12 变更触发 PUT 且四数组全发',
    mirrorPutAfterPatch && Object.keys(mirrorPutAfterPatch.policy).sort().join() === ['allowedActions', 'allowedConnections', 'allowedProxies', 'blockedActions'].sort().join()
    && Array.isArray(mirrorPutAfterPatch.policy.allowedActions) && Array.isArray(mirrorPutAfterPatch.policy.allowedConnections), JSON.stringify(mirrorPutAfterPatch ?? {}).slice(0, 240))

  // -- T-04 目录下架联动（先落库裁剪再镜像 PUT） ----------------------------------
  ocCtl.actions = (ocCtl.actions ?? [...ocActionsDefault]).filter((action) => action.id !== 'hackernews.fetch_item')
  const resyncAfterRemoval = await api('POST', '/api/connector/catalog/sync', { token: admin })
  check('目录下架检测（removed 命中）', resyncAfterRemoval.ok && (resyncAfterRemoval.data.removed ?? []).includes('hackernews.fetch_item'), JSON.stringify(resyncAfterRemoval.data?.removed))
  const prunedPut = await waitFor(() => ocPuts.find((put) => !put.policy.allowedActions.includes('hackernews.fetch_item') && put.policy.allowedActions.length >= 1), 4000)
  check('T-04 下架后受影响组收到裁剪后的 PUT 更新', Boolean(prunedPut), JSON.stringify(ocPuts.slice(-2)))

  // -- T-13 自动恢复（403 connection_not_allowed → PUT 最新快照 + 重试一次） ----------
  ocCtl.connNotAllowedOnce = '*ANY*'
  const recoverOk = await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.get_top_stories', input: {} } })
  check('T-13 单次 403 自动恢复重试成功（对调用方透明）', recoverOk.ok && recoverOk.data?.status === 'ok', JSON.stringify(recoverOk).slice(0, 220))
  // 恢复过程触发了「删旧铸新」：最新铸造值即平台当前在用的该组令牌（每次铸造都会入册）
  const mintCountBefore = ocMintedValues.length
  void mintCountBefore
  ocCtl.alwaysDenyToken = '*ANY*'
  const persistFail = await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.get_top_stories', input: {} } })
  check('T-13 持续拒绝 → 重试仍失败计 error_rate', persistFail.ok && persistFail.data?.status === 'error', JSON.stringify(persistFail).slice(0, 220))
  ocCtl.alwaysDenyToken = null

  // 目录恢复：fetch_item 回归目录并重新同步（后续 T-16a 等用例依赖它）
  ocCtl.actions = [...(ocCtl.actions ?? [])].concat((ocActionsDefault).filter((action) => action.id === 'hackernews.fetch_item'))
  await api('POST', '/api/connector/catalog/sync', { token: admin })

  // -- T-28 auditPersisted=false 补记 + 低阈告警记分 -------------------------------
  ocCtl.auditPersistedNext = true
  const ghostRun = await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.get_top_stories', input: { ghost: true } } })
  ocCtl.auditPersistedNext = false
  check('meta.auditPersisted=false 透传给调用方', ghostRun.ok && ghostRun.data?.status === 'ok' && ghostRun.data.meta.auditPersisted === false, JSON.stringify(ghostRun.data?.meta))
  const recoveredLog = await api('GET', `/api/audit/logs?q=${encodeURIComponent('recovered-audit')}&type=invoke&limit=50`, { token: admin })
  check('T-28 平台补记审计', recoveredLog.ok && recoveredLog.data.items.length >= 1, JSON.stringify(recoveredLog.data?.items?.slice(0, 1)))

  // -- OPT-P1-05 TOCTOU 收紧（镜像失败 fail-closed + 执行侧快照漂移拒绝） -------------
  // 隔离主体（isoGroup 仅本组覆盖 fetch_item），保证候选组唯一、断言不受其他健康组干扰
  const pgP105 = (await api('POST', '/api/connector/perm-groups', { token: admin, body: {
    name: 'P1-05 TOCTOU 观测组', orgId: connOrg,
    policies: { hackernews: { allowedActions: ['hackernews.fetch_item'], riskCap: 'write' } },
    subjects: [{ type: 'user_group', id: isoGroup.id }],
    rateLimitPerMin: 60,
  } })).data
  const p105Invoke = () => api('POST', '/api/connector/execute', { token: isoLogin.data.token, body: { actionId: 'hackernews.fetch_item', input: {} } })
  const p105Baseline = await p105Invoke()
  check('P1-05 基线调用成功（健康组可用）', p105Baseline.data?.status === 'ok', JSON.stringify(p105Baseline.data ?? {}).slice(0, 200))
  // 场景一：镜像注入失败 → 旧 oct_ 令牌立即吊销 + 组级 fail-closed
  // （快照哈希只含 allowedActions/connections 面——扩动作列表才会触发镜像 PUT）
  const deletesBeforeFail = ocDeletes.length
  ocMirrorFailOnce = true
  await api('PATCH', `/api/connector/perm-groups/${pgP105.id}`, { token: admin, body: { policies: { hackernews: { allowedActions: ['hackernews.fetch_item', 'hackernews.get_top_stories'], riskCap: 'write' } } } })
  await waitFor(() => ocDeletes.length > deletesBeforeFail, 4000)
  check('P1-05 镜像失败 → 旧 oct_ 令牌立即吊销（DELETE 命中 stub，不静默放大窗口）', ocDeletes.length > deletesBeforeFail)
  const p105FailClosed = await p105Invoke()
  check('P1-05 镜像失败期间组级 fail-closed → invoke 拒绝', p105FailClosed.data?.status === 'denied' && String(p105FailClosed.data.error).includes('fail-closed'), JSON.stringify(p105FailClosed.data ?? {}).slice(0, 220))
  // 场景二：恢复铸币期间并发收紧（确定性注入：钩子 PATCH 收紧至 H3 并延迟应答，外层镜像最后落账 H2）
  const mintedBeforeDrift = ocMintedValues.length
  // PATCH#2 回收组面（H2：单动作）触发恢复铸币；钩子在铸币期间并发改到 H3（双动作）并延迟应答，
  // 外层镜像最后按 H2 落账 → ledger(H2) 滞后于当前策略(H3)，确定性制造快照漂移
  ocDriftOnMint = { permGroupId: pgP105.id, token: admin, delayMs: 150, body: { policies: { hackernews: { allowedActions: ['hackernews.fetch_item', 'hackernews.get_top_stories', 'hackernews.submit_post'], riskCap: 'write' } } } }
  await api('PATCH', `/api/connector/perm-groups/${pgP105.id}`, { token: admin, body: { policies: { hackernews: { allowedActions: ['hackernews.get_top_stories'], riskCap: 'write' } } } })
  await waitFor(() => ocMintedValues.length > mintedBeforeDrift + 1, 5000)
  await new Promise((resolve) => setTimeout(resolve, 400))
  const p105Drift = await p105Invoke()
  check('P1-05 授权后策略漂移（ledger 滞后当前策略）→ 执行侧拒绝按旧快照执行',
    p105Drift.data?.status === 'denied' && String(p105Drift.data.error).includes('快照漂移'), JSON.stringify(p105Drift.data ?? {}).slice(0, 240))
  // 收敛：镜像一次 PUT（账本哈希对齐当前）→ 调用恢复
  await api('PATCH', `/api/connector/perm-groups/${pgP105.id}`, { token: admin, body: { policies: { hackernews: { allowedActions: ['hackernews.fetch_item', 'hackernews.get_top_stories'], riskCap: 'write' } } } })
  await waitFor(() => ocPuts.length > mintedBeforeDrift, 4000).catch(() => {})
  await new Promise((resolve) => setTimeout(resolve, 400))
  const p105Recovered = await p105Invoke()
  check('P1-05 镜像收敛后调用恢复（对齐账本哈希后正常执行）', p105Recovered.data?.status === 'ok', JSON.stringify(p105Recovered.data ?? {}).slice(0, 200))
  // 观测组退场：删除组（连带吊销令牌），恢复 isoGroup 单点清单组口径，不污染后续用例
  await api('DELETE', `/api/connector/perm-groups/${pgP105.id}`, { token: admin })

  // OPT-P2-02：敏感命名入参不入审批存储（admin 审批通道 fail-closed）
  const pgP202 = (await api('POST', '/api/connector/perm-groups', { token: admin, body: {
    name: 'P2-02 敏感面观测组', orgId: connOrg,
    policies: { hackernews: { allowedActions: ['hackernews.do_the_thing'], riskCap: 'admin' } },
    subjects: [{ type: 'user_group', id: isoGroup.id }],
    rateLimitPerMin: 60,
  } })).data
  const p202Sensitive = await api('POST', '/api/connector/execute', { token: isoLogin.data.token, body: { actionId: 'hackernews.do_the_thing', input: { password: 'plain-secret' } } })
  check('P2-02 admin 调用携敏感命名入参 → 拒绝开单（敏感值不入审批存储）',
    p202Sensitive.data?.status === 'denied' && String(p202Sensitive.data.error).includes('敏感命名参数'), JSON.stringify(p202Sensitive.data ?? {}).slice(0, 220))
  await api('DELETE', `/api/connector/perm-groups/${pgP202.id}`, { token: admin })

  // OPT-P2-01：ODD 域内判定（排除 action → 离域拒绝 + connector.odd_exit 落审计）
  const pgOdd = (await api('POST', '/api/connector/perm-groups', { token: admin, body: {
    name: 'P2-01 ODD 观测组', orgId: connOrg,
    policies: { hackernews: { allowedActions: ['hackernews.fetch_item', 'hackernews.get_top_stories'], riskCap: 'write' } },
    subjects: [{ type: 'user_group', id: isoGroup.id }],
    rateLimitPerMin: 60,
    odd: { allowedServices: ['hackernews'], excludedActions: ['hackernews.fetch_item'] },
  } })).data
  check('P2-01 ODD 块声明入库', Boolean(pgOdd.odd?.excludedActions?.length === 1), JSON.stringify(pgOdd.odd ?? {}))
  const oddDenied = await api('POST', '/api/connector/execute', { token: isoLogin.data.token, body: { actionId: 'hackernews.fetch_item', input: {} } })
  check('P2-01 排除清单内 action → ODD 离域拒绝', oddDenied.data?.status === 'denied' && String(oddDenied.data.error).includes('ODD'), JSON.stringify(oddDenied.data ?? {}).slice(0, 220))
  // OPT-P1-04 起总线异步派发：审计落账为最终一致，轮询等待（FIFO 中其他监听器退避重试会延迟投递）
  let oddTrailItems
  const oddTrailDeadline = Date.now() + 4000
  while (Date.now() < oddTrailDeadline) {
    const trail = await api('GET', '/api/audit/logs?q=' + encodeURIComponent('ODD') + '&type=invoke&limit=20', { token: admin })
    if (trail.ok && trail.data.items.length >= 1) { oddTrailItems = trail.data.items; break }
    await new Promise((resolve) => setTimeout(resolve, 150))
  }
  check('P2-01 离域事件落审计（ODD 离域可检索）', Array.isArray(oddTrailItems) && oddTrailItems.length >= 1, JSON.stringify(oddTrailItems?.slice(0, 1) ?? []).slice(0, 180))
  const oddAllowed = await api('POST', '/api/connector/execute', { token: isoLogin.data.token, body: { actionId: 'hackernews.get_top_stories', input: {} } })
  check('P2-01 白名单内 action 正常执行', oddAllowed.data?.status === 'ok', JSON.stringify(oddAllowed.data ?? {}).slice(0, 160))
  await api('DELETE', `/api/connector/perm-groups/${pgOdd.id}`, { token: admin })

  // -- T-16a 限流（用单点清单组保证候选组唯一，绕开多组并集下的候选顺序不确定性） --------
  await api('PATCH', `/api/connector/perm-groups/${pgIso.id}`, { token: admin, body: { rateLimitPerMin: 1 } })
  const rateLimited = await api('POST', '/api/connector/execute', { token: isoLogin.data.token, body: { actionId: 'hackernews.get_top_stories', input: {} } })
  const rateLimitedSecond = await api('POST', '/api/connector/execute', { token: isoLogin.data.token, body: { actionId: 'hackernews.get_top_stories', input: {} } })
  check('T-16a 超 rateLimitPerMin → rate_limited 拒绝',
    [rateLimited.data?.status, rateLimitedSecond.data?.status].includes('rate_limited'),
    JSON.stringify([rateLimited.data, rateLimitedSecond.data]).slice(0, 300))
  await api('PATCH', `/api/connector/perm-groups/${pgIso.id}`, { token: admin, body: { rateLimitPerMin: 60 } })

  // -- T-19 stub 关停 fail-closed + 恢复 ------------------------------------------
  await api('PUT', '/api/connector/gateway', { token: admin, body: { baseUrl: 'http://127.0.0.1:9', adminToken: 'env:OOMOL_CONNECT_ADMIN_TOKEN' } })
  const outage1 = await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.get_top_stories', input: {} } })
  await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.get_top_stories', input: {} } })
  const outage3 = await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.get_top_stories', input: {} } })
  check('T-19 网关不可达 → invoke fail-closed（GATEWAY_UNAVAILABLE）',
    outage1.ok === false || outage1.data?.status === 'error', JSON.stringify(outage1).slice(0, 220))
  // 连续失败计数 ≥3 时 ConnectorGatewayUnhealthy 事件→audit 落 invoke 日志（探活定时器 30s 周期之外的即时口径）
  const unhealthyTrail = await api('GET', '/api/audit/logs?q=' + encodeURIComponent('fail-closed') + '&type=invoke&limit=20', { token: admin })
  check('T-19 fail-closed 原因入审计（unavailableReason 可检索）', unhealthyTrail.ok && unhealthyTrail.data.items.length >= 1, JSON.stringify(unhealthyTrail.data?.items?.slice(0, 1)).slice(0, 200))
  await api('PUT', '/api/connector/gateway', { token: admin, body: { baseUrl: OC_BASE } })
  await api('POST', '/api/connector/gateway/health', { token: admin })
  const recoveredState = await api('GET', '/api/connector/gateway', { token: admin })
  check('T-19 恢复后自动回 healthy 并可继续调用', recoveredState.data.available === true, JSON.stringify(recoveredState).slice(0, 160))

  // -- OPT-P3-01 故障注入回归（4 类：网关 5xx / sidecar 审计失联 / 目录漂移 / oct_ 令牌吊销） ----
  // ①网关 5xx：注入一次 500 → 调用显式失败（不静默、可计数），随后恢复
  ocCtl.failNextExec = true
  const gw5xx = await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.get_top_stories', input: {} } })
  check('P3-01 故障① 网关 5xx → 调用显式失败（status=error 计入 error_rate）', gw5xx.data?.status === 'error', JSON.stringify(gw5xx.data ?? {}).slice(0, 200))
  const gw5xxRecover = await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.get_top_stories', input: {} } })
  check('P3-01 故障① 注入解除后调用恢复', gw5xxRecover.data?.status === 'ok', JSON.stringify(gw5xxRecover.data ?? {}).slice(0, 160))
  // ②sidecar 审计失联：数据面 auditPersisted=false → 平台补记（fail-visible 双写口径）
  ocCtl.auditPersistedNext = true
  const auditLost = await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.get_top_stories', input: { fault: 'audit-loss' } } })
  ocCtl.auditPersistedNext = false
  check('P3-01 故障② sidecar 审计失联 → 平台补记且向调用方透出', auditLost.data?.status === 'ok' && auditLost.data.meta.auditPersisted === false, JSON.stringify(auditLost.data?.meta ?? {}))
  // ③目录漂移：action 被目录同步移除 → 后续调用 fail-closed 拒绝
  ocCtl.actions = (ocCtl.actions ?? [...ocActionsDefault]).filter((action) => action.id !== 'hackernews.fetch_item')
  await api('POST', '/api/connector/catalog/sync', { token: admin })
  const driftDenied = await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.fetch_item', input: {} } })
  check('P3-01 故障③ 目录漂移（action 被移除）→ 调用拒绝', driftDenied.data?.status === 'denied' && String(driftDenied.data.error).includes('不在纳管目录'), JSON.stringify(driftDenied.data ?? {}).slice(0, 200))
  ocCtl.actions = [...(ocCtl.actions ?? [])].filter((action) => action.id !== 'hackernews.fetch_item').concat(ocActionsDefault.filter((action) => action.id === 'hackernews.fetch_item'))
  await api('POST', '/api/connector/catalog/sync', { token: admin })
  const driftRecover = await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.fetch_item', input: {} } })
  check('P3-01 故障③ 目录回补后调用恢复', driftRecover.data?.status === 'ok', JSON.stringify(driftRecover.data ?? {}).slice(0, 160))
  // ④oct_ 令牌吊销：sidecar 侧令牌被吊销 → 401 → 自动重铸恢复（obtainOctToken 重铸语义）
  const revokedToken = [...ocTokenByValue.entries()][0]
  if (revokedToken) {
    ocTokenByValue.delete(revokedToken[0])
    const afterRevoke = await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.get_top_stories', input: {} } })
    check('P3-01 故障④ oct_ 令牌被吊销 → 自动重铸恢复调用', afterRevoke.data?.status === 'ok', JSON.stringify(afterRevoke.data ?? {}).slice(0, 200))
  }

  // -- OPT-P3-01 P95 尾延迟质量闸门（阈值键可经环境覆盖：P95_GATE_LOGIN_MS / P95_GATE_INVOKE_MS） ----
  const P95_GATE_LOGIN_MS = Number(process.env.P95_GATE_LOGIN_MS ?? 800)
  const P95_GATE_INVOKE_MS = Number(process.env.P95_GATE_INVOKE_MS ?? 1500)
  const pct = (samples, p) => { const sorted = [...samples].sort((a, b) => a - b); return sorted[Math.min(sorted.length - 1, Math.max(0, Math.ceil(sorted.length * p) - 1))] }
  const loginSamples = []
  const invokeSamples = []
  for (let i = 0; i < 20; i++) {
    const loginStart = Date.now()
    await api('POST', '/api/auth/login', { body: { username: 'admin', password: 'Ybk@2026' } })
    loginSamples.push(Date.now() - loginStart)
    const invokeStart = Date.now()
    await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.get_top_stories', input: {} } })
    invokeSamples.push(Date.now() - invokeStart)
  }
  const loginP95 = pct(loginSamples, 0.95)
  const invokeP95 = pct(invokeSamples, 0.95)
  const dist = (samples) => `P50=${pct(samples, 0.5)}ms P95=${pct(samples, 0.95)}ms max=${Math.max(...samples)}ms`
  console.log(`  » P95 分布（n=20）：登录 ${dist(loginSamples)} ｜ connector invoke ${dist(invokeSamples)}`)
  check(`P3-01 登录换票 P95 ≤ ${P95_GATE_LOGIN_MS}ms`, loginP95 <= P95_GATE_LOGIN_MS, `p95=${loginP95}ms`)
  check(`P3-01 connector invoke P95 ≤ ${P95_GATE_INVOKE_MS}ms`, invokeP95 <= P95_GATE_INVOKE_MS, `p95=${invokeP95}ms`)

  // -- T-21 org 巡检注入不一致 -----------------------------------------------------
  const foreignConnectionSummary = (() => { return { id: 'oc-con-fake-foreign' } })()
  const anyManagedToken = [...ocLedgerTokens.entries()][0]
  if (anyManagedToken) anyManagedToken[1].policy.allowedConnections.push(foreignConnectionSummary.id)
  const patrolNow = await api('POST', '/api/connector/patrol', { token: admin })
  if (anyManagedToken) anyManagedToken[1].policy.allowedConnections.pop()
  check('T-21 巡检发现「令牌绑定 org 外连接」异常', patrolNow.ok && (patrolNow.data.violations ?? []).some((violation) => violation.kind === 'token_binds_foreign_connection'), JSON.stringify(patrolNow.data).slice(0, 260))
  const patrolAlerts = (await api('GET', '/api/audit/alerts', { token: admin })).data.alerts ?? []
  check('T-21 异常联动 warning 告警（org 巡检标题）', patrolAlerts.some((alert) => String(alert.title).includes('org 巡检')), JSON.stringify(patrolAlerts.filter((a) => String(a.title).includes('巡检')).slice(0, 1)))

  // -- T-23 runs 对账（cursor 增量去重 + 绕行 critical） ---------------------------
  const pageOne = await fetch(`${OC_BASE}/api/runs?limit=2`, { headers: { authorization: `Bearer ${OC_TOKEN}` } }).then((r) => r.json())
  check('T-01 runs 分页信封 {items,nextCursor}',
    Array.isArray(pageOne.data.items) && (pageOne.data.nextCursor === undefined || typeof pageOne.data.nextCursor === 'string'), JSON.stringify(pageOne.data).slice(0, 120))
  const reconcileFirst = await api('POST', '/api/connector/reconcile', { token: admin })
  check('对账首跑：正常 run 与平台计量近似一致（bypass 空）', reconcileFirst.ok && (reconcileFirst.data?.bypassRuns ?? []).length === 0 && reconcileFirst.data.checkedRuns >= 1, JSON.stringify({ err: reconcileFirst.error, data: reconcileFirst.data }))
  ocRuns.push({ id: 'fake-bypass-run-0001', service: 'github', actionId: 'github.list_issues', ok: true, runtimeTokenId: anyManagedToken ? anyManagedToken[0] : 'tok-none', caller: 'direct-sidecar', startedAt: new Date().toISOString() })
  const reconcileBypass = await api('POST', '/api/connector/reconcile', { token: admin })
  check('T-23 有 run 无 meter → 绕行 critical 告警命中 fake-bypass-run-0001', reconcileBypass.ok && (reconcileBypass.data.bypassRuns ?? []).includes('fake-bypass-run-0001'), JSON.stringify(reconcileBypass.data))
  ocCtl.overlapDupInRuns = true
  const reconcileOverlap = await api('POST', '/api/connector/reconcile', { token: admin })
  ocCtl.overlapDupInRuns = false
  // 增量语义：已处理的 run 不重复计入（重叠窗口翻倍也不放大结果集）
  check('T-23 cursor 重叠窗口去重（增量运行零新增，无重复放大）',
    reconcileOverlap.ok && (reconcileOverlap.data.bypassRuns ?? []).length === 0 && reconcileOverlap.data.checkedRuns === 0, JSON.stringify(reconcileOverlap.data))
  const bypassAlerts = (await api('GET', '/api/audit/alerts', { token: admin })).data.alerts ?? []
  check('绕行调用 critical 告警已入审计告警流', bypassAlerts.some((alert) => String(alert.title).includes('绕行调用')), JSON.stringify(bypassAlerts.filter((a) => a.severity === 'critical').slice(-1)))

  // -- T-29 数据面层独立强制（合法 oct_ 直连打非命中 action） ------------------------
  const scopedMint = await fetch(`${OC_BASE}/api/runtime-tokens`, {
    method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${OC_TOKEN}` },
    body: JSON.stringify({ name: 'scoped-single-action', allowedActions: ['github.delete_webhook'], blockedActions: [], allowedProxies: [], allowedConnections: [] }),
  }).then((r) => r.json())
  ocMintedValues.push(scopedMint.data.token)
  const dataPlaneDeny = await fetch(`${OC_BASE}/v1/actions/github.list_issues`, {
    method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${scopedMint.data.token}` },
    body: JSON.stringify({ input: {} }),
  }).then((r) => r.json())
  check('T-29 合法 oct_ 直连非命中 action → 数据面 403 拒绝',
    dataPlaneDeny.success === false && Number.isFinite(dataPlaneDeny.statusCode ?? dataPlaneDeny.status ?? 403) && dataPlaneDeny.errorCode === 'forbidden_action', JSON.stringify(dataPlaneDeny).slice(0, 200))

  // -- M0 桥接（T-25，importServices + 桥接徽章标记字段） ----------------------------
  const bridgeImport = await api('POST', '/api/mcp/import', { token: admin, body: {
    config: JSON.stringify({
      mcpServers: {
        'open-connector-stub': {
          url: `${OC_BASE}/mcp`,
          headers: { authorization: `Bearer ${OC_TOKEN}`, 'x-bridged-from': 'open-connector' },
        },
      },
    }),
    autoDeploy: true,
  } })
  const bridgeResult = bridgeImport.data?.results?.[0]
  check('T-25 桥接 import 成功（reachable+online）', bridgeImport.ok && bridgeResult?.ok === true && bridgeResult.reachable === true && bridgeResult.tools > 0, JSON.stringify(bridgeImport.data).slice(0, 260))
  const servicesList = (await api('GET', '/api/mcp/services', { token: admin })).data.services
  const bridgedService = servicesList.find((service) => service.slug === 'open-connector-stub')
  check('桥接服务带「bridgeFrom=open-connector」治理降级标记', Boolean(bridgedService?.bridgeFrom) && bridgedService.bridgeFrom === 'open-connector', JSON.stringify({ slug: bridgedService?.slug, bridgeFrom: bridgedService?.bridgeFrom }))
  // M0 治理降级语义：服务级粗粒度 MCP 权限组授权（无 action 级/连接级/令牌镜像）
  await api('POST', '/api/mcp/perm-groups', { token: admin, body: {
    name: '桥接自测组（M0）',
    policies: { [bridgedService.id]: { allowedTools: '*', constraints: {} } },
    subjects: [{ type: 'user_group', id: grpAdmin.id }],
  } })
  const bridgedCall = await rawReq('POST', '/mcp', {
    headers: { 'content-type': 'application/json', authorization: `Bearer ${admin}` },
    body: JSON.stringify({ jsonrpc: '2.0', id: 77, method: 'tools/call', params: { name: 'mcp_invoke', arguments: { serviceId: bridgedService?.id, tool: 'hackernews_get_top_stories', args: { platform: 'bridge' } } } }),
  })
  const bridgedText = jsonBody(bridgedCall).result?.content?.[0]?.text ?? ''
  // 平台工具层包装形态：InvokeResult.result 可为内容块数组（[{type:text,text:'{...}'}]）
  const bridgeParsed = JSON.parse(bridgedText || '{}')
  const innerBlockText = Array.isArray(bridgeParsed.result) ? bridgeParsed.result[0]?.text ?? '' : ''
  const bridgeEchoSource = (() => {
    try {
      return Array.isArray(bridgeParsed.result) ? JSON.parse(innerBlockText) : bridgeParsed
    } catch { return {} }
  })()
  const bridgeEcho = bridgeParsed.bridgeEcho ?? bridgeParsed.result?.bridgeEcho ?? bridgeEchoSource.bridgeEcho ?? {}
  check('经平台 MCP 网关调用桥接服务成功', bridgedCall.status === 200 && bridgeEcho.platform === 'bridge', bridgedText.slice(0, 220))

  // -- 三端工具面补验（工具桥 connector_execute / perm_group_list） -----------------
  const toolBridgePermList = await api('POST', '/api/tools/execute', { token: admin, body: { name: 'connector_perm_group_list', args: { orgId: connOrg } } })
  check('工具桥 connector_perm_group_list 返回结构化组清单', toolBridgePermList.ok && toolBridgePermList.data.value.total >= 4, JSON.stringify(toolBridgePermList.data?.value?.total))
  const toolBridgeExecute = await api('POST', '/api/tools/execute', { token: admin, body: { name: 'connector_execute', args: { actionId: 'hackernews.get_top_stories', input: { viaTool: true } } } })
  check('工具桥 connector_execute 身份注入 + 放行', toolBridgeExecute.ok && toolBridgeExecute.data.value.status === 'ok', JSON.stringify(toolBridgeExecute.data?.value).slice(0, 220))

  // -- 工具面权限收敛负向用例（架构审查 P0-1/P0-2：org 收敛 + 身份出参数层） -------
  const toolSchemas = (await api('GET', '/api/tools/schemas', { token: admin })).data.tools ?? []
  const connListTool = toolSchemas.find((tool) => tool.name === 'connector_connection_list')
  const connExecTool = toolSchemas.find((tool) => tool.name === 'connector_execute')
  check('工具 schema 不再暴露 orgId / callerId（身份与 org 收敛移出参数层）',
    Boolean(connListTool) && !JSON.stringify(connListTool.parameters).includes('orgId')
    && Boolean(connExecTool) && !JSON.stringify(connExecTool.parameters).includes('callerId'), JSON.stringify({ list: connListTool?.parameters, exec: connExecTool?.parameters }).slice(0, 240))

  const devOrgId = devUserSearch.orgId
  const devForge = await api('POST', '/api/tools/execute', { token: connDevLogin.data.token, body: { name: 'connector_connection_list', args: { orgId: connOrg } } })
  const devForgeList = devForge.data?.value?.connections ?? []
  check('低权限用户伪造 args.orgId 无效（工具仅返回其归属组织连接）',
    devForge.ok && devForgeList.every((item) => item.ownerOrgId === devOrgId), JSON.stringify({ devOrgId, got: devForgeList.map((item) => item.ownerOrgId) }).slice(0, 240))

  const devRestForge = await api('GET', `/api/connector/connections?orgId=${connOrg}`, { token: connDevLogin.data.token })
  check('REST 路径同一套收敛（?orgId= 对非 * 用户无效）', devRestForge.ok && (devRestForge.data.connections ?? []).every((item) => item.ownerOrgId === devOrgId), JSON.stringify(devRestForge.data).slice(0, 160))

  const extReader = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'ext-connector-reader', refType: 'external', scopes: ['console.login', 'connector.connection.read'] } })
  const extCc = await api('POST', '/api/auth/client-credentials', { body: { clientId: extReader.data.clientId, clientSecret: extReader.data.clientSecret } })
  const extList = await api('POST', '/api/tools/execute', { token: extCc.data.token, body: { name: 'connector_connection_list', args: {} } })
  check('外部机器（无资源归属）连接列表 fail-closed 返回空', extList.ok && extList.data.value.total === 0 && String(extList.data.value.note ?? '').includes('fail-closed'), JSON.stringify(extList.data?.value).slice(0, 220))
  const extPermGroups = await api('POST', '/api/tools/execute', { token: extCc.data.token, body: { name: 'connector_perm_group_list', args: { orgId: connOrg } } })
  check('外部机器权限组枚举同样 fail-closed（伪造 orgId 无效）', extPermGroups.ok && extPermGroups.data.value.total === 0, JSON.stringify(extPermGroups.data?.value).slice(0, 180))

  // ================================================================ 审批深化（WP-10/L1）与目录筛选（WP-12）
  section('审批 SLA 与公司级终审（WP-10：二次确认强制 / 终审可追溯 / 调用水印 / SLA 看板）')
  {
    const probe = await api('POST', '/api/agents', { token: admin, body: { name: '终审探针Agent', attrs: { description: 'WP-10 审批治理验证', model: 'deepseek-chat', riskLevel: 'medium', entryUrl: 'http://127.0.0.1:3080/', systemPromptVersion: 'v1.0', dataClass: 'internal', avatar: '🛡️' } } })
    check('终审探针：注册（entryUrl 免登通道过上线门禁）', probe.ok, JSON.stringify(probe.error))
    const onlineReq = await api('POST', `/api/agents/${probe.data.agent.id}/transition`, { token: admin, body: { action: 'online', note: 'WP-10 二次确认验证' } })
    check('终审探针：L4 上线审批单为高风险', onlineReq.ok && onlineReq.data.approval?.status === 'pending' && onlineReq.data.approval.riskLevel === 'high', JSON.stringify(onlineReq.data?.approval ?? onlineReq.error))
    const noConfirm = await api('POST', `/api/approvals/${onlineReq.data.approval.id}/decide`, { token: approver, body: { decision: 'approve', opinion: '未二次确认应被拒' } })
    check('终审探针：高风险通过缺二次确认被拒（服务端强制，非仅前端拦截）',
      noConfirm.status === 400 && JSON.stringify(noConfirm.error).includes('二次确认'), `${noConfirm.status} ${JSON.stringify(noConfirm.error)}`)
    const withConfirm = await api('POST', `/api/approvals/${onlineReq.data.approval.id}/decide`, { token: approver, body: { decision: 'approve', opinion: '已复核影响面（二次确认）', confirmed: true } })
    check('终审探针：二次确认后通过并自动执行', withConfirm.ok && withConfirm.data.status === 'executed', JSON.stringify(withConfirm.error))
    check('终审探针：审批单落公司级终审标记（终审人 + 时间）',
      withConfirm.ok && Boolean(withConfirm.data.finalReview?.approverId) && Boolean(withConfirm.data.finalReview?.at), JSON.stringify(withConfirm.data?.finalReview))
    const finalAudit = await api('GET', '/api/audit/logs?q=' + encodeURIComponent('approval.final_review'), { token: admin })
    check('终审探针：终审标记审计可追溯（action=approval.final_review 指向本审批单）',
      finalAudit.ok && (finalAudit.data.items ?? []).some((log) => log.action === 'approval.final_review' && log.resourceId === onlineReq.data.approval.id),
      JSON.stringify(finalAudit.data?.total))
    // MCP 服务终审 → 调用水印（hosted 演示服务 + 临时权限组授权 admin，确定性不依赖真实传输 stub 存活）
    const mcpsAll = await api('GET', '/api/mcp/services', { token: admin })
    const wmSvc = (mcpsAll.data.services ?? []).find((item) => item.status === 'online' && (item.tools ?? []).some((tool) => tool.riskLevel === 'read'))
      ?? (mcpsAll.data.services ?? []).find((item) => item.status === 'online')
    check('终审水印：在线服务在册', Boolean(wmSvc), JSON.stringify(mcpsAll.data?.services?.length))
    const adminUserId = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('admin'), { token: admin })).data.users.find((user) => user.username === 'admin').id
    const wmGroup = await api('POST', '/api/iam/groups', { token: admin, body: { name: `终审水印组-${Date.now()}`, type: 'static', memberIds: [adminUserId] } })
    const wmPerm = await api('POST', '/api/mcp/perm-groups', { token: admin, body: {
      name: `终审水印权限组-${Date.now()}`,
      policies: { [wmSvc.id]: { allowedTools: '*', constraints: { readOnly: true } } },
      subjects: [{ type: 'user_group', id: wmGroup.data.group?.id ?? wmGroup.data.id, name: '终审水印组' }],
    } })
    check('终审水印：admin 授权权限组就绪', wmPerm.ok, JSON.stringify(wmPerm.error))
    const fr = await api('POST', `/api/mcp/services/${wmSvc.id}/final-review`, { token: admin, body: {} })
    check('终审水印：MCP 服务公司级终审标记成功', fr.ok && Boolean(fr.data.finalReview?.approverId), JSON.stringify(fr.error))
    const wmTool = (wmSvc.tools ?? [])[0]?.name
    const wmInvoke = await api('POST', '/api/mcp/invoke', { token: admin, body: { serviceId: wmSvc.id, tool: wmTool, args: {} } })
    check('终审水印：终审服务可正常调用', wmInvoke.ok && wmInvoke.data.status === 'ok', JSON.stringify({ status: wmInvoke.status, error: wmInvoke.error, data: wmInvoke.data }))
    const wmCalls = await api('GET', `/api/mcp/calls?serviceId=${wmSvc.id}&limit=200`, { token: admin })
    check('终审水印：该服务调用记录附带水印（watermark.finalReview=true）',
      wmCalls.ok && (wmCalls.data.items ?? []).some((call) => call.watermark?.finalReview === true),
      JSON.stringify({ ok: wmCalls.ok, total: wmCalls.data?.total, n: wmCalls.data?.items?.length, w0: wmCalls.data?.items?.[0]?.watermark, s0: wmCalls.data?.items?.[0]?.serviceName, err: wmCalls.error }))
    // SLA 看板
    const sla = await api('GET', '/api/approvals/sla?windowDays=30', { token: admin })
    check('SLA 看板：≤2 工作日达成率可查（自测审批即时决策 → 100% 达标）',
      sla.ok && sla.data.decided >= 1 && sla.data.achievementRate >= 0.9 && typeof sla.data.calendarNote === 'string',
      JSON.stringify(sla.data ?? sla.error))
    const slaDenied = await api('GET', '/api/approvals/sla', { token: dev })
    check('SLA 看板：无 approval.read 被拒（dev 无该权限点）', slaDenied.status === 403, String(slaDenied.status))
  }
  section('资产目录筛选（WP-12：纯函数三条件 + 1000 项性能断言）')
  {
    const filters = await import(new URL('../packages/plugin-console/public/js/asset-filters.js', import.meta.url).href)
    const items = [
      { type: 'mcp', name: '数据分析引擎', slug: 'datawise', platform: 'rd', org: 'AI部', owner: '甲' },
      { type: 'agent', name: '研发编码助手', slug: 'dev-coder', platform: '', org: '研发部', owner: '乙' },
      { type: 'app', name: '数据洞察 BI', slug: 'insight-bi', platform: 'rd', org: 'AI部', owner: '丙' },
    ]
    check('目录：纯函数筛选（类型/平台/关键词三条件，缺失平台归「未标注」）',
      filters.filterAssets(items, { type: 'mcp' }).length === 1
      && filters.filterAssets(items, { platform: 'rd' }).length === 2
      && filters.filterAssets(items, { q: '编码' }).length === 1
      && filters.filterAssets(items, { q: 'DEV-CODER' }).length === 1
      && filters.assetPlatform(items[1]) === '未标注'
      && JSON.stringify(filters.platformFacets(items)) === JSON.stringify(['rd', '未标注']))
    const big = Array.from({ length: 1000 }, (_, i) => ({ type: i % 2 ? 'mcp' : 'agent', name: `资产${i}`, platform: i % 3 ? 'rd' : 'quality', org: 'o', owner: 'w' }))
    const perfStart = Date.now()
    filters.filterAssets(big, { type: 'mcp', platform: 'rd', q: '资产99' })
    const perfMs = Date.now() - perfStart
    check('目录：筛选性能断言（1000 项三条件 < 50ms，单栏卡片流无服务端二次请求）', perfMs < 50, `${perfMs}ms`)
  }

  // ================================================================ 验收回归：offline 审批闭环 / 规则播种 / mcp 直调 execute
  section('验收回归（offline 闭环 · 规则播种 · mcp 直调 execute）')

  // ③ 运营口径：连接器两条规则随演示种子幂等播种
  const seedRules = (await api('GET', '/api/audit/alert-rules', { token: admin })).data.rules ?? []
  check('连接器告警规则已播种（error_rate=critical / latency=warning）',
    seedRules.some((rule) => rule.metric === 'connector_error_rate' && rule.severity === 'critical')
    && seedRules.some((rule) => rule.metric === 'connector_latency' && rule.severity === 'warning'),
    JSON.stringify(seedRules.filter((rule) => String(rule.metric).startsWith('connector_')).map((rule) => [rule.metric, rule.threshold])))

  // ① 网关维护下线：L4 审批闭环（executor 落地 → fail-closed → 恢复探活）
  const gwOfflineReq = await api('POST', '/api/connector/gateway/offline', { token: admin, body: { reason: '验收回归-维护窗口' } })
  check('gateway.offline 默认生成 L4 审批单', gwOfflineReq.data?.approvalRequired === true && Boolean(gwOfflineReq.data.approvalId), JSON.stringify(gwOfflineReq).slice(0, 200))
  await api('POST', `/api/approvals/${gwOfflineReq.data.approvalId}/decide`, { token: approver, body: { decision: 'approve', confirmed: true } })
  const gwAfterOff = await api('GET', '/api/connector/gateway', { token: admin })
  check('审批通过 → executor 落地下线（fail-closed，原因含维护说明）', gwAfterOff.data.available === false && /验收回归/.test(String(gwAfterOff.data.reason)), JSON.stringify({ reason: gwAfterOff.data.reason }))
  const execBlockedMaint = await api('POST', '/api/connector/execute', { token: admin, body: { actionId: 'hackernews.get_top_stories', input: {} } })
  check('维护态 invoke fail-closed 拒绝', execBlockedMaint.data?.status === 'error' || /GATEWAY_UNAVAILABLE|网关/.test(JSON.stringify(execBlockedMaint)), JSON.stringify(execBlockedMaint).slice(0, 200))
  const gwOnline = await api('POST', '/api/connector/gateway/online', { token: admin })
  check('恢复上线即真实探活回 healthy', gwOnline.ok && gwOnline.data.ok === true, JSON.stringify(gwOnline).slice(0, 160))

  // ① 连接级下线：direct 模式留痕生效（不经审批的显式管理员路径）
  const connOffline = await api('POST', `/api/connector/connections/${patRef.id}/offline`, { token: admin, body: { reason: '验收回归-连接巡检', viaApproval: false } })
  check('连接 direct 下线立即生效（offlined 态留痕）', connOffline.ok && connOffline.data.reference?.status === 'offlined' && connOffline.data.reference.offlinedAt, JSON.stringify(connOffline).slice(0, 220))
  const execViaOfflined = await api('POST', '/api/connector/execute', { token: connDevLogin.data.token, body: { actionId: 'github.list_issues', input: {} } })
  check('经由下线连接的调用被平台侧拒绝（连接级闸）', execViaOfflined.ok && execViaOfflined.data?.status === 'denied' && /已下线/.test(String(execViaOfflined.data.error)), JSON.stringify(execViaOfflined).slice(0, 240))
  const connBack = await api('POST', `/api/connector/connections/${patRef.id}/online`, { token: admin })
  check('连接恢复后 sidecar 回查转 active', connBack.ok && connBack.data.reference?.status === 'active', JSON.stringify(connBack).slice(0, 220))

  // ④ POST /mcp tools/call 直调 connector_execute（三端最后一环；验收项原定下次迭代，本轮提前闭合）
  const mcpDirectCall = await rawReq('POST', '/mcp', {
    headers: { 'content-type': 'application/json', authorization: `Bearer ${admin}` },
    body: JSON.stringify({ jsonrpc: '2.0', id: 88, method: 'tools/call', params: { name: 'connector_execute', arguments: { actionId: 'hackernews.get_top_stories', input: { viaMcp: true } } } }),
  })
  const mcpDirectRaw = jsonBody(mcpDirectCall).result?.content?.[0]?.text ?? ''
  const mcpDirectOutcome = (() => { try { return JSON.parse(mcpDirectRaw) } catch { return {} } })()
  check('POST /mcp 直调 connector_execute（身份注入 + runId 回执）',
    mcpDirectCall.status === 200 && mcpDirectOutcome.status === 'ok' && /^exec-/.test(String(mcpDirectOutcome.runId)) && mcpDirectOutcome.data?.echo?.viaMcp === true, mcpDirectRaw.slice(0, 260))

  // 桥接规范形态：经 execute_action(actionId,input) 调用（集成指南 v0.2 §五口径；legacy 别名仍兼容）
  const bridgedExecCall = await rawReq('POST', '/mcp', {
    headers: { 'content-type': 'application/json', authorization: `Bearer ${admin}` },
    body: JSON.stringify({ jsonrpc: '2.0', id: 89, method: 'tools/call', params: { name: 'mcp_invoke', arguments: { serviceId: bridgedService?.id, tool: 'execute_action', args: { actionId: 'hackernews.get_top_stories', input: { viaExecuteAction: true } } } } }),
  })
  const execRaw = jsonBody(bridgedExecCall).result?.content?.[0]?.text ?? ''
  const execParsed = (() => { try { return JSON.parse(execRaw) } catch { return {} } })()
  const execBlocks = Array.isArray(execParsed.result) ? JSON.parse(execParsed.result[0]?.text ?? '{}') : {}
  check('桥接 execute_action 规范调用成功（含 runId 回执）',
    bridgedExecCall.status === 200 && Boolean(execBlocks.bridgeEcho?.runId ?? execBlocks.runId), execRaw.slice(0, 240))

  // ================================================================ /docs 静态发布（文档目录随服务可访问）
  section('/docs 静态发布（接入指南等文档直接可读）')

  const docIndex = await rawReq('GET', '/docs')
  check('/docs 目录索引页（HTML + 列出接入指南）', docIndex.status === 200 && String(docIndex.headers['content-type']).startsWith('text/html') && docIndex.body.includes('app-sso-integration.md'))
  const docFile = await rawReq('GET', '/docs/app-sso-integration.md')
  check('/docs/app-sso-integration.md 可读（markdown + 正文）', docFile.status === 200 && String(docFile.headers['content-type']).startsWith('text/markdown') && docFile.body.includes('OIDC') && docFile.body.includes('接入'))
  const docMissing = await rawReq('GET', '/docs/not-exists.md')
  check('/docs 未知文档 404', docMissing.status === 404)
  // 路径穿越探测：字面 .. 与编码 %2e%2e 均被 URL 解析归一化（WHATWG 规范视编码点段为点段）→ 回落 SPA 兜底页，不泄露文件
  const docTraverseLiteral = await rawReq('GET', '/docs/../package.json')
  check('/docs 字面 .. 穿越 → SPA 兜底页（不泄露文件）', docTraverseLiteral.status === 200 && String(docTraverseLiteral.headers['content-type']).startsWith('text/html') && !docTraverseLiteral.body.includes('"name": "dsh-enterprise-ops"'))
  const docTraverseEncoded = await rawReq('GET', '/docs/%2e%2e/package.json')
  check('/docs 编码 %2e%2e 穿越 → SPA 兜底页（不泄露文件）', docTraverseEncoded.status === 200 && String(docTraverseEncoded.headers['content-type']).startsWith('text/html') && !docTraverseEncoded.body.includes('"name": "dsh-enterprise-ops"'))
  const spaStillOk = await rawReq('GET', '/')
  check('SPA 静态兜底不受影响（/ 仍返回控制台首页）', spaStillOk.status === 200 && String(spaStillOk.headers['content-type']).startsWith('text/html') && spaStillOk.body.includes('榕器'))

  // ================================================================ 门户数据通道（plugin-portal：外部拉取端点）
  section('统一入口：/panel 无尾斜杠 302 归一（相对资源解析防御）')
  const panelBare = await rawReq('GET', '/panel')
  check('/panel 302 → /panel/（独立形态；无归一时 index.html 的 ./js/* 会解析到 /js/* → 白屏）',
    panelBare.status === 302 && panelBare.headers.location === '/panel/',
    `status=${panelBare.status} location=${panelBare.headers.location}`)
  const panelSlash = await rawReq('GET', '/panel/')
  check('/panel/ 面板 SPA 正常伺服（归一目标可达）', panelSlash.status === 200 && panelSlash.body.includes('部门 Agent 工作台'))
  // 落地分诊纯函数随包单测（landing.test.mjs：五内置角色决议/通配展开/裸落地/回跳白名单）
  const landingTest = spawn(process.execPath, ['packages/plugin-console/public/js/landing.test.mjs'], { stdio: 'pipe' })
  await new Promise((resolve) => landingTest.on('close', resolve))
  check('落地分诊随包单测全绿（node --test）', landingTest.exitCode === 0, `exit=${landingTest.exitCode}`)
  // 登录回跳共享面随包单测（F 清单 P 节：一次读取消费/白名单/出口规则，next-redirect.test.mjs）
  const nextRedirectTest = spawn(process.execPath, ['packages/plugin-console/public/js/next-redirect.test.mjs'], { stdio: 'pipe' })
  await new Promise((resolve) => nextRedirectTest.on('close', resolve))
  check('登录回跳共享面随包单测全绿（node --test）', nextRedirectTest.exitCode === 0, `exit=${nextRedirectTest.exitCode}`)
  // 契约↔实现双向一致性（OPT-P0-01，2026-09-12）：引擎构造性红/绿测试 + 真仓零红闸门
  const contractLintTest = spawn(process.execPath, ['scripts/contract-lint.test.mjs'], { stdio: 'pipe' })
  await new Promise((resolve) => contractLintTest.on('close', resolve))
  check('契约 lint 引擎构造性红/绿测试全绿（node --test）', contractLintTest.exitCode === 0, `exit=${contractLintTest.exitCode}`)
  const contractLintRepo = spawn(process.execPath, ['scripts/lint-manifests.mjs'], { stdio: 'pipe' })
  await new Promise((resolve) => contractLintRepo.on('close', resolve))
  check('契约比对真仓零红（路由/工具/权限双向一致，lint:manifests 通道）', contractLintRepo.exitCode === 0, `exit=${contractLintRepo.exitCode}`)
  // connect 工具远程代理契约化自证（OPT-P1-03：扩展点挂载/转发失败 fail-closed/注销还原）
  const connectProxyTest = spawn(process.execPath, ['packages/plugin-connect/src/proxy.test.mjs'], { stdio: 'pipe' })
  await new Promise((resolve) => connectProxyTest.on('close', resolve))
  check('connect 远程代理契约化随包单测全绿（node --test）', connectProxyTest.exitCode === 0, `exit=${connectProxyTest.exitCode}`)
  // 平台总线管道自证（OPT-P1-04：异步串行派发/异常落事件/3 次退避重试入死信/journal 重启回放/人工重投）
  const busPipelineTest = spawn(process.execPath, ['packages/platform-core/src/bus.test.mjs'], { stdio: 'pipe' })
  await new Promise((resolve) => busPipelineTest.on('close', resolve))
  check('平台总线管道随包单测全绿（node --test）', busPipelineTest.exitCode === 0, `exit=${busPipelineTest.exitCode}`)
  // 工具注册契约自证（OPT-P2-04：output.schema 强校验，无 schema 注册即抛）
  const toolsLiteTest = spawn(process.execPath, ['packages/platform-core/src/tools-lite.test.mjs'], { stdio: 'pipe' })
  await new Promise((resolve) => toolsLiteTest.on('close', resolve))
  check('工具注册契约随包单测全绿（node --test）', toolsLiteTest.exitCode === 0, `exit=${toolsLiteTest.exitCode}`)
  // 审批卫生与规则源自证（OPT-P2-02：敏感面掩码/拒绝 + 补偿注册表编排）
  const approvalTest = spawn(process.execPath, ['packages/plugin-audit/src/approval.test.mjs'], { stdio: 'pipe' })
  await new Promise((resolve) => approvalTest.on('close', resolve))
  check('审批卫生与补偿注册表随包单测全绿（node --test）', approvalTest.exitCode === 0, `exit=${approvalTest.exitCode}`)
  // ODD 域内判定纯函数自证（OPT-P2-01）
  const oddTest = spawn(process.execPath, ['packages/plugin-connector/src/odd.test.mjs'], { stdio: 'pipe' })
  await new Promise((resolve) => oddTest.on('close', resolve))
  check('ODD 域内判定随包单测全绿（node --test）', oddTest.exitCode === 0, `exit=${oddTest.exitCode}`)
  // 前端接线 grep 不变量（纯前端逻辑的静态面断言）
  const panelBoot = readFileSync(join(process.cwd(), 'packages', 'plugin-panel-core', 'public', 'js', 'boot.js'), 'utf8')
  check('面板 boot 宿主直通走根绝对 /dsh-bridge/*（带 BASE 在挂载形态会 miss → 静默失效）',
    panelBoot.includes("fetch('/dsh-bridge/status'") && !panelBoot.includes('${BASE}/dsh-bridge'))
  const consoleBoot = readFileSync(join(process.cwd(), 'packages', 'plugin-console', 'public', 'js', 'app.js'), 'utf8')
  check('控制台启动链含宿主会话直通 + 落地分诊（exchangeBridgeSession/resolveLanding）',
    consoleBoot.includes('exchangeBridgeSession') && consoleBoot.includes('resolveLanding'))
  const loginSrc = readFileSync(join(process.cwd(), 'packages', 'plugin-console', 'public', 'js', 'pages', 'login.js'), 'utf8')
  const nextRedirectSrc = readFileSync(join(process.cwd(), 'packages', 'plugin-console', 'public', 'js', 'next-redirect.js'), 'utf8')
  check('登录回跳接线（F 清单 P 节：消费面提升共享模块 next-redirect.js，login/app 双消费者同规则）',
    loginSrc.includes('consumeNextSources') && loginSrc.includes('exitWithNext')
    && consoleBoot.includes('exitWithNext') && consoleBoot.includes('consumeNextSources')
    && nextRedirectSrc.includes('sanitizeNext') && nextRedirectSrc.includes('sanitizeCrossOriginNext')
    && nextRedirectSrc.includes('heng_ops_next') && nextRedirectSrc.includes('heng_ops_next_cross'))
  const panelApp = readFileSync(join(process.cwd(), 'packages', 'plugin-panel-core', 'public', 'js', 'app.js'), 'utf8')
  check('面板侧切换接线（管理控制台 data-landing 偏好 + 401 引导带 ?next= 回面板）',
    panelApp.includes('data-landing') && panelApp.includes('next='))
  check('面板模型面接线（composer 模型切换 #chatModel + 模型配置界面 showModels + 回包模型徽标）',
    panelApp.includes('#chatModel') && panelApp.includes('showModels') && panelApp.includes("role model"))

  // ================================================================ 宿主服务连接切换（docs/frontend-host-switching.md）
  section('宿主服务连接切换（前端多宿主 + 数据面跨域放行）')
  // 决议纯函数（platform-core http 导出，selftest 直测）
  check('CORS 决议：* 放行任意来源', platformCore.corsAllowOriginFor(['*'], 'http://192.168.0.5:7300') === '*')
  check('CORS 决议：无 Origin（同源/curl）不放行', platformCore.corsAllowOriginFor(['*'], undefined) === undefined)
  check('CORS 决议：白名单命中精确回显', platformCore.corsAllowOriginFor(['http://a:1', 'http://b:2'], 'http://b:2') === 'http://b:2')
  check('CORS 决议：白名单未命中不发放', platformCore.corsAllowOriginFor(['http://a:1'], 'http://evil:2') === undefined)
  check('CORS 决议：空列表=关闭', platformCore.corsAllowOriginFor([], 'http://a:1') === undefined)
  check('CORS 决议：畸形 Origin 不发放', platformCore.corsAllowOriginFor(['http://a:1'], 'not-a-url') === undefined)
  // 数据面端到端（隔离实例默认 corsAllowOrigins=['*']）
  const connOrigin = 'http://192.168.0.5:7300'
  const corsPreflightApi = await rawReq('OPTIONS', '/api/health', { headers: { origin: connOrigin, 'access-control-request-method': 'GET', 'access-control-request-headers': 'authorization,content-type' } })
  check('API 预检 OPTIONS → 204 + allow-origin/methods/headers/max-age（先于鉴权中间件，不被 401 拦截）',
    corsPreflightApi.status === 204
    && corsPreflightApi.headers['access-control-allow-origin'] === '*'
    && String(corsPreflightApi.headers['access-control-allow-methods']).includes('POST')
    && String(corsPreflightApi.headers['access-control-allow-headers']).includes('authorization')
    && String(corsPreflightApi.headers['access-control-allow-headers']).includes('content-type')
    && corsPreflightApi.headers['access-control-max-age'] === '600')
  const corsHealth = await rawReq('GET', '/api/health', { headers: { origin: connOrigin } })
  check('公开端点跨域携带放行头（连接页测活可读）', corsHealth.status === 200 && corsHealth.headers['access-control-allow-origin'] === '*')
  const corsUnauthorized = await rawReq('GET', '/api/overview', { headers: { origin: connOrigin } })
  check('鉴权端点 401 错误体同样携带放行头（远端页面可读失败原因）',
    corsUnauthorized.status === 401 && corsUnauthorized.headers['access-control-allow-origin'] === '*')
  const corsAuthorized = await rawReq('GET', '/api/overview', { headers: { origin: connOrigin, authorization: `Bearer ${admin}` } })
  check('携带 Bearer 的跨域业务请求正常返回（宿主切换后的主链路）',
    corsAuthorized.status === 200 && jsonBody(corsAuthorized).ok === true)
  const corsNoOrigin = await rawReq('OPTIONS', '/api/health')
  check('无 Origin 的 OPTIONS 不被预检分支劫持（同源行为不变）', corsNoOrigin.status === 404 && corsNoOrigin.headers['access-control-allow-origin'] === undefined)
  // RQ 澄清第 1 条：令牌铸造/交换面 /api/auth/* 对 blanket '*' 永不发放（drive-by 凭证探测面关闭）
  const authPreflight = await rawReq('OPTIONS', '/api/auth/login', { headers: { origin: connOrigin, 'access-control-request-method': 'POST' } })
  check('CORS 收紧：/api/auth/* 预检在 blanket * 下无 ACAO（跨站登录探测被浏览器拦截）',
    authPreflight.headers['access-control-allow-origin'] === undefined, JSON.stringify(authPreflight.headers))
  const authDirect = await rawReq('GET', '/api/auth/providers', { headers: { origin: connOrigin } })
  check('CORS 收紧：/api/auth/* 直跨域响应同样不挂放行头（未进预检分支头也不发放）',
    authDirect.headers['access-control-allow-origin'] === undefined, JSON.stringify(authDirect.headers))
  // 配置具体来源列表时 /api/auth/* 按精确来源放行（远程宿主在线登录 = B 侧显式配置，零信任默认）
  {
    const preciseDir = join(DATA_DIR, 'cors-precise')
    await mkdir(preciseDir, { recursive: true })
    const preciseCtx = new Context()
    await preciseCtx.plugin(platformCore, { dataDir: preciseDir, http: { port: 7399, corsAllowOrigins: [connOrigin] }, startHttp: false })
    await preciseCtx.httpServer.start()
    try {
      const pBase = `http://127.0.0.1:${preciseCtx.httpServer.port}`
      const preciseAuth = await fetch(`${pBase}/api/auth/login`, { method: 'POST', headers: { origin: connOrigin, 'content-type': 'application/json' }, body: '{}' })
      check('CORS 精确来源：/api/auth/login 按白名单回显放行（显式配置即放行，跨机器部署的正确姿势）',
        preciseAuth.headers.get('access-control-allow-origin') === connOrigin, String(preciseAuth.headers.get('access-control-allow-origin')))
      const preciseEvil = await fetch(`${pBase}/api/auth/login`, { method: 'POST', headers: { origin: 'http://evil.example.com' }, body: '{}' })
      check('CORS 精确来源：未命中白名单的来源对 /api/auth/* 仍不发放', preciseEvil.headers.get('access-control-allow-origin') === null)
    } finally {
      await preciseCtx.httpServer.stop()
    }
  }
  // 前端接线：连接管理纯函数随包单测 + api.js 动态 BASE 不变量
  const connectionsTest = spawn(process.execPath, ['packages/plugin-console/public/js/connections.test.mjs'], { stdio: 'pipe' })
  await new Promise((resolve) => connectionsTest.on('close', resolve))
  check('连接管理纯函数随包单测全绿（node --test）', connectionsTest.exitCode === 0, `exit=${connectionsTest.exitCode}`)
  const apiSrc = readFileSync(join(process.cwd(), 'packages', 'plugin-console', 'public', 'js', 'api.js'), 'utf8')
  check('api.js 动态 BASE + 会话按连接隔离 + 桥接直通仅本机（连接切换的三个承重点）',
    apiSrc.includes('activeConnection(localStorage, MOUNT)') && apiSrc.includes('TOKEN_NS') && apiSrc.includes('IS_LOCAL_HOST'))
  const appConnSrc = readFileSync(join(process.cwd(), 'packages', 'plugin-console', 'public', 'js', 'app.js'), 'utf8')
  check('控制台接线：#/connections 会话前置独立渲染 + 外壳内 builders + 顶栏远程指示',
    appConnSrc.includes("page === 'connections'") && appConnSrc.includes('connections: renderConnections') && appConnSrc.includes('conn-indicator'))
  check('app.js 显式 import BASE（缺失时 NAV「部门面板」ext 点击 ReferenceError → 无响应，c0fca1a 回归守卫）',
    /import\s*\{[^}]*\bBASE\b[^}]*\}\s*from\s*'\.\/api\.js'/.test(appConnSrc))

  // ================================================================ 门户数据通道（plugin-portal：外部拉取端点）

  // ================================================================ 门户数据通道（plugin-portal：外部拉取端点）
  section('门户数据通道（plugin-portal：企业门户拉取已发布应用/Agent，非核心）')
  const portalOrigin = 'http://192.168.0.4:8092'
  const portalGet = async (path, headers = {}) => rawReq('GET', `/api/portal${path}`, { headers })
  const portalJson = async (path, headers = {}) => {
    const raw = await portalGet(path, headers)
    return { status: raw.status, headers: raw.headers, body: jsonBody(raw) }
  }
  // 门户契约：纯前端无鉴权拉取——不带 Bearer 直接访问（console 鉴权中间件不得拦截门户前缀）
  const portalDiscovery = await portalJson('/', { origin: portalOrigin })
  check('公开访问 200（无 Bearer，门户前缀先于 console 鉴权中间件截获）', portalDiscovery.status === 200 && portalDiscovery.body.code === 0 && Array.isArray(portalDiscovery.body.data?.endpoints))
  const portalApps = await portalJson('/apps', { origin: portalOrigin })
  check('契约包装 {code:0, message, data} + no-cache（刷新即可见）', portalApps.status === 200 && portalApps.body.code === 0 && portalApps.body.message === 'ok' && Array.isArray(portalApps.body.data) && portalApps.headers['cache-control'] === 'no-cache')
  check('CORS 放行生产门户来源', portalApps.headers['access-control-allow-origin'] === portalOrigin)
  // 全链路：注册 → L4 审批上线 → 门户拉取即可见（miniapp 形态不走 SSO 门禁）
  const portalProbe = await api('POST', '/api/apps', { token: admin, body: { name: '门户拉取探针应用', attrs: { description: '门户数据通道验收：上线即对门户可见', appType: 'miniapp', url: 'http://192.168.0.8:9000/', riskLevel: 'low', dataClass: 'internal' } } })
  const portalProbeReq = await api('POST', `/api/apps/${portalProbe.data.app.id}/transition`, { token: admin, body: { action: 'online' } })
  await api('POST', `/api/approvals/${portalProbeReq.data.approval.id}/decide`, { token: approver, body: { decision: 'approve', opinion: '门户可见性验收', confirmed: true } })
  const portalAppsAfter = await portalJson('/apps', { origin: portalOrigin })
  const portalApp = portalAppsAfter.body.data.find((item) => item.id === portalProbe.data.app.id)
  check('已上线应用进入 /apps（link=访问地址，tag/version/accent 契约齐全）',
    portalApp && portalApp.name === '门户拉取探针应用' && portalApp.link === 'http://192.168.0.8:9000/'
    && portalApp.tag === '小程序' && portalApp.desc === '门户数据通道验收：上线即对门户可见'
    && typeof portalApp.accent === 'string' && /^#[0-9A-Fa-f]{6}$/.test(portalApp.accent))
  check('launchDate 为上线当日（YYYY-MM-DD）', /^\d{4}-\d{2}-\d{2}$/.test(portalApp?.launchDate ?? '') && portalApp.launchDate === new Date().toISOString().slice(0, 10))
  const adminApps = (await api('GET', '/api/apps', { token: admin })).data.apps
  const expectedOnline = adminApps.filter((item) => item.status === 'online')
  check('/apps 与平台已上线应用一致（仅 online 进入门户，未上线/下架不出现）',
    portalAppsAfter.body.data.length === expectedOnline.length
    && expectedOnline.every((item) => portalAppsAfter.body.data.some((entry) => entry.id === item.id)))
  const portalEmployees = await portalJson('/employees', { origin: 'http://192.168.0.8:8443' })
  check('/employees：已上线 Agent=数字员工（内网 :8443 开发来源 CORS 同样放行）',
    portalEmployees.status === 200 && portalEmployees.headers['access-control-allow-origin'] === 'http://192.168.0.8:8443'
    && Array.isArray(portalEmployees.body.data) && portalEmployees.body.data.some((item) => item.id === targetAgent.id && item.avatar && typeof item.skills === 'string'))
  const portalSkills = await portalJson('/skills')
  check('/skills：已上架 Skill 契约（downloadUrl 为门户登录下载端点绝对地址）',
    portalSkills.status === 200 && Array.isArray(portalSkills.body.data) && portalSkills.body.data.length >= 1
    && portalSkills.body.data.every((item) => /^https?:\/\/.+\/api\/portal\/skills\/.+\/download$/.test(item.downloadUrl)))
  const portalSkillDl = await rawReq('GET', new URL(portalSkills.body.data[0].downloadUrl).pathname)
  check('downloadUrl 未登录被拒 401 契约错误（v1.1：必须登录）',
    portalSkillDl.status === 401 && portalSkillDl.headers['content-type'].includes('json') && jsonBody(portalSkillDl).code === 40100, JSON.stringify({ status: portalSkillDl.status }))
  const portalSkillDlBad = await rawReq('GET', new URL(portalSkills.body.data[0].downloadUrl).pathname, { headers: { authorization: 'Bearer dst1_forged_token' } })
  check('无效令牌下载被拒 401（不泄露技能存在性）', portalSkillDlBad.status === 401 && jsonBody(portalSkillDlBad).code === 40100)
  const portalSkillDlAuth = await rawReq('GET', new URL(portalSkills.body.data[0].downloadUrl).pathname, { headers: { authorization: `Bearer ${admin}` } })
  check('携带登录令牌可下载（200 + zip 魔数 PK + attachment 头）',
    portalSkillDlAuth.status === 200 && String(portalSkillDlAuth.headers['content-type']).includes('zip')
    && portalSkillDlAuth.body.startsWith('PK') && String(portalSkillDlAuth.headers['content-disposition']).includes('attachment'), JSON.stringify({ status: portalSkillDlAuth.status, type: portalSkillDlAuth.headers['content-type'] }))
  const portalDlUnknownAuth = await rawReq('GET', '/api/portal/skills/skl_not_exist/download', { headers: { authorization: `Bearer ${admin}` } })
  check('未上架/未知技能下载 404 契约错误（登录后）', portalDlUnknownAuth.status === 404 && jsonBody(portalDlUnknownAuth).code === 40400)
  const portalDownloadAudit = (await api('GET', '/api/audit/logs?action=portal.skill.download&limit=5', { token: admin })).data?.items ?? []
  check('下载审计落账（谁在下载：actor=登录用户）', Array.isArray(portalDownloadAudit) && portalDownloadAudit.some((item) => item.actorId && item.actorId !== 'portal-feed' && String(item.detail ?? '').includes('via=')), JSON.stringify(portalDownloadAudit?.[0] ?? {}))
  const portalStats = await portalJson('/stats', { origin: portalOrigin })
  check('/stats：恰 4 卡且 value 为字符串（契约明确非数值）', portalStats.body.data.length === 4 && portalStats.body.data.every((item) => typeof item.value === 'string' && item.unit !== undefined && item.label !== undefined))
  check('/stats 口径：已上线应用计数与 /apps 一致', Number(portalStats.body.data[0].value) === portalAppsAfter.body.data.length)
  const portalSolutions = await portalJson('/solutions')
  const portalTools = await portalJson('/tools')
  check('/solutions、/tools：暂无数据源 → 空数组（门户契约 §5：降级展示内置样板）', portalSolutions.body.data?.length === 0 && portalTools.body.data?.length === 0)
  const portalPreflight = await rawReq('OPTIONS', '/api/portal/apps', { headers: { origin: portalOrigin, 'access-control-request-method': 'GET', 'access-control-request-headers': 'authorization, content-type' } })
  check('OPTIONS 预检 204 + 放行方法/来源/authorization 请求头', portalPreflight.status === 204 && portalPreflight.headers['access-control-allow-origin'] === portalOrigin && String(portalPreflight.headers['access-control-allow-methods']).includes('GET') && String(portalPreflight.headers['access-control-allow-headers']).includes('authorization'))
  const portalUnknown = await portalJson('/nope', { origin: portalOrigin })
  check('未知端点 404 契约错误（门户展示错误与重试，不影响其他端点）', portalUnknown.status === 404 && portalUnknown.body.code === 40400)
  const portalNoOrigin = await portalGet('/stats')
  check('无 Origin 请求正常应答（仅不回 CORS 放行头）', portalNoOrigin.status === 200 && !portalNoOrigin.headers['access-control-allow-origin'])
  const portalPost = await rawReq('POST', '/api/portal/apps', { headers: { 'content-type': 'application/json', origin: portalOrigin }, body: '{}' })
  check('写方法被拒 405（契约全只读）', portalPost.status === 405)

  // ================================================================ 收尾终检：凭证零进平台（红线一，T-24）
  section('部门面板（plugin-panel-core：数据面 / 图谱 / 激活 / 计量 / 运行时）')
  {
    const panelAdmin = admin
    const rootOrgId = (await api('GET', '/api/iam/orgs', { token: panelAdmin })).data.find((org) => org.parentId === null).id

    // -- 部门骨架与总览 ------------------------------------------------------
    const depts = await api('GET', '/api/panel/depts', { token: panelAdmin })
    check('面板：五部门骨架（一套骨架五种皮肤的数据底座）',
      depts.ok && depts.data.depts.length === 5 && depts.data.depts.some((dept) => dept.id === 'mfg' && dept.colors?.accent === '#0f766e'),
      JSON.stringify(depts.data?.depts?.map((dept) => dept.id)))
    const overview = await api('GET', '/api/panel/mfg/overview', { token: panelAdmin })
    check('面板：制造部总览（行业激活 + 频道 + 阵容 + KPI/widget 来源徽标）',
      overview.ok && overview.data.industry?.code === 'qb01' && overview.data.channels.length >= 3
      && overview.data.agents.length === 4 && overview.data.kpis.length >= 3
      && overview.data.widgets.length >= 3 && overview.data.widgets.every((widget) => !widget.degraded && widget.source === '模拟数据'),
      JSON.stringify({ industry: overview.data?.industry, widgets: overview.data?.widgets?.length }))
    const overviewNoAuth = await api('GET', '/api/panel/mfg/overview')
    check('面板：未认证访问被拒（401）', overviewNoAuth.status === 401)

    // -- 消息闭环：发消息 / 卡片动作走纯平台链（task.create + 幂等） ----------------
    const channels = await api('GET', '/api/panel/mfg/channels', { token: panelAdmin })
    const mainChannel = channels.data.channels[0]
    const posted = await api('POST', '/api/panel/mfg/messages', { token: panelAdmin, body: { channelId: mainChannel.id, text: '自测：协作消息链路', ddSync: false } })
    check('面板：发消息落库（人 × 频道归属校验）', posted.ok && posted.data.message.dept === 'mfg')
    const msgList = await api('GET', `/api/panel/mfg/messages?channelId=${mainChannel.id}`, { token: panelAdmin })
    const cardMsg = msgList.data.messages.find((m) => m.card?.title?.includes('WX-0912'))
    check('面板：演示卡片消息在库（Agent 操作卡片）', Boolean(cardMsg) && cardMsg.card.ops.length === 3)
    const cardAct = await api('POST', `/api/panel/messages/${cardMsg.id}/card-action`, { token: panelAdmin, body: { opId: cardMsg.card.ops[0].id } })
    check('面板：卡片动作「确认派单」→ 生成任务（纯平台链）',
      cardAct.ok && /已生成任务/.test(cardAct.data.result), JSON.stringify(cardAct.data?.result ?? cardAct.error))
    const cardActReplay = await api('POST', `/api/panel/messages/${cardMsg.id}/card-action`, { token: panelAdmin, body: { opId: cardMsg.card.ops[0].id } })
    check('面板：卡片动作幂等保护（重复执行被拒）', !cardActReplay.ok && /已执行/.test(cardActReplay.error.message))

    // -- 任务看板（泳道状态机） ------------------------------------------------
    const taskCreated = await api('POST', '/api/panel/mfg/tasks', { token: panelAdmin, body: { title: '自测任务：M-2207 缺口复勘', lane: 'doing', sceneCode: 'QB01-G-4-1' } })
    check('面板：任务创建（泳道 + 场景引用）', taskCreated.ok && taskCreated.data.task.lane === 'doing')
    const taskMoved = await api('POST', `/api/panel/tasks/${taskCreated.data.task.id}/transition`, { token: panelAdmin, body: { lane: 'done' } })
    check('面板：任务泳道迁移（doing → done）', taskMoved.ok && taskMoved.data.task.lane === 'done')
    const badLane = await api('POST', `/api/panel/tasks/${taskCreated.data.task.id}/transition`, { token: panelAdmin, body: { lane: 'archived' } })
    check('面板：非法泳道被拒', !badLane.ok)

    // -- 部门知识 ---------------------------------------------------------------
    const artCreated = await api('POST', '/api/panel/mfg/artifacts', { token: panelAdmin, body: { kind: 'diagnosis', title: '自测诊断卡', content: '四清单框架自测沉淀' } })
    const artList = await api('GET', '/api/panel/mfg/artifacts', { token: panelAdmin })
    check('面板：部门知识沉淀与列表', artCreated.ok && artList.ok && artList.data.artifacts.some((art) => art.title === '自测诊断卡'))

    // -- 场景图谱：装载 / 未激活拒绝 ----------------------------------------------
    const graph = await api('GET', '/api/panel/scenegraph?industry=QB01', { token: panelAdmin })
    const qb01SceneCount = Object.values(graph.data?.pack?.activities ?? {}).reduce((sum, list) => sum + list.length, 0)
    check('面板：QB01 场景图谱下发（一图四清单全字段）',
      graph.ok && qb01SceneCount >= 24 && graph.data.pack.activities.mfg.every((scene) => scene.tools.length > 0 && scene.models.length > 0 && scene.data.length > 0 && scene.talent.length > 0),
      `scenes=${qb01SceneCount}`)
    const graphLocked = await api('GET', '/api/panel/scenegraph?industry=JQR', { token: panelAdmin })
    check('面板：未装载图谱 honest 400（不冒充数据）', !graphLocked.ok && /未装载/.test(graphLocked.error.message))

    // -- 行业三态 + 激活审批链（申请 → 审批（高风险二次确认）→ 激活生效） -------------
    const industries = await api('GET', '/api/panel/industries', { token: panelAdmin })
    check('面板：行业三态（QB01/GCJX 已激活，JQR/NEV/PCB 待授权）',
      industries.ok
      && industries.data.industries.filter((ind) => ind.state === 'active').map((ind) => ind.code).sort().join(',') === 'GCJX,QB01'
      && industries.data.industries.filter((ind) => ind.state === 'locked').length === 3,
      JSON.stringify(industries.data?.industries?.map((ind) => `${ind.code}:${ind.state}`)))
    const actReq = await api('POST', '/api/panel/industries/NEV/activate-requests', { token: panelAdmin })
    check('面板：激活申请进入审批中心（industry.activation · high）',
      actReq.ok && actReq.data.approval.kind === 'industry.activation',
      JSON.stringify(actReq.error ?? actReq.data?.approval?.id))
    const actPending = (await api('GET', '/api/panel/industries', { token: panelAdmin })).data.industries.find((ind) => ind.code === 'NEV')
    check('面板：申请后行业显示审批中（pending 三态）', actPending.state === 'pending')
    const decideOk = await api('POST', `/api/approvals/${actReq.data.approval.id}/decide`, { token: approver, body: { decision: 'approve', opinion: '新能源汽车图谱启用', confirmed: true } })
    check('面板：审批通过 → 激活执行器生效（active + grantCapabilities）',
      decideOk.ok && decideOk.data.status === 'executed', JSON.stringify(decideOk.data?.execution ?? decideOk.error))
    const industriesAfter = await api('GET', '/api/panel/industries', { token: panelAdmin })
    check('面板：激活后 NEV 三态转 active', industriesAfter.data.industries.find((ind) => ind.code === 'NEV').state === 'active')
    const dupActivate = await api('POST', '/api/panel/industries/NEV/activate-requests', { token: panelAdmin })
    check('面板：重复激活申请被拒（已是激活态）', !dupActivate.ok && /已是激活态/.test(dupActivate.error.message))

    // -- panelAgentRuntime：诚实降级 + 真实模型调用 + panel:* 计量（D1 键格式） -------
    const mentionFallback = await api('POST', '/api/panel/mfg/messages', { token: panelAdmin, body: { channelId: mainChannel.id, text: '@设备运维 Agent 自测：请巡检 3# 冲床', ddSync: false } })
    await new Promise((resolve) => setTimeout(resolve, 600))
    const afterFallback = await api('GET', `/api/panel/mfg/messages?channelId=${mainChannel.id}&limit=10`, { token: panelAdmin })
    const fallbackReply = afterFallback.data.messages.find((m) => m.agentName === '设备运维 Agent' && /暂不能自主应答/.test(m.text))
    check('面板：@Agent 未绑定资产 → 诚实降级回包（不造假回复）', Boolean(fallbackReply), JSON.stringify(afterFallback.data?.messages?.at(-1)?.text ?? '').slice(0, 120))
    const fallbackTasks = await api('GET', '/api/panel/mfg/tasks', { token: panelAdmin })
    check('面板：降级转人工待办落看板', fallbackTasks.ok && fallbackTasks.data.tasks.some((task) => task.createdBy.startsWith('agent:') && task.lane === 'todo'))

    // stub 模型 + Agent 资产 + 阵容绑定 → 真实单轮调用
    const panelModelStub = createServer((req, res) => {
      if ((req.url ?? '').endsWith('/chat/completions')) {
        res.writeHead(200, { 'content-type': 'application/json' })
        res.end(JSON.stringify({ choices: [{ message: { content: '质检结论：一次装机合格率 93.2%（±0.4pp），无异常波动。' } }], usage: { prompt_tokens: 100, completion_tokens: 40 } }))
        return
      }
      res.writeHead(404).end('{}')
    })
    await new Promise((resolve) => panelModelStub.listen(0, '127.0.0.1', resolve))
    try {
      // agent 资产的 model 属性受资源 schema 枚举约束（deepseek-*），故覆盖登记 deepseek-chat 指向 stub
      const modelReg = await api('POST', '/api/modelgw/models', { token: panelAdmin, body: { slug: 'deepseek-chat', displayName: 'DeepSeek Chat（面板自测 stub）', provider: 'deepseek', endpoint: `http://127.0.0.1:${panelModelStub.address().port}/v1`, apiKey: 'stub-key', listCentsPerKTokens: 1, costCentsPerKTokens: 0 } })
      const agentAsset = await api('POST', '/api/agents', { token: panelAdmin, body: { name: '面板质检员', slug: 'panel-qc', attrs: { description: '部门面板质检数字同事（自测）', avatar: '🔍', model: 'deepseek-chat', systemPrompt: '你是制造部质检数字同事。', riskLevel: 'low', dataClass: 'internal' } } })
      check('面板：stub 模型 + Agent 资产就绪', modelReg.ok && agentAsset.ok, JSON.stringify({ modelReg: modelReg.error, agent: agentAsset.error }))
      const roster = await api('PUT', '/api/panel/mfg/agents', { token: panelAdmin, body: { agents: [
        { name: '排产优化 Agent', desc: 'APS 齐套排产 / 插单重排', icon: '📅' },
        { name: '设备运维 Agent', desc: '点检提醒 / 故障预判 / 维修工单', icon: '⚙️' },
        { name: '面板质检员', desc: 'SPC 监控 / 合格率追溯', icon: '🔍', agentRef: `agent:${agentAsset.data.agent?.slug ?? agentAsset.data.agent?.id ?? 'panel-qc'}` },
      ] } })
      check('面板：阵容绑定 agentRef（panel.config.write）', roster.ok, JSON.stringify(roster.error))
      const mentionReal = await api('POST', '/api/panel/mfg/messages', { token: panelAdmin, body: { channelId: mainChannel.id, text: '@面板质检员 今天一次装机合格率有波动吗？', ddSync: false } })
      check('面板：@面板质检员 消息已发', mentionReal.ok)
      await new Promise((resolve) => setTimeout(resolve, 1200))
      const afterReal = await api('GET', `/api/panel/mfg/messages?channelId=${mainChannel.id}&limit=10`, { token: panelAdmin })
      const realReply = afterReal.data.messages.find((m) => m.agentName === '面板质检员')
      check('面板：panelAgentRuntime 单轮真实调用（modelgw → 回包落库）',
        Boolean(realReply) && /一次装机合格率 93.2%/.test(realReply.text),
        JSON.stringify(realReply?.text ?? afterReal.data?.messages?.at(-1)?.text ?? '').slice(0, 160))
      const recentUsage = await api('GET', '/api/usage/events?resource=' + encodeURIComponent('panel:mfg.qb01') + '&limit=50', { token: panelAdmin })
      check('面板：协作计量落账（D1 键格式 panel:mfg.qb01，价格簿零费率放行）',
        recentUsage.ok && recentUsage.data.items.some((item) => item.resource === 'panel:mfg.qb01'),
        JSON.stringify(recentUsage.data?.items?.map((item) => item.resource)))

      // -- 面板模型目录面（与 dsh 服务共用 modelgw 唯一事实源）+ 对话框模型切换 -----------
      const panelModelsList = await api('GET', '/api/panel/models', { token: panelAdmin })
      check('面板：模型目录读取（GET /api/panel/models，直填 apiKey 脱敏不回显）',
        panelModelsList.ok && panelModelsList.data.models.some((item) => item.slug === 'deepseek-chat')
        && !JSON.stringify(panelModelsList.data).includes('stub-key'),
        JSON.stringify(panelModelsList.error ?? panelModelsList.data?.models?.map((item) => item.slug)))
      const panelModelUpsert = await api('POST', '/api/panel/models', { token: panelAdmin, body: { slug: 'qwen-plus', displayName: 'Qwen Plus（面板登记）', provider: 'aliyun', endpoint: `http://127.0.0.1:${panelModelStub.address().port}/v1`, apiKey: 'panel-stub-key', listCentsPerKTokens: 2, costCentsPerKTokens: 1 } })
      check('面板：模型登记 upsert（POST /api/panel/models，panel.config.write；回显脱敏）',
        panelModelUpsert.ok && panelModelUpsert.data.slug === 'qwen-plus' && panelModelUpsert.data.apiKey === '***',
        JSON.stringify(panelModelUpsert.error ?? panelModelUpsert.data?.apiKey))
      const panelModelKeepKey = await api('POST', '/api/panel/models', { token: panelAdmin, body: { slug: 'qwen-plus', displayName: 'Qwen Plus（面板登记·改）', endpoint: `http://127.0.0.1:${panelModelStub.address().port}/v1`, listCentsPerKTokens: 2 } })
      check('面板：编辑模型留空 apiKey 保持既有密钥（不被默认 env 引用覆盖）',
        panelModelKeepKey.ok && panelModelKeepKey.data.displayName === 'Qwen Plus（面板登记·改）', JSON.stringify(panelModelKeepKey.error))
      const panelModelTest = await api('POST', '/api/panel/models/qwen-plus/test', { token: panelAdmin })
      check('面板：模型连通性测试（真实走 modelgw.invoke 全链，失败如实回传不造假成功）',
        panelModelTest.ok && panelModelTest.data.ok === true && panelModelTest.data.content.length > 0,
        JSON.stringify(panelModelTest.data ?? panelModelTest.error))
      const switchMsg = await api('POST', '/api/panel/mfg/messages', { token: panelAdmin, body: { channelId: mainChannel.id, text: '@面板质检员 切换模型后再答一次：合格率波动结论？', model: 'qwen-plus', ddSync: false } })
      check('面板：对话框指定模型发送（POST messages 带 model）', switchMsg.ok, JSON.stringify(switchMsg.error))
      await new Promise((resolve) => setTimeout(resolve, 1200))
      const afterSwitch = await api('GET', `/api/panel/mfg/messages?channelId=${mainChannel.id}&limit=10`, { token: panelAdmin })
      const switchReply = afterSwitch.data.messages.find((m) => m.agentName === '面板质检员' && m.model === 'qwen-plus')
      check('面板：对话框模型切换生效（modelOverride 优先于资产 model，回包记录实际所用模型）', Boolean(switchReply),
        JSON.stringify(afterSwitch.data?.messages?.filter((m) => m.agentName)?.map((m) => ({ t: String(m.text).slice(0, 30), model: m.model }))))
      const badModelMsg = await api('POST', '/api/panel/mfg/messages', { token: panelAdmin, body: { channelId: mainChannel.id, text: '未登记模型应被拒', model: 'no-such-model', ddSync: false } })
      check('面板：对话框指定未登记模型被拒（400，诚实报错）', badModelMsg.status === 400, JSON.stringify(badModelMsg.error))
      const panelModelDel = await api('DELETE', `/api/panel/models/${panelModelUpsert.data.id}`, { token: panelAdmin })
      check('面板：模型删除（DELETE /api/panel/models/:id，登记移除后目录不含）',
        panelModelDel.ok && panelModelDel.data.deleted === true
        && !(await api('GET', '/api/panel/models', { token: panelAdmin })).data.models.some((item) => item.slug === 'qwen-plus'),
        JSON.stringify(panelModelDel.error))
    } finally {
      panelModelStub.close()
    }

    // -- widget 求值：connector 源诚实降级 + 配置抽屉 ------------------------------
    const widgetsPut = await api('PUT', '/api/panel/mfg/widgets', { token: panelAdmin, body: { widgets: [
      { id: 'w1', type: 'bars', title: '📊 产线实时状态', live: true, source: 'mock', rows: [['冲压一线', 92, '']] },
      { id: 'w2', type: 'bars', title: '📈 设备联网率（ERP）', source: 'connector', ref: 'erp.oee-line', rows: [] },
    ] } })
    check('面板：widget 布局写入（含来源徽标声明）', widgetsPut.ok && widgetsPut.data.widgets.length === 2)
    const boardAfter = await api('GET', '/api/panel/mfg/board', { token: panelAdmin })
    const degradedWidget = boardAfter.data.widgets.find((widget) => widget.id === 'w2')
    check('面板：connector 源 widget 显式降级（绝不冒充真实业务面）',
      Boolean(degradedWidget) && degradedWidget.degraded === true && /连接器/.test(degradedWidget.source),
      JSON.stringify(degradedWidget))
    const widgetsRestore = await api('PUT', '/api/panel/mfg/widgets', { token: panelAdmin, body: { widgets: [
      { id: 'w1', type: 'bars', title: '📊 产线实时状态', live: true, source: 'mock', rows: [['冲压一线', 92, ''], ['组装二线', 76, 'warn'], ['包装三线 · 换型中', 41, 'danger']] },
      { id: 'w2', type: 'alerts', title: '🚨 异常告警', source: 'mock', rows: [['r', '停机', '冲压一线 3# 冲床油温过高，已待机 12 分钟'], ['y', '缺料', '组装二线 M-2207 物料 16:00 后缺口 800pcs']] },
      { id: 'w3', type: 'todos', title: '📋 今日工单', source: 'mock', rows: [['WO-2607 电机外壳 ×5000', '87%'], ['WO-2611 风扇组件 ×3200', '62%'], ['WO-2615 控制板 ×1800', '23%']] },
    ] } })
    check('面板：widget 布局复原', widgetsRestore.ok && widgetsRestore.data.widgets.length === 3)

    // -- SSE + 降级轮询（钉钉 webview 双通道铁律） -----------------------------------
    const sseEvents = []
    const sseController = new AbortController()
    const sseWorker = (async () => {
      const response = await fetch(`${BASE}/api/panel/stream?dept=mfg&token=${encodeURIComponent(panelAdmin)}`, { signal: sseController.signal })
      const reader = response.body.getReader()
      const decoder = new TextDecoder()
      // 持续读取直到抓到 panel.message.created（SSE 分块到达，首块只有 retry）
      for (let i = 0; i < 12; i++) {
        const { value, done } = await reader.read()
        if (done) break
        sseEvents.push(decoder.decode(value))
        if (sseEvents.join('').includes('panel.message.created')) break
      }
    })().catch(() => sseEvents.push('sse-failed'))
    await new Promise((resolve) => setTimeout(resolve, 700))
    await api('POST', '/api/panel/mfg/messages', { token: panelAdmin, body: { channelId: mainChannel.id, text: 'SSE 推流自测', ddSync: false } })
    await Promise.race([sseWorker, new Promise((resolve) => setTimeout(resolve, 4000))])
    sseController.abort()
    check('面板：SSE 通道建立且事件推送（公开路径 + ?token= 自校验）',
      sseEvents[0]?.includes('retry:') && sseEvents.join('').includes('panel.message.created'),
      JSON.stringify(sseEvents.map((chunk) => chunk.slice(0, 80))))
    const sseNoToken = await fetch(`${BASE}/api/panel/stream?dept=mfg`)
    check('面板：SSE 无 token 被拒（fail-closed）', sseNoToken.status === 401)
    const poll = await api('GET', `/api/panel/mfg/poll?since=${new Date(Date.now() - 60_000).toISOString()}`, { token: panelAdmin })
    check('面板：降级轮询端点（消息/任务/未读）',
      poll.ok && Array.isArray(poll.data.messages) && Array.isArray(poll.data.tasks) && Array.isArray(poll.data.unread),
      JSON.stringify(poll.error ?? ''))

    // -- RBAC 行为抽检（矩阵网全覆盖之外的业务语义） ----------------------------------
    const memberRole = (await api('GET', '/api/iam/roles', { token: panelAdmin })).data.roles.find((role) => role.code === 'member')
    const memberUser = await api('POST', '/api/iam/users', { token: panelAdmin, body: { username: 'panel_member', displayName: '面板成员', orgId: rootOrgId, roleIds: [memberRole.id] } })
    const memberLogin = await api('POST', '/api/auth/login', { body: { username: 'panel_member', password: memberUser.data.initialPassword } })
    const memberToken = memberLogin.data.token
    const memberRead = await api('GET', '/api/panel/mfg/overview', { token: memberToken })
    const memberConfig = await api('PUT', '/api/panel/mfg/kpis', { token: memberToken, body: { kpis: [] } })
    check('面板：成员可读总览（panel.read 迁移生效）但改配置被拒（403）',
      memberRead.ok && memberConfig.status === 403, `read=${memberRead.status} config=${memberConfig.status}`)

    // -- 账号组织打通：部门↔组织绑定 + 部门范围权限 + 名册/资产联动 -------------------
    const agentAssetOverview = await api('GET', '/api/panel/mfg/overview', { token: panelAdmin })
    check('面板：Agent 阵容联动资产状态（asset.status/model 实时解析自资源底座）',
      agentAssetOverview.data.agents.find((agent) => agent.name === '面板质检员')?.asset?.model === 'deepseek-chat',
      JSON.stringify(agentAssetOverview.data?.agents?.map((agent) => ({ n: agent.name, asset: agent.asset?.status }))))
    const boundOrg = await api('POST', '/api/iam/orgs', { token: panelAdmin, body: { name: '研发部（自测）' } })
    const orgBind = await api('PUT', '/api/panel/rd/config', { token: panelAdmin, body: { orgId: boundOrg.data.id } })
    check('面板：部门绑定组织（PUT config，账号组织打通管理动作）',
      orgBind.ok && orgBind.data.dept.org?.name === '研发部（自测）', JSON.stringify(orgBind.error ?? orgBind.data?.dept?.org))
    const rdUser = await api('POST', '/api/iam/users', { token: panelAdmin, body: { username: 'rd_scope_member', displayName: '研发部张工', orgId: boundOrg.data.id, roleIds: [memberRole.id] } })
    const rdLogin = await api('POST', '/api/auth/login', { body: { username: 'rd_scope_member', password: rdUser.data.initialPassword } })
    const rdOverview = await api('GET', '/api/panel/rd/overview', { token: rdLogin.data.token })
    check('面板：组织子树成员可访问已绑定部门 + 成员名册随总览下发',
      rdOverview.ok && rdOverview.data.org?.name === '研发部（自测）' && rdOverview.data.members.some((member) => member.name === '研发部张工'),
      JSON.stringify({ ok: rdOverview.ok, org: rdOverview.data?.org, members: rdOverview.data?.members?.length }))
    const outsiderDenied = await api('GET', '/api/panel/rd/overview', { token: memberToken })
    check('面板：组织外成员被部门范围权限拒绝（403，组织治理双通道）',
      outsiderDenied.status === 403 && /部门范围/.test(outsiderDenied.error?.message ?? ''), JSON.stringify(outsiderDenied.error))
    const outsiderDepts = await api('GET', '/api/panel/depts', { token: memberToken })
    check('面板：部门清单带 allowed 徽标（外部成员视角 rd 锁定/mfg 开放）',
      outsiderDepts.ok && outsiderDepts.data.depts.find((dept) => dept.id === 'rd').allowed === false
      && outsiderDepts.data.depts.find((dept) => dept.id === 'mfg').allowed === true)
    const adminCrossDept = await api('GET', '/api/panel/rd/overview', { token: panelAdmin })
    check("面板：'*' 管理员跨部门直通（治理豁免）", adminCrossDept.ok)
    // -- SSE 握手部门范围同规校验（QA BUG-A-01/T-01 回归）+ stream ticket 一次性通道（H4） --
    const sseUnknown = await fetch(`${BASE}/api/panel/stream?dept=zzzz&token=${encodeURIComponent(panelAdmin)}`)
    check('面板：SSE 未知部门 404（握手即断，绝不先订阅）', sseUnknown.status === 404, String(sseUnknown.status))
    const sseOutsider = await fetch(`${BASE}/api/panel/stream?dept=rd&token=${encodeURIComponent(memberToken)}`)
    const sseOutsiderBody = sseOutsider.status === 200 ? '' : await sseOutsider.text()
    check('面板：SSE 组织外成员 403（deptScopeAllowed 握手同规，QA BUG-A-01 根治）',
      sseOutsider.status === 403 && /部门范围/.test(sseOutsiderBody), `${sseOutsider.status} ${sseOutsiderBody.slice(0, 80)}`)
    const ticketRd = await api('POST', '/api/panel/stream-ticket', { token: rdLogin.data.token, body: { dept: 'rd' } })
    check('面板：stream ticket 签发（Bearer + panel.read + 部门范围校验，H4）',
      ticketRd.ok && /^stk_/.test(ticketRd.data?.ticket ?? '') && ticketRd.data?.expiresInSeconds === 60,
      JSON.stringify(ticketRd.error ?? ticketRd.data))
    const ticketRes = await fetch(`${BASE}/api/panel/stream?dept=rd&ticket=${encodeURIComponent(ticketRd.data.ticket)}`)
    const ticketReader = ticketRes.body?.getReader()
    const ticketHead = ticketReader ? new TextDecoder().decode((await ticketReader.read()).value) : ''
    await ticketReader?.cancel().catch(() => {})
    check('面板：ticket 换流成功（URL 只出现一次性短时凭证，不再携带长效 access token）',
      ticketRes.status === 200 && ticketHead.includes('retry:'), String(ticketRes.status))
    const ticketReplay = await fetch(`${BASE}/api/panel/stream?dept=rd&ticket=${encodeURIComponent(ticketRd.data.ticket)}`)
    check('面板：ticket 一次性消费（重放 401，消费即焚）', ticketReplay.status === 401, String(ticketReplay.status))
    const ticketOutsider = await api('POST', '/api/panel/stream-ticket', { token: memberToken, body: { dept: 'rd' } })
    check('面板：组织外成员签发 ticket 被拒 403（签发端同规校验）', ticketOutsider.status === 403, String(ticketOutsider.status))
    const ticketNoAuth = await fetch(`${BASE}/api/panel/stream-ticket`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ dept: 'rd' }) })
    check('面板：未认证签发 ticket 被拒 401', ticketNoAuth.status === 401, String(ticketNoAuth.status))
    const orgUnbind = await api('PUT', '/api/panel/rd/config', { token: panelAdmin, body: { orgId: null } })
    check('面板：解除组织绑定恢复开放', orgUnbind.ok && !orgUnbind.data.dept.org)
  }

  // ================================================================ J1 契约 v1 + 安全响应头 + usage 保留策略（2026-09-11 版本优化）
  section('J1 契约 v1：面板技能/Agent 点名直调（GET skills · POST skills/invoke · panel_*_invoke 工具）')
  {
    const j1Admin = admin
    // 专用 stub 模型（本段自备生命周期，不依赖面板段的 try/finally）
    const j1Stub = createServer((req, res) => {
      if ((req.url ?? '').endsWith('/chat/completions')) {
        res.writeHead(200, { 'content-type': 'application/json' })
        res.end(JSON.stringify({ choices: [{ message: { content: 'J1 直调自测应答：按技能指令完成。' } }], usage: { prompt_tokens: 80, completion_tokens: 60 } }))
        return
      }
      res.writeHead(404).end('{}')
    })
    await new Promise((resolve) => j1Stub.listen(0, '127.0.0.1', resolve))
    try {
      const j1Model = await api('POST', '/api/modelgw/models', { token: j1Admin, body: { slug: 'j1-stub-model', displayName: 'J1 直调自测', provider: 'deepseek', endpoint: `http://127.0.0.1:${j1Stub.address().port}/v1`, apiKey: 'stub-key', costCentsPerKTokens: 0 } })
      check('J1：stub 模型就绪', j1Model.ok, JSON.stringify(j1Model.error))
      // deepseek-chat 重指本段 stub：面板段 stub 已在 finally 关闭，而 mfg 名册「面板质检员」的资产 model 仍指向它
      await api('POST', '/api/modelgw/models', { token: j1Admin, body: { slug: 'deepseek-chat', displayName: 'DeepSeek Chat（面板自测 stub·J1 段接管）', provider: 'deepseek', endpoint: `http://127.0.0.1:${j1Stub.address().port}/v1`, apiKey: 'stub-key', listCentsPerKTokens: 1, costCentsPerKTokens: 0 } })
      const j1Channel = (await api('GET', '/api/panel/mfg/channels', { token: j1Admin })).data.channels[0]

      // 种一个已上架技能（提交 → 领域审批 → 上架）
      const j1Submit = await api('POST', '/api/skills', { token: j1Admin, body: { name: 'J1 直调自测技能', summary: 'J1 契约直调验证', content: '# J1 直调自测技能\n\n## 何时使用\n面板技能直调契约自测。\n\n## 步骤\n1. 点名直调\n2. 断言应答', category: '通用', version: '1.0.0' } })
      await api('POST', `/api/skills/${j1Submit.data.id}/approve`, { token: j1Admin, body: { decision: 'approve', level: 'domain', opinion: '契约自测' } })
      const j1Publish = await api('POST', `/api/skills/${j1Submit.data.id}/publish`, { token: j1Admin, body: {} })
      check('J1：直调技能上架就绪', j1Publish.ok && j1Publish.data.status === 'published', JSON.stringify(j1Publish.error))

      const j1Skills = await api('GET', '/api/panel/mfg/skills', { token: j1Admin })
      check('J1：可直调技能清单（published + 组织可见，行含 id/name/slug/version）',
        j1Skills.ok && j1Skills.data.skills.some((item) => item.name === 'J1 直调自测技能')
        && j1Skills.data.skills.every((item) => item.id && item.slug && item.version),
        JSON.stringify(j1Skills.error ?? j1Skills.data?.skills?.length))

      const j1Invoke = await api('POST', '/api/panel/mfg/skills/invoke', { token: j1Admin, body: { skill: 'J1 直调自测技能', message: '请按技能指令执行', channelId: j1Channel.id, model: 'j1-stub-model' } })
      check('J1：技能直调成功路径（200 + ok:true + reply + skill 元数据 + model 回显）',
        j1Invoke.status === 200 && j1Invoke.data.ok === true && /J1 直调自测应答/.test(j1Invoke.data.reply ?? '')
        && j1Invoke.data.skill?.name === 'J1 直调自测技能' && j1Invoke.data.model === 'j1-stub-model',
        JSON.stringify(j1Invoke.error ?? j1Invoke.data).slice(0, 180))
      const j1Msgs = (await api('GET', `/api/panel/mfg/messages?channelId=${j1Channel.id}&limit=30`, { token: j1Admin })).data.messages
      const j1Trace = j1Msgs.find((m) => m.senderType === 'human' && m.text.startsWith('/J1 直调自测技能'))
      const j1ReplyMsg = j1Msgs.find((m) => m.senderType === 'agent' && m.senderName === '⚡ J1 直调自测技能')
      check('J1：直调留痕——斜杠原文落频道（skipAgentDispatch）+ 应答落 ⚡ agent 消息（含 model）',
        Boolean(j1Trace) && Boolean(j1ReplyMsg) && j1ReplyMsg.model === 'j1-stub-model')

      const j1Auto = await api('POST', '/api/panel/mfg/skills/invoke', { token: j1Admin, body: { skill: 'J1 直调自测技能', message: '自动选模直调', channelId: j1Channel.id } })
      check('J1：未指定模型自动选「在线且已配 endpoint」模型（ghost-model 这类必败模型不被选中）',
        j1Auto.status === 200 && j1Auto.data.ok === true && j1Auto.data.model !== 'ghost-model',
        JSON.stringify(j1Auto.error ?? { model: j1Auto.data?.model, reason: j1Auto.data?.reason }))

      const j1Missing = await api('POST', '/api/panel/mfg/skills/invoke', { token: j1Admin, body: { skill: '不存在的技能XYZ', message: 'x', channelId: j1Channel.id } })
      check('J1：诚实降级——不存在技能 200 + ok:false + reason（降级是数据不是传输错误）',
        j1Missing.status === 200 && j1Missing.data.ok === false && /没有已上架/.test(j1Missing.data.reason ?? ''))
      const j1FailRow = (await api('GET', `/api/panel/mfg/messages?channelId=${j1Channel.id}&limit=30`, { token: j1Admin })).data.messages.find((m) => m.senderType === 'system' && /技能「不存在的技能XYZ」调用失败/.test(m.text))
      check('J1：失败原因落系统行全频道可见（不静默）', Boolean(j1FailRow))

      const j1Tool = await api('POST', '/api/tools/execute', { token: j1Admin, body: { name: 'panel_skill_invoke', args: { skill: 'J1 直调自测技能', message: '工具面同步直调' } } })
      check('J1：panel_skill_invoke 工具面（与 REST 同一服务原语）',
        j1Tool.ok && j1Tool.data.value?.ok === true && j1Tool.data.value.skill?.name === 'J1 直调自测技能',
        JSON.stringify(j1Tool.error ?? j1Tool.data?.value).slice(0, 160))
      const j1AgentTool = await api('POST', '/api/tools/execute', { token: j1Admin, body: { name: 'panel_agent_invoke', args: { dept: 'mfg', agent: '面板质检员', message: '工具面点名 Agent' } } })
      check('J1：panel_agent_invoke 工具面（askAgent 同步应答，不落频道消息）',
        j1AgentTool.ok && j1AgentTool.data.value?.ok === true && /J1 直调自测应答/.test(j1AgentTool.data.value.reply ?? ''),
        JSON.stringify(j1AgentTool.error ?? j1AgentTool.data?.value).slice(0, 160))
      const j1AgentMissing = await api('POST', '/api/tools/execute', { token: j1Admin, body: { name: 'panel_agent_invoke', args: { dept: 'mfg', agent: '不存在AgentXYZ', message: 'x' } } })
      check('J1：Agent 点名诚实降级（名册无此 Agent → ok:false + 可用阵容提示）',
        j1AgentMissing.ok && j1AgentMissing.data.value?.ok === false && /名册无此 Agent/.test(j1AgentMissing.data.value.reason ?? ''))

      // 可见性：orgs 限定技能不进清单、直调给 visibility 提示（对表定制侧 C1-2 语义）
      const j1OtherOrg = await api('POST', '/api/iam/orgs', { token: j1Admin, body: { name: 'J1 可见性对照组织' } })
      const j1Scope = await api('PATCH', `/api/skills/${j1Submit.data.id}`, { token: j1Admin, body: { visibility: 'orgs', targetOrgs: [j1OtherOrg.data.id] } })
      const j1ScopeList = await api('GET', '/api/panel/mfg/skills', { token: j1Admin })
      const j1ScopeInvoke = await api('POST', '/api/panel/mfg/skills/invoke', { token: j1Admin, body: { skill: 'J1 直调自测技能', message: 'x', channelId: j1Channel.id } })
      check('J1：orgs 限定技能按调用人组织过滤（清单不含 + 直调 visibility 提示 ok:false）',
        j1Scope.ok && !j1ScopeList.data.skills.some((item) => item.name === 'J1 直调自测技能')
        && j1ScopeInvoke.status === 200 && j1ScopeInvoke.data.ok === false && /未对当前用户组织开放/.test(j1ScopeInvoke.data.reason ?? ''),
        JSON.stringify({ scope: j1Scope.error, invoke: j1ScopeInvoke.data?.reason }))
      await api('PATCH', `/api/skills/${j1Submit.data.id}`, { token: j1Admin, body: { visibility: 'all' } })
    } finally {
      j1Stub.close()
    }
  }

  section('安全响应头（platform-core http.ts：nosniff / SAMEORIGIN / Referrer-Policy；SECURITY_HEADERS=off 关闭）')
  {
    const secRoot = await rawReq('GET', '/')
    check('安全响应头：静态页携带 nosniff / SAMEORIGIN / Referrer-Policy',
      secRoot.headers['x-content-type-options'] === 'nosniff'
      && secRoot.headers['x-frame-options'] === 'SAMEORIGIN'
      && secRoot.headers['referrer-policy'] === 'strict-origin-when-cross-origin',
      JSON.stringify({ nosniff: secRoot.headers['x-content-type-options'], frame: secRoot.headers['x-frame-options'], referrer: secRoot.headers['referrer-policy'] }))
    const secApi = await rawReq('GET', '/api/overview')
    check('安全响应头：401 API 响应同样携带（鉴权面不豁免）',
      secApi.status === 401 && secApi.headers['x-content-type-options'] === 'nosniff' && secApi.headers['x-frame-options'] === 'SAMEORIGIN',
      JSON.stringify(secApi.headers['x-content-type-options']))
  }

  section('usage 保留策略（USAGE_RETENTION_DAYS 默认 730d；POST /api/usage/retention/purge 手动巡检）')
  {
    const retOrg = (await api('GET', '/api/iam/orgs', { token: admin })).data.find((org) => org.parentId === null).id
    const oldEvent = await api('POST', '/api/usage/record', { token: admin, body: { org: retOrg, subject: 'user:admin', principal: `org:${retOrg}`, resource: 'panel:mfg.qb01', meters: [{ key: 'calls', value: 1, unit: '次' }], idempotency_key: 'retention-selftest-old-1', occurred_at: new Date(Date.now() - 1100 * 86_400_000).toISOString() } })
    check('保留策略：出窗历史事件回填成功（occurred_at 显式指定，约 3 年前）', oldEvent.ok, JSON.stringify(oldEvent.error))
    const purgeDefault = await api('POST', '/api/usage/retention/purge', { token: admin, body: {} })
    check('保留策略：默认窗口巡检清理出窗事件并回显 retentionDays',
      purgeDefault.ok && purgeDefault.data.retentionDays === 730 && purgeDefault.data.purgedEvents >= 1,
      JSON.stringify(purgeDefault.data ?? purgeDefault.error))
    const afterPurge = await api('GET', '/api/usage/events?resource=' + encodeURIComponent('panel:mfg.qb01') + '&limit=500', { token: admin })
    check('保留策略：出窗事件已不在流水，窗口内事件不受影响',
      afterPurge.ok && !afterPurge.data.items.some((item) => item.idempotency_key === 'retention-selftest-old-1'))
    const purgeZero = await api('POST', '/api/usage/retention/purge', { token: admin, body: { days: 0 } })
    check('保留策略：days=0 显式跳过（cutoff 为空，零清理）',
      purgeZero.ok && purgeZero.data.cutoff === '' && purgeZero.data.purgedEvents === 0, JSON.stringify(purgeZero.data))
    const memberRoleRet = (await api('GET', '/api/iam/roles', { token: admin })).data.roles.find((role) => role.code === 'member')
    const retMember = await api('POST', '/api/iam/users', { token: admin, body: { username: 'retention_member', displayName: '保留策略成员', orgId: retOrg, roleIds: [memberRoleRet.id] } })
    const retMemberToken = (await api('POST', '/api/auth/login', { body: { username: 'retention_member', password: retMember.data.initialPassword } })).data.token
    const purgeDenied = await api('POST', '/api/usage/retention/purge', { token: retMemberToken, body: {} })
    check('保留策略：无 usage.admin 被拒 403', purgeDenied.status === 403, String(purgeDenied.status))
  }

  // ================================================================ 钉钉桥接（review-dsh-agent-panel-v2 Phase 3）
  section('钉钉桥接（plugin-dingtalk-bridge：群桥 / 出向投递 / 审批推送 / 告警通道 / 回决 fail-closed）')
  {
    const ddSends = []
    const bridgeStub = createServer(async (req, res) => {
      const url = new URL(req.url ?? '/', 'http://stub')
      const raw = await readBody(req)
      if (url.pathname === '/v1.0/oauth2/accessToken') {
        const body = JSON.parse(raw || '{}')
        if (body.appKey === 'bridge-key' && body.appSecret === 'bridge-secret') {
          res.writeHead(200, { 'content-type': 'application/json' }).end(JSON.stringify({ accessToken: 'bridge-token', expireIn: 7200 }))
          return
        }
        res.writeHead(400, { 'content-type': 'application/json' }).end(JSON.stringify({ code: 'invalid.credentials' }))
        return
      }
      if (url.pathname === '/v1.0/robot/groupMessages/send') {
        ddSends.push({ chatId: JSON.parse(raw || '{}').openConversationId, at: Date.now() })
        res.writeHead(200, { 'content-type': 'application/json' }).end(JSON.stringify({ errcode: 0, errmsg: 'ok' }))
        return
      }
      res.writeHead(404).end('{}')
    })
    await new Promise((resolve) => bridgeStub.listen(0, '127.0.0.1', resolve))
    const bridgePort = bridgeStub.address().port

    const putReal = await api('PUT', '/api/iam/connectors/dingtalk', { token: admin, body: { corpId: 'ding-bridge', appKey: 'bridge-key', appSecret: 'bridge-secret', mode: 'real', apiBase: `http://127.0.0.1:${bridgePort}`, oapiBase: `http://127.0.0.1:${bridgePort}`, enabled: true, conflictStrategy: 'manual' } })
    check('桥接：连接器切 real（凭证单一来源=iam 连接器）', putReal.ok)
    const ddStatus = await api('GET', '/api/dingtalk/status', { token: admin })
    check('桥接：状态胶囊（连接器 real / 入向 R-SPIKE 停用声明 / 扫码绑定事实源）',
      ddStatus.ok && ddStatus.data.connector.mode === 'real'
      && ddStatus.data.inbound.enabled === false && /R-SPIKE/.test(ddStatus.data.inbound.reason)
      && /sso\/bind/.test(ddStatus.data.bindPath),
      JSON.stringify(ddStatus.data))

    const mfgChannels = await api('GET', '/api/panel/mfg/channels', { token: admin })
    const syncChannel = mfgChannels.data.channels.find((channel) => channel.name === '异常快速响应群') ?? mfgChannels.data.channels[0]
    const bindBridge = await api('POST', `/api/dingtalk/channels/${syncChannel.id}/bridge`, { token: admin, body: { chatId: 'cid-mfg-001', robotCode: 'rb-001' } })
    check('桥接：频道群桥绑定（dingtalk.message.send）', bindBridge.ok && bindBridge.data.bridge.chatId === 'cid-mfg-001', JSON.stringify(bindBridge.error ?? bindBridge.data))
    const bindAlerts = await api('POST', '/api/dingtalk/channels/alerts-ops/bridge', { token: admin, body: { chatId: 'cid-alerts', robotCode: 'rb-001', purpose: 'alerts' } })
    check('桥接：运维告警群桥绑定（purpose=alerts）', bindAlerts.ok && bindAlerts.data.bridge.purpose === 'alerts', JSON.stringify(bindAlerts.error ?? bindAlerts.data))
    const bridges = await api('GET', '/api/dingtalk/bridges?dept=mfg', { token: admin })
    check('桥接：群桥列表可查', bridges.ok && bridges.data.bridges.length >= 1, JSON.stringify(bridges.error ?? bridges.data))

    // 出向投递：面板消息（ddSync）→ 桥接 → stub 收到 → 回执回写 ddSync=sent
    const ddMsg = await api('POST', '/api/panel/mfg/messages', { token: admin, body: { channelId: syncChannel.id, text: '桥接出向自测：换模窗口确认', ddSync: true } })
    check('桥接：消息带钉钉同步意图（ddSync=pending）', ddMsg.ok && ddMsg.data.message.ddSync === 'pending')
    await new Promise((resolve) => setTimeout(resolve, 900))
    const ddMsgAfter = await api('GET', `/api/panel/mfg/messages?channelId=${syncChannel.id}&limit=5`, { token: admin })
    const sentMsg = ddMsgAfter.data.messages.find((m) => m.id === ddMsg.data.message.id)
    check('桥接：出向投递成功且回执回写（ddSync=sent）', sentMsg.ddSync === 'sent' && ddSends.some((send) => send.chatId === 'cid-mfg-001'),
      JSON.stringify({ ddSync: sentMsg.ddSync, sends: ddSends.length }))

    // 卡片/场景卡推送（panel.card.action dd.push 路径）
    const sendsBeforeScene = ddSends.length
    const sceneSync = await api('POST', '/api/panel/mfg/scenes/QB01-A-2-5/sync-dingtalk', { token: admin })
    await new Promise((resolve) => setTimeout(resolve, 700))
    check('桥接：场景卡同步钉钉（dd.push → 群投递）', sceneSync.ok && ddSends.length > sendsBeforeScene, JSON.stringify({ ok: sceneSync.ok, sends: ddSends.length }))

    // 告警 dingtalk 通道坐实：usage 对账不平 → audit.alert.fired → alerts 群桥投递
    const sendsBeforeAlert = ddSends.length
    const reconcile = await api('POST', '/api/usage/reconcile', { token: admin })
    await new Promise((resolve) => setTimeout(resolve, 900))
    check('桥接：告警经 purpose=alerts 群桥投递（补齐 channels:[dingtalk] 欠账）',
      reconcile.ok && ddSends.filter((send) => send.chatId === 'cid-alerts').length >= 1,
      JSON.stringify({ reconcileOk: reconcile.ok, alertSends: ddSends.filter((send) => send.chatId === 'cid-alerts').length, total: ddSends.length, before: sendsBeforeAlert }))

    // 审批推送
    const pcbReq = await api('POST', '/api/panel/industries/PCB/activate-requests', { token: admin })
    const approvalPush = await api('POST', `/api/dingtalk/approvals/${pcbReq.data.approval.id}/push`, { token: admin })
    check('桥接：审批单推送钉钉', approvalPush.ok && approvalPush.data.delivered === true, JSON.stringify(approvalPush.data ?? approvalPush.error))

    // 回决写回：staffId 反查 fail-closed 三连
    const cbNoLink = await api('POST', '/api/dingtalk/bridge/callback', { token: admin, body: { staffId: 'nobody-staff', approvalId: pcbReq.data.approval.id, decision: 'approve' } })
    check('桥接：未绑定 staffId 回决被拒（fail-closed）', !cbNoLink.ok && /未绑定/.test(cbNoLink.error.message))
    // QA A-05：回决人须非提交人——绑定第二审批人（approver02）作为钉钉侧回决身份
    const dingApprover = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('第二审批人'), { token: admin })).data.users[0]
    await api('POST', `/api/iam/users/${dingApprover.id}/bindings`, { token: admin, body: { provider: 'dingtalk', unionId: 'selftest-staff-001', displayName: '第二审批人' } })
    const cbOk = await api('POST', '/api/dingtalk/bridge/callback', { token: admin, body: { staffId: 'selftest-staff-001', approvalId: pcbReq.data.approval.id, decision: 'approve', opinion: '钉钉侧回决（自测）', confirmed: true } })
    check('桥接：合规回决写回（staffId↔identityLinks 反查 + confirmed）→ 审批执行',
      cbOk.ok && cbOk.data.approval.status === 'executed', JSON.stringify(cbOk.data ?? cbOk.error))
    const pcbAfter = (await api('GET', '/api/panel/industries', { token: admin })).data.industries.find((ind) => ind.code === 'PCB')
    check('桥接：回决生效后 PCB 行业转 active', pcbAfter.state === 'active')

    // 解绑 + 恢复 mock（不污染后续断言）
    const unbind = await api('DELETE', `/api/dingtalk/channels/${syncChannel.id}/bridge`, { token: admin })
    check('桥接：群桥解绑', unbind.ok && unbind.data.deleted === true, JSON.stringify(unbind.error ?? unbind.data))
    const restoreMock = await api('PUT', '/api/iam/connectors/dingtalk', { token: admin, body: { corpId: 'ding-yuanbingke', appKey: 'demo-app-key', appSecret: 'demo-secret-do-not-use', mode: 'mock', enabled: true } })
    check('桥接：连接器恢复 mock（自测收尾）', restoreMock.ok && restoreMock.data.mode === 'mock')
    await new Promise((resolve) => bridgeStub.close(resolve))
  }

  // ================================================================ dsh 宿主挂载（plugin-dsh-bridge，dev-plan-agent-host-unification M1）
  // 进程内构造最小插件树：platform-core（不监听）+ dsh-bridge（挂载半），
  // 用伪造 dsh webServer 捕获注册的 prefix 路由，再经真实 HTTP 端口模拟 dsh 侧分发。
  section('dsh 宿主挂载（单进程单入口 /rq 前缀）')
  {
    const captured = []
    const taps = []
    const fakeWebServer = {
      register: (route) => { captured.push(route); return () => {} },
      tapIndex: (transform) => { taps.push(transform); return () => {} },
    }
    const bridgeDataDir = join(DATA_DIR, 'bridge-mount')
    await mkdir(bridgeDataDir, { recursive: true })
    const mountCtx = new Context()
    await mountCtx.plugin(platformCore, { dataDir: bridgeDataDir, http: { port: 0, externalBase: '/rq' }, startHttp: false })
    // 完整业务树（等价 boot-all 依赖序；startHttp=false → 数据面经 bridge 挂载）：
    await mountCtx.plugin(resourceCore)
    await mountCtx.plugin(iam)
    await mountCtx.plugin(authn)
    await mountCtx.plugin(usage)
    await mountCtx.plugin(audit)
    await mountCtx.plugin(market)
    await mountCtx.plugin(connector)
    await mountCtx.plugin(mcp)
    await mountCtx.plugin(nas)
    await mountCtx.plugin(skillhub)
    await mountCtx.plugin(agent)
    await mountCtx.plugin(app)
    await mountCtx.plugin(modelgw)
    await mountCtx.plugin(connect, { role: 'host' })
    await mountCtx.plugin(update)
    // 先于 console：门户端点在其鉴权中间件之前截获 /api/portal/*
    await mountCtx.plugin(portal)
    await mountCtx.plugin(consolePlugin) // 基线初始化：内置角色 + 根组织 + admin
    // 部门面板 + 钉钉桥接（review-dsh-agent-panel-v2）：与 boot-all 同序（console 之后）
    await mountCtx.plugin(panelCore)
    await mountCtx.plugin(dingtalkBridge)
    await mountCtx.plugin(dshBridge, { mountPath: '/rq' })
    mountCtx.httpServer.register('GET', '/api/__mount_probe', (exchange) => exchange.ok({ pong: exchange.path }), { access: 'authenticated' })
    // 将伪造 webServer 提供给 ctx 后正常装配（等价 dsh 形态：inject 完成后 apply）
    // 绑定服务显式构造（注册在真实 mountCtx 上，供 plugin-nas 出站归因读取）；
    // apply 以「服务视图」调用——等价 dsh 形态下 inject 完成后的装配
    // OIDC 授权码通道凭证（register-dsh-agent.mjs 产物形态）
    writeFileSync(join(bridgeDataDir, 'dsh-agent-credential.json'), JSON.stringify({
      agentId: 'agt_mount_test',
      oidc: { clientId: 'oc-selftest-bridge', clientSecret: 'ocs_selftest_secret' },
    }))
    const bindingService = new dshBridge.IdentityBindingService(mountCtx, {})
    dshBridge.apply(
      { webServer: fakeWebServer, httpServer: mountCtx.httpServer, entryTickets: mountCtx.entryTickets, oidc: mountCtx.oidc, iam: mountCtx.iam, authn: mountCtx.authn, audit: mountCtx.audit, logger: (name) => mountCtx.logger(name), identityBinding: bindingService },
      { mountPath: '/rq', oidcCredentialFile: join(bridgeDataDir, 'dsh-agent-credential.json') },
    )
    check('bridge 向 webServer 注册挂载路由（/rq + /auth/entry + /dsh-bridge + /auth/oidc/*）',
      captured.some((r) => r.kind === 'prefix' && r.path === '/rq') && captured.some((r) => r.kind === 'exact' && r.path === '/auth/entry')
      && captured.some((r) => r.kind === 'prefix' && r.path === '/dsh-bridge') && captured.some((r) => r.kind === 'exact' && r.path === '/auth/oidc/start')
      && captured.some((r) => r.kind === 'exact' && r.path === '/auth/oidc/callback'),
      JSON.stringify(captured.map((r) => `${r.kind}:${r.path}`)))
    check('externalBase 配置生效（/rq）', mountCtx.httpServer.externalBase === '/rq')

    // -- M0-1 死信重放演练：消费 3 次失败入死信 → 修复后重投成功且不双计 ----------
    let drillFail = true
    let drillHandled = 0
    mountCtx.usage.consume('selftest-drill', (event) => {
      drillHandled++
      if (drillFail) throw new Error('drill 注入失败')
      mountCtx.usage.project('selftest-drill', event)
    })
    const drillEvent = mountCtx.usage.record({
      org: 'drill-org', subject: 'agent:drill-bot', principal: 'platform',
      resource: 'app:app-drill', meters: [{ key: 'calls', value: 1, unit: 'call' }],
      idempotency_key: 'selftest-drill-001',
    })
    const drillLetters = mountCtx.usage.deadLetters().all()
    check('M0-1 死信演练：消费连续 3 次失败入死信',
      drillLetters.some((letter) => letter.event_id === drillEvent.event_id && letter.consumer === 'selftest-drill'),
      JSON.stringify(drillLetters))
    drillFail = false
    const drillRetry = mountCtx.usage.retryDeadLetters()
    const projectionAfter = mountCtx.opsStorage.collection('usage:projection:selftest-drill').all().reduce((sum, row) => sum + row.count, 0)
    check('M0-1 死信重投：修复后重投成功且投影恰好一次', drillRetry.retried >= 1 && drillHandled === 4 && projectionAfter === 1,
      JSON.stringify({ drillRetry, drillHandled, projectionAfter }))
    mountCtx.usage.replay(new Date(Date.now() - 3_600_000).toISOString())
    const projectionAfterReplay = mountCtx.opsStorage.collection('usage:projection:selftest-drill').all().reduce((sum, row) => sum + row.count, 0)
    check('M0-1 死信重投后 replay 不双计（消费水位幂等）', projectionAfterReplay === 1, String(projectionAfterReplay))

    // -- H3 白盒回归：宽限窗口外旧 token 重放 = 硬重放，整链吊销（含宽限兄弟对） ----------
    const gracePrincipal = mountCtx.authn.ensureHumanPrincipal('selftest-grace-user', '宽限窗口自测')
    const gracePairA = mountCtx.authn.issueSessionPair(gracePrincipal.id, { issuedBy: 'selftest-grace' })
    const graceRotated = mountCtx.authn.refreshSession(gracePairA.refreshToken)
    const graceSibling = mountCtx.authn.refreshSession(gracePairA.refreshToken) // 窗口内：兄弟对自愈
    check('H3 白盒：宽限内二次兑换签发兄弟对（不吊销链）',
      graceSibling.refreshToken !== graceRotated.refreshToken
      && Boolean(mountCtx.authn.verify(graceRotated.token))
      && Boolean(mountCtx.authn.verify(graceSibling.token)))
    const graceOldHash = createHash('sha256').update(gracePairA.refreshToken).digest('hex')
    const graceOldRecord = mountCtx.authn.tokens().findOne((token) => token.refreshHash === graceOldHash)
    // 时间旅行：轮转时刻拨到 60s 前（窗口 30s）→ 旧 token 再现即硬重放
    mountCtx.authn.tokens().update(graceOldRecord.id, { rotatedAt: new Date(Date.now() - 60_000).toISOString() })
    let graceReplayThrew = false
    try { mountCtx.authn.refreshSession(gracePairA.refreshToken) } catch { graceReplayThrew = true }
    check('H3 白盒：宽限窗口外旧 token 重放被拒并整链吊销（重放防线不变）', graceReplayThrew)
    let graceChainDead = true
    try { mountCtx.authn.verify(graceRotated.token); graceChainDead = false } catch { /* 已吊销 */ }
    try { mountCtx.authn.verify(graceSibling.token); graceChainDead = false } catch { /* 已吊销 */ }
    check('H3 白盒：整链吊销覆盖轮转对与宽限兄弟对', graceChainDead)
    // 模拟 dsh webserver 分发：命中 /rq 前缀即交给 bridge handler，其余 404
    const sim = createServer((req, res) => {
      const exact = captured.find((r) => r.kind === 'exact' && (req.url ?? '').split('?')[0] === r.path)
      if (exact) { exact.handler(req, res); return }
      const route = captured.find((r) => r.kind === 'prefix' && (req.url === r.path || (req.url ?? '').startsWith(`${r.path}/`)))
      if (route) { route.handler(req, res); return }
      res.writeHead(404).end('sim-miss')
    })
    await new Promise((resolve) => sim.listen(0, '127.0.0.1', resolve))
    // 完整树下数据面带 console 鉴权中间件：先经 /rq/api/auth/login 换 Bearer（基线初始口令文件）
    const pwFile = join(bridgeDataDir, 'admin-initial-password.txt')
    const adminPassword = existsSync(pwFile)
      ? (readFileSync(pwFile, 'utf8').split('\n').map((l) => l.trim()).filter((l) => l && !l.startsWith('平台管理员'))[0] ?? '')
      : ''
    const loginRes = await fetch(`http://127.0.0.1:${sim.address().port}/rq/api/auth/login`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ username: 'admin', password: adminPassword || '自测兜底口令' }),
    })
    const adminToken = (await loginRes.json().catch(() => null))?.data?.token
    check('/rq/api/auth/login 可用（单入口下登录链路通）', Boolean(adminToken), `status=${loginRes.status}`)
    const simGet = async (path, token) => fetch(`http://127.0.0.1:${sim.address().port}${path}`, {
      redirect: 'manual', headers: token ? { authorization: `Bearer ${token}` } : {},
    })
    const probe = await simGet('/rq/api/__mount_probe', adminToken)
    const probeBody = await probe.json().catch(() => null)
    check('/rq/api/* 剥前缀后与独立形态路由等价（含 Bearer 鉴权链）', probe.status === 200 && probeBody?.data?.pong === '/api/__mount_probe', `status=${probe.status} body=${JSON.stringify(probeBody)}`)
    const redir = await simGet('/rq')
    check('/rq 302 归一到 /rq/（SPA 相对引用可解析）', redir.status === 302 && redir.headers.get('location') === '/rq/')
    const spa = await simGet('/rq/')
    check('/rq/ 伺服控制台 index.html（SPA fallback）', spa.status === 200 && (await spa.text()).includes('<!doctype html>'))
    const asset = await simGet('/rq/js/app.js')
    check('/rq/js/* 控制台静态资源按前缀命中', asset.status === 200 && String(asset.headers.get('content-type') ?? '').includes('javascript'), `status=${asset.status}`)
    const panelSpa = await simGet('/rq/panel/')
    check('/rq/panel/ 面板 SPA 经前缀挂载可达（宿主 web diff=0）', panelSpa.status === 200 && (await panelSpa.text()).includes('部门 Agent 工作台'), `status=${panelSpa.status}`)
    const panelBareMounted = await simGet('/rq/panel')
    check('/rq/panel 302 → /rq/panel/（externalBase 感知，与独立形态同语义）',
      panelBareMounted.status === 302 && panelBareMounted.headers.get('location') === '/rq/panel/',
      `status=${panelBareMounted.status} location=${panelBareMounted.headers.get('location')}`)
    const spaMiss = await simGet('/rq/anything-else')
    check('非 /api 未命中回落 SPA（与独立形态一致）', spaMiss.status === 200 && (await spaMiss.text()).includes('<!doctype html>'))
    const apiMiss = await simGet('/rq/api/definitely-missing', adminToken)
    const apiMissBody = await apiMiss.json().catch(() => null)
    check('未匹配 API 404 JSON 不落静态（DEF-01）', apiMiss.status === 404 && apiMissBody?.error?.code === 'NOT_FOUND')
    const simMiss = await fetch(`http://127.0.0.1:${sim.address().port}/outside`)
    check('前缀外请求不进榕器数据面（dsh 侧自有路由域不受影响）', simMiss.status === 404 && (await simMiss.text()) === 'sim-miss')

    // -- 身份半：票据兑换 → Cookie 绑定 → 状态 → 会话归因 → 实时失效（M4/M5） ----
    check('免登引导脚本经 tapIndex 注入', taps.length === 1 && taps[0]('<html><head></head></html>').includes('entry_ticket'))
    const simOrigin = `http://127.0.0.1:${sim.address().port}`
    const adminUser = mountCtx.iam.users().findOne((u) => u.username === 'admin')
    check('基线初始化（挂载形态最小树）产出 admin', Boolean(adminUser))
    const entryIssue = mountCtx.entryTickets.issue({ refType: 'agent', refId: 'agt_mount_test', userId: adminUser.id, userName: '平台管理员' })
    const entryRes = await fetch(`${simOrigin}/auth/entry?entry_ticket=${encodeURIComponent(entryIssue.ticket)}`, { redirect: 'manual' })
    const setCookie = entryRes.headers.get('set-cookie') ?? ''
    check('/auth/entry 兑换 → 302 / + Set-Cookie rq_sid（HttpOnly/SameSite=Lax）',
      entryRes.status === 302 && entryRes.headers.get('location') === '/' && setCookie.includes('rq_sid=rbs_') && setCookie.includes('HttpOnly') && setCookie.includes('SameSite=Lax'),
      `${entryRes.status} ${setCookie}`)
    const cookie = setCookie.split(';')[0] ?? ''
    const statusRes = await fetch(`${simOrigin}/dsh-bridge/status`, { headers: { cookie } })
    const statusBody = await statusRes.json()
    check('/dsh-bridge/status 读 Cookie 返回绑定身份', statusBody?.data?.bound === true && statusBody.data.identity?.sub === adminUser.id, JSON.stringify(statusBody))
    const statusAnon = await fetch(`${simOrigin}/dsh-bridge/status`)
    const statusAnonBody = await statusAnon.json()
    check('无 Cookie 状态查询 → 未绑定（不作身份推断）', statusAnonBody?.data?.bound === false)
    check('绑定自检原因码：无 Cookie → no_cookie（WP-04/A2 文案映射依据）', statusAnonBody?.data?.reason === 'no_cookie', JSON.stringify(statusAnonBody))
    const entryReplay = await fetch(`${simOrigin}/auth/entry?entry_ticket=${encodeURIComponent(entryIssue.ticket)}`, { redirect: 'manual' })
    check('票据重放被拒（一次性消费，redeem 抛错→400）', entryReplay.status === 400)
    const bindRes = await fetch(`${simOrigin}/dsh-bridge/bind-session`, {
      method: 'POST', headers: { 'content-type': 'application/json', cookie },
      body: JSON.stringify({ sessionId: 'sess-mount-1' }),
    })
    check('会话绑定 200（Cookie 定身份 → sessionId 关联）', bindRes.status === 200, JSON.stringify(await bindRes.json()))
    const boundViaSession = mountCtx.identityBinding.identityForSession('sess-mount-1')
    const boundFallback = mountCtx.identityBinding.identityForSession('sess-unknown')
    check('工具出站归因解析：会话绑定优先 / 未绑定回落最近绑定', boundViaSession?.userId === adminUser.id && boundFallback?.userId === adminUser.id, JSON.stringify({ boundViaSession, boundFallback }))
    mountCtx.iam.users().update(adminUser.id, { status: 'suspended' })
    const statusFrozen = await fetch(`${simOrigin}/dsh-bridge/status`, { headers: { cookie } })
    const statusFrozenBody = await statusFrozen.json()
    check('账号停用 → 绑定实时失效（兑换面已校验 + 读取面再校验）', statusFrozenBody?.data?.bound === false)
    check('绑定自检原因码：停用账号 → account_inactive（可识别、可出文案）', statusFrozenBody?.data?.reason === 'account_inactive', JSON.stringify(statusFrozenBody))
    mountCtx.iam.users().update(adminUser.id, { status: 'active' })
    const crossOrigin = await fetch(`${simOrigin}/dsh-bridge/status`, { headers: { origin: 'http://evil.example.com' } })
    check('绑定面同源收紧：跨站 Origin 403（对齐 dsh fence 语义）', crossOrigin.status === 403)

    // -- 宿主会话直通（review-dsh-agent-panel-v2 宿主打通）：rq_sid → 平台会话 → 面板 RBAC 面 --
    mountCtx.iam.users().update(adminUser.id, { status: 'active' })
    const sessionRes = await fetch(`${simOrigin}/dsh-bridge/session`, { method: 'POST', headers: { 'content-type': 'application/json', cookie } })
    const sessionBody = await sessionRes.json().catch(() => null)
    check('宿主会话直通：Cookie 绑定身份兑换平台会话（token + user + permissions）',
      sessionRes.status === 200 && sessionBody?.ok === true && Boolean(sessionBody.data?.token) && Array.isArray(sessionBody.data?.user?.permissions) && sessionBody.data.user.permissions.length > 0,
      JSON.stringify(sessionBody?.error ?? sessionBody?.data?.user?.displayName))
    const panelViaSession = await fetch(`${simOrigin}/rq/api/panel/depts`, { headers: { authorization: `Bearer ${sessionBody.data.token}` } })
    const panelViaSessionBody = await panelViaSession.json().catch(() => null)
    check('宿主会话直通：兑换令牌直通面板 RBAC 面（/rq/api/panel/depts 200）',
      panelViaSession.status === 200 && panelViaSessionBody?.ok === true && Array.isArray(panelViaSessionBody.data?.depts) && panelViaSessionBody.data.depts.length === 5,
      `status=${panelViaSession.status}`)
    const sessionNoCookie = await fetch(`${simOrigin}/dsh-bridge/session`, { method: 'POST' })
    const sessionNoCookieBody = await sessionNoCookie.json().catch(() => null)
    check('宿主会话直通：无 Cookie 401（NOT_BOUND fail-closed，同源面统一收紧）',
      sessionNoCookie.status === 401 && sessionNoCookieBody?.error?.code === 'NOT_BOUND')

    // -- behavior 消费语义（WP-03/D3，进程内直测：投递 / 死信 / 重放幂等） -----------
    const behaviorSeen = []
    const offBehavior = mountCtx.behavior.consume('selftest-observer', (event) => { behaviorSeen.push(event.event_id) })
    const bFirst = mountCtx.behavior.record({ subject: 'user:usr-behavior-test', type: 'funnel.step', platform: 'rd', payload: { step: 1 }, idempotency_key: 'b-selftest-001' })
    check('behavior 投递：先写后发（消费方收到首投）', bFirst.duplicated === false && behaviorSeen.includes(bFirst.event.event_id))
    const bDup = mountCtx.behavior.record({ subject: 'user:usr-behavior-test', type: 'funnel.step', platform: 'rd', payload: { step: 1 }, idempotency_key: 'b-selftest-001' })
    check('behavior 投递：幂等重放不重发（消费水位跳过 + duplicated 标记）',
      bDup.duplicated === true && behaviorSeen.filter((id) => id === bFirst.event.event_id).length === 1)
    mountCtx.behavior.consume('selftest-broken', () => { throw new Error('自测故障消费方') })
    const bFail = mountCtx.behavior.record({ subject: 'user:usr-behavior-test', type: 'card.clicked', idempotency_key: 'b-selftest-002' })
    check('behavior 投递：消费方连续 3 次失败入死信', mountCtx.behavior.deadLetters().all().some((letter) => letter.event_id === bFail.event.event_id && letter.consumer === 'selftest-broken'))
    check('behavior 投递：死信触发 critical 告警（audit.alert.fired）',
      mountCtx.platformBus.recent(50).some((event) => event.name === 'audit.alert.fired' && JSON.stringify(event.payload).includes('behavior 消费死信')))
    const behaviorBeforeReplay = behaviorSeen.length
    mountCtx.behavior.replay(new Date(0).toISOString())
    check('behavior 投递：replay 幂等（已消费事件不重投）', behaviorSeen.length === behaviorBeforeReplay)
    const retriedBehavior = mountCtx.behavior.retryDeadLetters()
    check('behavior 投递：死信重投（故障消费方仍失败则保留死信）', retriedBehavior.remaining >= 1 && mountCtx.behavior.deadLetters().all().some((letter) => letter.consumer === 'selftest-broken'))
    offBehavior()

    // -- OIDC 授权码通道（start 302 → PKCE；callback 坏 state 拒绝） -----------------
    const oidcStart = await fetch(`${simOrigin}/auth/oidc/start`, { redirect: 'manual' })
    const oidcLocation = oidcStart.headers.get('location') ?? ''
    check('/auth/oidc/start 302 平台授权页（client_id + PKCE S256 + state）',
      oidcStart.status === 302 && oidcLocation.startsWith(`${mountCtx.oidc.issuer()}/oauth/authorize`)
      && oidcLocation.includes('client_id=oc-selftest-bridge') && oidcLocation.includes('code_challenge_method=S256') && oidcLocation.includes('state='),
      `${oidcStart.status} ${oidcLocation}`)
    const oidcCallbackBad = await fetch(`${simOrigin}/auth/oidc/callback?code=x&state=bogus`, { redirect: 'manual' })
    check('/auth/oidc/callback 坏 state 被拒 400（防 CSRF/重放）', oidcCallbackBad.status === 400)
    await new Promise((resolve) => sim.close(resolve))
  }

  // ================================================================ IAW 交接批次（docs/handoff-iaw-gaps-to-main.md 2026-09-11）
  // 批次共享主体（模块顶层声明，跨分节复用）：根组织 / 成员账号 / 仅 console.login 的机器凭证
  const iawRootOrg = (await api('GET', '/api/iam/orgs', { token: admin })).data.find((org) => org.parentId === null)
  // 成员挂 mfg 部门绑定的组织（面板组织子树范围语义：通知/面板可见性同源）
  const iawMfgOrgId = (await api('GET', '/api/panel/depts', { token: admin })).data.depts.find((dept) => dept.id === 'mfg')?.orgId
  const iawMemberOrgId = iawMfgOrgId ?? iawRootOrg.id
  const iawMemberRole = (await api('GET', '/api/iam/roles', { token: admin })).data.roles.find((role) => role.code === 'member')
  const iawMemberInit = await api('POST', '/api/iam/users', { token: admin, body: { username: 'iaw_member', displayName: 'IAW 成员', orgId: iawMemberOrgId, roleIds: [iawMemberRole.id] } })
  const iawMemberInitPassword = iawMemberInit.data?.initialPassword ?? 'Ybk@2026'
  const iawMemberToken = (await api('POST', '/api/auth/login', { body: { username: 'iaw_member', password: iawMemberInitPassword } })).data.token
  const iawCred = await api('POST', '/api/authn/principals', { token: admin, body: { name: 'iaw-no-panel', refType: 'external', scopes: ['console.login'] } })
  const iawMachine = (await api('POST', '/api/auth/client-credentials', { body: { clientId: iawCred.data.clientId, clientSecret: iawCred.data.clientSecret } })).data.token

  section('IAW 4-1/4-2：usage 成本摘要与反馈聚合（面板度量驾驶舱数据源）')
  {
    const iawAdminSummary = await api('GET', '/api/usage/summary?window=today', { token: admin })
    check('4-1：管理员查摘要（scope=platform，cost_cents/byResource 齐备）',
      iawAdminSummary.ok && iawAdminSummary.data.scope === 'platform' && iawAdminSummary.data.window === 'today'
      && Number.isFinite(iawAdminSummary.data.cost_cents) && Array.isArray(iawAdminSummary.data.byResource)
      && Number.isFinite(iawAdminSummary.data.input_tokens) && Number.isFinite(iawAdminSummary.data.output_tokens),
      JSON.stringify({ scope: iawAdminSummary.data?.scope, cost: iawAdminSummary.data?.cost_cents }))
    const iawMonth = await api('GET', '/api/usage/summary?window=month', { token: admin })
    check('4-1：month 窗口边界为当月 1 日（UTC 口径）',
      iawMonth.ok && iawMonth.data.from === `${new Date().toISOString().slice(0, 7)}-01T00:00:00.000Z` && iawMonth.data.window === 'month',
      JSON.stringify({ from: iawMonth.data?.from }))
    const iawMemberSummary = await api('GET', '/api/usage/summary?window=today&org=other-org', { token: iawMemberToken })
    check('4-1：panel.read 成员强制收敛自身组织（传入 org=other 被忽略，scope=self-org）',
      iawMemberSummary.ok && iawMemberSummary.data.scope === 'self-org' && iawMemberSummary.data.org === iawMemberOrgId,
      JSON.stringify({ scope: iawMemberSummary.data?.scope, org: iawMemberSummary.data?.org }))
    const iawDenied = await api('GET', '/api/usage/summary', { token: iawMachine })
    check('4-1：无 panel.read 主体被拒 403', iawDenied.status === 403, String(iawDenied.status))

    // 4-2：一组全新 up/down 反馈 → 聚合口径与采纳率
    const fbUp = await api('POST', '/api/usage/feedback', { token: iawMemberToken, body: { resource: 'panel:mfg.qb01', messageId: 'iaw-msg-up-1', score: 'up' } })
    const fbDown = await api('POST', '/api/usage/feedback', { token: iawMemberToken, body: { resource: 'panel:mfg.qb01', messageId: 'iaw-msg-down-1', score: 'down' } })
    check('4-2：反馈落账（零价快照 up/down 各一条）', fbUp.ok && fbDown.ok, JSON.stringify({ up: fbUp.error, down: fbDown.error }))
    await api('POST', '/api/usage/feedback', { token: iawMemberToken, body: { resource: 'panel:mfg.qb01', messageId: 'iaw-msg-up-2', score: 'up' } })
    const fbReplayIaw = await api('POST', '/api/usage/feedback', { token: iawMemberToken, body: { resource: 'panel:mfg.qb01', messageId: 'iaw-msg-up-1', score: 'up' } })
    check('4-2：同键重放幂等（不重复计数）', fbReplayIaw.ok && fbReplayIaw.data.event_id === fbUp.data.event_id)
    const fbStats = await api('GET', '/api/usage/feedback-stats?days=7', { token: iawMemberToken })
    const iawRow = (fbStats.data?.byResource ?? []).find((row) => row.resource === 'panel:mfg.qb01')
    check('4-2：采纳率聚合（自测行 up=2/down=1，adoptionRate≈0.667，scope 收敛自身组织）',
      fbStats.ok && fbStats.data.scope === 'self-org' && iawRow && iawRow.up === 2 && iawRow.down === 1
      && Math.abs(iawRow.adoptionRate - 2 / 3) < 0.001 && fbStats.data.adoptionRate > 0 && fbStats.data.adoptionRate <= 1,
      JSON.stringify({ up: iawRow?.up, down: iawRow?.down, rate: iawRow?.adoptionRate, global: fbStats.data.adoptionRate }))
    const fbStatsAdmin = await api('GET', '/api/usage/feedback-stats?days=7', { token: admin })
    check('4-2：usage.read 主体可跨组织聚合（scope=platform 且含同资源行）',
      fbStatsAdmin.ok && fbStatsAdmin.data.scope === 'platform'
      && fbStatsAdmin.data.byResource.some((row) => row.resource === 'panel:mfg.qb01' && row.up >= 2))
  }

  section('IAW 5-1/5-2：结论级证据锚点 + 场景维度审计时间线')
  {
    const evPost = await api('POST', '/api/audit/evidence', { token: iawMemberToken, body: {
      sceneCode: 'QB01-G-4-1', messageId: 'iaw-msg-ev-1', subject: 'user:iaw_member',
      anchors: [
        { kind: 'dataset', id: 'ds_selftest_a', name: '自测数据集A', qualityScore: 92 },
        { kind: 'query', id: 'q-77', timeWindow: { from: '2026-09-01', to: '2026-09-11' }, hitRows: 42 },
      ],
    } })
    check('5-1：证据登记（2 锚点落库发 id，panel.write）', evPost.ok && evPost.data.anchors.length === 2, JSON.stringify(evPost.error))
    const evGet = await api('GET', `/api/audit/evidence/${evPost.data.id}`, { token: iawMemberToken })
    check('5-1：证据反查（锚点/时间窗/命中行数原样可读）',
      evGet.ok && evGet.data.anchors[1].hitRows === 42 && evGet.data.anchors[0].qualityScore === 92 && evGet.data.sceneCode === 'QB01-G-4-1')
    const ev404 = await api('GET', '/api/audit/evidence/evd_not_exist', { token: iawMemberToken })
    check('5-1：不存在的证据 404', ev404.status === 404, String(ev404.status))
    const evBad = await api('POST', '/api/audit/evidence', { token: iawMemberToken, body: { anchors: [{ kind: 'bogus', id: 'x' }] } })
    check('5-1：非法锚点 kind 被拒 400', !evBad.ok && /kind 非法/.test(evBad.error.message), JSON.stringify(evBad.error))
    const evMachineDenied = await api('POST', '/api/audit/evidence', { token: iawMachine, body: { anchors: [{ kind: 'doc', id: 'd1' }] } })
    check('5-1：无 panel.write 主体登记被拒 403', evMachineDenied.status === 403, String(evMachineDenied.status))

    // 5-2：任务带 sceneCode 创建/流转 → 审计时间线可反查
    const tlTask = await api('POST', '/api/panel/mfg/tasks', { token: admin, body: { title: 'IAW 时间线自测任务', lane: 'doing', sceneCode: 'QB01-G-4-2' } })
    check('5-2：带场景任务创建', tlTask.ok && tlTask.data.task.sceneCode === 'QB01-G-4-2', JSON.stringify(tlTask.error))
    const tlMove = await api('POST', `/api/panel/tasks/${tlTask.data.task.id}/transition`, { token: admin, body: { lane: 'done' } })
    check('5-2：任务流转', tlMove.ok, JSON.stringify(tlMove.error))
    const tl = await api('GET', '/api/audit/timeline?sceneCode=QB01-G-4-2', { token: iawMemberToken })
    const tlActions = (tl.data?.items ?? []).map((item) => item.action)
    check('5-2：场景时间线含 create+transition（panel.read 可读，倒序）',
      tl.ok && tlActions.includes('panel.task.create') && tlActions.includes('panel.task.transition')
      && tl.data.items[0].at >= tl.data.items[tl.data.items.length - 1].at,
      JSON.stringify(tlActions))
    const tlEmpty = await api('GET', '/api/audit/timeline?sceneCode=QB01-NOPE-0-0', { token: iawMemberToken })
    check('5-2：无痕场景时间线为空（诚实空集）', tlEmpty.ok && tlEmpty.data.total === 0 && tlEmpty.data.items.length === 0)
    const tlDenied = await api('GET', '/api/audit/timeline', { token: iawMachine })
    check('5-2：无 panel.read 主体被拒 403', tlDenied.status === 403, String(tlDenied.status))
  }

  section('IAW 8-1：通知中心持久化（任务/告警落账 + since/已读游标）')
  {
    const before = await api('GET', '/api/notifications', { token: iawMemberToken })
    const baselineUnread = before.data?.unread ?? 0
    // 任务事件 → 部门绑定组织范围通知（mfg 绑定组织后组织子树成员可见）
    const ntfTask = await api('POST', '/api/panel/mfg/tasks', { token: admin, body: { title: 'IAW 通知自测任务', lane: 'todo' } })
    check('8-1：触发事件（任务创建→流转产生 panel.task.updated）', ntfTask.ok, JSON.stringify(ntfTask.error))
    await api('POST', `/api/panel/tasks/${ntfTask.data.task.id}/transition`, { token: admin, body: { lane: 'doing' } })
    const after = await api('GET', '/api/notifications', { token: iawMemberToken })
    const taskNotif = (after.data?.items ?? []).find((item) => item.type === 'task' && /IAW 通知自测任务/.test(item.title))
    check('8-1：任务通知持久化并按组织范围可见（unread 递增）',
      after.ok && Boolean(taskNotif) && after.data.unread >= baselineUnread + 1,
      JSON.stringify({ count: after.data?.items?.length, unread: after.data?.unread }))
    // 告警事件（全局范围）：告警规则 threshold=0 + 一次越权 → audit.authz.denied → 告警 → 通知
    const ruleIaw = await api('POST', '/api/audit/alert-rules', { token: admin, body: { name: 'IAW 通知自测规则', metric: 'permission_denied', threshold: 0, severity: 'warning' } })
    const deniedHit = await api('POST', '/api/iam/orgs', { token: iawMachine, body: { name: 'IAW 通知触发越权' } })
    check('8-1：越权探针（403 触发 permission_denied 链路）', deniedHit.status === 403 && ruleIaw.ok, JSON.stringify({ denied: deniedHit.status }))
    await new Promise((resolve) => setTimeout(resolve, 400))
    const afterAlert = await api('GET', '/api/notifications', { token: iawMemberToken })
    check('8-1：告警通知落账（type=alert，全局范围）',
      afterAlert.ok && (afterAlert.data.items ?? []).some((item) => item.type === 'alert' && /IAW 通知自测规则/.test(item.title)),
      JSON.stringify(afterAlert.data?.items?.slice(0, 2).map((item) => item.title)))
    // 已读游标 + since 增量
    const markRead = await api('POST', '/api/notifications/read-cursor', { token: iawMemberToken, body: {} })
    check('8-1：已读游标推进', markRead.ok && markRead.data.unread === 0, JSON.stringify(markRead.data))
    const afterRead = await api('GET', '/api/notifications', { token: iawMemberToken })
    check('8-1：游标后 unread=0 且历史可见（游标语义非删除）', afterRead.ok && afterRead.data.unread === 0 && afterRead.data.items.length >= 1)
    const sinceNow = await api('GET', '/api/notifications?since=' + encodeURIComponent(markRead.data.readCursor), { token: iawMemberToken })
    check('8-1：since 增量拉取（游标后零新增）', sinceNow.ok && sinceNow.data.items.length === 0, JSON.stringify(sinceNow.data?.items?.length))
    const machineNotif = await api('GET', '/api/notifications', { token: iawMachine })
    check('8-1：机器主体无个人通知面（空集诚实返回）', machineNotif.ok && machineNotif.data.items.length === 0 && /机器主体/.test(machineNotif.data.note ?? ''))
  }

  section('IAW 1-1..1-4：模型渠道分级路由 / 降级链 / 遥测 / 预算熔断')
  {
    // 双 stub：主渠道恒 500，备渠道正常应答
    const gwPrimaryStub = createServer((req, res) => {
      if ((req.url ?? '').endsWith('/chat/completions')) { res.writeHead(500).end('{"error":"primary down"}'); return }
      res.writeHead(404).end('{}')
    })
    const gwBackupStub = createServer((req, res) => {
      if ((req.url ?? '').endsWith('/chat/completions')) {
        res.writeHead(200, { 'content-type': 'application/json' })
        res.end(JSON.stringify({ choices: [{ message: { content: '降级链自测：备用渠道应答' } }], usage: { prompt_tokens: 10, completion_tokens: 5 } }))
        return
      }
      res.writeHead(404).end('{}')
    })
    await new Promise((resolve) => gwPrimaryStub.listen(0, '127.0.0.1', resolve))
    await new Promise((resolve) => gwBackupStub.listen(0, '127.0.0.1', resolve))
    try {
      const primaryPort = gwPrimaryStub.address().port
      const backupPort = gwBackupStub.address().port
      // 1-1 分级：public 上限渠道 + secret 数据 → 直接拒绝（选择器锁死+原因）
      const regPub = await api('POST', '/api/modelgw/models', { token: admin, body: { slug: 'iaw-pub', displayName: '公开级渠道', endpoint: `http://127.0.0.1:${backupPort}/v1`, apiKey: 'stub', costCentsPerKTokens: 0, dataClassLimit: 'public' } })
      const regSecret = await api('POST', '/api/modelgw/models', { token: admin, body: { slug: 'iaw-scr', displayName: '秘密级渠道', endpoint: `http://127.0.0.1:${primaryPort}/v1`, apiKey: 'stub', costCentsPerKTokens: 1, dataClassLimit: 'secret' } })
      const regSecretOk = await api('POST', '/api/modelgw/models', { token: admin, body: { slug: 'iaw-scrok', displayName: '秘密级可用渠道', endpoint: `http://127.0.0.1:${backupPort}/v1`, apiKey: 'stub', costCentsPerKTokens: 1, dataClassLimit: 'secret' } })
      const regBackup = await api('POST', '/api/modelgw/models', { token: admin, body: { slug: 'iaw-bkp', displayName: '内部级备用渠道', endpoint: `http://127.0.0.1:${backupPort}/v1`, apiKey: 'stub', costCentsPerKTokens: 1 } })
      check('1-1：四渠道登记（public/secret-500/secret-ok/默认 internal）', regPub.ok && regSecret.ok && regSecretOk.ok && regBackup.ok, JSON.stringify({ pub: regPub.error, scr: regSecret.error, scrok: regSecretOk.error, bkp: regBackup.error }))
      const gradedDeny = await api('POST', '/api/modelgw/invoke', { token: admin, body: { model: 'iaw-pub', messages: [{ role: 'user', content: 'x' }], orgId: iawRootOrg.id, dataClass: 'secret' } })
      check('1-1：秘密数据 → 公开级渠道被锁死拒绝（错误含原因）',
        gradedDeny.status === 400 && /数据分级越界/.test(gradedDeny.error.message) && /锁死/.test(gradedDeny.error.message),
        JSON.stringify(gradedDeny.error))
      const gradedAllow = await api('POST', '/api/modelgw/invoke', { token: admin, body: { model: 'iaw-scrok', messages: [{ role: 'user', content: '分级内调用' }], orgId: iawRootOrg.id, dataClass: 'secret' } })
      check('1-1：秘密数据 → 秘密级渠道放行（真实应答）', gradedAllow.ok && gradedAllow.data.content.includes('备用渠道应答'), JSON.stringify(gradedAllow.error))

      // 1-2 降级链：主(500) → 备(ok)，manual=true
      const grpPut = await api('PUT', '/api/modelgw/channel-groups', { token: admin, body: { slug: 'iaw-grp', name: 'IAW 自测渠道组', primary: 'iaw-scr', backup1: 'iaw-bkp', manual: true, stepTimeoutMs: 2000 } })
      check('1-2：渠道组登记（主/备/转人工）', grpPut.ok && grpPut.data.primary === 'iaw-scr' && grpPut.data.backup1 === 'iaw-bkp' && grpPut.data.manual === true, JSON.stringify(grpPut.error))
      const fbCall = await api('POST', '/api/modelgw/channel-groups/iaw-grp/invoke', { token: admin, body: { prompt: '降级链自测' } })
      check('1-2：主渠道 5xx → 备渠道自动接管（真实应答 + degradations 留痕）',
        fbCall.ok && fbCall.data.ok === true && fbCall.data.model === 'iaw-bkp' && Array.isArray(fbCall.data.degradations) && fbCall.data.degradations.length === 1
        && /HTTP 500/.test(fbCall.data.degradations[0].reason),
        JSON.stringify({ model: fbCall.data?.model, degradations: fbCall.data?.degradations }))
      // 1-3 遥测：主渠道失败 1 次 → 可用率下降；ttft 诚实缺列
      const telPrimary = await api('GET', '/api/modelgw/iaw-scr/telemetry?window=7d', { token: admin })
      check('1-3：主渠道遥测（failures>=1，availability<1，ttftMs=null 诚实缺列）',
        telPrimary.ok && telPrimary.data.failures >= 1 && telPrimary.data.availability !== null && telPrimary.data.availability < 1
        && telPrimary.data.ttftMs === null && /TTFT/.test(telPrimary.data.note),
        JSON.stringify({ inv: telPrimary.data?.invocations, fail: telPrimary.data?.failures, avail: telPrimary.data?.availability }))
      const telBackup = await api('GET', '/api/modelgw/iaw-bkp/telemetry?window=7d', { token: admin })
      check('1-3：备用渠道遥测（degraded 标记 + TPS 代理口径）',
        telBackup.ok && telBackup.data.invocations >= 1 && telBackup.data.degradedInvocations >= 1
        && (telBackup.data.avgTps === null || telBackup.data.avgTps > 0),
        JSON.stringify({ inv: telBackup.data?.invocations, deg: telBackup.data?.degradedInvocations }))
      const tel404 = await api('GET', '/api/modelgw/iaw-none/telemetry', { token: admin })
      check('1-3：未登记模型遥测 404', tel404.status === 404, String(tel404.status))

      // 1-4 预算：org 级日预算 1 分 + block → 熔断；摘要带预算进度
      const budgetPut = await api('PUT', '/api/modelgw/budgets', { token: admin, body: { orgId: iawRootOrg.id, dailyLimitCents: 1, monthlyLimitCents: 100, warnRatio: 0.5, action: 'block' } })
      check('1-4：预算登记（日 1 分 block / 月 100 分）', budgetPut.ok && budgetPut.data.dailyLimitCents === 1, JSON.stringify(budgetPut.error))
      const budgetBlocked = await api('POST', '/api/modelgw/invoke', { token: admin, body: { model: 'iaw-scr', messages: [{ role: 'user', content: '预算内调用' }], orgId: iawRootOrg.id } })
      check('1-4：日预算触达 → 调用前熔断（错误含「预算熔断」）',
        budgetBlocked.status === 400 && /预算熔断/.test(budgetBlocked.error.message), JSON.stringify(budgetBlocked.error))
      const summaryBudget = await api('GET', `/api/usage/summary?window=today&org=${encodeURIComponent(iawRootOrg.id)}`, { token: admin })
      check('1-4：成本摘要携带预算进度（budget.daily.limitCents=1）',
        summaryBudget.ok && summaryBudget.data.budget && summaryBudget.data.budget.daily
        && summaryBudget.data.budget.daily.limitCents === 1 && summaryBudget.data.budget.daily.breached === true,
        JSON.stringify(summaryBudget.data?.budget))
      // 放宽预算（action=warn + 大额），避免影响后续分节
      const budgetRelax = await api('PUT', '/api/modelgw/budgets', { token: admin, body: { orgId: iawRootOrg.id, dailyLimitCents: 100000, monthlyLimitCents: 1000000, warnRatio: 0.99, action: 'warn' } })
      check('1-4：预算放宽（upsert 同键覆盖）', budgetRelax.ok && budgetRelax.data.action === 'warn', JSON.stringify(budgetRelax.error))
    } finally {
      await new Promise((resolve) => gwPrimaryStub.close(resolve))
      await new Promise((resolve) => gwBackupStub.close(resolve))
    }
  }

  section('IAW 6-1：场景级授权策略（scene ABAC）与 iam.check 自检')
  {
    const iawMemberId = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('iaw_member'), { token: admin })).data.users.find((user) => user.username === 'iaw_member').id
    const polPut = await api('PUT', '/api/iam/scene-policies', { token: admin, body: {
      sceneCode: 'QB01-G-4-1',
      entries: [
        { principalType: 'role', principalId: '*', actions: ['scene.export'], effect: 'deny' },
        { principalType: 'user', principalId: iawMemberId, actions: ['*'], effect: 'allow' },
      ],
      note: 'IAW 自测策略：全员禁导出，该成员全放行',
    } })
    check('6-1：策略登记（deny 导出 + 成员 allow，v1）', polPut.ok && polPut.data.version === 1, JSON.stringify(polPut.error))
    const versionConflict = await api('PUT', '/api/iam/scene-policies', { token: admin, body: { sceneCode: 'QB01-G-4-1', expectedVersion: 99, entries: [{ principalType: 'role', principalId: '*', actions: ['x'], effect: 'allow' }] } })
    check('6-1：version 乐观锁冲突被拒 400', versionConflict.status === 400 && /版本冲突/.test(versionConflict.error.message), JSON.stringify(versionConflict.error))
    const checkAllow = await api('POST', '/api/iam/scene-authz/check', { token: iawMemberToken, body: { sceneCode: 'QB01-G-4-1', action: 'panel.read' } })
    check('6-1：iam.check allow 命中（成员 allow 条目）', checkAllow.ok && checkAllow.data.decision === 'allow', JSON.stringify(checkAllow.data))
    const checkDeny = await api('POST', '/api/iam/scene-authz/check', { token: iawMemberToken, body: { sceneCode: 'QB01-G-4-1', action: 'scene.export' } })
    check('6-1：iam.check deny 优先命中（全员禁导出）', checkDeny.ok && checkDeny.data.decision === 'deny', JSON.stringify(checkDeny.data))
    const checkDefault = await api('POST', '/api/iam/scene-authz/check', { token: iawMemberToken, body: { sceneCode: 'QB01-NOPE-9-9', action: 'panel.read' } })
    check('6-1：未配置策略场景回落 default（存量 RBAC 口径不变）', checkDefault.ok && checkDefault.data.decision === 'default', JSON.stringify(checkDefault.data))
    const polList = await api('GET', '/api/iam/scene-policies?sceneCode=QB01-G-4-1', { token: iawMemberToken })
    check('6-1：member 无 iam.org.read 策略列表被拒 403', polList.status === 403, String(polList.status))
    const machineCheck = await api('POST', '/api/iam/scene-authz/check', { token: iawMachine, body: { sceneCode: 'QB01-G-4-1', action: 'panel.read', userId: iawMemberId } })
    check('6-1：机器代查被拒 403（无 iam.user.read）', machineCheck.status === 403, String(machineCheck.status))
    const polDel = await api('DELETE', `/api/iam/scene-policies/${polPut.data.id}`, { token: admin })
    check('6-1：策略删除（回滚自测环境）', polDel.ok && polDel.data.deleted === true)
    const afterDel = await api('POST', '/api/iam/scene-authz/check', { token: iawMemberToken, body: { sceneCode: 'QB01-G-4-1', action: 'scene.export' } })
    check('6-1：删除后回落 default（fail-closed 随策略移除）', afterDel.ok && afterDel.data.decision === 'default')
  }

  section('IAW 2-1..2-4：数据要素域（数据集登记/质量分/血缘/指标字典仲裁）')
  {
    const dsPut = await api('PUT', '/api/resource/datasets', { token: admin, body: { code: 'ds_selftest_a', name: '自测数据集A', sourceSystem: '自测台账', classification: 'secret', refreshFrequency: '每日', sceneCodes: ['QB01-G-4-1', 'QB01-G-4-2'] } })
    check('2-1：数据集登记（分级/来源/刷新/双场景）', dsPut.ok && dsPut.data.classification === 'secret' && dsPut.data.sceneCodes.length === 2, JSON.stringify(dsPut.error))
    await api('PUT', '/api/resource/datasets', { token: admin, body: { code: 'ds_selftest_a', name: '自测数据集A（改）', sourceSystem: '自测台账', classification: 'internal', sceneCodes: ['QB01-G-4-1'] } })
    const dsList = await api('GET', '/api/resource/datasets?scene=QB01-G-4-1', { token: admin })
    const dsRow = (dsList.data?.datasets ?? []).find((item) => item.code === 'ds_selftest_a')
    check('2-1：按场景过滤 + upsert 幂等（sceneCount=1）', dsList.ok && Boolean(dsRow) && dsRow.sceneCount === 1 && dsRow.classification === 'internal', JSON.stringify(dsRow))
    const dsQuality = await api('PUT', '/api/resource/datasets/ds_selftest_a/quality', { token: admin, body: { completeness: 90, accuracy: 80, timeliness: 100, consistency: 70 } })
    check('2-2：质量分四维登记（等权 overall=85）', dsQuality.ok && dsQuality.data.quality.overall === 85, JSON.stringify(dsQuality.error))
    const dsBadQuality = await api('PUT', '/api/resource/datasets/ds_selftest_a/quality', { token: admin, body: { completeness: 120, accuracy: 80, timeliness: 100, consistency: 70 } })
    check('2-2：越界质量分被拒 400', dsBadQuality.status === 400 && /0-100/.test(dsBadQuality.error.message), JSON.stringify(dsBadQuality.error))
    await api('PUT', '/api/resource/datasets', { token: admin, body: { code: 'ds_selftest_b', name: '自测数据集B（派生）', sourceSystem: '自测台账', classification: 'internal' } })
    const lineagePut = await api('PUT', '/api/resource/lineage', { token: admin, body: { derived: 'ds_selftest_b', source: 'ds_selftest_a' } })
    check('2-3：血缘边登记（派生→源）', lineagePut.ok && lineagePut.data.toId === 'ds_selftest_a', JSON.stringify(lineagePut.error))
    const lineageUp = await api('GET', '/api/resource/lineage?dataset=ds_selftest_b', { token: admin })
    const lineageDown = await api('GET', '/api/resource/lineage?dataset=ds_selftest_a', { token: admin })
    check('2-3：反向追溯（B 的 upstream=A，A 的 downstream=B）',
      lineageUp.ok && lineageUp.data.upstream.some((item) => item.code === 'ds_selftest_a')
      && lineageDown.ok && lineageDown.data.downstream.some((item) => item.code === 'ds_selftest_b'),
      JSON.stringify({ up: lineageUp.data?.upstream, down: lineageDown.data?.downstream }))
    // 2-4 指标字典：口径冲突留账 + 仲裁
    const mDef1 = await api('PUT', '/api/resource/metrics/gm_selftest/definitions', { token: admin, body: { name: '毛利额（口径一）', unit: '元', description: '收入-成本（含税口径）' } })
    const mDefSame = await api('PUT', '/api/resource/metrics/gm_selftest/definitions', { token: admin, body: { name: '毛利额（口径一）', unit: '元', description: '收入-成本（含税口径）' } })
    check('2-4：口径登记（首条 active；同内容幂等）', mDef1.ok && mDef1.data.definition.status === 'active' && mDefSame.data.definition.id === mDef1.data.definition.id)
    const mDef2 = await api('PUT', '/api/resource/metrics/gm_selftest/definitions', { token: admin, body: { name: '毛利额（口径二）', unit: '元', description: '收入-成本（不含税口径）' } })
    check('2-4：口径冲突并存（新定义 superseded 待仲裁）', mDef2.ok && mDef2.data.conflict === true && mDef2.data.definition.status === 'superseded', JSON.stringify(mDef2.data))
    const mList = await api('GET', '/api/resource/metrics/gm_selftest/definitions', { token: admin })
    check('2-4：定义列表双条（按时间倒序）', mList.ok && mList.data.definitions.length === 2 && mList.data.definitions[0].id === mDef2.data.definition.id)
    const mArb = await api('POST', '/api/resource/metrics/gm_selftest/arbitrate', { token: admin, body: { definitionId: mDef2.data.definition.id } })
    check('2-4：仲裁定版（口径二 active，取代 1 条）', mArb.ok && mArb.data.active.status === 'active' && mArb.data.superseded === 1, JSON.stringify(mArb.data))
    const dsWriteDenied = await api('PUT', '/api/resource/datasets', { token: iawMachine, body: { code: 'ds_x', name: 'x', sourceSystem: 'x', classification: 'public' } })
    check('2-1：无 resource.dataset.write 被拒 403', dsWriteDenied.status === 403, String(dsWriteDenied.status))
  }

  section('IAW 3-1..3-4：事务流引擎（模板库 / TF 编排 / 步骤状态机 / SLA 进度）')
  {
    const tplPut = await api('PUT', '/api/flow/templates', { token: admin, body: {
      code: 'tpl_iaw_selftest', name: 'IAW 自测模板', sceneCode: 'QB01-G-4-1', slaMinutes: 120,
      steps: [
        { key: 's1', name: '现场复核', actorType: 'human' },
        { key: 's2', name: 'Agent 诊断', actorType: 'agent', assignee: '设备运维 Agent' },
        { key: 's3', name: '网关归档', actorType: 'gateway' },
      ],
      contextPack: { kpiRef: '一次装机合格率', window: '7d' },
    } })
    check('3-2：模板登记（3 步 + SLA + 上下文包）', tplPut.ok && tplPut.data.steps.length === 3, JSON.stringify(tplPut.error))
    const tplList = await api('GET', '/api/flow/templates?sceneCode=QB01-G-4-1', { token: iawMemberToken })
    check('3-2：按场景查模板（panel 成员 flow.read 可读）', tplList.ok && tplList.data.templates.some((item) => item.code === 'tpl_iaw_selftest'))
    const tplDenied = await api('PUT', '/api/flow/templates', { token: iawMemberToken, body: { code: 'tpl_x', name: 'x', steps: [{ key: 'a', name: 'a', actorType: 'human' }] } })
    check('3-2：member 无 flow.admin 被拒 403', tplDenied.status === 403, String(tplDenied.status))
    // 实例化：模板复制推广 + 上下文包自动注入 + SLA 折算 dueAt
    const flowCreate = await api('POST', '/api/flow/flows', { token: iawMemberToken, body: { name: 'IAW 自测事务流', templateCode: 'tpl_iaw_selftest', sceneCode: 'QB01-G-4-1', dept: 'mfg' } })
    check('3-1/3-2：TF 模板实例化（首步 running + contextPack 注入 + dueAt 折算）',
      flowCreate.ok && flowCreate.data.steps[0].status === 'running' && flowCreate.data.steps[1].status === 'pending'
      && flowCreate.data.contextPack && flowCreate.data.contextPack.kpiRef === '一次装机合格率'
      && Boolean(flowCreate.data.dueAt) && /^tf_/.test(flowCreate.data.code),
      JSON.stringify(flowCreate.error))
    const flowId = flowCreate.data.id
    const wrongOrder = await api('POST', `/api/flow/flows/${flowId}/steps/s2/transition`, { token: iawMemberToken, body: { action: 'complete' } })
    check('3-1：步骤状态机拒绝跳序（pending 不可 complete）', wrongOrder.status === 400 && /不允许/.test(wrongOrder.error.message), JSON.stringify(wrongOrder.error))
    const s1 = await api('POST', `/api/flow/flows/${flowId}/steps/s1/transition`, { token: iawMemberToken, body: { action: 'complete', note: '复核完成' } })
    check('3-1：s1 complete → s2 自动 running', s1.ok && s1.data.completed === false && s1.data.flow.currentStep === 's2', JSON.stringify(s1.data?.flow?.steps))
    const s2 = await api('POST', `/api/flow/flows/${flowId}/steps/s2/transition`, { token: iawMemberToken, body: { action: 'complete' } })
    check('3-1：s2 complete → s3 自动 running', s2.ok && s2.data.flow.currentStep === 's3')
    const s3 = await api('POST', `/api/flow/flows/${flowId}/steps/s3/transition`, { token: iawMemberToken, body: { action: 'skip', note: '网关缺位跳过' } })
    check('3-1：s3 skip → TF completed（进度 100）', s3.ok && s3.data.completed === true && s3.data.flow.status === 'completed' && s3.data.flow.progress === 100, JSON.stringify({ status: s3.data?.flow?.status, progress: s3.data?.flow?.progress }))
    const flowGet = await api('GET', `/api/flow/flows/${flowId}`, { token: iawMemberToken })
    check('3-3/3-4：TF 详情（elapsedMinutes/finishedAt/步骤时间轴齐备，甘特数据源）',
      flowGet.ok && flowGet.data.status === 'completed' && Number.isFinite(flowGet.data.elapsedMinutes)
      && flowGet.data.steps.every((step) => Boolean(step.startedAt)) && flowGet.data.steps.every((step) => Boolean(step.finishedAt) || step.status === 'running'),
      JSON.stringify({ status: flowGet.data?.status }))
    // 自由编排 + 取消
    const flowAdhoc = await api('POST', '/api/flow/flows', { token: admin, body: { name: 'IAW 自由编排流', steps: [{ key: 'a', name: '步骤A', actorType: 'human' }], sceneCode: 'QB01-G-4-2' } })
    const flowCancel = await api('POST', `/api/flow/flows/${flowAdhoc.data.id}/cancel`, { token: admin, body: { note: '自测取消' } })
    check('3-1：自由编排 + 取消（status=cancelled）', flowAdhoc.ok && flowCancel.ok && flowCancel.data.status === 'cancelled', JSON.stringify(flowCancel.error))
    const afterCancel = await api('POST', `/api/flow/flows/${flowAdhoc.data.id}/steps/a/transition`, { token: admin, body: { action: 'start' } })
    check('3-1：已结束 TF 步骤不可流转', afterCancel.status === 400 && /已结束/.test(afterCancel.error.message), JSON.stringify(afterCancel.error))
    const flowList = await api('GET', '/api/flow/flows?sceneCode=QB01-G-4-1&status=completed', { token: iawMemberToken })
    check('3-1：TF 列表按场景+状态过滤（视图字段 progress/slaBreached 随行）',
      flowList.ok && flowList.data.flows.some((item) => item.id === flowId && Number.isFinite(item.progress) && item.slaBreached === false),
      JSON.stringify(flowList.data?.flows?.length))
  }

  // ================================================================ QA-20260912 修复批次回归（A-03 / A-04 / A-08 / B-04）
  console.log('\n\x1b[36m━━ QA-20260912 修复批次回归（A-03 / A-04 / A-08 / B-04） ━━\x1b[0m')

  // A-08：建号口令强度（'123' 不可建号，与重置口径统一）
  const weakPwCreate = await api('POST', '/api/iam/users', { token: admin, body: { username: 'qaweak01', displayName: '弱口令靶子', orgId: newOrg.data.id, password: '123' } })
  check('弱口令建号被拒（QA A-08：≥8 位统一口径）', !weakPwCreate.ok && /8 位/.test(weakPwCreate.error?.message ?? ''), JSON.stringify(weakPwCreate.error ?? {}))

  // A-03：org_admin 组织隔离（服务层补栏）
  const roleListQa = (await api('GET', '/api/iam/roles', { token: admin })).data.roles
  const orgAdminRole = roleListQa.find((role) => role.code === 'org_admin')
  const qaOrgAdminCreate = await api('POST', '/api/iam/users', { token: admin, body: { username: 'qaorgadmin', displayName: 'QA部门管理员', orgId: newOrg.data.id, password: 'Ybk@2026', roleIds: [orgAdminRole.id] } })
  check('QA部门管理员建号（org_admin，归属自测事业部）', qaOrgAdminCreate.ok, JSON.stringify(qaOrgAdminCreate.error ?? {}))
  const qaOrgAdminLogin = await api('POST', '/api/auth/login', { body: { username: 'qaorgadmin', password: 'Ybk@2026' } })
  const qaOrgAdmin = qaOrgAdminLogin.data.token
  const qaBatch01 = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('batch01'), { token: admin })).data.users[0]
  const qaInsideReset = await api('POST', `/api/iam/users/${qaBatch01.id}/reset-password`, { token: qaOrgAdmin })
  check('org_admin 可管理本组织子树内账号（QA A-03 正向）', qaInsideReset.ok && typeof qaInsideReset.data.initialPassword === 'string', JSON.stringify(qaInsideReset.error ?? {}))
  const qaCascadeUser = (await api('GET', '/api/iam/users?q=' + encodeURIComponent('cascadeu01'), { token: admin })).data.users[0]
  const qaOutsideReset = await api('POST', `/api/iam/users/${qaCascadeUser.id}/reset-password`, { token: qaOrgAdmin })
  check('org_admin 跨组织接管被拒（QA A-03：服务层组织隔离）', !qaOutsideReset.ok && /组织隔离|组织子树/.test(qaOutsideReset.error?.message ?? ''), JSON.stringify(qaOutsideReset.error ?? {}))

  // A-04：非 owner 开发者不可改写他人应用
  const qaOwnerApp = await api('POST', '/api/apps', { token: admin, body: { name: 'QA回归-Owner校验', attrs: { description: 'QA 修复批次回归用应用（owner=admin）', appType: 'web', riskLevel: 'low' } } })
  check('QA回归应用创建（owner=admin）', qaOwnerApp.ok && Boolean(qaOwnerApp.data.app?.id), JSON.stringify(qaOwnerApp.error ?? {}))
  const qaForeignPatch = await api('PATCH', `/api/apps/${qaOwnerApp.data.app.id}`, { token: otherDev, body: { name: '越权改名' } })
  check('非 owner 开发者改写他人应用被拒（QA A-04）', !qaForeignPatch.ok && /owner|负责人/.test(qaForeignPatch.error?.message ?? ''), JSON.stringify(qaForeignPatch.error ?? {}))
  const qaOwnerPatch = await api('PATCH', `/api/apps/${qaOwnerApp.data.app.id}`, { token: admin, body: { name: 'QA回归-Owner校验（已更新）' } })
  check('平台管理员/owner 可正常更新（QA A-04 正向）', qaOwnerPatch.ok, JSON.stringify(qaOwnerPatch.error ?? {}))

  // B-04：audit/cost 的 days 参数真实生效
  const qaCostDays = await api('GET', '/api/audit/cost?days=14', { token: admin })
  check('audit/cost days 参数生效（QA B-04：不再被静默丢弃）', qaCostDays.ok && qaCostDays.data.days === 14 && Array.isArray(qaCostDays.data.rows), JSON.stringify(qaCostDays.data ?? qaCostDays.error).slice(0, 160))
  const qaCostBare = await api('GET', '/api/audit/cost', { token: admin })
  check('audit/cost 不带 days 保持全量口径（QA B-04 兼容）', qaCostBare.ok && qaCostBare.data.days === undefined)

  // ================================================================ 收尾终检：凭证零进平台（红线一，T-24）
  section('凭证零进平台（红线一 · T-24 全目录扫描）')
  // SIGTERM 触发 main.ts 的 flushNow（把内存中的待写集合全部原子落盘）后退出，
  // 再扫描数据目录——保证连「尚未刷盘的最新写入」也在扫描覆盖之内。
  proc.kill('SIGTERM')
  let stopped = false
  for (let i = 0; i < 30; i++) {
    await new Promise((resolve) => setTimeout(resolve, 300))
    try { await fetch(`${BASE}/api/health`); } catch { stopped = true; break }
  }
  if (!stopped) proc.kill('SIGKILL')
  const bannedSecrets = ['ghp_selftestSecret123', 'client-supersecret-oauth-xyz', ...new Set(ocMintedValues)]
  const bannedHits = []
  const walkFiles = (dir) => readdirSync(dir, { withFileTypes: true }).flatMap((entry) =>
    entry.isDirectory() ? walkFiles(join(dir, entry.name)) : [join(dir, entry.name)])
  let dataFiles = []
  try { dataFiles = walkFiles(DATA_DIR) } catch { /* 目录已被清理则跳过扫描 */ }
  for (const file of dataFiles) {
    try {
      const text = readFileSync(file).toString('latin1')
      for (const secret of bannedSecrets) {
        if (text.includes(secret)) bannedHits.push({ file: file.split(/[\\/]/).slice(-2).join('/'), secret })
      }
    } catch { /* 二进制读失败跳过 */ }
  }
  check(`T-24 数据目录 ${dataFiles.length} 个文件全部扫描`, dataFiles.length > 5, `files=${dataFiles.length}`)
  check('T-24 凭证原文零命中（API Key / OAuth client secret / 每个一次性 oct_ 值）',
    bannedHits.length === 0 && ocMintedValues.length >= 3, JSON.stringify(bannedHits))
} finally {
  // ---------------------------------------------------------------- 收尾
  console.log('\n\x1b[90m» 停止测试实例…\x1b[0m')
  proc.kill('SIGKILL')
  await new Promise((resolve) => ghStub.close(resolve))
  await new Promise((resolve) => nasGwStub.close(resolve))
  await new Promise((resolve) => ocStub.close(resolve))
  await rm(DATA_DIR, { recursive: true, force: true }).catch(() => {})
}

// ================================================================ 汇总
const failed = results.filter((item) => !item.pass)
console.log(`\n${'━'.repeat(46)}`)
console.log(`  \x1b[1m自测结果：${results.length - failed.length}/${results.length} 通过\x1b[0m`)
if (failed.length > 0) {
  console.log(`\n  \x1b[31m失败项：\x1b[0m`)
  for (const item of failed) {
    console.log(`   ✘ [${item.section}] ${item.name}`)
  }
  process.exit(1)
} else {
  console.log('  \x1b[32m全部通过 ✔\x1b[0m')
  process.exit(0)
}
