window.__ModuleLoader__.load({
	id: "deepseek-manners",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		let react = require("react");
		let react_jsx_runtime = require("react/jsx-runtime");
		//#region src/client/MannersToggle.tsx
		/**
		* 心形道谢开关组件（A4 样式：关=空心灰 / 开=实心绿 + 角标脉冲点）。
		* 样式内联（DSH 设计 token），避免 CSS module 构建依赖。
		* @module deepseek-manners/client
		*/
		/** 心形开关组件。 */
		function MannersToggle({ read, write }) {
			const [enabled, setEnabled] = (0, react.useState)(null);
			const [busy, setBusy] = (0, react.useState)(false);
			(0, react.useEffect)(() => {
				let alive = true;
				read().then((value) => {
					if (alive) setEnabled(value);
				}, () => {
					if (alive) setEnabled(true);
				});
				return () => {
					alive = false;
				};
			}, [read]);
			const toggle = async () => {
				if (busy || enabled === null) return;
				setBusy(true);
				const next = !enabled;
				try {
					await write(next);
					setEnabled(next);
				} finally {
					setBusy(false);
				}
			};
			const on = enabled === true;
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
				type: "button",
				style: {
					position: "relative",
					display: "inline-flex",
					alignItems: "center",
					justifyContent: "center",
					width: 28,
					height: 28,
					border: "none",
					borderRadius: "50%",
					background: "transparent",
					cursor: "pointer",
					color: on ? "var(--dsw-alias-state-success-primary, #0f9d58)" : "var(--dsw-alias-label-secondary, #5f5e5a)",
					opacity: busy || enabled === null ? .4 : 1,
					padding: 0
				},
				"aria-label": "道谢开关",
				"aria-pressed": on,
				title: "给小鲸鱼道谢",
				disabled: busy || enabled === null,
				onClick: toggle,
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { style: {
					position: "absolute",
					top: 2,
					right: 2,
					width: 7,
					height: 7,
					borderRadius: "50%",
					background: "var(--dsw-alias-state-success-primary, #0f9d58)",
					display: on ? "block" : "none",
					animation: on ? "manners-chase 1s infinite" : void 0
				} }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 24 24",
					style: {
						width: 16,
						height: 16,
						display: "block",
						fill: on ? "currentColor" : "none",
						stroke: on ? "none" : "currentColor",
						strokeWidth: 1.5,
						strokeLinecap: "round",
						strokeLinejoin: "round"
					},
					"aria-hidden": true,
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M12 21C12 21 4 14.6 4 9.5C4 6.5 6.4 4.5 8.8 4.5C10.3 4.5 11.5 5.3 12 6.5C12.5 5.3 13.7 4.5 15.2 4.5C17.6 4.5 20 6.5 20 9.5C20 14.6 12 21 12 21Z" })
				})]
			});
		}
		//#endregion
		//#region src/client/index.ts
		const inject = ["slots", "connection"];
		/** settings 端点路径（与 host 端一致）。 */
		const SETTINGS_PATH = "/deepseek-manners/settings";
		/** slot 条目 id。 */
		const SLOT_ID = "deepseek-manners";
		/** 脉冲动画 keyframes（一次注入，全局生效）。 */
		const KEYFRAMES_ID = "deepseek-manners-keyframes";
		const KEYFRAMES = "@keyframes manners-chase { 0%,12.4%{opacity:1} 12.5%,24.9%{opacity:.6} 25%,37.4%{opacity:.35} 37.5%,100%{opacity:.15} }";
		function ensureKeyframes() {
			if (typeof document === "undefined") return;
			if (document.getElementById(KEYFRAMES_ID) !== null) return;
			const style = document.createElement("style");
			style.id = KEYFRAMES_ID;
			style.textContent = KEYFRAMES;
			document.head.appendChild(style);
		}
		function apply(ctx) {
			ensureKeyframes();
			ctx.slots.inject("conversation.input.right", () => ctx.slots.register({
				name: "conversation.input.right",
				id: SLOT_ID,
				order: -10,
				inject: () => ({
					read: async () => {
						const resp = await fetch(SETTINGS_PATH);
						if (!resp.ok) throw new Error(`GET ${SETTINGS_PATH} -> ${resp.status}`);
						return (await resp.json()).enabled ?? true;
					},
					write: async (enabled) => {
						const resp = await fetch(SETTINGS_PATH, {
							method: "POST",
							headers: { "Content-Type": "application/json" },
							body: JSON.stringify({ enabled })
						});
						if (!resp.ok) throw new Error(`POST ${SETTINGS_PATH} -> ${resp.status}`);
					}
				})
			}, MannersToggle));
		}
		//#endregion
		exports.MannersToggle = MannersToggle;
		exports.SETTINGS_PATH = SETTINGS_PATH;
		exports.SLOT_ID = SLOT_ID;
		exports.apply = apply;
		exports.inject = inject;
		return module.exports;
	}
});
