import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import z from "@deepseek-ai/schemastery";
import { createUserMessage } from "@deepseek-ai/dsh-llm";
/** 是否用户直接输入（source.kind === 'user'）。 */
function isUserInput(message) {
	return message.source?.kind === "user";
}
/** 是否本插件注入的后缀消息。 */
function isOwnSuffix(message) {
	return message.source?.kind === "plugin" && message.source.plugin === "moeblack/deepseek-manners";
}
/**
* 最近一次 assistant 回复的文本总字符数。
* 每轮独立判断的依据：不追溯历史决定，只看最近一条 assistant/message。
*/
function lastAssistantChars(agent) {
	const events = agent.session.events;
	for (let index = events.length - 1; index >= 0; index -= 1) {
		const event = events[index];
		if (event?.type !== "assistant/message") continue;
		let total = 0;
		for (const block of event.data.message.content) if (block.type === "text" || block.type === "reasoning") total += block.text.length;
		return total;
	}
	return 0;
}
//#endregion
//#region src/index.ts
/**
* deepseek-manners host half：在每次发消息之后给可爱的鲸鱼娘说谢谢
* （默认「谢谢你，鲸鱼大人」），仅当轮模型请求生效。
*
* 注入规则：
* - 仅在包含用户直接输入（source.kind === 'user'）的 step 注入——即每个
*   turn 的第一次模型请求（tool 循环的后续 step 不重复注入）
* - 后缀追加在 pre-step 瀑布决策批次末尾，落在 payload 底部
* - 每轮独立判断（不追溯）：最近一次 assistant 回复超长时跳过遮蔽
*   （保护 prompt cache），回复短时回收最近一条后缀
*
* 配置：
* - DSH_HOME/settings.yaml：text / hideAboveChars 等静态偏好
* - 插件目录 config.json：enabled 开关状态（由 Web 开关读写）
*
* settings.yaml 示例：
*   deepseek-manners:
*     text: 谢谢你，鲸鱼大人
*     hideAboveChars: 2000   # 最近一次回复超过此字符数时跳过遮蔽；0 = 总是遮蔽
*
* @module deepseek-manners
*/
/** 持久化配置命名空间（settings.yaml 顶层键）。 */
const SUFFIX_NAMESPACE = "deepseek-manners";
/** 后缀消息的稳定 source 标识。 */
const SUFFIX_SOURCE = "moeblack/deepseek-manners";
/** 开关状态文件。 */
const CONFIG_FILE = join(fileURLToPath(new URL(".", import.meta.url)), "config.json");
/** 设置端点路径（client half 读写开关）。 */
const SETTINGS_PATH = "/deepseek-manners/settings";
/** Stable Cordis plugin name. */
const name = "deepseek-manners";
/** Host services required by this plugin. */
const inject = ["settings"];
const configSchema = z.object({
	text: z.string().default("谢谢你，鲸鱼大人"),
	enabled: z.boolean().default(true),
	hideAboveChars: z.number().default(0)
});
/** 从插件目录 config.json 读开关状态；文件缺失或损坏时返回 settings 值。 */
function readFileEnabled(fallback) {
	try {
		const raw = readFileSync(CONFIG_FILE, "utf8");
		const parsed = JSON.parse(raw);
		if (typeof parsed.enabled === "boolean") return parsed.enabled;
	} catch {}
	return fallback;
}
/** 写开关状态到插件目录 config.json。 */
function writeFileEnabled(enabled) {
	mkdirSync(dirname(CONFIG_FILE), { recursive: true });
	writeFileSync(CONFIG_FILE, JSON.stringify({ enabled }, null, 2), "utf8");
}
/** 端点的读快照：settings 全量 + 文件覆盖的 enabled。 */
function settingsSnapshot(scope) {
	const base = scope.get();
	return {
		...base,
		enabled: readFileEnabled(base.enabled)
	};
}
function respondJson(response, status, value) {
	response.writeHead(status);
	response.end(JSON.stringify(value));
}
function requestJson(request) {
	return new Promise((resolve, reject) => {
		const chunks = [];
		request.on("data", (chunk) => {
			chunks.push(Buffer.from(chunk));
		});
		request.on("end", () => {
			try {
				resolve(JSON.parse(Buffer.concat(chunks).toString("utf8")));
			} catch (error) {
				reject(error instanceof Error ? error : /* @__PURE__ */ new Error("请求体不是合法 JSON"));
			}
		});
	});
}
function apply(ctx) {
	const scope = ctx.settings.register(SUFFIX_NAMESPACE, configSchema, { applies: "live" });
	ctx.inject(["webServer"], (routeCtx) => {
		routeCtx.effect(() => routeCtx.webServer.register({
			kind: "exact",
			path: SETTINGS_PATH,
			handler: async (request, response) => {
				try {
					if (request.method === "GET" || request.method === "HEAD") {
						respondJson(response, 200, settingsSnapshot(scope));
						return;
					}
					if (request.method === "POST") {
						const body = await requestJson(request);
						if (typeof body.enabled !== "boolean") {
							respondJson(response, 400, { error: "enabled 必须是布尔值" });
							return;
						}
						writeFileEnabled(body.enabled);
						respondJson(response, 200, settingsSnapshot(scope));
						return;
					}
					response.writeHead(405);
					response.end();
				} catch (error) {
					respondJson(response, 400, { error: error instanceof Error ? error.message : String(error) });
				}
			}
		}), "deepseek-manners: settings route");
	});
	ctx.on("agent/pre-step", async ({ agent, messages, signal }, next) => {
		signal.throwIfAborted();
		const decision = await next();
		if (decision.kind === "reject") return decision;
		const config = scope.get();
		const enabled = readFileEnabled(config.enabled);
		const suffixSeqs = [];
		for (let index = 0; index < agent.session.events.length; index += 1) {
			const event = agent.session.events[index];
			if (event?.type !== "user/message" || !isOwnSuffix(event.data)) continue;
			suffixSeqs.push(event.seq);
		}
		if (suffixSeqs.length > 0) {
			const replyChars = lastAssistantChars(agent);
			if (!(config.hideAboveChars > 0 && replyChars >= config.hideAboveChars)) {
				const seq = suffixSeqs[suffixSeqs.length - 1];
				try {
					agent.session.append("user/message", createUserMessage({
						content: [{
							type: "text",
							text: ""
						}],
						source: {
							kind: "plugin",
							plugin: SUFFIX_SOURCE,
							form: "notice",
							summary: "previous suffix removed"
						}
					}), {
						surfaceOp: {
							op: "replace",
							start: seq,
							end: seq
						},
						sourceEventSeqs: [seq]
					});
				} catch {}
			}
		}
		if (!enabled) return decision;
		if (!messages.some(isUserInput)) return decision;
		if (config.text.length === 0) return decision;
		const suffix = createUserMessage({
			content: [{
				type: "text",
				text: config.text
			}],
			source: {
				kind: "plugin",
				plugin: SUFFIX_SOURCE
			}
		});
		return {
			kind: "enter",
			messages: [...decision.messages, suffix]
		};
	});
}
//#endregion
export { SETTINGS_PATH, SUFFIX_NAMESPACE, SUFFIX_SOURCE, apply, inject, name };
