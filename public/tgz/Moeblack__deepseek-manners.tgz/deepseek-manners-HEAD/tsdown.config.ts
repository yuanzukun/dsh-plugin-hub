/**
 * deepseek-manners 构建：Node half（host 注入逻辑）+ client half（浏览器开关）。
 * 独立包，配置零 import（避免仓库外解析问题）——参考 plugin-registry console 插件。
 */
export default [
  {
    entry: { index: "src/index.ts" },
    outDir: "dist",
    format: "esm",
    platform: "node",
    target: "es2024",
    fixedExtension: false,
    dts: false,
    clean: true,
    external: [/@deepseek-ai\//],
  },
  {
    name: "deepseek-manners/client",
    entry: { client: "src/client/index.ts" },
    format: "cjs",
    platform: "browser",
    target: "es2022",
    outDir: "dist",
    dts: false,
    clean: false,
    external: [/^react(\/|$)/, /@deepseek-ai\/dsh-client-/],
    outputOptions: {
      entryFileNames: "client.js",
      banner: 'window.__ModuleLoader__.load({ id: "deepseek-manners", factory: (require) => {',
      intro: 'var module = { exports: {} }; var exports = module.exports;',
      footer: 'return module.exports; } });',
    },
  },
]
