/**
 * deepseek-manners host half：在每次发消息之后给可爱的鲸鱼娘说谢谢
 * （默认「谢谢你，鲸鱼大人」），仅当轮模型请求生效。
 *
 * 注入规则：
 * - 仅在包含用户直接输入（source.kind === 'user'）的 step 注入——即每个
 *   turn 的第一次模型请求（tool 循环的后续 step 不重复注入）
 * - 后缀追加在 pre-step 瀑布决策批次末尾，落在 payload 底部
 * - 每轮独立判断（不追溯）：最近一次 assistant 回复超长时跳过遮蔽
 *   （保护 prompt cache），回复短时回收最近一条后缀
 *
 * 配置：
 * - DSH_HOME/settings.yaml：text / hideAboveChars 等静态偏好
 * - 插件目录 config.json：enabled 开关状态（由 Web 开关读写）
 *
 * settings.yaml 示例：
 *   deepseek-manners:
 *     text: 谢谢你，鲸鱼大人
 *     hideAboveChars: 2000   # 最近一次回复超过此字符数时跳过遮蔽；0 = 总是遮蔽
 *
 * @module deepseek-manners
 */

import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import type { SettingsNamespace, SettingsScope } from '@deepseek-ai/dsh-settings'
import { isOwnSuffix, isUserInput, lastAssistantChars } from './impl.ts'

/** 持久化配置命名空间（settings.yaml 顶层键）。 */
export const SUFFIX_NAMESPACE = 'deepseek-manners' as SettingsNamespace

/** 后缀消息的稳定 source 标识。 */
export const SUFFIX_SOURCE = 'moeblack/deepseek-manners'

/** 插件目录（构建产物 index.mjs 所在位置）。 */
const PLUGIN_ROOT = fileURLToPath(new URL('.', import.meta.url))

/** 开关状态文件。 */
const CONFIG_FILE = join(PLUGIN_ROOT, 'config.json')

/** 设置端点路径（client half 读写开关）。 */
export const SETTINGS_PATH = '/deepseek-manners/settings'

/** 请求类型（端点用）。 */
interface HttpRequestLike {
  method: string | undefined
  url: string | undefined
  on(event: string, listener: (...args: unknown[]) => void): unknown
}

/** 响应类型（端点用）。 */
interface HttpResponseLike {
  writeHead(status: number): unknown
  end(value?: unknown): unknown
}

/** host webserver 服务（tank-context 同款本地声明）。 */
interface WebServerLike {
  register(route: {
    kind: 'exact'
    path: string
    handler: (request: HttpRequestLike, response: HttpResponseLike) => void | Promise<void>
  }): () => void
}

declare module '@deepseek-ai/cordis' {
  interface Context {
    webServer: WebServerLike
  }
}

/** Stable Cordis plugin name. */
export const name = 'deepseek-manners'

/** Host services required by this plugin. */
export const inject = ['settings']

interface SuffixConfig {
  /** 后缀文本；为空则不注入。 */
  text: string
  /** 总开关（文件层覆盖 settings 层）。 */
  enabled: boolean
  /** 最近一次回复超过此字符数时跳过遮蔽（保护 cache）；0 = 总是遮蔽。 */
  hideAboveChars: number
}

const configSchema = z.object({
  text: z.string().default('谢谢你，鲸鱼大人'),
  enabled: z.boolean().default(true),
  hideAboveChars: z.number().default(0),
}) as z<SuffixConfig>

/** 从插件目录 config.json 读开关状态；文件缺失或损坏时返回 settings 值。 */
function readFileEnabled(fallback: boolean): boolean {
  try {
    const raw = readFileSync(CONFIG_FILE, 'utf8')
    const parsed = JSON.parse(raw) as { enabled?: unknown }
    if (typeof parsed.enabled === 'boolean') return parsed.enabled
  } catch {
    // 缺失/损坏：用 fallback
  }
  return fallback
}

/** 写开关状态到插件目录 config.json。 */
function writeFileEnabled(enabled: boolean): void {
  mkdirSync(dirname(CONFIG_FILE), { recursive: true })
  writeFileSync(CONFIG_FILE, JSON.stringify({ enabled }, null, 2), 'utf8')
}

/** 端点的读快照：settings 全量 + 文件覆盖的 enabled。 */
function settingsSnapshot(scope: SettingsScope<SuffixConfig>): unknown {
  const base = scope.get()
  return {
    ...base,
    enabled: readFileEnabled(base.enabled),
  }
}

function respondJson(response: HttpResponseLike, status: number, value: unknown): void {
  response.writeHead(status)
  response.end(JSON.stringify(value))
}

function requestJson(request: HttpRequestLike): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    request.on('data', (chunk: unknown) => { chunks.push(Buffer.from(chunk as string)) })
    request.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')))
      } catch (error) {
        reject(error instanceof Error ? error : new Error('请求体不是合法 JSON'))
      }
    })
  })
}

export function apply(ctx: Context): void {
  const scope: SettingsScope<SuffixConfig> = ctx.settings.register(
    SUFFIX_NAMESPACE,
    configSchema,
    { applies: 'live' },
  )

  // 设置端点：GET 读快照、POST 写 enabled。
  ctx.inject(['webServer'], (routeCtx) => {
    routeCtx.effect(() => routeCtx.webServer.register({
      kind: 'exact',
      path: SETTINGS_PATH,
      handler: async (request: HttpRequestLike, response: HttpResponseLike) => {
        try {
          if (request.method === 'GET' || request.method === 'HEAD') {
            respondJson(response, 200, settingsSnapshot(scope))
            return
          }
          if (request.method === 'POST') {
            const body = (await requestJson(request)) as { enabled?: unknown }
            if (typeof body.enabled !== 'boolean') {
              respondJson(response, 400, { error: 'enabled 必须是布尔值' })
              return
            }
            writeFileEnabled(body.enabled)
            respondJson(response, 200, settingsSnapshot(scope))
            return
          }
          response.writeHead(405)
          response.end()
        } catch (error: unknown) {
          const message = error instanceof Error ? error.message : String(error)
          respondJson(response, 400, { error: message })
        }
      },
    }), 'deepseek-manners: settings route')
  })

  ctx.on('agent/pre-step', async ({ agent, messages, signal }, next) => {
    signal.throwIfAborted()
    const decision = await next()
    if (decision.kind === 'reject') return decision

    const config = scope.get()
    const enabled = readFileEnabled(config.enabled)

    // 回收残留的旧后缀与开关无关：关闭开关只停止「注入」，历史里已
    // 存在的后缀仍按规则回收（每轮独立判断，只看最近一次回复长度）。
    const suffixSeqs: number[] = []
    for (let index = 0; index < agent.session.events.length; index += 1) {
      const event = agent.session.events[index]
      if (event?.type !== 'user/message' || !isOwnSuffix(event.data)) continue
      suffixSeqs.push(event.seq)
    }
    if (suffixSeqs.length > 0) {
      // 每轮独立判断，不追溯历史决定：只看最近一次 assistant 回复长度。
      // 回复超长时跳过遮蔽：surface replace 会改动历史消息序列，长回复
      // 场景下破坏 prompt cache 的代价大于保留旧后缀（保留=本轮不回收）。
      // 回复短时照常回收。下一轮重新判断，互不影响。
      // 关键：只处理最近一条后缀——被跳过的（超长保留）永不回收，
      // 因为后续轮次的「最近一条」已是新注入的后缀，不会追溯旧项。
      const replyChars = lastAssistantChars(agent)
      const skipHide = config.hideAboveChars > 0 && replyChars >= config.hideAboveChars
      if (!skipHide) {
        const seq = suffixSeqs[suffixSeqs.length - 1]!
        try {
          agent.session.append('user/message', createUserMessage({
            content: [{ type: 'text', text: '' }],
            source: { kind: 'plugin', plugin: SUFFIX_SOURCE, form: 'notice', summary: 'previous suffix removed' },
          }), {
            surfaceOp: { op: 'replace', start: seq, end: seq },
            sourceEventSeqs: [seq],
          })
        } catch {
          // 已被遮蔽或结构异常时跳过，不阻断本轮
        }
      }
    }

    // 仅当开关开启且本轮包含用户直接输入（turn 的第一个 step）时注入新后缀
    if (!enabled) return decision
    if (!messages.some(isUserInput)) return decision
    if (config.text.length === 0) return decision

    const suffix = createUserMessage({
      content: [{ type: 'text', text: config.text }],
      source: { kind: 'plugin', plugin: SUFFIX_SOURCE },
    })
    return { kind: 'enter', messages: [...decision.messages, suffix] }
  })
}
