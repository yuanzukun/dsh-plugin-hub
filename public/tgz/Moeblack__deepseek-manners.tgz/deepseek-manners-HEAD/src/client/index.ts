/**
 * deepseek-manners client half：composer trailing 区的心形道谢开关（A4 样式）。
 * 走标准 slot `conversation.input.right`（list）；读写走 host 自定义
 * 端点（GET/POST /deepseek-manners/settings），绕开 settings 白名单。
 * @module deepseek-manners/client
 */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import { MannersToggle, type MannersToggleInjected } from './MannersToggle.tsx'

export { MannersToggle }
export type { MannersToggleInjected }

export const inject = ['slots', 'connection']

/** settings 端点路径（与 host 端一致）。 */
export const SETTINGS_PATH = '/deepseek-manners/settings'

/** slot 条目 id。 */
export const SLOT_ID = 'deepseek-manners'

/** 脉冲动画 keyframes（一次注入，全局生效）。 */
const KEYFRAMES_ID = 'deepseek-manners-keyframes'
const KEYFRAMES = '@keyframes manners-chase { 0%,12.4%{opacity:1} 12.5%,24.9%{opacity:.6} 25%,37.4%{opacity:.35} 37.5%,100%{opacity:.15} }'

function ensureKeyframes(): void {
  if (typeof document === 'undefined') return
  if (document.getElementById(KEYFRAMES_ID) !== null) return
  const style = document.createElement('style')
  style.id = KEYFRAMES_ID
  style.textContent = KEYFRAMES
  document.head.appendChild(style)
}

export function apply(ctx: ClientContext & { connection: ConnectionHandle }): void {
  ensureKeyframes()
  ctx.slots.inject('conversation.input.right', () => ctx.slots.register({
    name: 'conversation.input.right',
    id: SLOT_ID,
    order: -10,
    inject: (): MannersToggleInjected => ({
      read: async (): Promise<boolean> => {
        const resp = await fetch(SETTINGS_PATH)
        if (!resp.ok) throw new Error(`GET ${SETTINGS_PATH} -> ${resp.status}`)
        const data = (await resp.json()) as { enabled?: boolean }
        return data.enabled ?? true
      },
      write: async (enabled: boolean): Promise<void> => {
        const resp = await fetch(SETTINGS_PATH, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ enabled }),
        })
        if (!resp.ok) throw new Error(`POST ${SETTINGS_PATH} -> ${resp.status}`)
      },
    }),
  }, MannersToggle))
}
