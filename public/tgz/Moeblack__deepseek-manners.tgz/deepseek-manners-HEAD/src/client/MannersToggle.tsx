/**
 * 心形道谢开关组件（A4 样式：关=空心灰 / 开=实心绿 + 角标脉冲点）。
 * 样式内联（DSH 设计 token），避免 CSS module 构建依赖。
 * @module deepseek-manners/client
 */

import { useEffect, useState, type CSSProperties } from 'react'

/** 开关注入面。 */
export interface MannersToggleInjected {
  /** 当前是否启用（settings 解析；默认 true）。 */
  read: () => Promise<boolean>
  /** 写入新 enabled（settings.update 合并 patch）。 */
  write: (enabled: boolean) => Promise<void>
}

/** 心形开关组件。 */
export function MannersToggle({ read, write }: MannersToggleInjected) {
  const [enabled, setEnabled] = useState<boolean | null>(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    let alive = true
    read().then(
      value => { if (alive) setEnabled(value) },
      () => { if (alive) setEnabled(true) },
    )
    return () => { alive = false }
  }, [read])

  const toggle = async (): Promise<void> => {
    if (busy || enabled === null) return
    setBusy(true)
    const next = !enabled
    try {
      await write(next)
      setEnabled(next)
    } finally {
      setBusy(false)
    }
  }

  const on = enabled === true

  const rootStyle: CSSProperties = {
    position: 'relative',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: 28,
    height: 28,
    border: 'none',
    borderRadius: '50%',
    background: 'transparent',
    cursor: 'pointer',
    color: on ? 'var(--dsw-alias-state-success-primary, #0f9d58)' : 'var(--dsw-alias-label-secondary, #5f5e5a)',
    opacity: busy || enabled === null ? 0.4 : 1,
    padding: 0,
  }

  const pulseStyle: CSSProperties = {
    position: 'absolute',
    top: 2,
    right: 2,
    width: 7,
    height: 7,
    borderRadius: '50%',
    background: 'var(--dsw-alias-state-success-primary, #0f9d58)',
    display: on ? 'block' : 'none',
    animation: on ? 'manners-chase 1s infinite' : undefined,
  }

  return (
    <button
      type="button"
      style={rootStyle}
      aria-label="道谢开关"
      aria-pressed={on}
      title="给小鲸鱼道谢"
      disabled={busy || enabled === null}
      onClick={toggle}
    >
      <span style={pulseStyle} />
      <svg viewBox="0 0 24 24" style={{ width: 16, height: 16, display: 'block', fill: on ? 'currentColor' : 'none', stroke: on ? 'none' : 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' }} aria-hidden>
        <path d="M12 21C12 21 4 14.6 4 9.5C4 6.5 6.4 4.5 8.8 4.5C10.3 4.5 11.5 5.3 12 6.5C12.5 5.3 13.7 4.5 15.2 4.5C17.6 4.5 20 6.5 20 9.5C20 14.6 12 21 12 21Z" />
      </svg>
    </button>
  )
}
