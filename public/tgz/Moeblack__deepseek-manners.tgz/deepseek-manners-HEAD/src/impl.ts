/**
 * deepseek-manners 纯逻辑：无框架依赖，可直接单测。
 * @module deepseek-manners/impl
 */

import type { Agent } from '@deepseek-ai/dsh-agent'
import type { UserMessage } from '@deepseek-ai/dsh-session'

/** 后缀消息的稳定 source 标识。 */
export const SUFFIX_SOURCE = 'moeblack/deepseek-manners'

/** 是否用户直接输入（source.kind === 'user'）。 */
export function isUserInput(message: UserMessage): boolean {
  return message.source?.kind === 'user'
}

/** 是否本插件注入的后缀消息。 */
export function isOwnSuffix(message: UserMessage): boolean {
  return message.source?.kind === 'plugin' && message.source.plugin === SUFFIX_SOURCE
}

/**
 * 最近一次 assistant 回复的文本总字符数。
 * 每轮独立判断的依据：不追溯历史决定，只看最近一条 assistant/message。
 */
export function lastAssistantChars(agent: Agent): number {
  const events = agent.session.events
  for (let index = events.length - 1; index >= 0; index -= 1) {
    const event = events[index]
    if (event?.type !== 'assistant/message') continue
    let total = 0
    for (const block of event.data.message.content) {
      if (block.type === 'text' || block.type === 'reasoning') {
        total += block.text.length
      }
    }
    return total
  }
  return 0
}
