import { describe, expect, it } from 'vitest'
import { isOwnSuffix, isUserInput, lastAssistantChars } from '../src/impl.ts'

describe('deepseek-manners impl', () => {
  it('recognizes direct user input by source.kind', () => {
    expect(isUserInput({ source: { kind: 'user' } } as never)).toBe(true)
    expect(isUserInput({ source: { kind: 'plugin', plugin: 'x' } } as never)).toBe(false)
    expect(isUserInput({} as never)).toBe(false)
  })

  it('recognizes own suffix by plugin id', () => {
    expect(isOwnSuffix({ source: { kind: 'plugin', plugin: 'moeblack/deepseek-manners' } } as never)).toBe(true)
    expect(isOwnSuffix({ source: { kind: 'plugin', plugin: 'moeblack/user-suffix' } } as never)).toBe(false)
    expect(isOwnSuffix({ source: { kind: 'user' } } as never)).toBe(false)
  })

  it('counts only the most recent assistant reply', () => {
    const agent = {
      session: {
        events: [
          { seq: 1, type: 'assistant/message', data: { message: { content: [{ type: 'text', text: 'short' }] } } },
          { seq: 2, type: 'user/message', data: {} },
          { seq: 3, type: 'assistant/message', data: { message: { content: [{ type: 'text', text: 'long'.repeat(50) }, { type: 'reasoning', text: 'think' }] } } },
        ],
      },
    } as never
    expect(lastAssistantChars(agent)).toBe(50 * 4 + 5)
  })

  it('returns 0 when no assistant reply exists', () => {
    const agent = { session: { events: [{ seq: 1, type: 'user/message', data: {} }] } } as never
    expect(lastAssistantChars(agent)).toBe(0)
  })
})
