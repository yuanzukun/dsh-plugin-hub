import { describe, expect, it } from 'vitest'
import * as plugin from '../src/index.ts'

describe('deepseek-manners registration', () => {
  it('exposes stable plugin identity', () => {
    expect(plugin.name).toBe('deepseek-manners')
  })

  it('declares settings inject', () => {
    expect(plugin.inject).toContain('settings')
  })
})
