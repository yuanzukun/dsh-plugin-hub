import { copyFile, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { run, withDshEnvironment } from "./dsh-env.mjs";

await withDshEnvironment(async ({ dshRoot, pluginRoot }) => {
  const dist = join(pluginRoot, "dist");
  await rm(dist, { recursive: true, force: true });
  await run(join(dshRoot, "node_modules/.bin/tsc"), ["-b", "tsconfig.json"]);
  await run(join(dshRoot, "node_modules/.bin/tsdown"), ["--config", "tsdown.config.ts"]);
  const index = join(dist, "index.js");
  const source = await readFile(index, "utf8");
  await writeFile(
    index,
    source.replace(
      `createRequire(import.meta.url)("../package.json")`,
      `createRequire(import.meta.url)("./package.json")`,
    ),
  );
  if (/from ["'][^"']*\.ts["']/.test(source)) {
    throw new Error("build: dist/index.js still contains .ts imports");
  }
  await copyFile(index, join(pluginRoot, "index.mjs"));
  if (await readFile(join(dist, "client.js"), "utf8").then(() => true).catch(() => false)) {
    await copyFile(join(dist, "client.js"), join(pluginRoot, "client.js"));
  }
  await rm(dist, { recursive: true, force: true });
});
