import { run, withDshEnvironment } from "./dsh-env.mjs";
import { join } from "node:path";

await withDshEnvironment(async ({ dshRoot, pluginRoot }) => {
  await run(join(dshRoot, "node_modules/vitest/vitest.mjs"), ["run"], pluginRoot);
});
