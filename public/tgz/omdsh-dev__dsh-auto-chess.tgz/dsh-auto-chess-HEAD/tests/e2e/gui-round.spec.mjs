// E2E: the auto-chess tab in the dsh web GUI. Load the test instance, open a
// session, switch to the 自走棋 tab, start an AI-vs-AI game, and assert that
// a full round completes (both AIs decide, the battle plays out, the round
// advances) with no page errors.
import { createRequire } from 'node:module'

const require = createRequire('/Users/yejiming/.dsh/source/current/apps/cli/package.json')
const { chromium } = require('/Users/yejiming/.dsh/source/current/node_modules/.pnpm/playwright-core@1.61.1/node_modules/playwright-core')

const BASE = 'http://127.0.0.1:3095'

const browser = await chromium.launch({
  executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  headless: true,
  args: ['--no-sandbox'],
})
const page = await browser.newPage()
const consoleErrors = []
page.on('pageerror', (err) => consoleErrors.push(String(err)))
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const step = (label) => console.log(`\n== ${label}`)

async function waitFor(fn, timeoutMs, label) {
  const start = Date.now()
  while (Date.now() - start < timeoutMs) {
    const value = await fn()
    if (value) return value
    await sleep(500)
  }
  throw new Error(`timeout waiting for ${label}`)
}

async function clickText(text, selector = 'button, [role="button"], [role="tab"]') {
  return page.evaluate(({ t, s }) => {
    const el = [...document.querySelectorAll(s)].find(e => e.textContent?.trim() === t)
    if (!el) return false
    el.click()
    return true
  }, { t: text, s: selector })
}

step('load the GUI and open a session')
await page.goto(BASE, { waitUntil: 'domcontentloaded', timeout: 30000 })
await page.waitForTimeout(6000)
const clicked = await page.evaluate(() => {
  // Prefer a session in the current workspace; fall back to any session row.
  const candidates = ['为Harness开发自走棋AI对战插件', '安装dsh-gomoku插件到项目']
  for (const name of candidates) {
    const el = [...document.querySelectorAll('*')].find(e => e.textContent?.trim() === name)
    if (!el) continue
    const clickable = el.closest('[role="button"], button, a, [class*="session"], [data-session]')
    if (clickable) {
      clickable.click()
      return true
    }
    el.click()
    return true
  }
  return false
})
if (!clicked) throw new Error('no session found')

step('wait for the auto-chess tab in the conversation view')
await waitFor(async () => (await page.evaluate(() => [...document.querySelectorAll('[role="tab"]')].map(t => t.textContent))).includes('自走棋'), 20000, '自走棋 tab')

step('open the auto-chess tab')
await page.evaluate(() => {
  const tab = [...document.querySelectorAll('[role="tab"]')].find(b => b.textContent?.includes('自走棋'))
  tab?.click()
})
await waitFor(async () => (await page.evaluate(() => [...document.querySelectorAll('button')].some(b => b.textContent?.includes('双 AI 对战')))), 15000, 'mode buttons')

step('start an AI-vs-AI game')
await page.evaluate(() => {
  const btn = [...document.querySelectorAll('button')].find(b => b.textContent?.includes('双 AI 对战'))
  btn?.click()
})

step('wait for the first AI prep decision to land (status leaves "AI 思考中")')
await waitFor(async () => (await page.evaluate(() => {
  const text = document.body.textContent ?? ''
  return text.includes('蓝方准备中') || text.includes('红方准备中') || text.includes('战斗进行中') || text.includes('结算中')
})), 120000, 'AI prep decision')

step('wait for the battle to complete and the round to advance')
await waitFor(async () => (await page.evaluate(() => {
  const text = document.body.textContent ?? ''
  return text.includes('第 2 回合') || text.includes('第2 回合') || text.includes('蓝方胜利') || text.includes('红方胜利')
})), 180000, 'round 2 (or a winner)')

step('capture the reasoning log presence')
const log = await page.evaluate(() => {
  const text = document.body.textContent ?? ''
  return {
    hasReasoningTitle: text.includes('AI 思考记录'),
    hasThinkingEntries: (text.match(/第 \d+ 回合 ·/g) ?? []).length,
  }
})
console.log('reasoning log:', JSON.stringify(log))

const errors = consoleErrors.filter(e => !e.includes('ResizeObserver') && !e.includes('favicon'))
console.log(`\npage errors: ${errors.length}`)
for (const error of errors.slice(0, 10)) console.log('  -', error)
await browser.close()
if (errors.length > 0) process.exit(1)
console.log('\nE2E PASS')
