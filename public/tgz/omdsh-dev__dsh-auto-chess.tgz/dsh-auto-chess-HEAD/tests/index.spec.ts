import { describe, expect, it } from 'vitest'
import {
  BENCH_CAP, COLS, MAX_ACTIONS, ROWS, START_HP,
  applyAction, cloneGameState, expNeeded, freshGame, incomePreview,
  settleRound, simulateBattle, traitCounts,
  type GameState,
} from '../src/game/engine.ts'
import { buildActionUserMessage, enemyScoutText, traitLine } from '../src/game/prompt.ts'
import {
  AUTO_CHESS_PATH, DEFAULT_SYSTEM_PROMPT, parseActionReply, validateActionRequest,
  isRetryableActionFailure,
} from '../src/index.ts'

/* ------------------------------------------------------------------ *
 * Engine: economy and leveling
 * ------------------------------------------------------------------ */

describe('freshGame', () => {
  it('starts both sides at full HP with 6 gold, level 1 and a rolled shop', () => {
    const state = freshGame()
    expect(state.round).toBe(1)
    expect(state.sides[0]!.hp).toBe(START_HP)
    expect(state.sides[1]!.hp).toBe(START_HP)
    expect(state.sides[0]!.gold).toBe(6)
    expect(state.sides[1]!.gold).toBe(6)
    expect(state.sides[0]!.level).toBe(1)
    expect(state.sides[0]!.shop).toHaveLength(5)
    expect(state.sides[1]!.shop).toHaveLength(5)
    expect(state.over).toBe(false)
  })

  it('rolls shops deterministically for a fixed seed', () => {
    const a = freshGame(42)
    const b = freshGame(42)
    expect(a.sides[0]!.shop.map(entry => entry.name)).toEqual(b.sides[0]!.shop.map(entry => entry.name))
    expect(a.sides[1]!.shop.map(entry => entry.name)).toEqual(b.sides[1]!.shop.map(entry => entry.name))
  })

  it('level-1 shops only contain 1-cost units', () => {
    const state = freshGame(7)
    for (const entry of [...state.sides[0]!.shop, ...state.sides[1]!.shop]) {
      expect(entry.cost).toBe(1)
    }
  })
})

describe('expNeeded', () => {
  it('matches the prompt contract (4→5 needs 6)', () => {
    expect(expNeeded(4)).toBe(6)
    expect(expNeeded(1)).toBe(3)
    expect(expNeeded(7)).toBe(9)
  })
})

describe('upgrade action', () => {
  it('spends 4 gold for 4 exp and levels up when the threshold is met', () => {
    const state = freshGame()
    const side = state.sides[0]!
    side.gold = 20
    expect(applyAction(state, 1, { action: 'upgrade' })).toBeUndefined()
    expect(side.gold).toBe(16)
    // 4 exp ≥ 3 (level 1→2 needs 3): one level-up, 1 exp left.
    expect(side.level).toBe(2)
    expect(side.exp).toBe(1)
  })

  it('rejects when gold is short', () => {
    const state = freshGame()
    state.sides[0]!.gold = 3
    expect(applyAction(state, 1, { action: 'upgrade' })).toContain('金币不足')
  })
})

describe('refresh action', () => {
  it('spends 2 gold and rerolls the shop', () => {
    const state = freshGame(11)
    const side = state.sides[0]!
    side.gold = 10
    const before = side.shop.map(entry => entry.defId)
    expect(applyAction(state, 1, { action: 'refresh' })).toBeUndefined()
    expect(side.gold).toBe(8)
    expect(side.shop.map(entry => entry.defId)).not.toEqual(before)
  })

  it('rejects when gold is short', () => {
    const state = freshGame()
    state.sides[0]!.gold = 1
    expect(applyAction(state, 1, { action: 'refresh' })).toContain('金币不足')
  })
})

describe('incomePreview', () => {
  it('computes base + capped interest + streak bonus + win bonus', () => {
    const state = freshGame()
    const side = state.sides[0]!
    side.gold = 32
    side.winStreak = 5
    side.lastResult = 'win'
    const preview = incomePreview(side)
    expect(preview.interest).toBe(3) // floor(32/10) = 3
    expect(preview.streak).toBe(2) // 5 → tier 4
    expect(preview.win).toBe(1)
    expect(preview.total).toBe(5 + 3 + 2 + 1)
    side.gold = 999
    expect(incomePreview(side).interest).toBe(5) // capped
  })
})

/* ------------------------------------------------------------------ *
 * Engine: buying, selling, moving, star merging
 * ------------------------------------------------------------------ */

describe('buy action', () => {
  it('spends gold, adds the unit to the bench and assigns a new id', () => {
    const state = freshGame(3)
    const side = state.sides[0]!
    const entry = side.shop[0]!
    side.gold = 10
    const benchBefore = side.bench.length
    const error = applyAction(state, 1, { action: 'buy', name: entry.name })
    expect(error).toBeUndefined()
    expect(side.gold).toBe(10 - entry.cost)
    expect(side.bench).toHaveLength(benchBefore + 1)
    const unit = side.bench[side.bench.length - 1]!
    expect(unit.name).toBe(entry.name)
    expect(unit.star).toBe(1)
    expect(unit.id).toBeGreaterThan(0)
    expect(state.nextUnitId).toBeGreaterThan(unit.id)
  })

  it('rejects unknown names and short gold', () => {
    const state = freshGame()
    expect(applyAction(state, 1, { action: 'buy', name: '不存在的棋子' })).toContain('商店中没有')
    const side = state.sides[0]!
    side.gold = 0
    expect(applyAction(state, 1, { action: 'buy', name: side.shop[0]!.name })).toContain('金币不足')
  })

  it('rejects when the bench is full', () => {
    const state = freshGame(3)
    const side = state.sides[0]!
    side.gold = 100
    side.shop = Array.from({ length: 9 }, (_, i) => ({
      defId: i + 1, name: `unit${i + 1}`, cost: 1, race: 'frost' as const, class: 'mage' as const,
    }))
    for (let i = 0; i < BENCH_CAP; i += 1) {
      expect(applyAction(state, 1, { action: 'buy', name: `unit${i + 1}` })).toBeUndefined()
    }
    expect(side.bench).toHaveLength(BENCH_CAP)
    const error = applyAction(state, 1, { action: 'buy', name: 'unit1' })
    expect(error).toContain('备战区已满')
  })
})

describe('star merging', () => {
  it('merges three identical 1-star units into one 2-star with ~1.8× stats', () => {
    const state = freshGame(3)
    const side = state.sides[0]!
    side.gold = 100
    const name = side.shop[0]!.name
    expect(applyAction(state, 1, { action: 'buy', name })).toBeUndefined()
    expect(applyAction(state, 1, { action: 'buy', name })).toBeUndefined()
    const unit = side.bench[side.bench.length - 1]!
    const baseHp = unit.hp
    expect(applyAction(state, 1, { action: 'buy', name })).toBeUndefined()
    const merged = side.bench.find(candidate => candidate.name === name && candidate.star === 2)
    expect(merged).toBeDefined()
    expect(side.bench.filter(candidate => candidate.name === name)).toHaveLength(1)
    expect(merged!.hp).toBe(Math.round(baseHp * 1.8))
    expect(merged!.atk).toBe(Math.round(unit.atk * 1.8))
  })

  it('merges across bench and board', () => {
    const state = freshGame(3)
    const side = state.sides[0]!
    side.gold = 100
    side.level = 3
    const name = side.shop[0]!.name
    applyAction(state, 1, { action: 'buy', name })
    applyAction(state, 1, { action: 'buy', name })
    const first = side.bench[0]!
    applyAction(state, 1, { action: 'move', chess_id: first.id, pos: [0, 0] })
    applyAction(state, 1, { action: 'move', chess_id: side.bench[0]!.id, pos: [0, 1] })
    expect(side.board.filter(unit => unit?.name === name)).toHaveLength(2)
    expect(applyAction(state, 1, { action: 'buy', name })).toBeUndefined()
    // All three copies consumed: the merged 2★ lands on the bench.
    expect(side.board.filter(unit => unit?.name === name)).toHaveLength(0)
    expect(side.bench.filter(unit => unit.name === name && unit.star === 2)).toHaveLength(1)
  })
})

describe('sell action', () => {
  it('refunds cost + star bonus and removes the unit', () => {
    const state = freshGame(3)
    const side = state.sides[0]!
    side.gold = 10
    const entry = side.shop[0]!
    applyAction(state, 1, { action: 'buy', name: entry.name })
    const unit = side.bench[0]!
    const refund = unit.cost + (unit.star - 1) * 2
    const goldBefore = side.gold
    expect(applyAction(state, 1, { action: 'sell', chess_id: unit.id })).toBeUndefined()
    expect(side.gold).toBe(goldBefore + refund)
    expect(side.bench.find(candidate => candidate.id === unit.id)).toBeUndefined()
  })

  it('rejects unknown ids', () => {
    const state = freshGame()
    expect(applyAction(state, 1, { action: 'sell', chess_id: 999 })).toContain('未找到棋子')
  })
})

describe('move action', () => {
  it('deploys a bench unit and moves a board unit', () => {
    const state = freshGame(3)
    const side = state.sides[0]!
    side.gold = 100
    side.level = 2
    const name = side.shop[0]!.name
    applyAction(state, 1, { action: 'buy', name })
    const unit = side.bench[0]!
    expect(applyAction(state, 1, { action: 'move', chess_id: unit.id, pos: [1, 2] })).toBeUndefined()
    expect(side.board[1 * COLS + 2]).toBe(unit)
    expect(applyAction(state, 1, { action: 'move', chess_id: unit.id, pos: [3, 6] })).toBeUndefined()
    expect(side.board[1 * COLS + 2]).toBeNull()
    expect(side.board[3 * COLS + 6]).toBe(unit)
  })

  it('rejects out-of-bounds and occupied cells', () => {
    const state = freshGame(3)
    const side = state.sides[0]!
    side.gold = 100
    side.level = 2
    const name = side.shop[0]!.name
    applyAction(state, 1, { action: 'buy', name })
    const unit = side.bench[0]!
    expect(applyAction(state, 1, { action: 'move', chess_id: unit.id, pos: [4, 0] })).toContain('越界')
    expect(applyAction(state, 1, { action: 'move', chess_id: unit.id, pos: [0, 7] })).toContain('越界')
    applyAction(state, 1, { action: 'move', chess_id: unit.id, pos: [0, 0] })
    applyAction(state, 1, { action: 'buy', name: side.shop[1]!.name })
    const second = side.bench[0]!
    expect(applyAction(state, 1, { action: 'move', chess_id: second.id, pos: [0, 0] })).toContain('已被占用')
  })

  it('rejects deploying beyond the level cap', () => {
    const state = freshGame(3)
    const side = state.sides[0]!
    side.gold = 100
    side.level = 1
    const names = [side.shop[0]!.name, side.shop[1]!.name]
    applyAction(state, 1, { action: 'buy', name: names[0]! })
    applyAction(state, 1, { action: 'buy', name: names[1]! })
    applyAction(state, 1, { action: 'move', chess_id: side.bench[0]!.id, pos: [0, 0] })
    expect(applyAction(state, 1, { action: 'move', chess_id: side.bench[0]!.id, pos: [0, 1] })).toContain('上限')
  })
})

/* ------------------------------------------------------------------ *
 * Engine: traits, battle, settlement
 * ------------------------------------------------------------------ */

describe('traitCounts', () => {
  it('counts deployed races and classes only', () => {
    const state = freshGame()
    const side = state.sides[0]!
    side.level = 3
    const names = [side.shop[0]!.name, side.shop[1]!.name, side.shop[2]!.name]
    for (const name of names) {
      side.gold = 10
      applyAction(state, 1, { action: 'buy', name })
    }
    // Deploy two of them.
    applyAction(state, 1, { action: 'move', chess_id: side.bench[0]!.id, pos: [0, 0] })
    applyAction(state, 1, { action: 'move', chess_id: side.bench[0]!.id, pos: [0, 1] })
    const counts = traitCounts(side)
    const deployed = side.board.filter(unit => unit !== null).map(unit => unit!)
    for (const unit of deployed) {
      expect(counts.get(unit.race) ?? 0).toBeGreaterThanOrEqual(1)
      expect(counts.get(unit.class) ?? 0).toBeGreaterThanOrEqual(1)
    }
    expect(counts.get(deployed[0]!.race)! + counts.get(deployed[1]!.race)!).toBeLessThanOrEqual(2)
  })
})

describe('simulateBattle', () => {
  function oneVsOne(a: number, b: number): GameState {
    const state = freshGame(1)
    for (const [index, defId] of [a, b].entries()) {
      const player = state.sides[index]!
      player.level = 1
      player.gold = 10
      player.shop = [{ defId, name: `unit${defId}`, cost: 1, race: 'frost', class: 'mage' }]
      applyAction(state, (index + 1) as 1 | 2, { action: 'buy', name: `unit${defId}` })
      applyAction(state, (index + 1) as 1 | 2, { action: 'move', chess_id: player.bench[0]!.id, pos: [0, 0] })
    }
    return state
  }

  it('deterministically resolves a mirror match within the tick budget', () => {
    const state = oneVsOne(1, 1)
    const result = simulateBattle(state)
    expect(result.ticks.length).toBeGreaterThan(1)
    expect(result.ticks[0]!.units).toHaveLength(2)
    expect([0, 1, 2]).toContain(result.winner)
    expect(result.damage).toBe(result.winner === 0 ? 0 : result.survivors * 2)
    // Same state → same replay.
    const again = simulateBattle(cloneGameState(state))
    expect(again.winner).toBe(result.winner)
    expect(again.survivors).toBe(result.survivors)
    expect(again.ticks.length).toBe(result.ticks.length)
  })

  it('a lone 3-cost beats a lone 1-cost (much higher stats)', () => {
    const state = oneVsOne(20, 1)
    const result = simulateBattle(state)
    expect(result.winner).toBe(1)
    expect(result.survivors).toBeGreaterThanOrEqual(1)
  })

  it('an empty board loses immediately with 0 damage survivors', () => {
    const state = freshGame(2)
    // Give red a deployed unit.
    const red = state.sides[1]!
    red.level = 1
    red.gold = 10
    red.shop = [{ defId: 1, name: '冰女', cost: 1, race: 'frost', class: 'mage' }]
    applyAction(state, 2, { action: 'buy', name: '冰女' })
    applyAction(state, 2, { action: 'move', chess_id: red.bench[0]!.id, pos: [0, 0] })
    const result = simulateBattle(state)
    expect(result.winner).toBe(2)
    expect(result.survivors).toBe(1)
    expect(result.damage).toBe(2)
  })
})

describe('settleRound', () => {
  it('applies damage, streaks, income and advances the round', () => {
    const state = freshGame(5)
    const red = state.sides[1]!
    red.level = 1
    red.gold = 10
    red.shop = [{ defId: 20, name: '战神之王', cost: 3, race: 'warmonger', class: 'blade' }]
    applyAction(state, 2, { action: 'buy', name: '战神之王' })
    applyAction(state, 2, { action: 'move', chess_id: red.bench[0]!.id, pos: [0, 0] })
    const result = simulateBattle(state)
    const blueGoldBefore = state.sides[0]!.gold
    const redGoldBefore = state.sides[1]!.gold
    settleRound(state, result)
    expect(state.round).toBe(2)
    expect(state.sides[0]!.hp).toBe(START_HP - result.damage)
    expect(state.sides[0]!.lastResult).toBe('loss')
    expect(state.sides[0]!.lossStreak).toBe(1)
    expect(state.sides[1]!.winStreak).toBe(1)
    // Income was credited (base 5 + interest + bonuses ≥ 5).
    expect(state.sides[0]!.gold).toBeGreaterThanOrEqual(blueGoldBefore + 5)
    expect(state.sides[1]!.gold).toBeGreaterThanOrEqual(redGoldBefore + 5)
    expect(state.sides[0]!.shop).toHaveLength(5)
    expect(state.history).toHaveLength(1)
  })

  it('ends the game when a side hits zero HP', () => {
    const state = freshGame(5)
    state.sides[0]!.hp = 1
    settleRound(state, { winner: 2, survivors: 1, damage: 2, ticks: [] })
    expect(state.over).toBe(true)
    expect(state.winner).toBe(2)
  })
})

/* ------------------------------------------------------------------ *
 * LLM interaction: reply parsing and request validation
 * ------------------------------------------------------------------ */

describe('parseActionReply', () => {
  it('accepts a clean action array', () => {
    const reply = parseActionReply('[{"action":"buy","name":"剑圣"},{"action":"end_prep"}]')
    expect(reply).toEqual({
      kind: 'actions',
      actions: [{ action: 'buy', name: '剑圣' }, { action: 'end_prep' }],
    })
  })

  it('accepts an array wrapped in prose and a code fence', () => {
    expect(parseActionReply('好的，我的决策如下：```json\n[{"action":"refresh"},{"action":"upgrade"}]\n```')).toEqual({
      kind: 'actions',
      actions: [{ action: 'refresh' }, { action: 'upgrade' }],
    })
  })

  it('caps the action list at MAX_ACTIONS', () => {
    const actions = Array.from({ length: 8 }, (_, i) => `{"action":"upgrade"}`).join(',')
    const reply = parseActionReply(`[${actions}]`)
    expect(reply.kind).toBe('actions')
    if (reply.kind === 'actions') expect(reply.actions).toHaveLength(MAX_ACTIONS)
  })

  it('rejects malformed payloads', () => {
    const expectations: [string, string][] = [
      ['no json here', 'JSON 数组'],
      ['{"action":"buy"}', 'JSON 数组'],
      ['[1, 2]', 'JSON 对象'],
      ['[{"action":"buy"}]', 'name'],
      ['[{"action":"sell"}]', 'chess_id'],
      ['[{"action":"move","chess_id":1,"pos":"1,2"}]', 'pos'],
      ['[{"action":"move","chess_id":1,"pos":[1]}]', 'pos'],
      ['[{"action":"teleport"}]', '未知操作'],
      ['[{not json}]', '无法解析'],
      ['[]', '空数组'],
    ]
    for (const [text, reason] of expectations) {
      const reply = parseActionReply(text)
      expect(reply.kind).toBe('invalid')
      if (reply.kind === 'invalid') expect(reply.reason).toContain(reason)
    }
  })
})

describe('validateActionRequest', () => {
  const state = freshGame()

  it('accepts a well-formed request', () => {
    expect(validateActionRequest({ provider: 'deepseek-official', model: 'deepseek-v4-flash', side: 1, state }))
      .toMatchObject({ provider: 'deepseek-official', model: 'deepseek-v4-flash', side: 1, state })
    expect(validateActionRequest({ provider: 'p', model: 'm', side: 2, state, system: '' }))
      .toMatchObject({ side: 2, system: '' })
  })

  it('rejects non-object bodies and missing fields', () => {
    expect(() => validateActionRequest(null)).toThrow(/JSON 对象/)
    expect(() => validateActionRequest([1])).toThrow(/JSON 对象/)
    expect(() => validateActionRequest({ model: 'm', side: 1, state })).toThrow(/provider/)
    expect(() => validateActionRequest({ provider: '', model: 'm', side: 1, state })).toThrow(/provider/)
    expect(() => validateActionRequest({ provider: 'p', side: 1, state })).toThrow(/model/)
    expect(() => validateActionRequest({ provider: 'p', model: 'm', side: 3, state })).toThrow(/side/)
  })

  it('rejects malformed states', () => {
    expect(() => validateActionRequest({ provider: 'p', model: 'm', side: 1, state: {} })).toThrow(/state/)
    expect(() => validateActionRequest({ provider: 'p', model: 'm', side: 1, state: { sides: [] } })).toThrow(/state/)
    const bad = cloneGameState(state)
    bad.sides[0]!.gold = 'many' as unknown as number
    expect(() => validateActionRequest({ provider: 'p', model: 'm', side: 1, state: bad })).toThrow(/state/)
  })

  it('accepts optional thinking, overrides and retry feedback', () => {
    const body = validateActionRequest({
      provider: 'p', model: 'm', side: 1, state,
      thinking: 'max', actionTimeoutMs: 45_000, maxActionOutputTokens: 2048,
      previous: '[{"action":"buy","name":"x"}]', reason: '金币不足',
    })
    expect(body).toMatchObject({
      thinking: 'max', actionTimeoutMs: 45_000, maxActionOutputTokens: 2048,
      previous: '[{"action":"buy","name":"x"}]', reason: '金币不足',
    })
    expect(validateActionRequest({ provider: 'p', model: 'm', side: 1, state })).not.toHaveProperty('thinking')
  })

  it('rejects invalid thinking levels and overrides', () => {
    expect(() => validateActionRequest({ provider: 'p', model: 'm', side: 1, state, thinking: 'ultra' })).toThrow(/thinking/)
    expect(() => validateActionRequest({ provider: 'p', model: 'm', side: 1, state, actionTimeoutMs: 999 })).toThrow(/actionTimeoutMs/)
    expect(() => validateActionRequest({ provider: 'p', model: 'm', side: 1, state, maxActionOutputTokens: 7 })).toThrow(/maxActionOutputTokens/)
    expect(() => validateActionRequest({ provider: 'p', model: 'm', side: 1, state, previous: 3 })).toThrow(/previous/)
    expect(() => validateActionRequest({ provider: 'p', model: 'm', side: 1, state, reason: 3 })).toThrow(/reason/)
  })
})

/* ------------------------------------------------------------------ *
 * Prompt framing
 * ------------------------------------------------------------------ */

describe('buildActionUserMessage', () => {
  it('frames the state in the structured text format of the spec', () => {
    const state = freshGame(9)
    // Give blue a bought unit on the bench and one deployed.
    const blue = state.sides[0]!
    blue.gold = 12
    blue.level = 4
    blue.exp = 4
    blue.shop = [
      { defId: 11, name: '剑圣', cost: 2, race: 'warmonger', class: 'blade' },
      { defId: 1, name: '冰女', cost: 1, race: 'frost', class: 'mage' },
      ...blue.shop.slice(2),
    ]
    applyAction(state, 1, { action: 'buy', name: '冰女' })
    applyAction(state, 1, { action: 'buy', name: '冰女' })
    applyAction(state, 1, { action: 'buy', name: '冰女' }) // merges into 2★ 冰女
    applyAction(state, 1, { action: 'move', chess_id: blue.bench[0]!.id, pos: [1, 3] })
    blue.hp = 78
    blue.gold = 12
    state.sides[1]!.hp = 82
    const text = buildActionUserMessage(state, 1)
    expect(text).toContain('你正在玩一场简化自走棋。当前是你的准备阶段（第1回合）。')
    expect(text).toContain('你的生命值: 78，对手生命值: 82。')
    expect(text).toContain('你的金币: 12，升级所需经验: 4/6（当前等级4）。')
    expect(text).toContain('你的上场名额: 已上场 1 个 / 上限 4（还可上场 3 个），备战区有 0 个棋子未上场。')
    expect(text).toContain('若还有上场名额且备战区有棋子，请务必用 move 把棋子上场')
    expect(text).toContain('你的备战区棋子: [')
    expect(text).toContain('棋盘上已布阵: [')
    expect(text).toContain('商店刷出棋子: [')
    expect(text).toContain('{"name":"剑圣","cost":2,"race":"战神","class":"剑士"}')
    expect(text).toContain('上一轮战斗结果:')
    expect(text).toContain('对手已知阵容:')
    expect(text).toContain('请决定你要执行的操作，返回JSON数组，可能的操作包括：')
    expect(text).toContain('{"action":"buy", "name":"剑圣"}')
    expect(text).toContain('{"action":"sell", "chess_id":6}')
    expect(text).toContain('{"action":"move", "chess_id":6, "pos":[1,4]}')
    expect(text).toContain('{"action":"upgrade"} (购买经验)')
    expect(text).toContain('{"action":"refresh"} (刷新商店，花费2金币)')
    expect(text).toContain('{"action":"end_prep"} (结束准备)')
    expect(text).toContain(`你最多可以执行${MAX_ACTIONS}个操作，但总花费不能超过金币。请保证操作合法。`)
  })

  it('shows the 2★ unit stats on the bench after a merge', () => {
    const state = freshGame(3)
    const blue = state.sides[0]!
    blue.gold = 100
    const name = blue.shop[0]!.name
    applyAction(state, 1, { action: 'buy', name })
    applyAction(state, 1, { action: 'buy', name })
    applyAction(state, 1, { action: 'buy', name })
    const text = buildActionUserMessage(state, 1)
    const unit = blue.bench[0]!
    expect(unit.star).toBe(2)
    expect(text).toContain(`"name":"${name}"`)
    expect(text).toContain(`"star":2`)
  })

  it('appends corrective feedback on a retry', () => {
    const state = freshGame()
    const text = buildActionUserMessage(state, 1, '[{"action":"buy","name":"剑圣"}]', '金币不足')
    expect(text).toContain('你上一次的返回不合法（金币不足）')
    expect(text).toContain('[{"action":"buy","name":"剑圣"}]')
  })
})

describe('enemyScoutText', () => {
  it('reports counts, star breakdown, trait counts and power', () => {
    const state = freshGame(3)
    const blue = state.sides[0]!
    blue.level = 3
    blue.gold = 100
    const name = blue.shop[0]!.name
    applyAction(state, 1, { action: 'buy', name })
    applyAction(state, 1, { action: 'buy', name })
    applyAction(state, 1, { action: 'buy', name }) // 2★
    applyAction(state, 1, { action: 'move', chess_id: blue.bench[0]!.id, pos: [0, 0] })
    const text = enemyScoutText(blue)
    expect(text).toContain('对手上场1个棋子')
    expect(text).toContain('1个二星')
    expect(text).toContain('种族')
    expect(text).toContain('预估战力约')
  })

  it('handles an empty board', () => {
    expect(enemyScoutText(freshGame().sides[0]!)).toContain('未上场任何棋子')
  })
})

describe('traitLine', () => {
  it('labels triggered and untriggered traits', () => {
    const state = freshGame(3)
    const blue = state.sides[0]!
    blue.level = 4
    blue.gold = 100
    // Buy 冰女 three times (2★ 冰女, frost/mage) and 小精灵 once (stellar/mage).
    const frost = '冰女'
    for (let i = 0; i < 3; i += 1) {
      blue.shop = [{ defId: 1, name: frost, cost: 1, race: 'frost', class: 'mage' }]
      applyAction(state, 1, { action: 'buy', name: frost })
    }
    blue.shop = [{ defId: 6, name: '小精灵', cost: 1, race: 'stellar', class: 'mage' }]
    applyAction(state, 1, { action: 'buy', name: '小精灵' })
    // Deploy 冰女 + 小精灵: 冰裔×1, 星灵×1, 法师×2 → 2法师 triggered.
    applyAction(state, 1, { action: 'move', chess_id: blue.bench[0]!.id, pos: [0, 0] })
    applyAction(state, 1, { action: 'move', chess_id: blue.bench[0]!.id, pos: [0, 1] })
    const text = traitLine(blue)
    expect(text).toContain('冰裔×1（未触发）')
    expect(text).toContain('星灵×1（未触发）')
    expect(text).toContain('法师×2（已触发2法师')
  })
})

describe('default system prompt', () => {
  it('states the rules, the return format and a correct worked example', () => {
    expect(DEFAULT_SYSTEM_PROMPT).toContain('简化自走棋')
    expect(DEFAULT_SYSTEM_PROMPT).toContain(`${ROWS} 行 × ${COLS} 列`)
    expect(DEFAULT_SYSTEM_PROMPT).toContain('3 个同名同星棋子自动合成')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('合成会统计备战区与棋盘上所有的同名同星棋子')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('必须用 move 把棋子上场')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('冰裔')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('暗影')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('战神')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('星灵')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('蛮族')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('法师')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('剑士')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('射手')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('守卫')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('刺客')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('牧师')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('利息')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('只返回一个 JSON 数组')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('{"action":"buy", "name":"棋子名"}')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('{"action":"sell", "chess_id":棋子id}')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('{"action":"move", "chess_id":棋子id, "pos":[row, col]}')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('{"action":"upgrade"}')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('{"action":"refresh"}')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('{"action":"end_prep"}')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('正确案例')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('[{"action":"buy","name":"冰女"},{"action":"move","chess_id":6,"pos":[1,3]},{"action":"end_prep"}]')
    expect(DEFAULT_SYSTEM_PROMPT).toContain('错误示范')
  })
})

/* ------------------------------------------------------------------ *
 * Route constants and failure classification
 * ------------------------------------------------------------------ */

describe('route constants', () => {
  it('keeps the route prefix stable for the browser half', () => {
    expect(AUTO_CHESS_PATH).toBe('/plugins/auto-chess')
  })
})

describe('isRetryableActionFailure', () => {
  it('treats the harness transient failure codes as retryable', () => {
    for (const code of ['EMPTY_RESPONSE', 'RATE_LIMIT', 'SERVER', 'TIMEOUT', 'TRANSPORT']) {
      const error = new Error('boom') as Error & { code?: string }
      error.code = code
      expect(isRetryableActionFailure(error)).toBe(true)
    }
  })

  it('treats fatal, unknown, and codeless failures as non-retryable', () => {
    for (const code of ['AUTH', 'ABORTED', 'STREAM_CLOSED', 'NO_ADAPTER', 'INVALID_REQUEST', 'UNKNOWN']) {
      const error = new Error('boom') as Error & { code?: string }
      error.code = code
      expect(isRetryableActionFailure(error)).toBe(false)
    }
    expect(isRetryableActionFailure(new Error('no code'))).toBe(false)
    expect(isRetryableActionFailure(null)).toBe(false)
    expect(isRetryableActionFailure('string')).toBe(false)
  })
})
