/**
 * Auto chess (自走棋) node half for the dsh web GUI. The plugin owns three
 * routes under `/plugins/auto-chess`:
 *
 * - `GET  /plugins/auto-chess/prompt`  — the default system prompt (game
 *   rules, strict return format, and a worked example). The browser half
 *   fetches it to show and to restore, so the rules text lives in exactly
 *   one place.
 * - `GET  /plugins/auto-chess/models`  — the model catalog (registered
 *   provider routes and their models) for the side-model selectors.
 * - `POST /plugins/auto-chess/action`  — frame one side's full game state
 *   into a single-shot LLM request through the chosen provider/model route
 *   (optionally with a thinking level and per-request timeout/token
 *   overrides), parse the reply into a JSON action array, validate every
 *   action by applying it to a clone of the state with the same engine the
 *   browser uses, and return the accepted actions plus the model's reasoning
 *   text. Transient stream failures and illegal action batches retry within
 *   the attempt budget; the last attempt carries corrective feedback.
 *
 * The game itself (state, economy, battle) lives in the browser half; this
 * plugin only arbitrates AI prep decisions, so a malformed or illegal model
 * reply is rejected here and can never corrupt the client-side game. Rules,
 * the return format, and the correct example are spelled out in
 * {@link DEFAULT_SYSTEM_PROMPT}; users may hand-edit the prompt in the UI,
 * in which case the edited text is sent verbatim as the system prompt.
 * @module @deepseek-ai/dsh-auto-chess
 */

import type { IncomingMessage } from 'node:http'
import type { Context } from 'cordis'
import z from 'schemastery'
import { BlockAssembler, ReasoningEffortId, createUserMessage } from '@deepseek-ai/dsh-llm'
import type { ContentBlock, FinishReason, GenerateOptions, LlmModelInfo, Message } from '@deepseek-ai/dsh-llm'
// Type-only: the ctx.httpServer merge (the webserver host plugin).
import type {} from '@deepseek-ai/dsh-host-webserver'
import type {} from '@deepseek-ai/dsh-llm'
import {
  MAX_ACTIONS, applyAction, cloneGameState,
  type ChessAction, type GameState,
} from './game/engine.ts'
import { DEFAULT_SYSTEM_PROMPT, buildActionUserMessage } from './game/prompt.ts'

// The default prompt and the user-message assembler are part of the public
// surface: the browser half fetches the prompt over HTTP, and tests (and
// future embedders) exercise both directly.
export { DEFAULT_SYSTEM_PROMPT, buildActionUserMessage } from './game/prompt.ts'

/** Cordis plugin name (diagnostics only). */
export const name = 'auto-chess'

/** Services required before the board routes can mount. */
export const inject = ['httpServer', 'llm']

/** The side an AI prep decision plays for. */
export type AutoChessSide = 1 | 2

/** The AI thinking level for one action request (wire spelling). */
export type AutoChessThinking = 'off' | 'high' | 'max'

/** Required plugin configuration. */
export interface Config {
  /** End-to-end deadline for one AI action attempt, in milliseconds. */
  actionTimeoutMs: number
  /** Output-token cap for one AI action reply. */
  maxActionOutputTokens: number
  /** Total AI action attempts per request (1 = no retry); the last attempt carries corrective feedback. */
  maxActionAttempts: number
}

/** Loader schema with deployment defaults (no library defaults). */
export const Config: z<Config> = z.object({
  actionTimeoutMs: z.number().step(1).min(1000).default(300_000),
  // Generous by default: reasoning models count their thinking toward the
  // output budget, and a truncated reply is only salvageable when the JSON
  // itself survives the cut. The UI offers no input for this anymore — the
  // browser half sends this same fixed value with every request.
  maxActionOutputTokens: z.number().step(1).min(8).default(32_000),
  maxActionAttempts: z.number().step(1).min(1).max(3).default(3),
})

/** Route prefix owned by this plugin (the browser half calls under it). */
export const AUTO_CHESS_PATH = '/plugins/auto-chess'

/** Stable plugin identity stamped into auxiliary LLM request sources. */
const PLUGIN_ID = 'dsh-auto-chess'

/** The wire shape of one model group served to the browser half. */
export interface ModelGroupWire {
  /** Provider route key (passed back as the action request's `provider`). */
  provider: string
  /** Human-readable provider name. */
  displayName: string
  /** The provider's selectable models. */
  models: { id: string; name: string }[]
}

/** One provider whose model listing failed (the sound groups still serve). */
export interface ModelFailureWire {
  provider: string
  error: string
}

/** One validated prep action from the model reply (before legality is checked). */
export type ActionReply =
  | { kind: 'actions'; actions: ChessAction[] }
  | { kind: 'error'; message: string }
  | { kind: 'invalid'; reason: string }

/** The validated action-request wire body. */
export interface ActionRequestBody {
  /** Registered provider route key. */
  provider: string
  /** Model id the provider accepts. */
  model: string
  /** The side the AI plays in this request. */
  side: AutoChessSide
  /** The authoritative game state at decision time (the browser's). */
  state: GameState
  /** Custom system prompt; empty or absent falls back to the default. */
  system?: string
  /** AI thinking level; forwarded only when the selected model advertises that effort. */
  thinking?: AutoChessThinking
  /** Per-request deadline override (milliseconds); absent uses the config default. */
  actionTimeoutMs?: number
  /** Per-request output-token cap override; absent uses the config default. */
  maxActionOutputTokens?: number
  /** The previous illegal reply, for corrective feedback (client retries). */
  previous?: string
  /** The rejection reason of the previous reply (client retries). */
  reason?: string
}

/** One per-action verdict returned to the browser (the browser replays accepted ones). */
export interface ActionVerdictWire {
  /** The original action, verbatim. */
  action: ChessAction
  /** Whether the action was legal and applied. */
  ok: boolean
  /** The rejection reason when not ok (whole-batch responses never mix ok and not-ok). */
  error?: string
}

/** Tolerant extraction of the JSON array region from a model reply (first `[` … last `]`). */
function jsonArrayRegion(text: string): string | undefined {
  const start = text.indexOf('[')
  const end = text.lastIndexOf(']')
  if (start === -1 || end <= start) return undefined
  return text.slice(start, end + 1)
}

/** Narrow an unknown parsed element to a ChessAction, returning a reason string on failure. */
function parseActionElement(value: unknown): { action: ChessAction } | { error: string } {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    return { error: '操作必须是 JSON 对象' }
  }
  const candidate = value as Record<string, unknown>
  switch (candidate.action) {
    case 'buy':
      if (typeof candidate.name !== 'string' || candidate.name.length === 0) return { error: 'buy 需要非空 name' }
      return { action: { action: 'buy', name: candidate.name } }
    case 'sell': {
      const id = candidate.chess_id
      if (typeof id !== 'number' || !Number.isInteger(id)) return { error: 'sell 需要整数 chess_id' }
      return { action: { action: 'sell', chess_id: id } }
    }
    case 'move': {
      const id = candidate.chess_id
      const pos = candidate.pos
      if (typeof id !== 'number' || !Number.isInteger(id)) return { error: 'move 需要整数 chess_id' }
      if (!Array.isArray(pos) || pos.length !== 2
        || !Number.isInteger(pos[0]) || !Number.isInteger(pos[1])
        || typeof pos[0] !== 'number' || typeof pos[1] !== 'number') {
        return { error: 'move 的 pos 必须是 [row, col] 整数坐标' }
      }
      return { action: { action: 'move', chess_id: id, pos: [pos[0], pos[1]] } }
    }
    case 'upgrade':
      return { action: { action: 'upgrade' } }
    case 'refresh':
      return { action: { action: 'refresh' } }
    case 'end_prep':
      return { action: { action: 'end_prep' } }
    default:
      return { error: `未知操作类型「${String(candidate.action)}」` }
  }
}

/**
 * Parse and shape-check one model reply into an {@link ActionReply}. The
 * reply may wrap the JSON in prose or a code fence (models do), so the
 * array region is extracted before parsing; element shapes and the
 * MAX_ACTIONS cap are enforced here, while game legality is checked by
 * applying the actions (see the route).
 * @param text - the assembled model reply text.
 * @returns the parsed reply.
 */
export function parseActionReply(text: string): ActionReply {
  const region = jsonArrayRegion(text)
  if (region === undefined) return { kind: 'invalid', reason: '回复中没有 JSON 数组' }
  let parsed: unknown
  try {
    parsed = JSON.parse(region)
  } catch {
    return { kind: 'invalid', reason: '回复中的 JSON 无法解析' }
  }
  if (!Array.isArray(parsed)) return { kind: 'invalid', reason: '回复不是 JSON 数组' }
  if (parsed.length === 0) return { kind: 'invalid', reason: '回复是空数组' }
  const actions: ChessAction[] = []
  for (const element of parsed.slice(0, MAX_ACTIONS)) {
    const result = parseActionElement(element)
    if ('error' in result) return { kind: 'invalid', reason: result.error }
    actions.push(result.action)
  }
  return { kind: 'actions', actions }
}

/** Minimal structural validation of a game state (deep legality is the engine's job). */
function isGameState(value: unknown): value is GameState {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false
  const candidate = value as Record<string, unknown>
  if (typeof candidate.round !== 'number' || typeof candidate.nextUnitId !== 'number'
    || typeof candidate.seed !== 'number' || typeof candidate.over !== 'boolean') return false
  const sides = candidate.sides
  if (!Array.isArray(sides) || sides.length !== 2) return false
  return sides.every(side => {
    if (side === null || typeof side !== 'object' || Array.isArray(side)) return false
    const s = side as Record<string, unknown>
    return typeof s.hp === 'number' && typeof s.gold === 'number' && typeof s.level === 'number'
      && typeof s.exp === 'number' && Array.isArray(s.bench) && Array.isArray(s.board)
      && Array.isArray(s.shop)
  })
}

/**
 * Validate an untrusted action-request body into a typed request.
 * @param value - the parsed request body.
 * @returns the validated request.
 * @throws {Error} with a user-readable reason on the first invalid field.
 */
export function validateActionRequest(value: unknown): ActionRequestBody {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('请求体必须是 JSON 对象')
  }
  const candidate = value as Record<string, unknown>
  if (typeof candidate.provider !== 'string' || candidate.provider.length === 0) {
    throw new Error('provider 必须是非空字符串')
  }
  if (typeof candidate.model !== 'string' || candidate.model.length === 0) {
    throw new Error('model 必须是非空字符串')
  }
  if (candidate.side !== 1 && candidate.side !== 2) {
    throw new Error('side 必须是 1 或 2')
  }
  if (!isGameState(candidate.state)) {
    throw new Error('state 缺少必要的游戏字段（sides/hp/gold/level/exp/bench/board/shop）')
  }
  if (candidate.thinking !== undefined && candidate.thinking !== 'off'
    && candidate.thinking !== 'high' && candidate.thinking !== 'max') {
    throw new Error('thinking 必须是 "off"、"high" 或 "max"')
  }
  if (candidate.actionTimeoutMs !== undefined
    && (typeof candidate.actionTimeoutMs !== 'number'
      || !Number.isInteger(candidate.actionTimeoutMs) || candidate.actionTimeoutMs < 1000)) {
    throw new Error('actionTimeoutMs 必须是 >= 1000 的整数毫秒数')
  }
  if (candidate.maxActionOutputTokens !== undefined
    && (typeof candidate.maxActionOutputTokens !== 'number'
      || !Number.isInteger(candidate.maxActionOutputTokens) || candidate.maxActionOutputTokens < 8)) {
    throw new Error('maxActionOutputTokens 必须是 >= 8 的整数')
  }
  const system = candidate.system
  if (system !== undefined && typeof system !== 'string') {
    throw new Error('system 必须是字符串')
  }
  const previous = candidate.previous
  if (previous !== undefined && typeof previous !== 'string') {
    throw new Error('previous 必须是字符串')
  }
  const reason = candidate.reason
  if (reason !== undefined && typeof reason !== 'string') {
    throw new Error('reason 必须是字符串')
  }
  return {
    provider: candidate.provider,
    model: candidate.model,
    side: candidate.side,
    state: candidate.state,
    ...(typeof system === 'string' ? { system } : {}),
    ...(candidate.thinking !== undefined ? { thinking: candidate.thinking } : {}),
    ...(candidate.actionTimeoutMs !== undefined ? { actionTimeoutMs: candidate.actionTimeoutMs } : {}),
    ...(candidate.maxActionOutputTokens !== undefined ? { maxActionOutputTokens: candidate.maxActionOutputTokens } : {}),
    ...(typeof previous === 'string' ? { previous } : {}),
    ...(typeof reason === 'string' ? { reason } : {}),
  }
}

/** Translate a terminal finish reason into an action failure. */
function finishError(finish: FinishReason): Error | undefined {
  switch (finish.kind) {
    case 'stop':
      return undefined
    case 'error':
    case 'aborted': {
      const error = new Error(finish.failure.message) as Error & { code?: string }
      error.code = finish.failure.code
      return error
    }
    case 'max-tokens':
      return new Error('auto-chess: AI 回复超过最大输出长度')
    case 'tool-calls':
      return new Error('auto-chess: AI 意外请求了工具调用')
    /* v8 ignore next -- closed-union exhaustiveness guard */
    default:
      return new Error(`auto-chess: unsupported finish reason "${String((finish as { kind?: unknown }).kind)}"`)
  }
}

/** One attempt's assembled reply, reasoning, and whether the output budget cut it short. */
interface ActionAttemptText {
  /** The model's assembled visible text (may be incomplete). */
  text: string
  /** The model's reasoning/thinking text, when the reply carried any. */
  reasoning: string
  /** True when the stream hit maxActionOutputTokens (the JSON may still be complete). */
  truncated: boolean
}

/**
 * Failure codes the action loop treats as transient, mirroring the harness's
 * default provider retry policy (dsh-llm retry-policy.ts): a stream that
 * dropped mid-response or a transient provider failure deserves one more
 * attempt before the request gives up. Auth, validation, and cancellation
 * failures stay fatal.
 */
const RETRYABLE_ACTION_FAILURE_CODES: ReadonlySet<string> = new Set([
  'EMPTY_RESPONSE', 'RATE_LIMIT', 'SERVER', 'TIMEOUT', 'TRANSPORT',
])

/**
 * Whether a thrown action-stream failure is transient and worth one retry.
 * @param error - the error thrown by {@link streamActionText}.
 * @returns true when the failure carries one of the retryable codes.
 */
export function isRetryableActionFailure(error: unknown): boolean {
  const code = (error as { code?: unknown } | null)?.code
  return typeof code === 'string' && RETRYABLE_ACTION_FAILURE_CODES.has(code)
}

/**
 * Run one AI action attempt: stream the framed state through the chosen
 * provider/model route and assemble the reply text plus any reasoning
 * blocks. The requested thinking level is forwarded only when the selected
 * model advertises that exact effort; an unsupported level falls back to
 * the model's own default instead of failing the attempt.
 * @param ctx - host context exposing the llm service.
 * @param request - the validated action request.
 * @param system - the system prompt for this attempt.
 * @param user - the user message for this attempt.
 * @param maxTokens - the output-token cap for this attempt (per-request override or config default).
 * @param signal - cancellation (request deadline / plugin disposal).
 * @returns the assembled reply text, the reasoning text, and the truncation flag.
 * @throws when the stream fails or the model produced no text at all.
 */
async function streamActionText(
  ctx: Context,
  request: ActionRequestBody,
  system: string,
  user: Message,
  maxTokens: number,
  signal: AbortSignal,
): Promise<ActionAttemptText> {
  let reasoningEffort: ReasoningEffortId | undefined
  if (request.thinking !== undefined) {
    const info = await ctx.llm.resolveModelInfo(request.provider, request.model, signal)
    if (info.reasoning?.efforts.some(effort => effort.id === request.thinking)) {
      reasoningEffort = ReasoningEffortId(request.thinking)
    }
  }
  const options: GenerateOptions = {
    provider: request.provider,
    model: request.model,
    messages: [user],
    system,
    maxTokens,
    signal,
    ...(reasoningEffort !== undefined ? { reasoningEffort } : {}),
  }
  const assembler = new BlockAssembler()
  for await (const chunk of ctx.llm.stream(options)) {
    signal.throwIfAborted()
    assembler.push(chunk)
  }
  signal.throwIfAborted()
  const truncated = assembler.finish.kind === 'max-tokens'
  // A max-tokens cut is NOT a hard failure: reasoning models spend most of
  // the budget thinking, and the visible text may already hold a complete
  // JSON array — parsing it is the caller's job.
  const terminal = finishError(assembler.finish)
  if (terminal !== undefined && !truncated) throw terminal
  const blocks = assembler.blocks()
  const text = blocks
    .filter((block): block is Extract<ContentBlock, { type: 'text' }> => block.type === 'text')
    .map(block => block.text)
    .join(' ')
    .trim()
  if (text.length === 0 && !truncated) throw new Error('auto-chess: AI 没有返回任何内容')
  const reasoning = blocks
    .filter((block): block is Extract<ContentBlock, { type: 'reasoning' }> => block.type === 'reasoning')
    .map(block => block.text)
    .join(' ')
    .trim()
  return { text, reasoning, truncated }
}

/**
 * Mount the auto-chess plugin: the three routes plus the action-request
 * lifecycle.
 * @param ctx - host cordis context.
 * @param config - validated loader configuration.
 */
export function apply(ctx: Context, config: Config): void {
  const resolved: Required<Config> = {
    actionTimeoutMs: config.actionTimeoutMs,
    maxActionOutputTokens: config.maxActionOutputTokens,
    maxActionAttempts: config.maxActionAttempts,
  }

  /** Collect the request body into a parsed JSON value. */
  const readJson = async (req: IncomingMessage): Promise<unknown> => {
    const chunks: Buffer[] = []
    for await (const chunk of req) chunks.push(chunk as Buffer)
    const raw = Buffer.concat(chunks).toString('utf8')
    if (raw.length === 0) return {}
    return JSON.parse(raw)
  }

  ctx.effect(() => {
    const dispose = ctx.httpServer.register({
      kind: 'prefix',
      path: AUTO_CHESS_PATH,
      handler: async (req, res) => {
        const writeJson = (status: number, body: unknown): void => {
          res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
          res.end(JSON.stringify(body))
        }
        try {
          const url = new URL(req.url ?? '/', 'http://dsh.internal')
          const segments = url.pathname.slice(AUTO_CHESS_PATH.length).split('/').filter(Boolean)
          if (req.method === 'GET' && segments.length === 1 && segments[0] === 'prompt') {
            writeJson(200, { prompt: DEFAULT_SYSTEM_PROMPT })
            return
          }
          if (req.method === 'GET' && segments.length === 1 && segments[0] === 'models') {
            const groups: ModelGroupWire[] = []
            const failures: ModelFailureWire[] = []
            for (const provider of ctx.llm.listProviders()) {
              let models: readonly LlmModelInfo[]
              try {
                models = await ctx.llm.listModels(provider.id)
              } catch (error) {
                failures.push({ provider: provider.id, error: error instanceof Error ? error.message : String(error) })
                continue
              }
              groups.push({
                provider: provider.id,
                displayName: provider.name,
                models: models.map(model => ({ id: model.id, name: model.name })),
              })
            }
            writeJson(200, { groups, failures })
            return
          }
          if (req.method === 'POST' && segments.length === 1 && segments[0] === 'action') {
            const request = validateActionRequest(await readJson(req))
            // Per-request overrides stand; absent values fall back to the
            // deployment policy from the loader config.
            const effectiveTimeoutMs = request.actionTimeoutMs ?? resolved.actionTimeoutMs
            const effectiveMaxTokens = request.maxActionOutputTokens ?? resolved.maxActionOutputTokens
            const controller = new AbortController()
            const timer = setTimeout(
              () => { controller.abort(new Error('auto-chess: AI 决策超时')) },
              effectiveTimeoutMs,
            )
            try {
              const system = request.system !== undefined && request.system.trim().length > 0
                ? request.system
                : DEFAULT_SYSTEM_PROMPT
              let lastText: string | undefined
              let lastReason: string | undefined
              let lastReasoning = ''
              for (let attempt = 1; attempt <= resolved.maxActionAttempts; attempt += 1) {
                // The user message is framed by the shared (browser-safe)
                // prompt module, which cannot import dsh-llm — wrap the text
                // here, where the llm types live.
                const user = createUserMessage({
                  content: [{ type: 'text', text: buildActionUserMessage(request.state, request.side, lastText, lastReason) }],
                  source: { kind: 'plugin', plugin: PLUGIN_ID },
                })
                let attemptText: ActionAttemptText
                try {
                  attemptText = await streamActionText(ctx, request, system, user, effectiveMaxTokens, controller.signal)
                } catch (error) {
                  // A transient stream failure (the connection dropped
                  // mid-response, a provider rate limit, ...) is worth one more
                  // attempt — the model never saw a completed reply, so retry
                  // without corrective feedback. The last attempt falls through
                  // to the bounded failure response below instead of a raw 400.
                  if (!isRetryableActionFailure(error)) throw error
                  lastText = undefined
                  lastReason = error instanceof Error ? error.message : String(error)
                  // A failed stream carries no usable reasoning; drop any
                  // earlier attempt's text so the error response stays honest.
                  lastReasoning = ''
                  ctx.logger.warn('auto-chess: transient AI action failure: %s', lastReason)
                  if (attempt < resolved.maxActionAttempts) continue
                  break
                }
                const text = attemptText.text
                lastReasoning = attemptText.reasoning
                const reply = parseActionReply(text)
                if (reply.kind === 'actions') {
                  // Validate the WHOLE batch by applying every action to a
                  // clone of the authoritative state; any failure rejects the
                  // batch and triggers corrective feedback.
                  const clone = cloneGameState(request.state)
                  const verdicts: ActionVerdictWire[] = []
                  const failures: string[] = []
                  for (const action of reply.actions) {
                    const error = applyAction(clone, request.side, action)
                    verdicts.push({ action, ok: error === undefined, ...(error !== undefined ? { error } : {}) })
                    if (error !== undefined) failures.push(`${JSON.stringify(action)}：${error}`)
                  }
                  if (failures.length === 0) {
                    writeJson(200, { actions: verdicts, reasoning: lastReasoning })
                    return
                  }
                  lastText = text
                  lastReason = `以下操作不合法：${failures.join('；')}`
                  continue
                }
                if (reply.kind === 'error') {
                  writeJson(200, { error: `AI 报告：${reply.message}`, reasoning: lastReasoning })
                  return
                }
                lastText = text
                lastReason = attemptText.truncated
                  ? 'AI 回复被截断（超过最大输出长度），可能未输出完整的 JSON'
                  : reply.reason
              }
              writeJson(200, {
                error: `AI 连续 ${resolved.maxActionAttempts} 次未能给出合法操作（最后原因：${lastReason ?? '未知'}）`,
                reasoning: lastReasoning,
                ...(lastText !== undefined ? { lastText } : {}),
                ...(lastReason !== undefined ? { lastReason } : {}),
              })
            } finally {
              clearTimeout(timer)
            }
            return
          }
          writeJson(404, { error: 'unknown auto-chess route' })
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error)
          writeJson(400, { error: message })
        }
      },
    })
    return () => { dispose() }
  }, 'auto-chess: routes + action lifecycle')
}
