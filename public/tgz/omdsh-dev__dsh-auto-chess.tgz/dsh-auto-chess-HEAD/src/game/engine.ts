/**
 * Minimal Auto Chess — shared game engine.
 *
 * Pure TypeScript with no imports: the browser half owns the authoritative
 * game state and renders/battles with it, and the node half clones the state
 * from each AI action request to validate the model's proposed actions
 * against exactly the same rules. Everything here is deterministic given the
 * state (battle uses the state's own seed), so the server's validation and
 * the client's commit can never drift apart.
 *
 * Rule surface (deliberately small so an LLM can hold it all in context):
 * - Two sides, 100 HP each. A round is prep → auto battle → settlement.
 * - Each side deploys on its own 4×7 grid; battles mirror the two grids
 *   into one 4×14 field.
 * - A public pool of 24 units (1/2/3 gold). Three identical same-star units
 *   merge into one higher-star unit (1★→2★→3★; 2★ ≈ 1.8× stats, 3★ ≈ 3.24×).
 * - Race/class synergies trigger at thresholds on deployed units only.
 * - Economy: base 5 income, interest min(gold/10, 5), streak bonuses, +1 for
 *   a win; buying 4 exp costs 4 gold; level raises the board cap and the
 *   shop's odds of expensive units.
 * - Battle: a low-precision 0.5s-per-tick simulation — units seek the
 *   nearest enemy, move toward it, attack on their attack timer, and cast a
 *   simple skill every N attacks. The loser takes 2 damage per surviving
 *   enemy unit.
 * @module dsh-auto-chess/game/engine
 */

/** Board rows per side. */
export const ROWS = 4
/** Board columns per side. */
export const COLS = 7
/** Total board cells per side. */
export const BOARD_CELLS = ROWS * COLS
/** Combined battle field columns (two mirrored 7-column boards). */
export const FIELD_COLS = COLS * 2
/** Starting player HP. */
export const START_HP = 100
/** Starting gold. */
export const START_GOLD = 6
/** Bench capacity. */
export const BENCH_CAP = 9
/** Highest purchasable level. */
export const MAX_LEVEL = 8
/** Shop size per refresh. */
export const SHOP_SIZE = 5
/** Maximum actions one AI decision (or one human prep) may carry. */
export const MAX_ACTIONS = 4
/** Gold cost of refreshing the shop. */
export const REFRESH_COST = 2
/** Gold cost of buying 4 experience. */
export const UPGRADE_COST = 4
/** Experience gained per upgrade purchase. */
export const UPGRADE_EXP = 4
/** HP the loser loses per surviving enemy unit. */
export const DAMAGE_PER_SURVIVOR = 2
/** Interest cap (gold/10, at most this much). */
export const INTEREST_CAP = 5
/** Base income per round. */
export const BASE_INCOME = 5
/** Bonus gold for winning a round. */
export const WIN_BONUS = 1
/** Battle tick duration in seconds. */
export const TICK_SEC = 0.5
/** Battle tick limit before a timeout comparison. */
export const MAX_TICKS = 120
/** Horizontal cells a unit moves per battle tick. */
export const MOVE_PER_TICK = 0.5

/** Unit star level. */
export type Star = 1 | 2 | 3

/** Race ids (种族). */
export type RaceId = 'frost' | 'shadow' | 'warmonger' | 'stellar' | 'barbarian'
/** Class ids (职业). */
export type ClassId = 'mage' | 'blade' | 'marksman' | 'guardian' | 'assassin' | 'priest'

/** A unit's skill: cast every N attacks. Damage skills use ATK × power (× skill power); heals heal all allies. */
export interface SkillDef {
  kind: 'damage' | 'heal-all'
  /** Cast on the Nth attack since the last cast. */
  every: number
  /** ATK multiplier (damage) or heal amount as a fraction of ATK. */
  power: number
  /** Damage skills also hit enemies adjacent to the target. */
  aoe?: boolean
}

/** One entry of the static unit pool. */
export interface UnitDef {
  /** Stable pool id (1..24). */
  id: number
  name: string
  cost: 1 | 2 | 3
  race: RaceId
  class: ClassId
  /** Base (1★) max HP. */
  hp: number
  /** Base (1★) attack. */
  atk: number
  /** Attacks per second. */
  atkSpeed: number
  /** Attack range in cells (melee 1.5, marksman 4). */
  range: number
  skill: SkillDef
}

/** One concrete unit instance (star-scaled stats, no battle bonuses). */
export interface ChessUnit {
  id: number
  defId: number
  name: string
  cost: 1 | 2 | 3
  star: Star
  race: RaceId
  class: ClassId
  /** Current star-scaled max HP. */
  hp: number
  maxHp: number
  /** Current star-scaled attack. */
  atk: number
  atkSpeed: number
  range: number
  skill: SkillDef
}

/** One shop offer. */
export interface ShopEntry {
  defId: number
  name: string
  cost: number
  race: RaceId
  class: ClassId
}

/** One trait effect tier (the highest met threshold applies). */
export interface TraitEffect {
  /** Max-HP bonus fraction (of the unit's own star-scaled HP). */
  hpPct?: number
  /** Attack bonus fraction. */
  atkPct?: number
  /** Attack-speed bonus fraction. */
  atkSpeedPct?: number
  /** Skill-power bonus fraction (multiplies skill damage). */
  skillPct?: number
  /** Critical-chance bonus (0..1); crits deal 1.5×. */
  critPct?: number
  /** Flat max-HP bonus. */
  hpFlat?: number
  /** 'self' applies to units of this trait; 'all' applies to every ally. */
  scope: 'self' | 'all'
}

/** One trait definition. */
export interface TraitDef {
  id: RaceId | ClassId
  kind: 'race' | 'class'
  name: string
  tiers: { threshold: number; desc: string; effect: TraitEffect }[]
}

/** One side's full state. */
export interface SideState {
  side: 1 | 2
  hp: number
  gold: number
  level: number
  exp: number
  bench: ChessUnit[]
  /** BOARD_CELLS cells in row-major order; null = empty. */
  board: (ChessUnit | null)[]
  shop: ShopEntry[]
  winStreak: number
  lossStreak: number
  lastResult: 'win' | 'loss' | 'draw' | null
  /** Own surviving units at the end of the last battle. */
  lastSurvivors: number
}

/** One settled battle, kept in the round history. */
export interface BattleRecord {
  round: number
  winner: 1 | 2 | 0
  survivors: number
  damage: number
}

/** The whole game state (JSON-safe; the wire shape for AI action requests). */
export interface GameState {
  round: number
  sides: [SideState, SideState]
  nextUnitId: number
  /** Battle RNG seed; advanced after every battle so replays differ. */
  seed: number
  history: BattleRecord[]
  over: boolean
  winner: 1 | 2 | null
}

/** The action vocabulary the LLM (and the human UI) may use during prep. */
export type ChessAction =
  | { action: 'buy'; name: string }
  | { action: 'sell'; chess_id: number }
  | { action: 'move'; chess_id: number; pos: [number, number] }
  | { action: 'upgrade' }
  | { action: 'refresh' }
  | { action: 'end_prep' }

/** A seeded RNG (mulberry32). */
export type Rng = () => number

/** Build a mulberry32 PRNG from a seed. */
export function mulberry32(seed: number): Rng {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = a
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/** Human-readable trait name. */
export function traitName(id: RaceId | ClassId): string {
  return TRAITS.find(trait => trait.id === id)?.name ?? id
}

/* ------------------------------------------------------------------ *
 * Unit pool and traits
 * ------------------------------------------------------------------ */

/** The 24-unit public pool (ids 1..24, costs 1/2/3). */
export const UNIT_POOL: readonly UnitDef[] = [
  // ── 1 费 ────────────────────────────────────────────────────────────
  { id: 1, name: '冰女', cost: 1, race: 'frost', class: 'mage', hp: 500, atk: 42, atkSpeed: 0.75, range: 1.5, skill: { kind: 'damage', every: 4, power: 1.5 } },
  { id: 2, name: '小鹿', cost: 1, race: 'barbarian', class: 'marksman', hp: 460, atk: 40, atkSpeed: 0.85, range: 4, skill: { kind: 'damage', every: 5, power: 1.3 } },
  { id: 3, name: '石像鬼', cost: 1, race: 'stellar', class: 'guardian', hp: 620, atk: 30, atkSpeed: 0.6, range: 1.5, skill: { kind: 'damage', every: 4, power: 1.2, aoe: true } },
  { id: 4, name: '火鸡', cost: 1, race: 'barbarian', class: 'blade', hp: 480, atk: 44, atkSpeed: 0.8, range: 1.5, skill: { kind: 'damage', every: 4, power: 1.5 } },
  { id: 5, name: '幽魂', cost: 1, race: 'shadow', class: 'assassin', hp: 450, atk: 46, atkSpeed: 0.9, range: 1.5, skill: { kind: 'damage', every: 4, power: 1.6 } },
  { id: 6, name: '小精灵', cost: 1, race: 'stellar', class: 'mage', hp: 420, atk: 44, atkSpeed: 0.7, range: 1.5, skill: { kind: 'damage', every: 4, power: 1.5 } },
  { id: 7, name: '老铁匠', cost: 1, race: 'barbarian', class: 'guardian', hp: 640, atk: 32, atkSpeed: 0.6, range: 1.5, skill: { kind: 'damage', every: 4, power: 1.4 } },
  { id: 8, name: '白鸽', cost: 1, race: 'frost', class: 'priest', hp: 480, atk: 36, atkSpeed: 0.7, range: 1.5, skill: { kind: 'heal-all', every: 4, power: 1.5 } },
  { id: 9, name: '暗影鼠', cost: 1, race: 'shadow', class: 'assassin', hp: 440, atk: 45, atkSpeed: 0.85, range: 1.5, skill: { kind: 'damage', every: 4, power: 1.5 } },
  { id: 10, name: '见习剑士', cost: 1, race: 'warmonger', class: 'blade', hp: 500, atk: 42, atkSpeed: 0.75, range: 1.5, skill: { kind: 'damage', every: 4, power: 1.5 } },
  // ── 2 费 ────────────────────────────────────────────────────────────
  { id: 11, name: '剑圣', cost: 2, race: 'warmonger', class: 'blade', hp: 620, atk: 62, atkSpeed: 0.85, range: 1.5, skill: { kind: 'damage', every: 4, power: 2.0 } },
  { id: 12, name: '冰霜守卫', cost: 2, race: 'frost', class: 'guardian', hp: 760, atk: 40, atkSpeed: 0.6, range: 1.5, skill: { kind: 'damage', every: 4, power: 1.6 } },
  { id: 13, name: '暗影法师', cost: 2, race: 'shadow', class: 'mage', hp: 560, atk: 58, atkSpeed: 0.7, range: 1.5, skill: { kind: 'damage', every: 4, power: 2.0 } },
  { id: 14, name: '星灵射手', cost: 2, race: 'stellar', class: 'marksman', hp: 560, atk: 56, atkSpeed: 0.9, range: 4, skill: { kind: 'damage', every: 4, power: 1.8 } },
  { id: 15, name: '蛮族勇士', cost: 2, race: 'barbarian', class: 'blade', hp: 700, atk: 55, atkSpeed: 0.7, range: 1.5, skill: { kind: 'damage', every: 4, power: 2.0 } },
  { id: 16, name: '神官', cost: 2, race: 'frost', class: 'priest', hp: 580, atk: 44, atkSpeed: 0.65, range: 1.5, skill: { kind: 'heal-all', every: 3, power: 1.0 } },
  { id: 17, name: '猎手', cost: 2, race: 'warmonger', class: 'marksman', hp: 540, atk: 58, atkSpeed: 0.95, range: 4, skill: { kind: 'damage', every: 4, power: 1.9 } },
  { id: 18, name: '影武者', cost: 2, race: 'shadow', class: 'assassin', hp: 560, atk: 60, atkSpeed: 1.0, range: 1.5, skill: { kind: 'damage', every: 4, power: 2.1 } },
  // ── 3 费 ────────────────────────────────────────────────────────────
  { id: 19, name: '冰霜巨龙', cost: 3, race: 'frost', class: 'mage', hp: 800, atk: 70, atkSpeed: 0.7, range: 1.5, skill: { kind: 'damage', every: 4, power: 2.2, aoe: true } },
  { id: 20, name: '战神之王', cost: 3, race: 'warmonger', class: 'blade', hp: 900, atk: 80, atkSpeed: 0.75, range: 1.5, skill: { kind: 'damage', every: 4, power: 2.4 } },
  { id: 21, name: '暗影领主', cost: 3, race: 'shadow', class: 'mage', hp: 760, atk: 78, atkSpeed: 0.7, range: 1.5, skill: { kind: 'damage', every: 4, power: 2.5 } },
  { id: 22, name: '星灵女王', cost: 3, race: 'stellar', class: 'marksman', hp: 700, atk: 74, atkSpeed: 1.0, range: 4, skill: { kind: 'damage', every: 4, power: 1.8 } },
  { id: 23, name: '蛮族之王', cost: 3, race: 'barbarian', class: 'guardian', hp: 1100, atk: 60, atkSpeed: 0.55, range: 1.5, skill: { kind: 'damage', every: 4, power: 2.0 } },
  { id: 24, name: '大主教', cost: 3, race: 'stellar', class: 'priest', hp: 780, atk: 52, atkSpeed: 0.6, range: 1.5, skill: { kind: 'heal-all', every: 3, power: 1.3 } },
] as const

/** All trait definitions (races first, then classes, in display order). */
export const TRAITS: readonly TraitDef[] = [
  { id: 'frost', kind: 'race', name: '冰裔', tiers: [
    { threshold: 2, desc: '冰裔生命上限+15%', effect: { hpPct: 0.15, scope: 'self' } },
    { threshold: 4, desc: '冰裔生命上限+35%', effect: { hpPct: 0.35, scope: 'self' } },
  ] },
  { id: 'shadow', kind: 'race', name: '暗影', tiers: [
    { threshold: 2, desc: '暗影攻击力+20%', effect: { atkPct: 0.2, scope: 'self' } },
    { threshold: 4, desc: '暗影攻击力+45%', effect: { atkPct: 0.45, scope: 'self' } },
  ] },
  { id: 'warmonger', kind: 'race', name: '战神', tiers: [
    { threshold: 2, desc: '战神攻速+15%', effect: { atkSpeedPct: 0.15, scope: 'self' } },
    { threshold: 4, desc: '战神攻速+35%', effect: { atkSpeedPct: 0.35, scope: 'self' } },
  ] },
  { id: 'stellar', kind: 'race', name: '星灵', tiers: [
    { threshold: 2, desc: '星灵技能伤害+25%', effect: { skillPct: 0.25, scope: 'self' } },
    { threshold: 3, desc: '星灵技能伤害+50%', effect: { skillPct: 0.5, scope: 'self' } },
  ] },
  { id: 'barbarian', kind: 'race', name: '蛮族', tiers: [
    { threshold: 2, desc: '蛮族生命上限+20%、攻击力+10%', effect: { hpPct: 0.2, atkPct: 0.1, scope: 'self' } },
    { threshold: 4, desc: '蛮族生命上限+40%、攻击力+25%', effect: { hpPct: 0.4, atkPct: 0.25, scope: 'self' } },
  ] },
  { id: 'mage', kind: 'class', name: '法师', tiers: [
    { threshold: 2, desc: '法师技能伤害+25%', effect: { skillPct: 0.25, scope: 'self' } },
    { threshold: 4, desc: '法师技能伤害+60%', effect: { skillPct: 0.6, scope: 'self' } },
  ] },
  { id: 'blade', kind: 'class', name: '剑士', tiers: [
    { threshold: 2, desc: '剑士攻击力+25%', effect: { atkPct: 0.25, scope: 'self' } },
    { threshold: 4, desc: '剑士攻击力+50%', effect: { atkPct: 0.5, scope: 'self' } },
  ] },
  { id: 'marksman', kind: 'class', name: '射手', tiers: [
    { threshold: 2, desc: '射手攻速+20%', effect: { atkSpeedPct: 0.2, scope: 'self' } },
    { threshold: 4, desc: '射手攻速+45%', effect: { atkSpeedPct: 0.45, scope: 'self' } },
  ] },
  { id: 'guardian', kind: 'class', name: '守卫', tiers: [
    { threshold: 2, desc: '守卫生命上限+200', effect: { hpFlat: 200, scope: 'self' } },
    { threshold: 4, desc: '守卫生命上限+500', effect: { hpFlat: 500, scope: 'self' } },
  ] },
  { id: 'assassin', kind: 'class', name: '刺客', tiers: [
    { threshold: 2, desc: '刺客暴击率+30%', effect: { critPct: 0.3, scope: 'self' } },
    { threshold: 4, desc: '刺客暴击率+60%', effect: { critPct: 0.6, scope: 'self' } },
  ] },
  { id: 'priest', kind: 'class', name: '牧师', tiers: [
    { threshold: 2, desc: '全体友方生命上限+10%', effect: { hpPct: 0.1, scope: 'all' } },
    { threshold: 3, desc: '全体友方生命上限+20%', effect: { hpPct: 0.2, scope: 'all' } },
  ] },
] as const

/** Shop cost odds per level: [1费, 2费, 3费]. */
export const SHOP_ODDS: readonly (readonly [number, number, number])[] = [
  [1.0, 0.0, 0.0], // level 1
  [0.7, 0.3, 0.0], // level 2
  [0.5, 0.4, 0.1], // level 3
  [0.35, 0.45, 0.2], // level 4
  [0.25, 0.45, 0.3], // level 5
  [0.15, 0.45, 0.4], // level 6
  [0.1, 0.4, 0.5], // level 7
  [0.05, 0.35, 0.6], // level 8
] as const

/** Experience needed to advance from `level` to `level + 1`. */
export function expNeeded(level: number): number {
  return level + 2
}

/** Look a unit definition up by pool id. */
export function unitDef(defId: number): UnitDef | undefined {
  return UNIT_POOL.find(def => def.id === defId) as UnitDef | undefined
}

/** Star stat scale (2★ ≈ 1.8×, 3★ ≈ 3.24× of the 1★ base). */
export function starScale(star: Star): number {
  return star === 1 ? 1 : star === 2 ? 1.8 : 3.24
}

/** Build a concrete unit instance from a pool definition. */
export function makeUnit(def: UnitDef, star: Star, id: number): ChessUnit {
  const scale = starScale(star)
  const hp = Math.round(def.hp * scale)
  return {
    id,
    defId: def.id,
    name: def.name,
    cost: def.cost,
    star,
    race: def.race,
    class: def.class,
    hp,
    maxHp: hp,
    atk: Math.round(def.atk * scale),
    atkSpeed: def.atkSpeed,
    range: def.range,
    skill: { ...def.skill },
  }
}

/** Roll one shop of SHOP_SIZE distinct units for a level. */
export function rollShop(level: number, rng: Rng): ShopEntry[] {
  const odds = SHOP_ODDS[Math.max(1, Math.min(level, MAX_LEVEL)) - 1]!
  const pick = (): UnitDef => {
    const roll = rng()
    let acc = 0
    let cost = 1
    for (let i = 0; i < odds.length; i += 1) {
      acc += odds[i]!
      if (roll < acc) {
        cost = i + 1
        break
      }
    }
    const candidates = UNIT_POOL.filter(def => def.cost === cost)
    return candidates[Math.floor(rng() * candidates.length)]!
  }
  const shop: ShopEntry[] = []
  let guard = 0
  while (shop.length < SHOP_SIZE && guard < 200) {
    guard += 1
    const entry = pick()
    if (shop.some(existing => existing.defId === entry.id)) continue
    shop.push({ defId: entry.id, name: entry.name, cost: entry.cost, race: entry.race, class: entry.class })
  }
  return shop
}

/** Fresh game state (round 1, both sides at 100 HP / 6 gold / level 1). */
export function freshGame(seed = 1): GameState {
  const makeSide = (side: 1 | 2): SideState => ({
    side,
    hp: START_HP,
    gold: START_GOLD,
    level: 1,
    exp: 0,
    bench: [],
    board: new Array<ChessUnit | null>(BOARD_CELLS).fill(null),
    shop: [],
    winStreak: 0,
    lossStreak: 0,
    lastResult: null,
    lastSurvivors: 0,
  })
  const state: GameState = {
    round: 1,
    sides: [makeSide(1), makeSide(2)],
    nextUnitId: 1,
    seed: seed >>> 0,
    history: [],
    over: false,
    winner: null,
  }
  const rng = mulberry32(state.seed)
  state.sides[0]!.shop = rollShop(state.sides[0]!.level, rng)
  state.sides[1]!.shop = rollShop(state.sides[1]!.level, rng)
  return state
}

/** Deep-clone a game state (the wire shape is JSON-safe). */
export function cloneGameState(state: GameState): GameState {
  return JSON.parse(JSON.stringify(state)) as GameState
}

/** Number of units currently deployed by a side. */
export function boardCount(side: SideState): number {
  return side.board.filter(unit => unit !== null).length
}

/** Whether a cell index is inside the 4×7 board. */
export function inBoard(row: number, col: number): boolean {
  return row >= 0 && row < ROWS && col >= 0 && col < COLS
}

/** Cell index for a [row, col] pair. */
export function cellIndex(row: number, col: number): number {
  return row * COLS + col
}

/* ------------------------------------------------------------------ *
 * Trait (synergy) computation — deployed units only
 * ------------------------------------------------------------------ */

/** Per-trait deployed counts of a side. */
export function traitCounts(side: SideState): Map<RaceId | ClassId, number> {
  const counts = new Map<RaceId | ClassId, number>()
  for (const unit of side.board) {
    if (unit === null) continue
    counts.set(unit.race, (counts.get(unit.race) ?? 0) + 1)
    counts.set(unit.class, (counts.get(unit.class) ?? 0) + 1)
  }
  return counts
}

/** The traits of a side whose threshold is met, with the met tier. */
export function activeTraits(side: SideState): { trait: TraitDef; tier: TraitDef['tiers'][number] }[] {
  const counts = traitCounts(side)
  const active: { trait: TraitDef; tier: TraitDef['tiers'][number] }[] = []
  for (const trait of TRAITS) {
    const count = counts.get(trait.id) ?? 0
    let met: TraitDef['tiers'][number] | undefined
    for (const tier of trait.tiers) {
      if (count >= tier.threshold) met = tier
    }
    if (met !== undefined) active.push({ trait, tier: met })
  }
  return active
}

/** Per-unit battle stat bonuses from the deployed traits of a side. */
export function traitEffectsForBoard(board: readonly (ChessUnit | null)[]): Map<number, TraitEffect> {
  const effects = new Map<number, TraitEffect>()
  const side = { board: [...board] } as SideState
  const active = activeTraits(side)
  for (const unit of board) {
    if (unit === null) continue
    const merged: TraitEffect = { scope: 'self' }
    for (const { trait, tier } of active) {
      const apply = trait.kind === 'race'
        ? tier.effect.scope === 'all' || unit.race === trait.id
        : tier.effect.scope === 'all' || unit.class === trait.id
      if (!apply) continue
      merged.hpPct = (merged.hpPct ?? 0) + (tier.effect.hpPct ?? 0)
      merged.atkPct = (merged.atkPct ?? 0) + (tier.effect.atkPct ?? 0)
      merged.atkSpeedPct = (merged.atkSpeedPct ?? 0) + (tier.effect.atkSpeedPct ?? 0)
      merged.skillPct = (merged.skillPct ?? 0) + (tier.effect.skillPct ?? 0)
      merged.critPct = (merged.critPct ?? 0) + (tier.effect.critPct ?? 0)
      merged.hpFlat = (merged.hpFlat ?? 0) + (tier.effect.hpFlat ?? 0)
      merged.scope = 'self'
    }
    if (merged.hpPct !== undefined || merged.atkPct !== undefined || merged.atkSpeedPct !== undefined
      || merged.skillPct !== undefined || merged.critPct !== undefined || merged.hpFlat !== undefined) {
      effects.set(unit.id, merged)
    }
  }
  return effects
}

/** Rough power estimate of a side's board (cost × star summed). */
export function estimatedPower(side: SideState): number {
  let power = 0
  for (const unit of side.board) {
    if (unit !== null) power += unit.cost * unit.star
  }
  return power
}

/* ------------------------------------------------------------------ *
 * Prep actions
 * ------------------------------------------------------------------ */

/** Locate a unit by id; returns its location. */
export function findUnit(side: SideState, id: number): { where: 'bench' | 'board'; index: number } | null {
  const benchIndex = side.bench.findIndex(unit => unit.id === id)
  if (benchIndex !== -1) return { where: 'bench', index: benchIndex }
  const boardIndex = side.board.findIndex(unit => unit?.id === id)
  if (boardIndex !== -1) return { where: 'board', index: boardIndex }
  return null
}

/** Merge triples of identical name+star units (bench first, then board in cell order). */
function mergeStars(state: GameState, side: SideState): void {
  for (;;) {
    const counts = new Map<string, number>()
    const collect = (unit: ChessUnit): void => {
      const key = `${unit.name}|${unit.star}`
      counts.set(key, (counts.get(key) ?? 0) + 1)
    }
    for (const unit of side.bench) collect(unit)
    for (const unit of side.board) if (unit !== null) collect(unit)
    let targetKey: string | undefined
    for (const [key, count] of counts) {
      if (count >= 3) {
        targetKey = key
        break
      }
    }
    if (targetKey === undefined) return
    const [name, starText] = targetKey.split('|')
    const star = Number(starText) as Star
    if (star >= 3) return
    const def = UNIT_POOL.find(candidate => candidate.name === name)
    if (def === undefined) return
    let removed = 0
    // The merged unit keeps the id of the LAST consumed unit — normally the
    // one the player just bought — so a buy-then-move plan stays valid: ids
    // in the framed state never silently move to a brand-new number.
    let keptId: number | undefined
    const consume = (unit: ChessUnit): boolean => {
      if (unit.name !== name || unit.star !== star) return false
      keptId = unit.id
      return true
    }
    side.bench = side.bench.filter(unit => {
      if (removed < 3 && consume(unit)) {
        removed += 1
        return false
      }
      return true
    })
    for (let index = 0; index < side.board.length && removed < 3; index += 1) {
      const unit = side.board[index]
      if (unit !== null && consume(unit)) {
        side.board[index] = null
        removed += 1
      }
    }
    side.bench.push(makeUnit(def, (star + 1) as Star, keptId ?? state.nextUnitId))
    if (keptId === undefined) state.nextUnitId += 1
  }
}

/**
 * Apply one prep action to a side, mutating the state. Returns an error
 * string when the action is illegal; `undefined` on success. The whole
 * action list of an AI decision is validated by applying every action to a
 * clone — any failure rejects the batch and triggers corrective feedback.
 */
export function applyAction(state: GameState, side: 1 | 2, action: ChessAction): string | undefined {
  const player = state.sides[side - 1]!
  switch (action.action) {
    case 'buy': {
      const entry = player.shop.find(candidate => candidate.name === action.name)
      if (entry === undefined) return `商店中没有名为「${action.name}」的棋子`
      if (player.gold < entry.cost) return `金币不足（购买「${entry.name}」需要 ${entry.cost}，当前 ${player.gold}）`
      if (player.bench.length >= BENCH_CAP) return `备战区已满（上限 ${BENCH_CAP}）`
      const def = unitDef(entry.defId)
      if (def === undefined) return `未知棋子「${entry.name}」`
      player.gold -= entry.cost
      player.bench.push(makeUnit(def, 1, state.nextUnitId))
      state.nextUnitId += 1
      mergeStars(state, player)
      return undefined
    }
    case 'sell': {
      const found = findUnit(player, action.chess_id)
      if (found === null) return `未找到棋子（chess_id: ${action.chess_id}）`
      const unit = found.where === 'bench' ? player.bench[found.index]! : player.board[found.index]!
      const refund = unit.cost + (unit.star - 1) * 2
      if (found.where === 'bench') player.bench.splice(found.index, 1)
      else player.board[found.index] = null
      player.gold += refund
      return undefined
    }
    case 'move': {
      const [row, col] = action.pos
      if (!Number.isInteger(row) || !Number.isInteger(col) || !inBoard(row, col)) {
        return `目标位置越界：[${row}, ${col}]（范围 0-${ROWS - 1} 行、0-${COLS - 1} 列）`
      }
      const index = cellIndex(row, col)
      const found = findUnit(player, action.chess_id)
      if (found === null) return `未找到棋子（chess_id: ${action.chess_id}）`
      const occupant = player.board[index]
      if (occupant !== null) {
        return occupant.id === action.chess_id ? undefined : `目标位置已被占用：[${row}, ${col}]`
      }
      const unit = found.where === 'bench' ? player.bench[found.index]! : player.board[found.index]!
      if (found.where === 'bench') {
        if (boardCount(player) >= player.level) return `上场棋子数已达上限（当前等级 ${player.level}）`
        player.bench.splice(found.index, 1)
      } else {
        player.board[found.index] = null
      }
      player.board[index] = unit
      return undefined
    }
    case 'upgrade': {
      if (player.gold < UPGRADE_COST) return `金币不足（购买经验需要 ${UPGRADE_COST}，当前 ${player.gold}）`
      player.gold -= UPGRADE_COST
      player.exp += UPGRADE_EXP
      while (player.level < MAX_LEVEL && player.exp >= expNeeded(player.level)) {
        player.exp -= expNeeded(player.level)
        player.level += 1
      }
      return undefined
    }
    case 'refresh': {
      if (player.gold < REFRESH_COST) return `金币不足（刷新商店需要 ${REFRESH_COST}，当前 ${player.gold}）`
      player.gold -= REFRESH_COST
      player.shop = rollShop(player.level, mulberry32(state.seed ^ player.side))
      return undefined
    }
    case 'end_prep':
      return undefined
    /* v8 ignore next -- closed-union exhaustiveness guard */
    default:
      return '未知操作'
  }
}

/** The income a side would receive at the next settlement. */
export function incomePreview(side: SideState): { base: number; interest: number; streak: number; win: number; total: number } {
  const interest = Math.min(Math.floor(side.gold / 10), INTEREST_CAP)
  const longest = Math.max(side.winStreak, side.lossStreak)
  const streak = longest >= 6 ? 3 : longest >= 4 ? 2 : longest >= 2 ? 1 : 0
  const win = side.lastResult === 'win' ? WIN_BONUS : 0
  return {
    base: BASE_INCOME,
    interest,
    streak,
    win,
    total: BASE_INCOME + interest + streak + win,
  }
}

/* ------------------------------------------------------------------ *
 * Battle simulation
 * ------------------------------------------------------------------ */

/** One unit inside the battle simulation (trait bonuses already applied). */
export interface CombatUnit {
  uid: number
  side: 1 | 2
  name: string
  star: Star
  row: number
  col: number
  hp: number
  maxHp: number
  atk: number
  atkSpeed: number
  range: number
  crit: number
  skillPower: number
  skill: SkillDef
  attacks: number
  timer: number
  alive: boolean
}

/** One unit's visual snapshot at one tick. */
export interface BattleSnapshotUnit {
  uid: number
  side: 1 | 2
  name: string
  star: Star
  row: number
  col: number
  hp: number
  maxHp: number
}

/** One battle tick: unit snapshots plus events of that tick. */
export interface BattleTick {
  units: BattleSnapshotUnit[]
  events: string[]
}

/** The full battle result including the replay. */
export interface BattleResult {
  winner: 1 | 2 | 0
  /** Winner's surviving units (0 on a draw). */
  survivors: number
  /** HP the loser loses. */
  damage: number
  /** Per-tick replay (index 0 = the opening formation). */
  ticks: BattleTick[]
}

/** Build combat units for one side from its board (mirrored for side 2). */
function combatUnitsOf(side: 1 | 2, board: readonly (ChessUnit | null)[], effects: Map<number, TraitEffect>): CombatUnit[] {
  const units: CombatUnit[] = []
  for (let index = 0; index < board.length; index += 1) {
    const unit = board[index]
    if (unit === null) continue
    const row = Math.floor(index / COLS)
    const col = index % COLS
    const effect = effects.get(unit.id)
    const hpPct = effect?.hpPct ?? 0
    const atkPct = effect?.atkPct ?? 0
    const speedPct = effect?.atkSpeedPct ?? 0
    const skillPct = effect?.skillPct ?? 0
    const critPct = effect?.critPct ?? 0
    const hpFlat = effect?.hpFlat ?? 0
    const hp = Math.round(unit.hp * (1 + hpPct)) + hpFlat
    units.push({
      uid: unit.id,
      side,
      name: unit.name,
      star: unit.star,
      row,
      col: side === 1 ? col : FIELD_COLS - 1 - col,
      hp,
      maxHp: hp,
      atk: unit.atk * (1 + atkPct),
      atkSpeed: unit.atkSpeed * (1 + speedPct),
      range: unit.range,
      crit: critPct,
      skillPower: 1 + skillPct,
      skill: unit.skill,
      attacks: 0,
      timer: 0,
      alive: true,
    })
  }
  return units
}

/** Squared distance between two combat units (field coordinates). */
function distanceSq(a: CombatUnit, b: CombatUnit): number {
  const dr = a.row - b.row
  const dc = a.col - b.col
  return dr * dr + dc * dc
}

/** The nearest living enemy of one combat unit, or null. */
function nearestEnemy(unit: CombatUnit, enemies: readonly CombatUnit[]): CombatUnit | null {
  let best: CombatUnit | null = null
  let bestD = Infinity
  for (const enemy of enemies) {
    if (!enemy.alive) continue
    const d = distanceSq(unit, enemy)
    if (d < bestD) {
      bestD = d
      best = enemy
    }
  }
  return best
}

/** Star label for battle events. */
function starLabel(star: Star): string {
  return `${star}星`
}

/**
 * Simulate the battle between the two deployed boards. Pure: reads the
 * state, returns the replay; never mutates it. The RNG (crit rolls) comes
 * from the state's seed, so identical states produce identical battles.
 */
export function simulateBattle(state: GameState): BattleResult {
  const rng = mulberry32(state.seed)
  const effects1 = traitEffectsForBoard(state.sides[0]!.board)
  const effects2 = traitEffectsForBoard(state.sides[1]!.board)
  const units = [
    ...combatUnitsOf(1, state.sides[0]!.board, effects1),
    ...combatUnitsOf(2, state.sides[1]!.board, effects2),
  ]
  const snapshot = (): BattleTick => ({
    units: units.filter(unit => unit.alive).map(unit => ({
      uid: unit.uid,
      side: unit.side,
      name: unit.name,
      star: unit.star,
      row: unit.row,
      col: Math.round(unit.col * 2) / 2,
      hp: Math.max(0, Math.round(unit.hp)),
      maxHp: unit.maxHp,
    })),
    events: [],
  })

  const ticks: BattleTick[] = [snapshot()]
  const aliveOf = (side: 1 | 2): number => units.reduce((count, unit) => count + (unit.alive && unit.side === side ? 1 : 0), 0)

  for (let tickIndex = 0; tickIndex < MAX_TICKS; tickIndex += 1) {
    const events: string[] = []
    const side1Alive = aliveOf(1)
    const side2Alive = aliveOf(2)
    if (side1Alive === 0 || side2Alive === 0) break

    // Units act in stable order (side, then uid) so the replay is identical
    // for identical states.
    for (const unit of [...units].sort((a, b) => a.side - b.side || a.uid - b.uid)) {
      if (!unit.alive) continue
      const enemies = units.filter(candidate => candidate.side !== unit.side && candidate.alive)
      if (enemies.length === 0) continue
      const target = nearestEnemy(unit, enemies)
      if (target === null) continue
      const distSq = distanceSq(unit, target)
      if (distSq <= unit.range * unit.range) {
        unit.timer -= TICK_SEC
        if (unit.timer > 0) continue
        unit.timer = Math.max(1 / unit.atkSpeed, 0.25)
        unit.attacks += 1
        const isSkill = unit.skill.every > 0 && unit.attacks % unit.skill.every === 0
        if (isSkill) {
          if (unit.skill.kind === 'heal-all') {
            const heal = unit.atk * unit.skill.power
            for (const ally of units) {
              if (ally.side === unit.side && ally.alive) ally.hp = Math.min(ally.maxHp, ally.hp + heal)
            }
            events.push(`${unit.name}（${starLabel(unit.star)}）施放治疗，为全体友方恢复 ${Math.round(heal)} 生命`)
          } else {
            const damage = unit.atk * unit.skill.power * unit.skillPower
            const targets = unit.skill.aoe === true
              ? enemies.filter(enemy => distanceSq(unit, enemy) <= unit.range * unit.range || distanceSq(target, enemy) <= 2.25)
              : [target]
            const killed: string[] = []
            for (const enemy of targets) {
              enemy.hp -= damage
              if (enemy.hp <= 0 && enemy.alive) killed.push(enemy.name)
            }
            const hits = targets.map(enemy => enemy.name).join('、')
            events.push(`${unit.name}（${starLabel(unit.star)}）发动技能，对${hits}造成 ${Math.round(damage)} 伤害${killed.length > 0 ? `，击败了${killed.join('、')}` : ''}`)
          }
        } else {
          const damage = unit.atk * (rng() < unit.crit ? 1.5 : 1)
          target.hp -= damage
          if (target.hp <= 0 && target.alive) {
            events.push(`${unit.name}（${starLabel(unit.star)}）击败了${target.name}（${starLabel(target.star)}）`)
          }
        }
      } else {
        // Advance toward the target's column (rows stay fixed).
        const step = Math.sign(target.col - unit.col) * MOVE_PER_TICK
        unit.col = Math.min(FIELD_COLS - 1, Math.max(0, unit.col + step))
      }
    }
    for (const unit of units) {
      if (unit.alive && unit.hp <= 0) unit.alive = false
    }
    const tick: BattleTick = snapshot()
    tick.events = events
    ticks.push(tick)
  }

  const survivors1 = aliveOf(1)
  const survivors2 = aliveOf(2)
  let winner: 1 | 2 | 0 = 0
  let survivors = 0
  if (survivors1 > 0 && survivors2 === 0) {
    winner = 1
    survivors = survivors1
  } else if (survivors2 > 0 && survivors1 === 0) {
    winner = 2
    survivors = survivors2
  } else if (survivors1 === 0 && survivors2 === 0) {
    winner = 0
    survivors = 0
  } else {
    // Timeout: the side with more living units wins.
    if (survivors1 > survivors2) {
      winner = 1
      survivors = survivors1
    } else if (survivors2 > survivors1) {
      winner = 2
      survivors = survivors2
    } else {
      winner = 0
      survivors = 0
    }
  }
  return {
    winner,
    survivors,
    damage: winner === 0 ? 0 : survivors * DAMAGE_PER_SURVIVOR,
    ticks,
  }
}

/* ------------------------------------------------------------------ *
 * Settlement
 * ------------------------------------------------------------------ */

/**
 * Apply a battle result: HP damage, streaks, income, round advance, shop
 * rerolls, and the game-over check. Mutates the state; advances the battle
 * seed so the next battle's crit rolls differ.
 */
export function settleRound(state: GameState, result: BattleResult): void {
  const winner = result.winner
  if (winner === 1 || winner === 2) {
    const loser = state.sides[winner === 1 ? 1 : 0]!
    const winnerSide = state.sides[winner - 1]!
    loser.hp = Math.max(0, loser.hp - result.damage)
    loser.lastResult = 'loss'
    loser.lastSurvivors = 0
    winnerSide.lastResult = 'win'
    winnerSide.lastSurvivors = result.survivors
    winnerSide.winStreak += 1
    loser.lossStreak += 1
    state.history.push({ round: state.round, winner, survivors: result.survivors, damage: result.damage })
  } else {
    state.sides[0]!.lastResult = 'draw'
    state.sides[1]!.lastResult = 'draw'
    state.sides[0]!.lastSurvivors = 0
    state.sides[1]!.lastSurvivors = 0
    state.history.push({ round: state.round, winner: 0, survivors: 0, damage: 0 })
  }
  for (const side of state.sides) {
    const preview = incomePreview(side)
    side.gold += preview.total
    side.shop = rollShop(side.level, mulberry32(state.seed ^ side.side))
  }
  state.round += 1
  state.seed = (state.seed * 1103515245 + 12345) >>> 0
  if (state.sides[0]!.hp <= 0) {
    state.over = true
    state.winner = 2
  } else if (state.sides[1]!.hp <= 0) {
    state.over = true
    state.winner = 1
  }
}
