/**
 * Prompt framing for AI prep decisions: the default system prompt (rules,
 * strict return format, worked examples) and the user-message assembler
 * that renders one side's game state into the structured state text the
 * model decides from. Shared by the node half (per-request framing) and the
 * tests; the browser half only stores the custom prompt text and sends it
 * back verbatim.
 * @module dsh-auto-chess/game/prompt
 */

import {
  BENCH_CAP, COLS, DAMAGE_PER_SURVIVOR, INTEREST_CAP, MAX_ACTIONS, MAX_LEVEL,
  REFRESH_COST, ROWS, SHOP_SIZE, START_HP, TRAITS, UPGRADE_COST, UPGRADE_EXP,
  activeTraits, boardCount, expNeeded, estimatedPower, traitCounts, traitName,
  type ChessAction, type GameState, type SideState, type Star,
} from './engine.ts'

/**
 * The default system prompt: the full minimal-auto-chess rule surface
 * (board, units, star merging, traits with thresholds and effects, shop and
 * economy, battle and damage), the strict JSON-array return format, a
 * correct worked example, and an explicit wrong example. Users may edit
 * this text in the browser half; the edited text replaces it verbatim per
 * action request.
 */
export const DEFAULT_SYSTEM_PROMPT = [
  '你是《简化自走棋》的一名玩家。请根据给定的局面，为你控制的阵营做出准备阶段的操作决策，并严格按照规定的 JSON 格式返回操作数组。',
  '',
  '# 游戏规则',
  `- 你与对手各控制一个阵营（蓝方/红方），初始生命值 ${START_HP}。每回合分为「准备阶段 → 自动战斗 → 结算」。`,
  `- 战斗自动进行：棋子自动索敌、移动、攻击，每累计一定次数攻击会触发技能。失败方按对方存活棋子数 ×${DAMAGE_PER_SURVIVOR} 扣除生命值，生命归零即输。`,
  `- 每个回合你最多可以执行 ${MAX_ACTIONS} 个操作（买棋、卖棋、布阵、购买经验、刷新商店、结束准备）。`,
  '',
  '# 棋盘',
  `- 你的布阵区域是 ${ROWS} 行 × ${COLS} 列，坐标写作 [row, col]（row 为 0-${ROWS - 1}，col 为 0-${COLS - 1}）。`,
  `- 上场棋子数不能超过你的等级；备战区（未上场的棋子）上限 ${BENCH_CAP} 个。`,
  '',
  '# 棋子',
  '- 棋子分为 1 费、2 费、3 费。每颗棋子有生命（hp）、攻击力（atk）、攻速（每秒攻击次数）、攻击距离、种族、职业与技能。',
  '- 星阶：3 个同名同星棋子自动合成为 1 个更高星棋子（一星→二星→三星）。二星属性约为一星的 1.8 倍，三星约为 3.24 倍。',
  '- 合成会统计备战区与棋盘上所有的同名同星棋子，所以棋子上场不会影响后续合成。',
  '- 技能：每个棋子每累计 N 次攻击都会触发一次技能（造成技能伤害或治疗友方）。',
  '- 棋子 id：以局面文本中最新给出的 id 为准。购买触发合成后，被合成的旧棋子会消失，合成后的棋子保留「最后被消耗那颗」的 id（通常就是你刚买入的那颗）；因此批量操作中，先买后布阵时请使用刚买入棋子的 id，不要使用已被合成消耗的旧 id。',
  '',
  '# 种族与职业（羁绊）',
  '上场棋子的同种族/同职业数量达到阈值时触发加成，只计算已上场棋子，取满足的最高档：',
  ...TRAITS.flatMap(trait => [
    `- ${trait.name}（${trait.kind === 'race' ? '种族' : '职业'}）${trait.tiers.map(tier => `${tier.threshold}：${tier.desc}`).join('，')}`,
  ]),
  '',
  '# 商店与经济',
  `- 商店每回合免费刷新 ${SHOP_SIZE} 颗棋子；主动刷新花费 ${REFRESH_COST} 金币。购买花费棋子费用（1/2/3 金币）。`,
  '- 卖出返还金币：费用 + (星阶-1) × 2（一星卖 1/2/3 金，二星多返 2 金，三星多返 4 金）。',
  `- 每回合结算收入 = 基础 5 + 利息 min(金币÷10, ${INTEREST_CAP}) + 连胜/连败奖励 + 胜利 +1。`,
  '- 连胜/连败奖励：2 连胜起 +1，4 连胜起 +2，6 连胜起 +3（连胜与连败都算）。',
  `- 升级：花费 ${UPGRADE_COST} 金币购买 ${UPGRADE_EXP} 点经验。升级所需经验 = 等级 + 2（例如 4 级升 5 级需要 6 点）。等级提高上场人数上限与高费棋子的刷新概率，等级上限 ${MAX_LEVEL}。`,
  '',
  '# 操作格式（必须严格遵守）',
  `只返回一个 JSON 数组（最多 ${MAX_ACTIONS} 个操作），按顺序执行；不要输出任何思考过程、解释、Markdown 代码块或前后缀（思考会占用输出预算，导致回复被截断）：`,
  '- 购买商店棋子：{"action":"buy", "name":"棋子名"}',
  '- 卖出：{"action":"sell", "chess_id":棋子id}',
  '- 布阵/移动：{"action":"move", "chess_id":棋子id, "pos":[row, col]}',
  '- 购买经验：{"action":"upgrade"}',
  '- 刷新商店：{"action":"refresh"}',
  '- 结束准备：{"action":"end_prep"}（建议放在最后一个操作）',
  '- 若不想执行任何操作，直接返回 [{"action":"end_prep"}]',
  '',
  '# 正确案例',
  '局面：你金币 12，等级 4，备战区已有 2 个「冰女」，商店里有「冰女」和「剑圣」，你想合成二星冰女并把它放到棋盘 (1,3)。',
  '返回：[{"action":"buy","name":"冰女"},{"action":"move","chess_id":6,"pos":[1,3]},{"action":"end_prep"}]',
  '（共 3 个操作，总花费 1 金币，符合数量与预算限制）',
  '',
  '# 错误示范（禁止返回）',
  '"我觉得应该买剑圣。[{"action":"buy","name":"剑圣"}]" —— 带解释的文字不是合法输出；',
  '{"action":"buy","name":"剑圣"} —— 必须是数组，不能是单个对象；',
  `操作数超过 ${MAX_ACTIONS} 个时，只执行前 ${MAX_ACTIONS} 个（多余的会被忽略）；总花费超过金币、买入商店里没有的棋子、把棋子移动到已占用的格子等，会导致整批操作被拒绝，你会收到纠正提示并重新决策。`,
  '',
  '# 基本策略',
  '1. 只要还有上场名额（已上场数 < 等级）且备战区有棋子，就必须用 move 把棋子上场：上场不会影响星阶合成（合成统计备战区与棋盘上的同名同星棋子），还能腾出备战区空位；空位优先放能触发羁绊或高星的棋子。',
  '2. 优先凑同种族/同职业羁绊（例如 2 冰裔、2 法师），并让触发羁绊的棋子上场。',
  '3. 购买同名同星棋子合成高星；2 费、3 费核心棋子值得重点培养。',
  '4. 守卫/坦克放前排（靠敌方一侧，col 4-6），射手/法师/刺客等输出放后排（col 0-2）。',
  '5. 金币低于 10 时慎重刷新商店（每 10 金币可多拿 1 利息，上限 5）。',
  '6. 有足够金币时优先购买经验升级，扩大上场人数。',
  '7. 凑不齐羁绊的废棋可以卖掉换经济（卖出会返还金币）。',
].join('\n')

/** One shop entry in the compact wire shape the prompt describes. */
interface BenchWire {
  id: number
  name: string
  cost: number
  star: Star
  hp: number
  atk: number
  race: string
  class: string
}

/** One board placement in the prompt's wire shape. */
interface BoardWire {
  pos: [number, number]
  id: number
  name: string
  star: Star
}

/** The deployed-unit scout line: count, star breakdown, trait counts, power estimate. */
export function enemyScoutText(enemy: SideState): string {
  const units = enemy.board.filter(unit => unit !== null)
  const count = units.length
  if (count === 0) return '对手未上场任何棋子。'
  const star2 = units.filter(unit => unit!.star === 2).length
  const star3 = units.filter(unit => unit!.star === 3).length
  const breakdown: string[] = []
  if (star2 > 0) breakdown.push(`${star2}个二星`)
  if (star3 > 0) breakdown.push(`${star3}个三星`)
  const parts: string[] = []
  const counts = traitCounts(enemy)
  for (const trait of TRAITS) {
    const value = counts.get(trait.id) ?? 0
    if (value > 0) parts.push(`${value}个「${trait.name}」${trait.kind === 'race' ? '种族' : '职业'}`)
  }
  const active = activeTraits(enemy)
  const hits = active.map(entry => `${entry.tier.threshold}${entry.trait.name}`)
  const hint = hits.length > 0 ? `可能凑成了${hits.join('、')}羁绊` : '尚未触发羁绊'
  return `对手上场${count}个棋子${breakdown.length > 0 ? `（其中${breakdown.join('、')}）` : ''}，包含${parts.join('、')}，${hint}。预估战力约 ${estimatedPower(enemy)}。`
}

/** The last-battle result line for one side. */
export function lastResultText(state: GameState, side: 1 | 2): string {
  const player = state.sides[side - 1]!
  const enemy = state.sides[side === 1 ? 1 : 0]!
  if (player.lastResult === null) return '暂无（第一回合）。'
  if (player.lastResult === 'win') return `你赢了，剩余${player.lastSurvivors}个棋子存活。`
  if (player.lastResult === 'loss') return `你输了，对方剩余${enemy.lastSurvivors}个棋子存活。`
  return '平局。'
}

/** The trait line for the acting side (counts plus triggered thresholds). */
export function traitLine(side: SideState): string {
  const counts = traitCounts(side)
  const active = activeTraits(side)
  const parts: string[] = []
  for (const trait of TRAITS) {
    const count = counts.get(trait.id) ?? 0
    if (count === 0) continue
    const met = active.find(entry => entry.trait.id === trait.id)
    parts.push(met !== undefined ? `${trait.name}×${count}（已触发${met.tier.threshold}${trait.name}：${met.tier.desc}）` : `${trait.name}×${count}（未触发）`)
  }
  return parts.length > 0 ? parts.join('、') : '无'
}

/**
 * Frame the user message for one AI prep decision: the acting side's full
 * state in the structured text format the default prompt describes, plus
 * (on a retry) the previous illegal reply and the rejection reason.
 */
export function buildActionUserMessage(state: GameState, side: 1 | 2, previous?: string, reason?: string): string {
  const player = state.sides[side - 1]!
  const enemy = state.sides[side === 1 ? 1 : 0]!
  const bench: BenchWire[] = player.bench.map(unit => ({
    id: unit.id,
    name: unit.name,
    cost: unit.cost,
    star: unit.star,
    hp: unit.hp,
    atk: unit.atk,
    race: traitName(unit.race),
    class: traitName(unit.class),
  }))
  const board: BoardWire[] = []
  for (let index = 0; index < player.board.length; index += 1) {
    const unit = player.board[index]
    if (unit === null) continue
    board.push({ pos: [Math.floor(index / COLS), index % COLS], id: unit.id, name: unit.name, star: unit.star })
  }
  const shop = player.shop.map(entry => ({
    name: entry.name,
    cost: entry.cost,
    race: traitName(entry.race),
    class: traitName(entry.class),
  }))
  const lines = [
    `你正在玩一场简化自走棋。当前是你的准备阶段（第${state.round}回合）。`,
    `你的生命值: ${player.hp}，对手生命值: ${enemy.hp}。`,
    `你的金币: ${player.gold}，升级所需经验: ${player.exp}/${expNeeded(player.level)}（当前等级${player.level}）。`,
    `你的上场名额: 已上场 ${boardCount(player)} 个 / 上限 ${player.level}（还可上场 ${Math.max(0, player.level - boardCount(player))} 个），备战区有 ${player.bench.length} 个棋子未上场。`,
    `你的当前羁绊: ${traitLine(player)}。`,
    `你的备战区棋子: ${JSON.stringify(bench)}`,
    `棋盘上已布阵: ${JSON.stringify(board)}`,
    `商店刷出棋子: ${JSON.stringify(shop)}`,
    `上一轮战斗结果: ${lastResultText(state, side)}`,
    `对手已知阵容: ${enemyScoutText(enemy)}`,
  ]
  if (previous !== undefined && reason !== undefined) {
    lines.push('', `警告：你上一次的返回不合法（${reason}），完整输出如下：`, previous)
    lines.push('你的上一次操作已被拒绝，局面没有任何变化。请重新观察局面，只返回合法的 JSON 操作数组，不要输出任何思考过程或解释。')
    lines.push('注意：棋子 id 请以局面文本中「你的备战区棋子」「棋盘上已布阵」的 JSON 为准；购买触发合成后旧 id 会消失，请使用最新给出的 id。')
  }
  lines.push('', '请决定你要执行的操作，返回JSON数组，可能的操作包括：',
    '- {"action":"buy", "name":"剑圣"}',
    '- {"action":"sell", "chess_id":6}',
    '- {"action":"move", "chess_id":6, "pos":[1,4]}',
    '- {"action":"upgrade"} (购买经验)',
    '- {"action":"refresh"} (刷新商店，花费2金币)',
    '- {"action":"end_prep"} (结束准备)',
    '',
    `你最多可以执行${MAX_ACTIONS}个操作，但总花费不能超过金币。请保证操作合法。`,
    '若还有上场名额且备战区有棋子，请务必用 move 把棋子上场（备战区棋子不上场就不参与战斗）。',
  )
  return lines.join('\n')
}

/** Human-readable summary of one action (for the reasoning log). */
export function actionLabel(action: ChessAction): string {
  switch (action.action) {
    case 'buy': return `购买「${action.name}」`
    case 'sell': return `卖出#${action.chess_id}`
    case 'move': return `布阵#${action.chess_id}→[${action.pos[0]},${action.pos[1]}]`
    case 'upgrade': return '购买经验'
    case 'refresh': return '刷新商店'
    case 'end_prep': return '结束准备'
    /* v8 ignore next -- closed-union exhaustiveness guard */
    default: return String(action)
  }
}
