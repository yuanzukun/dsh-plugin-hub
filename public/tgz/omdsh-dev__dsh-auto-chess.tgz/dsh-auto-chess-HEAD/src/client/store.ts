/**
 * Auto-chess browser-half store: module-level game/settings state plus the
 * AI prep lifecycle and the battle replay clock. Living outside React means
 * the conversation view can unmount (tab switches, session switches)
 * without resetting the game or interrupting an in-flight AI decision — the
 * game and AI thinking continue in the background. The view subscribes via
 * useSyncExternalStore.
 *
 * The authoritative game state lives here (the node half only validates AI
 * actions against a clone), so the human's clicks and the AI's accepted
 * actions both commit through the same engine.
 */
import {
  applyAction, freshGame, simulateBattle, settleRound,
  type BattleResult, type ChessAction, type GameState,
} from '../game/engine.ts'
import { actionLabel } from '../game/prompt.ts'

/** One entry in the per-decision reasoning log. */
export interface ReasoningEntry {
  /** Decision counter (1-based, across the whole game). */
  n: number
  /** The round this decision belongs to. */
  round: number
  /** The side that decided. */
  side: 1 | 2
  /** Human-readable action summary. */
  actions: string
  /** The model's reasoning text for this decision. */
  reasoning: string
  /** The failure message when the decision did not produce actions. */
  error?: string
  /** True when the request was cut off (aborted/timed out) mid-thought. */
  interrupted?: boolean
  /** The last illegal reply (carried into a client retry for feedback). */
  lastText?: string
  /** The rejection reason of the last reply (carried into a client retry). */
  lastReason?: string
}

/** The battle replay view state (driven by a store-owned clock). */
export interface BattleView {
  result: BattleResult
  /** The tick currently shown. */
  tick: number
  /** True when the replay reached its final tick. */
  done: boolean
}

/** The playable game state (engine state + phase + decision log). */
export interface GameViewState {
  game: GameState
  /** prep1 = blue's prep, prep2 = red's prep. */
  phase: 'prep1' | 'prep2' | 'battle' | 'settle' | 'over'
  /** True while an AI decision request is in flight. */
  thinking: boolean
  /** The battle replay while phase is battle/settle. */
  battle: BattleView | null
  /** The reasoning log, newest last. */
  log: ReasoningEntry[]
  /** The side whose AI decision failed last (drives the retry button). */
  pendingSide: 1 | 2 | null
}

/** One provider group from the node half's model catalog. */
export interface ModelGroup {
  provider: string
  displayName: string
  models: { id: string; name: string }[]
}

/** One side's model selection (provider route + model id). */
export interface SideModel {
  provider: string | undefined
  model: string | undefined
}

/** The playable modes: human vs AI, or two AIs. */
export type GameMode = 'pvp' | 'ai'

/** The AI thinking level for one action request (wire spelling). */
export type Thinking = 'off' | 'high' | 'max'

/** The settings, kept across tab switches (models, thinking and prompts are per-side). */
export interface SettingsState {
  mode: GameMode
  /** The model used when an AI plays blue (side 1). */
  blueModel: SideModel
  /** The model used when an AI plays red (side 2). */
  redModel: SideModel
  /** The AI thinking level for blue's (side 1) action requests. */
  blueThinking: Thinking
  /** The AI thinking level for red's (side 2) action requests. */
  redThinking: Thinking
  /** Fixed deployment policy (no longer user-editable): per-request deadline, ms. */
  actionTimeoutMs: number
  /** Fixed deployment policy (no longer user-editable): output-token cap. */
  maxActionOutputTokens: number
  /** Custom system prompt for blue's (side 1) AI; undefined uses the node half's default. */
  bluePrompt: string | undefined
  /** Custom system prompt for red's (side 2) AI; undefined uses the node half's default. */
  redPrompt: string | undefined
  groups: ModelGroup[]
  modelsError: string | undefined
}

/** The whole store snapshot the view subscribes to. */
export interface Snapshot {
  game: GameViewState
  settings: SettingsState
}

/** The AI action request wire body (mirrors the node half's validateActionRequest). */
export interface ActionRequest {
  /** Registered provider route key. */
  provider: string
  /** Model id the provider accepts. */
  model: string
  /** The side the AI plays in this request. */
  side: 1 | 2
  /** The authoritative game state at decision time. */
  state: GameState
  /** Custom system prompt; absent falls back to the node half's default. */
  system?: string
  /** AI thinking level; forwarded only when the selected model advertises it. */
  thinking?: Thinking
  /** Per-request deadline override (milliseconds). */
  actionTimeoutMs?: number
  /** Per-request output-token cap override. */
  maxActionOutputTokens?: number
  /** The previous illegal reply, for corrective feedback (client retries). */
  previous?: string
  /** The rejection reason of the previous reply (client retries). */
  reason?: string
}

/** One per-action verdict from the node half. */
export interface ActionVerdictWire {
  action: ChessAction
  ok: boolean
  error?: string
}

/** The AI action reply wire body (actions or a failure). */
export interface ActionResponse {
  /** The accepted actions (all ok when present). */
  actions?: ActionVerdictWire[]
  /** A failure message (validation, AI-reported, or exhausted attempts). */
  error?: string
  /** The model's reasoning text for this decision, when present. */
  reasoning?: string
  /** The last illegal reply (carried into a client retry for feedback). */
  lastText?: string
  /** The rejection reason of the last reply (carried into a client retry). */
  lastReason?: string
}

/** The fresh game view state for a new game. */
function freshGameView(): GameViewState {
  return {
    game: freshGame(),
    phase: 'prep1',
    thinking: false,
    battle: null,
    log: [],
    pendingSide: null,
  }
}

/** The default settings (models fill in from the catalog fetch). */
function freshSettings(): SettingsState {
  return {
    mode: 'pvp',
    blueModel: { provider: undefined, model: undefined },
    redModel: { provider: undefined, model: undefined },
    blueThinking: 'off',
    redThinking: 'off',
    // Deployment-fixed: the timeout and output-token cap no longer have UI
    // inputs; the view sends these values with every request as before.
    actionTimeoutMs: 300_000,
    maxActionOutputTokens: 32_000,
    bluePrompt: undefined,
    redPrompt: undefined,
    groups: [],
    modelsError: undefined,
  }
}

let snapshot: Snapshot = { game: freshGameView(), settings: freshSettings() }
const listeners = new Set<() => void>()
/** Game generation: bumped on every new game; stale async results are dropped. */
let generation = 0
/** Per-request sequence: a settled reply only applies to the request it came from. */
let requestSeq = 0
/** The in-flight decision request's abort handle (cancelled on new game / teardown). */
let abort: AbortController | null = null
/** The battle replay clock (store-owned so tab switches never pause it). */
let battleTimer: number | undefined
/** The settle delay before the next prep phase starts. */
let settleTimer: number | undefined

/** Subscribe to store changes (useSyncExternalStore's subscribe). */
export function subscribe(listener: () => void): () => void {
  listeners.add(listener)
  return () => { listeners.delete(listener) }
}

/** The current stable snapshot (useSyncExternalStore's getSnapshot). */
export function getSnapshot(): Snapshot {
  return snapshot
}

/** Whether the side belongs to an AI in this mode. */
function isAiSide(side: 1 | 2): boolean {
  return snapshot.settings.mode === 'ai' || side === 2
}

/** Publish one game state to all subscribers. */
function commitGame(game: GameViewState): void {
  snapshot = { ...snapshot, game }
  for (const listener of [...listeners]) listener()
}

/** Publish one settings state to all subscribers. */
function commitSettings(settings: SettingsState): void {
  snapshot = { ...snapshot, settings }
  for (const listener of [...listeners]) listener()
}

/** Whether the game has settled (a winner exists). */
function gameOver(game: GameViewState): boolean {
  return game.game.over || game.phase === 'over'
}

/** Fetch the model catalog once; failures surface in settings.modelsError. */
export function loadModels(): void {
  if (snapshot.settings.groups.length > 0) return
  fetch('/plugins/auto-chess/models')
    .then(response => response.json() as Promise<{ groups?: ModelGroup[]; failures?: { provider: string; error: string }[] }>)
    .then((body) => {
      const groups = body.groups ?? []
      const next: SettingsState = { ...snapshot.settings, groups, modelsError: undefined }
      if (groups.length > 0) {
        // Both sides default to the first catalog model; the user can pick
        // per-side models afterwards.
        const first = groups[0]!
        const defaultModel = first.models[0]?.id
        if (next.blueModel.provider === undefined) {
          next.blueModel = { provider: first.provider, model: defaultModel }
        }
        if (next.redModel.provider === undefined) {
          next.redModel = { provider: first.provider, model: defaultModel }
        }
      }
      commitSettings(next)
    })
    .catch((error: unknown) => {
      if (snapshot.settings.groups.length > 0) return
      commitSettings({ ...snapshot.settings, modelsError: error instanceof Error ? error.message : String(error) })
    })
}

/** Clear store-owned timers of a previous generation. */
function clearTimers(): void {
  if (battleTimer !== undefined) {
    window.clearInterval(battleTimer)
    battleTimer = undefined
  }
  if (settleTimer !== undefined) {
    window.clearTimeout(settleTimer)
    settleTimer = undefined
  }
}

/** Start a new game in the given mode (or the current one). */
export function newGame(mode?: GameMode): void {
  generation += 1
  abort?.abort()
  clearTimers()
  const nextMode = mode ?? snapshot.settings.mode
  commitGame(freshGameView())
  if (nextMode === 'ai') scheduleAi(1)
}

/** Switch the play mode and restart the game in it. */
export function changeMode(mode: GameMode): void {
  if (mode === snapshot.settings.mode) return
  commitSettings({ ...snapshot.settings, mode })
  newGame(mode)
}

/** Apply one settings patch (model selection, thinking, overrides, prompt). */
export function patchSettings(patch: Partial<SettingsState>): void {
  commitSettings({ ...snapshot.settings, ...patch })
}

/** Whether the human may act right now (pvp mode, blue's prep, idle). */
function humanCanAct(): boolean {
  const { game, settings } = snapshot
  return settings.mode === 'pvp' && game.phase === 'prep1' && !game.thinking && !gameOver(game)
}

/** The human's side in pvp mode (blue). */
const HUMAN_SIDE = 1 as const

/** Human: buy the shop offer at `index`. */
export function buy(index: number): void {
  if (!humanCanAct()) return
  const { game } = snapshot
  const entry = game.game.sides[0]!.shop[index]
  if (entry === undefined) return
  const error = applyAction(game.game, HUMAN_SIDE, { action: 'buy', name: entry.name })
  if (error !== undefined) {
    commitGame({
      ...game,
      log: [...game.log, {
        n: game.log.length + 1, round: game.game.round, side: HUMAN_SIDE,
        actions: `购买「${entry.name}」被拒绝：${error}`, reasoning: '',
      }],
    })
    return
  }
  commitGame({ ...game })
}

/** Human: sell the unit with the given id. */
export function sell(id: number): void {
  if (!humanCanAct()) return
  const { game } = snapshot
  applyAction(game.game, HUMAN_SIDE, { action: 'sell', chess_id: id })
  commitGame({ ...game })
}

/** Human: move the unit with the given id to a board cell. */
export function moveUnit(id: number, row: number, col: number): void {
  if (!humanCanAct()) return
  const { game } = snapshot
  applyAction(game.game, HUMAN_SIDE, { action: 'move', chess_id: id, pos: [row, col] })
  commitGame({ ...game })
}

/** Human: buy 4 experience for 4 gold. */
export function upgradeExp(): void {
  if (!humanCanAct()) return
  const { game } = snapshot
  applyAction(game.game, HUMAN_SIDE, { action: 'upgrade' })
  commitGame({ ...game })
}

/** Human: refresh the shop for 2 gold. */
export function refreshShop(): void {
  if (!humanCanAct()) return
  const { game } = snapshot
  applyAction(game.game, HUMAN_SIDE, { action: 'refresh' })
  commitGame({ ...game })
}

/** Human: end the prep phase and hand over to red's AI. */
export function endPrep(): void {
  const { game, settings } = snapshot
  if (!humanCanAct()) return
  if (settings.mode === 'pvp') {
    commitGame({ ...game, phase: 'prep2' })
    scheduleAi(2)
  }
}

/* ------------------------------------------------------------------ *
 * AI prep lifecycle
 * ------------------------------------------------------------------ */

/** How long past the node half's own deadline a request may stay silent before the client declares the thinking interrupted. */
const WATCHDOG_MARGIN_MS = 5000

/** Post one AI action request to the node half's route. */
async function requestAiActions(body: ActionRequest, signal?: AbortSignal): Promise<ActionResponse> {
  const response = await fetch('/plugins/auto-chess/action', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal,
  })
  const parsed = await response.json() as ActionResponse
  if (!response.ok) {
    throw new Error(typeof parsed.error === 'string' ? parsed.error : `auto-chess: HTTP ${response.status}`)
  }
  return parsed
}

/** Run one AI prep decision for a side. */
function scheduleAi(side: 1 | 2, feedback?: { lastText?: string; lastReason?: string }): void {
  const { game, settings } = snapshot
  if (gameOver(game) || game.thinking) return
  const expectedPhase = side === 1 ? 'prep1' : 'prep2'
  if (game.phase !== expectedPhase) return
  const model = side === 1 ? settings.blueModel : settings.redModel
  const customPrompt = side === 1 ? settings.bluePrompt : settings.redPrompt
  if (model.provider === undefined || model.model === undefined) {
    commitGame({
      ...game,
      thinking: false,
      log: [...game.log, {
        n: game.log.length + 1, round: game.game.round, side,
        actions: '', reasoning: '',
        error: settings.modelsError ?? 'model catalog unavailable',
      }],
      pendingSide: side,
    })
    return
  }
  const gen = generation
  commitGame({ ...game, thinking: true, pendingSide: null })
  const controller = new AbortController()
  abort = controller
  const seq = ++requestSeq
  // Watchdog: if the request stays silent past the node half's own deadline
  // plus margin, abort it — the catch below then records an interruption
  // instead of leaving the board stuck on "AI 思考中" forever.
  const watchdog = window.setTimeout(() => {
    if (gen === generation && seq === requestSeq) controller.abort()
  }, settings.actionTimeoutMs + WATCHDOG_MARGIN_MS)
  requestAiActions({
    provider: model.provider,
    model: model.model,
    side,
    state: game.game,
    thinking: side === 1 ? settings.blueThinking : settings.redThinking,
    actionTimeoutMs: settings.actionTimeoutMs,
    maxActionOutputTokens: settings.maxActionOutputTokens,
    ...(customPrompt !== undefined ? { system: customPrompt } : {}),
    ...(feedback?.lastText !== undefined ? { previous: feedback.lastText } : {}),
    ...(feedback?.lastReason !== undefined ? { reason: feedback.lastReason } : {}),
  }, controller.signal)
    .then((reply: ActionResponse) => {
      window.clearTimeout(watchdog)
      if (gen !== generation || seq !== requestSeq) return
      applyAiReply(reply, side, gen)
    })
    .catch((error: unknown) => {
      window.clearTimeout(watchdog)
      if (gen !== generation || seq !== requestSeq) return
      const current = snapshot.game
      if (current.phase !== (side === 1 ? 'prep1' : 'prep2')) return
      // An aborted request (watchdog or an external abort) is an
      // interruption, not a model failure: the user gets a dedicated status
      // and a retry, and the stale promise can never touch the game.
      if ((error as { name?: string } | null)?.name === 'AbortError') {
        commitGame({
          ...current,
          thinking: false,
          log: [...current.log, {
            n: current.log.length + 1, round: current.game.round, side,
            actions: '', reasoning: '', interrupted: true,
          }],
          pendingSide: side,
        })
        return
      }
      const message = error instanceof Error ? error.message : String(error)
      commitGame({
        ...current,
        thinking: false,
        log: [...current.log, {
          n: current.log.length + 1, round: current.game.round, side,
          actions: '', reasoning: '', error: message,
        }],
        pendingSide: side,
      })
    })
}

/** Apply one settled AI reply for the side it was requested for. */
function applyAiReply(reply: ActionResponse, side: 1 | 2, gen: number): void {
  const { game, settings } = snapshot
  if (gen !== generation) return
  if (game.phase !== (side === 1 ? 'prep1' : 'prep2') || !game.thinking) return
  if (reply.actions !== undefined) {
    // The node half already validated the whole batch; replay it on the
    // authoritative state with the same engine.
    let hasEndPrep = false
    const labels: string[] = []
    for (const verdict of reply.actions) {
      if (!verdict.ok) continue
      labels.push(actionLabel(verdict.action))
      if (verdict.action.action === 'end_prep') {
        hasEndPrep = true
        continue
      }
      applyAction(game.game, side, verdict.action)
    }
    const logEntry: ReasoningEntry = {
      n: game.log.length + 1,
      round: game.game.round,
      side,
      actions: labels.length > 0 ? labels.join('、') : '（无操作，直接结束准备）',
      reasoning: reply.reasoning ?? '',
    }
    commitGame({ ...game, thinking: false, log: [...game.log, logEntry], pendingSide: null })
    if (hasEndPrep || labels.length === 0) {
      if (side === 1) {
        commitGame({ ...snapshot.game, phase: 'prep2' })
        scheduleAi(2)
      } else {
        startBattle()
      }
    } else {
      // The model never declared end_prep: treat the prep as over anyway so
      // the game can never stall waiting on an action that will not come.
      const current = snapshot.game
      const note: ReasoningEntry = {
        n: current.log.length + 1, round: current.game.round, side,
        actions: '（AI 未返回 end_prep，自动进入战斗）', reasoning: '',
      }
      commitGame({ ...current, log: [...current.log, note] })
      if (side === 1) {
        commitGame({ ...snapshot.game, phase: 'prep2' })
        scheduleAi(2)
      } else {
        startBattle()
      }
    }
    return
  }
  const error = reply.error ?? 'unknown error'
  const entry: ReasoningEntry = {
    n: game.log.length + 1,
    round: game.game.round,
    side,
    actions: '',
    reasoning: reply.reasoning ?? '',
    error,
    ...(reply.lastText !== undefined ? { lastText: reply.lastText } : {}),
    ...(reply.lastReason !== undefined ? { lastReason: reply.lastReason } : {}),
  }
  commitGame({ ...game, thinking: false, log: [...game.log, entry], pendingSide: side })
}

/**
 * Retry the last failed AI decision for the pending side (the state is
 * unchanged, so the retry carries the corrective feedback from the previous
 * reply). A no-op while the game is settled or a request is in flight.
 */
export function retryAction(): void {
  const { game } = snapshot
  if (gameOver(game) || game.thinking) return
  const side = game.pendingSide
  if (side === null) return
  const entry = game.log[game.log.length - 1]
  scheduleAi(side, entry?.lastText !== undefined
    ? { lastText: entry.lastText, lastReason: entry.lastReason }
    : undefined)
}

/* ------------------------------------------------------------------ *
 * Battle replay clock and settlement
 * ------------------------------------------------------------------ */

/** Milliseconds between replay ticks. */
const BATTLE_TICK_MS = 320
/** Milliseconds the final frame stays on screen before settlement. */
const SETTLE_DELAY_MS = 700

/** Start the battle: simulate, show the replay, then settle. */
function startBattle(): void {
  const { game } = snapshot
  if (gameOver(game) || game.phase !== 'prep2') return
  const result = simulateBattle(game.game)
  const gen = generation
  commitGame({ ...game, phase: 'battle', battle: { result, tick: 0, done: false }, thinking: false })
  let tick = 0
  battleTimer = window.setInterval(() => {
    if (gen !== generation) return
    const current = snapshot.game
    if (current.battle === null) return
    tick += 1
    if (tick >= current.battle.result.ticks.length - 1) {
      window.clearInterval(battleTimer)
      battleTimer = undefined
      commitGame({ ...current, battle: { ...current.battle, tick: current.battle.result.ticks.length - 1, done: true } })
      settleTimer = window.setTimeout(() => {
        if (gen !== generation) return
        settleAfterBattle()
      }, SETTLE_DELAY_MS)
      return
    }
    commitGame({ ...current, battle: { ...current.battle, tick } })
  }, BATTLE_TICK_MS)
}

/** Settle the finished battle and advance to the next round (or game over). */
function settleAfterBattle(): void {
  const { game, settings } = snapshot
  if (game.battle === null || game.battle.result === null) return
  settleRound(game.game, game.battle.result)
  const over = game.game.over
  const phase = over ? 'over' : 'prep1'
  commitGame({ ...game, phase, battle: null })
  if (!over && settings.mode === 'ai') {
    window.setTimeout(() => { scheduleAi(1) }, 250)
  }
}
