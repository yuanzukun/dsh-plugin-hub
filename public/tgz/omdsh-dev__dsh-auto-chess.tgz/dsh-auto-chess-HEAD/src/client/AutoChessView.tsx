/**
 * The auto-chess conversation view: the 自走棋 tab content. A responsive
 * three-column grid: blue's stack (AI settings, always-visible prompt
 * editor, reasoning log) on the left, the board area (header, status, the
 * two sides' panels / battle field, human toolbar) in the middle, red's
 * stack on the right; on narrower columns the two stacks move to a top row
 * and the board area takes the full width below them, the two board panels
 * always staying side by side on one row. A bottom bar under the board
 * area holds the play-mode selector and the new-game button. Each side's
 * AI (model, thinking level and custom prompt) is configured independently
 * in its own stack, the prompt textarea is always editable directly, and
 * each side's reasoning log shows only that side's decisions. Rendered
 * inside the conversation view ring (the same slot Trajectory occupies),
 * one-at-a-time by the session body, so the component unmounts on tab
 * switches and the game state lives in the module-level store (see
 * store.ts), never here.
 *
 * While this view is active the composer seat is hidden: the view marks the
 * document root with a class on mount and the stylesheet hides the
 * platform's composer seat (`[data-composer-seat]`) under it.
 */
import { useEffect, useRef, useState, useSyncExternalStore } from 'react'
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots'
// Type-only: pulls the ui-conversation view-slot declaration (register name)
// and the framework-standard view props (ConvViewProps) into this program.
import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client'
import { NS, type AutoChessKey } from './locales.ts'
import {
  BENCH_CAP, COLS, FIELD_COLS, ROWS,
  expNeeded, incomePreview, traitName, cellIndex,
  type ChessUnit, type GameState, type ShopEntry, type SideState,
} from '../game/engine.ts'
import {
  buy, changeMode, endPrep, getSnapshot, loadModels, moveUnit, newGame,
  patchSettings, refreshShop, retryAction, sell, subscribe, upgradeExp,
  type BattleView, type GameMode, type ModelGroup, type ReasoningEntry,
  type SideModel, type Thinking,
} from './store.ts'
import css from './AutoChess.module.css'

/** The board tab's full component props: the framework view seat + the locale seat. */
export type AutoChessViewProps = ConvViewProps & PropsLocale<'auto-chess'>

const MODES: readonly { value: GameMode; key: AutoChessKey }[] = [
  { value: 'pvp', key: 'mode.pvp' },
  { value: 'ai', key: 'mode.ai' },
]

const THINKINGS: readonly { value: Thinking; key: AutoChessKey }[] = [
  { value: 'off', key: 'thinking.off' },
  { value: 'high', key: 'thinking.high' },
  { value: 'max', key: 'thinking.max' },
]

/** The star glyphs of a unit. */
function starText(star: number): string {
  return '★'.repeat(star)
}

/** The status line copy for the current game. */
function statusCopy(
  game: { phase: string; thinking: boolean; pendingSide: 1 | 2 | null; log: { error?: string; interrupted?: boolean }[]; game: { over: boolean; winner: 1 | 2 | null } },
  mode: GameMode,
  t: PropsLocale<'auto-chess'>['t'],
): { text: string; error: boolean } {
  if (game.game.over) {
    return game.game.winner === 1 ? { text: t('status.win.blue'), error: false } : { text: t('status.win.red'), error: false }
  }
  if (game.phase === 'battle') return { text: t('status.battle'), error: false }
  if (game.phase === 'settle') return { text: t('status.settle'), error: false }
  if (game.thinking) return { text: t('status.thinking'), error: false }
  const last = game.log[game.log.length - 1]
  if (last?.interrupted === true) return { text: t('status.interrupted'), error: true }
  if (last?.error !== undefined) return { text: t('status.error', { message: last.error }), error: true }
  if (game.phase === 'prep1') {
    return { text: mode === 'pvp' ? t('status.prep.blue.human') : t('status.prep.blue.ai'), error: false }
  }
  if (game.phase === 'prep2') return { text: t('status.prep.red'), error: false }
  return { text: t('game.phase.over'), error: false }
}

/** A unit chip: used on the board, the bench and the battle field. */
function UnitChip({
  unit, selected, dim, onClick,
}: {
  unit: ChessUnit
  selected?: boolean
  dim?: boolean
  onClick?: () => void
}) {
  const ratio = unit.maxHp > 0 ? Math.max(0, Math.min(1, unit.hp / unit.maxHp)) : 0
  const content = (
    <>
      <span className={css.chipName}>{unit.name}</span>
      <span className={css.chipStar}>{starText(unit.star)}</span>
      <span className={css.chipHpBar}><span className={css.chipHpFill} style={{ width: `${ratio * 100}%` }} /></span>
    </>
  )
  if (onClick === undefined) {
    return <div className={`${css.chip}${dim ? ` ${css.chipDim}` : ''}`}>{content}</div>
  }
  return (
    <button
      type="button"
      className={`${css.chip}${selected === true ? ` ${css.chipSelected}` : ''}`}
      onClick={onClick}
      aria-label={unit.name}
      title={`${unit.name}（${unit.cost}费 ${starText(unit.star)}）hp ${unit.hp} atk ${unit.atk}`}
    >
      {content}
    </button>
  )
}

/** One side's board (4×7). */
function BoardGrid({
  side, state, interactive, selectedId, onCell,
}: {
  side: SideState
  state: GameState
  interactive: boolean
  selectedId: number | null
  onCell: (row: number, col: number) => void
}) {
  return (
    <div className={css.board} role="grid" aria-label={`side ${side.side}`}>
      {side.board.map((unit, index) => {
        const row = Math.floor(index / COLS)
        const col = index % COLS
        const empty = unit === null
        return (
          <button
            key={index}
            type="button"
            className={`${css.cell}${interactive ? ` ${css.cellInteractive}` : ''}`}
            disabled={!interactive}
            aria-label={`${row},${col}`}
            title={unit !== null ? unit.name : `${row},${col}`}
            onClick={() => onCell(row, col)}
          >
            {unit !== null && (
              <UnitChip
                unit={unit}
                selected={unit.id === selectedId}
                onClick={interactive ? () => onCell(row, col) : undefined}
              />
            )}
          </button>
        )
      })}
    </div>
  )
}

/** One side's bench row. */
function BenchRow({
  side, interactive, selectedId, onSelect,
}: {
  side: SideState
  interactive: boolean
  selectedId: number | null
  onSelect: (id: number) => void
}) {
  return (
    <div className={css.bench} role="list" aria-label="bench">
      {side.bench.length === 0 && <span className={css.hint}>—</span>}
      {side.bench.map(unit => (
        <div key={unit.id} role="listitem">
          <UnitChip
            unit={unit}
            selected={unit.id === selectedId}
            dim={!interactive}
            onClick={interactive ? () => onSelect(unit.id) : undefined}
          />
        </div>
      ))}
    </div>
  )
}

/** One shop offer card. */
function ShopCard({
  entry, affordable, benchFull, interactive, onBuy,
}: {
  entry: ShopEntry
  affordable: boolean
  benchFull: boolean
  interactive: boolean
  onBuy: () => void
}) {
  return (
    <div className={`${css.shopCard}${!interactive ? ` ${css.shopCardDim}` : ''}`}>
      <div className={css.shopName}>{entry.name}</div>
      <div className={css.shopMeta}>
        <span className={css.costBadge}>{entry.cost}费</span>
        <span>{traitName(entry.race)}·{traitName(entry.class)}</span>
      </div>
      <button
        type="button"
        className={css.buyButton}
        disabled={!interactive || !affordable || benchFull}
        title={benchFull ? 'bench full' : undefined}
        onClick={onBuy}
      >
        购买
      </button>
    </div>
  )
}

/** One side's panel: header, board, bench, shop (own side, or both while spectating) and toolbar. */
function SidePanel({
  side, state, mode, interactive, selectedId, onCell, onSelect, onBuy,
}: {
  side: SideState
  state: GameState
  /** The play mode: in 'ai' (spectator) both sides show their shop read-only; in 'pvp' only blue's. */
  mode: GameMode
  interactive: boolean
  selectedId: number | null
  onCell: (row: number, col: number) => void
  onSelect: (id: number) => void
  onBuy: (index: number) => void
}) {
  const preview = incomePreview(side)
  const hpRatio = Math.max(0, Math.min(1, side.hp / 100))
  const isBlue = side.side === 1
  // The shop is a side's own purchase panel: shown for the human's side
  // (always blue), and for BOTH sides when the human is spectating two AIs.
  const showShop = isBlue || mode === 'ai'
  return (
    <div className={`${css.sidePanel}${isBlue ? ` ${css.sideBlue}` : ` ${css.sideRed}`}`}>
      <div className={css.sideHeader}>
        <span className={css.sideName}>{isBlue ? '蓝方' : '红方'}{interactive ? '（你）' : ''}</span>
        <span className={css.hpBar}><span className={css.hpFill} style={{ width: `${hpRatio * 100}%` }} /></span>
        <span className={css.hpText}>{side.hp}/100</span>
        <span className={css.sideStats}>
          <span>金币 {side.gold}</span>
          <span>等级 {side.level}（{side.exp}/{expNeeded(side.level)}）</span>
        </span>
      </div>
      {/* The hint row is always rendered (empty on the AI side) so both
          panels' boards stay on the same row. */}
      <div className={css.hint}>
        {interactive
          ? `下回合收入 ${preview.base}+${preview.interest}+${preview.streak}${preview.win > 0 ? `+${preview.win}` : ''} = ${preview.total}`
            + (side.winStreak >= 2 ? ` · 连胜×${side.winStreak}` : '')
            + (side.lossStreak >= 2 ? ` · 连败×${side.lossStreak}` : '')
          : ''}
      </div>
      <BoardGrid side={side} state={state} interactive={interactive} selectedId={selectedId} onCell={onCell} />
      <div className={css.sectionLabel}>备战区</div>
      <BenchRow side={side} interactive={interactive} selectedId={selectedId} onSelect={onSelect} />
      {showShop && (
        <>
          <div className={css.sectionLabel}>商店</div>
          <div className={css.shopRow}>
            {side.shop.map((entry, index) => (
              <ShopCard
                key={entry.defId}
                entry={entry}
                affordable={side.gold >= entry.cost}
                benchFull={side.bench.length >= BENCH_CAP}
                interactive={interactive}
                onBuy={() => onBuy(index)}
              />
            ))}
          </div>
        </>
      )}
    </div>
  )
}

/** The battle field (4×14): units positioned by the current replay tick. */
function BattleField({ battle }: { battle: BattleView }) {
  const tick = battle.result.ticks[Math.min(battle.tick, battle.result.ticks.length - 1)]
  const events = tick?.events ?? []
  const result = battle.result
  return (
    <div className={css.battleArea}>
      <div className={css.field}>
        {tick?.units.map(unit => (
          <div
            key={`${unit.side}-${unit.uid}`}
            className={`${css.fieldUnit}${unit.side === 1 ? ` ${css.fieldBlue}` : ` ${css.fieldRed}`}`}
            style={{
              left: `${(unit.col / (FIELD_COLS - 1)) * 100}%`,
              top: `${(unit.row / (ROWS - 1)) * 100}%`,
            }}
            title={`${unit.name}（${starText(unit.star)}）`}
          >
            <span className={css.fieldName}>{unit.name}{starText(unit.star)}</span>
            <span className={css.fieldHp}>
              <span className={css.fieldHpFill} style={{ width: `${Math.max(0, Math.min(100, (unit.hp / unit.maxHp) * 100))}%` }} />
            </span>
          </div>
        ))}
      </div>
      <div className={css.fieldEvents}>
        {events.length === 0 && <span className={css.hint}>—</span>}
        {events.slice(-4).map((event, index) => (
          <div key={index} className={css.fieldEvent}>{event}</div>
        ))}
      </div>
      {battle.done && (
        <div className={css.battleResult}>
          {result.winner === 1 && '蓝方获胜，红方'}
          {result.winner === 2 && '红方获胜，蓝方'}
          {result.winner === 0 && '平局'}
          {result.winner !== 0 && <span> -{result.damage} 生命（剩余 {result.survivors} 个棋子）</span>}
        </div>
      )}
    </div>
  )
}

/** One per-side model selector. */
function ModelSelect({
  label, value, groups, onChange,
}: {
  label: string
  value: SideModel
  groups: readonly ModelGroup[]
  onChange: (model: SideModel) => void
}) {
  const selected = value.provider !== undefined && value.model !== undefined
    ? `${value.provider}/${value.model}`
    : ''
  return (
    <label className={css.field}>
      <span className={css.label}>{label}</span>
      <select
        className={css.select}
        value={selected}
        onChange={(event) => {
          const [provider, ...rest] = event.target.value.split('/')
          onChange({ provider, model: rest.join('/') })
        }}
        disabled={groups.length === 0}
      >
        {groups.length === 0 && <option value="">—</option>}
        {groups.map(group => (
          <optgroup key={group.provider} label={group.displayName}>
            {group.models.map(model => (
              <option key={model.id} value={`${group.provider}/${model.id}`}>{model.name}</option>
            ))}
          </optgroup>
        ))}
      </select>
    </label>
  )
}

/** One side's AI settings: the model selector and the thinking level. The
 *  prompt editor below is always visible, so no toggle button is needed. */
function SideAISettings({
  t, title, modelLabel, thinkingLabel, model, groups, thinking, variant,
  onModel, onThinking,
}: {
  t: PropsLocale<'auto-chess'>['t']
  title: string
  modelLabel: string
  thinkingLabel: string
  model: SideModel
  groups: readonly ModelGroup[]
  thinking: Thinking
  variant: 'blue' | 'red'
  onModel: (model: SideModel) => void
  onThinking: (level: Thinking) => void
}) {
  return (
    <div className={`${css.sideSettings}${variant === 'blue' ? ` ${css.sideSettingsBlue}` : ` ${css.sideSettingsRed}`}`}>
      <div className={css.panelTitle}>{title}</div>
      <ModelSelect label={modelLabel} value={model} groups={groups} onChange={onModel} />
      <div className={css.toolbar}>
        <span className={css.label}>{thinkingLabel}</span>
        <div className={css.segmented} role="group" aria-label={thinkingLabel}>
          {THINKINGS.map(level => (
            <button
              key={level.value}
              type="button"
              className={`${css.segButton}${thinking === level.value ? ` ${css.segActive}` : ''}`}
              onClick={() => onThinking(level.value)}
            >
              {t(level.key)}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

/** One side's prompt editor: default-loading textarea with restore/save actions. */
function SidePromptEditor({
  t, title, loading, value, saved, onChange, onSave, onRestore,
}: {
  t: PropsLocale<'auto-chess'>['t']
  title: string
  loading: boolean
  value: string
  saved: boolean
  onChange: (text: string) => void
  onSave: () => void
  onRestore: () => void
}) {
  return (
    <div className={css.promptArea}>
      <div className={css.promptTitle}>{title}</div>
      {loading && <div className={css.hint}>{t('panel.prompt.loading')}</div>}
      <textarea
        className={css.promptTextarea}
        value={value}
        rows={5}
        spellCheck={false}
        onChange={(event) => onChange(event.target.value)}
      />
      <div className={css.promptActions}>
        <button type="button" className={css.ghost} onClick={onRestore}>{t('panel.prompt.restore')}</button>
        <button type="button" className={css.primary} onClick={onSave}>{t('panel.prompt.save')}</button>
        {saved && <span className={css.flash}>{t('panel.prompt.saved')}</span>}
      </div>
    </div>
  )
}

/** One side's reasoning log: only that side's decisions, newest last. */
function SideReasoningList({
  t, title, variant, entries, expandedEntries, onToggle,
}: {
  t: PropsLocale<'auto-chess'>['t']
  title: string
  /** The side identity, tinting the list's title and entries. */
  variant: 'blue' | 'red'
  /** The side's decisions, each carrying its index in the full game log. */
  entries: { entry: ReasoningEntry; index: number }[]
  expandedEntries: ReadonlySet<number>
  onToggle: (index: number) => void
}) {
  return (
    <div className={`${css.reasoningList}${variant === 'blue' ? ` ${css.sideReasoningBlue}` : ` ${css.sideReasoningRed}`}`}>
      <div className={css.reasoningTitle}>{title}</div>
      {entries.length === 0 && <div className={css.hint}>{t('reasoning.empty')}</div>}
      {entries.map(({ entry, index }) => {
        const isExpanded = expandedEntries.has(index)
        return (
          <div key={index} className={css.reasoningItem}>
            <button
              type="button"
              className={css.reasoningHeader}
              aria-expanded={isExpanded}
              aria-label={isExpanded ? t('reasoning.collapse') : t('reasoning.expand')}
              onClick={() => onToggle(index)}
            >
              <span className={`${css.chevron}${isExpanded ? ` ${css.chevronOpen}` : ''}`}>▸</span>
              <span className={css.reasoningMove}>
                {t('reasoning.entry', {
                  round: entry.round,
                  side: entry.side === 1 ? t('reasoning.side.blue') : t('reasoning.side.red'),
                })}
                {' · '}
                {entry.actions}
              </span>
              {entry.interrupted === true && <span className={css.errorText}>{t('status.interrupted')}</span>}
              {entry.error !== undefined && entry.interrupted !== true && <span className={css.errorText}>{entry.error}</span>}
            </button>
            {isExpanded && entry.reasoning !== '' && (
              <pre className={css.reasoningText}>{entry.reasoning}</pre>
            )}
          </div>
        )
      })}
    </div>
  )
}

/** The auto-chess view tab body. */
export function AutoChessView({ t }: AutoChessViewProps) {
  const { game, settings } = useSyncExternalStore(subscribe, getSnapshot)
  // The prompt editors are always visible: each side keeps its own draft,
  // seeded from that side's saved override (or the package default).
  const [bluePromptText, setBluePromptText] = useState('')
  const [redPromptText, setRedPromptText] = useState('')
  const [defaultPrompt, setDefaultPrompt] = useState<string | undefined>(undefined)
  const [promptLoading, setPromptLoading] = useState(false)
  // Which side's editor just saved (drives the per-side "已保存" flash).
  const [savedFlash, setSavedFlash] = useState<'blue' | 'red' | null>(null)
  const savedTimer = useRef<number | undefined>(undefined)
  // Reasoning log entries start collapsed; clicking a header expands it.
  const [expandedEntries, setExpandedEntries] = useState<ReadonlySet<number>>(new Set())
  // The bench/board unit selected for deployment (blue, human prep).
  const [selectedId, setSelectedId] = useState<number | null>(null)

  // The catalog is needed the moment a game starts; retried on remount only
  // when a previous attempt failed (loadModels is idempotent on success).
  useEffect(() => { loadModels() }, [])

  // Hide the composer seat while the auto-chess view is mounted (the
  // stylesheet rules target `html.dsh-auto-chess-view [data-composer-seat]`).
  useEffect(() => {
    document.documentElement.classList.add(css.viewActive)
    return () => { document.documentElement.classList.remove(css.viewActive) }
  }, [])

  // Load the default prompt once; each side's editor seeds from its saved
  // override (or the default) while its textarea is still empty.
  useEffect(() => {
    if (defaultPrompt !== undefined) return
    let cancelled = false
    setPromptLoading(true)
    fetch('/plugins/auto-chess/prompt')
      .then(response => response.json() as Promise<{ prompt?: string }>)
      .then((body) => {
        if (cancelled) return
        const prompt = body.prompt
        if (prompt !== undefined) {
          setDefaultPrompt(prompt)
          setBluePromptText(current => current !== '' ? current : (settings.bluePrompt ?? prompt))
          setRedPromptText(current => current !== '' ? current : (settings.redPrompt ?? prompt))
        }
      })
      .catch(() => { /* the editors stay usable; save still works */ })
      .finally(() => { if (!cancelled) setPromptLoading(false) })
    return () => { cancelled = true }
  }, [defaultPrompt, settings.bluePrompt, settings.redPrompt])

  useEffect(() => () => { window.clearTimeout(savedTimer.current) }, [])

  const flashSaved = (side: 'blue' | 'red'): void => {
    setSavedFlash(side)
    window.clearTimeout(savedTimer.current)
    savedTimer.current = window.setTimeout(() => setSavedFlash(null), 1500)
  }

  /** Save one side's draft as that side's custom prompt. */
  const savePrompt = (side: 'blue' | 'red'): void => {
    const text = side === 'blue' ? bluePromptText : redPromptText
    const trimmed = text.trim()
    patchSettings(side === 'blue'
      ? { bluePrompt: trimmed.length > 0 ? text : undefined }
      : { redPrompt: trimmed.length > 0 ? text : undefined })
    flashSaved(side)
  }

  /** Restore one side's editor to the package default prompt. */
  const restorePrompt = (side: 'blue' | 'red'): void => {
    const prompt = defaultPrompt ?? ''
    if (side === 'blue') {
      setBluePromptText(prompt)
      patchSettings({ bluePrompt: undefined })
    } else {
      setRedPromptText(prompt)
      patchSettings({ redPrompt: undefined })
    }
  }

  const status = statusCopy(game, settings.mode, t)
  const settled = game.game.over
  const humanTurn = settings.mode === 'pvp' && game.phase === 'prep1' && !game.thinking && !settled
  const retryableError = status.error && !settled && !game.thinking && game.pendingSide !== null
  const inBattle = game.phase === 'battle' || game.phase === 'settle'

  const toggleEntry = (index: number): void => {
    setExpandedEntries(prev => {
      const next = new Set(prev)
      if (next.has(index)) next.delete(index)
      else next.add(index)
      return next
    })
  }

  /** Human cell click on blue's board. */
  const handleCell = (row: number, col: number): void => {
    if (!humanTurn) return
    const unit = game.game.sides[0]!.board[cellIndex(row, col)]
    if (unit !== null) {
      // Clicking a deployed unit selects it (or moves the selected one onto
      // it — impossible, the cell is occupied — so just select).
      setSelectedId(current => current === unit.id ? null : unit.id)
      return
    }
    if (selectedId !== null) {
      moveUnit(selectedId, row, col)
      setSelectedId(null)
    }
  }

  /** Human click on blue's bench. */
  const handleSelect = (id: number): void => {
    if (!humanTurn) return
    setSelectedId(current => current === id ? null : id)
  }

  /** Human click on a shop offer. */
  const handleBuy = (index: number): void => {
    if (!humanTurn) return
    buy(index)
    setSelectedId(null)
  }

  const blue = game.game.sides[0]!
  const red = game.game.sides[1]!
  // Split the decision log per side; each list shows only its own side's
  // entries (the original log index stays the expansion key).
  const logEntries = game.log.map((entry, index) => ({ entry, index }))
  const blueLog = logEntries.filter(item => item.entry.side === 1)
  const redLog = logEntries.filter(item => item.entry.side === 2)

  return (
    <div className={css.view}>
      <div className={css.inner}>
        <div className={css.sideBlockBlue}>
          <SideAISettings
            t={t}
            title={t('panel.settings.blue')}
            modelLabel={t('panel.model.blue')}
            thinkingLabel={t('panel.thinking.blue')}
            model={settings.blueModel}
            groups={settings.groups}
            thinking={settings.blueThinking}
            variant="blue"
            onModel={(blueModel) => patchSettings({ blueModel })}
            onThinking={(thinking) => patchSettings({ blueThinking: thinking })}
          />
          <SidePromptEditor
            t={t}
            title={t('panel.prompt.title.blue')}
            loading={promptLoading}
            value={bluePromptText}
            saved={savedFlash === 'blue'}
            onChange={setBluePromptText}
            onSave={() => savePrompt('blue')}
            onRestore={() => restorePrompt('blue')}
          />
          <SideReasoningList
            t={t}
            variant="blue"
            title={t('reasoning.title.blue')}
            entries={blueLog}
            expandedEntries={expandedEntries}
            onToggle={toggleEntry}
          />
        </div>

        <div className={css.sideBlockRed}>
          <SideAISettings
            t={t}
            title={t('panel.settings.red')}
            modelLabel={t('panel.model.red')}
            thinkingLabel={t('panel.thinking.red')}
            model={settings.redModel}
            groups={settings.groups}
            thinking={settings.redThinking}
            variant="red"
            onModel={(redModel) => patchSettings({ redModel })}
            onThinking={(thinking) => patchSettings({ redThinking: thinking })}
          />
          <SidePromptEditor
            t={t}
            title={t('panel.prompt.title.red')}
            loading={promptLoading}
            value={redPromptText}
            saved={savedFlash === 'red'}
            onChange={setRedPromptText}
            onSave={() => savePrompt('red')}
            onRestore={() => restorePrompt('red')}
          />
          <SideReasoningList
            t={t}
            variant="red"
            title={t('reasoning.title.red')}
            entries={redLog}
            expandedEntries={expandedEntries}
            onToggle={toggleEntry}
          />
        </div>

        <div className={css.main}>
          <div className={css.header}>
            <span className={css.round}>
              {t('game.round', { n: game.game.round })}
              {' · '}
              {game.phase === 'prep1' && t('game.phase.prep')}
              {game.phase === 'prep2' && t('game.phase.prep')}
              {game.phase === 'battle' && t('game.phase.battle')}
              {game.phase === 'settle' && t('game.phase.settle')}
              {game.phase === 'over' && t('game.phase.over')}
            </span>
            <span className={css.versus} aria-label={`蓝方 ${blue.hp} 比 ${red.hp} 红方`}>
              <span className={css.vSideBlue}>蓝方</span>
              <span className={css.vScore}>{blue.hp}</span>
              <span className={css.vSep}>:</span>
              <span className={css.vScore}>{red.hp}</span>
              <span className={css.vSideRed}>红方</span>
            </span>
            <span className={css.hint}>
              {settings.mode === 'pvp' ? t('status.side.hint.pvp') : t('status.side.hint.ai')}
            </span>
          </div>
          <div className={css.statusRow}>
            <div className={`${css.status}${status.error ? ` ${css.statusError}` : ''}${game.thinking ? ` ${css.statusThinking}` : ''}`}>{status.text}</div>
            {retryableError && (
              <button type="button" className={css.retry} onClick={retryAction}>{t('status.retry')}</button>
            )}
          </div>

          {inBattle && game.battle !== null ? (
            <BattleField battle={game.battle} />
          ) : (
            <div className={css.boards}>
              <SidePanel
                side={blue}
                state={game.game}
                mode={settings.mode}
                interactive={humanTurn}
                selectedId={selectedId}
                onCell={handleCell}
                onSelect={handleSelect}
                onBuy={handleBuy}
              />
              <SidePanel
                side={red}
                state={game.game}
                mode={settings.mode}
                interactive={false}
                selectedId={null}
                onCell={() => {}}
                onSelect={() => {}}
                onBuy={() => {}}
              />
            </div>
          )}

          {humanTurn && (
            <div className={css.toolbar}>
              {selectedId !== null && (
                <button type="button" className={css.sellButton} onClick={() => { sell(selectedId); setSelectedId(null) }}>
                  {t('game.sell')}
                </button>
              )}
              {selectedId !== null && <span className={css.hint}>{t('game.place')}</span>}
              <button type="button" className={css.ghost} onClick={upgradeExp}>{t('game.upgrade')}</button>
              <button type="button" className={css.ghost} onClick={refreshShop}>{t('game.refresh')}</button>
              <button type="button" className={css.primary} onClick={endPrep}>{t('game.endPrep')}</button>
            </div>
          )}
        </div>

        <div className={css.bottom}>
          <div className={css.bottomRow}>
            <span className={css.label}>{t('panel.mode')}</span>
            <div className={css.segmented} role="group" aria-label={t('panel.mode')}>
              {MODES.map(mode => (
                <button
                  key={mode.value}
                  type="button"
                  className={`${css.segButton}${settings.mode === mode.value ? ` ${css.segActive}` : ''}`}
                  onClick={() => changeMode(mode.value)}
                >
                  {t(mode.key)}
                </button>
              ))}
            </div>
            <button type="button" className={css.ghost} onClick={() => newGame()}>{t('panel.newGame')}</button>
          </div>
        </div>
      </div>
    </div>
  )
}
