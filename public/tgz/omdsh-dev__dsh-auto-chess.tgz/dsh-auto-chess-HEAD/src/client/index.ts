/**
 * Auto chess (自走棋) browser half, plugin entry: registers the auto-chess
 * conversation view tab (right of Trajectory and Gomoku) and the auto-chess
 * dictionaries. The game state lives in the module-level store, so tab
 * switches never reset the game or interrupt an in-flight AI decision.
 * @module @deepseek-ai/dsh-auto-chess/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only: pulls the locale plugin's Context merge (ctx.locale) and the
// conversation view-slot declaration into this program.
import type {} from '@deepseek-ai/dsh-client-locale/client'
import { AutoChessView } from './AutoChessView.tsx'
import { NS, en, zh, type AutoChessKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The auto-chess board tab copy. */
    'auto-chess': AutoChessKey
  }
}

/** Required services: the locale service and the slot registry. */
export const inject = ['locale', 'slots']

/**
 * Client plugin body: register the auto-chess dictionaries and the
 * conversation-view tab. The registration rides the slot service's effect
 * wrapper, so plugin unload removes the tab.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'auto-chess: dictionaries')
  const t = ctx.locale.bind(NS)
  ctx.slots.inject('conversation.view', () => ctx.slots.register({
    name: 'conversation.view',
    // order 30 places the tab right of Trajectory (order 10) and Gomoku (order 20).
    id: 'auto-chess',
    order: 30,
    label: () => t('tab.label'),
    locale: NS,
  }, AutoChessView))
}
