/**
 * Package-owned invariant companion for `@deepseek-ai/dsh-auto-chess`.
 * @module @deepseek-ai/dsh-auto-chess/invariant
 */

/* jscpd:ignore-start */
import type { Context } from 'cordis'
import type { InvariantInstaller } from '@deepseek-ai/dsh-invariants'

const PACKAGE_NAME = '@deepseek-ai/dsh-auto-chess'

/** Cordis companion plugin name. */
export const name = 'auto-chess-invariant'
/** Service required before the companion can reserve package ownership. */
export const inject = ['invariants']

/**
 * No runtime invariant: the auto-chess plugin owns no cross-plugin mutable
 * state and emits no cordis events — the action routes validate every
 * untrusted input at the HTTP boundary (and the game rules themselves at
 * apply time), and behavior is asserted by this package's engine/route
 * tests.
 */
const install: InvariantInstaller = () => {}

/**
 * Register this package's invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export const apply = (ctx: Context): Promise<() => void> =>
  Promise.resolve(ctx.invariants.register(PACKAGE_NAME, install))
/* jscpd:ignore-end */
