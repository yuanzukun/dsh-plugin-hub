# deepseek-harness-locale-ru

Русский | [English](README.en.md) | [中文](README.zh.md)

`deepseek-harness-locale-ru` — русская локализация веб-интерфейса [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness): плагин добавляет «Русский» в **официальную систему локализации** — штатный переключатель языка в настройках интерфейса.

Плагин регистрирует язык и словари через документированный клиентский API локали (`@deepseek-ai/dsh-client-locale`), а русские названия пресетов разрешений задаёт слоем конфигурации. Файлы самого Harness не модифицируются — форк и пересборка не нужны.

## Developer preview

DeepSeek Harness находится в стадии _developer preview_ и быстро развивается — **возможны изменения, ломающие совместимость.** Пакет отслеживает это: `node scripts/check.mjs` сверяет словари с актуальными строками upstream, а CI запускает проверку на каждый push и pull request. Строк, которых ещё нет в словаре, это не ломает — они отображаются на английском (он задан резервным языком).

Перед установкой ознакомьтесь с [уведомлением о безопасности](SAFETY.md).

## Совместимость

- Пакет — **внешний locale-плагин**, а не встроенный язык ядра: он регистрирует язык и словари через публичный API, не требуя изменений upstream. Гарантии у этих двух путей разные: встроенный язык проходит полный релизный цикл ядра, внешний плагин проверяется против конкретной ревизии.
- Протестировано против upstream-ревизии `cd5ef81` (v0.1.2-alpha.1). После обновления dsh повторно выполните `node scripts/check.mjs --strict` (клонировав репозиторий Harness) — см. [docs/upstream-sync.md](docs/upstream-sync.md).
- Откат — одна команда: `dsh plugin --profile web remove deepseek-harness-locale-ru` и перезапуск `dsh web`.

## Установка

### Одной командой

Скопируйте, вставьте, перезапустите:

```sh
dsh plugin --profile web add github:warment/deepseek-harness-locale-ru
```

Команда одинаково работает с любой установкой dsh — из npm (`npx @deepseek-ai/dsh web`) или из клона исходников (`pnpm dsh web`) — на macOS, Windows и Linux. Профиль `web` и его структура создаются автоматически, ничего вручную настраивать не нужно.

**Проверка за 30 секунд:**

1. Перезапустите `dsh web` (остановите и запустите процесс заново) и откройте интерфейс.
2. Откройте **Settings → General** и в строке **Language** выберите **«Русский»**.
3. Интерфейс сразу переключится на русский: боковая панель покажет «Новая сессия» и «Настройки». Выбор сохраняется между перезапусками.

Если при запуске не выбрать язык, интерфейс останется английским — «Русский» всегда доступен в том же пункте настроек.

### Из локальной копии

Для проверки без GitHub (например, перед публикацией или для своей правки):

```sh
dsh plugin --profile web add /путь/к/deepseek-harness-locale-ru
```

### Обновление и удаление

Чтобы обновиться до новой версии, удалите пакет и установите заново той же командой:

```sh
dsh plugin --profile web remove deepseek-harness-locale-ru
dsh plugin --profile web add github:warment/deepseek-harness-locale-ru
```

Удаление:

```sh
dsh plugin --profile web remove deepseek-harness-locale-ru
```

После любых изменений состава плагинов перезапустите `dsh web`.

## Сообщество и поддержка

- Ошибки и неточности перевода, непереведённые строки, идеи — в [Issues](https://github.com/warment/deepseek-harness-locale-ru/issues) этого репозитория.
- Вопросы по самому DeepSeek Harness (установка, модели, сессии — всё, кроме перевода) — в официальный репозиторий: [GitHub Discussions](https://github.com/deepseek-ai/deepseek-harness/discussions) и [Discord-сообщество](https://discord.gg/Ycq5dCaS4).

## Contributing

См. [CONTRIBUTING.md](CONTRIBUTING.md). Кратко порядок работы над переводом:

1. Найдите английскую строку в `upstream/corpus.json` — её пространство имён и ключ укажут нужный файл.
2. Отредактируйте `dict/ru/<namespace>.json`.
3. Проверьте словари: `node scripts/check.mjs`.
4. Пересоберите клиентскую часть: `node scripts/build.mjs`.
5. Закоммитьте оба изменения: файл словаря и обновлённый `lib/client.js`.

Состав репозитория: `dict/ru/*.json` — исходники перевода; `upstream/corpus.json` — английские строки, извлечённые из upstream (`node scripts/extract.mjs`, см. [docs/upstream-sync.md](docs/upstream-sync.md)); `lib/client.js` — собранная клиентская часть (коммитится, поэтому сборка пользователям не нужна); `scripts/` — проверка, сборка, извлечение строк, живая проверка загрузки.

## Лицензия

[MIT](LICENSE)

DeepSeek Harness — проект [DeepSeek AI](https://deepseek.com) под лицензией MIT; авторство и заимствования описаны в [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
