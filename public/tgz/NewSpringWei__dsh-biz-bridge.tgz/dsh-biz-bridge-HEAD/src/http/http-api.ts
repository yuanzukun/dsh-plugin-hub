/**
 * HTTP 路由与处理器装配（§6.1/§6.3/§6.4/§6.5）。
 *
 * 统一前缀 /bizbridge（webServer kind:'prefix'），路径内自路由：
 *   POST …/api/v1/stream            流式响应（SSE）
 *   POST …/api/v1/callback          回调响应（入队）
 *   POST …/api/v1/tasks/list        任务列表
 *   POST …/api/v1/tasks/{id}        详情
 *   POST …/api/v1/tasks/{id}/logs   日志
 *   POST …/api/v1/tasks/{id}/cancel 取消
 *   POST …/api/v1/tasks/{id}/replay 重播
 *   POST …/api/v1/tasks/{id}/redeliver 再次触发回调（重新投递，仅回调任务）
 *   POST …/api/v1/tasks/{id}/priority 优先级
 *   POST …/api/v1/stats             统计
 *   POST …/api/v1/models            可用模型查询（provider 级失败如实上报）
 *   POST …/api/v1/admin/models      模型配置面读取（admin）
 *   POST …/api/v1/admin/models/providers 模型 provider 段写入（admin）
 *   POST …/api/v1/sync              模型配置同步（免签名；第一方工具页触发，不接受参数）
 *   POST …/api/v1/sessions/{id}/messages  会话消息查询
 *   POST …/api/v1/callback-test/receive   回调测试接收（免签名）
 *   POST …/api/v1/callback-test/{id}      回调测试状态查询
 *   GET  …/static/*                第一方参考/调试页面（index/admin/client/utils，免签名）
 *
 * 除静态页外均需签名头（§6.2）。路由 handler 拥有完整响应生命周期（§6.1）。
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import { randomUUID } from 'node:crypto'
import { ForbiddenError, InvalidRequestError, NotImplementedError, NotFoundError } from '../shared/errors.ts'
import { CALLBACK_TEST_TOKEN_HEADER } from '../shared/callback-test.ts'
import type { Caller } from '../core/auth.ts'
import { internalSessionId } from '../shared/session-id.ts'
import { parseJsonBody, readBody, sendError, writeJson } from './http-util.ts'
import {
  cancelOp, detailOp, listOp, logsOp, priorityOp, redeliverOp, replayOp, requireAttachmentOwned,
  requireTaskOwned, statsOp, sessionMessagesOp,
} from '../core/ops.ts'
import { discardInbound, downloadInbound, readAttachmentBytes, recordInbound } from '../core/attachment-flow.ts'
import { toAttachmentEntry } from '../core/attachments.ts'
import { collectModelCatalog, readModelsConfig, writeModelProviders, type ModelCatalog } from '../core/models-config.ts'
import type { BridgeRuntime } from '../shared/runtime.ts'
import type { TaskAttachmentRow } from '../shared/types.ts'
import { validateSubmitInput } from '../core/submission.ts'
import { handleStreamSubmit } from './stream.ts'
import { nowIso } from '../core/db.ts'

/** 解析 URL pathname。 */
function pathnameOf(req: IncomingMessage): string {
  const raw = req.url ?? '/'
  try {
    return new URL(raw, 'http://localhost').pathname
  } catch {
    return raw.split('?')[0] ?? '/'
  }
}

const STATIC_PREFIX = '/bizbridge/static'
/** 附件下载路由前缀：GET /bizbridge/api/v1/attachments/<attachment_id>（§6.4.6）。 */
const ATTACHMENT_GET_PREFIX = '/bizbridge/api/v1/attachments'
/** 附件下载路由：POST /bizbridge/api/v1/attachments/download（§6.4.6，与现有POST签名方式一致）。 */
const ATTACHMENT_POST_PATH = '/bizbridge/api/v1/attachments/download'

function contentTypeOf(name: string): string {
  if (name.endsWith('.html')) return 'text/html; charset=utf-8'
  if (name.endsWith('.js')) return 'text/javascript; charset=utf-8'
  if (name.endsWith('.css')) return 'text/css; charset=utf-8'
  if (name.endsWith('.json')) return 'application/json; charset=utf-8'
  return 'application/octet-stream'
}

/**
 * 第一方参考/调试页面静态服务（GET/HEAD，免签名）：
 *   /bizbridge/static[/]            → index.html（入口导航）
 *   /bizbridge/static/<name>[.html] → 同名资源（admin/client/utils 及 common.js/style.css）
 */
function serveStatic(runtime: BridgeRuntime, req: IncomingMessage, res: ServerResponse, pathname: string): boolean {
  if (pathname !== STATIC_PREFIX && !pathname.startsWith(`${STATIC_PREFIX}/`)) return false
  let name: string
  if (pathname === STATIC_PREFIX || pathname === `${STATIC_PREFIX}/`) {
    name = 'index.html'
  } else {
    const rel = pathname.slice(STATIC_PREFIX.length + 1)
    if (!/^[A-Za-z0-9._-]+$/.test(rel)) return false
    name = rel.includes('.') ? rel : `${rel}.html`
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    writeJson(res, 405, { error: { code: 'INVALID_REQUEST', message: 'method not allowed', details: {} } })
    return true
  }
  const body = runtime.staticFiles[name]
  if (body === undefined) {
    writeJson(res, 404, { error: { code: 'NOT_FOUND', message: `static asset not found: ${name}`, details: {} } })
    return true
  }
  res.writeHead(200, {
    'content-type': contentTypeOf(name),
    'cache-control': 'no-cache',
  })
  if (req.method === 'GET') res.end(body)
  else res.end()
  return true
}

/** 脱敏：移除/截断敏感字段。 */
function sanitizeHeaders(headers: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(headers)) {
    const lk = k.toLowerCase()
    if (lk === 'x-signature') { out[k] = '***'; continue }
    if (lk === 'cookie') { out[k] = '***'; continue }
    out[k] = v
  }
  return out
}

function sanitizeBody(body: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(body)) {
    if (k === 'publicKey' || k === 'privateKey') { out[k] = '***'; continue }
    if (k === 'prompt' && typeof v === 'string') { out[k] = v.length > 50 ? v.slice(0, 50) + '…' : v; continue }
    out[k] = v
  }
  return out
}

/**
 * 免签名端点的同源守卫：带 `Origin` 的跨源请求拒绝，`Sec-Fetch-Site: cross-site` 拒绝。
 *
 * 用途是挡浏览器侧的 CSRF（工具页 `utils.html` 在**同源**下调用 `/api/v1/sync`）。
 * 非浏览器客户端两个头都没有——放行；该端点不接受任何参数，调用者无法注入配置。
 */
export function assertSameOriginRequest(headers: IncomingMessage['headers'], host: string | undefined): void {
  const origin = headers.origin
  if (typeof origin === 'string' && origin !== '') {
    let originHost: string | undefined
    try {
      originHost = new URL(origin).host
    } catch {
      originHost = undefined
    }
    if (originHost === undefined || host === undefined || originHost !== host) {
      throw new ForbiddenError('cross-origin request rejected')
    }
    return
  }
  if (headers['sec-fetch-site'] === 'cross-site') {
    throw new ForbiddenError('cross-origin request rejected')
  }
}

/** 完整处理器（注册为 /bizbridge 前缀路由）。 */
export function createBridgeHandler(runtime: BridgeRuntime) {
  return async (req: IncomingMessage, res: ServerResponse): Promise<void> => {
    const pathname = pathnameOf(req)
    const clientId = (req.headers['x-client-id'] as string) ?? '-'
    // 入口即记录（无论签名成败）
    runtime.fileLogger.info('http', `>>> ${req.method} ${pathname}`, { clientId })
    try {
      // 第一方参考/调试页面（GET/HEAD，免签名）
      if (serveStatic(runtime, req, res, pathname)) return
      // 模型配置同步（**免签名**）：第一方工具页 `/static/utils.html` 的按钮触发。
      //   安全设计：请求体不参与任何决策、源由配置固定、内容没变就不落盘——未验签调用者
      //   只能"让服务端按配置重读一次源补丁"，无法注入模型配置或指定路径。
      if (pathname === '/bizbridge/api/v1/sync' && req.method === 'POST') {
        assertSameOriginRequest(req.headers, req.headers.host)
        const outcome = await runtime.syncModels()
        runtime.fileLogger.info('models-sync', `manual trigger → ${outcome.status}`, { reason: outcome.reason })
        writeJson(res, 200, outcome)
        return
      }
      // 回调测试接收端点（免签名：scheduler 服务端 POST，不携带签名头）
      if (pathname === '/bizbridge/api/v1/callback-test/receive' && req.method === 'POST') {
        const rawBody = await readBody(req)
        const body = parseJsonBody(rawBody)
        handleCallbackTestReceive(runtime, req.headers, body, res)
        return
      }
      // 附件下载（GET + 签名）：签名串里的方法为 GET、请求体为空串哈希（§6.2.2/§6.4.6）
      if (req.method === 'GET' && pathname.startsWith(`${ATTACHMENT_GET_PREFIX}/`)) {
        const caller = runtime.verifier.verify(req.headers, 'GET', pathname, Buffer.alloc(0), runtime.nonceSeen)
        runtime.fileLogger.info('http', `<<< GET ${pathname} OK`, { clientId: caller.clientId, scope: caller.scope })
        await handleAttachmentDownloadGet(runtime, caller, pathname, res)
        return
      }
      // 附件下载（POST + 签名）：与现有POST签名方式一致，业务系统集成更简单（§6.4.6）
      if (req.method === 'POST' && pathname === ATTACHMENT_POST_PATH) {
        const rawBody = await readBody(req)
        const caller = runtime.verifier.verify(req.headers, 'POST', pathname, rawBody, runtime.nonceSeen)
        const body = parseJsonBody(rawBody)
        runtime.fileLogger.info('http', `<<< POST ${pathname} OK`, { clientId: caller.clientId, scope: caller.scope })
        await handleAttachmentDownloadPost(runtime, caller, body, res)
        return
      }
      // 其余全部 POST + 签名
      if (req.method !== 'POST') {
        runtime.fileLogger.warn('http', `method not allowed: ${req.method}`, { pathname })
        writeJson(res, 404, { error: { code: 'NOT_FOUND', message: `route not found: ${req.method} ${pathname}`, details: {} } })
        return
      }
      const rawBody = await readBody(req)
      const caller = runtime.verifier.verify(req.headers, 'POST', pathname, rawBody, runtime.nonceSeen)
      const body = parseJsonBody(rawBody)
      runtime.fileLogger.info('http', `<<< ${req.method} ${pathname} OK`, { clientId: caller.clientId, scope: caller.scope })
      await dispatch(runtime, caller, pathname, body, res)
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : String(error)
      runtime.fileLogger.error('http', `<<< ${pathname} FAIL`, { clientId, error: msg })
      sendError(res, error)
    }
  }
}

/** 内部路由分发。 */
async function dispatch(
  runtime: BridgeRuntime,
  caller: { clientId: string; scope: Array<'stream' | 'callback' | 'admin'> },
  pathname: string,
  body: Record<string, unknown>,
  res: ServerResponse,
): Promise<void> {
  const { db, fileLogger } = runtime
  if (pathname === '/bizbridge/api/v1/stream') {
    fileLogger.info('stream', `submit by ${caller.clientId}`, { sessionId: body.session_id, bizId: body.biz_id })
    await handleStreamSubmit(runtime, caller, body, res)
    return
  }
  if (pathname === '/bizbridge/api/v1/callback') {
    fileLogger.info('callback', `submit by ${caller.clientId}`, { sessionId: body.session_id, bizId: body.biz_id })
    await enqueueCallback(runtime, caller, body, res)
    return
  }
  if (pathname === '/bizbridge/api/v1/tasks/list') {
    writeJson(res, 200, listOp(db, caller, body))
    return
  }
  if (pathname === '/bizbridge/api/v1/stats') {
    writeJson(res, 200, statsOp(db, caller))
    return
  }
  if (pathname === '/bizbridge/api/v1/models') {
    fileLogger.info('models', `query by ${caller.clientId}`)
    writeJson(res, 200, await modelsOp(runtime))
    return
  }
  // 模型配置面（§15）：桥接 profile 是 headless，provider 路由由本 profile 的 settings 段供给。
  //   读：实时目录 + 该条目的 settings 状态与来源；
  //   写：`settings.replace` 该段（列出的 route 即完整集合）。
  if (pathname === '/bizbridge/api/v1/admin/models') {
    requireAdmin(caller, 'models configuration')
    fileLogger.info('models-config', `read by ${caller.clientId}`)
    writeJson(res, 200, await readModelsConfig(runtime.llm, runtime.settings, runtime.config.models.settingsNamespace))
    return
  }
  if (pathname === '/bizbridge/api/v1/admin/models/providers') {
    requireAdmin(caller, 'models configuration')
    const expectedRevision = body.expected_revision
    if (expectedRevision !== undefined && (!Number.isSafeInteger(expectedRevision) || (expectedRevision as number) < 0)) {
      throw new InvalidRequestError('expected_revision must be a non-negative safe integer')
    }
    const routes = typeof body.providers === 'object' && body.providers !== null && !Array.isArray(body.providers)
      ? Object.keys(body.providers as Record<string, unknown>)
      : []
    // 只记 route 名：这一段理论上不含密钥（值里是 apiKeyEnv 这类**引用名**），但不赌。
    fileLogger.info('models-config', `write by ${caller.clientId}`, { routes, expectedRevision })
    writeJson(res, 200, await writeModelProviders(
      runtime.llm,
      runtime.settings,
      runtime.config.models.settingsNamespace,
      body.providers,
      expectedRevision as number | undefined,
    ))
    return
  }
  // /bizbridge/api/v1/sessions/<id>/messages
  //   <id> 为内部会话 id（`<clientId>:<type>:<外部 id>`，含冒号）。浏览器侧习惯用
  //   encodeURIComponent 拼接，会把 `:` 编成 `%3A`；这里宽松匹配后再解码，两种写法都接受，
  //   避免"页面能发、路由不认"（2026-09-10 实测：编码形式曾 404 route not found）。
  const sessionMatch = /^\/bizbridge\/api\/v1\/sessions\/([A-Za-z0-9:._%-]{1,512})\/messages$/.exec(pathname)
  if (sessionMatch !== null) {
    const sessionId = decodeSessionIdParam(sessionMatch[1] ?? '')
    if (sessionId !== undefined) {
      fileLogger.info('session-messages', `query by ${caller.clientId}`, { sessionId })
      if (runtime.sessionQuery === undefined) {
        throw new NotImplementedError('sessionQuery service is not available')
      }
      writeJson(res, 200, await sessionMessagesOp(runtime.sessionQuery, sessionId, caller, body))
      return
    }
  }
  // 回调测试：状态查询（需签名；仅 admin 或该任务所属 client，禁止跨 client）
  const cbTestMatch = /^\/bizbridge\/api\/v1\/callback-test\/([A-Za-z0-9_-]{1,128})$/.exec(pathname)
  if (cbTestMatch !== null) {
    handleCallbackTestStatus(runtime, cbTestMatch[1] ?? '', caller, res)
    return
  }
  // /bizbridge/api/v1/tasks/<id>[/logs|cancel|replay|redeliver|priority]
  const match = /^\/bizbridge\/api\/v1\/tasks\/([A-Za-z0-9_-]{1,128})(?:\/(logs|cancel|replay|redeliver|priority))?$/.exec(pathname)
  if (match !== null) {
    const taskId = match[1] ?? ''
    const action = match[2]
    if (action === undefined) {
      writeJson(res, 200, detailOp(db, taskId, caller))
      return
    }
    if (action === 'logs') {
      writeJson(res, 200, logsOp(db, taskId, caller, body))
      return
    }
    if (action === 'replay') {
      fileLogger.info('replay', `task ${taskId} by ${caller.clientId}`)
      writeJson(res, 200, replayOp(db, taskId, caller))
      return
    }
    if (action === 'priority') {
      fileLogger.info('priority', `task ${taskId} by ${caller.clientId}`, { priority: body.priority })
      writeJson(res, 200, priorityOp(db, taskId, caller, body.priority))
      return
    }
    if (action === 'cancel') {
      // 需先读任务以取得 session（agent 取消用），再执行取消（业务级/管理级均可取消处理中任务）
      const task = db.getTask(taskId)
      if (task === undefined) throw new NotFoundError(`task "${taskId}" not found`)
      if (task.client_id !== caller.clientId && !caller.scope.includes('admin')) {
        throw new ForbiddenError(`task "${taskId}" belongs to another client`)
      }
      fileLogger.info('cancel', `task ${taskId} by ${caller.clientId}`, { sessionId: task.session_id, status: task.status })
      const result = cancelOp(db, taskId, caller)
      if (result.needAgentCancel) {
        const cancelled = runtime.hub.cancel(task.session_id, `caller cancelled task ${taskId}`)
        runtime.db.addLog(taskId, 'cancelled', `调用方取消：中止 live agent（${cancelled ? '已通知' : '无活动 turn'}）`, {}, nowIso())
        if (!cancelled) {
          // 处理中但 run 尚未注册（认领窗口）——由调度器执行前的状态复核兜底
          runtime.logger.warn(`cancel task ${taskId}: no active turn found; scheduler re-check guards execution`)
        }
      }
      writeJson(res, 200, result)
      return
    }
    if (action === 'redeliver') {
      fileLogger.info('redeliver', `task ${taskId} by ${caller.clientId}`)
      const result = redeliverOp(db, taskId, caller)
      runtime.db.addLog(taskId, 'callback', result.message, { action: 'redeliver' }, nowIso())
      writeJson(res, 200, result)
      return
    }
  }
  throw new NotFoundError(`route not found: ${pathname}`)
}

/** 查询可用模型列表：从 DSH LLM 运行时读取 provider → model → reasoning efforts。 */
async function modelsOp(runtime: BridgeRuntime): Promise<ModelCatalog> {
  return await collectModelCatalog(runtime.llm)
}

/** 管理面守卫：仅 `admin` scope 可调用（模型配置会改本 profile 的 settings）。 */
function requireAdmin(caller: { clientId: string; scope: readonly string[] }, what: string): void {
  if (!caller.scope.includes('admin')) {
    throw new ForbiddenError(`${what} requires the "admin" scope`)
  }
}

/**
 * 回调响应入队（§3.2 / §6.4.2）：立即返回 task_id + queued。
 *
 * 入站附件在入队前完成拉取落盘（§6.4.4）：业务方给的 URI 常为预签名地址，
 * 拖到调度器执行时可能已过期；此处失败则任务不入库，调用方拿到同步错误。
 */
async function enqueueCallback(
  runtime: BridgeRuntime,
  caller: { clientId: string; scope: Array<'stream' | 'callback' | 'admin'> },
  body: Record<string, unknown>,
  res: ServerResponse,
): Promise<void> {
  const input = validateSubmitInput(caller, 'callback', body, {
    enabled: runtime.config.attachments.enabled,
    maxItems: runtime.config.attachments.maxItems,
    allowedHosts: runtime.config.attachments.allowedHosts,
    denyInternalHosts: runtime.config.attachments.denyInternalHosts,
    allowInternalCallbackHosts: runtime.config.attachments.allowInternalCallbackHosts,
  })
  const sid = internalSessionId(input.clientId, input.sessionId, 'cb')
  const now = nowIso()
  const taskId = randomUUID()
  const prepared = await downloadInbound(runtime, {
    clientId: input.clientId,
    taskId,
    requests: input.attachmentRequests,
  })
  runtime.db.createTask({
    id: taskId,
    clientId: input.clientId,
    bizId: input.bizId,
    replaySeq: 0,
    sessionId: sid,
    prompt: input.prompt,
    type: 'callback',
    params: input.params,
    callbackUrl: input.callbackUrl,
    priority: input.priority ?? 0,
    scheduledAt: now,
    now,
  })
  let inbound: TaskAttachmentRow[]
  try {
    inbound = recordInbound(runtime, { clientId: input.clientId, taskId, prepared })
  } catch (error: unknown) {
    // 登记失败：账本无记录 → 已落盘文件不会被清理，就地回收避免孤儿文件（F9）
    await discardInbound(runtime, { clientId: input.clientId, taskId })
    throw error
  }
  if (inbound.length > 0) {
    runtime.db.addLog(taskId, 'attachments', `入站附件 ${inbound.length} 个已就绪`, {
      attachments: inbound.map(toAttachmentEntry),
    }, now)
  }
  runtime.db.addLog(taskId, 'received', '回调任务已入队', { biz_id: input.bizId, session_id: sid }, now)
  writeJson(res, 200, {
    task_id: taskId,
    status: 'queued',
    message: '任务已入队，等待处理',
    ext: { attachments: inbound.map(toAttachmentEntry) },
  })
}

/**
 * 解析会话消息路径里的 `id`：接受字面量冒号，也接受百分号编码（`:` → `%3A`）。
 * 解码后按 1-128 位 `[A-Za-z0-9:._-]` 重新校验；非法返回 undefined（调用方落到 404）。
 */
function decodeSessionIdParam(raw: string): string | undefined {
  let decoded = raw
  if (raw.includes('%')) {
    try {
      decoded = decodeURIComponent(raw)
    } catch {
      return undefined
    }
  }
  return /^[A-Za-z0-9:._-]{1,128}$/.test(decoded) ? decoded : undefined
}

// ─── 附件下载（§6.4.6） ───

/**
 * GET /bizbridge/api/v1/attachments/<attachment_id>：按附件 ID 返回字节流。
 *
 * 鉴权：签名头（方法 GET、请求体按空串计算摘要）+ 归属校验（admin 或该附件所属
 * client）。只有插件账本里登记过的附件可下载，不接受任意工作区路径——路径穿越
 * 与跨 client 读取都不成立。
 * @param runtime 运行时依赖
 * @param caller 已验签的调用者
 * @param pathname 完整 pathname（含前缀与附件 ID）
 * @param res 响应（成功时为字节流，失败抛 BizError 由上层统一映射）
 */
async function handleAttachmentDownloadGet(
  runtime: BridgeRuntime,
  caller: Caller,
  pathname: string,
  res: ServerResponse,
): Promise<void> {
  const id = pathname.slice(ATTACHMENT_GET_PREFIX.length + 1)
  if (!/^[A-Za-z0-9_-]{1,128}$/.test(id)) {
    throw new NotFoundError(`route not found: ${pathname}`)
  }
  await sendAttachmentBytes(runtime, caller, id, res)
}

/**
 * POST /bizbridge/api/v1/attachments/download：按附件 ID 返回字节流（与现有POST签名方式一致）。
 *
 * 鉴权：签名头（方法 POST、请求体按实际内容计算摘要）+ 归属校验（admin 或该附件所属
 * client）。业务系统集成更简单，无需处理GET请求的特殊签名逻辑。
 * @param runtime 运行时依赖
 * @param caller 已验签的调用者
 * @param body 请求体（需包含 attachment_id 字段）
 * @param res 响应（成功时为字节流，失败抛 BizError 由上层统一映射）
 */
async function handleAttachmentDownloadPost(
  runtime: BridgeRuntime,
  caller: Caller,
  body: Record<string, unknown>,
  res: ServerResponse,
): Promise<void> {
  const id = body.attachment_id
  if (typeof id !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(id)) {
    throw new InvalidRequestError('attachment_id is required and must be 1-128 alphanumeric characters')
  }
  await sendAttachmentBytes(runtime, caller, id, res)
}

/**
 * 附件下载的公共逻辑：归属校验 + 读取字节 + 发送响应。
 * @param runtime 运行时依赖
 * @param caller 已验签的调用者
 * @param attachmentId 附件 ID
 * @param res 响应（成功时为字节流，失败抛 BizError 由上层统一映射）
 */
async function sendAttachmentBytes(
  runtime: BridgeRuntime,
  caller: Caller,
  attachmentId: string,
  res: ServerResponse,
): Promise<void> {
  // 归属判定与任务同构（不存在 404、跨 client 403），放在 ops 层以便单测覆盖
  const row = requireAttachmentOwned(runtime.db, attachmentId, caller)
  let data: Uint8Array
  try {
    data = await readAttachmentBytes(runtime, row)
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : String(error)
    throw new NotFoundError(`attachment "${attachmentId}" is no longer readable: ${message}`)
  }
  // 校验outbound附件的完整性（如果存储了content_hash）
  if (row.content_hash && row.direction === 'outbound') {
    const { createHash } = await import('node:crypto')
    const actualHash = createHash('sha256').update(data).digest('hex')
    if (actualHash !== row.content_hash) {
      runtime.fileLogger.warn('attachments', `integrity check failed for ${attachmentId}`, {
        clientId: caller.clientId, taskId: row.task_id, expected: row.content_hash, actual: actualHash,
      })
      throw new NotFoundError(`attachment "${attachmentId}" has been modified since registration`)
    }
  }
  runtime.fileLogger.info('attachments', `download ${attachmentId}`, {
    clientId: caller.clientId, taskId: row.task_id, bytes: data.byteLength, name: row.name,
  })
  // 文件名可能含非 ASCII：按 RFC 5987 同时给出 filename 与 filename*
  const encoded = encodeURIComponent(row.name)
  res.writeHead(200, {
    'content-type': row.mime ?? 'application/octet-stream',
    'content-length': String(data.byteLength),
    'content-disposition': `attachment; filename="${encoded}"; filename*=UTF-8''${encoded}`,
    'cache-control': 'no-store',
  })
  res.end(Buffer.from(data))
}

// ─── 回调测试接收器（内存存储，仅用于调试页面端到端测试） ───

interface CallbackTestEntry {
  task_id: string
  biz_id: string
  status: string
  result: unknown
  received_at: string
  raw_body: unknown
}

const callbackTestStore = new Map<string, CallbackTestEntry>()
const CALLBACK_TEST_TTL_MS = 30 * 60 * 1000 // 30 分钟自动清理

/**
 * 回调测试接收端点：**仅本插件的调度器可写**。
 *
 * 该端点曾经免签名——任何能连到端口的人都能注入伪造的“回调已到达”，
 * 页面会把它当成真实投递展示（复审 F2）。现在要求携带每次激活随机生成的
 * 内部令牌；令牌从不暴露给客户端，故外部无法写入，而页面“回调追踪”照常工作
 * （投递始终由调度器完成，见 scheduler.postJson）。
 */
function handleCallbackTestReceive(
  runtime: BridgeRuntime,
  headers: IncomingMessage['headers'],
  body: unknown,
  res: ServerResponse,
): void {
  const token = headers[CALLBACK_TEST_TOKEN_HEADER]
  if (typeof token !== 'string' || token !== runtime.callbackTestToken) {
    runtime.fileLogger.warn('callback-test', 'rejected write to callback test receiver: missing/invalid internal token')
    writeJson(res, 403, {
      error: {
        code: 'FORBIDDEN',
        message: 'callback test receiver only accepts deliveries from the bridge scheduler',
        details: {},
      },
    })
    return
  }
  const entry = body as Record<string, unknown>
  const taskId = typeof entry.task_id === 'string' ? entry.task_id : 'unknown'
  const now = new Date().toISOString()
  callbackTestStore.set(taskId, {
    task_id: taskId,
    biz_id: typeof entry.biz_id === 'string' ? entry.biz_id : '',
    status: typeof entry.status === 'string' ? entry.status : 'unknown',
    result: entry.result ?? null,
    received_at: now,
    raw_body: body,
  })
  // 清理过期条目
  const cutoff = Date.now() - CALLBACK_TEST_TTL_MS
  for (const [id, e] of callbackTestStore) {
    if (new Date(e.received_at).getTime() < cutoff) callbackTestStore.delete(id)
  }
  writeJson(res, 200, { ok: true, task_id: taskId, received_at: now })
}

/**
 * 回调测试状态查询：需签名，且仅 `admin` 或**该任务所属 client** 可查（复审 F1）。
 * 归属判定复用 `requireTaskOwned`：admin 放行、非属主 403、任务不存在 404 —— 杜绝跨 client 读取。
 */
function handleCallbackTestStatus(
  runtime: BridgeRuntime,
  taskId: string,
  caller: Caller,
  res: ServerResponse,
): void {
  requireTaskOwned(runtime.db, taskId, caller)
  const entry = callbackTestStore.get(taskId)
  if (entry === undefined) {
    writeJson(res, 200, { task_id: taskId, received: false })
    return
  }
  writeJson(res, 200, { task_id: taskId, received: true, ...entry })
}
