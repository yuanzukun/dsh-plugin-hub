/**
 * 数据存储层（§4）— node:sqlite（DatabaseSync 同步 API）。
 *
 * - 单文件 SQLite，WAL + busy_timeout；表结构/索引/日志见 §4.2/§4.3。
 * - tasks 兼作消息队列：status 表达执行状态，callback_status/next_callback_at
 *   独立表达回调送达状态（两轴分离，§7.4）。
 * - 时间戳统一存 ISO-8601 UTC 字符串（new Date().toISOString()），
 *   等宽格式下字典序即时间序。
 * - 幂等键 UNIQUE(client_id, biz_id, replay_seq)：并发/重复插入映射为
 *   DuplicateBizIdError（§6.3.1 幂等 409 闭环）。
 *
 * 本模块只依赖 Node 内置模块，可单元测试（:memory:）。
 */

import { mkdirSync } from 'node:fs'
import { dirname, isAbsolute, resolve } from 'node:path'
import { DatabaseSync } from 'node:sqlite'
import { DuplicateBizIdError, InvalidRequestError } from '../shared/errors.ts'
import type {
  AttachmentDirection, CallbackStatus, TaskAttachmentRow, TaskLogRow, TaskRow, TaskStatus, TaskType,
} from '../shared/types.ts'

/** 数据库打开选项。 */
export interface BridgeDbOptions {
  /** 文件路径或 ':memory:'；相对路径按 DSH 进程 cwd 解析（设计 §4.1）。 */
  path: string
  journalMode: string
  busyTimeout: number
}

/** ISO 时间工具：nowIso()。 */
export function nowIso(): string {
  return new Date().toISOString()
}

/** 把相对数据库路径解析为绝对路径（':memory:' 除外）。 */
export function resolveDbPath(path: string): string {
  if (path === ':memory:') return path
  return isAbsolute(path) ? path : resolve(process.cwd(), path)
}

interface DbConnection {
  exec(sql: string): void
  prepare(sql: string): {
    run(...params: Array<string | number | null>): { changes: number; lastInsertRowid: number | bigint }
    get(...params: Array<string | number | null>): Record<string, unknown> | undefined
    all(...params: Array<string | number | null>): Array<Record<string, unknown>>
  }
}

const VALID_STATUSES: readonly TaskStatus[] = [
  'queued', 'received', 'processing', 'completed', 'failed', 'callback_failed', 'cancelled',
]
const VALID_CALLBACK_STATUSES: readonly CallbackStatus[] = ['pending', 'retrying', 'succeeded', 'exhausted']

/** 数据库句柄：封装 schema、事务与全部任务/日志原语。 */
export class BridgeDb {
  private readonly conn: DbConnection

  constructor(options: BridgeDbOptions) {
    const resolved = resolveDbPath(options.path)
    if (resolved !== ':memory:') {
      mkdirSync(dirname(resolved), { recursive: true })
    }
    // eslint-disable-next-line @typescript-eslint/no-require-imports -- node:sqlite 无默认导出类型
    const module = DatabaseSync as unknown as new (path: string) => DbConnection
    this.conn = new module(resolved)
    this.conn.exec(`PRAGMA journal_mode = ${options.journalMode}`)
    this.conn.exec(`PRAGMA busy_timeout = ${options.busyTimeout}`)
    this.migrate()
  }

  /** 关闭数据库连接。 */
  close(): void {
    const closer = this.conn as unknown as { close(): void }
    closer.close()
  }

  /**
   * 幂等建表 + 索引（§4.2/§4.3）。表与列的 `--` 中文注释即结构文档，改动列时同步维护。
   */
  private migrate(): void {
    this.conn.exec(`
      -- tasks：任务信息表，兼作消息队列（§4.2.1）。
      -- 两轴分离：status = 执行状态轴；callback_status = 回调送达状态轴（仅 callback 类型，§7.4）。
      -- 结果全文独立存 task_results（§4.2.3），本表仅保留 usage 等轻量摘要列，避免大文本膨胀热路径查询行。
      CREATE TABLE IF NOT EXISTS tasks (
        id               TEXT PRIMARY KEY,          -- 任务唯一 ID（UUID）
        client_id        TEXT NOT NULL,             -- 客户端标识（签名认证主体，§6.2.4）
        biz_id           TEXT NOT NULL,             -- 业务请求幂等键（与 client_id、replay_seq 组合唯一，§6.3.1）
        replay_seq       INTEGER NOT NULL DEFAULT 0,-- 重播序号（原始任务为 0，每次重播 +1）
        session_id       TEXT NOT NULL,             -- DSH agent 会话 ID（内部为 clientId:type:sessionId 三段式）
        prompt           TEXT NOT NULL DEFAULT '',  -- 请求内容（用户提交的 prompt 原文）
        type             TEXT NOT NULL CHECK (type IN ('stream','callback')),   -- 任务类型：stream=流式响应 / callback=回调响应
        status           TEXT NOT NULL CHECK (status IN ('queued','received','processing','completed','failed','callback_failed','cancelled')), -- 执行状态轴（§7.4）
        params           TEXT,                      -- 附加参数 JSON（agent 覆盖项、tools 等，§6.4）
        callback_url     TEXT,                      -- 回调地址（仅 callback 类型）
        usage            TEXT,                      -- token 用量 JSON（最后一次 assistant/message 的 usage，完成时写入，监测用）
        error_message    TEXT,                      -- 错误信息（failed / cancelled 时写入）
        retry_count      INTEGER NOT NULL DEFAULT 0,-- 回调送达重试次数（§7.4）
        callback_status  TEXT CHECK (callback_status IN ('pending','retrying','succeeded','exhausted')), -- 回调送达状态轴（仅 callback 类型，§7.4）
        next_callback_at TEXT,                      -- 下次回调尝试时间（ISO-8601 UTC）
        priority         INTEGER NOT NULL DEFAULT 0,-- 队列优先级（数字越小越优先；仅 callback 入队时有效）
        scheduled_at     TEXT,                      -- 计划消费时间（仅 callback；默认等于 created_at）
        locked_at        TEXT,                      -- 调度器乐观锁抢占时间（processing 期间非空，§7.2）
        created_at       TEXT NOT NULL,             -- 创建时间（ISO-8601 UTC）
        updated_at       TEXT NOT NULL,             -- 最近更新时间（ISO-8601 UTC）
        completed_at     TEXT                       -- 完成时间（进入终态时写入，ISO-8601 UTC）
      );
      CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
      CREATE INDEX IF NOT EXISTS idx_tasks_type ON tasks(type);
      CREATE INDEX IF NOT EXISTS idx_tasks_biz_id ON tasks(biz_id);
      CREATE UNIQUE INDEX IF NOT EXISTS idx_tasks_biz_replay ON tasks(client_id, biz_id, replay_seq);
      CREATE INDEX IF NOT EXISTS idx_tasks_client_id ON tasks(client_id);
      CREATE INDEX IF NOT EXISTS idx_tasks_session_id ON tasks(session_id);
      CREATE INDEX IF NOT EXISTS idx_tasks_queue ON tasks(type, status, priority, scheduled_at);
      CREATE INDEX IF NOT EXISTS idx_tasks_callback ON tasks(type, status, callback_status, next_callback_at);
      -- task_logs：任务流水日志表（§4.2.2）。记录任务从接收到终态的各阶段事件，含分块文本与扩展元数据。
      CREATE TABLE IF NOT EXISTS task_logs (
        id         INTEGER PRIMARY KEY AUTOINCREMENT, -- 自增主键
        task_id    TEXT NOT NULL,                   -- 关联任务 ID（tasks.id）
        stage      TEXT NOT NULL,                   -- 阶段标识：received / processing / chunk / callback / completed / failed / cancelled
        message    TEXT,                            -- 日志内容
        metadata   TEXT,                            -- 扩展元数据 JSON（turn、usage、reason、http_status 等）
        created_at TEXT NOT NULL                    -- 日志时间（ISO-8601 UTC）
      );
      CREATE INDEX IF NOT EXISTS idx_task_logs_task_id ON task_logs(task_id);
      -- task_results：任务结果全文表（§4.2.3）。大文本与 tasks 热路径行解耦（1:1），列表/队列查询不加载全文。
      CREATE TABLE IF NOT EXISTS task_results (
        task_id    TEXT PRIMARY KEY REFERENCES tasks(id), -- 关联任务 ID（与 tasks 1:1）
        result     TEXT NOT NULL,                   -- 结果全文（text-delta 按事件序拼接，§5.5）
        created_at TEXT NOT NULL                    -- 写入时间（ISO-8601 UTC）
      );
      -- task_attachments：附件账本（§4.2.4）。入站=业务方 URI 拉取落盘后的记录；
      -- 出站=agent 在本 client 工作目录内产出的文件。rel_path 是相对该 client
      -- 工作目录的 POSIX 路径，下载接口与执行期附件准入都以它为唯一依据；
      -- 字节与 DSH 附件库引用都不在此表（内容寻址，按需重新准入）。
      CREATE TABLE IF NOT EXISTS task_attachments (
        id           TEXT PRIMARY KEY,               -- 附件 ID（UUID，对外暴露的下载标识）
        task_id      TEXT NOT NULL,                  -- 关联任务 ID（tasks.id）
        client_id    TEXT NOT NULL,                  -- 归属 client（下载越权判定的依据）
        direction    TEXT NOT NULL CHECK (direction IN ('inbound','outbound')), -- 方向：入站/出站
        name         TEXT NOT NULL,                  -- 展示名（已净化，不含路径）
        mime         TEXT,                           -- 媒体类型（未知为 NULL）
        bytes        INTEGER NOT NULL,               -- 字节数
        rel_path     TEXT NOT NULL,                  -- 相对 client 工作目录的 POSIX 路径
        source_uri   TEXT,                           -- 入站来源 URI（出站为 NULL）
        content_hash TEXT,                           -- 内容 SHA256 哈希（出站附件有值，入站为 NULL；用于完整性校验）
        created_at   TEXT NOT NULL                   -- 登记时间（ISO-8601 UTC）
      );
      CREATE INDEX IF NOT EXISTS idx_task_attachments_task ON task_attachments(task_id);
      CREATE INDEX IF NOT EXISTS idx_task_attachments_client ON task_attachments(client_id);
    `)
    // 增量迁移：`CREATE TABLE IF NOT EXISTS` 不会给**已存在**的表补列，存量库直接升级会
    // 因缺列而使全部附件登记 500。此处按需 ALTER。
    this.ensureColumn('task_attachments', 'content_hash', 'TEXT')
  }

  /**
   * 幂等补列：表已存在且缺该列时执行 `ALTER TABLE ADD COLUMN`。
   * @param table 表名（内部常量，非外部输入）
   * @param column 列名
   * @param ddl 列定义（如 `TEXT` / `INTEGER NOT NULL DEFAULT 0`）
   */
  private ensureColumn(table: string, column: string, ddl: string): void {
    const columns = this.conn.prepare(`PRAGMA table_info(${table})`).all() as unknown as Array<{ name?: unknown }>
    if (columns.length === 0) return // 表不存在（理论上不会走到这里）
    if (columns.some(entry => String(entry.name) === column)) return
    this.conn.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${ddl}`)
  }

  /** 行 → TaskRow（DB 行键 snake_case）。 */
  private mapTask(row: Record<string, unknown> | undefined): TaskRow | undefined {
    if (row === undefined) return undefined
    return {
      id: String(row.id),
      client_id: String(row.client_id),
      biz_id: String(row.biz_id),
      replay_seq: Number(row.replay_seq),
      session_id: String(row.session_id),
      prompt: String(row.prompt ?? ''),
      type: String(row.type) as TaskType,
      status: String(row.status) as TaskStatus,
      params: row.params === null || row.params === undefined ? null : String(row.params),
      callback_url: row.callback_url === null || row.callback_url === undefined ? null : String(row.callback_url),
      usage: row.usage === null || row.usage === undefined ? null : String(row.usage),
      error_message: row.error_message === null || row.error_message === undefined ? null : String(row.error_message),
      retry_count: Number(row.retry_count ?? 0),
      callback_status: row.callback_status === null || row.callback_status === undefined
        ? null
        : String(row.callback_status) as CallbackStatus,
      next_callback_at: row.next_callback_at === null || row.next_callback_at === undefined ? null : String(row.next_callback_at),
      priority: Number(row.priority ?? 0),
      scheduled_at: row.scheduled_at === null || row.scheduled_at === undefined ? null : String(row.scheduled_at),
      locked_at: row.locked_at === null || row.locked_at === undefined ? null : String(row.locked_at),
      created_at: String(row.created_at),
      updated_at: String(row.updated_at),
      completed_at: row.completed_at === null || row.completed_at === undefined ? null : String(row.completed_at),
    }
  }

  /** 唯一键冲突归一化：查 existing 行抛 DuplicateBizIdError（§6.3.1）。 */
  private raiseDuplicateOrRethrow(error: unknown, clientId: string, bizId: string, replaySeq: number): never {
    const message = error instanceof Error ? error.message : String(error)
    if (message.includes('UNIQUE constraint failed')) {
      const existing = this.getTaskByBizKey(clientId, bizId, replaySeq)
      if (existing !== undefined) {
        throw new DuplicateBizIdError(
          `biz_id "${bizId}" already submitted (replay_seq=${existing.replay_seq}, status=${existing.status})`,
          {
            existing_task_id: existing.id,
            existing_replay_seq: existing.replay_seq,
            existing_status: existing.status,
          },
        )
      }
      throw new DuplicateBizIdError(`biz_id "${bizId}" conflicts with an existing submission`, {
        existing_task_id: '',
        existing_replay_seq: replaySeq,
        existing_status: '',
      })
    }
    throw error
  }

  /** 新增任务（含幂等冲突归一化）。stream 任务直接以 received 入库。 */
  createTask(input: {
    id: string
    clientId: string
    bizId: string
    replaySeq: number
    sessionId: string
    prompt: string
    type: TaskType
    params?: Record<string, unknown>
    callbackUrl?: string
    priority: number
    scheduledAt: string
    now: string
  }): TaskRow {
    try {
      this.conn.prepare(`
        INSERT INTO tasks (
          id, client_id, biz_id, replay_seq, session_id, prompt, type, status,
          params, callback_url, priority, scheduled_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        input.id,
        input.clientId,
        input.bizId,
        input.replaySeq,
        input.sessionId,
        input.prompt,
        input.type,
        input.type === 'stream' ? 'received' : 'queued',
        input.params === undefined ? null : JSON.stringify(input.params),
        input.callbackUrl ?? null,
        input.priority,
        input.scheduledAt,
        input.now,
        input.now,
      )
    } catch (error: unknown) {
      this.raiseDuplicateOrRethrow(error, input.clientId, input.bizId, input.replaySeq)
    }
    const row = this.getTask(input.id)
    if (row === undefined) throw new Error('dsh-biz-bridge: task insert succeeded but read-back failed')
    return row
  }

  /** 流式任务进入处理中（received→processing，SSE 转发前置，§3.1）。 */
  markProcessing(taskId: string, now: string): boolean {
    return this.transition(taskId, 'received', 'processing', now) === 1
  }

  /** 通用乐观状态迁移：仅当当前状态匹配时生效（终态守护）。 */
  transition(taskId: string, from: TaskStatus, to: TaskStatus, now: string): number {
    return this.conn.prepare(
      'UPDATE tasks SET status = ?, updated_at = ? WHERE id = ? AND status = ?',
    ).run(to, now, taskId, from).changes
  }

  /** 设置任务完成：completed + usage 写入 tasks + 可选 completed_at；result 全文写 task_results；回调任务同时武装送达状态机。 */
  completeTask(
    taskId: string,
    input: { result: string; usage?: Record<string, unknown> | null; isCallback: boolean; now: string },
  ): void {
    // usage JSON 落 tasks.usage（token 用量监测，§4.2.1）；无用量时置 NULL。
    const usageJson = input.usage === null || input.usage === undefined ? null : JSON.stringify(input.usage)
    const sql = input.isCallback
      ? `UPDATE tasks SET status='completed', completed_at=?, updated_at=?, usage=?,
           callback_status='pending', next_callback_at=? WHERE id=? AND status='processing'`
      : `UPDATE tasks SET status='completed', completed_at=?, updated_at=?, usage=?
         WHERE id=? AND status='processing'`
    const params: Array<string | null> = [input.now, input.now, usageJson]
    if (input.isCallback) {
      this.conn.prepare(sql).run(...params, input.now, taskId)
    } else {
      this.conn.prepare(sql).run(...params, taskId)
    }
    // result 大文本写入独立表，避免主表膨胀影响热路径查询
    if (input.result !== '') {
      this.conn.prepare(
        'INSERT OR REPLACE INTO task_results (task_id, result, created_at) VALUES (?, ?, ?)',
      ).run(taskId, input.result, input.now)
    }
  }

  /** 设置任务失败（执行性错误，§9）。 */
  failTask(taskId: string, errorMessage: string, now: string): void {
    this.conn.prepare(
      `UPDATE tasks SET status='failed', error_message=?, updated_at=?, completed_at=?
       WHERE id=? AND status IN ('processing','received','queued')`,
    ).run(errorMessage, now, now, taskId)
  }

  /**
   * 回调任务"再次触发回调"（§6.5.8）：把已完成执行（completed / callback_failed）的
   * 回调任务重新武装送达状态机——status 归位 completed、callback_status='pending'、
   * next_callback_at=now、retry_count 清零，调度器下一轮 pump 即重新 POST。
   * @returns 影响行数（0 = 类型/状态不符或缺少 callback_url）
   */
  armRedelivery(taskId: string, now: string): number {
    return this.conn.prepare(
      `UPDATE tasks
         SET status='completed', callback_status='pending', next_callback_at=?, retry_count=0, updated_at=?
       WHERE id=? AND type='callback' AND status IN ('completed','callback_failed') AND callback_url IS NOT NULL`,
    ).run(now, now, taskId).changes
  }

  /** 优先级调整（§6.5.6，仅 queued）；返回影响行数（0 = 状态已变）。 */
  updatePriority(taskId: string, priority: number): number {
    return this.conn.prepare(
      `UPDATE tasks SET priority=?, updated_at=? WHERE id=? AND status='queued'`,
    ).run(priority, nowIso(), taskId).changes
  }

  /** 设置任务取消（断连取消/管理取消/会话忙放弃；仅未完成状态可取消，§6.5.4）。 */
  cancelTask(taskId: string, message: string, now: string, from?: TaskStatus[]): number {
    if (from !== undefined) {
      const marks = from.map(() => '?').join(',')
      return this.conn.prepare(
        `UPDATE tasks SET status='cancelled', error_message=?, updated_at=?, completed_at=?
         WHERE id=? AND status IN (${marks})`,
      ).run(message, now, now, taskId, ...from).changes
    }
    return this.conn.prepare(
      `UPDATE tasks SET status='cancelled', error_message=?, updated_at=?, completed_at=?
       WHERE id=? AND status IN ('queued','received','processing')`,
    ).run(message, now, now, taskId).changes
  }

  /** 回调任务完成后的送达认领——pending 一次尝试（无锁单进程；配送器另有内存互斥）。 */
  getDeliveryCandidate(now: string): TaskRow | undefined {
    const rows = this.conn.prepare(`
      SELECT * FROM tasks
      WHERE type='callback' AND status='completed'
        AND callback_status IN ('pending','retrying')
        AND next_callback_at IS NOT NULL AND next_callback_at <= ?
      ORDER BY next_callback_at ASC, id ASC
      LIMIT 1
    `).all(now)
    return rows[0] === undefined ? undefined : this.mapTask(rows[0])
  }

  /** 回调执行队列认领（乐观锁：queued→processing，仅回调）。返回认领行或 undefined。 */
  claimQueuedCallback(now: string): TaskRow | undefined {
    const row = this.conn.prepare(`
      SELECT * FROM tasks
      WHERE type='callback' AND status='queued' AND scheduled_at <= ?
      ORDER BY priority ASC, scheduled_at ASC, created_at ASC, id ASC
      LIMIT 1
    `).get(now)
    const candidate = this.mapTask(row as Record<string, unknown> | undefined)
    if (candidate === undefined) return undefined
    const claimed = this.conn.prepare(
      `UPDATE tasks SET status='processing', locked_at=?, updated_at=?
       WHERE id=? AND status='queued'`,
    ).run(now, now, candidate.id).changes
    if (claimed === 0) return undefined
    const fresh = this.getTask(candidate.id)
    return fresh
  }

  /** 队列前 N 个候选（按 §7.2 排序），供调度器做会话串行筛选后定点认领。 */
  peekQueuedCallbacks(now: string, limit = 16): TaskRow[] {
    const rows = this.conn.prepare(`
      SELECT * FROM tasks
      WHERE type='callback' AND status='queued' AND scheduled_at <= ?
      ORDER BY priority ASC, scheduled_at ASC, created_at ASC, id ASC
      LIMIT ?
    `).all(now, limit) as Array<Record<string, unknown>>
    return rows.map(row => this.mapTask(row) as TaskRow)
  }

  /** 定点认领（乐观锁），成功返回 true。 */
  claimSpecific(taskId: string, now: string): boolean {
    return this.conn.prepare(
      `UPDATE tasks SET status='processing', locked_at=?, updated_at=?
       WHERE id=? AND status='queued'`,
    ).run(now, now, taskId).changes === 1
  }

  /** 会话是否已有进行中任务（§5.8 串行化双查之一：tasks 表 processing 行）。 */
  hasActiveForSession(sessionId: string, excludeTaskId?: string): boolean {
    if (excludeTaskId === undefined) {
      const row = this.conn.prepare(
        'SELECT COUNT(*) AS c FROM tasks WHERE session_id = ? AND status = \'processing\'',
      ).get(sessionId)
      return Number((row as { c: number }).c ?? 0) > 0
    }
    const row = this.conn.prepare(
      "SELECT COUNT(*) AS c FROM tasks WHERE session_id = ? AND status = 'processing' AND id <> ?",
    ).get(sessionId, excludeTaskId)
    return Number((row as { c: number }).c ?? 0) > 0
  }

  /** 认领后因会话忙回滚（乐观条件回滚，§7.2 步骤 2）。 */
  releaseClaim(taskId: string, lockedAt: string, now: string): void {
    this.conn.prepare(
      `UPDATE tasks SET status='queued', locked_at=NULL, updated_at=?
       WHERE id=? AND status='processing' AND locked_at=?`,
    ).run(now, taskId, lockedAt)
  }

  /**
   * 回调送达结果落库（§7.4 状态机）：
   * @returns 新 callback_status（'succeeded' | 'retrying' | 'exhausted'）
   */
  recordCallbackResult(
    taskId: string,
    input: { ok: boolean; retryCount: number; maxRetry: number; retryIntervalSeconds: number; now: string },
  ): CallbackStatus {
    if (input.ok) {
      this.conn.prepare(
        `UPDATE tasks SET callback_status='succeeded', retry_count=?, updated_at=?
         WHERE id=? AND status='completed' AND callback_status IN ('pending','retrying')`,
      ).run(input.retryCount, input.now, taskId)
      return 'succeeded'
    }
    const next: CallbackStatus = input.retryCount <= input.maxRetry ? 'retrying' : 'exhausted'
    if (next === 'exhausted') {
      this.conn.prepare(
        `UPDATE tasks SET callback_status='exhausted', status='callback_failed', retry_count=?, updated_at=?
         WHERE id=? AND status='completed'`,
      ).run(input.retryCount, input.now, taskId)
    } else {
      const waitMs = input.retryIntervalSeconds * 1000
      const nextAt = new Date(Date.now() + waitMs).toISOString()
      this.conn.prepare(
        `UPDATE tasks SET callback_status='retrying', retry_count=?, next_callback_at=?, updated_at=?
         WHERE id=? AND status='completed'`,
      ).run(input.retryCount, nextAt, input.now, taskId)
    }
    return next
  }

  /** 读任务。 */
  getTask(taskId: string): TaskRow | undefined {
    return this.mapTask(this.conn.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId) as Record<string, unknown> | undefined)
  }

  /** 读任务结果（从 task_results 表，大文本不随主查询加载）。 */
  getTaskResult(taskId: string): string | null {
    const row = this.conn.prepare('SELECT result FROM task_results WHERE task_id = ?').get(taskId) as { result?: string } | undefined
    return row?.result ?? null
  }

  /** 登记一条附件账本记录（§4.2.4）。 */
  addTaskAttachment(input: {
    id: string
    taskId: string
    clientId: string
    direction: AttachmentDirection
    name: string
    mime: string | null
    bytes: number
    relPath: string
    sourceUri: string | null
    contentHash?: string | null
    now: string
  }): TaskAttachmentRow {
    this.conn.prepare(`
      INSERT INTO task_attachments (
        id, task_id, client_id, direction, name, mime, bytes, rel_path, source_uri, content_hash, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      input.id,
      input.taskId,
      input.clientId,
      input.direction,
      input.name,
      input.mime,
      input.bytes,
      input.relPath,
      input.sourceUri,
      input.contentHash ?? null,
      input.now,
    )
    const row = this.getTaskAttachment(input.id)
    if (row === undefined) throw new Error('dsh-biz-bridge: attachment insert succeeded but read-back failed')
    return row
  }

  /** 读单条附件（下载接口的归属校验与读取入口）。 */
  getTaskAttachment(id: string): TaskAttachmentRow | undefined {
    return this.mapTaskAttachment(
      this.conn.prepare('SELECT * FROM task_attachments WHERE id = ?').get(id) as Record<string, unknown> | undefined,
    )
  }

  /**
   * 某任务的附件清单。
   * 顺序 = 登记顺序（隐式 rowid）：入站附件的顺序决定模型看到的图片顺序，必须稳定。
   */
  listTaskAttachments(taskId: string): TaskAttachmentRow[] {
    const rows = this.conn.prepare(
      'SELECT * FROM task_attachments WHERE task_id = ? ORDER BY rowid ASC',
    ).all(taskId) as Array<Record<string, unknown>>
    return rows.map(row => this.mapTaskAttachment(row) as TaskAttachmentRow)
  }

  /**
   * 把源任务的入站附件复制到新任务（replay 用）。
   * 只复制账本行、不复制字节：文件仍在原落盘目录，按 rel_path 可继续读取。
   * @returns 复制的行数
   */
  copyInboundAttachments(
    fromTaskId: string,
    toTaskId: string,
    newId: () => string,
    now: string,
  ): number {
    const rows = this.conn.prepare(
      "SELECT * FROM task_attachments WHERE task_id = ? AND direction = 'inbound' ORDER BY rowid ASC",
    ).all(fromTaskId) as Array<Record<string, unknown>>
    for (const row of rows) {
      const mapped = this.mapTaskAttachment(row) as TaskAttachmentRow
      this.addTaskAttachment({
        id: newId(),
        taskId: toTaskId,
        clientId: mapped.client_id,
        direction: 'inbound',
        name: mapped.name,
        mime: mapped.mime,
        bytes: mapped.bytes,
        relPath: mapped.rel_path,
        sourceUri: mapped.source_uri,
        now,
      })
    }
    return rows.length
  }

  /** 行 → TaskAttachmentRow。 */
  private mapTaskAttachment(row: Record<string, unknown> | undefined): TaskAttachmentRow | undefined {
    if (row === undefined) return undefined
    return {
      id: String(row.id),
      task_id: String(row.task_id),
      client_id: String(row.client_id),
      direction: String(row.direction) as AttachmentDirection,
      name: String(row.name),
      mime: row.mime === null || row.mime === undefined ? null : String(row.mime),
      bytes: Number(row.bytes),
      rel_path: String(row.rel_path),
      source_uri: row.source_uri === null || row.source_uri === undefined ? null : String(row.source_uri),
      content_hash: row.content_hash === null || row.content_hash === undefined ? null : String(row.content_hash),
      created_at: String(row.created_at),
    }
  }

  /** 按幂等键读任务。 */
  getTaskByBizKey(clientId: string, bizId: string, replaySeq: number): TaskRow | undefined {
    return this.mapTask(this.conn.prepare(
      'SELECT * FROM tasks WHERE client_id = ? AND biz_id = ? AND replay_seq = ?',
    ).get(clientId, bizId, replaySeq) as Record<string, unknown> | undefined)
  }

  /** 某 (client_id, biz_id) 下当前最大 replay_seq（无记录为 0）。重播取此 + 1，避免撞唯一键。 */
  maxReplaySeq(clientId: string, bizId: string): number {
    const row = this.conn.prepare(
      'SELECT COALESCE(MAX(replay_seq), 0) AS m FROM tasks WHERE client_id = ? AND biz_id = ?',
    ).get(clientId, bizId) as { m: number } | undefined
    return Number(row?.m ?? 0)
  }

  /** 任务分页查询（§6.5.1）。 */
  listTasks(filter: {
    status?: TaskStatus
    type?: TaskType
    clientId?: string
    bizId?: string
    startTime?: string
    endTime?: string
    page: number
    pageSize: number
  }): { total: number; tasks: TaskRow[] } {
    const where: string[] = []
    const params: Array<string | number> = []
    const push = (sql: string, value: string): void => {
      where.push(sql)
      params.push(value)
    }
    if (filter.status !== undefined) push('status = ?', filter.status)
    if (filter.type !== undefined) push('type = ?', filter.type)
    if (filter.clientId !== undefined) push('client_id = ?', filter.clientId)
    if (filter.bizId !== undefined) push('biz_id = ?', filter.bizId)
    if (filter.startTime !== undefined) push('created_at >= ?', filter.startTime)
    if (filter.endTime !== undefined) push('created_at <= ?', filter.endTime)
    const whereSql = where.length === 0 ? '' : ` WHERE ${where.join(' AND ')}`
    const totalRow = this.conn.prepare(`SELECT COUNT(*) AS c FROM tasks${whereSql}`).get(...params)
    const total = Number((totalRow as { c: number }).c ?? 0)
    const offset = (filter.page - 1) * filter.pageSize
    const rows = this.conn.prepare(
      `SELECT * FROM tasks${whereSql} ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?`,
    ).all(...params, filter.pageSize, offset) as Array<Record<string, unknown>>
    return { total, tasks: rows.map(row => this.mapTask(row) as TaskRow) }
  }

  /** 任务日志分页（§6.5.3）。 */
  listLogs(taskId: string, page: number, pageSize: number): { total: number; logs: TaskLogRow[] } {
    const totalRow = this.conn.prepare(
      'SELECT COUNT(*) AS c FROM task_logs WHERE task_id = ?',
    ).get(taskId)
    const total = Number((totalRow as { c: number }).c ?? 0)
    const offset = (page - 1) * pageSize
    const rows = this.conn.prepare(
      'SELECT * FROM task_logs WHERE task_id = ? ORDER BY id ASC LIMIT ? OFFSET ?',
    ).all(taskId, pageSize, offset) as Array<Record<string, unknown>>
    const logs: TaskLogRow[] = rows.map(row => ({
      id: Number(row.id),
      task_id: String(row.task_id),
      stage: String(row.stage),
      message: row.message === null || row.message === undefined ? null : String(row.message),
      metadata: row.metadata === null || row.metadata === undefined ? null : String(row.metadata),
      created_at: String(row.created_at),
    }))
    return { total, logs }
  }

  /** 取某阶段最后一条日志（回调体 usage 读取等场景用）。 */
  lastLogOfStage(taskId: string, stage: string): TaskLogRow | null {
    const row = this.conn.prepare(
      'SELECT * FROM task_logs WHERE task_id = ? AND stage = ? ORDER BY id DESC LIMIT 1',
    ).get(taskId, stage) as Record<string, unknown> | undefined
    if (row === undefined) return null
    return {
      id: Number(row.id),
      task_id: String(row.task_id),
      stage: String(row.stage),
      message: row.message === null || row.message === undefined ? null : String(row.message),
      metadata: row.metadata === null || row.metadata === undefined ? null : String(row.metadata),
      created_at: String(row.created_at),
    }
  }

  /** 追加任务日志（§4.2.2）。 */
  addLog(taskId: string, stage: string, message: string, metadata?: Record<string, unknown>, now?: string): void {
    this.conn.prepare(
      'INSERT INTO task_logs (task_id, stage, message, metadata, created_at) VALUES (?, ?, ?, ?, ?)',
    ).run(
      taskId,
      stage,
      message,
      metadata === undefined ? null : JSON.stringify(metadata),
      now ?? nowIso(),
    )
  }

  /** 全部 processing 任务快照（激活时救援用，§7.3）。 */
  listProcessingTasks(): TaskRow[] {
    const rows = this.conn.prepare(
      "SELECT * FROM tasks WHERE status = 'processing' ORDER BY created_at ASC, id ASC",
    ).all() as Array<Record<string, unknown>>
    return rows.map(row => this.mapTask(row) as TaskRow)
  }

  /** 清理超过 retentionDays 天的终态任务及其日志和结果（默认 90 天）。返回清理的任务数。 */
  cleanupExpired(retentionDays = 90): number {
    const cutoff = new Date(Date.now() - retentionDays * 86_400_000).toISOString()
    // 1. 删除过期 task_logs（先删子表，避免外键约束问题）
    const expiredTaskIds = this.conn.prepare(
      `SELECT id FROM tasks WHERE created_at < ? AND status IN ('completed','failed','callback_failed','cancelled')`,
    ).all(cutoff) as Array<{ id: string }>
    if (expiredTaskIds.length === 0) return 0
    const ids = expiredTaskIds.map(r => r.id)
    const marks = ids.map(() => '?').join(',')
    this.conn.prepare(`DELETE FROM task_logs WHERE task_id IN (${marks})`).run(...ids)
    this.conn.prepare(`DELETE FROM task_results WHERE task_id IN (${marks})`).run(...ids)
    this.conn.prepare(`DELETE FROM task_attachments WHERE task_id IN (${marks})`).run(...ids)
    // 2. 删除过期 tasks
    this.conn.prepare(
      `DELETE FROM tasks WHERE created_at < ? AND status IN ('completed','failed','callback_failed','cancelled')`,
    ).run(cutoff)
    // 3. 回收空间（温和模式，不阻塞写入）
    try {
      this.conn.exec('PRAGMA incremental_vacuum')
    } catch {
      // incremental_vacuum 需要先设置 auto_vacuum=INCREMENTAL，失败时忽略
    }
    return expiredTaskIds.length
  }

  /** 统计（§6.5.7）。scope 非 admin 时限定 clientId。 */
  stats(input: { isAdmin: boolean; clientId?: string }): {
    tasks: { stream: { total: number; success: number; failed: number }; callback: { total: number; success: number; failed: number } }
    queue: { queued: number; processing: number }
    callback: { callback_failed: number; avg_retry_count: number }
  } {
    const clientWhere = input.isAdmin ? '' : ' AND client_id = ?'
    const clientParam: Array<string> = input.isAdmin ? [] : [input.clientId ?? '']
    const scoped = (sql: string, params: Array<string>): number => {
      const row = this.conn.prepare(sql).get(...params)
      return Number((row as { c: number }).c ?? 0)
    }
    const countStatus = (type: TaskType, statuses: TaskStatus[]): number => {
      const marks = statuses.map(() => '?').join(',')
      const params: Array<string> = [type, ...statuses, ...clientParam]
      return scoped(
        `SELECT COUNT(*) AS c FROM tasks WHERE type=? AND status IN (${marks})${clientWhere}`,
        params,
      )
    }
    // 口径（§6.5.7 / v0.9）：success = completed；failed = failed + callback_failed；
    // cancelled 不计入分母；total = success + failed（进行中/排队单列 queue 维度）。
    const streamSuccess = countStatus('stream', ['completed'])
    const callbackSuccess = countStatus('callback', ['completed'])
    const streamFailed = countStatus('stream', ['failed'])
    const callbackFailed = countStatus('callback', ['failed', 'callback_failed'])
    const streamTotal = streamSuccess + streamFailed
    const callbackTotal = callbackSuccess + callbackFailed
    const queued = scoped(`SELECT COUNT(*) AS c FROM tasks WHERE status='queued'${clientWhere}`, clientParam)
    const processing = scoped(`SELECT COUNT(*) AS c FROM tasks WHERE status='processing'${clientWhere}`, clientParam)
    const callbackFailedTotal = countStatus('callback', ['callback_failed'])
    const retryRow = this.conn.prepare(
      `SELECT COALESCE(AVG(retry_count), 0) AS avg FROM tasks WHERE type='callback' AND callback_status IS NOT NULL${clientWhere}`,
    ).get(...clientParam) as { avg: number }
    return {
      tasks: {
        stream: { total: streamTotal, success: streamSuccess, failed: streamFailed },
        callback: { total: callbackTotal, success: callbackSuccess, failed: callbackFailed },
      },
      queue: { queued, processing },
      callback: { callback_failed: callbackFailedTotal, avg_retry_count: Number(retryRow.avg ?? 0) },
    }
  }
}

/** 打开数据库（工厂函数；入口与工具统一走此 API）。 */
export function openBridgeDb(options: BridgeDbOptions): BridgeDb {
  return new BridgeDb(options)
}

/** 分页参数校验（page_size 默认 20、最大 100，§6.3.1）。 */
export function resolvePage(pageInput: unknown, pageSizeInput: unknown): { page: number; pageSize: number } {
  const page = pageInput === undefined || pageInput === null ? 1 : Number(pageInput)
  const pageSize = pageSizeInput === undefined || pageSizeInput === null ? 20 : Number(pageSizeInput)
  if (!Number.isSafeInteger(page) || page < 1) throw new InvalidRequestError('page must be a positive integer')
  if (!Number.isSafeInteger(pageSize) || pageSize < 1 || pageSize > 100) {
    throw new InvalidRequestError('page_size must be an integer between 1 and 100')
  }
  return { page, pageSize }
}

/** 时间筛选值归一化：接受 'YYYY-MM-DD'（当日 00:00:00.000Z）或完整 ISO 串。 */
export function normalizeTimeFilter(value: string, name: string): string {
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return `${value}T00:00:00.000Z`
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) {
    throw new InvalidRequestError(`${name} must be a date (YYYY-MM-DD) or ISO-8601 datetime`)
  }
  return date.toISOString()
}

/** 客户端标识 / biz_id / session_id 格式校验（§6.4：^[A-Za-z0-9_-]{1,128}$）。 */
export function assertWireId(value: string, name: string): void {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(value)) {
    throw new InvalidRequestError(
      `${name} must match ^[A-Za-z0-9_-]{1,128}$ (got ${JSON.stringify(value)})`,
    )
  }
}
