// dsh-plugin-market — browser half (client bundle).
//
// Renders the "插件市场 / Plugin market" tab into the Plugins settings section
// (the `settings.plugins.tab` slot). Search happens over GitHub's public Search
// API and install/uninstall go through the same-origin /api/plugin-market
// bridge registered by this bundle's host half.
//
// This file is served by the host modules node half at /plugins/<id>/client.js
// and evaluated by window.__ModuleLoader__; it must be plain (bundled) JS.

window.__ModuleLoader__.load({
  id: "dsh-plugin-market",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });

    var react = require("react");
    var React = react;

    /** Dictionary namespace owned by this plugin. */
    var NS = "settings.pluginMarket";

    var zh = {
      tab: "插件市场",
      searchPlaceholder: "搜索 GitHub 上的 dsh-plugin 插件…",
      searchButton: "搜索",
      searching: "搜索中…",
      results: "搜索结果",
      empty: "输入关键词搜索插件，或直接点击搜索浏览热门插件。",
      noResults: "没有找到匹配的插件。",
      installing: "安装中…",
      installingLog: "正在安装，请保持页面打开。",
      install: "安装",
      installed: "已安装",
      uninstall: "卸载",
      uninstalling: "卸载中…",
      stars: "星",
      visit: "查看仓库",
      installedHeading: "已安装的插件",
      noInstalled: "暂无已安装的第三方插件。",
      error: "出错了，请查看下方日志或稍后重试。",
      rateLimited: "GitHub 搜索接口达到未登录速率限制，请稍后再试。",
      log: "安装日志",
      npmHeading: "从 npm 安装",
      npmPlaceholder: "输入 npm 包名（如 @scope/pkg）…",
      npmInstall: "安装 npm 包",
      npmInstalling: "安装中…",
      npmHint: "有些插件的可安装包发布在 npm 而非 GitHub 仓库，直接输入包名即可安装。"
    };

    var en = {
      tab: "Plugin market",
      searchPlaceholder: "Search GitHub for dsh-plugin plugins…",
      searchButton: "Search",
      searching: "Searching…",
      results: "Results",
      empty: "Type a keyword to search, or press Search to browse popular plugins.",
      noResults: "No matching plugins found.",
      installing: "Installing…",
      installingLog: "Installing. Keep this page open.",
      install: "Install",
      installed: "Installed",
      uninstall: "Uninstall",
      uninstalling: "Uninstalling…",
      stars: "stars",
      visit: "Open repository",
      installedHeading: "Installed plugins",
      noInstalled: "No third-party plugins installed yet.",
      error: "Something went wrong; see the log below or retry.",
      rateLimited: "GitHub search rate limit reached (unauthenticated). Try again later.",
      log: "Install log",
      npmHeading: "Install from npm",
      npmPlaceholder: "Enter an npm package name (e.g. @scope/pkg)…",
      npmInstall: "Install npm package",
      npmInstalling: "Installing…",
      npmHint: "Some plugins ship their installable package on npm rather than the GitHub repo — enter the package name to install it."
    };

    /** Translate helper bound at apply time. */
    function MarketTab(props) {
      var t = props.t;
      var reactState = react.useState("");
      var query = reactState[0];
      var setQuery = reactState[1];

      var searchState = react.useState({ status: "idle" });
      var search = searchState[0];
      var setSearch = searchState[1];

      var installedState = react.useState({ status: "loading" });
      var installed = installedState[0];
      var setInstalled = installedState[1];

      var busy = react.useState(null);
      var busyName = busy[0];
      var setBusy = busy[1];

      var npmState = react.useState("");
      var npmInput = npmState[0];
      var setNpmInput = npmState[1];

      var log = react.useState("");
      var logText = log[0];
      var setLog = log[1];

      function api(path, options) {
        return fetch(path, options).then(function (response) {
          return response.json().catch(function () {
            return { ok: false, error: "http", message: "HTTP " + response.status };
          });
        });
      }

      function loadInstalled() {
        setInstalled({ status: "loading" });
        api("/api/plugin-market/list").then(function (result) {
          setInstalled(result.ok
            ? { status: "ready", bundles: result.bundles || [] }
            : { status: "error" });
        }, function () {
          setInstalled({ status: "error" });
        });
      }

      react.useEffect(function () {
        loadInstalled();
      }, []);

      function runSearch() {
        setSearch({ status: "loading" });
        var qs = encodeURIComponent(query.trim());
        api("/api/plugin-market/search" + (qs.length > 0 ? "?q=" + qs : "")).then(function (result) {
          if (result.ok) setSearch({ status: "ready", items: result.items, total: result.total });
          else setSearch({ status: "error", message: result.message });
        }, function () {
          setSearch({ status: "error", message: t("error") });
        });
      }

      function installItem(item) {
        if (busyName !== null) return;
        setBusy(item.fullName);
        setLog("");
        api("/api/plugin-market/install", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ spec: item.installSpec })
        }).then(function (result) {
          setBusy(null);
          setLog(result.message || result.log || "");
          if (result.ok) {
            loadInstalled();
            setSearch(function (prev) {
              if (prev.status !== "ready") return prev;
              var items = prev.items.map(function (it) {
                if (it.fullName !== item.fullName) return it;
                return Object.assign({}, it, { installed: true });
              });
              return Object.assign({}, prev, { items: items });
            });
          }
        }, function (error) {
          setBusy(null);
          setLog(String(error));
        });
      }

      function installNpm() {
        var name = npmInput.trim();
        if (name.length === 0 || busyName !== null) return;
        setBusy("npm:" + name);
        setLog("");
        api("/api/plugin-market/install", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ spec: name })
        }).then(function (result) {
          setBusy(null);
          setLog(result.message || result.log || "");
          if (result.ok) {
            loadInstalled();
            setNpmInput("");
          }
        }, function (error) {
          setBusy(null);
          setLog(String(error));
        });
      }

      function removeItem(name) {
        if (busyName !== null) return;
        setBusy("remove:" + name);
        setLog("");
        api("/api/plugin-market/remove", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ name: name })
        }).then(function (result) {
          setBusy(null);
          setLog(result.log || "");
          if (result.ok) loadInstalled();
        }, function (error) {
          setBusy(null);
          setLog(String(error));
        });
      }

      function makeCard(item) {
        var isInstalling = busyName === item.fullName;
        var isInstalled = item.installed === true;
        return React.createElement(
          "li",
          {
            key: item.fullName,
            style: {
              border: "1px solid var(--dsw-alias-border-l2)",
              background: "var(--dsw-alias-bg-layer-3)",
              borderRadius: "10px",
              padding: "14px 16px",
              display: "flex",
              flexDirection: "column",
              gap: "8px"
            }
          },
          React.createElement(
            "div",
            { style: { display: "flex", alignItems: "center", gap: "8px", justifyContent: "space-between" } },
            React.createElement(
              "a",
              {
                href: item.url,
                target: "_blank",
                rel: "noopener noreferrer",
                style: { color: "var(--dsw-alias-label-primary)", fontWeight: 600, fontSize: "14px", textDecoration: "none" }
              },
              item.fullName
            ),
            React.createElement(
              "span",
              { style: { color: "var(--dsw-alias-label-tertiary)", fontSize: "12px", whiteSpace: "nowrap" } },
              "★ " + item.stars + " " + t("stars")
            )
          ),
          item.description ? React.createElement(
            "p",
            { style: { color: "var(--dsw-alias-label-tertiary)", fontSize: "13px", margin: 0, lineHeight: 1.5 } },
            item.description
          ) : null,
          React.createElement(
            "div",
            { style: { display: "flex", gap: "8px", alignItems: "center", marginTop: "2px" } },
            isInstalled ? React.createElement(
              "button",
              {
                type: "button",
                style: buttonStyle(true),
                onClick: function () { removeItem(item.fullName); },
                disabled: busyName !== null
              },
              busyName === "remove:" + item.fullName ? t("uninstalling") : t("uninstall")
            ) : React.createElement(
              "button",
              {
                type: "button",
                style: buttonStyle(false),
                onClick: function () { installItem(item); },
                disabled: busyName !== null
              },
              isInstalling ? t("installing") : t("install")
            )
          )
        );
      }

      function buttonStyle(secondary) {
        return {
          appearance: "none",
          font: "inherit",
          cursor: "pointer",
          border: "1px solid " + (secondary ? "var(--dsw-alias-border-l2)" : "var(--dsw-alias-brand-primary)"),
          background: secondary ? "transparent" : "var(--dsw-alias-brand-primary)",
          color: secondary ? "var(--dsw-alias-label-secondary)" : "#fff",
          borderRadius: "8px",
          padding: "5px 14px",
          fontSize: "13px",
          lineHeight: 1.5
        };
      }

      return React.createElement(
        "div",
        { style: { maxWidth: "760px", display: "flex", flexDirection: "column", gap: "16px", color: "var(--dsw-alias-label-primary)" } },
        // Search box
        React.createElement(
          "div",
          { style: { display: "flex", gap: "8px" } },
          React.createElement(
            "input",
            {
              type: "search",
              value: query,
              placeholder: t("searchPlaceholder"),
              "aria-label": t("searchPlaceholder"),
              style: {
                flex: 1,
                height: "36px",
                border: "1px solid var(--dsw-alias-border-l2)",
                background: "var(--dsw-alias-bg-layer-1)",
                color: "var(--dsw-alias-label-primary)",
                borderRadius: "8px",
                padding: "0 12px",
                fontSize: "13px",
                outline: "none"
              },
              onKeyDown: function (event) { if (event.key === "Enter") runSearch(); },
              onChange: function (event) { setQuery(event.currentTarget.value); }
            }
          ),
          React.createElement(
            "button",
            { type: "button", style: buttonStyle(false), onClick: runSearch, disabled: search.status === "loading" },
            search.status === "loading" ? t("searching") : t("searchButton")
          )
        ),
        // npm install box
        React.createElement(
          "div",
          { style: { display: "flex", flexDirection: "column", gap: "6px" } },
          React.createElement("span", { style: { color: "var(--dsw-alias-label-tertiary)", fontSize: "12px" } }, t("npmHeading") + " · " + t("npmHint")),
          React.createElement(
            "div",
            { style: { display: "flex", gap: "8px" } },
            React.createElement(
              "input",
              {
                type: "text",
                value: npmInput,
                placeholder: t("npmPlaceholder"),
                "aria-label": t("npmPlaceholder"),
                style: {
                  flex: 1,
                  height: "36px",
                  border: "1px solid var(--dsw-alias-border-l2)",
                  background: "var(--dsw-alias-bg-layer-1)",
                  color: "var(--dsw-alias-label-primary)",
                  borderRadius: "8px",
                  padding: "0 12px",
                  fontSize: "13px",
                  outline: "none"
                },
                onKeyDown: function (event) { if (event.key === "Enter") installNpm(); },
                onChange: function (event) { setNpmInput(event.currentTarget.value); }
              }
            ),
            React.createElement(
              "button",
              { type: "button", style: buttonStyle(false), onClick: installNpm, disabled: busyName !== null || npmInput.trim().length === 0 },
              busyName !== null && busyName.indexOf("npm:") === 0 ? t("npmInstalling") : t("npmInstall")
            )
          )
        ),
        // Results
        search.status === "idle" ? React.createElement("p", { style: muted() }, t("empty")) : null,
        search.status === "error" ? React.createElement("p", { style: { color: "var(--dsw-alias-state-error-primary)", fontSize: "13px" } }, search.message || t("error")) : null,
        search.status === "ready" && search.items.length === 0 ? React.createElement("p", { style: muted() }, t("noResults")) : null,
        search.status === "ready" && search.items.length > 0 ? React.createElement(
          "div",
          null,
          React.createElement(
            "div",
            { style: { display: "flex", alignItems: "baseline", gap: "8px", marginBottom: "10px" } },
            React.createElement("h3", { style: { margin: 0, fontSize: "13px", fontWeight: 600 } }, t("results")),
            React.createElement("span", { style: { color: "var(--dsw-alias-label-tertiary)", fontSize: "12px" } }, search.total)
          ),
          React.createElement("ul", { style: { listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: "10px" } },
            search.items.map(makeCard))
        ) : null,
        // Install log
        logText ? React.createElement(
          "details",
          { style: { fontSize: "12px" } },
          React.createElement("summary", { style: { cursor: "pointer", color: "var(--dsw-alias-label-secondary)" } }, t("log")),
          React.createElement(
            "pre",
            { style: {
              whiteSpace: "pre-wrap",
              wordBreak: "break-all",
              background: "var(--dsw-alias-bg-layer-2)",
              border: "1px solid var(--dsw-alias-border-l2)",
              borderRadius: "8px",
              padding: "10px 12px",
              maxHeight: "220px",
              overflow: "auto",
              margin: "8px 0 0"
            } },
            logText
          )
        ) : null,
        // Installed list
        React.createElement(
          "div",
          null,
          React.createElement("h3", { style: { margin: "0 0 10px", fontSize: "13px", fontWeight: 600 } }, t("installedHeading")),
          installed.status === "loading" ? React.createElement("p", { style: muted() }, "…") : null,
          installed.status === "ready" && installed.bundles.length === 0 ? React.createElement("p", { style: muted() }, t("noInstalled")) : null,
          installed.status === "ready" && installed.bundles.length > 0 ? React.createElement(
            "ul",
            { style: { listStyle: "none", margin: 0, padding: 0, display: "flex", flexWrap: "wrap", gap: "8px" } },
            installed.bundles.map(function (name) {
              return React.createElement(
                "li",
                { key: name, style: {
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "8px",
                  border: "1px solid var(--dsw-alias-border-l2)",
                  background: "var(--dsw-alias-bg-layer-3)",
                  borderRadius: "999px",
                  padding: "4px 12px",
                  fontSize: "12px"
                } },
                React.createElement("span", null, name),
                name.indexOf("@deepseek-ai/") !== 0 ? React.createElement(
                  "button",
                  {
                    type: "button",
                    onClick: function () { removeItem(name); },
                    disabled: busyName !== null,
                    style: { background: "none", border: "none", cursor: "pointer", color: "var(--dsw-alias-label-tertiary)", padding: 0, fontSize: "12px" },
                    title: t("uninstall")
                  },
                  "×"
                ) : null
              );
            })
          ) : null
        )
      );
    }

    function muted() {
      return { color: "var(--dsw-alias-label-tertiary)", fontSize: "13px", margin: 0 };
    }

    /** Required services for the Settings registration. */
    var inject = ["slots", "locale"];

    /** Mount the market tab into the Plugins settings section. */
    function apply(ctx) {
      ctx.effect(function () {
        return ctx.locale.register(NS, { zh: zh, en: en });
      }, "dsh-plugin-market: dictionaries");

      var t = ctx.locale.bind(NS);

      ctx.slots.inject("settings.plugins.tab", function () {
        return ctx.slots.register({
          name: "settings.plugins.tab",
          id: "market",
          order: 5,
          label: function () { return t("tab"); },
          locale: NS,
          inject: function () { return { t: t }; }
        }, MarketTab);
      });
    }

    exports.apply = apply;
    exports.inject = inject;
    return module.exports;
  }
});
