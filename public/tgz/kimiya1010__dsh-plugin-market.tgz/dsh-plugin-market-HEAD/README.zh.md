# dsh-plugin-market

*[English](README.md) | [简体中文](README.zh.md)*

一个 DeepSeek Harness（DSH）插件：让使用者在 **Web 界面里直接搜索并安装其他插件**，无需离开界面去敲命令行。

它在「设置 → 插件」里新增一个 **「插件市场」** 标签页：

- 🔍 搜索 GitHub 上带 [`dsh-plugin`](https://github.com/topics/dsh-plugin) 主题的插件仓库（按 star 排序）
- 📋 展示插件名称、描述、星标数，可跳转到 GitHub 仓库
- ⚡ 一键安装（内部等价于 `dsh plugin --profile web add github:owner/repo`）
- 🗑️ 一键卸载已安装的第三方插件
- 📦 展示当前 profile 已安装的插件（`dsh.profile.bundles`）

## 安装

像安装任何其他 DSH bundle 一样：

```sh
# 从 GitHub 安装到本地 web profile
dsh plugin --profile web add github:kimiya1010/dsh-plugin-market

# 重启 web 界面后生效
dsh web
```

或者本地 checkout 安装：

```sh
dsh plugin --profile web add ./dsh-plugin-market
```

> 说明：本插件是纯 JavaScript、**无 `prepare` 构建脚本**，从 `github:` 安装时无需在
> `pnpm-workspace.yaml` 中放行任何构建，开箱即用。

## 目录结构

```
dsh-plugin-market/
├── package.json        # dsh.bundle（补丁层）+ dsh.client（浏览器半程）声明
├── cordis.patch.yml    # 把 loader 行 insert 进组合
├── index.js            # Host 半程：注册 /api/plugin-market HTTP 桥 + 搜索/安装/卸载
└── client.js           # Client 半程：设置页「插件市场」标签页 UI
```

## 工作原理

- **Host 半程**（`index.js`）：注入 `webServer` 服务，注册一个同源前缀路由
  `/api/plugin-market`，提供四个端点：
  - `GET  /api/plugin-market/search?q=<关键词>` — 调 GitHub Search API（`topic:dsh-plugin`）
  - `POST /api/plugin-market/install`（body `{ "spec": "github:owner/repo" }`）— 执行 `dsh plugin add`
  - `GET  /api/plugin-market/list` — 读取当前 profile 的 `dsh.profile.bundles`
  - `POST /api/plugin-market/remove`（body `{ "name": "…" }`）— 执行 `dsh plugin remove`
- **Client 半程**（`client.js`）：在 `settings.plugins.tab` 槽位注册「插件市场」页，用
  同源 `fetch` 调用上面的 HTTP 桥，渲染搜索框、结果列表、安装/卸载按钮与已安装清单。

因为 HTTP 桥挂在 Web 界面自己监听的端口上（同源），不存在跨域问题，也不需要改动框架自身的
Remote 描述符。

## 发布你自己的版本

把本仓库推到你自己的 GitHub，并给它加上 [`dsh-plugin`](https://github.com/topics/dsh-plugin)
主题，就能被其他用户的插件市场搜索到。也可以发布到 npm：

```sh
npm publish --access public
```

## 安全提示

安装第三方插件意味着其作者的代码会在你的机器上执行（安装期可能跑 `prepare`，运行期加载 bundle）。
请只安装你信任来源的插件，必要时固定到某个 commit（`github:owner/repo#<sha>`）以避免上游改动静默变更行为。

## License

MIT
