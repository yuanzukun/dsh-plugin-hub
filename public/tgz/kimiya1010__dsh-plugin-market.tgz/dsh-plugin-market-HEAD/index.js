// dsh-plugin-market — host half.
//
// Registers a same-origin HTTP bridge on the Web profile's `webServer` so the
// browser Settings tab can search GitHub's `dsh-plugin` topic and install /
// uninstall plugins into the current profile without leaving the GUI.
//
// This is an ordinary Cordis bundle plugin: it runs with full Node access
// (unlike an in-session `cordis_define` dynamic package). Everything it
// registers is a fiber effect and is removed when the profile stops.

import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import { readFile } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";

const GITHUB_API = "https://api.github.com";
const USER_AGENT = "dsh-plugin-market";

/** The HTTP methods this route answers. */
const ALLOWED_METHODS = new Set(["GET", "POST"]);

/** Name of this plugin (used as console/log tag). */
export const name = "dsh-plugin-market";

/**
 * Hard dependency: this plugin only makes sense where a webserver is mounted.
 * The web profile always mounts `@deepseek-ai/dsh-host-webserver` (service
 * `webServer`), so declaring the injection lets Cordis park this plugin until
 * it exists and exposes it as `ctx.webServer` in `apply`.
 */
export const inject = ["webServer"];

/**
 * Resolve the profile directory `dsh plugin --profile web` operates on.
 * The web profile lives at `$DSH_HOME/profiles/web`; DSH_HOME defaults to
 * `~/.dsh` when unset.
 */
function resolveProfileDir() {
  const envHome = process.env.DSH_HOME;
  const home = envHome && envHome.length > 0 ? envHome : join(homedir(), ".dsh");
  return join(home, "profiles", "web");
}

/**
 * Read the installed bundle list for the current profile: the ordered
 * `dsh.profile.bundles` array in `<profile>/package.json`.
 */
async function listInstalled(profileDir) {
  const manifestPath = join(profileDir, "package.json");
  if (!existsSync(manifestPath)) return [];
  const raw = await readFile(manifestPath, "utf8");
  const manifest = JSON.parse(raw);
  return manifest?.dsh?.profile?.bundles ?? [];
}

/** Write a minimal JSON response with CORS disabled (same origin only). */
function json(res, status, value) {
  const body = JSON.stringify(value);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store"
  });
  res.end(body);
}

/** Read a JSON request body, or null when absent/invalid. */
async function readJsonBody(req) {
  return await new Promise((resolvePromise) => {
    let data = "";
    req.on("data", (chunk) => {
      if (data.length < 1_000_000) data += chunk;
    });
    req.on("end", () => {
      if (data.length === 0) return resolvePromise({});
      try {
        resolvePromise(JSON.parse(data));
      } catch {
        resolvePromise(null);
      }
    });
    req.on("error", () => resolvePromise(null));
  });
}

/**
 * Search GitHub for repositories bearing the `dsh-plugin` topic plus the
 * user's keywords. Returns the same shape the client renders.
 */
async function searchGitHub(query) {
  const q = query && query.trim().length > 0 ? `topic:dsh-plugin ${query.trim()}` : "topic:dsh-plugin";
  const url = `${GITHUB_API}/search/repositories?q=${encodeURIComponent(q)}&sort=stars&order=desc&per_page=30`;
  const response = await fetch(url, {
    headers: {
      "user-agent": USER_AGENT,
      accept: "application/vnd.github+json"
    }
  });
  if (response.status === 403) {
    return {
      ok: false,
      error: "rate-limited",
      message: "GitHub 搜索接口已达到未登录速率限制，请稍后再试。"
    };
  }
  if (!response.ok) {
    return {
      ok: false,
      error: "github-error",
      message: `GitHub 搜索失败（HTTP ${response.status}）。`
    };
  }
  const payload = await response.json();
  const items = (payload.items ?? []).map((repo) => ({
    fullName: repo.full_name ?? "",
    name: repo.name ?? "",
    owner: repo.owner?.login ?? "",
    description: repo.description ?? "",
    stars: repo.stargazers_count ?? 0,
    url: repo.html_url ?? "",
    defaultBranch: repo.default_branch ?? "main",
    // Install spec pnpm accepts straight from a git host.
    installSpec: `github:${repo.full_name ?? ""}`
  }));
  return { ok: true, total: payload.total_count ?? items.length, items };
}

/**
 * Inspect a GitHub repo's root `package.json` to decide whether it is a
 * directly-installable DSH bundle: it must declare `dsh.bundle.patch` and must
 * not be `private: true` (private packages cannot be installed from git).
 * Tries the reported default branch first, then `main`, then `master`.
 * Returns a decision object; `found` is false when no branch yields a manifest.
 */
async function inspectRepo(fullName, defaultBranch) {
  const branches = [...new Set([defaultBranch, "main", "master"].filter(Boolean))];
  for (const branch of branches) {
    const url = `https://raw.githubusercontent.com/${fullName}/${branch}/package.json`;
    try {
      const response = await fetch(url, {
        headers: {
          "user-agent": USER_AGENT,
          accept: "application/vnd.github.raw+json"
        }
      });
      if (!response.ok) continue;
      const pkg = await response.json();
      const hasBundle = typeof pkg?.dsh?.bundle?.patch === "string";
      const isPrivate = pkg?.private === true;
      return {
        found: true,
        hasBundle,
        isPrivate,
        installable: hasBundle && !isPrivate,
        packageName: typeof pkg?.name === "string" ? pkg.name : "",
        branch
      };
    } catch {
      /* try the next branch */
    }
  }
  return { found: false, hasBundle: false, isPrivate: false, installable: false };
}

/**
 * Run one `dsh plugin` invocation: `add <spec>` or `remove <name>`.
 * The `dsh` CLI forwards to pnpm in the profile directory and then reconciles
 * `dsh.profile.bundles`. We stream its stdout/stderr back so the UI can show
 * a live log of progress. Returns { ok, exitCode, log }.
 */
async function runPluginCommand(profileDir, args, onLine) {
  const dshBin = process.platform === "win32" ? "dsh.cmd" : "dsh";
  const report = (text) => {
    if (typeof onLine === "function") onLine(text);
  };
  return await new Promise((resolvePromise) => {
    let log = "";
    const child = spawn(dshBin, ["plugin", "--profile", "web", ...args], {
      cwd: profileDir,
      env: process.env,
      shell: process.platform === "win32"
    });
    const onData = (stream) => (chunk) => {
      const text = chunk.toString();
      log += text;
      for (const line of text.split(/\r?\n/)) {
        if (line.length > 0) report(line);
      }
    };
    child.stdout?.on("data", onData("stdout"));
    child.stderr?.on("data", onData("stderr"));
    child.on("error", (error) => {
      const message = error.code === "ENOENT"
        ? "未找到 dsh 命令，请先安装 DeepSeek Harness CLI 并确保其位于 PATH。"
        : `启动安装进程失败：${error.message}`;
      resolvePromise({ ok: false, exitCode: 127, log, error: message });
    });
    child.on("close", (code) => {
      resolvePromise({ ok: code === 0, exitCode: code ?? 1, log });
    });
  });
}

/**
 * Route handler for anything under /api/plugin-market/.
 * Sub-paths: /search?q=…, /list, /install (POST {spec}), /remove (POST {name}).
 */
function createHandler(profileDir) {
  return async (req, res) => {
    let pathname;
    try {
      pathname = new URL(req.url ?? "/", "http://localhost").pathname;
    } catch {
      return json(res, 400, { ok: false, error: "bad-url", message: "请求路径无效。" });
    }
    const method = req.method ?? "GET";
    if (!ALLOWED_METHODS.has(method)) {
      return json(res, 405, { ok: false, error: "method", message: "不支持的方法。" });
    }
    const sub = pathname.slice("/api/plugin-market".length).replace(/^\/+/, "");
    const [endpoint] = sub.split("/");

    try {
      if (endpoint === "search" && method === "GET") {
        const q = new URL(req.url ?? "/", "http://localhost").searchParams.get("q") ?? "";
        const result = await searchGitHub(q);
        return json(res, result.ok ? 200 : 502, result);
      }
      if (endpoint === "list" && method === "GET") {
        const bundles = await listInstalled(profileDir);
        return json(res, 200, { ok: true, bundles });
      }
      if (endpoint === "inspect" && method === "GET") {
        const params = new URL(req.url ?? "/", "http://localhost").searchParams;
        const repo = params.get("repo") ?? "";
        if (!repo.includes("/")) {
          return json(res, 400, { ok: false, error: "bad-request", message: "需要 repo 参数（owner/repo）。" });
        }
        const branch = params.get("branch") ?? "main";
        const inspect = await inspectRepo(repo, branch);
        return json(res, 200, { ok: true, repo, ...inspect });
      }
      if (endpoint === "install" && method === "POST") {
        const body = await readJsonBody(req);
        if (body === null || typeof body.spec !== "string" || body.spec.trim().length === 0) {
          return json(res, 400, { ok: false, error: "bad-request", message: "需要提供待安装的插件 spec。" });
        }
        const spec = body.spec.trim();
        // For a `github:owner/repo` spec, pre-check that the repo is a real,
        // directly-installable bundle before spending time on `dsh plugin add`.
        const gitMatch = /^github:([^#]+)(?:#(.+))?$/.exec(spec);
        if (gitMatch) {
          const fullName = gitMatch[1];
          const inspect = await inspectRepo(fullName, body.branch ?? "main");
          if (inspect.found && !inspect.installable) {
            const reason = inspect.isPrivate
              ? "该仓库声明为 private，无法从 git 安装。"
              : "该仓库根 package.json 没有 dsh.bundle 声明，不是可直接安装的插件（很可能发布在 npm，试试它的 npm 包名）。";
            return json(res, 422, { ok: false, error: "not-installable", message: reason, inspect });
          }
        }
        const result = await runPluginCommand(profileDir, ["add", spec]);
        return json(res, result.ok ? 200 : 500, {
          ok: result.ok,
          exitCode: result.exitCode,
          log: result.log,
          error: result.error,
          bundles: result.ok ? await listInstalled(profileDir) : undefined
        });
      }
      if (endpoint === "remove" && method === "POST") {
        const body = await readJsonBody(req);
        if (body === null || typeof body.name !== "string" || body.name.trim().length === 0) {
          return json(res, 400, { ok: false, error: "bad-request", message: "需要提供待卸载的插件名。" });
        }
        const result = await runPluginCommand(profileDir, ["remove", body.name.trim()]);
        return json(res, result.ok ? 200 : 500, {
          ok: result.ok,
          exitCode: result.exitCode,
          log: result.log,
          error: result.error,
          bundles: result.ok ? await listInstalled(profileDir) : undefined
        });
      }
      return json(res, 404, { ok: false, error: "not-found", message: `未知的插件市场端点：${endpoint || "(空)"}` });
    } catch (error) {
      return json(res, 500, {
        ok: false,
        error: "internal",
        message: error instanceof Error ? error.message : String(error)
      });
    }
  };
}

/**
 * Cordis entry: mount the HTTP bridge on the webserver and own its disposer.
 */
export function apply(ctx) {
  const profileDir = resolveProfileDir();
  ctx.effect(() => {
    const dispose = ctx.webServer.register({
      kind: "prefix",
      path: "/api/plugin-market",
      handler: createHandler(profileDir)
    });
    return dispose;
  }, "dsh-plugin-market: HTTP bridge");
}
