/**
 * GBC atelier skin. The client entry keeps the palace backdrop, a rotating
 * character stage (bottom-right member carousel over an ensemble collage),
 * and the ornamental pink/black chrome as independent layers. The sidebar
 * keeps the product's native vector wordmark; every skin-owned write is
 * restored by the Cordis effect disposer.
 */
import type { Context } from '@deepseek-ai/cordis'
import {
  GBC_COMPOSER_BAND,
  GBC_ICON,
  GBC_SUBARU,
  GBC_TOMO_1,
} from './art.ts'
import {
  GBC_GROUP,
  GBC_MEMBERS,
  GBC_PALACE_DARK,
  GBC_PALACE_LIGHT,
} from './background-art.generated.ts'
import {
  GBC_COMPOSER_FRAME,
  GBC_SETTINGS_FRAME,
  GBC_SIDEBAR_CORNER,
} from './chrome-art.generated.ts'
import {
  GBC_WORKSPACE_RIBBON,
  GBC_WORKSPACE_SHIELD,
} from './workspace-art.generated.ts'
import './gbc-atelier.module.css'
import { GBC_TITLEBAR_BRAND } from './titlebar-brand.ts'

const SKIN_TITLE = 'GirlsBangCry · DeepSeek Harness'
const SKIN_OWNER = 'gbc-atelier'
const SKIN_SYSTEM_CHROME_COLOR = '#170d14'
const SIDEBAR_COLUMN_SELECTOR = ":is([data-pane='sidebar'], [class*='sidebarCol'])"
const SETTINGS_TRIGGER_SELECTOR = "[data-slot='sidebar.settings'] > :is(button, [role='button'])"
const SETTINGS_MASK_SELECTOR = "[role='presentation'] > [class*='mask']"
const SETTINGS_STORAGE_KEY = 'gbc-ui-settings'

/** Defaults mirror the legacy dsh-gbc-ui config surface (rotate/dim/blur/accent). */
interface GbcSettings {
  enabled: boolean
  rotateInterval: number
  dim: number
  blur: number
  accent: string
  /** User-uploaded stage portrait (data URL), overrides the member rotation. */
  customPortrait?: string
  /** User-uploaded backdrop (data URL), overrides the palace painting. */
  customBackdrop?: string
  /** User-uploaded left-side portrait (data URL). */
  customLeftPortrait?: string
}

const DEFAULT_SETTINGS: GbcSettings = {
  enabled: true,
  rotateInterval: 30,
  dim: 0.35,
  blur: 0,
  accent: '#e84855',
}

function loadSettings(): GbcSettings {
  try {
    const raw = window.localStorage.getItem(SETTINGS_STORAGE_KEY)
    if (raw === null) return { ...DEFAULT_SETTINGS }
    const parsed = JSON.parse(raw) as Partial<GbcSettings>
    return {
      enabled: typeof parsed.enabled === 'boolean' ? parsed.enabled : DEFAULT_SETTINGS.enabled,
      rotateInterval: typeof parsed.rotateInterval === 'number' && parsed.rotateInterval > 0
        ? parsed.rotateInterval
        : DEFAULT_SETTINGS.rotateInterval,
      dim: typeof parsed.dim === 'number' && parsed.dim >= 0 && parsed.dim <= 1
        ? parsed.dim
        : DEFAULT_SETTINGS.dim,
      blur: typeof parsed.blur === 'number' && parsed.blur >= 0
        ? parsed.blur
        : DEFAULT_SETTINGS.blur,
      accent: typeof parsed.accent === 'string' && /^#[0-9a-f]{6}$/i.test(parsed.accent)
        ? parsed.accent
        : DEFAULT_SETTINGS.accent,
      customPortrait: typeof parsed.customPortrait === 'string' && parsed.customPortrait.startsWith('data:image/')
        ? parsed.customPortrait
        : undefined,
      customBackdrop: typeof parsed.customBackdrop === 'string' && parsed.customBackdrop.startsWith('data:image/')
        ? parsed.customBackdrop
        : undefined,
      customLeftPortrait: typeof parsed.customLeftPortrait === 'string' && parsed.customLeftPortrait.startsWith('data:image/')
        ? parsed.customLeftPortrait
        : undefined,
    }
  } catch {
    return { ...DEFAULT_SETTINGS }
  }
}

function saveSettings(settings: GbcSettings): void {
  try {
    window.localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings))
  } catch {
    // storage unavailable (private mode): settings live for the session only
  }
}

/** Blend a hex color toward white by `amount` (0..1) and return a hex string. */
function mixWithWhite(hex: string, amount: number): string {
  const value = Number.parseInt(hex.slice(1), 16)
  const r = Math.round(((value >> 16) & 0xff) + (255 - ((value >> 16) & 0xff)) * amount)
  const g = Math.round(((value >> 8) & 0xff) + (255 - ((value >> 8) & 0xff)) * amount)
  const b = Math.round((value & 0xff) + (255 - (value & 0xff)) * amount)
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`
}

const BACKDROP_PROPERTIES = [
  'background-image',
  'background-position',
  'background-size',
  'background-attachment',
  'background-repeat',
  '--gbc-sidebar-width',
  '--gbc-titlebar-height',
  '--gbc-sidebar-corner-art',
  '--gbc-composer-band-art',
  '--gbc-composer-frame-art',
  '--gbc-settings-frame-art',
  '--gbc-workspace-crest-art',
  '--gbc-workspace-ribbon-art',
  '--gbc-pink',
  '--gbc-pink-soft',
  '--gbc-pink-pale',
  '--gbc-dim',
] as const

function createCharacterStage(settings: GbcSettings): HTMLDivElement {
  const stage = document.createElement('div')
  stage.dataset.skinChrome = 'character-stage'
  stage.dataset.skinOwner = SKIN_OWNER
  stage.setAttribute('aria-hidden', 'true')

  const group = document.createElement('img')
  group.dataset.gbcStageGroup = ''
  group.alt = ''
  group.src = GBC_GROUP
  stage.append(group)

  const portrait = document.createElement('img')
  portrait.dataset.gbcStagePortrait = ''
  portrait.alt = ''
  portrait.src = settings.customPortrait ?? GBC_MEMBERS[0]
  stage.append(portrait)

  return stage
}

function createDimVeil(settings: GbcSettings): HTMLDivElement {
  const veil = document.createElement('div')
  veil.dataset.skinChrome = 'dim-veil'
  veil.dataset.skinOwner = SKIN_OWNER
  veil.setAttribute('aria-hidden', 'true')
  applyDimVeil(veil, settings)
  return veil
}

function applyDimVeil(veil: HTMLDivElement, settings: GbcSettings): void {
  veil.style.background = `rgba(16, 8, 13, ${settings.dim})`
  veil.style.backdropFilter = settings.blur > 0 ? `blur(${settings.blur}px)` : 'none'
}

function createStageToggle(): HTMLButtonElement {
  const toggle = document.createElement('button')
  toggle.dataset.skinChrome = 'stage-toggle'
  toggle.dataset.skinOwner = SKIN_OWNER
  toggle.type = 'button'
  toggle.setAttribute('aria-label', '切换角色舞台')
  toggle.setAttribute('title', '切换角色舞台')
  toggle.textContent = '🎸'
  return toggle
}

/** Small side figures flanking the composer so the composition stays full. */
function createSideFigure(chrome: string, src: string): HTMLImageElement {
  const figure = document.createElement('img')
  figure.dataset.skinChrome = chrome
  figure.dataset.skinOwner = SKIN_OWNER
  figure.setAttribute('aria-hidden', 'true')
  figure.alt = ''
  figure.src = src
  return figure
}

function createSidebarCorners(): HTMLDivElement {
  const corners = document.createElement('div')
  corners.dataset.skinChrome = 'sidebar-corners'
  corners.dataset.skinOwner = SKIN_OWNER
  corners.setAttribute('aria-hidden', 'true')
  for (const position of ['top-left', 'top-right', 'bottom-right', 'bottom-left']) {
    const corner = document.createElement('span')
    corner.dataset.skinCorner = position
    corners.append(corner)
  }
  return corners
}

/**
 * Place the whale-free DeepSeek Harness wordmark at the left of the
 * frameless title bar (Web-app overlay / desktop shell), mirroring the
 * sidebar brand at a smaller scale.
 */
function decorateTitlebarBrand(ownedNodes: Set<Element>): void {
  const titlebar = document.querySelector<HTMLElement>("[class*='titlebar']")
  if (!titlebar) return
  if (titlebar.querySelector("[data-skin-chrome='titlebar-brand']")) return
  const brand = document.createElement('span')
  brand.dataset.skinChrome = 'titlebar-brand'
  brand.dataset.skinOwner = SKIN_OWNER
  brand.setAttribute('aria-hidden', 'true')
  brand.innerHTML = GBC_TITLEBAR_BRAND
  ownedNodes.add(brand)
  titlebar.prepend(brand)
}

function decorateSidebar(ownedNodes: Set<Element>, decoratedElements: Set<HTMLElement>): void {
  const sidebar = document.querySelector<HTMLElement>(SIDEBAR_COLUMN_SELECTOR)
  const sidebarRoot = sidebar?.querySelector<HTMLElement>(':scope > div')
  if (!sidebar || !sidebarRoot) return

  sidebar.querySelectorAll<HTMLElement>('[data-gbc-sidebar-footer]').forEach((element) => {
    delete element.dataset.gbcSidebarFooter
  })
  const settingsSlot = sidebar.querySelector<HTMLElement>("[data-slot='sidebar.settings']")
  if (settingsSlot) {
    let footer = settingsSlot.parentElement
    while (footer && footer !== sidebar) {
      if (footer.querySelector("[data-slot='sidebar.footer.action']")) {
        footer.dataset.gbcSidebarFooter = ''
        decoratedElements.add(footer)
        break
      }
      footer = footer.parentElement
    }
  }

  if (!sidebarRoot.querySelector("[data-skin-chrome='sidebar-corners']")) {
    const corners = createSidebarCorners()
    ownedNodes.add(corners)
    sidebarRoot.prepend(corners)
  }
}

function decorateWorkspaceTree(decoratedElements: Set<HTMLElement>): void {
  const sidebar = document.querySelector<HTMLElement>(SIDEBAR_COLUMN_SELECTOR)
  if (!sidebar) return

  sidebar.querySelectorAll<HTMLElement>(
    '[data-gbc-workspace-group], [data-gbc-workspace-row], [data-gbc-workspace-active], [data-gbc-session-row], [data-gbc-session-flat], [data-gbc-session-first], [data-gbc-session-last]',
  ).forEach((element) => {
    delete element.dataset.gbcWorkspaceGroup
    delete element.dataset.gbcWorkspaceRow
    delete element.dataset.gbcWorkspaceActive
    delete element.dataset.gbcSessionRow
    delete element.dataset.gbcSessionFlat
    delete element.dataset.gbcSessionFirst
    delete element.dataset.gbcSessionLast
  })

  sidebar.querySelectorAll<HTMLElement>("[role='tree']").forEach((tree) => {
    const rows = [...tree.querySelectorAll<HTMLElement>("[role='treeitem']")]
    if (tree.matches("[class*='flatList']") && !rows.some(row => row.hasAttribute('aria-expanded'))) {
      rows.filter(row => row.hasAttribute('aria-selected')).forEach((sessionRow) => {
        sessionRow.dataset.gbcSessionRow = ''
        sessionRow.dataset.gbcSessionFlat = ''
        decoratedElements.add(sessionRow)
      })
      return
    }

    let workspaceRow: HTMLElement | undefined
    let sessionRows: HTMLElement[] = []
    const decorateGroup = (): void => {
      if (!workspaceRow) return

      workspaceRow.dataset.gbcWorkspaceRow = ''
      decoratedElements.add(workspaceRow)
      if (workspaceRow.parentElement) {
        workspaceRow.parentElement.dataset.gbcWorkspaceGroup = ''
        decoratedElements.add(workspaceRow.parentElement)
      }
      sessionRows.forEach((sessionRow) => {
        sessionRow.dataset.gbcSessionRow = ''
        decoratedElements.add(sessionRow)
      })
      if (sessionRows[0]) sessionRows[0].dataset.gbcSessionFirst = ''
      if (sessionRows.at(-1)) sessionRows.at(-1)!.dataset.gbcSessionLast = ''

      const containsCurrent = workspaceRow.getAttribute('aria-expanded') === 'true'
        && sessionRows.some(sessionRow => sessionRow.getAttribute('aria-selected') === 'true')
      if (containsCurrent) workspaceRow.dataset.gbcWorkspaceActive = ''
    }

    rows.forEach((row) => {
      if (row.hasAttribute('aria-expanded')) {
        decorateGroup()
        workspaceRow = row
        sessionRows = []
      } else if (workspaceRow && row.hasAttribute('aria-selected')) {
        sessionRows.push(row)
      }
    })
    decorateGroup()
  })
}

/**
 * Apply the skin-owned background and independently retractable chrome.
 * @param ctx - owning context whose effect retracts every DOM and CSS write.
 */
export function apply(ctx: Context): void {
  const body = document.body
  const originalTitle = document.title
  const settings = loadSettings()
  const previous = new Map<string, string>()
  for (const property of BACKDROP_PROPERTIES) {
    previous.set(property, body.style.getPropertyValue(property))
  }

  const ownedNodes = new Set<Element>()
  const decoratedElements = new Set<HTMLElement>()
  let themeColorMeta: HTMLMetaElement | null = null
  let previousThemeColor: string | undefined
  let themeColorObserver: MutationObserver | undefined
  let observedSidebar: HTMLElement | undefined
  let resizeObserver: ResizeObserver | undefined
  let composerPhase: 'hero' | 'active' | undefined
  let composerMotionTimer: ReturnType<typeof setTimeout> | undefined
  let settingsBackdropFrame: HTMLDivElement | undefined
  let observer: MutationObserver | undefined
  let titlebarOverlay: WindowControlsOverlay | undefined
  let syncTitlebarHeight: (() => void) | undefined
  let stageIndex = 0
  let stageSwapping = false
  let stageTimer: ReturnType<typeof setInterval> | undefined
  let leftTimer: ReturnType<typeof setInterval> | undefined
  const portrait = (): HTMLImageElement | null => (
    document.querySelector<HTMLImageElement>('[data-gbc-stage-portrait]')
  )

  const startStageRotation = (): void => {
    if (stageTimer !== undefined) clearInterval(stageTimer)
    const image = portrait()
    if (!image || !settings.enabled) return
    stageTimer = setInterval(() => {
      if (document.hidden || stageSwapping) return
      stageSwapping = true
      image.dataset.gbcSwapping = ''
      setTimeout(() => {
        if (!image.isConnected) {
          stageSwapping = false
          return
        }
        stageIndex = (stageIndex + 1) % GBC_MEMBERS.length
        image.src = GBC_MEMBERS[stageIndex]
        delete image.dataset.gbcSwapping
        stageSwapping = false
      }, 430)
    }, Math.max(5, settings.rotateInterval) * 1000)
  }

  const setStageEnabled = (enabled: boolean): void => {
    settings.enabled = enabled
    saveSettings(settings)
    if (enabled) {
      delete body.dataset.gbcStageOff
      startStageRotation()
    } else {
      body.dataset.gbcStageOff = ''
      if (stageTimer !== undefined) clearInterval(stageTimer)
      stageTimer = undefined
    }
  }

  ctx.effect(() => () => {
    delete body.dataset.dshGbcAtelier
    delete body.dataset.gbcComposerMotion
    delete body.dataset.gbcSidebarCompact
    delete body.dataset.gbcSidebarSize
    delete body.dataset.gbcStageOff
    if (composerMotionTimer !== undefined) clearTimeout(composerMotionTimer)
    if (stageTimer !== undefined) clearInterval(stageTimer)
    if (leftTimer !== undefined) clearInterval(leftTimer)
    observer?.disconnect()
    themeColorObserver?.disconnect()
    if (titlebarOverlay !== undefined && syncTitlebarHeight !== undefined) {
      titlebarOverlay.removeEventListener('geometrychange', syncTitlebarHeight)
    }
    resizeObserver?.disconnect()
    for (const [property, value] of previous) {
      body.style.setProperty(property, value)
    }
    ownedNodes.forEach(element => element.remove())
    decoratedElements.forEach((element) => {
      delete element.dataset.gbcSidebarFooter
      delete element.dataset.gbcWorkspaceGroup
      delete element.dataset.gbcWorkspaceRow
      delete element.dataset.gbcWorkspaceActive
      delete element.dataset.gbcSessionRow
      delete element.dataset.gbcSessionFlat
      delete element.dataset.gbcSessionFirst
      delete element.dataset.gbcSessionLast
    })
    if (themeColorMeta?.isConnected && themeColorMeta.content === SKIN_SYSTEM_CHROME_COLOR) {
      themeColorMeta.content = previousThemeColor ?? ''
    }
    if (document.title === SKIN_TITLE) document.title = originalTitle
  }, 'ui-skin-gbc-atelier: layered background and ornament')

  const syncSystemChrome = (): void => {
    const meta = document.head.querySelector<HTMLMetaElement>('meta[name="theme-color"]')
    if (meta === null) return
    if (meta !== themeColorMeta) {
      themeColorMeta = meta
      previousThemeColor = meta.content
    }
    if (meta.content !== SKIN_SYSTEM_CHROME_COLOR) meta.content = SKIN_SYSTEM_CHROME_COLOR
  }
  themeColorObserver = new MutationObserver(syncSystemChrome)
  themeColorObserver.observe(document.head, {
    attributes: true,
    attributeFilter: ['content'],
    childList: true,
    subtree: true,
  })
  syncSystemChrome()
  body.dataset.dshGbcAtelier = ''
  body.style.setProperty('--gbc-sidebar-corner-art', `url(${GBC_SIDEBAR_CORNER})`)
  body.style.setProperty('--gbc-composer-band-art', `url(${GBC_COMPOSER_BAND})`)
  body.style.setProperty('--gbc-composer-frame-art', `url(${GBC_COMPOSER_FRAME})`)
  body.style.setProperty('--gbc-settings-frame-art', `url(${GBC_SETTINGS_FRAME})`)
  body.style.setProperty('--gbc-workspace-crest-art', `url(${GBC_WORKSPACE_SHIELD})`)
  body.style.setProperty('--gbc-workspace-ribbon-art', `url(${GBC_WORKSPACE_RIBBON})`)
  body.style.setProperty('--gbc-pink', settings.accent)
  body.style.setProperty('--gbc-pink-soft', mixWithWhite(settings.accent, 0.55))
  body.style.setProperty('--gbc-pink-pale', mixWithWhite(settings.accent, 0.82))
  body.style.setProperty('--gbc-dim', `${settings.dim}`)

  const syncBackdrop = (): void => {
    const source = settings.customBackdrop ?? (
      body.hasAttribute('data-ds-dark-theme')
        ? GBC_PALACE_DARK
        : GBC_PALACE_LIGHT
    )
    body.style.setProperty('background-image', `url(${source})`)
  }
  syncBackdrop()
  body.style.setProperty('background-position', 'center top')
  body.style.setProperty('background-size', 'cover')
  body.style.setProperty('background-attachment', 'fixed')
  body.style.setProperty('background-repeat', 'no-repeat')

  // 宽度联动写入独立的 <style> 规则而非 body style：CSSOM 修改不产生
  // attribute mutation，Chrome autofill 的 MutationObserver 不会逐帧触发，
  // 因此可以每帧跟随侧边栏宽度（幕布瞬移跟手）而无需防抖节流。
  const widthSheet = document.createElement('style')
  widthSheet.dataset.skinChrome = 'sidebar-width-rule'
  widthSheet.dataset.skinOwner = SKIN_OWNER
  ownedNodes.add(widthSheet)
  document.head.append(widthSheet)
  widthSheet.sheet!.insertRule('body { --gbc-sidebar-width: 280px; --gbc-titlebar-height: 0px; }')
  // The official frame rules reference env(titlebar-area-height), but the
  // CSS-modules pipeline rewrites the env() identifier there too, so the
  // title-bar row silently falls back to an auto row: expanding the sidebar
  // is fine, but collapsing it lets the content row's max-content grow and
  // stretches the title-bar row to hundreds of pixels. Re-assert the rows
  // here through CSSOM, where env() survives verbatim (fallback 40px keeps
  // the headless/plain-tab mock sane), and pin the drag handles to the same
  // boundary.
  // insertRule defaults to index 0, which would push the body rule aside and
  // orphan the widthRule reference; append explicitly so cssRules[0] stays
  // the body variable rule.
  const appendRule = (rule: string): void => {
    widthSheet.sheet!.insertRule(rule, widthSheet.sheet!.cssRules.length)
  }
  appendRule('body[data-dsh-gbc-atelier] [class*="frame"][data-wco] { grid-template-rows: env(titlebar-area-height, 40px) 1fr; }')
  appendRule('body[data-dsh-gbc-atelier] [class*="frame"][data-desktop] { grid-template-rows: 32px 1fr; }')
  appendRule('body[data-dsh-gbc-atelier] [class*="frame"] [class*="handle"] { top: var(--gbc-titlebar-height, 0px); }')

  const widthRule = widthSheet.sheet!.cssRules[0] as CSSStyleRule
  // The curtain is position:fixed, so it needs the viewport-space top of
  // the frame's title-bar row. Measuring the sidebar column (the row below
  // it) is authoritative: whatever the title-bar height is — WCO env(), the
  // desktop 32px row, or a scaled window — the curtain lands exactly on the
  // rendered boundary, never a pixel off.
  syncTitlebarHeight = (): void => {
    const columns = document.querySelector<HTMLElement>(SIDEBAR_COLUMN_SELECTOR)
    if (columns !== null) {
      const top = columns.getBoundingClientRect().top
      if (top > 0) {
        widthRule.style.setProperty('--gbc-titlebar-height', `${top}px`)
        return
      }
    }
    // Desktop shell: fixed 32px row (columns not laid out yet).
    if (document.querySelector("[class*='frame'][data-desktop]") !== null) {
      widthRule.style.setProperty('--gbc-titlebar-height', '32px')
      return
    }
    widthRule.style.setProperty('--gbc-titlebar-height', '0px')
  }
  titlebarOverlay = navigator.windowControlsOverlay
  titlebarOverlay?.addEventListener('geometrychange', syncTitlebarHeight)
  syncTitlebarHeight()

  const applySidebarWidth = (width: number): void => {
    if (width <= 0) return
    const roundPx = (value: number): string => `${Math.round(value * 100) / 100}px`
    widthRule.style.setProperty('--gbc-sidebar-width', roundPx(width))
    body.dataset.gbcSidebarSize = width <= 120 ? 'rail' : width <= 220 ? 'narrow' : 'wide'
    if (width <= 104) body.dataset.gbcSidebarCompact = ''
    else delete body.dataset.gbcSidebarCompact
  }

  const clearSidebarWidth = (): void => {
    widthRule.style.setProperty('--gbc-sidebar-width', '0px')
    body.dataset.gbcSidebarSize = 'rail'
    body.dataset.gbcSidebarCompact = ''
  }

  const ensureSidebarObserved = (): void => {
    const sidebar = document.querySelector<HTMLElement>(SIDEBAR_COLUMN_SELECTOR)
    if (!resizeObserver || sidebar === observedSidebar) return
    if (!sidebar) {
      if (observedSidebar) resizeObserver.unobserve(observedSidebar)
      observedSidebar = undefined
      return
    }
    if (observedSidebar) resizeObserver.unobserve(observedSidebar)
    observedSidebar = sidebar
    resizeObserver.observe(sidebar)
  }

  if (typeof ResizeObserver !== 'undefined') {
    resizeObserver = new ResizeObserver((entries) => {
      const entry = entries.at(-1)
      if (entry) applySidebarWidth(entry.contentRect.width)
    })
  }

  const syncComposerMotion = (): void => {
    const phaseRoot = document.querySelector<HTMLElement>("[data-phase='hero'], [data-phase='active']")
    const next = phaseRoot?.dataset.phase
    if (next !== 'hero' && next !== 'active') return

    if (composerPhase !== undefined && composerPhase !== next) {
      body.dataset.gbcComposerMotion = next === 'active' ? 'dock' : 'rise'
      if (composerMotionTimer !== undefined) clearTimeout(composerMotionTimer)
      composerMotionTimer = setTimeout(() => {
        delete body.dataset.gbcComposerMotion
        composerMotionTimer = undefined
      }, 560)
    }
    composerPhase = next
  }

  /* The settings mask is mounted inside a promoted sidebar descendant. Chrome
     can omit sibling composited layers from that backdrop sample, so seat a
     copy of the existing frame immediately before the mask while it is open. */
  const syncSettingsBackdropFrame = (): void => {
    const expanded = document.querySelector(
      `${SETTINGS_TRIGGER_SELECTOR}[aria-expanded='true']`,
    )
    const mask = expanded === null
      ? null
      : document.querySelector<HTMLElement>(SETTINGS_MASK_SELECTOR)
    const overlay = mask?.parentElement
    if (overlay === undefined || overlay === null) {
      settingsBackdropFrame?.remove()
      return
    }

    if (settingsBackdropFrame === undefined) {
      settingsBackdropFrame = createSidebarCorners()
      settingsBackdropFrame.dataset.gbcSettingsBackdropFrame = ''
      ownedNodes.add(settingsBackdropFrame)
    }
    if (settingsBackdropFrame.parentElement !== overlay) {
      overlay.insertBefore(settingsBackdropFrame, mask)
    }
  }

  decorateTitlebarBrand(ownedNodes)
  decorateSidebar(ownedNodes, decoratedElements)
  decorateWorkspaceTree(decoratedElements)
  ensureSidebarObserved()
  const initialSidebar = document.querySelector<HTMLElement>(SIDEBAR_COLUMN_SELECTOR)
  if (initialSidebar) applySidebarWidth(initialSidebar.getBoundingClientRect().width)
  syncComposerMotion()
  syncSettingsBackdropFrame()

  const dimVeil = createDimVeil(settings)
  ownedNodes.add(dimVeil)
  body.prepend(dimVeil)

  const characterStage = createCharacterStage(settings)
  ownedNodes.add(characterStage)
  body.prepend(characterStage)

  // One portrait stands on the composer's left, tucked UNDER the composer so
  // the input card can overlap it. It rotates through the same member set.
  const sidebarHost = document.querySelector<HTMLElement>(SIDEBAR_COLUMN_SELECTOR)
  const leftComposerFigure = createSideFigure('left-composer-figure', settings.customLeftPortrait ?? GBC_TOMO_1)
  ownedNodes.add(leftComposerFigure)
  body.append(leftComposerFigure)
  let leftIndex = GBC_MEMBERS.indexOf(GBC_TOMO_1)
  if (leftIndex < 0) leftIndex = 0
  const stopLeftRotation = (): void => {
    if (leftTimer !== undefined) {
      clearInterval(leftTimer)
      leftTimer = undefined
    }
  }
  const startLeftRotation = (): void => {
    if (leftTimer !== undefined) clearInterval(leftTimer)
    leftTimer = setInterval(() => {
      if (document.hidden) return
      leftIndex = (leftIndex + 1) % GBC_MEMBERS.length
      leftComposerFigure.src = GBC_MEMBERS[leftIndex]
    }, Math.max(5, settings.rotateInterval) * 1000)
  }
  startLeftRotation()

  // The animated Subaru returns to the left sidebar column.
  const subaru = createSideFigure('subaru-figure', GBC_SUBARU)
  ownedNodes.add(subaru)
  if (sidebarHost) sidebarHost.append(subaru)
  else body.append(subaru)

  const stageToggle = createStageToggle()
  ownedNodes.add(stageToggle)
  stageToggle.addEventListener('click', () => {
    setStageEnabled(body.hasAttribute('data-gbc-stage-off'))
  })
  body.append(stageToggle)

  // 🖼️ portrait/backdrop picker: choose any built-in member or upload your
  // own portrait and backdrop. Uploads are downscaled to data URLs and kept
  // in settings, so they survive a reload without any backend storage.
  const stopStageRotation = (): void => {
    if (stageTimer !== undefined) {
      clearInterval(stageTimer)
      stageTimer = undefined
    }
  }

  const downscaleToDataUrl = (file: File, maxDim: number): Promise<string> => (
    new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file)
      const img = new Image()
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height))
        const w = Math.max(1, Math.round(img.width * scale))
        const h = Math.max(1, Math.round(img.height * scale))
        const canvas = document.createElement('canvas')
        canvas.width = w
        canvas.height = h
        const ctx = canvas.getContext('2d')
        if (!ctx) {
          URL.revokeObjectURL(url)
          reject(new Error('canvas unavailable'))
          return
        }
        ctx.drawImage(img, 0, 0, w, h)
        URL.revokeObjectURL(url)
        try {
          resolve(canvas.toDataURL('image/webp', 0.85))
        } catch {
          resolve(canvas.toDataURL('image/png'))
        }
      }
      img.onerror = () => {
        URL.revokeObjectURL(url)
        reject(new Error('image decode failed'))
      }
      img.src = url
    })
  )

  const portraitToggle = document.createElement('button')
  portraitToggle.dataset.skinChrome = 'portrait-toggle'
  portraitToggle.dataset.skinOwner = SKIN_OWNER
  portraitToggle.type = 'button'
  portraitToggle.setAttribute('aria-label', '立绘与背景')
  portraitToggle.setAttribute('title', '立绘与背景')
  portraitToggle.textContent = '🖼️'
  ownedNodes.add(portraitToggle)

  const portraitPanel = document.createElement('div')
  portraitPanel.dataset.skinChrome = 'portrait-panel'
  portraitPanel.dataset.skinOwner = SKIN_OWNER
  portraitPanel.setAttribute('role', 'dialog')
  portraitPanel.setAttribute('aria-label', '立绘与背景设置')
  portraitPanel.hidden = true
  ownedNodes.add(portraitPanel)

  const panelHead = document.createElement('div')
  panelHead.dataset.gbcPanelHead = ''
  const panelTitle = document.createElement('span')
  panelTitle.textContent = '立绘 / 背景'
  panelTitle.dataset.gbcPanelTitle = ''
  const panelClose = document.createElement('button')
  panelClose.type = 'button'
  panelClose.dataset.gbcPanelClose = ''
  panelClose.setAttribute('aria-label', '关闭')
  panelClose.textContent = '✕'
  panelHead.append(panelTitle, panelClose)
  portraitPanel.append(panelHead)

  // Which target the grid / uploads act on: the right stage or the left
  // companion. Mirrors the same member set so both sides can be swapped.
  let panelSide: 'right' | 'left' = 'right'
  const tabRow = document.createElement('div')
  tabRow.dataset.gbcPanelTabs = ''
  const tabRight = document.createElement('button')
  tabRight.type = 'button'
  tabRight.dataset.gbcPanelTab = 'right'
  tabRight.dataset.gbcPanelTabActive = ''
  tabRight.textContent = '右侧'
  const tabLeft = document.createElement('button')
  tabLeft.type = 'button'
  tabLeft.dataset.gbcPanelTab = 'left'
  tabLeft.textContent = '左侧'
  tabRow.append(tabRight, tabLeft)
  portraitPanel.append(tabRow)

  const setPanelSide = (side: 'right' | 'left'): void => {
    panelSide = side
    for (const tab of [tabRight, tabLeft]) {
      if (tab.dataset.gbcPanelTab === side) tab.dataset.gbcPanelTabActive = ''
      else delete tab.dataset.gbcPanelTabActive
    }
    if (side === 'right') rotateBox.checked = stageTimer !== undefined
    else rotateBox.checked = leftTimer !== undefined
  }
  tabRight.addEventListener('click', () => setPanelSide('right'))
  tabLeft.addEventListener('click', () => setPanelSide('left'))

  const memberGrid = document.createElement('div')
  memberGrid.dataset.gbcPanelGrid = ''
  GBC_MEMBERS.forEach((src, index) => {
    const thumb = document.createElement('img')
    thumb.src = src
    thumb.alt = ''
    thumb.dataset.gbcMemberPick = String(index)
    memberGrid.append(thumb)
  })
  portraitPanel.append(memberGrid)

  const rotateRow = document.createElement('label')
  rotateRow.dataset.gbcPanelRow = ''
  const rotateBox = document.createElement('input')
  rotateBox.type = 'checkbox'
  rotateBox.checked = settings.enabled && stageTimer !== undefined
  rotateRow.append(rotateBox, document.createTextNode(' 自动轮播'))
  portraitPanel.append(rotateRow)

  const uploadRow = document.createElement('div')
  uploadRow.dataset.gbcPanelRow = ''
  const portraitFile = document.createElement('input')
  portraitFile.type = 'file'
  portraitFile.accept = 'image/*'
  portraitFile.hidden = true
  const backdropFile = document.createElement('input')
  backdropFile.type = 'file'
  backdropFile.accept = 'image/*'
  backdropFile.hidden = true
  const uploadPortraitBtn = document.createElement('button')
  uploadPortraitBtn.type = 'button'
  uploadPortraitBtn.dataset.gbcUploadPortrait = ''
  uploadPortraitBtn.textContent = '上传立绘'
  const uploadBackdropBtn = document.createElement('button')
  uploadBackdropBtn.type = 'button'
  uploadBackdropBtn.dataset.gbcUploadBackdrop = ''
  uploadBackdropBtn.textContent = '上传背景'
  uploadRow.append(portraitFile, uploadPortraitBtn, backdropFile, uploadBackdropBtn)
  portraitPanel.append(uploadRow)

  const resetBtn = document.createElement('button')
  resetBtn.type = 'button'
  resetBtn.dataset.gbcPanelReset = ''
  resetBtn.textContent = '恢复默认'
  portraitPanel.append(resetBtn)

  const applyUpload = (file: File | undefined, kind: 'portrait' | 'backdrop'): void => {
    if (file === undefined) return
    downscaleToDataUrl(file, kind === 'portrait' ? 1200 : 1800)
      .then((dataUrl) => {
        if (kind === 'portrait') {
          if (panelSide === 'left') {
            settings.customLeftPortrait = dataUrl
            leftComposerFigure.src = dataUrl
            stopLeftRotation()
            rotateBox.checked = false
          } else {
            settings.customPortrait = dataUrl
            const img = document.querySelector<HTMLImageElement>('[data-gbc-stage-portrait]')
            if (img !== null) img.src = dataUrl
            stopStageRotation()
            rotateBox.checked = false
          }
        } else {
          settings.customBackdrop = dataUrl
          body.style.setProperty('background-image', `url(${dataUrl})`)
        }
        saveSettings(settings)
      })
      .catch(() => { /* unreadable image: keep the current art */ })
  }

  portraitToggle.addEventListener('click', () => {
    portraitPanel.hidden = !portraitPanel.hidden
  })
  panelClose.addEventListener('click', () => {
    portraitPanel.hidden = true
  })
  memberGrid.addEventListener('click', (event) => {
    const target = event.target instanceof Element ? event.target.closest('[data-gbc-member-pick]') : null
    if (target === null) return
    const index = Number(target.dataset.gbcMemberPick)
    if (panelSide === 'left') {
      leftIndex = index
      leftComposerFigure.src = GBC_MEMBERS[index]
      stopLeftRotation()
      rotateBox.checked = false
      return
    }
    const img = document.querySelector<HTMLImageElement>('[data-gbc-stage-portrait]')
    if (img === null) return
    stageIndex = index
    img.src = GBC_MEMBERS[index]
    delete img.dataset.gbcSwapping
    stopStageRotation()
    rotateBox.checked = false
  })
  uploadPortraitBtn.addEventListener('click', () => portraitFile.click())
  portraitFile.addEventListener('change', () => {
    applyUpload(portraitFile.files?.[0], 'portrait')
    portraitFile.value = ''
  })
  uploadBackdropBtn.addEventListener('click', () => backdropFile.click())
  backdropFile.addEventListener('change', () => {
    applyUpload(backdropFile.files?.[0], 'backdrop')
    backdropFile.value = ''
  })
  rotateBox.addEventListener('change', () => {
    if (panelSide === 'left') {
      if (rotateBox.checked) startLeftRotation()
      else stopLeftRotation()
      return
    }
    if (rotateBox.checked) startStageRotation()
    else stopStageRotation()
  })
  resetBtn.addEventListener('click', () => {
    delete settings.customPortrait
    delete settings.customBackdrop
    delete settings.customLeftPortrait
    saveSettings(settings)
    const img = document.querySelector<HTMLImageElement>('[data-gbc-stage-portrait]')
    if (img !== null) img.src = GBC_MEMBERS[stageIndex % GBC_MEMBERS.length]
    if (leftComposerFigure.src !== GBC_TOMO_1) leftComposerFigure.src = GBC_TOMO_1
    syncBackdrop()
    rotateBox.checked = settings.enabled
    if (settings.enabled) startStageRotation()
    startLeftRotation()
  })

  body.append(portraitToggle, portraitPanel)

  if (settings.enabled) startStageRotation()

  const syncSidebarDecorations = (): void => {
    syncTitlebarHeight?.()
    decorateTitlebarBrand(ownedNodes)
    decorateSidebar(ownedNodes, decoratedElements)
    decorateWorkspaceTree(decoratedElements)
    ensureSidebarObserved()
    const sidebar = document.querySelector<HTMLElement>(SIDEBAR_COLUMN_SELECTOR)
    if (sidebar === null) clearSidebarWidth()
    else if (resizeObserver === undefined) applySidebarWidth(sidebar.getBoundingClientRect().width)
  }

  const isSkinChrome = (node: Node): boolean => (
    node instanceof Element && node.getAttribute('data-skin-owner') === SKIN_OWNER
  )

  const nodeTouches = (node: Node, selector: string): boolean => (
    node instanceof Element && (node.matches(selector) || node.querySelector(selector) !== null)
  )
  const sidebarChromeSelector = `${SIDEBAR_COLUMN_SELECTOR}, [class*='titlebar']`
  const composerSelector = "[data-phase='hero'], [data-phase='active']"

  // ResizeObserver writes the animated width through CSSOM, so it never enters
  // this observer. Keep structural decoration in the MutationObserver checkpoint
  // before paint: delaying every change made the wide/rail hand-off visibly late.
  // Skin-owned insertions are ignored so decorating a React-owned node cannot
  // schedule a redundant whole-sidebar pass.
  observer = new MutationObserver((records) => {
    let sidebarStructureChanged = false
    let workspaceStateChanged = false
    let backdropChanged = false
    let composerChanged = false
    let settingsStateChanged = false
    for (const record of records) {
      if (record.type === 'attributes') {
        const target = record.target instanceof Element ? record.target : undefined
        if (record.attributeName === 'aria-expanded'
          && target !== undefined
          && target.closest("[data-slot='sidebar.settings']") !== null) {
          settingsStateChanged = true
        } else if ((record.attributeName === 'aria-expanded' || record.attributeName === 'aria-selected')
          && target !== undefined && target.closest(SIDEBAR_COLUMN_SELECTOR) !== null) {
          workspaceStateChanged = true
        } else if (record.attributeName === 'data-ds-dark-theme' && record.target === body) {
          backdropChanged = true
        } else if (record.attributeName === 'data-phase' && target?.matches(composerSelector)) {
          composerChanged = true
        }
        continue
      }
      const appNodes = [...record.addedNodes, ...record.removedNodes]
        .filter(node => node instanceof Element && !isSkinChrome(node))
      const target = record.target instanceof Element ? record.target : undefined
      if (appNodes.length > 0 && (appNodes.some(node => nodeTouches(node, sidebarChromeSelector))
        || (target !== undefined && target.closest(SIDEBAR_COLUMN_SELECTOR) !== null))) {
        sidebarStructureChanged = true
      }
      if (appNodes.length > 0 && (appNodes.some(node => nodeTouches(node, composerSelector))
        || (target !== undefined && target.closest(composerSelector) !== null))) {
        composerChanged = true
      }
      if (appNodes.some(node => nodeTouches(node, SETTINGS_MASK_SELECTOR))) {
        settingsStateChanged = true
      }
    }
    if (sidebarStructureChanged) syncSidebarDecorations()
    else if (workspaceStateChanged) decorateWorkspaceTree(decoratedElements)
    if (backdropChanged) syncBackdrop()
    if (composerChanged) syncComposerMotion()
    if (settingsStateChanged) syncSettingsBackdropFrame()
  })
  observer.observe(body, {
    attributes: true,
    attributeFilter: ['aria-expanded', 'aria-selected', 'data-ds-dark-theme', 'data-phase'],
    childList: true,
    subtree: true,
  })

  const favicon = document.createElement('link')
  favicon.rel = 'icon'
  favicon.type = 'image/webp'
  favicon.href = GBC_ICON
  favicon.dataset.skinChrome = 'favicon'
  favicon.dataset.skinOwner = SKIN_OWNER
  ownedNodes.add(favicon)
  document.head.append(favicon)

  document.title = SKIN_TITLE
}
