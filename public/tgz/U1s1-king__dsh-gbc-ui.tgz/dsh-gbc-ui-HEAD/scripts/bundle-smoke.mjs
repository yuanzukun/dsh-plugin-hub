/**
 * Bundle smoke test — validates the BUILT artifact (lib/client.js), not the
 * source: registers the ModuleLoader callback the way the dsh web GUI does,
 * applies the skin inside a jsdom window, and asserts the injected chrome,
 * the painted backdrop, the 🎸 toggle, and the full cleanup contract.
 * Run: node scripts/bundle-smoke.mjs
 */
import { readFileSync } from 'node:fs'
import vm from 'node:vm'
import { JSDOM } from 'jsdom'

const dom = new JSDOM('<!DOCTYPE html><html><head></head><body></body></html>', {
  url: 'http://localhost:3080/',
  pretendToBeVisual: true,
})
const { window } = dom
const context = vm.createContext(window)

window.__ModuleLoader__ = {
  load({ id, factory }) {
    const exports = factory((request) => {
      throw new Error(`unexpected runtime require: ${request}`)
    })
    window.__loadedSkin = { id, exports }
  },
}

const code = readFileSync(new URL('../lib/client.js', import.meta.url), 'utf8')
vm.runInContext(code, context, { filename: 'lib/client.js' })

const skin = window.__loadedSkin
if (!skin || skin.id !== 'dsh-gbc-ui') throw new Error('bundle did not self-register')
if (typeof skin.exports?.apply !== 'function') throw new Error('apply not exported')

let cleanup
const ctx = {
  effect(factory) {
    cleanup = factory()
    return () => cleanup?.()
  },
}
skin.exports.apply(ctx)

const { document } = window
const body = document.body
let failures = 0
const check = (cond, msg) => {
  if (cond) console.log(`ok: ${msg}`)
  else { console.error(`FAIL: ${msg}`); failures += 1 }
}

check(body.hasAttribute('data-dsh-gbc-atelier'), 'body scoped attribute set')
check(document.querySelector("[data-skin-chrome='character-stage']") !== null, 'character stage injected')
for (const chrome of ['dim-veil', 'stage-toggle', 'portrait-toggle', 'portrait-panel', 'left-composer-figure', 'subaru-figure']) {
  check(document.querySelector(`[data-skin-chrome='${chrome}']`) !== null, `${chrome} injected`)
}
const picker = document.querySelector("[data-skin-chrome='portrait-panel']")
check(picker !== null && picker.hidden === true, 'portrait panel starts hidden')
const pickerToggle = document.querySelector("[data-skin-chrome='portrait-toggle']")
pickerToggle.click()
check(picker.hidden === false, 'portrait toggle opens the panel')
check(document.querySelectorAll('[data-gbc-member-pick]').length === 14, 'member grid lists all 14 portraits')
check(document.querySelector("[data-skin-chrome='sidebar-width-rule']") !== null, 'width rule sheet injected')
check(body.style.backgroundImage.includes('data:image/webp;base64'), 'palace backdrop painted')
check(body.style.getPropertyValue('--gbc-pink') === '#e84855', 'accent default applied')
const portrait = document.querySelector('[data-gbc-stage-portrait]')
check(portrait !== null && portrait.src.startsWith('data:image/webp;base64'), 'portrait painted')
const group = document.querySelector('[data-gbc-stage-group]')
check(group !== null && group.src.startsWith('data:image/webp;base64'), 'group backdrop painted')
check(document.title.includes('GirlsBangCry'), 'title set')

const toggle = document.querySelector("[data-skin-chrome='stage-toggle']")
toggle.click()
check(body.hasAttribute('data-gbc-stage-off'), 'toggle disables the stage')
toggle.click()
check(!body.hasAttribute('data-gbc-stage-off'), 'toggle re-enables the stage')

cleanup()
check(!body.hasAttribute('data-dsh-gbc-atelier'), 'body attribute retracted on dispose')
check(document.querySelector("[data-skin-owner='gbc-atelier']") === null, 'all chrome removed on dispose')
check(body.style.backgroundImage === '', 'backdrop restored on dispose')
check(document.title === '', 'title restored on dispose')

console.log(failures === 0 ? 'BUNDLE SMOKE PASSED' : `BUNDLE SMOKE FAILED (${failures})`)
process.exitCode = failures === 0 ? 0 : 1
