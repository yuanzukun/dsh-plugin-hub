# Convert the source PNG artwork (D:\dsh-GBC-GUI) into the plugin's webp assets.
# Requires ffmpeg with libwebp on PATH. Run from the repo root:
#   powershell -ExecutionPolicy Bypass -File scripts/gen-assets.ps1
$ErrorActionPreference = 'Stop'

$src = 'D:\dsh-GBC-GUI'
$out = Join-Path $PSScriptRoot '..\assets'
if (Test-Path $out) { Remove-Item (Join-Path $out '*') -Force -Recurse }
New-Item -ItemType Directory -Path $out -Force | Out-Null

$ff = Get-Command ffmpeg -ErrorAction Stop
Write-Host "ffmpeg: $($ff.Source)"

function Convert-To-Webp {
  param(
    [string]$InputFile,
    [string]$OutputName,
    [string]$Filter = $null,
    [int]$Quality = 82,
    [int]$Level = 6
  )
  $target = Join-Path $out $OutputName
  $args = @('-hide_banner', '-loglevel', 'error', '-y', '-i', $InputFile)
  if ($Filter) { $args += @('-vf', $Filter) }
  $args += @('-c:v', 'libwebp', '-quality', "$Quality", '-compression_level', "$Level", $target)
  & $ff.Source @args
  if ($LASTEXITCODE -ne 0) { throw "ffmpeg failed for $OutputName" }
  $kb = [math]::Round((Get-Item $target).Length / 1KB)
  Write-Host ("  {0,-28} {1} KB" -f $OutputName, $kb)
}

Write-Host '== palace backdrops =='
Convert-To-Webp (Join-Path $src 'maid-atelier-palace-day-v4.png') 'gbc-palace-day.webp'    'scale=-2:1428' 78
# Night variant: darkened + slightly blue-shifted day scene.
Convert-To-Webp (Join-Path $src 'maid-atelier-palace-day-v4.png') 'gbc-palace-night.webp'  'scale=-2:1428,eq=brightness=-0.26:saturation=0.8:contrast=1.06,colorbalance=bs=0.1:bm=0.05' 80

Write-Host '== viewport chrome ornaments =='
Convert-To-Webp (Join-Path $src 'maid-composer-frame-v4.png')     'gbc-composer-frame.webp'    'scale=2000:-2' 88
Convert-To-Webp (Join-Path $src 'maid-settings-frame-v1.png')     'gbc-settings-frame.webp'    $null           92
Convert-To-Webp (Join-Path $src 'maid-sidebar-corner-v1.png')     'gbc-sidebar-corner.webp'    'scale=480:480' 92
Convert-To-Webp (Join-Path $src 'maid-workspace-ribbon-v2.png')   'gbc-workspace-ribbon.webp'  $null           95
Convert-To-Webp (Join-Path $src 'maid-workspace-shield-v2.png')   'gbc-workspace-shield.webp'  $null           95

Write-Host '== character portraits =='
$members = @(
  @{ file = '人物立绘.png';   name = 'gbc-member-01.webp' },
  @{ file = '人物立绘1.png';  name = 'gbc-member-02.webp' },
  @{ file = '人物立绘2.png';  name = 'gbc-member-03.webp' },
  @{ file = '人物立绘3.png';  name = 'gbc-member-04.webp' },
  @{ file = '人物立绘5.png';  name = 'gbc-member-05.webp' },
  @{ file = '人物立绘6.png';  name = 'gbc-member-06.webp' },
  @{ file = '人物立绘7.png';  name = 'gbc-member-07.webp' }
)
foreach ($m in $members) {
  Convert-To-Webp (Join-Path $src $m.file) $m.name 'scale=-2:1600' 82
}
Convert-To-Webp (Join-Path $src '多个人物的立绘.png') 'gbc-group.webp' 'scale=2400:-2' 80

Write-Host '== favicon (shield crop) =='
Convert-To-Webp (Join-Path $src 'maid-workspace-shield-v2.png') 'gbc-favicon.webp' 'scale=48:48' 95 9

Write-Host 'done'
