# Retheme the GBC atelier CSS from the maid-atelier navy/gold palette to a
# GBC black/pink palette by remapping color families in HSL space:
#   gold/amber family  (hue 25-75)   -> pink (hue ~340)
#   blue family        (hue 200-270) -> plum-black / lavender-pink by lightness
#   red family         (hue <25)     -> pink
#   neutrals and porcelain           -> kept (slight warm tilt for porcelain)
#
# Prereq: src/client/gbc-atelier.module.css exists (copy of the maid-atelier
# module css with maid->gbc token rename already applied).
# Run: powershell -ExecutionPolicy Bypass -File scripts/retheme-css.ps1
$ErrorActionPreference = 'Stop'
$cssPath = Join-Path $PSScriptRoot '..\src\client\gbc-atelier.module.css'
$css = [System.IO.File]::ReadAllText($cssPath, [System.Text.Encoding]::UTF8)

function RgbToHsl([int]$r, [int]$g, [int]$b) {
  $rn = $r / 255.0; $gn = $g / 255.0; $bn = $b / 255.0
  $max = [math]::Max($rn, [math]::Max($gn, $bn)); $min = [math]::Min($rn, [math]::Min($gn, $bn))
  $l = ($max + $min) / 2
  if ([math]::Abs($max - $min) -lt 1e-6) { return @{ h = 0.0; s = 0.0; l = $l } }
  $d = $max - $min
  $s = if ($l -gt 0.5) { $d / (2 - $max - $min) } else { $d / ($max + $min) }
  $h = if ($max -eq $rn) { (($gn - $bn) / $d + 6) % 6 } elseif ($max -eq $gn) { (($bn - $rn) / $d + 2) } else { (($rn - $gn) / $d + 4) }
  return @{ h = $h * 60; s = $s; l = $l }
}

function HslToRgb([double]$h, [double]$s, [double]$l) {
  if ($s -lt 1e-6) { $v = [int][math]::Round($l * 255); return "$v,$v,$v" }
  $c = (1 - [math]::Abs(2 * $l - 1)) * $s
  $hp = (($h % 360) + 360) % 360 / 60
  $x = $c * (1 - [math]::Abs($hp % 2 - 1))
  $m = $l - $c / 2
  $rgb = switch ([int][math]::Floor($hp)) {
    0 { @($c, $x, 0) }; 1 { @($x, $c, 0) }; 2 { @(0, $c, $x) }
    3 { @(0, $x, $c) }; 4 { @($x, 0, $c) }; default { @($c, 0, $x) }
  }
  $parts = foreach ($v in $rgb) { [int][math]::Round(($v + $m) * 255) }
  return ($parts -join ',')
}

function Remap-Rgb([int]$r, [int]$g, [int]$b) {
  $hsl = RgbToHsl $r $g $b
  $h = $hsl.h; $s = $hsl.s; $l = $hsl.l
  if ($s -lt 0.07) {
    if ($l -gt 0.82) { $h = 340; $s = 0.055 }
    return HslToRgb $h $s $l
  }
  if ($h -lt 25 -or ($h -ge 340 -and $h -lt 360)) { return HslToRgb 342 ([math]::Min(0.92, $s * 1.02)) $l }
  if ($h -ge 25 -and $h -lt 75) { return HslToRgb 344 ([math]::Min(0.95, $s * 0.98)) $l }
  if ($h -ge 75 -and $h -lt 200) { return HslToRgb 330 ([math]::Min(0.3, $s * 0.4)) $l }
  if ($h -ge 200 -and $h -lt 270) {
    if ($l -lt 0.35) { return HslToRgb 336 ([math]::Min(0.5, $s * 0.55)) ([math]::Max(0.04, $l * 0.92)) }
    if ($l -lt 0.62) { return HslToRgb 330 ([math]::Min(0.62, $s * 0.7)) $l }
    return HslToRgb 328 ([math]::Min(0.42, $s * 0.55)) $l
  }
  return HslToRgb ([math]::Max(300, $h * 0.98)) $s $l
}

function Format-Hex([string]$out) {
  $pairs = foreach ($v in ($out -split ',')) { [Convert]::ToString([int]$v, 16).PadLeft(2, '0') }
  return '#' + ($pairs -join '')
}

# --- hex remap ---
$hexCount = 0
$css = [regex]::Replace($css, '#[0-9a-fA-F]{6}\b', {
  param($m)
  $hex = $m.Value
  $r = [Convert]::ToInt32($hex.Substring(1, 2), 16)
  $g = [Convert]::ToInt32($hex.Substring(3, 2), 16)
  $b = [Convert]::ToInt32($hex.Substring(5, 2), 16)
  $new = Format-Hex (Remap-Rgb $r $g $b)
  $hexCount++
  return $new
})

# --- rgba remap (match evaluator preserves the original spacing) ---
$rgbaCount = 0
$css = [regex]::Replace($css, 'rgba\((\d+),\s*(\d+),\s*(\d+),\s*([0-9.]+)\)', {
  param($m)
  $r = [int]$m.Groups[1].Value; $g = [int]$m.Groups[2].Value; $b = [int]$m.Groups[3].Value
  $rgbaCount++
  return 'rgba(' + (Remap-Rgb $r $g $b) + ',' + $m.Groups[4].Value + ')'
})

# --- variable renames for the GBC palette vocabulary ---
$css = $css.Replace('--gbc-navy-950', '--gbc-black-950').Replace('--gbc-navy-900', '--gbc-black-900').Replace('--gbc-navy-800', '--gbc-black-800').Replace('--gbc-gold-soft', '--gbc-pink-soft').Replace('--gbc-gold', '--gbc-pink').Replace('--gbc-indigo', '--gbc-plum').Replace('--gbc-periwinkle', '--gbc-lavender')

[System.IO.File]::WriteAllText($cssPath, $css, (New-Object System.Text.UTF8Encoding($false)))
Write-Host "hex remapped: $hexCount ; rgba remapped: $rgbaCount ; palette vars renamed"
