// Emit src/client/*-art.generated.ts + art.ts from the webp assets in assets/.
// Run `node scripts/gen-art.mjs` from the repo root after regenerating assets.
import { readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const root = new URL('..', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')
const assetsDir = join(root, 'assets')

function b64(name) {
  return `data:image/webp;base64,${readFileSync(join(assetsDir, name)).toString('base64')}`
}

function header(kind) {
  return `/**
 * Generated ${kind} artwork for the GBC atelier skin. Regenerate with:
 *   powershell -ExecutionPolicy Bypass -File scripts/gen-assets.ps1
 *   node scripts/gen-art.mjs
 */
`
}

// ---- background-art.generated.ts -------------------------------------
let bg = header('palace backdrops and character layers') +
  `export const GBC_PALACE_LIGHT = '${b64('gbc-palace-day.webp')}'\n` +
  `export const GBC_PALACE_DARK = '${b64('gbc-palace-night.webp')}'\n` +
  `export const GBC_GROUP = '${b64('gbc-group.webp')}'\n` +
  `export const GBC_MEMBERS = [\n`
for (let i = 1; i <= 7; i++) {
  bg += `  '${b64(`gbc-member-0${i}.webp`)}',\n`
}
for (let i = 1; i <= 5; i++) {
  bg += `  '${b64(`gbc-tomo-${i}.webp`)}',\n`
}
bg += `  '${b64('gbc-aono-1.webp')}',\n`
bg += `  '${b64('gbc-aono-2.webp')}',\n`
bg += `] as const\n`
writeFileSync(join(root, 'src/client/background-art.generated.ts'), bg)

// ---- chrome-art.generated.ts -----------------------------------------
const chrome = header('viewport chrome artwork') +
  `export const GBC_SIDEBAR_CORNER = '${b64('gbc-sidebar-corner.webp')}'\n` +
  `export const GBC_COMPOSER_FRAME = '${b64('gbc-composer-frame.webp')}'\n` +
  `export const GBC_SETTINGS_FRAME = '${b64('gbc-settings-frame.webp')}'\n`
writeFileSync(join(root, 'src/client/chrome-art.generated.ts'), chrome)

// ---- workspace-art.generated.ts --------------------------------------
const ws = header('workspace artwork') +
  `export const GBC_WORKSPACE_RIBBON = '${b64('gbc-workspace-ribbon.webp')}'\n` +
  `export const GBC_WORKSPACE_SHIELD = '${b64('gbc-workspace-shield.webp')}'\n`
writeFileSync(join(root, 'src/client/workspace-art.generated.ts'), ws)

// ---- art.ts (favicon + composer band + subaru + tomo left figure) -------
const art = header('sidebar and ornamental raster assets') +
  `export const GBC_ICON = '${b64('gbc-favicon.webp')}'\n` +
  `export const GBC_COMPOSER_BAND = '${b64('gbc-composer-band.webp')}'\n` +
  `export const GBC_SUBARU = '${b64('gbc-subaru.gif')}'\n` +
  `export const GBC_TOMO_1 = '${b64('gbc-tomo-1.webp')}'\n`
writeFileSync(join(root, 'src/client/art.ts'), art)

console.log('generated art modules:')
for (const f of ['background-art.generated.ts', 'chrome-art.generated.ts', 'workspace-art.generated.ts', 'art.ts']) {
  const p = join(root, 'src/client', f)
  console.log(`  ${f}  ${Math.round(readFileSync(p).length / 1024)} KB`)
}
