import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    environment: 'jsdom',
    environmentOptions: {
      jsdom: {
        // localStorage requires a non-opaque origin
        url: 'http://localhost:3000/',
      },
    },
  },
})
