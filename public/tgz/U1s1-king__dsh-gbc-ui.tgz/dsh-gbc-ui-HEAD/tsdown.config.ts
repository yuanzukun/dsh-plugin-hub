import { clientBundle } from './build/tsdown.client.ts'

export default clientBundle('dsh-gbc-ui', ['src/index.ts'], {
  portableCssModuleIds: true,
})
