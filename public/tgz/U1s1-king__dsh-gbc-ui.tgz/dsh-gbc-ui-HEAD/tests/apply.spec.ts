// @vitest-environment jsdom
/**
 * GBC Atelier skin apply spec — the template contract: the body attribute
 * the stylesheet is scoped on is set on apply and retracted on dispose,
 * every injected chrome element (marked data-skin-chrome) is removed, and
 * the rotating character stage obeys the settings surface.
 */
import { afterEach, describe, expect, it, vi } from 'vitest'
import { Context, type Fiber } from '@deepseek-ai/cordis'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { apply } from '../src/client/index.ts'

const SETTINGS_KEY = 'gbc-ui-settings'

/**
 * jsdom does not expose `localStorage` in this vitest build, so provide a
 * deterministic in-memory store on the window before the skin loads.
 */
const memoryStorage: Storage = {
  get length(): number { return this._size() },
  _store: new Map<string, string>(),
  _size(): number { return (this as unknown as { _store: Map<string, string> })._store.size },
  getItem(key: string): string | null {
    return (this as unknown as { _store: Map<string, string> })._store.get(key) ?? null
  },
  setItem(key: string, value: string): void {
    (this as unknown as { _store: Map<string, string> })._store.set(key, String(value))
  },
  removeItem(key: string): void {
    (this as unknown as { _store: Map<string, string> })._store.delete(key)
  },
  clear(): void {
    (this as unknown as { _store: Map<string, string> })._store.clear()
  },
  key(index: number): string | null {
    return [...(this as unknown as { _store: Map<string, string> })._store.keys()][index] ?? null
  },
}
Object.defineProperty(window, 'localStorage', { value: memoryStorage, configurable: true })

let fiber: Fiber | undefined

async function mount(): Promise<Fiber> {
  const f = new Context().plugin({ apply })
  await f.await()
  return f
}

/** Let jsdom deliver the current MutationObserver checkpoint. */
async function flushMutations(): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, 0))
}

afterEach(async () => {
  await fiber?.dispose()
  fiber = undefined
  vi.useRealTimers()
  vi.unstubAllGlobals()
  document.body.innerHTML = ''
  document.title = ''
  window.localStorage.clear()
})

describe('GBC Atelier skin apply', () => {
  it('declares only the public rc.6 client manifest', () => {
    const manifest = JSON.parse(readFileSync(resolve(process.cwd(), 'package.json'), 'utf8'))
    expect(manifest.dsh.client).toEqual({ inject: [], platform: 'web' })
    expect(manifest).not.toHaveProperty('dshClient')
    expect(manifest.peerDependencies).toHaveProperty('@deepseek-ai/cordis', '^4.0.1')
  })

  it('sets the body attribute and retracts it on dispose', async () => {
    fiber = await mount()
    expect(document.body.hasAttribute('data-dsh-gbc-atelier')).toBe(true)
    await fiber.dispose()
    expect(document.body.hasAttribute('data-dsh-gbc-atelier')).toBe(false)
  })

  it('injects the stage, veil, toggle and trims as skin-owned chrome', async () => {
    fiber = await mount()
    const chrome = [...document.querySelectorAll<HTMLElement>("[data-skin-owner='gbc-atelier']")]
    const kinds = chrome.map(node => node.dataset.skinChrome).filter(Boolean)
    for (const expected of ['character-stage', 'dim-veil', 'stage-toggle', 'sidebar-width-rule']) {
      expect(kinds).toContain(expected)
    }
    expect(document.querySelector('[data-gbc-stage-portrait]')).not.toBeNull()
    expect(document.querySelector('[data-gbc-stage-group]')).not.toBeNull()

    await fiber!.dispose()
    expect(document.querySelector("[data-skin-owner='gbc-atelier']")).toBeNull()
    expect(document.body.style.getPropertyValue('background-image')).toBe('')
  })

  it('paints the palace backdrop and swaps on dark theme', async () => {
    fiber = await mount()
    expect(document.body.style.getPropertyValue('background-image')).toContain('data:image/webp;base64')
    document.body.setAttribute('data-ds-dark-theme', '')
    await flushMutations()
    expect(document.body.style.getPropertyValue('background-image')).toContain('data:image/webp;base64')
  })

  it('rotates the stage member on the configured interval', async () => {
    vi.useFakeTimers()
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify({ enabled: true, rotateInterval: 30 }))
    fiber = await mount()
    const portrait = document.querySelector<HTMLImageElement>('[data-gbc-stage-portrait]')
    const initial = portrait!.src
    vi.advanceTimersByTime(30_000)
    vi.advanceTimersByTime(450)
    expect(portrait!.src).not.toBe(initial)
  })

  it('toggles the stage off and back on via the 🎸 switch', async () => {
    fiber = await mount()
    const toggle = document.querySelector<HTMLButtonElement>("[data-skin-chrome='stage-toggle']")
    expect(document.body.hasAttribute('data-gbc-stage-off')).toBe(false)
    toggle!.click()
    expect(document.body.hasAttribute('data-gbc-stage-off')).toBe(true)
    toggle!.click()
    expect(document.body.hasAttribute('data-gbc-stage-off')).toBe(false)
  })

  it('applies the stored dim, blur and accent settings', async () => {
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify({ dim: 0.5, blur: 3, accent: '#123456' }))
    fiber = await mount()
    const veil = document.querySelector<HTMLElement>("[data-skin-chrome='dim-veil']")
    expect(veil!.style.background).toBe('rgba(16, 8, 13, 0.5)')
    expect(veil!.style.backdropFilter).toBe('blur(3px)')
    expect(document.body.style.getPropertyValue('--gbc-pink')).toBe('#123456')
  })

  it('registers cleanup before a later CSSOM initialization failure', () => {
    let dispose: (() => void) | undefined
    const ctx = {
      effect(factory: () => () => void): void {
        dispose = factory()
      },
    } as unknown as Context
    const insertRule = vi.spyOn(CSSStyleSheet.prototype, 'insertRule')
      .mockImplementationOnce(() => {
        throw new Error('fixture CSSOM failure')
      })

    expect(() => apply(ctx)).toThrow('fixture CSSOM failure')
    expect(dispose).toBeTypeOf('function')
    dispose?.()

    expect(document.body.hasAttribute('data-dsh-gbc-atelier')).toBe(false)
    expect(document.querySelector("[data-skin-owner='gbc-atelier']")).toBeNull()
    insertRule.mockRestore()
  })

  it('decorates the sidebar footer and workspace rows when present', async () => {
    document.body.innerHTML = `
      <div data-pane='sidebar'>
        <div>
          <div data-slot='sidebar.settings'>
            <button aria-expanded='false'>设置</button>
            <div data-slot='sidebar.footer.action'></div>
          </div>
          <div role='tree'>
            <div role='treeitem' aria-expanded='true'>
              <span class='projectText'>w</span>
            </div>
            <div role='treeitem' aria-selected='true'></div>
          </div>
        </div>
      </div>`
    fiber = await mount()
    await flushMutations()
    expect(document.querySelector('[data-gbc-sidebar-footer]')).not.toBeNull()
    expect(document.querySelector('[data-gbc-session-row]')).not.toBeNull()
    expect(document.querySelector('[data-gbc-workspace-row]')).not.toBeNull()
    expect(document.querySelector('[data-gbc-workspace-active]')).not.toBeNull()
  })
})
