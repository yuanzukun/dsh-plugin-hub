# Changelog

All notable changes to this project are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses
[Semantic Versioning](https://semver.org/).

## [Unreleased]

### 0.3.0 candidate — 2026-09-28

- Target DSH 0.1.7-rc.2; prior compatibility evidence remains historical.
- 66 native tools, 47 task mappings, conditional profile readiness, PTC mode, and verified session-query activation.


### Changed

- Refresh the generated catalog to 59 native tools at official upstream commit `c291e7961a515f6d7af9304e7fd1d257929aef26`.
- Follow the current base's enabled web-fetch default while requiring the selected HTTP provider in effective-profile checks.
- Preserve existing version gates for activation recipes; a newer catalog does not expand activation compatibility.

## [0.2.1] - 2026-08-16

### Added

- Five-stage capability lifecycle with provider-aware operational readiness.
- Version-gated activation planning, activation, verification, deactivation, and automatic rollback APIs.
- First reviewed Tier-1 recipe for official workspace-authorized session full-text search.
- Automatic runtime activation through the existing `native_capability` tool.
- Consumer-install smoke coverage and machine-readable `llms.txt` discovery metadata.

### Changed

- GitHub installations now consume committed prebuilt artifacts without build approval.
- Runtime guidance is intentionally small and prioritizes operational official DSH capabilities.
- English and Chinese READMEs now lead with the one-command DSH journey and real scenarios.

### Removed

- Consumer lifecycle build scripts, including `prepare`.

### Compatibility

| Surface | v0.1 behavior | v0.2.1 behavior | Compatibility |
| --- | --- | --- | --- |
| `native_capability` | Task lookup | Task lookup plus lifecycle and reviewed activation | Compatible; existing fields remain |
| `dsh-native lookup` | Native lookup | Native lookup with richer lifecycle data | Compatible command and flags |
| `dsh-native status` | Profile status | Provider-aware lifecycle status | Compatible command and JSON extension |
| Agent Skill | Native-first guidance | Native-first guidance plus safe activation policy | Same name and installation path |
| Node API | Lookup, catalog, profile, and install exports | Existing exports plus activation APIs | Existing exports preserved |

## [0.1.0] - 2026-08-14

### Added

- Native-first Agent Skill with focused references and more than 15 recipes.
- Official Codex skill-only plugin manifest pointing to the same Skill tree.
- Installable DSH bundle and thin runtime adapter exposing `native_capability`.
- Live runtime availability detection from the calling Agent's visible DSH tools.
- Curated task map covering more than 30 high-value DSH intents.
- Generated official tool and base-profile snapshot pinned to an upstream commit.
- Profile-aware CLI, offline lookup, JSON output, Node API, and safe Skill installer.
- Cross-platform CI and open-source project policies.

[Unreleased]: https://github.com/cyanseek/dsh-native-playbook/compare/v0.2.1...HEAD
[0.2.1]: https://github.com/cyanseek/dsh-native-playbook/compare/v0.1.0...v0.2.1
[0.1.0]: https://github.com/cyanseek/dsh-native-playbook/releases/tag/v0.1.0
