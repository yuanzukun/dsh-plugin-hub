import { fileURLToPath } from 'node:url'
import { defineConfig } from 'vitest/config'

export default defineConfig({
  resolve: {
    alias: {
      // 上游实现包由宿主解析；0.2.2 起控制与清单工具共用根入口，不再使用已删除的子路径。
      '@deepseek-ai/dsh-tool-subagent-control': fileURLToPath(
        new URL('./tests/stubs/tool-subagent-control.ts', import.meta.url),
      ),
    },
  },
  test: {
    environment: 'node',
    include: ['tests/**/*.spec.{ts,tsx}'],
  },
})
