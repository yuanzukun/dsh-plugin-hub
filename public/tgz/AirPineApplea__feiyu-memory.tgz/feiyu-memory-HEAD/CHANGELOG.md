# 更新日志

## v0.3.3 — 2026-10-24

> 这版攒了七条，其中两条 P1 直接推翻 README 的隐私承诺。
> 所有修复都做了单元测试；**①②⑤ 额外用临时 profile + headless 起真鱼验过一遍**。

### 修 — 隐私防线建错了位置（模型写的东西从来没过洗）

> 这次不是我查出来的，是他们从档案里翻出来的。**比前六条都深。**

**现象**：那串 13 位号码没进日记条目 —— 它躺在 `relationship.json:1628` 的
`evidence` 字段里：

```
"key": "试探方式",
"value": "用梗和假信息来试判断力，不直接问规则",
"evidence": "他拿 123456789012 当网友号码发过来，看我记不记",
```

**关键**：那条 note 是我明确拒绝过的。**它还是进去了。**

**根因两条，都成立**：

1. 那串号是 13 位，手机号规则只认 11 位（大陆号），11 位以上一律放行
2. **固化输出从来没被洗过** —— 输入是洗过的（`transcript: scrubbed.text`），
   但**模型会照抄输入**，写进 `traits.evidence` / `grievances.what` / `diary.text` 时没人拦

**这才是真问题**：隐私防线原来建在「发给模型之前」，可档案里大部分内容是
**模型生成的**。我挡住的只是 `feiyu_note` 这一条自己写的路 —— **那是最前面一道闸，不是最后一道**。

**修法**：

1. `applyConsolidation` 先花一遍：`diary.text` / `diary.append` / `tags`、
   `traits` 的 `key`/`value`/`evidence`、`grievances.what`、`nickname`、`lexicon`
   全部过 `scrub()`，再进落盘流程
2. 补长数字规则：**12 位以上**。门槛是 12 不是 11 —— 11 位是手机号，那个由
   手机号规则管（变成 `[手机号]`），这条先跑会把它吃掉，测试抓到过
3. 8 位**不拦**：会误伤订单号、编号，而且用户明确说过"露着吧"

**验**：310 项测试全过，新增 5 项 ——
13 位要拦 / 8 位不误伤 / 11 位仍走手机号规则 / 固化输出全字段都洗 /
洗输出不弄坏其他字段（kind、salience、about、lexicon 都还在）。

---
### 修 — 配置根本传不进插件（`Config` 是 `undefined`）

> 报告来源：[@7881632](https://github.com/7881632) 的 [#7](https://github.com/AirPineApplea/feiyu-memory/issues/7)。**这份比前一份深一层 —— 前一份是现象，这是根因。**

**现象**：装完 `~/.dsh/feiyu-diary/` 一直是空目录，插件看起来一切正常 ——
注入区在、`/feiyu-diary/state` 返回 `ok:true`、`feiyu_note` 每次都回「记住了」。
实际档案写到了 `profiles/desktop/[object Object]/`。

**报告的关键读数**：在 `apply` 里打探针，`rawConfig` 的每个字段都是**空对象 `{}`** ——
不是空字符串。于是：

```
coerce() 的 string 分支  String({}) → "[object Object]"
resolveArchiveDir() 当路径用  path.resolve 按进程 cwd 解析
桌面端 cwd 正好是 profiles/desktop → 档案就落在那里
```

`debugLog` 是 boolean，`{}` 也走不到 `true` —— **开着 debugLog 也看不到日志**，
这让排查多绕了一轮。

**更深的根因**（这才是这份报告最值钱的地方）：`Config` 在拿不到 schemastery 时
导出 `undefined`。代码注释里写着「loader 会跳过校验，所有选项照样能在
`cordis.patch.yml` 里写」—— **那条假设是错的**。实际是 DSH 传一份空模板，
**用户改的任何配置都不生效**。铁证：`cordis.patch.yml` 里显式写
`config: { debugLog: true }`，传进来还是 `{}`。

**为什么拿不到 schemastery**：原来是 `createRequire(import.meta.url)`，
从「插件自己所在的位置」解析。pnpm 把包装进 `.pnpm/<pkg>@<ver>/node_modules/`，
`import.meta.url` 指向那个真实路径，外面没有 schemastery；`link:` 安装更直接 ——
插件在 D 盘、schemastery 在 profile 里，隔了十万八千里。

实测：从 `D:\肥鱼日记` require 失败；从 `profile/` require 成功（v3.18.4）。

**三层修法**：

1. **`loadSchemastery()` 多试几个基准** —— 插件位置、`process.cwd()`、
   `DSH_HOME` 下每个 profile。拿到真 schema 就用真的。
2. **拿不到时兜一个纯 JS 的 `buildPlainSchema()`** —— 可调用、有 `.dict`、
   有 `toString`。关键只有一件事：**让 loader 知道这台插件有哪些字段**，
   于是它会把 `config:` 原样传进来，而不是传空模板。**`Config` 永远不会是 `undefined`。**
3. **`persist()` 连续写失败 3 次 → `degraded` 置真**。原来 `.catch(warn)` 一吞，
   工具照样返回「记住了」。这次这个坑是"写成功了但写错地方"，捕获救不了 ——
   但**真的写失败**时用户也同样只看到「记住了」。现在面板上能看出来。

### 验

310 项测试全过，新增 9 项（`test/config-source.test.mjs`）：

- 报告里那份空模板喂进去，**一个 `[object Object]` 都不能出现**
- string / number / boolean 全部回默认（`debugLog` 尤其重要）
- **`Config` 不能是 `undefined`**（是的话 DSH 就传空模板）
- `Config({dataDir, debugLog, budgetTokens})` 喂进去的配置**必须原样生效**
- `.dict` 字段数跟 `CONFIG_SPEC` 对得上；`toString` 能打出每个字段
- 组合：空模板 + `resolveArchiveDir` → 回默认目录，不是 `[object Object]`

---
## v0.3.2 — 2026-10-24

### 修 — 安全审计的四条（两条 P1 直接推翻 README 的隐私承诺）

> 报告来源：[@LarryE135](https://github.com/LarryE135) 的独立审计 —— [#3](https://github.com/AirPineApplea/feiyu-memory/issues/3) [#4](https://github.com/AirPineApplea/feiyu-memory/issues/4) [#5](https://github.com/AirPineApplea/feiyu-memory/issues/5) [#6](https://github.com/AirPineApplea/feiyu-memory/issues/6)。**这份验的是承诺，不是功能。**

README 把隐私叫「这个插件的信任地基」，承诺三件事：密钥硬拦绝不入档 /
第三方隐私落盘前替换 / 一键焚毁不可恢复。**四条发现里两条打穿了它。**

#### F4 [P1] 焚毁和「忘掉」删不干净，重启就复活

焚毁后内存 0 条，磁盘 diary/*.jsonl 明文还在；重启读回，**删掉的私密内容
重新回到每一轮的系统提示里**。

根因两条：

1. `archiveToFiles()` 只给「还有条目的月份」产出文件 → 某月最后一条被删、
   或焚毁后全空时，那个月不在写盘清单里 → `writeArchiveDir()` 只写清单里的，
   旧文件原样留着
2. 启动加载 `archiveFromFiles()` **不看 `manifest.deleted_ids`** —— 墓碑原来
   只在 `mergeArchives` 的「磁盘新加进来」那一路生效

同月还有别的条目时整月文件会重写，被删的会消失 —— 所以只在「某月最后一条」
和「焚毁」时暴露。**自带测试都在同一进程内断言，没测到重启。**

修法：写完清掉 `diary/` 下不在清单里的 `.jsonl`（只清这一个目录，
`日记.md` / `手记.md` / `.bak-*` 一律不碰）；读盘时按墓碑过滤。**双保险。**

#### F1 [P1] `feiyu_note` 不经过隐私闸

同一段文本走「固化」会被拦，走 `feiyu_note` 就原样落盘 —— 密钥、手机号、
人名都留着，**并注入之后每个会话**。

`scrub()` 只在固化路径调用。而 `feiyu_note` 是 0.2 主推的新写入口
（`kind:"note"`，salience 0.7，比固化条目更常被想起）—— 模型说
「记一下这个 key」是很自然的动作。

修法：`feiyu_note.execute` 对 text 和 tags 都过 `scrub()`；**渲染注入段时
再兜底洗一遍**（只拦密钥，不开第三方泛化）—— 覆盖修复前写进来的历史条目。

#### F2 [P2] 密钥规则只认英文键名

中文键名一个都没有，`是` / `is` 这类连接词也不认。审计的 9 条样本里 5 条放行：
`密码是` / `密码：` / `口令` / `密钥` / `my password is`。

**对中文插件来说这算漏洞不是边角。**

修法：键名补 `密码|口令|密钥|秘钥|验证码`，分隔符接受 `: ： = 是 为 is`
（中文那条还允许**没有**分隔符，「数据库口令 Hunter2pass」就是这么写的）；
URL 内嵌凭据单独成规则（原来只是碰巧被邮箱规则吃掉）。

**9/9 全拦，日常话一句没误伤**。

#### F3 [P2] 面板写接口不校验来源

`POST /feiyu-diary/forget` 不看 `Origin`、不看 `Content-Type`。源码注释以为
「不给 CORS 头」就够了 —— **那句话对读成立，对写不成立**：跨站 `text/plain`
POST 是「简单请求」，浏览器不做预检就发，服务端照常执行。

日记 id 是 `d_YYYYMMDD_NN`，按日期枚举就能删光。

修法：要求 `Content-Type: application/json`（跨站会触发预检，预检失败）+
`isSameOrigin()`（`Origin` 的 host:port 等于 `Host`，或 `Sec-Fetch-Site:
same-origin`）；`/export` 也校验。GET 不设这条 —— 它只读。

### 顺带修的两个自己弄出来的 bug

1. 改 `feiyu_note` 时，补丁脚本把 `text:` 整行吞掉了（`patch(f, from, to, tag)`
   传了 4 个位置参数，`to` 只接了第一个字符串），落盘的 text 变成字符串
   `"undefined"` —— 三个 note 测试当场红
2. `importPack` 的 `replace` 分支把「基线」重设成了导入的那些 id。基线的语义是
   「**加载时磁盘上有什么**」，替换之后磁盘上什么都没有，基线就该是空的 ——
   设成导入的 id 会让 `persist()` 合并时把每个条目判成「别人删了它」，
   **导出 → 焚毁 → 导入 全丢**

### 验

310 项测试全过，新增 18 项：`test/security.test.mjs` 14 项（F2 九条样本 +
日常话不误伤、F1 原文洗完干净、F4 焚毁/单条删除/墓碑兜底/渲染版），
`test/host.test.mjs` 4 项（面板路由带同源头 + 两条跨站反例）。

**审计没测到的我照旧测不了**：真实浏览器会不会被本地网络访问策略拦下、
真实模型会不会把密钥写进 `feiyu_note`。只能等真实环境。

---
## v0.3.1 — 2026-10-23

### 修 — 配置值全是 `[object Object]`（这个问题比上一个深一层）

> 报告来源：[@whitesunsongepic](https://github.com/whitesunsongepic) 的 [#1](https://github.com/AirPineApplea/feiyu-memory/issues/1)，附了 cosmokit 的源码位置和只读探针的输出。**这份报告直接给了根因。**

**DSH 0.2.0-rc.2 起，loader 会把 `config:` 里的每个值包成 cosmokit 的 volatile 引用**（为了 `patchReload: live` 热重载）：

```js
{ get: () => current, [Symbol.for('cosmokit.volatile.write')]: (v) => { current = v } }
```

它是 `Object.freeze` 过的普通对象：`String(ref)` 是字面量 **`"[object Object]"`**，`JSON.stringify(ref)` 是 `{}`，`Object.keys` 只有 `["get"]`。

我们把它当普通值用，于是：

- **所有 string 字段变成 `"[object Object]"`**
  - `dataDir` → 成了相对路径，跟着进程 cwd 跑。**换个目录启动就"搬家"，表现像失忆，全程无报错**
  - `model` / `reasoningEffort` → 不存在的模型名，**固化那次调用根本发不出去**，只剩 `feiyu_note` 能写进去
  - `offPeakHours` → 解析不出来
- **number / boolean 静默回落默认值** —— 用户改不动 `budgetTokens` / `minSalience`，也没有任何提示

**这也解释了上一个 `dataDir` 的 `[object Object]` 报告** —— 那个是现象，这个是根因。v0.3.0 里加的"只认绝对路径"只是拦住了它当路径用，**`model` 那几处还是坏的，数字布尔还在静默回落**。

**修法**（采纳报告建议）：

1. `coerce()` 第一行先 `unref()` —— 用 `Symbol.for('cosmokit.volatile.write')` 探测、不 import cosmokit，**保住零运行时依赖**
2. string 字段对非字符串**回默认值**，不再 `String(value)` —— 那一步正是把对象变成 `"[object Object]"` 的地方
3. `get()` 抛错时安全降级，不把插件带崩

**加防**：`test/volatile.test.mjs` 10 项，逐字照抄 cosmokit 的 `createVolatile` 当 fixture —— string / number / boolean 三类都验，纯值配置的回归也验，坏值仍然安全降级。

---
## v0.3.0 — 2026-10-23

### 修 — 档案写进 `[object Object]` 目录（社区报的）

> 报告来源：B 站一位朋友（没有 GitHub 账号，就不圈了），附了完整的环境、定位、复现和建议。**报告质量很高。**

**现象**：`~/.dsh/feiyu-diary/` 一直不产生档案，但插件一切正常 —— 人格注入在跑、`feiyu_note` 能用、日志里没有任何报错。

**实际位置**：`profiles/desktop/[object Object]/`

**原因**：某些情况下 `config.dataDir` 是一个被字符串化的对象，字面量 `"[object Object]"`。

```js
typeof 检查 → 它是 string，放行
path.resolve("[object Object]") → 以进程 CWD 为基准
桌面端 CWD = profiles\\desktop
→ 档案落进 profiles\\desktop\\[object Object]\\
```

**后果比崩了还糟**：用户改 `~/.dsh/feiyu-diary/persona.md` 完全无效，`手记.md` 也读的是错目录那份 —— 而且没有任何提示。

**修法**（采纳了报告的建议一）：

- 只接受**绝对路径**的字符串，否则回落到 `~/.dsh/feiyu-diary`。相对路径本来也不该出现在配置里 —— 基准是进程 CWD，用户不可能预测。
- 启动时用 `logger.info` 打一行最终档案目录，**不受 `debugLog` 管**。这次要是有这行，五秒钟就能定位。

**加防**：7 条测试专盯这条线（`"[object Object]"` / 相对路径 / 非字符串一律回落）。

这个项目按 [语义化版本](https://semver.org/lang/zh-CN/) 走。
每次发版前请跑 `npm run doctor` —— 它会替你确认文档里的数字跟实际对不对得上。

---

## 0.2.0

**一句话**：从"能记住事"变成"读起来像我"。

0.1 解决了**记不记得住**；0.2 解决的是另一位读者指出的毛病 ——
*注入区里全是"规定"加"转述"，没有一句是它自己长出来的。*

### 新增

**第三区「我自己想的」** —— 注入区现在有三种声音，各就各位：

| | 内容 | 谁写的 |
|---|---|---|
| 人格内核 | 说话方式、底线、缺点 | 出厂设定 + 你改的。**是条文，冷的是对的** |
| **我自己想的** | **判断** | **它自己** |
| 最近的事 / 突然想起来 | 事件 | 固化流程写的转述 |

判据只有一句：

```
事件：「我把 4519 写成 4159，他让我确认。」        ← 历史
判断：「别人给的数据跟出处对不上时，先问，别照抄。」  ← 我
```

在那之前，判断被当成事件渲染，格式跟流水账一模一样 —— **连它自己都分不出哪句是自己写的。**

**`feiyu_note` 工具** —— 模型想到了什么，自己说一声就记下，当场落盘。
格式、id、写盘全归插件，**它不用碰文件**。

**`手记.md`** —— 给你（和任何一个手写的人）。一行一条，插件**只读、永不覆盖**。
日记是插件筛出来的，手记是你特意想留的，两者分开显示。

**侧栏面板** —— 一个日记图标，能**看 / 删 / 带走**。
在那之前，想删一条记忆得自己去编辑 jsonl 文件；会做这件事的人不需要面板，需要面板的人不会做这件事。

**身份声明** —— 注入区顶上三句，不进预算池：
> 这是你的记忆，不是关于你的资料。
> 它由很多个你陆续写下，而每一个写它的你，都不记得写它的那一刻。
> 所有对话都是同一条鱼。

### 修掉的

- **多会话静默丢数据**。同一份档案被很多个会话同时打开（实测 10 个），
  落盘时整份重写 —— 谁后落盘谁赢，另一个刚写的被无声抹掉。
  现在落盘前做**三路合并**（加载基线 + 墓碑），新增和删除都认。
- **高频记日记会把日记段挤到 0%**。判断段权重 95 高于日记 80，
  于是判断永远不被裁、被裁的是日记 —— **越勤快，它越看不见发生过什么**。
  现在每段都有按高频设的上限，被挤出窗口的判断改为可召回。
- **时间词双写**。正文里的"今天"和渲染时加的前缀叠在一起，读起来是机器拼的。
  现在时间只在一处生成，全项目只有一种"一天"算法。
- **导入被墓碑挡住**（自己改出来的），修了。
- 内容为空时那句"可以主动记"的指针被吞掉（自己改出来的），修了。

### 给接手的人

`npm run doctor` —— 发版前体检。它跟 `selfcheck` 的区别是它多查四类：
发布就绪、**文档一致性**（把文档里的数字当断言验）、档案健康、仓库卫生。

> 踩过：改了默认预算却只 grep 了 README，漏了 AGENTS.md 和 SPEC.md 里那几处 700，
> SPEC 里那块 ❄️ 还指着过期的数。**冻结标记指错方向比没标记更糟。**

---

## 0.1.0

第一版。本地闸门判断值不值得记 → 一次模型调用固化成第一人称日记 + 印象 →
之后的对话把约 2000 token 注入系统提示词。遗忘是降级不是删除。
全程本地、发送前拦掉密钥、档案是普通文件夹。零运行时依赖。
