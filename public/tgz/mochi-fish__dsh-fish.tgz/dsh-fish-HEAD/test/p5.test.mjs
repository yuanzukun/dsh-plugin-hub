/**
 * p5.test.mjs —— 2026-10-23 这一轮的回归测试
 *
 * 守四件事：
 *   1. **三个时段各自独立**：把"醒来时间"改坏，不能顺手把"上网时间"也改掉。
 *   2. **上网时段真的生效**：不在时段里就不许碰 B 站接口（不是先请求再丢弃）。
 *   3. **保存不会被 400 挡回来**：观测台提交的 chat / memory / window / browse.window /
 *      bili 必须在 /config 的白名单里。曾漏登记过两次，界面点"保存"直接报错。
 *      现在有一条用例直接从 client.js 的 buildConfig() 反查这张白名单，不再靠手写清单。
 *   4. **设置界面文案不带性别代词**：她/他 在面向用户的字符串里必须为零。
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'

import { normalizeConfig, inWindow, DEFAULTS } from '../lib/settings.js'
import { lookBeforeWake } from '../lib/scheduler.js'
import { registerObserve } from '../lib/observe.js'
import { HER_TOOLS, rememberFromView, registerToolRestrict, forgetBlockedTools } from '../lib/restrict.js'

const HERE = dirname(fileURLToPath(import.meta.url))
const CLIENT = join(HERE, '..', 'lib', 'client.js')
const OBSERVE = join(HERE, '..', 'lib', 'observe.js')

test('默认配置里上网时段是独立的一项，不填就跟着醒来时段（issue #86 第 2 条）', () => {
  const cfg = normalizeConfig({})
  // null = 跟随：醒来 20:00–23:00，上网也就只在这段里，睡着时不会被安排出门
  assert.deepEqual(cfg.browse.window, null)
  assert.deepEqual(cfg.window, ['20:00', '23:00'])
  assert.deepEqual(cfg.comment.window, ['20:00', '23:00'])
  // 改了醒来时段，跟着走的就是新那段
  const moved = normalizeConfig({ window: ['22:00', '23:30'] })
  assert.deepEqual(moved.browse.window, null)
  assert.deepEqual(moved.window, ['22:00', '23:30'])
  // 自己填一段别的 → 就是独立的，原样留着
  const own = normalizeConfig({ browse: { window: ['09:00', '18:00'] } })
  assert.deepEqual(own.browse.window, ['09:00', '18:00'])
  // 填得和醒来时段一模一样 = 跟随，不收两份（不然改了醒来的它不跟）
  const same = normalizeConfig({ browse: { window: ['20:00', '23:00'] } })
  assert.equal(same.browse.window, null)
})

test('坏时段只回退自己那一项，不牵连别的时段', () => {
  const cfg = normalizeConfig({
    window: ['乱写', '23:00'],
    browse: { window: ['09:00', '18:00'] },
    comment: { window: ['09:00', '09:00'] }, // 起止相同 = 无效
  })
  // 醒来时段坏了 → 回默认
  assert.deepEqual(cfg.window, DEFAULTS.window)
  // 上网时段是好的 → 必须原样保留，不能被上一条连坐
  assert.deepEqual(cfg.browse.window, ['09:00', '18:00'])
  // 说话时段起止相同 → 回它自己的默认，不跟 window 走
  assert.deepEqual(cfg.comment.window, DEFAULTS.comment.window)
})

test('上网时段支持跨零点', () => {
  const cfg = normalizeConfig({ browse: { window: ['22:00', '02:00'] } })
  const at = (h) => new Date(2026, 9, 23, h, 30, 0)
  assert.equal(inWindow({ window: cfg.browse.window }, at(23)), true)
  assert.equal(inWindow({ window: cfg.browse.window }, at(1)), true)
  assert.equal(inWindow({ window: cfg.browse.window }, at(12)), false)
})

test('不在上网时段时，一次 B 站接口都不发', async () => {
  const root = await mkdtemp(join(tmpdir(), 'fish-p5-'))
  try {
    const calls = []
    const client = new Proxy({}, {
      get: (_t, k) => (...a) => { calls.push(String(k)); return { ok: false } },
    })
    const cfg = normalizeConfig({ browse: { window: ['09:00', '10:00'] } })
    const out = await lookBeforeWake(root, { name: '测试' }, cfg, '2026-10-23', {
      client,
      now: new Date(2026, 9, 23, 15, 0, 0), // 15:00，在时段外
      events: [],
    }, () => {})
    assert.deepEqual(out, { text: '', intro: '', picks: [] })
    assert.deepEqual(calls, [], '时段外不该碰任何接口')
  } finally {
    await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
})

test('在上网时段内会真的去取素材（证明闸门不是永远关着）', async () => {
  const root = await mkdtemp(join(tmpdir(), 'fish-p5b-'))
  try {
    const calls = []
    const client = new Proxy({}, {
      get: (_t, k) => (...a) => { calls.push(String(k)); return { ok: false, note: 'stub' } },
    })
    const cfg = normalizeConfig({ browse: { enabled: true, window: ['09:00', '18:00'] } })
    await lookBeforeWake(root, { name: '测试' }, cfg, '2026-10-23', {
      client,
      now: new Date(2026, 9, 23, 10, 0, 0),
      events: [],
    }, () => {})
    assert.ok(calls.length > 0, '时段内应该走进去')
  } finally {
    await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
})

/** 极简假 ctx：只提供 observe 需要的两个服务 */
function fakeCtx(root) {
  const routes = []
  const cfg = { connection: null }
  const webServer = { register: (def) => { routes.push(def); return () => {} } }
  return {
    routes,
    cfg,
    get: (k) => (k === 'connection' ? cfg.connection : k === 'webServer' ? webServer : undefined),
    webServer,
    tools: { register: () => {} },
    slots: { inject: () => {}, register: () => {} },
    effect: (fn) => fn(),
    on: () => {},
    logger: { info: () => {}, warn: () => {}, error: () => {} },
    log: () => {},
    root,
  }
}

test('/config 白名单收下观测台提交的全部环境键（含 chat 与 memory）', async () => {
  const root = await mkdtemp(join(tmpdir(), 'fish-p5c-'))
  try {
    const ctx = fakeCtx(root)
    ctx.cfg.connection = { requestRejection: () => null }
    registerObserve(ctx, { root })
    const route = ctx.routes.find((r) => String(r.path || '').endsWith('/config'))
    assert.ok(route, '必须有 /config 路由')

    // 这是观测台 save() 实际提交的形状
    const patch = {
      absenceAfterDays: 3,
      wakesPerDay: 1,
      daily: { events: 1, questions: 1 },
      diary: { visible: true, enabled: true },
      avoid: { keywords: ['恐怖'] },
      window: ['19:00', '22:00'],
      browse: { enabled: true, perDay: 2, topN: 5, danmaku: 3, window: ['08:30', '22:30'] },
      // bili 是 2026-10-29 用户真机踩到的：0.6.5 加了这两个设置项，
      // 客户端整表提交一直带着它们，白名单漏登记 → 改任何一项都报 400。
      bili: { minIntervalMs: 900, jitterMs: 300 },
      notify: { enabled: false },
      chat: { rotateAfter: 30, carry: 6 },
      memory: { docBudget: 1900 },
      comment: { enabled: false, perDay: 1, replyPerDay: 2, replyToReplies: true, scanEveryMin: 30, window: ['20:00', '23:00'] },
    }
    const body = JSON.stringify(patch)
    const req = {
      method: 'POST',
      url: '/dsh-fish/config',
      headers: { 'content-type': 'application/json' },
      on: (ev, fn) => { if (ev === 'data') fn(Buffer.from(body, 'utf8')); if (ev === 'end') fn() },
    }
    let status = 0
    let payload = null
    const res = {
      writeHead: (s) => { status = s },
      end: (s) => { payload = JSON.parse(s || '{}') },
      setHeader: () => {},
    }
    await route.handler(req, res)
    assert.equal(status, 200, `保存不该被挡回来：${JSON.stringify(payload)}`)
    assert.equal(payload.ok, true)
    assert.deepEqual(payload.config.browse.window, ['08:30', '22:30'])
    assert.deepEqual(payload.config.window, ['19:00', '22:00'])
    assert.equal(payload.config.chat.rotateAfter, 30)
    assert.equal(payload.config.chat.carry, 6, '换会话带几轮原话必须真的存进去')
    assert.equal(payload.config.memory.docBudget, 1900)
    assert.equal(payload.config.bili.minIntervalMs, 900, '请求间隔必须真的存进去')
    assert.equal(payload.config.bili.jitterMs, 300, '请求抖动必须真的存进去')
  } finally {
    await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
})

test('/config 拒收起止相同的时段，并把是哪一段说清楚', async () => {
  const root = await mkdtemp(join(tmpdir(), 'fish-p5c-bad-'))
  try {
    const ctx = fakeCtx(root)
    ctx.cfg.connection = { requestRejection: () => null }
    registerObserve(ctx, { root })
    const route = ctx.routes.find((r) => String(r.path || '').endsWith('/config'))
    const post = async (patch) => {
      const body = JSON.stringify(patch)
      const req = {
        method: 'POST',
        url: '/dsh-fish/config',
        headers: { 'content-type': 'application/json' },
        on: (ev, fn) => { if (ev === 'data') fn(Buffer.from(body, 'utf8')); if (ev === 'end') fn() },
      }
      let status = 0
      let payload = null
      const res = {
        writeHead: (s) => { status = s },
        end: (s) => { payload = JSON.parse(s || '{}') },
        setHeader: () => {},
      }
      await route.handler(req, res)
      return { status, payload }
    }

    for (const [label, patch] of [
      ['她醒着的时间段', { window: ['08:00', '08:00'] }],
      ['上网时段', { browse: { window: ['18:00', '18:00'] } }],
      ['评论时段', { comment: { window: ['20:00', '20:00'] } }],
    ]) {
      const { status, payload } = await post(patch)
      assert.equal(status, 400, `${label} 起止相同该被拒`)
      assert.match(payload.error, new RegExp(`^${label}：`))
      assert.match(payload.error, /00:00–23:59/)
    }
  } finally {
    await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
})

test('观测台提交的每个顶层键都在 /config 白名单里（防漂移）', async () => {
  // 2026-10-29 用户真机报「没保存：不允许修改：bili」：0.6.5 加了 bili 两个设置项，
  // 客户端整表提交带着它，服务端白名单没登记 → **每一项设置都存不进去**。
  // 上一版回归测试手写了一份 patch 形状，自己也会漏，所以这里改成互相反查：
  //   客户端 buildConfig() 的顶层键 ←→ 服务端 allowed 数组，缺一个就红。
  const client = await readFile(CLIENT, 'utf8')
  const start = client.indexOf('const buildConfig = () => ({')
  assert.ok(start > 0, '找不到 buildConfig()')
  const end = client.indexOf('\n      })', start)
  assert.ok(end > start, '找不到 buildConfig() 的结尾')
  // 顶层键缩进 8 空格；子键缩进更深，正好靠缩进区分开。
  const keys = [...client.slice(start, end).matchAll(/^ {8}([a-zA-Z]+):/gm)].map((m) => m[1])
  assert.ok(keys.length >= 10, `buildConfig() 只解析出 ${keys.length} 个顶层键，缩进可能变了`)

  const server = await readFile(OBSERVE, 'utf8')
  const m = server.match(/const allowed = \[([^\]]+)\]/)
  assert.ok(m, '找不到 /config 的白名单')
  const allowed = [...m[1].matchAll(/'([^']+)'/g)].map((x) => x[1])

  const missing = keys.filter((k) => !allowed.includes(k))
  assert.deepEqual(missing, [], `这些键客户端会提交、服务端会 400 挡回来：${missing.join(', ')}`)
})

test('白名单仍然挡得住"指向她本人"的键', async () => {
  const root = await mkdtemp(join(tmpdir(), 'fish-p5d-'))
  try {
    const ctx = fakeCtx(root)
    ctx.cfg.connection = { requestRejection: () => null }
    registerObserve(ctx, { root })
    const route = ctx.routes.find((r) => String(r.path || '').endsWith('/config'))
    const body = JSON.stringify({ persona: { name: '小美' }, traits: { shy: 1 } })
    const req = {
      method: 'POST',
      url: '/dsh-fish/config',
      headers: { 'content-type': 'application/json' },
      on: (ev, fn) => { if (ev === 'data') fn(Buffer.from(body, 'utf8')); if (ev === 'end') fn() },
    }
    let status = 0
    let payload = null
    const res = { writeHead: (s) => { status = s }, end: (s) => { payload = JSON.parse(s || '{}') }, setHeader: () => {} }
    await route.handler(req, res)
    assert.equal(status, 400)
    // 报错会原样显示在界面上：得是人话，不能是「不允许修改：persona」那种开发者口吻。
    assert.match(payload.error, /这一版还不支持保存/, `报错要能看懂：${payload.error}`)
    assert.doesNotMatch(payload.error, /不允许修改/, '别再用「不允许修改」这种说法')
  } finally {
    await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
})

test('/config 收得下主人的代词，取值越界就退回「他」（issue #127）', async () => {
  const root = await mkdtemp(join(tmpdir(), 'fish-p5p-'))
  try {
    const ctx = fakeCtx(root)
    ctx.cfg.connection = { requestRejection: () => null }
    registerObserve(ctx, { root })
    const route = ctx.routes.find((r) => String(r.path || '').endsWith('/config'))
    let status = 0
    let payload = null
    const res = { writeHead: (s) => { status = s }, end: (s) => { payload = JSON.parse(s || '{}') }, setHeader: () => {} }
    const post = async (obj) => {
      const body = JSON.stringify(obj)
      const req = {
        method: 'POST',
        url: '/dsh-fish/config',
        headers: { 'content-type': 'application/json' },
        on: (ev, fn) => { if (ev === 'data') fn(Buffer.from(body, 'utf8')); if (ev === 'end') fn() },
      }
      await route.handler(req, res)
    }
    await post({ owner: { pronoun: '她' } })
    assert.equal(status, 200)
    assert.equal(payload.config.owner.pronoun, '她')
    // 界面上的整表提交不会带 owner，回头不能把它抹掉
    await post({ growthDays: 30 })
    assert.equal(status, 200)
    assert.equal(payload.config.owner.pronoun, '她', '整表保存不该把代词重置')
    // 不认的值不报错，退回默认
    await post({ owner: { pronoun: '它' } })
    assert.equal(status, 200)
    assert.equal(payload.config.owner.pronoun, '他')
  } finally {
    await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
})
test('/config 收得下自动备份的三个设置项（用户 m00002）', async () => {
  // 自动备份的三个旋钮走数据页单独 patch 提交，不挤进 buildConfig() 整表——
  // 所以 p5 那条「反查 buildConfig」的防漂移用例**管不到它**。
  // 这里补一条真发一次 POST 的用例：白名单漏登记时，界面上会看到
  // 「这一版还不支持保存：backup」，而开关看起来像是没生效。
  const root = await mkdtemp(join(tmpdir(), 'fish-p5b-'))
  try {
    const ctx = fakeCtx(root)
    ctx.cfg.connection = { requestRejection: () => null }
    registerObserve(ctx, { root })
    const route = ctx.routes.find((r) => String(r.path || '').endsWith('/config'))
    let status = 0
    let payload = null
    const res = { writeHead: (s) => { status = s }, end: (s) => { payload = JSON.parse(s || '{}') }, setHeader: () => {} }
    const body = JSON.stringify({ backup: { enabled: false, everyDays: 3, keep: 5 } })
    const req = {
      method: 'POST',
      url: '/dsh-fish/config',
      headers: { 'content-type': 'application/json' },
      on: (ev, fn) => { if (ev === 'data') fn(Buffer.from(body, 'utf8')); if (ev === 'end') fn() },
    }
    await route.handler(req, res)
    assert.equal(status, 200, `保存不该被挡回来：${JSON.stringify(payload)}`)
    assert.equal(payload.config.backup.enabled, false)
    assert.equal(payload.config.backup.everyDays, 3)
    assert.equal(payload.config.backup.keep, 5)
    // 越界由 LIMITS 夹住，不是拒收（1–30 / 1–60）
    const body2 = JSON.stringify({ backup: { everyDays: 999, keep: 0 } })
    const req2 = {
      method: 'POST',
      url: '/dsh-fish/config',
      headers: { 'content-type': 'application/json' },
      on: (ev, fn) => { if (ev === 'data') fn(Buffer.from(body2, 'utf8')); if (ev === 'end') fn() },
    }
    await route.handler(req2, res)
    assert.equal(status, 200)
    assert.equal(payload.config.backup.everyDays, 30)
    assert.equal(payload.config.backup.keep, 1)
    // lastAt 是计时用的，不该被一次「改间隔」抹掉
    assert.equal(typeof payload.config.backup.lastAt, 'string')
  } finally {
    await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
})

test('设置界面面向用户的文案里不出现男字旁的「他」', async () => {
  const src = await readFile(CLIENT, 'utf8')
  // 只扫字符串字面量，注释不算（注释里保留原话便于追溯）。
  //
  // 口径在 2026-10-24 改过：早期要求「她/他」都为零，是想让界面完全不用
  // 人称代词；后来用户在文案面板里亲手把 15 处「它」改成了「她」，等于
  // 选定了「她」这个写法。规则跟着用户的决定走 —— 现在只禁男字旁的「他」，
  // 「她」是选定写法，「它」留给真正指物的句子（AGENTS.md、事件流、插件）。
  const bad = []
  const re = /(['"`])((?:[^'"`\\\n]|\\.)*)\1/g
  let m
  while ((m = re.exec(src))) {
    // 例外：`其他/其它` 里的「他」是词素（意思是「别的」），不是人称代词。
    const shorn = m[2].replace(/其[他它]/g, '')
    if (/他/.test(shorn)) bad.push(m[2].slice(0, 40))
  }
  assert.deepEqual(bad, [], '面向用户的字符串里不许出现「他」')
})

test('设置界面里跟她有关的固定文案都走 S()，不裸写「她」（issue #139）', async () => {
  const src = await readFile(CLIENT, 'utf8')
  // 守的是 issue #139 的边界：旁观者视角的第三人称统一经 S() 出，
  // 换 config.self.pronoun 时才只有一处可改。她说过的话、日记原文不经过 S()，
  // 也不在 client.js 里；模板里的静态段已由 codemod 换成 ${SELF_SHE}。
  //
  // 这里用一个小词法走一遍：注释跳过，字符串/模板记下来，模板的 ${...} 里按代码
  // 再走（所以 `...${cond ? '她…' : ''}` 这种也能抓到）。
  const bad = []
  const lineAt = (at) => {
    const s = src.lastIndexOf('\n', at) + 1
    const e = src.indexOf('\n', at)
    return src.slice(s, e === -1 ? src.length : e)
  }
  const flag = (at, why) => bad.push(`${why}${src.slice(Math.max(0, at - 20), at + 24)}`)

  const stack = []
  let i = 0
  let inCode = true
  while (i < src.length) {
    const c = src[i]
    const n = src[i + 1]

    if (!inCode) {
      const top = stack[stack.length - 1]
      const wrapped = src.slice(top.start - 2, top.start) === 'S('
      if (c === '\\') { i += 2; continue }
      if (c === '`') {
        const seg = src.slice(top.segStart, i)
        if (!wrapped && /她/.test(seg)) flag(top.start, '模板里的「她」没包 S()：')
        stack.pop()
        inCode = true
        i += 1
        continue
      }
      if (c === '$' && n === '{') {
        if (!wrapped && /她/.test(src.slice(top.segStart, i))) flag(top.segStart, '模板插值外的「她」没换成 ${SELF_SHE}：')
        stack.push({ kind: 'expr', depth: 0, start: i })
        inCode = true
        i += 2
        continue
      }
      i += 1
      continue
    }

    if (c === '/' && n === '/') { const e = src.indexOf('\n', i); i = e === -1 ? src.length : e; continue }
    if (c === '/' && n === '*') { const e = src.indexOf('*/', i + 2); i = e === -1 ? src.length : e + 2; continue }
    if (c === "'" || c === '"') {
      const q = c
      let j = i + 1
      while (j < src.length && src[j] !== q) { if (src[j] === '\\') j += 1; j += 1 }
      // S() 自己的实现：初值与 split 的那个「她」是机制本身，不是文案。
      if (/她/.test(src.slice(i + 1, j)) && src.slice(i - 2, i) !== 'S('
        && !/SELF_SHE\s*=.*'她'|\.split\('她'\)/.test(lineAt(i))) flag(i, '固定文案里的「她」没包 S()：')
      i = j + 1
      continue
    }
    if (c === '`') {
      stack.push({ kind: 'template', segStart: i + 1, start: i })
      inCode = false
      i += 1
      continue
    }

    const top = stack[stack.length - 1]
    if (top && top.kind === 'expr') {
      if (c === '{') top.depth += 1
      else if (c === '}') {
        if (top.depth === 0) {
          stack.pop()
          const parent = stack[stack.length - 1]
          if (parent && parent.kind === 'template') parent.segStart = i + 1
          inCode = false
          i += 1
          continue
        }
        top.depth -= 1
      }
    }
    i += 1
  }
  assert.deepEqual(bad, [], '固定文案里的「她」必须包在 S() 里；否则 self.pronoun 换不掉它')
})

test('own 层的 ops_* 能存进白名单，且 /tools 会说明「收窄挡不住它」（2026-10-29）', async () => {
  // 用户真机：想把 dsh-ops 的 ops_bash 写进白名单，输入框一直报「名字不存在」。
  // 原因是 knownToolNames 只收 restrictableNames，而 ops_* 注册在 agent 自身作用域。
  // 现在收 restrictable ∪ visible；但下给 restrict() 的仍然只有收得窄的那批。
  const root = await mkdtemp(join(tmpdir(), 'fish-p5e-'))
  try {
    rememberFromView({
      restrictableNames: new Set([...HER_TOOLS]),
      visible: new Map([...HER_TOOLS.map((n) => [n, {}]), ['ops_bash', {}]]),
    })
    const ctx = fakeCtx(root)
    ctx.cfg.connection = { requestRejection: () => null }
    registerObserve(ctx, { root })

    const tools = ctx.routes.find((r) => String(r.path || '').endsWith('/tools'))
    let payload = null
    const res = {
      writeHead: () => {},
      end: (s) => { payload = JSON.parse(s || '{}') },
      setHeader: () => {},
    }
    await tools.handler({ method: 'GET', url: '/dsh-fish/tools', headers: {} }, res)
    assert.ok(payload.known.includes('ops_bash'), '白名单校验必须认得这个名字')
    assert.deepEqual(payload.ownLayer, ['ops_bash'], 'own 层名单用来解释「加进来只是让守卫放行」')

    const config = ctx.routes.find((r) => String(r.path || '').endsWith('/config'))
    const body = JSON.stringify({ tools: { restrict: true, allow: ['ops_bash', 'read_image'] } })
    const req = {
      method: 'POST',
      url: '/dsh-fish/config',
      headers: { 'content-type': 'application/json' },
      on: (ev, fn) => { if (ev === 'data') fn(Buffer.from(body, 'utf8')); if (ev === 'end') fn() },
    }
    let status = 0
    let saved = null
    await config.handler(req, {
      writeHead: (s) => { status = s },
      end: (s) => { saved = JSON.parse(s || '{}') },
      setHeader: () => {},
    })
    assert.equal(status, 200, `ops_bash 该存得进去：${JSON.stringify(saved)}`)
    assert.deepEqual(saved.config.tools.allow, ['ops_bash', 'read_image'])
    // 0.9.8（2026-11-11，外部用户反馈）：白名单存完当场换刀，结果要回给界面说「现在就生效」。
    // 这一条用例没挂收窄（liveReg 空），换刀是 disabled——界面据此仍按老说法说重启。
    assert.ok(saved.toolsLive, '存完要把换刀结果一起回给界面')
    assert.equal(saved.toolsLive.ok, false, '这一条里收窄没注册，换刀只能是 disabled')

    // 名单没变时不必再下一次刀：toolsLive 是 null，界面据此走「名单没变」那句。
    let again = null
    const req2 = {
      method: 'POST',
      url: '/dsh-fish/config',
      headers: { 'content-type': 'application/json' },
      on: (ev, fn) => { if (ev === 'data') fn(Buffer.from(body, 'utf8')); if (ev === 'end') fn() },
    }
    await config.handler(req2, {
      writeHead: () => {},
      end: (s) => { again = JSON.parse(s || '{}') },
      setHeader: () => {},
    })
    assert.equal(again.toolsLive, null, '名单没变就不该再换刀')
  } finally {
    await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
})

test('config 里留着一个早就不存在的工具名，不该让整页设置都存不进去（2026-10-31 issue #14）', async () => {
  // 用户那台机器：config.json 的 tools.allow 里有个裸的 `delete`（0.8.1）。
  // 设置页的自动保存是**整表提交**，于是改任何一个开关都会 400，横幅还说是
  // 「插件这一版还没接上它」——方向完全错了，而且他得手动翻进白名单框删名字才能解锁。
  const root = await mkdtemp(join(tmpdir(), 'fish-p5f-'))
  try {
    rememberFromView({
      restrictableNames: new Set([...HER_TOOLS]),
      visible: new Map([...HER_TOOLS.map((n) => [n, {}])]),
    })
    const ctx = fakeCtx(root)
    ctx.cfg.connection = { requestRejection: () => null }
    registerObserve(ctx, { root })
    const config = ctx.routes.find((r) => String(r.path || '').endsWith('/config'))

    const post = async (payload) => {
      const body = JSON.stringify(payload)
      const req = {
        method: 'POST',
        url: '/dsh-fish/config',
        headers: { 'content-type': 'application/json' },
        on: (ev, fn) => { if (ev === 'data') fn(Buffer.from(body, 'utf8')); if (ev === 'end') fn() },
      }
      let status = 0
      let out = null
      await config.handler(req, {
        writeHead: (s) => { status = s },
        end: (s) => { out = JSON.parse(s || '{}') },
        setHeader: () => {},
      })
      return { status, out }
    }

    // 整表提交（buildConfig 的形状），白名单里混一个这台机器上没有的名字 + 改一个无关设置
    const { status, out } = await post({
      tools: { restrict: true, allow: ['delete', 'read_image'] },
      wakesPerDay: 3,
    })
    assert.equal(status, 200, `不该整表拒掉：${JSON.stringify(out)}`)
    assert.deepEqual(out.config.tools.allow, ['read_image'], '坏名字丢掉，好的留下')
    assert.deepEqual(out.droppedTools, ['delete'], '丢掉了哪些要原样告诉界面')
    assert.equal(out.config.wakesPerDay, 3, '同一张表里别的设置必须照常存进去')
  } finally {
    await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
})

test('整张表全是坏名字时也只是白名单清空，不报错', async () => {
  const root = await mkdtemp(join(tmpdir(), 'fish-p5g-'))
  try {
    rememberFromView({
      restrictableNames: new Set([...HER_TOOLS]),
      visible: new Map([...HER_TOOLS.map((n) => [n, {}])]),
    })
    const ctx = fakeCtx(root)
    ctx.cfg.connection = { requestRejection: () => null }
    registerObserve(ctx, { root })
    const config = ctx.routes.find((r) => String(r.path || '').endsWith('/config'))
    const body = JSON.stringify({ tools: { restrict: true, allow: ['delete', 'remove'] } })
    const req = {
      method: 'POST',
      url: '/dsh-fish/config',
      headers: { 'content-type': 'application/json' },
      on: (ev, fn) => { if (ev === 'data') fn(Buffer.from(body, 'utf8')); if (ev === 'end') fn() },
    }
    let status = 0
    let out = null
    await config.handler(req, {
      writeHead: (s) => { status = s },
      end: (s) => { out = JSON.parse(s || '{}') },
      setHeader: () => {},
    })
    assert.equal(status, 200)
    assert.deepEqual(out.config.tools.allow, [])
    assert.deepEqual(out.droppedTools, ['delete', 'remove'])
  } finally {
    await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
})

// ---------------------------------------------------------------------------
// /tools 要把「被挡过什么」「她自己本来就有什么」也一起交出来（2026-11-04，issue #20）
//
// 以前设置页只知道「这台机器上有哪些工具名字」：能核对拼写，说不清
// 「这两只她本来就有，加白名单只是让守卫放行」，更看不见「她伸手够过、被挡了」。
// ---------------------------------------------------------------------------

test('/tools 多给三样：herTools 只读清单、blocked 被挡记录、ownLayer 照旧', async () => {
  forgetBlockedTools()
  const root = await mkdtemp(join(tmpdir(), 'fish-p5f-'))
  try {
    rememberFromView({
      restrictableNames: new Set([...HER_TOOLS, 'vision_describe']),
      visible: new Map([...HER_TOOLS.map((n) => [n, {}]), ['ops_bash', {}]]),
    })
    const ctx = fakeCtx(root)
    ctx.cfg.connection = { requestRejection: () => null }
    registerObserve(ctx, { root })

    // 制造一条真的「被挡」：挂守卫、撞它
    const listeners = new Map()
    const guards = []
    const gctx = {
      on: (ev, fn) => { if (!listeners.has(ev)) listeners.set(ev, []); listeners.get(ev).push(fn); return () => {} },
      emit: (ev, p) => { for (const fn of listeners.get(ev) ?? []) fn(p) },
    }
    registerToolRestrict(gctx, { herDir: 'C:\\h', log: () => {} })
    gctx.emit('agent/created', {
      agent: {
        session: { header: { cwd: 'C:\\h' } },
        ctx: { tools: { restrict: () => () => {}, guard: (fn) => { guards.push(fn); return () => {} } }, effect: () => {} },
      },
    })
    guards[0]({ name: 'vision_describe' })

    const tools = ctx.routes.find((r) => String(r.path || '').endsWith('/tools'))
    let payload = null
    await tools.handler({ method: 'GET', url: '/dsh-fish/tools', headers: {} }, {
      writeHead: () => {},
      end: (s) => { payload = JSON.parse(s || '{}') },
      setHeader: () => {},
    })

    assert.deepEqual(payload.herTools, [...HER_TOOLS], '她自己那几件要能原样交代给界面')
    assert.ok(payload.herTools.includes('growth_commit'))
    assert.deepEqual(payload.ownLayer, ['ops_bash'], 'ownLayer 的语义不能变（老界面靠它解释白名单）')
    assert.equal(payload.blocked.length, 1)
    assert.equal(payload.blocked[0].name, 'vision_describe')
    assert.equal(payload.blocked[0].count, 1)
    // 第三方工具在 known 里看得见：名字本身不重要，能被放行才是重点
    assert.ok(payload.known.includes('vision_describe'))
  } finally {
    forgetBlockedTools()
    await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
})

