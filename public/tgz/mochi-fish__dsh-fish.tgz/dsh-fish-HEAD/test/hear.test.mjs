/**
 * hear.test.mjs —— 旁听（A2，2026-10-30 用户 m00112）与回忆检索的排序变化
 *
 * 覆盖：
 *   1. 从一段话里只挑一句原话；太短不记；超长截断
 *   2. 每 hearEvery 轮才写一条；0 = 不记
 *   3. 她写不了 heard（只有系统侧能写）——旁听的凭据价值全靠这一点
 *   4. 她翻回忆时，heard 明确写成「他说：」，不会被当成自己说过的话
 *   5. 默认翻全部时间（30 天以前也翻得到）；kind 只看一类
 *   6. 显著性加权：被固化/被检验过的条目排在同样字面命中前面
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { pickHearSentence, pickHearStatus, hearTurn, rememberGroupWord, latestHeardId, HEAR_LINK_DAYS, HEAR_SNIPPET, HEAR_MIN_CHARS } from '../lib/hear.js'
import { hearMark, bumpTurns } from '../lib/home.js'
import { readEvents, appendEvent } from '../lib/store.js'
import { validateEvent, isContactEvent } from '../lib/schema.js'
import { searchEvents, renderRecall, RECALL_LIMIT, RECALL_DAYS } from '../lib/recall.js'
import { eventsSince } from '../lib/outing.js'

const DAY = 86_400_000

async function withRoot(fn) {
  const root = await mkdtemp(join(tmpdir(), 'fish-hear-'))
  try {
    return await fn(root)
  } finally {
    await rm(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
}

function at(daysAgo) {
  return new Date(Date.now() - daysAgo * DAY).toISOString()
}

// ---------------------------------------------------------------- 挑句子

test('旁听：只留最长的一句，句号问号都切掉', () => {
  const s = pickHearSentence('嗯。今天我在想一件事，想了很久。你呢？')
  assert.equal(s, '今天我在想一件事，想了很久')
})

test('旁听：太短的话不记', () => {
  assert.equal(pickHearSentence('嗯。'), '')
  assert.equal(pickHearSentence('好'), '')
  assert.ok(HEAR_MIN_CHARS >= 2)
})

test('旁听：太长截断到上限', () => {
  const s = pickHearSentence('我' + '很'.repeat(500) + '。')
  assert.ok(s.length <= HEAR_SNIPPET)
  assert.ok(s.endsWith('…'))
})

test('旁听：桥加在开头的来源抬头不会被当成「他说」的那句（issue #96）', () => {
  // 2026-11-09：桥把群聊原样递进来时，正文前常有一行「（群聊 · 示例群 · im:group:10001）」。
  // 那一行比人说的话还长，取最长句就记成了抬头——她翻回忆读到的是频道名。
  const s = pickHearSentence(
    '（群聊 · 示例群 · im:group:10001）\n这句话我觉得挺有意思的，你怎么看？',
  )
  assert.equal(s, '这句话我觉得挺有意思的，你怎么看')
  // 多行抬头、方括号、空行一起出现也认得
  assert.equal(
    pickHearSentence('[渠道：im:group:10001]\n\n（群聊 · 示例群）\n今天外面下雨了，你那边呢？'),
    '今天外面下雨了，你那边呢',
  )
  // 只裁「整行被括号包住、且带群/渠道/频道的」，普通人说的话一个字都不动：
  // 误裁等于把他的话从记忆里抹掉，宁可少裁。
  assert.equal(pickHearSentence('（其实我觉得这件事）没那么简单吧，再想想。'), '（其实我觉得这件事）没那么简单吧，再想想')
  assert.equal(pickHearSentence('群聊里有人说了一句很长的话，我也记不清了。'), '群聊里有人说了一句很长的话，我也记不清了')
})

// ---------------------------------------------------------------- 写事件

test('旁听：不到轮数不写，到了才写一条 heard', async () => {
  await withRoot(async (root) => {
    const cfg = { memory: { hearEvery: 3 } }
    const text = '今天我在想一件事，想了很久'
    assert.equal((await hearTurn(root, { text, turns: 1, day: 2, stage: 1, config: cfg })).written, false)
    assert.equal((await hearTurn(root, { text, turns: 2, day: 2, stage: 1, config: cfg })).written, false)
    const ok = await hearTurn(root, { text, turns: 3, day: 2, stage: 1, config: cfg })
    assert.equal(ok.written, true)
    assert.ok(ok.id)

    const { events } = await readEvents(root)
    const heard = events.filter((e) => e.type === 'heard')
    assert.equal(heard.length, 1)
    assert.equal(heard[0].source, 'system')
    assert.equal(heard[0].text, '今天我在想一件事，想了很久')
    assert.equal(heard[0].day, 2)
  })
})

test('旁听：装上时 turns 已经过去好几轮，下一轮就记（本机 0.8.0 的现场）', async () => {
  await withRoot(async (root) => {
    const cfg = { memory: { hearEvery: 3 } }
    const text = '今天我在想一件事，想了很久'
    // 真实链路里 bumpTurns 先跑（记轮次），home.json 一定存在；hearAt 只写在已有的 home.json 上。
    await bumpTurns(root, 1)
    // 0.8.0 装上旁听时本机 turns 已经 4。旧写法（turns % every === 0）要等到 6 才记，
    // 中间这段时间 events.jsonl 里一条 heard 都没有，看上去像功能没生效。
    assert.equal((await hearTurn(root, { text, turns: 4, day: 6, stage: 1, config: cfg })).written, true)
    // 记过一次之后重新数：4 → 7 之间不再记
    assert.equal((await hearTurn(root, { text, turns: 5, day: 6, stage: 1, config: cfg })).written, false)
    assert.equal((await hearTurn(root, { text, turns: 6, day: 6, stage: 1, config: cfg })).written, false)
    assert.equal((await hearTurn(root, { text, turns: 7, day: 6, stage: 1, config: cfg })).written, true)

    const { events } = await readEvents(root)
    assert.equal(events.filter((e) => e.type === 'heard').length, 2)
  })
})

test('旁听：轮次标记记在 home.json 的 hearAt 上，普通记账不会把它冲掉', async () => {
  await withRoot(async (root) => {
    const cfg = { memory: { hearEvery: 3 } }
    const text = '今天我在想一件事，想了很久'
    await bumpTurns(root, 1) // 先让 home.json 存在（真实链路同此）
    await hearTurn(root, { text, turns: 3, day: 2, stage: 1, config: cfg })
    assert.equal(await hearMark(root), 3)
    // bumpTurns 写回 home.json 时用的是 `{...saved, turns}`，不能把 hearAt 丢掉
    await bumpTurns(root, 1)
    assert.equal(await hearMark(root), 3)
    assert.equal((await hearTurn(root, { text, turns: 4, day: 2, stage: 1, config: cfg })).written, false)
  })
})

test('旁听：hearEvery=0 就是完全不记', async () => {
  await withRoot(async (root) => {
    const r = await hearTurn(root, { text: '今天我在想一件事，想了很久', turns: 30, day: 5, stage: 1, config: { memory: { hearEvery: 0 } } })
    assert.equal(r.written, false)
    const { events } = await readEvents(root)
    assert.equal(events.filter((e) => e.type === 'heard').length, 0)
  })
})

test('旁听：她不能自己伪造一条「他说过」', () => {
  const ok = validateEvent({ type: 'heard', text: '今天我在想一件事' }, { day: 1, stage: 1, source: 'system' })
  assert.equal(ok.type, 'heard')
  let err = null
  try {
    validateEvent({ type: 'heard', text: '今天我在想一件事' }, { day: 1, stage: 1, source: 'tool' })
  } catch (e) {
    err = e
  }
  assert.ok(err, 'tool 侧写 heard 必须被拒')
  assert.equal(err.code, 'NOT_HER_TYPE')
})

// ---------------------------------------------------------------- 翻回忆

test('旁听：她翻到时看到的是「他说：」，不是自己的口吻', () => {
  const rows = [{
    id: 'ev_1', date: '2026-10-20', ago: 9, type: 'heard', text: '今天我在想一件事，想了很久',
  }]
  const out = renderRecall(rows)
  assert.match(out, /他说：今天我在想一件事/)
  assert.match(out, /9 天前/)
  assert.match(out, /（ev_1）/)
})

test('回忆：默认翻全部时间，一个月以前的也翻得到', () => {
  assert.equal(RECALL_DAYS, 0, '0 = 全部')
  const now = Date.now()
  const events = [{ id: 'old', type: 'utterance', ts: at(200), text: '很久以前的评论' }]
  const { rows } = searchEvents(events, '评论', { now })
  assert.equal(rows.length, 1)
  assert.equal(rows[0].id, 'old')
  assert.ok(rows[0].ago >= 199)
})

test('回忆：kind 只看他听过的话', () => {
  const now = Date.now()
  const events = [
    { id: 'a', type: 'utterance', ts: at(1), text: '评论这件事我说不好' },
    { id: 'b', type: 'heard', ts: at(2), text: '你在评论里那句话我喜欢' },
  ]
  const all = searchEvents(events, '评论', { now })
  assert.equal(all.rows.length, 2)
  const onlyHeard = searchEvents(events, '评论', { now, kind: 'heard' })
  assert.equal(onlyHeard.rows.length, 1)
  assert.equal(onlyHeard.rows[0].id, 'b')
})

test('回忆：固化/被检验过的排在同样字面命中的前面', () => {
  const now = Date.now()
  const events = [
    { id: 'plain', type: 'utterance', ts: at(0), text: '评论' },
    { id: 'solid', type: 'utterance', ts: at(10), text: '评论' },
    { id: 't', type: 'test', ts: at(1), text: '检验一下', refs: ['plain'] },
  ]
  // 不加权：新的在前
  assert.equal(searchEvents(events, '评论', { now, weigh: false }).rows[0].id, 'plain')
  // 加权：solid 先
  const { rows } = searchEvents(events, '评论', { now, solidIds: new Set(['solid']) })
  assert.equal(rows[0].id, 'solid')
})

test('回忆：条数上限是 8', () => {
  assert.equal(RECALL_LIMIT, 8)
  const now = Date.now()
  const events = Array.from({ length: 30 }, (_, i) => ({
    id: `x${i}`, type: 'utterance', ts: at(i), text: `评论第 ${i} 条`,
  }))
  assert.equal(searchEvents(events, '评论', { now }).rows.length, RECALL_LIMIT)
})

// ---------------------------------------------------------------- 2026-11-04 群反馈第二、三条

test('回忆：时间到分钟，不再只有日期', () => {
  const rows = [{
    id: 'ev_1', date: '2026-11-04', clock: '18:10', ago: 0, type: 'utterance', text: '今天下雨。',
  }]
  const out = renderRecall(rows)
  assert.match(out, /- 2026-11-04 18:10｜今天下雨。/)
})

test('回忆：同一天的两句话分得出先后', () => {
  const now = Date.now()
  const t0 = now - 3_600_000
  const t1 = now - 60_000
  const events = [
    { id: 'early', type: 'utterance', ts: new Date(t0).toISOString(), text: '这句在后' },
    { id: 'late', type: 'utterance', ts: new Date(t1).toISOString(), text: '这句在前' },
  ]
  const { rows } = searchEvents(events, '这句', { now, weigh: false })
  assert.ok(rows[0].clock && rows[1].clock, '每条都要有时分')
  assert.notEqual(rows[0].clock, rows[1].clock)
})

test('回忆：改口关系要写出来，别让她翻到 revise 跟普通一句长得一样', () => {
  const rows = [{
    id: 'ev_9', date: '2026-11-04', clock: '09:00', ago: 0, type: 'revise',
    text: '我之前说错了。', verdict: 'refuted', refs: ['ev_1'],
  }]
  const out = renderRecall(rows)
  assert.match(out, /推翻了 ev_1/)
  assert.match(out, /那是更早说的/)
  // refined 用另一套说法
  const refined = renderRecall([{ ...rows[0], verdict: 'refined' }])
  assert.match(refined, /修正了 ev_1/)
})

test('回忆：聊天里说的要标出来，跟她自己写下的分开', () => {
  const rows = [
    { id: 'a', date: '2026-11-04', clock: '10:00', ago: 0, type: 'utterance', text: '这是我记下的。' },
    { id: 'b', date: '2026-11-04', clock: '10:10', ago: 0, type: 'utterance', text: '这是随口说的。', chatOnly: true },
  ]
  const out = renderRecall(rows)
  assert.match(out, /- 2026-11-04 10:00｜这是我记下的。/)
  assert.match(out, /- 2026-11-04 10:10｜这是随口说的。｜聊天里说的/)
  assert.ok(!out.includes('这是我记下的。｜聊天里说的'), '认领过的不该被标成聊天里说的')
})

test('回忆：认领过的排在聊天原话前面（同样字面命中）', () => {
  const now = Date.now()
  const events = [
    // 聊天原话更新，但没认领
    { id: 'chat', type: 'utterance', ts: at(0), text: '评论这件事', flags: ['uncommitted'] },
    // 认领过的更旧
    { id: 'mine', type: 'utterance', ts: at(5), text: '评论这件事' },
  ]
  const { rows } = searchEvents(events, '评论', { now })
  assert.equal(rows[0].id, 'mine', '认领过的那个要先出来')
})

test('回忆：认领的 +4 不能盖过字面命中差很多的情况', () => {
  const now = Date.now()
  const q = '判断 视频 记录 评论 天气 出门'
  const events = [
    // 六个词全中，但是聊天原话（六片各 +1 = 6）
    { id: 'chat', type: 'utterance', ts: at(0), text: '判断 视频 记录 评论 天气 出门', flags: ['uncommitted'] },
    // 只中一片，但认领过（1 + 4 = 5）
    { id: 'mine', type: 'utterance', ts: at(5), text: '判断' },
  ]
  const { rows } = searchEvents(events, q, { now })
  assert.equal(rows[0].id, 'chat', '字面命中差得多的时候，认领的加权不该盖过它')
})

// ---------------------------------------- 2026-11-08（用户 m00394）群里他本人的话

test('群里他本人说的一句：记成 heard + scene:group，只留最长的一句', async () => {
  await withRoot(async (root) => {
    const r = await rememberGroupWord(root, {
      text: '嗯。这个版本我打算先发一版试试看，后面有问题再说。', day: 3, stage: 2, sessionId: 's-group-1',
    })
    assert.equal(r.written, true)
    const { events } = await readEvents(root)
    const ev = events.find((e) => e.type === 'heard')
    assert.ok(ev, '要真的落进事件流')
    assert.equal(ev.scene, 'group', '场次必须留下：她翻到时才知道这是在群里说的')
    assert.equal(ev.text, '这个版本我打算先发一版试试看，后面有问题再说')
    assert.equal(ev.sessionId, 's-group-1', '群聊那句要知道是哪间房说的')
    assert.equal(ev.source, 'system', '她不能写 heard——那就等于能凭空造一句「他说过」')
    // 进记忆 ≠ 他来找过她
    assert.equal(isContactEvent(ev), false)
  })
})

test('群里那句没有值得留的句子就不写，也不抛', async () => {
  await withRoot(async (root) => {
    const r = await rememberGroupWord(root, { text: '嗯。好的。', day: 1, stage: 1 })
    assert.equal(r.written, false)
    const { events } = await readEvents(root)
    assert.equal(events.length, 0, '「嗯」「好」记下来也翻不出什么')
  })
})

test('家里记下的那句也带会话 id：出门/请神算「这一趟多了什么」时分得清（issue #68）', async () => {
  await withRoot(async (root) => {
    const cfg = { memory: { hearEvery: 1 } }
    const a = await hearTurn(root, {
      text: '今天我在想一件事，想了很久',
      turns: 1,
      sessionId: 'session-home',
      day: 2,
      stage: 1,
      config: cfg,
    })
    assert.equal(a.written, true)
    // 调用方没给会话 id 时照旧不写这个字段：老调用点（单测、脚本）不用跟着改
    const b = await hearTurn(root, { text: '今天我在想一件事，想了很久', turns: 2, day: 2, stage: 1, config: cfg })
    assert.equal(b.written, true)

    const { events } = await readEvents(root)
    const heard = events.filter((e) => e.type === 'heard')
    assert.equal(heard.length, 2)
    assert.equal(heard[0].sessionId, 'session-home')
    assert.equal('sessionId' in heard[1], false)

    // 在外面那一趟的账里：别的会话记的句子不算这趟的（没有 id 的仍会按时间兜底，这是已知的取舍）
    const list = eventsSince(join(root, 'events.jsonl'), Date.now() - 60_000, { sessionId: 'session-away' })
    assert.equal(list.ok, true)
    assert.equal(list.items.some((x) => x.id === a.id), false, '家里那句不该被算进外头那一趟')
  })
})

// ---------------------------------------------------------------- 短状态句（2026-11-14，用户 m00242）

test('旁听：两个字的状态句「好了」也记得下，接话「嗯」不进', () => {
  assert.equal(pickHearStatus('好了'), '好了')
  assert.equal(pickHearStatus('肚子不胀了。'), '肚子不胀了')
  assert.equal(pickHearStatus('嗯'), '')
  assert.equal(pickHearStatus('在吗'), '')
  // 够长的句子走 pickHearSentence，不在这一支里重复处理
  assert.equal(pickHearStatus('好的，我知道了谢谢你'), '')
  // 一段里有好几句：交给 pickHearSentence 取最长那句，不从长段里抠碎片
  assert.equal(pickHearStatus('好了。今天我在想一件事，想了很久'), '')
})

test('旁听：短状态句跳过「每几轮」的间隔，长句照旧（肚子胀 → 好了）', async () => {
  await withRoot(async (root) => {
    const cfg = { memory: { hearEvery: 3 } }
    // 真实链路里 bumpTurns 先跑，home.json 一定存在
    await bumpTurns(root, 1)
    // 第 1 轮的长句：还不到 interval
    assert.equal(
      (await hearTurn(root, { text: '今天肚子有点胀，可能是吃多了', turns: 1, day: 3, stage: 1, config: cfg })).written,
      false,
    )
    // 第 2 轮只有两个字：照样记
    const ok = await hearTurn(root, { text: '好了', turns: 2, day: 3, stage: 1, config: cfg })
    assert.equal(ok.written, true)
    assert.equal(ok.text, '好了')
    const { events } = await readEvents(root)
    const heard = events.filter((e) => e.type === 'heard')
    assert.equal(heard.length, 1)
    assert.equal(heard[0].text, '好了')
  })
})

test('旁听：hearEvery=0 时短状态句也不记（这个开关管全部）', async () => {
  await withRoot(async (root) => {
    const r = await hearTurn(root, { text: '好了', turns: 9, day: 3, stage: 1, config: { memory: { hearEvery: 0 } } })
    assert.equal(r.written, false)
    assert.equal(r.why, 'off')
  })
})

// ---------------------------------------------------------------- 短句接回上一句（2026-11-14，用户 m00533）

test('latestHeardId：只接家里最近的一条长话，群里、状态句、7 天前的都不接', () => {
  const now = Date.now()
  const ev = (id, text, ts, extra = {}) => ({ id, type: 'heard', text, ts, ...extra })
  const events = [
    ev('old', '上个月他说要去体检', at(30)),
    ev('newer-dull', '嗯', at(1)),                        // 太短、没状态词，本来就不会被写成 heard
    ev('group', '群里他说今晚加班', at(2), { scene: 'group' }),
    ev('status', '好了', at(1)),                          // 状态句不接状态句，否则会串成一串
    ev('long', '今天肚子有点胀，可能是吃多了', at(3)),
  ]
  assert.equal(latestHeardId(events, { now }), 'long')
  assert.equal(latestHeardId([], { now }), '')
  // 7 天以外的不算
  assert.equal(latestHeardId([ev('old', '很久以前的一句话', at(HEAR_LINK_DAYS + 1))], { now }), '')
})

test('旁听：短状态句落库时带 re，指回上一句长话（换房间以后也接得上）', async () => {
  await withRoot(async (root) => {
    const cfg = { memory: { hearEvery: 3 } }
    await bumpTurns(root, 3)
    const first = await hearTurn(root, { text: '今天肚子有点胀，可能是吃多了', turns: 3, day: 3, stage: 1, config: cfg })
    assert.equal(first.written, true)
    // 另一个房间（sessionId 不同）里他回了一句「好了」
    const second = await hearTurn(root, { text: '好了', turns: 4, day: 3, stage: 1, config: cfg, sessionId: 's-other-room' })
    assert.equal(second.written, true)
    const { events } = await readEvents(root)
    const heard = events.filter((e) => e.type === 'heard')
    assert.equal(heard.length, 2)
    assert.equal(heard[1].text, '好了')
    assert.equal(heard[1].re, heard[0].id, '要指回上一条 heard，读的人才知道「好了」说的是哪件事')
  })
})

test('回忆：被接上的那句会带一句「他后来接着说」，brief 档不展开', async () => {
  await withRoot(async (root) => {
    const a = await appendEvent({ type: 'heard', text: '今天肚子有点胀，可能是吃多了' }, { day: 3, stage: 1, source: 'system' }, root)
    await appendEvent({ type: 'heard', text: '好了', re: a.id }, { day: 3, stage: 1, source: 'system' }, root)
    const { events } = await readEvents(root)

    const { rows } = searchEvents(events, '肚子')
    const row = rows.find((r) => r.text.includes('肚子'))
    assert.ok(row?.patched, '被后一句接上的那条要带上后来的说法')
    assert.equal(row.patched.text, '好了')
    const out = renderRecall([row], {})
    assert.match(out, /后来接着说/)
    assert.match(out, /好了/)

    // 反过来翻「好了」，要能看见它接的是哪一句
    const back = searchEvents(events, '好了').rows.find((r) => r.text === '好了')
    assert.ok(back?.reTo)
    assert.match(renderRecall([back], {}), /接的是/)

    // brief 只报开头，不铺这些关系行
    assert.doesNotMatch(renderRecall([row], { brief: true }), /后来接着说/)
  })
})

// ---------------------------------------------------------------- 本子上的便条与约定（2026-11-14）

test('回忆：便条和约定也翻得到，划掉的会说明「后来你自己划掉了」', async () => {
  const { searchOps } = await import('../lib/recall.js')
  const now = Date.now()
  const iso = (d) => new Date(now - d * DAY).toISOString()
  const notes = [
    { id: 'n1', text: '买猫粮', status: 'done', created: iso(5), closedAt: iso(1) },
    { id: 'n2', text: '写周报', status: 'open', created: iso(2) },
  ]
  const appointments = [{ id: 'a1', due: '2026-11-20', what: '带猫复查', status: 'done', closedAt: iso(2) }]
  assert.match(searchOps({ notes, appointments }, '猫粮')[0], /后来你自己划掉了/)
  assert.match(searchOps({ notes, appointments }, '周报')[0], /还没划掉/)
  assert.match(searchOps({ notes, appointments }, '复查')[0], /已经做完了/)
  // 时间窗：只翻最近 1 天的，那条 2 天前做完的约定就翻不到
  assert.equal(searchOps({ notes, appointments }, '复查', { now, days: 1 }).length, 0)
})

test('回忆：事件流翻不到但本子上记着时，不要回「没翻到」', () => {
  const out = renderRecall([], { ops: ['你记着「买猫粮」——后来你自己划掉了（11 月 13 日）'] })
  assert.notEqual(out, '你翻了，没翻到。')
  assert.match(out, /不过你自己的本子上记着/)
  assert.match(out, /买猫粮/)
})
