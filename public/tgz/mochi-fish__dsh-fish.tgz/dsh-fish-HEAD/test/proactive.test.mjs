/**
 * proactive.test.mjs —— 她主动开口（0.8.1 本机实验，用户 m04610，只在 .dev 下启用）
 *
 * 为什么单独测：这一层最容易长成「系统命令她说话」。
 * 这里钉住四条边界：
 *   - 触发只是开门，不是任务（prompt 里可以什么都不做，不含「你应该」）；
 *   - 她说的话必须指回真实事件（refs 1–6 条，且得是她自己的话/听见的话）；
 *   - 频率是上限（一天最多几次、冷却几小时），不是每天必须说；
 *   - 工具默认不在白名单里，只有 .dev + 开关打开才会出现。
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { appendFileSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import {
  PROACTIVE_MAX,
  PROACTIVE_PING,
  proactiveConfig,
  proactiveSection,
  proactiveState,
  turnsToday,
  lastTurnAt,
  silentToday,
  lastSilentAt,
  SILENT_MARK,
  SILENT_MAX_PER_DAY,
  SILENT_QUIET_HOURS,
  idleHoursOf,
  countsForIdle,
  looseEnds,
  recentMaterial,
  registerProactive,
  writeSay,
  saysToday,
} from '../lib/proactive.js'
import { dateKey, normalizeConfig } from '../lib/settings.js'
import { readEvents, writeConfig } from '../lib/store.js'
import { HER_TOOLS } from '../lib/restrict.js'
import { deriveSelf } from '../lib/derive.js'
import { startScheduler } from '../lib/scheduler.js'

async function withRoot(fn) {
  const root = mkdtempSync(join(tmpdir(), 'fish-proactive-'))
  try {
    mkdirSync(root, { recursive: true })
    writeFileSync(join(root, 'events.jsonl'), '', 'utf8')
    return await fn(root)
  } finally {
    rmSync(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 })
  }
}

function line(root, ev) {
  appendFileSync(join(root, 'events.jsonl'), `${JSON.stringify({ v: 1, stage: 1, refs: [], verdict: null, confidence: 0.5, flags: [], ...ev })}\n`, 'utf8')
}

/** 事件数组直接造出来，避免每个用例都落一次盘。 */
function ev(over = {}) {
  const now = Date.now()
  return {
    id: 'ev_x',
    v: 1,
    ts: new Date(now).toISOString(),
    day: dateKey(new Date(now)),
    stage: 1,
    type: 'utterance',
    source: 'tool',
    text: '一句话',
    refs: [],
    verdict: null,
    confidence: 0.5,
    flags: [],
    ...over,
  }
}

const ON = { proactive: { enabled: true } }

test('六种不该开口的情况各有各的理由，别混成一句「不到时候」', () => {
  const now = Date.now()
  const old = new Date(now - 10 * 3_600_000).toISOString()
  const quiet = [ev({ ts: old })]

  assert.match(proactiveState({ config: {}, events: quiet, now }).why, /关着/)
  assert.match(proactiveState({ config: ON, events: quiet, now, away: { kind: 'outing' } }).why, /不在家/)
  assert.match(proactiveState({ config: ON, events: quiet, now, rested: true }).why, /请了假/)

  const used = [ev({ ts: old }), ev({ id: 'ev_t1', type: 'meta', text: `proactive-turn:${dateKey(new Date(now))}:1`, ts: new Date(now - 3 * 3_600_000).toISOString() }), ev({ id: 'ev_t2', type: 'meta', text: `proactive-turn:${dateKey(new Date(now))}:2`, ts: new Date(now - 2 * 3_600_000).toISOString() })]
  assert.match(proactiveState({ config: ON, events: used, now }).why, /上限/)

  const cooling = [ev({ ts: old }), ev({ id: 'ev_t', type: 'meta', text: `proactive-turn:${dateKey(new Date(now))}:x`, ts: new Date(now - 30 * 60_000).toISOString() })]
  assert.match(proactiveState({ config: ON, events: cooling, now }).why, /冷却/)

  const fresh = [ev({ ts: new Date(now - 60_000).toISOString() })]
  assert.match(proactiveState({ config: ON, events: fresh, now }).why, /还不到时候/)

  // 时间窗：她醒着的时段之外不开口。凌晨三点的一句「我想你了」不是自主，是作息被打乱。
  const away = (new Date(now).getHours() + 2) % 24
  const win = [`${String(away).padStart(2, '0')}:00`, `${String((away + 1) % 24).padStart(2, '0')}:00`]
  assert.match(proactiveState({ config: { ...ON, window: win }, events: quiet, now }).why, /时段/)
})

test('配置读进来会夹紧（issue #67 后只剩频次与冷却）', () => {
  const clamped = proactiveConfig({ proactive: { maxPerDay: 99, minIdleHours: -5, cooldownHours: 999 } })
  assert.equal(clamped.maxPerDay, 12)
  assert.equal(clamped.minIdleHours, 1)
  assert.equal(clamped.cooldownHours, 240)
  assert.equal('baseChance' in clamped, false, '概率那三个键已经删了')
})

test('到点只判闸门，不再掷骰子：state 里没有 chance（issue #67）', () => {
  const now = Date.now()
  const quiet = [ev({ ts: new Date(now - 7 * 3_600_000).toISOString() })]
  const s = proactiveState({ config: ON, events: quiet, now })
  assert.equal(s.ok, true, s.why)
  assert.equal('chance' in s, false)
  // 成长阶段只影响别处；开口这件事不再随阶段改概率
  const s4 = proactiveState({ config: ON, events: quiet, now, model: { stage: 4 } })
  assert.equal(s4.ok, true, s4.why)
  assert.equal('chance' in s4, false)
})

test('刚有人跟她说过话：余温还在，冷却从 4 小时缩到 2 小时', () => {
  const now = Date.now()
  const spoke = (h) => ev({ id: `ev_t_${h}`, type: 'meta', text: `proactive-turn:${dateKey(new Date(now - h * 3_600_000))}:1`, ts: new Date(now - h * 3_600_000).toISOString() })
  const heard = ev({ id: 'ev_h', type: 'heard', text: '他说了一句', ts: new Date(now - 10 * 3_600_000).toISOString() })
  const events = [heard, spoke(3)]

  // 3 小时前刚开过口：默认冷却 4 小时 → 挡着。
  const blocked = proactiveState({ config: ON, events, now })
  assert.equal(blocked.ok, false)
  assert.match(blocked.why, /冷却/)

  // 10 小时前有人跟她说过话（24 小时内）→ 冷却缩到 2 小时 → 放行。
  const warm = proactiveState({ config: ON, events, now, model: { stage: 1 } })
  assert.equal(warm.ok, true, `余温没起作用：${warm.why}`)

  // 冷透了（heard 超过 24 小时）还是 4 小时。
  const cold = [
    ev({ id: 'ev_h2', type: 'heard', text: '很久以前', ts: new Date(now - 30 * 3_600_000).toISOString() }),
    spoke(3),
  ]
  assert.match(proactiveState({ config: ON, events: cold, now, model: { stage: 1 } }).why, /冷却/)
})

test('空手回合的正文只说事实和许可，不写「你应该」', () => {
  const text = proactiveSection({ now: Date.now(), state: { idleHours: 9.5 }, material: [{ id: 'ev_a', type: 'utterance', text: '今天有点累' }], loose: [{ id: 'ev_b', text: '你问过一件事，还没答复。' }] })
  assert.match(text, /没有人跟你说话/)
  assert.match(text, /想说什么就说/)
  // 2026-11-06（issue #41）：原文写「他看得见」，装了渠道路由插件就不成立。
  // 保留的意图是「这句话有收件人，不是只记一笔」——改成她能验证的那个事实：字会进你们的对话。
  assert.match(text, /落进你们俩这条对话里/, '得说她的话有收件人，不然她以为只是记一笔')
  // 2026-11-05（用户 m02937）：「什么都不做」在文本界面上不成立，改成明确的不写。
  assert.match(text, /什么都别写/)
  assert.match(text, /不要写任何字/)
  assert.match(text, /1–6 条/)
  assert.doesNotMatch(text, /你应该/)
  assert.match(text, /\[ev_a\]/)
  // 2026-11-04（用户 m00428）：触发语从「（现在没有人跟你说话。）」改成一个空格。
  // 那句话被宿主按真人发言画成用户气泡，用户怎么都能看见；现在这条消息走
  // `source.kind='fish-wake'`，前端画成收起的折叠条，正文越空越好 ——
  // 以前那句「没有人跟你说话」还会被她在 reasoning 里当成「谁发了这句话给我」去解释。
  assert.equal(PROACTIVE_PING.trim(), '', '投递信号不许带正文，否则她又会去猜这句话是谁说的')
})

test('材料只取她自己的话与听见的东西，悬着的事只列未答的 ask', () => {
  const now = Date.now()
  const events = [
    ev({ id: 'ev_u', ts: new Date(now - 3_600_000).toISOString(), text: '我说过一句' }),
    ev({ id: 'ev_m', type: 'meta', ts: new Date(now - 3_600_000).toISOString(), text: 'diary:2026-10-30' }),
    ev({ id: 'ev_h', type: 'heard', ts: new Date(now - 3_600_000).toISOString(), text: '听见一句' }),
    ev({ id: 'ev_ask', type: 'ask', ts: new Date(now - 3_600_000).toISOString(), text: '我想问你一件事' }),
  ]
  const m = recentMaterial(events, { now })
  assert.deepEqual(m.map((x) => x.id).sort(), ['ev_h', 'ev_u'])
  const loose = looseEnds(events, { now })
  assert.equal(loose.length, 1)
  assert.match(loose[0].text, /还没有得到答复/)

  const answered = [...events, ev({ id: 'ev_ans', type: 'answer', ts: new Date(now - 1000).toISOString(), ask: { askId: 'ev_ask', verdict: 'reject' } })]
  assert.equal(looseEnds(answered, { now }).length, 0, '「这次不行」就不摆：再提一次就成了追问')

  // 2026-11-07（用户 m01602）：答了却没兑现的，线索不能断。
  // 「以后再说」是「先放着」而不是否决，得继续摆着，否则她开口了、被答了、
  // 然后这件事永远消失——2026-10-29 那张看整条视频的卡就是这么断的。
  const later = [...events, ev({ id: 'ev_l', type: 'answer', ts: new Date(now - 1000).toISOString(), ask: { askId: 'ev_ask', verdict: 'later' } })]
  const l = looseEnds(later, { now })
  assert.equal(l.length, 1, '说了「以后再说」的还得摆着')
  assert.match(l[0].text, /以后再说/)

  const approved = [...events, ev({ id: 'ev_a', type: 'answer', ts: new Date(now - 1000).toISOString(), ask: { askId: 'ev_ask', verdict: 'approve' } })]
  const a = looseEnds(approved, { now })
  assert.equal(a.length, 1, '答应了还没到的也得摆着')
  assert.match(a[0].text, /答应了，还没见到/)

  // 放一天没人答的（`lib/ask.js` 记成 verdict:'later' + via:'timeout'）不是「以后再说」：
  // 什么都没人说。文案还得是「还没有得到答复」，窗口也还是 3 天。
  const timedOut = [...events, ev({ id: 'ev_t', type: 'answer', ts: new Date(now - 1000).toISOString(), ask: { askId: 'ev_ask', verdict: 'later', via: 'timeout' } })]
  const t = looseEnds(timedOut, { now })
  assert.equal(t.length, 1)
  assert.match(t[0].text, /还没有得到答复/)
  assert.doesNotMatch(t[0].text, /以后再说/)
  assert.equal(looseEnds(timedOut, { now: now + 4 * 86_400_000 }).length, 0, '没人答的仍是 3 天窗口')

  // 窗口：没答的 3 天、「以后再说」30 天、答应了 14 天。
  const old = [ev({ id: 'ev_old', type: 'ask', ts: new Date(now - 10 * 86_400_000).toISOString(), text: '十天前问的' })]
  assert.equal(looseEnds(old, { now }).length, 0, '十天没答的就不催了')
  const oldLater = [...old, ev({ id: 'ev_old_ans', type: 'answer', ts: new Date(now - 9 * 86_400_000).toISOString(), ask: { askId: 'ev_old', verdict: 'later' } })]
  assert.equal(looseEnds(oldLater, { now }).length, 1, '十天前说「以后再说」的还摆着')
  const oldApproved = [
    ev({ id: 'ev_vo', type: 'ask', ts: new Date(now - 15 * 86_400_000).toISOString(), text: '十五天前问的' }),
    ev({ id: 'ev_vo_ok', type: 'answer', ts: new Date(now - 14 * 86_400_000).toISOString(), ask: { askId: 'ev_vo', verdict: 'approve' } }),
  ]
  assert.equal(looseEnds(oldApproved, { now }).length, 0, '答应过 14 天还没到的，不再摆')
})

test('her_say 必须指回真实事件：没 refs、超量、不存在、不是材料都写不进去', () => withRoot(async (root) => {
  line(root, ev({ id: 'ev_say', type: 'utterance', text: '我先前的记录', ts: new Date().toISOString() }))
  line(root, ev({ id: 'ev_meta', type: 'meta', text: 'diary:2026-10-30', ts: new Date().toISOString() }))

  assert.match((await writeSay(root, { text: '想说的话' })).note, /refs/)
  assert.match((await writeSay(root, { text: '想说的话', refs: ['ev_say', 'ev_say', 'ev_say', 'ev_say', 'ev_say', 'ev_say', 'ev_say'] })).note, /最多/)
  assert.match((await writeSay(root, { text: '想说的话', refs: ['ev_nope'] })).note, /不存在/)
  assert.match((await writeSay(root, { text: '想说的话', refs: ['ev_meta'] })).note, /不能当材料/)
  assert.match((await writeSay(root, { text: '想'.repeat(PROACTIVE_MAX + 1), refs: ['ev_say'] })).note, /最多/)
  assert.match((await writeSay(root, { text: '   ', refs: ['ev_say'] })).note, /写出来/)
}))

test('写下的一句会落成 utterance（带「她主动说」前缀）并留一条 proactive-say 记账', () => withRoot(async (root) => {
  const now = Date.now()
  line(root, ev({ id: 'ev_say', type: 'utterance', text: '我今天有点累', ts: new Date(now - 3_600_000).toISOString() }))

  const r = await writeSay(root, { text: '我想问你，晚饭吃了没有。', refs: ['ev_say'], why: 'care', now })
  assert.equal(r.ok, true, r.note)

  const { events } = await readEvents(root)
  const said = events.find((e) => e.id === r.id)
  assert.equal(said.type, 'utterance')
  assert.match(said.text, /^（她主动说）我想问你/)
  assert.deepEqual(said.refs, ['ev_say'])

  const meta = events.find((e) => e.type === 'meta' && String(e.text ?? '').startsWith(`proactive-say:${dateKey(new Date(now))}`))
  assert.ok(meta, '得留一条记账，事后查得到她那天为什么开口')
  assert.match(meta.text, /care/)
}))

test('her_say 真的按「一天最多几次」拦住，不是只在说明书写着（issue #41）', () => withRoot(async (root) => {
  const now = Date.now()
  const dk = dateKey(new Date(now))
  line(root, ev({ id: 'ev_say', type: 'utterance', text: '我今天有点累', ts: new Date(now - 3_600_000).toISOString() }))
  await writeConfig(normalizeConfig({ proactive: { enabled: true, maxPerDay: 2 } }), root)

  const a = await writeSay(root, { text: '第一句。', refs: ['ev_say'], now })
  assert.equal(a.ok, true, a.note)
  const b = await writeSay(root, { text: '第二句。', refs: ['ev_say'], now })
  assert.equal(b.ok, true, b.note)
  // 第三句该被挡住：原来这里读了 config 却没用，连写八次都成功。
  const c = await writeSay(root, { text: '第三句。', refs: ['ev_say'], now })
  assert.equal(c.ok, false)
  assert.match(c.note, /上限/)

  assert.equal(saysToday(await readEvents(root).then((r) => r.events), dk), 2)
}))

test('her_say 写下的 day/stage 是真实成长坐标，不是写死的 1/1（issue #41）', () => withRoot(async (root) => {
  const now = Date.now()
  // seed 落在 40 天前：growthDay 应该算出 41 天左右，而不是恒定 1。
  line(root, ev({ id: 'ev_seed', type: 'seed', text: '起点', ts: new Date(now - 40 * 86_400_000).toISOString() }))
  line(root, ev({ id: 'ev_say', type: 'utterance', text: '我先前的记录', ts: new Date(now - 3_600_000).toISOString() }))
  await writeConfig(normalizeConfig({ proactive: { enabled: true } }), root)

  const { events } = await readEvents(root)
  const model = deriveSelf(events)
  assert.ok(model.day > 30, `seed 40 天前，成长日该是 41 左右，实际 ${model.day}`)

  const r = await writeSay(root, { text: '写一句。', refs: ['ev_say'], now })
  assert.equal(r.ok, true, r.note)
  const after = (await readEvents(root)).events
  const said = after.find((e) => e.id === r.id)
  assert.equal(said.day, model.day, 'day 得跟 deriveSelf 一致，否则 consistency() 会把它当成阶段 1 的旧话')
  assert.equal(said.stage, model.stage)
  const meta = after.find((e) => e.type === 'meta' && String(e.text ?? '').startsWith(`proactive-say:${dateKey(new Date(now))}`))
  assert.equal(meta.day, model.day)
}))

test('her_say 在 0.9.0 起对所有人注册', () => {
  const src = readFileSync(new URL('../lib/proactive.js', import.meta.url), 'utf8')
  assert.match(src, /name: 'her_say'/)
  // 2026-11-07（用户 m01602）：原来每次醒来都摆的 TOOL_ASK_NOTE 常量已经撤掉。
  // 只许在注释里提到它为什么消失，不许再有这个导出。
  assert.doesNotMatch(src, /export const TOOL_ASK_NOTE/)

  const registered = []
  const ctx = { tools: { register: (t) => registered.push(t) } }
  registerProactive(ctx, { root: tmpdir(), log: () => {} })
  assert.equal(registered.length, 1)
  assert.equal(registered[0].name, 'her_say')
  assert.deepEqual(registered[0].parameters.required, ['text', 'refs'])
})

test('her_say 的显示结果是 ContentBlock 数组，不是字符串（0.8.2 真机栽在这）', () => {
  const registered = []
  const ctx = { tools: { register: (t) => registered.push(t) } }
  registerProactive(ctx, { root: tmpdir(), log: () => {} })
  const spec = registered[0]

  // 2026-10-30 真机：她连着两次拿到「Error: content.some is not a function」，
  // 第三轮她写「Don't retry a third time」，然后一个字都没说。
  for (const out of [{ ok: true, note: '' }, { ok: false, note: '这条没记下。' }]) {
    const blocks = spec.output.render({}, out)
    assert.ok(Array.isArray(blocks), 'render 必须返回数组，宿主会对它调 content.some')
    assert.equal(blocks.length, 1)
    assert.equal(blocks[0].type, 'text')
    assert.equal(typeof blocks[0].text, 'string')
    assert.ok(blocks[0].text.length > 0)
  }
  // 2026-11-06（issue #41）：回执原来写「说出去了」，可这一步只落一条流水；
  // 用户此刻看不看得见，由她这一轮有没有直接写正文决定。回执按实际做的事说。
  assert.match(spec.output.render({}, { ok: true }).at(0).text, /记下了/)
  assert.match(spec.output.render({}, { ok: false, note: '这条没记下。' }).at(0).text, /没记下/)
})

test('turnsToday / lastTurnAt 只认当日与最近一次，不把别人的 meta 算进来', () => {
  const now = Date.now()
  const dk = dateKey(new Date(now))
  const events = [
    ev({ id: 'ev_t', type: 'meta', text: `proactive-turn:${dk}:${now - 3_600_000}`, ts: new Date(now - 3_600_000).toISOString() }),
    ev({ id: 'ev_d', type: 'meta', text: `proactive-turn:2020-01-01:1`, ts: new Date(now - 5 * 86_400_000).toISOString() }),
    ev({ id: 'ev_other', type: 'meta', text: 'diary:2026-10-30', ts: new Date(now - 1000).toISOString() }),
  ]
  assert.equal(turnsToday(events, dk), 1)
  assert.equal(lastTurnAt(events), now - 3_600_000)
  // 那条 diary 是一秒前写的，但它是系统记账、不是谁说的话：idle 时钟停在 1 小时前那个空手回合上。
  // 改之前这里会算成「一秒前刚说过话」——2026-11-01 用户 m02507 修的就是这个。
  assert.ok(idleHoursOf(events, now) > 0.9, '系统记账不许把 idle 时钟往回拨')
  const withSpeak = [...events, ev({ id: 'ev_u', type: 'utterance', ts: new Date(now - 300).toISOString() })]
  assert.ok(idleHoursOf(withSpeak, now) < 0.1, '她真的说了话，才算「刚才说过」')
  assert.equal(idleHoursOf([], now), Infinity, '一条记录都没有时算「很久」')
})

test('meta:quiet 不刷新 idle：今天没找到模板，不等于她刚说过话（用户 m02507）', () => {
  const now = Date.now()
  const quiet = ev({ id: 'ev_q', type: 'meta', text: 'quiet:2026-10-31 无候选模板，今天不打扰', ts: new Date(now - 60_000).toISOString() })
  const spoke = ev({ id: 'ev_u', type: 'utterance', ts: new Date(now - 6 * 3_600_000).toISOString() })
  assert.equal(countsForIdle(quiet), false, 'quiet 是记账行，不算有人说话')
  assert.ok(idleHoursOf([quiet, spoke], now) > 5.9, '时钟还是停在 6 小时前那句真话上')
  assert.equal(idleHoursOf([quiet], now), Infinity, '只有记账行时，等于「一直没人说话」')
})

test('meta:watched 也不刷新 idle：她看了条视频，不等于她说过话（真机 2026-10-30 22:03 那次假阴性）', () => {
  const now = Date.now()
  // 那次现场：她实际安静了 17.55 小时，插件读到 0.01h，来源是一条 meta:watched。
  const watched = ev({ id: 'ev_w', type: 'meta', text: 'watched:BV1xx411c7mD', ts: new Date(now - 36_000).toISOString() })
  const answer = ev({ id: 'ev_a', type: 'answer', text: '可以', ts: new Date(now - 17.55 * 3_600_000).toISOString() })
  assert.equal(countsForIdle(watched), false)
  const idle = idleHoursOf([watched, answer], now)
  assert.ok(idle > 17.5, '应该是 17.5 小时，不是 0.01 小时')
  // 反过来：几种「真的有人说话」的事件都要算。
  for (const type of ['utterance', 'revise', 'heard', 'voice', 'ask', 'answer', 'dream']) {
    assert.equal(countsForIdle(ev({ type })), true, `${type} 应该算`)
  }
  // 2026-11-05 真机（用户 m02797）：`seen:` 不算。它会被别的会话的用户活动误写，
  // 一写就把 idle 清零 → `minIdleHours` 永远不满足 → 主动搭话一次都开不出来。
  assert.equal(countsForIdle(ev({ type: 'meta', text: `seen:${new Date(now).toISOString()}` })), false, 'seen: 不进 idle（会被别的会话误写）')
  const seenOnly = [ev({ id: 'ev_s', type: 'meta', text: `seen:${new Date(now - 2_000).toISOString()}` })]
  assert.equal(idleHoursOf(seenOnly, now), Infinity, '只有 seen: 时等于「一直没有话落进她房间」')
  assert.equal(countsForIdle(ev({ type: 'meta', text: `diary:2026-10-31` })), false, 'diary 不算')
  assert.equal(countsForIdle(ev({ type: 'meta', text: `sched:2026-11-01` })), false, 'sched 不算')
})

test('醒来后没开口的那几次：不占当天额度，但单独限次数、单独隔时间（2026-11-05，用户 m00803）', () => {
  const now = Date.now()
  const dk = dateKey(new Date(now))
  const quiet = [ev({ ts: new Date(now - 10 * 3_600_000).toISOString() })]
  const silent = (h, id = `ev_s${h}`) => ev({
    id,
    type: 'meta',
    text: `${SILENT_MARK}${dk}:${now + h * 3_600_000}`,
    ts: new Date(now + h * 3_600_000).toISOString(),
  })

  // 三次静默、proactive-turn 一次都没有 → 当天的额度一个都没被扣。
  const three = [...quiet, silent(-5), silent(-4), silent(-3)]
  assert.equal(turnsToday(three, dk), 0, '静默不许记成空手回合，否则「醒着没话说」会吃掉额度')
  assert.equal(silentToday(three, dk), 3)
  assert.equal(lastSilentAt(quiet), 0, '没静默过就是 0')
  assert.equal(lastSilentAt(three), now - 3 * 3_600_000)
  // 上一次静默在 3 小时前（超过 SILENT_QUIET_HOURS）→ 放行，额度仍在。
  const ok = proactiveState({ config: ON, events: three, now })
  assert.equal(ok.ok, true, `静默过也不该挡住下一次开口：${ok.why}`)

  // 刚静默过 30 分钟：先隔一会儿，别让「醒来」变成机械动作。
  const justNow = [...quiet, ev({ id: 'ev_s', type: 'meta', text: `${SILENT_MARK}${dk}:${now}`, ts: new Date(now - 30 * 60_000).toISOString() })]
  assert.match(proactiveState({ config: ON, events: justNow, now }).why, /没开口/)

  // 今天已经静默满 SILENT_MAX_PER_DAY 次：停，但仍然没动 proactive-turn 的额度。
  const full = [
    ...quiet,
    ...Array.from({ length: SILENT_MAX_PER_DAY }, (_, i) => silent(-(i + 3), `ev_f${i}`)),
  ]
  assert.equal(turnsToday(full, dk), 0)
  assert.equal(proactiveState({ config: ON, events: full, now }).why.length > 0, true)
  assert.match(proactiveState({ config: ON, events: full, now }).why, /太多次/)
  assert.ok(SILENT_QUIET_HOURS >= 1, '静默间隔至少一小时，不然她会连着醒、连着不说')
})

// ---- tick 里先看开关，再算 deriveSelf ----
//
// tick 每分钟跑一次，deriveSelf 是同步的，事件流长了会卡住主线程。
// 「允许她主动开口」默认就是关的，关着的时候不该为它算这一遍。
//
// deriveSelf 是 scheduler.js 静态 import 的，从外面数不了次数，耗时又不稳，不拿来断言。
// 所以往事件流里放一条它读不了的行：revise 的 refs 不是数组时它会抛，
// tick 接住后记一行 `proactive failed`。日志里有这一行，就是这一趟算过了。
async function twoTicks(root, over, windowOverride) {
  // 2026-11-06：主动性现在也要过「每天几点醒」这一关，所以默认给全天的窗口——
  // tick 才会真的走到 maybeProactive，几点跑都一样。要测「窗口外不开口」
  // 就显式传一个不覆盖此刻的窗口。
  // （2026-11-07 PR #55 @BBleae：不要按此刻现算——0 点时 `hh(-1)` 算出 `-1:00`，
  //  validWindow 不认，normalizeConfig 悄悄退回默认 20:00–23:00，那三条就红。）
  const win = windowOverride ?? ['00:00', '23:59']
  await writeConfig(normalizeConfig({ window: win, ...over }), root)
  line(root, { id: 'ev_unreadable', type: 'revise', ts: new Date().toISOString(), text: '合成', refs: 1 })
  const { events } = await readEvents(root)
  assert.throws(() => deriveSelf(events), TypeError, '这一行得让 deriveSelf 抛，否则下面的断言什么也没测')

  const logs = []
  const s = startScheduler({}, { root, log: (...a) => logs.push(a.join(' ')) })
  const realNow = Date.now
  try {
    await s.tick()
    // 同一分钟内 tick 只算一次，把钟往后拨一分钟。
    const later = realNow() + 60_000
    Date.now = () => later
    await s.tick()
  } finally {
    Date.now = realNow
    s.dispose()
  }
  return logs
}

test('tick：主动说话关着不算 deriveSelf，跳过的原因照旧只记一行', async () => {
  await withRoot(async (root) => {
    const logs = await twoTicks(root, {})
    assert.deepEqual(logs.filter((l) => l.startsWith('proactive')), ['proactive skip 主动说话是关着的'], logs.join(' | '))
  })
})

test('tick：「主动性」关着仍然排在最前面，记的还是它自己那一行', async () => {
  await withRoot(async (root) => {
    const logs = await twoTicks(root, { drive: { enabled: false } })
    assert.deepEqual(logs.filter((l) => l.startsWith('proactive')), ['proactive skip 主动性关着'], logs.join(' | '))
  })
})

test('tick：主动说话开着，每一趟照旧先算 deriveSelf', async () => {
  await withRoot(async (root) => {
    const logs = await twoTicks(root, { proactive: { enabled: true } })
    assert.equal(logs.filter((l) => l.startsWith('proactive failed')).length, 2, logs.join(' | '))
  })
})

test('tick：「每天几点醒」之外的时刻，主动性也不许开口', async () => {
  await withRoot(async (root) => {
    // 窗口排到 5 小时后：此刻一定不在里面。她要是在这种时刻还能主动找他，
    // 「只在这个时段里自己醒」就成了摆设。
    const t = new Date(Date.now() + 5 * 3600_000)
    const hh2 = (d) => `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
    const logs = await twoTicks(root, { proactive: { enabled: true } },
      [hh2(t), hh2(new Date(t.getTime() + 30 * 60_000))])
    assert.equal(logs.filter((l) => l.startsWith('proactive')).length, 0, logs.join(' | '))
  })
})
