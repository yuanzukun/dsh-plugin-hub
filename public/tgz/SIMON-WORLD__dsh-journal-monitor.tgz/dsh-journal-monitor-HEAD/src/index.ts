/**
 * dsh-journal-monitor — 经管期刊/工作论文监控推送插件
 *
 * 真插件（非 skill）：RSS/API 抓取 → 关键词过滤 → 推送 → 去重持久化 → 定时调度。
 * 最小闭环：scan → filter(plan) → push(apply) → status(verify) → rollback。
 * 定时：journal_briefing 生成 schedule_create 参数（复用内置 dsh-schedule 协议）。
 * 默认 dry-run：不真正发送推送，只输出将推送内容，配置 webhook 后启用真实推送。
 *
 * v0.2.0 变更：并入 schedule-briefing 的 arXiv 多类目 API 抓取 + 定时简报参数生成。
 * 标准 DSH 插件格式：cordis.patch.yml 挂载 + defineTool 注册。
 * 依赖：Node >= 18（全局 fetch），运行时零第三方依赖。
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import { readFileSync, mkdirSync, existsSync, appendFileSync } from 'node:fs'
import { dirname, join } from 'node:path'

export const name = 'dsh-journal-monitor'
export const inject = ['tools']

/** 运行时自定义源（journal_add_source 注册，会话内有效） */
export const customSources: Array<{ id: string; kind?: string; url?: string; label?: string }> = []

/** 注册自定义源：id 唯一；kind 支持 rss / arxiv / cn-toc / ajcass。 */
export function registerSource(src: { id: string; kind?: string; url?: string; label?: string }): { ok: boolean; error?: string } {
  if (!src.id || !/^[a-zA-Z0-9-_]{2,40}$/.test(src.id)) return { ok: false, error: `invalid id: ${src.id}` }
  if (!src.url && src.kind !== 'arxiv') return { ok: false, error: 'url required for non-arxiv sources' }
  const existing = [...ECON_SOURCES, ...customSources].find((s) => s.id === src.id)
  if (existing) return { ok: false, error: `duplicate id: ${src.id}` }
  customSources.push({ id: src.id, kind: src.kind ?? 'rss', url: src.url, label: src.label ?? src.id })
  return { ok: true }
}

/** 全部源（内置 + 自定义）。 */
export function allSources(): Array<{ id: string; kind?: string; url?: string; label?: string }> {
  return [...ECON_SOURCES, ...customSources]
}

/** 经济学文献源：arXiv 多类目（API）+ NBER RSS + 中文经管期刊（HTML 目录页） */
export const ECON_SOURCES = [
  { id: 'arxiv-econ.GN', kind: 'arxiv', label: 'arXiv 一般经济学' },
  { id: 'arxiv-econ.EM', kind: 'arxiv', label: 'arXiv 计量经济学' },
  { id: 'arxiv-econ.TH', kind: 'arxiv', label: 'arXiv 理论经济学' },
  { id: 'arxiv-q-fin.GN', kind: 'arxiv', label: 'arXiv 量化金融' },
  { id: 'nber', kind: 'rss', label: 'NBER Working Papers', url: 'https://www.nber.org/rss/new.xml' },
  {
    id: 'sjjj',
    kind: 'cn-toc',
    label: '世界经济（中文经管）',
    url: 'https://sjjj.magtech.com.cn/CN/online_first',
  },
  {
    id: 'sjjj-current',
    kind: 'cn-toc',
    label: '世界经济当期目录（含摘要）',
    url: 'https://sjjj.magtech.com.cn/CN/home',
  },
  {
    id: 'zgncgc',
    kind: 'ajcass',
    label: '中国农村观察（中文经管）',
    url: 'https://zgncgc.ajcass.com/',
  },
  {
    id: 'cmjj',
    kind: 'ajcass',
    label: '财贸经济（中文经管）',
    url: 'https://cmjj.ajcass.com/',
  },
  {
    id: 'zgrkkx',
    kind: 'ajcass',
    label: '中国人口科学（中文经管）',
    url: 'https://zgrkkx.ajcass.com/',
  },
  {
    id: 'jjgl',
    kind: 'ajcass',
    label: '经济管理（中文经管）',
    url: 'https://jjgl.ajcass.com/',
  },
]

/** 内置默认 RSS 源（v0.1.0 兼容：journal_scan 无参调用） */
const DEFAULT_SOURCES = [
  { id: 'nber', label: 'NBER Working Papers', url: 'https://www.nber.org/rss/new.xml' },
  { id: 'arxiv-econ', label: 'arXiv Economics', url: 'http://export.arxiv.org/rss/econ' },
]

/** 状态文件位置：DSH_JOURNAL_STATE 环境变量 > 工作区 .dsh-journal-monitor/state.jsonl */
function stateFile(): string {
  return (
    process.env.DSH_JOURNAL_STATE ||
    join(process.env.DSH_WORKSPACE || process.cwd(), '.dsh-journal-monitor', 'state.jsonl')
  )
}

function readState(): Map<string, string> {
  const map = new Map<string, string>()
  const f = stateFile()
  if (!existsSync(f)) return map
  for (const line of readFileSync(f, 'utf8').split('\n')) {
    if (!line.trim()) continue
    try {
      const rec = JSON.parse(line)
      map.set(rec.id, rec.pushedAt || '')
    } catch {
      // skip malformed lines
    }
  }
  return map
}

function appendState(rec: unknown): void {
  const f = stateFile()
  mkdirSync(dirname(f), { recursive: true })
  appendFileSync(f, JSON.stringify(rec) + '\n', 'utf8')
}

/** 抓取 RSS/Atom 并解析为条目列表（title/link/summary/date）。Node 全局 fetch。 */
async function fetchFeed(url: string, timeoutMs = 20000): Promise<Array<Record<string, string>>> {
  const ctrl = new AbortController()
  const t = setTimeout(() => ctrl.abort(), timeoutMs)
  try {
    const res = await fetch(url, { signal: ctrl.signal, headers: { 'user-agent': 'dsh-journal-monitor/0.2' } })
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`)
    const xml = await res.text()
    return parseFeed(xml)
  } finally {
    clearTimeout(t)
  }
}

/** 极简 XML 解析：按 <item> 或 <entry> 块切分，提取常见字段（无第三方依赖）。 */
export function parseFeed(xml: string): Array<Record<string, string>> {
  const items: Array<Record<string, string>> = []
  const blockRe = /<(item|entry)\b[^>]*>([\s\S]*?)<\/\1>/gi
  let m: RegExpExecArray | null
  while ((m = blockRe.exec(xml)) !== null) {
    const block = m[2]
    const grab = (tag: string): string => {
      const re = new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)</${tag}>`, 'i')
      const mm = block.match(re)
      if (!mm) return ''
      return mm[1]
        .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
        .replace(/<[^>]+>/g, '')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/\s+/g, ' ')
        .trim()
    }
    const linkRaw = grab('link') || grab('id')
    // Atom 的 link 是属性形式 <link href="..."/> 时上面拿不到，补一个属性提取
    const hrefMatch = block.match(/<link\b[^>]*href="([^"]+)"/i)
    const title = grab('title')
    if (!title && !linkRaw) continue
    items.push({
      title,
      link: linkRaw || (hrefMatch ? hrefMatch[1] : ''),
      summary: grab('description') || grab('summary'),
      date: grab('pubDate') || grab('published') || grab('updated'),
    })
  }
  return items
}

/** 抓取 arXiv 类目（API，支持 econ.GN / econ.EM / econ.TH / q-fin.GN）。 */
export async function fetchArxivCategory(category: string, limit = 10, timeoutMs = 20000): Promise<Array<Record<string, string>>> {
  const url = `http://export.arxiv.org/api/query?search_query=cat:${encodeURIComponent(category)}&sortBy=submittedDate&sortOrder=descending&max_results=${limit}`
  const res = await fetch(url, { signal: AbortSignal.timeout(timeoutMs) })
  if (!res.ok) throw new Error(`arXiv API HTTP ${res.status}`)
  return parseFeed(await res.text())
}

/** 解析中文期刊 HTML 目录页（玛格泰克平台）：支持两种格式——
 * 1) online_first：abstract*.shtml 链接 + 标题
 * 2) home 当期目录：j-title-1（标题）+ j-author（作者）+ j-volumn-doi（卷期页码）+ j-abstract（摘要）
 */
export function parseCnToc(html: string, baseUrl: string): Array<Record<string, string>> {
  const items: Array<Record<string, string>> = []
  const seen = new Set<string>()

  // 格式 2：home 当期目录（更完整：作者/卷期/摘要）
  const fullRe = /<div class="j-title-1">\s*<a href="([^"]+)">([\s\S]*?)<\/a>[\s\S]*?<div class="j-author">([\s\S]*?)<\/div>[\s\S]*?<div class="j-volumn-doi">[\s\S]*?<span class="j-volumn">([\s\S]*?)<\/span>[\s\S]*?<div class="j-abstract">([\s\S]*?)<\/div>/gi
  let fm: RegExpExecArray | null
  while ((fm = fullRe.exec(html)) !== null) {
    const title = fm[2].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim()
    if (title.length < 4 || seen.has(title)) continue
    seen.add(title)
    const link = fm[1].startsWith('http') ? fm[1] : new URL(fm[1], baseUrl).href
    items.push({
      title,
      link,
      summary: fm[5].replace(/<[^>]+>/g, '').replace(/&#x0201[cd];/g, '').replace(/&[a-z]+;/g, '').replace(/\s+/g, ' ').trim(),
      date: fm[4].replace(/\s+/g, ' ').trim(),
      authors: fm[3].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim(),
    })
  }

  // 格式 1：online_first（abstract*.shtml 链接）
  const re = /<a[^>]*href="([^"]*(?:abstract|article|view|online)[^"]*)"[^>]*>([\s\S]{2,180}?)<\/a>/gi
  let m: RegExpExecArray | null
  while ((m = re.exec(html)) !== null) {
    const href = m[1]
    const rawTitle = m[2].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim()
    if (rawTitle.length < 4 || seen.has(rawTitle)) continue
    seen.add(rawTitle)
    const link = href.startsWith('http') ? href : new URL(href, baseUrl).href
    items.push({ title: rawTitle, link, summary: '', date: '', authors: '' })
  }
  return items
}

/** 解析 ajcass 平台（中国社科院期刊，如《中国农村观察》）当期目录：标题 + 作者 + 卷期 + 摘要链接。 */
export function parseAjcass(html: string, baseUrl: string): Array<Record<string, string>> {
  const items: Array<Record<string, string>> = []
  const seen = new Set<string>()

  // 版式 A：旧版（中国农村观察）——<p class="green"> 标题块 + <p class="hod pop"> 卷期块
  const blockRe = /<p[^>]*class="green"[^>]*>([\s\S]*?)<\/p>/gi
  let bm: RegExpExecArray | null
  while ((bm = blockRe.exec(html)) !== null) {
    const block = bm[1]
    const href = block.match(/href="(\/Magazine\/Show\?id=\d+)"/)?.[1]
    const title = block.match(/<a[^>]*>([\s\S]{2,200}?)<\/a>/)?.[1]?.replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim()
    const authors = block.match(/作者:([\s\S]{2,80}?)(?:<|$)/)?.[1]
    if (!href || !title || title.length < 4 || seen.has(title)) continue
    seen.add(title)
    const tail = html.slice(bm.index + bm[0].length, bm.index + bm[0].length + 400)
    const vol = tail.match(/(20\d{2}\s*NO\.\d+)/)?.[1] ?? ''
    items.push({
      title,
      link: href.startsWith('http') ? href : new URL(href, baseUrl).href,
      summary: '',
      date: vol.trim(),
      authors: (authors ?? '').replace(/\s+/g, ' ').trim(),
    })
  }

  // 版式 B：新版（财贸经济/中国人口科学/经济管理）——<li><h3><a>标题</a></h3> 或 <li><a title="标题">
  // href 支持查询式（?id=NNN / ?ID=NNN）与路径式（/Show/NNN）
  // 跨 li 可能同一 href 出现截断标题（…）与完整标题，按 href 全局保留最长标题
  const byHref = new Map<string, { title: string; block: string }>()
  const liRe = /<li\b[^>]*>([\s\S]*?)<\/li>/gi
  let lm: RegExpExecArray | null
  while ((lm = liRe.exec(html)) !== null) {
    const block = lm[1]
    const href =
      block.match(/href="(\/Magazine\/Show(?:\?(?:ID|id)=\d+|\/\d+))"/)?.[1] ??
      block.match(/href="(\/Magazine\/Show\/\d+)"/)?.[1]
    if (!href) continue
    // 取 li 内最长的 a 文本或 title 属性作为标题
    let bestTitle = ''
    const aRe = /<a[^>]*>([\s\S]{2,220}?)<\/a>/g
    let am: RegExpExecArray | null
    while ((am = aRe.exec(block)) !== null) {
      const t = am[1].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim()
      if (t.length > bestTitle.length) bestTitle = t
    }
    if (bestTitle.length < 4) {
      bestTitle = block.match(/title="([\s\S]{2,220}?)"/)?.[1]?.replace(/\s+/g, ' ').trim() ?? ''
    }
    if (!bestTitle || bestTitle.length < 4 || /^\[?(摘要|PDF|下载)/.test(bestTitle)) continue
    const absHref = href.startsWith('http') ? href : new URL(href, baseUrl).href
    const existing = byHref.get(absHref)
    // 同 href 截断标题（含 … 省略号）应被完整标题覆盖；都不含省略号时取更长
    const isTruncated = (t: string) => /…|\.\.\./.test(t)
    if (existing) {
      const oldWins = !isTruncated(existing.title) && isTruncated(bestTitle) // 旧的是完整版
      const newWins = isTruncated(existing.title) && !isTruncated(bestTitle) // 新的是完整版
      const sameClass = isTruncated(existing.title) === isTruncated(bestTitle) && bestTitle.length <= existing.title.length
      if (newWins) byHref.set(absHref, { title: bestTitle, block })
      if (oldWins || sameClass) continue
    } else {
      byHref.set(absHref, { title: bestTitle, block })
    }
  }
  for (const [absHref, { title, block }] of byHref) {
    if (seen.has(title)) continue
    seen.add(title)
    let authors = ''
    const pm = block.match(/<p[^>]*>\s*([^<]{2,60}?)\s*<\/p>/)
    if (pm && !/20\d{2}年/.test(pm[1])) authors = pm[1]
    const vol = block.match(/(20\d{2}年\s*第\(?\d+\)?卷[^<]*?第\d+期[^<]*?)/)?.[1]?.replace(/\s+/g, ' ').trim() ?? ''
    const summary = block.match(/class="zy"[^>]*title="([\s\S]*?)"/)?.[1]?.replace(/\s+/g, ' ').trim() ?? ''
    items.push({
      title,
      link: absHref,
      summary,
      date: vol,
      authors: authors.replace(/\s+/g, ' ').trim(),
    })
  }
  return items
}

/** 抓取中文期刊 HTML 目录页。 */
async function fetchCnToc(url: string, timeoutMs = 25000): Promise<Array<Record<string, string>>> {
  const res = await fetch(url, {
    signal: AbortSignal.timeout(timeoutMs),
    headers: { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36' },
  })
  if (!res.ok) throw new Error(`CN TOC HTTP ${res.status}`)
  return parseCnToc(await res.text(), url)
}

/** 抓取 ajcass 平台期刊当期目录。 */
async function fetchAjcass(url: string, timeoutMs = 25000): Promise<Array<Record<string, string>>> {
  const res = await fetch(url, {
    signal: AbortSignal.timeout(timeoutMs),
    headers: { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36' },
  })
  if (!res.ok) throw new Error(`Ajcass HTTP ${res.status}`)
  return parseAjcass(await res.text(), url)
}

/** 按源 id 抓取：arXiv 类目（arxiv-*）走 API，cn-toc 走中文 HTML 目录页，ajcass 走社科院平台，其余按 RSS URL。 */
async function fetchSource(src: { id: string; kind?: string; url?: string }, limit: number): Promise<Array<Record<string, string>>> {
  if (src.kind === 'arxiv' || /^arxiv-/.test(src.id)) {
    const cat = src.id.replace(/^arxiv-/, '')
    return fetchArxivCategory(cat, limit)
  }
  if (src.kind === 'cn-toc' && src.url) {
    return (await fetchCnToc(src.url)).slice(0, limit)
  }
  if (src.kind === 'ajcass' && src.url) {
    return (await fetchAjcass(src.url)).slice(0, limit)
  }
  if (src.url) return fetchFeed(src.url)
  return []
}

/** 关键词过滤：标题+摘要小写匹配。 */
export function filterItems(items: Array<Record<string, string>>, keywords: string[]): Array<Record<string, string>> {
  if (!keywords || keywords.length === 0) return items
  const kws = keywords.map((k) => k.toLowerCase().trim()).filter(Boolean)
  return items.filter((it) => {
    const hay = `${it.title} ${it.summary}`.toLowerCase()
    return kws.some((k) => hay.includes(k))
  })
}

/** 计算条目稳定 id（link 或 title hash），用于去重。 */
export function itemId(it: Record<string, string>): string {
  const base = it.link || it.title
  let h = 0
  for (let i = 0; i < base.length; i++) {
    h = (h * 31 + base.charCodeAt(i)) | 0
  }
  return `jm-${h.toString(16)}`
}

/** 构建 schedule_create 参数 + 自包含监控提示词（复用内置 dsh-schedule 协议）。 */
export function buildBriefing(topic: string, intervalDays: number): { every_seconds: number; schedule_prompt: string } {
  const everySeconds = Math.max(300, Math.max(1, Math.floor(intervalDays)) * 86400)
  const sourceIds = ECON_SOURCES.map((s) => s.id).join('、')
  const prompt = [
    `[经济文献简报] 主题：${topic}`,
    `监控源：${sourceIds}`,
    `步骤：1) 对每个源调用 journal_scan 拉取最近文献；2) 用 journal_filter 按主题关键词过滤；3) 用 journal_push 推送（dry-run 或 webhook）；4) 用 journal_status 查看去重记录。`,
    `只汇报真实抓取到的条目，不要臆造。`,
  ].join('\n')
  return { every_seconds: everySeconds, schedule_prompt: prompt }
}

/** 推送：默认 dry-run 只打印；配置 barkUrl / feishuUrl 任一才真实发送。导出供集成测试。 */
export async function push(
  items: Array<Record<string, string>>,
  opts: { barkUrl?: string; feishuUrl?: string; dryRun?: boolean },
): Promise<{ pushed: Array<Record<string, string>>; skipped: number; dryRun: boolean }> {
  const state = readState()
  const newItems = items.filter((it) => !state.has(itemId(it)))
  // 显式 dryRun: true 覆盖 webhook；无 webhook 时自动 dry-run；dryRun: false 且无 webhook 也按 dry-run（不误发）
  const dryRun = opts.dryRun === true || (!opts.barkUrl && !opts.feishuUrl)
  const sent: Array<Record<string, string>> = []
  for (const it of newItems) {
    const id = itemId(it)
    if (dryRun) {
      sent.push(it)
      appendState({ id, title: it.title, link: it.link, pushedAt: new Date().toISOString(), dryRun: true })
      continue
    }
    if (opts.barkUrl) {
      const body = `【${it.title}】\n${it.summary || ''}\n${it.link}`
      const r = await fetch(opts.barkUrl + encodeURIComponent(body), { signal: AbortSignal.timeout(15000) })
      if (!r.ok) throw new Error(`Bark push failed: HTTP ${r.status}`)
    }
    if (opts.feishuUrl) {
      const body = {
        msg_type: 'text',
        content: { text: `【${it.title}】\n${it.link}` },
      }
      const r = await fetch(opts.feishuUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(15000),
      })
      if (!r.ok) throw new Error(`Feishu push failed: HTTP ${r.status}`)
    }
    appendState({ id, title: it.title, link: it.link, pushedAt: new Date().toISOString() })
    sent.push(it)
  }
  return { pushed: sent, skipped: newItems.length - sent.length, dryRun }
}

export function apply(ctx: any): void {
  ctx.tools.register(
    defineTool({
      name: 'journal_scan',
      description:
        '抓取经管期刊/工作论文源，返回论文条目列表。源：nber（RSS）、arxiv-econ.GN/EM/TH、arxiv-q-fin.GN（API）、任意 RSS/Atom URL（sourceUrl）。不传参数默认抓全部经济源。',
      parameters: {
        source: { type: 'string', description: '源 id：nber / arxiv-econ.GN / arxiv-econ.EM / arxiv-econ.TH / arxiv-q-fin.GN' },
        sourceUrl: { type: 'string', description: '自定义 RSS/Atom URL（可选，优先级高于 source）' },
        limit: { type: 'number', description: '最多返回条数，默认 20' },
      },
      output: {
        schema: {
          type: 'object',
          properties: {
            source: { type: 'string' },
            count: { type: 'number' },
            items: { type: 'array', items: { type: 'object', additionalProperties: true } },
            error: { type: 'string' },
          },
          additionalProperties: false,
        },
        render: (_args: unknown, value: any) => {
          if (value.error) return [{ type: 'text', text: `[journal_scan] ${value.error}` }]
          const lines = (value.items || []).map(
            (it: any, i: number) => `${i + 1}. ${it.title}\n   ${it.link}\n   ${it.date || ''}`,
          )
          return [{ type: 'text', text: `[journal_scan] ${value.source} 抓到 ${value.count} 条\n\n${lines.join('\n')}` }]
        },
      },
      execute: async (args: any) => {
        const limit = args.limit && Number(args.limit) > 0 ? Number(args.limit) : 20
        const sources = allSources()
        try {
          if (args.sourceUrl) {
            const items = await fetchFeed(args.sourceUrl)
            return { source: args.sourceUrl, count: items.length, items: items.slice(0, limit) }
          }
          if (args.source) {
            const src = sources.find((s) => s.id === args.source)
            if (!src) return { error: `unknown source: ${args.source}（可用 ${sources.map((s) => s.id).join('、')}）` }
            const items = await fetchSource(src, limit)
            return { source: args.source, count: items.length, items: items.slice(0, limit) }
          }
          // 默认抓全部源（内置 + 自定义）
          const all: Array<Record<string, string>> = []
          for (const src of sources) {
            try {
              all.push(...(await fetchSource(src, Math.ceil(limit / sources.length))))
            } catch {
              // 单个源失败不阻断整体
            }
          }
          return { source: sources.map((s) => s.id).join(', '), count: all.length, items: all.slice(0, limit) }
        } catch (e) {
          return { error: `fetch failed: ${e instanceof Error ? e.message : String(e)}` }
        }
      },
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'journal_filter',
      description:
        '按关键词过滤论文条目（标题+摘要小写匹配）。keywords 为空则原样返回。示例：["did", "causal", "labor supply", "china"]。',
      parameters: {
        items: { type: 'array', required: true, description: 'journal_scan 返回的 items' },
        keywords: { type: 'array', required: true, description: '关键词列表，支持子串匹配' },
      },
      output: {
        schema: {
          type: 'object',
          properties: {
            total: { type: 'number' },
            matched: { type: 'number' },
            items: { type: 'array', items: { type: 'object', additionalProperties: true } },
          },
          additionalProperties: false,
        },
        render: (_args: unknown, value: any) => {
          const lines = (value.items || []).map((it: any, i: number) => `${i + 1}. ${it.title}\n   ${it.link}`)
          return [{ type: 'text', text: `[journal_filter] ${value.total} 条中命中 ${value.matched} 条\n\n${lines.join('\n')}` }]
        },
      },
      execute: async (args: any) => {
        const matched = filterItems(args.items || [], args.keywords || [])
        return { total: (args.items || []).length, matched: matched.length, items: matched }
      },
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'journal_push',
      description:
        '推送论文条目（去重后）。默认 dry-run 只记录不发送；配置环境变量 DSH_BARK_URL 或 DSH_FEISHU_URL 后真实推送。返回 pushed/skipped/dryRun。',
      parameters: {
        items: { type: 'array', required: true, description: '要推送的条目（建议先 journal_filter）' },
        dryRun: { type: 'boolean', description: '强制 dry-run（默认：无 webhook 时为 dry-run）' },
      },
      output: {
        schema: {
          type: 'object',
          properties: {
            pushed: { type: 'number' },
            skipped: { type: 'number' },
            dryRun: { type: 'boolean' },
            titles: { type: 'array', items: { type: 'string' } },
            error: { type: 'string' },
          },
          additionalProperties: false,
        },
        render: (_args: unknown, value: any) => {
          if (value.error) return [{ type: 'text', text: `[journal_push] ${value.error}` }]
          const mode = value.dryRun ? 'DRY-RUN（未发送）' : '已推送'
          return [
            {
              type: 'text',
              text: `[journal_push] ${mode}：新推送 ${value.pushed} 条，去重跳过 ${value.skipped} 条\n\n${(value.titles || []).join('\n')}`,
            },
          ]
        },
      },
      execute: async (args: any) => {
        try {
          const res = await push(args.items || [], {
            barkUrl: process.env.DSH_BARK_URL,
            feishuUrl: process.env.DSH_FEISHU_URL,
            dryRun: args.dryRun !== undefined ? !!args.dryRun : undefined,
          })
          return {
            pushed: res.pushed.length,
            skipped: res.skipped,
            dryRun: res.dryRun,
            titles: res.pushed.map((it) => it.title),
          }
        } catch (e) {
          return { error: `push failed: ${e instanceof Error ? e.message : String(e)}` }
        }
      },
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'journal_status',
      description: '查看监控状态：已推送记录数、最近 N 条标题（去重依据）。',
      parameters: {
        limit: { type: 'number', description: '最近几条，默认 10' },
      },
      output: {
        schema: {
          type: 'object',
          properties: {
            total: { type: 'number' },
            recent: { type: 'array', items: { type: 'object', additionalProperties: true } },
            stateFile: { type: 'string' },
          },
          additionalProperties: false,
        },
        render: (_args: unknown, value: any) => {
          const lines = (value.recent || []).map((r: any) => `- ${r.title} (${r.pushedAt})`)
          return [
            {
              type: 'text',
              text: `[journal_status] 已记录 ${value.total} 条\n${lines.join('\n')}\nstate: ${value.stateFile}`,
            },
          ]
        },
      },
      execute: async (args: any) => {
        const f = stateFile()
        const state = readState()
        const limit = args.limit && Number(args.limit) > 0 ? Number(args.limit) : 10
        const lines = existsSync(f) ? readFileSync(f, 'utf8').split('\n').filter(Boolean) : []
        const recent = lines
          .slice(-limit)
          .map((l) => {
            try {
              return JSON.parse(l)
            } catch {
              return null
            }
          })
          .filter(Boolean)
        return { total: state.size, recent, stateFile: f }
      },
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'journal_briefing',
      description:
        '生成定时经济文献简报的 schedule_create 参数 + 自包含监控提示词（复用内置 dsh-schedule 的 schedule_create）。返回 every_seconds + schedule_prompt，可据此建立每日/每周监控。',
      parameters: {
        topic: { type: 'string', required: true, description: '简报主题（如「数字化转型」「货币政策」）' },
        interval_days: { type: 'number', description: '监控间隔天数，默认 1' },
      },
      output: {
        schema: {
          type: 'object',
          properties: {
            every_seconds: { type: 'number' },
            schedule_prompt: { type: 'string' },
            sources: { type: 'array', items: { type: 'string' } },
          },
          additionalProperties: false,
        },
        render: (_args: unknown, value: any) => {
          return [
            {
              type: 'text',
              text: `调用 schedule_create(prompt=<下方提示词>, every_seconds=${value.every_seconds}) 即可建立监控。\n监控源：${(value.sources || []).join('、')}\n\n提示词：\n${value.schedule_prompt}`,
            },
          ]
        },
      },
      execute: async (args: any) => {
        const { every_seconds, schedule_prompt } = buildBriefing(args.topic, args.interval_days ?? 1)
        return { every_seconds, schedule_prompt, sources: allSources().map((s) => s.id) }
      },
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'journal_add_source',
      description:
        '注册自定义监控源（会话内有效，重启失效）。kind 支持 rss（RSS/Atom URL）/ arxiv（arXiv 类目 id）/ cn-toc（玛格泰克平台）/ ajcass（社科院平台）。示例：journal_add_source(id="my-econ-blog", url="https://example.com/feed.xml", kind="rss")',
      parameters: {
        id: { type: 'string', required: true, description: '源唯一 id（字母数字-_，2-40 字符）' },
        url: { type: 'string', description: '源 URL（arxiv 类目可省略）' },
        kind: { type: 'string', description: 'rss（默认）/ arxiv / cn-toc / ajcass' },
        label: { type: 'string', description: '显示名（默认用 id）' },
      },
      output: {
        schema: {
          type: 'object',
          properties: {
            ok: { type: 'boolean' },
            error: { type: 'string' },
            sources: { type: 'array', items: { type: 'string' } },
          },
          additionalProperties: false,
        },
        render: (_args: unknown, value: any) => {
          if (!value.ok) return [{ type: 'text', text: `[journal_add_source] 失败：${value.error}` }]
          return [{ type: 'text', text: `[journal_add_source] 已注册。当前源：${(value.sources || []).join('、')}` }]
        },
      },
      execute: async (args: any) => {
        const res = registerSource({ id: args.id, url: args.url, kind: args.kind, label: args.label })
        return res.ok
          ? { ok: true, sources: allSources().map((s) => s.id) }
          : { ok: false, error: res.error ?? 'unknown' }
      },
    }),
  )

  ctx.tools.register(
    defineTool({
      name: 'journal_list_sources',
      description: '列出全部监控源（内置 + 自定义），含 id/类型/URL。',
      parameters: {},
      output: {
        schema: {
          type: 'object',
          properties: {
            count: { type: 'number' },
            sources: { type: 'array', items: { type: 'object', additionalProperties: true } },
          },
          additionalProperties: false,
        },
        render: (_args: unknown, value: any) => {
          const lines = (value.sources || []).map((s: any) => `- ${s.id}（${s.kind ?? 'rss'}）${s.url ? ' ' + s.url : ''}`)
          return [{ type: 'text', text: `[journal_list_sources] 共 ${value.count} 个源\n${lines.join('\n')}` }]
        },
      },
      execute: async () => {
        return { count: allSources().length, sources: allSources().map((s) => ({ id: s.id, kind: s.kind ?? 'rss', url: s.url ?? '' })) }
      },
    }),
  )
}
