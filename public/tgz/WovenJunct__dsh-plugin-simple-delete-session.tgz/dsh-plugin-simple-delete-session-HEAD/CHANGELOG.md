# Changelog

All notable changes to this plugin are documented here.
Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) · versioning: [SemVer](https://semver.org/).

## [0.2.1] — 2026-10-06

Verified on DSH desktop **0.2.0-rc.2** (Windows).

### Fixed

- The session menu row now passes its glyph through `MenuItemButton`'s `icon` prop instead of as children. Children are wrapped whole in the label span, so the glyph previously lost the primitive's 14x14 optical box, the row's flex gap and the shared icon colour — the row sat tight against its text, oversized at 16px and baseline-aligned beside the shipped rows.
- The row is now destructive through the primitive's `danger` prop. The previous `style` object was silently discarded (`MenuItemButton` forwards no owner `style` to its button), so the promised red text, red icon and danger hover fill never rendered.
- The row uses the shipped 1px-stroke outline trash glyph (`IconTrashOutlineRegular`, with `IconTrashOutlineMedium` / `IconTrashOutline` as fallbacks) so its stroke weight matches the neighbouring rows; the inline filled glyph stays as the no-primitives fallback and is now 14px.

### Changed

- `verify/verify.mjs` now loads the browser half a second time with a `MenuItemButton` stand-in and asserts the row's contract: glyph in the `icon` seat, `danger: true`, no owner `style`, label as the only child. Both this guard and the label check fail against the pre-fix code.
- README install instructions now name the real repository (`github:WovenJunct/dsh-plugin-simple-delete-session`) instead of a placeholder user.

## [0.2.0] — 2026-09-30

Verified on DSH desktop **0.2.0-rc.1** (Windows).

### Added

- Sidebar session menu row **删除会话 / Delete session** (`sidebar.workspaces.session.menu.item`, `order: 900`).
- Two-step confirmation dialog in `shell.overlay`: title + session id, red irreversibility warning, mandatory acknowledgement checkbox, running-session warning and **Stop and delete** action.
- After deleting the session that is currently open, the shell navigates to the most recently used remaining session (or to the new-session empty state when none is left).
- zh/en copy that follows the client locale service.
- Zero-dependency self-check (`npm run verify`) covering the disk logic, the host delete orchestration and the browser half.

### Changed

- Hard delete now releases the live in-memory session through the store entry's own detach capability, so the sidebar row disappears immediately instead of after a restart.
- Hard delete also removes the session's persisted projection-cache row (`session_projcache`), which previously kept folded metadata such as the title on disk.
- The delete route is registered as soon as a web carrier exists (`ctx.inject`), so the browser half no longer receives the `/plugins` bundle route's 405.

### Fixed

- Cold (persistence-only) sessions no longer linger as an "Ungrouped" ghost row: the host broadcasts both `session/disposed` and `api-session/removed`.
- A log directory recreated by a lingering writer right after the unlink is detected and erased again.

## [0.1.0] — 2026-09-30

### Added

- First working version: menu row, confirmation dialog, host delete route and the ordered hard-delete chain (cancel running turn → `flush` → release `ctx.sessions` residency → detach from workspaces / archive / pin → remove the session's own log directory → re-scan verification → broadcast `session/disposed`).
- Sessions-root resolution through `ctx.configEditor` (`session-persistence-jsonl.root`), then `DSH_SESSIONS_ROOT`, then `DSH_HOME`/`sessions`.
