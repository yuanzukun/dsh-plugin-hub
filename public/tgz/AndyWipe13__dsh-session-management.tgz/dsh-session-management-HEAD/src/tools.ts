/**
 * Agent tools for dsh-session-management.
 *
 * These tools are deliberately thin: they parse/validate args, call the
 * SessionManagement service, and render the canonical result for the model.
 * No business logic lives here.
 */

import { defineTool } from '@deepseek-ai/dsh-tools'
import { SESSION_SOURCES } from './manifest.js'
import type {
  CleanupPreviewResult,
  CleanupReport,
  CleanupRule,
  ImportReport,
  ImportScanPageResult,
  SessionDeleteResult,
  SessionListFilter,
  SessionListItem,
  SessionManagementService,
  SessionStatsResult,
} from './service.js'

interface ToolContext {
  tools: {
    register(tool: unknown): () => void
  }
  on?(event: string, listener: (exec: unknown, next: () => unknown) => unknown): unknown
}

const sourceEnum = SESSION_SOURCES

/** Tools that permanently destroy sessions and always require user approval. */
const APPROVAL_REASONS: Partial<Record<string, (targets: string) => string>> = {
  delete_sessions: (targets) => `Permanently delete DSH session(s): ${targets}. This action cannot be undone.`,
  cleanup_sessions: (targets) => `Permanently delete ${targets} via cleanup. This action cannot be undone.`,
}

function formatList(items: readonly SessionListItem[], total: number): string {
  if (items.length === 0) return `No sessions found (total ${total}).`
  const lines = items.map((item) => {
    const flags = [
      item.running ? 'running' : '',
      item.archived ? 'archived' : '',
    ].filter(Boolean).join(',')
    const sizeMb = (item.sizeBytes / 1024 / 1024).toFixed(1)
    const snippet = item.snippet ? ` snippet="${item.snippet}"` : ''
    return `- ${item.title ?? item.id} [${item.source}] updated=${new Date(item.updatedAt).toISOString()} size=${sizeMb}MB messages=${item.messageCount}${flags ? ` (${flags})` : ''}${snippet}`
  })
  return `Found ${total} session(s):\n${lines.join('\n')}`
}

function formatPreview(value: Awaited<ReturnType<SessionManagementService['preview']>>): string {
  const lines = [
    `Session: ${value.title ?? value.id}`,
    `Source: ${value.source}`,
    `Path: ${value.cwd ?? '(none)'}`,
    `Created: ${new Date(value.createdAt).toISOString()}`,
    `Updated: ${new Date(value.updatedAt).toISOString()}`,
    `State: ${value.running ? 'running' : 'idle'}${value.archived ? ', archived' : ''}`,
    `Events: ${value.events.length}`,
  ]
  for (const event of value.events.slice(0, 100)) {
    const e = event as { type?: string; time?: number; data?: unknown }
    lines.push(`- [${e.type ?? 'event'}] ${JSON.stringify(e.data ?? '')}`)
  }
  return lines.join('\n')
}

function formatImportReport(report: ImportReport): string {
  const lines = [
    `Import complete: ${report.success} succeeded, ${report.skipped} skipped, ${report.failed} failed, ${report.reconciliationRequired} reconciliation required.`,
  ]
  for (const item of report.items) {
    const details = [
      item.path ?? item.sourceSessionId,
      item.status,
      item.dshSessionId ? `dsh=${item.dshSessionId}` : '',
      item.reason ?? '',
      item.badLines ? `badLines=${item.badLines}` : '',
    ].filter(Boolean)
    lines.push(`- ${details.join(' | ')}`)
  }
  return lines.join('\n')
}

function formatImportQueue(result: ImportScanPageResult): string {
  const lines = [
    `Import queue: ${result.total} candidate(s).`,
    `Scan id: ${result.scanId}`,
    ...result.items.map((item) => `- ${item.title ?? item.sourceSessionId} [${item.source}] id=${item.sourceSessionId}${item.importState ? ` (${item.importState}, dsh=${item.dshSessionId})` : ''}`),
  ]
  if (result.nextCursor) lines.push(`Next cursor: ${result.nextCursor}`)
  return lines.join('\n')
}

function formatDeleteResult(result: SessionDeleteResult): string {
  if (result.deletedSessionIds.length === 0) return 'No sessions deleted.'
  const lines = result.deletedSessionIds.map((id, index) => {
    const path = result.paths[index]
    return `- ${id}${path ? ` at ${path}` : ''}`
  })
  return `Deleted ${result.deletedSessionIds.length} session(s):\n${lines.join('\n')}`
}

function formatStats(stats: SessionStatsResult): string {
  const lines = [
    `Sessions: ${stats.totalSessions}`,
    `Total size: ${(stats.totalSizeBytes / 1024 / 1024).toFixed(2)} MB`,
    'By source:',
    ...stats.bySource.map((entry) => `- ${entry.source}: ${entry.count} session(s), ${(entry.totalSizeBytes / 1024 / 1024).toFixed(2)} MB`),
    '',
    'Per session:',
    ...stats.sessions.map((session) => {
      const flags = [
        session.running ? 'running' : '',
        session.archived ? 'archived' : '',
        session.blank ? 'blank' : '',
      ].filter(Boolean).join(',')
      return `- ${session.title ?? session.id} [${session.source}] updated=${new Date(session.updatedAt).toISOString()} size=${(session.sizeBytes / 1024 / 1024).toFixed(1)}MB messages=${session.messageCount} duration=${session.durationMs}ms tools=${session.toolCalls} (ok=${session.toolSuccess}, noResult=${session.toolNoResult})${flags ? ` (${flags})` : ''}`
    }),
  ]
  return lines.join('\n')
}

function formatCleanupPreview(preview: CleanupPreviewResult): string {
  const lines = [
    `Cleanup preview: ${preview.total} candidate(s), ${(preview.totalSizeBytes / 1024 / 1024).toFixed(2)} MB`,
    `Rules: olderThanDays=${preview.rules.olderThanDays}, largerThanMb=${preview.rules.largerThanMb}, emptySessions=${preview.rules.emptySessions}, archivedOnly=${preview.rules.archivedOnly}, source=${preview.rules.source}`,
    `Preview id: ${preview.previewId}`,
    ...preview.items.map((item) =>
      `- ${item.title ?? item.id} [${item.source}] size=${(item.sizeBytes / 1024 / 1024).toFixed(1)}MB updated=${new Date(item.updatedAt).toISOString()} matched=${item.matchedRules.join(',')}`),
  ]
  if (preview.excluded.length > 0) {
    lines.push('Excluded running sessions:')
    for (const item of preview.excluded) lines.push(`- ${item.title ?? item.sessionId}: ${item.reason}`)
  }
  return lines.join('\n')
}

function formatCleanupReport(report: CleanupReport): string {
  const lines = [
    `Cleanup complete: ${report.success} succeeded, ${report.failed} failed.`,
    ...report.items.map((item) => {
      const details = [
        item.sessionId,
        item.status,
        item.path ?? '',
        item.reason ?? '',
      ].filter(Boolean)
      return `- ${details.join(' | ')}`
    }),
  ]
  return lines.join('\n')
}

export function registerSessionTools(ctx: ToolContext, service: SessionManagementService): () => void {
  const disposers: Array<() => void> = []
  const register = (tool: unknown): void => {
    disposers.push(ctx.tools.register(tool))
  }
  // Tool literals carry domain result types that are JSON-serializable at
  // runtime but not provably `JsonValue`; this seam keeps that erasure in one
  // place instead of inside every tool definition.
  const define = (options: any) => defineTool(options)

  register(define({
    name: 'list_sessions',
    description: 'List DSH native and imported sessions with optional source, archive-state, workspace, and title query filters.',
    parameters: {
      source: {
        type: 'string',
        enum: [...sourceEnum],
        description: 'Filter by session source: dsh, claude-code, or codex.',
      },
      archived: {
        type: 'boolean',
        description: 'When true list only archived sessions; when false list only active sessions. Omit for all.',
      },
      cwd: {
        type: 'string',
        description: 'Exact working directory filter.',
      },
      workspace: {
        type: 'string',
        description: 'Workspace/project name or path substring filter.',
      },
      query: {
        type: 'string',
        description: 'Optional title substring filter.',
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: { items: readonly SessionListItem[]; total: number }) => [
        { type: 'text', text: formatList(value.items, value.total) },
      ],
    },
    async execute(args: SessionListFilter) {
      return service.list(args)
    },
  }))

  register(define({
    name: 'search_sessions',
    description: 'Search DSH native and imported sessions by conversation body text (user/assistant/tool messages) with snippets, or by title when full-text search is disabled, combined with optional filters.',
    parameters: {
      query: {
        type: 'string',
        description: 'Text to search for in conversation body or title (depending on full-text configuration).',
        required: true,
      },
      source: {
        type: 'string',
        enum: [...sourceEnum],
        description: 'Filter by session source: dsh, claude-code, or codex.',
      },
      archived: {
        type: 'boolean',
        description: 'When true list only archived sessions; when false list only active sessions. Omit for all.',
      },
      workspace: {
        type: 'string',
        description: 'Workspace/project name or path substring filter.',
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: { items: readonly SessionListItem[]; total: number }) => [
        { type: 'text', text: formatList(value.items, value.total) },
      ],
    },
    async execute(args: { query: string } & Omit<SessionListFilter, 'query'>) {
      return service.search(args.query, args)
    },
  }))

  register(define({
    name: 'session_stats',
    description: 'Show global session statistics (total sessions, total log size, per-source distribution) and per-session metrics (size, messages, duration, tool calls).',
    parameters: {},
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: SessionStatsResult) => [
        { type: 'text', text: formatStats(value) },
      ],
    },
    async execute() {
      return service.stats()
    },
  }))

  register(define({
    name: 'preview_session',
    description: 'Preview one DSH session history (title, metadata, and the official read-path event log).',
    parameters: {
      sessionId: {
        type: 'string',
        description: 'DSH session id to preview.',
        required: true,
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: Awaited<ReturnType<SessionManagementService['preview']>>) => [
        { type: 'text', text: formatPreview(value) },
      ],
    },
    async execute(args: { sessionId: string }) {
      return service.preview(args.sessionId)
    },
  }))

  register(define({
    name: 'archive_session',
    description: 'Archive one DSH session through the official workspace registry. Reversible; no approval required.',
    parameters: {
      sessionId: {
        type: 'string',
        description: 'DSH session id to archive.',
        required: true,
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: { sessionId: string; archived: boolean }) => [
        { type: 'text', text: `Archived session ${value.sessionId}.` },
      ],
    },
    async execute(args: { sessionId: string }) {
      await service.archive(args.sessionId)
      return { sessionId: args.sessionId, archived: true }
    },
  }))

  register(define({
    name: 'unarchive_session',
    description: 'Unarchive one DSH session through the internal workspace registry channel. Reversible; no approval required.',
    parameters: {
      sessionId: {
        type: 'string',
        description: 'DSH session id to unarchive.',
        required: true,
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: { sessionId: string; archived: boolean }) => [
        { type: 'text', text: `Unarchived session ${value.sessionId}.` },
      ],
    },
    async execute(args: { sessionId: string }) {
      await service.unarchive(args.sessionId)
      return { sessionId: args.sessionId, archived: false }
    },
  }))

  register(define({
    name: 'scan_import_queue',
    description: 'Scan one read-only Claude Code or Codex source and create a source-bound import queue snapshot.',
    parameters: {
      source: { type: 'string', enum: ['claude-code', 'codex'], required: true, description: 'Source to scan.' },
      root: { type: 'string', description: 'Optional source root; only accepted on the first page.' },
      workspace: { type: 'string', description: 'Optional workspace path filter.' },
      limit: { type: 'number', description: 'Page size from 1 to 100.' },
      cursor: { type: 'string', description: 'Cursor from the previous page.' },
      scanId: { type: 'string', description: 'Scan id from the first page; required for later pages.' },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: ImportScanPageResult) => [{ type: 'text', text: formatImportQueue(value) }],
    },
    async execute(args: { source: 'claude-code' | 'codex'; root?: string; workspace?: string; limit?: number; cursor?: string; scanId?: string }) {
      return service.scanPage(args.source, args)
    },
  }))

  register(define({
    name: 'import_sessions',
    description: 'Import selected Claude Code or Codex sessions into DSH as native sessions through the official seed path. Already imported sessions are skipped.',
    parameters: {
      source: {
        type: 'string',
        enum: ['claude-code', 'codex'],
        description: 'Source to import from. Defaults to claude-code.',
      },
      sourceSessionIds: {
        type: 'array',
        items: { type: 'string' },
        description: 'Session ids to import, from a prior scan of the source directory.',
        required: true,
      },
      scanId: {
        type: 'string',
        description: 'Source-bound scan id returned by scan_import_queue.',
        required: true,
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: ImportReport) => [
        { type: 'text', text: formatImportReport(value) },
      ],
    },
    async execute(args: { source?: 'claude-code' | 'codex'; sourceSessionIds: readonly string[]; scanId: string }) {
      const selections = args.sourceSessionIds.map((sourceSessionId) => ({ sourceSessionId }))
      return service.import(args.source ?? 'claude-code', args.scanId, selections)
    },
  }))

  register(define({
    name: 'delete_sessions',
    description: 'Permanently delete DSH sessions. Requires the exact token DELETE and official user approval; deleted session logs are removed and cannot be recovered.',
    parameters: {
      sessionIds: {
        type: 'array',
        items: { type: 'string' },
        description: 'DSH session ids to permanently delete.',
        required: true,
      },
      confirmToken: {
        type: 'string',
        description: 'Must equal DELETE to confirm permanent deletion.',
        required: true,
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: SessionDeleteResult) => [
        { type: 'text', text: formatDeleteResult(value) },
      ],
    },
    async execute(args: { sessionIds: readonly string[]; confirmToken: string }) {
      return service.deleteSessions(args.sessionIds, { confirmToken: args.confirmToken })
    },
  }))

  register(define({
    name: 'cleanup_preview_sessions',
    description: 'Preview sessions that match cleanup rules (age, size, empty, archive state, source). Returns a previewId and candidate list; no session is deleted in this step.',
    parameters: {
      olderThanDays: {
        type: 'number',
        description: 'Only sessions last active at least this many days ago. Defaults to plugin configuration (30).',
      },
      largerThanMb: {
        type: 'number',
        description: 'Only sessions with log size larger than this many MB. Defaults to plugin configuration (100).',
      },
      emptySessions: {
        type: 'boolean',
        description: 'Include sessions with no turn/start event. Defaults to plugin configuration (false).',
      },
      archivedOnly: {
        type: 'boolean',
        description: 'Only preview archived sessions. Defaults to plugin configuration (true).',
      },
      source: {
        type: 'string',
        enum: [...sourceEnum, 'all'],
        description: 'Restrict cleanup to one source or all DSH-side sources.',
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: CleanupPreviewResult) => [
        { type: 'text', text: formatCleanupPreview(value) },
      ],
    },
    async execute(args: Partial<CleanupRule> = {}) {
      return service.cleanupPreview(args)
    },
  }))

  register(define({
    name: 'cleanup_sessions',
    description: 'Execute a previously previewed cleanup. Requires the previewId from cleanup_preview_sessions, the exact token DELETE, and official user approval; deleted session logs are removed and cannot be recovered.',
    parameters: {
      previewId: {
        type: 'string',
        description: 'Preview id returned by cleanup_preview_sessions.',
        required: true,
      },
      sessionIds: {
        type: 'array',
        items: { type: 'string' },
        description: 'DSH session ids selected from the preview to permanently delete.',
        required: true,
      },
      confirmToken: {
        type: 'string',
        description: 'Must equal DELETE to confirm permanent cleanup.',
        required: true,
      },
    },
    output: {
      schema: { type: 'json' },
      render: (_args: unknown, value: CleanupReport) => [
        { type: 'text', text: formatCleanupReport(value) },
      ],
    },
    async execute(args: { previewId: string; sessionIds: readonly string[]; confirmToken: string }) {
      return service.cleanupExecute(args.sessionIds, {
        confirmToken: args.confirmToken,
        previewId: args.previewId,
      })
    },
  }))

  if (typeof ctx.on === 'function') {
    const disposeApproval = ctx.on('tools/pre-execute', async (exec: unknown, next: () => unknown) => {
      const execution = exec as { name?: string; arguments?: { sessionIds?: readonly string[] } } | undefined
      const approvalReason = execution?.name ? APPROVAL_REASONS[execution.name] : undefined
      if (approvalReason && execution) {
        const targets = execution.arguments?.sessionIds
        const targetText = targets && targets.length > 0 ? targets.join(', ') : 'unknown session(s)'
        return { kind: 'ask', reason: approvalReason(targetText) }
      }
      return next()
    })
    if (typeof disposeApproval === 'function') disposers.push(disposeApproval as () => void)
  }

  return () => {
    for (const dispose of disposers.splice(0)) dispose()
  }
}
