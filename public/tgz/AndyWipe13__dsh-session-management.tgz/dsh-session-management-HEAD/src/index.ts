/**
 * @nathan110628/dsh-session-management — 会话管理插件。
 *
 * Issue #3 落地读路径全栈：
 * - SessionManagement 服务面（list/search/preview）作为单一测试接缝；
 * - import manifest 存储单元（初始为空）用于来源反查；
 * - Agent 工具 list_sessions / search_sessions / preview_session / archive_session / unarchive_session；
 * - Host HTTP API 供设置页薄 UI 消费（client 半区见 client.js）。
 */
import { rm, stat } from 'node:fs/promises'
import path from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { openManifestStore } from './manifest.js'
import { createClaudeImportAdapter, resolveClaudeProjectsRoot } from './claude.js'
import { createCodexImportAdapter, resolveCodexHome } from './codex.js'
import { createSessionManagementService } from './service.js'
import { registerSessionTools } from './tools.js'
import { registerSessionApi } from './web.js'

export const name = '@nathan110628/dsh-session-management'
// webServer must be injected before `ctx.webServer` is reachable in apply().
export const inject = ['tools', 'sessions', 'agents', 'apiProxy', 'sessionQuery', 'sessionPersistence', 'workspaceRegistry', 'storageDomain', 'webServer']

export interface Config {
  /** Claude Code projects root. Empty means auto-detect `~/.claude/projects`. */
  claudePath?: string
  /** Codex home. Empty means auto-detect `~/.codex`. */
  codexPath?: string
  /**
   * Full-text search mode. `first-search` enables content search and builds
   * the SQLite index on the first search; `never` disables full-text indexing
   * and falls back to title-only search.
   */
  fullTextSearch?: 'first-search' | 'never'
  /** Default cleanup rule values used by the 清理与统计 tab and Agent tools. */
  cleanup?: {
    olderThanDays?: number
    largerThanMb?: number
    emptySessions?: boolean
    archivedOnly?: boolean
  }
}

export const Config = z.object({
  claudePath: z.string().default(''),
  codexPath: z.string().default(''),
  fullTextSearch: z.union(['first-search', 'never']).default('first-search'),
  cleanup: z.object({
    olderThanDays: z.number().default(30),
    largerThanMb: z.number().default(100),
    emptySessions: z.boolean().default(false),
    archivedOnly: z.boolean().default(true),
  }).default({
    olderThanDays: 30,
    largerThanMb: 100,
    emptySessions: false,
    archivedOnly: true,
  }),
})

export function apply(ctx: Context, config: Config): void {
  const services = ctx as unknown as {
    storageDomain: { open(spec: unknown): Promise<unknown> }
    tools: { register(tool: unknown): () => void }
    webServer?: {
      register(route: unknown): () => void
    }
    on?(event: string, listener: (exec: unknown, next: () => unknown) => unknown): unknown
  }

  const manifest = openManifestStore(services.storageDomain)
  const claudeRoot = resolveClaudeProjectsRoot(config.claudePath)
  const codexHome = resolveCodexHome(config.codexPath)
  const service = createSessionManagementService(ctx as never, manifest, {
    claudePath: claudeRoot,
    codexPath: codexHome,
    fullTextSearch: config.fullTextSearch ?? 'first-search',
    cleanup: config.cleanup,
    imports: [
      createClaudeImportAdapter(claudeRoot),
      createCodexImportAdapter(codexHome),
    ],
    sessionArtifactStat: async (file) => {
      const info = await stat(file)
      return { sizeBytes: info.size, mtimeMs: info.mtimeMs }
    },
    deleter: async (location) => {
      // The persistence locate() points at the session log file; the whole
      // session directory is the DSH-side artifact we remove.
      await rm(path.dirname(location.path), { recursive: true, force: true })
    },
  })

  ctx.effect(() => () => {
    void manifest.close()
  }, '@nathan110628/dsh-session-management: import manifest')

  ctx.effect(() => registerSessionTools(services, service), '@nathan110628/dsh-session-management: session tools')
  ctx.effect(() => registerSessionApi(services, service), '@nathan110628/dsh-session-management: settings api')
  void service.reconcileImports().catch((error) => {
    console.error('[dsh-session-management] import manifest reconciliation failed:', error)
  })
}
