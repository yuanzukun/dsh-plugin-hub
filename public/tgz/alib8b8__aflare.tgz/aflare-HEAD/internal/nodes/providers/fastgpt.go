// Copyright (c) 2026 aflare Contributors
//
// aflare‍​‌​​​​​‌​‌​​​‌‌​​‌​​‌‌​​​‌​‌​​‌​​​​​​​‌​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​‌‌​‌​‌​‌​​​‌​‌‌‌‌‌‌‌​​​​​​​‌‌​‌‌​​‌​​‌​​‌‌​‌​​‌​‌‌​‌​​‌‌‌‌​​​‌​‌‌​​‌‌​‌​​‌‌​​​‌​​​​​​​​​​​​​​​​‌‌​​‌​​‌‌‌​‌‌‌​​⁠
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

package providers

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"

	"github.com/alib8b8/aflare/internal/nodes/core"
)

type FastGPTNode struct{}

func init() {
	core.Register(&FastGPTNode{})
}

func (n *FastGPTNode) Name() string {
	return "fastgpt"
}

func (n *FastGPTNode) Description() string {
	return "Call FastGPT API"
}

func (n *FastGPTNode) Schema() core.NodeSchema {
	return core.NodeSchema{
		Name:        "fastgpt",
		Description: "Call FastGPT API",
		Input:       "string - user message content",
		Output:      "string - AI response content",
		Params: []core.ParamSchema{
			{Name: "api_key", Type: "string", Description: "FastGPT API key (or set FASTGPT_API_KEY env var)", Required: false},
			{Name: "app_id", Type: "string", Description: "FastGPT app ID", Required: false},
			{Name: "chat_id", Type: "string", Description: "Chat ID for conversation continuity", Required: false},
			{Name: "endpoint", Type: "string", Description: "API base URL (or set FASTGPT_BASE_URL env var)", Required: false, Default: "https://fastgpt.in/api/v1"},
			{Name: "system", Type: "string", Description: "System prompt", Required: false},
		},
	}
}

type fastGPTMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type fastGPTRequest struct {
	AppId    string           `json:"appId,omitempty"`
	ChatId   string           `json:"chatId,omitempty"`
	Messages []fastGPTMessage `json:"messages"`
	Stream   bool             `json:"stream"`
	Detail   bool             `json:"detail,omitempty"`
}

type fastGPTChoice struct {
	Message struct {
		Content string `json:"content"`
	} `json:"message"`
	Delta struct {
		Content string `json:"content"`
	} `json:"delta"`
}

type fastGPTResponse struct {
	Choices []fastGPTChoice `json:"choices"`
	Error   *struct {
		Message string `json:"message"`
	} `json:"error,omitempty"`
}

func (n *FastGPTNode) Execute(ctx context.Context, input string, params map[string]string) (string, error) {
	return n.execute(ctx, input, params, false, nil)
}

func (n *FastGPTNode) ExecuteStream(ctx context.Context, input string, params map[string]string, onChunk func(chunk string)) (string, error) {
	return n.execute(ctx, input, params, true, onChunk)
}

func (n *FastGPTNode) execute(ctx context.Context, input string, params map[string]string, stream bool, onChunk func(chunk string)) (string, error) {
	apiKey, ok := params["api_key"]
	if !ok || apiKey == "" {
		apiKey = os.Getenv("FASTGPT_API_KEY")
	}
	if apiKey == "" {
		return "", fmt.Errorf("FastGPT API key required. Set FASTGPT_API_KEY env var or pass api_key param")
	}

	appId, _ := params["app_id"]
	chatId, _ := params["chat_id"]

	endpoint, ok := params["endpoint"]
	if !ok || endpoint == "" {
		endpoint = os.Getenv("FASTGPT_BASE_URL")
	}
	if endpoint == "" {
		endpoint = "https://fastgpt.in/api/v1"
	}

	// Validate endpoint URL to prevent SSRF + API key leakage
	if err := core.ValidateLMLEndpoint(endpoint); err != nil {
		return "", fmt.Errorf("endpoint URL validation failed: %w", err)
	}

	generateURL := fmt.Sprintf("%s/chat/completions", endpoint)

	// Validate the full URL to prevent SSRF
	if err := core.ValidateLMLEndpoint(generateURL); err != nil {
		return "", fmt.Errorf("URL validation failed: %w", err)
	}

	systemPrompt, _ := params["system"]
	// Opt-in LLM 出口密钥脱敏（AFLARE_LLM_REDACT_SECRETS=1，默认关闭）。
	input, systemPrompt = core.MaybeRedactLLMSecrets("FastGPT", input, systemPrompt)
	messages := []fastGPTMessage{}
	if systemPrompt != "" {
		messages = append(messages, fastGPTMessage{Role: "system", Content: systemPrompt})
	}
	messages = append(messages, fastGPTMessage{Role: "user", Content: input})

	reqBody := fastGPTRequest{
		AppId:    appId,
		ChatId:   chatId,
		Messages: messages,
		Stream:   stream,
	}

	jsonBody, err := json.Marshal(reqBody)
	if err != nil {
		return "", fmt.Errorf("failed to marshal request: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, generateURL, bytes.NewBuffer(jsonBody))
	if err != nil {
		return "", fmt.Errorf("failed to create request: %w", err)
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+apiKey)

	client := &http.Client{
		Timeout:       core.DefaultLLMTimeout,
		Transport:     core.SafeLLMHTTPClient.Transport,
		CheckRedirect: core.HTTPRedirectValidator(core.ValidateLMLEndpoint),
	}

	resp, err := client.Do(req) // codeql[go/request-forgery] -- endpoint from node config/env, pre-validated twice by core.ValidateLMLEndpoint (endpoint and full generateURL); client uses core.SafeLLMHTTPClient.Transport (dial-time SSRF/IP validation, DNS-rebinding protection), core.HTTPRedirectValidator(core.ValidateLMLEndpoint) re-checks redirects, core.DefaultLLMTimeout; response capped by core.MaxHTTPResponseSize
	if err != nil {
		return "", fmt.Errorf("failed to call FastGPT API: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		var errResp fastGPTResponse
		_ = json.NewDecoder(io.LimitReader(resp.Body, core.MaxHTTPResponseSize)).Decode(&errResp)
		if errResp.Error != nil && errResp.Error.Message != "" {
			return "", fmt.Errorf("FastGPT API error (%d): %s", resp.StatusCode, errResp.Error.Message)
		}
		return "", fmt.Errorf("FastGPT API returned status %d", resp.StatusCode)
	}

	if stream {
		out, err := n.readStreamResponse(resp, onChunk)
		if err == nil {
			core.RecordOutbound(len(out))
		}
		return out, err
	}

	var fgResp fastGPTResponse
	if err := json.NewDecoder(resp.Body).Decode(&fgResp); err != nil {
		return "", fmt.Errorf("failed to parse FastGPT response: %w", err)
	}

	if len(fgResp.Choices) == 0 {
		return "", fmt.Errorf("no choices in FastGPT response")
	}

	core.RecordOutbound(len(fgResp.Choices[0].Message.Content))
	return fgResp.Choices[0].Message.Content, nil
}

func (n *FastGPTNode) readStreamResponse(resp *http.Response, onChunk func(chunk string)) (string, error) {
	scanner := bufio.NewScanner(resp.Body)
	var fullContent strings.Builder

	for scanner.Scan() {
		line := scanner.Text()
		if !strings.HasPrefix(line, "data: ") {
			continue
		}

		data := strings.TrimPrefix(line, "data: ")
		if data == "[DONE]" {
			break
		}

		var streamResp fastGPTResponse
		if err := json.Unmarshal([]byte(data), &streamResp); err != nil {
			continue
		}

		if len(streamResp.Choices) > 0 {
			chunk := streamResp.Choices[0].Delta.Content
			if chunk != "" {
				fullContent.WriteString(chunk)
				if onChunk != nil {
					onChunk(chunk)
				}
			}
		}
	}

	if err := scanner.Err(); err != nil {
		return fullContent.String(), fmt.Errorf("error reading stream: %w", err)
	}

	return fullContent.String(), nil
}
