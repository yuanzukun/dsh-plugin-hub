// Copyright (c) 2026 aflare Contributors
//
// aflare‍​‌​​​​​‌​‌​​​‌‌​​‌​​‌‌​​​‌​‌​​‌​​​​​​​‌​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​‌‌​‌​‌​‌​​​‌​‌‌‌‌‌‌‌​​​​​​​‌‌​‌​‌​‌​‌​​​​​​‌​​‌‌​​​‌​​​‌‌​‌‌​​‌​‌‌​​‌‌‌‌​​​‌​​​​​​​​​​​​​​​​​​​​​‌‌​​‌​​​​‌​​‌‌⁠
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

package nodes

import (
	"context"
	"fmt"
	"strconv"
	"strings"
	"time"
)

type SupervisorNode struct{}

func init() {
	Register(&SupervisorNode{})
}

func (n *SupervisorNode) Name() string {
	return "supervisor"
}

func (n *SupervisorNode) Description() string {
	return "Supervisor agent with MoE routing, MindSearch mode, and domain specialist delegation"
}

func (n *SupervisorNode) Schema() NodeSchema {
	params := []ParamSchema{
		{Name: "provider", Type: "string", Description: "LLM provider (default: ollama)", Required: false, Default: "ollama"},
		{Name: "model", Type: "string", Description: "Model name (default: llama3)", Required: false, Default: "llama3"},
		{Name: "api_key", Type: "string", Description: "API key for cloud providers", Required: false},
		{Name: "endpoint", Type: "string", Description: "API endpoint URL", Required: false},
	}
	params = append(params,
		ParamSchema{Name: "specialists", Type: "string", Description: "Comma-separated specialists. Persona roles: planner,researcher,critic,code_review,evaluator,reflector,legal_expert,medical_expert,educational_expert,financial_expert,creative_writer,data_analyst. Registered external agents: prefix with @ (e.g. @codex,@claude,@my-a2a-agent) for real delegation", Required: false, Default: "planner,researcher,critic,evaluator"},
		ParamSchema{Name: "max_parallel", Type: "string", Description: "Max concurrent external-agent delegations; excess subtasks queue (default: 4, max: 16)", Required: false, Default: "4"},
		ParamSchema{Name: "fail_on", Type: "string", Description: "Overall failure policy for delegated agents: none = never fail the node, failures stay isolated in the results (default); all = fail the node only if every delegation failed; any = fail the node if any delegation failed", Required: false, Default: "none"},
		ParamSchema{Name: "delegation_timeout", Type: "string", Description: "Per-delegation timeout for external agents, e.g. 30s, 10m (default: 10m, max: 60m). Agents failing repeatedly trip a per-agent circuit breaker: delegations fail fast with `circuit-open` instead of burning the full timeout, and recovery is probed via the agent card", Required: false},
		ParamSchema{Name: "strategy", Type: "string", Description: "Strategy: sequential, parallel, hierarchical, mindsearch, moe, agency, swarm (default: sequential)", Required: false, Default: "sequential"},
		ParamSchema{Name: "output_format", Type: "string", Description: "Output format: json, markdown, summary (default: json)", Required: false, Default: "json"},
		ParamSchema{Name: "domain", Type: "string", Description: "Domain specialization: general,legal,medical,education,finance,creative,tech,business (default: general)", Required: false, Default: "general"},
		ParamSchema{Name: "enable_moe", Type: "string", Description: "Enable Mixture-of-Experts routing (default: false)", Required: false, Default: "false"},
		ParamSchema{Name: "max_depth", Type: "string", Description: "Max decomposition depth for hierarchical/mindsearch (default: 3)", Required: false, Default: "3"},
		ParamSchema{Name: "subagent_prompts", Type: "string", Description: "Inject per-specialist subagent prompt templates into the supervisor context (default: true). Borrows Grok Build's main/subagent prompt hierarchy.", Required: false, Default: "true"},
		ParamSchema{Name: "collaboration_template", Type: "string", Description: "Collaboration template: software_development, product_design, data_science, marketing, research, legal_compliance, healthcare, education, finance, game_development, video_production, security_operations, cloud_infrastructure, content_creation, community_management, startup_acceleration, ai_development, design_system, event_management, translation_localization", Required: false},
		ParamSchema{Name: "template_role", Type: "string", Description: "Template role to use: team, workflow, review_cycle (default: team)", Required: false, Default: "team"},
	)
	return NodeSchema{
		Name:        "supervisor",
		Description: "Advanced supervisor with MoE routing, MindSearch deep research, 232+ domain specialists, and collaboration templates. External-agent delegations are checkpointed at (agent, subtask) granularity when the run uses --resume: a crashed supervisor step restores its finished delegations and re-dispatches only the unfinished ones (reported as `resumed` in the results envelope); without checkpointing the behavior is exactly one-shot",
		Input:       "string - the overall goal or task to supervise",
		Output:      "string - structured task plan with delegation and synthesis",
		Params:      params,
	}
}

func (n *SupervisorNode) Execute(ctx context.Context, input string, params map[string]string) (string, error) {
	provider := getParam(params, "provider", "ollama")
	model := getParam(params, "model", "llama3")
	apiKey := getParam(params, "api_key", "")
	endpoint := getParam(params, "endpoint", defaultEndpointFor(provider))
	specialists := getParam(params, "specialists", "planner,researcher,critic,evaluator")
	strategy := getParam(params, "strategy", "sequential")
	outputFormat := getParam(params, "output_format", "json")
	domain := getParam(params, "domain", "general")
	enableMoE := getParam(params, "enable_moe", "false") == "true"
	maxDepthStr := getParam(params, "max_depth", "3")
	collaborationTemplate := getParam(params, "collaboration_template", "")
	templateRole := getParam(params, "template_role", "team")

	maxDepth := 3
	if _, err := fmt.Sscanf(maxDepthStr, "%d", &maxDepth); err != nil {
		// keep default value on parse failure
	}
	if maxDepth < 1 {
		maxDepth = 1
	}
	if maxDepth > 10 {
		maxDepth = 10
	}

	// Delegation concurrency (backpressure): unparseable values fall
	// back to the default instead of failing the node.
	maxParallel := defaultDelegationParallelism
	if v, err := strconv.Atoi(strings.TrimSpace(getParam(params, "max_parallel", "4"))); err == nil {
		maxParallel = v
	}
	maxParallel = clampParallelism(maxParallel)

	// Delegation failure policy: unlike concurrency, a typo here must
	// not silently loosen a strict policy — invalid values fail the
	// node instead of degrading to "none".
	failOn := strings.TrimSpace(getParam(params, "fail_on", "none"))
	switch failOn {
	case "none", "all", "any":
	default:
		return "", fmt.Errorf("supervisor: invalid fail_on %q (valid: none, all, any)", failOn)
	}

	// Per-delegation timeout; 0 keeps the agentx default (10m).
	var delegationTimeout time.Duration
	if v := strings.TrimSpace(getParam(params, "delegation_timeout", "")); v != "" {
		d, err := time.ParseDuration(v)
		if err != nil || d <= 0 {
			return "", fmt.Errorf("supervisor: invalid delegation_timeout %q (e.g. 30s, 10m)", v)
		}
		delegationTimeout = d
	}
	delegationOpts := delegationOpts{maxParallel: maxParallel, failOn: failOn, timeout: delegationTimeout}

	if collaborationTemplate != "" {
		if template, ok := collaborationTemplates[collaborationTemplate]; ok {
			if roleSpecialists, ok := template[templateRole]; ok {
				specialists = strings.Join(roleSpecialists, ",")
			}
		}
	} else if preset, ok := domainSpecialistPresets[domain]; ok && specialists == "planner,researcher,critic,evaluator" {
		specialists = strings.Join(preset, ",")
	}

	specialistList := strings.Split(specialists, ",")
	for i := range specialistList {
		specialistList[i] = strings.TrimSpace(specialistList[i])
	}

	// Real delegation mode: specialists entries naming registered
	// external agents ("@codex", "@my-a2a-agent") are commanded and
	// supervised for real instead of being role-played by one LLM call.
	personas, agentRefs, err := parseAgentRefs(specialistList)
	if err != nil {
		return "", err
	}
	if len(agentRefs) > 0 {
		llm := func(ctx context.Context, systemPrompt, userInput string) (string, error) {
			return runAgentLLM(ctx, provider, model, apiKey, endpoint, systemPrompt, userInput)
		}
		if outputFormat != "json" {
			// Raw text mode: return only the synthesis so callers get a
			// direct answer, not the supervision envelope.
			results, _ := runDelegations(ctx, agentRefs, input, nil, delegationOpts)
			if err := delegationFailure(delegationOpts.failOn, results); err != nil {
				return "", err
			}
			return synthesizeResults(ctx, input, results, llm), nil
		}
		return delegateToAgents(ctx, agentRefs, input, llm, delegationOpts)
	}
	specialistList = personas

	specDescs := buildSpecialistDescriptions(specialistList)

	var systemPrompt string
	switch strategy {
	case "mindsearch":
		systemPrompt = buildMindSearchPrompt(specDescs, maxDepth)
	case "moe":
		systemPrompt = buildMoEPrompt(specDescs)
	case "parallel":
		systemPrompt = buildParallelPrompt(specDescs)
	case "hierarchical":
		systemPrompt = buildHierarchicalPrompt(specDescs, maxDepth)
	case "agency":
		systemPrompt = buildAgencyPrompt(specDescs)
	case "swarm":
		systemPrompt = buildSwarmPrompt(specDescs)
	default:
		systemPrompt = buildSequentialPrompt(specDescs)
	}

	if enableMoE && strategy != "moe" {
		systemPrompt += "\n\nAdditionally, use Mixture-of-Experts routing: when a subtask requires multiple expertise areas, assign it to multiple specialists and merge their results."
	}

	// 子智能体提示词分层：注入各 specialist 的行为边界模板（借鉴 Grok Build 主/子 Agent 架构）
	if getParam(params, "subagent_prompts", "true") != "false" {
		systemPrompt += RenderSubagentPromptForSpecialists(specialistList)
	}

	result, err := runAgentLLM(ctx, provider, model, apiKey, endpoint, systemPrompt, input)
	if err != nil {
		return "", fmt.Errorf("supervisor agent failed: %w", err)
	}

	if outputFormat == "json" {
		return cleanJSONResp(result), nil
	}

	return result, nil
}

func cleanJSONResp(response string) string {
	response = strings.TrimSpace(response)
	response = strings.TrimPrefix(response, "```json")
	response = strings.TrimPrefix(response, "```")
	response = strings.TrimSuffix(response, "```")
	response = strings.TrimSpace(response)
	return response
}
