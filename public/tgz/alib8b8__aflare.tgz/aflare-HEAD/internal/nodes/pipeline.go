// Copyright (c) 2026 aflare Contributors
//
// aflare‍​‌​​​​​‌​‌​​​‌‌​​‌​​‌‌​​​‌​‌​​‌​​​​​​​‌​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​‌‌​‌​‌​‌​​​‌​‌‌‌‌‌‌‌​​​​​​​‌‌​‌​​‌‌‌‌‌‌‌​​‌‌‌​‌‌​​​‌​​‌​‌‌​​​​​​‌​‌‌‌​‌​​​‌‌‌‌‌​​​​​​​​​​​​​​​​‌‌‌‌‌‌​‌​‌‌‌​​‌‌⁠
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published
// by the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

package nodes

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime/debug"
	"strings"
	"sync"
	"time"

	"github.com/alib8b8/aflare/internal/logger"
	"gopkg.in/yaml.v3"
)

type PipelineStep struct {
	Name      string            `json:"name" yaml:"name"`
	Node      string            `json:"node" yaml:"node"`
	Input     string            `json:"input,omitempty" yaml:"input,omitempty"`
	Params    map[string]string `json:"params,omitempty" yaml:"params,omitempty"`
	DependsOn []string          `json:"depends_on,omitempty" yaml:"depends_on,omitempty"`
	InputFrom []string          `json:"input_from,omitempty" yaml:"input_from,omitempty"`
}

type PipelineConfig struct {
	Steps          []PipelineStep `json:"steps" yaml:"steps"`
	TimeoutSeconds int            `json:"timeout_seconds,omitempty" yaml:"timeout_seconds,omitempty"`
}

type PipelineStepResult struct {
	Name     string        `json:"name"`
	Node     string        `json:"node"`
	Output   string        `json:"output"`
	Error    string        `json:"error,omitempty"`
	Skipped  bool          `json:"skipped,omitempty"`
	Duration time.Duration `json:"duration_ms"`
	Started  time.Time     `json:"started_at"`
	Finished time.Time     `json:"finished_at"`
}

type PipelineResult struct {
	Success bool                 `json:"success"`
	Results []PipelineStepResult `json:"results"`
	TotalMs int64                `json:"total_duration_ms"`
	Errors  []string             `json:"errors,omitempty"`
}

type PipelineNode struct{}

func init() {
	Register(&PipelineNode{})
}

func (n *PipelineNode) Name() string {
	return "pipeline"
}

func (n *PipelineNode) Description() string {
	return "Execute steps with dependency-based parallel scheduling (no-barrier, Tunix-inspired)"
}

func (n *PipelineNode) Schema() NodeSchema {
	return NodeSchema{
		Name:        "pipeline",
		Description: "Dependency-based parallel workflow executor: steps run as soon as their dependencies are met, no global barriers (Tunix-inspired async rollout)",
		Input:       "string - YAML or JSON pipeline configuration with steps and dependencies. Step fields: name, node, input, params, depends_on (list), input_from (list). If a step fails, all transitive downstream steps are cascade-skipped (results carry skipped: true); independent branches still run",
		Output:      "string - JSON with execution results, timings, and errors; skipped steps appear with skipped: true and error \"skipped: upstream step ... failed\"",
		Params: []ParamSchema{
			{Name: "timeout", Type: "string", Description: "Timeout in seconds (default: 300)", Required: false, Default: "300"},
			{Name: "format", Type: "string", Description: "Input format: json|yaml|auto (default: auto)", Required: false, Default: "auto"},
		},
	}
}

func (n *PipelineNode) Execute(ctx context.Context, input string, params map[string]string) (string, error) {
	if strings.TrimSpace(input) == "" {
		return "", fmt.Errorf("pipeline configuration required")
	}

	timeoutStr := getParam(params, "timeout", "300")
	timeoutSeconds := 300
	if _, err := fmt.Sscanf(timeoutStr, "%d", &timeoutSeconds); err != nil {
		// keep default value on parse failure
	}

	config, err := parsePipelineConfig(input, getParam(params, "format", "auto"))
	if err != nil {
		return "", fmt.Errorf("failed to parse pipeline config: %w", err)
	}

	if len(config.Steps) == 0 {
		return "", fmt.Errorf("pipeline has no steps")
	}

	if config.TimeoutSeconds > 0 {
		timeoutSeconds = config.TimeoutSeconds
	}

	reg := GetGlobalRegistry()

	pipelineCtx, cancel := context.WithTimeout(ctx, time.Duration(timeoutSeconds)*time.Second)
	defer cancel()

	return runPipeline(pipelineCtx, config, timeoutSeconds, reg)
}

// parsePipelineConfig parses a pipeline configuration in JSON or YAML.
// format is the documented `format` param: "auto" (default) sniffs the
// payload — a `{`/`[` prefix means JSON, anything else is tried as YAML —
// while "json" and "yaml" force their parser for precise error messages.
// An unrecognized format value fails fast instead of being ignored
// (previously the param was documented but never read, and non-JSON input
// always died with "unsupported format, use JSON").
func parsePipelineConfig(input string, format string) (PipelineConfig, error) {
	input = strings.TrimSpace(input)

	parseJSON := func() (PipelineConfig, error) {
		var config PipelineConfig
		if err := json.Unmarshal([]byte(input), &config); err != nil {
			return PipelineConfig{}, fmt.Errorf("invalid JSON: %w", err)
		}
		return config, nil
	}
	parseYAML := func() (PipelineConfig, error) {
		var config PipelineConfig
		if err := yaml.Unmarshal([]byte(input), &config); err != nil {
			return PipelineConfig{}, fmt.Errorf("invalid YAML: %w", err)
		}
		return config, nil
	}

	switch strings.ToLower(strings.TrimSpace(format)) {
	case "", "auto":
		if strings.HasPrefix(input, "{") || strings.HasPrefix(input, "[") {
			return parseJSON()
		}
		return parseYAML()
	case "json":
		return parseJSON()
	case "yaml", "yml":
		return parseYAML()
	default:
		return PipelineConfig{}, fmt.Errorf("invalid format %q (supported: json, yaml, auto)", format)
	}
}

func runPipeline(ctx context.Context, config PipelineConfig, timeoutSeconds int, reg *Registry) (string, error) {
	startTime := time.Now()

	stepMap := make(map[string]*PipelineStep)
	for i := range config.Steps {
		s := &config.Steps[i]
		if s.Name == "" {
			s.Name = fmt.Sprintf("step_%d", i)
		}
		stepMap[s.Name] = s
	}

	for name, s := range stepMap {
		for _, dep := range s.DependsOn {
			if _, ok := stepMap[dep]; !ok {
				return "", fmt.Errorf("step %q depends on unknown step %q", name, dep)
			}
		}
	}

	results := make(map[string]*PipelineStepResult)
	resultsMu := sync.Mutex{}

	completed := make(map[string]bool)
	completedMu := sync.Mutex{}

	var wg sync.WaitGroup
	started := make(map[string]bool)
	startedMu := sync.Mutex{}

	var allErrors []string
	errorsMu := sync.Mutex{}

	tryStart := func() bool {
		startedMu.Lock()
		completedMu.Lock()

		now := time.Now()
		var toStart []*PipelineStep
		var toSkip []*PipelineStepResult
		for name, step := range stepMap {
			if started[name] || completed[name] {
				continue
			}

			depsMet := true
			badDep := ""
			for _, dep := range step.DependsOn {
				if !completed[dep] {
					depsMet = false
					break
				}
				// completed[dep] is set only after results[dep] is
				// written, so the result (if any) is visible here.
				resultsMu.Lock()
				r, ok := results[dep]
				resultsMu.Unlock()
				if ok && r.Error != "" {
					badDep = dep
					break
				}
			}

			if badDep != "" {
				// Upstream failed (or was itself cascade-skipped):
				// skip this step instead of running it on missing
				// input. Marked completed so the dispatcher makes
				// progress; the skip result is written under the
				// same lock section so later steps in THIS pass see
				// it and cascade correctly.
				skip := &PipelineStepResult{
					Name:     name,
					Node:     step.Node,
					Error:    fmt.Sprintf("skipped: upstream step %q failed", badDep),
					Skipped:  true,
					Started:  now,
					Finished: now,
				}
				started[name] = true
				completed[name] = true
				resultsMu.Lock()
				results[name] = skip
				resultsMu.Unlock()
				toSkip = append(toSkip, skip)
				continue
			}

			if depsMet {
				started[name] = true
				toStart = append(toStart, step)
			}
		}

		completedMu.Unlock()
		startedMu.Unlock()

		for _, r := range toSkip {
			logger.Info("pipeline step skipped: upstream failed", "step", r.Name, "node", r.Node)
		}

		for _, step := range toStart {
			wg.Add(1)
			go func(s *PipelineStep) {
				defer wg.Done()
				executePipelineStep(ctx, s, reg, results, &resultsMu, completed, &completedMu, &allErrors, &errorsMu)
			}(step)
		}

		return len(toStart) > 0 || len(toSkip) > 0
	}

	done := make(chan bool)
	go func() {
		defer func() {
			if r := recover(); r != nil {
				logger.Error("pipeline dispatcher panicked",
					"panic", r,
					"stack", string(debug.Stack()),
				)
			}
		}()
		for {
			select {
			case <-ctx.Done():
				return
			default:
			}

			startedMu.Lock()
			completedMu.Lock()
			totalRunning := len(started) - len(completed)
			allDone := len(completed) == len(stepMap)
			startedMu.Unlock()
			completedMu.Unlock()

			if allDone {
				close(done)
				return
			}

			startedAny := tryStart()
			if !startedAny && totalRunning == 0 {
				completedMu.Lock()
				remaining := len(stepMap) - len(completed)
				completedMu.Unlock()
				if remaining > 0 {
					errorsMu.Lock()
					allErrors = append(allErrors, fmt.Sprintf("deadlock: %d steps cannot start due to unmet dependencies", remaining))
					errorsMu.Unlock()
				}
				close(done)
				return
			}

			time.Sleep(10 * time.Millisecond)
		}
	}()

	select {
	case <-done:
	case <-ctx.Done():
		errorsMu.Lock()
		allErrors = append(allErrors, fmt.Sprintf("pipeline timeout after %d seconds", timeoutSeconds))
		errorsMu.Unlock()
	}

	wg.Wait()

	orderedResults := make([]PipelineStepResult, 0, len(config.Steps))
	for _, s := range config.Steps {
		resultsMu.Lock()
		if r, ok := results[s.Name]; ok {
			orderedResults = append(orderedResults, *r)
		}
		resultsMu.Unlock()
	}

	pipelineResult := PipelineResult{
		Success: len(allErrors) == 0,
		Results: orderedResults,
		TotalMs: time.Since(startTime).Milliseconds(),
		Errors:  allErrors,
	}

	output, err := json.MarshalIndent(pipelineResult, "", "  ")
	if err != nil {
		return "", fmt.Errorf("failed to marshal result: %w", err)
	}

	return string(output), nil
}

func executePipelineStep(
	ctx context.Context,
	s *PipelineStep,
	reg *Registry,
	results map[string]*PipelineStepResult,
	resultsMu *sync.Mutex,
	completed map[string]bool,
	completedMu *sync.Mutex,
	allErrors *[]string,
	errorsMu *sync.Mutex,
) {
	defer func() {
		if r := recover(); r != nil {
			logger.Error("pipeline step panicked",
				"step", s.Name,
				"node", s.Node,
				"panic", r,
				"stack", string(debug.Stack()),
			)
			// Ensure the step is marked as completed so the
			// dispatcher does not deadlock waiting on it.
			resultsMu.Lock()
			if _, ok := results[s.Name]; !ok {
				now := time.Now()
				results[s.Name] = &PipelineStepResult{
					Name:     s.Name,
					Node:     s.Node,
					Error:    fmt.Sprintf("panic: %v", r),
					Started:  now,
					Finished: now,
				}
			}
			resultsMu.Unlock()
			errorsMu.Lock()
			*allErrors = append(*allErrors, fmt.Sprintf("%s: panic: %v", s.Name, r))
			errorsMu.Unlock()
			completedMu.Lock()
			completed[s.Name] = true
			completedMu.Unlock()
		}
	}()

	stepStart := time.Now()
	result := &PipelineStepResult{
		Name:    s.Name,
		Node:    s.Node,
		Started: stepStart,
	}

	node, ok := reg.Get(s.Node)
	if !ok {
		result.Error = fmt.Sprintf("node %q not found", s.Node)
		result.Finished = time.Now()
		result.Duration = result.Finished.Sub(result.Started)
		resultsMu.Lock()
		results[s.Name] = result
		resultsMu.Unlock()
		errorsMu.Lock()
		*allErrors = append(*allErrors, fmt.Sprintf("%s: %s", s.Name, result.Error))
		errorsMu.Unlock()
		completedMu.Lock()
		completed[s.Name] = true
		completedMu.Unlock()
		return
	}

	stepInput := s.Input
	if len(s.InputFrom) > 0 {
		var parts []string
		for _, src := range s.InputFrom {
			resultsMu.Lock()
			if r, ok := results[src]; ok && r.Error == "" {
				parts = append(parts, r.Output)
			}
			resultsMu.Unlock()
		}
		if stepInput == "" {
			stepInput = strings.Join(parts, "\n\n")
		}
	}

	stepParams := make(map[string]string)
	for k, v := range s.Params {
		stepParams[k] = v
	}

	output, execErr := node.Execute(ctx, stepInput, stepParams)
	if execErr != nil {
		result.Error = execErr.Error()
		errorsMu.Lock()
		*allErrors = append(*allErrors, fmt.Sprintf("%s: %s", s.Name, execErr.Error()))
		errorsMu.Unlock()
	} else {
		result.Output = output
	}

	result.Finished = time.Now()
	result.Duration = result.Finished.Sub(result.Started)

	resultsMu.Lock()
	results[s.Name] = result
	resultsMu.Unlock()

	completedMu.Lock()
	completed[s.Name] = true
	completedMu.Unlock()
}
