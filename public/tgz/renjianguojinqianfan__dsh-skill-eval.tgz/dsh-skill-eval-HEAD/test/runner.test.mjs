import assert from 'node:assert/strict'
import { fileURLToPath } from 'node:url'
import test from 'node:test'

import { runEvaluation } from '../runner.js'

const TEST_FILE = fileURLToPath(new URL('../examples/dsh-plugin-eval-smoke.json', import.meta.url))

function textStream(text, reason = { kind: 'stop' }) {
  return (async function* () {
    yield { type: 'block-start', index: 0, blockType: 'text' }
    yield { type: 'text-delta', index: 0, text }
    yield { type: 'block-end', index: 0, block: { type: 'text', text } }
    yield { type: 'finish', reason }
  })()
}

function makeCtx(stream) {
  return {
    skills: {
      snapshot: async () => ({
        skills: [{
          name: 'dsh-plugin-writing',
          description: 'Write & test <DSH> plugins',
          invocation: { modelInvocable: true },
        }],
      }),
    },
    llm: { stream },
  }
}

test('runner judges all smoke cases against the mock skill catalog', async () => {
  const ctx = makeCtx(() => textStream('YES'))
  const result = await runEvaluation({
    ctx,
    config: { provider: 'mock', model: 'mock-model', maxTokens: 64 },
    skillName: 'dsh-plugin-writing',
    testFile: TEST_FILE,
  })

  assert.equal(result.cases.length, 3)
  assert.equal(result.metrics.total, 3)
  assert.equal(result.metrics.accuracy, 2 / 3)
  assert.equal(result.metrics.confusion.TP, 2)
  assert.equal(result.metrics.confusion.FP, 1)
  assert.equal(result.metrics.confusion.TN, 0)
  assert.ok(result.cases.every((entry) => entry.actual === true))
})

test('runner reports missing target skill', async () => {
  const ctx = makeCtx(() => textStream('YES'))
  ctx.skills.snapshot = async () => ({ skills: [] })
  await assert.rejects(
    runEvaluation({
      ctx,
      config: { provider: 'mock', model: 'mock-model', maxTokens: 64 },
      skillName: 'missing-skill',
      testFile: TEST_FILE,
    }),
    /skill "missing-skill" not found among model-invocable skills/,
  )
})

test('runner surfaces a judge stream error', async () => {
  const ctx = makeCtx(() => textStream('', { kind: 'error', failure: { code: 'X', message: 'boom' } }))
  await assert.rejects(
    runEvaluation({
      ctx,
      config: { provider: 'mock', model: 'mock-model', maxTokens: 64 },
      skillName: 'dsh-plugin-writing',
      testFile: TEST_FILE,
    }),
    /judge LLM call failed \(finish=error\)/,
  )
})
