import assert from 'node:assert/strict'
import test from 'node:test'

import { apply } from '../index.js'

function makeLogger() {
  const logger = Object.assign((name) => logger, {
    warn() {},
  })
  return logger
}

function makeCtx(providers = [{ id: 'deepseek' }]) {
  const registrations = { tools: [], commands: [] }
  const ctx = {
    tools: {
      register(definition) {
        registrations.tools.push(definition)
      },
    },
    commands: {
      register(definition) {
        registrations.commands.push(definition)
      },
    },
    llm: {
      listProviders() {
        return providers
      },
    },
    logger: makeLogger(),
  }
  return { ctx, registrations }
}

test('apply throws when judge provider or model is missing', () => {
  const { ctx } = makeCtx()
  assert.throws(() => apply(ctx, {}), /judge provider and model must be configured/)
  assert.throws(() => apply(ctx, { provider: 'deepseek' }), /judge provider and model must be configured/)
})

test('apply registers the model tool and slash command', () => {
  const { ctx, registrations } = makeCtx()
  apply(ctx, { provider: 'deepseek', model: 'deepseek-chat' })

  const tool = registrations.tools.find((definition) => definition.name === 'run_skill_eval')
  assert.ok(tool, 'run_skill_eval tool is registered')
  assert.deepEqual(tool.parameters.required, ['skill_name'])
  assert.equal(tool.output.schema.type, 'string')
  assert.deepEqual(tool.output.render(null, '# report'), [{ type: 'text', text: '# report' }])

  const command = registrations.commands.find((definition) => definition.name === 'skill-eval')
  assert.ok(command, 'skill-eval command is registered')
  assert.equal(command.input.hint, '<skill-name> [test-file]')
})

test('slash command returns usage error for empty input', async () => {
  const { ctx, registrations } = makeCtx()
  apply(ctx, { provider: 'deepseek', model: 'deepseek-chat' })
  const command = registrations.commands.find((definition) => definition.name === 'skill-eval')
  const result = await command.handler({ rawInput: '' })
  assert.equal(result.kind, 'error')
  assert.match(result.text, /^Usage: \/skill-eval <skill-name> \[test-file\]$/)
})
