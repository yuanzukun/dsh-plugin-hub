import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

import { renderCatalogMessage } from '../catalog.js'

const FIXTURE_URL = new URL('./fixtures/dsh-tool-skill-catalog-0.1.0-rc.6.txt', import.meta.url)
const ENTRIES_URL = new URL('./fixtures/canonical-entries.json', import.meta.url)

test('catalog template matches pinned official dsh-tool-skill 0.1.0-rc.6', async () => {
  const fixture = (await readFile(FIXTURE_URL, 'utf8')).replace(/\r?\n$/, '')
  const entries = JSON.parse(await readFile(ENTRIES_URL, 'utf8'))
  assert.equal(renderCatalogMessage(entries), fixture)
})

test('catalog fixture still carries the official guardrails', async () => {
  const fixture = await readFile(FIXTURE_URL, 'utf8')
  assert.match(fixture, /<system-reminder>/)
  assert.match(fixture, /<available_skills>/)
  assert.match(fixture, /call the `skill` tool/)
})
