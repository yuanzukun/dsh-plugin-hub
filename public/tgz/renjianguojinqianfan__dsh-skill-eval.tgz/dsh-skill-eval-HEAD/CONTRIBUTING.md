# Contributing

## 硬约束

- 纯 JS / ESM，无构建步骤。
- **零 `@deepseek-ai` 运行时依赖**：不要给 `package.json` 增加任何
  `@deepseek-ai/*` 依赖；catalog 保真比对使用本地 fixture。
- 不修改 `package.json` 的 `dsh.bundle.patch` 指向。
- 提交前按原子提交拆分，并自查 `git diff --check`。

## 开发环境

- Node.js >= 20
- pnpm（用于 DSH 挂载）
- DSH CLI（`dsh`，本地验证用）

## 常用验证

```bash
npm run check      # 全部 JS 语法检查
npm test           # node:test：catalog 保真 + apply/runner mock 行为测试
npm run smoke      # 51 条纯函数冒烟
npm pack --dry-run # 发布包文件清单
bash scripts/mount-smoke.sh  # scratch DSH_HOME 真实挂载冒烟
```

## 更新 catalog fixture

升级 DSH 版本后，从本机安装的官方包重新生成 fixture，并 review diff：

```bash
node scripts/refresh-catalog-fixture.mjs \
  <path-to-@deepseek-ai/dsh-tool-skill/lib/index.js>
```

如果 fixture 文本发生变化，说明官方 catalog 提示词已变；需要同步确认
`catalog.js` 是否需要修改，再提交。

## 发布前检查

- [ ] `npm run check`、`npm test`、`npm run smoke` 全部通过
- [ ] `npm pack --dry-run` 包含全部运行时文件
- [ ] tarball 安装后 `import('dsh-skill-eval')` 成功
- [ ] scratch DSH 挂载启动无错误
- [ ] `CHANGELOG.md` 已更新

## 提交风格

使用语义化提交前缀，例如：

- `feat:` 新功能
- `fix:` 缺陷修复
- `test:` 测试与评测用例
- `ci:` 工作流与自动化
- `docs:` 文档
- `chore:` 基础元数据与维护
