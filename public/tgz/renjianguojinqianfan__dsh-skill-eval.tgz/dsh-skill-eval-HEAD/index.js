import { runEvaluation } from './runner.js'
import { formatReport } from './metrics.js'

export const name = 'skill-eval'

export const inject = ['tools', 'llm', 'skills', 'commands']

export function apply(ctx, config = {}) {
  const provider = config.provider
  const model = config.model
  const maxTokens = config.maxTokens ?? 64
  const maxCases = config.maxCases
  const catalogDescriptionMaxLength = config.catalogDescriptionMaxLength ?? 500

  // ── validate config at apply time ────────────────────────────────────
  if (!provider || !model) {
    throw new Error(
      'skill-eval: judge provider and model must be configured.\n' +
      'Add to your profile/overlay cordis.patch.yml:\n' +
      '  - id: skill-eval\n' +
      '    config:\n' +
      '      provider: <provider-id>\n' +
      '      model: <model-name>'
    )
  }
  // Verify provider is registered (warn only — the adapter may register late)
  const providers = ctx.llm.listProviders()
  if (!providers.find((p) => p.id === provider)) {
    ctx.logger?.('skill-eval')?.warn?.(`provider "${provider}" is not in the LLM provider list: ${providers.map(p => p.id).join(', ')}`)
  }

  // ── shared evaluation helper used by both tool and command ────────────
  async function evaluate({ skillName, testFile, signal, agent }) {
    const result = await runEvaluation({
      ctx,
      config: { provider, model, maxTokens, maxCases, catalogDescriptionMaxLength },
      skillName,
      testFile,
      signal,
      agent,
    })
    return formatReport(result)
  }

  // ── register tool: run_skill_eval (model-callable) ────────────────────
  ctx.tools.register({
    name: 'run_skill_eval',
    description: 'Run a skill-trigger evaluation: given a skill name, the judge LLM checks each test query against the skill catalog and reports accuracy, precision, recall, and confusion matrix.',
    parameters: {
      type: 'object',
      properties: {
        skill_name: { type: 'string', description: 'The exact skill name to evaluate.' },
        test_file: { type: 'string', description: 'Path to the test-case JSON file (defaults to examples/dsh-plugin-eval.json).' },
      },
      required: ['skill_name'],
    },
    output: {
      schema: { type: 'string' },
      render(_a, value) { return [{ type: 'text', text: value }] },
    },
    async execute(args, exec) {
      const signal = exec.signal
      const agent = exec.agent ?? undefined
      return await evaluate({
        skillName: args.skill_name,
        testFile: args.test_file,
        signal,
        agent,
      })
    },
  })

  // ── register slash command: /skill-eval (user-callable) ───────────────
  ctx.commands.register({
    name: 'skill-eval',
    description: 'Run skill-trigger evaluation on a skill',
    input: { hint: '<skill-name> [test-file]' },
    async handler(invocation) {
      const raw = (invocation.rawInput || '').trim()
      const parts = raw.split(/\s+/)
      const skillName = parts[0]
      if (!skillName) {
        return { kind: 'error', text: 'Usage: /skill-eval <skill-name> [test-file]' }
      }
      const testFile = parts.length > 1 ? parts.slice(1).join(' ') : undefined
      try {
        const report = await evaluate({
          skillName,
          testFile,
          signal: invocation.signal,
          agent: invocation.agent,
        })
        return { kind: 'success', text: report }
      } catch (e) {
        return { kind: 'error', text: `skill-eval: ${e.message}` }
      }
    },
  })
}