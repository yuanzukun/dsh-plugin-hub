/**
 * Accumulate the confusion matrix and derive all metrics from per-case results.
 * @param {import('./types.js').SkillEvalCaseResult[]} cases
 * @returns {import('./types.js').SkillEvalMetrics}
 */
export function computeMetrics(cases) {
  let TP = 0
  let FP = 0
  let FN = 0
  let TN = 0
  for (const c of cases) {
    if (c.expected && c.actual) TP++
    else if (!c.expected && c.actual) FP++
    else if (c.expected && !c.actual) FN++
    else TN++
  }
  const total = cases.length
  const correct = TP + TN
  const safe = (numerator, denominator) => (denominator === 0 ? 0 : numerator / denominator)
  const precision = safe(TP, TP + FP)
  const recall = safe(TP, TP + FN)
  return {
    accuracy: safe(correct, total),
    precision,
    recall,
    false_positive_rate: safe(FP, FP + TN),
    false_negative_rate: safe(FN, TP + FN),
    f1: safe(2 * precision * recall, precision + recall),
    confusion: { TP, FP, FN, TN },
    total,
    correct,
  }
}

/**
 * Render a full markdown report: headline metrics, confusion matrix, per-case table.
 * @param {import('./types.js').SkillEvalResult} result
 * @returns {string}
 */
export function formatReport(result) {
  const m = result.metrics
  const pct = (n) => `${(n * 100).toFixed(1)}%`
  const lines = []
  lines.push(`## Skill trigger evaluation: \`${result.skill_name}\``)
  lines.push('')
  lines.push(`Total: ${m.total} | Correct: ${m.correct} | Accuracy: ${pct(m.accuracy)}`)
  lines.push('')
  lines.push('| Metric | Value |')
  lines.push('|--------|-------|')
  lines.push(`| Accuracy | ${pct(m.accuracy)} |`)
  lines.push(`| Precision | ${pct(m.precision)} |`)
  lines.push(`| Recall | ${pct(m.recall)} |`)
  lines.push(`| False positive rate (over-trigger) | ${pct(m.false_positive_rate)} |`)
  lines.push(`| False negative rate (under-trigger) | ${pct(m.false_negative_rate)} |`)
  lines.push(`| F1 | ${m.f1.toFixed(3)} |`)
  lines.push('')
  lines.push('| | Triggered | Not triggered |')
  lines.push('|--------|-----------|---------------|')
  lines.push(`| Should trigger | ${m.confusion.TP} (TP) | ${m.confusion.FN} (FN) |`)
  lines.push(`| Should NOT trigger | ${m.confusion.FP} (FP) | ${m.confusion.TN} (TN) |`)
  lines.push('')
  lines.push('### Per-case results')
  lines.push('')
  lines.push('| # | Query | Expected | Actual | Correct |')
  lines.push('|---|-------|----------|--------|---------|')
  result.cases.forEach((c, i) => {
    const q = c.query.length > 80 ? `${c.query.slice(0, 77)}...` : c.query
    lines.push(`| ${i + 1} | ${q} | ${c.expected ? 'YES' : 'NO'} | ${c.actual ? 'YES' : 'NO'} | ${c.correct ? 'OK' : 'MISS'} |`)
  })
  return lines.join('\n')
}
