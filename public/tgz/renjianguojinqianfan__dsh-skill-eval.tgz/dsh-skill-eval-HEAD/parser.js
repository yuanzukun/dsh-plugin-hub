import { readFile } from 'node:fs/promises'

/**
 * Read and validate a skill-eval test-case JSON file.
 * @param {string} filePath - absolute path to the JSON file.
 * @returns {Promise<import('./types.js').SkillEvalTestCase[]>}
 */
export async function readTestCases(filePath) {
  let raw
  try {
    raw = await readFile(filePath, 'utf8')
  } catch (e) {
    throw new Error(`skill-eval: cannot read test file "${filePath}": ${e.message}`)
  }
  let data
  try {
    data = JSON.parse(raw)
  } catch (e) {
    throw new Error(`skill-eval: test file "${filePath}" is not valid JSON: ${e.message}`)
  }
  if (!Array.isArray(data)) {
    throw new Error(`skill-eval: test file "${filePath}" must contain a JSON array of cases`)
  }
  return data.map((item, index) => {
    if (typeof item !== 'object' || item === null || typeof item.query !== 'string' || typeof item.should_trigger !== 'boolean') {
      throw new Error(`skill-eval: test case #${index + 1} in "${filePath}" must have a string "query" and a boolean "should_trigger"`)
    }
    return {
      query: item.query,
      should_trigger: item.should_trigger,
      category: typeof item.category === 'string' ? item.category : undefined,
    }
  })
}
