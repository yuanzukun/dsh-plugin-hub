// Skill-trigger evaluation data shapes. Pure JSDoc typedefs, no runtime exports.

// 测试用例格式（沿用现有格式，可扩展）
/** @typedef {{ query: string, should_trigger: boolean, category?: string }} SkillEvalTestCase */
// category 可选：undertrigger/overtrigger/boundary/...

// 单个用例结果
/** @typedef {{ query: string, expected: boolean, actual: boolean, correct: boolean, llm_output: string }} SkillEvalCaseResult */
// llm_output: LLM 原始输出，用于调试

// 混淆矩阵
/** @typedef {{ TP: number, FP: number, FN: number, TN: number }} ConfusionMatrix */
// TP 该触发且触发 / FP 不该触发却触发（过触发）/ FN 该触发却没触发（欠触发）/ TN 不该触发且没触发

// 评测指标
/** @typedef {{ accuracy: number, precision: number, recall: number, false_positive_rate: number, false_negative_rate: number, f1: number, confusion: ConfusionMatrix, total: number, correct: number }} SkillEvalMetrics */
// accuracy=(TP+TN)/total；precision/recall 分母为 0 时取 0；FPR=FP/(FP+TN)；FNR=FN/(TP+FN)

// 完整评测结果
/** @typedef {{ skill_name: string, cases: SkillEvalCaseResult[], metrics: SkillEvalMetrics }} SkillEvalResult */
