import { fileURLToPath } from 'node:url'
import { dirname, isAbsolute, resolve } from 'node:path'
import { BlockAssembler, createUserMessage, deepFreeze } from './llm-helpers.js'
import { catalogDescription, renderCatalogMessage, buildJudgePrompt, parseVerdict } from './catalog.js'
import { readTestCases } from './parser.js'
import { computeMetrics } from './metrics.js'

const PACKAGE_DIR = dirname(fileURLToPath(import.meta.url))
const DEFAULT_TEST_FILE = resolve(PACKAGE_DIR, 'examples', 'dsh-plugin-eval.json')

/** Minimal check mirroring dsh-skill's isModelInvocable. */
function isModelInvocable(skill) {
  return skill.invocation?.modelInvocable === true
}

/** One judge LLM call via the verified ctx.llm.stream + BlockAssembler pattern. */
async function judgeCall(ctx, config, judgePrompt, signal) {
  const messages = [createUserMessage({
    content: [{ type: 'text', text: judgePrompt }],
    source: { kind: 'plugin', plugin: 'dsh-skill-eval' },
  })]
  const options = deepFreeze({
    provider: config.provider,
    model: config.model,
    messages,
    maxTokens: config.maxTokens ?? 64,
    signal,
  })
  const assembler = new BlockAssembler()
  for await (const chunk of ctx.llm.stream(options)) {
    assembler.push(chunk)
  }
  if (assembler.finish?.kind !== 'stop') {
    throw new Error(`skill-eval: judge LLM call failed (finish=${assembler.finish?.kind})`)
  }
  return assembler.blocks()
    .filter((b) => b.type === 'text')
    .map((b) => b.text)
    .join(' ')
}

function resolveTestFile(testFile) {
  if (!testFile) return DEFAULT_TEST_FILE
  return isAbsolute(testFile) ? testFile : resolve(PACKAGE_DIR, testFile)
}

/**
 * Run the full evaluation: enumerate skills, recreate the catalog, judge each query.
 * @param {object} opts
 * @param {object} opts.ctx - plugin context exposing skills/llm services.
 * @param {object} opts.config - plugin config (provider/model/maxTokens/maxCases/catalogDescriptionMaxLength).
 * @param {string} opts.skillName - the skill to evaluate.
 * @param {string|undefined} opts.testFile - test-case JSON path; defaults to examples/dsh-plugin-eval.json.
 * @param {AbortSignal} opts.signal
 * @param {object|undefined} opts.agent - calling agent; undefined for non-agent callers.
 * @returns {Promise<import('./types.js').SkillEvalResult>}
 */
export async function runEvaluation({ ctx, config, skillName, testFile, signal, agent }) {
  if (!config.provider || !config.model) {
    throw new Error('skill-eval: judge provider and model must be configured (config.provider / config.model)')
  }
  const cwd = agent?.session?.header?.cwd
  const snapshot = await ctx.skills.snapshot({ cwd, signal, scope: agent })
  const skills = snapshot.skills.filter(isModelInvocable)
  const target = skills.find((s) => s.name === skillName)
  if (!target) {
    const available = skills.map((s) => s.name).join(', ')
    throw new Error(`skill-eval: skill "${skillName}" not found among model-invocable skills (available: ${available || 'none'})`)
  }
  const maxLength = config.catalogDescriptionMaxLength ?? 500
  const entries = skills.map((s) => ({ name: s.name, description: catalogDescription(s.description, maxLength) }))
  const catalogText = renderCatalogMessage(entries)

  const cases = await readTestCases(resolveTestFile(testFile))
  const maxCases = config.maxCases
  const selected = maxCases && maxCases > 0 ? cases.slice(0, maxCases) : cases

  const results = []
  for (const tc of selected) {
    signal?.throwIfAborted?.()
    const judgePrompt = buildJudgePrompt(catalogText, tc.query, skillName)
    const output = await judgeCall(ctx, config, judgePrompt, signal)
    const verdict = parseVerdict(output)
    results.push({
      query: tc.query,
      expected: tc.should_trigger,
      actual: verdict === true,
      correct: verdict !== null && verdict === tc.should_trigger,
      llm_output: output,
    })
  }
  return {
    skill_name: skillName,
    cases: results,
    metrics: computeMetrics(results),
  }
}