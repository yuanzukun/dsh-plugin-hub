# AGENTS.md - dsh-skill-eval

> 本文件是 `dsh-skill-eval`（技能触发评测 DSH 插件）的 Agent 操作手册。约束「怎么写 / 怎么装 / 怎么验」；不重复全局 `~/.dsh/AGENTS.md` 的工作循环纪律。短而稳。

## 1. 快照

- **是什么**：DSH 插件，用 LLM judge 复现官方技能 catalog 提示词，评测给定技能描述在测试查询上的触发准确率（含欠触发/过触发）。
- **形态**：纯 JS / ESM，无构建，零 `@deepseek-ai` 外部依赖。工具/命令经 `ctx.tools.register` / `ctx.commands.register` 注册。
- **关键约束**：依赖于 `ctx.llm.stream()` + `ctx.skills.snapshot()`，运行时必须挂载到 DSH profile 且 judge 模型（provider/model）必须在 patch 层配置。

## 2. 硬规则（踩过的坑 / 架构约束）

- **零 `@deepseek-ai` 依赖**：pnpm link 的真实路径下 Node 无法解析 profile 的 node_modules，`BlockAssembler`/`createUserMessage`/`deepFreeze`/`isModelInvocable` 全部本地复现（`llm-helpers.js` / `runner.js`），不引入任何 `@deepseek-ai/*`。
- **catalog 提示词逐字复现**：`catalog.js` 的 `renderCatalogMessage` 必须与官方 `tool-skill/src/index.ts` 的 `<system-reminder>` + `<available_skills>` 模板完全一致，否则评测结果与真实触发场景有偏差。`test/fixtures/` 固化了 `dsh-tool-skill@0.1.0-rc.6` 官方模板；升级 DSH 后用 `scripts/refresh-catalog-fixture.mjs` 刷新并 review diff。
- **judge 模型必须配置**：`apply()` 时若 `config.provider` 或 `config.model` 为空，直接 throw（不静默跳过）。Patch 层必须提供。
- **工具参数用编译 JSON-schema**：`parameters.required` 是顶层数组（不是属性内 `required: true`），与 `dsh-local-extras` 一致。
- **副作用全走 `ctx.effect`**：注册的工具/命令要可撤销。

## 3. 目录结构

| 路径 | 内容 |
|---|---|
| `index.js` | 插件主入口：`name`/`inject`/`apply`，注册 `run_skill_eval` 工具 + `/skill-eval` 命令 |
| `types.js` | JSDoc 类型定义（`SkillEvalTestCase` / `SkillEvalResult` / `ConfusionMatrix`） |
| `parser.js` | 读取并验证 JSON 测试用例文件 |
| `runner.js` | 评测核心：技能枚举 → catalog 渲染 → LLM judge 逐条调用 → 结果收集 |
| `catalog.js` | 纯函数：catalog 消息渲染 + 判定解析（零 DSH 依赖，可独立测试） |
| `llm-helpers.js` | 零依赖 `BlockAssembler`/`createUserMessage`/`deepFreeze`（复现官方模式） |
| `metrics.js` | 指标计算：混淆矩阵 + 准确率/精确率/召回率/F1 + markdown 报告 |
| `smoke-test.mjs` | 纯函数冒烟测试（51 断言，无需 DSH 运行时） |
| `test/` | `node:test` 行为测试：apply 注册/参数校验、runner mock LLM 集成、catalog 官方 fixture 比对 |
| `scripts/refresh-catalog-fixture.mjs` | 从本机官方 `dsh-tool-skill` 包刷新 catalog fixture（仓库保持零依赖） |
| `examples/` | 默认测试用例（`dsh-plugin-eval.json` 20 条 + `dsh-plugin-eval-smoke.json` 3 条 + `code-review-eval.json` 20 条） |
| `cordis.patch.yml` | bundle patch 层（insert 条目） |
| `.github/workflows/ci.yml` | CI：Node 20/22 矩阵 + node:test + 打包实装探针 + 真实挂载门禁 |
| `LICENSE` / `CHANGELOG.md` / `CONTRIBUTING.md` | 许可证与协作文档 |

## 4. 常用命令

```bash
# 语法检查 + 测试 + 冒烟
npm run check
npm test
npm run smoke
# 发布包实装探针
npm pack --dry-run
# 真实挂载冒烟（scratch DSH_HOME，不碰真实 ~/.dsh）
bash scripts/mount-smoke.sh
# 挂载到 web profile
dsh plugin --profile web add link:E:/code/demo/dsh-skill-eval
# 卸载
dsh plugin --profile web remove dsh-skill-eval
# 列出已挂载插件（确认挂载成功）
dsh plugin --profile web list
```

## 5. 完成定义

- `npm run check` 通过
- `npm test` 通过（含 catalog 官方 fixture 比对与 mock ctx 行为测试）
- `npm run smoke` 通过（51 断言）
- `npm pack --dry-run` 文件清单正确，tarball 安装后 `import('dsh-skill-eval')` 成功
- scratch DSH 挂载启动成功（`bash scripts/mount-smoke.sh`）
- 挂载到 web profile 后 `dsh plugin --profile web list` 可见
- 在 DSH 会话中 `/skill-eval` 命令可用或 `run_skill_eval` 工具可调用
- 已获用户确认

## 6. 行为边界

- ✅ **允许**：改 `dsh-skill-eval/` 下代码；增删测试用例（`examples/`）；调整 CI 配置；本仓库内 git commit / push
- ⚠️ **需确认**：改 `cordis.patch.yml` 的 insert 格式；引入 `@deepseek-ai` 依赖（如不再需要 link 兼容）
- ⛔ **禁止**：碰 DSH 源码；不经提权写 `~/.dsh`；修改 `package.json` 的 `dsh.bundle.patch` 指向