# Changelog

本项目遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 习惯；版本号遵循语义化版本。

## [0.1.0] - 2026-08-18

### Added

- DSH 插件 bundle：`run_skill_eval` 模型工具 + `/skill-eval` 命令
- 逐字复现官方 DSH skill catalog 提示词的 LLM judge 评测
- 混淆矩阵与 Accuracy/Precision/Recall/FPR/FNR/F1 报告
- 默认 `dsh-plugin-eval`（20 条）与冒烟用例（3 条）
- `code-review` 触发评测用例（20 条）
- `node:test` 行为测试与官方 catalog 保真 fixture
- CI：Node 20/22 矩阵、打包实装探针、真实挂载门禁、每日定时集成

### Fixed

- 发布包 `files` 缺失 `catalog.js` / `llm-helpers.js` 导致 tarball 安装失败
- `mount-smoke.ps1` 成功路径未清理 scratch 目录与 DSH 进程
- `mount-smoke.sh` 在 Windows Git Bash 下 `link:` 使用 POSIX 路径导致插件未被识别为 bundle
- CI 在无 `pnpm-lock.yaml` 时配置 `cache: pnpm` 的问题
