// Quick smoke test for pure functions — no DSH runtime needed.
import { catalogDescription, escapeText, renderCatalogEntries, renderCatalogMessage, buildJudgePrompt, parseVerdict } from './catalog.js'
import { deepFreeze, createUserMessage, BlockAssembler } from './llm-helpers.js'
import { computeMetrics, formatReport } from './metrics.js'
import { readTestCases } from './parser.js'

let passed = 0
let failed = 0
function assert(condition, label) {
  if (condition) { passed++ } else { console.error(`FAIL: ${label}`); failed++ }
}

// ── catalogDescription ────────────────────────────────────────────────
assert(catalogDescription('  hello   world ', 500) === 'hello world', 'normalize whitespace')
assert(catalogDescription('hello world', 8) === 'hello...', 'truncate with ellipsis')
assert(catalogDescription('short', 500) === 'short', 'short string unchanged')

// ── escapeText ────────────────────────────────────────────────────────
assert(escapeText('a & b < c > d') === 'a &amp; b &lt; c &gt; d', 'escape XML specials')
assert(escapeText('plain text') === 'plain text', 'no escaping needed')

// ── renderCatalogEntries ──────────────────────────────────────────────
const entries = [{ name: 'test-skill', description: 'does something' }]
const rendered = renderCatalogEntries(entries)
assert(rendered.length === 1, 'one entry rendered')
assert(rendered[0] === '- `test-skill`: does something', 'entry format matches official')

// ── renderCatalogMessage ──────────────────────────────────────────────
const msg = renderCatalogMessage(entries)
assert(msg.includes('<system-reminder>'), 'has system-reminder open')
assert(msg.includes('</system-reminder>'), 'has system-reminder close')
assert(msg.includes('<available_skills>'), 'has available_skills open')
assert(msg.includes('</available_skills>'), 'has available_skills close')
assert(msg.includes('- `test-skill`: does something'), 'has the entry line')
assert(msg.includes('call the `skill` tool'), 'has the instruction')
assert(msg.includes('do not infer or follow'), 'has the guardrail')

// ── buildJudgePrompt ──────────────────────────────────────────────────
const judge = buildJudgePrompt(msg, 'test query', 'test-skill')
assert(judge.includes('test query'), 'query appears in prompt')
assert(judge.includes('`test-skill`'), 'skill name appears in prompt')
assert(judge.includes('YES'), 'YES in answer format')
assert(judge.includes('NO'), 'NO in answer format')

// ── parseVerdict ──────────────────────────────────────────────────────
assert(parseVerdict('YES') === true, 'exact YES')
assert(parseVerdict('NO') === false, 'exact NO')
assert(parseVerdict('yes') === true, 'lowercase yes')
assert(parseVerdict('Yes.') === true, 'Yes with period')
assert(parseVerdict('NO.') === false, 'NO with period')
assert(parseVerdict('NO, because the query does not match') === false, 'NO with explanation')
assert(parseVerdict('YES, this clearly matches') === true, 'YES with explanation')
assert(parseVerdict('maybe') === null, 'unrecognized returns null')
assert(parseVerdict('') === null, 'empty returns null')
assert(parseVerdict('  YES  ') === true, 'whitespace padded YES')

// ── llm-helpers ───────────────────────────────────────────────────────
const frozen = deepFreeze({ a: { b: 1 }, c: [1, 2] })
assert(Object.isFrozen(frozen) && Object.isFrozen(frozen.a) && Object.isFrozen(frozen.c), 'deepFreeze freezes nested')
const um = createUserMessage({ content: [{ type: 'text', text: 'hi' }], source: { kind: 'plugin', plugin: 'x' } })
assert(um.role === 'user' && typeof um.id === 'string', 'createUserMessage shape')
assert(Object.isFrozen(um), 'createUserMessage frozen')
const ab = new BlockAssembler()
ab.push({ type: 'block-start', index: 0, blockType: 'text' })
ab.push({ type: 'text-delta', index: 0, text: 'hel' })
ab.push({ type: 'text-delta', index: 0, text: 'lo' })
ab.push({ type: 'block-end', index: 0, block: { type: 'text', text: 'hello' } })
ab.push({ type: 'finish', reason: { kind: 'stop' } })
const blocks = ab.blocks()
assert(blocks.length === 1 && blocks[0].text === 'hello', 'BlockAssembler assembles text')
assert(ab.finish.kind === 'stop', 'BlockAssembler finish stop')

// ── computeMetrics ────────────────────────────────────────────────────
const allCorrect = [
  { expected: true, actual: true, query: '', llm_output: '', correct: true },
  { expected: false, actual: false, query: '', llm_output: '', correct: true },
]
const m1 = computeMetrics(allCorrect)
assert(m1.accuracy === 1, 'all correct accuracy=1')
assert(m1.f1 === 1, 'all correct f1=1')

const mixed = [
  { expected: true, actual: true, query: '', llm_output: '', correct: true },
  { expected: true, actual: false, query: '', llm_output: '', correct: false },
  { expected: false, actual: true, query: '', llm_output: '', correct: false },
  { expected: false, actual: false, query: '', llm_output: '', correct: true },
]
const m2 = computeMetrics(mixed)
assert(m2.accuracy === 0.5, 'mixed accuracy=0.5')
assert(m2.confusion.TP === 1, 'TP=1')
assert(m2.confusion.FN === 1, 'FN=1')
assert(m2.confusion.FP === 1, 'FP=1')
assert(m2.confusion.TN === 1, 'TN=1')
assert(m2.precision === 0.5, 'precision=0.5')
assert(m2.recall === 0.5, 'recall=0.5')

const noTrue = [
  { expected: false, actual: false, query: '', llm_output: '', correct: true },
  { expected: false, actual: true, query: '', llm_output: '', correct: false },
]
const m3 = computeMetrics(noTrue)
assert(m3.precision === 0, 'no TP precision=0 (no division by zero)')
assert(m3.recall === 0, 'no TP recall=0')

// ── formatReport ──────────────────────────────────────────────────────
const report = formatReport({ skill_name: 'test', cases: mixed, metrics: m2 })
assert(report.includes('## Skill trigger evaluation: `test`'), 'report contains title')
assert(report.includes('Accuracy'), 'report contains metrics')
assert(report.includes('TP'), 'report contains confusion matrix')
assert(report.includes('Per-case'), 'report contains per-case table')

// ── parser ────────────────────────────────────────────────────────────
import { fileURLToPath } from 'node:url'
import { dirname, resolve } from 'node:path'
const here = dirname(fileURLToPath(import.meta.url))
const cases = await readTestCases(resolve(here, 'examples/dsh-plugin-eval.json'))
assert(cases.length === 20, 'eval.json has 20 cases')
assert(cases.every((c) => typeof c.query === 'string' && typeof c.should_trigger === 'boolean'), 'all cases validated')
const smoke = await readTestCases(resolve(here, 'examples/dsh-plugin-eval-smoke.json'))
assert(smoke.length === 3, 'smoke.json has 3 cases')

// ── summary ───────────────────────────────────────────────────────────
console.log(`\n${passed} passed, ${failed} failed`)
if (failed > 0) process.exit(1)