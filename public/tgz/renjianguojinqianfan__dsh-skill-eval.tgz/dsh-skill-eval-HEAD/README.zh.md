# dsh-skill-eval

[![CI](https://github.com/renjianguojinqianfan/dsh-skill-eval/actions/workflows/ci.yml/badge.svg)](https://github.com/renjianguojinqianfan/dsh-skill-eval/actions/workflows/ci.yml)

DeepSeek Harness（DSH）技能触发评测插件。

用 LLM judge 逐字复现 DSH 的技能 catalog 提示词，对每条测试查询判断目标技能是否应被触发，输出准确率、精确率、召回率、误报/漏报率与混淆矩阵——可复现地衡量技能描述的路由质量（以及过触发/欠触发程度）。

## 安装

在仓库根目录执行：

```bash
dsh plugin --profile web add ./dsh-skill-eval
```

然后在 profile / overlay 的 `cordis.patch.yml` 里配置 judge 模型路由：

```yaml
- id: skill-eval
  config:
    provider: <provider-id>
    model: <model-name>
```

provider 必须已在 DSH LLM 运行时注册（与你 profile 对话用的同一套）。插件启动时校验路由，provider 未注册会告警。

## 用法

Slash 命令：

```
/skill-eval <skill-name> [test-file]
```

模型可调用工具：

```
run_skill_eval(skill_name="<skill-name>", test_file="examples/dsh-plugin-eval.json")
```

`test-file` 可选，默认取插件包内 `examples/dsh-plugin-eval.json`；相对路径相对插件包目录解析。

## 测试用例格式

JSON 数组，元素为 `{ query, should_trigger }`：

```json
[
  { "query": "add a tool to the harness that persists across restarts", "should_trigger": true },
  { "query": "help me write a Python script for this CSV", "should_trigger": false }
]
```

`category` 可选，为后续扩展预留。

## 工作原理

1. 枚举会话中模型可调用的技能（`ctx.skills.snapshot`）。
2. 逐字复现官方 catalog 消息（`<system-reminder>` + `<available_skills>` + 归一化/截断/转义的描述）。
3. 对每条查询让 judge 模型判断目标技能是否应触发，强制一行 `YES`/`NO` 回答。
4. 与期望标签比对并聚合指标。

评测衡量的是 **judge 模型视角**下该技能描述的路由准确率。可通过配置更换 `provider`/`model` 测试不同 judge。

## 开发与测试

```bash
npm run check     # 全部 JS 语法检查
npm test          # node:test（含 catalog 官方保真比对与 mock ctx 行为测试）
npm run smoke     # 51 条纯函数冒烟
npm pack --dry-run  # 发布包清单检查
bash scripts/mount-smoke.sh  # scratch DSH 真实挂载冒烟
```

catalog 保真 fixture 固化了 `dsh-tool-skill@0.1.0-rc.6` 的官方模板。升级 DSH
版本后，用本机官方包源码刷新 fixture 并 review diff：

```bash
node scripts/refresh-catalog-fixture.mjs <path-to-dsh-tool-skill/lib/index.js>
```

## 文件

- `index.js` — 插件入口：注册 `run_skill_eval` 工具与 `/skill-eval` 命令。
- `runner.js` — catalog 复现、judge LLM 调用、判定解析。
- `catalog.js` — 纯函数：catalog 消息渲染与判定解析。
- `llm-helpers.js` — 零依赖的 `BlockAssembler`、`createUserMessage`、`deepFreeze`（逐字复现官方 dsh-llm 模式）。
- `parser.js` — 测试用例 JSON 加载与校验。
- `metrics.js` — 混淆矩阵、指标与 markdown 报告格式化。
- `examples/` — 默认测试用例。
