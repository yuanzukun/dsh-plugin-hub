// DSH LLM call helpers — minimal reimplementation of the verified official pattern
// (BlockAssembler + createUserMessage + deepFreeze from @deepseek-ai/dsh-llm).
// Kept dependency-free so the plugin resolves without its own node_modules.

import { randomUUID } from 'node:crypto'

/** Iterative deep freeze; skips AbortSignal and cycles (mirrors dsh-llm deepFreeze). */
export function deepFreeze(value) {
  const seen = new WeakSet()
  const pending = [{ kind: 'visit', node: value }]
  while (pending.length > 0) {
    const task = pending.pop()
    if (task === undefined) continue
    if (task.kind === 'property') {
      pending.push({ kind: 'visit', node: task.source[task.key] })
      continue
    }
    const node = task.node
    if (node === null || typeof node !== 'object') continue
    if (node instanceof AbortSignal) continue
    if (seen.has(node)) continue
    seen.add(node)
    Object.freeze(node)
    const keys = Object.keys(node)
    for (let index = keys.length - 1; index >= 0; index--) {
      pending.push({ kind: 'property', source: node, key: keys[index] })
    }
  }
  return value
}

/** One identified user-role message, frozen (mirrors dsh-llm createUserMessage). */
export function createUserMessage(input) {
  return deepFreeze({
    ...input,
    role: 'user',
    id: randomUUID(),
  })
}

/**
 * Assemble raw stream chunks into blocks (mirrors dsh-llm BlockAssembler).
 * Only the text path is exercised by this plugin's judge calls.
 */
export class BlockAssembler {
  constructor() {
    this.partials = new Map()
    this.order = []
    this._finish = undefined
  }

  push(chunk) {
    switch (chunk.type) {
      case 'block-start':
        if (!this.partials.has(chunk.index)) {
          this.order.push(chunk.index)
          this.partials.set(chunk.index, { blockType: chunk.blockType, text: '', toolCallArguments: '' })
        }
        return
      case 'text-delta':
      case 'reasoning-delta': {
        const partial = this.ensure(chunk.index, chunk.type === 'text-delta' ? 'text' : 'reasoning')
        if (partial.block) return
        partial.text += chunk.text
        return
      }
      case 'tool-call-delta': {
        const partial = this.ensure(chunk.index, 'tool-call')
        if (partial.block) return
        partial.toolCallId = chunk.id
        if (chunk.name) partial.toolCallName = chunk.name
        partial.toolCallArguments += chunk.argumentsDelta
        return
      }
      case 'block-end': {
        const partial = this.ensure(chunk.index, chunk.block.type)
        if (partial.block) return
        partial.block = chunk.block
        return
      }
      case 'usage':
        return
      case 'finish':
        this._finish = chunk.reason
        return
      default:
        throw new Error(`BlockAssembler: unknown chunk type "${chunk.type}"`)
    }
  }

  ensure(index, blockType) {
    let partial = this.partials.get(index)
    if (!partial) {
      partial = { blockType, text: '', toolCallArguments: '' }
      this.partials.set(index, partial)
      this.order.push(index)
    }
    return partial
  }

  assemble(partial) {
    if (partial.block) return partial.block
    switch (partial.blockType) {
      case 'text': return { type: 'text', text: partial.text }
      case 'reasoning': return { type: 'reasoning', text: partial.text }
      case 'tool-call': return { type: 'tool-call', id: partial.toolCallId ?? `call-${partial.index}`, name: partial.toolCallName ?? '', arguments: partial.toolCallArguments }
      default: throw new Error(`cannot assemble incomplete block of type "${partial.blockType}"`)
    }
  }

  blocks() {
    return this.order.map((index) => this.assemble(this.partials.get(index)))
  }

  get finish() {
    return this._finish ?? { kind: 'stop' }
  }
}