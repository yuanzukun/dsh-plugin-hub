// Regenerate the pinned official DSH catalog fixture from a local install of
// @deepseek-ai/dsh-tool-skill. The package's renderCatalogMessage is internal,
// so this script extracts the bundled source text and evaluates the official
// array expression with its official renderCatalogEntries implementation.
//
// Usage:
//   node scripts/refresh-catalog-fixture.mjs <path-to-dsh-tool-skill/lib/index.js>
//
// Only regenerate when the DSH version changes, then review the diff before
// committing. The repo itself keeps zero @deepseek-ai dependencies.

import { readFile, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const HERE = dirname(fileURLToPath(import.meta.url))
const FIXTURE = resolve(HERE, '../test/fixtures/dsh-tool-skill-catalog-0.1.0-rc.6.txt')
const ENTRIES_FILE = resolve(HERE, '../test/fixtures/canonical-entries.json')

const srcPath = process.argv[2]
if (!srcPath) {
  console.error('usage: node scripts/refresh-catalog-fixture.mjs <dsh-tool-skill-lib-index.js>')
  process.exit(1)
}

const escapeText = (value) =>
  value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')

function officialRenderCatalogEntries(source) {
  const fnStart = source.indexOf('function renderCatalogEntries(entries)')
  const fnEnd = source.indexOf('function digestCatalogEntries(entries)')
  if (fnStart < 0 || fnEnd < 0) throw new Error('renderCatalogEntries not found in source')
  const chunk = source.slice(source.indexOf('{', fnStart) + 1, fnEnd)
  const body = chunk.slice(0, chunk.lastIndexOf('}')).trim()
  const factory = new Function('escapeText', 'entries', body)
  return (entries) => factory(escapeText, entries)
}

function officialCatalogParts(source, renderCatalogEntries, entries) {
  const msgStart = source.indexOf('function renderCatalogMessage(entries)')
  const msgEnd = source.indexOf('function renderCatalogUpdate(entries)')
  if (msgStart < 0 || msgEnd < 0) throw new Error('renderCatalogMessage not found in source')
  const body = source.slice(msgStart, msgEnd)
  const arrayStart = body.indexOf('text: [')
  const arrayEnd = body.indexOf('].join(')
  if (arrayStart < 0 || arrayEnd < 0) throw new Error('catalog text array not found in source')
  const expression = body.slice(arrayStart + 6, arrayEnd + 1)
  const factory = new Function('renderCatalogEntries', 'entries', `return (${expression})`)
  return factory(renderCatalogEntries, entries)
}

const source = await readFile(srcPath, 'utf8')
const entries = JSON.parse(await readFile(ENTRIES_FILE, 'utf8'))
const renderCatalogEntries = officialRenderCatalogEntries(source)
const parts = officialCatalogParts(source, renderCatalogEntries, entries)
const text = `${parts.join('\n')}\n`

await writeFile(FIXTURE, text, 'utf8')
console.log(`fixture written: ${FIXTURE}`)
console.log(text)
