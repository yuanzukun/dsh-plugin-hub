# dsh-skill-eval mount smoke test (PowerShell, for local Windows verification)
#
# Usage:
#   .\scripts\mount-smoke.ps1 [-PluginDir <path>] [-DshCmd <command>]
#
# Env:
#   KEEP_HOME: keep the scratch dir when set (debugging)

param (
  [string]$PluginDir = (Resolve-Path $PSScriptRoot\..).Path,
  [string]$DshCmd = "dsh"
)

$ErrorActionPreference = "Stop"

function Say($text) { Write-Host "`e[32m[mount-smoke]`e[0m $text" }
function Warn($text) { Write-Warning "$text" }
function Die($text) { Write-Error "$text"; exit 1 }

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Die "node not found (DSH needs Node.js >= 20)"
}
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) {
  Die "pnpm not found (dsh plugin forwards to pnpm)"
}
if (-not (Get-Command $DshCmd -ErrorAction SilentlyContinue)) {
  Die "dsh CLI not found; install with 'npm i -g @deepseek-ai/dsh' or pass -DshCmd"
}
if (-not (Test-Path "$PluginDir/package.json")) {
  Die "not a plugin root: $PluginDir"
}

# Resolve the dsh command to a node-invocable entry. On Windows `dsh` is a
# .cmd/.ps1 shim that runs node "<shimDir>\node_modules\@deepseek-ai\dsh\lib\bin.js";
# Start-Process cannot execute a shim directly.
function Resolve-DshNodeEntry {
  param([string]$Cmd)
  $gci = Get-Command $Cmd -ErrorAction SilentlyContinue
  if (-not $gci) { return $null }
  $source = $gci.Source
  if ($source -match '\.(cmd|ps1)$') {
    $shimDir = Split-Path $source -Parent
    $candidate = Join-Path $shimDir "node_modules\@deepseek-ai\dsh\lib\bin.js"
    if (Test-Path $candidate) { return $candidate }
  }
  return $null
}
$dshNodeEntry = Resolve-DshNodeEntry $DshCmd
if (-not $dshNodeEntry) {
  Die "cannot resolve dsh node entry from '$DshCmd'"
}
Say "dsh entry: $dshNodeEntry"

Say "plugin: $PluginDir"

$scratch = Join-Path ([System.IO.Path]::GetTempPath()) "dsh-skill-eval-$(Get-Random -Maximum 999999)"
$dshHome = Join-Path $scratch "home"
$profileDir = Join-Path $dshHome "profiles\web"
$outLog = Join-Path $scratch "web.out.log"
$errLog = Join-Path $scratch "web.err.log"
New-Item -ItemType Directory -Force -Path $profileDir | Out-Null

Say "scratch: $scratch (DSH_HOME=$dshHome)"

$originalDshHome = $env:DSH_HOME
$SERVER_PID = $null

function Cleanup {
  if ($SERVER_PID) {
    try { Stop-Process -Id $SERVER_PID -Force -ErrorAction SilentlyContinue } catch {}
    $SERVER_PID = $null
  }
  $env:DSH_HOME = $originalDshHome
  if ($scratch -and (Test-Path $scratch)) {
    if ($env:KEEP_HOME) {
      Warn "KEEP_HOME 已设置，保留 $scratch"
    } else {
      Remove-Item -Recurse -Force $scratch -ErrorAction SilentlyContinue
    }
  }
}

trap {
  Write-Host "TRAP: $($_.Exception.Message)" -ForegroundColor Red
  Cleanup
}

# 1. Bootstrap scratch profile (mirror dsh initProfile)
$pkgJson = @"
{
  "name": "dsh-profile-web",
  "private": true,
  "dependencies": {},
  "dsh": {
    "profile": {
      "bundles": ["@deepseek-ai/dsh-base", "@deepseek-ai/dsh-web-app"]
    }
  }
}
"@
Set-Content -Path "$profileDir\package.json" -Value $pkgJson

# Dummy config for skill-eval (required to avoid throw on apply)
$patchYaml = @"
- id: skill-eval
  config:
    provider: dummy
    model: dummy
"@
Set-Content -Path "$profileDir\cordis.patch.yml" -Value $patchYaml

$pnpmWorkspace = @"
packages:
  - .

nodeLinker: hoisted
autoInstallPeers: false

allowBuilds:
  node-pty: true
  protobufjs: true
"@
Set-Content -Path "$profileDir\pnpm-workspace.yaml" -Value $pnpmWorkspace

# 2. Run dsh plugin add (real mount flow)
$env:DSH_HOME = $dshHome
Say "running dsh plugin --profile web add link:$PluginDir ..."
node $dshNodeEntry plugin --profile web add "link:$PluginDir"
if ($LASTEXITCODE -ne 0) {
  Die "dsh plugin add failed (exit $LASTEXITCODE)"
}

# 3. Verify bundle registration
$pkg = Get-Content "$profileDir\package.json" -Raw | ConvertFrom-Json
if (-not ($pkg.dsh.profile.bundles -contains "dsh-skill-eval")) {
  Warn "dsh-skill-eval not in dsh.profile.bundles"
  Get-Content "$profileDir\package.json" | Write-Host
  Die "mount not registered"
}
Say "mount registered: dsh.profile.bundles contains dsh-skill-eval"

# 4. Start dsh web (--port 0, keyless)
Say "starting dsh web (keyless) ..."
$env:DSH_TELEMETRY_DISABLED = "1"
$proc = Start-Process -FilePath "node" -ArgumentList $dshNodeEntry,"web","--port","0" -RedirectStandardOutput $outLog -RedirectStandardError $errLog -PassThru -NoNewWindow
$SERVER_PID = $proc.Id

$url = $null
for ($i = 0; $i -lt 180; $i++) {
  if ($proc.HasExited) {
    Write-Host "=== dsh web exited early, log tail ===" -ForegroundColor Red
    Get-Content $outLog -Tail 40 -ErrorAction SilentlyContinue
    Get-Content $errLog -Tail 40 -ErrorAction SilentlyContinue
    Die "dsh web exited early (code $($proc.ExitCode))"
  }
  if (Test-Path $outLog) {
    $content = Get-Content $outLog -Raw
    if ($content -match 'dsh web: (http://127\.0\.0\.1:[0-9]+)') {
      $url = $matches[1]
      break
    }
  }
  Start-Sleep -Seconds 1
}

if (-not $url) {
  Write-Host "=== dsh web not ready in 180s, log tail ===" -ForegroundColor Red
  Get-Content $outLog -Tail 60 -ErrorAction SilentlyContinue
  Get-Content $errLog -Tail 60 -ErrorAction SilentlyContinue
  Die "timeout waiting for dsh web"
}
Say "dsh web ready: $url (pid $SERVER_PID)"

# 5. Check log for errors
$logContent = Get-Content $outLog -Raw
if ($logContent -match '(?i)skill-eval.*(throw|error|failed)|error.*skill-eval') {
  Write-Host "=== skill-eval errors in log ===" -ForegroundColor Red
  Select-String -Pattern '(?i)(skill-eval|error)' -InputObject $logContent | Select-Object -Last 20 | ForEach-Object { Write-Host $_.Line }
  Die "plugin startup error"
}

Say "PASS: dsh-skill-eval mounted into real DSH, boot did not crash"
Cleanup
exit 0
