#!/usr/bin/env bash
# =============================================================================
# dsh-skill-eval 挂载冒烟（CI + 本地）：
#
#   1. 用官方 CLI 把插件真实挂载进一个全新 scratch profile
#      （`dsh plugin --profile web add link:<dir>`，触发 dsh.profile.bundles
#      协调，与用户安装路径一致）；
#   2. 在 scratch profile 的 cordis.patch.yml 里给 skill-eval 注入
#      dummy provider/model（apply() 缺配置会 throw，必须提供）；
#   3. 启动真实 `dsh web`（keyless，--port 0 取 OS 分配端口），等待就绪
#      URL，确认插件 apply() 未抛错、外壳未崩溃。
#
# 用法：
#   bash scripts/mount-smoke.sh [plugin-dir]
#
# 环境变量（均可省略）：
#   DSH_CMD        dsh 命令；缺省 PATH 上的 `dsh`，回退 npx 拉官方包
#   DSH_HOME_BASE  覆盖 scratch 根目录（默认 mktemp -d）
#   KEEP_HOME      非空时保留 scratch home（调试用）
#
# 退出码 = 0 成功；非 0 失败。服务器与 scratch 目录由 trap 兜底清理。
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PLUGIN_DIR="${1:-$ROOT}"
PLUGIN_DIR="$(cd "$PLUGIN_DIR" && pwd)"

DSH_CMD="${DSH_CMD:-dsh}"

# pnpm runs on Windows even under Git Bash/MSYS, where `/e/...` is not a
# Windows path. Convert to `E:/...` for the link: spec only; filesystem
# checks above keep using the POSIX path.
if command -v cygpath >/dev/null 2>&1 && uname -s | grep -qiE 'MINGW|MSYS|CYGWIN'; then
  PLUGIN_SPEC="$(cygpath -m "$PLUGIN_DIR")"
else
  PLUGIN_SPEC="$PLUGIN_DIR"
fi

say()  { printf '\033[32m[mount-smoke]\033[0m %s\n' "$*"; }
warn() { printf '\033[33m[mount-smoke]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[31m[mount-smoke]\033[0m %s\n' "$*" >&2; exit 1; }

command -v node >/dev/null 2>&1 || die "未找到 node（DSH 运行需要 Node.js >= 20）"
command -v pnpm >/dev/null 2>&1 || die "未找到 pnpm（dsh plugin 转发给 pnpm）"

# dsh CLI 解析：PATH 上的 dsh 优先，否则 npx 拉官方包
if ! command -v "$DSH_CMD" >/dev/null 2>&1; then
  if command -v npx >/dev/null 2>&1; then
    say "PATH 上无 $DSH_CMD，回退 npx -y --package @deepseek-ai/dsh"
    DSH_CMD="npx -y --package @deepseek-ai/dsh dsh"
  else
    die "未找到 $DSH_CMD 或 npx；请先安装 DSH CLI（npm i -g @deepseek-ai/dsh）或用 DSH_CMD 指定"
  fi
fi

[ -f "$PLUGIN_DIR/package.json" ] || die "plugin-dir 不是插件根目录：$PLUGIN_DIR"
say "plugin: $PLUGIN_DIR"

# scratch home（每次全新，绝不触碰真实 ~/.dsh）
SCRATCH="${DSH_HOME_BASE:-$(mktemp -d /tmp/dsh-skill-eval-mount.XXXXXX)}"
export DSH_HOME="$SCRATCH/home"
LOG_DIR="$SCRATCH"
WEB_LOG="$LOG_DIR/web.log"
mkdir -p "$DSH_HOME/profiles/web"
say "scratch home: ${DSH_HOME}（DSH_HOME=${DSH_HOME}）"

SERVER_PID=""
cleanup() {
  local code=$?
  if [ -n "$SERVER_PID" ] && kill -0 "$SERVER_PID" 2>/dev/null; then
    kill "$SERVER_PID" 2>/dev/null || true
    wait "$SERVER_PID" 2>/dev/null || true
  fi
  if [ -z "${KEEP_HOME:-}" ]; then
    rm -rf "$SCRATCH"
  else
    warn "KEEP_HOME 已设置，保留 $SCRATCH"
  fi
  exit "$code"
}
trap cleanup EXIT

# 步骤 1：引导 scratch profile（web 模板，镜像 initProfile；先写
# pnpm-workspace.yaml 的 allowBuilds，避免 pnpm 11 strict-dep-builds 拦截
# node-pty/protobufjs——同 DSH-better-sidebar 的 e2e-mount.sh）
PROFILE_DIR="$DSH_HOME/profiles/web"
cat > "$PROFILE_DIR/package.json" <<EOF
{
  "name": "dsh-profile-web",
  "private": true,
  "dependencies": {},
  "dsh": {
    "profile": {
      "bundles": ["@deepseek-ai/dsh-base", "@deepseek-ai/dsh-web-app"]
    }
  }
}
EOF
# apply() 缺 provider/model 会 throw；注入 dummy 路由让挂载可验证
cat > "$PROFILE_DIR/cordis.patch.yml" <<'EOF'
- id: skill-eval
  config:
    provider: dummy
    model: dummy
EOF
cat > "$PROFILE_DIR/pnpm-workspace.yaml" <<'EOF'
packages:
  - .

nodeLinker: hoisted
autoInstallPeers: false

allowBuilds:
  node-pty: true
  protobufjs: true
EOF

# 步骤 2：官方 CLI 安装插件 + bundle 协调（真实挂载路径）
say "执行 dsh plugin --profile web add link:$PLUGIN_SPEC ..."
$DSH_CMD plugin --profile web add "link:$PLUGIN_SPEC"

# 步骤 3：校验挂载生效（dsh.profile.bundles 含 dsh-skill-eval）
if ! node -e '
  const fs = require("fs");
  const p = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
  const bundles = p.dsh?.profile?.bundles ?? [];
  process.exit(bundles.includes("dsh-skill-eval") ? 0 : 1);
' "$PROFILE_DIR/package.json"; then
  warn "dsh-skill-eval 未出现在 dsh.profile.bundles 中——挂载未注册"
  cat "$PROFILE_DIR/package.json"
  exit 1
fi
say "挂载已注册：dsh.profile.bundles 包含 dsh-skill-eval"

# 步骤 4：启动 dsh web（--port 0 = OS 分配，避免端口冲突；keyless 可起）
say "启动 dsh web（keyless）..."
DSH_TELEMETRY_DISABLED=1 $DSH_CMD web --port 0 > "$WEB_LOG" 2>&1 &
SERVER_PID=$!

URL=""
for _ in $(seq 1 180); do
  if ! kill -0 "$SERVER_PID" 2>/dev/null; then
    echo "=== dsh web 提前退出，日志尾部 ===" >&2
    tail -40 "$WEB_LOG" >&2 || true
    exit 1
  fi
  if URL="$(grep -oE 'dsh web: http://127\.0\.0\.1:[0-9]+' "$WEB_LOG" | head -1 | awk '{print $3}')" && [ -n "$URL" ]; then
    break
  fi
  sleep 1
done
[ -n "$URL" ] || { echo "=== 180s 内未等到 dsh web 就绪，日志尾部 ===" >&2; tail -60 "$WEB_LOG" >&2 || true; exit 1; }
say "dsh web 就绪：${URL}（pid ${SERVER_PID}）"

# 步骤 5：确认日志无 apply 崩溃标记
if grep -qiE 'skill-eval.*(throw|error|failed)|error:.*skill-eval' "$WEB_LOG"; then
  echo "=== 日志中发现 skill-eval 报错 ===" >&2
  grep -iE 'skill-eval|error' "$WEB_LOG" | tail -20 >&2 || true
  exit 1
fi

say "通过：dsh-skill-eval 挂载到真实 DSH 后启动未崩溃"
