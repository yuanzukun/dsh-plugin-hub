// DSH skill catalog message rendering — pure functions, no DSH runtime imports.
// Verbatim reproduction of dsh-tool-skill's renderCatalogMessage/renderCatalogEntries/catalogDescription/escapeText.

/** Normalized, length-bounded description exactly as the catalog publishes it (unescaped). */
export function catalogDescription(value, maxLength) {
  const normalized = value.replaceAll(/\s+/g, ' ').trim()
  return normalized.length <= maxLength ? normalized : `${normalized.slice(0, maxLength - 3)}...`
}

/** Pseudo-XML escaping applied to catalog descriptions (mirrors dsh-skill escapeText). */
export function escapeText(value) {
  return value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
}

/** Model-facing catalog lines, one per entry. */
export function renderCatalogEntries(entries) {
  return entries.map((entry) => `- \`${entry.name}\`: ${escapeText(entry.description)}`)
}

/** Verbatim reproduction of dsh-tool-skill's renderCatalogMessage. */
export function renderCatalogMessage(entries) {
  return [
    '<system-reminder>',
    'A skill is a reusable set of task-specific instructions. The following skills are available in this session:',
    '',
    '<available_skills>',
    ...renderCatalogEntries(entries),
    '</available_skills>',
    '',
    "If the user names a skill, or the task clearly matches a skill's description, call the `skill` tool with the exact skill name before taking task actions. Load all applicable skills, then follow their full instructions. This catalog contains summaries only; do not infer or follow a skill's instructions until it has been loaded.",
    'A user may also invoke a skill directly; its <skill_content> block then appears in this conversation. Follow it, and do not call the `skill` tool again for that skill.',
    '</system-reminder>',
  ].join('\n')
}

/** Append the judge task to the catalog so the model decides on the target skill only. */
export function buildJudgePrompt(catalogText, query, skillName) {
  return [
    catalogText,
    '',
    `User query: ${query}`,
    '',
    `TASK: Does the above user query clearly match the description of \`${skillName}\` and should the \`skill\` tool be called?`,
    'ANSWER FORMAT: Reply with exactly one line: either `YES` if it should be triggered, or `NO` if it should NOT be triggered. Do not add any explanation.',
  ].join('\n')
}

/** Parse the judge verdict from the first word; tolerant of case, punctuation, and extra prose. */
export function parseVerdict(text) {
  const first = String(text || '').trim().split(/\s+/)[0] || ''
  const token = first.replace(/[^A-Za-z]/g, '').toUpperCase()
  if (token === 'YES') return true
  if (token === 'NO') return false
  return null
}