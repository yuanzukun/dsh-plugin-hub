# 开发路径文档：Multi-root Workspace（不改上游）

> 状态：active（**进度总账 + 里程碑概览**）。MVP-v0.1.0（M1/M2/M3）已实施并以 `v0.1.0` 发版（2026-09-13）；v0.1.1 硬化批次（H1–H4）已实施、全绿并随 `v0.1.1` 发版（2026-09-16）；v0.1.2 支持矩阵提升（`0.1.6-alpha.2`、`0.1.7-alpha.1`）已实施并随 `v0.1.2` 发版（2026-09-22）；v0.1.3 支持矩阵提升（`0.1.7-alpha.2`、`0.1.7-rc.1`）已实施并随 `v0.1.3` 发版（2026-09-24）；v0.1.4 支持矩阵提升（`0.1.7-rc.2`）已实施并随 `v0.1.4` 发版（2026-09-25）；v0.1.5 DSH 0.2 支持矩阵提升已发版；v0.1.6 已发版；v0.1.7（第二期 B 系列、Files 页签附加根浏览、DSH `0.2.1-alpha.3`–`0.2.1-rc.2`）已发版；v0.1.8（DSH 0.2.0 `permissionPresets/catalog` 修复：可选包分类取证 + provider 行去门禁化）已发版；v0.1.9（Auto Review 多根上下文以主包内置可选行交付，默认关闭，ADR-0022）已发版；v0.1.10（附属根 Skills、Workspace Folders 面板对齐与 DSH `0.2.1-rc.3`）已发版；v0.1.11（DSH `0.2.1-rc.4` 与 `0.2.2-alpha.2` 支持矩阵提升、Issue #24 Registry／Skills 刷新循环 hot-fix）已发版；v0.1.12（多 Host 共享 Registry 权威服务与逐操作授权、DSH `0.2.1-rc.5` 支持矩阵提升）已发版；v0.1.13（F4 后台恢复与 Files 页签根选择修复）随 `v0.1.13` 发版；v0.1.14（Issue #30 依赖单例修复与 koffi 宿主锚定、DSH `0.2.2-alpha.3`/`0.2.2-rc.1` 兼容提升、插件详情页设置卡 Auto Review 开关与富文本详情）随 `v0.1.14` 发版；v0.1.15（`/add-dirs` 别名、根授权安全修复与 OPS 默认关闭的实验性兜底及开启风险确认）随 `v0.1.15` 发版；v0.1.16（准入外受限 spawn 修复、面板会话存在性细分与预览页 Folder 导航树附加根接管）随 `v0.1.16` 发版；v0.1.17（Worktree 附加根建议与 linked worktree 主 checkout 授权、新会话 Hero 与工作区菜单 Workspace Folders 入口、已批准的一次性 Full-access 提权）随 `v0.1.17` 发版；v0.1.18（精确支持 DSH `0.2.2-rc.2`，Files 页签搜索纳入共享准入与根边界）随 `v0.1.18` 发版；v0.1.19（精确支持 DSH `0.2.2-rc.3`，支持合同扩至 24 个精确版本）随 `v0.1.19` 发版；v0.1.20（附加根 Files 行右键与工作区搜索、Auto Review 两代 9 个精确发布联合支持、Worktree 提示与确认 Dialog 重构、新会话 Hero 入口宽度自适应）随 `v0.1.20` 发版；v0.1.21（附加根预览导航树的工作区搜索、Files 页接管提示、koffi 宿主提供、Worktree 关闭按钮与清理面板 UX 收敛、侧栏 footer 行几何对齐与同槽共存）随 `v0.1.21` 发版；v0.1.22（Files 页头 RootSwitcher 窄宽让位与三档根名显示、精确支持 DSH `0.2.2-rc.4`）随 `v0.1.22` 发版；v0.1.23（面板与详情页 8 语言本地化、8 语言根 README 与逐功能用户指南、贡献与安全治理、精确支持 DSH `0.2.2-rc.5`）随 `v0.1.23` 发版；v0.1.24-beta.1（SSH 远端环境个人模式，实验性、默认关闭；Workspace Folders 附加根列表滚动修复）随 `v0.1.24-beta.1` 发版；v0.1.24-beta.2（SSH 依赖修复引导与 Helper 安装诊断）随 `v0.1.24-beta.2` 发版；v0.1.24-beta.3（SSH 转发流的 BoringSSL PSK 回退）随 `v0.1.24-beta.3` 发版；v0.1.24-beta.4（活跃 SSH 连接下卸载插件的 Host 退出修复、随插件发行的 SSH 依赖安装命令与 Desktop 一键安装入口）随 `v0.1.24-beta.4` 发版；第二期（B 系列）范围见[需求文档 §4/§7](../../requirements/multi-root-workspace.md)。
> 设计依据：[multi-root-workspace.md](../../architecture/multi-root-workspace.md)；验收标准见 [multi-root-workspace.md](../../requirements/multi-root-workspace.md) §5。
> 产物是本仓库（`dsh-plugin-multi-root-workspace`，包 `@dsh-electron/dsh-plugin-multi-root-workspace`），经 `dsh plugin --profile <name> add <path|git>` 安装；对上游仓库（deepseek-harness）零改动。
> 插件仓库自建门禁（上游 `verify-cordis-config` 等仓库 gates 不适用）：lint + typecheck + vitest 全绿 + patch 快照测试。

## 编号口径

先读这一段，再读历史文档与评审材料。
本仓库同时存在「里程碑」与「批次」两套编号，历史文档、评审材料与 commit 各用其一，因此先约定：

- **M1 / M2 / M3** = MVP（`v0.1.0`）的三个里程碑（2026-09-12 实施，2026-09-13 发版）。
- **M4** = 跨进程 Registry Authority Lease（2026-09-15 加入路线图）。它与 v0.1.1 批次的 **H1 是同一件事的两个名字**：路线图叫 M4，批次叫 H1。
- **H1–H4** = v0.1.1 硬化批次的四项任务：H1 lease（= M4）、H2 面板主根改为 host session 推导、H3 DSH 兼容性代码契约、H4 附加根指令注入。
- **H4 分两期**：Phase 1（附加根**顶层** `AGENTS.md` / `CLAUDE.md`）与 Phase 2（nested instructions：由本会话**成功**触碰过的目录链增量补投）**均已实现**，见 [ADR-0010](../../decisions/ADR-0010-additional-root-instruction-scope.md)。
- 外部评审材料若用「M1–M4」指 v0.1.1 的四项，对应关系为：其 M1 = H1、其 M2 = H2、其 M3 = H3、其 M4 = H4。

## 进度总账

本表是**进度、编号与发布状态的唯一真源**；其他文档只链接到这里，不复制。

| 批次 | 编号 | 任务 | 详细计划 | ADR | commit | 发布状态 |
|---|---|---|---|---|---|---|
| MVP | M1 | 组合与空根直通：bundle 骨架、两行 provider 替换 | [M1 计划](../completed/2026-09-12-m1-composition-and-passthrough.md) | [0001](../../decisions/ADR-0001-provider-replacement-scope.md)、[0002](../../decisions/ADR-0002-upstream-coupling-policy.md) | `d9e5afb`…`faf0ef7` | `v0.1.0` |
| MVP | M2 | 附加根数据源、两个 provider 的多根逻辑、方言 grant、parity 矩阵 | [M2 计划](../completed/2026-09-12-m2-additional-roots-and-dialect-grants.md) | [0003](../../decisions/ADR-0003-dialect-grant-widening.md) | `852d2d4`…`f650143` | `v0.1.0` |
| MVP | M3 | root 注册表、`/workspace-folders`、Workspace Folders 面板、跨仓库旅程 e2e（含外部评审两轮返工） | [M3 计划](../completed/2026-09-12-m3-root-registry-command-and-ui.md) | [0004](../../decisions/ADR-0004-root-registry-persistence-and-validation.md)、[0005](../../decisions/ADR-0005-out-of-tree-client-transport.md)、[0006](../../decisions/ADR-0006-client-ui-host-tokens.md) | `ff235ae`…`fd1ab18` | `v0.1.0` |
| v0.1.1 | H1（= M4） | 跨进程 Registry Authority Lease：store-wide 内核 lease、争用 fail-closed、`refresh()` 接管 | [M4 计划](../completed/2026-09-15-m4-registry-authority-lease.md) | [0007](../../decisions/ADR-0007-registry-authority-lease.md) | `aa4b19e` | `v0.1.1` |
| v0.1.1 | H2 | 面板主根改为 host session 推导（删除客户端 `primaryRoot`） | [面板计划](../completed/2026-09-15-panel-session-derived-authority.md) | [0008](../../decisions/ADR-0008-panel-session-derived-authority.md) | `66375ca` | `v0.1.1` |
| v0.1.1 | H3 | DSH 兼容性从文档约定变成启动门禁 + `src/compat/` 适配层 + 按周升级车道 | [compat 计划](../completed/2026-09-15-dsh-compat-contract.md) | [0009](../../decisions/ADR-0009-dsh-compat-contract.md) | `d4b16ff` | `v0.1.1` |
| v0.1.1 | H4 Phase 1 | 附加根顶层 `AGENTS.md` / `CLAUDE.md` 以 `form=instructions` 注入模型上下文 | 同上 §5 | [0010](../../decisions/ADR-0010-additional-root-instruction-scope.md) | `d4b16ff` | `v0.1.1` |
| v0.1.1 | H4 Phase 2 | 附加根 nested instructions：本会话成功触碰过的子目录增量注入、变化重发、消失撤回 | 同上 §5b（该设计草案的实现） | [0010](../../decisions/ADR-0010-additional-root-instruction-scope.md) | `507c954`…`76c6377` | `v0.1.1` |
| v0.1.2 | compat | DSH 支持矩阵扩展至 `0.1.6-alpha.2` 与 `0.1.7-alpha.1`；`0.1.6-alpha.2` 面板 Session 目录 `retainedBy.mainView` 探针 | — | [0009](../../decisions/ADR-0009-dsh-compat-contract.md) | `318ff52`…`6e68a0b` | `v0.1.2` |
| v0.1.3 | compat | DSH 支持矩阵扩展至 `0.1.7-alpha.2` 与 `0.1.7-rc.1`；形状未变，`rc.1` 安装期 peer 门禁要求精确 peer | — | [0009](../../decisions/ADR-0009-dsh-compat-contract.md) | `10381fc` | `v0.1.3` |
| v0.1.4 | compat | DSH 支持矩阵扩展至 `0.1.7-rc.2`；相对 `rc.1` 形状未变，无新适配分支，cordis 仍是 `~4.0.4` | — | [0009](../../decisions/ADR-0009-dsh-compat-contract.md) | `f2a8f75` | `v0.1.4` |
| v0.1.5 | compat | DSH 支持矩阵扩展至 `0.2.0-rc.1` / `0.2.0-rc.2`，开发 pin 升级，全部支持版本 × OS 的持续矩阵 | [本次记录](#dsh-02-兼容提升2026-09-30) | [0009](../../decisions/ADR-0009-dsh-compat-contract.md) | `135af7f` | `v0.1.5` 已发布 |
| v0.1.6 | DSH 0.2.1 + B1–B3 + ADR-0012 | DSH `0.2.1-alpha.1` / `.2`；Session origin 与动态 cwd 分离；附加根 LSP、Windows ACL、文件树与 Worktree | [B1–B3](#b1b3第二期-p12026-10-02)、[DSH 0.2.1](#dsh-021-迁移与目录安全契约2026-10-10) | [0011](../../decisions/ADR-0011-multi-root-workspace-consumers.md)、[0012](../../decisions/ADR-0012-session-origin-and-effective-cwd.md) | `466b3bb` | `v0.1.6` |
| 第二期 | B1–B3 加固与 Windows 全量验证 | 每个消费者补原生执行证据、Windows fail-closed、打包产物与 Windows 冒烟入全平台门禁 | [本节](#b1b3-加固与-windows-全量验证2026-10-11) | [0011 修订](../../decisions/ADR-0011-multi-root-workspace-consumers.md) | `9f9a1df`…`a385f06` | `v0.1.7` |
| 第二期 | B4 per-root / per-tool 权限 | 根自带 read-write / read-only 访问级别；`toolAccess` 按工具封顶附加根写权限（ALS 经 `tools/execute`）；命令与面板 surface | [B4–B8](./2026-10-11-b4-b8-p2.md) | [0013](../../decisions/ADR-0013-per-root-and-per-tool-access.md) | `99a443f`…`1758885`、`980b925`、`8e770c9`…`f4fc3df` | `v0.1.7` |
| 第二期 | B5 mutation 前重分类 | 每个 mutation 的 serialize job 以存储记录重新分类再校验；revive 只看 fresh 分类 | [B4–B8](./2026-10-11-b4-b8-p2.md) | [0004 修订](../../decisions/ADR-0004-root-registry-persistence-and-validation.md)、[0014](../../decisions/ADR-0014-root-limit-and-provider-conflict.md) | `a3240b1`、`395e32b` | `v0.1.7` |
| 第二期 | B6 附加根数量上限 | `maxAdditionalRoots` 默认 16、顶 64；按全部存储记录计数；超限存量照授只拒新增；非法配置 fail closed | [B4–B8](./2026-10-11-b4-b8-p2.md) | [0014](../../decisions/ADR-0014-root-limit-and-provider-conflict.md) | `067933f` | `v0.1.7` |
| 第二期 | B7 provider 冲突检测 | 品牌 + `multi-root-providers` 门禁；外来 `ctx.fs`/`ctx.sandbox` 下注册表缺席、scope 为空 | [B4–B8](./2026-10-11-b4-b8-p2.md) | [0014](../../decisions/ADR-0014-root-limit-and-provider-conflict.md) | `2a36d5f` | `v0.1.7` |
| 第二期 | B8 平台感知提示词 | `renderWorkspaceRootsContext` 纯函数化；按模式/平台/访问级别陈述授权；win32 附带 partial-enforcement 说明 | [B4–B8](./2026-10-11-b4-b8-p2.md) | [0013](../../decisions/ADR-0013-per-root-and-per-tool-access.md) | `a7f3d20` | `v0.1.7` |
| 第二期 | B9 附加根三态权限与跨 SandboxMode 执行一致性 | 继承 / 只读 / 读写；显式根权限覆盖会话模式默认行为，文件与新进程执行一致；先验证 Full-access 局部限权 | [B9 计划](../completed/2026-10-13-b9-root-access-and-sandbox-modes.md) | [0017](../../decisions/ADR-0017-three-state-root-access-and-sandbox-modes.md)；并修订 [0001](../../decisions/ADR-0001-provider-replacement-scope.md)/[0003](../../decisions/ADR-0003-dialect-grant-widening.md)/[0011](../../decisions/ADR-0011-multi-root-workspace-consumers.md)/[0012](../../decisions/ADR-0012-session-origin-and-effective-cwd.md)/[0013](../../decisions/ADR-0013-per-root-and-per-tool-access.md) | `55c6260` | B9 实施与原生验收完成；Windows 普通 deny-only 组与暂停赋值、Linux bubblewrap 补局部只读；保留 Windows partial 边界；随 `v0.1.7` 发版 |
| 第二期 | 分支安全审查修复（R1–R4） | 负授权规则统一（R2/R3）、Windows 祖先路径稳定性（R1）、硬链接失败关闭与 profile 隔离（R4） | [审查计划](./2026-10-16-branch-security-review-and-hardlink-isolation.md) | [0017 修订](../../decisions/ADR-0017-three-state-root-access-and-sandbox-modes.md)、[0004 修订](../../decisions/ADR-0004-root-registry-persistence-and-validation.md)、[0020 修订](../../decisions/ADR-0020-windows-normal-deny-groups.md) | `55c6260` | Phase A（R2/R3）、B（R1）、C1（全根硬链接预检）与 C2（`/workspace-folders isolate-profiles` 命令、迁移与冒烟）已实施，门禁已执行（771 通过 / 49 跳过，冒烟四项实跑通过）；POSIX 原生内核未验证；随 `v0.1.7` 发版 |
| 第二期 | Files 页签附加根浏览（P1–P11） | `RootSwitcher` 根切换器 + 复刻的 `RootFileTree` 接管树区；open-in-app fork 重定向到选中根；面板徽标、`PathCopy`、确认层与下拉选择器 | [P1–P11](#files-头部根浏览-p1p112026-10-12未发布) | [0015](../../decisions/ADR-0015-files-tab-plugin-owned-browsing.md)、[0016](../../decisions/ADR-0016-files-tab-native-tree-fork.md) | `79f6934`…`a43cbc0` | `v0.1.7` |
| compat | DSH 0.2.1 后续提升 | DSH 支持矩阵扩展至 `0.2.1-alpha.3`–`0.2.1-rc.2` 五个精确版本；storage-domain zod 分裂适配、warn 车道 allow-version 预授权 | [本次记录](#dsh-021-后续兼容提升2026-10-17) | [0009](../../decisions/ADR-0009-dsh-compat-contract.md) | `eaf2d8f` | `v0.1.7` |
| compat | DSH 0.2.1-rc.3 提升 | DSH 支持矩阵纳入 `0.2.1-rc.3`；上游差异全部为新增（sidebar 槽位、导航 pins、DeepSeek `/models`），无新适配分支；开发 pin 升级 | [本次记录](#dsh-021-rc3-兼容提升2026-10-23) | [0009](../../decisions/ADR-0009-dsh-compat-contract.md) | `bddeae3` | `v0.1.10` |
| compat | DSH 0.2.1-rc.4 与 0.2.2-alpha.2 提升 | DSH 支持矩阵纳入 `0.2.1-rc.4` 与 `0.2.2-alpha.2`；测试栈补 `sessionProjections` 注入与执行器结构探测；fork 基线前移 `f3803c9697`；CI 按版本分流 Node 22/24；升级脚本补 cordis 生态 pin 防混树；开发 pin `0.2.2-alpha.2` / cordis `4.0.6-alpha.1` | [本次记录](#dsh-021-rc4-与-022-alpha2-兼容提升2026-10-28) | [0009](../../decisions/ADR-0009-dsh-compat-contract.md) | `08795a1` | `v0.1.11` |
| compat | DSH 0.2.1-rc.5 提升 | 支持合同纳入 `0.2.1-rc.5`；保留原有版本和开发 pin，不新增 adapter 分支 | [本次记录](#dsh-021-rc5-兼容提升2026-10-30) | [0009](../../decisions/ADR-0009-dsh-compat-contract.md) | `7bb642e` | `v0.1.12` |
| compat | DSH 0.2.0 `permissionPresets/catalog` 修复 | 可选包按"谁加载副本、经哪个锚点"分三类取证（运行时加载 / 宿主服务 / runner 锚定），link: 检出不再幻影混装；两个 provider 行不再 inject 门禁，被拒安装退化为上游等价而非拖死 `ctx.fs`/`ctx.sandbox`/`ctx.shell`/`permissionPresets` | [本次记录](#dsh-020-permissionpresetscatalog-修复2026-10-18) | [0009 修订](../../decisions/ADR-0009-dsh-compat-contract.md) | `f6d81de` | `v0.1.8` |
| 第二期 | 后续 P3 项 | Registry observer 语义、TOCTOU 表述、workspace 导入导出、SDK API 等 | 见[需求文档 §4/§7](../../requirements/multi-root-workspace.md) | — | — | 未开始 |
| 兼容协作 | Auto Review 多根上下文 | 拓扑/有效访问权限/当前项目约束的可信输入；可选外部兼容层及联合验证 | [适配计划](../completed/2026-10-18-auto-review-context-adaptation.md)、[源码调研](../../reference/auto-review-compatibility.md) | [0021](../../decisions/ADR-0021-auto-review-context-companion.md) | `feat/compat-auto-review` | Phase 0–2 已实施；本机验收与旧版回归见[本次记录](#auto-review-多根上下文适配2026-10-18)；仅联合目标 `0.2.1-rc.2`；独立 companion 交付形态在发布前被 ADR-0022 取代，能力以内置行随 `v0.1.9` 发版；Phase 3 不在本批范围 |
| 兼容协作 | Auto Review 多基线适配 | 联合合同从单一 `0.2.1-rc.2` 扩为两个冻结上游源码基线的 9 个精确发布：`0.2.1-rc.2`–`rc.5`（legacy fork）与 `0.2.2-alpha.2`–`rc.3`（current fork）；按车道动态加载实现、按基线编译 pin 做实现类型检查、`0.2.2-alpha.2` 请求身份例外、跨代测试/冒烟/CI 门禁 | [适配计划](../completed/2026-11-14-auto-review-multi-baseline.md)、[接口审查](../../reference/auto-review-0.2.2-migration.md) | [0040](../../decisions/ADR-0040-auto-review-multi-baseline.md) | `5abf849`、`96a544b` | 实施与验收证据见[本次记录](#auto-review-多基线适配2026-11-14)；开发 pin 不再声明联合支持版本；随 `v0.1.20` 发版 |
| 兼容协作 | Auto Review 内置入口迁移 | companion 并入主包：`./auto-review` 导出 + 默认 `disabled` 的 `multi-root-auto-review` 行；loader 生命周期接管/恢复；configure、独立 manifest 与第二 tarball 退役 | [评审记录](../completed/2026-10-20-auto-review-in-package-review.md)、[迁移记录](#auto-review-内置入口迁移2026-10-20) | [0022](../../decisions/ADR-0022-auto-review-loader-entry.md) | `9138084`…`e4804fb` | `v0.1.9` |
| 第二期 | 附属根 Skills（S1–S7） | 附属根 `.dsh/skills` / `.agents/skills` 发现、`/alias-id:skill-name` 命名空间调用、每根开关与 `aliasId`、全局 Settings 开关；native effective-cwd 旁路封堵 | [实施计划](../completed/2026-10-23-multi-root-skills.md)、[本次记录](#multi-root-skills-架构验证2026-10-23) | [0023](../../decisions/ADR-0023-multi-root-skill-discovery-and-invocation.md) | `1218543`…`e2c6fb1` | `v0.1.10` |
| hot-fix | Issue #24 Registry／Skills 刷新循环 | `setRegistryAuthority()` 仅在实际状态变化时通知，阻断 Skills 失效 → `skills/change` → 客户端重查的无界反馈循环；lease 重试、接管与 fail-closed 语义不变 | [本次记录](#issue-24registryskills-刷新循环-hot-fix2026-10-29) | [0023 修订](../../decisions/ADR-0023-multi-root-skill-discovery-and-invocation.md) | `c53c8a9` | `v0.1.11` |
| Long-term | 多 Host 共享 Registry 权威服务 | 实现完成；本机、最早同步基线、19 精确版本 × 三平台 CI 与 macOS 真实 TUI 长跑已验收；Ubuntu 报告环境长跑复测遗留 | [专项计划](./2026-10-30-shared-registry-authority.md)、[本次记录](#多-host-权威服务开发2026-10-29) | [0024](../../decisions/ADR-0024-registry-operation-admission.md)、[0025](../../decisions/ADR-0025-shared-registry-authority.md) | `abdb5c6` | `v0.1.12` |
| Long-term | F4 后台恢复与故障诊断 | 自动恢复、投影同步与诊断；三平台 CI 验收，真实 TUI soak 暂缓 | [专项计划](./2026-10-31-f4-background-recovery.md)、[本次记录](#f4-后台恢复与故障诊断立项2026-10-31) | [0026](../../decisions/ADR-0026-registry-background-recovery.md) | `0b2102c`…`8b3f22b` | 随 `v0.1.13` 发版 |
| 第二期 | Files 页签根选择修复 | 打开文件后的页签重挂载保留根选择与目录树状态 | [ADR 修订](../../decisions/ADR-0016-files-tab-native-tree-fork.md) | [0016](../../decisions/ADR-0016-files-tab-native-tree-fork.md) | `4cb8822` | 随 `v0.1.13` 发版 |
| hot-fix | Issue #30 DSH 核心包移出 dependencies | `schemastery` / `node-addon-system` 移入 `peerDependencies` 由宿主供给唯一副本；`koffi` 经 `loadHostKoffi()` 锚定宿主副本（darwin-arm64 SIGBUS）；`compat:check` 拒绝 `dependencies` 里的 `@deepseek-ai/*` | [本次记录](#issue-30dsh-核心包移出-dependencies2026-11-01)、[排查](../../troubleshooting/profile-core-mixed.md) | [0009 修订](../../decisions/ADR-0009-dsh-compat-contract.md) | `c9dc4a0` | 随 `v0.1.14` 发版 |
| compat | DSH 0.2.2-alpha.3 提升 | fs `patchText`/`deleteFile`/`moveFile` 纳入围栏与 Registry admission；Connection RPC getter 绑定消费 fiber 修复 HTTP 405；Files 页签改用宿主文件树 Factory；开发 pin `0.2.2-alpha.3` / cordis `4.0.6-alpha.2` | [本次记录](#dsh-022-alpha3-兼容适配2026-11-04)、[接口审查](../../reference/dsh-0.2.2-migration.md) | [0009](../../decisions/ADR-0009-dsh-compat-contract.md)、[0024 修订](../../decisions/ADR-0024-registry-operation-admission.md) | `9035ab0` | 随 `v0.1.14` 发版 |
| compat | DSH 0.2.2-rc.1 提升 | 支持合同纳入 `0.2.2-rc.1`（22 个精确版本）；开发 pin `0.2.2-rc.1` / cordis `4.1.0` / schemastery `3.19.0`；稳定 vendor 选择器限宿主声明 minor 线；未新增适配分支 | [本次记录](#dsh-022-rc1-兼容适配2026-11-05)、[接口审查](../../reference/dsh-0.2.2-migration.md) | [0009](../../decisions/ADR-0009-dsh-compat-contract.md) | `1c025b2` | 随 `v0.1.14` 发版 |
| compat | DSH 0.2.2-rc.2 提升 | 支持合同纳入 `0.2.2-rc.2`（23 个精确版本）；开发 pin `0.2.2-rc.2` / cordis `4.1.0` / schemastery `3.19.0`；`registerWritableRoot`、`workspaceFiles.search`、Windows ACL 语义翻转审查与回归；open-in-app fork 基线 `ddac96760b`；未新增适配分支 | [本次记录](#dsh-022-rc2-兼容提升2026-11-12)、[接口审查](../../reference/dsh-0.2.2-migration.md#022-rc2-后续审查2026-11-11) | [0009](../../decisions/ADR-0009-dsh-compat-contract.md) | PR #49 | 评审返工 HEAD `eafabcb` 的全矩阵 CI 已通过：[run 43227479998](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43227479998)，**94/94 jobs**（23 个精确版本 × macOS / Ubuntu 22.04 / Ubuntu latest / Windows）；其后仅文档状态更新；随 `v0.1.18` 发版 |
| compat | DSH 0.2.2-rc.3 提升 | 支持合同纳入 `0.2.2-rc.3`（24 个精确版本）；开发 pin `0.2.2-rc.3` / cordis `4.1.0` / schemastery `3.19.0`；上游差异全部为新增（新会话行 HOC 槽、`workspace.picker` Factory 与第三个 directory-flow 洞、上传图标、可选实验 bundle `dsh-deepseek-chat-import`），沙箱/fs/tools/session/storage 运行时源码未变，未新增适配分支；open-in-app 与 files-tree 复刻基线不变 | [本次记录](#dsh-022-rc3-兼容提升2026-11-13)、[接口审查](../../reference/dsh-0.2.2-migration.md#022-rc3-后续审查2026-11-13) | [0009](../../decisions/ADR-0009-dsh-compat-contract.md) | PR #52（`cbda993`） | 本机门禁已通过（compat / lint / 双端 typecheck / build / docs / pack / auto-review / 完整 vitest 与三个 smoke）；合入 `main` 后的 CI [run 43469327214](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43469327214) **30/30 jobs 通过**（24 个精确版本 × macOS / Ubuntu 22.04 / Ubuntu latest / Windows，含原生 ACL 与 gate）；随 `v0.1.19` 发版 |
| compat | DSH 0.2.2-rc.4 提升 | 支持合同纳入 `0.2.2-rc.4`（25 个精确版本）；开发 pin `0.2.2-rc.4` / cordis `4.1.0` / schemastery `3.19.0`；Auto Review 联合集合扩到 10 个精确发布、current 编译 pin 前移到 rc.4；上游差异只有 DeepSeek 内容审查拒答（新增 `CONTENT_REFUSED`）、liveshare 实验包与文档/快照，沙箱/fs/session/storage/client/reviewer 源码逐树未变，未新增适配分支 | [本次记录](#dsh-022-rc4-兼容提升2026-11-18)、[接口审查](../../reference/dsh-0.2.2-migration.md#022-rc4-后续审查2026-11-18) | [0009](../../decisions/ADR-0009-dsh-compat-contract.md)、[0040 修订](../../decisions/ADR-0040-auto-review-multi-baseline.md#修订2026-11-18) | `45950f6`（PR #68） | 本机门禁已通过（compat / peers / lint / 双端 typecheck / build / docs / pack / auto-review / kernel probe / 完整 vitest 与四个 smoke + joint Auto Review smoke）；三 OS 矩阵与原生 ACL 结果由合入 `main` 后的 push CI 给出（[run 44260988200](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/44260988200)）；随 `v0.1.22` 发版 |
| compat | DSH 0.2.2-rc.5 提升 | 支持合同纳入 `0.2.2-rc.5`（26 个精确版本）；开发 pin `0.2.2-rc.5` / cordis `4.1.0` / schemastery `3.19.0`；Auto Review 联合集合扩到 11 个精确发布、current 编译 pin 前移到 rc.5；上游差异只有 DeepSeek 联网搜索的按模型路由选择（`dsh-web` / `dsh-tool-web` / `dsh-web-search-deepseek` / 设置卡片）与文档、e2e、快照，插件消费的沙箱/fs/session/storage/client/reviewer 源码逐树未变，未新增适配分支 | [本次记录](#dsh-022-rc5-兼容提升2026-11-18)、[接口审查](../../reference/dsh-0.2.2-migration.md#022-rc5-后续审查2026-11-18) | [0009](../../decisions/ADR-0009-dsh-compat-contract.md)、[0040 修订](../../decisions/ADR-0040-auto-review-multi-baseline.md) | `ac13ce7`（PR #70） | 本机门禁通过（compat / peers / lint / 双端 typecheck / build / docs / pack / auto-review / kernel probe / 完整 vitest 与 smoke）；PR 的 CI [run 44439046316](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/44439046316) 成功，合入 `main` 后的 push CI [run 44443312370](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/44443312370) 准备时仍在运行（最终判定由 `release.yml` 的 verify 等待同 SHA 的 main CI 与最终 `gate`）；随 `v0.1.23` 发版 |
| 第二期 | 插件详情页设置卡与富文本详情 | 「多根 Auto Review（实验性）」设置开关与 Loader 行等价（`setPluginEnabled` 持久化、热应用、restart-required Toast）；设置卡错误改 Toast；`refreshSeq` 修并发刷新竞态；locale `meta.detail` + `preview.svg` 富文本详情 | [本次记录](#插件详情页设置卡与富文本详情2026-11-05) | — | `220bc82` | 随 `v0.1.14` 发版 |
| 安全修复 | 根授权安全修复 P0–P4 | BYP-01、MRW-01、BYP-02、home/物理介质保护与默认权威 | [专项计划](../completed/2026-11-05-root-authorization-security-fixes.md)（含 P0 记录与维护者决定） | [0027](../../decisions/ADR-0027-revive-target-and-protected-paths.md)（P1）、[0028](../../decisions/ADR-0028-upstream-primary-identity-and-shared-only-registry.md)（F3、移除单进程模式） | `a492976`（PR #39） | 2026-11-05：P0 静态证据已记录，维护者决定 P2（可信确认）不实施、BYP-01 作为残余风险保留、Skills migration 保持现状；P1 已实施；F3 改为以上游主根拼写为 key、拒写优先于主根，单进程 Registry 模式移除。PR #39 两条 P1 评审回归先红后绿：Follower 的 fs/进程准入同样收窄 home 授权，迁移后清空在刷新、准入和重启后均不恢复旧根（见两份 ADR 的同日修订）。macOS / Node `24.18.0` / DSH `0.2.2-rc.1` 的 `compat:check` 与完整 `verify:all` 通过：lint、双端 typecheck、build、Seatbelt 内核探针及显式要求实跑的测试（74 文件通过，1019 通过、86 平台跳过）、compose / behavior / journey（52 / 137 / 76）、pack 与 packed behavior（136）、Auto Review fork 检查；可选 Auto Review 集成按精确版本规则跳过。Linux/Windows 原生门禁见下述合入 CI。P2、F5 与 F4 执行侧 deny 按维护者决定不实施（上游对工作区内的 `$DSH_HOME` 本就不设例外）；合入 PR #39（`a492976`），[main CI 42165203436](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/42165203436) 全矩阵通过；随 `v0.1.15` 发版 |
| 兼容协作 | OPS 实验性保守兜底（ADR-0029） | 默认关闭；DSH `0.2.*` 显式启用与 UI 风险确认；受限执行、Phase A 实时活动及精确基线 Review | [已完成计划](../completed/2026-11-01-ops-compatibility-adaptation.md)、[P6 验收](#ops-p6-最终验收2026-11-05) | [0029](../../decisions/ADR-0029-ops-file-authorization-and-activity-adapter.md)（限定范围 Accepted） | `3fdf12d`（PR #40） | P0–P6 限定范围已验收，[main CI 42183917954](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/42183917954) 全矩阵通过；完整兼容恢复无限期延后；随 `v0.1.15` 发版 |
| 第二期 | `/add-dirs` 命令别名 | 复用 `/workspace-folders add` 的路径、访问选项、选择器及校验 | [用户指南](../../guide/README.md#workspace-folders-命令的完整语义) | — | `a7a85b4`（PR #38） | 随 `v0.1.15` 发版 |
| 兼容协作 | 准入外受限 spawn 修复（forge bundle Git 面板报错） | `v0.1.12` 起 forge 等第三方插件的「裸 `confine→spawn`」被进程围栏硬拒；scope 增加按**铸造时**发布代次键控的台账（放行 = 本进程刚铸出的无帧主根形态 profile 且授权基线未被超越；`operationFrameState` 三态分流：过期准入帧的 mint 直接丢弃不落账；`captureMint` 形态标记机械限定台账只收 `clamped`/`read-only`，`restrictedExecution` 等 ambient mint 无帧即死），同时 `ctx.inject` 按 `compat/forge-entrypoints.ts` 清单包装上游 `worktrees`/`forgePanel` 可达入口取真准入（准入获取失败退回无准入执行，方法体错误照常传播）；OPS 域与保护窗口对台账 mint 一律严格（只认存活准入帧内铸造） | — | [0035](../../decisions/ADR-0035-unadmitted-confined-spawn.md) | `59b2e03`、`16f2a2a`（复审加固）、`c235bee`（二次复审）、`0dd7009`（三次复审）、`afb6c1f`（PR #41） | 随 `v0.1.16` 发版；验证环境为 macOS 宿主（Seatbelt 可用、`nativeHostAvailability` 通过）：lint / typecheck / 全量 vitest（含台账竞态、ambient 落账拒绝、同内容重发布保留、准入回退与 OPS 守卫新回归）通过；台账核心用例无能力门禁（单元素 confine 链不执行 `sandbox-exec`），受限宿主与 Linux/Windows CI 均可实跑；存在与本次无关的 follower/lease 环境性失败 |
| hot-fix | 面板「存在但非 live」会话细分 | 会话被另一 Host 的 writer 锁持有、仍在恢复或待迁移时不再误报 `session-not-found`；catch 处复跑 resolver 并探测 `sessionPersistence.stat`，仅在能证明持久化快照存在时改报 `session-not-live`，授权仍只认本进程 live 会话 | [本次记录](#v0116-发版验收2026-11-08) | [0008 修订](../../decisions/ADR-0008-panel-session-derived-authority.md#修订失败码按持久化存在性细分2026-11-07amendment) | `bd1320f`（PR #42） | 随 `v0.1.16` 发版 |
| 第二期 | 预览页 Folder 导航树附加根接管 | 上游 `0.2.2-alpha.3` 的文档预览 Folder 导航树固定会话 cwd；接管 aside 树体到被预览文件所在最长前缀附加根，复刻 reveal（逐层展开、当前行高亮、滚动到位）、`replaceTab` 打开与关闭/重开的展开、滚动记忆；无匹配根时原生树不受影响 | [本次记录](#v0116-发版验收2026-11-08) | [0015](../../decisions/ADR-0015-files-tab-plugin-owned-browsing.md)、[0016](../../decisions/ADR-0016-files-tab-native-tree-fork.md) | `48ef357`…`a3bb4d3`（PR #43） | 随 `v0.1.16` 发版 |
| 第二期 | Worktree 感知的附加根建议与主 checkout 授权 | P1–P7 先完成 B（同 common 的 worktree 建议、手动清理及实验性默认关闭的插件开关），P8–P10 再实施 A（linked primary 的主 checkout 根授权、owner 复验与受限 Git 旅程）；第十九次修订加入单/多候选提示分流 | [计划](./2026-11-09-worktree-aware-root-suggestions.md) | [0039](../../decisions/ADR-0039-worktree-aware-root-suggestions.md) | `21d28f1`（PR #48） | P0–P10、两轮审计修复、第十九次修订与 Devin Review 两条修复已实施。PR #48 的 91 条 CI 检查全部通过，覆盖全部支持 DSH 版本 × macOS/Ubuntu（22.04 与 latest）/Windows；macOS 原生全量、受限 Git 旅程、共享 IPC 与组合/打包冒烟通过。随 `v0.1.17` 发版。第二十次修订（2026-11-14）把自动触发收敛为「会话激活时一次只读检查 + 非模态 Toast + 显式确认 Dialog」，并新增 snooze/sidecar `snooze` 与 `worktreePromptSeen`；本机验证见[第二十次修订验收](#第二十次修订验收2026-11-14)。第二十一次修订（2026-11-15：页面感知的提示位置与形态、手动入口）与第二十二次修订（Dialog 重构与逐行权限选择）见[v0.1.20 发版验收](#v0120-发版验收2026-11-15)；三次修订均随 `v0.1.20` 发版 |
| 第二期 | 工作区菜单「管理工作区目录…」 | 工作区 `...` / 右键菜单复用 footer 对话框：`apply()` 作用域 controller、`workspace` contribution（order 150）、当前会话属于目标时直接打开，否则先经 `openWorkspace` 打开/复用 blank 并确认 current 后固定 session；服务缺失置灰，`RootSwitcher` 与上游 `WorkspaceBrowser` 零改动 | [计划](./2026-11-08-workspace-menu-folders-dialog.md) | [0038](../../decisions/ADR-0038-workspace-menu-folders-dialog.md) | `feat/workspace-menu-ui` | 随 `v0.1.17` 发版；已 rebase 到 `main`（含 #44/#45），完整门禁通过，隔离 Web 宿主目检完成 |
| 第二期 | 附加根 Files 树对齐（行右键 + 工作区搜索） | 附加根 Files 视图补齐与主根一致的行右键菜单（file/directory target 传附加根绝对路径，Factory 转发 `rowTriggerProps`/`canOpen`，旧行同语义，预览 Folder 导航器同样生效）与工作区搜索（插件通道 `search` 端点：会话派生主根、刷新 Registry 解析 `rootId`、单次准入、帧内复核授权；页头开关/搜索栏/命中高亮结果树/偏好浮层/隐藏项过滤，偏好按根存上游 `dsh.sidebar-files.workspace-search.v1`）；结构门控 `useContextMenu`（`0.2.2-alpha.3`+）与 `remote.workspaceFiles.search`（`0.2.2-rc.2`+），旧宿主附加根视图逐字节不变 | [完成计划](../completed/2026-11-14-additional-root-files-parity.md) | [0041](../../decisions/ADR-0041-additional-root-workspace-search.md)、[0042](../../decisions/ADR-0042-additional-root-row-context-menus.md) | `efd51bf`、`530b3a7`、`8a1678e`、`1e2e6ec`、`e91e648`、`420849b`（`feat/addtional-file-tree-1114`） | 实施完成（2026-11-14）；本地门禁 `lint` / `typecheck` / `build` / `test`（1691 通过、17 个既有 sandbox-IPC authority/lease 失败，同一组在基线 `8c09c7b` 亦失败）/ `compat:check` / `docs:check` / `pack:check` 通过，`kernel:probe` 在本沙箱无可受限执行；Draft PR [#56](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/56) 已打开，CI run [https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43585015258](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43585015258) 在 `420849b` 上 30/30 checks 全绿，PR CLEAN/MERGEABLE；随 `v0.1.20` 发版 |
| 第二期 | 附加根 Files code review 修复（4 项） | 修复 PR #56 review：设置浮层 toggle 关闭时提交排除规则草稿；搜索请求身份复用使 body 重挂载不重置展开/滚动（失败重试仍显式）；搜索端点透传上游 `workspace-file/*` 失败码；搜索记录按 session 拥有、tab 所有者死亡时清理（body-only unmount 保留） | [完成计划](../completed/2026-11-14-files-parity-review-fixes.md) | [0041](../../decisions/ADR-0041-additional-root-workspace-search.md)、[0042](../../decisions/ADR-0042-additional-root-row-context-menus.md) | `eb8a430`、`909ec2e`、`83a87f5` | 实施完成（2026-11-14）；focused vitest + lint/typecheck 绿；PR #56 的 CI 在 `64a4868` 上 31/31 checks 全绿（run [43599694607](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43599694607)），详见完成计划 §7；随 `v0.1.20` 发版 |
| 第二期 | 附加根搜索 reload 刷新（R6） | Codex review：搜索结果替换树后，页头 reload 只调 face 刷新、无目录节点可刷，且搜索保留请求身份不重跑，文件变化无法取到。修复：store `refresh` 对非空查询递增 attempt 并清空 settledKey（保留旧结果与位置），RootSwitcher reload 在 face 刷新之外调用它；空查询仍只 re-list 树 | [完成计划](../completed/2026-11-14-search-reload-refresh.md) | [0041](../../decisions/ADR-0041-additional-root-workspace-search.md) | `1dbb201`、`79a902b` | 实施完成（2026-11-14）；focused vitest 37 passed + lint/typecheck/build 绿；PR #56 的 CI 在 `79a902b` 上 31/31 checks 全绿（run [https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43606644577](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43606644577)），详见完成计划 §8；随 `v0.1.20` 发版 |
| 第二期 | 新会话 Hero 入口宽度自适应 | 探针测量工作区行留给该组的余量（减去其他占用、间距与座椅内缩），`max-width` 夹取并允许 label 省略号；余量 < 88px 退化为 28×28 图标；识别上游行结构与共享 slot outlet 的多个占用者，认不出结构时保留原视口回退 | [计划](./2026-11-14-hero-entry-adaptive-width.md) | [0037 修订](../../decisions/ADR-0037-conversation-hero-workspace-folders-entry.md) | `8c09c7b`（PR #53） | 实施完成；CI run [43576034884](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43576034884) success；随 `v0.1.20` 发版 |
| 第二期 | Worktree 提示与确认 Dialog 重构 | 一次只读检查 + 非模态提示、snooze 与共享提醒；页面感知的居中提示卡（主题自适应、primitives、无关闭按钮）；Dialog 加宽 + 连续列表 + Git 分支 + 逐行权限选择 + follower `addNew` 三档授权 | [实施计划](./2026-11-15-workspace-toast-implementation.md)、[Dialog 计划](./2026-11-15-worktree-dialog-redesign.md)、[评审修复](./2026-11-15-worktree-review-fixes.md) | [0039 第二十–二十二修订](../../decisions/ADR-0039-worktree-aware-root-suggestions.md) | `8642af6`（PR #55）、`2208048`（PR #60） | PR #60 的 CI [run 43702749353](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43702749353) 30/30 checks 全绿；合入后 main push CI 见[v0.1.20 发版验收](#v0120-发版验收2026-11-15)；随 `v0.1.20` 发版 |
| 第二期 | Worktree 提示加回圆形关闭按钮 | 收回第二十一次修订「删除 ×」：常驻提示右上角新增 18px 正圆关闭按钮（自绘裸 `button`：primitives 紧凑尺寸会渲染成 28px 圆角矩形，ghost hover 会让悬停变灰；0.5px 描边、圆心相对角点向内收 2px 的视觉重心、允许外凸，`::after` 命中环扩到 24px，悬停不改变表面）；语义为纯关闭——不发 snooze/resolve、不写提醒状态，靠 `seen` 认领保证本 Host 不再自动提示；关闭立即递增 `workEpoch`，在飞提醒完成不能复活提示 | [实施计划](./2026-11-15-worktree-toast-close.md) | [0039 第二十五次修订](../../decisions/ADR-0039-worktree-aware-root-suggestions.md#第二十五次修订2026-11-15) | `53ae34d`（PR #62） | 实施完成（2026-11-15，分支 `feat/worktree-toast-close`）：focused vitest 绿，`lint` / `typecheck` / `build` 绿；PR #62 首轮 GUI 复核要求正圆、缩小且悬停不变色，改为自绘并移除 hover 状态；二次 GUI 复核已通过（正圆、18px、`0.5px` 描边、2px 内收、无 hover 变化）。PR [#62](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/62) 已合入（`53ae34d`），main push CI [run 43736530700](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43736530700) 30/30 成功；随 `v0.1.21` 发版 |
| 第二期 | 附加根预览导航树的工作区搜索 | 预览文件位于附加根时，右侧 Folder 导航树（上游 `FileNavigator`，插件接管树体）复用既有 `search` 端点与 `FilesPane` 搜索面（新增 preview 模式）：搜索栏常显、结果当前行、隐藏项默认、设置回焦、焦点交接、Escape 顺序与旧宿主降级；Host 零改动 | [计划](./2026-11-16-additional-root-preview-navigator-search.md) | [0043](../../decisions/ADR-0043-additional-root-preview-navigator-search.md) | `2265702`…`882fb2b`、`73bc32c`（PR #65） | P1–P4 实施完成；P5 本机门禁通过（`test` 17 个基线同因失败；三项 smoke/packed/auto-review 全绿），隔离环境交互目检完成并截图 20 张待维护者复核；PR [#65](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/65) 已合入（`73bc32c`），main push CI [run 43843154269](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43843154269) 30/30 成功；随 `v0.1.21` 发版 |
| 第二期 | 侧栏 footer 入口图标与几何对齐、同槽共存 | footer occupant 改用 workspace tree 字形；行几何改为「宿主 token + 旧值 fallback」一份配方（旧 19 版 / 新 5 版逐像素对齐；rail 圆角按其更早的 `0.1.6-alpha.2` 分界处理，22/24 对齐、最老 2 版已知偏差）；本入口挂载期间把 `sidebar.footer.action` 的 slot anchor 改为纵向列，使同槽第二行各占一整行（不隐藏、不读槽账本、不改他人行） | [计划](./2026-11-16-sidebar-footer-row-alignment-and-coexistence.md) | [0044](../../decisions/ADR-0044-sidebar-footer-row-alignment-and-coexistence.md) | `b1bd1d8`、`16b17f9`、`e4c8d41`、`290d7f7`（PR #63） | 实施完成（2026-11-16，分支 fix/sidebar-buttom-style）：footer 图标换 workspace tree；footer 行/按钮/rail 改为 §D2 的 token+fallback 配方（两代逐像素）；§D3 纵向列共存规则；新增 client-styles + client-panel 钉扎。A 修订（用户确认）：按钮高度跟随可见设置行 occupant（`0.2.0-rc.1` 起账号 launcher 未登录 32 / 登录 44，旧代 42 回退，rail 36），修复 hover 药丸与 `⋯ More` 不同高的问题（改动前 42 vs 32，改动后 32/32、模拟登录 44/44）；随后宽度复核发现 hover 的 `background` 简写重置了 `background-clip`，绘制填充 264 vs 宿主 258（两侧各多 3px），改用 `background-color` 长写后两侧均 258（11..269），高宽都与宿主行一致（ADR-0044 §修订三）。`typecheck` / `lint` / `build` / `compat:check` / `docs:check` 绿；全量 vitest 的 17 项失败为既有 registry/lease 环境问题（基线同样失败）。一次性 Chromium 复刻：新几何 20/42、旧几何 18/42（Δ 0），多 occupant 各 272 宽无溢出，rail 22/24 与宿主一致。真实 GUI 目检完成：隔离 scratch `$DSH_HOME` + 本仓库构建产物安装进 `web` profile，`dsh web`（0.2.2-rc.3）经 headless Chromium 截图/测量——宽形态本行 icon/label 20/42 与宿主行一致、rail 两按钮 36×36 @ x=9.5 圆角 12px、同槽两行各占整行无溢出（第二行为合成的克隆行，官方 cordis occupant 空 profile 按设计渲染 null）、A 修订后两行 hover 药丸同高。PR [#63](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/63) 已合入（`290d7f7`），main push CI [run 43834956446](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43834956446) 30/30 成功；随 `v0.1.21` 发版 |
| 第二期 | Worktree 清理面板 UX 收敛（R1–R4） | 批量清理入口从 footer 移到「附属工作目录」标题行；删除确认改为覆盖面板的 primitives `Modal`（批量/单行共用，独立 `cleanupError`，请求中关闭不撤销、成功只清本次 id 数组）；`cleanupEligible` 行收敛为 名称 + 权限徽标 + 路径 + 红色删除 + `…`（移除技能/reveal/重新登记/行内橙字与路径复用提示，披露移入确认层）；手动发现空结果用官方 info `Toast`（自动 fresh 与 notice 竞态空保持静默） | [完成计划](../completed/2026-11-16-worktree-cleanup-panel-ux.md) | [0045](../../decisions/ADR-0045-worktree-cleanup-panel-ui.md)（ADR-0039 第二十六次修订指针） | `aefa190`（PR #64，分支 `fix/worktree-delete-panel`） | 实施与验收完成（2026-11-16）：受影响客户端 199 passed；全量 vitest 1860 passed / 165 skipped / 17 环境性共享 Registry 失败（与既有基线同形）；lint / 双端 typecheck / build / docs:check / kernel:probe / 三 smoke / pack:check / smoke:packed 均按门禁规则执行；隔离 DSH Web 实机目检完成（1280/640/600/560/480 × 浅/深，见[本次记录](#worktree-清理面板-ux-收敛2026-11-16)）。PR [#64](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/64) 已合入（`aefa190`），main push CI [run 43851525562](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43851525562) 30/30 成功；随 `v0.1.21` 发版 |
| 第二期 | Files 页被第三方整页接管时的可见提示（Issue #47） | 第三方插件以 `priority: "extension"` 接管 `files` kind 时宿主不渲染内置 Files 页，根切换器的 seat 永不挂载；读取 `sidebarRightTabs.get('files')` 的生效定义（声明 band + 实现 id 结构探测），确认接管后弹一次官方 info 级瞬时 Toast，同一实现只提示一次、解除后重新武装，缺失服务或定义静默 | [计划](./2026-11-15-files-page-takeover-notice.md) | [0015 修订](../../decisions/ADR-0015-files-tab-plugin-owned-browsing.md#修订files-页被整页接管时的可见提示2026-11-15) | `a3baafd`（PR #61） | 实施完成；main push CI [run 43726552680](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43726552680) 30/30 成功；随 `v0.1.21` 发版 |
| 第二期 | Files 页头 RootSwitcher 窄宽让位 | 窄栏 / 双栏 / 浮动小窗下根名、完整路径、reload / 搜索 / open-in-app 互相重叠：`Menu` 的 anchor 包装 span 是 header 外层 flex item，缺 `min-width: 0` 时被内容 min-content（完整根名）钉死，溢出压住后继控件。修复为三级让位：固定控件不动、路径 `flex: 1 1 0` 先让到 0、anchor 解钉后根名省略、触发器 `overflow: hidden` 最后裁剪；`Menu.className` 24 个受支持发布逐 tag 核对 | [完成计划](../completed/2026-11-17-files-rootswitch-narrow-width.md) | [0046](../../decisions/ADR-0046-files-header-rootswitch-shrink-priority.md) | `3b5d62e`（计划）、`6380ffe`（修复）、`eacbc98`（P5 三档显示）、`f2dd05b`（PR #67） | 实施与目检完成（2026-11-17，分支 `fix/file-tree-rootswitch-width`）：`tests/client-` 28 文件 664 项全绿（新增断言先红后绿），lint/typecheck/docs:check/compat:check 绿；隔离 Web 宿主实测三工况 299/323/220 与附加根接管态重叠全为 0、宽形态 647 几何与改动前逐值相同（计划 §Evidence）。P5 追加三档根名显示：全名 → 前几个…后几个 → 开头…，真实 GUI 逐档实测（520/420 全名；394–299 一头一尾；双栏 233 与浮动 220 只留开头），附加根 `…-ssh` 尾部可辨，全部无重叠（计划 §P5）。评审跟进：Codex P2（应用目录异步加载后出现的 open-in-app 控件占宽但不改变行宽，需重拟合）已修并加先红后绿回归；Devin 关于「单测因原语 stub 无法证明上游 DOM」的分析已核实，证据边界写入 ADR-0046 并修正测试表述。PR [#67](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/67) 已合入（`f2dd05b`），main push CI [run 44117746472](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/44117746472) 30/30 成功；随 `v0.1.22` 发版 |
| hot-fix | `koffi` 改由宿主提供（optional peer） | `koffi` 移出 `dependencies`，改为 optional `peerDependencies` + `devDependencies` 开发 pin；pnpm 不再安装可选 peer，首次 `dsh plugin add` 不再停在构建授权，profile 不再出现第二个 `koffi.node`；`loadHostKoffi()` 依次解析 `DSH_KOFFI_PATH`、`dsh-fs-local` 锚点、宿主入口与 Desktop `app.asar`，无包内回退；`compat:check` 校验开发 pin 与宿主解析副本一致 | [排查](../../troubleshooting/install-stops-at-build-approval.md) | [0007 修订](../../decisions/ADR-0007-registry-authority-lease.md) | `34567ef`（PR #66） | 实施完成；main push CI [run 43889108132](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43889108132) 30/30 成功；随 `v0.1.21` 发版 |
| 多执行环境 | SSH 远端环境（个人模式，Issue #32） | 只开放个人 SSH，默认关闭：插件级连接与凭据文件、Workspace Root 绑定、`remote_copy` 三方向单文件传输、`remote_bash` 两阶段准入、独立 SSH 设置通道与八语言文案、四个 SSH 包的宿主锚定可选 peer 与 `SUPPORTED_SSH_RELEASES` 门禁 | [门禁计划](./2026-11-06-multi-environment-gates.md)、[绑定拆分计划](../completed/2026-11-20-ssh-environments-and-workspace-bindings.md)、[流预算计划](./2026-11-22-remote-copy-stream-budget.md)、[SSH 参考](../../reference/ssh-remote-environments.md) | [0030](../../decisions/ADR-0030-environment-and-root-identity.md)–[0034](../../decisions/ADR-0034-binary-transfer.md)、[0048](../../decisions/ADR-0048-credential-broker.md)、[0049](../../decisions/ADR-0049-ssh-custody-modes.md)、[0050](../../decisions/ADR-0050-add-affordance-and-wizard-kit.md) | `506a52f`（PR #73）、`b4769d6`（PR #72） | 实施完成；真相与证据见[个人 SSH 外部评审后续](#个人-ssh-外部评审后续2026-11-22)及[发版验收](#v0124-beta1-发版验收2026-11-22)；随 `v0.1.24-beta.1` 发版（实验性、默认关闭）；依赖修复引导与 Helper 诊断见下一行 |
| hot-fix | SSH 依赖修复引导与 Helper 安装诊断 | 开启个人 SSH 后按当前 Profile 检查四个 SSH 包（全部缺失／部分缺失／版本不符／私有副本／无法解析／需重启），自动打开修复对话框并给出可复制的 `add --save-exact` 精确版本命令，重检只读且运行中的 Host 不执行包管理器；Helper 安装失败按 `host-preflight`／`ssh-connect`／`remote-prerequisites`／`remote-install`／`artifact-verification`／`entry-generation`／`config-commit` 归因，携带 retryable／remediation／退出码／受限 stderr／期望与实际版本／远端与登记状态，连接页保留可展开详情；OpenSSH 255 只识别标准诊断，远端写操作不因诊断自动重发 | [SSH 参考](../../reference/ssh-remote-environments.md)、[个人 SSH 指南](../../guide/user/ssh-remote-environments.md#安装当前-profile-的-ssh-依赖) | [0049 修订](../../decisions/ADR-0049-ssh-custody-modes.md#2026-11-23-修订由当前-profile-提供-ssh-包) | `8e21ca4`（PR #75） | 实施完成；随 `v0.1.24-beta.2` 发版；发版验收见[本节](#v0124-beta2-发版验收2026-11-23) |
| hot-fix | SSH 转发流的 BoringSSL PSK 回退 | DSH Desktop 的 Electron/BoringSSL 不实现上游为转发流固定的 `PSK-AES256-GCM-SHA384`，Host 在本地创建 TLS 上下文时报 `NO_CIPHER_MATCH`，连接测试成功但远端目录登记中断；Host 端在 BoringSSL 运行时只改写上游 `authenticateStream` 的精确参数形状为 `ECDHE-PSK-CHACHA20-POLY1305`，Helper 安装额外部署 `helper-entry-v3.mjs` 给服务端追加同一套件；`helper-entry.mjs`、记录 `integrity`/`helperPath`/`bindingDigest` 与已登记 Root 不变，plain Node 仍用原套件，旧 Helper 报 `helper-outdated` 重装一次 | [SSH 参考](../../reference/ssh-remote-environments.md)、[排查](../../troubleshooting/ssh-stream-cipher-boringssl.md) | [0051](../../decisions/ADR-0051-ssh-stream-psk-boringssl-fallback.md) | `301f85b`（PR #76） | 实施完成；随 `v0.1.24-beta.3` 发版；发版验收见[本节](#v0124-beta3-发版验收2026-11-23) |
| hot-fix | 卸载时 Host 退出修复与随插件发行的 SSH 依赖安装命令 | 上游 `SshConnection` 在转发流 TLS `secureConnect` 后移除认证期的一次性 `error` 监听、之后才挂上连接自身的永久监听，连接丢失落在该窗口时 `socket.destroy(error)` 成为未处理的 `'error'` 事件并终止 Host；插件在 `tls.connect` 返回时同步为上游转发流套接字附加只吞掉未处理错误的监听（精确匹配上游 stream 选项形状，native 与 BoringSSL 都安装），不替换连接自身的监听、不改变真实掉线的失效与上报、不安装进程级处理器；管理器关闭改为幂等事务（先停止接纳新操作，取消并等待在途传输，再逐项清理 Helper／SFTP 会话／fiber，单资源失败只记诊断并继续）。发布 tarball 新增 `scripts/install-ssh-deps.mjs` 与 `lib/install-ssh-deps.js`：从可信安装上下文确定精确 DSH CLI、Profile、DSH Home 与 Host 版本，以一次结构化 argv 的 `dsh plugin add --save-exact` 把四个 SSH 包对齐到 Host 版本，重复执行为只读就绪；Desktop 启动器显式声明能力时显示「安装并重启」 | [SSH 参考](../../reference/ssh-remote-environments.md)、[个人 SSH 指南](../../guide/user/ssh-remote-environments.md#安装当前-profile-的-ssh-依赖) | — | `ffa53fc`（PR #77） | 实施完成；随 `v0.1.24-beta.4` 发版；发版验收见[本节](#v0124-beta4-发版验收2026-11-23) |
| 第二期 | 面板与详情页 8 语言本地化 | 面板文案按 DSH 内置的 8 种界面语言各一份词典（`src/client/locales/`，中文 canonical，其余以 `satisfies` 钉住键集与占位符）；`locale/<lang>.json` 补齐 `meta.title`/`description`/`detail`；`detail/preview.<lang>.svg` 与 `DETAIL.<lang>.md` 提供 8 语预览插图，生成脚本按槽位实测宽度自适应收缩并在溢出时失败 | [本次记录](#面板与详情页-8-语言本地化2026-11-18) | — | `e5e4417`（PR #69） | 本机门禁：lint、双端 typecheck、build、docs:check、pack:check 通过；全量 vitest 除既有 Registry lease／多进程环境性失败外全部通过。PR 的 CI [run 44336205469](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/44336205469) 成功；合入后的 main push CI [run 44439036440](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/44439036440) 被随后的 #70 推送取代（cancelled）；随 `v0.1.23` 发版 |

### Worktree 感知建议 B/A 实施（2026-11-09）

ADR-0039 第十八次修订的 B（P1–P7）与 A（P8–P10）均已落地。以下保留首次审计返工的阶段记录，现行验证见末条复审记录。

- **P1 元数据快照**：插件自己以 trusted-fd/有界读取打开并解析 config、HEAD、index 与两种 checkout 形态；完整祖先链、Unicode NFC/NFD、split/sparse index、祖先 gitlink、alternates、FIFO/symlink 全部 fail closed；不启动 Git、不解析 commit 对象。单测覆盖真实 Git 夹具（含 linked worktree、separate-git-dir、bare 派生、版本 1、祖先遮蔽、linked worktree 本身是 submodule）。
- **P2 发现与激活**：受控枚举 `<common>/worktrees/*/gitdir`，默认 pool 无特殊规则；`unactivated`/`active`/`lost` 三态、显式恢复、watcher 去抖与 admin 上限降级；实验性默认关闭的 Host 设置复用附属根 Skills 的 Settings 接缝。
- **P3 Prompt RPC/UI**：`WORKTREE_ENDPOINTS` 与双端严格判别联合（禁止 retry 字段）、设置卡第二个 Switch（第十九次修订后带实验性 Tag、默认关闭）、shell overlay；P3 曾以只读预览提交，P4 后确认按钮启用。
- **P4 写路径**：Registry owner 串行队列内的 `addNew`（primary/candidate 完整复验、identity、HEAD、祖先索引、duplicate 不 revive）与 `removeForDeletedWorktree`（`rootId + path + addedAt`，仅确认缺失）；`promptsRoot` 按 `sha256(primaryKey)` 分文件，全部写入在 owner 队列内，损坏即 memory-only；面板徽标、逐条与批量显式清理。
- **P5 竞态**：同路径删除重建、primary `.git` 移走、admin HEAD 变化、候选换 symlink、等待 owner 期间祖先新增 `160000` 均 `worktree/prompt-stale`，且断言 Registry 无写入。
- **P6 验证（首次返工 `db50de6`）**：worktree 专项 11 个 spec（metadata/discovery/contract/channel/write/owner/sidecar/client/common/common-owner/audit-regressions）另有受限 Git e2e，覆盖 ADR §2.5 的布局矩阵与 §5/§6.8 的映射规则；专项 **109 通过、0 失败**，2 个受限 Git 旅程按外层沙箱 `requireKernelRunner` 显式 skip。全量 vitest **1332 通过、161 跳过、17 失败**；17 个失败仍是审计基线同一组共享 IPC / lease 环境失败（当前 Host 自身被沙箱化，follower 无法接管），本次新增用例全部通过。真实 Web 组合的开关关闭/恢复、B 提示确认+清理、A 提示确认已在 `smoke:journey` 的 web leg 通过真实 HTTP Connection RPC 实跑（83 通过、2 skip，skip 为外层沙箱禁止嵌套内核执行）。`smoke:compose` 56 通过；`smoke:behavior` 96 通过、8 按能力 skip。
- **P8 A 候选**：linked primary 的主 checkout 根 `<main> = dirname(common)` 与 B 共用候选池；仅 `workspace-write` 可见，按 session 过滤；`<main>/.git` 必须 canonical 指向 common。默认 pool 的主根包含 primary，`primary-overlap` 使其没有 A；外部 linked checkout 覆盖。
- **P9 A 确认**：owner 重跑完整 primary/common/admin 身份、双向指针、HEAD 语法与祖先索引；A 根为普通 `inherit` 登记，无 sidecar 清理映射，普通 Remove 撤回；等待期间 admin HEAD/反向指针/模式/开关变化都会 `prompt-stale` 或 `not-enabled`。
- **P10 受限 Git 旅程（审计后重写，第十九次修订调整）**：`tests/worktrees-git.e2e.ts` 以外部 linked checkout 为 live session primary；先断言受限 `git add` 写 admin index 被拒，再通过真实 `worktreePromptWait` 取主 checkout 的 A 提示并 `resolve('add')`，然后在同一 `workspace-write` 下完成 `add`/`commit`，核对 index、HEAD 与 common 中的 branch ref；主 checkout 源码现在**在授权内**（可写），无关目录仍拒写；普通 Remove 后新进程再次拒写。默认 pool 用例改为断言无 A 且 `git add` 仍拒写。每一步都通过 `Registry.withOperation` 取得有序准入，再在准入帧内 `confine` 并 spawn（ambient `confine` 按 ADR-0024 看到 unavailable scope）。本机外层沙箱禁止嵌套 Seatbelt，两个用例按 `requireKernelRunner` 显式 skip；Linux/Windows/CI 保持同等门禁。
- **R1 候选 common 绑定**：inventory 要求候选 common 等于枚举 common、admin 就是枚举项、canonical 与 admin 指针目标一致；owner 的 B/A 分支都要求 candidate.common 与 primary.common 相同。回归覆盖同名 admin 指向另一仓库与伪造 expectation。
- **R2 元数据先拒绝再解析（首次返工）**：指针目标在 `realpath` 前逐段拒绝 symlink；父链用 `O_NOFOLLOW|O_DIRECTORY` 打开并复核；POSIX 只按 `/` 分段，祖先 index 保留字面反斜杠；最终文件同 fd `fstat` 与 pre-open `lstat` 比对。
- **R3 提交边界**：`addNew`/`removeForDeletedWorktree`/sidecar mutation 在 owner 队列内、持久化前复查开关；Host 在送交前重读 live session 的 primary、mode、开关与提示代次。
- **R4 清理资格**：owner 内要求 primary 仍激活且当前 sidecar 有 `rootId + path + rootAddedAt` 匹配的 B 映射；inactive reset 与空 reset 不再写 sidecar。
- **R5 提示 ID**：仅完整 expectation 深相等时复用提示；admin HEAD/primary/目录身份变化生成新 ID 并唤醒旧 waiter。
- **R6 客户端恢复**：worktree 设置订阅与面板显式 `list` 的 `notify()` 都能重挂已停止的 overlay；`stale` 后旧 ID 不再重复出现。
- **P4 契约**：IPC `hello` 绑定 `promptsRoot`；follower `snapshotView()` 返回 owner 同一 envelope。
- **第二轮复审验证**：修复原生句柄读取、实际提交边界、发现失效与路径重建警告、IPC 协商及重放和跨平台旅程。逐项实现见[计划](./2026-11-09-worktree-aware-root-suggestions.md#第二轮复审修复2026-11-09)。macOS 原生全量 vitest **1428 通过、96 跳过、0 失败**，包括默认 pool 和外部 linked checkout 的真实 Seatbelt Git 旅程，以及共享 Registry IPC。组合冒烟 **56 通过**、行为 **137 通过**、Web/headless 旅程 **90 通过**、tarball 安装行为 **136 通过**，均无失败或跳过。`lint`、`typecheck`、`build`、`compat:check`、`docs:check`、`pack:check` 通过。Linux / Windows 原生矩阵和实际浏览器设置操作尚待验证。

### 第十九次修订验收（2026-11-10）

- **A 目标**：`main-checkout` 候选 = `dirname(common)`；`<main>/.git` 回指、主根与 admin 身份由 owner 复验；外部 linked checkout 的 A 路径与 Registry 行均为主 checkout 根。
- **默认 pool**：`probeAdd` 因 `primary-overlap` 拒绝主根，`worktrees-common` 与 Git e2e 均断言 pool 无 A、`git add` 仍失败。
- **`--separate-git-dir`**：回归改为断言提示 `dirname(store)`（store 父目录）并在文案中披露歧义；这是本次明确接受的风险。
- **默认关闭/实验性**：`Config` 默认 `false`；发现 spec 新增“默认关闭不激活、不写”用例；客户端新增“worktree 行默认未勾选 + 实验性 Tag”用例；`cordis.patch.yml` 为 `enabled: false`。
- **列表**：`worktrees-contract` 覆盖 `prompt`/`prompts` 两分支与 `promptIds` 去重/上限；`client-worktree` 覆盖默认勾选（B 勾、A 不勾）、批量添加、只提交所选、skipped 行保持未勾选并显示 code；`worktrees-common` 覆盖外部 B+A 列表顺序与 pool 无 A。
- **验证**：worktree 专项 12 个 spec **131 通过、3 skip**；全量 vitest **1356 通过、17 个既有 lease/follower 环境失败**（与审计基线同一组）；`smoke:journey` 的 web leg 覆盖默认关闭、双候选列表、删除 B 后 A 确认与 `.git` 旧根阻塞。
- **迁移**：旧版 `<main>/.git` 根不会被自动替换；主根因嵌套被拒，先在面板手动移除旧根。sidecar 的旧 `git-common` ignore 作为 legacy 读取但不匹配新 key。
- **Devin Review 修复（PR #48，2026-11-11）**：客户端 `enabled()` 不再把缺失或非 ready 的 Settings form 读成“关闭”（只有 ready 的显式值才抑制，宿主 `worktree/not-enabled` 决定）；owner `requireWorktreesEnabled()` 对缺失 provider fail closed。回归见 `tests/client-skills.spec.tsx`、`tests/worktrees-owner.spec.ts`；worktree 相关 spec 与 `client-worktree`/`authority-native` 实跑 134 通过、44 环境 skip，全量 vitest 1362 通过、17 个既有 lease/follower 环境失败（与审计基线同一组）；逐项见[计划](./2026-11-09-worktree-aware-root-suggestions.md#devin-review-修复2026-11-11完成)。

### 第二十次修订验收（2026-11-14）

- **触发收敛**：WorktreePrompt overlay 不再常驻 `worktreePromptWait`。客户端只在「session 从空/其他变为有效 session」时调用一次 `worktreePrompt(sessionId, { fresh: true })`；有候选显示非模态 Toast（`role="status"`、无 backdrop/focus trap、`pointer-events: auto`、`mrfw-` 类名 + host `var(--dsw-*)` token、默认常驻不自动消失；操作「查看」「稍后（until-new-worktree 默认 / 7d / 30d）」「×」），空候选或任何失败一律静默、不重试、无 backoff。只有点「查看」才打开现有确认 Dialog：先 `prompt()`（不带 `fresh`）拿全量 A/B 可见候选，再启动 `wait(seenViewRevision)`；Dialog 关闭立即 abort 且不写任何提示状态。
- **禁止的自动触发**：页面重挂同一 session、设置开关重新开启、面板 `list`、`worktrees.notify()`、新 worktree 的 `fs.watch`、20 秒定时器/窗口 focus/重连退避都不再发起检查；`WorkspaceFoldersAction` 的 `notify()` 调用与客户端 `WorktreeClient.notify/subscribe` 同时移除。新 worktree 只在下一次 session 激活或用户显式入口出现（刻意取舍，写进 ADR §20.2）。
- **宿主契约**：`worktreePrompt` 增加可选 strict `fresh`（纯查询：不写 sidecar/Registry，不改变 `offered`/`prompted`/queue/evaluated）；`prompt()` 的 `ensureWorkspace` 固定 `'first'`，自动检查不复活 `lost`（`lost` 仍只由面板/命令显式 `list` 或显式 reset 恢复）。新增 `worktreePromptSeen` 只写 Host 内存 `WorkspaceState.offered`（按 workspace 共享；`reset`/`disposeAll`/Host 重启清空；不持久化、不参与授权）。`worktreePromptResolve` 增加 `action: 'snooze'` 与 `snooze.mode`，宿主从 `promptIds` 派生 discovery keys；不写 Registry、不加入 `prompted`，候选仍留在队列并可在 Dialog 中确认；失效 id 进 `skipped`。
- **sidecar snooze**：`WorktreeSidecarDocument`/`WorktreeSidecarView` 增加可选 `snooze`（`mode: 'until-new-worktree' | 'until'`、`until?`、`keys`、`at`；`version` 仍为 1，`emptySidecar` 默认没有该字段）。`readSidecar` 与 follower `parseSidecarView` 都把损坏的可选字段当作 `undefined`，不丢 `ignored`/`worktreeRoots`；owner 串行队列内新增 `{ op: 'snooze', snooze }`，仍走 `requireWorktreeMutation`/worktreeGate，inactive/开关关闭/authority 不可用一律拒绝且不写；`ignore`/`reconcile`/映射增删保留 snooze；`reset` 同时清空 `ignored` + `snooze`，没有可清内容时不制造 revision。`until` 由宿主时钟判定，`7d`/`30d` 由宿主换算；`until-new-worktree` 只抑制记录中的 keys，新 key 立即可见。
- **契约**：`worktreePromptSeen` 新端点、`worktreePrompt` 的 `fresh`、`worktreePromptResolve` 的 `snooze`/`action` 互斥与必填、`snooze.mode` 枚举、`promptIds` 必填/去重/上限 64，全部双端 schema 同步；宿主 dispatch（`parseWorktreeCall`）拒绝跨端点的多余字段。
- **验证（本机 macOS，Node 24.18.0，DSH 0.2.2-rc.3）**：worktree 专项 11 个 spec + `client-worktree` + `locale-parity` + `authority-native` 实跑 **188 通过、15 环境 skip、0 失败**（skip 为平台/原生 IPC 能力组）。全量 vitest **1435 通过、162 跳过、17 失败**；17 个失败与审计基线同一组 lease/follower 环境用例（`registry-lease`、`registry-multiprocess.e2e`、`registry`、`registry-operation`、`authority-boundaries`、`b9-review-regressions`、`skills-authority`、`skills-registry`），根因是当前 Host 自身被外层沙箱化，`nativeHostAvailability()` 报 `the Host itself is sandboxed; shared IPC refuses sandboxed peers`，与本次改动无关；本次新增用例全部通过。`lint`、双端 `typecheck`、`build`、`docs:check`、`compat:check`、`pack:check` 通过。`smoke:compose` **56 通过**；`smoke:behavior` **96 通过、8 按能力 skip**（嵌套内核执行与共享 IPC）；`smoke:journey` **88 通过、2 按能力 skip**（两个 leg 的受限 shell）——web leg 走真实 HTTP Connection RPC 的 fresh → `seen`（Toast 等价）→「查看」全量列表 → B 确认/面板徽标/清理 → 关开关拒绝 → 重开后下一次激活 fresh 出 A → A 确认；`smoke:packed` 以 tarball 经 `dsh plugin add` 安装后重跑行为 battery **95 通过、0 失败、8 按能力 skip**（同上的嵌套内核与共享 IPC），并确认载荷解析在 checkout 之外。
- **代码审查返工（2026-11-14，PR #55）**：十三条 finding（Devin 六条 + Codex 七条 P2）全部复现并修复，均先写失败回归。① sidecar `reset` 的空态判断用了「去掉 snooze 的副本」，snooze-only 的 reset 因此不落盘、重启后延迟复活——改为判断原始文档（`ignored.length === 0 && snooze === undefined`），只清 snooze 也写一次 revision；回归覆盖 sidecar 往返（重开 owner 读回为空、二次 reset 不制造 revision）与服务层 reset 后重启不恢复。② `prompt(fresh)` 走完整 `activate`，会安装 watcher 并调度 owner reconcile（有映射时可能写 sidecar），违反「纯查询、无副作用」——新增 `WorkspaceState.passive`，fresh 的首次激活与 re-inventory 只读 `resolveRepo`/sidecar 并只重建候选队列，不装 watcher、不调度 reconcile、不写 sidecar；首个显式请求（Dialog `prompt()`/`wait`/面板 list/reset）提升为持久发现一次，registry/settings 触发的 reconcile 沿用当前姿态；回归以 fresh 作为冷启动 Host 的首个调用，断言 `watching === false`、sidecar 操作只有 `read`、文件逐字不变、后台不发现新 worktree，打开 Dialog 后才出现 watcher 与 reconcile。③ 定时 snooze 到期后 `offered` 仍压制（浏览器顺序是 seen → 选 7/30 天）——新增到期处理（到期丢弃内存记录并把 keys 从 `offered` 释放；读回时同样丢弃过期记录），sidecar 不主动清理过期记录；回归覆盖 seen → 7d → 到期后同一 Host 重新提示。④ 到期后若先发生显式 sidecar 读取（面板/命令 `list` → `describeRoots` → `loadSidecar`、确认或 cleanup 的 load），读回路径会丢掉过期记录却不释放 `offered` 的 keys，下一次自动检查没有可到期的记录，候选被永久隐藏到 reset/重启——改为统一 `adoptSnoozes`：任何 sidecar 读回观察到到期都先释放 keys 再丢弃记录（到期处理复用同一 helper）；回归覆盖 seen → 7d → 到期 → `describeRoots` → 下一次 fresh 重新提示。⑤ 到期重提示后操作者再次 `seen`，随后一次面板 `list`（`describeRoots` → `loadSidecar`）又从 sidecar 读回**同一条**过期记录并再次释放 keys，把新认领冲掉，下一次 session 激活重复提示已确认候选——改为 workspace 内存按记录指纹（mode/until/at/keys）记录「每条过期记录只释放一次」，所有到期处理共用，新写入的延迟 `at` 不同按新记录处理；回归覆盖 到期 → fresh 重提示 → seen → describeRoots → 下一次 fresh 保持安静。⑥ Codex P2：单条 snooze 记录会让后来针对新候选的选择吞掉先前记录的期限与 keys（A 选 7 天后 B 再选 7 天，A 在本 Host 生命周期内永不再提醒）——sidecar 改为 `snoozes` 列表，新记录只取代 keys 有交集的旧记录、其余保留各自期限（上限 32，读取兼容旧单对象 `snooze`）；回归覆盖 A(7d)/B(7d) 各自到期分别恢复。⑦ Codex P2：已激活 Host 的 fresh 只重跑 inventory、不重读 sidecar，另一 Host 新写入的 snooze 又不改变 Registry roots、不触发刷新，于是本 Host 仍提示已被「稍后」的候选——`fresh` 在过滤前从 owner 只读重读提醒投影（不写、不建 watcher）；回归覆盖「空投影激活 → owner 写入延迟 → 下一次 fresh 为空」。⑧ Codex P2：合并只在记录互不相交时正确——两个 Host 的提示覆盖不同候选集合时，仅含 A 的新选择会把 `{A,B}` 记录整条替换成 `{A}`，B 的原期限随记录消失；改为按 key 拆分部分重叠：点名的 key 进新记录，剩余 keys 拆成残余记录并保留原期限/原 `at`，完全覆盖才删除。回归覆盖 sidecar 两种 mode 的部分重叠，以及服务层 A(7d)+B(2d) 部分重叠后 B 在原期限前安静、到期只回 B、A 新期限到期再回 A。⑨ Devin Review：到期释放原先按整条记录指纹（含 keys）去重，共享记录 `{A,B}` 到期释放后另一 Host 只对 A 再选「稍后」，owner 拆出的 `{B}` 残余记录身份不变但 keys 变了，显式读取于是再次释放 B、冲掉操作者在重提示后的 `seen` 认领——改为按延迟身份（`mode`/`until`/`at`，不含 keys）+ 单个发现 key 去重，残余记录不再算新记录，真正的新选择（`at` 不同）照常释放。回归：到期 → fresh 重提示 → `seen` → 另一 Host 只对 A 再选 7d → `describeRoots` 读回残余 → 下一次 fresh 保持安静。⑩ Codex P2：`MAX_SNOOZE_RECORDS = 32` 淘汰最旧记录后没有释放它的 `offered` 认领，记录从后续所有投影消失、只依赖到期的释放路径再也看不到它，被淘汰的定时选择退化为永久抑制——`observeSnoozes` 统一处理自动过滤、任何 sidecar 读回与本地合并，淘汰时同样释放；回归以另一 Host 写入 32 条不相交延迟触发淘汰后下一次 fresh 重新提示。⑪ Codex P2：`applyLater`/`snoozeNotice` 丢弃成功响应里的 `skipped` 直接关闭 Dialog/Toast——候选在渲染后发生变化时该行决策未落盘，`seen` 认领因此无期限压制候选（永久 ignore 也未落盘）；改为与 `confirmAdd` 一致：Toast 只为未处理行保留提示（刷新后的 id，select 重新武装），Dialog 保留刷新后的行 + 行错误 + skipped 计数供重试，transport/authority 失败仍静默关闭且不自动重试。回归：client 的 Toast(7d) 与 Dialog(7d/permanent) 三条。⑫ Codex P2：`snoozeNotice` 的失败路径只检查 `mounted`，成功路径只比较 session id——A 会话的 snooze 在切到 B 后 reject 会清掉 B 刚刚显示、候选已被 `seen` 认领的 Toast（B 在本 Host 生命周期内不再提示）；A→B→A 往返后旧请求成功也会清掉第二次激活的 Toast——改为调用时捕获 `workEpoch`，两个完成路径只在 `mounted && epoch === workEpoch.current`（成功路径仍校验 session）时修改 Toast，生命周期已变的完成一律丢弃，同生命周期失败仍静默关闭、不重试。回归：client 的跨会话失败与同会话往返成功两条。⑬ Codex P2：`seen`（Toast/Dialog）与 snooze/resolve 一次发送整个可见集合，请求受 `promptIds` 的 64 上限约束而发现本身不设上限；更早的失败点是响应 schema 同样 `max(64)`——真实客户端会整份拒绝 >64 的答案，Toast 完全不出现、Dialog 关闭，因此 review 描述的直接请求溢出在旧代码中先被响应解析挡住，但根因相同且影响更糟——响应 schema 不再限制列表长度（请求上限保留 64），`WorktreeClient` 按 64 个 id 顺序分批 `seen`/`resolve`/`snooze` 并合并（`seen` 求和；`resolved`/`skipped` 合并；`viewRevision`/`prompts` 取最后一批）。回归：合同 65 项响应、客户端 65/100/130 个 id、真实客户端 + 65 候选 Toast 与两批 `seen`。同一轮广泛审查把 `workEpoch` 归属扩到 `confirmAdd`/`applyLater`，并让 `openDialog`/Toast「×」立即作废旧完成；回归：Dialog add/later 往返、关闭 Toast 后 refused snooze 不重现。追加第⑬条后专项 **204 通过 / 15 skip / 0 失败**、全量 **1451 通过 / 162 跳过 / 17 既有 lease-follower 环境失败**，lint、双端 typecheck、build、docs:check、compat:check、pack:check 通过；四个冒烟在①–⑪条返工时通过（56、96/8、88/2、95/8），本次由 PR #55 的新 CI 轮次按支持矩阵复验；CI 结果记录在 PR 描述。
- **非目标与说明**：不做 repo（common）级去重（状态仍按 `primaryKey`/workspace）；`worktreePromptWait` 保留（仅 Dialog 打开时使用）；不把 `offered`/snooze 用于授权或写入 Registry 授权数据；不改 owner 的 `addNew`/`removeForDeletedWorktree`/`probeAdd` 校验。面板内常驻「可添加 N 个目录」入口属于任务中的可选项，本次未实现：Toast 不自动消失，「×」是用户显式关闭，因此不构成「fresh 已认领但用户再也看不到」的自动消失场景；Dialog 打开即 `seen`、关闭不写状态，与 ADR §20.5 一致。

## 总体策略

MVP 三个里程碑加一个硬化批次，每一项都独立可验证，且**第一步就建立"空根直通 = 上游行为"的安全网**，之后所有增量都在安全网内：

- **M1 组合与直通（已完成）**：bundle 骨架 + 两行替换 + 空根直通。插件已可安装，行为与未装一致；组合、disable/insert 时序与 provide 冲突这三项结构性风险已清零。
- **M2 多根能力（已完成）**：附加根数据源 + 两个 provider 的多根逻辑 + 方言 grant + parity 测试。
- **M3 Root 管理与 UI（已完成）**：注册表、命令、client 半部、e2e。
- **H1（= M4）跨进程 Authority（已完成）**：store-wide 内核 lease，争用 fail-closed。
- **H2 面板权威收紧（已完成）**：面板主根只从 host session 推导，删除客户端 `primaryRoot`。
- **H3 兼容性代码契约（已完成）**：精确版本 allowlist + 启动门禁 + `src/compat/` 适配层 + 按周升级车道。
- **H4 附加根指令（已完成）**：Phase 1 让附加根顶层 `AGENTS.md` / `CLAUDE.md` 在第一步之前进入模型上下文；Phase 2 让本会话成功触碰过的子目录增量补投、内容变化重发、文件消失显式撤回。

## M1 — bundle 骨架、两行替换、空根直通（已完成）

> 任务清单、设计决定、验证判据、T0 探查结论与实施结果见 **[M1 开发计划（completed）](../completed/2026-09-12-m1-composition-and-passthrough.md)**；本文件只保留里程碑概览，不重复其内容。

相对首版路线的修正（已同步架构与需求文档）：

- 替换集合收窄为两行（`fs-sandbox`、`sandbox`）：bash 与 PTY 的 confinement 全部经 `ctx.sandbox`，`bash-sandbox` 保持上游（[ADR-0001](../../decisions/ADR-0001-provider-replacement-scope.md)）。
- scope 服务在 M1 落地（数据源为空表），provider 只经它取根；M2 只替换数据源，provider 结构不变。
- fs provider 在 M1 即实现 containment（空根时根列表长度为 1），并以差分 parity 测试证明与上游 `SandboxedFileSystem` 等价：`LocalFileSystem` 自身没有 fence，"直通 super"会丢掉 fence。
- 方言 builder 不可深导入（发布包不含 `src/`），M2 改为克隆 `super.confine` 的 grant 模板；识别失败即抛错（[ADR-0002](../../decisions/ADR-0002-upstream-coupling-policy.md)）。

验证（已完成）：`pnpm lint` / `typecheck` / `test`、`pnpm smoke:compose`（30/30）、`pnpm smoke:behavior`（54/54）、`pnpm docs:check`；两个冒烟在 `0.1.5-rc.2` 与 `0.1.2-rc.1` 双运行时上均通过。

## M2 — 附加根数据源与多根 provider（已完成）

> 任务清单、设计决定、验证判据与实施结果见 **[M2 开发计划（completed）](../completed/2026-09-12-m2-additional-roots-and-dialect-grants.md)**；本文件只保留里程碑概览，不重复其内容。

相对首版路线的修正（已同步架构与需求文档）：

- `MultiRootFileSystem` 的多根 containment 在 M1 就已实现，M2 的 fs 侧增量是「证明与方言授予集合逐项一致」的 parity 矩阵 + 多根 denial 文案回归。
- 方言 grant 的实现形态定为**结构识别 + 观测克隆 + 已授予跳过**（不给 win32 制造 ACL 副作用、不硬编码上游 flag），识别失败抛 `SandboxUnavailableError`（[ADR-0003](../../decisions/ADR-0003-dialect-grant-widening.md)）。
- 拓扑快照落在 scope 服务内（不新增 patch 行），仅 workspace-write + 非空根输出（空根/只读逐字节不变）。
- 不新增 `windows-latest` CI 腿：win32 行为用 `internals.chain` 在任意宿主上钉住。

验证（已完成）：`pnpm lint` / `typecheck` / `test`（79 项：3 项真实受限执行按宿主能力显式 skip）、`pnpm build`、`pnpm smoke:compose`（30/30）、`pnpm smoke:behavior`（69/69，4 项显式 skip）、`pnpm docs:check`；两个冒烟在 `0.1.5-rc.2` 与 `0.1.2-rc.1` 双运行时上均通过。

## M3 — Root 注册表、命令、client UI、e2e（已实施，且按外部审查返工后重新验收）

> 任务清单、设计决定、修正依据、验证判据与实施结果见 **[M3 开发计划（completed）](../completed/2026-09-12-m3-root-registry-command-and-ui.md)**；本文件只保留里程碑概览，不重复其内容。

相对首版路线的修正（依据见 M3 计划「对路线图 M3 段落的修正」表）：

- **不接入** `sidebar.workspaces.directoryFlow` / `conversation.hero.workspace.directoryFlow`：它们是 ui-workspace「创建工作区」流程的 single 洞且已被默认 picker 包占用；add 改走 host 侧 `ctx.directoryPicker` 与 client 侧 `ctx.uiWorkspace.pickDirectory()`。
- **不使用 Typert 远程命名空间**：出树契约生成不可用（generator 是 workspace 形状）、client 侧 remote 清单是上游静态表；面板改用 Connection RPC 通道（兄弟插件同款公开缝，双运行时可用）。
- 面板落在 `sidebar.footer.action`（两个运行时都存在）+ 自绘对话框；0.1.5 专属的 `sidebar.panellist`/`main` 全屏面板不在 M3。
- 注册表以 **canonical 主根** 为存储键（`ctx.workspaceRegistry` 在 headless 不存在）；nested roots **拍板拒绝**。
- e2e 用真实组合 + 无凭据脚本化模型在进程内驱动真实 agent turn（web 与 headless 各一轮），不引入 Playwright/Electron 车道。

**外部审查返工（2026-09-12）**：审查提出 8 项发现（3 项发布阻断）——登记根被替换为符号链接后授权转移、并发改注册表丢写/复活已撤销授权、CI 先测后构建、刷新不重查目录、手输路径被 picker 覆盖、Reveal 应答契约不一致、重复 id 未校验、主根未纳入嵌套校验。已全部修复并各带回归测试，取舍与语义写入 [ADR-0004](../../decisions/ADR-0004-root-registry-persistence-and-validation.md)（返工补充第 9–15 条）与 [架构 §4/§7](../../architecture/multi-root-workspace.md)；逐项证据见 M3 计划「外部审查返工」章节。

## v0.1.1 — 硬化批次（H1–H4，已实施，已发版）

> 任务清单、设计决定、验证判据与实施结果见各自的 completed 计划；本文件只保留批次概览，不重复其内容。

- **H1（= M4）跨进程 Registry Authority Lease**：[M4 计划](../completed/2026-09-15-m4-registry-authority-lease.md)、[ADR-0007](../../decisions/ADR-0007-registry-authority-lease.md)、commit `aa4b19e`。POSIX `flock` / Windows named semaphore 表达"同一时刻只有一个 Registry Authority Process"；争用进程 fail-closed（空 scope、mutation 抛 `registry-contended`），对方退出或崩溃后由 `refresh()` 接管。
- **H2 面板主根 host 推导**：[面板计划](../completed/2026-09-15-panel-session-derived-authority.md)、[ADR-0008](../../decisions/ADR-0008-panel-session-derived-authority.md)、commit `66375ca`。`PanelRequest` 删除客户端 `primaryRoot`、`sessionId` 变为每个端点必填；host 唯一 resolver 是 `resolvePanelPrimaryRoot(ctx, sessionId)`。
- **H3 DSH 兼容性代码契约**：[compat 计划](../completed/2026-09-15-dsh-compat-contract.md)、[ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md)、commit `d4b16ff`。精确版本 allowlist（`0.1.5-rc.2` / `0.1.6-alpha.1`）、`multi-root-compat` 启动门禁（四个安全相关行全部 inject `multiRootCompat`）、混装 fail loud、`src/compat/` 适配层、`upgrade.yml` 按周升级车道（不自动扩大支持矩阵）。
- **H4 附加根指令注入**：同一计划 §5/§5b、[ADR-0010](../../decisions/ADR-0010-additional-root-instruction-scope.md)。Phase 1：附加根**顶层** `AGENTS.md` / `CLAUDE.md` 经 `agent/pre-step` 以 `form: 'instructions'` 的 user 消息注入（format 3 的 source kind 是 `plugin`，format 4 起是 `multi-root-workspace`），共享 64 KiB 预算，根离场时显式撤销。Phase 2：本会话**成功**的 `read` / `write` / `edit` 触碰过的子目录里的同类文件，在其目录被考察到时补投（触碰取自持久化的 `session/event` 的 `tool/call` + `tool/result` 配对），内容变化只重发该文件，文件消失则显式撤回。Phase 1 的验收场景与证据见该计划 §5；Phase 2 的验收判据见需求文档 §5 的 7.8，端到端证据在 `pnpm smoke:journey` 两条腿。

第二轮审查（2026-09-16）的新增发现、修复和验证见同一[返工报告](../completed/2026-09-15-v0.1.1-review-rework.md#第二轮审查与修复2026-09-16)。

**PR #1 评审返工（2026-09-15）**：发版前的 Codex 自动评审（head `507c954`）提出 5 项发现（P1×2 / P2×3），已全部修复并各带「修复前红、修复后绿」的回归测试；逐项证据、验收判据与文档同步见 [v0.1.1 评审返工计划](../completed/2026-09-15-v0.1.1-review-rework.md)，语义写入 [ADR-0007](../../decisions/ADR-0007-registry-authority-lease.md) / [ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md) / [ADR-0010](../../decisions/ADR-0010-additional-root-instruction-scope.md) 的返工补充。一行摘要：

- **P1-1 lease 拆除顺序**：`releaseAuthority()` 原本先释放 lease 再 close domain，且未串入 store-wide authority 转场队列 —— 继任者可能读到缺最后一次写的快照，在飞 acquisition 还可能在拆除之后完成并泄漏 domain + lease；现改为在转场队列内「排空在飞 mutation → close domain → release lease」，并置 `disposed` 拒绝后续 acquisition（[ADR-0007](../../decisions/ADR-0007-registry-authority-lease.md)）。
- **P1-2 中间目录指令**：`planRoot()` 原本只考察被触碰文件的父目录，`<root>/a/AGENTS.md` 被精确目录过滤丢弃；现考察父目录及其每个祖先目录（直到该附加根），中间目录的规则才到得了模型（[ADR-0010](../../decisions/ADR-0010-additional-root-instruction-scope.md)）。
- **P2-3 warn 收紧**：`DSH_MULTI_ROOT_COMPAT=warn` 原本放宽所有非 `supported` 判定；现只放宽 `unsupported`，`mixed` / `incomplete` 两种模式都拒绝（[ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md)）。
- **P2-4 可选 peer 按需加载**：新增 `src/compat/llm-message.ts`，`@deepseek-ai/dsh-llm` 在真正构造消息时才 import；barrel 的加载期依赖集合等于必需包集合（旧形态下零附加根的最小组合会在加载 carrier 行时失败）（[ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md)）。
- **P2-5 缺失与求值失败区分**：新增 `isPackageInstalled()` 单独探测可解析性；「已安装但求值失败」不再被当作缺失缓存吞掉（旧形态下整个进程会静默停止投递附加根指令）（[ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md)）。

### 发版准备与跨平台回归（2026-09-16）

`fix/v0.1.1-hardening` 经 PR #1 合入 `main`（merge `6b4c796`）之后，发版前做了四件事；每一件都可复现，命令写在[开发工作流](../../development/plugin-development-workflow.md)与[发版流程](../../development/release-workflow.md)。

| 项 | 结果 |
|---|---|
| 发布状态与 CHANGELOG | 路线图、README（中英）、需求/架构/各目录 README 的版本句改为"随 `v0.1.1` 发版"；新增 [`CHANGELOG.md`](../../../CHANGELOG.md) / [`CHANGELOG.en.md`](../../../CHANGELOG.en.md) 记录 `0.1.0` 与 `0.1.1` 的使用者可见变更，并把"每个版本写 CHANGELOG"写进发版流程 |
| 基线运行时完整矩阵（`0.1.5-rc.2`） | `compat:check` + `lint` + `typecheck` + `build` + `kernel:probe` + `test`（321 passed / 3 skipped）+ compose 40/40 + behavior 99/99 + journey 55/55 + `docs:check` 全绿 |
| 第二运行时完整矩阵（`0.1.6-alpha.1`） | 按升级流程重指 pin、重装后 `DSH_MULTI_ROOT_COMPAT=warn pnpm verify:all` 全绿（同样的 321 passed / 3 skipped 与三个冒烟计数），随后回退三文件并 `pnpm install --frozen-lockfile` 回到基线 |
| Windows 验证腿 | 仓库是公开仓库、标准 runner 在公开仓库上不计费，因此把仓库变量 `DSH_WINDOWS_CI` 置 1；首次运行即抓到 `tests/scope.spec.ts` 两处期望值用 `/` 拼接路径（产品侧交回的是 `canonicalPath()` 的平台分隔符），修正后 [macOS / ubuntu / Windows 三条腿全绿](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/35055445350) |
| 打包产物校验 | 按 `release.yml` 的做法 `pnpm pack` 并逐项校验 tarball，发现 `lib/` 里残留 4 份历史 `instructions-*` chunk 与陈旧的 registry / lease chunk（tsdown `clean: false` + 内容哈希命名），已由 `scripts/clean-lib.mjs` 在 `bundle` 前清掉上一轮的 JS 面；CI 在干净 checkout 上看不到这个问题，只有本地打包会 |
| 打包产物端到端安装 | 把 tarball 装进隔离 `$DSH_HOME` 并跑与 `smoke:compose` 同构的差分断言：首次 `add` **在四种来源下都会失败**——本批次新增的生产依赖 `koffi` 带构建脚本，pnpm ≥10 默认不运行它，`dsh` 因此判定 pnpm 失败并且**不回填** `dsh.profile.bundles`；按 profile 里留下的 `allowBuilds` 待决项回答 `true` 后重跑成功，装出的组合与预期逐项一致（8 行 insert、两行 disabled、顺序不变） |

**版本号与 tag 由发版提交完成**（`pnpm release patch --tag` → `chore(release): v0.1.1` + annotated tag `v0.1.1`）；推送 tag（进而触发 npm 发布与 GitHub Release）是人工动作，绿灯是证据、不是授权。桌面端（Electron）车道仍未建立，属人工验证。

## v0.1.2 — 支持矩阵提升（已实施，已发版）

> 用户可见变更见 [`CHANGELOG.md`](../../../CHANGELOG.md) 的 `0.1.2` 条目；设计取舍仍见 [ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md)。

### 支持矩阵提升（随 `v0.1.2` 发版，2026-09-22）

`0.1.6-alpha.2` 按 [ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md) 的人工提升流程写入 allowlist（`peerDependencies` 同步为三项精确或）。开发 pin 与 lockfile 仍是 `0.1.5-rc.2`。`confine` 仍是带可选 `signal` 的 `Promise`，instruction renderer 仍是 `renderAgentInstructions`，journey 的 Messages 端点未改。**客户端 Session 目录删掉了 `current`**，面板必须走 `src/compat/client-session.ts` 同时认旧的 `list.current` 与新的 `retainedBy.mainView`。

| 项 | 结果 |
|---|---|
| 纳入前（pin 在 `0.1.6-alpha.2`，`DSH_MULTI_ROOT_COMPAT=warn`） | `pnpm verify:all` 全绿：321 passed / 3 skipped，compose 40/40，behavior 99/99，journey 55/55。macOS，seatbelt 可用，bwrap / landlock 不可用 |
| 纳入后 enforce（同一棵 `0.1.6-alpha.2` 树） | `pnpm compat:check` + `pnpm verify:all` 全绿，计数相同 |
| 基线回归（pin 回到 `0.1.5-rc.2`，enforce） | `pnpm compat:check` + `pnpm verify:all` + `pnpm docs:check` 全绿，计数相同 |

### 支持矩阵提升（随 `v0.1.2` 发版，2026-09-22）：`0.1.7-alpha.1`

`0.1.7-alpha.1` 按 [ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md) 的人工提升流程写入 allowlist（`peerDependencies` 同步为四项精确或）。开发 pin 与 lockfile 仍是 `0.1.5-rc.2`（cordis 仍是 `4.0.2`）。`confine` 与 instruction renderer 的形状没变，journey 仍走 `/v1/messages`。客户端 Session 目录与 `0.1.6-alpha.2` 一样没有 `current`，面板继续走 `src/compat/client-session.ts` 的 `retainedBy.mainView` 探针。适配层有改动：session format 4 拒绝 `kind: 'plugin'`（改投 `multi-root-workspace`）、工具失败位移到消息上、面板图标改为 Regular、进程内启动改为 `PluginPackages`、bash 改为 `execute().result()`。探测时 cordis 必须钉到 `4.0.3`，否则两份 `dsh-tools` 让调度 Symbol 对不上。

| 项 | 结果 |
|---|---|
| 纳入前（pin 在 `0.1.7-alpha.1`，cordis `4.0.3`，`DSH_MULTI_ROOT_COMPAT=warn`） | `pnpm verify:all` 全绿：329 passed / 3 skipped，compose 40/40，behavior 99/99，journey 55/55。macOS，seatbelt 可用，bwrap / landlock 不可用（rebase 前、尚未带 `client-session`） |
| 纳入后 enforce（同一棵 `0.1.7-alpha.1` 树） | `pnpm compat:check` + `pnpm verify:all` 全绿，计数相同 |
| 基线回归（pin 回到 `0.1.5-rc.2`，cordis `4.0.2`，enforce） | 同一次数：测试 329 passed / 3 skipped，compose 40/40，behavior 99/99，journey 55/55。`pnpm docs:check` 通过 |
| rebase `main` 后重跑（含 PR #4 的 Session 目录探针，2026-09-22） | 0.1.7 客户端目录仍无 `current`，`retainedBy.mainView` 谓词未变。enforce 在 `0.1.7-alpha.1` + cordis `4.0.3` 与基线 `0.1.5-rc.2` + cordis `4.0.2` 上都是 343 passed / 3 skipped，compose 40/40，behavior 99/99，journey 55/55。`pnpm docs:check` 通过 |

### 发版准备（2026-09-22）

| 项 | 结果 |
|---|---|
| 发布状态与 CHANGELOG | 路线图、README（中英）的版本句与 tarball / tag 示例对齐 `v0.1.2`；[`CHANGELOG.md`](../../../CHANGELOG.md) / [`CHANGELOG.en.md`](../../../CHANGELOG.en.md) 新增 `0.1.2` 条目 |
| 本地门禁 | `compat:check` + `lint` + `typecheck` + `build` + `test`（342 passed / 4 skipped）+ `smoke:compose` 40/40 + `smoke:behavior` 91/91（4 项 seatbelt 不可用 skip）+ `smoke:journey` 55/55 + `docs:check` 全绿（2026-09-22，macOS） |

**版本号与 tag 由发版提交完成**（`pnpm release patch --tag` → `chore(release): v0.1.2` + annotated tag `v0.1.2`）；推送 tag（进而触发 npm 发布与 GitHub Release）是人工动作。

## v0.1.3 — 支持矩阵提升（已实施，已发版准备完成）

> 用户可见变更见 [`CHANGELOG.md`](../../../CHANGELOG.md) 的 `0.1.3` 条目；设计取舍仍见 [ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md)。

### 支持矩阵提升（随 `v0.1.3` 发版，2026-09-24）：`0.1.7-alpha.2` 与 `0.1.7-rc.1`

这两项按 [ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md) 写入 allowlist（`peerDependencies` 同步为六项精确或）。开发 pin 与 lockfile 仍是 `0.1.5-rc.2`（cordis 仍是 `4.0.2`）。相对 `0.1.7-alpha.1`，适配层没有新分支；`rc.1` 的安装期 peer 门禁要求 allowlist 与 `peerDependencies` 同时带上该精确版本。探测时 cordis 钉 `4.0.4`。

| 项 | 结果 |
|---|---|
| `0.1.7-alpha.2` 纳入前（cordis `4.0.4`，`DSH_MULTI_ROOT_COMPAT=warn`） | 343 passed / 3 skipped，compose 40/40，behavior 99/99，journey 55/55。macOS，seatbelt 可用，bwrap / landlock 不可用 |
| `0.1.7-rc.1` 纳入后 enforce（cordis `4.0.4`） | 同样 343 passed / 3 skipped，compose 40/40，behavior 99/99，journey 55/55 |
| 基线回归（pin 回到 `0.1.5-rc.2`，cordis `4.0.2`，enforce） | `compat:check` + `docs:check` 通过；343 passed / 3 skipped，compose 40/40，behavior 99/99，journey 55/55 |

### 发版准备（2026-09-24）

| 项 | 结果 |
|---|---|
| 发布状态与 CHANGELOG | 路线图、README（中英）的版本句与 tarball / tag 示例对齐 `v0.1.3`；[`CHANGELOG.md`](../../../CHANGELOG.md) / [`CHANGELOG.en.md`](../../../CHANGELOG.en.md) 新增 `0.1.3` 条目 |
| 本地门禁 | `compat:check` + `lint` + `typecheck` + `build` + `test`（342 passed / 4 skipped）+ `smoke:compose` 40/40 + `smoke:behavior` 91/91（4 项 seatbelt 不可用 skip）+ `smoke:journey` 55/55 + `docs:check` 全绿（2026-09-24，macOS） |

**版本号与 tag 由发版提交完成**（`pnpm release patch --tag` → `chore(release): v0.1.3` + annotated tag `v0.1.3`）；推送 tag（进而触发 npm 发布与 GitHub Release）是人工动作。

## v0.1.4 — 支持矩阵提升（已实施，已发版准备完成）

> 用户可见变更见 [`CHANGELOG.md`](../../../CHANGELOG.md) 的 `0.1.4` 条目；设计取舍仍见 [ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md)。

### 支持矩阵提升（随 `v0.1.4` 发版，2026-09-25）：`0.1.7-rc.2`

`0.1.7-rc.2` 按 [ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md) 写入 allowlist（`peerDependencies` 同步为七项精确或）。开发 pin 与 lockfile 仍是 `0.1.5-rc.2`（cordis 仍是 `4.0.2`）。相对 `0.1.7-rc.1`，适配层没有新分支。安装期 peer 门禁与 `rc.1` 相同。探测时 cordis 钉 `4.0.4`。

| 项 | 结果 |
|---|---|
| `0.1.7-rc.2` 纳入后 enforce（cordis `4.0.4`，peer 已含该版本） | lint / typecheck / build / kernel:probe 通过；343 passed / 3 skipped，compose 40/40，behavior 99/99，journey 55/55。macOS，seatbelt 可用，bwrap / landlock 不可用 |
| 基线回归（pin 回到 `0.1.5-rc.2`，cordis `4.0.2`，lockfile 保持基线，enforce） | `compat:check` 与 `docs:check` 通过；同样 343 passed / 3 skipped，compose 40/40，behavior 99/99，journey 55/55 |

### 发版准备（2026-09-25）

| 项 | 结果 |
|---|---|
| 发布状态与 CHANGELOG | 路线图、README（中英）的版本句与 tarball / tag 示例对齐 `v0.1.4`；[`CHANGELOG.md`](../../../CHANGELOG.md) / [`CHANGELOG.en.md`](../../../CHANGELOG.en.md) 新增 `0.1.4` 条目 |
| 本地门禁 | `compat:check` + `lint` + `typecheck` + `build` + `test`（343 passed / 3 skipped）+ `smoke:compose` 40/40 + `smoke:behavior` 99/99 + `smoke:journey` 55/55 + `docs:check` 全绿（2026-09-25，macOS） |

**版本号与 tag 由发版提交完成**（`pnpm release patch --tag` → `chore(release): v0.1.4` + annotated tag `v0.1.4`）；推送 tag（进而触发 npm 发布与 GitHub Release）是人工动作。

## 里程碑与仓库状态对照

进度、编号与发布状态的唯一真源是本文开头的[进度总账](#进度总账)；此处不再重复维护一份对照表。

## 测试与检查指引

```sh
# 插件仓库（自建门禁）
pnpm typecheck && pnpm lint && pnpm test          # vitest：方言单测、方言 grant 矩阵、空根差分 parity、patch 不变量、注册表/lease、契约往返、指令注入
pnpm smoke:compose                                 # dsh --dump-config 组合差分断言（只差两行禁用 + 八行 insert）
pnpm smoke:behavior                                # 空根直通 + 多根 battery + 注册表/命令 battery（隔离 $DSH_HOME，进程内 boot）
pnpm smoke:journey                                 # 跨两个 git repo 的 web/headless 旅程（脚本化模型，无凭据）
pnpm verify:all                                    # lint → typecheck → build → kernel:probe → test → smoke

# 升级检查（每次上游发版手动/CI 触发）
# 改 pin（精确版本）后重跑差分 parity + 方言矩阵 + smoke:compose + smoke:behavior；差异即报警（pre-stable API 风险）
```

**没有** `smoke:multiprocess` / `smoke:instructions` 这两个脚本，这是刻意的：跨进程争用与指令注入的正确性由 vitest 覆盖（`tests/registry-multiprocess.e2e.ts` 真的起第二个 OS 进程、`tests/instructions.spec.ts` 覆盖注入与撤销），因为它们需要夹具级的进程编排与断言，塞进 `--dump-config` 式的冒烟只会更难定位。

上游仓库（deepseek-harness）本身在此项目中的唯一用途是**阅读与对照**：不修改任何文件，不在其中跑本插件的 CI；smoke 通过环境内安装的 dsh 运行。

## 风险与开放问题

| # | 风险/问题 | 影响 | 处置 |
|---|---|---|---|
| 1 | 上游 pre-stable API 升级破坏子类（AGENTS.md 明言无 semver 承诺） | 插件可用性 | 精确 pin（可变 dist-tag 和范围依赖不能证明已验证版本，见 ADR-0002）+ 启动门禁（ADR-0009）+ 按周升级车道；只允许包入口导入；M1 即建立差分对照测试 |
| 2 | 方言 parity 责任转移到插件 | 安全正确性 | 已落地：parity 矩阵测试（测试侧独立解析 argv 授予集合）+ 方言单测为核心资产；方言 grant 由 `super.confine` 输出克隆模板（上游 builder 在发布形态下不可达），识别失败即抛错（[ADR-0003](../../decisions/ADR-0003-dialect-grant-widening.md)） |
| 3 | ~~bash 子类落点未定~~（已关闭） | — | 不替换 `bash-sandbox`：bash 与 PTY 的 confinement 全部经 `ctx.sandbox`（ADR-0001） |
| 4 | provider 行替换影响未盘点的 Consumer | 隐藏回归 | 已盘点：`ctx.sandbox` 的消费者是 bash-sandbox / pwsh-sandbox / terminal-bash；`ctx.fs` 的消费者是 tool-fs / tool-str-replace-editor。全部只依赖 `confine`、`sandboxMode` 等结构化事实；M1 冒烟逐一实跑 |
| 5 | disable/insert 时序或 id 变化（上游 base patch 行 id 不是稳定承诺） | 组合失败 | duplicate-provide 天然抛错 + 插件身份断言 + `smoke:compose` 组合差分断言 |
| 6 | Windows 内核级多根缺失（pwsh 方言） | Windows bash 场景 | B2 已实现 root-set SID runner；2026-10-11 起 `kernel:probe` 在 Windows 上以真实上游 runner 验证 `windows-acl` 并导出方言，Windows 冒烟与原生用例在全部 11 个支持版本上原生执行，证据见 [B1–B3 加固记录](#b1b3-加固与-windows-全量验证2026-10-11)；网络/设备根在 Windows 上按 `unsupported-path` 词法拒绝 |
| 7 | `isPathUnder` 等价实现的正确性 | fence 语义漂移 | 深导入不可用（发布包不含 `src/`，ADR-0002）⇒ 本地实现 + 注明出处 + M1 差分 parity 套件钉住；M2 起另由方言矩阵复验 |
| 8 | 拓扑快照进入 context 对 prompt cache 的影响 | 长会话成本 | 已落地：空根 / 只读 / 无 agent 时零输出（逐字节快照断言）；根集变化频率 = 用户增删根频率，可接受 |
| 9 | ~~nested roots 态度未最终拍板~~（已关闭） | — | 已拍板**拒绝**（[ADR-0004](../../decisions/ADR-0004-root-registry-persistence-and-validation.md)） |
| 10 | 桌面端（apps/desktop）插件安装形态与 CLI profile 的差异 | M3 e2e | 已安装桌面 app 用的是 `web` profile（其自带 runtime 0.1.2-rc.1）；M3 的面板因此落在两个运行时都有的 `sidebar.footer.action` 上，Electron 车道仍未建立（人工验证） |
| 11 | Linux CI 上 bwrap 可能不可用（用户命名空间受限） | 真实执行用例被跳过 | 内核链有第二个 rung（Landlock）；矩阵与冒烟只在 runner 真的不可用时显式 skip，并在输出里说明原因，不把"没跑"记成通过 |
| 12 | ~~附加根 nested instructions 未实现（H4 Phase 2）~~（已关闭） | — | 已实现（H4 Phase 2）：触碰取自持久化的 `session/event`（`tool/call` + `tool/result` 配对，只认成功的 `read` / `write` / `edit`），不使用 `SessionMessageProjection`；语义与边界见 [ADR-0010](../../decisions/ADR-0010-additional-root-instruction-scope.md) |
| 13 | 触碰识别只覆盖 `read` / `write` / `edit` | 其他写文件工具（`str_replace_editor` 等）触碰的目录不会立刻发现其 nested 指令 | 记录为已知限制（需求文档 §5「已知限制」、README 已知限制）；上游同样只认这三个名字，扩大集合需要先有让插件识别工具类别的 seam |
| 14 | 桌面端自带的旧 runtime（`0.1.2-rc.1`）不在 `v0.1.1` 的 allowlist 上 | 已安装的桌面端在升级自带 runtime 之前，插件的四行**不启动**（fail loud，组合退化为"未装插件"），即相对 `v0.1.0` 的功能回退 | 属 [ADR-0009](../../decisions/ADR-0009-dsh-compat-contract.md) 有意的收窄（范围承诺换成了实测清单）；已在 [CHANGELOG](../../../CHANGELOG.md) / [README](../../../README.md) 的「升级注意 / 环境要求」里明示，桌面端升级自带 runtime 后自动恢复；Electron 车道仍未建立 |
| 15 | ~~生产依赖 `koffi`（Windows lease 的 FFI）带构建脚本，pnpm ≥10 默认不运行它~~（已关闭） | — | 已修复（`v0.1.21`）：`koffi` 改为宿主提供的 optional peer + 开发 pin，pnpm 不安装可选 peer，npm / tarball / 本地路径安装不再触发构建授权；运行时 `loadHostKoffi()` 按 `DSH_KOFFI_PATH` → `dsh-fs-local` 锚点 → 宿主入口 → Desktop `app.asar` / `app.asar.unpacked` 运行时目录解析宿主副本，包内不再回退（[ADR-0007 修订](../../decisions/ADR-0007-registry-authority-lease.md)、[故障排查](../../troubleshooting/install-stops-at-build-approval.md)）。git 来源仍只需为插件自身 `prepare` 授权；旧宿主矩阵与 Windows 原生 runner 的执行证据待 CI |

## 与"可改上游"路线的关系

若未来允许向上游贡献，按架构文档 §9 的 PR 栈提交通用 Filesystem Scope Seam；合入后本插件撤销三个替换行、provider 子类退化为 scope contributor——`FilesystemScope` 接口自 M2 起即按该 seam 目标形态设计，迁移是删除而非重写。

### DSH 0.2 兼容提升（2026-09-30）

用户授权范围是 `dsh-v0.1.7-rc.2` 至 `dsh-v0.2.0-rc.2` 的所有发布版本。上游本地 tag 与 npm `versions` 列表一致：这个闭区间只有起点及 `0.2.0-rc.1` / `0.2.0-rc.2`。支持合同保留全部旧版，再纳入这两个精确版本；开发 pin 与 lockfile 升到 `0.2.0-rc.2`，cordis 是 `4.0.4`。这批已整理为 **v0.1.5** 发版内容并通过本地及远端门禁；当前仅完成发版准备，插件版本号仍是 `0.1.4`，尚未创建 release tag 或发布 npm 包。用户可见变更见双语 CHANGELOG 的 `0.1.5` 条目。

#### 接口变更与风险

对上游上述三个 tag 做源码差分，并用各自的 npm 发布包验证。版本形状判断继续集中在 `src/compat/`，没有新增版本字符串分支。

| 接缝 | 上游变化与影响 | 本次处理与证据 |
|---|---|---|
| fs / sandbox policy / profile dialect | `writeText` / `editText`、`confine`、Seatbelt / bwrap / Landlock profile 生成形状未变。0.2 的 Windows provider 新增 ACL diagnosis skill 的可选 `skills` 注册；rc.2 改进诊断脚本 | 继承上游 provider，保留软注册和空根透传；fs / sandbox / parity 差分套件及真实 Seatbelt 写入验证。Windows 内核多根仍不在承诺内 |
| 指令 discovery / renderer、runtime-context | 上游公开导出及本插件使用的事件接口未变 | 原适配器保留；顶层 / 嵌套发现、预算、显式撤销、空根零贡献的单测和 journey |
| agent-loop / session | `6a6f350b94` 新增 `ToolCallRecovery`：失败 step 关闭前补 `tool/result`，含纯文本 content、message `isError` 与 `data.error`；格式常量仍为 4 | 已有失败适配器能处理，新增 provider 回归分别覆盖旧 block 位、新 message 位、恢复事件，失败不能发现子目录指令。恢复结果缺少 call 配对时也不会创造 touch |
| 客户端 sessions / primitives / sidebar | fork 新增可选 `onCreated`；Input 改 forwardRef；sidebar 加遥测、rc.2 更新折叠布局；renderer 修复 factory ancestors 的引用稳定性 | 本插件不调用 fork；当前会话仍用 `retainedBy.mainView`，footer slot、Regular icons、Input / Modal 调用仍兼容。双面类型检查、客户端组件 / bundle 单测 |
| boot / profile / Connection RPC / registry storage | app-boot 增加可选 schedule bundle；`createRuntimeResolution` / `PluginPackages`、peer 精确校验、RPC 和 storage domain 接口未变 | 保留 bare-package carrier 行和 host-derived session authority；compose / behavior / journey 在真实 web 与 headless profile 上验证 |
| npm 安装树 / cordis / 升级脚本 | 旧上游的预发布范围可解析到同 minor 的更晚版本；`0.1.7-alpha.1` 首轮 boot 中 `dsh-client-connection` 被 runtime resolution 重定向到 `0.1.7-rc.2`，尽管顶层单测读到 alpha.1 | 门禁正确拒绝混装。`upgrade-dsh.mjs` 从现有精确 release-age 条目派生 workspace-only probe overrides，把整个已知 DSH 树与 cordis 固定到探测版，防止 `^4.0.3` 又解析出 `4.0.4` 并拆分调度 Symbol，拒绝覆盖自定义 overrides。probe 后恢复保存文件；生产门禁没有放宽 |
| Windows 矩阵安装 | 第一轮 CI 的八个旧版均在 `execFileSync('npm')` 报 `spawnSync npm ENOENT`，Windows 的 `npm.cmd` 不是直接可执行文件；开发版 frozen install 已通过 | 新增 shell-free npm launcher：Windows 通过当前 Node 执行随 Node 安装的 `npm-cli.js`，POSIX 保留原调用；回归覆盖带空格的 Windows 路径与参数边界，CI 重跑全部版本 |
| pnpm release age | pnpm 11 在 frozen install 和运行脚本前检查全部锁文件；0.2 传递 DSH 包及新 LibreOffice tooling 仍在年龄门禁内 | workspace 对当前开发版本逐包精确豁免，包含锁文件里的平台包；不使用跨版本包名通配。候选安装使用 `minimumReleaseAge=0`，临时重指后恢复 |

#### 持续矩阵与验证范围

CI 主车道从 `SUPPORTED_DSH_RELEASES` 派生版本轴，与 Linux / macOS / 启用的 Windows 做笛卡尔积；每个版本执行现有全部门禁，始终 enforce。开发 pin 验证 frozen lockfile，旧版用 upgrade 脚本重建一致安装树。日志制品同时包含版本与 OS，避免同名冲突。升级候选车道仍只给出证据，不自动扩大支持合同。

本次本地矩阵在 macOS 宿主运行，先以真实内核探针确认 Seatbelt，然后对每个版本传入 `DSH_PROBE_VERIFIED_DIALECTS=seatbelt`，因此 Seatbelt 不可执行会导致失败而非 skip。Linux bwrap / Landlock 与 Windows 本地未覆盖，由 PR 的对应 CI 腿验证；尚未完成的远端检查不得记为通过。矩阵期间逐版保存日志，结束后恢复 `0.2.0-rc.2` 的 manifest、workspace、lockfile、node_modules 与构建产物。

| 运行时 | 静态合同 / lint / 双面 typecheck / build | 单测 | compose / behavior / journey | 内核 |
|---|---|---|---|---|
| `0.1.5-rc.2` | 通过 | 346 passed / 3 skipped | 40/40、99/99、55/55 | Seatbelt 实际执行 |
| `0.1.6-alpha.1` | 通过 | 同上 | 同上 | 同上 |
| `0.1.6-alpha.2` | 通过 | 同上 | 同上 | 同上 |
| `0.1.7-alpha.1` | 通过 | 同上 | 同上 | 同上 |
| `0.1.7-alpha.2` | 通过 | 同上 | 同上 | 同上 |
| `0.1.7-rc.1` | 通过 | 同上 | 同上 | 同上 |
| `0.1.7-rc.2` | 通过 | 同上 | 同上 | 同上 |
| `0.2.0-rc.1` | 通过 | 同上 | 同上 | 同上 |
| `0.2.0-rc.2` | 通过 | 同上 | 同上 | 同上 |

单测三条 skip 是本机无 bwrap / Landlock 的两条真实执行断言，以及只适用于候选 warn 车道的一条互斥断言；没有把 macOS Seatbelt 跳过算通过。新版本不需要额外适配分支；升级风险集中在候选安装树一致性、异常恢复结果语义，以及未在本地运行的其他 OS。最终开发安装树已恢复；`pnpm install --frozen-lockfile`、`pnpm compat:check` 与 `pnpm docs:check` 均通过。

完整本地矩阵的计数对应 Windows npm launcher 修复之前的 349 项单测；launcher 另外新增两条回归，开发树在修复后重跑单测（348 passed / 3 skipped）。远端矩阵须以修复后的 PR head 为准。

远端验证（实现提交 `187d9ad`）：[CI run 36690954880](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/36690954880) 的 releases job 与 **九个版本 × Linux / macOS / Windows 的 27 个 verify job 全部 success**。Linux/macOS 执行完整冒烟与按宿主能力验证的内核断言；Windows 按既有范围执行静态合同、lint、双面类型检查、构建、单测和文档检查，明确不运行 POSIX 冒烟或内核多根断言。前述其他 OS 的本地未覆盖现已由远端平台回归补齐，仍不把缺失的内核机制视作实际执行通过。

### v0.1.5 发版准备（2026-09-30）

| 项 | 结果 |
|---|---|
| 发布状态与 CHANGELOG | 路线账本曾登记为 `v0.1.5` 待打 tag；README（中英）的支持版本、tarball 与 tag 示例对齐 `v0.1.5`；[`CHANGELOG.md`](../../../CHANGELOG.md) / [`CHANGELOG.en.md`](../../../CHANGELOG.en.md) 新增 `0.1.5` 条目 |
| 本地门禁 | frozen install、`compat:check`、lint、typecheck、build、`test`（347 passed / 4 skipped）、`smoke:compose` 40/40、`smoke:behavior` 91/91（4 项真实内核断言因宿主无可用 runner 跳过）、`smoke:journey` 52/52（2 项真实内核断言同因跳过）、`docs:check` 通过；`verify:all` 退出码 0（2026-09-30，macOS） |
| 跨平台矩阵 | 上方 PR #6 记录的 CI run `36690954880` 已验证九个 DSH 版本 × Linux / macOS / Windows，共 27 个 verify job 全绿；Windows 车道按既有范围不运行 POSIX 冒烟或内核断言 |

后续已由 `657e6d1` 产生 v0.1.5 发布提交并完成发布；以上保留当时准备阶段的证据。

## B1–B3：第二期 P1（2026-10-02）

分支为 `feat/lsp-windows-feature`，范围为用户确认的全部三项 P1；功能未发布，不改版本号。设计、接口与安全边界的唯一真源为 [ADR-0011](../../decisions/ADR-0011-multi-root-workspace-consumers.md)。

| 项 | 实现 | 验证状态 |
|---|---|---|
| B1 Additional Root LSP routing | additive 公共 query 包装，按 canonical file target 选择根，上游 stdio provider 负责独立初始化与池化 | 真实协议服务器 e2e、路由与撤销、取消、卸载恢复通过；九个支持版本的构建、类型与全量测试通过 |
| B2 Windows kernel multi-root | 插件 runner 调用公开 AclSandbox，root-set capability SID、自有 private temp、保留失败签名与 payload | SID / argv / fail-closed 结构回归通过；2026-10-03 Windows 本机原生执行通过；2026-10-11 起 Windows CI 在全部 11 个支持版本上原生执行内核探针、冒烟与原生用例，证据见[加固记录](#b1b3-加固与-windows-全量验证2026-10-11) |
| B3 workspace-files / client tree | 公共 list 和新版 path-watch 按根隔离；Connection 新增 files/readFile；对话框 lazy tree + preview，原生 Files actions slot 提供入口（**2026-10-12 P11 修订**：面板 `files`/`readFile` 端点与对话框内树随后移除——浏览统一在 Files 页签由逐字节复刻的上游树体承担，数据源正是本行的 list/watch 路由，见下方 P1–P11 节） | 真实 registry/fs 的包含性、跨主根、symlink/redirect、I/O 中撤销与 caps 回归通过；客户端 lazy tree、响应校验与可选 Files 入口通过；全量本地 gate 通过 |

新增可选 peer 纳入原精确版本合同，allowlist 无变化。旧版会话级 watch 原样保留；附加根树手动刷新（P11 起为原生 watch 自动刷新，同条修订）。已启动的 Windows/其他内核子进程使用启动时 scope，根集合变更限制后续进程。Windows 的 partial enforcement 与 caller-owned 目录条件继承上游。

本地验收（macOS，2026-10-02）：

| Gate | 结果 |
|---|---|
| `pnpm compat:check`、lint、双端 typecheck、build | 通过，开发 pin 为 `0.2.0-rc.2` |
| `pnpm test` | 最终 29 文件、371 passed / 5 skipped；含真实 LSP stdio e2e |
| `pnpm smoke:compose` | 44/44 |
| `pnpm smoke:behavior` | 91/91；4 个内核执行断言因本机没有可用 Seatbelt runner 跳过 |
| `pnpm smoke:journey` | 52/52；web/headless 的 2 个内核执行断言同因跳过 |
| 八个旧版矩阵 | `0.1.5-rc.2`、`0.1.6-alpha.1`、`0.1.6-alpha.2`、`0.1.7-alpha.1`、`0.1.7-alpha.2`、`0.1.7-rc.1`、`0.1.7-rc.2`、`0.2.0-rc.1` 各通过 exact pin 安装、compat、双端 typecheck、build 与全量测试（370 passed / 5 skipped；此时尚未追加 Files actions 入口用例）；未重复计作每版 smoke 证据 |
| 最终增补复验 | 八个旧版均再次通过双端 typecheck、build 和三文件定向测试（58 passed / 1 skipped）；Windows 原生用例另以独立 tsc 命令检查，在九个版本全部通过，四个 portable Windows 用例也复验通过 |
| Windows 原生验证 | 已加入真实 restricted-token Node、PowerShell 与 ConPTY 用例，检查两根可写、第三根拒绝、read-only 拒绝、移除根后拒绝、PTY 退出码保留；本机明确 skip，由已有 Windows CI lane 执行，尚无实跑结论 |
| `pnpm docs:check` / `git diff --check` | 通过，文档 0 errors / 0 warnings |

矩阵发现的差异均已回归：早期 `changes(scope, signal)` 必须按实际 arity 透传；旧版目录列表会先把 symlink 报为 `not-directory`，测试保留该上游错误顺序，不要求新版的 `outside-workspace` 先出现。上述跳过项不能算作本机内核执行证据，也不代表 Windows 平台验收完成。

### Windows 修复与复验（2026-10-03）

PR #7 原 HEAD `1c914b5` 的 [CI run 36987457760](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/36987457760) 中，九个 Windows job 均在测试阶段失败，18 个 Linux/macOS job 通过。开发基线和最早支持版的日志均显示 LSP 源码断言错误，以及原生用例启动不存在的 `src/windows-runner.js`；前者把 JSON 转义后的源码与原始 Windows 路径比较，后者从源码加载 provider，令 `import.meta.url` 落在 `src/`。

修复将 LSP 两个根的回传文本与完整磁盘源码比对，并让 Windows 原生用例加载发布产物 `lib/sandbox.js`、断言其实际启动 `lib/windows-runner.js`。本机全量复验还发现目录 symlink 无权限时，read-only 矩阵没有沿用 workspace-write 的条件，错误地访问未创建的链接；两种模式现使用同一夹具条件。未修改生产权限模型、兼容 allowlist 或 CI 的 Windows 必跑规则。

| 验证范围 | 结果 |
|---|---|
| 本机环境 | Windows 11 x64（`10.0.26200`），Node `24.14.0`，pnpm `11.25.0`，DSH `0.2.0-rc.2`，frozen lockfile 安装 |
| Windows 全量门禁 | `compat:check`、lint、双端 typecheck、build、`pnpm test`、`docs:check` 通过；29 文件，354 passed / 22 skipped；文档 0 errors / 0 warnings |
| 原生执行与 LSP 定向复验 | 两文件 6/6 通过；真实 restricted-token Node 和 PowerShell 可写两根、第三目录拒绝，ConPTY 两根写入及第三目录拒绝、退出码 `23` 保留，read-only 与移除根后拒绝；真实 LSP stdio 初始化和池化隔离通过 |
| 跳过范围 | 本机无目录 symlink 权限，以及不适用于 Windows 的 POSIX 内核执行和条件用例；Windows 原生 ACL 用例没有 skip。Windows 不运行 POSIX 冒烟和 `kernel:probe` |
| 修复后远端矩阵 | 修复提交 `41e4d1a` 的 [CI run 37118946523](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/37118946523) 全部 success：releases job 及九个支持版本 × Linux/macOS/Windows 的 27 个 verify job；九个 Windows job 均执行原生 ACL 用例，Linux/macOS 完成各自内核探针、测试及完整冒烟 |

### B1–B3 加固与 Windows 全量验证（2026-10-11）

分支 `feat/b1-b3-hardening`（在 `v0.1.6` 之上），目标是：把 B1–B3 的实现推到"每个消费者都有原生执行证据"、在 Windows 上 fail-closed 而不是静默运行、并让打包产物与 Windows 冒烟成为全平台门禁。提交序列：`9f9a1df`（硬化 + 原生 Windows 用例）、`af962fd`（原生 Windows 冒烟门禁 + 打包产物验证 + CI/release 门控）、`a0cfe22` / `1f72fb5`（CI 暴露后的测试修正）。**本节记录的是分支工作，尚未发布。**

**审计分类（在 v0.1.6 HEAD 上）**：

- **已实现且有原生证据**：B1 真实 stdio LSP 路由/池化；B2 root-set SID runner（Node / PowerShell / ConPTY，双根可写、第三根拒绝、read-only、撤销）；B3 list/watch 路由、面板 `files` / `readFile`、客户端 lazy tree；注册表 lease 的 junction 别名归一。
- **已实现但欠测 → 本批补测**：LSP 并发会话（不同主根）、Unicode/空格根、飞行中取消、服务器崩溃（下一次查询上游重生）、真实服务器的 redirect、存活服务器下卸载、win32 大小写变体 + 第二盘；Windows 敌意名称（CJK、空格、`'&^%!();,`）、第二盘、大小写/8.3 别名、junction 重指、confine 与 spawn 之间根被移除（127，子进程不启动）、非调用者拥有的根、撤销快照语义、4 个并发进程各自独立 private temp 且退出后删除、退出码/stdout/stderr 镜像、ConPTY Ctrl+C、Git Bash；大小写变体/8.3 别名的 lease 名一致；三进程争用恰好选出一个 authority。
- **确认的缺陷并已修复**：
  1. **Windows 网络/设备根此前会被接受**（UNC `\\server\share`、`\\?\`、`\\.\`、映射网络盘——`realpathSync.native` 会把它解析成 UNC）：restricted token 的 capability SID / Low label 无法证明能绑定 SMB 访问，且 stat UNC 路径会触发 SMB 认证。新增 `unsupported-path` 错误码：注册表校验在任何 fs 触碰之前词法拒绝、存量记录判 `invalid`、profile 扩展与 runner 均 fail closed（`SandboxUnavailableError` / exit 127，绝不无约束执行）。
  2. **runner 现在在 ACL 授予之后、spawn 之前重新验证每个根**（仍是目录 + canonical 身份一致），并要求 `--temp` 是已存在的目录。
  3. **面板文件路径此前不拒绝反斜杠**（POSIX 上 `..\..\x` 会词法解析到根内）→ 现在拒绝。
  4. **Windows reveal 总报失败**：`explorer.exe` 成功时退出 1 → win32 接受 0/1。
  5. **文件树 RPC 现在可中止**：组件卸载 / 路径 / 会话变化时取消在飞调用（Connection RPC 支持 AbortSignal，host 早已转发该信号）。
  6. **CI `pnpm test | tee` 缺 `pipefail`**：单测红了也能报绿 → 已修。
  7. **安装副本的 Windows runner 在 `main()` 之前就死于 `ERR_MODULE_NOT_FOUND`**（CI run `38131613042` 由 `smoke:packed` 暴露，`7702ffb` 修复）：`lib/windows-runner.js` 是独立 Node 进程，宿主的进程内插件包解析不适用，它的静态图却 `import '@deepseek-ai/dsh-sandbox'`（roots/windows-profile chunk 也一样）——从插件安装目录解析不到。`0.1.5-rc.2` / `0.1.6-*` 通过是因为那些版本仍写 module-fallback 目录；`0.1.7-alpha.1+` 的受限 pwsh 全部失败。checkout 内测试看不到它（checkout 的 `node_modules` 带着 peers）。修复：runner 的静态图只许 `node:`（新模块 `src/windows-runner-contract.ts`），上游 ACL 包改为从 `--upstream-runner`（上游 runner 自身路径）按包自引用 `createRequire` 解析后动态 import；`check-pack` 与"拷到无 node_modules 目录运行"的可移植用例双重钉住。
- **保留的上游限制（已记录，不算回归）**：Windows enforcement 仍是上游 `partial`；Git Bash/MSYS 在 restricted Low-integrity token 下无法启动（0.2.x：`NtCreateDirectoryObject … 0xC0000022`；0.1.5-rc.2：`CreateFileMapping … Win32 error 5`，exit 256）——上游 runner 与插件 runner 表现完全一致，Windows 受限 shell 就是 pwsh；上游 runner 调 `SetConsoleCtrlHandler(NULL, TRUE)` 且 ignore 标志被子进程继承，所以上游 confine 的子进程（空附加根）收不到 Ctrl+C，而插件 runner（非空根）用 Node SIGINT handler（不被继承），Ctrl+C 能到达子进程并由 runner 镜像其退出码（测试中为 130）；每个根集合的 standing workspace ACE 只增不减且永不撤销（与上游一致）；已启动进程保留启动时快照；`Local\` 命名信号量作用域 = 每登录会话，网络共享上的 `$DSH_HOME` 被多台机器使用不受 lease 保护（与上游 SessionWriteLease 相同）；elevated host 上的 foreign-owned 根：admin token 可能仍能授权，因此接受两种结局（exit 127 fail-closed，或 exit 0 且所有未授权写被拒），并且 unconfined admin 进程不是有效探针（libuv `FILE_FLAG_BACKUP_SEMANTICS` + backup/restore 特权绕过 DACL，restricted token 不能）。
- **新增 CI / 代码门禁**：`kernel:probe` 以**真实上游 runner** 验证 `windows-acl`（一次允许写 + 一次兄弟目录被拒——不能拒绝的探针不算 sandbox）并导出该方言，Windows 内核断言因此不可 skip；`smoke:compose` / `smoke:behavior` / `smoke:journey` 在 Windows 原生运行（pwsh executor + pwsh 工具、两个真实 git 仓库、web + headless 两条腿）；新增 `pnpm pack:check`（tarball 成员含 `lib/windows-runner.js`、每个 `exports` 目标、`cordis.patch.yml` 引用的每个模块、传递依赖的共享 chunk、`lib/windows-runner.js` 全图只许 `node:` 导入；当前 71 个成员）与 `pnpm smoke:packed`（tarball 经 `dsh plugin add` 装进隔离 `$DSH_HOME`，再从**安装副本**跑完整 behavior battery 并断言其解析路径在 checkout 之外）；以上门禁在 Linux / macOS / Windows 三平台全部执行；冒烟日志 `if: always()` 上传；新增 `gate` job（`needs: [releases, verify]` + `if: always()`），矩阵被 skip/cancel 不再可能显示为成功；release 的 publish 依赖可复用 CI 的 gate 并使用 `check-pack`。

**koffi 安装路径实测**（本机 macOS，DSH `0.2.1-alpha.2`，tarball 来源，全新 scratch profile）：第一次 `dsh plugin add <tgz>` 装完依赖后以 `[ERR_PNPM_IGNORED_BUILDS] Ignored build scripts: koffi@3.3.3` 失败；该 profile 的 `pnpm-workspace.yaml` **没有**留下 `set this to true or false` 待决标记；写入 `allowBuilds: { koffi: true }` 后重跑同一 `add` 退出 0，但插件**不在** `dsh.profile.bundles` 里（plugin-manager 的 reconcile 只激活本次运行中新增的依赖）；再做一次 `dsh plugin --profile <p> remove <name>` 加同一 `add` 才完成激活（`koffi install: Done`）。smoke 在 scratch home 内按此路径执行；对用户可见的处置见[故障排查：安装停在构建授权](../../troubleshooting/install-stops-at-build-approval.md)。

**本地验收**（macOS，DSH `0.2.1-alpha.2`，`DSH_PROBE_VERIFIED_DIALECTS=seatbelt`）：`compat:check` / lint / typecheck / build 通过；`pnpm test` 31 文件、412 passed / 18 skipped（12 = Windows 原生用例在 macOS 上的平台 gate）；compose 44/44、behavior 99/99、journey 55/55；`pack:check` 71 成员；`smoke:packed` 98/98；`docs:check` 通过。

**Windows CI 证据**：

| Run | 结果与暴露 |
|---|---|
| `38126361009`（`9f9a1df`） | 11 个 Windows job 同批失败 7 项，Linux/macOS 全绿：5 处测试前提错误（exit code 1 在 win32 是成功语义、`cmd /s` 引号破坏 8.3 查询、POSIX 断言在 win32 上跑、elevated runner 下"必须 127"前提不成立）、ConPTY Ctrl\C 超时、Git Bash MSYS 启动失败签名未覆盖 |
| `38127852508`（`af962fd`） | `kernel:probe` 验证 `windows-acl`；Git Bash parity 通过；仅剩两处：foreign-owned 用例的 icacls grant-only 锁定对 elevated 进程无效（admin 仍可写），PowerShell `Start-Sleep` 无交互时不响应 ConPTY Ctrl+C |
| `38128970508`（`a0cfe22`） | 仅剩断言修正：foreign-owned 改为 ACL 回读验证（unconfined admin 进程有 backup/restore 特权，不是有效探针）；Ctrl+C 结果 `upstream=timeout plugin=interrupted`——上游 runner 的 ignore-Ctrl+C 标志被子进程继承，改为断言插件侧被中断且镜像子进程退出码；Git Bash 在 `0.1.5-rc.2` 上是 `CreateFileMapping … Win32 error 5` / exit 256 的另一签名 |
| `38129713987` | Windows 上单测、compose 44/44、behavior 99/99 全绿；`smoke:journey` 50/5——断言在 JSON 序列化文本里找原始 Windows 路径（反斜杠被转义），改为按 `JSON.stringify` 转义拼写查找 |
| `38130676072` | Windows 上全部冒烟转绿；`pack:check` 无法 spawn `pnpm.cmd` → 改为经 `npm_execpath` 启动 |
| `38131613042` | `0.1.5-rc.2` / `0.1.6-*` 的 Windows 全绿（含 `smoke:packed`）；`0.1.7-alpha.1` 起 `smoke:packed` 暴露缺陷 #7：安装副本的 runner `ERR_MODULE_NOT_FOUND`（`@deepseek-ai/dsh-sandbox`）→ `7702ffb` 修复 |
| [`38134856191`](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38134856191)（`7702ffb`，最终代码 HEAD） | **全部 35 个 job success**：releases + 11 个精确 DSH 版本 × Linux / macOS / Windows 的 33 个 verify + `gate`。每个 job 的 `kernel:probe` 都实际验证了本机方言（macOS `seatbelt`、Linux `landlock`、Windows `windows-acl`）并设为必跑；33 个 job 均为 compose 44/0/0、behavior 99/0/0、journey 55/0/0、`pack:check` 71 成员、`smoke:packed`（安装副本）98/0/0。单测：Windows 414 passed / 18 skipped（`0.2.1-alpha.2` 419 / 13），Linux / macOS 408 / 24（`0.2.1-alpha.2` 414 / 18）。Windows 上 `windows-native.e2e.ts` 12/12 实际执行、无 skip；唯一的 Windows 侧条件跳过是 8.3 别名断言——runner 的 D: 卷关闭了短名生成，日志显式记录。实测结局：Ctrl+C `upstream=timeout`、`plugin=interrupted exit=130`；Git Bash 两侧同为 MSYS 启动失败；foreign-owned 根在 elevated runner 上走「授权成功但两处写均被拒」结局。Linux bwrap 仍因宿主 uid map 限制不可执行，Landlock 为 Linux 原生证据 |

## DSH 0.2.1 迁移与目录安全契约（2026-10-10，随 v0.1.6 发布）

分支 `feat/dsh-0.2.1-alpha.2-compat` 从 `main` 的 `f149fa4` 创建；本项现已包含于 `v0.1.6`。上游差异唯一真源是[接口审查](../../reference/dsh-0.2.1-migration.md)，目录、指令、LSP 和进程快照设计是 [ADR-0012](../../decisions/ADR-0012-session-origin-and-effective-cwd.md)。

| 项 | 当前证据 |
|---|---|
| 候选 `0.2.1-alpha.1` | 一致精确安装树，Cordis 4.0.4；lint、双面 typecheck、build；native Seatbelt test（381 passed / 8 skipped），compose 44/44、behavior 99/99、journey 55/55；该版本没有 workingDirectory/Worktree，所以四条新服务测试明确不适用 |
| 候选 `0.2.1-alpha.2` | 一致精确安装树，Cordis 4.0.5-alpha.1；真实 Host composition、web/headless Agent journey 和 native Seatbelt 测试通过；上游 install-time gate 拒绝候选 peers，隔离 profile 的 exact allow-version 豁免仅用于候选 lane |
| 正式精确合同 | allowlist 和所有 DSH peers 增加两个精确版本，开发 pin 为 alpha.2；Cordis prerelease 单独精确声明；生产仍 enforce，workingDirectory 为 optional service lookup，不成为旧 runtime 的必装模块 |
| 本地 alpha.2 enforce | compat、lint、双面 typecheck、build、test（389 passed / 4 skipped）、compose 44/44、behavior 99/99、journey 55/55，通过；无候选豁免 |
| Worktree / 目录 | Git 2.53 + 真实 Seatbelt 下 Primary/Additional 内的默认 pool 创建、访问、共享 gitdir、切回原项目、删除当前 checkout 后恢复、重复名称失败、取消、未授权 repository 拒绝通过；Registry 始终不由 Worktree mutation 改变 |
| 新旧进程 / PTY | 真实 Seatbelt 下旧 process 和 PTY 保留原 cwd 与 grant snapshot，撤销后新 confine 和 fs 写拒绝；没有修改已有 shell cwd |
| 继承的不变量 | fs / 三个 POSIX dialect 独立 grant parity、unknown dialect、mixed/incomplete gate、lease 争用/接管/拆除、symlink redirect、missing 恢复、LSP stdio、workspace-files caps/撤销、user-context 指令与 global 排除、同批 native 去重和 I/O 中撤销均由完整套件覆盖 |
| 本地未覆盖 | Linux bwrap/Landlock、Windows ACL/ConPTY 未在 macOS 本机原生执行；远端 Landlock 与 Windows 原生验收见下方，bwrap 仍未验证 |
| 上游限制 | Apple Git 2.39 不认识 `--no-lazy-fetch`，明确失败且不改 Registry；不删除该安全参数。native instruction baseline 的相对 project identity 可能在同构 cwd 间复用，插件不依赖它决定 authority；见接口审查。任意敌对 rename 的原子安全与即时撤销旧 kernel snapshot 不在既有机制保证内 |

支持矩阵扩大前已分别把两个版本作为候选跑过。正式 allowlist 下旧版矩阵和跨平台 CI 的最终结果见下方；任何 skip 均不计为该机制验收通过。

### 最终矩阵与平台验收

实现 HEAD `b32f452` 的 [CI run 38046100174](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38046100174) 全部 success：releases job + **11 个精确 DSH 版本 × Linux / macOS / Windows 的 33 个 verify job**。没有以候选 warn 或 installation exemption 运行正式矩阵。测试日志在成功时也上传，可核对执行与 skip，不能把 job success 解释为所有方言均原生验证。

| 范围 | 最终证据 |
|---|---|
| 本地全部旧支持版本与 alpha.1 | 十个版本分别重建一致安装树，compat/lint/typecheck/build/full test/compose/behavior/journey 全通过；该轮 382 passed / 10 skipped，44/44、99/99、55/55。六条 workingDirectory/Worktree 测试在这些版本不适用，其余 skip 为非 macOS 方言、Windows native 和候选专属断言。最终 LSP fallback 增补另由上述全部版本的 CI 全套复验覆盖 |
| 本地最终 alpha.2 | 标准 `pnpm compat:check`、lint、typecheck、build、kernel:probe、test、smoke、docs:check 通过；最终 31 文件、389 passed / 4 skipped；compose 44/44、behavior 99/99、web/headless journey 55/55；Seatbelt 必跑 |
| Linux alpha.2 原生 | 自带 Landlock launcher 探针实际执行并输出 `DSH_PROBE_VERIFIED_DIALECTS=landlock`；真实 grant parity 与六条 workingDirectory e2e 全执行，31 文件、389 passed / 4 skipped。包括两根 Worktree、外部 gitdir 拒绝、新旧进程和 PTY 的 cwd/grant snapshot。完整 Host/Agent 冒烟通过 |
| macOS alpha.2 原生 | Seatbelt 探针实际执行并设为必跑；六条 workingDirectory e2e 全执行，31 文件、389 passed / 4 skipped；完整 Host/Agent 冒烟通过 |
| Windows alpha.2 原生 | `windows-multi-root.spec.ts` 5/5 执行通过，含 restricted-token Node / PowerShell / ConPTY；workingDirectory e2e 5 passed / 1 skipped（仅 POSIX PTY 用例不适用），真实 Worktree 两根创建/失败/取消/未授权与外部 gitdir 拒绝、进程 snapshot 全通过。全套 31 文件、381 passed / 12 skipped；Windows 按既有设计不运行 POSIX smoke |
| bwrap 明确未验证 | Linux CI 已安装 bubblewrap，但实际 probe 返回 `bwrap: setting up uid map: Permission denied`。该宿主不允许原生执行，bwrap kernel assertion 明确 skip；没有关闭宿主限制来换取通过。结构/argv/独立 grant parity 通过，但不算 bwrap kernel 验收。Linux 平台原生保证来自实际执行的 Landlock |
| Registry / resume / 客户端 | 完整矩阵同时覆盖原 lease 争用、接管、Host stack restart、missing/redirect 恢复，native Session replay / cwd 恢复，LSP stdio pool、无 origin metadata 的 policy fallback、面板 Session 订阅/旧响应丢弃、workspace-files 隔离与指令撤销 |
| 开发树恢复 | 已恢复 alpha.2 的 manifest、workspace、lockfile、node_modules 与 lib；frozen install 通过，无临时 probe overrides，无上游修改。版本仍为 0.1.5；迁移已实施并验证、未发布 |

第一轮 `00afbce` 的 CI 虽全绿，但 Linux 探针只查 PATH，漏掉自带 Landlock；因此不采用它作为 Linux kernel 验收。改用公开 addon launcher 后 `77c0d30` 的 CI 如实暴露原生测试仍指向 inert launcher；原生组已在 `3691d00` 修正。最终上述 run 完成所有版本/平台复验。保留这段证据说明，避免未来再次把不存在 launcher 导致的 skip 当成原生安全验证。

后续建议：在允许 user namespace 的 Linux runner 补做 bwrap 原生验收；向上游报告相对 instruction baseline identity 在同构 cwd 切换中的协调风险；需要撤销旧进程权限时先终止旧进程，再使用新 scope 启动。以上均不通过扩大授权、禁用 sandbox 或重实现 Worktree 绕过。


### PR #8 P1 返工（2026-10-10）

[评审问题](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/8#discussion_r4237499560)指出 native 代投递的文件在 cwd 切换后被上游撤回，插件却保留完整 digest，导致仍获授权的指令不再补发。修复规则见 [ADR-0012 指令章节](../../decisions/ADR-0012-session-origin-and-effective-cwd.md#指令)。新增四条回归覆盖无 baseline identity 的 remove、baseline 替换、不同项目复用同名 scope，以及补发构造失败后无需新 touch 的重试；同时断言同批去重、插件投递不受 native remove 影响和根撤销仍生效。

本机 alpha.2 enforce 下 compat、lint、双端 typecheck、build、完整 test（31 文件，388 passed / 9 skipped）、docs:check 和 diff whitespace 检查通过；指令定向测试 53/53，web/headless journey 52/52。本次受限进程没有可用 kernel runner，journey 的两条 confined bash 断言明确 skip；不更新为 native 内核验收，也未复跑其他版本和平台。此前最终矩阵证据属于上述历史 HEAD，修复后的跨版本结果由新提交 CI 另行验证。

### v0.1.6 发版验证（2026-10-11）

`v0.1.6` 已通过 `pnpm release patch --tag` 生成，发版提交为 `466b3bb`，并推送至 `origin/main`，连同 annotated tag `v0.1.6`。本机 `pnpm verify:all`、`pnpm compat:check`、`pnpm docs:check` 均通过；本机 Test 为 393 passed / 4 skipped，compose 44/44、behavior 99/99、journey 55/55。GitHub [Release workflow run 38121365127](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38121365127) 全绿：11 个支持版本 × Linux/macOS/Windows 的 33 个 verify job，以及 npm publish 和 GitHub Release 创建均成功。

### PR #10 全面复核与第二轮返工（2026-10-12，未发布）

本轮修复内容见 [B4–B8 返工记录](./2026-10-11-b4-b8-p2.md#全面复核与第二轮审查返工2026-10-12pr-10)，接口与工程规则分别维护在 ADR-0013、ADR-0014 与开发工作流。

本机开发 pin `0.2.1-alpha.2`：compat、lint、双端 typecheck、build、docs:check 通过；Seatbelt 探针原生执行成功并通过 `DSH_PROBE_VERIFIED_DIALECTS=seatbelt` 约束完整测试，结果 **500 passed / 22 skipped**（35 文件通过、1 Windows 原生文件跳过）。compose **46/46**、behavior **99/99**、web/headless journey **62/62** 全通过；pack:check **73 个成员**通过，安装 tarball 的 packed behavior **98/98** 通过。外层 Agent 沙箱内的首次探针被 sandbox_apply 拒绝，该次不计原生证据；上述完整测试与冒烟在外层沙箱之外执行。

本机不能证明 Windows ACL 夹具修复有效，也不能验证 Linux 内核；本轮跨版本与原生平台证据采用下方修复后矩阵，不沿用历史 HEAD 的绿色结果。

首轮 [CI run 38153898876](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38153898876) 暴露新 SID 查询命中了 Git Bash PATH 中的 GNU whoami，所有 Windows 腿在夹具前置步骤失败；不将此轮计作修复验收。后续改为按 System32 绝对路径启动原生 whoami/icacls/takeown，继续完整矩阵验证。

最终实现 HEAD `9c2a27a` 的 [CI run 38154203689](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38154203689) **35/35 success**：11 个精确支持版本 × Linux/macOS/Windows 的 33 个 verify job，以及 releases/gate；没有整项自动 retry 或额外 skip。全部 Windows 版本均完成 kernel:probe、原生测试、三冒烟、pack:check 与 smoke:packed。`0.1.6-alpha.1` Windows 日志确认 foreign-owned 夹具成功、受限子进程实际执行且两个未授权写都被拒（不是仅靠 runner 127 早退通过）；该腿 **496 passed / 26 skipped**，compose **46/46**、behavior **99/99**、journey **62/62**、packed behavior **98/98**。一次完整矩阵通过是本轮验收证据，不等于证明所有未来环境都不再出现瞬态失败；后续诊断与有界重试规则见开发工作流。

### PR #10 第三轮返工（2026-10-12，未发布）

修复内容见 [B4–B8 第三轮记录](./2026-10-11-b4-b8-p2.md#第三轮审查返工2026-10-12pr-10)。修改前回归复现了实时 scope 顺序、发布次数与真实指令预算优先级三个失败，修复后注册表 / 指令套件 **107/107** 通过。

本机开发 pin `0.2.1-alpha.2`：compat、lint、双端 typecheck、build、docs:check 通过；完整测试在原生 Seatbelt 探针及 `DSH_PROBE_VERIFIED_DIALECTS=seatbelt` 约束下 **501 passed / 22 skipped**。compose **46/46**、原生 behavior **99/99**、原生 web/headless journey **62/62**、pack:check **73 个成员**、原生 packed behavior **98/98** 全通过。

同时在外层 Agent 沙箱内验证 runner 不可用路径：Seatbelt 返回 `sandbox_apply: Operation not permitted`，journey **55 passed / 0 failed / 2 skipped**，两条腿均明确跳过 shell cap 与命令产物，fs 与模型上下文检查仍执行。此记录只证明本机可用 / 不可用两种路径；本轮跨版本、Linux 与 Windows 结果须以本次推送触发的 CI 为准。

### Files 头部根浏览 P1–P11（2026-10-12，未发布）

实施计划见 [files-header-root-browsing](../completed/2026-10-12-files-header-root-browsing.md)（P1+P2 为原计划两阶段，P3–P11 为目检后追加，每阶段一个提交），决策见 [ADR-0015](../../decisions/ADR-0015-files-tab-plugin-owned-browsing.md)。

- **P1**（提交 `7e3232a`，后改写为 `79f6934`）：`files.actions` 的 launcher 改为仅图标齿轮钮并经 flex `order` 前移到 reload 左侧；footer 触发器同步换齿轮。
- **P2**（提交 `252b927`）：该 occupant 升级为 `RootSwitcher`——伪装成 PathLabel 的触发钮 + `Menu`（主根、`list` RPC 返回的附加根、footer 的「管理…」入口）；选中附加根时 `closest('[data-files-root]')` 定位 pane，`createPortal` 挂入 `RootFileTree` 接管树区，`:has()` 规则同条件隐藏原生 path/body/reload；owner 缺 `absolutePath` 时退回 P1 compact launcher。对话框行内 `RootFileTree` 与 `files.browse` 词条下线。`data-files-*` 钩子（非槽位契约）列入 `.agent/note` 升版目检与故障排查条目。
- **P3**：触发钮后随一个 `PathLabel`（`mrfw-switcherPath`）显示**选中根**的完整路径——主根即原标签的值，附加根为其 canonical 路径；复用上游同一组件，观感与原生一致。`.mrfw-rootSwitchBtn` 收敛为只缩不涨（`flex: 0 1 auto`），PathLabel 接管头部剩余宽度。
- **P4**：附加根态的刷新收进 header——`RootFileTree` 移除行内「刷新文件树」按钮，header 在原生 reload 位置出现同款 `.mrfw-switcherReload` 图标钮（28px tool 配方）；与 portal 同生同灭，纯菜单降级时不渲染。
- **P5**：刷新改原地重拉消除 loading 闪烁——`RootFileTree` 收 `reload` 计数 prop，各挂载目录 effect 依赖之；只有根或目录身份（`entry.id + path`）变化才清空当前列表，reload 重拉在现有行下后台进行、成功就地换数据，展开态与文件预览均保留。
- **P6**：对话框添加行的权限选择器从系统原生 `<select>` 换成 ui-primitives `Menu` 锚定下拉（胶囊触发钮 + 勾选行，与根选择器同一控件族）；`onSelect` 即显式选择，`accessChosen` 的「未触碰不携带 access」语义不变。权限字形（`IconWorkspaceWrite`/`IconReadOnly`）仅 0.1.7+ 存在，走新增的 `maybeIcon` 软探测，缺失版本回退为无图标行。
- **P7**：附属根行的权限徽标移到显示名右侧（`.mrfw-rootName` 改 flex 基线对齐，徽标 `flex:none`）；复制从独立 IconButton 变为路径本身——抽出的 `PathCopy` 组件（`.mrfw-pathCopy` 无边框按钮保持文本观感，`.mrfw-pathCopyIcon` 在流内 `opacity:0` → hover/focus 才可见、出现不回流，点击路径区任意处复制完整 canonical path，反馈沿用 copyPath↔copied 的可达名切换）随后推广到**全部路径展示**：主根行与「当前执行目录」行同一控件。
- **P8**：只读→读写升级的 `window.confirm` 换成 ui-primitives `Modal` 确认层——覆盖在工作区目录对话框之上，footer 为普通取消钮 + 红色确认钮（`.mrfw-btnDanger` 补实底配方）；Escape/遮罩即取消，portaled Modal 的 Escape 也纳入底层对话框的守卫；降级方向照旧无确认直接执行。
- **P9**：修复 open-in-app 分离按钮在附加根态仍路由到主根——上游 `files.actions` 槽位的 `absolutePath` 永远是原生树根。`:has()` 规则隐藏原生 `data-open-target="directory"` 元素（整项隐藏 + 内层兜底双选择器），`src/client/open-in-app/` 逐字节复刻上游 `ui-open-in-app` client 包（基线 `d743267388` = `0.2.1-alpha.2`，`FORK.md` 钉住清单与同步步骤）在原位渲染同款控件、`absolutePath` 换为选中根；宿主路由不校验根归属，locale `bind('open-in-app')` 复用上游词典，应用选择共享 `dsh.open-in-app.choice`。css 走 `*.module.css.ts` shim（类名前缀 `mrfw-open-`）；`*Regular` 图标族缺席的运行时不渲染按钮（同型降级）；`dsh-client-store` 因此进入 bundle module-table；`workspace.openLocal` 快捷键仍开主根（已知限制）。**遗留（P10 已修）**：复刻钮与窗口右缘间距仍有像素级偏差（容器 gap + 整项隐藏两轮修正后目检仍报残留，根因与修复见 P10）。
- **P10**：修复 P9 遗留的复刻钮 4px 左偏——根因查明：上游 `ui-renderer` 给每个槽位渲染点包 `<div data-slot="sidebar.right.tab.files.actions" style="display:contents">`，`.header` 的子项是该包装而非 occupant 的 Menu 锚 span，P9 的 `> * > *` 选择器命中包装自身、被其内联 `display:contents` 压成惰性；只有内层兜底生效，空锚 span 仍以零宽 flex 项多占一个 header gap。第一选择器改经 `data-slot` 锚点定位 occupant 项，`> * > *` 形态删除；新增 jsdom DOM 回归（`element.matches()` 钉住命中面：命中原生锚 span、不命中包装 / 选择器 / 复刻锚，主根态全不命中）。
- **P11**：自绘 `RootFileTree` 换成 `src/client/files-tree/` 下逐字节复刻的上游 `ui-sidebar-files` 树体（基线 `d743267388` = `0.2.1-alpha.2`；`directory-node`/`face`/`store`/`FilesBody.module.css` 字节级一致，行级 `Entry`/`Level` 逐字节，唯一改写是外壳函数——根由 `sessions.byId` cwd 换成选中根 prop、tab 身份经 `data-dockkit-content` 取得、生命周期由 takeover AbortController 供给、文件经 `fileAddressFor(sessionId, undefined, path)` + `sidebarRight.openResourceIn` 交给 viewer 打开）。`files.actions` 注册按上游同款声明 `store`/`inject`（session 域合法形态，`ui-open-in-app` 有先例）；列目录与 watch 直走 `remote.workspaceFiles.list/changes` 的按根路由，remote 缺席时 lazy proxy 折成 `gateway/internal` 失败。插件私有 `files`/`readFile` 端点、`browseRoot`、`FilesView`/`FilePreview`、`RootFileTree.tsx`、`panel-files.ts` 与对应词条整体删除。复刻体类名 `mrfw-ft*`、不携带 `data-files-root`/`data-files-body`；primitives 探针失败时整树不渲染（同型降级）。附带收益：附加根树获得原生 watch 自动刷新与按 tab 的滚动/展开记忆。新增 devDep `dsh-client-ui-dockkit`、`dsh-util-workspace-path`、`dsh-api-remotes`、`dsh-client-ui-session` 全部钉在 dev pin；清单与同步步骤见 `src/client/files-tree/FORK.md`。

本机开发 pin `0.2.1-alpha.2`：P1 与 P2 各自完成时 `pnpm lint` / `typecheck` / `test` / `build` / `docs:check` / `smoke`（compose 46、behavior 99、journey 62）全绿；P10 完成时 lint / typecheck / test / build / docs:check 全绿（未跑 smoke）；P11 完成时 lint / typecheck / test（37 文件 537 passed / 22 skipped）/ build / docs:check / smoke（compose 46、behavior 99、journey 62）全绿。web 组合三态（无附加根原生观感 / 附加根选中接管 / 切回主根还原）的目检见计划 Validation 记录。

本轮 PR #11 审查修复（2026-10-12，未发布）：四项修复与回归面见[计划的 Review corrections](../completed/2026-10-12-files-header-root-browsing.md#review-corrections2026-10-12)，关联读取约束见 ADR-0011。开发 pin `0.2.1-alpha.2` 上 compat / lint / 双端 typecheck / build / docs:check 全通过；原生 macOS 内核探针确认 Seatbelt 可用，并在 `DSH_PROBE_VERIFIED_DIALECTS=seatbelt` 下运行全套测试（**549 passed / 22 skipped**）、三冒烟（compose **46/46**、behavior **99/99**、journey **62/62**）、pack:check（**92 个成员**）与 packed behavior（**98/98**），全部通过。外层 Agent 沙箱中的探针仍报告 `sandbox_apply: Operation not permitted`，原生验证在该沙箱之外完成；本轮其他版本与 Linux / Windows 的执行证据以本次提交触发的 CI 为准。

## B9：附加根三态权限与跨 SandboxMode 执行一致性（2026-10-13）

用户要求为第二期补充 B9，覆盖 P1 / P2 的沙箱与根权限问题。目标权限合同和完整实施路径见 [B9 专项计划](../completed/2026-10-13-b9-root-access-and-sandbox-modes.md)，本节不复制权限矩阵。

- **进度**：Phase 1 审查与定案完成（2026-10-13），决策写入 [ADR-0017](../../decisions/ADR-0017-three-state-root-access-and-sandbox-modes.md)，ADR-0001/0003/0011/0012/0013 已按修订节同步。定案：三档编码 `recordedPath`→`inherit`（旧 read-write 记录自动改为继承）、`readOnlyRecordedPath`→`read-only`、新增 `readWriteRecordedPath`→固定读写；新增根默认 `inherit`；PTC（run_code）纳入 B9。**Phase 2–4 实现已落地（2026-10-14）**：注册表三档 + 迁移、scope 有效权限与 deny 集投影、fs fence 三态化、命令 `--inherit` 与面板三态、`ctx.sandbox` 受限 confine（`restrictedArgvPrefix`）与四方言 profile 变换、新增 `multi-root-process-fence` 行以 ALS + `spawn`/`spawnTerminal` 包装覆盖 shell / PTC / PTY 的 Full-access bypass。**两个组合按定案显式拒绝（spawn 前 fail closed，不计为已实现）**：Landlock Full-access + 局部只读——「尝试扩展」结论为不可行，上游启动器只有 `--ro`/`--rw` allowlist union，无法对 `--rw` 祖先做子树减法；Windows ACL 同组合——上游 runner 只导出 grant 模型（`AclSandbox`/`AclWriteGrant`），无 deny ACE 或受限 token 原语，新机制延后并在 ADR-0017 标注。Windows read-only + 固定读写经独立 runner `--mode read-only` + `--additional-root` 实现，仅授权固定根。
- **首个关口**：已核对——全部 11 个支持版本的 bash / pwsh / PTY / PTC 在 Full-access 下绕过 `confine()`；接缝定案为公开方法包装（`ctx.shell.execute`/`ctx.ptcRuntime.execute` 注入 ALS、`ctx.subprocess.spawn` 按 ALS confine、`ctx.subprocess.spawnTerminal` 由 env 会话标记恢复策略），不新增替换行。
- **本轮证据范围**：文档规划、11 个支持版本的执行链源码核对、真实 composition dump；`pnpm vitest run` 575 通过 / 22 跳过（含新增 `tests/process-fence.spec.ts` 16 例：受限 prefix、ALS 注入、PTY 会话解析 fail-closed、撤销对下一进程生效、各后端 deny 边缘）；`pnpm docs:check` 通过。**Seatbelt 已获 macOS 原生执行证据**：`sandbox-exec` CLI 直接验证两种构造（`(allow default)+(deny file-write* (subpath R))` 下 R 内写 EPERM、ambient 写放行；deny-default + graft `(allow file-write* (subpath W))` 下 W 内写放行、其余写 EPERM；且验证 deny 必须拼 canonical 路径——`/tmp` 词法拼写不匹配 `/private/tmp` 实路径，这正是 deny 集取 `recordedPath` 的原因），`smoke:behavior` 105/105 在真实组合内端到端复验（只读会话下 inherit 根拒写、固定读写根经 fs/dialect/confined bash 三面可写，0 skip）。`smoke:compose` 48/48、`smoke:journey` 62/62、`pack:check` 与 `smoke:packed` 104/104（打包产物含 `multi-root-process-fence` 行）全绿。bwrap / Landlock / Windows ACL 的原生执行证据待对应平台补齐；结构确认不当作原生证据。不借用 B4–B8 的绿灯作为 B9 证据。
- **Windows 重新纳入（2026-10-13）**：用户撤回先前延后决定；新增 [ADR-0019](../../decisions/ADR-0019-windows-token-attributes-and-conditional-acls.md)，并按修订节更新 ADR-0017 / ADR-0011。独立 runner 的 ambient token-attribute 路径接入现有 shell / PTC / PTY fence；原生回归覆盖混合根九格、PowerShell / Node 后代、受保护 DACL、overwrite / delete / rename / ACL edits、弱化令牌仍拒写、ConPTY 与 fd 7。行为冒烟及 packed 冒烟增加真实 Full-access pwsh 的主根 / 未登记目录 / 固定读写允许、显式只读拒写、移除后新进程可写断言。本机开发 pin `0.2.1-alpha.2` 上 compat / lint / 双端 typecheck / build / docs:check / pack:check 全通过；测试 **574 passed / 33 skipped**，compose **48/48**，behavior **95 passed / 6 skipped**，journey **55 passed / 2 skipped**，packed behavior **94 passed / 6 skipped**。本机外层沙箱禁止 Seatbelt 嵌套（`sandbox_apply: Operation not permitted`），Windows 原生组按平台跳过，原生结果须由本次提交 CI 确认，不能以 macOS 结构测试代替。
- **Windows 原生开发结果（2026-10-13，尚未验收）**：PR #12 的原生 CI 已实际运行新九格 / pwsh / Node 后代 / ConPTY / fd 7。restricting deny SID prototype 能通过普通文件矩阵，但 WRITE_RESTRICTED 漏掉根重命名，改完整 restricting check 后重命名被拒；token 副本保护继续被 actual impersonation 写入证伪（CI [38341055967](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38341055967)，输出 escaped）。条件 ACL prototype 改用 mandatory local attribute，但设置 TokenSecurityAttributes 返回 **Win32 1314**（CI [38342020870](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38342020870)），普通宿主缺少 SeTcbPrivilege；启动 fail closed，条件 ACL 后续尚未取得原生证据。当前 Windows Full-access 局部只读不能记为已完成，是否引入需管理员安装的最小 SYSTEM broker 等待用户范围决定。ADR-0018 标记被替代，ADR-0019 保持 Proposed；不得去掉实际令牌弱化回归来获取绿灯。
- **发布状态**：未发布，未指定目标版本；本轮不修改兼容 allowlist、创建 tag 或发版。

### B9 审查修复批次（2026-10-13）

- 第一批：失效登记保留负授权边界，Registry 刷新/重启不解除只读；成员资格与写授权继续 withheld。新增缺失目录重建、刷新/重启与显式移除回归。同时补齐面板会话模式/有效权限/工具 cap、两向继承切换确认和三模式模型 cap 说明。开发 pin 的相关七文件测试 194 passed，lint、双端 typecheck 与 docs:check 通过。其余批次与原生矩阵继续执行，不据此将 B9 标记完成。

- 第二批：实现管理员安装的每用户 SYSTEM token-attribute broker；普通 runner 在 Win32 1314 时请求服务，并读回 mandatory/inheritable 属性后继续 ACL 与 spawn。服务只允许给同用户 restricted token ADD 固定拒写属性，资源限时限长，不接受命令或 ACL 操作；安装源码随 tarball 发布，Windows CI 原生验证前安装。用户已授权继续开发，先前等待范围决定的状态由本条取代；原生执行验收继续跟进。

- 第三批：Full-access shell/PTC 结果补齐实际后端诊断，保留 execution 身份/缓存，PTC 改用公开 run 接缝；Landlock 组合选择 bubblewrap 并保持 ambient 文件/进程/设备语义；bwrap 临时区的只读根保持可读。客户端样式与双语回归同步修正，真实组合/packed 冒烟扩展到各 OS 的 Full-access 与 PTC。实际执行证据随后记录。

- 第三批本机验收：开发 pin 0.2.1-alpha.2；compat / lint / 双端 typecheck / build / docs:check / pack:check 全通过。原生 Seatbelt probe 通过并强制执行对应内核断言：测试 593 passed / 26 skipped（其他平台不算本机证据），compose 48/48、behavior 126/126、journey 62/62、packed behavior 125/125，所有冒烟 0 skip。Windows broker 原生 CI 已通过编译和安装，已修复属性查询 ABI；完整 Windows 与 Linux bwrap 证据继续由当前提交矩阵确认。

- 第四批：矩阵发现并修复旧版 shell 的公开前台 run 入口绕过（不能只包 execute/start）、Windows 管道必须先读取再取得 impersonation 身份、跨平台 POSIX profile 路径比较，以及原生测试将 Landlock 成功运行的 partial warning 误判为 runner 失败。新增独立 runner 证据分类、九格 edit、三模式工具 cap 和真实 Koffi UTF-16 回归；兼容笔记双语同步。Windows 弱化令牌反绕过断言保留，新的矩阵继续验证。

### B9 暂停交接（2026-10-13）

用户要求暂停开发并准备交接。B9 **未完成、未验收、未发布**，继续工作需要用户恢复任务。用户此前已授权具体实现 Windows ADR-0019，不能把拒绝启动作为最终结果，也不能删除弱化令牌实际写入回归来获取绿灯。

- 仓库：`<checkout>`；分支 `feat/sandbox-permision-harden`；[PR #12](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/12)。最新开发提交 `e472de4` 已推送。此次交接前工作树干净；本节是暂停后唯一文件修改，尚未提交/推送。PR 已更新实现说明，但最后的测试数字和 Windows 失败事实尚需在恢复后同步。
- 已推送批次：`55cb262` 失效只读边界/有效权限；`1c822db` SYSTEM broker；`9f00548` Framework 编译歧义；`e946389` 属性查询 ABI；`598df54` 进程诊断/Linux 混合权限；`7c4e99f` UTF-16 指针解码；`e472de4` 旧 shell run/管道认证读取顺序/原生证据分类。
- 本机最终原生验证：开发 pin `0.2.1-alpha.2`，Seatbelt 内核断言强制运行；测试 **598 passed / 26 skipped**，compose **48/48**、behavior **126/126**、journey **62/62**、packed behavior **125/125**，冒烟全部 0 skip。compat、lint、双端 typecheck、build、docs:check、pack:check 通过。其他平台的跳过不是本机原生证据。
- 当前 [CI 38348496627](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38348496627) 对应 `e472de4`，暂停时仍在运行，不取消。已成功32个 job（包括 versions job），另有两个 macOS job 运行中。**全部11个 Windows 版本失败**；应在恢复后重新读取最终结果。Linux latest 和 Ubuntu 22.04 的原生执行已有通过结果，不能据此认为 Windows 完成。

**必须首先处理的 Windows 缺陷**：broker 已通过编译、管理员安装、管道认证、设置 mandatory/inheritable 属性与 runner 读回；进程可以启动，但条件 ACL 没有兑现拒写。`tests/windows-native.e2e.ts` 的完整矩阵、mutation/弱化令牌、ConPTY 三组失败：显式只读根返回 `allowed`；overwrite/delete/rename/弱化令牌组出现 `escaped`；ConPTY 只读写入也放行。代表 job `115135351095`（`0.1.7-alpha.2, windows-latest`），原始日志在本机 `/tmp/b9-broker-handshake.log`（约693–780行；临时文件可能在后续会话消失，以 CI 为准）。启动成功绝不能作为拒写验收。

排查入口：`src/windows-deny.ts` 的 token 构造/属性读回/`protect()`/child spawn，`src/compat/windows-native.ts` 的公开进程 seam，`scripts/windows-broker/service.cs`。目前条件表达式为 `(Exists DshMultiRootDeniedRoots && DshMultiRootDeniedRoots Contains "<root-id>")`，条件 deny 放在 ACL 首位。普通 token 设置 Win32 1314 已通过 broker 解决；新失败根因尚未证明。下一步应直接核验真正子进程 token 是否保留属性、条件 ACE 是否匹配，而不是继续修改无证据的兼容分支。Chromium 的公开属性实现使用本地属性名和 mandatory flags，可作为 ABI 参照；不要把 `@User` 属性与本地属性混为一谈。

**已修复的兼容风险（恢复后第一批提交）**：`src/compat/process-result.ts` 的 `decorateProcessOutcome()` 曾把旧 shell `start()` 返回的活跃后台 handle 交给 `stampProcessResult()` 展开复制，丢失原型、live 字段和方法身份——上游 `processOutcome(proc)` 与 `renderProcessRead(proc.readOutput(), proc.sandbox)` 都读同一对象，副本会冻结 `status`/`exitCode` 并脱离消费者持有的实体。现改为：handle 形态（`done` settle 钩子、可调成员或非平凡原型）保持身份原地返回，`sandbox` 戳记推迟到 `done` 结算时按上游 `onProcessDone` 语义原地写入；结算 stderr 由 `process-fence.ts` 的 spawn 包装器经 `SubprocessHandle.collected.stderr.readFrom(0)`（游标无关、全版本契约）捕获并作为 diagnostics 传入。回归覆盖 live handle 身份/取消/轮询、结算戳记、runner 失败分类与无 diagnostics 退化；本机 602 passed / 27 skipped。

恢复后顺序：读取本节与 ADR-0017/0019、双语兼容笔记；检查 Git/最终 CI 状态；修复以上两个问题；运行相应本机检查并分批提交推送；保留 Windows 原生反绕过测试，确认11版本×4系统完整 gate；更新本账本和 PR 最终证据后才能记完成。版本 allowlist、版本号和 tag 均未变更，用户没有要求发布。

CI 日志读取：`gh api --allow-escape-sequences repos/cherrchen/dsh-plugin-multi-root-workspace/actions/jobs/<job-id>/logs > /tmp/b9-job.log`。`gh run view --log-failed` 会尝试写受限制的默认 cache；上述 API 可避开。Git 写操作及本机脱离外层沙箱的 Seatbelt 原生执行需要工具的 `require_escalated`；前述提交/推送与测试已有授权。不要输出完整 journey/smoke 日志，其中可能含临时 web 认证令牌。

### B9 交接续作：普通 deny-only 组候选（2026-10-13）

收到外部 Agent 的交接并恢复开发。起点 `b947250` 干净且已推送；旧 start() 活句柄与 stderr 诊断改动保留。复核 CI 38376966866：UserClaimAttributes 写入在两种 token 上均返回 87；`@User` Exists 探针的 PowerShell 非终止 SDDL 错误导致 ACE 未装入，该探针不能证明求值。当前改用 [ADR-0020](../../decisions/ADR-0020-windows-normal-deny-groups.md) 候选：NtCreateTokenEx 镜像调用方身份，仅增加普通 deny-only groups，普通 deny ACE 不依赖属性求值；弱化测试增加 disable 全部普通组后的真实写入。B9 仍未完成、未发布，Windows 原生与完整门禁正在验证。

候选提交 `13af289` 的本机门禁：compat/typecheck/lint/build/docs 全通过；602 passed / 26 平台跳过，随后加入 broker 响应边界回归后 609 passed / 26 平台跳过；Seatbelt probe 通过，compose 48/48、behavior 126/126、journey 62/62、packed behavior 125/125，所有冒烟 0 skip。CI [38391229281](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38391229281) 的 Windows C# 编译通过、服务启动失败，尚未到达 token / 拒写断言。续作将 token-create 特权错误移到可回传的请求阶段，并让现有单版本 diag workflow 在相关 PR 编辑时运行；完整 CI 门禁不减少。弱化测试进一步要求实际激活成功且写返回 EPERM/EACCES，增加受限调用方向 broker 请求重建 token 的拒绝断言。

单版本 [diag 38391811054](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38391811054) 明确失败为 `EnablePrivilege(SeCreateTokenPrivilege) win32=1300`，LocalSystem 并不持有候选需要的 token-create 特权。续作改用 ADR-0020 的专用虚拟服务账户和仅该 SID 的固定 LSA rights；完整 CI 旧候选轮次已取消，继续保留全矩阵验收要求。

专用账户候选 `7d49dfb` 的 [diag 38393091968](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38393091968) 已通过账户 rights 配置及服务启动，实际请求在 `OpenProcessToken(client)` 返回 Win32 5。修正为仅在短暂模拟已认证 pipe caller 期间获取其 process-token QUERY/QUERY_SOURCE handle，随后恢复服务身份进行创建；不放宽 token DACL，也不接受客户端提供身份。

候选 `4969e15` 的 [diag 38393550613](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38393550613) 已越过 token handle 获取，下一处失败为信息查询 size 检查。空 claim/group 通道改为提供至少 16 字节的已清零 buffer 进行实际查询，必须确认第二次 API 调用成功；不能从 sizing 失败推断空集合。所有查询错误现在带信息类编号及 Win32 码。

候选 `f7c753e` 的 [diag 38394060369](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38394060369) 已越过全部 source 信息查询并执行 NtCreateTokenEx，返回 NTSTATUS c000000d / Win32 87。续作补齐 ObjectAttributes 的 SECURITY_QUALITY_OF_SERVICE（SecurityImpersonation）；另拒绝源 token 的可继承 local 属性，以免创建时丢掉原有属性约束。

候选 `5e65a2f` 的 [diag 38395468655](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38395468655) 给出参数对照：原始 groups 创建成功（base=0）；增加直接 deny-only groups 后 extended、no-policy、legacy 均 c000000d。改为仅在 broker 内创建普通组，随即以 CreateRestrictedToken 转成 deny-only 并移除 bypass privileges，服务不回传中间 token；runner 再过滤并验证普通组 deny-only / 非 enabled，不把 mandatory 位当作抗删除依据。普通组与可删除 restricting list 的区别仍由原生弱化测试验证。

候选 `83139a2` 的 [diag 38396216276](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38396216276) 已通过 NtCreateTokenEx、服务内转换 deny-only、runner 再过滤及组读回，失败移到 CreateProcessAsUserW / Win32 1314：broker 创建的 token 不属于 runner 自身的直接派生，不能享受免 SeAssignPrimaryTokenPrivilege 的启动例外。续作的本地候选新增仅对 caller-owned 初始暂停子进程设置 token 的 v3 操作；helper 创建 flag、parent PID、线程归属、源身份与实际 child token 回读均须验证，失败终止且不 Resume。专用服务账户需要另增 SeAssignPrimaryTokenPrivilege，用户已明确授权该新增权限及提交、推送、原生 CI 验证；不为宿主用户授予特权，不把 argv 或路径传给服务。

暂停赋值候选 `43e0a26` 的 [diag 38399814375](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38399814375) Windows 原生 18/18 全通过，包括真实弱化 token 激活后拒写及 broker 重建拒绝。完整矩阵同一提交发现 `0.1.5-rc.2` 的公开 process binding 缺少 GetFileType，fd 7 用例失败；兼容层通过公开 extension seam 补齐，保留原生回归，不缩小版本矩阵。补充安装、升级、卸载的真实 LSA policy 回读验证，要求预存服务权限与其他账户权限不变。完整门禁尚待最终结果。

### B9 最终验收（2026-10-13，未发布）

实现提交 `006637a` 的 [完整 CI 38400586253](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38400586253) 全部通过：11 个精确支持版本 × Windows / macOS / Ubuntu latest / Ubuntu 22.04 = 44 个 verify job，另加 releases 与总 gate，46/46 success。各版本执行 compat、lint、双端 typecheck、build、kernel probe、单元与原生测试、compose / behavior / journey、pack / packed smoke、docs；Windows 在安装 broker 后运行，结束卸载并撤销新增权限。全部 11 个 Windows job 的原生 ACL suite 18/18 通过；包括 overwrite / delete / rename / ACL reset、protected descendants、两种真实 token 激活后拒写、disable 全部普通组后的拒写、broker 重建拒绝、ConPTY / fd 7 与宿主写允许。

[diag 38400586259](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38400586259) 额外验证服务安装、升级、卸载的实际 LSA policy；预存服务登录权保留，其他账户权限不变。Mac 本机最终 618 passed / 26 其他平台跳过，Seatbelt probe 通过，compose 48/48、behavior 126/126、journey 62/62、packed behavior 125/125 全部 0 skip；compat / lint / typecheck / build / pack / docs 通过。

Phase 5 完成，专项计划移至 completed；ADR-0020 Accepted，ADR-0019 保留 Superseded 历史。用户已分别明确授权提交推送、专用服务账户及包括 SeAssignPrimaryTokenPrivilege 在内的固定权限集合。未合并 PR #12、未创建 tag、未发布；完整门禁不扩大 allowlist，Windows 仍报告 partial，授权快照、standing ACL、path-based TOCTOU 与 owner/parent 操作边界见 ADR-0020 及其链接的 ADR-0018。

### B9 外部审查返工（2026-10-14，PR #12 评审）

外部评审复现两个 Full-access P1 绕过，另有一项 Linux 可用性问题；三处修复设计经用户批准，合同与残余记录于 [ADR-0017 修订](../../decisions/ADR-0017-three-state-root-access-and-sandbox-modes.md#外部审查返工修订2026-10-14pr-12-评审) 与 [ADR-0007 第三轮修订](../../decisions/ADR-0007-registry-authority-lease.md#第三轮修订2026-10-14b9-评审返工)。

- **权限未知 ≠ 没有限制（P1）**：`registry-contended` 进程发布空 scope 后，Full-access 的 fs / 进程 fence 曾把空 deny 集当作「无限制」放行 ambient 写，可覆写另一进程登记的 `read-only` 根。修复：scope 新增 `authority: 'available' | 'unavailable'`（注册表在构造、contended、storage-failed、config-invalid、releaseAuthority 转场标 `unavailable`，`openDomain` 发布完全部记录后标 `available`）；不可用时 fs fence 以 `writableRoots({mode:'workspace-write'})` 判定（仅主根 + temp，不并入 scope 成员），进程 fence 用 `clampedExecution`（`workspace-write` 探针 + 原 profile 前缀）钳制 shell / PTC / PTY，`spawnTerminal` 不可解析会话经 `hasActiveDenyRoots()` 自动拒绝；模型拓扑在 Full-access + 不可用时固定陈述降级句。
- **Full-access 不再沿用旧 FsTarget（P1）**：`checkedTarget` 只在 Full-access 且 deny 集为空时返回调用方 target（零根逐字节保持上游）；其余一律重解析 displayPath、以新 `targetKey` 判 deny 并以新 target 执行 mutation——评审的「父目录被换成指向只读根的符号链接」绕过被关闭。
- **bwrap deny 根改用 `--ro-bind-try`（历史决定，已取代）**：此前 `--ro-bind <missing recordedPath>` 使 bwrap 启动即失败，一个被删除的只读根会打断全部 Full-access shell（或其位于 temp 时的 workspace-write 命令）。deny / restrict（含 landlock→bwrap）均改 `--ro-bind-try`；当时记录了命名空间内可重建目录的残余，后续 P1 确认 fs fence 无法兜底进程写入，以下修订撤回该决定。

回归：新增 `tests/b9-review-regressions.spec.ts`（反转的两条 P1 复现：争用进程写只读根与 ambient 区均拒写、接管后恢复；stale target 的 write/edit 均拒写）；scope / registry-lease 增加 authority 状态断言；process-fence 增加 clamped prefix（与上游 `workspace-write` confined argv 逐项一致）与不可解析终端断言；dialects 期望改 `--ro-bind-try`；prompt-context 增加降级句。本机门禁输出见交接报告；未发布，版本号与 allowlist 不变。

#### 用户终端直通与 `$DSH_HOME` 负授权（2026-10-14 第二批）

两项用户产品决策，合同记录于 [ADR-0017 修订节](../../decisions/ADR-0017-three-state-root-access-and-sandbox-modes.md#用户终端直通与-dsh_home-负授权修订2026-10-14)。

- **面板用户终端任何模式不受约束**：原 `spawnTerminal` 按 `env.DSH_SESSION_ID` 恢复会话的机制把面板用户终端（controller 同盖该标记）误伤为受限对象。判别改为 `DSH_PTY_SESSION_ID`：全部 11 个支持版本的 `dsh-terminal-bash` backend 启动 agent PTY 时经 `childEnvironment` 盖该标记（与 `DSH_SESSION_ID` 并列），面板 controller 不盖——env 无该标记即用户终端，任何模式直通；有则按 `DSH_SESSION_ID` 恢复会话与策略，会话不可解析且 `hasActiveDenyRoots()` 时 fail closed。`ctx.terminals` 不包装：`optional-persistent-terminals` 组 `isolate: terminals` 使 registry 在 web profile 不可达，env 判别同时覆盖隔离与未隔离挂载。
- **`$DSH_HOME` 受限 Full-access 负授权**：scope 新增 `dshHome` 配置（patch 行 `dshHomePath()`；非法值记 error 忽略）。`danger-full-access` 且（deny 集非空或 authority `unavailable`）时把 canonical home 追加进 `deniedRoots`（`protectedHome`），`workspace-write` / `read-only` 与零根健康 authority 不追加；主根在 home 内时 deny 胜出。fs 有专用拒写文案；`clampedExecution` 改收 deny 集并按 workspace-write 分支规则 graft（POSIX `denyProfileArgs`、Windows `widenWindowsProfile(…, [], denied, primary)`），不可表达 → `SandboxUnavailableError`；模型拓扑固定陈述 home 拒写。Windows 风险如实记录：该 deny 经 `runWindowsDenied` 对 home 整树写**持久化** deny ACE（含父目录守卫），ambient 进程不受影响但存在 ACL 写入量与节点失败面。

回归：process-fence agent/user 终端分轨断言（controller 形状直通、backend 形状受限/钳制、不可解析会话 fail closed）、scope `protectedHome` 触发矩阵、b9-review-regressions home 拒写（含主根位于 home 内）、patch 行 `dshHome`、prompt-context home 陈述句。未发布；版本号与 allowlist 不变。


#### 最新 P1：缺失拒写根的 bubblewrap 挂载（2026-10-14）

PR #12 的最新 Code Reviewer 指出 `--ro-bind-try` 会在只读根被删除时跳过挂载，使 Full-access 进程可重建并写入该路径。deny / restrict（含 Landlock fallback）统一改回强制 `--ro-bind`，源缺失时拒绝启动；workspace-write 可写父挂载同样失败关闭。决策、代价与回归场景见 [ADR-0017 缺失根修订](../../decisions/ADR-0017-three-state-root-access-and-sandbox-modes.md#缺失-deny-根必须失败关闭2026-10-14pr-12-最新-p1)。新增 `tests/missing-deny-root.spec.ts`；未发布，版本与 allowlist 不变。

验证：新增三项构造回归在旧实现上均失败，修复后通过；开发 pin 的 compat、lint、双端 typecheck、build、docs:check、pack:check 通过。原生 Seatbelt probe 通过；完整测试 643 通过 / 29 平台跳过（含新增的 3 项 Linux 原生用例）；compose 48/48、behavior 126/126、journey 62/62、packed behavior 125/125，全部冒烟 0 skip。本机为 macOS，bubblewrap / Landlock 不可用，Linux 原生缺失源执行证据待推送后的 CI，不把结构断言记为原生验证。

#### 四项审查修复（2026-10-15）

基于 PR #12 头部 `5103979` 复现并修复：未知 registry authority 保留共享 temp grant 的 fs/进程绕过；四后端遗漏 deny 祖先覆盖 grant 的反向相交；Windows broker 无法容纳 64 根加 home 与历史超限存量；安装记录写入失败未撤销新增 LSA rights。权限决定见 [ADR-0017 本轮修订](../../decisions/ADR-0017-three-state-root-access-and-sandbox-modes.md#临时区与反向包含修订2026-10-15)，有界 IPC、超预算显式拒绝与安装回滚见 [ADR-0020 本轮修订](../../decisions/ADR-0020-windows-normal-deny-groups.md#协议容量与安装回滚修订2026-10-15)。未发布，版本号与兼容 allowlist 不变。

本机 macOS 开发 pin：compat、lint、双端 typecheck、build、docs:check、pack:check 通过；原生 Seatbelt probe 与含新增回归的完整测试 **668 通过 / 33 平台跳过**；compose **48/48**、behavior **126/126**、journey **62/62**、packed behavior **125/125**，全部冒烟 0 skip。新增 Windows 原生 64/80 根加 home、primary-only 执行，以及真实 LSA/SCM 的三类失败注入随本次 CI 验证；本机不把平台跳过记为 Windows/Linux 原生证据。

#### 祖先改名解除拒写修复与文档/接缝收尾（2026-10-15）

PR #12 评审的又一处 P1：deny 根的祖先目录被改名即可把整棵树搬出 subpath deny（Seatbelt 只检查被操作路径，fs fence 的 deny 集仍记旧 `recordedPath`）。修复钉住每个祖先：Seatbelt deny 形式追加 `(literal A)`（restrict 与 workspace-write covered 根一致），bwrap 把祖先 `--bind A A` 自绑成挂接点使 `rename` 返回 EBUSY（restrict 全量钉扎、workspace-write 只钉可写 bind 目标内的祖先，tmpfs 内与挂载点自身不绑，ro-bind 仍在最后）；Windows deny ACE 随目录对象走，不受影响。代价：受限 Full-access 进程不能 rename/chmod/touch 被拒根与 `$DSH_HOME` 的祖先目录（目录内读写不变）。决定、复现与取舍见 [ADR-0017 本节](../../decisions/ADR-0017-three-state-root-access-and-sandbox-modes.md#祖先目录改名不得解除拒写2026-10-15pr-12-评审-p1)；Linux 侧由 bwrap 原生 CI 用例验证，本机无 Linux。

同批收尾：进程栅栏的入口形状探测收进 `src/compat/process-entrypoints.ts`（shell `execute`/`run`/`start` 与 PTC 公开 `run`，业务代码不再出现版本注释）；Full-access 拓扑在存在拒写根时补「授权变化只对后续操作与新进程生效」句；README/CHANGELOG/指南补齐 B9 三态合同与两条边界说明（Landlock 主机上受限 Full-access 需要 bwrap 否则拒绝启动；持久终端/已运行进程保留启动时 deny 集）。未发布，版本号与 allowlist 不变。

#### Windows 真机验证（2026-10-16）

Windows 实机（非 CI）验证暴露两个 CI 不可见的问题，处置经用户定案，决策细节见 [ADR-0020 本轮修订](../../decisions/ADR-0020-windows-normal-deny-groups.md#过滤令牌放行与打包子进程诊断2026-10-16windows-真机验证)：

- **UAC 过滤令牌被误拒**：`TokenHasRestrictions` 拒绝规则挡住全部非提权 UAC 管理员 runner（`Caller process must be an unrestricted installation identity`）。改判为拒绝 `IsTokenRestricted` 与 `TokenIsAppContainer`、放行 filtered token——minted token 逐位镜像调用方身份，放行不扩权。**升级后需 `install.ps1` 重装 broker**。
- **打包子进程保持 fail-closed，加诊断**：Store/MSIX 版 `pwsh.exe`（别名与包内真实 exe 均验证走打包激活，「直接执行包内 exe」候选证伪）携带包身份，`NtCompareTokens` 必不等。runner 在赋值前用 `GetPackageFullName` 探测，对打包子进程给出指向 MSI/ZIP 版的可操作诊断。

真机验证数字：

- **提权侧**（broker 按当前源码重装，ZIP 版 pwsh 7.6.0 居 PATH 首位）：`windows-native.e2e` **24/24**（含三条新增用例：filtered caller 放行、受限子进程嵌套 deny 集、打包子进程诊断；remint 用例改判为验证 deny-only 组被保留）；smoke:behavior **126/0/0**、smoke:packed **125/0/0**。
- **改动前的提权基线**：compat/lint/typecheck/build/kernel:probe/docs 通过；compose **48/0/0**。`working-directory.e2e`（2 用例）与 journey 的「pwsh saw the other repository's diff」仅在提权下失败（提权创建的目录归 Administrators，git 报 dubious ownership）；非提权下通过：**5/5**、journey **62/0/0**。
- **改动后的非提权侧**：探针矩阵——node `denied:EPERM`、Store 别名 exit 127 且报打包诊断、ZIP pwsh `denied:UnauthorizedAccessException`；smoke:behavior **126/0/0**（先清除上一提权运行留下的 Administrators 属主 `%TEMP%\dsh-multi-root-smoke` 残留后）、smoke:journey **62/0/0**、smoke:packed **104 通过 / 1 跳过**（见残余 2）；`windows-native.e2e` **22/24**，2 个失败均为仅提权可构造的夹具（另一驱动器 `C:\` 根的 ACL 写入、指定外国属主）；完整 `pnpm test` **676 通过 / 2 失败（同两条）/ 46 跳过**；compat/lint/typecheck/docs 通过。
- CI run 38767014622（commit 21369d9，win32 断言修复提交）：**47/47 全绿**。

残余（真机发现，未修改）：

- **属主残余**：runner 的 deny 遍历要求每个路径归调用方所有。提权会话创建的路径属主为 BUILTIN\Administrators，而 filtered token 仅以 deny-only 形式持有该组。此类路径若为只读根或位于 `$DSH_HOME` 内，非提权的受限 Full-access 启动会 fail-closed 报 `deny ACL requires caller-owned path`（安全但不可用，须先修正属主，例如 `icacls <path> /setowner <user> /T`）。
- **pnpm 硬链接残余**：pnpm 把全局 store（`%LOCALAPPDATA%\pnpm\store`）中的包文件硬链接进 `$DSH_HOME` 各 profile 的 `node_modules`，也链进其他项目。硬链接共享同一份安全描述符，因此 `$DSH_HOME` 的 deny 遍历会把常驻 deny ACE 写到 store 文件及其全部链接上。已用 `fsutil hardlink list` 验证：一个仓库文件与 store 及另两个项目共享链接。而 store 文件若是提权安装所建，遍历会 fail-closed（即非提权 `smoke:packed` 的跳过原因：`...\dsh-plugin-multi-root-workspace\CHANGELOG.md` 非调用方所有）。跳过硬链接不安全——文件内容写受文件自身 ACL 约束，跳过的链接会让受限子进程改动 `$DSH_HOME` 内的插件代码。留作用户的开放决策。

未发布，版本号与 allowlist 不变。

## 分支安全审查修复（2026-10-16 起，门禁已执行）

`feat/sandbox-permision-harden` 的分支安全审查（[2026-10-16 审查计划](./2026-10-16-branch-security-review-and-hardlink-isolation.md)）确认 R1–R4 四条发现；修复按计划的三阶段推进，本节记录进度与证据。

### Phase A：统一负授权规则（R2 + R3，已实施）

- **R2 修复**：`widenForScope` 的 read-only 分支在 graft 固定读写根之后同样应用 `denyProfileArgs`——Seatbelt 在 allow 之后追加 deny（last match wins），bwrap 沿用缺失根失败关闭决定使用强制 `--ro-bind`，Landlock 对不可表达的子树减法 fail closed（`SANDBOX_UNAVAILABLE`）；windows-acl 此前已拒绝同一重叠。同步/Promise 形状与上游 `enforcement` / `denialSignatures` / `runnerFailureRules` 不变。
- **R3 修复**：`classifyStoredRoots` 改两遍分类——第一遍逐条独立判定（recorded boundary 绝对性、以其判主根重叠先于 redirect），第二遍对全部结构有效记录的 recorded boundary 两两比较，任一重叠双方判 `membership-conflict` invalid：成员资格 withheld 但 recorded 边界仍作为 deny 发布，结果与展示顺序/重启无关。`registry.add` 改用 `reservedRootBoundary` 收集保留边界（missing、redirected、冲突记录都算），仅按索引豁免精确复活的同一行。结构损坏记录照旧不发布任何投影。
- **本批证据**：`pnpm exec vitest run tests/roots.spec.ts tests/registry.spec.ts tests/missing-deny-root.spec.ts tests/sandbox-multi-root.spec.ts tests/b9-review-regressions.spec.ts` —— 130 通过 / 27 跳过（平台与内核原生用例）；`pnpm typecheck`、`pnpm docs:check` 通过。新增回归：mocked 上游 `confine` 的四方言 read-only 组合（POSIX 形状在 Windows 上亦可跑，sync/Promise 两路）、missing/redirected 子根双向包含拒绝、redirected 保留原边界、legacy 重叠两种顺序均判冲突且 deny 保留、重建缺失只读子根后真实 `MultiRootFileSystem` writeText/edit 拒写且内容不变。
- **明确未做**：Phase B（R1）另行实施见下节；Phase C（R4，硬链接预检 + profile 隔离命令）未开始；完整门禁（compat:check、lint、build、完整 test、kernel:probe、三项 smoke、pack:check、smoke:packed）与 macOS/Linux 原生执行留待实施验收阶段统一运行——mocked 上游的 profile 构造验证不充当 POSIX 内核拒写证据。
- **发布状态**：未发布；版本号、tag 与版本 allowlist 不变。

### Phase B：Windows 祖先路径钉扎（R1，已实施）

- **机制**：`src/compat/windows-path-guard.ts` 经公开 `extendWin32ProcessBindings` 接缝绑定 CreateFileW 等原语，为每个 deny 根钉住从卷根到根本身的去重祖先链——每个目录持有 GENERIC_READ + 读/写共享（不含 delete sharing）的常驻句柄，实机探测否决了 FILE_READ_ATTRIBUTES 属性级句柄（不参与删除共享门）。同句柄校验目录属性、非重解析点、`HANDLE_FLAG_INHERIT` 清零、内核最终 DOS 拼写一致；任一环失败逆序释放并拒绝启动，不写任何祖先链持久 ACL。
- **runner 集成**：`runWindowsDenied` 在 token 请求与 ACL 编辑之前获取钉住；`closeSync(7)` 与 `waitForProcessExit` 包入子进程 try 后，先 `terminateWindowsJobAndWait`（TerminateJobObject + ActiveProcesses 轮询至零，无超时）排空 Job 再关句柄，钉住在全部资源清理中最后释放。runner 被强制终止为异常边界——句柄随进程消亡、后代由 kill-on-close 兜底。
- **本批证据**：`pnpm exec vitest run tests/windows-native-adapter.spec.ts` —— 26 通过（新增 mocked Job 排空：先 terminate 再轮询至 ActiveProcesses=0、Sleep(10) 间隔、Win32 失败不透传）；`pnpm exec vitest run tests/windows-native.e2e.ts -t "ancestor guard|preserves ConPTY output and the control descriptor"` —— 5 通过：真实受限子进程 rename deny 根父/祖父目录均拒绝、ambient 写仍可用，宿主 `MultiRootFileSystem` 对原拼写 writeText/editText 仍 `FS_SANDBOX_DENIED` 且内容不变；退出子进程的 Job 后代被排空（pid 死亡先于钉住释放、逃逸标记未写出）；ConPTY terminate 后钉住释放且无存活进程；祖先被 DELETE 独占句柄预占时发布版 runner 在 spawn 前 127 拒绝；ConPTY 输出与 fd 7 控制描述符回归不变。原型组「deny path guard」4 通过 / 1 跳过（本机无第二可写固定盘，第二驱动器钉扎未验证）。`pnpm build`、`pnpm typecheck`、`pnpm lint`、`pnpm docs:check` 通过。
- **明确未做**：Phase C（R4，硬链接预检 + profile 隔离）未开始；完整门禁与 macOS/Linux 原生执行仍留待实施验收阶段。
- **发布状态**：未发布；版本号、tag 与版本 allowlist 不变。

### Phase C1：Windows 全根硬链接预检（R4，已实施）

- **机制**：`src/compat/windows-deny-preflight.ts` 在祖先钉住之后、任何 token 请求 / ACL 编辑 / 锁工作之前，对全部 deny 根做只读递归预检——FILE_READ_ATTRIBUTES + 全共享打开、`GetFileInformationByHandle` 读身份、`GetFileType` 要求普通文件为磁盘类型，每个检查句柄在下行前关闭；任一打开 / 类型 / 身份 / 目录列出失败（含句柄关闭失败，聚合保留原始错误）都使启动在零副作用点拒绝并报出根与路径。任一普通文件 `links > 1` 一律拒绝：快照无法证明链接拓扑，保守不试图证明——不跳过 `node_modules`，不做全局重置。诊断区分「protected DSH home」（指向挂起的 `/workspace-folders isolate-profiles`）与登记根（建立独立副本）。
- **写侧收紧**：ACL 遍历消费快照（深度优先序），目录继承与否由快照属性决定；写目录继承 ACE 前比对即时 `readdir` 名单与快照名单；`protect` 在即将写 ACL 的活句柄上 `verifyHandle` 复核属性位 / 卷序列 / 文件索引 / link 计数；根父目录守卫（树外、无快照）是唯一豁免 `verifyContent` 的调用且不启用 OICI。非事务性如实记录：复核到写之间的恶意并发外部修改仍可能竞过，零副作用只承诺到预检失败点。
- **标签透传**：`--protected-home` 只做诊断标签——`scope.protectedHome` 经 `restrictedExecution` / `restrictedArgvPrefix` 第四可选参、`restrictWindowsProfile`、runner 契约解析（仅 standalone `danger-full-access`、须为 deny 根成员）传到 `runWindowsDenied`，不改变任何授权。
- **本批证据**：`pnpm exec vitest run tests/windows-native-adapter.spec.ts tests/windows-multi-root.spec.ts tests/process-fence.spec.ts` —— 73 通过（新增 7 项 mocked 预检用例：快照序 / 句柄协议 / 硬链接与 home 标签 / 重解析不下降 / 打开·读·列出·关闭失败与聚合 / verifyHandle 身份与 link 复核；parser 标签校验与 fence 标签转发）；`pnpm exec vitest run tests/windows-native.e2e.ts -t "hardlink preflight|ancestor guard"` —— 11 通过：深层硬链接、末根硬链接首根零变化、同树双名、protected home 标签拒绝、不可读文件拒绝、junction 目标未扫描未改写、独立副本成功且外部原件不变——SDDL 前后快照逐字节比对，全部失败都在任何 ACL 副作用之前 127 退出且子进程哨兵未创建。`pnpm build` 通过。
- **明确未做**：C2——`/workspace-folders isolate-profiles` 命令、profile 迁移与硬链接冒烟夹具未实施；完整门禁与 macOS/Linux 原生执行仍留待实施验收阶段。
- **发布状态**：未发布；版本号、tag 与版本 allowlist 不变。

### Phase C2：profile 硬链接隔离命令与冒烟夹具（R4，已实施）

- **命令与检查**：`/workspace-folders isolate-profiles` 落地为宿主侧维护命令（面板无端点），默认只读检查、`--apply` 迁移。`src/profile-isolation.ts` 只认 `profiles/` 下 `package.json` 可解析且 `dsh.profile` 为对象的真实目录；整 home 递归扫描统计目录 / 文件 / `nlink>1` 与不可检查项，任一不可读子树报 incomplete 不报干净；home 本身是重解析点即拒绝检查，profile 内重解析点只计数不下降。
- **保守 YAML 迁移**：不引入 yaml 运行期依赖——`parseWorkspaceYamlKeys` 是严格子集扫描器，拒绝缩进 tab、指令 / 文档标记、重复顶层键、非 `key:` 顶层行及 `&` `*` `!` `|` `>` `{` `[` 起始的复杂值；缺失文件用上游 `initProfile` 同款模板补 `packageImportMethod: copy`，标量值按原始 span 原地替换（注释、引号与 CRLF/LF 保留），其余一律 refused。写入走 `<file>.mrw-<pid>.tmp` + rename 原子就位，重解析点目标拒绝写穿；`cordis.patch.yml` 的 `multi-root-command` 行新增 `dshHome` 配置。
- **诊断与 remediation**：预检文案移除「pending」措辞，指向现已存在的命令；`--apply` 报告逐 profile 的 written / replaced / noop / refused，并在仍有多链接文件时给出 PowerShell 安全引用（`& 'path' -Verb RunAs` 风格单引号转义）的退出宿主 → 删 `node_modules` → 按 lockfile 重装步骤。copy 不隔离既有硬链接、不修复 Administrators 属主、不撤销历史 store ACE——三条边界在命令输出、ADR 与指南中一致声明。
- **冒烟夹具**：`scripts/lib/dsh-runtime.mjs` 新增 `ensureProfileCopyImport`，`installPluginProfile` 在首个 `dsh plugin add` 前落 copy 配置，journey / compose / behavior / packed 冒烟 profile 全覆盖（正向）；`smoke-behavior` 另建保持默认硬链接的 scratch profile，用真实 runner `--deny-root <home> --protected-home <home>` 断言 127 + 硬链接拒绝文案 + 子进程未运行（负向，不与正向夹具共享 home）。
- **本批证据**：`pnpm exec vitest run tests/patch.spec.ts tests/profile-isolation.spec.ts tests/command.spec.ts` —— 80 项执行，79 通过 / 1 跳过（新增 23 项隔离套件：YAML 子集接受/拒绝面、span 精确替换、确认 profile 过滤、重解析边界、整 home 多链接统计、incomplete 结论、模板创建 / 追加 / 替换 / noop / 拒绝矩阵、原子写失败、PowerShell 引用；命令解析、帮助、hint 与 handler 集成；patch `dshHome` 断言）。`pnpm run build:types`、`pnpm run bundle`、`pnpm typecheck`、`pnpm lint`、`pnpm docs:check` 通过。本机另以与冒烟负向相同的夹具形状实跑发布版 `lib/windows-runner.js`（scratch home + profile 内指向 home 外「store」文件的真实 `linkSync` 硬链接，`--deny-root <home> --protected-home <home>`）：退出 127，stderr 为 `windows-acl-run: hardlinked file inside the protected DSH home … has links=2; … run \`/workspace-folders isolate-profiles\` …`，子进程哨兵未创建——零副作用拒绝、文案指向 C2 命令，本机非提权会话实机验证。
- **明确未做 / defer**：非提权 CI lane 未新增——GitHub Actions `windows-latest` 全程提权，非提权进程需第二账户或计划任务，超出本批范围；预检拒绝本身发生在 token / broker 之前，非提权环境可本地回归（冒烟负向即此路径）。完整门禁（compat:check、完整 test、kernel:probe、三项 smoke 实跑、pack:check、smoke:packed）与 macOS/Linux 原生执行仍留待实施验收阶段。
- **发布状态**：未发布；版本号、tag 与版本 allowlist 不变。

### 实施验收（2026-10-17，门禁执行完毕）

- **套件与类型**：`pnpm typecheck`、`pnpm lint`（0 警告 / 0 错误）、`pnpm run build:types`、`pnpm run bundle`、`pnpm docs:check`、`pnpm compat:check`、`pnpm pack:check`（109 个打包成员）全部通过。完整 `pnpm test` 串行执行（`pnpm pack` 的 `prepare` 会清空重建 `lib/`，与测试并发会产生假象，不可并行）：49 个文件、771 通过 / 49 跳过 / 0 失败；其中 `windows-native.e2e.ts` 38 通过 / 2 跳过。
- **冒烟实跑**：`smoke:compose` 48 通过；`smoke:behavior` 112 通过 / 1 跳过；`smoke:journey` 62 通过；`smoke:packed` 111 通过 / 1 跳过。唯一跳过原因一致：本机 `pwsh.exe` 是 MSIX 商店版，受限 token 拒绝 packaged 子进程——上游既定限制，非本批缺陷。
- **内核探针**：`pnpm kernel:probe`——windows-acl 可用；seatbelt / bwrap / Landlock 本机不存在，POSIX 原生执行仍未验证（mocked profile 构造验证不充当内核拒写证据）。
- **验收期修复（测试/冒烟基础设施，非产品代码）**：`tests/windows-native.e2e.ts` 的 `secondDrive()` 盘符比较既有缺陷——`'C:\'` 与 `'C:'` 比较恒不等，单盘机把 C: 当作不同盘在卷根跑 xdrive 用例，撞上游 `grantWrite` 写 mandatory label 的 WRITE_OWNER 需求；归一化后本机如实跳过（CI 的 `D:` 仍会真跑）。`sddlOf` 改用 `icacls /save` 替代 `powershell Get-Acl`——本机混合 PowerShell 5.1/7 `PSModulePath` 与共享 ModuleAnalysisCache 使 spawn 的 `powershell.exe -NoProfile` 间歇性模块加载失败，属宿主环境抖动。`scripts/smoke-behavior.mjs` 清理识别进程内映射的 `.node` addon：packed 模式下 `boot()` 从 scratch profile `dlopen` `koffi.node`，映射期间所有者进程自身无法删除——残留仅当全部由映射 addon 解释（每个失败文件是 `.node`、每个失败目录是其祖先）且注入了 `DSH_SMOKE_HOME` 时移交父进程在子进程退出后删除；独立运行的严格清理语义不变。
- **复审修复（推送前）**：`isolate-profiles --apply` 两处复审发现已修——整体缩进的顶层 YAML 一律 refused（原先误判 `packageImportMethod` absent 并追加零缩进键，使合法文件失效）；临时文件改 `wx` 独占创建，既有文件 / 硬链接 / 符号链接不再被写穿或删除，仅清理本进程创建的临时文件。新增 4 项回归；修复后完整套件 49 文件 775 通过 / 49 跳过 / 0 失败，冒烟四项、`pack:check`、`docs:check` 重跑全绿。
- **边界如实记录**：macOS / Linux 内核原生执行本机不可用；xdrive 第二可写盘路径本机跳过（无第二固定盘）；非提权 CI lane 按 C2 节 defer。
- **发布状态**：未发布；版本号、tag 与版本 allowlist 不变。

### PR #12 复核与 Windows packed smoke 清理修复（2026-10-17）

- **旧审查逐项复核**：PR 四条意见均有对应修复及回归——缺失 deny 根使用强制 bwrap mount（`tests/missing-deny-root.spec.ts`）；broker 授权、记录落盘及启动共用回滚路径（诊断脚本真实注入 `Set-Content` / `Move-Item` / `Start-Service` 三类失败）；shell 入口探测集中在 `src/compat/process-entrypoints.ts`；中英文 README 与 Unreleased changelog 已说明 inherit 默认值及三态。R1–R4 的实现与测试亦复核；补齐 changelog 中仍称 Windows 仅靠对象 ACL 随改名移动的过时表述，并补记负授权与硬链接隔离行为，决定仍由 ADR-0017 / ADR-0020 维护。
- **远端基线证据**：`ba704b7` 的 [CI run 38937909169](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38937909169) 共 44 条平台/版本 verify 车道及最终 gate 全绿；[diag run 38937909410](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/38937909410) 验证真实 broker 生命周期与三类授权后失败回滚。此处是旧提交证据，不替代本次修复的验收。
- **阻塞证据**：Windows `0.1.6-alpha.1` job `117098022247` 在北京时间 01:18:09 已打印 packed battery **132/0/0**，03:15:48 才移交清理；11 条 Windows 版本车道的 Packed smoke 均约 118–119 分钟。锁定文件为子进程加载的安装副本 `koffi.node`，旧 `rmSync(maxRetries: 10, retryDelay: 500)` 在递归祖先层层重试，等待无法在本进程退出前解除的模块映射。
- **修复与回归**：清理所有权和有界重试规则写入[开发工作流](../../development/plugin-development-workflow.md#ci)。新增真实 `.node` 加载的深层目录子进程回归（移交后退出、父进程严格删除、独立清理持久锁必须及时失败），以及普通目录、外部 junction 不跟随、显式移交和 CI 超时门禁回归；不靠扩展名豁免清理，不跳过行为断言。
- **本地执行**：Windows 非提权会话，开发 pin `0.2.1-alpha.2`、Node `24.14.0`；内核探针 windows-acl 可用。完整套件 **50 文件、781 通过 / 49 条件跳过 / 0 失败**，含新增回归；lint、双端 typecheck、build、compat:check 通过。compose **48/0/0**、behavior **133/0/0**、journey **62/0/0**、packed behavior **132/0/0**，pack:check **109 成员完整**；packed 含打包/安装/严格清理耗时 **50.04 秒**，四项冒烟加打包检查共 **101.99 秒**，无残留。docs:check 通过。
- **修复提交远端执行**：`033bbe6` 的 [CI run 39022484207](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39022484207) **44 条 verify 车道及最终 gate 全部 success**（含 releases 共 46 jobs）；11 条 Windows packed smoke 分别为 **31–67 秒**，不再等待模块映射解除。相同提交的 [diag run 39022484171](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39022484171) 同样 success，真实 Windows ACL 与 broker 生命周期通过。当前复核未发现新的合并阻断项；非提权 CI lane 与 Windows partial / 并发外部修改边界仍按既有决定记录，未扩大安全承诺。未合并、未发布。

## DSH 0.2.1 后续兼容提升（2026-10-17）

用户授权范围是 `dsh-v0.2.1-alpha.3` 至 `dsh-v0.2.1-rc.2` 的五个发布版本。上游本地 tag 与 npm `versions` 列表一致，逐 tag 与 `0.2.1-alpha.2` 做源码差分。支持合同保留全部旧版，再纳入这五个精确版本；开发 pin 与 lockfile 升到 `0.2.1-rc.2`，cordis 是 `4.0.5`。插件版本号不变（`0.1.6`），不创建 release tag。

| 上游 tag | commit |
|---|---|
| `dsh-v0.2.1-alpha.3` | `2fbf4359b82fb94c03dcce0b831660d87f12ea5c` |
| `dsh-v0.2.1-alpha.4` | `86a402200d95fecef4529d969836f1fe13c6cb0d` |
| `dsh-v0.2.1-alpha.5` | `1517a4dbca0a2789ff1d41ba439600f8547d23fa` |
| `dsh-v0.2.1-rc.1` | `1600d8a1e140dcde43a1a0941940a0480712c011` |
| `dsh-v0.2.1-rc.2` | `687f282e8625c6b8d11ff58211a90524be2e4317` |

#### 接口变更与风险

| 接缝 | 上游变化与影响 | 本次处理与证据 |
|---|---|---|
| registry storage / zod | `alpha.3` 起 `dsh-storage-domain` 把 `zod` 依赖从 `^4.4.3` 钉死为 `4.4.3`；本插件自身的 `^4.6.2` 解析成另一副本，`domainTable` 声明的 `ZodType` 与插件侧 schema 类型互不兼容（运行时仅调 `.parse`/`.safeParse`，是类型缝而非行为缝） | 新增 `src/compat/storage-zod.ts`：经 `createRequire` 从 `dsh-storage-domain` 自身解析路径取 zod 构建域 schema，值与声明同源，任何支持版本都成立；不 pin 本包 zod、不加 overrides、不做版本串分支。宿主/客户端 typecheck 与全部测试通过 |
| 插件安装门禁 | `alpha.4` 起 plugin-manager 优先读 `engines.dsh`，缺失时回退 `peerDependencies` 的 `@deepseek-ai/dsh*` 条目；本插件仍以 peers 为唯一版本契约 | peers 精确枚举 16 个版本；warn 车道在首个 `plugin add` 前授予精确 `allow-version` 豁免（覆盖 remove/add 激活回退路径），保留反应式回退，enforce 模式不依赖豁免 |
| cordis | `alpha.3`–`alpha.5` 依赖 `~4.0.5-alpha.2`；`rc.1`/`rc.2` 依赖 `~4.0.5`（解析为 `4.0.5`） | `cordis-pin.mjs`/`upgrade-dsh.mjs` 按候选版本分派；peer 声明补 `|| 4.0.5-alpha.2`（`4.0.5` 已在 `>=4.0.1 <5.0.0` 内），开发 pin `4.0.5` |
| fork 客户端文件 | `alpha.2`→`rc.2` 的 `src/client/` 子树逐字节零改动（含 files-tree 与 open-in-app 上游源）；locales 仅新增 market meta 键，与 fork 的 `SidebarFilesKey` 无关 | 按 FORK.md 核对后仅前移 revision 基线至 `687f282e86`，不重新拷贝 |
| Connection RPC / session / workingDirectory / LSP / workspaceFiles | `rpc.call` 签名不变；handler 新增第 4 个可选 `peer` 参数向后兼容；`sessions.list` 快照、`retainedBy.mainView`、working-directory 服务键与 LSP stdio 池形状均未变 | 不新增适配分支；行为/旅程冒烟在真实 profile 上验证 |
| `read` 等工具提示文案 | `dsh-tools` 个别工具 description 微调，事件名与 schema 未变 | 本插件不钉文案快照，无影响 |

#### 候选车道与验收

每个候选版本走完整 upgrade lane（`upgrade-dsh.mjs` repoint + 重装 + `DSH_MULTI_ROOT_COMPAT=warn pnpm verify:all`），cordis pin 按版本分派。本地宿主为 macOS：`pnpm kernel:probe` 实测 Seatbelt 可执行并作为必跑断言（`DSH_PROBE_VERIFIED_DIALECTS=seatbelt`）；bwrap / Landlock 本机不存在，Linux/Windows 原生证据由远端 CI 承担，不得把本地 skip 记为通过。

| 运行时 | 单测 | compose | behavior | journey | packed behavior | 结果 |
|---|---|---|---|---|---|---|
| `0.2.1-alpha.3` | 766 passed / 64 skipped | 48 | 126 | 62 | 125 | 通过 |
| `0.2.1-alpha.4` | 766 passed / 64 skipped | 48 | 126 | 62 | 125 | 通过 |
| `0.2.1-alpha.5` | 766 passed / 64 skipped | 48 | 126 | 62 | 125 | 通过 |
| `0.2.1-rc.1` | 766 passed / 64 skipped | 48 | 126 | 62 | 125 | 通过 |
| `0.2.1-rc.2` | 766 passed / 64 skipped | 48 | 126 | 62 | 125 | 通过 |

候选期间修复两处接缝（见上）：storage-zod 适配消除 zod 双副本类型不兼容；`installPluginProfile` 的 warn 预授权修复「构建审批中断后的 remove/add 激活路径撞上版本门禁」——该路径曾把插件装为依赖但未激活，行为断言以 `setAdditionalRoots` 空指针暴露，现已修复并有 rc.2 完整 packed battery 复验。

#### 正式提升

`SUPPORTED_DSH_RELEASES` 扩至 16 个精确版本；20 个 `@deepseek-ai/dsh-*` peer 同步枚举；cordis peer 补 `4.0.5-alpha.2`；开发 pin `0.2.1-rc.2`、cordis `4.0.5`；release-age 精确豁免重写为 rc.2 集合；probe overrides 与 `minimumReleaseAge: 0` 不落入提交。提升后 enforce 验收（`0.2.1-rc.2` / cordis `4.0.5` 开发树，本机 macOS）：`pnpm compat:check` 四方一致；`pnpm verify:all` 全绿——lint、双端 typecheck、build、`kernel:probe`（Seatbelt 实测可执行，bwrap / Landlock 本机不存在）、test **49 文件 766 passed / 64 skipped**、compose **48/0/0**、behavior **126/0/0**、journey **62/0/0**、pack:check **110 成员**、packed behavior **125/0/0**（enforce 下无豁免，peers 精确覆盖 rc.2 直接通过版本门禁）；`pnpm docs:check` 通过。远端 16 版本 × OS 矩阵由本分支 PR 的 CI 车道执行，未完成前不记为通过。

远端矩阵已完成：PR #13（head `40ff7dd`）的 [CI run 39029762518](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39029762518) **66/66 jobs 全部 success**（16 版本 × 4 OS verify 车道 + releases + gate），随后合入 `main`（`eaf2d8f`）。本批次与第二期 B 系列、Files 页签浏览一并随 `v0.1.7` 发版。

## DSH 0.2.0 `permissionPresets/catalog` 修复（2026-10-18，随 `v0.1.8` 发版）

用户报告：插件在 DSH `0.2.0`（宿主实际组合 `0.2.0-rc.2`）上把权限设置页拖死——`gateway/service-unavailable: permissionPresets/catalog: active Service "permissionPresets" is unavailable`。以 `dsh-app-boot@0.2.0-rc.2` 进程内复现基线（无插件正常）与含插件组合，还原出「检测误报 × 爆炸半径」双因：

1. **误报**：`classifyInstallation()` 对所有 optional 包一视同仁。`link:` 安装下 `dsh-lsp` / `dsh-lsp-stdio` / `dsh-working-directory` 从插件锚点解析到仓库自身 devDependencies（`0.2.1-rc.2`），版本统一的宿主被判 `mixed`。修法：`OPTIONAL_CORE_PACKAGES` 按"谁加载副本、经哪个锚点"拆为三类：`RUNTIME_OPTIONAL_PACKAGES`（插件动态 import，私有副本真会执行）、`HOST_SERVICE_PACKAGES`（只作宿主挂载服务/类型，插件根内命中计为缺席，宿主锚点回退受同一根边界约束）与 `RUNNER_ANCHORED_PACKAGES`（`dsh-sandbox-windows-acl` 由独立 runner 经上游 runner 自引用加载，只从 `dsh-sandbox-local` 锚点取证——Codex 评审 P2 指出，归 host-service 会让未受检 ABI 被判缺席）。
2. **爆炸半径**：上游 `fs-sandbox`/`sandbox` 被 patch 无条件禁用，而替身 provider 又 inject `multiRootCompat`；门禁一倒 `ctx.fs`/`ctx.sandbox` 消失 → `ctx.shell` → `permissionPresets` 全瘫。修法：两个 provider 行不 inject 门禁——放宽由 scope 驱动、被门禁的 registry 不可能在被拒安装上填充 scope，provider 空 scope 即上游等价。宽授权行（providers/registry/instructions/lsp/workspace-files/process-fence）门禁不变，`mixed`/`incomplete` 依旧 fail-closed。

落点：`src/compat/dsh-version.ts`、`src/fs.ts`、`src/sandbox.ts`、`src/compat.ts`、`cordis.patch.yml`、`scripts/check-dsh-compat.mjs`、`src/index.ts`、`tests/compat.spec.ts`；文档：ADR-0009 修订节（2026-10-18）、故障排查条目退化形态更正、`.agent/note/dsh-compat-contract.{md,en.md}` §2/§10、AGENTS.md 不变量 #7。同期观测的 `job/registered` 未知事件报错经查证为 0.2.1 线 harness 写入的 session 日志被 0.2.0 reader 读取，与本插件无关。

## Auto Review 多根上下文适配（2026-10-18）

工作分支 `feat/compat-auto-review` 从 `main` 的 `15c1d26` 创建，保留了调研、计划及导航的未提交修改。上游核对为 `dsh-v0.2.1-rc.2` / `687f282e8625c6b8d11ff58211a90524be2e4317`，没有编辑上游源码、安装包或检出其旧构建产物。实现设计和维护边界见 [ADR-0021](../../decisions/ADR-0021-auto-review-context-companion.md)，阶段范围见[已归档计划](../completed/2026-10-18-auto-review-context-adaptation.md)。本节工作完成时主包版本仍为 `0.1.8`，未创建 tag；独立 companion 从未发布——其交付形态随后被 [ADR-0022](../../decisions/ADR-0022-auto-review-loader-entry.md) 取代，同一能力并入主包内置行随 `v0.1.9` 发版（见下节）。普通支持 allowlist、provider 门禁例外与默认 Auto 行为不变。

### 装配与请求证据

Phase 0 先在隔离 profile 中验证官方 Auto Review / Multi-root 两种顺序：web 和 headless 均启动，fs/sandbox、Registry 和官方 Auto 可用。确认 Loader 的 id patch 只能作用于此前的 insert 后，采用显式 enable 顺序校验，不依赖碰撞或静默 patch 跳过。headless 装配探针禁用 launcher，避免自动发起无关任务；原有 headless journey 仍实跑。

`pnpm smoke:auto-review` 的 source/link 腿运行 web/headless × 两种顺序，共四组；packed 腿把主包和 companion **分别打包并实际安装**，运行 web/headless 两组。每组依次验证：普通安装不发布 Auto 或 context → 官方 owner → 安装 companion、执行安装副本的 enable CLI → 单一兼容 owner → 捕获两次真实 reviewer 请求 → 固定 allow 对可写根写入成功、对只读根拒写且原字节不变 → live disable 迁移存活 Auto 到 Full access 并恢复官方 → live re-enable 仍只有一个 owner且不自动重选 Auto → 重启恢复 → 实际移除 companion 包保留官方选择。总计 **6 组 / 12 次工具调用 / 12 次 reviewer 请求**；两包 packed 结构检查含入口、声明、bin、双语 README、MIT 和 FORK 文档。

### 本机完整门禁

执行环境为 macOS arm64 / Node 24，运行的是本仓库锁定的发布包，不是上游 checkout 的 node_modules。`pnpm compat:check` 四方一致；`DSH_PROBE_VERIFIED_DIALECTS=seatbelt pnpm verify:all`（本机为避免 pnpm 的依赖自检误触发重装，使用 `--config.verifyDepsBeforeRun=false`，不改变门禁内容）退出 0：

| 门禁 | 结果 |
|---|---|
| lint / 双端 typecheck / 主包与独立 companion build | 通过 |
| kernel probe | Seatbelt 可执行；bwrap 不存在；Landlock launcher 不存在 |
| test | **55 文件：54 passed / 1 skipped；828 passed / 64 skipped** |
| 官方 fork 行为回归 | 31 用例通过；覆盖 native/PTC 身份、风险协议、human/parent/constraint/checkpoint/fact、ask/never、下游 gate、取消和卸载 |
| 联合 context / fs / PTC | 17 用例通过；真实主根/cwd、三态注册、nested/首次目标/最终 file symlink、resume、更新/删除/撤销/redirect、authority、预算/故障、有界 stream 关闭、人工批准后复核、嵌套/并发 cap；不读取普通目标正文 |
| native instruction overlap | 6 用例通过；当前 baseline、纯附加帧替换、mixed 帧去重/失败、未登记 cwd 的 native 约束保留 |
| compose / behavior / journey | **48 / 126 / 62** passed，均 0 failed / 0 skipped |
| pack:check / packed behavior | **115 成员 / 125** passed，packed behavior 0 failed / 0 skipped |
| auto-review:fork / smoke:auto-review | 基线与允许差异通过；上述 source 与 packed 六组通过 |
| docs:check / git diff --check | 通过 |

Seatbelt 证明的断言强制实跑。PTC 联合用例用真实 Node runtime 与 SDK bridge：外层 run_code 不审查，内层 write 每次恰好一次；继承外层 run_code 的 cap；子进程直接 `node:fs` 覆写只读文件也被内核拒绝，原内容不变。人工批准同样不能解除 fs 围栏。成功路径与失败路径的 main Agent delivery bookkeeping 分离，审查发现没有伪造成功 touch。

### 旧版普通插件回归

使用仓库内隔离副本，经既有 upgrade 工具逐版本安装，不切换或回退主工作区。probe 已排除不匹配联合合同的独立 companion 项目，避免全局 overrides 误重指该 fork 的开发依赖；没有放宽普通插件 allowlist。每个已支持旧版运行 `compat:check`、双端 typecheck、build，以及 scope、instructions、tool-access、compat、optional peers、working-directory、durable activity 和 preview 差分八组回归。最终结果在下表记录。

| 运行时（现有 allowlist 中的精确条目） | 共享回归 | 类型 / 构建 / compat |
|---|---|---|
| `0.1.5-rc.2` 至 `0.2.1-alpha.1` 的 10 项 | 每项 131 passed / 7 skipped | 通过 |
| `0.2.1-alpha.2` 至 `0.2.1-rc.1` 的 5 项 | 每项 137 passed / 1 skipped | 通过 |

其中旧宿主缺失 workingDirectory/worktree 的用例按能力明确跳过，剩余 skip 属现有平台/能力条件；不记为原生通过。`0.2.0-rc.2` 还实跑原有完整普通插件路径：compose **48**、behavior **126**、journey **62**、packed behavior **125** 全过，pack:check 通过，确认可选新入口没有重现 `permissionPresets/catalog` 故障。旧版未启用、也不宣称联合 Auto Review 兼容。

### 未覆盖与维护边界

本批没有在 Linux bwrap/Landlock 或 Windows ACL/broker/pwsh/ConPTY 主机上原生执行；相关原有测试按本机平台跳过，已把新增联合 gate 接入现有 OS 矩阵，但没有把尚未运行的远端 CI 写成通过。真实模型语义质量未认证：脚本化 allow 只证明请求来源与内容、单一 owner及执行围栏独立，不能证明误拒绝/误放行率。Phase 3 普通目标源码自动读取未实施。

当前 mixed native 帧若含已失效附加指令，公开接口无法无损拆出其中的 global/primary 正文，本次 review 明确失败；需要重建 producer baseline，必要时用新 Session。指令/根/authority 在等待期间变化同样失败，不沿用旧 allow。已经启动的进程保留旧 kernel snapshot，多次复核不声称消除任意敌对文件系统 TOCTOU。fork 只维护精确基线；正式上下文 API 足够后删除 fork 的迁移合同见 ADR-0021 与 FORK.md。

### 远端 CI 首轮失败与修复

分支首 head `40ec946` 的 [CI run 39130958098](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39130958098)：releases 及全部 Linux/macOS verify 成功，**16 个 Windows verify job 全部失败**，gate 随之失败。三类失败均由本批 Windows 首跑暴露：

| 失败面 | 原因 | 修复 |
|---|---|---|
| `0.1.5-rc.2` 至 `0.2.1-alpha.1` 共 10 个 lane 的 install：`@deepseek-ai/dsh-working-directory@<旧版>` 不存在（该包自 `0.2.1-alpha.2` 才发布） | Windows 检出为 CRLF，`upgrade-dsh.mjs` 按字面 `\n` 删不掉 `packages:` 中的 `compat/auto-review` 行，companion 仍留在 workspace（日志 `Scope: all 2 workspace projects`），probe overrides 将其 devDependency 一并重指到不存在的旧版 | `.gitattributes` 增加 `* text=auto eol=lf` 统一 LF 检出；脚本的两处 `packages:` 行编辑同时容忍 `\r?\n` 作防御纵深 |
| `0.2.1-alpha.2` 至 `0.2.1-rc.1` 共 5 个 lane 的 `auto-review:fork`：`upstream baseline drift` | 同一 CRLF 检出；`check-auto-review-fork.mjs` 对 `upstream.ts` 原始字节计算 sha256 | 同上 `.gitattributes`；这些 lane 顺带验证了 companion 在场但被排除时普通插件门禁全绿 |
| `0.2.1-rc.2` lane 单测：`reviews real PTC inner fs calls …` 的 worker `Cannot find module` | 联合用例经 `src/sandbox.ts` 挂载 provider，`import.meta.url` 落在 `src/`，widen/restrict 产出的 `src/windows-runner.js` 不存在——与 2026-10-03 Windows 修复记录（PR #7）是同一陷阱 | win32 下该用例改从 `lib/sandbox.js` 挂载 provider，沿用 `tests/windows-multi-root.spec.ts` 的既定选择 |

非 joint 版本本就没有上游 Auto Review：companion 由 upgrade 脚本从 `packages:` 摘除（joint 仅 `0.2.1-rc.2`），`vitest.config.ts`、`build-auto-review.mjs`、`smoke-auto-review.mjs` 也只在精确 pin 下启用；本次修复恢复的是这条既定语义——旧版上该功能视为不存在，不安装、不构建、不验证。远端复验以下一次 CI run 为准，在此之前不把 Windows lane 记为通过。

`87fd7aa` 的 [CI run 39136285430](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39136285430)：三类修复全部生效——`0.1.5-rc.2` 等老版本 Windows install、fork 基线哈希、`0.2.1-rc.2` 联合单测均通过；但同一 lane 的 joint 冒烟暴露第四类失败：companion 启用后 `lib/index.js` 仍引用 `./compat/contract.ts`（`ERR_MODULE_NOT_FOUND …\lib\compat\contract.ts`）。原因是 `build-auto-review.mjs` 的 `neverBundle` 用「不以 `.`/`/` 开头」判定外部依赖，而 rolldown 会用**解析后绝对路径**再次调该谓词——macOS/Linux 的 `/Volumes/…` 以 `/` 开头被正确内联，Windows 的 `D:\…`/`D:/…` 被误判为外部依赖并原样保留 `.ts` specifier。修复改为与 `tsdown.config.ts` 相同的契约：按 companion manifest（dependencies + peerDependencies）枚举外部包名，任何解析形态都不会误伤自有源码；并在构建后断言 `lib/index.js` 不再残留相对导入（单文件产物的既定契约），把这类缺陷挡在本地而非依赖远端冒烟。

`ef6a26c` 的 [CI run 39137744875](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39137744875)：bundle 修复生效，companion 在 Windows 成功导入激活（不再出现 `did not activate`）；冒烟推进到 reviewer 请求断言后暴露第五类失败——`auto-review-battery.mjs` 用 `text.includes(primary)` 匹配 reviewer 文本中的根路径，但该文本经 `JSON.stringify` 渲染，Windows 路径 `D:\…` 被转义为 `D:\\…`（canonical 根另有 `\\?\` 前缀），POSIX 的 `/` 无转义问题故仅 Windows 失败。断言改为按 JSON 转义拼写匹配（去引号后仍为 `\\?\` canonical 形式的子串），产品代码不动。

`15637f8` 的 [CI run 39138769855](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39138769855)：路径断言修复生效，四种组合的完整 battery（装/启/审/停/卸）在 Windows 全部通过；冒烟推进到收尾清理时暴露第六类失败——packed 子进程从安装副本 `dlopen` `koffi.node`（`profiles/<name>/node_modules/@koromix/…/koffi.node`），进程内映射期间 `rmSync` unlink 报 `EPERM`——与 2026-10-17 记录的 smoke-behavior 缺陷同源，只是当时 joint 冒烟在更早的断言处已挂、从未走到清理。修复沿用既定契约：`smoke-auto-review.mjs` 收到 `DSH_SMOKE_DEFER_HOME_CLEANUP` 时把 home 清理移交父进程，`verify-auto-review.mjs` 为每个子进程注入 `DSH_SMOKE_HOME` 并在子进程关闭后以 `removeScratchTree`（有界重试）删除根目录；独立运行保持严格清理语义不变。

`df79b35` 的 [CI run 39139931861](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39139931861)：**66/66 jobs 全部 success**——releases、16 版本 × 4 OS 共 64 条 verify 车道及最终 gate。四轮 Windows 修复（CRLF 检出与行编辑、fork 基线哈希、源码侧 runner 路径、neverBundle 解析后谓词、reviewer 文本 JSON 转义、映射 addon 清理移交）在远端全部复验通过，joint 冒烟在 Windows 上完成 packed/unpacked 双形态全流程。

## Auto Review 内置入口迁移（2026-10-20）

用户授权将独立 companion 合并进主包。需求评审见[评审记录](../completed/2026-10-20-auto-review-in-package-review.md)，交付及生命周期方案见 [ADR-0022](../../decisions/ADR-0022-auto-review-loader-entry.md)。已实施并经 PR #16 合入 `main`（`9138084`，随后 README 收尾 `0851a28`/`e4804fb`），随 `v0.1.9` 发版。

已移入 `src/auto-review/`，增加主包 `./auto-review` 导出和默认 disabled 的 `multi-root-auto-review` 行；context/reviewer 共用一个开关。configure、独立 manifest/workspace、第二 tarball 与版本协调退役。精确 fork 仍仅支持 `0.2.1-rc.2`，普通 allowlist 未变。

最小真实 loader 验证已通过两种顺序、延迟 import、反复 reload、官方原有 disabled、官方后加入/移除与描述符恢复。真实 profile 联合回归（source 与 packed 双车道、web/headless × 官方前后序、默认零挂载、live 接管/恢复/再启用、真实 reviewer 请求）已通过；typecheck 双通道、全量 vitest、lint、docs:check、pack:check、compat/fork 门禁全绿。官方 bundle 未选择时入口独立运行（自身注册 Auto preset），已在 README/ADR-0022 写明。`verify:all` 全项在本机通过（含 kernel:probe、compose/behavior/journey/packed 与 auto-review 双车道 smoke）。合入后 `main` 的多 OS CI 已复验：`9138084` 的 [CI run 39399743823](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39399743823) 全绿（含各支持版本的 Windows/Linux/macOS 车道）。随 `v0.1.9` 发版。


## Multi-root Skills 架构验证（2026-10-23）

用户授权在 `feat/additional-root-skills` 上完成 Proposed ADR 的剩余工程验证，再定案并拆分计划。问题源为 Issue #17；[ADR-0023](../../decisions/ADR-0023-multi-root-skill-discovery-and-invocation.md) 已据此升级为 **Accepted（架构定案）**。源码事实归[接缝调研](../../reference/multi-root-skills-seams.md)，S1–S7 任务和退出条件归[实施计划](../completed/2026-10-23-multi-root-skills.md)。**生产实现与本批全平台 CI 验证已完成，随 `v0.1.10` 发版；S7 含发布准备全部完成，A1–A13 的生产证据与能力边界见下文。**

### 2026-10-24 交互修订

按用户反馈及 ADR-0023 的同日修订，命名空间引用改为普通文字，移除独立按钮样式和聊天点击预览入口；补全与 Host 调用保留。开发 pin 本地 `pnpm lint`、`pnpm typecheck`、`pnpm docs:check` 通过，`pnpm test -- tests/client-skills.spec.tsx` 实际执行全套：891 通过、90 跳过。DOM 回归覆盖 interactive 两态均输出文字节点，点击不打开弹窗、不调用预览 RPC；该结果不替代真实宿主浏览器目检。

### 2026-10-24 PR #18 并发投递修复

[P2 评论](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/18#discussion_r4367566103)指出：同一条用户消息调用多个 Skill 时，前一个正文通过准入后进入待投递数组，等待后一个加载期间即使被撤销，返回时仍会投递。现按 ADR-0023 的并发补充保留全批加载凭据，所有异步操作结束后统一重验，最后同步检查 generation，再更新投递跟踪并返回；任一失效即丢弃本批新正文。

新增 9 项回归：7 类后续加载期间的失效（Root 关闭、移除、文件内容、用户调用策略、aliasId、全局关闭、authority）和最终准入期间 generation 改变共 8 项在修复前失败、修复后通过；另有未变化批次保持顺序、重复引用只注入一次的正对照。调用测试共 18/18 通过。

本地为 macOS、开发 pin `0.2.1-rc.2`，未重指安装树或扩大支持集合。重新构建后移除预览导致的 `react-dom/client` 产物断言也已同步。`compat:check`、lint、双端 typecheck、build、`docs:check` 通过；外层沙箱禁止 Seatbelt 嵌套，改在可执行的环境运行探针并确认 Seatbelt 后，携带 `DSH_PROBE_VERIFIED_DIALECTS=seatbelt` 执行全套：**911 通过、79 平台相关跳过**。compose / behavior / journey 为 **52 / 126 / 76 通过，零失败、零跳过**；`pack:check` 完整，`smoke:packed` 的 behavior 为 **125 通过、零失败、零跳过**。`auto-review:fork` 与 `smoke:auto-review` 亦通过（source/link、packed，web/headless 与两种 bundle 顺序）。这不是重新执行全部版本或跨平台矩阵的证据。

### 执行范围与结果

上游只读检出为 `dsh-v0.2.1-rc.2` / `687f282e8625c6b8d11ff58211a90524be2e4317`，未修改上游文件或切换其版本。本地运行时从本插件的 DSH 安装锚点解析，版本 `0.2.1-rc.2`；没有重指主 manifest/lockfile 或扩大支持集合。

可复现命令：

```sh
node --experimental-transform-types scripts/probe-multi-root-skills.mjs --upstream <upstream-checkout>
```

macOS / Node `24.18.0`：**13 组检查通过**。其中一组对 `SUPPORTED_DSH_RELEASES` 当前全部 **16 个 tag** 进行源码契约审查并输出 source 摘要与能力标志；其余为当前 pin 的发布模块和 UI 纯核原型，不等于 16 个独立运行时或完整 OS 矩阵。

| 原型证据 | 结果 |
| --- | --- |
| 真实 Registry、首步 pre-step、原生 skill 定义 | 首步有目录而无完整正文；两 Origin 共用 effective cwd 并发加载隔离；带父 scope 的子 Agent 按自身 Origin 选择根；缺失 scope 不贡献 |
| 真实 SessionSkillCatalog 与 invocation | 内部候选退出原生人类目录；user-only 可经 Alias 加载而模型拒绝；model-only 不进入 Alias；原生冒号参数被拒绝 |
| Alias pre-step | 保留用户原文，正文追加在 native Catalog 后；只解析本批用户消息；外部来源不能伪造手势 |
| 失效与原生替换 Catalog | 全局关闭后空目录、新加载拒绝；有历史 Catalog 时产生空替换；恢复后重新发现 |
| 延迟读取竞态 | get 已读文件、返回前关闭 Root 并失效，最终不返回正文 |
| 动态可用性 | 元数据调用策略变化、Alias 更名、authority 丢失、Root missing 与 symlink redirect 均按当前状态判定 |
| 受限原生文件解析 | 根外 Skill symlink 在内容读取前拒绝；未把原生 provider 当成自带 confinement |
| native Effective CWD 负对照 | 未包装原生 snapshot 在附加根 cwd 暴露裸名；公开 snapshot/get 包装后不再暴露；主根 Skill 保留；live/cold Remote 与 cwd symlink 覆盖 |
| 迁移与降级 | 分配幂等、反转输入顺序身份稳定、重复别名和空名处理；同值权限不重置；真实旧 Registry schema 剥离新字段，证实降级写回可能丢失手动选择 |
| 真实 Loader/Settings 多行 profile | 表单只对 multi-root-skills 行暴露；启用/关闭可持久化并实时读取；modern volatile 修改不重挂 Skills fiber，不写 Registry 行 |
| UI 纯核与卸载 | 冒号 trigger 保留、草稿不高亮限制复现、自定义已发送 matcher 可用；Registry 方法原始实例属性描述符可恢复 |

### 验证后收敛的边界

发现两项必须加入实现的约束：只注册 Provider 不能防 native effective-cwd 再发现；不能承诺 domain v1 的未知 metadata 经旧版写回仍保留。旧宿主的设置和已发送 UI 也须按实际能力分支：legacy installSection 与 modern volatile Config 分开；UserTextRule 只在 `0.2.1-alpha.3` 及之后的本次审查集合出现。

架构原型结束时尚未执行：旧版隔离安装树上的动态验证、真实 Connection 传输、完整浏览器 DOM/交互、真实 agent-loop/LLM journey、新字段在生产 Registry lease/迁移队列中的集成、观察调度器资源测试，以及 Linux/Windows 原生路径与句柄测试。该阶段没有源码产品改动，未将全套 kernel/smoke/packed 门禁记为执行通过；后续生产验证见下文。文件句柄与前后检查也不声称可抵御任意祖先 rename 的原子事务。

### 后续进度

2026-10-23 开始连续实施，按阶段保存可分批应用的 checkpoint；不创建发布版本或 tag。

| 阶段 | 状态与证据 |
| --- | --- |
| S1 | 装配完成。新增独立 Skills entry / patch 行、可选 peer 分类、scope 身份与 Config 接缝。正式 `skills-compat.spec.ts` 随既有版本矩阵运行；本机 rc.2 的 4 个相关测试文件共 53 passed / 1 既有 skip，host typecheck、build、定向 lint、compat:check 通过。其余版本动态执行留在 S7，不扩大本机证据。 |
| S2 | 完成 metadata / 迁移、两项 mutation、命令与 Dialog。rc.2 真实 JSON Registry、lease、命令、wire、DOM 与 locale 共 7 文件 187 passed / 1 既有 skip；新增覆盖迁移写失败、重复加载、损坏字段、并发命名空间、takeover、降级写回与 revive。新 metadata 不改变 grant 三键或 writableRoots；refresh 无写。 |
| S3 | Provider / 受限原生解析 / live 与 cold Origin 路由已实现。rc.2 原生 pre-step 与公开 Remote 的回归验证两 Origin 共用 cwd、两目录发现、symlink 拒绝、冷 Session、裸名负对照、零根参数保持、reload 和描述符恢复。完整 Loader web/headless journey 与旧版动态运行仍在 S7 验收，不把本层测试称为完整组合验收。 |
| S4 | 按需模型 get、Host Alias pre-step、读取前后文件签名和 generation fence、独立撤销提示已实现。rc.2 的 8 个正式回归经真实 tools.execute / pre-step 覆盖默认/user-only/model-only、伪造 source、旧 Alias/内部 ID、读取中禁用/移除/策略变化/取消、其他 Provider incomplete、原生 exact-ID winner；通过。 |
| S5 | 共享 128 根 LRU 委托池与 2 秒单调度器、generation、冷 Session list/preview/changes RPC、Client epoch/取消围栏、ordered teardown 已实现。rc.2 8 个相关文件 86 passed（含真实 Connection localhost HTTP、实际文件增改删/Root missing、容量/去重/淘汰、排队取消、延迟 get 卸载排空、旧包丢弃）；typecheck 与定向 lint 通过。 |
| S6 | Slash Source、完整文本插入、conditional UserTextRule/Renderer、安全预览、双形状 Settings 卡片及 Host 动态配置已实现。rc.2 Loader/Settings 真实多行 profile 验证只改 Skills 行、volatile 不重挂；legacy installSection 到达/移除回归通过。DOM 覆盖 namespace 补全、原文插入、sent 引用预览 RPC、表单映射与 accessible checkbox。旧宿主动态验收及真实浏览器整页检查在 S7 继续。 |
| S7 | macOS 本机集成、Windows 与 Linux（WSL2）各 16 精确版本本机完整门禁完成；PR #18 的远端 16 版本 × 4 runner 矩阵及最终 gate 全绿，补齐 Windows 第二固定卷与 foreign-owner 两项能力缺口。发布准备完成，随 `v0.1.10` 发版，计划归档 completed；执行证据与能力边界见下文。 |

C0 保存既有架构文档与原型；C1 保存 S1，C2 保存 S2，C3 保存 S3 的实现与本层测试，C4 保存 S4，C5 保存 S5，C6 保存 S6 的实现与本层测试。checkpoint 为本机临时快照仓库中的增量 patch；上述阶段结束时正式仓库尚未提交，后续阶段继续基于同一工作树。本批提交状态见下文。


### 生产实现本机验收（2026-10-23）

主工作树保持 `0.2.1-rc.2` 开发 pin、原 16 项精确支持集合及 enforce 门禁。macOS / Node `24.18.0`，未修改上游；S1–S6 生产实现及本机整体验证完成，S7 保留必要平台门禁与发布准备。

| 本机门禁 | 结果 |
| --- | --- |
| compat:check、lint、typecheck、build | 通过；支持集合、peer 与安装树一致 |
| test | **891 passed / 65 skipped**，63 文件通过、1 文件平台跳过；skip 不计为原生通过 |
| kernel:probe | Seatbelt 实跑成功；本机无 bwrap/Landlock |
| smoke:compose / smoke:behavior / smoke:journey | **52 / 126 / 76 passed**，均 0 failed / 0 skipped |
| pack:check / smoke:packed | 通过；tarball behavior **125 passed / 0 failed / 0 skipped** |
| auto-review:fork / smoke:auto-review | 通过；source/link 与 tarball，web/headless × 两种官方 bundle 顺序，真实 reviewer 和写围栏回归通过 |
| 架构原型 | 更新为冻结旧记录 schema 后重新运行，仍 **13 组通过** |

journey 使用真实 Loader、preset、Agent loop、原生 skill 工具和本地脚本化 LLM 服务；web/headless 的首请求只有目录，模型调用后收到正文，第二轮用户 `/repo-b:journey-user` 保留原文并按 user-only 策略加载。web 动态关闭/恢复 Config 后旧内部 ID 拒绝，主根 Skill 与各 Root 手动选择保留；关闭 Root 后进入附加目录不能通过 native 裸名发现。测试环境须允许原生 watcher 和 Seatbelt：外层执行沙箱曾使上游文件 Provider 报 incomplete，原生工具因此正确拒绝整个 Catalog，不能用绕过 incomplete 来取得绿灯。

浏览器在隔离 home/仓库的真实 Web 页面完成：插件详情页只有一份全局 Skills 卡片、关闭/恢复；Root checkbox 关闭后候选消失、恢复后出现；`/repo-b:` 候选无内部 ID，选择插入完整 `/repo-b:review `；已发送引用显示并可打开受 Session RPC 重验的正文预览。浏览器的模型地址刻意指向不可用的本地端口，发送后的 transport failure 不作为模型调用成功证据；模型调用成功证据归上述 journey。草稿保持无原生高亮。末轮修正了普通会话 activity/title 更新误关闭预览的问题：Skills 现在只在当前 Session ID 实际变化时重置；现有根面板保持原订阅语义。

A1/A2/A10 由真实 Registry/lease/JSON 重启与命令/DOM 测试覆盖；A3–A8 由 native snapshot/get、真实 tools.execute/pre-step、Connection 及 journey 覆盖，另有子 Agent 自身 Origin、cwd symlink 与 reload 的正式回归；A9 由文件变化、受限读取、128 根池配额/去重/LRU、排队取消与卸载排空覆盖；A11/A12 由真实 Loader/Settings、DOM 和浏览器覆盖。A13 的跨版本动态接缝见下节；该轮尚缺的 Windows、Linux 原生证据已在下文补验，全平台退出条件仍未关闭，不能称 A1–A13 最终全部完成。

本机成本样本来自 `node --experimental-transform-types scripts/measure-multi-root-skills.mjs`：16 根 × 8 Skills，正文每项约 6 KiB；首次 metadata list **586.89 ms**，5 次重复 list **459.61–623.83 ms**，受检 preview **406.15–568.29 ms**。目录断言不含正文。这是同时执行其他回归时的本机 IO 样本，不是 UI 网络延迟、吞吐保证或跨平台性能认证；当前每次请求重验有可见扫描成本。

### 已支持版本的隔离动态验证

从 `SUPPORTED_DSH_RELEASES` 读取全部 **16 个版本**，在临时源码副本中依次通过既有 `upgrade-dsh.mjs` 重指，每项执行独立 install、`compat:check`、`typecheck`、`build` 和 10 个 Skills/Client/可选 peer/patch 定向测试文件。**16/16 通过**；每项 **58 passed / 1 skipped**。该 skip 为 legacy namespace Settings 与现代 ConfigEditor 两种互斥能力中的另一分支，实际对应形状均有运行，不是跳过整个 Settings 功能。临时树安装使用 `CI=true`，负对照 fixture 显式置于自动 temp grant 之外；主树 pin、lockfile 和安装树未参与重指。

这是 macOS 上的跨版本动态接缝验证，不能替代每个版本的完整普通插件/联合 smoke 或其他 OS 原生验证。完整本机门禁仅对主开发 pin 执行。后续补充的真实 Connection 延迟包回归，以及两种 Session store 形状下只在选择变化时关闭预览的回归，均在主 pin 通过；不将未重跑的旧版新增断言计入上面的 58 项。

### Windows 原生验证（2026-10-23）

Windows 11 `10.0.26200` / NTFS，Node `24.14.0`、pnpm `11.25.0`，非提权 UAC 令牌；已有 deny broker 正在运行，PATH 首位为非 MSIX 的 PowerShell。基于 `4faa6f1` 增加 Windows 专项回归，没有修改产品源码、支持集合或主树开发 pin。验证在外层 Agent 执行沙箱之外进行；`kernel:probe` 确认真实 `windows-acl` runner 可写工作区、拒写相邻目录，后续测试与冒烟均携带 `DSH_PROBE_VERIFIED_DIALECTS=windows-acl`。

| 开发 pin `0.2.1-rc.2` 门禁 | 结果 |
| --- | --- |
| compat:check、lint、typecheck、build | 通过；主树 manifest、lockfile 与精确支持集合保持原样 |
| test | **912 passed / 51 skipped**，65 文件通过；包含新增 7 项 Windows Skills 回归 |
| kernel:probe | `windows-acl` 实跑成功；Seatbelt/bwrap/Landlock 不在 Windows 上声明原生通过 |
| smoke:compose / smoke:behavior / smoke:journey | **52 / 133 / 76 passed**，均 0 failed / 0 skipped |
| pack:check / smoke:packed | **144 个成员**完整；安装 tarball 后 behavior **132 passed / 0 failed / 0 skipped** |
| auto-review:fork / smoke:auto-review | 通过；source/link 与 tarball、web/headless × 官方 bundle 两种顺序、真实 reviewer 写围栏与 owner drain 均执行 |

新增 `tests/skills-windows.e2e.ts` 在真实 Windows 文件系统上验证：大小写不同的 effective cwd 仍受 Root 开关约束（live/cold 两入口）；登记目录替换为根外 junction 后，旧内部 ID 与预览失效；Skill 目录 junction 改目标触发观察失效且根外正文不可发现；已打开的真实文件句柄读取中发生文件替换、删除、撤销或取消时，旧正文不返回且句柄关闭。读取竞态通过暂停 `FileHandle.readFile()` 的返回制造，保留真实 open/read/stat/close 与原生解析，不以 stub Provider 结果替代句柄证据。现有 Windows ACL/broker/pwsh/ConPTY 回归随全量测试和冒烟执行。

本机只有一个可写固定卷，当前非提权令牌不能把夹具属主设为 SYSTEM；既有“第二固定磁盘授权”和“非调用方属主拒绝”两例按原有本地能力规则跳过，不能记为通过，须由具备条件的 Windows CI/提权环境补验。首次误将本地测试设为 `CI=true` 时，这两个 CI 前提被强制检查并失败（905 passed / 49 skipped / 2 failed），不作为成功证据；后续保留原生方言强制断言、按本地能力重跑得到上表结果，没有修改或放宽测试门禁。其余 skip 为现有平台/宿主能力分支，不计作相应原生能力通过。

Windows 成本样本仍用 `measure-multi-root-skills.mjs` 的 16 根 × 8 Skills 夹具：首次 metadata list **1709.69 ms**，5 次重复 list **932.26–2308.76 ms**，受检 preview **962.29–1511.74 ms**；目录不含正文。采样时另有验证任务运行，不作为跨平台性能阈值。

#### Windows 精确版本完整本机矩阵

从 `SUPPORTED_DSH_RELEASES` 读取全部 **16 个精确版本，16/16 完成本机完整门禁**。开发 pin 使用上述主树结果，其余 15 个版本在独立源码副本中用 `upgrade-dsh.mjs` 重指、单独 install；副本既不位于其他安装树之下，也不在自动 temp grant 内，负对照夹具仍在非临时授权区域。主树不参与重指。安装使用 `CI=true`；本地测试保留上文两项能力限制，两个隔离车道各用 `pnpm test --maxWorkers=2` 限制并发。

每版逐项执行 compat:check、lint、typecheck、build、kernel:probe、test、三项 smoke、pack:check、smoke:packed、auto-review:fork、smoke:auto-review 和 docs:check，全部命令退出 0。每版均核实 `windows-acl: ok` 并强制该方言的原生断言；全程 enforce，没有使用 `DSH_MULTI_ROOT_COMPAT=warn`。`auto-review:fork` 在所有版本执行；Auto Review 联合 smoke 仅在其合同指定的 `0.2.1-rc.2` 执行并通过，其余 15 版明确报告可选集成跳过，不计为联合集成通过。

下表 smoke 列为通过数，**全部 0 failed / 0 skipped**；test 的平台/宿主能力跳过单独列出，不计作原生通过。新增 7 项 Windows Skills 用例进入每个版本的完整套件。

| DSH 精确版本 | test 通过 / 跳过 | compose | behavior | journey | packed behavior |
| --- | --- | --- | --- | --- | --- |
| `0.1.5-rc.2` | 836 / 57 | 52 | 125 | 76 | 124 |
| `0.1.6-alpha.1` | 836 / 57 | 52 | 133 | 76 | 132 |
| `0.1.6-alpha.2` | 836 / 57 | 52 | 133 | 76 | 132 |
| `0.1.7-alpha.1` | 838 / 55 | 52 | 133 | 76 | 132 |
| `0.1.7-alpha.2` | 838 / 55 | 52 | 133 | 76 | 132 |
| `0.1.7-rc.1` | 838 / 55 | 52 | 133 | 76 | 132 |
| `0.1.7-rc.2` | 838 / 55 | 52 | 133 | 76 | 132 |
| `0.2.0-rc.1` | 838 / 55 | 52 | 133 | 76 | 132 |
| `0.2.0-rc.2` | 838 / 55 | 52 | 133 | 76 | 132 |
| `0.2.1-alpha.1` | 838 / 55 | 52 | 133 | 76 | 132 |
| `0.2.1-alpha.2` | 843 / 50 | 52 | 133 | 76 | 132 |
| `0.2.1-alpha.3` | 843 / 50 | 52 | 133 | 76 | 132 |
| `0.2.1-alpha.4` | 843 / 50 | 52 | 133 | 76 | 132 |
| `0.2.1-alpha.5` | 843 / 50 | 52 | 133 | 76 | 132 |
| `0.2.1-rc.1` | 843 / 50 | 52 | 133 | 76 | 132 |
| `0.2.1-rc.2` | 912 / 51 | 52 | 133 | 76 | 132 |

逐命令日志、源码快照校验和与机器可读汇总保存在被忽略的 `.dsh-smoke/s7-windows-20261023/`；上述执行结论以本节为持久真源。完整 Windows 本机矩阵不替代下述剩余平台和 CI 验收，也不补记第二磁盘/foreign-owner 两例为通过。

### Linux 原生验证（2026-10-23，WSL2）

Ubuntu `24.04.4 LTS` / WSL2，内核 `6.6.87.2-microsoft-standard-WSL2`、x86_64，夹具位于 Linux ext4（非 Windows 挂载盘）；Node `24.13.0`、pnpm `11.25.0`。基于 `72d27d3` 增加 Linux 专项回归并修正 symlink 夹具，没有修改产品源码、上游包、支持集合或主树开发 pin。验证在外层 Agent 执行沙箱之外进行；每版 `kernel:probe` 均确认 **bwrap 与 Landlock 实跑成功**，后续测试与冒烟均携带 `DSH_PROBE_VERIFIED_DIALECTS=bwrap,landlock`，这两个方言的原生断言不能因 runner 不可用而跳过。

| 开发 pin `0.2.1-rc.2` 门禁 | 结果 |
| --- | --- |
| compat:check、lint、typecheck、build | 通过；主树 manifest、lockfile 与精确支持集合保持原样 |
| test | **901 passed / 69 skipped**，64 文件通过、2 文件平台跳过；包含新增 7 项 Linux Skills 回归 |
| kernel:probe | bwrap、Landlock 实跑成功；Seatbelt / Windows ACL 不计为 Linux 原生通过 |
| smoke:compose / smoke:behavior / smoke:journey | **52 / 126 / 76 passed**，均 0 failed / 0 skipped |
| pack:check / smoke:packed | **142 个成员**完整；安装 tarball 后 behavior **125 passed / 0 failed / 0 skipped** |
| auto-review:fork / smoke:auto-review | 通过；source/link 与 tarball、web/headless × 官方 bundle 两种顺序、真实 reviewer 写围栏与 owner drain 均执行 |

新增 `tests/skills-linux.e2e.ts` 在真实 Linux 文件系统上验证：大小写不同的两根不合并，关闭其中一根不会停用另一根，live/cold 查询均不能走 native 裸名旁路；登记目录替换为根外 symlink 后，旧内部 ID 与预览失效；Skill 目录 symlink 换目标触发观察失效且根外正文不可发现；已打开的真实文件句柄读取中发生文件替换、删除、撤销或取消时，旧正文不返回且句柄关闭。读取竞态只暂停 `FileHandle.readFile()` 的返回，仍执行真实 open/read/stat/close 与原生解析。既有原生沙箱、读写权限、进程围栏、Registry authority、Connection、DOM 和 agent-loop 回归随全量测试与冒烟执行。

本轮两类首跑失败均保留日志并在处理后重跑：

- 两项既有 Registry 测试使用 `rmSync()` 删除指向目录的 symlink，本机返回 `Path is a directory`，导致恢复目录前失败。改用 `unlinkSync()`，behavior battery 同一夹具操作同步修正；原有拒授/恢复断言保持不变。修正后所有版本的完整测试、source 与 packed behavior 均通过。新增 Linux symlink 用例也使用 `unlinkSync()`。
- 系统 Git `2.43.0` 不认识 `0.2.1-alpha.2` 原生 Worktree 使用的 `--no-lazy-fetch`，该版两个既有 Worktree 用例失败。由 kernel.org 的 Git `2.48.1` 与 zlib.net 的 zlib `1.3.1` 源码在忽略的验证目录内构建独立 Git，通过既有 `DSH_TEST_GIT_COMMAND` 指向它，重跑该版全部门禁通过；不删除安全参数、不修改上游、不增加 skip。其余 15 版使用系统 Git 完成完整门禁。

Linux 成本样本仍用 `measure-multi-root-skills.mjs` 的 16 根 × 8 Skills 夹具：首次 metadata list **356.25 ms**，5 次重复 list **237.01–269.07 ms**，受检 preview **233.66–264.99 ms**；目录不含正文。采样时另有版本车道运行，不作为 UI 网络延迟、性能阈值或跨平台性能认证。文件句柄与前后检查仍不声称提供对任意祖先 rename 的原子事务。

#### Linux 精确版本完整本机矩阵

从 `SUPPORTED_DSH_RELEASES` 读取全部 **16 个精确版本，16/16 完成本机完整门禁**。所有版本使用独立源码副本，副本既不嵌套在其他安装树内，也不在自动 temp grant 内；通过现有 `upgrade-dsh.mjs` 重指、单独 install。最多 **3 个版本车道并行**，每车道 `pnpm test --maxWorkers=2`；安装与测试使用 `CI=true`。全程 enforce，没有使用 `DSH_MULTI_ROOT_COMPAT=warn`。

每版逐项执行 compat:check、lint、typecheck、build、kernel:probe、test、三项 smoke、pack:check、smoke:packed、auto-review:fork、smoke:auto-review 和 docs:check，最终全部命令退出 0。每版均强制 bwrap / Landlock 原生断言，新增 7 项 Linux Skills 用例进入每版完整套件。Auto Review 联合 smoke 按既有合同仅在 `0.2.1-rc.2` 实跑，其余 15 版明确报告可选集成跳过，不计为联合集成通过。

下表 smoke 列为通过数，**全部 0 failed / 0 skipped**；test 的其他 OS、旧宿主缺席能力及互斥 Settings 等分支跳过单独列出，不计为相应原生能力通过。

| DSH 精确版本 | test 通过 / 跳过 | compose | behavior | journey | packed behavior |
| --- | --- | --- | --- | --- | --- |
| `0.1.5-rc.2` | 822 / 78 | 52 | 118 | 76 | 117 |
| `0.1.6-alpha.1` | 822 / 78 | 52 | 126 | 76 | 125 |
| `0.1.6-alpha.2` | 822 / 78 | 52 | 126 | 76 | 125 |
| `0.1.7-alpha.1` | 825 / 75 | 52 | 126 | 76 | 125 |
| `0.1.7-alpha.2` | 825 / 75 | 52 | 126 | 76 | 125 |
| `0.1.7-rc.1` | 825 / 75 | 52 | 126 | 76 | 125 |
| `0.1.7-rc.2` | 825 / 75 | 52 | 126 | 76 | 125 |
| `0.2.0-rc.1` | 825 / 75 | 52 | 126 | 76 | 125 |
| `0.2.0-rc.2` | 825 / 75 | 52 | 126 | 76 | 125 |
| `0.2.1-alpha.1` | 825 / 75 | 52 | 126 | 76 | 125 |
| `0.2.1-alpha.2` | 831 / 69 | 52 | 126 | 76 | 125 |
| `0.2.1-alpha.3` | 831 / 69 | 52 | 126 | 76 | 125 |
| `0.2.1-alpha.4` | 831 / 69 | 52 | 126 | 76 | 125 |
| `0.2.1-alpha.5` | 831 / 69 | 52 | 126 | 76 | 125 |
| `0.2.1-rc.1` | 831 / 69 | 52 | 126 | 76 | 125 |
| `0.2.1-rc.2` | 901 / 69 | 52 | 126 | 76 | 125 |

逐命令日志、失败尝试、源码快照 SHA-256、隔离 Git 构建记录与机器可读汇总保存在被忽略的 `.dsh-smoke/s7-linux-20261023/`，复跑调度器为其中的 `run-matrix.py`；最终汇总逐项核实了全部命令退出码、smoke 零失败/零跳过、双方言探针与执行源码校验和。上述结论以本节为持久真源。WSL2 的原生执行不替代远端 Ubuntu 两种 runner 镜像或其他 OS 的本批 CI，也不补记 Windows 两项能力缺口为通过。

### PR #18 远端 CI 验收（2026-10-23）

[CI run 39955314649](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39955314649)（run #176，attempt **1**）对应 [PR #18](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/18) 的 `c51f3efd5f1ec38caa052b15cfc3e79b8a1de1d0`，实际 checkout 为 PR merge tree `ac3de488927b727289dffb8341d1d168f7e979c4`。矩阵从既有 allowlist 读取 **16 个精确版本 × 4 个 runner 镜像 = 64 项**：`ubuntu-latest`、`ubuntu-22.04`、`macos-latest`、`windows-latest`。Node `22.19.0` / pnpm `11.25.0`，使用 enforce 门禁，未扩大支持集合或修改 Windows 前提检查。GitHub connector 的 jobs 入口只返回前 30 项，核对时通过 Actions API 分页取得全部任务，不能把第一页当完整矩阵。

该 run 于 **2026-10-23 20:58:09（Asia/Taipei）**结束，结论 **success**：**64/64 矩阵任务 success**，加上 releases 与[最终 gate](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39955314649/job/120426410563)，共 **66/66 任务 success**，没有失败、取消或整项跳过。每项均完成 compat、lint、双端 typecheck、build、kernel:probe、test、compose/behavior/journey、pack:check、smoke:packed、Auto Review 合同入口与 docs:check；Windows broker 安装与卸载也均成功。任务成功不等于其中所有平台/宿主能力断言均已执行，下表保留实际 skip。

开发 pin 的远端执行证据：test 列为通过 / 跳过；所有 skip 均不计作对应原生能力通过。

| runner / 任务日志 | test | compose / behavior / journey / packed behavior | 原生方言与边界 |
| --- | --- | --- | --- |
| [macos-latest](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39955314649/job/120419666897) | 891 / 79 | 52 / 126 / 76 / 125，均零失败、零跳过 | Seatbelt 实跑；无 bwrap/Landlock |
| [ubuntu-latest](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39955314649/job/120419667036) | 893 / 77 | 52 / 105 / 76 / 104，均零失败；behavior 与 packed behavior 各 1 skip | Landlock 实跑；bwrap 因 `setting up uid map: Permission denied` 不可执行，保留宿主策略，不补记 bwrap 通过 |
| [ubuntu-22.04](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39955314649/job/120419667109) | 901 / 69 | 52 / 126 / 76 / 125，均零失败、零跳过 | bwrap 与 Landlock 均实跑 |
| [windows-latest](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39955314649/job/120419666834) | 926 / 44 | 52 / 133 / 76 / 132，均零失败、零跳过 | Windows Server 2025 / `windows-2025-vs2026`；真实 windows-acl 探针、broker 安装与卸载、Auto Review 和任务收尾均成功 |

#### Windows 两项本机能力缺口的闭环

已检查其余 15 个 Windows 任务的完整日志及 rc.2 已上传的 `vitest-log-windows-latest-0.2.1-rc.2`、`smoke-log-windows-latest-0.2.1-rc.2`。**16 个版本均完成原生测试，第二固定卷与 foreign-owner 不再是待补验项**。rc.2 的 vitest 日志明确列出以下两例通过；其他版本同一套件通过，且 `CI=true` 下缺少第二固定卷、SYSTEM owner 或 deny ACE 都会使测试失败，不能走本地能力 skip：

- `grants an additional root on a different drive`：真实受限 Node 写探针断言主根、跨固定卷附加根为 `allowed`，第三目录为 `denied:*`。
- `refuses a root the caller does not own`：测试先核实 owner 为 `S-1-5-18`（SYSTEM）并读回 Everyone deny ACE。全部 Windows 日志均记录 `the grant was applied; asserting the child could not write either dir (status 0)`，实际走的是**受限子进程启动后两处写入均拒绝**的成功分支；不宣称本轮复现了启动前 exit 127。随后断言 foreign-owned 与第三目录均未生成 `owned.txt`。

每版 `tests/windows-native.e2e.ts` 为 **40 tests / 2 skipped**；上述两例不在 skip 内。每版 `tests/skills-windows.e2e.ts` 的 **7 项均执行通过**。完整套件按版本分组为：`0.1.5-rc.2`、`0.1.6-alpha.1`、`0.1.6-alpha.2` 各 **849 passed / 51 skipped**；`0.1.7-alpha.1` 至 `0.2.1-alpha.1` 的 7 个受支持版本各 **852 / 48**；`0.2.1-alpha.2` 至 `0.2.1-rc.1` 的 5 个受支持版本各 **857 / 43**；`0.2.1-rc.2` 为上表 **926 / 44**。这些远端计数独立于前述本机矩阵，不回写或覆盖本机的真实 skip。

最早支持版的复核日志为 [Windows 0.1.5-rc.2](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/39955314649/job/120419666284)，开发 pin 的日志为上表 Windows 任务；其余版本任务均可由同一 run 的完整矩阵定位。Auto Review 的 fork 检查进入全部版本，联合 smoke 的真实集成范围仍仅限 `0.2.1-rc.2`，该版四个 runner 均完成 source/link 与 packed、web/headless × 两种官方 bundle 顺序；其他 15 版的可选集成退出 0 不计为联合集成通过。

### 剩余验收与 checkpoint

Windows、Linux（WSL2）本机各 16 版本完整门禁已执行；Windows 第二固定卷与 foreign-owner 两例及本批远端完整矩阵已补验，最终 gate 全绿。新测试已进入既有测试入口；本批已按 C0 → C7a 的 checkpoint 顺序分为 9 笔提交，Windows、Linux 验证另作独立提交。S7 剩余发布准备：按 release workflow 确定版本、同步发布状态并更新双语 CHANGELOG，说明旧 inherit/read-write 登记默认启用、read-only 默认关闭、全局关闭方式与 metadata 降级边界。当前未准备版本或 tag，不修改已发布历史，PR 保持 Draft，计划保留 active。上述 CI 结论只绑定记录的代码 SHA；后续提交的 CI 应另行核对，不能继承为已通过。

C7 保存本机集成、最终回归、浏览器/兼容性收敛和文档；C7a 保存浏览器末轮发现的预览生命周期修正及两形状回归。这些 checkpoint 只代表当时本机阶段完成，后续平台结果见上文。C0–C7、C7a 为按顺序应用的增量 patch；临时快照另备份在本工作区被忽略的 `.dsh-smoke/checkpoints-multi-root-skills-20261023/`，含基线与校验和 manifest，可用于后续分批提交。正式仓库已按 checkpoint 完成分批提交；原始补丁继续保留，最后一笔另同步本节提交状态。S7 全部退出条件（含发布准备）已满足；计划已归档 `completed/` 并随 `v0.1.10` 发版。

## DSH 0.2.1-rc.3 兼容提升（2026-10-23）

用户授权范围是 `dsh-v0.2.1-rc.3` 一个发布版本。上游本地 tag 与 npm `versions` 列表一致，与 `0.2.1-rc.2` 做源码差分。支持合同保留全部旧版，再纳入这个精确版本；开发 pin 与 lockfile 升到 `0.2.1-rc.3`，cordis 仍是 `4.0.5`（`dsh` 仍依赖 `~4.0.5`）。插件版本号不变，本提升不单独创建 release tag（随后随 `v0.1.10` 一并发版）。

| 上游 tag | commit |
|---|---|
| `dsh-v0.2.1-rc.3` | `1f81c047fc48fa190a683e469daa699857e9afe8` |

#### 接口变更与风险

| 接缝 | 上游变化与影响 | 本次处理与证据 |
|---|---|---|
| client slot catalog / navigation | 新增 `sidebar.panellist.actions` 与 `sidebar.right.tab.guide.actions` 槽位；navigation pins 与 selection 分离；导航/预设埋点 | 不相关：不占本插件 slot；`sidebar.footer.action` 与 `sidebar.right.tab.files.actions` 注册不变 |
| `dsh-llm` DeepSeek API-key 路由 | 模型列表改走官方 `/models` listing | 不相关：LLM 接缝只包装工具消息形状 |
| fork 客户端文件 | `rc.2`→`rc.3` 的 `src/client/` 子树逐字节零改动（`ui-sidebar-files/src/client` 与 `ui-open-in-app/src`） | 按 FORK.md 核对后仅前移 revision 基线至 `1f81c047fc`，不重新拷贝 |
| cordis / storage-domain zod / session format / install 门禁 | 均无变化 | 无新适配分支；storage-zod 与 peers 契约原样覆盖 |

#### 候选车道与验收

候选 `0.2.1-rc.3` 走完整 upgrade lane（`upgrade-dsh.mjs` repoint + `--config.minimumReleaseAge=0` 重装 + `DSH_MULTI_ROOT_COMPAT=warn pnpm verify:all`）。本地宿主为 macOS：`kernel:probe` 实测 Seatbelt 可执行；bwrap / Landlock 本机不存在，Linux/Windows 原生证据由远端 CI 承担，不把本地 skip 记为通过。

| 运行时 | 单测 | compose | behavior | journey | packed behavior | 结果 |
|---|---|---|---|---|---|---|
| `0.2.1-rc.3` | 841 passed / 79 skipped | 52 | 126 | 76 | 125 | 通过 |

候选期间无接缝修复——全部验证一次通过。

#### 正式提升

`SUPPORTED_DSH_RELEASES` 扩至 17 个精确版本；27 个 `@deepseek-ai/dsh-*` peer 同步枚举；开发 pin `0.2.1-rc.3`、cordis `4.0.5`；release-age 精确豁免重写为 rc.3 集合；probe overrides 与 `minimumReleaseAge: 0` 不落入提交。可选 Auto Review 联合合同保持 `0.2.1-rc.2` 不变（`AUTO_REVIEW_RELEASE` 未动）。提升后 enforce 验收（`0.2.1-rc.3` / cordis `4.0.5` 开发树，本机 macOS）：`pnpm compat:check` 四方一致；`pnpm verify:all` 全绿——lint、双端 typecheck、build、`kernel:probe`（Seatbelt 实测可执行）、test **59 文件 841 passed / 79 skipped**、compose **52/0/0**、behavior **126/0/0**、journey **76/0/0**、pack:check **144 成员**、packed behavior **125/0/0**；`pnpm docs:check` 通过。

#### 旧版回归

在正式 allowlist（enforce）下用 `upgrade-dsh.mjs` 重指并逐版重建安装树：覆盖最近一次支持的 `0.2.1-rc.2`（同时是 Auto Review 联合 pin，其开发包在该 pin 恢复）与 zod 分裂前最后的 `0.2.1-alpha.2`（覆盖 storage-zod 旧形状分支）。每版跑 `compat:check`、全量 test、compose、behavior：

| 版本 | resolved 树 | 单测 | compose | behavior | 结果 |
|---|---|---|---|---|---|
| `0.2.1-rc.2` | 65 包统一（含 Auto Review 开发包） | 911 passed / 79 skipped | 52 | 126 | 通过 |
| `0.2.1-alpha.2` | 49 包统一 | 841 passed / 79 skipped | 52 | 126 | 通过 |

回归后开发 pin 与安装树恢复 `0.2.1-rc.3`：可选 peer（`dsh-permission-presets` / `dsh-util-values`）曾被 lockfile 钉在旧版造成混装，`pnpm dedupe` 重指后 49 包统一 `0.2.1-rc.3`，frozen lockfile install 通过、`compat:check` 再次四方一致。该现象只发生在本地来回重指的工作流，不影响干净 checkout 的 frozen 安装。远端 17 版本 × OS 矩阵由本分支 PR 的 CI 车道执行，未完成前不记为通过。

## DSH 0.2.1-rc.4 与 0.2.2-alpha.2 兼容提升（2026-10-28）

用户授权范围是 `dsh-v0.2.1-rc.4` 与 `dsh-v0.2.2-alpha.2` 两个发布版本。上游本地 tag 与 npm `versions` 列表一致，分别与 `0.2.1-rc.3`、`0.2.1-rc.4` 做源码差分（接口审查见 [dsh-0.2.2-migration.md](../../reference/dsh-0.2.2-migration.md)）。支持合同保留全部旧版，再纳入这两个精确版本；开发 pin 与 lockfile 升到 `0.2.2-alpha.2`，cordis 随 `dsh` 声明升到 `4.0.6-alpha.1`；上游 root engines 自 0.2.2 起要求 Node `>=24.9.0`。插件版本号不变，本提升不单独创建 release tag。

| 上游 tag | commit | npm dist-tag |
|---|---|---|
| `dsh-v0.2.1-rc.4` | `504a01a9578abc2c6f1fb896b1dc322c9fe24f66` | `next` |
| `dsh-v0.2.2-alpha.2` | `f3803c96974ad4a94195fb97e5c637e9c2a3afe3` | `alpha` |

#### 接口变更与风险

| 接缝 | 上游变化与影响 | 本次处理与证据 |
|---|---|---|
| `AgentRegistry` 注入 | 新增 `inject = ['sessionProjections']`；挂缺 `ctx.agents` 为 `undefined` | 测试栈补挂 `SessionProjectionRegistry`（skills-stack、auto-review/parent）；插件源码不消费 `ctx.agents` |
| 工具执行拆分 | `ctx.tools.setExecutor`、批量 `execute({calls})`、`dsh-tools/pipeline` 仅 0.2.2 起存在 | `tests/support/tool-executor.ts` 按 `setExecutor` 存在性动态挂载；动态导入 specifier 非字面量（Vite 转换期会解析字面动态导入，旧版本直接炸 spec） |
| Sandbox `additionalWritableRoots` | 原生第三路可写根（Seatbelt/bwrap/Landlock/fs-sandbox 消费，windows-acl 拒绝） | 本插件不设该字段；`tests/upstream-additional-roots.spec.ts` 钉住原生根 X 与 scope 根 Y 在各方言同时授予、fs fence 与真实 Seatbelt 执行一致 |
| client fork | `ui-sidebar-files` hover 移入 `@media (hover: hover)`；`ui-open-in-app` 失败反馈改为 `shell.overlay` outcome toast | fork 基线前移 `f3803c9697`（见两个 FORK.md）；新增 `outcome.ts`/`device.ts` shim、`open-failure-toast.tsx` 删除；`Toast` 的 `tone`/`actions` 经 `upstream-surface.d.ts` 重载在 0.1.5 像素期上过 typecheck |
| session / storage / skills | session/created 完成前拒 append；storage 新增 deleteRecords/unknown-state；filesystem skills 报 incomplete observation | 均为新增面或语义微调，插件不受影响（skills incomplete 记为已知后续观察点） |
| Node / cordis | 0.2.2 起 engines `>=24.9.0`；cordis `~4.0.6-alpha.1` | CI verify 按已知旧版前缀分流：仅 `0.1.*`/`0.2.0`/`0.2.1` 用 Node `22.19.0`，其余用 `24.9.0`；`upgrade.yml` 升至 `24.9.0` |

#### 候选车道与验收

`0.2.1-rc.4` 探针一次全绿、零源码改动：单测 **841 passed / 79 skipped**，compose **52**、behavior **126**、journey **76**。

`0.2.2-alpha.2` 首跑 typecheck/build/三路 smoke 全绿；首轮 Vitest 为 **815 passed / 26 failed**——全部集中在 skills 测试栈（`AgentRegistry` 的 `sessionProjections` 注入 fixture 缺口），补齐后又暴露 `ToolExecutorUnavailableError`（执行器拆分），经 `tests/support/tool-executor.ts` 结构探测解决。修复后 alpha.2 enforce 验收（本机 macOS，Seatbelt 可执行）：`compat:check` 四方一致；lint、双端 typecheck、build、`kernel:probe` 全过；test **61 文件 855 passed / 79 skipped**、compose **52/0/0**、behavior **126/0/0**、journey **76/0/0**、packed behavior **125/0/0**；auto-review:fork 验证通过、smoke:auto-review 按设计跳过（仅 `0.2.1-rc.2` 目标）；`pnpm docs:check` 通过。`dsh plugin add` 在安装门禁下接受 `0.2.2-alpha.2`（peers 已含精确版本，无版本告警）。

#### 旧版回归

在正式 allowlist（enforce）下逐版重指重建：**回归期间发现升级脚本混树缺陷并已修复**——committed lockfile 偏好的 alpha 行 cordis 生态包（`cordis-plugin-loader@1.0.7-alpha.1` 等）会被旧版 peer 范围沿用，使 `0.2.1` 运行时混在 alpha loader 上、Settings volatile 写够不到 live Config（skills-settings 的 enabled 断言静默失败）；`upgrade-dsh.mjs` 现从目标版本自身 manifest 派生 `cordis-plugin-*`/`schemastery`/`cosmokit` 精确 pin。修复后每版跑 `compat:check`、双端 typecheck、build、全量 test、compose、behavior：

| 版本 | resolved 树 | 单测 | compose | behavior | journey | 结果 |
|---|---|---|---|---|---|---|
| `0.2.1-rc.4` | 统一 `0.2.1-rc.4`（loader `1.0.6` / cordis `4.0.5`） | 851 passed / 83 skipped | 52 | 126 | 76 | 通过 |
| `0.2.1-rc.3` | 统一 `0.2.1-rc.3`（loader `1.0.6` / cordis `4.0.5`） | 851 passed / 83 skipped | 52 | 126 | — | 通过 |
| `0.2.1-rc.2` | 统一 `0.2.1-rc.2`（loader `1.0.6` / cordis `4.0.5`，含 Auto Review 开发包） | 921 passed / 83 skipped | 52 | 126 | — | 通过；auto-review:fork 验证、smoke:auto-review **真跑**（行开关往返、bundle 顺序、reload、owner drain） |
| `0.2.1-alpha.2` | 统一 `0.2.1-alpha.2`（loader `1.0.6` / cordis `4.0.5-alpha.1`） | 851 passed / 83 skipped | 52 | 126 | — | 通过 |
| `0.2.0-rc.2` | 统一 `0.2.0-rc.2`（loader `1.0.6` / cordis `4.0.4`） | 845 passed / 89 skipped | 52 | 126 | — | 通过 |
| `0.1.7-rc.2` | 统一 `0.1.7-rc.2`（loader `1.0.6` / cordis `4.0.4`） | 845 passed / 89 skipped | 52 | 126 | — | 通过 |
| `0.1.5-rc.2` | 统一 `0.1.5-rc.2`（loader `1.0.6` / cordis `4.0.2`） | 842 passed / 92 skipped | 52 | 118 | 76 | 通过 |

回归后开发 pin 与安装树恢复 `0.2.2-alpha.2`：frozen lockfile install 通过、`--print-installed` 单一 `0.2.2-alpha.2`、`compat:check` 再次四方一致、workspace 无 probe 残留。

**未覆盖**：Linux 上 bwrap/Landlock 的真实内核执行（本机仅 Seatbelt）、Windows ACL 原生矩阵、fork 的浏览器目检（`data-*` 钩子由源码对照核对）、远端全版本 × OS 矩阵（由本分支 PR 的 CI 车道执行）。

## Issue #24：Registry／Skills 刷新循环 hot-fix（2026-10-29）

在 `fix/skill-lock-fix` 修复并经 PR #25 合入 `main`，随 `v0.1.11` 发版；问题机制与修复边界见[故障排查](../../troubleshooting/registry-owned-by-another-process.md#skills-查询导致持续刷新issue-24)，通知规则见 [ADR-0023](../../decisions/ADR-0023-multi-root-skill-discovery-and-invocation.md#4-生命周期缓存与撤销)。生产改动仅使 `setRegistryAuthority()` 对相同状态保持静默，保留现有 lease 重试、持续持锁、拆除顺序与 fail-closed 语义。

新增 `tests/skills-authority.spec.ts` 的四项集成回归，并加强 `tests/scope.spec.ts` 的相同状态通知断言。集成用例挂真实内核锁、生产 Registry、原生 Skills，模拟收到 `skills/change` 即自动重查的客户端，设 20 次硬上限。覆盖正常持锁、空根及有根时持续竞争失败、存储打开失败、故障期间继续持锁、原持有者释放后接管、介质修复后恢复、授权与 Skill 正文加载，以及不可用期间的空附加根授权。既有 `authority-boundaries` / `process-fence` 回归继续覆盖仅主根可写与不授予共享临时区的执行边界。

**先红后绿证据**：未改生产源码时，scope 单测因重复通知失败，两个竞争用例与存储故障用例均触及 20 次查询上限，共 **4 failed / 33 passed**。加入状态相等即返回的判断后，同一组 **37 passed**；持续竞争或存储故障下，初次查询为 1 次、变化事件为 0，重复刷新不增加事件；真实恢复仍通知，接管后稳定刷新不再失效。

本机 macOS、Node `24.18.0`、开发 pin DSH `0.2.2-alpha.2`：`pnpm verify:all` 完成，`compat:check`、lint、双端 typecheck、build 通过；全量 test **848 passed / 90 skipped**；compose **52 passed / 0 failed / 0 skipped**、behavior **95 / 0 / 7**、journey **69 / 0 / 2**、packed behavior **94 / 0 / 7**，`pack:check`、`auto-review:fork` 与 `pnpm docs:check` 通过。`smoke:auto-review` 按既有规则跳过（仅针对 `0.2.1-rc.2`）。`kernel:probe` 正常完成，但外层沙箱使 Seatbelt `sandbox_apply: Operation not permitted`，bwrap/Landlock 未安装，真实受限执行用例按既有能力探测跳过。packed 安装遇到 `koffi` 构建审批后，经既有脚本在隔离 profile 中授权并 remove/add 恢复，behavior battery 通过。

**20 分钟真实双 Host 观察通过**（20:31:56–20:51:57，Asia/Taipei，实际双实例时长 `1200.425s`）：两个独立进程挂完整 DSH `web` profile，共用隔离 `$DSH_HOME` 的登记存储；Skills 开启、真实 Agent/Session，每 5 秒查询、每 30 秒刷新 Registry，收到 `skills/change` 立即重查。约第 8 分半通过真实 HTTP/RPC 手动读取并修改附加根 Skill 正文，此后每 30 秒重复读取。没有 TUI 或模型调用，也没有强制 GC 或降低 V8 堆上限（实测每个 Host 上限 2240 MiB）；外部 RSS 超过 1 GiB 或查询失控即中止的保护均未触发。原定 30 分钟，按用户后续要求在控制器中把截止时间改为 20 分钟，仅调试控制器的截止变量，不重启或修改两个被测 Host；收尾接管观察为 5 秒。原始采样与汇总见[测量数据](../../reference/issue-24-registry-skills-soak-darwin.json)。

| 指标（双实例阶段） | 持锁方 | 竞争等待方 |
|---|---|---|
| 平均 CPU（去除前 30 秒，100% = 一个 CPU 核心，整个 Host 的 user + system 时间） | 0.8560% | 0.7119% |
| 5 秒窗口 CPU 峰值（去除前 30 秒） | 4.4424% | 4.1419% |
| 结束时 RSS / V8 已用堆 / old-space | 28.094 / 88.244 / 66.008 MiB | 30.516 / 86.500 / 65.177 MiB |
| 第 5–10 分钟 → 第 15–20 分钟已用堆中位数 | 83.908 → 87.704 MiB | 83.674 → 86.467 MiB |
| 定时与事件驱动的原生 Skills 查询 / 主动 Registry 刷新 | 242 / 40 | 241 / 40 |
| Skills 变化事件 | 1（修改 Skill 文件） | 0 |
| HTTP/RPC 正文读取 | 24 次成功，包含修改后的正文 | 24 次正确拒绝 |
| 运行错误 / 未预期退出 / OOM | 0 / 0 / 0 | 0 / 0 / 0 |

两个 Host 在 20 分钟内都未出现报告中的持续单核占用或高速内存增长；已用堆有少量漂移，不能据此声称绝无慢泄漏。双实例阶段结束后，持锁方正常退出（code 0），等待方在约 60 ms 后完成显式刷新，从 `contended` 恢复 `active`，附加根写权限和原生 Skills 目录恢复；真实根/authority 变化产生 3 次原生 Skills 事件及有限重查，收尾阶段事件数不再增加，随后也正常退出（code 0）。完整记录含 486 个采样点；该接管阶段验证目录恢复，正文恢复另由上述正式回归用例覆盖。

**未覆盖**：真实 `dsh-tui` 的 OOM 复现、Ubuntu 报告环境的原生复测、Windows 原生 ACL 和远端全版本 × OS 矩阵。


## 多 Host 权威服务开发（2026-10-29）

在 `feat/multi-instant-dsh-lock-upgrade` 开始分批开发。完整原始目标、初版能力对照、未完成项与后续演进见[专项计划](./2026-10-30-shared-registry-authority.md)；当前合同见[共享服务架构](../../architecture/registry-authority-service.md)，第一版撤权完成语义见 [ADR-0024](../../decisions/ADR-0024-registry-operation-admission.md)。A1 为最初基础；2026-10-30 已接入默认共享服务（[ADR-0025](../../decisions/ADR-0025-shared-registry-authority.md)），active/follower 均可逐操作使用附加根，唯一 owner 管理存储。实现完成与三平台/全版本验收分开记录。

| 批次 | 范围 | 状态 |
| --- | --- | --- |
| A1 | 确定撤权语义；store-wide mutation / refresh / fs 准入排序；write/edit 每调用独立快照、过期 handle、epoch 与 publication revision | 已实施并完成下述本机门禁；随 `v0.1.12` 发版 |
| A2 | async admission → sync confine/spawn；直接服务调用、shell/PTC/agent PTY 与旧进程边界 | 已实施；原有全部精确版本原生 CI 验收通过 |
| B | 唯一存储核心 / Host facade；store 身份、配置握手、本机 IPC 与调用者隔离、流控、幂等及结果不明 | 已实施；三平台原生认证/受限子进程回归通过 |
| C | LSP、Files/watch、instructions、Skills 等全消费者准入；断线保守拒绝、崩溃/竞选/接管、新 epoch | 已实施；真实服务、多进程及全版本 CI 回归通过 |
| D | 屏障控制的真实多进程交错、三平台、所有支持版本与 packed 安装验收 | 多进程、三平台、全版本及 packed 已验收；macOS 真实 TUI 长跑/故障注入通过，Ubuntu 报告环境待复测 |

A1 实现不改变 lock 路径、持锁时间、domain schema 或 provider 门禁。原有 hot-fix 保留；`setAdditionalRoots()` 仍是唯一根写口。测试使用真实 Registry / JSON backend / 内核锁，以 Promise 屏障固定“先准入后撤权”和“先撤权后准入”，并实际写入/编辑文件；不把通知、revision 或“连接活着”作为授权依据。

本机证据（macOS、Node `24.18.0`、已安装 DSH `0.2.2-alpha.2`；未重装依赖、未更改支持矩阵）：

| 检查 | 结果 |
| --- | --- |
| `compat:check`、lint、typecheck、build | 通过；compat enforce，allowlist / peer / dev pin / 实际树一致 |
| 完整 `test` | 63 文件通过 / 3 文件跳过；862 测试通过 / 90 跳过，包含原有 Registry、lease 和 Skills 循环回归 |
| 最后补强后的 `tests/registry-operation.spec.ts` | 15 项通过：跨主根排队屏障、detached async handle 失效、真实 fs 撤权交错、工具封顶、三态矩阵、路径替换与接管 |
| `kernel:probe` | 完成；Seatbelt 被外层沙箱拒绝（`sandbox_apply: Operation not permitted`），bwrap/Landlock 未安装；内核执行断言按既有规则显式跳过 |
| `smoke:compose` | 52 通过 / 0 失败 / 0 跳过 |
| `smoke:behavior` | 95 通过 / 0 失败 / 7 内核项跳过 |
| `smoke:journey` | 69 通过 / 0 失败 / 2 内核项跳过；web/headless 两条旅程 |
| `pack:check` | 149 成员完整性检查通过 |
| `smoke:packed` | 从 tarball 安装的 behavior battery：94 通过 / 0 失败 / 7 内核项跳过 |
| `docs:check` | 0 错误 / 0 警告 |

pnpm 的自动依赖自检最初尝试重装并因非交互环境中止；后续用 `pnpm_config_verify_deps_before_run=false` 运行仓库脚本以保留现有安装树，真实兼容门禁仍正常执行并通过。未执行真实 dsh-tui 双 Host；Windows/Linux、其他支持版本以及未来 IPC 行为均不能由本机测试代替。

### 共享服务与全消费者接入（2026-10-30）

默认 bundle 配置 `sharedStorageRoot`，owner 单独打开显式 JSON medium，follower 经内核认证 IPC；所有变更/admission 在核心排序，owner 无本地旁路。同步消费以短期上下文连接，复制的旧 argv 不再是后续新操作许可；agent PTY 新准入后重新生成 profile，用户控制器终端透传。fs、LSP、Files/watch、instructions、原生 Skills 缓存与加载已接入；失联保留拒绝边界，写入结果不明隔离，mutation 丢应答不自动重放。协议只缓存紧凑 mutation 结果，持续查询不积累整份 roots snapshot。behavior/packed battery 另以两个完整独立 boot 的 Host profile 验证实际安装产物的 IPC 共享、撤权和新 epoch 接管（同进程双 Host；进程隔离另由 e2e 覆盖）。具体合同与能力前提以[共享架构](../../architecture/registry-authority-service.md)为准。

本机 macOS / Node `24.18.0` / DSH `0.2.2-alpha.2`，当前开发依赖树保持原样；新增的旧版验证使用 `/private/tmp` 独立安装树，不变更当前 manifest pin 或 allowlist。Seatbelt 在外层沙箱外实测可用，完整回归显式要求已验证的 Seatbelt，不能以嵌套沙箱为由静默跳过。

| 验证范围 | 结果 |
| --- | --- |
| `compat:check`、lint、typecheck、build | 通过；enforce 模式及原精确支持列表保持 |
| 当前基线完整 `test` | 67 文件通过 / 3 文件跳过，900 测试通过 / 84 跳过；包含真实 IPC 与独立进程 |
| `kernel:probe` | Seatbelt 真实受限命令可执行；bwrap/Landlock 本机无 runner |
| compose / behavior / journey | 52 / 136 / 76 通过，各 0 失败、0 跳过；web/headless 真实工具旅程 |
| `pack:check` / `smoke:packed` | 157 成员检查通过；tarball 安装后 behavior 135 通过 / 0 失败 / 0 跳过 |
| `auto-review:fork` / `smoke:auto-review` | fork 检查通过；可选集成按既有精确 `0.2.1-rc.2` 规则跳过 |
| `docs:check` | 0 错误 / 0 警告 |
| 最早支持版本 `0.1.5-rc.2`（Cordis `4.0.2`） | 隔离树 enforce compat、typecheck、build 通过；6 个接缝/共享/命令测试文件 86 通过 / 5 平台项跳过；behavior 128 / journey 76 通过，各 0 失败、0 跳过 |

旧版 fixture 显式放在仓库既有 `.dsh-smoke` 物理目录，使用 `DSH_TEST_FIXTURE_PARENT`；隔离 smoke 仅修改 fixture 路径，避免 `/tmp` 自带 write grant 和 symlink 拼写使断言失真。没有对生产接缝加入测试豁免、没有放宽 compat。最早版本证明同步 confine/旧执行器与公开 JSON/domain 适配的实际兼容，不代替其余版本矩阵。

确定性故障用例：独立进程并发同/异主根修改不丢数据；在 fs 真正解析处暂停已准入写，然后另一 Host 撤权，旧操作可完成、新写被拒；SIGKILL 后多个候选仅一个 owner，从磁盘恢复；旧 holder 重启成为 follower；SIGSTOP 时超时拒绝新操作但不夺锁。另覆盖广播丢失、已提交应答丢失不重放、断线后的新嵌套调用不继承旧 grant、新 epoch、unknown-state 保留 lease、原生 Skills change→requery 有界、读缓存撤权、指令显式撤回、空闲 Files 流断线取消、hello/change 同批读取，以及受限 macOS 子进程知道 endpoint 仍不能调用管理方法。

**初版提交时尚未执行的验收**：Windows 原生 pipe/token/ambient deny 与 semaphore 多候选崩溃恢复；Linux 原生 SO_PEERPIDFD、NoNewPrivs 与 bubblewrap 攻击用例；三平台 × 所有精确版本远端 CI；真实 dsh-tui 的多 Host 长期运行/Ubuntu OOM 报告环境复测。前三项的后续结果见下节；当时真实 TUI 长期观察仍未执行，后续 macOS 实机结果见本节末尾。该变更随后经 PR #26 合入 `main` 并随 `v0.1.12` 发版；原先 Issue #24 hot-fix 的 20 分钟观察不能作为新共享服务的长期内存证据。


### 初版核对与 Draft PR 验收（2026-10-30）

初版 `c56fbb2` 与专项计划 `58e2439` 已推送并创建 [Draft PR #26](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/26)。首轮 [CI run 40997877818](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/40997877818) 覆盖 19 个精确版本 × 4 个 runner（macOS、Windows、Ubuntu latest/22.04），不能仅凭部分 job 成功记全绿。

核对补充：加入 build 后的 `registry:probe --required`，防止认证实现异常导致 shared tests 整体跳过；Windows 能力探测只将已知受限身份记为 unavailable，原生绑定/API 错误向外失败。补充同物理 store 路径别名共享、替代锁名拒绝、Host 根上限冲突、旧 epoch 应答不能执行 body 的回归。首轮实际暴露两项夹具问题：Ubuntu latest 的 Full-access runner 受限提前返回时没有清理持久化登记；Windows ambient-deny probe 把 temp 的 8.3 别名直接传给要求 canonical 路径的 runner。分别补 finally 清理和 canonical 化，不放宽生产授权或降低内核断言。

最终验收见本节末尾；此阶段不发布，不将原生/版本验收和真实 dsh-tui 长期观察合并为一个完成结论。


另外补齐 Windows semaphore 的真实子进程夹具：在 contender 持有 handle 的位置设置恢复屏障，holder SIGKILL 后不得借残存对象/旧缓存授权；waiter 关闭最后 handle 后重新竞选并读回磁盘数据。这个用例验证 handle 生命周期，屏障不声称是 Windows OS suspend 的独立实现。共享 Host NDJSON 驱动抽到测试 helper，保留已有多进程交错。macOS 上该 Windows 专项按平台跳过，执行结果须取 CI，不能记为本机通过。

远端检查点：`b9e5d93` 的 [run 40998531394](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/40998531394) 完整成功，覆盖 19 精确版本 × 4 runner。新增 semaphore 夹具的 `fa278b2` [run 40999088342](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/40999088342) 首次执行中 75/76 verify 成功，Windows 19 车道全部通过；唯一失败是 Ubuntu 22.04 / `0.2.1-rc.2` journey 的显式 Skills 正文断言，因此整轮 gate 失败，不能记为全绿。

随后补出确定性回归：在正文加载后、最终 receipt 检查前创建普通根文件并执行生产 `pool.poll()`，旧实现丢弃未变化的显式调用正文。根目录的 mtime/ctime/size 原本随普通文件增删改变，被误算为 Skills generation 变化。修复将根指纹限定为 canonical 身份/权限，Skills 目录和文件仍跟踪内容元数据；原路径的根替换、Skills 增删改和权限撤销检查保留。此交错解释偶发 journey 失败，但原失败没有保存该轮轮询时序，不能声称取得了逐事件对应证据。

补强后本机完整测试 **906 通过 / 85 跳过**（67 文件通过 / 4 跳过），journey **76 通过 / 0 失败 / 0 跳过**，重新打包安装的 behavior **135 通过 / 0 失败 / 0 跳过**；lint、typecheck、build、docs 检查通过。新回归先在旧逻辑失败，再在修复后通过；原有撤权/正文变更丢弃测试继续通过。

**最终代码验收**：`480d474` 的 [CI run 41019582308](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/41019582308) 首次执行完整成功，**76/76 verify**（19 个原有精确版本 × macOS / Windows / Ubuntu latest / Ubuntu 22.04），releases 与最终 gate 均成功。所有车道都经过 `registry:probe --required`，不能因共享能力探测整体跳过新服务回归。每车道执行 enforce compat、lint、typecheck、build、kernel probe、test、compose/behavior/journey、pack/packed、适用的 Auto Review 和 docs 门禁。Windows semaphore 保留 waiter handle 的屏障用例、pipe/token/ambient deny 用例已在原生执行；Linux NoNewPrivs/SO_PEERPIDFD 与 Ubuntu 22.04 的 bwrap 用例已执行。Ubuntu latest 的 bwrap 能力限制仍按 probe 显式处理，不把跳过记为该方言通过。

`fa278b2` 原偶发失败车道不改代码重跑后成功（run attempt 2）；这不代替 `480d474` 的完整重验。**该 CI 检查点时的剩余交付**是新服务的真实 dsh-tui / Ubuntu 长期 CPU、RSS、V8 heap 观察及发布前复核；不以自动化一致性测试替代原报告环境的长期资源证据。


### 真实 dsh-tui 的 macOS 实机验证（2026-10-30）

使用本机 macOS Darwin 24.6.0 / arm64 / Node `24.18.0`，隔离安装报告使用的 **`@deepseek-harness-tui/dsh-tui@0.17.0` + DSH `0.2.1-rc.2` / Cordis `4.0.5`**。插件为代码提交 `6e87ab7` 打出的 tarball（元数据仍是开发基线 `0.1.11`，不是已发布 hot-fix 的包体）；SHA-256、版本、采样、逐项断言与 epoch 见[实机原始摘要](../../reference/issue-24-tui-shared-registry-soak-darwin.json)。开发树 pin/安装依赖和支持列表未改变；两侧均是真实 TUI PTY 及其独立 `host-entry.js`，经官方 plugin 安装的包体、真实 JSON/内核锁/认证 IPC、真实工具调度及文件 I/O。本地脚本模型只替代远端推理，无真实模型凭据。

双 Host 首次共同采样 `08:15:49.031Z`，首次故障注入 `08:45:49.755Z`，**连续双 Host 1800.724 秒**；整个正式采样从 `08:15:22.278Z` 到 `08:53:07.971Z`。零根阶段约 5 分钟（稳定统计排除启动，含一次真实 list）；登记附加根、调用 Skill、写文件、撤权/恢复后，保留约 21.5 分钟无新输入的稳定窗口。所有时间为 UTC。

| 稳定窗口 | owner | follower |
| --- | --- | --- |
| 零附加根：CPU 均值 / P95（100% = 一核心，整 Host） | 2.84% / 4.73% | 2.57% / 4.96% |
| 零根：Skills 查询 / 变化事件 | 4→4 / 6→6 | 4→4 / 7→7 |
| 已登记且 Skills 开启：CPU 均值 / P95 | 0.93% / 1.09% | 0.54% / 0.68% |
| 已登记：heapUsed 起止（MiB） | 129.56→129.91 | 131.45→131.27 |
| 已登记：old_space 起止（MiB） | 96.58→96.65 | 98.18→98.32 |
| 已登记：Skills 查询 / 变化事件 | 19→19 / 12→12 | 21→21 / 13→13 |

RSS、heapTotal、external、每个采样与分布另存 JSON；不强制 GC、不抬高 heap 上限。整 Host CPU 是主线程占用的上界，不将它误称为 Linux `/proc` 的逐线程采样。零根与带根窗口的 UI 动画/任务状态不同，不把两者 CPU 差值归因于 Registry 性能提升。本轮未见查询自激、持续单核占用或 retained heap 失控；有限窗口不能证明所有长期泄漏都不存在。

真实操作与故障结果：

- 两个 TUI 都能列出根，owner/follower 各经真实 `write` 成功落盘；两侧 `/additional:review` 均使正文抵达实际模型请求。
- owner 通过 TUI 改为只读，follower 的下一次真实 write 返回 `is_error: true` / read-only additional root，目标未生成；follower 自己经 IPC 恢复权限后，owner 同步恢复。
- owner `SIGSTOP` **138.971 秒**：follower 变为 contended，没有夺锁、没有目标文件或模型/工具调用。TUI 在约 5 秒时报 `registry request result is unknown`，错误发生在准备阶段，不能记为 write 工具返回拒绝。恢复后回到原 epoch；失败请求不自动重放，重新提交的新 write 成功。
- owner `SIGKILL` 后，follower 成为 active、从磁盘恢复登记并以新 epoch 写入成功；旧 owner 重启成为该 epoch 的 follower，也能写入。
- 新 owner 经 TUI `/exit` 正常退出（0），剩余 Host 再次竞选，以第三个 epoch 写入成功并 `/exit` 退出（0）。核对已知 launcher/Host PID 全部消失；无 OOM 或保护器中止。

17 项文件/错误/Skill/epoch/退出/清理断言通过。长跑先用临时驱动执行，随后将观测方法整理为 `pnpm soak:tui-registry`；仓库脚本另以独立 store 短测真实启动、受支持/共享元数据、未登记根写入负例、清理，以及约 40 秒显式暂停/恢复。脚本不提供生产授权、不加入 bundle 或普通 CI；用法和保护边界见[开发工作流](../../development/plugin-development-workflow.md#真实-tui-的长期观测手工验收)。lint、Node/Python 语法、兼容静态检查与 docs 检查通过；本轮未改生产实现。

**仍未验证**：原报告 Ubuntu / Node `24.22.1` 的同组合长跑。本轮未连接原 Ubuntu 机器，当前安装源也未取得该 Node 的 macOS 包；不能用 macOS/Node `24.18.0` 的结果勾掉原环境验收。真实模型/第三方工具、自主旧 PTY/进程和所有故障交错也不由这次实机步骤覆盖；既有三平台 CI 是独立证据。PR #26 随后合入 `main` 并随 `v0.1.12` 发版；Ubuntu 报告环境的同组合长跑复测仍为遗留验收。

### PR #26 Review P1：打开与卸载重叠时的 listener 泄漏（2026-10-30）

[Review 5709799843](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/26#pullrequestreview-5709799843) 的 [P1](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/26#discussion_r4421755480) 成立：`releaseAuthority()` 原先在 authority 队列外关闭当前 server；正在运行的 `openDomain()` 随后仍能创建新 listener，队列里的拆除只关 domain/release lease，遗漏 listener。Windows 遗留 named-pipe instance 会阻止继任者创建首个监听。

修复将 server 清理放回 authority-transition 队列，在已开始的 acquisition/open/listen 完成后，按 **server → domain → lease** 拆除。disposed 标记和 follower 连接失效仍即时执行，不改变持锁、撤权或数据格式合同。测试 helper 保留 `ctx.plugin()` 返回的真实 Registry fiber，用于只卸载该行并保留 sibling Host 服务。

新增 `shared-registry.spec.ts` 的确定性屏障回归：真实介质和内核锁，暂停异步 listener 返回，先触发 Registry 行卸载再释放屏障；旧代码漏关 server，修复后清理顺序正确。继续验证继任者在同一 endpoint 启动、新 follower 握手、磁盘登记保留及真实 fs 写入。Windows 的 FIRST_PIPE_INSTANCE 由该用例在原生 CI 执行，不能用 macOS 结果代替。

本机 macOS / Node `24.18.0` / DSH `0.2.2-alpha.2`：定向 3 文件 **39 通过 / 1 平台项跳过**；完整测试 **907 通过 / 85 跳过**；compose/behavior/journey **52/136/76 通过**，packed behavior **135 通过**，均无失败。lint、typecheck、build、compat、原生 Registry probe、Seatbelt kernel probe、pack 检查通过；依赖树及支持列表未变。本修复未重跑 TUI 长期观察，也不把前述旧提交的实机结果记为本提交的并发卸载验收。修复提交 `fc56c4f` 的 [CI run 41031794733](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/41031794733) 完整成功：**76/76 verify**（19 个原有精确版本 × 4 runner），releases 与最终 gate 均成功；包含 Windows FIRST_PIPE_INSTANCE 的新回归。该结果对应尚未升级安全依赖的 P1 提交，不替代后续依赖变更的矩阵。

### Socket / CVE 依赖安全升级（2026-10-30）

核对 [Socket 0.1.11 告警](https://socket.dev/npm/package/@dsh-electron/dsh-plugin-multi-root-workspace/alerts/0.1.11?tab=dependencies) 与实际安装树，公告、版本和引入链以[依赖安全排查](../../troubleshooting/dependency-security-alerts.md)为准；[审计摘要](../../reference/dependency-security-audit-2026-10-30.json)记录依赖文件哈希和原始告警的紧凑快照。没有仅凭 shell / network / install script 等行为标记判为恶意，也没有通过删除 Host peer 或绕过围栏消除告警。

插件直接 Zod 下限提升到 `^4.6.7`；测试工具 Vitest 下限到 `^4.1.12`。显式开发依赖 MCP SDK `^1.32.2` 保留 GenAI 原本自动带入的可选能力并使用修复版，当前实际 GenAI `mcpToTool` 加载成功。定向更新原有范围允许的传递依赖，最终无 overrides / patchedDependencies；DSH 开发 pin `0.2.2-alpha.2`、Cordis 和 19 版本支持列表均不变。

| 当前安装树审计 | 更新前 | 更新后 |
| --- | --- | --- |
| 生产含 Host peers | 5 high / 4 moderate | **5 high / 4 moderate** |
| 完整开发 / Host 树 | 1 critical / 17 high / 27 moderate / 3 low | **0 critical / 5 high / 6 moderate / 0 low** |

完整树审计条目从 48 降到 11，包含 critical 的修复；这是当前基线 lockfile 的结果，不是所有受支持 Host 的生产安全结论。生产审计剩余 Zod `4.4.3` 与 Undici `8.11.2` 均由 DSH 精确 pin，插件自己的 Zod 已是 `4.6.7`。完整树另外剩 `libreoffice-kit` 的 fflate `0.8.2` 和 `dsh-mcp-client` 的 2.x client `2.2.0` 精确 pin。最新 DSH `0.2.1-rc.5` 仍保留同一 Zod、Undici 和 MCP client pin，因此没有为消除告警而盲目扩充支持范围。

后续：等待或验证解除精确 pin 的父包 / DSH 组合，确保 Host 实际使用修复版，完成其精确版本及原生矩阵，再按发布流程交付。旧 `0.1.11` 的 Socket 结果不会因本分支更新而自动修复；当前不能宣称 CVE 全部解决。Host 根项目 override 仍是另行验证的候选，并非本次已支持的安装合同。

本机 macOS / Node `24.18.0` 的最终依赖树：lint、typecheck、build、enforce compat、原生 Registry probe、Seatbelt kernel probe 通过；显式要求已验证的 Seatbelt，完整测试 **907 通过 / 85 跳过**（67 文件通过 / 4 跳过）。compose / behavior / journey **52 / 136 / 76 通过**，packed behavior **135 通过**，均无失败；pack、Auto Review fork 检查通过，可选 Auto Review 集成仍按现有精确基线规则跳过。冻结安装通过；实际 tarball manifest 的 Zod 下限为 `^4.6.7`。docs 检查 **0 错误 / 0 警告**。本轮没有重跑真实 TUI 长期观察；安全依赖代码提交 `90c47e0` 的 [CI run 41058256934](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/41058256934) **首次执行完整成功**：19 个原有精确版本 × 4 runner，**76/76 verify**，releases 与最终 gate 均成功。该结果独立于 `fc56c4f` 的旧依赖验收；兼容门禁通过不等于剩余 CVE 已修复。

## DSH 0.2.1-rc.5 兼容提升（2026-10-30）

本地上游 tag、远端 tag 与 npm 发布列表均核对：相对既有合同，本次唯一新增版本是 `0.2.1-rc.5`。与 `0.2.2-alpha.2` 的共同祖先是 `0.2.1-rc.4`，两条发布线互不包含；上游接口差异与 Files 钩子核对见[接口审查](../../reference/dsh-0.2.2-migration.md#021-rc5-后续审查2026-10-30)。本次把 `rc.5` 加入精确 allowlist 和全部 DSH peer，保留原 19 个版本；开发 pin 继续为 `0.2.2-alpha.2`，不调整 Auto Review 的 `0.2.1-rc.2` 基线，也不创建 release；经 PR #27 合入 `main`，随 `v0.1.12` 发版。

候选树在独立目录重建：49 个直接检查的 DSH 包统一解析到 `0.2.1-rc.5`，cordis `4.0.5`；Node `22.23.1`、macOS 上先以候选 warn 门禁、再以正式 enforce 门禁各跑完整 `verify:all`。正式门禁下 `compat:check`、lint、双端 typecheck、build、Registry 原生认证探针和 Seatbelt 内核探针通过；测试 **903 通过 / 89 跳过**，compose / behavior / journey 分别 **52 / 136 / 76 通过**，打包安装后的 behavior **135 通过**，均无失败。Seatbelt 已显式要求实跑；Auto Review fork 校验通过，可选联合 smoke 按既有精确目标规则跳过。开发 pin `0.2.2-alpha.2` 的 frozen 安装、`compat:check`、原生 Registry 探针与完整 `verify:all` 通过：测试 **907 通过 / 85 跳过**，四项 smoke 分别 **52 / 136 / 76 / 135 通过**，Seatbelt 实跑。

PR 的 CI 以正式门禁覆盖全部 20 个精确版本与启用的四个 runner，原 19 版的跨平台回归以该矩阵为准；本机结果不代替 Linux 或 Windows 原生执行。`rc.5` 的隔离 Web profile 使用本地模拟模型和临时工作区完成 Files 页签三态目检：无附属根、选附属根、切回主根时目录树、路径与刷新 / 打开按钮均正常；对照主根与附属根的目录展开、空目录、长文件名截断、读取失败行和打开方式菜单，外观一致。

## F4 后台恢复与故障诊断立项（2026-10-31）

共享计划 F 表的 F4 项经三轮技术评审后通过（[专项计划](./2026-10-31-f4-background-recovery.md) rev.4），合同由 [ADR-0026](../../decisions/ADR-0026-registry-background-recovery.md) 定案并立项。本节登记批次、合同与实施状态（逐批见下表）；三平台 CI 已验收（真实 dsh-tui soak 暂缓），随 `v0.1.13` 发版。2026-10-31 实施前源码审核门发现 shared 介质绑定校验可被重试绕过（复现两个 active owner），计划修订为 rev.5 并先行修复（F4-P0.5）。评审以真实 Registry + JSON 介质 + 内核锁做的定向复现已把五处前置缺口写进合同（follower hello 不同步投影、空快照 `''` 签名残留旧边界、整轮失败通知振荡、提交顺序被同步回调反向观察、握手不可取消/资格分类缺失）；实施时按"先红后绿"补齐，不以文档表述代替回归。

| 批次 | 范围 | 状态 |
| --- | --- | --- |
| F4-P0.5 | 实施前源码审核门（计划 rev.5）+ R0 阻塞修复：shared 介质/锁绑定校验通过后才记录介质，重试不再绕过校验接管同一介质 | 已实施（macOS 本机：`shared-registry.spec.ts` 修复前红、修复后绿，`registry.spec.ts` 同跑 75/75；三平台 CI 通过） |
| F4-P1 | 前置修复：scope 真值签名；私有暂存与并集提交（scope `subscribe()` 纳入通知批处理，`setAdditionalRoots()` 仍为唯一根写口）；withheld republish 门控；失败日志去重；`AuthorityClient.connect` 本地取消（request 定时器保持 ref、取消时同步清除）；结构化资格分类 | 已实施（macOS 本机：各项修复前红、修复后绿——空快照 scope 边界残留、takeover 订阅者见未落定 authority、暂存期 `list()` 物化磁盘 key、已删主根残留、dispose 等待 hello 4959ms→<1s、资格字段缺失；首轮 PR CI Windows 全版本失败——request 定时器 `unref` 使 Windows 子进程在 hello 期间事件循环清空、退出码 13，已改为保持 ref；复跑后三平台 CI 通过） |
| F4-P2 | 恢复调度器（退避/jitter、合并/取消、`unref`、默认开启 opt-out）+ follower 投影同步完成条件（失败集合清零） | 已实施（macOS 本机：`recovery.spec.ts` 12/12 fake timers；`shared-registry.spec.ts` 自动接管、两主根重连同步、部分同步失败、持续 listen 失败静默、dispose 停调度、opt-out、Issue #24 静默均只读观测通过；三平台 CI 通过） |
| F4-P3 | 诊断面 + 多进程 e2e + `pnpm soak:tui-registry` 口径复测 + 三平台/全版本验收 | 基本完成（真实 TUI soak 暂缓）：`diagnostics` getter 与转换日志已实施；多进程 e2e（SIGKILL→新 epoch 自动接管、SIGSTOP→SIGCONT 原 epoch 重连且不夺锁/不重放）macOS 本机通过；本机空闲降级 30s 长稳（尝试 5 次、scope 通知 0、CPU ≈40ms、heap +1–3MB）通过；全量 `pnpm test` 947 passed / 86 skipped / 0 failed。PR #29 CI（`0468e9a`，run 41193188159）82/82 通过：20 个精确版本 × ubuntu-22.04 / ubuntu-latest / macOS / Windows，gate 通过；Windows 原生后台接管用例实跑通过（约 2.5s），多进程 SIGKILL/SIGSTOP 三例按设计仅 POSIX 运行。暂缓：真实 dsh-tui `pnpm soak:tui-registry`（本批决定暂不运行） |

验收沿用专项计划 Validation 表：自动恢复用例只经只读观测（getter/scope），不得调用 `refresh()` 或隐式 `ensureAuthority` 的 helper；提交一致性回归至少两个主根并同时检查 scope 订阅者、Registry 监听器和广播 snapshot。心跳式主动故障检测与 `unknown-state` 重开不在本批，单列 F4b 候选另立 ADR。Ubuntu 报告环境长跑仍是共享服务既有遗留验收，不由本批勾销；本批随 `v0.1.13` 发版，暂缓的验收仍保留。

## Issue #30：DSH 核心包移出 dependencies（2026-11-01）

[Issue #30](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/issues/30) 报告：DSH `0.2.2-alpha.2` + pnpm `nodeLinker: hoisted` 的 profile 里出现 `@deepseek-ai/schemastery@3.18.5`（宿主 `3.18.6-alpha.1`）、`@deepseek-ai/cosmokit@1.8.6`（宿主 `1.8.7-alpha.1`）与同版本的 `node-addon-system@0.1.2` 第二份副本，启动器报 `profile-core-mixed` / `profile-core-copy`。引入提交定位：`node-addon-system` 自 `aa4b19e`（v0.1.1 的 Registry Authority lease），`schemastery` 自 `1218543`（v0.1.10 的 Skills）。机制：两者都是 `dependencies`，pnpm 为插件单独解析——`^3.18.2` 不匹配 prerelease `3.18.6-alpha.1`，于是装了 `3.18.5`（连带 `cosmokit@1.8.6`）；`node-addon-system` 虽同版本仍是私带副本。

修复：两包移入 `peerDependencies`，由宿主 `dsh-sandbox-local`（每个受支持版本都直接依赖二者）供给唯一副本；`koffi` / `zod` 非 `@deepseek-ai/*`，保留 `dependencies`。peer 范围按"稳定线范围 + alpha 线逐个具名"（cordis peer 同形态）：schemastery `>=3.18.2 <4.0.0 || 3.18.5-alpha.1 || 3.18.5-alpha.2 || 3.18.6-alpha.1`（覆盖 0.1.5-rc.2→0.2.2-alpha.2 全线宿主实带版本），node-addon-system `^0.1.2`；`devDependencies` 钉开发宿主自带的精确版 `3.18.6-alpha.1` / `0.1.2`。防回归：`check-dsh-compat.mjs` 新增形状检查拒绝 `dependencies` / `optionalDependencies` 里的任何 `@deepseek-ai/*`；`tests/compat.spec.ts` 新组钉 peer 形态、必需性与解析同一性（插件侧与 `dsh-sandbox-local` 侧 `createRequire` + `realpath` 必须是同一文件）。`upgrade-dsh.mjs` 的 ecosystemPins 增加 `dsh-sandbox-local` 来源并把 `node-addon-system` 纳入生态系统包集合，`repointManifest` 现在同步重指这些包的 devDeps 开发 pin（同版本自探测全 no-op、输出逐字节一致）。

本机 macOS / Node `24.18.0` / DSH `0.2.2-alpha.2` 验收：`compat:check`、lint、双端 typecheck、build、docs:check、pack:check 全过；完整测试 **951 通过 / 86 跳过**（69 文件 / 4 跳过）；packed 行为 **135 通过**——tarball 经 `dsh plugin add` 装进 scratch profile 后 profile `node_modules` 仅 +4 包，无任何 `@deepseek-ai/*` 第二份副本，issue 形态在端到端验证中消除。修复前在同一工作树上复现过双副本（root `3.18.5` ↔ `dsh-settings` `3.18.6-alpha.1`），修复后 lockfile 中两包只余宿主一份解析。旧版已装 profile 的处理见[排查文档](../../troubleshooting/profile-core-mixed.md)。

同一 PR（#31，合入提交 `c9dc4a0`）另含 `koffi` 原生镜像单例修复：profile 安装会再装一份私有 koffi，与宿主已加载的 `koffi.node` 构成同进程第二个原生镜像，在 darwin-arm64 指针校验下直接 SIGBUS 无声退出（F4 引入的既有回归，CI 0.1.5-rc.2 / 0.1.6-alpha.1 macOS lane 的 Packed smoke 实锤）。新增 `src/compat/koffi.ts` 的 `loadHostKoffi()`：以必需 peer `dsh-fs-local`（每个受支持版本都携带 koffi）为锚点解析宿主副本，解析不到才回退包内自带；`src/` 内全部裸 `import('koffi')` 收编到该入口，`tests/compat.spec.ts` 扫描禁绝回潮并断言锚定同源；`loadHostKoffi` 用 `require` 取 live exports 并校验 `.load`（`import()` 在宿主 addon loader 介入下 CJS 缓存项不可靠，0.2.1-rc.2 auto-review 实锤 `koffi.load is not a function`）。排查文档已同步该形态。合入提交的 [CI run 41380349540](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/41380349540) 全绿；本批随 `v0.1.14` 发版。


## DSH 0.2.2-alpha.3 兼容适配（2026-11-04）

对照上游 `0.2.2-alpha.2` 和 `0.2.1-rc.5` 的 patch，新增精确版本 `0.2.2-alpha.3`，开发 pin 为该版本与 Cordis `4.0.6-alpha.2`；可选 Auto Review 仍钉 `0.2.1-rc.2`，不创建发行版。文件变更接口、Connection 路由和新版 Files 页面适配见[接口审查](../../reference/dsh-0.2.2-migration.md#022-alpha3-后续审查2026-11-04)。

macOS / Node `24.18.0` 候选 warn 验证：Registry 原生认证与 Seatbelt 探针可用；完整测试 959 通过、86 跳过（新增的回归另行通过），compose / behavior / journey 分别 52 / 136 / 76 通过，packed behavior 135 通过；Auto Review fork 检查通过，联合 smoke 按精确目标规则跳过。最初 journey 发现 RPC HTTP 405，修复后真实 HTTP 两种认证路径通过。正式 enforce 下 `compat:check` 与完整 `verify:all` 通过：测试 964 通过 / 86 跳过，三项 smoke 与 packed 分别 52 / 136 / 76 / 135 通过；随后补入真实 `apply_patch` 工具正反例和 Full-access 符号链接替换回归，最终完整测试 967 通过 / 86 跳过。macOS 隔离 Web 页面实机检查了零附加根、主根、附加根、切回主根、目录展开和刷新、打开附加根文件后返回及打开方式菜单；零根会话先经面板确认确无附加根。原有 20 个精确版本在独立 macOS / Node `24.18.0` 安装树中逐一通过 `compat:check`、双端 typecheck、文件系统 / Connection / Files / 工具封顶等关键回归及真实 web/headless journey（各 76 项）；`0.2.2-alpha.2` 起初因旧版 Cordis 混入新 loader 失败，修正预发布依赖选择后重跑通过。Linux、Windows 和旧版 Node 22 的原生 CI 尚待完成。

经 PR #34 合入 `main`（`9035ab0`），其 [CI run 41775651417](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/41775651417) 全绿覆盖全矩阵；本批随 `v0.1.14` 发版。

## DSH 0.2.2-rc.1 兼容适配（2026-11-05）

从 `main` 的 `9035ab0` 新建 `feat/adapt-1105`。分别检查上游 rc.1 与前两个版本 alpha.3 / alpha.2 的完整 patch；结论见[接口审查](../../reference/dsh-0.2.2-migration.md#022-rc1-后续审查2026-11-05)。新增精确支持 `0.2.2-rc.1`，保留原 21 个版本；开发 pin 为 DSH `0.2.2-rc.1` / Cordis `4.1.0` / Schemastery `3.19.0`。未新增适配器分支，可选 Auto Review 仍钉 `0.2.1-rc.2`，不创建发行版。

macOS / Node `24.18.0` 候选 warn 下完整 `verify:all` 通过：原生 Seatbelt 探针可用且显式要求实跑；测试 **967 通过 / 86 跳过**，compose / behavior / journey 分别 **52 / 136 / 76 通过**，packed behavior **135 通过**，pack 与 Auto Review fork 检查通过；可选 Auto Review 集成按既有精确目标规则跳过。

正式 enforce 下 `compat:check`、原生 Registry 认证探针（`--required`）、完整 `verify:all` 与 frozen 安装通过；计数与候选相同，Seatbelt 实跑。`docs:check` 为 **0 错误 / 0 警告**。隔离 Web profile 完成零附加根（面板确认空登记）、主根、附加根、切回主根的三态目检，目录展开、长名截断、刷新、附加根文件预览并返回、打开方式菜单正常，切回后原生树与按钮恢复。未运行真实 TUI 长期观察。

原有 21 个精确版本已在独立安装树中逐一完成 enforce `compat:check`、双端 typecheck、build、13 个权限与客户端关键接缝测试文件及真实 web/headless journey；按 CI 同一版本分流规则使用 Node 22 / 24，Seatbelt 显式要求实跑。最早两版的修复复验另含选择器回归。主 worktree 始终保留 rc.1 开发树，最终 frozen 安装与原生 Registry 探针再次通过；临时 probe overrides 未进入提交。全精确版本 × 启用 OS 的 CI 沿用现有 allowlist 派生矩阵；Linux 与 Windows 的完整原生结果尚待当前 PR 的 CI，不以本机 macOS 结果代替。

本批首次 CI（`bee1a59`，[run 41959434977](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/41959434977)）发现旧稳定线宽 vendor 范围混入新 loader `1.1.0`，并非 rc.1 本机回归。升级选择器已改为稳定 vendor 限于宿主声明 minor 线内的最新稳定 patch，prerelease 仍钉精确基线；loader / timer 稳定线回归先红后绿，保留旧版支持并重跑矩阵。

稳定 patch 规则在 `0.1.5-rc.2` 与 `0.1.6-alpha.1` 的 Node `22.23.1` 独立树通过类型检查、关键接缝测试及 web/headless journey（各 76 项）；loader 混装和 Schemastery codec 两种启动失败均消除。修复后 rc.1 的完整 enforce 验收为 **968 通过 / 86 跳过**，compose / behavior / journey / packed 仍为 **52 / 136 / 76 / 135 通过**；新增选择器回归另行通过，文档检查仍为 0 错误 / 0 警告。

原有版本本机回归明细（测试列为关键测试的通过 / 跳过；journey 为通过 / 失败 / 跳过）：

| DSH | Node | 关键测试 | web/headless journey |
| --- | --- | --- | --- |
| `0.1.5-rc.2` | `22.23.1` | 199 / 13 | 76 / 0 / 0 |
| `0.1.6-alpha.1` | `22.23.1` | 199 / 13 | 76 / 0 / 0 |
| `0.1.6-alpha.2` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.1.7-alpha.1` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.1.7-alpha.2` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.1.7-rc.1` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.1.7-rc.2` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.0-rc.1` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.0-rc.2` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.1-alpha.1` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.1-alpha.2` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.1-alpha.3` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.1-alpha.4` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.1-alpha.5` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.1-rc.1` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.1-rc.2` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.1-rc.3` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.1-rc.4` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.1-rc.5` | `22.23.1` | 196 / 13 | 76 / 0 / 0 |
| `0.2.2-alpha.2` | `24.18.0` | 200 / 9 | 76 / 0 / 0 |
| `0.2.2-alpha.3` | `24.18.0` | 208 / 1 | 76 / 0 / 0 |

代码提交 `0ffb3e6` 的 [CI run 41960785058](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/41960785058) 已重新覆盖旧版 vendor 修复。经 PR #35 合入 `main`（`1c025b2`），最终 [CI run 41964828437](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/41964828437) 全绿；本批随 `v0.1.14` 发版。


### Windows PID 握手竞态修复（2026-11-05）

最终验收提交 `613223d` 的 [CI run 41961801526](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/41961801526) 完成 88 个 verify：87 成功，仅 `0.1.6-alpha.1 × windows-latest` 的 `ancestor guard` 后代回收测试失败（最终 gate 随之失败）；rc.1 四个 runner 全部成功。

失败诊断为 `Job descendant 0 outlived the drained runner`。夹具只等 PID 文件存在，可能在 `writeFileSync` 创建文件后、写入 PID 前读到空串；`Number('') === 0` 且 `Number.isInteger(0)` 为真，后续 signal-0 探针检查的是特殊 PID 0，而非真正的后代。跨平台回归以已创建的空文件确定复现旧逻辑误判（修复前红）。现将 PID 标记写入临时文件后原子 rename 发布，消费者等待完整的正安全整数 PID，缺失 / 空白 / 0 / 负数 / 非整数字节均不算 ready。原生 Job drain、后代已退出、延迟逃逸写入不存在、祖先 pin 释放的断言和时限保持不变；未修改产品运行时代码。本机回归修复后通过（1 通过 / 40 个 Windows 用例按平台跳过），lint、双端 typecheck、docs:check 均通过；修复随 PR #35 合入，其 [CI run 41964828437](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/41964828437) 在 `0.1.6-alpha.1 × windows-latest` 复跑通过。

## 插件详情页设置卡与富文本详情（2026-11-05）

经 PR #37 合入 `main`（`220bc82`），随 `v0.1.14` 发版。四项交付：

- **「多根 Auto Review」设置开关（实验性，默认关闭）**：插件详情页设置卡在「附属根 Skills」开关下方新增同名开关，与插件管理页同名 Loader 行等价——经 `remote.pluginManager.setPluginEnabled` 持久化 `{id, disabled}` 覆盖并热应用，`restart-required` 时以 Toast 提示重启；宿主无 `pluginManager` Remote 或组合未列该可选行时该行不渲染；Skills 与 Auto Review 共用单一 `plugins.bundle.config` 设置单元格，legacy `settings.plugin.item` 保留 Skills 行。
- **设置卡错误反馈改 Toast 横幅**：Auto Review 与 Skills 设置行的内联 `role=alert` 文案改为顶部 Toast——写入结果（保存失败/需重启）与读取失败、条目诊断均以横幅提示，状态源消失时自动撤下。
- **并发刷新竞态修复（评审 P2）**：`AutoReviewSettingsClient.refresh()` 的 epoch 只在 attach/detach 时变化，无法区分同 epoch 内重叠请求；`plugin-manager/changed` 刷新与 `setEnabled()` 后刷新并发时旧响应后到会覆盖新快照、开关停留在写入前的值。新增 `refreshSeq` 代际计数，非最新 `listPlugins()` 响应直接丢弃。
- **插件管理页富文本详情**：`locale/en|zh.json` 提供 `meta.title`/`description`/`detail`，`exports` 暴露 `./locale/*.json`，`files` 打包 `detail/` 与 `locale/`；DETAIL 文档遵循上游惯例——单行图片指向 640×300 自包含 `preview.svg`（`preview.zh.svg` 为中文版，文字经 fontkit 转曲）。`check-pack` 支持 exports 通配符目标，`plugin-detail` spec 固定 manifest/字典/文档/资产一致性契约。富文本详情在 DSH `0.2.2-alpha.2` 起生效，更早版本无此读取路径，locale/detail 文件为惰性资源无副作用。

验收：PR [CI run 41992772063](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/41992772063) 全绿；新增 `tests/client-auto-review-settings.spec.tsx`（开关持久化/热应用/restart-required/无 Remote 不渲染/并发刷新）与 `tests/plugin-detail.spec.ts`（manifest/字典/文档/资产契约）。

## PR #39 Review P2：Follower 在解析前拒绝 Windows 网络路径（2026-11-06）

[评审发现](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/39#discussion_r4482517586)已修复：follower 的候选预检补齐 owner 已有的 Windows 网络／设备路径词法拒绝，合同见 [ADR-0027 修订](../../decisions/ADR-0027-revive-target-and-protected-paths.md#修订follower-候选解析前拒绝-windows-网络与设备路径2026-11-06pr-39-评审)。`registry.spec.ts` 在真实 owner/follower 栈上覆盖 UNC 两种分隔符与设备路径，断言 `unsupported-path`、候选未被 `realpath` 解析、follower 未转发 `add`、存储不变；测试桩拦截危险候选，回归失败时也不实际访问网络。修复前 owner 通过、follower 因候选被解析而失败，修复后两者通过。

macOS / Node `24.18.0` / DSH `0.2.2-rc.1`：`compat:check` 与完整 `verify:all` 通过，Seatbelt 探针可用并以 `DSH_PROBE_VERIFIED_DIALECTS=seatbelt` 要求实跑；全量测试 **1020 通过 / 86 平台跳过**，compose / behavior / journey 分别 **52 / 137 / 76 通过**，packed behavior **136 通过**，均无失败或跳过。lint、双端 typecheck、build、pack 与 Auto Review fork 检查通过；可选 Auto Review 集成按精确版本规则跳过。Windows 路径分支在本机通过平台桩覆盖，不代替 Windows 原生 CI；未扩大支持集合、未发布。


## OPS P5 本仓兜底验证（2026-11-05）

按用户直接授权完成不依赖 OPS 修改的 P5 安全拒绝子集；允许误拒，不允许借恢复可用性扩大写范围。范围与决策见 [ADR-0029 P5 修订](../../decisions/ADR-0029-ops-file-authorization-and-activity-adapter.md#p5-本仓保守兜底修订2026-11-05直接授权实施)及[专项计划](../completed/2026-11-01-ops-compatibility-adaptation.md#p5-本仓交付范围)。不开发布、不改 allowlist，不将全计划或 P6 标完成。

- 基线：MR 从 `56c1909` 开发；OPS `2c0b0397ce4b48436ff76cf5c5b039054240a45c` / `0.5.0-alpha3` 原样副本，Rust release Worker 本机编译。隔离组合为 DSH `0.2.0-rc.2` / cordis `4.0.4`，与 OPS peer 范围相容；本仓开发依赖仍为 DSH `0.2.2-rc.1` / cordis `4.1.0`，未拿它冒充 OPS 支持宿主。Node `24.18.0`，macOS arm64；没有运行 Linux/Windows 验证。
- 真实 OPS 组合：`node --experimental-transform-types scripts/verify-ops-protection.mjs <isolated-host>` **76/76 PASS**。shared / legacy × FA / WW / RO，真实 Native 写入/新建/edit/replace/copy/双向 move/remove/符号链接路径，RO 文件 SHA256 与目录内容不变，失败 move 的可写源仍保留。FA Native 读取与主根合法写入为正对照，每个 shared/legacy FA 车道均实际启动 13 个进程，逐次保存 argv。
- PTC：shared 三模式及 legacy FA 真实 run_code 子 dispatch 触达 OPS 并被拒写；legacy WW/RO 在代码进程启动前被 scope spawn guard 拒绝（每车道 0 次启动），**不是子 dispatch 端到端通过**。该误拒作为本次安全退路保留。
- maintenance：shared/legacy FA 均触发真实 OPS Session 清理 purge；缺少独立授权时拒绝启动，启动数不增加、RO 文件不变。单独卸载 fence 后 scope guard 仍拒绝无来源启动。缓存可能残留，不声明合法清理已恢复。
- 持久活动：Phase B **未启用**。当前 DSH Session 文档明文禁止外部插件调用其实验记录 API；早期无 API 的车道同样不适用。不私写日志，恢复后缺证的 Review 继续技术失败。D3/F07 与合法后台恢复仍依赖上游公开合同；未提交无消费者的授权 provider。
- 证据交付：`docs/reviews/` 只纳入 `dsh-ops-compatibility-audit.md`；原始 JSON/日志/临时脚本保留本地，不纳入 Git。可复跑程序在 `scripts/`，其输出包含宿主、源码与 Worker 摘要，文件树和进程 argv 留在隔离宿主目录。
- 仓库门禁：`compat:check`、lint、typecheck、build、`docs:check`、`auto-review:fork` 通过；macOS Seatbelt probe 实际启动成功。完整测试 **1101 passed / 87 skipped**（78 个文件通过、3 个按平台跳过）；compose **54/54**、behavior **136/136**、journey **76/76**；`pack:check` 通过，`smoke:packed` 的行为检查 **135/135**，无 kernel skip。Auto Review 精确 `0.2.1-rc.2` 实现套件未在本轮重跑，未把开发 pin 的跳过记成通过。

该次 macOS 运行未验证其他平台；Windows 与 Linux 的后续补验见下文。


### OPS 分支 rebase 与实验性标签（2026-11-05）

OPS 分支已 rebase 到 `main` HEAD `a7a85b4`（含 `v0.1.14` 及 `/add-dirs`）。设置卡冲突合并保留 Skills、Auto Review、OPS 三行，仍只注册一个 bundle 卡片，三种开关分别走各自写路径；OPS 安全执行代码与 rebase 前一致。新增三开关同时渲染与写入隔离回归。OPS 标题的“实验性”括号文字改为与 Auto Review 相同的宿主 `Tag tone="info"`，复用 `mrfw-settingsTitleRow`，中英文标签独立呈现；配置字段原有 experimental 标记及默认关闭保持不变。

rebase 后完整 macOS 测试 **1127 passed / 87 skipped**；compat、lint、typecheck、build、docs 检查通过，Seatbelt probe 成功，compose **54/54**、behavior **137/137**、journey **76/76** 以及 pack/packed 通过。标签改动另复核客户端设置卡与打包构建；未新增平台验证，`docs/reviews/` 仍只跟踪原审计 Markdown。

### Windows P5 补验（2026-11-05）

按用户要求完成 **P5 本仓保守兜底的 Windows 验证**，不改变生产保护策略，不代表 Windows 受保护 Worker 准备、完整 OPS 兼容或全计划退出。专项计划仍在 active，ADR-0029 保持 Proposed。

- **基线**：MR `913d168` 加本次验证脚本/测试修订；Windows `10.0.26200` x64、Node `24.14.0`，非打包便携 pwsh。隔离宿主统一 DSH `0.2.0-rc.2` / cordis `4.0.4`，运行时门禁通过；主工作树仍为 DSH `0.2.2-rc.1` / cordis `4.1.0`。OPS 原样检出 `2c0b0397ce4b48436ff76cf5c5b039054240a45c` / `0.5.0-alpha3`，公开构建通过且工作树干净；Windows Worker 取同版本官方 Release 包，tarball SHA256 与 `SHA256SUMS` 一致（`bed2baee8d277050095d6ea4d79056ccdb5d8cda22b16602f33dc0a16ea5dadb`），staged provenance 校验通过，Worker SHA256 为 `44da3344a980db0e973fe81848448797c9e67e1759c33dd84ddf67971aedaaba`。未改 OPS 源码、本仓 pin、allowlist 或真实用户 profile。
- **组合验证**：扩展后的 `scripts/verify-ops-protection.mjs` **104/104 PASS**，shared / legacy × FA / WW / RO。Windows 在 deny 存在时早拒真实 Native 覆盖写、新建、edit、replace、copy、双向 move、remove 及 junction 别名写；逐次断言零 Worker 启动、零新增 cache confine、隔离 DSH_HOME 与业务树内容不变、失败 move 不移除可写源。三个模式另通过真实后台 Bash、Registry 卸载失权、系统 temp 根重叠的早拒检查；单独卸载 fence 后 scope 仍拒绝无来源 spawn。无 deny 正对照在六条车道真实读取成功，FA/WW 四条车道真实新建文件成功，证明未以坏 Worker 或整体不可启动制造拒绝。
- **PTC 边界**：shared 三模式与 legacy FA 均真实启动 `run_code` 并触达 OPS 子 dispatch，内层拒写且 RO SHA256 不变；legacy WW/RO 在代码进程启动前被 scope guard 拒绝，仍不计作子 dispatch 端到端通过。
- **maintenance 边界**：legacy FA 由真实 Session disposed 触发 purge，scope guard 拒绝其无来源 spawn，进程启动数不增加。shared FA 的真实 cache 准备 profile 没有 `--temp-write-sid`，OPS 未形成私有结果缓存位置，因此未注册 purge；该车道的 purge **不适用，未声称已触发或恢复清理**。合法后台/maintenance 和受保护 Windows Worker 准备仍依赖上游公开接缝，缓存残留边界保留。
- **回归修订**：原 `tests/ops-compat.spec.ts` 中 35 个 POSIX profile/准备生命周期用例在 Windows 错把早拒当失败（含等待不存在的 prepare 导致超时）。将这些用例明确限定到 POSIX，并新增 9 个 Windows 用例：两种 Registry × 三模式遍历全部 OPS 执行能力、两种加载顺序的 Bash/未知工具、工具 cap 与未封顶 sibling 对照。其余跨平台生命周期与 scope guard 回归继续执行，未修改生产实现。
- **仓库门禁**：完整 Windows 测试 **1119 passed / 104 skipped**（82 个文件通过、1 个跳过；104 包含上述 35 个 POSIX 用例及原有平台/基线跳过），无失败。`compat:check`、lint、typecheck、build、`docs:check`、`auto-review:fork` 通过；真实 `windows-acl` kernel probe 成功（工作区可写、兄弟目录拒写），后续测试使用 `DSH_PROBE_VERIFIED_DIALECTS=windows-acl`。compose **54/54**、behavior **144/144**、journey **76/76**，`pack:check` 与 `smoke:packed` 通过，安装副本行为 **143/143**，三个 smoke 与 packed 均无 skip。未重跑 Auto Review 精确 `0.2.1-rc.2` 套件，不将其开发 pin 跳过记为通过。
- **本地证据**：隔离宿主与输出位于忽略的 `.dsh-smoke/ops-p5-windows/`，`p5-results.json` 保留提交、精确依赖树、锁摘要、Worker/源码摘要、业务夹具路径、准备 profile、argv、拒绝结果和各入口边界；`test.log`、各 smoke 日志及 `gates.json` 保留门禁结果。不纳入 Git，也不把本次 Windows 证据外推到 Linux。

### Linux P5 补验（2026-11-05）

按用户要求完成 **P5 本仓保守兜底的 Linux 验证**。本轮只扩展验证脚本、修正测试夹具及更新文档，生产保护策略未改；D3、F07、Phase B 和合法后台/maintenance 的上游依赖仍保留，专项计划仍在 active，ADR-0029 保持 Proposed。

- **基线**：MR `a2f6b20` 加本次验证修订；Ubuntu `24.04.4` / WSL2 Linux `6.6.87.2-microsoft-standard-WSL2` x64，Node `24.13.0`。隔离宿主统一 DSH `0.2.0-rc.2` / cordis `4.0.4`，锁文件中 268 个 DSH 条目均为该精确版本，每个组合的运行时兼容门禁均通过；主工作树仍为 DSH `0.2.2-rc.1` / cordis `4.1.0`。旧版 npm 可选 peer 求解失败后，显式固定 OPS 锁文件中的 DSH 包并用 `--legacy-peer-deps` 安装隔离宿主，未使用 warn 门禁。OPS 原样检出 `2c0b0397ce4b48436ff76cf5c5b039054240a45c` / `0.5.0-alpha3`，工作树干净，公开 JS build 通过。官方包只携带 Windows Worker，因此以隔离 Rust `1.88.0` 按 `native/Cargo.lock` 执行 `cargo build --release --locked`，公开 stage 校验 Linux x64 ELF/provenance 通过；Worker SHA256 为 `a569b3e11af5e612410fb9bbf66f749e390d3d3da1e6c3b0a794b5526dce2ecd`。未改 OPS 源码、本仓 pin、allowlist 或真实用户 profile。
- **组合验证**：`scripts/verify-ops-protection.mjs <host> bwrap` 与 `<host> landlock` 各 **94/94 PASS**，均覆盖 shared / legacy × FA / WW / RO。FA 真实 Worker 拒绝覆盖写、新建、edit、replace、copy、双向 move、remove 及符号链接别名写；RO 文件 SHA256 与目录内容不变，失败 move 保留可写源。新增真实工具 cap 拒写 RW 根、未封顶 `ops_copy` 成功写入 RW 根、普通 `/tmp` 兄弟根到达受限 Worker 后拒写的对照；FA 读取及主根合法写入成功，每个 shared/legacy FA 组合实际启动 16 个进程并保存 argv。WW/RO 有 deny 时拒绝 Native 执行及读取，断言零 Worker、零新增 cache confine、隔离 DSH_HOME 与业务树不变。三个模式均通过 Registry 卸载失权及系统 temp 根重叠的准备前早拒；单独卸载 fence 后 scope 继续拒绝无来源 spawn。
- **实际 runner 与 PTC**：参数选择的是上游探测链。FA ambient-minus-deny 无法由 Landlock 表达，两次运行的 FA Worker 均按既有设计实际使用 bwrap，不声称纯 Landlock 提供该保护。shared WW/RO 的 `run_code` 外层分别真实使用 bwrap、Landlock；shared 三模式及 legacy FA 均触达 OPS 子 dispatch，内层拒写且 RO SHA256 不变。legacy WW/RO 均在代码进程启动前被 scope guard 拒绝（零启动），不计作子 dispatch 端到端通过。
- **maintenance 与未覆盖能力**：两次运行的 shared/legacy FA 都由真实 Session disposed 触发 purge，scope guard 拒绝无来源启动，进程数不增加、RO 文件不变，缓存可能残留。Linux 未发布 OPS Bash，真实后台 Bash 不适用；F07 的 WW batch/result 后置 cache bind 可用性和新的公开授权桥未在本轮恢复或验收，不以安全拒绝替代完整兼容结论。未重跑 Auto Review 精确 `0.2.1-rc.2` 实现套件。
- **回归修订**：scope 重挂载会连带重建 sandbox provider，原用例仍假定重挂载前强制的 Seatbelt fixture 存活，在 Linux 错拿原生 bwrap argv 对比 Seatbelt 文本。现在在新 provider 上重新设置同一结构夹具，保留原有重挂载生命周期与拒写 profile 断言；真实 Linux runner 由组合程序和内核回归独立验证。
- **仓库门禁**：完整测试 **1137 passed / 86 skipped**（81 个文件通过、2 个跳过），无失败；`compat:check`、lint、typecheck、build、`docs:check`、`auto-review:fork` 通过。`registry:probe --required` 确认原生 peer 认证可用；`kernel:probe` 确认 bwrap / Landlock 均可实际执行，测试及冒烟使用 `DSH_PROBE_VERIFIED_DIALECTS=bwrap,landlock`。compose **54/54**、behavior **137/137**、journey **76/76**，`pack:check`（176 个成员）与 `smoke:packed` 通过，安装副本行为 **136/136**，三个 smoke 与 packed 均无 skip。journey 使用此前隔离安装的 Git `2.48.1`，未更改系统 Git。
- **本地证据**：忽略的 `.dsh-smoke/ops-p5-linux/` 保存隔离宿主、npm 锁、OPS 原样检出、Rust 工具链、Worker 与 provenance；`p5-results-bwrap.json` / `p5-results-landlock.json` 保存提交、源码/锁/Worker 摘要、每次 argv、准备 profile、业务夹具、cap/正对照结果及 PTC/maintenance 边界，普通 tmp 兄弟根夹具路径也在结果中。原始日志与 JSON 留本地，不纳入 Git；可复跑程序及参数说明见[专项计划](../completed/2026-11-01-ops-compatibility-adaptation.md#p5-本仓交付范围)。


### Windows/Linux 提交接入后的 macOS 回归（2026-11-05）

快进接入 Windows `a2f6b20` 与 Linux `8b633eb` 后复核：两次提交仅修改验证脚本、测试夹具与文档，`src/` 生产保护代码相对 `913d168` 无差异。macOS arm64 / Node `24.18.0` 回跑共享脚本，发现两处新增临时目录记录查找直接比较原始路径：macOS `tmpdir()` 的 `/var/...` 与 Registry 的 `/private/var/...` 是同一路径，导致两个 tmp-sibling 和六个 tmp-overlap 检查失败（86 通过 / 8 失败）；其中未找到 sibling 记录还使该登记未被移除，连带让后续注册 temp 根因包含关系被拒。修复仅将验证脚本的查找目标先经 `realpathSync.native()` 规范化，Windows 保留大小写归一，POSIX 按原大小写比较；不放宽任何业务拒写或 Registry 边界。

干净隔离宿主固定 DSH `0.2.0-rc.2` / cordis `4.0.4`（npm lock 中 278 个 DSH 条目同版本），补齐运行时 peer；OPS 原样 `2c0b0397ce4b48436ff76cf5c5b039054240a45c` / `0.5.0-alpha3`，检出干净，使用此前按其 Cargo.lock 本机构建的同一 macOS Worker，未修改 OPS。修复后真实组合 **94/94 PASS**：shared/legacy × 三模式；FA 每个组合实际启动 16 个进程，cap 拒写、未封顶 RW 正对照、普通 tmp 兄弟根到达受限 Worker 拒写及 temp 重叠准备前拒绝均通过。shared 三模式和 legacy FA 到达真实 PTC 子 dispatch；legacy WW/RO 仍启动前拒绝；shared/legacy FA 的真实 purge 均被拒。已有误拒、缓存残留、D3/F07/Phase B/合法后台与全计划/P6 边界不变。

仓库检查：完整 macOS 测试 **1127 passed / 96 skipped**（新增九个 Windows 专属用例按平台跳过），compat、lint、typecheck、build、docs、Auto Review fork 通过；Seatbelt probe 成功，compose **54/54**、behavior **137/137**、journey **76/76**、pack 与 packed behavior **136/136** 通过，冒烟无跳过。未在本机重跑 Windows/Linux 或 Auto Review 精确基线套件；跨平台原始证据仍留在各设备。macOS 本轮结果与日志保存在忽略的 `.dsh-smoke/ops-p5-macos-followup/`，未提交；`docs/reviews/` 仍只跟踪现有审计 Markdown。


## OPS P6 最终验收（2026-11-05）

**结论：按用户明确缩小后的范围，实验性保守兜底的 P0–P6 与最终验收完成。** P5 尚未实现的功能及全功能 OPS 兼容验收无限期延后，不作为本次退出条件，也不标为通过。唯一延后清单和未来仅实验性开放的约束见 [ADR-0029 最终范围](../../decisions/ADR-0029-ops-file-authorization-and-activity-adapter.md#最终范围与无限期延后2026-11-05)。专项计划移至 [completed](../completed/2026-11-01-ops-compatibility-adaptation.md)；不修改 OPS、不提升支持版本、不创建发布或 tag。

### 已交付范围与平台证据汇总

下表汇总本节之前的独立平台运行，不将 Windows/Linux 历史证据写成本轮 macOS 执行。组合均为 DSH `0.2.0-rc.2` / cordis `4.0.4` 与原样 OPS `0.5.0-alpha3`（`2c0b0397ce4b48436ff76cf5c5b039054240a45c`），涵盖 shared/legacy × FA/WW/RO。

| 平台与证据来源 | 组合结果 | 实际执行边界 |
| --- | --- | --- |
| macOS arm64；`22920a9` 共享脚本修正后的回跑 | 94/94 PASS | FA 有 deny 的真实 Worker 由 Seatbelt 拒写；WW/RO 有 deny 准备前拒绝。cap 拒写与未封顶 RW/主根合法写入有正对照，普通 tmp 兄弟根拒写、temp 重叠早拒 |
| Windows x64；`a2f6b20` | 104/104 PASS | 三模式有 deny 均在准备前拒绝，零 Worker/新增 cache confine；无 deny 真实读取及 FA/WW 写入有正对照，不能声明受保护 Worker 可用 |
| Linux x64；`8b633eb` | bwrap 与 Landlock 探测链各 94/94 PASS | FA 两次均实际使用 bwrap；shared WW/RO 的外层 PTC 分别实际使用 bwrap/Landlock。不能把探测参数写成 FA 的实际 runner |

三平台均验证了失权拒绝、tool cap、单独卸载 fence 后 scope guard 继续拒绝无来源启动。shared 三模式及 legacy FA 的真实 PTC 子调用触达 OPS 后拒写；legacy WW/RO 在代码进程启动前拒绝，不计为子 dispatch 端到端成功。macOS/Linux shared/legacy FA 及 Windows legacy FA 的真实 purge 被拒；Windows shared FA 未注册 purge，记为不适用。缓存残留、误拒与合法后台未恢复继续披露。Linux 未发布 OPS Bash，不将其记作后台 Bash 通过。

### 本轮补齐的实时活动与精确 Review 验证

新增可复跑 `scripts/verify-ops-activity.mjs <isolated-host> <new-output.json>`（Node `--experimental-transform-types`；宿主准备方式同 `verify-ops-protection.mjs`，本脚本只验 macOS）。显式启用设置并确认 mode token，通过真实 AgentLoop、原样 OPS Worker、真实 PTC 子 dispatch，检查工具完成后的下一次实际模型请求：inspect 的完整祖先指令链；read_files 三项中两项成功的两条指令链且排除失败目录；PTC 内两个成功目标的指令链。DSH `0.2.0-rc.2` 与 `0.2.1-rc.2` 各 **3/3 PASS**，每宿主六次模型请求，所有实际 spawn 均带 Seatbelt write-deny。模型响应由脚本控制，验收的是实际调用链和消息内容，不是外部模型质量；本轮未在 Windows/Linux 重跑 live AgentLoop。

Auto Review 独立宿主固定其精确基线 DSH `0.2.1-rc.2` / cordis `4.0.5`，未使用主开发 pin 替代。兼容门禁、host/client/fork 类型检查、build、fork 校验与 **91/91 实现测试**通过。补充了真实 reviewer 接收所有静态 OPS 目标指令链、历史 OPS 缺实时证据在模型请求和写入前技术失败的回归，并使动态目标测试显式启用 mode、断言准确拒绝原因。该静态测试用合成工具隔离 Review 参数传递，真实 OPS Worker 由前述 live 组合独立验证。

`verify-auto-review.mjs` 完成源码/打包 × Web/Headless × 两种 bundle 加载顺序的 **8 个组合**，每个组合两次 reviewer/dispatch（合计 16 次），含默认关闭、显式启用、关闭/重启用排空恢复以及真实原生 RO 拒写。Review 接受业务调用不赋予越过原生 fence 的权限。以上不等于支持新版 Auto Review，也不等于恢复 Phase B。

### P6 验收处置

| 检查范围 | 结果与限制 |
| --- | --- |
| shared/legacy、三模式、cap、失权及生命周期 | 已有真实组合与回归通过；早拒如实记录，原生 fs/shell/PTC/PTY 边界继续有效 |
| 无 OPS、空 scope、可选 peer 与原生消费者 | 主基线完整回归及源码/打包冒烟覆盖；不添加运行时必需依赖，不改变原生授权合同 |
| 活动与 Review | 静态成功目标可达实际模型请求/reviewer；动态目标、恢复历史缺证和快照失效继续技术失败 |
| 开放方式 | OPS 与 Auto Review 开关独立；OPS 默认 false，显式 true，配置 experimental 标记和双语独立“实验性”Tag 保留 |
| 未交付能力 | ADR-0029 清单全部无限期延后、排除验收；不以误拒代替可用性通过，不设自动恢复触发条件 |
| 文档与交付 | 专项计划归档，ADR 仅有限范围 Accepted，双语入口同步；无发布、无 tag、无 OPS/版本支持变更 |

**本轮最终门禁**：macOS arm64 / Node `24.18.0`，主开发树 DSH `0.2.2-rc.1` / cordis `4.1.0`。`compat:check`、lint、host/client/fork typecheck、build、`docs:check`、`auto-review:fork` 全部通过；原生 `registry:probe --required` peer 认证可用，Seatbelt `kernel:probe` 实际执行成功。完整回归 **1127 passed / 96 skipped / 0 failed**；compose **54/54**、behavior **137/137**、journey **76/76**、`pack:check`（176 个成员）及 packed behavior **136/136** 均通过，三个 smoke 与 packed 无 skip。96 个回归跳过包含 Windows 专属与不适用精确基线的项目，Auto Review 实现另在正确基线以 91/91 取证，不把主开发树跳过当作通过。lint 扫到本地未跟踪历史证据脚本的既有 unused-vars 告警，无报错；仅导出暂存的交付文件后，直接运行同一 oxlint 与文档检查程序均通过；没有依赖本地未跟踪的证据目录补齐链接。

**本地证据**：忽略的 `.dsh-smoke/ops-p6/` 保存本轮门禁日志、精确 Review 套件/类型/冒烟输出，以及两个 live 宿主的 `activity-rc0.json` / `activity-rc1.json`（版本、OPS commit/工作树、Worker/源码 SHA256、完整请求、结果与 argv）。隔离安装树留在本机临时目录，Windows/Linux 原始证据仍各留原设备；所有原始日志、JSON 和目录均不提交。`docs/reviews/` 只跟踪现有审计 Markdown。本轮生产 `src/`、pin、peer、allowlist 与 lockfile 相对 `22920a9` 无差异；新增内容仅为验收脚本、Review 回归及文档。

## OPS 启用版本范围收窄（2026-11-06）

按维护者要求，功能开放范围收窄到 DSH `0.2.*`；策略与 Settings/UI 合同的唯一来源见 [ADR-0029 版本范围修订](../../decisions/ADR-0029-ops-file-authorization-and-activity-adapter.md#ops-版本范围修订2026-11-06)。不修改精确支持列表、开发 pin、peer 或锁文件，不构成发布或稳定支持提升。

本机 macOS arm64 / Node `24.18.0`，开发树 DSH `0.2.2-rc.1` / cordis `4.1.0`：compat、lint、host/client 类型、build、`docs:check` 和 fork 校验通过；原生 Registry peer 认证及 Seatbelt 探针通过。完整测试 **1165 passed / 95 skipped / 0 failed**（80 个文件通过、3 个按平台跳过）。compose **54/54**、behavior **137/137**、journey **76/76**、`pack:check`（178 个成员）及 packed behavior **136/136** 通过，三个 smoke 与 packed 无跳过。lint 仍有本地未跟踪审计证据脚本的既有 unused-vars 告警，无错误。

隔离安装树使用 Node `22.23.1`，没有从主工作树回退解析依赖；权限夹具仍放在自动 temp grant 之外。以下四个精确版本的 compat 和类型检查均通过：

| DSH | Settings 定向结果 | 最终 OPS/Skills 客户端回归 |
| --- | --- | --- |
| `0.1.6-alpha.2` | 14 通过；真实现代 Loader 用例因接口不存在跳过，强制关闭及不注册旧 Settings section 通过 | 18/18 |
| `0.1.7-rc.2` | 15/15；真实现代 Settings 不发布 OPS namespace，配置显式 true 仍关闭 | 18/18 |
| `0.2.0-rc.2` | 15/15；真实 Settings 修改与重启持久化通过 | 18/18 |
| `0.2.1-rc.2` | 15/15；真实 Settings 修改与重启持久化通过 | 18/18 |

四版另跑适用的 OPS 执行/活动、Skills Settings、Registry lease 和跨进程回归；旧版不执行仅适用于 `0.2.*` 的 OPS 启用路径。删除旧 Settings 分支同时移除了 scope → ops-settings → skills 的运行时导入链；Node 22 直接导入 scope 成功，Registry 子进程不再因 Skills 文件的 `using` 语法在启动前失败。未通过更改 CI Node 版本或放宽门禁掩盖该问题。

Auto Review 另在精确 DSH `0.2.1-rc.2` / cordis `4.0.5` 上通过联合类型检查、**91/91** 实现测试，以及源码/单一 tarball 的 web/headless × 官方前后顺序真实审查冒烟，保留默认关闭、live toggle、reload、owner drain 和恢复检查。本轮未在 Windows/Linux 重跑，也未重新触发远端 CI；隔离树和原始日志留本地，不提交 `docs/reviews/` 的证据目录。


## OPS UI 开启前风险确认（2026-11-06）

本次交互合同见 [ADR-0029 UI 启用前风险确认](../../decisions/ADR-0029-ops-file-authorization-and-activity-adapter.md#ui-启用前风险确认2026-11-06)。设置卡复用宿主官方 `RiskConfirmation`，确认前不发送开启写入；保存仍走同一个 Settings form 与 revision，不增加持久数据或授权来源。

macOS arm64 / Node `24.18.0` / DSH `0.2.2-rc.1`：compat、lint、host/client 类型、build、原生 Registry/Seatbelt 探针、fork 校验及 `docs:check` 通过。完整测试 **1178 passed / 95 skipped / 0 failed**；compose **54/54**、behavior **137/137**、journey **76/76**、`pack:check`（179 个成员）及 packed behavior **136/136** 通过，三个 smoke 与 packed 无跳过。lint 只有本地未跟踪历史证据脚本的既有 unused-vars 告警。

隔离 DSH `0.1.6-alpha.2`、`0.2.0-rc.2`、`0.2.1-rc.2` 的类型检查与最终 OPS/Skills 客户端、双语字典回归均通过（每版 **37/37**，测试使用 Node `22.23.1`）。`0.2.1-rc.2` 的类型步骤包含精确 Auto Review 实现检查；本次未重跑其 91 项宿主实现测试，因为宿主和 Review 实现未改动。官方组件按导出结构探测，缺失时不能跳过警告直接开启；旧版类型树仍能编译。

真实 DSH Web 使用独立临时 profile，通过 Playwright 验证官方组件：确认前 switch 未开启且确认按钮 disabled；Esc 取消后仍关闭；重新打开需要重新勾选；确认后 Settings 才持久化 true；关闭操作直接恢复默认 false。桌面 1280×720 与窄屏 390×844 截图检查通过。JSDOM 另覆盖取消按钮、关闭按钮、遮罩、双语文案、保存失败，以及 revision/表单/可写性/可用性/外部启用变化时废弃旧确认。截图与浏览器记录只留忽略目录，测试浏览器与隔离 Host 已关闭。

本轮未在 Windows/Linux 实跑浏览器，不改变宿主兼容列表、OPS 功能范围或此前无限期延期决定；不把 UI 二次确认当作配置文件或 RPC 的独立授权通道。

## v0.1.15 发版验收（2026-11-06）

本次按“文档准备提交 → 仅版本号的正式提交 → 正式提交上的 annotated tag”发版。内容归 CHANGELOG 双语对；支持合同仍为 22 个精确 DSH 版本，开发 pin `0.2.2-rc.1` / cordis `4.1.0`，Auto Review 基线仍为 `0.2.1-rc.2`。

合入后的 [PR #39 main CI](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/42165203436) 与 [PR #40 main CI](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/42183917954) 均为 success，覆盖支持版本与已启用的原生平台矩阵。根授权计划按维护者限定范围归档至 completed；BYP-01、F5 与 F4 执行侧等排除项不计为已修复，OPS 完整兼容恢复继续无限期延后。

发版前在 macOS arm64 / Node `24.18.0` / pnpm `11.25.0` 重跑 `compat:check`、lint、双端类型检查、build、原生 `registry:probe --required`、Seatbelt `kernel:probe`、完整测试、三个 smoke、`pack:check`、`smoke:packed`、`auto-review:fork` 和 `docs:check`，均通过。探针确认 `seatbelt` 后显式传入 `DSH_PROBE_VERIFIED_DIALECTS=seatbelt`，要求相关内核断言实跑。完整回归 **1178 passed / 95 skipped / 0 failed**；compose **54/54**、behavior **137/137**、journey **76/76** 与 packed behavior **136/136**，三个 smoke 与 packed 无跳过；可选 `smoke:auto-review` 在当前开发 pin 按精确版本规则跳过，不能计作本轮 Auto Review 集成通过，其独立基线证据见上方 OPS P6 与后续记录。本地日志仅存于忽略的 `.dsh-smoke/release-v0.1.15/`，不随发布提交。

## v0.1.16 发版验收（2026-11-08）

本次按“文档准备提交 → 仅版本号的正式提交 → 正式提交上的 annotated tag”发版。内容归 CHANGELOG 双语对；支持合同仍为 22 个精确 DSH 版本，开发 pin `0.2.2-rc.1` / cordis `4.1.0`，Auto Review 基线仍为 `0.2.1-rc.2`。本版由三笔合入构成：PR #41（准入外受限 spawn 修复与 ADR-0035）、PR #42（面板 `session-not-live` 细分与 ADR-0008 修订）、PR #43（预览页 Folder 导航树附加根接管）。

发版前在 macOS arm64 / Node `24.18.0` / pnpm `11.25.0` 重跑 `compat:check`、lint、双端类型检查、build、原生 `kernel:probe`、`registry:probe --required`、完整测试、三个 smoke、`pack:check`、`smoke:packed`、`auto-review:fork`、`smoke:auto-review` 和 `docs:check`，均通过。探针确认本机可用方言为 `seatbelt`，并以 `DSH_PROBE_VERIFIED_DIALECTS=seatbelt` 要求内核断言实跑；`registry:probe --required` 确认共享 IPC 可以实跑。完整回归 **1221 passed / 95 skipped / 0 failed**（81 个文件通过、3 个文件整体跳过）；compose **54/54**、behavior **137/137**、journey **76/76** 与 packed behavior **136/136**，三个 smoke 与 packed 无跳过；`pack:check` 校验 **186** 个成员；可选 `smoke:auto-review` 按精确版本规则跳过，不能计作本轮 Auto Review 集成通过。

首次运行位于 DSH 工具沙箱内时，嵌套 `sandbox-exec` 与共享 Registry 的 follower/IPC 用例被外层沙箱拒绝（探针报告 `sandbox_apply: Operation not permitted`），上述结果来自随后在完整本机权限下的重跑；两类失败均非本版代码回归。Linux/Windows 原生矩阵由 tag 触发的 `release.yml` verify 覆盖，不在本机结论内。本地日志仅存于忽略的 `.dsh-smoke/release-v0.1.16/`，不随发布提交。

## 新会话 Hero 入口（2026-11-08）

状态：已完成并通过完整门禁，随 `v0.1.17` 发版；决策见 [ADR-0037](../../decisions/ADR-0037-conversation-hero-workspace-folders-entry.md)，实施记录见[计划](../completed/2026-11-08-workspace-folders-hero-entry.md)。侧栏 `Folders` 入口保留，退役不在本批次内。

范围：

- 不依赖 `@deepseek-ai/dsh-client-ui-conversation`：typecheck 矩阵的旧版本没有该 SlotMap 键，注册走窄结构接口（`inject` + `spec` + `register`），槽位声明不存在时直接返回空 disposer；未进入运行时依赖、`dsh.client.inject` 或 peer/optional 依赖。
- 新增 `src/client/HeroWorkspaceEntry.tsx`：icon + label 的 trigger，复用 `WorkspaceFoldersDialog`；无 chevron，`aria-haspopup="dialog"` 与 `aria-expanded`。
- `src/client/index.ts` 新增 `HERO_SLOT_ID = 'multi-root-folders.hero'`、`HERO_ORDER = 10` 与独立的 `ctx.slots.inject('conversation.hero.options', ...)`；occupant 使用槽属性 `sessionId` 并 memoize；`sidebar.footer.action` 注册与 occupant 未改。
- `src/client/styles.ts` 新增 `.mrfw-heroEntry*`：28px 高、`0 8px`、4px gap、`--dsw-radius-sm`、13px/20px/500、hover/展开 token、`max-width: min(100%, 240px)`；`@media (max-width: 560px)` 退化为 28×28 图标按钮。
- 测试：`tests/client-panel.spec.tsx` 的 harness 支持 `heroOptions`，覆盖注册、共存、旧运行时缺席、会话权威、无 chevron、StrictMode 重渲染不重发 `list`；`tests/client-styles.spec.ts` 覆盖几何、token、无字面颜色、560px 分支与禁止 chevron 规则。
- 文档：README 双语、guide 双语、requirements §9/已知限制、architecture Client 半部、ADR-0037、CHANGELOG `[Unreleased]`、兼容笔记 §13 均已同步。

验证（macOS arm64 / Node `24.18.0` / pnpm `11.25.0`，完整本机权限）：

- `pnpm typecheck`、`pnpm lint`、`pnpm build`、`pnpm compat:check`、`pnpm docs:check` 均通过；`pnpm install` 只把该包加到 importer 的 devDependencies，解析图未变。
- `pnpm test`：rebase 到 main 后 **1264 passed / 95 skipped / 0 failed**（83 个文件通过、3 个文件整体跳过；rebase 前 1235；图标修订后新增 fallback、右内缩、不独占、槽位缺席与真实 SlotRegistry probe 断言）。
- `pnpm verify:all`：通过。compose **54/54**、behavior **137/137**、journey **76/76**、packed behavior **136/136**；`pack:check` 校验 **184** 个成员；`auto-review:fork` 通过；`smoke:auto-review` 按精确版本规则跳过（可选集成基线仍为 `0.2.1-rc.2`）。
- 在 DSH 工具沙箱内直接跑完整套件时，共享 Registry 的 follower/IPC 用例以 `contended` 失败（`shared IPC refuses sandboxed peers`）；同一用例在未改动的 main 基线工作树上以相同形状失败，确认是环境限制而非本批次回归。上述数字来自完整本机权限下的重跑，与 `v0.1.16` 发版验收的处理方式一致。
- 文档对形态的承诺：与相邻 workspace / 模式选择器同几何、无 chevron、workspace tree 图标（旧运行时回退 folder）、`≤560px` 只显示图标、首条消息后 hero 行消失、旧运行时只有侧栏入口。
- 目检修订（2026-11-08）：真实 GUI 目检发现首版 `IconSettings` 语义不符；改为 `IconWorkspaceTreeOutlineRegular`，旧运行时经 `selectIconOr` 回退 `IconFolderOpen`；随后按右对齐行顺序把文字放左、icon 放右，并补 DOM 顺序断言；再按上游行 `0 16px 0 20px` 的不对称内边距补 `margin-right: 4px`，使按钮盒与工作区选择器同为 20px 内缩。样式测试钉住 4px 右内缩，并断言入口不 grow、不绝对定位、不占满宽度，不会独占 list 槽。首轮 PR CI 在 `0.2.1-alpha.3` 之前的 lane 因 SlotMap 无该键而 typecheck 失败，最终改为零 `ui-conversation` 依赖的 `spec` 显式门控；新增槽位缺席回归用例。 Review 进一步发现 `specDynamic` 是 `SlotCore` 内部方法、`SlotRegistry` 服务只公开 `spec`；已改为公开 `spec`，并以真实浏览器 bundle 的 `SlotRegistry` 测试与 `0.2.1-alpha.3` repointed 树上的实跑验证。适配层与图标测试已更新；注册、RPC、授权与窄窗行为不变。

## v0.1.17 发版验收（2026-11-11）

本次按“文档准备提交 → 仅版本号的正式提交 → 正式提交上的 annotated tag”发版。内容归 CHANGELOG 双语对；支持合同仍为 22 个精确 DSH 版本，开发 pin `0.2.2-rc.1` / cordis `4.1.0`，Auto Review 基线仍为 `0.2.1-rc.2`。本版由四笔合入构成：PR #44（已批准的一次性 Full-access 提权与 ADR-0036）、PR #45（新会话 Hero 行 Workspace Folders 入口与 ADR-0037）、PR #46（工作区 `...` 菜单入口与 ADR-0038）、PR #48（Worktree 附加根建议与主 checkout 授权、ADR-0039）。

PR #48 的 91 条 CI 检查全部 success，覆盖全部支持 DSH 版本 × macOS/Ubuntu（22.04 与 latest）/Windows；worktree 的 macOS 原生全量、受限 Git 旅程与共享 IPC 亦在本机实跑通过。Worktree 功能保持实验性、默认关闭；Linux / Windows 原生矩阵以 PR #48 CI 与 tag 触发的 `release.yml` verify 为准。

发版前在 macOS arm64 / Node `24.18.0` / pnpm `11.25.0` 重跑 `compat:check`、lint、双端类型检查、build、原生 `kernel:probe`、`registry:probe --required`、完整测试、三个 smoke、`pack:check`、`smoke:packed`、`auto-review:fork` 和 `docs:check`，均通过。探针确认本机可用方言为 `seatbelt`（bwrap/Landlock 未安装），`registry:probe --required` 确认共享 IPC 可以实跑。完整回归 **1445 passed / 96 skipped / 0 failed**（96 个文件通过、3 个文件整体跳过）；compose **56/56**、behavior **137/137**、journey **92/92** 与 packed behavior **136/136**，三个 smoke 与 packed 无跳过；`pack:check` 校验 **210** 个成员；可选 `smoke:auto-review` 按精确版本规则跳过，不能计作本轮 Auto Review 集成通过。

首次运行位于 DSH 工具沙箱内时，17 个共享 Registry 的 follower/IPC 与租约用例以 `contended` 失败（`shared IPC refuses sandboxed peers`），上述结果来自随后在完整本机权限下的重跑；失败形状与 v0.1.16 记录的既有环境限制一致，非本版代码回归。本地日志仅存于忽略的 `.dsh-smoke/`，不随发布提交。

## DSH 0.2.2-rc.2 兼容提升（2026-11-12）

从 `main` 的 `5af8fea`（`v0.1.17`）新建 `feat/adapt-1111-rc2`。上游 tag `dsh-v0.2.2-rc.2`（`ddac96760b`）先在 2026-11-11 完成接缝审查与适配；当时 npm 尚未发布该精确版本，因此分支只落适配。2026-11-12 npm 已提供服务（`next` 指向 `0.2.2-rc.2`，`latest` 仍为 `0.2.2-rc.1`），本分支随后按 ADR-0009 完成提升：`SUPPORTED_DSH_RELEASES`、全部 DSH peer 与开发 pin 都指向 `0.2.2-rc.2`（23 个精确版本），开发树由 `scripts/upgrade-dsh.mjs 0.2.2-rc.2` 整体重指，probe overrides 已移除，新增的 10 个传递包已补 `minimumReleaseAgeExclude`。

对 rc.1 → rc.2 的 4645 个文件 patch 做了接缝审查，结论与逐项分类见[接口审查](../../reference/dsh-0.2.2-migration.md#022-rc2-后续审查2026-11-11)。落到本分支的代码：

- `src/workspace-files.ts`：把 rc.2 新增的 `workspaceFiles.search` 纳入共享 authority 的 `withOperation(..., 'files', ...)` admission（与 list/stat/read 同一排序），并对其 **Session 根**应用 `canonicalRoot` 级 withheld 检查（`list`/`changes` 检查路径解析后的所选目录；目标落在在册未授权边界下时在枚举/启动 `rg` 前拒绝）；不路由（搜索根是 Session cwd，附加根没有搜索 UI）；旧版没有该方法时结构性跳过。
- `src/client/styles.ts`：接管附加根时隐藏 rc.2 导航器新增的原生搜索条、状态行与 Files 页搜索开关（原生 body 已隐藏，搜索主根的结果无处显示）；primary 根浏览保持上游原样。
- `src/compat/dsh-version.ts`：新增 `@deepseek-ai/dsh-error` 到 `OPTIONAL_CORE_PACKAGES` 与 `HOST_SERVICE_PACKAGES`（只经宿主锚点作证，发现跨包单例混装），不列为 peer（rc.1 无此包）；allowlist 末尾加入 `0.2.2-rc.2`。
- 测试：`tests/upstream-additional-roots.spec.ts` 增加两个 rc.2-only 用例（Session 注册根进入 POSIX 方言与 fs fence、scope read-only deny 仍胜出）；`tests/sandbox-multi-root.spec.ts` 增加 Windows ACL 组合用例（scope 根进入进程 profile，上游额外根不进入；alpha.2–rc.1 结构跳过）；`tests/workspace-routing.spec.ts` 增加 search admission 用例与 `list`/`changes`/`search` 的 withheld 回归（canonical 目标拒绝、词法覆盖但解析在外的反向放行、主根在 withheld 内时已授权附加根仍可列/监听）；`tests/shared-consumers.spec.ts` 的原生共享用例覆盖 route 检查与 admission scope 的时序；`tests/client-styles.spec.ts` 增加搜索条/页头开关的 DOM 回归。
- 复刻源：按 `src/client/open-in-app/FORK.md` 重拷 `OpenInAppAction.tsx` / `controller.ts`（rc.2 只有注释变化），FORK.md 基线移到 `ddac96760b`，`OpenInAppKey` 补 `menu.openIn`；files-tree 旧版复刻仍钉 alpha.2。
- 文档：迁移审查的 rc.2 小节、兼容笔记双语 §17、README 支持矩阵与开发 pin、AGENTS.md 兼容契约段、`docs/development/plugin-development-workflow.md`。

发布包 enforce 验证（macOS arm64 / Node `24.18.0` / pnpm `11.25.0`）：

- `compat:check`：allowlist、peer、开发 pin、安装树一致（23 个精确版本）。
- lint、双端 `tsc --noEmit`、`build`、`docs:check`、`pack:check`、`auto-review:fork`：通过。
- 完整 `vitest`：**1368 通过 / 162 跳过 / 17 失败**；17 个失败全部是本会话 Seatbelt 下的 sandboxed-peer registry IPC 用例，rc.1 基线在同一环境同样失败 **17** 个（**1364 通过 / 166 跳过**）。rc.2 比 rc.1 多通过的 4 个正是本轮新增、在 rc.1 上跳过而在 rc.2 上执行的用例（Windows ACL 组合用例在 alpha.2–rc.1 因上游拒绝额外根而跳过，更早版本不拒绝，会执行）。失败形状与 v0.1.17 记录的既有环境限制一致。
- Host smoke 与 packed（本机，0 失败）：compose **56/56**、behavior **96 通过 / 8 跳过**、journey **85 通过 / 2 跳过**、packed **95 通过 / 8 跳过**；跳过项是 Seatbelt 内无可用内核 runner 与共享 IPC。
- PR CI（评审返工 HEAD `eafabcb`，[run 43227479998](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43227479998)）：**94/94 jobs 通过**，覆盖 23 个精确版本 × macOS / Ubuntu 22.04 / Ubuntu latest / Windows；Windows lane 含原生 ACL 探针与门禁。本机结果与 CI 结果一致。浏览器实机目检不是 CI 项，按实际执行记录单独列出；本轮未执行则保留为合入前唯一人工项。

评审返工（2026-11-12）：Devin Review 连续指出三项——`workspaceFiles.search` 未应用根级 withholding；`list`/`changes` 不应按 Session 根拒绝已授权附加根；英文兼容笔记与中文不同步。最终语义：`search` 按 Session 根检查；`list`/`changes` 按路径解析后的所选目录检查，且 `changes` 的 route 解析与 withheld 检查在同一个 `withRegistryRead` admission 内（共享 follower 的 ambient scope 可能滞后于 operation scope）；显式路径读取仍按词法规则。回归覆盖 search 拒绝、canonical 反向放行、list/path watch 拒绝、主根在 withheld 内时已授权附加根仍可列/监听，原生共享用例覆盖 route/admission 时序；英文笔记已同步。最终 CI [run 43227479998](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43227479998)（HEAD `eafabcb`）**94/94 jobs 通过**。

本分支以 PR #49（`feat/adapt-1111-rc2`）合入 `main`（`e17ace4`），随 `v0.1.18` 发版；发版验收见[本次记录](#v0118-发版验收2026-11-12)。

## v0.1.18 发版验收（2026-11-12）

本次按“文档准备提交 → 仅版本号的正式提交 → 正式提交上的 annotated tag”发版。自 `v0.1.17`（`5af8fea`）以来 `main` 只有 PR #49（`e17ace4`）一笔内容提交：精确支持 DSH `0.2.2-rc.2`（23 个精确版本，开发 pin `0.2.2-rc.2` / cordis `4.1.0` / schemastery `3.19.0`），把 `workspaceFiles.search` 纳入共享 Registry 准入与根边界，并在接管附加根浏览时隐藏原生搜索入口。没有配置或协议变更，也没有不兼容变更。

PR #49 的 94 条 CI 检查全部通过（[run 43227479998](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43227479998)），覆盖 23 个精确版本 × macOS / Ubuntu 22.04 / Ubuntu latest / Windows；内容与 `main` 上的 `e17ace4` 相同。

准备提交只改文档与 CHANGELOG；正式提交只改 `package.json` 的 `version`，tag 指向正式提交。本次在本机 macOS arm64 / Node `24.18.0` 对准备提交后的树运行 `docs:check`（0 错误 0 警告）、`compat:check`（allowlist / peer / 开发 pin / 安装树一致，23 个精确版本）、`lint`（0 警告 0 错误）、双端 `tsc --noEmit`、`build` 与 `pack:check`（210 个成员），均通过；完整 `vitest` 与三个 smoke 未在本次准备提交上重跑，由 PR #49 的 CI 覆盖。发布矩阵与 GitHub Release 由 tag 触发的 `release.yml` 完成，本机不发布。

## DSH 0.2.2-rc.3 兼容提升（2026-11-13）

从 `main` 的 `50fb77b`（`v0.1.18`）新建 `feat/adapt-1113`。上游 tag `dsh-v0.2.2-rc.3` 指向 `38a6a5c965aa99ab525161efb7cc5cf1fe62fced`，npm 已发布该精确版本（`next` 指向它，`latest` 仍为 `0.2.2-rc.1`），因此本分支按 ADR-0009 完成提升：`SUPPORTED_DSH_RELEASES`、全部 DSH peer 与开发 pin 都指向 `0.2.2-rc.3`（24 个精确版本），开发树由 `scripts/upgrade-dsh.mjs 0.2.2-rc.3` 整体重指，probe overrides 已移除，唯一的新传递包 `@deepseek-ai/dsh-deepseek-chat-import` 已补进 `minimumReleaseAgeExclude`。

rc.3 只有 6 个提交（三次合并、一次发布提交、实验性 DeepSeek 会话导入、桌面安装器重启状态修复与 CI 下载校验），515 个文件；380 个 `package.json` 只替换版本号。逐项接缝分类见[接口审查](../../reference/dsh-0.2.2-migration.md#022-rc3-后续审查2026-11-13)。落到本分支的改动只有：

- `src/compat/dsh-version.ts`：allowlist 末尾加入 `0.2.2-rc.3`；`CORE_PACKAGES` 不变——新包 `dsh-deepseek-chat-import` 是默认不挂载的可选实验 bundle，与插件授权面没有交点。
- `package.json`：28 个 DSH peer 各追加 `0.2.2-rc.3`，全部 DSH devDependency 由升级脚本重指；`cordis 4.1.0` / `schemastery 3.19.0` / `node-addon-system 0.1.2` 与 Auto Review 基线 `0.2.1-rc.2` 不变。
- `pnpm-workspace.yaml`：release-age 条目整体重指到 `0.2.2-rc.3`，删除探测期的 probe overrides，补入新传递包。
- `pnpm-lock.yaml`：`pnpm install --frozen-lockfile` 通过，`0.2.2-rc.2` 包副本为 0（只剩 peer 范围字符串），`pnpm peers check` 输出 `No peer dependency issues found`；非 DSH 差异只有 rolldown `1.2.8` 与新版本的去重。
- 复刻源：rc.3 未改 `ui-open-in-app` / `ui-sidebar-files` 的 `src/client/`，open-in-app 基线保持 `ddac96760b`、files-tree 旧版保持 `f3803c9697`；`FORK.md` 只记录 dev pin 前移、基线不变。
- 文档：迁移审查的 rc.3 小节、兼容笔记双语 §18、README 支持矩阵与开发 pin、`AGENTS.md` 兼容契约段、`docs/development/plugin-development-workflow.md` 与 `docs/reference/README` 双语条目。

安静陷阱（开发树）：升级脚本只重指直接依赖与 release-age；`@deepseek-ai/dsh-permission-presets` 与 `@deepseek-ai/dsh-util-values` 在 rc.2 → rc.3 后仍一度以 rc.2 副本满足 peer 边，`dedupe` / `--force` / `--lockfile-only` 都不改写这类仍“看似有效”的边，必须显式强制到同一精确版本后 frozen install 才一致。

本机验证（macOS arm64 / Node `24.18.0` / pnpm `11.25.0`，`0.2.2-rc.3` 开发树，enforce 车道）：

- `compat:check`：allowlist、28 个 peer、开发 pin、安装树一致（24 个精确版本）；`pnpm peers check` 无问题；
- lint（0 警告 0 错误）、双端 `tsc --noEmit`、`build`、`docs:check`、`pack:check`（210 个成员）、`auto-review:fork`：通过；
- 完整 `vitest`：**1386 通过 / 162 跳过 / 17 失败**（99 个文件，85 通过 / 8 失败 / 6 跳过）。17 个失败全部是共享 Registry 的核内 IPC/租约用例（`contended` 而非 `follower`），本会话运行在 DSH 自身的 Seatbelt 内、Peer 凭据被识别为 sandboxed peer；与 rc.2 基线同形的 17 个失败，不是 rc.3 回归；
- Host smoke 与 packed（0 失败）：compose **56/56**、behavior **96 通过 / 8 跳过**、journey **85 通过 / 2 跳过**、packed **95 通过 / 8 跳过**；跳过项是 Seatbelt 内无可用内核 runner 与共享 IPC；
- 三 OS 矩阵、Windows ACL 原生探针与旧版回归由 PR 的 CI 给出（24 个精确版本 × macOS / Ubuntu 22.04 / Ubuntu latest / Windows）；浏览器实机目检不是 CI 项，本轮未执行，保留为合入前的人工项。

本分支以 PR #52（`feat/adapt-1113`）合入 `main`（`cbda993`），随 `v0.1.19` 发版；发版验收见[本次记录](#v0119-发版验收2026-11-14)。

## v0.1.19 发版验收（2026-11-14）

本次按“文档准备提交 → 仅版本号的正式提交 → 正式提交上的 annotated tag”发版。自 `v0.1.18`（`dde20cf`）以来 `main` 先有两笔提交：PR #51（`50fb77b`）把精确版本按 Node 分桶分组验证，并让 tag 触发的发布复用同一次 main push 门禁；PR #52（`cbda993`）精确支持 DSH `0.2.2-rc.3`（24 个精确版本，开发 pin `0.2.2-rc.3` / cordis `4.1.0` / schemastery `3.19.0`）。前者不改变插件运行时与用户可见行为；后者只有支持矩阵提升，rc.3 对插件消费的接缝全部为新增，未新增适配分支。没有配置或协议变更，也没有不兼容变更。

`main` 在 `cbda993` 上的 push CI 通过：[run 43469327214](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43469327214)，**30/30 jobs**（`releases` + 28 个 `verify` 组 + `gate`，覆盖 24 个精确版本 × macOS / Ubuntu 22.04 / Ubuntu latest / Windows，含 Windows 原生 ACL 门禁）。

首次 tag 推送暴露了 #51 引入的 verify 缺陷：`actions/checkout` 在 `fetch-depth: 0` 检出 tag 时把 `refs/tags/v0.1.19` 重指到被检出的提交，旧步骤的 `^{tag}` 剥离因此失败（[run 43545226397](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43545226397)：`verify` 失败、`publish` 跳过，未发布任何内容）。修复以第三笔提交 `ci(release): restore the annotated tag ref after checkout` 落在 `main`：verify 先从 origin 取回 annotated tag 对象再剥离，并新增在临时仓库中模拟该重指的回归测试；`v0.1.19` 重新打在该提交上，tag 与 `package.json` 的 `0.1.19` 仍然一致。修复提交的 main push CI 由 `release.yml` 的 verify 等待。

准备提交只改文档与 CHANGELOG；正式提交只改 `package.json` 的 `version`。本次在本机 macOS arm64 / Node `24.18.0` 对准备提交后的树运行 `docs:check`（0 错误 0 警告）、`compat:check`（allowlist / peer / 开发 pin / 安装树一致，24 个精确版本）、`lint`（0 警告 0 错误）、双端 `tsc --noEmit`、`build` 与 `pack:check`（210 个成员），均通过；完整 `vitest` 与三个 smoke 未在本次准备提交上重跑，由 `cbda993` 的 CI 覆盖；修复提交另跑 `tests/workflows.spec.ts`、`lint` 与 `docs:check`。发布矩阵与 GitHub Release 由 tag 触发的 `release.yml` 完成，本机不发布。

## Auto Review 多基线适配（2026-11-14）

工作分支 `feat/auto-review-adapt-1114` 从 `main` 的 `b27e3b7` 创建，开发 pin 为 DSH `0.2.2-rc.3`（cordis `4.1.0`，macOS arm64，Node `24.18.0`）。本批解决“联合 Auto Review 只支持 `0.2.1-rc.2`，而其后的普通支持版本没有联合适配”的缺口：用户可见的 Auto Review 能力不变，只是联合合同的精确发布集合扩到 `0.2.1-rc.2` 之后的全部 8 个发布。

上游事实以只读 tag 源码核对，记录于[多基线接口审查](../../reference/auto-review-0.2.2-migration.md)：`0.2.1-rc.2`–`rc.5` 的 reviewer 源码逐字节相同（仅 package version 改写）；`0.2.2-alpha.2` 重写了 reviewer 输入模型（固定 system + 每条保留项一条 user message、逐项 tool-schema、跨审查 schema 复用、`AutoReviewFailedError`、应用关闭保留 Auto），`alpha.3` 新增 `sessionId`/`purpose` 与 `LlmRequestPurposeMap`，`alpha.3`–`rc.3` 源码相同。两条发布线以 `0.2.1-rc.4` 为共同祖先（`rc.5` 与 `alpha.2` 是兄弟，随后都并入 `0.2.2-rc.3`），因此不能互相替代。设计决策见 [ADR-0040](../../decisions/ADR-0040-auto-review-multi-baseline.md)。

改动：

- `src/compat/auto-review-contract.ts` 成为联合合同的唯一机器可读事实源：`AUTO_REVIEW_LEGACY_RELEASES`（`0.2.1-rc.2`–`rc.5`）、`AUTO_REVIEW_CURRENT_RELEASES`（`0.2.2-alpha.2`–`rc.3`）、两个编译 pin（`0.2.1-rc.5` / `0.2.2-rc.3`）、`autoReviewBaseline()`、`requireAutoReviewRelease()` 与 `autoReviewRequestIdentity()`；`auto-review-packages.ts` 按传入的精确发布校验四个执行副本。
- 源码按基线分目录：`legacy/`（逐字节 `d4975b54f5` 基线 + fork + patch）与 `current/`（逐字节 `29df7771f0` 基线 + locale 副本 + fork + patch）；A 的 native/当前约束核对算法提取为基线无关的 `partition.ts`。`entry.ts` 在确认发布属于合同后按基线用计算出的产物路径动态加载 `lib/auto-review-legacy.js` 或 `lib/auto-review-current.js`，宿主不会把另一代的导入拉进模块图（`FiberState` 是 const enum、0.2.2 的 executor 类型子路径在 0.2.1 线不存在）。
- 基线 B 的允许差异：`snapshotAutoReview` 接收 `ReviewContext`；`reviewMessages` 把多根环境合入 `ENVIRONMENT`、把当前附加根约束作为 constraint 项插在环境消息之后与保留项之前、对 native 指令帧执行同一套核对/降级/失败关闭；`classifyRisk` 先构建 context 并做发送前/模型返回后/下游 gate 后的 `assertCurrent`；`apply` 保留 prepend 的 `tools/execute` token 复核。`FiberState.ACTIVE` 改为带注释的字面量 `2`（cordis 发布包无该运行时导出）；`0.2.2-alpha.2` 不发送 `sessionId`/`purpose`（该发布 purpose 仍是闭集），`alpha.3` 起发送。
- 门禁按车道：`scripts/build-auto-review.mjs` 只在开发 pin 等于当前基线编译 pin 时用对应 tsconfig 做实现类型检查；`scripts/lib/auto-review-development.mjs` 按基线维护开发包清单，`upgrade-dsh.mjs` 只安装目标基线清单；`check-auto-review-fork.mjs` 对两个基线分别校验上游哈希/locale 哈希、patch 重建、policy/受保护函数/渲染结构/注入面/owner teardown 与导出面；`vitest.config.ts` 只收集当前基线目录，`loader.spec.ts` 与 `overlap.spec.ts` 常驻、`ops-context.spec.ts` 在联合车道执行；`smoke-auto-review.mjs` 按联合集合判定，冒烟电池跨两代解析 reviewer 消息并用结构探测桥接 `ctx.tools.execute` 的单发/批量形态；`check-dsh-compat.mjs` 校验全部联合发布属于普通 allowlist；`ci/plan.mjs` 要求矩阵包含全部联合发布，`ci/run-group.mjs` 在每个联合发布车道执行差分门禁、完整单测与联合冒烟。

本机验收（macOS arm64 / Node `24.18.0` / pnpm `11.25.0`，开发 pin `0.2.2-rc.3`，enforce）：

- `compat:check` 通过并报告 9 个联合发布；lint 0 警告 0 错误；双端 `tsc --noEmit`（含 `tsconfig.auto-review-current.json` 的实现类型检查）；`build` 生成 `lib/auto-review.js` + 两份实现 chunk；`docs:check` 通过；`auto-review:fork` 通过两个基线的哈希/patch/受保护行为/注入面/渲染结构/导出面校验；`pack:check` 与 packed 成员断言通过。
- `pnpm test`：**1486 通过 / 163 跳过 / 17 失败**（104 文件，90 通过 / 8 失败 / 6 跳过）。17 个失败与本分支之前同环境的基线树逐条相同（base commit `b27e3b7` 在同一沙箱为 **1387 通过 / 162 跳过 / 17 失败**，失败用例集合完全一致）：全部是共享 Registry 的核内 IPC/租约用例（`contended` 而非 `follower`），本会话运行在 DSH 自身的 Seatbelt 内、Peer 凭据被识别为 sandboxed peer；不是本批回归。Auto Review 套件在本车道全部实际执行并通过（`current/upstream.spec.ts` 40、`current/context.spec.ts` 25 通过 + 1 内核能力跳过、`ops-context.spec.ts` 18、`loader.spec.ts` 10、`overlap.spec.ts` 6）。
- `smoke:auto-review`：source/link 与 packed 两条车道、web/headless × 官方 bundle 前后两种顺序全部通过——真实 reviewer 请求包含多根环境与当前 constraint，脚本化 allow 对可写根写入成功、对只读根不能写入且原字节不变，行开关接管/恢复/drain 与重启语义不变。
- 基线 A 车道证据：在独立工作树把开发 pin 重指 `0.2.1-rc.5`（该基线编译 pin）后，`auto-review:fork`、`typecheck`（含 `tsconfig.auto-review-legacy.json`）、`build`、`tests/auto-review`（`legacy/upstream.spec.ts` 31、`legacy/context.spec.ts` 26 + 1 平台跳过、`ops-context.spec.ts` 18、`loader.spec.ts` 10、`overlap.spec.ts` 6）与 `smoke:auto-review` 全部通过；该车道完整 `vitest` 为 1461 通过 / 179 跳过 / 17 失败，失败集合同样是与环境相关的共享 Registry 用例。`0.2.1-rc.2` 车道因类型声明与 rc.5 逐字节相同未重复重指，其发布由 CI 矩阵覆盖。
- 三 OS 矩阵、`0.2.2-alpha.2`–`rc.3` 的逐发布运行、Windows ACL 与旧版回归由 PR 的 CI 给出；本机不把 macOS 单机结论写成跨平台通过。

收尾后追加 `e046f00`：入口在挂载动态加载的基线实现前校验其 `inject` 声明（缺失时不再以误导性的 cordis “without inject” 诊断启动失败），复跑 `lint`/`typecheck`/`build`/`auto-review:fork`/`smoke:auto-review` 通过。

已知边界：`0.2.2-alpha.2` 的闭集 `purpose` 使同一份 current 源码无法在该发布的 .d.ts 下通过类型检查，因此该发布只做运行时验证（完整单测 + 联合冒烟），编译验证在基线 B 的编译 pin `0.2.2-rc.3`；这是 ADR-0040 的显式取舍。发布说明（`CHANGELOG`）与版本号不在本批写入，按既有发版流程在实际发版时补。

## v0.1.20 发版验收（2026-11-15）

本次按“文档准备提交 → 仅版本号的正式提交 → 正式提交上的 annotated tag”发版。自 `v0.1.19`（`b27e3b7`）以来 `main` 有七笔内容提交：PR #53（`8c09c7b`，新会话 Hero 入口宽度自适应）、PR #54（`e1dd466`，Auto Review 两代双基线联合支持）、PR #56（`c82c80a`，附加根 Files 行右键与工作区搜索）、PR #58（`3089e6b`，R6 reload 刷新证据）、PR #55（`8642af6`，Worktree 一次只读检查 + 非模态提示）、PR #59（`af34ac4`，Desktop 安装恢复排查文档）与 PR #60（`2208048`，提示位置/形态与确认 Dialog 重构）。内容归 CHANGELOG 双语对；精确 DSH 支持合同不变（24 个精确版本，开发 pin `0.2.2-rc.3` / cordis `4.1.0` / schemastery `3.19.0`），可选 Auto Review 的联合合同扩为两个冻结源码基线共 9 个精确发布。没有配置或协议变更，也没有不兼容变更。

合入 `main` 的内容提交 push CI 均 success，每次 30 个 job（`releases` + 28 个 verify 组 + 最终 `gate`，覆盖 24 个精确版本 × macOS / Ubuntu 22.04 / Ubuntu latest / Windows，含 Windows 原生 ACL 门禁）：`8c09c7b` [run 43576034884](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43576034884)、`e1dd466` [run 43583650604](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43583650604)、`c82c80a` [run 43610174521](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43610174521)、`3089e6b` [run 43610518488](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43610518488)、`8642af6` [run 43611750159](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43611750159)、`af34ac4` [run 43614377208](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43614377208)。PR #60 的评审修复在 reviewed commit `ab17638` 上 [run 43702749353](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43702749353) 30/30 checks 全绿；最后一笔内容提交 `2208048` 的 main push CI 为 [run 43711839319](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43711839319)，tag 触发的 `release.yml` verify 等待与 tag 提交同 SHA 的 main push CI 与最终 `gate`。

准备提交只改文档与 CHANGELOG；正式提交只改 `package.json` 的 `version`，tag 指向正式提交。本次在本机 macOS arm64 / Node `24.18.0` / pnpm `11.25.0` 对准备提交后的树运行：`docs:check`（0 错误 0 警告）、`compat:check`（allowlist / peerDependencies / 开发 pin / 安装树一致，24 个精确版本；Auto Review 联合合同报告 9 个精确发布）、lint（0 警告 0 错误）、双端 `tsc --noEmit`（含 Auto Review 实现类型检查）、`build`、`pack:check`（228 个成员）、`auto-review:fork`（两个基线的上游哈希、patch 重建、保护面与导出面），均通过。完整 `vitest` 为 **1813 通过 / 165 跳过 / 17 失败**；17 个失败全部是共享 Registry 的核内 IPC/租约用例（`contended` 而非 `follower`），本机 `kernel:probe` 报告无可用受限执行内核，失败集合与既有基线同形，不是本版回归。四个冒烟 0 失败：compose **56/56**、behavior **96 通过 / 8 跳过**、journey **88 通过 / 2 跳过**、`smoke:packed` 的打包行为电池 **95 通过 / 8 跳过**；跳过项是无可用内核 runner 的受限 bash 与嵌套执行断言。`smoke:auto-review` 未在准备树上重跑，由 PR #54 的联合车道 CI 覆盖，不能计作本机通过。发布矩阵与 GitHub Release 由 tag 触发的 `release.yml` 完成，本机不发布。

## Worktree 清理面板 UX 收敛（2026-11-16）

从 `main` 的 `53ae34d`（`v0.1.20` 之后第二笔提交）新建 `fix/worktree-delete-panel`。ADR-0045 与实施计划于 2026-11-16 通过外部技术评审（无阻断项），本批执行计划 Phase 1–3；纯客户端呈现层变更，授权、清理资格、owner 复验、RPC 契约、存储、依赖与 DSH 支持矩阵零改动。

**实现**

- `src/client/WorkspaceFoldersAction.tsx`：批量清理 `Action` 从 footer 移到第二个 section 的标题行（`.mrfw-sectionAction` 包裹、标题行加 `.mrfw-sectionTitleRowAction`），可见条件与 id 收集不变；删除 body 顶部内联确认，新增权限升级 Modal 之后的共用清理 `Modal`（`worktree.cleanupTitle` 标题、`worktree.cleanupConfirm` 数量/不可撤销描述、单/多 id 分别披露 `worktree.pathReuse` / 新增 `worktree.pathReuseMany`、取消 + danger 确认）；独立 `cleanupError`（不复用/不清空面板 body 的 `state.error`），请求中关闭后失败的归属由 `cleanupForRef` 判定；新增 `openCleanup` / `closeCleanup` / `clearCleanupIfCurrent` 统一三处入口，成功只清本次 id 数组；请求中 footer 取消 `disabled`、×/遮罩/Escape 只关 Dialog 不撤销请求；打开清理清 `upgradeFor` / `menuFor` / `accessMenuOpen`，打开升级清 `cleanupFor` / `cleanupError`；面板 keydown 的 Escape/Tab 守卫加入 `cleanupFor`。`cleanupEligible` 行只保留 显示名 + 权限徽标 + `PathCopy` + 红色删除（`IconButton variant=danger` + `IconTrash`，`aria-label`/`title` = `worktree.cleanup`）+ `…` 菜单；跳过两条状态橙字、`worktree.pathReuse` 行内提示、重新登记、技能开关与 reveal。非 eligible 行保持现状。
- `src/client/WorktreePrompt.tsx`：手动入口打开的建议 Dialog 首次 `prompt` 返回空列表时，发布官方 info `Toast`（新 `worktree.noCandidates`、`WORKTREE_EMPTY_NOTICE_HOLD_MS = 5000`、无 icon/tone）；`manualDialogOpen` ref 只允许手动路径触发，notice「查看」/关闭/会话切换/设置关闭清理状态；自动 `fresh` 空与 notice 竞态空保持静默；`onDone` 按 seq 只清匹配项。
- `src/client/styles.ts`：新增 `.mrfw-sectionTitleRowAction { flex-wrap: wrap }` 与 `.mrfw-sectionAction { margin-left:auto; align-self:center; display:inline-flex }`；未改基础标题行、footer、row、danger/icon 按钮规则。`src/client/locales.ts`：中英各新增 `worktree.cleanupTitle`、`worktree.pathReuseMany`、`worktree.noCandidates`，既有键文案不变。
- 维护者目检后追加（2026-11-16）：`panel.limitReached` 从控件之间移到 footer 独立提示行——提示占满一行（`.mrfw-actionsNote`），控件行在其下方，两行都在 footer 顶部分割线之下；`.mrfw-actions` 改为允许换行（`≤560px` 的控件换行行为保留），样式与 panel 结构测试同步。
- 测试：`tests/client-worktree.spec.tsx` 内联确认用例改写为 Dialog 用例并新增批量位置/计数 0、行内删除单 id、菜单入口、行动作集收敛、非 eligible 回归、单/多路径复用披露、失败错误归属、请求中关闭后失败回 body alert、`busy` 取消失效/关闭不撤销/成功采用应答、应答后不重开确认、两个确认互斥、打开清理清菜单、Escape 守卫、空发现 Toast 及自动/竞态静默、抛错静默、会话与设置清理、重复展示；`tests/client-styles.spec.ts` 增加两条样式断言；`tests/stubs/ui-primitives.tsx` 的 `Modal` 桩补上真实 Modal 的固定关闭控件。
- 文档：README 双语 Worktree 小节（批量入口位置、确认 Dialog、失效行动作、空发现 Toast、路径复用改为删除确认披露）、`docs/guide/README.md`「删除与清理」、`docs/architecture/multi-root-workspace.md` Client 半部（普通行/eligible 行动作集、批量入口、空发现 Toast、token 与 primitives 边界改指 ADR-0006 决策 7）；本计划移入 `docs/plans/completed/` 并同步中英索引；ADR-0045 保持 Proposed。

**验证（macOS arm64 / Node `24.18.0` / pnpm `11.25.0`，DSH `0.2.2-rc.3` 开发树）**

- `pnpm exec vitest run tests/client-worktree.spec.tsx tests/client-panel.spec.tsx tests/client-styles.spec.ts` → **197 passed**。
- `pnpm lint` → 0 warnings / 0 errors；双端 `pnpm typecheck`、`pnpm build`、`pnpm docs:check`（0 errors / 0 warnings）、`pnpm compat:check` → 通过。
- `pnpm test`（build 后）→ **1860 passed / 165 skipped / 17 failed**；17 个失败全部是共享 Registry 的 IPC/租约用例（`contended` 而非 `follower`），与既有基线记录的失败集合同形，不是本批回归。
- `pnpm kernel:probe`：本机无可用受限执行（seatbelt `runner-failed: sandbox_apply: Operation not permitted`；bwrap / landlock 未安装），内核断言按既有规则显式 skip；`pnpm smoke`：compose **56/56**、behavior **96 passed / 8 能力 skip**、journey **88 passed / 2 能力 skip**；`pnpm pack:check` **227 members**；`pnpm smoke:packed` **95 passed / 8 能力 skip**（tarball 装进隔离 scratch home，载荷解析在 checkout 之外）。
- 实机目检（隔离 scratch `DSH_HOME` + 真实 `dsh web` 子进程 + Chrome 157 headless/CDP；fixture 为真实 git main checkout 与 linked worktree）：经面板「Worktree 建议」登记 linked worktree 后 `rm -rf` 其目录制造 `cleanupEligible`。1280 / 640 / 600 / 560 / 480 px × 浅/深主题：footer 各宽度 `scrollWidth <= clientWidth + 1`、末按钮与标题行批量按钮都在 Dialog 内，560/480 按既有换行规则换行；达根上限（`panel.limitReached`）的同一组宽度无新溢出；批量与单行都打开覆盖面板的 Dialog（标题/数量/不可撤销/路径复用/取消/确认齐全），未提交取消不发送请求；请求中 footer 取消 `disabled`、× 关闭只关 Dialog 且请求继续，成功后 Dialog 关闭、行消失、计数下降；失败时 Dialog 保持并显示本地化错误；`cleanupEligible` 行仅 名称/权限徽标/路径/红色删除/`…`，普通 missing 行保留 状态文字 + 重新登记 + 技能 + reveal；Tab 在 Modal 内循环（不进背后面板），Escape 先关 Dialog 再关面板；空发现 Toast 为官方 info 形态（无 icon/警告色）并自动淡出。截图与 CDP 脚本保留在 gitignored 的 `.dsh-smoke/manual-verify/`（`qa/**/*.png`），随实施记录引用。
- rebase 到 main（2026-11-16）：main 合入的预览导航搜索 ADR 保留 0043、sidebar footer 对齐使用 0044，本 ADR 由起草时的 0043 改号为 **0045**（决策内容不变）；冲突只在 decisions 索引/编号口径、ADR-0006 Status 行与 architecture Client 半部，已按「保留 main 新增内容 + 重放本批文案」解决，其余文件自动合并。
- 边界：本批已通过 PR [#64](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/pull/64) 合入 `main`（`aefa190`），main push CI [run 43851525562](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43851525562) 30/30 成功；随 `v0.1.21` 发版。实机目检为本地证据，未上传。

## v0.1.21 发版验收（2026-11-17）

本次按“文档准备提交 → 仅版本号的正式提交 → 正式提交上的 annotated tag”发版。自 `v0.1.20`（`7a29f1b`）以来 `main` 有七笔内容提交：PR #61（`a3baafd`，Files 页被第三方整页接管时的 info 提示）、PR #62（`53ae34d`，Worktree 提示加回圆形关闭按钮）、PR #63（`290d7f7`，侧栏 footer 入口的两代行几何对齐、workspace tree 图标与同槽共存）、PR #65（`73bc32c`，附加根文件预览导航树的工作区搜索）、PR #64（`aefa190`，Workspace Folders 的 Worktree 清理面板 UX 收敛）、`7f5584b`（README 功能概览重写与已知限制重组）与 PR #66（`34567ef`，`koffi` 改由宿主提供）。内容归 CHANGELOG 双语对；精确 DSH 支持合同不变（24 个精确版本，开发 pin `0.2.2-rc.3` / cordis `4.1.0` / schemastery `3.19.0`），Auto Review 联合合同仍是两个冻结源码基线共 9 个精确发布。没有配置或协议变更，也没有不兼容变更；清理面板与 footer 对齐都是纯客户端呈现层改动。ADR-0045 保持 Proposed，转 Accepted 由维护者决定。

合入 `main` 的内容提交 push CI 均 success，每次 30 个 job（`releases` + 28 个 verify 组 + 最终 `gate`，覆盖 24 个精确版本 × macOS / Ubuntu 22.04 / Ubuntu latest / Windows，含 Windows 原生 ACL 门禁）：`a3baafd` [run 43726552680](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43726552680)、`53ae34d` [run 43736530700](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43736530700)、`290d7f7` [run 43834956446](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43834956446)、`73bc32c` [run 43843154269](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43843154269)、`aefa190` [run 43851525562](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43851525562)、`7f5584b` [run 43864310850](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43864310850)、`34567ef` [run 43889108132](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43889108132)。tag 触发的 `release.yml` verify 等待与 tag 提交同 SHA 的 main push CI 与最终 `gate`。

准备提交只改文档与 CHANGELOG；正式提交只改 `package.json` 的 `version`，tag 指向正式提交。本次在本机 macOS arm64 / Node `24.18.0` / pnpm `11.25.0` 对准备提交后的树运行：`docs:check`（0 错误 0 警告）、`compat:check`（allowlist / peerDependencies / 开发 pin / 安装树一致，24 个精确版本；Auto Review 联合合同报告 9 个精确发布）、lint（0 警告 0 错误）、双端 typecheck、`build`、`pack:check`（**231** 个成员）与 `auto-review:fork`（两个基线的上游哈希、patch 重建、保护面与导出面），均通过。完整 `vitest` 为 **1907 通过 / 165 跳过 / 17 失败**；17 个失败全部是共享 Registry 的核内 IPC/租约用例（`contended` 而非 `follower`），本机无可用受限执行内核，失败集合与既有基线同形（涉及 `authority-boundaries`、`b9-review-regressions`、`registry-lease`、`registry-multiprocess`、`registry-operation`、`registry`、`skills-authority`、`skills-registry` 八个文件），不是本版回归。冒烟 0 失败：compose **56/56**、behavior **96 通过 / 8 跳过**、journey **88 通过 / 2 跳过**、`smoke:packed` 的打包行为电池 **95 通过 / 8 跳过**；跳过项是无可用内核 runner 的受限 bash 与嵌套执行断言。`smoke:auto-review` 未在准备树上重跑，本批未改 Auto Review 代码，由既有联合车道 CI 覆盖，不能计作本机通过。发布矩阵与 GitHub Release 由 tag 触发的 `release.yml` 完成，本机不发布。

## 多执行环境 G0 基线（2026-11-07）

**状态：G0 本地首批已实现，整体关卡验收仍开放。** 按[实施计划](./2026-11-06-multi-environment-gates.md)从基线开始；本轮没有开启或发布 SSH 能力，不修改生产 provider、scope、Registry、兼容 allowlist 或可选 peers。G1/G1a/G2/G3/G4/G5 尚未实施；G6、原生 Windows 发起端及其他已延期消费者不纳入本批。取证方法、公开工具接缝、兼容检查落点与 SFTP 待测清单归[基线参考](../../reference/multi-environment-baseline.md)。

插件起点 `44c5e24c1b38e4177aa887377009028523cbb353`（`feat/ssh-workspace`、包 `0.1.15`），上游只读 checkout 为干净的 `66491b05e3f05ad35bcdd4f6cd7ed26041d9e3db`。本机 macOS arm64 / Darwin `24.6.0` / Node `24.18.0` / pnpm `11.25.0`。`pnpm baseline:multi-environment --upstream ../deepseek-harness` 以最终源码生成报告：源码摘要 `fd601cf8faa5eb390ed093c40e6571ba8774c8f76a2376687735cb19e8bcb586`，定向 **48 passed / 0 failed / 0 skipped**，记录宿主工具/服务包版本、FS 方法存在性及四个 SSH peers 全部缺席。输出仅留忽略目录 `.dsh-smoke/multi-environment-g0-WwANP8/`，不是已发布制品或跨平台支持声明。

八份实际 CLI 组合快照覆盖 web/headless × 原生/安装插件 × applyPatch false/true：rc.1 web 为 **196 → 211** 行、headless 为 **99 → 114** 行。`smoke:compose` 另验证只有两个上游 provider 行被 disabled、插入十五个既有插件行；开关字段出现在 dump 与实际注册是不同证据。真实 apply_patch 增删改移和 tool cap 由既有 e2e 证明；新增五项出树工具测试使用真实 SessionStore 和 execute pipeline 验证条件注册/卸载、不可伪造的调度身份、pre-execute 拒绝、两 Session 政策及取消信号。真实 Agent turn 继续由 web/headless journey 验证。

| 本地安装树 | 验证结果 |
| --- | --- |
| 开发 pin DSH `0.2.2-rc.1` / cordis `4.1.0` | `compat:check`、lint、host/client 类型、build、原生 Seatbelt probe、完整 `verify:all` 通过。**1185 passed / 95 skipped / 0 failed**；compose **54/54**、behavior **137/137**、journey **76/76**、pack 完整性及静态 SSH 导入检查、packed behavior **136/136** 通过，四个 smoke 均无跳过。Auto Review fork 校验通过；可选 Auto Review smoke 因精确基线不同而跳过，不算该集成验收。 |
| 隔离快照 DSH `0.1.5-rc.2` / cordis `4.0.2` | 使用现有 upgrade 脚本重指并独立安装，主工作树 pin/lock 不回退；兼容门禁保持 enforce。类型、build、原生 Seatbelt probe 与完整测试通过：**1078 passed / 202 skipped / 0 failed**。compose **54/54**、behavior **129/129**、journey **76/76**、pack 检查、packed behavior **128/128** 与 fork 校验通过，四个 smoke 均无跳过。该副本在 gitignore 目录内，oxlint 无法枚举文件，所以 lint 只在相同源码的主工作树通过，未声称旧副本的 `verify:all` 整条命令通过。 |

最老 pin 另跑相同的 G0/FS/apply_patch/静态导入定向用例：**20 passed / 7 skipped / 0 failed**；七项均因后端没有 patchText/deleteFile/moveFile 而跳过（五项 FS patch、两项真实 apply_patch）。不为旧 pin 合成新 API。旧版完整测试/安装证据留 `.dsh-smoke/g0-old-pin-*.log` 与隔离快照；pnpm 在此临时树因脚本/安装元数据检查尝试重装，后续仅将其运行前检查设为 `warn`，真正的 `compat:check` 不放宽。

初次在外层受控执行环境中，Seatbelt probe 被 `sandbox_apply: Operation not permitted` 拒绝，17 项 Registry follower 断言失败；不能据此验收。随后在允许原生 IPC/Seatbelt 的宿主环境重跑，确认 Seatbelt 实际执行、完整回归零失败。旧快照首次全测还因未复制 workflow/locale/detail 夹具失败，补齐同一仓库的资源后重跑通过；这些失败不计为产品缺陷或通过证据。所有原始日志仅留忽略目录。

**未验证与下一步：** 本轮只有 macOS arm64 本地事实；Linux 与 Windows 本地回归尚未重跑。未取得受信部署清单、可丢弃 SSH/SFTP 目标、host key/Helper 绑定和 OS 身份隔离证据；SFTP EXCL、hardlink/no-replace、目标摘要及对象/父目录绑定均为待验证，没有方向被宣布 supported。缺少这些证据不阻止记录 G0 的本地结果，也不授权启动 G2/G4 的真实远端操作或开放 G5 工具。后续可按计划继续独立的 G1 本地委托、G1a 控制面实验，并在部署就绪后补齐远端取证。

### G0 验收审查（2026-11-07）

**结论：暂不通过 G0 完整验收；本地回归通过。** 本次按计划 G0 行及 G0/G1 细则核查前批产物，没有修改实现代码或提前实施下一关。以下是本轮验收决定；上方首批结果仍作为历史证据保留。

| 验收项 | 结论与证据 |
| --- | --- |
| 变更范围 | 通过。生产 `src/`、profile patch、peer/allowlist 与 lockfile 均未被本批修改；只有测试、采集/打包检查和文档变更。 |
| 当前证据完整性 | 通过。重新计算当前源码摘要、manifest/lock/patch 摘要及八份 rc.1 dump 摘要，全部匹配 `multi-environment-g0-WwANP8/report.json`；其 JSON 测试报告为 48 通过、零失败、零跳过。这份 rc.1 报告本身未发现被误记成旧 pin。 |
| rc.1 完整门禁 | 本次重跑 `compat:check` 和 `verify:all` 通过：**1185 passed / 95 skipped / 0 failed**，Seatbelt 实际执行；compose **54/54**、behavior **137/137**、journey **76/76**、pack 检查与 packed behavior **136/136**，四个 smoke 无跳过。Auto Review 仍只计 fork 校验，不把精确版本跳过的集成 smoke 算成通过。日志为 `.dsh-smoke/g0-acceptance-compat.log`、`g0-acceptance-verify.log`。 |
| 最老 pin 定向复验 | 本次在既有独立安装快照中重新 enforce compat，并重跑 G0、FS parity、apply_patch 与静态导入检查：**20 passed / 7 skipped / 0 failed**。七项依旧只因 patch API 不存在而跳过。日志及逐项 JSON 为 `.dsh-smoke/g0-acceptance-old-*`；旧版完整回归、原生内核和 smoke 证据已核对上方原始日志，本次没有声称又重跑了旧版完整链。 |
| 静态 SSH 引用与兼容清单 | 通过本关的检查范围。打包门禁检查 ESM 静态 import/re-export；SSH 分类、peer range、独立 dev pin 与核心 mixed 判定隔离的待实现清单已写清楚。它们不是已实现的运行时 SSH 门禁。 |
| 真实 profile 工具与执行基线 | **未通过，待补。** collector 只 dump 配置并校验 applyPatch 字段；未启动这八种组合读取实际工具清单或保存对应文件/进程效果。现有 apply_patch e2e 是专用 Context 的 true 配置，真实 journey 没有 apply_patch 调用；没有证明真实 web/headless 的 false 态不可调、true 态经实际工具执行并留下正确哨兵。旧 pin 留下测试/smoke 日志，没有同格式的逐 profile 快照包。新工具取消测试使用手动 AbortController 与测试 Agent carrier，尚未演练真实 Agent turn 的取消到达该工具。 |
| 平台与受管 SFTP | 未验证。Linux/Windows 本地格、真实 SSH、SFTP 三项原语及部署隔离仍缺实际环境。计划明确允许缺 Host/凭据的格子标为未验证；这不是产品执行失败，也不授权对外宣称这些能力通过。 |

两个采集器问题也需在关闭 G0 前处理，均可在无 SSH 的本地复现：

1. **运行时归属混用（P2）。** 将 `DSH_CLI` 指向已有旧 pin 的 `node_modules/@deepseek-ai/dsh/lib/bin.js`，`runtimeRequire()` 所见版本为 `0.1.5-rc.2`；但 collector 静态导入的 LocalFileSystem 仍来自主工作树 rc.1，报告 patchText 存在，旧 runtime 的实际 fs-local 源码却没有该方法。collector 的 compat 子进程及多数测试静态依赖同样取主工作树。必须拒绝不一致的 override，或确保版本检查、方法探测、测试和 profile 全部绑定同一棵树，并补一个新旧树相反的负例；不能用当前 tests 结果为另一棵 runtime 作证。定位 `scripts/probe-multi-environment-baseline.mjs` 的静态 LocalFileSystem 导入、runtimeRequire、fsMethods 与测试子进程。
2. **快照源码身份不可信（P2）。** 在本次使用的仓库内独立安装快照 `.dsh-smoke/g0-old-pin` 中执行 collector 的 Git 枚举逻辑：Git 向上找到主工作树，HEAD 返回 `44c5e24c…`，`src/scripts/tests` 的文件列表却为 **0 项**，源码摘要成为空数组的固定 SHA-256 `4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945`，未验证快照内容。应校验 Git top-level 与采集根相同且文件列表非空，或为无 Git 快照实现独立的内容枚举与明确 provenance；不满足时显式失败/未验证，不生成看似有效的源码身份。

**复验退出条件：** 修复上述两个取证问题并补拒绝用例；为两个 pin 保存真实 profile 工具清单、applyPatch 两态适用的调用/拒绝与哨兵证据，明确旧版方法缺席；补真实 turn 取消链路。重跑受影响的 G0 采集和本地门禁后再作结论。SSH/SFTP 与其他 OS 可继续保持计划允许的未验证状态，但不得用本轮本地通过替代其以后各关的验收。

### G0 缺项关闭与复验（2026-11-07）

**验收结论：G0 通过，可以进入 G1。** 这次结论覆盖本机 macOS arm64 的本地基线，按计划保留其他 OS、真实 SSH/SFTP 与部署隔离格为未验证；没有签收或开放任何真实 SSH 能力。上次暂不通过的三个事项均已关闭：

- 采集器在运行任何测试/安装前核对 `DSH_CLI` 与本树 CLI 的真实入口；跨树 override 显式失败。以两棵真实安装树双向复现，均为 exit 1、`G0_RUNTIME_MISMATCH`、0 个 checks、0 个 profiles。负例原始数据为 `.dsh-smoke/g0-close-runtime-guards.json`。
- 源码指纹改为实际内容枚举；非空文件树是前置条件。父 Git 仓库不再给快照提供 HEAD：主工作树记 git-worktree，旧 pin 独立快照记 content-snapshot/sha=null。两棵树均枚举 **290** 个文件，源码摘要同为 `15f53b340472a186050a567f5496ae66c9c5522da0c8f2e792e5004a823a2dd6`；快照内容变化及空目录拒绝有自动回归。
- 两个 pin 各保存 **8** 个真实组合的 CLI dump、实际覆盖层、执行 JSON 与子进程日志，共 **16** 个组合。Web 不再只改被禁用的顶层 tool-fs：实际 preset 行也被覆盖，其他字段和 `!!js` 条件保留。headless 使用原生 startup/runner 自己创建的 Agent。每组记录完整原生工具 schema、模型 wire 工具名、文件工具/直接 FS 的允许与拒绝、真实 shell 命令及根内/根外哨兵，以及原生 Agent turn 的取消链路。rc.1 的 patch 开态实际增删改移，关态调用被拒；最老 pin 两态均实际拒绝不存在的工具，文件保持不变。

| 最终采集 | 结果 |
| --- | --- |
| rc.1：`.dsh-smoke/multi-environment-g0-v28J6m/` | 定向 **53 passed / 0 skipped / 0 failed**；8 个组合全部 passed。 |
| 最老 pin：`.dsh-smoke/g0-old-pin/.dsh-smoke/multi-environment-g0-SGD5OK/` | 定向 **46 passed / 7 skipped / 0 failed**；七项仍为旧版缺 patch API 的适用性跳过，8 个真实组合全部 passed、没有跳过。 |
| 两树的自动差分 | 每树的 web/headless × patch 两态均比较原生/插件工具 schema、wire 工具清单、服务可用性、raw FS 结果及最终哨兵，合计 **8/8** 差分通过。 |
| 原生取消 | 16 个组合全部证实真实注册 Agent/Session、工具携带 AbortSignal、agent.cancel 后正文结束和 turn/end；web 与原生 headless 都覆盖。 |
| 证据完整性 | 对两个最终 report 的每份 dump、overlay、执行 JSON 重新计算 SHA-256，全部匹配；旧版内容 provenance 没有借用父 Git 身份。 |

修复后的 rc.1 完整 `verify:all` 通过：**1190 passed / 95 skipped / 0 failed**，原生 Seatbelt probe 成功；compose **54/54**、behavior **137/137**、journey **76/76**、pack 检查、packed behavior **136/136**，四个 smoke 均无跳过；Auto Review fork 校验通过，精确版本集成 smoke 仍按既有规则跳过。共享 SSE 帧提取由这次真实 journey 联测，两个 wire 协议另由两个 pin 的真实 profile 采集实际覆盖。日志 `.dsh-smoke/g0-close-verify.log`；最后新增的组合断言由上述最终采集覆盖。主工作树 pin/lock/生产 provider 仍未改变。

下一阶段按计划选择 **G1 仅 local backend 委托 POC**；先进入 test composition，不替换生产 `ctx.fs`，不引入 SSH peers、远端记录或面板。G1 的三平台退出条件仍须独立验证。

## 多执行环境 G1 本地委托（2026-11-07）

**状态：G1 本地委托通过：macOS arm64 含真实组合差分，Linux/Windows 经 CI 矩阵通过单元与差分用例；生产 `ctx.fs` 切换不在本关。** 本关只在测试组合中加入仅 local backend 的委托门面（`tests/support/local-fs-facade.ts`），生产 `ctx.fs`、`src/`、profile patch、peers/allowlist 与 lockfile 均未修改；没有 SSH peer、远端记录或面板。门面保留原 provider 的接收者、同步返回、品牌与可选方法存在性，只检查位置参数：未知或撤销的 `remote:`/`ssh:`/`sftp:` 等 URI 与带远端 targetKey/displayPath 的 target（含 move 两端、resolve 的 cwd）在任何本地 IO 之前以 `G1_REMOTE_REFERENCE_UNAVAILABLE` 拒绝。

| 证据 | 结果 |
| --- | --- |
| 单元/差分 | `tests/local-fs-facade.spec.ts` 与 `tests/fs-parity.spec.ts` 的 G1 组 **32/32**：同步 target/fileUrl/contains、stat/stream/bytes/range/listDir、三种 Session 模式 × 三态访问、陈旧版本与 createIfAbsent、真实 tool-fs 的观察事件与意图回调、Registry 单次准入/撤权/销毁、tool cap，以及经 traced `ctx.fs` 输入同名本地哨兵时本地 IO 计数为零。 |
| rc.1 真实组合 | `pnpm baseline:multi-environment --upstream ../deepseek-harness --local-facade`：`.dsh-smoke/multi-environment-g1-w42Jyh/`，定向 **67 passed / 0 skipped / 0 failed**；web/headless × applyPatch 两态 × 空根/本地根共 **8/8** 差分通过（工具 schema、wire 工具名、哨兵、服务、raw FS、scope、confine argv/enforcement、规范化 prompt 摘要、附加根写入与 shell 效果）。插件组合 web **212**、headless **115** 行（较既有插件各多一行候选行，原 `multi-root-fs` 行 disabled）。 |
| 最老 pin `0.1.5-rc.2` | 独立快照 `.dsh-smoke/g0-old-pin/.dsh-smoke/multi-environment-g1-pEklgP/`：定向 **60 passed / 7 skipped / 0 failed**，8/8 差分通过。七项跳过均为旧后端缺 patchText/deleteFile/moveFile（五项 FS patch 围栏、两项真实 apply_patch）。 |
| rc.1 完整门禁 | `verify:all` 通过：Seatbelt 实际执行；**1204 passed / 95 skipped / 0 failed**；compose **54/54**、behavior **137/137**、journey **76/76**、pack 检查、packed behavior **136/136**；Auto Review 仅 fork 校验计入。`docs:check` 零错误。 |

复验中发现并修复两个测试/取证侧问题，均不属产品行为差异：cordis `4.0.x` 的 traced 方法只从**自有** `ctx` 描述符恢复服务上下文，门面因此复制后端的 `ctx` 描述符；web prompt 中随机的 Web GUI 端口（rc.1 与旧版两种措辞）改为规范化后再取摘要。原始日志为 `.dsh-smoke/g1-close-*.log`。

**三平台 CI（df03e7e）：** 手动触发的 [CI run 42337702790](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/42337702790) 在全部 22 个支持版本 × ubuntu-22.04/ubuntu-latest/macos-latest/windows-latest 上 success（含 smoke 与 packed）。抽查日志：rc.1 的 ubuntu-latest 与 windows-latest 上 `local-fs-facade.spec.ts` **11/11**、`fs-parity.spec.ts` **21/21** 实跑无跳过（ubuntu 全量 1206 passed / 93 skipped）；`0.1.5-rc.2` 的 ubuntu-latest 与 windows-latest 上 facade **11/11**，fs-parity 仅五项旧版缺 patch API 跳过。真实 profile 采集器（`--local-facade`）不在 CI 中运行，Linux/Windows 的组合级 prompt/argv 差分仍只有 macOS 证据。

**未验证与下一步：** 若需将 Linux/Windows 的组合级差分也签收，须在对应宿主上运行 `--local-facade` 采集；切换生产 `ctx.fs` 仍须按 ADR-0031 的门槛另行评审，本关不构成该结论。下一步进入 G1a 控制面（远端记录域与版本化准入），与真实 SSH 无关的部分可先用真实存储、双 Host 与无网络 fake 端点验证。

## 多执行环境 G1a 控制面（2026-11-07）

**状态：G1a 的 macOS arm64 本地格实现并通过定向验证；三平台退出条件与真实 SSH 无关的部分已用真实存储、双 Host 与无网络 fake 端点覆盖，关卡整体尚未签收。** 格式与拒绝码见[控制面参考](../../reference/multi-environment-control-plane.md)。本关在 `src/remote/` 新增控制面模块（manifest / records / protocol / plane / contract），`src/registry.ts` 仅做接线：配置行 `remoteEnvironments`、owner 的远端域与 remote-1 监听器开闭、follower 的 remote-1 hello、以及 `remoteStatus` / `remoteList` / `addRemote` / `removeRemote` / `withRemoteOperation` / `setRemoteEndpointVerifier` 六个服务入口。默认 `enabled !== true` 时 remote 状态为 `disabled`，v1 协议、v1 域、`ctx.multiRootScope` 与 prompt 逐字节不变；`win32` 发起端为 `platform-deferred`。本关没有 SSH 包、没有网络、没有面板/命令/工具暴露，也没有默认 verifier——生产上 `addRemote` 必然以 `endpoint-unverifiable` 拒绝。

| 证据 | 结果 |
| --- | --- |
| 清单解析与保护 | `tests/remote-manifest.spec.ts` **24/24**：合法清单与稳定 digest；windows-target-unsupported / unsupported-platform / unknown-environment / duplicate-environment / duplicate-binding / alias-conflict（相等与嵌套）/ 非法路径（`..`、`//`、尾斜杠、相对、NUL、相对 primary）/ helper 与 transport 配对 / 多余键逐一拒绝；group-writable 文件、symlink、位于被绑定 primary 内三种保护拒绝。 |
| 单 Host 注册表 | `tests/remote-registry.spec.ts` **10/10**：disabled 不产生远端域文件且 v1 行为不变；无 verifier 拒绝、fake verifier 注册只进 `multi_root_workspace_remote.json` 而不进 v1 文件/scope；跨项目同名 rootId `binding-not-authorized`、携带 `access` 键 `invalid-arguments`；hostKey 变更 `withheld`、binding 移除 `revoked` 且准入相应拒绝；只读会话禁写/执行、danger-full-access 收敛为 workspace-write、双 Session 不互串、tool cap 禁写、缺策略 `session-policy-unavailable`、操作句柄过期后读取抛错；远端域打开失败降级为 `storage-failed` 而本地 add/list 正常；enable→revoke→disable→restart→re-enable 后 v1 文件字节不变且 grant 保持 `revoked`；撤权排在准入前的 Promise barrier 拒绝、已准入体完成后下一次才拒绝、慢 verifier 期间 binding 变更 `binding-changed`。 |
| remote-1 协议 | `tests/remote-protocol.spec.ts` **4/4**：hello 绑定 store/epoch/manifestDigest，digest 不符显式 `config-digest-mismatch`；未知 domain 显式 `unknown-domain` 且通道保持打开；mutation request-id 去重（同参幂等、换参毁链）；丢失回复以 `authority-disconnected` 拒绝且不重放。 |
| 双 Host 矩阵 | `tests/remote-multiprocess.e2e.ts` **5/5**（与 shared-registry-multiprocess 同一原生可用性门）：新 owner+新 follower 准入与转发 add；新 owner+旧 follower（remote disabled）v1 正常；旧 owner+新 follower `owner-without-remote-protocol` 而 v1 正常；digest 不符仅 `config-digest-mismatch`；owner 退出→接管→新 epoch→remote 重新 hello，旧 epoch 在途请求被拒绝。 |
| 既有定向回归 | `registry-operation` / `shared-registry(-multiprocess)` / `tool-access` / `authority-native` / `authority-boundaries` / `skills-authority` / `shared-registry` 全部通过，v1 wire 与域语义未变。 |

设计取舍：remote-1 是 v1 之外的**第二**监听端点（`<store>.r1.sock`），旧 owner 没有该端点即天然表现为 `owner-without-remote-protocol`；owner 侧远端域在同一份 `serialize` 队列内以独立 `remoteRevision` 读写，不占用 v1 `operationRevision`；verifier 的校验在队列外执行、入队后重检 binding digest；`withRemoteOperation` 在发起侧按 Session 模式与 tool cap 先收窄再进 owner 准入，`local` 端点不带远端身份字段（`verifiedTarget`/`bindingDigest`/`configVersion` 为 `null`）。远端 grant 永不进入 `setAdditionalRoots`、scope、方言、指令或 Skills。

**未验证与下一步：** Linux 与 Windows 本地格须在 CI 支持矩阵上复跑同一组用例；manifest 保护检查只覆盖 POSIX（`win32` 发起端整格 `platform-deferred`）；helper transport 与 sftp transport 的真实握手、hostKey 轮换、对象型 verifiedTarget 与双端 transfer 的真实消费侧留给 G2/G4；`remote-1` 尚不支持跨 Host 广播远端变更（本关不需要）。真实 SSH 能力仍无任何开关可达。

## 多执行环境 G4 兼容门禁与 G3 远端命令合同（2026-11-07）

**状态：macOS arm64 本地格实现并通过定向验证；关卡整体尚未签收。** 本轮为两个互不依赖的纯代码部分，未构造 `SshConnection`、未打开任何网络连接，真实 SSH 能力仍无入口。

**G4 SSH 兼容门禁与宿主锚定装载。** `src/compat/dsh-version.ts` 新增 `SUPPORTED_SSH_RELEASES`（`['0.2.2-rc.1']`，`SUPPORTED_DSH_RELEASES` 的后缀）与 `SSH_PEER_PACKAGES` 四字面量，以及纯函数 `classifySshCapability`：平台（非 linux/darwin）→ `platform-deferred`、本地 verdict 非 supported → `local-compat-not-supported`、宿主低于 SSH 地板 → `host-below-floor`（静默，绝不影响本地 verdict）、SSH 包缺席 → `missing-optional-package`、版本不符或私有副本 → `identity-mismatch`。默认读取器先从 `@deepseek-ai/dsh` 宿主锚点解析、再回退本模块；仅宿主锚点不可见且命中本包根的解析才计为私有副本（开发树内宿主锚点同根时该判别自动放开，同 `insidePackageRoot` 的未知根语义）。四个 SSH 包以全量 allowlist range 进入 `peerDependencies` 并 `optional: true`（上游安装期检查按 peer 逐一通过），devDependencies 恰钉 `0.2.2-rc.1`；未进 `dependencies`。`check-dsh-compat.mjs` 保留全量 peer range 检查，§4 将 SSH dev pin 与核心 pin 分开验证、另验后缀关系与 optional meta、SSH 永不进入 §5 核心版本集合，缺 SSH 不失败；新增 `[compat] SSH floor` 行。`src/compat/ssh-packages.ts` 的 `loadHostSshPackages` 仅接受 `eligible` 闸门、只经宿主锚点解析（无 koffi 式回退），锚点在包外而解析落进包根即 `identity-mismatch`，对四个包只结构校验公开类（`SshConnection`、`SshFileSystem`、`SshSubprocessRuntime`、`SshSandboxProvider`，已与 rc.1 实际导出核对）而不实例化；暂无任何生产路径调用。

**G3 `remote_bash` 双准入合同。** `src/remote/exec.ts` 定义部署/后端/句柄契约与 `runRemoteCommand`：准入 A 内完成 backend 查找、cwd/timeout 校验与 `confine`（`workspace-write` + 端点 displayPath + 真实 sessionId），非 `enforced` 即 `sandbox-unverified`；准入 B 以相同请求重入排序点，比对 epoch、displayPath、bindingDigest、verifiedTarget、effectiveMode 与后端 generation，任一变动即 `admission-changed` 且 argv 丢弃——spawn 只发生在 B 的体内。出队后等待：限幅 stdout/stderr、超时与取消各 `terminate()` 一次、`waitForExit` 区分 `scope-exited(confirmed)`/`exited(unconfirmed)`；`started` 失败为 `admitted-may-start`，`exited` 断线为 `unknown{reconcileId}`，绝不重连重放。`src/remote/exec-tool.ts` 把合同包成 `remote_bash` 工具定义（strict 参数、dispatch 的 session/name/signal 定身份），不注册于任何生产行、不在 `src/index.ts` 与 `cordis.patch.yml`。

| 证据 | 结果 |
| --- | --- |
| G4 单元 | `tests/ssh-compat.spec.ts` **7/7**：各 classify 分支（win32/freebsd、本地不支持、`0.1.5-rc.2` 地板下且本地 verdict 仍 supported、缺包、版本混入、私有副本）、真实树 darwin eligible、装载器对非 eligible 闸门在不 import 前拒绝、四包类名核验不实例化。 |
| G3 单元 | `tests/remote-exec.spec.ts` **9/9**：confine 阻塞期撤权 `endpoint-not-registered` 且 0 spawn、generation 变化 `admission-changed`、partial 执行面 `sandbox-unverified`、只读 `mode-denies` 与 0 confine、tool cap `tool-capped`、非法 cwd/timeout；spawn 后撤权在途完成而下次拒绝；scope-exited/exited、超时 terminate 一次 `timeout`、重复 cancel 一次 terminate、started/exited 断线分别 `admitted-may-start`/`unknown` 且恰 1 spawn、输出限幅截断、双 Session 互不取消；真实工具管线下未注册调用报错、伪造 `sessionId`/`toolName` 不影响到达 backend 的真实 sessionId。评审补充：`cwdRelative` 的 NUL 判定原误写为空串（使任何非空相对 cwd 被拒），已改为 `\0` 并补嵌套 cwd 正例（`build/out` → `/work/app/build/out`）及 NUL、反斜杠、`//` 负例。 |
| 回归 | `process-entrypoints` / `optional-peers` / `static-ssh-imports` 与全部 remote-*.spec、registry-operation、shared-registry(-multiprocess)、tool-access、authority-native、shared-registry 共 **14 文件 134 passed / 5 skipped / 0 failed**；本地 PTY/PTC/shell 行为未变，`pnpm compat:check` 通过。 |

**CI 返工（同日）：** 首轮手动 CI（G1a 的 [42339134544](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/42339134544)、G3/G4 的 [42340238250](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/42340238250)）失败，三类原因均属测试与升级脚本、非产品语义：① `upgrade-dsh.mjs` 把 SSH dev 包也重指到矩阵版本（`0.1.5-rc.2` 无该包、其余版本不在 SSH 地板），现仅在目标版本属 `SUPPORTED_SSH_RELEASES` 时保留，否则删除；`check-dsh-compat.mjs` 相应要求 SSH dev pin 全有或全无，全无只允许核心 pin 不在 SSH 地板时出现。② Windows 上控制面按设计为 `platform-deferred`，远端启用用例改为 POSIX 限定，另加在每个平台都执行的 `platform-deferred`/`ready` 断言；`loadDeploymentManifest` 在无 `getuid` 的宿主上显式拒绝。③ 接管用例的在途请求在等待 kill 期间先被拒、处理器尚未挂上，造成偶发未处理拒绝；现立即挂接并接受“旧 epoch 完成”或“已知断线码”两种结果，本机 10 次循环全过。

返工后 [CI run 42341613467](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/42341613467) 全部 **89/89** job success（22 个支持版本 × 四个 runner 与 gate）。抽查：rc.1 ubuntu-latest 上 remote-registry **11**、remote-exec **9**、remote-manifest **25**、ssh-compat **7**、remote-multiprocess **5**、remote-protocol **4** 全部实跑（全量 1267 passed / 93 skipped）；rc.1 windows-latest 上只执行 `platform-deferred` 用例与纯解析/注入式 classify，其余按设计跳过；`0.1.5-rc.2` ubuntu-latest 上远端控制面用例全部实跑，ssh-compat 仅两项真实树用例因低于 SSH 地板跳过。

**未验证与下一步：** 当前控制面本身只受 `remoteEnvironments` 开关与平台约束，测试中可在低于 SSH 地板的宿主上运行；它在没有校验器和后端时不能登记或执行任何远端操作。G5 接线时须让控制面的启用同时服从 `classifySshCapability` 的 `eligible`，使低于地板的宿主静默缺席。`loadHostSshPackages` 尚无生产调用方，连接构造、真实部署绑定与 hostKey 轮换在 G4 后半；`remote_bash` 未暴露给任何组合，真实远端执行依赖受信部署与真实 SSH 端点证据。

## 多执行环境真实 SSH 取证与 G4 接线（2026-11-07）

**状态：在一台维护者临时提供、可丢弃的 VPS 上取得首批真实 SSH 证据，并把官方 SSH 组合接到 G1a/G3/G4 接缝；仍无任何用户入口，部署凭据隔离未证明（unattested）。** 目标：Ubuntu 24.04.5 x86_64、内核 6.8、OpenSSH 9.6p1，1 vCPU / 848 MB。发起端：macOS arm64 / Node 24.18.0 / DSH `0.2.2-rc.1`。凭据、主机别名配置与 `ssh` 包装脚本只存在于仓库外的 `~/.dsh-ssh-test/`（700）；不进仓库或 `.dsh-smoke` 日志。主机密钥按首次使用固定为 ED25519 `SHA256:ZVJcb8gU2m2/IDlL0Zq4y2dzsJxbaMKHqm12KbIQ8D0`，客户端 known_hosts 只含这一把。

**部署：** `dshbuild`（普通账户，Helper/执行）与 `dshxfer`（`internal-sftp`、chroot `$HISTORICAL_PATH_01`、仅 `/import` 可写、禁转发与 TTY）各用独立密钥；工作根 `$HISTORICAL_PATH_02{app,lib}`，根外哨兵 `$HISTORICAL_PATH_03`（root 0644）。Node 24.22.2 官方包校验 SHASUMS256 后装于 root 所有的 `$HISTORICAL_PATH_04`；`@deepseek-ai/dsh-ssh@0.2.2-rc.1` 以 `--omit=dev --ignore-scripts` 装于 root 所有的 `$HISTORICAL_PATH_05`，`lib/helper.js` SHA-256 `8cf436d3…f40e`，与本仓库安装物逐字节相同。Ubuntu 24.04 默认 `kernel.apparmor_restrict_unprivileged_userns=1` 使普通用户 bwrap 失败；加载系统自带的 `bwrap-userns-restrict` AppArmor profile 后 bwrap 可用，全局限制保持开启。**发起端部署前提：** 受验账户的 ssh config 必须 `UpdateHostKeys no`——OpenSSH 默认会把对端其余主机密钥类型自动追加进 known_hosts（Ubuntu 上为 hashed 条目），使"恰有一把密钥"的身份校验拒绝建连；该要求同时适用于直连账户与 broker 凭据根内的 config。

| 证据（均为执行成功） | 结果 |
| --- | --- |
| 上游 live e2e | 上游干净 checkout `66491b05e`：`packages/ssh/ssh/tests/live.e2e.ts` **7 passed / 2 skipped / 0 failed**；两项跳过为未配置的 PTC bootstrap 与远端 LSP，不计通过。上游工作树未被修改。 |
| 远端内核与逐调用策略 | hello：linux、protocol 3、workspace `$HISTORICAL_PATH_06`。`confine` 的 workspace-write 与 read-only 均为 `enforcement: full`（bwrap）；danger-full-access 被拒绝。受限 shell：根内写成功；同机另一根 `$HISTORICAL_PATH_07` 与根外哨兵写入均 `Read-only file system`，哨兵摘要不变；`/tmp` 可写（后端私有临时区，如实披露）。FS 逐调用策略：read-only 写入拒绝、workspace-write 允许。 |
| 受管 SFTP 原语（`scripts/probe-sftp-primitives.mjs`） | 服务器通告 `posix-rename`、`hardlink`、`fsync` 等扩展。`SSH_FXF_EXCL` 首次创建成功、同名二次创建被拒且原字节不变；0 字节与 96 KiB（3 次 WRITE）回读摘要一致；`hardlink` 到不存在目标成功（nlink 1→2），到已存在目标被拒且目标不变——**存在原子 no-replace 发布原语**；`posix-rename` 覆盖已存在目标，不能作 no-replace；`fsync` 可用。 |

**G4 接线（`src/remote/`）：** 清单环境新增必填 `connection`（helper：别名、Node、Helper、默认 workspace；sftp：仅别名）、可选 `exec`（部署控制的 shell、环境变量、时限与输出上限）及必填 `credentialIsolation`。`SshEnvironmentManager` 在构造任何官方类之前依次检查：SSH 能力闸门 `eligible` → helper 传输 → 隔离声明为 `attested`（仅测试可显式放行 `unattested`）→ `ssh -G` 解析出的登录账户等于清单 `account`、StrictHostKeyChecking 开启、ForwardAgent 为 `no`、known_hosts 恰有一把密钥且指纹等于清单 `hostKey`；随后宿主锚定装载四包，在独立 Context 中按上游 live fixture 顺序挂载并核对 hello 平台。每个环境一个连接与代次，dispose 或失联只影响本环境，重开产生新代次。`SshEndpointVerifier` 以 read-only `full` 受限进程取登记目录的 realpath 与 `dev:ino`，路径被重定向即拒绝，登记为对象型身份。`sshExecBackend` 把 G3 合同接到官方 `confine` 与 `spawn`；G3 合同的执行面枚举改为上游实际的 `full`/`partial`，`confine` 失败报告 `not-started`。

| 本仓库测试 | 结果 |
| --- | --- |
| `tests/remote-ssh.live.e2e.ts`（需 `DSH_MULTI_ROOT_SSH_LIVE` 与包装 PATH，CI 中跳过） | **5/5 实跑**：两个环境登记为对象身份；清单 hostKey 改一位或 account 不符在建连前拒绝；Helper 摘要不符由上游连接拒绝且未登记；经双准入的 `remote_bash` 根内写入并回读，根外哨兵与同机另一根写入失败且哨兵不变，退出码 7、输出截断、`sleep 30` 超时终止，只读会话 `mode-denies` 且零次 confine，完全访问会话收敛为 workspace-write 且仍 `full`；A/B 之间撤权零次 spawn；释放一个环境不影响另一个环境的在途命令，重开后旧代次 argv 被 `admission-changed` 拒绝；非 eligible 闸门在 `ssh -G` 前拒绝。 |
| 单元与回归 | `ssh-environment` 5/5（`ssh -G` 解析与指纹比较用夹具）；远端批次 72/72；`verify:all` **1276 passed / 100 skipped / 0 failed**，compose 54、behavior 137、journey 76、packed 136。 |

**未验证与限制：** 部署凭据隔离已由 G5a 的双账户 broker 部署证明（见下文 G5a 节）；直连路径本身仍以发起端同一 OS 用户持有私钥与 ControlMaster socket 运行，清单标为 `unattested`，按 ADR-0032 不得对模型开放。Linux 目标与 Linux 发起端（Ubuntu 24.04，`源测试机`→`目标测试机`，19/19）均已覆盖；hostKey 轮换（清单层错钥拒绝→修正恢复）与真实断线中途注入（SIGKILL 发起端 ssh：不 committed、尸体代次被替换、远端无孤儿进程）已由故障注入 spec 覆盖（见 G5a 节）；macOS 目标、macOS 发起端 broker 路径、其他 Ubuntu 版本、目标侧真实重生成主机钥未覆盖。上游 `spawn` 无独立启动确认，`started` 在返回时即视为成立。

## 多执行环境 G2 单文件复制：三个方向（2026-11-07）

**状态：`local → sftp`、`sftp → local` 与 `sftp → sftp` 三条单文件方向均实跑通过；本地写入走受 Registry/Scope 围栏保护的二进制端口，远端 → 远端经 Host 有界中转。sftp→sftp 已由 broker 路径在两台物理机间复验（`vps-xfer`@目标测试机 → `vps-xfer2`@源测试机）。无用户入口；直连路径清单仍为 unattested（broker 路径见 G5a），Windows 发起端与 macOS 目标未验证。** 合同依据 ADR-0034，格式与拒绝码见[控制面参考](../../reference/multi-environment-control-plane.md)。

**实现（本轮增量）：** `src/remote/local-sink.ts` 新增 `LocalBinarySink`：只能由 `registry.localTransferDestination()` 签发的 `LocalDestinationAuthority` 打开；该 Registry 入口复用 `ctx.fs` 写围栏的根状态、三态 access、per-tool cap 与受保护边界。sink 在目标父目录内以 `EXCL|O_NOFOLLOW` 创建 0600 staging，绑定父目录 dev/ino，逐级拒绝 symlink，按 fd 回读校验，发布前复核父目录身份与目标仍不存在，最后 `link(2)` 无覆盖发布；发布后清理失败只报 `residual`，`publish-unverified` 报 `unknown`。`src/remote/transfer.ts` 按端点方向分派并保持七阶段；远端源先 realpath 父目录/目标、`lstat` 普通文件、`open(P_READ)` 后复检，读完整流后再复核 size/mtime/realpath。两远端端点时 Host 逐块中转，源/目标失联分别报 `source-connection-lost`（清理目标 staging）与 `destination-connection-lost`（`unknown`，不重放）。传输准入新增动作校验：源远端必须 `read`、目的远端必须 `write`，缺配对仍先报 `transfer-pair-not-allowed`。目标名占用 `.dsh-staging-` 前缀为 `reserved-name`。

| 证据 | 结果 |
| --- | --- |
| 实跑（`tests/remote-ssh.live.e2e.ts`，VPS：Ubuntu，kernel 6.8.0-142，OpenSSH 9.9p2） | **19/19 实跑、0 跳过**（copy 组 14/14，约 357 s；G4 SSH 组 5/5，约 74 s）。两个 chroot SFTP 账户 `dshxfer`（`$HISTORICAL_PATH_01`）与 `dshxfer2`（`$HISTORICAL_PATH_08`）各自独立连接。新增：96 KiB 二进制从 `vps-xfer` 下载到本地 primary 与带 aliasId 的附加根，逐字节一致、无 staging；只读本地根在准入前 `local-destination-read-only` 且目录为空；已存在本地目标 `target-exists` 且字节不变；96 KiB 从 `vps-xfer` 经 Host 中转到 `vps-xfer2`，两端独立 SFTP 读取一致、源不变、无 staging，重复复制 `target-exists`；中转中同长改写源 `source-changed` 且目标不存在、目标 staging 为空；部署 cap 1 KiB 下 2 KiB 源 `source-too-large` 且未开始流。原有本地 → 远端用例全部保持通过。 |
| 单元 | `tests/remote-copy.spec.ts` **29/29**（三方向、源变化、源失联、目标失联、hardlink 失联、代次变化、预留名）；`tests/local-sink.spec.ts` **10/10**（发布、覆盖、symlink 父、重定向根、受保护边界、预算、staging 替换、父目录替换、拒删他人 staging）；`tests/local-transfer-authority.spec.ts` **5/5**（primary、三态 access、未知/缺失根、tool cap、authority 不可用）；`tests/remote-registry.spec.ts` **13/13**（新增 transfer 动作校验）。 |
| 回归 | `pnpm lint`、`pnpm typecheck`、`pnpm build`、`pnpm docs:check`、`pnpm pack:check`（193 members）通过；`smoke:compose` **54/0/0**、`smoke:behavior` **96/0/8**、`smoke:journey` **69/0/2**、`smoke:packed` **95/0/8**。本机沙箱 Agent 会话中 `kernel:probe` 无法启动 Seatbelt（`sandbox_apply: Operation not permitted`），behavior/journey 的 8+2 项因此跳过，未计为通过。`pnpm test` 为 **1233 passed / 185 skipped / 18 failed**；18 项失败全部是共享 Registry 的 follower/IPC 用例（`registry-lease`、`registry-multiprocess`、`registry.spec`、`skills-*`、`remote-exec` 的第二挂载等），原因是该会话本身处于 DSH 沙箱，内核 peer 认证按设计拒绝“sandboxed peer”（`src/authority/native.ts`）；同一批用例在改动前以相同方式失败，不能作为本次回归结论，须由未沙箱化的 CI 车道复验。 |
| 环境 | VPS 的两段传输分别使用独立 chroot 账户；`ssh -G` 解析、StrictHostKeyChecking、ForwardAgent no、单把 known_hosts 主机钥与清单一致；SFTP 服务宣告 `hardlink@openssh.com` 与 `fsync@openssh.com`。 |

**未验证与限制：** 结果联合中的 `partial` 在单文件复制中没有产生路径；目录、覆盖、删除仍不在本批。直连路径的远端 → 远端仍是同机双账户（`vps-xfer`/`vps-xfer2` 均在 目标测试机）；跨物理机方向由 broker live e2e 在 `目标测试机`→`源测试机` 间复验。macOS 目标、hostKey 轮换（清单层已由故障注入覆盖：错钥拒绝→修正恢复；目标侧真实重生成未演练）、Windows 发起端（ADR-0030 无限期延后）不在本批；直连路径的真实断线中途注入已由故障注入 spec 覆盖（见 G5a 节）。SFTP v3 无 inode/link count：远端源不能证明 `nlink===1`，同秒同长改写无法由 size/mtime 发现；目标端与父目录绑定依赖部署前提——chroot 账户是该目录唯一写者，路径型 SFTP 本身不能排除替换竞态。本地 sink 最终以路径型 `link(2)` 发布，父目录 dev/ino/realpath 复核缩小但不能消除 same-UID 写者的最后窗口；目的根须没有不可信的同 UID 写者。直连路径的私钥、Control Socket 与 `ssh` 仍由发起端同一 OS 用户持有，清单标为 `unattested`；G5a 的双账户 broker 部署已取得凭据隔离实机证据（见下节）。按 ADR-0032 远端能力仍不得对模型开放；`remoteCopyTool` 仍未在任何生产路径注册。


## 多执行环境 G5 显式工具、面板与单会话旅程（2026-11-07）

> **历史性证据，未经 2026-11-10 外部评审复核**：本节计数与结论按历史记录保留——协议 2 已由协议 3 取代、helper 复制目的已被收窄拒绝；最终计数由维护者末轮验证后填写。

**状态：显式工具、能力投影与远端面板已接入一个专用 headless 测试组合；同一 Session 的"两个本地根 → 构建机 → 设备"旅程先在有界内存端点上跑通，随后已在生产 `broker:` 配置路径上完成真实 SSH 复跑（`tests/remote-journey.live.e2e.ts` 4/4，见 G5a 节）；没有新增生产行，远端实验仍默认关闭、未对模型开放。** 内存旅程的准入、绑定/配对、staging、哈希、无覆盖发布与双准入命令合同全部走真实代码；真实复跑暴露了默认 `backendFor` 工厂的双准入实例缺陷并已修复（`1f4f40a`）。该轮仅覆盖 headless VPS；Web 后续结果见[模型开放门槛](#多执行环境模型开放门槛2026-11-09)。

**实现（本轮增量）：** `src/remote/tools.ts` 新行 `apply(ctx, {enabled, manager?, backends?})`，`inject` 保持兼容门禁与 provider 品牌门禁；`enabled !== true` 时零动作，远端控制面未就绪（关闭/清单无效）时拒绝加载。该行统一注册 `remote_copy` 与 `remote_bash`、安装 `SshEndpointVerifier`（未挂载该行的组合登记固定 `endpoint-unverifiable`），默认连接管理器是清单之上的官方 SSH 栈，默认执行后端是新的 `lazySshExecBackend`（准备阶段才 `open`，未打开连接无法通过最终启动准入）。`src/remote/capabilities.ts` 通过 `systemPrompt.context` 贡献 `multi-root:remote`，只含环境/根 ID、绑定路径、平台、动作与传输配对，绝不含 host/账号/密钥。清单与连接层允许任意 transport 声明 `transfer`（传输适配器是同一别名的 SFTP 子系统），`exec` 仍仅 helper——这样一台构建机才能既收源码又执行构建。`src/remote/panel-contract.ts` 新增独立远端端点（`remotes`/`addRemote`/`removeRemote`），`src/command.ts` 按 Session 推导主根后提供列表与登记/撤销；列表只读状态/清单/记录、不建立任何远端连接，能力按会话模式与工具 cap 收窄；`src/client/remotes-client.ts` 与 Workspace Folders 面板的新“远端环境”区消费它，双语文案与失败码覆盖经 locale parity 校验。`remote_bash` 的未开始结果不再携带显式 `undefined` 的 `operationId`（工具输出必须 lossless JSON）。

**专用组合与旅程：** `tests/support/fake-remote.ts` 提供每环境独立的文件表、SFTP v3 子集、verifier 探针应答与可识别 `build app`/`test app` 的执行后端；`tests/support/remote-tools.ts` 挂真实 Registry/Sessions/Policy/SystemPrompt/Tools/执行器、显式工具行与（可选）命令/面板行。`tests/remote-journey.e2e.ts` 在**同一 Session**：两个本地根各复制一个源文件到构建机（同一远端路径、不同内容）→ `remote_bash` 构建 → 产物经 Host 中转设备；设备与构建机同路径但内容互不串扰；仅传输设备执行拒绝、只读会话三向拒绝、撤销后 `endpoint-not-registered`、`local → local` `direction-unsupported`、面板列表零连接与登记/撤销、未知 Session 与客户端自带路径拒绝、只读能力投影，均有断言。

| 证据 | 结果 |
| --- | --- |
| 单元 | `tests/remote-tools.spec.ts` **8/8**（仅组合挂载时注册、未挂载为 `ToolNotFoundError` 且登记 `endpoint-unverifiable`、控制面未就绪拒绝加载、开关关闭零注册、投影空/敏感字段/降级与只读文案、生产 patch 无该行）；`tests/remote-journey.e2e.ts` **8/8**；`tests/client-panel.spec.tsx` **60/60**（新增远端区四条：关闭状态不发起远端动作、登记后状态更新与请求形态、跨会话迟到应答被丢弃、飞行中重复点击只提交一次）；`tests/command.spec.ts` **58/58**（远端端点关闭态、严格请求体）。受影响批次 **221 passed / 4 skipped / 1 failed**，唯一失败是本会话沙箱下的 `remote-exec` 第二挂载（见下）。 |
| 回归 | `pnpm lint`、`pnpm typecheck`、`pnpm build`、`pnpm docs:check`、`pnpm pack:check`（**197 members**）通过；`smoke:compose` **54/0/0**、`smoke:behavior` **96/0/8**、`smoke:journey` **69/0/2**、`smoke:packed` **95/0/8**（packed 运行中首次 `pnpm add` 因构建审批中断未激活，smoke 自带 remove+add 恢复后通过）。`pnpm test` 为 **1254 passed / 185 skipped / 18 failed**（较 G2 增加 21 项新用例）；18 项失败与 G2 完全相同，全部是共享 Registry 的 follower/IPC 用例（`authority-boundaries`、`b9-review-regressions`、`registry-lease`、`registry-multiprocess`、`registry-operation`、`registry`、`skills-authority`、`skills-registry`、`remote-exec` 第二挂载），原因是本会话本身处于 DSH 沙箱，内核 peer 认证按设计拒绝“sandboxed peer”（`contended` / `owner-without-remote-protocol`），须由未沙箱化 CI 车道复验。 |
| 实跑回归 | 用 G2/G4 的临时 VPS 与 `tests/remote-ssh.live.e2e.ts` 复跑 **19/19 通过**（约 504 s）：真实 SFTP 连接、三方向复制与 SSH 栈用例未受本轮 `transfer`/transport 规则放宽影响；该组仍只覆盖 Linux 目标与 `unattested` 部署。 |
| 组合边界 | 工具行不在 `cordis.patch.yml`；默认与 packed profile 都不存在 `remote_copy`/`remote_bash`，`tests/remote-tools.spec.ts` 直接断言 patch 文本。该行**可命名**：`./remote-tools` export 已随包发出（`lib/remote-tools.js`），部署方自写组合可以列 `multi-root-remote-tools`——面板三区（`remotes`/`addRemote`/`removeRemote`）与区块 UI 本来就在 `multi-root-command`/`multi-root-client` 行内发货，启用清单见控制面参考"部署启用清单"。面板区只在客户端 bundle 可达时出现；列表不建立远端连接，`add` 才经校验器连接。 |

**未验证与限制：** 真实 G5 实跑已由 `tests/remote-journey.live.e2e.ts` 在生产 `broker:` 路径上完成（**4/4**，单 Session 两本地根→构建机→设备→下载，SFTP-only 执行拒绝，未注册/撤销/未声明拒绝，投影无凭据——见 G5a 节证据表）；内存端点旅程保留为快速回归。`capabilities` 只描述部署声明与当前模式/工具 cap，具体调用仍逐次准入；`receive`/`send` 不替代本地目的根 access 检查。面板只投影当前主根的部署条目，Web/Electron 实际入口（真实 GUI 宿主渲染）未覆盖——本部署为 headless VPS，面板合约只经 stub Connection 与内存旅程验证；macOS 目标、Windows 发起端与目标侧真实 hostKey 重生成未覆盖。凭据隔离实机证据已由 G5a 取得，但工具行仍未进入默认 patch，按 ADR-0032 远端能力不得对模型开放；G6 的透明执行路由不在本批。



## 多执行环境 G5a 凭据隔离：本机凭据代理（2026-11-07）

> **历史性证据，未经 2026-11-10 外部评审复核**：本节 broker live/故障注入均为协议 2 时代实机记录，协议 3 票据、目的收窄与运行时守卫未取得实机证据；原始产物属历史附件而非现行绿色证据。

**状态：凭据代理在两台真实 VPS 的双账户部署上完成首次实机验收——Ubuntu 24.04 发起端（`dsh-test` Host + `_dsh_ssh` broker）× Ubuntu 24.04 被控端（`dshbuild`/`dshxfer`/`dshxfer2`），安装器真实执行、受限探针拒绝记录、socket 内核认证与三方向真实 SSH 复制全部通过；工具仍未进入默认 patch、未对模型开放。** 合同见 [ADR-0048](../../decisions/ADR-0048-credential-broker.md)，接口与限制见[控制面参考](../../reference/multi-environment-control-plane.md#凭据隔离本机凭据代理adr-0039)。

**实现（本轮增量）：** `src/remote/broker/protocol.ts` 定义 `protocol: 1` 的有界 JSON-lines（行 ≤ 2 MiB、二进制字段 ≤ 256 KiB、在飞请求 32、进程 8）与八个语义方法；`server.ts` 以专用账户运行，拒绝同 UID 启动与未声明 `attested` 的清单，对每条连接做内核 peer 认证（Host UID + 非沙箱/非 `NoNewPrivs`，Linux 用 `SO_PEERPIDFD`），只转发 SFTP 原语、`confine`、`spawn`/等待/终止/处置；`client.ts` 的 `BrokerEnvironmentManager` 保持官方 manager 的结构面，复制管线、`SshEndpointVerifier` 与双准入命令合同不改，命令输出在退出事件中携带 `scope` 确认；`attest.ts` 在打开任何环境前检查 UID 不同、凭据根对 Host 不可读、socket/目录属主与权限、`hello` 协议/UID/环境覆盖以及部署记录的受限探针；`tools.ts` 的 `broker` 配置先证明后挂载，失败只告警并保持工具缺席；`scripts/ssh-broker/install.sh` 以 root 创建账户、组、0700 凭据根、0750 socket 目录、0640 broker.json 与 launchd/systemd unit，不代建清单或远端公钥。`src/authority/native.ts` 的 peer 认证参数化出 `expectedUid` 与 `allowRestricted`（服务端生产路径绝不放宽）。`src/remote/ssh-environment.ts` 增加 `custody: "broker"`，使托管进程可以打开清单声明为 `unattested` 的端点（证明责任在 Host 侧），而 Host 进程没有这个开关。

**实机部署与首次跑通的修复：** 发起端 Ubuntu 24.04 VPS 上以 root 真实执行 `scripts/ssh-broker/install.sh`（systemd 分支），创建 `_dsh_ssh`（uid 996）、`dsh-ssh-clients` 组、0700 凭据根 `$HISTORICAL_PATH_09`、0750 socket 目录 `$HISTORICAL_PATH_10`、0640 `broker.json` 与 `dsh-ssh-broker.service`；仓库树置于服务账户可读的 `$HISTORICAL_PATH_11`（家目录 0700 会使 `_dsh_ssh` 无法遍历）。首次实跑暴露出五个单测盲区并各自修复：`broker/main.ts` 守护入口曾是 `attest.ts` 的误拷贝（`6410014`）；`listenNative()` 的 unref 轮询计时器使 standalone daemon 打印 listening 后即退出，`main.ts` 增加显式 keepalive（`17f1075`）；`SshEndpointVerifier` 的 `confine` 探针漏传 broker 线协议必填的 `sessionId`（`3634a5b`）；`closeConnection`/`dispose` 绕过 manager 直接 dispose 环境，下个连接的 `open()` 命中缓存拿到已卸载 Cordis fiber 的"尸体"并报 `cannot get required service "ssh" in inactive context`——一切释放改走 manager 并做代次校验（`183f76c`，含重开回归）；broker 线上把 `SftpStatusError`/`SftpConnectionLost` 压平成普通 `BrokerError`，使 transfer 的 `instanceof` 分流失效（缺源 vs 真失败、连接丢失语义），`BrokerSftp.call()` 还原类型化错误（`d4d8e71`）。第二波真实旅程/故障注入又暴露两个生产路径缺陷：默认 `backendFor` 工厂每次调用新建 lazy 适配器，准入 A（confine 绑连接）与准入 B（spawn）拿到不同实例，`remote_bash` 在生产默认路径永远 `admitted-may-start`——工厂按环境缓存实例（`1f4f40a`，含默认工厂回归）；发起端 ssh 被杀后 `resolved` 缓存仍返回尸体代次（上游只标记连接失败、不清我们的映射），`SshEnvironment` 增加 `assertAlive()`（上游 `assertOpen` / broker 通道状态），`open()` 命中缓存先验活、尸体走 `markStale` 再开新代次，broker 服务端逐连接缓存同样验活（`062050b`）。

| 证据 | 结果 |
| --- | --- |
| 协议与边界 | `tests/remote-broker.spec.ts` **13/13**：同 UID 生产启动拒绝、world 目录拒绝、沙箱 peer 拒绝（本会话为沙箱 Host，未沙箱 CI 跳过该负例）、SFTP 原语往返（EXCL/写/fsync/读/硬链接/删除）、`confine`/`spawn` 代次与退出 scope、stale 代次不 spawn、协议方法与字段/长度上限、证明的同 UID/缺探针/凭据可读/socket 缺失/属主不符五类失败、连接关闭后重开环境拿到新代次而非尸体（`183f76c` 回归）。 |
| 工具门禁 | `tests/remote-tools.spec.ts` **9/9**：新增“证明失败不挂载 `remote_copy`/`remote_bash`”；原有“仅组合挂载时注册、未挂载 `ToolNotFoundError`、生产 patch 无该行”保持。 |
| 静态门 | `pnpm lint`、`pnpm typecheck`、`pnpm build`、`pnpm docs:check`、`pnpm pack:check`（**211 members**，新增 `lib/remote-broker.js` 与 `lib/remote-tools.js` 及其声明）通过；`sh -n scripts/ssh-broker/install.sh` 通过。 |
| 回归 | `pnpm test` 为 **1267 passed / 185 skipped / 18 failed**（较 G5 增加 13 项）；18 项失败与 G5 完全相同，仍是本会话沙箱下的共享 Registry follower/IPC 用例，须由未沙箱化 CI 复验。 |
| 实机部署（发起端 源测试机 → 被控 目标测试机，均为 Ubuntu 24.04 x86_64 / kernel 6.8 / OpenSSH 9.6p1） | `install.sh` 以 root 真实执行（systemd）：`_dsh_ssh`(uid 996) / `dsh-test`(uid 1000) 双账户成立；socket `srw-rw---- _dsh_ssh:dsh-ssh-clients`、父目录 0750；`dsh-test` 读 `$HISTORICAL_PATH_12` 被拒绝。`dsh-ssh-broker.service` active，broker `hello` 正常。 |
| 受限探针（发起端 Host 账户下的 `g5a/probe.log`） | bwrap + `NoNewPrivs`（已验证置位）下：读凭据根 `Permission denied`、连 broker socket 拒绝/零字节；未受限控制连接成功收到 `hello`。`confinementProbe` 记录据此置 `verified`。 |
| broker live e2e（`tests/remote-broker.live.e2e.ts` + `DSH_MULTI_ROOT_BROKER_LIVE`，约 9.4 s） | **5/5 实跑**：证明后打开全部 4 个清单环境（`vps-app`/`vps-lib` helper @目标测试机、`vps-xfer` sftp @目标测试机、`vps-xfer2` sftp @源测试机）；confined 命令在被控端 enforcement `full` 执行；local→sftp、sftp→local 逐字节一致；sftp→sftp 由 Host 中转**跨物理机**（`vps-xfer`@目标测试机 → `vps-xfer2`@源测试机）、`target-exists` 拒绝且目标字节不变、read-only 会话在准入前拒绝且零 SFTP 连接。 |
| 直连路径补证（`tests/remote-ssh.live.e2e.ts` + `DSH_MULTI_ROOT_SSH_LIVE`，约 27 s） | **19/19 实跑**于 Linux 发起端 `源测试机`→`目标测试机`（补齐此前只有 macOS 发起端的格子）：身份漂移（hostKey/account/Helper 摘要）建连前拒绝、confined 命令边界/截断/超时、撤权零 spawn、代次失效拒绝、三方向复制、并发同目标恰一提交、中转中同长改写 `source-changed`。注意部署前提：受验账户的 ssh config 必须 `UpdateHostKeys no`——OpenSSH 会把对端其余主机密钥类型自动追加进 known_hosts（Ubuntu 为 hashed 条目），使"恰有一把"校验拒绝。 |
| G5 真实旅程（`tests/remote-journey.live.e2e.ts` + `DSH_MULTI_ROOT_BROKER_LIVE`，约 7.9 s） | **4/4 实跑**于生产 `broker:` 配置路径（`applyRemoteTools` → 证明 → 异步挂载，真实工具注册表轮询就绪）：单 Session 两个本地根 → `vps-app` 构建（confined `mkdir`/`cat`/`echo`）→ 产物经 Host 中转落到 `vps-xfer` 设备 → sftp→local 下载逐字节一致；SFTP-only 设备上 `remote_bash` 准入前拒绝；未注册/已撤销/未声明端点与 local→local 复制全部拒绝；能力投影不含凭据与别名。 |
| 故障注入与回滚（`tests/remote-faults.live.e2e.ts` + `DSH_MULTI_ROOT_SSH_LIVE`） | **5/5 实跑**：hostKey 轮换——错指纹 `host-key-mismatch` 拒绝、修正清单后同栈恢复注册；传输中途 SIGKILL 发起端 ssh——复制绝不 `committed`（`unknown`/`failed`）、尸体代次被验出并替换为新代次、目的端无 `killed-relay.bin` 与 `.dsh-staging-*` 残留；在飞取消——preflight 边界武装 AbortSignal 落入读循环，结果 `failed`/`cancelled`、无目的件与残留（`'cancelled'` 状态只由发布前准入变化路径产生）；杀 SSH 会话后远端无孤儿 `sleep`（sshd 回收进程组）；注册表级回滚——撤销后历史引用 `endpoint-not-registered`、重新准入后新目标名 `committed`。 |
| broker 侧故障注入（`tests/remote-broker-faults.live.e2e.ts` + `DSH_MULTI_ROOT_BROKER_LIVE`，root watcher 消费触发文件代打信号） | **2/2 实跑**：杀 `_dsh_ssh` 全部 ssh（含 ControlMaster mux）——传输绝不 `committed`，服务端验出尸体并新代次重开，客户端 `open` 观察到新代次（服务端为代次权威），目的件缺失（BrokerSftp 无 readdir，以 lstat 断言）；SIGKILL broker 守护进程——所有在途/后续操作 fail-closed、双代次表清空为 `stale`，systemd `Restart=on-failure` 拉起后必须**重新 attest** 才恢复托管（无静默回退）。实跑抓出并已修复两个生产缺陷：①`SftpClient` 未监听 `child.stdin` 的 `error`——被杀 ssh 的 EPIPE 以未处理事件**令整个 broker 崩溃**（殃及所有环境），现按传输丢失处理（`sftp.ts`）；②broker 客户端 `open` 永远复用本地缓存 env——服务端重开新代次后客户端继续回放尸体代理，现每次询问服务端并按代次更替（`broker/client.ts`）。 |
| 目标侧真实主机钥轮换 | **实机演练**：在 目标测试机 真实重生成 `ssh_host_ed25519_key`（旧钥备份于 `$HISTORICAL_PATH_13`）后，`dsh-test` 与 `_dsh_ssh` 双侧 ssh 均以真实的 `REMOTE HOST IDENTIFICATION HAS CHANGED` 拒绝——身份漂移拒绝不仅由清单指纹层产生；随后更新两账户 known_hosts 与 manifest/`ssh-live.json` 指纹（注意：`vps-xfer2` 连 源测试机 loopback，其 `hostKey` 必须是 源测试机 的指纹 `swMIQ4My`，不能随 目标测试机 一并改）→ 连通恢复、双路径冒烟通过。 |

**未验证与限制：** `danger-full-access` 与这些凭据互斥，但运行时不检查其他 Session 的模式。托管进程崩溃后 unit 会重启，Host 不自动重建连接，必须重走证明（已由 broker-daemon 用例实证）。聚合配额、吊销清单与审计轮转已实现并实机验证（清单 `quotas`/`revocations` + `auditMaxBytes`/`auditKeep`，2026-11-11 `源测试机` 探针证据见 F13 行），窗口随 broker 重启重置、吊销只随清单生效；on-disk 配额未实现。SFTP 语义代理只覆盖 transfer/verifier 使用的方法，没有 readdir/extended；命令输出在退出时一次性返回（受部署上限约束）。安装器的 Linux systemd 与 macOS launchd 分支均已实机验证（launchd 腿见本节末"macOS 发起端/目标与 Windows 腿"实机记录，实跑抓出并修复两处 Darwin 缺陷）；原生 Windows 发起端未覆盖且按 ADR-0030 无限期延后。回滚演练覆盖注册表层（撤销→历史引用拒绝→重新准入）与单操作在飞取消（AbortSignal→`cancelled` 语义），编排层（禁新准入排队、批量取消在飞任务、对账后恢复原 profile）未演练——目前不存在该编排队列实现。Web 面板的渲染侧需要真实 GUI 宿主（本部署为 headless VPS），面板合约只经 stub Connection 与内存旅程验证。默认 patch 未加入 broker 行或任何远端工具。


## 多执行环境模型开放门槛（2026-11-09）

> **历史性证据**：本节"1362 passed/131 skipped"、pack 211 members、"12/12"、Linux 12/12 与 GUI（stub 旅程、Chromium 叙述）均为历史断言；2026-11-10/11 的现行证据与 2026-11-11 外部评审见下方各节及[评审报告](../../reviews/2026-11-11-model-entry-evidence-review.md)。当前状态：评审通过；模型入口仍默认关闭，等待维护者签收与逐部署开启决定。

**范围：先审查 DSH `0.2.2-rc.1` 的 Linux → Linux 专用实验 profile。** 默认组合保持关闭。此前 Ubuntu 双账户实机已覆盖三向复制、受限命令、故障注入和真实目标主机钥轮换。直连和内存后端的取证继续用于回归。逐项启用配置与回滚步骤见[控制面参考](../../reference/multi-environment-control-plane.md#部署启用清单)。

| 开放前事项 | 当前证据与退出条件 |
| --- | --- |
| 工具与凭据边界 | 包入口只有 broker 路径。要求 Host 的 SSH 版本与可选包、provider 品牌、就绪的 Registry、受限默认模式与可选预设、部署侧隔离证明。协议 2 核对实际清单摘要；同名环境或协议旧版无法通过证明。部署侧入口取证已在参考装置完成（见本节末段）：shell/PTY/PTC 三入口 × 只读与工作区可写两模式均拒绝凭据根与 socket，伪造完全访问会话收到 hello 的对照同时记录了该排除的必要性。任何实际部署仍须以同法在其自身环境复核。 |
| 安装、升级与回滚 | tarball 包含 broker 入口和安装脚本；Linux 安装器生成负责重建运行目录的 systemd unit。卸载取消并等待工具，复制在最终发布前复查取消，命令在最终 spawn 准入前复查取消。注册、覆盖拒绝、已提交物保留、未知结果对账与回到本地 profile 按部署手册验收。 |
| Linux 实机复验 | Debian 12 arm64 双容器（内核 6.12.76、OpenSSH 9.2p1、Node 24.22.2、DSH 0.2.2-rc.1）使用真实 sshd、独立 Host/broker UID 与 chroot SFTP。Host 可读共享清单、不可读 broker 配置与私钥。普通 Host 收到 hello，bwrap 探针和打包 headless 的原生 `bash` 在只读、工作区可写两种模式下均读不到私钥、用不了 broker socket。真实 broker **6/6**、会话旅程 **4/4**、broker 故障注入 **2/2**、Linux 多 Host **5/5**，覆盖大输出截断、SSH 中断换代和 daemon 崩溃后重证。独立的 systemd 容器实跑安装、停服务删除运行目录、重新启动重建目录和 SIGKILL 自动重启，并核对 0750 目录、0660 socket 及属主。 |
| 正式组合与 GUI | Linux 上通过 `dsh plugin add <tgz>` 安装并启动 headless/Web 组合。两者均实际挂载工具、登记 SSH 根，停用重启后远端能力消失、本地根及原生服务可用。headless 以 loopback 脚本模型完成真实回合，确认收到两项工具和 `remote_bash` 的退出状态、输出。Chromium 实际打开 Workspace Folders，SFTP 根的登记、能力更新和撤销均走真实 RPC。现有 Rivetdeck 工作树的 DSH 为 `0.2.1-rc.5`，低于 SSH 地板；可用桌面宿主另行验收。 |
| 平台与评审 | macOS 发起端（含 launchd）与 macOS 目标已于 2026-11-11 实机验证（见本节末"macOS 发起端/目标与 Windows 腿"）；Windows 目标在清单解析即拒（`windows-target-unsupported`），原生 Windows 发起端仍按 ADR-0030 延后，G6 透明路由另行处理。只有在对应部署完成取证和外部评审后，才启用该部署的模型入口。 |

真实模型回合发现两项工具的输出渲染误用了输入参数。改为读取宿主渲染回调的结果参数，并用调度管线分别断言两项工具的模型侧内容等于规范化结果。打包、兼容、类型、lint、文档检查通过；原生本地全量回归为 **1362 passed / 131 skipped / 0 failed**（Linux SSH 实跑单列）。新增结果渲染回归后 `remote-tools.spec.ts` 为 **12/12**。

**部署侧入口取证（同批次补全）**：`scripts/probe-remote-entry-isolation.mjs` 在 `scripts/ssh-broker/probe/` 的一次性容器（Debian 12 arm64、Node `24.22.2`、DSH `0.2.2-rc.1`、插件包 `0.1.15`）中实跑：root 真实执行打包 `install.sh`（systemctl 打桩、daemon 由编排脚本直接拉起），`_dsh_ssh`（uid 999）持有 0700 凭据根与 0750 socket 目录，`dsh-test`（uid 1001）作为 Host UID 经 `dsh plugin add` 安装专用 `remote-exp` profile 并施加部署 patch。Registry 取得 shared 权威（`authority: active`）、远端平面 `ready`、broker 证明通过（协议 2 + 清单摘要）、`remote_copy`/`remote_bash` 挂载。Host 对照：socket hello 正常、凭据根 `EACCES`、`broker.json` `EACCES`、清单可读。两个受限模式 × 三个 Agent 进程入口——shell 公开执行器、`DSH_PTY_SESSION_ID` 标记的 Agent PTY（真实交互 bash 全程转录）、PTC `run`（run_code）——全部 `enforcement: full`（bwrap + `NoNewPrivs`）：读凭据根一律 `EACCES`，连 broker socket 一律 `closed-no-data`（连接经内核凭据检查被拒、无 hello）。预设表只含 `read-only`/`workspace-write`。提权面：伪造 `sandbox/mode: danger-full-access` 事件使 `sandboxPolicy.resolve` 解析出完全访问、shell 以 `enforcement: null` 无沙箱执行——凭据根仍 `EACCES`（账户隔离兜底），但 socket **收到 broker hello**，反向实证了完全访问会话必须与这些凭据互斥；沙箱内 `NoNewPrivs=1`、无 sudo、su 认证失败、`unshare -r` 只得命名空间内伪 root。原始证据：[remote-entry-isolation-evidence.json](../../reference/remote-entry-isolation-evidence.json)。另实踩并记录一个部署陷阱：profile patch 层对同一行的 `config` 是整体替换，`multi-root-registry` 必须重写 `sharedStorageRoot`/`leasePath`，否则 medium 缺席、远端平面停在 `owner-without-remote-protocol`、工具行正确拒挂。macOS 发起端/目标已于 2026-11-11 实机验证（见下节"macOS 发起端/目标与 Windows 腿"）；Electron 宿主仍待验；外部评审与 push/CI 待维护者指令。

## 外部评审整改与开放阻断（2026-11-10）

**2026-11-10 状态：BLOCKED——模型入口保持关闭。**（2026-11-11 复核后状态见[评审报告](../../reviews/2026-11-11-model-entry-evidence-review.md)：证据达标，但模型入口仍默认关闭，等待维护者签收。）本次外部评审的 F1–F21 整改为**工作树修复，尚未提交、未发布、未经维护者签收**（SSH 分支 43 个提交已全部 rebase 到 `main + experiment = 3e84d85`；备份引用与 pre-rebase bundle 保留，最终提交号由维护者注记）。本节之上的 G5 实机/测试证据均为**历史性、未经本轮复核**：协议 2 已被协议 3 取代、helper 复制目的已被收窄拒绝、此前"1362 passed / 131 skipped / 0 failed"、pack **211 members**、"12/12" 等计数全部作废待重跑，最终计数由维护者在末轮验证后填写。先前 GUI 断言（stub 旅程与 Chromium 记录）同样只有历史叙述、本轮无原始产物——当前仅有本地单元/DOM 覆盖，无 GUI 签收。

| 编号 | 主题 | 处理 | 备注 |
| --- | --- | --- | --- |
| F1 | 远端父目录/staging 路径遍历 | fixed | `assertRemoteParent`/`assertRemoteStaging` 逐段 lstat 含终点；读后再检；属纵深防御，**不提供 dirfd 级 TOCTOU 保证**——生产目的端仍须独立 chroot SFTP-only 账户。 |
| F2 | 断线语义与超时 | fixed | started 后丢线 `unknown`+reconcileId 绝不重试；发布后清理失败为 `residual`；请求超时销毁连接、在飞请求 typed-lost。 |
| F3 | Full-access 运行时守卫 | fixed（代码） | `profile-guard.ts` 包裹 resolve/confine/spawn/spawnTerminal/approval：拒绝一切 `danger-full-access` 解析/策略/回放/单发升级，256 票据 FIFO+TTL 30s 绑定受限 argv 快照；标记 PTY 经 `DSH_SESSION_ID` 活体会话重新准入。 |
| F4 | 原始 spawn 接缝与目的收窄 | fixed（代码） | 未受票据约束的 spawn（LSP/job 形、伪造/回放/突变 argv、过期票据）fail-closed；守卫覆盖受支持服务接缝，第三方 `node:child_process` 直引与用户终端标记属部署信任假设；`environment.transfer.destinationIsolation:"chroot-sftp"` + 证明期同账号 helper/exec 拒绝。 |
| F5 | rebase 与版本标号 | fixed | SSH 分支 rebase 到 main+experiment；凭据 broker 决策当时改为 0040（原 0039，与主线 worktree ADR 撞号；现为 ADR-0048）；包版本 `0.1.17-ssh.1` 未发布、无 tag/publish。 |
| F6 | 清单加载信任链 | fixed | 生产要求文件与**每一级祖先** root 所有、非 symlink、不可被 group/other 写；Host/broker 均不得 root；测试内部加载器才放宽（无生产开关）。 |
| F7 | OpenSSH 身份解析 | fixed | `HostKeyAlias` 逐字（含 `none`）、`[hostname]:port`、Strict/Batch/ForwardAgent/UpdateHostKeys 强制、全部 user+global 源合计恰一钥。 |
| F8 | confine/spawn 绑定 | fixed | 票据绑定 confine **返回后**的 argv+代次+workspaceRoot；非空 `LD_*`/`DYLD_*`/`NODE_OPTIONS`/`NODE_PATH` env 拒绝；票据校验失败或使用消耗。 |
| F9 | SFTP 代次权威 | fixed | 每请求服务端代次复核；旧 proxy 不路由新会话；dispose 不删更新缓存项。 |
| F10 | 部署图/临时目录 | fixed | 凭据根只放密钥/config/known_hosts；ControlMaster/helper 暂存为 broker mkdtemp+PrivateTmp；unit 于 2026-11-10/11 实机验证（`ActiveState=active`/`PrivateTmp=yes`/`ProtectSystem=strict`）。 |
| F11 | 校验器清理 | fixed | 中止/超时/完成均 terminate+有界 drain，timer/listener 必清。 |
| F12 | 证据账本与实机 | narrowed / partially verified | 既有 Linux/GUI 断言标为历史未复核；本轮本机原始日志与 JSON 已归档（见下）。**Linux 实机已于 2026-11-10/11 复验**（见本节末"协议 3 实机复验"）：真 systemd unit/`ActiveState`/`PrivateTmp`、socket 私访探针、chroot 写者隔离均已取得现行证据；GUI 宿主证据已于 2026-11-11 本机 DSH Web 实测取得（见本节末"GUI 宿主实测"）；跨平台矩阵（macOS 发起端/目标、Windows fail-closed）已于 2026-11-11 实机补齐（见本节末"macOS 发起端/目标与 Windows 腿"）。 |
| F13 | 配额/审计/吊销 | verified（代码 + 实机） | **已实现并实机验证**（2026-11-11，`源测试机`，协议 3）：清单 `environments[].quotas` 与顶层 `quotas` 滚动时间窗预算（操作数 + SFTP 载字节，`quota-exceeded`）、清单 `revocations` 显式拒绝清单（`environment-revoked`，`dispose` 放行清理）、broker 内建审计轮转（`auditMaxBytes`/`auditKeep` 链式滚动，0600，拒绝外国属主/symlink 占用）；确定拒绝在 SFTP 代理透传原 code，不再误报 `SftpConnectionLost`。实机探针：vps-xfer env 窗口第 4 次操作命中、全局窗口第 7 次跨环境命中、`vps-xfer2` `environment-revoked`、2.1MB 审计文件按预算轮转且 `.1-.3` 保留上限成立；生产清单已声明 1h 预算（env 20k ops/512GiB、全局 50k ops/1TiB），`remote-broker.live` 在声明预算下复验 6/6。实机另抓出并修复跨窗口记账泄漏（`336951d`）。on-disk 配额未实现（systemd/文件系统配额可作纵深）。 |
| F14 | 安装器与部署手册 | fixed（本轮） | 依赖解析 preflight（`createRequire` 锚定 broker 入口，核验 dsh/cordis/四 SSH peer 可解析）、可复现依赖树命令与 ssh config 清单、out-of-band 指纹验证说明、logrotate 示例；安装是部署操作，**不构成**隔离认证。 |
| F15 | broker 自报能力 | fixed | `hello.sshCapability` 由 broker 自身状态派生，缺席/为否/畸形即拒绝。 |
| F16 | 凭据根证明 | fixed | lstat 真实非 symlink 目录、broker 属主、恰 0700，先于 `R_OK` 探针；root Host/broker 拒绝。 |
| F17 | 陈旧注释 | fixed | exec/transfer 工具引言与 ssh-packages 引言已纠正。 |
| F18 | 回归覆盖补齐 | fixed | 新增/扩充远端 manifest、broker 票据/代次/env、profile guard 单测与集成 spec、SFTP 帧与校验器用例；历史协议 2 样例与伪造 hello 记录标为反例，不作现行守卫证据。 |
| F19 | SFTP 帧校验 | fixed | 短帧、截断 VERSION/STATUS/ATTRS、分片与 EOF 已覆盖；畸形帧 fail-closed。 |
| F20 | 远端 cwd 校验 | fixed | `verifyCwd` 后端方法：准入 A 经 `assertRemoteParent` 复核远端 cwd，fake 后端可省、生产后端必提供。 |
| F21 | 终端信任边界 | fixed（文档/行为） | `DSH_PTY_SESSION_ID` 标记的 Agent 终端走会话重准入；未标记为用户终端按部署信任假设放行。 |

**开门前置状态**：平台矩阵已于 2026-11-11 补齐——macOS 发起端/目标实机验证、Windows 目标在配置入口即拒、原生 Windows 发起端按 ADR-0030 延后不实施；F13 三项、磁盘重载会话与其他 profile 隔离、GUI 宿主均已实机验证。**2026-11-11 外部评审已通过（PASS）**，见[评审报告](../../reviews/2026-11-11-model-entry-evidence-review.md)。剩余为维护者签收与逐部署开启决定；默认组合仍不挂 `remote-tools`、不启用 `remoteEnvironments`。

**协议 3 实机复验（2026-11-10/11，`源测试机` 发起端 × `目标测试机` 被控端，协议 3 + 目的收窄 + profile-guard 全部生效）**：打包 `0.1.17-ssh.1` 部署于 root 所有的 `$HISTORICAL_PATH_14` 依赖树；`dsh-ssh-broker.service` `ActiveState=active`/`SubState=running`、`PrivateTmp=yes`、`ProtectSystem=strict`、真私有 `$HISTORICAL_PATH_15`；凭据根 `0700 _dsh_ssh`、socket `0660`/`0750`、hello 协议 3（`sshCapability.eligible`，四环境）；bwrap `NoNewPrivs` 下探针：凭据根 `EACCES`、socket 连接零字节关闭。`remote-broker.live` **6/6**、`remote-broker-faults.live` **2/2**（root 侧 fault-watcher 消费触发文件，杀 `_dsh_ssh` 的 `vps-build` ssh 于 `preflight` 注入点——绝不 committed、尸体代次替换；SIGKILL daemon 后双代次转 `stale`、须重证）、`remote-ssh.live` **19/19**、`remote-journey.live` **4/4**（生产 `broker:` 路径；helper 目的 `remote_copy` 实机 `transfer-pair-not-allowed`，种子改走 `remote_bash`）。chroot 写者隔离：两个 xfer 账户各自 `/` 仅见自己的 `/import`，`/srv` 不存在，互不可见。本轮实跑另抓出并已修复四个缺陷：`UpdateHostKeys` 的 `-G` 归一化（`51d8f99`）、SFTP 会话继承 `ControlMaster auto` 破坏逐会话代次隔离（`adcf4df`）、`wellFormedReply` 把 NAME(104)/ATTRS(105) 写反致真帧误判断连（`56d972a`）、journey mount 缺 `subprocess` 注入致工具永不挂载与 faults 注入点/负载校准（`19ebb07`）。本段证据为现行有效，不再依赖协议 2 历史记录。

**F13 实机复验（2026-11-11，`源测试机`，`f02501a`/`336951d` 部署件，socket 直探针 `$HISTORICAL_PATH_16`）**：配额——清单 `vps-xfer` env 窗口 `{60s,3 ops,1MiB}` + 顶层全局 `{60s,6 ops,16MiB}`：openSftp+2 realpath 准入后第 4 次操作 `refused:quota-exceeded`（env 窗口）；`vps-xfer2` 在全局窗口第 7 次（跨连接累计）命中；被拒操作不计费（记账泄漏修复 `336951d` 前后对比可证）。吊销——清单 `revocations:[{environmentId:"vps-xfer2"}]`（新摘要 `b4df5c73bf4e` 已生效）：`openSftp vps-xfer2` → `environment-revoked`，`vps-xfer` 不受影响。审计轮转——`auditMaxBytes`/`auditKeep` 实机生效：重启后首写即把 2.1MB 追加文件滚为 `audit.jsonl.1`；`512B×keep3` 下 `.1-.3` 全为 `0600 _dsh_ssh`、`.4` 不出现；审计行现含 `environment` 字段。恢复后生产清单已声明预算（env `{1h,20000 ops,512GiB}`、全局 `{1h,50000 ops,1TiB}`，摘要 `9ad5926a1ebb`），broker.json 显式 `8MiB×4`；`remote-broker.live` 在声明预算下复验 **6/6**。

**磁盘重载会话与其他 profile 实机复验（2026-11-11，`源测试机`，`93c37d5` 起探针在真实 `dsh plugin add` 部署上运行，原始证据 [`remote-entry-isolation-evidence-20261111.json`](../../reference/remote-entry-isolation-evidence-20261111.json)）**：scratch `DSH_HOME` 下 `remote-exp`（受限 patch + remote-tools 行）与 `stock-exp`（同插件、无 patch）双 profile，协议 3 attestation 后 `remote_copy`/`remote_bash` 挂载。受限入口矩阵（bash/PTY/PTC × workspace-write/read-only）与伪造 `sandbox/mode` 守卫拒绝重验一致（凭据根 `EACCES`、socket `closed-no-data`、NoNewPrivs 生效、su/sudo/unshare 均无出路）。磁盘重载——经 `ctx.sessionPersistence` 真实后端落盘 `sessions/.../probe-reload/session.v4.jsonl.zstd`，新 boot 经 `open('read')` 读回并以 `eventState: shared-frozen` 重放进 store：解析仍 `workspace-write`、该会话 Agent PTY 仍受限、socket 拒。篡改对照——同型 zstd 双帧重写 `sandbox/mode` 为 `danger-full-access` 后重载：后端读路径接受格式良好事件，`sandboxPolicy.resolve` 被守卫 `remote-profile-full-access` 拒绝，盘上状态无法洗白提权。其他 profile——`stock-exp` 实机显示其预设表含 `danger-full-access`、伪造模式可解析（部署危害实证：此类 profile 绝不可承载 Agent 入口）；其受限 spawn 仍凭据根 `EACCES`+socket `closed-no-data`（broker 按沙箱态拒绝，不认 profile 名）；打同一受限 patch 后预设表仅两项受限、`forgedMode` 由守卫拒。

**GUI 宿主实测（2026-11-11，本机 macOS arm64，真实 `dsh plugin add <tgz>` + `dsh web` 组合 + Google Chrome 经 CDP 驱动，脱敏证据 [`remote-gui-host-evidence-20261111.json`](../../reference/remote-gui-host-evidence-20261111.json) 与面板截图 [`remote-gui-panel-final-20261111.txt`](../../reference/remote-gui-panel-final-20261111.txt)）**：scratch `DSH_HOME` 下 `guiweb` profile（`dsh-base + dsh-web-app + 0.1.17-ssh.1` tarball，同形受限 patch）。部署形态按生产语义复刻：清单 `$GUI_MANIFEST` root:wheel 0644、祖先链全部 root 属主（不经测试旁路），摘要 `bd7141c4d0b5` 与 broker hello 一致；socket 路径 `$GUI_BROKER_SOCKET` 为 `srw-rw---- 996:staff`、父目录 `drwxr-s--- 996:staff`，由本机 uid-996 前哨进程转发到 `源测试机` 真实 broker；凭据根 `$GUI_CREDENTIAL_ROOT` `drwx------ 996`，本账户 `accessSync` 实测 `EACCES`。attestation 全项通过后 remote-tools 挂载：脚本模型端点录到的真实 `/v1/messages` 请求中 `tools` 表末尾含 `remote_bash`/`remote_copy`。Chromium 中打开 Workspace Folders 对话框：远端环境区块先列 `vps-app`/`vps-xfer` 未登记；CDP Network 抓包证实 `list`/`remotes`/`addRemote`/`removeRemote`/`skillsChanges` 均走插件 Connection RPC——`addRemote` 返回 `state:registered` + 能力投影 `{read,write,exec,send}`，`removeRemote` 返回 `unregistered`+`remote-unregistered` 且 `remotes` 复核持久化态；面板随后显示"已登记 当前能力：读取, 写入, 执行, 发送"。停用复验：`remoteEnvironments.enabled:false` 重启后工具表无 `remote_*`、面板显示"远端控制面不可用：disabled"，本地主根/附属根与原生服务不受影响。模型为脚本化端点（与 smoke/journey 同约），其余链路（profile 组合、attestation、注册表、RPC、渲染）全部真实。

**macOS 发起端/目标与 Windows 腿实机复验（2026-11-11，本机 macOS arm64 launchd 部署，原始证据 [`remote-macos-matrix-evidence-20261111.json`](../../reference/remote-macos-matrix-evidence-20261111.json)）**：`install.sh` Darwin 分支实跑抓出并修复两处真实缺陷——`next_id` 对 `/Groups` 错查 `UniqueID`（组记录用 `PrimaryGroupID`），产出无 GID 的用户/组记录使 `id` 无法解析；`DSH_SSH_BROKER_NODE` 指向宿主用户主目录内二进制时隐私框架拒系统 daemon 执行（launchd `access(X_OK)` EACCES → EX_CONFIG），node 复制到 `$HISTORICAL_PATH_17` 并在脚本头注释固化该约束。部署形态：`_dsh_ssh`（uid 502）+ `dsh-ssh-clients`（gid 702，含 example-account）、凭据根 `$HISTORICAL_PATH_18` `0700`（Host 账户 `ls`/`cat` 实测 `EACCES`）、socket `$HISTORICAL_PATH_19` `srw-rw---- _dsh_ssh:dsh-ssh-clients`、`$HISTORICAL_PATH_20` `0640 root:_dsh_ssh`（8MiB×4 审计）、root 属主生产清单（不经旁路加载，摘要 `7e2c3c91`）、`system/com.dsh.ssh-broker` 以 `_dsh_ssh` 常驻（RunAtLoad+KeepAlive）。hello：协议 3、`brokerUid:502`、五环境、`sshCapability.eligible:true`、摘要一致。实操：①`mac-local`（darwin 目标，`example-account@127.0.0.1`）open→helper hello `{platform:"darwin"}`→confine 生成 seatbelt 段（仅 workspace+$HISTORICAL_PATH_21 可写）→spawn→stdout `Darwin arm64`/`example-account`/`501`→exit `scope:true`；②`vps-app`（`目标测试机` Linux 目标）open `{platform:"linux"}`→bwrap→`Linux x86_64`/`dshbuild`/`1000`→`scope:true`；③`vps-xfer`→`目标测试机` 与 `vps-xfer2`→`源测试机` openSftp v3→`realpath /import`+`lstat`（chroot uid 1001）。Host 侧 `attestBroker` 对生产部署**全项通过**并 `manager.open('mac-local')` 成功。负向：未知环境 `unknown-environment`、未签发票据 `confinement-ticket-invalid`、cwd 逃逸 `confinement-ticket-cwd`、`danger-full-access` 在协议 schema 边缘即拒（仅 `read-only`/`workspace-write` 可表达）。审计 `audit.jsonl` `-rw------- _dsh_ssh` 如实记录每次 ok/refused/rejected。Windows 腿：`windows`/`win32` 目标在清单解析即 `windows-target-unsupported`、`freebsd` `unsupported-platform`（整份清单失效、不触网），`tests/remote-manifest.spec.ts` **42/42**；原生 Windows 发起端按 ADR-0030 延后（无自定义 SSH/SFTP 客户端、WSL 桥或 POSIX 转发）。未覆盖：受限 profile 的 Agent-sandbox 隔离探针在 macOS 未重跑（探针为 Linux 形态）、Electron 宿主、独立第二台 macOS 目标（本腿以 loopback `example-account@127.0.0.1` 走完整 ssh+helper+seatbelt 路径）。`源测试机` 部署清单不声明 `mac-local`，各部署内部摘要自洽。

本轮仅在 macOS arm64 / Node `24.18.0` / DSH `0.2.2-rc.1` 执行，不替代 Linux→Linux 专用 profile 的部署验收。[机器证据清单](../../reference/ssh-review-20261110-evidence.json)、[完整 Vitest JSON](../../reference/ssh-review-20261110-vitest.json)、[检查日志](../../reference/ssh-review-20261110-checks.txt)保留本轮原始结果（日志仅隐去临时 Web token、去除 ANSI 颜色并清理行末空白）。2026-11-11 复核在 HEAD `83b76e4` 重跑为 **1562 passed / 131 skipped / 0 failed**，见[评审报告](../../reviews/2026-11-11-model-entry-evidence-review.md)与 [`ssh-review-20261111-vitest.json`](../../reference/ssh-review-20261111-vitest.json)。

以下为 2026-11-10 本轮本机记录；现行复核基线见上句与评审报告。

- 全量：**1545 passed / 131 skipped / 0 failed**，106 个文件通过、8 个文件跳过；Linux live 与其他平台跳过项不计通过。
- lint 首轮发现三个测试参数未使用；仅改为下划线参数名，lint 复查通过；受影响两文件的[增量复查](../../reference/ssh-review-20261110-lint-delta.json)为 **48 passed / 0 failed**。compat、host/client 类型、build、kernel probe（仅 Seatbelt 可用）通过。
- smoke compose **54/0/0**、behavior **137/0/0**、journey **76/0/0**（通过/失败/跳过）；pack 为 **222 members**，packed behavior **136/0/0**。这不是沿用历史 211/213 的计数。
- Auto Review fork 静态检查通过；运行 smoke 因本机不是其专用 `0.2.1-rc.2` 目标而跳过，不计通过。GUI 宿主证据已由上方"GUI 宿主实测"段取得；macOS/Windows 矩阵证据仍缺；磁盘重载 Session、真实其他 profile、Linux unit/PrivateTmp/chroot 证据见上方实机复验段。
- `docs:check` 通过；安装器通过 `sh -n` 与隔离的依赖解析正负例（未执行账户/unit 配置）。预检查发现 DSH 无根导出后已改用其公开 `package.json` 入口解析，原失败与修正后记录一并保留。
- 入口探针已改为记录 Full-access 守卫拒绝并增加 raw/LSP-like/job-like 接缝观察，且已扩展磁盘重载会话与其他 profile 实测段；2026-11-11 起在 `源测试机` 的 Linux 实机运行，原始证据见 [`remote-entry-isolation-evidence-20261111.json`](../../reference/remote-entry-isolation-evidence-20261111.json)。其他 profile 的静态文本清点保留作清单对照，运行时隔离结论以实测段为准。

## 模型入口证据外部评审（2026-11-11）

**状态：证据评审通过（PASS）；模型入口仍默认关闭，等待维护者签收与逐部署开启决定。** 详细结论、逐项证据、非阻断追溯缺口与签收条件见[评审报告](../../reviews/2026-11-11-model-entry-evidence-review.md)。复核基线为 `feat/ssh-workspace` @ `83b76e4`、包 `0.1.17-ssh.1`、DSH `0.2.2-rc.1`。

- 全量回归在 DSH Agent 沙箱外重跑：**1562 passed / 131 skipped / 0 failed**（1693 tests，106 files passed / 8 skipped）；原始报告为 [`ssh-review-20261111-vitest.json`](../../reference/ssh-review-20261111-vitest.json)，复核日志为 [`ssh-review-20261111-checks.txt`](../../reference/ssh-review-20261111-checks.txt)。2026-11-10 清单中的 1562 计数此前没有对应的归档报告（其引用的原始报告是 F13 前的 1545）；本次重跑补上了原始产物，11-10 报告保留为历史。
- 复核确认：Linux 入口隔离的机器记录、F13 代码与单测、GUI 面板 RPC 与截图、磁盘重载/篡改拒绝、其他 profile 的运行时审计、macOS/Windows 矩阵均与记录一致。F13 受控探针（临时 broker，配额/吊销/审计轮转）、`remote-broker.live` 6/6、真实 `源测试机` unit、GUI 工具目录/停用态与面板 RPC、入口探针原始日志均已归档（见[评审报告](../../reviews/2026-11-11-model-entry-evidence-review.md#复核产物)）。macOS 原始命令转录仍缺少（R6）。**其他 profile** 已在 `源测试机` 上运行时核实：`remote-exp`/`stock-exp` 都只有受限预设、伪造 `danger-full-access` 均被守卫拒、无第三个 profile，`stock-exp` 已不再是 unpatched 状态；维护者签收只需确认不新增 unrestricted profile/入口。
- 默认组合未改动：`cordis.patch.yml` 不含 `remote-tools`，不配置 `remoteEnvironments`；开启是维护者对具体部署的人工决定，不是评审通过的直接结果。

## SSH 分支 rebase 到 v0.1.18 之后的主线（2026-11-13）

`experiment` 落后 `main` 且无独有提交，按快进追平到 `50fb77b`（`v0.1.18` 之后合并的 CI 分组提交 #51，减少 runner 数量）；`feat/ssh-workspace` 随后 rebase 到其上。分支末尾两笔 CI 提交（bubblewrap apt 重试与镜像回退）连同其回滚一起在 rebase 中丢弃：对应失败是 runner 级 DNS 故障，`azure.archive.ubuntu.com` 与 `archive.ubuntu.com` 均不可解析，重试与回退均无济于事，只拉长了失败作业；CI 工作流现与主线完全一致。

rebase 的集成处理：

- **ADR 撞号。** 主线把 ADR-0039 用于 worktree 附加根建议，分支的凭据 broker ADR 当时改为 0040（现为 [ADR-0048](../../decisions/ADR-0048-credential-broker.md)），分支侧源码、脚本与文档引用随之更新；已归档的实机日志（`docs/reference/*-evidence-*.txt/json`）保持原文不改。
- **SSH 地板随主线 pin 前移。** 主线开发 pin 升到 `0.2.2-rc.2` 后，`SUPPORTED_SSH_RELEASES` 必须仍是 allowlist 的后缀，因此扩为 `['0.2.2-rc.1', '0.2.2-rc.2']`，四个 SSH 开发包 pin 到 `0.2.2-rc.2` 并加入 `minimumReleaseAgeExclude`。rc.1 → rc.2 的 SSH 包有源码变化（`dsh-ssh` 的 helper/协议/schema，`dsh-fs-ssh` 与 `dsh-subprocess-ssh` 的入口）；`tests/ssh-compat.spec.ts` 的真实安装树断言改为跟随已安装版本，而不是写死 rc.1。
- **代码冲突。** `registry.ts`（`promptsRoot` 与 `remoteEnvironments`/`loadRemoteManifest` 并存）、`command.ts`（worktree 清理与远端视图并存，`WorktreeError`/`RemoteAdmissionError` 共用失败映射）、客户端入口与面板（worktree 客户端与 remotes 客户端并存）均按两侧都保留合并。
- 包版本改为未发布的 `0.1.19-ssh.1`。

本机 macOS arm64 / Node `24.18.0` / DSH `0.2.2-rc.2`：`compat:check`、lint、双端类型检查、build、`kernel:probe`（仅 Seatbelt）、`docs:check` 通过；全量 `pnpm test` **1717 passed / 132 skipped / 0 failed**（118 个文件通过、8 个跳过）。

## 模型入口以实验性开关开放（2026-11-13）

**决定：维护者批准将 Issue #32 模型入口以"默认关闭的实验性开关"形式开放。** `remote-tools` 行从此随默认 `cordis.patch.yml` 发货（`enabled: false`、无 broker 块，排在 worktrees 行之后），Registry 行默认携带 `remoteEnvironments.manifestPath: $HISTORICAL_PATH_22` 但**不写** `enabled`。这一节取代 11-11 评审记录中"默认组合不含 remote-tools"的状态描述（该节按日期保留为历史）。

- **live 开关。** 新增 `multi-root-remote-tools` Settings 命名空间（`src/compat/remote-settings.ts`，与 worktree 同一套 modern `installSection` + legacy `configure`/`settings/document-updated` 适配），字段 `enabled` 为 volatile、默认 `false`；行配置 `enabled` 为初值，缺省时回落到 `registry.remoteEnabled`（`remoteEnvironments.enabled`），持久化值覆盖两者。
- **控制面跟随开关。** `MultiRootRegistry.configureRemote(enabled)` 在既有 `serializeAuthority` 权威转移队列内执行：拆除 follower/owner 远端状态 → `RemoteControlPlane.configure`（有效开启 = live 开关且 `manifestPath` 已配置；关闭恢复精确 `disabled`，无 `remote-1` 监听、无远端域）→ 按当前权威 `openOwner`/`connectFollower`；本地 v1 注册表不受影响。
- **行内门控。** `src/remote/tools.ts` 始终安装 Settings 命名空间，但只在 live 值为 true 时经串行化的 `sync()` 挂载受管子树（SSH 能力分类、profile 守卫、清单/就绪检查、`danger-full-access` 拒绝、broker 证明、校验器与 `remote_copy`/`remote_bash`、能力投影）；任何一步失败不挂载，关闭先卸子树再 `configureRemote(false)`。broker 块缺席时开关打开也不注册工具。
- **设置卡与面板。** 插件详情新增"SSH 远端环境 / SSH remote environments"卡，`<Tag tone="warning">` 实验性标签，开启前走与 OPS 同款风险确认（勾选已了解→确认，取消/Esc/关闭不保存），关闭即时生效；Workspace Folders 面板在控制面 `disabled` 时不渲染远端区块。
- **专用 profile 语义。** `remoteEnvironments.enabled: true` 保留为开关初值；broker profile patch 改为按 id **替换**已发货行的整个 `config`（不再 `- insert` 同名行）。
- **测试。** 新增 `tests/remote-tools-switch.spec.ts`（mock broker 证明）：默认组合开关关闭→平面 `disabled`、无任何注册；拨开后 `configureRemote(true)`+证明→工具注册并可调用；再关闭→工具注销、平面回 `disabled`、v1 行为不变；证明失败不注册。`patch.spec`/`smoke-compose` 行清单与断言、`client-panel`（disabled 不渲染远端区）、`client-ops-settings`（警示标签+确认流）同步更新。

本机 macOS arm64 / Node `24.18.0` / DSH `0.2.2-rc.2`：`compat:check`、lint（0 警告）、双端类型检查、build、`docs:check` 通过；`smoke:compose` **58 passed**；全量 `pnpm test` **1743 passed / 132 skipped / 0 failed**（119 个文件通过、8 个跳过）。

## 四个入口的面板统一（2026-11-13）

**问题（实测）。** Workspace Folders 面板随打开入口不同而表现不同。四个入口都把 `WorkspaceFoldersDialog` 渲染在槽位 DOM 内：`.mrfw-overlay` 是 `position: fixed; inset: 0`，但右侧边栏/dockkit 祖先带 `transform`/`backdrop-filter`，使 fixed 相对该窗格定位，面板被裁切并落在错误的层叠上下文；同时 `RootSwitcher` 不传 `remotes`/`worktrees`、`HeroWorkspaceEntry` 不传 `remotes`/`subscribeSession`，远端区块与 worktree 清理只在部分入口出现。

**修复。** 面板 overlay 一律经 `createPortal` 挂到 `document.body`（access-upgrade Modal 原样不动；`onDialogKeyDown` 已有 `stopPropagation`，React 合成事件照常冒泡，DOM 级上游窗格监听不受影响）。`src/client/index.ts` 建立单一 `dialogDeps = { panel, remotes, pickDirectory, subscribeSession, t, worktrees }` 传给全部四个入口；`RootSwitcher`/`HeroWorkspaceEntry` 接受并转发 `remotes`/`worktrees`/`subscribeSession`，会话身份仍各走各的（footer 当前/钉住会话、Files 窗格会话、hero 组合会话），触发器外观不变，`RootSwitcher` 关闭后重新列表不变。ADR-0037/0038 未声称对话框就地渲染，无文档变更。

**测试。** `client-panel.spec` 新增"四个入口的统一面板"五例：footer、workspace-menu→footer owner、Files 紧凑启动器、Files `RootSwitcher`、hero 各自打开后面板的 `.mrfw-overlay` 均为 `document.body` 直接子节点，且给定相同假客户端时远端区块与 worktree 清理按钮一致出现；hero 组合会话测试改为断言 `list` 与 `remotes` 均以组合 `sessionId` 发出。

本机 macOS arm64 / Node `24.18.0` / DSH `0.2.2-rc.2`：lint（0 警告）、双端类型检查、build、`docs:check` 通过；全量 `pnpm test` **1748 passed / 132 skipped / 0 failed**（119 个文件通过、8 个跳过）。

## SSH 三档托管模式：Host 侧（2026-11-13）

**决定（ADR-0049，Accepted）。** SSH 远端环境的凭据托管分三档：`personal`（默认；Host 进程内直跑官方 SSH 栈，用户 `~/.ssh` 别名或插件凭据根）、`team`（broker 托管，放宽 `confinement-unproven`/`full-access-unrestricted`/独立写者检查，`chroot-sftp` 目的隔离保留）、`hardened`（ADR-0048 全量证据原路径）。本步实现 Host 侧全部机制；GUI（6b）与专用 profile 组合后续。

- **Settings。** `multi-root-remote-tools` 命名空间扩为 `{ enabled, mode, team? }`（schemastery + zod 校验）；未知/非法值 fail closed 为 `enabled:false` 并告警；`read()` 返回整个对象。settings `mode` 优先于行 `mode`，两者都缺省时：有 broker 块 → `hardened`（专用 profile 兼容），否则 → `personal`。
- **Registry/Plane。** `configureRemote(next: { enabled, mode, manifestPath? })` 取代布尔签名；行配置加 `personalPath`/`credentialRoot`（默认组合写入 `$DSH_HOME/storages/` 下两路径）。personal 经 `loadPersonalManifest`（缺失文件 = 空清单，照常 `ready`）；`registry.remoteMode`/`remoteManifestDigest` 暴露，`RemotesView` 增 `custodyMode`。每次远端 op 前 `refreshPersonal()` 按 stat 身份重载；摘要变化时 owner 换摘要重听 `remote-1`、follower 重连，授权不迁移。
- **个人基础设施。** `src/remote/personal/`：config（zod schema、权限检查、CAS `savePersonalConfig`、`toDeploymentManifest` 等形转换）、credentials（生成/导入去口令/密码/in-use 拒绝/元数据列表，绝不返回秘密）、ssh-files（托管 `ssh_config`/`known_hosts` 渲染、首行 `Include` 链接+备份）、operations（keyscan 60 秒令牌、连接测试、helper npm 安装+SHA-256 对比、askpass 访问密钥引导）。`SshEnvironmentManager` 增 `custody:'personal'`：`ssh -G` 放宽四项 flag 检查，未链接 managed 别名报 `ssh-config-not-linked`。
- **行内分派。** `tools.ts` mount 按 mode 分派：personal 无 broker 无守卫直接挂载 manager；team 以 settings `team` 覆盖行 broker 并 `attestBroker(mode:'team')`；hardened 原样。`onRemoteChange` 通知驱动按摘要重挂载（通知仅在真实 rebind 时发出，否则自反馈死循环——测试实测发现）。
- **RPC。** `src/remote/personal-contract.ts` + `src/remote/personal-endpoints.ts`：14 个 `ssh*` 端点，全部要 `sessionId`、严格 schema、非 personal/未开启一律 `remote-personal-unavailable`；变更返回刷新 `sshState`；秘密字节不出 RPC。`src/client/ssh-client.ts` 解析全部应答；zh/en `error.*` 键补齐。
- **文档。** 凭据托管模式 ADR 入库（当时编号 0041，现为 ADR-0049）；新参考 `docs/reference/ssh-remote-environments.md`；控制面参考加托管档位指针与 `personalPath`/`credentialRoot`；AGENTS.md Issue #32 段落更新。
- **测试。** `tests/remote-personal.spec.ts`（10 例）：缺文件空清单、权限/符号链接/父目录拒绝、CAS 冲突、manifest 转换、ssh_config 渲染+Include 幂等+备份、relaxed `parseSshConfig`、fail-closed 设置、端点 schema、密码凭据列表不泄露+in-use 拒绝。`remote-tools-switch.spec` 增 `mode` 选项；专用 profile 默认值回归修正。

本机 macOS arm64 / Node `24.18.0` / DSH `0.2.2-rc.2`：验证数字见提交说明。

## SSH 三档托管模式：GUI（2026-11-13）

**决定（ADR-0049 §6 落地）。** 三档托管模式的用户面补齐：设置卡档位选择 + Workspace Folders 个人管理区 + 用户文档。`ssh*` RPC、秘密卫生、fail-closed 语义沿用 Host 侧提交（`9d0e4b8`/`942b131`/`6e482ee`），本步不加新 Host 行为，除一处测试暴露的线形修正。

- **设置卡（`RemoteSwitchRow`）。** 开关与启用风险确认不变；常驻三档单选（个人/团队/硬化，各带一行说明，`REMOTE_ISOLATION` 排序 personal<team<hardened）。team 显示四个 broker 字段并以 `remote.team.save` 逐项 `set` 写 `team.*`；hardened 显示只读部署提示。开关开启时降到更低档位走同一风险确认组件，文案按目标档位（`remote.downgrade.personal`/`remote.downgrade.team`）；升级或未开启时直接写 `mode`。
- **面板远端区块。** 标题行显示 `custodyMode` 徽标；仅 personal + `ready` 时挂 `SshPersonalArea`（`src/client/ssh-panel.tsx`），team/hardened 保持只读端点列表。管理区含：`linked` 横幅（managed 环境存在时）、凭据行与三个添加表单（秘密输入提交即清、访问密钥列于所属环境而非凭据列表）、环境行（测试连接/helper/访问密钥/编辑/行内删除）、环境编辑器（ssh-config 别名或托管凭据、keyscan→指纹单选→token+fingerprint 保存、exec/transfer 开关写出文档默认值）、本项目绑定表单（本地传输对端恰为 `primary` + 各可用根 `aliasId`）。所有变更带 `revision`；`personal-config-conflict` 先重取 `sshState` 再提示。
- **接线。** `createSshClient` 进 `dialogDeps`（四个入口一致）；`RootSwitcher`/`HeroWorkspaceEntry` 转发 `ssh`。`personal-contract.ts` 补 `SshEnvironmentView`/`SshBindingView`/`CredentialPublicView`（含 `purpose`/`environmentId`）公开视图类型；测试发现环境草稿的 `exec` 线形缺 `shell`/`env`/`maxTimeoutMs`/`terminateGraceMs` 字段，保存必被 Host 语义校验拒绝——已按 `personal/config.ts` 校验边界补全。
- **测试。** `client-ops-settings.spec` 新增五例：关闭状态下直接写 `mode`、team 字段保存带 revision、hardened 只读提示、enabled+hardened→personal 的风险确认与档位文案、升级无需确认。`client-ssh-panel.spec`（13 例，假 `SshClient`）：挂载条件（仅 personal+ready+有 client）、链接横幅显隐、密码/私钥提交即清且 DOM 无秘密字节、scan→选指纹→token+fingerprint 保存、exec/transfer 默认值、行内删除确认、绑定本地对端取自 RootsView、`personal-config-conflict` 重取、连接测试结果显示。
- **用户文档。** README 双语 "SSH 远端环境" 段重写：三档保护与不保护什么、个人模式 GUI 走通流程、指针至参考与控制面清单。`ssh-remote-environments.md` 增 GUI 节与 exec/transfer 默认值。

本机 macOS arm64 / Node `24.18.0` / DSH `0.2.2-rc.2`：`compat:check`、lint（0 警告）、双端 typecheck、build（59 文件）通过；触达 spec 157 例（panel 82 + ops-settings 34 + ssh-panel 13 + locale/styles 28）；全量 `pnpm test` **1791 passed / 132 skipped / 0 failed**（122 个文件）；`smoke:compose` **58 passed**；`docs:check` 0 错误 0 警告。

## SSH 远端管理面板抽离（2026-11-13）

**问题。** ADR-0049 §6 的个人管理区、托管档位选择器与部署端点列表全部内联在 Workspace Folders 面板的“远端环境”区块：列表、全局 SSH 设置、凭据、环境、绑定混在同一滚动区，个人模式下体积过大，工作区面板的主要职责被挤占。上一节记录的“设置卡常驻三档单选”在 `28ece12` 已把档位与 team 字段移入面板，实际形态与文字不再一致。

**决定。** Workspace Folders 远端区块只保留：(a) 远端工作区列表（沿用附属工作目录行样式，平台显示实际系统名称 Linux / macOS，保留登记/移除）；(b) “添加 SSH 远端…”与“管理 SSH 远端…”两枚入口。新增独立 `SshManagementDialog`（`src/client/ssh-panel.tsx`），由 ui-primitives `Modal` 承载，四个 Tab：添加连接、已有连接、SSH Key、模式设置。计划见 [2026-11-13-ssh-management-dialog.md](../completed/2026-11-13-ssh-management-dialog.md)。**2026-11-19 修订：** 管理对话框收敛为三个 Tab（已有连接 / SSH Key / 模式设置），添加连接改为从“已有连接”打开的独立 Dialog；远端区块只保留“管理 SSH 远端…”入口，远端工作区行复用主要/附属工作目录的 `WorkspaceRow`，可复制位置为 personal 的 `user@host:port/path`（部署清单无 port 时为 `user@host/path`）。见 [2026-11-19-ssh-add-connection-two-step.md](../completed/2026-11-19-ssh-add-connection-two-step.md)。

- **添加连接。** personal 显示分步引导表单（目标 → 凭据 → 远端目录与能力 → 主机密钥扫描/指纹单选），保存沿用既有 `sshEnvironmentSave` 的 revision/token/fingerprint 语义；team/hardened 显示部署清单/broker 引导，不渲染个人表单，也不调用 `sshState`；模式设置 Tab 的档位选择决定引导分支。
- **已有连接。** personal 保留链接横幅、环境行（测试连接/helper/访问密钥/编辑/行内删除）与“本项目绑定”（本地传输对端仍为 `primary` + 各可用根 `aliasId`）；team/hardened 显示部署端点只读列表。
- **SSH Key。** personal 保留凭据行、复制公钥、行内删除与三个添加表单；秘密输入提交即清且永不由状态回填；访问密钥仍显示在其所属环境下。team/hardened 说明凭据由部署 broker 托管。
- **模式设置。** 复用 `RemoteCustodyModeControl` 与同一个 `multi-root-remote-tools` form/CAS；同时显示档位对“添加连接”引导方式的说明。
- **兼容与刷新。** `SegmentedTabs` 仅在 `0.1.7-alpha.1+` 提供，客户端经 `maybeComponent` 探测并降级为同 ARIA/DOM 契约的本地 tablist；对话框只通过父级 `onChanged` 触发 `remotes.list`，不建立第二个数据源；会话切换清空旧 `sshState` 并重读。
- **不改 Host。** 没有新增/修改 RPC、线形、准入或凭据语义；team/hardened 的 broker 证明与清单来源保持不变。

**测试。** `client-ssh-panel.spec` 重写为 23 例：内联管理区消失、入口分别打开四个 Tab、平台显示 Linux/macOS、team/hardened 不调用 `sshState`、模式引导、链接横幅、秘密清理、hostKeyScan→保存、exec/transfer 默认值、编辑/删除/绑定、CAS 冲突重取、连接测试、mutation 后父面板刷新、对话框关闭不影响外层。`client-panel.spec` 的远端区块用例保持通过。

本机 macOS arm64 / Node `24.18.0` / DSH `0.2.2-rc.2`：`compat:check`、lint（0 警告）、双端 typecheck、build、`docs:check`、`pack:check`（254 members）、`kernel:probe`、Auto Review 检查通过；`smoke` compose 58 / behavior 96（8 skip）/ journey 85（2 skip），`smoke:packed` 通过。特性相关 client/locale/styles spec **168 passed**；全量 `pnpm test` 在本会话的 DSH Agent 沙箱内因共享 Registry IPC 拒绝沙箱 peer，10 个既有 authority 文件失败（**1713 passed / 207 skipped / 20 failed**，其余全部通过），排除这些文件后为 **1570 passed / 201 skipped / 0 failed**；完整套件由干净 runner 上的 CI 覆盖：手动触发的 [CI run 43447653166](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43447653166) @ `be5a489` 为 **26/26 jobs success、0 failed**；抽查 `0.2.1-rc.2` / ubuntu-latest 产物为 **1875 passed / 156 skipped**（含 `client-ssh-panel.spec` 23 passed）。

## SSH 管理对话框表单 primitives 化（2026-11-13）

**问题（用户目检）。** “添加连接”表单的输入框被拉成 220px 级巨块。根因是 `.mrfw-input` 的 `flex: 1 1 220px` 原本用于横向 flex 行；放进纵向 `.mrfw-sshForm` 后，220px 从宽度基准变为高度基准。jsdom 不做布局，原 client 用例未发现。

**修复。** 文本/密码/数字输入改用 primitives `Input`，动作按钮改用 `Button`，平台/helper/状态徽标改用 `Tag`；`Checkbox`/`SegmentedControl` 从 `0.1.7-alpha.1` 起使用 primitives，旧版本回退到显式自绘控件（同语义、固定高度）。原生 select（宿主无 Select primitive）改用 32px 的 `.mrfw-sshSelectControl`，私钥 textarea 改用 `.mrfw-sshTextarea`。表单改为两列 grid + 持久 label；对话框内不再使用 `.mrfw-input`，并保留 `.mrfw-sshForm .mrfw-input { flex: 0 0 auto }` 作为安全网。`RemoteCustodyModeControl` 的 team 字段同步改用 `Input`/`Button`。

**测试。** `client-styles.spec` 增加 grid 与“不继承 220px flex”的断言；`client-ssh-panel.spec` 增加无 `.mrfw-input`、存在 `.mrfw-sshInput` 包装/ `.mrfw-sshGrid` 与可见字段 label 的断言。特性相关 client/locale/styles spec **169 passed**；lint、双端 typecheck、build、docs:check、compat:check、pack:check、`smoke:compose`、`smoke:packed` 通过，过滤后全量 **1571 passed / 201 skipped / 0 failed**。文档：`docs/reference/ssh-remote-environments.md` 的 GUI 节补充控件与旧版本 fallback 契约。按维护者指示，UI-only follow-up 不触发 CI（误触发的 run 43456982757 已取消）。

## SSH 分支合入主线（2026-11-17）

从 `eb89ea2` 以 merge 合入 `main` 的 `f2dd05b`。保留主线的 Files、Worktree、Auto Review 与宿主提供的 `koffi` 变更。SSH 凭据代理与托管模式决策分别改号为 [ADR-0048](../../decisions/ADR-0048-credential-broker.md) 与 [ADR-0049](../../decisions/ADR-0049-ssh-custody-modes.md)。分支包版本为未发布的 `0.1.22-ssh.1`。

开发树和四个 SSH 可选依赖统一为 DSH `0.2.2-rc.3`。本机 macOS arm64 验证了宿主树解析、SSH 类导出及本地组合。全量测试 **2448 通过 / 132 跳过 / 0 失败**，compose / behavior / journey 分别 **58 / 137 / 95 通过**，均无跳过。文档、兼容性、lint、构建、Auto Review fork 与打包检查均通过。本次未重跑跨平台矩阵与真实 SSH 部署验收。
## DSH 0.2.2-rc.4 兼容提升（2026-11-18）

从 `main` 的 `f2dd05b`（`v0.1.21` 之后）新建 `feat/adapt-1118`。上游 tag `dsh-v0.2.2-rc.4` 指向 `3f321d32bfe382212a8ed8785c1d47a5a300aa23`（发布提交 `bc3bddffbd`），npm 已发布该精确版本（`next` 指向它，`latest` 仍为 `0.2.2-rc.1`），因此本分支按 ADR-0009 完成提升：`SUPPORTED_DSH_RELEASES`、全部 DSH peer 与开发 pin 都指向 `0.2.2-rc.4`（25 个精确版本），开发树由 `scripts/upgrade-dsh.mjs 0.2.2-rc.4` 整体重指，probe overrides 已移除。

rc.4 只有 8 个提交、395 个文件；其中 380 个 `package.json`（379 个 workspace 包与根 manifest）只替换版本号，其余 15 个文件的净改动是 DeepSeek 内容安全审查拒答（`dsh-llm` 新增 `LLM_FAILURE_CODES.CONTENT_REFUSED`；`llm-deepseek` 的 `translate()` 在 `refusal` 时先产出 usage 再抛带 provider 解释的错误），`llm-deepseek` 的三次 `safetyCheck` 开关提交净零，实验包 liveshare 的 tunnel worker 修复，以及 npm upgrade guide 与会话快照。逐项接缝分类见[接口审查](../../reference/dsh-0.2.2-migration.md#022-rc4-后续审查2026-11-18)。落到本分支的改动只有：

- `src/compat/dsh-version.ts`：allowlist 末尾加入 `0.2.2-rc.4`；`CORE_PACKAGES` 不变——rc.4 没有新增包，也没有新的交叉接缝。
- `package.json`：28 个 DSH peer 各追加 `0.2.2-rc.4`，全部 DSH devDependency 由升级脚本重指；`cordis 4.1.0` / `schemastery 3.19.0` / `node-addon-system 0.1.2` / `koffi 3.1.1` 不变。
- `src/compat/auto-review-contract.ts`：`AUTO_REVIEW_CURRENT_RELEASES` 加入 `0.2.2-rc.4`（联合集合 10 个精确发布），current 编译 pin 前移到 `0.2.2-rc.4`（reviewer `src` 树 hash `2c4de92078…` 与 rc.3 相同）。
- `pnpm-workspace.yaml`：release-age 条目整体重指到 `0.2.2-rc.4`；probe overrides 删除。
- `pnpm-lock.yaml`：`pnpm install --no-frozen-lockfile --config.minimumReleaseAge=0` 后 `0.2.2-rc.3` 包副本为 0，`pnpm peers check` 输出 `No peer dependency issues found`。
- 复刻源：rc.4 未改 `ui-open-in-app` / `ui-sidebar-files` 的 `src/client/`，open-in-app 基线保持 `ddac96760b`、files-tree 旧版保持 `f3803c9697`；`FORK.md` 只记录 dev pin 前移、基线不变。
- 文档：迁移审查的 rc.4 小节、兼容笔记双语 §19、README 支持矩阵与开发 pin、`AGENTS.md` 兼容契约段、`docs/development/plugin-development-workflow.md`、`docs/reference/README` 双语条目、ADR-0040 修订与 ADR-0044 §修订三。

安静陷阱（开发树）：升级脚本只重指直接依赖与 release-age，peer-only 副本仍可能以旧 rc 满足“看似有效”的边；本轮升级后 `pnpm peers check` 为 0、lockfile 中 `0.2.2-rc.3` 为 0，但每次提升仍要以这两项证据为准。`CONTENT_REFUSED` 是共享 `dsh-llm` 的新增故障码，插件不按 LLM 错误码路由，不要新增适配器分支。

本机验证（macOS arm64 / Node `24.18.0` / pnpm `11.25.0`，`0.2.2-rc.4` 开发树，enforce 车道）：

- `compat:check`：allowlist、28 个 peer、开发 pin、安装树一致（25 个精确版本；可选 Auto Review 10 个联合发布）；`pnpm peers check` 无问题；
- lint（0 警告 0 错误）、双端 `tsc --noEmit`（含 `tsconfig.auto-review-current.json` 的实现类型检查）、`build`、`docs:check`（0 错误 0 警告）、`pack:check`、`auto-review:fork`、`kernel:probe`：通过；
- 完整 `vitest`：**1933 通过 / 165 跳过 / 17 失败**（118 个文件，104 通过 / 8 失败 / 6 跳过）。17 个失败全部是共享 Registry 的核内 IPC/租约用例（`registry*` / `authority-boundaries` / `b9-review-regressions` / `skills-authority` / `skills-registry` 共 8 个文件），本会话运行在 DSH 自身的 Seatbelt 内、Peer 凭据被识别为 sandboxed peer；与 rc.3 基线记录的失败集合相同，不是 rc.4 回归；
- Host smoke 与 packed（0 失败）：compose **56/56**、behavior **96 通过 / 8 跳过**、journey **88 通过 / 2 跳过**、packed **95 通过 / 8 跳过**；`smoke:auto-review` 在 source/link 与 packed 两条车道、官方 bundle 前后两种顺序全部通过。跳过项是 Seatbelt 内无可用内核 runner 与共享 IPC；
- 实机目检（2026-11-18，隔离 scratch `$DSH_HOME` + 真实 `dsh web`（`0.2.2-rc.4` 开发树）+ 本机 Google Chrome headless/CDP；注册两个附加根 `dsh-plugin-multi-root-workspace-ssh` 与 `$HISTORICAL_PATH_23`）覆盖[兼容笔记 §12 的目检清单](../../../.agent/note/dsh-compat-contract.md)：
  - Files 三态：主根态原生 body / reload / open-in-app 可见、无复刻 body；附加根态原生 body 隐藏，复刻 body 645×824 可见，原生 reload 换为 `.mrfw-switcherReload`，原生 open-in-app 隐藏而复刻分离按钮可见；切回主根完整还原。同宽 647px 下原生行与复刻行同为 29.5px 高、13px 字号、16px 图标。
  - 预览导航器：附加根嵌套文件（`src/index.ts`）打开 Folder 后 aside 带 `data-mrfw-navigator`、插件 pane 与常显搜索栏出现，原生导航 body 与原生搜索栏隐藏，`src` 祖先展开，当前行 `aria-current` 且在 aside 视口内（top 783 ∈ 84..892）；主根文件预览完全原生（无 marker/pane，原生 body 与搜索栏可见）。
  - 折叠/重开与多根记忆：Folder 关闭/重开后 `scrollTop 240`、2 个展开目录、86 行原样恢复且直接绘制；A→B→A（两个附加根）时各自导航器根与当前文件正确，A 的 `revealed` 未被 B 的地址串写。
  - 预览搜索：查询 `README` → `Results: 22`、22 处 `<mark>`；点结果行后预览 tab 数量不变（2）且 `data-textpreview-url` 原位换成结果文件；关闭/重开 Folder 与 replaceTab 后查询与结果保留；眼睛默认隐藏 `.git`，开启后树由 27 行增至 37 行并出现 `.git`；设置浮层打开后 Esc 顺序为「关设置 → 清查询（回到树）→ 关导航树」；移除附加根目录后搜索显示本地化失败行与 Retry，恢复目录点 Retry 后回到 settled 状态。
- 三 OS 矩阵、Windows ACL 原生探针与旧版回归由 PR 的 CI 给出（25 个精确版本 × macOS / Ubuntu 22.04 / Ubuntu latest / Windows）；实机目检截图由本机 scratch 环境保留（gitignored，不入库）。

`CHANGELOG` 条目与版本号由后续发版流程写入，本分支不创建 tag。

## v0.1.22 发版验收（2026-11-18）

本次沿用「文档准备提交 → 仅版本号的正式提交 → 正式提交上的 annotated tag」的发版步骤。自 `v0.1.21`（`e50edcf`）以来 `main` 有两笔内容提交：PR #67（`f2dd05b`，Files 页头 `RootSwitcher` 的窄宽让位与三档根名显示，ADR-0046）与 PR #68（`45950f6`，精确支持 DSH `0.2.2-rc.4`）。内容归 CHANGELOG 双语对；精确 DSH 支持合同扩至 25 个精确版本，可选 Auto Review 联合集合扩至 10 个精确发布；`rc.4` 未改任何被消费的 `src` 树，因此未新增适配分支。没有配置或协议变更，也没有不兼容变更；ADR-0046 保持 Accepted。

合入 `main` 的内容提交 push CI：`f2dd05b` [run 44117746472](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/44117746472) 30/30 成功；`45950f6` [run 44260988200](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/44260988200) 覆盖 25 个精确版本 × macOS / Ubuntu 22.04 / Ubuntu latest / Windows（含 Windows 原生 ACL 门禁），准备时已完成的分组全部通过、其余仍在运行。矩阵的最终判定不依赖该次运行：tag 触发的 `release.yml` verify 等待与正式提交同 SHA 的 main push CI 与最终 `gate`，那份运行覆盖同一份代码。

准备提交只改文档与 CHANGELOG；正式提交只改 `package.json` 的 `version`，tag 指向正式提交。本次在本机 macOS arm64 / Node `24.18.0` / pnpm `11.28.5` 对准备提交后的树运行：`docs:check`（0 错误 0 警告）、`compat:check`（allowlist / peerDependencies / 开发 pin / 安装树一致，25 个精确版本；Auto Review 联合合同报告 10 个精确发布）、lint（0 警告 0 错误）、双端 typecheck、`build`、`pack:check`（**233** 个成员）、`auto-review:fork`、`kernel:probe`，均通过。完整 `vitest` 为 **1933 通过 / 165 跳过 / 17 失败**；17 个失败全部是共享 Registry 的核内 IPC/租约用例（`contended` 而非 `follower`），本会话运行在 DSH 自身的 Seatbelt 内、Peer 凭据被识别为 sandboxed peer，失败集合与 `0.2.2-rc.4` 基线记录的八个文件相同，不是本版回归。冒烟 0 失败：compose **56/56**、behavior **96 通过 / 8 跳过**、journey **88 通过 / 2 跳过**、`smoke:packed` 的打包行为电池 **95 通过 / 8 跳过**；跳过项是无可用内核 runner 的受限 bash 与共享 IPC。发布矩阵与 GitHub Release 由 tag 触发的 `release.yml` 完成，本机不发布。

## 面板与详情页 8 语言本地化（2026-11-18）

DSH 客户端内置 8 种界面语言（`zh`、`en`、`ja`、`es`、`fr`、`de`、`ru`、`pt`，其中 `ja`/`es`/`fr`/`de`/`ru`/`pt` 自 `0.2.1-rc.2` 起随包内置），面板此前只有中英双语，插件详情页也只有中英两套资源。本批把面半与详情页对齐到同一组语言。

**面板词典**：`src/client/locales.ts` 仍是唯一入口（`NS`、`Key`、`DICTIONARIES` 与 `LocaleNamespaceMap` 合并声明），词典拆到 `src/client/locales/<language>.ts` 每语言一个模块；`zh` 为 canonical（`Key = keyof typeof zh`），其余 7 份以 `satisfies Record<Key, string>` 钉住键集，`ctx.locale.register(NS, DICTIONARIES)` 一次注册 8 份。`ctx.locale.register` 接受宿主未注册为可选语言的词典（只做 BCP 47 形状与重复注册校验），因此支持矩阵里更早的发布只提供它们自己内置的语言、词典作为惰性资源存在，不会报错也不会改变旧宿主的语言菜单。

**键集与占位符门禁**：`tests/locale-parity.spec.ts` 从同一批模块读 8 份词典，逐项比较键集、单行性、非空、`{count}`/`{access}`/`{tools}` 等占位符是否与中文一致，并对“整份语言仍等于英文”的漏译设门禁（`panel.accessEffective` 这类纯格式串，以及 `Experimental`、`Full-access`、`Main checkout` 等有意保留的固定词用白名单列明）。`tests/client-panel.spec.tsx` 的注册断言改为 8 个语言 id；`tests/client-ops-settings.spec.tsx` 的风险确认文案改为 8 语逐语渲染。

**详情页资源**：`locale/<lang>.json` 从 2 份扩到 8 份，每份提供本地化的 `meta.title`、`meta.description` 与指向自己那份 `meta.detail`；`detail/` 增加 `DETAIL.ja/es/fr/de/ru/pt.md`（单行图片 + 本地化 alt）与 `preview.ja/es/fr/de/ru/pt.svg`，英文 alt 文案随插图里的入口标签改为 `Folders`。8 份 SVG 由 `pnpm preview:gen` 从同一份版式数据生成：文字经 fontkit 转曲（无 `<text>`/`<script>`/外链），字体按语言选用——拉丁与西里尔用 SF / Georgia Bold，中文用 Hiragino Sans GB + Songti，日文用 Yu Gothic + Yu Mincho（macOS 的可下载字体资产，脚本按资产名解析并在缺失时报错）——并对每个受限槽位（大标题、副标题、卡片标题、入口药丸、分区标题、权限徽标、气泡两行、状态行、按钮）按实测宽度自适应缩小字号；缩到下限仍溢出时直接抛错，避免出现被药丸盖住的半截文案。入口药丸改用侧栏动作自己的短标签（`action.label`：Folders / フォルダー / Carpetas / Dossiers / Ordner / Папки / Pastas），长语言不再挤压卡片标题。每份 SVG 约 150–200 KiB，低于 1 MiB 预算与宿主 `detailImageMaxBytes` 默认值。

**测试**：`tests/plugin-detail.spec.ts` 改为按 8 种语言驱动——locale 文件集合等于 8 语言、每份 `meta.detail` 指向存在且单行图片的文档、8 份预览内容互不相同、每份满足 640×300 自包含约束且不超过 1 MiB、locale 标题与说明不允许 8 份重复。

**证据**：`pnpm lint`（0 warning / 0 error）、`pnpm typecheck`（host + client）、`pnpm build`、`pnpm docs:check`（0 error / 0 warning）、`pnpm pack:check`（packed artifact complete）、`pnpm vitest run tests/locale-parity.spec.ts tests/plugin-detail.spec.ts tests/client-panel.spec.tsx tests/client-ops-settings.spec.tsx` 全绿；全量 `pnpm test` 中除既有 Registry lease／多进程 authority 环境性失败（17 条，均为进程间租约与 IPC 用例，与本批无关）外通过。SVG 逐语言经 `sharp` 光栅化目检，无截断、重叠或溢出。

**边界**：更早的宿主只显示它自己内置的语言（词典惰性存在）；`/workspace-folders` 命令输出仍为英文（host 侧没有活动语言信息）。根目录 README 的 8 语言版本与其打包属于独立的文档批次，不在本记录范围内。

## DSH 0.2.2-rc.5 兼容提升（2026-11-18）

从 `main` 的 `02a541c`（八语言 README 批次之后）新建 `feat/adapt-1118-rc5`。上游 tag `dsh-v0.2.2-rc.5` 指向 `9c2670d3bce5275e0d1610272958121af87787bb`（发布提交 `9bf478edde5b14e6a15d3802a8834bdca83f2d97`），npm 已发布该精确版本（`next` 指向它，`latest` 仍为 `0.2.2-rc.1`），因此本分支按 ADR-0009 完成提升：`SUPPORTED_DSH_RELEASES`、全部 DSH peer 与开发 pin 都指向 `0.2.2-rc.5`（26 个精确版本），开发树由 `scripts/upgrade-dsh.mjs 0.2.2-rc.5` 整体重指，probe overrides 已移除。

rc.5 只有 5 个提交、433 个文件（917 行新增 / 594 行删除）；其中 380 个 `package.json`（379 个 workspace 包与根 manifest）只替换版本号，其余 53 个文件的净改动是 DeepSeek 内置联网搜索的按模型路由选择：`dsh-web` 在未配置 `searchProvider` 时按模型请求的 provider 路由解析（`deepseek-official` / `deepseek-account` 路由用 Messages 搜索，其余路由与模型请求之外用 `deepseek-search-api`），`dsh-tool-web` 把 `exec.agent.session.requestContext()?.provider` 透传给 `ctx.web.search`，`web-search-deepseek` 优先使用结果项自带 `snippet`、文案改为「DeepSeek server-side search」，以及设置卡片、配置目录、e2e、升级指南与会话快照。liveshare test-clock 提交在两个 tag 之间是同一 blob、无净差异。

- `src/compat/dsh-version.ts`：allowlist 末尾加入 `0.2.2-rc.5`；`CORE_PACKAGES` 不变——rc.5 没有新增包，也没有新的交叉接缝。
- `package.json`：28 个 DSH peer 各追加 `0.2.2-rc.5`，全部 DSH devDependency 由升级脚本重指；`cordis 4.1.0` / `schemastery 3.19.0` / `node-addon-system 0.1.2` / `koffi 3.1.1` 不变。
- `src/compat/auto-review-contract.ts`：`AUTO_REVIEW_CURRENT_RELEASES` 加入 `0.2.2-rc.5`（联合集合 11 个精确发布），current 编译 pin 前移到 `0.2.2-rc.5`（reviewer `src` 树 hash `2c4de92078…` 与 rc.4 相同）。
- `pnpm-workspace.yaml`：release-age 条目整体重指到 `0.2.2-rc.5`；probe overrides 删除。
- `pnpm-lock.yaml`：`pnpm install --no-frozen-lockfile --config.minimumReleaseAge=0` 后 `0.2.2-rc.4` 包副本为 0，`pnpm peers check` 输出 `No peer dependency issues found`。
- 复刻源：rc.5 未改 `ui-open-in-app` / `ui-sidebar-files` 的 `src/client/`，open-in-app 基线保持 `ddac96760b`、files-tree 旧版保持 `f3803c9697`；`FORK.md` 只记录 dev pin 前移、基线不变。
- 文档：迁移审查的 rc.5 小节、兼容笔记双语 §24、README 支持矩阵与开发 pin、`AGENTS.md` 兼容契约段、`docs/development/plugin-development-workflow.md`、`docs/reference/README` 双语条目、`docs/architecture` / `docs/guide` / `docs/requirements` 的几何计数、ADR-0040 修订与 ADR-0044 §修订四。

安静陷阱（开发树）：升级脚本只重指直接依赖与 release-age，peer-only 副本仍可能以旧 rc 满足“看似有效”的边；本轮升级后 `pnpm peers check` 为 0、lockfile 中 `0.2.2-rc.4` 为 0，但每次提升仍要以这两项证据为准。联网搜索不是插件面：`ctx.web` 的 provider 选择与 `web_search` / `web_fetch` 工具都在上游，插件不注册 provider、不包装服务、不实现工具，不新增适配器分支。

本机验证（macOS arm64 / Node `24.18.0` / pnpm `11.25.0`，`0.2.2-rc.5` 开发树，enforce 车道）：

- `compat:check`：allowlist、28 个 peer、开发 pin、安装树一致（26 个精确版本；可选 Auto Review 11 个联合发布）；`pnpm peers check` 输出 `No peer dependency issues found`，lockfile 中 `0.2.2-rc.4` 包副本为 0；
- lint（0 警告 0 错误）、双端 `tsc --noEmit`（含 `tsconfig.auto-review-current.json` 的实现类型检查）、`build`、`docs:check`（0 错误 0 警告）、`pack:check`、`auto-review:fork`、`kernel:probe`：通过；
- 完整 `vitest`：**1950 通过 / 165 跳过 / 17 失败**（119 个文件，105 通过 / 8 失败 / 6 跳过）。17 个失败全部是共享 Registry 的核内 IPC/租约用例（`registry*` / `authority-boundaries` / `b9-review-regressions` / `skills-authority` / `skills-registry` 共 8 个文件），本会话运行在 DSH 自身的 Seatbelt 内、Peer 凭据被识别为 sandboxed peer；与 rc.4 基线同一失败集合，不是 rc.5 回归。通过数与用例总数高于 rc.4 记录，是因为本分支携带八语言本地化批次（新增 locale / 详情页用例），不是 rc.5 引入的测试；
- Host smoke 与 packed（0 失败）：compose **56/56**、behavior **96 通过 / 8 跳过**、journey **88 通过 / 2 跳过**、packed 的行为电池 **95 通过 / 8 跳过**；`smoke:auto-review` 在 source/link 与 packed 两条车道、官方 bundle 前后两种顺序、web/headless 两种组合全部通过。跳过项是 Seatbelt 内无可用内核 runner 与共享 IPC；
- 三 OS 矩阵、Windows ACL 原生探针与旧版回归由 PR 的 CI 给出（26 个精确版本 × macOS / Ubuntu 22.04 / Ubuntu latest / Windows）。

`CHANGELOG` 条目与版本号由后续发版流程写入，本分支不创建 tag。

## v0.1.23 发版验收（2026-11-19）

本次沿用「文档准备提交 → 仅版本号的正式提交 → 正式提交上的 annotated tag」的发版步骤。自 `v0.1.22`（`3a97649`）以来 `main` 有两笔内容提交：PR #69（`e5e4417`，面板 / 详情页 8 语言本地化、8 语言根 README 与逐功能用户指南、贡献与安全治理、生成的第三方许可清单）与 PR #70（`ac13ce7`，精确支持 DSH `0.2.2-rc.5`）。内容归 CHANGELOG 双语对；精确 DSH 支持合同扩至 26 个精确版本，可选 Auto Review 联合集合扩至 11 个精确发布；`rc.5` 未改任何被消费的 `src` 树，因此未新增适配分支。没有配置或协议变更，也没有不兼容变更。

合入 `main` 的内容提交 CI：#69 的 PR CI [run 44336205469](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/44336205469) 成功，其 main push CI [run 44439036440](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/44439036440) 被随后的 #70 推送取代（cancelled）；#70 的 PR CI [run 44439046316](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/44439046316) 成功，main push CI [run 44443312370](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/44443312370) 在准备时仍在运行。矩阵的最终判定不依赖该次运行：tag 触发的 `release.yml` verify 等待与正式提交同 SHA 的 main push CI 与最终 `gate`，那份运行覆盖同一份代码。

准备提交只改文档与 CHANGELOG；正式提交只改 `package.json` 的 `version`，tag 指向正式提交。本次在本机 macOS arm64 / Node `24.18.0` / pnpm `11.25.0` 对准备提交后的树运行：`docs:check`（0 错误 0 警告）、`compat:check`（allowlist / peerDependencies / 开发 pin / 安装树一致，26 个精确版本；Auto Review 联合合同报告 11 个精确发布）、`licenses:check`（`THIRD_PARTY_LICENSE` 与声明一致）、lint（0 警告 0 错误）、双端 typecheck、`build`、`pack:check`（**266** 个成员）、`auto-review:fork`，均通过；`kernel:probe` 报告本机无可用受限执行 runner（Seatbelt `sandbox_apply` 被拒、无 bwrap / Landlock），受限内核断言按设计跳过。完整 `vitest` 为 **1950 通过 / 165 跳过 / 17 失败**；17 个失败全部是共享 Registry 的核内 IPC/租约用例（`contended` 而非 `follower`），本会话运行在 DSH 自身的 Seatbelt 内、Peer 凭据被识别为 sandboxed peer，失败集合与 `0.2.2-rc.5` 基线记录的八个文件相同，不是本版回归。冒烟 0 失败：compose **56/56**、behavior **96 通过 / 8 跳过**、journey **88 通过 / 2 跳过**、`smoke:packed` 的打包行为电池 **95 通过 / 8 跳过**，joint Auto Review smoke 在 source / packed 两条车道与 web / headless 两种组合全部通过；跳过项是无可用内核 runner 的受限 bash 与共享 IPC。发布矩阵与 GitHub Release 由 tag 触发的 `release.yml` 完成，本机不发布。
## SSH 分支再次合入主线（v0.1.23）（2026-11-19）

**状态：合并与适配已实施；本节的验证格待完整门禁跑完后回填。SSH 能力默认关闭，随 `v0.1.24-beta.1` 发版（见[发版验收](#v0124-beta1-发版验收2026-11-22)）。** 从 `f9a1f38`（`feat/ssh-workspace`，包 `0.1.22-ssh.1`）以 merge 合入 `main` 的 `8dee97a`（`v0.1.23`，合并基 `f2dd05b`），合并提交为 `d93eb2b`。主线七笔提交：PR #68（`45950f6`，精确支持 DSH `0.2.2-rc.4`）、PR #69（`e5e4417`，面板/详情页 8 语言本地化、8 语言根 README 与逐功能用户指南、贡献与安全治理、生成的第三方许可清单）、PR #70（`ac13ce7`，精确支持 `0.2.2-rc.5`），以及 v0.1.22 / v0.1.23 的发版文档。本次只把分支自己的适配重新贴到主线结构上，不复制主线的实现。

**适配内容：**

- **八语言本地化**：`src/client/locales.ts` 改为主线的每语言模块 barrel；分支新增的 252 个键（`remote.*` / `ssh.*` / `panel.remote*` 与远端错误码）追加进八份字典。`zh` 是规范键集，`en` 是审阅过的英文稿；`ja` / `es` / `fr` / `de` / `ru` / `pt` 的译文随本次合入补齐，由 `tests/locale-parity.spec.ts` 钉住键集合、键序与占位符。八个根 README 同步 SSH 简介条目与「SSH 远端环境（实验性）」章节。
- **兼容合同**：核心部分直接采用主线的 26 个精确发布、全部 peer range 与 `0.2.2-rc.5` 开发 pin；`SUPPORTED_SSH_RELEASES` 后缀扩为 `0.2.2-rc.1`–`0.2.2-rc.5`，四个 SSH 可选 peer 保持全量 allowlist range 与 `optional: true`，SSH 开发 pin 跟随核心 pin 前移，`pnpm-workspace.yaml` 的 release-age 豁免同步到 rc.5。
- **SSH 地板证据**：对比 npm tarball，`@deepseek-ai/dsh-ssh`、`dsh-fs-ssh`、`dsh-sandbox-ssh`、`dsh-subprocess-ssh` 的 `lib/` 树在 `rc.3`→`rc.4` 与 `rc.4`→`rc.5` 均逐字节相同，只有 `package.json` 的 `version` 与包间精确 pin 变化；实际运行的是与 rc.3 相同的实现，因此未新增适配分支（审查记录见[迁移参考](../../reference/dsh-0.2.2-migration.md)）。
- **包版本与文档**：分支包版本改为未发布的 `0.1.24-ssh.1`；`AGENTS.md` 的 SSH 段、兼容门禁计划与 ADR-0032 的当前地板列表、控制面参考里的 broker 安装示例同步到 rc.5。
- **冲突面**：`package.json`、`pnpm-workspace.yaml`、`pnpm-lock.yaml`（以合并后的 manifest 为准重新生成，未手工合并 lock）、`src/client/index.ts`、`src/client/locales.ts`、`README.md` / `README.en.md`、路线图本节；ADR 编号无冲突（分支停在 0048/0049，主线到 0046）。`pnpm install` 后 `pnpm compat:check` 通过：26 个精确版本、核心与 SSH 开发 pin 均为 `0.2.2-rc.5`、安装树一致、SSH floor 为 `rc.1`–`rc.5`、Auto Review 联合集合 11 个精确发布。

**验证（2026-11-19，macOS arm64 / Node `24.18.0` / pnpm `11.25.0`，`0.2.2-rc.5` 开发树）：**

**验证（2026-11-19，macOS arm64 / Node `24.18.0` / pnpm `11.25.0`，`0.2.2-rc.5` 开发树）：**

- `compat:check`：allowlist / 28 个 peer / 核心与 SSH 开发 pin / 安装树一致（26 个精确版本；SSH floor `0.2.2-rc.1`–`0.2.2-rc.5`；Auto Review 联合集合 11 个精确发布）；`licenses:check` 报告 `THIRD_PARTY_LICENSE` 与声明一致；`docs:check` 0 错误 0 警告；lint 0 警告 0 错误；双端 typecheck 与 `build` 通过。
- `kernel:probe`：本会话的 Host 自身运行在沙箱内，`sandbox-exec` 的 `sandbox_apply` 被拒、无 bwrap / Landlock，因此本机无可用受限执行 runner；受限内核断言按设计跳过（与 `v0.1.23` 基线记录一致）。
- 完整 `vitest`：**2367 通过 / 211 跳过 / 20 失败**（151 个文件：128 通过 / 10 失败 / 13 跳过）。20 个失败全部属于同一宿主环境类：Host 自身被沙箱化、共享 Registry 的本机 IPC 拒绝 sandboxed peer，第二挂载得到 `contended` 而非 `follower`（或派生 `owner-without-remote-protocol`）。这与 `v0.1.23` 基线记录的 17 个失败属于同一集合（`registry`、`registry-operation`、`registry-lease`、`registry-multiprocess`、`authority-boundaries`、`b9-review-regressions`、`skills-authority`、`skills-registry` 八个文件），另加分支自有的同类用例 `remote-exec`（2）与 `remote-personal-ops`（1）；没有本地行为、locale 或 compat 断言失败。首次运行还暴露 `locale-parity` 对新增技术文案的误判（平台名 / `Helper` / 字段占位符 / 单词技术标签被当成未翻译），现按既有 `neutral` 机制显式豁免这些键，并把 pt 的 `Link` 步骤改为 `Ligar`。
- 冒烟与打包（0 失败）：compose **58/58**、behavior **96 通过 / 0 失败 / 8 跳过**、journey **88 通过 / 0 失败 / 2 跳过**、`pack:check` **310** 个成员、`smoke:packed` 的行为电池 **95 通过 / 0 失败 / 8 跳过**、`auto-review:fork` 通过，联合 Auto Review smoke 在 source / packed 两条车道、web / headless 两种组合与官方 bundle 前后两种顺序全部通过。跳过项均为无可用内核 runner 的受限 bash 与共享 IPC 断言。
- 因此 `pnpm verify:all` 在本机与发版基线一样于 `pnpm test` 处以环境性失败退出；其余门禁按基线做法逐条运行并全绿。跨平台与旧 pin 矩阵留给 push 后的 CI。

提交结构：合并提交 `d93eb2b`（解冲突 + 兼容合同 + zh/en 键合并 + 版本 `0.1.24-ssh.1`）、`314ad0b`（六语言 locale 与 README 翻译）、`9f152e2`（本节及 `AGENTS.md` / 迁移参考 / ADR / 计划的地板更新）、`0f9918a`（locale parity 的 neutral 集合与 pt 步骤文案）。


## SSH 环境与 Workspace Root 绑定拆分（2026-11-20）

personal 模式的连接和 Workspace Root 已分别管理。同一个 Workspace 可通过同一条连接绑定多个远端目录。旧文件迁移、核验范围和 CI 修复见 [拆分计划](../completed/2026-11-20-ssh-environments-and-workspace-bindings.md)。

## SSH 开放范围收窄为个人模式（2026-11-21）

未发布的 SSH 分支仅向用户开放默认关闭的个人模式。界面、设置和 Host 控制面同步限制开放范围，npm 包移除 SSH Broker 入口与安装脚本。旧档位的停用和迁移办法见 [SSH 远端环境参考](../../reference/ssh-remote-environments.md#停用的旧配置)。

macOS arm64、DSH `0.2.2-rc.5` 验证：全量测试 2509 通过、133 跳过。默认组合冒烟 58 通过。兼容性、构建、lint、文档和 npm 打包检查通过。真实远端主机与 Broker 的实机用例未运行。

## 个人 SSH 外部评审后续（2026-11-22）

未发布分支包版本调整为 `0.1.24-beta.1`。停用的 broker 实现与探针保留，以便后续评估，发布包仍排除 broker 入口。当前协议与升级要求见[控制面参考](../../reference/multi-environment-control-plane.md)，个人 SSH 的超时、Helper 和访问密钥语义见[SSH 参考](../../reference/ssh-remote-environments.md)。历史 SSH 证据中的机器路径已替换为占位符，含路径的旧面板截图由脱敏文本与 RPC 记录替代。

本机 macOS / DSH `0.2.2-rc.5` 复验通过 lint、类型、构建、兼容、许可证、文档和打包检查，Seatbelt 探针有效。原生全量测试 2559 通过、133 跳过、0 失败。compose、behavior、journey 与 packed smoke 分别通过 58、137、98、136 项断言。该变更的真实 SSH、GUI 手工验收与跨平台矩阵尚待验证。

同日的 PR #73 自动评审（Codex，reviewed commit `1c4e267`）另提出 1 条 P2：`remote_copy` 的两条上传路径（`local → sftp`、`sftp → sftp`）只在源绑定时比较 `maxBytes`，源在 `stat` 后增长时会把超限字节先写入远端 staging，再由 `source-changed` 收尾。隔离复现（1024 字节预算、绑定后增长到 4096 字节）两条路径各发出 1 次 4096 字节写。修复把预算收紧为 `RemoteStage.write` 的累计写入前检查（`transfer-too-large`），两条上传循环共用；回归断言超限时目的端 0 次 SFTP 写、无目标、无 staging 残留，并补恰好填满预算的正例。本机 `tests/remote-copy.spec.ts` 53 tests（52 passed / 1 skipped）、lint / typecheck / docs:check 通过；最终树全量 2465 passed / 213 skipped / 23 failed，失败全部是既有的 sandboxed-peer 共享 Registry 类（与 `v0.1.23` 基线同类，均不经过本改动）。范围、红/绿证据与退出验收见[计划](./2026-11-22-remote-copy-stream-budget.md)；语义见[控制面参考](../../reference/multi-environment-control-plane.md#sftp-传输g2三个方向单文件无用户入口)。首轮 CI（[run 45011838211](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/45011838211)）在 `verify (macos-latest, group 4, Node 22.19.0)` 的 `0.2.1-alpha.4` 车道失败：既有用例 `refuses symlink and multilinked sources at the bound open` 因 macOS `F_GETPATH` 对多硬链接 vnode 可能命名任一链接，被分类为 `source-escapes-root` 而非 `source-multilinked`；`gate` 为连带失败，其余 27 个 verify job 与同 job 其他版本通过。分类改为先按 `nlink` 拒绝，并加 mock 回归 `tests/remote-copy-local-link-classification.spec.ts`（红/绿见计划 §7）；推送后复跑整轮矩阵。复跑（[run 45018215618](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/45018215618)，`a5757c0`）又在同一车道暴露既有 `bounds a stalled fsync without publishing again` 的 40ms 预算竞态：预算可能在插桩调用前耗尽，令 `entered` 永不落定并挂到 30s 测试超时。该用例改为 1s 预算并先取传输结果、再断言方法确实被调用（提前耗尽立即报错），7 例通过。

## v0.1.24-beta.1 发版验收（2026-11-22）

这是 `0.1.24` 线的首个预发布，沿用「文档准备提交 → 正式发版提交 → 正式提交上的 annotated tag」的步骤，但正式发版提交只作版本标记：`0.1.24-beta.1` 已随 SSH 分支合入（PR #73，`506a52f`）写入 `package.json`，没有可改写的版本差异，因此该提交为 empty commit（`chore(release): v0.1.24-beta.1`），tag 指向它，`release.yml` 仍强制校验 tag 与 `package.json` 的 `version` 一致。自 `v0.1.23`（`8dee97a`）以来 `main` 有两笔内容提交：PR #72（`b4769d6`，Workspace Folders 对话框的附加根列表滚动）与 PR #73（`506a52f`，SSH 远端环境个人模式）。内容归 CHANGELOG 双语对；SSH 能力默认关闭、仅个人模式，`team` / `hardened` / broker 档位停用且不进发布包；没有配置或协议层面的不兼容变更。

准备提交只改文档与 CHANGELOG。在本机 macOS arm64 / Node `24.18.0` / pnpm `11.25.0` / DSH `0.2.2-rc.5` 上对准备提交后的树运行：`docs:check`（0 错误 0 警告）、`compat:check`（26 个精确发布；SSH floor `0.2.2-rc.1`–`0.2.2-rc.5`；核心与 SSH 开发 pin 均为 `0.2.2-rc.5`；Auto Review 联合集合 11 个精确发布；allowlist / peers / 开发 pin / 安装树一致）、`licenses:check`（`THIRD_PARTY_LICENSE` 与声明一致）、lint（0 警告 0 错误）、双端 typecheck、`build`、`pack:check`（**314** 个成员）全部通过。准备提交没有触及 `src/`、`scripts/`、`cordis.patch.yml` 或依赖，代码树与已合入的 `506a52f` 逐字节相同，因此本次未重跑 vitest 与冒烟；跨平台矩阵与真实安装由 tag 触发的 `release.yml` 完成：verify 等待与正式提交同 SHA 的 main push CI 与最终 gate，publish 走 npm trusted publishing 并创建 GitHub Release。该发布的真实远端主机、GUI 手工验收与跨平台矩阵证据仍以 `v0.1.24-beta.1` 的 beta 反馈和后续 CI 为准。

预发布发布策略：`release.yml` 在 publish 前运行 `scripts/release-channel.mjs`，从 `package.json` 的版本推导 npm 发布标签与 GitHub 发布渠道——`0.1.24-beta.1` 发布到 npm 的 `beta` 标签，`latest` 仍为 `v0.1.23`；GitHub Release 以 `--prerelease --latest=false` 创建，不成为 latest release。因此 README 的「当前最新发布」、npm 安装段与裸包名安装示例区分稳定线与 beta：裸包名仍装稳定版，安装本 beta 需显式指定 `@beta` 或精确版本。该策略由 `tests/workflows.spec.ts`（`distTagFor` / `isPrerelease` 与 workflow 断言）钉住，文档见[发版流程](../../development/release-workflow.md#预发布prerelease)。

## v0.1.24-beta.2 发版验收（2026-11-23）

这是 `0.1.24` 线的第二个 beta，沿用「文档准备提交 → 仅版本号的正式发版提交 → 正式提交上的 annotated tag」的步骤。自 `v0.1.24-beta.1`（`3c3ddb1`）以来 `main` 只有一笔内容提交：PR #75（`8e21ca4`，SSH 依赖修复引导与 Helper 安装诊断）。内容归 CHANGELOG 双语对；该改动把开启 SSH 后的依赖检查、可复制的 Profile 安装命令，以及 Helper 失败的阶段与远端状态诊断加进面板，未改变配置、协议或默认行为，没有不兼容变更。其 main push CI（[run 45122509718](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/45122509718)，`8e21ca4`）在准备时仍在排队；tag 触发的 `release.yml` verify 会等待与正式提交同 SHA 的 main push CI 与最终 `gate`，跨平台矩阵由该次运行判定。

准备提交只改文档与 CHANGELOG；正式提交只改 `package.json` 的 `version`（`0.1.24-beta.1` → `0.1.24-beta.2`），tag 指向正式提交。本次在本机 macOS arm64 / Node `24.18.0` / pnpm `11.25.0` / DSH `0.2.2-rc.5` 上对准备提交后的树运行：`docs:check`（0 错误 0 警告）、`compat:check`（26 个精确发布；SSH floor `0.2.2-rc.1`–`0.2.2-rc.5`；核心与 SSH 开发 pin 均为 `0.2.2-rc.5`；Auto Review 联合集合 11 个精确发布；allowlist / peers / 开发 pin / 安装树一致）、`licenses:check`（`THIRD_PARTY_LICENSE` 与声明一致）、lint（0 警告 0 错误）、双端 typecheck、`build`、`pack:check`（**324** 个成员）全部通过。与本次内容相关的 7 个测试文件 **224 通过 / 1 失败**：失败项是 `tests/remote-personal-ops.spec.ts` 的 `keeps the owner store and follower IPC live across a digest change`（期望 `follower`、实际 `contended`），属于既有的 sandboxed-peer 共享 Registry 环境性失败集合，不经过准备提交。准备提交没有触及 `src/`、`scripts/`、`cordis.patch.yml` 或依赖，代码树与已合入的 `8e21ca4` 逐字节相同，因此本次未重跑全量 vitest 与冒烟；跨平台矩阵与真实安装由 tag 触发的 `release.yml` 完成。

预发布发布策略：`release.yml` 在 publish 前运行 `scripts/release-channel.mjs`，从 `package.json` 的版本推导 npm 发布标签与 GitHub 发布渠道——`0.1.24-beta.2` 发布到 npm 的 `beta` 标签，`latest` 仍为 `v0.1.23`；GitHub Release 以 `--prerelease --latest=false` 创建，不成为 latest release。因此 README 的「当前最新发布」、npm 安装段与裸包名安装示例区分稳定线与 beta：裸包名仍装稳定版，安装本 beta 需显式指定 `@beta` 或精确版本。该策略由 `tests/workflows.spec.ts`（`distTagFor` / `isPrerelease` 与 workflow 断言）钉住，文档见[发版流程](../../development/release-workflow.md#预发布prerelease)。

## v0.1.24-beta.3 发版验收（2026-11-23）

这是 `0.1.24` 线的第三个 beta，沿用「文档准备提交 → 仅版本号的正式发版提交 → 正式提交上的 annotated tag」的步骤。自 `v0.1.24-beta.2`（`aca08d9`）以来 `main` 只有一笔内容提交：PR #76（`301f85b`，SSH 转发流的 BoringSSL PSK 回退）。内容归 CHANGELOG 双语对；该改动只影响 DSH Desktop 的 BoringSSL 运行时：Host 端替换上游转发流的那一次调用，Helper 安装额外部署 `helper-entry-v3.mjs`，`helper-entry.mjs`、`integrity`/`helperPath`/`bindingDigest` 与已登记 Root 都不变，plain Node 继续协商原套件，旧 Helper 以 `helper-outdated` 重装一次。没有配置、协议或默认行为层面的不兼容变更。其 main push CI（[run 45148872996](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/45148872996)，`301f85b`）在准备时仍在排队；tag 触发的 `release.yml` verify 会等待与正式提交同 SHA 的 main push CI 与最终 `gate`，跨平台矩阵由该次运行判定。

准备提交只改文档与 CHANGELOG；正式提交只改 `package.json` 的 `version`（`0.1.24-beta.2` → `0.1.24-beta.3`），tag 指向正式提交。本次在本机 macOS arm64 / Node `24.18.0` / pnpm `11.25.0` / DSH `0.2.2-rc.5` 上对准备提交后的树运行：`docs:check`（0 错误 0 警告）、`compat:check`（26 个精确发布；SSH floor `0.2.2-rc.1`–`0.2.2-rc.5`；核心与 SSH 开发 pin 均为 `0.2.2-rc.5`；Auto Review 联合集合 11 个精确发布；allowlist / peers / 开发 pin / 安装树一致）、`licenses:check`（`THIRD_PARTY_LICENSE` 与声明一致）、lint（0 警告 0 错误）、双端 typecheck、`build`、`pack:check`（**324** 个成员）全部通过。与本次内容相关的 5 个测试文件 **181 通过 / 1 失败**：失败项是 `tests/remote-personal-ops.spec.ts` 的 `keeps the owner store and follower IPC live across a digest change`（期望 `follower`、实际 `contended`），属于既有的 sandboxed-peer 共享 Registry 环境性失败集合，与 `v0.1.24-beta.2` 记录同形，不经过准备提交。准备提交没有触及 `src/`、`scripts/`、`cordis.patch.yml` 或依赖，代码树与已合入的 `301f85b` 逐字节相同，因此本次未重跑全量 vitest 与冒烟；跨平台矩阵与真实安装由 tag 触发的 `release.yml` 完成。

预发布发布策略：`release.yml` 在 publish 前运行 `scripts/release-channel.mjs`，从 `package.json` 的版本推导 npm 发布标签与 GitHub 发布渠道——`0.1.24-beta.3` 发布到 npm 的 `beta` 标签，`latest` 仍为 `v0.1.23`；GitHub Release 以 `--prerelease --latest=false` 创建，不成为 latest release。因此 README 的「当前最新发布」、npm 安装段与裸包名安装示例区分稳定线与 beta：裸包名仍装稳定版，安装本 beta 需显式指定 `@beta` 或精确版本。该策略由 `tests/workflows.spec.ts`（`distTagFor` / `isPrerelease` 与 workflow 断言）钉住，文档见[发版流程](../../development/release-workflow.md#预发布prerelease)。

## v0.1.24-beta.4 发版验收（2026-11-23）

这是 `0.1.24` 线的第四个 beta，沿用「文档准备提交 → 仅版本号的正式发版提交 → 正式提交上的 annotated tag」的步骤。自 `v0.1.24-beta.3`（`02c89fd`）以来 `main` 只有一笔内容提交：PR #77（`ffa53fc`，活跃 SSH 连接下卸载插件的 Host 退出修复、随插件发行的 SSH 依赖安装命令与 Desktop 一键安装入口）。内容归 CHANGELOG 双语对；该改动只在 Host 与 Helper 侧收束事件与清理顺序，并新增一个随包发行的安装脚本，未改变配置、协议或默认行为，没有不兼容变更。其 main push CI（[run 45183439032](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/45183439032)，`ffa53fc`）在准备时仍在排队；tag 触发的 `release.yml` verify 会等待与正式提交同 SHA 的 main push CI 与最终 `gate`，跨平台矩阵由该次运行判定。

准备提交只改文档与 CHANGELOG；正式提交只改 `package.json` 的 `version`（`0.1.24-beta.3` → `0.1.24-beta.4`），tag 指向正式提交。本次在本机 macOS arm64 / Node `24.18.0` / pnpm `11.25.0` / DSH `0.2.2-rc.5` 上对准备提交后的树运行：`docs:check`（0 错误 0 警告）、`compat:check`（26 个精确发布；SSH floor `0.2.2-rc.1`–`0.2.2-rc.5`；核心与 SSH 开发 pin 均为 `0.2.2-rc.5`；Auto Review 联合集合 11 个精确发布；allowlist / peers / 开发 pin / 安装树一致）、`licenses:check`（`THIRD_PARTY_LICENSE` 与声明一致）、lint（0 警告 0 错误）、双端 typecheck、`build`、`pack:check`（**328** 个成员，含新增的 `scripts/install-ssh-deps.mjs` 与 `lib/install-ssh-deps.js`）全部通过。与本次内容相关的 6 个测试文件 **112 通过 / 1 失败**：失败项是 `tests/remote-personal-ops.spec.ts` 的 `keeps the owner store and follower IPC live across a digest change`（期望 `follower`、实际 `contended`），属于既有的 sandboxed-peer 共享 Registry 环境性失败集合，与 `v0.1.24-beta.2`、`v0.1.24-beta.3` 记录同形，不经过准备提交。准备提交没有触及 `src/`、`scripts/`、`cordis.patch.yml` 或依赖，代码树与已合入的 `ffa53fc` 逐字节相同，因此本次未重跑全量 vitest 与冒烟；跨平台矩阵与真实安装由 tag 触发的 `release.yml` 完成。

预发布发布策略：`release.yml` 在 publish 前运行 `scripts/release-channel.mjs`，从 `package.json` 的版本推导 npm 发布标签与 GitHub 发布渠道——`0.1.24-beta.4` 发布到 npm 的 `beta` 标签，`latest` 仍为 `v0.1.23`；GitHub Release 以 `--prerelease --latest=false` 创建，不成为 latest release。因此 README 的「当前最新发布」、npm 安装段与裸包名安装示例区分稳定线与 beta：裸包名仍装稳定版，安装本 beta 需显式指定 `@beta` 或精确版本。该策略由 `tests/workflows.spec.ts`（`distTagFor` / `isPrerelease` 与 workflow 断言）钉住，文档见[发版流程](../../development/release-workflow.md#预发布prerelease)。
