# Worktree 感知的附加根建议与 Git 元数据授权实施计划

> 状态：**已完成——P1–P10 与第十九次修订随 `v0.1.17` 发版；第二十次修订（会话激活时一次只读检查 + 非模态 Toast + 显式确认 Dialog + snooze）及后续提示位置/Dialog/关闭按钮修订随 `v0.1.20` 与 `v0.1.21` 发版，验证状态以[路线账本](../active/2026-09-12-multi-root-workspace.md#进度总账)为准**。先完成 B（P1–P7），再实施 A（P8–P10）；第十九次修订把 A 的目标改为主 checkout、开关改为实验性默认关闭，并加入单/多候选提示分流；第二十次修订把自动发现从常驻长轮询收敛为会话激活时一次只读检查。
> 决策：[ADR-0039](../../decisions/ADR-0039-worktree-aware-root-suggestions.md)（Accepted，2026-11-14 第二十次修订）。
> 需求：[§7.16–§7.18](../../requirements/multi-root-workspace.md#7-行为约束)。

## Goal

在插件内按以下顺序交付 worktree 支持：

1. **B：worktree 发现与附加根建议。** primary root 是 main 或 linked checkout 时，发现同一 common 下外部/预存在/其他创建者的 worktree，提示用户把该 worktree 加为 `inherit` 附加根；**默认 pool 没有特殊排除**：主仓库作为 primary 时 `.agents/worktrees/<id>` 位于 primary 内，按包含规则过滤；primary 本身是 pool worktree 时，兄弟 pool worktree 仍是合法 B 候选（再受 registry/上限/ignore 约束）；永不自动添加。
2. **B 的删除生命周期。** 已登记的 B 根只有在 `record.path` 确认缺失时才提供专用清理入口；面板显示、用户显式触发、owner 复验、永不自动删除；缺失根占额度直到清理或手动删除。
3. **A：linked worktree 的共享 Git 元数据授权。** 用户确认后登记 canonical common git dir 为 `inherit` 根，解决默认 pool 和外部 linked checkout 的 `git add` / `git commit` 写入缺口。

插件详情提供与「启用附属根 Skills」同款的全局开关，**实验性、默认关闭**（标题旁有“实验性”Tag）；显式开启后才启用 A/B 建议及 B 专用清理。

## Background

Worktree 可能被 Git 或手动删除、移动。B 解决兄弟 checkout 的源码树访问和已登记根清理。A 解决 linked checkout 作为 session primary 时的 Git 元数据写入：私有 `index` 在 admin 下，`objects`、`refs` 等位于共享 common，二者通常都在 primary 外。默认 pool 下主 checkout 包含 primary，按既有重叠规则不能登记整个主 checkout。

ADR-0039 已经过多轮只读复审，覆盖：

- 不运行任何 Git 子进程，只消费插件自己打开并解析的元数据快照；
- 两种 checkout 形态（`.git` 目录、`.git` 文件 + `commondir`）都遍历完整祖先链；
- submodule、linked worktree submodule、bare、separate main、worktreeConfig、relativeWorktrees、split/sparse index 的 inactive 边界；
- HEAD 语法、checkout/admin 文件系统身份、primary/candidate owner 复验；
- `unactivated`/`active`/`lost` 三态与 `WorktreePromptWaitResult` 判别联合；
- 映射 prune 只依据 owner 成功完整快照。

## Current State

- ADR-0039 第十七次修订接受 B；第十八次修订确定 A 的授权边界与全局开关。
- P1–P10 已全部实施：B 的发现、激活、提示、开关、owner 串行写入、sidecar 与专用清理，以及 A 的 common 候选、确认与受限 Git 旅程用例。
- 2026-11-09 的独立审计在 `feat/worktree-find` 的 `ceb708e` 上复现了六类缺陷（候选/owner 未绑定同一 common、指针目标先 `realpath` 再检查、owner 门禁在入队前读取、清理资格只在调用端、旧提示 ID 复用、客户端轮询不恢复），另指出 P4 握手未绑定 `promptsRoot`、follower `snapshotView()` 混用本地列表与 owner envelope，以及 P10 没有走真实 A 确认。返工 `R1–R6` 已实施，逐项见下节。
- 现有 Registry、scope、面板、`/workspace-folders` 命令与 Connection RPC 已经存在；本功能新增独立的 `multi-root-worktrees` 行与 `WORKTREE_ENDPOINTS`，不修改上游包。
- 未创建 tag，也未更新 CHANGELOG：发布是维护者的独立动作。

## Scope

### In scope（先 B，后 A）

- primary 必须是 Git main 或 linked checkout 根；普通目录/仓库子目录不执行本功能动作，曾 active 后失效也停止后台活动，仅收尾旧提示/资源。
- 受控枚举 `<common>/worktrees/*/gitdir`；包含 workspace 创建前已存在、由终端/IDE/forge/其他 DSH 创建的 worktree。
- 候选必须属于同一 common、双向指针一致、admin 在 `common/worktrees/<id>` 下、HEAD/common 结构合法。
- 用户确认后添加 `access='inherit'` 的附加根；提示按 workspace 共享，按 session mode 过滤。
- 已登记 B 根的 `missing`/`moved`/`changed`/`unregistered` 生命周期；专用 cleanup 入口；sidecar `worktreeRoots`。
- `worktreePromptWait` 判别联合、`unactivated`/`active`/`lost` 三态、watcher 释放与恢复。
- 完整祖先链、两种 checkout 形态、Unicode 路径等价、HEAD 语法、checkout/admin 身份、owner 复验。
- 平台：macOS / Linux / Windows（Windows 的文件句柄/文件 ID 实现按平台能力；无法提供稳定身份时不发提示或 stale）。
- A 仅在 linked primary 的 `workspace-write` 会话提示；通过完整快照绑定 primary/admin/common，显式确认后经 owner 新建普通 `inherit` 登记。
- `multi-root-worktrees.enabled` 全局开关默认 `false`（实验性），位于插件详情卡，与附属根 Skills 的开关独立生效。

### Out of scope

- 授权整个主 checkout、通过 effective cwd 选择授权目标、修改现有附加根权限来绕过 A 门禁。
- 自动添加、自动删除、自动清理；后台静默扩大授权。
- `git worktree list` 或任何 Git 子进程。
- 解析 commit 对象、读取 `objects`、执行 hooks/fsmonitor/attributes。
- submodule（含 linked worktree 本身是 submodule）、bare 派生 worktree、`--separate-git-dir` 主 checkout、`extensions.worktreeConfig=true`、`core.repositoryformatversion=1`/`--relative-paths`、split/sparse index。
- 未登记/未授权的外部 gitdir、UNC/设备路径、越界 symlink。
- **`forget-workspace` 新命令/RPC/owner 删除路径延期**：v1 不交付；ADR 只记录为未来 Registry maintenance，单独计划/需求排期。v1 删除只走 `removeForDeletedWorktree`，不依赖 forget。
- 修改 `primary-overlap`、`maxAdditionalRoots` 计数规则、上游包或 DSH 版本分支。

## Design

实现以 ADR-0039 为准，计划只固定模块边界：

| 模块 | 责任 | 关键约束 |
|---|---|---|
| `worktrees/metadata` | 可信 fd 逐段打开、`O_NOFOLLOW`/`O_NONBLOCK`、`fstat`、有界读取；config/index/HEAD/仓库结构解析 | 不启动 Git；不跟随中间/最终 symlink；FIFO/设备拒绝；解析失败即 inactive |
| `worktrees/activation` | 本层 `.git` 门禁、两种 checkout 形态、完整祖先链、Unicode 路径等价、submodule/inactive 判定 | 普通子目录第一道门禁直接退出；阴性继续更外层；无法排除即 inactive |
| `worktrees/inventory` | `<common>/worktrees/*/gitdir` 枚举、候选 key、`CommonState`/`WorkspaceState`、watcher | 不运行 `git worktree list`；admin/父目录 watcher 上限；`filename null` reconcile |
| `worktrees/prompt` | `WorktreePromptWaitResult`、`unactivated`/`active`/`lost`、显式重新检测、候选重新评估 | unactivated/lost 都停止后台重查；所有响应禁止 retry 字段；旧 prompt ID 失效 |
| `worktrees/registry` | `addNew`/`removeForDeletedWorktree`、sidecar `worktreeRoots`、映射 prune | owner 串行队列；完整快照才 prune；不 revive 手动记录 |
| `worktrees/owner` | primary/candidate 完整判据、HEAD 语法、checkout/admin 身份、祖先索引 | 写入使用同一 canonical 值；任何变化 `prompt-stale` |
| `worktrees/client` | 对话框、面板行、RPC schema、`stale`/`lost` 客户端行为 | 不发送路径；宿主/客户端同时校验判别联合 |
| Settings 与插件详情卡 | Host 开关、现代/旧版适配、卡片 Switch 与运行时失效 | 复用附属根 Skills 接缝与卡片，独立配置；Host 门禁先于后台活动和写入 |

## Implementation

### P0 文档（本阶段完成）

- [x] ADR-0039 第十八次修订（Accepted）。
- [x] 需求 §7.16–§7.18。
- [x] 本计划。
- [x] 路线账本条目（P0 / P1 未开始）。
- ADR 已满足 P1 的设计前置条件。

### P1 元数据快照与解析器（完成）

- 可信目录句柄逐段打开；中间目录/最终文件拒绝 symlink；`O_NOFOLLOW`/`O_NONBLOCK`；同 fd `fstat`；有界读取。
- config 快照：include/core.worktree/worktreeConfig/relativeWorktrees/split/sparse/objectFormat/repositoryformatversion/core.bare；记录 precomposeUnicode/ignorecase。
- HEAD 语法：`ref: refs/<refname>` 或 40/64 hex；primary/common/admin 共用。
- repository 结构：HEAD/config/objects/refs；admin 的 `HEAD`/`gitdir`/`commondir`；common。
- index 解析：v2/v3/v4、`link`/`sdir`/`040000`/未知版本拒绝；路径等价。
- 祖先链：两种形态、逐层 config/index、完整相对路径、阴性继续、无法排除 inactive。
- 单测覆盖最终 index 换链、中间目录换链、FIFO、split/sparse 伪 index、NFC/NFD、祖先遮蔽、sha256/version 1。

### P2 发现、激活、watcher 与 Host 设置（完成）

- 在 `multi-root-worktrees` 行新增默认 `true` 的 `enabled`，复用附属根 Skills 的现代 volatile Config / 旧版 Settings namespace 适配；无 Settings UI 时读取 loader Config。Host 按 ADR §9 控制发现和专用清理，关闭时唤醒 waiter、清理资源并失效旧提示。P4 接通 owner 写入前门禁。
- inventory、候选 key、`CommonState`/`WorkspaceState`、workspace 共享。
- `activation` 三态；首次门禁拒绝不建 watcher/sidecar。
- primary/ancestor watcher best-effort；active 时长轮询重挂复验；`lost` 清候选并释放 watcher/waiter/定时器，停止重挂。
- 恢复只经用户面板/命令 `list` 或显式重新检测；禁止自动 wait、one-shot 与周期重查；重建时清 `evaluated`、保留明确 `prompted`。
- 验收：普通目录/仓库子目录无后台；active→lost 停止后台→显式恢复新 ID；候选去重/上限/degraded。

### P3 Prompt RPC、UI 与插件设置开关（完成）

- 在「设置 → 插件 → Multi-root Workspace → 插件详情」现有卡片内，于「启用附属根 Skills」旁添加独立 Switch「启用 Worktree 附加根建议」/「Enable worktree root suggestions」。复用同一 Settings form 订阅与写入、revision、错误提示与旧版 `settings.plugin.item` 适配；支持即时生效和持久化，不另注册包级卡片。
- 关闭时退出提示和专用清理 UI，处理 `worktree/not-enabled` 并停止轮询；开启后对当前 live session 重新检测，已 `lost` 的 workspace 仍走显式恢复。
- `WorktreePromptWaitResult`：`prompt`/`timeout`/`unactivated`/`lost`/`stale`；所有分支禁止 `retryAfterMs`。
- 宿主 `WorktreeResponseMap` 与客户端 schema 同时校验；拒绝缺字段/错误 status/多余 retry。
- 面板/对话框：只展示 eligible 候选、`effectiveAccess`、remaining；**P3 只做只读预览，生产 `worktreePromptResolve`/确认按钮保持禁用（`worktree/not-enabled` 或路由未挂载），不得调用 Registry 写入**。
- resolve 后旧 prompt 失效；`stale`/`lost` 的客户端行为按 ADR-0039 §4.3。

### P4 Registry、owner 写路径与 sidecar/cleanup（完成）

> P4 是**首次可写阶段**：`addNew` 与完整 owner 复验必须在同一阶段实现；P3 的确认操作在 P4 验收通过前不启用。

- `addNew(primaryRoot, { path, access, expected })`：owner 串行队列；分开 primary/candidate；复用 add 校验；只新建不 revive。确认与专用写入同时接入 ADR §9 的设置门禁，覆盖在途 owner 请求的提交边界。
- owner 复验：primary 完整判据（含完整祖先链）+ candidate 激活判据（含祖先 gitlink）；primary/common/admin HEAD 语法；candidate admin HEAD == expected；`rootIdentity`/`adminIdentity` 比对；任何变化 → `prompt-stale`。
- `addNew` 在 owner 同一队列操作内先持久化登记再写 B 映射，返回 `{ id, path, addedAt, registryEpoch, registryRevision }`；禁止 follower 事后补写。保持跨文件崩溃窗口按手动根处理的降级。
- `removeForDeletedWorktree`：`record.path` 确认缺失 + `rootId + path + addedAt`；路径存在/无法判定/inaccessible → not-eligible。
- sidecar 全部写入（ignore/reset/映射新增、删除、prune）复用既有 Registry owner/lease/串行队列；follower 只走认证 IPC，不写文件。固定 sidecar 路径绑定 store，握手校验配置；teardown drain 写入后才释放 lease；内部 helper 不嵌套排队。
- prune 在 owner 队列内重取当前 sidecar 与完整 `RegistrySnapshotView`，不接受客户端旧快照作写入依据。跨 epoch 按 `rootId + path + rootAddedAt` 核对，匹配则重绑当前 epoch/revision，不匹配仅删映射；不可用或完整快照失败保留映射。精确规则以 ADR §5 / §6.8 为准。
- IPC 增加严格 schema 的 sidecar 查询/ignore/reset/reconcile 操作；映射新增/删除封装在 Registry 操作内，旧 epoch 请求拒绝、不明结果先对账，不自动重放。owner memory-only 降级不得变成 follower 各写副本。
- inactive 时专用 cleanup/ignore/reset/reconcile 不写入，停用 Registry change 触发的本功能任务；新 owner 仅在 workspace 显式重新激活后核对映射。
- 清理后释放额度；不自动删除；`forget-workspace` 延期，不在本阶段实现。
- 验收：等待 owner 时替换候选 → 无写入；authority 不可用 → 映射保留；owner 确认空 → prune；两个 Host 同时提交新增/删除/prune，通过 barrier 强制交错，验证串行执行且无覆盖/复活；旧空快照后新增的映射保留；owner 重启/接管后匹配旧映射重绑、不匹配修剪，旧 epoch 在飞请求拒绝。

### P5 Owner 竞态与平台验收（完成）

> P5 不新增可写入口；写路径已在 P4 与 owner 复验同阶段落地。P5 只验证竞态、身份和平台行为。

- 同路径删除重建（同提交/同 adminId/同 HEAD，inode 变化）→ `prompt-stale`。
- primary/candidate 任一激活判据在等待期间变化（祖先新增 `160000`、primary `.git` 移走）→ `prompt-stale`。
- 平台：macOS 文件句柄/Unicode；Windows 文件 ID/reparse point；无法提供稳定身份时不发提示/直接 stale。
- 验收等待 owner 时替换候选，断言 Registry 无写入；P3 确认在 P4 前不可用。

### P6 验证与平台矩阵（完成）

- 单测：metadata/activation/inventory/prompt/registry/sidecar/owner。
- 集成（**Web**）：`connection` + `webServer` 存在的真实宿主 + 客户端 schema；确认、清理、`WorktreePromptWaitResult` 全链路。
- 集成（**headless**）：组合可启动、现有 `/workspace-folders` 命令与 Registry 行为正常；不要求面板 RPC 路由，不为验收新增浏览器入口。
- e2e：
  - 外部 worktree 提示 → 确认 → `inherit` 根 + 清理；
  - **默认 pool 两场景**：主仓库为 primary 时 `.agents/worktrees/a`/`b` 位于 primary 内 → 无提示；以 `a` 为 primary 时 `b` 同 common、互不包含 → 进入 B 候选；
  - **P3 确认门禁**：P4 验收前 `worktreePromptResolve` 不可用，断言 Registry 无写入；
  - **owner 竞态**：等待 owner 时替换候选 → `prompt-stale`，Registry 无写入；
  - submodule / linked submodule / bare / separate main / version 1 inactive；
  - **snapshot/owner**：两种空快照、并发新增/删除/prune、owner 重启与接管、跨 epoch 重绑/修剪、旧请求拒绝，覆盖 ADR §5 / §6.8；
  - ordinary dir/repo subdir 无后台；
  - active→lost 停止后台→显式恢复新 ID；
  - 同路径删除重建 → stale；
  - `forget-workspace` 新入口不存在（延期），专用 cleanup 不依赖它。
- Settings：覆盖默认关闭、关闭/开启即时生效、跨重启持久化、现代/旧版卡片不重复、已登记根保留、旧提示和未提交的异步任务失效。真实 Web 验证与 Skills 并列且相互独立；headless 验证 loader 显式关闭。
- 平台：macOS 文件句柄/Unicode；Linux；Windows 文件 ID/reparse point；无法验证的行显式 skip 并打印原因。
- 门禁：`pnpm lint`、`typecheck`、`test`、`build`、`docs:check`；需要时 `compat:check`。

### P7 B 文档与发布准备（完成）

- 更新 B 的 requirements、双语 README、路线账本和实现文档；CHANGELOG 仅在实际发布时更新。完成 B 的验收和发布准备后进入 P8，是否拆成两次发布由路线账本记录。
- 不修改上游；不新增 DSH 版本分支。

### P8 A：common 候选与来源契约（完成）

- 复用 P1/P2 的 linked primary 快照，按 ADR §1 识别 `main-checkout` 候选（主 checkout 根）。绑定 canonical primary、admin、common 与主根的稳定文件身份和 admin HEAD；应用 `probeAdd`、全局设置与 `workspace-write` 门禁。B 的 inventory 继续独立。默认 pool 的主根包含 primary，`primary-overlap` 使其没有 A。
- 验收：默认 pool 和外部 linked checkout 都能得到相同形态的 common 候选；普通主 checkout、仓库子目录、仅 effective cwd 切入 linked checkout、伪指针、不受支持布局、既有登记或根校验拒绝时不产生 A 提示。分离式 gitdir 反例验证候选永远不会变成 common 的父目录。
- P8 只构造宿主候选；生产界面与确认在 P9 同阶段接通。

### P9 A：提示、确认与 owner 提交（完成）

- 扩展 B 的提示联合、双端 schema、工作区去重/忽略与可见队列。对话框分别展示 A/B 文案，A 显示 canonical common、`inherit`、共享元数据范围及持久性。客户端沿用 `sessionId + promptId + action` 确认，无路径参数。
- 同阶段接通 `addNew` 的 A 分支。请求 Host 和 owner 分别重跑来源与身份检查，owner 队列内按普通 Registry 规则新建；不 revive、不写 B 清理映射。开关关闭或 mode 变化时作废旧提示；已确认的普通根通过普通 Remove 撤回。
- 验收：验证送交 owner 前的 mode 切换和设置关闭都会作废旧提示。用队列屏障在 owner 提交前替换 common/admin、修改反向指针或祖先索引，断言无写入。按 ADR §9 验证跨 Host 已送交 owner 请求的边界。A/B 同时可见时，一个 session 的 A 过滤不得堵住该 session 的 B 提示。

### P10 A：受限 Git 旅程、回归与发布准备（完成）

- 在隔离夹具中分别用默认 pool 和外部 linked checkout 作为 live session primary。确认前，真实受限 shell 的 Git 写入因缺少元数据权限失败；确认后，在同一 `workspace-write` 模式、不走 `danger-full-access` 的条件下完成 `git add` 和 `git commit`，核对 index、commit/ref 产物。验证主 checkout 源码（当前 primary 之外）和无关目录仍拒写；普通 Remove 后，新进程再次无法写该 common。
- 覆盖 `read-only`、`danger-full-access` 无 A 提示、per-tool cap、authority 不可用以及设置关闭/开启；删除 linked checkout 后，A 根保持普通 Registry 生命周期，专用清理只追踪 B 根。
- 按现有 macOS / Linux / Windows 内核探测记录实跑与 skip 证据，回归 B 和完整门禁。更新实现文档、双语 README 与路线账本，实际发布时同步双语 CHANGELOG。

### R1–R6 审计返工（2026-11-09，完成）

> 返工不改变 ADR-0039 的设计，只把实现收回第十八次修订已经写明的边界。回归集中在 `tests/worktrees-audit-regressions.spec.ts`，客户端恢复在 `tests/client-worktree.spec.tsx`，IPC 绑定在 `tests/authority-native.spec.ts` / `tests/shared-registry.spec.ts`。

- **R1（审计 P1-a）候选与 owner 绑定同一 common。** `inventoryWorktrees()` 在 admin 名称之外要求候选解析出的 `common` 与正在枚举的 common 相同、admin 目录就是枚举项本身、候选 canonical 等于该 admin 指针的目标；`verifyPromptExpected()` 的 B 分支同时要求 `primary.common == candidate.common == 解析出的 common`，A 分支也要求 `candidate.common == primary.common`。回归：同仓库放置同名 admin 并指向另一仓库的真实 linked checkout；对 B 的伪造 `addNew` expectation 返回 `worktree/prompt-stale` 且 Registry 无写入。
- **R2（审计 P1-b）元数据 I/O 先拒绝再解析。** `canonicalExisting()` 先在字面拼写上逐段 `lstat`（父链必须是真目录、任何一级 symlink 都拒绝），之后才 `realpath`，并用 dev/ino 证明解析结果仍是同一对象；指针目标、`commondir`、admin、common 都不再跟随 symlink。`readRegularFile()`/`directoryIdentity()` 逐段 `O_NOFOLLOW|O_DIRECTORY` 打开父目录并在最终 open 后复核句柄，最终文件用同 fd `fstat` 与 pre-open `lstat` 比对。POSIX 路径只按 `/` 分段，`vendor\lib` 这类字面反斜杠目录不再被当成 `vendor/lib`；祖先 index 查找同样只按平台分隔符拆段。回归：admin 指针/commondir 指向目录 symlink 均 inactive；反斜杠路径可激活；祖先 `160000` 条目能被命中。Node 没有公开 `openat`，首次返工仍使用路径型最终 open，此边界由第二轮复审修复替代。
- **R3（审计 P1-c）提交门禁进入 owner 队列，调用端重读 live session。** `addNew()`、`removeForDeletedWorktree()` 与全部 sidecar mutation 在 `serialize()` 任务内、持久化前重读开关；`WorktreePrompt.resolve()` 在送交 owner 前重读 live session 的 primary、mode、开关与当前提示代次。回归：barrier 阻塞 owner 队列后关闭开关 → `worktree/not-enabled` 且无写入；A 提示在送交前切到 `read-only` → `worktree/prompt-stale` 且无写入。
- **R4（审计 P2-a）清理资格在 owner 内复核。** 专用清理在队列内要求 primary 仍通过完整激活判据，并且当前 sidecar 存在 `rootId + path + rootAddedAt` 完全匹配的 B 映射；手动根、A 根、lost primary 一律 `worktree/not-eligible`。`reset` 在无 ignore 时不再制造 sidecar revision，inactive workspace 不再写 sidecar。回归：缺失的手动根不可清理；primary 失效时 tracked 根不可清理；普通目录/空 reset 不创建 sidecar。
- **R5（审计 P2-b）快照变化必须换提示 ID。** `refreshInventory()` 只在完整 `PromptExpectation` 深相等时复用旧 record；key 不变但 admin HEAD、primary 快照或目录身份变化时生成新 promptId，并递增 revision、唤醒持有旧 ID 的 waiter。回归：合法切换 admin HEAD 后旧 ID 返回 `stale`，重新查询得到新 ID。
- **R6（审计 P2-c）设置与显式面板操作恢复轮询。** `installSkillsSettingsCard()` 返回 worktree 开关订阅，overlay 用它重挂因 `worktree/not-enabled` 停止的循环；`WorktreeClient` 增加 `notify/subscribe`，面板成功执行显式 `list`（可恢复 `lost` workspace）后唤醒同一会话的 overlay。回归：设置信号与 `notify()` 都能让已停止的 overlay 重新拿到提示；面板 `list` 会发出该信号。
- **P4 契约补齐。** IPC `hello` 绑定 `promptsRoot`，不匹配即拒绝（`tests/authority-native.spec.ts`）；follower `snapshotView()` 返回 owner 的同一份 envelope（roots/available/epoch/revision），不再在应用后回退本地 `list()`（`tests/shared-registry.spec.ts`）。
- **P10 旅程重写。** `tests/worktrees-git.e2e.ts` 现在分别以默认 pool（`.agents/worktrees/w1`）与外部 linked checkout 作为 live session primary：先断言受限 `git add` 失败，再通过真实 `worktreePromptWait` 取 A 提示并 `resolve('add')`，随后在同一 `workspace-write` 下完成 add/commit，核对 index、HEAD 与 common 中的 branch ref；主 checkout 源码与无关目录仍拒写；普通 Remove 后新进程再次拒写。真实 Web 组合的证据补在 `smoke:journey` 的 web leg：同一进程启动真实浏览器组合，用真实 HTTP Connection RPC 完成 worktree 开关关闭/恢复、B 提示确认、B 删除清理与 A 提示确认（不是捕获 handler 的替身）；headless 仍只验证组合启动与现有命令。

### 第二轮复审修复（2026-11-09）

- 用原生目录句柄实现 [ADR §2.4](../../decisions/ADR-0039-worktree-aware-root-suggestions.md#24-结构校验不启动-git只消费元数据快照)。回归覆盖原始 `//`、`symlink/..`、持续父目录换链和带 U+FEFF 的祖先 gitlink。
- 将 owner 复验移到队列内最后一次异步读取之后，调用 Host 在权威恢复后校验再送交。屏障覆盖此时关闭开关、原址替换和 mode 切换。
- 发现与轮询按设置和激活代次失效，保留 lost 的显式恢复规则和已观察到的路径重建警告。回归覆盖在途关闭、开关切换和路径重建。
- 补齐[共享 Registry 线协议](../../architecture/registry-authority-service.md#3-授权与版本协议)的旧版握手、Worktree 能力协商、重放答复和完整 owner 快照。
- 两条受限 Git 旅程使用平台原生 Node 写入探针和 PATH 上的 Git。按 provider 返回的实际方言决定内核探针结果。实际执行和 skip 证据只记[路线账本](../active/2026-09-12-multi-root-workspace.md#worktree-感知建议-ba-实施2026-11-09)。

### 第十九次修订实施（2026-11-10，完成）

> 决策见 ADR-0039 第十九次修订。本阶段不改变 owner 串行写入、逐项复验或不启动 Git 的边界。

- **A 目标**：`commonCandidate()` 从 `repo.common` 改为主 checkout 根 `dirname(repo.common)`；候选要求 `<main>/.git` 是真实目录且 canonical 等于 common，记录主根与 admin 身份。kind/`promptKey`/discovery key 改为 `main-checkout`；owner 复验新增 `<main>/.git` 回指与主根身份，旧 `.git` 根仍在时主根因嵌套不提示（需手动移除旧根）。
- **默认 pool**：`<main>` 包含 primary，`probeAdd` 的 `primary-overlap` 拒绝，A 不进入队列；Git 写回到会失败，这是接受的限制。
- **`--separate-git-dir`**：`dirname(common)` 是 store 父目录而非真正主 checkout，且无法从 linked checkout 元数据区分；对话框显示实际路径并披露歧义。
- **开关**：`multi-root-worktrees.enabled` 缺省 `false`；`Config`、Settings schema、初始值、Host getter、客户端 overlay fallback 与 `cordis.patch.yml` 全部改为严格 `true` 才启用；插件详情卡标题旁显示“实验性”Tag（与 Auto Review 同款）。
- **提示分流**：`worktreePromptWait` 恰好一个可见候选返回 `prompt`，两个及以上返回 `prompts`；列表行可勾选（B 默认勾选、A 默认不勾并内联共享元数据/separate 披露），`promptIds` 批量确认，逐项 stale 通过 `skipped` 返回，客户端按 key 标红并保持未勾选。`seenPromptId` 由 `seenViewRevision` 取代。
- **验证**：worktree 专项 12 个 spec **131 通过、3 skip**；全量 vitest **1356 通过、17 个既有 lease/follower 环境失败**（与审计基线同一组，见路线账本）；`lint`、`typecheck`、`build`、`docs:check` 通过。真实 Web 冒烟的默认关闭、双候选列表、主 checkout A 确认与 `.git` 移除后的回归随 `smoke:journey` 的 web leg 执行。

### Devin Review 修复（2026-11-11，完成）

> PR #48 的 Devin Review 在 `78e6d47` 上提出两条 finding（当时均未解决）。修复不改变 ADR-0039 的其余边界，只把两条已写明的边界收回实现。

- **客户端“未知”语义（BUG，`src/client/skills-settings.tsx`）**：`enabled()` 原先只从绑定的 Settings form 取值，没有 form 时返回 `false`；loader `enabled: true` 而没有浏览器 `configForms`/`settingsScope` 的组合因此永远不会发起 `worktreePromptWait`。现在只有 ready 且已发布布尔值的 form 才按值抑制，其余状态（无 form、loading/unavailable/error、ready 但无值）返回 `true`，由宿主的 `worktree/not-enabled` 决定并停止循环。回归：`tests/client-skills.spec.tsx` 的无 form、三种非 ready 状态、ready 明确 false/true 与 ready 空值用例。
- **owner 门禁 fail closed（SEC，`src/registry.ts`）**：`requireWorktreesEnabled()` 原先只在 provider 返回 `false` 时拒绝，provider 缺失（worktree 行未挂载或已 dispose）即放行；协商过 `promptsRoot` 的 IPC peer 可在 owner 没有开关时提交 `addNew`、`removeForDeletedWorktree` 和 sidecar mutation。现在要求 provider 显式返回 `true`，缺失一律 `worktree/not-enabled`；read 形状的 sidecar 操作不受影响。`tests/support/registry-stack.ts` 为裸 Registry 栈安装 `() => true` 的替身（生产中的唯一调用者是 worktree 行），`tests/worktrees-owner.spec.ts` 覆盖 absent provider 下三条写路径全部拒绝且 read 仍可用。
- **验证**：worktree 相关 spec 与 `client-worktree`/`authority-native` 实跑 **134 通过、44 环境 skip**；全量 vitest **1362 通过、17 个既有 lease/follower 环境失败**（与审计基线同一组，均因当前 Host 被沙箱化而无法协商共享 IPC）；`lint`、`typecheck`、`build`、`docs:check` 通过。

### 第二十次修订实施（2026-11-14，完成）

> 决策见 ADR-0039 第二十次修订。授权语义不变：不自动添加/删除根，`addNew` 仍是唯一写入路径，owner 复验与 `worktree/prompt-stale` 行为不变。本阶段记录实施范围与验收清单；实际验证证据只记[路线账本](../active/2026-09-12-multi-root-workspace.md#进度总账)，不在本小节预写。

- [x] **宿主：`fresh` 只读检查**。`worktreePrompt` 增加可选 `fresh`（默认 `false`，strict）；`fresh: true` 只返回「未被 Host `offered` 认领且不被当前 snooze 覆盖」的候选，纯查询、无副作用；`prompt()` 的 `ensureWorkspace` 固定 `'first'`，自动检查不复活 `lost`；返回 `{ prompts, viewRevision }` 不变。
- [x] **宿主：`worktreePromptSeen` 与 `offered`**。新增端点，把命中当前 queue 且仍 eligible 的 `promptIds` 的 discovery key 写入 Host 内存 `WorkspaceState.offered`；不写 sidecar/Registry、不要求 owner 队列；`offered` 按 workspace 共享，`reset`/`disposeAll`/Host 重启清空，不持久化。
- [x] **宿主：sidecar snooze**。`WorktreeSidecarDocument`/`WorktreeSidecarView` 增加可选 `snooze`（`mode: 'until-new-worktree' | 'until'`、`until?`、`keys`、`at`，`version` 仍 1）；`emptySidecar` 默认无该字段；`readSidecar` 把损坏值视为 `undefined`，不拒绝整份 sidecar；`worktreeSidecar` 增加 `{ op: 'snooze', snooze }`，只在 owner 串行队列内写并通过 `requireWorktreeMutation`/`worktreeGate`；`ignore`/`reconcile`/映射增删保留 `snooze`；`reset` 同时清空 `ignored` 与 `snooze`，无可清内容时不制造 revision。
- [x] **宿主：resolve snooze 与生效规则**。`worktreePromptResolve` 接受 `action: 'snooze'` + `snooze`；复验 session/mode/switch/queue/eligibility，失效 id 进 `skipped`；有效 id 由宿主从 `promptIds` 派生 discovery keys 写 sidecar，不写 Registry、不加入 `prompted`；`7d`/`30d` 用宿主时钟换算 `until`，`until` 到期前抑制 keys，`until-new-worktree` 只抑制记录中的 keys。
- [x] **契约**。双端 schema 同步（strict、拒绝多余字段）；`worktreePromptSeen` 端点、`worktreePrompt` 的 `fresh`、`worktreePromptResolve` 的 `action`/`snooze` 互斥校验齐全；`promptIds` 必填、去重、上限 64；`WorktreeResolveAnswerView` 形状复用。
- [x] **客户端：Toast/Dialog 拆分**。overlay 不再常驻长轮询：session 从空/其他变为有效 session 时调用一次 `worktreePrompt(sessionId, { fresh: true })`，有候选显示非模态 Toast（无 backdrop、无 focus trap、不阻塞页面与输入框），否则不渲染；Toast 操作「查看」「稍后（下拉：直到出现新 worktree（默认）/ 7 天 / 30 天）」「×」，默认常驻不自动消失；A/B 共用中性文案。
- [x] **客户端：Dialog 与调用**。只有「查看」打开现有 Dialog；打开时 `worktreePrompt(sessionId)`（不带 `fresh`）取全量可见候选，再启动 `worktreePromptWait(sessionId, { seenViewRevision })`，关闭立即 abort；Toast 显示后与 Dialog 打开后各调用一次 `seen`；「稍后」调用 `client.snooze`，「添加所选」继续 `resolve('add')`；X/ESC 关闭不写状态。
- [x] **面板/样式/词典 + journey**。面板 `list` 与 `worktrees.notify()` 不触发自动检查；`src/client/styles.ts` 增加 Toast 样式（`mrfw-` 前缀、`var(--dsw-*)` token）；词典补齐 Toast 文案与稍后选项；`smoke:journey` 的 web leg 走真实 HTTP 通道的 fresh → 查看 → 确认序列；`tests/worktrees-git.e2e.ts` 若直接调用 wait 可保持。
- [x] **单测与客户端测试**。宿主覆盖 `fresh`/`seen`/snooze 语义、sidecar 往返与降级、owner 拒绝路径；客户端覆盖触发收敛、Toast/Dialog、下拉、StrictMode 幂等；契约测试覆盖 strict/互斥/枚举/去重/上限。
- [x] **文档**。ADR-0039 第二十次修订与本计划小节；[路线账本](../active/2026-09-12-multi-root-workspace.md#进度总账)由维护者在验证后写入实际证据。

**验收**（按 ADR-0039 第二十次修订的契约与失败方向；证据只记路线账本）：

- 客户端：
  - session 激活 + `fresh` 有候选 → 显示 Toast，且不渲染 `role="dialog"`；无候选 → 不显示任何内容；
  - 点「查看」→ Dialog 含全部可见候选（A+B）；
  - 默认「稍后」→ `snooze.mode` 为 `until-new-worktree`，Toast 关闭，Registry 无写入；
  - 「7 天」「30 天」→ `until` 分别为宿主当前时间 + 7/30 天；
  - 永久「不再提醒」→ `action: 'dismiss'` + `dontRemind`；
  - 切换 session → Toast/Dialog 关闭且 wait abort；
  - 关闭设置开关 → Toast/Dialog 隐藏；重新开启 → 不自动弹；
  - 面板 `list` / `notify()` → 不自动弹；
  - Dialog 关闭 → wait abort；
  - `fresh` 空候选 → 无 Toast；
  - 只有 A 时 Toast 文案仍为中性；
  - StrictMode 重复挂载 → 只检查一次/幂等。
- 宿主：
  - `fresh` 只返回未被 `offered`/当前 snooze 覆盖的候选，且查询无副作用（无 sidecar/Registry 写入、无 `offered`/`prompted`/queue 变化）；
  - `seen` 后同一候选 `fresh` 为空，`reset` 后恢复；
  - `until-new-worktree`：同 key 抑制；新 key 可见，旧 key 仍抑制；
  - `until`：到期前抑制，到期后可见（宿主时钟）；
  - snooze 不写 Registry、不加入 `prompted`，候选仍留在队列、可在 Dialog 中显式添加；
  - 开关关闭/inactive/lost 时 snooze 拒绝且 sidecar 无写入；
  - sidecar 往返保留 `ignored`/mappings，坏 `snooze` 视为 `undefined`；
  - `prompt()` 不复活 `lost`；
  - 多 Host/follower 经 owner 串行写入，view 带回 `snooze`。
- 契约：
  - `fresh` 为可选布尔且 strict；
  - `snooze` 与 `action` 的互斥/必填、mode 枚举；
  - `seen` 的 `promptIds` 必填、去重、上限 64；
  - 双端 schema 同步，宿主与客户端同时拒绝多余字段。
- E2E/冒烟：
  - `tests/worktrees-git.e2e.ts` 若直接调用 `worktreePromptWait` 可保持；
  - `smoke:journey` 的 web leg 必须走真实 HTTP 通道：先 `fresh` prompt 判定有候选（等价于 Toast 显示），再「查看」等价的 `prompt`（不带 `fresh`）拿全量列表，再确认；
  - 现有 add/resolve/cleanup/owner 测试保持通过。

### 第二十次修订返工（2026-11-14，Code Review，完成）

> PR #55 的代码审查复现了十三处实现偏离（ADR §20.3–§20.10；Devin 六条 + Codex 七条 P2），均先写失败回归再修复；授权语义不变。

- **snooze-only reset 落盘**：`worktreeSidecar` 的 `reset` 空态判断改为针对原始文档（同时看 `ignored` 与 `snooze`）；只清 snooze 也写一次 revision，无内容时仍不制造 revision。回归：sidecar snooze-only reset 持久化（重开 owner 读回为空、二次 reset 不制造 revision）+ 服务层 reset 后重启不恢复。
- **fresh 保持只读**：新增 `WorkspaceState.passive`；`prompt(fresh)` 的首次激活与重新 inventory 走被动路径——只读 `resolveRepo` 与 sidecar、只重建候选队列，不安装 watcher、不调度 owner 侧 reconcile、不写 sidecar；首个显式请求（Dialog 的 `prompt()`/`wait`/面板 list/reset）提升为持久发现一次并恢复映射核对，settings/registry 触发的 reconcile 沿用当前姿态。回归：fresh 作为第二个 Host 的首个调用时 `watching === false`、sidecar 操作只有 `read`、文件逐字不变、后台不发现新 worktree；打开 Dialog 后 watcher 与 reconcile 才出现。
- **定时 snooze 到期释放提醒**：新增 `expireSnooze`（到期时丢弃内存记录并把 keys 从 `offered` 释放）与 `liveSnooze`（sidecar 读回过期记录不再激活）；sidecar 不主动清理过期记录。回归：`seen` → 7d snooze → 到期后同一 Host 重新提示。
- **sidecar 读回先观察到到期也要释放**：`liveSnooze` 丢弃过期记录时会丢失释放；改为统一 `adoptSnooze`，任何 sidecar 读回（`loadSidecar`/`reconcileSidecar`/snooze 写入回读）观察到到期都先释放 `offered` 中的 keys 再丢弃记录，`expireSnooze` 复用同一 helper。回归：`seen` → 7d snooze → 到期 → 先 `describeRoots`（面板打开等价）→ 下一次 fresh 仍重新提示。
- **每条过期记录只释放一次**：sidecar 有意保留过期记录，重复读取不能重复释放，否则会删掉操作者在重新提示之后通过 `seen` 做出的新认领、导致下一次激活重复提示。Workspace 内存按记录指纹（mode/until/at/keys）记录已处理记录，只有首次观察释放；`expireSnooze`/`adoptSnooze` 共用。回归：到期 → fresh 重新提示 → `seen` → `describeRoots` → 下一次 fresh 保持安静。
- **多个待处理提醒共存**：sidecar 从单条 `snooze` 改为 `snoozes` 列表；新记录只取代 keys 有交集的旧记录，不相交的记录保留各自期限（上限 32，读取兼容旧单对象）。回归：A(7d) → B(7d) → A 到期只回 A → `seen(A)` → B 到期只回 B。
- **fresh 前重读共享提醒投影**：`fresh: true` 在过滤前从 owner 只读重读 `snoozes`，否则已激活的 Host 会忽略另一 Host 刚写入的延迟（snooze 不改变 Registry roots、不触发变更刷新）。回归：先以空投影激活 → owner 写入延迟 → 下一次 fresh 为空。
- **部分重叠按 key 拆分**：新选择只点名旧记录的一部分候选时，旧记录未被点名的 keys 拆成一条残余记录并保留原期限/原 `at`，完全覆盖的记录才删除。回归：sidecar 部分重叠（until 与 until-new-worktree）保留残余记录；服务层 A(7d)/B(2d) 部分重叠后 B 原期限前安静、到期只回 B、A 的新期限到期再回 A。
- **残余记录不重复释放**：到期去重从「整条记录指纹（含 keys）」改为「延迟身份（mode/until/at，不含 keys）+ 单个发现 key」。共享记录 `{A,B}` 到期释放后，另一 Host 只对 A 再选「稍后」，owner 拆出的 `{B}` 残余记录身份不变；原先指纹不同会再次释放 B、冲掉重新提示后的 `seen` 认领。回归：到期 → fresh 重提示 → `seen` → 另一 Host 只对 A 再选 7d → `describeRoots` 读回残余 → 下一次 fresh 保持安静。
- **淘汰记录释放认领**：`observeSnoozes` 统一处理自动过滤、任何 sidecar 读回与本地合并；到期记录释放 keys，本 Host 记得但新投影不再覆盖其 key 的记录（`MAX_SNOOZE_RECORDS = 32` 淘汰）同样释放，避免被淘汰的定时选择退化为永久抑制。回归：`seen` → 7d → 另一 Host 写入 32 条不相交延迟触发淘汰 → 下一次 fresh 重新提示。
- **客户端处理 `skipped`**：`applyLater`/`snoozeNotice` 不再丢弃成功响应里的 `skipped` 直接关闭。Toast 只为未处理行保留提示（刷新后的 id，select 以 id 集合为 key 重新武装），Dialog 保留刷新后的行 + 行错误 + skipped 计数（与「添加所选」一致）；transport/authority 失败仍静默关闭、不自动重试。回归：client 的 Toast(7d) 与 Dialog(7d/permanent) 三条。
- **定时选择的完成路径不拥有后续会话的提示**：`snoozeNotice` 的失败路径只检查组件是否挂载，成功路径只比较 session id。A 会话选择 7 天后切到 B，A 的请求拒绝会清掉 B 刚显示、其候选已被 `seen` 认领的 Toast；A→B→A 往返后旧请求成功也会清掉第二次激活的提示。改为调用时捕获 `workEpoch`，两个完成路径都要求 `mounted && epoch === workEpoch.current`（成功路径仍校验 session）才修改 Toast，生命周期已变的完成一律丢弃；同生命周期内失败仍静默关闭、不重试。回归：`tests/client-worktree.spec.tsx` 的跨会话失败与同会话往返成功两条。
- **请求批次与完整响应**：`seen`（Toast/Dialog）与 snooze/resolve 原先一次发送整个可见集合；仓库超过 64 个 worktree 时请求会被 `promptIds` 的 64 上限拒绝。更早的失败点是响应 schema 同样 `max(64)`：真实客户端整份拒绝回答，Toast 完全不出现（自动检查静默失败）、Dialog 关闭——因此 review 描述的直接请求溢出在旧代码中先被响应解析挡住，但根因相同且影响更糟。改为响应可携带完整可见列表（请求上限仍 64），`WorktreeClient` 的 `seen`/`resolve`/`snooze` 按 64 个 id 顺序分批并合并答复（`seen` 求和；`resolved`/`skipped` 合并；`viewRevision`/`prompts` 取最后一批）。回归：合同 65 项响应、客户端 65/100/130 个 id 的分批、真实客户端 + 65 候选的 Toast 与两批 `seen`。
- **广泛审查：异步完成的归属**：`confirmAdd`/`applyLater` 也捕获 `workEpoch`，A→B→A 后旧 Dialog 的 resolve 完成不再关闭或改写第二次激活的 Dialog；`openDialog` 与 Toast 的「×」立即递增 epoch，打开 Dialog 或显式关闭 Toast 之后的旧 snooze 完成不能再改 UI。回归：Dialog 的 add/later 往返两条，以及关闭 Toast 后部分 refused 的 snooze 不重新出现。
- **验证**：worktree + client + locale + authority-native + `worktree-client` 专项 15 文件 **204 通过 / 15 环境 skip / 0 失败**；`lint`、双端 `typecheck`、`build`、`docs:check`、`compat:check`、`pack:check` 通过；全量与冒烟结果记[路线账本](../active/2026-09-12-multi-root-workspace.md#第二十次修订验收2026-11-14)。

### P11 发现提示位置与形态（2026-11-15）

> 决策见 [ADR-0039 第二十一次修订](../../decisions/ADR-0039-worktree-aware-root-suggestions.md#第二十一次修订2026-11-15)；需求分析与初始方案见 [toast placement 报告](./2026-11-15-workspace-toast-placement.md)，最终实施与退出验收见 [实施计划](./2026-11-15-workspace-toast-implementation.md)。只改客户端呈现，不改宿主/RPC/授权。

- [x] **落点解析器**：新增 `src/client/notice-placement.ts`（纯解析器 + 只读 DOM 探针：`data-phase`/`data-composer-card`/`data-conversation-content`/Header 测量/官方 Toast 检测）；Hero 与对话页都水平居中（对话页 Header 下方、内容列中心），缺失降级 Hero 顶部居中，禁止回右下角。
- [x] **提示 UI**：`WorktreePrompt` 提示区改用 primitives `Button`/`Menu` 与既有 compat 图标；删除「×」，「稍后提醒」改为带同色细框的拆分按钮（左半默认档位、右半 Menu 三档）；Workspace Folders 面板「重试」右侧新增手动入口，经 `worktree-prompt-bus` 让 overlay 打开同一 Dialog；`openDialog`/session/设置关闭仍递增 `workEpoch`。
- [x] **样式**：删除右下角 `.mrfw-toast*`；新增随主题自适应的 `.mrfw-notice*`（R16、`border: 0` + `elevation-panel`、两行/粗指针 32px、reduced motion）。
- [x] **词典**：新增 `toastLabel`/`toastActions`；`toastLater` 改为「稍后提醒」；删除 `toastClose`。
- [x] **测试**：placement 13 条；client-worktree 52 条（含 a11y、拆分按钮、面板手动入口、紧凑、跨会话）；client-panel 72 条；styles 40 条；locale parity 与 bundle 保持。
- [x] **面板布局**：Worktree 手动入口加入添加行后保持单行；手动路径输入改为可收缩字段（`flex: 1 1 120px`，未来移除），窄视口才回退换行。
- [x] **文档**：ADR 第二十一次修订、README 双语、本 P11、计划索引。
- [ ] **退出验收**：质量门与 GUI 证据、Draft PR（见实施计划 §6）。

### P12 Worktree 确认 Dialog 视觉、权限选择器与分支展示（2026-11-15）

> 决策见 [ADR-0039 第二十二次修订](../../decisions/ADR-0039-worktree-aware-root-suggestions.md#第二十二次修订2026-11-15)；需求/契约缺口与实施方案见 [Dialog 重构报告](./2026-11-15-worktree-dialog-redesign.md)。本轮**扩展了宿主契约与授权语义**：worktree 根不再固定 `inherit`。

- [x] **布局**：确认 Dialog 加宽到 `min(860px, 100%)`；候选改为连续列表（行间 0.5px 分隔线、无卡片描边/圆角），行内 checkbox + 文件夹名 + 路径 + 分支 chip + 权限选择器；删除「勾选要登记为 inherit 附加根…」说明行；单候选共用同一行结构。
- [x] **权限选择器**：每行 `inherit` / `read-only` / `read-write`，默认 `inherit`；`WorktreeRequest.accesses` 只在 `add` 上接受，host 校验 id/重复/取值并传 `addNew`；Registry `addNew` 使用 `grantFields` 写入对应 grant（只读用 `readOnlyRecordedPath`，关闭 Skills）；README/ADR 同步授权语义变化。
- [x] **分支展示**：从候选 admin HEAD 解析 `ref: refs/heads/<name>`；主 checkout 使用 common HEAD（主 checkout 自己的分支）；detached HEAD 缺省；仅展示，不参与授权/owner 复验。
- [x] **footer**：snooze 原生 select 换为 primitives `Button` + `Menu`；「暂不处理 / 添加所选」改用 primitives `Button`。
- [x] **测试**：client-worktree 54 条、styles 43 条、worktrees-contract 16 条、worktrees-discovery 28 条、worktrees-common 14 条；新增 access 只属于 add、未知/重复 id、非法值、branch 可选/非空、A/B 分支、detached 缺省、只读 grant 与 effective access、逐行选择后请求携带 accesses。
- [x] **文档**：ADR 第二十二次修订、README 双语、本 P11/P12、Dialog 重构报告、计划索引。
- [ ] **退出验收**：CI matrix、GUI 视觉复核（宽度、连续列表、选择器、分支 chip、footer 下拉）。

## Dependencies

- ADR-0039 已 Accepted；P8 以 B 的 P1–P7 完成为前置条件。
- 现有 Registry、Connection RPC、panel controller、Registry owner 串行队列、scope/authority 语义。
- 平台能力：POSIX `openat`/`O_NOFOLLOW`/`O_NONBLOCK`；Windows 文件 ID/reparse point；Node 版本按现有支持矩阵。
- 无新增可选 peer；无上游改动。

## Validation

- 所有新行为先有失败用例，再有实现；回归覆盖 ADR-0039 §2.5 的每个布局。
- “无 Git 子进程”用进程 spy / 环境断言；`core.fsmonitor` 脚本不得执行。
- “外部文件没有被读取/脚本没有执行”用外部 marker/监控断言，不只无提示。
- RPC 判别联合由宿主和客户端 schema 双重校验；错误 shape 必须拒绝。
- 映射 prune 的 authority 空快照用例必须端到端覆盖。
- 文档门禁：`pnpm docs:check`。

## Risks

- **保守 inactive 的可用性代价**：submodule/祖先链/Unicode/未知格式一律 inactive；宁可漏提示，不可错误授权。面板应能解释 inactive 原因，但不泄露路径外内容。
- **解析器复杂度**：v2/v3/v4 index、config、HEAD、祖先链、Unicode 等价；解析失败必须 fail closed。
- **Windows 文件身份**：无稳定 file ID 时不能回退到路径比较；不发提示或 stale。
- **停止与恢复**：unactivated/lost 都停止后台；显式恢复才重新检测。测试推进时钟断言零重查、零 sidecar 写入；所有 RPC 分支拒绝 retry 字段。
- **Registry 空快照**：`available=false` 的空列表不是“没有根”；prune 只消费同一次 owner `RegistrySnapshotView`，`available=true` 的空快照才删除映射。
- **写入口时序**：P3 的确认在生产 RPC 中默认禁用；P4 将 `addNew` 与完整 owner 复验同阶段接通，P5 只做竞态/平台验收。
- **默认 pool**：没有特殊排除；主仓库 primary 由包含规则过滤，pool worktree primary 的兄弟仍可成为 B 候选。
- **不自动删除**：missing 根占额度是刻意取舍；面板必须显眼。

## Documentation Impact

- ADR-0039（状态与修订）。
- 需求 §7.16–§7.18（含 `forget-workspace` 延期）。
- 本计划与 `docs/plans/README.md` active 列表。
- 路线账本（唯一进度/发布状态来源）。
- 发布时 `CHANGELOG.md` / `CHANGELOG.en.md`。
- 如实现引入新的 RPC/客户端契约，更新面板/协议文档与 ADR-0005 的关联说明。

## Completion Criteria

- P1–P7 的 B 行为验收后完成 P8–P10；默认 pool 的兄弟 checkout 与 A 的 common 分别验收。
- A 经显式确认后，默认 pool 和外部 linked checkout 的受限 `git add` / `git commit` 均通过；主 checkout 源码和无关路径仍拒写。
- 插件详情开关与 Skills 同卡、实验性默认关闭、实时生效并可持久化；关闭后客户端停止 worktree 请求，当前 Host 停止后台任务。已登记根仍可在普通根管理中操作。
- P3 确认门禁生效；P4 才接通写路径，等待 owner 替换候选时 Registry 无写入。
- 所有 inactive 布局在入队和 owner 提交都拒绝；owner 不接受过期提示。
- 无 Git 子进程、无外部 index/object/config 读取；Web 宿主/客户端 RPC schema 一致，headless 只验证组合启动与现有命令/Registry 正常（不新增浏览器入口）。
- 删除只在面板显式触发；缺失根占额度；不入自动清理；`forget-workspace` 明确延期。
- sidecar 所有写入由唯一 owner 排序；prune 取队列内当前完整快照；两种空语义、并发交错、重启/接管跨 epoch 核对通过。
- 平台矩阵与文档门禁通过；发布状态只记录在路线账本与 CHANGELOG。
