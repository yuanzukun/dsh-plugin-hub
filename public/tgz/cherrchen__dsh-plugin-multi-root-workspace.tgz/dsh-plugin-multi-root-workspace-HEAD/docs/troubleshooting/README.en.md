# Troubleshooting

中文：[README.md](./README.md)

## What Belongs Here

Verified problem-solving experience with recurring value. Each entry typically includes:

- Symptoms;
- Root cause;
- Diagnostics;
- Verified solution.

## What Does Not Belong Here

Do not log every one-off error.

Only issues that are expected to recur and are costly to diagnose are worth recording.

## Current State

- [Client bundle missing from the web boot graph: bundle patch mounts only subpath rows](./client-bundle-not-in-boot-graph.md) (Chinese) — root cause and fix for the silently absent footer slot registration.
- [Panel reports "cannot connect to the dsh main process" (HTTP 405)](./panel-channel-http-405.md) (Chinese) — root cause and fix for the channel registration silently swallowed by cordis service resolution.
- [The SSH section only shows "The operation failed."](./ssh-panel-operation-failed.md) (Chinese) — a Schemastery volatile field leaked as the `custodyMode` object, so the whole remote view failed to parse.
- [Root registry owned by another DSH process](./registry-owned-by-another-process.md) (Chinese) — fail-closed lease when two processes share `$DSH_HOME`, and how the waiter takes over.
- [The installed DSH release is not on the support matrix](./unsupported-dsh-release.md) (Chinese) — the `unsupported` / `mixed` / `incomplete` verdicts, why the providers then never start, and the manual process for promoting a new release.
- [The install stops at build approval](./install-stops-at-build-approval.md) (Chinese) — why a GitHub source install (or an npm / tarball install of `0.1.20` or earlier) fails on a build script, and how to answer the one `allowBuilds` decision it leaves behind; npm / tarball installs no longer need it in `0.1.21`.
- [DSH Desktop install leaves the bundle unregistered](./desktop-install-missing-bundle.md) (Chinese) — the Plugins page writes only `dependencies`, hot enabling collides with the old providers, and the bundled CLI's `remove` + `add` recovery.
- [Files-tab root switcher degraded](./files-switcher-degraded.md) (Chinese) — the upstream `data-files-*` hooks are not slot contract; how to inspect the three degradation states when the switcher falls back to a plain menu.
- [Launcher reports profile-core-mixed / profile-core-copy](./profile-core-mixed.md) (Chinese) — why older releases shipped shared upstream packages as `dependencies` and installed a second singleton into the profile, and how to fix it.

- [Socket / CVE dependency alerts](./dependency-security-alerts.md) (Chinese) — direct dependency patches, upstream exact pins, and the limits of Host-level overrides.

## Naming Convention

Use lowercase kebab-case, for example:

```text
<symptom-or-topic>.md
```
