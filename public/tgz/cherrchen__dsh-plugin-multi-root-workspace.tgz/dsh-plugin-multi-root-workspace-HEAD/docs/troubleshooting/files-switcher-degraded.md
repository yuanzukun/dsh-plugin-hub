# Files 页签根选择器退化：上游 `data-*` 钩子失效

## 症状

四种可分别出现的退化（每条对应一类失效的钩子）：

- **路径标签出现两次/位置错乱**：选择器以普通菜单钮的身份停在 actions 区原位，上游路径标签恢复显示，与选择器自带的 `PathLabel`（`.mrfw-switcherPath`）并存——`[data-files-root]:has(.mrfw-rootSwitcher) [data-files-path]:not([data-files-entry])` 或 `.mrfw-rootSwitcher { order: -1 }` 失效（上游把扁平 flex header 换了结构，或属性挪了位置）。
- **选中附加根但原生树仍在**：菜单状态变了、触发钮显示根名，树区却仍是主根原生树——`[data-root-kind="additional"]` 条件下的 `display:none` 规则失效，`closest('[data-files-root]')` 找不到祖先（portal 目标缺席时组件**主动不渲染**复刻树），或复刻树的 primitives 探针整面缺席（`filesTreeSurfaceSupported()` 为假 → adapter 不建，与 open-in-app 同型降级）。
- **树接管了但滚动/展开记忆跨接管不保留**：树区换成复刻树、展开/懒加载/失败行均正常，只是切主根再切回后滚动位置与展开态没记住——`data-dockkit-content` 钩子（dockkit tabHost 的 tab id 属性）改名或挪位，store bucket 键退回生成 id。功能层面无碍，属目检级退化。
- **原生 reload 还留着 / 附加根态出现两个刷新钮**：与上一条同源的 `:has()` 失效——接管态下原生 reload 应隐藏、由 header 内的 `.mrfw-switcherReload` 顶替（点击调复刻 face 的 `refresh(tabId)` 原地重拉，不清屏）；两者同时可见即规则失配。
- **附加根态出现两个「在应用中打开」钮 / 原生钮点回主根**：`data-open-target="directory"` 钩子（`ui-open-in-app` 分离按钮的锚点属性）改名或挪位——隐藏规则失配时原生钮在附加根态重新露出，点击仍打开**主根**（P9 修复前的旧 bug 回归）；复刻钮自身带 `.mrfw-openSplit`、被 `:not()` 保住，仍开选中根。若连复刻钮都不见了，先查 adapter 是否因 `*Regular` 图标族缺席而未建（0.1.x 像素名运行时的预期降级），再查 `GET open-in-app/apps` 是否 404/空数组（上游「无应用即无按钮」同型行为）。
- **复刻钮与窗口右缘间距像素级偏差（已修，留作诊断参考）**：根因查明——上游 `ui-renderer` 给每个槽位渲染点包 `<div data-slot="<key>" style="display:contents">`，`.header` 的子项是该包装而非 occupant 的 Menu 锚 span；旧的 `> * > *` 隐藏选择器命中包装自身，样式表 `display:none` 敌不过内联 `display:contents` 而惰性，原生 `.split` 只被内层兜底藏住、空的 Menu 锚 span 仍以零宽 flex 项多占一个 header gap。现第一选择器锚定 `[data-slot="sidebar.right.tab.files.actions"] > *:has(...)` 隐藏 occupant 项本身。**若该 `data-slot` 锚点改名或挪位，同一症状回归**：DevTools 中在 `.mrfw-rootSwitcher` 之前的同槽位查找一个无内容的 Menu 锚 span——仍占位即确认（原生 `.split` 被藏而锚壳残留），再对照该版本 `scoped-slots.tsx` 的包装实现找新锚。

所有症状共享一个性质：**功能不坏**。选择器菜单依然列出主根与附加根、能打开管理对话框；变的是视觉接管退回了原生布局。

## 根本原因

`data-files-root` / `data-files-path` / `data-files-reload` / `data-files-body` 落在上游 `FilesBody` 的 flex 项本体上，`data-open-target="directory"` 落在 `ui-open-in-app` occupant 的锚点上，`data-slot="sidebar.right.tab.files.actions"` 落在渲染器给槽位渲染点包的 `display:contents` 包装上（occupant 项级隐藏经它定位），`data-dockkit-content` 落在 dockkit 的 tabHost 上（复刻树 store bucket 键经它取得）——它们都是上游渲染器的实现细节，**不是 `files.actions` 槽位契约的一部分**。上游改 DOM（换布局、改属性名、给 flex 项包 wrapper）时，插件的 `:has()` 规则和 `closest()` 查找同时失去目标——这正是设计选择的失效路径：静默退化而非破碎头部（[ADR-0015](../decisions/ADR-0015-files-tab-plugin-owned-browsing.md)）。

## 诊断方法

1. 打开 Files 页签，DevTools 检查 pane：四个 `data-files-*` 属性是否仍在对应元素上（`data-files-root` 在 pane、`data-files-path`/`data-files-reload` 在 header 的 flex 项、`data-files-body` 在树区），`data-open-target="directory"` 是否仍在 open-in-app 分离按钮的锚点上，`data-slot="sidebar.right.tab.files.actions"` 包装是否仍包着 actions 区全部 occupant（其内联 `display:contents` 是故意的——不能对它 `display:none`，要隐藏的是包装内的 occupant 项），dockkit tabHost 上是否仍有 `data-dockkit-content`（复刻树的 store bucket 键——缺席只损滚动/展开记忆）。`.header` / `.body` 的 class 是 CSS-module hash，不能锚。注意 `data-files-path` 有双重含义：**每个树行也携带它**（值是该行绝对路径），所以命中表头标签的选择器必须是 `[data-files-path]:not([data-files-entry])`——如果症状是「主根树区整片空白」，先查这条限定符还在不在。
2. 确认 `.mrfw-rootSwitcher` 确实渲染进了 actions 区（footer 面板存在 ⇒ client bundle 在跑；选择器不在则说明 slot 注册本身出了问题，另查 `files.actions` 槽位是否还声明）。
3. 选中一个附加根后看 `.mrfw-rootSwitcher` 是否带上 `data-root-kind="additional"`：带了但原生树仍可见 ⇒ `:has()` 规则失配；不带 ⇒ 组件状态问题而非钩子问题。
4. 复刻钮缺失的排查顺序：`.mrfw-openSplit` 元素是否存在（不存在 ⇒ adapter 未建，查 `*Regular` 图标与 `open-in-app/apps` 路由）；存在但被隐藏 ⇒ 检查 `:not(.mrfw-openSplit)` 限定符是否还在隐藏规则里。
5. 复刻树缺失的排查顺序：接管态下 DevTools 找 `.mrfw-ftBody`（不存在 ⇒ adapter 未建，查 `filesTreeSurfaceSupported()` 的 primitives 探针——folder 图标/`FileTypeIcon`/`classifyFileType`）；存在但行为异常 ⇒ 对照 `src/client/files-tree/FORK.md` 查上游该版本的 `ui-sidebar-files` 源码漂移；滚动/展开记忆丢失 ⇒ 查 `data-dockkit-content`。
6. **附加根树卡在「正在读取…」不复位（已修，留作诊断参考）**：根因查明——`remote.workspaceFiles` 是 cordis 的嵌套服务，在 context 代理路径上受 inject 守卫（未声明的 fiber 访问会抛 `cannot get property "remote.workspaceFiles" without inject`），而本版 cordis 的 inject 条目全是 required（声明会把整行 gate 在可选服务上）。`lazyFilesRemote` 一度走 `ctx.get('remote').workspaceFiles` 代理路径，抛出的 rejection 无人接住（verbatim `load` 的 `.then` 无 `.catch`），静默钉死 loading。现改为 `ctx.get('remote')` / `ctx.get('remote.workspaceFiles')`——免 inject 的 store 直查；且一切查找失败都折叠成 settled `gateway/internal` 失败行（P11 回归测试锁住）。所以接管态下：出现 `error.unavailable` 失败行 ⇒ 读行的真实错误信息，即 remote 侧实际失败原因；**永远停在 loading** ⇒ `changes` 流开了但一帧未出（传输层问题——此时主根原生树通常也同样不工作），查 DevTools 的 WebSocket 与 host 日志，而非本插件。
7. **点击附加根文件报 `workspace-file/outside-workspace`**：这是 `src/workspace-files.ts` 的读面边界按设计拒绝——该路径词法上仍落在一个**已登记但未授权**的根下（被移除、消失或 `redirected`；上游 `stat`/`read`/`readBytes`/`readAll`/`readRelated` 与文件级 `changes` 本就不做 workspace 围限，所以边界由本插件补）；或者该操作是 `list`/`changes`/`search`，其解析后的**所选目录或搜索根**落在这样的根下（例如主根被替换/重定向进一个在册根）。处置：在 Workspace Folders 面板重新挂载/修正该根（redirected 需重新授权）；若报错路径从未属于任何附加根、且操作根也不在在册根下，则是 `routeWorkspacePath` 的真 bug，按 routing 层排查。

## 已验证的解决方案

1. 对照该上游版本的 `FilesBody` 与 `ui-open-in-app` 源码找出新钩子：属性改名就改选择器，flex 项被包了一层就调整 `:has()` 的组合路径，`closest()` 的目标同理（`src/client/RootSwitcher.tsx` 与 `src/client/styles.ts` 是唯一两处消费点）。
2. 保持 `:has()` 守卫结构：任何命名上游元素的规则都必须以本插件元素在场为前提，失效路径才会继续是"退化"而非"误伤"。
3. 复刻控件自身的漂移（上游 `ui-open-in-app` / `ui-sidebar-files` 改了组件结构/路由/注入面）按 `src/client/open-in-app/FORK.md` 与 `src/client/files-tree/FORK.md` 的同步步骤重拷对照——许可差异分别是 css specifier 的 `.ts` 后缀与外壳函数的根源改写。
4. 若上游彻底移除了可用钩子（例如 flex 项不再携带任何稳定标识），接受退回槽内菜单形态——选择器仍可用，但树区接管不再可行；此时重新评估方案（上游 seam 出现的可能性见 ADR-0015 备选节），不要为了视觉接管去锚 hash class。

## Files 页被第三方整页接管：根切换器完全不出现（Issue #47）

### 症状

- Files 页签仍能打开，但页面是另一个插件提供的文件页；本插件的根切换器、路径标签接管与附加根树全部不出现，页面上没有任何说明。
- 其余入口正常：footer 的「工作区目录」、`/workspace-folders`、附加根权限与指令注入均可用。

### 根本原因

- 第三方插件以 `priority: 'extension'` 注册 `kind: 'files'`，宿主内置 Files 页（实现 id `@deepseek-ai/dsh-client-ui-sidebar-files`）被降为 shadowed，`FilesBody` 不再渲染。
- 根切换器注册在 `FilesBody` 声明的 `sidebar.right.tab.files.actions` 槽上；槽声明在启动时随 `FilesBody` 注册的 `children` 建立，接管时仍是 declared，`slots.inject` 照常触发——但 seat 不挂载，组件永远不渲染。它与本文其余症状属于不同失效模式：不是 selector 失配，而是宿主页面整体缺席。

### 诊断方法

1. 读 `ctx.sidebarRightTabs.get('files')`：返回定义的 `id` 不是 `@deepseek-ai/dsh-client-ui-sidebar-files`（或 `priority !== 'builtin'`）即确认被接管；extension 注销后 `get('files')` 回到内置定义，因此可用它确认恢复。
2. 不要用 `slots.spec('sidebar.right.tab.files.actions')` 判断：接管时它仍然存在，这正是本失效模式的静默之处。

### 行为与处置

- 插件在检测到接管时弹一次官方 info 级瞬时 Toast（词条 `filesPage.notice`），说明根切换器暂不可用、可继续从侧栏管理；接管解除后自动重新武装，再次接管会再提示。
- 根管理仍可从 footer 的「工作区目录」与 `/workspace-folders` 完成；要让 Files 页切换器恢复，需要在第三方插件侧关闭对 `files` kind 的接管（如 better-sidebar 的对应开关）或停用它。

升版验收时的目检清单（三态：无附加根原生观感 / 附加根选中接管 / 切回主根还原）记录在 `.agent/note/dsh-compat-contract.md` 第 12 节。
