# 故障排查（Troubleshooting）

English: [README.en.md](./README.en.md)

## 这里存放什么

已经验证、具有重复价值的问题处理经验，每条记录通常包括：

- Symptoms（症状）；
- Root Cause（根本原因）；
- Diagnostics（诊断方法）；
- Verified Solution（已验证的解决方案）。

## 不应该存放什么

不要把所有一次性报错都记录进来。

只有预期会复发、且排查成本较高的问题才值得记录。

## 当前状态

- [client bundle 不进 web 启动图：bundle patch 只挂子路径行](./client-bundle-not-in-boot-graph.md) — footer 槽位注册静默失效的根因与修复。
- [面板报"无法连接到 dsh 主进程"（HTTP 405）](./panel-channel-http-405.md) — 通道注册被 cordis 服务解析静默吞掉的根因与修复。
- [面板 SSH 区块只显示“操作失败。”](./ssh-panel-operation-failed.md) — Schemastery volatile 字段泄漏成 `custodyMode` 对象，导致整个远端视图解析失败。
- [根目录登记被另一个 DSH 进程占用](./registry-owned-by-another-process.md) — 两进程共用 `$DSH_HOME` 时的 fail-closed lease 与接管方式。
- [DSH 版本不在支持矩阵上](./unsupported-dsh-release.md) — `unsupported` / `mixed` / `incomplete` 三种判定、provider 不启动的原因，以及人工提升新版本的流程。
- [安装停在构建授权](./install-stops-at-build-approval.md) — GitHub 源码安装（或 `0.1.20` 及更早版本的 npm / tarball 安装）因构建脚本被 pnpm 拦下而失败，以及那一次 `allowBuilds` 表态怎么回；`0.1.21` 起 npm / tarball 不再需要。
- [DSH Desktop 安装后缺少 bundle 登记](./desktop-install-missing-bundle.md) — 插件页只写 `dependencies`、热启用撞上旧 provider 的重复注册，以及用 Desktop 自带 CLI 做 `remove` + `add` 的恢复路径。
- [Files 页签根选择器退化](./files-switcher-degraded.md) — 上游 `data-files-*` 钩子不是槽位契约；选择器退回菜单形态时的三态目检与修法。
- [启动器报 profile-core-mixed / profile-core-copy](./profile-core-mixed.md) — 旧版把共享上游包发成 `dependencies` 导致 profile 里出现第二份单例的根因与修法。

- [Socket / CVE 依赖告警](./dependency-security-alerts.md) — 直接依赖补丁、上游精确 pin 与 Host 根项目 override 的修复边界。

## 推荐命名

使用小写中划线命名，例如：

```text
<symptom-or-topic>.md
```
