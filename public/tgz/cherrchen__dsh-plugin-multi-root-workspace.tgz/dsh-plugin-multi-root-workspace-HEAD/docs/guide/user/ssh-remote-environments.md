# 个人 SSH 远端环境

English: [ssh-remote-environments.en.md](./ssh-remote-environments.en.md)

个人 SSH 是默认关闭的实验性功能。开启后，Agent 可通过 `remote_copy` 和 `remote_bash` 操作已登记的远端目录。本机 DSH Host 持有 SSH 凭据，同一操作系统账号下的进程可能访问这些凭据。

> [!WARNING]
> **平台与版本前提**：
> - 仅支持 **Linux** 和 **macOS** 发起端，远端目标主机也仅支持 **Linux** 和 **macOS**（Windows 发起端和 Windows 目标目前均延后或不支持）。
> - 需要 DSH 运行时在 SSH 支持矩阵内（当前为 `0.2.2-rc.1` ～ `0.2.3-alpha.2`），且宿主安装有对应的四个官方 SSH 可选包（`@deepseek-ai/dsh-ssh`、`dsh-fs-ssh`、`dsh-subprocess-ssh`、`dsh-sandbox-ssh`）。

## 远端访问边界

1. 模型通过显式调用 `remote_copy` 和 `remote_bash` 访问远端目录。
2. 每次调用前都经过 Registry 的两段准入检查（操作前准备 + 真正执行/发布前二次复核）。
3. 会话处于 `read-only` 模式时，自动拒绝远端写入、命令执行以及向远端复制。
4. 远端目录必须先在本工作区**登记（Register）**后才能被模型使用；文件发布采用临时暂存 + 校验 + 原子硬链接（不覆盖已有文件）。

## 开启个人 SSH

1. 打开侧栏 **插件（Plugins）** → 找到 **Multi-root Workspace** 详情页。
2. 在设置卡中找到 **SSH 远端环境**（带有黄色「实验性」标签），打开开关。
3. 阅读弹出的风险确认框，勾选确认后点击 **确认开启**（取消则保持关闭）。
4. 打开管理界面的两种方式：
   - **插件详情页**：开启后设置卡顶部会出现「**SSH 远端 → 管理**」按钮（此入口可在无活动会话时管理全局连接）。
   - **工作区面板**：点击侧栏底部的 **工作区目录（Folders）**（或新会话页工作区行右侧入口）→ 在「远端工作目录」区点击 **管理 SSH 远端…**。

## 安装当前 Profile 的 SSH 依赖

安装 Multi-root Workspace 后即可使用本地工作区功能。确认开启个人 SSH 后，若当前 Profile 的依赖未就绪，界面会自动打开「安装 SSH 依赖」对话框。关闭后可从「管理 SSH 远端」再次查看四包状态。依赖已就绪时可直接配置连接。

依赖修正有两种入口，任选其一；两者都只写入当前 Profile，不要求逐包安装或手动填写版本。

1. **Desktop 一键安装（启动器明确支持时）**：对话框显示 **安装并重启**。点击后由 Desktop 启动器校验当前 Host、Profile 和版本，停止 Host 并等待退出，复用下方命令行的同一套安装核心，然后以原配置重启 `desktop` Profile。按钮会依次显示停止、安装、重启和检测状态；Web、旧版 Desktop 或启动器未提供该能力时不显示此按钮。
2. **复制安装命令（所有宿主可用）**：点击 **复制安装命令**，完全退出相应的 DSH Host，在运行 DSH 的机器上执行。命令使用界面上显示的 Host **完全同版**的 CLI、准确的 Profile 与 DSH Home，并通过一次 `dsh plugin --profile <name> add --save-exact` 对齐四个包。Web 使用运行 Web Host 的机器；Desktop 在完全退出应用后执行 `desktop` Profile 的命令。重复执行是安全的：四包已经对齐时直接报告「已就绪」，不会重复写入。
3. 使用同一 Profile 重新启动 Host，再打开「管理 SSH 远端」。如仍显示依赖提示，点击 **重新检测依赖**，根据各包状态定位。检测只读取状态，当前进程发现磁盘已修复时仍提示重启。

界面的三种结果要区分：

- **安装完成**：本次命令或启动器操作成功写入了四个包；
- **待重启**：磁盘上的包已对齐，但当前进程仍在使用启动时加载的旧依赖；
- **依赖已就绪**：当前 Host 已能解析四个同版包，可以配置连接。

更换 DSH 版本后，用新 Host 提供的命令重新对齐四个包。版本与部署边界见 [SSH 技术参考](../../reference/ssh-remote-environments.md#host-profile-依赖)。

## 设置连接与目录绑定

Profile 就绪后，连接和绑定在 GUI 中配置，无需 root 权限、独立系统账户或部署清单文件。

### 第 1 步：准备凭据（二选一）

- **方式 A：使用本机 `~/.ssh/config` 主机别名**
  - 确保本机 `~/.ssh/config` 中已配置好 `Host <别名>`（包含 `HostName`、`User`、`IdentityFile` 等），且目标主机钥已在你的 `~/.ssh/known_hosts` 中存在**唯一**匹配条目。
- **方式 B：使用插件托管凭据**
  1. 在「SSH 设置」左侧选择 **SSH Key**（或在添加连接时点「管理凭据」）。
  2. 点击 **添加凭据**，在弹出的对话框中先选择一种方式，再填写对应字段：
     - **生成密钥**：输入名称，插件生成 ed25519 密钥对。创建后点击凭据卡片右侧的 **复制公钥** 图标，将其追加到远端主机的 `~/.ssh/authorized_keys`。
     - **导入私钥**：输入名称并粘贴私钥（加密私钥需同时提供口令，导入时会自动剥离口令并以 0600 权限保存在本机凭据根），同样确保公钥已授权给远端主机。
     - **保存密码**：输入名称和密码。保存后会在后续步骤中用密码登录一次，自动在远端安装专用访问密钥（`authorized_keys`），之后连接全部改为密钥认证。

### 第 2 步：添加连接

1. 在左侧选择 **远端连接**，点击列表底部的 **添加连接**。
2. **第 1 步（连接与主机密钥）**：
   - 凭据来源选择「本机 SSH 主机别名」或「托管凭据」，填写显示名、远端平台（Linux / macOS）及 `用户名@主机名:端口`（使用别名时端口和目标会在扫描时从 `ssh -G` 自动解析）。
   - 点击 **扫描并测试连接**，在同一步内选择一条扫描到的主机密钥指纹后点击 **确认并保存**；点 **上一步** 可回到表单。
3. **第 2 步（连接设置）**：
   - **密码凭据**：先点击 **安装访问密钥**，使用刚才保存的密码登录一次并在远端写入访问密钥。
   - **托管凭据链接**：如果界面提示「尚未链接」，点击 **链接到 ~/.ssh/config**。插件会先备份原 `~/.ssh/config`，再在其首行写入一条 `Include` 指令以使托管别名生效（未链接前无法建立连接）。`~/.ssh/config` 是符号链接时，改动落在链接目标上、符号链接保持不变。
   - **安装 Helper**（如需命令执行或对象级核验，推荐安装）：可先点 **检测 Node**，再点击 **安装 Helper**（插件会通过 SSH 在远端 `~/.dsh-helper/<版本>` 安装与宿主完全同版的 `@deepseek-ai/dsh-ssh`，并写入一个每次启动都会校验整个依赖文件集的入口脚本；要求远端 Node.js ≥ 24.9.0、可运行的 npm 和可写安装目录，Node 路径须为规范化绝对路径）。如果远端 PATH 选中了旧版本，可在连接卡片的安装表单内指定新版 Node 的绝对路径。
   - 勾选 **允许命令执行**（需 Helper 已安装）和/或 **允许文件传输**，点击 **完成**。

### 第 3 步：绑定目录到工作区并登记

连接是插件全局的，目录绑定则是按当前工作区保存的。**此步必须在有活动会话的工作区面板中完成**：

1. 打开侧栏 **工作区目录（Folders）**，在「远端工作目录」区点击 **管理远端 Root 绑定**。
2. 点击 **添加绑定**，在引导界面完成两步：
   - **绑定目录**：选择已创建的 SSH 连接；输入远端绝对路径（例如 `/srv/work/app`），或点击 **浏览…** 通过 SFTP 挑选远端目录；勾选 **允许动作**：`读取`、`写入`、`执行`（`执行` 需连接已安装 Helper 并开启执行）；如需在本地与远端间使用 `remote_copy`，在 **本地传输** 中勾选对应本地根（`primary` 或可用附加根）的 **允许拷贝文件到远端** / **允许拷贝文件到本地**。点击 **下一步** 保存绑定。
   - **确认登记**：核对环境、路径、动作与传输摘要，点击 **登记到工作区**。登记时会实际连接远端校验目录存在性及真实路径（不可为符号链接重定向），完成后显示「已登记」，模型即可使用该目录。

> [!TIP]
> 删除不再需要的连接前，必须先解除它的全部工作区绑定（在绑定对话框中，或在远端行「…」菜单点击 **移除**——个人模式下移除会同时撤销登记并解除绑定），否则会报 `environment-in-use`。修改绑定权限或更新部署后状态变为「待重新登记（`withheld`）」时，再次从 `…` 菜单点击 **登记** 即可恢复。要修改某个已绑定目录的路径、动作或本地传输，从该行「…」菜单点击 **编辑** 即可直接打开「本项目绑定」对话框的对应编辑表单。

## 使用远端工具

模型只能通过 `remote_copy` 与 `remote_bash` 访问已登记的远端目录。两个复制端点写法相同，只有**省略** `environmentId` 才表示本机：本地主根写作 `local:primary`（省略 `environmentId`，`rootId` 为 `primary`），附加根用登记的 `aliasId`（如 `docs`）；远端端点必须显式给出 `environmentId`，`rootId` 用绑定对话框里登记的标识。`relativePath` 是根内单个普通文件的规范化相对路径，不能以 `/` 开头，也不能含 `.` 或 `..` 段。

一次上传和一次下载的参数：

```json
{"from":{"rootId":"primary","relativePath":"dist/app.tar"},
 "to":{"environmentId":"build","rootId":"app","relativePath":"in/app.tar"}}
```

```json
{"from":{"environmentId":"build","rootId":"app","relativePath":"out/app.tar"},
 "to":{"rootId":"primary","relativePath":"dist/app.tar"}}
```

复制只处理单个普通文件，且目标必须不存在：目标以 0600 创建，不保留源文件的 mtime 与可执行位，从不覆盖。需要搬运多个文件时，先在已授权的根内打成归档（例如 `tar -cf dist/app.tar -C dist .`），再把归档当单文件复制，最后在目标端自行解包。

`remote_bash` 默认给 stdout 和 stderr 各 64 KiB 预览预算，JSON 转义也计入。可传 `maxOutputBytes` 调高预览，受连接部署上限约束。结果里的 `totalBytes` 是原始字节总数，`droppedBytes` 是未进入预览的原始字节数，无法精确确定的计数为 `null`。大输出可以重定向到已授权远端根内，例如通过 `remote_bash` 执行 `command > /srv/work/build.log 2>&1`，再分段查看（如 `sed -n '1,200p' …` 或 `tail -n 200 …`）或复制该文件。

失败结果包含稳定的 `code`、简短的 `message` 和 `hint`。端点类错误可列出与对端匹配的候选，包含可用的本地根，每个方向最多 6 个。`unknown`、`admitted-may-start` 或 `scope: "unconfirmed"` 都需要先确认远端状态再决定是否重试。`unknown` 的 `reconcileId` 可用于核对本次操作。

## 停用 SSH 与故障排查

在插件设置中关闭 **SSH 远端环境**，即可卸载远端工具并关闭远端控制面。沿用旧凭据代理实验的 profile 时，参见[旧配置迁移说明](../../reference/ssh-remote-environments.md#停用的旧配置)。

### 常见错误与排查

- **`owner-without-remote-protocol` / 面板提示另一实例持有存储**：另一个未开启 SSH 远端功能的 DSH 实例（例如未启用该插件的 Desktop 端）正持有 `$DSH_HOME` 的存储锁。退出那个实例后再刷新。
- **`endpoint-unverifiable`** — 确认 Host 使用受支持的 DSH 版本，并已安装四个版本匹配的 SSH 可选包。
- **`ssh-config-not-linked`**（个人模式）：存在托管凭据的环境但尚未把插件生成的配置链接进 `~/.ssh/config`，在「远端连接」中点击 **链接到 ~/.ssh/config**。
- **`access-key-reconcile-required`**：安装或回滚的结果无法确认。使用错误消息中的密钥编号，在原 SSH 主机上核对 `authorized_keys` 后再重试。
- **Helper 安装失败**：连接页显示失败阶段、修复建议和可展开的技术详情。如果显示远端可能已改动，先检查服务器上的安装目录和 npm 日志。如果显示远端已校验但 Host 登记未确认，先重新读取连接状态，再决定是否重新安装。参见 [SSH 故障排查](../../troubleshooting/ssh-panel-operation-failed.md#helper-安装诊断)。
- **`helper-outdated`**：桌面端记录的 Helper 没有 BoringSSL 传输入口，在对应连接卡片上重新 **安装 Helper**；已登记 Root 保持有效，无需重新登记。
- **`unknown` 返回与 `reconcileId`**：远端命令启动后连接断开或文件发布应答丢失时，工具不会自动重试（避免重复执行或覆盖文件），请凭返回的 `reconcileId` 到远端对账后再决定后续操作。
- **`invalid-arguments`**：工具在 Registry 准入与任何 SSH/SFTP I/O 之前拒绝了结构非法的参数，`message` 会指出具体字段（例如 `"to.relativePath" is required`）；按 `hint` 修正后重试。

关于协议字段、全部错误码与架构细节，参见技术参考 [SSH 远端环境参考](../../reference/ssh-remote-environments.md) 与 [多执行环境控制面参考](../../reference/multi-environment-control-plane.md)。
