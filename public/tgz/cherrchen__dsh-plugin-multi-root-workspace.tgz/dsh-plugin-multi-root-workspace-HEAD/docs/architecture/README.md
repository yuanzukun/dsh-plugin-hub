# 架构文档（Architecture）

English: [README.en.md](./README.en.md)

## 这里存放什么

- Current Architecture（当前架构）；
- Target Architecture（目标架构）；
- 子系统设计（subsystem design）；
- 组件边界（component boundaries）；
- 数据流（data flow）；
- 接口（interfaces）。

## 不应该存放什么

- 需求（放入 `../requirements/`）；
- 决策记录（放入 `../decisions/`）；
- 实施计划（放入 `../plans/`）。

## 重要要求

不得将 Proposal 或 Target Architecture 描述成当前已经实现的系统事实。

描述未来设计的文档必须明确标注其状态。

## 当前状态

架构文档区分**已实现部分（Current）**与**尚未实现部分（Target / Proposed）**，边界在文档头部与各节内明确标注：

- [multi-root-workspace.md](./multi-root-workspace.md) — Multi-root Workspace 的不改上游设计：provider 替换 + 子类化。
  - 已实现（M1/M2/M3/M4）：§3 组合结构、§4 scope 解析、§5 两个 provider、§6 拓扑快照与 parity 矩阵、§7 Root 注册表 / 命令 / 面板（主根由 session cwd 推导，ADR-0008） / 跨进程 Authority Lease。
  - 仍为 Target：§8 的长期形态（上游 seam）与 §9 附录为备忘。
- [registry-authority-service.md](./registry-authority-service.md) — 多 Host 共享 Registry：有序准入、内核认证 IPC、全消费者接缝、保守故障处理与接管（已实现；平台证据见路线账本）。
- [file-browsing-providers.md](./file-browsing-providers.md) — Files 标签页的本地/SSH 远端浏览 Provider：组件依赖、选择/身份/权威/传输分层、能力矩阵、元数据租约（非文件监视）与有界安全姿态（已实现 P1–P8；远端预览扩展见下一条，已随 `v0.1.25-beta.2` 发版）。
- [remote-file-preview.md](./remote-file-preview.md) — 远端文件预览：插件自有 Viewer、`filePreview:'stable-path'` 授权、不透明资源身份、有界 SFTP 读取与二进制 RPC、租约和渲染边界（随 `v0.1.25-beta.2` 发版）。

## 推荐命名

使用小写中划线命名，例如：

```text
<subsystem-or-topic>.md
```
