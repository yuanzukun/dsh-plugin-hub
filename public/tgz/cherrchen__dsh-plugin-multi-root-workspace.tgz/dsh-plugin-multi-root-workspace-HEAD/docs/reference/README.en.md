# Reference

中文：[README.md](./README.md)

## What Belongs Here

Stable reference material, such as:

- Configuration reference;
- API reference;
- Schemas;
- Protocols;
- File formats.

## What Does Not Belong Here

- Proposals or target designs;
- Brainstorming and scratch discussions;
- Development plans;
- Unsettled ideas.

Only established, relatively stable factual reference content belongs here.

## Current State

- [multi-root-skills-seams.md](./multi-root-skills-seams.md) (Chinese) — Verified Session, native-ID, effective-cwd, file parsing, Settings and Web seams for additional-root Skills, with a reproducible architecture probe.
- [auto-review-compatibility.md](./auto-review-compatibility.md) (Chinese) — Review context, source roles, tool scheduling order, and external integration seams in Auto Review `0.2.1-rc.2`.
- [multi-root-workspace-research.md](./multi-root-workspace-research.md) — Snapshot research of the upstream repository's Workspace / Sandbox / plugin system (master `c291e7961a`; §8 covers the supplementary research on the no-upstream-changes mechanism).

## Naming Convention

Use lowercase kebab-case, for example:

```text
<topic>.md
```

- [dsh-0.2.1-migration.md](./dsh-0.2.1-migration.md) — Interface and security review of three upstream tags, with Worktree constraints.
- [dsh-0.2.2-migration.md](./dsh-0.2.2-migration.md) — Interface and security review of DSH 0.2.1-rc.4, 0.2.1-rc.5, and the 0.2.2 releases (sessionProjections injection, the tool-executor split, additionalWritableRoots, and the Node 24 requirement, plus rc.2's SandboxPreparationError, registerWritableRoot, workspaceFiles.search, and the dsh-error shared base).
