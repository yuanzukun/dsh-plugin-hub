# Reference

中文：[README.md](./README.md)

## What Belongs Here

Stable reference material, such as:

- Configuration reference;
- API reference;
- Schemas;
- Protocols;
- File formats.

## What Does Not Belong Here

- Proposals or target designs;
- Brainstorming and scratch discussions;
- Development plans;
- Unsettled ideas.

Only established, relatively stable factual reference content belongs here.

## Current State

- [multi-environment-baseline.md](./multi-environment-baseline.md) (Chinese) — Reproducible G0 evidence collection, public tool seams, SSH compatibility check integration points, and the pending managed-SFTP primitive inventory.
- [multi-environment-control-plane.md](./multi-environment-control-plane.md) (Chinese) — G1a remote control plane: deployment manifest format, the remote grant domain, the `remote-1` IPC entry, Host-side admission and denial codes.
- [multi-root-skills-seams.md](./multi-root-skills-seams.md) (Chinese) — Verified Session, native-ID, effective-cwd, file parsing, Settings and Web seams for additional-root Skills, with a reproducible architecture probe.
- [auto-review-compatibility.md](./auto-review-compatibility.md) (Chinese) — Review context, source roles, tool scheduling order, and external integration seams in Auto Review `0.2.1-rc.2`.
- [auto-review-0.2.2-migration.md](./auto-review-0.2.2-migration.md) (Chinese) — Release topology, source-generation deltas, consumed seam changes, and the multi-baseline grouping for Auto Review after `0.2.1-rc.2` through `0.2.2-rc.5`.
- [multi-root-workspace-research.md](./multi-root-workspace-research.md) — Snapshot research of the upstream repository's Workspace / Sandbox / plugin system (master `c291e7961a`; §8 covers the supplementary research on the no-upstream-changes mechanism).

## Naming Convention

Use lowercase kebab-case, for example:

```text
<topic>.md
```

- [dsh-0.2.1-migration.md](./dsh-0.2.1-migration.md) — Interface and security review of three upstream tags, with Worktree constraints.
- [dsh-0.2.2-migration.md](./dsh-0.2.2-migration.md) — Interface and security review of DSH 0.2.1-rc.4, 0.2.1-rc.5, and the 0.2.2 releases (sessionProjections injection, the tool-executor split, additionalWritableRoots, and the Node 24 requirement, rc.2's SandboxPreparationError, registerWritableRoot, workspaceFiles.search, and the dsh-error shared base, and rc.3's New-session HOC slot, the workspace.picker Factory, and the optional experimental dsh-deepseek-chat-import bundle).
- [dsh-0.2.3-migration.md](./dsh-0.2.3-migration.md) — Interface and security review of DSH `0.2.3-alpha.2` (`alpha.1` source comparison retained; that release cannot launch and is not in the contract) (the security impact of the Session workspace root, the `workspace-root/change` event, the two cordis root APIs, client-fork deltas, Node 24.22.3, and the Auto Review joint-set expansion).
