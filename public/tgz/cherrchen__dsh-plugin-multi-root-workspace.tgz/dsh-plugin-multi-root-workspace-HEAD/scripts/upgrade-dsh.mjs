/**
 * upgrade-dsh — repoint this repository's DSH pin at one upstream release.
 *
 * The upgrade lane's job is to answer a single question: would this plugin
 * still be correct if the harness were release X? Answering it requires the
 * whole repository to be pinned at X — `devDependencies`, the release-age
 * allowances, and the lockfile — because the fence and the kernel-sandbox
 * dialects are verified against the copy that is actually installed, not
 * against a range.
 *
 * This script performs exactly that repointing and nothing else. It does NOT
 * touch `SUPPORTED_DSH_RELEASES` or `peerDependencies`: a green upgrade lane is
 * evidence that a release COULD be supported, and promoting it is a human act
 * performed afterwards (ADR-0009). That separation is the whole point — a
 * scheduled job that widened the support matrix on its own would reintroduce the
 * over-promise this contract was written to remove.
 *
 * ```bash
 * node scripts/upgrade-dsh.mjs 0.1.6-alpha.1   # pin an exact release
 * node scripts/upgrade-dsh.mjs --latest-prerelease   # pin the newest published
 * node scripts/upgrade-dsh.mjs --print-latest-prerelease   # just report it
 * node scripts/upgrade-dsh.mjs --print-installed   # report the resolved tree
 *
 * pnpm install --no-frozen-lockfile --config.minimumReleaseAge=0
 * DSH_MULTI_ROOT_COMPAT=warn pnpm verify:all
 * ```
 *
 * Reverting is `git checkout -- package.json pnpm-workspace.yaml pnpm-lock.yaml`.
 * That is safe in CI, which always runs on a clean checkout, and it is the ONLY
 * way back this script offers on purpose — a backup file would be a second
 * source of truth for "what the pin was".
 *
 * Locally it is a loaded gun: it reverts those three files to HEAD *entirely*,
 * so any UNCOMMITTED edit to them — a new script, a widened peer range — is
 * destroyed along with the pin. Commit or stash before running an upgrade probe
 * over dirty manifests.
 *
 * @module scripts/upgrade-dsh
 */

import { readFileSync, writeFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { npmOutput } from './lib/npm-cli.mjs'
import { cordisPin, ecosystemPin } from './lib/cordis-pin.mjs'
import { AUTO_REVIEW_BASELINES, AUTO_REVIEW_CONTRACT_DATA } from './lib/auto-review-development.mjs'

const REPO_ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const MANIFEST = join(REPO_ROOT, 'package.json')
const WORKSPACE = join(REPO_ROOT, 'pnpm-workspace.yaml')

/** Read one `export const NAME = [...]` string array from a contract source. */
function contractArray(source, name) {
  const match = new RegExp(String.raw`export const ${name} = \[([^\]]*)\]`, 'u').exec(source)
  if (match === null) throw new Error(`${name} is not declared as an array literal`)
  return [...match[1].matchAll(/'([^']+)'/gu)].map(token => token[1])
}

/** Whether a dependency name belongs to the upstream harness. */
function isDshPackage(name) {
  return name === '@deepseek-ai/dsh' || name.startsWith('@deepseek-ai/dsh-')
}

/**
 * The newest published pre-release of `@deepseek-ai/dsh`.
 *
 * The npm `versions` array is in publish order, so the last pre-release entry
 * is the newest one — no semver comparison of pre-release identifiers needed,
 * and none wanted: publish order is what "newest" means for an upgrade probe.
 * @returns the version string.
 */
function latestPrerelease() {
  const raw = npmOutput(['view', '@deepseek-ai/dsh', 'versions', '--json'])
  const versions = JSON.parse(raw)
  const prereleases = versions.filter(version => version.includes('-'))
  const newest = prereleases.at(-1)
  if (newest === undefined) throw new Error('@deepseek-ai/dsh has published no pre-release')
  return newest
}

/**
 * The cordis version the pinned `dsh` package declares.
 *
 * `dsh` 0.1.7 depends on cordis `^4.0.3`. Leaving the repository's 4.0.2 pin
 * in the same tree installs both, and pnpm then gives `dsh-agent-loop` and
 * `dsh-tools` different physical copies. The tool scheduler is a module-local
 * `Symbol`, so the loop looks the symbol up on a runtime built by the other
 * copy and every tool call dies with `reading 'prepare'` of `undefined`.
 * The declared range is a single caret or tilde of one exact version; that
 * exact version is the pin. A wider range is refused rather than guessed.
 * @param dshVersion - the exact `@deepseek-ai/dsh` release being pinned.
 * @returns the exact cordis version to pin.
 */
function cordisRequiredBy(dshVersion) {
  const raw = npmOutput(['view', `@deepseek-ai/dsh@${dshVersion}`, 'dependencies.@deepseek-ai/cordis', '--json'])
  const range = JSON.parse(raw)
  return cordisPin(range)
}

/** Whether a dependency name belongs to the cordis ecosystem a DSH release declares beside its own packages. */
function isEcosystemPackage(name) {
  return name === '@deepseek-ai/schemastery' || name === '@deepseek-ai/cosmokit' || name === '@deepseek-ai/node-addon-system'
    || name.startsWith('@deepseek-ai/cordis-plugin-')
}

/**
 * Pin the cordis ecosystem the target release declares, so a repointed tree
 * cannot mix it with the newer one the committed lockfile carries.
 *
 * The lockfile prefers the versions of the last committed dev pin. Without
 * these pins an older release resolves its `~1.0.6` plugin-loader to a
 * `1.0.7-alpha.1` entry already in the lockfile, and the loader/cordis pair no
 * longer matches what that release shipped with (Settings volatile writes then
 * miss the live config). The ranges come from the release's own manifests:
 * `dsh` and `dsh-app-boot` (which declares the plugin trio as peers), the
 * pinned cordis, and `dsh-sandbox-local` (which carries the schemastery /
 * node-addon-system pairs this plugin shares with the host). Declared
 * prereleases pin their exact base; stable ranges take the latest stable patch
 * in their declared minor line. A newer vendor minor can satisfy semver while
 * changing the Cordis API (loader 1.1.0 requires Cordis 4.1.0).
 *
 * `koffi` is not repointed here: it arrives through `dsh-fs-local` rather than
 * a package this function queries. `compat:check` requires
 * `devDependencies.koffi` to equal the copy `dsh-fs-local` resolves, so a
 * release that changes the host's koffi pin fails the gate until a human
 * updates the development pin.
 * @param version - the exact `@deepseek-ai/dsh` release being pinned.
 * @param cordisVersion - the exact cordis version {@link cordisRequiredBy} returned.
 * @returns package name to exact version, sorted by name.
 */
function ecosystemPins(version, cordisVersion) {
  const ranges = new Map()
  for (const spec of [
    `@deepseek-ai/dsh@${version}`, `@deepseek-ai/dsh-app-boot@${version}`,
    `@deepseek-ai/cordis@${cordisVersion}`, `@deepseek-ai/dsh-sandbox-local@${version}`,
  ]) {
    for (const field of ['dependencies', 'peerDependencies']) {
      const raw = npmOutput(['view', spec, field, '--json']).trim()
      const declared = raw === '' ? {} : JSON.parse(raw)
      for (const [name, range] of Object.entries(declared)) if (isEcosystemPackage(name)) ranges.set(name, range)
    }
  }
  const pins = {}
  for (const [name, range] of [...ranges].sort(([a], [b]) => a.localeCompare(b))) {
    const raw = npmOutput(['view', `${name}@${range}`, 'version', '--json']).trim()
    const admitted = [].concat(JSON.parse(raw))
    if (admitted.length === 0) throw new Error(`[upgrade] no published ${name} satisfies ${range}`)
    pins[name] = ecosystemPin(range, admitted)
  }
  return pins
}

/**
 * Repoint every DSH devDependency, cordis to the version that release requires,
 * and each ecosystem devDependency to that release's own resolved pin — a
 * schemastery left at the newer line would install a private copy beside the
 * repointed host's own one (issue #30's failure shape, in the probe lane).
 * @param version - the release to pin.
 * @param cordisVersion - the exact cordis version {@link cordisRequiredBy} returned.
 * @param pins - the resolved ecosystem pins {@link ecosystemPins} returned.
 * @returns the packages that were changed.
 */
function repointManifest(version, cordisVersion, pins) {
  const source = readFileSync(MANIFEST, 'utf8')
  const manifest = JSON.parse(source)
  const changed = []
  // The optional Auto Review fork keeps one development-package set per frozen
  // source baseline. A lane installs only its own baseline's set: several of
  // these packages do not exist in older releases, and one manifest cannot hold
  // two exact versions of the same package.
  const forkBaseline = AUTO_REVIEW_CONTRACT_DATA.baselineOf(version)
  const activePackages = forkBaseline === undefined ? [] : AUTO_REVIEW_BASELINES[forkBaseline].developmentPackages
  for (const baseline of Object.values(AUTO_REVIEW_BASELINES)) {
    for (const name of baseline.developmentPackages) {
      if (activePackages.includes(name)) manifest.devDependencies[name] = version
      else delete manifest.devDependencies[name]
    }
  }
  const sshSource = readFileSync(join(REPO_ROOT, 'src/compat/dsh-version.ts'), 'utf8')
  const sshSupported = contractArray(sshSource, 'SUPPORTED_SSH_RELEASES')
  const sshPeers = contractArray(sshSource, 'SSH_PEER_PACKAGES')
  const sshNames = new Set(sshPeers)
  for (const name of sshPeers) {
    if (sshSupported.includes(version)) manifest.devDependencies[name] = version
    else delete manifest.devDependencies[name]
  }
  for (const name of Object.keys(manifest.devDependencies ?? {})) {
    if (!isDshPackage(name) || sshNames.has(name)) continue
    if (manifest.devDependencies[name] === version) continue
    changed.push(`${name}: ${manifest.devDependencies[name]} → ${version}`)
    manifest.devDependencies[name] = version
  }
  const cordisName = '@deepseek-ai/cordis'
  if (manifest.devDependencies?.[cordisName] !== cordisVersion) {
    changed.push(`${cordisName}: ${manifest.devDependencies?.[cordisName]} → ${cordisVersion}`)
    manifest.devDependencies[cordisName] = cordisVersion
  }
  for (const name of Object.keys(manifest.devDependencies ?? {})) {
    if (!isEcosystemPackage(name)) continue
    const pin = pins[name]
    if (pin === undefined) throw new Error(`[upgrade] ${name} is a devDependency but ${version} declares no range for it`)
    if (manifest.devDependencies[name] === pin) continue
    changed.push(`${name}: ${manifest.devDependencies[name]} → ${pin}`)
    manifest.devDependencies[name] = pin
  }
  // Re-serialize with the trailing newline the repository's manifest carries, so
  // the only diff is the versions themselves.
  writeFileSync(MANIFEST, `${JSON.stringify(manifest, null, 2)}\n`)
  return changed
}

/**
 * Repoint the release-age allowances.
 *
 * Every upstream release is published minutes before this repository uses it, so
 * `minimumReleaseAge` would otherwise reject it outright (ADR-0002). Only the
 * entries already listed are rewritten; the upgrade lane additionally installs
 * with `--config.minimumReleaseAge=0`, because a candidate release drags in every
 * transitive `@deepseek-ai/*` package and enumerating those here would turn a
 * throwaway probe into a 200-line diff.
 *
 * Editing the YAML as TEXT is deliberate: a parse-and-dump round trip would drop
 * the comments that explain why each allowance exists.
 * @param version - the release to pin.
 * @param cordisVersion - the exact cordis version to write into the cordis allowance.
 * @param pins - the resolved ecosystem pins {@link ecosystemPins} returned.
 * @returns the number of rewritten entries.
 */
function repointWorkspace(version, cordisVersion, pins) {
  const source = readFileSync(WORKSPACE, 'utf8')
  // The SSH packages exist only from their own floor: below it their
  // allowances (and therefore their probe overrides) would name releases
  // npm never published, so those lines are dropped for this probe.
  const sshSource = readFileSync(join(REPO_ROOT, 'src/compat/dsh-version.ts'), 'utf8')
  const sshNames = new Set(contractArray(sshSource, 'SSH_PEER_PACKAGES'))
  const sshSupported = contractArray(sshSource, 'SUPPORTED_SSH_RELEASES').includes(version)
  let count = 0
  let updated = source.replace(/^(\s*- '(@deepseek-ai\/dsh(?:-[\w-]+)?))@[^']+'\n/gmu, (line, prefix, name) => {
    if (sshNames.has(name) && !sshSupported) return ''
    count += 1
    return `${prefix}@${version}'\n`
  })
  const cordisLine = /^(\s*- '@deepseek-ai\/cordis@)[^']+'$/mu
  if (!cordisLine.test(updated)) {
    throw new Error('[upgrade] pnpm-workspace.yaml has no @deepseek-ai/cordis release-age entry to repoint')
  }
  updated = updated.replace(cordisLine, `$1${cordisVersion}'`)
  count += 1
  // Upstream prerelease dependency ranges may admit a later release in the
  // same minor line. A direct dev pin alone does not make the runtime carried
  // by `dsh` coherent: its resolution hook can override that direct copy with
  // a transitive one. Pin the known DSH tree for this probe as well. Names
  // come from the existing exact release-age entries, not a second inventory.
  // These overrides are workspace-only and restored with the probe's files.
  const marker = '# BEGIN DSH probe overrides'
  updated = updated.replace(/\n# BEGIN DSH probe overrides\n[\s\S]*?# END DSH probe overrides\n?/u, '\n')
  if (/^overrides:/mu.test(updated)) {
    throw new Error('[upgrade] workspace has custom overrides; merge probe pins explicitly instead of replacing them')
  }
  const names = [...new Set([...updated.matchAll(/^\s*- '(@deepseek-ai\/dsh(?:-[\w-]+)?)@[^']+'$/gmu)]
    .map(match => match[1]))].sort()
  updated = updated.trimEnd() + `\n\n${marker}\noverrides:\n`
    + `  '@deepseek-ai/cordis': '${cordisVersion}'\n`
    + Object.entries(pins).map(([name, pin]) => `  '${name}': '${pin}'\n`).join('')
    + names.map(name => `  '${name}': '${version}'\n`).join('')
    + '# END DSH probe overrides\n'
  writeFileSync(WORKSPACE, updated)
  return count
}

/**
 * Report what each declared DSH package actually RESOLVED to.
 *
 * The declared pin and the resolved tree are different facts, and only the
 * second one is what the tests ran against — so it is the one an upgrade run
 * must print into its log before drawing any conclusion.
 */
function printInstalled() {
  const manifest = JSON.parse(readFileSync(MANIFEST, 'utf8'))
  const declared = { ...manifest.dependencies, ...manifest.devDependencies, ...manifest.peerDependencies }
  const require = createRequire(import.meta.url)
  const resolved = {}
  for (const name of Object.keys(declared).filter(isDshPackage).sort()) {
    try {
      resolved[name] = require(`${name}/package.json`).version
    } catch {
      resolved[name] = null
    }
  }
  console.log(JSON.stringify(resolved, null, 2))
}

const [argument] = process.argv.slice(2)
if (argument === undefined) {
  console.error('usage: node scripts/upgrade-dsh.mjs <version> | --latest-prerelease | --print-latest-prerelease | --print-installed')
  process.exit(2)
}

if (argument === '--print-latest-prerelease') {
  console.log(latestPrerelease())
  process.exit(0)
}

if (argument === '--print-installed') {
  printInstalled()
  process.exit(0)
}

const target = argument === '--latest-prerelease' ? latestPrerelease() : argument
if (!/^\d+\.\d+\.\d+(?:-[\w.]+)?$/u.test(target)) {
  console.error(`[upgrade] "${target}" is not an exact version`)
  process.exit(2)
}

const cordisVersion = cordisRequiredBy(target)
const pins = ecosystemPins(target, cordisVersion)
const allowances = repointWorkspace(target, cordisVersion, pins)
const changed = repointManifest(target, cordisVersion, pins)
console.log(`[upgrade] cordis pin: ${cordisVersion}`)
console.log(`[upgrade] pinned ${target}`)
console.log(`[upgrade] devDependencies rewritten: ${changed.length}`)
for (const entry of changed) console.log(`           ${entry}`)
console.log(`[upgrade] release-age allowances rewritten: ${allowances}`)
console.log('[upgrade] next: pnpm install --no-frozen-lockfile --config.minimumReleaseAge=0')
console.log('[upgrade] then: DSH_MULTI_ROOT_COMPAT=warn pnpm verify:all')
console.log('[upgrade] revert: git checkout -- package.json pnpm-workspace.yaml pnpm-lock.yaml')
console.log('[upgrade]         ^ reverts those files to HEAD entirely — commit or stash first')
