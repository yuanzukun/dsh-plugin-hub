/**
 * smoke:compose — the composition acceptance test.
 *
 * It drives the real plugin install chain (`dsh plugin --profile <name> add`),
 * dumps two composed profiles with `dsh --dump-config` — one with the plugin
 * and one without — and asserts that the ONLY difference is the two disabled
 * provider rows plus the three inserted rows.
 *
 * This is the milestone's structural gate. The upstream patch semantics warn
 * and skip on an id that no longer matches, so "the replacement silently did
 * nothing" is a real failure mode; comparing a baseline dump against the patched
 * one is what turns it into a hard failure here instead of a surprise at runtime.
 *
 * The run is always isolated: it uses a scratch `$DSH_HOME` and refuses to touch
 * the operator's real one.
 *
 * @module scripts/smoke-compose
 */

import { existsSync, mkdirSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { parse } from 'yaml'
import { createChecker } from './lib/check.mjs'
import { assertIsolatedHome, captureDsh, ensureProfileCopyImport, installPluginProfile, REPO_ROOT, resolveScratchHome, runDsh } from './lib/dsh-runtime.mjs'

const PLUGIN_NAME = '@dsh-electron/dsh-plugin-multi-root-workspace'
const REPLACED = new Map([
  ['fs-sandbox', '@deepseek-ai/dsh-fs-sandbox'],
  ['sandbox', '@deepseek-ai/dsh-sandbox-local'],
])
const INSERTED = [
  // The compatibility gate comes first: every widened-authority row below
  // injects `multiRootCompat`, so a harness whose DSH release is not on the
  // allowlist mounts none of them.
  'multi-root-compat',
  // The two providers stay mounted on a refused gate by design — their
  // widening is scope-driven and the gated registry can never populate the
  // scope, so they degenerate to the upstream providers instead of taking
  // ctx.fs/ctx.sandbox (and with them ctx.shell + permissionPresets) down.
  'multi-root-fs',
  'multi-root-sandbox',
  // The provider-conflict gate: asserts the mounted ctx.fs/ctx.sandbox carry
  // this bundle's brand, so a foreign provider leaves every widened-authority
  // row below unmounted rather than granting on it.
  'multi-root-providers',
  'multi-root-scope',
  'multi-root-ops-compatibility',
  'multi-root-registry',
  'multi-root-skills',
  // Worktree-aware suggestions: additive, compat-gated, and inert until a
  // confirmation; it never writes a root on its own (ADR-0039).
  'multi-root-worktrees',
  // SSH remote environments: mounted so the plugin-detail switch exists, but
  // EXPERIMENTAL and inert while `multi-root-remote-tools.enabled` is off —
  // no tool, verifier, projection, or remote plane is exposed (ADR-0030).
  'multi-root-remote-tools',
  'multi-root-instructions',
  'multi-root-lsp',
  'multi-root-workspace-files',
  // The B9 process fence: wraps the public shell/PTC/PTY entries so
  // `danger-full-access` cannot bypass an explicit read-only root.
  'multi-root-process-fence',
  'multi-root-command',
  // The client-graph anchor: mounted at the bare package name so the web
  // client-module scan reads this package's `dsh.client` declaration.
  'multi-root-client',
  // The optional Auto Review entry: ships disabled, so it is present in the
  // composition metadata but mounts no reviewer, context or takeover hook.
  'multi-root-auto-review',
]
const UPSTREAM_STANDALONE = ['bash-sandbox', 'sandbox-policy', 'tool-fs', 'tool-bash', 'terminal-bash']

const check = createChecker('compose')
const home = resolveScratchHome(`compose-${process.pid}`)
const keep = process.env.DSH_SMOKE_KEEP === '1'

/** The dump must be a YAML array of rows; `!!js` tag warnings are expected. */
function parseDump(text, label) {
  const rows = parse(text, { logLevel: 'silent' })
  if (!Array.isArray(rows)) throw new Error(`${label}: --dump-config did not print a YAML array`)
  return rows
}

function byId(rows) {
  const map = new Map()
  for (const row of rows) if (row !== null && typeof row === 'object' && typeof row.id === 'string') map.set(row.id, row)
  return map
}

async function dump(profile) {
  const result = await captureDsh(['--profile', profile, '--dump-config'], { DSH_HOME: home })
  check.ok(result.code === 0, `dsh --profile ${profile} --dump-config exits 0`, result.stderr.trim())
  check.ok(!result.stderr.includes('not found'), `dsh reports no unmatched patch rows for ${profile}`, result.stderr.trim())
  return { rows: parseDump(result.stdout, profile), stderr: result.stderr }
}

try {
  if (!existsSync(join(REPO_ROOT, 'lib', 'fs.js'))) throw new Error('lib/ is missing — run `pnpm build` before the smoke')

  rmSync(home, { recursive: true, force: true })
  mkdirSync(home, { recursive: true })
  assertIsolatedHome(home)

  const baselineProfile = 'mr-baseline'
  const pluginProfile = 'mr-plugin'

  console.log(`[smoke:compose] scratch home: ${home}`)
  // Copy import lands before `plugin install` materializes store references —
  // the hardlink preflight counts every multi-link file under the home.
  ensureProfileCopyImport(home, baselineProfile)
  const initCode = await runDsh(['plugin', '--profile', baselineProfile, 'install'], { DSH_HOME: home })
  check.ok(initCode === 0, 'baseline profile initialized without the plugin', `exit ${initCode}`)

  const addCode = await installPluginProfile(pluginProfile, home)
  check.ok(addCode === 0, 'plugin installed into a profile through `dsh plugin add`', `exit ${addCode}`)

  const baseline = await dump(baselineProfile)
  const composed = await dump(pluginProfile)

  const baselineRows = byId(baseline.rows)
  const composedRows = byId(composed.rows)

  // 1. The baseline really is the untouched composition.
  for (const [id, name] of REPLACED) {
    const row = baselineRows.get(id)
    check.ok(row !== undefined, `baseline still mounts ${id}`, `rows: ${[...baselineRows.keys()].length}`)
    check.equal(row?.name, name, `baseline ${id} points at the upstream provider`)
    check.ok(row?.disabled !== true, `baseline ${id} is enabled`)
  }

  // 2. The plugin's rows are present, enabled, and point at this package.
  const insertedIds = composed.rows
    .filter(row => typeof row?.id === 'string' && row.id.startsWith('multi-root-'))
    .map(row => row.id)
  check.equal(insertedIds, INSERTED, `exactly the ${INSERTED.length} plugin rows were inserted, in order`)
  for (const id of INSERTED) {
    const row = composedRows.get(id)
    check.ok(
      row?.name === PLUGIN_NAME || row?.name?.startsWith(`${PLUGIN_NAME}/`) === true,
      `${id} resolves inside ${PLUGIN_NAME}`,
      String(row?.name),
    )
    if (id === 'multi-root-auto-review') {
      check.ok(row?.disabled === true, `${id} ships disabled`)
    } else {
      check.ok(row?.disabled !== true, `${id} is enabled`)
    }
  }

  // 3. The two replaced rows are disabled, and nothing else changed about them.
  for (const [id] of REPLACED) {
    const before = baselineRows.get(id)
    const after = composedRows.get(id)
    check.equal(after?.disabled, true, `${id} is disabled in the composed tree`)
    const { disabled: _dropped, ...restAfter } = after ?? {}
    check.equal(restAfter, before, `${id} is byte-identical apart from \`disabled\``)
  }

  // 4. Every other row is untouched, in the same order.
  const composedWithoutInserted = composed.rows.filter(row => !(typeof row?.id === 'string' && row.id.startsWith('multi-root-')))
  check.equal(composedWithoutInserted.length, baseline.rows.length, 'the composed tree adds no rows beyond the plugin rows')
  check.equal(
    composedWithoutInserted.map(row => row?.id),
    baseline.rows.map(row => row?.id),
    'row order is unchanged',
  )
  const changed = []
  for (const [index, before] of baseline.rows.entries()) {
    const after = composedWithoutInserted[index]
    if (JSON.stringify(before) !== JSON.stringify(after)) changed.push(after?.id)
  }
  check.equal(changed.sort(), [...REPLACED.keys()].sort(), 'only the two replaced rows differ')

  // 5. The rows this plugin deliberately keeps upstream are still enabled.
  for (const id of UPSTREAM_STANDALONE) {
    if (!baselineRows.has(id)) continue
    const before = baselineRows.get(id)
    const after = composedRows.get(id)
    check.equal(after?.disabled, before?.disabled, `${id} keeps its upstream enablement`)
  }

  check.finish()
} finally {
  if (!keep && process.env.DSH_SMOKE_KEEP !== '1') rmSync(home, { recursive: true, force: true })
  else console.log(`[smoke:compose] kept scratch home at ${home}`)
}
