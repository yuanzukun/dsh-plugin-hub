/**
 * smoke:journey — the acceptance journey: a user registers a second Git
 * repository as an additional workspace root, and an Agent then works across
 * BOTH repositories in one session.
 *
 * What makes this an acceptance test rather than another battery:
 *
 * - the root is registered the way a user registers it, through
 *   `/workspace-folders add` executed by the real command runtime;
 * - the Agent runs REAL turns through the real loop, driven by a scripted
 *   OpenAI-compatible endpoint (`DEEPSEEK_BASE_URL`), so no credential is needed
 *   and the tool calls are the ones a user's session would get;
 * - every assertion reads the WORLD — file bytes, a `git` command re-run from
 *   outside the session, the recorded model request — rather than prose.
 *
 * Two compositions, two shapes of the same journey:
 *
 * - `web` is booted IN PROCESS with the launcher facts its app rows need, so the
 *   browser composition is assembled for real, the command is dispatched by
 *   `ctx.commands.execute`, and the panel's RPC channel is exercised over real
 *   HTTP against the bound web server (401 unauthenticated, an ok envelope
 *   authenticated) — the browser→HTTP→channel hop no other test covers;
 * - `headless` runs as a REAL `dsh --profile headless "<task>"` subprocess, with
 *   the registration pre-seeded in the registry store (the one path that process
 *   has to a registration) and its own one-shot turn.
 *
 * A host that cannot nest a kernel sandbox refuses confined `bash`; the
 * bash-dependent assertions then report an explicit skip with the reason instead
 * of passing silently (see docs/development/plugin-development-workflow.md).
 *
 * @module scripts/smoke-journey
 */

import { execFileSync, spawn } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, realpathSync, rmSync, writeFileSync } from 'node:fs'
import { createServer } from 'node:http'
import { join } from 'node:path'
import { createChecker } from './lib/check.mjs'
import {
  assertIsolatedHome,
  loadRuntimeModule,
  installPluginProfile,
  REPO_ROOT,
  resolveDshCliPath,
  resolveScratchHome,
} from './lib/dsh-runtime.mjs'
import { bootProfile } from './lib/profile-boot.mjs'
import { requireKernelRunner } from '../tests/support/kernel-runner.ts'

const DOMAIN = 'multi_root_workspace'
const PLUGIN_NAME = '@dsh-electron/dsh-plugin-multi-root-workspace'
const PRIMARY_README = 'primary repository readme\n'
const SEED_README = 'seed readme for repo-b\n'
const EDITED_README = 'seed readme for repo-b\nedited by the agent through the additional root\n'
/**
 * Instruction-file markers, one per level of the discovery hierarchy.
 *
 * Each is a phrase no other part of the composition produces, so finding it in a
 * recorded model request proves WHICH file reached the model — and counting it
 * proves the plugin did not inject a second copy of something upstream already
 * supplies (the primary chain and the user-global file).
 */
const SKILL_MODEL_BODY = 'journey additional-root model skill body marker'
const SKILL_USER_BODY = 'journey additional-root user-only skill body marker'
const RULE_PRIMARY = 'house rule alpha: the primary repository is authoritative'
const RULE_ADDITIONAL = 'house rule bravo: the other repository uses four-space indentation'
const RULE_NESTED = 'house rule echo: the other repository\'s src directory uses two-space indentation'
const RULE_DEEP = 'house rule foxtrot: the other repository\'s src/deep directory uses one-space indentation'
const RULE_USER_GLOBAL = 'house rule charlie: always explain the plan first'
const RULE_ANCESTOR = 'house rule delta: this ancestor directory is not a workspace root'
/** One scripted turn: nine tool calls, then the closing assistant text. */
const SCRIPT_LENGTH = 11
/** A path spelling that survives inside a single-quoted Node `-e` string on every shell. */
function shellPath(path) {
  return path.replace(/\\/g, '/')
}

/** The composed shell tool's registered name on this platform. */
const shellTool = process.platform === 'win32' ? 'pwsh' : 'bash'
const home = resolveScratchHome(`journey-${process.pid}`)
const fixtureRoot = join(REPO_ROOT, '.dsh-smoke', `journey-${process.pid}`)
const primaryRepo = join(fixtureRoot, 'repo-a')
const additionalRepo = join(fixtureRoot, 'repo-b')
const outsideRoot = join(fixtureRoot, 'outside')
const keep = process.env.DSH_SMOKE_KEEP === '1'
const check = createChecker('journey')

/** The canonical spelling of a fixture path. */
function canonical(path) {
  try {
    return realpathSync.native(path)
  } catch {
    return path
  }
}

/**
 * The spelling `path` has INSIDE JSON-serialized text.
 *
 * Checks that search a recorded model request or a channel view search a JSON
 * body, where each backslash is escaped: a Windows path only ever appears as
 * `D:\\a\\...`, never as `D:\a\...`. On POSIX this is the identity.
 */
function jsonText(path) {
  return JSON.stringify(path).slice(1, -1)
}

/** Seed one Git repository with a tracked file and one commit. */
function seedRepo(path, trackedFile, content) {
  mkdirSync(path, { recursive: true })
  writeFileSync(join(path, trackedFile), content)
  const git = (...args) => execFileSync('git', ['-C', path, ...args], { stdio: 'pipe' })
  git('init', '--quiet', '--initial-branch=main')
  git('config', 'user.email', 'smoke@example.invalid')
  git('config', 'user.name', 'Multi-root smoke')
  git('add', '.')
  git('commit', '--quiet', '-m', 'seed')
}

/**
 * One recorded model request's wire messages, flattened to role and text.
 *
 * Reading the WIRE body is the point: it is the only place that shows what the
 * model was actually told, in which role, after every row in the composition has
 * had its say.
 * @param request - one recorded request body.
 * @returns the messages, in wire order.
 */
function wireMessages(request) {
  return (request?.messages ?? []).map(message => ({
    role: message?.role,
    text: typeof message?.content === 'string'
      ? message.content
      : (Array.isArray(message?.content) ? message.content : []).map(part => part?.text ?? '').join(''),
  }))
}

/**
 * The roles of the wire messages carrying one marker.
 *
 * The length answers "how many times was this file injected" and the contents
 * answer "with what authority" — the two questions the instruction design turns
 * on: exactly once, and never as `system`.
 * @param request - one recorded request body.
 * @param marker - the phrase to look for.
 * @returns one role per carrying message.
 */
function rolesCarrying(request, marker) {
  return wireMessages(request).filter(entry => entry.text.includes(marker)).map(entry => entry.role)
}

/** Run one git command against a seeded repository and return its stdout. */
function git(path, ...args) {
  return execFileSync('git', ['-C', path, ...args], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
}

/**
 * One scripted turn in the chat-completions wire dialect.
 *
 * Deltas carry the whole tool call in one chunk; the smoke is scripting a model,
 * not testing the harness's stream reassembly.
 * @param call - the tool call to emit, or `undefined` to close the turn.
 * @param text - the assistant text used when closing the turn.
 * @param id - the tool call id.
 * @returns SSE frames, in order.
 */
function chatCompletionFrames(call, text, id) {
  const frame = payload => `data: ${JSON.stringify(payload)}\n\n`
  return [
    frame({ choices: [{ delta: { role: 'assistant', content: null } }] }),
    call === undefined
      ? frame({ choices: [{ delta: { content: text } }] })
      : frame({
        choices: [{
          delta: {
            tool_calls: [{
              index: 0,
              id,
              type: 'function',
              function: { name: call.name, arguments: JSON.stringify(call.arguments) },
            }],
          },
        }],
      }),
    frame({
      choices: [{ delta: {}, finish_reason: call === undefined ? 'stop' : 'tool_calls' }],
      usage: { prompt_tokens: 5, completion_tokens: 2 },
    }),
    'data: [DONE]\n\n',
  ]
}

/**
 * The same scripted turn in the block-oriented Messages wire dialect.
 *
 * This protocol has a stricter contract than chat completions, and all of it is
 * load-bearing here: every event names its `type`, the named SSE event must
 * agree with it, each content block is explicitly opened and closed, and the
 * stream must settle with a stop reason before `message_stop` or the harness
 * rejects it as malformed.
 * @param call - the tool call to emit, or `undefined` to close the turn.
 * @param text - the assistant text used when closing the turn.
 * @param id - the tool call id.
 * @returns SSE frames, in order.
 */
function messagesFrames(call, text, id) {
  const frame = payload => `event: ${payload.type}\ndata: ${JSON.stringify(payload)}\n\n`
  const block = call === undefined
    ? [
      { type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } },
      { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text } },
      { type: 'content_block_stop', index: 0 },
    ]
    : [
      { type: 'content_block_start', index: 0, content_block: { type: 'tool_use', id, name: call.name, input: {} } },
      { type: 'content_block_delta', index: 0, delta: { type: 'input_json_delta', partial_json: JSON.stringify(call.arguments) } },
      { type: 'content_block_stop', index: 0 },
    ]
  return [
    { type: 'message_start', message: { usage: { input_tokens: 5, output_tokens: 2 } } },
    ...block,
    { type: 'message_delta', delta: { stop_reason: call === undefined ? 'end_turn' : 'tool_use' } },
    { type: 'message_stop' },
  ].map(frame)
}

/**
 * The scripted model endpoint.
 *
 * Two kinds of request arrive on it: the session-title side call (recognized by
 * its own system prompt) and the agent's own step requests. Title requests are
 * always answered with plain text and never consume the script; each STEP
 * request consumes the next tool call, and the request that starts a new cycle
 * closes the turn with plain text. Every body is recorded — that is how the
 * smoke reads what the model actually received, including the runtime-context
 * snapshot.
 *
 * It answers BOTH wire dialects the supported releases speak, selected per
 * request by path. A journey that only spoke one of them would fail on the other
 * release for a reason that has nothing to do with this plugin.
 * @returns the endpoint handle.
 */
async function startScriptedModel() {
  const requests = []
  const steps = []
  const aliasSteps = []
  const calls = [
    // A read INSIDE the additional root's `src/deep/`: H4 phase 2 must make BOTH
    // that directory's AGENTS.md and its parent `src`'s — an ancestor of the
    // touched file — relevant to the NEXT step.
    { name: 'read', arguments: { file_path: join(additionalRepo, 'src', 'deep', 'entry.mjs') } },
    // The write below needs the file to have been read first — the tool layer's
    // own rule — so the README read stays exactly where it was.
    { name: 'read', arguments: { file_path: join(additionalRepo, 'README.md') } },
    { name: 'write', arguments: { file_path: join(additionalRepo, 'README.md'), content: EDITED_README } },
    // The shell calls keep a placeholder name — the composed row is `bash` on
    // POSIX and `pwsh` on Windows, decided per request from the tools the
    // harness itself advertised. The command text is valid in both dialects:
    // a single-quoted path is a literal string to PowerShell, and `workdir`
    // exists on both tool schemas.
    { name: 'bash', arguments: { command: `git -C '${additionalRepo}' diff --stat`, description: 'Show the other repository diff' } },
    { name: 'bash', arguments: { command: 'node check.mjs', description: 'Run the other repository check', workdir: additionalRepo } },
    // The per-tool cap proof: the shell tool is configured `read-only` for
    // additional roots on BOTH legs (see capShellTool), so this write must be
    // refused by the kernel runner while the same shell still writes the
    // primary root — and the uncapped `write` tool keeps the full grant.
    { name: 'bash', arguments: { command: `node -e "require('fs').writeFileSync('${shellPath(join(additionalRepo, 'capped-shell.txt'))}','x')"`, description: 'Write the other repository through the shell' } },
    { name: 'bash', arguments: { command: `node -e "require('fs').writeFileSync('${shellPath(join(primaryRepo, 'shell-primary.txt'))}','x')"`, description: 'Write the primary repository through the shell' } },
    { name: 'write', arguments: { file_path: join(additionalRepo, 'write-tool.txt'), content: 'written by the write tool\n' } },
    { name: 'write', arguments: { file_path: join(outsideRoot, 'denied.txt'), content: 'must not land' } },
    { name: 'skill', arguments: { name: 'journey-model' } },
  ]
  /**
   * Resolve a scripted shell call against the tool list the HARNESS sent:
   * `pwsh` when that is the composed tool, `bash` otherwise. The command,
   * description and workdir arguments are schema-identical on both tools, so
   * only the name differs.
   */
  const withShellTool = (call, request) => {
    if (call?.name === 'skill') {
      const name = JSON.stringify(request).match(/mr-[a-f0-9]{64}-journey-model/)?.[0]
      if (name === undefined) throw new Error('additional-root model Skill missing from the native first-step catalog')
      return { ...call, arguments: { name } }
    }
    if (call === undefined || (call.name !== 'bash' && call.name !== 'pwsh')) return call
    const tools = request.tools ?? []
    const found = tools.find(tool => (tool?.function?.name ?? tool?.name) === 'pwsh')
    if (found === undefined) return { ...call, name: 'bash' }
    // The pwsh tool's schema differs across releases: drop every argument the
    // advertised schema does not declare (`additionalProperties: false` makes
    // an extra field a hard error), and fold a missing `workdir` into the
    // command itself.
    const properties = found?.function?.parameters?.properties ?? found?.parameters?.properties ?? {}
    const args = { ...call.arguments }
    if ('workdir' in args && !('workdir' in properties)) {
      args.command = `Set-Location -LiteralPath '${String(args.workdir).replace(/'/g, "''")}'; ${String(args.command)}`
      delete args.workdir
    }
    if (Object.keys(properties).length > 0) {
      for (const key of Object.keys(args)) if (!(key in properties)) delete args[key]
    }
    return { ...call, name: 'pwsh', arguments: args }
  }
  const server = createServer((request, response) => {
    let body = ''
    request.setEncoding('utf8')
    request.on('data', chunk => { body += chunk })
    request.on('end', () => {
      let parsed
      try {
        parsed = JSON.parse(body)
      } catch {
        parsed = { unparsable: body.slice(0, 200) }
      }
      requests.push(parsed)
      // An agent STEP is the request that offers tools; the session-title side
      // call never does. That structural difference holds in both wire dialects,
      // unlike matching the title prompt's wording — on some releases the whole
      // session log travels with every request, so the title text appears in the
      // agent's own body too and a text match classifies everything as a title.
      const isTitle = !Array.isArray(parsed.tools) || parsed.tools.length === 0
      const alias = !isTitle && wireMessages(parsed).some(message => message.role === 'user' && message.text.includes('/repo-b:journey-user'))
      if (!isTitle && !alias) steps.push(parsed)
      if (alias) aliasSteps.push(parsed)
      const call = isTitle || alias ? undefined : withShellTool(calls[(steps.length - 1) % SCRIPT_LENGTH], parsed)
      const text = isTitle ? 'journey' : alias ? 'alias complete' : 'journey complete'
      const id = `journey-${steps.length}`
      response.writeHead(200, { 'content-type': 'text/event-stream' })
      // The REQUEST PATH picks the wire dialect, because that is how the
      // harness itself distinguishes them: `/v1/messages` is the block-oriented
      // Messages protocol, anything else the chat-completions one. Answering
      // whichever the installed release asks for is what lets one journey
      // script serve the whole supported matrix (ADR-0009).
      const frames = (request.url ?? '').includes('/v1/messages')
        ? messagesFrames(call, text, id)
        : chatCompletionFrames(call, text, id)
      for (const frame of frames) response.write(frame)
      response.end()
    })
  })
  await new Promise(resolve => { server.listen(0, '127.0.0.1', resolve) })
  const address = server.address()
  if (address === null || typeof address === 'string') throw new Error('the scripted model did not bind a TCP port')
  return {
    baseUrl: `http://127.0.0.1:${address.port}`,
    requests,
    steps,
    aliasSteps,
    close: () => new Promise(resolve => { server.close(resolve) }),
  }
}

/**
 * Prepare one shipped profile on the scratch home.
 *
 * The shipped profiles are installation-owned and cannot be targets of
 * `--from-default-profile`; installing a plugin into one initializes its user
 * layer (bundles = the shipped template plus this bundle), which is exactly the
 * composition the journey must run in.
 */
async function prepareProfile(profile) {
  const added = await installPluginProfile(profile, home)
  check.ok(added === 0, `${profile}: plugin installed into the shipped profile`, `exit ${added}`)
}

/**
 * Cap the composed shell tool for additional roots on one profile, the way a
 * host configures it: an id-targeted config override in the profile's own
 * patch layer, applied after every bundle layer. `bash` and `pwsh` are the two
 * registered names the composed shell tool takes, so capping both keeps the
 * assertion identical on every platform.
 * @param profile - the shipped profile the next leg boots.
 */
function capShellTool(profile) {
  writeFileSync(join(home, 'profiles', profile, 'cordis.patch.yml'), [
    '# smoke override: the shell tool may never write an additional root.',
    '- id: multi-root-scope',
    '  config:',
    '    toolAccess:',
    '      bash: read-only',
    '      pwsh: read-only',
    '',
  ].join('\n'))
}

/** Write the registry store a fresh process reads at boot. */
function seedRegistryStore(primaryRoot) {
  const storeRoot = join(home, 'storages')
  mkdirSync(storeRoot, { recursive: true })
  writeFileSync(join(storeRoot, `${DOMAIN}.json`), JSON.stringify({
    unit: { name: DOMAIN, version: 1 },
    global: null,
    tables: {
      roots: {
        [canonical(primaryRoot)]: {
          roots: [{
            id: 'journey-seed',
            path: canonical(additionalRepo),
            // The directory this registration is granted for. A record without it
            // is reported as unusable rather than granted on a guess (the plugin
            // never writes such a record itself; this seeding plays the registry).
            // `recordedPath` alone IS the read-write grant; a read-only record
            // would name `readOnlyRecordedPath` instead (see src/registry.ts).
            recordedPath: canonical(additionalRepo),
            alias: 'repo-b',
            addedAt: new Date().toISOString(),
          }],
        },
      },
    },
  }, null, 2))
}

/** Environment every leg runs the harness with. */
function legEnvironment(model) {
  return {
    ...process.env,
    DSH_PERMISSION_MODE: 'workspace-write',
    DEEPSEEK_API_KEY: 'journey-smoke-key',
    DEEPSEEK_BASE_URL: model.baseUrl,
  }
}

/**
 * The `web` leg: boot the browser composition in process, register the root
 * through the command, and drive one real turn.
 * @returns what the assertions read.
 */
async function runWebLeg() {
  const { ctx } = await bootProfile('web', home, async (hostCtx) => {
    const { provideCmdline } = await loadRuntimeModule('@deepseek-ai/dsh-cmdline')
    // The web app's rows read these launcher facts; `--port 0` keeps the smoke
    // from claiming a fixed port on the machine running it.
    provideCmdline(hostCtx, { args: ['--no-open', '--port', '0'], exit: () => {} })
  })
  const observed = { events: [] }
  try {
    // The bundle patch must carry a bare-package-name row, or the web
    // client-module scan never reads this package's `dsh.client` declaration
    // and the browser is never served `lib/client.js` — the footer action then
    // silently never registers (see docs/troubleshooting/).
    const clientModules = ctx.get('clientModules')
    observed.clientEntryServed = clientModules?.graph().entries.some(entry => entry.id === PLUGIN_NAME) === true
    const { installModelSelection } = await loadRuntimeModule('@deepseek-ai/dsh-agent')
    const selection = ctx.agentDefaultModel.currentSelection()
    const selected = { current: selection, assembled: undefined }
    // The browser composition keeps its model-facing tool rows in the agent
    // preset realm, so a session that does not join a preset resolves tools
    // against an empty layer. This mirrors what the shipped session controller
    // does for every Web session.
    const presets = ctx.get('agentPresets')
    const presetId = presets === undefined ? undefined : (await presets.resolve(undefined)).id
    const handle = await ctx.agents.create({
      sessionId: 'journey-web',
      meta: { cwd: primaryRepo, ...(presetId === undefined ? {} : { agentPreset: presetId }) },
      agentOptions: { provider: selection.provider, model: selection.model },
      setup: async (agentCtx) => {
        installModelSelection(agentCtx, selected)
        if (presets !== undefined && presetId !== undefined) await presets.mount(agentCtx, presetId)
      },
    })
    const agent = handle.agent
    try {
      const registered = await ctx.commands.execute(
        agent,
        `/workspace-folders add '${additionalRepo}'`,
        [],
        new AbortController().signal,
      )
      observed.registration = registered?.result
      const dispose = ctx.on('session/event', (session, event) => {
        if (session !== agent.session) return
        observed.events.push(event)
      })
      try {
        const llm = await loadRuntimeModule('@deepseek-ai/dsh-llm')
        agent.followup(llm.createUserMessage({
          content: [{ type: 'text', text: 'work across both repositories' }],
          source: { kind: 'user' },
        }))
        await agent.whenIdle()
        await ctx.sessions.flush(agent.session)
      } finally {
        dispose()
      }
      observed.granted = ctx.multiRootScope.snapshot({ workspaceRoot: primaryRepo, mode: 'read-only' }).additionalRoots
      const llm = await loadRuntimeModule('@deepseek-ai/dsh-llm')
      agent.followup(llm.createUserMessage({ content: [{ type: 'text', text: '/repo-b:journey-user verify this skill' }], source: { kind: 'user' } }))
      await agent.whenIdle()
      const root = ctx.multiRootRegistry.list(primaryRepo)[0]
      const skills = ctx.get('skills')
      const catalog = await skills.snapshot({ cwd: additionalRepo, scope: agent })
      const internal = catalog.skills.find(skill => skill.name.endsWith('-journey-model'))?.name
      if (!internal) throw new Error('live additional-root Skill missing')
      const descriptor = ctx.settings.describe().find(entry => entry.ns === 'multi-root-skills')
      await ctx.settings.mutate('multi-root-skills', [{ op: 'set', path: ['enabled'], value: false }], descriptor?.revision)
      observed.globalDisabled = (await skills.snapshot({ cwd: additionalRepo, scope: agent })).skills.every(skill => skill.provider !== 'multi-root-workspace')
        && await skills.get(internal, { cwd: additionalRepo, scope: agent }) === undefined
      observed.primarySkillKept = (await skills.snapshot({ cwd: additionalRepo, scope: agent })).skills.some(skill => skill.name === 'journey-primary')
      await ctx.settings.mutate('multi-root-skills', [{ op: 'set', path: ['enabled'], value: true }])
      observed.globalRestored = ctx.multiRootRegistry.list(primaryRepo)[0].skillsEnabled === true
        && (await skills.snapshot({ cwd: additionalRepo, scope: agent })).skills.some(skill => skill.name === internal)
      await ctx.multiRootRegistry.setSkillsEnabled(primaryRepo, { kind: 'id', id: root.id }, false)
      observed.noBareBypass = await skills.get('journey-model', { cwd: additionalRepo, scope: agent }) === undefined
      await ctx.multiRootRegistry.setSkillsEnabled(primaryRepo, { kind: 'id', id: root.id }, true)

      // The panel's own path: real HTTP against the bound web server. An
      // unauthenticated POST must answer 401 — 405 would mean the channel
      // route never registered and the request fell through to the static
      // SPA fallback (the silent failure this probe exists to catch).
      const webServer = ctx.get('webServer')
      const base = `http://127.0.0.1:${webServer.port}/`
      const unauthenticated = await fetch(new URL('/multi-root-workspace/list', base), {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ type: 'client-request', rpcId: 'journey-unauth', method: 'list', payload: {} }),
      })
      observed.channelUnauthenticated = unauthenticated.status
      const authResponse = await fetch(ctx.get('connection').authenticatedUrl(base), { redirect: 'manual' })
      const cookie = authResponse.headers.get('set-cookie')?.split(';', 1)[0]
      const listed = await fetch(new URL('/multi-root-workspace/list', base), {
        method: 'POST',
        headers: { 'content-type': 'application/json', ...(cookie === undefined ? {} : { cookie }) },
        body: JSON.stringify({
          type: 'client-request',
          rpcId: 'journey-list',
          method: 'list',
          payload: { sessionId: 'journey-web' },
        }),
      })
      observed.channelList = listed.status
      observed.channelView = listed.status === 200 ? (await listed.json())?.result : undefined

      // ---- worktree A/B over the same real HTTP channel ---------------------
      // The audit's P6 gap: settings switch, prompt confirmation and cleanup
      // must be exercised by the browser composition, not by a captured
      // handler. One linked checkout becomes the live session primary; a
      // sibling checkout is the B prompt, then the shared common is the A
      // prompt after the B root is cleaned up.
      const linkedRoot = join(fixtureRoot, 'repo-a-wt')
      const siblingRoot = join(fixtureRoot, 'repo-a-wt2')
      execFileSync('git', ['-C', primaryRepo, 'worktree', 'add', '-q', linkedRoot, '-b', 'journey-wt'], { stdio: 'pipe' })
      execFileSync('git', ['-C', primaryRepo, 'worktree', 'add', '-q', siblingRoot, '-b', 'journey-wt2'], { stdio: 'pipe' })
      const worktreeSelection = ctx.agentDefaultModel.currentSelection()
      const worktreePresetId = presets === undefined ? undefined : (await presets.resolve(undefined)).id
      const worktreeHandle = await ctx.agents.create({
        sessionId: 'journey-worktree',
        meta: { cwd: linkedRoot, ...(worktreePresetId === undefined ? {} : { agentPreset: worktreePresetId }) },
        agentOptions: { provider: worktreeSelection.provider, model: worktreeSelection.model },
        setup: async (agentCtx) => {
          installModelSelection(agentCtx, { current: worktreeSelection, assembled: undefined })
          if (presets !== undefined && worktreePresetId !== undefined) await presets.mount(agentCtx, worktreePresetId)
        },
      })
      try {
        let rpcSequence = 0
        const channel = async (endpoint, payload) => {
          const response = await fetch(new URL(`/multi-root-workspace/${endpoint}`, base), {
            method: 'POST',
            headers: { 'content-type': 'application/json', ...(cookie === undefined ? {} : { cookie }) },
            body: JSON.stringify({ type: 'client-request', rpcId: `journey-worktree-${++rpcSequence}`, method: endpoint, payload }),
          })
          return { status: response.status, body: await response.json().catch(() => undefined) }
        }
        observed.worktreeSibling = canonical(siblingRoot)
        observed.worktreeCommon = canonical(primaryRepo)
        const descriptor = ctx.settings.describe().find(entry => entry.ns === 'multi-root-worktrees')
        observed.worktreeSettingPresent = descriptor !== undefined
        // The feature is experimental and OFF by default: the first request must
        // be refused, and only an explicit Settings opt-in enables it.
        const off = await channel('worktreePrompt', { sessionId: 'journey-worktree' })
        observed.worktreeDefaultOff = off.body?.result?.error?.code
        await ctx.settings.mutate('multi-root-worktrees', [{ op: 'set', path: ['enabled'], value: true }])
        const first = await channel('worktreePrompt', { sessionId: 'journey-worktree' })
        observed.worktreePromptStatus = first.status
        const firstPrompts = first.body?.result?.value?.prompts ?? []
        observed.worktreePromptCount = firstPrompts.length
        const bPrompt = firstPrompts.find(prompt => prompt.kind === 'worktree' && prompt.path === canonical(siblingRoot))
        observed.worktreePromptKind = bPrompt?.kind
        observed.worktreePromptPath = bPrompt?.path
        const confirmedB = await channel('worktreePromptResolve', { sessionId: 'journey-worktree', promptIds: [bPrompt?.id], action: 'add' })
        observed.worktreeConfirmedB = confirmedB.body?.result?.ok === true
        const listedWorktrees = await channel('list', { sessionId: 'journey-worktree' })
        const mapped = listedWorktrees.body?.result?.value?.roots?.find(row => row.path === canonical(siblingRoot))
        observed.worktreeMappedB = mapped !== undefined && mapped?.worktree?.state === 'active'
        const rootId = mapped?.id
        rmSync(siblingRoot, { recursive: true, force: true })
        const cleaned = await channel('worktreeRootsCleanup', { sessionId: 'journey-worktree', rootIds: [rootId] })
        observed.worktreeCleaned = Array.isArray(cleaned.body?.result?.value?.removed) && cleaned.body.result.value.removed.includes(rootId)
        const next = await channel('worktreePrompt', { sessionId: 'journey-worktree' })
        const nextPrompt = next.body?.result?.value?.prompts?.[0]
        observed.worktreeCommonKind = nextPrompt?.kind
        observed.worktreeCommonPath = nextPrompt?.path
        const commonId = nextPrompt?.id
        await ctx.settings.mutate('multi-root-worktrees', [{ op: 'set', path: ['enabled'], value: false }])
        const disabled = await channel('worktreePrompt', { sessionId: 'journey-worktree' })
        observed.worktreeDisabledCode = disabled.body?.result?.error?.code
        await ctx.settings.mutate('multi-root-worktrees', [{ op: 'set', path: ['enabled'], value: true }])
        const restored = await channel('worktreePromptWait', { sessionId: 'journey-worktree' })
        const restoredValue = restored.body?.result?.value
        const restoredPrompt = restoredValue?.prompt ?? restoredValue?.prompts?.[0]
        observed.worktreeRestoredKind = restoredPrompt?.kind
        observed.worktreeNewId = restoredPrompt?.id !== commonId
        const confirmedA = await channel('worktreePromptResolve', {
          sessionId: 'journey-worktree', promptIds: [restoredPrompt?.id], action: 'add',
        })
        observed.worktreeConfirmedA = confirmedA.body?.result?.ok === true
        observed.worktreeCommonRegistered = ctx.multiRootRegistry.list(linkedRoot).some(row => row.path === canonical(primaryRepo))
      } finally {
        await worktreeHandle.dispose()
      }
    } finally {
      await handle.dispose()
    }
    // The browser composition is the one that carries the panel's channel.
    observed.hasConnection = ctx.get('connection') !== undefined
    return observed
  } finally {
    await ctx.fiber.dispose()
  }
}

/**
 * The `headless` leg: a real one-shot CLI process, with the registration
 * pre-seeded in the store the process reads at boot.
 * @param model - the scripted endpoint.
 * @returns the process outcome and its stdout.
 */
async function runHeadlessLeg(model, prompt = 'work across both repositories') {
  const child = spawn(process.execPath, [resolveDshCliPath(), '--profile', 'headless', prompt], {
    cwd: primaryRepo,
    env: legEnvironment(model),
    stdio: ['ignore', 'pipe', 'pipe'],
  })
  let stdout = ''
  let stderr = ''
  child.stdout.setEncoding('utf8')
  child.stderr.setEncoding('utf8')
  child.stdout.on('data', chunk => { stdout += chunk })
  child.stderr.on('data', chunk => { stderr += chunk })
  const code = await new Promise((resolve, reject) => {
    child.on('error', reject)
    child.on('close', value => { resolve(value ?? 1) })
  })
  return { code, stdout, stderr }
}

try {
  if (!existsSync(join(REPO_ROOT, 'lib', 'registry.js'))) throw new Error('lib/ is missing — run `pnpm build` before the smoke')

  rmSync(home, { recursive: true, force: true })
  rmSync(fixtureRoot, { recursive: true, force: true })
  mkdirSync(home, { recursive: true })
  assertIsolatedHome(home)

  // Instruction files at all four levels: the primary root and the user-global
  // file are upstream's to inject, the additional root is this plugin's, and the
  // fixture's own parent is nobody's — it is an ancestor of an additional root,
  // which is the case a naive upward walk would wrongly pick up.
  mkdirSync(fixtureRoot, { recursive: true })
  writeFileSync(join(home, 'AGENTS.md'), `# user rules\n\n${RULE_USER_GLOBAL}\n`)
  writeFileSync(join(fixtureRoot, 'AGENTS.md'), `# ancestor rules\n\n${RULE_ANCESTOR}\n`)
  // Written before the seed commit, so `git status` stays clean: the journey's
  // strongest passthrough evidence is that the primary repository has no local
  // changes at the end, and an untracked fixture file would mask that.
  mkdirSync(primaryRepo, { recursive: true })
  writeFileSync(join(primaryRepo, 'AGENTS.md'), `# primary rules\n\n${RULE_PRIMARY}\n`)
  mkdirSync(join(primaryRepo, '.dsh/skills/journey-primary'), { recursive: true })
  writeFileSync(join(primaryRepo, '.dsh/skills/journey-primary/SKILL.md'), '---\nname: journey-primary\ndescription: Primary skill control\n---\nPRIMARY SKILL BODY\n')
  seedRepo(primaryRepo, 'README.md', PRIMARY_README)
  mkdirSync(additionalRepo, { recursive: true })
  writeFileSync(join(additionalRepo, 'check.mjs'), 'console.log("repo-b check ok")\n')
  writeFileSync(join(additionalRepo, 'AGENTS.md'), `# other repository rules\n\n${RULE_ADDITIONAL}\n`)
  // A subdirectory with its own instruction file, reached by the first scripted
  // tool call: this is what H4 phase 2 has to make visible, and it must be
  // committed state like everything else here so `git status` stays clean.
  //
  // TWO levels of it, because the touch below reaches `src/deep/entry.mjs`:
  // `src` is then only an ANCESTOR of the touched file, and its own file has to
  // arrive on the same step as the touched directory's — a walk of `src/deep`
  // alone reports it but filters it out.
  mkdirSync(join(additionalRepo, 'src', 'deep'), { recursive: true })
  writeFileSync(join(additionalRepo, 'src', 'AGENTS.md'), `# other src rules\n\n${RULE_NESTED}\n`)
  writeFileSync(join(additionalRepo, 'src', 'deep', 'AGENTS.md'), `# other deep rules\n\n${RULE_DEEP}\n`)
  writeFileSync(join(additionalRepo, 'src', 'deep', 'entry.mjs'), 'export const entry = 1\n')
  for (const [name, body, policy] of [['journey-model', SKILL_MODEL_BODY, ''], ['journey-user', SKILL_USER_BODY, 'disable-model-invocation: true\n']]) {
    mkdirSync(join(additionalRepo, '.dsh/skills', name), { recursive: true })
    writeFileSync(join(additionalRepo, '.dsh/skills', name, 'SKILL.md'), `---\nname: ${name}\ndescription: Additional-root journey Skill\n${policy}---\n${body}\n`)
  }
  seedRepo(additionalRepo, 'README.md', SEED_README)
  mkdirSync(outsideRoot, { recursive: true })
  writeFileSync(join(outsideRoot, 'keep.txt'), 'untouched\n')

  console.log(`[smoke:journey] scratch home: ${home}`)
  console.log(`[smoke:journey] fixture: ${fixtureRoot}`)

  const model = await startScriptedModel()
  const originalCwd = process.cwd()
  try {
    // ---- the browser composition ---------------------------------------------
    await prepareProfile('web')
    capShellTool('web')
    process.chdir(primaryRepo)
    Object.assign(process.env, legEnvironment(model))
    const stepsBeforeWeb = model.steps.length
    const web = await runWebLeg()

    check.equal(web.registration?.kind, 'success', 'web: /workspace-folders add succeeded', JSON.stringify(web.registration?.text))
    check.contains(String(web.registration?.text), additionalRepo, 'web: the command reports the registered root')
    check.equal(web.granted, [canonical(additionalRepo)], 'web: the scope grants exactly the registered root')
    check.ok(web.hasConnection, 'web: the browser composition carries the host Connection the panel needs')
    check.ok(web.clientEntryServed, 'web: the composed boot graph serves the plugin client bundle to the browser')
    check.equal(web.channelUnauthenticated, 401, 'web: an unauthenticated panel POST reaches the channel route (401, not the SPA fallback 405)', `status ${String(web.channelUnauthenticated)}`)
    check.equal(web.channelList, 200, 'web: the panel channel answers an authenticated list over real HTTP', `status ${String(web.channelList)}`)
    check.ok(web.channelView?.ok === true, 'web: the channel answers with an ok envelope', JSON.stringify(web.channelView)?.slice(0, 400))
    check.contains(JSON.stringify(web.channelView?.value), jsonText(canonical(additionalRepo)), 'web: the channel view lists the registered additional root', JSON.stringify(web.channelView)?.slice(0, 400))
    check.contains(JSON.stringify(web.channelView?.value), jsonText(canonical(primaryRepo)), 'web: the channel view names the primary root', JSON.stringify(web.channelView)?.slice(0, 400))
    check.equal(web.worktreeDefaultOff, 'worktree/not-enabled', 'web: the experimental worktree feature defaults to off')
    check.equal(web.worktreePromptStatus, 200, 'web: the worktree prompt answers over real HTTP', `status ${String(web.worktreePromptStatus)}`)
    check.equal(web.worktreePromptCount, 2, 'web: the popup lists the sibling checkout and the main checkout together')
    check.equal(web.worktreePromptKind, 'worktree', 'web: the sibling linked checkout is listed as a B candidate')
    check.equal(web.worktreePromptPath, web.worktreeSibling, 'web: the B candidate names the sibling checkout')
    check.ok(web.worktreeConfirmedB, 'web: the B confirmation registers through the real channel')
    check.ok(web.worktreeMappedB, 'web: the confirmed B root is listed with an active worktree badge')
    check.ok(web.worktreeCleaned, 'web: the deleted B root is cleaned through the real channel')
    check.equal(web.worktreeCommonKind, 'main-checkout', 'web: the A prompt follows the B cleanup')
    check.equal(web.worktreeCommonPath, web.worktreeCommon, 'web: the A prompt names the main checkout root')
    check.ok(web.worktreeSettingPresent, 'web: the worktree switch is a live Settings namespace')
    check.equal(web.worktreeDisabledCode, 'worktree/not-enabled', 'web: turning the switch off retires the live prompt')
    check.equal(web.worktreeRestoredKind, 'main-checkout', 'web: turning the switch back on re-detects the live session')
    check.ok(web.worktreeNewId, 'web: the restored prompt has a new ID')
    check.ok(web.worktreeConfirmedA, 'web: the A confirmation registers the main checkout through the real channel')
    check.ok(web.worktreeCommonRegistered, 'web: the A root is the main checkout root')
    check.equal(readFileSync(join(additionalRepo, 'README.md'), 'utf8'), EDITED_README, 'web: the additional root carries the agent\'s write')
    check.equal(readFileSync(join(primaryRepo, 'README.md'), 'utf8'), PRIMARY_README, 'web: the primary repository is byte-identical')
    check.equal(readFileSync(join(outsideRoot, 'keep.txt'), 'utf8'), 'untouched\n', 'web: a file outside every root is byte-identical')
    check.ok(!existsSync(join(outsideRoot, 'denied.txt')), 'web: the write outside every root left no file behind')
    check.equal(readFileSync(join(additionalRepo, 'write-tool.txt'), 'utf8'), 'written by the write tool\n', 'web: the uncapped write tool keeps the additional-root grant')
    check.contains(git(additionalRepo, 'status', '--porcelain'), ' M README.md', 'web: git reports the change in the other repository')

    const webRequests = model.steps.slice(stepsBeforeWeb)
    // Tool results travel back to the model, so the step requests are the one
    // place every result is visible for BOTH legs (in process and subprocess).
    check.ok(web.globalDisabled, 'web: global disable removes native catalog entries and blocks old internal IDs')
    check.ok(web.primarySkillKept, 'web: global disable preserves primary-root native Skills')
    check.ok(web.globalRestored, 'web: live global restore preserves Root choice and restores discovery')
    check.ok(web.noBareBypass, 'web: disabled Root cannot re-enter through native additional-root cwd')
    check.ok(JSON.stringify(model.aliasSteps).includes(SKILL_USER_BODY), 'web: user-only namespaced invocation reaches a real model request', `alias requests: ${model.aliasSteps.length}; ${JSON.stringify(model.aliasSteps).slice(-1600)}`)
    check.ok(!JSON.stringify(webRequests[0]).includes(SKILL_MODEL_BODY), 'web: first model request contains no additional-root Skill body')
    check.ok(/mr-[a-f0-9]{64}-journey-model/.test(JSON.stringify(webRequests[0])), 'web: first model request contains the namespaced bridge catalog')
    check.ok(JSON.stringify(webRequests).includes(SKILL_MODEL_BODY), 'web: native skill tool loads the body on demand')
    const webRendered = webRequests.map(request => JSON.stringify(request)).join('\n')
    const runnerFailed = rendered =>
      rendered.includes('SANDBOX_UNAVAILABLE')
      || rendered.includes('no sandbox backend is usable')
      || rendered.includes('the sandbox runner itself failed')
    // On a host whose dialect the kernel probe verified, an unusable runner is
    // a FAILURE, not a skip — requireKernelRunner throws for exactly that case.
    const runnerSkip = () => process.platform === 'win32'
      ? requireKernelRunner('windows-acl', 'the confined shell could not run in this process')
      : 'no usable kernel runner in this process'
    const webShellUnavailable = runnerFailed(webRendered)
    // The tool layer maps the structured FS_SANDBOX_DENIED code onto the shared
    // `[sandbox: …]` marker before the model sees it; that marker is what the
    // operator's denial text is built from.
    check.contains(webRendered, 'file access denied under workspace-write mode', 'web: the tool layer reported the outside write as a sandbox denial')
    if (webShellUnavailable) {
      check.skip(`web: confined ${shellTool} (per-tool cap writes, git diff and the other repository's check) — ${runnerSkip()}`)
    } else {
      // A missing additional-root marker proves the cap only when the shell
      // actually ran; its primary-root write is the positive control.
      check.ok(!existsSync(join(additionalRepo, 'capped-shell.txt')), `web: capped ${shellTool} could not write the additional root`)
      check.ok(existsSync(join(primaryRepo, 'shell-primary.txt')), `web: capped ${shellTool} still writes the primary root`)
      check.contains(webRendered, 'README.md |', `web: ${shellTool} saw the other repository's diff`, webRendered.slice(-800))
      check.contains(webRendered, 'repo-b check ok', `web: ${shellTool} ran the other repository's check`, webRendered.slice(-800))
    }
    rmSync(join(primaryRepo, 'shell-primary.txt'), { force: true })
    check.equal(git(primaryRepo, 'status', '--porcelain'), '', 'web: the primary repository has no local changes')
    const webExcerpt = webRendered.slice(-800)
    check.contains(webRendered, jsonText(canonical(additionalRepo)), 'web: the model\'s request names the additional root', webExcerpt)
    check.contains(webRendered, 'additional roots of this session\'s workspace', 'web: the runtime-context snapshot states the topology', webExcerpt)
    check.contains(webRendered, 'session origin remains the primary root', 'web: the snapshot separates session origin from cwd', webExcerpt)
    check.contains(webRendered, 'cannot write additional roots', `web: the snapshot names ${shellTool} as capped for additional roots`, webExcerpt)
    check.ok(webRequests.length >= SCRIPT_LENGTH, 'web: the agent issued one request per scripted step', `requests: ${webRequests.length}`)

    // The instruction journey, read off the first step's wire body: the Agent
    // sees all three repositories' rules before it touches anything, each
    // exactly once, and none of them with system authority.
    const webFirstStep = webRequests[0]
    const webWire = JSON.stringify(wireMessages(webFirstStep)).slice(0, 600)
    check.equal(rolesCarrying(webFirstStep, RULE_ADDITIONAL), ['user'], 'web: the additional root\'s AGENTS.md reached the model once, in the user role', webWire)
    check.equal(rolesCarrying(webFirstStep, RULE_PRIMARY).length, 1, 'web: the primary root\'s AGENTS.md reached the model exactly once', webWire)
    check.equal(rolesCarrying(webFirstStep, RULE_USER_GLOBAL).length, 1, 'web: the user-global AGENTS.md was not injected a second time', webWire)
    check.equal(rolesCarrying(webFirstStep, RULE_ANCESTOR).length, 0, 'web: an ancestor of the additional root was not injected at all', webWire)
    check.contains(JSON.stringify(webFirstStep), jsonText(canonical(additionalRepo)), 'web: the instruction text names the root its rules belong to')

    // The nested instruction journey. The first scripted call READS a file in
    // the additional root's `src/deep/`, so that directory's own AGENTS.md —
    // and its parent `src`'s, which is only an ANCESTOR of the touched file —
    // become relevant exactly one step later, and are injected exactly once.
    // Later requests repeat them because the whole log travels with every
    // request, so "once" is counted WITHIN one request, not across them.
    const webNested = webRequests.map(request => rolesCarrying(request, RULE_NESTED))
    const webDeep = webRequests.map(request => rolesCarrying(request, RULE_DEEP))
    check.equal(webNested[0].length, 0, 'web: a nested instruction file is not injected before it is reached', webWire)
    check.equal(webDeep[0].length, 0, 'web: a deeper instruction file is not injected before it is reached', webWire)
    check.equal(webNested[1], ['user'], 'web: the touched directory\'s ANCESTOR AGENTS.md reaches the model once, in the user role', JSON.stringify(webNested))
    check.equal(webDeep[1], ['user'], 'web: the touched directory\'s own AGENTS.md reaches the model once, in the user role', JSON.stringify(webDeep))
    check.equal(
      rolesCarrying(webRequests[webRequests.length - 1], RULE_NESTED),
      ['user'],
      'web: the nested instruction file sits in the final history exactly once, in the user role',
      JSON.stringify(webNested),
    )
    check.equal(
      rolesCarrying(webRequests[webRequests.length - 1], RULE_DEEP),
      ['user'],
      'web: the deeper instruction file sits in the final history exactly once, in the user role',
      JSON.stringify(webDeep),
    )

    // ---- the one-shot composition --------------------------------------------
    await prepareProfile('headless')
    capShellTool('headless')
    seedRegistryStore(primaryRepo)
    const stepsBeforeHeadless = model.steps.length
    // Reset the fixtures so the headless leg proves the same facts on its own.
    writeFileSync(join(additionalRepo, 'README.md'), SEED_README)
    execFileSync('git', ['-C', additionalRepo, 'checkout', '--', 'README.md'], { stdio: 'pipe' })
    rmSync(join(additionalRepo, 'write-tool.txt'), { force: true })
    rmSync(join(additionalRepo, 'capped-shell.txt'), { force: true })
    rmSync(join(primaryRepo, 'shell-primary.txt'), { force: true })

    const headless = await runHeadlessLeg(model)
    check.equal(headless.code, 0, 'headless: the one-shot task completed', headless.stderr.slice(-400))
    check.contains(headless.stdout, 'journey complete', 'headless: the run printed the final assistant message')
    check.equal(readFileSync(join(additionalRepo, 'README.md'), 'utf8'), EDITED_README, 'headless: the additional root carries the agent\'s write')
    check.equal(readFileSync(join(primaryRepo, 'README.md'), 'utf8'), PRIMARY_README, 'headless: the primary repository is byte-identical')
    check.ok(!existsSync(join(outsideRoot, 'denied.txt')), 'headless: the write outside every root left no file behind')
    check.equal(readFileSync(join(additionalRepo, 'write-tool.txt'), 'utf8'), 'written by the write tool\n', 'headless: the uncapped write tool keeps the additional-root grant')
    check.contains(git(additionalRepo, 'status', '--porcelain'), ' M README.md', 'headless: git reports the change in the other repository')

    const headlessAlias = await runHeadlessLeg(model, '/repo-b:journey-user verify this skill')
    check.equal(headlessAlias.code, 0, 'headless: user-only namespaced invocation completed')
    check.contains(headlessAlias.stdout, 'alias complete', 'headless: namespaced turn reached the scripted model')
    check.ok(model.aliasSteps.length >= 2 && JSON.stringify(model.aliasSteps.at(-1)).includes(SKILL_USER_BODY), 'headless: Host Alias injected user-only Skill body')
    const headlessSteps = model.steps.slice(stepsBeforeHeadless)
    check.ok(!JSON.stringify(headlessSteps[0]).includes(SKILL_MODEL_BODY), 'headless: first model request contains no additional-root Skill body')
    check.ok(/mr-[a-f0-9]{64}-journey-model/.test(JSON.stringify(headlessSteps[0])), 'headless: first model request already contains the bridge catalog')
    check.ok(JSON.stringify(headlessSteps).includes(SKILL_MODEL_BODY), 'headless: native skill tool loads the body on demand')
    const headlessResults = model.steps.slice(stepsBeforeHeadless).map(request => JSON.stringify(request)).join('\n')
    if (runnerFailed(headlessResults)) {
      check.skip(`headless: confined ${shellTool} (per-tool cap writes and the other repository's check) — ${runnerSkip()}`)
    } else {
      check.ok(!existsSync(join(additionalRepo, 'capped-shell.txt')), `headless: capped ${shellTool} could not write the additional root`)
      check.ok(existsSync(join(primaryRepo, 'shell-primary.txt')), `headless: capped ${shellTool} still writes the primary root`)
      check.contains(headlessResults, 'repo-b check ok', `headless: ${shellTool} ran the other repository's check`, headlessResults.slice(-800))
    }
    rmSync(join(primaryRepo, 'shell-primary.txt'), { force: true })

    const headlessRequests = model.steps.slice(stepsBeforeHeadless)
    const headlessRendered = headlessRequests.map(request => JSON.stringify(request)).join('\n')
    const headlessExcerpt = headlessRendered.slice(-800)
    check.contains(headlessRendered, jsonText(canonical(additionalRepo)), 'headless: the model\'s request names the additional root', headlessExcerpt)
    check.contains(headlessRendered, 'additional roots of this session\'s workspace', 'headless: the runtime-context snapshot states the topology', headlessExcerpt)

    const headlessFirstStep = headlessRequests[0]
    const headlessWire = JSON.stringify(wireMessages(headlessFirstStep)).slice(0, 600)
    check.equal(rolesCarrying(headlessFirstStep, RULE_ADDITIONAL), ['user'], 'headless: the additional root\'s AGENTS.md reached the model once, in the user role', headlessWire)
    check.equal(rolesCarrying(headlessFirstStep, RULE_PRIMARY).length, 1, 'headless: the primary root\'s AGENTS.md reached the model exactly once', headlessWire)
    check.equal(rolesCarrying(headlessFirstStep, RULE_USER_GLOBAL).length, 1, 'headless: the user-global AGENTS.md was not injected a second time', headlessWire)
    check.equal(rolesCarrying(headlessFirstStep, RULE_ANCESTOR).length, 0, 'headless: an ancestor of the additional root was not injected at all', headlessWire)

    const headlessNested = headlessRequests.map(request => rolesCarrying(request, RULE_NESTED))
    const headlessDeep = headlessRequests.map(request => rolesCarrying(request, RULE_DEEP))
    check.equal(headlessNested[0].length, 0, 'headless: a nested instruction file is not injected before it is reached', headlessWire)
    check.equal(headlessDeep[0].length, 0, 'headless: a deeper instruction file is not injected before it is reached', headlessWire)
    check.equal(headlessNested[1], ['user'], 'headless: the touched directory\'s ANCESTOR AGENTS.md reaches the model once, in the user role', JSON.stringify(headlessNested))
    check.equal(headlessDeep[1], ['user'], 'headless: the touched directory\'s own AGENTS.md reaches the model once, in the user role', JSON.stringify(headlessDeep))
    check.equal(
      rolesCarrying(headlessRequests[headlessRequests.length - 1], RULE_NESTED),
      ['user'],
      'headless: the nested instruction file sits in the final history exactly once, in the user role',
      JSON.stringify(headlessNested),
    )
    check.equal(
      rolesCarrying(headlessRequests[headlessRequests.length - 1], RULE_DEEP),
      ['user'],
      'headless: the deeper instruction file sits in the final history exactly once, in the user role',
      JSON.stringify(headlessDeep),
    )
  } finally {
    process.chdir(originalCwd)
    delete process.env.DSH_PERMISSION_MODE
    delete process.env.DEEPSEEK_API_KEY
    delete process.env.DEEPSEEK_BASE_URL
    // Under DSH_SMOKE_KEEP the recorded bodies are kept beside the fixture: when
    // an assertion about what the model was told fails, the body is the evidence,
    // and it is far too large to print.
    if (keep) writeFileSync(join(fixtureRoot, 'model-requests.json'), JSON.stringify(model.requests, null, 2))
    await model.close()
  }

  check.finish()
} finally {
  if (keep) {
    console.log(`[smoke:journey] kept scratch home at ${home} and fixture at ${fixtureRoot}`)
  } else {
    rmSync(home, { recursive: true, force: true })
    rmSync(fixtureRoot, { recursive: true, force: true })
  }
}
