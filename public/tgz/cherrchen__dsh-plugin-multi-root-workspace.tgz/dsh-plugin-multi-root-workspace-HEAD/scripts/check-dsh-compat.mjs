/**
 * compat:check — the static half of the DSH compatibility contract.
 *
 * The runtime gate (`src/compat.ts`) protects an installed harness; this script
 * protects the REPOSITORY, and it is the check that answers the complaint this
 * whole contract came from: `package.json` used to promise a whole minor range
 * while the code had only ever been verified against one release. A runtime
 * gate cannot catch that, because by the time it runs, npm has already resolved
 * whatever the range allowed.
 *
 * Four things must agree, and this script fails when any pair of them drifts:
 *
 * ```text
 * src/compat/dsh-version.ts   SUPPORTED_DSH_RELEASES   the allowlist
 * package.json                peerDependencies         what npm promises
 * package.json                devDependencies          what CI actually runs
 * node_modules                resolved versions        what is installed here
 * ```
 *
 * It deliberately re-reads the allowlist out of the TypeScript source rather
 * than importing it: this script must run before `pnpm build`, on a clean
 * checkout with no `lib/`, so it cannot depend on the bundle existing.
 *
 * @module scripts/check-dsh-compat
 */

import { existsSync, readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { readAutoReviewContract } from './lib/auto-review-development.mjs'

const require = createRequire(import.meta.url)
const REPO_ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const CONTRACT = join(REPO_ROOT, 'src', 'compat', 'dsh-version.ts')

const failures = []
const notes = []

/** Record a violation. */
function fail(message) {
  failures.push(message)
}

/**
 * Extract one `export const NAME = [...]` string array from the contract source.
 *
 * Parsing the source keeps the allowlist single-sourced without needing a
 * TypeScript loader in a pre-build step. The shapes accepted are exactly the
 * ones the contract file uses; anything else is a hard error rather than a
 * silent empty list, because an empty allowlist would make every check pass.
 * @param source - the contract file's text.
 * @param name - the exported binding to read.
 * @returns the string entries, in order.
 */
function readStringArray(source, name) {
  const match = new RegExp(String.raw`export const ${name} = \[([^\]]*)\]`, 'u').exec(source)
  if (match === null) throw new Error(`${name} is not declared as an array literal in src/compat/dsh-version.ts`)
  const entries = [...match[1].matchAll(/'([^']+)'/gu)].map(token => token[1])
  if (entries.length === 0) throw new Error(`${name} is empty in src/compat/dsh-version.ts`)
  return entries
}

const contractSource = readFileSync(CONTRACT, 'utf8')
const supported = readStringArray(contractSource, 'SUPPORTED_DSH_RELEASES')
const required = readStringArray(contractSource, 'REQUIRED_CORE_PACKAGES')
const optional = readStringArray(contractSource, 'OPTIONAL_CORE_PACKAGES')
const hostService = readStringArray(contractSource, 'HOST_SERVICE_PACKAGES')
const core = [...required, ...optional]

const manifest = JSON.parse(readFileSync(join(REPO_ROOT, 'package.json'), 'utf8'))
const peers = manifest.peerDependencies ?? {}
const devs = manifest.devDependencies ?? {}

console.log(`[compat] allowlist: ${supported.join(', ')}`)

// 1. Every dsh peer promises exactly the allowlist — no ranges, no extra
//    versions, nothing the code has not been run against.
const expectedRange = supported.join(' || ')
for (const [name, range] of Object.entries(peers)) {
  if (name !== '@deepseek-ai/dsh' && !name.startsWith('@deepseek-ai/dsh-')) continue
  if (range !== expectedRange) {
    fail(`peerDependencies["${name}"] is "${range}" but the allowlist is "${expectedRange}"`)
  }
}

// 2. Every required core package is declared as a peer at all. A package this
//    plugin subclasses but does not declare would be resolved from whatever the
//    host happens to hoist.
for (const name of required) {
  if (!(name in peers)) fail(`${name} is a required core package but is not declared in peerDependencies`)
}

// 3. No @deepseek-ai/* package may be a shipped dependency. Peers resolve to
//    the single copy the host carries; a shipped dep installs a SECOND copy
//    into the profile — `dsh-sandbox-local` pulls schemastery/node-addon-system
//    itself, so a private one only ever differs from the host's, and the
//    launcher reports profile-core-mixed / profile-core-copy (issue #30).
for (const field of ['dependencies', 'optionalDependencies']) {
  for (const name of Object.keys(manifest[field] ?? {})) {
    if (name.startsWith('@deepseek-ai/')) {
      fail(`package.json ${field} contains ${name}: DSH core packages belong in peerDependencies so they resolve through the host`)
    }
  }
}

// 4. The development pin is one of the allowlisted releases. CI runs this pin,
//    so a pin outside the allowlist means the list has no evidence behind it.
const pinned = new Set()
for (const [name, version] of Object.entries(devs)) {
  if (name !== '@deepseek-ai/dsh' && !name.startsWith('@deepseek-ai/dsh-')) continue
  pinned.add(version)
}
if (pinned.size > 1) {
  fail(`devDependencies pin several dsh releases (${[...pinned].sort().join(', ')}); pin exactly one`)
} else {
  const [pin] = [...pinned]
  if (pin === undefined) fail('devDependencies pin no dsh release at all')
  else if (!supported.includes(pin)) fail(`devDependencies pin ${pin}, which is not on the allowlist`)
  else notes.push(`development pin: ${pin}`)
}

// 5. koffi stays host-provided. As a shipped dependency it stops the first
//    `dsh plugin add` at pnpm's build approval and installs a second native
//    image beside the host's (SIGBUS on darwin-arm64); as an optional peer it
//    is never installed and the runtime resolves the host's copy instead. The
//    development pin keeps type-checking and tests on the host's release.
if (manifest.dependencies?.koffi !== undefined || manifest.optionalDependencies?.koffi !== undefined) {
  fail('package.json installs koffi: declare it as an optional peer (the host supplies it) and pin it in devDependencies')
}
if (peers.koffi !== '>=3.1.0 <4.0.0') {
  fail(`peerDependencies.koffi is "${peers.koffi ?? '(absent)'}" but must be ">=3.1.0 <4.0.0"`)
}
if (manifest.peerDependenciesMeta?.koffi?.optional !== true) {
  fail('peerDependenciesMeta.koffi.optional must be true: pnpm must never install the peer')
}
if (!/^3\.\d+\.\d+$/.test(devs.koffi ?? '')) {
  fail(`devDependencies.koffi is "${devs.koffi ?? '(absent)'}"; pin the 3.x release the development host carries`)
}
// The development pin must equal the copy the host tree itself resolves. When
// an upstream release changes its koffi pin, `upgrade-dsh` repoints the harness
// but not this package; without this check the dev pin could drift silently.
function packageVersionOf(entry) {
  let dir = dirname(entry)
  while (true) {
    const filename = join(dir, 'package.json')
    if (existsSync(filename)) return JSON.parse(readFileSync(filename, 'utf8')).version
    const parent = dirname(dir)
    if (parent === dir) return undefined
    dir = parent
  }
}
let hostKoffi
try {
  const hostRequire = createRequire(require.resolve('@deepseek-ai/dsh-fs-local/package.json'))
  hostKoffi = packageVersionOf(hostRequire.resolve('koffi'))
} catch {
  hostKoffi = undefined
}
if (hostKoffi === undefined) {
  fail('cannot resolve koffi from @deepseek-ai/dsh-fs-local (run pnpm install)')
} else if (hostKoffi !== devs.koffi) {
  fail(`devDependencies.koffi is "${devs.koffi ?? '(absent)'}" but the host tree resolves ${hostKoffi}; repoint the development pin to the host's koffi`)
}

// 6. What is actually installed here agrees with itself and with the allowlist.
//    This mirrors the runtime gate, so `pnpm compat:check` reproduces a boot
//    refusal without booting a harness.
const installed = new Map()
for (const name of core) {
  try {
    installed.set(name, require(`${name}/package.json`).version)
  } catch {
    try {
      if (!hostService.includes(name)) throw new Error('no host lookup')
      installed.set(name, createRequire(require.resolve('@deepseek-ai/dsh/package.json'))(`${name}/package.json`).version)
    } catch { installed.set(name, undefined) }
  }
}
for (const name of required) {
  if (installed.get(name) === undefined) fail(`${name} is required but not installed (run pnpm install)`)
}
const releases = [...new Set([...installed.values()].filter(version => version !== undefined))]
if (releases.length > 1) {
  fail(`the installed tree mixes dsh releases: ${releases.sort().join(', ')}`)
  for (const [name, version] of installed) console.log(`         ${name} ${version ?? '(not installed)'}`)
} else if (releases.length === 1) {
  const [release] = releases
  if (!supported.includes(release)) fail(`the installed tree is dsh ${release}, which is not on the allowlist`)
  else notes.push(`installed tree: ${release}`)
}

// The optional integration's joint contract is narrower than ordinary support:
// every release it names must belong to the ordinary allowlist, and the two
// frozen source baselines must not overlap.
const autoReviewContract = readFileSync(join(REPO_ROOT, 'src/compat', 'auto-review-contract.ts'), 'utf8')
let autoReview
try {
  autoReview = readAutoReviewContract(autoReviewContract)
} catch (error) {
  fail(`the Auto Review joint contract is unreadable: ${error instanceof Error ? error.message : String(error)}`)
}
if (autoReview !== undefined) {
  for (const release of autoReview.releases) {
    if (!supported.includes(release)) fail(`Auto Review release ${release} must belong to the ordinary allowlist`)
  }
  for (const [baseline, pin] of Object.entries(autoReview.compilePins)) {
    if (pin !== undefined && !autoReview.byBaseline[baseline].includes(pin)) fail(`Auto Review ${baseline} compile pin must be one of its releases`)
  }
  notes.push(`optional Auto Review releases: ${autoReview.releases.join(', ')}`)
}

for (const note of notes) console.log(`[compat] ${note}`)

if (failures.length > 0) {
  console.error('\n[compat] the DSH compatibility contract is violated:\n')
  for (const failure of failures) console.error(`  - ${failure}`)
  console.error('\nSee docs/decisions/ADR-0009-dsh-compat-contract.md for what each of these guards.\n')
  process.exit(1)
}

console.log('[compat] allowlist, peerDependencies, development pin and installed tree agree')
