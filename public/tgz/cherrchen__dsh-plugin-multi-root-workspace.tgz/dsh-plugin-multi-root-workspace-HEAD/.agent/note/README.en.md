# Agent Notes

中文：[README.md](./README.md)

This directory is where Coding Agents progressively deposit durable project knowledge.

## What Belongs Here

- Repository observations;
- Recurring implementation patterns;
- Compatibility notes;
- Upstream integration notes;
- Migration context;
- Important facts that Agents tend to rediscover repeatedly;
- Long-lived code archaeology results.

The core test:

> Only knowledge that future Agents are likely to need again, and that is costly to rediscover, belongs here.

## Current State

- [dsh-compat-contract.en.md](./dsh-compat-contract.en.md) — the DSH compatibility contract: the allowlist's single source of truth, how the `multiRootCompat` gate affects tests, `confine`'s shape-preserving sync/async adapter, the rules for `src/compat/`, how to use the upgrade lane, and two quiet traps already stepped in.
- [windows-deny-broker-packaged-child.en.md](./windows-deny-broker-packaged-child.en.md) — the B9 Windows deny broker's MSIX-alias trap: Store `pwsh.exe` launched through an execution alias gets a package-identity token, and `NtCompareTokens` fails closed; includes the minimal reproduction matrix and candidate fixes.

## What Does Not Belong Here

- Chat log backups;
- Scratchpads;
- Chain of Thought;
- Temporary TODOs;
- Per-task journals.

## Bilingual Requirement

Every formal document in this directory must be maintained bilingually:

```text
<name>.md       canonical Chinese version
<name>.en.md    English companion
```

For example, a future document might be:

```text
upstream-integration.md
upstream-integration.en.md
```

When updating either version, check whether the other needs to be synchronized; in case of conflict, the Chinese version prevails.

Do not create empty `.en.md` files automatically; create both files only when a document is established as formal knowledge.

## Naming Convention

Use lowercase kebab-case, for example:

```text
<topic>.md
```
