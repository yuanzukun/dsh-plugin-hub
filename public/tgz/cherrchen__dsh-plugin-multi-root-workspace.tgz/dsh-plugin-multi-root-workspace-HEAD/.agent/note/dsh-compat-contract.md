# DSH 兼容性契约：Agent 需要先知道的事

English: [dsh-compat-contract.en.md](./dsh-compat-contract.en.md)

这份笔记记录的是**改动本仓库之前必须知道、否则很容易踩坑**的兼容性机制。决策理由在 [ADR-0009](../../docs/decisions/ADR-0009-dsh-compat-contract.md)，用户侧排查在 [故障排查条目](../../docs/troubleshooting/unsupported-dsh-release.md)。这里只写"作为 Agent 你会撞到什么"。

## 1. 支持矩阵的唯一真源

```text
src/compat/dsh-version.ts  →  SUPPORTED_DSH_RELEASES
```

它是**精确版本数组**，不是 semver 范围，也是 DSH 支持矩阵唯一维护版本列表的地方。`package.json` 的 `peerDependencies` 是这组精确版本的并集，`devDependencies` 里的 DSH 开发 pin 是 allowlist 中的一项，已安装树实际解析到的版本也必须落在它里面。**本笔记不再抄写版本字面量**：需要当前矩阵时直接读 `src/compat/dsh-version.ts` 与 `package.json`，或用 `pnpm compat:check` 校验。

改它的时候，下面四处必须同时一致，否则 `pnpm compat:check` 失败：

```text
src/compat/dsh-version.ts   SUPPORTED_DSH_RELEASES   唯一 allowlist
package.json                peerDependencies          逐项对应 allowlist 的精确版本并集
package.json                devDependencies           allowlist 中的某一项（开发 pin）
node_modules                实际解析到的版本          allowlist 中的某一项
```

`scripts/check-dsh-compat.mjs` 是**文本读取** TypeScript 源码里的这个数组，不是 import。所以：**不要把它改成非 `export const NAME = [...]` 字面量形式**（比如从别处拼出来、或者加类型断言以外的表达式），否则静态检查会直接抛错。原因是这个检查必须能在 `pnpm build` 之前、在没有 `lib/` 的干净 checkout 上跑。

非 `dsh-*` 的共享上游包（`cordis`、`schemastery`、`node-addon-system`）同样**只能是 peer**：它们是宿主树自带的单例——`dsh-sandbox-local` 在每个受支持版本上都直接依赖后两者，插件私带一份就是第二份。放进 `dependencies` 的实际后果（issue #30）：profile 里装出 schemastery `3.18.5` 对宿主 `3.18.6-alpha.1`、cosmokit `1.8.6` 对 `1.8.7-alpha.1` 和一份同版本的 node-addon-system，启动器依赖自检报 `profile-core-mixed` / `profile-core-copy`。机制要记牢：`^3.18.2` 这类范围**不匹配** prerelease（`3.18.6-alpha.1` 不满足它），所以 peer 范围必须像 cordis peer 那样"稳定线用范围 + alpha 线逐个具名"（`>=3.18.2 <4.0.0 || 3.18.5-alpha.1 || 3.18.5-alpha.2 || 3.18.6-alpha.1 || 3.18.6-alpha.2`），升版纳入新 alpha 线时同步扩并集；`devDependencies` 钉开发 pin 宿主自带的精确版本，由 `upgrade-dsh.mjs` 随 ecosystemPins 重指。`compat:check` 与 `tests/compat.spec.ts` 硬性检查 `dependencies` / `optionalDependencies` 里没有任何 `@deepseek-ai/*` 名字。

同一单例规则对**原生镜像**也成立，且 `koffi` 自 `0.1.21` 起**不再是**生产依赖：它是 optional peer，包内不携带副本。pnpm 不安装可选 peer，首次 `dsh plugin add` 因此不再停在 koffi 的构建授权。运行时全部 FFI 调用点统一走 `src/compat/koffi.ts` 的 `loadHostKoffi()`；需要同步读取 Git 元数据的 Worktree 使用同一模块的 `loadHostKoffiSync()`。两者按同一候选链解析宿主副本：`DSH_KOFFI_PATH` → 必需 peer `dsh-fs-local` 锚点（每个受支持版本都携带 koffi）→ 宿主入口 `process.argv[1]` → DSH Desktop 的 `app.asar` / `app.asar.unpacked` 运行时目录；**没有包内回退**，找不到即明确报错。这不是可选项：profile 里再装一份私有 koffi，就是同进程第二个 `koffi.node` 镜像，在 darwin-arm64 指针校验（PAC）下直接 SIGBUS，进程无声退出（2026-11-01 packed smoke 实锤）。`tests/compat.spec.ts` 扫描 `src/` 禁止 `compat/koffi.ts` 之外出现裸 `import('koffi')`，并断言 koffi 只以 optional peer + 开发 pin 出现。git 来源安装仍需为插件自身的 `prepare` 授权。

## 2. 你写的测试可能因为门禁而失败——这是对的

`multi-root-compat` 是 patch 第一行，以下**宽授权行** inject 它：

```text
multi-root-providers
multi-root-registry
multi-root-instructions
multi-root-lsp
multi-root-workspace-files
multi-root-process-fence
```

cordis 不会启动 injected service 缺失的行。所以在测试里 mount 上述任何行（或经它们间接受门控的行，如注入 `multiRootRegistry` 的 `multi-root-command`）之前，必须先：

```ts
import { mountCompat } from './support/compat.ts'

await mountCompat(ctx)
```

否则 `ctx.get('multiRootRegistry')` 之类是 `undefined`。这不是 bug，是门禁在工作（`tests/compat.spec.ts` 里有专门断言）。

**两个 provider 行（`multi-root-fs` / `multi-root-sandbox`）刻意不 inject 门禁**：它们的放宽由 scope 驱动，而被门禁的 registry 永远不会在被拒安装上填充 scope，所以它们在门禁失败时退化为上游 provider。这必须保持：patch 已经无条件禁用了上游 `fs-sandbox` / `sandbox`，provider 一缺席，`ctx.fs` / `ctx.sandbox` 消失 → `ctx.shell`（inject `sandbox`）起不来 → `permissionPresets`（inject `shell`）起不来 → 整个 profile 瘫痪（`permissionPresets/catalog` 报 service-unavailable）。门禁失败的正确形状是"插件功能缺席、profile 完好"，从来不是"profile 死"。

`mountCompat` 挂载的是**真实的** compat 行，含门禁策略。所以整个单元套件在一个不在 allowlist 上的版本上会直接失败——这是刻意的，见下面第 5 条。

## 3. `confine` 在不同版本上是同步/异步的

```text
0.1.5-rc.2     confine(argv, policy): ConfinedArgv
0.1.6-alpha.1  confine(argv, policy, signal?): Promise<ConfinedArgv>
0.1.6-alpha.2  confine 形状与 0.1.6-alpha.1 相同（2026-09-22 实测）。会话目录的形状不同，见下一节。
0.1.7-alpha.1  confine 形状与 0.1.6-alpha.1 相同（2026-09-22 实测；这一版别的形状变了，见第 4 条）
0.1.7-alpha.2  与 0.1.7-alpha.1 相同（2026-09-24 实测）
0.1.7-rc.1     与 0.1.7-alpha.1 相同（2026-09-24 实测）。这一版新增的是安装期 peer 门禁，见第 4 条末尾
0.1.7-rc.2     与 0.1.7-rc.1 相同（2026-09-25 对照 tag 实测）。cordis 仍是 `~4.0.4`
```

**不要**在 `src/sandbox.ts` 里手写签名去迁就某一个版本。统一走 `src/compat/sandbox-confine.ts` 的 `widenConfined()`，它**保形**：上游同步就同步返回，上游返回 promise 就返回 promise。

绝不要"统一包成 promise"。在 `0.1.5-rc.2` 上那会把 `ctx.sandbox.confine()` 对组合里每一个调用方（bash executor、PTY backend）都变成 thenable，等于插件自己引入一次破坏性变更。

测试和 smoke 里读结果时：

- 单元测试用 `tests/support/confine.ts` 的 `confined(provider, argv, policy)`；
- smoke 脚本一律 `await ctx.sandbox.confine(...)`。

**这是一个安静的坑**：`await` 一个普通值是 no-op，但直接读 promise 的 `.argv` 会得到 `undefined`，报错形如 `Cannot read properties of undefined (reading 'some')`，看起来完全不像版本问题。

## 4. 上游改过的 API 只能在 `src/compat/` 里分支，且用结构探测

业务代码不出现任何版本判断。目前的适配器：

| 文件 | 吸收的差异 |
| --- | --- |
| `src/compat/sandbox-confine.ts` | `confine` 的同步/异步与 arity |
| `src/compat/agent-instructions.ts` | renderer 改名：`renderWorkspaceContext`（0.1.5）→ `renderAgentInstructions`（0.1.6，0.1.7 未再改） |
| `src/compat/client-session.ts` | 当前会话：`list.current`（0.1.5 / 0.1.6-alpha.1）→ 目录行 `retainedBy.mainView > 0`（0.1.6-alpha.2 与 0.1.7-alpha.1 至 0.1.7-rc.2；0.1.7 挪走了别的目录字段，主视图谓词没变） |
| `src/compat/llm-message.ts` | session format 3 及更早投 `{ kind: 'plugin', plugin, form: 'instructions' }`；format 4（`0.1.7` 的 `SESSION_FORMAT_VERSION`）拒绝 `kind: 'plugin'`，改投 `{ kind: 'multi-root-workspace', plugin, form: 'instructions' }`。探针是 session 包导出的格式常量，**不是** renderer 名字——0.1.6 已经改名却仍接受 `plugin`。不要用 `agent-instructions`：上游把那个 kind 的 `changes` 当自己的协调权威 |
| `src/compat/tool-result.ts` | 失败位：0.1.5/0.1.6 在 `content[0].isError`，0.1.7 在消息自身的 `isError`。`event.data.error` 两边都还在 |
| `src/compat/client-icons.ts` | 面板图标：0.1.5/0.1.6 是像素名（`IconFolderClose16`），0.1.7 是线宽名。上游 UI 用的是 Regular，不是 Medium。先取像素名，没有再取 Regular。纯装饰字形走 `maybeIcon` 软探测（缺失降级为无图标，不抛错），带必需 fallback 的可选字形走 `selectIconOr`——权限字形 `IconWorkspaceWrite`/`IconReadOnly` 仅 0.1.7+ 存在 |
| `src/compat/process-entrypoints.ts` | 进程栅栏包装哪些公开入口：`ctx.shell` 上 `execute`/`run`/`start` 的存在性探测（`start` 存在于 0.1.6 及更早），`ctx.ptcRuntime` 只认公开 `run`（具体实现的 `execute` 是私有 helper，不作跨包接缝） |
| `scripts/lib/profile-boot.mjs` | `healProfilesModuleFallback` 是函数就调用它；否则 `createRuntimeResolution`，并在 `boot` 的 prepare 里 `hostCtx.plugin(PluginPackages, { resolution })`。0.1.7 不再导出 heal |
| `scripts/lib/shell-exec.mjs` | `shell.run` 存在就用它；否则 `shell.execute(spec)` 再 `execution.result()`。0.1.7 的 `SandboxBashExecutor` 改了名从 run 到 execute |

一律用**结构探测**（是否 thenable、导出哪个名字、快照有没有 `current`），不要比较版本号。上游是 pre-stable，同一版本内也会改形状；结构探测能应付，版本比较不能。

`0.1.7-alpha.2`、`0.1.7-rc.1` 与 `0.1.7-rc.2` 相对 `0.1.7-alpha.1` 没有改上面这张表里的形状（2026-09-24 对照 `alpha.1` / `alpha.2` / `rc.1`；2026-09-25 对照 `rc.1` → `rc.2`）。`rc.1` 新增的是**安装期**门禁，不在 `src/compat/`：`dsh plugin add` 与 `loadProfile` 用 `semver.satisfies(runtime, peerRange, { includePrerelease: true })` 检查每一个 `@deepseek-ai/dsh*` peer，不满足就拒绝安装或跳过 bundle。因此把一个 `0.1.7-rc.1` 及以后的版本放进 allowlist 时，`peerDependencies` 必须在同一改动里带上那个精确版本，否则 smoke 的 `dsh plugin add` 会在本插件的运行时门禁之前就失败。`DSH_MULTI_ROOT_COMPAT=warn` 放宽不了这一关。

**这是一个安静的坑**：`0.1.6-alpha.2` 的 host 矩阵（`confine`、instruction renderer、journey Messages 端点）与 alpha.1 相同，所以当时按"适配层无改动"纳入 allowlist。客户端 Session Controller 却在 `6830e1460d` 把 `SessionListState.current` 删掉了，导航改由主视图 `retain(..., { source: 'mainView' })` 持有。面板仍读 `list.current` 时，已打开的对话会显示「当前没有活动会话」，并且**不向 host 发请求**。

探测顺序：非空的 `current` 优先（旧形状），否则取第一条 `retainedBy.mainView` 为正数的目录行。目录有行但没有一行被主视图持有时返回 `undefined`——**绝不要**回退 `ids[0]`，那会把操作打到操作者没在看的会话。`getSnapshot` 必须按方法调用，抽出来再调会丢掉 store 的 `this`。

`agent-instructions` 是**可选 peer**：最小组合里可能既没有它也没有 agent。`instructionsApi()` 在包不存在时返回 `undefined`（贡献为空），但包存在却两个 renderer 名字都没有时**抛错**——那是需要修适配器的兼容性破坏，不是可选接缝。

`@deepseek-ai/dsh-llm` **同样是可选 peer，且只能按需加载**：barrel（`src/index.ts`）正是 carrier loader 行挂载的模块，它的加载期依赖集合必须等于必需包集合，所以任何静态值导入都会让一个根本不构造消息的最小组合加载失败。消息构造统一走 `src/compat/llm-message.ts` 的 `createInstructionMessage()`，它在真正要构造消息时才 `await import('@deepseek-ai/dsh-llm')`。`tests/optional-peers.spec.ts` 钉住了这一点：加载 `src/index.ts` 与 `src/instructions.ts` 时该包不会被 resolve。

`instructionsApi()` 还要把**包不存在**与**包在但求值失败**分开：先用 `isPackageInstalled()` 单独探测安装情况（`createRequire(import.meta.url).resolve`，与 `readInstalledVersion` 同一模式），只有 `MODULE_NOT_FOUND` / `ERR_MODULE_NOT_FOUND` 算"不存在"；其余失败（例如传递依赖缺失导致 `import()` 抛错）必须向上抛，绝不缓存成 `undefined`——那会让整个进程静默停止投递附加根指令。

## 5. `DSH_MULTI_ROOT_COMPAT=warn` 不是给你用的调试开关

它只为升级车道存在：让完整矩阵能在一个还不在 allowlist 上的版本上跑起来。

它只放宽**一个**判定：`unsupported`（版本一致、只是还没被 allowlist 点名的树——升级车道唯一会探测的形状）。`mixed` 与 `incomplete` 在 `enforce` 和 `warn` 下**都**拒绝。

如果你在本地遇到门禁拒绝，**不要**用它绕过去继续开发。正确做法是确认宿主/`node_modules` 是否真的在 allowlist 上（`pnpm compat:check`）。只有在你确实在做"提升一个新上游版本"这件事时才用它，流程写在[故障排查条目](../../docs/troubleshooting/unsupported-dsh-release.md)。

`upgrade.yml` 设置它，CI 主车道不设置，`tests/workflows.spec.ts` 钉住了这条分界。

## 6. 升级车道不会自动扩大支持矩阵

`upgrade.yml` 按周跑，权限是 `contents: read`，不提交不推送，也不碰 `SUPPORTED_DSH_RELEASES`。绿灯是**证据**，不是授权。提升版本是人工动作。

`compat:check` **不**在升级车道里跑：候选版本按设计就不在 allowlist 上。如果你往那个 workflow 里加 `run: pnpm compat:check`，`tests/workflows.spec.ts` 会失败。

升级/探测用：

```bash
node scripts/upgrade-dsh.mjs 0.1.7-alpha.1          # 重指 pin
node scripts/upgrade-dsh.mjs --latest-prerelease     # 指向最新 pre-release
node scripts/upgrade-dsh.mjs --print-latest-prerelease
node scripts/upgrade-dsh.mjs --print-installed       # 实际解析到的版本
pnpm install --no-frozen-lockfile --config.minimumReleaseAge=0
git checkout -- package.json pnpm-workspace.yaml pnpm-lock.yaml   # 回退
pnpm install --frozen-lockfile                                     # node_modules 也回基线
```

安装候选版本时**必须**加 `--config.minimumReleaseAge=0`。否则 pnpm 会因为 release-age 门禁把整棵新树往 `pnpm-workspace.yaml` 的 `minimumReleaseAgeExclude` 里追加两百多行——那是一次性探测不该留下的东西。

`0.1.7-alpha.1` 的 `dsh` 依赖 cordis `^4.0.3`；`0.1.7-alpha.2`、`0.1.7-rc.1` 与 `0.1.7-rc.2` 依赖 `~4.0.4`。`upgrade-dsh.mjs` 会把 `@deepseek-ai/cordis` 的开发 pin 和 `pnpm-workspace.yaml` 里那一行 release-age 改到这个范围中的精确版本。不要在同一棵树里留下 `4.0.2`：pnpm 会拆出两份 `@deepseek-ai/dsh-tools`，agent-loop 持有的 `TOOL_RUNTIME_SCHEDULER` 是模块局部 `Symbol`，对不上另一份构造的 ToolRuntime，工具调用在第一步抛 `Cannot read properties of undefined (reading 'prepare')`。回基线时 cordis 随开发 pin 回到 `4.0.2`。

两个只在本地咬人的坑（CI 每次都是干净 checkout，碰不到）：

- **那句 `git checkout` 会把三个文件整体退回 HEAD**，连同你对它们的未提交修改。在脏的 manifest 上跑探测之前先提交或 stash。
- 候选版本装上之后，`pnpm <script>` 的**依赖自检**会因为同一个 release-age 门禁判定"依赖不同步"并触发一次重装，而那次重装同样会失败，把 `node_modules` 撕成半截（`.bin` 消失、`.package-map.json` 只剩一条）。这时 `pnpm install` 会说 "Already up to date" 却修不好，唯一出路是 `rm -rf node_modules` 重装。要避免它，探测期间绕开 pnpm 的脚本包装，直接用 `PATH="$PWD/node_modules/.bin:$PATH"` 跑 `oxlint` / `tsc` / `vitest` / `node scripts/*.mjs`。

**混树坑（2026-10-28 踩实）**：重指旧版本时，committed lockfile 里已有的 alpha 行 cordis 生态包会被 pnpm 优先沿用——`dsh-app-boot` 的 `cordis-plugin-loader` / `-group` / `-include` peer 范围同时接纳稳定版与 alpha，`rc.3` 树上的 `0.2.1` 运行时曾跑到 `1.0.7-alpha.1` 的 loader 上，Settings 的 volatile 写够不到 live Config（`tests/skills-settings.spec.ts` 的 enabled 断言静默留在 `true`）。`upgrade-dsh.mjs` 现在除了 DSH/cordis pin，还会从目标版本自身的 `dsh` / `dsh-app-boot` / `cordis` / `dsh-sandbox-local` manifest 推导 `cordis-plugin-*`、`schemastery`、`cosmokit`、`node-addon-system` 的精确版本，写进同一个临时 `overrides` 块，并同步重指这些包留在 `devDependencies` 里的开发 pin；跨预发行线回退旧版本后，务必确认解析出的 loader/group/include 是该版本自带的稳定版再下结论。

## 7. journey smoke 的模型端点同时说两套 wire 协议

`0.1.6-alpha.1` 把默认 LLM 协议从 chat-completions 换成了 Messages：

```text
0.1.5-rc.2     POST {base}/chat/completions    choices[].delta，finish_reason
0.1.6-alpha.1  POST {base}/v1/messages         message_start / content_block_* / message_delta / message_stop
0.1.6-alpha.2  与 0.1.6-alpha.1 相同（journey 55/55，端点未改）
0.1.7-alpha.1  与 0.1.6-alpha.1 相同（journey 55/55，仍是 `/v1/messages`）
0.1.7-alpha.2  与 0.1.7-alpha.1 相同（journey 55/55）
0.1.7-rc.1     与 0.1.7-alpha.1 相同（journey 55/55）
0.1.7-rc.2     与 0.1.7-rc.1 相同（`/v1/messages` 未改；未声明 `toolUpdate` 的路由会剥掉 developer 消息）
```

这个变化不经过插件代码，但会打断 `scripts/smoke-journey.mjs` 的脚本化端点。它现在**按请求路径**选择应答协议，两个构造函数分别是 `chatCompletionFrames()` 与 `messagesFrames()`。

同一处还有一个曾经踩过的坑：**不要用"请求体里是否含 title 提示词"来判断哪个请求是 agent step**。某些版本会把整个 session log 随每个请求一起发送，于是所有请求都被判成 title、agent 一步都不跑、而 smoke 报出的却是二十多条"模型没看到附加根"之类的下游失败。现在的判据是**请求是否提供 tools**。

调试模型看到了什么：

```bash
DSH_SMOKE_KEEP=1 pnpm smoke:journey
# 结束后读 .dsh-smoke/journey-<pid>/model-requests.json
```

## 8. 一条命令跑完整矩阵

```bash
pnpm verify:all   # lint → typecheck → build → test → kernel:probe → smoke
```

它**故意不含** `compat:check`，因为升级车道要在未列入的版本上跑它。CI 主车道单独跑 `compat:check`（在 lint 之前）。

## 9. DSH 0.2 与新的开发基线

写本节时开发 pin 是 `0.2.0-rc.2`，cordis 是 `4.0.4`（当前基线见 `package.json` 的 `devDependencies`；受支持版本列表见 `src/compat/dsh-version.ts`）。回到开发基线不再表示回到 `0.1.5-rc.2` / `4.0.2`；前文的旧版探测记录是历史事实。恢复探测前保存的 manifest / workspace / lockfile，并重装安装树，绝不把未提交的支持声明退回 HEAD。

`0.2.0-rc.1` / `rc.2` 保留了现有适配器的接缝。0.2 的 agent-loop 异常恢复会在关闭 step 前补保守的失败 `tool/result`：`message.isError: true`、纯文本 content，并带 `data.error`。它绝不能算成功文件 touch；`tests/instructions.spec.ts` 同时钉住旧 content block、新 message 与恢复事件三种失败形状。Windows 新增 ACL diagnosis skill 由继承的上游 provider 自动软注册，本插件仍不承诺 Windows 内核多根授权。风险与各版验证证据见[路线图记录](../../docs/plans/active/2026-09-12-multi-root-workspace.md#dsh-02-兼容提升2026-09-30)。

CI 用 `scripts/list-dsh-releases.mjs` 从 allowlist 直接读取版本轴，所有支持版本都跑所有启用的 OS，主车道始终 enforce。`pnpm-workspace.yaml` 对开发版本的传递 DSH 包与 LibreOffice host tooling 逐项使用精确发布年龄豁免：pnpm 11 不接受带版本的包名通配模式，而且运行脚本前也会校验整棵锁文件。安装候选仍使用 `--config.minimumReleaseAge=0`，临时 pin 与临时豁免必须恢复。

候选重指脚本还从这些 DSH 条目派生一个 workspace-only 的 DSH / cordis `overrides` 块，确保旧版的宽预发布范围不会在 runtime resolution 下变成混装；已有自定义 overrides 时脚本拒绝覆盖。这个块是探测产物，不随插件发布，探测结束恢复保存的 workspace 文件。

Windows 的 Node 不能直接 `execFileSync('npm')` 启动 `npm.cmd`，旧版矩阵会在重指前报 `spawnSync npm ENOENT`。升级脚本统一走 `scripts/lib/npm-cli.mjs`：Windows 用当前 Node 执行其安装目录的 `node_modules/npm/bin/npm-cli.js`，POSIX 继续直接执行 npm；不拼 shell 命令，带空格的路径与参数边界由回归测试覆盖。

## 10. B1–B3 的新接缝

LSP / workspace-files 只包装公开方法，卸载必须恢复原属性描述符；不要比较 Cordis 代理函数的引用。旧版 `changes(scope, signal)` 与新版 `changes(scope, path, signal)` 由 `src/compat/workspace-files.ts` 按 arity 适配。读面 `stat`/`read`/`readBytes` 同样被包装——上游对它们不做 workspace 围限，边界由 `routeWorkspacePath` + `registry.list()` 的「在册未授权」词法检查补齐（拒绝用 `workspace-file/outside-workspace`）；`readBytes` 第三参跨版本形态不同（`WorkspaceByteRange` ↔ `WorkspaceByteReadOptions`），wrapper 保留 range 与其余选项，只在路由时改写 `baseFile`，关联尾路径语义见 [ADR-0011 的读面修订](../../docs/decisions/ADR-0011-multi-root-workspace-consumers.md#修订面板-files--readfile-端点下线2026-10-12amendment)。Windows 非空 scope 的 runner 必须用整个根集合的 SID，不能把主根 SID 授予附加根，否则移除后仍可写。可选 peer 均纳入混装检查，carrier barrel 不得静态加载这些可选包。混装检查的"证词"按谁真正加载解析到的副本来分（`src/compat/dsh-version.ts`）：`RUNTIME_OPTIONAL_PACKAGES` 是本插件自己动态 `import()` 的（`dsh-agent-instructions` / `dsh-llm` / `dsh-session` / `dsh-typert-protocol`），私有副本真的会执行，任何位置的命中都作证；`HOST_SERVICE_PACKAGES` 只作为宿主挂载的服务或类型被消费，落在**本插件目录内**的副本永远不可能执行——`link:` 安装的检出会把 `dsh-lsp` / `dsh-lsp-stdio` / `dsh-working-directory` 解析到自己的 devDependencies，不剔除就会把一个版本统一的宿主幻影判成 `mixed`。宿主锚点回退（经 `@deepseek-ai/dsh` 的 package.json）只对这些宿主服务包开放，且同样受插件根边界约束。还有第三类 `RUNNER_ANCHORED_PACKAGES`：`dsh-sandbox-windows-acl` 由独立 runner 进程经 `profile.upstreamRunner` 自引用加载，执行副本是已安装 `dsh-sandbox-local` 树里的兄弟副本——只从该锚点取证，锚点解析不到即缺席（runner 同样加载不到），命中一律作证（锚点即执行链，含插件根内命中）；自解析与 dsh 宿主锚点都不反映这里的执行情况。新增可选包时必须按"谁会加载这份副本、经哪个锚点"归入其一，不要混进另一个列表。完整决策见 [ADR-0011](../../docs/decisions/ADR-0011-multi-root-workspace-consumers.md)，各平台验证状态只见[路线账本](../../docs/plans/active/2026-09-12-multi-root-workspace.md#b1b3第二期-p12026-10-02)。

## 11. DSH 0.2.1 目录语义

当前开发基线由 `package.json` 的 `devDependencies` 定义（DSH 与 cordis 的开发 pin 都在那里，由 `upgrade-dsh.mjs` 重指），受支持版本列表与已安装树的约束由 `src/compat/dsh-version.ts` 与 `pnpm compat:check` 校验；本笔记不抄写基线版本号。Registry 身份和 grants 始终绑定不可变的 Session 原始项目；effective cwd 使用上游 workingDirectory，不能按共享目录反查会话。LSP 从工具 dispatch 携带 Session，instructions 优先捕获成功 fs observation 的实际路径。精确候选与原生平台执行证据只见[路线账本](../../docs/plans/active/2026-09-12-multi-root-workspace.md)，目录与进程快照设计见 [ADR-0012](../../docs/decisions/ADR-0012-session-origin-and-effective-cwd.md)，上游差异见[接口审查](../../docs/reference/dsh-0.2.1-migration.md)。

升级脚本接受单一 Cordis prerelease 版本，仍输出精确 pin。新的安装期 peer gate 需要在隔离候选 smoke profile 使用精确 allow-version 豁免；warn 模式下豁免在第一次 `add` 前授予（构建审批恢复路径内部的 remove+add 同样有版本 gate），只用于升级车道，正式矩阵和生产仍 enforce。当前 package 为 `0.1.6` 且 `v0.1.6` tag 已存在，本迁移不创建 release。

`0.2.1-alpha.3` 起 `dsh-storage-domain` 把 `zod` 从 `^4.4.3` 钉死为 `4.4.3`，与本包浮动的 `^4.6.x` 分裂成两个解析副本；zod v4 按构建 minor 打类型标记，`domainTable` 声明的 `ZodType` 只认它自己那一份。域 schema（`src/registry.ts` 的 `persistedRoot` / `persistedPrimaryRoot`）必须由 `src/compat/storage-zod.ts` 构建——它从 storage-domain 的解析路径取 zod，值与边界类型永远同源。不许回退到包级 `import { z } from 'zod'` 构建域 schema，也不许把本包 zod pin 到上游版本（旧支持版本的 `^4.4.3` 会把分裂移到另一侧）。本包 `zod` 仍用于 `src/contract.ts` 的面板 wire schema——那是本插件自有边界，与上游类型无关。`alpha.4` 起上游安装门禁优先 `engines.dsh`、回退 `peerDependencies`；本插件仍以 peers 为唯一版本契约，不引入第二处版本列表。

## 12. 浏览器侧的上游 DOM 钩子（升版目检）

`src/client/` 里有一批**不是槽位契约**的上游结构依赖，结构探测管不到它们，只能靠目检：

| 依赖 | 消费方 | 失效表现 |
| --- | --- | --- |
| `Menu` 原语的 anchor 包装 `<span>`（`className` 落在它上面，是 header 槽 occupant 内的 flex item） | `RootSwitcher` 的收缩钩子：`styles.ts` 的 `.mrfw-rootSwitchAnchor`（`flex: 0 1 auto; min-width: 0`）。收缩必须写在参与外层 flex 的包装上，写在内层触发器按钮上无效 | `className` 不再落到这个包装上 → 触发器被内容 min-content（nowrap 根名）钉死，窄栏/双栏/浮动小窗下溢出并压住 reload/搜索/open-in-app（ADR-0046 的旧缺陷回归）；包装不再是 flex item → 收缩语义整体失效 |
| `FilesBody` 扁平 flex header + flex 项上的 `data-files-root` / `data-files-path` / `data-files-reload` | `styles.ts` 的 `:has()` 规则（`.mrfw-rootSwitcher` 接管路径标签位置、隐藏 `[data-files-path]`——选择器自带 `PathLabel`（`.mrfw-switcherPath`）显示选中根完整路径、自带 `.mrfw-switcherReload` 在附加根态顶替原生 reload；`[data-root-kind="additional"]` 时隐藏 `[data-files-body]` 与 `[data-files-reload]`） | 规则停止匹配：上游路径标签恢复显示、与选择器自带 PathLabel 并存（路径出现两次），选择器退回槽内默认位序，仅剩菜单可用——静默退化，功能不坏 |
| `closest('[data-files-root]')` 命中本 pane | `RootSwitcher.tsx` 的 portal 目标查找 | 找不到祖先即不渲染复刻树，切附加根只改菜单态；原生布局不受影响 |
| dockkit tabHost 上的 `data-dockkit-content`（值为 tab id） | `RootSwitcher.tsx` 的复刻树 store bucket 键（scroll/展开态记忆） | 属性缺席时退回生成 id——功能不受影响，只是滚动/展开记忆跨接管不保留；属性若改名或挪位，bucket 键与原生 tab 失配 |
| `ui-open-in-app` 分离按钮锚点上的 `data-open-target="directory"` | 附加根态的隐藏规则（`:not(.mrfw-openSplit)` 保住复刻按钮自身） | 属性改名/移除 → 原生按钮在附加根态露出、点击仍开主根（旧 bug 回归）；选择器失效只影响隐藏，不碰功能 |
| `sidebar.right.tab.document.actions` 槽（0.2.2-alpha.3 起 `documentpreview` 声明） | `navigator.tsx` 预览导航接管的挂载位，owner `absolutePath` 是被预览文件的宿主路径 | 宿主不声明该槽 → `slots.inject` 不注册，预览导航全程原生（该导航器本来就不存在）；槽在但 owner 字段改名 → occupant 拿不到路径、零渲染，原生树不受影响 |
| 预览根上的 `data-textpreview-url`（tab contentId）与内容行上的 `data-textpreview-content` | `navigator.tsx` 的预览定位、跨会话校验（`parseFileAddress` 必须解析出本会话的 session-scope 地址）与 aside 观察范围 | 钩子缺席/改名 → 找不到预览或会话校验不通过，永不接管——原生导航树零影响 |
| `aside[data-files-navigator]`（值为 dockkit pane id）与其内 `[data-files-body]` | `navigator.tsx` 的接管目标与 pane 记账键；`styles.ts` 的 `aside[data-mrfw-navigator] > [data-files-body]` 隐藏规则 | aside 不出现 → 永不接管（该导航器未开）；属性值不再是 pane id → bucket/快照改键、跨 `replaceTab` 的展开/滚动记忆丢失但功能不坏 |
| dockkit 的 pane 载体：非空 pane 的 id 骑在其**选中 tab 的 host**（`data-dockkit-pane`）上、空 pane 由 `TabPanel` 携带、浮动 pane 用 `data-dockkit-float`——pane 本体**没有**稳定元素 | `navigator.tsx` 的 pane 死亡观察是查询式的（文档中仍有携带该 id 的元素即存活），death-watch 独立于 takeover 生命周期、cleanup 永远赢不了它的竞速 | 载体属性的拼写/归属改变 → 存活判定失真：误报死会让快照提前丢弃（记忆降级、功能不坏）；误报活则快照留到会话结束 |
| rc.2 起的导航器搜索节点：原生输入框 `[data-files-search]`、状态行 `[data-files-search-status]`、设置浮层 `[data-files-search-settings]`、页头开关 `[data-files-search-toggle]`；插件 pane 根 `[data-mrfw-files-pane]` 与输入 `[data-mrfw-files-search]` | `styles.ts` 的隐藏规则（预览接管期隐藏原生栏/状态行/遗留设置；附加根 Files 页隐藏原生页头开关）与 `pane.tsx` 的搜索面 | 原生精确钩子改名 → 原生栏在接管期重新露出、与插件 pane 重叠（视觉错乱、功能不坏）；`data-mrfw-files-pane` 丢失 → 守卫与测试锚点失效，重构时可能误伤插件自己的 pane；插件 pane 的同名 `data-files-search-status/settings` 位于 pane 后代，direct-child 规则不会命中 |

**收缩优先级（ADR-0046）**：`RootSwitcher` 占据的这条 header 是扁平 flex 行，窄宽下按固定顺序让位——固定控件（reload / 搜索 / open-in-app，主根态来自 header、附加根态来自 switcher 内部）永不移动、永不收缩；完整路径以零 flex basis 先让到 0（换成 max-content basis 会让根名在路径还有余量时先被省略）；根名随后由 label 的 `text-overflow: ellipsis` 收缩；最后触发器的 `overflow: hidden` 在图标都放不下时裁剪它们。任何一层重排都可能让两个控件重新互相覆盖，三条规则由 `tests/client-styles.spec.ts` 与 `tests/client-switcher.spec.tsx` 钉住。

⚠️ `data-files-path` 有**双重含义**：表头 `PathLabel` 携带裸值（`"true"`），而**每个树行**（`data-files-entry` 的 `li`）也携带它、值是该行自己的绝对路径。任何想命中表头标签的选择器都必须写 `[data-files-path]:not([data-files-entry])`——不带限定符的 `display:none`/`order` 会作用到整棵原生树（曾真实发生：主根树区全空）。其余三个钩子（`root`/`body`/`reload`）各只出现一次。

提升上游版本时（升级车道跑完、人工验收阶段）必须目检三态：无附加根时 Files 页签是原生观感；选中一个附加根时树区换成逐字节复刻的原生 Files 树（行高/图标/缩进/空态/截断/失败行应与原生逐项一致）、原生 reload 由 header 内的同款 `.mrfw-switcherReload` 顶替、原生 open-in-app 按钮由复刻按钮顶替（点开 chevron 菜单应与原生同款）；切回主根时原生树、reload 与 open-in-app 完整还原。预览侧 Folder 导航器另有四态：预览附加根文件时打开 Folder → 树以该附加根为根、祖先已展开、当前文件高亮在视口内、从树里打开文件替换当前预览 tab 且树仍挂在新 tab 的 pane 上；预览主根文件时原生导航树原样（根=cwd）；折叠再展开 Folder 时展开/滚动位置回到离开时的样子，且直接画出保留的行、不闪 loading；同一预览 pane 从 A 附加根切到 B 再切回 A → A 的折叠与滚动位置各自恢复、B 的地址没有写进 A 的 `revealed`（两端记忆互不串写）。预览导航搜索另有四态（rc.2+）：附加根文件预览 → aside 内出现带 `data-mrfw-files-pane` 的搜索面、原生栏仍在 DOM 但被隐藏，搜索栏常显；输入查询 → 结果树/计数/高亮/当前行/眼睛/设置/失败重试与 Files 页一致，点结果行原位替换预览 tab；关闭/重开 Folder 与 `replaceTab` 后查询与结果保留且不重发请求；切回主根文件 → 插件 pane 消失、原生搜索栏恢复；Esc 顺序为设置 → 清查询 → 关导航树。任一项失真先查这些 `data-*` 属性还在不在对应 flex 项上（`.header` / `.body` 的 class 是 CSS-module hash，不能锚）。退化症状与修法见 [故障排查条目](../../docs/troubleshooting/files-switcher-degraded.md)，决策见 [ADR-0015](../../docs/decisions/ADR-0015-files-tab-plugin-owned-browsing.md)。

**files-tree 旧版复刻面**：`src/client/files-tree/` 保留旧宿主使用的上游 `ui-sidebar-files` 树体逐字节 fork（基线 `f3803c9697` = `0.2.2-alpha.2`；清单、shim 对照、外壳 delta 与同步步骤见该目录 `FORK.md`）。变更旧版基线时按 FORK.md 重拷并对照——`directory-node.ts`/`store.ts`/`FilesBody.module.css` 与 `FilesBody.tsx` 的行级定义必须字节级一致；`face.ts` 带 hold/release 生命周期 delta（`start`/record-abort 重播或丢弃 bucket，`hold`/`release` 让 Folder 关闭只关节点/watch、保留已列 levels），其余部分保持字节级。许可差异有：外壳函数根源改写、css specifier 的 `.ts` 后缀、文件行的 reveal 标记（`Entry` 按钮上的 `ref`/`data-files-current`/`aria-current` 与 `TreeContext` 的 `current`/`currentRef`）、`reveal`/`saved`/`onScrollOffset` 三个 prop 及其外壳逻辑、body 的 `tabIndex` 与原生 `scroll` 监听（portal 外的事件委托到不了，必须用元素自身监听）；同时检查上游 `locales.ts` 的 `zh` 键集（shim 的 `SidebarFilesKey` 联合须同步）、`workspaceFiles` remote 面与 `data-dockkit-content` 钩子。复刻体类名 `mrfw-ft*`、不携带 `data-files-root`/`data-files-body`（防本插件 `:has()` 隐藏规则误伤）； primitives 探针失败时整棵复刻树不渲染（同型降级，不崩）。**remote 面只能经 `ctx.get` 懒解析**：`remote.workspaceFiles` 是 cordis 嵌套服务，context 代理路径（`remote.workspaceFiles` 或 `ctx['remote.workspaceFiles']`）受 inject 守卫（未声明 fiber 直接抛 `without inject`），而本版 cordis 的 inject 条目全 required（声明会把整行 gate 在可选服务上）——`lazyFilesRemote` 用 `ctx.get('remote')`/`ctx.get('remote.workspaceFiles')` 免守卫直查 store，一切查找失败折叠成 `gateway/internal` 失败行（verbatim `load` 的 `.then` 无 `.catch`，逃逸 rejection 会静默钉死 loading）。**编译面同理钉在 dev-pin**：`0.2.0-rc.2` 之前 `workspaceFiles.changes` 是 2 参（session 级 watch），`tsconfig.client.json` 的 `paths` 把 `@deepseek-ai/dsh-api-remotes/client` 映射到 `client-remote.d.ts`（本地声明拼的是 path-watch 时代的 3 参签名），让 verbatim `face.ts` 在矩阵旧版本上也能过 typecheck——安全前提是 `files.actions` 槽位在旧版不存在、调用永不会执行。

**open-in-app 复刻面**：`src/client/open-in-app/` 是上游 `ui-open-in-app` client 包的逐字节 fork（基线 `ddac96760b` = `0.2.2-rc.2`；清单、shim 对照与同步步骤见该目录 `FORK.md`）。升版时按 FORK.md 重拷并对照——许可差异只有 `OpenTargetButton.tsx` 里 css specifier 的 `.ts` 后缀与 `open-toast.tsx` 的两行（丢 layout 副作用导入、`isMobileDevice` 改从 `./device.ts` 导入——它 re-export `src/compat/open-in-app-device.ts` 的探测 shim）；同时检查上游 `locales.ts` 的 `zh` 键集是否新增（shim 的 `OpenInAppKey` 联合须同步）、`shared.ts` 路由常量是否变化（devDep 版本即出处记录）、`OpenInAppActionInjected` 的 hook 名是否漂移。复刻组件拼写 `*Regular` 图标族：0.1.5/0.1.6 像素名运行时不建 adapter、不渲染按钮（同型降级，不崩）。

## 13. B9 进程栅栏接缝（Full-access bypass）

全部 26 个支持版本的四个进程面在 `danger-full-access` 下都绕过 `ctx.sandbox.confine()`：bash/pwsh executor 的 `execute`（`0.1.5/0.1.6` 还有 `start`）、`dsh-terminal-bash` 模块私有 `spawnArgv`、`dsh-ptc-runtime-node`（run_code）。subprocess spec 不携带 `sandboxPolicy`，无法在下层恢复授权意图——`multi-root-process-fence` 行用 `AsyncLocalStorage` 注入 deny 上下文：包装 `ctx.shell.execute`（旧版 `run` / `start`）/`ctx.ptcRuntime.run` 置上下文，`ctx.subprocess.spawn` 见到上下文才重写 argv。PTY 的可达接缝只有共享的 `ctx.subprocess.spawnTerminal`（`persistent-shell` 组 `isolate: terminals`，组内 backend 不可达），会话从 `env.DSH_SESSION_ID` 恢复（`Agent.enter` 强制 `agent.id === session.id`）再 `sandboxPolicy.resolve({session})`；会话不可解析且存在显式只读根时 fail closed。受限 prefix 不私有调 runner：以 read-only policy 探 `super.confine(['true'])` 拆出 profile 骨架，再 `restrictProfileArgs` 变换（保同步/异步形状）。决策见 [ADR-0017](../../docs/decisions/ADR-0017-three-state-root-access-and-sandbox-modes.md)，测试见 `tests/process-fence.spec.ts`。

PTC 的具体实现 `execute` 是 private；包装公开 `run`。Windows 宽字符串指针用 `koffi.decode(ptr, 'char16_t', -1)` 解码指向的数据，不能用 `str16`（那会再解引用一次，把字符串头当地址并原生崩溃）。旧属性候选的 TokenSecurityAttributes 查询采用 native UNICODE_STRING，不能与 Win32 claim 的 PWSTR 布局混用。runner 从 broker 接收 token handle，再读回派生 token 的普通 TokenGroups，确认每根 deny-only 且非 enabled；不能信任 broker ACK。普通 deny-only 组与可取交集删除的 restricting SID list 是两个列表；安装与安全边界链接 ADR-0020，不在本笔记复制进度。

PTY 的 agent/用户判别是 `13 唯一的静默 fail-open 接缝：`DSH_PTY_SESSION_ID` 只由 agent PTY 的启动路径盖章（面板终端控制器只盖 `DSH_SESSION_ID`），下游 release 一旦不再盖章，agent PTY 会被当作用户终端直通放行。`src/compat/pty-marker.ts` 在启动时探测已安装 `@deepseek-ai/dsh-terminal-bash` 的构建产物里有没有这个常量——探的是产物内容，不是版本号也不是 in-process shape（远端打包/裁剪后的构建不执行本机代码也能验证）。后端不存在 = 无 PTY 接缝、放行；存在但探不到 = 启动拒载，`DSH_MULTI_ROOT_COMPAT=warn` 也放宽不了（warn 只放行「未列名但自洽的候选版本」，不放行「合同已经破裂」）。测试在 `tests/pty-marker.spec.ts`。

旧版 Windows process binding 的 `GetFileType` 可能缺失；fd 7 适配必须通过公开 `extendWin32ProcessBindings` 补齐，不能依赖开发 pin 的表形状。

## 14. DSH 0.2.2 接缝与安静陷阱

`0.2.2-alpha.2` 是一次 2000+ commit 的大跨越（rc.4 之后无 alpha.1 标签）。插件源码不需要适配，但测试与宿主组合有几处必须知道的变化：

- **AgentRegistry 新增 `static inject = ['sessionProjections']`**：任何测试栈在 `ctx.plugin(AgentRegistry)` 之前必须先挂 `SessionProjectionRegistry`，否则 `ctx.agents` 静默为 `undefined`，首个 `ctx.agents.enter()` 报 `Cannot read properties of undefined (reading 'enter')`——fixture 缺口，不是插件缺陷。`sessionProjections.register()` 改为 async 且返回 handle；`registry.stateOf(session,key)` 已废弃。
- **工具执行拆出 `dsh-tools`**：执行器是独立行（`dsh-tool-executor-native` / `-ptc`），`ctx.tools.execute` 收批量 `calls` 输入；`@deepseek-ai/dsh-tools/pipeline` 子路径只在 0.2.2 起存在。测试侧的统一处理是 `tests/support/tool-executor.ts`：`ctx.tools.setExecutor` 存在才动态挂上等价分发器，调用按批量/单发两种形态分发。**注意**：`import('@deepseek-ai/dsh-tools/pipeline')` 这类字面动态导入会被 Vite 在转换期解析，在旧版本上直接炸整份 spec——动态导入的 specifier 必须在运行时才拼得出——即 `import()` 的实参写成模板字符串拼接，而不是一段完整字面量。
- **Sandbox 原生第三路可写根**：`SandboxExecutionPolicy.additionalWritableRoots` + `workspaceWritableRoots`（policy service 配置键 `sandboxPolicy.additionalWritableRoots`）由 Seatbelt/bwrap/Landlock/fs-sandbox 原生消费；windows-acl 以 `SandboxUnsupportedPolicyError` 拒绝。本插件不设该字段，宽授权照旧来自自身 scope；两路 grant 的复合由 `tests/upstream-additional-roots.spec.ts` 钉住（旧版本按 `workspaceWritableRoots` 导出存在性结构性跳过）。
- **Session/store**：store 持有的 Session 在 `session/created` 完成前拒绝 append——插件测试用独立 Session，不受影响。`dsh-storage-domain` 新增 `deleteRecords`/`deleteMany` 与 `unknown-state` 隔离，均为新增面。
- **Node ≥24.9**：0.2.2 起的 lanes 需要 Node 24；CI verify 按已知旧版前缀走 22.19.0、其余走 24.9.0。
- **Auto Review 双基线**：上游实验性 auto-review 在 `0.2.2-alpha.2` 重写了输入模型（固定 system + 每条保留项一条请求消息、逐项 schema、前缀复用、`AutoReviewFailedError`、卸载规则），`alpha.3` 又加了 `sessionId`/`purpose` 与 `LlmRequestPurposeMap`。因此联合合同改为两个冻结源码基线（`0.2.1-rc.2`–`rc.5` 用 legacy fork，`0.2.2-alpha.2`–`rc.5` 用 current fork），按车道动态加载、按基线编译 pin 做实现类型检查；`0.2.2-alpha.2` 的 purpose 仍是闭集，不发送该字段（ADR-0040）。
- **上游 Skills 语义微调**：filesystem provider 把失败根报为 incomplete observation、tool-skill 发布 incomplete catalog；本插件的多根 skills provider 仍把嵌套 observation 当普通候选、忽略 `complete:false`——行为不变，记为已知后续观察点。


## 15. DSH 0.2.2-alpha.3 接缝

上游新增 patch、delete 和双端 move：不能直接继承而绕过围栏。结构适配器只在后端具备方法时安装包装，move 两端共享一次 Registry admission。Cordis 的 getter 追踪也改变，Connection 适配器将公开 RPC getter 绑定到消费 fiber。新版 Files 页面使用宿主文件树 Factory，旧界面保留 alpha.2 复刻树。见[接口审查](../../docs/reference/dsh-0.2.2-migration.md#022-alpha3-后续审查2026-11-04)和各 fork 的同步步骤。

升级探测遇到 vendor 预发布范围时取声明的精确基线，即使 npm 同范围还返回更新的预发布版本。alpha.1 Cordis 混入 alpha.2 loader 会破坏旧宿主；alpha.3 阶段的稳定版范围仍取最高匹配版本（已由 `16 修订）。

## 16. DSH 0.2.2-rc.1 转稳定生态

rc.1 相对 alpha.3 的 patch 只改包版本。沿用既有适配器，保留旧宿主所需的具名 prerelease peer 分支；稳定 peer 范围已覆盖 Cordis 4.1.0 / Schemastery 3.19.0。开发树须整体重指，提交前移除临时 probe overrides。稳定版 vendor 范围只能取声明 minor 线内的最新稳定 patch（prerelease 仍钉精确基线）：旧 loader peer `^1.0.3` 会接纳新发布的 `1.1.0`，却在 Cordis `4.0.2` 的 `fiber.entry` 处崩溃。升级 helper 现在对未发布基线或复合范围拒绝猜测，不跨入新的 vendor minor 或把 prerelease 混入稳定线。详见[接口审查](../../docs/reference/dsh-0.2.2-migration.md#022-rc1-后续审查2026-11-05)；执行证据仍在路线账本，可选 Auto Review 的联合合同见 ADR-0040（两个源码基线）。

## 13. 新会话 Hero 入口（`conversation.hero.options`）

`conversation.hero.options` 是 `list` / `session` 槽，`0.2.1-alpha.3` 起由 `ui-conversation` 声明（commit `3f1d5dfcfa`），渲染在 blank session 工作区行的 workspace / 模式选择器之后；`.heroOptions` 自带 `margin-left: auto`，条目组落在整行右端。本插件在其中注册 `multi-root-folders.hero`（order 10，无 `label`），occupant 直接使用 composed `sessionId` 并 memoize 成稳定回调，与侧栏 `sidebar.footer.action` 共用 `WorkspaceFoldersDialog`、RPC、错误码与文案。槽是 `list`，outlet 以 `display: contents` 挂在 `.heroOptions` 内，本入口不 grow/不绝对定位/不占满宽度，不会独占该槽；当前组合只有本入口是安装事实。

- **可用版本**：`0.2.1-alpha.3` 及更新；`0.1.5-rc.2` ～ `0.2.1-alpha.2` 没有该槽。
- **缺席行为**：`ctx.slots.inject` 静默不触发，新会话页没有该入口；侧栏入口、host 侧、RPC 与授权语义全部不变。
- **依赖形态**：**不依赖** `ui-conversation`（不 import 类型、不加 devDependency、不进 `dsh.client.inject`）。typecheck 矩阵包含 `0.2.1-alpha.3` 之前的版本，它们的 SlotMap 没有该键；注册走窄结构接口（`inject` + `spec` + `register`），`spec` 查不到声明就直接返回空 disposer。只有声明了该槽的版本会注册并显示入口；旧版本不显示，侧栏入口不受影响。
- **用公开的 `spec` 探测，不要用 `specDynamic`**：`specDynamic` 只存在于 `SlotCore`，`ctx.slots`（`SlotRegistry` 服务）只公开 `spec`、`entries` 等方法。测试替身必须使用真实 `SlotRegistry`，否则会把不存在的服务方法伪装成可用；`tests/client-slot-probe.spec.ts` 通过浏览器模块加载器实例化真实服务并声明槽位。
- **会话权威**：槽是 `session` scope，composed props 的 `sessionId` 是确定值；不要在 hero occupant 里回退到全局 current-session 解析（侧栏 fallback 是另一条路径）。
- **形态约束**：与相邻 workspace / 模式选择器同几何，但因打开对话框而非菜单**没有 chevron**；图标优先 `IconWorkspaceTreeOutlineRegular`，旧运行时经 `selectIconOr` 回退 `IconFolderOpen`（不使用像素时代名）；文字在左、icon 在右，以贴合该行右对齐的阅读顺序；trigger 另加 `margin-right: 4px`，因为上游行 padding 是 `0 16px 0 20px`，这样按钮盒与工作区选择器一样内缩 20px。**宽度自适应**：`.heroOptions` 是 `flex: none`，条目不会被行挤窄，因此入口用 `measureHeroEntryRoom` 把 seat 临时固定为图标下限（`data-measuring` → 28px、隐藏 label）后读取 options 组预算（前一个控件 + flex gap 到行内容右缘，减去同槽其他条目、组内 gap 与自身外边距），写进 `--mrfw-hero-entry-room` 交给样式夹取；余量 < 88px 时 `data-size="compact"` 只留图标。探针只依赖四条结构事实——options 容器是 flex 子项、slot outlet 为 `display: contents`、同槽条目与入口共享同一个 outlet 包装（探针沿包装下钻计数，不把包装当条目）、options 组是行内最后一项；`0.2.1-alpha.3`–`0.2.2-rc.5` 的已安装源码中一致。任一条不成立时探针返回 `null`，样式回落到 `:not([data-size])` 的内容宽度与 560px 视口兜底。上游若给该行加容器或允许 `.heroOptions` 收缩，重新评估该探针。
- **无 DOM 钩子**：入口只依赖槽位契约；上游改名或移除该槽时按上面的缺席路径静默退化，不需要目检表更新。

## 17. DSH 0.2.2-rc.2 支持与发布

- **状态**：上游 tag `dsh-v0.2.2-rc.2` 指向 `ddac96760b`，npm 已发布（`next` 指向该版本，`latest` 仍为 `0.2.2-rc.1`）。本分支已把 `SUPPORTED_DSH_RELEASES`、全部 DSH peer 与开发 pin 提升到 `0.2.2-rc.2`（23 个精确版本），并用 `scripts/upgrade-dsh.mjs 0.2.2-rc.2` 整体重指开发树；临时 probe overrides 已移除，新增的 10 个传递包（`dsh-agent-team`、`dsh-client-ui-account-notifications`、`dsh-client-ui-agent-team`、`dsh-error`、`dsh-mcp-manager`、`dsh-office-kit`、`dsh-terminal-panel`、`dsh-tool-agent-team`、`dsh-tool-office`、`dsh-util-ripgrep`）已补 `minimumReleaseAgeExclude`，否则 frozen install 会被发布年龄门禁拒绝。
- **新增接缝**：`dsh-sandbox` 用 `SandboxPreparationError` / `SandboxEscalationError` 取代未编码错误，Windows ACL 不再因额外根报错而是进程侧忽略；`SandboxPolicyService.registerWritableRoot` 让 Session 把目录并入 `resolve()` 的额外根；`workspaceFiles.search` 用打包 rg 经 `ctx.subprocess` 搜索；`dsh-error` 成为 `HarnessError` 的新共享基类；`dsh-subprocess` 与 `working-directory` 改为编码错误，后者新增 `working-directory/access` waterfall。插件均按结构消费，未新增版本判断。
- **安静陷阱 1（Windows ACL 语义翻转）**：上游在 Windows 进程侧**忽略** `additionalWritableRoots`，只让文件工具执行；插件自己 scope 根的进程授予仍来自 `widenWindowsProfile` 拼进的 ACE 参数，两者不可混为一谈。`tests/upstream-additional-roots.spec.ts` 的 per-Session 小节钉住“原生注册根可被 fs fence 写入、scope read-only deny 仍胜出”。
- **安静陷阱 2（authority 降级优先）**：`registerWritableRoot` 的根随 policy 进入 `writableRoots()` 与 POSIX profile，但插件在 authority unavailable 时仍只保留主根与显式 deny；不要把“上游已授权”当作可用 authority 的证据。
- **安静陷阱 3（搜索根）**：`workspaceFiles.search` 做共享 authority 的 admission，不做事先的多根路由——搜索根是 Session cwd；但它的 **Session 根**受 withheld 检查：canonical 搜索根落在在册未授权边界下时在启动 `rg` 前拒绝。接管附加根时原生搜索条、状态行与 Files 页开关随原生 body 一起隐藏；primary 根浏览保持上游原样。
- **安静陷阱 4（fork 基线）**：rc.2 的 `ui-open-in-app` 复刻源只有两处注释变化并新增 `menu.openIn`；本分支已按 FORK.md 重拷 `OpenInAppAction.tsx` / `controller.ts`、把 baseline 移到 `ddac96760b`，并在 `OpenInAppKey` 补 `menu.openIn`。files-tree 旧版复刻仍钉 alpha.2。
- **契约检查**：`@deepseek-ai/dsh-error` 已加入 `OPTIONAL_CORE_PACKAGES` 与 `HOST_SERVICE_PACKAGES`（只经宿主锚点作证，发现跨包单例混装）；**不要**把它写进 `peerDependencies`——rc.1 没有该包，会让旧宿主安装失败。
- **验证（已发布包）**：在已发布的 `0.2.2-rc.2` 开发树上，`compat:check`、lint、双端 typecheck、`build`、`docs:check`、`pack:check` 与 `auto-review:fork` 通过；完整 vitest 为 **1368 通过 / 162 跳过 / 17 失败**。17 个失败全部是当前 Seatbelt 会话的 sandboxed-peer registry IPC 用例；rc.1 基线在同一环境同样失败 17 个（1364 / 166），不是 rc.2 回归。本机 `smoke:compose` **56/56**、`smoke:behavior` **96 通过 / 8 跳过**、`smoke:journey` **85 通过 / 2 跳过**、`smoke:packed` **95 通过 / 8 跳过**，均 0 失败（跳过项是 Seatbelt 内无可用内核 runner 与共享 IPC）。三 OS 矩阵与 Windows ACL 原生结果由 PR 的 CI 给出（[run 43227479998](https://github.com/cherrchen/dsh-plugin-multi-root-workspace/actions/runs/43227479998)，94/94 jobs）；浏览器目检不是 CI 项，按路线账本的人工记录。

## 18. DSH 0.2.2-rc.3 支持

- **状态**：上游 tag `dsh-v0.2.2-rc.3` 指向 `38a6a5c965`，npm 已发布（`next` 指向该版本，`latest` 仍为 `0.2.2-rc.1`）。本分支把 `SUPPORTED_DSH_RELEASES`、28 个 DSH peer 与开发 pin 提升到 `0.2.2-rc.3`（24 个精确版本），并用 `scripts/upgrade-dsh.mjs 0.2.2-rc.3` 重指开发树；probe overrides 已移除，唯一新增的传递包 `dsh-deepseek-chat-import` 已补进 `minimumReleaseAgeExclude`。
- **上游差异**：rc.3 只有 6 个提交、515 个文件；380 个 `package.json` 只改版本号，其余集中在 `ui-sidebar` 的新会话行 HOC 槽、`ui-workspace` 的 `workspace.picker` Factory 与第三个 directory-flow 洞、两个目录选择器包、`ui-primitives` 的上传图标、可选实验 bundle `dsh-deepseek-chat-import`、`session-log-export` 的不可读附件降级，以及桌面安装器与 CI。插件的沙箱、fs、tools、session、storage、skills、lsp、workspace-files 与 Connection 接缝没有任何改动，**未新增 adapter 分支**。
- **安静陷阱 1（peer-only 副本）**：升级后 `dsh-permission-presets` / `dsh-util-values` 仍可能以 rc.2 副本满足 peer 边（rc.3 各包声明的是精确 peer），`pnpm peers check` 必须为 0；`pnpm dedupe`、`--force`、`--lockfile-only` 都不会改写这类“看似有效”的边。落地前要让它们升到同一精确版本，最终 lockfile 中 `0.2.2-rc.2` 只作为 peer 范围字符串出现。

- **安静陷阱 2（新包不是契约成员）**：`dsh-deepseek-chat-import` 默认不挂载、与插件授权面没有交点，不加入 `OPTIONAL_CORE_PACKAGES`；它自带的 `zod 4.6.6` 与 `dsh-storage-domain` 的 `4.4.3` 是两份独立副本，域 schema 仍只经 `storage-zod` 构建。
- **安静陷阱 3（目录选择器第三个洞）**：`workspace.picker.directoryFlow` 由 `workspace.picker` Factory 声明；插件没有 occupant，也不要往宿主的新会话/选择器流里挂自己的根 UI。
- **安静陷阱 4（新会话行 DOM）**：`sidebar.session.action` 用 `display: contents` 锚点夹在 `.newSessionRow` 与按钮之间，`sidebar.footer.action` 在页脚、不受影响；将来若要注册该 HOC 槽，必须原样返回 `children`，不要多套一层盒子。
- **fork 基线**：rc.3 未改 `ui-open-in-app` / `ui-sidebar-files` 的 `src/client/`，open-in-app 基线保持 `ddac96760b`、files-tree 旧版保持 `f3803c9697`；`FORK.md` 只记录 dev pin 已前移、基线不变。
- **验证（已发布包）**：`compat:check`（allowlist / peer / 开发 pin / 安装树一致，24 个精确版本；`pnpm peers check` 无问题）、lint、双端 typecheck、`build`、`docs:check`、`pack:check`（210 成员）与 `auto-review:fork` 通过；完整 vitest **1386 通过 / 162 跳过 / 17 失败**，17 个失败仍全部是本会话 Seatbelt 下的 sandboxed-peer registry IPC 用例（与 rc.2 基线的 17 个同形）。本机 `smoke:compose` **56/56**、`smoke:behavior` **96 通过 / 8 跳过**、`smoke:journey` **85 通过 / 2 跳过**、`smoke:packed` **95 通过 / 8 跳过**，0 失败。三 OS 矩阵与 Windows ACL 原生结果由 PR 的 CI 给出。

## 19. 附加根 Files 的行右键与工作区搜索（2026-11-14）

两个宿主面都是 `0.2.2` 线新增，插件按结构门控：**不要**改成版本字符串比较，也**不要**把上游 client 包加进任何依赖——`scripts/upgrade-dsh.mjs` 会把每个 `@deepseek-ai/dsh*` devDependency 改写到目标 release，`0.2.2-alpha.3` 之前不存在的包会让 20 个老版本 lane 在 `pnpm install` 阶段死亡。

- **行右键（`0.2.2-alpha.3` 起）**：renderer 的根级 composed prop `useContextMenu` 提供 `getTriggerProps`，插件从 slot occupant 直接取；seat 由 `src/client/files-tree/context-menu.ts` 取，经 `src/compat/files-tree.ts` 的 `rowTriggerProps`/`canOpen` 转发进 `sidebar.files.tree` Factory，旧行渲染路径 spread 同一组 handlers。target 是 `{ kind: 'file' | 'directory', value: { sessionId, path: 绝对路径 } }`；**必须传绝对路径**——宿主贡献方按 Session cwd 解析相对路径，会把附加根行指向主根同名文件。没有 `useContextMenu`（更早宿主）→ 不绑定、DOM 不变。
- **`contextMenus.registeredKinds`（`0.2.2-rc.2` 起）**：可选探测。没有该成员时直接绑定（alpha.3 原生已注册 file/directory 贡献），不要把“探不到 kinds”误判成“没有菜单”而丢掉 alpha.3 的右键。
- **工作区搜索（`0.2.2-rc.2` 起）**：客户端探测 `typeof remote.workspaceFiles.search === 'function'`，宿主探测 `typeof service.search === 'function'`；缺席时不渲染页头搜索钮/搜索栏、不调用端点（端点会答 `search-unavailable`）。搜索根在 wire 上无法命名（request 只有 SessionId），所以走插件通道 `/multi-root-workspace` 的 `search` 端点：`rootId` 解析自**刷新后的** Registry（稳定 id，不是路径），以 host 内部 scope 命名附加根，单次以主根为 key 的 Registry 准入；`scopeOf()` 的授权复核必须在准入帧内——共享权威 Host 的帧外答案是空，帧外检查会把所有搜索拒掉。
- **`highlight` / `omitted` 与隐藏项过滤（`0.2.2-rc.2` 起）**：结果树给 Factory 传 `highlight`，旧行路径用 `<mark>`；树态在绘制期过滤隐藏项（`src/client/files-tree/hidden.ts`），隐藏目录下的已列层级丢弃、只含隐藏项的目录用 `omitted: 'hidden'` 画说明，搜索把同一偏好作为 `includeHidden` 上送。偏好与上游同一个 localStorage 键 `dsh.sidebar-files.workspace-search.v1`，只存与默认值的差异；删掉插件代码不影响原生读取。
- **已知边界**：原生 Files 快捷键（Cmd+P）仍聚焦被接管隐藏的原生搜索框，附加根搜索的受支持入口是页头搜索钮；预览导航树的搜索由 ADR-0043 补齐（见 `21），它的搜索面在 aside 内、同样不响应 Cmd+P。
- **升级目检**：更早宿主上附加根树零变化（没有菜单、没有搜索钮）；rc.2+ 上右键 target 命中附加根真实路径、搜索结果与主根原生同构，预览附加根文件时 aside 内出现插件 pane 的常显搜索栏。结构边界与证据见[接口审查](../../docs/reference/dsh-0.2.2-migration.md#附加根-files-视图消费的两个接口面2026-11-14)与 [ADR-0041](../../docs/decisions/ADR-0041-additional-root-workspace-search.md)、[ADR-0042](../../docs/decisions/ADR-0042-additional-root-row-context-menus.md)、[ADR-0043](../../docs/decisions/ADR-0043-additional-root-preview-navigator-search.md)。


## 20. Files 页签的实现接管与可见性（2026-11-15）

- **tab 注册表是唯一的接管事实源**：`ctx.sidebarRightTabs`（`0.1.5-rc.2` 起由 `ui-sidebar-right` provide）的 `get(kind)` 返回该 kind 的**生效**定义，`subscribe(listener)` 在注册/移除时通知（`0.2.0-rc.2` 已有）。extension band 接管 builtin 后，内置 Files 页实现（id `@deepseek-ai/dsh-client-ui-sidebar-files`、`priority: 'builtin'`）被降为 shadowed，`FilesBody` 不再挂载。
- **槽位声明 ≠ 渲染**：`sidebar.right.tab.files.actions` 由 `ui-sidebar-files` 注册 `FilesBody` 时的 `children` 在启动时声明；页面被接管后该槽仍是 declared，`slots.inject`/`spec()` 都正常。不要用它们判断 Files 页是否还在渲染——同类问题先查 tab 注册表。
- **可见性约定**：检测到接管时，本插件经 `shell.overlay` 弹一次官方 primitives `Toast`（`src/client/files-page-notice.tsx`，词条 `filesPage.notice`），不传 `icon`/`tone`（icon 座席是 warning 色，省略才是 info 级），5 秒淡出；同一接管实现 id 只提示一次，解除后重置。探测在 `src/compat/files-page.ts`，只读结构、不比较版本字符串；`dsh-client-ui-sidebar-right` 不是本插件的 devDependency，也不要为它新增运行时依赖。
- **升级目检**：装 better-sidebar 等接管 `files` kind 的插件 → 顶部出现一次 info Toast、切换器不出现，footer 与 `/workspace-folders` 仍可用；停用接管插件 → 切换器恢复，再次接管会再次提示。

## 21. 侧栏 footer 入口的图标、两代行几何与同槽共存（2026-11-16）

侧栏底部 `sidebar.footer.action` 的 occupant 行现在有四条“安静”的版本与耦合事实，改样式或往同槽加 occupant 之前必须知道（决策与全部取证见 [ADR-0044](../../docs/decisions/ADR-0044-sidebar-footer-row-alignment-and-coexistence.md)）。

- **行几何的分界是 `0.2.2-alpha.2`，旧宿主靠 fallback 命中。** 宿主在 commit `86fb01a613` 把侧栏行从“2px 外扩 + 12px 列内边距”改成 paint-inset token 配方（`--dsh-sidebar-row-padding: 12px`、`--dsh-sidebar-paint-inset: 3px`、`--dsh-sidebar-label-gap: 6px`，列内边距 8px；首个受支持 tag 是 `dsh-v0.2.2-alpha.2`）。因此 19 个旧几何版本（`0.1.5-rc.2` … `0.2.1-rc.5`）根本没有 `--dsh-sidebar-*` 自定义属性，样式表里的 fallback 值就是它们的实际配方；7 个新几何版本（`0.2.2-alpha.2` … `0.2.2-rc.5`）命中 token。一份「token + fallback」声明在两代上都与宿主设置触发行逐像素一致——不要按版本号判断代际，也不要只改 padding：新宿主同时改了列内边距、行内边距与 paint-inset，单改 padding 不可能两代同时命中。
- **rail 圆角有自己更早的分界 `0.1.6-alpha.2`，最老 2 个版本是已记录偏差。** 宿主从 commit `c6b81a75fd` 起让 rail 触发器继承 `.trigger` 的 12px 圆角（此前是 `border-radius: 50%` + `corner-shape: round`）；26 个受支持版本里只有 `0.1.5-rc.2`、`0.1.6-alpha.1` 是圆。本插件用 `border-radius: var(--dsw-radius-md, 12px)`：与 `0.1.6-alpha.2` 起的 24 个版本一致，最老 2 个版本宿主画圆、插件画 12px 圆角方（无 ink/布局影响）。不存在能区分 `0.1.6-alpha.2` 的 CSS-only 探针，所以这 2 个版本的偏差被接受；不要换回 `50%`，也不要用 `max(12px, 50% - 2 * inset)` 之类的公式——它只在 7 个新几何版本与最老 2 个版本上与宿主一致，其余 17 个旧几何版本会得到 18px（宿主是 12px）。
- **官方 cordis footer occupant 永远注册但通常不渲染，槽账本不是“有人在渲染”的信号。** 标准 `dsh-web-app` 组合无条件挂载 `ui-cordis`，它永久注册 `cordis-panel` 的 footer occupant，只在存在动态 Cordis 插件时才渲染（inventory 为空时返回 `null`）。`ctx.slots.entries / entriesOfSlot / subscribe / getVersion` 在全部 26 个受支持版本上都是公开 API，但只能回答“谁注册了”：`entriesOfSlot('sidebar.footer.action').length > 1` 在所有标准安装里恒真，拿它做让位判据会让本入口永久消失；`return null` 式让位仍占着 ledger cell，两个插件互相让位会互隐/抖动，“渲染可见”只能靠对宿主 DOM 的观测，而本插件不做这种观测。同槽几何冲突的实际做法是 CSS/DOM 布局修补——本插件在自身挂载期间把 `[data-slot='sidebar.footer.action']` 锚点变成纵向列，让每个真正渲染的 occupant 各占一整行，插件卸载即回到宿主布局。ADR-0044 `D4 是这条的完整否决记录。
- **设置行 occupant 的高度从 `0.2.0-rc.1` 起随登录状态变化，按钮跟随它而不是写死 42px。** `0.1.7-rc.2` 及更早的 7 个版本里，侧栏设置行 occupant 是 42px 的设置触发器，按钮保持 `height: 42px`；从 `0.2.0-rc.1` 起该行 occupant 是账号菜单 launcher（`AccountMenu.module.css`：已登录 44px、未登录 32px、rail 36px），样式表用 `[data-slot='sidebar']:has(button[data-signed-out='true'])` 与 `[data-slot='sidebar']:has(button[data-signed-out='false'])` 两条例外把 wide 触发器覆盖为 32px / 44px，标记缺席时回退 42px，rail 固定 36px。这是对账号 launcher 结构属性的 CSS 依赖，不是槽位契约：不要写死 32/42/44、不要按版本号切换、也不要把 `data-signed-out` 当成公开 slot 字段；宿主改名时按钮退化为 42px（不会误设尺寸）。只有高度跟随，左侧 inset 与 hover token 仍来自行几何配方。

## 22. 预览导航树的工作区搜索（2026-11-16）

- **复用而非复制**：`FilesPane` 新增 `mode='preview'`，预览导航接管在 `filesTree.search` seat 存在时 portal 同一个 `FilesPane`，而不是第二套搜索状态机（[ADR-0043](../../docs/decisions/ADR-0043-additional-root-preview-navigator-search.md)）。预览形态的差异只有四项：栏常显（不读不写 `barOpen`）、挂载不抢焦点、调用方提供打开路由（`openFileIn` → `replaceTab`）、结果命中被预览文件时标当前行（`TreeView.current.ref` 变可选，只标记不滚动）。搜索记录键是 `(pane, root)`，与 Files 页的 `(tab, root)` 分开；偏好仍写宿主同名 localStorage 键、按根隔离。
- **接管记录原子化**：预览接管与 Files 页 `RootSwitcher` 的 takeover 都在一次 state 提交里携带 `{ root, rootId }`，搜索 key 与请求的 `rootId` 同源；换根过渡帧不再发出“新根 rootId + 旧根 query”的请求，也不会把旧根记录写成无人结算的 `pending`（v0.1.20 已发布缺陷的修复）。
- **降级**：有面板通道但无 `workspaceFiles.search`（rc.2 之前或裁掉 search 服务的组合）→ 仍 portal `FilesTree`，DOM、生命周期与隐藏规则逐项不变；无面板通道 → 不建立接管、导航树全程原生；主根文件在任何宿主上都不接管、原生搜索零变化。
- **结构依赖与目检**：原生搜索节点由 `styles.ts` 的 DIRECT-CHILD 规则隐藏，bar 选择器带 `:not([data-mrfw-files-pane])` 守卫，插件 pane 根携带 `data-mrfw-files-pane`；焦点交接在 `[data-files-page], aside[data-files-navigator]` 容器内查找原生 body（覆盖 pane 包装、直挂与 Files 页新包装三种形态）。升级目检清单见第 12 节；测试面与已接受偏差见[实施计划](../../docs/plans/completed/2026-11-16-additional-root-preview-navigator-search.md)。


## 23. DSH 0.2.2-rc.4 支持

- **状态**：上游 tag `dsh-v0.2.2-rc.4` 指向 `3f321d32bfe382212a8ed8785c1d47a5a300aa23`（发布提交 `bc3bddffbd`），npm 已发布该精确版本（`next` 指向它，`latest` 仍为 `0.2.2-rc.1`）。本分支把 `SUPPORTED_DSH_RELEASES`、28 个 DSH peer 与开发 pin 提升到 `0.2.2-rc.4`（25 个精确版本），并用 `scripts/upgrade-dsh.mjs 0.2.2-rc.4` 重指开发树；probe overrides 已移除，`pnpm install` 后 lockfile 中 `0.2.2-rc.3` 包副本为 0、`pnpm peers check` 无问题。
- **上游差异**：rc.4 只有 8 个提交、395 个文件；其中 379 个 `package.json` 只替换版本号，其余 16 个文件的净改动集中在 DeepSeek 内容安全审查拒答（`dsh-llm` 新增 `LLM_FAILURE_CODES.CONTENT_REFUSED`，`llm-deepseek` 的 `translate()` 在 `refusal` 时先产出 usage 再抛该错误并附带 provider 解释）、`llm-deepseek` 的 `safetyCheck` 开关三次提交净零（最终没有配置开关，始终请求安全审查）、实验包 liveshare 的 tunnel worker 启动模式修复，以及对应的 npm upgrade guide 与会话快照。插件不按 LLM 错误码或 deepseek adapter 配置路由，这些语义由宿主继承。
- **接缝核对（逐树 hash）**：sandbox / sandbox-local / sandbox-policy / sandbox-windows-acl、fs / fs-local / fs-sandbox、session-projection、storage-domain、skill / skill-filesystem、lsp / lsp-stdio、api/workspace-files、`ui-open-in-app/src/client`、`ui-sidebar-files/src/client` 与 Auto Review reviewer `src` 在 rc.3 与 rc.4 之间的 tree hash 完全相同；唯一变化的运行时源码树是 `dsh-llm/src`，即新增故障码。**未新增 adapter 分支**。
- **Auto Review 编译 pin 前移**：current 基线的 reviewer `src` 在两版之间相同（`2c4de92078…`），因此编译 pin 从 `0.2.2-rc.3` 前移到 `0.2.2-rc.4`，联合发布集合从 9 个扩到 10 个；实现类型检查仍在开发 pin 等于该基线编译 pin 的车道执行。
- **安静陷阱 1（peer-only 副本）**：每次提升都要以 `pnpm peers check` 与 lockfile 中旧 rc 副本计数为准，不要依赖 `dedupe` / `--force` / `--lockfile-only`；本轮升级后两项分别为 0 与 `No peer dependency issues found`，其他命令的输出不能替代这两项证据。
- **安静陷阱 2（内容审查拒答不是插件面）**：`CONTENT_REFUSED` 是普通 `LlmError` 故障码，发生在会话循环的 LLM 调用内；插件既不包装该调用也不声明失败分类，不要为它新增版本判断或适配器分支，也不要假设 deepseek adapter 仍有 `safetyCheck` 配置项（rc.4 已移除）。
- **安静陷阱 3（编译 pin 前移的依据）**：只有 reviewer `src` 逐字节相同才允许把编译 pin 移到新发布；上游若改 reviewer 源码，必须重做该基线的 fork 与差分门禁，而不是只改 pin。
- **fork 基线**：rc.4 未改 `ui-open-in-app` / `ui-sidebar-files` 的 `src/client/`，open-in-app 基线保持 `ddac96760b`、files-tree 旧版保持 `f3803c9697`；`FORK.md` 只记录 dev pin 前移、基线不变。
- **验证（已发布包）**：`compat:check`（allowlist / 28 个 peer / 开发 pin / 安装树一致，25 个精确版本；`pnpm peers check` 无问题）、lint（0 警告 0 错误）、双端 typecheck（含 `tsconfig.auto-review-current.json` 的实现类型检查）、`build`、`docs:check`、`pack:check`、`auto-review:fork` 与 `kernel:probe` 通过；`12 的浏览器目检清单已在隔离 scratch `$DSH_HOME` + 真实 `dsh web`（rc.4 开发树）+ Chrome headless/CDP 上完成（Files 三态、行几何 parity、附加根/主根预览导航器、折叠/重开与 A→B→A 记忆、搜索/眼睛/设置/Esc 顺序与失败重试），证据见[路线账本](../../docs/plans/active/2026-09-12-multi-root-workspace.md#dsh-022-rc4-兼容提升2026-11-18)；完整 vitest **1933 通过 / 165 跳过 / 17 失败**，17 个失败仍是本会话 Seatbelt 下的 sandboxed-peer registry IPC/租约用例（`registry*` / `authority-boundaries` / `b9-review-regressions` / `skills-authority` / `skills-registry` 共 8 个文件），与 rc.3 基线同一失败集合，不是 rc.4 回归。本机 `smoke:compose` **56/56**、`smoke:behavior` **96 通过 / 8 跳过**、`smoke:journey` **88 通过 / 2 跳过**、`smoke:packed` **95 通过 / 8 跳过**，0 失败（跳过项是 Seatbelt 内无可用内核 runner 与共享 IPC）。三 OS 矩阵与 Windows ACL 原生结果由 PR 的 CI 给出。

## 24. DSH 0.2.2-rc.5 支持

- **状态**：上游 tag `dsh-v0.2.2-rc.5` 指向 `9c2670d3bce5275e0d1610272958121af87787bb`（发布提交 `9bf478edde5b14e6a15d3802a8834bdca83f2d97`），npm 已发布该精确版本（`next` 指向它，`latest` 仍为 `0.2.2-rc.1`）。本分支把 `SUPPORTED_DSH_RELEASES`、28 个 DSH peer 与开发 pin 提升到 `0.2.2-rc.5`（26 个精确版本），并用 `scripts/upgrade-dsh.mjs 0.2.2-rc.5` 重指开发树；probe overrides 已移除，`pnpm install` 后 lockfile 中 `0.2.2-rc.4` 包副本为 0、`pnpm peers check` 无问题。
- **上游差异**：rc.5 是 5 个提交、433 个文件；其中 380 个 `package.json` 只替换版本号，其余 53 个文件的净改动集中在 DeepSeek 内置联网搜索的按模型路由选择（`dsh-web` 在未配置 `searchProvider` 时按模型请求的 provider 路由解析：`deepseek-official` / `deepseek-account` 路由用 Messages 搜索 `deepseek-official`，其余路由与模型请求之外用 `deepseek-search-api`；`dsh-tool-web` 把 `exec.agent.session.requestContext()?.provider` 透传给 `ctx.web.search`）、`web-search-deepseek` 优先使用结果项自带的 `snippet`（缺失时才回落到 citation 片段）、文案改为「DeepSeek server-side search」，以及设置卡片、配置目录、e2e 与会话快照更新；liveshare test-clock 提交在两 tag 之间没有净差异（同一 blob）。插件不注册 search provider、不包装 `ctx.web`、不实现 `web_search` / `web_fetch` 工具，`cordis.patch.yml` 也不引用 `web` 行，因此未新增 adapter 分支——宿主继承新的搜索选择语义。
- **接缝核对（逐树 hash）**：本插件消费的 `src` 树在 rc.4 与 rc.5 之间全部逐字节相同，包括 sandbox / sandbox-local / sandbox-policy / sandbox-windows-acl（`01104584d8` / `df462d3e5e` / `ec4a77eb6c` / `ceee0b85f1`）、fs / fs-local / fs-sandbox（`a2ead247d1` / `700a6e5ac9` / `178f100356`）、session-projection（`7935938ee8`）、storage-domain（`3f84d317ea`）、skill / skill-filesystem（`2c9c47d5ee` / `bbd5a998e7`）、lsp / lsp-stdio（`6edec9f634` / `37b51c90c5`）、api/workspace-files（`55865100c9`）、`ui-open-in-app/src/client`、`ui-sidebar-files/src/client` 与 Auto Review reviewer `src`（`2c4de92078`）。被改动的五个运行时 `src` 树（`dsh-web`、`dsh-tool-web`、`dsh-web-search-deepseek`、`dsh-client-ui-settings-web-search`、`dsh-tool-cordis` 的 API 目录文案）都不在插件消费面。
- **Auto Review 编译 pin 前移**：current 基线的 reviewer `src` 在两版之间相同（`2c4de92078…`），因此编译 pin 从 `0.2.2-rc.4` 前移到 `0.2.2-rc.5`，联合发布集合从 10 个扩到 11 个；实现类型检查仍在开发 pin 等于该基线编译 pin 的车道执行。
- **安静陷阱 1（peer-only 副本）**：每次提升都要以 `pnpm peers check` 与 lockfile 中旧 rc 副本计数为准，不要依赖 `dedupe` / `--force` / `--lockfile-only`；本轮升级后两项分别为 0 与 `No peer dependency issues found`。
- **安静陷阱 2（联网搜索不是插件面）**：rc.5 的搜索 provider 选择发生在 `ctx.web` 与 `dsh-tool-web` 内，插件既不注册 search provider、不包装 `ctx.web`，也不消费 `web_search` / `web_fetch` 的工具实现；不要为它新增版本判断或适配器分支，也不要假设 `WebSearchRequest` 新增了路由字段——新增的参数只在上游 tool-web 内部传给服务。
- **安静陷阱 3（编译 pin 前移的依据）**：只有 reviewer `src` 逐字节相同才允许把编译 pin 移到新发布；上游若改 reviewer 源码，必须重做该基线的 fork 与差分门禁，而不是只改 pin。
- **fork 基线**：rc.5 未改 `ui-open-in-app` / `ui-sidebar-files` 的 `src/client/`，open-in-app 基线保持 `ddac96760b`、files-tree 旧版保持 `f3803c9697`；`FORK.md` 只记录 dev pin 前移、基线不变。
- **验证**：本机门禁、vitest 与四个 smoke 的结果记在[路线账本](../../docs/plans/active/2026-09-12-multi-root-workspace.md#dsh-022-rc5-兼容提升2026-11-18)；三 OS 矩阵与 Windows ACL 原生结果由 PR 的 CI 给出。


## 25. DSH 0.2.3-alpha.2 支持（alpha.1 发布不可启动，未纳入合同）

- **状态**：`dsh-v0.2.3-alpha.1` 指向 `d98f5d68519215da48f3002da2cb9c9d2068d81d`（发布提交 `aae91d692e2802f63a4a92fd073fe21259795e59`），`dsh-v0.2.3-alpha.2` 指向 `4b399c39a6d1479cd84ca591b4d7c88e24d38a96`（发布提交 `267805d20d`）；npm 的 `alpha` dist-tag 指向 alpha.2，`next` / `latest` 仍是 `0.2.2-rc.5`。本分支把 `SUPPORTED_DSH_RELEASES`、全部 DSH peer 与开发 pin 提升到 `0.2.3-alpha.2`（**27 个精确版本**），`peerDependencies.cordis` 追加 `4.2.0-alpha.1`。
- **发布边界**：alpha.1 是 rc.5 的后代，中间合入四天主线；alpha.2 只替换包版本号（含 vendor 4.2 升级），另有 3 个 `src` 行级变化（app-boot profile resolver、boot/hmr manifest、ptc-runtime-node vm-modules）与根 `engines` 变化。全部服务端接缝差异来自 `rc.5 → alpha.1` 源码，两个 tag 共用一份适配；受支持发布是 alpha.2。
- **安全适配（session origin vs effective cwd）**：`dsh-sandbox-policy` 现在把 `resolve({session}).workspaceRoot` 设为 `workingDirectory.get(session) ?? header.cwd`（有效目录）。插件 ADR-0012 的不变量是「身份 = Session 原始项目」，因此 Registry/scope 身份全部改用显式原始目录（`src/compat/session-directory.ts` 的 `originDirectory` / `policyOriginRoot`），`policy.workspaceRoot` 只保留为上游执行边界与路径基。按有效拼写查 scope 表会得到空 deny 集：Host 移动 Session 目录后，登记为 `read-only` 的附加根可能在被移动到其内部时变成可写、`toolAccess` 上限被绕过；回归测试覆盖该场景。**同源缺口（外部复核补齐）**：authority 不可用时的 `clampedExecution()` 曾用有效目录作唯一可写根，而文件径只授原始主根——现在两者都取 `policyOriginRoot()`；cold Session 的 Files 请求从 `sessionPersistence.stat().header.cwd` 取身份；指令重放仍只让恢复前缀贡献 touched 路径；再次恢复时以 Host 登记的 working-directory 投影 `stateVersion`（`0.2.2` 线及更早为 `1`、`0.2.3` 起为 `3`，经公开的投影 `checkpoint()` 读取）作为跨重启的目录语义证据，并以「投影重建目录与两条候选链终点」的比对作回退，判定废弃的 `working-directory/change` 链是否仍生效；证据无法判定的旧相对活动保守跳过，不再按旧目录链猜测；正常活动仍由 live 监听按有效目录处理。Windows ACL 的 widen 交叉校验仍用上游 profile 的 policy root，但 graft 的授权根用原始主根。
- **cordis 4.2 根上下文**：current Auto Review 基线横跨 `0.2.2` 行（cordis 4.1，只有 `ctx.root`）与受支持的 `0.2.3-alpha.2`（cordis 4.2，只有 `Context.root` 符号），因此卸载分支必须两种 API 都探：新增 `src/compat/cordis-root.ts`（先符号、后属性、都不存在则失败关闭），`current/fork.ts` 经它取根；差分门禁新增第 9 项，禁止 fork 直接拼任一 API，并要求探测模块保留符号、属性回退与失败关闭。
- **Auto Review 联合合同**：alpha.2 与 alpha.1 的 reviewer `src` 树逐字节相同（`9178184679…`，`index.ts` sha256 `179e8f50…`），与 rc.5 相比只有 import 顺序与根上下文两行——两者都在 `current/fork.patch` 已替换的行内，输入模型未变，因此**不新增第三个源码代际**：`AUTO_REVIEW_CURRENT_RELEASES` 追加受支持的 alpha.2（联合集合 11 → **12** 个精确发布），编译 pin 前移到 `0.2.3-alpha.2`。冻结副本仍保持 rc.5 字节（8 个发布中 7 个逐字节命中），审计差异即上述两行；不要为了「贴合」把 `upstream.ts` 换成 alpha 字节。alpha.1 不在支持合同内、没有 CI 车道，也没有运行时测试或联合冒烟证据；它只作为源码对照解释接缝来源，alpha.2 是唯一受支持的 0.2.3 发布。
- **客户端复刻同步**：`ui-sidebar-files` 把 Files header 的 actions 槽包进新的 `div.externalActions`、covered 规则改为自定义属性、层级缩进改 `calc(16px + 6px)`、并将 cwd 选择改为 `selectSessionDirectory`（投影 `workingDirectory` ?? 头部 cwd）；`ui-open-in-app` 的 `controller.ts` 重构、`OpenTargetButton.module.css` hover/compact 规则变化。插件 fork 侧：`styles.ts` 同步缩进与 `mrfw-open*` 规则，并新增 `:not(:has(> [data-files-path]))` 守卫的 externalActions unwrap；`controller.ts` / `OpenTargetButton.module.css` 重拷 alpha.2 字节；附加根树的根仍来自 RootSwitcher / `rootForPath`，不从新选择器推导，也不静态 import 旧宿主不存在的 `@deepseek-ai/dsh-api-session-controller/client/directories`（会让整个 client bundle 加载失败）。Files 页头路径、tooltip 与 open-in-app 目标使用 Files 槽位 owner 的 `absolutePath`（上游 `selectSessionDirectory` 解析出的有效目录），不是面板 `list` 的 `view.primaryRoot`（Registry 身份）；`RootsView.effectiveCwd` 仍用于工作区菜单等其它展示。
- **宿主 API 与夹具**：`dsh-client-connection` 的 `HostConnectionService` 构造改为 `(ctx, trustedHosts)` 并要求 `connection.authentication`，无 peer 时路由提前返回（面板公开 RPC 形状不变，只需测试夹具创建 Peer）；`ConnectionService.authenticatedUrl()` 移出，登录 URL 改由新包 `@deepseek-ai/dsh-host-authentication-token` 通过 `webserver/entry-url` 事件贡献（journey 冒烟按「旧方法优先、否则事件收集」兼容两代）；`dsh-app-boot` 的 profile patch 解析新增字段（设置类测试夹具补齐）。`dsh-api-workspace-files` 的 live Session scope 变为有效根、stored Session 用 projection cache，并新增纯增量 `scopeOf()`；Remote 方法形状不变。
- **SSH 地板随核心 pin 前移**：四个可选 SSH 包（`dsh-ssh`、`dsh-fs-ssh`、`dsh-sandbox-ssh`、`dsh-subprocess-ssh`）在 alpha.2 均已发布，上游 `src` 树与 `rc.5` 逐字节相同，因此 `SUPPORTED_SSH_RELEASES` 追加 `0.2.3-alpha.2`（必须保持 `SUPPORTED_DSH_RELEASES` 的后缀），四个 peer range 随 27 个精确发布全量更新，SSH 开发 pin 跟随核心 pin。SSH 能力仍只在 macOS/Linux 开放、默认关闭，缺席或漂移只让 SSH 缺席。
- **无影响接缝**：`fs-local` / `fs`、`sandbox-local` / `sandbox-windows-acl` / `fs-sandbox`、`session-projection`、`storage-*`、`settings`、`subprocess`、`skill`（`TypeError` → `SkillError`）、`lsp` / `lsp-stdio`、`permission-presets`、`commands`、`typert-protocol`、`system-prompt` / `session-query` 的 inject 变化、`agent` / `session`（格式仍 4）。逐接缝证据见[接口审查](../../docs/reference/dsh-0.2.3-migration.md)。
- **安静陷阱 1（Node 下限按发布分代）**：`0.2.3-alpha.2` 起必须 `^24.22.3 || >=26.13.1`；CI 分桶为 22.19 / 24.9 / 24.22.3 三档，开发树与 release 车道同步 24.22.3。插件自身 `engines` 不写死上游下限——运行下限由宿主决定。
- **安静陷阱 2（Auto Review 开发包由合同映射驱动）**：`upgrade-dsh.mjs` 只在目标发布能映射到基线时安装该基线的 21 个开发包；必须先让 alpha 发布进入 `AUTO_REVIEW_CURRENT_RELEASES` 再重跑升级脚本，否则这些包会被删除并留下旧 peer 副本。
- **安静陷阱 3（身份与执行边界分离）**：`policy.workspaceRoot` 只作执行边界/路径基；任何 Registry 键、scope 表查找、面板命令主根都必须用 `session.header.cwd`。这是安全语义，不是「找不到附加根」的可用性问题。
- **安静陷阱 4（客户端包装层）**：新宿主把 actions 槽包进 `div.externalActions`；样式规则必须同时兼容旧直接子节点布局（守卫用 `:not(:has(> [data-files-path))`），且不要复制上游 covered 变量规则（插件 pane 是 portal，不是 `.navigator` 子节点）。
- **quiet trap 5（release-age）**：alpha.2 引入 17 个新传递包与 cordis 生态新版本；漏加 `minimumReleaseAgeExclude` 会让启用发布年龄门禁的 frozen install 失败。`libreoffice-kit`、`cordis-plugin-*`、`cosmokit` 与 schemastery 排除范围已同步。
- **安静陷阱 6（tag 存在不等于可支持）**：`0.2.3-alpha.1` 的源码与发布元数据不一致，发布包无法启动。最小判别是在空目录 `npm install @deepseek-ai/dsh@<release>` 后运行 `dsh --version`；失败即不可作为精确支持发布。
- **安静陷阱 7（profileContext 两代字段）**：0.2.3 前的 `dsh-app-boot.readProfilePatches()` 展开 `context.overlays`，0.2.3 之后展开 `context.overlayPaths`；任何 in-process boot 夹具（`scripts/lib/profile-boot.mjs`、`scripts/smoke-auto-review.mjs`、`scripts/probe-multi-root-skills.mjs`）都必须同时提供两个空数组，否则旧车道 `listPlugins()` / journey 直接抛 `context.overlays is not iterable`。共享 helper `scripts/lib/profile-context.mjs` + `tests/profile-context-fixtures.spec.ts` 守住这一点。
- **安静陷阱 8（PTC 程序格式）**：0.2.3 的 PTC runtime 默认不再是 function-body，顶层 `return` 会报 `Return statement is not allowed here`。程序需要取值时按 `runtime.programFormat` 选择：function-body 用 `return`，其余形态用最终表达式的完成值（`inspect()` 则写入 output）；fixture 与 smoke 不要硬编码某一种。
- **安静陷阱 9（恢复重放的目录证据）**：一条 durable log 可以混有两代目录事件（`working-directory/change` 与 `workspace-root/change`）。进程内的 live event 计数只覆盖本进程实际看到的活动：再次恢复时它可能缺少上一次运行的 live 事件，因此重放不能把整个 seed 前缀都当成旧目录链。宿主登记 working-directory 投影的 `stateVersion` 才是目录代际的结构证据（`0.2.2` 线及更早为 `1`、`0.2.3` 起为 `3`，经公开的投影 `checkpoint()` 读取，绝不做版本号比较）——会话进入附加根、成功读取、再回到主根后，两条候选链终点相同，只有这个版本能判定中途读取该按哪一代语义归因。读不到该版本时，才退回「投影重建目录与两条候选链终点」的比对；两者都无法判定的相对 touch 保守跳过，而不是按可能错误的目录注入 instructions。绝对路径不受影响；OPS 历史校验仍在整条 log 上执行（`touchBoundary` 只限制 touched 路径的记录）。证据优先级、部署默认目录和缓存细节见[接口审查](../../docs/reference/dsh-0.2.3-migration.md#含旧目录事件的快照)。
- **fork 基线**：open-in-app 与 files-tree 的复刻源在 alpha.2 都有变化，基线随本分支重拷并记入各自 `FORK.md`。
- **验证**：本机门禁、vitest、四个 smoke 与 Auto Review 联合冒烟的结果记在[路线账本](../../docs/plans/active/2026-09-12-multi-root-workspace.md#dsh-023-alpha2-兼容提升2026-11-22)；三 OS 矩阵与 Windows ACL 原生结果由 PR 的 CI 给出。
