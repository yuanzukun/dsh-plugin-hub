/**
 * The remote control plane: deployment manifest, remote grant domain, the
 * remote-2 listener/client, and the owner-side admission evaluation. One
 * object owned by `MultiRootRegistry`; it shares the registry's lease,
 * medium, and operation queue but never the v1 records.
 */
import { createHash, randomUUID } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import type { KvTable } from '@deepseek-ai/dsh-storage-domain'
import { openAuthorityStorage } from '../compat/authority-storage.ts'
import type { storeIdentity } from '../authority/native.ts'
import type {
  AdmittedLocalRoot, AdmittedRemoteEndpoint, RemoteAdmission, RemoteEndpointRef, RemoteEndpointVerifier,
  RemoteGrant, RemotePurpose, RemoteSnapshotReply, RemoteStatus,
} from './contract.ts'
import { RemoteAdmissionError } from './contract.ts'
import { bindingDigest, environmentDigest, type loadDeploymentManifest, ManifestError, type DeploymentManifest } from './manifest.ts'
import { loadPersonalManifest, type PersonalManifest } from './personal/config.ts'
import { findBinding, grantState, remoteDomainSpec, REMOTE_TABLE_NAME, type PersistedRemoteGrants } from './records.ts'
import { RemoteClient, RemoteServer, type RemoteRequestTimeouts } from './protocol.ts'

/** The three SSH custody modes (ADR-0049). */
export type RemoteMode = 'personal' | 'team' | 'hardened'

export interface RemoteConfig {
  readonly enabled?: boolean
  /** Initial custody mode; the live value always comes through configure(). */
  readonly mode?: RemoteMode
  readonly manifestPath?: string
  /** Personal-mode config file (user-owned); also enables personal mode. */
  readonly personalPath?: string
  /** Personal-mode credential root (0700, user-owned). */
  readonly credentialRoot?: string
}

/** One live re-evaluation of the plane (ADR-0049 §5). */
export interface RemoteLiveConfig {
  readonly enabled: boolean
  readonly mode: RemoteMode
  /** Live override for the manifest path; falls back to the row's. */
  readonly manifestPath?: string | undefined
}

type Medium = ReturnType<typeof storeIdentity>

/** Evaluate the row config once at construction; failures map to a remote-only state. */
export class RemoteControlPlane {
  /** The live switch; `remoteEnvironments.enabled` is only its initial value. */
  enabled: boolean
  /** The live custody mode (ADR-0049); personal is the default. */
  mode: RemoteMode = 'personal'
  /** The validated deployment manifest; undefined unless remote is enabled and valid. */
  manifest: DeploymentManifest | undefined
  manifestDigest: string | undefined
  /** The live manifest-path override in effect (for the same-config check). */
  liveManifestPath: string | undefined
  /** Personal mode: the config revision and file identity we loaded. */
  personalRevision = 0
  private personalSnapshot: PersonalManifest | undefined
  private state: RemoteStatus
  private domain: { close(): Promise<void> } | undefined
  private table: KvTable<string, PersistedRemoteGrants> | undefined
  private server: RemoteServer | undefined
  client: RemoteClient | undefined
  private revision = 0
  verifier: RemoteEndpointVerifier | undefined
  /** Test hook: overrides for the remote-2 client's per-method request budgets. */
  requestTimeouts: RemoteRequestTimeouts | undefined

  constructor(private readonly config: RemoteConfig | undefined, private readonly logger: { warn(message: string): unknown }, private readonly loadDeploymentForTesting?: typeof loadDeploymentManifest) {
    this.state = { state: 'disabled' }
    this.enabled = false
    this.configure({ enabled: config?.enabled === true, mode: this.profileMode() })
  }

  private profileMode(): RemoteMode {
    const mode = this.config?.mode
    if (mode !== undefined) return mode
    return this.config?.manifestPath === undefined ? 'personal' : 'hardened'
  }

  /** Resolve legacy profile configuration before comparing or opening the plane. */
  effectiveConfig(next: RemoteLiveConfig): RemoteLiveConfig {
    // Deployment fixtures inject their own loader in source tests. No profile
    // configuration or Settings value can supply that constructor dependency.
    if (this.loadDeploymentForTesting !== undefined) return next
    return { enabled: next.enabled === true && next.mode === 'personal' && this.profileMode() === 'personal', mode: 'personal' }
  }

  /**
   * Re-evaluate the plane against new live facts: manifest and digest are
   * reparsed (or dropped) and the state is recomputed. The caller owns the
   * remote teardown and re-open — this method only rebinds the static facts.
   */
  configure(request: RemoteLiveConfig): void {
    const next = this.effectiveConfig(request)
    this.enabled = next.enabled
    this.mode = next.mode
    this.liveManifestPath = next.manifestPath
    this.manifest = undefined
    this.manifestDigest = undefined
    this.personalRevision = 0
    this.personalSnapshot = undefined
    if (!next.enabled) { this.setState('disabled'); return }
    if (process.platform === 'win32') { this.setState('platform-deferred'); return }
    try {
      if (next.mode === 'personal') {
        const path = next.manifestPath ?? this.config?.personalPath
        if (path === undefined || path.trim() === '') throw new ManifestError('manifest-untrusted', 'remoteEnvironments.personalPath is required when personal custody is enabled')
        // A missing file is the empty manifest, not an error.
        const loaded = loadPersonalManifest(path)
        this.manifest = loaded.manifest
        this.manifestDigest = loaded.digest
        this.personalRevision = loaded.revision
        this.personalSnapshot = loaded
      } else {
        const path = next.manifestPath ?? this.config?.manifestPath
        if (path === undefined || path.trim() === '') throw new ManifestError('manifest-untrusted', 'remoteEnvironments.manifestPath is required when the remote experiment is enabled')
        const load = this.loadDeploymentForTesting
        if (load === undefined) throw new ManifestError('manifest-untrusted', 'deployment manifests are unavailable in personal SSH')
        const loaded = load(path)
        this.manifest = loaded.manifest
        this.manifestDigest = loaded.digest
      }
      // Enabled and valid, but nothing remote has been connected/opened yet.
      this.setState('owner-without-remote-protocol')
    } catch (error) {
      this.setState('config-invalid', error instanceof Error ? error.message : String(error))
    }
  }

  /**
   * Personal mode: check both protected stores before every remote operation.
   * A personal reload publishes facts synchronously and retains the grant
   * domain and IPC channel. Invalid facts immediately close admission.
   */
  refreshPersonal(path?: string): 'unchanged' | 'reloaded' | 'disabled' | 'invalid' {
    if (!this.enabled || this.mode !== 'personal' || this.state.state === 'storage-failed') return 'disabled'
    const target = path ?? this.liveManifestPath ?? this.config?.personalPath
    if (target === undefined) return 'disabled'
    let loaded: PersonalManifest
    try {
      loaded = loadPersonalManifest(target, this.personalSnapshot)
      if (loaded === this.personalSnapshot) return 'unchanged'
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error)
      if (this.state.state === 'config-invalid' && this.state.reason === reason) return 'unchanged'
      this.manifest = undefined
      this.manifestDigest = undefined
      this.personalRevision = 0
      this.personalSnapshot = undefined
      this.setState('config-invalid', reason)
      return 'invalid'
    }
    const changed = loaded.digest !== this.manifestDigest
    this.manifest = loaded.manifest
    this.manifestDigest = loaded.digest
    this.personalRevision = loaded.revision
    this.personalSnapshot = loaded
    if (this.table !== undefined && this.state.state === 'config-invalid') this.setState('ready')
    return changed ? 'reloaded' : 'unchanged'
  }

  get status(): RemoteStatus { return this.state }

  private setState(state: RemoteStatus['state'], reason?: string, code?: string): void {
    this.state = {
      state,
      ...(reason === undefined ? {} : { reason }),
      ...(code === undefined ? {} : { code }),
    }
  }

  requireReady(): void {
    if (this.state.state !== 'ready') {
      throw new RemoteAdmissionError('remote-unavailable', `the remote control plane is ${this.state.state}${this.state.reason === undefined ? '' : `: ${this.state.reason}`}`)
    }
  }

  private requireOwner(): void {
    this.requireReady()
    if (this.table === undefined) throw new RemoteAdmissionError('remote-unavailable', 'the remote grant store is closed')
  }

  private grantsOf(key: string): readonly RemoteGrant[] {
    this.requireOwner()
    try {
      return this.table?.get(key)?.grants ?? []
    } catch (error) {
      this.setState('storage-failed', error instanceof Error ? error.message : String(error))
      throw error
    }
  }

  private async persistGrants(key: string, grants: readonly RemoteGrant[]): Promise<void> {
    try {
      await this.table!.put(key, { grants: [...grants] })
      this.revision++
    } catch (error) {
      this.setState('storage-failed', `remote grant store write failed: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  /** Owner-side snapshot; called inside the registry's operation queue. */
  snapshot(key: string, epoch: string): RemoteSnapshotReply {
    this.requireReady()
    return {
      epoch, revision: this.revision, primary: key, manifestDigest: this.manifestDigest!,
      grants: this.grantsOf(key).map(grant => ({ ...grant, state: grantState(this.manifest!, key, grant) })),
    }
  }

  /**
   * Owner-side add; called inside the queue AFTER the verifier ran outside it.
   * Re-checks the binding against the current manifest: a manifest or record
   * change during the verify window is refused rather than written.
   */
  async commitAdd(key: string, ref: RemoteEndpointRef, digest: string, verifiedTarget: RemoteGrant['verifiedTarget'], epoch: string): Promise<RemoteSnapshotReply> {
    this.requireOwner()
    const found = findBinding(this.manifest!, key, ref)
    if (found === undefined || bindingDigest(found.environment, found.binding) !== digest) {
      throw new RemoteAdmissionError('binding-changed', 'the deployment binding changed while the endpoint was being verified; retry the add')
    }
    const grants = this.grantsOf(key)
    const existing = grants.findIndex(grant => grant.environmentId === ref.environmentId && grant.rootId === ref.rootId)
    const record: RemoteGrant = {
      environmentId: ref.environmentId, rootId: ref.rootId, displayPath: found.binding.path,
      verifiedTarget, configVersion: this.manifest!.configVersion, bindingDigest: digest, addedAt: new Date().toISOString(), grantId: randomUUID(),
    }
    if (existing !== -1) {
      const previous = grants[existing]!
      if (previous.bindingDigest === digest && previous.verifiedTarget.kind === verifiedTarget.kind
        && previous.verifiedTarget.value === verifiedTarget.value) return this.snapshot(key, epoch)
    }
    const next = [...grants]
    if (existing === -1) next.push(record)
    else next[existing] = record
    await this.persistGrants(key, next)
    return this.snapshot(key, epoch)
  }

  /** Retire the observed incarnation until an explicit add verifies it again. */
  async withhold(key: string, ref: RemoteEndpointRef, incarnation: string): Promise<void> {
    const grants = this.grantsOf(key)
    const withheldDigest = '0'.repeat(64)
    const matching = grants.find(grant => grant.environmentId === ref.environmentId && grant.rootId === ref.rootId
      && (grant.grantId ?? grant.addedAt) === incarnation)
    if (matching === undefined || matching.bindingDigest === withheldDigest) return
    // Keep the record and its verified identity. A reserved non-manifest digest
    // makes older readers withhold it too, without changing the stored schema.
    await this.persistGrants(key, grants.map(grant => grant === matching ? { ...grant, bindingDigest: withheldDigest } : grant))
  }

  /** Owner-side remove; called inside the queue. */
  async remove(key: string, ref: RemoteEndpointRef, epoch: string): Promise<RemoteSnapshotReply> {
    this.requireReady()
    const grants = this.grantsOf(key)
    const next = grants.filter(grant => !(grant.environmentId === ref.environmentId && grant.rootId === ref.rootId))
    if (next.length === grants.length) throw new RemoteAdmissionError('endpoint-not-registered', `no remote grant is registered for ${ref.environmentId}:${ref.rootId}`)
    await this.persistGrants(key, next)
    return this.snapshot(key, epoch)
  }

  /**
   * Owner-side admission; called inside the queue, same ordering point as
   * `captureSnapshot`/`admit` on the v1 side. `localRecord` resolves a `local`
   * endpoint through the owner's authoritative root state (ADR-0034), so a
   * removed or withheld local root refuses here, ordered with the remote end.
   */
  admit(
    key: string,
    request: { purpose: RemotePurpose; endpoints: readonly RemoteEndpointRef[]; manifestDigest: string },
    epoch: string,
    localRecord: (rootId: string) => AdmittedLocalRoot,
  ): RemoteAdmission {
    this.requireReady()
    if (request.manifestDigest !== this.manifestDigest) {
      throw new RemoteAdmissionError('config-digest-mismatch', 'the deployment manifest digest does not match the owner\'s')
    }
    const manifest = this.manifest!
    const grants = this.grantsOf(key)
    const identities: unknown[] = []
    const admitted = (ref: RemoteEndpointRef): AdmittedRemoteEndpoint => {
      if (ref.environmentId === 'local') {
        const localRoot = localRecord(ref.rootId)
        identities.push([ref.environmentId, ref.rootId, localRoot.path, localRoot.access, localRoot.incarnation])
        return { environmentId: 'local', rootId: ref.rootId, displayPath: ref.rootId, verifiedTarget: null, bindingDigest: null, environmentDigest: null, configVersion: null, localRoot }
      }
      const grant = grants.find(candidate => candidate.environmentId === ref.environmentId && candidate.rootId === ref.rootId)
      if (grant === undefined) throw new RemoteAdmissionError('endpoint-not-registered', `no remote grant is registered for ${ref.environmentId}:${ref.rootId}`)
      const state = grantState(manifest, key, grant)
      if (state === 'revoked') throw new RemoteAdmissionError('endpoint-revoked', `the remote grant for ${ref.environmentId}:${ref.rootId} was revoked`)
      if (state === 'withheld') throw new RemoteAdmissionError('endpoint-withheld', `the remote grant for ${ref.environmentId}:${ref.rootId} is withheld pending re-registration`)
      identities.push([ref.environmentId, ref.rootId, grant.grantId ?? grant.addedAt, grant.bindingDigest, grant.verifiedTarget])
      return {
        environmentId: ref.environmentId, rootId: ref.rootId, displayPath: grant.displayPath,
        verifiedTarget: grant.verifiedTarget, bindingDigest: grant.bindingDigest, configVersion: grant.configVersion,
        environmentDigest: environmentDigest(findBinding(manifest, key, ref)!.environment),
        incarnation: grant.grantId ?? grant.addedAt,
        localRoot: null,
      }
    }
    let endpoints: AdmittedRemoteEndpoint[]
    if (request.purpose === 'transfer') {
      if (request.endpoints.length !== 2) throw new RemoteAdmissionError('invalid-arguments', 'a transfer requires exactly two endpoints')
      const [source, destination] = request.endpoints as [RemoteEndpointRef, RemoteEndpointRef]
      if (source.environmentId === 'local' && destination.environmentId === 'local') {
        throw new RemoteAdmissionError('transfer-pair-not-allowed', 'a remote transfer requires at least one remote endpoint')
      }
      // Registered-with-state before pairing, so a revoked endpoint wins over a pairing error.
      endpoints = [admitted(source), admitted(destination)]
      if (source.environmentId !== 'local' && !findBinding(manifest, key, source)!.binding.transfers?.some(
        transfer => transfer.direction === 'export' && transfer.peer.environmentId === destination.environmentId && transfer.peer.rootId === destination.rootId,
      )) throw new RemoteAdmissionError('transfer-pair-not-allowed', 'the source binding does not export to this destination')
      if (destination.environmentId !== 'local' && !findBinding(manifest, key, destination)!.binding.transfers?.some(
        transfer => transfer.direction === 'import' && transfer.peer.environmentId === source.environmentId && transfer.peer.rootId === source.rootId,
      )) throw new RemoteAdmissionError('transfer-pair-not-allowed', 'the destination binding does not import from this source')
      // The transfer contract is read/export on the source and create/import on
      // the destination: a declared pairing does not widen a binding that never
      // declared the matching action (ADR-0034, "双端准入").
      if (source.environmentId !== 'local' && !findBinding(manifest, key, source)!.binding.actions.includes('read')) {
        throw new RemoteAdmissionError('action-not-allowed', 'the source binding does not allow "read"')
      }
      if (destination.environmentId !== 'local' && !findBinding(manifest, key, destination)!.binding.actions.includes('write')) {
        throw new RemoteAdmissionError('action-not-allowed', 'the destination binding does not allow "write"')
      }
    } else {
      if (request.endpoints.length !== 1 || request.endpoints[0]!.environmentId === 'local') {
        throw new RemoteAdmissionError('invalid-arguments', `${request.purpose} requires exactly one remote endpoint`)
      }
      const ref = request.endpoints[0]!
      const binding = findBinding(manifest, key, ref)
      const endpoint = admitted(ref)
      if (!binding!.binding.actions.includes(request.purpose)) {
        throw new RemoteAdmissionError('action-not-allowed', `the binding for ${ref.environmentId}:${ref.rootId} does not allow "${request.purpose}"`)
      }
      endpoints = [endpoint]
    }
    const authorizationFingerprint = createHash('sha256').update(JSON.stringify([key, request.purpose, identities])).digest('hex')
    return { decision: 'admit', epoch, authorizationFingerprint, primary: key, endpoints }
  }

  /** Verify outside the queue; the queued recheck is {@link commitAdd}. */
  async verifiedAddTarget(
    key: string,
    ref: RemoteEndpointRef,
    signal: AbortSignal,
  ): Promise<{ digest: string; verifiedTarget: RemoteGrant['verifiedTarget'] }> {
    this.requireOwner()
    const found = findBinding(this.manifest!, key, ref)
    if (found === undefined) throw new RemoteAdmissionError('binding-not-authorized', `no deployment binding authorizes ${ref.environmentId}:${ref.rootId} for this primary root`)
    if (this.verifier === undefined) throw new RemoteAdmissionError('endpoint-unverifiable', 'no remote endpoint verifier is configured; remote endpoints cannot be registered')
    const verified = await this.verifier.verify(found.environment, found.binding, signal)
    if (verified.platform !== found.environment.platform) {
      throw new RemoteAdmissionError('platform-mismatch', `the endpoint reports platform "${verified.platform}" but the manifest declares "${found.environment.platform}"`)
    }
    if (verified.target === undefined || (verified.target.kind !== 'object' && verified.target.kind !== 'path') || typeof verified.target.value !== 'string' || verified.target.value === '' || verified.target.value.length > 512) {
      throw new RemoteAdmissionError('endpoint-unverifiable', 'the endpoint verifier did not return a usable target identity')
    }
    return { digest: bindingDigest(found.environment, found.binding), verifiedTarget: verified.target }
  }

  /**
   * Open the remote domain and the remote-2 listener under the held lease.
   * Failures degrade the remote side only — the local registry commits normally.
   */
  async openOwner(ctx: Context, medium: Medium, epoch: string, dispatch: (method: string, args: unknown[], manifestDigest?: string, signal?: AbortSignal) => Promise<unknown>): Promise<void> {
    if (!this.enabled || (this.manifest === undefined && !(this.mode === 'personal' && this.state.state === 'config-invalid'))) return
    // A retryable v1 failure keeps this handle open; never stack a second one.
    await this.closeOwner()
    try {
      const domain = await openAuthorityStorage(ctx, medium.root, remoteDomainSpec)
      try {
        this.server = await RemoteServer.listen(medium.remoteEndpoint!, { store: medium.id, epoch, manifestDigest: () => this.digestForHello() }, dispatch)
      } catch (error) {
        // The listener is for followers; a failure must not block owner-side ops.
        this.logger.warn(`multi-root-workspace: remote-2 listener failed (${error instanceof Error ? error.message : String(error)}); followers cannot reach the remote plane`)
      }
      this.domain = domain
      this.table = domain.table(REMOTE_TABLE_NAME) as KvTable<string, PersistedRemoteGrants>
      if (this.manifest !== undefined) this.setState('ready')
    } catch (error) {
      this.setState('storage-failed', error instanceof Error ? error.message : String(error))
    }
  }

  private digestForHello(): string | undefined {
    if (this.mode !== 'personal') return this.manifestDigest
    const path = this.liveManifestPath ?? this.config?.personalPath
    if (path === undefined) return undefined
    try { return loadPersonalManifest(path, this.personalSnapshot).digest } catch { return undefined }
  }

  notifyFollowers(): void { this.server?.changed() }

  /** The v1 store failed: stop serving remote admission too. */
  ownerFailed(reason: string): void {
    this.server?.close(); this.server = undefined
    if (this.enabled) this.setState('storage-failed', reason)
  }

  async closeOwner(): Promise<void> {
    this.server?.close(); this.server = undefined
    const domain = this.domain
    this.domain = undefined; this.table = undefined
    if (domain !== undefined) { try { await domain.close() } catch { /* teardown must not throw */ } }
  }

  /**
   * Follower-side: adopt the remote-2 channel of the just-connected v1 epoch.
   * Never throws — failures become the remote state.
   */
  async connectFollower(medium: Medium, epoch: string, changed: () => void = () => {}): Promise<void> {
    if (!this.enabled || this.manifest === undefined) return
    try {
      const adopted: { client: RemoteClient | undefined } = { client: undefined }
      const client = await RemoteClient.connect(medium.remoteEndpoint!, medium.id, this.manifestDigest!, () => {
        if (adopted.client === undefined) return
        const current = this.client === adopted.client
        adopted.client = undefined
        if (current) {
          this.client = undefined
          if (this.state.state === 'ready') this.setState('owner-without-remote-protocol', 'the remote channel closed')
        }
      }, this.requestTimeouts, changed)
      adopted.client = client
      if (client.epoch !== epoch) { client.close(); adopted.client = undefined; this.setState('epoch-mismatch', 'the remote-2 epoch differs from the v1 authority epoch'); return }
      this.client = client
      this.setState('ready')
    } catch (error) {
      const code = (error as { code?: unknown })?.code
      const message = error instanceof Error ? error.message : String(error)
      if (code === 'config-digest-mismatch') this.setState('config-digest-mismatch', 'the owner serves a different deployment manifest')
      else if (message === 'registry authority is not ready') {
        // The v1 lease is held by another Host, but that owner never opened
        // the remote-2 listener. This is the common "desktop host owns the
        // store, web host runs the SSH plugin" shape; a restart of the
        // follower cannot heal it. Surface an actionable diagnostic instead
        // of the raw socket-connect text.
        this.logger.warn('multi-root remote: the Registry owner does not serve the SSH remote plane; quit the other DSH instance or run the SSH-enabled profile as the only Host')
        this.setState('owner-without-remote-protocol', message, 'owner-without-remote-plane')
      } else this.setState('owner-without-remote-protocol', message)
    }
  }

  /** The v1 client died: the remote channel dies with it; a new epoch needs a new hello. */
  dropFollower(): void {
    const client = this.client
    this.client = undefined
    client?.close()
    if (this.enabled && this.manifest !== undefined && this.state.state === 'ready') {
      this.setState('owner-without-remote-protocol', 'the remote channel closed with the registry connection')
    }
  }

  /** Follower-side remote-2 request; AuthorityRpcError propagates with its code. */
  async remoteRequest(method: 'remote-snapshot' | 'remote-add' | 'remote-remove' | 'remote-admit' | 'remote-withhold', args: readonly unknown[]): Promise<unknown> {
    const client = this.client
    if (client === undefined) throw new RemoteAdmissionError('owner-without-remote-protocol', 'the remote control plane has no live remote-2 channel')
    try {
      return await client.request(method, args, this.manifestDigest)
    } catch (error) {
      const code = (error as { code?: unknown })?.code
      throw new RemoteAdmissionError(typeof code === 'string' ? code : 'remote-unavailable', error instanceof Error ? error.message : String(error))
    }
  }
}
