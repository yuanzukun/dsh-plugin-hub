import { withRegistryRead, withRegistryAdmission } from './registry-operation.ts'
/**
 * `multi-root-instructions`: the additional roots' own instruction files, made
 * visible to the model.
 *
 * Upstream `agent-instructions` discovers instruction files by walking UP from
 * the session cwd (plus the one user-global file). In a multi-root workspace
 * that walk never reaches an additional root, so `repo-b/AGENTS.md` is
 * invisible to a model that is nevertheless allowed to write `repo-b`. This row
 * closes exactly that gap, and nothing else: the primary root's chain — nested
 * files included — and the user-global file stay upstream's business.
 *
 * Four deliberate choices:
 *
 * 1. **Not a system-prompt contribution.** Instruction text is
 *    producer-supplied context, not system authority, so it enters as a
 *    user-role message tagged `form: 'instructions'`. Through session format 3
 *    the source kind is `plugin`; format 4 retired that shared kind, so the
 *    adapter persists this plugin's own (`multi-root-workspace`). It is also
 *    the only channel that is logged, and model-visible content must be logged.
 * 2. **Injected from `agent/pre-step`, not a session lifecycle event.**
 *    `pre-step` is an awaited waterfall, so discovery, reading and rendering all
 *    complete BEFORE the step it feeds — deterministically, on the first step.
 *    A synchronous prompt callback could not await them, and an emit-mode
 *    lifecycle listener would race the first step. It is also the one hook whose
 *    shape is identical across every supported release, which keeps the
 *    instruction feature out of the compatibility matrix (ADR-0009).
 * 3. **Discovery is pinned to the root.** `projectRoot` is the additional root,
 *    so the walk can never leave it, and every candidate is then required to be
 *    canonically INSIDE that root. That is what keeps `$DSH_HOME/AGENTS.md`, the
 *    primary root's `AGENTS.md`, and any ancestor's file from being injected a
 *    second time by this plugin.
 * 4. **Nested files are driven by the session's own tool activity.** A
 *    subdirectory's `AGENTS.md` only matters once the session has worked in that
 *    subdirectory, so the directories worth examining are derived from the
 *    session's persisted events: `tool/call` and `tool/result` are paired, and a
 *    successful `read`/`write`/`edit` makes the path from the root down to the
 *    touched file's directory relevant (ADR-0010). A file that disappears is
 *    retracted explicitly, because the text it contributed earlier is still in
 *    the conversation and silence does not withdraw it.
 *
 * The byte budget is shared: `maxBytes` bounds the WHOLE additional-root
 * snapshot, not each root, because ten roots must not quietly cost ten budgets
 * of context. Roots consume it in scope order. Retractions are exempt, because a
 * truncated withdrawal is worse than a slightly over-budget message.
 *
 * @module @dsh-electron/dsh-plugin-multi-root-workspace/instructions
 */

import { createHash } from 'node:crypto'
import { stat as nodeStat } from 'node:fs/promises'
import { AsyncLocalStorage } from 'node:async_hooks'
import { basename, dirname, isAbsolute, relative, resolve, sep } from 'node:path'
import { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-agent'
import type { OpsFileActivityInput, OpsFileTarget } from './compat/instruction-activity.ts'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { FileSystem } from '@deepseek-ai/dsh-fs'
import type { UserMessage } from '@deepseek-ai/dsh-llm'
import { canonicalPath } from '@deepseek-ai/dsh-sandbox'
import type {} from '@deepseek-ai/dsh-sandbox-policy'
import type {} from './compat.ts'
import type {} from './providers.ts'
import { instructionsApi } from './compat/agent-instructions.ts'
import type { InstructionFile, InstructionsApi, LoadedInstructionFile } from './compat/agent-instructions.ts'
import { createInstructionMessage } from './compat/llm-message.ts'
import { toolResultFailed } from './compat/tool-result.ts'
import { effectiveDirectory } from './compat/session-directory.ts'
import { aroundTool, type ToolCaller } from './compat/tool-context.ts'
import { FILE_TOUCH_TOOL_NAMES, normalizeOpsFileActivity, opsActivityEvidenceKey, ptcFileActivity, replayedInstructionTargets, stableOpsJson, touchedPathOfToolCall } from './compat/instruction-activity.ts'
import { opsCompatibilityToken } from './compat/ops-settings.ts'
import { nativeInstructionCopies } from './compat/instruction-overlap.ts'
import { isCanonicallyUnder } from './roots.ts'
import type {} from './scope.ts'

declare module '@deepseek-ai/cordis' {
  interface Context {
    multiRootInstructions: {
      knownRoots(session: object): readonly string[]
      snapshot(agent: Agent, roots: readonly string[], target: string | readonly string[] | undefined, signal: AbortSignal,
        pending?: { readonly callId: string; readonly name: string; readonly arguments: unknown; readonly parent?: unknown }): Promise<readonly CurrentRootInstruction[]>
    }
  }
}

/** Current constraints; never delivery deltas or authorization. */
export interface CurrentRootInstruction {
  readonly root: string
  readonly path: string
  readonly relativeDirectory: string
  readonly digest: string
  readonly text: string
}

/** The `plugin` attribution every message this row produces carries. */
export const PLUGIN_SOURCE = '@dsh-electron/dsh-plugin-multi-root-workspace'

/**
 * Total UTF-8 byte budget for the additional-root snapshot, matching the
 * default the upstream `agent-instructions` row is composed with so that one
 * extra workspace root costs at most as much as the primary one does.
 */
export const DEFAULT_MAX_BYTES = 65536

/** Largest instruction file this row will read; larger files are ignored. */
export const DEFAULT_MAX_SOURCE_BYTES = 32768

// A successful read/write/edit makes the directories on the path to the file
// relevant; FILE_TOUCH_TOOL_NAMES is shared with the review-context replay.

/** Cap on unanswered `tool/call` records remembered per session. */
const MAX_PENDING_CALLS = 128
const MAX_LIVE_OPS_CALLS = 128
const MAX_LIVE_OPS_OBSERVED = 64
const MAX_LIVE_OPS_EVIDENCE = 128

/** Cap on touched paths remembered per session; beyond it, touches are dropped. */
const MAX_TOUCHED_PATHS = 64

/** Cap on delivered scopes remembered per session; beyond it, nested scopes stop. */
const MAX_DELIVERED_SCOPES = 512

/** Plugin configuration for the `multi-root-instructions` row. */
export interface Config {
  /** Total budget for ALL additional roots (default {@link DEFAULT_MAX_BYTES}); non-positive disables the row. */
  readonly maxBytes?: number
  /** Per-file source cap (default {@link DEFAULT_MAX_SOURCE_BYTES}). */
  readonly maxSourceBytes?: number
  /** Ordered same-directory instruction candidates; upstream's defaults when omitted. */
  readonly instructionFileCandidates?: readonly string[]
  /** Ordered same-directory local-overlay candidates; upstream's defaults when omitted. */
  readonly localInstructionFileCandidates?: readonly string[]
}

/** One instruction file the model has already been told about. */
interface DeliveredScope {
  /** The additional root the file belongs to. */
  readonly root: string
  /** The file's absolute path. */
  readonly path: string
  /** SHA-256 of fully delivered content; undefined means partial or withdrawn delivery needs retry. */
  readonly digest: string | undefined
  /** Native display scope when upstream supplied the copy instead of this row. */
  readonly nativePath?: string
}

/** One session's delivery state: what was delivered, and what is worth looking at. */
interface SessionState {
  /** Delivered instruction files, keyed by {@link scopeKey}. */
  readonly scopes: Map<string, DeliveredScope>
  /** Historical provenance, retained after delivery withdrawal; never grants access. */
  readonly provenanceRoots: Set<string>
  /** Absolute paths touched by a successful tool call since the last evaluation. */
  readonly touched: Set<string>
  /** Successful work index retained independently of delivery deltas. */
  readonly worked: Set<string>
  readonly liveOpsEvidence: Map<string, { readonly targets: readonly OpsFileTarget[]; readonly complete: boolean }>
  activityIncomplete?: boolean
  overflow?: boolean
}

/** Unanswered `tool/call` records, by call id, so a result can name its tool. */
type PendingCalls = Map<string, { readonly name: string; readonly arguments: string; readonly cwd: string | undefined; observedPath?: string }>

/** One root's freshly rendered instruction text. */
export interface RenderedRoot {
  /** The canonical additional root. */
  readonly root: string
  /** The rendered instruction text. */
  readonly text: string
}

/** One instruction file that is no longer present. */
export interface RemovedScope {
  /** The additional root it belonged to. */
  readonly root: string
  /** The instruction file's absolute path. */
  readonly path: string
}

/** Digest one file's content. Content-addressed, so identical content never re-sends. */
function digestOf(text: string): string {
  return createHash('sha256').update(text).digest('hex')
}

/**
 * The scope identity of one candidate instruction file.
 *
 * NUL-joined, so two additional roots carrying the same relative
 * `AGENTS.md` can never collide on one key.
 * @param root - the canonical additional root.
 * @param relativeDirectory - the file's directory, relative to the root, `.` for the root itself.
 * @param fileName - the instruction file's name.
 * @returns the scope key.
 */
function scopeKey(root: string, relativeDirectory: string, fileName: string): string {
  return `${root}\0${relativeDirectory}\0${fileName}`
}

/** A directory's location within its root, spelled `.` for the root itself. */
function relativeDirectoryOf(root: string, directory: string): string {
  const suffix = relative(root, directory)
  return suffix.length === 0 ? '.' : suffix
}

/**
 * The path one RAW tool call touched.
 *
 * `arguments` is the model-produced JSON string, so the path is only known after
 * parsing it; a call that names no `file_path`, or is not one of the tools whose
 * success makes a directory relevant, touched nothing this row cares about.
 * @param name - the tool name the model called.
 * @param argumentsJson - the tool call's raw arguments, exactly as produced.
 * @returns the trimmed absolute-or-relative path, or `undefined`.
 */
export { touchedPathOfToolCall } from './compat/instruction-activity.ts'

/**
 * The directory a touched path's instructions would live in.
 *
 * Tool arguments are the model's raw input, so a relative `file_path` is
 * captured as an absolute path at the operation boundary. Mac's `realpath`
 * spelling is applied here so it compares against the canonical roots.
 * @param path - the absolute touched file path.
 * @returns the canonical parent directory, or `undefined` when it cannot be named.
 */
function parentDirectoryOf(path: string): string | undefined {
  const absolute = isAbsolute(path) ? path : undefined
  if (absolute === undefined) return undefined
  try {
    return canonicalPath(dirname(absolute))
  } catch {
    return undefined
  }
}

/** Cap warnings are emitted once per process; the cap itself is not user-facing. */
let scopeCapWarned = false

/**
 * Compose the model-facing message body for one batch of changes.
 *
 * All three halves matter. A newly visible root — or a newly touched
 * subdirectory — needs its rules; a root that left needs an explicit
 * revocation; and a file that disappeared needs an explicit withdrawal, because
 * the instructions it contributed are still sitting in the conversation history
 * and would otherwise keep applying forever. Silence is not a retraction.
 * @param rendered - roots whose instruction text is new or changed.
 * @param revoked - canonical roots that left the workspace scope.
 * @param removed - instruction files that are no longer present.
 * @returns the message text, or `undefined` when there is nothing to say.
 */
export function composeInstructionMessage(
  rendered: readonly RenderedRoot[],
  revoked: readonly string[],
  removed: readonly RemovedScope[],
): string | undefined {
  if (rendered.length === 0 && revoked.length === 0 && removed.length === 0) return undefined
  const sections: string[] = [
    'Additional workspace root instructions. The directories below are additional roots of this '
    + "session's workspace; the instruction files found at their top level, and in the subdirectories "
    + 'this session has worked in, follow, and they apply to work in those directories exactly as this '
    + 'workspace\'s own instructions apply to the session root.',
  ]
  for (const entry of rendered) {
    sections.push(`Instructions for additional workspace root ${entry.root}:\n\n${entry.text}`)
  }
  for (const root of revoked) {
    sections.push(
      `The directory ${root} is no longer an additional root of this session's workspace. Any instructions `
      + 'previously supplied for it in this conversation no longer apply, and it is no longer writable here.',
    )
  }
  // Sorted, so the same world state always renders the same text.
  for (const scope of [...removed].sort((left, right) => (left.path < right.path ? -1 : left.path > right.path ? 1 : 0))) {
    sections.push(
      `The instruction file ${scope.path} is no longer present in the additional workspace root `
      + `${scope.root}, so the instructions it supplied earlier no longer apply.`,
    )
  }
  return sections.join('\n\n')
}

/** This row is gated on the compatibility contract like every other provider. */
// `multiRootProviders` is the provider-conflict gate: a foreign `ctx.fs` or
// `ctx.sandbox` must not end up named by this row's root list.
export const inject = ['multiRootCompat', 'multiRootProviders', 'multiRootScope', 'sandboxPolicy']

/**
 * Mount the additional-root instruction provider.
 *
 * `fs` is a SOFT dependency, like the scope service's prompt contribution: a
 * composition with no filesystem seam (headless probes, bare test contexts)
 * contributes nothing instead of failing to load. The same is true of the
 * upstream instruction package, which is an optional peer.
 *
 * Touch recording is registered OUTSIDE the `fs` injection, so a composition
 * without a filesystem seam still learns which directories the session worked
 * in; delivery is what needs the seam.
 * @param ctx - the row's context.
 * @param config - the row's configuration.
 */
export function apply(ctx: Context, config: Config = {}): void {
  const maxBytes = config.maxBytes ?? DEFAULT_MAX_BYTES
  if (maxBytes <= 0 || !Number.isFinite(maxBytes)) return

  const states = new WeakMap<object, SessionState>()
  const callsBySession = new WeakMap<object, PendingCalls>()
  const executions = new AsyncLocalStorage<ToolCaller>()

  const fingerprintOf = (value: unknown): string => createHash('sha256').update(stableOpsJson(value)).digest('hex')
  const record = (value: unknown): value is Record<string, unknown> => value !== null && typeof value === 'object'
  interface LiveCall {
    readonly exec: ToolCaller
    readonly session: object
    readonly agent: Agent
    readonly token: object
    readonly kind: 'native' | 'ptc'
    readonly callId: string
    readonly name: string
    readonly args: unknown
    readonly argsJson: string
    readonly cwd: string | undefined
    readonly observed: Set<string>
    readonly mode: object
    readonly signal?: AbortSignal | undefined
    fingerprint?: string | undefined
    incomplete?: boolean | undefined
    abort?: (() => void) | undefined
  }
  const keyOf = (exec: ToolCaller): object => (exec.token ?? exec) as object
  let disposed = false
  const opsLive = new Map<object, LiveCall>()
  const removeEntry = (key: object): LiveCall | undefined => {
    const call = opsLive.get(key)
    if (call === undefined) return undefined
    if (call.signal !== undefined && call.abort !== undefined) call.signal.removeEventListener('abort', call.abort)
    opsLive.delete(key)
    return call
  }
  const boundedLiveSet = (key: object, call: LiveCall) => {
    if (opsLive.size >= MAX_LIVE_OPS_CALLS) {
      const oldest = opsLive.keys().next()
      if (!oldest.done) {
        const evicted = removeEntry(oldest.value)
        if (evicted !== undefined && evicted.mode === opsCompatibilityToken(ctx)) stateOf(evicted.session).activityIncomplete = true
      }
    }
    opsLive.set(key, call)
  }
  const putEvidence = (state: SessionState, key: string, entry: { readonly targets: readonly OpsFileTarget[]; readonly complete: boolean }) => {
    const existing = state.liveOpsEvidence.get(key)
    if (existing !== undefined) {
      const same = existing.complete === entry.complete && JSON.stringify(existing.targets) === JSON.stringify(entry.targets)
      if (same) return
      if (existing.complete === true) { state.activityIncomplete = true; return }
    } else if (state.liveOpsEvidence.size >= MAX_LIVE_OPS_EVIDENCE) {
      const oldest = state.liveOpsEvidence.keys().next()
      if (!oldest.done) state.liveOpsEvidence.delete(oldest.value)
      state.activityIncomplete = true
    }
    state.liveOpsEvidence.set(key, entry)
  }
  const mark = (call: LiveCall) => {
    if (call.mode !== opsCompatibilityToken(ctx)) return
    const state = stateOf(call.session)
    state.activityIncomplete = true
    try {
      putEvidence(state, opsActivityEvidenceKey(call.kind, call.callId, call.name, call.args), { targets: [], complete: false })
    } catch (error) {
      ctx.logger.warn(`multi-root instructions: OPS activity key failed: ${(error as Error).message}`)
    }
  }
  aroundTool(ctx, (exec, next) => executions.run(exec, () => runLive(exec, next)))
  const runLive = async (exec: ToolCaller, next: () => Promise<unknown>): Promise<unknown> => {
    const agent = exec.agent
    const bare = exec.name.startsWith('ops_') ? exec.name.slice(4) : ''
    const modeToken = opsCompatibilityToken(ctx)
    if (bare === '' || bare === 'discover_tools' || bare === 'load_sdk' || agent === undefined || disposed || modeToken === undefined) return await next()
    let argsJson = ''
    let incomplete = false
    try {
      argsJson = stableOpsJson(exec.arguments)
    } catch {
      incomplete = true
    }
    const directories = ctx.get('workingDirectory') as { ensure(agent: Agent, signal?: AbortSignal): Promise<string | undefined> } | undefined
    const ensured = directories === undefined ? undefined : await directories.ensure(agent, exec.signal).catch(() => undefined)
    if (disposed || opsCompatibilityToken(ctx) !== modeToken) return await next()
    const cwd = ensured ?? effectiveDirectory(ctx, agent.session) ?? agent.session?.header?.cwd
    const call: LiveCall = {
      exec, session: agent.session, agent, token: keyOf(exec),
      kind: exec.parent === undefined ? 'native' : 'ptc',
      callId: exec.callId, name: exec.name,
      args: incomplete ? undefined : JSON.parse(argsJson) as unknown, argsJson, cwd,
      observed: new Set(), incomplete, signal: exec.signal, mode: modeToken,
    }
    if (exec.signal?.aborted === true) {
      mark(call)
      return await next()
    }
    boundedLiveSet(call.token, call)
    call.abort = () => {
      const removed = removeEntry(call.token)
      if (removed !== undefined) mark(removed)
    }
    call.signal?.addEventListener('abort', call.abort)
    let result: unknown
    try {
      result = await next()
    } catch (error) {
      removeEntry(call.token)
      throw error
    }
    if (call.mode !== opsCompatibilityToken(ctx)) { removeEntry(call.token); return result }
    try {
      const raw = result !== null && typeof result === 'object' && 'value' in (result as object)
        ? (result as { value?: unknown }).value : result
      call.fingerprint = fingerprintOf(raw)
    } catch {
      call.incomplete = true
      ctx.logger.warn('multi-root instructions: OPS activity fingerprint exceeded its budget')
    }
    return result
  }
  const onResult = ctx.on as unknown as (name: string, callback: (exec: ToolCaller, result: unknown) => void, options: { global: boolean }) => unknown
  onResult.call(ctx, 'tools/result', (exec, result) => {
    const call = removeEntry(keyOf(exec))
    if (call === undefined) return
    if (call.mode !== opsCompatibilityToken(ctx)) return
    try {
      const final = result as { value?: unknown; isError?: boolean }
      const sameArgs = (() => { try { return stableOpsJson(exec.arguments) === call.argsJson } catch { return false } })()
      const identity = exec === call.exec && keyOf(exec) === call.token && exec.agent?.session === call.session
        && exec.name === call.name && exec.callId === call.callId && sameArgs
        && exec.signal?.aborted !== true && !disposed && call.incomplete !== true
      const effectNone = final.isError === true && record(final.value)
        && record((final.value as Record<string, unknown>).error)
        && (final.value as { error: { effectState?: unknown } }).error.effectState === 'none'
      if (!identity || call.fingerprint === undefined) { mark(call); return }
      let same = false
      try {
        same = fingerprintOf(final.value) === call.fingerprint
      } catch {
        ctx.logger.warn('multi-root instructions: OPS final fingerprint exceeded its budget')
      }
      if (!same) { mark(call); return }
      if (final.isError === true) {
        if (effectNone === true) {
          try {
            putEvidence(stateOf(call.session), opsActivityEvidenceKey(call.kind, call.callId, call.name, call.args), { targets: [], complete: true })
          } catch {
            mark(call)
          }
        } else mark(call)
        return
      }
      const activity = normalizeOpsFileActivity({
        name: call.name, args: call.args, cwd: call.cwd, finalValue: final.value,
        observedPaths: [...call.observed],
      } as OpsFileActivityInput)
      const state = stateOf(call.session)
      if (!activity.complete) state.activityIncomplete = true
      for (const target of activity.targets) {
        if (state.worked.size >= MAX_DELIVERED_SCOPES && !state.worked.has(target.path)) state.overflow = true
        else state.worked.add(target.path)
        if (state.touched.size >= MAX_TOUCHED_PATHS) state.overflow = true
        else state.touched.add(target.path)
      }
      try {
        putEvidence(state, opsActivityEvidenceKey(call.kind, call.callId, call.name, call.args), {
          targets: activity.targets, complete: activity.complete,
        })
      } catch {
        mark(call)
      }
    } catch (error) {
      ctx.logger.warn(`multi-root instructions: live OPS activity observer failed: ${(error as Error).message}`)
      mark(call)
    }
  }, { global: true })
  const onDispose = ctx.on as unknown as (name: string, callback: (target: never) => void, options: { global: boolean }) => unknown
  onDispose.call(ctx, 'agent/disposed', (payload: { agent: Agent }) => {
    for (const [key, call] of [...opsLive]) if (call.agent === payload.agent) removeEntry(key)
  }, { global: true })
  onDispose.call(ctx, 'session/disposed', (session: object) => {
    for (const [key, call] of [...opsLive]) if (call.session === session) removeEntry(key)
  }, { global: true })
  ctx.effect(() => () => {
    disposed = true
    for (const key of [...opsLive.keys()]) removeEntry(key)
  })
  const stateOf = (session: object): SessionState => {
    const existing = states.get(session)
    if (existing !== undefined) return existing
    const created: SessionState = { scopes: new Map(), provenanceRoots: new Set(), touched: new Set(), worked: new Set(), liveOpsEvidence: new Map() }
    states.set(session, created)
    return created
  }

  // The session log is the only seam that carries tool activity without
  // depending on the tool layer's own package: `tool/call` records the raw
  // arguments, `tool/result` names the call it answers, and a pairing is a
  // directory the session has worked in.
  ctx.on('session/event', (session, event) => {
    const pendingCalls = callsBySession.get(session) ?? new Map()
    callsBySession.set(session, pendingCalls)
    const ptc = ptcFileActivity(event)
    if (event.type === 'tool/call' || ptc?.kind === 'start') {
      if (pendingCalls.size >= MAX_PENDING_CALLS) {
        const oldest = pendingCalls.keys().next()
        if (!oldest.done) pendingCalls.delete(oldest.value)
      }
      const call = ptc?.kind === 'start' ? {callId:ptc.id,name:ptc.name,arguments:ptc.arguments} : event.type === 'tool/call' ? event.data : undefined
      if (call !== undefined) pendingCalls.set(call.callId, { name: call.name, arguments: call.arguments, cwd: effectiveDirectory(ctx, session) })
      return
    }
    if (event.type !== 'tool/result' && ptc?.kind !== 'end') return
    const callId = ptc?.kind === 'end' ? ptc.id : event.type === 'tool/result' ? event.data.message.source.callId : ''
    const call = pendingCalls.get(callId)
    pendingCalls.delete(callId)
    if (call === undefined) return
    // A failed call never makes a directory relevant: the file may not have
    // been reached at all. The failure bit moved between releases; the adapter
    // reads both spellings.
    if (ptc?.kind === 'end' ? ptc.failed : event.type === 'tool/result' && (event.data.error !== undefined || toolResultFailed(event.data.message))) return
    const path = call.observedPath ?? touchedPathOfToolCall(call.name, call.arguments)
    if (path === undefined) return
    const state = stateOf(session)
    const absolute = isAbsolute(path) ? path : call.cwd === undefined ? undefined : resolve(call.cwd, path)
    if (absolute !== undefined) {
      if (state.worked.size >= MAX_DELIVERED_SCOPES && !state.worked.has(absolute)) state.overflow = true
      else state.worked.add(absolute)
    }
    if (state.touched.size >= MAX_TOUCHED_PATHS) return
    if (isAbsolute(path)) state.touched.add(path)
    else if (call.cwd !== undefined) state.touched.add(resolve(call.cwd, path))
  })

  ctx.inject(['fs'], (scope: Context) => {
    scope.provide('multiRootInstructions', {
      knownRoots(session) { return [...(states.get(session)?.provenanceRoots ?? [])] },
      async snapshot(agent, roots, target, signal, pending) {
        const modeToken = opsCompatibilityToken(scope)
        const snapshot = await withRegistryRead(scope, scope.sandboxPolicy.resolve({ session: agent.session }).workspaceRoot, 'instructions', async () => {
        if (opsCompatibilityToken(scope) !== modeToken) throw new Error('review-context: OPS compatibility changed during the snapshot; retry')
        const allowed = new Set(scope.multiRootScope.scopeOf(scope.sandboxPolicy.resolve({ session: agent.session }).workspaceRoot))
        roots = roots.filter(root => allowed.has(root))
        signal.throwIfAborted()
        const existing = states.get(agent.session)
        if (existing?.overflow) throw new Error('review-context: successful work index exceeded')
        if (modeToken !== undefined && existing?.activityIncomplete === true) throw new Error('review-context: incomplete OPS file activity')
        // Copy the scope index; invalidate ONLY this copy's digests to collect
        // all current files, including unchanged and formerly native copies.
        const state: SessionState = {
          scopes: new Map([...(existing?.scopes ?? [])].map(([key, value]) => [key, { ...value, digest: undefined }])),
          provenanceRoots: new Set(existing?.provenanceRoots),
          touched: new Set([...(existing?.touched ?? []), ...(existing?.worked ?? [])]),
          worked: new Set(),
          liveOpsEvidence: new Map(existing?.liveOpsEvidence ?? []),
        }
        // Seed events do not publish session/event on resume. Read their
        // successful activity without mutating the main agent's delivery index.
        // oxlint-disable-next-line typescript/no-deprecated -- No public activity projection exists.
        for (const path of replayedInstructionTargets(agent.session.snapshotEvents(), agent.session.header.cwd,
          modeToken === undefined ? undefined : existing?.liveOpsEvidence,
          modeToken === undefined ? undefined : pending,
          { opsCompatibility: modeToken !== undefined })) state.touched.add(path)
        const targets = typeof target === 'string' ? [target] : target ?? []
        for (const item of targets) state.touched.add(item)
        if (roots.length === 0) return []
        const api = await instructionsApi()
        if (api === undefined) throw new Error('review-context: instruction discovery unavailable')
        // Native discovery can already cover this directory before any file
        // tool succeeds. Recollect that chain before replacing native frames,
        // without recording cwd as successful activity or delivery state.
        const cwd = effectiveDirectory(scope, agent.session)
        const reviewCwd = cwd === undefined ? undefined : canonicalPath(cwd)
        const result: CurrentRootInstruction[] = []
        for (const root of roots) {
          const plan = await planRoot(scope, api, root, config, state, signal, true, reviewCwd)
          for (const {file} of plan.deliveries) {
            result.push({ root, path: file.absolutePath, relativeDirectory: relativeDirectoryOf(root, dirname(file.absolutePath)),
              digest: digestOf(file.content), text: file.content })
          }
        }
        signal.throwIfAborted()
        // Metadata counts too, and no partial constraint is ever returned.
        if (Buffer.byteLength(JSON.stringify(result), 'utf8') > maxBytes) throw new Error('review-context: instruction budget exceeded')
        if (opsCompatibilityToken(scope) !== modeToken) throw new Error('review-context: OPS compatibility changed during the snapshot; retry')
        return result
        })
        if (opsCompatibilityToken(scope) !== modeToken) throw new Error('review-context: OPS compatibility changed during the snapshot; retry')
        return snapshot
      },
    })
    // Native tools report the actual canonical target with their execution as
    // actor. Prefer it over a pre-dispatch cwd snapshot: ensure() may recover a
    // missing cwd, and a directory change can race the tool's async resolution.
    const onObserved = scope.on as unknown as (name: 'fs/observed', callback: (target: Parameters<typeof scope.fs.processPath>[0], observation: unknown, actor: unknown) => void, options: { global: boolean }) => void
    onObserved.call(scope, 'fs/observed', (target, _observation, actor) => {
      const exec = executions.getStore()
      if (exec?.agent === undefined || actor !== exec) return
      const live = opsLive.get(keyOf(exec))
      if (live !== undefined && live.mode === opsCompatibilityToken(ctx)) {
        if (live.observed.size < MAX_LIVE_OPS_OBSERVED) live.observed.add(scope.fs.processPath(target))
        else live.incomplete = true
        return
      }
      if (FILE_TOUCH_TOOL_NAMES[exec.name] !== true) return
      const calls = callsBySession.get(exec.agent.session)
      const call = calls?.get(exec.callId) ?? calls?.get(`ptc:${exec.callId}`)
      if (call !== undefined) call.observedPath = scope.fs.processPath(target)
    }, { global: true })
    scope.on('agent/pre-step', async ({ agent, messages, signal }, next) => {
      const decision = await next()
      // A rejected step never delivers: the touch stays queued for the step that
      // actually enters.
      if (decision.kind !== 'enter') return decision
      const seeded = await withRegistryAdmission(scope, scope.sandboxPolicy.resolve({ session: agent.session }), 'instructions', () => pending(scope, states, agent, config, maxBytes, signal, decision.messages))
      if (seeded === undefined) return decision
      signal.throwIfAborted()
      // Splice in at the same place upstream's own instruction baseline goes:
      // right after the last message claimed from the inbox, so instruction
      // context stays adjacent instead of displacing the operator's prompt.
      const lastClaimed = decision.messages.findLastIndex(message => messages.includes(message))
      return { ...decision, messages: decision.messages.toSpliced(lastClaimed + 1, 0, seeded) }
    }, { prepend: true })
  })
}

/**
 * Compute the message this step should carry, if any.
 *
 * Returns `undefined` — the steady state — whenever every delivered file is
 * still current, so a long session does not re-send the same text on every step.
 * @param ctx - the injected scope, which owns `fs` and the services.
 * @param states - per-session delivery state.
 * @param agent - the agent whose step this is.
 * @param config - the row's configuration.
 * @param maxBytes - the total budget for all additional roots.
 * @param signal - the turn's cancellation signal.
 * @returns the message to inject, or `undefined`.
 */
async function pending(
  ctx: Context,
  states: WeakMap<object, SessionState>,
  agent: Agent,
  config: Config,
  maxBytes: number,
  signal: AbortSignal,
  messages: readonly UserMessage[],
  retried = false,
): Promise<UserMessage | undefined> {
  const session = agent.session
  const sourceEpoch = ctx.get('multiRootRegistry')?.epoch
  const state: SessionState = states.get(session) ?? { scopes: new Map(), provenanceRoots: new Set(), touched: new Set(), worked: new Set(), liveOpsEvidence: new Map() }
  states.set(session, state)
  const evaluatedTouches = new Set(state.touched)
  let retryTouches = false
  const scope = ctx.multiRootScope.resolve(ctx.sandboxPolicy.resolve({ session }))

  // A root the scope no longer grants — removed, missing, or redirected — must
  // be retracted. `sanitizeAdditionalRoots` already withheld the unusable ones,
  // so "absent from the scope" is the single condition to react to.
  const rendered: RenderedRoot[] = []
  const nativeCopy = nativeInstructionCopies(messages, effectiveDirectory(ctx, session))
  // Withdrawal is already model-visible in the native batch. Forget only the
  // borrowed digest, keeping the scope for nested discovery and revocation.
  // Persist this invalidation even if rendering is budget-deferred or fails:
  // the native removal may occur in just this one step's batch.
  for (const [key, entry] of state.scopes) {
    if (entry.nativePath !== undefined && nativeCopy.withdraws(entry.nativePath)) {
      state.scopes.set(key, { ...entry, digest: undefined })
    }
  }
  const gone: GoneScope[] = []
  const updates: Array<{ readonly key: string; readonly scope: DeliveredScope }> = []

  if (scope.additionalRoots.length > 0) {
    const api = await instructionsApi()
    if (api !== undefined) {
      let remaining = maxBytes
      for (const root of scope.additionalRoots) {
        signal.throwIfAborted()
        const plan = await planRoot(ctx, api, root, config, state, signal)
        gone.push(...plan.gone)
        if (plan.deliveries.length === 0) continue
        if (remaining <= 0) {
          retryTouches = true
          continue
        }
        const deliveries = plan.deliveries.filter(entry => {
          const nativePath = nativeCopy.pathOf(entry.file)
          if (nativePath === undefined) return true
          updates.push({ key: entry.key, scope: { root, path: entry.file.absolutePath, digest: digestOf(entry.file.content), nativePath } })
          return false
        })
        if (deliveries.length === 0) continue
        const { text, omitted, truncated } = api.render(deliveries.map(entry => entry.file), { maxBytes: remaining })
        const omittedPaths = new Set(omitted.map(file => file.absolutePath))
        const truncatedPaths = new Set(truncated.map(file => file.displayPath))
        if (omitted.length > 0 || truncated.length > 0 || text === '') retryTouches = true
        if (text === '') continue
        remaining -= Buffer.byteLength(text, 'utf8')
        rendered.push({ root, text })
        for (const entry of deliveries) {
          if (omittedPaths.has(entry.file.absolutePath)) continue
          updates.push({ key: entry.key, scope: {
            root, path: entry.file.absolutePath,
            digest: truncatedPaths.has(entry.file.displayPath) ? undefined : digestOf(entry.file.content),
          } })
        }
      }
    }
  }

  // Discovery/read awaits can span revocation or redirect. Publish only files
  // still inside the live root set, and retract any earlier delivery now gone.
  const current = new Set(await withRegistryAdmission(ctx, ctx.sandboxPolicy.resolve({ session }), 'instructions',
    () => ctx.multiRootScope.resolve(ctx.sandboxPolicy.resolve({ session })).additionalRoots))
  const revoked = [...new Set([...state.scopes.values()].map(entry => entry.root))].filter(root => !current.has(root))
  const liveUpdates = updates.filter(entry => current.has(entry.scope.root))
  const text = composeInstructionMessage(rendered.filter(entry => current.has(entry.root)), revoked, gone.filter(entry => current.has(entry.scope.root)).map(entry => entry.scope))
  const message = text === undefined ? undefined : await createInstructionMessage({ text, plugin: PLUGIN_SOURCE })
  signal.throwIfAborted()
  if (ctx.get('multiRootRegistry')?.shared) {
    const final = await withRegistryAdmission(ctx, ctx.sandboxPolicy.resolve({ session }), 'instructions', () => ({
      roots: ctx.multiRootScope.resolve(ctx.sandboxPolicy.resolve({ session })).additionalRoots,
      epoch: ctx.get('multiRootRegistry')?.epoch,
    }))
    if (sourceEpoch !== final.epoch || final.roots.length !== current.size || final.roots.some(root => !current.has(root))) {
      if (retried) return undefined
      return withRegistryAdmission(ctx, ctx.sandboxPolicy.resolve({ session }), 'instructions',
        () => pending(ctx, states, agent, config, maxBytes, signal, messages, true))
    }
  }
  // Keep budget-deferred directories discoverable without another tool call.
  // Delete only the evaluated snapshot, preserving new touches during I/O.
  if (!retryTouches) for (const touch of evaluatedTouches) state.touched.delete(touch)
  if (text !== undefined || liveUpdates.length > 0) {
    // The message is built, so the bookkeeping it was built from is now the
    // recorded truth: withdrawals are forgotten and deliveries are remembered.
    for (const root of revoked) {
      for (const [key, entry] of state.scopes) if (entry.root === root) state.scopes.delete(key)
    }
    for (const entry of gone) state.scopes.delete(entry.key)
    for (const entry of liveUpdates) {
      state.scopes.set(entry.key, entry.scope)
      state.provenanceRoots.add(entry.scope.root)
    }
  }
  return message
}

/** A delivered file that vanished from a directory this step examined. */
interface GoneScope {
  /** The scope key to forget. */
  readonly key: string
  /** The withdrawal to state in the message. */
  readonly scope: RemovedScope
}

/** One candidate file to deliver, with the scope key it will be remembered under. */
interface Delivery {
  /** The scope key of the file. */
  readonly key: string
  /** The loaded candidate. */
  readonly file: LoadedInstructionFile
}

/** The change one additional root needs this step. */
interface RootPlan {
  /** Candidates that are new, or whose content changed since delivery. */
  readonly deliveries: readonly Delivery[]
  /** Delivered files that are no longer present where they were delivered from. */
  readonly gone: readonly GoneScope[]
}

/** One examined directory, with the candidates its walk reported. */
interface DirectoryWalk {
  /** That directory's location within its root. */
  readonly relativeDirectory: string
  /** What the walk found. */
  readonly read: DirectoryRead
}

/**
 * Plan one additional root's delivery for this step.
 *
 * Which directories are worth walking is the whole design of phase 2, and the
 * set is exactly three things: the root itself (top-level files, as in phase 1,
 * so a change or a removal there is noticed every step), every directory a
 * nested file was already delivered from (so a change or a removal is noticed
 * without a new touch, like upstream's own reconcile), and the parent directory
 * of every path the session has touched since the last evaluation — plus each
 * of that directory's ancestors up to the root, because discovery reports an
 * intermediate directory's file but only the exact directory's candidates
 * survive the filter below.
 * A strict review can also seed its effective cwd chain without recording a
 * successful touch; ordinary pre-step delivery never supplies that seed.
 * @param ctx - the row's context, for `fs` and the logger.
 * @param api - the adapted upstream instruction surface.
 * @param root - the canonical additional root.
 * @param config - the row's configuration.
 * @param state - the session's delivery state.
 * @param signal - the turn's cancellation signal.
 * @param strict - fail on incomplete review discovery instead of deferring delivery.
 * @param reviewCwd - review-only directory seed; never a successful touch.
 * @returns the files to send and the deliveries to withdraw.
 */
async function planRoot(
  ctx: Context,
  api: InstructionsApi,
  root: string,
  config: Config,
  state: SessionState,
  signal: AbortSignal,
  strict = false,
  reviewCwd?: string,
): Promise<RootPlan> {
  const delivered = new Map<string, DeliveredScope>()
  for (const [key, entry] of state.scopes) if (entry.root === root) delivered.set(key, entry)

  const dirs = new Set<string>([root])
  for (const entry of delivered.values()) {
    const dir = dirname(entry.path)
    if (dir !== root) dirs.add(dir)
  }
  const parents = [...state.touched].map(parentDirectoryOf)
  if (reviewCwd !== undefined) parents.push(reviewCwd)
  for (const parent of parents) {
    if (parent === undefined || !isCanonicallyUnder(parent, root)) continue
    // Every ancestor up to the root, not just the file's own directory. The
    // walk for `<root>/a/b` REPORTS `<root>/a/AGENTS.md` (discovery walks
    // upward), but the exact-directory filter below keeps only the candidates
    // of the directory being walked — so `<root>/a` has to be walked in its own
    // right, or an intermediate directory's rules never reach the model.
    let dir = parent
    for (;;) {
      dirs.add(dir)
      if (dir === root) break
      const up = dirname(dir)
      // Unreachable while `parent` is canonically under `root` (a canonical
      // path's ancestors are prefixes of it); present so this can never spin.
      if (up === dir) break
      dir = up
    }
  }

  const walks: DirectoryWalk[] = []
  for (const dir of dirs) {
    signal.throwIfAborted()
    walks.push({
      relativeDirectory: relativeDirectoryOf(root, dir),
      read: await loadDirectory(ctx.fs, api, root, config, signal, dir, strict),
    })
  }
  // Shallow first, so the model reads the broader rules before the narrower
  // ones; discovery order is preserved within one directory.
  walks.sort((left, right) => left.relativeDirectory.split(sep).length - right.relativeDirectory.split(sep).length
    || (left.relativeDirectory < right.relativeDirectory ? -1 : left.relativeDirectory > right.relativeDirectory ? 1 : 0))

  const deliveries: Delivery[] = []
  const gone: GoneScope[] = []
  for (const walk of walks) {
    // A walk that failed to probe says nothing about what is there, so it can
    // neither deliver nor withdraw.
    if (!walk.read.probed) continue
    // The PRE-FILTER candidates, so a file skipped for size or readability is
    // not mistaken for a deleted one.
    const present = new Set<string>()
    for (const candidate of walk.read.candidates) {
      if (relativeDirectoryOf(root, dirname(candidate.absolutePath)) !== walk.relativeDirectory) continue
      present.add(basename(candidate.absolutePath))
    }
    for (const file of walk.read.files) {
      if (relativeDirectoryOf(root, dirname(file.absolutePath)) !== walk.relativeDirectory) continue
      const key = scopeKey(root, walk.relativeDirectory, basename(file.absolutePath))
      const previous = delivered.get(key)
      if (previous !== undefined && previous.digest === digestOf(file.content)) continue
      if (previous === undefined && walk.relativeDirectory !== '.') {
        if (!strict && state.scopes.size >= MAX_DELIVERED_SCOPES) {
          if (!scopeCapWarned) {
            scopeCapWarned = true
            ctx.logger.warn('multi-root workspace: additional-root instruction scopes capped at %d', MAX_DELIVERED_SCOPES)
          }
          continue
        }
      }
      deliveries.push({ key, file })
    }
    for (const [key, entry] of delivered) {
      if (relativeDirectoryOf(root, dirname(entry.path)) !== walk.relativeDirectory) continue
      if (present.has(basename(entry.path))) continue
      gone.push({ key, scope: { root, path: entry.path } })
    }
  }
  return { deliveries, gone }
}

/** A directory's candidates, and whether the walk itself succeeded. */
interface DirectoryRead {
  /** The candidates the walk reported, before this row's own filters. */
  readonly candidates: readonly InstructionFile[]
  /** The candidates that passed canonical containment, the size cap, and the read. */
  readonly files: readonly LoadedInstructionFile[]
  /** Whether the walk itself succeeded; a failed walk judges nothing. */
  readonly probed: boolean
}

/** Bounded provider read; an over-budget source never becomes a partial constraint. */
async function readReviewInstruction(
  fs: FileSystem,
  target: Parameters<FileSystem['streamText']>[0],
  signal: AbortSignal,
  maxBytes: number,
): Promise<string> {
  const chunks: string[] = []
  let bytes = 0
  for await (const chunk of await fs.streamText(target, signal)) {
    signal.throwIfAborted()
    bytes += Buffer.byteLength(chunk, 'utf8')
    if (bytes > maxBytes) throw new Error('review-context: instruction source budget exceeded')
    chunks.push(chunk)
  }
  return chunks.join('')
}

/**
 * Walk from `cwd` up to `root` and read the instruction candidates it reports.
 *
 * Two filters are applied to what the walk reports, and both are load-bearing:
 *
 * - **canonical containment** drops every candidate that is not inside the root
 *   itself, which is what excludes the user-global file and any ancestor's;
 * - **the source cap** skips a file too large to be instructions, using `stat`
 *   so an oversized file is never read at all.
 *
 * The pre-filter candidates are returned alongside the loaded ones: they are how
 * a caller tells "this file is gone" from "this file could not be read".
 *
 * `displayPath` is rewritten to the absolute path on purpose: discovery
 * displays candidates relative to `projectRoot`, so every root's file would
 * otherwise render as the same ambiguous `AGENTS.md`, and the absolute spelling
 * is also the one the model must use in a tool call against a directory outside
 * the session root.
 * @param fs - the filesystem provider to read through.
 * @param api - the adapted upstream instruction surface.
 * @param root - the canonical additional root the walk stops at.
 * @param config - the row's configuration.
 * @param signal - the turn's cancellation signal.
 * @param cwd - the directory the walk starts from; always inside `root`.
 * @returns the directory read.
 */
async function loadDirectory(
  fs: FileSystem,
  api: InstructionsApi,
  root: string,
  config: Config,
  signal: AbortSignal,
  cwd: string,
  strict = false,
): Promise<DirectoryRead> {
  const configuredSourceBytes = config.maxSourceBytes ?? DEFAULT_MAX_SOURCE_BYTES
  if (strict && (!Number.isFinite(configuredSourceBytes) || configuredSourceBytes <= 0)) throw new Error('review-context: invalid source budget')
  const maxSourceBytes = strict ? Math.min(configuredSourceBytes, DEFAULT_MAX_BYTES) : configuredSourceBytes
  let candidates: readonly InstructionFile[]
  if (strict) {
    // Upstream discovery deliberately treats probe failures as absent. A review
    // may not do that. Preflight this exact directory's configured candidates;
    // normal missing/non-file paths still are absence, permission/I/O errors are not.
    for (const name of [...(config.instructionFileCandidates ?? ['AGENTS.md', 'CLAUDE.md']),
      ...(config.localInstructionFileCandidates ?? ['AGENTS.local.md', 'CLAUDE.local.md'])]) {
      if (basename(name) !== name || name === '.' || name === '..') throw new Error('review-context: invalid instruction candidate')
      signal.throwIfAborted()
      try { await nodeStat(resolve(cwd, name)) } catch (error) {
        const code = (error as NodeJS.ErrnoException).code
        if (code !== 'ENOENT' && code !== 'ENOTDIR') throw new Error('review-context: instruction probe failed')
      }
    }
  }
  try {
    candidates = await api.discover({
      cwd,
      projectRoot: root,
      signal,
      // Omitted rather than passed as undefined, so upstream applies its own
      // candidate defaults (`AGENTS.md`, `CLAUDE.md`, the `.local` overlays).
      ...(config.instructionFileCandidates === undefined ? {} : { instructionFileCandidates: config.instructionFileCandidates }),
      ...(config.localInstructionFileCandidates === undefined ? {} : { localInstructionFileCandidates: config.localInstructionFileCandidates }),
    })
  } catch (error) {
    if (strict) throw error
    // Discovery probes a directory that may have vanished between the scope
    // resolution and this read. A directory that cannot be discovered
    // contributes nothing; it is not a reason to fail the model's step.
    return { candidates: [], files: [], probed: false }
  }

  const files: LoadedInstructionFile[] = []
  for (const candidate of candidates) {
    // Global display paths do not resolve relative to projectRoot. This also
    // excludes a global home placed *inside* an explicitly registered root.
    if (isAbsolute(candidate.displayPath) || resolve(root, candidate.displayPath) !== resolve(candidate.absolutePath)) continue
    if (!isCanonicallyUnder(canonicalPath(candidate.absolutePath), root)) continue
    try {
      const target = await fs.resolve(candidate.absolutePath)
      const path = fs.processPath(target)
      if (!isCanonicallyUnder(path, root)) continue
      const info = await fs.stat(target, signal)
      if (info === undefined || info.type !== 'file') continue
      if (info.size !== undefined && info.size > maxSourceBytes) {
        if (strict) throw new Error('review-context: instruction source budget exceeded')
        continue
      }
      const content = strict ? await readReviewInstruction(fs, target, signal, maxSourceBytes) : await fs.readText(target, signal)
      if (strict && Buffer.byteLength(content, 'utf8') > maxSourceBytes) throw new Error('review-context: instruction source budget exceeded')
      if (strict && canonicalPath(candidate.absolutePath) !== path) throw new Error('review-context: instruction identity changed')
      if (canonicalPath(candidate.absolutePath) !== path || !isCanonicallyUnder(path, root)) continue
      files.push({ ...candidate, displayPath: candidate.absolutePath, content })
    } catch (error) {
      if (strict) throw error
      continue
    }
  }
  return { candidates, files, probed: true }
}
