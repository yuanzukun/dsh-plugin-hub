/**
 * The user-facing surface: the `/workspace-folders` command, its `/add-dirs`
 * alias for adding a root, and the panel's RPC channel.
 *
 * They share one module because they are one thing — the operator-facing edge
 * over `ctx.multiRootRegistry`. The command serves the text surfaces (the
 * composer, headless diagnostics) and the channel serves the browser panel;
 * both resolve the same canonical workspace root, call the same registry, and
 * report the same `RootValidationCode` values.
 *
 * Both are also the two places a READ happens, so both go through the same
 * revalidation entry point: `registry.refresh()` re-stats every registered
 * directory, re-resolves it against the directory it was granted for, and
 * republishes the scope BEFORE the list is rendered. Listing is therefore
 * enough to notice that a directory disappeared (and enough to bring a
 * restored one back) — which is what the panel's "Retry" button and the
 * command's `list` both promise.
 *
 * Both halves are SOFT: the command registers only where a command registry is
 * composed, and the channel only where a host Connection and web server exist
 * (web), so a headless profile mounts this row with zero effect on the
 * providers.
 *
 * The command's own text is English: a host-side command handler has no active
 * locale to consult (the browser owns locale state). The panel follows the
 * interface language.
 * That split is recorded in the M3 plan and the requirements as a known limit.
 *
 * @module @dsh-electron/dsh-plugin-multi-root-workspace/command
 */

import { sshTarget } from './remote/ssh-location.ts'
import { AuthorityRpcError } from './authority/protocol.ts'
import { statSync } from 'node:fs'
import { isAbsolute } from 'node:path'
import { Context } from '@deepseek-ai/cordis'
import type { ConnectionRpcResult } from '@deepseek-ai/dsh-client-connection'
import type {} from '@deepseek-ai/dsh-client-connection'
import { connectionRpcFor } from './compat/connection-rpc.ts'
import { searchAdditionalRoot } from './files-search.ts'
import type { CommandInvocation, CommandResult } from '@deepseek-ai/dsh-commands'
import { effectiveRootAccess } from './contract.ts'
import { RemoteAdmissionError } from './remote/contract.ts'
import { REMOTE_FILES_AUTHORIZATION_WAIT, REMOTE_FILES_FAILURES, REMOTE_FILES_LIST, RemoteFilesError, remoteFilesAuthorizationRequest, remoteFilesListRequest, remoteFilesListing } from './remote/files-contract.ts'
import { remoteFilesAuthorization } from './remote/files-authorization.ts'
import { environmentDigest, ManifestError, type RemoteEnvironment } from './remote/manifest.ts'
import { CredentialError } from './remote/personal/credentials.ts'
import { loadPersonalConfig, type PersonalEnvironment } from './remote/personal/config.ts'
import { RemoteOperationError } from './remote/personal/operations.ts'
import { SshEnvironmentError } from './remote/ssh-environment.ts'
import {
  parseRemoteRequest,
  REMOTE_ENDPOINTS,
  type RemoteCapabilitiesView,
  type RemoteEndpointView,
  type RemoteTransferView,
  type RemotesView,
} from './remote/panel-contract.ts'
import { parseSshCall, parseSshSettingsCall, SSH_SETTINGS_CHANNEL, type SshSettingsView, SSH_ENDPOINTS, type SshEndpoint } from './remote/personal-contract.ts'
import { handlePersonalEndpoint } from './remote/personal-endpoints.ts'
import { HelperInstallError } from './remote/personal/helper-error.ts'
import { captureSshProfile, inspectSshProfile } from './compat/ssh-profile.ts'
import type { SandboxMode } from '@deepseek-ai/dsh-sandbox'
import type {} from '@deepseek-ai/dsh-sandbox-policy'
import type { SessionId } from '@deepseek-ai/dsh-session'
import type {} from '@deepseek-ai/dsh-session'
import type {} from '@deepseek-ai/dsh-subprocess'
// Type-only: loads the `workspaceRegistry` Context augmentation this module's
// optional lookup is typed against (the service itself stays a sibling lookup).
import type {} from '@deepseek-ai/dsh-workspace'
import {
  PANEL_CHANNEL,
  SKILLS_ENDPOINTS,
  WORKTREE_ENDPOINTS,
  parsePanelCall,
  parseWorktreeCall,
  skillsRequestSchema,
  type PanelCall,
  type RevealedView,
  type RootEntryView,
  type RootView,
  type RootsView,
  type WorktreeCleanupView,
} from './contract.ts'
import type {} from './skills.ts'
import type {} from './worktrees.ts'
import { WorktreeError } from './worktrees/errors.ts'
import type { MultiRootRegistry } from './registry.ts'
import { effectiveDirectory, originDirectory } from './compat/session-directory.ts'
import { persistedSessionExists } from './compat/session-existence.ts'
import {
  availableRoots,
  canonicalRoot,
  entryRootRef,
  primaryKey,
  RootValidationError,
  resolveRootRef,
  type RootAccess,
  type RootRef,
  type RootStatus,
} from './roots.ts'
import {
  applyIsolateConfig,
  isolateReport,
  remediationSteps,
  type ApplyReport,
  type IsolateReport,
} from './profile-isolation.ts'

/** Services this row needs before it may activate. */
export const inject = ['commands', 'sandboxPolicy', 'multiRootRegistry']

/** The command name, without the leading slash. */
export const COMMAND_NAME = 'workspace-folders'

/** The shortcut for `/workspace-folders add`, without the leading slash. */
const ADD_COMMAND_NAME = 'add-dirs'

/** One parsed command line. */
export interface FoldersCommand {
  /** The subcommand; `list` when the line named none. */
  readonly verb: 'list' | 'add' | 'remove' | 'alias' | 'alias-id' | 'skills' | 'access' | 'reveal' | 'isolate-profiles' | 'help'
  /** Everything after the verb, verbatim (paths may contain spaces). */
  readonly rest: string
}

/**
 * Parse the text that follows `/workspace-folders`.
 * @param rawInput - the verbatim `rawInput` of the command invocation.
 * @returns the subcommand and its remaining text.
 * @throws {RootValidationError} `invalid-ref` for an unknown subcommand.
 */
export function parseFoldersCommand(rawInput: string): FoldersCommand {
  const trimmed = rawInput.trim()
  if (trimmed === '') return { verb: 'list', rest: '' }
  const match = /^(\S+)(?:\s+([\s\S]*))?$/.exec(trimmed)
  const verb = match?.[1] ?? ''
  const rest = (match?.[2] ?? '').trim()
  switch (verb) {
    case 'list':
    case 'add':
    case 'remove':
    case 'alias':
    case 'alias-id':
    case 'skills':
    case 'access':
    case 'reveal':
    case 'isolate-profiles':
    case 'help':
      return { verb, rest }
    default:
      throw new RootValidationError('invalid-ref', `unknown subcommand "${verb}"; try /${COMMAND_NAME} help`)
  }
}

/** Strip one layer of matching quotes from an operator-supplied path. */
function unquote(text: string): string {
  if (text.length >= 2) {
    const first = text[0]
    const last = text[text.length - 1]
    if ((first === '"' && last === '"') || (first === "'" && last === "'")) return text.slice(1, -1)
  }
  return text
}

/**
 * Render the roots report the command returns. Additional roots are numbered
 * from 1, which is the numbering every other subcommand accepts; the workspace
 * root is never numbered because it cannot be removed.
 * @param primaryRoot - the canonical workspace root.
 * @param statuses - the registry's status list.
 * @param unavailable - the store failure, when the registry could not read it.
 * @returns the report text.
 */
export function renderRootsReport(
  primaryRoot: string,
  statuses: readonly RootStatus[],
  unavailable?: string,
  limit?: number,
  mode?: SandboxMode,
): string {
  const lines = [`Workspace root (primary; access follows the current sandbox mode): ${primaryRoot}`]
  if (unavailable !== undefined) {
    lines.push(`Root registry unavailable: ${unavailable}`)
    return lines.join('\n')
  }
  if (statuses.length === 0) {
    lines.push(`No additional roots. Add one with /${COMMAND_NAME} add <absolute path>.`)
    return lines.join('\n')
  }
  for (const [index, status] of statuses.entries()) {
    const alias = status.alias === undefined ? '' : ` [${status.alias}]`
    const state = status.state === 'available' ? '' : ` (${status.state}: ${status.detail ?? 'unavailable'})`
    lines.push(`  ${index + 1} ${status.path}${alias} (${status.access})${state}${typeof status.aliasId === 'string' ? ` Skills: ${status.skillsEnabled === true ? 'on' : 'off'} /${status.aliasId}:` : ''}`)
  }
  const withheld = statuses.length - availableRoots(statuses).length
  if (withheld > 0) {
    lines.push(
      `${withheld} root(s) are registered but not writable right now;`
      + ` restore the directory and run /${COMMAND_NAME} list, or remove the entry.`,
    )
  }
  if (limit !== undefined) {
    lines.push(`${statuses.length} of ${limit} additional roots.`)
    if (statuses.length > limit) {
      lines.push(
        `Warning: the store exceeds the configured limit of ${limit};`
        + ' every stored root stays granted, only new adds are refused.',
      )
    }
  }
  // "Writable" is mode-relative under the three-state contract (B9): an
  // `inherit` root is writable only when the session is not read-only, while
  // a fixed `read-write` root stays writable under every mode.
  const writable = statuses.filter(status => status.state === 'available'
    && status.access !== 'read-only'
    && (mode !== 'read-only' || status.access === 'read-write')).length
  lines.push(`Writable additional roots${mode === undefined ? '' : ' under the current mode'}: ${writable} of ${statuses.length}.`)
  return lines.join('\n')
}

/** The command-row config: the canonical DSH home `isolate-profiles` inspects. */
export interface CommandConfig {
  /** `$DSH_HOME` as the host resolved it — an absolute path, or the verb fails. */
  readonly dshHome?: string
}

/**
 * Register the command and, where a host Connection exists, the panel channel.
 * @param ctx - the host context carrying `commands`, `sandboxPolicy`, and the registry.
 * @param config - the row's config; `dshHome` feeds `isolate-profiles` only.
 */
export function apply(ctx: Context, config: CommandConfig = {}): void {
  captureSshProfile(ctx)
  ctx.commands.register({
    name: COMMAND_NAME,
    description: 'List, add, remove, alias, or reveal the additional workspace roots of this session, or isolate DSH profile imports',
    input: { hint: '[list|add [path] [--inherit|--read-only|--read-write]|remove <n|path>|alias <n|path> [name]|alias-id <n|path> <id>|skills <n|path> on|off|access <n|path> <level>|reveal <n|path>|isolate-profiles [--apply]|help]' },
    handler: async invocation => await runCommand(ctx, invocation, config),
  })
  ctx.commands.register({
    name: ADD_COMMAND_NAME,
    description: `Add an additional workspace root (alias for /${COMMAND_NAME} add)`,
    input: { hint: '[absolute path] [--inherit|--read-only|--read-write]' },
    handler: async invocation => await runCommand(ctx, {
      ...invocation,
      rawInput: `add ${invocation.rawInput}`,
    }, config),
  })

  // Soft: a profile without the browser host half (headless, sdk) simply has no
  // panel to serve, and the registry is unaffected.
  //
  // Both services are required so the channel lives exactly as long as the
  // consumer fiber. The compatibility adapter binds the RPC getter to that
  // fiber even when Cordis traces service getters through the provider context.
  ctx.inject(['connection', 'webServer'], (connectionCtx) => {
    const connection = connectionCtx.get('connection')
    if (connection === undefined) {
      ctx.logger.warn('multi-root: connection resolved without the service; the panel channel is not mounted')
      return
    }
    const rpc = connectionRpcFor(connectionCtx, connection)
    const disposePanel = rpc.handle(PANEL_CHANNEL, async (endpoint, payload, signal) =>
      await dispatchPanelRequest(ctx, endpoint, payload, signal))
    const disposeSettings = rpc.handle(SSH_SETTINGS_CHANNEL, async (endpoint, payload) =>
      await dispatchPanelRequest(ctx, endpoint, payload, undefined, true))
    return () => { void disposeSettings(); void disposePanel() }
  })
}

/** Execute one `/workspace-folders` invocation. */
async function runCommand(ctx: Context, invocation: CommandInvocation, config: CommandConfig): Promise<CommandResult> {
  let parsed: FoldersCommand
  try {
    parsed = parseFoldersCommand(invocation.rawInput)
  } catch (error: unknown) {
    return { kind: 'error', text: failureText(error) }
  }
  const policy = ctx.sandboxPolicy.resolve({ session: invocation.agent.session })
  // Every Registry call below acts on the Session origin: upstream's policy root
  // follows the effective working directory and is not a key (ADR-0012).
  const primaryRoot = originDirectory(ctx, invocation.agent.session) ?? policy.workspaceRoot
  const registry = ctx.multiRootRegistry

  try {
    switch (parsed.verb) {
      case 'help':
        return { kind: 'success', text: helpText() }
      case 'list': {
        const reportText = await report(registry, primaryRoot, policy.mode)
        await ctx.get('multiRootWorktrees')?.describeRoots(primaryRoot)
        return { kind: 'success', text: reportText }
      }
      case 'add': {
        const { text: rest, access } = splitAddAccess(parsed.rest)
        const typed = unquote(rest)
        const path = typed === '' ? await pickRootPath(ctx, invocation.signal) : typed
        if (path === undefined) {
          return {
            kind: 'error',
            text: `/${COMMAND_NAME}: no directory was selected; pass an absolute path or use the Workspace Folders panel`,
          }
        }
        await registry.add(primaryRoot, { path, ...(access === undefined ? {} : { access }) })
        return { kind: 'success', text: await report(registry, primaryRoot, policy.mode) }
      }
      case 'remove': {
        const { ref } = await targetOf(registry, primaryRoot, parsed.rest)
        await registry.removeAt(primaryRoot, ref)
        return { kind: 'success', text: await report(registry, primaryRoot, policy.mode) }
      }
      case 'alias': {
        const { text: reference, rest: alias } = splitReference(parsed.rest)
        const { ref } = await targetOf(registry, primaryRoot, reference)
        await registry.setAlias(primaryRoot, ref, alias === '' ? undefined : unquote(alias))
        return { kind: 'success', text: await report(registry, primaryRoot, policy.mode) }
      }
      case 'alias-id':
      case 'skills': {
        const { text: reference, rest: value } = splitReference(parsed.rest)
        const { ref } = await targetOf(registry, primaryRoot, reference)
        if (parsed.verb === 'alias-id') await registry.setAliasId(primaryRoot, ref, unquote(value))
        else {
          if (value !== 'on' && value !== 'off') throw new RootValidationError('invalid-ref', 'skills requires on or off')
          await registry.setSkillsEnabled(primaryRoot, ref, value === 'on')
        }
        return { kind: 'success', text: await report(registry, primaryRoot, policy.mode) }
      }
      case 'access': {
        const { text: reference, rest: level } = splitReference(parsed.rest)
        const access = parseAccessLevel(level)
        const { ref } = await targetOf(registry, primaryRoot, reference)
        await registry.setAccess(primaryRoot, ref, access)
        return { kind: 'success', text: await report(registry, primaryRoot, policy.mode) }
      }
      case 'reveal': {
        const { status: target } = await targetOf(registry, primaryRoot, parsed.rest)
        await revealRoot(ctx, target.path)
        return { kind: 'success', text: `revealed ${target.path}` }
      }
      case 'isolate-profiles': {
        if (parsed.rest !== '' && parsed.rest !== '--apply') {
          throw new RootValidationError(
            'invalid-ref',
            `isolate-profiles accepts only --apply or nothing, got "${parsed.rest}"`,
          )
        }
        const home = isolateHome(config)
        const report = parsed.rest === '--apply' ? applyIsolateConfig(home) : isolateReport(home)
        return { kind: 'success', text: renderIsolateReport(report) }
      }
    }
  } catch (error: unknown) {
    return { kind: 'error', text: failureText(error) }
  }
}

/**
 * The current report for one primary root, after re-checking every registered
 * directory. The refresh is what makes the report describe the present rather
 * than the moment the process started.
 */
async function report(registry: MultiRootRegistry, primaryRoot: string, mode?: SandboxMode): Promise<string> {
  const statuses = await registry.refresh(primaryRoot)
  return renderRootsReport(canonicalRoot(primaryRoot), statuses, registry.unavailable, registry.limit, mode)
}

/** Render a failure the way the composer displays it. */
function failureText(error: unknown): string {
  if (error instanceof RootValidationError || error instanceof AuthorityRpcError) return `/${COMMAND_NAME}: ${error.code}: ${error.message}`
  return `/${COMMAND_NAME}: ${error instanceof Error ? error.message : String(error)}`
}

/**
 * The DSH home `isolate-profiles` inspects — the row config's `dshHome`,
 * an absolute path. Missing or invalid is a verb failure, not a guess: the
 * home is the protected root the deny writer scans, and a wrong guess would
 * either read the wrong tree or pretend a home was checked when none was.
 */
function isolateHome(config: CommandConfig): string {
  const home = config.dshHome
  if (typeof home !== 'string' || !isAbsolute(home)) {
    throw new RootValidationError(
      'config-invalid',
      `isolate-profiles needs this row's dshHome config to be an absolute path, got ${JSON.stringify(home)}`,
    )
  }
  return home
}

/**
 * Render the `isolate-profiles` report: one line per confirmed profile, the
 * whole-home scan counts, then — on `--apply` — the per-profile action and
 * the remediation steps. An incomplete scan is always called out, because an
 * uninspectable entry is not evidence the home is clean.
 */
function renderIsolateReport(report: IsolateReport | ApplyReport): string {
  const lines: string[] = [
    `/${COMMAND_NAME} isolate-profiles — pnpm import isolation for the DSH home`,
    `DSH home: ${report.home}`,
  ]
  if (report.profiles.length === 0) {
    lines.push('No confirmed profiles under profiles/ (a profile is a directory whose package.json has dsh.profile as an object).')
  }
  for (const profile of report.profiles) {
    const yaml = profile.yaml
    const state = yaml.state === 'copy'
      ? 'packageImportMethod: copy — isolated on the next install'
      : yaml.state === 'absent'
        ? 'packageImportMethod is unset — pnpm defaults to hardlinks'
        : yaml.state === 'conflict'
          ? `conflict: ${yaml.detail ?? 'needs a manual fix'}`
          : `unreadable: ${yaml.detail ?? 'cannot be read'}`
    lines.push(`  ${profile.name}: ${state}`)
  }
  if (report.nonProfileEntries.length > 0) {
    lines.push(`${report.nonProfileEntries.length} entr(ies) under profiles/ are not confirmed profiles and were left untouched:`)
    for (const entry of report.nonProfileEntries) lines.push(`    ${entry}`)
  }
  const scan = report.scan
  lines.push(`Home scan: scanned ${scan.directories} dirs/${scan.files} files, ${scan.multiLinkTotal} multi-link files, ${scan.uninspectableTotal} uninspectable`)
  for (const path of scan.multiLinkPaths) lines.push(`    multi-link: ${path}`)
  if (scan.multiLinkTotal > scan.multiLinkPaths.length) {
    lines.push(`    … and ${scan.multiLinkTotal - scan.multiLinkPaths.length} more multi-link file(s)`)
  }
  for (const entry of scan.uninspectable) lines.push(`    uninspectable: ${entry.path} (${entry.reason})`)
  if (report.scan.uninspectableTotal > scan.uninspectable.length) {
    lines.push(`    … and ${scan.uninspectableTotal - scan.uninspectable.length} more uninspectable entr(ies)`)
  }
  if (report.incomplete) {
    lines.push(`INCOMPLETE: ${scan.uninspectableTotal} entr(ies) could not be inspected — this report must not be read as clean.`)
  }
  const stuck = report.profiles.filter(profile =>
    profile.yaml.state === 'unreadable' || (profile.yaml.state === 'conflict'))
  if (stuck.length > 0) {
    lines.push('Profiles listed as conflict/unreadable are refused by --apply: fix or remove their pnpm-workspace.yaml by hand, then re-run.')
  }
  if ('actions' in report) {
    lines.push('Apply results:')
    for (const action of (report as ApplyReport).actions) {
      lines.push(`  ${action.name}: ${action.action}${action.detail === undefined ? '' : ` — ${action.detail}`}`)
    }
    lines.push(...remediationSteps(report))
  } else {
    lines.push(`This was a read-only check; run /${COMMAND_NAME} isolate-profiles --apply to write packageImportMethod: copy into every fixable profile.`)
    lines.push('A configured profile still needs its dependencies reinstalled to become copies — the check reports, --apply configures, the reinstall is yours.')
  }
  return lines.join('\n')
}

/** The command's own help text. */
function helpText(): string {
  return [
    `/${COMMAND_NAME} — additional workspace roots of this session`,
    `  /${COMMAND_NAME} list`,
    `  /${COMMAND_NAME} add [absolute path] [--inherit|--read-only|--read-write]   (no path opens the directory picker when one is composed)`,
    `  /${ADD_COMMAND_NAME} [absolute path] [--inherit|--read-only|--read-write]   (alias for /${COMMAND_NAME} add)`,
    `  /${COMMAND_NAME} remove <n|path>`,
    `  /${COMMAND_NAME} alias <n|path> [name]  (no name clears the alias)`,
    `  /${COMMAND_NAME} access <n|path> inherit|read-only|read-write`,
    `  /${COMMAND_NAME} skills <n|path> on|off`,
    `  /${COMMAND_NAME} alias-id <n|path> <kebab-case>`,
    `  /${COMMAND_NAME} reveal <n|path>`,
    `  /${COMMAND_NAME} isolate-profiles [--apply]   (report or set packageImportMethod: copy for every profile under $DSH_HOME)`,
    'Roots are canonicalized before they are stored: `~` expands, and a duplicate, a nested directory,',
    "or this session's own workspace root is rejected.",
    'Access levels: `inherit` follows the session mode; `read-only` refuses writes under every mode;',
    '`read-write` stays writable even in a read-only session.',
    '`isolate-profiles` exists because a Windows deny ACE applies to the file object, not one hardlink name:',
    'profiles whose dependencies are hardlinked into the pnpm store make `$DSH_HOME` unsafe to deny;',
    'the check scans the whole home (links > 1, uninspectable entries) and --apply rewrites the yaml atomically,',
    'but the existing hardlinks are replaced only by the reinstall the report prints.',
  ].join('\n')
}

/**
 * Split `add`'s argument into the path text and the access flag. Either flag
 * is accepted as the first or the last token, so a path containing the flag
 * spelling (quoted or unquoted) is never mistaken for the flag.
 *
 * The access is TRI-STATE on purpose: it stays `undefined` when the operator
 * named no level. `registry.add` revives a withheld record with its stored
 * access unless a level is given explicitly, so forwarding a default here
 * would silently change the registration's authority.
 */
function splitAddAccess(text: string): { text: string; access: RootAccess | undefined } {
  const trimmed = text.trim()
  for (const access of ['read-only', 'read-write', 'inherit'] as const) {
    const flag = `--${access}`
    if (trimmed === flag) return { text: '', access }
    if (trimmed.startsWith(`${flag} `) || trimmed.startsWith(`${flag}\t`)) {
      return { text: trimmed.slice(flag.length).trim(), access }
    }
    if (new RegExp(`\\s${flag}$`).test(trimmed)) {
      return { text: trimmed.slice(0, -flag.length).trim(), access }
    }
  }
  return { text: trimmed, access: undefined }
}

/** Parse the access level an `access` subcommand must end with. */
function parseAccessLevel(text: string): RootAccess {
  const trimmed = text.trim()
  if (trimmed === 'read-only' || trimmed === 'read-write' || trimmed === 'inherit') return trimmed
  throw new RootValidationError('invalid-ref', `the access level must be inherit, read-only, or read-write, got "${trimmed || 'nothing'}"`)
}

/**
 * Split `alias`'s argument into a reference and the alias text.
 *
 * The reference is the first whitespace-delimited token, except when it opens
 * with a quote: a quoted path may contain spaces, so the whole quoted span is
 * the reference and the remainder is the alias.
 */
function splitReference(text: string): { text: string; rest: string } {
  const trimmed = text.trim()
  if (trimmed === '') throw new RootValidationError('invalid-ref', 'a root reference is required')
  if (trimmed.startsWith('"') || trimmed.startsWith("'")) {
    const quote = trimmed[0] ?? ''
    const end = trimmed.indexOf(quote, 1)
    if (end > 0) return { text: trimmed.slice(0, end + 1), rest: trimmed.slice(end + 1).trim() }
  }
  const match = /^(\S+)(?:\s+([\s\S]*))?$/.exec(trimmed)
  return { text: match?.[1] ?? '', rest: (match?.[2] ?? '').trim() }
}

/**
 * Resolve an operator reference — a 1-based number, a path, or an id — to the
 * registered root it names.
 * @param registry - the registry to read.
 * @param primaryRoot - the workspace root the registrations belong to.
 * @param text - the operator's text.
 * @returns the matched status, after re-checking the registered directories.
 * @throws {RootValidationError} `invalid-ref` for empty text, `not-found` when nothing matches.
 */
async function targetOf(
  registry: MultiRootRegistry,
  primaryRoot: string,
  text: string,
): Promise<{ readonly status: RootStatus; readonly ref: RootRef }> {
  const trimmed = text.trim()
  if (trimmed === '') throw new RootValidationError('invalid-ref', 'a root reference is required')
  // A reference must name a root that exists RIGHT NOW: an ordinal points at a
  // position, and a path is resolved against the current canonical spelling.
  const statuses = await registry.refresh(primaryRoot)
  let status: RootStatus
  if (/^\d+$/.test(trimmed)) {
    const ordinal = Number(trimmed)
    status = resolveRootRef(statuses, { kind: 'ordinal', ordinal })
    return { status, ref: entryRootRef(status, ordinal) }
  }
  const asPath = unquote(trimmed)
  if (asPath === '~' || asPath.startsWith('~') || asPath.startsWith('/') || /^[A-Za-z]:[\\/]/.test(asPath)) {
    status = resolveRootRef(statuses, { kind: 'path', path: asPath })
  } else {
    status = resolveRootRef(statuses, { kind: 'id', id: trimmed })
  }
  const ordinal = statuses.indexOf(status) + 1
  return { status, ref: entryRootRef(status, ordinal) }
}

/**
 * Derive the primary root a panel request may act on.
 *
 * The browser names a live session; the host looks that session up and uses
 * its immutable cwd. There is no client-supplied path and no deployment-default
 * fallback: a panel call without a real host session has no workspace to
 * manage. Property access would demand an injected `sessions` dependency this
 * row does not name, so the lookup stays an explicit sibling `get` (the same
 * pattern as `directoryPicker` / `subprocess`).
 *
 * @param ctx - the host context that may carry `sessions`.
 * @param sessionId - the id the panel sent; already required by the wire schema.
 * @returns the session's cwd spelling, verbatim — the Registry key.
 * @throws {RootValidationError} `session-not-found` when the service is absent,
 *   the id does not name a live session, or that session has no cwd.
 */
export function resolvePanelPrimaryRoot(ctx: Context, sessionId: string): string {
  const session = ctx.get('sessions')?.get(sessionId as SessionId)
  const cwd = session?.header.cwd
  // The Registry key is the upstream spelling verbatim — never re-resolved
  // (ADR-0028 / MRW-01): a symlinked session and its realpath target are
  // different identities with different record sets.
  if (session === undefined || cwd === undefined || cwd === '' || !isAbsolute(cwd)) {
    throw new RootValidationError('session-not-found', `session "${sessionId}" is not an active host session`, {
      reference: sessionId,
    })
  }
  return cwd
}

/**
 * Whether the panel's resolver would now name a primary root for the session —
 * the exact live-and-usable-cwd predicate, re-run so a resume that landed
 * between a rejection and its classification is recognized instead of
 * duplicating the cwd rule.
 */
function panelSessionResolvable(ctx: Context, sessionId: string): boolean {
  try {
    resolvePanelPrimaryRoot(ctx, sessionId)
    return true
  } catch {
    return false
  }
}

/**
 * Whether the sessions store names no live session for `sessionId` — or
 * cannot even answer, in which case "not live" stays unproven and the
 * caller keeps the code the flow already had.
 */
function liveSessionAbsent(ctx: Context, sessionId: string): boolean {
  try {
    return ctx.get('sessions')?.get(sessionId as SessionId) === undefined
  } catch {
    return false
  }
}

/** Project one status into the panel's view. */
function toRootView(status: RootStatus, index: number): RootView {
  return {
    ordinal: index + 1,
    id: status.id,
    path: status.path,
    ...(typeof status.aliasId === 'string' ? { aliasId: status.aliasId } : {}),
    skillsEnabled: status.skillsEnabled === true,
    ...(status.alias === undefined ? {} : { alias: status.alias }),
    addedAt: status.addedAt,
    state: status.state,
    access: status.access,
    ...(status.detail === undefined ? {} : { detail: status.detail }),
  }
}

/**
 * Resolve the display name of the primary root from the host's workspace
 * registry — the title the operator set in the workspace browser, falling back
 * to nothing (the panel then shows the path's basename).
 *
 * The registry is an optional sibling service, read through the explicit
 * lookup like `sessions`/`subprocess`: property access would demand an
 * injected dependency this row does not name. Membership wins over cwd, which
 * mirrors the host's own session→workspace resolution.
 */
async function primaryNameOf(ctx: Context, primaryRoot: string, request: PanelCall): Promise<string | undefined> {
  const registry = ctx.get('workspaceRegistry')
  if (registry === undefined) return undefined
  try {
    const sessionId = request.sessionId
    if (sessionId !== undefined && sessionId !== '') {
      const member = registry.list().find(workspace => workspace.sessionIds.includes(sessionId as SessionId))
      if (member !== undefined) return member.title
    }
    const resolved = await registry.resolveByPath(primaryRoot)
    return resolved?.title
  } catch (error: unknown) {
    // A name is decoration, never a reason to fail the endpoint: an unreadable
    // registry leaves the panel on the basename fallback.
    ctx.logger.warn('multi-root: workspace title lookup failed; the panel falls back to the path basename', error)
    return undefined
  }
}

/**
 * Build the panel's view of one primary root, after re-checking every
 * registered directory — the panel's read path is the same revalidation the
 * command uses, so "the list the operator sees" is always the list the scope
 * currently enforces.
 */
async function rootsViewOf(ctx: Context, registry: MultiRootRegistry, primaryRoot: string, request: PanelCall, detectWorktree = request.endpoint === 'list'): Promise<RootsView> {
  const statuses = await registry.refresh(primaryRoot)
  const unavailable = registry.unavailable
  const primaryName = await primaryNameOf(ctx, primaryRoot, request)
  const session = ctx.get('sessions')?.get(request.sessionId as SessionId)
  const effectiveCwd = session === undefined ? undefined : effectiveDirectory(ctx, session)
  // Session origin and policy are host-derived; the request carries neither.
  if (session === undefined) throw new RootValidationError('session-not-found', 'the panel session closed during the request')
  const policy = ctx.sandboxPolicy.resolve({ session })
  const scope = ctx.get('multiRootScope')
  const worktreeInfo = await ctx.get('multiRootWorktrees')?.describeRoots(primaryRoot, detectWorktree)
  return {
    primaryRoot: canonicalRoot(primaryRoot),
    ...(primaryName === undefined ? {} : { primaryName }),
    ...(effectiveCwd === undefined ? {} : { effectiveCwd }),
    mode: policy.mode,
    cappedTools: scope?.toolCaps() ?? [],
    toolAccessInvalid: scope?.toolAccessInvalid ?? false,
    roots: statuses.map((status, index) => {
      const badge = worktreeInfo?.badges.get(status.id)
      return {
        ...toRootView(status, index),
        effectiveAccess: status.state === 'available' ? effectiveRootAccess(status.access, policy.mode) : 'unavailable',
        ...(badge === undefined ? {} : { worktree: badge }),
      }
    }),
    limit: registry.limit,
    count: statuses.length,
    ...(unavailable === undefined ? {} : { unavailable }),
    primaryState: primaryStateOf(primaryRoot),
    ...(worktreeInfo === undefined ? {} : { worktreeCleanupCount: worktreeInfo.cleanupCount }),
  }
}

/**
 * The host's own fact about the primary directory: present, missing, or
 * inaccessible. Not derived from an additional root, and never a substitute
 * for the Registry's authority state (ADR-0039 §6.7).
 */
function primaryStateOf(primaryRoot: string): 'present' | 'missing' | 'inaccessible' {
  try {
    return statSync(primaryRoot).isDirectory() ? 'present' : 'missing'
  } catch (error) {
    const code = (error as NodeJS.ErrnoException).code
    return code === 'ENOENT' || code === 'ENOTDIR' ? 'missing' : 'inaccessible'
  }
}

/**
 * The effective capabilities of one deployment entry: declared actions and
 * pairings, narrowed by the session mode and the two tools' caps. A withheld,
 * revoked, or unregistered endpoint can do nothing at all.
 */
function remoteCapabilitiesOf(
  state: RemoteEndpointView['state'],
  actions: readonly ('read' | 'write' | 'exec')[],
  transfers: readonly RemoteTransferView[],
  mode: SandboxMode,
  cappedTools: readonly string[],
): RemoteCapabilitiesView {
  const usable = state === 'registered'
  const readOnly = mode === 'read-only'
  const imports = transfers.filter(transfer => transfer.direction === 'import')
  const exports = transfers.filter(transfer => transfer.direction === 'export')
  return {
    read: usable && actions.includes('read'),
    write: usable && !readOnly && actions.includes('write'),
    exec: usable && !readOnly && actions.includes('exec') && !cappedTools.includes('remote_bash'),
    // Receiving always writes the remote root; sending reads it. A send whose
    // only peers are local stays legal in a read-only session (the local
    // destination is what the local sink will re-authorize).
    receive: usable && !readOnly && actions.includes('write') && imports.length > 0 && !cappedTools.includes('remote_copy'),
    send: usable && actions.includes('read') && exports.length > 0
      && (!readOnly || exports.every(transfer => transfer.environmentId === 'local')),
  }
}

/**
 * The row's connection target: a personal environment knows its exact
 * `user@host:port`; a deployment manifest carries an account and an SSH host
 * alias but no port, so it stays `user@host`.
 * @param environment - the manifest environment the binding names.
 * @param personal - the personal environment, when the custody mode is personal.
 * @returns the display target prefix for the binding path.
 */
export function remoteTargetOf(
  environment: Pick<RemoteEnvironment, 'account' | 'connection'>,
  personal?: Pick<PersonalEnvironment, 'endpoint'> | undefined,
): string {
  if (personal !== undefined) return sshTarget(personal.endpoint.user, personal.endpoint.hostname, personal.endpoint.port)
  return sshTarget(environment.account, environment.connection.host)
}

/**
 * Explicit worktree cleanup: each id must be a tracked B mapping, and the
 * Registry owner re-verifies `rootId + path + addedAt` before anything is
 * deleted. The answer carries the refreshed roots view, so the panel never
 * needs a second round trip after a cleanup.
 */
async function cleanupWorktreeRoots(ctx: Context, sessionId: string, rootIds: readonly string[]): Promise<WorktreeCleanupView> {
  const worktrees = ctx.get('multiRootWorktrees')
  if (worktrees === undefined) throw new WorktreeError('worktree/not-available', 'worktree root suggestions are not mounted in this composition')
  const result = await worktrees.cleanup(sessionId, rootIds)
  const primaryRoot = resolvePanelPrimaryRoot(ctx, sessionId)
  const roots = await rootsViewOf(ctx, ctx.multiRootRegistry, primaryRoot, { endpoint: 'list', sessionId }, false)
  return { removed: result.removed, skipped: result.skipped, roots }
}

/**
 * Build the panel's remote section without creating a connection: the live
 * control-plane state, the deployment entries for this session's primary root,
 * and each entry's registered state. Only `addRemote` connects.
 */
async function remotesViewOf(
  ctx: Context,
  registry: MultiRootRegistry,
  primaryRoot: string,
  sessionId: string,
): Promise<RemotesView> {
  const session = ctx.get('sessions')?.get(sessionId as SessionId)
  if (session === undefined) throw new RootValidationError('session-not-found', 'the panel session closed during the request')
  const mode = ctx.sandboxPolicy.resolve({ session }).mode
  const status = registry.remoteStatus
  const base = {
    primaryRoot: canonicalRoot(primaryRoot), mode, custodyMode: registry.remoteMode, status,
    ...(registry.remoteEnabled && registry.remoteMode === 'personal' ? { dependencies: inspectSshProfile(ctx).view } : {}),
  }
  // Availability is checked BEFORE the async list, but the manifest itself
  // is re-read AFTER it: a rebind landing during remoteList would otherwise
  // mint browse tokens against bindings the live manifest no longer holds.
  if (registry.remoteManifest === undefined || status.state !== 'ready') {
    return { ...base, endpoints: [] }
  }
  const key = primaryKey(primaryRoot)
  const snapshot = await registry.remoteList(primaryRoot).catch((error: unknown) => {
    // Keep a stable refusal code the panel already localizes; wrap only an
    // unexpected failure.
    if (error instanceof RemoteAdmissionError) throw error
    throw new RemoteAdmissionError('remote-unavailable', error instanceof Error ? error.message : String(error))
  })
  // The snapshot and the manifest must describe the same moment: a manifest
  // rebind landing after remoteList makes any minted token stale, so nothing
  // in this view is browsable.
  const manifest = registry.remoteManifest
  const browsable = manifest !== undefined && snapshot.manifestDigest === registry.remoteManifestDigest
    ? registry.remoteFilesService : undefined
  if (manifest === undefined) {
    return { ...base, endpoints: [] }
  }
  // Personal environments keep the resolved user@host:port in their own
  // config; the converted manifest only carries the managed alias. Read it
  // after remoteList refreshed the file, and fall back to the manifest's
  // account@host if the environment moved away.
  const personalPath = registry.remoteMode === 'personal' ? registry.remotePersonalPath : undefined
  let personal: ReturnType<typeof loadPersonalConfig> | undefined
  if (personalPath !== undefined) {
    try { personal = loadPersonalConfig(personalPath) } catch { personal = undefined }
  }
  const capped = ctx.get('multiRootScope')?.toolCaps() ?? []
  const endpoints = manifest.bindings
    .filter(binding => primaryKey(binding.primary) === key)
    .map((binding): RemoteEndpointView => {
      const environment = manifest.environments.find(entry => entry.environmentId === binding.environmentId)!
      const personalEnvironment = personal?.environments.find(entry => entry.environmentId === binding.environmentId)
      const grant = snapshot.grants.find(entry => entry.environmentId === binding.environmentId && entry.rootId === binding.rootId)
      const state = grant?.state ?? 'unregistered'
      const transfers: RemoteTransferView[] = (binding.transfers ?? []).map(transfer => ({
        direction: transfer.direction, environmentId: transfer.peer.environmentId, rootId: transfer.peer.rootId,
      }))
      const capabilities = remoteCapabilitiesOf(state, binding.actions, transfers, mode, capped)
      const browseTargetMatches = grant !== undefined && (
        grant.verifiedTarget.kind === 'path'
          ? grant.verifiedTarget.value === grant.displayPath && grant.displayPath === binding.path
          : environment.transport === 'helper'
      )
      const browseAuthorization = browsable !== undefined
        && state === 'registered' && grant !== undefined && capabilities.read
        && browseTargetMatches
        && browsable.supports(binding.environmentId, binding)
        ? remoteFilesAuthorization(snapshot.epoch, grant.grantId ?? grant.addedAt, grant.bindingDigest, environmentDigest(environment))
        : undefined
      return {
        environmentId: binding.environmentId,
        rootId: binding.rootId,
        path: binding.path,
        platform: environment.platform,
        ...(environment.displayName === undefined ? {} : { displayName: environment.displayName }),
        target: remoteTargetOf(environment, personalEnvironment),
        state,
        actions: [...new Set(binding.actions)],
        transfers,
        capabilities,
        ...(browseAuthorization === undefined ? {} : { browseAuthorization }),
        ...(state === 'unregistered' ? { reason: 'remote-unregistered' }
          : state === 'withheld' ? { reason: 'remote-withheld' }
          : state === 'revoked' ? { reason: 'remote-revoked' } : {}),
      }
    })
  return { ...base, endpoints }
}

/**
 * Serve one panel endpoint.
 *
 * The payload is validated before anything acts on it: it arrived from a
 * browser, and the host is the side that must not be surprised by a shape it
 * did not expect (see `contract.ts`, which owns the schema both halves share).
 * A malformed request is reported as `panel/bad-request` rather than throwing
 * through the channel.
 */
async function dispatchPanelRequest(
  ctx: Context,
  endpoint: string,
  payload: unknown,
  signal?: AbortSignal,
  sshSettings = false,
): Promise<ConnectionRpcResult<unknown>> {
  let panelSessionId: string | undefined
  try {
    if (sshSettings) {
      const registry = ctx.multiRootRegistry
      if (endpoint === 'status' && payload !== null && typeof payload === 'object' && !Array.isArray(payload) && Object.keys(payload).length === 0) {
        await registry.refreshRemotePersonal()
        const value: SshSettingsView = {
          custodyMode: registry.remoteMode,
          status: registry.remoteStatus,
          // The settings write may settle before the remote plane applies its
          // switch. Dependency inspection is read-only and independent of it.
          ...(registry.remoteMode === 'personal' ? { dependencies: inspectSshProfile(ctx).view } : {}),
          // The legacy wire field remains for older clients. Personal
          // connections are returned by sshState.
          connections: [],
        }
        return { ok: true, value }
      }
      const call = parseSshSettingsCall(endpoint, payload)
      if (!call.ok) return { ok: false, error: { code: 'panel/bad-request', message: call.message, details: {} } }
      return { ok: true, value: await handlePersonalEndpoint(ctx, registry, undefined, call.value) }
    }
    // Worktree endpoints are a separate contract with their own strict schema;
    // they never pass through the roots panel schema (ADR-0039 §7).
    if ((WORKTREE_ENDPOINTS as readonly string[]).includes(endpoint)) {
      const parsedWorktree = parseWorktreeCall(endpoint, payload)
      if (!parsedWorktree.ok) {
        return { ok: false, error: { code: 'panel/bad-request', message: parsedWorktree.message, details: {} } }
      }
      const call = parsedWorktree.value
      panelSessionId = call.sessionId
      const worktrees = ctx.get('multiRootWorktrees')
      if (worktrees === undefined) {
        throw new WorktreeError('worktree/not-available', 'worktree root suggestions are not mounted in this composition')
      }
      switch (call.endpoint) {
        case 'worktreePrompt':
          return { ok: true, value: await worktrees.prompt(call.sessionId, { fresh: call.fresh === true }) }
        case 'worktreePromptSeen':
          return { ok: true, value: await worktrees.seen(call.sessionId, call.promptIds ?? []) }
        case 'worktreePromptWait':
          return {
            ok: true,
            value: await worktrees.wait(call.sessionId, {
              ...(call.seenViewRevision === undefined ? {} : { seenViewRevision: call.seenViewRevision }),
            }, signal),
          }
        case 'worktreePromptResolve':
          return {
            ok: true,
            value: await worktrees.resolve(call.sessionId, call.promptIds ?? [], call.action ?? 'dismiss', {
              ...(call.dontRemind === undefined ? {} : { dontRemind: call.dontRemind }),
              ...(call.snooze === undefined ? {} : { snooze: call.snooze }),
              ...(call.accesses === undefined ? {} : { accesses: call.accesses }),
            }),
          }
        case 'worktreePromptReset':
          return { ok: true, value: await worktrees.reset(call.sessionId) }
        case 'worktreeRootsCleanup':
          return { ok: true, value: await cleanupWorktreeRoots(ctx, call.sessionId, call.rootIds ?? []) }
      }
    }
    if ((SKILLS_ENDPOINTS as readonly string[]).includes(endpoint)) {
      const parsedSkills = skillsRequestSchema.safeParse(payload)
      if (!parsedSkills.success) return { ok: false, error: { code: 'panel/bad-request', message: 'invalid Skills request', details: {} } }
      const request = parsedSkills.data
      if ((endpoint === 'skillsPreview' && request.name === undefined) || (endpoint === 'skillsChanges' && request.generation === undefined)) return { ok: false, error: { code: 'panel/bad-request', message: 'missing Skills request field', details: {} } }
      const skills = ctx.get('multiRootSkills')
      if (skills === undefined) throw new Error('multi-root skills: service is unavailable')
      const value = endpoint === 'skillsList' ? await skills.listSession(request.sessionId, signal)
        : endpoint === 'skillsPreview' ? await skills.previewSession(request.sessionId, request.name ?? '', signal)
        : await skills.changes(request.sessionId, request.generation ?? -1, signal)
      return { ok: true, value }
    }
    if ((SSH_ENDPOINTS as readonly string[]).includes(endpoint)) {
      const parsedSsh = parseSshCall(endpoint as SshEndpoint, payload)
      if (!parsedSsh.ok) {
        return { ok: false, error: { code: 'panel/bad-request', message: parsedSsh.message, details: {} } }
      }
      // Record the session like the roots branch does, so a resume-race
      // `session-not-found` can reclassify to `session-not-live` below.
      panelSessionId = parsedSsh.value.sessionId
      const primaryRoot = resolvePanelPrimaryRoot(ctx, parsedSsh.value.sessionId)
      return { ok: true, value: await handlePersonalEndpoint(ctx, ctx.multiRootRegistry, primaryRoot, parsedSsh.value) }
    }
    // The browse listing endpoint is its own strict contract: it precedes the
    // remote view endpoints, shares their authenticated channel, and the raw
    // request is schema-checked before anything is resolved or admitted.
    if (endpoint === REMOTE_FILES_LIST) {
      const parsedFiles = remoteFilesListRequest.safeParse(payload)
      if (!parsedFiles.success) {
        return { ok: false, error: { code: 'panel/bad-request', message: 'invalid remoteFiles.list request', details: {} } }
      }
      panelSessionId = parsedFiles.data.sessionId
      const service = ctx.multiRootRegistry.remoteFilesService
      if (service === undefined) {
        return {
          ok: false,
          error: { code: 'provider-unavailable', message: 'the remote listing service is not mounted', details: { retryable: true } },
        }
      }
      try {
        const listed = remoteFilesListing.safeParse(await service.list(parsedFiles.data, signal))
        // A listing that fails the wire contract is a coded failure, never
        // a raw payload handed to the browser.
        if (!listed.success) {
          return {
            ok: false,
            error: { code: 'invalid-listing', message: REMOTE_FILES_FAILURES['invalid-listing'].message, details: { retryable: REMOTE_FILES_FAILURES['invalid-listing'].retryable } },
          }
        }
        return { ok: true, value: listed.data }
      } catch (error: unknown) {
        // Only vocabulary entries reach the browser — never raw error text
        // or SSH facts; anything else rethrows through the channel.
        if (error instanceof RemoteFilesError) {
          return { ok: false, error: { code: error.code, message: error.message, details: { retryable: error.retryable } } }
        }
        throw error
      }
    }
    // The authorization lease is its own read-only endpoint beside the
    // listing: an authenticated metadata wait (never a filesystem watch),
    // same strict-before-touch discipline and the same fixed vocabulary.
    if (endpoint === REMOTE_FILES_AUTHORIZATION_WAIT) {
      const parsedWait = remoteFilesAuthorizationRequest.safeParse(payload)
      if (!parsedWait.success) {
        return { ok: false, error: { code: 'panel/bad-request', message: 'invalid remotes.waitForAuthorizationChange request', details: {} } }
      }
      panelSessionId = parsedWait.data.sessionId
      const service = ctx.multiRootRegistry.remoteFilesService
      if (service === undefined) {
        return {
          ok: false,
          error: { code: 'provider-unavailable', message: 'the remote listing service is not mounted', details: { retryable: true } },
        }
      }
      try {
        await service.waitForAuthorizationChange(parsedWait.data, signal)
        return { ok: true, value: { unchanged: true } }
      } catch (error: unknown) {
        if (error instanceof RemoteFilesError) {
          return { ok: false, error: { code: error.code, message: error.message, details: { retryable: error.retryable } } }
        }
        throw error
      }
    }
    if ((REMOTE_ENDPOINTS as readonly string[]).includes(endpoint)) {
      const parsedRemote = parseRemoteRequest(payload)
      if (!parsedRemote.ok) {
        return { ok: false, error: { code: 'panel/bad-request', message: parsedRemote.message, details: {} } }
      }
      const registry = ctx.multiRootRegistry
      const { sessionId, environmentId, rootId } = parsedRemote.value
      panelSessionId = sessionId
      const primaryRoot = resolvePanelPrimaryRoot(ctx, sessionId)
      if (endpoint !== 'remotes') {
        if (environmentId === undefined || rootId === undefined) {
          throw new RootValidationError('invalid-ref', 'environmentId and rootId are required')
        }
        const ref = { environmentId, rootId }
        if (endpoint === 'addRemote') await registry.addRemote(primaryRoot, ref)
        else await registry.removeRemote(primaryRoot, ref)
      }
      return { ok: true, value: await remotesViewOf(ctx, registry, primaryRoot, sessionId) }
    }
    const parsed = parsePanelCall(endpoint, payload)
    if (!parsed.ok) {
      return { ok: false, error: { code: 'panel/bad-request', message: parsed.message, details: {} } }
    }
    const request = parsed.value
    panelSessionId = request.sessionId
    const registry = ctx.multiRootRegistry
    const primaryRoot = resolvePanelPrimaryRoot(ctx, request.sessionId)
    switch (request.endpoint) {
      case 'list':
        return { ok: true, value: await rootsViewOf(ctx, registry, primaryRoot, request) }
      case 'add': {
        if (request.path === undefined || request.path === '') {
          throw new RootValidationError('missing', 'a directory path is required')
        }
        await registry.add(primaryRoot, {
          path: request.path,
          ...(request.alias === undefined ? {} : { alias: request.alias }),
          ...(request.access === undefined ? {} : { access: request.access }),
        })
        return { ok: true, value: await rootsViewOf(ctx, registry, primaryRoot, request) }
      }
      case 'setSkillsEnabled':
        if (request.skillsEnabled === undefined) throw new RootValidationError('invalid-ref', 'skillsEnabled is required')
        await registry.setSkillsEnabled(primaryRoot, requireEntry(request), request.skillsEnabled)
        return { ok: true, value: await rootsViewOf(ctx, registry, primaryRoot, request) }
      case 'setAliasId':
        if (request.aliasId === undefined) throw new RootValidationError('invalid-alias-id', 'aliasId is required')
        await registry.setAliasId(primaryRoot, requireEntry(request), request.aliasId)
        return { ok: true, value: await rootsViewOf(ctx, registry, primaryRoot, request) }
      case 'setAccess': {
        if (request.access === undefined) {
          throw new RootValidationError('invalid-ref', 'an access level is required')
        }
        await registry.setAccess(primaryRoot, requireEntry(request), request.access)
        return { ok: true, value: await rootsViewOf(ctx, registry, primaryRoot, request) }
      }
      case 'remove':
        await registry.removeAt(primaryRoot, requireEntry(request))
        return { ok: true, value: await rootsViewOf(ctx, registry, primaryRoot, request) }
      case 'alias':
        await registry.setAlias(primaryRoot, requireEntry(request), request.alias)
        return { ok: true, value: await rootsViewOf(ctx, registry, primaryRoot, request) }
      case 'move':
        await registry.move(
          primaryRoot,
          requireEntry(request),
          request.beforeEntry !== undefined
            ? entryRefOf(request.beforeEntry)
            : request.beforeId === undefined ? undefined : { kind: 'id', id: request.beforeId },
        )
        return { ok: true, value: await rootsViewOf(ctx, registry, primaryRoot, request) }
      case 'reveal': {
        const ref = requireEntry(request)
        // The reference is resolved against the re-checked list, so revealing a
        // root whose directory changed still targets the current spelling.
        const target = resolveRootRef(await registry.refresh(primaryRoot), ref)
        await revealRoot(ctx, target.path)
        // The ONE endpoint that does not answer with a roots view: it reports
        // what it revealed, and the panel leaves its list as it is.
        const value: RevealedView = { revealed: target.path }
        return { ok: true, value }
      }
      case 'search':
        // The one file operation the upstream wire cannot route: the endpoint
        // names an additional root by id, and the host resolves/authorizes it.
        return { ok: true, value: await searchAdditionalRoot(ctx, primaryRoot, request, signal) }
    }
  } catch (error: unknown) {
    if (error instanceof RootValidationError) {
      // `session-not-found` names three states — no sessions service, no live
      // session, a live session without a usable cwd — and only the first two
      // mean "exists but was not usable during this request". A resolver that
      // would now succeed is a race that resolved between the throw and this
      // catch; `stat` proving durable existence is writer-held or mid-resume.
      // Both invite the retry `session-not-live` promises. A live session
      // that still cannot name a root keeps `session-not-found`: it is live,
      // not "not live", and retry cannot heal it. The reclassify is bound to
      // this channel's own session resolution — AuthorityRpcError carries
      // its own vocabulary and never enters it.
      const code = error.code === 'session-not-found'
        && panelSessionId !== undefined
        && (panelSessionResolvable(ctx, panelSessionId)
          || (liveSessionAbsent(ctx, panelSessionId)
            && await persistedSessionExists(ctx, panelSessionId, signal)))
        ? 'session-not-live'
        : error.code
      return { ok: false, error: { code, message: error.message, details: {} } }
    }
    if (error instanceof HelperInstallError) {
      return { ok: false, error: { code: error.code, message: error.message, details: error.details } }
    }
    // Every coded domain error keeps its stable code: the panel localizes it
    // and `submit` branches on it (a `personal-config-conflict` reloads the
    // state). Laundering any of these into `panel/internal` loses both.
    if (error instanceof AuthorityRpcError || error instanceof WorktreeError || error instanceof RemoteAdmissionError
      || error instanceof ManifestError || error instanceof CredentialError || error instanceof RemoteOperationError
      || error instanceof SshEnvironmentError) {
      return { ok: false, error: { code: error.code, message: error.message, details: {} } }
    }
    const workspaceFile = workspaceFileFailureOf(error)
    if (workspaceFile !== undefined) {
      // The panel localizes this vocabulary (`workspace-file/*` rows), so the
      // refusal keeps its code and message instead of becoming panel/internal.
      return { ok: false, error: workspaceFile }
    }
    return {
      ok: false,
      error: { code: 'panel/internal', message: error instanceof Error ? error.message : String(error), details: {} },
    }
  }
}

/**
 * The upstream workspace-file failure codes this channel may relay.
 *
 * The search endpoint is the one panel operation that runs the upstream
 * `workspaceFiles` implementation in-process, so its refusals arrive as
 * `RemoteError`s from that vocabulary — both the plugin's own admission
 * refusals (`outside-workspace`) and the upstream search's own failures
 * (`not-found`, `not-directory`, `search-failed`). The browser localizes
 * those codes, so the channel must not fold them into `panel/internal`.
 */
const WORKSPACE_FILE_FAILURE_CODES: ReadonlySet<string> = new Set([
  'workspace-file/not-found',
  'workspace-file/not-directory',
  'workspace-file/not-regular-file',
  'workspace-file/not-text',
  'workspace-file/too-large',
  'workspace-file/outside-workspace',
  'workspace-file/search-failed',
  'workspace-file/watch-unsupported',
])

/** One recognized upstream file failure, read structurally. */
interface WorkspaceFileFailure {
  readonly code: string
  readonly message: string
  readonly details: Record<string, unknown>
}

/**
 * Recognize an upstream `workspaceFiles` failure structurally: a code from the
 * declared vocabulary and a string message. The code set is deliberately
 * closed — any other `code` (or a thrown object without one) is not an
 * upstream file failure and stays normalized by the caller.
 * @param error - the caught value.
 * @returns the failure to relay, or `undefined` when this is not one.
 */
function workspaceFileFailureOf(error: unknown): WorkspaceFileFailure | undefined {
  const record = error as { readonly code?: unknown; readonly message?: unknown; readonly details?: unknown } | null | undefined
  if (typeof record?.code !== 'string' || !WORKSPACE_FILE_FAILURE_CODES.has(record.code)) return undefined
  const details = typeof record.details === 'object' && record.details !== null
    ? record.details as Record<string, unknown>
    : {}
  return { code: record.code, message: typeof record.message === 'string' ? record.message : '', details }
}

/** Convert a validated wire snapshot to the registry's exact-entry reference. */
function entryRefOf(entry: RootEntryView): RootRef {
  return { kind: 'entry', ...entry }
}

/** Require the exact list row a mutating panel request must carry. */
function requireEntry(request: PanelCall): RootRef {
  if (request.entry !== undefined) return entryRefOf(request.entry)
  if (request.id !== undefined && request.id !== '') return { kind: 'id', id: request.id }
  throw new RootValidationError('invalid-ref', 'an exact root entry is required')
}

/**
 * Open the composed directory picker when one exists, and answer `undefined`
 * otherwise (the command then reports the missing affordance).
 *
 * Only the `native` capability can answer a host-side command: the `browse`
 * capability is an in-app dialog that only the browser panel can render.
 */
async function pickRootPath(ctx: Context, signal: AbortSignal): Promise<string | undefined> {
  const picker = ctx.get('directoryPicker')
  if (picker === undefined) return undefined
  const capability = picker.capability()
  if (capability.kind !== 'native') return undefined
  const picked = await capability.pick(signal)
  return picked ?? undefined
}

/** The per-platform argv that reveals one directory in the OS file manager. */
export function revealArgv(platform: NodeJS.Platform, path: string): readonly string[] {
  switch (platform) {
    case 'darwin':
      return ['open', '-R', path]
    case 'win32':
      return ['explorer', `/select,${path}`]
    default:
      return ['xdg-open', path]
  }
}

/**
 * Whether the file manager's exit code means the reveal was accepted.
 * `explorer.exe` answers 1 even when it successfully selected the item, so on
 * Windows both 0 and 1 are success; the other managers honor the usual 0.
 */
export function revealAccepted(platform: NodeJS.Platform, exitCode: number | null): boolean {
  return exitCode === 0 || (platform === 'win32' && exitCode === 1)
}

/**
 * Reveal one directory in the OS file manager through `ctx.subprocess`.
 *
 * This runs no confined command and grants the agent nothing: it is an
 * operator action taken from the panel or the command line, and the process is
 * the platform's own file manager. Failures are reported to the caller.
 */
async function revealRoot(ctx: Context, path: string): Promise<void> {
  const subprocess = ctx.get('subprocess')
  if (subprocess === undefined) {
    throw new RootValidationError(
      'reveal-unavailable',
      'revealing a root needs a process runtime, which this composition does not mount',
    )
  }
  const argv = revealArgv(process.platform, path)
  const [program = '', ...args] = argv
  const executable = await subprocess.resolveExecutable(program)
  const handle = subprocess.spawn({
    argv: [executable, ...args],
    cwd: path,
    // The file manager's own chatter is collected boundedly and never shown:
    // all this action reports is whether the platform accepted the request.
    stdio: { stdin: 'ignore', stdout: { maxBytes: 4096 }, stderr: { maxBytes: 4096 } },
    graceMs: 3000,
  })
  const outcome = await handle.done
  await handle.waitForExit()
  if (!revealAccepted(process.platform, outcome.exitCode)) {
    throw new RootValidationError('reveal-unavailable', `the file manager exited with ${String(outcome.exitCode)}`)
  }
}
