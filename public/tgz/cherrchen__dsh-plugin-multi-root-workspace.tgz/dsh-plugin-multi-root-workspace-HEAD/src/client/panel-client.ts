/**
 * The panel's own client for the Connection RPC channel.
 *
 * The browser half cannot use a Typert Remote namespace: contract generation
 * is workspace-shaped and the client assembly's contribution list belongs to
 * the shipped composition, so an out-of-tree plugin has no supported way to
 * mount one (see docs/decisions/ADR-0005 and the M3 plan). What IS public and
 * present in both supported runtimes is the generic Connection channel the
 * shipped sibling plugin already uses: the host registers
 * `connection.rpc.handle(PANEL_CHANNEL, …)` and this module calls it.
 *
 * The call is typed by {@link PanelResponseMap}: the endpoint decides the
 * request shape AND the response type, so a caller cannot decode one endpoint's
 * answer as another's. The response is additionally parsed at the boundary,
 * because the type is a promise about the host while the value on the wire is
 * whatever the host actually sent.
 *
 * @module @dsh-electron/dsh-plugin-multi-root-workspace/client/panel-client
 */

import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import {
  PANEL_CHANNEL,
  parseErrorView,
  parseRevealedView,
  parseRootsView,
  parseSearchView,
  type PanelEndpoint,
  type PanelRequest,
  type PanelResponseMap,
} from '../contract.ts'
import { zh, type Key } from './locales.ts'

/**
 * The Connection result shape this plugin consumes. Declared structurally
 * rather than imported: the host face of the same package would drag the
 * HOST context augmentations into the browser program, and a channel handler
 * is an ordinary `{ ok, value } | { ok, error }` envelope on the wire.
 */
type ChannelResult =
  | { readonly ok: true; readonly value: unknown }
  | { readonly ok: false; readonly error: unknown }

/** A failure the panel renders from its `code`. */
export class PanelError extends Error {
  /**
   * @param code - stable code from the root vocabulary, or a transport code.
   * @param message - the host's fallback text.
   */
  constructor(readonly code: string, message: string) {
    super(message)
    this.name = 'PanelError'
  }
}

/**
 * The copy key for one failure code, with a safe fallback for codes this build
 * does not know (a newer host, or a transport failure).
 * @param code - the failure code.
 * @returns the locale key to render.
 */
export function errorKeyOf(code: string): Key {
  const candidate = `error.${code}`
  if (candidate in zh) return candidate as Key
  // A suffixed code (`ssh-capability-absent:<gate reason>`) localizes by its
  // prefix; the suffix is host detail `errorHasDetail` keeps visible.
  const colon = code.indexOf(':')
  if (colon > 0) {
    const prefixed = `error.${code.slice(0, colon)}`
    if (prefixed in zh) return prefixed as Key
  }
  return 'error.fallback'
}

/**
 * Whether the host's own message adds diagnosis the localized key omits.
 * Transport and protocol failures carry their detail in the message text,
 * and a code this build has no key for can say nothing else; a code with a
 * translated key already says what it means, so the host prose stays off.
 * @param code - the failure code.
 * @returns whether to render `error.message` after the localized key.
 */
/** Codes whose host message names the actual cause the fixed copy cannot. */
const DETAIL_CODES = new Set([
  'access-key-reconcile-required',
  // `verifiedAddTarget` alone throws it for three unrelated failures (no
  // verifier, incomplete confinement, probe timeout) — the message splits them.
  'endpoint-unverifiable',
  // The message says which ssh -G/known_hosts check failed and names the alias.
  'ssh-config-not-linked',
  'host-identity-unverifiable',
  'invalid-manifest',
  'workspace-invalid',
  // The SFTP picker surfaces the server's/transport's own reason (not found,
  // permission denied, timeout); the fixed copy cannot name which one.
  'remote-path-listing-failed',
])

export function errorHasDetail(code: string): boolean {
  // A code with no exact key (transport, suffixed, or unknown) means the
  // localized text cannot name the failure; the host message must show.
  return code === 'unavailable' || code.startsWith('panel/') || DETAIL_CODES.has(code) || !(`error.${code}` in zh)
}

/** The panel's callable face, injected into its component. */
export interface PanelClient {
  /**
   * Call one endpoint.
   * @param endpoint - the endpoint name; it also selects the response type.
   * @param payload - the request fields for that endpoint (the endpoint name
   *   travels as the RPC method, so it is not repeated in the payload).
   * @param signal - optional cancellation; aborting rejects the call.
   * @returns the host's value, in the shape the endpoint promises.
   * @throws {PanelError} when the host answered with a failure, or with a value
   *   that is not what this endpoint promises.
   */
  call<E extends PanelEndpoint>(endpoint: E, payload: PanelRequest, signal?: AbortSignal): Promise<PanelResponseMap[E]>
}

/**
 * Build the panel client over a Connection handle.
 * @param connection - the client Connection service.
 * @returns the client, with every transport failure normalized to a `PanelError`.
 */
export function createPanelClient(connection: ConnectionHandle): PanelClient {
  return {
    async call(endpoint, payload, signal) {
      let result: ChannelResult
      try {
        result = await connection.rpc.call(PANEL_CHANNEL, endpoint, payload, signal) as ChannelResult
      } catch (error: unknown) {
        throw new PanelError('unavailable', error instanceof Error ? error.message : String(error))
      }
      if (!result.ok) {
        // The host reports failures as `{ code, message }`; a transport that
        // failed differently still has to reach the panel as a renderable code.
        const failure = parseErrorView(result.error)
        throw failure === undefined
          ? new PanelError('unavailable', 'the host answered with an unreadable failure')
          : new PanelError(failure.code, failure.message)
      }
      return expectShape(endpoint, result.value)
    },
  }
}

/**
 * Read the value one endpoint promised, narrowing it at the boundary so a host
 * that answered a different endpoint — or a shape from another version — cannot
 * crash the render.
 * @param endpoint - the endpoint that was called.
 * @param value - the raw endpoint value.
 * @returns the value as the endpoint's declared type.
 * @throws {PanelError} `panel/bad-response` when the value is not that shape.
 */
function expectShape<E extends PanelEndpoint>(endpoint: E, value: unknown): PanelResponseMap[E] {
  // The endpoint union is closed here, so the two answers that are not a roots
  // view are named explicitly; everything else keeps the roots-view contract.
  const parsed = endpoint === 'reveal' ? parseRevealedView(value)
    : endpoint === 'search' ? parseSearchView(value)
      : parseRootsView(value)
  if (!parsed.ok) throw new PanelError('panel/bad-response', parsed.message)
  return parsed.value as PanelResponseMap[E]
}
