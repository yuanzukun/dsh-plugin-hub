/**
 * Regression coverage for the two reproducible P1 bypasses the B9 external
 * review reported against `danger-full-access`.
 *
 * - **Unknown authority must not read as "nothing is restricted".** A process
 *   that lost the registry lease publishes an empty scope — with zero
 *   `deniedRoots`, so Full-access used to write anywhere, including inside a
 *   `read-only` root another process registered. While the registry is not
 *   the store's authority, Full-access is now enforced as upstream
 *   `workspace-write` on the fs fence and on the process fence.
 * - **A stale `FsTarget` must not smuggle a write past the deny set.** A
 *   target resolved before its parent directory was swapped for a symlink
 *   into a `read-only` root used to write the protected file: Full-access
 *   checked the STALE target key against the deny set. With deny roots the
 *   fence now re-resolves the display path and checks (and mutates) the FRESH
 *   target, exactly like the confined modes always did.
 */

import { mkdirSync, readFileSync, renameSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'
import { canonicalPath } from '@deepseek-ai/dsh-sandbox'
import SandboxPolicyService from '@deepseek-ai/dsh-sandbox-policy'
import SessionProjectionRegistry from '@deepseek-ai/dsh-session-projection'
import { MultiRootFileSystem } from '../src/fs.ts'
import { DOMAIN_NAME } from '../src/registry.ts'
import { primaryKey } from '../src/roots.ts'
import type { Config as ScopeConfig } from '../src/scope.ts'
import { mountRegistryStack, type RegistryStack } from './support/registry-stack.ts'
import { createFixtureWorkspace, symlinkUnsupportedReason } from './support/temp-workspace.ts'

/** Mount one Full-access stack: real storage + registry + the multi-root fs fence. */
async function stack(store: string, primary: string, scopeConfig: ScopeConfig = {}): Promise<RegistryStack> {
  return await mountRegistryStack(store, {}, {
    scopeConfig,
    beforeGate: async ctx => {
      await ctx.plugin(SessionProjectionRegistry)
      await ctx.plugin(SandboxPolicyService, { mode: 'danger-full-access', workspaceRoot: primary })
      await ctx.plugin(MultiRootFileSystem, { cwd: primary })
    },
  })
}

describe('an unknown registry authority is not "no restrictions"', () => {
  it('enforces a contended Full-access stack as workspace-write until it takes the lease over', async () => {
    const fixture = createFixtureWorkspace('review-contended')
    const first = await stack(join(fixture.base, 'store'), fixture.workspace)
    let second: RegistryStack | undefined
    try {
      await first.registry.add(fixture.workspace, { path: fixture.outside, access: 'read-only' })
      const file = join(fixture.outside, 'victim.txt')
      writeFileSync(file, 'original')
      // The active authority still refuses the registered read-only root.
      await expect(first.ctx.fs.writeText(await first.ctx.fs.resolve(file), 'first'))
        .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })

      second = await stack(join(fixture.base, 'store'), fixture.workspace)
      // A second Host is a follower: the unadmitted read path is still
      // fail-closed (`unavailable`), while its admitted operations run
      // against the owner's projection.
      expect(second.registry.authority.kind).toBe('follower')
      expect(second.scope.resolve({ mode: 'danger-full-access', workspaceRoot: fixture.workspace }).authority)
        .toBe('unavailable')

      // The registered read-only boundary the owner holds is denied for the
      // follower too — the deny travels with the snapshot.
      await expect(second.ctx.fs.writeText(await second.ctx.fs.resolve(file), 'bypass'))
        .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
      expect(readFileSync(file, 'utf8')).toBe('original')

      // `fixture.base` is outside the platform temp grants by fixture
      // construction (`assertOutsideTempGrants`), outside the primary root,
      // and outside every registered root — ambient territory a real
      // Full-access writes, and a follower's admitted operation writes too.
      const stray = join(fixture.base, 'stray.txt')
      await second.ctx.fs.writeText(await second.ctx.fs.resolve(stray), 'stray')
      expect(readFileSync(stray, 'utf8')).toBe('stray')

      // The primary root stays writable: the downgrade is upstream
      // workspace-write semantics, not a lockout.
      await second.ctx.fs.writeText(await second.ctx.fs.resolve(join(fixture.workspace, 'inside.txt')), 'inside')

      // After the holder exits, takeover restores real Full-access
      // semantics: the persisted read-only boundary is denied again and the
      // ambient write is free again.
      await first.dispose()
      await second.registry.refresh(fixture.workspace)
      expect(second.registry.authority.kind).toBe('active')
      // The published projection reads available; the unadmitted `resolve()`
      // path stays fail-closed in shared mode by design.
      expect(second.scope.snapshot({ mode: 'danger-full-access', workspaceRoot: fixture.workspace }).authority)
        .toBe('available')
      await expect(second.ctx.fs.writeText(await second.ctx.fs.resolve(file), 'still denied'))
        .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
      expect(readFileSync(file, 'utf8')).toBe('original')
      await second.ctx.fs.writeText(await second.ctx.fs.resolve(stray), 'stray')
      expect(readFileSync(stray, 'utf8')).toBe('stray')
    } finally {
      await second?.dispose()
      await first.dispose()
      fixture.dispose()
    }
  })
})

describe('the DSH-home boundary under Full-access', () => {
  it('refuses ambient writes under the configured home while restrictions apply', async () => {
    const fixture = createFixtureWorkspace('review-home')
    const home = join(fixture.base, 'dsh-home')
    mkdirSync(home)
    const service = await stack(join(fixture.base, 'store'), fixture.workspace, { dshHome: home })
    try {
      // With zero additional roots and a healthy authority the home boundary
      // does not engage — Full-access stays upstream-exact.
      const free = join(home, 'early.txt')
      await service.ctx.fs.writeText(await service.ctx.fs.resolve(free), 'before')
      expect(readFileSync(free, 'utf8')).toBe('before')

      // Once any deny boundary exists, the home is protected too.
      await service.registry.add(fixture.workspace, { path: fixture.outside, access: 'read-only' })
      const victim = join(home, 'victim.txt')
      writeFileSync(victim, 'config')
      await expect(service.ctx.fs.writeText(await service.ctx.fs.resolve(victim), 'tampered'))
        .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
      expect(readFileSync(victim, 'utf8')).toBe('config')
      await expect(service.ctx.fs.writeText(await service.ctx.fs.resolve(victim), 'tampered'))
        .rejects.toThrow('DSH home directory')
    } finally {
      await service.dispose()
      fixture.dispose()
    }
  })

  it('denies the home under the unavailable-authority clamp', async () => {
    const fixture = createFixtureWorkspace('review-home-clamp')
    const home = join(fixture.base, 'dsh-home')
    mkdirSync(home)
    const service = await stack(join(fixture.base, 'store'), fixture.workspace, { dshHome: home })
    try {
      // Unavailable authority for the admitted fs path means an unavailable
      // REGISTRY — the scope flag alone no longer gates the admitted scope.
      await service.registryFiber.dispose()
      const victim = join(home, 'victim.txt')
      writeFileSync(victim, 'config')
      await expect(service.ctx.fs.writeText(await service.ctx.fs.resolve(victim), 'tampered'))
        .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
      expect(readFileSync(victim, 'utf8')).toBe('config')
    } finally {
      await service.dispose()
      fixture.dispose()
    }
  })

  it('lets the deny win when the primary root sits inside the home', async () => {
    const fixture = createFixtureWorkspace('review-home-primary')
    const home = join(fixture.base, 'dsh-home')
    const primary = join(home, 'workspace')
    mkdirSync(primary, { recursive: true })
    const service = await stack(join(fixture.base, 'store'), primary, { dshHome: home })
    try {
      await service.registry.add(primary, { path: fixture.outside, access: 'read-only' })
      const target = await service.ctx.fs.resolve(join(primary, 'work.txt'))
      await expect(service.ctx.fs.writeText(target, 'inside primary'))
        .rejects.toThrow('DSH home directory')
    } finally {
      await service.dispose()
      fixture.dispose()
    }
  })
})

describe('a stale FsTarget under Full-access', () => {
  it('is re-resolved and refused instead of written into a read-only subtree', async context => {
    const noSymlinks = symlinkUnsupportedReason()
    if (noSymlinks !== undefined) context.skip(noSymlinks)
    const fixture = createFixtureWorkspace('review-stale')
    const service = await stack(join(fixture.base, 'store'), fixture.workspace)
    try {
      const protectedSub = join(fixture.outside, 'sub')
      const parent = join(fixture.workspace, 'parent')
      mkdirSync(protectedSub)
      mkdirSync(parent)
      const victim = join(protectedSub, 'victim.txt')
      writeFileSync(victim, 'protected')
      writeFileSync(join(parent, 'victim.txt'), 'ordinary')
      await service.registry.add(fixture.workspace, { path: fixture.outside, access: 'read-only' })

      const oldTarget = await service.ctx.fs.resolve(join(parent, 'victim.txt'))
      renameSync(parent, `${parent}-old`)
      symlinkSync(protectedSub, parent, 'dir')

      // workspace-write already re-resolved; Full-access now does too — the
      // target is checked as what the display path resolves to NOW.
      await expect(service.ctx.fs.writeText(oldTarget, 'workspace control', undefined, undefined,
        { mode: 'workspace-write', workspaceRoot: fixture.workspace }))
        .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
      await expect(service.ctx.fs.writeText(oldTarget, 'stale bypass'))
        .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
      await expect(service.ctx.fs.editText(oldTarget,
        { oldString: 'protected', newString: 'stale bypass', replaceAll: false }))
        .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
      expect(readFileSync(victim, 'utf8')).toBe('protected')
      // The fresh spelling of the same file is equally refused.
      await expect(service.ctx.fs.writeText(await service.ctx.fs.resolve(join(parent, 'victim.txt')), 'fresh'))
        .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
      expect(readFileSync(victim, 'utf8')).toBe('protected')
    } finally {
      await service.dispose()
      fixture.dispose()
    }
  })
})

describe('a legacy overlapping store keeps its read-only boundary', () => {
  it('denies writes into the recreated child while both memberships stay withheld', async () => {
    const fixture = createFixtureWorkspace('review-conflict')
    const store = join(fixture.base, 'store')
    mkdirSync(store)
    const cage = join(fixture.base, 'cage')
    const denied = join(cage, 'denied')
    mkdirSync(denied, { recursive: true })
    const victim = join(denied, 'victim.txt')
    writeFileSync(victim, 'original')

    // Persist the formerly legal state: the read-only child registered, then
    // — while it was missing — a covering fixed read-write parent admitted by
    // the old available-only overlap check.
    const first = await stack(store, fixture.workspace)
    await first.registry.add(fixture.workspace, { path: denied, access: 'read-only' })
    await first.dispose()
    const storeFile = join(store, `${DOMAIN_NAME}.json`)
    const document = JSON.parse(readFileSync(storeFile, 'utf8')) as {
      tables: { roots: Record<string, { roots: Record<string, unknown>[] }> }
    }
    document.tables.roots[primaryKey(fixture.workspace)]!.roots.push({
      id: 'legacy-parent',
      path: canonicalPath(cage),
      readWriteRecordedPath: canonicalPath(cage),
      addedAt: '2026-10-16T00:00:00.000Z',
    })
    writeFileSync(storeFile, JSON.stringify(document))

    // The child is gone when the pair is re-opened; both records classify as a
    // membership conflict and publish no membership — but the child's recorded
    // read-only boundary still feeds the deny set.
    rmSync(denied, { recursive: true, force: true })
    const second = await stack(store, fixture.workspace)
    try {
      const statuses = second.registry.list(fixture.workspace)
      expect(statuses.map(status => status.state)).toEqual(['invalid', 'invalid'])
      expect(statuses.every(status => status.invalidReason === 'membership-conflict')).toBe(true)
      expect(second.scope.snapshot({ mode: 'workspace-write', workspaceRoot: fixture.workspace }).additionalRoots).toEqual([])

      mkdirSync(denied, { recursive: true })
      writeFileSync(victim, 'original')
      for (const mode of ['read-only', 'workspace-write', 'danger-full-access'] as const) {
        expect(second.scope.snapshot({ mode, workspaceRoot: fixture.workspace }).deniedRoots, mode)
          .toEqual([canonicalPath(denied)])
      }

      // The R3 invariant: a denied directory recreated under an accepted
      // writable parent must NOT be writable through the in-process fence —
      // the conflict withheld BOTH grants and kept the child's deny.
      const target = await second.ctx.fs.resolve(victim)
      await expect(second.ctx.fs.writeText(target, 'bypass'))
        .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
      await expect(second.ctx.fs.editText(target,
        { oldString: 'original', newString: 'bypass', replaceAll: false }))
        .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
      expect(readFileSync(victim, 'utf8')).toBe('original')

      // The fence stays writable inside the primary root — the deny is the
      // child boundary, not a lockout.
      await second.ctx.fs.writeText(await second.ctx.fs.resolve(join(fixture.workspace, 'inside.txt')), 'inside')
    } finally {
      await second.dispose()
      fixture.dispose()
    }
  })
})
