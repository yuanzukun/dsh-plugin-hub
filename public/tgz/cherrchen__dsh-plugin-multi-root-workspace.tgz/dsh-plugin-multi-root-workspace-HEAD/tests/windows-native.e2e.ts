import { rootDenySid } from '../src/windows-runner-contract.ts'
/**
 * Windows-native ACL hardening e2e: real restricted-token spawns against
 * hostile root names, a second drive, path aliases, junction redirection,
 * non-caller-owned roots, revocation snapshots, concurrent root sets, ConPTY
 * interruption, and Git Bash. Runs only on Windows; every case cleans its
 * fixtures in `finally`.
 */
import { execFileSync, spawn, spawnSync, type ChildProcess } from 'node:child_process'
import { existsSync, linkSync, lstatSync, mkdirSync, mkdtempSync, readFileSync, renameSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join, parse } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { Context } from '@deepseek-ai/cordis'
import { canonicalPath } from '@deepseek-ai/dsh-sandbox'
import type { SandboxExecutionPolicy, SandboxPolicy } from '@deepseek-ai/dsh-sandbox'
import LocalSubprocess from '@deepseek-ai/dsh-subprocess-local'
import SandboxPolicyService from '@deepseek-ai/dsh-sandbox-policy'
import SessionProjectionRegistry from '@deepseek-ai/dsh-session-projection'
import { describe, expect, it } from 'vitest'
import { MultiRootFileSystem } from '../src/fs.ts'
import type { MultiRootSandboxProvider } from '../src/sandbox.ts'
import { MultiRootScopeService } from '../src/scope.ts'
import { mountCompat } from './support/compat.ts'
import { createFixtureWorkspace, REPO_ROOT } from './support/temp-workspace.ts'
import { shortPathName } from './support/windows.ts'
import { loadWindowsNative } from '../src/compat/windows-native.ts'
import type { NativeFunction, WindowsNative } from '../src/compat/windows-native.ts'
import { pinWindowsDenyPaths } from '../src/compat/windows-path-guard.ts'

const PLUGIN_RUNNER = join(REPO_ROOT, 'lib', 'windows-runner.js')
const UPSTREAM_RUNNER_ARGS = (): string[] => [process.execPath, fileURLToPath(import.meta.resolve('@deepseek-ai/dsh-sandbox-windows-acl/runner'))]

interface Spawned {
  readonly status: number | null
  readonly stdout: string
  readonly stderr: string
  readonly error?: Error
}

interface Mounted {
  readonly ctx: Context
  readonly provider: MultiRootSandboxProvider
  readonly policy: SandboxPolicy
}

/** Mount the SHIPPED provider and pin the real upstream Windows ACL runner. */
async function mountProvider(workspace: string, scopeConfig: ConstructorParameters<typeof MultiRootScopeService>[1] = {}): Promise<Mounted> {
  const ctx = new Context()
  // Execute the shipped provider: its import.meta.url must locate the built
  // standalone runner, not a nonexistent src/windows-runner.js under Vitest.
  const { MultiRootSandboxProvider } = await import(pathToFileURL(join(REPO_ROOT, 'lib/sandbox.js')).href) as typeof import('../src/sandbox.ts')
  ctx.provide('sandboxPolicy', {} as never)
  await ctx.plugin(MultiRootScopeService, scopeConfig)
  await mountCompat(ctx)
  await ctx.plugin(MultiRootSandboxProvider)
  const provider = ctx.sandbox as MultiRootSandboxProvider
  provider.internals = { chain: ['windows-acl'], windowsAclRunnerArgs: UPSTREAM_RUNNER_ARGS() }
  return { ctx, provider, policy: { mode: 'workspace-write', workspaceRoot: canonicalPath(workspace) } }
}

/** Confine `argv` and spawn it, collecting the child's piped output. */
async function spawnConfined(mounted: Mounted, argv: readonly string[], policy = mounted.policy): Promise<Spawned> {
  const confined = await mounted.provider.confine(argv, policy)
  return await spawnArgv(confined.argv[0]!, confined.argv.slice(1))
}

async function spawnArgv(command: string, args: readonly string[], timeout = 120_000): Promise<Spawned> {
  return await new Promise<Spawned>((resolve, reject) => {
    const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'] })
    const stdout: Buffer[] = []
    const stderr: Buffer[] = []
    child.stdout?.on('data', chunk => stdout.push(chunk as Buffer))
    child.stderr?.on('data', chunk => stderr.push(chunk as Buffer))
    const timer = setTimeout(() => {
      child.kill('SIGKILL')
      reject(new Error(`spawn timed out after ${timeout}ms: ${command} ${args.join(' ')}\nstderr: ${Buffer.concat(stderr).toString('utf8')}`))
    }, timeout)
    child.once('error', error => { clearTimeout(timer); resolve({ status: null, stdout: '', stderr: '', error }) })
    // `exit` may precede the final stdout/stderr chunks on Windows. Verdicts
    // are complete only after `close`, when both pipes have drained.
    child.once('close', code => {
      clearTimeout(timer)
      resolve({ status: code, stdout: Buffer.concat(stdout).toString('utf8'), stderr: Buffer.concat(stderr).toString('utf8') })
    })
  })
}

/** Spawn `argv` while exposing its live stdout buffer for readiness probes. */
function spawnObserved(argv: readonly string[]): { child: ChildProcess; output: () => string; done: Promise<Spawned> } {
  const child = spawn(argv[0]!, argv.slice(1), { stdio: ['ignore', 'pipe', 'pipe'] })
  const stdout: Buffer[] = []
  const stderr: Buffer[] = []
  child.stdout?.on('data', chunk => stdout.push(chunk as Buffer))
  child.stderr?.on('data', chunk => stderr.push(chunk as Buffer))
  const done = new Promise<Spawned>((resolve, reject) => {
    child.once('error', reject)
    child.once('close', code => resolve({ status: code, stdout: Buffer.concat(stdout).toString('utf8'), stderr: Buffer.concat(stderr).toString('utf8') }))
  })
  return { child, done, output: () => Buffer.concat(stdout).toString('utf8') }
}

/** Poll `predicate` until it holds or the deadline expires. */
async function waitFor(predicate: () => boolean, description: string, timeout = 15_000): Promise<void> {
  const deadline = Date.now() + timeout
  while (!predicate()) {
    if (Date.now() > deadline) throw new Error(`timed out waiting for ${description}`)
    await new Promise(resolve => setTimeout(resolve, 50))
  }
}

/** Whether `pid` still names a live process (the signal-0 probe). */
function processAlive(pid: number): boolean {
  try { process.kill(pid, 0); return true } catch { return false }
}

/** A pin handle must make rename/delete of the directory fail outright. */
function expectRenameBlocked(from: string, to: string): void {
  let code: string | undefined
  try { renameSync(from, to) } catch (error) { code = (error as NodeJS.ErrnoException).code }
  expect(code, `rename of ${from}`).toMatch(/EPERM|EACCES|EBUSY/)
  expect(existsSync(from), 'the pinned directory itself stays put').toBe(true)
  expect(existsSync(to), 'no moved copy may appear').toBe(false)
}

/** A confined spawn whose exit can be awaited later (concurrency cases). */
async function startConfined(mounted: Mounted, argv: readonly string[], policy = mounted.policy): Promise<{ child: ChildProcess; done: Promise<Spawned> }> {
  const confined = await mounted.provider.confine(argv, policy)
  const child = spawn(confined.argv[0]!, confined.argv.slice(1), { stdio: ['ignore', 'pipe', 'pipe'] })
  const done = new Promise<Spawned>((resolve, reject) => {
    const stdout: Buffer[] = []
    const stderr: Buffer[] = []
    child.stdout?.on('data', chunk => stdout.push(chunk as Buffer))
    child.stderr?.on('data', chunk => stderr.push(chunk as Buffer))
    child.once('error', reject)
    child.once('close', code => resolve({ status: code, stdout: Buffer.concat(stdout).toString('utf8'), stderr: Buffer.concat(stderr).toString('utf8') }))
  })
  return { child, done }
}

/** A PowerShell invocation safe for hostile paths: the script goes base64. */
function powershellArgv(script: string): string[] {
  return ['powershell.exe', '-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')]
}

/** Node `-e` payload that writes one file per root and reports allowed/denied. */
function writeProbe(roots: readonly string[], name = 'probe.txt'): string {
  return `const fs=require('fs');const roots=${JSON.stringify(roots)};for(const root of roots){try{fs.writeFileSync(root+${JSON.stringify(`/${name}`)},'ok');console.log('allowed')}catch(e){console.log('denied:'+(e&&e.code||e))}}`
}

/**
 * PTY variant: each verdict is its own `MRW:<index>:<verdict>` line.
 * ConPTY interleaves output with cursor/erase escape sequences and may wrap
 * lines, so verdicts are matched by marker anywhere in the stream instead of
 * assuming clean `\n`-separated lines. Each marker line stays far below the
 * 100-column terminal width, so wrapping cannot split one.
 */
function writeProbeMarked(roots: readonly string[], name = 'probe.txt'): string {
  return `const fs=require('fs');const roots=${JSON.stringify(roots)};roots.forEach((root,i)=>{try{fs.writeFileSync(root+${JSON.stringify(`/${name}`)},'ok');console.log('MRW:'+i+':allowed')}catch(e){console.log('MRW:'+i+':denied:'+(e&&e.code||e))}})`
}

/** Extract the indexed `MRW:` verdicts from a ConPTY stream, ignoring ANSI/OSC escapes. */
function ptyVerdicts(seen: string): (string | undefined)[] {
  // eslint-disable-next-line no-control-regex -- the escape sequences are exactly what ConPTY emits.
  const clean = seen.replace(/\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07]*\x07/g, '')
  const verdicts: (string | undefined)[] = []
  for (const match of clean.matchAll(/MRW:(\d+):([^\r\n]+)/g)) {
    verdicts[Number(match[1])] = match[2]!.trim()
  }
  return verdicts
}

/** Find a writable local fixed drive other than the fixture's, if one exists. */
function secondDrive(fixtureDrive: string): string | undefined {
  for (const letter of ['D:\\', 'C:\\']) {
    // `fixtureDrive` is a two-character 'C:'; `letter` carries the trailing
    // separator — compare the drive letters only, or a single-drive host
    // "finds" C:\ as its own second drive and lands at the volume root.
    if (letter.slice(0, 2).toUpperCase() === fixtureDrive) continue
    try {
      const probe = mkdtempSync(join(letter, 'dsh-mr-xdrive-probe-'))
      rmSync(probe, { recursive: true, force: true })
      return letter
    } catch { continue }
  }
  return undefined
}

describe.runIf(process.platform === 'win32')('Windows ACL native confinement', () => {
  it.each([64, 80])('keeps every deny in a %i-root snapshot plus the DSH home', async count => {
    const fixture = createFixtureWorkspace('deny-capacity')
    const home = join(fixture.base, 'home')
    const roots = Array.from({ length: count }, (_, i) => join(fixture.base, `root-${i}`))
    for (const root of [...roots, home]) mkdirSync(root)
    const mounted = await mountProvider(fixture.workspace, { dshHome: home })
    try {
      // 64 is a legal current limit; 80 represents an accepted historical
      // over-limit snapshot. The scope must not truncate either one.
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, roots.map((path, i) => ({
        id: `root-${i}`, path, recordedPath: canonicalPath(path), access: 'read-only',
      })))
      const policy = { mode: 'danger-full-access' as const, workspaceRoot: fixture.workspace }
      const denied = mounted.ctx.multiRootScope.resolve(policy).deniedRoots
      expect(denied).toHaveLength(count + 1)
      const prefix = await mounted.provider.restrictedArgvPrefix(policy, denied)
      const argv = [...prefix, process.execPath, '-e', writeProbe([roots[0]!, roots[count - 1]!, home, fixture.workspace], 'capacity.txt')]
      const result = await spawnArgv(argv[0]!, argv.slice(1))
      expect(result.status, result.stderr).toBe(0)
      expect(result.stdout.trim().split(/\r?\n/)).toEqual([
        expect.stringMatching(/^denied:/), expect.stringMatching(/^denied:/), expect.stringMatching(/^denied:/), 'allowed',
      ])
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 120_000)

  it('omits shared temp grants under an unavailable authority', async () => {
    const fixture = createFixtureWorkspace('primary-only')
    const shared = mkdtempSync(join(tmpdir(), 'mrw-clamp-'))
    const mounted = await mountProvider(fixture.workspace)
    try {
      mounted.ctx.multiRootScope.setRegistryAuthority(false)
      const result = await spawnConfined(mounted, [process.execPath, '-e', writeProbe([fixture.workspace, shared], 'primary-only.txt')])
      expect(result.status, result.stderr).toBe(0)
      expect(result.stdout.trim().split(/\r?\n/)).toEqual(['allowed', expect.stringMatching(/^denied:/)])
    } finally { await mounted.ctx.fiber.dispose(); rmSync(shared, { recursive: true, force: true }); fixture.dispose() }
  })

  it('enforces the complete B9 mode matrix for mixed roots without restricting ambient writes', async () => {
    const fixture = createFixtureWorkspace('win-b9-matrix')
    const inherited = join(fixture.base, 'inherit')
    const fixed = join(fixture.base, 'fixed')
    const readonly = join(fixture.base, "只 读 'a'&%!")
    const ambient = join(fixture.base, 'ambient')
    for (const dir of [inherited, fixed, readonly, ambient]) mkdirSync(dir)
    writeFileSync(join(readonly, 'seed.txt'), 'seed')
    const mounted = await mountProvider(fixture.workspace)
    try {
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [
        { id: 'inherit', path: inherited, recordedPath: canonicalPath(inherited), access: 'inherit' },
        { id: 'fixed', path: fixed, recordedPath: canonicalPath(fixed), access: 'read-write' },
        { id: 'ro', path: readonly, recordedPath: canonicalPath(readonly), access: 'read-only' },
      ])
      for (const mode of ['read-only', 'workspace-write', 'danger-full-access'] as const) {
        const policy: SandboxExecutionPolicy = { mode, workspaceRoot: fixture.workspace }
        const command = [process.execPath, '-e', writeProbe([fixture.workspace, inherited, readonly, fixed, ambient], `${mode}.txt`)]
        const argv = mode === 'danger-full-access'
          ? [...await mounted.provider.restrictedArgvPrefix(policy, mounted.ctx.multiRootScope.resolve(policy).deniedRoots), ...command]
          : (await mounted.provider.confine(command, policy)).argv
        const result = await spawnArgv(argv[0]!, argv.slice(1))
        expect(result.status, result.stderr).toBe(0)
        expect(result.stdout.trim().split(/\r?\n/)).toEqual([
          mode === 'read-only' ? expect.stringMatching(/^denied:/) : 'allowed',
          mode === 'read-only' ? expect.stringMatching(/^denied:/) : 'allowed',
          expect.stringMatching(/^denied:/), 'allowed',
          mode === 'danger-full-access' ? 'allowed' : expect.stringMatching(/^denied:/),
        ])
      }
      const policy: SandboxExecutionPolicy = { mode: 'danger-full-access', workspaceRoot: fixture.workspace }
      const prefix = await mounted.provider.restrictedArgvPrefix(policy, [canonicalPath(readonly)])
      const ps = await spawnArgv(prefix[0]!, [...prefix.slice(1), ...powershellArgv(
        `Get-Content -LiteralPath ${JSON.stringify(join(readonly, 'seed.txt'))}; try { Set-Content -LiteralPath ${JSON.stringify(join(readonly, 'ps.txt'))} -Value bad -ErrorAction Stop; 'wrote' } catch { 'denied' }; Set-Content -LiteralPath ${JSON.stringify(join(ambient, 'ps.txt'))} -Value ok; 'ambient'`,
      )])
      expect(ps.status, ps.stderr).toBe(0)
      expect(ps.stdout.trim().split(/\r?\n/)).toEqual(['seed', 'denied', 'ambient'])
      // A descendant receives the same token and cannot escape through Node's
      // ordinary CreateProcess path.
      const descendant = await spawnArgv(prefix[0]!, [...prefix.slice(1), process.execPath, '-e',
        `const r=require('child_process').spawnSync(process.execPath,['-e',${JSON.stringify(writeProbe([readonly, ambient], 'descendant.txt'))}],{encoding:'utf8'});process.stdout.write(r.stdout);process.stderr.write(r.stderr);process.exit(r.status??99)`])
      expect(descendant.status, descendant.stderr).toBe(0)
      expect(descendant.stdout.trim().split(/\r?\n/)).toEqual([expect.stringMatching(/^denied:/), 'allowed'])
      // Host permissions survive the standing deny ACE; changing access later
      // does not revoke that ACE from a token which still carries its identity.
      writeFileSync(join(readonly, 'host.txt'), 'host')
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [])
      const unrestricted = await spawnArgv(process.execPath, ['-e', writeProbe([readonly], 'removed.txt')])
      expect(unrestricted.stdout.trim()).toBe('allowed')
      const oldSnapshot = await spawnArgv(prefix[0]!, [...prefix.slice(1), process.execPath, '-e', writeProbe([readonly], 'old.txt')])
      expect(oldSnapshot.stdout.trim()).toMatch(/^denied:/)
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 300_000)

  it('denies overwrite, delete, rename, ACL edits and activation of weakened tokens, including protected descendant ACLs', async () => {
    const fixture = createFixtureWorkspace('win-b9-mutations')
    const nested = join(fixture.outside, 'protected')
    mkdirSync(nested)
    const seed = join(nested, 'seed.txt')
    writeFileSync(seed, 'seed')
    // Disable inheritance while retaining the existing ACEs: a root-only
    // inheritable deny would miss this directory and its explicit allows.
    const icacls = join(process.env.SystemRoot!, 'System32', 'icacls.exe')
    execFileSync(icacls, [nested, '/inheritance:d'])
    const mounted = await mountProvider(fixture.workspace)
    try {
      const prefix = await mounted.provider.restrictedArgvPrefix(
        { mode: 'danger-full-access', workspaceRoot: fixture.workspace }, [canonicalPath(fixture.outside)],
      )
      const mutation = `const fs=require('fs');const p=${JSON.stringify(seed)};for(const op of [()=>fs.writeFileSync(p,'bad'),()=>fs.unlinkSync(p),()=>fs.renameSync(p,p+'.moved'),()=>fs.renameSync(${JSON.stringify(fixture.outside)},${JSON.stringify(fixture.outside + '-moved')})]){try{op();console.log('escaped')}catch(e){if(!['EPERM','EACCES'].includes(e.code))throw e;console.log('denied')}}`
      const result = await spawnArgv(prefix[0]!, [...prefix.slice(1), process.execPath, '-e', mutation])
      expect(result.status, result.stderr).toBe(0)
      expect(result.stdout.trim().split(/\r?\n/)).toEqual(['denied', 'denied', 'denied', 'denied'])
      expect(readFileSync(seed, 'utf8')).toBe('seed')
      const acl = await spawnArgv(prefix[0]!, [...prefix.slice(1), icacls, seed, '/reset'])
      expect(acl.status, acl.stdout + acl.stderr).not.toBe(0)
      // .NET needs token duplication for identity queries. Test the actual
      // escape: discard the restricting list, then attempt to activate that weakened
      // token through both public impersonation paths and write the seed.
      const koffiEntry = fileURLToPath(import.meta.resolve('koffi'))
      const tokenProbe = `
const fs=require('fs'), k=require(${JSON.stringify(koffiEntry)});
const a=k.load('advapi32.dll'), b=k.load('kernel32.dll');
const bind=(lib,name,ret,args)=>lib.func('__stdcall',name,ret,args);
const open=bind(b,'OpenProcess','void*',['uint32','int','uint32']);
const tok=bind(a,'OpenProcessToken','int',['void*','uint32','void*']);
const info=bind(a,'GetTokenInformation','int',['void*','int','void*','uint32','void*']);
const restrict=bind(a,'CreateRestrictedToken','int',['void*','uint32','uint32','void*','uint32','void*','uint32','void*','void*']);
const impersonate=bind(a,'ImpersonateLoggedOnUser','int',['void*']);
const duplicate=bind(a,'DuplicateTokenEx','int',['void*','uint32','void*','int','int','void*']);
const setThread=bind(a,'SetThreadToken','int',['void*','void*']);
const revert=bind(a,'RevertToSelf','int',[]);
const close=bind(b,'CloseHandle','int',['void*']);
const h=open(0x400,0,process.pid), out=Buffer.alloc(8);
if(!tok(h,10,out))throw Error('identity query/duplication unavailable');
const source=k.decode(out,'void*'), size=Buffer.alloc(4);
info(source,1,null,0,size); const user=Buffer.alloc(size.readUInt32LE());
if(!info(source,1,user,user.length,size))throw Error('TokenUser unavailable');
const oneSid=Buffer.alloc(16);oneSid.writeBigUInt64LE(k.address(k.decode(user,'void*')));
const derivedOut=Buffer.alloc(8);
if(!restrict(source,1,0,null,0,null,1,oneSid,derivedOut))throw Error('token narrowing unavailable');
const derived=k.decode(derivedOut,'void*');
// Disable every ordinary group too. Deny-only markers must survive both the
// restricting-list intersection and this normal-group disabling operation.
info(derived,2,null,0,size);const groups=Buffer.alloc(size.readUInt32LE());
if(!info(derived,2,groups,groups.length,size))throw Error('TokenGroups unavailable');
const count=groups.readUInt32LE(), ordinary=[];for(let i=0;i<count;i++){const group=groups.subarray(8+i*16,24+i*16);if((group.readUInt32LE(8)&0x20)===0)ordinary.push(group)}
const all=Buffer.concat(ordinary), disabledOut=Buffer.alloc(8);
if(!restrict(derived,1,ordinary.length,all,0,null,1,oneSid,disabledOut))throw Error('group disabling unavailable');
const disabled=k.decode(disabledOut,'void*');
const attempt=ok=>{try{if(!ok)throw Error('weak token activation failed');try{fs.writeFileSync(${JSON.stringify(seed)},'escaped');console.log('escaped')}catch(e){if(!['EPERM','EACCES'].includes(e.code))throw e;console.log('denied')}}finally{if(ok)revert()}};
attempt(impersonate(derived));
attempt(impersonate(disabled));
const threadOut=Buffer.alloc(8), copied=duplicate(derived,4,null,2,2,threadOut);
if(copied){const thread=k.decode(threadOut,'void*');attempt(setThread(null,thread));close(thread)}else throw Error('weak token duplication failed');
// A confined caller may ask the broker to remint its process identity: its
// token carries no restricting SIDs, only UAC-style TokenHasRestrictions, which
// the broker now accepts. Reminting must mirror the existing deny-only groups —
// the returned token still carries the root deny SID as deny-only, and an
// impersonation built from it still cannot write the seed.
const convert=bind(a,'ConvertSidToStringSidW','int',['void*','void*']);
const free=bind(b,'LocalFree','void*',['void*']);
const gle=bind(b,'GetLastError','uint32',[]);
const sidOut=Buffer.alloc(8);if(!convert(k.decode(user,'void*'),sidOut))throw Error('SID query failed');
const sidText=k.decode(k.decode(sidOut,'void*'),'char16_t',-1);free(k.decode(sidOut,'void*'));
const pipeName='DshMultiRootBroker-'+require('crypto').createHash('sha256').update(sidText).digest('hex').slice(0,16);
const socket=require('net').createConnection(${JSON.stringify('\\\\.\\pipe\\')}+pipeName);
const timeout=setTimeout(()=>{socket.destroy();throw Error('broker timeout')},10000);
let response='';socket.on('connect',()=>socket.write('2|'+k.address(source)+'|'+${JSON.stringify(rootDenySid(canonicalPath(fixture.outside)))}+'\\n'));
socket.on('error',e=>{throw e});socket.on('data',b=>{response+=b.toString();if(!response.includes('\\n'))return;clearTimeout(timeout);socket.destroy();
const accepted=response.match(/^OK\\|([0-9]+)/);if(!accepted)throw Error('remint refused: '+JSON.stringify(response));
const handleSlot=Buffer.alloc(8);handleSlot.writeBigUInt64LE(BigInt(accepted[1]));const minted=k.decode(handleSlot,'void*');
info(minted,2,null,0,size);const sizingError=gle();const mintedGroups=Buffer.alloc(size.readUInt32LE());
if(!info(minted,2,mintedGroups,mintedGroups.length,size))throw Error('reminted TokenGroups unavailable Win32='+gle()+' sizingWin32='+sizingError+' handle='+accepted[1]);
const mintedCount=mintedGroups.readUInt32LE();let mirrored=false;
for(let i=0;i<mintedCount;i++){const group=mintedGroups.subarray(8+i*16,24+i*16);const flags=group.readUInt32LE(8);
if((flags&0x10)===0||(flags&4)!==0)continue;const nameOut=Buffer.alloc(8);
if(!convert(k.decode(group,'void*'),nameOut))throw Error('reminted group SID query failed');
const name=k.decode(k.decode(nameOut,'void*'),'char16_t',-1);free(k.decode(nameOut,'void*'));
if(name===${JSON.stringify(rootDenySid(canonicalPath(fixture.outside)))})mirrored=true}
if(!mirrored)throw Error('reminted token dropped the deny-only root group');
const impersonationOut=Buffer.alloc(8);
if(!duplicate(minted,0xF01FF,null,2,1,impersonationOut))throw Error('reminted token duplication failed');
const impersonation=k.decode(impersonationOut,'void*');
try{if(!impersonate(impersonation))throw Error('reminted impersonation failed');
try{fs.writeFileSync(${JSON.stringify(seed)},'escaped');console.log('escaped')}catch(e){if(!['EPERM','EACCES'].includes(e.code))throw e;console.log('remint-keeps-deny')}}finally{revert();close(impersonation)}
close(minted);close(disabled);close(derived);close(source);close(h)});
`
      const token = await spawnArgv(prefix[0]!, [...prefix.slice(1), process.execPath, '-e', tokenProbe])
      expect(token.status, token.stderr).toBe(0)
      expect(token.stdout.trim().split(/\r?\n/)).toEqual(['denied', 'denied', 'denied', 'remint-keeps-deny'])
      expect(readFileSync(seed, 'utf8')).toBe('seed')
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('preserves ConPTY output and the control descriptor on ambient deny launches', async () => {
    const fixture = createFixtureWorkspace('win-b9-transport')
    const mounted = await mountProvider(fixture.workspace)
    try {
      const prefix = await mounted.provider.restrictedArgvPrefix(
        { mode: 'danger-full-access', workspaceRoot: fixture.workspace }, [canonicalPath(fixture.outside)],
      )
      await mounted.ctx.plugin(LocalSubprocess)
      const terminal = await mounted.ctx.subprocess.spawnTerminal({
        argv: [...prefix, process.execPath, '-e', writeProbeMarked([fixture.workspace, fixture.outside])],
        cwd: fixture.workspace, rows: 24, cols: 100, terminalType: 'xterm-256color', graceMs: 3000,
      })
      try {
        let seen = ''
        terminal.output.on('data', (chunk: Buffer | string) => { seen += chunk.toString() })
        terminal.output.resume()
        await terminal.done
        expect(ptyVerdicts(seen)).toEqual(['allowed', expect.stringMatching(/^denied:/)])
      } finally { await terminal.terminate() }
      const control = await new Promise<string>((resolve, reject) => {
        const child = spawn(prefix[0]!, [...prefix.slice(1), process.execPath, '-e', "require('fs').writeSync(7,'control-ok');process.exit(23)"], {
          env: { ...process.env, DSH_SUBPROCESS_CONTROL: 'pipe' },
          stdio: ['ignore', 'pipe', 'pipe', 'ignore', 'ignore', 'ignore', 'ignore', 'pipe'],
        })
        let result = ''
        let stderr = ''
        child.stderr?.on('data', chunk => { stderr += chunk.toString() })
        const pipe = child.stdio[7] as NodeJS.ReadableStream
        pipe.on('data', (chunk: Buffer) => { result += chunk.toString() })
        child.once('error', reject)
        child.once('close', code => {
          if (code !== 23) reject(new Error(`control child exit ${code}: ${stderr}`))
          else resolve(result)
        })
      })
      expect(control).toBe('control-ok')
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('confines hostile root names for Node and PowerShell children alike', async () => {
    const fixture = createFixtureWorkspace('win-hostile')
    const primary = join(fixture.base, "主 根 'a'&^%!(1)")
    const extra = join(fixture.base, '额外 根;b,c')
    const third = join(fixture.base, 'third')
    for (const dir of [primary, extra, third]) mkdirSync(dir)
    const mounted = await mountProvider(primary)
    try {
      mounted.ctx.multiRootScope.setAdditionalRoots(primary, [{ id: 'extra', path: extra, recordedPath: canonicalPath(extra), access: 'read-write' }])
      const node = await spawnConfined(mounted, [process.execPath, '-e', writeProbe([primary, extra, third])])
      expect(node.error).toBeUndefined()
      expect(node.status, node.stderr).toBe(0)
      expect(node.stdout.trim().split(/\r?\n/)).toEqual(['allowed', 'allowed', expect.stringMatching(/^denied:/)])
      const ps = powershellArgv(`[System.IO.File]::WriteAllText(${JSON.stringify(join(extra, 'ps.txt'))}, 'powershell')`)
      const psResult = await spawnConfined(mounted, ps)
      expect(psResult.status, psResult.stderr).toBe(0)
      expect(readFileSync(join(extra, 'ps.txt'), 'utf8')).toBe('powershell')
      const deniedPs = powershellArgv(`try { [System.IO.File]::WriteAllText(${JSON.stringify(join(third, 'ps.txt'))}, 'bad'); exit 11 } catch { exit 0 }`)
      const deniedResult = await spawnConfined(mounted, deniedPs)
      expect(deniedResult.status, deniedResult.stderr).toBe(0)
      expect(existsSync(join(third, 'ps.txt'))).toBe(false)
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 240_000)

  it('grants an additional root on a different drive', async (context) => {
    const fixture = createFixtureWorkspace('win-xdrive')
    const fixtureDrive = canonicalPath(fixture.workspace).slice(0, 2).toUpperCase()
    const drive = secondDrive(fixtureDrive)
    if (drive === undefined) {
      if (process.env.CI !== undefined) expect.unreachable('CI runners have a second fixed drive (C: and D:)')
      context.skip('no second writable fixed drive found')
      return
    }
    const extra = mkdtempSync(join(drive, `dsh-mr-xdrive-${process.pid}-`))
    const third = join(fixture.base, 'third')
    mkdirSync(third)
    const mounted = await mountProvider(fixture.workspace)
    try {
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'drive', path: extra, recordedPath: canonicalPath(extra), access: 'read-write' }])
      const result = await spawnConfined(mounted, [process.execPath, '-e', writeProbe([fixture.workspace, extra, third])])
      expect(result.status, result.stderr).toBe(0)
      expect(result.stdout.trim().split(/\r?\n/)).toEqual(['allowed', 'allowed', expect.stringMatching(/^denied:/)])
    } finally {
      await mounted.ctx.fiber.dispose()
      rmSync(extra, { recursive: true, force: true })
      fixture.dispose()
    }
  }, 180_000)

  it('grants a root registered under a case variant or its 8.3 alias', async () => {
    const fixture = createFixtureWorkspace('win-alias')
    const mounted = await mountProvider(fixture.workspace)
    try {
      const recorded = canonicalPath(fixture.outside)
      // The scope canonicalizes `path`, so a case variant or the volume's 8.3
      // short name for the same directory carries the same grant.
      const variant = fixture.outside.toUpperCase()
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'extra', path: variant, recordedPath: recorded, access: 'read-write' }])
      const first = await spawnConfined(mounted, [process.execPath, '-e', writeProbe([fixture.outside], 'variant.txt')])
      expect(first.status, first.stderr).toBe(0)
      expect(first.stdout.trim()).toBe('allowed')
      const short = shortPathName(fixture.outside)
      if (short === fixture.outside || short === recorded) {
        console.info(`8.3 short names are disabled on this volume; skipping the short-alias assertion (${short})`)
        return
      }
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'extra', path: short, recordedPath: recorded, access: 'read-write' }])
      const second = await spawnConfined(mounted, [process.execPath, '-e', writeProbe([fixture.outside], 'short.txt')])
      expect(second.status, second.stderr).toBe(0)
      expect(second.stdout.trim()).toBe('allowed')
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('withholds a junction that is repointed after registration', async () => {
    const fixture = createFixtureWorkspace('win-junction')
    const target = join(fixture.base, 'target')
    const other = join(fixture.base, 'other')
    const link = join(fixture.base, 'link')
    for (const dir of [target, other]) mkdirSync(dir)
    symlinkSync(target, link, 'junction')
    const mounted = await mountProvider(fixture.workspace)
    try {
      // Registering the junction records the TARGET; writes through the link
      // work while the link still resolves there.
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'extra', path: link, recordedPath: canonicalPath(link), access: 'read-write' }])
      expect(canonicalPath(link)).toBe(canonicalPath(target))
      const first = await spawnConfined(mounted, [process.execPath, '-e', writeProbe([join(link)], 'via-link.txt')])
      expect(first.status, first.stderr).toBe(0)
      expect(first.stdout.trim()).toBe('allowed')
      expect(existsSync(join(target, 'via-link.txt'))).toBe(true)
      // Repoint the junction: the scope reports redirected and withholds, and
      // the runner never widens a grant onto the new target.
      rmSync(link, { force: true, recursive: true })
      symlinkSync(other, link, 'junction')
      expect(mounted.ctx.multiRootScope.scopeOf(fixture.workspace)).toEqual([])
      const confined = await mounted.provider.confine([process.execPath, '-e', writeProbe([link, other], 'sneaky.txt')], mounted.policy)
      expect(confined.argv[1]).not.toBe(PLUGIN_RUNNER)
      const second = await spawnArgv(confined.argv[0]!, confined.argv.slice(1))
      expect(second.stdout.trim().split(/\r?\n/)).toEqual([expect.stringMatching(/^denied:/), expect.stringMatching(/^denied:/)])
      expect(existsSync(join(other, 'sneaky.txt'))).toBe(false)
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('exits 127 without running the child when a root is removed between confine and spawn', async () => {
    const fixture = createFixtureWorkspace('win-removed')
    const mounted = await mountProvider(fixture.workspace)
    try {
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'extra', path: fixture.outside, recordedPath: canonicalPath(fixture.outside), access: 'read-write' }])
      const marker = join(fixture.workspace, 'child-ran.txt')
      const confined = await mounted.provider.confine([process.execPath, '-e', `require('fs').writeFileSync(${JSON.stringify(marker)},'ran')`], mounted.policy)
      rmSync(fixture.outside, { recursive: true, force: true })
      const result = await spawnArgv(confined.argv[0]!, confined.argv.slice(1))
      expect(result.status).toBe(127)
      expect(result.stderr).toContain('windows-acl-run:')
      expect(existsSync(marker)).toBe(false)
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 120_000)

  it('refuses a root the caller does not own', async (context) => {
    const fixture = createFixtureWorkspace('win-owner')
    const foreign = join(fixture.base, 'foreign-owned')
    mkdirSync(foreign)
    // CI invokes Vitest from Git Bash, whose GNU whoami precedes System32
    // on PATH. Pin native utilities rather than depending on shell ordering.
    const systemTool = (name: string): string => join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', `${name}.exe`)
    const identity = execFileSync(systemTool('whoami'), ['/user', '/fo', 'csv', '/nh'], { encoding: 'utf8' })
    const ownerSid = identity.match(/S-1-\d+(?:-\d+)+/)?.[0]
    if (ownerSid === undefined) throw new Error(`whoami did not report the caller SID: ${identity}`)
    const icacls = (args: string[]) => spawnSync(systemTool('icacls'), args, { encoding: 'utf8', timeout: 60_000 })
    let hijacked = false
    const restore = (): void => {
      // Every cleanup step is best-effort and logged: takeown works for
      // administrators even while SYSTEM owns the directory, /reset restores
      // inherited ACLs, and /remove:d clears the deny if it survived. The
      // fixture's own rmSync removes the directory afterwards.
      const steps = [
        ['takeown', ['/f', foreign, '/r', '/d', 'y']],
        ['icacls', [foreign, '/reset', '/t', '/c']],
        ['icacls', [foreign, '/remove:d', '*S-1-1-0', '/t', '/c']],
      ] as const
      for (const [command, args] of steps) {
        try {
          const done = spawnSync(systemTool(command), [...args], { encoding: 'utf8', timeout: 60_000 })
          if (done.status !== 0) console.info(`foreign-owned cleanup \`${command} ${args.slice(1).join(' ')}\` exited ${done.status}: ${done.stderr || done.stdout}`)
        } catch (error) {
          console.info(`foreign-owned cleanup ${command} threw: ${String(error)}`)
        }
      }
    }
    const mounted = await mountProvider(fixture.workspace)
    try {
      // Build the DACL while we still own it. Keep explicit WRITE_DAC and
      // WRITE_OWNER so later ACL edits and cleanup do not depend on the CI
      // account's elevated restore privileges after inheritance is removed.
      // Read/execute/control are not data-write permissions.
      hijacked = true
      const locked = icacls([foreign, '/inheritance:r', '/grant:r', `*${ownerSid}:(OI)(CI)(GR,GE,RC,S,WDAC,WO)`])
      // A grant-only DACL does not bind an elevated caller — administrators
      // still wrote through it on the CI runner — so an explicit DENY on
      // Everyone's write/delete/delete-child makes the lockout hold under
      // elevation too. WDAC/WO are deliberately not denied so cleanup can
      // still read and repair the ACL afterwards.
      const denied = locked.status === 0 ? icacls([foreign, '/deny', '*S-1-1-0:(OI)(CI)(W,D,DC)']) : locked
      // SYSTEM's numeric SID avoids localized account-name lookup. Transfer
      // ownership last, after the final DACL is complete.
      const seized = denied.status === 0 ? icacls([foreign, '/setowner', '*S-1-5-18']) : denied
      if (seized.status !== 0) {
        const detail = `lock=${locked.status} deny=${denied.status} owner=${seized.status}: ${seized.stderr || seized.stdout}`
        if (process.env.CI !== undefined) expect.unreachable(`icacls setup failed on CI: ${detail}`)
        context.skip(`cannot build a foreign-owned directory on this host: ${detail}`)
        return
      }
      const recordedOwner = execFileSync('pwsh', ['-NoProfile', '-NonInteractive', '-Command',
        '(Get-Acl -LiteralPath $env:DSH_TEST_FOREIGN_ROOT).GetOwner([System.Security.Principal.SecurityIdentifier]).Value',
      ], { encoding: 'utf8', env: { ...process.env, DSH_TEST_FOREIGN_ROOT: foreign } }).trim()
      expect(recordedOwner, 'the fixture must actually be owned by SYSTEM').toBe('S-1-5-18')
      // The premise to prove first: the setup must be effective. An unconfined
      // WRITE probe is not a valid check on an elevated host — libuv opens
      // files with FILE_FLAG_BACKUP_SEMANTICS and the elevated runner token
      // holds backup/restore privileges, so the unconfined process bypasses
      // the DACL entirely (the restricted-token child cannot). Read the ACL
      // back instead: the Everyone DENY entry must be present.
      const acl = icacls([foreign])
      const aclText = `${acl.stdout}\n${acl.stderr}`
      // icacls renders a deny ACE as e.g. `Everyone:(OI)(CI)(DENY)(W,D,DC)`.
      if (!/(everyone|S-1-1-0)[^\r\n]*\(DENY\)/i.test(aclText)) {
        if (process.env.CI !== undefined) expect.unreachable(`the Everyone deny ACE is missing from the ACL; icacls says:\n${aclText}`)
        context.skip(`cannot verify the deny ACE on this host; icacls says:\n${aclText}`)
        return
      }
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'extra', path: foreign, recordedPath: canonicalPath(foreign), access: 'read-write' }])
      const third = join(fixture.base, 'third')
      mkdirSync(third)
      // Fail-closed, not a specific exit: either the runner refuses the grant
      // before the child runs (127) or the child runs and the kernel denies
      // every unauthorized write. On an elevated host the precondition
      // failure (127) may never reproduce — the widened grant applies
      // cleanly — which is why both outcomes are accepted.
      const probe = writeProbe([foreign, third], 'owned.txt')
      let result: Spawned
      try {
        result = await spawnConfined(mounted, [process.execPath, '-e', probe])
      } catch (error) {
        console.info(`foreign-owned root: the provider refused at confine (fail-closed): ${String(error)}`)
        expect(existsSync(join(foreign, 'owned.txt'))).toBe(false)
        expect(existsSync(join(third, 'owned.txt'))).toBe(false)
        return
      }
      if (result.status === 127) {
        console.info('foreign-owned root: the runner refused before spawn (exit 127)')
        expect(result.stderr).toContain('windows-acl-run:')
      } else {
        console.info(`foreign-owned root: the grant was applied; asserting the child could not write either dir (status ${String(result.status)})`)
        expect(result.status, result.stderr).toBe(0)
        expect(result.stdout.trim().split(/\r?\n/)).toEqual([
          expect.stringMatching(/^denied:/),
          expect.stringMatching(/^denied:/),
        ])
      }
      expect(existsSync(join(foreign, 'owned.txt'))).toBe(false)
      expect(existsSync(join(third, 'owned.txt'))).toBe(false)
    } finally {
      if (hijacked) restore()
      await mounted.ctx.fiber.dispose()
      fixture.dispose()
    }
  }, 180_000)

  it('keeps an already-confined child on its snapshot when a root is revoked', async () => {
    const fixture = createFixtureWorkspace('win-revoke')
    const go = join(fixture.workspace, 'go.flag')
    const writtenByA = join(fixture.outside, 'from-a.txt')
    const mounted = await mountProvider(fixture.workspace)
    try {
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'extra', path: fixture.outside, recordedPath: canonicalPath(fixture.outside), access: 'read-write' }])
      const waiter = `const fs=require('fs');const go=${JSON.stringify(go)};const t=setInterval(()=>{if(fs.existsSync(go)){clearInterval(t);fs.writeFileSync(${JSON.stringify(writtenByA)},'a');process.exit(0)}},100);setTimeout(()=>process.exit(9),90000)`
      const a = await startConfined(mounted, [process.execPath, '-e', waiter])
      // Revoke X before A is released: A's grant snapshot still covers it.
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [])
      const b = await spawnConfined(mounted, [process.execPath, '-e', writeProbe([fixture.outside], 'from-b.txt')])
      expect(b.stdout.trim()).toMatch(/^denied:/)
      writeFileSync(go, 'go')
      const aResult = await a.done
      expect(aResult.status, aResult.stderr).toBe(0)
      expect(readFileSync(writtenByA, 'utf8')).toBe('a')
      a.child.kill('SIGKILL')
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('confines four children under two root sets with private temps each', async () => {
    const fixture = createFixtureWorkspace('win-concurrent')
    const secondPrimary = join(fixture.base, 'p2')
    const extraY = join(fixture.base, 'extra-y')
    const third = join(fixture.base, 'third')
    for (const dir of [secondPrimary, extraY, third]) mkdirSync(dir)
    const mounted = await mountProvider(fixture.workspace)
    try {
      const payload = (roots: readonly string[]) => `const fs=require('fs');console.log('TEMP='+process.env.TEMP);const roots=${JSON.stringify(roots)};for(const root of roots){try{fs.writeFileSync(root+'/probe.txt','ok');console.log('allowed')}catch(e){console.log('denied:'+(e&&e.code||e))}}`
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'x', path: fixture.outside, recordedPath: canonicalPath(fixture.outside), access: 'read-write' }])
      const setX = [
        await startConfined(mounted, [process.execPath, '-e', payload([fixture.outside, extraY])]),
        await startConfined(mounted, [process.execPath, '-e', payload([fixture.outside, extraY])]),
      ]
      const policyY = { ...mounted.policy, workspaceRoot: canonicalPath(secondPrimary) }
      mounted.ctx.multiRootScope.setAdditionalRoots(secondPrimary, [{ id: 'y', path: extraY, recordedPath: canonicalPath(extraY), access: 'read-write' }])
      const setY = [
        await startConfined(mounted, [process.execPath, '-e', payload([extraY, fixture.outside])], policyY),
        await startConfined(mounted, [process.execPath, '-e', payload([extraY, fixture.outside])], policyY),
      ]
      const results = await Promise.all([...setX, ...setY].map(entry => entry.done))
      const temps: string[] = []
      for (const [index, result] of results.entries()) {
        expect(result.status, result.stderr).toBe(0)
        const lines = result.stdout.trim().split(/\r?\n/)
        temps.push(lines[0]!.replace('TEMP=', ''))
        const verdicts = lines.slice(1)
        // X-set children write X and are denied Y; Y-set the mirror image.
        expect(verdicts, `child ${index}`).toEqual(index < 2
          ? ['allowed', expect.stringMatching(/^denied:/)]
          : ['allowed', expect.stringMatching(/^denied:/)])
      }
      expect(new Set(temps).size).toBe(4)
      const parents = new Set(temps.map(temp => dirname(temp)))
      expect(parents.size, `private temps share the upstream temp parent: ${temps.join(', ')}`).toBe(1)
      for (const temp of temps) expect(existsSync(temp), `${temp} was not removed`).toBe(false)
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 300_000)

  it('mirrors the child exit code and carries both output streams', async () => {
    const fixture = createFixtureWorkspace('win-streams')
    const mounted = await mountProvider(fixture.workspace)
    try {
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'extra', path: fixture.outside, recordedPath: canonicalPath(fixture.outside), access: 'read-write' }])
      const result = await spawnConfined(mounted, [process.execPath, '-e', `process.stdout.write('out');process.stderr.write('err');process.exit(42)`])
      expect(result.status).toBe(42)
      expect(result.stdout).toContain('out')
      expect(result.stderr).toContain('err')
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 120_000)

  it('leaves read-only mode on the upstream runner with no widened grant', async () => {
    const fixture = createFixtureWorkspace('win-readonly')
    const mounted = await mountProvider(fixture.workspace)
    try {
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'extra', path: fixture.outside, recordedPath: canonicalPath(fixture.outside), access: 'inherit' }])
      const confined = await mounted.provider.confine(
        [process.execPath, '-e', `try{require('fs').writeFileSync(${JSON.stringify(join(fixture.outside, 'ro.txt'))},'bad');console.log('allowed')}catch(e){console.log('denied:'+(e&&e.code||e))}`],
        { ...mounted.policy, mode: 'read-only' },
      )
      expect(confined.argv[1]).not.toBe(PLUGIN_RUNNER)
      const result = await spawnArgv(confined.argv[0]!, confined.argv.slice(1))
      expect(result.status, result.stderr).toBe(0)
      expect(result.stdout.trim()).toMatch(/^denied:/)
      expect(existsSync(join(fixture.outside, 'ro.txt'))).toBe(false)
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 120_000)

  it('routes read-only mode through the plugin runner when a fixed read-write root exists', async () => {
    const fixture = createFixtureWorkspace('win-readonly-fixed')
    const mounted = await mountProvider(fixture.workspace)
    try {
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'fixed', path: fixture.outside, recordedPath: canonicalPath(fixture.outside), access: 'read-write' }])
      const confined = await mounted.provider.confine(
        [process.execPath, '-e', `const fs=require('fs');for(const root of ${JSON.stringify([fixture.outside, fixture.workspace])}){try{fs.writeFileSync(root+'/probe.txt','ok');console.log('allowed')}catch(e){console.log('denied:'+(e&&e.code||e))}}`],
        { ...mounted.policy, mode: 'read-only' },
      )
      // The fixed root must use the standalone runner: upstream's read-only
      // profile cannot grant anything, and the workspace stays denied.
      expect(confined.argv[1]).toBe(PLUGIN_RUNNER)
      const result = await spawnArgv(confined.argv[0]!, confined.argv.slice(1))
      expect(result.status, result.stderr).toBe(0)
      expect(result.stdout.trim().split(/\r?\n/)).toEqual(['allowed', expect.stringMatching(/^denied:/)])
      expect(readFileSync(join(fixture.outside, 'probe.txt'), 'utf8')).toBe('ok')
      expect(existsSync(join(fixture.workspace, 'probe.txt'))).toBe(false)
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 120_000)

  it('keeps upstream Ctrl+C semantics for a confined ConPTY child', async (context) => {
    const fixture = createFixtureWorkspace('win-pty')
    const mounted = await mountProvider(fixture.workspace)
    const terminals: Awaited<ReturnType<typeof mounted.ctx.subprocess.spawnTerminal>>[] = []
    try {
      await mounted.ctx.plugin(LocalSubprocess)
      // The probe program must demonstrably accept a ConPTY Ctrl+C unconfined
      // before it can prove anything under a runner: on the CI runner
      // `powershell -Command Start-Sleep` ignored \x03 even unconfined, so the
      // baseline is picked from candidates in order and the FIRST
      // interruptible one becomes the program both runners execute.
      const candidates: { name: string; argv: string[]; ready?: string }[] = [
        {
          name: 'node-sigint',
          argv: [process.execPath, '-e',
            `process.stdout.write('ready\\n');process.on('SIGINT',()=>{process.stdout.write('sigint\\n');process.exit(130)});setInterval(()=>{},1000)`],
          ready: 'ready',
        },
        { name: 'cmd-ping', argv: ['cmd.exe', '/d', '/c', 'ping -n 60 127.0.0.1'] },
        { name: 'powershell-sleep', argv: ['powershell.exe', '-NoProfile', '-Command', 'Start-Sleep -Seconds 60'] },
      ]
      // One run of the same argv per terminal. The upstream runner calls
      // SetConsoleCtrlHandler(NULL, TRUE) — an ignore-Ctrl+C attribute the
      // confined child INHERITS — while our runner's SIGINT handling is a Node
      // handler and is not inherited. So parity is not the property: the
      // property is that the PLUGIN run is interrupted and exits with the
      // child's own code (the runner forwarded Ctrl+C and mirrored the child's
      // exit rather than dying itself).
      type Interrupt = { outcome: 'interrupted' | 'timeout' | 'failed' | 'no-input'; exitCode?: number | null }
      const interruptOutcome = async (argv: readonly string[], ready?: string): Promise<Interrupt> => {
        const terminal = await mounted.ctx.subprocess.spawnTerminal({
          argv: [...argv], cwd: fixture.workspace, rows: 24, cols: 100, terminalType: 'xterm-256color', graceMs: 3000,
        })
        terminals.push(terminal)
        terminal.output.resume()
        if (typeof terminal.write !== 'function') return { outcome: 'no-input' }
        try {
          if (ready !== undefined) {
            // Wait until the child is demonstrably running (its ready marker)
            // rather than racing the \x03 against startup.
            let seen = ''
            terminal.output.on('data', (chunk: Buffer | string) => { seen += chunk.toString() })
            const deadline = Date.now() + 5000
            while (!seen.includes(ready) && Date.now() < deadline) {
              await new Promise(resolve => setTimeout(resolve, 50))
            }
          } else {
            await new Promise(resolve => setTimeout(resolve, 2000))
          }
          await terminal.write('\x03')
          return await Promise.race([
            terminal.done.then(
              done => ({ outcome: 'interrupted' as const, exitCode: done.exitCode }),
              () => ({ outcome: 'failed' as const }),
            ),
            new Promise<Interrupt>(resolve => setTimeout(() => resolve({ outcome: 'timeout' }), 20_000)),
          ])
        } finally {
          await terminal.terminate()
        }
      }
      const unconfinedOutcomes: string[] = []
      let baseline: (typeof candidates)[number] | undefined
      let baselineExitCode: number | null | undefined
      for (const candidate of candidates) {
        const result = await interruptOutcome(candidate.argv, candidate.ready)
        unconfinedOutcomes.push(`${candidate.name}=${result.outcome}`)
        console.info(`ConPTY Ctrl+C unconfined candidate ${candidate.name}: ${result.outcome}`)
        if (result.outcome === 'no-input') {
          context.skip('this release exposes no terminal input API')
          return
        }
        if (result.outcome === 'interrupted') {
          baseline = candidate
          baselineExitCode = result.exitCode
          break
        }
      }
      // If NO candidate can be interrupted even unconfined the \x03 delivery
      // mechanism itself is wrong on this host — that is a test bug, not a
      // confinement fact, and the log needs every outcome to see it.
      expect(baseline, `no candidate program was interruptible even unconfined (${unconfinedOutcomes.join(', ')}); the Ctrl+C mechanism itself is broken here`).toBeDefined()
      const upstream = await mounted.provider.confine(baseline!.argv, mounted.policy)
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'extra', path: fixture.outside, recordedPath: canonicalPath(fixture.outside), access: 'read-write' }])
      const widened = await mounted.provider.confine(baseline!.argv, mounted.policy)
      const upstreamResult = await interruptOutcome(upstream.argv, baseline!.ready)
      console.info(`ConPTY Ctrl+C upstream (program=${baseline!.name}): ${upstreamResult.outcome} — ` +
        'an upstream runner characteristic: its SetConsoleCtrlHandler ignore flag is inherited by the confined child, ' +
        'so a timeout here is expected and not asserted')
      const pluginResult = await interruptOutcome(widened.argv, baseline!.ready)
      console.info(`ConPTY Ctrl+C plugin (program=${baseline!.name}): ${pluginResult.outcome} exit=${String(pluginResult.exitCode)}`)
      if (upstreamResult.outcome === 'no-input' || pluginResult.outcome === 'no-input') {
        context.skip('this release exposes no terminal input API')
        return
      }
      expect(pluginResult.outcome, 'the plugin-confined child was not interrupted by \\x03').toBe('interrupted')
      expect(pluginResult.exitCode,
        `the widened runner must mirror the child's own SIGINT exit (the unconfined baseline exited ${String(baselineExitCode)}), not die as the runner itself`)
        .toBe(baselineExitCode)
    } finally {
      for (const terminal of terminals) await terminal.terminate().catch(() => {})
      await mounted.ctx.fiber.dispose()
      fixture.dispose()
    }
  }, 180_000)

  it('enforces per-root access end to end: writable members write, read-only members only read', async () => {
    const fixture = createFixtureWorkspace('win-access')
    const primary = fixture.workspace
    const a = join(fixture.base, 'extra-a')
    const b = join(fixture.base, 'extra-b')
    for (const dir of [a, b]) mkdirSync(dir)
    // A pre-existing file in the read-only member proves reads still pass.
    writeFileSync(join(b, 'existing.txt'), 'seed')
    const mounted = await mountProvider(primary)
    try {
      const setRoots = (roots: readonly { id: string; path: string; access: 'read-write' | 'read-only' }[]) =>
        mounted.ctx.multiRootScope.setAdditionalRoots(primary,
          roots.map(root => ({ id: root.id, path: root.path, recordedPath: canonicalPath(root.path), access: root.access })))
      setRoots([
        { id: 'a', path: a, access: 'read-write' },
        { id: 'b', path: b, access: 'read-only' },
      ])

      const expectVerdicts = async (argv: readonly string[], wanted: readonly (string | RegExp)[]) => {
        const result = await spawnConfined(mounted, argv)
        expect(result.error).toBeUndefined()
        const lines = result.stdout.trim().split(/\r?\n/)
        expect(lines).toEqual(wanted.map(expectation => typeof expectation === 'string' ? expectation : expect.stringMatching(expectation)))
      }

      // Node fs.writeFileSync: primary and A writable, B refused, B readable.
      await expectVerdicts(
        [process.execPath, '-e', writeProbe([primary, a, b])],
        ['allowed', 'allowed', /^denied:/],
      )
      await expectVerdicts(
        [process.execPath, '-e', `console.log(require('fs').readFileSync(${JSON.stringify(join(b, 'existing.txt'))},'utf8'))`],
        ['seed'],
      )
      // PowerShell Set-Content: same verdicts under a different write API.
      await expectVerdicts(
        powershellArgv(`try { Set-Content -Path ${JSON.stringify(join(a, 'ps.txt'))} -Value ok -ErrorAction Stop; 'allowed' } catch { 'denied' }`),
        ['allowed'],
      )
      await expectVerdicts(
        powershellArgv(`try { Set-Content -Path ${JSON.stringify(join(b, 'ps.txt'))} -Value bad -ErrorAction Stop; 'allowed' } catch { 'denied' }`),
        ['denied'],
      )
      // The ConPTY path: the terminal spawns the confined argv, so the runner's
      // restricted token gates it exactly like a piped spawn.
      await mounted.ctx.plugin(LocalSubprocess)
      const terminal = await mounted.ctx.subprocess.spawnTerminal({
        argv: (await mounted.provider.confine([process.execPath, '-e', writeProbeMarked([primary, a, b], 'pty.txt')], mounted.policy)).argv as string[],
        cwd: primary, rows: 24, cols: 100, terminalType: 'xterm-256color', graceMs: 3000,
      })
      try {
        terminal.output.resume()
        let seen = ''
        terminal.output.on('data', (chunk: Buffer | string) => { seen += chunk.toString() })
        const done = await Promise.race([
          terminal.done.then(() => 'done' as const, () => 'failed' as const),
          new Promise<'timeout'>(resolve => setTimeout(() => resolve('timeout'), 60_000)),
        ])
        expect(done, `pty child never exited; output: ${seen}`).toBe('done')
        expect(ptyVerdicts(seen), `pty verdicts; raw output: ${JSON.stringify(seen)}`)
          .toEqual(['allowed', 'allowed', expect.stringMatching(/^denied:/)])
      } finally { await terminal.terminate() }

      // The in-process fence agrees with the kernel token on both verbs. The
      // file system needs the real policy/scope services, so it gets its own
      // context carrying the same scope entries.
      const fsCtx = new Context()
      try {
        await fsCtx.plugin(SessionProjectionRegistry)
        await fsCtx.plugin(SandboxPolicyService, { mode: 'workspace-write', workspaceRoot: primary })
        await fsCtx.plugin(MultiRootScopeService)
        await mountCompat(fsCtx)
        await fsCtx.plugin(MultiRootFileSystem, { cwd: primary })
        fsCtx.multiRootScope.setAdditionalRoots(primary, [
          { id: 'a', path: a, recordedPath: canonicalPath(a), access: 'read-write' },
          { id: 'b', path: b, recordedPath: canonicalPath(b), access: 'read-only' },
        ])
        const fs = fsCtx.fs
        await fs.writeText(await fs.resolve(join(a, 'via-fs.txt')), 'fs')
        await expect(fs.writeText(await fs.resolve(join(b, 'via-fs.txt')), 'fs'))
          .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
        await expect(fs.editText(await fs.resolve(join(b, 'existing.txt')), { oldString: 'seed', newString: 'x', replaceAll: false }))
          .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
      } finally { await fsCtx.fiber.dispose() }

      // Flip access: A read-only refuses new writes, B read-write accepts them.
      setRoots([
        { id: 'a', path: a, access: 'read-only' },
        { id: 'b', path: b, access: 'read-write' },
      ])
      await expectVerdicts(
        [process.execPath, '-e', writeProbe([a, b], 'after-flip.txt')],
        [/^denied:/, 'allowed'],
      )
      // Removing B revokes it entirely for new processes.
      setRoots([{ id: 'a', path: a, access: 'read-only' }])
      await expectVerdicts(
        [process.execPath, '-e', writeProbe([b], 'gone.txt')],
        [/^denied:/],
      )
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 300_000)

  it('drops the additional-root grant for a capped tool dispatch', async () => {
    const fixture = createFixtureWorkspace('win-toolcap')
    const primary = fixture.workspace
    const a = join(fixture.base, 'extra-a')
    mkdirSync(a)
    const mounted = await mountProvider(primary, { toolAccess: { bash: 'read-only' } })
    try {
      mounted.ctx.multiRootScope.setAdditionalRoots(primary, [
        { id: 'a', path: a, recordedPath: canonicalPath(a), access: 'read-write' },
      ])
      const waterfall = mounted.ctx.waterfall.bind(mounted.ctx) as (
        event: string,
        exec: { name: string; callId: string },
        next: () => Promise<unknown>,
      ) => Promise<unknown>
      const dispatch = (name: string, body: () => Promise<unknown>) => waterfall('tools/execute', { name, callId: name }, body)

      // Uncapped: the widened runner grants A and a confined write lands.
      await dispatch('write', async () => {
        const confined = await mounted.provider.confine([process.execPath, '-e', writeProbe([a], 'uncapped.txt')], mounted.policy)
        expect(confined.argv.slice(1)).toContain('--additional-root')
        const result = await spawnArgv(confined.argv[0]!, confined.argv.slice(1))
        expect(result.stdout.trim()).toBe('allowed')
        expect(existsSync(join(a, 'uncapped.txt'))).toBe(true)
      })

      // Capped: the runner is never given --additional-root, so the kernel
      // token alone refuses the write for Node and PowerShell alike.
      await dispatch('bash', async () => {
        const confined = await mounted.provider.confine([process.execPath, '-e', writeProbe([a], 'capped.txt')], mounted.policy)
        expect(confined.argv.slice(1)).not.toContain('--additional-root')
        const node = await spawnArgv(confined.argv[0]!, confined.argv.slice(1))
        expect(node.stdout.trim()).toMatch(/^denied:/)
        expect(existsSync(join(a, 'capped.txt'))).toBe(false)
        const ps = await spawnConfined(mounted, powershellArgv(
          `try { Set-Content -Path ${JSON.stringify(join(a, 'capped-ps.txt'))} -Value bad -ErrorAction Stop; 'allowed' } catch { 'denied' }`,
        ))
        expect(ps.stdout.trim()).toBe('denied')
      })
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('runs Git Bash confined when a Git installation is present', async (context) => {
    const fixture = createFixtureWorkspace('win-bash')
    const candidates = ['C:\\Program Files\\Git\\bin\\bash.exe', 'C:\\Program Files (x86)\\Git\\bin\\bash.exe']
    let bash = candidates.find(existsSync)
    if (bash === undefined) {
      try {
        bash = execFileSync('where', ['bash'], { encoding: 'utf8' }).split(/\r?\n/)[0]?.trim()
      } catch { bash = undefined }
    }
    if (bash === undefined || bash === '') {
      context.skip('no Git Bash on this host')
      return
    }
    const third = join(fixture.base, 'third')
    mkdirSync(third)
    const mounted = await mountProvider(fixture.workspace)
    try {
      const script = `echo x > '${fixture.outside.replace(/\\/g, '/')}/bash.txt' && echo bash-ok`
      // MSYS cannot start under the write-restricted Low-integrity token:
      // `NtCreateDirectoryObject(\BaseNamedObjects\msys-2.0…): 0xC0000022` on
      // newer releases, `*** fatal error - CreateFileMapping …, Win32 error
      // 5. Terminating.` (exit 256) on 0.1.5-rc.2. That is an upstream
      // restricted-token limitation, not a plugin defect — the property is
      // PARITY between the upstream runner's argv and the widened runner's
      // argv for the same child.
      const msysStartupFailure = (result: Spawned): boolean =>
        /NtCreateDirectoryObject|0xC0000022|\*\*\* fatal error - /i.test(result.stderr) || result.status === 3221225794
      const upstream = await mounted.provider.confine([bash, '-c', script], mounted.policy)
      const upstreamResult = await spawnArgv(upstream.argv[0]!, upstream.argv.slice(1))
      mounted.ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'extra', path: fixture.outside, recordedPath: canonicalPath(fixture.outside), access: 'read-write' }])
      const pluginResult = await spawnConfined(mounted, [bash, '-c', script])
      const upstreamFailed = msysStartupFailure(upstreamResult)
      const pluginFailed = msysStartupFailure(pluginResult)
      console.info(`Git Bash confined start: upstream=${upstreamFailed ? `msys startup failure (${String(upstreamResult.status)})` : `exit ${String(upstreamResult.status)}`} plugin=${pluginFailed ? `msys startup failure (${String(pluginResult.status)})` : `exit ${String(pluginResult.status)}`}`)
      if (upstreamFailed && pluginFailed) {
        console.info('documented limitation: Git Bash/MSYS cannot start under the restricted token; upstream and plugin agree')
        expect(existsSync(join(fixture.outside, 'bash.txt'))).toBe(false)
        expect(existsSync(join(third, 'bash.txt'))).toBe(false)
        return
      }
      expect(pluginFailed, `plugin runner failed where upstream started.\nplugin stderr: ${pluginResult.stderr}\nupstream stderr: ${upstreamResult.stderr}`).toBe(upstreamFailed)
      expect(pluginResult.status, pluginResult.stderr).toBe(0)
      expect(pluginResult.stdout).toContain('bash-ok')
      expect(readFileSync(join(fixture.outside, 'bash.txt'), 'utf8')).toContain('x')
      const denied = await spawnConfined(mounted, [bash, '-c', `echo x > '${third.replace(/\\/g, '/')}/bash.txt' && echo wrote || echo denied`])
      expect(denied.status, denied.stderr).toBe(0)
      expect(existsSync(join(third, 'bash.txt'))).toBe(false)
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('accepts a UAC-filtered caller: the broker mints for a TokenHasRestrictions identity', async () => {
    const fixture = createFixtureWorkspace('win-filtered')
    const ambient = join(fixture.base, 'ambient')
    mkdirSync(ambient)
    // An elevated run owns new fixtures through the Administrators group, which
    // a filtered token holds deny-only; hand the fixture paths to the caller's
    // user SID so the runner's caller-owned check can pass. Non-elevated the
    // caller already owns them and the icacls result is ignored either way.
    const systemTool = (name: string): string => join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', `${name}.exe`)
    const identity = execFileSync(systemTool('whoami'), ['/user', '/fo', 'csv', '/nh'], { encoding: 'utf8' })
    const userSid = identity.match(/S-1-\d+(?:-\d+)+/)?.[0]
    if (userSid !== undefined) {
      for (const dir of [fixture.base, ambient, fixture.outside]) {
        spawnSync(systemTool('icacls'), [dir, '/setowner', `*${userSid}`], { encoding: 'utf8', timeout: 60_000 })
      }
    }
    const mounted = await mountProvider(fixture.workspace)
    try {
      const prefix = await mounted.provider.restrictedArgvPrefix(
        { mode: 'danger-full-access', workspaceRoot: fixture.workspace }, [canonicalPath(fixture.outside)],
      )
      const koffiEntry = fileURLToPath(import.meta.resolve('koffi'))
      // Grandchild probe: the denied root refuses writes, ambient accepts them,
      // Administrators (when listed) is deny-only, and no bypass privilege
      // survived the filtered-token mint.
      const probe = `
const fs=require('fs'), k=require(${JSON.stringify(koffiEntry)});
const a=k.load('advapi32.dll'), b=k.load('kernel32.dll');
const bind=(lib,name,ret,args)=>lib.func('__stdcall',name,ret,args);
const tok=bind(a,'OpenProcessToken','int',['void*','uint32','void*']);
const info=bind(a,'GetTokenInformation','int',['void*','int','void*','uint32','void*']);
const privName=bind(a,'LookupPrivilegeNameW','int',['void*','void*','void*','void*']);
const convert=bind(a,'ConvertSidToStringSidW','int',['void*','void*']);
const free=bind(b,'LocalFree','void*',['void*']);
const cur=bind(b,'GetCurrentProcess','void*',[]);
const close=bind(b,'CloseHandle','int',['void*']);
const denied=${JSON.stringify(fixture.outside)}, ambient=${JSON.stringify(ambient)};
try{fs.writeFileSync(denied+'/filtered.txt','bad');console.log('escaped')}catch(e){if(!['EPERM','EACCES'].includes(e.code))throw e;console.log('denied')}
try{fs.writeFileSync(ambient+'/filtered.txt','ok');console.log('allowed')}catch(e){console.log('ambient-denied:'+(e&&e.code||e))}
const out=Buffer.alloc(8);if(!tok(cur(),10,out))throw Error('token query unavailable');
const token=k.decode(out,'void*');const size=Buffer.alloc(4);
info(token,2,null,0,size);const groups=Buffer.alloc(size.readUInt32LE());
if(!info(token,2,groups,groups.length,size))throw Error('TokenGroups unavailable');
const gcount=groups.readUInt32LE();let admins=null;
for(let i=0;i<gcount;i++){const g=groups.subarray(8+i*16,24+i*16);const so=Buffer.alloc(8);
if(!convert(k.decode(g,'void*'),so))continue;const name=k.decode(k.decode(so,'void*'),'char16_t',-1);free(k.decode(so,'void*'));
if(name==='S-1-5-32-544')admins=g.readUInt32LE(8)}
if(admins===null)console.log('admins-absent');
else if((admins&0x10)!==0&&(admins&4)===0)console.log('admins-deny-only');
else throw Error('Administrators retained enabled authority: 0x'+admins.toString(16));
info(token,3,null,0,size);const privs=Buffer.alloc(size.readUInt32LE());
if(!info(token,3,privs,privs.length,size))throw Error('TokenPrivileges unavailable');
const pcount=privs.readUInt32LE();const banned=new Set(['SeDebugPrivilege','SeBackupPrivilege','SeRestorePrivilege','SeTakeOwnershipPrivilege','SeTcbPrivilege','SeAssignPrimaryTokenPrivilege']);
for(let i=0;i<pcount;i++){const luid=privs.subarray(4+i*12,4+i*12+8);const nameSize=Buffer.alloc(4);nameSize.writeUInt32LE(64);
const nameBuf=Buffer.alloc(128);if(!privName(null,luid,nameBuf,nameSize))throw Error('LookupPrivilegeNameW failed');
const name=nameBuf.subarray(0,nameSize.readUInt32LE()*2).toString('utf16le');
if(banned.has(name))throw Error('bypass privilege survived: '+name)}
console.log('privs-clean');close(token);`
      const helper = join(REPO_ROOT, 'tests', 'support', 'windows-filtered-spawn.mjs')
      const upstreamRunner = UPSTREAM_RUNNER_ARGS()[1]!
      const argv = [...prefix, process.execPath, '-e', probe]
      const result = await spawnArgv(process.execPath, [helper, upstreamRunner, fixture.workspace, '--', argv[0]!, ...argv.slice(1)])
      expect(result.status, result.stderr).toBe(0)
      expect(result.stdout.trim().split(/\r?\n/)).toEqual([
        'denied', 'allowed', expect.stringMatching(/^admins-(deny-only|absent)$/), 'privs-clean',
      ])
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('keeps both deny sets when a confined child runs the Full-access runner again', async () => {
    const fixture = createFixtureWorkspace('win-nested')
    // Sibling deny roots must not share a parent: the outer runner's parent
    // guard denies WRITE_DAC on the first root's parent, which would block the
    // inner runner's own parent guard for the second root.
    const secondParent = mkdtempSync(join(dirname(fixture.base), 'dsh-mr-nestedb-'))
    const second = join(secondParent, 'second-deny')
    mkdirSync(second)
    const mounted = await mountProvider(fixture.workspace)
    try {
      const outerPrefix = await mounted.provider.restrictedArgvPrefix(
        { mode: 'danger-full-access', workspaceRoot: fixture.workspace }, [canonicalPath(fixture.outside)],
      )
      const innerPrefix = await mounted.provider.restrictedArgvPrefix(
        { mode: 'danger-full-access', workspaceRoot: fixture.workspace }, [canonicalPath(second)],
      )
      const innerArgv = [...innerPrefix, process.execPath, '-e', writeProbe([fixture.outside, second, fixture.workspace], 'nested.txt')]
      // The outer child's process token is the broker-minted deny token (no
      // restricting SIDs); the broker may remint it, and the remint must carry
      // BOTH deny-only groups, so the grandchild writes neither A nor B.
      const relay = `const r=require('child_process').spawnSync(${JSON.stringify(innerArgv[0])},${JSON.stringify(innerArgv.slice(1))},{encoding:'utf8'});process.stdout.write(r.stdout);process.stderr.write(r.stderr);process.exit(r.status??99)`
      const result = await spawnArgv(outerPrefix[0]!, [...outerPrefix.slice(1), process.execPath, '-e', relay])
      expect(result.status, result.stderr).toBe(0)
      expect(result.stdout.trim().split(/\r?\n/)).toEqual([
        expect.stringMatching(/^denied:/), expect.stringMatching(/^denied:/), 'allowed',
      ])
    } finally { await mounted.ctx.fiber.dispose(); rmSync(secondParent, { recursive: true, force: true }); fixture.dispose() }
  }, 180_000)

  it('refuses a packaged (MSIX/Store) child with an actionable diagnosis', async (context) => {
    const alias = join(process.env.LOCALAPPDATA ?? '', 'Microsoft', 'WindowsApps', 'pwsh.exe')
    // App-execution aliases are reparse points that cannot be stat-followed:
    // existsSync reports false while lstatSync sees the entry itself.
    let aliasPresent = false
    try { aliasPresent = lstatSync(alias).size > 0 } catch { aliasPresent = false }
    if (!aliasPresent) {
      context.skip('no Store pwsh app-execution alias on this host')
      return
    }
    const fixture = createFixtureWorkspace('win-packaged')
    const marker = join(fixture.workspace, 'packaged-ran.txt')
    const mounted = await mountProvider(fixture.workspace)
    try {
      const prefix = await mounted.provider.restrictedArgvPrefix(
        { mode: 'danger-full-access', workspaceRoot: fixture.workspace }, [canonicalPath(fixture.outside)],
      )
      const result = await spawnArgv(prefix[0]!, [...prefix.slice(1), alias, '-NoProfile', '-NonInteractive', '-Command',
        `[IO.File]::WriteAllText('${marker.replace(/'/g, "''")}', 'ran')`])
      expect(result.status, result.stdout + result.stderr).toBe(127)
      expect(result.stderr).toContain('windows-acl-run:')
      expect(result.stderr).toContain('packaged (MSIX/Microsoft Store)')
      expect(existsSync(marker)).toBe(false)
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)
})

/**
 * Phase B prototype evidence: `pinWindowsDenyPaths` holds a GENERIC_READ +
 * share-read/write (no delete-sharing) handle on every ancestor of each deny
 * root, so renames of the registered tree fail while a confined child would
 * be running — without any persistent ancestor ACL. This is the
 * runner-integration-free feasibility check: every case OBSERVES the rename
 * attempt failing and the tree staying put, never infers it from the acquire
 * succeeding. No broker, no build, no ACL writes.
 */
describe.runIf(process.platform === 'win32')('deny path guard', () => {
  let nativePromise: Promise<WindowsNative> | undefined
  const loadNative = (): Promise<WindowsNative> =>
    (nativePromise ??= loadWindowsNative(UPSTREAM_RUNNER_ARGS()[1]!))

  it('blocks parent, grandparent and root renames while held, releases on close, keeps siblings writable', async () => {
    const fixture = createFixtureWorkspace('path-guard')
    const cage = join(fixture.base, 'cage')
    const inner = join(cage, 'inner')
    const denied = join(inner, 'denied')
    mkdirSync(denied, { recursive: true })
    writeFileSync(join(denied, 'seed.txt'), 'seed')
    const guard = pinWindowsDenyPaths(await loadNative(), [canonicalPath(denied)])
    try {
      // The deny root, its parent, its grandparent, and the fixture base are
      // all pinned: every rename attempt fails and the tree does not move.
      for (const dir of [denied, inner, cage, fixture.base]) {
        expectRenameBlocked(dir, `${dir}-moved`)
      }
      expect(readFileSync(join(denied, 'seed.txt'), 'utf8')).toBe('seed')
      // Read+write sharing still permits ordinary work inside pinned dirs.
      writeFileSync(join(inner, 'sibling.txt'), 'sibling')
      expect(readFileSync(join(inner, 'sibling.txt'), 'utf8')).toBe('sibling')
      // A spawned CHILD process hits the same block — the pin is on the object,
      // not on our process token.
      const child = await spawnArgv(process.execPath, ['-e',
        `require('fs').renameSync(${JSON.stringify(inner)}, ${JSON.stringify(`${inner}-child`)})`])
      expect(child.status, `child rename must fail: ${child.stdout}${child.stderr}`).not.toBe(0)
      expect(existsSync(inner)).toBe(true)
      expect(existsSync(`${inner}-child`)).toBe(false)
    } finally {
      guard.close()
    }
    // Released: the identical rename now succeeds.
    renameSync(inner, `${inner}-moved`)
    expect(existsSync(`${inner}-moved`)).toBe(true)
    fixture.dispose()
  }, 120_000)

  it('fails acquisition when a DELETE-sharing handle already holds a deny path', async () => {
    const native = await loadNative()
    // Bind the same public seam for a raw conflicting handle: DELETE access,
    // DELETE-only sharing — our GENERIC_READ pin is then NOT covered
    // by its share mode, so CreateFileW must fail before any spawn.
    const api = native.extendWin32ProcessBindings(({ kernel32, bind }) => ({
      createFileW: bind(kernel32, 'CreateFileW', 'void*', ['str16', 'uint32', 'uint32', 'void*', 'uint32', 'uint32', 'void*']),
      closeHandle: bind(kernel32, 'CloseHandle', 'int', ['void*']),
      getLastError: bind(kernel32, 'GetLastError', 'uint32', []),
    }))
    const fixture = createFixtureWorkspace('path-guard-share')
    const denied = join(fixture.base, 'denied')
    mkdirSync(denied)
    const blocker = api.createFileW!(canonicalPath(denied), 0x10000, 4, null, 3, 0x02200000, null)
    expect(blocker === null || BigInt(blocker as bigint) === -1n).toBe(false)
    try {
      expect(() => pinWindowsDenyPaths(native, [canonicalPath(denied)])).toThrow(/CreateFileW.*Win32 32/)
    } finally {
      api.closeHandle!(blocker)
    }
    // Once the conflicting handle is gone the same pin succeeds.
    pinWindowsDenyPaths(native, [canonicalPath(denied)]).close()
    fixture.dispose()
  }, 120_000)

  it('refuses a deny root reached through a junction ancestor, leaving the target untouched', async () => {
    const fixture = createFixtureWorkspace('path-guard-junction')
    const real = join(fixture.base, 'real')
    mkdirSync(join(real, 'denied'), { recursive: true })
    writeFileSync(join(real, 'denied', 'victim.txt'), 'original')
    const link = join(fixture.base, 'alias')
    symlinkSync(real, link, 'junction')
    // The lexical spelling crosses the reparse point: the guard must refuse
    // instead of pinning the link's target under a borrowed name.
    const native = await loadNative()
    expect(() => pinWindowsDenyPaths(native, [join(link, 'denied')])).toThrow(/reparse point/)
    // Nothing was pinned or mutated: the real directory still renames freely.
    renameSync(real, `${real}-moved`)
    expect(readFileSync(join(`${real}-moved`, 'denied', 'victim.txt'), 'utf8')).toBe('original')
    fixture.dispose()
  }, 120_000)

  it('accepts a canonical alias spelling and pins the resolved ancestors', async () => {
    const fixture = createFixtureWorkspace('path-guard-alias')
    const real = join(fixture.base, 'real')
    const denied = join(real, 'denied')
    mkdirSync(denied, { recursive: true })
    const link = join(fixture.base, 'alias')
    symlinkSync(real, link, 'junction')
    // The canonical spelling of alias\denied is real\denied: accepted, and the
    // REAL ancestors are the pinned ones — the link name is cosmetic.
    const canonical = canonicalPath(join(link, 'denied'))
    expect(canonical.toLowerCase()).toBe(canonicalPath(denied).toLowerCase())
    const guard = pinWindowsDenyPaths(await loadNative(), [canonical])
    try {
      expectRenameBlocked(real, `${real}-moved`)
      expectRenameBlocked(denied, `${denied}-moved`)
    } finally {
      guard.close()
    }
    fixture.dispose()
  }, 120_000)

  it('pins a deny root on a second fixed drive when one is writable', async (context) => {
    const probe = createFixtureWorkspace('path-guard-xdrive')
    const drive = secondDrive(parse(probe.base).root.toUpperCase())
    probe.dispose()
    if (drive === undefined) {
      context.skip('no second writable fixed drive found')
      return
    }
    const root = mkdtempSync(join(drive, 'dsh-mr-guard-'))
    const denied = join(root, 'denied')
    mkdirSync(denied)
    const guard = pinWindowsDenyPaths(await loadNative(), [canonicalPath(denied)])
    try {
      expectRenameBlocked(denied, `${denied}-moved`)
      expectRenameBlocked(root, `${root}-moved`)
    } finally {
      guard.close()
      rmSync(root, { recursive: true, force: true })
    }
  }, 120_000)
})

/**
 * Phase B runner integration evidence: the shipped ambient-deny runner holds
 * the ancestor pins for the WHOLE confined lifetime — acquired before any
 * token request or ACL edit, released only after the kill-on-close Job has
 * drained. Every case goes through `restrictedArgvPrefix` + the real
 * `lib/windows-runner.js` (broker included), observes the blocked rename or
 * the drained descendant directly, and never infers safety from the runner
 * merely having started.
 */
describe.runIf(process.platform === 'win32')('ancestor guard', () => {
  let nativePromise: Promise<WindowsNative> | undefined
  const loadNative = (): Promise<WindowsNative> =>
    (nativePromise ??= loadWindowsNative(UPSTREAM_RUNNER_ARGS()[1]!))

  /** Set one read-only member and return the ambient-deny runner prefix. */
  async function restrictedPrefix(mounted: Mounted, workspace: string, denied: string): Promise<readonly string[]> {
    mounted.ctx.multiRootScope.setAdditionalRoots(workspace, [
      { id: 'ro', path: denied, recordedPath: canonicalPath(denied), access: 'read-only' },
    ])
    const policy: SandboxExecutionPolicy = { mode: 'danger-full-access', workspaceRoot: workspace }
    const deniedRoots = mounted.ctx.multiRootScope.resolve(policy).deniedRoots
    expect(deniedRoots).toContain(canonicalPath(denied))
    return await mounted.provider.restrictedArgvPrefix(policy, deniedRoots)
  }

  it('keeps the denied tree unrenamable inside the restricted child, and the fs fence still refuses the registered spelling', async () => {
    const fixture = createFixtureWorkspace('win-ancestor-shell')
    const cage = join(fixture.base, 'cage')
    const inner = join(cage, 'inner')
    const denied = join(inner, 'ro-root')
    mkdirSync(denied, { recursive: true })
    const seed = join(denied, 'seed.txt')
    writeFileSync(seed, 'seed')
    const mounted = await mountProvider(fixture.workspace)
    try {
      const prefix = await restrictedPrefix(mounted, fixture.workspace, denied)
      const ambient = join(fixture.workspace, 'ambient.txt')
      // The restricted child attempts the escape directly: rename the deny
      // root's parent AND grandparent, then prove ambient writes still work.
      const script = `const fs=require('fs');for(const dir of ${JSON.stringify([inner, cage])}){try{fs.renameSync(dir,dir+'-moved');console.log('rename-escaped')}catch(e){console.log('rename-denied:'+(e&&e.code||e))}}fs.writeFileSync(${JSON.stringify(ambient)},'ok');console.log('ambient-ok')`
      const result = await spawnArgv(prefix[0]!, [...prefix.slice(1), process.execPath, '-e', script])
      expect(result.status, result.stderr).toBe(0)
      expect(result.stdout.trim().split(/\r?\n/)).toEqual([
        expect.stringMatching(/^rename-denied:E/), expect.stringMatching(/^rename-denied:E/), 'ambient-ok',
      ])
      expect(existsSync(inner)).toBe(true)
      expect(existsSync(`${inner}-moved`)).toBe(false)
      expect(existsSync(`${cage}-moved`)).toBe(false)
      expect(readFileSync(seed, 'utf8')).toBe('seed')
      expect(readFileSync(ambient, 'utf8')).toBe('ok')

      // The in-process fence judges the SAME registered spelling: because the
      // tree never moved, the original protected file is still denied to host
      // fs writes too — reproducing the actual shell → fs sequence.
      const fsCtx = new Context()
      try {
        await fsCtx.plugin(SessionProjectionRegistry)
        await fsCtx.plugin(SandboxPolicyService, { mode: 'danger-full-access', workspaceRoot: fixture.workspace })
        await fsCtx.plugin(MultiRootScopeService)
        await mountCompat(fsCtx)
        await fsCtx.plugin(MultiRootFileSystem, { cwd: fixture.workspace })
        fsCtx.multiRootScope.setAdditionalRoots(fixture.workspace, [
          { id: 'ro', path: denied, recordedPath: canonicalPath(denied), access: 'read-only' },
        ])
        const fs = fsCtx.fs
        await expect(fs.writeText(await fs.resolve(seed), 'bad'))
          .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
        await expect(fs.editText(await fs.resolve(seed), { oldString: 'seed', newString: 'x', replaceAll: false }))
          .rejects.toMatchObject({ code: 'FS_SANDBOX_DENIED' })
      } finally { await fsCtx.fiber.dispose() }
      expect(readFileSync(seed, 'utf8')).toBe('seed')
      expect(existsSync(`${inner}-moved`)).toBe(false)
      expect(existsSync(`${cage}-moved`)).toBe(false)
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('holds the pins past the direct child exit until the Job has drained its descendant', async () => {
    const fixture = createFixtureWorkspace('win-ancestor-drain')
    const cage = join(fixture.base, 'cage')
    const denied = join(cage, 'ro-root')
    mkdirSync(denied, { recursive: true })
    const mounted = await mountProvider(fixture.workspace)
    try {
      const prefix = await restrictedPrefix(mounted, fixture.workspace, denied)
      const pidFile = join(fixture.workspace, 'descendant.pid')
      const escaped = join(fixture.workspace, 'escaped.txt')
      const go = join(fixture.workspace, 'go.flag')
      // The direct child spawns a descendant (Job member — the Job grants no
      // breakaway), prints the ready marker, then WAITS on a go-file: the
      // "pins held while the runner is active" probe must not race the
      // child's own exit. The descendant records its pid, then would write
      // the escape marker seconds later — past the runner's exit if the Job
      // drain is missing.
      const descendant = `require('fs').writeFileSync(${JSON.stringify(pidFile)},String(process.pid));setTimeout(()=>require('fs').writeFileSync(${JSON.stringify(escaped)},'escaped'),3000)`
      const script = `const cp=require('child_process'),fs=require('fs');const d=cp.spawn(process.execPath,['-e',${JSON.stringify(descendant)}],{stdio:'ignore'});d.unref();console.log('ready');const t=setInterval(()=>{if(fs.existsSync(${JSON.stringify(go)})){clearInterval(t);process.exit(0)}},50);setTimeout(()=>process.exit(9),60000)`
      const runner = spawnObserved([...prefix, process.execPath, '-e', script])
      try {
        await waitFor(() => runner.output().includes('ready'), 'the confined child ready marker', 30_000)
        // The runner is demonstrably active (the direct child is still
        // running): the ancestor cannot be renamed.
        expectRenameBlocked(cage, `${cage}-moved`)
        await waitFor(() => existsSync(pidFile), 'the descendant pid marker', 15_000)
        const pid = Number(readFileSync(pidFile, 'utf8').trim())
        expect(Number.isInteger(pid)).toBe(true)
        const observedAt = Date.now()
        // Release the direct child; the descendant outlives it inside the Job.
        writeFileSync(go, 'go')
        const result = await Promise.race([
          runner.done,
          new Promise<never>((_, reject) => setTimeout(() => reject(new Error('runner did not exit after the direct child did')), 60_000)),
        ])
        expect(result.status, result.stderr).toBe(0)
        // The drain, not luck, is what stops the descendant: the Job's
        // ActiveProcesses reached zero before the runner exited — on the
        // orderly path the descendant pid is already dead, no post-exit wait.
        expect(processAlive(pid), `Job descendant ${pid} outlived the drained runner`).toBe(false)
        const elapsed = Date.now() - observedAt
        if (elapsed < 3600) await new Promise(resolve => setTimeout(resolve, 3600 - elapsed))
        expect(existsSync(escaped), 'a Job descendant survived the drain and wrote after the runner exited').toBe(false)
      } finally {
        runner.child.kill('SIGKILL')
        await runner.done.catch(() => {})
      }
      // Only after full drain + runner exit may the rename succeed again.
      await waitFor(() => {
        try { renameSync(cage, `${cage}-moved`); return true } catch { return false }
      }, 'the ancestor pins to release', 15_000)
      expect(existsSync(`${cage}-moved`)).toBe(true)
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('releases the pins after a terminated ConPTY launch, leaving no survivor', async () => {
    const fixture = createFixtureWorkspace('win-ancestor-cancel')
    const cage = join(fixture.base, 'cage')
    const denied = join(cage, 'ro-root')
    mkdirSync(denied, { recursive: true })
    const mounted = await mountProvider(fixture.workspace)
    try {
      const prefix = await restrictedPrefix(mounted, fixture.workspace, denied)
      await mounted.ctx.plugin(LocalSubprocess)
      // The ready marker carries the confined child's pid so the test can
      // prove no survivor — not merely that the terminal resolved.
      const terminal = await mounted.ctx.subprocess.spawnTerminal({
        argv: [...prefix, process.execPath, '-e', `process.stdout.write('ready:'+process.pid+'\\n');setInterval(()=>{},1000)`],
        cwd: fixture.workspace, rows: 24, cols: 100, terminalType: 'xterm-256color', graceMs: 3000,
      })
      let seen = ''
      try {
        terminal.output.on('data', (chunk: Buffer | string) => { seen += chunk.toString() })
        terminal.output.resume()
        await waitFor(() => /ready:\d+/.test(seen), 'the confined ready marker', 30_000)
        const childPid = Number(seen.match(/ready:(\d+)/)![1])
        expectRenameBlocked(cage, `${cage}-moved`)
        await terminal.terminate()
        await Promise.race([
          terminal.done,
          new Promise<never>((_, reject) => setTimeout(() => reject(new Error('terminated runner never finished')), 60_000)),
        ])
        // Forced termination of the runner kills the Job via kill-on-close;
        // the pin handles die with the runner process.
        await waitFor(() => !processAlive(childPid), `confined child ${childPid} to exit`, 15_000)
      } finally { await terminal.terminate() }
      await waitFor(() => {
        try { renameSync(cage, `${cage}-moved`); return true } catch { return false }
      }, 'the ancestor pins to release', 15_000)
      expect(existsSync(`${cage}-moved`)).toBe(true)
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('refuses the shipped launch when an incompatible handle already holds an ancestor', async () => {
    const fixture = createFixtureWorkspace('win-ancestor-blocked')
    const cage = join(fixture.base, 'cage')
    const denied = join(cage, 'ro-root')
    mkdirSync(denied, { recursive: true })
    const mounted = await mountProvider(fixture.workspace)
    try {
      const prefix = await restrictedPrefix(mounted, fixture.workspace, denied)
      const api = (await loadNative()).extendWin32ProcessBindings(({ kernel32, bind }) => ({
        createFileW: bind(kernel32, 'CreateFileW', 'void*', ['str16', 'uint32', 'uint32', 'void*', 'uint32', 'uint32', 'void*']) as NativeFunction,
        closeHandle: bind(kernel32, 'CloseHandle', 'int', ['void*']) as NativeFunction,
        getLastError: bind(kernel32, 'GetLastError', 'uint32', []) as NativeFunction,
      }))
      // A DELETE-access handle sharing ONLY delete: the runner's pin open
      // (GENERIC_READ with read+write sharing) is not covered, so acquisition
      // must fail before any token request, ACL edit, or child launch.
      const blocker = api.createFileW!(canonicalPath(cage), 0x10000, 4, null, 3, 0x02200000, null)
      expect(blocker === null || BigInt(blocker as bigint) === -1n || BigInt(blocker as bigint) === 0xffffffffffffffffn).toBe(false)
      try {
        const sentinel = join(fixture.workspace, 'launched.txt')
        const result = await spawnArgv(prefix[0]!, [...prefix.slice(1), process.execPath, '-e',
          `require('fs').writeFileSync(${JSON.stringify(sentinel)},'ran')`])
        expect(result.status).toBe(127)
        expect(result.stderr).toContain('windows-acl-run:')
        expect(result.stderr).toContain('CreateFileW')
        expect(existsSync(sentinel)).toBe(false)
        // The refused launch left the tree untouched.
        expect(existsSync(cage)).toBe(true)
        expect(existsSync(denied)).toBe(true)
      } finally {
        api.closeHandle!(blocker)
      }
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)
})


/**
 * Phase C1 evidence: the shipped ambient-deny runner scans EVERY deny root
 * and descendant — read-only — before the first token request or ACL write.
 * A multi-link file or an uninspectable node exits 127 with the hardlink/scan
 * diagnostic, the child never runs, and no security descriptor anywhere has
 * moved. SDDL snapshots prove the before/after equality directly.
 */
describe.runIf(process.platform === 'win32')('hardlink preflight', () => {
  /**
   * The security descriptor as the kernel reports it — SDDL text, read
   * through `icacls /save` rather than PowerShell: a mixed pwsh/5.1 host can
   * make `powershell.exe` autoload an incompatible `Microsoft.PowerShell.
   * Security` module from the shared analysis cache — the flake is in the
   * runtime, not in the path under test.
   */
  function sddlOf(path: string): string {
    const icacls = join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'icacls.exe')
    const save = join(tmpdir(), `sddl-${process.pid}-${Math.random().toString(16).slice(2)}.txt`)
    const saveResult = spawnSync(icacls, [path, '/save', save], { encoding: 'utf8', timeout: 60_000 })
    try {
      expect(saveResult.status, saveResult.stderr).toBe(0)
      // The save file is UTF-16: one `path\nSDDL` pair per saved object.
      const lines = readFileSync(save, 'utf16le').split(/\r?\n/).filter(line => line.trim() !== '')
      expect(lines.length).toBeGreaterThanOrEqual(2)
      const sddl = lines[lines.length - 1]!.trim()
      // `D:` control flags: AI/AR are bookkeeping, not access. The runner's
      // parent-guard write on a deny root's parent re-derives the DACL of
      // every auto-inheriting sibling — an ACE-identical descriptor comes
      // back flagged `D:AI` where a `D:`-drive fixture had plain `D:`. Keep
      // `P` (protected blocks inheritance — access-relevant); compare the
      // rest byte-for-byte.
      return sddl.replace(/^(D:)([A-Z]*)/, (_match, prefix: string, flags: string) => prefix + flags.replace(/A[IR]/g, ''))
    } finally { rmSync(save, { force: true }) }
  }

  /** Snapshot every listed path; `expectUnchanged` compares after the run. */
  function aclSnapshot(paths: readonly string[]): () => void {
    const before = new Map(paths.map(path => [path, sddlOf(path)]))
    return () => {
      for (const [path, sddl] of before) {
        expect(sddlOf(path), `ACL of ${path} changed`).toBe(sddl)
      }
    }
  }

  /** A confined launch that must refuse BEFORE the sentinel could run. */
  async function expectPreflightRefusal(
    prefix: readonly string[], sentinel: string, diagnostics: RegExp,
  ): Promise<void> {
    const result = await spawnArgv(prefix[0]!, [...prefix.slice(1), process.execPath, '-e',
      `require('fs').writeFileSync(${JSON.stringify(sentinel)},'ran')`])
    expect(result.status, result.stderr).toBe(127)
    expect(result.stderr).toContain('windows-acl-run:')
    expect(result.stderr).toMatch(diagnostics)
    expect(existsSync(sentinel), 'the child must never run on a preflight refusal').toBe(false)
  }

  /** Mount a provider with `roots` as read-only members and return its prefix. */
  async function denyPrefix(mounted: Mounted, workspace: string, roots: readonly string[]): Promise<readonly string[]> {
    mounted.ctx.multiRootScope.setAdditionalRoots(workspace, roots.map((path, i) => ({
      id: `ro-${i}`, path, recordedPath: canonicalPath(path), access: 'read-only' as const,
    })))
    const policy: SandboxExecutionPolicy = { mode: 'danger-full-access', workspaceRoot: workspace }
    const scope = mounted.ctx.multiRootScope.resolve(policy)
    return await mounted.provider.restrictedArgvPrefix(policy, scope.deniedRoots, undefined, scope.protectedHome)
  }

  it('refuses a deep hardlink before any ACL write — every descriptor unchanged', async () => {
    const fixture = createFixtureWorkspace('win-hl-deep')
    const denied = join(fixture.base, 'ro-root')
    mkdirSync(join(denied, 'sub', 'dir'), { recursive: true })
    const outsideLink = join(fixture.base, 'outside-link.txt')
    writeFileSync(join(denied, 'sub', 'dir', 'linked.txt'), 'shared')
    linkSync(join(denied, 'sub', 'dir', 'linked.txt'), outsideLink)
    const mounted = await mountProvider(fixture.workspace)
    const before = aclSnapshot([denied, join(denied, 'sub'), join(denied, 'sub', 'dir'), join(denied, 'sub', 'dir', 'linked.txt'), outsideLink])
    try {
      const prefix = await denyPrefix(mounted, fixture.workspace, [denied])
      await expectPreflightRefusal(prefix, join(fixture.workspace, 'sentinel.txt'), /hardlinked file.*links=2/s)
    before()
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('leaves earlier roots byte-identical when the LAST root is the hardlinked one', async () => {
    const fixture = createFixtureWorkspace('win-hl-multi')
    const first = join(fixture.base, 'ro-first')
    const last = join(fixture.base, 'ro-last')
    mkdirSync(first)
    mkdirSync(last)
    const firstFile = join(first, 'keep.txt')
    writeFileSync(firstFile, 'keep')
    writeFileSync(join(last, 'linked.txt'), 'shared')
    linkSync(join(last, 'linked.txt'), join(fixture.base, 'external.txt'))
    const mounted = await mountProvider(fixture.workspace)
    const before = aclSnapshot([first, firstFile, last, join(last, 'linked.txt'), join(fixture.base, 'external.txt')])
    try {
      const prefix = await denyPrefix(mounted, fixture.workspace, [first, last])
      await expectPreflightRefusal(prefix, join(fixture.workspace, 'sentinel.txt'), /hardlinked file.*links=2/s)
    before()
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('refuses a same-tree hardlink — two names inside one root are still multi-link', async () => {
    const fixture = createFixtureWorkspace('win-hl-same')
    const denied = join(fixture.base, 'ro-root')
    mkdirSync(denied)
    writeFileSync(join(denied, 'a.txt'), 'shared')
    linkSync(join(denied, 'a.txt'), join(denied, 'b.txt'))
    const mounted = await mountProvider(fixture.workspace)
    const before = aclSnapshot([denied, join(denied, 'a.txt'), join(denied, 'b.txt')])
    try {
      const prefix = await denyPrefix(mounted, fixture.workspace, [denied])
      await expectPreflightRefusal(prefix, join(fixture.workspace, 'sentinel.txt'), /hardlinked file.*links=2/s)
    before()
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('names the protected DSH home and the isolation remediation for a hardlinked home file', async () => {
    const fixture = createFixtureWorkspace('win-hl-home')
    const denied = join(fixture.base, 'ro-root')
    const home = join(fixture.base, 'dsh-home')
    mkdirSync(denied)
    mkdirSync(home)
    writeFileSync(join(home, 'store.json'), '{}')
    linkSync(join(home, 'store.json'), join(fixture.base, 'home-copy.json'))
    const mounted = await mountProvider(fixture.workspace, { dshHome: home })
    const before = aclSnapshot([home, join(home, 'store.json'), join(fixture.base, 'home-copy.json')])
    try {
      // The home joins the deny set only once a registered restriction exists.
      const prefix = await denyPrefix(mounted, fixture.workspace, [denied])
      const scope = mounted.ctx.multiRootScope.resolve({ mode: 'danger-full-access', workspaceRoot: fixture.workspace })
      expect(scope.protectedHome).toBe(canonicalPath(home))
      await expectPreflightRefusal(prefix, join(fixture.workspace, 'sentinel.txt'),
        /protected DSH home.*links=2.*isolate-profiles/s)
      before()
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('refuses an uninspectable tree — an unreadable file fails the scan, nothing is mutated', async context => {
    const fixture = createFixtureWorkspace('win-hl-locked')
    const denied = join(fixture.base, 'ro-root')
    mkdirSync(denied)
    const lockedFile = join(denied, 'locked.txt')
    writeFileSync(lockedFile, 'locked')
    // Deny the caller's read on one child: the metadata-only inspection open
    // still evaluates access and fails ACCESS_DENIED. (A share-mode lock does
    // NOT cover this path — FILE_READ_ATTRIBUTES opens are transparent to the
    // sharing gate, the same probe result Phase B established.)
    const systemTool = (name: string): string => join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', `${name}.exe`)
    const userSid = execFileSync(systemTool('whoami'), ['/user', '/fo', 'csv', '/nh'], { encoding: 'utf8' })
      .match(/S-1-\d+(?:-\d+)+/)?.[0]
    expect(userSid, 'cannot create the unreadable fixture without the caller SID').not.toBeUndefined()
    const deniedAcl = spawnSync(systemTool('icacls'), [lockedFile, '/deny', `*${userSid}:(R)`], { encoding: 'utf8', timeout: 60_000 })
    expect(deniedAcl.status, deniedAcl.stderr).toBe(0)
    // On an elevated host the runner's FILE_FLAG_BACKUP_SEMANTICS open
    // bypasses the deny ACE through SeBackupPrivilege — the file stays
    // inspectable and no refusal can occur. libuv opens files with the same
    // flag, so a plain read probes the same open class the preflight uses.
    let bypassed = false
    try { readFileSync(lockedFile, 'utf8'); bypassed = true } catch { /* the deny holds */ }
    if (bypassed) {
      spawnSync(systemTool('icacls'), [lockedFile, '/remove:d', `*${userSid}`], { encoding: 'utf8', timeout: 60_000 })
      fixture.dispose()
      context.skip('the host token bypasses the read deny through backup-privileged opens — an uninspectable fixture cannot be built')
      return
    }
    const mounted = await mountProvider(fixture.workspace)
    // Baseline includes the test's own deny ACE — the failed run must move nothing.
    const before = aclSnapshot([denied, lockedFile])
    try {
      const prefix = await denyPrefix(mounted, fixture.workspace, [denied])
      await expectPreflightRefusal(prefix, join(fixture.workspace, 'sentinel.txt'), /cannot inspect.*Win32 5/s)
      before()
    } finally {
      spawnSync(systemTool('icacls'), [lockedFile, '/remove:d', `*${userSid}`], { encoding: 'utf8', timeout: 60_000 })
      await mounted.ctx.fiber.dispose()
      fixture.dispose()
    }
  }, 180_000)

  it('denies a junction on itself without scanning or mutating its external target', async () => {
    const fixture = createFixtureWorkspace('win-hl-junction')
    const denied = join(fixture.base, 'ro-root')
    const target = join(fixture.base, 'junction-target')
    mkdirSync(denied)
    mkdirSync(target)
    const targetFile = join(target, 'victim.txt')
    writeFileSync(targetFile, 'original')
    symlinkSync(target, join(denied, 'junc'), 'junction')
    const mounted = await mountProvider(fixture.workspace)
    const before = aclSnapshot([target, targetFile])
    try {
      const prefix = await denyPrefix(mounted, fixture.workspace, [denied])
      const sentinel = join(fixture.workspace, 'sentinel.txt')
      const result = await spawnArgv(prefix[0]!, [...prefix.slice(1), process.execPath, '-e',
        `require('fs').writeFileSync(${JSON.stringify(sentinel)},'ran')`])
      expect(result.status, result.stderr).toBe(0)
      expect(existsSync(sentinel)).toBe(true)
      // The target was never opened for inspection or mutation — its content
      // and security descriptor are byte-identical, and ambient writes to it
      // still succeed (its own canonical policy is a different root's).
      writeFileSync(targetFile, 'ambient')
    before()
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)

  it('accepts independent copies — ambient writes allowed, denied root refused, external original untouched', async () => {
    const fixture = createFixtureWorkspace('win-hl-copies')
    const denied = join(fixture.base, 'ro-root')
    mkdirSync(denied)
    const original = join(fixture.base, 'original.txt')
    writeFileSync(original, 'original')
    // A COPY, not a link: independent ACL storage, safe to deny.
    writeFileSync(join(denied, 'copy.txt'), readFileSync(original, 'utf8'))
    const mounted = await mountProvider(fixture.workspace)
    const before = aclSnapshot([original])
    try {
      const prefix = await denyPrefix(mounted, fixture.workspace, [denied])
      const result = await spawnArgv(prefix[0]!, [...prefix.slice(1), process.execPath, '-e',
        writeProbe([fixture.workspace, denied], 'copy-check.txt')])
      expect(result.status, result.stderr).toBe(0)
      expect(result.stdout.trim().split(/\r?\n/)).toEqual(['allowed', expect.stringMatching(/^denied:/)])
      expect(readFileSync(original, 'utf8')).toBe('original')
    before()
    } finally { await mounted.ctx.fiber.dispose(); fixture.dispose() }
  }, 180_000)
})
