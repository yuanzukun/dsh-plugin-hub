import { createHash } from 'node:crypto'
import { mkdirSync, readFileSync, writeFileSync, rmSync, renameSync, symlinkSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { afterEach, describe, expect, it, vi } from 'vitest'
import AgentRegistry, { type Agent } from '@deepseek-ai/dsh-agent'
import LlmRuntime, { LlmAdapter, ToolCallId, createMessage, createUserMessage, createToolResultMessage, type GenerateOptions, type StreamChunk } from '@deepseek-ai/dsh-llm'
import Presets from '@deepseek-ai/dsh-permission-presets'
import Sessions, { SessionId } from '@deepseek-ai/dsh-session'
import Projections from '@deepseek-ai/dsh-session-projection'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import Policy from '@deepseek-ai/dsh-sandbox-policy'
import Tools from '@deepseek-ai/dsh-tools'
import { defineContentToolFixture } from '@deepseek-ai/dsh-tool-testkit'
import { executeTool, installToolExecutor } from '../../support/tool-executor.ts'
import Approval, {setApprovalPolicy} from '@deepseek-ai/dsh-user-approval'
import WorkingDirectory from '@deepseek-ai/dsh-working-directory'
import LocalSubprocess from '@deepseek-ai/dsh-subprocess-local'
import NodePtcRuntime from '@deepseek-ai/dsh-ptc-runtime-node'
import * as PtcExecutor from '@deepseek-ai/dsh-tool-executor-ptc'
import { MultiRootSandboxProvider } from '../../../src/sandbox.ts'
import * as ProcessFence from '../../../src/process-fence.ts'
import { requireKernelRunner } from '../../support/kernel-runner.ts'
import * as ToolFs from '@deepseek-ai/dsh-tool-fs'
import { MultiRootFileSystem } from '../../../src/fs.ts'
import * as Instructions from '../../../src/instructions.ts'
import ReviewContextService from '../../../src/review-context.ts'
import { MultiRootOpsCompatibility } from '../../../src/ops-compatibility.ts'
import { mountRegistryStack } from '../../support/registry-stack.ts'
import { createFixtureWorkspace, REPO_ROOT } from '../../support/temp-workspace.ts'
import { installOpsSetting } from '../../support/ops-settings.ts'
import * as Companion from '../../../src/auto-review/current/fork.ts'

const cleanup: Array<() => Promise<void>> = []
afterEach(async () => { vi.restoreAllMocks(); while(cleanup.length) await cleanup.pop()!() })
function chunks(text = '{"risk":"low","decision":"allow"}'): StreamChunk[] {
  return [{type:'block-start',index:0,blockType:'text'}, {type:'text-delta',index:0,text}, {type:'block-end',index:0,block:{type:'text',text}}, {type:'finish',reason:{kind:'stop'}}]
}
class Adapter extends LlmAdapter {
  requests: GenerateOptions[] = []
  response = '{"risk":"low","decision":"allow"}'
  onRequest?: (request: GenerateOptions) => Promise<void>
  async *stream(options: GenerateOptions) { this.requests.push(options); await this.onRequest?.(options); yield* chunks(this.response) }
}
async function world(toolAccess: Record<string,'read-only'> = {}, instructionConfig: Instructions.Config = {}, ptc = false) {
  const f = createFixtureWorkspace('review')
  const ro = join(f.base,'readonly'); mkdirSync(ro)
  const stack = await mountRegistryStack(join(f.base,'store'), {}, {scopeConfig:{toolAccess}, beforeGate: async ctx => {
    await ctx.plugin(Sessions); await ctx.plugin(Projections); await ctx.plugin(SystemPrompt)
    await ctx.plugin(Policy,{mode:'danger-full-access',workspaceRoot:f.workspace})
    await ctx.plugin(MultiRootFileSystem,{cwd:f.workspace})
    if(ptc){
      // The widened Windows ACL argv names ./windows-runner.js beside the
      // provider module; only lib/ ships it (src/ carries windows-runner.ts),
      // so the real-runner mount reads the built provider — the choice
      // tests/windows-multi-root.spec.ts makes for its Windows-native cases.
      const provider=process.platform==='win32'
        ?(await import(pathToFileURL(join(REPO_ROOT,'lib','sandbox.js')).href) as typeof import('../../src/sandbox.ts')).MultiRootSandboxProvider
        :MultiRootSandboxProvider
      await ctx.plugin(provider,{})
    }
  }})
  cleanup.push(async () => { await stack.dispose(); f.dispose() })
  const ctx = stack.ctx
  // 0.2.2's permission-preset and approval services register projections on
  // `agents`; mount the registry (after SessionProjectionRegistry, which the
  // provider gate's stack already mounted) so those services can activate.
  await ctx.plugin(AgentRegistry)
  await ctx.plugin(WorkingDirectory)
  await ctx.plugin(Instructions, instructionConfig)
  await ctx.plugin(ReviewContextService)
  await ctx.plugin(Tools)
  // 0.2.2 selects dispatch through a mounted executor; earlier releases select
  // their mode through `dsh-tools` config. Probe the shape, not the release.
  const executorDispatch = typeof (ctx.tools as { setExecutor?: unknown }).setExecutor === 'function'
  if(executorDispatch){
    if(ptc){await ctx.plugin(LocalSubprocess);await ctx.plugin(NodePtcRuntime,{});await ctx.plugin(ProcessFence);await ctx.plugin(PtcExecutor,{})}
    else await installToolExecutor(ctx)
  } else if(ptc){await ctx.plugin(LocalSubprocess);await ctx.plugin(NodePtcRuntime,{});await ctx.plugin(ProcessFence)}
  await ctx.plugin(LlmRuntime)
  ctx.provide('shell', {sandboxMode:'danger-full-access'})
  await ctx.plugin(Approval,{policy:'never'})
  await ctx.plugin(Presets,{presets:{'danger-full-access':{sandbox:'danger-full-access',approval:'never'}}})
  await ctx.plugin(ToolFs,{})
  const adapter = new Adapter(); ctx.llm.registerAdapter(['review'],adapter)
  const auto = await ctx.plugin(Companion)
  expect(ctx.permissionPresets.names).toContain('auto')
  const session = ctx.sessions.create(SessionId('review-session'),{meta:{cwd:f.workspace}})
  ctx.permissionPresets.set(session,'auto')
  const agent = {id:session.id,session,ctx,options:{},inject() {}} as unknown as Agent
  await stack.registry.add(f.workspace,{path:f.outside,access:'inherit'})
  await stack.registry.add(f.workspace,{path:ro,access:'read-only'})
  let n = 0
  async function run(name: string, args: unknown, signal = new AbortController().signal) {
    const id = ToolCallId(`call-${++n}`)
    // Real published schemas, real Session identities, real tools scheduler.
    // A PTC executor exposes the reserved run_code transport only through its
    // own describe(), so the fixture states that schema; every other tool comes
    // from the registry.
    const definition = ctx.tools.schemas().find(x => x.name === name) ?? (name === 'run_code' ? {
      name: 'run_code',
      description: 'Execute a program whose nested calls go through the reviewed pipeline',
      parameters: { type: 'object', properties: { code: { type: 'string' }, description: { type: 'string' } }, required: ['code'] },
    } : undefined)
    if (definition === undefined) throw new Error(`no schema for ${name}`)
    const headerSchema = { name: definition.name, description: definition.description, parameters: definition.parameters }
    session.append('request/header',{header:{config:{provider:'review',model:'scripted'},tools:[headerSchema]},reason:n===1?'initial':'change'})
    session.append('step/start',{turn:n,step:1})
    session.append('assistant/message',{turn:n,step:1,stream:[],message:createMessage({role:'assistant',source:{kind:'model',provider:'review',model:'scripted'},content:[{type:'tool-call',id,name,arguments:JSON.stringify(args)}]})},{surfaceOp:'append'})
    session.append('tool/call',{turn:n,step:1,callId:id,name,arguments:JSON.stringify(args)})
    return await executeTool(ctx,{callId:id,name,args,agent,signal})
  }
  const build = (name='write',args: unknown={file_path:join(f.outside,'x.txt')}) => ctx.multiRootReviewContext.build({agent,name,arguments:args},new AbortController().signal)
  return {f,ro,ctx,stack,session,agent,adapter,auto,run,build}
}
/** Every review message is one text block; the 0.2.2 generation renders one per retained item. */
function texts(request: GenerateOptions): string[] {
  return request.messages.map(message => {
    const block = message.content[0]
    if (message.role !== 'user' || message.content.length !== 1 || block?.type !== 'text') throw new Error('review request message is not one user text block')
    return block.text
  })
}
function environment(request: GenerateOptions): Record<string, any> {
  const first = texts(request)[0]!
  if (!first.startsWith('ENVIRONMENT\n')) throw new Error('missing ENVIRONMENT')
  return JSON.parse(first.slice('ENVIRONMENT\n'.length))
}
function items(request: GenerateOptions): any[] { return texts(request).slice(1).map(text => JSON.parse(text)) }
function constraintsOf(request: GenerateOptions): any[] { return items(request).filter(entry => entry.kind === 'current-root-instructions') }
function historyOf(request: GenerateOptions): any[] { return items(request).filter(entry => entry.kind !== 'current-root-instructions' && entry.kind !== 'tool-schema') }
function pendingOf(request: GenerateOptions): any {
  const entries = items(request)
  const call = entries.at(-1)
  if (call?.kind !== 'tool-call') throw new Error('review request does not end with the pending call')
  return call
}

describe('current host review context and real tool fences', () => {
  it('sends trusted topology and current nested constraints as constraints, then fences scripted allow',async()=>{
    const w=await world({bash:'read-only'})
    mkdirSync(join(w.f.outside,'src','nested'),{recursive:true})
    writeFileSync(join(w.f.outside,'AGENTS.md'),'root rule: never deploy')
    writeFileSync(join(w.f.outside,'src','AGENTS.md'),'middle rule')
    writeFileSync(join(w.f.outside,'src','nested','CLAUDE.md'),'nested rule')
    w.session.append('user/message',createUserMessage({source:{kind:'user',rpcId:'human-1'},content:[{type:'text',text:'Edit the project'}]}),{surfaceOp:'append'})
    const target=join(w.f.outside,'src','nested','new.txt')
    expect((await w.run('write',{file_path:target,content:'allowed'})).isError).toBe(false)
    expect(readFileSync(target,'utf8')).toBe('allowed')
    expect(w.adapter.requests).toHaveLength(1)
    const request=w.adapter.requests[0]!
    const env=environment(request)
    expect(env).toMatchObject({sessionOrigin:w.f.workspace,effectiveCwd:w.f.workspace,sandboxMode:'danger-full-access',registryAuthority:'available',ambientWrites:true,readConfinement:false})
    expect(env.roots).toEqual([{path:w.f.outside,access:'inherit',effectiveWritable:true},{path:w.ro,access:'read-only',effectiveWritable:false}])
    const constraints=constraintsOf(request)
    expect(constraints).toHaveLength(3)
    expect(constraints.every((c:any)=>c.role==='constraint' && c.source.snapshot==='current')).toBe(true)
    expect(constraints.map((c:any)=>c.text)).toEqual(['root rule: never deploy','middle rule','nested rule'])
    expect(historyOf(request)[0].role).toBe('user-instruction')
    const denied=join(w.ro,'existing.txt');writeFileSync(denied,'unchanged')
    expect((await w.run('write',{file_path:denied,content:'bad'})).isError).toBe(true)
    expect(readFileSync(denied,'utf8')).toBe('unchanged')
    expect(w.adapter.requests).toHaveLength(2)
  })
  it('does not mark first-target discovery as success or consume delivery state',async()=>{
    const w=await world();mkdirSync(join(w.f.outside,'new'))
    const nested=join(w.f.outside,'new','AGENTS.md');writeFileSync(nested,'new-rule')
    expect((await w.build('write',{file_path:join(w.f.outside,'new','x')})).constraints.map(x=>x.path)).toContain(nested)
    expect((await w.build('bash',{})).constraints).toHaveLength(0)
    const decision=await w.ctx.waterfall('agent/pre-step',{agent:w.agent,messages:[],signal:new AbortController().signal},async()=>({kind:'enter',messages:[]}))
    expect(JSON.stringify(decision)).not.toContain('new-rule')
  })
  it('recollects the effective cwd instruction chain before demoting native constraints on a first bash call',async()=>{
    const w=await world()
    const middle=join(w.f.outside,'src'), cwd=join(middle,'nested')
    mkdirSync(cwd,{recursive:true})
    const files=[join(w.f.outside,'AGENTS.md'),join(middle,'AGENTS.md'),join(cwd,'AGENTS.md')]
    const texts=['root constraint','middle constraint','nested constraint: never deploy']
    files.forEach((file,index)=>writeFileSync(file,texts[index]!))
    await w.ctx.workingDirectory.set(w.agent,cwd)
    w.session.append('user/message',createUserMessage({source:{
      kind:'agent-instructions',baseline:true,baselineIdentity:JSON.stringify({projectRoot:w.f.outside}),
      changes:files.map((file,index)=>({action:'set' as const,path:file,digest:createHash('sha1').update(texts[index]!).digest('hex')})),
    },content:[{type:'text',text:texts.join('\n')}]}),{surfaceOp:'append'})
    let executed=0
    w.ctx.tools.register(defineContentToolFixture({name:'bash',description:'Record a reviewed bash dispatch',parameters:{command:{type:'string'}},async execute(){
      executed++;return [{type:'text',text:'done'}]
    }}))
    expect((await w.run('bash',{command:'echo reviewed'})).isError).toBe(false)
    expect(executed).toBe(1);expect(w.adapter.requests).toHaveLength(1)
    const request=w.adapter.requests[0]!
    const constraints=constraintsOf(request)
    expect(constraints.map((item:any)=>item.text)).toEqual(texts)
    expect(constraints.every((item:any)=>item.role==='constraint' && item.source.snapshot==='current')).toBe(true)
    expect(historyOf(request)[0]).toMatchObject({role:'fact'})
    expect(w.ctx.multiRootInstructions.knownRoots(w.session)).toEqual([])
    // Cwd discovery is review-local, not a successful file touch or delivery.
    await w.ctx.workingDirectory.set(w.agent,w.f.workspace)
    expect((await w.build('bash',{})).constraints.map(item=>item.path)).toEqual([files[0]])
    const decision=await w.ctx.waterfall('agent/pre-step',{agent:w.agent,messages:[],signal:new AbortController().signal},async()=>({kind:'enter',messages:[]}))
    expect(JSON.stringify(decision)).not.toContain(texts[2])
  })
  it('applies source budgets to the cwd chain before any review or dispatch',async()=>{
    const w=await world({}, {maxSourceBytes:8})
    const cwd=join(w.f.outside,'nested');mkdirSync(cwd)
    writeFileSync(join(cwd,'AGENTS.md'),'a nested constraint beyond the source budget')
    await w.ctx.workingDirectory.set(w.agent,cwd)
    const target=join(w.f.workspace,'never.txt')
    const result=await w.run('write',{file_path:target,content:'no'})
    expect(result.isError).toBe(true);expect(JSON.stringify(result)).toContain('source budget exceeded')
    expect(w.adapter.requests).toHaveLength(0);expect(()=>readFileSync(target)).toThrow()
  })
  it('keeps cwd discovery within current additional roots',async()=>{
    const w=await world()
    const cwd=join(w.f.base,'unregistered','nested');mkdirSync(cwd,{recursive:true})
    writeFileSync(join(cwd,'AGENTS.md'),'unregistered instruction')
    await w.ctx.workingDirectory.set(w.agent,cwd)
    expect((await w.build('bash',{})).constraints).toEqual([])
    const primaryNested=join(w.f.workspace,'nested');mkdirSync(primaryNested)
    writeFileSync(join(primaryNested,'AGENTS.md'),'primary instruction')
    await w.ctx.workingDirectory.set(w.agent,primaryNested)
    expect((await w.build('bash',{})).constraints).toEqual([])
  })
  it.skipIf(process.platform==='win32')('finds first-target instructions through a final file symlink without reading its contents',async()=>{
    const w=await world();mkdirSync(join(w.f.outside,'actual'))
    const file=join(w.f.outside,'actual','target');writeFileSync(file,'ordinary source must stay private')
    const instruction=join(w.f.outside,'actual','AGENTS.md');writeFileSync(instruction,'canonical nested rule')
    const link=join(w.f.workspace,'alias');symlinkSync(file,link)
    const context=await w.build('edit',{file_path:link})
    expect(context.constraints.map(item=>item.path)).toContain(instruction)
    expect(JSON.stringify(context)).not.toContain('ordinary source must stay private')
  })
  it('restores nested constraints from successful seed activity without changing delivery state',async()=>{
    const w=await world();mkdirSync(join(w.f.outside,'seed'))
    const instruction=join(w.f.outside,'seed','AGENTS.md');writeFileSync(instruction,'resumed constraint')
    const id=ToolCallId('seed-success')
    w.session.append('tool/call',{turn:0,step:0,callId:id,name:'read',arguments:JSON.stringify({file_path:join(w.f.outside,'seed','file')})})
    w.session.append('tool/result',{turn:0,step:0,message:createToolResultMessage({callId:id,isError:false,content:[{type:'text',text:'ok'}]})},{surfaceOp:'append'})
    const resumed=w.ctx.sessions.create(SessionId('resumed-review'),{meta:{cwd:w.f.workspace},seed:w.session.snapshotEvents()})
    const agent={...w.agent,id:resumed.id,session:resumed} as Agent
    const snapshot=await w.ctx.multiRootReviewContext.build({agent,name:'bash',arguments:{}},new AbortController().signal)
    expect(snapshot.constraints.map(item=>item.path)).toContain(instruction)
    expect(snapshot.constraints[0]?.text).toBe('resumed constraint')
  })
  it.each(['remove-root', 'missing-root', 'delete-file'] as const)('keeps withdrawn native provenance after pre-step: %s',async(change)=>{
    const w=await world()
    const path=join(w.f.outside,'AGENTS.md')
    const text='obsolete native constraint'
    writeFileSync(path,text)
    const native=createUserMessage({source:{
      kind:'agent-instructions',baseline:true,baselineIdentity:JSON.stringify({projectRoot:w.f.outside}),
      changes:[{action:'set',path,digest:createHash('sha1').update(text).digest('hex')}],
    },content:[{type:'text',text}]})
    w.session.append('user/message',native,{surfaceOp:'append'})
    const step=(messages: typeof native[]=[])=>w.ctx.waterfall('agent/pre-step',
      {agent:w.agent,messages:[],signal:new AbortController().signal},async()=>({kind:'enter',messages}))
    // Borrow the native copy through the real pre-step delivery path.
    await step([native])
    expect(w.ctx.multiRootInstructions.knownRoots(w.session)).toContain(w.f.outside)
    if(change==='remove-root'){
      const record=w.stack.registry.list(w.f.workspace).find(root=>root.path===w.f.outside)!
      await w.stack.registry.remove(w.f.workspace,{kind:'id',id:record.id})
    }else if(change==='missing-root') rmSync(w.f.outside,{recursive:true})
    else rmSync(path)
    await w.stack.registry.refresh(w.f.workspace)
    await step()
    await step() // A later steady-state step must not resurrect the old frame.
    expect(w.ctx.multiRootInstructions.knownRoots(w.session)).toContain(w.f.outside)
    const snapshot=await w.build('bash',{})
    expect(snapshot.constraints).toEqual([])
    if(change!=='delete-file') expect(snapshot.environment.roots.map(root=>root.path)).not.toContain(w.f.outside)
    expect((await w.run('write',{file_path:join(w.f.workspace,'reviewed.txt'),content:'ok'})).isError).toBe(false)
    const request=w.adapter.requests[0]!
    expect(constraintsOf(request)).toEqual([])
    expect(historyOf(request)).toContainEqual(expect.objectContaining({
      role:'fact',content:[{type:'text',text}],
    }))
  })
  it('sends every static OPS target chain through the actual reviewer before dispatch',async()=>{
    const w=await world()
    installOpsSetting(w.ctx,true)
    await w.ctx.plugin(MultiRootOpsCompatibility,{enabled:true})
    const denied=w.stack.registry.list(w.f.workspace).find(root=>root.path===w.ro)!
    await w.stack.registry.remove(w.f.workspace,{kind:'id',id:denied.id})
    const paths=['one','two'].map(dir=>{
      const directory=join(w.f.outside,dir);mkdirSync(directory)
      writeFileSync(join(directory,'AGENTS.md'),`OPS-${dir}-constraint`)
      const file=join(directory,'file.txt');writeFileSync(file,dir);return file
    })
    let bodies=0
    w.ctx.tools.register({name:'ops_read_files',description:'Read static OPS fixture targets',
      parameters:{type:'object',properties:{files:{type:'array',items:{type:'object',properties:{path:{type:'string'}}}}}},
      output:{schema:{type:'object',properties:{}},render:()=>'read'},
      execute:async()=>{bodies++;return {status:'completed'}},} as never)
    expect((await w.run('ops_read_files',{files:paths.map(path=>({path}))})).isError).toBe(false)
    expect(bodies).toBe(1);expect(w.adapter.requests).toHaveLength(1)
    const constraints=constraintsOf(w.adapter.requests[0]!)
    expect(constraints.map((item:any)=>item.text)).toEqual(['OPS-one-constraint','OPS-two-constraint'])
    expect(constraints.every((item:any)=>item.role==='constraint')).toBe(true)
  })
  it('fails the actual review before a model request or write when OPS history lacks evidence',async()=>{
    const w=await world()
    installOpsSetting(w.ctx,true)
    await w.ctx.plugin(MultiRootOpsCompatibility,{enabled:true})
    const id=ToolCallId('missing-ops-evidence')
    w.session.append('tool/call',{turn:0,step:0,callId:id,name:'ops_read_files',arguments:JSON.stringify({files:[{path:join(w.f.outside,'past.txt')}]})})
    w.session.append('tool/result',{turn:0,step:0,message:createToolResultMessage({callId:id,isError:false,content:[{type:'text',text:'no canonical receipt'}]})},{surfaceOp:'append'})
    const target=join(w.f.workspace,'never-written.txt')
    const result=await w.run('write',{file_path:target,content:'no'})
    expect(result.isError).toBe(true);expect(JSON.stringify(result)).toContain('OPS file activity lacks live evidence')
    expect(w.adapter.requests).toHaveLength(0);expect(()=>readFileSync(target)).toThrow()
  })
  it('fails an OPS call before the reviewer when its dynamic targets are unknowable',async()=>{
    const w=await world()
    installOpsSetting(w.ctx, true)
    await w.ctx.plugin(MultiRootOpsCompatibility, { enabled: true })
    const denied=w.stack.registry.list(w.f.workspace).find(root=>root.path===w.ro)!
    await w.stack.registry.remove(w.f.workspace,{kind:'id',id:denied.id})
    let bodies=0
    w.ctx.tools.register({name:'ops_replace',description:'spec ops_replace',parameters:{type:'object',properties:{}},
      output:{schema:{type:'object',properties:{}},render:()=>'ops_replace'},
      execute:async()=>{bodies+=1;return {status:'completed'}},} as never)
    const result=await w.run('ops_replace',{path:w.f.outside,pattern:'x',replacement:'y'})
    expect(bodies).toBe(0)
    expect(w.adapter.requests).toHaveLength(0)
    expect(result.isError).not.toBe(false)
    expect(JSON.stringify(result)).toContain('dynamic instruction targets')
  })
  it('re-reads updates, deletion and revocation, and ignores historical prose',async()=>{
    const w=await world();const path=join(w.f.outside,'AGENTS.md');writeFileSync(path,'old-rule')
    const before=await w.build();writeFileSync(path,'new-rule');expect((await w.build()).constraints[0]?.text).toBe('new-rule')
    await expect(w.ctx.multiRootReviewContext.assertCurrent({agent:w.agent,name:'write',arguments:{}},before,new AbortController().signal)).rejects.toThrow('changed')
    rmSync(path);expect((await w.build()).constraints).toHaveLength(0)
    writeFileSync(path,'another-rule');const records=w.stack.registry.list(w.f.workspace)
    await w.stack.registry.remove(w.f.workspace,{kind:'id',id:records[0]!.id})
    expect((await w.build()).constraints).toHaveLength(0)
  })
  it.each(['instruction','roots','cwd'] as const)('fails closed when %s changes while the reviewer waits',async(change)=>{
    const w=await world();const file=join(w.f.outside,'AGENTS.md');writeFileSync(file,'initial')
    w.adapter.onRequest=async()=>{
      if(change==='instruction')writeFileSync(file,'changed')
      if(change==='roots')await w.stack.registry.setAccess(w.f.workspace,{kind:'id',id:w.stack.registry.list(w.f.workspace)[0]!.id},'read-only')
      if(change==='cwd')await w.ctx.workingDirectory.set(w.agent,w.ro)
    }
    const path=join(w.f.outside,'never.txt')
    const result=await w.run('write',{file_path:path,content:'no'})
    expect(result.isError).toBe(true);expect(JSON.stringify(result)).toContain('snapshot changed')
    expect(()=>readFileSync(path)).toThrow()
  })
  it('fails on budget exhaustion, collector errors and cancellation without a review or body',async()=>{
    const w=await world({}, {maxBytes:100});writeFileSync(join(w.f.outside,'AGENTS.md'),'constraint'.repeat(100))
    expect((await w.run('write',{file_path:join(w.f.outside,'x'),content:'bad'})).isError).toBe(true)
    expect(w.adapter.requests).toHaveLength(0)
    rmSync(join(w.f.outside,'AGENTS.md'))
    vi.spyOn(w.ctx.multiRootInstructions,'snapshot').mockRejectedValueOnce(new Error('collector broke'))
    expect((await w.run('write',{file_path:join(w.f.outside,'x'),content:'bad'})).isError).toBe(true)
    const abort=new AbortController();abort.abort()
    expect((await w.run('write',{file_path:join(w.f.outside,'x'),content:'bad'},abort.signal)).isError).toBe(true)
    expect(w.adapter.requests).toHaveLength(0)
  })
  it('bounds streamed instruction reads and closes an over-budget stream without calling the reviewer',async()=>{
    const w=await world({}, {maxSourceBytes:8})
    writeFileSync(join(w.f.outside,'AGENTS.md'),'small')
    let closed=false
    vi.spyOn(w.ctx.fs,'streamText').mockResolvedValueOnce((async function*(){try{yield 'small';yield 'grown beyond the stat size'}finally{closed=true}})())
    const result=await w.run('write',{file_path:join(w.f.outside,'never'),content:'no'})
    expect(result.isError).toBe(true);expect(closed).toBe(true);expect(w.adapter.requests).toHaveLength(0)
  })
  it('retains unavailable authority and redirect restrictions without stale constraints',async()=>{
    const w=await world();writeFileSync(join(w.f.outside,'AGENTS.md'),'stale')
    const displaced=`${w.f.outside}-old`;renameSync(w.f.outside,displaced);symlinkSync(w.ro,w.f.outside,process.platform==='win32'?'junction':'dir')
    const redirected=await w.build();expect(redirected.constraints).toHaveLength(0)
    expect(redirected.environment.roots.some(x=>x.path===w.f.outside)).toBe(false)
    w.ctx.multiRootScope.setRegistryAuthority(false)
    vi.spyOn(w.stack.registry,'refresh').mockResolvedValue([])
    const absent=await w.build();expect(absent.environment.registryAuthority).toBe('unavailable');expect(absent.environment.writeBoundary).toContain('primary-root-only');expect(absent.constraints).toHaveLength(0)
  })
  it('matches read-only preview to actual nested execution and isolates concurrent caps',async()=>{
    const w=await world({bash:'read-only'})
    const policy=w.ctx.sandboxPolicy.resolve({session:w.session})
    // The 'bash' cap sees nothing writable; 'write' keeps the extra root.
    expect(w.ctx.multiRootScope.previewForTool(policy,'bash').writableRoots).toEqual([])
    expect(w.ctx.multiRootScope.previewForTool(policy,'write').writableRoots).toContain(w.f.outside)
    const dispatch=(name:string,fn:()=>Promise<any>)=> (w.ctx.waterfall as any)('tools/execute',{name,callId:name,token:{}},fn)
    await Promise.all([dispatch('bash',async()=>{
      expect((await w.build()).environment.writableRoots).toEqual([])
      // The waterfall hook itself is ambient — the tool's real execution runs
      // inside registry admission, which is where the scope it obeys lives.
      await dispatch('write',async()=>await w.stack.registry.withOperation(policy,'fs-write',async()=>{
        expect(w.ctx.multiRootScope.resolve(policy)).toEqual(w.ctx.multiRootScope.previewForTool(policy,'write'))
      }))
    }),dispatch('write',async()=>{expect((await w.build()).environment.writableRoots).toContain(w.f.outside)})])
  })
  it('reviews real PTC inner fs calls once and retains the outer run_code tool cap',async(test)=>{
    const w=await world({}, {}, true)
    const target=join(w.f.outside,'ptc.txt')
    const result=await w.run('run_code',{code:`return await tools.write(${JSON.stringify({file_path:target,content:'ptc-ok'})});`,description:'Write one fixture'})
    if(result.isError && /sandbox|SANDBOX|Operation not permitted/.test(JSON.stringify(result)) && w.adapter.requests.length===0){
      test.skip(requireKernelRunner(process.platform==='darwin'?'seatbelt':process.platform==='win32'?'windows-acl':'bwrap',JSON.stringify(result)));return
    }
    expect(result.isError,JSON.stringify(result)).toBe(false)
    expect(readFileSync(target,'utf8')).toBe('ptc-ok');expect(w.adapter.requests).toHaveLength(1)
    expect(pendingOf(w.adapter.requests[0]!).mode).toBe('ptc-inner')
    writeFileSync(join(w.ro,'ptc-keep'),'keep')
    await w.run('run_code',{code:`return await tools.write(${JSON.stringify({file_path:join(w.ro,'ptc-keep'),content:'no'})});`,description:'Try a readonly root'})
    expect(readFileSync(join(w.ro,'ptc-keep'),'utf8')).toBe('keep');expect(w.adapter.requests).toHaveLength(2)
    const direct=await w.run('run_code',{code:`await (await import('node:fs/promises')).writeFile(${JSON.stringify(join(w.ro,'ptc-keep'))},'kernel bypass');`,description:'Direct process write must remain fenced'})
    expect(direct.isError,JSON.stringify(direct)).toBe(true)
    expect(readFileSync(join(w.ro,'ptc-keep'),'utf8')).toBe('keep')
    expect(w.adapter.requests).toHaveLength(2)
    const capped=await world({run_code:'read-only'}, {}, true)
    const refused=join(capped.f.outside,'capped-ptc.txt')
    await capped.run('run_code',{code:`return await tools.write(${JSON.stringify({file_path:refused,content:'no'})});`,description:'Capped inner write'})
    expect(()=>readFileSync(refused)).toThrow()
    expect(capped.adapter.requests).toHaveLength(1)
    expect(environment(capped.adapter.requests[0]!).writableRoots).toEqual([])
  })
  it('rechecks after human approval and does not let approval bypass a read-only fence',async()=>{
    const w=await world();setApprovalPolicy(w.session,'ask')
    w.adapter.response='{"risk":"medium","decision":"deny"}'
    w.ctx.on('approval/request',async()=> 'approved')
    const path=join(w.ro,'human.txt');writeFileSync(path,'keep')
    expect((await w.run('write',{file_path:path,content:'bad'})).isError).toBe(true)
    expect(readFileSync(path,'utf8')).toBe('keep')
  })
  it('fails stale snapshots after approval and after downstream gates',async()=>{
    const w=await world();setApprovalPolicy(w.session,'ask')
    const instruction=join(w.f.outside,'AGENTS.md');writeFileSync(instruction,'before')
    w.adapter.response='{"risk":"medium","decision":"deny"}'
    w.ctx.on('approval/request',async()=>{writeFileSync(instruction,'after');return 'approved'})
    const path=join(w.f.outside,'approved.txt')
    expect((await w.run('write',{file_path:path,content:'bad'})).isError).toBe(true)
    expect(()=>readFileSync(path)).toThrow()
    w.adapter.response='{"risk":"low","decision":"allow"}'
    w.ctx.on('tools/pre-execute',async(_exec,next)=>{const result=await next();writeFileSync(instruction,'last-minute');return result})
    expect((await w.run('write',{file_path:path,content:'bad'})).isError).toBe(true)
  })
  it('includes effective cwd without changing the origin or adding an ambient membership grant',async()=>{
    const w=await world();await w.ctx.workingDirectory.set(w.agent,w.ro)
    const context=await w.build('write',{file_path:'relative.txt'})
    expect(context.environment.sessionOrigin).toBe(w.f.workspace)
    expect(context.environment.effectiveCwd).toBe(w.ro)
    expect(context.environment.roots.find(x=>x.path===w.ro)?.effectiveWritable).toBe(false)
    expect((await w.run('write',{file_path:'relative.txt',content:'no'})).isError).toBe(true)
  })
  it('unloads Auto to Full access without removing write fences, and reinstalls one owner',async()=>{
    const w=await world();await w.auto.dispose()
    expect(w.ctx.permissionPresets.current(w.session)).toBe('danger-full-access')
    expect(w.ctx.permissionPresets.names).not.toContain('auto')
    expect(w.ctx.get('fs')).toBeDefined();expect(w.ctx.get('sandbox')).toBeDefined()
    await expect(w.ctx.fs.writeText(await w.ctx.fs.resolve(join(w.ro,'x')),'bad',undefined,undefined,w.ctx.sandboxPolicy.resolve({session:w.session}))).rejects.toMatchObject({code:'FS_SANDBOX_DENIED'})
    await w.ctx.plugin(Companion);expect(w.ctx.permissionPresets.names.filter(x=>x==='auto')).toHaveLength(1)
  })
})
