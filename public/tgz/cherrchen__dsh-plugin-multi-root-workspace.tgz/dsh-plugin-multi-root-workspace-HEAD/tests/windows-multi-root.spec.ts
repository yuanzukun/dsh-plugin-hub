import { copyFileSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import { tmpdir } from 'node:os'
import { basename, dirname, join, resolve as resolvePath } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { Context } from '@deepseek-ai/cordis'
import { canonicalPath } from '@deepseek-ai/dsh-sandbox'
import type { SandboxPolicy } from '@deepseek-ai/dsh-sandbox'
import { LocalSandboxProvider } from '@deepseek-ai/dsh-sandbox-local'
import SandboxPolicyService from '@deepseek-ai/dsh-sandbox-policy'
import SessionProjectionRegistry from '@deepseek-ai/dsh-session-projection'
import LocalSubprocess from '@deepseek-ai/dsh-subprocess-local'
import { afterEach, describe, expect, it } from 'vitest'
import { MultiRootSandboxProvider } from '../src/sandbox.ts'
import { MultiRootScopeService } from '../src/scope.ts'
import { parseWindowsProfile, restrictWindowsProfile, workspaceScopeSid, widenWindowsProfile } from '../src/windows-profile.ts'
import { rootDenySid } from '../src/windows-runner-contract.ts'
import { mountCompat } from './support/compat.ts'
import { confined } from './support/confine.ts'
import { createFixtureWorkspace, REPO_ROOT } from './support/temp-workspace.ts'

// The upstream runner slot must be an absolute existing file: the standalone
// runner resolves the upstream ACL package by self-reference FROM it.
const upstreamRunner = fileURLToPath(import.meta.url)
const profile = ['node', upstreamRunner, '--workspace', 'C:\\primary', '--temp', 'C:\\temp', '--mode', 'workspace-write']
describe('Windows root-set capability', () => {
  it('uses a separate stable per-root deny identity', () => {
    expect(rootDenySid('D:\\extra')).toBe(rootDenySid('d:\\EXTRA'))
    expect(rootDenySid('D:\\extra')).not.toBe(rootDenySid('D:\\other'))
    expect(rootDenySid('D:\\extra')).not.toBe(workspaceScopeSid(['D:\\extra']))
  })
  it('strictly separates ambient deny profiles from grant profiles', () => {
    const args = restrictWindowsProfile(profile, ['D:\\ro space', 'E:\\ro'])
    const parsed = parseWindowsProfile(args.slice(2), true)
    expect(parsed.mode).toBe('danger-full-access')
    expect(parsed.deniedRoots).toEqual(['D:\\ro space', 'E:\\ro'])
    expect(parsed.additionalRoots).toEqual([])
    expect(() => parseWindowsProfile(args.slice(2))).toThrow()
    expect(() => restrictWindowsProfile(profile, [])).toThrow()
    expect(() => restrictWindowsProfile(profile, ['\\\\server\\share'])).toThrow('network or device')
    expect(() => parseWindowsProfile([...args.slice(2), '--additional-root', 'D:\\extra'], true)).toThrow('deny roots only')
    expect(() => parseWindowsProfile([...args.slice(2), '--write-sid', 'sid', '--temp-write-sid', 'sid2'], true)).toThrow('deny roots only')
    expect(() => parseWindowsProfile(['--upstream-runner', upstreamRunner, ...profile.slice(2), '--deny-root', 'D:\\ro'], true)).toThrow('deny roots only')
  })
  it('labels the protected home for runner diagnostics only, never changing the deny set', () => {
    const denied = ['D:\\ro space', 'E:\\ro']
    const withHome = restrictWindowsProfile(profile, denied, 'E:\\ro')
    const parsed = parseWindowsProfile(withHome.slice(2), true)
    expect(parsed.protectedHome).toBe('E:\\ro')
    expect(parsed.deniedRoots).toEqual(denied)
    // The label is case-insensitive and a non-member label is dropped rather
    // than shipped to the runner — it carries no authority of its own.
    expect(parseWindowsProfile(restrictWindowsProfile(profile, denied, 'e:\\RO').slice(2), true).protectedHome).toBe('e:\\RO')
    expect(restrictWindowsProfile(profile, denied, 'D:\\nope')).not.toContain('--protected-home')
    expect(restrictWindowsProfile(profile, denied)).not.toContain('--protected-home')
    // The upstream contract must not know the flag at all.
    expect(() => parseWindowsProfile(withHome.slice(2))).toThrow(/unknown or duplicate/)
    // Duplicates, non-absolute values, non-members, and the wrong mode all fail.
    const bare = restrictWindowsProfile(profile, denied).slice(2)
    expect(() => parseWindowsProfile([...withHome.slice(2), '--protected-home', 'E:\\ro'], true)).toThrow(/repeats --protected-home/)
    expect(() => parseWindowsProfile([...bare, '--protected-home', 'D:\\nope'], true)).toThrow(/absolute member/)
    expect(() => parseWindowsProfile([...bare, '--protected-home', 'relative\\path'], true)).toThrow(/absolute member/)
    const writeProfile = ['--upstream-runner', upstreamRunner, ...profile.slice(2), '--protected-home', 'E:\\ro']
    expect(() => parseWindowsProfile(writeProfile, true)).toThrow(/danger-full-access/)
  })
  it('is stable across ordering and casing, and changes on revocation', () => {
    const sid = workspaceScopeSid(['C:\\primary', 'D:\\extra'])
    expect(sid).toBe(workspaceScopeSid(['d:\\EXTRA', 'c:\\PRIMARY', 'C:\\primary']))
    expect(sid).not.toBe(workspaceScopeSid(['C:\\primary']))
    expect(sid).not.toBe(workspaceScopeSid(['D:\\extra']))
    expect(sid).toMatch(/^S-1-4-(\d+-){4}2$/)
  })
  it('preserves argv boundaries for paths with spaces, quotes, and -- tokens', () => {
    const roots = ['D:\\repo space', 'D:\\quote"repo', '--mode']
    const widened = widenWindowsProfile(profile, roots, [])
    expect(widened.slice(2, 4)).toEqual(['--upstream-runner', upstreamRunner])
    expect(widened.slice(4, profile.length + 2)).toEqual(profile.slice(2))
    expect(parseWindowsProfile(widened.slice(2), true).additionalRoots).toEqual(roots)
  })
  it('refuses to widen a profile onto a network or device path', () => {
    // Any root that is a UNC or device path fails closed: the provider turns
    // this DialectUnrecognizedError into SandboxUnavailableError, never a
    // silently unconfined or primary-only spawn.
    const uncWorkspace = ['node', 'runner.js', '--workspace', '\\\\server\\share', '--temp', 'C:\\temp', '--mode', 'workspace-write']
    for (const args of [uncWorkspace, profile]) {
      const roots = args === profile ? ['\\\\server\\share\\x'] : ['D:\\extra']
      expect(() => widenWindowsProfile(args, roots, [])).toThrow('network or device paths')
    }
    expect(() => widenWindowsProfile(profile, ['D:\\fine', '//server/share'], [])).toThrow('network or device paths')
  })
  it('fails closed on unknown, duplicated, missing, or unpaired flags', () => {
    for (const flags of [profile.slice(2).concat('--future', 'yes'), profile.slice(2).concat('--temp', 'x'), profile.slice(2).concat('--write-sid', 'sid'), profile.slice(2, -1)]) {
      expect(() => parseWindowsProfile(flags)).toThrow()
    }
    expect(() => widenWindowsProfile(profile, ['D:\\extra'], [], 'C:\\different')).toThrow('does not match')
  })
  it('fails closed when a denied root sits inside a granted directory (B9)', () => {
    // The restricted-token model cannot subtract: an explicit read-only root
    // under the workspace or the private temp stays writable through the
    // parent's ACE, so the profile refuses rather than confine too wide.
    expect(() => widenWindowsProfile(profile, [], ['C:\\primary\\ro'])).toThrow('cannot deny')
    expect(() => widenWindowsProfile(profile, [], ['C:\\temp\\ro'])).toThrow('cannot deny')
    expect(() => widenWindowsProfile(profile, ['D:\\extra'], ['D:\\extra\\ro'])).toThrow('cannot deny')
    // A denied root outside every grant is denied by the mode already.
    expect(() => widenWindowsProfile(profile, [], ['D:\\elsewhere\\ro'])).not.toThrow()
  })
  it('recognizes --upstream-runner only in the runner mode, exactly once, as an absolute file', () => {
    const runnerFlags = ['--upstream-runner', upstreamRunner, ...profile.slice(2)]
    expect(parseWindowsProfile(runnerFlags, true).upstreamRunner).toBe(upstreamRunner)
    // The upstream contract (allowAdditional off) must not know the flag at all.
    expect(() => parseWindowsProfile(runnerFlags)).toThrow(/unknown or duplicate/)
    // Required in the runner mode, accepted exactly once, and only when it
    // names an absolute existing file — anything else fails closed.
    expect(() => parseWindowsProfile(profile.slice(2), true)).toThrow(/--upstream-runner/)
    expect(() => parseWindowsProfile([...runnerFlags, '--upstream-runner', upstreamRunner], true)).toThrow(/repeats --upstream-runner/)
    expect(() => parseWindowsProfile(['--upstream-runner', 'runner.js', ...profile.slice(2)], true)).toThrow(/absolute existing file/)
    expect(() => parseWindowsProfile(['--upstream-runner', join(REPO_ROOT, 'lib', 'nonexistent-runner.js'), ...profile.slice(2)], true)).toThrow(/absolute existing file/)
  })
  it('ships a standalone runner and fails closed when invoked on a different OS', () => {
    const runner = join(REPO_ROOT, 'lib/windows-runner.js')
    expect(existsSync(runner)).toBe(true)
    if (process.platform === 'win32') return
    const result = spawnSync(process.execPath, [runner], { encoding: 'utf8' })
    expect(result.status).toBe(127)
    expect(result.stderr).toContain('windows-acl-run: Windows ACL runner requires Windows')
  })
  it('ships a runner whose module graph imports node builtins only, and boots from a bare directory', () => {
    // lib/windows-runner.js runs as a separate Node process outside the host's
    // plugin package resolution: a bare specifier in its static graph dies
    // with ERR_MODULE_NOT_FOUND before main() can fail closed (the defect this
    // test exists to keep dead).
    const runner = join(REPO_ROOT, 'lib/windows-runner.js')
    expect(existsSync(runner)).toBe(true)
    const specifierPattern = /(?:import|export)[^'"]*?\bfrom\s*['"]([^'"]+)['"]|import\s*['"]([^'"]+)['"]|import\(\s*['"]([^'"]+)['"]\s*\)/g
    const visited = new Set<string>()
    const queue = [runner]
    while (queue.length > 0) {
      const file = queue.pop()!
      if (visited.has(file)) continue
      visited.add(file)
      for (const match of readFileSync(file, 'utf8').matchAll(specifierPattern)) {
        const specifier = (match[1] ?? match[2] ?? match[3])!
        if (!specifier.startsWith('.')) {
          expect(specifier, `${file} imports a bare specifier`).toMatch(/^node:/)
          continue
        }
        const base = resolvePath(dirname(file), specifier)
        for (const candidate of [base, `${base}.js`]) {
          if (existsSync(candidate)) { queue.push(candidate); break }
        }
      }
    }
    // The same graph must run copied into a directory with NO node_modules on
    // any path upward — where the installed tarball's runner actually lives.
    const dir = mkdtempSync(join(tmpdir(), 'windows-runner-bare-'))
    try {
      for (const file of visited) copyFileSync(file, join(dir, basename(file)))
      const result = spawnSync(process.execPath, [join(dir, basename(runner))], { encoding: 'utf8' })
      expect(result.status).toBe(127)
      expect(result.stderr).toContain('windows-acl-run:')
      expect(result.stderr).not.toContain('ERR_MODULE_NOT_FOUND')
      if (process.platform !== 'win32') expect(result.stderr).toContain('Windows ACL runner requires Windows')
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })
})

it.runIf(process.platform === 'win32')('enforces real Windows writes in both roots and denies a sibling and a removed root', async () => {
  const fixture = createFixtureWorkspace('windows-kernel')
  const third = join(fixture.base, 'third'); mkdirSync(third)
  const ctx = new Context()
  try {
    // Execute the shipped provider: its import.meta.url must locate the built
    // standalone runner, not a nonexistent src/windows-runner.js under Vitest.
    const { MultiRootSandboxProvider } = await import(pathToFileURL(join(REPO_ROOT, 'lib/sandbox.js')).href) as typeof import('../src/sandbox.ts')
    // Select the real public Windows ACL runner; no permissive runner fallback.
    ctx.provide('sandboxPolicy', {} as never)
    await ctx.plugin(MultiRootScopeService)
    await mountCompat(ctx)
    await ctx.plugin(MultiRootSandboxProvider)
    const provider = ctx.sandbox as MultiRootSandboxProvider
    provider.internals = { chain: ['windows-acl'], windowsAclRunnerArgs: [process.execPath, fileURLToPath(import.meta.resolve('@deepseek-ai/dsh-sandbox-windows-acl/runner'))] }
    ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [{ id: 'extra', path: fixture.outside, recordedPath: canonicalPath(fixture.outside), access: 'inherit' }])
    const policy = { mode: 'workspace-write' as const, workspaceRoot: canonicalPath(fixture.workspace) }
    const execute = async (provider: LocalSandboxProvider, roots: string[]) => {
      const payload = `const fs=require('fs'); const roots=${JSON.stringify(roots)}; for(const root of roots){try {fs.writeFileSync(root+'/probe.txt','ok');console.log('allowed')}catch(e){console.log('denied:'+e.code)}}`
      const confined = await provider.confine([process.execPath, '-e', payload], policy)
      if (ctx.multiRootScope.scopeOf(fixture.workspace).length > 0) {
        expect(confined.argv[1]).toBe(join(REPO_ROOT, 'lib/windows-runner.js'))
      }
      return spawnSync(confined.argv[0]!, confined.argv.slice(1), { encoding: 'utf8', timeout: 60000 })
    }
    const result = await execute(ctx.sandbox as MultiRootSandboxProvider, [fixture.workspace, fixture.outside, third])
    expect(result.error).toBeUndefined(); expect(result.status, result.stderr).toBe(0)
    expect(result.stdout.trim().split(/\r?\n/)).toEqual(['allowed', 'allowed', expect.stringMatching(/^denied:/)])
    expect(readFileSync(join(fixture.outside, 'probe.txt'), 'utf8')).toBe('ok')
    const psPath = join(fixture.outside, 'powershell.txt').replace(/'/g, "''")
    const psArgv = ['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', `[System.IO.File]::WriteAllText('${psPath}', 'powershell')`]
    const ps = await ctx.sandbox.confine(psArgv, policy)
    const psResult = spawnSync(ps.argv[0]!, ps.argv.slice(1), { encoding: 'utf8', timeout: 60000 })
    expect(psResult.status, psResult.stderr).toBe(0)
    expect(readFileSync(join(fixture.outside, 'powershell.txt'), 'utf8')).toBe('powershell')
    // Exercise the real ConPTY transport with the same confined argv seam.
    await ctx.plugin(LocalSubprocess)
    const psLiteral = (path: string) => path.replace(/'/g, "''")
    const ptyCommand = `[System.IO.File]::WriteAllText('${psLiteral(join(fixture.workspace, 'pty.txt'))}', 'primary'); [System.IO.File]::WriteAllText('${psLiteral(join(fixture.outside, 'pty.txt'))}', 'extra'); try { [System.IO.File]::WriteAllText('${psLiteral(join(third, 'pty.txt'))}', 'bad'); exit 11 } catch { [System.IO.File]::WriteAllText('${psLiteral(join(fixture.outside, 'pty-denied.txt'))}', 'denied') }; exit 23`
    const ptyArgv = await ctx.sandbox.confine(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', ptyCommand], policy)
    const ptySpec = { argv: ptyArgv.argv, cwd: fixture.workspace, rows: 24, cols: 100, terminalType: 'xterm-256color', graceMs: 500 }
    const terminal = await ctx.subprocess.spawnTerminal(ptySpec)
    terminal.output.resume()
    let ptyTimeout: ReturnType<typeof setTimeout> | undefined
    try {
      const outcome = await Promise.race([terminal.done, new Promise<never>((_, reject) => {
        ptyTimeout = setTimeout(() => { reject(new Error('Windows restricted PTY timed out')) }, 60000)
      })])
      // ConPTY occasionally settles without delivering an exit code on hosted
      // runners; the file verdicts below carry the authoritative enforcement
      // check, so only assert the code when the transport actually gave one.
      if (typeof outcome.exitCode === 'number') expect(outcome.exitCode).toBe(23)
      expect(readFileSync(join(fixture.workspace, 'pty.txt'), 'utf8')).toBe('primary')
      expect(readFileSync(join(fixture.outside, 'pty.txt'), 'utf8')).toBe('extra')
      expect(readFileSync(join(fixture.outside, 'pty-denied.txt'), 'utf8')).toBe('denied')
      expect(existsSync(join(third, 'pty.txt'))).toBe(false)
    } finally {
      clearTimeout(ptyTimeout)
      await terminal.terminate()
    }
    const readOnly = await ctx.sandbox.confine([process.execPath, '-e', `try { require('fs').writeFileSync(${JSON.stringify(join(fixture.outside, 'readonly.txt'))}, 'bad'); process.exit(1) } catch { console.log('denied') }`], { ...policy, mode: 'read-only' })
    const readOnlyResult = spawnSync(readOnly.argv[0]!, readOnly.argv.slice(1), { encoding: 'utf8', timeout: 60000 })
    expect(readOnlyResult.status, readOnlyResult.stderr).toBe(0)
    expect(readOnlyResult.stdout.trim()).toBe('denied')
    ctx.multiRootScope.setAdditionalRoots(fixture.workspace, [])
    // Empty scope delegates to upstream; its SID cannot use the old scope ACEs.
    const denied = await execute(ctx.sandbox as MultiRootSandboxProvider, [fixture.outside])
    expect(denied.status, denied.stderr).toBe(0); expect(denied.stdout).toMatch(/^denied:/)
  } finally { await ctx.fiber.dispose(); fixture.dispose() }
}, 180000)

describe('writable-only roots in the Windows ACL profile', () => {
  const fibers: Array<Awaited<ReturnType<Context['plugin']>>> = []
  afterEach(async () => {
    while (fibers.length > 0) await fibers.pop()?.dispose()
  })

  const COMMAND = ['cmd.exe', '/c', 'echo hi']

  /**
   * Confine once through the real provider with the windows-acl runner forced
   * (no Win32 calls on a POSIX host): the answer is the argv shape plus the
   * scope SID the runner would compute from the flags it received.
   */
  async function confineWindows(
    fixture: ReturnType<typeof createFixtureWorkspace>,
    members: readonly { path: string; access: 'inherit' | 'read-only' | 'read-write' }[],
  ): Promise<{ argv: readonly string[]; sid: string }> {
    const ctx = new Context()
    fibers.push(
      await ctx.plugin(SessionProjectionRegistry),
      await ctx.plugin(SandboxPolicyService, { mode: 'workspace-write', workspaceRoot: fixture.workspace }),
      await ctx.plugin(MultiRootScopeService),
    )
    await mountCompat(ctx)
    fibers.push(await ctx.plugin(MultiRootSandboxProvider, {}))
    const provider = ctx.sandbox as LocalSandboxProvider
    provider.internals = { chain: ['windows-acl'], windowsAclRunnerArgs: ['node', '/fake/runner.js'] }
    ctx.multiRootScope.setAdditionalRoots(fixture.workspace, members.map((member, index) => ({
      id: `root-${index}`,
      path: member.path,
      recordedPath: canonicalPath(member.path),
      access: member.access,
    })))
    const policy: SandboxPolicy = { mode: 'workspace-write', workspaceRoot: fixture.workspace }
    const result = await confined(provider, COMMAND, policy)
    // The runner derives the scope SID from the flags it is invoked with, so
    // reading them back is the same derivation — independent of the widening.
    // (Parsed by hand rather than parseWindowsProfile: on a POSIX host the
    // src-relative `./windows-runner.js` path the widening emits does not
    // exist yet, and the strict runner-mode parse would fail on that alone.)
    const workspace = flagValues(result.argv, '--workspace')[0]!
    const additionalRoots = flagValues(result.argv, '--additional-root')
    return { argv: result.argv, sid: workspaceScopeSid([workspace, ...additionalRoots]) }
  }

  /** Every value that follows one flag spelling in the argv. */
  function flagValues(argv: readonly string[], flag: string): string[] {
    const values: string[] = []
    for (const [index, part] of argv.entries()) {
      if (part === flag && argv[index + 1] !== undefined) values.push(argv[index + 1]!)
    }
    return values
  }

  it('grants only the writable members: A read-write + B read-only', async () => {
    const fixture = createFixtureWorkspace('windows-access')
    try {
      const extra = `${fixture.base}/A`; mkdirSync(extra)
      const restricted = `${fixture.base}/B`; mkdirSync(restricted)
      const { argv, sid } = await confineWindows(fixture, [
        { path: extra, access: 'read-write' },
        { path: restricted, access: 'read-only' },
      ])
      expect(argv).toContain('--additional-root')
      expect(argv).toContain(canonicalPath(extra))
      expect(argv).not.toContain(canonicalPath(restricted))
      expect(sid).toBe(workspaceScopeSid([canonicalPath(fixture.workspace), canonicalPath(extra)]))
    } finally { fixture.dispose() }
  })

  it('degenerates to the upstream passthrough when every member is read-only', async () => {
    const fixture = createFixtureWorkspace('windows-access')
    try {
      const restricted = `${fixture.base}/B`; mkdirSync(restricted)
      const { argv, sid } = await confineWindows(fixture, [{ path: restricted, access: 'read-only' }])
      // No widening at all: the upstream runner argv returns element for
      // element, so no --additional-root flag and no plugin runner.
      expect(argv).not.toContain('--additional-root')
      expect(argv[1]).not.toMatch(/windows-runner\.js$/)
      expect(sid).toBe(workspaceScopeSid([canonicalPath(fixture.workspace)]))
    } finally { fixture.dispose() }
  })

  it('widens the SID when a member becomes writable', async () => {
    const fixture = createFixtureWorkspace('windows-access')
    try {
      const extra = `${fixture.base}/A`; mkdirSync(extra)
      const restricted = `${fixture.base}/B`; mkdirSync(restricted)
      const { sid } = await confineWindows(fixture, [
        { path: extra, access: 'read-write' },
        { path: restricted, access: 'read-write' },
      ])
      expect(sid).toBe(workspaceScopeSid([
        canonicalPath(fixture.workspace),
        canonicalPath(extra),
        canonicalPath(restricted),
      ]))
    } finally { fixture.dispose() }
  })
})
