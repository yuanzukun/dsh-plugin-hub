/**
 * The root validation rules, exercised directly.
 *
 * These are the rules every write AND every startup re-read passes through, so
 * each one is pinned on its own: the code an operator sees, the canonical
 * spelling that gets stored, and the two "this grants nothing new" cases that
 * M3 rejects on purpose (equal to the primary root, nested either way).
 */

import { mkdirSync, symlinkSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join, sep } from 'node:path'
import { afterAll, beforeAll, describe, expect, it } from 'vitest'
import { canonicalPath } from '@deepseek-ai/dsh-sandbox'
import {
  additionalRootId,
  availableRoots,
  canonicalRoot,
  classifyStoredRoots,
  expandRootInput,
  indexedStatuses,
  isCanonicallyUnder,
  isWindowsNetworkOrDevicePath,
  markProtectedPaths,
  primaryKey,
  removeStatusAt,
  reservedRootBoundary,
  entryRootRef,
  resolveRootRef,
  RootValidationError,
  validateRootCandidate,
  type ProtectedPath,
  type RegisteredRoot,
} from '../src/roots.ts'
import { createFixtureWorkspace, symlinkUnsupportedReason, type FixtureWorkspace } from './support/temp-workspace.ts'

let fixture: FixtureWorkspace
let primary: string
let sibling: string
let nested: string
let other: string
let alias: string
/** Why the symlink cases cannot run here, when the host refuses directory links. */
let symlinkReason: string | undefined

beforeAll(() => {
  fixture = createFixtureWorkspace('roots')
  primary = canonicalPath(fixture.workspace)
  sibling = join(fixture.base, 'extra')
  nested = join(sibling, 'inner')
  other = join(fixture.base, 'other')
  alias = join(fixture.base, 'alias')
  mkdirSync(sibling)
  mkdirSync(nested)
  mkdirSync(other)
  writeFileSync(join(fixture.base, 'a-file'), 'not a directory')
  // Windows refuses a directory symlink without Developer Mode or elevation: the
  // alias cases then skip with the reason instead of failing for a privilege this
  // suite cannot grant itself.
  symlinkReason = symlinkUnsupportedReason()
  if (symlinkReason === undefined) symlinkSync(sibling, alias)
})

afterAll(() => { fixture.dispose() })

/** Run one candidate against the primary root and the given existing roots. */
function check(raw: string, existing: readonly string[] = [], home?: string): string {
  return home === undefined
    ? validateRootCandidate(raw, { primaryRoot: primary, existing })
    : validateRootCandidate(raw, { primaryRoot: primary, existing, home })
}

/** Capture the failure code of one candidate. */
function codeOf(raw: string, existing: readonly string[] = [], home?: string): string {
  try {
    check(raw, existing, home)
  } catch (error: unknown) {
    if (error instanceof RootValidationError) return error.code
    throw error
  }
  return 'accepted'
}

describe('expandRootInput', () => {
  it('expands a bare tilde and a tilde-prefixed path against the given home', () => {
    const home = join(sep, 'home', 'op')
    expect(expandRootInput('~', home)).toBe(home)
    expect(expandRootInput('~/projects', home)).toBe(join(home, 'projects'))
  })

  it('leaves every other spelling untouched, so validation can reject it', () => {
    expect(expandRootInput('  relative/dir  ')).toBe('relative/dir')
    expect(expandRootInput('./here')).toBe('./here')
    expect(expandRootInput('~other/dir')).toBe('~other/dir')
  })

  it('defaults to the process home directory', () => {
    expect(expandRootInput('~')).toBe(homedir())
  })
})

describe('isCanonicallyUnder', () => {
  it('accepts the root itself and its descendants, and nothing spelled alike', () => {
    // Platform separators: the predicate is lexical, so a POSIX literal would ask
    // the wrong question on Windows (where `/a/b/c` is not under `/a/b`).
    const root = ['', 'a', 'b'].join(sep)
    expect(isCanonicallyUnder(root, root)).toBe(true)
    expect(isCanonicallyUnder(join(root, 'c'), root)).toBe(true)
    expect(isCanonicallyUnder(`${root}c`, root)).toBe(false)
    expect(isCanonicallyUnder(['', 'a'].join(sep), root)).toBe(false)
  })
})

describe('validateRootCandidate', () => {
  it('canonicalizes an accepted candidate', () => {
    expect(check(sibling)).toBe(canonicalPath(sibling))
  })

  it('expands `~` against a home directory and accepts it', () => {
    // Run against a home that is plainly a sibling of the fixture. On a CI runner
    // the real home IS an ancestor of the checkout, where the primary-overlap rule
    // correctly refuses the whole home tree — that is the case below, and mixing
    // the two would make this assertion depend on where the runner keeps $HOME.
    const expandedHome = join(fixture.outside, 'home')
    mkdirSync(expandedHome, { recursive: true })
    expect(check('~', [], expandedHome)).toBe(canonicalPath(expandedHome))
  })

  it('rejects a home directory that contains the workspace, with the overlap rule', () => {
    // The other side of the same coin, and the reason the case above takes a home
    // of its own: on a runner whose home holds the checkout, `~` overlaps the
    // primary root and is refused — as a configuration, not as a path bug.
    const ancestor = join(primary, 'ancestor-home')
    mkdirSync(ancestor, { recursive: true })
    expect(() => check('~', [], fixture.base)).toThrow(RootValidationError)
    expect(codeOf(primary, [])).toBe('equals-primary')
    expect(codeOf(ancestor, [])).toBe('primary-overlap')
  })

  it('resolves a spelling with `..` to the same canonical root', () => {
    expect(check(join(sibling, 'inner', '..'))).toBe(canonicalPath(sibling))
  })

  it('rejects a relative path as not-absolute', () => {
    expect(codeOf('relative/dir')).toBe('not-absolute')
    expect(codeOf('./relative')).toBe('not-absolute')
  })

  it('rejects an empty input as not-absolute', () => {
    expect(codeOf('   ')).toBe('not-absolute')
  })

  it('rejects a missing directory', () => {
    expect(codeOf(join(fixture.base, 'nope'))).toBe('missing')
  })

  it('rejects a file', () => {
    expect(codeOf(join(fixture.base, 'a-file'))).toBe('not-a-directory')
  })

  it('rejects the primary root itself', () => {
    expect(codeOf(primary)).toBe('equals-primary')
    expect(codeOf(join(primary, '.'))).toBe('equals-primary')
  })

  it('rejects a candidate that canonicalizes onto an already registered root', () => {
    expect(codeOf(sibling, [sibling])).toBe('duplicate')
    expect(codeOf(join(sibling, 'inner', '..'), [sibling])).toBe('duplicate')
  })

  it('rejects a candidate nested under a registered root', () => {
    expect(codeOf(nested, [sibling])).toBe('nested')
  })

  it('rejects a candidate that contains a registered root', () => {
    // A parent of the workspace root overlaps the primary root first, which is
    // the same refusal for a sharper reason; the pure additional-root case is
    // covered below with a sibling that does not contain the primary root.
    expect(codeOf(fixture.base, [sibling])).toBe('primary-overlap')
    expect(codeOf(join(fixture.base, 'parent'), [canonicalPath(join(fixture.base, 'parent/child'))])).toBe('missing')
  })

  it('rejects a candidate inside the primary root, even with nothing registered', () => {
    // The primary root takes part in the overlap rule like any other root: a
    // child of it adds no writable range. Checking it only against `existing`
    // used to let this through on an empty registration list.
    const sub = join(primary, 'sub')
    mkdirSync(sub)
    expect(codeOf(sub, [])).toBe('primary-overlap')
    expect(codeOf(sub, [sibling])).toBe('primary-overlap')
  })

  it('rejects a candidate that contains the primary root, even with nothing registered', () => {
    expect(codeOf(fixture.base, [])).toBe('primary-overlap')
  })

  it('keeps equals-primary distinct from primary-overlap', () => {
    expect(codeOf(primary)).toBe('equals-primary')
    expect(codeOf(join(primary, '.'))).toBe('equals-primary')
  })

  it('names the primary root in the primary-overlap detail', () => {
    const sub = join(primary, 'sub')
    mkdirSync(sub, { recursive: true })
    try {
      check(sub)
      expect.unreachable('a child of the primary root must be rejected')
    } catch (error: unknown) {
      expect(error).toBeInstanceOf(RootValidationError)
      expect((error as RootValidationError).code).toBe('primary-overlap')
      expect((error as RootValidationError).detail?.conflict).toBe(primary)
    }
  })

  it('still reports a nested additional root as nested, not as a primary overlap', () => {
    const outer = join(fixture.base, 'outer')
    const inner = join(outer, 'inner')
    mkdirSync(inner, { recursive: true })
    expect(codeOf(inner, [outer])).toBe('nested')
    expect(codeOf(outer, [inner])).toBe('nested')
  })

  it('names the conflicting root in the failure detail', () => {
    try {
      check(nested, [sibling])
      expect.unreachable('nested candidate must be rejected')
    } catch (error: unknown) {
      expect(error).toBeInstanceOf(RootValidationError)
      expect((error as RootValidationError).detail?.conflict).toBe(canonicalPath(sibling))
    }
  })

  it('treats a symlink alias as the same root', (context) => {
    if (symlinkReason !== undefined) context.skip(symlinkReason)
    expect(codeOf(alias, [canonicalPath(sibling)])).toBe('duplicate')
    expect(check(alias)).toBe(canonicalPath(sibling))
  })

  describe('on Windows', () => {
    const win32 = { platform: 'win32' as const }

    it('rejects a network or device path lexically, before any filesystem touch', () => {
      // `//host/missing` would otherwise be `missing` (or would hang inside an
      // SMB lookup): the refusal must name unsupported-path and must happen
      // without stat-ing the path.
      for (const raw of ['//host/missing', '//server/share/dir', '//?/C:/x', '//./pipe/x']) {
        try {
          validateRootCandidate(raw, { primaryRoot: primary, existing: [], ...win32 })
          expect.unreachable(`${raw} must be rejected`)
        } catch (error: unknown) {
          expect(error).toBeInstanceOf(RootValidationError)
          expect((error as RootValidationError).code).toBe('unsupported-path')
        }
      }
      expect(codeOf(join(fixture.base, 'nope'), [], undefined)).toBe('missing')
    })

    it('still accepts an ordinary local directory', () => {
      expect(validateRootCandidate(sibling, { primaryRoot: primary, existing: [], ...win32 })).toBe(canonicalPath(sibling))
    })
  })
})

describe('isWindowsNetworkOrDevicePath', () => {
  it('matches two leading slashes or backslashes in any mix', () => {
    for (const path of ['\\\\server\\share\\x', '//server/share', '\\\\?\\C:\\x', '\\\\.\\pipe\\x', '/\\mixed']) {
      expect(isWindowsNetworkOrDevicePath(path), path).toBe(true)
    }
    for (const path of ['C:\\x', '/home/x', 'relative', '']) {
      expect(isWindowsNetworkOrDevicePath(path), path).toBe(false)
    }
  })
})

describe('classifyStoredRoots', () => {
  /** One stored record: `path` as spelled, `recordedPath` as granted. */
  const stored = (path: string, id = path, recordedPath = path): RegisteredRoot => ({
    id: additionalRootId(id),
    path,
    access: 'read-write',
    recordedPath,
    addedAt: '2026-09-12T00:00:00.000Z',
  })

  it('marks an existing root available and keeps registry order', () => {
    const statuses = classifyStoredRoots(primary, [stored(sibling), stored(other, 'o2')])
    expect(statuses.map(status => status.state)).toEqual(['available', 'available'])
    expect(statuses[0]?.path).toBe(canonicalPath(sibling))
    expect(availableRoots(statuses)).toEqual([canonicalPath(sibling), canonicalPath(other)])
  })

  it('keeps a registration whose directory vanished, as missing rather than invalid', () => {
    const gone = join(fixture.base, 'vanished')
    const statuses = classifyStoredRoots(primary, [stored(gone)])
    expect(statuses[0]?.state).toBe('missing')
    expect(statuses[0]?.path).toBe(gone)
    expect(availableRoots(statuses)).toEqual([])
  })

  it('flags a record equal to the primary root as invalid', () => {
    expect(classifyStoredRoots(primary, [stored(primary)])[0]?.state).toBe('invalid')
  })

  it('flags both records of equal recorded boundaries as a membership conflict', () => {
    // No "first one wins": which side of an equal pair is unusable must never
    // depend on which record the registry happens to list first.
    const statuses = classifyStoredRoots(primary, [stored(sibling), stored(join(sibling, '.'), 'other')])
    expect(statuses.map(status => status.state)).toEqual(['invalid', 'invalid'])
    expect(statuses.every(status => status.invalidReason === 'membership-conflict')).toBe(true)
    expect(availableRoots(statuses)).toEqual([])
  })

  it('flags every record of an overlap as a membership conflict, in either direction and either order', () => {
    // Both sides lose membership while the conflict stands, and the detail
    // says the trustworthy negative boundary survives — a move is cosmetic
    // and must never change who is denied.
    for (const records of [
      [stored(sibling), stored(nested, 'n2')],
      [stored(nested), stored(sibling, 'n2')],
      [stored(nested), stored(join(nested, 'deep'), 'n2'), stored(sibling, 'n3')],
    ]) {
      const statuses = classifyStoredRoots(primary, records)
      expect(statuses.map(status => status.state)).toEqual(records.map(() => 'invalid'))
      for (const status of statuses) {
        expect(status.invalidReason).toBe('membership-conflict')
        expect(status.detail).toContain('overlaps')
        expect(status.detail).toContain('remains in force')
      }
      expect(availableRoots(statuses)).toEqual([])
    }
  })

  it('flags a relative stored path as invalid', () => {
    expect(classifyStoredRoots(primary, [stored('relative/dir')])[0]?.state).toBe('invalid')
  })

  it('flags a record with no usable identity as invalid', () => {
    expect(classifyStoredRoots(primary, [{ ...stored(sibling), id: additionalRootId('') }])[0]?.state).toBe('invalid')
  })

  it('canonicalizes a stored symlink spelling that was granted as that symlink', (context) => {
    if (symlinkReason !== undefined) context.skip(symlinkReason)
    // The operator registered the alias itself: the recorded directory IS the
    // resolved one, so the record is granted under its canonical spelling.
    const statuses = classifyStoredRoots(primary, [stored(alias, 'alias', canonicalPath(sibling))])
    expect(statuses[0]?.state).toBe('available')
    expect(statuses[0]?.path).toBe(canonicalPath(sibling))
  })

  it('flags a record whose path now resolves elsewhere as redirected, not granted', () => {
    // Granted for `nested` but now resolving to its parent `sibling`: the
    // directory that would be handed to the providers is not the one the
    // record was granted for, so it is withheld and reported.
    const statuses = classifyStoredRoots(primary, [stored(sibling, 'moved', nested)])
    expect(statuses[0]?.state).toBe('redirected')
    expect(statuses[0]?.detail).toContain(canonicalPath(sibling))
    expect(availableRoots(statuses)).toEqual([])
  })

  it('grants a record that is spelled through a symlink but resolves to its recorded directory', (context) => {
    if (symlinkReason !== undefined) context.skip(symlinkReason)
    // The alias resolves to `sibling`, which is the directory this record was
    // granted for. Authorization follows the resolved directory, so the
    // spelling does not matter here.
    const statuses = classifyStoredRoots(primary, [stored(alias, 'alias', canonicalPath(sibling))])
    expect(statuses[0]?.state).toBe('available')
    expect(statuses[0]?.path).toBe(canonicalPath(sibling))
  })

  it('flags a record that does not say what it was granted for as invalid', () => {
    expect(classifyStoredRoots(primary, [stored(sibling, 'legacy', '')])[0]?.state).toBe('invalid')
  })

  it('flags every record of a duplicated id as invalid, and grants none of them', () => {
    const statuses = classifyStoredRoots(primary, [
      stored(sibling, 'shared'),
      stored(join(fixture.base, 'gone'), 'shared'),
    ])
    expect(statuses.map(status => status.state)).toEqual(['invalid', 'invalid'])
    expect(statuses[0]?.detail).toBeDefined()
    expect(availableRoots(statuses)).toEqual([])
  })

  it('flags a record nested under the primary root as invalid', () => {
    const inside = join(primary, 'inside')
    mkdirSync(inside, { recursive: true })
    expect(classifyStoredRoots(primary, [stored(inside)])[0]?.state).toBe('invalid')
  })

  it('flags a record containing the primary root as invalid', () => {
    expect(classifyStoredRoots(primary, [stored(fixture.base)])[0]?.state).toBe('invalid')
  })

  it('marks a network or device path invalid on Windows without stat-ing it', () => {
    // `//host/missing` is absolute on every platform and resolves nowhere: only
    // the lexical win32 check can mark it invalid without a filesystem touch.
    for (const record of [
      stored('//host/missing', 'unc-path'),
      { ...stored(sibling, 'unc-recorded'), recordedPath: '//host/missing' },
    ]) {
      const status = classifyStoredRoots(primary, [record], 'win32')[0]!
      expect(status.state).toBe('invalid')
      expect(status.detail).toContain('network or device path')
    }
    // The same records stay available/ordinary on platforms without the rule —
    // only meaningful on a POSIX host: on Windows the host filesystem handles
    // `//host/missing` and may judge it invalid for its own reasons.
    if (process.platform !== 'win32') {
      expect(classifyStoredRoots(primary, [stored('//host/missing', 'unc-path')])[0]?.state).not.toBe('invalid')
    }
  })

  it('marks a membership conflict between missing and redirected records too', () => {
    // Withheld records grant nothing, but their recorded boundaries still
    // describe restrictions the operator has not removed — a missing record
    // and a redirected one must collide like two available ones.
    const gone = join(fixture.base, 'vanished')
    const statuses = classifyStoredRoots(primary, [
      stored(gone, 'gone', gone),
      // Granted for `gone` but now resolving to `sibling`: redirected, and its
      // recorded boundary still names `gone` — the very boundary above.
      stored(sibling, 'moved', gone),
    ])
    expect(statuses.map(status => status.state)).toEqual(['invalid', 'invalid'])
    expect(statuses.every(status => status.invalidReason === 'membership-conflict')).toBe(true)
  })

  it('judges the primary-overlap rule on the recorded boundary, before the redirect check', () => {
    // The record's path now resolves outside the primary root, but its
    // recorded grant IS inside it: the current resolution is
    // attacker-influenceable, so a grant that was inside the workspace must
    // not come back as `redirected` (withheld-but-revivable).
    const inside = join(primary, 'inside')
    const statuses = classifyStoredRoots(primary, [stored(sibling, 'moved', inside)])
    expect(statuses[0]?.state).toBe('invalid')
    // Trustworthy boundary: withheld, deny-only — never re-granted.
    expect(statuses[0]?.invalidReason).toBe('primary-overlap')
    expect(statuses[0]?.detail).toContain('overlaps')
  })

  it('flags a non-absolute recorded boundary as invalid, and lets it claim nothing', () => {
    const statuses = classifyStoredRoots(primary, [
      stored(sibling, 'corrupt', 'relative/grant'),
      stored(nested, 'n2'),
    ])
    // The corrupt record is structural-invalid and stays out of pass two —
    // the overlapping `nested` record is NOT dragged into a conflict with a
    // boundary that could never be verified.
    expect(statuses[0]?.state).toBe('invalid')
    expect(statuses[0]?.invalidReason).toBeUndefined()
    expect(statuses[1]?.state).toBe('available')
    expect(availableRoots(statuses)).toEqual([canonicalPath(nested)])
  })

  it('keeps a multi-grant record out of the conflict pass entirely', () => {
    // Two grant fields at once can state no trustworthy boundary: it never
    // conflicts with — and never denies through — the root it overlaps.
    const statuses = classifyStoredRoots(primary, [
      { ...stored(sibling, 'corrupt'), readOnlyRecordedPath: nested },
      stored(nested, 'n2'),
    ])
    expect(statuses[0]?.state).toBe('invalid')
    expect(statuses[0]?.invalidReason).toBeUndefined()
    expect(statuses[0]?.detail).toContain('more than one grant')
    expect(statuses[1]?.state).toBe('available')
    expect(availableRoots(statuses)).toEqual([canonicalPath(nested)])
  })
})

describe('reservedRootBoundary', () => {
  const stored = (path: string, id = path, grant: 'recordedPath' | 'readOnlyRecordedPath' | 'readWriteRecordedPath' = 'recordedPath'): RegisteredRoot => ({
    id: additionalRootId(id),
    path,
    access: 'inherit',
    [grant]: path,
    addedAt: '2026-09-12T00:00:00.000Z',
  })

  it('returns the one recorded grant of every trustworthy status', () => {
    const gone = join(fixture.base, 'vanished')
    const statuses = classifyStoredRoots(primary, [
      stored(sibling),
      stored(gone, 'gone', 'readOnlyRecordedPath'),
      // Granted for `other` but now resolving to `sibling`: redirected — and
      // the reserved boundary is the recorded grant, never the resolution.
      { ...stored(other, 'moved', 'readWriteRecordedPath'), path: sibling },
    ])
    expect(statuses.map(status => status.state)).toEqual(['available', 'missing', 'redirected'])
    expect(reservedRootBoundary(statuses[0]!)).toBe(sibling)
    expect(reservedRootBoundary(statuses[1]!)).toBe(gone)
    expect(reservedRootBoundary(statuses[2]!)).toBe(other)
  })

  it('keeps the recorded boundary of a membership-conflict record', () => {
    // A conflicted record grants nothing, but its recorded boundary is exactly
    // the deny an attacker would like to see lapse — it stays reserved.
    const statuses = classifyStoredRoots(primary, [stored(sibling), stored(nested, 'n2', 'readOnlyRecordedPath')])
    expect(statuses.every(status => status.invalidReason === 'membership-conflict')).toBe(true)
    expect(reservedRootBoundary(statuses[0]!)).toBe(sibling)
    expect(reservedRootBoundary(statuses[1]!)).toBe(nested)
  })

  it('returns nothing for a structurally invalid record', () => {
    const noGrant: RegisteredRoot = {
      id: additionalRootId('legacy'), path: sibling, access: 'inherit', addedAt: '2026-09-12T00:00:00.000Z',
    }
    const noGrantStatus = classifyStoredRoots(primary, [noGrant])[0]!
    expect(noGrantStatus.state).toBe('invalid')
    expect(reservedRootBoundary(noGrantStatus)).toBeUndefined()
    const ambiguous = classifyStoredRoots(primary, [{ ...stored(sibling, 'corrupt'), readOnlyRecordedPath: nested }])[0]!
    expect(ambiguous.invalidReason).toBeUndefined()
    expect(reservedRootBoundary(ambiguous)).toBeUndefined()
    const notAbsolute = classifyStoredRoots(primary, [{ ...stored(sibling, 'corrupt2'), recordedPath: 'relative' }])[0]!
    expect(notAbsolute.invalidReason).toBeUndefined()
    expect(reservedRootBoundary(notAbsolute)).toBeUndefined()
  })
})

describe('resolveRootRef', () => {
  /** Built per test: the fixture tree only exists once `beforeAll` has run. */
  const statusesOf = (): ReturnType<typeof classifyStoredRoots> => classifyStoredRoots(primary, [
    { id: additionalRootId('a'), path: sibling, access: 'read-write', recordedPath: sibling, addedAt: '2026-09-12T00:00:00.000Z' },
    {
      id: additionalRootId('b'),
      path: join(fixture.base, 'gone'),
      access: 'read-write',
      recordedPath: join(fixture.base, 'gone'),
      addedAt: '2026-09-12T00:00:00.000Z',
    },
  ])

  it('resolves by id, ordinal, and path spelling', () => {
    const statuses = statusesOf()
    expect(resolveRootRef(statuses, { kind: 'id', id: 'a' }).id).toBe('a')
    expect(resolveRootRef(statuses, { kind: 'ordinal', ordinal: 2 }).id).toBe('b')
    expect(resolveRootRef(statuses, { kind: 'path', path: sibling }).id).toBe('a')
    expect(resolveRootRef(statuses, { kind: 'path', path: join(sibling, '.') }).id).toBe('a')
  })

  it('rejects an out-of-range ordinal and an unknown id', () => {
    const statuses = statusesOf()
    expect(() => resolveRootRef(statuses, { kind: 'ordinal', ordinal: 0 })).toThrow(RootValidationError)
    expect(() => resolveRootRef(statuses, { kind: 'ordinal', ordinal: 3 })).toThrow(RootValidationError)
    expect(() => resolveRootRef(statuses, { kind: 'id', id: 'zzz' })).toThrow(RootValidationError)
  })

  it('reports not-found as the code the surfaces localize', () => {
    try {
      resolveRootRef(statusesOf(), { kind: 'path', path: join(fixture.base, 'other') })
      expect.unreachable('unknown path must not resolve')
    } catch (error: unknown) {
      expect((error as RootValidationError).code).toBe('not-found')
    }
  })
})

describe('indexedStatuses and removeStatusAt', () => {
  /** Two records that share one id — the case a removal by id cannot address. */
  const duplicateId = (): ReturnType<typeof classifyStoredRoots> => classifyStoredRoots(primary, [
    { id: additionalRootId('same'), path: sibling, access: 'read-write', recordedPath: sibling, addedAt: '2026-09-12T00:00:00.000Z' },
    {
      id: additionalRootId('same'),
      path: join(fixture.base, 'gone'),
      access: 'read-write',
      recordedPath: join(fixture.base, 'gone'),
      addedAt: '2026-09-12T00:00:00.000Z',
    },
  ])

  it('numbers the positions from 1, independently of the ids', () => {
    expect(indexedStatuses(duplicateId()).map(entry => entry.ordinal)).toEqual([1, 2])
  })

  it('removes exactly one record by ordinal, even when two share an id', () => {
    const statuses = duplicateId()
    const afterFirst = removeStatusAt(statuses, { kind: 'ordinal', ordinal: 1 })
    expect(afterFirst).toHaveLength(1)
    expect(afterFirst[0]?.path).toBe(join(fixture.base, 'gone'))
    const afterSecond = removeStatusAt(statuses, { kind: 'ordinal', ordinal: 2 })
    expect(afterSecond).toHaveLength(1)
    expect(afterSecond[0]?.path).toBe(sibling)
  })

  it('rejects an id that matches more than one record', () => {
    expect(() => removeStatusAt(duplicateId(), { kind: 'id', id: 'same' }))
      .toThrowError(/matches more than one/)
  })

  it('rejects an entry snapshot when the stored rows are completely indistinguishable', () => {
    const first = duplicateId()[0]!
    const identical = [first, { ...first }]
    expect(() => removeStatusAt(identical, entryRootRef(first, 1))).toThrowError(/matches more than one/)
  })

  it('removes by canonical path spelling', () => {
    const after = removeStatusAt(duplicateId(), { kind: 'path', path: join(sibling, '.') })
    expect(after).toHaveLength(1)
    expect(after[0]?.path).toBe(join(fixture.base, 'gone'))
  })

  it('reports not-found for an ordinal outside the list', () => {
    expect(() => removeStatusAt(duplicateId(), { kind: 'ordinal', ordinal: 3 })).toThrow(RootValidationError)
  })
})

describe('canonicalRoot', () => {
  it('returns the input unchanged when the path cannot be resolved', () => {
    const missing = join(fixture.base, 'missing', 'deep')
    expect(canonicalRoot(missing)).toBe(missing)
  })
})

describe('protected DSH directories', () => {
  // fixture only exists after the file-level beforeAll runs.
  let home: string
  let medium: string
  beforeAll(() => {
    home = join(fixture.base, 'dsh-home')
    medium = join(fixture.base, 'medium')
  })
  const boundary = (path: string, kind: ProtectedPath['kind']): ProtectedPath => ({ kind, path: canonicalPath(path) })
  /** One stored record: `path` as spelled, `recordedPath` as granted. */
  const stored = (path: string, id = path): RegisteredRoot => ({
    id: additionalRootId(id), path, access: 'read-write', recordedPath: path, addedAt: '2026-09-12T00:00:00.000Z',
  })
  /** The failure code of one candidate judged against a protected set. */
  const protectedCodeOf = (raw: string, protectedPaths: readonly ProtectedPath[]): string => {
    try {
      validateRootCandidate(raw, { primaryRoot: primary, existing: [], protectedPaths })
    } catch (error: unknown) {
      if (error instanceof RootValidationError) return error.code
      throw error
    }
    return 'accepted'
  }

  it('refuses the home itself, a descendant, and an ancestor — and accepts a sibling', () => {
    mkdirSync(join(home, 'inner'), { recursive: true })
    const protectedPaths = [boundary(home, 'dsh-home')]
    expect(protectedCodeOf(home, protectedPaths)).toBe('protected-path')
    expect(protectedCodeOf(join(home, 'inner'), protectedPaths)).toBe('protected-path')
    expect(protectedCodeOf(fixture.base, protectedPaths)).toBe('protected-path')
    expect(protectedCodeOf(sibling, protectedPaths)).toBe('accepted')
  })

  it('refuses a symlink alias into a protected directory, judged canonically', (context) => {
    if (symlinkReason !== undefined) context.skip(symlinkReason)
    mkdirSync(home, { recursive: true })
    const link = join(fixture.base, 'home-alias')
    symlinkSync(home, link)
    expect(protectedCodeOf(link, [boundary(home, 'dsh-home')])).toBe('protected-path')
  })

  it('refuses a registry-medium directory outside the home the same way', () => {
    mkdirSync(join(medium, 'inner'), { recursive: true })
    const protectedPaths = [boundary(medium, 'registry-medium')]
    expect(protectedCodeOf(medium, protectedPaths)).toBe('protected-path')
    expect(protectedCodeOf(join(medium, 'inner'), protectedPaths)).toBe('protected-path')
    expect(protectedCodeOf(fixture.base, protectedPaths)).toBe('protected-path')
  })

  it('marks a stored record inside a protected directory as protected-path invalid, for every grant encoding', () => {
    mkdirSync(home, { recursive: true })
    const inside = join(home, 'stored')
    const protectedPaths = [{ kind: 'dsh-home', path: home } as const]
    for (const field of ['recordedPath', 'readOnlyRecordedPath', 'readWriteRecordedPath'] as const) {
      const record: RegisteredRoot = {
        id: additionalRootId(field), path: inside, access: 'inherit', [field]: inside,
        addedAt: '2026-09-12T00:00:00.000Z',
      }
      const [status] = classifyStoredRoots(primary, [record], process.platform, protectedPaths)
      expect(status?.state).toBe('invalid')
      expect(status?.invalidReason).toBe('protected-path')
      expect(status?.detail).toContain('protected DSH directory')
      // Deny-only: the intact boundary still reserves the tree.
      expect(reservedRootBoundary(status!)).toBe(inside)
    }
  })

  it('keeps a protected-path verdict while an overlapping partner becomes a membership conflict', () => {
    // Protected path INSIDE record A's grant: partner B overlaps A without
    // touching the protected path, so B alone earns the conflict verdict.
    const inner = join(home, 'inner')
    mkdirSync(inner, { recursive: true })
    const other = join(home, 'other')
    mkdirSync(other, { recursive: true })
    const statuses = classifyStoredRoots(primary, [
      stored(home, 'covering'),
      stored(other, 'partner'),
    ], process.platform, [{ kind: 'dsh-home', path: inner }])
    expect(statuses.map(status => status.state)).toEqual(['invalid', 'invalid'])
    expect(statuses[0]?.invalidReason).toBe('protected-path')
    expect(statuses[0]?.detail).toContain('protected DSH directory')
    expect(statuses[1]?.invalidReason).toBe('membership-conflict')
  })

  it('markProtectedPaths applies the same verdict to already-classified statuses', () => {
    const inner = join(home, 'inner')
    mkdirSync(inner, { recursive: true })
    const records = [stored(home, 'covering'), stored(sibling, 'plain')]
    const protectedPaths = [{ kind: 'dsh-home', path: inner } as const]
    const marked = markProtectedPaths(classifyStoredRoots(primary, records), protectedPaths)
    const direct = classifyStoredRoots(primary, records, process.platform, protectedPaths)
    expect(marked.map(status => [status.state, status.invalidReason]))
      .toEqual(direct.map(status => [status.state, status.invalidReason]))
    expect(marked[0]?.invalidReason).toBe('protected-path')
    expect(marked[0]?.detail).toBe(direct[0]?.detail)
    expect(marked[1]?.state).toBe('available')
  })
})

describe('primaryKey', () => {
  it('normalizes lexically without touching the filesystem', () => {
    const base = join(fixture.base, 'anything')
    expect(primaryKey(`${base}/`)).toBe(primaryKey(base))
    expect(primaryKey(join(base, 'sub', '..'))).toBe(primaryKey(base))
    expect(primaryKey(join(base, 'a/../b'))).toBe(primaryKey(join(base, 'b')))
    // Lexical only: no realpath — a symlink spelling keeps its own key.
    expect(primaryKey(fixture.base)).not.toBe(canonicalPath(fixture.base) === fixture.base ? '' : '')
  })

  it('case-folds on Windows and nowhere else', () => {
    expect(primaryKey('C:\\Repos\\WS', 'win32')).toBe(primaryKey('c:\\repos\\ws', 'win32'))
    expect(primaryKey('/Repos/WS', 'linux')).not.toBe(primaryKey('/repos/ws', 'linux'))
  })
})
