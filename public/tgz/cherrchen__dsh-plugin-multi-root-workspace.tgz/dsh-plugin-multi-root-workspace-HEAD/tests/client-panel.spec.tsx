// @vitest-environment jsdom
/**
 * The panel, driven the way the browser drives it: the real client entry is
 * applied to a stub client context, the registered component is rendered, and
 * every action is observed through the stub Connection channel.
 *
 * The stub is deliberate — the panel's contract IS the channel, and asserting
 * the exact (channel, endpoint, payload) triples is what keeps the browser half
 * and the host half from drifting apart. The host side of each endpoint is
 * covered by `tests/command.spec.ts` and by the behavior smoke.
 */

import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { createElement, StrictMode } from 'react'
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { PANEL_CHANNEL, type PanelRequest, type RevealedView, type RootView, type RootsView } from '../src/contract.ts'
import * as client from '../src/client/index.ts'
import { en, NS, zh } from '../src/client/locales.ts'

// The jsdom environment has no file-URL `import.meta.url`, so the repository
// root comes from the runner's working directory (vitest runs at the root).
const REPO_ROOT = process.cwd()

/** One captured channel call. */
interface Call {
  readonly channel: string
  readonly endpoint: string
  readonly payload: PanelRequest
}

/** One slot registration the plugin made. */
interface Registration {
  readonly options: { name: string; id?: string; order?: number; label?: unknown; locale?: string }
  readonly component: () => unknown
}

/** The stub client context, plus what the plugin did with it. */
interface Harness {
  readonly ctx: unknown
  readonly calls: Call[]
  readonly registrations: Registration[]
  readonly dictionaries: { ns: string; dicts: Record<string, unknown> }[]
  setView: (view: HostView) => void
  setSession: (sessionId: string | undefined) => void
  /**
   * Present the 0.1.6-alpha.2 catalog: no `current` field, and the main view
   * is whichever row carries `mainView`. Passing this switches the stub off
   * the legacy selection snapshot until `setSession` is called again.
   */
  setCatalog: (rows: readonly { id: string; mainView?: number }[]) => void
  setFailure: (failure: { code: string; message: string } | undefined) => void
  /** What the next `reveal` answers (the real host answers a `RevealedView`). */
  setRevealed: (value: unknown) => void
  /** Make the NEXT channel call hang until `release` is called. */
  holdNextCall: () => void
  /** Release a call held by `holdNextCall`. */
  release: () => void
}

/** Old hosts omit cap metadata; exercise their actual response on the channel. */
type HostView = Omit<RootsView, 'limit' | 'count'> & Partial<Pick<RootsView, 'limit' | 'count'>>

const ROOT_A: RootView = { ordinal: 1, id: 'a', path: '/repos/payments', addedAt: '2026-09-12T00:00:00.000Z', state: 'available', access: 'read-write', alias: 'payments' }
const ROOT_B: RootView = { ordinal: 2, id: 'b', path: '/repos/website', addedAt: '2026-09-12T00:00:00.000Z', state: 'missing', access: 'read-only', detail: 'gone' }
const ROOT_C: RootView = {
  ordinal: 3,
  id: 'c',
  path: '/repos/swapped',
  addedAt: '2026-09-12T00:00:00.000Z',
  state: 'redirected',
  access: 'read-write',
  detail: 'the path now resolves to "/repos/other"',
}

/**
 * The 0.1.6-alpha.2 list snapshot: catalog rows, no `current`.
 * `retainedBy.mainView` is omitted when the row is not the main view, which
 * is what an unselected catalog entry looks like.
 */
function catalogSnapshot(rows: readonly { id: string; mainView?: number }[]): {
  ids: string[]
  byId: Record<string, { id: string; retainedBy: { mainView?: number } }>
  phase: 'ready'
} {
  const byId: Record<string, { id: string; retainedBy: { mainView?: number } }> = {}
  for (const row of rows) {
    byId[row.id] = {
      id: row.id,
      retainedBy: row.mainView === undefined ? {} : { mainView: row.mainView },
    }
  }
  return { ids: rows.map(row => row.id), byId, phase: 'ready' }
}

/** Apply the real client entry to a recording stub context. */
function mount(withFilesActions = false): Harness {
  const calls: Call[] = []
  const registrations: Registration[] = []
  const dictionaries: { ns: string; dicts: Record<string, unknown> }[] = []
  let view: HostView = { primaryRoot: '/repos/primary', roots: [ROOT_A, ROOT_B], limit: 16, count: 2 }
  const sessionListeners = new Set<() => void>()
  let currentSession: string | undefined = 'session-1'
  // Undefined keeps the 0.1.5 / 0.1.6-alpha.1 selection snapshot (`current`).
  let catalog: readonly { id: string; mainView?: number }[] | undefined
  let failure: { code: string; message: string } | undefined
  let revealed: unknown = { revealed: '/repos/payments' } satisfies RevealedView
  let gate: Promise<void> | undefined
  let releaseGate: (() => void) | undefined
  const picked: string | null = '/repos/picked'

  const connection = {
    rpc: {
      call: async (channel: string, endpoint: string, payload: PanelRequest) => {
        calls.push({ channel, endpoint, payload })
        const listedView = view
        if (gate !== undefined) {
          const held = gate
          gate = undefined
          await held
        }
        if (failure !== undefined) return { ok: false, error: failure }
        if (endpoint === 'move' && payload.entry !== undefined) {
          const target = view.roots.find(root => root.ordinal === payload.entry!.ordinal)
          const without = view.roots.filter(root => root !== target)
          const before = payload.beforeEntry === undefined
            ? undefined
            : without.find(root => root.ordinal === payload.beforeEntry!.ordinal)
          const at = before === undefined ? without.length : without.indexOf(before)
          const reordered = target === undefined
            ? without
            : [...without.slice(0, at), target, ...without.slice(at)]
          view = { ...view, roots: reordered.map((root, index) => ({ ...root, ordinal: index + 1 })) }
        }
        // One shape per endpoint, exactly as the host sends them: `reveal`
        // answers with the revealed path, everything else with the whole view.
        // Answering a list for every endpoint is what used to hide the mismatch.
        return { ok: true, value: endpoint === 'reveal' ? revealed : endpoint === 'list' ? listedView : view }
      },
    },
  }
  const ctx = {
    effect: (callback: () => unknown) => {
      const dispose = callback()
      return typeof dispose === 'function' ? dispose : () => {}
    },
    locale: {
      register: (ns: string, dicts: Record<string, unknown>) => {
        dictionaries.push({ ns, dicts })
        return () => {}
      },
      // The real service resolves the live locale per call; for the spec the
      // namespace-qualified key is enough to observe which copy is used.
      bind: (ns: string) => (key: string, params?: Record<string, unknown>) => key === 'panel.accessEffective'
        ? zh['panel.accessEffective'].replace(/\{(\w+)\}/g, (_, name: string) => String(params?.[name]))
        : `${ns}.${key}`,
    },
    slots: {
      inject: (name: string, callback: () => unknown) => {
        if (name === 'sidebar.right.tab.files.actions' && !withFilesActions) return () => {}
        expect(['sidebar.footer.action', 'sidebar.right.tab.files.actions', 'shell.overlay']).toContain(name)
        callback()
        return () => {}
      },
      register: (options: Registration['options'], component: () => unknown) => {
        registrations.push({ options, component })
        return () => {}
      },
    },
    get: (name: string) => {
      if (name === 'connection') return connection
      if (name === 'uiWorkspace') return { pickDirectory: async () => picked }
      if (name === 'sessions') {
        return {
          list: {
            subscribe: (listener: () => void) => { sessionListeners.add(listener); return () => { sessionListeners.delete(listener) } },
            getSnapshot: () => catalog === undefined
              ? { current: currentSession }
              : catalogSnapshot(catalog),
          },
        }
      }
      return undefined
    },
  }
  client.apply(ctx as never)
  return {
    ctx,
    calls,
    registrations,
    dictionaries,
    setView: next => { view = next },
    setSession: next => {
      currentSession = next
      catalog = undefined
      for (const listener of sessionListeners) listener()
    },
    setCatalog: rows => { catalog = rows },
    setFailure: next => { failure = next },
    setRevealed: next => { revealed = next },
    holdNextCall: () => { gate = new Promise<void>(resolve => { releaseGate = resolve }) },
    release: () => { releaseGate?.(); releaseGate = undefined },
  }
}

/**
 * Render the component the plugin registered. The registered value is a
 * component function, so it is wrapped in an element: React does not accept a
 * bare function as a child.
 * @param harness - the mounted harness whose registration to render.
 */
function renderPanel(harness: Harness, strictMode = false): void {
  const registration = harness.registrations.find(item => item.options.name === 'sidebar.footer.action')!
  const panel = createElement(registration.component as never)
  render(strictMode ? createElement(StrictMode, null, panel) : panel)
}

beforeEach(() => {
  Object.defineProperty(navigator, 'clipboard', { value: { writeText: vi.fn(async () => {}) }, configurable: true })
})

afterEach(() => {
  // Vitest runs without globals, so the auto-cleanup hook is never installed.
  cleanup()
  vi.restoreAllMocks()
})

describe('the client entry', () => {
  it('opens the same session-derived panel from the optional Files actions slot', async () => {
    const harness = mount(true)
    const registration = harness.registrations.find(item => item.options.name === 'sidebar.right.tab.files.actions')!
    expect(registration).toBeDefined()
    render(createElement(registration.component as never))
    // Icon-only: the accessible name comes from `aria-label`, never from text.
    const launcher = screen.getByRole('button', { name: /action.title/ })
    expect(launcher.textContent).toBe('')
    fireEvent.click(launcher)
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })
    expect(harness.calls[0]).toEqual({ channel: PANEL_CHANNEL, endpoint: 'list', payload: { sessionId: 'session-1' } })
  })

  it('declares the services it needs', () => {
    expect(client.inject).toEqual(['slots', 'locale', 'connection'])
  })

  it('registers its dictionaries for both languages under its own namespace', () => {
    const harness = mount()
    expect(NS).toBe('multiRootWorkspace')
    expect(harness.dictionaries[0]?.ns).toBe(NS)
    expect(Object.keys(harness.dictionaries[0]?.dicts ?? {}).sort()).toEqual(['en', 'zh'])
  })

  it('registers into the sidebar footer action with a localized label thunk', () => {
    const harness = mount()
    const registration = harness.registrations.find(item => item.options.name === 'sidebar.footer.action')
    expect(registration?.options.name).toBe('sidebar.footer.action')
    expect(registration?.options.id).toBe(client.SLOT_ID)
    expect(registration?.options.order).toBe(50)
    expect(registration?.options.locale).toBe(NS)
    const label = registration?.options.label
    expect(typeof label).toBe('function')
    expect((label as () => string)()).toBe(`${NS}.action.label`)
  })

  it('registers nothing when no sidebar declares the slot', () => {
    const ctx = {
      effect: () => () => {},
      locale: { register: () => () => {}, bind: () => (key: string) => key },
      slots: { inject: () => () => {}, register: () => () => {} },
      get: () => undefined,
    }
    expect(() => { client.apply(ctx as never) }).not.toThrow()
  })
})

describe('the panel dialog', () => {
  it('toggles read-only Root Skills and edits its independent namespace over the channel', async () => {
    const harness = mount()
    harness.setView({ primaryRoot: '/repos/primary', roots: [{ ...ROOT_B, aliasId: 'website', skillsEnabled: false }], limit: 16, count: 1 })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    const toggle = await screen.findByRole('button', { name: `${NS}.panel.skills` })
    expect(toggle.getAttribute('aria-pressed')).toBe('false')
    expect(toggle.getAttribute('title')).toBe(`${NS}.panel.skillsDisabled`)
    expect(toggle.closest('.mrfw-rootText')).toBeNull()
    expect(screen.queryByText('/website:')).toBeNull()
    expect(screen.queryByRole('checkbox')).toBeNull()
    fireEvent.click(toggle)
    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'setSkillsEnabled' && call.payload.skillsEnabled === true)).toBe(true) })
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.more` }))
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.aliasIdEdit` }))
    const input = screen.getByPlaceholderText(`${NS}.panel.aliasIdPlaceholder`)
    fireEvent.change(input, { target: { value: 'site' } })
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.aliasSave` }))
    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'setAliasId' && call.payload.aliasId === 'site')).toBe(true) })
    expect(harness.calls.filter(call => call.endpoint === 'setAccess')).toHaveLength(0)
  })

  it('reflects an enabled Skills preference and disables it without changing folder access', async () => {
    const harness = mount()
    const root = { ...ROOT_A, aliasId: 'payments', skillsEnabled: true }
    harness.setView({ primaryRoot: '/repos/primary', roots: [root], limit: 16, count: 1 })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    const toggle = await screen.findByRole('button', { name: `${NS}.panel.skills` })
    expect(toggle.getAttribute('aria-pressed')).toBe('true')
    expect(toggle.getAttribute('title')).toBe(`${NS}.panel.skillsEnabled`)
    harness.setView({ primaryRoot: '/repos/primary', roots: [{ ...root, skillsEnabled: false }], limit: 16, count: 1 })
    fireEvent.click(toggle)
    await waitFor(() => { expect(toggle.getAttribute('aria-pressed')).toBe('false') })
    expect(harness.calls.find(call => call.endpoint === 'setSkillsEnabled')?.payload).toEqual({
      sessionId: 'session-1', entry: { ordinal: root.ordinal, id: root.id, path: root.path, addedAt: root.addedAt }, skillsEnabled: false,
    })
    expect(harness.calls.some(call => call.endpoint === 'setAccess')).toBe(false)
  })

  it.each([false, true])('keeps Skills controls stable while saving (failure: %s)', async failure => {
    const harness = mount()
    const root = { ...ROOT_A, skillsEnabled: true }
    harness.setView({ primaryRoot: '/repos/primary', roots: [root], limit: 16, count: 1 })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    const toggle = await screen.findByRole('button', { name: `${NS}.panel.skills` })
    const reveal = screen.getByRole('button', { name: `${NS}.panel.reveal` })
    const opacity = (element: HTMLElement) => getComputedStyle(element).opacity || '1'
    const before = [opacity(toggle), opacity(reveal)]
    toggle.focus()
    harness.holdNextCall()
    fireEvent.click(toggle)
    expect([opacity(toggle), opacity(reveal)]).toEqual(before)
    expect(document.activeElement).toBe(toggle)
    expect(toggle.getAttribute('aria-busy')).toBe('true')
    expect(toggle.getAttribute('aria-disabled')).toBe('true')
    expect(toggle).toHaveProperty('disabled', false)
    expect(toggle.getAttribute('aria-pressed')).toBe('true')
    fireEvent.click(toggle)
    fireEvent.click(reveal)
    expect(harness.calls.filter(call => call.endpoint === 'setSkillsEnabled')).toHaveLength(1)
    expect(harness.calls.some(call => call.endpoint === 'reveal')).toBe(false)
    if (failure) harness.setFailure({ code: 'storage-unavailable', message: 'save failed' })
    else harness.setView({ primaryRoot: '/repos/primary', roots: [{ ...root, skillsEnabled: false }], limit: 16, count: 1 })
    harness.release()
    await waitFor(() => { expect(toggle.getAttribute('aria-busy')).toBeNull() })
    expect(screen.getByRole('button', { name: `${NS}.panel.skills` })).toBe(toggle)
    expect(toggle.getAttribute('aria-pressed')).toBe(String(failure))
    expect(document.activeElement).toBe(toggle)
    expect([opacity(toggle), opacity(reveal)]).toEqual(before)
    expect(screen.queryByRole('alert') !== null).toBe(failure)
  })

  it('accepts list and mutation results after StrictMode replays mount effects', async () => {
    const harness = mount()
    renderPanel(harness, true)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await screen.findByText('/repos/payments')
    harness.setView({ primaryRoot: '/repos/primary', roots: [ROOT_B], limit: 16, count: 1 })
    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.more` })[0]!)
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.remove` }))
    await waitFor(() => { expect(screen.queryByText('/repos/payments')).toBeNull() })
    expect(harness.calls.some(call => call.endpoint === 'remove')).toBe(true)
  })

  it('reads the roots view for the current session and lists both roots', async () => {
    const harness = mount()
    renderPanel(harness)

    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))

    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })
    expect(harness.calls[0]).toEqual({ channel: PANEL_CHANNEL, endpoint: 'list', payload: { sessionId: 'session-1' } })
    // The primary row is two lines: the workspace's upstream title when the host
    // resolved one, the path basename otherwise, and the path underneath.
    expect(screen.getByText('/repos/primary')).toBeTruthy()
    expect(screen.getByText('primary')).toBeTruthy()
    expect(screen.getByText('payments')).toBeTruthy()
    expect(screen.getByText(`${NS}.state.missing`)).toBeTruthy()
  })

  it('embeds no additional-root file tree inside the dialog', async () => {
    // Browsing moved to the Files-tab root switcher; the management rows
    // keep no per-row tree.
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    expect(document.querySelector('.mrfw-ftBody')).toBeNull()
  })

  it('keeps legacy host lists usable even with more than the new default limit', async () => {
    const harness = mount()
    harness.setView({ primaryRoot: '/repos/primary', roots: Array.from({ length: 17 }, (_, i) => ({
      ...ROOT_A, ordinal: i + 1, id: String(i), path: `/repos/legacy-${i}`, alias: `legacy-${i}`,
    })) })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('legacy-16')).toBeTruthy() })
    expect(screen.queryByRole('alert')).toBeNull()
    expect(screen.getByRole('button', { name: `${NS}.panel.add` })).toHaveProperty('disabled', false)
    fireEvent.change(screen.getByPlaceholderText(`${NS}.panel.addManual`), { target: { value: '/repos/new' } })
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.addConfirm` }))
    await waitFor(() => { expect(harness.calls.at(-1)).toMatchObject({ endpoint: 'add', payload: { path: '/repos/new' } }) })
  })

  it('shows No active session and does not call the host when there is no current session', async () => {
    const harness = mount()
    harness.setSession(undefined)
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))

    await waitFor(() => { expect(screen.getByText(`${NS}.panel.noSession`)).toBeTruthy() })
    expect(harness.calls).toHaveLength(0)
    expect(screen.queryByPlaceholderText(`${NS}.panel.addManual`)).toBeNull()
    expect(screen.getByRole('button', { name: `${NS}.panel.retry` })).toBeTruthy()
  })

  it('calls the host after a session appears', async () => {
    const harness = mount()
    harness.setSession(undefined)
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText(`${NS}.panel.noSession`)).toBeTruthy() })

    act(() => { harness.setSession('session-1') })
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.retry` }))

    await waitFor(() => { expect(harness.calls.length).toBeGreaterThanOrEqual(1) })
    expect(harness.calls[0]?.payload).toEqual({ sessionId: 'session-1' })
  })

  it('reads the main-view session when the catalog has no current field', async () => {
    const harness = mount()
    // The unrelated row is first, so a reader that takes ids[0] names the
    // wrong session. Only retainedBy.mainView marks the one on screen.
    harness.setCatalog([
      { id: 'session-other' },
      { id: 'session-main', mainView: 1 },
    ])
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))

    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })
    expect(harness.calls[0]).toEqual({ channel: PANEL_CHANNEL, endpoint: 'list', payload: { sessionId: 'session-main' } })
    expect(screen.queryByText(`${NS}.panel.noSession`)).toBeNull()
  })

  it('shows No active session when catalog rows exist but none is the main view', async () => {
    const harness = mount()
    harness.setCatalog([{ id: 'session-other' }])
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))

    await waitFor(() => { expect(screen.getByText(`${NS}.panel.noSession`)).toBeTruthy() })
    expect(harness.calls).toHaveLength(0)
  })

  it('follows a main-view change on retry', async () => {
    const harness = mount()
    harness.setCatalog([{ id: 'session-main', mainView: 1 }])
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(harness.calls).toHaveLength(1) })

    harness.setCatalog([
      { id: 'session-main' },
      { id: 'session-next', mainView: 1 },
    ])
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.retry` }))

    await waitFor(() => { expect(harness.calls.length).toBeGreaterThanOrEqual(2) })
    expect(harness.calls[1]?.payload).toEqual({ sessionId: 'session-next' })
  })

  it('reads the current session again for each request', async () => {
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(harness.calls).toHaveLength(1) })

    act(() => { harness.setSession('session-2') })
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.retry` }))

    await waitFor(() => { expect(harness.calls.length).toBeGreaterThanOrEqual(2) })
    expect(harness.calls[1]?.payload).toEqual({ sessionId: 'session-2' })
  })

  it('shows the upstream workspace title as the primary row name', async () => {
    const harness = mount()
    harness.setView({ primaryRoot: '/repos/primary', primaryName: 'Payments Platform', roots: [ROOT_A], limit: 16, count: 1 })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))

    await waitFor(() => { expect(screen.getByText('Payments Platform')).toBeTruthy() })
    expect(screen.getByText('/repos/primary')).toBeTruthy()
  })

  it('removes and re-aliases roots without showing reorder buttons', async () => {
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    expect(screen.queryByRole('button', { name: `${NS}.panel.moveUp` })).toBeNull()
    expect(screen.queryByRole('button', { name: `${NS}.panel.moveDown` })).toBeNull()

    // Rename and remove live in the row's ellipsis menu.
    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.more` })[0]!)
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.rename` }))
    const input = screen.getByPlaceholderText(`${NS}.panel.aliasPlaceholder`)
    fireEvent.change(input, { target: { value: 'renamed' } })
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.aliasSave` }))
    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'alias')).toBe(true) })
    expect(harness.calls.find(call => call.endpoint === 'alias')?.payload).toEqual({
      sessionId: 'session-1',
      entry: { ordinal: 1, id: 'a', path: '/repos/payments', addedAt: '2026-09-12T00:00:00.000Z' },
      alias: 'renamed',
    })

    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.more` })[0]!)
    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.remove` })[0]!)
    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'remove')).toBe(true) })
    expect(harness.calls.find(call => call.endpoint === 'remove')?.payload).toEqual({
      sessionId: 'session-1',
      entry: { ordinal: 1, id: 'a', path: '/repos/payments', addedAt: '2026-09-12T00:00:00.000Z' },
    })
  })

  it('adds through the composed picker, then through the manual path field', async () => {
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.add` }))
    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'add')).toBe(true) })
    // The access picker is untouched, so no level travels: a chosen level is
    // the only one a request may carry — a displayed default is not a choice.
    expect(harness.calls.find(call => call.endpoint === 'add')?.payload).toEqual({
      sessionId: 'session-1',
      path: '/repos/picked',
    })

    const manual = screen.getByPlaceholderText(`${NS}.panel.addManual`)
    fireEvent.change(manual, { target: { value: '/repos/typed' } })
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.addConfirm` }))
    await waitFor(() => { expect(harness.calls.filter(call => call.endpoint === 'add')).toHaveLength(2) })
    // The confirm button submits the TYPED path. It used to submit whatever the
    // picker had returned, because both entry points shared one function.
    expect(harness.calls.filter(call => call.endpoint === 'add')[1]?.payload).toEqual({
      sessionId: 'session-1',
      path: '/repos/typed',
    })
    expect(screen.getByPlaceholderText(`${NS}.panel.addManual`)).toHaveProperty('value', '')
  })

  it('keeps a rejected manual path in the field', async () => {
    const harness = mount()
    harness.setFailure({ code: 'missing', message: 'host prose' })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByRole('alert').textContent).toBe(`${NS}.error.missing`) })

    const manual = screen.getByPlaceholderText(`${NS}.panel.addManual`)
    fireEvent.change(manual, { target: { value: '/repos/typo' } })
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.addConfirm` }))

    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'add')).toBe(true) })
    expect(screen.getByPlaceholderText(`${NS}.panel.addManual`)).toHaveProperty('value', '/repos/typo')
  })

  it('submits the typed path from the Enter key too', async () => {
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    const manual = screen.getByPlaceholderText(`${NS}.panel.addManual`)
    fireEvent.change(manual, { target: { value: '/repos/entered' } })
    fireEvent.keyDown(manual, { key: 'Enter' })

    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'add')).toBe(true) })
    expect(harness.calls.find(call => call.endpoint === 'add')?.payload).toEqual({
      sessionId: 'session-1',
      path: '/repos/entered',
    })
  })

  it('leaves the manual field alone when the operator opens the picker', async () => {
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    fireEvent.change(screen.getByPlaceholderText(`${NS}.panel.addManual`), { target: { value: '/repos/typed' } })
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.add` }))

    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'add')).toBe(true) })
    expect(harness.calls.find(call => call.endpoint === 'add')?.payload).toEqual({
      sessionId: 'session-1',
      path: '/repos/picked',
    })
    // The picker path and the typed path are two different actions; the typed
    // text is neither submitted nor cleared by the picker.
    expect(screen.getByPlaceholderText(`${NS}.panel.addManual`)).toHaveProperty('value', '/repos/typed')
  })

  it('reveals and copies a path from the row actions', async () => {
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.reveal` })[0]!)
    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'reveal')).toBe(true) })
    expect(harness.calls.find(call => call.endpoint === 'reveal')?.payload).toEqual({
      sessionId: 'session-1',
      entry: { ordinal: 1, id: 'a', path: '/repos/payments', addedAt: '2026-09-12T00:00:00.000Z' },
    })

    fireEvent.click(screen.getByTitle('/repos/payments'))
    await waitFor(() => { expect(navigator.clipboard.writeText).toHaveBeenCalledWith('/repos/payments') })
    // The path region itself is the control: the copy button IS the path
    // text, and the success swaps its accessible name for the feedback window.
    await waitFor(() => { expect(screen.getByTitle('/repos/payments').getAttribute('aria-label')).toBe(`${NS}.panel.copied`) })
  })

  it('does not report an error when a reveal succeeds', async () => {
    // The host answers `{ revealed }` for this endpoint. Parsing that as a roots
    // view is what made every successful reveal paint a failure.
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.reveal` })[0]!)

    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'reveal')).toBe(true) })
    // No failure is painted, and the list survives a reveal untouched.
    await waitFor(() => { expect(screen.queryByRole('alert')).toBeNull() })
    expect(screen.getByText('/repos/payments')).toBeTruthy()
    expect(harness.calls.filter(call => call.endpoint === 'list')).toHaveLength(1)
  })

  it('reports a reveal whose answer is not a reveal result', async () => {
    const harness = mount()
    harness.setRevealed({ primaryRoot: '/repos/primary', roots: [], limit: 16, count: 0 })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.reveal` })[0]!)

    await waitFor(() => { expect(screen.getByRole('alert').textContent).toBe(`${NS}.error.fallback`) })
  })

  it('reports a clipboard that refuses the copy', async () => {
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    vi.mocked(navigator.clipboard.writeText).mockRejectedValueOnce(new Error('denied'))
    fireEvent.click(screen.getByTitle('/repos/payments'))

    await waitFor(() => { expect(screen.getByRole('alert').textContent).toBe(`${NS}.error.copy-failed`) })
  })

  it('disables the row actions while a mutation is in flight', async () => {
    // The hold gate keeps the remove's channel call pending, which is the only
    // way to observe the busy window deterministically.
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    harness.holdNextCall()
    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.more` })[0]!)
    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.remove` })[0]!)
    expect(harness.calls.some(call => call.endpoint === 'remove')).toBe(true)
    // The menu closed on selection; the row's icon actions carry the busy state.
    expect(screen.getAllByRole('button', { name: `${NS}.panel.reveal` })[0]?.getAttribute('aria-disabled')).toBe('true')

    harness.release()
    await waitFor(() => {
      expect(screen.getAllByRole('button', { name: `${NS}.panel.reveal` })[0]).toHaveProperty('disabled', false)
    })
  })

  it('closes on Escape and keeps Tab cycling inside the dialog', async () => {
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    // Shift-Tab from the first focusable element wraps to the last one: the
    // dialog is modal, so Tab must not escape into the sidebar behind it.
    const dialog = screen.getByRole('dialog')
    const focusable = dialog.querySelectorAll<HTMLElement>('button:not([disabled]), input')
    focusable[0]!.focus()
    fireEvent.keyDown(dialog, { key: 'Tab', shiftKey: true })
    expect(document.activeElement).toBe(focusable[focusable.length - 1])

    fireEvent.keyDown(dialog, { key: 'Escape' })
    expect(screen.queryByRole('dialog')).toBeNull()
  })

  it('lets the nested upgrade modal keep its own Tab while it is open', async () => {
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/website')).toBeTruthy() })

    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.more` })[1]!)
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.accessReadWrite` }))
    const upgradeDialog = screen.getByRole('dialog', { name: `${NS}.panel.accessUpgradeTitle` })

    // The confirmation's buttons live outside `dialogRef` (the Modal portals
    // to document.body) but still bubble keys through the dialog's React
    // tree. A Tab must reach the modal's own focus handling — the parent
    // trap would otherwise steal focus to a control behind the modal.
    const modalButton = upgradeDialog.querySelector('button')!
    modalButton.focus()
    fireEvent.keyDown(modalButton, { key: 'Tab' })
    expect(upgradeDialog.contains(document.activeElement)).toBe(true)
  })

  it('renders a redirected root as its own state', async () => {
    const harness = mount()
    harness.setView({ primaryRoot: '/repos/primary', roots: [ROOT_C], limit: 16, count: 1 })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))

    await waitFor(() => { expect(screen.getByText(`${NS}.state.redirected`)).toBeTruthy() })
  })

  it('localizes a failure by its code instead of showing host prose', async () => {
    const harness = mount()
    harness.setFailure({ code: 'nested', message: 'host prose the panel must not show' })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))

    await waitFor(() => { expect(screen.getByRole('alert').textContent).toBe(`${NS}.error.nested`) })
    expect(screen.queryByText(/host prose/)).toBeNull()
  })

  it('shows internal host error details for diagnosis', async () => {
    const harness = mount()
    harness.setFailure({ code: 'panel/internal', message: 'cannot get property "sessions" without inject' })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))

    await waitFor(() => {
      expect(screen.getByRole('alert').textContent).toContain('cannot get property "sessions" without inject')
    })
  })

  it('falls back to the generic message for a code this build does not know', async () => {
    const harness = mount()
    harness.setFailure({ code: 'brand/new-code', message: 'unexpected' })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))

    await waitFor(() => { expect(screen.getByRole('alert').textContent).toBe(`${NS}.error.fallback`) })
  })

  it('shows the store failure the host reported', async () => {
    const harness = mount()
    harness.setView({ primaryRoot: '/repos/primary', roots: [], limit: 16, count: 0, unavailable: 'multi_root_workspace: file is not valid JSON' })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))

    await waitFor(() => {
      expect(screen.getByText(/file is not valid JSON/)).toBeTruthy()
    })
  })

  it('shows an access badge per root and sends the Add row selector with the request', async () => {
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    // ROOT_A is read-write, ROOT_B is read-only: both carry a badge. The
    // badge rides inside the name line, next to the display name — not in
    // the action cluster.
    const badges = () => Array.from(document.querySelectorAll('.mrfw-accessBadge')).map(node => node.textContent)
    expect(badges()).toEqual([`${NS}.access.readWrite`, `${NS}.access.readOnly`])
    expect(document.querySelector('.mrfw-accessBadge [data-icon="workspace-write"]')).not.toBeNull()
    expect(document.querySelector('.mrfw-accessBadge [data-icon="read-only"]')).not.toBeNull()
    expect(document.querySelectorAll('.mrfw-rootName .mrfw-accessBadge').length).toBe(2)

    // Every path is its own copy control — the primary row's too: a
    // borderless button painting as text, with the hover-revealed icon inside
    // it — no standalone copy action anywhere.
    const pathCopies = Array.from(document.querySelectorAll('.mrfw-pathCopy'))
    expect(pathCopies.length).toBe(3)
    expect(pathCopies[0]?.textContent).toContain('/repos/primary')
    expect(pathCopies[1]?.textContent).toContain('/repos/payments')
    expect(pathCopies[1]?.querySelector('.mrfw-pathCopyIcon')).toBeTruthy()

    // The Add row selector defaults to read-write; choosing read-only goes into
    // the same `add` request the path does. The picker is the host's anchored
    // Menu — a trigger named by its aria-label, rows named by their text.
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.accessLabel` }))
    fireEvent.click(screen.getByRole('button', { name: `${NS}.access.readOnly` }))
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.add` }))
    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'add')).toBe(true) })
    expect(harness.calls.find(call => call.endpoint === 'add')?.payload).toEqual({
      sessionId: 'session-1',
      path: '/repos/picked',
      access: 'read-only',
    })
  })

  it('keeps combined root permissions and tool caps without the introductory permission copy', async () => {
    const harness = mount()
    harness.setView({ primaryRoot: '/repos/primary', mode: 'danger-full-access', cappedTools: ['bash'],
      roots: [{ ...ROOT_A, access: 'inherit', effectiveAccess: 'full-access' }], limit: 16, count: 1 })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await screen.findByText('/repos/payments')
    expect(screen.queryByText(/panel.subtitle|panel.mode|mode.danger-full-access/)).toBeNull()
    expect(document.querySelector('.mrfw-accessBadge')?.textContent)
      .toBe(`${NS}.access.inherit（${NS}.effective.full-access）`)
    expect(screen.getByText(/panel.toolCaps/)).toBeTruthy()
  })

  it('keeps the re-register route open at the root limit, and it sends no access', async () => {
    const harness = mount()
    // count >= limit: a full store, one of whose records is withheld.
    harness.setView({ primaryRoot: '/repos/primary', roots: [ROOT_A, ROOT_B], limit: 2, count: 2 })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/website')).toBeTruthy() })

    // Every NEW-add control stays refused at the limit (the picker button even
    // relabels itself to explain the refusal)…
    expect(screen.getByRole('button', { name: `${NS}.panel.limitReached` })).toHaveProperty('disabled', true)
    expect(screen.getByPlaceholderText(`${NS}.panel.addManual`)).toHaveProperty('disabled', true)
    expect(screen.getByRole('button', { name: `${NS}.panel.addConfirm` })).toHaveProperty('disabled', true)

    // …but a withheld row keeps its re-register action: a revive consumes no
    // slot and the host accepts it at or above the limit. The request names
    // the stored path and NO access, so the record's level is preserved
    // (ROOT_B is read-only) instead of silently widened.
    const reRegister = screen.getByRole('button', { name: `${NS}.panel.reRegister` })
    expect(reRegister).toHaveProperty('disabled', false)
    fireEvent.click(reRegister)
    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'add')).toBe(true) })
    expect(harness.calls.find(call => call.endpoint === 'add')?.payload).toEqual({
      sessionId: 'session-1',
      path: '/repos/website',
    })
  })

  it('flips a root to read-only without asking, and renders the host answer', async () => {
    const harness = mount()
    const confirm = vi.spyOn(window, 'confirm')
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })

    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.more` })[0]!)
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.accessReadOnly` }))
    // A downgrade widens nothing, so it never confirms — not even the modal.
    expect(confirm).not.toHaveBeenCalled()
    expect(screen.queryByRole('dialog', { name: `${NS}.panel.accessUpgradeTitle` })).toBeNull()
    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'setAccess')).toBe(true) })
    expect(harness.calls.find(call => call.endpoint === 'setAccess')?.payload).toEqual({
      sessionId: 'session-1',
      entry: { ordinal: 1, id: 'a', path: '/repos/payments', addedAt: '2026-09-12T00:00:00.000Z' },
      access: 'read-only',
    })
  })

  it('confirms an upgrade to read-write and paints the host-returned view only', async () => {
    const harness = mount()
    const confirm = vi.spyOn(window, 'confirm')
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/website')).toBeTruthy() })

    // ROOT_B is read-only: upgrading it is a grant, so it asks first — in a
    // dialog layered on this one, never through window.confirm.
    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.more` })[1]!)
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.accessReadWrite` }))
    expect(confirm).not.toHaveBeenCalled()
    const upgradeDialog = screen.getByRole('dialog', { name: `${NS}.panel.accessUpgradeTitle` })
    expect(upgradeDialog).toBeTruthy()
    // Cancelled: the layer closes and no channel call at all.
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.aliasCancel` }))
    await waitFor(() => { expect(screen.queryByRole('dialog', { name: `${NS}.panel.accessUpgradeTitle` })).toBeNull() })
    expect(harness.calls.some(call => call.endpoint === 'setAccess')).toBe(false)

    // The host answers a view where B is now writable; the panel must paint
    // THAT answer, not an optimistic local flip.
    const upgradedB: RootView = { ...ROOT_B, access: 'read-write', state: 'available' }
    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.more` })[1]!)
    harness.setView({ primaryRoot: '/repos/primary', roots: [ROOT_A, upgradedB], limit: 16, count: 2 })
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.accessReadWrite` }))
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.accessUpgradeDo` }))
    await waitFor(() => { expect(harness.calls.some(call => call.endpoint === 'setAccess')).toBe(true) })
    expect(harness.calls.find(call => call.endpoint === 'setAccess')?.payload).toEqual({
      sessionId: 'session-1',
      entry: { ordinal: 2, id: 'b', path: '/repos/website', addedAt: '2026-09-12T00:00:00.000Z' },
      access: 'read-write',
    })
    await waitFor(() => {
      expect(Array.from(document.querySelectorAll('.mrfw-accessBadge')).map(node => node.textContent))
        .toEqual([`${NS}.access.readWrite`, `${NS}.access.readWrite`])
    })
  })

  it('confirms fixed read-write changing to Full-access inheritance before sending the mutation', async () => {
    const harness = mount()
    harness.setView({ primaryRoot: '/repos/primary', mode: 'danger-full-access', roots: [ROOT_A], limit: 16, count: 1 })
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/payments')).toBeTruthy() })
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.more` }))
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.accessInherit` }))
    expect(screen.getByRole('dialog', { name: `${NS}.panel.accessUpgradeTitle` })).toBeTruthy()
    expect(harness.calls.some(call => call.endpoint === 'setAccess')).toBe(false)
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.accessUpgradeDo` }))
    await waitFor(() => { expect(harness.calls.find(call => call.endpoint === 'setAccess')?.payload.access).toBe('inherit') })
  })

  it('localizes a refused upgrade instead of flipping the badge', async () => {
    const harness = mount()
    renderPanel(harness)
    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByText('/repos/website')).toBeTruthy() })

    fireEvent.click(screen.getAllByRole('button', { name: `${NS}.panel.more` })[1]!)
    harness.setFailure({ code: 'root-unavailable', message: 'host prose' })
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.accessReadWrite` }))
    fireEvent.click(screen.getByRole('button', { name: `${NS}.panel.accessUpgradeDo` }))

    await waitFor(() => { expect(screen.getByRole('alert').textContent).toBe(`${NS}.error.root-unavailable`) })
    // The badge still says what the last host view said.
    expect(document.querySelectorAll('.mrfw-accessBadge')[1]?.textContent).toBe(`${NS}.access.readOnly`)
  })

  it('renders a working entry without any panel client (no Connection in this surface)', async () => {
    const registrations: Registration[] = []
    const ctx = {
      effect: (callback: () => unknown) => { callback(); return () => {} },
      locale: { register: () => () => {}, bind: () => (key: string) => key },
      slots: {
        inject: (_name: string, callback: () => unknown) => { callback(); return () => {} },
        register: (options: Registration['options'], component: () => unknown) => {
          registrations.push({ options, component })
          return () => {}
        },
      },
      get: () => undefined,
    }
    client.apply(ctx as never)
    const footer = registrations.find(item => item.options.name === 'sidebar.footer.action')!
    render(createElement(footer.component as never))

    fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
    await waitFor(() => { expect(screen.getByRole('alert')).toBeTruthy() })
  })
})

describe('the panel copy', () => {
  it('keeps the shipped Chinese copy in the source of truth for the bundle', () => {
    // The dictionaries live in the host-visible source tree so both the spec and
    // the bundle read one definition.
    const source = readFileSync(join(REPO_ROOT, 'src/client/locales.ts'), 'utf8')
    expect(source).toContain(zh['panel.title'])
    expect(source).toContain(en['panel.title'])
    expect(Object.keys(zh).length).toBeGreaterThan(20)
  })
})

it.each([
  ['/repos/primary', '/repos/primary', 'primary'],
  ['/repos/primary/src/nested', '/repos/primary', 'primary'],
  ['/repos/payments', '/repos/payments', 'payments'],
  ['/repos/payments/src/nested', '/repos/payments', 'payments'],
  ['/repos/payments-other', undefined, undefined],
  ['/unregistered/current', undefined, undefined],
  [undefined, undefined, undefined],
])('tags the listed root containing the Agent cwd %s', async (effectiveCwd, expectedPath, expectedName) => {
  const harness = mount()
  harness.setView({ primaryRoot: '/repos/primary', ...(effectiveCwd === undefined ? {} : { effectiveCwd }), roots: [ROOT_A], limit: 16, count: 1 })
  renderPanel(harness)
  fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
  await waitFor(() => { expect(screen.getByText('/repos/primary')).toBeDefined() })
  const tag = screen.queryByText(`${NS}.panel.currentAgentCwd`)
  if (expectedPath === undefined) {
    expect(tag).toBeNull()
  } else {
    expect(tag?.closest('.mrfw-rootText')?.querySelector('.mrfw-rootNameText')?.textContent).toBe(expectedName)
    expect(tag?.closest('.mrfw-rootText')?.querySelector('.mrfw-rootPath')?.textContent).toBe(expectedPath)
    expect(document.querySelectorAll('.mrfw-cwdTag')).toHaveLength(1)
  }
  expect(screen.queryByText(`${NS}.panel.cwdNote`)).toBeNull()
  expect(harness.calls[0]?.payload).toEqual({ sessionId: 'session-1' })
  fireEvent.click(screen.getByTitle('/repos/primary'))
  await waitFor(() => { expect(navigator.clipboard.writeText).toHaveBeenCalledWith('/repos/primary') })
})

it('matches Windows cwd paths with mixed separators and casing', async () => {
  const harness = mount()
  harness.setView({ primaryRoot: 'C:/repos/primary', effectiveCwd: 'd:/REPOS/payments/src/',
    roots: [{ ...ROOT_A, path: 'D:\\repos\\payments' }], limit: 16, count: 1 })
  renderPanel(harness)
  fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
  const tag = await screen.findByText(`${NS}.panel.currentAgentCwd`)
  expect(tag.closest('.mrfw-rootName')?.textContent).toContain('payments')
})

it('ignores a response belonging to the previous session after catalog selection changes', async () => {
  const harness = mount()
  harness.holdNextCall()
  renderPanel(harness)
  fireEvent.click(screen.getByRole('button', { name: /action.label/ }))
  await waitFor(() => { expect(harness.calls).toHaveLength(1) })
  harness.setView({ primaryRoot: '/repos/second', effectiveCwd: '/repos/second/src', roots: [], limit: 16, count: 0 })
  act(() => { harness.setSession('session-2') })
  await waitFor(() => { expect(screen.getByText('/repos/second')).toBeDefined() })
  harness.release()
  await waitFor(() => { expect(harness.calls).toHaveLength(2) })
  expect(screen.queryByText('/repos/primary')).toBeNull()
  expect(harness.calls[1]?.payload).toEqual({ sessionId: 'session-2' })
})
