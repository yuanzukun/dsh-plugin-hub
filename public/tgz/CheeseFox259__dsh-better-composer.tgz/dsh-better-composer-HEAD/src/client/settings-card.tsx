import { useState, useSyncExternalStore } from 'react'
import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type {} from '@deepseek-ai/dsh-client-ui-settings-plugins/client'
import type { BetterComposerSettings } from '../settings.ts'
import type { BetterComposerSettingsStore } from './settings-store.ts'

/** Business face injected into the keyed Settings slot. */
export interface BetterComposerSettingsCardInjected {
  settings: BetterComposerSettingsStore
}

/** Settings card props: the injected settings face only. */
export type BetterComposerSettingsCardProps = InjectFace<BetterComposerSettingsCardInjected>

/**
 * Render the Better Composer preference controls.
 * @param props - keyed slot props and the caller-owned Settings store.
 * @returns the Settings card.
 */
export function BetterComposerSettingsCard({ settings }: BetterComposerSettingsCardProps) {
  const current = useSyncExternalStore(
    listener => settings.subscribe(listener),
    () => settings.get(),
    () => settings.get(),
  )
  const [failure, setFailure] = useState(false)

  const update = <K extends keyof BetterComposerSettings>(field: K, value: BetterComposerSettings[K]): void => {
    setFailure(false)
    void settings.set(field, value).catch(() => { setFailure(true) })
  }

  return (
    <div className="dsh-better-composer-settings-card">
      <section aria-label="Better Composer 设置">
        <div className="dsh-better-composer-settings-header">
          <h3>Better Composer 设置</h3>
          <p>在 DSH 输入框中提供 Markdown 编辑增强。</p>
        </div>
        <div className="dsh-better-composer-settings-fields">
          <label className="dsh-better-composer-settings-row">
            <span className="dsh-better-composer-settings-copy">
              <strong>启用 Better Composer</strong>
              <small>关闭后保留原生 Composer。</small>
            </span>
            <input aria-label="启用 Better Composer" type="checkbox" checked={current.enabled}
              onChange={event => { update('enabled', event.target.checked) }} />
          </label>
          <label className="dsh-better-composer-settings-row">
            <span className="dsh-better-composer-settings-copy">
              <strong>Markdown 视觉增强</strong>
              <small>突出 Markdown 结构，不会修改实际发送给 Agent 的文本。</small>
            </span>
            <input aria-label="Markdown 视觉增强" type="checkbox" checked={current.markdownVisual}
              onChange={event => { update('markdownVisual', event.target.checked) }} />
          </label>
          <label className="dsh-better-composer-settings-row">
            <span className="dsh-better-composer-settings-copy">
              <strong>非焦点行语法标记</strong>
              <small>光标离开后，Markdown 语法符号的显示方式。</small>
            </span>
            <select aria-label="非焦点行语法标记" value={current.inactiveMarkerDisplay}
              onChange={event => { update('inactiveMarkerDisplay', event.currentTarget.value as BetterComposerSettings['inactiveMarkerDisplay']) }}>
              <option value="hide">完全隐藏（只留渲染效果）</option>
              <option value="fade">淡化显示</option>
            </select>
          </label>
          <label className="dsh-better-composer-settings-row">
            <span className="dsh-better-composer-settings-copy">
              <strong>超长粘贴转引用</strong>
              <small>粘贴超过该字符数时自动转为可点击编辑的引用；0 表示关闭。</small>
            </span>
            <input aria-label="超长粘贴转引用阈值" type="number" min={0} step={100} value={current.pasteClipThreshold}
              onChange={event => { update('pasteClipThreshold', Math.max(0, Math.floor(Number(event.currentTarget.value) || 0))) }} />
          </label>
        </div>
        {failure ? <p className="dsh-better-composer-settings-failure" role="status">设置保存失败，请重试。</p> : null}
      </section>
    </div>
  )
}
