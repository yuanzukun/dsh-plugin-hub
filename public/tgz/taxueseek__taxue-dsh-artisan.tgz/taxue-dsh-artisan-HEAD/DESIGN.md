# taxue-dsh-artisan 设计说明

一体化视觉创作工具链的设计与实现记录。

整合来源：

- 原反推提示词插件（提示词反推 / 优化 / 审计，纯函数）。
- 第三方多供应商生图插件（Google / OpenAI / Seedream / Grok）。

## 问题重定义

原始状态是两个互不协作的插件并存：一个只产提示词、一个只生图，模型需手动搬运 `meta_prompt` 到 `prompt`，中间缺少统一的组装层，且两份插件各自维护一套设置/凭证体系。

用 MECE 拆解「视觉创作」为互斥又穷尽的阶段：

1. **想清楚**：反推 / 提炼视觉意图（`reverse_prompt`）。
2. **改到位**：审计并收敛提示词（`optimize_prompt`）。
3. **画出来**：交给生成器落地为图（`generate_image`）。

三个工具互相独立（可单调），又天然可串联（1→2→3），无重叠、无遗漏。

### 2026-08 直出改造（重新定义「反推工具的角色」）

实测发现原「任务包外包」形态与 DSH 单模型环境脱节：模型自己就能看图（`read_image`/`modlens_read_image`），不需要「把任务外包给下游多模态模型」的中间层，于是 `reverse_prompt` 被模型绕开，绑定其上的参考图预览也不触发。

第一性原理：DSH 里模型就是唯一的视觉理解执行者，工具的价值不是「再外包一层」，而是「把模型的观察结构化、补强、给出可直接落地的产物」。因此：

- `reverse_prompt` 从「编译任务包」改为**直出可生图提示词**：`prompt` + `optimization_advice` + `aspect_ratio` + `variant_guidance`。
- 参考图显示不再依赖工具结果 content（那是错的），改为从**调用参数** `reference_assets[].uri` 提取，经同源文件路由（`ARTISAN_FILE_IMAGE_ROUTE`）加载预览。
- `generate_image` 新增 `reference_assets` 参数，结果卡片并排显示参考图与生成图对比。
- 修复后台生图（`run_in_background`）的展示断点：结果无 attachment 时不再卡在「正在生成图片…」，改为显示后台任务状态。

### 2026-08 订阅优先生图（有订阅走订阅，无订阅走 API）

用户实际用订阅生图（dsh-plugin-subscriptions 的 Grok OAuth 登录），而 `generate_image` 原先只用 API Key，缺 key 直接报错、与订阅脱节。

- 新增 `src/subscription.ts`：读取 subscriptions 保存的 `~/.dsh/plugins/subscriptions/auth.json`，返回未过期的 Grok 订阅 accessToken。
- `resolveImageCredential`：provider=grok 且有订阅 → 订阅优先；其他 provider 无 API Key 但有 Grok 订阅 → 自动重定向到 Grok 订阅；否则 API Key 兜底。
- `generate_image` 声明 `timeoutMs: 180000`，覆盖 Grok 订阅约 30-90 秒出图耗时，避免同步等待被 DSH 工具超时掐断。
- 新增「保存文件夹」设置（`saveDir`）：生成图落盘到可配置目录，留空用默认 `~/Downloads/`，便于追溯；落盘失败不阻断出图。

### 2026-08 订阅出图实测修正（有订阅就能出图，但需分模型、走代理）

此前设计假设「Grok 订阅不开放出图端点」，属误判。实测（2026-08-20，SuperGrok OAuth token）：

- `POST /v1/responses`（对话）→ 200；`POST /v1/images/generations`（出图）→ `grok-imagine-image` 200 约 7 秒、`grok-imagine-image-2.0` 200 约 57 秒。**订阅 token 对出图端点有效**，Hermes Agent 文档也确认 OAuth 覆盖 TTS/图/视频/转写。
- 早前「挂起」是只等了 20 秒没等够 2.0 的 57 秒，以及 DSH 环境依赖系统代理（api.x.ai 需走 HTTP_PROXY/HTTPS_PROXY，node fetch 靠 `NODE_USE_ENV_PROXY` 走代理）。
- 因此：凭证路由保持「订阅优先」不变；`generateOpenAICompatibleImage` 把网络层 `fetch failed` 包装为带排查提示（代理/端点/凭证）的错误，替代笼统报错。

### 2026-08 视觉还原锚点（量身为本插件定做）

反推还原度不足的第一性原理：**模型看图没有方法论约束**，观察全凭自觉。按本插件「模型是视觉理解执行者 + reverse_prompt 是直出编译器」的形态，提炼 9 个可量化还原锚点，注入最终提示词，供下游生图模型逐条复现（画幅/气质/风格/表面层/构图/光色材质/主体/文字/负向）。

- `reverse_prompt` 新增 `image_width` / `image_height`：模型 `read_image` 后把返回的真实像素宽高填入，插件按真实比例换算最接近的标准画幅（含 Grok 扩展比例），并在提示词第一句写死真实比例——解决「截图原图比例靠文本猜、还原失真」。
- 比例换算用「射线夹角」量化偏差（`atan2`），比简单除法对极端比例更稳；像素优先，文本启发式只作后备。
- 方法论注入只作用于图像反推（`mode=image_reverse` 或 `target=image`）；视频反推仍走平台分层规范，不注入图像锚点。

### 2026-08 图控图、确定性色卡与审计强化

三个能力缺口一次补齐：

1. **可选图控图**（`use_reference_images`，默认 false）：原先参考图只用于前端对比预览，从不参与生成，「照着还原」全靠文字描述。现显式开启时把本地 PNG/JPEG/WebP 参考图内联编码进生图请求：Gemini 走 Interactions API 的 `input_image` 内容块；OpenAI/Seedream/codex 走 data URL 数组 `image` 字段；Grok Imagine 走 `image_url` 字段。默认行为不变。
2. **确定性色卡提取**（新工具 `extract_palette`）：配色描述此前全凭模型目测。新模块 `palette.ts` 零依赖实现 PNG 解码 + Oklab K-Means（无随机种子、最远点播种、固定 14 轮迭代、近簇合并两轮），输出主/辅/点缀色 hex 与占比、暗部/高光锚点色；hex 取「离簇心最近的真实采样像素」保证颜色真实出现过。语义理解交给反推模型，像素统计交给本地确定性算法。
3. **审计硬冲突与变体纪律**：`optimize_prompt` 新增三组成对互斥检测（平涂硬边阴影 vs 大面积连续柔光、复古手绘 vs 现代数字渲染、洁净表面 vs 扫描颗粒）；`variant_guidance` 注入变体纪律（锁定全部风格维度，只换 2-4 个非风格维度，幅度 20%-40%）；优化建议补上缺失的光照维度。

配套修复：llmPolish 重组器增加画幅锚点保护（system 指令要求原样保留首句画幅，结果缺失时自动回填），消除「润色丢画幅」的正确性隐患；落盘生成图时同步写提示词 sidecar JSON（prompt/provider/model/时间戳），收藏即溯源。

### 2026-09 技能桥（重新定义「技能的接入方式」）

**原问题**：「让插件配合技能，还是把技能能力吸纳进插件？」

**重新定义后**：这不是二选一。先拆清两件事——技能由三类性质完全不同的东西组成，DSH 侧现状也各不相同：

| 技能组成 | 性质 | DSH 现状 |
|---|---|---|
| 提示词资产（5 类元模板、坑库、方法论） | 知识，360 KB | 完全缺失 |
| 确定性脚本（填槽 / 预检 / 验收 / 去水印） | 代码，35 个 py | 完全缺失 |
| WorkBuddy 运行时绑定（积分、ImageGen、show_widget） | 平台耦合 | 已由 `dsh-workbuddy-image` 承担（同源混元，阈值可直接沿用） |

按能力单元做 MECE 拆解后，载体选择只落在「高频 × 确定性 × 上下文敏感」的交集上：

| 能力单元 | 频率 | 载体 | 理由 |
|---|---|---|---|
| 类型路由与槽位清单 | 高 | 工具 `artisan_plan` | 返回 <1 KB，省去读 SKILL.md |
| 机械填槽组装 | 高 | 工具 `artisan_compose` | 高频纯计算 |
| 出图前静态预检 | 高 | 工具 `artisan_preflight` | 纯正则，且类型 D 与手写场景需要独立入口 |
| 出图后验收 | 高 | 工具 `artisan_check` | 复用已有 PNG 解码基建 |
| 模板正文 / 坑库 / 方法论 | 低 | 不内化，按需读技能文件 | 知识资产，进 TS 无收益 |
| 去水印族（8 版算法） | 低 | 不内化，子进程调用 | 三十余轮实测调优，重写即丢弃实测依据 |

**关键取舍一：子进程调用而非 TS 重写。** 重写会丢弃实测依据，并从第一天起与技能漂移（技能仍在活跃迭代，v1.22.2 发布次日接入）。桥层只做「调用 + 透传」：脚本输出本就是为 Agent 设计的文本，原样交给模型比结构化解析更稳，脚本升级也不会让解析器碎掉。代价是每次调用约 300ms 进程启动开销，而出图本身 5-60 秒，占比不到 1%。

**关键取舍二：零复制，只读引用。** 槽位清单、模板正文、验收阈值全部从技能目录实时读取，插件侧唯一保留的重复常量是类型路由索引（判断逻辑而非知识资产，且从 markdown 表格解析反而更脆），已在代码注释标注对齐来源。

**关键取舍三：不静默降级。** 技能目录缺失时工具明确报错并指向设置页；桥层只接受四个白名单脚本，不接受任意命令，避免变成通用命令执行入口。

**量化**（`pnpm measure:tools`，只统计真正进上下文的三部分）：

| 指标 | 改造前 | 改造后 |
|---|---|---|
| 工具面常驻（4 工具） | 13,052 B | 10,483 B（-20%） |
| 工具面常驻（8 工具） | — | 15,283 B |
| 单次生图任务上下文 | 读 SKILL.md（30 KB）+ 读模板（32 KB）+ 多轮往返 | 3 次工具调用，返回合计约 5.5 KB |

常驻成本净增 2,231 B，换来单次任务上下文降约 60-80%，这笔账在生图高频场景成立。

## 架构决策

### 命名
`taxue-dsh-artisan`（taxue 画师）。沿用 `dsh-` 生态惯例，`taxue` 标识自研归属。

### 工具形态（用户决策：灵活组装）
保留四个原生工具而非单一「一键出图」工具，让模型/用户可决定走几步。`generate_image` 也可独立使用（不强制前置反推）。

### 供应商（用户决策：三供应商 + Grok）
在 Google / OpenAI / Seedream 基础上新增 xAI Grok。Grok 走已存在的 OpenAI 兼容适配器，但参数路径独立（见下）。

### 炭笔桥（用户决策：保留开关默认关闭）
`dynamic_charcoal_mode` 布尔开关保留，默认 false，不默认注入炭笔规则，避免把风格先验强加给所有任务。

## Code Review 结论

### 最大瓶颈（Token / 上下文占用）
`compile_visual_prompt_task`（原 forge 主工具）单次调用会把约 3.9 KB 的 `meta_prompt` + `output_contract` 注入对话上下文，其中：
- 默认双语导致英文元提示词整段冗余；
- 输出合同对单媒介任务带了无关字段（如图像任务也含 `shot_plan`）。

这是「日常上下文占用与 token 消耗」的最大来源。

### 修复的低级 bug / 隐患

1. **Grok 参数不兼容（本次新引入，已修）**：xAI `/images/generations` 不支持 `size`/`quality`/`style`，只支持 `aspect_ratio`、`resolution`。若按通用 OpenAI 路径带 `size` 会收到 400。已在 `generateOpenAICompatible.ts` 为 grok 分支单独组装请求体。

2. **输出合同冗余（原 forge）**：`outputContract` 在图像任务仍携带 `shot_plan` 字段；已按 `target`/`mode` 精确裁剪。

3. **默认双语冗余（原 forge）**：`output_language` 默认 `bilingual`；已改为默认 `zh-CN`，多语言变体为显式选项。

4. **工具结果渲染灌流（原 forge）**：`compile_visual_prompt_task` 的 render 会把任务包摘要给出，但 `meta_prompt` 本体作为结构化字段返回仍占输出 token。保留「摘要渲染 + 字段返回」设计，但通过单语言与契约裁剪压缩体积。

### 保留的既有优点
- 生图适配器的**字节预算**（`maxBytes` 封顶）、**32 位边界校验**、**临时 URL 立即下载**、**凭证写保护**——这些设计质量高，原样保留。

## 验证

- `pnpm run typecheck`：`tsc --noEmit` 无错误。
- `pnpm run test`：`tests/smoke.mjs` 覆盖直出反推、画幅推断、优化建议、视频反推+炭笔、优化、审计、空输入抛错；`tests/skill-bridge.mjs` 覆盖技能探测、缺技能的错误路径、四个桥工具的 execute 契约与 schema 合法性（技能缺席时端到端部分自动跳过，保持可移植）。全部通过。
- `pnpm run measure:tools`：输出工具面常驻上下文体积，防止 schema 无声膨胀。
- 接入 web profile 后 `dsh web` 正常 boot，`POST /plugins/taxue-dsh-artisan/file-image` 对 `.dsh-filess` 参考图返回 200（JPEG 900×1200），`POST /plugins/taxue-dsh-artisan/image` 返回 400 `invalid-attachment`（host bundle 已加载、路由已注册）。
- 端到端：新会话反推「大雪.jpg」，模型主动调用 `reverse_prompt` 一次即直出完整提示词（还原文字排版/材质/配色/印章细节）+ 画幅建议 9:16 + 七维拆解，链路从 8-24 步降到 2-3 步。

## 已知边界（2026-08 验证）

- 参考图在工具卡片的预览依赖模型在调用 `reverse_prompt`/`generate_image` 时传入 `reference_assets` 路径；模型偶尔绕开工具自行反推（此时参考图预览不触发，但直出质量仍可用）。已在工具描述中强化引导。
- `generate_image` 需要配置供应商 API Key（`GEMINI_API_KEY`/`OPENAI_API_KEY`/`ARK_API_KEY`/`XAI_API_KEY`）；未配置时模型会回退到订阅生图。
- 用户消息中的 `.dsh-filess` 图片路径由 dsh-files 以文件引用形式进入对话，DSH 原生不渲染图片预览；如需在消息层显示，属 dsh-files/DSH 层能力，不在本插件范围。

### 技能桥附加边界（2026-09）

- 桥工具依赖本地 taxue-imagegen 技能目录与可用的 Python（含 numpy / PIL / opencv）。两者缺一即报错并指向设置页，不静默降级；不装技能的用户不受影响，四个原生工具照常工作。
- 验收阈值标定在 hunyuan-image 上。经 `dsh-workbuddy-image` 走 WorkBuddy 混元出图时阈值可直接沿用；换用 Gemini / GPT / Seedream / Grok 出图时，阈值需按技能 `scripts/calibrate_thresholds.py` 重标，不要直接沿用数字。
- 技能脚本每次调用约 300ms 进程启动开销；出图本身 5-60 秒，占比可忽略，但批量验收多张图时会累积。
- 技能在活跃迭代中（v1.22.2 起接入）。桥层原样透传脚本输出，因此技能升级不需要同步改插件；但脚本 CLI 契约（参数名、退出码语义）变化会影响桥层，升级后应跑一次 `pnpm test`。

## 客户端契约

浏览器端 `lib/client.js` 按 DSH `dsh-client-modules` 契约产出：

```js
window.__ModuleLoader__.load({
  id: "taxue-dsh-artisan",
  factory: (require) => { /* ... */ return module.exports; },
});
```

注入 `settings.plugin.item`（taxue 画师设置卡）与 `tool.call.toolview`（生成图结果卡）。
