/** taxue-dsh-artisan：提示词反推/优化 + 多供应商生图的一体化 DSH 工具链。 */
import { mkdir as fsMkdir, readFile as fsReadFile, writeFile as fsWriteFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join as pathJoin } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import { credentialRef } from '@deepseek-ai/dsh-credentials'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { defineTool, type ToolResult } from '@deepseek-ai/dsh-tools'
import { ARTISAN_PROVIDERS, ArtisanConfig, ASPECT_RATIOS, GOOGLE_ASPECT_RATIOS, resolveProvider, type ArtisanProvider, type AspectRatio, type ImageSize } from './config.js'
import { registerBridgeTools } from './bridge-tools.js'
import { PLATFORMS, REVERSE_MODES, TARGETS, optimizePrompt, reversePrompt, type ReversePromptInput, type ReversePromptOutput } from './compiler.js'
import { generateGoogleImage } from './google.js'
import { ARTISAN_FILE_IMAGE_ROUTE, ARTISAN_IMAGE_ROUTE, imageAttachmentFromMeta, serveFileImage, serveImage, MAX_FILE_BYTES } from './image-route.js'
import { generateCodexImage, generateOpenAICompatibleImage } from './openai-compatible.js'
import { registerNativeTools } from './native-tools.js'
import { resetBridgeCache, type BridgeOptions } from './skill-bridge.js'
import { resolveCodexSubscriptionToken, resolveGrokSubscriptionToken } from './subscription.js'
import { decodePng, extractPalette } from './palette.js'
import { loadInlineReferences, SUPPORTED_REFERENCE_EXTS } from './references.js'
import { ARTISAN_SETTINGS_NAMESPACE } from './shared.js'

export { ArtisanConfig, ArtisanConfig as Config } from './config.js'
export { ARTISAN_FILE_IMAGE_ROUTE, ARTISAN_IMAGE_ROUTE, imageAttachmentFromMeta } from './image-route.js'
export { optimizePrompt, reversePrompt } from './compiler.js'
export type { ReversePromptInput, ReversePromptOutput } from './compiler.js'

/** Cordis 插件名。 */
export const name = 'taxue-dsh-artisan'
/** 主机端所需服务。llm 是 harness 核心必需（agent 运行时必有，反推重组器默认走它）；jobs 用于异步后台生图，可选（无则后台生图报错、同步仍可用，走 ctx.get 判空）。 */
export const inject = ['tools', 'attachments', 'credentials', 'webServer', 'llm'] as const

interface GeneratedValue {
  attachment: ImageAttachmentRef
  provider: ArtisanProvider
  model: string
  output: string
  savedPath?: string
}

/** 环境能力探测结果：识别 DSH 里是否挂了订阅/第三方生图能力（如 dsh-plugin-subscriptions 注册的 grok/codex）。 */
interface CapabilityProbe {
  /** 通过 llm 服务注册的供应商名（grok/codex/claude 等）。 */
  registeredProviders: string[]
  /** 是否存在可用作订阅生图的 provider。 */
  hasSubscriptionImageProvider: boolean
}

/** 订阅插件注册的供应商名，凡出现即视为「环境具备订阅生图能力」。 */
const SUBSCRIPTION_PROVIDERS: ReadonlySet<string> = new Set(['grok', 'codex', 'claude'])

/** 探测 DSH 环境能力：零侵入，探测失败静默返回（不阻断主流程）。 */
function probeCapabilities(ctx: Context): CapabilityProbe {
  const registeredProviders: string[] = []
  try {
    const llm = (ctx as { get?: (key: string) => unknown }).get?.('llm') as
      | { listProviders?: () => Iterable<{ id?: unknown; name?: unknown }> }
      | undefined
    if (llm?.listProviders) {
      for (const provider of llm.listProviders()) {
        const id = provider?.id
        if (typeof id === 'string' && id.length > 0) registeredProviders.push(id)
      }
    }
  } catch {
    // 探测失败不阻断主流程。
  }
  const hasSubscriptionImageProvider = registeredProviders.some((provider) => SUBSCRIPTION_PROVIDERS.has(provider))
  return { registeredProviders, hasSubscriptionImageProvider }
}

/** 订阅能力提示，拼到 reverse_prompt 渲染文本里。 */
function capabilityHint(probe: CapabilityProbe): string {
  if (probe.hasSubscriptionImageProvider) {
    const names = probe.registeredProviders.filter((provider) => SUBSCRIPTION_PROVIDERS.has(provider)).join('/')
    return `本 DSH 环境已通过订阅接入 ${names} 供应商生图能力；generate_image 支持 provider 参数：codex=ChatGPT 订阅（gpt-image-2）、grok=Grok 订阅优先/API Key 兜底、其余供应商用 API Key。`
  }
  return '本 DSH 环境暂未检测到订阅生图供应商；如需出图请用 generate_image（需配置 API Key），或先在订阅插件里登录供应商。'
}

/** 生图凭证解析：codex 走 ChatGPT 订阅；grok 订阅优先（含无 API key 时兜底）；否则用 API Key。 */
type ImageCredential =
  | { apiKey: string; source: 'subscription'; provider: 'grok' | 'codex'; accountId?: string }
  | { apiKey: string; source: 'apikey'; provider: ReturnType<typeof resolveProvider>['provider']; accountId?: string }
  | { apiKey: undefined; source: 'missing'; provider: ReturnType<typeof resolveProvider>['provider']; accountId?: string }

async function resolveImageCredential(ctx: Context, active: ReturnType<typeof resolveProvider>): Promise<ImageCredential> {
  // codex 无 API Key：必须走 ChatGPT 订阅，未登录即缺失。
  if (active.provider === 'codex') {
    const session = await resolveCodexSubscriptionToken()
    if (session !== undefined) {
      return { apiKey: session.accessToken, source: 'subscription', provider: 'codex', ...(session.accountId !== undefined ? { accountId: session.accountId } : {}) }
    }
    return { apiKey: undefined, source: 'missing', provider: 'codex' }
  }
  const subToken = await resolveGrokSubscriptionToken()
  const credential = await ctx.credentials.resolve(credentialRef(active.apiKeyEnv))
  const hasApiKey = credential !== undefined && credential.value.length > 0
  // provider=grok 无条件优先订阅；其他 provider 在无 API key 时用 Grok 订阅兜底（自动重定向）。
  if (subToken !== undefined && (active.provider === 'grok' || !hasApiKey)) {
    return { apiKey: subToken, source: 'subscription', provider: 'grok' }
  }
  if (hasApiKey) return { apiKey: credential.value, source: 'apikey', provider: active.provider }
  return { apiKey: undefined, source: 'missing', provider: active.provider }
}

/** 按订阅重定向后的有效 provider profile（订阅时用对应订阅的 model/baseURL）。 */
function effectiveProfile(current: () => ArtisanConfig, active: ReturnType<typeof resolveProvider>, source: ImageCredential['source']): ReturnType<typeof resolveProvider> {
  if (source === 'subscription' && active.provider !== 'grok' && active.provider !== 'codex') {
    return resolveProvider({ ...current(), provider: 'grok' })
  }
  return active
}

/** 凭证缺失时的报错文案（含订阅/API 双通道提示）。capability 由 apply() 探测后传入，避免重复调用 probeCapabilities。 */
function missingCredentialError(active: ReturnType<typeof resolveProvider>, capability: CapabilityProbe): Error {
  if (active.provider === 'codex') {
    return new Error(`generate_image 走 ChatGPT 订阅（codex/gpt-image-2）：请先在 设置 > 插件 > 订阅 里登录 ChatGPT（codex）。`)
  }
  if (active.provider === 'grok') {
    if (capability.hasSubscriptionImageProvider) {
      return new Error(`generate_image 需要 ${active.apiKeyEnv} 或 Grok 订阅：已检测到订阅生图能力，请先在 设置 > 插件 > 订阅 里登录 Grok；或在 设置 > 插件 > taxue 画师 中配置 ${active.apiKeyEnv}。`)
    }
    return new Error(`generate_image 需要 ${active.apiKeyEnv} 凭证；请在 设置 > 插件 > taxue 画师 中配置。`)
  }
  return new Error(`generate_image 需要 ${active.apiKeyEnv} 凭证；请在 设置 > 插件 > taxue 画师 中配置。`)
}

/**
 * LLM 反推重组器（llmPolish 开关，默认开）：把反推模型对参考图的观察描述（brief）
 * 与结构化约束，转译重组为「可直接喂给生图模型的生成指令」——按 6-block 结构化协议
 * 组织、按题材路由选序、去描述语气加生成语气、无元语言、负向用「没有」自然表达。
 * 区别于填空式模板：反推的输入是观察描述，需转译而非填空。任一环节失败回退原 prompt。
 * 画幅锚点保护：重组结果必须保留第一句「画幅比例：…」，缺失时自动回填。
 */
async function polishPromptViaLlm(ctx: Context, input: ReversePromptInput, draft: ReversePromptOutput, config: ArtisanConfig, signal?: AbortSignal): Promise<string | undefined> {
  const llm = (ctx as { get?: (key: string) => unknown }).get?.('llm') as
    | {
        stream(options: { provider: string; model: string; system?: string; messages: unknown[]; maxTokens?: number; signal?: AbortSignal | undefined }): AsyncIterable<{ type: string; text?: string }>
        listProviders(): Array<{ id?: string }>
        listModels(provider: string): Promise<Array<{ id?: string }>>
      }
    | undefined
  if (llm === undefined) return undefined
  try {
    const provider = config.llmPolishProvider || llm.listProviders()[0]?.id
    if (typeof provider !== 'string' || provider.length === 0) return undefined
    const model = config.llmPolishModel || (await llm.listModels(provider))[0]?.id
    if (typeof model !== 'string' || model.length === 0) return undefined
    const aspectSentence = draft.prompt.split('\n')[0] ?? ''
    const hasAspectSentence = /^画幅比例[:：]|^Aspect ratio:/i.test(aspectSentence)
    const system = [
      '你是图像提示词反推重组器。输入是反推模型对参考图的观察描述（brief）与结构化约束。任务：把「观察描述」转译为「可生成提示词」——不是润色、不是背景介绍，是可直接喂给生图模型的生成指令。',
      '转译原则：',
      '1. 去描述语气（「这张图里有」「反推一张」「画面中可以看到」），改生成语气（直接写要生成的画面）。',
      '2. 按 6 个 block 组织，有料才写、无则省略，不写「未观察到」占位：',
      '   - 主体与任务：主体是谁/什么、动作、姿态、方向',
      '   - 构图与版式：空间纵深、前后层次、视觉优先级（第一/第二视觉）、留白、裁切',
      '   - 视觉风格与材质：风格气质、光源方向与色温、投影、主色数量/色值、材质纹理',
      '   - 文字与标注：可见文字内容、字体、排版、字号关系、内边距',
      '   - 画幅与输出：画幅比例',
      '   - 约束与负向：保持/可改/避免用「没有…」「无…」自然表达；气质首尾呼应',
      '3. 题材路由：先判题材（人像/装置/海报/场景/插画/UI/图表…），选 block 顺序与重点——装置类「构图与版式/空间纵深」先行；海报类「文字与标注/版式纪律」加重；人像类「主体与任务」先行。',
      '4. 无元语言：不写「反推/这是/请生成/这是一张」。',
      '5. 信息密度高、每 block 具体可执行、负向克制。',
      ...(hasAspectSentence ? [`6. 硬性要求：输出第一行必须原样保留这一句（不得改写或删除）：${aspectSentence}`] : []),
      '样本风格（学其组织方式，不照抄内容）：',
      '[人像] {主体}：一名女性的侧影，身体向右延伸，头部微抬，长发在脑后散开成一道弧线。',
      '[装置] 一幅多层叠纸的当代剪纸装置。四层纸由前到后依次为：纯黑卡纸、深炭灰、中灰、浅灰。每层独立激光切割，层间约一厘米空隙，固定在透明亚克力支架上，离墙约五厘米浮装。灯光从左上方斜射，投影随光源角度拉长或压缩。全画面只有黑、炭灰、中灰、浅灰、暖白墙五种色值，没有彩色，没有金箔，无文字。',
      '[海报] 一张 5:2 超宽横版的高级概念海报，极简、克制、有展览感的丝网印刷质感。主题词横排于画面中央，颜色与背景强对比，是整张画唯一的主视觉。配色克制、整体不超过四种，深底浅字。整张画除主题词和那行短句外没有任何其他文字、水印、日期或印章。',
      '直接输出重组后的提示词，不要解释、不要分节标题。',
    ].join('\n')
    const material = [
      `题材线索：${input.target}/${input.platform}`,
      `画幅：${draft.aspect_ratio}`,
      `观察描述（brief）：${input.brief}`,
      ...(input.preserve?.length ? [`保持：${input.preserve.join('；')}`] : []),
      ...(input.change?.length ? [`可改：${input.change.join('；')}`] : []),
      ...(input.avoid?.length ? [`避免：${input.avoid.join('；')}`] : []),
      ...(input.dynamic_charcoal_mode ? ['炭笔模式：开启'] : []),
    ].join('\n')
    const chunks: string[] = []
    for await (const chunk of llm.stream({ provider, model, system, messages: [{ role: 'user', content: [{ type: 'text', text: material }] }], maxTokens: 2000, signal })) {
      if (chunk.type === 'text-delta' && typeof chunk.text === 'string') chunks.push(chunk.text)
    }
    const text = chunks.join('').trim()
    if (text.length === 0) return undefined
    // 画幅锚点保护：重组结果丢失第一句画幅时自动回填，保证下游生图画幅不被润色破坏。
    if (hasAspectSentence && !/^画幅比例[:：]|^Aspect ratio:/i.test(text)) return `${aspectSentence}\n\n${text}`
    return text
  } catch {
    return undefined
  }
}

/** 注册设置、图片路由与模型可调用的工具。设置表单由 cordis 原生 Config 约定（configEditor 读 Config 导出）提供。 */
export function apply(ctx: Context, config: ArtisanConfig = {}): void {
  // 设置可能已变更：清技能桥的探测缓存，让 skillRoot/python 重新按当下配置解析。
  resetBridgeCache()
  let current: () => ArtisanConfig = () => config
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact', path: ARTISAN_IMAGE_ROUTE,
    handler: (req, res) => serveImage(req, res, { readImage: ref => ctx.attachments.readImage(ref) }),
  }), 'taxue-dsh-artisan: image route')
  ctx.effect(() => ctx.webServer.register({
    kind: 'exact', path: ARTISAN_FILE_IMAGE_ROUTE,
    handler: (req, res) => serveFileImage(req, res, {
      readFile: async (path) => {
        try { return new Uint8Array(await fsReadFile(path)) } catch { return undefined }
      },
    }),
  }), 'taxue-dsh-artisan: file image route')

  // 环境能力感知：探测 DSH 是否挂了订阅/第三方生图供应商，用于渲染提示。
  const capability = probeCapabilities(ctx)
  const capHint = capabilityHint(capability)

  // ── 工具 1：反推直出可生图提示词（本地纯函数，不调用远程） ──
  ctx.tools.register(defineTool({
    name: 'reverse_prompt',
    description: '反推图像/视频提示词并直出可直接用于生图的完整提示词。调用前必须先按「视觉降级链」看清参考图：①read_image（宿主原生视觉）→②modlens_read_image（桥接）→③两者均不可用时改用 DeepSeek Vision API 兜底（model 用 deepseek-v4-flash-vision-exp，图片 base64 内联进 user 消息；仅支持 JPEG/PNG/GIF/WebP，TIFF/HEIC 需先转格式；单图内联上限 32 MiB、请求体上限 48 MiB；大图会被等比缩到约 800×800 再识别，小字号文字易误读——小字排版以 modlens OCR 为准，走③时把「文字转写可信度受限」写入 risk_flags，且无 attachment 元数据，需用 sips 等本地命令读真实像素宽高）。看清后按「视觉还原锚点」逐条观察：①画幅（必须读 read_image 返回的 width×height 精确换算真实比例，填入 image_width/image_height）；②总体气质（媒介感优先）；③风格判定（闭合线稿+平面固有色+1-2层硬边阴影→赛璐璐/平涂，线稿弱化+大区域连续混色→厚涂，否则写柔和渲染/写实，先证据后定名，禁止编造）；④表面层（扫描颗粒/柔焦/低清/色偏只写作用区域，不得当材质纹理）；⑤构图（景别、主体位置、留白、视角各一句，禁止冲突景别）；⑥光色材质（主光源、冷暖、饱和度、关键材质固有色与反射，如船体木纹/漆面/金属）；⑦主体（≥3项独立锚点一致才写具体IP/角色/品牌，否则「原创或身份未确认」）；⑧文字（可见文字逐字照抄、注明字体/横竖排/对齐）；⑨负向（只留2-5个最可能跑偏风险，原图已有特征不得列入）。必须把参考图文件路径（如 .dsh-filess/<sessionId>/x.jpg，即会话工作区下的相对路径）放入 reference_assets 参数，即使 brief 里已描述，结果卡片才能预览参考图并与生成图对比。本工具基于 brief 编译 prompt（直出提示词，第一句锁定真实画幅比例）、optimization_advice（优化方向）、aspect_ratio（真实画幅建议）与 variant_guidance（同规格同风格新图引导）。拿到后直接用 prompt 字段调用 generate_image 生成，把 prompt 原样作为 generate_image 的 prompt（不要重新组织或删减锚点段、不要改动第一句画幅比例），并把 reference_assets 原样传给 generate_image 做对比预览。',
    parameters: {
      mode: { type: 'string', required: true, enum: [...REVERSE_MODES], description: '工作流：image_reverse / video_reverse / prompt_optimize / meta_prompt。' },
      target: { type: 'string', required: true, enum: [...TARGETS], description: '目标媒介：image / video / both。' },
      platform: { type: 'string', required: true, enum: [...PLATFORMS], description: '目标生成平台；未指定时用 universal。' },
      brief: { type: 'string', required: true, description: '用户目标、观察素材或创意简报。不能为空。' },
      current_prompt: { type: 'string', description: '需要保留、诊断或优化的现有提示词。' },
      reference_assets: { type: 'array', items: { type: 'object', additionalProperties: false, properties: {
        uri: { type: 'string', required: true, description: '参考资产 URI、绝对路径或可访问标识。工具不会上传或读取该资产。' },
        role: { type: 'string', enum: ['content', 'composition', 'color', 'material', 'motion', 'audio', 'mixed'], description: '该资产在反推中的控制角色。' },
        notes: { type: 'string', description: '用户对资产作用、局部细节或限制的补充。' },
        rights: { type: 'string', enum: ['user_owned', 'licensed', 'public_domain', 'unknown'], description: '资产权利状态。' },
      } }, description: '参考资产列表。' },
      image_width: { type: 'number', description: '参考图真实像素宽。read_image 返回的 attachment.width；用于精确还原画幅比例。' },
      image_height: { type: 'number', description: '参考图真实像素高。read_image 返回的 attachment.height；用于精确还原画幅比例。' },
      preserve: { type: 'array', items: { type: 'string' }, description: '必须保持不变的特征。' },
      change: { type: 'array', items: { type: 'string' }, description: '用户允许或要求修改的特征。' },
      avoid: { type: 'array', items: { type: 'string' }, description: '必须避免的特征、失败模式或约束。' },
      output_language: { type: 'string', enum: ['zh-CN', 'en', 'bilingual'], description: '下游模型输出语言。默认 zh-CN。' },
      dynamic_charcoal_mode: { type: 'boolean', description: '启用炭笔动态/墨彩速写语法桥。默认关闭。' },
      skip_polish: { type: 'boolean', description: '跳过 LLM 重组，直接使用本地直出提示词。当 brief 已包含足够细节、无需 LLM 润色时开启以降低延迟。默认 false。' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false, properties: {
          task_id: { type: 'string', required: true },
          task_summary: { type: 'string', required: true },
          prompt: { type: 'string', required: true, description: '直出：可直接用于生图的完整提示词（已还原参考图文字排版、风格与细节）。' },
          optimization_advice: { type: 'array', required: true, items: { type: 'string' }, description: '可执行的优化方向建议。' },
          aspect_ratio: { type: 'string', required: true, description: '参考图推断的画幅建议。' },
          variant_guidance: { type: 'string', required: true, description: '同规格同风格新图引导。' },
          quality_gate: { type: 'array', required: true, items: { type: 'string' } },
          risk_flags: { type: 'array', required: true, items: { type: 'string' } },
          clarification_questions: { type: 'array', required: true, items: { type: 'string' } },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: [
          `提示词已直出：${value.task_id}`,
          value.task_summary,
          `可生图提示词：${value.prompt}`,
          `画幅建议：${value.aspect_ratio}`,
          `优化方向：${value.optimization_advice.join('；')}`,
          `同规格新图引导：${value.variant_guidance}`,
          `风险提示：${value.risk_flags.length} 项；待澄清问题：${value.clarification_questions.length} 项。`,
          '请直接用上面的「可生图提示词」作为 generate_image 的 prompt 生成图片，结果会与参考图并排预览对比。',
          capHint,
        ].join('\n'),
      }],
    },
    async execute(args: unknown, exec?: { signal?: AbortSignal }) {
      const input = args as ReversePromptInput & { skip_polish?: boolean }
      const draft = reversePrompt(input)
      if (config.llmPolish && input.skip_polish !== true) {
        const polished = await polishPromptViaLlm(ctx, input, draft, config, exec?.signal)
        if (polished !== undefined && polished.length > 0) draft.prompt = polished
      }
      return draft
    },
  }))

  // ── 工具 2：审计/优化提示词（本地纯函数） ──
  ctx.tools.register(defineTool({
    name: 'optimize_prompt',
    description: '对候选图像或视频提示词做本地结构审计：标记信息量不足、相机运动冲突、缺失主体动作/构图、直接模仿措辞与 IP 风险，并给出单变量优化建议。不判断审美。支持中英文输出。',
    parameters: {
      target: { type: 'string', required: true, enum: [...TARGETS], description: '用于选择审计规则的目标媒介。' },
      prompt: { type: 'string', required: true, description: '待审计的候选提示词。不能为空。' },
      output_language: { type: 'string', enum: ['zh-CN', 'en', 'bilingual'], description: '审计输出的语言。默认 zh-CN。' },
      dynamic_charcoal_mode: { type: 'boolean', description: '额外检查炭笔、纸张、抓拍与有限墨彩要求。' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false, properties: {
          summary: { type: 'string', required: true },
          warnings: { type: 'array', required: true, items: { type: 'string' } },
          risk_flags: { type: 'array', required: true, items: { type: 'string' } },
          next_single_variable_test: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: [
          value.summary,
          value.warnings.length ? `可执行警示：${value.warnings.join('；')}` : '可执行警示：无。',
          value.risk_flags.length ? `风险提示：${value.risk_flags.join('；')}` : '风险提示：无。',
          `建议下一步：${value.next_single_variable_test}`,
        ].join('\n'),
      }],
    },
    async execute(args: { target: 'image' | 'video' | 'both'; prompt: string; output_language?: 'zh-CN' | 'en' | 'bilingual'; dynamic_charcoal_mode?: boolean }) {
      return optimizePrompt(args)
    },
  }))

  // ── 工具 3：本地确定性色卡提取（零依赖、离线、可复现） ──
  ctx.tools.register(defineTool({
    name: 'extract_palette',
    description: '对本地参考图做确定性色卡提取：本地像素级聚类算法（Oklab K-Means，无随机种子），同一张图永远输出同一个色卡。返回主色/辅色/点缀色的 hex 值与占比、暗部与高光锚点色。用于把「光色锚点」从模型目测升级为像素级精确——反推图像时先调用本工具拿到真实色值，再把 hex 写进 brief 或提示词的配色描述里；禁止凭印象编造色值。仅支持 PNG（8-bit 非隔行）；JPEG/WebP 参考图请先用 sips 等本地命令转 PNG 再调用。',
    parameters: {
      path: { type: 'string', required: true, description: '参考图绝对路径或会话内相对路径（.dsh-filess/...）。必须是 PNG 文件。' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false, properties: {
          dominant: { type: 'string', required: true, description: '主色 hex。' },
          secondary: { type: 'string', required: true, description: '辅色 hex。' },
          accent: { type: 'string', required: true, description: '点缀色 hex。' },
          dark: { type: 'string', description: '暗部锚点色 hex（存在时）。' },
          light: { type: 'string', description: '高光锚点色 hex（存在时）。' },
          swatches: { type: 'array', required: true, items: { type: 'object', additionalProperties: false, properties: {
            hex: { type: 'string', required: true }, share: { type: 'number', required: true }, role: { type: 'string', required: true },
          } }, description: '全部颜色及占比（0-100）。' },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: [
          `确定性色卡已提取：主色 ${value.dominant}，辅色 ${value.secondary}，点缀 ${value.accent}`,
          ...(value.dark !== undefined ? [`暗部锚点：${value.dark}`] : []),
          ...(value.light !== undefined ? [`高光锚点：${value.light}`] : []),
          `全部颜色：${value.swatches.map((swatch) => `${swatch.hex}(${String(swatch.share)}%)`).join('、')}`,
          '请把这些真实色值写进提示词的配色描述（如「主色 #xxxxxx 约占 xx%」），不要凭印象改写色值。',
        ].join('\n'),
      }],
    },
    async execute(args: { path: string }) {
      const data = await fsReadFile(args.path)
      if (data.byteLength > MAX_FILE_BYTES) throw new Error(`图片文件过大（${(data.byteLength / 1024 / 1024).toFixed(1)} MiB），上限 25 MiB`)
      const decoded = decodePng(Buffer.from(data))
      const palette = extractPalette(decoded.pixels, decoded.width)
      return palette
    },
  }))

  // ── 工具 3：多供应商生图 ──
  ctx.tools.register(defineTool({
    name: 'generate_image',
    timeoutMs: config.toolTimeoutMs ?? 180000,
    description: '使用配置的生成供应商生成一张图：Google Gemini、OpenAI、Seedream、Grok 或 ChatGPT 订阅（codex）。当用户要求创建或绘制图像时使用，尤其当 reverse_prompt 已产出直出提示词时，把其 prompt 作为本工具的 prompt（原样传入，不要重新组织或删减锚点段），并把参考图路径原样传入 reference_assets（reverse_prompt 怎么传你就怎么传），生成结果会与参考图并排预览对比。供应商选择：provider 参数可显式指定（google/openai/seedream/grok/codex），缺省用插件配置；凭证路由：codex 走 ChatGPT 订阅（gpt-image-2，需在 设置 > 插件 > 订阅 登录）、grok 走 Grok 订阅优先（无需 API Key）否则 API Key 兜底、其余供应商用 API Key。Grok 出图时效：grok-imagine-image 约 5-15 秒，grok-imagine-image-2.0（默认，质量最高）约 30-60 秒；同步等待接近超时可改用 run_in_background 后台生图。Grok 的 OpenAI 兼容端点不支持 size，用 aspect_ratio（或 image_size 的 resolution）控制画幅；订阅通道出图要求网络可达 api.x.ai / chatgpt.com（走系统代理），失败时先检查代理/网络。成功的图已直接附加到会话，没有本地文件路径；不要调用 read、glob 等工具去定位或校验它。',
    parameters: {
      prompt: { type: 'string', required: true, description: '要生成图像的完整描述。' },
      provider: { type: 'string', enum: [...ARTISAN_PROVIDERS], description: '供应商：google=Gemini（API Key）、openai=OpenAI gpt-image（API Key）、seedream=豆包 Seedream（API Key）、grok=Grok（订阅优先/API Key 兜底）、codex=ChatGPT 订阅 gpt-image-2。缺省用插件配置。' },
      quality: { type: 'string', enum: ['low', 'medium', 'high', 'auto'], description: '渲染质量（仅 codex/ChatGPT 订阅支持；其余供应商忽略）。缺省用供应商默认。' },
      reference_assets: { type: 'array', items: { type: 'string' }, description: '参考图路径列表（如 .dsh-filess/.../x.jpg 或绝对路径）。默认仅用于结果卡片与生成图并排预览对比，不上传。' },
      use_reference_images: { type: 'boolean', description: '把 reference_assets 里的参考图真正传给生图模型做图控图（默认 false：参考图只用于对比预览，不参与生成）。开启后支持还原参考图的构图/色彩/主体；要求路径为本地可读的 PNG/JPEG/WebP 文件。' },
      aspect_ratio: { type: 'string', enum: [...ASPECT_RATIOS], description: '输出画幅。Google 支持 1:1/3:2/2:3/4:3/3:4/16:9/9:16；Grok/Seedream 额外支持 2:1/1:2/19.5:9/9:19.5/20:9/9:20 及 auto。优先使用 reverse_prompt 返回的 aspect_ratio。' },
      image_size: { type: 'string', enum: ['1K', '2K', '4K'], description: 'Google Gemini 的可选输出分辨率；Grok 出图同样支持 1K/2K（resolution）。' },
      size: { type: 'string', description: 'OpenAI / Seedream / codex 的可选尺寸，格式 WxH，如 1024x1024、1024x1536、1536x1024。Grok 不支持该参数（用 aspect_ratio），传入会被忽略。' },
      run_in_background: { type: 'boolean', description: '以后台任务方式生图：立即返回 job id，不阻塞当前对话，可继续做其他操作；图生成后用 job_output 收集，job_kill 可取消。默认 false（同步等待）。Grok 2.0 出图较慢时建议开启。' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false, properties: {
          attachment: { type: 'object', additionalProperties: false, properties: {
            attachmentId: { type: 'string', required: true }, mediaType: { type: 'string', required: true }, bytes: { type: 'integer', required: true }, width: { type: 'integer', required: true }, height: { type: 'integer', required: true }, name: { type: 'string' },
          } },
          kind: { type: 'string', description: 'background 表示后台任务已发起；foreground 表示同步结果。' },
          jobId: { type: 'string', description: '后台任务 id（kind=background 时）。用 job_output 收集结果。' },
          provider: { type: 'string' }, model: { type: 'string' }, output: { type: 'string' }, savedPath: { type: 'string' },
        },
      },
      render: (_args, value) => {
        const text = value.kind === 'background' && value.jobId
          ? `已发起后台生图任务 ${value.jobId}。任务进行期间可继续做其他操作；完成后用 job_output 读取图片结果，job_kill 可取消。`
          : `已用 ${value.provider}/${value.model} 生成一张图（${value.output}）。它已附加到会话且无本地文件路径；直接回应，无需读取或搜索。`
        return [{ type: 'text', text }]
      },
      presentationMeta: (args, value) => {
        const reference = Array.isArray(args?.reference_assets) ? (args.reference_assets as unknown[]).filter((item): item is string => typeof item === 'string') : []
        if (value.kind === 'background' && typeof value.jobId === 'string') {
          return { kind: 'taxue-artisan-background', jobId: value.jobId, reference }
        }
        if (value.attachment !== undefined) {
          return { kind: 'taxue-artisan', attachment: value.attachment, reference }
        }
        return { kind: 'taxue-artisan', jobId: null, reference }
      },
    },
    async execute(args, exec) {
      // 图控图开关：显式开启时才读取本地参考图并内联上传（默认 false，只做对比预览）。
      const inlineReferences = args.use_reference_images === true && Array.isArray(args.reference_assets) && args.reference_assets.length > 0
        ? await loadInlineReferences(args.reference_assets.filter((item): item is string => typeof item === 'string' && item.length > 0))
        : undefined
      if (args.run_in_background === true) {
        // 异步后台生图：立即返回 job id，不阻塞对话。
        const jobs = ctx.get('jobs')
        if (jobs === undefined) throw new Error('后台任务不可用：请确保 @deepseek-ai/dsh-jobs 与 @deepseek-ai/dsh-tool-jobs 已加载。')
        const active = resolveProvider(args.provider !== undefined ? { ...current(), provider: args.provider } : current())
        const imageCred = await resolveImageCredential(ctx, active)
        if (imageCred.apiKey === undefined) throw missingCredentialError(active, capability)
        const eff = effectiveProfile(current, active, imageCred.source)
        const imageLimits = ctx.attachments.imageLimits
        const source = imageCred.source
        const saveDir = current().saveDir
        const jobId = jobs.start({
          kind: 'artisan-image',
          label: args.prompt.slice(0, 60),
          ...(exec.agent ? { owner: exec.agent } : {}),
          run: () => {
            const controller = new AbortController()
            const runPromise = (async () => {
              const generated = await generateOnce({
                provider: eff.provider, model: eff.model,
                ...('endpoint' in eff ? { endpoint: eff.endpoint } : {}),
                ...('baseURL' in eff ? { baseURL: eff.baseURL } : {}),
                prompt: args.prompt,
                ...(args.aspect_ratio !== undefined ? { aspectRatio: args.aspect_ratio } : {}),
                ...(args.image_size !== undefined ? { imageSize: args.image_size } : {}),
                ...(args.size !== undefined ? { size: args.size } : {}),
                ...(args.quality !== undefined ? { quality: args.quality } : {}),
                ...(imageCred.provider === 'codex' && imageCred.accountId !== undefined ? { accountId: imageCred.accountId } : {}),
                ...(inlineReferences !== undefined ? { referenceImages: inlineReferences } : {}),
                maxBytes: imageLimits.maxImageBytes, signal: controller.signal,
                apiKey: imageCred.apiKey, imageLimits,
              })
              const saved = await saveGenerated({ attachments: ctx.attachments }, generated, eff.provider, eff.model, outputLabel(eff, args, source), saveDir, args.prompt)
              return saved
            })()
            return {
              cancel: () => { controller.abort() },
              done: runPromise.then(() => undefined),
              readOutput: () => {
                // 完成后返回图片已附加的说明；job_output 会展示它。
                return runPromise.then((saved) => `图片已生成并附加到会话：provider=${saved.provider}, model=${saved.model}, ${saved.output}。attachment=${saved.attachment.attachmentId}（${saved.attachment.mediaType}，${saved.attachment.bytes} 字节，${saved.attachment.width}×${saved.attachment.height}）。`).catch((cause: unknown) => `后台生图失败：${cause instanceof Error ? cause.message : String(cause)}`)
              },
            }
          },
        })
        return { kind: 'background', jobId: String(jobId) }
      }
      // 同步分支：订阅优先，API 兜底。
      const active = resolveProvider(args.provider !== undefined ? { ...current(), provider: args.provider } : current())
      const imageCred = await resolveImageCredential(ctx, active)
      if (imageCred.apiKey === undefined) throw missingCredentialError(active, capability)
      const eff = effectiveProfile(current, active, imageCred.source)
      const saveDir = current().saveDir
      if (eff.provider === 'google') {
        const requested = args.aspect_ratio ?? eff.aspectRatio
        if (!GOOGLE_ASPECT_RATIOS.includes(requested as (typeof GOOGLE_ASPECT_RATIOS)[number])) {
          throw new Error(`Google Gemini 只支持画幅 ${GOOGLE_ASPECT_RATIOS.join('/')}；你提供的是 ${requested}。Grok/Seedream 的扩展画幅请切换到对应供应商。`)
        }
        const aspectRatio = (args.aspect_ratio ?? eff.aspectRatio) as AspectRatio
        const imageSize = (args.image_size ?? eff.imageSize) as ImageSize
        const generated = await generateGoogleImage({
          apiKey: imageCred.apiKey, endpoint: eff.endpoint, model: eff.model, prompt: args.prompt,
          aspectRatio, imageSize,
          ...(inlineReferences !== undefined ? { referenceImages: inlineReferences } : {}),
          maxBytes: ctx.attachments.imageLimits.maxImageBytes, signal: exec.signal,
        })
        return saveGenerated({ attachments: ctx.attachments }, generated, eff.provider, eff.model, `${aspectRatio}, ${imageSize}`, saveDir, args.prompt)
      }
      if (eff.provider === 'codex') {
        const generated = await generateCodexImage({
          accessToken: imageCred.apiKey,
          ...(imageCred.provider === 'codex' && imageCred.accountId !== undefined ? { accountId: imageCred.accountId } : {}),
          baseURL: eff.baseURL, model: eff.model, prompt: args.prompt,
          ...(args.size !== undefined ? { size: args.size } : {}),
          ...(args.quality !== undefined ? { quality: args.quality } : {}),
          ...(inlineReferences !== undefined ? { referenceImages: inlineReferences } : {}),
          maxBytes: ctx.attachments.imageLimits.maxImageBytes, signal: exec.signal,
        })
        return saveGenerated({ attachments: ctx.attachments }, generated, eff.provider, eff.model, outputLabel(eff, args, imageCred.source), saveDir, args.prompt)
      }
      const size = args.size ?? eff.imageSize
      const generated = await generateOpenAICompatibleImage({
        provider: eff.provider, apiKey: imageCred.apiKey, baseURL: eff.baseURL, model: eff.model, prompt: args.prompt, size,
        ...(args.aspect_ratio !== undefined ? { aspectRatio: args.aspect_ratio } : {}),
        ...(inlineReferences !== undefined ? { referenceImages: inlineReferences } : {}),
        maxBytes: ctx.attachments.imageLimits.maxImageBytes, signal: exec.signal,
      })
      return saveGenerated({ attachments: ctx.attachments }, generated, eff.provider, eff.model, outputLabel(eff, args, imageCred.source), saveDir, args.prompt)
    },
    presentResult: (_args, result) => imagePresentation(result),
  }))

  // 注册原生工具（风格库 / 图像编辑 / 质量审计）
  registerNativeTools(ctx)

  // 注册技能桥工具（taxue-imagegen：plan / compose / preflight / check）
  registerBridgeTools(ctx, () => {
    const cfg = current()
    return {
      ...(cfg.skillRoot !== undefined && cfg.skillRoot.length > 0 ? { skillRoot: cfg.skillRoot } : {}),
      ...(cfg.skillPython !== undefined && cfg.skillPython.length > 0 ? { pythonPath: cfg.skillPython } : {}),
      ...(cfg.skillTimeoutMs !== undefined && cfg.skillTimeoutMs > 0 ? { timeoutMs: cfg.skillTimeoutMs } : {}),
    }
  })
}

interface SaveImageStore {
  attachments: {
    imageLimits: { maxImageBytes: number; mediaTypes: readonly string[] }
    saveImage(input: { data: Uint8Array; mediaType: ImageAttachmentRef['mediaType']; name: string }): Promise<ImageAttachmentRef>
  }
}

async function saveGenerated(store: SaveImageStore, generated: { data: Uint8Array; mediaType: ImageAttachmentRef['mediaType'] }, provider: ArtisanProvider, model: string, output: string, saveDir?: string, prompt?: string): Promise<GeneratedValue> {
  if (!store.attachments.imageLimits.mediaTypes.includes(generated.mediaType)) throw new Error(`当前 DSH 部署不接受 ${generated.mediaType} 生成图`)
  const attachment = await store.attachments.saveImage({ data: generated.data, mediaType: generated.mediaType, name: 'generated-image' })
  // 落盘到可配置保存文件夹（未配置用默认 ~/Downloads）；失败不阻断主流程，仅提示。
  // 同时写提示词 sidecar JSON：图与生成它的 prompt 不分离，收藏即溯源。
  let savedPath: string | undefined
  try {
    const dir = typeof saveDir === 'string' && saveDir.trim().length > 0 ? saveDir.trim() : pathJoin(homedir(), 'Downloads')
    const base = `taxue-image-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
    savedPath = pathJoin(dir, `${base}.${mediaTypeExt(generated.mediaType)}`)
    // Fire-and-forget：落盘不阻塞返回给模型，失败仅丢本地副本不影响会话附加。
    fsMkdir(dir, { recursive: true }).then(() =>
      fsWriteFile(savedPath!, generated.data).then(() => {
        if (typeof prompt === 'string' && prompt.length > 0) {
          const sidecar = { prompt, provider, model, generatedAt: new Date().toISOString() }
          return fsWriteFile(pathJoin(dir, `${base}.json`), `${JSON.stringify(sidecar, null, 2)}\n`)
        }
      }),
    ).catch(() => { savedPath = undefined })
  } catch {
    savedPath = undefined
  }
  return {
    attachment,
    provider,
    model,
    output: savedPath === undefined ? output : `${output}；已保存到 ${savedPath}`,
    ...(savedPath === undefined ? {} : { savedPath }),
  }
}

/** 由媒体类型推导文件扩展名。 */
function mediaTypeExt(mediaType: ImageAttachmentRef['mediaType']): string {
  switch (mediaType) {
    case 'image/png': return 'png'
    case 'image/jpeg': return 'jpg'
    case 'image/webp': return 'webp'
    case 'image/gif': return 'gif'
    default: return 'png'
  }
}

interface GenerateOnceInput {
  provider: ArtisanProvider
  model: string
  endpoint?: string
  baseURL?: string
  prompt: string
  aspectRatio?: string
  imageSize?: string
  size?: string
  quality?: string
  accountId?: string
  /** 可选内联参考图（图控图），同步与后台共用。 */
  referenceImages?: Array<{ base64: string; mediaType: 'image/png' | 'image/jpeg' | 'image/webp' }>
  maxBytes: number
  signal: AbortSignal
  apiKey: string
  imageLimits: { maxImageBytes: number }
}

/** 按供应商执行一次生图请求，返回规范化字节。同步与后台共用。 */
async function generateOnce(input: GenerateOnceInput): Promise<{ data: Uint8Array; mediaType: ImageAttachmentRef['mediaType'] }> {
  if (input.provider === 'google') {
    const requested = input.aspectRatio ?? '1:1'
    if (!GOOGLE_ASPECT_RATIOS.includes(requested as (typeof GOOGLE_ASPECT_RATIOS)[number])) {
      throw new Error(`Google Gemini 只支持画幅 ${GOOGLE_ASPECT_RATIOS.join('/')}；你提供的是 ${requested}。Grok/Seedream 的扩展画幅请切换到对应供应商。`)
    }
    return generateGoogleImage({
      apiKey: input.apiKey, endpoint: input.endpoint ?? '', model: input.model, prompt: input.prompt,
      aspectRatio: (requested as AspectRatio), imageSize: ((input.imageSize ?? '1K') as ImageSize),
      ...(input.referenceImages !== undefined ? { referenceImages: input.referenceImages } : {}),
      maxBytes: input.imageLimits.maxImageBytes, signal: input.signal,
    })
  }
  if (input.provider === 'codex') {
    return generateCodexImage({
      accessToken: input.apiKey, baseURL: input.baseURL ?? '', model: input.model, prompt: input.prompt,
      ...(input.size !== undefined ? { size: input.size } : {}),
      ...(input.quality !== undefined ? { quality: input.quality } : {}),
      ...(input.accountId !== undefined ? { accountId: input.accountId } : {}),
      ...(input.referenceImages !== undefined ? { referenceImages: input.referenceImages } : {}),
      maxBytes: input.imageLimits.maxImageBytes, signal: input.signal,
    })
  }
  return generateOpenAICompatibleImage({
    provider: input.provider, apiKey: input.apiKey, baseURL: input.baseURL ?? '', model: input.model, prompt: input.prompt,
    size: input.size ?? '1024x1024', ...(input.aspectRatio !== undefined ? { aspectRatio: input.aspectRatio } : {}),
    ...(input.referenceImages !== undefined ? { referenceImages: input.referenceImages } : {}),
    maxBytes: input.imageLimits.maxImageBytes, signal: input.signal,
  })
}

/** 计算生图 output 标签（尺寸/画幅说明，订阅通道加标记）。 */
function outputLabel(active: ReturnType<typeof resolveProvider>, args: { aspect_ratio?: string; image_size?: string; size?: string }, source?: 'subscription' | 'apikey'): string {
  const label = active.provider === 'google' ? `${args.aspect_ratio ?? active.aspectRatio}, ${args.image_size ?? active.imageSize}` : args.size ?? active.imageSize
  if (source !== 'subscription') return label
  return active.provider === 'codex' ? `${label}（ChatGPT 订阅）` : `${label}（Grok 订阅）`
}

function imagePresentation(result: ToolResult) {
  const attachment = imageAttachmentFromMeta(result.meta)
  return attachment === undefined ? undefined : { card: 'generic' as const, title: '生成的图片', content: [{ type: 'image' as const, attachment }] }
}
