/**
 * taxue-imagegen 技能桥：以子进程方式复用技能的 Python 脚本，能力接入而不重写。
 *
 * 设计取舍：技能的填槽/预检/验收逻辑经过数十轮实测调优，重写即丢弃实测依据并
 * 制造第二套真源。这里只做「调用 + 透传」——脚本输出本就是为 Agent 设计的文本，
 * 原样交给模型比结构化解析更稳，脚本升级也不会让解析器碎掉。
 */
import { spawn } from 'node:child_process'
import { existsSync } from 'node:fs'
import { homedir } from 'node:os'
import { join as pathJoin } from 'node:path'

/** 技能目录探测候选（按优先级）。 */
const SKILL_ROOT_CANDIDATES = [
  '.workbuddy/skills/taxue-imagegen',
  '.agents/skills/taxue-imagegen',
  '.claude/skills/taxue-imagegen',
] as const

/** Python 解释器探测候选（按优先级）：WorkBuddy 内置环境依赖最全，其次 Homebrew。 */
const PYTHON_CANDIDATES = [
  '.workbuddy/binaries/python/envs/default/bin/python',
  '/opt/homebrew/bin/python3',
  '/usr/local/bin/python3',
  'python3',
] as const

/** 技能载荷的最小标识：这个文件在则视为技能根目录有效。 */
const SKILL_MARKER = pathJoin('scripts', 'fill_meta.py')

/** 允许调用的脚本白名单（不接受任意路径，避免桥层变成通用命令执行入口）。 */
export const ALLOWED_SCRIPTS = ['fill_meta.py', 'preflight.py', 'postcheck.py', 'build_storyboard.py'] as const
export type AllowedScript = (typeof ALLOWED_SCRIPTS)[number]

/** 可生图的技能类型；D 是半机械型（改 SCENES 列表），不在 fill_meta 里。 */
export const SKILL_TRACKS = ['A', 'B', 'C', 'D', 'E'] as const
export type SkillTrack = (typeof SKILL_TRACKS)[number]
/** fill_meta.py 直接支持的类型。 */
export const FILL_META_TRACKS = ['A', 'B', 'C', 'E'] as const

/** 桥层配置，来自插件设置。 */
export interface BridgeOptions {
  /** 技能根目录；留空则按候选列表探测。 */
  skillRoot?: string
  /** Python 解释器路径；留空则按候选列表探测。 */
  pythonPath?: string
  /** 单次脚本执行超时（ms）。 */
  timeoutMs?: number
}

/** 子进程执行结果。 */
export interface ScriptResult {
  /** 退出码；被杀或异常时为 -1。 */
  code: number
  stdout: string
  stderr: string
}

const DEFAULT_TIMEOUT_MS = 60000

/** 探测结果缓存：技能路径与解释器在进程生命周期内不会变，避免每次调用都 stat。 */
let cachedSkillRoot: string | undefined
let cachedPython: string | undefined

/** 展开 `~` 前缀。 */
function expandHome(input: string): string {
  return input.startsWith('~/') ? pathJoin(homedir(), input.slice(2)) : input
}

/** 判断某路径是否像技能根目录。 */
function isSkillRoot(dir: string): boolean {
  return existsSync(pathJoin(dir, SKILL_MARKER))
}

/** 解析技能根目录：显式配置优先，否则按候选探测。 */
export function resolveSkillRoot(options: BridgeOptions = {}): string | undefined {
  const configured = typeof options.skillRoot === 'string' ? options.skillRoot.trim() : ''
  if (configured.length > 0) {
    const expanded = expandHome(configured)
    return isSkillRoot(expanded) ? expanded : undefined
  }
  if (cachedSkillRoot !== undefined) return cachedSkillRoot
  for (const candidate of SKILL_ROOT_CANDIDATES) {
    const dir = pathJoin(homedir(), candidate)
    if (isSkillRoot(dir)) {
      cachedSkillRoot = dir
      return dir
    }
  }
  return undefined
}

/** 技能未就绪时的可操作报错。 */
export function skillMissingError(options: BridgeOptions = {}): Error {
  const configured = typeof options.skillRoot === 'string' ? options.skillRoot.trim() : ''
  const hint = configured.length > 0
    ? `已配置的 skillRoot「${configured}」下找不到 ${SKILL_MARKER}。`
    : `未找到 taxue-imagegen 技能，候选目录：${SKILL_ROOT_CANDIDATES.map(c => `~/${c}`).join('、')}。`
  return new Error(`${hint} 请在「设置 → 插件 → taxue 画师 → 技能目录」填入 taxue-imagegen 的绝对路径（该目录下应有 scripts/fill_meta.py）。`)
}

/** 解析 Python 解释器：显式配置优先，否则按候选探测；只返回路径，可用性由首次调用暴露。 */
export function resolvePython(options: BridgeOptions = {}): string {
  const configured = typeof options.pythonPath === 'string' ? options.pythonPath.trim() : ''
  if (configured.length > 0) return expandHome(configured)
  if (cachedPython !== undefined) return cachedPython
  for (const candidate of PYTHON_CANDIDATES) {
    const resolved = candidate.startsWith('/') ? candidate : pathJoin(homedir(), candidate)
    if (existsSync(resolved)) {
      cachedPython = resolved
      return resolved
    }
  }
  cachedPython = 'python3'
  return cachedPython
}

/** 重置探测缓存（设置变更后调用）。 */
export function resetBridgeCache(): void {
  cachedSkillRoot = undefined
  cachedPython = undefined
}

/**
 * 执行技能脚本。
 *
 * cwd 固定为技能根目录：脚本内部虽有自身路径解析，但记账与产物默认落在技能目录下，
 * 固定 cwd 可让这些相对路径行为与手动调用完全一致。
 */
export async function runScript(
  options: BridgeOptions,
  script: AllowedScript,
  args: readonly string[],
  input?: string,
): Promise<ScriptResult> {
  const root = resolveSkillRoot(options)
  if (root === undefined) throw skillMissingError(options)
  const python = resolvePython(options)
  const timeoutMs = typeof options.timeoutMs === 'number' && options.timeoutMs > 0 ? options.timeoutMs : DEFAULT_TIMEOUT_MS

  return await new Promise<ScriptResult>((resolve, reject) => {
    const child = spawn(python, [pathJoin(root, 'scripts', script), ...args], {
      cwd: root,
      env: { ...process.env, PYTHONIOENCODING: 'utf-8' },
    })
    let stdout = ''
    let stderr = ''
    let settled = false
    const timer = setTimeout(() => {
      if (settled) return
      settled = true
      child.kill('SIGKILL')
      reject(new Error(`${script} 执行超时（${timeoutMs}ms）。技能脚本通常 <1s，超时多因 Python 依赖缺失或首次导入缓慢。`))
    }, timeoutMs)

    child.stdout.setEncoding('utf-8')
    child.stderr.setEncoding('utf-8')
    child.stdout.on('data', (chunk: string) => { stdout += chunk })
    child.stderr.on('data', (chunk: string) => { stderr += chunk })
    child.on('error', (cause: Error) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      reject(new Error(`无法启动 Python（${python}）：${cause.message}。请在「设置 → 插件 → taxue 画师 → Python 解释器」指定可用路径。`))
    })
    child.on('close', (code: number | null) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve({ code: code ?? -1, stdout, stderr })
    })
    if (input !== undefined) child.stdin.write(input)
    child.stdin.end()
  })
}

/** 脚本因环境问题失败时的统一报错（依赖缺失是最高频原因）。 */
function environmentError(script: AllowedScript, python: string, result: ScriptResult): Error {
  const detail = result.stderr.trim().split('\n').slice(-3).join(' / ')
  const dependencyHint = /ModuleNotFoundError|ImportError/.test(result.stderr)
    ? ' 疑似缺少 numpy/PIL/opencv，请安装依赖或改用 WorkBuddy 内置 Python。'
    : ''
  return new Error(`${script} 执行失败（exit=${result.code}，解释器 ${python}）：${detail}${dependencyHint}`)
}

/**
 * 技能类型路由的一句话说明，供 artisan_plan 无参调用时返回。
 *
 * 取舍：这是全插件唯一一处与技能重复的常量。路由索引本身是「判断逻辑」而非「知识资产」，
 * 且极低频变动；从 SKILL.md §1 的 markdown 表格解析反而更脆。槽位清单、模板正文、
 * 验收阈值一律不复制，全部从技能读取。改动此处时需与技能 SKILL.md §1 路由表对齐。
 */
const TRACK_SUMMARY: Readonly<Record<SkillTrack, string>> = {
  A: '竖版概念海报（管图文关系与尺度反差）：概念海报 / 展览 KV / 专辑封面 / 书籍封面 / 电影氛围海报 / 杂志专题',
  B: '手绘群像插画（管多角色差异化）：多角色插画 / 动物图鉴 / 角色群像 / 旅行团 / 手账式群像',
  C: '写实包装 Mockup（棚拍实物做底 + 编辑风单色专色版面）：产品包装 / 包装样机 / mockup',
  D: '叙事分镜（同角色跨帧一致 + 镜头叙事）：漫剧切片 / 绘本连环画 / 同角色多场景，N=6-9 帧连续叙事',
  E: '多格排版（每格独立成品靠统一规格串组）：精灵图 / sprite sheet / 系列海报 / 邮票组 / 表情包 / 角色设定表',
}

/** artisan_plan：列类型路由，或列指定类型的槽位清单。 */
export async function planSlots(options: BridgeOptions, track?: SkillTrack): Promise<{ track?: SkillTrack; text: string }> {
  if (track === undefined) {
    const lines = (Object.keys(TRACK_SUMMARY) as SkillTrack[]).map((key) => `${key} · ${TRACK_SUMMARY[key]}`)
    return {
      text: [
        '五种类型，先选类型再填空，不要混用：',
        ...lines,
        '',
        '拿不准就问一句：画面主体是一个→A，一群→B，多张连续叙事→D，每格独立成品→E，实物包装→C。',
        '选定后用 artisan_plan 传 track 查该类型的槽位清单，再交给 artisan_compose 组装。',
      ].join('\n'),
    }
  }
  if (track === 'D') {
    const result = await runScript(options, 'build_storyboard.py', ['--help'])
    return {
      track,
      text: [
        TRACK_SUMMARY.D,
        '',
        '类型 D 是半机械型：fill_meta 不覆盖它，提示词由 build_storyboard.py 的 SCENES 列表生成（--case cyber|ink），生成后单独跑 preflight.py --track D。',
        '完整规则（双 LOCK 一致性锚、9 帧镜头设计法、实测参数 1024x1792）见技能 references/storyboard.md。',
        '',
        result.stdout.trim() || result.stderr.trim(),
      ].join('\n'),
    }
  }
  const result = await runScript(options, 'fill_meta.py', [track, '--list'])
  if (result.code !== 0) throw environmentError('fill_meta.py', resolvePython(options), result)
  return { track, text: `${TRACK_SUMMARY[track]}\n\n${result.stdout.trim()}` }
}

/** artisan_compose：槽位 → 可生图提示词。 */
export interface ComposeInput {
  track: Exclude<SkillTrack, 'D'>
  /** 槽位键值对；键名以 artisan_plan 的清单为准。 */
  slots: Record<string, string>
  /** 类型 B 主题名。 */
  theme?: string
  /** 类型 A 满铺型变体。 */
  manpu?: boolean
  /** 允许缺槽/残留槽位（半成品）。 */
  allowPartial?: boolean
}

export async function composePrompt(options: BridgeOptions, input: ComposeInput): Promise<{ prompt: string; warnings: string[] }> {
  const args: string[] = [input.track]
  if (input.theme !== undefined && input.theme.trim().length > 0) args.push('--theme', input.theme.trim())
  if (input.manpu === true) args.push('--manpu')
  if (input.allowPartial === true) args.push('--allow-partial')
  for (const [key, value] of Object.entries(input.slots)) {
    if (typeof value !== 'string') continue
    args.push('--set', `${key}=${value}`)
  }
  const result = await runScript(options, 'fill_meta.py', args)
  if (result.code !== 0) {
    // 缺槽/残留槽位属可预期失败：把脚本原话交给模型，比包装成通用错误更有用。
    const detail = result.stderr.trim() || result.stdout.trim()
    throw new Error(`填槽未通过（exit=${result.code}）：${detail}`)
  }
  const warnings = result.stderr.trim().length > 0 ? result.stderr.trim().split('\n').filter(line => line.trim().length > 0) : []
  return { prompt: result.stdout.trim(), warnings }
}

/** artisan_compose 的手写检查模式：对现成提示词跑静态预检。 */
export async function preflightText(options: BridgeOptions, track: SkillTrack, text: string): Promise<{ report: string; ok: boolean }> {
  const result = await runScript(options, 'preflight.py', ['-', '--track', track], text)
  const report = [result.stdout.trim(), result.stderr.trim()].filter(part => part.length > 0).join('\n')
  // 预检把 findings 写在输出里，退出码 0 表示无 blocker 级问题；报告原样交给模型判读。
  return { report: report.length > 0 ? report : '预检通过：未发现已知翻车项。', ok: result.code === 0 }
}

/** 出图后验收。 */
export interface CheckInput {
  /** 待验收图片的绝对路径。 */
  path: string
  track?: SkillTrack
  /** 是否加测顶部留白（类型 A 必用）。 */
  top?: boolean
  /** 文案逐字目检结论；不传则脚本判 pending（文字未核对不得计 pass）。 */
  text?: 'ok' | 'bad'
  /** 类型 E 声明格数，用于校验「说的和画的」是否一致。 */
  expectCells?: number
  /** 不写 runs.csv（跑验证时用）。 */
  noLog?: boolean
}

/** postcheck 退出码语义（技能 v1.10+ 三档）：0=pass，1=blocker，3=pending。 */
export type CheckVerdict = 'pass' | 'blocker' | 'pending' | 'unknown'

export async function checkImage(options: BridgeOptions, input: CheckInput): Promise<{ verdict: CheckVerdict; report: string }> {
  const args = [input.path, '--track', input.track ?? 'A']
  if (input.top === true) args.push('--top')
  if (input.text !== undefined) args.push('--text', input.text)
  if (typeof input.expectCells === 'number' && input.expectCells > 0) args.push('--expect-cells', String(input.expectCells))
  if (input.noLog === true) args.push('--no-log')
  const result = await runScript(options, 'postcheck.py', args)
  const report = [result.stdout.trim(), result.stderr.trim()].filter(part => part.length > 0).join('\n')
  if (result.code !== 0 && result.code !== 1 && result.code !== 3) {
    throw environmentError('postcheck.py', resolvePython(options), result)
  }
  const verdict: CheckVerdict = result.code === 0 ? 'pass' : result.code === 1 ? 'blocker' : 'pending'
  return { verdict, report }
}
