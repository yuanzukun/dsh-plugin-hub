/** Google Gemini Interactions API 适配。 */
import type { ImageMediaType } from '@deepseek-ai/dsh-attachment'
import type { AspectRatio, ImageSize } from './config.js'

const ERROR_LIMIT = 4096
const REQUESTED_MEDIA_TYPE = 'image/jpeg'

/** Attachment 持久化前的生图字节。 */
export interface GeneratedImage {
  data: Uint8Array
  mediaType: ImageMediaType
}

/** 发送一次原生 Google 图像请求并校验其内联图像响应。 */
export async function generateGoogleImage(input: {
  apiKey: string
  endpoint: string
  model: string
  prompt: string
  aspectRatio: AspectRatio
  imageSize: ImageSize
  /** 可选参考图（内联 base64），随 prompt 一起作为生成输入。 */
  referenceImages?: Array<{ base64: string; mediaType: string }> | undefined
  maxBytes: number
  signal: AbortSignal
}): Promise<GeneratedImage> {
  // Interactions API 的 input 支持字符串或内容分块数组；带参考图时用数组形式。
  const content = [
    ...(input.referenceImages ?? []).map((image) => ({ type: 'input_image' as const, mime_type: image.mediaType, data: image.base64 })),
    { type: 'text' as const, text: input.prompt },
  ]
  const response = await fetch(input.endpoint, {
    method: 'POST',
    redirect: 'error',
    signal: input.signal,
    headers: { 'content-type': 'application/json', 'x-goog-api-key': input.apiKey },
    body: JSON.stringify({
      model: input.model,
      input: (input.referenceImages?.length ?? 0) > 0 ? content : input.prompt,
      response_format: {
        type: 'image',
        mime_type: REQUESTED_MEDIA_TYPE,
        aspect_ratio: input.aspectRatio,
        image_size: input.imageSize,
      },
    }),
  })
  const text = await readBoundedText(response, Math.ceil(input.maxBytes * 1.4) + ERROR_LIMIT)
  if (!response.ok) throw new Error(`Google 图像生成失败 (${response.status}): ${text.slice(0, ERROR_LIMIT)}`)
  let payload: unknown
  try {
    payload = JSON.parse(text)
  } catch {
    throw new Error('Google 图像生成返回了非法 JSON')
  }
  const image = outputImage(payload)
  if (image === undefined) throw new Error(`Google 图像生成未返回图像: ${text.slice(0, ERROR_LIMIT)}`)
  const mediaType = mediaTypeOf(image.mime_type ?? REQUESTED_MEDIA_TYPE)
  if (mediaType === undefined) throw new Error(`Google 图像生成返回了不支持的媒体类型 ${JSON.stringify(image.mime_type)}`)
  const data = decodeBase64(image.data)
  if (data.byteLength > input.maxBytes) throw new Error(`Google 图像生成超出 ${String(input.maxBytes)} 字节的图像上限`)
  return { data, mediaType }
}

function outputImage(value: unknown): { data: string; mime_type?: unknown } | undefined {
  const interaction = record(value)
  if (interaction === undefined) return undefined
  const direct = imageContent(interaction.output_image, false)
  if (direct !== undefined) return direct
  if (!Array.isArray(interaction.steps)) return undefined
  for (const step of interaction.steps) {
    const modelOutput = record(step)
    if (modelOutput?.type !== 'model_output' || !Array.isArray(modelOutput.content)) continue
    for (const content of modelOutput.content) {
      const image = imageContent(content, true)
      if (image !== undefined) return image
    }
  }
  return undefined
}

function imageContent(value: unknown, requiresImageType: boolean): { data: string; mime_type?: unknown } | undefined {
  const image = record(value)
  if (image === undefined || (requiresImageType && image.type !== 'image') || typeof image.data !== 'string') return undefined
  return { data: image.data, mime_type: image.mime_type }
}

function record(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value) ? value as Record<string, unknown> : undefined
}

function mediaTypeOf(value: unknown): ImageMediaType | undefined {
  return value === 'image/png' || value === 'image/jpeg' || value === 'image/webp' || value === 'image/gif' ? value : undefined
}

function decodeBase64(data: string): Uint8Array {
  const clean = data.replace(/\s+/g, '')
  if (clean.length === 0) throw new Error('Google 图像生成返回了非法 base64 图像数据')
  const decoded = Buffer.from(clean, 'base64')
  if (decoded.length === 0) throw new Error('Google 图像生成返回了非法 base64 图像数据')
  return new Uint8Array(decoded)
}

async function readBoundedText(response: Response, maxBytes: number): Promise<string> {
  if (response.body === null) return ''
  const reader = response.body.getReader()
  const chunks: Uint8Array[] = []
  let bytes = 0
  try {
    for (;;) {
      const next = await reader.read()
      if (next.done) break
      bytes += next.value.byteLength
      if (bytes > maxBytes) throw new Error(`Google 图像生成响应超出 ${String(maxBytes)} 字节上限`)
      chunks.push(next.value)
    }
  } finally {
    reader.releaseLock()
  }
  const joined = new Uint8Array(bytes)
  let offset = 0
  for (const chunk of chunks) {
    joined.set(chunk, offset)
    offset += chunk.byteLength
  }
  return new TextDecoder().decode(joined)
}
