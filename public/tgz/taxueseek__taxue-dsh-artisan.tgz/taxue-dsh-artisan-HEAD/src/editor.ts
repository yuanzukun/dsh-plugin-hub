/**
 * 原生图像编辑工具：从 compositor-retouch 吸纳精华。
 *
 * 三步流程：体检 → 出可回退的工程 → 渲染成稿
 * 核心立场：AI 出的图是原料，修图师的手法负责收尾。不把图喂回模型重画。
 */

// ─── 七条纪律 ───
export const EDITING_PRINCIPLES = [
  '先看意图，再动手。低对比、低饱和、暗调、颗粒既可能是缺陷也可能是风格。',
  '先定真值边界，再碰像素。修图方案要同时写明要达到什么和不许改什么。',
  '宽到窄。全局（白平衡/曝光/影调/色彩）做完再做局部，最后才做修饰与输出锐化。',
  '保留退路。全部做成可回退图层，不烘死像素。',
  '成稿必须出自真引擎。',
];

// ─── 体检清单 ───
export const CHECKUP_ITEMS = [
  { id: 'exposure', name: '曝光', check: '直方图是否集中在中间调，有无过曝/欠曝' },
  { id: 'white-balance', name: '白平衡', check: '有无色偏，中性灰是否准确' },
  { id: 'contrast', name: '对比度', check: '动态范围是否充分利用，有无灰闷感' },
  { id: 'saturation', name: '饱和度', check: '色彩是否自然，有无过饱和/欠饱和' },
  { id: 'sharpness', name: '锐度', check: '细节是否清晰，有无模糊/过锐' },
  { id: 'noise', name: '噪点', check: '暗部是否有明显噪点' },
  { id: 'composition', name: '构图', check: '主体是否突出，有无干扰元素' },
  { id: 'style-consistency', name: '风格一致性', check: '是否与目标风格一致' },
];

// ─── 修图操作（可回退图层）───
export const EDIT_OPERATIONS = [
  { id: 'wb', name: '白平衡', desc: '调整色温/色调，修正色偏' },
  { id: 'exposure', name: '曝光', desc: '调整整体亮度' },
  { id: 'contrast', name: '对比度', desc: '调整动态范围' },
  { id: 'highlights', name: '高光', desc: '恢复过曝区域细节' },
  { id: 'shadows', name: '阴影', desc: '提亮暗部细节' },
  { id: 'whites', name: '白色', desc: '调整白点' },
  { id: 'blacks', name: '黑色', desc: '调整黑点' },
  { id: 'vibrance', name: '自然饱和度', desc: '智能调整饱和度' },
  { id: 'saturation', name: '饱和度', desc: '调整整体饱和度' },
  { id: 'clarity', name: '清晰度', desc: '增强中间调对比' },
  { id: 'dehaze', name: '去雾', desc: '去除雾霾感' },
  { id: 'sharpen', name: '锐化', desc: '增强细节' },
  { id: 'denoise', name: '降噪', desc: '去除噪点' },
  { id: 'vignette', name: '暗角', desc: '添加/去除暗角' },
  { id: 'grain', name: '颗粒', desc: '添加胶片颗粒' },
  { id: 'crop', name: '裁剪', desc: '调整构图' },
  { id: 'straighten', name: '拉直', desc: '修正水平线' },
  { id: 'remove', name: '移除', desc: '去除瑕疵/水印/不需要的元素' },
  { id: 'background', name: '换背景', desc: '替换背景' },
];

// ─── 修图方案生成 ───
export function generateEditPlan(checkupResults: Array<{ id: string; name: string; issue: boolean }>) {
  const issues = checkupResults.filter((r) => r.issue);
  const plan: Array<{ issue: string; operation: string; desc: string }> = [];
  for (const issue of issues) {
    const op = EDIT_OPERATIONS.find((candidate) => candidate.id === issue.id);
    if (op) {
      plan.push({ issue: issue.name, operation: op.name, desc: op.desc });
    }
  }
  return plan;
}

// ─── 修图提示词生成 ───
export function generateEditPrompt(imageDesc: string, operations: Array<{ operation: string }>) {
  const ops = operations.map((op) => op.operation).join('、');
  return `Professional photo editing: ${imageDesc}. Apply: ${ops}. Preserve original style and intent. Non-destructive editing with reversible layers. Output high quality render.`;
}
