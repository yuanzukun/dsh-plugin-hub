/** OpenAI Images、xAI Grok 与 Volcengine Ark/Seedream 的 OpenAI 兼容响应适配。 */
import type { ImageMediaType } from '@deepseek-ai/dsh-attachment'

const ERROR_LIMIT = 4096
/** Grok/Seedream 默认返回临时 URL，需立即下载；b64 则直接解码。 */
const URL_PROVIDERS: ReadonlySet<string> = new Set(['seedream', 'grok'])

/** 一张已规范化的栅格图，等待 Attachment 持久化。 */
export interface GeneratedCompatibleImage {
  data: Uint8Array
  mediaType: ImageMediaType
}

/** 从 OpenAI 兼容端点生成一张图。 */
export async function generateOpenAICompatibleImage(input: {
  provider: 'openai' | 'seedream' | 'grok'
  apiKey: string
  baseURL: string
  model: string
  prompt: string
  size: string
  aspectRatio?: string | undefined
  /** 可选参考图（内联 base64）。默认不带；显式传入时才随请求上传。 */
  referenceImages?: Array<{ base64: string; mediaType: string }> | undefined
  maxBytes: number
  signal: AbortSignal
}): Promise<GeneratedCompatibleImage> {  const endpoint = imageEndpoint(input.baseURL)
  // 参考图按各家兼容端约定编码：Grok Imagine 用 image_url 数组；OpenAI/Seedream 用 image 字段（data URL）。
  const references = input.referenceImages ?? []
  let response: Response
  try {
    response = await fetch(endpoint, {
      method: 'POST', redirect: 'error', signal: input.signal,
      headers: { authorization: `Bearer ${input.apiKey}`, 'content-type': 'application/json' },
      // Grok 不支持 size/quality/style，仅支持 aspect_ratio 与 resolution，因此单独组装参数。
      body: JSON.stringify(input.provider === 'grok'
        ? {
            model: input.model,
            prompt: input.prompt,
            response_format: 'url',
            ...(input.aspectRatio !== undefined ? { aspect_ratio: input.aspectRatio } : {}),
            ...(references.length > 0 ? { image_url: references.map((image) => `data:${image.mediaType};base64,${image.base64}`) } : {}),
          }
        : {
            model: input.model,
            prompt: input.prompt,
            size: input.size,
            ...(URL_PROVIDERS.has(input.provider) ? { response_format: 'url' } : {}),
            ...(references.length > 0 ? { image: references.map((image) => `data:${image.mediaType};base64,${image.base64}`) } : {}),
          }),
    })
  } catch (cause) {
    // 网络层失败（如 fetch failed）：常见原因是直连不通、未走代理或订阅通道对端点不开放。
    const detail = cause instanceof Error ? cause.message : String(cause)
    const providerHint = input.provider === 'grok'
      ? 'api.x.ai 需走系统代理（HTTP_PROXY/HTTPS_PROXY），订阅 token 仅对 /v1/responses 与 /v1/images/* 有效；确认代理可达与订阅未过期'
      : `确认网络可达 ${input.baseURL} 且 API Key 有效`
    throw new Error(`${input.provider} 图像生成请求失败（${detail}）：${providerHint}。`)
  }
  const text = await readBoundedText(response, Math.ceil(input.maxBytes * 1.4) + ERROR_LIMIT)
  if (!response.ok) throw new Error(`${input.provider} 图像生成失败 (${response.status}): ${text.slice(0, ERROR_LIMIT)}`)
  let payload: unknown
  try { payload = JSON.parse(text) } catch { throw new Error(`${input.provider} 图像生成返回了非法 JSON`) }
  const image = firstImage(payload)
  if (image === undefined) throw new Error(`${input.provider} 图像生成未返回图像: ${text.slice(0, ERROR_LIMIT)}`)
  if (image.b64_json !== undefined) {
    // Grok 即使请求 url 也可能在个别网关返回 b64，稳妥起见两种都支持。
    return { data: decodeBase64(image.b64_json, input.provider), mediaType: 'image/png' }
  }
  return downloadImage(image.url, input)
}

function imageEndpoint(baseURL: string): string {
  try { return new URL('images/generations', baseURL.endsWith('/') ? baseURL : `${baseURL}/`).toString() } catch { throw new Error('图像生成端点必须是绝对 URL') }
}

function firstImage(value: unknown): { b64_json?: string; url?: string } | undefined {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return undefined
  const data = (value as { data?: unknown }).data
  if (!Array.isArray(data) || data.length === 0) return undefined
  const candidate = data[0]
  if (typeof candidate !== 'object' || candidate === null || Array.isArray(candidate)) return undefined
  const item = candidate as { b64_json?: unknown; url?: unknown }
  return typeof item.b64_json === 'string' ? { b64_json: item.b64_json } : typeof item.url === 'string' ? { url: item.url } : undefined
}

async function downloadImage(url: string | undefined, input: Parameters<typeof generateOpenAICompatibleImage>[0]): Promise<GeneratedCompatibleImage> {
  if (url === undefined) throw new Error(`${input.provider} 图像生成未返回图像数据`)
  let response: Response
  try {
    response = await fetch(url, { redirect: 'follow', signal: input.signal })
  } catch (cause) {
    const detail = cause instanceof Error ? cause.message : String(cause)
    throw new Error(`${input.provider} 图像临时 URL 下载失败（${detail}）：请检查网络/代理可达性，临时 URL 需立即下载。`)
  }
  if (!response.ok) throw new Error(`${input.provider} 图像下载失败 (${response.status})`)
  const mediaType = imageMediaType(response.headers.get('content-type'))
  if (mediaType === undefined) throw new Error(`${input.provider} 图像下载返回了不支持的内容类型`)
  return { data: await readBoundedBytes(response, input.maxBytes), mediaType }
}

function decodeBase64(value: string, provider: string): Uint8Array {
  const clean = value.replace(/\s+/g, '')
  if (clean.length === 0) throw new Error(`${provider} 图像生成返回了非法 base64 图像数据`)
  const decoded = Buffer.from(clean, 'base64')
  if (decoded.length === 0) throw new Error(`${provider} 图像生成返回了非法 base64 图像数据`)
  return new Uint8Array(decoded)
}

function imageMediaType(value: string | null): ImageMediaType | undefined {
  const mediaType = value?.split(';', 1)[0]?.trim().toLowerCase()
  return mediaType === 'image/png' || mediaType === 'image/jpeg' || mediaType === 'image/webp' || mediaType === 'image/gif' ? mediaType : undefined
}

async function readBoundedText(response: Response, maxBytes: number): Promise<string> { return new TextDecoder().decode(await readBoundedBytes(response, maxBytes)) }

async function readBoundedBytes(response: Response, maxBytes: number): Promise<Uint8Array> {
  if (response.body === null) return new Uint8Array()
  const reader = response.body.getReader(); const chunks: Uint8Array[] = []; let bytes = 0
  try { for (;;) { const next = await reader.read(); if (next.done) break; bytes += next.value.byteLength; if (bytes > maxBytes) throw new Error(`图像响应超出 ${String(maxBytes)} 字节上限`); chunks.push(next.value) } } finally { reader.releaseLock() }
  const joined = new Uint8Array(bytes); let offset = 0
  for (const chunk of chunks) { joined.set(chunk, offset); offset += chunk.byteLength }
  return joined
}

/** 从 ChatGPT 订阅（codex）端点生成一张图：gpt-image-2，走 chatgpt.com 专属头。 */
export async function generateCodexImage(input: {
  accessToken: string
  accountId?: string | undefined
  baseURL: string
  model: string
  prompt: string
  size?: string | undefined
  quality?: string | undefined
  /** 可选参考图（内联 base64），gpt-image 支持以 image 数组传入。 */
  referenceImages?: Array<{ base64: string; mediaType: string }> | undefined
  maxBytes: number
  signal: AbortSignal
}): Promise<GeneratedCompatibleImage> {
  const endpoint = `${input.baseURL.replace(/\/+$/, '')}/images/generations`
  const references = input.referenceImages ?? []
  let response: Response
  try {
    response = await fetch(endpoint, {
      method: 'POST', redirect: 'error', signal: input.signal,
      headers: {
        authorization: `Bearer ${input.accessToken}`,
        ...(input.accountId !== undefined && input.accountId.length > 0 ? { 'chatgpt-account-id': input.accountId } : {}),
        originator: 'codex_cli_rs',
        'content-type': 'application/json',
        accept: 'application/json',
      },
      body: JSON.stringify({
        prompt: input.prompt,
        model: input.model,
        ...(input.size !== undefined ? { size: input.size } : {}),
        ...(input.quality !== undefined ? { quality: input.quality } : {}),
        ...(references.length > 0 ? { image: references.map((image) => `data:${image.mediaType};base64,${image.base64}`) } : {}),
      }),
    })
  } catch (cause) {
    const detail = cause instanceof Error ? cause.message : String(cause)
    throw new Error(`codex 图像生成请求失败（${detail}）：chatgpt.com 需网络可达；订阅 token 仅对已登录的 ChatGPT 账号有效。`)
  }
  const text = await readBoundedText(response, Math.ceil(input.maxBytes * 1.4) + ERROR_LIMIT)
  if (!response.ok) throw new Error(`codex 图像生成失败 (${response.status}): ${text.slice(0, ERROR_LIMIT)}`)
  let payload: unknown
  try { payload = JSON.parse(text) } catch { throw new Error('codex 图像生成返回了非法 JSON') }
  const image = firstImage(payload)
  if (image?.b64_json === undefined) throw new Error(`codex 图像生成未返回图像数据: ${text.slice(0, ERROR_LIMIT)}`)
  // codex（gpt-image-2）服务端返回 PNG base64。
  return { data: decodeBase64(image.b64_json, 'codex'), mediaType: 'image/png' }
}
