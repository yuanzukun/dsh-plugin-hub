/**
 * 原生风格库：从 taxue-halftone、taxue-creative-style、taxue-solar-polaroid 三个技能吸纳精华。
 *
 * 设计原则：
 * - 每个风格是一个自包含的提示词模板，不依赖外部脚本
 * - 六不变式（纸/墨/印刷布尔/机制/主体行为/字图音量）作为所有风格的共同约束
 * - 反模式表作为出图前的静态检查
 */

// ─── 六不变式约束（所有风格共享）───
export const SIX_INVARIANTS = {
  paper: '纸色与纸纹（底衬色不算墨）',
  ink: '墨色角色与配比（主 70-85%，辅各 1 职务）',
  printing: '印刷布尔（knockout/overprint/trap 三选一）',
  mechanism: '印刷机制（半调/孔版/双色/木刻/蓝晒/蓝染/复印/剪影/拼贴/钢印）',
  behavior: '主体行为（still/dissipate/densify/horizon/vertical-extend）',
  volume: '字图音量（字大声则图退，禁止双开 11）',
};

// ─── 反模式表（出图前静态检查）───
export const ANTI_PATTERNS = [
  { id: 'third-hue', pattern: '第三色相', fix: '限墨族 ≤2 墨，丰富族 ≤5 版各司一职' },
  { id: 'gradient-halftone', pattern: '渐变冒充网点', fix: '网点必须有结构，不能是平滑渐变' },
  { id: 'neon-splash', pattern: '霓虹泼彩', fix: '用限墨色卡，不用霓虹色' },
  { id: 'full-color-photo', pattern: '全彩照片', fix: '必须有限墨或半调处理' },
  { id: 'auto-age', pattern: '自动做旧', fix: '复古编辑不做旧，纸色自然即可' },
  { id: 'fake-cmyk', pattern: '假 CMYK 扮孔版', fix: '孔版用专色，不用 CMYK 四色' },
  { id: 'same-angle', pattern: '全通道同角', fix: '每支墨必须有不同角度' },
  { id: 'rgb-halftone', pattern: 'RGB 上套 Color Halftone', fix: '用专色半调，不用 RGB 滤镜' },
  { id: 'center-template', pattern: '居中模板', fix: '用非对称构图，避免居中' },
  { id: 'sticker-collage', pattern: '贴纸拼贴', fix: '用撕纸拼贴三层结构' },
  { id: 'sales-cta', pattern: '销售 CTA', fix: '用编辑型语言，不用销售话术' },
  { id: 'orphan-number', pattern: '孤儿编号', fix: '任何编号必须能回答来源' },
];

// ─── 半调海报 12+ 风格（从 taxue-halftone 吸纳）───
export const HALFTONE_STYLES = [
  {
    id: 'editorial',
    name: '复古编辑印刷风',
    summary: 'AM 半调 + 字撞物 + 纸露白，一物主导',
    mechanism: 'AM 半调',
    ink: '双色，主墨 45°',
    paper: '中性白纸',
    behavior: 'still',
    volume: '字大声',
    prompt: 'editorial halftone print, single dominant subject, bold typography colliding with image, paper white visible, AM halftone screen, two-color duotone, 45 degree angle, editorial print aesthetic',
  },
  {
    id: 'polish',
    name: '波兰海报风格',
    summary: 'photogram 高反差，字即物，单墨或高反差',
    mechanism: 'photogram',
    ink: '单墨或高反差双色',
    paper: '深色纸',
    behavior: 'still',
    volume: '字即物',
    prompt: 'Polish poster style, photogram high contrast, typography as object, single ink or high contrast duotone, bold graphic design, expressive hand-drawn elements',
  },
  {
    id: 'swiss',
    name: '瑞士海报风格',
    summary: '摄影阶调 + 实色字 + 大量纸白，克制秩序',
    mechanism: '摄影阶调',
    ink: '实色字',
    paper: '大量纸白',
    behavior: 'horizon',
    volume: '字大声',
    prompt: 'Swiss poster style, photographic tonal range, solid color typography, generous white space, restrained order, grid-based layout, International Typographic Style',
  },
  {
    id: 'riso_zine',
    name: '孔版 zine 风格',
    summary: '极疏构图，主体小、空纸大，当代纸不做旧',
    mechanism: '孔版',
    ink: '专色 1-2 支',
    paper: '当代纸',
    behavior: 'still',
    volume: '字小声',
    prompt: 'Risograph zine style, sparse composition, small subject, large empty paper, contemporary paper without aging, spot color 1-2 inks, misregistration aesthetic',
  },
  {
    id: 'filmstack',
    name: '胶片叠层风格',
    summary: '粗网本身是图形，字与图共享一层，宽边框住',
    mechanism: '粗网半调',
    ink: '双色',
    paper: '胶片底',
    behavior: 'densify',
    volume: '字图共享',
    prompt: 'Film stack style, coarse halftone screen as graphic element, typography and image sharing one layer, wide border, layered film aesthetic, duotone',
  },
  {
    id: 'archival',
    name: '标本/档案风格',
    summary: '标题 + 规整图像板 + 多栏图注，标本/观察笔记',
    mechanism: '档案印刷',
    ink: '单色',
    paper: '档案纸',
    behavior: 'still',
    volume: '字大声',
    prompt: 'Archival specimen style, title header, regular image plates, multi-column captions, specimen observation notes, scientific illustration aesthetic, monochrome',
  },
  {
    id: 'imperfect_collage',
    name: '不完美印刷拼贴',
    summary: '撕纸拼贴三层结构，专色场 + 黑白半调主体，上图下卡',
    mechanism: '撕纸拼贴',
    ink: '专色场 + 黑白半调',
    paper: '拼贴纸',
    behavior: 'dissipate',
    volume: '字小声',
    prompt: 'Imperfect print collage, torn paper three-layer structure, spot color field + black and white halftone subject, image above text below, handmade aesthetic',
  },
  {
    id: 'dot_dissolve',
    name: '点阵解构海报风格',
    summary: '复古丝网圆点阵，具象解构为点阵颗粒波纹，字融入点阵场',
    mechanism: '丝网圆点阵',
    ink: '双色',
    paper: '复古纸',
    behavior: 'dissipate',
    volume: '字融入',
    prompt: 'Dot dissolve poster, vintage screen print dot matrix, concrete subject deconstructed into dot particles and waves, typography merged into dot field, retro aesthetic',
  },
  {
    id: 'paper_cut_group',
    name: '中式剪纸风格',
    summary: '剪纸剪影群像+负空间镂空，上图下卡，一枚跳色例外成员',
    mechanism: '剪纸',
    ink: '单色 + 跳色',
    paper: '剪纸',
    behavior: 'still',
    volume: '字小声',
    prompt: 'Chinese paper cutting style, silhouette group with negative space hollow, image above text below, one accent color exception member, traditional folk art aesthetic',
  },
  {
    id: 'paper_cut_halftone',
    name: '点阵剪纸风格',
    summary: '点阵解构×中式剪纸混搭：剪纸窗花轮廓+粗圆网点铺形',
    mechanism: '点阵剪纸',
    ink: '双色',
    paper: '剪纸',
    behavior: 'still',
    volume: '字小声',
    prompt: 'Paper cut halftone style, dot matrix deconstruction mixed with Chinese paper cutting, window flower outline + coarse dot fill, dark areas 70-90% continuous dots, restrained accent color',
  },
  {
    id: 'aizome',
    name: '蓝染艺术海报风格',
    summary: '绝对纯白数字平面 + 深靛蓝/钴蓝 + 蓝晒式平阶剪影',
    mechanism: '蓝晒',
    ink: '深靛蓝/钴蓝',
    paper: '纯白',
    behavior: 'still',
    volume: '字大声',
    prompt: 'Aizome indigo dye poster, absolute white digital flat, deep indigo/cobalt blue, cyanotype flat silhouette, dye concentration and print lines only within blue, modern Chinese typography',
  },
  {
    id: 'emboss',
    name: '钢印盲压风格',
    summary: '凹凸质感，无墨压印，证书/文件质感',
    mechanism: '钢印盲压',
    ink: '无墨',
    paper: '证书纸',
    behavior: 'still',
    volume: '字大声',
    prompt: 'Embossed blind stamp style, raised texture without ink, certificate document quality, tactile impression, official seal aesthetic',
  },
];

// ─── 创意风格 14 家族（从 taxue-creative-style 吸纳）───
export const CREATIVE_FAMILIES = [
  { id: 'ink-wash', name: '笔意水墨', summary: '文人水墨，留白，意境', prompt: 'Chinese ink wash painting, literati style, generous negative space, artistic conception, flowing brushstrokes, monochromatic with subtle color accents' },
  { id: 'blank-poster', name: '留白海报', summary: '大量留白，极简，诗意', prompt: 'Minimalist poster with generous white space, poetic composition, single focal point, subtle texture, East Asian aesthetic' },
  { id: 'city-arch', name: '城市建筑', summary: '城市景观，建筑摄影，空间感', prompt: 'Urban architecture photography, city landscape, spatial depth, geometric composition, modern metropolitan aesthetic' },
  { id: 'healing', name: '治愈插画', summary: '温暖治愈，柔和色彩，生活感', prompt: 'Healing illustration, warm and soothing colors, daily life feeling, soft lighting, gentle atmosphere, cozy aesthetic' },
  { id: 'oriental', name: '东方古典', summary: '东方美学，古典元素，纹样', prompt: 'Oriental classical style, traditional elements, decorative patterns, rich cultural heritage, elegant composition' },
  { id: 'ambient', name: '氛围实验', summary: '实验性，氛围感，抽象', prompt: 'Atmospheric experimental style, abstract composition, mood-driven, ethereal quality, artistic exploration' },
  { id: 'realistic', name: '写实摄影', summary: '写实，高细节，真实感', prompt: 'Realistic photography, high detail, authentic representation, natural lighting, documentary style' },
  { id: 'concept', name: '概念海报', summary: '概念性，视觉冲击，创意', prompt: 'Conceptual poster, visual impact, creative composition, bold ideas, striking imagery' },
  { id: 'photo-art', name: '照片转艺术', summary: '照片艺术化，风格转换', prompt: 'Photo to art transformation, stylized photography, artistic filter, creative interpretation' },
  { id: 'paper-cut', name: '剪纸纸艺', summary: '剪纸，纸艺，民间艺术', prompt: 'Paper cutting art, folk art style, intricate hollow patterns, silhouette composition, traditional craft' },
  { id: 'shadow-puppet', name: '皮影偶戏', summary: '皮影，偶戏，光影', prompt: 'Shadow puppet style, silhouette theater, light and shadow play, traditional Chinese folk art, dramatic backlighting' },
  { id: 'ceramic', name: '釉面器物', summary: '陶瓷，釉面，器物美', prompt: 'Ceramic glaze style, pottery aesthetic, glazed surface texture, vessel beauty, traditional craft' },
  { id: 'paper-archive', name: '纸本档案', summary: '纸本，档案，文献感', prompt: 'Paper archive style, document aesthetic, vintage paper texture, archival quality, historical feel' },
  { id: 'film-art', name: '美术片媒介', summary: '美术片，动画，中国传统动画', prompt: 'Chinese animation film style, traditional art film aesthetic, hand-painted quality, cultural heritage' },
];

// ─── 节气推演卡（从 taxue-solar-polaroid 吸纳）───
export const SEASONAL_TEMPLATES = [
  { id: 'spring', name: '春', keywords: ['春分', '清明', '谷雨', '立春', '雨水', '惊蛰'], prompt: 'spring season visual, fresh green tones, new growth, gentle rain, flower blossoms, renewal energy, soft natural light' },
  { id: 'summer', name: '夏', keywords: ['夏至', '小暑', '大暑', '立夏', '小满', '芒种'], prompt: 'summer season visual, warm golden tones, lush vegetation, bright sunlight, vibrant energy, tropical atmosphere' },
  { id: 'autumn', name: '秋', keywords: ['秋分', '寒露', '霜降', '立秋', '处暑', '白露'], prompt: 'autumn season visual, warm amber tones, falling leaves, harvest mood, golden hour light, nostalgic atmosphere' },
  { id: 'winter', name: '冬', keywords: ['冬至', '小寒', '大寒', '立冬', '小雪', '大雪'], prompt: 'winter season visual, cool blue tones, snow and ice, quiet stillness, minimalist composition, serene atmosphere' },
];

// ─── 统一风格查询 ───
export function getAllStyles() {
  return [
    ...HALFTONE_STYLES.map((s) => ({ ...s, category: 'halftone' })),
    ...CREATIVE_FAMILIES.map((s) => ({ ...s, category: 'creative' })),
  ];
}

export function getStyleById(id: string) {
  return getAllStyles().find((s) => s.id === id);
}

export function getSeasonalTemplate(text: string) {
  for (const t of SEASONAL_TEMPLATES) {
    if (t.keywords.some((k) => text.includes(k))) return t;
  }
  return null;
}

export function checkAntiPatterns(prompt: string) {
  const hits = [];
  for (const ap of ANTI_PATTERNS) {
    if (prompt.toLowerCase().includes(ap.pattern.toLowerCase())) {
      hits.push(ap);
    }
  }
  return hits;
}
