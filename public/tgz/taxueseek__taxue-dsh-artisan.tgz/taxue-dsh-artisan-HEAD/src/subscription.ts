/** 订阅生图凭证桥：读取 dsh-plugin-subscriptions 保存的订阅 accessToken（Grok / ChatGPT codex）。 */
import { readFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join } from 'node:path'

interface SubscriptionEntry {
  accessToken?: unknown
  expiresAt?: unknown
  accountId?: unknown
  account?: unknown
}

function dshHomePath(...segments: string[]): string {
  const root = typeof process.env.DSH_HOME === 'string' && process.env.DSH_HOME.length > 0
    ? process.env.DSH_HOME
    : join(homedir(), '.dsh')
  return join(root, ...segments)
}

/** 一个可用的订阅会话（accessToken 必填；codex 额外需要 accountId）。 */
export interface SubscriptionSession {
  accessToken: string
  accountId?: string
}

function readAccountId(entry: SubscriptionEntry): string | undefined {
  if (typeof entry.accountId === 'string' && entry.accountId.length > 0) return entry.accountId
  const account = entry.account
  if (typeof account === 'object' && account !== null && !Array.isArray(account)) {
    const id = (account as { id?: unknown }).id
    if (typeof id === 'string' && id.length > 0) return id
  }
  return undefined
}

/** 距过期不足该毫秒数时提前刷新，避免用到秒级边界上的 token。 */
const EXPIRY_SKEW_MS = 60_000

interface CacheEntry {
  session: SubscriptionSession
  /** auth.json 中该 entry 的 expiresAt（毫秒时间戳）；无则回退到保守值。 */
  expiresAt: number
  /** 写入缓存的时间，用于无 expiresAt 时的兜底 TTL。 */
  cachedAt: number
}

const cache = new Map<'grok' | 'codex', CacheEntry>()

/** 缓存命中且未临近过期时返回 true。 */
function isFresh(entry: CacheEntry): boolean {
  return Date.now() < entry.expiresAt - EXPIRY_SKEW_MS
}

/** 返回未过期的订阅 accessToken；未登录、已过期或读取失败返回 undefined（不抛错）。磁盘 I/O 在进程生命周期内按 provider 缓存。 */
export async function resolveSubscriptionToken(provider: 'grok' | 'codex'): Promise<SubscriptionSession | undefined> {
  const cached = cache.get(provider)
  if (cached && isFresh(cached)) return cached.session
  try {
    const raw = await readFile(dshHomePath('plugins', 'subscriptions', 'auth.json'), 'utf8')
    const data = JSON.parse(raw) as { grok?: SubscriptionEntry; codex?: SubscriptionEntry }
    const entry = data[provider]
    if (typeof entry !== 'object' || entry === null) return undefined
    const access = entry.accessToken
    if (typeof access !== 'string' || access.length === 0) return undefined
    const expiresAt = entry.expiresAt
    if (typeof expiresAt === 'number' && expiresAt > 0 && Date.now() > expiresAt) return undefined
    const accountId = readAccountId(entry)
    const session: SubscriptionSession = { accessToken: access, ...(accountId !== undefined ? { accountId } : {}) }
    const ttl = typeof expiresAt === 'number' && expiresAt > 0 ? expiresAt : Date.now() + 30 * 60 * 1000
    cache.set(provider, { session, expiresAt: ttl, cachedAt: Date.now() })
    return session
  } catch {
    return undefined
  }
}

/** 返回未过期的 Grok 订阅 accessToken；未登录、已过期或读取失败返回 undefined（不抛错）。 */
export async function resolveGrokSubscriptionToken(): Promise<string | undefined> {
  return (await resolveSubscriptionToken('grok'))?.accessToken
}

/** 返回未过期的 ChatGPT（codex）订阅会话；未登录或已过期返回 undefined（不抛错）。 */
export async function resolveCodexSubscriptionToken(): Promise<SubscriptionSession | undefined> {
  return resolveSubscriptionToken('codex')
}

/** 是否具备可用的 Grok 订阅生图能力。 */
export async function hasGrokSubscription(): Promise<boolean> {
  return (await resolveGrokSubscriptionToken()) !== undefined
}
