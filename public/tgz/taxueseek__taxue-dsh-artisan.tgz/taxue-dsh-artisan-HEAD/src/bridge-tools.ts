/**
 * taxue-imagegen 技能桥工具：把 skill-bridge.ts 的四个桥函数暴露为模型可调用的工具。
 * 描述与参数命名面向模型；桥层只做「调用 + 透传」，能力真源在技能脚本。
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { Context } from '@deepseek-ai/cordis'
import {
  FILL_META_TRACKS,
  SKILL_TRACKS,
  checkImage,
  composePrompt,
  planSlots,
  preflightText,
  type BridgeOptions,
} from './skill-bridge.js'

/** 注册技能桥工具。bridgeOptions 由 apply() 用当下配置现取（设置变更即时生效）。 */
export function registerBridgeTools(ctx: Context, bridgeOptions: () => BridgeOptions): void {
  ctx.tools.register(defineTool({
    name: 'artisan_plan',
    description: '列出 taxue-imagegen 五种创作类型（A 竖版概念海报 / B 手绘群像插画 / C 写实包装 Mockup / D 叙事分镜 / E 多格排版）的选型指引；传 track 时返回该类型的完整槽位清单。做概念海报、群像插画、包装 mockup、分镜、精灵图前先用本工具选型，再按槽位清单用 artisan_compose 组装。',
    parameters: {
      track: {
        type: 'string',
        enum: [...SKILL_TRACKS],
        description: '技能类型；不传返回五种类型的选型指引。',
      },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false, properties: {
          track: { type: 'string', enum: [...SKILL_TRACKS] },
          text: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: value.text }],
    },
    async execute({ track }) {
      const result = await planSlots(bridgeOptions(), track)
      return { text: result.text, ...(result.track !== undefined ? { track: result.track } : {}) }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'artisan_compose',
    description: '按 artisan_plan 给出的槽位清单机械填槽，组装出可直接生图的完整提示词（内嵌静态预检）。缺必填槽会明确失败并把脚本原话带出，不要静默产出半成品；组装成功后把 prompt 原样传给 generate_image，出图后用 artisan_check 验收。',
    parameters: {
      track: {
        type: 'string',
        required: true,
        enum: [...FILL_META_TRACKS],
        description: '技能类型（D 是半机械型，不走本工具）。',
      },
      slots: {
        type: 'array',
        required: true,
        items: { type: 'object', additionalProperties: false, properties: {
          key: { type: 'string', required: true, description: '槽位名，以 artisan_plan 的清单为准。' },
          value: { type: 'string', required: true, description: '槽位取值。' },
        } },
        description: '槽位键值对列表。',
      },
      theme: { type: 'string', description: '类型 B 主题名。' },
      manpu: { type: 'boolean', description: '类型 A 满铺型变体。' },
      allow_partial: { type: 'boolean', description: '允许缺槽/残留槽位（半成品）通过。' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false, properties: {
          prompt: { type: 'string', required: true },
          warnings: { type: 'array', required: true, items: { type: 'string' } },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: [
          `提示词已组装（脚本告警 ${value.warnings.length} 条）：`,
          value.prompt,
          '把上面的提示词原样作为 generate_image 的 prompt 生成图片；出图后用 artisan_check 验收。',
          ...(value.warnings.length > 0 ? [`脚本告警：${value.warnings.join('；')}`] : []),
        ].join('\n'),
      }],
    },
    async execute({ track, slots, theme, manpu, allow_partial }) {
      const result = await composePrompt(bridgeOptions(), {
        track,
        slots: Object.fromEntries(slots.map((slot) => [slot.key, slot.value])),
        ...(theme !== undefined ? { theme } : {}),
        ...(manpu === true ? { manpu: true } : {}),
        ...(allow_partial === true ? { allowPartial: true } : {}),
      })
      return { prompt: result.prompt, warnings: result.warnings }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'artisan_preflight',
    description: '对现成/手写的提示词跑静态预检：命中已知翻车项（色相词、残留槽位、渐变冒充网点等）时给出报告并判不通过。送生图前单独调用；artisan_compose 组装出的提示词已内嵌预检，不必重复调用。',
    parameters: {
      track: {
        type: 'string',
        required: true,
        enum: [...SKILL_TRACKS],
        description: '技能类型。',
      },
      prompt: {
        type: 'string',
        required: true,
        description: '待预检的提示词全文。',
      },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false, properties: {
          ok: { type: 'boolean', required: true },
          report: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: `${value.ok ? '预检通过' : '预检未通过（有 blocker 或待确认项）'}：\n${value.report}` }],
    },
    async execute({ track, prompt }) {
      const result = await preflightText(bridgeOptions(), track, prompt)
      return { ok: result.ok, report: result.report }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'artisan_check',
    description: '对生成图做像素级验收：黑边/文字完整性/顶部留白/格数一致性检查，返回 pass / blocker / pending 三档判定。仅 blocker 允许一次定向重生；文字正确性必须人工逐字核对后以 text 参数传入，未核对不得计 pass。',
    parameters: {
      path: {
        type: 'string',
        required: true,
        description: '待验收图片的绝对路径。',
      },
      track: {
        type: 'string',
        enum: [...SKILL_TRACKS],
        description: '技能类型，默认 A。',
      },
      top: { type: 'boolean', description: '加测顶部留白占比（类型 A 必用）。' },
      text: {
        type: 'string',
        enum: ['ok', 'bad'],
        description: '文案逐字目检结论；不传则脚本判 pending。',
      },
      expect_cells: { type: 'integer', description: '类型 E 声明格数，校验「说的和画的」是否一致。' },
      no_log: { type: 'boolean', description: '不写 runs.csv（跑验证时用）。' },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false, properties: {
          verdict: { type: 'string', required: true, enum: ['pass', 'blocker', 'pending', 'unknown'] },
          report: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: `验收判定：${value.verdict}\n${value.report}` }],
    },
    async execute({ path, track, top, text, expect_cells, no_log }) {
      const result = await checkImage(bridgeOptions(), {
        path,
        ...(track !== undefined ? { track } : {}),
        ...(top === true ? { top: true } : {}),
        ...(text !== undefined ? { text } : {}),
        ...(expect_cells !== undefined ? { expectCells: expect_cells } : {}),
        ...(no_log === true ? { noLog: true } : {}),
      })
      return { verdict: result.verdict, report: result.report }
    },
  }))
}
