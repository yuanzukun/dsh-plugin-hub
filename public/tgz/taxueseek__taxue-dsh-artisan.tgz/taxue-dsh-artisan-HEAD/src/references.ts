/** 参考图输入：把本地参考图编码为各生图供应商可用的内联数据。
 * 默认关闭——只有调用方显式传 `use_reference_images: true` 才读取文件并上传。 */
import { readFile } from 'node:fs/promises'
import { extname } from 'node:path'

/** 一张已编码的内联参考图。 */
export interface InlineReferenceImage {
  /** 纯 base64（无 data: 前缀）。 */
  base64: string
  mediaType: 'image/png' | 'image/jpeg' | 'image/webp'
}

const EXT_MEDIA_TYPES: Record<string, InlineReferenceImage['mediaType']> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
}

/** 单张参考图字节上限（与 DSH attachment 上限对齐，防超限请求）。 */
const MAX_REFERENCE_BYTES = 20 * 1024 * 1024

/** 支持的参考图扩展名集合。 */
export const SUPPORTED_REFERENCE_EXTS = new Set(Object.keys(EXT_MEDIA_TYPES))

/** 读取并把一张本地参考图编码为内联 base64。不支持 GIF（三家生图端均不接受 GIF 输入）。 */
export async function loadInlineReference(path: string): Promise<InlineReferenceImage> {
  const mediaType = EXT_MEDIA_TYPES[extname(path).toLowerCase()]
  if (mediaType === undefined) throw new Error(`不支持的参考图格式 ${extname(path) || '(无扩展名)'}；支持 PNG/JPEG/WebP`)
  const data = await readFile(path)
  if (data.byteLength === 0) throw new Error(`参考图是空文件：${path}`)
  if (data.byteLength > MAX_REFERENCE_BYTES) throw new Error(`参考图超出 ${String(MAX_REFERENCE_BYTES)} 字节上限：${path}`)
  return { base64: Buffer.from(data).toString('base64'), mediaType }
}

/** 批量加载；单张失败抛错并注明是第几张。 */
export async function loadInlineReferences(paths: readonly string[]): Promise<InlineReferenceImage[]> {
  const images: InlineReferenceImage[] = []
  for (let i = 0; i < paths.length; i++) {
    try {
      images.push(await loadInlineReference(paths[i]!))
    } catch (cause) {
      throw new Error(`第 ${String(i + 1)} 张参考图加载失败：${cause instanceof Error ? cause.message : String(cause)}`)
    }
  }
  return images
}
