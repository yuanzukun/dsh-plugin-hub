/** 提示词反推/优化/审计的本地纯函数编译器。不调用远程模型，不读取或上传素材。 */

export const REVERSE_MODES = ['image_reverse', 'video_reverse', 'prompt_optimize', 'meta_prompt'] as const
export const TARGETS = ['image', 'video', 'both'] as const
export const PLATFORMS = [
  'universal',
  'seedream',
  'nano_banana',
  'midjourney',
  'runway',
  'veo',
  'sora',
  'kling',
  'grok',
  'other',
] as const

export type ReverseMode = (typeof REVERSE_MODES)[number]
export type Target = (typeof TARGETS)[number]
export type Platform = (typeof PLATFORMS)[number]
export type OutputLanguage = 'zh-CN' | 'en' | 'bilingual'

export interface ReferenceAsset {
  uri: string
  role?: 'content' | 'composition' | 'color' | 'material' | 'motion' | 'audio' | 'mixed'
  notes?: string
  rights?: 'user_owned' | 'licensed' | 'public_domain' | 'unknown'
}

export interface ReversePromptInput {
  mode: ReverseMode
  target: Target
  platform: Platform
  brief: string
  current_prompt?: string
  reference_assets?: ReferenceAsset[]
  preserve?: string[]
  change?: string[]
  avoid?: string[]
  output_language?: OutputLanguage
  dynamic_charcoal_mode?: boolean
  /** 参考图真实像素宽。模型在 read_image 后把返回的 width 填进来，用于精确还原画幅比例。 */
  image_width?: number
  /** 参考图真实像素高。模型在 read_image 后把返回的 height 填进来，用于精确还原画幅比例。 */
  image_height?: number
}

export interface ReversePromptOutput {
  task_id: string
  task_summary: string
  /** 直出：可直接用于生图的完整提示词（已还原参考图的文字排版、风格与细节）。 */
  prompt: string
  /** 优化方向建议（可执行、单条一个变量）。 */
  optimization_advice: string[]
  /** 参考图推断的画幅建议（如 9:16 / 16:9 / 1:1）。 */
  aspect_ratio: string
  /** 同规格同风格新图引导：生成一张与参考图同尺寸、同风格的新图提示词。 */
  variant_guidance: string
  quality_gate: string[]
  risk_flags: string[]
  clarification_questions: string[]
}

export interface OptimizePromptInput {
  target: Target
  prompt: string
  output_language?: OutputLanguage
  dynamic_charcoal_mode?: boolean
}

export interface OptimizePromptOutput {
  summary: string
  warnings: string[]
  risk_flags: string[]
  next_single_variable_test: string
}

const namedStylePattern = /\b(in\s+the\s+style\s+of|exactly\s+like|copy\s+the\s+style\s+of)\b|模仿|复刻|仿[照制]|像.+(画风|风格)/iu
const protectedIpPattern = /\b(disney|marvel|pokemon|star\s*wars|harry\s*potter)\b|迪士尼|漫威|宝可梦|星球大战|哈利[·・]?波特/iu
const conflictingCameraPattern = /\b(close[- ]?up|macro)\b[\s\S]{0,160}\b(wide\s+shot|aerial|bird'?s-eye)\b|\b(wide\s+shot|aerial|bird'?s-eye)\b[\s\S]{0,160}\b(close[- ]?up|macro)\b/iu
const conflictingMotionPattern = /\b(static\s+camera|locked[- ]?off)\b[\s\S]{0,160}\b(dolly|orbit|crane|pan|tilt|zoom)\b|\b(dolly|orbit|crane|pan|tilt|zoom)\b[\s\S]{0,160}\b(static\s+camera|locked[- ]?off)\b/iu

// 硬冲突审计：同一提示词内不能并存的成对视觉机制。
// 平涂/赛璐璐（硬边分层阴影）与大面积连续柔和明暗互斥；复古手绘制作语言与现代数字渲染语言互斥；
// 洁净表面与扫描颗粒/压缩噪声互斥。
const flatShadingPattern = /\b(cel|cell[- ]?shad\w*|flat\s+(color|shad\w*)|hard[- ]?edge[d]?\s+shad\w*|anime\s+flat)|赛璐璐|平涂|硬边阴影/iu
const softBlendingPattern = /\b(soft\s+(blend\w*|grad\w*|render\w*|light\w*)|smooth\s+(blend\w*|gradient)|continuous\s+(blend\w*|shad\w*))|厚涂|连续混色|柔和渐变|大范围柔光/iu
const retroProductionPattern = /\b(retro|vintage|old[- ]?school|1990s?\s+anime|90s\s+anime|ova|hand[- ]?(drawn|painted)|limited\s+palette)|复古|老动画|手绘轮廓|有限色盘|旧式造型/iu
const modernRenderPattern = /\b(modern\s+(digital|mobile[- ]?game|illustration)|glossy\s+3d|octane|unreal\s+render|trendy\s+webtoon)|现代手游|现代数字插画|3D 塑料感|高清网漫/iu
const cleanSurfacePattern = /\b(clean|pristine|flawless)(\s+(surface|skin|line\w*|background))?|no\s+(grain|noise)|无颗粒|洁净表面|干净背景/iu
const grainSurfacePattern = /\b(scan\s+grain|film\s+grain|noise|grainy|halftone|low[- ]?res(olution)?|compression\s+artifact)|扫描颗粒|胶片颗粒|网点|低清|压缩噪点/iu

function unique(values: readonly string[] | undefined): string[] {
  return [...new Set((values ?? []).map((value) => value.trim()).filter(Boolean))]
}

function clean(value: string | undefined): string {
  return (value ?? '').trim()
}

/** 稳定任务 ID：FNV-1a 散列 brief 种子。 */
function stableTaskId(input: ReversePromptInput): string {
  const seed = `${input.mode}|${input.target}|${input.platform}|${input.brief}`
  let hash = 2166136261
  for (const character of seed) {
    hash ^= character.charCodeAt(0)
    hash = Math.imul(hash, 16777619)
  }
  return `taxue-${(hash >>> 0).toString(36)}`
}

/** 语言解析：zh 为纯中文；en 为纯英文；bilingual 为中文正文 + 关键英文锚点（不整段翻译）。 */
function langOf(input: { output_language?: OutputLanguage }): 'zh' | 'en' | 'bi' {
  if (input.output_language === 'en') return 'en'
  if (input.output_language === 'bilingual') return 'bi'
  return 'zh'
}

const PLATFORM_GUIDANCE: Record<Platform, { zh: string; en: string }> = {
  universal: {
    zh: '保持平台无关的清晰自然语言；将意图、约束与可调参数分开。',
    en: 'Keep platform-agnostic clear natural language; separate intent, constraints, and tunable parameters.',
  },
  seedream: {
    zh: '优先使用中文或双语的自然语言长句，按主体、动作、构图、媒介、光色、约束顺序表达；不要假定权重语法。',
    en: 'Prefer natural-language sentences in Chinese or bilingual, ordered by subject, action, composition, medium, light/color, constraints; do not assume weight syntax.',
  },
  nano_banana: {
    zh: '明确画幅、主体位置、参考图角色、文字内容与局部编辑范围；将必须保留与允许变化分开。',
    en: 'Be explicit about frame, subject position, reference-image roles, text content, and local edit scope; separate must-keep from may-change.',
  },
  midjourney: {
    zh: '把视觉内容先写完，再把画幅和可选参数置于末尾；不把平台参数当作内容描述。',
    en: 'Write the visual content first, then put frame and optional parameters at the end; do not treat platform parameters as content description.',
  },
  runway: {
    zh: '若为视频，优先写主体动作、环境反应与单一相机运动；不要重复描述参考图中已经固定的外观。',
    en: 'For video, prioritize subject motion, environment reaction, and a single camera move; do not re-describe appearance already fixed in reference frames.',
  },
  veo: {
    zh: '视频按摄影、主体、动作、环境、氛围和必要的声音事件分层；每个镜头只设定一个主相机运动。',
    en: 'For video, layer photography, subject, action, environment, mood, and necessary sound events; set one primary camera move per shot.',
  },
  sora: {
    zh: '强调镜头连续性、时间顺序、主体一致性与可见的物理因果；避免单条提示中塞入多场戏。',
    en: 'Emphasize camera continuity, temporal order, subject consistency, and visible physical causality; avoid cramming multiple scenes into one prompt.',
  },
  kling: {
    zh: '明确时长、镜头运动、主体动作、环境反应与镜头切换；将复杂叙事拆分为镜头。',
    en: 'Be explicit about duration, camera moves, subject motion, environment reaction, and cuts; split complex narratives into shots.',
  },
  grok: {
    zh: '用清晰自然语言描述主体、构图、媒介、光色与约束；支持 aspect_ratio 与 resolution 参数但不写入内容描述。',
    en: 'Describe subject, composition, medium, light/color, and constraints in clear natural language; support aspect_ratio and resolution parameters without writing them into content.',
  },
  other: {
    zh: '先保留平台无关的结构化意图，再由用户补充该平台支持的参数与限制。',
    en: 'Keep platform-agnostic structured intent first, then let the user supply that platform\'s supported parameters and limits.',
  },
}

const MEDIA_LABEL: Record<Target, { zh: string; en: string }> = {
  video: { zh: '视频任务', en: 'video task' },
  image: { zh: '图像任务', en: 'image task' },
  both: { zh: '图像与视频混合任务', en: 'image and video mixed task' },
}

function platformGuidance(platform: Platform, target: Target, lang: 'zh' | 'en'): string {
  const entry = PLATFORM_GUIDANCE[platform]
  const media = MEDIA_LABEL[target]
  return lang === 'en'
    ? `Platform compilation principle for this ${media.en}: ${entry.en}`
    : `${media.zh}的平台编译原则：${entry.zh}`
}

const CHARCOAL_ZH = `
## 可选桥接：炭笔动态万物速写

用户已启用动态炭笔/墨彩模式。除一般视觉反推外，额外执行：

1. 先锁定主体类别、一个受力事件、主轴、深黑锚点与向纸白淡出的余势。
2. 若需要抓拍感，从临界瞬间、动作主轴、镜头视角、画框切边、清晰锚点、时间残线、方向性留白中选择 3—5 项；夸张只能沿透视和受力方向发生。
3. 仅在用户要求颜色时采用有限矿物色：accent 约 5%–10%，visible 约 15%–25%，color-led 约 25%–45%。清晰彩色模式必须写出色相、运动面、覆盖范围，并说明“颜色在正常观看尺寸下清晰可见，不是灰阶”。
4. 不要使用摄影式全图 motion blur 代替手绘余势；不要复制具体新闻影像、摄影师、艺术家或作品。
`

const CHARCOAL_EN = `
## Optional bridge: dynamic charcoal gesture sketching

The user enabled dynamic charcoal/ink mode. In addition to general visual reverse-engineering, also:

1. First pin down the subject category, one force event, the main axis, a deep-black anchor, and the momentum fading toward paper white.
2. If a candid feel is wanted, pick 3–5 from: critical instant, action axis, camera angle, frame crop, sharp anchor, time residue lines, directional negative space; exaggeration may only follow perspective and force direction.
3. Use limited mineral color only when the user asks for color: accent ~5%–10%, visible ~15%–25%, color-led ~25%–45%. A clearly colored mode must state hue, moving surface, and coverage, and note that “the color is clearly visible at a normal viewing size, not grayscale.”
4. Do not use photographic full-frame motion blur to stand in for hand-drawn momentum; do not reproduce specific news footage, photographer, artist, or work.
`

function charcoalBridge(enabled: boolean | undefined, lang: 'zh' | 'en'): string {
  if (!enabled) return ''
  return lang === 'en' ? CHARCOAL_EN : CHARCOAL_ZH
}

/**
 * 视觉还原锚点（图像反推专用编译指令）。
 *
 * 为本插件「直出编译器」形态量身定做的方法论（画幅必判、风格判定硬规则、构图互斥、
 * 负向约束克制、文字照抄、IP 锚点）：
 * 提炼为 9 个可量化的还原锚点，每个锚点有明确的通过标准，
 * 供下游生图模型逐条复现。缺信息时要求写「未观察到」，防止模型编造细节。
 */
const REVERSE_METHODOLOGY_ZH = `
## 视觉还原锚点（编译指令，逐条执行；缺信息的锚点写「未观察到」，禁止编造）

1. 画幅锚点：最终提示词第一句必须写死「画幅比例：<真实比例>。」，正文不得再出现第二个比例。
2. 气质锚点：首段用一句锁定总体视觉气质，媒介感优先于局部细节（如「媒介质感优先的写实影像」「冷灰低饱和胶片感」「高饱和商业插画」）。
3. 风格锚点：先写可观察证据再给风格名，禁止编造风格：闭合线稿+平面固有色+覆盖大区域的 1-2 层硬边阴影同时成立→赛璐璐/平涂；线稿明显弱化+大区域连续混色/材质体积塑形→厚涂；二者皆非且明暗连续→柔和渲染/写实；不确定时写「线稿保留型柔和渲染」并给证据。
4. 表面层锚点：扫描颗粒/柔焦/低清压缩/色偏/网点是成像表面层，只描述其作用区域，不得解释成材质内部塑形或纹理。
5. 构图锚点：景别、主体位置、留白方向、裁切与观看视角各一句；禁止冲突景别（如「中近景全身」「半身全身」）。
6. 光色材质锚点：主光源方向、冷暖、饱和度，以及关键材质（船体/木纹/漆面/金属/织物/皮肤）的固有色、高光与反射方式。
7. 主体锚点：主体身份、标志性轮廓、配色、专属道具；只有 ≥3 项独立锚点一致才写具体 IP/角色/品牌名，否则写「原创或身份未确认」。
8. 文字锚点：参考图中的可见文字逐字照抄，注明字体风格、横排/竖排与对齐方式。
9. 负向锚点：只保留 2-5 个最可能发生的画风跑偏风险（如现代手游立绘化、默认萌系大眼、3D 塑料感、纸纹覆盖五官、辅助风格升级成主风格）；原图本身具备的特征不得列入；无风险时写「无额外负向约束」。
`

const REVERSE_METHODOLOGY_EN = `
## Visual reconstruction anchors (compile instructions; execute each one; write "not observed" for missing anchors, never fabricate)

1. Frame anchor: the final prompt must start with "Aspect ratio: <real ratio>." and contain no second ratio elsewhere.
2. Mood anchor: open with one sentence locking the overall visual mood, medium feel before local detail (e.g. "medium-first photoreal", "cold gray desaturated film", "high-saturation commercial illustration").
3. Style anchor: cite observable evidence before naming a style, never invent one: closed linework + flat local color + 1-2 hard-edge shadow layers over most area → cel/flat shading; clearly weakened linework + large continuous blending/material volume → thick paint; neither with continuous shading → soft render/photoreal; when unsure write "soft render with retained linework" and give evidence.
4. Surface-layer anchor: scan grain/soft-focus/low-res compression/color cast/halftone are imaging surface layers; describe only where they act, never reframe them as material internal shading or texture.
5. Composition anchor: one sentence each for shot size, subject position, negative space, crop, and viewing angle; no conflicting shot sizes (e.g. "medium-full body", "half-full body").
6. Light/color/material anchor: key light direction, warmth, saturation, and the local color, specular and reflection of critical materials (hull/wood grain/paint/metal/fabric/skin).
7. Subject anchor: identity, signature silhouette, palette, signature props; write a concrete IP/character/brand name only when ≥3 independent anchors match, otherwise "original or unidentified subject".
8. Text anchor: transcribe visible text verbatim, noting font style, horizontal/vertical layout and alignment.
9. Negative anchor: keep only 2-5 most likely style-drift risks (e.g. modern mobile-game illustration, default cute big eyes, 3D plastic look, paper texture over facial features, auxiliary style escalating to main style); never list features the source already has; write "no extra negative constraints" when there is no risk.
`

function reverseMethodology(lang: 'zh' | 'en'): string {
  return lang === 'en' ? REVERSE_METHODOLOGY_EN : REVERSE_METHODOLOGY_ZH
}

/** 生图供应商支持的标准画幅（Grok/Seedream 扩展集）。 */
const RATIO_BANDS: ReadonlyArray<{ ratio: string; w: number; h: number }> = [
  { ratio: '1:1', w: 1, h: 1 },
  { ratio: '4:3', w: 4, h: 3 },
  { ratio: '3:4', w: 3, h: 4 },
  { ratio: '3:2', w: 3, h: 2 },
  { ratio: '2:3', w: 2, h: 3 },
  { ratio: '16:9', w: 16, h: 9 },
  { ratio: '9:16', w: 9, h: 16 },
  { ratio: '2:1', w: 2, h: 1 },
  { ratio: '1:2', w: 1, h: 2 },
  { ratio: '19.5:9', w: 19.5, h: 9 },
  { ratio: '9:19.5', w: 9, h: 19.5 },
  { ratio: '20:9', w: 20, h: 9 },
  { ratio: '9:20', w: 9, h: 20 },
]

/** 由真实像素宽高取最接近的标准画幅（角度差最小）。输入非法或为 0 时返回 undefined。 */
function aspectRatioFromDimensions(width: number | undefined, height: number | undefined): string | undefined {
  if (typeof width !== 'number' || typeof height !== 'number' || !Number.isFinite(width) || !Number.isFinite(height)) return undefined
  if (width <= 0 || height <= 0) return undefined
  const source = width / height
  let best: string | undefined
  let bestAngle = Number.POSITIVE_INFINITY
  for (const band of RATIO_BANDS) {
    const target = band.w / band.h
    // 用两条射线的夹角量化偏差，避免简单除法被极端比例带偏。
    const angle = Math.abs(Math.atan2(source, 1) - Math.atan2(target, 1))
    if (angle < bestAngle) {
      bestAngle = angle
      best = band.ratio
    }
  }
  return best
}

/**
 * 从 brief 推断画幅建议（启发式）。
 *
 * 优先级：参考图真实像素（image_width/image_height）→ 文本语义（横版/竖版/方形）→ 1:1。
 * 真实像素是唯一精确来源；文本启发式只作后备，防止 brief 没提画幅时误判。
 */
function aspectRatioOf(input: ReversePromptInput): string {
  const fromPixels = aspectRatioFromDimensions(input.image_width, input.image_height)
  if (fromPixels !== undefined) return fromPixels
  const text = `${input.brief} ${unique(input.preserve).join(' ') || ''}`.toLowerCase()
  if (/(横版|横图|横向|16\s*[:：]\s*9|3\s*[:：]\s*2|landscape|horizontal|banner)/.test(text)) return '16:9'
  if (/(竖版|竖图|竖向|9\s*[:：]\s*16|2\s*[:：]\s*3|3\s*[:：]\s*4|portrait|vertical)/.test(text)) return '9:16'
  if (/(方形|方图|正方形|square|1\s*[:：]\s*1)/.test(text)) return '1:1'
  return '1:1'
}

/** 从真实像素比例推导可读描述（用于提示词第一句），无像素时回退为建议比例文案。 */
function aspectRatioSentence(input: ReversePromptInput, lang: 'zh' | 'en'): string {
  const fromPixels = aspectRatioFromDimensions(input.image_width, input.image_height)
  if (fromPixels !== undefined) {
    const dimensionText = Number.isFinite(input.image_width) && Number.isFinite(input.image_height)
      ? `（参考图真实 ${input.image_width}×${input.image_height}px，最接近标准比 ${fromPixels}）`
      : ''
    const dimensionTextEn = Number.isFinite(input.image_width) && Number.isFinite(input.image_height)
      ? ` (source is ${input.image_width}×${input.image_height}px, nearest standard ratio ${fromPixels})`
      : ''
    return lang === 'en'
      ? `Aspect ratio: ${fromPixels}${dimensionTextEn}.`
      : `画幅比例：${fromPixels}${dimensionText}。`
  }
  const ratio = aspectRatioOf(input)
  const sourceHint = ratio === '1:1' ? '（无参考图尺寸信息时的默认值，生图前请按参考图实际比例校准）' : '（由描述推断，生图前请按参考图实际比例校准）'
  const sourceHintEn = ratio === '1:1' ? ' (default without source dimensions; calibrate against the reference before generating)' : ' (inferred from description; calibrate against the reference before generating)'
  return lang === 'en'
    ? `Aspect ratio: ${ratio}${sourceHintEn}.`
    : `画幅比例：${ratio}${sourceHint}。`
}

const DIMENSION_HINTS: Record<string, { zh: RegExp; en: RegExp }> = {
  text: {
    zh: /(文字|排版|标题|字体|版式|文案|字|竖排|横排)/,
    en: /(text|typography|title|font|layout|caption|letter)/,
  },
  color: {
    zh: /(色|配色|色调|色彩|palette|色板)/,
    en: /(color|palette|hue|tone)/,
  },
  composition: {
    zh: /(构图|布局|居中|留白|裁切|视角|景别|对称|层次)/,
    en: /(composition|layout|center|negative space|crop|angle|framing)/,
  },
  light: {
    zh: /(光|光照|光线|打光|阴影|柔光|逆光)/,
    en: /(light|lighting|shadow|glow|backlight)/,
  },
  material: {
    zh: /(材质|质感|纹理|纸张|颗粒|纤维|布料)/,
    en: /(material|texture|grain|paper|fiber|fabric)/,
  },
}

/** 基于 brief 覆盖度给可执行的优化方向建议（每一条一个变量）。 */
function optimizationAdvice(input: ReversePromptInput, lang: 'zh' | 'en'): string[] {
  const text = `${input.brief} ${input.current_prompt ?? ''}`.toLowerCase()
  const advice: string[] = []
  const push = (zh: string, en: string) => advice.push(lang === 'en' ? en : zh)
  const hints = DIMENSION_HINTS
  if (!hints.text!.zh.test(text) && !hints.text!.en.test(text)) {
    push('补足文字排版细节：写出具体文字内容、字体风格、字号层级、横排/竖排与对齐方式（参考图中的中文文字需原文照抄）。', 'Add typography detail: write the exact text content, font style, size hierarchy, horizontal/vertical layout, and alignment (verbatim Chinese text from the reference).')
  }
  if (!hints.color!.zh.test(text) && !hints.color!.en.test(text)) {
    push('明确配色方案：写清主色、辅色与点缀色的色相/明度，以及占比。', 'Specify the palette: dominant, secondary and accent hues with lightness and proportions.')
  }
  if (!hints.composition!.zh.test(text) && !hints.composition!.en.test(text)) {
    push('补足构图与布局：写清主体位置、留白方向、裁切与观看视角。', 'Add composition: subject position, negative space, crop, and viewing angle.')
  }
  if (!hints.light!.zh.test(text) && !hints.light!.en.test(text)) {
    push('补足光照描述：写清主光源方向、冷暖倾向、阴影硬度与高光位置。', 'Add lighting: key light direction, warm/cool tendency, shadow hardness, and highlight placement.')
  }
  if (!hints.material!.zh.test(text) && !hints.material!.en.test(text)) {
    push('补充媒介与质感：写清纸张/纹理/颗粒等材质细节。', 'Add medium and texture: paper, grain, fiber or other material details.')
  }
  if (advice.length === 0) {
    push('保持当前信息量；下一轮只测一个高杠杆变量（例如仅改变主体位置与前方留白）。', 'Keep the current detail level; next round change one high-leverage variable only (e.g. subject position and forward negative space).')
  }
  return advice
}

/** 同规格同风格新图引导：以参考图的画幅、风格与文字排版为模板，生成一张新内容的图。
 * 变体纪律：锁全部风格维度，只换 2-4 个非风格维度，变化幅度 20%-40%。 */
function variantGuidance(input: ReversePromptInput, aspectRatio: string, lang: 'zh' | 'en'): string {
  const newSubject = clean(input.brief).split(/[\n，。；,.;]/)[0]?.slice(0, 60) || '新的主题'
  return lang === 'en'
    ? `Generate a NEW image in the SAME style, aspect ratio (${aspectRatio}) and typography system as the reference, but with a different subject: ${JSON.stringify(newSubject)}. Lock every style dimension (medium, linework/shading mechanism, palette system, surface grain, layout discipline); vary only 2-4 non-style dimensions among subject content, pose, gaze, clothing, props, background or composition, with a 20%-40% change amplitude. Replace only the central content.`
    : `请以参考图同样的风格、画幅（${aspectRatio}）与文字排版体系，创作一张新内容的图：${JSON.stringify(newSubject)}。锁定全部风格维度（媒介、线条/明暗机制、配色体系、表面颗粒、版式纪律）；只在主体内容、姿态、视线、服装、道具、背景或构图中选 2-4 个非风格维度做 20%-40% 幅度的变化；只替换中心内容。`
}

/** 把「保持/可改/避免」三组约束转成一段自然约束句（无约束时返回空串）。 */
function naturalConstraints(input: { preserve: string[]; change: string[]; avoid: string[] }, lang: 'zh' | 'en'): string {
  const lines: string[] = []
  if (input.preserve.length) lines.push(lang === 'en' ? `Keep: ${input.preserve.join('; ')}.` : `保持：${input.preserve.join('；')}。`)
  if (input.change.length) lines.push(lang === 'en' ? `May change: ${input.change.join('; ')}.` : `可改：${input.change.join('；')}。`)
  if (input.avoid.length) lines.push(lang === 'en' ? `Avoid: ${input.avoid.join('; ')}.` : `避免：${input.avoid.join('；')}。`)
  return lines.join(' ')
}

/** 动态炭笔/墨彩要求：转成自然描述句，随 main prompt 发出（不再单独成节）。 */
function charcoalNatural(lang: 'zh' | 'en'): string {
  return lang === 'en'
    ? 'Dynamic charcoal gesture sketch: lock the subject category, one force event and the main axis, with a deep-black anchor fading toward paper white; for a candid feel pick 3-5 from critical instant, action axis, camera angle, frame crop, sharp anchor, time residue lines and directional negative space, exaggerating only along perspective and force. Use limited mineral color only when asked (accent about 5-10%, visible 15-25%, color-led 25-45%); a clearly colored mode must state hue, moving surface and coverage, and note the color is clearly visible at a normal viewing size, not grayscale. Do not substitute full-frame photographic motion blur for hand-drawn momentum, and do not reproduce specific news footage, photographer, artist or work.'
    : '动态炭笔速写：先锁定主体类别、一个受力事件与主轴，深黑锚点向纸白淡出；若需抓拍感，从临界瞬间、动作主轴、镜头视角、画框切边、清晰锚点、时间残线、方向性留白中选 3-5 项，夸张只沿透视与受力方向；仅在用户要求颜色时用有限矿物色（accent 约 5-10%，visible 约 15-25%，color-led 约 25-45%），清晰彩色模式必须写出色相、运动面、覆盖范围，并说明颜色在正常观看尺寸下清晰可见；不要用全图摄影式运动模糊代替手绘余势，也不要复刻具体新闻影像、摄影师、艺术家或作品。'
}

/** 直出提示词：组织成一段可生图的自然语言描述。第一句锁定画幅，brief 原样融入，约束转成自然句。不再使用章节/JSON/方法论模板。 */
function buildDirectPrompt(input: ReversePromptInput, lang: 'zh' | 'en' | 'bi'): string {
  const brief = clean(input.brief)
  const preserve = unique(input.preserve)
  const change = unique(input.change)
  const avoid = unique(input.avoid)
  const zx = lang === 'en' ? 'en' : 'zh'
  const parts: string[] = []
  parts.push(aspectRatioSentence(input, zx))
  if (brief) parts.push(brief)
  const constraints = naturalConstraints({ preserve, change, avoid }, zx)
  if (constraints) parts.push(constraints)
  if (input.dynamic_charcoal_mode) parts.push(charcoalNatural(zx))
  return parts.filter((s) => s.length > 0).join('\n\n')
}

const RISK_FLAGS: Record<string, { zh: string; en: string }> = {
  styleImitation: {
    zh: '检测到可能的直接风格模仿措辞：请改写为媒介、构图、光线、色彩、材质与动态等可观察属性。',
    en: 'Possible direct style-imitation wording detected: rewrite it into observable attributes such as medium, composition, light, color, material, and motion.',
  },
  ip: {
    zh: '检测到可能涉及受保护角色、品牌或影视 IP：请确认授权或改为原创、非专名的视觉特征。',
    en: 'Possible protected character, brand, or film/TV IP detected: confirm rights or switch to original, non-proprietary visual traits.',
  },
  rightsUnknown: {
    zh: '至少一项参考资产的权利状态未知：在公开或商业使用前请人工确认来源、授权与肖像/声音同意。',
    en: 'At least one reference asset has unknown rights status: confirm source, license, and portrait/voice consent manually before public or commercial use.',
  },
  videoReverse: {
    zh: '视频反推对遮挡、镜外空间、不可见镜头参数和音源位置只应输出带置信度的推断，不应宣称逐帧还原。',
    en: 'For video reverse-engineering, only output confidence-labeled inferences for occlusions, off-screen space, invisible camera parameters, and sound source positions; never claim frame-by-frame recovery.',
  },
  imageReverse: {
    zh: '图像反推仅输出可解释的提示词重建假设，不应宣称获得真实原提示词。',
    en: 'Image reverse-engineering only outputs an explainable prompt-reconstruction hypothesis; it must not claim the true original prompt.',
  },
}

function collectRisks(input: ReversePromptInput, lang: 'zh' | 'en'): string[] {
  const text = [input.brief, input.current_prompt, ...(input.preserve ?? []), ...(input.change ?? []), ...(input.avoid ?? [])].join('\n')
  const flags: string[] = []
  const textKey = (key: 'styleImitation' | 'ip' | 'rightsUnknown' | 'videoReverse' | 'imageReverse') => RISK_FLAGS[key]![lang]
  if (namedStylePattern.test(text)) flags.push(textKey('styleImitation'))
  if (protectedIpPattern.test(text)) flags.push(textKey('ip'))
  if ((input.reference_assets ?? []).some((asset) => asset.rights === 'unknown')) flags.push(textKey('rightsUnknown'))
  if (input.mode === 'video_reverse') flags.push(textKey('videoReverse'))
  if (input.mode === 'image_reverse') flags.push(textKey('imageReverse'))
  return flags
}

const CLARIFY: Record<string, { zh: string; en: string }> = {
  currentPrompt: {
    zh: '请提供需要优化的现有提示词，或说明它在生成结果中具体失败的地方。',
    en: 'Please provide the existing prompt to optimize, or describe how it fails in the generated result.',
  },
  referenceAssets: {
    zh: '请提供参考素材、关键帧、分镜或更完整的可观察描述；没有素材时，反推只能作为概念性假设。',
    en: 'Please provide reference material, keyframes, storyboards, or a fuller observable description; without material, reverse-engineering can only be a conceptual hypothesis.',
  },
  videoDuration: {
    zh: '视频任务建议补充目标时长、镜头数量和是否需要声音；未提供时将按短单镜头原型处理。',
    en: 'For video, consider adding target duration, shot count, and whether sound is needed; otherwise a short single-shot prototype is assumed.',
  },
  otherPlatform: {
    zh: '请补充目标平台或模型的版本与参数能力，以便生成可直接粘贴的适配版本。',
    en: 'Please supply the target platform/model version and parameter capabilities so a directly pastable adapted version can be produced.',
  },
}

function clarificationQuestions(input: ReversePromptInput, lang: 'zh' | 'en'): string[] {
  const questions: string[] = []
  const key = (name: string) => (CLARIFY as Record<string, { zh: string; en: string }>)[name]![lang]
  if (!clean(input.current_prompt) && input.mode === 'prompt_optimize') questions.push(key('currentPrompt'))
  if ((input.mode === 'image_reverse' || input.mode === 'video_reverse') && (input.reference_assets?.length ?? 0) === 0) questions.push(key('referenceAssets'))
  if (input.target === 'video' && !/\b(秒|s|second|duration|时长|镜头|shot)\b/iu.test(input.brief)) questions.push(key('videoDuration'))
  if (input.platform === 'other') questions.push(key('otherPlatform'))
  return questions
}


const QUALITY_GATE = {
  base: [
    { zh: '证据账本必须区分 observed、inferred 与 unknown，不能把创作推断包装成视觉事实。', en: 'The evidence ledger must distinguish observed, inferred, and unknown; never dress creative inference up as visual fact.' },
    { zh: '提示词必须显式覆盖用户的保留项、修改项与排除项；冲突项进入风险清单。', en: 'The prompt must explicitly cover the user\'s preserve, change, and avoid lists; conflicts go into the risk list.' },
  ],
  video: { zh: '每个镜头记录一个主相机运动、主体运动与独立音画事件；时间码不可重叠。', en: 'Every shot records one primary camera move, subject motion, and separate audio/visual events; timecodes must not overlap.' },
  image: { zh: '图像提示词应明确主体、空间层次、构图/视角、光色材质与文字约束（如有）。', en: 'The image prompt should specify subject, spatial layers, composition/viewpoint, light/color/material, and text constraints (if any).' },
  iteration: { zh: '输出一条基线方案和一条单变量测试建议，不用无止境形容词堆叠替代迭代。', en: 'Output one baseline and one single-variable test suggestion; do not substitute endless adjective stacking for iteration.' },
} as const

/** 主反推工具：直出可生图提示词 + 优化建议 + 画幅建议 + 新图引导。 */
export function reversePrompt(input: ReversePromptInput): ReversePromptOutput {
  if (!clean(input.brief)) throw new Error('brief 不能为空')
  // Bug B：mode×target 媒介一致性校验。
  if (input.mode === 'image_reverse' && input.target === 'video') throw new Error('mode=image_reverse 与 target=video 矛盾：图像反推需 target=image 或 both。')
  if (input.mode === 'video_reverse' && input.target === 'image') throw new Error('mode=video_reverse 与 target=image 矛盾：视频反推需 target=video 或 both。')
  const lang = langOf(input)
  const zx = lang === 'en' ? 'en' : 'zh' // zh 与 bi 统一走中文文案层
  const taskId = stableTaskId(input)
  const risks = collectRisks(input, zx)
  const questionList = clarificationQuestions(input, zx)
  const assets = input.reference_assets?.length ?? 0
  const aspectRatio = aspectRatioOf(input)
  const prompt = buildDirectPrompt(input, lang)
  const advice = optimizationAdvice(input, zx)
  const variant = variantGuidance(input, aspectRatio, zx)
  const isVideo = input.target === 'video' || input.mode === 'video_reverse'
  const qualityGate = [
    QUALITY_GATE.base[0][zx],
    QUALITY_GATE.base[1][zx],
    (isVideo ? QUALITY_GATE.video : QUALITY_GATE.image)[zx],
    QUALITY_GATE.iteration[zx],
  ]
  const summary = lang === 'en'
    ? `Reverse-engineered a ${input.target} prompt for ${input.platform} with ${assets} reference asset(s).`
    : `已为 ${input.target} 任务直出可生图提示词（平台 ${input.platform}，登记 ${assets} 项参考资产）。`
  return {
    task_id: taskId,
    task_summary: summary,
    prompt,
    optimization_advice: advice,
    aspect_ratio: aspectRatio,
    variant_guidance: variant,
    quality_gate: qualityGate,
    risk_flags: risks,
    clarification_questions: questionList,
  }
}

const OPTIMIZE: Record<string, { zh: string; en: string }> = {
  short: {
    zh: '提示词信息量偏低：建议补足主体、动作/状态、空间、构图/镜头、光色材质和关键约束。',
    en: 'Prompt carries too little information: consider adding subject, action/state, space, composition/camera, light/color/material, and key constraints.',
  },
  cameraVideo: {
    zh: '视频提示词未明确相机策略：建议只指定一个主相机运动，或明确固定机位。',
    en: 'Video prompt lacks a camera strategy: specify one primary camera move, or state a locked-off camera explicitly.',
  },
  motionVideo: {
    zh: '视频提示词缺少主体动作或状态变化：建议补充起始、变化和结束的可见因果。',
    en: 'Video prompt lacks subject motion or state change: add the visible cause-and-effect from start through change to end.',
  },
  compositionImage: {
    zh: '图像提示词缺少构图或视角：建议补充景别、主体位置、画幅、留白或裁切。',
    en: 'Image prompt lacks composition or viewpoint: add shot size, subject position, frame, negative space, or crop.',
  },
  cameraConflict: {
    zh: '检测到可能冲突的同镜头景别：请拆分为镜头，或指定哪个景别优先。',
    en: 'Possible conflicting shot sizes in the same shot detected: split into shots, or specify which size takes priority.',
  },
  motionConflict: {
    zh: '检测到可能冲突的相机运动：请保留一个主运动，或改为多镜头结构。',
    en: 'Possible conflicting camera moves detected: keep one primary move, or switch to a multi-shot structure.',
  },
  styleRisk: {
    zh: '可能包含直接模仿特定风格的措辞：请改为可观察的媒介、构图、光色和材质特征。',
    en: 'Possible wording that directly imitates a specific style: rewrite into observable medium, composition, light/color, and material traits.',
  },
  ipRisk: {
    zh: '可能涉及受保护角色、品牌或影视 IP：请确认授权或改为原创特征。',
    en: 'Possible protected character, brand, or film/TV IP: confirm rights or switch to original traits.',
  },
  charcoal: {
    zh: '已启用炭笔动态模式，但提示词未写出媒介、纸张或有限色彩规则。',
    en: 'Dynamic charcoal mode is on, but the prompt does not state medium, paper, or limited-color rules.',
  },
  flatSoftConflict: {
    zh: '硬冲突：平涂/赛璐璐的硬边分层阴影与大面积连续柔和明暗不能并存——请二选一，或把柔光限定到局部（如皮肤高光）。',
    en: 'Hard conflict: cel/flat hard-edge layered shading and large-area continuous soft blending cannot coexist — pick one, or restrict softness to local highlights (e.g. skin).',
  },
  retroModernConflict: {
    zh: '硬冲突：复古手绘制作语言与现代数字渲染语言不能并存——锁定一个时代/工艺层，删除另一个。',
    en: 'Hard conflict: retro hand-drawn production language and modern digital rendering language cannot coexist — lock one era/craft layer and drop the other.',
  },
  cleanGrainConflict: {
    zh: '硬冲突：洁净无噪表面与扫描颗粒/低清压缩质感不能并存——请明确表面层只作用于哪个区域。',
    en: 'Hard conflict: pristine clean surface and scan grain / low-res compression texture cannot coexist — state which region the surface layer affects.',
  },
  summary: {
    zh: '已完成 {target} 提示词的本地结构审计；发现 {warnings} 项可执行警示与 {risks} 项风险提示。',
    en: 'Local structural audit of the {target} prompt complete; {warnings} actionable warnings and {risks} risk flags found.',
  },
  nextVideo: {
    zh: '下一轮只测试“固定机位 vs. 单一侧向跟拍”之一，保持主体动作与场景不变。',
    en: 'Next round, test only "locked-off vs. a single lateral tracking shot," keeping subject motion and scene unchanged.',
  },
  nextImage: {
    zh: '下一轮只测试“主体位置与前方留白”这一变量，保持主体、光色与材质不变。',
    en: 'Next round, test only the "subject position and forward negative space" variable, keeping subject, light/color, and material unchanged.',
  },
}

/** 前置诊断器：只做本地结构审计，不评判审美。 */
export function optimizePrompt(input: OptimizePromptInput): OptimizePromptOutput {
  const prompt = clean(input.prompt)
  if (!prompt) throw new Error('prompt 不能为空')
  const lang = langOf(input)
  const zx = lang === 'en' ? 'en' : 'zh' // zh 与 bi 统一走中文文案层
  const warnings: string[] = []
  const riskFlags: string[] = []
  const k = (name: string) => (OPTIMIZE as Record<string, { zh: string; en: string }>)[name]![zx]

  if (prompt.length < 80) warnings.push(k('short'))
  if (input.target === 'video' && !/\b(camera|dolly|pan|tilt|orbit|static|镜头|推镜|摇镜|跟拍|相机)\b/iu.test(prompt)) warnings.push(k('cameraVideo'))
  if (input.target === 'video' && !/\b(move|walk|run|turn|open|fall|flow|动作|移动|奔跑|旋转|展开|倾倒|流动)\b/iu.test(prompt)) warnings.push(k('motionVideo'))
  if (input.target === 'image' && !/\b(composition|framing|angle|close|wide|构图|视角|近景|远景|留白|裁切)\b/iu.test(prompt)) warnings.push(k('compositionImage'))
  if (conflictingCameraPattern.test(prompt)) warnings.push(k('cameraConflict'))
  if (conflictingMotionPattern.test(prompt)) warnings.push(k('motionConflict'))
  // 硬冲突审计：成对互斥的视觉机制同时出现即报警（进 warnings，语义比风险更强）。
  if (flatShadingPattern.test(prompt) && softBlendingPattern.test(prompt)) warnings.push(k('flatSoftConflict'))
  if (retroProductionPattern.test(prompt) && modernRenderPattern.test(prompt)) warnings.push(k('retroModernConflict'))
  if (cleanSurfacePattern.test(prompt) && grainSurfacePattern.test(prompt)) warnings.push(k('cleanGrainConflict'))
  if (namedStylePattern.test(prompt)) riskFlags.push(k('styleRisk'))
  if (protectedIpPattern.test(prompt)) riskFlags.push(k('ipRisk'))
  if (input.dynamic_charcoal_mode && !/\b(charcoal|graphite|ink wash|炭笔|石墨|墨彩|留白|paper)\b/iu.test(prompt)) warnings.push(k('charcoal'))

  const next = input.target === 'video' ? k('nextVideo') : k('nextImage')

  return {
    summary: (lang === 'en' ? OPTIMIZE.summary!.en : OPTIMIZE.summary!.zh)
      .replace('{target}', input.target)
      .replace('{warnings}', String(warnings.length))
      .replace('{risks}', String(riskFlags.length)),
    warnings,
    risk_flags: riskFlags,
    next_single_variable_test: next,
  }
}
