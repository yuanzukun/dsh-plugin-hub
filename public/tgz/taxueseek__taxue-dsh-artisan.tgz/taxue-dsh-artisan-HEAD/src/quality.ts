/**
 * 原生质量审计：从 skill-optimizer 吸纳精华。
 *
 * 七维诊断打分 + 基线门控 + 修复建议
 */

// ─── 七维诊断 ───
export const SEVEN_DIMENSIONS = [
  { id: 'intent', name: '意图识别', weight: 0.20, desc: '是否准确理解用户需求' },
  { id: 'style', name: '风格精度', weight: 0.20, desc: '风格模板是否精确匹配' },
  { id: 'params', name: '参数完整', weight: 0.15, desc: '参数化是否完整' },
  { id: 'constraint', name: '约束遵守', weight: 0.15, desc: '是否遵守六不变式和反模式' },
  { id: 'evidence', name: '依据反馈', weight: 0.10, desc: '是否有依据支撑' },
  { id: 'output', name: '输出质量', weight: 0.10, desc: '输出是否可直接使用' },
  { id: 'efficiency', name: '效率', weight: 0.10, desc: '是否高效无浪费' },
];

// ─── 基线门控 ───
export const BASELINE_GATES = [
  { id: 'no-anti-pattern', name: '无反模式', check: (prompt: string) => !hasAntiPattern(prompt) },
  { id: 'six-invariants', name: '六不变式齐全', check: (prompt: string) => hasSixInvariants(prompt) },
  { id: 'style-matched', name: '风格匹配', check: (prompt: string) => hasStyleMatch(prompt) },
  { id: 'params-complete', name: '参数完整', check: (prompt: string) => hasCompleteParams(prompt) },
];

function hasAntiPattern(prompt: string) {
  const antiPatterns = ['第三色相', '渐变冒充网点', '霓虹泼彩', '全彩照片', '居中模板'];
  return antiPatterns.some((p) => prompt.includes(p));
}

function hasSixInvariants(prompt: string) {
  const keywords = ['纸', '墨', '印刷', '机制', '主体', '字图'];
  return keywords.filter((k) => prompt.includes(k)).length >= 4;
}

function hasStyleMatch(prompt: string) {
  const styles = ['半调', '孔版', '双色', '木刻', '蓝晒', '蓝染', '剪纸', '水墨', '海报'];
  return styles.some((s) => prompt.includes(s));
}

function hasCompleteParams(prompt: string) {
  return prompt.length > 50 && prompt.includes('prompt');
}

// ─── 质量打分 ───
export function scorePrompt(prompt: string, context: { userIntent?: string; targetStyle?: string } = {}) {
  const scores: Record<string, { name: string; score: number; weight: number }> = {};
  let total = 0;

  for (const dim of SEVEN_DIMENSIONS) {
    let score = 0.7; // 默认 70 分

    if (dim.id === 'intent' && context.userIntent) {
      score = prompt.includes(context.userIntent) ? 0.95 : 0.6;
    } else if (dim.id === 'style' && context.targetStyle) {
      score = prompt.includes(context.targetStyle) ? 0.95 : 0.6;
    } else if (dim.id === 'constraint') {
      score = hasAntiPattern(prompt) ? 0.3 : 0.9;
    } else if (dim.id === 'params') {
      score = hasCompleteParams(prompt) ? 0.9 : 0.5;
    } else if (dim.id === 'output') {
      score = prompt.length > 100 ? 0.9 : 0.6;
    }

    scores[dim.id] = { name: dim.name, score, weight: dim.weight };
    total += score * dim.weight;
  }

  return { total: Math.round(total * 100), dimensions: scores };
}

// ─── 基线门控检查 ───
export function checkBaseline(prompt: string) {
  const results = [];
  for (const gate of BASELINE_GATES) {
    const passed = gate.check(prompt);
    results.push({ gate: gate.name, passed });
  }
  const allPassed = results.every((r) => r.passed);
  return { allPassed, results };
}

// ─── 修复建议 ───
export function getFixSuggestions(prompt: string, context: { userIntent?: string; targetStyle?: string } = {}) {
  const suggestions = [];

  if (hasAntiPattern(prompt)) {
    suggestions.push('检测到反模式，请参考反模式表修正');
  }
  if (!hasSixInvariants(prompt)) {
    suggestions.push('六不变式不齐全，请补充纸/墨/印刷/机制/主体/字图音量');
  }
  if (!hasStyleMatch(prompt)) {
    suggestions.push('未检测到明确风格，请指定风格家族');
  }
  if (prompt.length < 50) {
    suggestions.push('提示词过短，请补充更多细节');
  }

  return suggestions;
}
