/** taxue-dsh-artisan 浏览器端：设置卡片与生成图卡片。 */
import { useEffect, useState, type FormEvent } from 'react'
import type { Context } from '@deepseek-ai/cordis'
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type { SettingsScope, ToolCallBlock } from '@deepseek-ai/dsh-client-runtime/client'
import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { ImageLoader } from '@deepseek-ai/dsh-client-ui-attachment'
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings-plugins/client'
import type {} from '@deepseek-ai/dsh-client-ui-tool/client'
import {
  ARTISAN_SETTINGS_NAMESPACE,
  ARTISAN_IMAGE_ROUTE,
  ARTISAN_FILE_IMAGE_ROUTE,
  DEFAULT_BASE_URLS,
  DEFAULT_MODELS,
  type ArtisanProvider,
} from '../shared.js'

interface ArtisanSettings {
  provider?: ArtisanProvider
  googleModel?: string
  googleEndpoint?: string
  openaiBaseURL?: string
  openaiModel?: string
  seedreamBaseURL?: string
  seedreamModel?: string
  grokBaseURL?: string
  grokModel?: string
  codexBaseURL?: string
  codexModel?: string
  saveDir?: string
  skillRoot?: string
  skillPython?: string
  skillTimeoutMs?: number
}
interface LocaleService { getSnapshot(): { active: string }; subscribe(fn: () => void): () => void }
interface SettingsFace { scope: SettingsScope<ArtisanSettings>; credentials: ConnectionHandle['api']['credentials']; locale?: LocaleService | undefined }
type SettingsCardProps = PropsRuntime<'settings.plugin.item'> & InjectFace<SettingsFace>
type ImageCardProps = PropsRuntime<'tool.call.toolview'>

const KEY_REF: Record<ArtisanProvider, string> = {
  google: 'GEMINI_API_KEY',
  openai: 'OPENAI_API_KEY',
  seedream: 'ARK_API_KEY',
  grok: 'XAI_API_KEY',
  codex: 'CODEX_SUBSCRIPTION',
}

const DICT = {
  zh: {
    title: 'taxue 画师',
    description: '选择生成厂商并配置生图模型（含 Grok 订阅与 ChatGPT 订阅）。',
    provider: 'Provider',
    providerGoogle: 'Google Gemini',
    providerOpenAI: 'OpenAI / 中转站',
    providerSeedream: '字节 Seedream',
    providerGrok: 'xAI Grok',
    providerCodex: 'ChatGPT 订阅 (gpt-image-2)',
    apiKeyLabel: '{provider} API Key',
    apiKeyPlaceholder: '留空即可保留已配置的 Key',
    apiKeyHint: '安全保存为 {key}；页面不会读回明文。',
    codexNoKey: 'ChatGPT 订阅生图无需 API Key；请到 设置 > 插件 > 订阅 里登录 ChatGPT（codex）。',
    endpoint: '接口地址',
    reset: '重置',
    resetTitle: '重置为默认官方地址',
    endpointHintGoogle: 'Google 官方地址或反代端点（全路径）。',
    endpointHintOpenAI: '中转站请填其 OpenAI 兼容的 /v1 地址。',
    endpointHintSeedream: '火山方舟兼容的 /api/v3 地址。',
    endpointHintGrok: 'xAI 官方 /v1 地址或其兼容反代。',
    endpointHintCodex: 'ChatGPT 订阅的 codex 基础地址（默认官方，通常无需改）。',
    model: '模型',
    saving: '保存中…',
    save: '保存',
    saved: '已保存',
    saveDir: '保存文件夹',
    saveDirPlaceholder: '留空用默认（~/Downloads）',
    saveDirHint: '生成图落盘目录；可填绝对路径，留空保存到 ~/Downloads。',
    skillGroup: '技能桥（taxue-imagegen）',
    skillRoot: '技能目录',
    skillRootPlaceholder: '留空自动探测',
    skillRootHint: 'taxue-imagegen 根目录（含 scripts/fill_meta.py）；留空按 ~/.workbuddy/skills/taxue-imagegen 等路径探测。',
    skillPython: 'Python 解释器',
    skillPythonPlaceholder: '留空自动探测',
    skillPythonHint: '运行技能脚本用；留空按 WorkBuddy 内置环境与 Homebrew 探测。脚本需 numpy / PIL / opencv。',
    skillTimeout: '脚本超时（毫秒）',
    skillTimeoutHint: '单次脚本执行超时，默认 60000。',
    checkingKey: '正在检查 API Key…',
    keyConfigured: '已配置 API Key',
    keyNotConfigured: '尚未配置 API Key',
    generating: '正在生成图片…',
    loading: '正在加载图片…',
    loadFailed: '图片读取失败 ({status})',
    generatedTitle: '生成的图片',
    refImage: '参考图',
    refOpen: '查看原图',
    refOpenNamed: '查看原图：{name}',
    refLoading: '参考图加载中…',
    refLoadFailed: '参考图加载失败，点击重试',
    refPreview: '参考图预览',
    refClose: '关闭',
    compareTitle: '参考图 vs 生成图',
    refLabel: '参考图',
    genLabel: '生成图',
    bgStarted: '后台任务已发起（{jobId}），完成后用 job_output 查看结果。',
    bgLoading: '后台任务进行中…',
  },
  en: {
    title: 'taxue Artisan',
    description: 'Choose provider and configure image generation models (incl. Grok & ChatGPT subscriptions).',
    provider: 'Provider',
    providerGoogle: 'Google Gemini',
    providerOpenAI: 'OpenAI / Relay',
    providerSeedream: 'ByteDance Seedream',
    providerGrok: 'xAI Grok',
    providerCodex: 'ChatGPT subscription (gpt-image-2)',
    apiKeyLabel: '{provider} API Key',
    apiKeyPlaceholder: 'Leave empty to keep configured key',
    apiKeyHint: 'Securely saved as {key}; never read back in plaintext.',
    codexNoKey: 'ChatGPT subscription images need no API Key; log in to ChatGPT (codex) under Settings > Plugins > Subscriptions.',
    endpoint: 'Endpoint / Base URL',
    reset: 'Reset',
    resetTitle: 'Reset to official default URL',
    endpointHintGoogle: 'Official Google endpoint or reverse proxy (full path).',
    endpointHintOpenAI: 'OpenAI-compatible /v1 base URL for relays.',
    endpointHintSeedream: 'Volcengine Ark compatible /api/v3 base URL.',
    endpointHintGrok: 'Official xAI /v1 base URL or compatible relay.',
    endpointHintCodex: 'ChatGPT subscription codex base URL (official default; rarely changed).',
    model: 'Model',
    saving: 'Saving…',
    save: 'Save',
    saved: 'Saved',
    saveDir: 'Save folder',
    saveDirPlaceholder: 'Empty = default (~/Downloads)',
    saveDirHint: 'Generated images are written here; absolute path, or leave empty for ~/Downloads.',
    skillGroup: 'Skill bridge (taxue-imagegen)',
    skillRoot: 'Skill folder',
    skillRootPlaceholder: 'Empty = auto-detect',
    skillRootHint: 'taxue-imagegen root (contains scripts/fill_meta.py); empty probes ~/.workbuddy/skills/taxue-imagegen and similar.',
    skillPython: 'Python interpreter',
    skillPythonPlaceholder: 'Empty = auto-detect',
    skillPythonHint: 'Runs the skill scripts; empty probes the WorkBuddy bundled env and Homebrew. Needs numpy / PIL / opencv.',
    skillTimeout: 'Script timeout (ms)',
    skillTimeoutHint: 'Per-script execution timeout, default 60000.',
    checkingKey: 'Checking API Key…',
    keyConfigured: 'API Key configured',
    keyNotConfigured: 'API Key not configured',
    generating: 'Generating image…',
    loading: 'Loading image…',
    loadFailed: 'Failed to load image ({status})',
    generatedTitle: 'Generated image',
    refImage: 'Reference image',
    refOpen: 'View original',
    refOpenNamed: 'View original: {name}',
    refLoading: 'Loading reference image…',
    refLoadFailed: 'Failed to load reference image, click to retry',
    refPreview: 'Reference image preview',
    refClose: 'Close',
    compareTitle: 'Reference vs Generated',
    refLabel: 'Reference',
    genLabel: 'Generated',
    bgStarted: 'Background job started ({jobId}); use job_output to view the result.',
    bgLoading: 'Background job in progress…',
  },
} as const

type DictKey = keyof typeof DICT.zh

const PROVIDER_ORDER: ArtisanProvider[] = ['google', 'openai', 'seedream', 'grok', 'codex']

const STYLE = `
.dsh-ta-card{list-style:none;border:1px solid var(--dsw-alias-border-l2,#e5e7eb);border-radius:12px;background:var(--dsw-alias-bg-layer-3,#fff);transition:border-color .16s,background .16s;overflow:hidden}
.dsh-ta-card:hover{border-color:var(--dsw-alias-label-dimmed,#9ca3af)}
.dsh-ta-card-open{background:var(--dsw-alias-bg-layer-2,#fff);border-color:var(--dsw-alias-label-dimmed,#9ca3af)}
.dsh-ta-head{width:100%;appearance:none;border:0;background:none;font:inherit;color:inherit;text-align:left;cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 16px;border-radius:12px}
.dsh-ta-head:focus-visible{outline:2px solid var(--dsw-alias-brand-primary,#4c78ff);outline-offset:-2px}
.dsh-ta-head-text{flex:1;min-width:0;display:flex;flex-direction:column;gap:4px}
.dsh-ta-title{display:block;font-size:15px;font-weight:600;line-height:1.4;color:var(--dsw-alias-label-primary,inherit)}
.dsh-ta-desc{display:block;font-size:13px;line-height:1.5;color:var(--dsw-alias-label-tertiary,#7b818b)}
.dsh-ta-chevron{flex:none;color:var(--dsw-alias-label-tertiary,#7b818b);transition:transform .16s;display:inline-flex;align-items:center}
.dsh-ta-chevron-open{transform:rotate(180deg)}
.dsh-ta-body{border-top:1px solid var(--dsw-alias-border-l2,#eee);padding:0 16px 16px}
.dsh-ta-field{display:grid;gap:6px;margin-top:14px}
.dsh-ta-label{font-size:13px;font-weight:500;color:var(--dsw-alias-label-primary,inherit)}
.dsh-ta-input{box-sizing:border-box;width:100%;padding:8px 12px;font-size:13px;border:1px solid var(--dsw-alias-border-l2,#d7dbe0);border-radius:8px;background:var(--dsw-alias-bg-layer-3,transparent);color:inherit;outline:none;transition:border-color .15s}
.dsh-ta-input:focus{border-color:var(--dsw-alias-brand-primary,#4c78ff)}
.dsh-ta-input-group{display:flex;gap:8px;align-items:center}
.dsh-ta-btn-reset{appearance:none;border:1px solid var(--dsw-alias-border-l2,#d7dbe0);border-radius:8px;padding:7px 12px;background:var(--dsw-alias-bg-layer-3,#f9fafb);color:var(--dsw-alias-label-secondary,inherit);font:inherit;font-size:13px;cursor:pointer;white-space:nowrap;transition:background .15s,border-color .15s}
.dsh-ta-btn-reset:hover{background:var(--dsw-alias-bg-layer-2,#edf0f3);border-color:var(--dsw-alias-label-dimmed,#9ca3af)}
.dsh-ta-hint,.dsh-ta-status{margin:0;color:var(--dsw-alias-label-tertiary,#7b818b);font-size:12px;line-height:1.4}
.dsh-ta-actions{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:16px;padding-top:12px;border-top:1px solid var(--dsw-alias-border-l2,#eee)}
.dsh-ta-save{appearance:none;border:0;border-radius:8px;padding:6px 16px;background:var(--dsw-alias-label-primary,#111827);color:var(--dsw-alias-bg-layer-3,#fff);font:inherit;font-size:13px;font-weight:500;cursor:pointer;transition:opacity .15s}
.dsh-ta-save:disabled{opacity:.4;cursor:default}
.dsh-ta-result{display:grid;gap:10px;max-width:520px}
.dsh-ta-result-title{font-size:14px;font-weight:600}
.dsh-ta-container{position:relative;display:inline-block;width:fit-content;max-width:100%;justify-self:start;border-radius:12px;overflow:hidden;line-height:0}
.dsh-ta-container:hover .dsh-ta-toolbar{opacity:1;pointer-events:auto}
.dsh-ta-toolbar{position:absolute;top:8px;left:8px;display:flex;align-items:center;gap:5px;padding:3px 5px;border-radius:8px;background:rgba(0,0,0,0.65);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);opacity:0;pointer-events:none;transition:opacity .18s ease;z-index:10;line-height:1}
.dsh-ta-tool-btn{appearance:none;border:0;background:transparent;color:#fff;padding:5px;border-radius:6px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;transition:background .15s}
.dsh-ta-tool-btn:hover{background:rgba(255,255,255,0.25)}
.dsh-ta-toast{position:absolute;top:100%;left:0;margin-top:5px;padding:3px 8px;border-radius:6px;background:rgba(0,0,0,0.85);color:#fff;font-size:11px;white-space:nowrap;pointer-events:none;z-index:20}
.dsh-ta-image{display:block;max-width:100%;max-height:520px;border-radius:12px;background:#f2f3f5;cursor:pointer}
.dsh-ta-modal{position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.88);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;cursor:zoom-out;animation:dsh-ta-fade .15s ease-out}
@keyframes dsh-ta-fade{from{opacity:0}to{opacity:1}}
.dsh-ta-modal-img{max-width:92vw;max-height:92vh;object-fit:contain;border-radius:8px;box-shadow:0 24px 60px rgba(0,0,0,0.6);user-select:none;cursor:default}
.dsh-ta-error{color:var(--dsw-alias-label-error,#d33);font-size:13px}
.dsh-ta-loading{color:var(--dsw-alias-label-tertiary,#7b818b);font-size:13px}`

/** 所需浏览器服务。settingsScope 在 dsh 0.2.0-rc.2 改名 webUiSettings（由 web-ui-settings 表面提供）。 */
export const inject = ['slots', 'connection', 'remote', 'webUiSettings', 'locale']

/** 挂载设置卡片与生成图卡片。 */
export function apply(ctx: Context): void {
  const { api } = ctx.get('connection') as ConnectionHandle
  const settingsSource = ctx.get('webUiSettings') ?? ctx.settingsScope
  const scope = (settingsSource as typeof ctx.settingsScope).bind<ArtisanSettings>({ namespace: ARTISAN_SETTINGS_NAMESPACE as never })
  const locale = ctx.get('locale') as LocaleService | undefined
  ctx.effect(() => {
    const style = document.createElement('style'); style.dataset.plugin = 'taxue-dsh-artisan'; style.textContent = STYLE; document.head.appendChild(style)
    return () => { style.remove() }
  }, 'taxue-dsh-artisan: styles')
  const register = ctx.slots.register.bind(ctx.slots) as unknown as (options: object, component: unknown) => () => void
  ctx.slots.inject('settings.plugin.item', () => register({
    name: 'settings.plugin.item',
    key: ARTISAN_SETTINGS_NAMESPACE,
    id: ARTISAN_SETTINGS_NAMESPACE,
    order: 100,
    inject: (): SettingsFace => ({ scope, credentials: api.credentials, locale }),
  }, ArtisanSettingsCard))
  ctx.slots.inject('tool.call.toolview', () => ctx.slots.register({ name: 'tool.call.toolview', key: 'generate_image' }, GeneratedImageCard))
  ctx.slots.inject('tool.call.toolview', () => ctx.slots.register({ name: 'tool.call.toolview', key: 'reverse_prompt' }, ReversePromptToolview))
}

/** 编辑厂商设置与其只写 API 凭证。 */
export function ArtisanSettingsCard(props: SettingsCardProps) {
  const [open, setOpen] = useState(false)
  const [snapshot, setSnapshot] = useState(() => props.scope.getSnapshot())
  const [lang, setLang] = useState(() => props.locale?.getSnapshot?.()?.active ?? 'zh')
  const [provider, setProvider] = useState<ArtisanProvider>('google')
  const [model, setModel] = useState('')
  const [baseURL, setBaseURL] = useState('')
  const [saveDir, setSaveDir] = useState('')
  const [skillRoot, setSkillRoot] = useState('')
  const [skillPython, setSkillPython] = useState('')
  const [skillTimeout, setSkillTimeout] = useState('60000')
  const [key, setKey] = useState('')
  const [configured, setConfigured] = useState<boolean | undefined>()
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => props.scope.subscribe(() => { setSnapshot(props.scope.getSnapshot()) }), [props.scope])
  useEffect(() => {
    return props.locale?.subscribe?.(() => {
      setLang(props.locale?.getSnapshot?.()?.active ?? 'zh')
    })
  }, [props.locale])

  const t = (keyName: DictKey, params?: Record<string, string>): string => {
    const dict = lang === 'en' ? DICT.en : DICT.zh
    let text: string = dict[keyName] || DICT.zh[keyName] || keyName
    if (params) {
      for (const [k, v] of Object.entries(params)) {
        text = text.replace(`{${k}}`, v)
      }
    }
    return text
  }

  const providerLabels: Record<ArtisanProvider, string> = {
    google: t('providerGoogle'),
    openai: t('providerOpenAI'),
    seedream: t('providerSeedream'),
    grok: t('providerGrok'),
    codex: t('providerCodex'),
  }

  useEffect(() => {
    const value = snapshot.value
    const next = value?.provider ?? 'google'
    setProvider(next); setModel(modelOf(next, value)); setBaseURL(baseURLOf(next, value)); setSaveDir(value?.saveDir ?? '')
    setSkillRoot(value?.skillRoot ?? ''); setSkillPython(value?.skillPython ?? ''); setSkillTimeout(String(value?.skillTimeoutMs ?? 60000))
  }, [snapshot])

  useEffect(() => {
    let active = true
    // codex 无 API Key，不查凭证状态。
    if (provider === 'codex') {
      setConfigured(undefined)
      return () => { active = false }
    }
    void props.credentials.describe({ refs: [KEY_REF[provider]] }).then(response => {
      if (active) setConfigured(response.result.ok ? response.result.value.credentials[KEY_REF[provider]]?.configured ?? false : undefined)
    }).catch(() => { if (active) setConfigured(undefined) })
    return () => { active = false }
  }, [props.credentials, provider])

  const save = async (event: FormEvent): Promise<void> => {
    event.preventDefault(); setSaving(true); setMessage('')
    try {
      await props.scope.set('provider', provider)
      await props.scope.set(modelKeyOf(provider), model)
      await props.scope.set(endpointKeyOf(provider), baseURL)
      await props.scope.set('saveDir', saveDir)
      await props.scope.set('skillRoot', skillRoot)
      await props.scope.set('skillPython', skillPython)
      const parsedTimeout = Number.parseInt(skillTimeout, 10)
      await props.scope.set('skillTimeoutMs', Number.isFinite(parsedTimeout) && parsedTimeout > 0 ? parsedTimeout : 60000)
      if (key.trim().length > 0) {
        const response = await props.credentials.set({ ref: KEY_REF[provider], value: key.trim() })
        if (!response.result.ok) throw new Error(response.result.error.message)
        setKey(''); setConfigured(true)
      }
      setMessage(t('saved'))
    } catch (cause) { setMessage(cause instanceof Error ? cause.message : String(cause)) } finally { setSaving(false) }
  }

  const keyStatus = configured === undefined ? t('checkingKey') : configured ? t('keyConfigured') : t('keyNotConfigured')

  return <li className={`dsh-ta-card ${open ? 'dsh-ta-card-open' : ''}`}><button type="button" className="dsh-ta-head" aria-expanded={open} onClick={() => { setOpen(value => !value) }}><span className="dsh-ta-head-text"><span className="dsh-ta-title">{t('title')}</span><span className="dsh-ta-desc">{t('description')}</span></span><span className={`dsh-ta-chevron ${open ? 'dsh-ta-chevron-open' : ''}`} aria-hidden="true"><svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 6l4 4 4-4"/></svg></span></button>{open ? <form className="dsh-ta-body" onSubmit={(event) => { void save(event) }}>
    <label className="dsh-ta-field"><span className="dsh-ta-label">{t('provider')}</span><select className="dsh-ta-input" value={provider} onChange={event => { const next = event.target.value as ArtisanProvider; setProvider(next); setModel(modelOf(next, snapshot.value)); setBaseURL(baseURLOf(next, snapshot.value)); setKey('') }}>{PROVIDER_ORDER.map(value => <option key={value} value={value}>{providerLabels[value]}</option>)}</select><span className="dsh-ta-hint">{providerLabels[provider]}</span></label>
    {provider === 'codex'
      ? <span className="dsh-ta-hint" style={{ marginTop: 14 }}>{t('codexNoKey')}</span>
      : <label className="dsh-ta-field"><span className="dsh-ta-label">{t('apiKeyLabel', { provider: providerLabels[provider] })}</span><input className="dsh-ta-input" type="password" autoComplete="off" value={key} onChange={event => { setKey(event.target.value) }} placeholder={configured ? t('apiKeyPlaceholder') : ''} /><span className="dsh-ta-hint">{t('apiKeyHint', { key: KEY_REF[provider] })}</span></label>}
    <label className="dsh-ta-field"><span className="dsh-ta-label">{t('endpoint')}</span><div className="dsh-ta-input-group"><input className="dsh-ta-input" type="url" value={baseURL} onChange={event => { setBaseURL(event.target.value) }} required /><button type="button" className="dsh-ta-btn-reset" title={t('resetTitle')} onClick={() => { setBaseURL(DEFAULT_BASE_URLS[provider]) }}>{t('reset')}</button></div><span className="dsh-ta-hint">{endpointHint(provider, t)}</span></label>
    <label className="dsh-ta-field"><span className="dsh-ta-label">{t('model')}</span><input className="dsh-ta-input" value={model} onChange={event => { setModel(event.target.value) }} required /></label>
    <label className="dsh-ta-field"><span className="dsh-ta-label">{t('saveDir')}</span><input className="dsh-ta-input" type="text" value={saveDir} onChange={event => { setSaveDir(event.target.value) }} placeholder={t('saveDirPlaceholder')} /><span className="dsh-ta-hint">{t('saveDirHint')}</span></label>
    <span className="dsh-ta-hint" style={{ marginTop: 14, fontWeight: 600 }}>{t('skillGroup')}</span>
    <label className="dsh-ta-field"><span className="dsh-ta-label">{t('skillRoot')}</span><input className="dsh-ta-input" type="text" value={skillRoot} onChange={event => { setSkillRoot(event.target.value) }} placeholder={t('skillRootPlaceholder')} /><span className="dsh-ta-hint">{t('skillRootHint')}</span></label>
    <label className="dsh-ta-field"><span className="dsh-ta-label">{t('skillPython')}</span><input className="dsh-ta-input" type="text" value={skillPython} onChange={event => { setSkillPython(event.target.value) }} placeholder={t('skillPythonPlaceholder')} /><span className="dsh-ta-hint">{t('skillPythonHint')}</span></label>
    <label className="dsh-ta-field"><span className="dsh-ta-label">{t('skillTimeout')}</span><input className="dsh-ta-input" type="number" min="1000" step="1000" value={skillTimeout} onChange={event => { setSkillTimeout(event.target.value) }} /><span className="dsh-ta-hint">{t('skillTimeoutHint')}</span></label>
    <div className="dsh-ta-actions"><p className="dsh-ta-status" role="status">{message || keyStatus}</p><button className="dsh-ta-save" type="submit" disabled={saving || !snapshot.writable}>{saving ? t('saving') : t('save')}</button></div>
  </form> : null}</li>
}

/** 渲染一次已完成的图像工具调用引用的持久化附件。 */
/** 渲染一次已完成的图像工具调用：生成图 + 参考图并排对比。 */
export function GeneratedImageCard(props: ImageCardProps) {
  const { block } = props
  const attachment = imageRef(block)
  const meta = blockMeta(block)
  const reference = meta?.reference?.filter((item): item is string => typeof item === 'string' && item.length > 0) ?? []
  const jobId = typeof meta?.jobId === 'string' ? meta.jobId : undefined
  const isBackground = meta?.kind === 'taxue-artisan-background' || (meta?.kind === 'taxue-artisan' && jobId !== undefined)
  const [url, setUrl] = useState<string>()
  const [blob, setBlob] = useState<Blob>()
  const [error, setError] = useState<string>()
  const [previewOpen, setPreviewOpen] = useState(false)
  const [toast, setToast] = useState<string>()

  useEffect(() => {
    if (!previewOpen) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setPreviewOpen(false)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => { window.removeEventListener('keydown', onKeyDown) }
  }, [previewOpen])

  useEffect(() => {
    if (attachment === undefined) return
    const controller = new AbortController()
    let objectUrl: string | undefined
    void fetch(ARTISAN_IMAGE_ROUTE, {
      method: 'POST',
      signal: controller.signal,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ attachment }),
    }).then(async response => {
      if (!response.ok) throw new Error(`图片读取失败 (${String(response.status)})`)
      const resBlob = await response.blob()
      if (controller.signal.aborted) return
      setBlob(resBlob)
      objectUrl = URL.createObjectURL(resBlob)
      setUrl(objectUrl)
    }).catch(cause => {
      if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : String(cause))
    })
    return () => {
      controller.abort()
      if (objectUrl !== undefined) URL.revokeObjectURL(objectUrl)
    }
  }, [attachment?.attachmentId])

  const copy = async (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!blob) return
    const ok = await copyImageBlob(blob)
    setToast(ok ? '已复制图片' : '复制失败')
    setTimeout(() => { setToast(undefined) }, 2000)
  }

  const download = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!url) return
    const a = document.createElement('a')
    a.href = url
    a.download = attachment?.name || `taxue-image-${Date.now()}.png`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
  }

  const openNewTab = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!url) return
    window.open(url, '_blank', 'noopener,noreferrer')
  }

  if (attachment === undefined) {
    if (isBackground && jobId !== undefined) {
      return <section className="dsh-ta-result" aria-label="Background job"><div className="dsh-ta-result-title">生成的图片</div><div className="dsh-ta-loading">后台任务已发起（{jobId}），完成后用 job_output 查看结果。</div></section>
    }
    if (isBackground) {
      return <section className="dsh-ta-result" aria-label="Background job"><div className="dsh-ta-result-title">生成的图片</div><div className="dsh-ta-loading">后台任务进行中…</div></section>
    }
    return <div className="dsh-ta-loading">正在生成图片…</div>
  }
  return <section className="dsh-ta-result" aria-label="Generated image">
    <div className="dsh-ta-result-title">生成的图片</div>
    {error !== undefined ? <div className="dsh-ta-error">{error}</div> : null}
    {reference.length > 0 ? <div style={{ display: 'grid', gap: 4 }}>
      <div style={{ fontSize: 12, color: 'var(--dsw-alias-label-tertiary,#7b818b)' }}>参考图 vs 生成图</div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', overflowX: 'auto' }}>
        {reference.map((path, index) => <FilePreview key={`ref-${index}`} path={path} label="参考图" />)}
        {url !== undefined ? <div className="dsh-ta-container" style={{ alignSelf: 'flex-start' }}>
          <img className="dsh-ta-image" style={{ maxWidth: 240, maxHeight: 320 }} src={url} alt={attachment.name ?? 'Generated image'} onClick={() => { setPreviewOpen(true) }} />
        </div> : null}
      </div>
    </div> : null}
    {url === undefined && error === undefined ? <div className="dsh-ta-loading">正在加载图片…</div> : null}
    {url !== undefined ? <div className="dsh-ta-container">
      <img className="dsh-ta-image" src={url} alt={attachment.name ?? 'Generated image'} onClick={() => { setPreviewOpen(true) }} />
      <div className="dsh-ta-toolbar">
        <button type="button" className="dsh-ta-tool-btn" title="复制图片" onClick={(e) => { void copy(e) }}><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>
        <button type="button" className="dsh-ta-tool-btn" title="下载图片" onClick={download}><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></button>
        <button type="button" className="dsh-ta-tool-btn" title="新标签页打开" onClick={openNewTab}><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg></button>
        {toast ? <div className="dsh-ta-toast">{toast}</div> : null}
      </div>
    </div> : null}

    {previewOpen && url !== undefined ? <div className="dsh-ta-modal" onClick={() => { setPreviewOpen(false) }}>
      <img className="dsh-ta-modal-img" src={url} alt={attachment.name ?? 'Generated image preview'} onClick={(e) => { e.stopPropagation() }} />
    </div> : null}
  </section>
}

async function copyImageBlob(blob: Blob): Promise<boolean> {
  try {
    if (blob.type === 'image/png') {
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })])
      return true
    }
    const img = new Image()
    const url = URL.createObjectURL(blob)
    await new Promise((resolve, reject) => {
      img.onload = resolve
      img.onerror = reject
      img.src = url
    })
    const canvas = document.createElement('canvas')
    canvas.width = img.naturalWidth
    canvas.height = img.naturalHeight
    const ctx = canvas.getContext('2d')
    if (!ctx) throw new Error('Canvas unavailable')
    ctx.drawImage(img, 0, 0)
    URL.revokeObjectURL(url)
    const pngBlob = await new Promise<Blob | null>(res => { canvas.toBlob(res, 'image/png') })
    if (!pngBlob) throw new Error('Blob conversion failed')
    await navigator.clipboard.write([new ClipboardItem({ 'image/png': pngBlob })])
    return true
  } catch (_err) {
    return false
  }
}

function modelOf(provider: ArtisanProvider, value: ArtisanSettings | undefined): string {
  const stored = value?.[modelKeyOf(provider)]
  return typeof stored === 'string' && stored.length > 0 ? stored : DEFAULT_MODELS[provider]
}

function baseURLOf(provider: ArtisanProvider, value: ArtisanSettings | undefined): string {
  const stored = value?.[endpointKeyOf(provider)]
  return typeof stored === 'string' && stored.length > 0 ? stored : DEFAULT_BASE_URLS[provider]
}

function modelKeyOf(provider: ArtisanProvider): keyof ArtisanSettings {
  switch (provider) {
    case 'google': return 'googleModel'
    case 'openai': return 'openaiModel'
    case 'seedream': return 'seedreamModel'
    case 'grok': return 'grokModel'
    case 'codex': return 'codexModel'
  }
}

function endpointKeyOf(provider: ArtisanProvider): keyof ArtisanSettings {
  switch (provider) {
    case 'google': return 'googleEndpoint'
    case 'openai': return 'openaiBaseURL'
    case 'seedream': return 'seedreamBaseURL'
    case 'grok': return 'grokBaseURL'
    case 'codex': return 'codexBaseURL'
  }
}

function endpointHint(provider: ArtisanProvider, t: (key: DictKey) => string): string {
  switch (provider) {
    case 'google': return t('endpointHintGoogle')
    case 'openai': return t('endpointHintOpenAI')
    case 'seedream': return t('endpointHintSeedream')
    case 'grok': return t('endpointHintGrok')
    case 'codex': return t('endpointHintCodex')
  }
}

function imageRef(block: ToolCallBlock): ImageAttachmentRef | undefined {
  if (!('kind' in block) || block.resultView?.card !== 'generic') return undefined
  const image = block.resultView.content?.find(item => item.type === 'image')
  return image?.type === 'image' ? image.attachment : undefined
}

/** 提取工具结果携带的 presentationMeta（后台状态、参考图路径）。 */
function blockMeta(block: ToolCallBlock): { kind?: string; jobId?: unknown; reference?: readonly unknown[] } | undefined {
  if (!('kind' in block) || block.meta === undefined) return undefined
  if (typeof block.meta !== 'object' || block.meta === null) return undefined
  const meta = block.meta as { kind?: string; jobId?: unknown; reference?: unknown }
  return {
    kind: typeof meta.kind === 'string' ? meta.kind : undefined,
    jobId: meta.jobId,
    reference: Array.isArray(meta.reference) ? meta.reference as readonly unknown[] : undefined,
  } as { kind?: string; jobId?: unknown; reference?: readonly unknown[] }
}

function safeJsonParse(raw: string | undefined): unknown {
  if (raw === undefined) return undefined
  try { return JSON.parse(raw) } catch { return undefined }
}

/** 从工具调用参数里提取参考图路径（reference_assets[].uri）。 */
function referencePaths(block: ToolCallBlock): string[] {
  const argsRaw = 'kind' in block ? block.call?.argsRaw : block.argsRaw
  const args = safeJsonParse(argsRaw)
  if (typeof args !== 'object' || args === null) return []
  const value = args as Record<string, unknown>
  const assets = Array.isArray(value.reference_assets) ? value.reference_assets : []
  const paths: string[] = []
  for (const asset of assets) {
    if (typeof asset !== 'object' || asset === null) continue
    const uri = (asset as Record<string, unknown>).uri
    if (typeof uri === 'string' && uri.startsWith('/')) paths.push(uri)
  }
  return paths
}

/** 通过本插件同源路由把附件图片加载成可展示 URL。 */
function createArtisanImageLoader(): ImageLoader {
  return async (attachment) => {
    const response = await fetch(ARTISAN_IMAGE_ROUTE, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ attachment }),
    })
    if (!response.ok) throw new Error(`图片读取失败 (${String(response.status)})`)
    const blob = await response.blob()
    return URL.createObjectURL(blob)
  }
}

/** 本地图片文件路径的预览（经同源文件路由加载）。 */
function FilePreview({ path, label }: { path: string; label?: string }) {
  const [url, setUrl] = useState<string>()
  const [error, setError] = useState<string>()
  useEffect(() => {
    let objectUrl: string | undefined
    const controller = new AbortController()
    void fetch(ARTISAN_FILE_IMAGE_ROUTE, {
      method: 'POST',
      signal: controller.signal,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ path }),
    }).then(async response => {
      if (!response.ok) throw new Error(`参考图加载失败 (${String(response.status)})`)
      const blob = await response.blob()
      objectUrl = URL.createObjectURL(blob)
      setUrl(objectUrl)
    }).catch(cause => {
      if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : String(cause))
    })
    return () => {
      controller.abort()
      if (objectUrl !== undefined) URL.revokeObjectURL(objectUrl)
    }
  }, [path])
  return <figure style={{ margin: 0, display: 'grid', gap: 4, maxWidth: 240 }}>
    <figcaption style={{ fontSize: 11, color: 'var(--dsw-alias-label-tertiary,#7b818b)' }}>{label ?? '参考图'}</figcaption>
    {url === undefined && error === undefined ? <div className="dsh-ta-loading">参考图加载中…</div> : null}
    {error !== undefined ? <div className="dsh-ta-error">{error}</div> : null}
    {url !== undefined ? <img src={url} alt={label ?? '参考图'} style={{ maxWidth: 240, maxHeight: 320, borderRadius: 8, border: '1px solid var(--dsw-alias-border-l2,#e5e7eb)' }} /> : null}
  </figure>
}

/** reverse_prompt 的对话内预览：展示参考图（来自调用参数的 reference_assets）。 */
interface ReverseToolviewProps extends ImageCardProps {
  locale?: { getSnapshot(): { active: string }; subscribe(fn: () => void): () => void }
}
export function ReversePromptToolview(props: ReverseToolviewProps) {
  const { block } = props
  const refs = referencePaths(block)
  const [lang, setLang] = useState(() => props.locale?.getSnapshot?.()?.active ?? 'zh')
  useEffect(() => props.locale?.subscribe?.(() => setLang(props.locale?.getSnapshot?.()?.active ?? 'zh')), [props.locale])
  const dict = lang === 'en' ? DICT.en : DICT.zh
  return (
    <div style={{ display: 'grid', gap: 8, padding: '4px 0' }}>
      {refs.length > 0 ? refs.map((path, index) => <FilePreview key={`ref-${index}`} path={path} label={dict.refImage} />) : null}
    </div>
  )
}