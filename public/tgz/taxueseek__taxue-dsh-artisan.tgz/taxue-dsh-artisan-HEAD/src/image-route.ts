/** 从 Web 结果卡片到 Attachment 服务的同源 HTTP 桥。 */
import type { IncomingMessage, ServerResponse } from 'node:http'
import type { ImageAttachmentRef, StoredImageAttachment } from '@deepseek-ai/dsh-attachment'
import { ARTISAN_IMAGE_ROUTE } from './shared.js'

export { ARTISAN_FILE_IMAGE_ROUTE, ARTISAN_IMAGE_ROUTE } from './shared.js'
const MAX_BODY_BYTES = 4096

/** 参考图文件路径预览的最大字节（25 MiB）。 */
export const MAX_FILE_BYTES = 25 * 1024 * 1024
const FILE_IMAGE_EXT: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
}

/**
 * 跨平台同源校验：Origin 只比 host 部分，不比完整 scheme://host 字符串。
 * TLS 可能在上游终结（反向代理 / 隧道）：服务端看到的是明文 HTTP socket，
 * 而浏览器 Origin 是 https。比完整串会把合法请求误判为跨源（403）。
 * 端口默认（:80/:443）不参与比较。返回 null 表示放行。
 */
export function sameOriginCheck(origin: string | undefined, host: string | undefined): string | null {
  if (origin === undefined || host === undefined) return null
  let originHost: string | undefined
  try {
    originHost = new URL(String(origin)).host
  } catch {
    return 'origin-unparsable'
  }
  const hostUrl = new URL(`http://${host}`)
  if (originHost !== hostUrl.host) return 'cross-origin'
  return null
}

/** 图片路由所需的依赖。 */
export interface ArtisanImageRouteDeps {
  readImage(ref: ImageAttachmentRef): Promise<StoredImageAttachment>
}

/** 向同源浏览器请求提供一个已校验的持久化图片引用。 */
export async function serveImage(req: IncomingMessage, res: ServerResponse, deps: ArtisanImageRouteDeps): Promise<void> {
  if (req.method !== 'POST') return jsonError(res, 405, 'method-not-allowed')
  if (!(req.headers['content-type'] ?? '').toLowerCase().startsWith('application/json')) return jsonError(res, 415, 'json-required')
  const origin = req.headers.origin
  const host = req.headers.host
  const originErr = sameOriginCheck(origin, host)
  if (originErr !== null) {
    return jsonError(res, 403, originErr === 'origin-unparsable' ? 'invalid-origin' : 'origin-rejected')
  }
  let body: unknown
  try {
    body = JSON.parse(await readBody(req))
  } catch {
    return jsonError(res, 400, 'invalid-request')
  }
  const attachment = attachmentFromRequest(body)
  if (attachment === undefined) return jsonError(res, 400, 'invalid-attachment')
  try {
    const stored = await deps.readImage(attachment)
    res.writeHead(200, {
      'content-type': stored.ref.mediaType,
      'content-length': String(stored.data.byteLength),
      'cache-control': 'private, no-store',
      'x-content-type-options': 'nosniff',
    })
    res.end(stored.data)
  } catch {
    jsonError(res, 404, 'image-unavailable')
  }
}

/** 校验工具展示携带的持久化引用。 */
export function imageAttachmentFromMeta(meta: unknown): ImageAttachmentRef | undefined {
  const value = record(meta)
  if (value?.kind !== 'taxue-artisan') return undefined
  return imageAttachment(value.attachment)
}

/** 参考图文件预览路由所需依赖。 */
export interface ArtisanFileImageDeps {
  readFile(path: string): Promise<Uint8Array | undefined>
}

/** 向同源浏览器提供一张本地图片文件（用于参考图路径预览）。仅允许绝对路径与图片扩展名。 */
export async function serveFileImage(req: IncomingMessage, res: ServerResponse, deps: ArtisanFileImageDeps): Promise<void> {
  if (req.method !== 'POST') return jsonError(res, 405, 'method-not-allowed')
  if (!(req.headers['content-type'] ?? '').toLowerCase().startsWith('application/json')) return jsonError(res, 415, 'json-required')
  const origin = req.headers.origin
  const host = req.headers.host
  const originErr = sameOriginCheck(origin, host)
  if (originErr !== null) {
    return jsonError(res, 403, originErr === 'origin-unparsable' ? 'invalid-origin' : 'origin-rejected')
  }
  let body: unknown
  try {
    body = JSON.parse(await readBody(req))
  } catch {
    return jsonError(res, 400, 'invalid-request')
  }
  const path = record(body)?.path
  if (typeof path !== 'string' || !path.startsWith('/')) return jsonError(res, 400, 'invalid-path')
  const dot = path.lastIndexOf('.')
  const ext = dot === -1 ? '' : path.slice(dot).toLowerCase()
  const mediaType = FILE_IMAGE_EXT[ext]
  if (mediaType === undefined) return jsonError(res, 415, 'unsupported-image')
  try {
    const data = await deps.readFile(path)
    if (data === undefined || data.byteLength > MAX_FILE_BYTES) return jsonError(res, 404, 'file-unavailable')
    res.writeHead(200, {
      'content-type': mediaType,
      'content-length': String(data.byteLength),
      'cache-control': 'private, no-store',
      'x-content-type-options': 'nosniff',
    })
    res.end(Buffer.from(data))
  } catch {
    jsonError(res, 404, 'file-unavailable')
  }
}

function attachmentFromRequest(value: unknown): ImageAttachmentRef | undefined {
  return imageAttachment(record(value)?.attachment)
}

function imageAttachment(value: unknown): ImageAttachmentRef | undefined {
  const ref = record(value)
  if (ref === undefined) return undefined
  if (typeof ref.attachmentId !== 'string' || !mediaType(ref.mediaType) || typeof ref.bytes !== 'number' || typeof ref.width !== 'number' || typeof ref.height !== 'number') return undefined
  if (ref.name !== undefined && typeof ref.name !== 'string') return undefined
  return ref as unknown as ImageAttachmentRef
}

function mediaType(value: unknown): value is ImageAttachmentRef['mediaType'] {
  return value === 'image/png' || value === 'image/jpeg' || value === 'image/webp' || value === 'image/gif'
}

function record(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value) ? value as Record<string, unknown> : undefined
}

async function readBody(req: IncomingMessage): Promise<string> {
  const chunks: Buffer[] = []
  let bytes = 0
  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    bytes += buffer.byteLength
    if (bytes > MAX_BODY_BYTES) throw new Error('请求过大')
    chunks.push(buffer)
  }
  return Buffer.concat(chunks).toString('utf8')
}

function jsonError(res: ServerResponse, status: number, code: string): void {
  res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' })
  res.end(JSON.stringify({ error: code }))
}
