/** 本地确定性色卡提取：PNG 解码 + Oklab 聚类。零依赖、离线、同一张图永远出同一个色卡。
 * 语义理解交给反推模型，像素统计交给本地确定性算法——两者以「模型不得编造色值」分工。 */
import { inflateSync } from 'node:zlib'

/** 一张参考图的确定性色卡。 */
export interface ExtractedPalette {
  /** 主色 hex（占比最大的簇，输出真实出现过的采样像素而非簇心）。 */
  dominant: string
  secondary: string
  accent: string
  /** 暗部/高光锚点色（L 过低或过高时存在；否则省略）。 */
  dark?: string
  light?: string
  /** 全部颜色及占比（0-100，一位小数，总和归一化）。 */
  swatches: Array<{ hex: string; share: number; role: 'dominant' | 'secondary' | 'accent' | 'dark' | 'light' | 'supporting' }>
}

// ── PNG 解码（仅支持非隔行 8-bit；覆盖生图与截图的绝大多数情况）──

const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])

interface DecodedPng {
  width: number
  height: number
  /** RGB 三通道交错像素，长度 = width*height*3。 */
  pixels: Uint8Array
}

function crc32(buffer: Buffer, seed = 0xffffffff): number {
  let crc = seed
  for (let i = 0; i < buffer.length; i++) {
    crc ^= buffer[i]!
    for (let bit = 0; bit < 8; bit++) {
      crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1))
    }
  }
  return crc >>> 0
}

/** 解析 PNG（8-bit 非隔行，color type 0/2/3/4/6），返回 RGB 像素。 */
export function decodePng(buffer: Buffer): DecodedPng {
  if (buffer.length < 8 || !buffer.subarray(0, 8).equals(PNG_SIGNATURE)) throw new Error('不是 PNG 文件（缺少 PNG 签名）')
  let width = 0
  let height = 0
  let bitDepth = 0
  let colorType = -1
  let interlace = 0
  const idat: Buffer[] = []
  let palette: Uint8Array | undefined
  let trns: Uint8Array | undefined
  let offset = 8
  while (offset + 12 <= buffer.length) {
    const length = buffer.readUInt32BE(offset)
    const type = buffer.toString('ascii', offset + 4, offset + 8)
    const dataStart = offset + 8
    const dataEnd = dataStart + length
    if (dataEnd + 4 > buffer.length) throw new Error('PNG 数据块不完整')
    if (type === 'IHDR') {
      width = buffer.readUInt32BE(dataStart)
      height = buffer.readUInt32BE(dataStart + 4)
      bitDepth = buffer[dataStart + 8]!
      colorType = buffer[dataStart + 9]!
      interlace = buffer[dataStart + 12]!
      void crc32(buffer.subarray(dataStart - 4, dataEnd)) // 含 type 字段的 CRC 覆盖范围校验占位
    } else if (type === 'PLTE') {
      palette = new Uint8Array(buffer.subarray(dataStart, dataEnd))
    } else if (type === 'tRNS') {
      trns = new Uint8Array(buffer.subarray(dataStart, dataEnd))
    } else if (type === 'IDAT') {
      idat.push(Buffer.from(buffer.subarray(dataStart, dataEnd)))
    } else if (type === 'IEND') {
      break
    }
    offset = dataEnd + 4
  }
  if (width <= 0 || height <= 0) throw new Error('PNG 头缺失或尺寸非法')
  if (bitDepth !== 8) throw new Error(`仅支持 8-bit PNG（当前 ${String(bitDepth)}-bit）；JPEG/WebP 参考图请先转 PNG`)
  if (interlace !== 0) throw new Error('不支持隔行扫描 PNG')
  if (idat.length === 0) throw new Error('IDAT 数据块缺失')
  if (![0, 2, 3, 4, 6].includes(colorType)) throw new Error(`不支持的 PNG 颜色类型 ${String(colorType)}`)
  const raw = inflateSync(Buffer.concat(idat))
  const channels = colorType === 2 ? 3 : colorType === 6 ? 4 : colorType === 4 ? 2 : colorType === 3 ? 1 : 1
  const stride = width * channels
  if (raw.length < (stride + 1) * height) throw new Error('PNG 像素数据不完整')
  // 原地还原滤波器：每行前置 1 字节滤波器标记，还原只依赖当前行与上一行，无需整图副本。
  const bpp = channels
  const rowBytes = stride + 1
  let prevStart = -1
  for (let y = 0, rowStart = 0; y < height; y++, rowStart += rowBytes) {
    const filter = raw[rowStart]!
    const data = rowStart + 1
    const prev = prevStart < 0 ? -1 : prevStart + 1
    switch (filter) {
      case 1:
        for (let x = bpp; x < stride; x++) raw[data + x] = (raw[data + x]! + raw[data + x - bpp]!) & 0xff
        break
      case 2:
        if (prev >= 0) for (let x = 0; x < stride; x++) raw[data + x] = (raw[data + x]! + raw[prev + x]!) & 0xff
        break
      case 3:
        for (let x = 0; x < stride; x++) {
          const left = x >= bpp ? raw[data + x - bpp]! : 0
          const up = prev >= 0 ? raw[prev + x]! : 0
          raw[data + x] = (raw[data + x]! + ((left + up) >> 1)) & 0xff
        }
        break
      case 4: {
        for (let x = 0; x < stride; x++) {
          const a = x >= bpp ? raw[data + x - bpp]! : 0
          const b = prev >= 0 ? raw[prev + x]! : 0
          const c = x >= bpp && prev >= 0 ? raw[prev + x - bpp]! : 0
          const p = a + b - c
          const pa = Math.abs(p - a)
          const pb = Math.abs(p - b)
          const pc = Math.abs(p - c)
          const predictor = pa <= pb && pa <= pc ? a : pb <= pc ? b : c
          raw[data + x] = (raw[data + x]! + predictor) & 0xff
        }
        break
      }
      default: break
    }
    prevStart = rowStart
  }
  // 展开为 RGB。
  const pixels = new Uint8Array(width * height * 3)
  let out = 0
  for (let y = 0; y < height; y++) {
    const line = y * rowBytes + 1
    for (let x = 0; x < width; x++) {
      const base = line + x * channels
      switch (colorType) {
        case 0: { // 灰度
          const v = raw[base]!
          pixels[out++] = v; pixels[out++] = v; pixels[out++] = v
          break
        }
        case 2: // RGB
          pixels[out++] = raw[base]!
          pixels[out++] = raw[base + 1]!
          pixels[out++] = raw[base + 2]!
          break
        case 3: { // 索引色
          const index = raw[base]!
          const entry = index * 3
          if (trns !== undefined && index < trns.length && trns[index] === 0) continue // 全透明跳过
          pixels[out++] = palette?.[entry] ?? 0
          pixels[out++] = palette?.[entry + 1] ?? 0
          pixels[out++] = palette?.[entry + 2] ?? 0
          break
        }
        case 4: { // 灰度+alpha
          const v = raw[base]!
          const alpha = raw[base + 1]!
          if (alpha === 0) continue
          pixels[out++] = v; pixels[out++] = v; pixels[out++] = v
          break
        }
        case 6: { // RGBA
          const alpha = raw[base + 3]!
          if (alpha < 128) continue
          pixels[out++] = raw[base]!
          pixels[out++] = raw[base + 1]!
          pixels[out++] = raw[base + 2]!
          break
        }
      }
    }
  }
  return { width, height, pixels: pixels.subarray(0, out) }
}

// ── 确定性采样与 Oklab 聚类 ──

interface Sample {
  r: number
  g: number
  b: number
}

/** 确定性网格采样：按行×列双步长取样，样本数上限约 maxSamples；跳过已剔除的透明像素由解码层处理。
 *  width 为像素行宽（透明剔除后行宽略有出入不影响确定性，只影响近似网格形状）。 */
function samplePixels(pixels: Uint8Array, width: number, maxSamples = 12000): Sample[] {
  const total = Math.floor(pixels.length / 3)
  if (total === 0) return []
  const rowWidth = Math.max(1, width)
  const stride = Math.max(1, Math.ceil(Math.sqrt(total / maxSamples)))
  const samples: Sample[] = []
  for (let row = 0; row * rowWidth < total; row += stride) {
    const rowStart = row * rowWidth
    for (let index = rowStart; index < rowStart + rowWidth && index < total; index += stride) {
      const base = index * 3
      samples.push({ r: pixels[base]!, g: pixels[base + 1]!, b: pixels[base + 2]! })
    }
  }
  return samples
}

/** sRGB → Oklab（Björn Ottosson 公式）。 */
function rgbToOklab(r: number, g: number, b: number): { L: number; a: number; bb: number } {
  const lr = srgbToLinear(r / 255)
  const lg = srgbToLinear(g / 255)
  const lb = srgbToLinear(b / 255)
  const l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb)
  const m = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb)
  const s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb)
  return {
    L: 0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s,
    a: 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s,
    bb: 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s,
  }
}

function srgbToLinear(value: number): number {
  const v = value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4
  return v
}

function linearToSrgb(value: number): number {
  const v = value <= 0.0031308 ? value * 12.92 : 1.055 * value ** (1 / 2.4) - 0.055
  return Math.round(Math.min(255, Math.max(0, v * 255)))
}

function oklabToRgb(L: number, a: number, b: number): Rgb {
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b
  const s_ = L - 0.0894841775 * a - 1.291485548 * b
  const l = l_ ** 3
  const m = m_ ** 3
  const s = s_ ** 3
  return {
    r: linearToSrgb(+4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s),
    g: linearToSrgb(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s),
    b: linearToSrgb(-0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s),
  }
}

interface Rgb {
  r: number
  g: number
  b: number
}

function hexOf(rgb: Rgb): string {
  const toHex = (value: number): string => value.toString(16).padStart(2, '0')
  return `#${toHex(rgb.r)}${toHex(rgb.g)}${toHex(rgb.b)}`
}

interface Cluster {
  L: number
  a: number
  bb: number
  members: Array<{ sample: Sample; lab: { L: number; a: number; bb: number } }>
}

/** 确定性 K-Means：最远点播种（无随机），14 轮固定迭代。 */
function kMeans(samples: Array<{ sample: Sample; lab: { L: number; a: number; bb: number } }>, k: number): Cluster[] {
  // 最远点播种：从第一个样本出发，每轮选距现有中心最远的样本作新种子。
  const centers: Array<{ L: number; a: number; bb: number }> = [{ ...samples[0]!.lab }]
  while (centers.length < k) {
    let bestIndex = 0
    let bestDistance = -1
    for (let i = 0; i < samples.length; i++) {
      const lab = samples[i]!.lab
      let nearest = Number.POSITIVE_INFINITY
      for (const center of centers) {
        const dl = lab.L - center.L
        const da = lab.a - center.a
        const dbb = lab.bb - center.bb
        const distance = dl * dl + da * da + dbb * dbb
        if (distance < nearest) nearest = distance
      }
      if (nearest > bestDistance) {
        bestDistance = nearest
        bestIndex = i
      }
    }
    if (bestDistance <= 1e-9) break // 所有点已被覆盖，提前结束播种
    centers.push({ ...samples[bestIndex]!.lab })
  }
  const clusters: Cluster[] = centers.map((center) => ({ ...center, members: [] }))
  for (let iteration = 0; iteration < 14; iteration++) {
    for (const cluster of clusters) cluster.members.length = 0
    for (const item of samples) {
      let nearest = clusters[0]!
      let nearestDistance = Number.POSITIVE_INFINITY
      for (const cluster of clusters) {
        const dl = item.lab.L - cluster.L
        const da = item.lab.a - cluster.a
        const dbb = item.lab.bb - cluster.bb
        const distance = dl * dl + da * da + dbb * dbb
        if (distance < nearestDistance) {
          nearestDistance = distance
          nearest = cluster
        }
      }
      nearest.members.push(item)
    }
    for (const cluster of clusters) {
      if (cluster.members.length === 0) continue
      let sumL = 0
      let sumA = 0
      let sumB = 0
      for (const member of cluster.members) {
        sumL += member.lab.L
        sumA += member.lab.a
        sumB += member.lab.bb
      }
      cluster.L = sumL / cluster.members.length
      cluster.a = sumA / cluster.members.length
      cluster.bb = sumB / cluster.members.length
    }
  }
  return clusters.filter((cluster) => cluster.members.length > 0)
}

/** 近簇合并两轮（Oklab 欧氏距离阈值递减）。 */
function mergeClusters(clusters: Cluster[], thresholds: [number, number]): Cluster[] {
  let merged = clusters
  for (const threshold of thresholds) {
    const result: Cluster[] = []
    for (const cluster of merged) {
      const target = result.find((existing) => {
        const dl = existing.L - cluster.L
        const da = existing.a - cluster.a
        const dbb = existing.bb - cluster.bb
        return Math.sqrt(dl * dl + da * da + dbb * dbb) < threshold
      })
      if (target !== undefined) target.members.push(...cluster.members)
      else result.push(cluster)
    }
    merged = result
  }
  return merged
}

/** 输出 hex 用「离簇心最近的真实采样像素」——保证颜色真实出现过。 */
function representativeHex(cluster: Cluster): string {
  let best = cluster.members[0]!
  let bestDistance = Number.POSITIVE_INFINITY
  for (const member of cluster.members) {
    const dl = member.lab.L - cluster.L
    const da = member.lab.a - cluster.a
    const dbb = member.lab.bb - cluster.bb
    const distance = dl * dl + da * da + dbb * dbb
    if (distance < bestDistance) {
      bestDistance = distance
      best = member
    }
  }
  return hexOf(best.sample)
}

/**
 * 从一张图的 RGB 像素提取确定性色卡。width 为像素行宽（来自 decodePng），
 * 缺省按正方形近似——只影响网格形状，不影响确定性。
 *
 * 流程：确定性采样 → Oklab K-Means(k=8) → 近簇合并两轮 → 角色标注（主/辅/点缀/暗部/高光）
 * → 占比归一化。同一张图永远产出同一个色卡。
 */
export function extractPalette(pixels: Uint8Array, width?: number): ExtractedPalette {
  const sampled = samplePixels(pixels, width ?? Math.max(1, Math.round(Math.sqrt(pixels.length / 3)))).map((sample) => ({ sample, lab: rgbToOklab(sample.r, sample.g, sample.b) }))
  if (sampled.length === 0) throw new Error('参考图没有可采样的不透明像素')
  const clusters = mergeClusters(kMeans(sampled, 8), [0.032, 0.026]).sort((left, right) => right.members.length - left.members.length)
  const totalWeight = clusters.reduce((sum, cluster) => sum + cluster.members.length, 0)
  // 点缀色：chroma 最高且与主辅色距离足够的簇。
  const chromaOf = (cluster: Cluster): number => Math.sqrt(cluster.a * cluster.a + cluster.bb * cluster.bb)
  let accentIndex = -1
  let accentScore = 0
  for (let i = 2; i < clusters.length; i++) {
    const cluster = clusters[i]!
    const share = cluster.members.length / totalWeight
    if (share < 0.01) continue
    const dominantCluster = clusters[0]!
    const secondaryCluster = clusters[1] ?? dominantCluster
    const distanceDominant = Math.sqrt((cluster.a - dominantCluster.a) ** 2 + (cluster.bb - dominantCluster.bb) ** 2)
    const distanceSecondary = Math.sqrt((cluster.a - secondaryCluster.a) ** 2 + (cluster.bb - secondaryCluster.bb) ** 2)
    const separation = Math.min(distanceDominant, distanceSecondary)
    const score = chromaOf(cluster) * 1.25 + separation * 0.9 + share * 0.08
    if (separation >= 0.04 && score > accentScore) {
      accentScore = score
      accentIndex = i
    }
  }
  const roles = new Map<number, 'dominant' | 'secondary' | 'accent' | 'dark' | 'light' | 'supporting'>()
  roles.set(0, 'dominant')
  if (clusters.length > 1) roles.set(1, 'secondary')
  if (accentIndex > 1) roles.set(accentIndex, 'accent')
  const swatches = clusters.map((cluster, index) => {
    let role = roles.get(index) ?? 'supporting'
    const L = cluster.L
    if (role === 'supporting' && L < 0.3) role = 'dark'
    else if (role === 'supporting' && L > 0.87) role = 'light'
    const share = Math.round((cluster.members.length / totalWeight) * 1000) / 10
    return { hex: representativeHex(cluster), share, role }
  })
  const findRole = (role: ExtractedPalette['swatches'][number]['role']): string | undefined => {
    const found = swatches.find((swatch) => swatch.role === role)?.hex
    return typeof found === 'string' ? found : undefined
  }
  const dominant = findRole('dominant') ?? swatches[0]?.hex ?? '#000000'
  const secondary = findRole('secondary') ?? dominant
  const accent = findRole('accent') ?? swatches.find((swatch) => swatch.role === 'supporting')?.hex ?? secondary
  const dark = findRole('dark')
  const light = findRole('light')
  return {
    dominant,
    secondary,
    accent,
    ...(dark !== undefined ? { dark } : {}),
    ...(light !== undefined ? { light } : {}),
    swatches,
  }
}
