/** 面向用户的供应商配置与运行时解析。 */
import z from '@deepseek-ai/schemastery'

import {
  DEFAULT_CODEX_BASE_URL,
  DEFAULT_CODEX_MODEL,
  DEFAULT_GOOGLE_ENDPOINT,
  DEFAULT_GOOGLE_MODEL,
  DEFAULT_GROK_BASE_URL,
  DEFAULT_GROK_MODEL,
  DEFAULT_OPENAI_BASE_URL,
  DEFAULT_OPENAI_MODEL,
  DEFAULT_SEEDREAM_BASE_URL,
  DEFAULT_SEEDREAM_MODEL,
  ARTISAN_PROVIDERS,
  type ArtisanProvider,
} from './shared.js'

export {
  DEFAULT_CODEX_BASE_URL,
  DEFAULT_CODEX_MODEL,
  DEFAULT_GOOGLE_ENDPOINT,
  DEFAULT_GOOGLE_MODEL,
  DEFAULT_GROK_BASE_URL,
  DEFAULT_GROK_MODEL,
  DEFAULT_OPENAI_BASE_URL,
  DEFAULT_OPENAI_MODEL,
  DEFAULT_SEEDREAM_BASE_URL,
  DEFAULT_SEEDREAM_MODEL,
  ARTISAN_PROVIDERS,
  type ArtisanProvider,
}

/** 各供应商的凭证引用。 */
export const GOOGLE_API_KEY_ENV = 'GEMINI_API_KEY'
export const OPENAI_API_KEY_ENV = 'OPENAI_API_KEY'
export const SEEDREAM_API_KEY_ENV = 'ARK_API_KEY'
export const GROK_API_KEY_ENV = 'XAI_API_KEY'
/** codex 无 API Key，该常量仅用于设置页与报错文案的展示位。 */
export const CODEX_CRED_REF = 'CODEX_SUBSCRIPTION'

/** Google 原生工具控制。 */
/** Google 原生支持的画幅子集。 */
export const GOOGLE_ASPECT_RATIOS = ['1:1', '3:2', '2:3', '4:3', '3:4', '16:9', '9:16'] as const
/** 工具层暴露的完整画幅集：Google 子集 + Grok/Seedream 支持的扩展比例。 */
export const ASPECT_RATIOS = [...GOOGLE_ASPECT_RATIOS, '2:1', '1:2', '19.5:9', '9:19.5', '20:9', '9:20', 'auto'] as const
export const IMAGE_SIZES = ['1K', '2K', '4K'] as const
export type AspectRatio = (typeof ASPECT_RATIOS)[number]
export type GoogleAspectRatio = (typeof GOOGLE_ASPECT_RATIOS)[number]
export type ImageSize = (typeof IMAGE_SIZES)[number]

/** Bundle 配置：来自 profile 补丁层与 Web 设置页。 */
export interface ArtisanConfig {
  provider?: ArtisanProvider
  googleModel?: string
  googleEndpoint?: string
  openaiBaseURL?: string
  openaiModel?: string
  seedreamBaseURL?: string
  seedreamModel?: string
  grokBaseURL?: string
  grokModel?: string
  codexBaseURL?: string
  codexModel?: string
  /** 生成图落盘目录；空串用默认（~/Downloads）。 */
  saveDir?: string
  /** generate_image 单次执行超时（ms）。 */
  toolTimeoutMs?: number
  /** taxue-imagegen 技能目录（含 scripts/fill_meta.py）；留空按 ~/.workbuddy 等候选探测。 */
  skillRoot?: string
  /** 技能脚本使用的 Python 解释器；留空按 WorkBuddy 内置环境、Homebrew 等候选探测。 */
  skillPython?: string
  /** 技能脚本单次执行超时（ms）。 */
  skillTimeoutMs?: number
  /** 开启 reverse_prompt 的 LLM 反推重组（把观察描述转译为真正提示词）；llm 为 harness 必需，默认开启。 */
  llmPolish?: boolean
  /** LLM 润色所用 provider（缺省用 llm 第一个注册 provider）；配合 llmPolish 使用。 */
  llmPolishProvider?: string
  /** LLM 润色所用模型 id（缺省用该 provider 第一个模型）；配合 llmPolish 使用。 */
  llmPolishModel?: string
}

/** Cordis 配置 schema。 */
export const ArtisanConfig: z<ArtisanConfig> = z.object({
  provider: z.union(ARTISAN_PROVIDERS).default('google'),
  googleModel: z.string().default(DEFAULT_GOOGLE_MODEL),
  googleEndpoint: z.string().default(DEFAULT_GOOGLE_ENDPOINT),
  openaiBaseURL: z.string().default(DEFAULT_OPENAI_BASE_URL),
  openaiModel: z.string().default(DEFAULT_OPENAI_MODEL),
  seedreamBaseURL: z.string().default(DEFAULT_SEEDREAM_BASE_URL),
  seedreamModel: z.string().default(DEFAULT_SEEDREAM_MODEL),
  grokBaseURL: z.string().default(DEFAULT_GROK_BASE_URL),
  grokModel: z.string().default(DEFAULT_GROK_MODEL),
  codexBaseURL: z.string().default(DEFAULT_CODEX_BASE_URL),
  codexModel: z.string().default(DEFAULT_CODEX_MODEL),
  saveDir: z.string().default(''),
  toolTimeoutMs: z.number().default(180000),
  skillRoot: z.string().default(''),
  skillPython: z.string().default(''),
  skillTimeoutMs: z.number().default(60000),
  llmPolish: z.boolean().default(true),
  llmPolishProvider: z.string().default(''),
  llmPolishModel: z.string().default(''),
})

type GoogleProfile = { provider: 'google'; apiKeyEnv: string; model: string; endpoint: string; aspectRatio: AspectRatio; imageSize: ImageSize }
type CompatProfile = { provider: 'openai' | 'seedream' | 'grok' | 'codex'; apiKeyEnv: string; model: string; baseURL: string; imageSize: string }

/** 为一次工具调用解析出恰好一个供应商 profile。 */
export function resolveProvider(config: ArtisanConfig): GoogleProfile | CompatProfile {
  switch (config.provider ?? 'google') {
    case 'openai': return { provider: 'openai', apiKeyEnv: OPENAI_API_KEY_ENV, model: config.openaiModel ?? DEFAULT_OPENAI_MODEL, baseURL: config.openaiBaseURL ?? DEFAULT_OPENAI_BASE_URL, imageSize: '1024x1024' }
    case 'seedream': return { provider: 'seedream', apiKeyEnv: SEEDREAM_API_KEY_ENV, model: config.seedreamModel ?? DEFAULT_SEEDREAM_MODEL, baseURL: config.seedreamBaseURL ?? DEFAULT_SEEDREAM_BASE_URL, imageSize: '2K' }
    case 'grok': return { provider: 'grok', apiKeyEnv: GROK_API_KEY_ENV, model: config.grokModel ?? DEFAULT_GROK_MODEL, baseURL: config.grokBaseURL ?? DEFAULT_GROK_BASE_URL, imageSize: '1024x1024' }
    case 'codex': return { provider: 'codex', apiKeyEnv: CODEX_CRED_REF, model: config.codexModel ?? DEFAULT_CODEX_MODEL, baseURL: config.codexBaseURL ?? DEFAULT_CODEX_BASE_URL, imageSize: '1024x1024' }
    case 'google': return { provider: 'google', apiKeyEnv: GOOGLE_API_KEY_ENV, model: config.googleModel ?? DEFAULT_GOOGLE_MODEL, endpoint: config.googleEndpoint ?? DEFAULT_GOOGLE_ENDPOINT, aspectRatio: '1:1', imageSize: '1K' }
  }
}

/** 凭证环境变量名（供设置界面展示）。 */
export const KEY_REF: Record<ArtisanProvider, string> = {
  google: GOOGLE_API_KEY_ENV,
  openai: OPENAI_API_KEY_ENV,
  seedream: SEEDREAM_API_KEY_ENV,
  grok: GROK_API_KEY_ENV,
  codex: CODEX_CRED_REF,
}
