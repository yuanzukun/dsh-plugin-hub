/**
 * 原生工具集：从 taxue-halftone、taxue-creative-style、taxue-solar-polaroid、
 * compositor-retouch、skill-optimizer 五个技能吸纳精华，集成为原生 DSH 工具。
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { Context } from '@deepseek-ai/cordis'
import { getAllStyles, SEASONAL_TEMPLATES } from './styles.js'
import { CHECKUP_ITEMS, generateEditPlan, generateEditPrompt } from './editor.js'
import { scorePrompt, checkBaseline, getFixSuggestions } from './quality.js'

/** 注册所有原生工具到 DSH 宿主。在 apply() 末尾调用。 */
export function registerNativeTools(ctx: Context): void {
  ctx.tools.register(defineTool({
    name: 'artisan_styles',
    description: '列出所有可用的创作风格（半调海报 12 种 + 创意风格 14 家族 + 节气模板），按类别分组返回。',
    parameters: {
      category: {
        type: 'string',
        enum: ['all', 'halftone', 'creative', 'seasonal'],
        description: '风格类别，默认 all',
      },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false, properties: {
          count: { type: 'integer', required: true },
          styles: { type: 'array', required: true, items: { type: 'object', additionalProperties: false, properties: {
            id: { type: 'string', required: true },
            name: { type: 'string', required: true },
            prompt: { type: 'string', required: true },
            summary: { type: 'string' },
            mechanism: { type: 'string' },
            ink: { type: 'string' },
            paper: { type: 'string' },
            behavior: { type: 'string' },
            volume: { type: 'string' },
            keywords: { type: 'array', items: { type: 'string' } },
            category: { type: 'string' },
          } } },
        },
      },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute({ category = 'all' }) {
      if (category === 'seasonal') {
        return { styles: SEASONAL_TEMPLATES, count: SEASONAL_TEMPLATES.length }
      }
      let styles = getAllStyles()
      if (category === 'halftone') styles = styles.filter((s) => s.category === 'halftone')
      else if (category === 'creative') styles = styles.filter((s) => s.category === 'creative')
      return { styles, count: styles.length }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'artisan_edit',
    description: '图像编辑：体检 → 出修图方案 → 生成修图提示词。不把图喂回模型重画，用专业修图手法收尾。',
    parameters: {
      imageDesc: {
        type: 'string',
        required: true,
        description: '图像描述',
      },
      issues: {
        type: 'array',
        items: { type: 'string' },
        description: '体检发现的问题（从 CHECKUP_ITEMS 的 id 中选）',
      },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false, properties: {
          plan: { type: 'array', required: true, items: { type: 'object', additionalProperties: false, properties: {
            issue: { type: 'string', required: true },
            operation: { type: 'string', required: true },
            desc: { type: 'string', required: true },
          } } },
          prompt: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute({ imageDesc, issues = [] }) {
      const checkupResults = CHECKUP_ITEMS.map((item) => ({
        id: item.id,
        name: item.name,
        issue: issues.includes(item.id),
      }))
      const plan = generateEditPlan(checkupResults)
      const prompt = generateEditPrompt(imageDesc, plan)
      return { plan, prompt }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'artisan_quality',
    description: '质量审计：七维诊断打分 + 基线门控检查 + 修复建议。出图前检查提示词质量。',
    parameters: {
      prompt: {
        type: 'string',
        required: true,
        description: '要检查的提示词',
      },
      context: {
        type: 'object', additionalProperties: false, properties: {
          userIntent: { type: 'string' },
          targetStyle: { type: 'string' },
        },
        description: '打分上下文：用户意图与目标风格',
      },
    },
    output: {
      schema: {
        type: 'object', additionalProperties: false, properties: {
          total: { type: 'integer', required: true },
          dimensions: { type: 'object', additionalProperties: true },
          baseline: { type: 'object', additionalProperties: false, properties: {
            allPassed: { type: 'boolean', required: true },
            results: { type: 'array', required: true, items: { type: 'object', additionalProperties: false, properties: {
              gate: { type: 'string', required: true },
              passed: { type: 'boolean', required: true },
            } } },
          } },
          suggestions: { type: 'array', required: true, items: { type: 'string' } },
        },
      },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute({ prompt, context = {} }) {
      const score = scorePrompt(prompt, context)
      const baseline = checkBaseline(prompt)
      const suggestions = getFixSuggestions(prompt, context)
      return { ...score, baseline, suggestions }
    },
  }))
}
