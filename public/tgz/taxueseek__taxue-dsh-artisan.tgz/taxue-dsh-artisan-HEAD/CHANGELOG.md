# Changelog

## 0.3.1 — 2026-10-16

性能与修复；0.3.0 从未单独发布，技能桥等内容随本版首发。

- **性能：`reverse_prompt` 新增 `skip_polish`** — brief 已足够时模型可跳过 LLM 重组（2-5s → <10ms）；`missingCredentialError` 复用 `apply()` 已探测的 capability，消除每次 `generate_image` 的重复探测。
- **性能：订阅凭证按 provider 内存缓存**至过期前 60s，消除批量生图的反复磁盘 I/O；`saveGenerated` 改 fire-and-forget，落盘不阻塞返回，文件名加随机后缀防碰撞。
- **健壮性：`extract_palette` 加 25MiB 文件大小上限**（与 serveFileImage 对齐），防 OOM。
- **修复：peerDependencies 与生态对齐** — `@deepseek-ai/*` 从 `>=0.2.0 <0.3.0` 改为 `>=0.1.0-0 <0.3.0`（semver 中 prerelease 不满足 `>=0.2.0`，生态最新只到 0.1.0-rc.8），pnpm install 恢复可用。
- **构建：vendor 的 lib/ 重新生成入库** — 上一提交只带了 src，git 直装拿到的是旧构建；本次 lib 与 src 同步（tsc + tsdown 幂等产物）。

## 0.3.0
- 新增 **taxue-imagegen 技能桥**（子进程复用，技能零改动、零复制）：
  - `artisan_plan`：类型路由（A/B/C/D/E）与槽位清单，省去读 SKILL.md 的常驻开销。
  - `artisan_compose`：按技能元模板机械填槽，直出可生图提示词（内嵌静态预检）。
  - `artisan_preflight`：对手写提示词跑静态预检，拦截 11 个可文本检出的翻车项。
  - `artisan_check`：出图后验收（量测 + 文字带裁片 + 水印识别），返回三档判定。
  - 设计取舍：填槽/预检/验收逻辑经数十轮实测调优，重写即丢弃实测依据，故走子进程调用而非 TS 重写；脚本输出原样透传给模型，技能升级不会让解析器碎掉。
- 新增设置项 `skillRoot` / `skillPython` / `skillTimeoutMs`，均可留空自动探测（默认探测 `~/.workbuddy/skills/taxue-imagegen` 等路径与 WorkBuddy 内置 Python）。
- 瘦身工具 schema（信息点未删，只压缩冗余表述与重复枚举）：`reverse_prompt` 6046 → 5053 B（-16%），`generate_image` 4203 → 3106 B（-26%），`extract_palette` 1452 → 1249 B。
- 新增 `scripts/measure-tools.mjs`（`pnpm measure:tools`）：量测工具面常驻上下文体积，只统计真正进上下文的 description / parameters / output.schema。
- 新增 `tests/skill-bridge.mjs`：桥层探测、错误路径、四个工具的 execute 契约与 schema 合法性。
- **宿主适配（0.2.1-alpha.1）**：移除对 `@deepseek-ai/dsh-settings` 的 `installSettingsSection/settingsNamespace` 导入（宿主已删），改用 cordis 原生 `Config` 导出约定，设置表单由 configEditor 自动生成；删除失效的 dsh-settings-compat 垫片（其依赖的 `settings.register` 服务方法已不存在）。
- **色卡提取性能**：修复采样步长 bug（原实现为一维平铺步长，4K 图实际采样 ~45 万像素、超 12000 上限 37 倍，聚类 293ms），改为真二维网格采样，4K 聚类降至 15ms（整体 872→590ms，1K 110→41ms）；PNG 滤波还原改为原地计算，消除整图像素级副本分配。色卡输出与修复前可能有细微差别（采样位置更均匀），确定性不变。
- 新增 **五技能精华原生吸纳**（styles / editor / quality / native-tools 四模块）：
  - `artisan_styles`：风格库查询——半调海报 12 种（taxue-halftone）+ 创意风格 14 家族（taxue-creative-style）+ 节气推演模板 4 张（taxue-solar-polaroid），每条带可直接生图的英文 prompt。
  - `artisan_edit`：图像编辑三步法（compositor-retouch）——体检 → 出可回退修图方案 → 生成专业修图提示词；不把图喂回模型重画。
  - `artisan_quality`：提示词质量审计（skill-optimizer）——七维诊断打分 + 基线门控检查 + 修复建议。
  - 设计取舍：只吸纳「判断逻辑与数据表」（风格机制、六不变式、反模式、七维权重），模板正文与脚本逻辑仍留在技能里，保持单一真源。

## 0.2.0
- 确定性色卡提取（`extract_palette`）+ 参考图反推增强 + 双订阅生图（Grok / ChatGPT codex）。

## 0.1.1
- 生图支持订阅 / API Key 自动路由，多供应商（Gemini / OpenAI / Seedream / Grok）。

## 0.1.0
- 首版：提示词反推 / 优化 + 多供应商生图，支持异步后台出图。
