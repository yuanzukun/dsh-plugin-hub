# 用法示例

```text
reverse_prompt / optimize_prompt / generate_image
```
