/** 一张参考图的确定性色卡。 */
export interface ExtractedPalette {
    /** 主色 hex（占比最大的簇，输出真实出现过的采样像素而非簇心）。 */
    dominant: string;
    secondary: string;
    accent: string;
    /** 暗部/高光锚点色（L 过低或过高时存在；否则省略）。 */
    dark?: string;
    light?: string;
    /** 全部颜色及占比（0-100，一位小数，总和归一化）。 */
    swatches: Array<{
        hex: string;
        share: number;
        role: 'dominant' | 'secondary' | 'accent' | 'dark' | 'light' | 'supporting';
    }>;
}
interface DecodedPng {
    width: number;
    height: number;
    /** RGB 三通道交错像素，长度 = width*height*3。 */
    pixels: Uint8Array;
}
/** 解析 PNG（8-bit 非隔行，color type 0/2/3/4/6），返回 RGB 像素。 */
export declare function decodePng(buffer: Buffer): DecodedPng;
/**
 * 从一张图的 RGB 像素提取确定性色卡。width 为像素行宽（来自 decodePng），
 * 缺省按正方形近似——只影响网格形状，不影响确定性。
 *
 * 流程：确定性采样 → Oklab K-Means(k=8) → 近簇合并两轮 → 角色标注（主/辅/点缀/暗部/高光）
 * → 占比归一化。同一张图永远产出同一个色卡。
 */
export declare function extractPalette(pixels: Uint8Array, width?: number): ExtractedPalette;
export {};
