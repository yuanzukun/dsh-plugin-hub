/** 允许调用的脚本白名单（不接受任意路径，避免桥层变成通用命令执行入口）。 */
export declare const ALLOWED_SCRIPTS: readonly ['fill_meta.py', 'preflight.py', 'postcheck.py', 'build_storyboard.py'];
export type AllowedScript = (typeof ALLOWED_SCRIPTS)[number];
/** 可生图的技能类型；D 是半机械型（改 SCENES 列表），不在 fill_meta 里。 */
export declare const SKILL_TRACKS: readonly ['A', 'B', 'C', 'D', 'E'];
export type SkillTrack = (typeof SKILL_TRACKS)[number];
/** fill_meta.py 直接支持的类型。 */
export declare const FILL_META_TRACKS: readonly ['A', 'B', 'C', 'E'];
/** 桥层配置，来自插件设置。 */
export interface BridgeOptions {
    /** 技能根目录；留空则按候选列表探测。 */
    skillRoot?: string;
    /** Python 解释器路径；留空则按候选列表探测。 */
    pythonPath?: string;
    /** 单次脚本执行超时（ms）。 */
    timeoutMs?: number;
}
/** 子进程执行结果。 */
export interface ScriptResult {
    /** 退出码；被杀或异常时为 -1。 */
    code: number;
    stdout: string;
    stderr: string;
}
/** 解析技能根目录：显式配置优先，否则按候选探测。 */
export declare function resolveSkillRoot(options?: BridgeOptions): string | undefined;
/** 技能未就绪时的可操作报错。 */
export declare function skillMissingError(options?: BridgeOptions): Error;
/** 解析 Python 解释器：显式配置优先，否则按候选探测；只返回路径，可用性由首次调用暴露。 */
export declare function resolvePython(options?: BridgeOptions): string;
/** 重置探测缓存（设置变更后调用）。 */
export declare function resetBridgeCache(): void;
/**
 * 执行技能脚本。
 *
 * cwd 固定为技能根目录：脚本内部虽有自身路径解析，但记账与产物默认落在技能目录下，
 * 固定 cwd 可让这些相对路径行为与手动调用完全一致。
 */
export declare function runScript(options: BridgeOptions, script: AllowedScript, args: readonly string[], input?: string): Promise<ScriptResult>;
/** artisan_plan：列类型路由，或列指定类型的槽位清单。 */
export declare function planSlots(options: BridgeOptions, track?: SkillTrack): Promise<{
    track?: SkillTrack;
    text: string;
}>;
/** artisan_compose：槽位 → 可生图提示词。 */
export interface ComposeInput {
    track: Exclude<SkillTrack, 'D'>;
    /** 槽位键值对；键名以 artisan_plan 的清单为准。 */
    slots: Record<string, string>;
    /** 类型 B 主题名。 */
    theme?: string;
    /** 类型 A 满铺型变体。 */
    manpu?: boolean;
    /** 允许缺槽/残留槽位（半成品）。 */
    allowPartial?: boolean;
}
export declare function composePrompt(options: BridgeOptions, input: ComposeInput): Promise<{
    prompt: string;
    warnings: string[];
}>;
/** artisan_compose 的手写检查模式：对现成提示词跑静态预检。 */
export declare function preflightText(options: BridgeOptions, track: SkillTrack, text: string): Promise<{
    report: string;
    ok: boolean;
}>;
/** 出图后验收。 */
export interface CheckInput {
    /** 待验收图片的绝对路径。 */
    path: string;
    track?: SkillTrack;
    /** 是否加测顶部留白（类型 A 必用）。 */
    top?: boolean;
    /** 文案逐字目检结论；不传则脚本判 pending（文字未核对不得计 pass）。 */
    text?: 'ok' | 'bad';
    /** 类型 E 声明格数，用于校验「说的和画的」是否一致。 */
    expectCells?: number;
    /** 不写 runs.csv（跑验证时用）。 */
    noLog?: boolean;
}
/** postcheck 退出码语义（技能 v1.10+ 三档）：0=pass，1=blocker，3=pending。 */
export type CheckVerdict = 'pass' | 'blocker' | 'pending' | 'unknown';
export declare function checkImage(options: BridgeOptions, input: CheckInput): Promise<{
    verdict: CheckVerdict;
    report: string;
}>;
