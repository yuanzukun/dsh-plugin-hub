/** 一张已编码的内联参考图。 */
export interface InlineReferenceImage {
    /** 纯 base64（无 data: 前缀）。 */
    base64: string;
    mediaType: 'image/png' | 'image/jpeg' | 'image/webp';
}
/** 支持的参考图扩展名集合。 */
export declare const SUPPORTED_REFERENCE_EXTS: Set<string>;
/** 读取并把一张本地参考图编码为内联 base64。不支持 GIF（三家生图端均不接受 GIF 输入）。 */
export declare function loadInlineReference(path: string): Promise<InlineReferenceImage>;
/** 批量加载；单张失败抛错并注明是第几张。 */
export declare function loadInlineReferences(paths: readonly string[]): Promise<InlineReferenceImage[]>;
