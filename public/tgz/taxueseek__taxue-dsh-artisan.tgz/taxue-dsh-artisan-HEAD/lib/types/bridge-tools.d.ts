import type { Context } from '@deepseek-ai/cordis';
import { type BridgeOptions } from './skill-bridge.js';
/** 注册技能桥工具。bridgeOptions 由 apply() 用当下配置现取（设置变更即时生效）。 */
export declare function registerBridgeTools(ctx: Context, bridgeOptions: () => BridgeOptions): void;
