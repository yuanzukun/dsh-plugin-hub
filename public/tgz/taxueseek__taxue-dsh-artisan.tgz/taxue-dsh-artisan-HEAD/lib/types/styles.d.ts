/**
 * 原生风格库：从 taxue-halftone、taxue-creative-style、taxue-solar-polaroid 三个技能吸纳精华。
 *
 * 设计原则：
 * - 每个风格是一个自包含的提示词模板，不依赖外部脚本
 * - 六不变式（纸/墨/印刷布尔/机制/主体行为/字图音量）作为所有风格的共同约束
 * - 反模式表作为出图前的静态检查
 */
export declare const SIX_INVARIANTS: {
    paper: string;
    ink: string;
    printing: string;
    mechanism: string;
    behavior: string;
    volume: string;
};
export declare const ANTI_PATTERNS: {
    id: string;
    pattern: string;
    fix: string;
}[];
export declare const HALFTONE_STYLES: {
    id: string;
    name: string;
    summary: string;
    mechanism: string;
    ink: string;
    paper: string;
    behavior: string;
    volume: string;
    prompt: string;
}[];
export declare const CREATIVE_FAMILIES: {
    id: string;
    name: string;
    summary: string;
    prompt: string;
}[];
export declare const SEASONAL_TEMPLATES: {
    id: string;
    name: string;
    keywords: string[];
    prompt: string;
}[];
export declare function getAllStyles(): {
    id: string;
    name: string;
    summary: string;
    prompt: string;
    category: string;
}[];
export declare function getStyleById(id: string): {
    id: string;
    name: string;
    summary: string;
    prompt: string;
    category: string;
} | undefined;
export declare function getSeasonalTemplate(text: string): {
    id: string;
    name: string;
    keywords: string[];
    prompt: string;
} | null;
export declare function checkAntiPatterns(prompt: string): {
    id: string;
    pattern: string;
    fix: string;
}[];
