import type { Context } from '@deepseek-ai/cordis';
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
import type { SettingsScope } from '@deepseek-ai/dsh-client-runtime/client';
import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type ArtisanProvider } from '../shared.js';
interface ArtisanSettings {
    provider?: ArtisanProvider;
    googleModel?: string;
    googleEndpoint?: string;
    openaiBaseURL?: string;
    openaiModel?: string;
    seedreamBaseURL?: string;
    seedreamModel?: string;
    grokBaseURL?: string;
    grokModel?: string;
    codexBaseURL?: string;
    codexModel?: string;
    saveDir?: string;
    skillRoot?: string;
    skillPython?: string;
    skillTimeoutMs?: number;
}
interface LocaleService {
    getSnapshot(): {
        active: string;
    };
    subscribe(fn: () => void): () => void;
}
interface SettingsFace {
    scope: SettingsScope<ArtisanSettings>;
    credentials: ConnectionHandle['api']['credentials'];
    locale?: LocaleService | undefined;
}
type SettingsCardProps = PropsRuntime<'settings.plugin.item'> & InjectFace<SettingsFace>;
type ImageCardProps = PropsRuntime<'tool.call.toolview'>;
/** 所需浏览器服务。settingsScope 在 dsh 0.2.0-rc.2 改名 webUiSettings（由 web-ui-settings 表面提供）。 */
export declare const inject: string[];
/** 挂载设置卡片与生成图卡片。 */
export declare function apply(ctx: Context): void;
/** 编辑厂商设置与其只写 API 凭证。 */
export declare function ArtisanSettingsCard(props: SettingsCardProps): import("react").JSX.Element;
/** 渲染一次已完成的图像工具调用引用的持久化附件。 */
/** 渲染一次已完成的图像工具调用：生成图 + 参考图并排对比。 */
export declare function GeneratedImageCard(props: ImageCardProps): import("react").JSX.Element;
/** reverse_prompt 的对话内预览：展示参考图（来自调用参数的 reference_assets）。 */
interface ReverseToolviewProps extends ImageCardProps {
    locale?: {
        getSnapshot(): {
            active: string;
        };
        subscribe(fn: () => void): () => void;
    };
}
export declare function ReversePromptToolview(props: ReverseToolviewProps): import("react").JSX.Element;
export {};
