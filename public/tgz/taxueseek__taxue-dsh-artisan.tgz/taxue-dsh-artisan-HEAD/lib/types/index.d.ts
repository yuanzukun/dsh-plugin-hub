import type { Context } from '@deepseek-ai/cordis';
import { ArtisanConfig } from './config.js';
export { ArtisanConfig, ArtisanConfig as Config } from './config.js';
export { ARTISAN_FILE_IMAGE_ROUTE, ARTISAN_IMAGE_ROUTE, imageAttachmentFromMeta } from './image-route.js';
export { optimizePrompt, reversePrompt } from './compiler.js';
export type { ReversePromptInput, ReversePromptOutput } from './compiler.js';
/** Cordis 插件名。 */
export declare const name = "taxue-dsh-artisan";
/** 主机端所需服务。llm 是 harness 核心必需（agent 运行时必有，反推重组器默认走它）；jobs 用于异步后台生图，可选（无则后台生图报错、同步仍可用，走 ctx.get 判空）。 */
export declare const inject: readonly ['tools', 'attachments', 'credentials', 'webServer', 'llm'];
/** 注册设置、图片路由与模型可调用的工具。设置表单由 cordis 原生 Config 约定（configEditor 读 Config 导出）提供。 */
export declare function apply(ctx: Context, config?: ArtisanConfig): void;
