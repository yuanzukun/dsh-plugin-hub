/** taxue-dsh-artisan 主机端与浏览器端共享常量。 */
/** 浏览器端用于结果卡片的同源图片路由。 */
export declare const ARTISAN_IMAGE_ROUTE = "/plugins/taxue-dsh-artisan/image";
/** 浏览器端用于参考图文件路径预览的同源路由。 */
export declare const ARTISAN_FILE_IMAGE_ROUTE = "/plugins/taxue-dsh-artisan/file-image";
/** DSH 设置持久化命名空间。 */
export declare const ARTISAN_SETTINGS_NAMESPACE = "taxue-artisan";
/** 支持的供应商：google/openai/seedream/grok 走 API Key；codex 走 ChatGPT 订阅（gpt-image-2）。 */
export declare const ARTISAN_PROVIDERS: readonly ['google', 'openai', 'seedream', 'grok', 'codex'];
export type ArtisanProvider = (typeof ARTISAN_PROVIDERS)[number];
/** 各供应商默认接口地址。 */
export declare const DEFAULT_GOOGLE_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/interactions";
export declare const DEFAULT_OPENAI_BASE_URL = "https://api.openai.com/v1";
export declare const DEFAULT_SEEDREAM_BASE_URL = "https://ark.cn-beijing.volces.com/api/v3";
export declare const DEFAULT_GROK_BASE_URL = "https://api.x.ai/v1";
export declare const DEFAULT_CODEX_BASE_URL = "https://chatgpt.com/backend-api/codex";
/** 各供应商默认模型。 */
export declare const DEFAULT_GOOGLE_MODEL = "gemini-3.1-flash-image";
export declare const DEFAULT_OPENAI_MODEL = "gpt-image-2";
export declare const DEFAULT_SEEDREAM_MODEL = "doubao-seedream-5-0-260128";
export declare const DEFAULT_GROK_MODEL = "grok-imagine-image-2.0";
export declare const DEFAULT_CODEX_MODEL = "gpt-image-2";
export declare const DEFAULT_MODELS: Record<ArtisanProvider, string>;
export declare const DEFAULT_BASE_URLS: Record<ArtisanProvider, string>;
