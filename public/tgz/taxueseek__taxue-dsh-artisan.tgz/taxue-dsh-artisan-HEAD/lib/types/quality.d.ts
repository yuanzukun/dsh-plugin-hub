/**
 * 原生质量审计：从 skill-optimizer 吸纳精华。
 *
 * 七维诊断打分 + 基线门控 + 修复建议
 */
export declare const SEVEN_DIMENSIONS: {
    id: string;
    name: string;
    weight: number;
    desc: string;
}[];
export declare const BASELINE_GATES: {
    id: string;
    name: string;
    check: (prompt: string) => boolean;
}[];
export declare function scorePrompt(prompt: string, context?: {
    userIntent?: string;
    targetStyle?: string;
}): {
    total: number;
    dimensions: Record<string, {
        name: string;
        score: number;
        weight: number;
    }>;
};
export declare function checkBaseline(prompt: string): {
    allPassed: boolean;
    results: {
        gate: string;
        passed: boolean;
    }[];
};
export declare function getFixSuggestions(prompt: string, context?: {
    userIntent?: string;
    targetStyle?: string;
}): string[];
