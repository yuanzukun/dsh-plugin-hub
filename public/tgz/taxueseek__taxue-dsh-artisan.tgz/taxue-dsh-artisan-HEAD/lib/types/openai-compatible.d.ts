/** OpenAI Images、xAI Grok 与 Volcengine Ark/Seedream 的 OpenAI 兼容响应适配。 */
import type { ImageMediaType } from '@deepseek-ai/dsh-attachment';
/** 一张已规范化的栅格图，等待 Attachment 持久化。 */
export interface GeneratedCompatibleImage {
    data: Uint8Array;
    mediaType: ImageMediaType;
}
/** 从 OpenAI 兼容端点生成一张图。 */
export declare function generateOpenAICompatibleImage(input: {
    provider: 'openai' | 'seedream' | 'grok';
    apiKey: string;
    baseURL: string;
    model: string;
    prompt: string;
    size: string;
    aspectRatio?: string | undefined;
    /** 可选参考图（内联 base64）。默认不带；显式传入时才随请求上传。 */
    referenceImages?: Array<{
        base64: string;
        mediaType: string;
    }> | undefined;
    maxBytes: number;
    signal: AbortSignal;
}): Promise<GeneratedCompatibleImage>;
/** 从 ChatGPT 订阅（codex）端点生成一张图：gpt-image-2，走 chatgpt.com 专属头。 */
export declare function generateCodexImage(input: {
    accessToken: string;
    accountId?: string | undefined;
    baseURL: string;
    model: string;
    prompt: string;
    size?: string | undefined;
    quality?: string | undefined;
    /** 可选参考图（内联 base64），gpt-image 支持以 image 数组传入。 */
    referenceImages?: Array<{
        base64: string;
        mediaType: string;
    }> | undefined;
    maxBytes: number;
    signal: AbortSignal;
}): Promise<GeneratedCompatibleImage>;
