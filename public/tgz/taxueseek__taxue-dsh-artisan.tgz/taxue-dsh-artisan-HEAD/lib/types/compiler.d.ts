/** 提示词反推/优化/审计的本地纯函数编译器。不调用远程模型，不读取或上传素材。 */
export declare const REVERSE_MODES: readonly ['image_reverse', 'video_reverse', 'prompt_optimize', 'meta_prompt'];
export declare const TARGETS: readonly ['image', 'video', 'both'];
export declare const PLATFORMS: readonly ['universal', 'seedream', 'nano_banana', 'midjourney', 'runway', 'veo', 'sora', 'kling', 'grok', 'other'];
export type ReverseMode = (typeof REVERSE_MODES)[number];
export type Target = (typeof TARGETS)[number];
export type Platform = (typeof PLATFORMS)[number];
export type OutputLanguage = 'zh-CN' | 'en' | 'bilingual';
export interface ReferenceAsset {
    uri: string;
    role?: 'content' | 'composition' | 'color' | 'material' | 'motion' | 'audio' | 'mixed';
    notes?: string;
    rights?: 'user_owned' | 'licensed' | 'public_domain' | 'unknown';
}
export interface ReversePromptInput {
    mode: ReverseMode;
    target: Target;
    platform: Platform;
    brief: string;
    current_prompt?: string;
    reference_assets?: ReferenceAsset[];
    preserve?: string[];
    change?: string[];
    avoid?: string[];
    output_language?: OutputLanguage;
    dynamic_charcoal_mode?: boolean;
    /** 参考图真实像素宽。模型在 read_image 后把返回的 width 填进来，用于精确还原画幅比例。 */
    image_width?: number;
    /** 参考图真实像素高。模型在 read_image 后把返回的 height 填进来，用于精确还原画幅比例。 */
    image_height?: number;
}
export interface ReversePromptOutput {
    task_id: string;
    task_summary: string;
    /** 直出：可直接用于生图的完整提示词（已还原参考图的文字排版、风格与细节）。 */
    prompt: string;
    /** 优化方向建议（可执行、单条一个变量）。 */
    optimization_advice: string[];
    /** 参考图推断的画幅建议（如 9:16 / 16:9 / 1:1）。 */
    aspect_ratio: string;
    /** 同规格同风格新图引导：生成一张与参考图同尺寸、同风格的新图提示词。 */
    variant_guidance: string;
    quality_gate: string[];
    risk_flags: string[];
    clarification_questions: string[];
}
export interface OptimizePromptInput {
    target: Target;
    prompt: string;
    output_language?: OutputLanguage;
    dynamic_charcoal_mode?: boolean;
}
export interface OptimizePromptOutput {
    summary: string;
    warnings: string[];
    risk_flags: string[];
    next_single_variable_test: string;
}
/** 主反推工具：直出可生图提示词 + 优化建议 + 画幅建议 + 新图引导。 */
export declare function reversePrompt(input: ReversePromptInput): ReversePromptOutput;
/** 前置诊断器：只做本地结构审计，不评判审美。 */
export declare function optimizePrompt(input: OptimizePromptInput): OptimizePromptOutput;
