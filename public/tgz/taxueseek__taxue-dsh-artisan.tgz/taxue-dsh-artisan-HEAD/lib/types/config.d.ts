/** 面向用户的供应商配置与运行时解析。 */
import z from '@deepseek-ai/schemastery';
import { DEFAULT_CODEX_BASE_URL, DEFAULT_CODEX_MODEL, DEFAULT_GOOGLE_ENDPOINT, DEFAULT_GOOGLE_MODEL, DEFAULT_GROK_BASE_URL, DEFAULT_GROK_MODEL, DEFAULT_OPENAI_BASE_URL, DEFAULT_OPENAI_MODEL, DEFAULT_SEEDREAM_BASE_URL, DEFAULT_SEEDREAM_MODEL, ARTISAN_PROVIDERS, type ArtisanProvider } from './shared.js';
export { DEFAULT_CODEX_BASE_URL, DEFAULT_CODEX_MODEL, DEFAULT_GOOGLE_ENDPOINT, DEFAULT_GOOGLE_MODEL, DEFAULT_GROK_BASE_URL, DEFAULT_GROK_MODEL, DEFAULT_OPENAI_BASE_URL, DEFAULT_OPENAI_MODEL, DEFAULT_SEEDREAM_BASE_URL, DEFAULT_SEEDREAM_MODEL, ARTISAN_PROVIDERS, type ArtisanProvider, };
/** 各供应商的凭证引用。 */
export declare const GOOGLE_API_KEY_ENV = "GEMINI_API_KEY";
export declare const OPENAI_API_KEY_ENV = "OPENAI_API_KEY";
export declare const SEEDREAM_API_KEY_ENV = "ARK_API_KEY";
export declare const GROK_API_KEY_ENV = "XAI_API_KEY";
/** codex 无 API Key，该常量仅用于设置页与报错文案的展示位。 */
export declare const CODEX_CRED_REF = "CODEX_SUBSCRIPTION";
/** Google 原生工具控制。 */
/** Google 原生支持的画幅子集。 */
export declare const GOOGLE_ASPECT_RATIOS: readonly ['1:1', '3:2', '2:3', '4:3', '3:4', '16:9', '9:16'];
/** 工具层暴露的完整画幅集：Google 子集 + Grok/Seedream 支持的扩展比例。 */
export declare const ASPECT_RATIOS: readonly ["1:1", "3:2", "2:3", "4:3", "3:4", "16:9", "9:16", "2:1", "1:2", "19.5:9", "9:19.5", "20:9", "9:20", "auto"];
export declare const IMAGE_SIZES: readonly ['1K', '2K', '4K'];
export type AspectRatio = (typeof ASPECT_RATIOS)[number];
export type GoogleAspectRatio = (typeof GOOGLE_ASPECT_RATIOS)[number];
export type ImageSize = (typeof IMAGE_SIZES)[number];
/** Bundle 配置：来自 profile 补丁层与 Web 设置页。 */
export interface ArtisanConfig {
    provider?: ArtisanProvider;
    googleModel?: string;
    googleEndpoint?: string;
    openaiBaseURL?: string;
    openaiModel?: string;
    seedreamBaseURL?: string;
    seedreamModel?: string;
    grokBaseURL?: string;
    grokModel?: string;
    codexBaseURL?: string;
    codexModel?: string;
    /** 生成图落盘目录；空串用默认（~/Downloads）。 */
    saveDir?: string;
    /** generate_image 单次执行超时（ms）。 */
    toolTimeoutMs?: number;
    /** taxue-imagegen 技能目录（含 scripts/fill_meta.py）；留空按 ~/.workbuddy 等候选探测。 */
    skillRoot?: string;
    /** 技能脚本使用的 Python 解释器；留空按 WorkBuddy 内置环境、Homebrew 等候选探测。 */
    skillPython?: string;
    /** 技能脚本单次执行超时（ms）。 */
    skillTimeoutMs?: number;
    /** 开启 reverse_prompt 的 LLM 反推重组（把观察描述转译为真正提示词）；llm 为 harness 必需，默认开启。 */
    llmPolish?: boolean;
    /** LLM 润色所用 provider（缺省用 llm 第一个注册 provider）；配合 llmPolish 使用。 */
    llmPolishProvider?: string;
    /** LLM 润色所用模型 id（缺省用该 provider 第一个模型）；配合 llmPolish 使用。 */
    llmPolishModel?: string;
}
/** Cordis 配置 schema。 */
export declare const ArtisanConfig: z<ArtisanConfig>;
type GoogleProfile = {
    provider: 'google';
    apiKeyEnv: string;
    model: string;
    endpoint: string;
    aspectRatio: AspectRatio;
    imageSize: ImageSize;
};
type CompatProfile = {
    provider: 'openai' | 'seedream' | 'grok' | 'codex';
    apiKeyEnv: string;
    model: string;
    baseURL: string;
    imageSize: string;
};
/** 为一次工具调用解析出恰好一个供应商 profile。 */
export declare function resolveProvider(config: ArtisanConfig): GoogleProfile | CompatProfile;
/** 凭证环境变量名（供设置界面展示）。 */
export declare const KEY_REF: Record<ArtisanProvider, string>;
