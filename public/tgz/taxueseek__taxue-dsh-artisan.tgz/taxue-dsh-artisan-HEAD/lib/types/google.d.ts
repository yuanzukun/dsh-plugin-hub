/** Google Gemini Interactions API 适配。 */
import type { ImageMediaType } from '@deepseek-ai/dsh-attachment';
import type { AspectRatio, ImageSize } from './config.js';
/** Attachment 持久化前的生图字节。 */
export interface GeneratedImage {
    data: Uint8Array;
    mediaType: ImageMediaType;
}
/** 发送一次原生 Google 图像请求并校验其内联图像响应。 */
export declare function generateGoogleImage(input: {
    apiKey: string;
    endpoint: string;
    model: string;
    prompt: string;
    aspectRatio: AspectRatio;
    imageSize: ImageSize;
    /** 可选参考图（内联 base64），随 prompt 一起作为生成输入。 */
    referenceImages?: Array<{
        base64: string;
        mediaType: string;
    }> | undefined;
    maxBytes: number;
    signal: AbortSignal;
}): Promise<GeneratedImage>;
