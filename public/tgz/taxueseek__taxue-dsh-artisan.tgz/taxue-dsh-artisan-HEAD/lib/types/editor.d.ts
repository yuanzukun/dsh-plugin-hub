/**
 * 原生图像编辑工具：从 compositor-retouch 吸纳精华。
 *
 * 三步流程：体检 → 出可回退的工程 → 渲染成稿
 * 核心立场：AI 出的图是原料，修图师的手法负责收尾。不把图喂回模型重画。
 */
export declare const EDITING_PRINCIPLES: string[];
export declare const CHECKUP_ITEMS: {
    id: string;
    name: string;
    check: string;
}[];
export declare const EDIT_OPERATIONS: {
    id: string;
    name: string;
    desc: string;
}[];
export declare function generateEditPlan(checkupResults: Array<{
    id: string;
    name: string;
    issue: boolean;
}>): {
    issue: string;
    operation: string;
    desc: string;
}[];
export declare function generateEditPrompt(imageDesc: string, operations: Array<{
    operation: string;
}>): string;
