import type { Context } from '@deepseek-ai/cordis';
/** 注册所有原生工具到 DSH 宿主。在 apply() 末尾调用。 */
export declare function registerNativeTools(ctx: Context): void;
