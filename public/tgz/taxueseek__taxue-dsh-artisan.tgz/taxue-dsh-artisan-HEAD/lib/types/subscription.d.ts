/** 一个可用的订阅会话（accessToken 必填；codex 额外需要 accountId）。 */
export interface SubscriptionSession {
    accessToken: string;
    accountId?: string;
}
/** 返回未过期的订阅 accessToken；未登录、已过期或读取失败返回 undefined（不抛错）。磁盘 I/O 在进程生命周期内按 provider 缓存。 */
export declare function resolveSubscriptionToken(provider: 'grok' | 'codex'): Promise<SubscriptionSession | undefined>;
/** 返回未过期的 Grok 订阅 accessToken；未登录、已过期或读取失败返回 undefined（不抛错）。 */
export declare function resolveGrokSubscriptionToken(): Promise<string | undefined>;
/** 返回未过期的 ChatGPT（codex）订阅会话；未登录或已过期返回 undefined（不抛错）。 */
export declare function resolveCodexSubscriptionToken(): Promise<SubscriptionSession | undefined>;
/** 是否具备可用的 Grok 订阅生图能力。 */
export declare function hasGrokSubscription(): Promise<boolean>;
