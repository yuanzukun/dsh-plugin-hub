/** 从 Web 结果卡片到 Attachment 服务的同源 HTTP 桥。 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { ImageAttachmentRef, StoredImageAttachment } from '@deepseek-ai/dsh-attachment';
export { ARTISAN_FILE_IMAGE_ROUTE, ARTISAN_IMAGE_ROUTE } from './shared.js';
/** 参考图文件路径预览的最大字节（25 MiB）。 */
export declare const MAX_FILE_BYTES: number;
/**
 * 跨平台同源校验：Origin 只比 host 部分，不比完整 scheme://host 字符串。
 * TLS 可能在上游终结（反向代理 / 隧道）：服务端看到的是明文 HTTP socket，
 * 而浏览器 Origin 是 https。比完整串会把合法请求误判为跨源（403）。
 * 端口默认（:80/:443）不参与比较。返回 null 表示放行。
 */
export declare function sameOriginCheck(origin: string | undefined, host: string | undefined): string | null;
/** 图片路由所需的依赖。 */
export interface ArtisanImageRouteDeps {
    readImage(ref: ImageAttachmentRef): Promise<StoredImageAttachment>;
}
/** 向同源浏览器请求提供一个已校验的持久化图片引用。 */
export declare function serveImage(req: IncomingMessage, res: ServerResponse, deps: ArtisanImageRouteDeps): Promise<void>;
/** 校验工具展示携带的持久化引用。 */
export declare function imageAttachmentFromMeta(meta: unknown): ImageAttachmentRef | undefined;
/** 参考图文件预览路由所需依赖。 */
export interface ArtisanFileImageDeps {
    readFile(path: string): Promise<Uint8Array | undefined>;
}
/** 向同源浏览器提供一张本地图片文件（用于参考图路径预览）。仅允许绝对路径与图片扩展名。 */
export declare function serveFileImage(req: IncomingMessage, res: ServerResponse, deps: ArtisanFileImageDeps): Promise<void>;
