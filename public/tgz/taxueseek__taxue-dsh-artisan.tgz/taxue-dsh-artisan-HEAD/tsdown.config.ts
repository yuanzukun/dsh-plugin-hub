/** 独立主机端与浏览器端 bundle 输出。 */
import type { UserConfig } from 'tsdown'

const CLIENT_EXTERNALS = [
  'react',
  'react/jsx-runtime',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-runtime/client',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-ui-attachment',
]

const host: UserConfig = {
  name: 'taxue-dsh-artisan',
  entry: ['lib/types/index.js'],
  outDir: 'lib',
  format: ['esm'],
  platform: 'node',
  target: 'es2024',
  fixedExtension: false,
  dts: false,
  clean: false,
}

// 纯函数编译器：独立 esm 产物，供测试与潜在复用直接 import。
const compiler: UserConfig = {
  name: 'taxue-dsh-artisan/compiler',
  entry: { compiler: 'lib/types/compiler.js' },
  outDir: 'lib',
  format: ['esm'],
  platform: 'node',
  target: 'es2024',
  fixedExtension: false,
  dts: false,
  clean: false,
  outputOptions: {
    entryFileNames: '[name].mjs',
  },
}

const client: UserConfig = {
  name: 'taxue-dsh-artisan/client',
  entry: { client: 'lib/types/client/index.js' },
  outDir: 'lib',
  format: 'cjs',
  platform: 'browser',
  target: 'es2022',
  dts: false,
  sourcemap: true,
  clean: false,
  external: CLIENT_EXTERNALS,
  noExternal: (_id: string) => true,
  outputOptions: {
    entryFileNames: 'client.js',
    banner: 'window.__ModuleLoader__.load({ id: "taxue-dsh-artisan", factory: (require) => {',
    footer: 'return module.exports; } });',
    intro: 'var module = { exports: {} }; var exports = module.exports;',
  },
}

// 技能桥：独立 esm 产物，供测试直接 import（探测与子进程调用可脱离 DSH 运行时验证）。
const skillBridge: UserConfig = {
  name: 'taxue-dsh-artisan/skill-bridge',
  entry: { 'skill-bridge': 'lib/types/skill-bridge.js' },
  outDir: 'lib',
  format: ['esm'],
  platform: 'node',
  target: 'es2024',
  fixedExtension: false,
  dts: false,
  clean: false,
  outputOptions: {
    entryFileNames: '[name].mjs',
  },
}

export default [host, compiler, skillBridge, client]
