# 工具

## 原生工具（本地纯函数 + 多供应商生图）

| 工具 | 作用 | 是否调远程 |
|---|---|---|
| `reverse_prompt` | 反推图像/视频提示词并直出可生图提示词 | 否 |
| `optimize_prompt` | 提示词结构审计与单变量优化建议 | 否 |
| `extract_palette` | 确定性色卡提取（Oklab K-Means，无随机种子） | 否 |
| `generate_image` | 多供应商生图（Gemini / OpenAI / Seedream / Grok / codex 订阅） | 是 |
| `artisan_styles` | 风格库查询：半调 12 种 + 创意 14 家族 + 节气模板 4 张（吸纳自 taxue-halftone / creative-style / solar-polaroid） | 否 |
| `artisan_edit` | 图像编辑三步法：体检 → 修图方案 → 修图提示词（吸纳自 compositor-retouch） | 否 |
| `artisan_quality` | 七维质量审计 + 基线门控 + 修复建议（吸纳自 skill-optimizer） | 否 |

## 技能桥（复用 taxue-imagegen，子进程调用）

桥层把 taxue-imagegen 技能的 Python 脚本接成插件工具，**技能本身零改动、零复制**：槽位清单、模板正文、验收阈值全部从技能目录读取，保持单一真源。

| 工具 | 作用 | 对应技能脚本 |
|---|---|---|
| `artisan_plan` | 类型路由（A/B/C/D/E）与槽位清单 | `fill_meta.py --list` / `build_storyboard.py` |
| `artisan_compose` | 机械填槽组装可生图提示词（内嵌预检） | `fill_meta.py` |
| `artisan_preflight` | 手写提示词静态预检 | `preflight.py` |
| `artisan_check` | 出图后验收，返回 pass / blocker / pending | `postcheck.py` |

### 配置

设置 → 插件 → taxue 画师：

| 项 | 说明 |
|---|---|
| 技能目录 | taxue-imagegen 根目录（含 `scripts/fill_meta.py`）。留空按 `~/.workbuddy/skills/taxue-imagegen`、`~/.agents/skills/...`、`~/.claude/skills/...` 顺序探测。 |
| Python 解释器 | 留空按 WorkBuddy 内置环境、`/opt/homebrew/bin/python3`、`/usr/local/bin/python3`、`python3` 顺序探测。技能脚本需 numpy / PIL / opencv。 |
| 脚本超时 | 单次脚本执行超时（ms），默认 60000。 |

### 典型链路

```
artisan_plan      → 拿到类型与槽位清单
artisan_compose   → 槽位进、可生图提示词出
generate_image    → 出图（或 workbuddy_generate_image 走 WorkBuddy 混元）
artisan_check     → 三档验收，blocker 才允许一次定向重生
```

手写或改造提示词时，送生图前单独跑 `artisan_preflight`；`artisan_compose` 组装出的提示词已内嵌预检，不必重复调用。

### 量测

`pnpm measure:tools` 输出工具面常驻上下文体积（只统计 description / parameters / output.schema，execute 代码不计）。
