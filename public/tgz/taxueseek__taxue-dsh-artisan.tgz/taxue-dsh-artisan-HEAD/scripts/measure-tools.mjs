/**
 * 工具面体积量测：把插件注册的工具定义喂给 mock ctx 收集，只统计真正进上下文的三部分
 * （description / parameters / output.schema），execute 代码不计。
 * 用法：node scripts/measure-tools.mjs [--json]
 */
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const { defineTool } = require('@deepseek-ai/dsh-tools')

const collected = []
const noop = () => {}
const ctx = {
  tools: { register: (tool) => { collected.push(tool); return tool } },
  effect: (fn) => { try { fn() } catch { /* mock 环境下的注册副作用可忽略 */ } },
  inject: () => { /* 设置段安装跳过：不影响工具 schema 量测 */ },
  webServer: { register: noop },
  get: () => undefined,
  attachments: { imageLimits: { maxImageBytes: 1e7, mediaTypes: ['image/png', 'image/jpeg', 'image/webp'] }, saveImage: noop, readImage: noop },
  credentials: { get: noop },
  llm: undefined,
  logger: { info: noop, warn: noop, error: noop, debug: noop },
}

const mod = await import('../lib/index.js')
mod.apply(ctx, {})

const bytes = (value) => (value === undefined ? 0 : Buffer.byteLength(JSON.stringify(value), 'utf-8'))
let total = 0
const rows = []
for (const tool of collected) {
  const description = Buffer.byteLength(tool.description ?? '', 'utf-8')
  const parameters = bytes(tool.parameters)
  const output = bytes(tool.output?.schema)
  const sum = description + parameters + output
  total += sum
  rows.push({ name: tool.name, description, parameters, output, sum })
}

rows.sort((a, b) => b.sum - a.sum)
const pad = (text, width) => String(text).padEnd(width)
console.log(`${pad('tool', 20)}${pad('description', 14)}${pad('parameters', 14)}${pad('output.schema', 16)}${pad('合计', 12)}`)
for (const row of rows) {
  console.log(`${pad(row.name, 20)}${pad(row.description, 14)}${pad(row.parameters, 14)}${pad(row.output, 16)}${pad(row.sum, 12)}`)
}
console.log(`${pad('TOTAL', 20)}${pad('', 14)}${pad('', 14)}${pad('', 16)}${pad(total, 12)}`)
console.log(`\n常驻上下文合计 ${total} B ≈ ${Math.round(total / 3)} token（中文按 3 B/字符粗估）`)
if (process.argv.includes('--json')) console.log(JSON.stringify(rows, null, 2))
