import assert from 'node:assert/strict'
import { existsSync, writeFileSync, unlinkSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join as pathJoin } from 'node:path'
import zlib from 'node:zlib'
import {
  ALLOWED_SCRIPTS,
  FILL_META_TRACKS,
  SKILL_TRACKS,
  checkImage,
  composePrompt,
  planSlots,
  preflightText,
  resolvePython,
  resolveSkillRoot,
  runScript,
  skillMissingError,
} from '../lib/skill-bridge.mjs'

// ── 常量契约 ──
assert.deepEqual([...SKILL_TRACKS], ['A', 'B', 'C', 'D', 'E'], '五种技能类型')
assert.deepEqual([...FILL_META_TRACKS], ['A', 'B', 'C', 'E'], '类型 D 不在 fill_meta 里')
assert.ok(ALLOWED_SCRIPTS.includes('fill_meta.py') && ALLOWED_SCRIPTS.includes('postcheck.py'), '白名单含关键脚本')
assert.equal(ALLOWED_SCRIPTS.length, 4, '白名单不得悄悄扩大（桥层不接受任意脚本）')

// ── 探测失败路径：不存在的 skillRoot 必须明确失败，不静默降级 ──
assert.equal(resolveSkillRoot({ skillRoot: '/nonexistent/taxue-imagegen-xyz' }), undefined, '假路径应探测失败')
const missing = skillMissingError({ skillRoot: '/nonexistent/taxue-imagegen-xyz' })
assert.match(missing.message, /skillRoot|找不到/, '缺技能时应指出配置项')
assert.match(missing.message, /设置/, '缺技能时应指向设置页')
await assert.rejects(
  () => runScript({ skillRoot: '/nonexistent/taxue-imagegen-xyz' }, 'fill_meta.py', ['A', '--list']),
  /taxue-imagegen|skillRoot/,
  '技能缺失时 runScript 应抛可操作错误',
)
assert.ok(resolvePython({}).length > 0, 'Python 解释器应能解析出路径或回退 python3')

// ── 真实技能存在时的端到端（技能缺席则整体跳过，保持测试可移植） ──
const root = resolveSkillRoot()
if (root === undefined) {
  console.log('taxue-imagegen skill not found; bridge end-to-end checks skipped')
} else {
  console.log(`taxue-imagegen found at ${root}`)

  // plan：无 track 给选型指引，带 track 给槽位清单
  const overview = await planSlots({})
  for (const track of SKILL_TRACKS) assert.ok(overview.text.includes(track), `选型指引应覆盖类型 ${track}`)
  assert.match(overview.text, /先选类型再填空/, '应说明先选类型')

  const planA = await planSlots({}, 'A')
  assert.equal(planA.track, 'A')
  assert.match(planA.text, /视觉风格/, '类型 A 槽位清单应含「视觉风格」')
  assert.match(planA.text, /槽位/, '应带槽位计数说明')

  const planD = await planSlots({}, 'D')
  assert.equal(planD.track, 'D')
  assert.match(planD.text, /半机械|build_storyboard/, '类型 D 应说明它是半机械型')

  // compose：填齐必填槽应产出可生图提示词
  const composed = await composePrompt({}, {
    track: 'A',
    slots: {
      视觉风格: '水墨写意',
      内容主题: '苏绣工坊',
      表达意图: '静水深流',
      主体形象: '一位绣娘侧身执针',
      英文主标题: 'SUZHOU',
      中文短句: '一针一线',
      英文短句: 'SILK AND TIME',
    },
  })
  assert.match(composed.prompt, /^设计一张竖版 2:3 概念海报/, '应直出模板首句')
  assert.ok(composed.prompt.includes('苏绣工坊'), '槽位取值应原样进提示词')
  assert.ok(composed.prompt.length > 500, '组装结果应是完整提示词')
  assert.ok(Array.isArray(composed.warnings), '告警应是数组')

  // compose：缺必填槽应失败并把脚本原话带出来，而不是静默产出半成品
  await assert.rejects(
    () => composePrompt({}, { track: 'A', slots: { 视觉风格: '水墨' } }),
    /填槽未通过/,
    '缺槽应明确失败',
  )

  // preflight：命中已知翻车项时不应报 ok
  const clean = await preflightText({}, 'A', '设计一张竖版 2:3 概念海报。背景：单一均匀纯色，无渐变、无纸纹。')
  assert.equal(typeof clean.ok, 'boolean')
  const dirty = await preflightText({}, 'A', '背景为温暖泛黄的做旧纸底，顶部留白占 25%，【未填槽位】')
  assert.equal(dirty.ok, false, '色相词与残留槽位应被判不通过')
  assert.ok(dirty.report.length > 0, '预检应给出报告')

  // check：验收判定与退出码三档映射
  const sample = pathJoin(tmpdir(), `taxue-bridge-test-${process.pid}.png`)
  try {
    // 纯中性白 1024x1536：不触发泛黄 pending，用于验证 pass 分支
    writeFileSync(sample, neutralWhitePng(1024, 1536))
    const checked = await checkImage({}, { path: sample, track: 'A', top: true, text: 'ok', noLog: true })
    assert.ok(['pass', 'pending'].includes(checked.verdict), `纯白图应为 pass 或 pending，实得 ${checked.verdict}`)
    assert.match(checked.report, /verdict=/, '报告应含脚本 verdict 行')
  } finally {
    if (existsSync(sample)) unlinkSync(sample)
  }

  // ── 工具层：mock ctx 收集插件真实注册的工具，直接调 execute 验证工具契约 ──
  // 覆盖「注册不报错 + schema 合法 + execute 走通子进程桥」三件事，无需 DSH 运行时。
  const { createRequire } = await import('node:module')
  const registered = []
  const noop = () => {}
  const plugin = await import('../lib/index.js')
  plugin.apply({
    tools: { register: (tool) => { registered.push(tool); return tool } },
    effect: (fn) => { try { fn() } catch { /* mock 环境下的注册副作用可忽略 */ } },
    inject: () => { /* 设置段安装跳过：不影响工具契约 */ },
    webServer: { register: noop },
    get: () => undefined,
    attachments: { imageLimits: { maxImageBytes: 1e7, mediaTypes: ['image/png'] }, saveImage: noop, readImage: noop },
    credentials: { get: noop },
  }, {})

  const names = registered.map((tool) => tool.name)
  for (const expected of ['reverse_prompt', 'optimize_prompt', 'extract_palette', 'generate_image', 'artisan_styles', 'artisan_edit', 'artisan_quality', 'artisan_plan', 'artisan_compose', 'artisan_preflight', 'artisan_check']) {
    assert.ok(names.includes(expected), `插件应注册工具 ${expected}`)
  }
  assert.equal(registered.length, 11, '工具数应为 11（原生 7 + 技能桥 4）')

  const planTool = registered.find((tool) => tool.name === 'artisan_plan')
  const planResult = await planTool.execute({}, {})
  assert.ok(planResult.text.includes('概念海报'), 'plan 工具应返回选型指引')
  const planATool = await planTool.execute({ track: 'A' }, {})
  assert.equal(planATool.track, 'A', 'plan 工具带 track 时应回填 track')

  const composeTool = registered.find((tool) => tool.name === 'artisan_compose')
  const composeResult = await composeTool.execute({
    track: 'A',
    slots: [
      { key: '视觉风格', value: '水墨写意' },
      { key: '内容主题', value: '苏绣工坊' },
      { key: '表达意图', value: '静水深流' },
      { key: '主体形象', value: '一位绣娘侧身执针' },
      { key: '英文主标题', value: 'SUZHOU' },
      { key: '中文短句', value: '一针一线' },
      { key: '英文短句', value: 'SILK AND TIME' },
    ],
  }, {})
  assert.match(composeResult.prompt, /^设计一张竖版/, 'compose 工具应直出模板提示词')

  const preflightTool = registered.find((tool) => tool.name === 'artisan_preflight')
  const preflightResult = await preflightTool.execute({ track: 'A', prompt: '背景为温暖泛黄的做旧纸底，顶部留白占 25%' }, {})
  assert.equal(preflightResult.ok, false, 'preflight 工具应拦下色相词')

  const checkTool = registered.find((tool) => tool.name === 'artisan_check')
  const checkSample = pathJoin(tmpdir(), `taxue-tool-test-${process.pid}.png`)
  try {
    writeFileSync(checkSample, neutralWhitePng(1024, 1536))
    const checkResult = await checkTool.execute({ path: checkSample, track: 'A', text: 'ok', no_log: true }, {})
    assert.ok(['pass', 'pending'].includes(checkResult.verdict), `check 工具应返回三档判定，实得 ${checkResult.verdict}`)
    assert.ok(checkResult.report.length > 0, 'check 工具应带回报告')
  } finally {
    if (existsSync(checkSample)) unlinkSync(checkSample)
  }

  // ── 原生吸收工具：风格库 / 图像编辑 / 质量审计（纯本地，无子进程） ──
  const stylesTool = registered.find((tool) => tool.name === 'artisan_styles')
  const allStyles = await stylesTool.execute({}, {})
  assert.equal(allStyles.count, 26, '全量风格应为 26（半调 12 + 创意 14）')
  assert.ok(Array.isArray(allStyles.styles) && allStyles.styles[0].prompt.length > 0, '每条风格应带可生图 prompt')
  assert.equal((await stylesTool.execute({ category: 'halftone' }, {})).count, 12, '半调风格应为 12')
  assert.equal((await stylesTool.execute({ category: 'seasonal' }, {})).count, 4, '节气模板应为 4')

  const editTool = registered.find((tool) => tool.name === 'artisan_edit')
  const edited = await editTool.execute({ imageDesc: '一张轻微过曝的概念海报', issues: ['exposure'] }, {})
  assert.equal(edited.plan.length, 1, 'exposure 体检项应映射到修图操作')
  assert.equal(edited.plan[0].operation, '曝光', '方案应带操作名而不是 undefined')
  assert.match(edited.prompt, /^Professional photo editing/, '修图提示词应为专业修图模板')

  const qualityTool = registered.find((tool) => tool.name === 'artisan_quality')
  const scored = await qualityTool.execute({ prompt: `${'细节'.repeat(40)} prompt` }, {})
  assert.equal(typeof scored.total, 'number', '七维打分应返回总分')
  assert.equal(scored.baseline.results.length, 4, '基线门控应为 4 条')
  assert.ok(Array.isArray(scored.suggestions), '修复建议应为数组')
}

/** 生成一张纯中性白 PNG（无依赖，手写最小 PNG 编码）。 */
function neutralWhitePng(width, height) {
  const raw = Buffer.alloc(height * (1 + width * 3))
  for (let y = 0; y < height; y += 1) {
    const rowStart = y * (1 + width * 3)
    raw[rowStart] = 0
    for (let x = 0; x < width; x += 1) {
      const at = rowStart + 1 + x * 3
      raw[at] = 255
      raw[at + 1] = 255
      raw[at + 2] = 255
    }
  }
  const idat = zlib.deflateSync(raw)
  const chunks = [Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])]
  chunks.push(pngChunk('IHDR', ihdr(width, height)))
  chunks.push(pngChunk('IDAT', idat))
  chunks.push(pngChunk('IEND', Buffer.alloc(0)))
  return Buffer.concat(chunks)
}

function ihdr(width, height) {
  const buf = Buffer.alloc(13)
  buf.writeUInt32BE(width, 0)
  buf.writeUInt32BE(height, 4)
  buf[8] = 8
  buf[9] = 2
  return buf
}

function pngChunk(type, data) {
  const length = Buffer.alloc(4)
  length.writeUInt32BE(data.length, 0)
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data])
  const crc = Buffer.alloc(4)
  crc.writeUInt32BE(crc32(body), 0)
  return Buffer.concat([length, body, crc])
}

function crc32(buf) {
  let crc = 0xffffffff
  for (const byte of buf) {
    crc ^= byte
    for (let i = 0; i < 8; i += 1) crc = crc & 1 ? (crc >>> 1) ^ 0xedb88320 : crc >>> 1
  }
  return (crc ^ 0xffffffff) >>> 0
}

console.log('taxue-dsh-artisan skill bridge tests passed')
