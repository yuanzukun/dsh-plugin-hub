import assert from 'node:assert/strict'
import {
  optimizePrompt,
  reversePrompt,
} from '../lib/compiler.mjs'

// ── reverse_prompt：图像反推，直出自然语言提示词 ──
const task = reversePrompt({
  mode: 'image_reverse',
  target: 'image',
  platform: 'nano_banana',
  brief: '反推一张竖版雨夜霓虹街头的赛博朋克猫咪插画，标题「夜猫」宋体，冰蓝与霓虹紫配色，纸张纹理',
  reference_assets: [{ uri: '/assets/d2ffdd0772cb-大雪.jpg', role: 'content', rights: 'user_owned' }],
  preserve: ['霓虹倒影'],
  avoid: ['具体作品复刻'],
  output_language: 'zh-CN',
})

assert.match(task.task_id, /^taxue-/)
// 自然语言化：第一句锁定画幅，brief 原样自然融入，约束转成自然句，无章节/方法论/JSON。
assert.match(task.prompt, /^画幅比例：9:16（由描述推断/)
assert.ok(task.prompt.includes('赛博朋克猫咪') && task.prompt.includes('夜猫'), 'brief 应原样自然融入')
assert.match(task.prompt, /保持：霓虹倒影/, '约束应自然化')
assert.ok(!/视觉还原锚点|主体与视觉观察|必须保留|平台编译|##|"反推一张/.test(task.prompt), '不应再出现章节/方法论/JSON 化 brief')
assert.ok(task.prompt.length > 0, '直出提示词不应为空')
assert.ok(Array.isArray(task.optimization_advice) && task.optimization_advice.length > 0, '应有优化方向建议')
assert.equal(task.aspect_ratio, '9:16', '竖版 brief 应推断 9:16')
assert.match(task.variant_guidance, /9:16/, '新图引导应带画幅')
assert.equal(task.risk_flags.length >= 1, true, '图像反推应给出假设性风险提示')
// 默认单语言 zh-CN：英文标题不应出现
assert.ok(!/Direct Prompt/.test(task.prompt), '默认应为中文单语言')

// ── 画幅推断：横版 / 方形 / 缺省 ──
const landscape = reversePrompt({ mode: 'image_reverse', target: 'image', platform: 'universal', brief: '横版风光海报', output_language: 'zh-CN' })
assert.equal(landscape.aspect_ratio, '16:9', '横版应推断 16:9')
const square = reversePrompt({ mode: 'image_reverse', target: 'image', platform: 'universal', brief: '方形插画', output_language: 'zh-CN' })
assert.equal(square.aspect_ratio, '1:1', '方形应推断 1:1')
const noHint = reversePrompt({ mode: 'image_reverse', target: 'image', platform: 'universal', brief: '一张海报', output_language: 'zh-CN' })
assert.equal(noHint.aspect_ratio, '1:1', '缺省应回退 1:1')

// ── 路径 A：技能委托形态。技能先观察，再转写成自然语言描述作 brief（不带字段标签）──
const naturalBrief = reversePrompt({
  mode: 'image_reverse',
  target: 'image',
  platform: 'universal',
  brief: '一名水墨女子侧身低眉，发髻高挽，衣袂随风。竖版构图，主体居右，左上留白过半。墨色为主，仅一处朱砂点缀。宣纸纹理，笔触边缘自然晕散。无印章、无文字、无现代元素。',
  image_width: 1792,
  image_height: 1008,
  output_language: 'zh-CN',
})
assert.equal(naturalBrief.aspect_ratio, '16:9', '真实像素 1792×1008 应换算 16:9')
assert.match(naturalBrief.prompt, /^画幅比例：/, '直出提示词第一句应锁定画幅')
assert.ok(naturalBrief.prompt.includes('水墨女子') && naturalBrief.prompt.includes('宣纸'), '自然语言观察应融入提示词')
assert.ok(!/主体：|构图：|光影：|N\/A/.test(naturalBrief.prompt), '观察字段标签不应残留在直出提示词')
assert.ok(naturalBrief.prompt.length > 0, '自然语言 brief 应正常直出')
assert.ok(naturalBrief.optimization_advice.length > 0, '也应有优化建议')

// ── video_reverse + 炭笔模式：炭笔要求自然化，仍不注入图像方法论 ──
const videoTask = reversePrompt({
  mode: 'video_reverse',
  target: 'video',
  platform: 'veo',
  brief: '反推一段风中舞者与花枝的短视频，保留抓拍感和有限墨彩。',
  reference_assets: [{ uri: '/assets/dancer.png', role: 'motion', rights: 'user_owned' }],
  output_language: 'zh-CN',
  dynamic_charcoal_mode: true,
})
assert.match(videoTask.prompt, /动态炭笔速写/, '炭笔要求应以自然句融入')
assert.match(videoTask.prompt, /有限墨彩/)
assert.ok(!videoTask.prompt.includes('视觉还原锚点'), '视频反推不应注入图像方法论')
assert.equal(videoTask.risk_flags.some((f) => f.includes('视频反推')), true)

// ── prompt_optimize：缺当前提示词应给澄清问题 ──
const opt = reversePrompt({
  mode: 'prompt_optimize',
  target: 'image',
  platform: 'universal',
  brief: '优化现有提示词',
})
assert.ok(opt.clarification_questions.length > 0, '缺少现有提示词时应提示澄清')

// ── optimize_prompt：审计 ──
const audit = optimizePrompt({
  target: 'video',
  prompt: 'A locked-off camera uses a fast orbit around a dancer in the style of a living painter.',
  dynamic_charcoal_mode: true,
})
assert.equal(audit.warnings.some((w) => w.includes('冲突的相机运动')), true)
assert.equal(audit.risk_flags.length > 0, true)
assert.match(audit.next_single_variable_test, /下一轮只测试/)

// ── 标准：空 brief / 空 prompt 抛错 ──
assert.throws(() => reversePrompt({ mode: 'image_reverse', target: 'image', platform: 'universal', brief: '   ' }), /brief/)
assert.throws(() => optimizePrompt({ target: 'image', prompt: '' }), /prompt/)

// ── Bug B：mode×target 矛盾校验 ──
assert.throws(() => reversePrompt({ mode: 'image_reverse', target: 'video', platform: 'universal', brief: 'x' }), /矛盾/)
assert.throws(() => reversePrompt({ mode: 'video_reverse', target: 'image', platform: 'universal', brief: 'x' }), /矛盾/)

// ── 优化建议：信息不全会给可执行方向 ──
const sparse = reversePrompt({ mode: 'image_reverse', target: 'image', platform: 'universal', brief: '一只猫', output_language: 'zh-CN' })
assert.ok(sparse.optimization_advice.some((a) => a.includes('文字排版') || a.includes('配色') || a.includes('构图')), '信息不全时应给出补足方向的建议')

// ── 英文支持：output_language=en 产出真正英文自然提示词 ──
const enTask = reversePrompt({
  mode: 'image_reverse',
  target: 'image',
  platform: 'grok',
  brief: 'reverse a vertical cyberpunk cat poster with neon purple',
  output_language: 'en',
})
assert.match(enTask.prompt, /^Aspect ratio: 9:16（由描述推断|^Aspect ratio: 9:16/)
assert.ok(enTask.prompt.includes('cyberpunk cat'), '英文 brief 应原样自然融入')
assert.ok(!/直出提示词|主体与视觉观察|视觉还原锚点|视觉还原锚点/.test(enTask.prompt), '英文模式正文不应混入中文/章节')
assert.match(enTask.quality_gate[0], /evidence ledger/i)
assert.ok(enTask.risk_flags.every((f) => !/[\u4e00-\u9fff]/.test(f)), '英文模式风险提示不应含中文')
assert.match(enTask.task_summary, /Reverse-engineered/)

const enAudit = optimizePrompt({
  target: 'image',
  prompt: 'A minimal living-room illustration.',
  output_language: 'en',
})
assert.match(enAudit.summary, /Local structural audit/)
assert.ok(enAudit.warnings.every((w) => !/[\u4e00-\u9fff]/.test(w)), '英文模式警示不应含中文')
assert.match(enAudit.next_single_variable_test, /Next round/)

// ── 真实像素比例：精确还原画幅（优先于文本启发式），画幅仍为第一句 ──
const pixel16x9 = reversePrompt({ mode: 'image_reverse', target: 'image', platform: 'grok', brief: '横版风光海报', image_width: 1280, image_height: 720, output_language: 'zh-CN' })
assert.equal(pixel16x9.aspect_ratio, '16:9', '1280×720 应还原为 16:9')
assert.match(pixel16x9.prompt, /^画幅比例：16:9（参考图真实 1280×720px/, '提示词第一句应写死真实画幅')
assert.match(pixel16x9.prompt, /横版风光海报/, 'brief 应原样融入，不 JSON 化')

const pixel9x16 = reversePrompt({ mode: 'image_reverse', target: 'image', platform: 'universal', brief: '一张插画', image_width: 1080, image_height: 1920 })
assert.equal(pixel9x16.aspect_ratio, '9:16', '1080×1920 应还原为 9:16（像素优先于 brief 缺省）')

const pixel3x2 = reversePrompt({ mode: 'image_reverse', target: 'image', platform: 'universal', brief: '一张海报', image_width: 1500, image_height: 1000 })
assert.equal(pixel3x2.aspect_ratio, '3:2', '1500×1000 应还原为 3:2')

const pixelSquare = reversePrompt({ mode: 'image_reverse', target: 'image', platform: 'universal', brief: '一张图', image_width: 1024, image_height: 1024 })
assert.equal(pixelSquare.aspect_ratio, '1:1', '1024×1024 应还原为 1:1')

// 非法像素输入应回退文本启发式
const badPixels = reversePrompt({ mode: 'image_reverse', target: 'image', platform: 'universal', brief: '横版', image_width: 0, image_height: -5 })
assert.equal(badPixels.aspect_ratio, '16:9', '非法像素应回退文本启发式')

// ── 不再注入方法论/锚点章节：任何反推都不应出现「视觉还原锚点」 ──
assert.ok(!pixel16x9.prompt.includes('视觉还原锚点'), '图像反推不应再注入方法论章节')
assert.ok(!videoTask.prompt.includes('视觉还原锚点'), '视频反推不应注入图像方法论')

// ── 英文模式：画幅句为英文，无锚点章节 ──
const enPixel = reversePrompt({ mode: 'image_reverse', target: 'image', platform: 'grok', brief: 'a boat', image_width: 1280, image_height: 720, output_language: 'en' })
assert.match(enPixel.prompt, /^Aspect ratio: 16:9（参考图真实 1280×720px|^Aspect ratio: 16:9/)
assert.ok(!enPixel.prompt.includes('reconstruction anchors'), '不应再有英文锚点章节')
assert.equal(enPixel.aspect_ratio, '16:9')

// ── 硬冲突审计：成对互斥机制同现应报警 ──
const flatSoft = optimizePrompt({ target: 'image', prompt: '赛璐璐平涂风格的少女立绘，大范围柔光连续混色塑造体积', output_language: 'zh-CN' })
assert.equal(flatSoft.warnings.some((w) => w.includes('硬冲突')), true, '平涂+大面积柔光应报硬冲突')
const cleanGrain = optimizePrompt({ target: 'image', prompt: 'A pristine clean surface photo with heavy film grain and halftone texture', output_language: 'en' })
assert.equal(cleanGrain.warnings.some((w) => w.toLowerCase().includes('hard conflict')), true, 'clean surface + film grain should flag hard conflict')

// ── 光照维度缺失应出现在优化建议里 ──
const noLight = reversePrompt({ mode: 'image_reverse', target: 'image', platform: 'universal', brief: '一只猫，构图居中', output_language: 'zh-CN' })
assert.ok(noLight.optimization_advice.some((a) => a.includes('光照')), '缺光照描述时应给出补足光照的建议')

// ── 变体纪律：锁定风格维度 + 非风格维度 20%-40% 变化 ──
assert.match(noLight.variant_guidance, /20%-40%/, '变体引导应带变化幅度纪律')

console.log('taxue-dsh-artisan smoke tests passed')
