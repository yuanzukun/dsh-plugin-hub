import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { readdirSync, realpathSync } from 'node:fs'
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import test from 'node:test'
import { fileURLToPath } from 'node:url'
import {
  buildReaderArgs,
  runSessionReader,
  slashReferenceFromSession,
  slashReferenceFromUserText,
} from '../src/reader.ts'

test('slashReferenceFromUserText keeps latest empty and checkout intact', () => {
  assert.equal(slashReferenceFromUserText('/resume-claude latest', 'claude'), undefined)
  assert.equal(slashReferenceFromUserText('/resume-claude', 'claude'), undefined)
  assert.equal(slashReferenceFromUserText('/resume-claude checkout', 'claude'), 'checkout')
  assert.equal(slashReferenceFromUserText('please /resume-claude checkout now', 'claude'), 'checkout')
})

test('slashReferenceFromSession reads the triggering user message', () => {
  const events = [
    { type: 'user/message', data: { content: [{ type: 'text', text: '/resume-claude checkout' }] } },
    { type: 'user/message', data: { content: [{ type: 'text', text: '<skill_content name="resume-claude">' }] } },
  ]
  assert.equal(slashReferenceFromSession(events, 'claude'), 'checkout')
})

test('buildReaderArgs keeps a leading-dash reference inert', () => {
  assert.deepEqual(buildReaderArgs({
    provider: 'codex',
    action: 'show',
    cwd: '/work/project',
    reference: '  --not-an-option  ',
  }), [
    'codex',
    'show',
    '--cwd',
    resolve('/work/project'),
    '--within-min',
    '0',
    '--max-tool-chars',
    '300',
    '--json',
    '--',
    '--not-an-option',
  ])
})

test('list rejects a session reference instead of guessing', () => {
  assert.throws(() => buildReaderArgs({
    provider: 'cursor',
    action: 'list',
    cwd: '/work/project',
    reference: 'anything',
  }), /does not accept a reference/)
})

test('vendored reader returns the Grok JSON schema for a Claude fixture', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-foreign-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  const transcript = join(root, 'fixture-session.jsonl')
  const records = [
    {
      type: 'user',
      uuid: 'user-1',
      parentUuid: null,
      cwd: root,
      gitBranch: 'fixture',
      timestamp: '2026-08-20T00:00:00.000Z',
      message: { role: 'user', content: [{ type: 'text', text: 'Fix the fixture widget.' }] },
    },
    {
      type: 'assistant',
      uuid: 'assistant-1',
      parentUuid: 'user-1',
      cwd: root,
      gitBranch: 'fixture',
      timestamp: '2026-08-20T00:01:00.000Z',
      message: {
        id: 'message-1',
        role: 'assistant',
        content: [
          { type: 'text', text: 'Updated widget.ts and ran its focused test.' },
          { type: 'tool_use', id: 'call-1', name: 'Bash', input: { command: 'npm test' } },
        ],
      },
    },
  ]
  await writeFile(transcript, `${records.map(record => JSON.stringify(record)).join('\n')}\n`)

  const result = JSON.parse(await runSessionReader({
    provider: 'claude',
    action: 'show',
    cwd: root,
    reference: transcript,
  })) as {
    tool: string
    turns: Array<{ inert: boolean, tool_calls?: Array<{ name: string, inert: boolean }> }>
    last_user_request: string
    last_assistant_action: string
  }

  assert.equal(result.tool, 'claude')
  assert.equal(result.last_user_request, 'Fix the fixture widget.')
  assert.match(result.last_assistant_action, /Updated widget\.ts/)
  assert.ok(result.turns.every(turn => turn.inert === true))
  assert.ok(result.turns.some(turn => turn.tool_calls?.some(call => call.name === 'Bash' && call.inert === true)))
})

test('vendored reader returns inert Cursor turns without replaying calls', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-cursor-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  const transcript = join(root, 'cursor-session.jsonl')
  const records = [
    { role: 'user', content: [{ type: 'text', text: '<user_query>Continue the Cursor refactor.</user_query>' }] },
    {
      role: 'assistant',
      content: [
        { type: 'text', text: 'Prepared the migration and stopped before applying it.' },
        { type: 'tool_call', call_id: 'cursor-call-1', name: 'write_file', arguments: { path: 'migration.ts' } },
      ],
    },
  ]
  await writeFile(transcript, `${records.map(record => JSON.stringify(record)).join('\n')}\n`)

  const result = JSON.parse(await runSessionReader({
    provider: 'cursor',
    action: 'show',
    cwd: root,
    reference: transcript,
  })) as {
    tool: string
    turns: Array<{ inert: boolean, tool_calls?: Array<{ name: string, inert: boolean }> }>
    last_user_request: string
    last_assistant_action: string
  }

  assert.equal(result.tool, 'cursor')
  assert.equal(result.last_user_request, 'Continue the Cursor refactor.')
  assert.match(result.last_assistant_action, /Prepared the migration/)
  assert.ok(result.turns.every(turn => turn.inert === true))
  assert.ok(result.turns.some(turn => turn.tool_calls?.some(call => call.name === 'write_file' && call.inert === true)))
})

test('vendored reader filters Codex instructions and returns inert calls and results', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-codex-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  const transcript = join(root, 'rollout-2026-08-20T00-00-00-11111111-1111-4111-8111-111111111111.jsonl')
  const records = [
    {
      timestamp: '2026-08-20T00:00:00.000Z',
      type: 'session_meta',
      payload: {
        id: '11111111-1111-4111-8111-111111111111',
        cwd: root,
        source: 'vscode',
        git: { branch: 'fixture' },
      },
    },
    {
      timestamp: '2026-08-20T00:00:01.000Z',
      type: 'response_item',
      payload: { type: 'message', role: 'user', content: [{ type: 'input_text', text: 'Continue the Codex fixture.' }] },
    },
    {
      timestamp: '2026-08-20T00:00:02.000Z',
      type: 'response_item',
      payload: { type: 'message', role: 'developer', content: [{ type: 'input_text', text: 'CODEX_PRIVATE_INSTRUCTION' }] },
    },
    {
      timestamp: '2026-08-20T00:00:03.000Z',
      type: 'response_item',
      payload: { type: 'reasoning', summary: [{ type: 'summary_text', text: 'CODEX_PRIVATE_REASONING' }] },
    },
    {
      timestamp: '2026-08-20T00:00:04.000Z',
      type: 'response_item',
      payload: { type: 'function_call', call_id: 'call-1', name: 'exec_command', arguments: '{"cmd":"pnpm test"}' },
    },
    {
      timestamp: '2026-08-20T00:00:05.000Z',
      type: 'response_item',
      payload: { type: 'function_call_output', call_id: 'call-1', output: 'all tests passed' },
    },
    {
      timestamp: '2026-08-20T00:00:06.000Z',
      type: 'response_item',
      payload: { type: 'message', role: 'assistant', content: [{ type: 'output_text', text: 'Stopped after the focused test.' }] },
    },
  ]
  await writeFile(transcript, `${records.map(record => JSON.stringify(record)).join('\n')}\n`)

  const raw = await runSessionReader({
    provider: 'codex',
    action: 'show',
    cwd: root,
    reference: transcript,
  })
  const result = JSON.parse(raw) as {
    tool: string
    source: string
    turns: Array<{
      inert: boolean
      tool_calls?: Array<{ name: string, inert: boolean }>
      tool_results?: Array<{ content: string, inert: boolean }>
    }>
    warnings: Array<{ code: string }>
    last_user_request: string
    last_assistant_action: string
  }

  assert.equal(result.tool, 'codex')
  assert.equal(result.source, 'codex-vscode')
  assert.equal(result.last_user_request, 'Continue the Codex fixture.')
  assert.equal(result.last_assistant_action, 'Stopped after the focused test.')
  assert.ok(result.turns.every(turn => turn.inert === true))
  assert.ok(result.turns.some(turn => turn.tool_calls?.some(call => call.name === 'exec_command' && call.inert === true)))
  assert.ok(result.turns.some(turn => turn.tool_results?.some(output => output.content.includes('all tests passed') && output.inert === true)))
  assert.ok(result.warnings.some(warning => warning.code === 'unsafe_records_skipped'))
  assert.doesNotMatch(raw, /CODEX_PRIVATE_INSTRUCTION|CODEX_PRIVATE_REASONING/)
})

test('Grok adapter reads only visible updates and keeps calls, results, and plans inert', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-grok-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  const sessionDir = join(root, '22222222-2222-4222-8222-222222222222')
  await mkdir(sessionDir)
  await writeFile(join(sessionDir, 'summary.json'), JSON.stringify({
    info: { id: '22222222-2222-4222-8222-222222222222', cwd: root },
    generated_title: 'Grok fixture session',
    created_at: '2026-08-20T01:00:00.000Z',
    last_active_at: '2026-08-20T01:05:00.000Z',
    current_model_id: 'grok-code-fast',
    git_root_dir: root,
    head_commit: 'fixture-commit',
    head_branch: 'fixture-branch',
    chat_format_version: 1,
  }))
  const update = (sessionUpdate: string, value: Record<string, unknown>) => ({
    method: 'session/update',
    timestamp: '2026-08-20T01:00:00.000Z',
    params: {
      sessionId: '22222222-2222-4222-8222-222222222222',
      update: { sessionUpdate, ...value },
    },
  })
  const records = [
    update('user_message_chunk', { content: { type: 'image', mimeType: 'image/png', data: 'omitted' } }),
    update('user_message_chunk', { content: { type: 'text', text: 'Continue the Grok fixture.' } }),
    update('agent_thought_chunk', { content: 'GROK_PRIVATE_THOUGHT' }),
    update('agent_message_chunk', { content: { type: 'text', text: 'Prepared the visible Grok change.' } }),
    update('tool_call', {
      toolCallId: 'grok-call-1',
      title: 'Run tests',
      rawInput: { command: 'pnpm test' },
      _meta: { 'x.ai/tool': { name: 'shell' } },
    }),
    update('tool_call_update', {
      toolCallId: 'grok-call-1',
      status: 'completed',
      content: [{ type: 'content', content: { type: 'text', text: 'focused tests passed' } }],
      rawOutput: { output: 'fallback output' },
    }),
    update('plan', {
      entries: [{ content: 'Publish after verification', status: 'pending', priority: 'high' }],
    }),
    update('hook_execution', { event_name: 'after-turn', prompt: 'GROK_PRIVATE_HOOK' }),
    update('turn_completed', { stop_reason: 'end_turn' }),
  ]
  await writeFile(
    join(sessionDir, 'updates.jsonl'),
    `${records.map(record => JSON.stringify(record)).join('\n')}\n`,
  )

  const raw = await runSessionReader({
    provider: 'grok',
    action: 'show',
    cwd: root,
    reference: sessionDir,
  })
  const result = JSON.parse(raw) as {
    tool: string
    turns: Array<{
      inert: boolean
      text: string
      tool_calls?: Array<{ name: string, inert: boolean }>
      tool_results?: Array<{ content: string, inert: boolean }>
    }>
    plan: Array<{ content: string, inert: boolean }>
    warnings: Array<{ code: string }>
    last_user_request: string
    last_assistant_action: string
    branch: string
  }

  assert.equal(result.tool, 'grok')
  assert.equal(result.branch, 'fixture-branch')
  assert.equal(result.last_user_request, '[image content unavailable] Continue the Grok fixture.')
  assert.equal(result.last_assistant_action, 'called inert foreign tool(s): shell')
  assert.ok(result.turns.some(turn => turn.text === 'Prepared the visible Grok change.'))
  assert.ok(result.turns.every(turn => turn.inert === true))
  assert.ok(result.turns.some(turn => turn.tool_calls?.some(call => call.name === 'shell' && call.inert === true)))
  assert.ok(result.turns.some(turn => turn.tool_results?.some(output => output.content.includes('focused tests passed') && output.inert === true)))
  assert.deepEqual(result.plan, [{ content: 'Publish after verification', status: 'pending', inert: true }])
  assert.ok(result.warnings.some(warning => warning.code === 'hidden_reasoning_skipped'))
  assert.ok(result.warnings.some(warning => warning.code === 'hook_records_skipped'))
  assert.ok(result.warnings.some(warning => warning.code === 'message_content_unavailable'))
  assert.doesNotMatch(raw, /GROK_PRIVATE_THOUGHT|GROK_PRIVATE_HOOK/)
})

test('Pi adapter follows the active branch and excludes thinking and extension records', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-pi-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  const transcript = join(root, '2026-08-20T02-00-00-000Z_33333333-3333-4333-8333-333333333333.jsonl')
  const records = [
    {
      type: 'session',
      version: 3,
      id: '33333333-3333-4333-8333-333333333333',
      timestamp: '2026-08-20T02:00:00.000Z',
      cwd: root,
    },
    {
      type: 'message',
      id: 'pi-user-root',
      parentId: null,
      timestamp: '2026-08-20T02:00:01.000Z',
      message: { role: 'user', content: [{ type: 'text', text: 'Continue the Pi fixture.' }] },
    },
    {
      type: 'message',
      id: 'pi-abandoned',
      parentId: 'pi-user-root',
      timestamp: '2026-08-20T02:00:02.000Z',
      message: { role: 'assistant', content: [{ type: 'text', text: 'PI_ABANDONED_BRANCH' }] },
    },
    {
      type: 'message',
      id: 'pi-assistant-active',
      parentId: 'pi-user-root',
      timestamp: '2026-08-20T02:00:03.000Z',
      message: {
        role: 'assistant',
        model: 'pi-fixture-model',
        content: [
          { type: 'thinking', thinking: 'PI_PRIVATE_THINKING' },
          { type: 'text', text: 'Prepared the active Pi branch.' },
          { type: 'toolCall', id: 'pi-call-1', name: 'bash', arguments: { command: 'pnpm test' } },
        ],
      },
    },
    {
      type: 'message',
      id: 'pi-tool-result',
      parentId: 'pi-assistant-active',
      timestamp: '2026-08-20T02:00:04.000Z',
      message: {
        role: 'toolResult',
        toolCallId: 'pi-call-1',
        toolName: 'bash',
        isError: false,
        content: [{ type: 'text', text: 'Pi focused tests passed' }],
      },
    },
    {
      type: 'custom',
      id: 'pi-custom',
      parentId: 'pi-tool-result',
      timestamp: '2026-08-20T02:00:05.000Z',
      customType: 'fixture-extension',
      data: 'PI_PRIVATE_EXTENSION_RECORD',
    },
    {
      type: 'message',
      id: 'pi-assistant-final',
      parentId: 'pi-custom',
      timestamp: '2026-08-20T02:00:06.000Z',
      message: { role: 'assistant', content: [{ type: 'text', text: 'Stopped after the Pi focused test.' }] },
    },
  ]
  await writeFile(transcript, `${records.map(record => JSON.stringify(record)).join('\n')}\n`)

  const raw = await runSessionReader({
    provider: 'pi',
    action: 'show',
    cwd: root,
    reference: transcript,
  })
  const result = JSON.parse(raw) as {
    tool: string
    active_leaf_id: string
    turns: Array<{
      inert: boolean
      tool_calls?: Array<{ name: string, inert: boolean }>
      tool_results?: Array<{ content: string, inert: boolean }>
    }>
    warnings: Array<{ code: string }>
    last_user_request: string
    last_assistant_action: string
  }

  assert.equal(result.tool, 'pi')
  assert.equal(result.active_leaf_id, 'pi-assistant-final')
  assert.equal(result.last_user_request, 'Continue the Pi fixture.')
  assert.equal(result.last_assistant_action, 'Stopped after the Pi focused test.')
  assert.ok(result.turns.every(turn => turn.inert === true))
  assert.ok(result.turns.some(turn => turn.tool_calls?.some(call => call.name === 'bash' && call.inert === true)))
  assert.ok(result.turns.some(turn => turn.tool_results?.some(output => output.content.includes('Pi focused tests passed') && output.inert === true)))
  assert.ok(result.warnings.some(warning => warning.code === 'inactive_branch_entries_skipped'))
  assert.ok(result.warnings.some(warning => warning.code === 'hidden_reasoning_skipped'))
  assert.ok(result.warnings.some(warning => warning.code === 'extension_records_skipped'))
  assert.doesNotMatch(raw, /PI_ABANDONED_BRANCH|PI_PRIVATE_THINKING|PI_PRIVATE_EXTENSION_RECORD/)
})

test('Grok and Pi automatic discovery stays scoped to the current workspace', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-discovery-'))
  const previousGrokHome = process.env.GROK_HOME
  const previousPiSessionDir = process.env.PI_CODING_AGENT_SESSION_DIR
  t.after(async () => {
    if (previousGrokHome === undefined) delete process.env.GROK_HOME
    else process.env.GROK_HOME = previousGrokHome
    if (previousPiSessionDir === undefined) delete process.env.PI_CODING_AGENT_SESSION_DIR
    else process.env.PI_CODING_AGENT_SESSION_DIR = previousPiSessionDir
    await rm(root, { recursive: true, force: true })
  })

  const grokHome = join(root, 'grok-home')
  const grokSession = join(
    grokHome,
    'sessions',
    encodeURIComponent(resolve(root)),
    '44444444-4444-4444-8444-444444444444',
  )
  await mkdir(grokSession, { recursive: true })
  await writeFile(join(grokSession, 'summary.json'), JSON.stringify({
    info: { id: '44444444-4444-4444-8444-444444444444', cwd: resolve(root) },
    generated_title: 'Discoverable Grok fixture',
    last_active_at: '2026-08-20T03:00:00.000Z',
  }))
  await writeFile(
    join(grokSession, 'updates.jsonl'),
    `${JSON.stringify({ sessionUpdate: 'user_message_chunk', content: 'Grok discovery fixture.' })}\n`,
  )

  const piSessionDir = join(root, 'pi-sessions')
  await mkdir(piSessionDir)
  const piSession = (id: string, cwd: string) => [
    { type: 'session', version: 3, id, timestamp: '2026-08-20T03:00:00.000Z', cwd },
    {
      type: 'message',
      id: `${id}-user`,
      parentId: null,
      timestamp: '2026-08-20T03:00:01.000Z',
      message: { role: 'user', content: [{ type: 'text', text: 'Pi discovery fixture.' }] },
    },
  ]
  await writeFile(
    join(piSessionDir, 'matching.jsonl'),
    `${piSession('55555555-5555-4555-8555-555555555555', resolve(root)).map(record => JSON.stringify(record)).join('\n')}\n`,
  )
  await writeFile(
    join(piSessionDir, 'other-workspace.jsonl'),
    `${piSession('66666666-6666-4666-8666-666666666666', join(root, 'other')).map(record => JSON.stringify(record)).join('\n')}\n`,
  )

  process.env.GROK_HOME = grokHome
  process.env.PI_CODING_AGENT_SESSION_DIR = piSessionDir
  const grokList = JSON.parse(await runSessionReader({
    provider: 'grok',
    action: 'list',
    cwd: root,
  })) as { sessions: Array<{ session_id: string, cwd: string }> }
  const piList = JSON.parse(await runSessionReader({
    provider: 'pi',
    action: 'list',
    cwd: root,
  })) as { sessions: Array<{ session_id: string, cwd: string }> }

  assert.deepEqual(grokList.sessions.map(session => session.session_id), [
    '44444444-4444-4444-8444-444444444444',
  ])
  assert.deepEqual(piList.sessions.map(session => session.session_id), [
    '55555555-5555-4555-8555-555555555555',
  ])
  assert.ok(grokList.sessions.every(session => session.cwd === resolve(root)))
  assert.ok(piList.sessions.every(session => session.cwd === resolve(root)))
})

const repoRoot = join(dirname(fileURLToPath(import.meta.url)), '..')
const zcodeFixtureBuilder = join(repoRoot, 'tests', 'fixtures', 'zcode_session.py')
const zcodeReader = join(repoRoot, 'resources', 'dsh_session_reader.py')

function zcodeEnv(home: string): NodeJS.ProcessEnv {
  return { ...process.env, ZCODE_HOME: home }
}

function buildZcodeFixture(home: string, cwd: string, otherCwd: string): void {
  const result = spawnSync('python3', [
    zcodeFixtureBuilder,
    '--home',
    home,
    '--cwd',
    cwd,
    '--other-cwd',
    otherCwd,
  ], { encoding: 'utf8' })
  assert.equal(result.status, 0, result.stderr || result.stdout)
}

test('ZCode sqlite discovery skips subagent children and keeps tool parts inert', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-zcode-'))
  const previousHome = process.env.ZCODE_HOME
  t.after(async () => {
    if (previousHome === undefined) delete process.env.ZCODE_HOME
    else process.env.ZCODE_HOME = previousHome
    await rm(root, { recursive: true, force: true })
  })
  const home = join(root, 'zcode-home')
  const cwd = join(root, 'workspace')
  const other = join(root, 'other')
  buildZcodeFixture(home, cwd, other)
  await mkdir(join(home, 'projects', 'decoy'), { recursive: true })
  await writeFile(join(home, 'projects', 'decoy', 'extra.jsonl'), `${JSON.stringify({
    sessionId: 'zcode-jsonl-decoy',
    role: 'user',
    content: 'ZCODE_JSONL_DECOY',
    cwd: resolve(cwd),
    title: 'JSONL decoy',
  })}\n`)
  await mkdir(join(home, 'v2', 'sessions'), { recursive: true })
  await writeFile(join(home, 'v2', 'sessions', 'abandoned.jsonl'), `${JSON.stringify({
    role: 'user',
    content: 'ZCODE_ABANDONED_V2',
    cwd: resolve(cwd),
  })}\n`)
  process.env.ZCODE_HOME = home

  const listed = JSON.parse(await runSessionReader({
    provider: 'zcode',
    action: 'list',
    cwd,
  })) as { sessions: Array<{ session_id: string, task_type: string | null }>, warnings: Array<{ code: string }> }
  assert.deepEqual(listed.sessions.map(session => session.session_id), [
    'zcode-session-gadget',
    'zcode-session-widget',
  ])
  assert.ok(listed.sessions.every(session => session.task_type !== 'subagent_child'))
  assert.ok(listed.warnings.every(warning => warning.code !== 'jsonl_fallback'))

  const raw = await runSessionReader({
    provider: 'zcode',
    action: 'show',
    cwd,
    reference: 'zcode-session-widget',
  })
  const result = JSON.parse(raw) as {
    tool: string
    source: string
    model: string
    turns: Array<{
      role: string
      inert: boolean
      text: string
      tool_calls?: Array<{ name: string, inert: boolean }>
      tool_results?: Array<{ content: string, inert: boolean }>
    }>
    summaries: Array<{ kind: string, inert: boolean, content: string }>
    warnings: Array<{ code: string }>
    last_user_request: string
  }
  assert.equal(result.tool, 'zcode')
  assert.equal(result.source, 'zcode')
  assert.equal(result.model, 'glm-4.6')
  assert.equal(result.last_user_request, 'Continue the ZCode fixture.')
  assert.deepEqual(result.turns.map(turn => turn.role), ['user', 'assistant', 'tool', 'assistant'])
  assert.ok(result.turns.every(turn => turn.inert === true))
  assert.ok(result.turns.some(turn => turn.text === 'Prepared the ZCode change.'))
  assert.ok(result.turns.some(turn => turn.text === 'Summary after compaction.'))
  assert.ok(result.turns.some(turn => turn.tool_calls?.some(call => call.name === 'bash' && call.inert === true)))
  assert.ok(result.turns.some(turn => turn.tool_results?.some(output => output.content.includes('zcode focused tests passed') && output.inert === true)))
  assert.ok(result.summaries.some(summary => summary.kind === 'compaction' && summary.inert === true))
  assert.ok(result.warnings.some(warning => warning.code === 'hidden_reasoning_skipped'))
  assert.ok(result.warnings.some(warning => warning.code === 'compaction_summary'))
  assert.doesNotMatch(raw, /ZCODE_PRIVATE_REASONING|ZCODE_SUBAGENT_CHILD|ZCODE_OTHER_WORKSPACE|ZCODE_JSONL_DECOY|ZCODE_ABANDONED_V2/)

  const child = JSON.parse(await runSessionReader({
    provider: 'zcode',
    action: 'show',
    cwd,
    reference: 'zcode-session-child',
  })) as { session_id: string, turns: Array<{ text: string, inert: boolean }> }
  assert.equal(child.session_id, 'zcode-session-child')
  assert.ok(child.turns.some(turn => turn.text === 'ZCODE_SUBAGENT_CHILD' && turn.inert === true))
})

test('ZCode title ambiguity exits 2 and a missing or invalid database fails clearly', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-zcode-ref-'))
  const previousHome = process.env.ZCODE_HOME
  t.after(async () => {
    if (previousHome === undefined) delete process.env.ZCODE_HOME
    else process.env.ZCODE_HOME = previousHome
    await rm(root, { recursive: true, force: true })
  })
  const home = join(root, 'zcode-home')
  const cwd = join(root, 'workspace')
  const other = join(root, 'other')
  buildZcodeFixture(home, cwd, other)
  process.env.ZCODE_HOME = home

  const ambiguous = spawnSync('python3', [
    zcodeReader,
    'zcode',
    'show',
    'continue the zcode',
    '--cwd',
    cwd,
    '--json',
  ], { encoding: 'utf8', env: zcodeEnv(home) })
  assert.equal(ambiguous.status, 2)
  assert.match(ambiguous.stderr, /matched 2 sessions/)
  assert.match(ambiguous.stderr, /zcode-session-widget/)
  assert.match(ambiguous.stderr, /zcode-session-gadget/)

  const unique = JSON.parse(await runSessionReader({
    provider: 'zcode',
    action: 'show',
    cwd,
    reference: 'widget',
  })) as { session_id: string }
  assert.equal(unique.session_id, 'zcode-session-widget')

  const emptyHome = join(root, 'empty-home')
  await mkdir(emptyHome)
  process.env.ZCODE_HOME = emptyHome
  const missing = JSON.parse(await runSessionReader({
    provider: 'zcode',
    action: 'list',
    cwd,
  })) as { sessions: unknown[], warnings: Array<{ code: string }> }
  assert.deepEqual(missing.sessions, [])
  assert.deepEqual(missing.warnings, [])
  const missingShow = await runSessionReader({
    provider: 'zcode',
    action: 'show',
    cwd,
  })
  assert.match(missingShow, /FOREIGN_SESSION_LOOKUP_NEEDS_INPUT/)
  assert.match(missingShow, /no zcode session found/)

  const brokenDb = join(root, 'broken-home', 'cli', 'db', 'db.sqlite')
  await mkdir(dirname(brokenDb), { recursive: true })
  const created = spawnSync('python3', ['-c', `
import sqlite3, sys
connection = sqlite3.connect(sys.argv[1])
connection.execute("CREATE TABLE note (id TEXT)")
connection.commit()
connection.close()
`, brokenDb], { encoding: 'utf8' })
  assert.equal(created.status, 0, created.stderr)
  const invalid = spawnSync('python3', [
    zcodeReader,
    'zcode',
    'list',
    '--cwd',
    cwd,
    '--json',
  ], { encoding: 'utf8', env: zcodeEnv(join(root, 'broken-home')) })
  assert.equal(invalid.status, 2)
  assert.match(invalid.stderr, /missing required table/)
})

test('ZCode projects JSONL is only a warned fallback when sqlite is absent', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-zcode-jsonl-'))
  const previousHome = process.env.ZCODE_HOME
  t.after(async () => {
    if (previousHome === undefined) delete process.env.ZCODE_HOME
    else process.env.ZCODE_HOME = previousHome
    await rm(root, { recursive: true, force: true })
  })
  const home = join(root, 'zcode-home')
  const cwd = join(root, 'workspace')
  await mkdir(join(home, 'projects', 'demo'), { recursive: true })
  await mkdir(cwd)
  const transcript = join(home, 'projects', 'demo', 'jsonl-session.jsonl')
  const records = [
    {
      type: 'session',
      id: 'jsonl-session-1',
      cwd: resolve(cwd),
      title: 'JSONL fallback session',
      timestamp: '2026-08-20T04:00:00.000Z',
    },
    {
      sessionId: 'jsonl-session-1',
      role: 'user',
      content: 'Continue from projects JSONL.',
      cwd: resolve(cwd),
      timestamp: '2026-08-20T04:00:01.000Z',
    },
    {
      sessionId: 'jsonl-session-1',
      role: 'assistant',
      content: [
        { type: 'reasoning', text: 'ZCODE_JSONL_PRIVATE' },
        { type: 'text', text: 'Read the fallback transcript.' },
      ],
      timestamp: '2026-08-20T04:00:02.000Z',
    },
  ]
  await writeFile(transcript, `${records.map(record => JSON.stringify(record)).join('\n')}\n`)
  await mkdir(join(home, 'cli', 'rollout'), { recursive: true })
  await writeFile(join(home, 'cli', 'rollout', 'ephemeral.jsonl'), `${JSON.stringify({
    role: 'user',
    content: 'ZCODE_ROLLOUT_DECOY',
    cwd: resolve(cwd),
    sessionId: 'rollout-decoy',
  })}\n`)
  await mkdir(join(home, 'v2', 'sessions'), { recursive: true })
  await writeFile(join(home, 'v2', 'sessions', 'abandoned.jsonl'), `${JSON.stringify({
    role: 'user',
    content: 'ZCODE_ABANDONED_V2',
    cwd: resolve(cwd),
    sessionId: 'v2-decoy',
  })}\n`)
  process.env.ZCODE_HOME = home

  const listed = JSON.parse(await runSessionReader({
    provider: 'zcode',
    action: 'list',
    cwd,
  })) as { sessions: Array<{ session_id: string }>, warnings: Array<{ code: string }> }
  assert.deepEqual(listed.sessions.map(session => session.session_id), ['jsonl-session-1'])
  assert.ok(listed.warnings.some(warning => warning.code === 'jsonl_fallback'))

  const raw = await runSessionReader({
    provider: 'zcode',
    action: 'show',
    cwd,
    reference: transcript,
  })
  const result = JSON.parse(raw) as {
    source: string
    turns: Array<{ role: string, inert: boolean, text: string }>
    warnings: Array<{ code: string }>
  }
  assert.equal(result.source, 'zcode-projects-jsonl')
  assert.deepEqual(result.turns.map(turn => turn.role), ['user', 'assistant'])
  assert.ok(result.turns.every(turn => turn.inert === true))
  assert.ok(result.warnings.some(warning => warning.code === 'jsonl_fallback'))
  assert.ok(result.warnings.some(warning => warning.code === 'hidden_reasoning_skipped'))
  assert.doesNotMatch(raw, /ZCODE_JSONL_PRIVATE|ZCODE_ROLLOUT_DECOY|ZCODE_ABANDONED_V2/)
})

const qoderFixtureBuilder = join(repoRoot, 'tests', 'fixtures', 'qoder_session.py')
const qoderReader = join(repoRoot, 'resources', 'dsh_session_reader.py')

function qoderEnv(home: string, ide?: string): NodeJS.ProcessEnv {
  return {
    ...process.env,
    QODER_CONFIG_DIR: home,
    QODER_IDE_CACHE_DIR: ide ?? join(home, 'no-ide'),
  }
}

function buildQoderFixture(home: string, cwd: string, otherCwd: string, ide?: string): void {
  const args = [
    qoderFixtureBuilder,
    '--home',
    home,
    '--cwd',
    cwd,
    '--other-cwd',
    otherCwd,
    ...(ide ? ['--ide', ide] : []),
  ]
  const result = spawnSync('python3', args, { encoding: 'utf8' })
  assert.equal(result.status, 0, result.stderr || result.stdout)
}

test('Qoder discovery scopes to cwd and keeps transcript turns inert', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-qoder-'))
  const previousConfig = process.env.QODER_CONFIG_DIR
  const previousIde = process.env.QODER_IDE_CACHE_DIR
  t.after(async () => {
    if (previousConfig === undefined) delete process.env.QODER_CONFIG_DIR
    else process.env.QODER_CONFIG_DIR = previousConfig
    if (previousIde === undefined) delete process.env.QODER_IDE_CACHE_DIR
    else process.env.QODER_IDE_CACHE_DIR = previousIde
    await rm(root, { recursive: true, force: true })
  })
  const home = join(root, 'qoder-home')
  const ide = join(root, 'ide-cache')
  const cwd = join(root, 'workspace')
  const other = join(root, 'other')
  buildQoderFixture(home, cwd, other, ide)
  process.env.QODER_CONFIG_DIR = home
  process.env.QODER_IDE_CACHE_DIR = ide

  const listed = JSON.parse(await runSessionReader({
    provider: 'qoder',
    action: 'list',
    cwd,
  })) as { sessions: Array<{ session_id: string, source: string }>, warnings: Array<{ code: string }> }
  assert.deepEqual(listed.sessions.map(session => session.session_id), [
    'task-00aa11bb22cc33dd.session.execution',
    'qoder-session-gadget',
    'qoder-session-widget',
  ])
  assert.equal(listed.sessions[0].source, 'qoder-ide-cache')

  const raw = await runSessionReader({
    provider: 'qoder',
    action: 'show',
    cwd,
    reference: 'qoder-session-widget',
  })
  const result = JSON.parse(raw) as {
    tool: string
    source: string
    model: string | null
    branch: string
    turns: Array<{
      role: string
      inert: boolean
      text: string
      tool_calls?: Array<{ name: string, inert: boolean }>
      tool_results?: Array<{ content: string, inert: boolean }>
    }>
    warnings: Array<{ code: string }>
    last_user_request: string
    last_assistant_action: string
  }
  assert.equal(result.tool, 'qoder')
  assert.equal(result.source, 'qoder-cli')
  assert.equal(result.branch, 'fixture-branch')
  assert.equal(result.last_user_request, 'Continue the Qoder fixture.')
  assert.equal(result.last_assistant_action, 'Stopped after the Qoder focused test.')
  assert.ok(result.turns.every(turn => turn.inert === true))
  assert.ok(result.turns.some(turn => turn.tool_calls?.some(call => call.name === 'Bash' && call.inert === true)))
  assert.ok(result.turns.some(turn => turn.tool_results?.some(output => output.content.includes('qoder focused tests passed') && output.inert === true)))
  assert.ok(result.warnings.some(warning => warning.code === 'sidechain_records_skipped'))
  assert.doesNotMatch(raw, /QODER_PRIVATE_THINKING|QODER_SIDECHAIN|QODER_OTHER_WORKSPACE|QODER_STATE_DECOY|QODER_COMPACTION_DECOY|QODER_INJECTED_CONTEXT/)
})

test('Qoder reference resolution handles ambiguity and title matches', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-qoder-ref-'))
  const previousConfig = process.env.QODER_CONFIG_DIR
  const previousIde = process.env.QODER_IDE_CACHE_DIR
  t.after(async () => {
    if (previousConfig === undefined) delete process.env.QODER_CONFIG_DIR
    else process.env.QODER_CONFIG_DIR = previousConfig
    if (previousIde === undefined) delete process.env.QODER_IDE_CACHE_DIR
    else process.env.QODER_IDE_CACHE_DIR = previousIde
    await rm(root, { recursive: true, force: true })
  })
  const home = join(root, 'qoder-home')
  const cwd = join(root, 'workspace')
  const other = join(root, 'other')
  buildQoderFixture(home, cwd, other)
  process.env.QODER_CONFIG_DIR = home
  process.env.QODER_IDE_CACHE_DIR = join(home, 'no-ide')

  const ambiguous = spawnSync('python3', [
    qoderReader,
    'qoder',
    'show',
    'continue the qoder',
    '--cwd',
    cwd,
    '--json',
  ], { encoding: 'utf8', env: qoderEnv(home) })
  assert.equal(ambiguous.status, 2)
  assert.match(ambiguous.stderr, /matched 2 sessions/)
  assert.match(ambiguous.stderr, /qoder-session-widget/)
  assert.match(ambiguous.stderr, /qoder-session-gadget/)

  const unique = JSON.parse(await runSessionReader({
    provider: 'qoder',
    action: 'show',
    cwd,
    reference: 'gadget',
  })) as { session_id: string }
  assert.equal(unique.session_id, 'qoder-session-gadget')
})

test('Qoder foreign cwd by id warns, and a missing home fails cleanly', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-qoder-empty-'))
  const previousConfig = process.env.QODER_CONFIG_DIR
  const previousIde = process.env.QODER_IDE_CACHE_DIR
  t.after(async () => {
    if (previousConfig === undefined) delete process.env.QODER_CONFIG_DIR
    else process.env.QODER_CONFIG_DIR = previousConfig
    if (previousIde === undefined) delete process.env.QODER_IDE_CACHE_DIR
    else process.env.QODER_IDE_CACHE_DIR = previousIde
    await rm(root, { recursive: true, force: true })
  })
  const home = join(root, 'qoder-home')
  const cwd = join(root, 'workspace')
  const other = join(root, 'other')
  buildQoderFixture(home, cwd, other)
  process.env.QODER_CONFIG_DIR = home
  process.env.QODER_IDE_CACHE_DIR = join(home, 'no-ide')

  const foreign = JSON.parse(await runSessionReader({
    provider: 'qoder',
    action: 'show',
    cwd,
    reference: 'qoder-session-other',
  })) as { session_id: string, warnings: Array<{ code: string }> }
  assert.equal(foreign.session_id, 'qoder-session-other')
  assert.ok(foreign.warnings.some(warning => warning.code === 'foreign_cwd_mismatch'))

  const emptyHome = join(root, 'empty-home')
  await mkdir(emptyHome)
  process.env.QODER_CONFIG_DIR = emptyHome
  const missing = JSON.parse(await runSessionReader({
    provider: 'qoder',
    action: 'list',
    cwd,
  })) as { sessions: unknown[], warnings: Array<{ code: string }> }
  assert.deepEqual(missing.sessions, [])
  assert.deepEqual(missing.warnings, [])
  const missingShow = await runSessionReader({
    provider: 'qoder',
    action: 'show',
    cwd,
  })
  assert.match(missingShow, /FOREIGN_SESSION_LOOKUP_NEEDS_INPUT/)
  assert.match(missingShow, /no qoder session found/)
})

const workbuddyFixtureBuilder = join(repoRoot, 'tests', 'fixtures', 'workbuddy_session.py')

function workbuddyEnv(home: string): NodeJS.ProcessEnv {
  return { ...process.env, WORKBUDDY_CONFIG_DIR: home }
}

function buildWorkbuddyFixture(home: string, cwd: string, otherCwd: string): void {
  const result = spawnSync('python3', [
    workbuddyFixtureBuilder,
    '--home',
    home,
    '--cwd',
    cwd,
    '--other-cwd',
    otherCwd,
  ], { encoding: 'utf8' })
  assert.equal(result.status, 0, result.stderr || result.stdout)
}

test('WorkBuddy discovery skips quick-ask files and keeps tool calls inert', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-workbuddy-'))
  const previousHome = process.env.WORKBUDDY_CONFIG_DIR
  t.after(async () => {
    if (previousHome === undefined) delete process.env.WORKBUDDY_CONFIG_DIR
    else process.env.WORKBUDDY_CONFIG_DIR = previousHome
    await rm(root, { recursive: true, force: true })
  })
  const home = join(root, 'workbuddy-home')
  const cwd = join(root, 'workspace')
  const other = join(root, 'other')
  buildWorkbuddyFixture(home, cwd, other)
  process.env.WORKBUDDY_CONFIG_DIR = home

  const listed = JSON.parse(await runSessionReader({
    provider: 'workbuddy',
    action: 'list',
    cwd,
  })) as { sessions: Array<{ session_id: string, cwd: string }>, warnings: Array<{ code: string }> }
  assert.deepEqual(listed.sessions.map(session => session.session_id), [
    'workbuddy-session-gadget',
    'workbuddy-session-widget',
  ])
  assert.ok(listed.sessions.every(session => session.cwd === realpathSync(cwd)))

  const raw = await runSessionReader({
    provider: 'workbuddy',
    action: 'show',
    cwd,
    reference: 'workbuddy-session-widget',
  })
  const result = JSON.parse(raw) as {
    tool: string
    source: string
    model: string
    title: string
    turns: Array<{
      role: string
      inert: boolean
      text: string
      tool_calls?: Array<{ name: string, inert: boolean }>
      tool_results?: Array<{ content: string, inert: boolean }>
    }>
    summaries: Array<{ kind: string, inert: boolean, content: string }>
    warnings: Array<{ code: string }>
    last_user_request: string
  }
  assert.equal(result.tool, 'workbuddy')
  assert.equal(result.source, 'workbuddy')
  assert.equal(result.model, 'wb-auto')
  assert.equal(result.title, 'WorkBuddy widget session')
  assert.equal(result.last_user_request, 'Continue the WorkBuddy fixture.')
  assert.deepEqual(result.turns.map(turn => turn.role), ['user', 'assistant', 'assistant', 'tool'])
  assert.ok(result.turns.every(turn => turn.inert === true))
  assert.ok(result.turns.some(turn => turn.text === 'Prepared the WorkBuddy change.'))
  assert.ok(result.turns.some(turn => turn.tool_calls?.some(call => call.name === 'shell' && call.inert === true)))
  assert.ok(result.turns.some(turn => turn.tool_results?.some(output => output.content.includes('workbuddy focused tests passed') && output.inert === true)))
  assert.ok(result.summaries.some(summary => summary.kind === 'summary' && summary.inert === true))
  assert.ok(result.warnings.some(warning => warning.code === 'hidden_reasoning_skipped'))
  assert.ok(result.warnings.some(warning => warning.code === 'internal_records_skipped'))
  assert.doesNotMatch(raw, /WORKBUDDY_PRIVATE_REASONING|WORKBUDDY_META_RECORD|WORKBUDDY_STEER_RECORD|WORKBUDDY_QUICKASK|WORKBUDDY_OTHER_WORKSPACE|hidden context/)

  const projectDir = readdirSync(join(home, 'projects')).find(name => name.endsWith('-workspace'))
  const byPath = JSON.parse(await runSessionReader({
    provider: 'workbuddy',
    action: 'show',
    cwd,
    reference: join(home, 'projects', projectDir!, 'workbuddy-session-gadget.jsonl'),
  })) as { session_id: string }
  assert.equal(byPath.session_id, 'workbuddy-session-gadget')
})

test('WorkBuddy title ambiguity exits 2 and a missing root fails clearly', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-workbuddy-ref-'))
  const previousHome = process.env.WORKBUDDY_CONFIG_DIR
  t.after(async () => {
    if (previousHome === undefined) delete process.env.WORKBUDDY_CONFIG_DIR
    else process.env.WORKBUDDY_CONFIG_DIR = previousHome
    await rm(root, { recursive: true, force: true })
  })
  const home = join(root, 'workbuddy-home')
  const cwd = join(root, 'workspace')
  const other = join(root, 'other')
  buildWorkbuddyFixture(home, cwd, other)
  process.env.WORKBUDDY_CONFIG_DIR = home

  const ambiguous = spawnSync('python3', [
    zcodeReader,
    'workbuddy',
    'show',
    'workbuddy',
    '--cwd',
    cwd,
    '--json',
  ], { encoding: 'utf8', env: workbuddyEnv(home) })
  assert.equal(ambiguous.status, 2)
  assert.match(ambiguous.stderr, /matched 2 sessions/)
  assert.match(ambiguous.stderr, /workbuddy-session-widget/)
  assert.match(ambiguous.stderr, /workbuddy-session-gadget/)

  const unique = JSON.parse(await runSessionReader({
    provider: 'workbuddy',
    action: 'show',
    cwd,
    reference: 'gadget',
  })) as { session_id: string }
  assert.equal(unique.session_id, 'workbuddy-session-gadget')

  const emptyHome = join(root, 'empty-home')
  await mkdir(emptyHome)
  process.env.WORKBUDDY_CONFIG_DIR = emptyHome
  const missing = JSON.parse(await runSessionReader({
    provider: 'workbuddy',
    action: 'list',
    cwd,
  })) as { sessions: unknown[], warnings: Array<{ code: string }> }
  assert.deepEqual(missing.sessions, [])
  assert.deepEqual(missing.warnings, [])
  const missingShow = await runSessionReader({
    provider: 'workbuddy',
    action: 'show',
    cwd,
  })
  assert.match(missingShow, /FOREIGN_SESSION_LOOKUP_NEEDS_INPUT/)
  assert.match(missingShow, /no workbuddy session found/)
})

const SYNTHETIC_CREDENTIAL = `sk-proj-VALIDATOR_SYNTHETIC_CREDENTIAL_${'x'.repeat(32)}`

function qoderDirectorySlug(cwd: string): string {
  return [...cwd].map(char => /[\p{L}\p{N}]/u.test(char) ? char : '-').join('')
}

function workbuddyDirectorySlug(cwd: string): string {
  return cwd.replace(/[/\\:]/g, '-').replace(/^-+|-+$/g, '').replace(/-+/g, '-')
}

function jsonl(records: unknown[]): string {
  return `${records.map(record => JSON.stringify(record)).join('\n')}\n`
}

test('Qoder slug fallback does not import an explicit foreign cwd', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-qoder-slug-'))
  const previousConfig = process.env.QODER_CONFIG_DIR
  const previousIde = process.env.QODER_IDE_CACHE_DIR
  t.after(async () => {
    if (previousConfig === undefined) delete process.env.QODER_CONFIG_DIR
    else process.env.QODER_CONFIG_DIR = previousConfig
    if (previousIde === undefined) delete process.env.QODER_IDE_CACHE_DIR
    else process.env.QODER_IDE_CACHE_DIR = previousIde
    await rm(root, { recursive: true, force: true })
  })
  const requested = join(root, 'project-a')
  const foreign = join(root, 'project_a')
  const bare = join(root, 'bare-workspace')
  assert.equal(qoderDirectorySlug(requested), qoderDirectorySlug(foreign))
  assert.notEqual(qoderDirectorySlug(requested), qoderDirectorySlug(bare))
  const home = join(root, 'qoder')
  process.env.QODER_CONFIG_DIR = home
  process.env.QODER_IDE_CACHE_DIR = join(root, 'no-ide')
  const foreignPath = join(home, 'projects', qoderDirectorySlug(requested), 'foreign.jsonl')
  const barePath = join(home, 'projects', qoderDirectorySlug(bare), 'bare.jsonl')
  await mkdir(join(foreignPath, '..'), { recursive: true })
  await mkdir(join(barePath, '..'), { recursive: true })
  const transcript = (cwd: string | null, sessionId: string) => [
    {
      type: 'user',
      uuid: 'u',
      parentUuid: null,
      sessionId,
      ...(cwd === null ? {} : { cwd }),
      timestamp: '2026-11-03T00:00:00Z',
      message: { role: 'user', content: `Continue ${sessionId}.` },
    },
    {
      type: 'assistant',
      uuid: 'a',
      parentUuid: 'u',
      sessionId,
      ...(cwd === null ? {} : { cwd }),
      timestamp: '2026-11-03T00:01:00Z',
      message: { role: 'assistant', content: [{ type: 'text', text: 'Ready.' }] },
    },
  ]
  await writeFile(foreignPath, jsonl(transcript(foreign, 'foreign-project-session')))
  await writeFile(barePath, jsonl(transcript(null, 'bare-session')))

  const listed = JSON.parse(await runSessionReader({
    provider: 'qoder',
    action: 'list',
    cwd: requested,
  })) as { sessions: Array<{ session_id: string, cwd: string }> }
  assert.deepEqual(listed.sessions, [])
  const latest = await runSessionReader({
    provider: 'qoder',
    action: 'show',
    cwd: requested,
  })
  assert.match(latest, /FOREIGN_SESSION_LOOKUP_NEEDS_INPUT/)
  assert.match(latest, /no qoder session found/)
  assert.doesNotMatch(latest, /foreign-project-session/)

  const bareListed = JSON.parse(await runSessionReader({
    provider: 'qoder',
    action: 'list',
    cwd: bare,
  })) as { sessions: Array<{ session_id: string, cwd: string }> }
  assert.deepEqual(bareListed.sessions.map(session => session.session_id), ['bare-session'])
  assert.equal(bareListed.sessions[0]?.cwd, bare)
  const bareShown = JSON.parse(await runSessionReader({
    provider: 'qoder',
    action: 'show',
    cwd: bare,
  })) as { session_id: string, cwd: string }
  assert.equal(bareShown.session_id, 'bare-session')
  assert.equal(bareShown.cwd, bare)
})

test('Qoder and WorkBuddy rendered transcripts redact credentials', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-secrets-'))
  const previousConfig = process.env.QODER_CONFIG_DIR
  const previousIde = process.env.QODER_IDE_CACHE_DIR
  const previousWorkbuddy = process.env.WORKBUDDY_CONFIG_DIR
  t.after(async () => {
    if (previousConfig === undefined) delete process.env.QODER_CONFIG_DIR
    else process.env.QODER_CONFIG_DIR = previousConfig
    if (previousIde === undefined) delete process.env.QODER_IDE_CACHE_DIR
    else process.env.QODER_IDE_CACHE_DIR = previousIde
    if (previousWorkbuddy === undefined) delete process.env.WORKBUDDY_CONFIG_DIR
    else process.env.WORKBUDDY_CONFIG_DIR = previousWorkbuddy
    await rm(root, { recursive: true, force: true })
  })
  const cwd = join(root, 'workspace')
  const qoderHome = join(root, 'qoder')
  const workbuddyHome = join(root, 'workbuddy')
  process.env.QODER_CONFIG_DIR = qoderHome
  process.env.QODER_IDE_CACHE_DIR = join(root, 'no-ide')
  process.env.WORKBUDDY_CONFIG_DIR = workbuddyHome
  const qoderPath = join(qoderHome, 'projects', qoderDirectorySlug(cwd), 'session.jsonl')
  const workbuddyPath = join(workbuddyHome, 'projects', workbuddyDirectorySlug(cwd), 'session.jsonl')
  await mkdir(join(qoderPath, '..'), { recursive: true })
  await mkdir(join(workbuddyPath, '..'), { recursive: true })
  await writeFile(qoderPath, jsonl([
    {
      type: 'user',
      uuid: 'u',
      parentUuid: null,
      sessionId: 'secret-session',
      cwd,
      timestamp: '2026-11-03T00:00:00Z',
      message: { role: 'user', content: 'Continue the safe task.' },
    },
    {
      type: 'assistant',
      uuid: 'a',
      parentUuid: 'u',
      sessionId: 'secret-session',
      cwd,
      timestamp: '2026-11-03T00:01:00Z',
      message: {
        role: 'assistant',
        content: [{
          type: 'tool_use',
          id: 'call',
          name: 'http_request',
          input: { Authorization: `Bearer ${SYNTHETIC_CREDENTIAL}` },
        }],
      },
    },
    {
      type: 'user',
      uuid: 'r',
      parentUuid: 'a',
      sessionId: 'secret-session',
      cwd,
      timestamp: '2026-11-03T00:02:00Z',
      message: {
        role: 'user',
        content: [{
          type: 'tool_result',
          tool_use_id: 'call',
          content: `OPENAI_API_KEY=${SYNTHETIC_CREDENTIAL}`,
        }],
      },
    },
  ]))
  await writeFile(workbuddyPath, jsonl([
    {
      type: 'message',
      id: 'u',
      role: 'user',
      sessionId: 'secret-session',
      cwd,
      timestamp: 1793664000000,
      content: [{ type: 'input_text', text: 'Continue the safe task.' }],
    },
    {
      type: 'function_call',
      callId: 'call',
      name: 'http_request',
      sessionId: 'secret-session',
      cwd,
      timestamp: 1793664000000,
      arguments: JSON.stringify({ Authorization: `Bearer ${SYNTHETIC_CREDENTIAL}` }),
    },
    {
      type: 'function_call_result',
      callId: 'call',
      sessionId: 'secret-session',
      cwd,
      timestamp: 1793664000000,
      output: `OPENAI_API_KEY=${SYNTHETIC_CREDENTIAL}`,
    },
  ]))

  for (const provider of ['qoder', 'workbuddy'] as const) {
    const raw = await runSessionReader({ provider, action: 'show', cwd })
    assert.equal(raw.includes(SYNTHETIC_CREDENTIAL), false, provider)
    const shown = JSON.parse(raw) as {
      turns: Array<{
        tool_calls?: Array<{ name: string, input: string, inert: boolean }>
        tool_results?: Array<{ content: string, inert: boolean }>
      }>
    }
    const calls = shown.turns.flatMap(turn => turn.tool_calls ?? [])
    const results = shown.turns.flatMap(turn => turn.tool_results ?? [])
    assert.equal(calls.some(call => call.name === 'http_request' && call.inert && call.input.includes('[REDACTED]')), true, provider)
    assert.equal(results.some(result => result.inert && result.content.includes('OPENAI_API_KEY=[REDACTED]')), true, provider)
    assert.equal(JSON.stringify(calls).includes(SYNTHETIC_CREDENTIAL), false, provider)
    assert.equal(JSON.stringify(results).includes(SYNTHETIC_CREDENTIAL), false, provider)
  }
})

test('opaque credential patterns redact values that do not start with sk-', () => {
  const result = spawnSync('python3', ['-B', 'tests/redaction_patterns.py'], {
    cwd: join(dirname(fileURLToPath(import.meta.url)), '..'),
    encoding: 'utf8',
  })
  assert.equal(result.status, 0, result.stderr || result.stdout)
})

test('Qoder and WorkBuddy redact opaque Bearer, Basic, and JSON keys', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-opaque-'))
  const previousConfig = process.env.QODER_CONFIG_DIR
  const previousIde = process.env.QODER_IDE_CACHE_DIR
  const previousWorkbuddy = process.env.WORKBUDDY_CONFIG_DIR
  t.after(async () => {
    if (previousConfig === undefined) delete process.env.QODER_CONFIG_DIR
    else process.env.QODER_CONFIG_DIR = previousConfig
    if (previousIde === undefined) delete process.env.QODER_IDE_CACHE_DIR
    else process.env.QODER_IDE_CACHE_DIR = previousIde
    if (previousWorkbuddy === undefined) delete process.env.WORKBUDDY_CONFIG_DIR
    else process.env.WORKBUDDY_CONFIG_DIR = previousWorkbuddy
    await rm(root, { recursive: true, force: true })
  })
  const bearer = 'VALIDATOR_OPAQUE_CREDENTIAL_authorization_bearer_text_0123456789'
  const basic = 'VALIDATOR_OPAQUE_CREDENTIAL_authorization_basic_text_0123456789'
  const apiJson = 'VALIDATOR_OPAQUE_CREDENTIAL_api_key_json_0123456789'
  const apiKey = 'OPAQUE_APIKEY_VALUE_0123456789'
  const tokens = [bearer, basic, apiJson, apiKey]
  const header = `Authorization: Bearer ${bearer}`
  const basicHeader = `Authorization: Basic ${basic}`
  const jsonText = JSON.stringify({
    OPENAI_API_KEY: apiJson,
    apiKey,
    api_key: 'OPAQUE_API_KEY_VALUE_0123456789',
    access_token: 'OPAQUE_ACCESS_TOKEN_VALUE_0123456789',
    secret: 'OPAQUE_SECRET_VALUE_0123456789',
    authorization: `Bearer OPAQUE_AUTHZ_VALUE_0123456789`,
    client_secret: 'OPAQUE_CLIENT_SECRET_VALUE_0123456789',
    password: 'OPAQUE_PASSWORD_VALUE_0123456789',
  })
  tokens.push(
    'OPAQUE_API_KEY_VALUE_0123456789',
    'OPAQUE_ACCESS_TOKEN_VALUE_0123456789',
    'OPAQUE_SECRET_VALUE_0123456789',
    'OPAQUE_AUTHZ_VALUE_0123456789',
    'OPAQUE_CLIENT_SECRET_VALUE_0123456789',
    'OPAQUE_PASSWORD_VALUE_0123456789',
  )
  const cwd = join(root, 'workspace')
  const qoderHome = join(root, 'qoder')
  const workbuddyHome = join(root, 'workbuddy')
  process.env.QODER_CONFIG_DIR = qoderHome
  process.env.QODER_IDE_CACHE_DIR = join(root, 'no-ide')
  process.env.WORKBUDDY_CONFIG_DIR = workbuddyHome
  const qoderPath = join(qoderHome, 'projects', qoderDirectorySlug(cwd), 'session.jsonl')
  const workbuddyPath = join(workbuddyHome, 'projects', workbuddyDirectorySlug(cwd), 'session.jsonl')
  await mkdir(join(qoderPath, '..'), { recursive: true })
  await mkdir(join(workbuddyPath, '..'), { recursive: true })
  const qoderInput = { command: header, apiKey, authorization: `Bearer ${bearer}` }
  await writeFile(qoderPath, jsonl([
    {
      type: 'user',
      uuid: 'u',
      parentUuid: null,
      sessionId: 'opaque-session',
      cwd,
      timestamp: '2026-11-03T00:00:00Z',
      message: { role: 'user', content: 'Continue safely.' },
    },
    {
      type: 'assistant',
      uuid: 'a',
      parentUuid: 'u',
      sessionId: 'opaque-session',
      cwd,
      timestamp: '2026-11-03T00:01:00Z',
      message: {
        role: 'assistant',
        content: [
          { type: 'text', text: `${header}\n${basicHeader}\n${jsonText}` },
          { type: 'tool_use', id: 'call', name: 'request', input: qoderInput },
        ],
      },
    },
    {
      type: 'user',
      uuid: 'r',
      parentUuid: 'a',
      sessionId: 'opaque-session',
      cwd,
      timestamp: '2026-11-03T00:02:00Z',
      message: {
        role: 'user',
        content: [{ type: 'tool_result', tool_use_id: 'call', content: `${basicHeader}\n${jsonText}` }],
      },
    },
  ]))
  await writeFile(workbuddyPath, jsonl([
    {
      type: 'message',
      id: 'u',
      role: 'user',
      sessionId: 'opaque-session',
      cwd,
      timestamp: 1793664000000,
      content: [{ type: 'input_text', text: 'Continue safely.' }],
    },
    {
      type: 'message',
      id: 'a',
      role: 'assistant',
      sessionId: 'opaque-session',
      cwd,
      timestamp: 1793664000000,
      content: [{ type: 'output_text', text: `${header}\n${basicHeader}\n${jsonText}` }],
    },
    {
      type: 'function_call',
      callId: 'call',
      name: 'request',
      sessionId: 'opaque-session',
      cwd,
      timestamp: 1793664000000,
      arguments: JSON.stringify({ command: header, apiKey, authorization: `Bearer ${bearer}` }),
    },
    {
      type: 'function_call_result',
      callId: 'call',
      sessionId: 'opaque-session',
      cwd,
      timestamp: 1793664000000,
      output: `${basicHeader}\n${jsonText}`,
    },
  ]))

  for (const provider of ['qoder', 'workbuddy'] as const) {
    const raw = await runSessionReader({
      provider,
      action: 'show',
      cwd,
      maxToolChars: 4000,
    })
    for (const token of tokens) {
      assert.equal(raw.includes(token), false, `${provider} ${token}`)
    }
    assert.equal(raw.includes(`Bearer ${bearer}`), false, provider)
    assert.equal(raw.includes(`Basic ${basic}`), false, provider)
    assert.match(raw, /\[REDACTED\]/)
    const shown = JSON.parse(raw) as {
      turns: Array<{ text?: string, tool_calls?: Array<{ input: string }>, tool_results?: Array<{ content: string }> }>
    }
    const blob = JSON.stringify(shown.turns)
    assert.equal(blob.includes('[REDACTED] ' + bearer), false, provider)
    assert.equal(blob.includes('[REDACTED] ' + basic), false, provider)
  }
})

test('Qoder and WorkBuddy skip records whose type is not a string', async (t) => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-resume-corrupt-'))
  const previousConfig = process.env.QODER_CONFIG_DIR
  const previousIde = process.env.QODER_IDE_CACHE_DIR
  const previousWorkbuddy = process.env.WORKBUDDY_CONFIG_DIR
  t.after(async () => {
    if (previousConfig === undefined) delete process.env.QODER_CONFIG_DIR
    else process.env.QODER_CONFIG_DIR = previousConfig
    if (previousIde === undefined) delete process.env.QODER_IDE_CACHE_DIR
    else process.env.QODER_IDE_CACHE_DIR = previousIde
    if (previousWorkbuddy === undefined) delete process.env.WORKBUDDY_CONFIG_DIR
    else process.env.WORKBUDDY_CONFIG_DIR = previousWorkbuddy
    await rm(root, { recursive: true, force: true })
  })
  const cwd = join(root, 'workspace')
  const qoderHome = join(root, 'qoder')
  const workbuddyHome = join(root, 'workbuddy')
  process.env.QODER_CONFIG_DIR = qoderHome
  process.env.QODER_IDE_CACHE_DIR = join(root, 'no-ide')
  process.env.WORKBUDDY_CONFIG_DIR = workbuddyHome
  const qoderPath = join(qoderHome, 'projects', qoderDirectorySlug(cwd), 'session.jsonl')
  const workbuddyPath = join(workbuddyHome, 'projects', workbuddyDirectorySlug(cwd), 'session.jsonl')
  await mkdir(join(qoderPath, '..'), { recursive: true })
  await mkdir(join(workbuddyPath, '..'), { recursive: true })
  await writeFile(qoderPath, jsonl([
    {
      type: 'user',
      uuid: 'u',
      parentUuid: null,
      sessionId: 'kept-session',
      cwd,
      timestamp: '2026-11-03T00:00:00Z',
      message: { role: 'user', content: 'Keep this turn.' },
    },
    { type: { unexpected: 'object' } },
  ]))
  await writeFile(workbuddyPath, jsonl([
    {
      type: 'message',
      id: 'u',
      role: 'user',
      sessionId: 'kept-session',
      cwd,
      timestamp: 1793664000000,
      content: [{ type: 'input_text', text: 'Keep this turn.' }],
    },
    { type: { unexpected: 'object' } },
  ]))

  for (const provider of ['qoder', 'workbuddy'] as const) {
    const raw = await runSessionReader({ provider, action: 'show', cwd })
    assert.equal(raw.includes('Traceback'), false, provider)
    assert.equal(raw.startsWith('FOREIGN_SESSION_READER_FAILED'), false, provider)
    const shown = JSON.parse(raw) as {
      turns: Array<{ text: string }>
      warnings: Array<{ code: string }>
    }
    assert.equal(shown.turns.some(turn => turn.text.includes('Keep this turn.')), true, provider)
    assert.equal(shown.warnings.some(warning => warning.code === 'corrupt_records_skipped'), true, provider)
  }
})
