import { appendFileSync, existsSync, mkdirSync } from 'node:fs';
import * as nodePath from 'node:path';
import { ensureEmbeddingEnv } from './adapters/embeddings/embedding-env.js';
import type { EmbeddingEnvReport } from './adapters/embeddings/embedding-env.js';
import { ensureRerankEnv } from './adapters/embeddings/rerank-env.js';
import type { RerankEnvReport } from './adapters/embeddings/rerank-env.js';
import { ensureOcrEnv } from './adapters/pdf/ocr-env.js';
import type { OcrEnvReport } from './adapters/pdf/ocr-env.js';
import { ensureOcrModel } from './adapters/pdf/ocr-model.js';
import type { OcrModelReport } from './adapters/pdf/ocr-model.js';
import { ensurePythonEnv } from './adapters/pdf/python-env.js';
import type { PythonEnvReport } from './adapters/pdf/python-env.js';
import { configFilePath, configMtime, loadConfig, resolveVaultPath, toolchainPaths, vaultGate } from './application/config-store.js';
import type { KbConfig, KbConfigOverrides } from './application/config-store.js';
import { handleSettingsApi, SETTINGS_ROUTE_PREFIX, type SettingsApiDeps } from './application/settings-api.js';
import { registerTool } from './tools/definition.js';
import { createKbDoctorTool } from './tools/kb-doctor.tool.js';
import { createKbEmbedTool } from './tools/kb-embed.tool.js';
import { createKbExportPackTool } from './tools/kb-export-pack.tool.js';
import { createKbInitTool } from './tools/kb-init.tool.js';
import { createKbJobsTool } from './tools/kb-jobs.tool.js';
import { createKbFeedbackTool } from './tools/kb-feedback.tool.js';
import { createKbHistoryTool } from './tools/kb-history.tool.js';
import { createKbCompileTool } from './tools/kb-compile.tool.js';
import { createKbIngestTool } from './tools/kb-ingest.tool.js';
import { createKbIndexTool } from './tools/kb-index.tool.js';
import { createKbInventoryTool } from './tools/kb-inventory.tool.js';
import { createKbLinkApplyTool } from './tools/kb-link-apply.tool.js';
import { createKbLinkReviewTool } from './tools/kb-link-review.tool.js';
import { createKbLintTool } from './tools/kb-lint.tool.js';
import { createKbPromoteTool } from './tools/kb-promote.tool.js';
import { createKbQueryTool } from './tools/kb-query.tool.js';
import { createKbReviewTool } from './tools/kb-review.tool.js';
import { createKbSuggestLinksTool } from './tools/kb-suggest-links.tool.js';

/** Stable cordis plugin identity. */
export const name = 'dsh-aikb';

/**
 * Cordis services this plugin needs before apply() runs. Declaring "tools" is what
 * makes ctx.tools exist: a plugin that reads it without injecting it is applied too
 * early and throws, and the whole bundle silently disappears from the tool list.
 */
export const inject = ['tools'];

export interface KbPluginConfig {
  /** Absolute path of the Obsidian vault. Unset: discover from the working directory. */
  readonly vaultPath?: string;
  /** Off by default; enabling it only allows inbox/ and .wiki/ to change. */
  readonly allowWrites?: boolean;
  /** Base interpreter used to create the private venv (must exist). Default "python". */
  readonly pythonPath?: string;
  /** Extra directory on PYTHONPATH when PyMuPDF is installed outside the interpreter. */
  readonly pythonLibPath?: string;
  /** Private venv the plugin prepares for itself. Default <workspaceRoot>/.kb/venv. */
  readonly venvPath?: string;
  /** Directory the venv is anchored to; defaults to the host working directory. */
  readonly workspaceRoot?: string;
  /** pip index for the one-time PyMuPDF install. Default: Tsinghua mirror. */
  readonly pythonMirror?: string;
  /** Local OCR for scanned PDFs. On by default; set false to skip image-only books. */
  readonly ocrEnabled?: boolean;
  /** OCR worker processes. Default 4. */
  readonly ocrWorkers?: number;
  /** OCR only the first N pages of each scanned book (a cheap first experiment). */
  readonly ocrMaxPages?: number;
  /** Directory holding the PP-OCRv4 recognizer. Default <workspaceRoot>/.kb/models/ocr. */
  readonly ocrModelDir?: string;
  /** Base URL the PP-OCRv4 graph is fetched from on first OCR use. Default: hf-mirror. */
  readonly ocrModelUrl?: string;
  /** Local embeddings for hybrid search. On by default; kb_embed builds them on demand. */
  readonly embedEnabled?: boolean;
  /** Embed newly ingested books in the same kb_ingest call. Default true; false leaves it to kb_embed. */
  readonly embedOnIngest?: boolean;
  /** Directory holding tokenizer.json + model_quantized.onnx. Default <workspaceRoot>/.kb/models/multilingual-e5-small. */
  readonly embedModelDir?: string;
  /** Base URL the ONNX files are fetched from on first use. Default: hf-mirror. */
  readonly embedModelUrl?: string;
  /**
   * Rerank every query with the local cross-encoder. Off by default: ~1-3 s per query and a
   * 279 MB model on first use. A single kb_query call can still pass rerank:true.
   */
  readonly rerankEnabled?: boolean;
  /** Directory holding the reranker files. Default <workspaceRoot>/.kb/models/bge-reranker-base. */
  readonly rerankModelDir?: string;
  /** Base URL the reranker files are fetched from on first use. Default: hf-mirror. */
  readonly rerankModelUrl?: string;
  /**
   * Widen queries with bilingual pairs harvested from this vault's books. Off by default: on the
   * 26-question evaluation the full list cost five page hits, and frequency-gated pairs were
   * neutral. Turn it on for a library that mixes Chinese questions with English books.
   */
  readonly glossaryExpansion?: boolean;
  /** Vault-relative folder kb_promote writes into. Unset disables promotion. */
  readonly promoteDir?: string;
  /** Where kb_export_pack writes; unset: keep the value from ~/.dsh-aikb/config.json. */
  readonly packDir?: string;
  /** Shared root for venv, OCR graph and ONNX models; unset: keep the configured toolchain. */
  readonly toolchainDir?: string;
}

interface ToolsRegistry {
  register(definition: unknown): void;
}

interface PluginContext {
  readonly tools: ToolsRegistry;
}

function nearestVault(start: string, maxDepth = 6): string | undefined {
  let current = nodePath.resolve(start);
  for (let depth = 0; depth <= maxDepth; depth += 1) {
    if (existsSync(nodePath.join(current, '.obsidian'))) return current;
    const parent = nodePath.dirname(current);
    if (parent === current) return undefined;
    current = parent;
  }
  return undefined;
}

export function resolveVaultRoot(config: KbPluginConfig, explicit?: string, cwd: string = process.cwd()): string {
  const fromArgs = explicit !== undefined && explicit.trim() !== '' ? explicit.trim() : undefined;
  const fromConfig = typeof config.vaultPath === 'string' && config.vaultPath.trim() !== '' ? config.vaultPath.trim() : undefined;
  const root = fromArgs ?? fromConfig ?? nearestVault(cwd);
  if (root === undefined) {
    throw new Error('kb.vault.not-found: set vaultPath in the dsh-AIkb plugin config, pass vaultPath, or start DSH inside an Obsidian vault.');
  }
  return nodePath.resolve(root);
}

/** Best-effort boot trace: a failed write must never break plugin loading. */
function logBoot(workspaceRoot: string, event: string, detail: string): void {
  try {
    const dir = nodePath.join(workspaceRoot, '.kb', 'logs');
    mkdirSync(dir, { recursive: true });
    appendFileSync(nodePath.join(dir, 'boot.log'), new Date().toISOString() + ' ' + event + ' ' + detail + String.fromCharCode(10), 'utf8');
  } catch {
    // diagnostics only
  }
}

export function apply(ctx: PluginContext, config: KbPluginConfig = {}): void {
  const bootRoot = config.workspaceRoot !== undefined && config.workspaceRoot.trim() !== ''
    ? nodePath.resolve(config.workspaceRoot.trim())
    : process.cwd();
  logBoot(bootRoot, 'apply', 'apply() entered');
  // The web panel is an iframe over the local UI server, so make sure it is up once per process.
  void (async () => {
    const port = process.env.KB_UI_PORT ?? '7341';
    try {
      const alive = await fetch('http://127.0.0.1:' + port + '/', { signal: AbortSignal.timeout(800) });
      if (alive.ok) return;
    } catch {
      // not listening yet: start it below
    }
    try {
      // In-process, like the other plugin UIs: the server lives exactly as long as DSH.
      const { fileURLToPath, pathToFileURL } = await import('node:url');
      const script = fileURLToPath(new URL('../scripts/kb-ui.mjs', import.meta.url));
      // A bare Windows path is not a valid ESM specifier: hand the loader a file:// URL.
      const { startUiServer } = await import(pathToFileURL(script).href);
      const configuredVault = config.vaultPath !== undefined && config.vaultPath.trim() !== ''
        ? nodePath.resolve(config.vaultPath.trim())
        : process.env.KB_VAULT ?? '';
      // A port still held by a previous process must not leave the panel blank: retry briefly.
      for (let attempt = 1; attempt <= 5; attempt += 1) {
        try {
          await startUiServer({
            port: Number(port),
            vault: configuredVault,
            promoteDir: (config as { promoteDir?: string }).promoteDir ?? '',
            configPath: configFilePath(),
          });
          logBoot(bootRoot, 'ui-start', 'in-process ' + script + ' attempt ' + attempt);
          return;
        } catch (error) {
          logBoot(bootRoot, 'ui-start-retry', attempt + ': ' + String(error));
          if (attempt === 5) throw error;
          await new Promise((done) => setTimeout(done, 1000));
        }
      }
    } catch (error) {
      logBoot(bootRoot, 'ui-start-failed', String(error));
    }
  })();
  if (ctx.tools === undefined || typeof ctx.tools.register !== 'function') {
    logBoot(bootRoot, 'apply-failed', 'tools service unavailable');
    throw new Error('dsh-AIkb: the tools service is unavailable; declare inject = ["tools"] (see src/index.ts)');
  }
  const allowWrites = config.allowWrites === true;
  /**
   * The config file is the source of truth and may change while DSH runs (settings page, panel).
   * Reload on mtime instead of holding one snapshot: a stale vault list is how the panel ends up
   * pointing at a directory the user removed ten minutes ago.
   */
  const configOverrides: KbConfigOverrides = {
    ...(config.vaultPath !== undefined ? { vaultPath: config.vaultPath } : {}),
    ...(config.allowWrites !== undefined ? { allowWrites: config.allowWrites } : {}),
    ...(config.pythonPath !== undefined ? { pythonPath: config.pythonPath } : {}),
    ...(config.pythonLibPath !== undefined ? { pythonLibPath: config.pythonLibPath } : {}),
    ...(config.venvPath !== undefined ? { venvPath: config.venvPath } : {}),
    ...(config.workspaceRoot !== undefined ? { workspaceRoot: config.workspaceRoot } : {}),
    ...(config.pythonMirror !== undefined ? { pythonMirror: config.pythonMirror } : {}),
    ...(config.ocrEnabled !== undefined ? { ocrEnabled: config.ocrEnabled } : {}),
    ...(config.ocrWorkers !== undefined ? { ocrWorkers: config.ocrWorkers } : {}),
    ...(config.embedEnabled !== undefined ? { embedEnabled: config.embedEnabled } : {}),
    ...(config.embedOnIngest !== undefined ? { embedOnIngest: config.embedOnIngest } : {}),
    ...(config.rerankEnabled !== undefined ? { rerankEnabled: config.rerankEnabled } : {}),
    ...(config.promoteDir !== undefined ? { promoteDir: config.promoteDir } : {}),
  };
  let cachedConfig = loadConfig(configOverrides);
  let cachedMtime = configMtime();
  const configNow = (): KbConfig => {
    const mtime = configMtime();
    if (mtime !== cachedMtime) {
      cachedConfig = loadConfig(configOverrides);
      cachedMtime = mtime;
    }
    const current = cachedConfig.config;
    // A patch-level toolchainDir pins the root for this deployment; the file cannot move it.
    const pinned = config.toolchainDir !== undefined && config.toolchainDir.trim() !== ''
      ? nodePath.resolve(config.toolchainDir.trim())
      : '';
    return pinned === '' ? current : { ...current, toolchainDir: pinned };
  };
  const toolchain = () => toolchainPaths(configNow());
  const resolveRoot = (explicit?: string): string => {
    const current = configNow();
    // Discovery stays the fallback for a machine with no config file yet: an unconfigured
    // install must still work when DSH is started inside a vault.
    if (current.vaults.length === 0 && !existsSync(configFilePath())) return resolveVaultRoot(config, explicit);
    const gate = vaultGate(current, explicit);
    if (!gate.ok) {
      throw new Error('kb.not-ready: no usable knowledge base (' + gate.missing.join(', ') + '). Open the KB settings page and choose a vault, or pass vaultPath. Config: ' + configFilePath());
    }
    return resolveVaultPath(current, explicit);
  };
  const workspaceRoot = config.workspaceRoot !== undefined && config.workspaceRoot.trim() !== ''
    ? nodePath.resolve(config.workspaceRoot.trim())
    : process.cwd();
  /** One bootstrap per process: probing is cheap, installing is not. */
  let pythonEnvOnce: Promise<PythonEnvReport> | undefined;
  const pythonEnv = (bootstrap: boolean): Promise<PythonEnvReport> => {
    if (bootstrap && pythonEnvOnce !== undefined) return pythonEnvOnce;
    const options = {
      workspaceRoot,
      pythonPath: config.pythonPath ?? '',
      venvPath: config.venvPath ?? toolchain().venv,
      mirrorUrl: config.pythonMirror ?? '',
      bootstrap,
    };
    const pending = ensurePythonEnv(options);
    if (bootstrap) pythonEnvOnce = pending;
    return pending;
  };

  /** RapidOCR is resolved once per process, like PyMuPDF. */
  let ocrEnvOnce: Promise<OcrEnvReport> | undefined;
  const ocrEnv = (): Promise<OcrEnvReport> => {
    if (ocrEnvOnce !== undefined) return ocrEnvOnce;
    const pending = ensureOcrEnv({
      workspaceRoot,
      pythonPath: config.pythonPath ?? '',
      venvPath: config.venvPath ?? toolchain().venv,
      mirrorUrl: config.pythonMirror ?? '',
      bootstrap: true,
    });
    ocrEnvOnce = pending;
    return pending;
  };
  /** One 10.8 MB graph; fetched on the first OCR run, then reused. Missing it keeps v3 working. */
  let ocrModelOnce: Promise<OcrModelReport> | undefined;
  const ocrModel = (): Promise<OcrModelReport> => {
    if (ocrModelOnce !== undefined) return ocrModelOnce;
    const pending = ensureOcrModel({
      workspaceRoot,
      modelDir: config.ocrModelDir ?? toolchain().ocr,
      modelUrl: config.ocrModelUrl ?? '',
      bootstrap: true,
    });
    ocrModelOnce = pending;
    return pending;
  };
  const ocrEnabled = config.ocrEnabled !== false;

  /** The e5-small model is downloaded once per machine, like the venv. */
  let embeddingEnvOnce: Promise<EmbeddingEnvReport> | undefined;
  const embeddingEnv = (): Promise<EmbeddingEnvReport> => {
    if (embeddingEnvOnce !== undefined) return embeddingEnvOnce;
    const pending = ensureEmbeddingEnv({
      workspaceRoot,
      pythonPath: config.pythonPath ?? '',
      venvPath: config.venvPath ?? toolchain().venv,
      mirrorUrl: config.pythonMirror ?? '',
      modelDir: config.embedModelDir ?? toolchain().embed,
      modelUrl: config.embedModelUrl ?? '',
      bootstrap: true,
    });
    embeddingEnvOnce = pending;
    return pending;
  };
  const embedEnabled = config.embedEnabled !== false;

  /** Fetched on first reranked query, not at boot: most queries do not ask for it. */
  let rerankEnvOnce: Promise<RerankEnvReport> | undefined;
  const rerankEnv = (): Promise<RerankEnvReport> => {
    if (rerankEnvOnce !== undefined) return rerankEnvOnce;
    const pending = ensureRerankEnv({
      workspaceRoot,
      pythonPath: config.pythonPath ?? '',
      venvPath: config.venvPath ?? toolchain().venv,
      mirrorUrl: config.pythonMirror ?? '',
      modelDir: config.rerankModelDir ?? toolchain().rerank,
      modelUrl: config.rerankModelUrl ?? '',
      bootstrap: true,
    });
    rerankEnvOnce = pending;
    return pending;
  };
  const rerankEnabled = config.rerankEnabled === true;

  try {
    registerTool(ctx, createKbDoctorTool({ allowWrites, resolveRoot, inspectPython: () => pythonEnv(false) }));
    registerTool(ctx, createKbInventoryTool({ allowWrites, resolveRoot }));
    registerTool(ctx, createKbLintTool({ resolveRoot }));
    registerTool(ctx, createKbCompileTool({ resolveRoot, allowWrites: () => allowWrites }));
    registerTool(ctx, createKbPromoteTool({ resolveRoot, allowWrites: () => allowWrites, promoteDir: () => config.promoteDir }));
    registerTool(ctx, createKbSuggestLinksTool({ resolveRoot }));
    registerTool(ctx, createKbIndexTool({ allowWrites: () => allowWrites, resolveRoot }));
    registerTool(ctx, createKbLinkReviewTool({ allowWrites: () => allowWrites, resolveRoot }));
    registerTool(ctx, createKbLinkApplyTool({ allowWrites: () => allowWrites, resolveRoot }));
    registerTool(ctx, createKbReviewTool({ allowWrites: () => allowWrites, resolveRoot }));
    registerTool(
      ctx,
      createKbIngestTool({
        allowWrites,
        resolveRoot,
        preparePython: () => pythonEnv(true),
        pythonLibPath: config.pythonLibPath ?? '',
        workspaceRoot,
        ocrWorkers: config.ocrWorkers !== undefined && config.ocrWorkers > 0 ? config.ocrWorkers : 4,
        ...(config.ocrEnabled === false ? {} : { prepareOcr: () => ocrEnv(), prepareOcrModel: () => ocrModel() }),
        ...(config.ocrMaxPages !== undefined ? { ocrMaxPages: config.ocrMaxPages } : {}),
        ...(embedEnabled ? { prepareEmbedding: () => embeddingEnv(), autoEmbed: config.embedOnIngest !== false } : {}),
      }),
    );
    registerTool(
      ctx,
      createKbQueryTool({
        resolveRoot,
        workspaceRoot: () => workspaceRoot,
        embedEnabled,
        glossaryExpansion: config.glossaryExpansion === true,
        ...(embedEnabled ? { prepareEmbedding: () => embeddingEnv() } : {}),
        prepareRerank: () => rerankEnv(),
        rerankDefault: rerankEnabled,
      }),
    );
    registerTool(
      ctx,
      createKbEmbedTool({
        resolveRoot,
        workspaceRoot: () => workspaceRoot,
        allowWrites: () => allowWrites,
        prepareEmbedding: () => embeddingEnv(),
      }),
    );
    registerTool(
      ctx,
      createKbExportPackTool({
        resolveRoot,
        allowWrites,
        // An explicit plugin config wins; otherwise the reloadable file config decides.
        packDir: () => (config.packDir !== undefined && config.packDir.trim() !== ''
          ? nodePath.resolve(config.packDir.trim())
          : configNow().packDir),
      }),
    );
    registerTool(ctx, createKbInitTool({ overrides: () => configOverrides }));
    registerTool(
      ctx,
      createKbJobsTool({
        // The queue lives with the rest of the heavy state so one toolchain directory owns it.
        queueDir: () => nodePath.join(toolchain().root, 'jobs'),
      }),
    );
    registerTool(ctx, createKbHistoryTool({ resolveRoot, allowWrites: () => allowWrites }));
    registerTool(ctx, createKbFeedbackTool({ resolveRoot, allowWrites: () => allowWrites }));
  } catch (error) {
    logBoot(workspaceRoot, 'apply-failed', error instanceof Error ? error.message : String(error));
    throw error;
  }

  /**
   * The settings page runs inside the DSH web GUI, so it needs JSON routes on the host
   * server instead of tools. Registration is strictly best-effort: a host without a
   * webServer service (headless, older DSH) must keep every tool registered above, so a
   * failure here is logged and not thrown.
   */
  try {
    const settingsDeps: SettingsApiDeps = {
      overrides: () => configOverrides,
      allowWrites: () => allowWrites,
      // An empty address means the vault this session would use, same as the tools.
      vaultFor: (address) => (address !== '' ? resolveVaultPath(configNow(), address) : resolveRoot()),
      // The page queues jobs through the same directory the kb_jobs tool reads.
      jobsDir: () => nodePath.join(toolchain().root, 'jobs'),
    };
    type HostRequest = AsyncIterable<Uint8Array> & { method?: string; url?: string };
    type HostResponse = {
      writeHead: (status: number, headers: Record<string, string>) => void;
      end: (body: string) => void;
    };
    const readBody = async (req: HostRequest): Promise<{ text: string; tooLarge: boolean }> => {
      const chunks: Uint8Array[] = [];
      let size = 0;
      for await (const chunk of req) {
        size += chunk.byteLength;
        // Cap at 1 MiB: a settings patch is a few KiB, anything bigger is not ours.
        if (size > 1024 * 1024) return { text: '', tooLarge: true };
        chunks.push(chunk);
      }
      return { text: Buffer.concat(chunks).toString('utf8'), tooLarge: false };
    };
    const handler = async (req: HostRequest, res: HostResponse): Promise<void> => {
      const url = req.url ?? SETTINGS_ROUTE_PREFIX;
      const queryAt = url.indexOf('?');
      const fullPath = queryAt < 0 ? url : url.slice(0, queryAt);
      const search = queryAt < 0 ? '' : url.slice(queryAt);
      // The prefix route sees the whole URL; the API contract matches on what follows.
      const rest = fullPath.startsWith(SETTINGS_ROUTE_PREFIX) ? fullPath.slice(SETTINGS_ROUTE_PREFIX.length) : fullPath;
      const pathname = rest === '' ? '/' : rest;
      let body = '';
      let tooLarge = false;
      try {
        const read = await readBody(req);
        body = read.text;
        tooLarge = read.tooLarge;
      } catch {
        // A client that dies mid-body is a bad request, not a crash.
      }
      const result = tooLarge
        ? { status: 413, body: { ok: false, error: { code: 'kb.api.too-large', message: 'The request body exceeds 1 MiB.' } } }
        : await handleSettingsApi({ method: req.method ?? 'GET', pathname, search, body }, settingsDeps);
      res.writeHead(result.status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
      res.end(JSON.stringify(result.body));
    };
    const anyCtx = ctx as unknown as {
      webServer?: { register: (options: unknown) => unknown };
      inject?: (names: string[], callback: (child: unknown) => void) => void;
    };
    const options = { kind: 'prefix', path: SETTINGS_ROUTE_PREFIX, handler };
    const install = (target: typeof anyCtx): void => {
      if (target.webServer === undefined) return;
      target.webServer.register(options);
      logBoot(bootRoot, 'settings-api', 'registered ' + SETTINGS_ROUTE_PREFIX);
    };
    if (typeof anyCtx.inject === 'function') {
      anyCtx.inject(['webServer'], (child) => {
        install(child as typeof anyCtx);
      });
    } else {
      install(anyCtx);
    }
  } catch (error) {
    logBoot(bootRoot, 'settings-api-failed', error instanceof Error ? error.message : String(error));
  }

  logBoot(workspaceRoot, 'apply', 'registered kb_doctor kb_inventory kb_lint kb_compile kb_promote kb_suggest_links kb_index kb_link_review kb_link_apply kb_ingest kb_query kb_embed kb_export_pack kb_init kb_jobs kb_history kb_feedback');
}
