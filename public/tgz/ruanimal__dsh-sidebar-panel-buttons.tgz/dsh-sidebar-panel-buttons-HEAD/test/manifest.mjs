/**
 * Package-manifest check — the declarations `@deepseek-ai/dsh-client-modules`
 * reads at boot, verified the same way it reads them.
 *
 * A profile mounts this package as an ordinary loader row; the host half scans
 * the row for `dsh.client`, resolves the package's `exports["./client"]`, and
 * serves that file as the browser bundle. Each of those steps fails loudly at
 * boot when a field drifts, so they are worth asserting before an install:
 *
 *   - `dsh.client.platform` must be a string;
 *   - `dsh.client.inject` (when present) must be a string array;
 *   - `exports["./client"]` must be a string (or `{ default: string }`) and the
 *     file must exist;
 *   - the bundle must register itself under the package name, because the boot
 *     graph keys factories by that name (a mismatched id is a silent miss);
 *   - the bundle layer's insert row must name this package exactly, because
 *     pnpm links packages by their true specifier.
 *
 * Run with `npm run check`; exits non-zero on the first problem.
 */
import { readFileSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join, resolve } from "node:path";

const packageDir = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const problems = [];
const ok = [];

/** Record a satisfied expectation. */
function pass(message) {
	ok.push(message);
}

/** Record a failed expectation. */
function fail(message) {
	problems.push(message);
}

const pkg = JSON.parse(readFileSync(join(packageDir, "package.json"), "utf8"));

// ── dsh.client ────────────────────────────────────────────────────────────
const client = pkg.dsh?.client;
if (client === undefined || typeof client !== "object" || client === null) fail("package.json: dsh.client is missing");
else if (typeof client.platform !== "string") fail("package.json: dsh.client.platform must be a string");
else pass(`dsh.client.platform = ${client.platform}`);
if (client?.inject !== undefined) {
	if (!Array.isArray(client.inject) || client.inject.some((item) => typeof item !== "string")) fail("package.json: dsh.client.inject must be a string array");
	else pass(`dsh.client.inject = [${client.inject.join(", ")}]`);
} else pass("dsh.client.inject is absent (no hard bundle dependency)");

// ── exports ───────────────────────────────────────────────────────────────
/** Resolve an exports entry shaped as a string or a one-level `{ default }`. */
function exportPath(value) {
	if (typeof value === "string") return value;
	if (typeof value === "object" && value !== null && typeof value.default === "string") return value.default;
	return undefined;
}

const exportsField = pkg.exports;
for (const [subpath, expected] of [
	[".", "host half"],
	["./client", "browser half"]
]) {
	const entry = exportsField?.[subpath];
	const relative = exportPath(entry);
	if (relative === undefined) {
		fail(`exports["${subpath}"] must be a string or { default: string }`);
		continue;
	}
	if (!existsSync(join(packageDir, relative))) fail(`exports["${subpath}"] points at a missing file: ${relative}`);
	else pass(`exports["${subpath}"] -> ${relative} (${expected})`);
}

// ── bundle identity ───────────────────────────────────────────────────────
const clientRel = exportPath(exportsField?.["./client"]);
if (clientRel !== undefined && existsSync(join(packageDir, clientRel))) {
	const bundle = readFileSync(join(packageDir, clientRel), "utf8");
	if (!bundle.includes("__ModuleLoader__.load(")) fail(`${clientRel}: does not register through window.__ModuleLoader__.load`);
	else pass(`${clientRel}: registers through the client module loader`);
	const idMatch = /id:\s*"([^"]+)"/.exec(bundle);
	if (idMatch === null) fail(`${clientRel}: no module id in the load() record`);
	else if (idMatch[1] !== pkg.name) fail(`${clientRel}: module id "${idMatch[1]}" must equal the package name "${pkg.name}"`);
	else pass(`${clientRel}: module id matches the package name`);
}

// ── bundle layer ──────────────────────────────────────────────────────────
const patchRel = pkg.dsh?.bundle?.patch;
if (typeof patchRel !== "string") fail("package.json: dsh.bundle.patch is missing");
else if (!existsSync(join(packageDir, patchRel))) fail(`dsh.bundle.patch points at a missing file: ${patchRel}`);
else {
	const patch = readFileSync(join(packageDir, patchRel), "utf8");
	if (!patch.includes(`name: ${pkg.name}`)) fail(`${patchRel}: no insert row naming ${pkg.name}`);
	else pass(`${patchRel}: inserts a row named ${pkg.name}`);
}

// ── report ────────────────────────────────────────────────────────────────
for (const line of ok) console.log(`  ok  ${line}`);
for (const line of problems) console.error(`fail  ${line}`);
console.log(`\n${ok.length} passed, ${problems.length} failed`);
process.exit(problems.length === 0 ? 0 : 1);
