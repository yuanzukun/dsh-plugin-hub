/**
 * DOM test — optional, needs a real DOM implementation:
 *
 *   npm install --no-save happy-dom && npm run test:dom
 *
 * `test/smoke.mjs` runs the bundle in a stub DOM and pins the plugin's own
 * logic. This test runs the same bundle against a real DOM, which is what
 * makes four further things checkable:
 *
 *   1. the scan works against real nodes (live `children` collections,
 *      `dataset` -> attribute, `closest`, `textContent`, `MutationObserver`);
 *   2. every selector in the injected stylesheet matches real markup — a typo
 *      in a selector would otherwise fail silently in a browser, which is
 *      exactly the failure mode a layout plugin hides;
 *   3. the sidebar cascade lands: the label cell computes to `display: none`,
 *      the container to `flex-direction: row`, the rows to 36px squares —
 *      with the shell's own sidebar stylesheet loaded first, so this is the
 *      override actually winning, not just our own declaration being read;
 *   4. the Settings section renders into a real tree with the shell's own row
 *      geometry, and clicking its options really flips the layout and
 *      persists it.
 *
 * The section's `SegmentedControl` and the icon/primitives the shell owns are
 * stubbed (this test does not load React); everything else is the real bundle.
 * Pseudo-elements (the sidebar tooltip) are not computable here and are not
 * asserted.
 */
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join, resolve } from "node:path";
import { homedir } from "node:os";

const packageDir = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const failures = [];
let checks = 0;
/** Assert one expectation. */
function check(description, condition, detail = "") {
	checks += 1;
	if (condition) console.log(`  ok  ${description}`);
	else {
		failures.push(description);
		console.error(`fail  ${description} ${detail}`);
	}
}

// ── the optional DOM dependency ───────────────────────────────────────────
let Window;
try {
	({ Window } = await import("happy-dom"));
} catch {
	console.log("happy-dom is not installed — skipping (npm install --no-save happy-dom)");
	process.exit(0);
}

const bundleSource = readFileSync(join(packageDir, "lib", "client.js"), "utf8");

// ── the shell's own sidebar stylesheet, when a local install has one ──────
/** Every candidate `@deepseek-ai/dsh-client-ui-sidebar/lib/client.js` we know how to find. */
function shellCandidates() {
	const relative = join("node_modules", "@deepseek-ai", "dsh-client-ui-sidebar", "lib", "client.js");
	const candidates = [];
	if (process.env.DSH_SIDEBAR_CLIENT) candidates.push(process.env.DSH_SIDEBAR_CLIENT);
	const profiles = join(homedir(), ".dsh", "profiles");
	candidates.push(join(profiles, relative));
	try {
		for (const entry of readdirSync(profiles, { withFileTypes: true })) {
			if (!entry.isDirectory()) continue;
			candidates.push(join(profiles, entry.name, relative));
		}
	} catch {}
	/* A desktop install keeps its own runtime outside the profiles: the `dsh`
	   directory (or a versioned `dsh-*` one) carries the client packages the
	   running page is actually served. */
	const appData = process.platform === "darwin" ? join(homedir(), "Library", "Application Support", "dsh-tauri", "dependencies") : process.platform === "win32" && process.env.APPDATA ? join(process.env.APPDATA, "dsh-tauri", "dependencies") : join(homedir(), ".local", "share", "dsh-tauri", "dependencies");
	try {
		for (const entry of readdirSync(appData, { withFileTypes: true })) {
			if (!entry.isDirectory() || !entry.name.startsWith("dsh")) continue;
			candidates.push(join(appData, entry.name, relative));
		}
	} catch {}
	return candidates;
}
let shellCss = "";
for (const candidate of shellCandidates()) {
	if (!existsSync(candidate)) continue;
	const source = readFileSync(candidate, "utf8");
	const start = source.indexOf('const css = "');
	if (start < 0) continue;
	const end = source.indexOf('";', start + 13);
	if (end < 0) continue;
	const css = JSON.parse(source.slice(start + 12, end + 1));
	/* Several shell generations can be installed side by side (the profile
	   hoist, the app bundle). This test builds the current markup — the panel
	   list with the More launcher — so prefer the stylesheet that defines that
	   launcher, and keep the first candidate only as a fallback. */
	if (css.includes("moreAnchor")) {
		shellCss = css;
		break;
	}
	if (shellCss === "") shellCss = css;
}
console.log(shellCss === "" ? "note: shell stylesheet not found — cascade check runs without it" : `note: shell stylesheet loaded (${shellCss.length} bytes)`);

// ── window and markup ─────────────────────────────────────────────────────
const window = new Window({ url: "http://127.0.0.1/" });
const document = window.document;
if (shellCss !== "") document.head.innerHTML = `<style data-plugin-css="shell">${shellCss}</style>`;

// The plugin schedules its scan on an animation frame; own the queue so the
// test decides when a frame runs.
const frames = [];
window.requestAnimationFrame = (callback) => frames.push(callback);
const flush = () => {
	while (frames.length > 0) frames.shift()();
};

globalThis.window = window;
globalThis.document = document;
globalThis.MutationObserver = window.MutationObserver;
Object.defineProperty(globalThis, "navigator", { value: window.navigator, configurable: true });

const LABELS = ["插件", "扩展管理", "定时任务", "IM"];
document.body.innerHTML = `
<div id="root">
  <div class="hHd-Xa_root">
    <button class="hHd-Xa_newSession"><span>新会话</span></button>
    <nav class="hHd-Xa_panelList" aria-label="全局面板">
      ${LABELS.map((label) => `
      <button class="hHd-Xa_panelRow" aria-label="${label}">
        <span class="hHd-Xa_panelGlyph"><div data-slot="sidebar.panellist" style="display: contents"><svg width="16" height="16"><path d="M0 0"/></svg></div></span>
        <span class="hHd-Xa_panelTitle hHd-Xa_wide">${label}</span>
      </button>`).join("")}
      <span class="hHd-Xa_moreAnchor">
        <button class="hHd-Xa_panelRow" aria-label="更多" aria-haspopup="menu" aria-expanded="false">
          <span class="hHd-Xa_panelGlyph" aria-hidden="true"><svg width="16" height="16"><path d="M0 0"/></svg></span>
          <span class="hHd-Xa_panelTitle hHd-Xa_wide">更多</span>
        </button>
      </span>
    </nav>
    <div class="hHd-Xa_regionArea">工作区</div>
  </div>
  <div id="settings-host">
    <div class="shellSection"><div data-slot="settings.general.item"></div></div>
  </div>
</div>`;
const nav = document.querySelector("nav.hHd-Xa_panelList");
check("shell markup built (4 rows + the More launcher)", nav.querySelectorAll("button.hHd-Xa_panelRow").length === 5);

// ── the module stubs (React is not loaded here) ───────────────────────────
const jsxStub = {
	jsx: (type, props) => ({ type, props }),
	jsxs: (type, props) => ({ type, props })
};
const reactStub = {
	useSyncExternalStore: (_subscribe, getSnapshot) => getSnapshot(),
	useState: (initial) => [typeof initial === "function" ? initial() : initial, () => {}],
	useEffect: () => {},
	useId: () => "dshpb-test-id"
};
/** The shell's SegmentedControl, rendered as the tablist it really is. */
const primitivesStub = {
	SegmentedControl: (props) => jsxStub.jsx("div", {
		role: "tablist",
		"aria-label": props.label,
		children: props.options.map((option) => jsxStub.jsx("button", {
			type: "button",
			role: "tab",
			"aria-selected": String(option.value === props.value),
			onClick: () => props.onChange(option.value),
			children: option.label
		}))
	})
};
const requireStub = (specifier) => {
	if (specifier === "react") return reactStub;
	if (specifier === "react/jsx-runtime") return jsxStub;
	if (specifier === "@deepseek-ai/dsh-client-ui-primitives") return primitivesStub;
	throw new Error(`unexpected require: ${specifier}`);
};

/**
 * Render a `{ type, props }` tree into the real document.
 * @param node - element, function component, text, or a children array.
 * @param parent - DOM node to append into.
 * @returns the created element, when one was created.
 */
function renderTree(node, parent) {
	if (node === null || node === undefined || typeof node === "boolean") return null;
	if (typeof node === "string" || typeof node === "number") {
		parent.appendChild(document.createTextNode(String(node)));
		return null;
	}
	if (Array.isArray(node)) {
		for (const child of node) renderTree(child, parent);
		return null;
	}
	if (typeof node.type === "function") return renderTree(node.type(node.props), parent);
	const element = document.createElement(node.type);
	for (const [key, value] of Object.entries(node.props ?? {})) {
		if (key === "children" || key === "className") continue;
		if (key.startsWith("on") && typeof value === "function") {
			element.addEventListener(key.slice(2).toLowerCase(), value);
			continue;
		}
		if (value === undefined || value === null || value === false) continue;
		element.setAttribute(key, String(value));
	}
	if (typeof node.props?.className === "string") element.setAttribute("class", node.props.className);
	parent.appendChild(element);
	renderTree(node.props?.children, element);
	return element;
}

// ── materialize the bundle and apply it ───────────────────────────────────
let registration;
window.__ModuleLoader__ = {
	load: (record) => {
		registration = record;
	}
};
new Function(bundleSource)();
const clientModule = registration.factory(requireStub);

const effects = [];
const injections = [];
const dictionaries = new Map();
const slotInjections = [];
const registrations = [];
clientModule.apply({
	effect: (callback, name) => {
		const disposer = callback();
		effects.push({ name, disposer });
		return disposer;
	},
	inject: (services, callback) => injections.push({ services, callback })
});
flush();

/** The stylesheet the plugin injected, and the same text with whitespace collapsed. */
const pluginCss = document.querySelector('style[data-plugin-css="dsh-sidebar-panel-buttons/sidebar-panel-buttons.css"]').textContent;
const compactCss = pluginCss.replace(/\s+/g, "");

// ── the scan tagged real nodes ────────────────────────────────────────────
check("nav tagged", nav.hasAttribute("data-dsh-panel-nav"));
check("rows tagged", nav.querySelectorAll("button[data-dsh-panel-row]").length === 5);
check("label cells tagged", nav.querySelectorAll("button[data-dsh-panel-row] > span[data-dsh-panel-label]").length === 5);
check("glyph cells left alone", nav.querySelectorAll("span.hHd-Xa_panelGlyph[data-dsh-panel-label]").length === 0);
check("the More launcher's menu wrapper is tagged", nav.querySelector(":scope > span[data-dsh-panel-row-wrap]") !== null);
check("tooltip edges follow row order", nav.querySelector("button[data-dsh-panel-row]").getAttribute("data-dsh-panel-edge") === "first" && [...nav.querySelectorAll("button[data-dsh-panel-row]")].at(-1).getAttribute("data-dsh-panel-edge") === "last");
check("expanded phase published", document.documentElement.hasAttribute("data-dsh-panel-wide"));
check("layout published", document.documentElement.getAttribute("data-dsh-panel-buttons") === "row");

// ── the Settings section, mounted through the slot the shell declares ─────
check("one dependency injection was requested", injections.length === 1 && injections[0].services.join(",") === "slots,locale");
injections[0].callback({
	effect: (callback, name) => {
		const disposer = callback();
		effects.push({ name, disposer });
		return disposer;
	},
	locale: {
		register: (namespace, dictionary) => {
			dictionaries.set(namespace, dictionary);
			return () => dictionaries.delete(namespace);
		}
	},
	slots: {
		inject: (key, callback) => slotInjections.push({ key, callback }),
		register: (options, component) => {
			registrations.push({ options, component });
			return () => {};
		}
	}
});
check("row registered into the shell's General list", slotInjections.length === 1 && slotInjections[0].key === "settings.general.item");
slotInjections[0].callback();
check("one row component registered", registrations.length === 1);
const rowOptions = registrations[0].options;
// The shell's own host markup: a section wrapper holding the list slot's anchor,
// which is `display: contents`, so the entry's root becomes the row itself.
const slotHost = document.querySelector('[data-slot="settings.general.item"]');
const row = renderTree(registrations[0].component({ t: (key) => dictionaries.get(rowOptions.locale).zh[key] }), slotHost);
const rowText = slotHost.querySelector(".dshpb-rowText");
const rowComputed = window.getComputedStyle(row);
const control = slotHost.querySelector('[role="tablist"]');
console.log(`      row: display=${rowComputed.display} justify-content=${rowComputed.justifyContent} padding=${rowComputed.padding}`);
check("the row is the entry root, inside the shell's list host", row.parentElement === slotHost);
check("the row is label left / control right", rowComputed.display === "flex" && rowComputed.justifyContent === "space-between");
check("the row keeps the shell's rhythm", rowComputed.paddingTop === "16px" && rowComputed.paddingBottom === "16px");
check("the row text block can shrink", window.getComputedStyle(rowText).flexGrow === "1");
// happy-dom cannot resolve `var()` inside a border shorthand, so the hairline is
// asserted as a declaration; the two type sizes below are computable.
check("the row closes with a hairline", /\.dshpb-row\{[^}]*border-bottom:0\.5pxsolidvar\(--dsw-alias-border-l2\)/.test(compactCss));
check("row title and hint use the shell's type scale", window.getComputedStyle(slotHost.querySelector(".dshpb-rowTitle")).fontSize === "14px" && window.getComputedStyle(slotHost.querySelector(".dshpb-rowHint")).fontSize === "12px");
check("the control renders both layouts", [...control.querySelectorAll('[role="tab"]')].map((tab) => tab.textContent).join(" / ") === "按钮行 / 列表");
check("the button row is the selected option", control.querySelector('[aria-selected="true"]').textContent === "按钮行");
check("the control is named for assistive tech", control.getAttribute("aria-label") === "面板菜单布局");

// ── clicking an option really switches (and persists) the layout ──────────
const listTab = [...control.querySelectorAll('[role="tab"]')].find((tab) => tab.textContent === "列表");
listTab.click();
check("choosing 列表 flips the layout gate", document.documentElement.getAttribute("data-dsh-panel-buttons") === "list");
check("choosing 列表 persists the choice", window.localStorage.getItem("dsh-sidebar-panel-buttons:layout") === "list");
const buttonTab = [...control.querySelectorAll('[role="tab"]')].find((tab) => tab.textContent === "按钮行");
buttonTab.click();
check("choosing 按钮行 flips back", document.documentElement.getAttribute("data-dsh-panel-buttons") === "row");

// ── every stylesheet selector matches the real markup of its region ───────
/** Drop the pseudo-class / pseudo-element tail of a compound selector. */
function baseSelector(selector) {
	let depth = 0;
	for (let index = 0; index < selector.length; index += 1) {
		const character = selector[index];
		if (character === "[") depth += 1;
		else if (character === "]") depth -= 1;
		else if (character === ":" && depth === 0) return selector.slice(0, index).trim();
	}
	return selector.trim();
}
const rules = [...pluginCss.replace(/\/\*[\s\S]*?\*\//g, "").matchAll(/(?:^|\})([^{}@]+)\{/g)].map((match) => match[1]);
const bases = new Set();
for (const rule of rules) for (const part of rule.split(",")) bases.add(baseSelector(part));
const unmatched = [];
for (const base of bases) {
	if (base === "") continue;
	if (document.querySelectorAll(base).length === 0) unmatched.push(base);
}
check("every selector matches the real markup it targets", unmatched.length === 0, JSON.stringify(unmatched));

// ── the sidebar cascade lands ─────────────────────────────────────────────
const firstRow = nav.querySelector(":scope > button");
const label = firstRow.querySelector("[data-dsh-panel-label]");
const moreWrap = nav.querySelector(":scope > span[data-dsh-panel-row-wrap]");
const moreRow = moreWrap.querySelector("button[data-dsh-panel-row]");
const moreLabel = moreRow.querySelector("[data-dsh-panel-label]");
const computedNav = window.getComputedStyle(nav);
const computedRow = window.getComputedStyle(firstRow);
const computedLabel = window.getComputedStyle(label);
const computedMoreWrap = window.getComputedStyle(moreWrap);
const computedMoreRow = window.getComputedStyle(moreRow);
const computedMoreLabel = window.getComputedStyle(moreLabel);
console.log(`      sidebar nav: flex-direction=${computedNav.flexDirection} flex-wrap=${computedNav.flexWrap} gap=${computedNav.gap}`);
console.log(`      sidebar row: ${computedRow.width} x ${computedRow.height} justify-content=${computedRow.justifyContent} margin=${computedRow.margin}`);
console.log(`      sidebar label: display=${computedLabel.display}`);
console.log(`      more wrapper: ${computedMoreWrap.width} x ${computedMoreWrap.height}; row: ${computedMoreRow.width} x ${computedMoreRow.height}; label: display=${computedMoreLabel.display}`);
check("the menu lays out as a row", computedNav.flexDirection === "row");
check("the row wraps instead of overflowing a narrow column", computedNav.flexWrap === "wrap");
check("each entry is a 36px square", computedRow.width === "36px" && computedRow.height === "36px");
check("the text label is hidden", computedLabel.display === "none");
check("the More launcher is one 36px square, not a labelled row", computedMoreWrap.width === "36px" && computedMoreWrap.height === "36px" && computedMoreRow.width === "36px" && computedMoreRow.height === "36px");
check("the More launcher's text label is hidden", computedMoreLabel.display === "none");
check("the rest of the sidebar is untouched", window.getComputedStyle(document.querySelector(".hHd-Xa_newSession")).display === "flex");
check("every sidebar rule is gated on the compact mode", pluginCss.split("html[data-dsh-panel-buttons='row'][data-dsh-panel-wide]").length - 1 >= 10);

console.log(`\n${checks - failures.length} passed, ${failures.length} failed`);
process.exit(failures.length === 0 ? 0 : 1);
