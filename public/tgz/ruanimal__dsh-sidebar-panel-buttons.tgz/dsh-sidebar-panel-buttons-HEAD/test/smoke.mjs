/**
 * Smoke test — materialize `lib/client.js` in a stub browser and drive its DOM
 * scan over a hand-built copy of the shell's panel-list markup.
 *
 * The bundle cannot run in Node, and the sidebar cannot be rendered here, so
 * this test supplies the smallest environment the bundle actually touches:
 * a document with attributes and a tree, `style` injection, `localStorage`,
 * `requestAnimationFrame`, `MutationObserver`, and the three modules the
 * factory requires (react, react/jsx-runtime, ui-primitives).
 *
 * The markup it builds is the shell's own shape, from
 * `@deepseek-ai/dsh-client-ui-sidebar`:
 *
 *   nav
 *     button                       ← one per `sidebar.panellist` entry
 *       span                       ← glyph cell
 *         div[data-slot="sidebar.panellist"]
 *       span                       ← label cell, only while expanded
 *     span                         ← the menu primitive's anchor wrapper
 *       button                     ← the panel list's More launcher
 *         span                     ← glyph cell (no panellist anchor)
 *         span                     ← label cell, only while expanded
 *
 * What this pins down: the rows and the container get this plugin's tags; the
 * *label* cell (never the glyph cell) is the one tagged as the label; a row
 * wrapped by the menu primitive (the More launcher) is tagged through the
 * wrapper, and the first/last tooltip edges follow row order rather than the
 * `nav`'s child order; the labelled phase is published on `<html>` and cleared
 * when the shell collapses to the rail; the Settings section flips the layout
 * attribute and persists it; and unload removes every trace it wrote.
 *
 * What it cannot cover: the stylesheet's effect (selectors, tooltips,
 * geometry) — that is browser-side and needs a real sidebar.
 *
 * Run with `npm test` (zero dependencies).
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join, resolve } from "node:path";

const packageDir = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const bundleSource = readFileSync(join(packageDir, "lib", "client.js"), "utf8");

/** Attributes the stylesheet is gated on, mirrored from the bundle's contract. */
const MODE_ATTR = "data-dsh-panel-buttons";
const WIDE_ATTR = "data-dsh-panel-wide";
const NAV_ATTR = "data-dsh-panel-nav";
const ROW_ATTR = "data-dsh-panel-row";
const WRAP_ATTR = "data-dsh-panel-row-wrap";
const LABEL_ATTR = "data-dsh-panel-label";
const EDGE_ATTR = "data-dsh-panel-edge";
const STORAGE_KEY = "dsh-sidebar-panel-buttons:layout";
const CSS_ID = "dsh-sidebar-panel-buttons/sidebar-panel-buttons.css";

//#region stub DOM
/** `pluginCss` -> `plugin-css`, for the dataset-to-attribute proxy below. */
function kebabCase(name) {
	return String(name).replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
}

/**
 * The only selectors the bundle uses. Anything else throws, so the stub cannot
 * silently "support" a selector it does not understand.
 */
const SELECTOR = /^([a-zA-Z][\w-]*)?(?:\[([\w-]+)(?:=["']([^"']*)["'])?\])?$/;

/** Match one stub element against `tag`, `[attr]` or `[attr="value"]`. */
function matches(node, selector) {
	const parsed = SELECTOR.exec(selector.trim());
	if (parsed === null) throw new Error(`stub DOM: unsupported selector ${selector}`);
	const [, tag, attribute, value] = parsed;
	if (tag !== undefined && node.tagName !== tag.toUpperCase()) return false;
	if (attribute !== undefined) {
		if (!node.attributes.has(attribute)) return false;
		if (value !== undefined && node.attributes.get(attribute) !== value) return false;
	}
	return true;
}

/** Depth-first visit of a subtree (including the node itself). */
function walk(node, visit) {
	visit(node);
	for (const child of node.children) walk(child, visit);
}

/** Minimal element: attributes, children, text, and the queries the bundle makes. */
class Element {
	constructor(tagName) {
		this.tagName = String(tagName).toUpperCase();
		this.children = [];
		this.parentNode = null;
		this.attributes = new Map();
		this.text = "";
		this.isConnected = false;
		// `dataset.x = y` must land in the attribute map, like the real DOM.
		this.dataset = new Proxy({}, {
			set: (target, key, value) => {
				target[key] = String(value);
				this.attributes.set(`data-${kebabCase(key)}`, String(value));
				return true;
			}
		});
	}
	get textContent() {
		let out = this.text;
		for (const child of this.children) out += child.textContent;
		return out;
	}
	set textContent(value) {
		this.text = String(value);
		this.children = [];
	}
	appendChild(child) {
		child.parentNode = this;
		this.children.push(child);
		child.setConnected(this.isConnected);
		return child;
	}
	removeChild(child) {
		const index = this.children.indexOf(child);
		if (index >= 0) this.children.splice(index, 1);
		child.parentNode = null;
		child.setConnected(false);
		return child;
	}
	remove() {
		if (this.parentNode !== null) this.parentNode.removeChild(this);
	}
	setConnected(state) {
		this.isConnected = state;
		for (const child of this.children) child.setConnected(state);
	}
	setAttribute(name, value) {
		this.attributes.set(String(name), String(value));
	}
	getAttribute(name) {
		return this.attributes.has(name) ? this.attributes.get(name) : null;
	}
	hasAttribute(name) {
		return this.attributes.has(name);
	}
	removeAttribute(name) {
		this.attributes.delete(name);
	}
	querySelector(selector) {
		return this.querySelectorAll(selector)[0] ?? null;
	}
	querySelectorAll(selector) {
		const found = [];
		walk(this, (node) => {
			if (matches(node, selector)) found.push(node);
		});
		return found;
	}
	closest(selector) {
		let node = this;
		while (node !== null) {
			if (matches(node, selector)) return node;
			node = node.parentNode;
		}
		return null;
	}
}
//#endregion

//#region stub environment
/** Create a detached element. */
function el(tagName) {
	return new Element(tagName);
}

const html = el("html");
html.setConnected(true);
const head = el("head");
const body = el("body");
html.appendChild(head);
html.appendChild(body);

const localStorageData = new Map();
/** Frames queued through `window.requestAnimationFrame`. */
const frames = [];
/** Every observer the plugin installed. */
const observers = [];

class MutationObserverStub {
	constructor(callback) {
		this.callback = callback;
		this.target = null;
		this.options = null;
		this.disconnected = false;
		observers.push(this);
	}
	observe(target, options) {
		this.target = target;
		this.options = options;
	}
	disconnect() {
		this.disconnected = true;
	}
	trigger() {
		this.callback([]);
	}
}

const documentStub = {
	documentElement: html,
	head,
	body,
	createElement: (tagName) => el(tagName),
	querySelector: (selector) => html.querySelector(selector),
	querySelectorAll: (selector) => html.querySelectorAll(selector)
};

const windowStub = {
	__ModuleLoader__: {
		load: (record) => {
			registration = record;
		}
	},
	requestAnimationFrame: (callback) => frames.push(callback),
	setTimeout: (callback) => setTimeout(callback, 0),
	addEventListener: () => {},
	removeEventListener: () => {},
	localStorage: {
		getItem: (key) => (localStorageData.has(key) ? localStorageData.get(key) : null),
		setItem: (key, value) => localStorageData.set(key, String(value)),
		removeItem: (key) => localStorageData.delete(key)
	}
};

let registration;
globalThis.window = windowStub;
globalThis.document = documentStub;
globalThis.MutationObserver = MutationObserverStub;
try {
	Object.defineProperty(globalThis, "navigator", {
		value: { language: "zh-CN" },
		configurable: true
	});
} catch {
	// Node's own navigator is fine; the bundle only reads the language.
}

/** Run every queued animation frame (the plugin's scan scheduler). */
function flushFrames() {
	while (frames.length > 0) frames.shift()();
}

/** Poke the observer the way a real DOM mutation would, then let the scan run. */
function settle() {
	for (const observer of observers) if (!observer.disconnected) observer.trigger();
	flushFrames();
}
//#endregion

//#region stub modules
const dictionaries = new Map();
const slotInjections = [];
const registrations = [];

const reactStub = {
	useSyncExternalStore: (_subscribe, getSnapshot) => getSnapshot(),
	useState: (initial) => [typeof initial === "function" ? initial() : initial, () => {}],
	useEffect: () => {},
	useId: () => "dshpb-test-id",
	createElement: () => {
		throw new Error("the bundle must build elements through react/jsx-runtime");
	}
};
const jsxRuntimeStub = {
	jsx: (type, props) => ({ type, props }),
	jsxs: (type, props) => ({ type, props }),
	Fragment: Symbol.for("react.fragment")
};
const primitivesStub = {
	SegmentedControl: function SegmentedControl() {}
};
function requireStub(specifier) {
	if (specifier === "react") return reactStub;
	if (specifier === "react/jsx-runtime") return jsxRuntimeStub;
	if (specifier === "@deepseek-ai/dsh-client-ui-primitives") return primitivesStub;
	throw new Error(`unexpected require: ${specifier}`);
}
//#endregion

//#region markup
/** One panel row in the shell's own shape; `expanded` adds the label cell. */
function panelRow(label, expanded) {
	const button = el("button");
	button.setAttribute("class", "hHd-Xa_panelRow");
	button.setAttribute("aria-label", label);
	const glyph = el("span");
	glyph.setAttribute("class", "hHd-Xa_panelGlyph");
	const anchor = el("div");
	anchor.setAttribute("data-slot", "sidebar.panellist");
	anchor.setAttribute("style", "display:contents");
	anchor.appendChild(el("svg"));
	glyph.appendChild(anchor);
	button.appendChild(glyph);
	let title = null;
	if (expanded) {
		title = el("span");
		title.setAttribute("class", "hHd-Xa_panelTitle hHd-Xa_wide");
		title.textContent = label;
		button.appendChild(title);
	}
	return { button, glyph, title };
}

/** The panel list's More launcher, wrapped by the menu primitive's anchor span. */
function panelMore(label, expanded) {
	const button = el("button");
	button.setAttribute("class", "hHd-Xa_panelRow");
	button.setAttribute("aria-label", label);
	button.setAttribute("aria-haspopup", "menu");
	button.setAttribute("aria-expanded", "false");
	const glyph = el("span");
	glyph.setAttribute("class", "hHd-Xa_panelGlyph");
	glyph.appendChild(el("svg"));
	button.appendChild(glyph);
	let title = null;
	if (expanded) {
		title = el("span");
		title.setAttribute("class", "hHd-Xa_panelTitle hHd-Xa_wide");
		title.textContent = label;
		button.appendChild(title);
	}
	const wrap = el("span");
	wrap.setAttribute("class", "hHd-Xa_moreAnchor");
	wrap.appendChild(button);
	return { button, glyph, title, wrap };
}

const sidebarRoot = el("div");
sidebarRoot.setAttribute("class", "hHd-Xa_root");
const nav = el("nav");
nav.setAttribute("class", "hHd-Xa_panelList");
nav.setAttribute("aria-label", "全局面板");
const LABELS = ["插件", "扩展管理", "定时任务", "IM"];
const rows = LABELS.map((label) => {
	const row = panelRow(label, true);
	nav.appendChild(row.button);
	return { ...row, label };
});
const more = panelMore("更多", true);
nav.appendChild(more.wrap);
const allRows = [...rows, { ...more, label: "更多" }];
sidebarRoot.appendChild(nav);
body.appendChild(sidebarRoot);
//#endregion

//#region assertions
const failures = [];
let checks = 0;
/** Assert one expectation. */
function check(description, condition) {
	checks += 1;
	if (condition) console.log(`  ok  ${description}`);
	else {
		failures.push(description);
		console.error(`fail  ${description}`);
	}
}

// ── materialize ───────────────────────────────────────────────────────────
new Function(bundleSource)();
check("bundle registers through window.__ModuleLoader__.load", registration !== undefined);
check("bundle id is the package name", registration.id === "dsh-sidebar-panel-buttons");
const clientModule = registration.factory(requireStub);
check("bundle exports apply()", typeof clientModule.apply === "function");
check("bundle declares no hard service dependency", Array.isArray(clientModule.inject) && clientModule.inject.length === 0);

// ── apply ─────────────────────────────────────────────────────────────────
const effects = [];
const injections = [];
const ctx = {
	effect: (callback, name) => {
		const disposer = callback();
		effects.push({ name, disposer });
		return disposer;
	},
	inject: (services, callback) => injections.push({ services, callback })
};
clientModule.apply(ctx);
flushFrames();

check("stylesheet injected once", documentStub.querySelector(`style[data-plugin-css="${CSS_ID}"]`) !== null);
check("stylesheet carries the compact-row gate", documentStub.querySelector(`style[data-plugin-css="${CSS_ID}"]`).textContent.includes(`html[data-dsh-panel-buttons='row']`));
check("stylesheets are not stacked by a reload", documentStub.querySelectorAll(`style[data-plugin-css="${CSS_ID}"]`).length === 1);
check("layout defaults to the compact row", html.getAttribute(MODE_ATTR) === "row");
check("one document observer installed", observers.length === 1 && observers[0].options.subtree === true);

// ── the scan tags the shell's own nodes ───────────────────────────────────
settle();
check("panel list container tagged", nav.getAttribute(NAV_ATTR) === "");
check("every row tagged", rows.every(({ button }) => button.getAttribute(ROW_ATTR) === ""));
check("the label cell is tagged, not the glyph cell", rows.every(({ title, glyph }) => title.getAttribute(LABEL_ATTR) === "" && glyph.getAttribute(LABEL_ATTR) === null));
check("the More launcher is tagged through its menu wrapper", more.wrap.getAttribute(WRAP_ATTR) === "" && more.button.getAttribute(ROW_ATTR) === "");
check("the More label is tagged like every other row", more.title.getAttribute(LABEL_ATTR) === "");
check("the More glyph is never mistaken for a label", more.glyph.getAttribute(LABEL_ATTR) === null);
check("tooltip edges follow row order, not nav child order", rows[0].button.getAttribute(EDGE_ATTR) === "first" && more.button.getAttribute(EDGE_ATTR) === "last" && rows[1].button.getAttribute(EDGE_ATTR) === null);
check("expanded phase published on <html>", html.getAttribute(WIDE_ATTR) === "");
check("scan skips non-button children", (() => {
	const stray = el("div");
	nav.appendChild(stray);
	settle();
	return stray.getAttribute(ROW_ATTR) === null;
})());

// ── collapsing to the rail clears the phase, keeps the tags ───────────────
for (const row of allRows) row.button.removeChild(row.title);
settle();
check("collapsed phase clears the gate (rail keeps shipped geometry)", html.getAttribute(WIDE_ATTR) === null);
check("rows stay tagged across the collapse", allRows.every(({ button }) => button.getAttribute(ROW_ATTR) === ""));

// ── re-expanding, and a late row (a plugin registering its panel) ─────────
for (const row of allRows) {
	const title = el("span");
	title.setAttribute("class", "hHd-Xa_panelTitle hHd-Xa_wide");
	title.textContent = row.label;
	row.button.appendChild(title);
	row.title = title;
}
const late = panelRow("", true);
nav.appendChild(late.button);
settle();
check("re-expanded phase is published again", html.getAttribute(WIDE_ATTR) === "");
check("late rows are tagged too", late.button.getAttribute(ROW_ATTR) === "");
check("a late row takes the last tooltip edge from the More launcher", late.button.getAttribute(EDGE_ATTR) === "last" && more.button.getAttribute(EDGE_ATTR) === null);
check("a second cell marks the labelled phase even with an empty label", html.getAttribute(WIDE_ATTR) === "");
check("an empty label cell is never tagged (nothing glyph-like is hidden)", late.title.getAttribute(LABEL_ATTR) === null);

// ── the Settings section ──────────────────────────────────────────────────
check("the General row wants the slots and locale seats", injections.length === 1 && injections[0].services.join(",") === "slots,locale");
const childCtx = {
	effect: ctx.effect,
	locale: {
		register: (namespace, dictionary) => {
			dictionaries.set(namespace, dictionary);
			return () => dictionaries.delete(namespace);
		}
	},
	slots: {
		inject: (key, callback) => slotInjections.push({ key, callback }),
		register: (options, component) => {
			registrations.push({ options, component });
			return () => {};
		}
	}
};
injections[0].callback(childCtx);
check("dictionaries registered for zh and en", dictionaries.get("sidebar-panel-buttons")?.zh && dictionaries.get("sidebar-panel-buttons")?.en);
check("the row is injected into the shell's General list", slotInjections.length === 1 && slotInjections[0].key === "settings.general.item");
slotInjections[0].callback();
check("exactly one settings row registered", registrations.length === 1);
const options = registrations[0].options;
const component = registrations[0].component;
const t = (key) => dictionaries.get(options.locale).zh[key];
check("the row owns a locale seat and a stable id", options.locale === "sidebar-panel-buttons" && options.name === "settings.general.item" && options.id === "dsh-sidebar-panel-buttons");
check("the row is ordered into the General list", typeof options.order === "number");
check("the row contributes no page of its own", options.label === undefined && options.children === undefined);

let tree = component({ t });
const [rowText, control] = tree.props.children;
check("the row is one element with the shell's row class", tree.type === "div" && tree.props.className === "dshpb-row");
check("the row is label block left, control right", rowText.type === "div" && rowText.props.className === "dshpb-rowText" && control.type === primitivesStub.SegmentedControl);
check("the label block carries title and description", rowText.props.children[0].props.children === "侧边栏面板菜单" && rowText.props.children[1].props.children === t("description"));
check("the control offers both layouts", control.props.options.map((option) => option.value).join(",") === "row,list" && control.props.options[0].label === "按钮行");
check("the control reflects the stored layout", control.props.value === "row");
check("the control is labelled for assistive tech", control.props.label === "面板菜单布局" && typeof control.props.id === "string" && control.props.id !== "");

control.props.onChange("list");
check("choosing list flips the layout gate", html.getAttribute(MODE_ATTR) === "list");
check("choosing list persists the choice", localStorageData.get(STORAGE_KEY) === "list");
tree = component({ t });
check("re-rendering shows the stored choice", tree.props.children[1].props.value === "list");
tree.props.children[1].props.onChange("row");
check("choosing the button row flips back", html.getAttribute(MODE_ATTR) === "row" && localStorageData.get(STORAGE_KEY) === "row");
check("without a locale seat the row reads the document language", component({}).props.children[0].props.children[0].props.children === "侧边栏面板菜单");

// ── stylesheet and component agree on the class vocabulary ────────────────
/** Every `dshpb-` class name a rule in the stylesheet declares. */
const declared = new Set([...documentStub.querySelector(`style[data-plugin-css="${CSS_ID}"]`).textContent.matchAll(/\.(dshpb-[A-Za-z-]+)/g)].map((match) => match[1]));
/** Every class name the rendered row tree uses. */
function collectClasses(node, found = new Set()) {
	if (node === null || typeof node !== "object") return found;
	if (["div", "h2", "p"].includes(node.type)) {
		for (const value of String(node.props.className ?? "").split(/\s+/)) if (value !== "") found.add(value);
	}
	const children = node.props?.children;
	if (Array.isArray(children)) for (const child of children) collectClasses(child, found);
	return found;
}
const used = collectClasses(component({ t }));
const unstyled = [...used].filter((name) => !declared.has(name));
const orphaned = [...declared].filter((name) => !used.has(name));
check("every class the row renders has a rule", unstyled.length === 0, JSON.stringify(unstyled));
check("every row rule has a use", orphaned.length === 0, JSON.stringify(orphaned));

// ── unload ────────────────────────────────────────────────────────────────
for (const { disposer } of effects) if (typeof disposer === "function") disposer();
check("unload removes the stylesheet", documentStub.querySelector(`style[data-plugin-css="${CSS_ID}"]`) === null);
check("unload removes the phase gate", html.getAttribute(WIDE_ATTR) === null);
check("unload removes every tag it wrote", nav.getAttribute(NAV_ATTR) === null && allRows.every(({ button, title }) => button.getAttribute(ROW_ATTR) === null && button.getAttribute(EDGE_ATTR) === null && title.getAttribute(LABEL_ATTR) === null) && more.wrap.getAttribute(WRAP_ATTR) === null);
check("unload disconnects the observer", observers[0].disconnected === true);
//#endregion

console.log(`\n${checks - failures.length} passed, ${failures.length} failed`);
process.exit(failures.length === 0 ? 0 : 1);
