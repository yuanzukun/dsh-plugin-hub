#!/usr/bin/env bash
#
# Mount (or unmount) this plugin in a local dsh profile.
#
# The official route is `dsh plugin --profile <profile> add <this directory>`,
# which forwards to `pnpm add` inside the profile and reconciles the bundle
# stack. This script performs exactly the writes that route settles on —
#
#   node_modules/<name>            symlink to this directory (pnpm's link: dep)
#   dependencies.<name>            link:<this directory>
#   dsh.profile.bundles[]          append <name>, so this package's
#                                  cordis.patch.yml insert row mounts it
#
# — and then asks pnpm to bring pnpm-lock.yaml back in sync with
# `--lockfile-only`, which never touches node_modules. Use it when pnpm cannot
# run (offline / sandboxed), or to see precisely what an install changes.
#
#   scripts/install-into-profile.sh [profile] [--no-lockfile]
#   scripts/install-into-profile.sh [profile] --remove
#
# `profile` is a name under $DSH_PROFILE_DIR's parent, or an absolute profile
# directory; it defaults to $DSH_PROFILE.
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
PACKAGE_NAME="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["name"])' "$PLUGIN_DIR/package.json")"

PROFILE_ARG=""
MODE="install"
LOCKFILE=1
for argument in "$@"; do
	case "$argument" in
		--remove) MODE="remove" ;;
		--no-lockfile) LOCKFILE=0 ;;
		-*) echo "unknown option: $argument" >&2; exit 2 ;;
		*) PROFILE_ARG="$argument" ;;
	esac
done

if [ -z "$PROFILE_ARG" ]; then
	PROFILE_ARG="${DSH_PROFILE:-}"
fi
if [ -z "$PROFILE_ARG" ]; then
	echo "usage: $0 <profile name | profile directory> [--remove] [--no-lockfile]" >&2
	exit 2
fi
case "$PROFILE_ARG" in
	/*) PROFILE_DIR="$PROFILE_ARG" ;;
	*) PROFILE_DIR="$(dirname -- "${DSH_PROFILE_DIR:-$HOME/.dsh/profiles/core-020}")/$PROFILE_ARG" ;;
esac

if [ ! -f "$PROFILE_DIR/package.json" ]; then
	echo "not a dsh profile (no package.json): $PROFILE_DIR" >&2
	exit 1
fi

echo "package : $PACKAGE_NAME"
echo "plugin  : $PLUGIN_DIR"
echo "profile : $PROFILE_DIR"

# ── node_modules symlink ───────────────────────────────────────────────────
LINK="$PROFILE_DIR/node_modules/$PACKAGE_NAME"
if [ "$MODE" = "remove" ]; then
	[ -L "$LINK" ] && rm -- "$LINK" && echo "removed symlink $LINK" || true
else
	mkdir -p -- "$PROFILE_DIR/node_modules"
	ln -sfn -- "$PLUGIN_DIR" "$LINK"
	echo "linked  $LINK -> $PLUGIN_DIR"
fi

# ── profile manifest ───────────────────────────────────────────────────────
PLUGIN_SPEC="link:$PLUGIN_DIR"
python3 - "$PROFILE_DIR/package.json" "$PACKAGE_NAME" "$PLUGIN_SPEC" "$MODE" <<'PY'
import json, sys

path, name, spec, mode = sys.argv[1:5]
with open(path) as handle:
    profile = json.load(handle)

dependencies = profile.setdefault("dependencies", {})
profile.setdefault("dsh", {}).setdefault("profile", {}).setdefault("bundles", [])
bundles = profile["dsh"]["profile"]["bundles"]

if mode == "remove":
    dependencies.pop(name, None)
    while name in bundles:
        bundles.remove(name)
else:
    dependencies[name] = spec
    if name not in bundles:
        bundles.append(name)

with open(path, "w") as handle:
    json.dump(profile, handle, indent=2, ensure_ascii=False)
    handle.write("\n")

print(f"{mode}: dependencies[{name}] = {dependencies.get(name, '<absent>')}")
print(f"{mode}: bundles = {json.dumps(bundles, ensure_ascii=False)}")
PY

# ── lockfile ───────────────────────────────────────────────────────────────
if [ "$LOCKFILE" = "1" ] && [ "$MODE" = "install" ] && command -v pnpm >/dev/null 2>&1; then
	backup="$(mktemp -t dsh-pnpm-lock)"
	cp -- "$PROFILE_DIR/pnpm-lock.yaml" "$backup" 2>/dev/null || true
	if (cd -- "$PROFILE_DIR" && pnpm install --lockfile-only --ignore-scripts >/dev/null 2>&1); then
		echo "synced  pnpm-lock.yaml (--lockfile-only)"
	else
		[ -s "$backup" ] && cp -- "$backup" "$PROFILE_DIR/pnpm-lock.yaml"
		echo "kept    pnpm-lock.yaml unchanged (lockfile-only install unavailable)"
	fi
	rm -f -- "$backup"
fi

echo
if [ "$MODE" = "remove" ]; then
	echo "unmounted. Restart dsh, or reload the profile config, to drop the bundle."
else
	echo "mounted. The profile configuration reloads on its own when it is watched;"
	echo "otherwise refresh the Web page (Cmd-R), then restart dsh if it still does not appear."
fi
