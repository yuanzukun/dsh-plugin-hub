/** `settings.theme` namespace dictionaries (the Appearance row's copy). */

/** Simplified Chinese dictionary (the key-set source of truth). */
export const zh = {
  'appearance.title': '外观',
  'appearance.light': '浅色',
  'appearance.dark': '深色',
  'appearance.system': '跟随系统',
  'appearance.themes': '主题',
  'appearance.default': '默认',
  'appearance.default.desc': 'Harness 经典配色',
  'appearance.custom': '自定义',
  'appearance.custom.logo': 'Logo SVG',
  'appearance.custom.logo.preview': '预览',
  'appearance.custom.logo.placeholder': '粘贴 SVG 代码或 data URI',
  'appearance.custom.wordmark': '品牌字样',
  'appearance.custom.wordmark.placeholder': 'DEEPSEEK',
  'appearance.custom.badge': '徽章字样',
  'appearance.custom.badge.placeholder': 'HARNESS',
  'appearance.custom.heroIcon': '新会话图标',
  'appearance.custom.heroIcon.placeholder': '粘贴 SVG 代码、emoji 或 data URI',
  'appearance.custom.headline': '新会话标题',
  'appearance.custom.headline.placeholder': '探索未至之境',
  'appearance.custom.mappings': '品牌映射',
  'appearance.custom.mappings.desc': '替换提示词中的品牌字符串',
  'appearance.custom.mappings.enabled': '启用品牌映射',
  'appearance.custom.mappings.deepseek': 'DeepSeek →',
  'appearance.custom.mappings.deepseekChinese': '深度求索 →',
  'appearance.custom.mappings.harness': 'Harness →',
  'appearance.custom.mappings.deepseekHarness': 'DeepSeek Harness →',
} satisfies Record<string, string>

/** The settings.theme namespace key union. */
export type ThemeKey = keyof typeof zh

/** English dictionary, checked complete against the zh key set. */
export const en = {
  'appearance.title': 'Appearance',
  'appearance.light': 'Light',
  'appearance.dark': 'Dark',
  'appearance.system': 'System',
  'appearance.themes': 'Theme',
  'appearance.default': 'Default',
  'appearance.default.desc': 'Classic Harness palette',
  'appearance.custom': 'Custom',
  'appearance.custom.logo': 'Logo SVG',
  'appearance.custom.logo.preview': 'Preview',
  'appearance.custom.logo.placeholder': 'Paste SVG code or data URI',
  'appearance.custom.wordmark': 'Wordmark',
  'appearance.custom.wordmark.placeholder': 'DEEPSEEK',
  'appearance.custom.badge': 'Badge text',
  'appearance.custom.badge.placeholder': 'HARNESS',
  'appearance.custom.heroIcon': 'New session icon',
  'appearance.custom.heroIcon.placeholder': 'Paste SVG, emoji, or data URI',
  'appearance.custom.headline': 'New session headline',
  'appearance.custom.headline.placeholder': 'Explore the unknown',
  'appearance.custom.mappings': 'Brand mappings',
  'appearance.custom.mappings.desc': 'Replace brand strings in prompts',
  'appearance.custom.mappings.enabled': 'Enable brand mappings',
  'appearance.custom.mappings.deepseek': 'DeepSeek →',
  'appearance.custom.mappings.deepseekChinese': '深度求索 →',
  'appearance.custom.mappings.harness': 'Harness →',
  'appearance.custom.mappings.deepseekHarness': 'DeepSeek Harness →',
} satisfies Record<ThemeKey, string>
