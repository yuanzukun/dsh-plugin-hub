/**
 * Appearance preference row registered into the General section item slot:
 * title + a mode cube row (light/dark/system) + a style-theme swatch grid +
 * a custom-brand configuration block. Registered by this package — the theme
 * feature owns its own settings surface. Selection follows the persisted
 * preference/theme/customBrand, never the resolved active theme.
 */
import clsx from 'clsx'
import {
  IconDarkOutline16, IconFollowsystemOutline16, IconLightOutline16,
} from '@deepseek-ai/dsh-client-ui-primitives'
import type { PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots'
import type { ThemePreference } from '../theme-settings.ts'
import { DEFAULT_THEME } from '../theme-settings.ts'
import type { CustomBrandConfig } from '../theme-settings.ts'
import type { ThemeKey } from './locales.ts'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type { createAppearanceRowStore } from './settings-store.ts'
import type { ThemeDefinition } from './index.ts'
import css from './AppearanceRow.module.css'

/** Injected business face: the preference/theme writes (t rides the standard locale seat). */
export interface AppearanceRowInjected {
  /** Switch the theme preference. */
  setTheme: (id: ThemePreference) => void
  /** Switch the style theme (a registered theme id or `default`). */
  setThemeId: (id: string) => void
  /** Switch the custom brand configuration. */
  setCustomBrand: (patch: Partial<CustomBrandConfig>) => void
}

/** Full component props: runtime share + store share + locale seat + injected face. */
export type AppearanceRowComponentProps =
  PropsRuntime<'settings.general.item'> & PropsStore<ReturnType<typeof createAppearanceRowStore>>
  & PropsLocale<'settings.theme'> & AppearanceRowInjected

/** Mode cube order and icons (figma 501:30015-30017: Light, Dark, System). */
const CUBES: readonly { id: ThemePreference; labelKey: ThemeKey; Icon: typeof IconLightOutline16 }[] = [
  { id: 'light', labelKey: 'appearance.light', Icon: IconLightOutline16 },
  { id: 'dark', labelKey: 'appearance.dark', Icon: IconDarkOutline16 },
  { id: 'system', labelKey: 'appearance.system', Icon: IconFollowsystemOutline16 },
]

/** Swatch gradient fallback when a theme declares none. */
const FALLBACK_SWATCH: [string, string] = ['#e8ecf0', '#c0c8d4']

/** Built-in palette ids the mode cubes already cover; they never appear as style-theme cards. */
const PALETTE_IDS = new Set(['light', 'dark'])

/** The implicit "no style theme" entry shown ahead of the registered grid. */
function defaultEntry(): ThemeDefinition {
  return {
    id: DEFAULT_THEME,
    colorScheme: 'light',
    tokens: {},
    name: '', // name/desc come from locale keys below
    swatch: FALLBACK_SWATCH,
  }
}

/** Render a live SVG/emoji preview, sanitizing raw markup. */
function MarkupPreview({ markup, className }: { markup: string; className?: string }) {
  if (markup === '') return null
  const isDataUri = markup.startsWith('data:')
  const isSvg = markup.trimStart().startsWith('<svg')
  if (isDataUri || isSvg) {
    return <span className={className} dangerouslySetInnerHTML={{ __html: markup }} />
  }
  // Treat as emoji / text fallback.
  return <span className={className} aria-hidden="true">{markup}</span>
}

/**
 * Render the Appearance row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export function AppearanceRow({ t, setTheme, setThemeId, setCustomBrand, useStore }: AppearanceRowComponentProps) {
  const preference = useStore(s => s.preference)
  const themeId = useStore(s => s.theme)
  const themes = useStore(s => s.themes)
  const customBrand = useStore(s => s.customBrand)
  const entries: readonly ThemeDefinition[] = [
    defaultEntry(),
    ...themes.filter(theme => !PALETTE_IDS.has(theme.id)),
  ]
  const update = (patch: Partial<CustomBrandConfig>) => { setCustomBrand(patch) }
  const updateMappings = (patch: Partial<CustomBrandConfig['mappings']>) => {
    setCustomBrand({ mappings: { ...customBrand.mappings, ...patch } })
  }
  return (
    <div className={css.group}>
      <div className={css.title}>{t('appearance.title')}</div>
      <div className={css.cubeRow}>
        {CUBES.map(({ id, labelKey, Icon }) => (
          <button
            key={id}
            type="button"
            className={clsx(css.themeCube, preference === id && css.selected)}
            aria-pressed={preference === id}
            onClick={() => { setTheme(id) }}
          >
            <Icon />
            {t(labelKey)}
          </button>
        ))}
      </div>
      {entries.length > 1 && (
        <>
          <div className={css.sectionTitle}>{t('appearance.themes')}</div>
          <div className={css.themeGrid}>
            {entries.map((entry) => {
              const label = entry.id === DEFAULT_THEME
                ? t('appearance.default')
                : (entry.name ?? entry.id)
              const desc = entry.id === DEFAULT_THEME
                ? t('appearance.default.desc')
                : (entry.desc ?? '')
              const swatch = entry.swatch ?? FALLBACK_SWATCH
              return (
                <button
                  key={entry.id}
                  type="button"
                  className={clsx(css.themeCard, themeId === entry.id && css.selected)}
                  aria-pressed={themeId === entry.id}
                  onClick={() => { setThemeId(entry.id) }}
                >
                  <span
                    className={css.swatch}
                    style={{ background: `linear-gradient(135deg, ${swatch[0]} 0%, ${swatch[1]} 100%)` }}
                    aria-hidden="true"
                  />
                  <span className={css.cardLabel}>{label}</span>
                  {desc !== '' && <span className={css.cardDesc}>{desc}</span>}
                </button>
              )
            })}
          </div>
        </>
      )}
      <div className={css.sectionTitle}>{t('appearance.custom')}</div>
      <div className={css.customBlock}>
        <div className={css.fieldRow}>
          <label className={css.fieldLabel} htmlFor="custom-logo">{t('appearance.custom.logo')}</label>
          <div className={css.fieldInput}>
            <textarea
              id="custom-logo"
              className={css.textarea}
              rows={3}
              value={customBrand.logo}
              placeholder={t('appearance.custom.logo.placeholder')}
              onChange={(e) => { update({ logo: e.target.value }) }}
            />
            {customBrand.logo !== '' && (
              <div className={css.previewWrap}>
                <span className={css.previewLabel}>{t('appearance.custom.logo.preview')}</span>
                <MarkupPreview markup={customBrand.logo} className={css.logoPreview} />
              </div>
            )}
          </div>
        </div>
        <div className={css.fieldRow}>
          <label className={css.fieldLabel} htmlFor="custom-wordmark">{t('appearance.custom.wordmark')}</label>
          <div className={css.fieldInput}>
            <input
              id="custom-wordmark"
              className={css.input}
              value={customBrand.wordmark}
              placeholder={t('appearance.custom.wordmark.placeholder')}
              onChange={(e) => { update({ wordmark: e.target.value }) }}
            />
          </div>
        </div>
        <div className={css.fieldRow}>
          <label className={css.fieldLabel} htmlFor="custom-badge">{t('appearance.custom.badge')}</label>
          <div className={css.fieldInput}>
            <input
              id="custom-badge"
              className={css.input}
              value={customBrand.wordmarkBadge}
              placeholder={t('appearance.custom.badge.placeholder')}
              onChange={(e) => { update({ wordmarkBadge: e.target.value }) }}
            />
          </div>
        </div>
        <div className={css.fieldRow}>
          <label className={css.fieldLabel} htmlFor="custom-hero">{t('appearance.custom.heroIcon')}</label>
          <div className={css.fieldInput}>
            <input
              id="custom-hero"
              className={css.input}
              value={customBrand.heroIcon}
              placeholder={t('appearance.custom.heroIcon.placeholder')}
              onChange={(e) => { update({ heroIcon: e.target.value }) }}
            />
            {customBrand.heroIcon !== '' && (
              <div className={css.previewWrap}>
                <MarkupPreview markup={customBrand.heroIcon} className={css.heroPreview} />
              </div>
            )}
          </div>
        </div>
        <div className={css.fieldRow}>
          <label className={css.fieldLabel} htmlFor="custom-headline">{t('appearance.custom.headline')}</label>
          <div className={css.fieldInput}>
            <input
              id="custom-headline"
              className={css.input}
              value={customBrand.headline}
              placeholder={t('appearance.custom.headline.placeholder')}
              onChange={(e) => { update({ headline: e.target.value }) }}
            />
          </div>
        </div>
        <div className={css.divider} />
        <div className={css.fieldRow}>
          <label className={css.fieldLabel}>{t('appearance.custom.mappings')}</label>
          <div className={css.fieldInput}>
            <p className={css.fieldHint}>{t('appearance.custom.mappings.desc')}</p>
            <label className={css.toggleRow}>
              <input
                type="checkbox"
                checked={customBrand.mappings.enabled}
                onChange={(e) => { updateMappings({ enabled: e.target.value === 'on' }) }}
              />
              <span>{t('appearance.custom.mappings.enabled')}</span>
            </label>
            {customBrand.mappings.enabled && (
              <div className={css.mappingGrid}>
                <label className={css.mappingLabel}>
                  <span>{t('appearance.custom.mappings.deepseekHarness')}</span>
                  <input
                    className={css.input}
                    value={customBrand.mappings.deepseekHarness}
                    onChange={(e) => { updateMappings({ deepseekHarness: e.target.value }) }}
                  />
                </label>
                <label className={css.mappingLabel}>
                  <span>{t('appearance.custom.mappings.deepseek')}</span>
                  <input
                    className={css.input}
                    value={customBrand.mappings.deepseek}
                    onChange={(e) => { updateMappings({ deepseek: e.target.value }) }}
                  />
                </label>
                <label className={css.mappingLabel}>
                  <span>{t('appearance.custom.mappings.deepseekChinese')}</span>
                  <input
                    className={css.input}
                    value={customBrand.mappings.deepseekChinese}
                    onChange={(e) => { updateMappings({ deepseekChinese: e.target.value }) }}
                  />
                </label>
                <label className={css.mappingLabel}>
                  <span>{t('appearance.custom.mappings.harness')}</span>
                  <input
                    className={css.input}
                    value={customBrand.mappings.harness}
                    onChange={(e) => { updateMappings({ harness: e.target.value }) }}
                  />
                </label>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}