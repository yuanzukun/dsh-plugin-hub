# dsh-auto-update

一个运行在宿主端的 **DeepSeek Harness 启动自动更新插件**。

DeepSeek Harness 官方 CLI 没有 `self-update`，社区里已有的插件（如 `dsh-update-checker`）只能**检查**更新、然后让用户点按钮手动安装。这个插件补上"无人值守"这一环：每次启动时对比本机 `dsh --version` 与 npm registry 的 dist-tag，发现新版本时按配置**只提醒**（默认，安全）或**自动安装**（需显式开启）。

## 特性

- **启动时检查一次**：启动后延迟几秒自动检查一次，之后不再重复检查
- **正确的 semver 比较**：正确处理 `0.1.0-rc.5` → `0.1.0-rc.6` 这类预发布版本
- **两种模式**：
  - `notify`（默认）：只在控制台打印醒目的"发现新版本"横幅，不安装
  - `install`：自动执行安装命令（默认 `npm install -g @deepseek-ai/dsh@<version>`）
- **状态持久化**：检查结果写入 `~/.dsh/dsh-auto-update-state.json`，保留最近 10 次历史
- **profile 无关**：不依赖 `webServer`，`web` / `headless` / `tui` / 任意自定义 profile 都能用
- **优雅卸载**：启动检查的 `setTimeout` 通过 `ctx.effect` 注册，HMR 替换或插件卸载时自动清理
- **零运行时依赖**：只用 Node 内置模块 + 全局 `fetch`

## 安装

```sh
dsh plugin --profile web add github:frostming/dsh-auto-update
# 或从本地 checkout 安装
dsh plugin --profile web add /path/to/dsh-auto-update
```

重启 `dsh web` 生效。默认只提醒不安装，控制台会打印：

```
════════════════════════════════════════════════════════
  dsh-auto-update: update available
    installed: 0.1.0-rc.5
    available: 0.1.0-rc.6 (latest)
    action:    notify only — run npm install -g @deepseek-ai/dsh@0.1.0-rc.6
════════════════════════════════════════════════════════
```

## 开启自动安装

编辑 profile 的 `cordis.patch.yml`（`$DSH_HOME/profiles/<name>/cordis.patch.yml`），覆盖 `mode`：

```yaml
- insert:
    - id: dsh-auto-update
      name: 'dsh-auto-update'
      config:
        mode: install
        # 可选：自定义安装命令，{version} / {package} 会被替换
        installCommand: 'npm install -g {package}@{version}'
```

> ⚠️ DeepSeek Harness 目前处于 developer preview，官方明确声明会有**破坏性兼容变更**。自动安装等于接受这种风险，请谨慎开启。

## 配置项

| 键 | 默认值 | 说明 |
|---|---|---|
| `channels` | `["latest", "next"]` | 按优先级咨询的 dist-tag |
| `startupDelayMs` | `5000` | 启动后检查的延迟，毫秒 |
| `mode` | `"notify"` | `"notify"` 或 `"install"` |
| `installCommand` | `npm install -g {package}@{version}` | 安装命令模板 |
| `stateFile` | `~/.dsh/dsh-auto-update-state.json` | 状态文件路径 |
| `verbose` | `true` | 是否打印检查日志 |

## 目录结构

```
dsh-auto-update/
├── package.json        # dsh bundle 声明（dsh.bundle.patch）
├── cordis.patch.yml    # 插入插件行到 profile 层级栈
├── lib/
│   ├── index.js        # 宿主端：启动时一次性检查 + 决策 + 安装执行
│   ├── semver.js       # 无依赖的 semver 比较
│   ├── version.js      # 本地版本解析 + npm registry 查询
│   └── state.js        # 状态持久化
└── test/               # node --test 单元测试
```

## 测试

```sh
npm test
```

## License

MIT
