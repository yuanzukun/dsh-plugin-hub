import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  comparePrerelease,
  compareVersions,
  isUpdate,
  parseVersion,
} from '../lib/semver.js'

test('parseVersion handles release versions', () => {
  assert.deepEqual(parseVersion('0.1.0-rc.6'), { major: 0, minor: 1, patch: 0, pre: ['rc', '6'] })
  assert.deepEqual(parseVersion('1.2.3'), { major: 1, minor: 2, patch: 3, pre: [] })
  assert.deepEqual(parseVersion('v2.0.0'), { major: 2, minor: 0, patch: 0, pre: [] })
})

test('parseVersion rejects malformed input', () => {
  assert.equal(parseVersion(''), null)
  assert.equal(parseVersion('latest'), null)
  assert.equal(parseVersion('1.2'), null)
  assert.equal(parseVersion('1.2.3.4'), null)
  assert.equal(parseVersion(null), null)
  assert.equal(parseVersion(undefined), null)
  assert.equal(parseVersion(123), null)
})

test('compareVersions orders release and prerelease correctly', () => {
  assert.ok(compareVersions('0.1.0-rc.6', '0.1.0-rc.5') > 0)
  assert.ok(compareVersions('0.1.0-rc.5', '0.1.0-rc.6') < 0)
  assert.ok(compareVersions('0.1.0-rc.6', '0.1.0-rc.6') === 0)
  assert.ok(compareVersions('0.1.0', '0.1.0-rc.6') > 0)
  assert.ok(compareVersions('0.1.0-rc.6', '0.1.0') < 0)
  assert.ok(compareVersions('0.2.0', '0.1.9') > 0)
  assert.ok(compareVersions('1.0.0', '0.9.9') > 0)
})

test('compareVersions is total across the real dsh publish history', () => {
  const history = ['0.0.1-rc.1', '0.0.1-rc.2', '0.0.1-rc.5', '0.1.0-rc.2', '0.1.0-rc.3', '0.1.0-rc.6']
  for (let i = 0; i < history.length; i += 1) {
    for (let j = i + 1; j < history.length; j += 1) {
      assert.ok(compareVersions(history[i], history[j]) < 0, `${history[i]} < ${history[j]}`)
      assert.ok(compareVersions(history[j], history[i]) > 0, `${history[j]} > ${history[i]}`)
    }
  }
})

test('compareVersions fails closed on malformed input', () => {
  assert.equal(compareVersions('garbage', '0.1.0-rc.6'), 0)
  assert.equal(compareVersions('0.1.0-rc.6', 'garbage'), 0)
  assert.equal(isUpdate('0.1.0-rc.6', 'garbage'), false)
})

test('comparePrerelease orders numeric and alpha identifiers per SemVer', () => {
  assert.ok(comparePrerelease(['rc', '2'], ['rc', '10']) < 0)
  assert.ok(comparePrerelease(['rc', '10'], ['rc', '2']) > 0)
  assert.ok(comparePrerelease(['beta'], ['alpha']) > 0)
  assert.ok(comparePrerelease(['alpha'], ['beta']) < 0)
  assert.ok(comparePrerelease(['alpha'], ['1']) > 0) // non-numeric ranks above numeric
  assert.ok(comparePrerelease(['rc'], ['rc', '1']) < 0) // shorter prefix ranks lower
})

test('isUpdate detects only strictly newer versions', () => {
  assert.equal(isUpdate('0.1.0-rc.5', '0.1.0-rc.6'), true)
  assert.equal(isUpdate('0.1.0-rc.6', '0.1.0-rc.6'), false)
  assert.equal(isUpdate('0.1.0-rc.6', '0.1.0-rc.5'), false)
  assert.equal(isUpdate('0.1.0-rc.6', '0.2.0'), true)
  assert.equal(isUpdate('0.2.0', '0.1.0-rc.6'), false)
})
