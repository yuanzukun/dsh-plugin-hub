import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { performCheck } from '../lib/index.js'
import { readState } from '../lib/state.js'

function makeConfig(overrides = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-au-check-'))
  return {
    channels: ['latest', 'next'],
    startupDelayMs: 5_000,
    mode: 'notify',
    installCommand: 'npm install -g {package}@{version}',
    stateFile: join(dir, 'state.json'),
    verbose: false,
    ...overrides,
  }
}

test('records up-to-date state when local equals latest', async () => {
  const config = makeConfig()
  const record = await performCheck(config, {
    resolveLocalVersion: () => '0.1.0-rc.6',
    fetchLatest: async () => ({ version: '0.1.0-rc.6', channel: 'latest' }),
  })
  assert.equal(record.hasUpdate, false)
  assert.equal(record.action, 'none')
  assert.equal(readState(config.stateFile).lastCheck.local, '0.1.0-rc.6')
})

test('notifies without installing in notify mode', async () => {
  const config = makeConfig({ mode: 'notify' })
  const record = await performCheck(config, {
    resolveLocalVersion: () => '0.1.0-rc.5',
    fetchLatest: async () => ({ version: '0.1.0-rc.6', channel: 'latest' }),
  })
  assert.equal(record.hasUpdate, true)
  assert.equal(record.action, 'notified')
})

test('fails closed when the registry cannot be reached', async () => {
  const config = makeConfig()
  const record = await performCheck(config, {
    resolveLocalVersion: () => '0.1.0-rc.5',
    fetchLatest: async () => null,
  })
  assert.equal(record.hasUpdate, false)
  assert.equal(record.latest, null)
  assert.equal(record.action, 'none')
})

test('fails closed when the local version is unreadable', async () => {
  const config = makeConfig()
  const record = await performCheck(config, {
    resolveLocalVersion: () => null,
    fetchLatest: async () => ({ version: '0.1.0-rc.6', channel: 'latest' }),
  })
  assert.equal(record.hasUpdate, false)
  assert.equal(record.local, null)
  assert.equal(record.action, 'none')
})

test('records notified action and persists history', async () => {
  const config = makeConfig()
  await performCheck(config, {
    resolveLocalVersion: () => '0.1.0-rc.5',
    fetchLatest: async () => ({ version: '0.1.0-rc.6', channel: 'latest' }),
  })
  await performCheck(config, {
    resolveLocalVersion: () => '0.1.0-rc.6',
    fetchLatest: async () => ({ version: '0.1.0-rc.6', channel: 'latest' }),
  })
  const state = readState(config.stateFile)
  assert.equal(state.history.length, 2)
  assert.equal(state.lastCheck.hasUpdate, false)
  assert.equal(state.history[1].hasUpdate, true)
})
