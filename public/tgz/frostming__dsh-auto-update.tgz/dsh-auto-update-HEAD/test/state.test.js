import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, readFileSync, writeFileSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { readState, writeState, recordCheck } from '../lib/state.js'

test('readState returns empty state for a missing file', () => {
  const file = join(mkdtempSync(join(tmpdir(), 'dsh-au-')), 'none.json')
  assert.deepEqual(readState(file), { lastCheck: null, history: [] })
})

test('writeState and readState round-trip', () => {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-au-'))
  const file = join(dir, 'state.json')
  const state = {
    lastCheck: { at: 1, local: '0.1.0-rc.5', latest: '0.1.0-rc.6', channel: 'latest', hasUpdate: true, action: 'notified' },
    history: [],
  }
  writeState(file, state)
  assert.deepEqual(readState(file).lastCheck, state.lastCheck)
  assert.ok(existsSync(file))
})

test('readState tolerates corrupt JSON', () => {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-au-'))
  const file = join(dir, 'state.json')
  writeFileSync(file, 'not json {')
  assert.deepEqual(readState(file), { lastCheck: null, history: [] })
})

test('recordCheck prepends and trims history to maxEntries', () => {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-au-'))
  const file = join(dir, 'state.json')
  for (let i = 1; i <= 12; i += 1) {
    recordCheck(file, { at: i, local: 'x', latest: 'y', channel: 'latest', hasUpdate: false, action: 'none' }, 10)
  }
  const state = readState(file)
  assert.equal(state.history.length, 10)
  assert.equal(state.history[0].at, 12)
  assert.equal(state.history[9].at, 3)
  assert.equal(state.lastCheck.at, 12)
})

test('history is persisted as JSON with expected keys', () => {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-au-'))
  const file = join(dir, 'state.json')
  recordCheck(file, { at: 123, local: '0.1.0-rc.5', latest: '0.1.0-rc.6', channel: 'latest', hasUpdate: true, action: 'notified' })
  const raw = JSON.parse(readFileSync(file, 'utf8'))
  assert.equal(raw.lastCheck.hasUpdate, true)
  assert.equal(raw.history[0].local, '0.1.0-rc.5')
})
