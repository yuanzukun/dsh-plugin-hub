// Replicate the extended controller's applyPackage step 1: resolve Config for
// every official package it injects, WITHOUT applying (no side effects).
import { createRequire } from 'node:module';

const require = createRequire('C:/Users/weryu/.dsh/profiles/web/node_modules/dsh-minimal-msys2/lib/x.js');

const pkgs = [
  ['@deepseek-ai/dsh-tool-pwsh', {}],
  ['@deepseek-ai/dsh-tool-fs', {}],
  ['@deepseek-ai/dsh-tool-fs-search', { sampleOverCapGlobResults: false }],
  ['@deepseek-ai/dsh-skill-filesystem', {}],
  ['@deepseek-ai/dsh-tool-skill', {}],
  ['@deepseek-ai/dsh-tool-goal', {}],
  ['@deepseek-ai/dsh-tool-jobs', {}],
  ['@deepseek-ai/dsh-tool-web', { fetch: false, searchTimeoutMs: 60000 }],
  ['@deepseek-ai/dsh-tool-ask-user', {}],
  ['@deepseek-ai/dsh-tool-todo', { allowParallelInProgress: true }],
  ['@deepseek-ai/dsh-tool-subagent', { provider: 'spawn', toolName: 'subagent', backgroundMode: 'continuable' }],
  ['@deepseek-ai/dsh-tool-subagent', { provider: 'fork', toolName: 'subagent_fork', backgroundMode: 'one-shot' }],
  ['@deepseek-ai/dsh-tool-subagent-control', {}],
  ['@deepseek-ai/dsh-tool-subagent-control/list-agents', {}],
  ['@deepseek-ai/dsh-tool-workflow', {}],
  ['@deepseek-ai/dsh-tool-ralph', { subagentProvider: 'spawn', maxRounds: 64 }],
];

for (const [spec, config] of pkgs) {
  try {
    const resolved = require.resolve(spec);
    const mod = await import('file://' + resolved.split('\\').join('/'));
    if (typeof mod.apply !== 'function') {
      console.log(`SKIP ${spec}: no apply export`);
      continue;
    }
    if (typeof mod.Config === 'function') {
      const parsed = mod.Config(config ?? {});
      console.log(`OK   ${spec}: Config resolved`);
    } else {
      console.log(`NOTE ${spec}: no Config export; apply would get raw config`);
    }
    // Also verify apply is a function and inspect its arity/name.
    console.log(`     ${spec}: apply.name=${mod.apply.name} apply.length=${mod.apply.length}`);
  } catch (error) {
    console.log(`FAIL ${spec}: ${error && error.message ? error.message : String(error)}`);
  }
}
