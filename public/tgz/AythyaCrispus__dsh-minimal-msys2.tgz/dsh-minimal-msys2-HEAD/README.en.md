# dsh-minimal-msys2

Windows Minimal Mode dsh plugin: provides a persistent `bash` tool on Windows whose model-facing definition is identical to the official `minimal` preset (`command` parameter, persistent-shell semantics), plus `str_replace_editor` — and a dedicated tool-call row for `str_replace_editor` (command summary, running/failed state, expandable before/after preview).

Ships two presets:

- **Windows Minimal Mode** (`minimal-msys2`): pure minimal — `bash` + `str_replace_editor`, tool definitions byte-identical to the official minimal preset.
- **Minimal Extended Mode** (`minimal-extended`): round one is the minimal preset (persistent bash + str_replace_editor + the minimal system prompt); after round one the full standard toolset, skills, and prompts are injected automatically (pwsh, read/write/edit, glob/grep, skill, goal, jobs, web_search, ask_user_question, todo, subagent/subagent_fork/send_message/interrupt_agent/list_agents, workflow, ralph, agent-instructions, plan-mode).

## Background

The official `minimal` preset's persistent bash cannot work on Windows, for two independent platform limitations:

1. `dsh-subprocess-local`'s terminal allocation depends on POSIX process inspection (Linux /proc, macOS ps) and throws `terminal inspection is unsupported on platform win32`;
2. Even past that, the default `workspace-write` sandbox wraps bash in the Windows ACL restricted-token runner, under which the MSYS2/Cygwin runtime cannot create its signal pipe (`bash: *** fatal error - couldn't create signal pipe, Win32 error 5`) and bash dies at startup.

This plugin provides a win32-native PTY spawn (node-pty/ConPTY, no POSIX process inspection) and reuses the official `BashTerminalBackend` session logic, so the model-visible `bash` tool definition stays identical to the official minimal preset.

## Install

```powershell
dsh plugin --profile web add github:AythyaCrispus/dsh-minimal-msys2
```

Then **restart dsh**. On startup the plugin copies the agent preset to `$DSH_HOME/.agent-presets/minimal-msys2` (existing files are never overwritten, so your edits survive upgrades).

## Usage

1. Run sessions in **danger-full-access** mode (MSYS2 bash is incompatible with the Windows restricted token — a hard limit):
   ```powershell
   $env:DSH_PERMISSION_MODE = 'danger-full-access'
   dsh web
   ```
   Or switch the session sandbox mode to danger-full-access in the Web UI.
2. Create a session and pick **Windows Minimal Mode**.
3. The tool list should be `bash` + `str_replace_editor`.

## Configuring the bash path (GUI)

MSYS2 and Git Bash install paths differ, so no config-file editing is required:

1. Open Web GUI **Settings → Plugin settings → "Windows 极简模式"** (the card is bilingual; it follows the GUI locale: "Windows 极简模式" in Chinese, "Windows Minimal Mode" in English);
2. Type your `bash.exe` absolute path (e.g. `C:/msys64/usr/bin/bash.exe` or `C:/Program Files/Git/bin/bash.exe`) and click **Save**;
3. The value is stored as the `DSH_MSYS2_BASH` entry in `$DSH_HOME/.credentials.yaml` (persisted via the credentials domain, which bypasses the rc.6 settings-namespace allowlist); the backend reads it on every session start; click **Clear** and save to restore the default.

You can also set the environment variable `DSH_MSYS2_BASH` (higher priority than the credentials file), or edit the `shellPath` of the `terminal-bash` row in `$DSH_HOME/.agent-presets/minimal-msys2/agent.cordis.yml` (lowest priority; the fallback default).

## Uninstall

```powershell
dsh plugin --profile web remove dsh-minimal-msys2
Remove-Item "$HOME\.dsh\.agent-presets\minimal-msys2" -Recurse -Force   # remove the copied preset by hand
```

## Known limitations

- Requires `danger-full-access` mode (fundamental MSYS2/Cygwin incompatibility with the Windows restricted token; cannot be worked around).
- Persistent PTY shell, matching the official minimal preset.
- Reuses the host's `node-pty`, `@deepseek-ai/dsh-terminal-bash`, and `@deepseek-ai/dsh-subprocess` (peerDependencies; no native rebuild on install).
