import fs from 'node:fs';
import path from 'node:path';
import { zstdDecompressSync } from 'node:zlib';

const dir = 'C:/Users/weryu/.dsh/sessions/--D-agent_works--';
const targets = ['session-41f86e52-4ce', 'session-9e5d2b6a-8dd'];
for (const sub of targets) {
  const p = path.join(dir, sub, 'session.jsonl.zstd');
  if (!fs.existsSync(p)) { console.log(sub, 'missing'); continue; }
  const out = zstdDecompressSync(fs.readFileSync(p));
  const text = out.toString('utf8');
  console.log(`===== ${sub} (${out.length} bytes) =====`);
  console.log(text.slice(0, 3000));
  console.log('...TAIL...');
  console.log(text.slice(-1500));
}
