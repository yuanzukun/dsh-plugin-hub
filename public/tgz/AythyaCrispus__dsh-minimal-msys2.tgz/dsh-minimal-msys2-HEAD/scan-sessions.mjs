import fs from 'node:fs';
import path from 'node:path';
import { zstdDecompressSync } from 'node:zlib';

const dir = 'C:/Users/weryu/.dsh/sessions/--D-agent_works--';
for (const sub of fs.readdirSync(dir)) {
  const p = path.join(dir, sub, 'session.jsonl.zstd');
  if (!fs.existsSync(p)) continue;
  try {
    const out = zstdDecompressSync(fs.readFileSync(p));
    const text = out.toString('utf8');
    const lines = text.split('\n');
    let preset = '?';
    try { preset = JSON.parse(lines[0]).agentPreset; } catch {}
    const count = (re) => (text.match(re) || []).length;
    const um = count(/"type":"user\/message"/g);
    const tc = count(/"type":"tool\/call"/g);
    const am = count(/"type":"assistant\/message"/g);
    const st = fs.statSync(p);
    console.log(`${sub.slice(0, 20)} | preset=${preset} | userMsg=${um} toolCall=${tc} asstMsg=${am} | ${st.mtime.toISOString()} | size=${st.size}`);
  } catch (e) {
    console.log(`${sub.slice(0, 20)} | ERR ${e.message}`);
  }
}
