import fs from 'node:fs';
import path from 'node:path';
import { createZstdDecompress } from 'node:zlib';
import { execSync } from 'node:child_process';

export async function decodeSessionFile(file) {
  const chunks = [];
  await new Promise((resolve, reject) => {
    const stream = createZstdDecompress();
    stream.on('data', (c) => chunks.push(c));
    stream.on('error', reject);
    stream.on('end', resolve);
    fs.createReadStream(file).pipe(stream);
  });
  return Buffer.concat(chunks).toString('utf8');
}

const root = 'C:/Users/weryu/.dsh/sessions';
if (process.argv[2] === 'find-minimal') {
  // find any session whose header says minimal-*
  for (const group of fs.readdirSync(root)) {
    const gdir = path.join(root, group);
    if (!fs.statSync(gdir).isDirectory()) continue;
    for (const sub of fs.readdirSync(gdir)) {
      const p = path.join(gdir, sub, 'session.jsonl.zstd');
      if (!fs.existsSync(p)) continue;
      try {
        const text = await decodeSessionFile(p);
        const first = text.split('\n').find(Boolean) || '';
        if (first.includes('minimal')) {
          console.log('FOUND', group, sub, 'first:', first.slice(0, 300));
        }
      } catch (e) { /* skip */ }
    }
  }
  console.log('scan done');
}
