<div align="center">

# DeepSeek Harness 数据保险箱（dsh-vault）🛡

[English](./README.md) | **简体中文**

[GitHub](https://github.com/feiyang-dev/dsh-vault) · [npm](https://www.npmjs.com/package/@feiyang666/dsh-vault) · MIT License

**由开发者制作的 DeepSeek Harness 插件** —— 自动备份 → 清空检测 → 一键恢复，把聊天记录、工作区数据、设置与凭据备份到 `~/.dsh` 之外的安全位置。

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Node](https://img.shields.io/badge/node-%3E%3D18-339933)
![Platform](https://img.shields.io/badge/platform-web%20%26%20desktop-4d9fff)

</div>

---

> ## 🔔 重要通知（2026-08-16）：项目已改名
>
> ### 1️⃣ 仓库改名
>
> | | 旧地址 | 新地址（当前） |
> |---|---|---|
> | **GitHub 仓库** | `feiyang-dev/deepseekharnessdesktop-vault` | **`feiyang-dev/dsh-vault`** |
> | **本地 remote** | `https://github.com/feiyang-dev/deepseekharnessdesktop-vault.git` | `https://github.com/feiyang-dev/dsh-vault.git` |
>
> 旧地址会自动 301 重定向到新地址，**star / fork / issue / Release 全部保留**。
> 本地已有 clone 的仓库，只需更新 remote：
>
> ```bash
> git remote set-url origin https://github.com/feiyang-dev/dsh-vault.git
> ```
>
> ### 2️⃣ npm 包名更换
>
> | | 旧包名 | 新包名（当前） |
> |---|---|---|
> | **npm 包** | `@feiyang666/deepseekharnessdesktop-vault` | **`@feiyang666/dsh-vault`** |
>
> - 安装 / 升级请改用新包名：`dsh plugin --profile web add @feiyang666/dsh-vault`
> - 旧包名 `@feiyang666/deepseekharnessdesktop-vault` 仍会保留一段时间，但**不再维护、不会更新**，请尽快迁移
> - 桌面端（[`DeepSeek Harness 桌面版`](https://github.com/feiyang-dev/DeepSeek-Harness-Desktop)）已兼容两种包名，旧包名安装的会**自动识别并升级**到新包名

---

## 简介

DeepSeek Harness 桌面端在检测到插件加载失败时，可能会强制清除 `~/.dsh` 本地数据（聊天记录、工作区数据、设置、凭据、插件配置）并恢复出厂。`dsh-vault` 把全部关键数据持续备份到 **`~/.dsh` 之外**的安全位置，即使数据被清空也能完整找回。

npm 包名：`@feiyang666/dsh-vault`（同项目系列：`@feiyang666/dsh-usage-plugin` 用量插件）。

## 功能

| 能力 | 说明 |
|---|---|
| **设置页「备份管理」** | Web 端设置页新增「备份管理」页面：查看备份状态与历史、立即备份、按范围一键恢复（全部 / 仅聊天记录 / 仅工作区设置）、删除备份（需二次确认） |
| **自动备份** | 只保留三种触发时机（v1.2.2 起）：① 启动备份（正常启动 6 秒后）② 意外关闭备份（上次运行未正常退出，本次启动立即备份）③ 手动备份（设置页 / backup_vault 工具）。不再按会话落盘或定时全量备份，避免大量任务运行时反复复制 `~/.dsh` 导致卡死 |
| **备份内容** | `sessions/`（聊天记录，zstd 二进制完整复制）、`storages/`（工作区数据）、`settings.yaml`、`.credentials.yaml`、`.anonymous-user-id`、`profiles/` 配置（排除可重装的 node_modules）；**若已安装用量插件（dsh-usage-plugin），其用量数据（`usage-records.json` / `pricing.json` 等）会一并备份**，恢复时按原目录还原 |
| **备份位置** | `~/.dsh-backups/<时间戳>/` —— 在 `~/.dsh` 之外，数据清空不会波及；最多保留最近 10 份，旧的自动清理 |
| **清空检测** | 启动时对比备份与当前会话数，数据疑似被清空时红色告警 |
| **一键恢复** | 设置页或 `backup_vault` 工具按范围恢复（全部 / 仅聊天记录 / 仅工作区设置） |
| **恢复脚本** | 生成 `restore-latest.ps1`，退出桌面端后右键运行即可离线还原 |
| **删除备份** | 设置页按名称删除指定备份（二次确认） |

## 推荐安装方式

> 两个方法任选其一，效果等价。**推荐使用桌面端**，全程图形化、无需命令行。

### 方式一（推荐）：桌面端一键安装

安装 [DeepSeek Harness 桌面版](https://github.com/feiyang-dev/DeepSeek-Harness-Desktop)，打开后点击 **「安装插件」→ 推荐插件 → 数据保险箱 → 一键安装**，完成后点 **「立即重启服务」** 即可生效。

### 方式二：命令行安装

```bash
# 前提：已安装 dsh（npm install -g @deepseek-ai/dsh）
dsh plugin --profile web add @feiyang666/dsh-vault
```

本插件是标准 Cordis bundle 插件，通过 npm 安装后挂载到 dsh profile：

```bash
# 1. 安装到 profile（等价于官方 bundle 机制）
npm install --prefix "$HOME/.dsh/profiles/web" @feiyang666/dsh-vault

# 2. 在 profile 的 package.json 中注册 bundle（dsh.vault 行会通过 cordis.patch.yml 自动挂载）
#    也可用你的桌面端插件管理器安装
```

或手动编辑 `~/.dsh/profiles/web/package.json`，在 `dsh.profile.bundles` 中加入 `"@feiyang666/dsh-vault"`。

---

## 使用方式一：设置页「备份管理」（Web 端）

安装并重启后，打开设置 → 「备份管理」：

- 顶部显示备份目录、上次备份时间、备份份数、数据完整性状态
- 「立即备份」按钮手动触发备份
- 「备份历史」列表每项有「恢复」（选择范围：全部/仅聊天记录/仅工作区设置）与「删除」（二次确认）按钮

## 使用方式二：`backup_vault` 工具（TUI / Web 通用）

插件注册模型工具 `backup_vault`，直接对助手说"帮我备份一下 / 查看备份状态 / 从最新备份恢复聊天记录 / 删除那个旧备份"即可：

- `action: status` —— 备份目录、上次备份、备份列表、是否检测到清空
- `action: backup` —— 立即备份
- `action: list` —— 列出全部备份
- `action: restore`（`name` + `scope`: all/sessions/data）—— 恢复
- `action: delete`（`name`）—— 删除备份
- `action: make_script` —— 生成一键恢复脚本

## 手动恢复（桌面端退出后）

1. 找到备份目录 `~/.dsh-backups/`
2. 若已生成 `restore-latest.ps1`，退出桌面端后右键"使用 PowerShell 运行"
3. 或手动把 `backup-<时间戳>/` 下的内容复制回 `~/.dsh/`

## 安全说明

- 备份含 `.credentials.yaml`（API 密钥），请妥善保管备份目录（可复制到加密磁盘/网盘）。
- 恢复会覆盖当前数据，请先确认备份时间点。
- 聊天记录文件在 DSH 运行时可能被占用，恢复聊天记录建议先退出桌面端。

## 相关项目

| 项目 | 说明 | 安装方式 |
| --- | --- | --- |
| [DeepSeek Harness 桌面版](https://github.com/feiyang-dev/DeepSeek-Harness-Desktop) | Windows 桌面控制台：一键安装/启动/停止/重启 dsh web 服务，内置插件管理，**推荐插件区一键安装本插件** | 下载桌面版，点几下即可 |
| [用量与消耗插件（dsh-usage-plugin）](https://github.com/feiyang-dev/dsh-usage-plugin) | 每次调用的 token 用量/缓存命中统计、峰谷计费、余额查询、CSV/JSON/PNG 导出 | 桌面端一键安装，或 `dsh plugin add @feiyang666/dsh-usage-plugin` |
| [DeepSeek-Harness](https://github.com/deepseek-ai/DeepSeek-Harness) | 官方 CLI / Web 服务 | 见下方「运行 DeepSeek Harness」 |

### 运行 DeepSeek Harness

**快速安装（通过 npm）**

安装 Node.js，然后运行：

```bash
npx @deepseek-ai/dsh web
```

该命令会启动 Web UI，默认地址为 http://127.0.0.1:3080。详见 [Web UI 指南](https://github.com/deepseek-ai/DeepSeek-Harness)。

**从源码运行**

如需从仓库源码运行：

```bash
git clone https://github.com/deepseek-ai/deepseek-harness.git
cd deepseek-harness
pnpm install
pnpm run build
pnpm dsh web
```

## License

MIT © dsh-vault
