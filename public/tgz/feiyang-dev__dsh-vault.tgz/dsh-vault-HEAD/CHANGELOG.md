# Changelog

本文件记录 `@feiyang666/dsh-vault` 的版本更新内容。

## 1.5.0 (2026-08-23)

### 新增

- **SSE 实时推送端点**：新增 `GET /api/dsh-vault/events` 事件流端点，备份 / 恢复 / 删除完成时向订阅者推送 `data: {"type":"changed","at":<时间戳>}`。桌面端数据中心等客户端订阅该流即可即时感知备份状态变化，无需轮询。无订阅者时零开销，插件独立使用不受影响。

## 1.4.0 (2026-08-23)

备份范围扩展：用量插件数据一并纳入备份。

### 新增

- **用量数据纳入备份**：备份时自动探测用量插件（`dsh-usage-plugin`）数据目录（`DSH_USAGE_DATA_DIR` > `%LOCALAPPDATA%/dsh-usage-plugin` > `%APPDATA%/dsh-usage-plugin` > `~/dsh-usage-data`），存在则把 `usage-records.json` / `pricing.json` / images 等一并复制进备份的 `usage-plugin/` 子目录。
  - 用量插件未安装 / 数据目录不存在时**静默跳过**，vault 对用量插件零依赖（两者均可独立使用）。
  - 恢复（scope `all` / `data`）与一键恢复脚本 `restore-latest.ps1` 均支持按 manifest 记录的原目录还原用量数据。
  - 备份列表与备份管理页显示「含用量数据」标记。

## 1.3.3 (2026-08-17)

修复备份失败与备份目录错位问题。

### 修复

- **修复「无法定位 DSH_HOME（settings.yaml 未找到）」导致备份失败**
  - `detectDshHome()` 不再依赖 `settings.prepareDocument()`（它会走文件锁 `withFileLock`，若磁盘残留孤儿锁文件 `settings.yaml.lock`，会一直等到锁超时才抛错，导致无法拿到路径）。
  - 改为优先读取 `settings.documentPath`（纯 getter，不触发锁），并新增兜底链路：环境变量 `DSH_HOME` → 操作系统用户主目录 `~/.dsh`，确保任何环境下都能定位到 DSH_HOME。
- **修复备份目录随工作目录漂移导致「备份管理读不到历史数据」**
  - `resolveBackupRoot()` 在 `detectDshHome()` 失败时，不再回退到 `sandboxPolicy.workspaceRoot`（该值在 dsh 官方配置中等同于 dsh 服务工作目录，桌面端可配置后会让备份写到项目目录下的 `.dsh-backups`，与用户主目录 `~/.dsh-backups` 的历史备份错位）。
  - 改为优先回退到操作系统用户主目录 `~/.dsh-backups`，保证备份位置始终与历史备份一致。
- **修复首次写入备份状态标记时报「找不到路径」**
  - `writeFileViaPowershell()` 写入前先用 `New-Item` 确保目标目录存在，避免目标目录尚未创建时 `Set-Content` 抛 `DirectoryNotFoundException`。

## 1.3.2 (2026-08-16)

- 项目改名：npm 包 `@feiyang666/deepseekharnessdesktop-vault` → `@feiyang666/dsh-vault`；GitHub 仓库 `feiyang-dev/deepseekharnessdesktop-vault` → `feiyang-dev/dsh-vault`。
- README 改为英文优先（README.md + README.zh.md），同步更新 dsh-usage-plugin 引用。

## 1.3.1 (2026-08-16)

- README 增加改名公告：旧仓库/旧包名仍保留一段时间，但不再维护，请迁移到新名。

## 1.3.0 (2026-08-16)

- 首版发布至 `@feiyang666/dsh-vault`。
