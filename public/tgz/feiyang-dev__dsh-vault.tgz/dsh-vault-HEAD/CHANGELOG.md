# Changelog

本文件记录 `@feiyang666/dsh-vault` 的版本更新内容。

## 1.6.0 (2026-11-01)

### 性能：增量快照（备份从 ~38 秒降到秒级）

- 以前每次备份都用 robocopy 整目录全量复制（sessions 343 个文件 / 188MB，单次 30~40 秒；10 份备份 ≈ 2GB）。现在与上一份备份逐文件比对（大小 + 修改时间 UTC），未变化的文件用**硬链接**（同卷零字节、毫秒级），只有变化的文件才真正复制；源文件永远是复制而不是链接，所以后续写入不会污染历史备份。
- 实测（252 个文件的样例集）：首次 252 个复制 / 0 个链接；第二次 **0 个复制 / 252 个链接，复制字节数 0**。

### 性能：意外关闭备份不再阻塞启动

- 旧实现 `await runBackup()`，把插件激活整个堵住，dsh 迟迟打印不出访问令牌（用户感知为"启动卡死 40 秒"）。现在改为后台执行，启动立即继续；备份仍在几秒内跑完，数据安全网不变。

### 备份范围扩大

- 新增 `attachments/`（附件与图片，此前完全没备份；本机实测 642 个文件 / 160MB）。
- 新增 home 级文件：`cordis.patch.yml`（优先级最高的配置层）、`cordis.yml`、`settings.yaml.imported`（0.1.7 起旧设置的唯一读取来源）。
- 恢复逻辑同步支持新增项，并逐项确认备份中确实存在才恢复（旧备份缺少的文件不会被覆盖成空文件）。

### 其它

- manifest 增加 `incremental`（基准备份、链接/复制数量、耗时）与 `scopes` 字段，排查"这份备份到底存了什么"更容易。

## 1.5.0 (2026-08-23)

### 新增

- **SSE 实时推送端点**：新增 `GET /api/dsh-vault/events` 事件流端点，备份 / 恢复 / 删除完成时向订阅者推送 `data: {"type":"changed","at":<时间戳>}`。桌面端数据中心等客户端订阅该流即可即时感知备份状态变化，无需轮询。无订阅者时零开销，插件独立使用不受影响。

## 1.4.0 (2026-08-23)

备份范围扩展：用量插件数据一并纳入备份。

### 新增

- **用量数据纳入备份**：备份时自动探测用量插件（`dsh-usage-plugin`）数据目录（`DSH_USAGE_DATA_DIR` > `%LOCALAPPDATA%/dsh-usage-plugin` > `%APPDATA%/dsh-usage-plugin` > `~/dsh-usage-data`），存在则把 `usage-records.json` / `pricing.json` / images 等一并复制进备份的 `usage-plugin/` 子目录。
  - 用量插件未安装 / 数据目录不存在时**静默跳过**，vault 对用量插件零依赖（两者均可独立使用）。
  - 恢复（scope `all` / `data`）与一键恢复脚本 `restore-latest.ps1` 均支持按 manifest 记录的原目录还原用量数据。
  - 备份列表与备份管理页显示「含用量数据」标记。

## 1.3.3 (2026-08-17)

修复备份失败与备份目录错位问题。

### 修复

- **修复「无法定位 DSH_HOME（settings.yaml 未找到）」导致备份失败**
  - `detectDshHome()` 不再依赖 `settings.prepareDocument()`（它会走文件锁 `withFileLock`，若磁盘残留孤儿锁文件 `settings.yaml.lock`，会一直等到锁超时才抛错，导致无法拿到路径）。
  - 改为优先读取 `settings.documentPath`（纯 getter，不触发锁），并新增兜底链路：环境变量 `DSH_HOME` → 操作系统用户主目录 `~/.dsh`，确保任何环境下都能定位到 DSH_HOME。
- **修复备份目录随工作目录漂移导致「备份管理读不到历史数据」**
  - `resolveBackupRoot()` 在 `detectDshHome()` 失败时，不再回退到 `sandboxPolicy.workspaceRoot`（该值在 dsh 官方配置中等同于 dsh 服务工作目录，桌面端可配置后会让备份写到项目目录下的 `.dsh-backups`，与用户主目录 `~/.dsh-backups` 的历史备份错位）。
  - 改为优先回退到操作系统用户主目录 `~/.dsh-backups`，保证备份位置始终与历史备份一致。
- **修复首次写入备份状态标记时报「找不到路径」**
  - `writeFileViaPowershell()` 写入前先用 `New-Item` 确保目标目录存在，避免目标目录尚未创建时 `Set-Content` 抛 `DirectoryNotFoundException`。

## 1.3.2 (2026-08-16)

- 项目改名：npm 包 `@feiyang666/deepseekharnessdesktop-vault` → `@feiyang666/dsh-vault`；GitHub 仓库 `feiyang-dev/deepseekharnessdesktop-vault` → `feiyang-dev/dsh-vault`。
- README 改为英文优先（README.md + README.zh.md），同步更新 dsh-usage-plugin 引用。

## 1.3.1 (2026-08-16)

- README 增加改名公告：旧仓库/旧包名仍保留一段时间，但不再维护，请迁移到新名。

## 1.3.0 (2026-08-16)

- 首版发布至 `@feiyang666/dsh-vault`。
