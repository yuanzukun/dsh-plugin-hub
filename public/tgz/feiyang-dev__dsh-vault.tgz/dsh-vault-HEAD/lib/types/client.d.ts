/**
 * dsh-vault — Client 半
 * 注册设置页「备份管理」页面，通过 fetch 调用 Host 的 /api/dsh-vault。
 */

/** Cordis 插件名（client 半） */
export declare const name: string

/** 插件声明的服务依赖 */
export declare const inject: []

/** Cordis 插件 apply 函数 */
export declare function apply(ctx: unknown): void
