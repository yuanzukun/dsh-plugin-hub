/**
 * dsh-vault — DeepSeek Harness 数据保险箱
 *
 * 纯 Host 插件。注册 `backup_vault` 模型工具并自动备份 ~/.dsh。
 */

/** Cordis 插件名 */
export declare const name: 'dsh-vault'

/** 插件声明的服务依赖（无硬依赖） */
export declare const inject: []

/** Cordis 插件 apply 函数 */
export declare function apply(ctx: unknown): void
