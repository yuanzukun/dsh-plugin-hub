<div align="center">

# DeepSeek Harness Data Vault (dsh-vault) 🛡

**English** · [简体中文](./README.zh.md)

[GitHub](https://github.com/feiyang-dev/dsh-vault) · [npm](https://www.npmjs.com/package/@feiyang666/dsh-vault) · MIT License

**A community plugin for DeepSeek Harness** — auto backup → wipe detection → one-click restore. Backs up chat history, workspace data, settings, and credentials to a safe location outside `~/.dsh`.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Node](https://img.shields.io/badge/node-%3E%3D18-339933)
![Platform](https://img.shields.io/badge/platform-web%20%26%20desktop-4d9fff)

</div>

---

> ## 🔔 Important Notice (2026-08-16): This project has been renamed
>
> ### 1️⃣ Repository renamed
>
> | | Old | New (current) |
> |---|---|---|
> | **GitHub repo** | `feiyang-dev/deepseekharnessdesktop-vault` | **`feiyang-dev/dsh-vault`** |
> | **Local remote** | `https://github.com/feiyang-dev/deepseekharnessdesktop-vault.git` | `https://github.com/feiyang-dev/dsh-vault.git` |
>
> The old URL redirects (301) to the new one automatically. **All stars / forks / issues / releases are preserved.**
> If you already cloned the repo locally, just update the remote:
>
> ```bash
> git remote set-url origin https://github.com/feiyang-dev/dsh-vault.git
> ```
>
> ### 2️⃣ npm package renamed
>
> | | Old package | New package (current) |
> |---|---|---|
> | **npm package** | `@feiyang666/deepseekharnessdesktop-vault` | **`@feiyang666/dsh-vault`** |
>
> - For install / upgrade, use the new package name: `dsh plugin --profile web add @feiyang666/dsh-vault`
> - The old package `@feiyang666/deepseekharnessdesktop-vault` remains published for a while, but it is **no longer maintained and will not receive updates** — please migrate soon.
> - The desktop client ([`DeepSeek Harness Desktop`](https://github.com/feiyang-dev/DeepSeek-Harness-Desktop)) supports both package names and will **auto-detect and upgrade** installs made with the old name.

---

## Overview

When the DeepSeek Harness desktop client detects a plugin load failure, it may force-clear the local `~/.dsh` data (chat history, workspace data, settings, credentials, plugin configs) and restore factory defaults. `dsh-vault` continuously backs up all critical data to a **safe location outside `~/.dsh`**, so your data can be fully recovered even after a wipe.

npm package: `@feiyang666/dsh-vault` (same series as the `@feiyang666/dsh-usage-plugin` usage plugin).

## Features

| Capability | Description |
|---|---|
| **Settings page "Backup Manager"** | Adds a "Backup Manager" page to the Web settings: view backup status and history, back up now, one-click restore by scope (All / Chat history only / Workspace settings only), delete backups (with confirmation) |
| **Automatic backup** | First backup 6s after startup + debounced backup after session writes/settings changes (2 min) + scheduled backup every 15 min |
| **Backup contents** | `sessions/` (chat history, zstd binary full copy), `storages/` (workspace data), `settings.yaml`, `.credentials.yaml`, `.anonymous-user-id`, `profiles/` configs (excluding reinstallable node_modules); **if the usage plugin (dsh-usage-plugin) is installed, its usage data (`usage-records.json` / `pricing.json` etc.) is included** and restored to its original directory |
| **Backup location** | `~/.dsh-backups/<timestamp>/` — outside `~/.dsh`, untouched by data wipes |
| **Wipe detection** | On startup, compares backup vs current session count; red alert when data is suspected wiped |
| **One-click restore** | Settings page or the `backup_vault` tool restores by scope (All / chat history only / workspace settings only) |
| **Restore script** | Generates `restore-latest.ps1`; after quitting the desktop app, right-click to run and restore offline |
| **Delete backups** | Delete a specific backup by name from the settings page (with confirmation) |

## Recommended Installation

> Either method works and is equivalent. **We recommend the desktop app** — fully graphical, no command line needed.

### Option 1 (recommended): One-click via the desktop app

Install [DeepSeek Harness Desktop](https://github.com/feiyang-dev/DeepSeek-Harness-Desktop), open it, then go to **"Install Plugins" → Recommended → Data Vault → Install** and click **"Restart Service Now"** to activate.

### Option 2: Command line

```bash
# Prerequisite: install dsh (npm install -g @deepseek-ai/dsh)
dsh plugin --profile web add @feiyang666/dsh-vault
```

This plugin is a standard Cordis bundle plugin installed via npm and mounted into a dsh profile:

```bash
# 1. Install into the profile (equivalent to the official bundle mechanism)
npm install --prefix "$HOME/.dsh/profiles/web" @feiyang666/dsh-vault

# 2. Register the bundle in the profile's package.json (the dsh.vault row mounts automatically via cordis.patch.yml)
#    Or use your desktop app's plugin manager
```

Or manually edit `~/.dsh/profiles/web/package.json` and add `"@feiyang666/dsh-vault"` to `dsh.profile.bundles`.

---

## Usage 1: Settings page "Backup Manager" (Web)

After installing and restarting, open Settings → "Backup Manager":

- Top shows backup directory, last backup time, backup count, and data-integrity status
- "Back Up Now" button triggers a manual backup
- The "Backup History" list offers "Restore" (scope: All / chat history only / workspace settings only) and "Delete" (with confirmation) per item

## Usage 2: `backup_vault` tool (TUI / Web universal)

The plugin registers the `backup_vault` model tool — just tell the assistant "back me up / check backup status / restore chat history from the latest backup / delete that old backup":

- `action: status` — backup directory, last backup, backup list, whether a wipe was detected
- `action: backup` — back up now
- `action: list` — list all backups
- `action: restore` (`name` + `scope`: all/sessions/data) — restore
- `action: delete` (`name`) — delete a backup
- `action: make_script` — generate a one-click restore script

## Manual restore (after quitting the desktop app)

1. Find the backup directory `~/.dsh-backups/`
2. If `restore-latest.ps1` was generated, quit the desktop app and right-click → "Run with PowerShell"
3. Or manually copy the contents of `backup-<timestamp>/` back into `~/.dsh/`

## Safety notes

- Backups include `.credentials.yaml` (API keys) — keep the backup directory safe (you may copy it to an encrypted disk / cloud drive).
- Restore overwrites current data — confirm the backup time point first.
- Chat-history files may be locked while DSH is running; it's best to quit the desktop app before restoring chat history.

## Related Projects

| Project | Description | Installation |
| --- | --- | --- |
| [DeepSeek Harness Desktop](https://github.com/feiyang-dev/DeepSeek-Harness-Desktop) | Windows desktop console: install/start/stop/restart the dsh web service with one click, built-in plugin management — **install this plugin from its Recommended section** | Download the desktop app and click a few buttons |
| [Usage & Cost Tracker (dsh-usage-plugin)](https://github.com/feiyang-dev/dsh-usage-plugin) | Per-call token/cache-hit stats, peak/off-peak billing, balance query, CSV/JSON/PNG export | One-click from the desktop app, or `dsh plugin add @feiyang666/dsh-usage-plugin` |
| [DeepSeek-Harness](https://github.com/deepseek-ai/DeepSeek-Harness) | Official CLI / Web service | Quick start below |

### Running DeepSeek Harness

**Quick start (via npm)**

Install Node.js, then run:

```bash
npx @deepseek-ai/dsh web
```

This command starts the Web UI at the default address http://127.0.0.1:3080. See the [Web UI Guide](https://github.com/deepseek-ai/DeepSeek-Harness) for details.

**Run from source**

To run from the repository source:

```bash
git clone https://github.com/deepseek-ai/deepseek-harness.git
cd deepseek-harness
pnpm install
pnpm run build
pnpm dsh web
```

## License

MIT © dsh-vault
