#!/usr/bin/env node
// dsh-vault 本地同步脚本（无需发布 NPM / 无需重新安装）。
// 与 dsh-usage-plugin / dsh-mobile-remote 的 sync-to-profile.mjs 一致：
//   已安装的插件实体在 ~/.dsh/profiles/<profile>/node_modules/@feiyang666/dsh-vault/
//   - lib/client.js（前端 UI）：dsh 的 /plugins/<id>/client.js 每次实时读文件
//     → 同步后刷新浏览器页面即生效，无需重启。
//   - lib/index.js（host 侧，备份逻辑所在）：运行在 dsh 的 Node 进程内，有模块缓存，
//     且 HMR 默认忽略 node_modules → 同步后必须重启 dsh 服务才生效。
//
// 用法：
//   node sync-to-profile.mjs                    # 同步到默认 profile（web）
//   DSH_PROFILE=desktop node sync-to-profile.mjs
//   DSH_HOME=D:/some/.dsh node sync-to-profile.mjs
import { homedir } from 'node:os'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { existsSync, mkdirSync, copyFileSync, readdirSync, readFileSync } from 'node:fs'

const here = dirname(fileURLToPath(import.meta.url))
const pkg = JSON.parse(readFileSync(join(here, 'package.json'), 'utf8'))
const profile = process.env.DSH_PROFILE || 'web'
const home = process.env.DSH_HOME || join(homedir(), '.dsh')
const target = join(home, 'profiles', profile, 'node_modules', '@feiyang666', String(pkg.name).split('/').pop())

if (!existsSync(target)) {
  console.error(`[同步失败] 未找到已安装的插件目录：${target}`)
  console.error('请先在桌面端「插件管理」安装一次 @feiyang666/dsh-vault，或在 CLI 中：')
  console.error(`  dsh plugin --profile ${profile} add @feiyang666/dsh-vault`)
  process.exit(1)
}

const libFiles = readdirSync(join(here, 'lib')).filter((f) => f.endsWith('.js'))
const FILES = [
  ...libFiles.map((f) => join('lib', f)),
  ...(existsSync(join(here, 'lib', 'types')) ? readdirSync(join(here, 'lib', 'types')).filter((f) => f.endsWith('.d.ts')).map((f) => join('lib', 'types', f)) : []),
  'cordis.patch.yml',
  'package.json',
  'README.md',
  'README.zh.md',
  'CHANGELOG.md',
]

let copied = 0
for (const rel of FILES) {
  const src = join(here, rel)
  if (!existsSync(src)) {
    console.warn(`  [跳过] 本地不存在：${rel}`)
    continue
  }
  const dst = join(target, rel)
  mkdirSync(dirname(dst), { recursive: true })
  copyFileSync(src, dst)
  console.log(`  ✓ ${rel}`)
  copied += 1
}

console.log(`\n已同步 ${copied} 个文件到：${target}`)
console.log(`插件版本：${pkg.version}`)
console.log('')
console.log('接下来按改动范围处理：')
console.log('  1. 只改了 lib/client.js（前端 UI）→ 刷新浏览器页面即生效。')
console.log('  2. 改了 lib/index.js（host 侧，备份逻辑）→ 必须重启 dsh 服务（桌面端「停止」再「启动」）。')
