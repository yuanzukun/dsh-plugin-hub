// @vitest-environment jsdom
/** Sprite overlay slot registration, its derived work-state source, and the selection toolbar wiring. */
import { Context } from '@deepseek-ai/cordis';
import { describe, expect, it, vi } from 'vitest';
import type { SelectionToolbarInjected, SpriteMascotInjected } from '../src/client/index.ts';

// Client bundles self-register into the module-loader registry and export
// nothing through CJS, so their APIs are retrieved through the loader after
// the registry-backed require pulls them in (see tests/setup.ts).
// biome-ignore lint/suspicious/noExplicitAny: the loader global is host-injected and untyped.
const loader = (window as any).__ModuleLoader__ as { require: (id: string) => unknown };
const { SlotRegistry } = loader.require(
  '@deepseek-ai/dsh-client-runtime/client',
) as typeof import('@deepseek-ai/dsh-client-runtime/client');
const { LocaleRuntime } = loader.require(
  '@deepseek-ai/dsh-client-locale/client',
) as typeof import('@deepseek-ai/dsh-client-locale/client');
const { apply, DEFAULT_VEIL, inject } = loader.require(
  '@wangjunjian/dsh-spritely/client',
) as typeof import('@wangjunjian/dsh-spritely/client');

async function bench(declare = true) {
  const ctx = new Context();
  await ctx.plugin(SlotRegistry).await();
  const draftBox = { draft: '' };
  const input = {
    state: { getSnapshot: () => ({ draft: draftBox.draft }) },
    setDraft: vi.fn((text: string) => {
      draftBox.draft = text;
    }),
  };
  const conversation = { input: { for: () => input } };
  const actx = { get: (name: string) => (name === 'conversation' ? conversation : undefined) };
  const sessions = {
    list: {
      getSnapshot: () => ({
        ids: [],
        byId: {},
        current: 's1',
        phase: 'ready',
        subagentsByParent: {},
        jobsBySession: {},
        currentAddress: undefined,
      }),
      subscribe: () => () => {},
    },
    binding: () => undefined,
    scope: (id: unknown) => (id === 's1' ? actx : undefined),
  };
  const workspaces = { startSession: vi.fn() };
  // Settings transport fakes: the bound scope stays unavailable (memory mode),
  // so the sync bridge is silent and the sources behave localStorage-only.
  const settingsScope = {
    bind: () => ({
      getSnapshot: () => ({
        status: 'unavailable',
        value: undefined,
        base: undefined,
        user: undefined,
        revision: undefined,
        writable: false,
        mode: 'memory',
      }),
      subscribe: () => () => {},
      set: () => Promise.resolve(),
      unset: () => Promise.resolve(),
    }),
  };
  ctx.provide('sessions', sessions as never);
  ctx.provide('workspaces', workspaces as never);
  ctx.provide('conversation', conversation as never);
  ctx.provide('connection', {} as never);
  ctx.provide('remote', {} as never);
  ctx.provide('settingsScope', settingsScope as never);
  ctx.provide('locale', new LocaleRuntime(ctx));
  const slots = ctx.get('slots') as SlotRegistry;
  if (declare) {
    slots.register(
      { name: 'root', children: { 'shell.overlay': { kind: 'list', scope: 'root' } } } as never,
      () => null,
    );
  }
  return { ctx, slots, workspaces, input, draftBox };
}

describe('ui-sprite apply', () => {
  it('declares only the services it uses', () => {
    expect(inject).toEqual([
      'slots',
      'sessions',
      'workspaces',
      'locale',
      'conversation',
      'connection',
      'remote',
      'settingsScope',
    ]);
  });

  it('registers the mascot into the overlay slot with its work-state source and New Session action', async () => {
    const b = await bench();
    await b.ctx.plugin({ inject: [...inject], apply }).await();
    const entries = b.slots.entries('shell.overlay');
    expect(entries.map((entry) => entry.options.id)).toEqual(['sprite', 'selection-toolbar']);
    expect(entries[0]!.locale).toBe('sprite');

    // Slot entries' `inject` is typed as `(...args: never[]) => Record<string, unknown>`
    // (the registrant contract); narrow through `unknown` to our concrete face.
    const injected = (entries[0]!.inject as unknown as () => SpriteMascotInjected)();
    expect(Object.keys(injected)).toEqual(['hooks', 'startSession', 'setBackground', 'setSpriteKind', 'setPosition']);
    expect(typeof injected.hooks.sprite.getSnapshot).toBe('function');
    expect(typeof injected.hooks.sprite.subscribe).toBe('function');
    expect(injected.hooks.sprite.getSnapshot()).toEqual({ activity: 'idle', toolName: undefined });
    // The background source starts null (follow the theme) and flips on set.
    expect(typeof injected.hooks.background.getSnapshot).toBe('function');
    expect(injected.hooks.background.getSnapshot()).toBeNull();
    injected.setBackground({ kind: 'color', value: '#EAF3FB', fit: 'contain', veil: DEFAULT_VEIL });
    expect(injected.hooks.background.getSnapshot()).toEqual({
      kind: 'color',
      value: '#EAF3FB',
      fit: 'contain',
      veil: DEFAULT_VEIL,
    });
    // The mascot-kind source starts as blob and flips on set.
    expect(injected.hooks.spriteKind.getSnapshot()).toBe('blob');
    injected.setSpriteKind('cat');
    expect(injected.hooks.spriteKind.getSnapshot()).toBe('cat');
    // New Session delegates to the workspaces service's default-workspace flow.
    injected.startSession();
    expect(b.workspaces.startSession).toHaveBeenCalledWith();
  });

  it('registers the selection toolbar with a quote-and-ask action targeting the composer draft', async () => {
    const b = await bench();
    await b.ctx.plugin({ inject: [...inject], apply }).await();
    const entries = b.slots.entries('shell.overlay');
    const toolbar = entries.find((entry) => entry.options.id === 'selection-toolbar');
    expect(toolbar).toBeDefined();
    expect(toolbar!.locale).toBe('sprite');

    const injected = (toolbar!.inject as unknown as () => SelectionToolbarInjected)();
    expect(Object.keys(injected)).toEqual(['hooks', 'quoteAsk']);
    expect(injected.hooks.selection.getSnapshot()).toBeNull();
    // Quote-and-ask appends a Markdown quote block to the current draft.
    injected.quoteAsk('hello');
    expect(b.input.setDraft).toHaveBeenCalledWith('> hello\n\n');
    expect(b.draftBox.draft).toBe('> hello\n\n');
    // With an existing draft, the quote lands after a blank line.
    injected.quoteAsk('again');
    expect(b.draftBox.draft).toBe('> hello\n\n> again\n\n');
  });

  it('waits for the overlay declaration instead of failing when it is absent', async () => {
    const b = await bench(false);
    await expect(b.ctx.plugin({ inject: [...inject], apply }).await()).resolves.toBeDefined();
    expect(b.slots.entries('shell.overlay')).toHaveLength(0);
  });

  it('removes both entries on teardown', async () => {
    const b = await bench();
    const fiber = b.ctx.plugin({ inject: [...inject], apply });
    await fiber.await();
    expect(b.slots.entries('shell.overlay')).toHaveLength(2);
    await fiber.dispose();
    expect(b.slots.entries('shell.overlay')).toHaveLength(0);
  });
});
