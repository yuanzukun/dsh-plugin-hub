import { Context } from '@deepseek-ai/cordis';
import InvariantRegistry from '@deepseek-ai/dsh-invariants';
import * as SpriteInvariant from '@wangjunjian/dsh-spritely/invariant';
import { describe, expect, it, vi } from 'vitest';

describe('invariant companion', () => {
  it('registers under the package name with an empty installer', async () => {
    const ctx = new Context();
    await ctx.plugin(InvariantRegistry, { enabled: true });
    await expect(ctx.plugin(SpriteInvariant).await()).resolves.toBeDefined();
  });

  it('node-half apply registers the ui-sprite settings namespace when the service is composed', async () => {
    const { apply } = await import('@wangjunjian/dsh-spritely');
    const ctx = new Context();
    const register = vi.fn();
    ctx.provide('settings', { register } as never);
    await ctx.plugin({ apply }).await();
    expect(register).toHaveBeenCalledWith('ui-sprite', expect.anything());
  });

  it('node-half apply still loads without a settings provider (localStorage fallback path)', async () => {
    const { apply } = await import('@wangjunjian/dsh-spritely');
    const ctx = new Context();
    await expect(ctx.plugin({ apply }).await()).resolves.toBeDefined();
  });
});
