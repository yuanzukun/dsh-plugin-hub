// @vitest-environment jsdom
/** The settings-sync bridge: localStorage sources kept in step with the Host settings scope. */

import type { SettingsScope, SettingsScopeSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import { afterEach, describe, expect, it, vi } from 'vitest';

/** Minimal in-memory snapshot store with localStorage persistence. */
function createSnapshotStore<T>(
  initial: T,
  options?: { persist?: { name: string } },
): {
  getSnapshot: () => T;
  subscribe: (fn: () => void) => () => void;
  set: (value: T) => void;
} {
  const key = options?.persist?.name;
  const stored = key ? localStorage.getItem(key) : null;
  let current: T = stored !== null ? JSON.parse(stored) : initial;
  const listeners = new Set<() => void>();
  return {
    getSnapshot: () => current,
    subscribe: (fn) => {
      listeners.add(fn);
      return () => {
        listeners.delete(fn);
      };
    },
    set: (value) => {
      current = value;
      if (key) localStorage.setItem(key, JSON.stringify(value));
      for (const fn of [...listeners]) fn();
    },
  };
}

vi.mock('@deepseek-ai/dsh-client-runtime/client', () => ({
  createSnapshotStore,
}));

import { type BackgroundState, createBackgroundSource, DEFAULT_VEIL } from '../src/client/background-source.ts';
import { SpriteSettingsSync } from '../src/client/settings-sync.ts';
import { createSpriteKindSource } from '../src/client/sprite-kind-source.ts';
import { createSpritePositionSource, type SpritePosition } from '../src/client/sprite-position-source.ts';
import type { SpritelySettings } from '../src/settings.ts';

/** Fake settings scope with a mutable snapshot and recorded writes. */
class FakeScope implements SettingsScope<SpritelySettings> {
  private readonly listeners = new Set<() => void>();
  readonly set = vi.fn((_field: string, _value: unknown) => Promise.resolve());
  readonly unset = vi.fn((_field: string) => Promise.resolve());

  constructor(private snapshot: SettingsScopeSnapshot<SpritelySettings>) {}

  getSnapshot(): SettingsScopeSnapshot<SpritelySettings> {
    return this.snapshot;
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  /** Simulate a Host-side document change reaching the browser. */
  update(snapshot: SettingsScopeSnapshot<SpritelySettings>): void {
    this.snapshot = snapshot;
    for (const fn of [...this.listeners]) fn();
  }
}

/** Build a scope snapshot; defaults to a writable host-mode ready section. */
function snapshot(
  overrides: Partial<SettingsScopeSnapshot<SpritelySettings>> = {},
): SettingsScopeSnapshot<SpritelySettings> {
  return {
    status: 'ready',
    value: { character: 'blob', position: null, background: null },
    base: undefined,
    user: undefined,
    revision: 1,
    writable: true,
    mode: 'host',
    ...overrides,
  };
}

/** Fresh sources over a clean localStorage. */
function sources() {
  return {
    spriteKind: createSpriteKindSource(),
    position: createSpritePositionSource(),
    background: createBackgroundSource(),
  };
}

function color(value: string): BackgroundState {
  return { kind: 'color', value, fit: 'contain', veil: DEFAULT_VEIL };
}

const POSITION: SpritePosition = { x: 24, y: 48 };

afterEach(() => {
  localStorage.clear();
});

describe('SpriteSettingsSync', () => {
  it('adopts host values for the fields the user layer holds', () => {
    const local = sources();
    local.spriteKind.set('cat');
    local.background.set(color('#EAF3FB'));
    const scope = new FakeScope(
      snapshot({
        value: { character: 'ghost', position: POSITION, background: null },
        user: { character: 'ghost', position: POSITION },
      }),
    );
    new SpriteSettingsSync(scope, local);
    // Held fields are overwritten by the Host document...
    expect(local.spriteKind.getSnapshot()).toBe('ghost');
    expect(local.position.getSnapshot()).toEqual(POSITION);
    // ...and fields outside the user layer keep their local value.
    expect(local.background.getSnapshot()).toEqual(color('#EAF3FB'));
    // Adoption never writes back (no echo loop).
    expect(scope.set).not.toHaveBeenCalled();
  });

  it('migrates local values into a fresh host namespace once', () => {
    const local = sources();
    local.spriteKind.set('cat');
    local.position.set(POSITION);
    local.background.set(color('#EAF3FB'));
    const scope = new FakeScope(snapshot());
    new SpriteSettingsSync(scope, local);
    expect(scope.set.mock.calls).toEqual([
      ['character', 'cat'],
      ['position', POSITION],
      ['background', color('#EAF3FB')],
    ]);
    // A later snapshot without a user layer does not re-migrate.
    scope.update(snapshot({ revision: 2 }));
    expect(scope.set).toHaveBeenCalledTimes(3);
  });

  it('migrates only the character when position and background are unset locally', () => {
    const scope = new FakeScope(snapshot());
    new SpriteSettingsSync(scope, sources());
    expect(scope.set.mock.calls).toEqual([['character', 'blob']]);
  });

  it('dual-writes user choices to the local source and the host document', () => {
    const local = sources();
    const scope = new FakeScope(snapshot({ user: { character: 'blob' } }));
    const sync = new SpriteSettingsSync(scope, local);
    sync.setCharacter('bot');
    expect(local.spriteKind.getSnapshot()).toBe('bot');
    expect(scope.set).toHaveBeenCalledWith('character', 'bot');
    sync.setPosition(POSITION);
    expect(local.position.getSnapshot()).toEqual(POSITION);
    expect(scope.set).toHaveBeenCalledWith('position', POSITION);
    sync.setBackground(color('#0B1F2A'));
    expect(local.background.getSnapshot()).toEqual(color('#0B1F2A'));
    expect(scope.set).toHaveBeenCalledWith('background', color('#0B1F2A'));
  });

  it('stays local-only in memory mode (non-loopback browser)', () => {
    const local = sources();
    const scope = new FakeScope(snapshot({ status: 'unavailable', value: undefined, writable: false, mode: 'memory' }));
    const sync = new SpriteSettingsSync(scope, local);
    sync.setCharacter('ghost');
    sync.setBackground(color('#EAF3FB'));
    expect(local.spriteKind.getSnapshot()).toBe('ghost');
    expect(local.background.getSnapshot()).toEqual(color('#EAF3FB'));
    expect(scope.set).not.toHaveBeenCalled();
  });

  it('follows later host changes (another browser or a settings.yaml edit)', () => {
    const local = sources();
    const scope = new FakeScope(snapshot({ user: { character: 'blob' } }));
    new SpriteSettingsSync(scope, local);
    scope.update(
      snapshot({
        value: { character: 'cat', position: POSITION, background: color('#0B1F2A') },
        user: { character: 'cat', position: POSITION, background: color('#0B1F2A') },
        revision: 2,
      }),
    );
    expect(local.spriteKind.getSnapshot()).toBe('cat');
    expect(local.position.getSnapshot()).toEqual(POSITION);
    expect(local.background.getSnapshot()).toEqual(color('#0B1F2A'));
    expect(scope.set).not.toHaveBeenCalled();
  });

  it('stops observing the scope after dispose', () => {
    const local = sources();
    const scope = new FakeScope(snapshot({ user: { character: 'blob' } }));
    const sync = new SpriteSettingsSync(scope, local);
    sync.dispose();
    scope.update(
      snapshot({ value: { character: 'cat', position: null, background: null }, user: { character: 'cat' } }),
    );
    expect(local.spriteKind.getSnapshot()).toBe('blob');
  });
});
