// @vitest-environment jsdom
/** Selection toolbar: quote formatting, component actions, and the selection controller. */

import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
import { act, cleanup, fireEvent, render, screen } from '@testing-library/react';
import { useSyncExternalStore } from 'react';
import { afterEach, describe, expect, it, vi } from 'vitest';

/** Minimal in-memory snapshot store used by the toolbar fixtures. */
function createSnapshotStore<T>(initial: T): {
  getSnapshot: () => T;
  subscribe: (fn: () => void) => () => void;
  set: (value: T) => void;
} {
  let current: T = initial;
  const listeners = new Set<() => void>();
  return {
    getSnapshot: () => current,
    subscribe: (fn) => {
      listeners.add(fn);
      return () => {
        listeners.delete(fn);
      };
    },
    set: (value) => {
      current = value;
      for (const fn of [...listeners]) fn();
    },
  };
}

vi.mock('@deepseek-ai/dsh-client-runtime/client', () => ({
  createSnapshotStore,
}));

// biome-ignore lint/correctness/noUnusedImports: forces the mocked module to load so dependent imports below resolve to the mock.
import { createSnapshotStore as _ } from '@deepseek-ai/dsh-client-runtime/client';
import { zh } from '../src/client/locales.ts';
import { SelectionToolbar } from '../src/client/SelectionToolbar.tsx';
import { createSelectionSource, formatQuote, type SelectionState } from '../src/client/selection-toolbar.ts';

const t = (key: string): string => (zh as Record<string, string>)[key] ?? key;

// The toolbar never reads the global hooks; stub them as never-called.
const neverHook = (() => {
  throw new Error('toolbar must not read global hooks');
}) as never;

afterEach(() => {
  cleanup();
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  document.body.innerHTML = '';
});

describe('formatQuote', () => {
  it('quotes a single line and leaves an empty line for the question', () => {
    expect(formatQuote('hello')).toBe('> hello\n\n');
  });

  it('quotes every line of a multi-line selection', () => {
    expect(formatQuote('a\nb\nc')).toBe('> a\n> b\n> c\n\n');
  });

  it('trims surrounding whitespace before quoting', () => {
    expect(formatQuote('  padded  \n')).toBe('> padded\n\n');
  });
});

function mountToolbar(initial: SelectionState | null) {
  const store = createSnapshotStore<SelectionState | null>(initial);
  const useSelection: SnapshotSelectorHook<SelectionState | null> = <S,>(sel: (s: SelectionState | null) => S): S => {
    const snap = useSyncExternalStore(store.subscribe, store.getSnapshot);
    return sel(snap);
  };
  const quoteAsk = vi.fn();
  render(
    <SelectionToolbar
      useSelection={useSelection}
      useSessions={neverHook}
      useWorkspaces={neverHook}
      quoteAsk={quoteAsk}
      t={t}
    />,
  );
  return { store, quoteAsk };
}

const SELECTION: SelectionState = {
  text: 'selected text',
  rect: { top: 200, left: 100, width: 80, height: 16 },
  pointer: null,
};

describe('SelectionToolbar', () => {
  it('renders nothing while no selection is active', () => {
    mountToolbar(null);
    expect(screen.queryByRole('toolbar')).toBeNull();
  });

  it('anchors at the pointer release point when present, else the rect center', () => {
    mountToolbar({ ...SELECTION, pointer: { x: 300, y: 240 } });
    const atPointer = screen.getByRole('toolbar');
    expect(atPointer.getAttribute('style')).toContain('left: 300px');
    expect(atPointer.getAttribute('style')).toContain('top: 232px');
    expect(atPointer.getAttribute('style')).toContain('translate(-50%, -100%)');

    cleanup();
    mountToolbar(SELECTION);
    const atRect = screen.getByRole('toolbar');
    expect(atRect.getAttribute('style')).toContain('left: 140px');
    expect(atRect.getAttribute('style')).toContain('top: 192px');
  });

  it('shows copy, read-aloud, and ask actions for an active selection', () => {
    mountToolbar(SELECTION);
    expect(screen.getByRole('toolbar', { name: '选区操作' })).toBeTruthy();
    expect(screen.getByRole('button', { name: '复制' })).toBeTruthy();
    expect(screen.getByRole('button', { name: '朗读' })).toBeTruthy();
    expect(screen.getByRole('button', { name: '提问' })).toBeTruthy();
  });

  it('copies the selected text and flashes a confirmation', () => {
    vi.useFakeTimers();
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, 'clipboard', { value: { writeText }, configurable: true });
    mountToolbar(SELECTION);
    fireEvent.click(screen.getByRole('button', { name: '复制' }));
    expect(writeText).toHaveBeenCalledWith('selected text');
    expect(screen.getByRole('button', { name: '已复制' })).toBeTruthy();
    act(() => {
      vi.advanceTimersByTime(1300);
    });
    expect(screen.getByRole('button', { name: '复制' })).toBeTruthy();
  });

  it('delegates ask to the inject face with the selected text', () => {
    const { quoteAsk } = mountToolbar(SELECTION);
    fireEvent.click(screen.getByRole('button', { name: '提问' }));
    expect(quoteAsk).toHaveBeenCalledWith('selected text');
  });

  it('toggles read-aloud through speechSynthesis', () => {
    const speak = vi.fn((utterance: { onend?: () => void }) => utterance);
    const cancel = vi.fn();
    vi.stubGlobal('speechSynthesis', { speak, cancel });
    vi.stubGlobal(
      'SpeechSynthesisUtterance',
      class {
        onend: (() => void) | null = null;
        onerror: (() => void) | null = null;
        constructor(public text: string) {}
      },
    );
    mountToolbar(SELECTION);
    fireEvent.click(screen.getByRole('button', { name: '朗读' }));
    expect(speak).toHaveBeenCalledOnce();
    expect(screen.getByRole('button', { name: '停止' })).toBeTruthy();
    fireEvent.click(screen.getByRole('button', { name: '停止' }));
    expect(cancel).toHaveBeenCalled();
    expect(screen.getByRole('button', { name: '朗读' })).toBeTruthy();
  });
});

/** A conversation-flow text node plus a fake Selection pointing at it; `box` is mutable so scroll tests can move it. */
function fakeSelection(text: string, insideFlow: boolean, box = { top: 10, left: 10, width: 50, height: 12 }) {
  const host = document.createElement('div');
  if (insideFlow) host.setAttribute('data-chat-flow', '');
  const paragraph = document.createElement('p');
  paragraph.textContent = text;
  host.appendChild(paragraph);
  document.body.appendChild(host);
  const node = paragraph.firstChild as Node;
  return {
    isCollapsed: false,
    rangeCount: 1,
    toString: () => text,
    getRangeAt: () => ({
      commonAncestorContainer: node,
      getBoundingClientRect: () => ({ ...box }),
    }),
  };
}

describe('createSelectionSource', () => {
  it('publishes the selection after the debounce when it lives in the chat flow', () => {
    vi.useFakeTimers();
    vi.spyOn(document, 'getSelection').mockReturnValue(fakeSelection('hello flow', true) as never);
    const source = createSelectionSource();
    document.dispatchEvent(new Event('selectionchange'));
    expect(source.getSnapshot()).toBeNull();
    vi.advanceTimersByTime(150);
    expect(source.getSnapshot()?.text).toBe('hello flow');
    // Keyboard-driven selection carries no pointer anchor.
    expect(source.getSnapshot()?.pointer).toBeNull();
    source.dispose();
  });

  it('records the pointer release point for mouse-made selections', () => {
    vi.useFakeTimers();
    vi.spyOn(document, 'getSelection').mockReturnValue(fakeSelection('hello flow', true) as never);
    const source = createSelectionSource();
    document.body.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true }));
    document.body.dispatchEvent(new MouseEvent('pointerup', { bubbles: true, clientX: 222, clientY: 333 }));
    vi.advanceTimersByTime(150);
    expect(source.getSnapshot()?.pointer).toEqual({ x: 222, y: 333 });
    source.dispose();
  });

  it('stays null for selections outside the chat flow', () => {
    vi.useFakeTimers();
    vi.spyOn(document, 'getSelection').mockReturnValue(fakeSelection('sidebar text', false) as never);
    const source = createSelectionSource();
    document.dispatchEvent(new Event('selectionchange'));
    vi.advanceTimersByTime(150);
    expect(source.getSnapshot()).toBeNull();
    source.dispose();
  });

  it('hides on outside pointerdown but not on toolbar pointerdown', () => {
    vi.useFakeTimers();
    vi.spyOn(document, 'getSelection').mockReturnValue(fakeSelection('hello flow', true) as never);
    const source = createSelectionSource();
    document.dispatchEvent(new Event('selectionchange'));
    vi.advanceTimersByTime(150);
    expect(source.getSnapshot()).not.toBeNull();

    const toolbar = document.createElement('div');
    toolbar.setAttribute('data-spritely-selection-toolbar', '');
    document.body.appendChild(toolbar);
    toolbar.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true }));
    expect(source.getSnapshot()).not.toBeNull();

    document.body.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true }));
    expect(source.getSnapshot()).toBeNull();
    source.dispose();
  });

  it('dismisses on Escape and keeps the same selection suppressed', () => {
    vi.useFakeTimers();
    vi.spyOn(document, 'getSelection').mockReturnValue(fakeSelection('hello flow', true) as never);
    const source = createSelectionSource();
    document.dispatchEvent(new Event('selectionchange'));
    vi.advanceTimersByTime(150);
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
    expect(source.getSnapshot()).toBeNull();

    // Scrolling or re-firing selectionchange must not resurrect a dismissed selection.
    document.dispatchEvent(new Event('scroll'));
    document.dispatchEvent(new Event('selectionchange'));
    vi.advanceTimersByTime(150);
    expect(source.getSnapshot()).toBeNull();
    source.dispose();
  });

  it('follows the live selection rect on scroll instead of hiding', () => {
    vi.useFakeTimers();
    const box = { top: 10, left: 10, width: 50, height: 12 };
    vi.spyOn(document, 'getSelection').mockReturnValue(fakeSelection('hello flow', true, box) as never);
    const source = createSelectionSource();
    document.dispatchEvent(new Event('selectionchange'));
    vi.advanceTimersByTime(150);
    expect(source.getSnapshot()?.rect.top).toBe(10);

    box.top = 400;
    document.dispatchEvent(new Event('scroll'));
    expect(source.getSnapshot()?.rect.top).toBe(400);
    expect(source.getSnapshot()?.pointer).toBeNull();
    source.dispose();
  });

  it('does not re-anchor when a toolbar button is pressed', () => {
    vi.useFakeTimers();
    vi.spyOn(document, 'getSelection').mockReturnValue(fakeSelection('hello flow', true) as never);
    const source = createSelectionSource();
    document.dispatchEvent(new Event('selectionchange'));
    vi.advanceTimersByTime(150);
    const shown = source.getSnapshot();
    expect(shown).not.toBeNull();

    const toolbar = document.createElement('div');
    toolbar.setAttribute('data-spritely-selection-toolbar', '');
    document.body.appendChild(toolbar);
    toolbar.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true }));
    toolbar.dispatchEvent(new MouseEvent('pointerup', { bubbles: true, clientX: 500, clientY: 600 }));
    vi.advanceTimersByTime(150);
    expect(source.getSnapshot()).toBe(shown);
    source.dispose();
  });
});
