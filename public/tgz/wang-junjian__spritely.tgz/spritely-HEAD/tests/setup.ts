/**
 * Polyfill the dsh client module loader for unit tests.
 *
 * The `@deepseek-ai/dsh-client-runtime/client` and sibling client bundles are
 * shipped as CJS artifacts that self-register through
 * `window.__ModuleLoader__.load(...)`. The real loader is injected by the dsh
 * host in the browser; tests need a minimal stand-in so these modules can be
 * imported under jsdom/Node. Their exports live in the loader registry only
 * (the file's own CJS exports stay empty), so tests retrieve them through
 * `window.__ModuleLoader__.require(specifier)` after a side-effect import.
 */
import { createRequire } from 'node:module';

export function setupModuleLoader(): void {
  if (typeof window === 'undefined') return;
  const nodeRequire = createRequire(import.meta.url);
  const modules = new Map<string, unknown>();
  // Bundles register with their package id; imports spell the `/client` subpath.
  const normalize = (id: string): string => (id.endsWith('/client') ? id.slice(0, -'/client'.length) : id);
  const requireFn = (depId: string): unknown => {
    const key = normalize(depId);
    if (modules.has(key)) return modules.get(key);
    // Fallback to Node's resolver for external packages (e.g. @deepseek-ai/cordis, react).
    // Loader bundles self-register as a side effect and export nothing themselves.
    try {
      const loaded = nodeRequire(depId);
      if (modules.has(key)) return modules.get(key);
      return loaded;
    } catch {
      return undefined;
    }
  };
  // biome-ignore lint/suspicious/noExplicitAny: the loader global is host-injected and untyped.
  (window as any).__ModuleLoader__ = {
    load: ({ id, factory }: { id: string; factory: (require: (id: string) => unknown) => unknown }): void => {
      modules.set(normalize(id), factory(requireFn));
    },
    require: requireFn,
  };
}

setupModuleLoader();
