/** Host loader entry for the sprite plugin: registers the durable settings namespace. */

import type { Context } from '@deepseek-ai/cordis';
import { settingsNamespace } from '@deepseek-ai/dsh-settings';
import { SPRITELY_SETTINGS_NAMESPACE, SpritelySettingsSchema } from './settings.ts';

/**
 * Register the durable sprite section when the optional settings service is
 * composed, so every loopback browser shares the mascot preferences (the web
 * client syncs them through its settings scope). Without a provider the
 * plugin still loads and the client falls back to localStorage.
 * @param ctx - Host context that may acquire the settings service.
 */
export function apply(ctx: Context): void {
  ctx.inject(['settings'], (settingsCtx) => {
    settingsCtx.settings.register(settingsNamespace(SPRITELY_SETTINGS_NAMESPACE), SpritelySettingsSchema);
  });
}
