/** Registers the floating mascot and the selection toolbar into the layout-owned overlay slot. */

// Type-only: pulls the locale plugin's Context merge (ctx.locale).
import type {} from '@deepseek-ai/dsh-client-locale/client';
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client';
// Type-only: the ctx.settingsScope Context merge. Cross-plugin collaboration
// goes through the service, never a value import (client bundle purity gate).
import type {} from '@deepseek-ai/dsh-client-ui-settings/client';
import { SPRITELY_SETTINGS_NAMESPACE, type SpritelySettings } from '../settings.ts';
import { BackgroundPresenter, createBackgroundSource } from './background-source.ts';
import { en, type SpriteKey, zh } from './locales.ts';
import { SelectionToolbar, type SelectionToolbarInjected } from './SelectionToolbar.tsx';
import { SpriteMascot, type SpriteMascotInjected } from './SpriteMascot.tsx';
import { createSelectionSource, formatQuote } from './selection-toolbar.ts';
import { SpriteSettingsSync } from './settings-sync.ts';
import { createSpriteKindSource } from './sprite-kind-source.ts';
import { createSpritePositionSource } from './sprite-position-source.ts';
import { createSpriteStateSource } from './sprite-state.ts';

export {
  type BackgroundKind,
  type BackgroundSource,
  type BackgroundState,
  DEFAULT_VEIL,
  type ImageFit,
} from './background-source.ts';
export type { SpriteKey } from './locales.ts';
export type { SelectionToolbarInjected, SelectionToolbarProps } from './SelectionToolbar.tsx';
export type { SpriteMascotInjected, SpriteMascotProps } from './SpriteMascot.tsx';
export {
  createSelectionSource,
  formatQuote,
  type SelectionSource,
  type SelectionState,
} from './selection-toolbar.ts';
export { type SpriteSettingsSources, SpriteSettingsSync } from './settings-sync.ts';
export type { SpriteKindSource } from './sprite-kind-source.ts';
export {
  createSpritePositionSource,
  type SpritePosition,
  type SpritePositionSource,
} from './sprite-position-source.ts';
export type { SpriteActivity, SpriteState } from './sprite-state.ts';
export { type Gaze, type Pose, SPRITE_KINDS, type SpriteKind, type SpriteKindMeta } from './sprites.tsx';

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The mascot's status copy. */
    sprite: SpriteKey;
  }
}

/** Dictionary namespace owned by this plugin. */
const NS = 'sprite';

/** Composer textarea anchor (ui-conversation's InputBar), focused after a quote-and-ask. */
const COMPOSER_TEXTAREA_SELECTOR = '[data-composer-card] textarea';

/**
 * Services required by the sprite plugin. `connection`/`remote`/`settingsScope`
 * carry the settings transport: the scope's invalidation subscription rides the
 * forwarded `settings/document-updated` event, and writes go through the
 * loopback-pinned settings RPCs.
 */
export const inject = [
  'slots',
  'sessions',
  'workspaces',
  'locale',
  'conversation',
  'connection',
  'remote',
  'settingsScope',
];

/**
 * Mount the mascot and the selection toolbar: register the dictionaries, then
 * contribute both surfaces into `shell.overlay` once ui-layout declares it. The
 * work-state observable, the persisted sources, and the selection tracker are
 * created per declaration lifetime and disposed with the registration; the
 * background presenter projects the source onto the `--dsw-alias-bg-base` CSS
 * variable (recoloring every surface layer).
 * @param ctx - Client root context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'ui-sprite: dictionaries');

  // Host-persisted preferences shared by every loopback browser; the sync
  // bridge falls back to localStorage alone when the scope is memory-mode or
  // unavailable.
  const settings = ctx.settingsScope.bind<SpritelySettings>({ namespace: SPRITELY_SETTINGS_NAMESPACE });

  ctx.slots.inject('shell.overlay', () => {
    const source = createSpriteStateSource(ctx.sessions);
    const background = createBackgroundSource();
    const spriteKind = createSpriteKindSource();
    const position = createSpritePositionSource();
    const selection = createSelectionSource();
    const sync = new SpriteSettingsSync(settings, { spriteKind, position, background });
    const presenter = new BackgroundPresenter();
    presenter.apply(background.getSnapshot());
    const unsubscribeBackground = background.subscribe(() => {
      presenter.apply(background.getSnapshot());
    });
    const dispose = ctx.slots.register(
      {
        name: 'shell.overlay',
        id: 'sprite',
        locale: NS,
        inject: (): SpriteMascotInjected => ({
          hooks: { sprite: source, background, spriteKind, position },
          startSession: () => {
            ctx.workspaces.startSession();
          },
          setBackground: (value) => {
            sync.setBackground(value);
          },
          setSpriteKind: (kind) => {
            sync.setCharacter(kind);
          },
          setPosition: (value) => {
            sync.setPosition(value);
          },
        }),
      },
      SpriteMascot,
    );
    const disposeToolbar = ctx.slots.register(
      {
        name: 'shell.overlay',
        id: 'selection-toolbar',
        locale: NS,
        inject: (): SelectionToolbarInjected => ({
          hooks: { selection },
          quoteAsk: (text) => {
            const current = ctx.sessions.list.getSnapshot().current;
            const actx = current === undefined ? undefined : ctx.sessions.scope(current);
            const input = actx?.get('conversation')?.input.for(actx);
            if (input === undefined) return;
            const draft = input.state.getSnapshot().draft;
            const prefix = draft.trim() === '' ? '' : `${draft.trimEnd()}\n\n`;
            input.setDraft(`${prefix}${formatQuote(text)}`);
            selection.dismiss();
            // Focus the composer and land the caret on the empty line after the
            // quote; the platform steals no focus on external drafts, so the
            // plugin restores it itself.
            requestAnimationFrame(() => {
              const el = document.querySelector<HTMLTextAreaElement>(COMPOSER_TEXTAREA_SELECTOR);
              if (el === null) return;
              el.focus({ preventScroll: true });
              el.setSelectionRange(el.value.length, el.value.length);
            });
          },
        }),
      },
      SelectionToolbar,
    );
    return () => {
      dispose();
      disposeToolbar();
      source.dispose();
      selection.dispose();
      sync.dispose();
      unsubscribeBackground();
      presenter.dispose();
    };
  });
}
