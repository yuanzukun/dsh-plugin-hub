/**
 * SelectionToolbar: the floating action bar shown above an in-conversation
 * text selection — copy, read aloud (SpeechSynthesis), and quote-and-ask
 * into the composer draft. Pure presentation: the live selection arrives
 * through the injected `useSelection` hook, and the ask action rides the
 * inject face (the registrant owns the conversation wiring).
 */

// Type-only: pulls ui-layout's SlotMap merge so PropsRuntime<'shell.overlay'> resolves.
import type {} from '@deepseek-ai/dsh-client-ui-layout/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type CSSProperties, type ReactElement, useEffect, useRef, useState } from 'react';
import css from './SelectionToolbar.module.css';
import { type SelectionState, TOOLBAR_SELECTOR } from './selection-toolbar.ts';

/** Registrant inject face: the live selection source plus the ask action. */
export interface SelectionToolbarInjected {
  hooks: {
    selection: import('@deepseek-ai/dsh-client-ui-slots').HostObservable<SelectionState | null>;
  };
  /** Quote the given text into the current session's composer draft. */
  quoteAsk: (text: string) => void;
}

/** Full composed props: runtime share + bound inject share + locale seat. */
export type SelectionToolbarProps = PropsRuntime<'shell.overlay'> &
  InjectFace<SelectionToolbarInjected> &
  PropsLocale<'sprite'>;

/** Vertical gap between the selection and the toolbar, in px. */
const TOOLBAR_GAP_PX = 8;

/** Flip the toolbar below the selection when this close to the viewport top. */
const FLIP_THRESHOLD_PX = 48;

/** Approximate half the toolbar width, for clamping the centered anchor inside the viewport. */
const TOOLBAR_HALF_WIDTH_PX = 112;

/** How long the copy button shows its "copied" confirmation, in ms. */
const COPIED_FEEDBACK_MS = 1200;

/** Selector attribute marking the toolbar root (kept in sync with selection-toolbar.ts). */
const TOOLBAR_DATA_ATTR = TOOLBAR_SELECTOR.slice(1, -1);

/**
 * Render the floating selection toolbar. Returns null while no qualifying
 * selection exists so the overlay layer stays click-through.
 * @param props - composed slot props (`useSelection`, `quoteAsk`, `t`).
 * @returns the toolbar element tree, or null.
 */
export function SelectionToolbar({ useSelection, quoteAsk, t }: SelectionToolbarProps): ReactElement | null {
  const selection = useSelection((sel) => sel);
  const [copied, setCopied] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const copyTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  // Stop any in-flight reading when the selection changes or the bar unmounts.
  const selectionText = selection?.text;
  // biome-ignore lint/correctness/useExhaustiveDependencies: selectionText is the intentional trigger — the effect resets transient copy/speech state whenever the selected text changes.
  useEffect(() => {
    setCopied(false);
    setSpeaking(false);
    if (typeof speechSynthesis !== 'undefined') speechSynthesis.cancel();
    return () => {
      if (typeof speechSynthesis !== 'undefined') speechSynthesis.cancel();
    };
  }, [selectionText]);

  useEffect(() => {
    return () => {
      if (copyTimer.current !== undefined) clearTimeout(copyTimer.current);
    };
  }, []);

  if (selection === null) return null;

  const copy = (): void => {
    void navigator.clipboard?.writeText(selection.text);
    setCopied(true);
    if (copyTimer.current !== undefined) clearTimeout(copyTimer.current);
    copyTimer.current = setTimeout(() => setCopied(false), COPIED_FEEDBACK_MS);
  };

  const speak = (): void => {
    if (typeof speechSynthesis === 'undefined') return;
    if (speaking) {
      speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    const utterance = new SpeechSynthesisUtterance(selection.text);
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    speechSynthesis.speak(utterance);
    setSpeaking(true);
  };

  const ask = (): void => {
    quoteAsk(selection.text);
  };

  // Anchor at the pointer's release point (mouse-made selections), falling
  // back to the selection's rect center (keyboard-made ones); flipped below
  // when there is no headroom above.
  const anchorX = selection.pointer?.x ?? selection.rect.left + selection.rect.width / 2;
  const anchorTop = selection.pointer?.y ?? selection.rect.top;
  const anchorBottom = selection.pointer?.y ?? selection.rect.top + selection.rect.height;
  const above = anchorTop >= FLIP_THRESHOLD_PX;
  const style: CSSProperties = {
    left: Math.max(TOOLBAR_HALF_WIDTH_PX, Math.min(anchorX, window.innerWidth - TOOLBAR_HALF_WIDTH_PX)),
    top: above ? anchorTop - TOOLBAR_GAP_PX : anchorBottom + TOOLBAR_GAP_PX,
    transform: above ? 'translate(-50%, -100%)' : 'translate(-50%, 0)',
  };

  return (
    <div
      className={css.toolbar}
      style={style}
      role="toolbar"
      aria-label={t('selection.label')}
      {...{ [TOOLBAR_DATA_ATTR]: '' }}
    >
      <button type="button" className={css.action} onClick={copy}>
        {copied ? t('selection.copied') : t('selection.copy')}
      </button>
      <button type="button" className={css.action} onClick={speak}>
        {speaking ? t('selection.stop') : t('selection.speak')}
      </button>
      <button type="button" className={css.action} onClick={ask}>
        {t('selection.ask')}
      </button>
    </div>
  );
}
