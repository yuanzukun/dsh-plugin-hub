/**
 * The settings-sync bridge: keeps the three localStorage-backed sources
 * (character, position, background) in step with the Host-owned `ui-sprite`
 * settings namespace. The local sources stay the instant-read path (first
 * paint, LAN browsers whose settings RPCs are loopback-pinned into memory
 * mode); once the scope reports `ready` the Host document becomes the source
 * of truth for every field the user layer holds, and explicit user writes
 * dual-write local + Host so every loopback browser shares them.
 */
import type { SettingsScope, SettingsScopeSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import {
  SPRITELY_BACKGROUND_FIELD,
  SPRITELY_CHARACTER_FIELD,
  SPRITELY_POSITION_FIELD,
  type SpritelySettings,
} from '../settings.ts';
import type { BackgroundSource, BackgroundState } from './background-source.ts';
import type { SpriteKindSource } from './sprite-kind-source.ts';
import type { SpritePosition, SpritePositionSource } from './sprite-position-source.ts';
import type { SpriteKind } from './sprites.ts';

/** The persisted sources the bridge synchronizes with the settings scope. */
export interface SpriteSettingsSources {
  /** The selected-character source. */
  spriteKind: SpriteKindSource;
  /** The dragged anchor-position source. */
  position: SpritePositionSource;
  /** The background source. */
  background: BackgroundSource;
}

/** Structural equality for the small JSON-shaped settings values. */
function sameValue(left: unknown, right: unknown): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

/**
 * Bidirectional sync between the localStorage sources and the Host settings
 * scope. Scope snapshots with a user layer push their held fields into the
 * local sources (so a second browser and external `settings.yaml` edits land
 * live); a scope without a user layer migrates the local values upward once.
 * Writes are accepted only in `host` mode with a writable document — memory
 * mode and unavailable scopes leave the bridge silent and the plugin behaves
 * exactly as the localStorage-only version.
 */
export class SpriteSettingsSync {
  private readonly unsubscribe: () => void;
  /** Guards the one-shot local-to-Host migration of a fresh namespace. */
  private migrated = false;

  /**
   * @param scope - settings scope bound to the `ui-sprite` namespace.
   * @param sources - the localStorage-backed sources to synchronize.
   */
  constructor(
    private readonly scope: SettingsScope<SpritelySettings>,
    private readonly sources: SpriteSettingsSources,
  ) {
    this.unsubscribe = scope.subscribe(() => {
      this.adopt();
    });
    this.adopt();
  }

  /** Set the mascot character locally and, when possible, on the Host. */
  setCharacter(kind: SpriteKind): void {
    this.sources.spriteKind.set(kind);
    this.write(SPRITELY_CHARACTER_FIELD, kind);
  }

  /** Set the anchor position locally and, when possible, on the Host. */
  setPosition(position: SpritePosition | null): void {
    this.sources.position.set(position);
    this.write(SPRITELY_POSITION_FIELD, position);
  }

  /** Set the background selection locally and, when possible, on the Host. */
  setBackground(background: BackgroundState | null): void {
    this.sources.background.set(background);
    this.write(SPRITELY_BACKGROUND_FIELD, background);
  }

  /** Stop observing the settings scope (slot teardown). */
  dispose(): void {
    this.unsubscribe();
  }

  /**
   * Adopt the scope's current snapshot. Only `ready` snapshots carry an
   * accepted section. A section with a user layer wins per held field; one
   * without migrates the local values upward once (existing users' settings
   * move from localStorage into the shared document).
   */
  private adopt(): void {
    const snapshot = this.scope.getSnapshot();
    if (snapshot.status !== 'ready' || snapshot.value === undefined) return;
    if (!this.hasUserLayer(snapshot)) {
      this.migrate(snapshot);
      return;
    }
    const { value } = snapshot;
    const user = snapshot.user as Partial<SpritelySettings>;
    if (SPRITELY_CHARACTER_FIELD in user && !sameValue(this.sources.spriteKind.getSnapshot(), value.character)) {
      this.sources.spriteKind.set(value.character);
    }
    if (SPRITELY_POSITION_FIELD in user && !sameValue(this.sources.position.getSnapshot(), value.position)) {
      this.sources.position.set(value.position);
    }
    if (SPRITELY_BACKGROUND_FIELD in user && !sameValue(this.sources.background.getSnapshot(), value.background)) {
      this.sources.background.set(value.background);
    }
  }

  /** Whether the raw user layer is a stored object (vs. absent). */
  private hasUserLayer(snapshot: SettingsScopeSnapshot<SpritelySettings>): boolean {
    return typeof snapshot.user === 'object' && snapshot.user !== null;
  }

  /** Push the local values into a fresh Host namespace (one-shot). */
  private migrate(snapshot: SettingsScopeSnapshot<SpritelySettings>): void {
    if (this.migrated || !snapshot.writable) return;
    this.migrated = true;
    void this.scope.set(SPRITELY_CHARACTER_FIELD, this.sources.spriteKind.getSnapshot());
    const position = this.sources.position.getSnapshot();
    if (position !== null) void this.scope.set(SPRITELY_POSITION_FIELD, position);
    const background = this.sources.background.getSnapshot();
    if (background !== null) void this.scope.set(SPRITELY_BACKGROUND_FIELD, background);
  }

  /** Route one field write to the Host when the document accepts it. */
  private write(field: string, value: unknown): void {
    const snapshot = this.scope.getSnapshot();
    if (snapshot.mode !== 'host' || !snapshot.writable) return;
    void this.scope.set(field, value);
  }
}
