/**
 * Text-selection tracking for the floating selection toolbar: a snapshot
 * store over the live selection inside the conversation flow, plus the quote
 * formatter the ask action uses. The store is null while no qualifying
 * selection exists, so the toolbar renders nothing at all.
 */
import { createSnapshotStore, type ObservableSnapshot } from '@deepseek-ai/dsh-client-runtime/client';

/** Selector marking the conversation message flow (ui-conversation's anchor). */
const CHAT_FLOW_SELECTOR = '[data-chat-flow]';

/** Selector marking the toolbar itself, so pressing its buttons is not a dismissal. */
export const TOOLBAR_SELECTOR = '[data-spritely-selection-toolbar]';

/** Debounce before re-reading the selection (selectionchange fires per drag step). */
const REFRESH_DEBOUNCE_MS = 120;

/** A live text selection inside the conversation flow. */
export interface SelectionState {
  /** The selected text (trimmed, non-empty). */
  text: string;
  /** Viewport rectangle of the selection's first range, for toolbar placement. */
  rect: { top: number; left: number; width: number; height: number };
  /** Viewport point where the pointer completed the selection; null for keyboard-made selections. */
  pointer: { x: number; y: number } | null;
}

/** The read/write face the toolbar's inject exposes for the live selection. */
export interface SelectionSource extends ObservableSnapshot<SelectionState | null> {
  /** Hide the toolbar without touching the selection itself. */
  dismiss(): void;
  /** Remove all listeners and pending timers. */
  dispose(): void;
}

/**
 * Format selected text as a Markdown quote block followed by an empty line,
 * leaving the caret ready for the user's question on the next line.
 * @param text - the selected text.
 * @returns the quote block, e.g. `> a\n> b\n\n`.
 */
export function formatQuote(text: string): string {
  const quoted = text
    .trim()
    .split('\n')
    .map((line) => `> ${line}`);
  return `${quoted.join('\n')}\n\n`;
}

/**
 * Create the selection source. Listens for selectionchange/pointer activity
 * on the document; a selection qualifies when it is non-collapsed, has
 * non-empty text, and lives inside the conversation flow (`data-chat-flow`).
 * The toolbar hides on pointerdown outside itself and on Escape/dismiss
 * (sticky: the same selection stays hidden until it changes or collapses),
 * and follows the selection's live rect on scroll.
 * @param doc - the document to observe (defaults to the global document).
 * @returns the source.
 */
export function createSelectionSource(doc: Document = document): SelectionSource {
  const store = createSnapshotStore<SelectionState | null>(null);
  /** True between pointerdown and pointerup — the drag is still in flight. */
  let pressed = false;
  /** True when the in-flight gesture started on the toolbar (button clicks must not re-anchor it). */
  let gestureOnToolbar = false;
  /** Release point of the pointer gesture that completed the selection (consumed by read). */
  let pointer: { x: number; y: number } | null = null;
  /** Text of the explicitly dismissed selection; suppressed until the selection changes or collapses. */
  let dismissedText: string | null = null;
  let timer: ReturnType<typeof setTimeout> | undefined;

  const read = (): SelectionState | null => {
    const selection = doc.getSelection();
    if (selection === null || selection.isCollapsed || selection.rangeCount === 0) {
      dismissedText = null;
      return null;
    }
    const text = selection.toString().trim();
    if (text === '' || text === dismissedText) return null;
    const range = selection.getRangeAt(0);
    const node = range.commonAncestorContainer;
    const element = node.nodeType === 1 ? (node as Element) : node.parentElement;
    if (element === null || element.closest(CHAT_FLOW_SELECTOR) === null) return null;
    const box = range.getBoundingClientRect();
    const point = pointer;
    pointer = null;
    return { text, rect: { top: box.top, left: box.left, width: box.width, height: box.height }, pointer: point };
  };

  const schedule = (): void => {
    if (pressed) return;
    if (timer !== undefined) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = undefined;
      store.set(read());
    }, REFRESH_DEBOUNCE_MS);
  };

  const onPointerDown = (event: Event): void => {
    pressed = true;
    const target = event.target;
    gestureOnToolbar = target instanceof Element && target.closest(TOOLBAR_SELECTOR) !== null;
    if (gestureOnToolbar) return;
    if (store.getSnapshot() !== null) store.set(null);
  };
  const onPointerUp = (event: Event): void => {
    pressed = false;
    if (gestureOnToolbar) {
      gestureOnToolbar = false;
      return;
    }
    pointer = event instanceof MouseEvent ? { x: event.clientX, y: event.clientY } : null;
    schedule();
  };
  const onKeyDown = (event: KeyboardEvent): void => {
    if (event.key === 'Escape') dismiss();
  };
  // The range is still live while scrolling: re-anchor instead of hiding.
  const onScroll = (): void => {
    if (pressed) return;
    store.set(read());
  };

  /** Hide the toolbar and suppress the current selection until it changes or collapses. */
  const dismiss = (): void => {
    const current = store.getSnapshot();
    if (current !== null) dismissedText = current.text;
    if (current !== null) store.set(null);
  };

  doc.addEventListener('selectionchange', schedule);
  doc.addEventListener('pointerdown', onPointerDown, true);
  doc.addEventListener('pointerup', onPointerUp, true);
  doc.addEventListener('keydown', onKeyDown, true);
  doc.addEventListener('scroll', onScroll, true);

  return {
    getSnapshot: () => store.getSnapshot(),
    subscribe: (fn) => store.subscribe(fn),
    dismiss,
    dispose: () => {
      if (timer !== undefined) clearTimeout(timer);
      doc.removeEventListener('selectionchange', schedule);
      doc.removeEventListener('pointerdown', onPointerDown, true);
      doc.removeEventListener('pointerup', onPointerUp, true);
      doc.removeEventListener('keydown', onKeyDown, true);
      doc.removeEventListener('scroll', onScroll, true);
    },
  };
}
