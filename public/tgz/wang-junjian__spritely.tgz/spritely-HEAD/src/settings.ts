/**
 * Durable sprite preferences stored in the Host user-settings document
 * (`~/.dsh/settings.yaml`, namespace `ui-sprite`). Shared by the Host entry
 * (which registers the schema) and the browser half (which binds a settings
 * scope over the same namespace); the schema doubles as the wire envelope the
 * browser scope validates sections against.
 */
import z from '@deepseek-ai/schemastery';
import type { BackgroundState } from './client/background-source.ts';
import type { SpritePosition } from './client/sprite-position-source.ts';
import type { SpriteKind } from './client/sprites.ts';

/** Settings namespace owned by the sprite plugin (matches the loader row id). */
export const SPRITELY_SETTINGS_NAMESPACE = 'ui-sprite';

/** Field carrying the selected mascot character. */
export const SPRITELY_CHARACTER_FIELD = 'character';
/** Field carrying the dragged anchor position. */
export const SPRITELY_POSITION_FIELD = 'position';
/** Field carrying the app background selection. */
export const SPRITELY_BACKGROUND_FIELD = 'background';

/** The valid sprite kinds (mirrors the `SpriteKind` union for the schema). */
const CHARACTER_KINDS = ['blob', 'bot', 'cat', 'ghost'] as const;

/** Durable sprite section shared by the Host schema and the browser scope. */
export interface SpritelySettings {
  /** Selected mascot character. */
  character: SpriteKind;
  /** Dragged anchor position; null restores the default corner. */
  position: SpritePosition | null;
  /** App background selection; null follows the theme. */
  background: BackgroundState | null;
}

/** Durable sprite schema; also the wire envelope the browser scope validates against. */
export const SpritelySettingsSchema: z<SpritelySettings> = z.object({
  [SPRITELY_CHARACTER_FIELD]: z.union([...CHARACTER_KINDS]).default('blob'),
  [SPRITELY_POSITION_FIELD]: z.union([z.object({ x: z.number(), y: z.number() }), z.const(null)]).default(null),
  [SPRITELY_BACKGROUND_FIELD]: z
    .union([
      z.object({
        kind: z.union(['color', 'gradient', 'image']),
        value: z.string(),
        fit: z.union(['contain', 'fill']).default('contain'),
        // Matches DEFAULT_VEIL in client/background-source.ts.
        veil: z.number().default(0.5),
      }),
      z.const(null),
    ])
    .default(null),
});
