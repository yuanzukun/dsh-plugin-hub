#!/usr/bin/env node
/**
 * 冒烟测试：本地起一个模拟 iLink 服务器，端到端验证
 *  登录（扫码确认）→ 长轮询收消息 → 回复（sendmessage 携带 context_token）
 * 整条协议链路。无需真实微信凭证即可运行。
 *
 * 用法：node scripts/smoke.mjs
 */

import http from "node:http";
import { IlinkClient } from "../lib/ilink.js";
import { ClawbotChannel } from "../lib/channel.js";
import { AgentBridge } from "../lib/bridge.js";
import { markdownToText } from "../lib/markdown.js";

const noopLogger = { info() {}, warn() {}, error() {} };
const PORT = 18999;

/** 模拟 iLink 服务器：脚本化返回扫码确认与一条用户消息。 */
function startMockServer() {
	const sent = [];
	let updatesCalls = 0;
	const server = http.createServer((req, res) => {
		const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
		res.setHeader("content-type", "application/json");
		if (url.pathname.endsWith("/get_bot_qrcode")) {
			res.end(JSON.stringify({ qrcode: "mock-qr-1", qrcode_img_content: "https://mock/qr" }));
			return;
		}
		if (url.pathname.endsWith("/get_qrcode_status")) {
			res.end(JSON.stringify({ status: "confirmed", bot_token: "mock-token", baseurl: `http://127.0.0.1:${PORT}`, ilink_bot_id: "bot-mock" }));
			return;
		}
		if (url.pathname.endsWith("/getupdates")) {
			updatesCalls++;
			if (updatesCalls === 1) {
				res.end(JSON.stringify({
					ret: 0,
					msgs: [{
						message_type: 1,
						from_user_id: "user_1@im.wechat",
						to_user_id: "bot@im.bot",
						context_token: "ctx-123",
						item_list: [{ type: 1, text_item: { text: "你好，Agent" } }],
					}],
					get_updates_buf: "cursor-1",
				}));
				return;
			}
			// 后续轮询挂起（长轮询语义）。
			setTimeout(() => res.end(JSON.stringify({ ret: 0, msgs: [], get_updates_buf: "cursor-2" })), 30000);
			return;
		}
		if (url.pathname.endsWith("/getconfig")) {
			res.end(JSON.stringify({ ret: 0, typing_ticket: "ticket-mock" }));
			return;
		}
		if (url.pathname.endsWith("/sendtyping") || url.pathname.endsWith("/sendmessage")) {
			let body = "";
			req.on("data", (chunk) => (body += chunk));
			req.on("end", () => {
				sent.push(JSON.parse(body));
				res.end(JSON.stringify({ ret: 0 }));
			});
			return;
		}
		res.statusCode = 404;
		res.end(JSON.stringify({ ret: -1, errmsg: "not found" }));
	});
	return new Promise((resolve) => {
		server.listen(PORT, "127.0.0.1", () => resolve({ server, sent }));
	});
}

/** 假 Agent 桥：收到消息立即回复。 */
function makeFakeBridge() {
	const delivered = [];
	const bridge = new AgentBridge({
		ctx: {
			get(name) {
				if (name === "agents") {
					return {
						get: () => undefined,
						resume: async () => {
							throw new Error("not found");
						},
					};
				}
				if (name === "agentLoop") {
					let seq = 0;
					return {
						create: () => {
							const session = { seq, events: [] };
							const agent = {
								session,
								followup() {
									// 立即产生回复。
									session.events.push({ seq: session.seq, type: "assistant/message", data: { message: { content: [{ type: "text", text: "你好！我是 DSH Agent，很高兴为你服务。" }] } } });
									session.seq++;
								},
								whenIdle: async () => {},
							};
							return agent;
						},
					};
				}
				return undefined;
			},
		},
		logger: noopLogger,
		cwd: process.cwd(),
		passiveTimeoutMs: 0,
		deliver: (userId, text) => delivered.push({ userId, text }),
		onError: (userId, error) => delivered.push({ userId, error: error.message }),
	});
	return { bridge, delivered };
}

async function main() {
	const { server, sent } = await startMockServer();
	const { bridge, delivered } = makeFakeBridge();
	const channel = new ClawbotChannel({
		client: new IlinkClient({ baseUrl: `http://127.0.0.1:${PORT}`, logger: noopLogger }),
		store: { dir: process.cwd() + "/.tmp", load: () => undefined, save: () => {}, clear: () => {}, ensure: () => {} },
		bridge,
		config: {
			storageDir: ".tmp",
			autoLogin: true,
			qrcodeOutput: "log",
			qrcodeScanTimeoutMs: 5000,
			sessionDurationMs: 86400000,
			reconnectWarningBeforeMs: 7200000,
			reconnectReminderIntervalMs: 1800000,
			reconnectForceBeforeMs: 1800000,
			longPollTimeoutMs: 3000,
			dmPolicy: "open",
			allowFrom: [],
			renderMarkdown: true,
			welcomeText: "欢迎使用 DSH Agent。",
			agentCwd: process.cwd(),
		},
		logger: noopLogger,
	});
	channel.attachBridgeCallbacks();

	console.log("1) 启动频道（自动扫码登录，模拟服务器立即确认）…");
	await channel.start();
	console.log("   登录完成，Bot =", channel.session.accountId);

	console.log("2) 等待长轮询收到模拟用户消息…");
	await new Promise((resolve) => setTimeout(resolve, 800));

	const replyMsg = sent.find((entry) => entry.msg?.item_list?.[0]?.type === 1 && entry.msg.to_user_id === "user_1@im.wechat" && entry.msg.context_token === "ctx-123" && entry.msg.item_list[0].text_item.text.includes("很高兴为你服务"));
	if (!replyMsg) throw new Error("冒烟失败：未收到带 context_token 的 Agent 回复");
	const replyText = replyMsg.msg.item_list[0].text_item.text;
	console.log(`   收到回复: ${replyText}`);
	if (!replyText.includes("DSH Agent")) throw new Error("冒烟失败：回复内容不符");

	const typing = sent.find((entry) => entry.typing_ticket !== undefined);
	if (!typing) throw new Error("冒烟失败：未发送 typing 状态");
	console.log(`   typing 状态已发送（status=${typing.status}）`);

	const rendered = markdownToText("# 你好\n**测试** [链接](https://x)");
	if (!rendered.includes("你好")) throw new Error("markdown 转换异常");
	console.log("3) markdown 转换验证通过");

	await channel.stop();
	server.close();
	console.log("\n✅ 冒烟测试通过：登录 → 收消息 → typing → 回复（context_token 关联）全链路正常。");
	process.exit(0);
}

main().catch((error) => {
	console.error("❌ 冒烟测试失败:", error.message);
	process.exit(1);
});
