#!/usr/bin/env python3
"""重启 dsh web 的脱离式守护进程。

用双 fork + setsid 让本进程完全脱离调用方（DSH 宿主）的进程组/会话，
即使宿主随后被 kill，重启流程仍会执行完毕，新实例日志落盘可读。

用法：python3 restart-daemon.py
输出：/tmp/dsh-restart.log（重启流程日志）、/tmp/dsh-web.log（dsh web 日志）
"""
import os
import sys
import time

RESTART_LOG = "/tmp/dsh-restart.log"
WEB_LOG = "/tmp/dsh-web.log"

def log(msg):
    with open(RESTART_LOG, "a") as f:
        f.write(f"[{time.strftime('%H:%M:%S')}] {msg}\n")

def run():
    log("守护进程已启动，3 秒后开始重启")
    time.sleep(3)

    # 1. 找到当前占用 3080 的进程并优雅停止
    import subprocess
    try:
        out = subprocess.run(
            ["lsof", "-nP", "-iTCP:3080", "-sTCP:LISTEN", "-t"],
            capture_output=True, text=True, timeout=10,
        ).stdout.strip()
        for pid in out.splitlines():
            if pid.isdigit():
                log(f"kill 旧实例 PID {pid}")
                os.kill(int(pid), 15)
    except Exception as e:
        log(f"查找/停止旧实例异常: {e}")

    # 2. 等待端口释放（最多 40 秒）
    for i in range(80):
        r = subprocess.run(
            ["lsof", "-nP", "-iTCP:3080", "-sTCP:LISTEN"],
            capture_output=True, text=True,
        )
        if r.returncode != 0:
            log(f"端口 3080 已释放（第 {i} 次探测）")
            break
        time.sleep(0.5)
    else:
        log("警告：端口 40 秒内未释放，强制继续")

    # 3. 启动新实例（cwd=/Users/echoding，日志落盘）
    dsh_bin = "/Users/echoding/.npm/_npx/1e7f6d9597241db0/node_modules/.bin/dsh"
    try:
        os.remove(WEB_LOG)
    except OSError:
        pass
    log(f"启动新实例: {dsh_bin} web")
    with open(WEB_LOG, "ab", buffering=0) as out:
        proc = subprocess.Popen(
            [dsh_bin, "web"],
            cwd="/Users/echoding",
            stdout=out, stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,  # setsid
        )
        log(f"新实例 PID {proc.pid}")

    # 4. 等待启动并验证
    time.sleep(15)
    r = subprocess.run(["lsof", "-nP", "-iTCP:3080", "-sTCP:LISTEN"], capture_output=True, text=True)
    log("端口 3080 状态:\n" + (r.stdout or r.stderr or "(未监听)"))
    # 采样 iLink 连接
    for i in range(3):
        r2 = subprocess.run(
            ["lsof", "-nP", "-p", str(proc.pid), "-iTCP"],
            capture_output=True, text=True,
        )
        ilink = [ln for ln in (r2.stdout or "").splitlines() if "ilink" in ln or "weixin" in ln]
        if ilink:
            log(f"iLink 连接已建立:\n" + "\n".join(ilink[:5]))
            break
        time.sleep(3)
    else:
        log("未观测到 iLink 连接（可能仍在登录/启动）")
    # 日志尾部
    try:
        with open(WEB_LOG, "r", errors="replace") as f:
            tail = f.read()[-4000:]
        log("dsh web 日志尾部:\n" + tail)
    except Exception as e:
        log(f"读日志失败: {e}")
    log("守护进程完成")

if __name__ == "__main__":
    # 双 fork + setsid，脱离调用方
    if os.fork() > 0:
        sys.exit(0)
    os.setsid()
    if os.fork() > 0:
        sys.exit(0)
    run()
