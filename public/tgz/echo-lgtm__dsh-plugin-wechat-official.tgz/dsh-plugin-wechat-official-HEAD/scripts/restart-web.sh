#!/bin/bash
# dsh web 重启脚本：优雅停止旧实例 → 等待端口释放 → 后台启动新实例。
# 由 run_in_background 执行，独立于当前会话进程，kill 旧实例后仍能继续。
set -u

DSH_BIN="/Users/echoding/.npm/_npx/1e7f6d9597241db0/node_modules/.bin/dsh"
LOG="/tmp/dsh-web-restart.log"
OLD_PID="62173"

echo "[restart] $(date '+%H:%M:%S') 开始重启 dsh web…"

# 1. 优雅停止旧实例（等待其完成会话落盘）。
if kill -0 "$OLD_PID" 2>/dev/null; then
  echo "[restart] 发送 SIGTERM 到 $OLD_PID"
  kill -TERM "$OLD_PID" 2>/dev/null || true
else
  echo "[restart] 旧进程 $OLD_PID 已不存在"
fi

# 2. 等待 3080 端口释放（最多 30 秒）。
for i in $(seq 1 60); do
  if ! lsof -nP -iTCP:3080 -sTCP:LISTEN >/dev/null 2>&1; then
    echo "[restart] 端口 3080 已释放（${i} 次探测）"
    break
  fi
  sleep 0.5
  if [ "$i" = "60" ]; then
    echo "[restart] 警告：端口 30 秒内未释放，强制继续"
  fi
done

# 3. 后台启动新实例。
echo "[restart] 启动新实例，日志: $LOG"
rm -f "$LOG"
nohup "$DSH_BIN" web > "$LOG" 2>&1 &
NEW_PID=$!
echo "[restart] 新进程 PID: $NEW_PID"

# 4. 等待启动并验证端口监听。
sleep 10
if lsof -nP -iTCP:3080 -sTCP:LISTEN >/dev/null 2>&1; then
  echo "[restart] ✅ 端口 3080 已监听"
else
  echo "[restart] ❌ 端口 3080 未监听，日志尾部："
fi
echo "---- 日志尾部 ----"
tail -40 "$LOG" 2>/dev/null || echo "(无日志)"
echo "[restart] $(date '+%H:%M:%S') 完成"
