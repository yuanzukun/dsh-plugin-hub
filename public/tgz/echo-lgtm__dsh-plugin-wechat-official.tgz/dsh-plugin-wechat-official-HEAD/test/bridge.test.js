/**
 * AgentBridge 测试（mock 核心服务与假 agent）。
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { AgentBridge, sessionIdForUser, extractAssistantText } from "../lib/bridge.js";

const noopLogger = { info() {}, warn() {}, error() {} };

/** 构造一个可编程假 agent：followup 时同步产生 assistant 回复事件（无竞态）。 */
function makeFakeAgent(seedEvents = []) {
	const session = { seq: seedEvents.length, events: [...seedEvents] };
	const agent = {
		session,
		followups: [],
		replyText: "默认回复",
		followup(msg) {
			agent.followups.push(msg);
			// 模拟真实会话：立即追加一条 assistant 文本事件并推进 seq。
			session.events.push({
				seq: session.seq,
				type: "assistant/message",
				data: { message: { content: [{ type: "text", text: agent.replyText }] } },
			});
			session.seq++;
		},
		async whenIdle() {},
	};
	return agent;
}

/** 构造最小 ctx mock：agents.get 返回 live，agentLoop.create 返回假 agent。 */
function makeCtx({ liveAgent, createdAgent }) {
	const createdMeta = [];
	return {
		createdMeta,
		get(name) {
			if (name === "agents") {
				return {
					get: () => liveAgent,
					resume: async () => {
						const error = new Error('session "x" not found');
						throw error;
					},
				};
			}
			if (name === "agentLoop") {
				return {
					create: (id, options, meta) => {
						createdMeta.push({ id, options, meta });
						return createdAgent;
					},
				};
			}
			if (name === "agentDefaultModel") return { currentSelection: () => ({ provider: "deepseek-official", model: "deepseek-v4-flash" }) };
			return undefined;
		},
	};
}

test("agent 创建时始终携带有效 cwd（persona 依赖 {{cwd}}）", async () => {
	const createdAgent = makeFakeAgent();
	const ctx = makeCtx({ liveAgent: undefined, createdAgent });
	const bridge = new AgentBridge({
		ctx,
		logger: noopLogger,
		cwd: "", // 配置为空 → bridge 必须回退到 process.cwd()
		passiveTimeoutMs: 0,
		deliver: () => {},
		onError: () => {},
	});
	await bridge.handleText("u@im.wechat", "hi");
	assert.equal(ctx.createdMeta.length, 1);
	const { meta } = ctx.createdMeta[0];
	assert.ok(meta && typeof meta.cwd === "string" && meta.cwd !== "", `meta.cwd 必须非空，实际: ${JSON.stringify(meta)}`);
});

test("sessionIdForUser 确定性且文件名安全", () => {
	const id1 = sessionIdForUser("o9cq800kum_xxx@im.wechat");
	const id2 = sessionIdForUser("o9cq800kum_xxx@im.wechat");
	const id3 = sessionIdForUser("another@im.wechat");
	assert.equal(String(id1), String(id2));
	assert.notEqual(String(id1), String(id3));
	assert.ok(!/[^A-Za-z0-9-]/.test(String(id1)));
	assert.ok(String(id1).startsWith("wechat-clawbot-"));
});

test("extractAssistantText 提取标记之后的最后一条 assistant 文本", () => {
	const events = [
		{ seq: 0, type: "turn/start", data: {} },
		{ seq: 1, type: "assistant/message", data: { message: { content: [{ type: "text", text: "旧回复" }] } } },
		{ seq: 2, type: "turn/end", data: {} },
	];
	// 从 seq 1 开始提取 → 只含 seq>=1 → "旧回复"
	assert.equal(extractAssistantText({ events }, 1), "旧回复");
	// 从 seq 3 开始提取（模拟新消息之后的标记）→ 空
	assert.equal(extractAssistantText({ events }, 3), "");
	// 多段文本块拼接
	const events2 = [...events, { seq: 3, type: "assistant/message", data: { message: { content: [{ type: "text", text: "A" }, { type: "tool_use", id: "x" }, { type: "text", text: "B" }] } } }];
	assert.equal(extractAssistantText({ events: events2 }, 3), "AB");
});

test("新用户：create 新 agent 并 followup 用户消息，deliver 回调收到回复", async () => {
	let delivered;
	let deliverResolve;
	const deliverPromise = new Promise((resolve) => {
		deliverResolve = resolve;
	});
	const createdAgent = makeFakeAgent();
	createdAgent.replyText = "回复内容";
	const ctx = makeCtx({ liveAgent: undefined, createdAgent });
	const bridge = new AgentBridge({
		ctx,
		logger: noopLogger,
		cwd: "/tmp",
		passiveTimeoutMs: 0,
		deliver: (userId, text) => {
			delivered = { userId, text };
			deliverResolve();
		},
		onError: (userId, error) => {
			throw error;
		},
	});

	const p = bridge.handleText("user_1@im.wechat", "你好");
	await p; // 入队完成（假 agent 已同步产生回复事件）
	await deliverPromise;
	assert.equal(delivered.userId, "user_1@im.wechat");
	assert.equal(delivered.text, "回复内容");
	// followup 消息形状正确。
	const [followup] = createdAgent.followups;
	assert.equal(followup.role, "user");
	assert.deepEqual(followup.content, [{ type: "text", text: "你好" }]);
	assert.equal(followup.source.kind, "user");
});

test("live agent 复用：不重复创建", async () => {
	const liveAgent = makeFakeAgent();
	let created = 0;
	const ctx = {
		get(name) {
			if (name === "agents") {
				return {
					get: () => liveAgent,
					resume: async () => {
						const error = new Error("not found");
						throw error;
					},
				};
			}
			if (name === "agentLoop") {
				return {
					create: () => {
						created++;
						return makeFakeAgent();
					},
				};
			}
			return undefined;
		},
	};
	const bridge = new AgentBridge({ ctx, logger: noopLogger, cwd: "/tmp", passiveTimeoutMs: 0, deliver: () => {}, onError: () => {} });
	await bridge.handleText("u@im.wechat", "第一条");
	await bridge.handleText("u@im.wechat", "第二条");
	assert.equal(created, 0); // 全程复用 live agent
	assert.equal(liveAgent.followups.length, 2);
});

test("错误路径：agentLoop 缺失抛错且不卡死链", async () => {
	const ctx = { get: () => undefined };
	const errors = [];
	const bridge = new AgentBridge({
		ctx,
		logger: noopLogger,
		cwd: "/tmp",
		passiveTimeoutMs: 0,
		deliver: () => {},
		onError: (userId, error) => errors.push(error),
	});
	const p = bridge.handleText("u@im.wechat", "hi");
	await p;
	assert.equal(errors.length, 1);
	assert.match(errors[0].message, /agentLoop service unavailable/);
	// 链不卡死：第二条消息也能进入。
	const p2 = bridge.handleText("u@im.wechat", "hi again");
	await p2;
	assert.equal(errors.length, 2);
});

test("按用户串行：同一用户消息顺序处理", async () => {
	const order = [];
	const liveAgent = makeFakeAgent();
	const ctx = {
		get(name) {
			if (name === "agents") {
				return {
					get: () => liveAgent,
					resume: async () => {
						const error = new Error("not found");
						throw error;
					},
				};
			}
			if (name === "agentLoop") return { create: () => makeFakeAgent() };
			return undefined;
		},
	};
	const bridge = new AgentBridge({
		ctx,
		logger: noopLogger,
		cwd: "/tmp",
		passiveTimeoutMs: 0,
		deliver: (userId, text) => order.push(text),
		onError: () => {},
	});
	await bridge.handleText("u@im.wechat", "m1");
	await bridge.handleText("u@im.wechat", "m2");
	assert.deepEqual(liveAgent.followups.map((m) => m.content[0].text), ["m1", "m2"]);
});
