/**
 * Markdown → 纯文本转换测试。
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { markdownToText } from "../lib/markdown.js";

test("标题转前缀", () => {
	const out = markdownToText("# 标题一\n## 标题二\n### 标题三");
	assert.ok(out.includes("【标题一】"));
	assert.ok(out.includes("■ 标题二"));
	assert.ok(out.includes("• 标题三"));
});

test("链接与图片", () => {
	const out = markdownToText("访问 [官网](https://example.com) 和 ![图](https://x/y.png)");
	assert.ok(out.includes("官网 (https://example.com)"));
	assert.ok(out.includes("[图片：图] https://x/y.png"));
});

test("内联样式剥离", () => {
	const out = markdownToText("**加粗** 与 *斜体* 与 `代码` 与 ~~删除~~");
	assert.ok(out.includes("加粗 与 斜体"));
	assert.ok(out.includes("`代码`"));
	assert.ok(out.includes("删除"));
});

test("列表与引用", () => {
	const out = markdownToText("- 甲\n- 乙\n\n> 引用内容");
	assert.ok(out.includes("- 甲"));
	assert.ok(out.includes("- 乙"));
	assert.ok(out.includes("> 引用内容"));
});

test("代码块保留", () => {
	const out = markdownToText("```js\nconsole.log(1)\n```\n后面");
	assert.ok(out.includes("```"));
	assert.ok(out.includes("console.log(1)"));
	assert.ok(out.includes("后面"));
});

test("表格转文本", () => {
	const out = markdownToText("| 列A | 列B |\n| --- | --- |\n| 1 | 2 |");
	assert.ok(out.includes("列A"));
	assert.ok(out.includes("列B"));
	assert.ok(out.includes("1"));
	assert.ok(out.includes("2"));
	assert.ok(!out.includes("---"));
});

test("HTML 标签剥离与 br 换行", () => {
	const out = markdownToText("<b>加粗</b><br/>下一行");
	assert.ok(out.includes("加粗"));
	assert.ok(out.includes("\n下一行"));
	assert.ok(!out.includes("<b>"));
});

test("空输入", () => {
	assert.equal(markdownToText(""), "");
	assert.equal(markdownToText(undefined), "");
	assert.equal(markdownToText(null), "");
});
