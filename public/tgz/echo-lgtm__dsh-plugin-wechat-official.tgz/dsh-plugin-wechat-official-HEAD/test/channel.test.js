/**
 * ClawbotChannel 测试（mock iLink 客户端 / store / bridge）。
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { ClawbotChannel } from "../lib/channel.js";

const noopLogger = { info() {}, warn() {}, error() {} };

const USER = "user_1@im.wechat";
const CTX = "ctx-1";

/** 默认配置。 */
function defaultConfig(overrides = {}) {
	return {
		storageDir: "/tmp/wechat-clawbot-test",
		autoLogin: true,
		qrcodeOutput: "log",
		qrcodeScanTimeoutMs: 60000,
		sessionDurationMs: 86400000,
		reconnectWarningBeforeMs: 7200000,
		reconnectReminderIntervalMs: 1800000,
		reconnectForceBeforeMs: 1800000,
		longPollTimeoutMs: 38000,
		dmPolicy: "open",
		allowFrom: [],
		renderMarkdown: true,
		welcomeText: "欢迎使用",
		agentCwd: "",
		...overrides,
	};
}

/** 构造 mock 依赖。 */
function makeMocks(overrides = {}) {
	const sent = [];
	const bridgeCalls = [];
	const bridge = {
		handleText: (userId, text) => bridgeCalls.push({ userId, text }),
		deliver: () => {},
		onError: () => {},
		dispose: async () => {},
	};
	const client = {
		getBotQrcode: async () => ({ qrcode: "qr-1", qrcode_img_content: "https://wx/qr" }),
		getQrcodeStatus: async () => ({ status: "confirmed", bot_token: "tk-2", baseurl: "https://ilink.example", ilink_bot_id: "bot-2" }),
		getUpdates: async () => ({ msgs: [], get_updates_buf: "" }),
		sendText: async (token, toUserId, contextToken, text) => {
			sent.push({ token, toUserId, contextToken, text });
		},
		getConfig: async () => "ticket-1",
		sendTyping: async () => {},
		...overrides.client,
	};
	const store = {
		dir: "/tmp/wechat-clawbot-test",
		load: () => undefined,
		save: () => {},
		clear: () => {},
		ensure: () => {},
		...overrides.store,
	};
	return { sent, bridgeCalls, bridge, client, store };
}

/** 快速 sleep。 */
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** 模拟长轮询挂起：真实场景下 getUpdates 会 hold 数十秒，这里用小延时避免忙循环。 */
const longPollIdle = () => sleep(15);

test("handleMessage：文本消息 → typing + 欢迎语 + 转发 Agent + 记录 context_token", async () => {
	const { sent, bridgeCalls, bridge, client, store } = makeMocks();
	const channel = new ClawbotChannel({ client, store, bridge, config: defaultConfig(), logger: noopLogger });
	channel.session = { token: "tk-1", baseUrl: "https://ilink.example" };
	channel.attachBridgeCallbacks();

	await channel.handleMessage({
		message_type: 1,
		from_user_id: USER,
		context_token: CTX,
		item_list: [{ type: 1, text_item: { text: "你好" } }],
	});

	// 欢迎语发送。
	assert.deepEqual(sent[0], { token: "tk-1", toUserId: USER, contextToken: CTX, text: "欢迎使用" });
	// 转发 Agent。
	assert.deepEqual(bridgeCalls, [{ userId: USER, text: "你好" }]);
	// context token 已记录。
	assert.equal(channel.contextTokens.get(USER), CTX);
	// typing 已开启。
	assert.equal(channel.typingTickets.get(USER), "ticket-1");
});

test("handleMessage：allowlist 拒绝未授权用户", async () => {
	const { sent, bridgeCalls, bridge, client, store } = makeMocks();
	const channel = new ClawbotChannel({
		client,
		store,
		bridge,
		config: defaultConfig({ dmPolicy: "allowlist", allowFrom: ["allowed@im.wechat"] }),
		logger: noopLogger,
	});
	channel.session = { token: "tk-1", baseUrl: "https://ilink.example" };
	channel.attachBridgeCallbacks();

	await channel.handleMessage({ message_type: 1, from_user_id: USER, context_token: CTX, item_list: [{ type: 1, text_item: { text: "hi" } }] });
	assert.equal(bridgeCalls.length, 0);
	assert.ok(sent.some((s) => /没有权限/.test(s.text)));
	assert.equal(channel.isAllowed("allowed@im.wechat"), true);
	assert.equal(channel.isAllowed(USER), false);
});

test("handleMessage：群消息跳过", async () => {
	const { bridgeCalls, bridge, client, store } = makeMocks();
	const channel = new ClawbotChannel({ client, store, bridge, config: defaultConfig(), logger: noopLogger });
	channel.session = { token: "tk-1", baseUrl: "https://ilink.example" };
	await channel.handleMessage({ message_type: 1, from_user_id: USER, group_id: "g-1", context_token: CTX, item_list: [{ type: 1, text_item: { text: "hi" } }] });
	assert.equal(bridgeCalls.length, 0);
});

test("handleMessage：/help 与 /time 指令不转发 Agent", async () => {
	const { sent, bridgeCalls, bridge, client, store } = makeMocks();
	const channel = new ClawbotChannel({ client, store, bridge, config: defaultConfig(), logger: noopLogger });
	channel.session = { token: "tk-1", baseUrl: "https://ilink.example" };
	channel.attachBridgeCallbacks();
	channel.loginTime = Date.now();

	await channel.handleMessage({ message_type: 1, from_user_id: USER, context_token: CTX, item_list: [{ type: 1, text_item: { text: "/help" } }] });
	await channel.handleMessage({ message_type: 1, from_user_id: USER, context_token: CTX, item_list: [{ type: 1, text_item: { text: "/time" } }] });
	assert.equal(bridgeCalls.length, 0);
	assert.ok(sent.some((s) => s.text.includes("可用指令")));
	assert.ok(sent.some((s) => /剩余时间/.test(s.text)));
});

test("handleMessage：重连确认 Y 触发重连", async () => {
	let reconnectDone;
	const { sent, bridge, client, store } = makeMocks();
	const channel = new ClawbotChannel({ client, store, bridge, config: defaultConfig(), logger: noopLogger });
	channel.session = { token: "tk-1", baseUrl: "https://ilink.example" };
	channel.attachBridgeCallbacks();
	channel.lastContact = { fromId: USER, contextToken: CTX };

	// 手动重连待确认。
	channel.manualReconnectPending.add(USER);
	reconnectDone = channel.doReconnect().then(() => true);
	await channel.handleMessage({ message_type: 1, from_user_id: USER, context_token: CTX, item_list: [{ type: 1, text_item: { text: "Y" } }] });
	await reconnectDone;
	assert.equal(channel.session.token, "tk-2");
	assert.ok(sent.some((s) => /正在重新连接/.test(s.text)));
});

test("轮询循环：收到消息后转发 Agent，游标更新", async () => {
	const { bridgeCalls, bridge, client, store } = makeMocks({
		client: {
			getUpdates: async (token, buf) => {
				if (buf === "") return { msgs: [{ message_type: 1, from_user_id: USER, context_token: CTX, item_list: [{ type: 1, text_item: { text: "hello" } }] }], get_updates_buf: "cursor-1" };
				await longPollIdle();
				return null; // 长轮询超时（正常）
			},
		},
		store: {
			load: () => ({ token: "tk-1", baseUrl: "https://ilink.example", accountId: "bot-1" }),
		},
	});
	const channel = new ClawbotChannel({ client, store, bridge, config: defaultConfig(), logger: noopLogger });
	channel.attachBridgeCallbacks();
	await channel.start();
	await sleep(80);
	assert.deepEqual(bridgeCalls, [{ userId: USER, text: "hello" }]);
	assert.equal(channel.getUpdatesBuf, "cursor-1");
	await channel.stop();
});

test("会话过期：token 清除并自动重新登录", async () => {
	let qrCalls = 0;
	let expiredThrown = false;
	const { bridge, client, store } = makeMocks({
		client: {
			getBotQrcode: async () => {
				qrCalls++;
				return { qrcode: `qr-${qrCalls}`, qrcode_img_content: "https://wx/qr" };
			},
			getQrcodeStatus: async () => ({ status: "confirmed", bot_token: "tk-new", baseurl: "https://ilink.example" }),
			getUpdates: async () => {
				// 首次抛会话过期，重登录后正常长轮询（返回 null 表示超时）。
				if (!expiredThrown) {
					expiredThrown = true;
					const error = new Error("session timeout");
					error.code = -14;
					throw error;
				}
				await longPollIdle();
				return null;
			},
		},
		store: {
			load: () => ({ token: "tk-old", baseUrl: "https://ilink.example" }),
			cleared: false,
			clear() {
				this.cleared = true;
			},
		},
	});
	const channel = new ClawbotChannel({ client, store, bridge, config: defaultConfig({ qrcodeScanTimeoutMs: 5000 }), logger: noopLogger });
	channel.attachBridgeCallbacks();
	await channel.start();
	await sleep(120);
	assert.equal(store.cleared, true);
	assert.ok(qrCalls >= 1); // 重新登录获取了二维码
	assert.equal(channel.session.token, "tk-new");
	await channel.stop();
});

test("stop 打断轮询与重连循环", async () => {
	const { bridge, client, store } = makeMocks({
		client: { getUpdates: async () => { await longPollIdle(); return null; } },
		store: { load: () => ({ token: "tk-1", baseUrl: "https://ilink.example" }) },
	});
	const channel = new ClawbotChannel({ client, store, bridge, config: defaultConfig(), logger: noopLogger });
	await channel.start();
	await sleep(50);
	assert.equal(channel.running, true);
	await channel.stop();
	assert.equal(channel.running, false);
});
