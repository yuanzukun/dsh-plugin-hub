/**
 * iLink 协议客户端测试（mock fetch）。
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { IlinkClient, randomWechatUin, newClientId, ERR_SESSION_EXPIRED } from "../lib/ilink.js";

/** 构造一个返回脚本化响应的 fetch mock。 */
function mockFetch(responses) {
	const calls = [];
	let index = 0;
	const impl = async (url, options) => {
		calls.push({ url: String(url), options });
		const entry = responses[Math.min(index, responses.length - 1)];
		index++;
		if (entry instanceof Error) throw entry;
		if (entry === null) return null;
		return {
			ok: entry.ok ?? true,
			status: entry.status ?? 200,
			text: async () => (typeof entry.body === "string" ? entry.body : JSON.stringify(entry.body)),
		};
	};
	return { impl, calls };
}

const TOKEN = "tk-test";
const USER = "user_1@im.wechat";
const CTX = "ctx-abc";

test("getBotQrcode 返回 qrcode", async () => {
	const { impl, calls } = mockFetch([{ body: { qrcode: "qr-1", qrcode_img_content: "https://wx/qr" } }]);
	const client = new IlinkClient({ fetchImpl: impl });
	const qr = await client.getBotQrcode();
	assert.equal(qr.qrcode, "qr-1");
	assert.match(calls[0].url, /get_bot_qrcode\?bot_type=3/);
});

test("getBotQrcode 缺 qrcode 抛错", async () => {
	const { impl } = mockFetch([{ body: { ret: 0 } }]);
	const client = new IlinkClient({ fetchImpl: impl });
	await assert.rejects(() => client.getBotQrcode(), /missing qrcode/);
});

test("getUpdates 附加 base_info 并携带 token 鉴权头", async () => {
	const { impl, calls } = mockFetch([{ body: { ret: 0, msgs: [{ message_type: 1 }], get_updates_buf: "buf-2" } }]);
	const client = new IlinkClient({ fetchImpl: impl });
	const resp = await client.getUpdates(TOKEN, "buf-1", 38000);
	assert.deepEqual(resp.msgs, [{ message_type: 1 }]);
	assert.equal(resp.get_updates_buf, "buf-2");
	const [call] = calls;
	const body = JSON.parse(call.options.body);
	assert.deepEqual(body.base_info, { channel_version: "1.0.2" });
	assert.equal(body.get_updates_buf, "buf-1");
	assert.equal(call.options.headers.Authorization, `Bearer ${TOKEN}`);
	assert.equal(call.options.headers.AuthorizationType, "ilink_bot_token");
	assert.ok(call.options.headers["X-WECHAT-UIN"]);
	assert.ok(call.options.signal instanceof AbortSignal);
});

test("getUpdates ret 非 0 抛业务错误并带 code", async () => {
	const { impl } = mockFetch([{ body: { ret: -14, errmsg: "session expired" } }]);
	const client = new IlinkClient({ fetchImpl: impl });
	await assert.rejects(
		() => client.getUpdates(TOKEN, ""),
		(error) => error.code === ERR_SESSION_EXPIRED && /session expired/.test(error.message),
	);
});

test("getUpdates 长轮询超时返回 null", async () => {
	const abortError = new Error("aborted");
	abortError.name = "AbortError";
	const { impl } = mockFetch([abortError]);
	const client = new IlinkClient({ fetchImpl: impl });
	const resp = await client.getUpdates(TOKEN, "", 100);
	assert.equal(resp, null);
});

test("sendText 构造正确的 sendmessage 载荷", async () => {
	let captured;
	const { impl } = mockFetch([
		{
			body: { ret: 0 },
			// 捕获请求体
			capture: true,
		},
	]);
	const client = new IlinkClient({
		fetchImpl: async (url, options) => {
			captured = JSON.parse(options.body);
			return { ok: true, status: 200, text: async () => JSON.stringify({ ret: 0 }) };
		},
	});
	const clientId = await client.sendText(TOKEN, USER, CTX, "你好");
	assert.equal(typeof clientId, "string");
	assert.ok(clientId.startsWith("openclaw-weixin-"));
	assert.equal(captured.msg.to_user_id, USER);
	assert.equal(captured.msg.context_token, CTX);
	assert.equal(captured.msg.message_type, 2);
	assert.equal(captured.msg.message_state, 2);
	assert.deepEqual(captured.msg.item_list, [{ type: 1, text_item: { text: "你好" } }]);
	assert.deepEqual(captured.base_info, { channel_version: "1.0.2" });
	assert.ok(captured.msg.client_id);
});

test("getConfig 与 sendTyping 载荷", async () => {
	const calls = [];
	const { impl } = mockFetch([
		{ body: { ret: 0, typing_ticket: "ticket-1" } },
		{ body: { ret: 0 } },
	]);
	const client = new IlinkClient({
		fetchImpl: async (url, options) => {
			calls.push(JSON.parse(options.body));
			return { ok: true, status: 200, text: async () => JSON.stringify(calls.length === 1 ? { ret: 0, typing_ticket: "ticket-1" } : { ret: 0 }) };
		},
	});
	const ticket = await client.getConfig(TOKEN, USER, CTX);
	assert.equal(ticket, "ticket-1");
	assert.deepEqual(calls[0], { ilink_user_id: USER, context_token: CTX, base_info: { channel_version: "1.0.2" } });
	await client.sendTyping(TOKEN, USER, ticket, 1);
	assert.deepEqual(calls[1], { ilink_user_id: USER, typing_ticket: "ticket-1", status: 1, base_info: { channel_version: "1.0.2" } });
});

test("extractText 覆盖各消息类型", () => {
	assert.equal(IlinkClient.extractText({ item_list: [{ type: 1, text_item: { text: "hi" } }] }), "hi");
	assert.equal(IlinkClient.extractText({ item_list: [{ type: 3, voice_item: { text: "语音转文字" } }] }), "[语音] 语音转文字");
	assert.equal(IlinkClient.extractText({ item_list: [{ type: 3 }] }), "[语音]");
	assert.equal(IlinkClient.extractText({ item_list: [{ type: 2 }] }), "[图片]");
	assert.equal(IlinkClient.extractText({ item_list: [{ type: 4, file_item: { file_name: "a.pdf" } }] }), "[文件] a.pdf");
	assert.equal(IlinkClient.extractText({ item_list: [{ type: 5 }] }), "[视频]");
	assert.equal(IlinkClient.extractText({ item_list: [] }), "");
});

test("isGroupMessage 判定", () => {
	assert.equal(IlinkClient.isGroupMessage({ group_id: "g1" }), true);
	assert.equal(IlinkClient.isGroupMessage({ from_user_id: "u1@im.wechat" }), false);
});

test("randomWechatUin / newClientId 格式", () => {
	const uin = randomWechatUin();
	const decoded = Buffer.from(uin, "base64").toString("utf-8");
	assert.ok(/^\d+$/.test(decoded));
	assert.match(newClientId(), /^openclaw-weixin-[0-9a-f]{16}$/);
});
