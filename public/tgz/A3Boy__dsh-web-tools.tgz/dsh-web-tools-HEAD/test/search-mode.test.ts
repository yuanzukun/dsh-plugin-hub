/**
 * dsh-web-tools — Search Mode runtime state model tests (pure, no DSH/pnpm).
 *
 * Covers the behavior table demanded by the "联网搜索" feature: auto leaves the
 * turn free, required freezes the flag per turn, a completed web_search (even
 * a failed one) satisfies the requirement, mid-turn flips only affect the next
 * turn, and sessions never pollute each other.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { pathToFileURL } from "node:url";
import {
  SearchModeRuntime,
  createSearchModeMessages,
  searchModeStepMessage,
  webResearchCompleted,
  REQUIRED_SEARCH_TEXT,
  REQUIRED_SEARCH_CORRECTION_TEXT,
  type TurnState,
} from "../src/host/search-mode-runtime.ts";

function runtime(available = true): SearchModeRuntime {
  return new SearchModeRuntime(() => available);
}

test("default mode is auto and does not mark a turn required", () => {
  const r = runtime();
  assert.equal(r.getMode("s1"), "auto");
  const turn = r.beginTurn("s1", 1);
  assert.equal(turn.required, false);
  assert.equal(turn.webSearchCompleted, false);
});

test("setMode(required) freezes the flag for the CURRENT turn only", () => {
  const r = runtime();
  r.setMode("s1", "required");
  const t17 = r.beginTurn("s1", 17);
  assert.equal(t17.required, true);
  // Mid-turn flip to auto does NOT change the already-begun turn (no race).
  r.setMode("s1", "auto");
  const same17 = r.beginTurn("s1", 17);
  assert.equal(same17.required, true, "frozen for the in-flight turn");
  // A NEW turn reads the updated mode.
  const t18 = r.beginTurn("s1", 18);
  assert.equal(t18.required, false);
});

test("markSearchResult: a completed search (even failure) satisfies the requirement", () => {
  const r = runtime();
  r.setMode("s1", "required");
  r.beginTurn("s1", 5);
  assert.equal(r.getTurn("s1")?.webSearchCompleted, false);
  // All-provider failure is still "tried".
  r.markSearchResult("s1", false);
  const state = r.getTurn("s1");
  assert.equal(state?.webSearchCompleted, true, "failure still counts as completed");
  assert.equal(state?.webSearchSucceeded, false);
});

test("markSearchResult success records succeeded", () => {
  const r = runtime();
  r.setMode("s1", "required");
  r.beginTurn("s1", 1);
  r.markSearchResult("s1", true);
  assert.equal(r.getTurn("s1")?.webSearchCompleted, true);
  assert.equal(r.getTurn("s1")?.webSearchSucceeded, true);
});

test("markFetchResult: a completed fetch (even failure) satisfies the requirement", () => {
  const r = runtime();
  r.setMode("s1", "required");
  r.beginTurn("s1", 5);
  assert.equal(r.getTurn("s1")?.webFetchCompleted, false);
  r.markFetchResult("s1", false);
  const state = r.getTurn("s1");
  assert.equal(state?.webFetchCompleted, true, "failure still counts as completed");
  assert.equal(state?.webFetchSucceeded, false);
  assert.equal(webResearchCompleted(state!), true, "a fetch alone completes web research");
});

test("markFetchResult success records succeeded", () => {
  const r = runtime();
  r.setMode("s1", "required");
  r.beginTurn("s1", 1);
  r.markFetchResult("s1", true);
  assert.equal(r.getTurn("s1")?.webFetchCompleted, true);
  assert.equal(r.getTurn("s1")?.webFetchSucceeded, true);
  assert.equal(webResearchCompleted(r.getTurn("s1")!), true);
});

test("correction counter increments on steer (no infinite loop), then cancel path", () => {
  const r = runtime();
  r.setMode("s1", "required");
  const state = r.beginTurn("s1", 3);
  assert.equal(state.correctionCount, 0);
  state.correctionCount += 1; // first steer
  assert.equal(state.correctionCount, 1);
  state.correctionCount += 1; // second offense → runtime.cancel is called upstream
  assert.equal(state.correctionCount, 2);
});

test("sessions never pollute each other", () => {
  const r = runtime();
  r.setMode("A", "required");
  assert.equal(r.getMode("B"), "auto");
  r.beginTurn("A", 1);
  r.markSearchResult("A", true);
  assert.equal(r.getTurn("B"), undefined);
  assert.equal(r.getMode("A"), "required");
});

test("required persists across turns in the same session", () => {
  const r = runtime();
  r.setMode("s1", "required");
  assert.equal(r.beginTurn("s1", 1).required, true);
  assert.equal(r.beginTurn("s1", 2).required, true);
});

test("setMode(auto) clears the entry back to auto", () => {
  const r = runtime();
  r.setMode("s1", "required");
  r.setMode("s1", "auto");
  assert.equal(r.getMode("s1"), "auto");
  assert.equal(r.beginTurn("s1", 1).required, false);
});

test("clear drops mode and turn state (agent disposed)", () => {
  const r = runtime();
  r.setMode("s1", "required");
  r.beginTurn("s1", 1);
  r.clear("s1");
  assert.equal(r.getMode("s1"), "auto");
  assert.equal(r.getTurn("s1"), undefined);
});

test("view reports mode and availability", () => {
  const r = runtime(false);
  r.setMode("s1", "required");
  assert.deepEqual(r.view("s1"), { mode: "required", available: false });
  const r2 = runtime(true);
  r2.setMode("s1", "required");
  assert.deepEqual(r2.view("s1"), { mode: "required", available: true });
});

// ---- hosted message shape (official createUserMessage contract) ------------

/** Capture the exact input the official createUserMessage would receive. */
function captureFactory() {
  const calls: any[] = [];
  const createUserMessage = (input: any) => {
    calls.push(input);
    return { __built: input };
  };
  return { calls, createUserMessage };
}

test("required message is a plugin snapshot section carrying REQUIRED_SEARCH_TEXT", () => {
  const { calls, createUserMessage } = captureFactory();
  const messages = createSearchModeMessages(createUserMessage);
  const built = messages.required();
  assert.equal(calls.length, 1);
  const input = calls[0];
  assert.ok(Array.isArray(input.content));
  assert.equal(input.content[0].type, "text");
  assert.equal(input.content[0].text, REQUIRED_SEARCH_TEXT);
  assert.equal(input.source.kind, "plugin:dsh-web-tools");
  assert.equal(input.source.plugin, "dsh-web-tools");
  assert.equal(input.source.form, "snapshot");
  assert.equal(input.source.sections[0].name, "web-search-mode");
  assert.equal(input.source.sections[0].text, REQUIRED_SEARCH_TEXT);
  assert.ok(REQUIRED_SEARCH_TEXT.includes("complete at least one web_search or web_fetch call"),
    "the one-shot notice must state the hard research requirement");
  assert.ok(REQUIRED_SEARCH_TEXT.includes("Use web_fetch for a specific URL"),
    "URL routing guidance must mention web_fetch");
  assert.ok(REQUIRED_SEARCH_TEXT.includes("otherwise use web_search"),
    "non-URL routing guidance must mention web_search");
  assert.ok(REQUIRED_SEARCH_TEXT.includes("use exactly one routing prefix"),
    "platform targeting must distinguish the routing marker from topic keywords");
  assert.ok(REQUIRED_SEARCH_TEXT.includes("not page details or comments"),
    "search snippets must not be represented as fetched comments");
  assert.ok(REQUIRED_SEARCH_TEXT.includes("only when web_fetch returns their contents"),
    "verified comment claims must be grounded in fetched comment content");
});

test("correction message is a one-shot plugin notice (not a snapshot)", () => {
  const { calls, createUserMessage } = captureFactory();
  const messages = createSearchModeMessages(createUserMessage);
  messages.correction();
  assert.equal(calls.length, 1);
  const input = calls[0];
  assert.equal(input.content[0].text, REQUIRED_SEARCH_CORRECTION_TEXT);
  assert.equal(input.source.kind, "plugin:dsh-web-tools");
  assert.equal(input.source.plugin, "dsh-web-tools");
  assert.equal(input.source.form, "notice");
  assert.equal(input.source.summary, "Web Search required");
});

test("search mode messages are admitted by session format v4 codec", async () => {
  const codecCandidates = [
    process.env.DSH_TOOL_WEB_NM && `${process.env.DSH_TOOL_WEB_NM}/dsh-session-format-v3-to-v4/lib/index.js`,
    "D:/Develop/nvm/v22.22.1/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-session-format-v3-to-v4/lib/index.js",
  ].filter(Boolean) as string[];

  let codec: any = null;
  for (const p of codecCandidates) {
    if (existsSync(p)) {
      const mod = await import(pathToFileURL(p).href);
      codec = mod.releasedV4SessionFormatCodec;
      break;
    }
  }

  const { calls, createUserMessage } = captureFactory();
  const messages = createSearchModeMessages(createUserMessage);
  const req = messages.required();
  const corr = messages.correction();

  assert.equal((calls[0].source as any).kind, "plugin:dsh-web-tools");
  assert.equal((calls[1].source as any).kind, "plugin:dsh-web-tools");

  if (codec) {
    assert.doesNotThrow(() => {
      codec.encodeEvent({ type: "user/message", seq: 1, time: Date.now(), data: req });
    });
    assert.doesNotThrow(() => {
      codec.encodeEvent({ type: "user/message", seq: 2, time: Date.now(), data: corr });
    });
  }
});

// ---- one-shot pre-step message policy --------------------------------------

function turnState(overrides: Partial<TurnState> = {}): TurnState {
  return {
    turn: 1,
    required: true,
    webSearchCompleted: false,
    webSearchSucceeded: false,
    webFetchCompleted: false,
    webFetchSucceeded: false,
    correctionCount: 0,
    ...overrides,
  };
}

test("pre-step step 1 injects the compact research policy (required)", () => {
  const messages = createSearchModeMessages(() => "M");
  assert.equal(searchModeStepMessage(turnState(), 1, messages), "M");
});

test("pre-step later steps inject NOTHING (before search completes)", () => {
  const messages = createSearchModeMessages(() => "M");
  const out = searchModeStepMessage(turnState({ webSearchCompleted: false }), 2, messages);
  assert.equal(out, undefined, "no reminder before research — enforcement is turn-stopping");
});

test("pre-step later steps inject NOTHING (after search succeeds)", () => {
  const messages = createSearchModeMessages(() => "M");
  const out = searchModeStepMessage(turnState({ webSearchCompleted: true, webSearchSucceeded: true }), 3, messages);
  assert.equal(out, undefined, "no grounding after success — tool result is the freshest context");
});

test("pre-step later steps inject NOTHING (after a fetch succeeds)", () => {
  const messages = createSearchModeMessages(() => "M");
  const out = searchModeStepMessage(turnState({ webFetchCompleted: true, webFetchSucceeded: true }), 3, messages);
  assert.equal(out, undefined);
});

test("pre-step later steps inject NOTHING (after search attempted and FAILED)", () => {
  const messages = createSearchModeMessages(() => "M");
  const out = searchModeStepMessage(turnState({ webSearchCompleted: true, webSearchSucceeded: false }), 3, messages);
  assert.equal(out, undefined, "no failed notice — the failure is already a tool result");
});

test("webResearchCompleted is true when EITHER search or fetch completed", () => {
  assert.equal(webResearchCompleted(turnState()), false);
  assert.equal(webResearchCompleted(turnState({ webSearchCompleted: true })), true);
  assert.equal(webResearchCompleted(turnState({ webFetchCompleted: true })), true);
  assert.equal(webResearchCompleted(turnState({ webSearchCompleted: true, webFetchCompleted: true })), true);
});

test("pre-step injects nothing when the turn is not in required mode", () => {
  const messages = createSearchModeMessages(() => "M");
  assert.equal(searchModeStepMessage(turnState({ required: false }), 1, messages), undefined);
  assert.equal(searchModeStepMessage(turnState({ required: false, webSearchCompleted: true }), 2, messages), undefined);
  assert.equal(searchModeStepMessage(undefined, 1, messages), undefined);
});

// ---- identity authority: UI sessionId drives the same Agent runtime --------

test("a UI/route setMode(sessionId, required) makes that session's Agent turn required", () => {
  const r = runtime();
  // This is exactly what the /search-mode/set route does with the sessionId the
  // conversation slot provides (identical to agent.id — one Session per Agent).
  const sessionIdFromConversationSlot = "sess-abc";
  r.setMode(sessionIdFromConversationSlot, "required");
  // The Agent runtime keys turn state by agent.id === session.id; here the same
  // string is used, so beginTurn() sees the required flag.
  const agentId = sessionIdFromConversationSlot;
  const turn = r.beginTurn(agentId, 7);
  assert.equal(turn.required, true);
});

test("slash /search and the UI button write the same runtime", () => {
  const r = runtime();
  const id = "sess-xyz";
  // UI button path (searchMode.set) and /search handler both call setMode(key).
  r.setMode(id, "required");
  assert.equal(r.getMode(id), "required");
  // /search toggles: required → auto
  r.setMode(id, r.getMode(id) === "required" ? "auto" : "required");
  assert.equal(r.getMode(id), "auto");
});
