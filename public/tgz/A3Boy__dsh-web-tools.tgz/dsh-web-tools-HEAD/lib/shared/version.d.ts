/** Version shipped by this plugin build. Keep in sync with package.json. */
export declare const CURRENT_VERSION = "0.5.2";
export declare function compareVersions(left: string, right: string): number;
