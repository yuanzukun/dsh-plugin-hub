import { type SearchRoutingPolicy } from "./routing-policy.ts";
import { type RetrievalStrategy } from "../shared/api-types.ts";
import { PoolEntry } from "./pool.ts";
import type { StoredProviderOptions } from "../shared/provider-options.ts";
import type { ProviderHealthStore } from "./provider-health.ts";
import { fetchGenericWebPage } from "./generic-fetch.ts";
import type { ProviderSnapshot } from "./custom-provider-registry.ts";
/** Stable provider id registered on ctx.web (the `web` row's searchProvider). */
export declare const PROVIDER_ID = "dsh-web-tools";
/** Structural mirror of the seam's WebSearchProvider contract. */
export interface WebSearchProviderLike {
    id: string;
    available(): boolean;
    search(request: {
        query: string;
        maxResults?: number;
        sort?: string;
        sortBy?: string;
    }, signal?: AbortSignal): Promise<{
        content?: string;
        sources: Array<{
            url: string;
            title?: string;
            snippet?: string;
            summary?: string;
            publishedAt?: string;
        }>;
        truncated: boolean;
        /** Which provider(s) served the answer (`a+b` for a fused answer). */
        backend?: string;
        /** Per-provider attempt ledger (diagnostics / settings card). */
        attempts?: Array<{
            provider: string;
            outcome: string;
            latencyMs?: number;
        }>;
        /** True when the result merged two providers with RRF. */
        fused?: boolean;
        /** Set when a platform query was served by a general web fallback. */
        degraded?: {
            code: string;
            message: string;
            platform?: string;
        };
        /** Channel diagnostics (why a platform fast path was skipped). */
        diagnostics?: string[];
    }>;
}
export interface WebFetchResponse {
    url: string;
    statusCode: number;
    body: {
        kind: "html" | "text";
        content: string;
    };
    truncated: boolean;
    backend?: string;
    metadata?: {
        title?: string;
        author?: string;
        publishedAt?: string;
        description?: string;
    };
}
/** Structural mirror of the seam's WebFetchProvider contract. */
export interface WebFetchProviderLike {
    id: string;
    available(): boolean;
    fetch(request: {
        url: string;
    }, signal?: AbortSignal): Promise<WebFetchResponse>;
}
/** A classified failure the executor throws (WebError-compatible shape). */
export declare class WebToolsWebError extends Error {
    code: string;
    attempts?: Array<{
        provider: string;
        outcome: string;
        latencyMs?: number;
    }>;
}
/** Runtime configuration resolved per search (snapshot per operation). */
export interface WebToolsRuntimeConfig {
    enabled: boolean;
    defaultProvider: string;
    /** Per-attempt budget for ONE provider call (the DSH tool owns the overall timeout). */
    providerAttemptTimeoutMs: number;
    fallbackOrder: string[];
    /** Search routing policy — how the runtime picks the starting provider per query. */
    searchRoutingPolicy?: SearchRoutingPolicy;
    /** Cross-provider retrieval strategy (single/hedged/fused). */
    retrievalStrategy?: RetrievalStrategy;
    /** Hedged mode only: delay before the second lane starts. Default 1200ms. */
    hedgeDelayMs?: number;
    providerBaseUrls: Record<string, string>;
    enabledProviders: Record<string, boolean>;
    providerOptions?: StoredProviderOptions;
}
/** Live per-provider key pools, keyed by provider name. */
export type Pools = Record<string, PoolEntry[]>;
/**
 * Shared credential pool store. One instance per plugin; Search and Fetch
 * executors share it so they never fight over separate pools.
 *
 * - Rebuilds a provider's pool ONLY when its credential string changed
 *   (avoids the concurrent-search race of replacing entries out from under an
 *   in-flight request).
 * - Preserves uses/health for keys that persist across rebuilds.
 * - markUsed/markUnhealthy mutate the stable entries array in place.
 */
export declare function createPoolStore(resolveKeys: (providerName: string) => Promise<string>): {
    poolOf: (providerName: string) => Promise<PoolEntry[]>;
    forget: (providerName: string) => void;
};
export type PoolStore = ReturnType<typeof createPoolStore>;
/** Structural subset of a provider adapter the executor needs (injectable). */
export interface ProviderAdapterLike {
    name: string;
    needsBaseUrl: boolean;
    fetchCapable: boolean;
    search(query: string, maxResults: number | undefined, apiKey: string, baseUrl: string | undefined, contextOrSignal?: AbortSignal | {
        signal?: AbortSignal;
        options?: unknown;
        hints?: unknown;
    }): Promise<{
        sources: Array<{
            url: string;
            title?: string;
            snippet?: string;
            publishedAt?: string;
        }>;
    }>;
    fetch(url: string, apiKey: string, baseUrl: string | undefined, contextOrSignal?: AbortSignal | {
        signal?: AbortSignal;
        options?: unknown;
        hints?: unknown;
    }): Promise<{
        text: string;
    }>;
}
/** Build a WebToolsSearchProvider for `ctx.web.registerSearchProvider`.
 *  `adapterRegistry` is injectable for tests; production uses the global
 *  PROVIDERS map (passed by index.ts via the default).
 *
 *  `resolveSnapshot` is the Issue #9 seam: when supplied, EVERY request reads
 *  one immutable catalog snapshot up front and takes adapters, credentials,
 *  endpoint overrides and keyless-ness from it. A config edit mid-flight can
 *  therefore never swap an adapter out from under the request. */
export declare function createSearchProvider(resolveConfig: () => WebToolsRuntimeConfig, resolveKeys: (providerName: string) => Promise<string>, stats: {
    record: (entry: {
        provider: string;
        outcome: string;
        latencyMs: number;
    }) => void;
    summary?: () => {
        byProvider: Record<string, import("./routing-policy.ts").ProviderMetrics>;
    };
}, adapterRegistry?: Record<string, ProviderAdapterLike>, poolStore?: PoolStore, healthStore?: ProviderHealthStore, resolveSnapshot?: () => ProviderSnapshot): WebSearchProviderLike;
/**
 * Build a `WebFetchProvider` for `ctx.web.registerFetchProvider`.
 * Routes fetch through configured native fetch providers (Tavily, Exa, Jina,
 * Firecrawl, Parallel) when available/healthy, and deterministically falls
 * back to the built-in generic HTTP fetcher (with SSRF guard + Defuddle Markdown
 * parsing) when native providers are unavailable, keyless, or fail.
 */
export declare function createFetchProvider(resolveConfig: () => WebToolsRuntimeConfig, resolveKeys: (providerName: string) => Promise<string>, adapterRegistry?: Record<string, ProviderAdapterLike>, poolStore?: PoolStore, healthStore?: ProviderHealthStore, genericFetcher?: typeof fetchGenericWebPage, resolveSnapshot?: () => ProviderSnapshot, stats?: {
    record: (entry: {
        provider: string;
        outcome: string;
        latencyMs: number;
    }) => void;
}): WebFetchProviderLike;
/**
 * Best-effort page title from provider-extracted Markdown.
 *
 * Native extraction endpoints (Tavily/Exa/Firecrawl/Parallel/Jina) return a
 * Markdown body with no metadata block. The first ATX heading is the only
 * reliable signal; when there is none we return undefined rather than guessing
 * a title from prose (a first paragraph makes a terrible title).
 */
export declare function inferTitleFromMarkdown(text: string): string | undefined;
