import { CdpClient } from "./cdp/client.ts";
import { type LiveSessionVerifier } from "./live-auth-verifier.ts";
import { type SpawnedBrowserProcess } from "./process-manager.ts";
import type { BrowserInfo, BrowserPlatform, BrowserRunMode, BrowserSessionStatus, CdpPageLease, NativeBrowserRuntime } from "./types.ts";
export type ProcessLauncher = (browser: BrowserInfo, profileDir: string, initialUrl?: string, minimized?: boolean, headless?: boolean) => Promise<SpawnedBrowserProcess>;
export type CdpClientFactory = (port: number, signal?: AbortSignal) => Promise<CdpClient>;
export type PidChecker = (pid: number) => boolean;
export type PidKiller = (pid: number) => void;
export declare class SessionManager implements NativeBrowserRuntime {
    private records;
    private profileStore;
    private stateStore;
    private readonly browserChoice;
    private readonly idleShutdownMs;
    private readonly launcher;
    private readonly cdpFactory;
    private readonly isPidAliveFn;
    private readonly killPidFn;
    private readonly liveSessionVerifier;
    private disposed;
    constructor(browserChoice?: "auto" | "edge" | "chrome" | string, baseDirOverride?: string, idleShutdownMs?: number, launcher?: ProcessLauncher, cdpFactory?: CdpClientFactory, isPidAliveFn?: PidChecker, killPidFn?: PidKiller, liveSessionVerifier?: LiveSessionVerifier);
    private getRecord;
    private enqueue;
    detect(): Promise<BrowserInfo | null>;
    checkAuthentication(platform: BrowserPlatform): Promise<boolean>;
    verifyAuthenticationForOperation(platform: BrowserPlatform, signal?: AbortSignal, mode?: BrowserRunMode): Promise<boolean>;
    private internalCheckAuth;
    private hasRequiredCookies;
    status(platform: BrowserPlatform): Promise<BrowserSessionStatus>;
    login(platform: BrowserPlatform, signal?: AbortSignal): Promise<BrowserSessionStatus>;
    private prepareInteractiveLogin;
    openPage(platform: BrowserPlatform, url: string, signal?: AbortSignal, mode?: BrowserRunMode): Promise<CdpPageLease>;
    createPage(platform: BrowserPlatform, signal?: AbortSignal, mode?: BrowserRunMode): Promise<CdpPageLease>;
    /**
     * Close every existing page that belongs to the platform origin.
     *
     * Called right before we open our own tab, so a search always starts from a
     * clean window: leftover tabs from a previous operation (or from Edge
     * restoring a crashed session) are removed. Internal new-tab pages are left
     * untouched — closing the last tab would terminate the browser.
     */
    private closePlatformPagesInternal;
    /** Public wrapper: close platform tabs (optionally keeping one target). */
    closePlatformPages(platform: BrowserPlatform, keepTargetId?: string, signal?: AbortSignal): Promise<void>;
    private retainLease;
    private releaseLease;
    private scheduleIdleTimer;
    private acquireSession;
    private internalStop;
    stop(platform: BrowserPlatform): Promise<void>;
    resetSession(platform: BrowserPlatform): Promise<void>;
    dispose(): Promise<void>;
}
