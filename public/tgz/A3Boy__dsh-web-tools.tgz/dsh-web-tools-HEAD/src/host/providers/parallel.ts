/**
 * dsh-web-tools — Parallel provider adapter (8th adapter).
 *
 * Parallel is an agent-native web tools API: Search returns LLM-ranked
 * compressed excerpts, Extract returns page bodies as markdown.
 *
 * Search  : POST https://api.parallel.ai/v1/search
 *           x-api-key: <apiKey>, Content-Type: application/json
 *           body { objective, search_queries[], mode, advanced_settings }
 *           → results[] (url / title / publish_date / excerpts[])
 * Extract : POST https://api.parallel.ai/v1/extract
 *           body { urls[], advanced_settings: { full_content: true } }
 *           → results[] (url / title / excerpts[] / full_content)
 *
 * First-version scope (frozen):
 *   - REST only — the anonymous Search MCP endpoint is intentionally NOT
 *     wired into the provider (two auth semantics in one adapter would be
 *     confusing);
 *   - mode set to "advanced" (deep agent-optimized retrieval, official default);
 *   - no session_id (optional upstream; correlating search→extract runs
 *     would need per-run state this plugin deliberately avoids);
 *   - quota is dashboard-only — Parallel exposes usage/spend in its
 *     Platform dashboard, not through a balance endpoint an ordinary API
 *     key can call.
 * @module
 */
import { providerError, throwIfHttp, resolveContext, type ProviderAdapter, type Source } from "./types.ts";
import { fetchWithProxy } from "../fetch-proxy.ts";
import { endpointViewOf } from "../endpoints.ts";
import type { ParallelProviderOptions } from "../../shared/provider-options.ts";
import type { SearchHints } from "../search-hints.ts";

const PARALLEL_SEARCH_URL = "https://api.parallel.ai/v1/search";
const PARALLEL_EXTRACT_URL = "https://api.parallel.ai/v1/extract";

/** Parallel caps max_results at 20 per search. */
const PARALLEL_MAX_RESULTS = 20;

/** Each entry in search_queries may be at most 200 characters. */
const PARALLEL_QUERY_MAX_CHARS = 200;

/** Snippet budget: excerpts are dense but several may add up — cap the joined text. */
const PARALLEL_SNIPPET_MAX_CHARS = 500;

export const PARALLEL_META = {
  name: "parallel",
  label: "Parallel",
  description: "Agent-optimized search + extract (LLM-ranked excerpts)",
  credSuffix: "PARALLEL",
  fetchCapable: true,
  needsBaseUrl: false,
} as const;

export const ParallelProvider: ProviderAdapter = {
  ...PARALLEL_META,

  async search(query, maxResults, apiKey, baseUrl, contextOrSignal) {
    const token = (apiKey ?? "").trim();
    if (!token) throw providerError("config", "Parallel API key is not configured");
    const { signal, options, hints } = resolveContext<ParallelProviderOptions>(contextOrSignal);
    const count = clampParallelCount(maxResults);
    const searchUrl = endpointViewOf("parallel", { parallel: baseUrl })?.url ?? PARALLEL_SEARCH_URL;
    const res = await fetchWithProxy(searchUrl, {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": token },
      body: JSON.stringify(buildParallelSearchBody(query, count, options, hints)),
      signal,
    }, { provider: "parallel" });
    throwIfHttp("Parallel", res);
    let raw: unknown;
    try {
      raw = await res.json();
    } catch {
      throw providerError("invalid-response", "Parallel returned invalid JSON");
    }
    return { sources: parseParallelSearchResults(raw, count) };
  },

  async fetch(url, apiKey, _baseUrl, contextOrSignal) {
    const { signal } = resolveContext(contextOrSignal);
    const token = (apiKey ?? "").trim();
    if (!token) throw providerError("config", "Parallel API key is not configured");
    // full_content must be explicitly requested — Extract defaults to
    // excerpts-only, which would return a snippet where web_fetch wants the
    // page body.
    const res = await fetchWithProxy(PARALLEL_EXTRACT_URL, {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": token },
      body: JSON.stringify({ urls: [url], advanced_settings: { full_content: true } }),
      signal,
    }, { provider: "parallel" });
    throwIfHttp("Parallel", res);
    let raw: unknown;
    try {
      raw = await res.json();
    } catch {
      throw providerError("invalid-response", "Parallel Extract returned invalid JSON");
    }
    const text = parseParallelExtractText(raw);
    if (!text) throw providerError("server", `Parallel Extract returned no content for ${url}`);
    return { text };
  },
};

/** Clamp the requested result count into Parallel's accepted range (1..20). */
export function clampParallelCount(maxResults: number | undefined): number {
  return Math.min(Math.max(maxResults ?? 5, 1), PARALLEL_MAX_RESULTS);
}

/**
 * Normalize one raw query into a Parallel search_queries entry: whitespace
 * collapsed, trimmed, and capped at 200 characters (the per-query API limit).
 */
export function normalizeParallelQuery(query: string): string {
  return query.replace(/\s+/g, " ").trim().slice(0, PARALLEL_QUERY_MAX_CHARS);
}

/**
 * Build the /v1/search request body. `objective` carries the natural
 * language goal (with soft steering for preferred sources); `search_queries`
 * carries clean keyword queries without syntax junk. `advanced_settings`
 * carries hard constraints (source_policy, max_results).
 */
export function buildParallelSearchBody(
  query: string,
  count: number,
  options?: Readonly<ParallelProviderOptions>,
  hints?: Readonly<SearchHints>,
): Record<string, unknown> {
  let objective = query;
  const cleanQ = hints?.cleanQuery ? hints.cleanQuery : query;

  // Soft steering via objective (Parallel official best practice)
  if (hints?.domains?.preferOfficial) {
    objective += "\nPrefer primary documentation and official sources when available.";
  } else if (hints?.domains?.prefer && hints.domains.prefer.length > 0 && !hints.domains.include) {
    objective += `\nPrefer sources from: ${hints.domains.prefer.join(", ")}.`;
  }

  // Advanced settings & source policy
  const advancedSettings: Record<string, unknown> = {
    max_results: count,
  };

  const sourcePolicy: Record<string, unknown> = {};
  if (hints?.domains?.include && hints.domains.include.length > 0) {
    sourcePolicy.include_domains = hints.domains.include;
  }
  if (hints?.domains?.exclude && hints.domains.exclude.length > 0) {
    sourcePolicy.exclude_domains = hints.domains.exclude;
  }
  if (hints?.freshness?.after) {
    sourcePolicy.after_date = hints.freshness.after;
  }

  if (Object.keys(sourcePolicy).length > 0) {
    advancedSettings.source_policy = sourcePolicy;
  }

  const body: Record<string, unknown> = {
    objective,
    search_queries: [normalizeParallelQuery(cleanQ)],
    mode: options?.mode ?? "advanced",
    advanced_settings: advancedSettings,
  };

  // max_chars_total is a top-level /v1/search field (docs.parallel.ai).
  if (typeof options?.maxCharsTotal === "number") {
    body.max_chars_total = options.maxCharsTotal;
  }
  return body;
}

/**
 * Parse Parallel's search envelope ({ results: [...] }) into normalized
 * sources. `url` is required per item; `excerpts` (an array of LLM-ranked
 * compressed passages) are joined into the snippet and capped so a multi-
 * excerpt result cannot balloon the DSH search payload.
 */
export function parseParallelSearchResults(body: unknown, maxResults: number): Source[] {
  const results = (body as { results?: unknown } | null)?.results;
  if (!Array.isArray(results)) return [];
  const sources: Source[] = [];
  for (const item of results) {
    if (sources.length >= maxResults) break;
    if (!item || typeof item !== "object") continue;
    const { url, title, publish_date, excerpts } = item as {
      url?: unknown;
      title?: unknown;
      publish_date?: unknown;
      excerpts?: unknown;
    };
    if (typeof url !== "string" || url.length === 0) continue;
    const source: Source = { url };
    if (typeof title === "string" && title) source.title = title;
    const excerptText = Array.isArray(excerpts)
      ? excerpts
          .filter((x): x is string => typeof x === "string")
          .join("\n\n")
          .trim()
      : "";
    if (excerptText) source.snippet = excerptText.slice(0, PARALLEL_SNIPPET_MAX_CHARS);
    if (typeof publish_date === "string" && publish_date) source.publishedAt = publish_date;
    sources.push(source);
  }
  return sources;
}

/**
 * Extract the page text from Parallel's extract envelope. Prefers
 * `full_content` (only present when requested); falls back to the joined
 * excerpts. Returns undefined when neither carries usable text — the caller
 * classifies that as a server failure.
 */
export function parseParallelExtractText(body: unknown): string | undefined {
  const results = (body as { results?: unknown } | null)?.results;
  const first = Array.isArray(results) ? results[0] : undefined;
  if (!first || typeof first !== "object") return undefined;
  const { full_content, excerpts } = first as { full_content?: unknown; excerpts?: unknown };
  if (typeof full_content === "string" && full_content.trim()) return full_content;
  if (Array.isArray(excerpts)) {
    const text = excerpts
      .filter((x): x is string => typeof x === "string")
      .join("\n\n")
      .trim();
    if (text) return text;
  }
  return undefined;
}
