/**
 * dsh-web-tools — SearXNG provider adapter (self-hosted, keyless option).
 * Queries the local instance's JSON output (GET {baseUrl}/search?format=json).
 * SSRF guard: refuses private/loopback targets unless the operator explicitly
 * opts in (self-hosted SearXNG on localhost is the normal case, so the guard
 * applies to the search TARGET, not the instance URL — the instance URL is
 * operator-configured and trusted by definition).
 * @module
 */
import { providerError, resolveContext, type ProviderAdapter, type SearchOutcome } from "./types.ts";
import { fetchWithProxy } from "../fetch-proxy.ts";
import { joinUrl } from "../endpoints.ts";
import type { SearchHints } from "../search-hints.ts";

export const SEARXNG_META = {
  name: "searxng",
  label: "SearXNG",
  description: "Self-hosted metasearch (JSON output)",
  credSuffix: "SEARXNG",
  fetchCapable: false,
  needsBaseUrl: true,
  defaultBaseUrl: "http://127.0.0.1:8080",
} as const;

/**
 * A SearXNG credential written `user:password` means HTTP Basic — the form
 * that reverse proxies guarding a self-hosted instance require, and the one
 * the retired dsh-search-failover backend accepted. Anything else is passed
 * on as the `api_key` query parameter.
 *
 * Basic is NOT optional here: `api_key` in the query string cannot satisfy a
 * proxy, and `fetch()` refuses a URL carrying userinfo
 * ("Request cannot be constructed from a URL that includes credentials"), so
 * there is no config-only workaround.
 */
export function buildSearxngAuth(apiKey?: string): {
  headers: Record<string, string>;
  queryKey?: string;
} {
  if (!apiKey) return { headers: {} };
  const separator = apiKey.indexOf(":");
  if (separator <= 0) return { headers: {}, queryKey: apiKey };
  const encoded = Buffer.from(apiKey, "utf8").toString("base64");
  return { headers: { authorization: `Basic ${encoded}` } };
}

/**
 * Build SearXNG URL parameters based on query, options, and SearchHints.
 * Maps:
 *  - topic=code → categories=it
 *  - topic=research → categories=science
 *  - topic=news → categories=news
 *  - freshness preset → time_range: "day" | "month" | "year"
 *  - language → language (e.g. "zh-CN", "en")
 */
export function buildSearxngUrl(
  instanceUrl: string,
  query: string,
  apiKey?: string,
  hints?: Readonly<SearchHints>,
): URL {
  // Prefix-preserving join: a reverse proxy mounted at /searxng must keep that
  // prefix (a root-relative "/search" would drop it).
  const url = new URL(joinUrl(instanceUrl, "search"));
  const cleanQ = hints?.cleanQuery ? hints.cleanQuery : query;

  url.searchParams.set("q", cleanQ);
  url.searchParams.set("format", "json");
  url.searchParams.set("safesearch", "0");
  const { queryKey } = buildSearxngAuth(apiKey);
  if (queryKey) url.searchParams.set("api_key", queryKey);

  // 1. Categories
  if (hints?.topic === "code") {
    url.searchParams.set("categories", "it");
  } else if (hints?.topic === "research") {
    url.searchParams.set("categories", "science");
  } else if (hints?.topic === "news") {
    url.searchParams.set("categories", "news");
  }

  // 2. Time range
  const freshnessPreset = hints?.freshness?.preset;
  if (freshnessPreset === "day" || freshnessPreset === "month" || freshnessPreset === "year") {
    url.searchParams.set("time_range", freshnessPreset);
  }

  // 3. Language
  if (hints?.locale?.language) {
    url.searchParams.set("language", hints.locale.language);
  }

  return url;
}

export const SearxngProvider: ProviderAdapter = {
  ...SEARXNG_META,

  async search(query, maxResults, apiKey, baseUrl, contextOrSignal) {
    const { signal, hints } = resolveContext(contextOrSignal);
    const instance = (baseUrl ?? SEARXNG_META.defaultBaseUrl).replace(/\/$/, "");
    if (!instance) throw providerError("config", "SearXNG base URL is not configured");
    const url = buildSearxngUrl(instance, query, apiKey, hints);
    const { headers } = buildSearxngAuth(apiKey);
    let res: Response;
    try {
      res = await fetchWithProxy(url, { signal, headers });
    } catch (e) {
      throw providerError("network", `SearXNG unreachable at ${instance}: ${String(e)}`);
    }
    if (!res.ok) {
      if (res.status === 401 || res.status === 403) {
        throw providerError("auth", `SearXNG refused the request (HTTP ${res.status}) — check the instance credential and enable JSON output in settings.yml`, res.status);
      }
      if (res.status >= 500) throw providerError("server", `SearXNG server error (HTTP ${res.status})`, res.status);
      throw providerError("bad-request", `SearXNG request failed (HTTP ${res.status})`, res.status);
    }
    const raw = await res.json();
    const results = Array.isArray(raw?.results) ? raw.results : [];
    const sources = results
      .slice(0, maxResults)
      .map((r: Record<string, unknown>) => {
        const u = typeof r?.url === "string" ? r.url : "";
        if (!u) return null;
        const s: { url: string; title?: string; snippet?: string } = { url: u };
        if (typeof r.title === "string" && r.title) s.title = r.title;
        if (typeof r.content === "string" && r.content) s.snippet = r.content;
        return s;
      })
      .filter((x: { url: string } | null): x is { url: string } => x !== null);
    const outcome: SearchOutcome = { sources };
    if (typeof raw?.answer === "string" && raw.answer) outcome.content = raw.answer;
    // HTTP 200 also carries upstream timeouts/CAPTCHAs. Preserve usable partial
    // results, but do not report an engine failure as a successful empty search.
    if (sources.length === 0 && !outcome.content?.trim()
      && Array.isArray(raw?.unresponsive_engines) && raw.unresponsive_engines.length > 0) {
      throw providerError("server", `SearXNG returned no usable results; ${raw.unresponsive_engines.length} upstream engine(s) reported errors`);
    }
    return outcome;
  },

  async fetch(_url, _apiKey, _baseUrl, _signal) {
    throw providerError("config", "SearXNG does not provide native fetch; use the generic path");
  },
};
