/**
 * dsh-web-tools — Host configuration: settings namespace + schema.
 *
 * The config (non-secret knobs) lives in a `dsh-web-tools` settings namespace
 * registered through the settings service, so it persists with the deployment's
 * settings document. API keys are NOT here — they live in the credentials
 * domain (`WEB_TOOLS_*` refs).
 * @module
 */
import z from "@deepseek-ai/schemastery";
import type { WebToolsContext } from "./context-types.ts";
import type { QuotaSnapshot } from "./quota.ts";
import type { StoredProviderOptions } from "../shared/provider-options.ts";
import type { SearchRoutingPolicy } from "../shared/api-types.ts";
import type { CustomProviderConfig } from "../shared/custom-provider-types.ts";
import type { OutboundAuthorization } from "./provider-transport.ts";
import { loadCustomProviders } from "./custom-provider-schema.ts";

/** Persistent search routing policy id (shared with the client card). */
export type ToolSearchRoutingPolicy = SearchRoutingPolicy;

/** Settings namespace for this plugin. */
export const SETTINGS_NS = "dsh-web-tools";

/** Default provider when nothing is configured. Changed from tavily to exa
 *  based on P5 evaluation: Exa achieves 72.2% Top-1, 97.2% Top-3 evidence,
 *  75% official source hit, 0% generic, 0% error across 36 tasks.
 *  This only affects new installs — existing users keep their saved provider. */
export const DEFAULT_PROVIDER = "exa";

/**
 * Explicit defaults. The resolved settings type is `WebToolsSettings` (below);
 * `Config` is the schemastery schema annotated the official way
 * (`z<WebToolsSettings>`) so the emitted d.ts references only `schemastery`,
 * never the dsh-private cosmokit copy.
 */
export const DEFAULT_SETTINGS = {
  enabled: true,
  defaultProvider: DEFAULT_PROVIDER,
  // Per-attempt budget for ONE provider call (the DSH tool owns the overall
  // web_search timeout). Distinct from tool-level timeout: this is how long a
  // single provider may run before we abort it and try the next one.
  providerAttemptTimeoutMs: 10000,
  fallbackOrder: [] as string[],
  providerBaseUrls: {} as Record<string, string>,
  providerEnabled: {} as Record<string, boolean>,
  platformEnabled: { xiaohongshu: true, x: true } as Record<string, boolean>,
  providerOptions: {} as StoredProviderOptions,
  // Brave has NO quota endpoint — its only quota signal is the X-RateLimit-*
  // response header captured during a real search. Persisted here so a
  // restart does not forget the last known balance (keyed by API key).
  braveQuotaCache: {} as Record<string, QuotaSnapshot>,
  // Search routing policy: how the runtime picks the starting provider per
  // search query. "ordered" = always from the first available; "round-robin"
  // and "random" rotate the start offset (see routing-policy.ts).
  searchRoutingPolicy: "ordered" as ToolSearchRoutingPolicy,
  // Operator-defined search sources (Issue #9). Kept in their OWN array rather
  // than merged into providerBaseUrls/providerEnabled: a merge would force a
  // migration of every existing profile for no benefit, and custom sources
  // carry structure (protocol, auth, mapping) the flat maps cannot express.
  customProviders: [] as CustomProviderConfig[],
  /** Operator-granted outbound destinations for internal gateways / private IPs. */
  outboundAuthorizations: [
    { host: "127.0.0.1", port: 8080, allowPrivate: true, allowHttp: true, note: "SearXNG default instance" },
    { host: "localhost", port: 8080, allowPrivate: true, allowHttp: true, note: "SearXNG default instance" },
  ] as OutboundAuthorization[],
};

/** Resolved settings shape (explicit interface — portable in emitted d.ts). */
export interface WebToolsSettings {
  enabled: boolean;
  defaultProvider: string;
  providerAttemptTimeoutMs: number;
  fallbackOrder: string[];
  providerBaseUrls: Record<string, string>;
  providerEnabled: Record<string, boolean>;
  platformEnabled: Record<string, boolean>;
  providerOptions: StoredProviderOptions;
  /** Brave per-key quota snapshots captured from search response headers. */
  braveQuotaCache: Record<string, QuotaSnapshot>;
  /** Search routing policy (see shared api-types). */
  searchRoutingPolicy: ToolSearchRoutingPolicy;
  /** Operator-defined custom search sources (Issue #9). */
  customProviders: CustomProviderConfig[];
  /** Operator-granted outbound destinations for internal gateways / private IPs. */
  outboundAuthorizations?: OutboundAuthorization[];
}

/** The schema object for settings registration (official z<T> annotation). */
export const Config: z<WebToolsSettings> = z.object({
  enabled: z.boolean(),
  defaultProvider: z.string(),
  providerAttemptTimeoutMs: z.number().step(1).min(1000).max(60000),
  fallbackOrder: z.array(z.string()),
  providerBaseUrls: z.dict(z.string()),
  providerEnabled: z.dict(z.boolean()),
  platformEnabled: z.dict(z.boolean()),
  providerOptions: z.dict(z.any()),
  braveQuotaCache: z.dict(z.any()),
  searchRoutingPolicy: z.union([z.const("ordered"), z.const("round-robin"), z.const("random")]),
  // Validated structurally on load; a bad entry is dropped, never thrown, so a
  // hand-edited profile cannot make the plugin fail to register.
  customProviders: z.array(z.any()),
  outboundAuthorizations: z.array(z.any()),
});
// Mark volatile for DSH 0.1.7+ SettingsForms and config editor
(Config as any).meta = { ...(Config as any).meta, volatile: true };

function unwrapConfig(val: unknown): unknown {
  if (val && typeof (val as any).get === "function") {
    return unwrapConfig((val as any).get());
  }
  if (Array.isArray(val)) {
    return val.map(unwrapConfig);
  }
  if (val !== null && typeof val === "object") {
    const res: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(val)) {
      res[k] = unwrapConfig(v);
    }
    return res;
  }
  return val;
}

/** A settings-scope handle: current value + write path. */
export interface ConfigHandle {
  /** Resolve the current effective section (re-read each call → live edits apply). */
  read: () => WebToolsSettings;
  /** Write a partial patch into the namespace; resolves when persisted. */
  write: (patch: Partial<WebToolsSettings>) => Promise<void>;
  /**
   * Called once the settings namespace is registered (ctx.inject callback).
   * Use it for anything that must read persisted settings at boot — the
   * synchronous apply() body runs BEFORE the inject callback, so reading
   * config there would only see the defaults.
   */
  onMounted: (cb: () => void) => void;
}

/**
 * Keep only usable base-URL overrides.
 *
 * A malformed override must never reach an adapter: an entry that is not an
 * absolute http(s) URL is dropped (which restores the official endpoint) rather
 * than being passed down and failing at request time.
 */
export function sanitizeBaseUrlOverrides(value: unknown): Record<string, string> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const out: Record<string, string> = {};
  for (const [key, raw] of Object.entries(value as Record<string, unknown>)) {
    if (typeof raw !== "string") continue;
    const trimmed = raw.trim();
    if (trimmed === "") continue; // an empty override means "restore default"
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") continue;
      if (parsed.username || parsed.password) continue;
      out[key] = parsed.href.replace(/\/+$/, "");
    } catch {
      continue;
    }
  }
  return out;
}

/**
 * Register the settings namespace; returns a handle for reads (live) and
 * Host-side writes. The browser card writes through the fenced routes, never
 * through settings/mutate (that proxy's whitelist excludes third-party
 * namespaces).
 */
export function installConfig(ctx: WebToolsContext, initialConfig?: unknown): ConfigHandle {
  const unwrapped = (unwrapConfig(initialConfig) as Partial<WebToolsSettings>) ?? {};
  const configured: WebToolsSettings = {
    ...DEFAULT_SETTINGS,
    ...unwrapped,
    providerBaseUrls: sanitizeBaseUrlOverrides(unwrapped.providerBaseUrls),
    customProviders: loadCustomProviders(unwrapped.customProviders),
    outboundAuthorizations: Array.isArray(unwrapped.outboundAuthorizations) ? unwrapped.outboundAuthorizations : [],
  };

  let current = () => configured;
  let scope: { update: (patch: object) => Promise<void>; get?: () => unknown } | undefined;
  let service: any;
  let mounted = false;
  const mountedCbs: Array<() => void> = [];

  ctx.inject(["settings"], (sctx: any) => {
    service = sctx.settings;
    if (typeof service?.register === "function") {
      // DSH pre-0.1.7: Settings service had register()
      const registered = service.register(SETTINGS_NS, Config, {
        base: configured,
      });
      scope = registered;
      current = () => registered.get() as WebToolsSettings;
    } else {
      // DSH 0.1.7+: SettingsForms has no register(); initial config came from loader.
      // Register presentation policy to prevent an empty generic page from auto-generating.
      if (typeof service?.configure === "function") {
        try {
          ctx.effect?.(() => service.configure({ auto: false }, (ctx as any).fiber));
        } catch {}
      }
    }
    mounted = true;
    for (const cb of mountedCbs.splice(0)) cb();
  });

  return {
    read: () => current(),
    write: async (patch) => {
      if (!scope && !service) {
        throw new Error("dsh-web-tools settings namespace is not mounted");
      }
      // Persist FIRST, then publish.
      //
      // The previous order (`Object.assign` then await) published the new value
      // to every live reader before the write was durable, and on DSH 0.1.7 a
      // settings write costs ~2.5s (profile patch + Loader reconciliation). A
      // failure or a slow write therefore left the runtime running on a value
      // that had never been persisted — catastrophic for a multi-step
      // custom-source create, where a later step would act on a phantom source.
      //
      // Applying only after a successful write keeps `read()` consistent with
      // what is on disk: either the whole patch is live, or none of it is.
      const normalized: Partial<WebToolsSettings> = { ...patch };
      if (patch.providerBaseUrls !== undefined) {
        normalized.providerBaseUrls = sanitizeBaseUrlOverrides(patch.providerBaseUrls);
      }
      if (patch.customProviders !== undefined) {
        normalized.customProviders = loadCustomProviders(patch.customProviders);
      }
      if (patch.outboundAuthorizations !== undefined) {
        normalized.outboundAuthorizations = Array.isArray(patch.outboundAuthorizations) ? patch.outboundAuthorizations : [];
      }

      if (scope) {
        await scope.update(normalized);
      } else if (typeof service?.update === "function") {
        await service.update(SETTINGS_NS, normalized);
      }
      Object.assign(configured, normalized);
    },
    onMounted: (cb) => {
      if (mounted) {
        cb();
      } else {
        mountedCbs.push(cb);
      }
    },
  };
}
