import { createNativeBrowserRuntime, type NativeBrowserRuntime, type CdpPageLease } from "../browser/index.ts";
import {
  extractVisibleXTweets,
  type XTweetExtraction,
} from "./browser-scripts/x.ts";
import {
  extractCommentsFromTweetDetail,
  extractTweetFromTweetDetail,
  extractTweetIdFromUrl,
  extractTweetsFromSearchTimeline,
  isSearchTimelineResponse,
  isTweetDetailResponse,
} from "./x/normalize.ts";
import { appendCommentsToItem } from "./comments.ts";
import { verifyPlatformSession } from "./auth.ts";
import { withMediaSection } from "./media.ts";
import { fetchWithProxy } from "../fetch-proxy.ts";
import type {
  SpecializedSource,
  SourceStatus,
  SourceSearchRequest,
  SourceSearchOutcome,
  SourceFetchOutcome,
  SourceItem,
} from "./types.ts";

const LOGIN_REDIRECT_RE = /\/i\/flow\/login|\/account\/access|challenge/i;

/** Wait for the real X search page and collect tweets via DOM (fallback path). */
/**
 * Snapshot of what the search page actually shows, for a failed capture.
 *
 * A bare "parse-failed" is undebuggable: the page may be a login wall, a
 * rate-limit interstitial, a consent/verification screen, or a hydrated shell
 * whose SPA never issued the SearchTimeline request. This records the facts
 * that distinguish them.
 */
interface XPageSnapshot {
  href: string;
  title: string;
  text: string;
  tweets: number;
  graphql: number;
  /** Logged-in side navigation present. */
  loggedIn: boolean;
  /** A "Log in / Sign up" call-to-action is on screen. */
  loginCta: boolean;
  /** The site's inline "Something went wrong" panel is on screen. */
  errorPanel?: boolean;
  readyState: string;
}

/** Snapshot of what the search page actually shows, for a failed capture. */
async function readXPageSnapshot(page: CdpPageLease, signal?: AbortSignal): Promise<XPageSnapshot | undefined> {
  try {
    return await page.evaluate<XPageSnapshot>(
      `(() => {
        const text = (document.body && document.body.innerText ? document.body.innerText : "")
          .replace(/\\s+/g, " ")
          .slice(0, 160);
        let graphql = 0;
        try {
          graphql = performance.getEntriesByType("resource")
            .filter((e) => e.name.indexOf("/i/api/graphql/") !== -1).length;
        } catch {}
        const loggedIn = !!document.querySelector(
          '[data-testid="SideNav_AccountSwitcher_Button"], [data-testid="AppTabBar_Profile_Link"], a[href="/logout"]'
        );
        const bodyText = (document.body && document.body.innerText ? document.body.innerText : "").toLowerCase();
        // Conservative: a login LINK exists on the site chrome even when signed
        // in, so the CTA flag is only a hint. The authoritative signal is the
        // URL (login redirect) combined with "nothing loaded at all".
        const loginCta = !!document.querySelector('a[href="/login"], a[href="/i/flow/login"]')
          || bodyText.indexOf("sign in to x") !== -1
          || bodyText.indexOf("log in to x") !== -1;
        // x.com renders an inline error panel ("出错了。请尝试重新加载。" /
        // "Something went wrong. Try reloading.") when its timeline request is
        // rejected. That is a platform-side error, not a login or parse issue.
        const errorPanel = /出错了|请尝试重新加载|something went wrong|try reloading/i.test(bodyText);
        return {
          href: location.href,
          title: document.title || "",
          text,
          tweets: document.querySelectorAll("article[data-testid='tweet']").length,
          graphql,
          loggedIn,
          loginCta,
          errorPanel,
          readyState: document.readyState,
        };
      })()`,
      signal,
    );
  } catch {
    return undefined;
  }
}

/**
 * Only treat the page as a logged-out shell on STRONG evidence.
 *
 * A cold SPA boot renders the site chrome (which contains a "Log in" link)
 * before hydration, so linkage alone proves nothing — that false positive is
 * exactly what made a valid session look signed out.
 */
function isLoggedOutShell(snap: XPageSnapshot | undefined): boolean {
  if (!snap) return false;
  if (/\/login\b|\/i\/flow\/login/.test(snap.href)) return true;
  return (
    !snap.loggedIn &&
    snap.graphql === 0 &&
    snap.tweets === 0 &&
    /sign in to x|log in to x/.test(snap.text.toLowerCase())
  );
}

function describeXPageSnapshot(info: XPageSnapshot): string {
  const bits = [
    `href=${info.href}`,
    `ready=${info.readyState}`,
    `tweets=${info.tweets}`,
    `graphql=${info.graphql}`,
    `loggedIn=${info.loggedIn}`,
    `loginCta=${info.loginCta}`,
    ...(info.errorPanel ? ["errorPanel=true"] : []),
  ];
  if (info.title) bits.push(`title=${info.title.slice(0, 60)}`);
  if (info.text) bits.push(`text=${info.text.slice(0, 120)}`);
  return bits.join(", ");
}

async function collectTweetsViaDom(
  page: CdpPageLease,
  maxResults: number,
  signal?: AbortSignal,
  opts: { selectorTimeoutMs?: number; maxScrolls?: number } = {},
): Promise<SourceItem[]> {
  try {
    await page.waitForSelector("article[data-testid='tweet']", opts.selectorTimeoutMs ?? 8000, signal);
  } catch {
    // Empty search result or loading slow
  }

  const collectedMap = new Map<string, SourceItem>();
  let noNewCount = 0;
  const maxScrolls = opts.maxScrolls ?? 6;

  for (let s = 0; s < maxScrolls; s++) {
    if (signal?.aborted) break;

    const batch: XTweetExtraction[] = await page.call(extractVisibleXTweets, [], signal);
    let addedThisBatch = 0;

    for (const item of batch) {
      if (!collectedMap.has(item.id)) {
        collectedMap.set(item.id, {
          id: item.id,
          title: item.text.slice(0, 80) || "X Tweet",
          url: item.url,
          text: item.text,
          snippet: item.text,
          author: item.authorHandle
            ? { name: item.authorName || item.authorHandle, handle: item.authorHandle }
            : undefined,
          publishedAt: item.publishedAt,
          likes: item.likes,
          retweets: item.retweets,
          replies: item.replies,
          platform: "x",
        });
        addedThisBatch++;
      }
    }

    if (collectedMap.size >= maxResults) break;

    if (addedThisBatch === 0) {
      noNewCount++;
      if (noNewCount >= 2) break;
    } else {
      noNewCount = 0;
    }

    await page.scrollBy(700, signal);
  }

  return Array.from(collectedMap.values()).slice(0, maxResults);
}

function isExpiredSessionResponse(status: number): boolean {
  return status === 401 || status === 403;
}

export function parseXMetricNumber(text?: string): number | undefined {
  if (!text) return undefined;
  const clean = text.trim().replace(/,/g, "");
  if (/^\d+$/.test(clean)) return parseInt(clean, 10);
  const kMatch = clean.match(/^([\d.]+)\s*[kK]$/);
  if (kMatch) return Math.round(parseFloat(kMatch[1]) * 1000);
  const mMatch = clean.match(/^([\d.]+)\s*[mM]$/);
  if (mMatch) return Math.round(parseFloat(mMatch[1]) * 1000000);
  return undefined;
}

export function buildXSearchUrl(query: string, req?: SourceSearchRequest, forceLatest = false): string {
  let q = query.trim();
  // Note: lang: filter is intentionally omitted. SearchHints.locale.language
  // is inferred from the user's instruction language, not from an explicit
  // "only search in this language" intent. Adding lang: here would incorrectly
  // filter out relevant results (e.g. "在X上搜索 OpenAI" would add lang:zh).
  // Future: reintroduce only when SearchHints exposes languageExplicit flag.
  if (req?.hints?.freshness) {
    const { after, before } = req.hints.freshness;
    if (after) {
      q += ` since:${after}`;
    }
    if (before) {
      q += ` until:${before}`;
    }
  }

  // Quality operators. These are FREE query syntax honored by x.com itself (no
  // paid API tier): topic searches are dominated by reply noise and bot spam.
  //
  // Only applied to ASCII/Latin queries: x.com's parser mis-handles negative
  // operators combined with CJK keywords and can return 0 posts for a query
  // that has plenty of matches. Reply filtering for CJK stays client-side.
  const raw = (req?.hints?.rawQuery ?? query).toLowerCase();
  const isAsciiQuery = /^[\x00-\x7F]+$/.test(raw);
  if (isAsciiQuery && !/filter:replies|回复|replies/.test(raw)) q += " -filter:replies";
  if (isAsciiQuery && /视频|video/.test(raw)) q += " filter:videos";
  else if (isAsciiQuery && /图片|图文|image|photo/.test(raw)) q += " filter:images";
  // Only when the caller asked for popularity: a global engagement floor would
  // erase exactly the niche terms a platform search is usually used for.
  if (isAsciiQuery && (req?.hints?.sort === "popularity_descending" || /热门|最火|高赞|trending|viral/.test(raw))) q += " min_faves:10";

  // `f=live` switches the UI from relevance-ranked "Top" to chronological
  // "Latest". The news topic wants it by default; the search fallback asks for
  // it explicitly when "Top" produced nothing usable.
  const fParam = forceLatest || req?.hints?.topic === "news" || req?.hints?.sort === "time_descending" ? "&f=live" : "";
  return `https://x.com/search?q=${encodeURIComponent(q)}&src=typed_query${fParam}`;
}

/**
 * Map the public syndication payload (the one X's embed widget uses) to a
 * SourceItem. Free endpoint, no auth, no browser.
 */
export function mapSyndicationTweet(json: any, fallbackUrl: string): SourceItem | null {
  const text = typeof json?.text === "string" ? json.text : "";
  const user = json?.user ?? {};
  const id = json?.id_str ?? json?.id;
  if (!id && !text) return null;
  const handle = typeof user?.screen_name === "string" ? `@${user.screen_name}` : undefined;
  return {
    id: String(id ?? ""),
    title: text.slice(0, 80) || "X Tweet",
    url: fallbackUrl,
    text: text || undefined,
    snippet: text ? text.slice(0, 240) : undefined,
    author: user?.name
      ? { name: String(user.name), handle, url: user?.screen_name ? `https://x.com/${user.screen_name}` : undefined }
      : undefined,
    publishedAt: typeof json?.created_at === "string" ? json.created_at : undefined,
    likes: typeof json?.favorite_count === "number" ? json.favorite_count : undefined,
    replies: typeof json?.conversation_count === "number" ? json.conversation_count : undefined,
    platform: "x",
  };
}

/** FxTwitter returns Twitter's raw date; normalise to ISO where possible. */
function fxTwitterPublishedAt(tweet: any): string | undefined {
  const ts = tweet?.created_timestamp;
  if (typeof ts === "number" && Number.isFinite(ts) && ts > 0) {
    return new Date(ts * 1000).toISOString();
  }
  const raw = typeof tweet?.created_at === "string" ? tweet.created_at : undefined;
  if (!raw) return undefined;
  const parsed = Date.parse(raw);
  return Number.isNaN(parsed) ? raw : new Date(parsed).toISOString();
}

function fxTwitterMedia(tweet: any): { images: string[]; videoUrl?: string } {
  const photos = Array.isArray(tweet?.media?.photos)
    ? tweet.media.photos
    : Array.isArray(tweet?.photos)
      ? tweet.photos
      : [];
  const videos = Array.isArray(tweet?.media?.videos)
    ? tweet.media.videos
    : Array.isArray(tweet?.videos)
      ? tweet.videos
      : [];
  const images = photos
    .map((p: any) => (typeof p?.url === "string" ? p.url : undefined))
    .filter(Boolean);
  const videoUrl = videos
    .map((v: any) => (typeof v?.url === "string" ? v.url : undefined))
    .filter(Boolean)[0];
  return { images, videoUrl };
}

/**
 * Map the FxTwitter proxy payload to a SourceItem — the standalone fallback
 * when the official syndication endpoint returns nothing.
 */
export function mapFxTwitterTweet(tweet: any, fallbackUrl: string): SourceItem | null {
  const text = typeof tweet?.text === "string" ? tweet.text : "";
  const id = tweet?.id !== undefined ? String(tweet.id) : "";
  if (!id && !text) return null;
  const author = tweet?.author ?? {};
  const handle = typeof author?.screen_name === "string" ? `@${author.screen_name}` : undefined;
  const { images, videoUrl } = fxTwitterMedia(tweet);
  return {
    id,
    title: text.slice(0, 80) || "X Tweet",
    url: typeof tweet?.url === "string" && tweet.url.startsWith("https://x.com/") ? tweet.url : fallbackUrl,
    text: text || undefined,
    snippet: text ? text.slice(0, 240) : undefined,
    author: author?.name || handle
      ? {
          name: author?.name ? String(author.name) : handle!,
          handle,
          url: author?.url ? String(author.url) : undefined,
        }
      : undefined,
    publishedAt: fxTwitterPublishedAt(tweet),
    likes: typeof tweet?.likes === "number" ? tweet.likes : undefined,
    retweets: typeof tweet?.retweets === "number" ? tweet.retweets : undefined,
    replies: typeof tweet?.replies === "number" ? tweet.replies : undefined,
    ...(images.length ? { images } : {}),
    ...(videoUrl ? { videoUrl } : {}),
    platform: "x",
  };
}

/**
 * Fill missing fields on an item (from the official syndication payload or a
 * browser extraction) with what FxTwitter knows. Strictly additive: a value
 * already present from a first-party source always wins.
 */
export function mergeFxTwitterInto(item: SourceItem, tweet: any): void {
  if (item.likes === undefined && typeof tweet?.likes === "number") item.likes = tweet.likes;
  if (item.retweets === undefined && typeof tweet?.retweets === "number") item.retweets = tweet.retweets;
  if (item.replies === undefined && typeof tweet?.replies === "number") item.replies = tweet.replies;
  if (item.publishedAt === undefined) item.publishedAt = fxTwitterPublishedAt(tweet);
  if (!item.author && (tweet?.author?.name || tweet?.author?.screen_name)) {
    const handle = typeof tweet.author.screen_name === "string" ? `@${tweet.author.screen_name}` : undefined;
    item.author = {
      name: tweet.author.name ? String(tweet.author.name) : handle!,
      handle,
      url: tweet.author.url ? String(tweet.author.url) : undefined,
    };
  }
  const { images, videoUrl } = fxTwitterMedia(tweet);
  if (!item.images?.length && images.length) item.images = images;
  if (!item.videoUrl && videoUrl) item.videoUrl = videoUrl;
}

type SyndicationFetcher = (tweetId: string, signal?: AbortSignal) => Promise<any | null>;

/** Fetch one tweet from X's public embed endpoint (no auth, no browser). */
export async function defaultSyndicationFetcher(tweetId: string, signal?: AbortSignal): Promise<any | null> {
  try {
    const res = await fetchWithProxy(
      `https://cdn.syndication.twimg.com/tweet-result?id=${encodeURIComponent(tweetId)}&lang=zh-cn&token=a`,
      { signal, headers: { accept: "application/json" } },
    );
    if (!res.ok) return null;
    const json = await res.json();
    return json && typeof json === "object" ? json : null;
  } catch {
    return null;
  }
}

let syndicationFetcher: SyndicationFetcher = defaultSyndicationFetcher;

/** Test seam: replace the network fetcher (pass a null-returning stub). */
export function setSyndicationFetcher(fn: SyndicationFetcher): void {
  syndicationFetcher = fn;
}

type FxTwitterFetcher = (tweetId: string, signal?: AbortSignal) => Promise<any | null>;

/**
 * Fetch one tweet from the FxTwitter public proxy API (no auth, no browser).
 *
 * The post https://x.com/vincent_ddup/status/2122917213342720381 popularised
 * this channel for "X intelligence research": one JSON GET returns the full
 * text, the author profile, engagement counts, and media URLs. It is a
 * THIRD-PARTY service — availability is best-effort and every failure here is
 * non-fatal by design; callers must treat null as "channel down".
 */
export async function defaultFxTwitterFetcher(tweetId: string, signal?: AbortSignal): Promise<any | null> {
  try {
    const res = await fetchWithProxy(
      `https://api.fxtwitter.com/i/status/${encodeURIComponent(tweetId)}`,
      { signal, headers: { accept: "application/json" } },
    );
    if (!res.ok) return null;
    const json: any = await res.json();
    return json?.tweet && typeof json.tweet === "object" ? json.tweet : null;
  } catch {
    return null;
  }
}

let fxTwitterFetcher: FxTwitterFetcher = defaultFxTwitterFetcher;

/** Test seam: replace the FxTwitter network fetcher (pass a null-returning stub). */
export function setFxTwitterFetcher(fn: FxTwitterFetcher): void {
  fxTwitterFetcher = fn;
}

export class XSource implements SpecializedSource {  readonly id = "x" as const;
  readonly name = "Twitter / X";
  private runtime: NativeBrowserRuntime;

  constructor(runtime?: NativeBrowserRuntime) {
    this.runtime = runtime || createNativeBrowserRuntime();
  }

  async status(): Promise<SourceStatus> {
    const sessionStatus = await this.runtime.status("x");
    return {
      id: "x",
      name: "Twitter / X",
      enabled: true,
      runtimeAvailable: sessionStatus.runtimeAvailable,
      runtimeState: sessionStatus.runtimeState,
      authenticated: sessionStatus.authenticated,
      sessionEstablished: sessionStatus.sessionEstablished,
      capabilities: {
        nativeSearch: true,     // X search via headless native browser
        nativeFetch: true,      // X tweet detail via headless native browser
        webSearchFallback: true,
      },
      account: sessionStatus.accountLabel
        ? { handle: sessionStatus.accountLabel, name: sessionStatus.accountLabel }
        : undefined,
      lastError: sessionStatus.lastError,
      lastCheckedAt: sessionStatus.verifiedAt || Date.now(),
    };
  }

  async search(
    query: string,
    req?: SourceSearchRequest,
    signal?: AbortSignal,
  ): Promise<SourceSearchOutcome> {
    const isAuth = await verifyPlatformSession(this.runtime, "x", signal, "interactive");
    if (!isAuth) {
      return {
        items: [],
        error: { code: "auth-required", message: "Twitter / X session is not authenticated", retryable: false },
      };
    }

    const maxResults = Math.min(req?.maxResults || 10, 30);

    // Pass 1 — the default ("Top") tab, which X ranks by relevance. Best for
    // evergreen or popular terms.
    const top = await this.searchOnce(buildXSearchUrl(query, req), maxResults, signal);
    if (top.items.length > 0) return top;
    if (top.error && !top.error.retryable) return top;
    if (signal?.aborted) return top;
    // A page that never hydrated will not hydrate on a second navigation
    // either — retrying the other tab would just double the wait.
    if (top.error?.message.includes("did not hydrate")) return top;

    // Smooth pause before switching to Latest tab to prevent consecutive burst rate limits
    await new Promise((resolve) => setTimeout(resolve, 400));

    // Pass 2 — "Latest". Niche or CJK keywords frequently have no Top matches
    // while the chronological tab still does. Without this retry the router
    // degraded to a `site:x.com` web search, which matches tokens loosely and
    // surfaced years-old unrelated tweets.
    const latest = await this.searchOnce(buildXSearchUrl(query, req, true), maxResults, signal);
    if (latest.items.length > 0) return latest;
    if (latest.error && !latest.error.retryable) return latest;
    return top.error ? top : latest;
  }

  /** One navigation + capture attempt against a concrete search URL. */
  private async searchOnce(searchUrl: string, maxResults: number, signal?: AbortSignal): Promise<SourceSearchOutcome> {
    let page;
    let capture;
    try {
      // Blank attached page — capture listeners must be in place BEFORE the
      // SPA fires SearchTimeline, so openPage() (which navigates eagerly) is
      // not usable here.
      page = await this.runtime.createPage("x", signal, "interactive");
    } catch (err: any) {
      if (err.name === "UrlDisallowedError") {
        return { items: [], error: { code: "blocked", message: err.message, retryable: false } };
      }
      return { items: [], error: { code: "runtime-unavailable", message: err.message, retryable: true } };
    }

    try {
      // PRIMARY: capture the SearchTimeline GraphQL response over CDP.
      // 9s window: gives sufficient runway for initial script compilation, Castle
      // security challenge, and hydration on both cold and warm loads.
      capture = await page.beginJsonCapture({
        urlIncludes: "/SearchTimeline",
        timeoutMs: 9000,
        signal,
      });
      // Bring tab to front early so Chromium does not throttle background execution
      try {
        await page.bringToFront?.(signal);
      } catch {}
      // Direct navigation only. A /home warm-up is a full hard reload, so it
      // does NOT preserve the hydrated app — it just costs another 4-6s. The
      // snapshot below detects an unhydrated shell and reports it instead.
      await page.navigate(searchUrl, signal);
      const outcome = await capture.wait();

      if (signal?.aborted || outcome.state === "aborted") {
        return {
          items: [],
          error: { code: "aborted", message: "Search operation was aborted", retryable: false },
        };
      }

      // Session can exist in cookies but be dead server-side — never fake 0.
      if (outcome.state === "captured" && isExpiredSessionResponse(outcome.status)) {
        return {
          items: [],
          error: { code: "auth-expired", message: `X search returned HTTP ${outcome.status}`, retryable: false },
        };
      }

      // Check for login redirect regardless of outcome state (e.g. timeout due to redirect)
      try {
        const pageUrl = await page.evaluate<string>("window.location.href", signal);
        if (LOGIN_REDIRECT_RE.test(pageUrl)) {
          return {
            items: [],
            error: { code: "auth-expired", message: "X redirected to the login flow", retryable: false },
          };
        }
      } catch {
        // URL check is best-effort
      }

      if (outcome.state === "captured") {
        const schemaRecognized = isSearchTimelineResponse(outcome.json);
        if (schemaRecognized) {
          const graphItems = extractTweetsFromSearchTimeline(outcome.json);
          const mergedMap = new Map<string, SourceItem>();
          for (const item of graphItems) mergedMap.set(item.id, item);

          // Thin GraphQL results: supplement via a short DOM pass (2s/2 scrolls).
          if (mergedMap.size < maxResults) {
            const domItems = await collectTweetsViaDom(page, maxResults, signal, {
              selectorTimeoutMs: 2000,
              maxScrolls: 2,
            });
            for (const item of domItems) {
              if (!mergedMap.has(item.id)) mergedMap.set(item.id, item);
            }
          }

          // DEEPER PAGES: scrolling makes x.com issue the next SearchTimeline
          // (with a bottom cursor); capture and merge it instead of forging a
          // GraphQL request ourselves.
          let stagnant = 0;
          for (let pageNo = 0; pageNo < 2 && mergedMap.size < maxResults && !signal?.aborted; pageNo++) {
            const before = mergedMap.size;
            let next: Awaited<ReturnType<CdpPageLease["beginJsonCapture"]>> | undefined;
            try {
              next = await page.beginJsonCapture({
                urlIncludes: "/SearchTimeline",
                timeoutMs: 6000,
                signal,
              });
              await page.scrollBy(1600, signal);
              const res = await next.wait();
              if (res?.state === "captured" && isSearchTimelineResponse(res.json)) {
                for (const item of extractTweetsFromSearchTimeline(res.json)) {
                  if (!mergedMap.has(item.id)) mergedMap.set(item.id, item);
                }
              }
            } catch {
              break;
            } finally {
              next?.cancel();
            }
            if (mergedMap.size === before) {
              stagnant++;
              if (stagnant >= 1) break;
            }
            await new Promise((resolve) => setTimeout(resolve, 250));
          }

          return { items: Array.from(mergedMap.values()).slice(0, maxResults), retrievalMode: "native-browser" };
        }

        // Captured but schema NOT recognized (X changed the envelope) → the
        // GraphQL path is dead; fall through to DOM so general-web fallback
        // still has a chance to run if the DOM is also empty.
      }

      // Capture failed or schema unrecognized → inspect the page BEFORE any scrolling.
      let snapshot = await readXPageSnapshot(page, signal);
      // "Hydrated" matters: a page that has rendered the search chrome (tabs,
      // account menu) is simply still LOADING the timeline, not broken.
      let hydrated =
        snapshot?.loggedIn === true ||
        /搜索|search/i.test(snapshot?.title ?? "") ||
        /热门|最新|Search|Latest/i.test(snapshot?.text ?? "");

      // SPLASH SCREEN RECOVERY: If the page is on the initial splash screen
      // (black background with X logo / unhydrated shell), the React app bundle
      // may still be loading or parsing script chunks. Poll up to 4.5s for hydration
      // instead of immediately aborting.
      if (!hydrated && !isLoggedOutShell(snapshot) && !signal?.aborted) {
        const pollStart = Date.now();
        while (Date.now() - pollStart < 4500 && !signal?.aborted) {
          await new Promise((r) => setTimeout(r, 300));
          snapshot = await readXPageSnapshot(page, signal);
          hydrated =
            snapshot?.loggedIn === true ||
            /搜索|search/i.test(snapshot?.title ?? "") ||
            /热门|最新|Search|Latest/i.test(snapshot?.text ?? "") ||
            Boolean(snapshot && (snapshot.tweets > 0 || snapshot.graphql > 0));
          if (hydrated) break;
        }
      }

      // If STILL not hydrated after polling, attempt a soft reload to un-stall
      // a hanging splash screen (known issue when X chunk loader stalls).
      if (!hydrated && !isLoggedOutShell(snapshot) && !signal?.aborted) {
        let lateSplashCapture: Awaited<ReturnType<CdpPageLease["beginJsonCapture"]>> | undefined;
        try {
          lateSplashCapture = await page.beginJsonCapture({
            urlIncludes: "/SearchTimeline",
            timeoutMs: 8000,
            signal,
          });
          await page.evaluate("window.location.reload()", signal);
          const splashOutcome = await lateSplashCapture.wait();
          if (splashOutcome?.state === "captured" && isSearchTimelineResponse(splashOutcome.json)) {
            const items = extractTweetsFromSearchTimeline(splashOutcome.json);
            if (items.length > 0) {
              return { items: items.slice(0, maxResults), retrievalMode: "native-browser" };
            }
          }
          snapshot = await readXPageSnapshot(page, signal);
          hydrated =
            snapshot?.loggedIn === true ||
            /搜索|search/i.test(snapshot?.title ?? "") ||
            /热门|最新|Search|Latest/i.test(snapshot?.text ?? "");
        } catch {
          // Best effort reload
        } finally {
          lateSplashCapture?.cancel();
        }
      }

      if (snapshot && snapshot.tweets === 0 && snapshot.graphql === 0 && !hydrated) {
        if (isLoggedOutShell(snapshot)) {
          return {
            items: [],
            error: {
              code: "auth-expired",
              message: `x.com showed the logged-out shell instead of search results [${describeXPageSnapshot(snapshot)}]`,
              retryable: false,
            },
          };
        }
        return {
          items: [],
          error: {
            code: "parse-failed",
            message: `X search page did not hydrate (no tweets, no API traffic) [${describeXPageSnapshot(snapshot)}]`,
            retryable: true,
          },
          diagnostics: [describeXPageSnapshot(snapshot)],
        };
      }

      // Hydrated page: the timeline is often deferred until the viewport
      // intersects the feed container (and a minimized window throttles idle
      // work). Nudge it with real scrolls WHILE a late capture is listening,
      // instead of idling for the selector.
      if (hydrated) {
        // Foreground + built-in retry: x.com renders an inline "出错了。请尝试重新加载。"
        // (Something went wrong. Try reloading.) panel when its timeline request is
        // rejected, and does NOT retry by itself.
        try {
          await page.bringToFront?.(signal);
        } catch {
          // Foregrounding is best-effort.
        }

        let late: Awaited<ReturnType<CdpPageLease["beginJsonCapture"]>> | undefined;
        try {
          // Listen FIRST so we never miss the SearchTimeline request fired by clicking reload/retry
          late = await page.beginJsonCapture({
            urlIncludes: "/SearchTimeline",
            timeoutMs: 9000,
            signal,
          });

          // 1. Try clicking the inline "重新加载 / 重试" button
          let retried = await this.clickXRetryIfPresent(page, signal);

          // 2. If error panel is visible but button was not found, soft-reload the search page
          if (!retried && snapshot?.errorPanel) {
            try {
              await page.navigate(searchUrl, signal);
              retried = true;
            } catch {}
          }

          if (retried) {
            // Give X React a tiny tick to initiate the request
            await new Promise((resolve) => setTimeout(resolve, 300));
            const lateOutcome = await late.wait();
            if (lateOutcome?.state === "captured" && isSearchTimelineResponse(lateOutcome.json)) {
              const lateItems = extractTweetsFromSearchTimeline(lateOutcome.json);
              if (lateItems.length > 0) {
                return { items: lateItems.slice(0, maxResults), retrievalMode: "native-browser" };
              }
            }
          } else {
            for (let i = 0; i < 3 && !signal?.aborted; i++) {
              await page.scrollBy(500, signal);
              await new Promise((resolve) => setTimeout(resolve, 600));
            }
            const lateOutcome = await late.wait();
            if (lateOutcome?.state === "captured" && isSearchTimelineResponse(lateOutcome.json)) {
              const lateItems = extractTweetsFromSearchTimeline(lateOutcome.json);
              if (lateItems.length > 0) {
                return { items: lateItems.slice(0, maxResults), retrievalMode: "native-browser" };
              }
            }
          }
        } catch {
          // Fall through to the DOM scan.
        } finally {
          late?.cancel();
        }
      }

      const domItems = await collectTweetsViaDom(page, maxResults, signal, {
        selectorTimeoutMs: hydrated ? 2500 : 2000,
        maxScrolls: hydrated ? 2 : 2,
      });
      if (domItems.length > 0) {
        return { items: domItems, retrievalMode: "native-browser" };
      }
      return {
        items: [],
        error: {
          code: "parse-failed",
          message:
            "X search produced no GraphQL response and no DOM tweets" +
            (snapshot ? ` [${describeXPageSnapshot(snapshot)}]` : ""),
          retryable: true,
        },
      };
    } catch (err: any) {
      if (signal?.aborted) {
        return {
          items: [],
          error: { code: "aborted", message: "Search operation was aborted", retryable: false },
        };
      }
      if (err.name === "UrlDisallowedError") {
        return { items: [], error: { code: "blocked", message: err.message, retryable: false } };
      }
      if (err.name === "NavigationTimeoutError" || err.name === "SelectorTimeoutError") {
        return { items: [], error: { code: "navigation-timeout", message: err.message, retryable: true } };
      }
      return { items: [], error: { code: "parse-failed", message: err.message, retryable: true } };
    } finally {
      capture?.cancel();
      await page.close();
    }
  }

  /**
   * Click x.com's inline "Something went wrong → Retry" panel if it is shown.
   *
   * The timeline request is sometimes rejected server-side; the SPA renders a
   * retry button and waits forever for a click. Returns whether one was found.
   */
  private async clickXRetryIfPresent(page: CdpPageLease, signal?: AbortSignal): Promise<boolean> {
    try {
      const clicked = await page.evaluate<boolean>(
        `(() => {
          const nodes = Array.from(document.querySelectorAll('[role="button"], button, div, span, [data-testid]'));
          const target = nodes.find((el) => {
            const testid = (el.getAttribute("data-testid") || "").toLowerCase();
            if (testid.includes("retry") || testid.includes("empty_state")) return true;
            const text = (el.textContent || "").trim();
            if (text.length === 0 || text.length > 25) return false;
            // Covers Chinese "重新加载", "重试", "刷新", English "Retry", "Try again", "Reload"
            if (!/重新加载|重试|刷新|retry|try again|reload/i.test(text)) return false;
            return el.tagName === "BUTTON"
              || el.getAttribute("role") === "button"
              || el.children.length === 0;
          });
          if (!target) return false;
          const button = (target.closest && target.closest('[role="button"], button')) || target;
          button.click();
          return true;
        })()`,
        signal,
      );
      return clicked === true;
    } catch {
      return false;
    }
  }

  async fetch(url: string, signal?: AbortSignal): Promise<SourceFetchOutcome> {
    if (signal?.aborted) return { error: { code: "aborted", message: "X fetch aborted", retryable: false } };
    const targetTweetId = extractTweetIdFromUrl(url);
    if (!targetTweetId) {
      return { error: { code: "parse-failed", message: `Invalid X status URL: "${url}"`, retryable: false } };
    }

    const isAuth = await verifyPlatformSession(this.runtime, "x", signal, "interactive");
    if (signal?.aborted) return { error: { code: "aborted", message: "X fetch aborted", retryable: false } };

    // RICH FIRST when signed in: only the browser path carries the reply tree,
    // the original-size images and the MP4 source. The public endpoint below is
    // a fast fallback that returns the text alone.
    let browserOutcome: SourceFetchOutcome | undefined;
    if (isAuth) {
      browserOutcome = await this.fetchViaBrowser(url, targetTweetId, signal);
      if (browserOutcome && !browserOutcome.error) return browserOutcome;
      if (signal?.aborted || browserOutcome?.error?.code === "aborted") {
        return browserOutcome ?? { error: { code: "aborted", message: "X fetch aborted", retryable: false } };
      }
    }

    // FAST FALLBACK: no login, no browser, no paid API. Two public endpoints
    // fetched in parallel — X's own embed widget API (text-level) and the
    // FxTwitter proxy (retweet counts, media URLs, author profile). Either
    // alone is enough; when both answer, first-party values win and FxTwitter
    // fills only the gaps. Both failures are non-fatal by design.
    let syndicated: any | null = null;
    let fxTweet: any | null = null;
    // Public enrichment must not hang an otherwise usable detail read when
    // one of the independent upstreams stalls. Caller cancellation still wins.
    const publicSignal = AbortSignal.any([...(signal ? [signal] : []), AbortSignal.timeout(8_000)]);
    await Promise.all([
      syndicationFetcher(targetTweetId, publicSignal).then(
        (v) => { syndicated = v; },
        () => {},
      ),
      fxTwitterFetcher(targetTweetId, publicSignal).then(
        (v) => { fxTweet = v; },
        () => {},
      ),
    ]);
    if (signal?.aborted) return { error: { code: "aborted", message: "X fetch aborted", retryable: false } };
    // A successful response is not proof of identity. Never relabel another
    // post's text or merge its metrics into the requested post.
    if (syndicated && String(syndicated.id_str ?? syndicated.id ?? "") !== targetTweetId) syndicated = null;
    if (fxTweet && String(fxTweet.id ?? "") !== targetTweetId) fxTweet = null;
    let item = syndicated ? mapSyndicationTweet(syndicated, url) : null;
    if (!item && fxTweet) item = mapFxTwitterTweet(fxTweet, url);
    if (item) {
      if (fxTweet) mergeFxTwitterInto(item, fxTweet);
      return { item, retrievalMode: "public-api" };
    }

    if (browserOutcome) return browserOutcome;
    return { error: { code: "auth-required", message: "Twitter / X session is not authenticated", retryable: false } };
  }

  /** Rich fetch: full tweet detail (replies, originals, MP4) through the browser. */
  private async fetchViaBrowser(
    url: string,
    targetTweetId: string,
    signal?: AbortSignal,
  ): Promise<SourceFetchOutcome> {
    let page;
    let capture;
    try {
      page = await this.runtime.createPage("x", signal, "interactive");
    } catch (err: any) {
      if (err.name === "UrlDisallowedError") {
        return { error: { code: "blocked", message: err.message, retryable: false } };
      }
      return { error: { code: "runtime-unavailable", message: err.message, retryable: true } };
    }

    try {
      // PRIMARY: capture TweetDetail GraphQL response over CDP.
      capture = await page.beginJsonCapture({
        urlIncludes: "/TweetDetail",
        timeoutMs: 8000,
        signal,
      });
      await page.navigate(url, signal);
      const outcome = await capture.wait();

      if (signal?.aborted || outcome.state === "aborted") {
        return { error: { code: "aborted", message: "Fetch operation was aborted", retryable: false } };
      }

      if (outcome.state === "captured" && isExpiredSessionResponse(outcome.status)) {
        return { error: { code: "auth-expired", message: `X tweet fetch returned HTTP ${outcome.status}`, retryable: false } };
      }

      try {
        const pageUrl = await page.evaluate<string>("window.location.href", signal);
        if (LOGIN_REDIRECT_RE.test(pageUrl)) {
          return { error: { code: "auth-expired", message: "X redirected to the login flow", retryable: false } };
        }
      } catch {
        // Best-effort URL check
      }

      if (outcome.state === "captured" && isTweetDetailResponse(outcome.json)) {
        const target = extractTweetFromTweetDetail(outcome.json, targetTweetId);
        if (target) {
          const comments = extractCommentsFromTweetDetail(outcome.json, targetTweetId);
          // Original-size images / highest-bitrate MP4 belong in the text: the
          // fetch result otherwise shows only the copy.
          target.text = withMediaSection(target.text, target);
          return {
            item: appendCommentsToItem(target, comments, {
              heading: "Replies",
              truncated: (target.replies || 0) > comments.length,
            }),
            retrievalMode: "native-browser",
          };
        }
      }

      // FALLBACK: DOM extraction matching the EXACT targetTweetId
      await page.waitForLoad(signal);
      try {
        await page.waitForSelector("article[data-testid='tweet']", 8000, signal);
      } catch {
        // Slow or empty DOM
      }

      const batch: XTweetExtraction[] = await page.call(extractVisibleXTweets, [], signal);
      const matched = batch.find((item) => item.id === targetTweetId);

      if (!matched) {
        return {
          error: {
            code: "parse-failed",
            message: `Target tweet ${targetTweetId} not found in page`,
            retryable: true,
          },
        };
      }

      return {
        item: {
          id: matched.id,
          title: matched.text.slice(0, 80) || "X Tweet",
          url: matched.url,
          text: matched.text,
          snippet: matched.text,
          author: matched.authorHandle
            ? { name: matched.authorName || matched.authorHandle, handle: matched.authorHandle }
            : undefined,
          publishedAt: matched.publishedAt,
          likes: matched.likes,
          retweets: matched.retweets,
          replies: matched.replies,
          platform: "x",
        },
        retrievalMode: "native-browser",
      };
    } catch (err: any) {
      if (signal?.aborted) {
        return { error: { code: "aborted", message: "Fetch operation was aborted", retryable: false } };
      }
      if (err.name === "UrlDisallowedError") {
        return { error: { code: "blocked", message: err.message, retryable: false } };
      }
      if (err.name === "NavigationTimeoutError" || err.name === "SelectorTimeoutError") {
        return { error: { code: "navigation-timeout", message: err.message, retryable: true } };
      }
      return { error: { code: "parse-failed", message: err.message, retryable: true } };
    } finally {
      capture?.cancel();
      await page.close();
    }
  }
}
