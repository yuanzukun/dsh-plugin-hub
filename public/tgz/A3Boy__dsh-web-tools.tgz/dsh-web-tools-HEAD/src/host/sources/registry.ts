import { validatePlatformUrl } from "../browser/paths.ts";
import { extractTweetIdFromUrl } from "./x/normalize.ts";
import { refinePlatformQuery } from "../search-hints.ts";
import { fallbackSearchToGeneralWeb, fallbackFetchToGeneralWeb } from "./web-fallback.ts";
import type {
  SpecializedSource,
  SpecializedPlatformId,
  SourceStatus,
  SourceSearchRequest,
  SourceSearchOutcome,
  SourceFetchOutcome,
} from "./types.ts";
import type { WebSearchProviderLike, WebFetchProviderLike } from "../registry.ts";

export class SpecializedSourceRegistry {
  private sources = new Map<SpecializedPlatformId, SpecializedSource>();
  private fallbackSearchProvider?: WebSearchProviderLike;
  private fallbackFetchProvider?: WebFetchProviderLike;
  private platformEnabled: Record<string, boolean> = { xiaohongshu: true, x: true };

  registerSource(source: SpecializedSource): void {
    this.sources.set(source.id, source);
  }

  setPlatformEnabled(enabledMap: Record<string, boolean>): void {
    this.platformEnabled = { ...this.platformEnabled, ...enabledMap };
  }

  isPlatformEnabled(platform: SpecializedPlatformId): boolean {
    return this.platformEnabled[platform] !== false;
  }

  unregisterSource(id: SpecializedPlatformId): void {
    this.sources.delete(id);
  }

  getSource(id: SpecializedPlatformId): SpecializedSource | undefined {
    return this.sources.get(id);
  }

  setFallbackProviders(
    search?: WebSearchProviderLike,
    fetch?: WebFetchProviderLike,
  ): void {
    this.fallbackSearchProvider = search;
    this.fallbackFetchProvider = fetch;
  }

  private inFlightStatus?: Promise<SourceStatus[]>;

  async getPlatformStatuses(): Promise<SourceStatus[]> {
    if (this.inFlightStatus) {
      return this.inFlightStatus;
    }
    this.inFlightStatus = (async () => {
      try {
        const platformIds: SpecializedPlatformId[] = ["xiaohongshu", "x"];
        const statusPromises = platformIds.map(async (id): Promise<SourceStatus> => {
          const source = this.sources.get(id);
          if (!source) {
            return {
              id,
              name: id === "xiaohongshu" ? "小红书" : "Twitter / X",
              enabled: this.isPlatformEnabled(id),
              runtimeAvailable: false,
              runtimeState: "unavailable",
              authenticated: false,
            };
          }
          try {
            const s = await source.status();
            return {
              ...s,
              enabled: this.isPlatformEnabled(id),
            };
          } catch (err: any) {
            return {
              id,
              name: source.name,
              enabled: this.isPlatformEnabled(id),
              runtimeAvailable: false,
              runtimeState: "error",
              authenticated: false,
              lastError: err?.message || String(err),
              lastCheckedAt: Date.now(),
            };
          }
        });
        return await Promise.all(statusPromises);
      } finally {
        this.inFlightStatus = undefined;
      }
    })();
    return this.inFlightStatus;
  }

  async routeSearch(
    query: string,
    req?: SourceSearchRequest,
    signal?: AbortSignal,
  ): Promise<SourceSearchOutcome> {
    return this.search(query, req, signal);
  }

  async search(
    query: string,
    req?: SourceSearchRequest,
    signal?: AbortSignal,
  ): Promise<SourceSearchOutcome> {
    const platform = req?.hints?.platform;
    if (!platform) {
      if (this.fallbackSearchProvider) {
        const res = await this.fallbackSearchProvider.search({ query, maxResults: req?.maxResults }, signal);
        const items = (res.sources || []).map((s) => ({
          id: s.url,
          title: s.title || s.url,
          url: s.url,
          snippet: s.snippet,
          summary: s.summary,
          publishedAt: s.publishedAt,
          platform: "general" as const,
        }));
        return {
          items,
          retrievalMode: "general-web",
          ...(res.content !== undefined ? { content: res.content } : {}),
          // Diagnostics must survive this hop: without them the settings card
          // (and the MCP tool) cannot report which backend served the answer.
          ...(res.backend !== undefined ? { backend: res.backend } : {}),
          ...(res.attempts !== undefined ? { attempts: res.attempts } : {}),
          ...(res.fused !== undefined ? { fused: res.fused } : {}),
        };
      }
      return { items: [] };
    }

    const source = this.sources.get(platform);
    if (!source || !this.isPlatformEnabled(platform)) {
      return fallbackSearchToGeneralWeb(
        query,
        platform,
        this.fallbackSearchProvider,
        req?.maxResults,
        signal,
        {
          code: "platform-disabled",
          message: source
            ? `${platform} is disabled in the settings card`
            : `No ${platform} source is registered in this build`,
          platform,
        },
      );
    }

    const nativeQuery = refinePlatformQuery(req?.hints?.cleanQuery?.trim() || query);
    const outcome = await source.search(nativeQuery, req, signal);
    // If native search succeeded (even 0 results), keep native outcome!
    if (outcome.error === undefined) {
      return { ...outcome, retrievalMode: "native-browser" };
    }

    if (signal?.aborted || outcome.error.code === "aborted") {
      return outcome;
    }

    // An absent/expired session used to fail the whole search. Indexed web
    // results WITH an explicit degraded marker are more useful than a hard
    // error: the agent still gets candidates, and every layer can tell this was
    // not native platform data (the marker is what stops it being hidden).
    const authIssue = outcome.error.code === "auth-required" || outcome.error.code === "auth-expired";
    if (!outcome.error.retryable && !authIssue) {
      return outcome;
    }

    // Retryable browser/runtime failures may still use indexed discovery.
    return fallbackSearchToGeneralWeb(
      query,
      platform,
      this.fallbackSearchProvider,
      req?.maxResults,
      signal,
      { code: outcome.error.code, message: outcome.error.message, platform },
    );
  }

  async routeFetch(url: string, signal?: AbortSignal): Promise<SourceFetchOutcome> {
    return this.fetch(url, signal);
  }

  async fetch(url: string, signal?: AbortSignal): Promise<SourceFetchOutcome> {
    let targetPlatform: SpecializedPlatformId | undefined;
    if (validatePlatformUrl(url, "xiaohongshu")) {
      targetPlatform = "xiaohongshu";
    } else if (validatePlatformUrl(url, "x") && extractTweetIdFromUrl(url)) {
      // A twitter.com domain alone is NOT enough: publish.twitter.com (oEmbed
      // endpoints, embed pages) is a twitter.com subdomain but carries no
      // status path, and the native source hard-fails such URLs. Only URLs
      // with an actual status ID go native; everything else falls to the
      // general fetch provider below.
      targetPlatform = "x";
    }

    if (!targetPlatform) {
      if (this.fallbackFetchProvider) {
        const res = await this.fallbackFetchProvider.fetch({ url }, signal);
        return {
          item: {
            id: res.url || url,
            title: res.metadata?.title || "Web Page",
            url: res.url || url,
            text: res.body?.content || "",
            platform: "general",
            author: res.metadata?.author ? { name: res.metadata.author } : undefined,
            publishedAt: res.metadata?.publishedAt,
          },
          retrievalMode: "general-web",
        };
      }
      return { error: { code: "runtime-unavailable", message: "No fetch provider available", retryable: false } };
    }

    const source = this.sources.get(targetPlatform);
    if (!source || !this.isPlatformEnabled(targetPlatform)) {
      return fallbackFetchToGeneralWeb(url, this.fallbackFetchProvider, signal);
    }

    const outcome = await source.fetch(url, signal);
    if (outcome.error === undefined && outcome.item) {
      // Sources may legitimately serve success from a non-browser channel
      // (e.g. X's public syndication endpoint is tagged "public-api"); keep
      // their label instead of relabelling everything as native-browser.
      return { ...outcome, retrievalMode: outcome.retrievalMode ?? "native-browser" };
    }

    if (signal?.aborted || outcome.error?.code === "aborted") {
      return outcome;
    }

    // A source marks platform-auth, access-control, and invalid-detail errors
    // as non-retryable. Do not hide that concrete result behind a potentially
    // long general-provider chain that cannot recover native comments/session
    // data and may consume the tool's entire timeout budget.
    if (outcome.error && !outcome.error.retryable) {
      return outcome;
    }

    return fallbackFetchToGeneralWeb(url, this.fallbackFetchProvider, signal);
  }
}
