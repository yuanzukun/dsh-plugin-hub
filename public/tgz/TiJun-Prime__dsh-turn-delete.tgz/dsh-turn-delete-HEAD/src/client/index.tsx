import type { MessageId } from '@deepseek-ai/dsh-llm'
import { TURN_DELETE_PATH } from '../shared.ts'
import type { ClientContext } from './context.ts'
import { DeletedTurnMarker } from './DeletedTurnMarker.tsx'
import { en, zh } from './locales.ts'
import { TurnDeleteAction, type DeleteTurnResponse } from './TurnDeleteAction.tsx'
import { selectDeletedTurn, turnDeletionDefinition } from './turn-deletion.ts'

const NS = 'turn-delete'

export const inject = ['slots', 'locale', 'uiConversation']

async function postDelete(sessionId: string, assistantMessageId: MessageId): Promise<DeleteTurnResponse> {
  const response = await fetch(TURN_DELETE_PATH, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ sessionId, assistantMessageId }),
  })
  const value = await response.json() as DeleteTurnResponse
  if (typeof value !== 'object' || value === null || typeof value.ok !== 'boolean') {
    throw new Error(`turn deletion returned HTTP ${String(response.status)}`)
  }
  return value
}

export function apply(ctx: ClientContext): void {
  ctx.uiConversation.events.register(turnDeletionDefinition)
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'turn-delete: dictionaries')
  ctx.slots.inject('conversation.chat.assistant-actions', () =>
    ctx.slots.register({
      name: 'conversation.chat.assistant-actions',
      id: 'turn-delete',
      order: 90,
      locale: NS,
      inject: sessionId => ({
        deleteTurn: (assistantMessageId: MessageId) => postDelete(sessionId, assistantMessageId),
      }),
    }, TurnDeleteAction))
  ctx.slots.inject('conversation.chat.turnTail', () =>
    ctx.slots.register({
      name: 'conversation.chat.turnTail',
      // DSH 0.2.0-rc.1 made `id` mandatory for list slots: registering without
      // one throws `list slot "<name>" requires options.id`, which fails this
      // plugin's whole `apply` and silently removes the delete action above too.
      id: 'turn-delete',
      order: 50,
      select: selectDeletedTurn,
    }, DeletedTurnMarker))
}
