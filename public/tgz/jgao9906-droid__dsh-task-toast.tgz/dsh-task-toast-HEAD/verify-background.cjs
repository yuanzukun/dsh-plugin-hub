const fs = require('node:fs');
const path = require('node:path');
const harness = fs.readFileSync(path.join(__dirname, 'verify-status.js'), 'utf8');
const setup = harness.slice(0, harness.indexOf("console.log('--- A:"));
const cases = `
return (async () => {
  const errorText = 'tools: at least one tool must have defer_loading=false. All tools cannot be deferred.';
  const event = (seq, kind) => ({type:'event',event:{type:'turn/end',seq,time:0,data:{turn:seq,reason:kind==='error'?{kind,error:{message:errorText,code:'INVALID_REQUEST'}}:{kind}}}});
  const fixture = (records) => {
    const state = {records,calls:[],signal:null};
    state.api = {
      async projections(request,signal) { state.calls.push(['projections',request]); state.signal=signal; return {ok:true,value:{asOfSeq:100}}; },
      async page(request,signal) { state.calls.push(['page',request]); state.signal=signal; return {ok:true,value:{records:state.records}}; },
    };
    return state;
  };
  const stop = (t,id='b') => { t.row(id,{displayTitle:'后台会话',running:true}); t.row(id,{displayTitle:'后台会话',running:false}); };
  const deferred = () => { let resolve; const promise=new Promise(r=>resolve=r); return {promise,resolve}; };
  {
    const f=fixture([event(11,'error')]);
    const t=boot({remoteSession:f.api}); t.setHidden(true);
    stop(t); await t.flush();
    check(t.word()==='ERROR' && t.task()===errorText, 'BG failed background turn displays ERROR and original message', 'BG failed turn was not ERROR');
    check(t.raised.length===1 && t.raised[0].title==='任务出错' && t.raised[0].sessionId==='b' && t.raised[0].tag==='dsh-notification-b-0', 'BG notification points at failed session, not current session', 'BG notification had wrong title or target');
    check(f.calls[0][1].sessionId==='b' && f.calls[1][1].address.sessionId==='b' && f.calls[1][1].throughSeq===100, 'BG result query uses its own session and authoritative journal cut', 'BG queried the wrong result');
    t.row('b',{running:false}); await t.flush();
    check(f.calls.length===2 && t.raised.length===1, 'BG duplicate idle publications neither query nor notify again', 'BG idle republish duplicated work');
    t.clock.advance(6000); f.records=[event(21,'completed')]; stop(t); await t.flush();
    check(t.word()==='COMPLETE' && t.task()==='后台会话', 'BG clean later turn reports completion with its own title', 'BG old failure contaminated later success');
    t.clock.advance(6000); f.records=[event(31,'error')]; stop(t); await t.flush();
    check(t.word()==='ERROR', 'BG same error on a later turn is not deduped', 'BG repeated error was lost');
    t.teardown()();
  }
  {
    const f=fixture([{type:'event',event:{type:'turn/start',seq:12,data:{turn:2}}}]);
    const t=boot({remoteSession:f.api}); stop(t); await t.flush();
    check(t.word()===undefined, 'BG a late end record is awaited, never guessed successful', 'BG guessed success while only start was available');
    f.records=[event(13,'error')]; t.clock.advance(150); await t.flush();
    check(t.word()==='ERROR', 'BG retry picks up a delayed failure result', 'BG delayed failure was missed');
    t.teardown()();
  }
  {
    const f=fixture([event(11,'completed')]);
    const t=boot({remoteSession:f.api}); stop(t); await t.flush(); t.clock.advance(6000);
    stop(t); await t.flush();
    check(t.word()===undefined, 'BG old already-reported success cannot stand in for the next turn', 'BG reused an old success result');
    f.records=[event(9,'completed')]; t.clock.advance(150); await t.flush();
    check(t.word()===undefined, 'BG an even older queried cut is not replayed as a new outcome', 'BG replayed an older result');
    f.records=[event(21,'error')]; t.clock.advance(150); await t.flush();
    check(t.word()==='ERROR', 'BG newer result replaces a stale queried cut', 'BG a stale cut swallowed the new failure');
    t.teardown()();
  }
  {
    const f=fixture([event(11,'error')]); const waiting=deferred();
    f.api.page=async (request,signal)=>{f.signal=signal;return waiting.promise;};
    const t=boot({remoteSession:f.api}); stop(t); await t.flush();
    t.row('b',{running:true}); waiting.resolve({ok:true,value:{records:[event(11,'error')]}}); await t.flush();
    check(t.word()===undefined && f.signal.aborted, 'BG restarting a session cancels its stale pending result query', 'BG stale result from previous run was reported');
    t.teardown()();
  }
  {
    const f=fixture([]); const waiting=deferred();
    f.api.page=async (request,signal)=>{f.signal=signal;return waiting.promise;};
    const t=boot({remoteSession:f.api}); stop(t); await t.flush(); t.teardown()();
    waiting.resolve({ok:true,value:{records:[event(11,'error')]}}); await t.flush();
    check(t.plates().length===0 && t.raised.length===0 && f.signal.aborted, 'BG teardown aborts queries and ignores late replies', 'BG query resurrected disposed plugin');
  }
  {
    const f=fixture([]); const waiting=deferred();
    f.api.page=async()=>waiting.promise;
    const t=boot({remoteSession:f.api}); stop(t); await t.flush();
    t.row('b',{removed:true,running:false}); waiting.resolve({ok:true,value:{records:[event(11,'error')]}}); await t.flush();
    check(t.word()===undefined, 'BG removed sessions cannot emit a late notification', 'BG removed session still notified');
    t.teardown()();
  }
  {
    let calls=0;
    const t=boot({remoteSession:{async projections(){calls++;return {ok:false,error:{message:'offline'}};},async page(){throw new Error('must not read a failed cut');}}});
    stop(t); await t.flush();
    for(let i=0;i<3;i++){t.clock.advance(150);await t.flush();}
    check(calls===4 && t.word()===undefined, 'BG unavailable result is retried finitely and never called COMPLETE', 'BG unavailable API guessed success or retried without a bound');
    t.teardown()();
  }
  {
    const f=fixture([event(11,'error')]); const t=boot({remoteSession:f.api});
    t.child('child',true); t.child('child',false); await t.flush();
    check(f.calls.length===0, 'BG child sessions do not emit standalone completion noise', 'BG child triggered background report');
    t.teardown()();
  }
  {
    const f=fixture([]); const waiting=deferred(); f.api.page=async()=>waiting.promise;
    const listeners=new Set(); let selected={key:'a'};
    const current={getSnapshot:()=>selected,subscribe:fn=>{listeners.add(fn);return()=>listeners.delete(fn);}};
    let entries=[]; const feedSubs=new Set();
    const feed={getSnapshot:()=>({entries,change:{kind:'append',entries}}),subscribe:fn=>{feedSubs.add(fn);return()=>feedSubs.delete(fn);}};
    const t=boot({remoteSession:f.api,modernList:true,uiSession:{current}}); t.setHidden(true);
    const sessions=t.ctx.get('sessions'),original=sessions.binding;
    sessions.binding=id=>id==='b'?{session:t.sessionA,eventSource:feed}:original(id);
    stop(t); await t.flush();
    selected={key:'b'}; for(const fn of [...listeners])fn();
    entries=[event(11,'error')]; for(const fn of [...feedSubs])fn();
    waiting.resolve({ok:true,value:{records:entries}}); await t.flush();
    check(t.word()==='ERROR' && t.raised.length===1, 'BG switching into a finishing session dedupes journal and query notifications', 'BG handover duplicated or lost the failure');
    t.teardown()();
  }
  if(failures){console.error(failures+' background checks failed');process.exitCode=1;}
  else console.log('all background-result checks passed');
})();
`;
new Function('require','__dirname','process',setup+cases)(require,__dirname,process).catch(error=>{console.error(error);process.exitCode=1;});
