# dsh-image-gen

[![dsh-plugin](https://img.shields.io/badge/topic-dsh--plugin-blue)](https://github.com/topics/dsh-plugin)

DeepSeek Harness 图片生成插件：给 agent 注册一个 `image_generate` 工具，让 dsh 里的大模型可以直接画图。

双通道支持：

| Provider | 模型 | 能力 |
|---|---|---|
| `volcano`（火山方舟，默认） | `doubao-seedream-5-0-pro-260628` | 文生图、图生图（`referenceImage`）、size 1K/2K/4K 或 WxH、水印开关 |
| `qwen`（阿里 MaaS） | `qwen-image-3.0-pro` | 文生图、`promptExtend` 提示词扩写 |

纯 JavaScript、零构建步骤，安装时无需 pnpm 构建授权。

## 安装

### 方式一：装进 profile（推荐）

```sh
dsh plugin --profile demo add github:Bald0Wang/dsh-imggenerate
dsh --profile demo
```

或从本地目录 / npm / tarball 安装：

```sh
dsh plugin --profile demo add ./dsh-image-gen        # 本地目录
dsh plugin --profile demo add dsh-image-gen          # npm（如已发布）
dsh plugin --profile demo add ./dsh-image-gen-0.1.0.tgz
```

### 方式二：不安装，直接 overlay

```sh
git clone https://github.com/Bald0Wang/dsh-imggenerate.git
cd dsh-imggenerate && npm install
cp quick.example.cordis.yml quick.cordis.yml   # 填入你的 key 与绝对路径
npx @deepseek-ai/dsh web --patch "$PWD/quick.cordis.yml"
```

## 配置 API Key（必做）

插件不携带任何密钥。二选一：

**A. profile 用户层（推荐）** — 编辑 `$DSH_HOME/profiles/<name>/cordis.patch.yml`（`dsh web` 对应 `web` profile），覆盖 `image-gen` 行（用户层在包层之后生效，需重述整个 config）：

```yaml
- id: image-gen
  config:
    defaultProvider: volcano
    qwenApiKey: 'sk-ws-...'
    volcanoApiKey: 'your-ark-key'
```

**B. 环境变量** — `DASHSCOPE_API_KEY`（qwen 通道）、`ARK_API_KEY`（volcano 通道）。显式 config 优先于环境变量。

## 配置项（cordis.yml 中 `config` 下覆盖）

| 键 | 默认值 | 说明 |
|---|---|---|
| `defaultProvider` | `volcano` | 未指定 provider 参数时使用 |
| `timeoutMs` | `180000` | 单次请求超时 |
| `qwenEndpoint` / `qwenModel` / `qwenApiKey` | 见 index.js | 阿里 MaaS 通道 |
| `volcanoEndpoint` / `volcanoModel` / `volcanoApiKey` | 见 index.js | 火山方舟通道 |
| `volcanoSize` / `volcanoWatermark` | `2K` / `true` | 火山默认尺寸与水印 |

## 工具参数（模型侧）

`prompt`（必填）、`provider`（qwen/volcano）、`size`、`referenceImage`（仅火山，图生图）、`watermark`（仅火山）、`promptExtend`（仅 qwen）、`seed`。

返回规范输出 `{provider, model, images:[{url}], size?, watermark?}`；工具结果以文本块携带 URL（供应商 URL 一般 24 小时过期，需及时下载）。

## 验证安装

启动日志应出现 `[image-gen] registered image_generate tool`；新开会话对模型说「用 image_generate 画一张……」。也可用 `dsh --profile <name> --dump-config` 查看是否包含 `# == dsh-image-gen` 层。
