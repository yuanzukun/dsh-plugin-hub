/**
 * dsh-image-gen: image-generation tool for DeepSeek Harness.
 *
 * Registers one model-facing tool `image_generate` backed by two providers:
 *  - qwen:    Aliyun MaaS multimodal-generation endpoint (qwen-image-3.0-pro)
 *  - volcano: Volcano Ark images/generations endpoint (doubao-seedream-5-0-pro)
 *
 * Canonical output carries provider image URLs (Volcano may instead return
 * base64, which is surfaced as a data: URI). Rendering stays text-only so the
 * tool result remains valid on text-only model routes.
 */

import Schema from '@deepseek-ai/schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'image-gen'
export const inject = ['tools']

export const Config = Schema.object({
  defaultProvider: Schema.string().default('volcano'),
  timeoutMs: Schema.number().default(180000),
  qwenEndpoint: Schema.string().default('https://llm-pux28gcqlwezimaw.cn-beijing.maas.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation'),
  qwenModel: Schema.string().default('qwen-image-3.0-pro'),
  qwenApiKey: Schema.string().default(''),
  volcanoEndpoint: Schema.string().default('https://ark.cn-beijing.volces.com/api/v3/images/generations'),
  volcanoModel: Schema.string().default('doubao-seedream-5-0-pro-260628'),
  volcanoApiKey: Schema.string().default(''),
  volcanoSize: Schema.string().default('2K'),
  volcanoWatermark: Schema.boolean().default(true),
})

const PROVIDERS = ['qwen', 'volcano']

/** POST JSON with a wall-clock timeout that also honors caller cancellation. */
async function postJson(url, headers, body, exec, timeoutMs) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(new Error(`request timed out after ${timeoutMs}ms`)), timeoutMs)
  const onCallerAbort = () => controller.abort(exec.signal.reason)
  if (exec.signal) {
    if (exec.signal.aborted) throw new Error('image generation aborted before request')
    exec.signal.addEventListener('abort', onCallerAbort, { once: true })
  }
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...headers },
      body: JSON.stringify(body),
      signal: controller.signal,
    })
    const text = await res.text()
    if (!res.ok) throw new Error(`provider API ${res.status}: ${text.slice(0, 500)}`)
    let data
    try {
      data = JSON.parse(text)
    } catch {
      throw new Error(`provider API returned non-JSON (${res.status}): ${text.slice(0, 300)}`)
    }
    if (data.code !== undefined && data.message !== undefined) {
      throw new Error(`provider API error ${data.code}: ${data.message}`)
    }
    if (data.error !== undefined) {
      throw new Error(`provider API error: ${data.error.message ?? JSON.stringify(data.error).slice(0, 300)}`)
    }
    return data
  } finally {
    clearTimeout(timer)
    if (exec.signal) exec.signal.removeEventListener('abort', onCallerAbort)
  }
}

/** Aliyun MaaS multimodal-generation: messages with a text part in, image URLs out. */
async function generateQwen(args, exec, c) {
  const apiKey = c.qwenApiKey || process.env.DASHSCOPE_API_KEY || ''
  if (!apiKey) throw new Error('qwen provider is not configured: set config.qwenApiKey (or DASHSCOPE_API_KEY)')
  if (args.referenceImage) {
    throw new Error('the qwen text-to-image endpoint takes no reference image; use provider "volcano" for image-to-image')
  }
  const parameters = { prompt_extend: args.promptExtend ?? true }
  if (args.size !== undefined) parameters.size = args.size
  if (args.seed !== undefined) parameters.seed = args.seed
  const data = await postJson(c.qwenEndpoint, { Authorization: `Bearer ${apiKey}` }, {
    model: c.qwenModel,
    input: { messages: [{ role: 'user', content: [{ text: args.prompt }] }] },
    parameters,
  }, exec, c.timeoutMs)
  const images = []
  for (const choice of data.output?.choices ?? []) {
    for (const part of choice.message?.content ?? []) {
      if (typeof part === 'string') continue
      if (part.image) images.push({ url: part.image })
    }
  }
  if (images.length === 0) throw new Error(`qwen returned no image: ${JSON.stringify(data.output).slice(0, 300)}`)
  return { provider: 'qwen', model: c.qwenModel, images }
}

/** Volcano Ark images/generations: OpenAI-style data[] of url or b64_json. */
async function generateVolcano(args, exec, c) {
  const apiKey = c.volcanoApiKey || process.env.ARK_API_KEY || ''
  if (!apiKey) throw new Error('volcano provider is not configured: set config.volcanoApiKey (or ARK_API_KEY)')
  const body = {
    model: c.volcanoModel,
    prompt: args.prompt,
    response_format: 'url',
    size: args.size ?? c.volcanoSize,
    stream: false,
    watermark: args.watermark ?? c.volcanoWatermark,
  }
  if (args.referenceImage) body.image = args.referenceImage
  if (args.seed !== undefined) body.seed = args.seed
  const data = await postJson(c.volcanoEndpoint, { Authorization: `Bearer ${apiKey}` }, body, exec, c.timeoutMs)
  const images = []
  for (const item of data.data ?? []) {
    if (item.url) images.push({ url: item.url })
    else if (item.b64_json) images.push({ url: `data:image/png;base64,${item.b64_json}` })
  }
  if (images.length === 0) throw new Error(`volcano returned no image: ${JSON.stringify(data).slice(0, 300)}`)
  return {
    provider: 'volcano',
    model: c.volcanoModel,
    images,
    size: body.size,
    watermark: body.watermark,
  }
}

export function apply(ctx, config) {
  const c = { ...config }
  ctx.tools.register(defineTool({
    name: 'image_generate',
    description:
      'Generate an image from a text prompt via a hosted image model. '
      + 'Providers: "volcano" (doubao-seedream: best quality, supports size 1K/2K/4K or WxH, optional referenceImage URL for image-to-image, watermark toggle) '
      + 'and "qwen" (qwen-image-3.0-pro: strong prompt following, optional promptExpand). '
      + 'Returns image URL(s). Prompts may be Chinese or English; detailed scene descriptions work best.',
    parameters: {
      prompt: { type: 'string', required: true, description: 'What to draw. Detailed descriptions of subject, style, lighting, and composition work best.' },
      provider: { type: 'string', enum: PROVIDERS, description: `Image provider. Defaults to "${c.defaultProvider}".` },
      size: { type: 'string', description: 'volcano: "1K"|"2K"|"4K" or "WxH" like "2048x2048"; qwen: provider format like "1664x928". Omit for provider default.' },
      referenceImage: { type: 'string', description: 'Public URL of a source image (volcano only): edits/reimagines it guided by the prompt.' },
      watermark: { type: 'boolean', description: 'volcano only: add provider watermark. Default true.' },
      promptExtend: { type: 'boolean', description: 'qwen only: let the provider expand the prompt for richer results. Default true.' },
      seed: { type: 'integer', description: 'Optional deterministic seed for reproducible generation.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          provider: { type: 'string', enum: PROVIDERS, required: true },
          model: { type: 'string', required: true },
          images: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: { url: { type: 'string', required: true } },
            },
          },
          size: { type: 'string' },
          watermark: { type: 'boolean' },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: `Generated ${value.images.length} image${value.images.length === 1 ? '' : 's'} via ${value.provider} (${value.model}`
          + `${value.size ? `, size ${value.size}` : ''}):\n` + value.images.map((image, i) => `${value.images.length === 1 ? '' : `${i + 1}. `}${image.url}`).join('\n')
          + '\n(URLs are provider-hosted and typically expire after 24h; download or embed them promptly.)',
      }],
    },
    timeoutMs: 300000,
    // Each call is an independent stateless API request; parallel calls are safe.
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const provider = args.provider ?? c.defaultProvider
      console.log(`[image-gen] image_generate [${provider}]: ${args.prompt.slice(0, 80)}`)
      const value = provider === 'qwen'
        ? await generateQwen(args, exec, c)
        : provider === 'volcano'
          ? await generateVolcano(args, exec, c)
          : throwInvalidProvider(provider)
      return value
    },
    presentCall(args) {
      return {
        card: 'generic',
        title: `Generate image${args.provider ? ` (${args.provider})` : ''}`,
        kind: 'other',
        rawInput: { prompt: args.prompt, size: args.size, referenceImage: args.referenceImage },
      }
    },
  }))
  console.log('[image-gen] registered image_generate tool')
}

function throwInvalidProvider(provider) {
  throw new Error(`unknown provider "${provider}"; expected one of: ${PROVIDERS.join(', ')}`)
}
