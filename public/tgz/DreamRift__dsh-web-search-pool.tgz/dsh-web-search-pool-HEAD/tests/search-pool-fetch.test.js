import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { TavilyAdapter } from '../src/adapters/tavily.js';
import { SearchPoolProvider } from '../src/dsh/provider.js';
import { SearchTakeover, OFFICIAL_FETCH_PROVIDER_IDS } from '../src/dsh/takeover.js';

// ── 通用 mock 响应 ────────────────────────────────────────────────────────────

function jsonResponse(status, body, headers = {}) {
  return {
    status,
    ok: status >= 200 && status < 300,
    headers: { get: (name) => headers[name.toLowerCase()] ?? null },
    json: async () => body,
  };
}

function options(overrides = {}) {
  return {
    enabled: true,
    available: true,
    entries: [{ id: 't1', provider: 'tavily', credentialRef: 'TAVILY_API_KEY_1', rpm: 60 }],
    strategy: 'weighted-round-robin',
    providerPriority: ['tavily'],
    allowedFails: 3,
    cooldownMs: 30000,
    retryAfterFallbackMs: 1000,
    usageCacheMs: 0,
    quotaReserveCredits: 2,
    quotaExhaustedCooldownMs: 1000,
    requestTimeoutMs: 5000,
    tavilyParams: { fetchDepth: 'basic', fetchFormat: 'markdown' },
    exaParams: {},
    resolveKey: async () => 'tvly-test',
    recordRequest: () => {},
    ...overrides,
  };
}

// ── Part A：TavilyAdapter.extract（注入 fetchImpl，不碰全局）─────────────────

test('TavilyAdapter.extract: 成功映射为 WebFetchResult，默认 basic + markdown + Bearer 认证', async () => {
  const calls = [];
  const adapter = new TavilyAdapter({
    fetchImpl: async (url, init) => {
      calls.push({ url: String(url), init });
      return jsonResponse(200, {
        results: [{ url: 'https://a.com/doc', raw_content: '# Title' }],
        failed_results: [],
      });
    },
  });
  const result = await adapter.extract({ url: 'https://a.com/doc', apiKey: 'k1' });
  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, 'https://api.tavily.com/extract');
  assert.equal(calls[0].init.headers.authorization, 'Bearer k1');
  const body = JSON.parse(calls[0].init.body);
  assert.deepEqual(body.urls, ['https://a.com/doc']);
  assert.equal(body.extract_depth, 'basic');
  assert.equal(body.format, 'markdown');
  assert.deepEqual(result, {
    url: 'https://a.com/doc',
    statusCode: 200,
    body: { kind: 'text', content: '# Title' },
    truncated: false,
  });
});

test('TavilyAdapter.extract: extractDepth/format 覆盖透传', async () => {
  const bodies = [];
  const adapter = new TavilyAdapter({
    fetchImpl: async (_url, init) => {
      bodies.push(JSON.parse(init.body));
      return jsonResponse(200, { results: [{ url: 'https://a.com', raw_content: 'x' }], failed_results: [] });
    },
  });
  await adapter.extract({ url: 'https://a.com', apiKey: 'k', extractDepth: 'advanced', format: 'text' });
  assert.equal(bodies[0].extract_depth, 'advanced');
  assert.equal(bodies[0].format, 'text');
});

test('TavilyAdapter.extract: failed_results 抛 ProviderHttpError 并带原因', async () => {
  const adapter = new TavilyAdapter({
    fetchImpl: async () => jsonResponse(200, { results: [], failed_results: [{ url: 'https://x.com', error: 'SITE_UNREACHABLE' }] }),
  });
  await assert.rejects(
    adapter.extract({ url: 'https://x.com', apiKey: 'k' }),
    (error) => error.name === 'ProviderHttpError' && /SITE_UNREACHABLE/.test(error.message),
  );
});

test('TavilyAdapter.extract: results 与 failed_results 均空时抛「no content extracted」', async () => {
  const adapter = new TavilyAdapter({ fetchImpl: async () => jsonResponse(200, { results: [], failed_results: [] }) });
  await assert.rejects(
    adapter.extract({ url: 'https://x.com', apiKey: 'k' }),
    (error) => error.name === 'ProviderHttpError' && /no content extracted/.test(error.message),
  );
});

test('TavilyAdapter.extract: 空 raw_content 是真实结果，返回空 content 不抛', async () => {
  const adapter = new TavilyAdapter({
    fetchImpl: async () => jsonResponse(200, { results: [{ url: 'https://a.com', raw_content: '' }], failed_results: [] }),
  });
  const result = await adapter.extract({ url: 'https://a.com', apiKey: 'k' });
  assert.equal(result.body.content, '');
  assert.equal(result.body.kind, 'text');
});

test('TavilyAdapter.extract: 429 转 RateLimitError（解析 Retry-After）', async () => {
  const adapter = new TavilyAdapter({
    fetchImpl: async () => jsonResponse(429, {}, { 'retry-after': '7' }),
  });
  await assert.rejects(
    adapter.extract({ url: 'https://a.com', apiKey: 'k' }),
    (error) => error.name === 'RateLimitError' && error.retryAfterMs === 7000,
  );
});

test('TavilyAdapter.extract: 500 转 ProviderHttpError(status=500)', async () => {
  const adapter = new TavilyAdapter({ fetchImpl: async () => jsonResponse(500, {}) });
  await assert.rejects(
    adapter.extract({ url: 'https://a.com', apiKey: 'k' }),
    (error) => error.name === 'ProviderHttpError' && error.status === 500,
  );
});

test('TavilyAdapter.extract: 非 JSON 响应体转 ProviderHttpError', async () => {
  const adapter = new TavilyAdapter({
    fetchImpl: async () => ({ status: 200, ok: true, headers: { get: () => null }, json: async () => { throw new SyntaxError('bad json'); } }),
  });
  await assert.rejects(
    adapter.extract({ url: 'https://a.com', apiKey: 'k' }),
    (error) => error.name === 'ProviderHttpError' && /unprocessable extract body/.test(error.message),
  );
});

// ── Part B：SearchPoolProvider.fetch（fetchImpl 构造注入，不碰全局猴补丁）─────
// 说明：run-tests.mjs 在同一进程内顺序执行全部测试文件，全局 fetch 的猴补丁会在
// import 阶段互相覆盖（执行期全局值取决于最后一个 import 的文件）。provider 的
// fetchImpl 注入点让本文件与 provider.test.js 的全局 mock 彻底解耦。

let extractCalls = 0;
let lastExtract = null;
let failingFetchKeys = new Set();
let usageRemaining = 1000;

function injectedFetch(url, init) {
  const target = String(url);
  if (target.includes('/usage')) {
    return Promise.resolve(jsonResponse(200, {
      account: { current_plan: 'Researcher', plan_usage: 1000 - usageRemaining, plan_limit: 1000 },
    }));
  }
  if (target.includes('/extract')) {
    extractCalls += 1;
    lastExtract = { url: target, init };
    const key = String(init.headers?.authorization ?? '').replace(/^Bearer /, '');
    if (failingFetchKeys.has(key)) return Promise.resolve(jsonResponse(500, {}));
    return Promise.resolve(jsonResponse(200, {
      results: [{ url: JSON.parse(init.body).urls[0], raw_content: 'fetched content' }],
      failed_results: [],
    }));
  }
  return Promise.reject(new Error('unexpected fetch url: ' + url));
}

function resetFetchMocks() {
  extractCalls = 0;
  failingFetchKeys = new Set();
  lastExtract = null;
  usageRemaining = 1000;
}

function injectedOptions(overrides = {}) {
  return options({ usageCacheMs: 60000, ...overrides, fetchImpl: injectedFetch });
}

test('SearchPoolProvider.fetch: 成功走 Tavily /extract 并透传 fetchDepth/fetchFormat', async () => {
  resetFetchMocks();
  const opts = injectedOptions();
  const provider = new SearchPoolProvider(() => opts);
  const result = await provider.fetch({ url: 'https://a.com/doc' });
  assert.equal(extractCalls, 1);
  const body = JSON.parse(lastExtract.init.body);
  assert.equal(body.extract_depth, 'basic');
  assert.equal(body.format, 'markdown');
  assert.deepEqual(result, {
    url: 'https://a.com/doc',
    statusCode: 200,
    body: { kind: 'text', content: 'fetched content' },
    truncated: false,
  });
});

test('SearchPoolProvider.fetch: 全部 key 失败转 WEB_PROVIDER_ERROR，逐 key 尝试', async () => {
  resetFetchMocks();
  failingFetchKeys = new Set(['tvly-test']);
  const records = [];
  const opts = injectedOptions({ recordRequest: (r) => records.push(r.code) });
  const provider = new SearchPoolProvider(() => opts);
  const error = await provider.fetch({ url: 'https://a.com' }).then(() => null, (e) => e);
  assert.equal(error?.code, 'WEB_PROVIDER_ERROR');
  assert.ok(records.includes('ERROR'));
});

test('SearchPoolProvider.fetch: 额度不足时被门禁拦截，不发 /extract', async () => {
  resetFetchMocks();
  const opts = injectedOptions({ quotaReserveCredits: 2 });
  const provider = new SearchPoolProvider(() => opts);
  // 先显式刷新（建池 + 写回额度缓存），再把该 key 的剩余额度改成 1（< 保留值 2）。
  await provider.refreshUsage(opts);
  provider._usageCache.byRef.get('TAVILY_API_KEY_1').remaining = 1;
  const error = await provider.fetch({ url: 'https://a.com' }).then(() => null, (e) => e);
  assert.equal(error?.code, 'WEB_PROVIDER_ERROR');
  assert.equal(extractCalls, 0);
});

test('SearchPoolProvider.fetch: 池里只有 Exa key 转 WEB_PROVIDER_UNAVAILABLE（fetch 仅 Tavily）', async () => {
  resetFetchMocks();
  const opts = injectedOptions({ entries: [{ id: 'e1', provider: 'exa', credentialRef: 'EXA_KEY', rpm: 60 }] });
  const provider = new SearchPoolProvider(() => opts);
  const error = await provider.fetch({ url: 'https://a.com' }).then(() => null, (e) => e);
  assert.equal(error?.code, 'WEB_PROVIDER_UNAVAILABLE');
  assert.equal(extractCalls, 0);
});

test('SearchPoolProvider.fetch: 非 http(s) URL 转 WEB_INVALID_URL 且不发请求', async () => {
  resetFetchMocks();
  const opts = injectedOptions();
  const provider = new SearchPoolProvider(() => opts);
  for (const url of ['ftp://a.com/x', 'not a url']) {
    const error = await provider.fetch({ url }).then(() => null, (e) => e);
    assert.equal(error?.code, 'WEB_INVALID_URL', url);
  }
  assert.equal(extractCalls, 0);
});

test('SearchPoolProvider.fetch: 禁用态委托官方 fetch provider', async () => {
  resetFetchMocks();
  const opts = injectedOptions({ enabled: false });
  const provider = new SearchPoolProvider(() => opts);
  provider.setDelegate(() => ({
    search: async () => { throw new Error('not used'); },
    fetch: async (request) => ({ url: request.url, statusCode: 200, body: { kind: 'text', content: 'official fetch' }, truncated: false }),
    available: () => true,
  }));
  const result = await provider.fetch({ url: 'https://a.com' });
  assert.equal(result.body.content, 'official fetch');
  assert.equal(extractCalls, 0);
});

// ── Part C：SearchTakeover 的 fetch 接管 ─────────────────────────────────────

function makeWeb(config, officialResult) {
  const searchProviders = new Map();
  const fetchProviders = new Map();
  const calls = { serviceFetch: 0, officialFetch: 0 };
  const officialProvider = {
    id: 'deepseek-fetch-api',
    available: () => true,
    fetch: async (request) => {
      calls.officialFetch += 1;
      return officialResult ?? { url: request.url, statusCode: 200, body: { kind: 'text', content: 'official' }, truncated: false };
    },
  };
  fetchProviders.set(officialProvider.id, officialProvider);
  const web = {
    config,
    searchProviders,
    fetchProviders,
    calls,
    registerSearchProvider(provider) {
      searchProviders.set(provider.id, provider);
      return () => { if (searchProviders.get(provider.id) === provider) searchProviders.delete(provider.id); };
    },
    async search() { throw new Error('official search should not be called'); },
    async fetch(request) {
      calls.serviceFetch += 1;
      const provider = fetchProviders.get(config.fetchProvider);
      if (provider == null || provider.available() !== true) {
        throw Object.assign(new Error('no fetch provider'), { code: 'WEB_PROVIDER_UNAVAILABLE' });
      }
      return provider.fetch(request);
    },
  };
  return { web, officialProvider, calls };
}

function poolProviderFor(opts) {
  return new SearchPoolProvider(() => opts);
}

const FETCH_OK = (url) => ({ url, statusCode: 200, body: { kind: 'text', content: 'fetched content' }, truncated: false });

test('SearchTakeover: 服务级接管 web.fetch——启用走池，fetchEnabled=false 走官方', async () => {
  resetFetchMocks();
  const provider = poolProviderFor(injectedOptions());
  const takeover = new SearchTakeover(provider, { enabled: true, fetchEnabled: true });
  const config = { searchProvider: 'deepseek-search-api', fetchProvider: 'deepseek-fetch-api' };
  const { web, calls } = makeWeb(config);

  takeover.attach(web);
  assert.equal(takeover.serviceMode, true);

  const result = await web.fetch({ url: 'https://a.com/doc' });
  assert.deepEqual(result, FETCH_OK('https://a.com/doc'));
  assert.equal(extractCalls, 1);
  assert.equal(calls.serviceFetch, 0);

  // fetchEnabled=false：原样转发 WebRuntime.fetch（按 fetchProvider 选官方）。
  takeover.setFetchEnabled(false);
  const official = await web.fetch({ url: 'https://a.com/doc' });
  assert.equal(official.body.content, 'official');
  assert.equal(calls.serviceFetch, 1);
  assert.equal(extractCalls, 1); // 池未被再次调用

  // 恢复 fetchEnabled：继续走池。
  takeover.setFetchEnabled(true);
  await web.fetch({ url: 'https://b.com' });
  assert.equal(extractCalls, 2);
  takeover.dispose();
});

test('SearchTakeover: 池抓取失败默认抛中性错误；开启回退走官方', async () => {
  resetFetchMocks();
  failingFetchKeys = new Set(['tvly-test']);
  const provider = poolProviderFor(injectedOptions());
  const config = { searchProvider: 'deepseek-search-api', fetchProvider: 'deepseek-fetch-api' };
  const { web, calls } = makeWeb(config);
  const takeover = new SearchTakeover(provider, { enabled: true, fetchEnabled: true, fetchFallbackToOfficial: false });
  takeover.attach(web);

  const error = await web.fetch({ url: 'https://a.com' }).then(() => null, (e) => e);
  assert.equal(error?.code, 'WEB_PROVIDER_UNAVAILABLE');
  assert.match(error?.message ?? '', /Web fetch is temporarily unavailable/);
  assert.equal(calls.officialFetch, 0);

  takeover.setFetchFallbackToOfficial(true);
  const result = await web.fetch({ url: 'https://a.com' });
  assert.equal(result.body.content, 'official');
  assert.equal(calls.officialFetch, 1);
  takeover.dispose();
});

test('SearchTakeover: dispose 后 web.fetch 恢复原方法', async () => {
  resetFetchMocks();
  const provider = poolProviderFor(injectedOptions());
  const config = { searchProvider: 'deepseek-search-api', fetchProvider: 'deepseek-fetch-api' };
  const { web } = makeWeb(config);
  const original = web.fetch;
  const takeover = new SearchTakeover(provider, { enabled: true, fetchEnabled: true });
  takeover.attach(web);
  assert.notEqual(web.fetch, original);
  takeover.dispose();
  assert.equal(web.fetch, original);
});

test('OFFICIAL_FETCH_PROVIDER_IDS: 云端 Fetch 优先，本机 http 兜底', () => {
  assert.deepEqual([...OFFICIAL_FETCH_PROVIDER_IDS], ['deepseek-fetch-api', 'http']);
});
