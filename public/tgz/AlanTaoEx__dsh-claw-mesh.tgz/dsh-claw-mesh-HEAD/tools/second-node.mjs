/**
 * Dev harness: run a second Claw-Mesh node in plain Node, outside the DSH host.
 *
 * It exists so the LAN transport (discovery, pairing, permission gate, remote
 * dispatch) can be exercised on a single machine. The node gets its own state
 * directory, its own ports, and a stub context that satisfies the two host
 * services the plugin touches (`tools`, `effect`).
 *
 *   DSH_MESH_STATE_DIR=/tmp/claw-mesh-b node tools/second-node.mjs
 */
import { apply } from '../index.js';

const stateDir = process.env.DSH_MESH_STATE_DIR;
if (!stateDir) {
  console.error('set DSH_MESH_STATE_DIR to a scratch directory');
  process.exit(2);
}

const ctx = {
  tools: { register: () => () => {} },
  // The harness half publishes a system-prompt section; the stub just accepts it.
  systemPrompt: { section: () => () => {} },
  effect: (fn) => {
    const dispose = fn();
    return () => {
      if (typeof dispose === 'function') dispose();
    };
  },
  logger: console,
  provide: () => () => {},
  // Stands in for the DSH account service: signing in is simulated through
  // DSH_MESH_FAKE_ACCOUNT (see index.js), so this node just reports signed-out.
  get: (name) =>
    name === 'deepseekAccount'
      ? { getState: async () => ({ status: 'signed-out' }), getDeviceIdentity: async () => ({}), getProfile: async () => null }
      : undefined,
};

apply(ctx, {
  port: Number(process.env.DSH_MESH_PORT || 46850),
  uiPort: Number(process.env.DSH_MESH_UI_PORT || 46860),
  discoveryPort: Number(process.env.DSH_MESH_DISCOVERY_PORT || 46801),
});

setInterval(() => {}, 1 << 30);
