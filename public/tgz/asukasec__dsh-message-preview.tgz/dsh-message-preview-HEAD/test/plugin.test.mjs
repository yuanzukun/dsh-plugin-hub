import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

function schemaChain() {
  const chain = {};
  chain.int = () => chain;
  chain.optional = () => chain;
  chain.strict = () => chain;
  return chain;
}

function loadHostInternals() {
  let source = fs.readFileSync(path.join(root, "lib/index.js"), "utf8");
  source = source
    .replace(/^import .*;\r?\n/gm, "")
    .replace(
      "export { Config, apply, name };",
      "globalThis.__host = { Config, apply, name, PROJECTION_KEY, textOf, messageIndexProjectionDefinition };"
    );
  const context = {
    z: { object: () => schemaChain() },
    zz: {
      array: () => schemaChain(),
      number: () => schemaChain(),
      object: () => schemaChain(),
      string: () => schemaChain()
    }
  };
  vm.runInNewContext(source, context, { filename: "lib/index.js" });
  return context.__host;
}

function loadClientInternals() {
  let source = fs.readFileSync(path.join(root, "lib/client.js"), "utf8");
  source = source.replace(
    "exports.MessageRail = MessageRail;",
    "exports.__testing = { userTextOf, normalize, collectFromNodes, anchorKeyOf, gapOf, layoutBlocks, blockTopBefore };\n\t\texports.MessageRail = MessageRail;"
  );
  let client;
  const context = {
    window: {
      __ModuleLoader__: {
        load(definition) {
          client = definition.factory(() => ({}));
        }
      }
    },
    Map,
    Promise,
    setTimeout,
    clearTimeout,
    setInterval,
    clearInterval
  };
  vm.runInNewContext(source, context, { filename: "lib/client.js" });
  return client.__testing;
}

test("manifest exposes an installable DSH bundle with direct client providers", () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
  assert.equal(pkg.version, "0.1.1");
  assert.equal(pkg.engines.node, ">=22");
  assert.equal(pkg.dsh.bundle.patch, "./cordis.patch.yml");
  assert.ok(pkg.dsh.client.inject.includes("@deepseek-ai/dsh-client-ui-slots"));
  assert.ok(pkg.dsh.client.inject.includes("@deepseek-ai/dsh-client-ui-conversation"));
  for (const file of ["lib/index.js", "lib/client.js", "cordis.patch.yml", "install.cmd", "install.ps1"]) {
    assert.ok(fs.existsSync(path.join(root, file)), `${file} must exist`);
  }
});

test("host projection accepts only direct user messages and bounds preview text", () => {
  const { PROJECTION_KEY, messageIndexProjectionDefinition: projection } = loadHostInternals();
  assert.equal(PROJECTION_KEY, "dshMessagePreview");
  assert.equal(projection.key, PROJECTION_KEY);
  assert.match(fs.readFileSync(path.join(root, "lib/client.js"), "utf8"), new RegExp(`useProjection\\(\"${PROJECTION_KEY}\"\\)`));
  const initial = projection.init();
  const ignored = projection.apply(initial, {
    type: "user/message",
    seq: 1,
    time: 2,
    data: { source: { kind: "plugin" }, content: [{ type: "text", text: "hidden" }] }
  });
  assert.equal(ignored, initial);
  const text = `  ${"x".repeat(90)}  `;
  const next = projection.apply(initial, {
    type: "user/message",
    seq: 3,
    time: 4,
    data: {
      id: "abc",
      source: { kind: "user" },
      content: [{ type: "text", text }, { type: "image" }]
    }
  });
  assert.equal(next.messages.length, 1);
  assert.equal(next.messages[0].seq, 3);
  assert.equal(next.messages[0].id, "abc");
  assert.equal(next.messages[0].text.length, 80);
});

test("client fallback collects user nodes and reconstructs durable anchors", () => {
  const { anchorKeyOf, collectFromNodes } = loadClientInternals();
  const nodes = new Map([
    ["user", { kind: "user", key: "13:input-messageabc", anchorSeq: 8, data: { time: 10, content: [{ type: "text", text: " hello " }] } }],
    ["assistant", { kind: "assistant", key: "other", anchorSeq: 9, data: { time: 11, content: [{ type: "text", text: "ignored" }] } }]
  ]);
  const messages = collectFromNodes({ chat: { nodes } });
  assert.equal(messages.length, 1);
  assert.equal(messages[0].text, "hello");
  assert.equal(anchorKeyOf({ id: "abc" }), "13:input-messageabc");
  assert.equal(anchorKeyOf({ key: "direct", id: "abc" }), "direct");
});

test("rail layout remains within its pixel budget for very long sessions", () => {
  const { gapOf, layoutBlocks } = loadClientInternals();
  const messages = Array.from({ length: 1_000 }, (_, index) => ({ text: "x".repeat(index % 120) }));
  const railHeight = 480;
  const heights = layoutBlocks(messages, railHeight);
  assert.equal(heights.length, messages.length);
  assert.ok(heights.every((height) => height > 0));
  const occupied = heights.reduce((sum, height) => sum + height, 0) + gapOf(messages.length) * (messages.length - 1) + 16;
  assert.ok(occupied <= railHeight + 1e-7, `occupied ${occupied} exceeds ${railHeight}`);
});
