// AntiGravity 插件设置页(注册 plugins.item,进「内置插件 → 插件列表」条目详情,
// 与官方 subagent/shell 设置页同机制)。
// 复用 dsh primitives 组件(Button/图标/writeClipboard)与官方
// ui-settings-plugins 的 PluginCard/fields CSS(注入同款样式类)。
// 字段读写走官方 SettingsScope;状态/测试探测需会话级 remote(暂不可用)。
// 服务端直接 spawn agy CLI,不落会话。
window.__ModuleLoader__.load({
  id: '@flg1217/dsh-llm-agy',
  factory: (require) => {
    const module = { exports: {} }
    const exports = module.exports
    const react = require('react')
    const slots = require('@deepseek-ai/dsh-client-ui-slots')
    const P = require('@deepseek-ai/dsh-client-ui-primitives')

    const {
      Button, Input, Modal, IconLoadingOutlineRegular, IconCheckOutlineRegular, IconRefreshOutlineRegular,
      IconCopyOutlineRegular, IconChevronDownOutlineMedium, writeClipboard,
      DisclosureRow, StateDot, IconBrowseOutlineRegular, IconApiOutlineMedium, IconEditOutlineRegular,
      IconSearchOutlineRegular, IconGlobeOutlineMedium,
    } = P

    // ── 官方 PluginCard CSS(与 ui-settings-plugins 完全一致) ──
    const CSS = {
      card: '.dshAgy_card{border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-3);border-radius:12px;list-style:none;transition:border-color .16s,background .16s}',
      cardHover: '.dshAgy_card:hover{border-color:var(--dsw-alias-label-dimmed)}',
      cardOpen: '.dshAgy_cardOpen{background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-label-dimmed)}',
      header: '.dshAgy_header{appearance:none;width:100%;font:inherit;color:inherit;text-align:left;cursor:pointer;background:0 0;border:0;border-radius:12px;align-items:center;gap:12px;padding:14px 16px;display:flex}',
      headerFocus: '.dshAgy_header:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:-2px}',
      headText: '.dshAgy_headText{flex-direction:column;flex:1;gap:4px;min-width:0;display:flex}',
      name: '.dshAgy_name{color:var(--dsw-alias-label-primary);font-size:15px;font-weight:600;line-height:1.4}',
      description: '.dshAgy_description{color:var(--dsw-alias-label-tertiary);font-size:13px;line-height:1.5}',
      chevron: '.dshAgy_chevron{color:var(--dsw-alias-label-tertiary);flex:none;transition:transform .16s}',
      chevronOpen: '.dshAgy_chevronOpen{transform:rotate(180deg)}',
      body: '.dshAgy_body{border-top:1px solid var(--dsw-alias-border-l2);margin:0 16px;padding-bottom:8px}',
      page: '.dshAgy_page{display:flex;flex-direction:column}',
      field: '.dshAgy_field{flex-direction:column;gap:6px;padding:12px 0;display:flex}',
      fieldTop: '.dshAgy_field+.dshAgy_field{border-top:1px solid var(--dsw-alias-border-l2)}',
      fieldHead: '.dshAgy_fieldHead{align-items:center;gap:8px;display:flex}',
      label: '.dshAgy_label{min-width:0;color:var(--dsw-alias-label-primary);flex:1;font-size:13px;font-weight:500;line-height:1.5}',
      hint: '.dshAgy_hint{color:var(--dsw-alias-label-tertiary);margin:0;font-size:12px;line-height:1.5}',
      badge: '.dshAgy_badge{white-space:nowrap;background:var(--dsw-alias-bg-module-platform);color:var(--dsw-alias-label-secondary);border-radius:999px;padding:1px 8px;font-size:11px;font-weight:500;line-height:17px}',
      code: '.dshAgy_code{display:flex;align-items:center;gap:8px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-3);border-radius:8px;padding:6px 10px;font-size:12px}',
      pre: '.dshAgy_pre{margin:8px 0 0;white-space:pre-wrap;font-size:12px;line-height:1.5;color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-bg-layer-3);border-radius:8px;padding:8px 10px}',
      row: '.dshAgy_row{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:12px 0}',
      // 模型输入框:铺满卡片宽度;min-width:0 避免 flex 项被内容撑爆导致超出卡片
      modelField: '.dshAgy_modelField{display:flex;width:100%;min-width:0;box-sizing:border-box}.dshAgy_modelField input{flex:1;min-width:0;width:100%;box-sizing:border-box}',
      // 获取模型弹窗列表:抄 Menu.module.css 的菜单卡片 + 行样式
      pickerList: '.dshAgy_pickerList{box-sizing:border-box;padding:4px;display:flex;flex-direction:column;gap:0;border:1px solid var(--dsw-alias-border-inverted);border-radius:12px;background:var(--dsw-specific-menu);box-shadow:var(--dsw-shadow-lv3);max-height:60vh;overflow-y:auto}',
      pickerItem: '.dshAgy_pickerItem{display:flex;align-items:center;gap:8px;width:100%;min-height:40px;padding:8px 10px;border:none;border-radius:10px;background:transparent;cursor:pointer;font-size:14px;line-height:22px;color:var(--dsw-alias-label-primary);text-align:left}.dshAgy_pickerItem:hover{background:var(--dsw-alias-interactive-bg-hover)}',
      pickerLabel: '.dshAgy_pickerLabel{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
      pickerCheck: '.dshAgy_pickerCheck{flex:none;color:var(--dsw-alias-label-primary)}',
      // read_image_agy 会话工具卡片(样式对齐 ui-tool ToolRow 的 read 家族行)
      tvRoot: '.dshAgy_tvRoot{display:flex;flex-direction:column}',
      tvRow: '.dshAgy_tvRow{position:relative;overflow:hidden}',
      tvLeading: '.dshAgy_tvLeading{flex-shrink:0}',
      tvTitle: '.dshAgy_tvTitle{font-weight:400}',
      tvChevron: '.dshAgy_tvChevron{color:var(--dsw-alias-label-secondary)}',
      tvSep: '.dshAgy_tvSep{flex:none;width:2px;height:2px;border-radius:1px;margin:0 8px;background:var(--dsw-alias-label-caption)}',
      tvSummary: '.dshAgy_tvSummary{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:var(--dsh-content-font-size-secondary,13px);line-height:calc(24px + var(--dsh-content-font-delta,0px));color:var(--dsw-alias-label-tertiary)}',
      tvErrorSummary: '.dshAgy_tvErrorSummary{color:var(--dsw-alias-state-error-primary)}',
      tvFileLink: '.dshAgy_tvFileLink{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin:0;padding:0;border:none;background:none;font:inherit;text-align:left;font-size:var(--dsh-content-font-size-secondary,13px);line-height:calc(24px + var(--dsh-content-font-delta,0px));color:var(--dsw-alias-label-secondary);text-decoration:underline dotted;text-decoration-color:var(--dsw-alias-label-tertiary);text-decoration-thickness:1px;text-underline-offset:3px;cursor:pointer}.dshAgy_tvFileLink:hover{color:var(--dsw-alias-label-primary);text-decoration-color:currentColor}',
      tvBody: '.dshAgy_tvBody{display:flex;flex-direction:column;gap:4px;margin:4px 0 4px 4px}',
      tvImg: '.dshAgy_tvImg{max-width:100%;max-height:320px;width:auto;border-radius:8px;border:0.5px solid var(--dsw-alias-border-l1);align-self:flex-start}',
      tvDesc: '.dshAgy_tvDesc{white-space:pre-wrap;overflow-wrap:anywhere;font:var(--dsw-font-xs-13);color:var(--dsw-alias-label-tertiary)}',
      // 文件类行的正文(读取预览/diff):等宽代码块样式,限高滚动
      tvCode: '.dshAgy_tvCode{white-space:pre-wrap;overflow-wrap:anywhere;font:var(--dsw-font-markdown-code-block-small);color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-markdown-code-block);border:.5px solid var(--dsw-alias-border-l1);border-radius:8px;padding:8px 10px;max-height:300px;overflow:auto}',
    }
    const cssText = Object.values(CSS).join('')
    const tagId = '@flg1217/llm-agy/plugin-card.css'
    if (typeof document !== 'undefined' && document.querySelector(`style[data-plugin-css=${JSON.stringify(tagId)}]`) === null) {
      const tag = document.createElement('style')
      tag.dataset.plugin = '@flg1217/llm-agy'
      tag.dataset.pluginCss = tagId
      tag.textContent = cssText
      document.head.appendChild(tag)
    }
    const C = {
      card: 'dshAgy_card', cardOpen: 'dshAgy_cardOpen', header: 'dshAgy_header',
      headText: 'dshAgy_headText', name: 'dshAgy_name', description: 'dshAgy_description',
      chevron: 'dshAgy_chevron', chevronOpen: 'dshAgy_chevronOpen', body: 'dshAgy_body',
      page: 'dshAgy_page',
      field: 'dshAgy_field', fieldHead: 'dshAgy_fieldHead', label: 'dshAgy_label',
      hint: 'dshAgy_hint', badge: 'dshAgy_badge', code: 'dshAgy_code',
      pre: 'dshAgy_pre', row: 'dshAgy_row', modelField: 'dshAgy_modelField',
      pickerList: 'dshAgy_pickerList', pickerItem: 'dshAgy_pickerItem',
      pickerLabel: 'dshAgy_pickerLabel', pickerCheck: 'dshAgy_pickerCheck',
      // read_image_agy 工具卡片(与上面 CSS 规则对象的 tv* 选择器一一对应)
      tvRoot: 'dshAgy_tvRoot', tvRow: 'dshAgy_tvRow', tvLeading: 'dshAgy_tvLeading',
      tvTitle: 'dshAgy_tvTitle', tvChevron: 'dshAgy_tvChevron', tvSep: 'dshAgy_tvSep',
      tvSummary: 'dshAgy_tvSummary', tvErrorSummary: 'dshAgy_tvErrorSummary',
      tvFileLink: 'dshAgy_tvFileLink', tvBody: 'dshAgy_tvBody',
      tvImg: 'dshAgy_tvImg', tvDesc: 'dshAgy_tvDesc', tvCode: 'dshAgy_tvCode',
    }

    // 多系统安装命令 + 工具说明
    const INSTALL_CMDS = [
      { label: 'Windows (winget)', cmd: 'winget install --id Google.Antigravity' },
      { label: 'macOS (Homebrew)', cmd: 'brew install --cask antigravity' },
      { label: 'Linux / macOS (curl)', cmd: 'curl -fsSL https://antigravity.google/install | bash' },
      { label: 'npm (global)', cmd: 'npm install -g @antigravity/cli' },
    ]
    const TOOLS = [
      { name: 'subagent_agy_ui', desc: '前端/UI 设计、样式、视觉实现、截图核验(continuable 可复用长线会话)' },
      { name: 'search_web_agy', desc: 'AGY 深度网络搜索:自动搜索、阅读全文、综合引用回答,无短超时限制' },
    ]

    /** 安装命令行:label + code + 复制按钮(带已复制状态)。 */
    function InstallCommandRow({ label, cmd }) {
      const [copied, setCopied] = react.useState(false)
      const copy = react.useCallback(async () => {
        try { await writeClipboard(cmd) } catch { /* 剪贴板失败静默 */ }
        setCopied(true)
        setTimeout(() => setCopied(false), 1500)
      }, [cmd])
      return react.createElement('div', { className: C.field },
        react.createElement('div', { className: C.fieldHead },
          react.createElement('span', { className: C.label }, label),
          react.createElement('span', { className: C.hint, style: { fontFamily: 'var(--dsw-font-family-code, monospace)' } }, cmd),
          react.createElement(Button, {
            size: 'sm', variant: 'ghost', onClick: copy,
            icon: copied
              ? react.createElement(IconCheckOutlineRegular, { size: 12 })
              : react.createElement(IconCopyOutlineRegular, { size: 12 }),
          }, copied ? '已复制' : '复制'),
        ),
      )
    }

    function AgyCard(props) {
      // 列表摘要视图:一句话(官方 ItemCard 的 description 渲染此返回值)。
      if (props.view === 'summary') return 'AGY(CLI)子代理:默认模型/代理/工具开关,检测安装与登录'
      const [checking, setChecking] = react.useState(false)
      const [testing, setTesting] = react.useState(false)
      const [statusText, setStatusText] = react.useState('')
      const [testText, setTestText] = react.useState('')
      const scope = props.scope


      // 探测(状态/测试)需 remote.llm 会话服务;0.1.2 插件设置卡(root)暂不可用。
      const runProbe = react.useCallback(async (_provider, setOut, setBusy) => {
        setBusy(true)
        setOut('状态/测试探测在 0.1.2 插件设置页暂不可用(需会话级 remote);字段编辑正常。')
        setBusy(false)
      }, [])

      const onStatus = react.useCallback(() => runProbe('status', setStatusText, setChecking), [runProbe])
      const onTest = react.useCallback(() => runProbe('test', setTestText, setTesting), [runProbe])

      // 看图分工提示开关:读写 agy settings namespace 的 delegationGuide。
      const [guideOn, setGuideOn] = react.useState(true)
      react.useEffect(() => {
        try {
          const v = scope.getSnapshot().value
          if (v?.delegationGuide !== undefined) setGuideOn(Boolean(v.delegationGuide))
        } catch { /* 镜像未就绪 */ }
        return scope.subscribe(() => {
          const v2 = scope.getSnapshot().value
          if (v2?.delegationGuide !== undefined) setGuideOn(Boolean(v2.delegationGuide))
        })
      }, [scope])
      const toggleGuide = react.useCallback(async () => {
        const next = !guideOn
        setGuideOn(next)
        try {
          await scope.set('delegationGuide', next)
        } catch (e) {
          setGuideOn(!next)
        }
      }, [scope, guideOn])

      // 使用 AGY 读取图片开关:读写 agy settings namespace 的 readImageAgy。
      const [imageRelayOn, setImageRelayOn] = react.useState(true)
      react.useEffect(() => {
        try {
          const v = scope.getSnapshot().value
          if (v?.readImageAgy !== undefined) setImageRelayOn(Boolean(v.readImageAgy))
        } catch { /* 镜像未就绪 */ }
        return scope.subscribe(() => {
          const v2 = scope.getSnapshot().value
          if (v2?.readImageAgy !== undefined) setImageRelayOn(Boolean(v2.readImageAgy))
        })
      }, [scope])
      const toggleImageRelay = react.useCallback(async () => {
        const next = !imageRelayOn
        setImageRelayOn(next)
        try {
          await scope.set('readImageAgy', next)
        } catch (e) {
          setImageRelayOn(!next)
        }
      }, [scope, imageRelayOn])

      // AGY 搜索接管开关:读写 agy settings namespace 的 searchOverride。
      const [searchOverrideOn, setSearchOverrideOn] = react.useState(true)
      react.useEffect(() => {
        try {
          const v = scope.getSnapshot().value
          if (v?.searchOverride !== undefined) setSearchOverrideOn(Boolean(v.searchOverride))
        } catch { /* 镜像未就绪 */ }
        return scope.subscribe(() => {
          const v2 = scope.getSnapshot().value
          if (v2?.searchOverride !== undefined) setSearchOverrideOn(Boolean(v2.searchOverride))
        })
      }, [scope])
      const toggleSearchOverride = react.useCallback(async () => {
        const next = !searchOverrideOn
        setSearchOverrideOn(next)
        try {
          await scope.set('searchOverride', next)
        } catch (e) {
          setSearchOverrideOn(!next)
        }
      }, [scope, searchOverrideOn])

      // 默认模型 + 代理:config 探测取当前值与明细;models 探测取可选列表;
      // 弹窗用官方 Modal,输入框用官方 Input(铺满卡片宽度)。
      const [models, setModels] = react.useState([])
      const [currentModel, setCurrentModel] = react.useState('')
      const [savedModel, setSavedModel] = react.useState('')
      const [currentProxy, setCurrentProxy] = react.useState('')
      const [savedProxy, setSavedProxy] = react.useState('')
      const [detailText, setDetailText] = react.useState('')
      const [loadingModels, setLoadingModels] = react.useState(false)
      const [pickerOpen, setPickerOpen] = react.useState(false)

      // 初始值与明细:读 SettingsScope 镜像(结构化、经网关校验)。
      // 避免响应 schema 校验失败导致解析出垃圾值)。
      const loadConfig = react.useCallback(async () => {
        try {
          const v = scope.getSnapshot().value ?? {}
          const model = v.model ?? ''
          const proxy = v.proxy ?? ''
          setCurrentModel(model)
          setSavedModel(model)
          setCurrentProxy(proxy)
          setSavedProxy(proxy)
          setDetailText(`命令:${v.command ?? 'agy'} | 强度:${v.effort ?? 'high'} | 代理:${proxy || '(空)'}`)
        } catch { /* 忽略 */ }
      }, [scope])

      const loadModels = react.useCallback(async () => {
        setLoadingModels(true)
        setModels([])
        try {
          // 自建模型列表路由(见服务端 models-route.ts):插件卡槽位拿不到
          // 会话级 remote,llm.discoverModels 对插件卡不可达。
          const resp = await fetch('/api/llm-agy/models', { headers: { accept: 'application/json' } })
          const data = await resp.json()
          if (data?.ok === true) {
            // 保留 {id, name} 结构:面板显示 name(标签),填回/比较一律用 id——
            // 设置里的 model 是传给 AGY CLI 的 id,填标签会让 spawn 拿到非法值。
            setModels((data.models ?? []).filter((m) => m !== null && typeof m === 'object'
              && typeof m.id === 'string' && m.id.length > 0))
          }
        } catch { /* 加载失败保持现状 */ } finally {
          setLoadingModels(false)
        }
      }, [])

      react.useEffect(() => {
        // 只加载存储的历史值,不自动拉取模型列表(点"获取模型"时才请求)。
        loadConfig()
      }, [loadConfig])

      // 提交默认模型:非空 = set,空 = unset(重置为 schema 默认,不写空字符串)。
      const writeModel = react.useCallback(async (value) => {
        try {
          if (value === '') await scope.unset('model')
          else await scope.set('model', value)
          if (value !== '') { setCurrentModel(value); setSavedModel(value) }
          loadConfig()
        } catch { /* 写失败回读还原 */ loadConfig() }
      }, [scope, loadConfig])

      const onModelInput = react.useCallback((e) => setCurrentModel(e.target.value), [])
      const onModelBlur = react.useCallback(() => {
        const value = currentModel.trim()
        if (value === savedModel) return
        writeModel(value)
      }, [currentModel, savedModel, writeModel])

      const openPicker = react.useCallback(async () => {
        setPickerOpen(true)
        if (models.length === 0) loadModels()
      }, [models.length, loadModels])
      const pickFromList = react.useCallback((value) => {
        writeModel(value)
        setPickerOpen(false)
      }, [writeModel])

      // 提交代理:非空 = set,空 = unset;与已保存值一致时跳过。
      const onProxyInput = react.useCallback((e) => setCurrentProxy(e.target.value), [])
      const onProxyBlur = react.useCallback(async () => {
        const value = currentProxy.trim()
        if (value === savedProxy) return
        try {
          if (value === '') await scope.unset('proxy')
          else await scope.set('proxy', value)
          setCurrentProxy(value)
          setSavedProxy(value)
        } catch { /* 写失败回读还原 */ loadConfig() }
      }, [currentProxy, savedProxy, scope, loadConfig])

      // 详情页:直接铺开字段(官方 plugins.item 详情页自带标题与说明,不画卡片头)。
      return react.createElement('div', { className: C.page },
          // 检测与测试
          react.createElement('div', { className: C.row },
            react.createElement(Button, {
              size: 'md', onClick: onStatus, disabled: checking,
              icon: checking
                ? react.createElement(IconLoadingOutlineRegular, { size: 14 })
                : react.createElement(IconRefreshOutlineRegular, { size: 14 }),
            }, checking ? '检测中...' : '检测安装/登录'),
            react.createElement(Button, {
              size: 'md', onClick: onTest, disabled: testing,
              icon: testing ? react.createElement(IconLoadingOutlineRegular, { size: 14 }) : undefined,
            }, testing ? '测试中...' : '测试(回复 hi)'),
          ),
          react.createElement('p', { className: C.hint }, '若已安装仍提示未安装,请重启 dsh 服务(PATH 生效后需重启)'),
          statusText !== '' && react.createElement('pre', { className: C.pre }, statusText),
          testText !== '' && react.createElement('pre', { className: C.pre }, testText),

          // 默认模型:字符串输入 + "获取模型"弹窗选择
          react.createElement('div', { className: C.field },
            react.createElement('div', { className: C.fieldHead },
              react.createElement('span', { className: C.label }, '默认模型'),
              react.createElement(Button, {
                size: 'sm', variant: 'ghost', onClick: openPicker, disabled: loadingModels,
                icon: loadingModels
                  ? react.createElement(IconLoadingOutlineRegular, { size: 12 })
                  : react.createElement(IconRefreshOutlineRegular, { size: 12 }),
              }, loadingModels ? '获取中...' : '获取模型'),
            ),
            react.createElement(Input, {
              type: 'text', value: currentModel, onChange: onModelInput, onBlur: onModelBlur,
              placeholder: '输入模型 id',
              className: C.modelField,
            }),
            detailText !== '' && react.createElement('p', { className: C.hint, style: { fontFamily: 'var(--dsw-font-family-code, monospace)' } }, detailText),
            react.createElement('p', { className: C.hint }, '可直接输入模型 id(失焦保存),或点"获取模型"从弹窗选择;留空则使用 AGY 默认'),
          ),

          // 代理:HTTP 代理,留空不设
          react.createElement('div', { className: C.field },
            react.createElement('div', { className: C.fieldHead },
              react.createElement('span', { className: C.label }, '代理'),
            ),
            react.createElement(Input, {
              type: 'text', value: currentProxy, onChange: onProxyInput, onBlur: onProxyBlur,
              placeholder: '例如 http://127.0.0.1:7890',
              className: C.modelField,
            }),
            react.createElement('p', { className: C.hint }, '例如 http://127.0.0.1:7890;留空则不设置代理(运行时未设置时回落到该地址)'),
          ),

          // 看图分工提示开关
          react.createElement('div', { className: C.field },
            react.createElement('div', { className: C.fieldHead },
              react.createElement('span', { className: C.label }, '注入工具使用提示词'),
              react.createElement('input', {
                type: 'checkbox',
                checked: guideOn,
                onChange: toggleGuide,
                style: { accentColor: 'var(--dsw-alias-brand-primary)', width: 16, height: 16, cursor: 'pointer' },
              }),
            ),
            react.createElement('p', { className: C.hint },
              guideOn
                ? '开启:注入工具使用提示词'
                : '关闭:不注入工具使用提示词',
            ),
          ),

          // 使用 AGY 读取图片开关
          react.createElement('div', { className: C.field },
            react.createElement('div', { className: C.fieldHead },
              react.createElement('span', { className: C.label }, '使用 AGY 读取图片'),
              react.createElement('input', {
                type: 'checkbox',
                checked: imageRelayOn,
                onChange: toggleImageRelay,
                style: { accentColor: 'var(--dsw-alias-brand-primary)', width: 16, height: 16, cursor: 'pointer' },
              }),
            ),
            react.createElement('p', { className: C.hint },
              imageRelayOn
                ? '开启:粘贴的图片由 AGY 读取为文字描述,文本模型也能看图(无需切换模型)'
                : '关闭:粘贴图片按原生流程处理(多模态模型可自己看图)',
            ),
          ),

          // AGY 搜索接管开关
          react.createElement('div', { className: C.field },
            react.createElement('div', { className: C.fieldHead },
              react.createElement('span', { className: C.label }, 'AGY 搜索接管 web_search'),
              react.createElement('input', {
                type: 'checkbox',
                checked: searchOverrideOn,
                onChange: toggleSearchOverride,
                style: { accentColor: 'var(--dsw-alias-brand-primary)', width: 16, height: 16, cursor: 'pointer' },
              }),
            ),
            react.createElement('p', { className: C.hint },
              searchOverrideOn
                ? '开启:全局 web_search 工具由 AGY 深度搜索提供'
                : '关闭:不占全局搜索(避免与其它搜索 provider 冲突),仅提供独立的 agy_web_search 工具',
            ),
          ),

          // 安装命令(多系统,每行带复制按钮)
          react.createElement('div', { className: C.field },
            react.createElement('div', { className: C.fieldHead },
              react.createElement('span', { className: C.label }, '安装命令'),
              react.createElement('span', { className: C.badge }, 'antigravity.google/docs/cli/install'),
            ),
            react.createElement('p', { className: C.hint }, '官方安装文档:https://antigravity.google/docs/cli/install'),
          ),
          ...INSTALL_CMDS.map((item) => react.createElement(InstallCommandRow, { key: item.label, label: item.label, cmd: item.cmd })),

          // 工具说明
          react.createElement('div', { className: C.field },
            react.createElement('div', { className: C.fieldHead },
              react.createElement('span', { className: C.label }, '工具说明'),
            ),
            react.createElement('ul', { style: { margin: 0, paddingLeft: 18, display: 'flex', flexDirection: 'column', gap: 4 } },
              TOOLS.map((t) => react.createElement('li', { key: t.name, className: C.hint },
                react.createElement('strong', { style: { color: 'var(--dsw-alias-label-secondary)' } }, t.name), ' — ', t.desc,
              )),
            ),
          ),

          // 获取模型弹窗:官方 Modal(模糊遮罩/Escape/标题/关闭) + Menu 样式列表
          react.createElement(Modal, {
            open: pickerOpen,
            onClose: () => setPickerOpen(false),
            title: '选择模型',
            closeLabel: '关闭',
          },
            loadingModels && models.length === 0
              ? react.createElement('p', { className: C.hint }, '加载中...')
              : models.length === 0
                ? react.createElement('p', { className: C.hint }, '未获取到模型列表,请确认 AGY CLI 已安装')
                : react.createElement('div', { className: C.pickerList },
                    models.map((m) => react.createElement('button', {
                      key: m.id,
                      type: 'button',
                      className: C.pickerItem,
                      onClick: () => pickFromList(m.id),
                    },
                      react.createElement('span', { className: C.pickerLabel }, m.name ?? m.id),
                      m.id === currentModel && react.createElement(IconCheckOutlineRegular, { className: C.pickerCheck, size: 14 }),
                    )),
                  ),
          ),
      )
    }

    // ── read_image_agy 会话工具卡片 ──
    // 对齐原生 read_image 卡片行:Disclose 行(浏览图标/读取图片标题/可打开路径),
    // 展开后渲染图片画廊(presentationMeta 携带的附件引用,经 loadImage 解析为
    // 会话授权 URL)与描述文本。运行中只显示摘要行;失败显示首行错误。

    /** 行状态:运行中/中断/失败/成功(与 ToolRow 的状态语义一致)。 */
    function blockStateOf(block) {
      if (!('kind' in block)) return 'running'
      if (block.error?.code === 'interrupted') return 'stopped'
      return block.isError ? 'error' : 'ok'
    }

    /** 路径缩写:主目录 → ~,工作区前缀剥除(显示用)。 */
    function abbreviatePath(path, cwd, home) {
      let p = path
      if (typeof home === 'string' && home.length > 1 && p.startsWith(home)) p = '~' + p.slice(home.length)
      if (typeof cwd === 'string' && cwd.length > 0) {
        const root = cwd.replace(/[/\\]+$/, '')
        if (p.startsWith(root + '/') || p.startsWith(root + '\\')) p = p.slice(root.length + 1)
      }
      return p
    }

    function firstLine(text) {
      const i = text.indexOf('\n')
      return i === -1 ? text : text.slice(0, i)
    }

    /**
     * 卡片正文文本:render 产物是 `<path>…</path>\n<content>描述</content>` 信封,
     * 展示时剥掉信封标签只留描述(路径已由摘要行展示);非信封形状(错误文本)原样返回。
     */
    function displayText(text) {
      const m = /<content>([\s\S]*)<\/content>\s*$/.exec(text)
      const inner = (m !== null ? m[1] : text).trim()
      return inner
    }

    /** 附件引用 → 会话授权 URL 的 <img>(状态机:peek 同步缓存优先,异步兜底)。 */
    function AgyImageGallery({ image, loadImage }) {
      const [url, setUrl] = react.useState(() => {
        try {
          const u = loadImage?.peek?.(image)
          return typeof u === 'string' ? u : undefined
        } catch { return undefined }
      })
      react.useEffect(() => {
        if (loadImage === undefined || typeof url === 'string') return undefined
        let alive = true
        loadImage(image).then((u) => {
          if (alive && typeof u === 'string') setUrl(u)
        }).catch(() => { /* 加载失败保持无图 */ })
        return () => { alive = false }
      }, [image, loadImage, url])
      if (typeof url !== 'string') return null
      return react.createElement('img', {
        src: url, className: C.tvImg, alt: image?.name ?? 'read_image_agy',
      })
    }

    /**
     * 构造 AGY 工具卡片行(工厂):行 chrome 与 read_image_agy 一致,差异全在 spec。
     *
     * spec 字段:
     * - title:conversation 命名空间的标题键;fallbackTitle:t 不可用时的兜底标题;
     * - icon:图标家族(read/bash/write/edit/search/globe);
     * - keys:摘要取值键(按序取第一个非空字符串参数);
     * - path:摘要是否为文件/目录路径(路径可点击打开,并做主目录/工作区缩写);
     * - mono:正文用等宽代码块样式(文件预览/diff);
     * - metaPath/metaImage:从结果 presentationMeta 取路径/图片(read_image_agy 用);
     * - gallery:展开时渲染图片画廊(需 metaImage)。
     */
    function makeAgyToolRow(spec) {
      return function AgyToolRow(props) {
        const { block, cwd, home, openFile, loadImage, t } = props
        const settled = 'kind' in block
        const state = blockStateOf(block)
        const argsRaw = (settled ? block.call?.argsRaw : block.argsRaw) ?? ''
        let args = {}
        try {
          const a = JSON.parse(argsRaw)
          if (a !== null && typeof a === 'object' && !Array.isArray(a)) args = a
        } catch { /* 参数未就绪或截断 */ }
        const meta = settled && typeof block.meta === 'object' && block.meta !== null ? block.meta : undefined
        // 图片引用双通道:presentationMeta(read_image_agy)或结果内容里的 image
        // 块(AGY 适配器对 view_file 读到图片时写入——会话附件授权按内容判定)。
        const contentImage = settled && Array.isArray(block.content)
          ? block.content.find((b) => b?.type === 'image' && typeof b?.attachment === 'object' && b?.attachment !== null)?.attachment
          : undefined
        const image = spec.gallery === true ? (meta?.image ?? contentImage) : undefined
        const metaPath = spec.metaPath === true && typeof meta?.path === 'string' && meta.path !== '' ? meta.path : undefined
        // 摘要:按 spec.keys 取第一个非空字符串;全部落空时退回第一个字符串参数。
        let raw = ''
        for (const key of spec.keys ?? []) {
          const v = args[key]
          if (typeof v === 'string' && v.trim() !== '') { raw = v; break }
        }
        if (raw === '') {
          for (const v of Object.values(args)) {
            if (typeof v === 'string' && v.trim() !== '') { raw = v; break }
          }
        }
        const rawPath = metaPath ?? (spec.path === true && raw !== '' ? raw : undefined)
        const displayPath = rawPath ?? ''
        const summary = displayPath !== ''
          ? abbreviatePath(displayPath, cwd, home)
          : firstLine(raw)
        // 结果文本:文本块原文拼接(AGY 工具输出为纯文本;信封剥壳对它是无操作)。
        const output = settled && Array.isArray(block.content)
          ? block.content
              .filter((b) => b?.type === 'text' && typeof b.text === 'string')
              .map((b) => b.text)
              .join('\n') || null
          : null
        const shownOutput = output !== null ? displayText(output) : null
        // 失败行的折叠摘要:content 有文本用首行;空 content 回退错误码
        // (对齐原生 ToolRow 的 resultText 空回退 error.name: error.code)。
        const failureLine = state === 'error'
          ? (shownOutput !== null && shownOutput !== '' ? firstLine(shownOutput) : `${block.error?.name ?? 'Error'}: ${block.error?.code ?? 'unknown'}`)
          : null
        const expandable = shownOutput !== null || image !== undefined
        const [open, setOpen] = react.useState(false)
        const showBody = open && expandable
        const leading = state === 'error'
          ? react.createElement(StateDot, { state: 'error' })
          : state === 'stopped'
            ? react.createElement(StateDot, { state: 'warning' })
            : AGY_TOOL_ICONS[spec.icon ?? 'read']()
        const collapsed = failureLine !== null
          ? react.createElement('span', { className: C.tvSummary + ' ' + C.tvErrorSummary }, failureLine)
          : summary === ''
            ? null
            : [
                react.createElement('span', { key: 'sep', className: C.tvSep, 'aria-hidden': true }),
                displayPath !== '' && typeof openFile === 'function' && state === 'ok'
                  ? react.createElement('button', {
                      key: 'path', type: 'button', className: C.tvFileLink,
                      onClick: (e) => { e.stopPropagation(); openFile(displayPath) },
                    }, summary)
                  : react.createElement('span', { key: 'path', className: C.tvSummary }, summary),
              ]
        return react.createElement('div', {
          className: C.tvRoot, 'data-state': state,
        },
          react.createElement(DisclosureRow, {
            icon: leading,
            title: typeof t === 'function' ? t(spec.title) : (spec.fallbackTitle ?? ''),
            open: showBody,
            expandable,
            expandOnRowClick: true,
            keepContentWhenOpen: true,
            onToggle: () => setOpen((v) => !v),
            rowClassName: C.tvRow,
            leadingClassName: C.tvLeading,
            titleClassName: C.tvTitle,
            chevronClassName: C.tvChevron,
            collapsedContent: collapsed,
          },
          showBody && react.createElement('div', { className: C.tvBody },
            image !== undefined && react.createElement(AgyImageGallery, { image, loadImage }),
            shownOutput !== null && shownOutput !== '' && react.createElement('div', {
              className: spec.mono === true ? C.tvCode : C.tvDesc,
            }, shownOutput),
          ),
          ),
        )
      }
    }

    /** 家族图标(与原生 GenericToolCard 的 VARIANT_ICONS 同款)。 */
    const AGY_TOOL_ICONS = {
      read: () => react.createElement(IconBrowseOutlineRegular, { size: 14 }),
      bash: () => react.createElement(IconApiOutlineMedium, { size: 14 }),
      write: () => react.createElement(IconEditOutlineRegular, { size: 14 }),
      edit: () => react.createElement(IconEditOutlineRegular, { size: 14 }),
      search: () => react.createElement(IconSearchOutlineRegular, { size: 14 }),
      globe: () => react.createElement(IconGlobeOutlineMedium, { size: 14 }),
    }

    /**
     * AGY(子代理)内部工具 → dsh 家族卡片映射。
     *
     * agy CLI 自己执行工具(浏览器/命令/文件),其 step 以 AGY 原名进会话时间线;
     * tool.call.toolview 键域开放,这里按 AGY 原名注册 dsh 同族的行呈现
     * (图标/标题/路径链接/展开输出)——会话日志保留真实工具名,不做重写。
     * 参数键是 AGY 的 PascalCase 口径(sessions 全量统计出的 13 种工具里的可映射子集)。
     */
    const AGY_TOOL_FAMILIES = {
      view_file: { title: 'tool.title.read', fallbackTitle: '读取文件', icon: 'read', keys: ['AbsolutePath', 'file_path'], path: true, mono: true, gallery: true },
      run_command: { title: 'tool.title.bash', fallbackTitle: '运行命令', icon: 'bash', keys: ['CommandLine', 'command'] },
      write_to_file: { title: 'tool.title.write', fallbackTitle: '写入文件', icon: 'write', keys: ['TargetFile', 'file_path'], path: true, mono: true },
      replace_file_content: { title: 'tool.title.edit', fallbackTitle: '编辑文件', icon: 'edit', keys: ['TargetFile', 'file_path'], path: true, mono: true },
      grep_search: { title: 'tool.title.grep', fallbackTitle: '内容搜索', icon: 'search', keys: ['Query', 'SearchPath'] },
      find_by_name: { title: 'tool.title.glob', fallbackTitle: '按名查找', icon: 'search', keys: ['Pattern', 'SearchDirectory'] },
      list_dir: { title: 'tool.title.read', fallbackTitle: '列目录', icon: 'read', keys: ['DirectoryPath'], path: true },
      read_url_content: { title: 'tool.title.webFetch', fallbackTitle: '网页获取', icon: 'globe', keys: ['Url'] },
      search_web: { title: 'tool.title.webSearch', fallbackTitle: '网页搜索', icon: 'search', keys: ['query'] },
    }
    /** read_image_agy 行:读取图片家族 + 展开图片画廊(引用来自 presentationMeta)。 */
    const AgyReadImageRow = makeAgyToolRow({
      title: 'tool.title.readImage', fallbackTitle: '读取图片', icon: 'read',
      keys: ['file_path'], path: true, metaPath: true, metaImage: true, gallery: true,
    })

    function apply(ctx) {
      // 0.2.1:settingsScope 已移除;命名空间改为 profile 条目 id(llm-agy)。
      const agyScope = ctx.configForms.get('llm-agy')
      const sectionInject = () => ({
        scope: agyScope,
      })
      ctx.effect(() => {
        return ctx.slots.inject('plugins.item', () => {
          return ctx.slots.register({
            name: 'plugins.item',
            id: 'llm-agy',
            order: 52,
            label: () => 'AntiGravity',
            inject: sectionInject,
          }, AgyCard)
        })
      }, 'llm-agy-client: plugins.item')
      // read_image_agy 会话工具卡片:对齐原生 read_image 的 read 家族行
      // (读取图片标题 + 可打开路径 + 展开显示图片画廊与描述文本)。
      // 图片引用来自工具结果的 presentationMeta(模型不可见,文本模型路由安全)。
      ctx.effect(() => {
        return ctx.slots.inject('tool.call.toolview', () => {
          return ctx.slots.register({
            name: 'tool.call.toolview',
            key: 'read_image_agy',
            locale: 'conversation',
          }, AgyReadImageRow)
        })
      }, 'llm-agy-client: read_image_agy toolview')
      // AGY 内部工具(view_file/run_command/...)按原名注册 dsh 家族行:
      // 子代理时间线里这些工具不再落通用"工具调用"行,而是与 dsh 原生工具同款
      // (图标/标题/可打开路径/展开输出)。未映射的工具照旧走通用行。
      for (const [toolName, spec] of Object.entries(AGY_TOOL_FAMILIES)) {
        const Row = makeAgyToolRow(spec)
        ctx.effect(() => {
          return ctx.slots.inject('tool.call.toolview', () => {
            return ctx.slots.register({
              name: 'tool.call.toolview',
              key: toolName,
              locale: 'conversation',
            }, Row)
          })
        }, `llm-agy-client: ${toolName} toolview`)
      }
    }



    exports.apply = apply
    exports.inject = ['slots', 'configForms']
    exports.name = 'llm-agy-client'
    return module.exports
  },
})
