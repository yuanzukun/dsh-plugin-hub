/**
 * llm-agy 插件入口:注册 AGY(Antigravity CLI)模型适配器 + 搜索 provider。
 * 对齐 llm-deepseek/index.ts 的结构:Config 定义 + apply 注册 provider 路由。
 * @module llm-agy
 */

import type { Context, Volatile } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { AgyLlmAdapter } from './adapter.js'
import { AgySearchProvider } from './search.js'
import type {} from '@deepseek-ai/dsh-settings'
import { registerAgySearchTool } from './search-tool.js'
import { registerAgySettings } from './settings.js'
import { registerDshMcpServer } from '@flg1217/dsh-mcp'
import { installImageRelay } from './image-paste.js'
import { captureAttachments, registerReadImageAgy } from './read-image.js'
import { installDelegationGuide } from './delegate-guide.js'
import { registerSubagentTool } from './subagent-tool.js'
import { registerAgyModelsTool } from './models.js'
import { registerAgyModelsRoute } from './models-route.js'
import { registerSearchWebAgy } from './search-web-agy.js'

export const name = 'llm-agy'
export const inject = ['llm', 'web', 'tools', 'subagents', 'systemPrompt']

/** 设置输入面(profile patch 条目 config / 表单写入的原始值;缺省走 schema 默认)。 */
export interface AgyConfigInput {
  command?: string
  model?: string
  effort?: string
  proxy?: string
  delegationGuide?: boolean
  readImageAgy?: boolean
  searchOverride?: boolean
  dshExecutor?: boolean
  extraArgs?: string[]
  registerSubagentTools?: boolean
}

/**
 * 本插件配置面(profile 条目 id = `llm-agy`;即设置表单)。
 * 前 8 个字段 volatile = 设置面板可编辑、读取即活引用;后两个仅 profile
 * patch 可编辑(不进表单,普通配置)。
 */
export interface Config {
  command: Volatile<string>
  model: Volatile<string>
  effort: Volatile<string>
  proxy: Volatile<string>
  delegationGuide: Volatile<boolean>
  readImageAgy: Volatile<boolean>
  searchOverride: Volatile<boolean>
  dshExecutor: Volatile<boolean>
  extraArgs: string[]
  registerSubagentTools: boolean
}

export const Config: z<AgyConfigInput, Config> = z.object({
  command: z.string().default('agy').description('agy 可执行文件命令(默认 agy)').volatile(),
  model: z.string().default('gemini-3.7-flash-high').description('传给 --model 的 AGY 模型').volatile(),
  effort: z.string().default('high').description('推理强度 low/medium/high').volatile(),
  proxy: z.string().default('http://127.0.0.1:7890')
    .description('AGY 流量代理(例如 http://127.0.0.1:7890;留空回落到默认)').volatile(),
  delegationGuide: z.boolean().default(true).description('注入子代理委派提示词').volatile(),
  readImageAgy: z.boolean().default(true).description('使用 AGY 读取粘贴的图片').volatile(),
  searchOverride: z.boolean().default(true).description('用 AGY 搜索接管全局 web_search 工具').volatile(),
  dshExecutor: z.boolean().default(true).description('AGY 工具全部经 dsh(禁用 AGY 自带工具)').volatile(),
  extraArgs: z.array(z.string()).default([]),
  registerSubagentTools: z.boolean().default(true),
})

/** 子代理委派工具:前端/UI 走 AGY/Gemini,独立于主模型。看图已由 read_image_agy 取代,不再注册子代理。 */
function registerSubagentTools(ctx: Context, model: string): void {
  const agentOptions = { provider: 'agy', model }
  // 自定义注册委派工具(替代官方 dsh-tool-subagent),以便在工具描述里
  // 内置"完整上下文"指引;机制一致(continuable 后台 + 前台回退)。
  registerSubagentTool(ctx, {
    provider: 'spawn',
    toolName: 'subagent_agy_ui',
    agentOptions,
    description:
      'Delegate a frontend/UI implementation task to an AGY/Gemini subagent (a separate agent driven by the '
      + 'Antigravity CLI) — UI design, styling research, visual implementation, screenshot verification — so it does '
      + 'not consume this conversation\'s context. The subagent returns its result, not its intermediate steps.\n\n'
      + 'Provide COMPLETE context for every delegation — the subagent does not see this conversation and cannot ask '
      + 'follow-up questions: (1) the goal and acceptance criteria; (2) exact file/directory paths to touch or inspect; '
      + '(3) constraints and boundaries (what NOT to do, what to preserve); (4) the expected output format. Split complex '
      + 'tasks into independent subagents and run them in parallel. '
      + 'This tool runs in the background by default: it immediately returns a durable subagent id and keeps the child '
      + 'conversation available for later turns; when the run settles, the runtime sends you a notice containing its '
      + 'outcome and any final assistant message. Set `run_in_background: false` only when your next action depends on '
      + 'receiving the result; `send_message` starts a later turn in the same child conversation. '
      + 'Optionally pass a `model` argument with an exact model id (query `list_agy_models` for the currently '
      + `supported ids); omit it to use the plugin-configured default model (\`${model}\`).`,
    promptDescription:
      'The complete, self-contained task for the subagent. It does not share this conversation\'s context, so include '
      + 'everything it needs: the goal, acceptance criteria, exact file paths, constraints, and the expected output format.',
  })
}

export function apply(ctx: Context, config: Config): void {
  // 设置面板:本插件自带页面(客户端 plugins.item,「插件列表」条目详情),关掉按 schema
  // 自动生成表单的策略(0.2.1 起替代旧 installSection;策略不移除配置读写)。
  ctx.inject(['settings'], (child) => {
    child.effect(() => child.settings.configure({ auto: false }, ctx.fiber))
  })

  // 模型探测通道先注册:命令/代理/模型实时读活引用,面板改动即时生效。
  registerAgySettings(ctx, config)
  /**
   * AGY 调用参数:每次调用实时读活引用(而不是插件加载时求值),
   * 设置面板里改代理/模型不需要重启。注意用 `||` 而非 `??`:手工把某项
   * 写成空串视为"未配置",继续回退内建默认。
   */
  const agyOptions = {
    get command(): string { return config.command.get() || 'agy' },
    get model(): string { return config.model.get() || 'gemini-3.7-flash-high' },
    get effort(): string { return config.effort.get() || 'high' },
    get proxy(): string { return config.proxy.get() || 'http://127.0.0.1:7890' },
  }

  // 设置面板的模型列表路由:插件卡槽位拿不到会话级 remote,发现只能自建
  // (围栏与 /api 网关行为一致,见 models-route.ts 模块头)。带缓存:agy models
  // 走网络很慢,刷新期间与失败时都回旧值。
  ctx.effect(() => registerAgyModelsRoute(ctx, () => ({ command: agyOptions.command, proxy: agyOptions.proxy })))

  ctx.llm.registerAdapter(['agy'], new AgyLlmAdapter(ctx, {
    command: agyOptions.command,
    model: agyOptions.model,
    effort: agyOptions.effort,
    extraArgs: config.extraArgs,
    proxy: agyOptions.proxy,
    // view_file 读到图片时走图片块通道(附件提交 + 画廊授权),与
    // read_image_agy 共用同一捕获的服务。
    getAttachments: captureAttachments(ctx),
    // AGY 工具全 dsh 化(getter,默认开):dsh-executor 自定义 agent 禁内置
    // 工具,全部工具经本插件注册的 dsh MCP 端点。
    dshExecutor: () => config.dshExecutor.get(),
  }))
  // dsh 的 MCP 端点(AGY 工具全 dsh 化通道):共享 @flg1217/dsh-mcp 提供单一
  // 端点(/api/dsh-mcp);agy 以 --agent dsh-executor 经全局 mcp_config.json 连接。
  registerDshMcpServer(ctx)
  // 子代理委派工具:前端/UI 设计(subagent_agy_ui,continuable 可复用长线会话),
  // 由 AGY/Gemini 驱动;看图不委派子代理(用全局 read_image_agy)。
  if (config.registerSubagentTools !== false) {
    registerSubagentTools(ctx, agyOptions.model)
  }
  // 模型查询工具:委派前可先确认当前支持的模型 id。command/proxy 用 getter
  // 实时读设置——之前透传的是一次性取值(默认代理而非面板配置的代理),
  // 导致 list_agy_models 不走设置里的代理。
  registerAgyModelsTool(ctx, {
    command: () => agyOptions.command,
    proxy: () => agyOptions.proxy,
    toolName: 'list_agy_models',
  })
  // AGY 搜索接入(searchOverride 开关热切换):
  // - 开:注册进全局 web 搜索缝(ctx.web),全局 web_search 工具走 AGY;
  // - 关:不占全局缝(避免与其它 provider 冲突),只注册独立 agy_web_search 工具。
  // 命令/模型/强度/代理一律走 agyOptions 活引用(与适配器同源,面板改动即时生效)。
  const searchOptions = () => ({
    command: agyOptions.command,
    model: agyOptions.model,
    effort: agyOptions.effort,
    proxy: agyOptions.proxy,
  })
  const searchDisposers = new Set<() => void>()
  const syncSearch = () => {
    for (const dispose of searchDisposers) {
      try { dispose() } catch { /* 注销失败不阻断 */ }
    }
    searchDisposers.clear()
    if (config.searchOverride.get()) {
      if (ctx.web !== undefined) {
        try {
          searchDisposers.add(ctx.web.registerSearchProvider(new AgySearchProvider(searchOptions())))
        } catch { /* 注册冲突等异常不阻断 */ }
      }
    } else {
      const dispose = registerAgySearchTool(ctx, searchOptions())
      if (dispose !== undefined) searchDisposers.add(dispose)
    }
  }
  syncSearch()
  // 注:read_image 覆盖由 router-agy 预设的 read-image-override.mjs
  // (agent 作用域同名注册 shadow 全局)实现,受设置表单 `readImageAgy` 开关控制;
  // 此处无需注册。
  // 图片中继(AGY 就地读图):受设置表单 `readImageAgy` 开关控制
  // (默认开启)。关闭时不注入 llm/stream 中继、不注册 AGY 看图工具、不禁用
  // 原生 read_image;设置面板切换后热同步(无需重启)。
  const imageServiceDisposers = new Set<() => void>()
  const syncImageServices = () => {
    const enabled = config.readImageAgy.get()
    if (enabled) {
      if (imageServiceDisposers.size === 0) {
        const disposeRelay = installImageRelay(ctx, () => ({
          command: agyOptions.command,
          proxy: agyOptions.proxy,
        }))
        if (disposeRelay !== undefined) imageServiceDisposers.add(disposeRelay)
        // AGY 看图工具(全局常驻):原生 read_image 被禁用后的替代入口,
        // 任何文本主模型都能通过它看图(返回 AGY 的文字描述)。
        const disposeTool = registerReadImageAgy(ctx, () => ({
          command: agyOptions.command,
          proxy: agyOptions.proxy,
        }))
        if (disposeTool !== undefined) imageServiceDisposers.add(disposeTool)
      }
    } else {
      for (const dispose of imageServiceDisposers) {
        try { dispose() } catch { /* 注销失败不阻断 */ }
      }
      imageServiceDisposers.clear()
    }
  }
  syncImageServices()
  // 0.2.1 起设置事件名为 settings/document-updated(ns, revision);
  // 旧 'settings/updated' 已不存在。ns = profile 条目 id(llm-agy)。
  ctx.on('settings/document-updated', (ns: string) => {
    if (ns === 'llm-agy') {
      syncSearch()
      syncImageServices()
    }
  })
  // 全局子代理委派提示(section),受设置表单 `delegationGuide` 开关控制
  // (apply 时读一次)。
  installDelegationGuide(ctx, config.delegationGuide.get())
}
