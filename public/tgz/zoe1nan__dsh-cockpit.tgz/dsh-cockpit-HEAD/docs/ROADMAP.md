# Cockpit 路线图与优化清单

> 当前版本：**v1.2.2**（已发布 2026-10-21 → [Release v1.2.2](https://github.com/zoe1nan/dsh-cockpit/releases/tag/v1.2.2)）。v1.2.2 = CI smoke 版本断言修复（不改插件行为）；v1.2.1 = D6 启动回放 + D7 实机验收/截图 + D8 术语统一。
> 发布方式：本机 git 协议不可用，经 GitHub REST API 把 1.0.1 / 1.1.0 / 1.2.0 的提交补放到 `main`（fast-forward，原有 7 stars 与 v1.0.0 Release 均保留）；1.0.1 / 1.1.0 同时补了 tag。
> CI：`.github/workflows/ci.yml` 已通过网页 UI 补入仓库，首次运行（syntax + tests / powershell parse 两个 job）全部通过。
> 本版路线图：2026-10-19 重梳理（v1.1.0 落地后，基于代码/文档走查 + 联调 harness 结果）。
> 更新规则：每完成一项，在 CHANGELOG 留一行并移入本文「已完成」；新想法先入 backlog，不直接插队。

---

## 0. 一句话现状

「看 / 批 / 说 / 盯」四件事已经闭环：任务板看全局、审批一键过、发消息插话、桌面胶囊和手机远程盯着。
**v1.0 解决「能用」，v1.1 解决「知道哪里坏了」（自检/分享/胶囊点击/空闲写入）；v1.2 该解决「用起来顺」——润色、优化、顺手补洞，不再铺新功能面。**

| 维度 | 现在 | 欠什么 |
| --- | --- | --- |
| 功能广度 | 编队/任务板/实时流/审批/写操作/胶囊/远程/PWA/扩展卡片/自检诊断/分享链接 | 成本与产物卡片、回滚、通知后台化、多语言、命令面板、移动端任务深化 |
| 稳定性 | 18 例单测 + CI + 24 项联调 harness；HUD 跟随修复已实机验证 | 6 套 tmp harness 未入库；无 DSH API 兼容层；插件重载瞬间的 running 状态会丢 |
| 平台 | Windows 胶囊 + 任意平台面板 | macOS/Linux 无胶囊；手机端离线能力弱 |
| 生态 | 卡片 API v1 + 一个示例插件 | 无 SDK 文档站、无第三方模板、无扩展市场 |

### v1.1.0 已完成（2026-10-19，本地提交 `5f82691`）

- 设置页「自检与诊断」：`GET /cockpit/api/diagnostics` 8 项只读检查 + 一键复制报告
- 可分享视图链接：顶栏「复制链接」→ `?s=` 恢复 + `history.replaceState` 同步；`?focus=approvals` 一次性深链
- 胶囊点击收敛：点本体打开指挥台（待审批时直达审批区），箭头区切展开，拖拽不变，桥缺失回退旧行为
- 空闲写入节流：`hud.json` 60 s / 胶囊帧 30 s keepalive（此前每秒重写）
- `node:test` 18 例 + GitHub Actions CI（syntax / test / pack）
- HUD 跟随修复（1.0.1 `f4c8c08`）随版本发布

### v1.2.0 已完成并发布（2026-10-19）

今日必做 7 项 + 1 项可选项已完成并单项提交：

- D2 `9b3c5e4`：preview 补齐 `diagnostics` 假数据与 `capsule` mock，新增 `scripts/preview-smoke.mjs`（26 项冒烟）
- D3 `8d1c73b`：`scripts/check-assets.mjs` 资产守卫（ps1 BOM/编码/换行、css 括号、版本一致性）；CI 增加 windows PowerShell 解析 job 与 preview smoke
- D4/D5 `7af7705`：失效 `?s=` 静默回落；`?focus=approvals` 最多等 3 帧 / 5 s，超时静默清理
- A1 `71c7bd8`：设置页信息层级与卡头统一（连接/设备 → 胶囊 → 自检 → 通知 → 别名 → 关于；窄屏 order 同步）
- A2 `2a46420`：反馈语气/时长统一（ok 2.4 s / warn 3.6 s / error 4.8 s）+ 内联错误统一 `.set-alert` + 失败文案给出下一步
- A4 `d946acb`：胶囊 hover 高亮 + 待审批琥珀描边（140/180 ms 淡入淡出，点击/拖拽/箭头区不变）
- B1 `b42d901`：实时流同类工具调用折叠「×N」+ 过滤空 detail（仅视图层，host 事件不丢）
- D7 实机验收（2026-10-21）：真实页面 CDP 检查 25/25 通过；README 截图重拍（desktop / desktop-dark / remote-settings / capsule-settings / mobile-dark，新增 capsule 与 diagnostics）
- D8 术语与文案统一（2026-10-21）：`docs/TERMS.md` 术语表 + `scripts/check-terms.mjs`（并入 `npm run check`）
- D6 启动回放（2026-10-21，v1.2.1）：插件启动 / 热重载时对每个会话回放最近 50 条事件，恢复 `running` / `lastAt` / `lastUserAt`；回放窗口内没有 `turn/start` 时不会把旧会话误标为运行中（幽灵 running 保护），4 条 `node:test` 覆盖

结论与调整：

- B2「渲染签名补全」经代码核对**已无必要**：`stateSignature()` 本就覆盖除 `now` / `session.elapsedMs` 外的全部 payload（含 approvals/remote/capsule），未变化时 `applyState` 直接返回、不重绘。进一步优化需把「整树重建」改为局部 patch，属 v1.3 范围，已移出今日清单。
- 发布时已同步：`package.json` / `mock/state.json` / `README` 安装命令 / `CHANGELOG` 顶部 / `docs/STATE.md` 抬头全部升到 v1.2.0；随后通过 GitHub API 发布（tag `v1.2.0` + Release 附件 `dsh-cockpit-1.2.0.tgz` / `.sha256`）。
- D6 启动回放已完成（见上），与 D8 一起进入 v1.2.1 补丁；C1 `scripts/release.mjs` 在 token + 网络就绪后随发布一起做。
- D7 实机验收已完成（2026-10-21）：插件重载到 v1.2.0 后，用 headless Edge CDP 直接驱动真实 `/cockpit/` 页面跑 25 项检查（overview 渲染、复制链接、设置页卡头、自检 8 行与徽标、D4 失效链接静默、D5 深链参数消费、分享链接、embed、移动端、无页面错误）全部通过；重拍 README 截图并新增胶囊 / 诊断卡截图。

---

## 1. 今天的走查结论（v1.2 的依据）

### 1.1 文档/数字失真（已在本版提交修正）

- `CHANGELOG.md` 1.1.0 段曾写「16 tests」，实际 **18**；`ROADMAP` 两处「16 条」同理（已统一）。
- `docs/STATE.md` 抬头曾为 `contract (v0.1)`，但 1.0.1 / 1.1.0 都改过契约（capsule 字段、诊断端点、分享链接）→ 已升 v1.1 并补充只读助手端点说明。
- 本文之前写「v1.1.0 已发布到 GitHub」，与事实不符（当时确实只在本机；现已于 2026-10-19 一并补发）。

### 1.2 预览/联调缺口

- `scripts/preview.mjs` 没有 `/cockpit/api/diagnostics` 路由 → 在 `npm run preview` 里打开「自检与诊断」必红，无法演示/录屏。
- `mock/state.json` 的 `version` 还是 `1.0.0`，且没有 `capsule` / `capsuleFocus` 字段（与真实 `/api/state` 不一致）。
- 6 套历史 harness 仍在 `tmp/`，未迁入 `tests/`（P0-1 后半）。

### 1.3 CI 守卫缺口（今天的真实坑）

- `capsule/overlay.ps1` 必须是 **UTF-8 带 BOM**，否则 Windows PowerShell 5.1 把中文读成乱码；edit 类工具会静默剥掉 BOM → 需要 CI 守卫。
- CI 现在只查 3 个 JS 的语法：PowerShell 解析、`public/app.css` 括号平衡、`scripts/preview.mjs` 冒烟（起服务抓 200）都没有。
- 本次 WPF 实测结论值得固化：`CaptureMouse` 后子元素收不到 MouseUp，胶囊点击分区只能靠坐标判断（已在 `overlay.ps1` 注释）。

### 1.4 运行期小缺口

- **失效 `?s=` 会弹 toast**：从旧链接进入时 applyState 丢弃选择并提示「该会话已结束」，噪音（应静默回落）。
- **`?focus=approvals` 首帧无审批就被消费**：标记在第一次 state 帧即清空，若那帧审批列表为空，深链静默失效。
- **重载瞬间 running 丢失**：poll 只种子 `lastSeq` 不回放历史，插件 reload / DSH 重启时正在跑的那轮 turn 不可见，直到下一次 turn/start。
- **渲染签名不完整**：`stateSignature()` 覆盖了主体字段，但 `approvals/remote/capsule` 的局部变化仍可能触发整段重渲染。
- **胶囊 hover 反馈弱**：目前只有 tooltip + 读数透明度动画，本体没有视觉高亮。
- **实时流未降噪**：host 只留 40 条，但 UI 整段重渲染，连续工具调用刷屏。

### 1.5 发布通道（最大不确定项）

- 本机到 github.com 不通，1.0.0 之后无法用 git 推送；需要 `scripts/release.mjs` 走 **token + GitHub API** 上传 tgz / 建 Release / 校验 sha256（ROADMAP 旧 P0-4）。

---

## 2. v1.2.0 方案（建议范围）

**主题：打磨与查缺补漏。** 不新增功能面，只做「润色 + 优化 + 升级（工程/发布）+ 补洞」。
估算 **2–3 天**（含实机回归）；原则：每项独立成 commit、有验收、可回滚。

### 2.1 查缺补漏 D（必做）

| 编号 | 事项 | 做法 | 验收 | 量级 |
| --- | --- | --- | --- | --- |
| D1 | 文档校准 ✅ | 已完成（本版路线图提交）：CHANGELOG 16→18；STATE.md 契约头升 v1.1 并注明只读助手端点；发布状态按当时实际写明（2026-10-19 已发布，见文首）；ROADMAP 数量/状态同步 | `grep -rn "16 tests\|16 条"` 除 §1.1 历史说明外为空；三份文档版本/状态一致 | — |
| D2 | preview 补齐 | `preview.mjs` 加 `/api/diagnostics` 假数据；`mock/state.json` 升 1.2.0 并补 `capsule` 字段；设置页「自检」在 preview 里可点 | `npm run preview` → 设置页自检卡显示「正常」，可展开报告 | 0.25 d |
| D3 | CI 守卫 | 加 `ps1 BOM` 检查脚本、`pwsh -File` 解析 overlay.ps1、`app.css` 括号平衡检查、preview 冒烟（起 6077 抓 `/cockpit/` 200） | CI 全绿；故意去掉 BOM 时 CI 失败 | 0.5 d |
| D4 | 失效 `?s=` 静默回落 | 区分「URL 带来的选择」与「用户手选」：来自 URL 的失效选择不弹 toast，直接换自动视图并清 URL | 旧链接打开无 toast；正常切换仍有提示 | 0.1 d |
| D5 | `?focus=approvals` 健壮化 | 标记保留到「审批列表非空」或 10 s 超时再清；审批出现后仍自动展开+滚动 | 审批稍后才到时深链仍生效；无审批时 10 s 后不残留 | 0.1 d |
| D6 | 启动回放 ✅ | 已完成（2026-10-21）：`index.js` 新增 `replayTail()`，启动与热重载时对每个会话回放最近 `REPLAY_EVENTS = 50` 条事件（经同一个 Tracker 折叠，`hydrated` 集合保证每个会话只回放一次，首条实时事件也会触发回放）；回放窗口内无 `turn/start` 则不产生 running（幽灵保护），poll 增量逻辑不变 | `node --test` 22 项全过（新增 `test/replay.test.mjs` 4 条：无边界不 running、turn/start 恢复、turn/end 清除、lastUserAt 恢复）；重载后首个 poll（≤500 ms）即恢复运行中会话 | 0.5 d |
| D7 | 实机验收 + 截图 ✅ | 已完成（2026-10-21）：重载到 v1.2.0 后用 CDP 驱动真实页面跑 25 项检查；重拍 `desktop` / `desktop-dark` / `remote-settings` / `capsule-settings`（卡面裁切）/ `mobile-dark`，新增 `capsule`（真实胶囊快照）与 `diagnostics`，README 引用更新。审批允许/拒绝、写操作等破坏性项未在真实会话上采样（由 preview harness 覆盖） | 25/25 检查通过；截图入库 | 0.5 d |
| D8 | 术语与文案统一 ✅ | 已完成（2026-10-21）：`docs/TERMS.md` 术语表 + 文案规则；README/CHANGELOG/ROADMAP/前端文案按表扫一遍（deck→指挥台、活动流→实时流、看板→任务板、对话→会话、拷贝→复制、HUD 桥→HUD 数据桥）；新增 `scripts/check-terms.mjs` 并入 `npm run check` | 术语表落文档；`npm run check` 含术语守卫 | 0.25 d |

### 2.2 润色 A（体验打磨）

| 编号 | 事项 | 做法 | 验收 | 量级 |
| --- | --- | --- | --- | --- |
| A1 | 设置页信息架构 | 左列：远程 → 胶囊 → **自检与诊断** → 通知 → 别名；右列：连接 → PWA → 关于；分组标题/版本行统一（版本 + 运行环境） | 三档宽度（1250/1000/390）无错位；新用户 30 s 内找到自检 | 0.5 d |
| A2 | 反馈一致性 | 按钮 busy/成功/失败态统一（remote/capsule/diag 共用一套 class）；hover/active/focus ring 统一 | 同操作在不同卡片表现一致；键盘 focus 可见 | 0.5 d |
| A3 | 空态/错误/加载文案 | 统一「加载中… / 加载失败 · 重试 / 暂无数据」措辞；错误里带下一步动作 | 全站无裸错误英文；重试路径可达 | 0.25 d |
| A4 | 胶囊 hover 视觉反馈 | 本体 hover 加轻微高亮/描边（不改尺寸，避免闪烁）+ cursor 已是 Hand；可点击区域一眼可辨 | 悬停 150ms 内有可见变化；不引起窗口抖动 | 0.25 d |
| A5 | 动效 token 化 | 关键时长/缓动收进 CSS 变量；`prefers-reduced-motion` 覆盖新加动效（现有 5 处 media query 基础上补齐） | 开 reduced-motion 后无动画残留；无布局跳变 | 0.25 d |
| A6 | README/文档润色 | 安装/升级/自检/限制结构重排；补 v1.1 功能截图；术语按 D8 表统一；CHANGELOG 链接 | 新用户按 README 5 分钟装好；链接无 404 | 0.5 d |

### 2.3 优化 B（性能与健壮性）

| 编号 | 事项 | 做法 | 验收 | 量级 |
| --- | --- | --- | --- | --- |
| B1 | 实时流降噪 | 连续同类工具调用折叠「运行命令 ×N」+ 过滤空 detail；暂不做虚拟化（40 条上限够用） | 100 条模拟活动下 DOM 行数 < 20；滚动无掉帧 | 0.5 d |
| B2 | 渲染签名补全 | `stateSignature()` 纳入 approvals/remote/capsule 关键字段（跳过时间戳），减少无效重渲染 | 无变化帧不触发 render（console 计数验证）；审批到达必重渲染 | 0.25 d |
| B3 | overlay 读取节流评估 | 用 snapshot 调试模式量 state/bridge 读取与空闲 CPU；必要时 350 ms→1 s、bridge 3 s 保持 | 空闲 CPU 不高于现基线；帧更新延迟 < 1 s | 0.25 d |
| B4 | 单卡异常隔离 | 卡片渲染/动作抛错只影响该卡片（错误占位 + 重试），不拖垮整页 | 注入坏卡片后其余卡片可交互 | 0.25 d |
| B5 | 长跑检查清单 | 8 h 空闲/活动内存、SSE 心跳、日志轮转、句柄数进验收清单 | 清单进 6.3 并有测量方法 | 0.25 d |

### 2.4 升级 C（工程/发布，本轮候选）

| 编号 | 事项 | 说明 | 建议版本 |
| --- | --- | --- | --- |
| C1 | `scripts/release.mjs` 发布通道 | 版本→`npm pack`→token API 上传 tgz→建 Release→校验 sha256；无 token 时 dry-run | **v1.2 候选**（解决当前推不上去的硬伤） |
| C2 | DSH API 兼容层 | `compat.js`：projection/agents/事件钩子收口，启动探测能力，缺失降级（只显示 lead），绝不抛错 | v1.3 |
| C3 | 英文界面 | `locale` 服务 en/zh，设置页切换；README 英文段对齐 | v1.3 |
| C4 | 命令面板 + 快捷键 | Ctrl/⌘+K 跳会话/搜任务/发消息；提示与焦点陷阱统一（P1-4） | v1.3 |
| C5 | 移动端任务 tab | 我的待办/阻塞原因/点进会话/快速发消息（P1-2） | v1.3 |

> 若只能做一轮：建议 v1.2 = **D1–D5、D8 + A1–A4 + B1–B2**（约 2 天，风险最低、观感提升最大）；
> D6/D7/C1 视时间追加。

---

## 3. Backlog（v1.3+ / 不排期）

| 编号 | 事项 | 价值 | 依赖 |
| --- | --- | --- | --- |
| C2 | DSH API 兼容层 + 降级用例 | DSH 升级不崩（最高优先） | 无 |
| C3 | 英文界面 | 海外可用 | 无 |
| C4 | 命令面板/快捷键/a11y | 键盘流体验 | 无 |
| C5 | 移动端任务 tab 深化 | 手机上闭环 | 无 |
| P2-1 | Web Push 审批推送 | 关页面也能收审批 | 公网 HTTPS |
| P2-2 | 自动隧道向导 | 手机远程零配置 | cloudflared/tailscale |
| P2-3 | 成本/产物卡片 | 官方卡片范例 | 上游数据 |
| P2-4 | 扩展 API v2 + SDK | 生态 | 卡片 API 稳定 |
| P2-5 | 任务板写操作 | 改状态/重指派 | 上游任务 API |
| P3 | 卡片 gallery / 文档站 / 主题包 / 模板 / 视频 / awesome 列表 | 生态与传播 | 有闲 |

---

## 4. 从旧路线图到新编号的对照

| 旧编号 | 旧内容 | 现在 |
| --- | --- | --- |
| P0-1 | 测试入库 + CI | ✅ 前半完成（18 例 + CI）；后半（6 套 harness 迁入）→ D2/后续 |
| P0-2 | DSH API 兼容层 | → C2（v1.3） |
| P0-3 | 远程安全补强 | 保持 backlog（低风险项并入 A 组文案） |
| P0-4 | 发布通道 | → C1（v1.2 候选） |
| P1-1 | 实时流虚拟化/降噪 | → B1（降噪先做，虚拟化观察后再定） |
| P1-2 | 移动端任务 tab | → C5（v1.3） |
| P1-3 | 设置页诊断 | ✅ v1.1 |
| P1-4 | 键盘与无障碍 | → A2/A5（基础）+ C4（命令面板） |
| P1-5 | 可分享链接 | ✅ v1.1（补 D4/D5 边界） |
| P1-6 | 胶囊交互 | ✅ v1.1（补 A4 hover 反馈） |
| P1-7 | 英文界面 | → C3（v1.3） |
| P2/P3 | 能力与生态 | 原样保留在 §3 |

---

## 5. 验收与回归

每次改动（v1.2 起固定流程）：

1. `npm test`（node:test，18+ 例）全绿
2. `node --check index.js client.js public/app.js` + overlay.ps1 BOM/解析检查（D3 起进 CI）
3. `npm pack --dry-run` 内容与体积无异常
4. `node scripts/preview.mjs` 冒烟：`/cockpit/` 200、设置页自检可点
5. 实机清单（每版一次，重载插件或重启 DSH 后）：
   - `/cockpit/api/state` 200，`session/capsule/team` 字段齐全
   - 审批：允许/拒绝各一次；`?focus=approvals` 深链
   - 写操作：发消息、插话、中断各一次
   - 胶囊：运行中显示、进度帧、点击开指挥台、箭头展开、关闭开关
   - 分享链接：两个窗口同链接同一会话
   - 诊断卡：8 项状态 + 复制报告
   - 远程：开/关、配对、撤销
   - 截图回归 1250 / 1000 / 390 三档宽度

### 性能预算（当前）

- state 帧 ≤ 30 KB；host 广播合并 260 ms；UI 状态签名跳过无变化渲染
- 胶囊：事件 150 ms 合并 + 每秒帧；overlay 读取 ≤ 500 ms；不变帧 30 s/60 s keepalive
- 目标：首屏 < 150 ms；常驻内存 < 80 MB

### 安全清单（已做，保持）

- [x] 远程端口只绑私有网段；配对码单次 + TTL + 失败锁定；Cookie HttpOnly/SameSite/Secure(https)
- [x] 写接口同源校验；审计文件轮转（256 KB → 保留 400 行）
- [ ] 扩展卡片动作信任边界写进文档（本地插件=可信；远程只读）
- [ ] 依赖升级检查（月度）

---

## 6. 已知限制（对外说明用）

1. Windows 专属胶囊（WPF + PowerShell），其他平台只有面板
2. 手机 PWA / 系统通知需要 HTTPS；局域网 http 只能当网页用
3. 后台推送（Web Push）未做，页面关闭后收不到审批提醒
4. 远程访问需要桌面端 DSH 保持运行；没有内置 TLS（需隧道或反代）
5. teammate 遥测依赖 DSH 投影与 agent 服务，上游变更可能降级（兼容层未做）
6. 任务板以只读展示为主，写操作集中在审批/消息/中断
7. 6 套历史集成 harness 仍在 `tmp/`（单测 18 例 + CI workflow 已入库，并在 GitHub Actions 跑通）
8. npm 包名 `dsh-cockpit` 已被占用，npm 发布需换名（GitHub Release 不受影响）
9. 本机 git 到 github.com 不通，发布依赖 token API 通道（2026-10-19 已用一次性脚本完成 v1.2.0 发布；C1 `scripts/release.mjs` 仍未做）

---

## 7. 需要拍板

> 2026-10-19 更新：第 1 项（v1.2 范围）已按建议落地并发布 v1.2.0；第 3 项（token / 发布）本次改用一次性 API 脚本完成，C1 `release.mjs` 仍待做；第 5 项（截图）随 D7 实机验收处理；第 2/4/6 项仍待拍板。

1. **v1.2 范围**：按 §2 建议（D1–D5、D8 + A1–A4 + B1–B2）先做一轮，还是缩到「只修 bug + 文档校准」的 patch（1.1.1）？
2. **D6 启动回放**：本轮做（体验直接受益，但动 Tracker 状态机），还是排 v1.3？
3. **C1 发布脚本**：本轮就做吗？需要你提供 token（环境变量名待定，例如 `DSH_COCKPIT_GITHUB_TOKEN`）与目标仓库确认。
4. **英文界面**：v1.3 还是更晚？（先有海外用户再做可以省 1.5 天）
5. **截图资产**：本轮是否重拍/补拍（需要起 preview + 浏览器截图；当前 docs/ 有 31 张旧图）？
6. **npm 发布**：是否要做（换包名，如 `dsh-command-deck`）？还是只发 GitHub Release + tgz？

---

## 8. 附录：旧版建议详情（保留备查）

> 以下是从 2026-10-18 版路线图（P0–P3 编号）保留下来的实现细节，新方案以 §2 为准；
> 排期时直接引用这里的「为什么 / 怎么做 / 验收 / 预估」。

### 兼容与稳定

- **DSH API 兼容层（旧 P0-2 → C2）**：teammate 遥测依赖 `sessionProjections` + `agents` 服务 + `snapshotEvents`（deprecated），DSH 一升级就可能整块数据消失。做法：projection key、agents 取法、事件钩子收进 `compat.js`；启动时探测能力，缺失则降级（只显示 lead / 隐藏泳道），绝不抛错。验收：模拟缺失 projection 的 fake-ctx 用例通过；面板不白屏、有降级提示。约 1 天。
- **启动回放（D6）**：插件启动时把最近 ~50 条事件补喂 Tracker，让重载/重启瞬间正在跑的 turn 立即可见；注意用「turn/start 后是否有 turn/end」判定，避免幽灵 running。

### 远程安全（旧 P0-3）

- 自动隧道启动目前是「检测 + 给命令」，用户手动复制；文档已写明风险 → 加**默认关闭 + 二次确认**，并补一条「公网可访问」的高危提醒。
- `cookie Secure` 只在 https 下加（已做）；补 **HSTS 提示**与「用 http 时隐藏 PWA/通知入口」的文案（入口已隐藏）。
- 远程 listener 的 `attempts` 已持久化 → 补**锁定告警**（连续失败达阈值时在桌面设置页提示）。
- 验收：安全清单逐条有测试或截图证据。约 0.5 天。

### 体验与性能

- **实时流虚拟化（旧 P1-1 → B1）**：host 只留 40 条活动，但 UI 整段重渲染，长会话滚动会顿。做：窗口化（超过 60 条只渲染可视区）、同类工具调用折叠成「运行命令 ×3」、过滤空 detail。验收：1000 条活动注入下滚动 60fps、首屏 ≤ 3 帧。约 1 天。
- **移动端任务 tab（旧 P1-2 → C5）**：手机端任务 tab 只有简单列表；补「我的待办、阻塞原因、点进会话、快速发消息」。验收：手机单列能完成「看到阻塞 → 发消息催」闭环。约 1 天。
- **键盘与无障碍（旧 P1-4 → C4 + A2/A5）**：Ctrl/⌘+K 命令面板（跳会话/搜任务/发消息/开关远程）、全局快捷键提示、焦点陷阱统一、tab 顺序审查、减少动效全量覆盖。验收：全流程纯键盘可完成；axe 扫描无 critical。约 1 天。
- **英文界面（旧 P1-7 → C3）**：UI 全中文；i18n 走 `locale` 服务，至少 en/zh 两套，设置页可切换。验收：切英文后无中文残留（截图检查 3 档宽度）。约 1.5 天。

### 能力升级（旧 P2）

- **后台推送 Web Push（P2-1）**：审批通知目前只在页面打开时生效；接 Service Worker + VAPID，订阅存 host，审批到达推送到手机（iOS 需 16.4+ 且添加到主屏）。依赖公网 HTTPS。验收：手机关页面仍能收到审批推送、点击回到对应审批。约 2 天。
- **自动隧道向导（P2-2）**：从「检测 cloudflared/tailscale + 复制命令」升级为「一键启动、自动公网地址、自动填入、显示二维码」；注意进程托管、退出清理、端口冲突；默认显式开启。验收：一键后手机可访问，关闭时隧道进程随之结束。约 2 天。
- **成本/产物卡片（P2-3）**：内置「本轮成本、今日 token、余额」与「产物清单（改了哪些文件、测试结果链接）」；以官方卡片形式实现，顺便当扩展 API 范例。验收：卡片可折叠、不拖慢帧率。约 1.5 天。
- **扩展 API v2 + SDK（P2-4）**：卡片 v2 增加 iframe 沙箱自定义渲染、权限声明、`cockpit.state` 订阅、事件回调（部署/测试状态）。验收：外部示例插件以 SDK 发布（GitHub 模板）。约 3 天。
- **任务板写操作（P2-5）**：改状态/重新指派/解除阻塞（目前只读，只有 todo 计划兜底）。依赖 DSH 团队任务 API 的稳定暴露；没有就只做「点任务跳会话」。验收：改动有审计、失败有回滚提示。约 2–3 天（依赖上游）。

### 生态与传播（旧 P3）

- 扩展卡片 gallery/模板仓库（5 个官方示例：git / tests / cost / calendar / deploy）
- 「Cockpit 插件开发」文档站（VitePress），含 API 参考与截图
- 官方主题包（深蓝、暖白、高对比）
- 团队启动模板（lead + 前端 + 后端 + 测试 + 审查）
- 发布视频素材（已有 20s 横版 / 60s 竖版）、B 站演示视频、X thread
- 提交 awesome-dsh-plugin（发布满 1 天后，用 v1.x 条目 + tarball）
- 与 dsh-hud 的关系：胶囊已内置，dsh-hud 仓库冻结，README 已指向 cockpit

### 环境/兼容矩阵（旧 §6.2）

- 支持 DSH 版本：实测 0.1.x（当前）；DSH 升级后按 §5 实机清单回归
- Windows 10 2004+（胶囊、WDA）；macOS/Linux：面板可用、胶囊不支持（需明确提示）
- Node 22+（插件 engines 已声明）
- 发布通道：npm 包名被占 → GitHub Release + tgz（token API 上传，见 C1）
