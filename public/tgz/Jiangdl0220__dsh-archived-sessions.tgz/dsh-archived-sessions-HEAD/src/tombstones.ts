/**
 * The plugin-owned tombstone store: session ids the user chose to remove from
 * the archive list. DSH ships no session-delete API, and dropping a session
 * from `archivedSessionIds` would resurrect it as a stray sidebar row, so a
 * delete keeps the session archived and records the id here instead.
 *
 * Durable state lives in `<DSH_HOME>/archived-sessions/tombstones.json`, read
 * and written through `ctx.fs`. DSH 0.1.7+ dropped the plugin-owned settings
 * namespace API (`settingsNamespace` / `ctx.settings.register`) that earlier
 * releases imported, and no replacement registration seam exists for plugin
 * data, so a plain file under the DSH home is the supported path — the same
 * shape `dsh-memory` uses for its own store. Session data itself is never
 * touched, matching the product, which never deletes session logs.
 */
import type { Context } from '@deepseek-ai/cordis'

/** Minimal structural face of `ctx.fs` (the subset this store uses). */
interface FsTargetLike {
  readonly targetKey: string
}

interface FsLike {
  resolve(path: string, opts?: { cwd?: string }): Promise<FsTargetLike>
  readText(target: FsTargetLike): Promise<string>
  writeText(target: FsTargetLike, content: string): Promise<unknown>
}

/** File, relative to the DSH home, holding the tombstone list. */
const STORE_RELATIVE_PATH = 'archived-sessions/tombstones.json'

/** Resolve the DSH home directory (matches the deployment default). */
function dshHome(env: NodeJS.ProcessEnv = process.env): string {
  return env.DSH_HOME ?? `${env.HOME ?? ''}/.dsh`
}

/** Durable set of session ids tombstoned by this plugin. */
export interface TombstoneStore {
  /** All tombstoned session ids (empty when the store file is absent). */
  read(): Promise<Set<string>>
  /** Persist the complete tombstone list. */
  save(ids: readonly string[]): Promise<void>
}

/**
 * Create the fs-backed tombstone store.
 * @param ctx - the plugin context carrying the `fs` service.
 * @returns the store the runtime reads and writes.
 */
export function createTombstoneStore(ctx: Context): TombstoneStore {
  const fs = (): FsLike => {
    const service = ctx.get('fs') as FsLike | undefined
    if (service === undefined) throw new Error('dsh-archived-sessions: fs service unavailable')
    return service
  }
  const target = (): Promise<FsTargetLike> => fs().resolve(`${dshHome()}/${STORE_RELATIVE_PATH}`)
  return {
    async read(): Promise<Set<string>> {
      try {
        const raw = await fs().readText(await target())
        const parsed = JSON.parse(raw) as { deleted?: unknown }
        const deleted = Array.isArray(parsed.deleted)
          ? parsed.deleted.filter((id): id is string => typeof id === 'string')
          : []
        return new Set(deleted)
      } catch {
        // Absent (first run) or unreadable store: no tombstones recorded yet.
        return new Set()
      }
    },
    async save(ids: readonly string[]): Promise<void> {
      await fs().writeText(await target(), JSON.stringify({ deleted: [...ids] }, null, 2))
    },
  }
}
