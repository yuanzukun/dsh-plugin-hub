import { embeddedWorldBookDocument } from '../../memory-sources/embedded-document.js'
import { createHash } from 'node:crypto'
import {
  WORLD_BOOK_LIMITS,
  computeWorldBookCandidates,
  mergeWorldBookLoaderResults,
  projectWorldBookForLoader,
} from '../../world-book/src/index.js'

function messageText(message) {
  if (message?.role !== 'user' && message?.role !== 'assistant') return ''
  return Array.isArray(message.content)
    ? message.content
      .filter((block) => block?.type === 'text' && typeof block.text === 'string')
      .map((block) => block.text)
      .join('\n')
    : ''
}

function boundedScanText(model, context, maxCharacters, maxMessages) {
  let text = typeof context.conversationText === 'string' ? context.conversationText : ''
  let messages = Array.isArray(context.activationContext?.messages)
    ? context.activationContext.messages.map(message => message?.text).filter(text => typeof text === 'string' && text !== '')
    : null
  if (messages === null && typeof context.agent?.session?.deriveMessages === 'function') {
    messages = context.agent.session.deriveMessages().map(messageText).filter(Boolean)
  }
  if (messages !== null) {
    const depth = model.settings?.scanDepth
    const depthBounded = depth === 0 ? [] : (Number.isSafeInteger(depth) ? messages.slice(-depth) : messages)
    text = depthBounded.slice(-maxMessages).join('\n')
  }
  const originalLength = text.length
  const activationOriginalLength = Number.isSafeInteger(context.activationContext?.metadata?.inputCharacters)
    ? context.activationContext.metadata.inputCharacters
    : originalLength
  const truncatedBeforeAdapter = context.activationContext?.metadata?.truncated === true
  return originalLength <= maxCharacters
    ? { text, truncated: truncatedBeforeAdapter, originalLength: Math.max(originalLength, activationOriginalLength) }
    : { text: text.slice(-maxCharacters), truncated: true, originalLength: Math.max(originalLength, activationOriginalLength) }
}

function resolveArguments(storeOrOptions, maybeOptions) {
  if (typeof storeOrOptions?.get === 'function') return { store: storeOrOptions, options: maybeOptions ?? {} }
  return { store: null, options: storeOrOptions ?? {} }
}

function projectBook(document, context, options) {
  const model = document.book
  const maxScanCharacters = Number.isSafeInteger(options.maxScanCharacters) && options.maxScanCharacters > 0
    ? options.maxScanCharacters
    : 64 * 1024
  const maxScanMessages = Number.isSafeInteger(options.maxScanMessages) && options.maxScanMessages > 0
    ? Math.min(options.maxScanMessages, 1024)
    : 128
  const scan = boundedScanText(model, context, maxScanCharacters, maxScanMessages)
  const candidates = computeWorldBookCandidates(model, {
    text: scan.text,
    tokenBudget: model.settings?.tokenBudget ?? options.defaultTokenBudget,
    probabilityRolls: options.probabilityRolls,
    groupRolls: options.groupRolls,
    allowUnsafeRegex: options.allowUnsafeRegex === true,
    maxRegexLength: options.maxRegexLength,
  })
  const projected = projectWorldBookForLoader(model, candidates, {
    resource: {
      id: document.id,
      name: document.name,
      kind: document.ownerSessionId ? 'session-opening-book' : 'standalone-world-book',
      ...(document.ownerSessionId ? { ownerSessionId: document.ownerSessionId, ownerCharacterId: document.ownerCharacterId } : {}),
      updatedAt: document.updatedAt,
      revision: createHash('sha256').update(JSON.stringify(document)).digest('hex'),
      bindingSources: Array.isArray(context.bindingSources) ? [...context.bindingSources] : ['session'],
    },
  })
  if (model.settings?.recursiveScanning === true) {
    projected.diagnostics.push({
      code: 'WORLD_BOOK_RECURSION_DEFERRED',
      severity: 'warning',
      message: 'Recursive world-book scanning is preserved but not executed in this runtime phase.',
      resourceId: document.id,
    })
  }
  if (scan.truncated) {
    projected.diagnostics.push({
      code: 'WORLD_BOOK_SCAN_TEXT_TRUNCATED',
      severity: 'info',
      message: `World-book scan input was limited to the most recent ${scan.text.length} characters`,
      resourceId: document.id,
      originalCharacters: scan.originalLength,
      scannedCharacters: scan.text.length,
    })
  }
  return projected
}

export function createWorldBookAdapter(storeOrOptions = {}, maybeOptions = {}) {
  const { store, options } = resolveArguments(storeOrOptions, maybeOptions)
  return {
    resolve({
      selection,
      worldBookSelection,
      character,
      conversationText = '',
      activationContext = null,
      requestAssembly = false,
      agent,
      sessionId = agent?.id ?? null,
    } = {}) {
      const results = []
      const diagnostics = []
      const requestedRuntimeEntries = Number.isSafeInteger(options.maxRuntimeEntries) && options.maxRuntimeEntries > 0
        ? options.maxRuntimeEntries
        : WORLD_BOOK_LIMITS.maxRuntimeEntries
      const maxRuntimeEntries = Math.min(requestedRuntimeEntries, WORLD_BOOK_LIMITS.maxRuntimeEntries)
      let reservedRuntimeEntries = 0
      const reserve = (model, resourceId) => {
        const entryCount = Array.isArray(model?.entries) ? model.entries.length : 0
        if (reservedRuntimeEntries + entryCount <= maxRuntimeEntries) {
          reservedRuntimeEntries += entryCount
          return true
        }
        diagnostics.push({
          code: 'WORLD_BOOK_RUNTIME_TOTAL_LIMIT',
          severity: 'warning',
          message: `World-book matching is limited to ${maxRuntimeEntries} total entries per request; this resource was not scanned.`,
          resourceId,
          entryCount,
          reservedEntries: reservedRuntimeEntries,
          limit: maxRuntimeEntries,
        })
        return false
      }

      if (Array.isArray(selection?.worldBookIds) && selection.worldBookIds.length > 0) {
        for (const id of selection.worldBookIds) {
          if (store === null) {
            diagnostics.push({
              code: 'WORLD_BOOK_STORE_NOT_INSTALLED',
              severity: 'warning',
              message: 'Standalone world-book ids are selected, but no world-book document store is installed.',
              resourceIds: [...selection.worldBookIds],
            })
            break
          }
          try {
            if (options.allowResource && !options.allowResource(id, { requestAssembly })) {
              diagnostics.push({ code: 'WORLD_BOOK_MANAGED_REQUIRES_ASSEMBLY', severity: 'warning', resourceId: id, message: 'Managed world book requires request assembly and a current manager policy.' })
              continue
            }
            const document = options.resolveDocument ? options.resolveDocument(id, { sessionId }) : store.get(id)
            if (!reserve(document.book, id)) continue
            const bindingSources = [
              ...(worldBookSelection?.explicitIds?.includes(id) ? ['session'] : []),
              ...(worldBookSelection?.userBoundIds?.includes(id) ? ['user'] : []),
              ...(worldBookSelection?.presetBoundIds?.includes(id) ? ['preset'] : []),
              ...(worldBookSelection?.characterBoundIds?.includes(id) ? ['character'] : []),
            ]
            if (bindingSources.length === 0) bindingSources.push('session')
            results.push(projectBook(document, {
              agent,
              conversationText,
              activationContext,
              bindingSources,
            }, options))
          } catch (error) {
            diagnostics.push({
              code: error?.code === 'WORLD_BOOK_NOT_FOUND' ? 'WORLD_BOOK_NOT_FOUND' : 'WORLD_BOOK_DOCUMENT_INVALID',
              severity: 'warning',
              message: error instanceof Error ? error.message : String(error),
              resourceId: id,
            })
          }
        }
      }

      const embedded = character?.data?.characterBook
      if (embedded !== null && typeof embedded === 'object' && !Array.isArray(embedded)) {
        try {
          const document = embeddedWorldBookDocument(character), model = document.book
          const resourceId = document.id
          if (options.allowResource && !options.allowResource(resourceId, { requestAssembly })) {
            diagnostics.push({ code: 'WORLD_BOOK_MANAGED_REQUIRES_ASSEMBLY', severity: 'warning', resourceId, message: 'Managed embedded world book requires request assembly and a current manager policy.' })
            const merged = mergeWorldBookLoaderResults(results)
            return { ...merged, diagnostics: [...diagnostics, ...merged.diagnostics] }
          }
          if (!reserve(model, resourceId)) {
            const merged = mergeWorldBookLoaderResults(results)
            return { ...merged, diagnostics: [...diagnostics, ...merged.diagnostics] }
          }
          const maxScanCharacters = Number.isSafeInteger(options.maxScanCharacters) && options.maxScanCharacters > 0
            ? options.maxScanCharacters
            : 64 * 1024
          const maxScanMessages = Number.isSafeInteger(options.maxScanMessages) && options.maxScanMessages > 0
            ? Math.min(options.maxScanMessages, 1024)
            : 128
          const scan = boundedScanText(model, { agent, conversationText, activationContext }, maxScanCharacters, maxScanMessages)
          const candidates = computeWorldBookCandidates(model, {
            text: scan.text,
            tokenBudget: model.settings?.tokenBudget ?? options.defaultTokenBudget,
            probabilityRolls: options.probabilityRolls,
            groupRolls: options.groupRolls,
            allowUnsafeRegex: options.allowUnsafeRegex === true,
            maxRegexLength: options.maxRegexLength,
          })
          const projected = projectWorldBookForLoader(model, candidates, {
            resource: {
              id: resourceId,
              name: model.name,
              ownerCharacterId: character.id,
              kind: 'embedded-character-book',
              revision: createHash('sha256').update(JSON.stringify(document)).digest('hex'),
            },
          })
          if (model.settings?.recursiveScanning === true) {
            projected.diagnostics.push({
              code: 'WORLD_BOOK_RECURSION_DEFERRED',
              severity: 'warning',
              message: 'Recursive world-book scanning is preserved but not executed in the first loader integration slice.',
              resourceId,
            })
          }
          if (scan.truncated) {
            projected.diagnostics.push({
              code: 'WORLD_BOOK_SCAN_TEXT_TRUNCATED',
              severity: 'info',
              message: `World-book scan input was limited to the most recent ${scan.text.length} characters`,
              resourceId,
              originalCharacters: scan.originalLength,
              scannedCharacters: scan.text.length,
            })
          }
          results.push(projected)
        } catch (error) {
          diagnostics.push({
            code: 'EMBEDDED_WORLD_BOOK_INVALID',
            severity: 'warning',
            message: error instanceof Error ? error.message : String(error),
            resourceId: `character:${character.id}:embedded-world-book`,
          })
        }
      }

      const merged = mergeWorldBookLoaderResults(results)
      return {
        ...merged,
        diagnostics: [...diagnostics, ...merged.diagnostics],
      }
    },
  }
}
